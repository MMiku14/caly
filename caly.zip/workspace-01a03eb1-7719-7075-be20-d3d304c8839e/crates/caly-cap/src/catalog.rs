use crate::loader::{CoverageEntry, CoverageMatrixDocument, RegistryDocument};
use crate::registry::{
    CapabilityDescriptor, CapabilityDomain, CapabilityKey, CapabilityState, Constraint,
    EvidenceRef, FallbackPolicy, SupportLevel,
};

pub fn default_registry_document() -> RegistryDocument {
    RegistryDocument {
        version: 1,
        capabilities: vec![
            descriptor(
                "dns.fake_ip",
                "Fake-IP DNS",
                CapabilityDomain::Dns,
                SupportLevel::CalyManaged,
                CapabilityState::SupportedExact,
                Vec::new(),
                None,
                "dns-fake-ip-basic",
            ),
            descriptor(
                "runtime.group.select",
                "Proxy group runtime selection",
                CapabilityDomain::Runtime,
                SupportLevel::CalyManaged,
                CapabilityState::SupportedExact,
                vec![Constraint {
                    field: "runtime_api".to_owned(),
                    expected: "control-plane-select-supported".to_owned(),
                }],
                None,
                "runtime-group-select",
            ),
            descriptor(
                "routing.rules",
                "Rule-based routing",
                CapabilityDomain::Routing,
                SupportLevel::CalyManaged,
                CapabilityState::SupportedExact,
                Vec::new(),
                None,
                "routing-rules-basic",
            ),
            descriptor(
                "network.tun",
                "TUN routing",
                CapabilityDomain::Tun,
                SupportLevel::CalyManaged,
                CapabilityState::SupportedExact,
                Vec::new(),
                Some(FallbackPolicy::EscalateToRestart),
                "tun-basic",
            ),
            descriptor(
                "tun.auto_route",
                "TUN auto-route",
                CapabilityDomain::Tun,
                SupportLevel::CalyManaged,
                CapabilityState::Experimental,
                Vec::new(),
                Some(FallbackPolicy::EscalateToRestart),
                "tun-auto-route",
            ),
            descriptor(
                "tun.strict_route",
                "TUN strict-route",
                CapabilityDomain::Tun,
                SupportLevel::CalyManaged,
                CapabilityState::Experimental,
                some_constraint("mode", "strict-route"),
                Some(FallbackPolicy::EscalateToRestart),
                "tun-strict-route",
            ),
            descriptor(
                "outbound.wireguard",
                "WireGuard outbound",
                CapabilityDomain::Outbounds,
                SupportLevel::NativeManaged,
                CapabilityState::SupportedNativeOnly,
                Vec::new(),
                Some(FallbackPolicy::UseNativeOnlyMode),
                "wireguard-outbound",
            ),
            descriptor(
                "proxy.shadowsocks",
                "Shadowsocks proxy",
                CapabilityDomain::Proxies,
                SupportLevel::CalyManaged,
                CapabilityState::SupportedExact,
                Vec::new(),
                None,
                "proxy-shadowsocks",
            ),
            descriptor(
                "proxy.vmess",
                "VMess proxy",
                CapabilityDomain::Proxies,
                SupportLevel::CalyManaged,
                CapabilityState::SupportedExact,
                Vec::new(),
                None,
                "proxy-vmess",
            ),
            descriptor(
                "proxy.vless",
                "VLESS proxy",
                CapabilityDomain::Proxies,
                SupportLevel::CalyManaged,
                CapabilityState::SupportedExact,
                Vec::new(),
                None,
                "proxy-vless",
            ),
            descriptor(
                "proxy.trojan",
                "Trojan proxy",
                CapabilityDomain::Proxies,
                SupportLevel::CalyManaged,
                CapabilityState::SupportedExact,
                Vec::new(),
                None,
                "proxy-trojan",
            ),
            descriptor(
                "proxy.hysteria2",
                "Hysteria2 proxy",
                CapabilityDomain::Proxies,
                SupportLevel::NativeManaged,
                CapabilityState::Experimental,
                Vec::new(),
                Some(FallbackPolicy::UseNativeOnlyMode),
                "proxy-hysteria2",
            ),
            descriptor(
                "proxy.tuic",
                "TUIC proxy",
                CapabilityDomain::Proxies,
                SupportLevel::NativeManaged,
                CapabilityState::Experimental,
                Vec::new(),
                Some(FallbackPolicy::UseNativeOnlyMode),
                "proxy-tuic",
            ),
            descriptor(
                "proxy.wireguard",
                "WireGuard proxy node",
                CapabilityDomain::Proxies,
                SupportLevel::NativeManaged,
                CapabilityState::SupportedNativeOnly,
                Vec::new(),
                Some(FallbackPolicy::UseNativeOnlyMode),
                "proxy-wireguard",
            ),
            descriptor(
                "group.relay",
                "Relay or chain style proxy groups",
                CapabilityDomain::ProxyGroups,
                SupportLevel::NativeManaged,
                CapabilityState::SupportedNativeOnly,
                some_constraint("target_core", "same-core-native-semantics"),
                Some(FallbackPolicy::PreserveOpaqueSameCore),
                "relay-group-native",
            ),
        ],
    }
}

pub fn default_coverage_matrix_document() -> CoverageMatrixDocument {
    CoverageMatrixDocument {
        version: 1,
        matrix: vec![
            coverage("dns.fake_ip", "mihomo", SupportLevel::CalyManaged, CapabilityState::SupportedExact),
            coverage("dns.fake_ip", "sing-box", SupportLevel::CalyManaged, CapabilityState::SupportedExact),
            coverage("runtime.group.select", "mihomo", SupportLevel::CalyManaged, CapabilityState::SupportedExact),
            coverage("runtime.group.select", "sing-box", SupportLevel::NativeManaged, CapabilityState::Experimental),
            coverage("routing.rules", "mihomo", SupportLevel::CalyManaged, CapabilityState::SupportedExact),
            coverage("routing.rules", "sing-box", SupportLevel::CalyManaged, CapabilityState::SupportedExact),
            coverage("network.tun", "mihomo", SupportLevel::CalyManaged, CapabilityState::SupportedExact),
            coverage("network.tun", "sing-box", SupportLevel::CalyManaged, CapabilityState::SupportedExact),
            coverage("tun.auto_route", "mihomo", SupportLevel::CalyManaged, CapabilityState::Experimental),
            coverage("tun.auto_route", "sing-box", SupportLevel::CalyManaged, CapabilityState::SupportedExact),
            coverage("tun.strict_route", "mihomo", SupportLevel::CalyManaged, CapabilityState::Unsupported),
            coverage("tun.strict_route", "sing-box", SupportLevel::CalyManaged, CapabilityState::SupportedExact),
            coverage("outbound.wireguard", "mihomo", SupportLevel::NativeManaged, CapabilityState::Unsupported),
            coverage("outbound.wireguard", "sing-box", SupportLevel::NativeManaged, CapabilityState::SupportedNativeOnly),
            coverage("proxy.shadowsocks", "*", SupportLevel::CalyManaged, CapabilityState::SupportedExact),
            coverage("proxy.vmess", "*", SupportLevel::CalyManaged, CapabilityState::SupportedExact),
            coverage("proxy.vless", "*", SupportLevel::CalyManaged, CapabilityState::SupportedExact),
            coverage("proxy.trojan", "*", SupportLevel::CalyManaged, CapabilityState::SupportedExact),
            coverage("proxy.hysteria2", "mihomo", SupportLevel::NativeManaged, CapabilityState::Experimental),
            coverage("proxy.hysteria2", "sing-box", SupportLevel::NativeManaged, CapabilityState::Experimental),
            coverage("proxy.tuic", "mihomo", SupportLevel::NativeManaged, CapabilityState::Experimental),
            coverage("proxy.tuic", "sing-box", SupportLevel::NativeManaged, CapabilityState::Experimental),
            coverage("proxy.wireguard", "mihomo", SupportLevel::NativeManaged, CapabilityState::Unsupported),
            coverage("proxy.wireguard", "sing-box", SupportLevel::NativeManaged, CapabilityState::SupportedNativeOnly),
            coverage("group.relay", "sing-box", SupportLevel::NativeManaged, CapabilityState::SupportedNativeOnly),
        ],
    }
}

pub fn merged_registry_document(
    base: &RegistryDocument,
    offered: &[CapabilityDescriptor],
) -> RegistryDocument {
    let mut capabilities = base.capabilities.clone();
    for descriptor in offered {
        if let Some(existing) = capabilities
            .iter_mut()
            .find(|value| value.key == descriptor.key)
        {
            *existing = descriptor.clone();
        } else {
            capabilities.push(descriptor.clone());
        }
    }
    RegistryDocument {
        version: base.version,
        capabilities,
    }
}

pub fn merged_coverage_matrix(
    base: &CoverageMatrixDocument,
    offered: &[CapabilityDescriptor],
    target_core: impl Into<String>,
) -> CoverageMatrixDocument {
    let target_core = target_core.into();
    let mut matrix = base.matrix.clone();
    for descriptor in offered {
        let candidate = CoverageEntry {
            capability_key: descriptor.key.clone(),
            target_core: target_core.clone(),
            version_range: "*".to_owned(),
            support_level: descriptor.support_level,
            state: descriptor.state,
            platforms: vec!["*".to_owned()],
            evidence: evidence_for_descriptor(descriptor),
        };
        if let Some(existing) = matrix.iter_mut().find(|entry| {
            entry.capability_key == candidate.capability_key && entry.target_core == candidate.target_core
        }) {
            *existing = candidate;
        } else {
            matrix.push(candidate);
        }
    }
    CoverageMatrixDocument {
        version: base.version,
        matrix,
    }
}

fn descriptor(
    key: &str,
    title: &str,
    domain: CapabilityDomain,
    support_level: SupportLevel,
    state: CapabilityState,
    constraints: Vec<Constraint>,
    fallback: Option<FallbackPolicy>,
    evidence_id: &str,
) -> CapabilityDescriptor {
    CapabilityDescriptor {
        key: CapabilityKey(key.to_owned()),
        title: title.to_owned(),
        domain,
        support_level,
        state,
        constraints,
        fallback,
        evidence_ref: EvidenceRef {
            fixture_id: Some(evidence_id.to_owned()),
            golden_test_id: None,
            native_validation_test_id: None,
            runtime_test_id: None,
        },
        notes: Vec::new(),
    }
}

fn coverage(
    key: &str,
    target_core: &str,
    support_level: SupportLevel,
    state: CapabilityState,
) -> CoverageEntry {
    CoverageEntry {
        capability_key: CapabilityKey(key.to_owned()),
        target_core: target_core.to_owned(),
        version_range: ">=1.0".to_owned(),
        support_level,
        state,
        platforms: vec!["linux".to_owned(), "macos".to_owned(), "windows".to_owned()],
        evidence: vec![format!("coverage:{key}:{target_core}")],
    }
}

fn evidence_for_descriptor(descriptor: &CapabilityDescriptor) -> Vec<String> {
    let mut evidence = Vec::new();
    if let Some(value) = &descriptor.evidence_ref.fixture_id {
        evidence.push(format!("fixture:{value}"));
    }
    if let Some(value) = &descriptor.evidence_ref.golden_test_id {
        evidence.push(format!("golden:{value}"));
    }
    if let Some(value) = &descriptor.evidence_ref.native_validation_test_id {
        evidence.push(format!("native:{value}"));
    }
    if let Some(value) = &descriptor.evidence_ref.runtime_test_id {
        evidence.push(format!("runtime:{value}"));
    }
    evidence
}

fn some_constraint(field: &str, expected: &str) -> Vec<Constraint> {
    vec![Constraint {
        field: field.to_owned(),
        expected: expected.to_owned(),
    }]
}
