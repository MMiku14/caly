use std::collections::{BTreeMap, BTreeSet};

use crate::loader::{CoverageEntry, CoverageMatrixDocument, RegistryDocument};
use crate::registry::{
    CapabilityDescriptor, CapabilityKey, CapabilityState, FallbackPolicy, SupportLevel,
};

#[derive(Clone, Copy, Debug, Eq, PartialEq, Ord, PartialOrd, Hash)]
pub enum RequirementStrength {
    Hard,
    Soft,
    Informational,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct RequiredCapability {
    pub key: CapabilityKey,
    pub reason: String,
    pub strength: RequirementStrength,
    pub origin_path: Option<String>,
}

#[derive(Clone, Debug, Default, Eq, PartialEq)]
pub struct RequiredCapabilitySet {
    pub items: Vec<RequiredCapability>,
}

impl RequiredCapabilitySet {
    pub fn push(&mut self, required: RequiredCapability) {
        self.items.push(required);
    }

    pub fn dedup(self) -> Self {
        let mut seen = BTreeSet::new();
        let mut out = Vec::new();
        for item in self.items {
            let dedup_key = (
                item.key.0.clone(),
                item.reason.clone(),
                item.origin_path.clone(),
                item.strength,
            );
            if seen.insert(dedup_key) {
                out.push(item);
            }
        }
        Self { items: out }
    }
}

#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub enum CapabilityDecisionKind {
    Allow,
    AllowWithWarning,
    Block,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct CapabilityDecision {
    pub key: CapabilityKey,
    pub kind: CapabilityDecisionKind,
    pub state: CapabilityState,
    pub support_level: SupportLevel,
    pub fallback: Option<FallbackPolicy>,
    pub reason: String,
    pub remediation: Option<String>,
    pub evidence_summary: Vec<String>,
    pub origin_path: Option<String>,
}

#[derive(Clone, Debug, Default, Eq, PartialEq)]
pub struct CapabilityEvaluationReport {
    pub required: Vec<RequiredCapability>,
    pub decisions: Vec<CapabilityDecision>,
    pub blocked_count: usize,
    pub warning_count: usize,
    pub informational_count: usize,
    pub may_compile: bool,
    pub must_escalate_apply: bool,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct EvaluationContext<'a> {
    pub target_core: &'a str,
    pub strict_mode: bool,
    pub registry: Option<&'a RegistryDocument>,
    pub coverage: Option<&'a CoverageMatrixDocument>,
}

pub fn evaluate_required_capabilities(
    required: RequiredCapabilitySet,
    offered: &[CapabilityDescriptor],
    context: EvaluationContext<'_>,
) -> CapabilityEvaluationReport {
    let required = required.dedup();
    let offered_by_key = offered
        .iter()
        .map(|descriptor| (descriptor.key.0.clone(), descriptor))
        .collect::<BTreeMap<_, _>>();
    let registry_by_key = context
        .registry
        .map(|registry| {
            registry
                .capabilities
                .iter()
                .map(|descriptor| (descriptor.key.0.clone(), descriptor))
                .collect::<BTreeMap<_, _>>()
        })
        .unwrap_or_default();
    let coverage_by_key = context
        .coverage
        .map(|coverage| group_coverage_by_key(coverage, context.target_core))
        .unwrap_or_default();

    let mut report = CapabilityEvaluationReport {
        required: required.items.clone(),
        decisions: Vec::new(),
        blocked_count: 0,
        warning_count: 0,
        informational_count: 0,
        may_compile: true,
        must_escalate_apply: false,
    };

    for item in required.items {
        let offered_descriptor = offered_by_key.get(&item.key.0).copied();
        let registry_descriptor = registry_by_key.get(&item.key.0).copied();
        let coverage_entry = coverage_by_key.get(&item.key.0).copied();
        let state = offered_descriptor
            .map(|descriptor| descriptor.state)
            .or_else(|| coverage_entry.map(|entry| entry.state))
            .or_else(|| registry_descriptor.map(|descriptor| descriptor.state))
            .unwrap_or(CapabilityState::Unknown);
        let support_level = offered_descriptor
            .map(|descriptor| descriptor.support_level)
            .or_else(|| coverage_entry.map(|entry| entry.support_level))
            .or_else(|| registry_descriptor.map(|descriptor| descriptor.support_level))
            .unwrap_or(SupportLevel::CalyManaged);
        let fallback = offered_descriptor
            .and_then(|descriptor| descriptor.fallback)
            .or_else(|| registry_descriptor.and_then(|descriptor| descriptor.fallback));
        let evidence_summary = offered_descriptor
            .map(evidence_from_descriptor)
            .or_else(|| registry_descriptor.map(evidence_from_descriptor))
            .unwrap_or_else(|| coverage_entry.map(evidence_from_coverage).unwrap_or_default());

        let (kind, remediation) = classify_decision(
            state,
            support_level,
            fallback,
            context.strict_mode,
            item.strength,
        );
        if matches!(fallback, Some(FallbackPolicy::EscalateToRestart)) {
            report.must_escalate_apply = true;
        }
        match kind {
            CapabilityDecisionKind::Allow => report.informational_count += 1,
            CapabilityDecisionKind::AllowWithWarning => report.warning_count += 1,
            CapabilityDecisionKind::Block => {
                report.blocked_count += 1;
                report.may_compile = false;
            }
        }

        report.decisions.push(CapabilityDecision {
            key: item.key,
            kind,
            state,
            support_level,
            fallback,
            reason: item.reason,
            remediation,
            evidence_summary,
            origin_path: item.origin_path,
        });
    }

    report
}

pub fn canonical_registry_document(offered: &[CapabilityDescriptor]) -> RegistryDocument {
    RegistryDocument {
        version: 1,
        capabilities: offered.to_vec(),
    }
}

pub fn canonical_coverage_matrix(
    offered: &[CapabilityDescriptor],
    target_core: impl Into<String>,
) -> CoverageMatrixDocument {
    let target_core = target_core.into();
    CoverageMatrixDocument {
        version: 1,
        matrix: offered
            .iter()
            .map(|descriptor| CoverageEntry {
                capability_key: descriptor.key.clone(),
                target_core: target_core.clone(),
                version_range: "*".to_owned(),
                support_level: descriptor.support_level,
                state: descriptor.state,
                platforms: vec!["*".to_owned()],
                evidence: evidence_from_descriptor(descriptor),
            })
            .collect(),
    }
}

fn group_coverage_by_key<'a>(
    coverage: &'a CoverageMatrixDocument,
    target_core: &str,
) -> BTreeMap<String, &'a CoverageEntry> {
    coverage
        .matrix
        .iter()
        .filter(|entry| entry.target_core == target_core || entry.target_core == "*")
        .map(|entry| (entry.capability_key.0.clone(), entry))
        .collect()
}

fn classify_decision(
    state: CapabilityState,
    support_level: SupportLevel,
    fallback: Option<FallbackPolicy>,
    strict_mode: bool,
    strength: RequirementStrength,
) -> (CapabilityDecisionKind, Option<String>) {
    match state {
        CapabilityState::SupportedExact => (CapabilityDecisionKind::Allow, None),
        CapabilityState::SupportedNativeOnly => (
            CapabilityDecisionKind::AllowWithWarning,
            Some("keep this feature in native-only mode for the selected core".to_owned()),
        ),
        CapabilityState::PreservedOpaque => match support_level {
            SupportLevel::OpaquePreserved => (
                CapabilityDecisionKind::AllowWithWarning,
                Some("preserve opaque fields only on the same target core".to_owned()),
            ),
            _ => (
                CapabilityDecisionKind::AllowWithWarning,
                Some("preserved capability should not be edited cross-core".to_owned()),
            ),
        },
        CapabilityState::Experimental => {
            if strict_mode {
                (
                    CapabilityDecisionKind::Block,
                    Some("experimental capability is blocked in strict mode".to_owned()),
                )
            } else {
                let message = match strength {
                    RequirementStrength::Hard => {
                        "experimental capability satisfies a hard requirement only with operator caution"
                    }
                    RequirementStrength::Soft | RequirementStrength::Informational => {
                        "experimental capability requires explicit operator caution"
                    }
                };
                (
                    CapabilityDecisionKind::AllowWithWarning,
                    Some(message.to_owned()),
                )
            }
        }
        CapabilityState::Unsupported => (
            CapabilityDecisionKind::Block,
            Some("switch target core or remove the unsupported feature".to_owned()),
        ),
        CapabilityState::Unknown => {
            if strict_mode {
                (
                    CapabilityDecisionKind::Block,
                    Some("refresh capability registry coverage or disable strict mode".to_owned()),
                )
            } else {
                let message = match strength {
                    RequirementStrength::Hard => {
                        "capability is unknown for a hard requirement; proceed only with explicit caution"
                    }
                    RequirementStrength::Soft | RequirementStrength::Informational => {
                        "capability is unknown for this target; proceed only with explicit caution"
                    }
                };
                (
                    CapabilityDecisionKind::AllowWithWarning,
                    Some(message.to_owned()),
                )
            }
        }
    }
    .map_remediation(fallback)
}

fn evidence_from_descriptor(descriptor: &CapabilityDescriptor) -> Vec<String> {
    let mut evidence = Vec::new();
    if let Some(value) = &descriptor.evidence_ref.fixture_id {
        evidence.push(format!("fixture:{value}"));
    }
    if let Some(value) = &descriptor.evidence_ref.golden_test_id {
        evidence.push(format!("golden:{value}"));
    }
    if let Some(value) = &descriptor.evidence_ref.native_validation_test_id {
        evidence.push(format!("native:{value}"));
    }
    if let Some(value) = &descriptor.evidence_ref.runtime_test_id {
        evidence.push(format!("runtime:{value}"));
    }
    evidence
}

fn evidence_from_coverage(entry: &CoverageEntry) -> Vec<String> {
    entry.evidence.clone()
}

trait DecisionExt {
    fn map_remediation(self, fallback: Option<FallbackPolicy>) -> (CapabilityDecisionKind, Option<String>);
}

impl DecisionExt for (CapabilityDecisionKind, Option<String>) {
    fn map_remediation(self, fallback: Option<FallbackPolicy>) -> (CapabilityDecisionKind, Option<String>) {
        let (kind, remediation) = self;
        let fallback_text = fallback.map(|value| match value {
            FallbackPolicy::PreserveOpaqueSameCore => "fallback=PreserveOpaqueSameCore",
            FallbackPolicy::RequireDropFlag => "fallback=RequireDropFlag",
            FallbackPolicy::UseNativeOnlyMode => "fallback=UseNativeOnlyMode",
            FallbackPolicy::EscalateToRestart => "fallback=EscalateToRestart",
            FallbackPolicy::DisableRuntimeFeature => "fallback=DisableRuntimeFeature",
        });
        match (remediation, fallback_text) {
            (Some(remediation), Some(fallback_text)) => {
                (kind, Some(format!("{remediation}; {fallback_text}")))
            }
            (None, Some(fallback_text)) => (kind, Some(fallback_text.to_owned())),
            (remediation, None) => (kind, remediation),
        }
    }
}
