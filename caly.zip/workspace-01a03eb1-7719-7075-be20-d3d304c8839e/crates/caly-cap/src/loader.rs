use crate::registry::{CapabilityDescriptor, CapabilityKey, CapabilityState, SupportLevel};

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct CoverageEntry {
    pub capability_key: CapabilityKey,
    pub target_core: String,
    pub version_range: String,
    pub support_level: SupportLevel,
    pub state: CapabilityState,
    pub platforms: Vec<String>,
    pub evidence: Vec<String>,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct RegistryDocument {
    pub version: u32,
    pub capabilities: Vec<CapabilityDescriptor>,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct CoverageMatrixDocument {
    pub version: u32,
    pub matrix: Vec<CoverageEntry>,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct ValidationIssue {
    pub code: String,
    pub message: String,
}

#[derive(Clone, Debug, Default, Eq, PartialEq)]
pub struct ValidationReport {
    pub issues: Vec<ValidationIssue>,
}

impl ValidationReport {
    pub fn is_valid(&self) -> bool {
        self.issues.is_empty()
    }

    pub fn push(&mut self, code: impl Into<String>, message: impl Into<String>) {
        self.issues.push(ValidationIssue {
            code: code.into(),
            message: message.into(),
        });
    }
}

pub fn validate_registry_document(document: &RegistryDocument) -> ValidationReport {
    let mut report = ValidationReport::default();
    let mut seen = std::collections::BTreeSet::new();

    for capability in &document.capabilities {
        if !seen.insert(capability.key.0.clone()) {
            report.push(
                "DUPLICATE_CAPABILITY_KEY",
                format!("duplicate capability key: {}", capability.key.0),
            );
        }

        if capability.title.trim().is_empty() {
            report.push(
                "EMPTY_CAPABILITY_TITLE",
                format!("capability {} has an empty title", capability.key.0),
            );
        }

        if capability.state == CapabilityState::SupportedExact {
            let has_any_evidence = capability.evidence_ref.fixture_id.is_some()
                || capability.evidence_ref.golden_test_id.is_some()
                || capability.evidence_ref.native_validation_test_id.is_some()
                || capability.evidence_ref.runtime_test_id.is_some();

            if !has_any_evidence {
                report.push(
                    "MISSING_SUPPORTED_EXACT_EVIDENCE",
                    format!(
                        "capability {} is SupportedExact but has no evidence reference",
                        capability.key.0
                    ),
                );
            }
        }
    }

    report
}

pub fn validate_coverage_matrix(
    registry: &RegistryDocument,
    coverage: &CoverageMatrixDocument,
) -> ValidationReport {
    let mut report = ValidationReport::default();
    let keys: std::collections::BTreeSet<_> = registry
        .capabilities
        .iter()
        .map(|descriptor| descriptor.key.0.clone())
        .collect();

    for entry in &coverage.matrix {
        if !keys.contains(&entry.capability_key.0) {
            report.push(
                "UNKNOWN_CAPABILITY_KEY",
                format!(
                    "coverage entry references unknown capability key: {}",
                    entry.capability_key.0
                ),
            );
        }

        if entry.platforms.is_empty() {
            report.push(
                "EMPTY_PLATFORM_SET",
                format!(
                    "coverage entry for {} must declare at least one platform",
                    entry.capability_key.0
                ),
            );
        }
    }

    report
}
