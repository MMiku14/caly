#[derive(Clone, Debug, Eq, PartialEq, Ord, PartialOrd, Hash)]
pub struct CapabilityKey(pub String);

#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub enum CapabilityDomain {
    Proxies,
    ProxyGroups,
    Routing,
    RuleSets,
    Dns,
    Inbounds,
    Outbounds,
    Tun,
    SystemProxy,
    SystemDns,
    Runtime,
    Security,
}

#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub enum SupportLevel {
    CalyManaged,
    NativeManaged,
    OpaquePreserved,
}

#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub enum CapabilityState {
    SupportedExact,
    SupportedNativeOnly,
    PreservedOpaque,
    Experimental,
    Unsupported,
    Unknown,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct Constraint {
    pub field: String,
    pub expected: String,
}

#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub enum FallbackPolicy {
    PreserveOpaqueSameCore,
    RequireDropFlag,
    UseNativeOnlyMode,
    EscalateToRestart,
    DisableRuntimeFeature,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct EvidenceRef {
    pub fixture_id: Option<String>,
    pub golden_test_id: Option<String>,
    pub native_validation_test_id: Option<String>,
    pub runtime_test_id: Option<String>,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct CapabilityDescriptor {
    pub key: CapabilityKey,
    pub title: String,
    pub domain: CapabilityDomain,
    pub support_level: SupportLevel,
    pub state: CapabilityState,
    pub constraints: Vec<Constraint>,
    pub fallback: Option<FallbackPolicy>,
    pub evidence_ref: EvidenceRef,
    pub notes: Vec<String>,
}
