use std::fmt;

pub use caly_common::TraceId;

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct DiagnosticSummary {
    pub code: String,
    pub message: String,
    pub path: Option<String>,
}

#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub enum ErrorCategory {
    User,
    Config,
    Capability,
    Core,
    Io,
    Platform,
    Internal,
}

#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub enum ErrorCode {
    ConfigInvalid,
    Conflict,
    UnsupportedCapability,
    CoreNotRunning,
    CoreFailed,
    Permission,
    NetOs,
    Storage,
    Timeout,
    Unavailable,
    ProtoMismatch,
    CursorStale,
    Cancelled,
    Internal,
}

impl ErrorCode {
    pub const fn as_str(self) -> &'static str {
        match self {
            Self::ConfigInvalid => "CONFIG_INVALID",
            Self::Conflict => "CONFLICT",
            Self::UnsupportedCapability => "UNSUPPORTED_CAPABILITY",
            Self::CoreNotRunning => "CORE_NOT_RUNNING",
            Self::CoreFailed => "CORE_FAILED",
            Self::Permission => "PERMISSION",
            Self::NetOs => "NET_OS",
            Self::Storage => "STORAGE",
            Self::Timeout => "TIMEOUT",
            Self::Unavailable => "UNAVAILABLE",
            Self::ProtoMismatch => "PROTO_MISMATCH",
            Self::CursorStale => "CURSOR_STALE",
            Self::Cancelled => "CANCELLED",
            Self::Internal => "INTERNAL",
        }
    }
}

impl fmt::Display for ErrorCode {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(self.as_str())
    }
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct ApiError {
    pub code: ErrorCode,
    pub category: ErrorCategory,
    pub retryable: bool,
    pub summary: String,
    pub detail: Option<String>,
    pub remediation: Option<String>,
    pub diagnostics: Vec<DiagnosticSummary>,
    pub trace_id: TraceId,
}

impl ApiError {
    pub fn new(
        code: ErrorCode,
        category: ErrorCategory,
        retryable: bool,
        summary: impl Into<String>,
        trace_id: TraceId,
    ) -> Self {
        Self {
            code,
            category,
            retryable,
            summary: summary.into(),
            detail: None,
            remediation: None,
            diagnostics: Vec::new(),
            trace_id,
        }
    }

    pub fn with_detail(mut self, detail: impl Into<String>) -> Self {
        self.detail = Some(detail.into());
        self
    }

    pub fn with_remediation(mut self, remediation: impl Into<String>) -> Self {
        self.remediation = Some(remediation.into());
        self
    }

    pub fn with_diagnostic(mut self, diagnostic: DiagnosticSummary) -> Self {
        self.diagnostics.push(diagnostic);
        self
    }

    pub fn internal(summary: impl Into<String>, trace_id: TraceId) -> Self {
        Self::new(
            ErrorCode::Internal,
            ErrorCategory::Internal,
            false,
            summary,
            trace_id,
        )
    }
}
