use crate::operation::SourceId;

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct SourceSummary {
    pub id: SourceId,
    pub label: String,
    pub kind: String,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct SourceInspection {
    pub summary: SourceSummary,
    pub latest_digest: Option<String>,
    pub warning_count: u32,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct SourcePreviewRequest {
    pub source_id: Option<SourceId>,
    pub inline_source: Option<String>,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct SourcePreview {
    pub node_count: usize,
    pub group_count: usize,
    pub warnings: Vec<String>,
}
