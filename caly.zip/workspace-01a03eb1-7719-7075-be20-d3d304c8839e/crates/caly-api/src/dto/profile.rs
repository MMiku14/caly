use crate::operation::ProfileId;

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct ApplyRequest {
    pub profile_id: ProfileId,
    pub dry_run: bool,
    pub strict: bool,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct RollbackRequest {
    pub snapshot_id: Option<String>,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct DeploymentPlanView {
    pub plan_kind: String,
    pub warnings: Vec<String>,
    pub steps: Vec<String>,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct ProfileSummary {
    pub id: ProfileId,
    pub label: String,
    pub active: bool,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct ProfileView {
    pub summary: ProfileSummary,
    pub source_count: usize,
    pub core_target: String,
}
