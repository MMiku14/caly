use crate::dto::common::PageRequest;
use crate::operation::{JobId, ProfileId};

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct RuleQuery {
    pub page: PageRequest,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct RuleView {
    pub id: String,
    pub label: String,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct RulePage {
    pub items: Vec<RuleView>,
    pub next: Option<String>,
    pub revision: u64,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct RouteExplainRequest {
    pub target: String,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct RouteExplainResult {
    pub matched_rule: Option<String>,
    pub action: String,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct RoutingValidation {
    pub warning_count: u32,
    pub error_count: u32,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct DnsExplainRequest {
    pub domain_or_ip: String,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct DnsExplainResult {
    pub resolved_via: String,
    pub outbound: Option<String>,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct DoctorRequest {
    pub include_runtime: bool,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct DoctorReport {
    pub summary: String,
    pub warnings: Vec<String>,
    pub errors: Vec<String>,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct PipelineExplainRequest {
    pub profile_id: ProfileId,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct PipelineExplain {
    pub stages: Vec<String>,
    pub diagnostics: Vec<String>,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct CapabilityQuery {
    pub target: String,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct CapabilityReport {
    pub target: String,
    pub supported: Vec<String>,
    pub warnings: Vec<String>,
    pub blocked: Vec<String>,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct RecoveryStatusView {
    pub daemon_lifecycle: String,
    pub active_profile: Option<ProfileId>,
    pub active_core: Option<String>,
    pub active_snapshot: Option<String>,
    pub last_apply_plan_summary: Option<String>,
    pub pending_apply_count: usize,
    pub pending_os_count: usize,
    pub decision_count: usize,
    pub decisions: Vec<String>,
    pub last_recovery_summary: Option<String>,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct JobFollowRequest {
    pub job_id: JobId,
    pub from_event_index: Option<u64>,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct JobFollowView {
    pub job_id: JobId,
    pub state: String,
    pub lifecycle: String,
    pub next_event_index: u64,
    pub retained_from_event_index: u64,
    pub reset_required: bool,
    pub event_count: usize,
    pub last_stage: Option<String>,
    pub last_stage_pct: Option<u8>,
    pub warning_count: usize,
    pub log_count: usize,
    pub failure_code: Option<String>,
    pub failure_summary: Option<String>,
}
