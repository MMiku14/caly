use crate::operation::ProfileId;

#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub struct ProtocolVersion {
    pub major: u16,
    pub minor: u16,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct SystemStatus {
    pub daemon_state: String,
    pub active_profile: Option<ProfileId>,
    pub active_core: Option<String>,
    pub state_revision: u64,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct ServerInfo {
    pub daemon_name: String,
    pub daemon_version: String,
    pub protocol_version: ProtocolVersion,
    pub instance_id: String,
}
