#[derive(Clone, Debug, Eq, PartialEq)]
pub struct PatchAutomationJob {
    pub job_id: String,
    pub enabled: bool,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct AutomationJobView {
    pub id: String,
    pub label: String,
    pub enabled: bool,
}
