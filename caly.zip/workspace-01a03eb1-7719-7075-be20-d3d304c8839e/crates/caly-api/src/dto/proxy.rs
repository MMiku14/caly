use crate::dto::common::PageRequest;
use crate::operation::{GroupId, NodeId};

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct NodeQuery {
    pub group: Option<GroupId>,
    pub search: Option<String>,
    pub page: PageRequest,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct NodeView {
    pub id: NodeId,
    pub label: String,
    pub protocol: String,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct NodePage {
    pub items: Vec<NodeView>,
    pub next: Option<String>,
    pub revision: u64,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct GroupView {
    pub id: GroupId,
    pub label: String,
    pub selected: Option<NodeId>,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct SelectNode {
    pub group_id: GroupId,
    pub node_id: NodeId,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct DelayTestRequest {
    pub node_ids: Vec<NodeId>,
}
