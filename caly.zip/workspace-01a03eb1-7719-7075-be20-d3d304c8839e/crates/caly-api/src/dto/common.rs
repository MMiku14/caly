use crate::operation::{JobId, StreamId};

#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub enum EstimatedImpact {
    Noop,
    ReadOnly,
    Reload,
    Restart,
    RebuildAndRestart,
    PrivilegedNetworkChange,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct Accepted {
    pub job_id: JobId,
    pub state_revision: u64,
    pub estimated_impact: EstimatedImpact,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct WatchOpened {
    pub stream_id: StreamId,
    pub subscription_kind: String,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct PageRequest {
    pub cursor: Option<String>,
    pub limit: u32,
}

pub use crate::operation::{ConnectionId, CoreInstallId, GroupId, ProfileId, RequestId, SourceId};
