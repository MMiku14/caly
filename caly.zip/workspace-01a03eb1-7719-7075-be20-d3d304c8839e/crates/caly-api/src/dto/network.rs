use crate::operation::CoreInstallId;

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct DnsStatus {
    pub fake_ip_enabled: bool,
    pub cache_entries: u64,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct NetworkStatus {
    pub tun_enabled: bool,
    pub system_proxy_enabled: bool,
    pub system_dns_overridden: bool,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct NetworkPlanView {
    pub summary: String,
    pub requires_privilege: bool,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct CoreInstallView {
    pub id: CoreInstallId,
    pub kind: String,
    pub version: String,
    pub active: bool,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct CoreInspection {
    pub install: CoreInstallView,
    pub binary_digest: String,
}
