use caly_common::{Actor, IoBudget, RequestContext};

use crate::error::{ApiError, TraceId};
use crate::ids::{Ctx, RequestId};
use crate::meta::Role;
use crate::operation::{Operation, ProtocolVersion};
use crate::result::OperationResult;

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct RequestEnvelope {
    pub protocol: ProtocolVersion,
    pub request_id: RequestId,
    pub trace_id: TraceId,
    pub deadline_ms: Option<u64>,
    pub expected_revision: Option<u64>,
    pub idempotency_key: Option<String>,
    pub role: Role,
    pub operation: Operation,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct ResponseEnvelope {
    pub request_id: RequestId,
    pub trace_id: TraceId,
    pub result: Result<OperationResult, ApiError>,
}

pub fn default_ctx(trace_id: impl Into<String>, actor: Actor) -> Ctx {
    RequestContext {
        trace_id: TraceId::new(trace_id),
        actor,
        deadline_ms: None,
        expected_revision: None,
        io_budget: IoBudget::unlimited(),
    }
}
