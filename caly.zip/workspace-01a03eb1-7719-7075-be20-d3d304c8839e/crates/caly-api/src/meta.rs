#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub enum Role {
    Viewer,
    Operator,
    Admin,
    PrivilegedBroker,
}

#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub enum OperationMode {
    Query,
    Command,
    Stream,
}

#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub enum Idempotency {
    NotApplicable,
    Optional,
    Required,
}

#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub enum CostClass {
    Tiny,
    Small,
    Medium,
    Large,
    Privileged,
}

#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub struct OperationMeta {
    pub mode: OperationMode,
    pub idempotency: Idempotency,
    pub required_role: Role,
    pub mutates_revision: bool,
    pub supports_dry_run: bool,
    pub max_cost: CostClass,
}

impl OperationMeta {
    pub const fn query(required_role: Role, max_cost: CostClass) -> Self {
        Self {
            mode: OperationMode::Query,
            idempotency: Idempotency::NotApplicable,
            required_role,
            mutates_revision: false,
            supports_dry_run: false,
            max_cost,
        }
    }

    pub const fn command(
        idempotency: Idempotency,
        required_role: Role,
        mutates_revision: bool,
        supports_dry_run: bool,
        max_cost: CostClass,
    ) -> Self {
        Self {
            mode: OperationMode::Command,
            idempotency,
            required_role,
            mutates_revision,
            supports_dry_run,
            max_cost,
        }
    }

    pub const fn stream(required_role: Role, max_cost: CostClass) -> Self {
        Self {
            mode: OperationMode::Stream,
            idempotency: Idempotency::NotApplicable,
            required_role,
            mutates_revision: false,
            supports_dry_run: false,
            max_cost,
        }
    }
}
