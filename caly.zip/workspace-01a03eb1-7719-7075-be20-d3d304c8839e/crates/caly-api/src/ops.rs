use crate::dto::{
    ApplyRequest, CapabilityQuery, ConnectionQuery, CoreInstallId, DelayTestRequest,
    DnsExplainRequest, DoctorRequest, JobFollowRequest, PatchAutomationJob, PipelineExplainRequest,
    ProfileId, RollbackRequest, RouteExplainRequest, RuntimeSubscription, SelectNode,
    SourcePreviewRequest, SourceId,
};
use crate::ids::ConnectionId;
use crate::meta::{CostClass, Idempotency, OperationMeta, Role};

#[derive(Clone, Debug, Eq, PartialEq)]
pub enum SystemOp {
    Status,
    Info,
    Shutdown,
}

impl SystemOp {
    pub fn meta(&self) -> OperationMeta {
        match self {
            Self::Status | Self::Info => OperationMeta::query(Role::Viewer, CostClass::Tiny),
            Self::Shutdown => OperationMeta::command(
                Idempotency::Required,
                Role::Admin,
                false,
                false,
                CostClass::Privileged,
            ),
        }
    }
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub enum ProfileOp {
    List,
    Get { profile_id: ProfileId },
    Plan { request: ApplyRequest },
    Apply { request: ApplyRequest },
    Rollback { request: RollbackRequest },
}

impl ProfileOp {
    pub fn meta(&self) -> OperationMeta {
        match self {
            Self::List | Self::Get { .. } => OperationMeta::query(Role::Viewer, CostClass::Small),
            Self::Plan { .. } => OperationMeta::query(Role::Operator, CostClass::Medium),
            Self::Apply { .. } | Self::Rollback { .. } => OperationMeta::command(
                Idempotency::Required,
                Role::Operator,
                true,
                true,
                CostClass::Large,
            ),
        }
    }
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub enum SourceOp {
    List,
    Inspect { source_id: SourceId },
    Update { source_id: SourceId },
    Preview { request: SourcePreviewRequest },
}

impl SourceOp {
    pub fn meta(&self) -> OperationMeta {
        match self {
            Self::List | Self::Inspect { .. } | Self::Preview { .. } => {
                OperationMeta::query(Role::Viewer, CostClass::Small)
            }
            Self::Update { .. } => OperationMeta::command(
                Idempotency::Optional,
                Role::Operator,
                true,
                false,
                CostClass::Medium,
            ),
        }
    }
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub enum ProxyOp {
    Nodes { query: crate::dto::NodeQuery },
    Groups,
    Select { request: SelectNode },
    TestDelay { request: DelayTestRequest },
}

impl ProxyOp {
    pub fn meta(&self) -> OperationMeta {
        match self {
            Self::Nodes { .. } | Self::Groups => OperationMeta::query(Role::Viewer, CostClass::Small),
            Self::Select { .. } => OperationMeta::command(
                Idempotency::Optional,
                Role::Operator,
                true,
                false,
                CostClass::Small,
            ),
            Self::TestDelay { .. } => OperationMeta::command(
                Idempotency::Optional,
                Role::Operator,
                false,
                false,
                CostClass::Medium,
            ),
        }
    }
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub enum RoutingOp {
    Rules { query: crate::dto::RuleQuery },
    Explain { request: RouteExplainRequest },
    Validate { profile_id: ProfileId },
}

impl RoutingOp {
    pub fn meta(&self) -> OperationMeta {
        OperationMeta::query(Role::Viewer, CostClass::Medium)
    }
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub enum DnsOp {
    Status,
    Explain { request: DnsExplainRequest },
    FlushCache,
}

impl DnsOp {
    pub fn meta(&self) -> OperationMeta {
        match self {
            Self::Status | Self::Explain { .. } => OperationMeta::query(Role::Viewer, CostClass::Small),
            Self::FlushCache => OperationMeta::command(
                Idempotency::Optional,
                Role::Operator,
                false,
                false,
                CostClass::Small,
            ),
        }
    }
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub enum NetworkOp {
    Status,
    InspectPlan { profile_id: ProfileId },
    Repair,
}

impl NetworkOp {
    pub fn meta(&self) -> OperationMeta {
        match self {
            Self::Status | Self::InspectPlan { .. } => {
                OperationMeta::query(Role::Viewer, CostClass::Medium)
            }
            Self::Repair => OperationMeta::command(
                Idempotency::Required,
                Role::Admin,
                false,
                false,
                CostClass::Privileged,
            ),
        }
    }
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub enum CoreOp {
    ListInstalls,
    Inspect { core_install_id: CoreInstallId },
    Capabilities { query: CapabilityQuery },
}

impl CoreOp {
    pub fn meta(&self) -> OperationMeta {
        OperationMeta::query(Role::Viewer, CostClass::Small)
    }
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub enum RuntimeOp {
    Status,
    Connections { query: ConnectionQuery },
    CloseConnection { connection_id: ConnectionId },
    Watch { subscription: RuntimeSubscription },
}

impl RuntimeOp {
    pub fn meta(&self) -> OperationMeta {
        match self {
            Self::Status | Self::Connections { .. } => {
                OperationMeta::query(Role::Viewer, CostClass::Small)
            }
            Self::CloseConnection { .. } => OperationMeta::command(
                Idempotency::Optional,
                Role::Operator,
                false,
                false,
                CostClass::Small,
            ),
            Self::Watch { .. } => OperationMeta::stream(Role::Viewer, CostClass::Medium),
        }
    }
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub enum DiagnosticsOp {
    Doctor { request: DoctorRequest },
    ExplainPipeline { request: PipelineExplainRequest },
    RecoveryStatus,
    FollowJob { request: JobFollowRequest },
    FollowJobStream { request: JobFollowRequest },
    SupportBundle,
}

impl DiagnosticsOp {
    pub fn meta(&self) -> OperationMeta {
        match self {
            Self::Doctor { .. }
            | Self::ExplainPipeline { .. }
            | Self::RecoveryStatus
            | Self::FollowJob { .. } => OperationMeta::query(Role::Viewer, CostClass::Medium),
            Self::FollowJobStream { .. } => OperationMeta::stream(Role::Viewer, CostClass::Medium),
            Self::SupportBundle => OperationMeta::command(
                Idempotency::Optional,
                Role::Operator,
                false,
                false,
                CostClass::Large,
            ),
        }
    }
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub enum AutomationOp {
    ListJobs,
    PatchJob { request: PatchAutomationJob },
}

impl AutomationOp {
    pub fn meta(&self) -> OperationMeta {
        match self {
            Self::ListJobs => OperationMeta::query(Role::Viewer, CostClass::Small),
            Self::PatchJob { .. } => OperationMeta::command(
                Idempotency::Optional,
                Role::Operator,
                true,
                false,
                CostClass::Medium,
            ),
        }
    }
}
