#![forbid(unsafe_code)]

#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub struct DependencyEdge {
    pub from: &'static str,
    pub to: &'static str,
}

#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub enum ViolationKind {
    ForbiddenDependency,
    MissingAllowedEdge,
    ForbiddenType,
    ForbiddenMethod,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct Violation {
    pub kind: ViolationKind,
    pub crate_name: String,
    pub detail: String,
}

#[derive(Clone, Debug, Default, Eq, PartialEq)]
pub struct ArchReport {
    pub violations: Vec<Violation>,
}

impl ArchReport {
    pub fn is_clean(&self) -> bool {
        self.violations.is_empty()
    }
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct CrateMeta {
    pub name: String,
    pub dependencies: Vec<String>,
}

#[derive(Clone, Debug, Default, Eq, PartialEq)]
pub struct WorkspaceMeta {
    pub crates: Vec<CrateMeta>,
}

pub const PURE_CORE_CRATES: &[&str] = &[
    "caly-domain",
    "caly-ir",
    "caly-pipeline",
    "caly-cap",
    "caly-plan",
];

pub const IO_FORBIDDEN_TYPES: &[&str] = &[
    "std::fs::File",
    "std::path::PathBuf",
    "std::process::Command",
];

pub const IO_FORBIDDEN_METHODS: &[&str] = &[
    "std::time::SystemTime::now",
    "std::time::Instant::now",
    "std::process::Command::new",
];

pub const WORKSPACE_TARGET_CRATES: &[&str] = &[
    "caly-api",
    "caly-app",
    "caly-arch-test",
    "caly-cap",
    "caly-cli",
    "caly-common",
    "caly-core",
    "caly-daemon",
    "caly-domain",
    "caly-engine",
    "caly-io",
    "caly-io-sim",
    "caly-ipc",
    "caly-ir",
    "caly-mihomo",
    "caly-pipeline",
    "caly-plan",
    "caly-singbox",
    "caly-storage",
];

pub const ALLOWED_DEPENDENCY_EDGES: &[DependencyEdge] = &[
    DependencyEdge { from: "caly-api", to: "caly-common" },
    DependencyEdge { from: "caly-app", to: "caly-api" },
    DependencyEdge { from: "caly-app", to: "caly-common" },
    DependencyEdge { from: "caly-app", to: "caly-daemon" },
    DependencyEdge { from: "caly-app", to: "caly-ipc" },
    DependencyEdge { from: "caly-cli", to: "caly-api" },
    DependencyEdge { from: "caly-cli", to: "caly-app" },
    DependencyEdge { from: "caly-cli", to: "caly-ipc" },
    DependencyEdge { from: "caly-core", to: "caly-cap" },
    DependencyEdge { from: "caly-core", to: "caly-ir" },
    DependencyEdge { from: "caly-core", to: "caly-plan" },
    DependencyEdge { from: "caly-daemon", to: "caly-api" },
    DependencyEdge { from: "caly-daemon", to: "caly-common" },
    DependencyEdge { from: "caly-daemon", to: "caly-engine" },
    DependencyEdge { from: "caly-daemon", to: "caly-ipc" },
    DependencyEdge { from: "caly-domain", to: "caly-ir" },
    DependencyEdge { from: "caly-engine", to: "caly-api" },
    DependencyEdge { from: "caly-engine", to: "caly-common" },
    DependencyEdge { from: "caly-engine", to: "caly-core" },
    DependencyEdge { from: "caly-engine", to: "caly-domain" },
    DependencyEdge { from: "caly-engine", to: "caly-ir" },
    DependencyEdge { from: "caly-engine", to: "caly-pipeline" },
    DependencyEdge { from: "caly-engine", to: "caly-plan" },
    DependencyEdge { from: "caly-engine", to: "caly-storage" },
    DependencyEdge { from: "caly-io", to: "caly-common" },
    DependencyEdge { from: "caly-io-sim", to: "caly-io" },
    DependencyEdge { from: "caly-ipc", to: "caly-api" },
    DependencyEdge { from: "caly-mihomo", to: "caly-cap" },
    DependencyEdge { from: "caly-mihomo", to: "caly-core" },
    DependencyEdge { from: "caly-mihomo", to: "caly-ir" },
    DependencyEdge { from: "caly-mihomo", to: "caly-plan" },
    DependencyEdge { from: "caly-pipeline", to: "caly-cap" },
    DependencyEdge { from: "caly-pipeline", to: "caly-core" },
    DependencyEdge { from: "caly-pipeline", to: "caly-domain" },
    DependencyEdge { from: "caly-pipeline", to: "caly-ir" },
    DependencyEdge { from: "caly-pipeline", to: "caly-plan" },
    DependencyEdge { from: "caly-singbox", to: "caly-cap" },
    DependencyEdge { from: "caly-singbox", to: "caly-core" },
    DependencyEdge { from: "caly-singbox", to: "caly-ir" },
    DependencyEdge { from: "caly-singbox", to: "caly-plan" },
    DependencyEdge { from: "caly-storage", to: "caly-plan" },
];

pub fn is_pure_core(crate_name: &str) -> bool {
    PURE_CORE_CRATES.contains(&crate_name)
}

pub fn check_dependency_edges(meta: &WorkspaceMeta) -> ArchReport {
    let mut report = ArchReport::default();

    for krate in &meta.crates {
        if !WORKSPACE_TARGET_CRATES.iter().any(|name| *name == krate.name) {
            continue;
        }

        for dependency in &krate.dependencies {
            let allowed = ALLOWED_DEPENDENCY_EDGES
                .iter()
                .any(|edge| edge.from == krate.name && edge.to == dependency);

            if !allowed {
                report.violations.push(Violation {
                    kind: ViolationKind::ForbiddenDependency,
                    crate_name: krate.name.clone(),
                    detail: format!("{} -> {} is not in the allow-list", krate.name, dependency),
                });
            }
        }
    }

    report
}

pub fn check_forbidden_symbol_usage(
    crate_name: &str,
    referenced_types: &[&str],
    referenced_methods: &[&str],
) -> ArchReport {
    let mut report = ArchReport::default();

    if !is_pure_core(crate_name) {
        return report;
    }

    for ty in referenced_types {
        if IO_FORBIDDEN_TYPES.contains(ty) {
            report.violations.push(Violation {
                kind: ViolationKind::ForbiddenType,
                crate_name: crate_name.to_owned(),
                detail: (*ty).to_owned(),
            });
        }
    }

    for method in referenced_methods {
        if IO_FORBIDDEN_METHODS.contains(method) {
            report.violations.push(Violation {
                kind: ViolationKind::ForbiddenMethod,
                crate_name: crate_name.to_owned(),
                detail: (*method).to_owned(),
            });
        }
    }

    report
}
