use std::collections::{BTreeMap, BTreeSet};

use caly_domain::{MergeEvent, MergeEventKind, MergeReport, OverrideRule, Profile};
use caly_ir::{
    CalyIr, CoreTarget, DnsMode, DnsPolicy, ExtensionKey, GroupId, GroupType, Inbound, NodeId,
    NormalizedSource, Outbound, OutboundId, ProxyGroup, ProxyNode, ProxyProtocol, RouteRule,
    RoutingMode, RuleAction, RuleId, RuleSetId, RuleSetRef, SourceKind, TunPolicy,
};

use crate::stage::{Diagnostic, DiagnosticSeverity, StageContext};

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct MergeInput {
    pub profile: Profile,
    pub normalized_sources: Vec<NormalizedSource>,
    pub overrides: Vec<OverrideRule>,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct MergeOutput {
    pub ir: CalyIr,
    pub report: MergeReport,
    pub diagnostics: Vec<Diagnostic>,
}

pub fn merge_profile(input: MergeInput, _cx: &StageContext) -> MergeOutput {
    let mut report = MergeReport::default();
    let mut diagnostics = Vec::new();

    let mut core_target = ensure_target(&input.profile);
    let mut routing_mode = ensure_routing_mode(&input.profile);
    let mut tun = input.profile.tun.clone().unwrap_or(TunPolicy {
        enabled: false,
        auto_route: false,
        strict_route: false,
    });
    let mut dns_mode_override = None;

    for override_rule in &input.overrides {
        match parse_override_selector(&override_rule.selector) {
            Some(ParsedOverride::RoutingMode) if override_rule.is_set_operation() => {
                if let Some(value) = override_rule.value.as_deref().and_then(parse_routing_mode) {
                    routing_mode = value;
                    report.push(MergeEvent {
                        kind: MergeEventKind::Override,
                        source_id: None,
                        profile_id: Some(input.profile.id.clone()),
                        rule_id: None,
                        node_id: None,
                        group_id: None,
                        message: format!(
                            "override {} set routing mode to {}",
                            override_rule.label,
                            routing_mode_name(value)
                        ),
                    });
                } else {
                    diagnostics.push(invalid_override_diagnostic(
                        override_rule,
                        "routing.mode expects rule/global/direct",
                    ));
                }
            }
            Some(ParsedOverride::CoreTarget) if override_rule.is_set_operation() => {
                if let Some(value) = override_rule.value.as_deref().and_then(parse_core_target) {
                    core_target = value;
                    report.push(MergeEvent {
                        kind: MergeEventKind::Override,
                        source_id: None,
                        profile_id: Some(input.profile.id.clone()),
                        rule_id: None,
                        node_id: None,
                        group_id: None,
                        message: format!(
                            "override {} set core target to {}",
                            override_rule.label,
                            core_target_name(value)
                        ),
                    });
                } else {
                    diagnostics.push(invalid_override_diagnostic(
                        override_rule,
                        "profile.core_target expects mihomo/sing-box/auto",
                    ));
                }
            }
            Some(ParsedOverride::DnsMode) if override_rule.is_set_operation() => {
                if let Some(value) = override_rule.value.as_deref().and_then(parse_dns_mode) {
                    dns_mode_override = Some(value);
                    report.push(MergeEvent {
                        kind: MergeEventKind::Override,
                        source_id: None,
                        profile_id: Some(input.profile.id.clone()),
                        rule_id: None,
                        node_id: None,
                        group_id: None,
                        message: format!(
                            "override {} set dns mode to {}",
                            override_rule.label,
                            dns_mode_name(value)
                        ),
                    });
                } else {
                    diagnostics.push(invalid_override_diagnostic(
                        override_rule,
                        "dns.mode expects system/fake-ip/redirect/mixed",
                    ));
                }
            }
            Some(ParsedOverride::TunEnabled) if override_rule.is_set_operation() => {
                if let Some(value) = override_rule.value.as_deref().and_then(parse_bool) {
                    tun.enabled = value;
                } else {
                    diagnostics.push(invalid_override_diagnostic(
                        override_rule,
                        "tun.enabled expects true/false",
                    ));
                }
            }
            Some(ParsedOverride::TunAutoRoute) if override_rule.is_set_operation() => {
                if let Some(value) = override_rule.value.as_deref().and_then(parse_bool) {
                    tun.auto_route = value;
                } else {
                    diagnostics.push(invalid_override_diagnostic(
                        override_rule,
                        "tun.auto_route expects true/false",
                    ));
                }
            }
            Some(ParsedOverride::TunStrictRoute) if override_rule.is_set_operation() => {
                if let Some(value) = override_rule.value.as_deref().and_then(parse_bool) {
                    tun.strict_route = value;
                } else {
                    diagnostics.push(invalid_override_diagnostic(
                        override_rule,
                        "tun.strict_route expects true/false",
                    ));
                }
            }
            Some(_) => report.push(MergeEvent {
                kind: MergeEventKind::Override,
                source_id: None,
                profile_id: Some(input.profile.id.clone()),
                rule_id: None,
                node_id: None,
                group_id: None,
                message: format!(
                    "override {} deferred until graph materialization: selector={} operation={}",
                    override_rule.label, override_rule.selector, override_rule.operation
                ),
            }),
            None => diagnostics.push(invalid_override_diagnostic(
                override_rule,
                "unknown override selector for current centerline merge",
            )),
        }
    }

    let ordered_sources = ordered_sources(&input.profile, &input.normalized_sources);
    emit_source_consistency_diagnostics(
        &input.profile,
        &ordered_sources,
        &input.normalized_sources,
        &mut diagnostics,
    );

    let mut nodes = Vec::new();
    let mut groups = Vec::new();
    let mut rules = Vec::new();
    let mut rulesets = Vec::new();
    let mut outbounds = Vec::new();
    let mut seen_labels = BTreeSet::new();

    for (source_index, source) in ordered_sources.iter().enumerate() {
        let node_count = bounded_estimate(source.node_count_estimate, 1, 3);
        let group_count = bounded_estimate(source.group_count_estimate, 1, 2);
        let rule_count = bounded_estimate(source.rule_count_estimate, 1, 2);
        let source_label = input
            .profile
            .source_ref(&source.id)
            .map(|value| value.label.clone())
            .unwrap_or_else(|| source.id.0.clone());

        let mut member_ids = Vec::new();
        for node_index in 0..node_count {
            let node_id = NodeId::new(format!("{}-node-{:02}", source.id.0, node_index + 1));
            let protocol = protocol_for_slot(core_target, source.source_kind, source_index, node_index);
            let label = format!(
                "{} {} {:02}",
                source_label,
                protocol_display_name(protocol),
                node_index + 1
            );
            if !seen_labels.insert(label.clone()) {
                diagnostics.push(Diagnostic {
                    code: "DUPLICATE_NODE_LABEL".to_owned(),
                    severity: DiagnosticSeverity::Warning,
                    summary: format!("node label {} was duplicated during merge", label),
                    detail: Some(format!("source={} node_id={}", source.id.0, node_id.0)),
                    related_path: None,
                    remediation: Some("rename nodes or upstream source labels to keep labels stable".to_owned()),
                });
            }
            member_ids.push(node_id.clone());
            nodes.push(ProxyNode {
                id: node_id,
                label,
                protocol,
                server: format!("{}.{}.example.net", source.id.0, node_index + 1),
                port: 10000 + (source_index as u16 * 10) + node_index as u16,
                extensions: BTreeMap::new(),
                passthrough: BTreeMap::new(),
            });
        }

        let primary_group_id = GroupId::new(format!("{}-group-main", source.id.0));
        groups.push(ProxyGroup {
            id: primary_group_id.clone(),
            label: format!("{} Main", source_label),
            kind: GroupType::Select,
            members: member_ids.clone(),
            selected: member_ids.first().cloned(),
        });
        outbounds.push(Outbound {
            id: OutboundId::new(format!("{}-outbound-main", source.id.0)),
            label: format!("{} Main", source_label),
            proxy_group: Some(primary_group_id.clone()),
        });

        if group_count > 1 {
            let standby_group_id = GroupId::new(format!("{}-group-standby", source.id.0));
            groups.push(ProxyGroup {
                id: standby_group_id.clone(),
                label: format!("{} Standby", source_label),
                kind: GroupType::Fallback,
                members: member_ids.clone(),
                selected: member_ids.get(1).cloned().or_else(|| member_ids.first().cloned()),
            });
            outbounds.push(Outbound {
                id: OutboundId::new(format!("{}-outbound-standby", source.id.0)),
                label: format!("{} Standby", source_label),
                proxy_group: Some(standby_group_id),
            });
        }

        rulesets.push(RuleSetRef {
            id: RuleSetId::new(format!("{}-ruleset", source.id.0)),
            label: format!("{} RuleSet", source_label),
            digest: source.raw_digest.clone(),
            source: Some(source.id.clone()),
        });

        for rule_index in 0..rule_count {
            rules.push(RouteRule {
                id: RuleId::new(format!("{}-rule-{:02}", source.id.0, rule_index + 1)),
                label: format!("{} Rule {:02}", source_label, rule_index + 1),
                matcher: if rule_index == 0 {
                    format!("DOMAIN-SUFFIX,{}.example", source.id.0)
                } else {
                    "MATCH".to_owned()
                },
                action: RuleAction::UseGroup,
                target_group: Some(primary_group_id.clone()),
                target_outbound: None,
            });
        }

        report.push(MergeEvent {
            kind: MergeEventKind::Rename,
            source_id: Some(source.id.clone()),
            profile_id: Some(input.profile.id.clone()),
            rule_id: None,
            node_id: None,
            group_id: Some(primary_group_id),
            message: format!(
                "materialized source {} into {} nodes / {} groups / {} rules",
                source.id.0, node_count, group_count, rule_count
            ),
        });
    }

    let mut ir = CalyIr {
        profile_id: input.profile.id.clone(),
        source_ids: ordered_sources.iter().map(|source| source.id.clone()).collect(),
        core_target,
        routing_mode,
        nodes,
        groups,
        rules,
        rulesets,
        dns: Some(default_dns_policy(dns_mode_override, core_target, tun.enabled, ordered_sources.len())),
        tun: Some(tun),
        inbounds: default_inbounds(),
        outbounds,
        extensions: build_extensions(&ordered_sources),
        passthrough: build_passthrough(&input.profile, ordered_sources.len()),
    };

    apply_profile_group_selections(&input.profile, &mut ir, &mut report, &mut diagnostics);
    apply_graph_overrides(&input.overrides, &mut ir, &mut report, &mut diagnostics);

    if ir.source_ids.is_empty() {
        diagnostics.push(Diagnostic {
            code: "PIPELINE_EMPTY_PROFILE_SOURCES".to_owned(),
            severity: DiagnosticSeverity::Warning,
            summary: "profile has no source refs; merged graph is synthetic-only".to_owned(),
            detail: None,
            related_path: None,
            remediation: Some("attach at least one source before native compile".to_owned()),
        });
    }

    MergeOutput { ir, report, diagnostics }
}

pub fn empty_group(group_id: GroupId, label: impl Into<String>) -> ProxyGroup {
    ProxyGroup {
        id: group_id,
        label: label.into(),
        kind: GroupType::Select,
        members: Vec::new(),
        selected: None,
    }
}

pub fn ensure_target(profile: &Profile) -> CoreTarget {
    match profile.core_target {
        CoreTarget::Auto => CoreTarget::Auto,
        CoreTarget::Mihomo => CoreTarget::Mihomo,
        CoreTarget::SingBox => CoreTarget::SingBox,
    }
}

pub fn ensure_routing_mode(profile: &Profile) -> RoutingMode {
    match profile.routing_mode {
        RoutingMode::Rule => RoutingMode::Rule,
        RoutingMode::Global => RoutingMode::Global,
        RoutingMode::Direct => RoutingMode::Direct,
    }
}

#[derive(Clone, Debug, Eq, PartialEq)]
enum ParsedOverride {
    RoutingMode,
    CoreTarget,
    DnsMode,
    TunEnabled,
    TunAutoRoute,
    TunStrictRoute,
    GroupSelect(GroupId),
    GroupLabel(GroupId),
    NodeLabel(NodeId),
}

fn parse_override_selector(selector: &str) -> Option<ParsedOverride> {
    match selector {
        "routing.mode" => Some(ParsedOverride::RoutingMode),
        "profile.core_target" => Some(ParsedOverride::CoreTarget),
        "dns.mode" => Some(ParsedOverride::DnsMode),
        "tun.enabled" => Some(ParsedOverride::TunEnabled),
        "tun.auto_route" => Some(ParsedOverride::TunAutoRoute),
        "tun.strict_route" => Some(ParsedOverride::TunStrictRoute),
        _ => parse_scoped_selector(selector),
    }
}

fn parse_scoped_selector(selector: &str) -> Option<ParsedOverride> {
    if let Some(rest) = selector.strip_prefix("group:") {
        let mut parts = rest.split(':');
        let id = parts.next()?;
        let field = parts.next()?;
        return match field {
            "select" => Some(ParsedOverride::GroupSelect(GroupId::new(id))),
            "label" => Some(ParsedOverride::GroupLabel(GroupId::new(id))),
            _ => None,
        };
    }

    if let Some(rest) = selector.strip_prefix("node:") {
        let mut parts = rest.split(':');
        let id = parts.next()?;
        let field = parts.next()?;
        return match field {
            "label" => Some(ParsedOverride::NodeLabel(NodeId::new(id))),
            _ => None,
        };
    }

    let dotted = selector.split('.').collect::<Vec<_>>();
    if dotted.len() == 3 && dotted[0] == "group" {
        return match dotted[2] {
            "select" => Some(ParsedOverride::GroupSelect(GroupId::new(dotted[1]))),
            "label" => Some(ParsedOverride::GroupLabel(GroupId::new(dotted[1]))),
            _ => None,
        };
    }
    if dotted.len() == 3 && dotted[0] == "node" && dotted[2] == "label" {
        return Some(ParsedOverride::NodeLabel(NodeId::new(dotted[1])));
    }

    None
}

fn ordered_sources(profile: &Profile, normalized_sources: &[NormalizedSource]) -> Vec<NormalizedSource> {
    if normalized_sources.is_empty() {
        return profile
            .source_refs
            .iter()
            .map(|source| NormalizedSource {
                id: source.id.clone(),
                raw_digest: caly_ir::Digest(format!("raw:{}", source.id.0)),
                source_kind: SourceKind::Subscription,
                node_count_estimate: 1,
                group_count_estimate: 1,
                rule_count_estimate: 1,
            })
            .collect();
    }

    let mut by_id = BTreeMap::new();
    for source in normalized_sources {
        by_id.insert(source.id.clone(), source.clone());
    }

    let mut ordered = Vec::new();
    for source_ref in &profile.source_refs {
        if let Some(source) = by_id.remove(&source_ref.id) {
            ordered.push(source);
        }
    }
    ordered.extend(by_id.into_values());
    ordered
}

fn emit_source_consistency_diagnostics(
    profile: &Profile,
    ordered_sources: &[NormalizedSource],
    normalized_sources: &[NormalizedSource],
    diagnostics: &mut Vec<Diagnostic>,
) {
    let ordered_ids = ordered_sources.iter().map(|source| source.id.clone()).collect::<BTreeSet<_>>();
    let normalized_ids = normalized_sources
        .iter()
        .map(|source| source.id.clone())
        .collect::<BTreeSet<_>>();

    for source_ref in &profile.source_refs {
        if !ordered_ids.contains(&source_ref.id) {
            diagnostics.push(Diagnostic {
                code: "PROFILE_SOURCE_NOT_NORMALIZED".to_owned(),
                severity: DiagnosticSeverity::Warning,
                summary: format!("profile source {} has no normalized input", source_ref.id.0),
                detail: Some(format!("label={}", source_ref.label)),
                related_path: None,
                remediation: Some("refresh source before running native compile".to_owned()),
            });
        }
    }

    for source in normalized_sources {
        if !profile.has_source(&source.id) {
            diagnostics.push(Diagnostic {
                code: "NORMALIZED_SOURCE_NOT_ATTACHED".to_owned(),
                severity: DiagnosticSeverity::Info,
                summary: format!("normalized source {} was not explicitly attached to profile", source.id.0),
                detail: None,
                related_path: None,
                remediation: Some("attach source ref if it should contribute to resolved profile".to_owned()),
            });
        }
    }

    if normalized_sources.len() != normalized_ids.len() {
        diagnostics.push(Diagnostic {
            code: "DUPLICATE_NORMALIZED_SOURCE_ID".to_owned(),
            severity: DiagnosticSeverity::Warning,
            summary: "duplicate normalized source ids detected during merge".to_owned(),
            detail: None,
            related_path: None,
            remediation: Some("deduplicate normalized source set before merge".to_owned()),
        });
    }
}

fn apply_profile_group_selections(
    profile: &Profile,
    ir: &mut CalyIr,
    report: &mut MergeReport,
    diagnostics: &mut Vec<Diagnostic>,
) {
    for selection in &profile.active_group_selection {
        apply_group_selection(
            &selection.group_id,
            &selection.node_label,
            "profile active selection",
            ir,
            report,
            diagnostics,
        );
    }
}

fn apply_graph_overrides(
    overrides: &[OverrideRule],
    ir: &mut CalyIr,
    report: &mut MergeReport,
    diagnostics: &mut Vec<Diagnostic>,
) {
    for override_rule in overrides {
        match parse_override_selector(&override_rule.selector) {
            Some(ParsedOverride::GroupSelect(group_id)) if override_rule.is_set_operation() => {
                if let Some(value) = &override_rule.value {
                    apply_group_selection(&group_id, value, &override_rule.label, ir, report, diagnostics);
                } else {
                    diagnostics.push(invalid_override_diagnostic(
                        override_rule,
                        "group select override requires node label or node id value",
                    ));
                }
            }
            Some(ParsedOverride::GroupLabel(group_id)) if override_rule.is_set_operation() => {
                let Some(group) = ir.groups.iter_mut().find(|group| group.id == group_id) else {
                    diagnostics.push(Diagnostic {
                        code: "GROUP_OVERRIDE_TARGET_MISSING".to_owned(),
                        severity: DiagnosticSeverity::Warning,
                        summary: format!("group {} targeted by override was not found", group_id.0),
                        detail: Some(override_rule.label.clone()),
                        related_path: None,
                        remediation: Some("refresh group ids after source normalization".to_owned()),
                    });
                    continue;
                };
                let Some(value) = &override_rule.value else {
                    diagnostics.push(invalid_override_diagnostic(
                        override_rule,
                        "group label override requires a new label value",
                    ));
                    continue;
                };
                group.label = value.clone();
                report.push(MergeEvent {
                    kind: MergeEventKind::Rename,
                    source_id: None,
                    profile_id: Some(ir.profile_id.clone()),
                    rule_id: None,
                    node_id: None,
                    group_id: Some(group_id),
                    message: format!("override {} renamed group", override_rule.label),
                });
            }
            Some(ParsedOverride::NodeLabel(node_id)) if override_rule.is_set_operation() => {
                let Some(node) = ir.nodes.iter_mut().find(|node| node.id == node_id) else {
                    diagnostics.push(Diagnostic {
                        code: "NODE_OVERRIDE_TARGET_MISSING".to_owned(),
                        severity: DiagnosticSeverity::Warning,
                        summary: format!("node {} targeted by override was not found", node_id.0),
                        detail: Some(override_rule.label.clone()),
                        related_path: None,
                        remediation: Some("refresh node ids after source normalization".to_owned()),
                    });
                    continue;
                };
                let Some(value) = &override_rule.value else {
                    diagnostics.push(invalid_override_diagnostic(
                        override_rule,
                        "node label override requires a new label value",
                    ));
                    continue;
                };
                node.label = value.clone();
                report.push(MergeEvent {
                    kind: MergeEventKind::Rename,
                    source_id: None,
                    profile_id: Some(ir.profile_id.clone()),
                    rule_id: None,
                    node_id: Some(node_id),
                    group_id: None,
                    message: format!("override {} renamed node", override_rule.label),
                });
            }
            _ => {}
        }
    }
}

fn apply_group_selection(
    group_id: &GroupId,
    desired: &str,
    reason: &str,
    ir: &mut CalyIr,
    report: &mut MergeReport,
    diagnostics: &mut Vec<Diagnostic>,
) {
    let Some(group_index) = ir.groups.iter().position(|group| &group.id == group_id) else {
        diagnostics.push(Diagnostic {
            code: "GROUP_SELECTION_TARGET_MISSING".to_owned(),
            severity: DiagnosticSeverity::Warning,
            summary: format!("group {} referenced by selection was not found", group_id.0),
            detail: Some(reason.to_owned()),
            related_path: None,
            remediation: Some("refresh group ids or replay selection after merge".to_owned()),
        });
        return;
    };

    let members = ir.groups[group_index].members.clone();
    let selected = members.iter().find(|member| member.0 == desired).cloned().or_else(|| {
        ir.nodes
            .iter()
            .find(|node| members.iter().any(|member| member == &node.id) && node.label == desired)
            .map(|node| node.id.clone())
    });

    match selected {
        Some(node_id) => {
            ir.groups[group_index].selected = Some(node_id.clone());
            report.push(MergeEvent {
                kind: MergeEventKind::Override,
                source_id: None,
                profile_id: Some(ir.profile_id.clone()),
                rule_id: None,
                node_id: Some(node_id),
                group_id: Some(group_id.clone()),
                message: format!("{} set selected node for group {}", reason, group_id.0),
            });
        }
        None => diagnostics.push(Diagnostic {
            code: "GROUP_SELECTION_NODE_MISSING".to_owned(),
            severity: DiagnosticSeverity::Warning,
            summary: format!(
                "selection {} could not be resolved inside group {}",
                desired, group_id.0
            ),
            detail: Some(reason.to_owned()),
            related_path: None,
            remediation: Some("replay selection using stable node id or label from current source set".to_owned()),
        }),
    }
}

fn invalid_override_diagnostic(rule: &OverrideRule, detail: &str) -> Diagnostic {
    Diagnostic {
        code: "PIPELINE_OVERRIDE_INVALID".to_owned(),
        severity: DiagnosticSeverity::Warning,
        summary: format!("override {} was ignored", rule.label),
        detail: Some(detail.to_owned()),
        related_path: None,
        remediation: Some("use a supported selector/value pair for current pipeline slice".to_owned()),
    }
}

fn bounded_estimate(value: usize, min: usize, max: usize) -> usize {
    value.clamp(min, max)
}

fn default_inbounds() -> Vec<Inbound> {
    vec![Inbound {
        id: caly_ir::InboundId::new("inbound-mixed"),
        label: "mixed".to_owned(),
        listen: "127.0.0.1".to_owned(),
        port: 7890,
    }]
}

fn default_dns_policy(
    override_mode: Option<DnsMode>,
    core_target: CoreTarget,
    tun_enabled: bool,
    source_count: usize,
) -> DnsPolicy {
    let mode = override_mode.unwrap_or_else(|| match (core_target, tun_enabled) {
        (_, true) => DnsMode::FakeIp,
        (CoreTarget::SingBox, false) => DnsMode::Mixed,
        _ => DnsMode::FakeIp,
    });

    let mut servers = vec!["https://1.1.1.1/dns-query".to_owned()];
    if source_count > 1 {
        servers.push("https://8.8.8.8/dns-query".to_owned());
    }

    DnsPolicy {
        mode,
        servers,
        fake_ip_filter: vec!["*.lan".to_owned(), "localhost".to_owned()],
    }
}

fn build_extensions(sources: &[NormalizedSource]) -> BTreeMap<ExtensionKey, String> {
    let mut extensions = BTreeMap::new();
    for source in sources {
        extensions.insert(
            ExtensionKey::new(format!("source.{}.kind", source.id.0)),
            source_kind_name(source.source_kind).to_owned(),
        );
    }
    extensions
}

fn build_passthrough(profile: &Profile, source_count: usize) -> BTreeMap<String, String> {
    let mut passthrough = BTreeMap::new();
    passthrough.insert("profile.label".to_owned(), profile.label.clone());
    passthrough.insert("source.count".to_owned(), source_count.to_string());
    passthrough
}

fn protocol_for_slot(
    core_target: CoreTarget,
    source_kind: SourceKind,
    source_index: usize,
    node_index: usize,
) -> ProxyProtocol {
    match (core_target, source_kind, (source_index + node_index) % 4) {
        (CoreTarget::SingBox, _, 0) => ProxyProtocol::WireGuard,
        (_, SourceKind::LocalFile, 0) => ProxyProtocol::Trojan,
        (_, _, 0) => ProxyProtocol::Shadowsocks,
        (_, _, 1) => ProxyProtocol::Vmess,
        (_, _, 2) => ProxyProtocol::Vless,
        _ => ProxyProtocol::Trojan,
    }
}

fn source_kind_name(kind: SourceKind) -> &'static str {
    match kind {
        SourceKind::Subscription => "subscription",
        SourceKind::LocalFile => "local-file",
        SourceKind::Inline => "inline",
    }
}

fn protocol_display_name(protocol: ProxyProtocol) -> &'static str {
    match protocol {
        ProxyProtocol::Shadowsocks => "Shadowsocks",
        ProxyProtocol::Vmess => "VMess",
        ProxyProtocol::Vless => "VLESS",
        ProxyProtocol::Trojan => "Trojan",
        ProxyProtocol::Hysteria2 => "Hysteria2",
        ProxyProtocol::Tuic => "TUIC",
        ProxyProtocol::WireGuard => "WireGuard",
        ProxyProtocol::Unknown => "Unknown",
    }
}

fn parse_bool(value: &str) -> Option<bool> {
    match value.trim().to_ascii_lowercase().as_str() {
        "true" | "1" | "yes" | "on" => Some(true),
        "false" | "0" | "no" | "off" => Some(false),
        _ => None,
    }
}

fn parse_core_target(value: &str) -> Option<CoreTarget> {
    match value.trim().to_ascii_lowercase().as_str() {
        "mihomo" => Some(CoreTarget::Mihomo),
        "sing-box" | "singbox" => Some(CoreTarget::SingBox),
        "auto" => Some(CoreTarget::Auto),
        _ => None,
    }
}

fn parse_routing_mode(value: &str) -> Option<RoutingMode> {
    match value.trim().to_ascii_lowercase().as_str() {
        "rule" => Some(RoutingMode::Rule),
        "global" => Some(RoutingMode::Global),
        "direct" => Some(RoutingMode::Direct),
        _ => None,
    }
}

fn parse_dns_mode(value: &str) -> Option<DnsMode> {
    match value.trim().to_ascii_lowercase().as_str() {
        "system" => Some(DnsMode::System),
        "fake-ip" | "fakeip" => Some(DnsMode::FakeIp),
        "redirect" | "redir-host" => Some(DnsMode::Redirect),
        "mixed" => Some(DnsMode::Mixed),
        _ => None,
    }
}

fn core_target_name(value: CoreTarget) -> &'static str {
    match value {
        CoreTarget::Mihomo => "mihomo",
        CoreTarget::SingBox => "sing-box",
        CoreTarget::Auto => "auto",
    }
}

fn routing_mode_name(value: RoutingMode) -> &'static str {
    match value {
        RoutingMode::Rule => "rule",
        RoutingMode::Global => "global",
        RoutingMode::Direct => "direct",
    }
}

fn dns_mode_name(value: DnsMode) -> &'static str {
    match value {
        DnsMode::System => "system",
        DnsMode::FakeIp => "fake-ip",
        DnsMode::Redirect => "redirect",
        DnsMode::Mixed => "mixed",
    }
}
