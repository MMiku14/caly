use caly_core::{
    CapabilitySet, CoreAdapter, CoreIdentity, CoreIssue, IssueLevel, NativeValidationReport,
};
use caly_ir::{CompiledArtifact, ResolvedProfile};

use crate::stage::{Diagnostic, DiagnosticSeverity};

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct CompilationOutput {
    pub identity: CoreIdentity,
    pub capabilities: CapabilitySet,
    pub preflight_issues: Vec<CoreIssue>,
    pub artifact: CompiledArtifact,
    pub native_validation: NativeValidationReport,
    pub apply_planning: caly_core::ApplyPlanningResult,
    pub diagnostics: Vec<Diagnostic>,
}

pub fn compile_for_adapter(
    adapter: &dyn CoreAdapter,
    profile: &ResolvedProfile,
    current: Option<&CompiledArtifact>,
    strict_mode: bool,
) -> Result<CompilationOutput, String> {
    let identity = adapter.inspect_binary()?;
    let capabilities = adapter.capability_set(&identity)?;
    let preflight_issues = adapter.preflight(profile, &capabilities)?;
    let artifact = adapter.compile(profile, &capabilities)?;
    let native_validation = adapter.validate_native(&artifact)?;
    let apply_planning = adapter.plan_apply(current, &artifact)?;

    let mut diagnostics = Vec::new();
    diagnostics.extend(core_issues_to_diagnostics("prefight", &preflight_issues));
    diagnostics.extend(core_issues_to_diagnostics("native", &native_validation.issues));

    if artifact.bytes.is_empty() {
        diagnostics.push(Diagnostic {
            code: "ARTIFACT_EMPTY".to_owned(),
            severity: DiagnosticSeverity::Error,
            summary: "adapter produced an empty native artifact".to_owned(),
            detail: Some(artifact.file_name_hint.clone()),
            related_path: None,
            remediation: Some("fix adapter lower/emit stages before apply".to_owned()),
        });
    }

    if strict_mode && !native_validation.accepted {
        diagnostics.push(Diagnostic {
            code: "STRICT_NATIVE_VALIDATION_REJECTED".to_owned(),
            severity: DiagnosticSeverity::Error,
            summary: "strict mode blocks artifacts rejected by native validation".to_owned(),
            detail: Some(artifact.file_name_hint.clone()),
            related_path: None,
            remediation: Some("repair adapter emission or disable strict mode for exploration only".to_owned()),
        });
    }

    Ok(CompilationOutput {
        identity,
        capabilities,
        preflight_issues,
        artifact,
        native_validation,
        apply_planning,
        diagnostics,
    })
}

fn core_issues_to_diagnostics(stage: &str, issues: &[CoreIssue]) -> Vec<Diagnostic> {
    issues
        .iter()
        .map(|issue| Diagnostic {
            code: format!("CORE_{}_{}", stage.to_ascii_uppercase(), issue.code),
            severity: match issue.level {
                IssueLevel::Error => DiagnosticSeverity::Error,
                IssueLevel::Warning => DiagnosticSeverity::Warning,
                IssueLevel::Info => DiagnosticSeverity::Info,
            },
            summary: issue.summary.clone(),
            detail: Some(format!("stage={stage}")),
            related_path: None,
            remediation: None,
        })
        .collect()
}
