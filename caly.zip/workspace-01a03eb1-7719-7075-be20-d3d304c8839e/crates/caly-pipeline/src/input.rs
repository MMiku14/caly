use caly_domain::{OverrideRule, Profile, SelectionMemory};
use caly_ir::NormalizedSource;

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct PipelineRequest {
    pub profile: Profile,
    pub normalized_sources: Vec<NormalizedSource>,
    pub overrides: Vec<OverrideRule>,
    pub selection_memory: Option<SelectionMemory>,
    pub strict_mode: bool,
}
