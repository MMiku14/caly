use std::collections::BTreeSet;

use caly_domain::SelectionMemory;
use caly_ir::{
    CalyIr, CoreTarget, Digest, NodeId, ProxyProtocol, ResolvedProfile, RevisionId,
    SemanticDigest, StableBytes,
};

use crate::stage::{Diagnostic, DiagnosticSeverity, StageContext};

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct ResolveInput {
    pub ir: CalyIr,
    pub selection_memory: Option<SelectionMemory>,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct ResolveOutput {
    pub profile: ResolvedProfile,
    pub diagnostics: Vec<Diagnostic>,
}

pub fn resolve_ir(input: ResolveInput, _cx: &StageContext) -> ResolveOutput {
    let mut diagnostics = Vec::new();
    let mut ir = input.ir;

    if let Some(memory) = &input.selection_memory {
        if memory.profile_id != ir.profile_id {
            diagnostics.push(Diagnostic {
                code: "SELECTION_MEMORY_PROFILE_MISMATCH".to_owned(),
                severity: DiagnosticSeverity::Warning,
                summary: "selection memory profile id does not match current profile".to_owned(),
                detail: Some(format!(
                    "selection profile={} current profile={}",
                    memory.profile_id.0, ir.profile_id.0
                )),
                related_path: None,
                remediation: Some("drop or regenerate selection memory".to_owned()),
            });
        } else {
            apply_selection_memory(memory, &mut ir, &mut diagnostics);
        }
    }

    ensure_group_defaults(&mut ir, &mut diagnostics);
    validate_references(&ir, &mut diagnostics);

    let core_target = resolve_core_target(ir.core_target, &ir, &mut diagnostics);
    let manifest = render_manifest(&ir, core_target);
    let checksum = stable_checksum(&manifest.bytes);
    let semantic = SemanticDigest(format!("semantic:{checksum:016x}"));
    let revision_id = RevisionId(format!("rev:{checksum:016x}"));

    let profile = ResolvedProfile {
        profile_id: ir.profile_id,
        revision_id,
        semantic_digest: semantic,
        core_target,
        routing_mode: ir.routing_mode,
        nodes: ir.nodes,
        groups: ir.groups,
        rules: ir.rules,
        rulesets: ir.rulesets,
        dns: ir.dns,
        tun: ir.tun,
        inbounds: ir.inbounds,
        outbounds: ir.outbounds,
        generated_bytes: Some(manifest),
    };

    ResolveOutput { profile, diagnostics }
}

pub fn resolved_digest(profile: &ResolvedProfile) -> Digest {
    Digest(profile.semantic_digest.0.clone())
}

fn apply_selection_memory(
    memory: &SelectionMemory,
    ir: &mut CalyIr,
    diagnostics: &mut Vec<Diagnostic>,
) {
    for selection in &memory.selections {
        let Some(group_index) = ir.groups.iter().position(|group| group.id == selection.group_id) else {
            diagnostics.push(Diagnostic {
                code: "SELECTION_MEMORY_GROUP_MISSING".to_owned(),
                severity: DiagnosticSeverity::Warning,
                summary: format!("selection memory referenced missing group {}", selection.group_id.0),
                detail: None,
                related_path: None,
                remediation: Some("refresh selection memory against latest merged graph".to_owned()),
            });
            continue;
        };

        let selected = find_member_by_id_or_label(ir, group_index, &selection.node_label);
        match selected {
            Some(node_id) => ir.groups[group_index].selected = Some(node_id),
            None => diagnostics.push(Diagnostic {
                code: "SELECTION_MEMORY_NODE_MISSING".to_owned(),
                severity: DiagnosticSeverity::Warning,
                summary: format!(
                    "selection memory could not resolve node {} in group {}",
                    selection.node_label, selection.group_id.0
                ),
                detail: None,
                related_path: None,
                remediation: Some("replay selection using stable node ids after source refresh".to_owned()),
            }),
        }
    }
}

fn ensure_group_defaults(ir: &mut CalyIr, diagnostics: &mut Vec<Diagnostic>) {
    for group in &mut ir.groups {
        if group.members.is_empty() {
            diagnostics.push(Diagnostic {
                code: "EMPTY_GROUP".to_owned(),
                severity: DiagnosticSeverity::Warning,
                summary: format!("group {} has no members", group.id.0),
                detail: Some(group.label.clone()),
                related_path: None,
                remediation: Some("drop empty groups or ensure source normalization emits members".to_owned()),
            });
            group.selected = None;
            continue;
        }

        let selected_valid = group
            .selected
            .as_ref()
            .map(|selected| group.members.iter().any(|member| member == selected))
            .unwrap_or(false);
        if !selected_valid {
            let fallback = group.members.first().cloned();
            group.selected = fallback.clone();
            diagnostics.push(Diagnostic {
                code: "GROUP_SELECTION_RECOVERED".to_owned(),
                severity: DiagnosticSeverity::Info,
                summary: format!("group {} selection was defaulted during resolve", group.id.0),
                detail: fallback.map(|node| format!("selected={}", node.0)),
                related_path: None,
                remediation: Some("persist latest selection memory after successful apply".to_owned()),
            });
        }
    }
}

fn validate_references(ir: &CalyIr, diagnostics: &mut Vec<Diagnostic>) {
    let node_ids = ir.nodes.iter().map(|node| node.id.clone()).collect::<BTreeSet<_>>();
    let group_ids = ir.groups.iter().map(|group| group.id.clone()).collect::<BTreeSet<_>>();
    let outbound_ids = ir
        .outbounds
        .iter()
        .map(|outbound| outbound.id.clone())
        .collect::<BTreeSet<_>>();

    for group in &ir.groups {
        for member in &group.members {
            if !node_ids.contains(member) {
                diagnostics.push(Diagnostic {
                    code: "GROUP_MEMBER_NODE_MISSING".to_owned(),
                    severity: DiagnosticSeverity::Error,
                    summary: format!("group {} references missing node {}", group.id.0, member.0),
                    detail: None,
                    related_path: None,
                    remediation: Some("repair source normalization or drop invalid group members".to_owned()),
                });
            }
        }
    }

    for rule in &ir.rules {
        if let Some(group_id) = &rule.target_group {
            if !group_ids.contains(group_id) {
                diagnostics.push(Diagnostic {
                    code: "RULE_TARGET_GROUP_MISSING".to_owned(),
                    severity: DiagnosticSeverity::Error,
                    summary: format!("rule {} targets missing group {}", rule.id.0, group_id.0),
                    detail: Some(rule.label.clone()),
                    related_path: None,
                    remediation: Some("rebuild rules after source merge".to_owned()),
                });
            }
        }
        if let Some(outbound_id) = &rule.target_outbound {
            if !outbound_ids.contains(outbound_id) {
                diagnostics.push(Diagnostic {
                    code: "RULE_TARGET_OUTBOUND_MISSING".to_owned(),
                    severity: DiagnosticSeverity::Error,
                    summary: format!("rule {} targets missing outbound {}", rule.id.0, outbound_id.0),
                    detail: Some(rule.label.clone()),
                    related_path: None,
                    remediation: Some("rebuild outbounds or retarget the rule".to_owned()),
                });
            }
        }
    }

    for outbound in &ir.outbounds {
        if let Some(group_id) = &outbound.proxy_group {
            if !group_ids.contains(group_id) {
                diagnostics.push(Diagnostic {
                    code: "OUTBOUND_GROUP_MISSING".to_owned(),
                    severity: DiagnosticSeverity::Error,
                    summary: format!("outbound {} references missing group {}", outbound.id.0, group_id.0),
                    detail: Some(outbound.label.clone()),
                    related_path: None,
                    remediation: Some("rebuild outbound mapping after group merge".to_owned()),
                });
            }
        }
    }
}

fn resolve_core_target(
    requested: CoreTarget,
    ir: &CalyIr,
    diagnostics: &mut Vec<Diagnostic>,
) -> CoreTarget {
    match requested {
        CoreTarget::Mihomo => CoreTarget::Mihomo,
        CoreTarget::SingBox => CoreTarget::SingBox,
        CoreTarget::Auto => {
            let inferred = if ir
                .nodes
                .iter()
                .any(|node| matches!(node.protocol, ProxyProtocol::WireGuard))
                || ir
                    .tun
                    .as_ref()
                    .map(|tun| tun.strict_route)
                    .unwrap_or(false)
            {
                CoreTarget::SingBox
            } else {
                CoreTarget::Mihomo
            };
            diagnostics.push(Diagnostic {
                code: "AUTO_TARGET_RESOLVED".to_owned(),
                severity: DiagnosticSeverity::Info,
                summary: format!("auto core target resolved to {}", core_target_name(inferred)),
                detail: Some("resolved target is derived from current merged graph".to_owned()),
                related_path: None,
                remediation: Some("pin profile.core_target to make deployments fully explicit".to_owned()),
            });
            inferred
        }
    }
}

fn find_member_by_id_or_label(ir: &CalyIr, group_index: usize, value: &str) -> Option<NodeId> {
    let group = ir.groups.get(group_index)?;
    group.members.iter().find(|member| member.0 == value).cloned().or_else(|| {
        ir.nodes
            .iter()
            .find(|node| group.members.iter().any(|member| member == &node.id) && node.label == value)
            .map(|node| node.id.clone())
    })
}

fn render_manifest(ir: &CalyIr, core_target: CoreTarget) -> StableBytes {
    let mut lines = vec![
        format!("profile={}", ir.profile_id.0),
        format!("target={}", core_target_name(core_target)),
        format!("routing_mode={}", routing_mode_name(ir.routing_mode)),
        format!("sources={}", ir.source_ids.iter().map(|source| source.0.clone()).collect::<Vec<_>>().join(",")),
    ];

    for node in &ir.nodes {
        lines.push(format!(
            "node={}#{}#{}:{}#{}",
            node.id.0,
            node.label,
            node.server,
            node.port,
            proxy_protocol_name(node.protocol)
        ));
    }

    for group in &ir.groups {
        lines.push(format!(
            "group={}#{}#{}#{}#{}",
            group.id.0,
            group.label,
            group
                .members
                .iter()
                .map(|member| member.0.clone())
                .collect::<Vec<_>>()
                .join("|"),
            group
                .selected
                .as_ref()
                .map(|selected| selected.0.clone())
                .unwrap_or_else(|| "none".to_owned()),
            format!("{:?}", group.kind).to_lowercase(),
        ));
    }

    for rule in &ir.rules {
        lines.push(format!(
            "rule={}#{}#{}#{}#{}",
            rule.id.0,
            rule.label,
            rule.matcher,
            rule
                .target_group
                .as_ref()
                .map(|group| group.0.clone())
                .unwrap_or_else(|| "none".to_owned()),
            rule
                .target_outbound
                .as_ref()
                .map(|outbound| outbound.0.clone())
                .unwrap_or_else(|| "none".to_owned())
        ));
    }

    if let Some(dns) = &ir.dns {
        lines.push(format!(
            "dns={}#{}#{}",
            dns_mode_name(dns.mode),
            dns.servers.join("|"),
            dns.fake_ip_filter.join("|"),
        ));
    }

    if let Some(tun) = &ir.tun {
        lines.push(format!(
            "tun={}#{}#{}",
            tun.enabled, tun.auto_route, tun.strict_route
        ));
    }

    StableBytes::new(lines.join("\n").into_bytes())
}

fn stable_checksum(bytes: &[u8]) -> u64 {
    const OFFSET: u64 = 0xcbf29ce484222325;
    const PRIME: u64 = 0x100000001b3;

    let mut hash = OFFSET;
    for byte in bytes {
        hash ^= u64::from(*byte);
        hash = hash.wrapping_mul(PRIME);
    }
    hash
}

fn core_target_name(target: CoreTarget) -> &'static str {
    match target {
        CoreTarget::Mihomo => "mihomo",
        CoreTarget::SingBox => "sing-box",
        CoreTarget::Auto => "auto",
    }
}

fn routing_mode_name(mode: caly_ir::RoutingMode) -> &'static str {
    match mode {
        caly_ir::RoutingMode::Rule => "rule",
        caly_ir::RoutingMode::Global => "global",
        caly_ir::RoutingMode::Direct => "direct",
    }
}

fn proxy_protocol_name(protocol: ProxyProtocol) -> &'static str {
    match protocol {
        ProxyProtocol::Shadowsocks => "shadowsocks",
        ProxyProtocol::Vmess => "vmess",
        ProxyProtocol::Vless => "vless",
        ProxyProtocol::Trojan => "trojan",
        ProxyProtocol::Hysteria2 => "hysteria2",
        ProxyProtocol::Tuic => "tuic",
        ProxyProtocol::WireGuard => "wireguard",
        ProxyProtocol::Unknown => "unknown",
    }
}

fn dns_mode_name(mode: caly_ir::DnsMode) -> &'static str {
    match mode {
        caly_ir::DnsMode::System => "system",
        caly_ir::DnsMode::FakeIp => "fake-ip",
        caly_ir::DnsMode::Redirect => "redirect",
        caly_ir::DnsMode::Mixed => "mixed",
    }
}
