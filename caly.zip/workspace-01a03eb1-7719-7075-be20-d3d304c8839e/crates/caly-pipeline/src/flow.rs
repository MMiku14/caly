use caly_core::CoreAdapter;
use caly_domain::{MergeReport, Profile};
use caly_ir::{NormalizedSource, ResolvedProfile};
use caly_plan::{ApplyPlan, EffectPlan};

use crate::compile::{compile_for_adapter, CompilationOutput};
use crate::input::PipelineRequest;
use crate::merge::{merge_profile, MergeInput};
use crate::resolve::{resolve_ir, ResolveInput};
use crate::stage::{Diagnostic, StageContext};
use crate::validate::{
    validate_capabilities, validate_semantic, CapabilityValidationReport,
};

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct PipelineFlowOutput {
    pub merge_report: MergeReport,
    pub diagnostics: Vec<Diagnostic>,
    pub resolved_profile: ResolvedProfile,
    pub capability_validation: Option<CapabilityValidationReport>,
    pub compile: Option<CompilationOutput>,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct ApplyWorkflowProjection {
    pub resolved_profile: ResolvedProfile,
    pub capability_validation: Option<CapabilityValidationReport>,
    pub apply_plan: ApplyPlan,
    pub effect_plan: Option<EffectPlan>,
    pub diagnostics: Vec<Diagnostic>,
}

pub fn run_pipeline(
    request: PipelineRequest,
    cx: StageContext,
) -> PipelineFlowOutput {
    let normalized_sources = collect_sources(&request.profile, &request.normalized_sources);
    let merge = merge_profile(
        MergeInput {
            profile: request.profile,
            normalized_sources,
            overrides: request.overrides,
        },
        &cx,
    );

    let resolve = resolve_ir(
        ResolveInput {
            ir: merge.ir,
            selection_memory: request.selection_memory,
        },
        &cx,
    );

    let semantic = validate_semantic(&resolve.profile, &cx);

    let mut diagnostics = Vec::new();
    diagnostics.extend(merge.diagnostics.clone());
    diagnostics.extend(resolve.diagnostics.clone());
    diagnostics.extend(semantic.diagnostics);

    PipelineFlowOutput {
        merge_report: merge.report,
        diagnostics,
        resolved_profile: resolve.profile,
        capability_validation: None,
        compile: None,
    }
}

pub fn run_pipeline_for_adapter(
    request: PipelineRequest,
    cx: StageContext,
    adapter: &dyn CoreAdapter,
    current: Option<&caly_ir::CompiledArtifact>,
) -> Result<PipelineFlowOutput, String> {
    let mut output = run_pipeline(request, cx.clone());
    let compiled = compile_for_adapter(adapter, &output.resolved_profile, current, cx.strict_mode)?;
    let capability_validation = validate_capabilities(&output.resolved_profile, &compiled.capabilities, cx.strict_mode);
    output.diagnostics.extend(compiled.diagnostics.clone());
    output.diagnostics.extend(capability_validation.diagnostics.clone());
    output.capability_validation = Some(capability_validation);
    output.compile = Some(compiled);
    Ok(output)
}

pub fn project_apply_workflow(output: PipelineFlowOutput) -> Option<ApplyWorkflowProjection> {
    let compiled = output.compile?;
    Some(ApplyWorkflowProjection {
        resolved_profile: output.resolved_profile,
        capability_validation: output.capability_validation,
        apply_plan: compiled.apply_planning.apply_plan,
        effect_plan: compiled.apply_planning.effect_plan,
        diagnostics: output.diagnostics,
    })
}

fn collect_sources(profile: &Profile, normalized_sources: &[NormalizedSource]) -> Vec<NormalizedSource> {
    if !normalized_sources.is_empty() {
        return normalized_sources.to_vec();
    }

    profile
        .source_refs
        .iter()
        .map(|source| NormalizedSource {
            id: source.id.clone(),
            raw_digest: caly_ir::Digest(format!("raw:{}", source.id.0)),
            source_kind: caly_ir::SourceKind::Subscription,
            node_count_estimate: 1,
            group_count_estimate: 1,
            rule_count_estimate: 1,
        })
        .collect()
}
