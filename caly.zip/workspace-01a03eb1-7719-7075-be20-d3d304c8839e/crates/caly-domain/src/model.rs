use caly_ir::{
    CoreTarget, GroupId, ProfileId, RoutingMode, SourceId, TunPolicy,
};

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct SourceRef {
    pub id: SourceId,
    pub label: String,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct Profile {
    pub id: ProfileId,
    pub label: String,
    pub core_target: CoreTarget,
    pub source_refs: Vec<SourceRef>,
    pub routing_mode: RoutingMode,
    pub tun: Option<TunPolicy>,
    pub active_group_selection: Vec<GroupSelection>,
}

impl Profile {
    pub fn has_source(&self, source_id: &SourceId) -> bool {
        self.source_refs.iter().any(|source| &source.id == source_id)
    }

    pub fn source_ref(&self, source_id: &SourceId) -> Option<&SourceRef> {
        self.source_refs.iter().find(|source| &source.id == source_id)
    }

    pub fn selection_for_group(&self, group_id: &GroupId) -> Option<&GroupSelection> {
        self.active_group_selection
            .iter()
            .find(|selection| &selection.group_id == group_id)
    }
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct GroupSelection {
    pub group_id: GroupId,
    pub node_label: String,
}

#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub enum OverrideScope {
    Runtime,
    Profile,
    Source,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct OverrideRule {
    pub label: String,
    pub scope: OverrideScope,
    pub selector: String,
    pub operation: String,
    pub value: Option<String>,
}

impl OverrideRule {
    pub fn is_set_operation(&self) -> bool {
        self.operation.eq_ignore_ascii_case("set")
            || self.operation.eq_ignore_ascii_case("replace")
    }
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct SelectionMemory {
    pub profile_id: ProfileId,
    pub selections: Vec<GroupSelection>,
}

impl SelectionMemory {
    pub fn selection_for_group(&self, group_id: &GroupId) -> Option<&GroupSelection> {
        self.selections
            .iter()
            .find(|selection| &selection.group_id == group_id)
    }
}
