use caly_ir::{CoreTarget, GroupId, RoutingMode, SourceId, TunPolicy};

use crate::model::{GroupSelection, OverrideRule, OverrideScope, Profile, SelectionMemory, SourceRef};

pub fn source_ref(id: impl Into<String>, label: impl Into<String>) -> SourceRef {
    SourceRef {
        id: SourceId::new(id),
        label: label.into(),
    }
}

pub fn skeleton_profile(
    id: impl Into<String>,
    label: impl Into<String>,
    core_target: CoreTarget,
    routing_mode: RoutingMode,
) -> Profile {
    Profile {
        id: caly_ir::ProfileId::new(id),
        label: label.into(),
        core_target,
        source_refs: Vec::new(),
        routing_mode,
        tun: Some(TunPolicy {
            enabled: false,
            auto_route: false,
            strict_route: false,
        }),
        active_group_selection: Vec::new(),
    }
}

pub fn attach_sources(mut profile: Profile, sources: Vec<SourceRef>) -> Profile {
    profile.source_refs = sources;
    profile
}

pub fn attach_group_selection(
    mut profile: Profile,
    group_id: impl Into<String>,
    node_label: impl Into<String>,
) -> Profile {
    profile.active_group_selection.push(GroupSelection {
        group_id: GroupId::new(group_id),
        node_label: node_label.into(),
    });
    profile
}

pub fn replace_tun(
    mut profile: Profile,
    enabled: bool,
    auto_route: bool,
    strict_route: bool,
) -> Profile {
    profile.tun = Some(TunPolicy {
        enabled,
        auto_route,
        strict_route,
    });
    profile
}

pub fn group_selection(group_id: impl Into<String>, node_label: impl Into<String>) -> GroupSelection {
    GroupSelection {
        group_id: GroupId::new(group_id),
        node_label: node_label.into(),
    }
}

pub fn override_rule(
    label: impl Into<String>,
    scope: OverrideScope,
    selector: impl Into<String>,
    operation: impl Into<String>,
    value: Option<String>,
) -> OverrideRule {
    OverrideRule {
        label: label.into(),
        scope,
        selector: selector.into(),
        operation: operation.into(),
        value,
    }
}

pub fn selection_memory(profile: &Profile, selections: Vec<GroupSelection>) -> SelectionMemory {
    SelectionMemory {
        profile_id: profile.id.clone(),
        selections,
    }
}
