use caly_ir::{GroupId, NodeId, ProfileId, RuleId, SourceId};

#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub enum MergeEventKind {
    Rename,
    Drop,
    Override,
    Conflict,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct MergeEvent {
    pub kind: MergeEventKind,
    pub source_id: Option<SourceId>,
    pub profile_id: Option<ProfileId>,
    pub rule_id: Option<RuleId>,
    pub node_id: Option<NodeId>,
    pub group_id: Option<GroupId>,
    pub message: String,
}

#[derive(Clone, Debug, Default, Eq, PartialEq)]
pub struct MergeReport {
    pub events: Vec<MergeEvent>,
}

impl MergeReport {
    pub fn push(&mut self, event: MergeEvent) {
        self.events.push(event);
    }

    pub fn conflict_count(&self) -> usize {
        self.events
            .iter()
            .filter(|event| matches!(event.kind, MergeEventKind::Conflict))
            .count()
    }
}
