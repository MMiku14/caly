use caly_ir::{ArtifactDigest, CoreTarget, StableBytes};

use crate::adapter::CoreKind;

pub fn stable_checksum_bytes(bytes: &[u8]) -> u64 {
    const OFFSET: u64 = 0xcbf29ce484222325;
    const PRIME: u64 = 0x100000001b3;

    let mut hash = OFFSET;
    for byte in bytes {
        hash ^= u64::from(*byte);
        hash = hash.wrapping_mul(PRIME);
    }
    hash
}

pub fn stable_checksum_text(text: &str) -> u64 {
    stable_checksum_bytes(text.as_bytes())
}

pub fn artifact_digest(core_name: &str, body: &StableBytes) -> ArtifactDigest {
    ArtifactDigest(format!("{}:{:016x}", core_name, stable_checksum_bytes(&body.bytes)))
}

pub fn target_for_core_kind(kind: CoreKind) -> CoreTarget {
    match kind {
        CoreKind::Mihomo => CoreTarget::Mihomo,
        CoreKind::SingBox => CoreTarget::SingBox,
    }
}
