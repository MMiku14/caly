#[derive(Clone, Debug, Eq, PartialEq)]
pub struct TrafficSample {
    pub upload_bytes_per_sec: u64,
    pub download_bytes_per_sec: u64,
    pub uploaded_total: u64,
    pub downloaded_total: u64,
    pub timestamp_ms: i64,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct RuntimeConnection {
    pub id: String,
    pub destination: String,
    pub process: Option<String>,
    pub rule: Option<String>,
    pub chain: Vec<String>,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct GroupRuntimeState {
    pub group_label: String,
    pub selected_label: Option<String>,
    pub group_type: String,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct RuntimeLogLine {
    pub level: String,
    pub timestamp_ms: i64,
    pub component: String,
    pub message: String,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct CoreResourceSample {
    pub cpu_percent: u32,
    pub rss_bytes: u64,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct RuntimeStatusView {
    pub running: bool,
    pub healthy: bool,
    pub config_identity: Option<String>,
    pub summary: String,
}

pub trait ControlPlane: Send + Sync + 'static {
    fn status(&self) -> Result<RuntimeStatusView, String>;
    fn reload(&self) -> Result<(), String>;
    fn select_proxy(&self, group_label: &str, node_label: &str) -> Result<(), String>;
    fn close_connection(&self, connection_id: &str) -> Result<(), String>;
}

pub trait TelemetryPlane: Send + Sync + 'static {
    fn traffic(&self) -> Result<Vec<TrafficSample>, String>;
    fn connections(&self) -> Result<Vec<RuntimeConnection>, String>;
    fn groups(&self) -> Result<Vec<GroupRuntimeState>, String>;
    fn logs(&self) -> Result<Vec<RuntimeLogLine>, String>;
    fn resource(&self) -> Result<Vec<CoreResourceSample>, String>;
}

pub trait ProbePlane: Send + Sync + 'static {
    fn api_ready(&self) -> Result<bool, String>;
    fn config_identity(&self) -> Result<Option<String>, String>;
    fn inbound_listening(&self) -> Result<bool, String>;
}

pub trait RuntimeDriver: Send + Sync + 'static {
    fn control(&self) -> &dyn ControlPlane;
    fn telemetry(&self) -> &dyn TelemetryPlane;
    fn probe(&self) -> &dyn ProbePlane;
}
