use caly_cap::{CapabilityDescriptor, CapabilityKey};
use caly_ir::{CompiledArtifact, CoreTarget, ResolvedProfile};
use caly_plan::{ApplyPlan, EffectPlan};

use crate::runtime::RuntimeDriver;

#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub enum CoreKind {
    Mihomo,
    SingBox,
}

impl CoreKind {
    pub const fn as_str(self) -> &'static str {
        match self {
            Self::Mihomo => "mihomo",
            Self::SingBox => "sing-box",
        }
    }

    pub const fn target(self) -> CoreTarget {
        match self {
            Self::Mihomo => CoreTarget::Mihomo,
            Self::SingBox => CoreTarget::SingBox,
        }
    }
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct CoreIdentity {
    pub kind: CoreKind,
    pub version: String,
    pub build: Option<String>,
    pub binary_digest: String,
}

#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub enum IssueLevel {
    Error,
    Warning,
    Info,
}

impl IssueLevel {
    pub const fn as_str(self) -> &'static str {
        match self {
            Self::Error => "error",
            Self::Warning => "warning",
            Self::Info => "info",
        }
    }
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct CoreIssue {
    pub level: IssueLevel,
    pub code: String,
    pub summary: String,
}

#[derive(Clone, Debug, Default, Eq, PartialEq)]
pub struct CapabilitySet {
    pub descriptors: Vec<CapabilityDescriptor>,
}

impl CapabilitySet {
    pub fn find(&self, key: &CapabilityKey) -> Option<&CapabilityDescriptor> {
        self.descriptors.iter().find(|descriptor| &descriptor.key == key)
    }

    pub fn supports_exact(&self, key: &CapabilityKey) -> bool {
        self.find(key)
            .map(|descriptor| {
                matches!(
                    descriptor.state,
                    caly_cap::CapabilityState::SupportedExact
                        | caly_cap::CapabilityState::SupportedNativeOnly
                        | caly_cap::CapabilityState::PreservedOpaque
                        | caly_cap::CapabilityState::Experimental
                )
            })
            .unwrap_or(false)
    }
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct NativeValidationReport {
    pub accepted: bool,
    pub issues: Vec<CoreIssue>,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct ApplyPlanningResult {
    pub apply_plan: ApplyPlan,
    pub effect_plan: Option<EffectPlan>,
}

pub trait CoreAdapter: Send + Sync + 'static {
    fn inspect_binary(&self) -> Result<CoreIdentity, String>;
    fn capability_set(&self, identity: &CoreIdentity) -> Result<CapabilitySet, String>;
    fn preflight(
        &self,
        profile: &ResolvedProfile,
        capabilities: &CapabilitySet,
    ) -> Result<Vec<CoreIssue>, String>;
    fn compile(
        &self,
        profile: &ResolvedProfile,
        capabilities: &CapabilitySet,
    ) -> Result<CompiledArtifact, String>;
    fn validate_native(&self, artifact: &CompiledArtifact) -> Result<NativeValidationReport, String>;
    fn plan_apply(
        &self,
        current: Option<&CompiledArtifact>,
        next: &CompiledArtifact,
    ) -> Result<ApplyPlanningResult, String>;
    fn runtime(&self) -> Result<Box<dyn RuntimeDriver>, String>;
}
