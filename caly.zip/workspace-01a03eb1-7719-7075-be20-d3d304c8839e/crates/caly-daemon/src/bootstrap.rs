use caly_api::ProtocolVersion;
use caly_engine::{EngineLifecycle, EngineState};

use crate::state::{DaemonLifecycle, DaemonRuntimeState};

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct DaemonBootstrapConfig {
    pub instance_id: String,
    pub protocol_version: ProtocolVersion,
    pub recover_on_start: bool,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct DaemonBootstrapResult {
    pub runtime: DaemonRuntimeState,
    pub engine: EngineState,
}

pub fn bootstrap(config: DaemonBootstrapConfig) -> DaemonBootstrapResult {
    let mut runtime = DaemonRuntimeState::new(config.instance_id, config.protocol_version);
    runtime.lifecycle = if config.recover_on_start {
        DaemonLifecycle::Recovering
    } else {
        DaemonLifecycle::Starting
    };

    let mut engine = EngineState::new();
    engine.set_lifecycle(if config.recover_on_start {
        EngineLifecycle::Recovering
    } else {
        EngineLifecycle::Idle
    });

    DaemonBootstrapResult { runtime, engine }
}
