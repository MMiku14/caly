use caly_api::{JobFollowRequest, Operation, OperationResult, RequestEnvelope, RuntimeSubscription, WatchOpened};
use caly_ipc::{AckPolicy, StreamFrame, StreamKind, stream_policy};

use crate::app::DaemonApp;

pub fn handle_stream(app: &DaemonApp, envelope: &RequestEnvelope) -> Option<OperationResult> {
    match &envelope.operation {
        Operation::Runtime(caly_api::RuntimeOp::Watch { subscription }) => {
            let runtime = app.allocate_stream(subscription.clone()).ok()?;
            Some(OperationResult::WatchOpened(WatchOpened {
                stream_id: caly_api::StreamId(runtime.stream_id),
                subscription_kind: runtime.subscription_kind,
            }))
        }
        Operation::Diagnostics(caly_api::DiagnosticsOp::FollowJobStream { request }) => {
            let runtime = app.allocate_job_stream(request.clone()).ok()?;
            Some(OperationResult::WatchOpened(WatchOpened {
                stream_id: caly_api::StreamId(runtime.stream_id),
                subscription_kind: runtime.subscription_kind,
            }))
        }
        _ => None,
    }
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct OpenedStream {
    pub stream_id: u64,
    pub subscription_kind: String,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub enum StreamSource {
    RuntimeSubscription(RuntimeSubscription),
    JobFollow(JobFollowRequest),
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct OpenedStreamState {
    pub stream_id: caly_api::StreamId,
    pub kind: StreamKind,
    pub source: StreamSource,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct StreamCursorState {
    pub opened: OpenedStreamState,
    pub last_emitted_seq: Option<u64>,
    pub acked_upto: Option<u64>,
}

impl StreamCursorState {
    pub fn new(opened: OpenedStreamState) -> Self {
        Self {
            opened,
            last_emitted_seq: None,
            acked_upto: None,
        }
    }

    pub fn note_emitted_frames(&mut self, frames: &[StreamFrame]) {
        if let Some(last) = frames.last() {
            self.last_emitted_seq = Some(last.seq);
        }
    }

    pub fn apply_ack(&mut self, upto_seq: u64) {
        self.acked_upto = Some(self.acked_upto.map(|current| current.max(upto_seq)).unwrap_or(upto_seq));
    }

    pub fn preferred_resume_from(&self, explicit: Option<u64>) -> Option<u64> {
        if explicit.is_some() {
            return explicit;
        }

        match stream_policy(self.opened.kind).ack {
            AckPolicy::Required | AckPolicy::Optional => self.acked_upto.or(self.last_emitted_seq),
            AckPolicy::None => self.last_emitted_seq,
        }
    }
}

pub fn subscription_kind_name(subscription: RuntimeSubscription) -> String {
    match subscription {
        RuntimeSubscription::Dashboard => "dashboard",
        RuntimeSubscription::Traffic => "traffic",
        RuntimeSubscription::Logs => "logs",
        RuntimeSubscription::Connections => "connections",
    }
    .to_owned()
}

pub fn stream_kind_for_operation(operation: &Operation) -> Option<StreamKind> {
    match operation {
        Operation::Runtime(caly_api::RuntimeOp::Watch { subscription }) => Some(match subscription {
            RuntimeSubscription::Dashboard => StreamKind::Dashboard,
            RuntimeSubscription::Traffic => StreamKind::Traffic,
            RuntimeSubscription::Logs => StreamKind::Logs,
            RuntimeSubscription::Connections => StreamKind::Connections,
        }),
        Operation::Diagnostics(caly_api::DiagnosticsOp::FollowJobStream { .. }) => Some(StreamKind::Job),
        _ => None,
    }
}

pub fn opened_stream_state_for_operation(
    operation: &Operation,
    opened: &WatchOpened,
) -> Option<OpenedStreamState> {
    let kind = stream_kind_for_operation(operation)?;
    let source = match operation {
        Operation::Runtime(caly_api::RuntimeOp::Watch { subscription }) => {
            StreamSource::RuntimeSubscription(subscription.clone())
        }
        Operation::Diagnostics(caly_api::DiagnosticsOp::FollowJobStream { request }) => {
            StreamSource::JobFollow(request.clone())
        }
        _ => return None,
    };

    Some(OpenedStreamState {
        stream_id: opened.stream_id,
        kind,
        source,
    })
}
