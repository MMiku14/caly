use std::sync::Arc;

use caly_api::{
    Accepted, ApiError, ApiResult, AutomationFacet, AutomationJobView, BoxFuture, CalyFacade,
    CapabilityQuery, CapabilityReport, ConnectionId, ConnectionPage, ConnectionQuery,
    CoreFacet, CoreInspection, CoreInstallId, CoreInstallView, Ctx, DelayTestRequest,
    DiagnosticsFacet, DnsExplainRequest, DnsExplainResult, DnsFacet, DnsStatus, DoctorReport,
    DoctorRequest, ErrorCategory, ErrorCode, GroupView, JobFollowRequest, JobFollowView,
    RecoveryStatusView,
    NetworkFacet, NetworkPlanView, NetworkStatus, NodePage, NodeQuery, PatchAutomationJob,
    PipelineExplain, PipelineExplainRequest, ProfileFacet, ProfileId, ProfileSummary, ProfileView,
    ProxyFacet, RollbackRequest, RouteExplainRequest, RouteExplainResult, RoutingFacet,
    RoutingValidation, RulePage, RuleQuery, RuntimeFacet, RuntimeStatus, RuntimeSubscription,
    SelectNode, ServerInfo, SourceFacet, SourceId, SourceInspection, SourcePreview,
    SourcePreviewRequest, SourceSummary, SystemFacet, SystemStatus, WatchOpened, Operation,
    OperationResult, RequestEnvelope, RequestId, Role, SystemOp, ProfileOp, SourceOp, ProxyOp,
    RoutingOp, DnsOp, NetworkOp, CoreOp, RuntimeOp, DiagnosticsOp, AutomationOp, ApplyRequest,
};

use crate::app::DaemonApp;
use crate::handler::handle_request;

#[derive(Clone)]
pub struct LocalFacade {
    app: Arc<DaemonApp>,
}

impl LocalFacade {
    pub fn new(app: DaemonApp) -> Self {
        Self { app: Arc::new(app) }
    }

    pub fn app(&self) -> Arc<DaemonApp> {
        Arc::clone(&self.app)
    }
}

impl CalyFacade for LocalFacade {
    fn system(&self) -> Arc<dyn SystemFacet> {
        Arc::new(LocalSystemFacet { app: self.app() })
    }

    fn profile(&self) -> Arc<dyn ProfileFacet> {
        Arc::new(LocalProfileFacet { app: self.app() })
    }

    fn source(&self) -> Arc<dyn SourceFacet> {
        Arc::new(LocalSourceFacet { app: self.app() })
    }

    fn proxy(&self) -> Arc<dyn ProxyFacet> {
        Arc::new(LocalProxyFacet { app: self.app() })
    }

    fn routing(&self) -> Arc<dyn RoutingFacet> {
        Arc::new(LocalRoutingFacet { app: self.app() })
    }

    fn dns(&self) -> Arc<dyn DnsFacet> {
        Arc::new(LocalDnsFacet { app: self.app() })
    }

    fn network(&self) -> Arc<dyn NetworkFacet> {
        Arc::new(LocalNetworkFacet { app: self.app() })
    }

    fn core(&self) -> Arc<dyn CoreFacet> {
        Arc::new(LocalCoreFacet { app: self.app() })
    }

    fn runtime(&self) -> Arc<dyn RuntimeFacet> {
        Arc::new(LocalRuntimeFacet { app: self.app() })
    }

    fn diagnostics(&self) -> Arc<dyn DiagnosticsFacet> {
        Arc::new(LocalDiagnosticsFacet { app: self.app() })
    }

    fn automation(&self) -> Arc<dyn AutomationFacet> {
        Arc::new(LocalAutomationFacet { app: self.app() })
    }
}

fn admin_request(ctx: &Ctx, operation: Operation) -> RequestEnvelope {
    RequestEnvelope {
        protocol: caly_api::ProtocolVersion { major: 1, minor: 0 },
        request_id: RequestId(0),
        trace_id: ctx.trace_id.clone(),
        deadline_ms: ctx.deadline_ms,
        expected_revision: ctx.expected_revision,
        idempotency_key: None,
        role: Role::Admin,
        operation,
    }
}

fn dispatch(app: &DaemonApp, ctx: &Ctx, operation: Operation) -> ApiResult<OperationResult> {
    let envelope = admin_request(ctx, operation);
    handle_request(app, ctx.actor, &envelope).result
}

fn unavailable(ctx: &Ctx, summary: impl Into<String>) -> ApiError {
    ApiError::new(
        ErrorCode::Unavailable,
        ErrorCategory::Internal,
        false,
        summary,
        ctx.trace_id.clone(),
    )
}

#[derive(Clone)]
struct LocalSystemFacet {
    app: Arc<DaemonApp>,
}

impl SystemFacet for LocalSystemFacet {
    fn status<'a>(&'a self, ctx: Ctx) -> BoxFuture<'a, ApiResult<SystemStatus>> {
        let app = Arc::clone(&self.app);
        Box::pin(async move {
            match dispatch(&app, &ctx, Operation::System(SystemOp::Status))? {
                OperationResult::SystemStatus(value) => Ok(value),
                other => Err(unavailable(&ctx, format!("unexpected result for system.status: {:?}", other))),
            }
        })
    }

    fn info<'a>(&'a self, ctx: Ctx) -> BoxFuture<'a, ApiResult<ServerInfo>> {
        let app = Arc::clone(&self.app);
        Box::pin(async move {
            match dispatch(&app, &ctx, Operation::System(SystemOp::Info))? {
                OperationResult::ServerInfo(value) => Ok(value),
                other => Err(unavailable(&ctx, format!("unexpected result for system.info: {:?}", other))),
            }
        })
    }

    fn shutdown<'a>(&'a self, ctx: Ctx) -> BoxFuture<'a, ApiResult<Accepted>> {
        let app = Arc::clone(&self.app);
        Box::pin(async move {
            match dispatch(&app, &ctx, Operation::System(SystemOp::Shutdown))? {
                OperationResult::Accepted(value) => Ok(value),
                other => Err(unavailable(&ctx, format!("unexpected result for system.shutdown: {:?}", other))),
            }
        })
    }
}

#[derive(Clone)]
struct LocalProfileFacet {
    app: Arc<DaemonApp>,
}

impl ProfileFacet for LocalProfileFacet {
    fn list<'a>(&'a self, ctx: Ctx) -> BoxFuture<'a, ApiResult<Vec<ProfileSummary>>> {
        let app = Arc::clone(&self.app);
        Box::pin(async move {
            match dispatch(&app, &ctx, Operation::Profile(ProfileOp::List))? {
                OperationResult::ProfileList(value) => Ok(value),
                other => Err(unavailable(&ctx, format!("unexpected result for profile.list: {:?}", other))),
            }
        })
    }

    fn get<'a>(&'a self, ctx: Ctx, profile_id: ProfileId) -> BoxFuture<'a, ApiResult<ProfileView>> {
        let app = Arc::clone(&self.app);
        Box::pin(async move {
            match dispatch(&app, &ctx, Operation::Profile(ProfileOp::Get { profile_id }))? {
                OperationResult::ProfileView(value) => Ok(value),
                other => Err(unavailable(&ctx, format!("unexpected result for profile.get: {:?}", other))),
            }
        })
    }

    fn plan<'a>(&'a self, ctx: Ctx, request: ApplyRequest) -> BoxFuture<'a, ApiResult<caly_api::DeploymentPlanView>> {
        let app = Arc::clone(&self.app);
        Box::pin(async move {
            match dispatch(&app, &ctx, Operation::Profile(ProfileOp::Plan { request }))? {
                OperationResult::DeploymentPlan(value) => Ok(value),
                other => Err(unavailable(&ctx, format!("unexpected result for profile.plan: {:?}", other))),
            }
        })
    }

    fn apply<'a>(&'a self, ctx: Ctx, request: ApplyRequest) -> BoxFuture<'a, ApiResult<Accepted>> {
        let app = Arc::clone(&self.app);
        Box::pin(async move {
            match dispatch(&app, &ctx, Operation::Profile(ProfileOp::Apply { request }))? {
                OperationResult::Accepted(value) => Ok(value),
                other => Err(unavailable(&ctx, format!("unexpected result for profile.apply: {:?}", other))),
            }
        })
    }

    fn rollback<'a>(&'a self, ctx: Ctx, request: RollbackRequest) -> BoxFuture<'a, ApiResult<Accepted>> {
        let app = Arc::clone(&self.app);
        Box::pin(async move {
            match dispatch(&app, &ctx, Operation::Profile(ProfileOp::Rollback { request }))? {
                OperationResult::Accepted(value) => Ok(value),
                other => Err(unavailable(&ctx, format!("unexpected result for profile.rollback: {:?}", other))),
            }
        })
    }
}

#[derive(Clone)]
struct LocalSourceFacet {
    app: Arc<DaemonApp>,
}

impl SourceFacet for LocalSourceFacet {
    fn list<'a>(&'a self, ctx: Ctx) -> BoxFuture<'a, ApiResult<Vec<SourceSummary>>> {
        let app = Arc::clone(&self.app);
        Box::pin(async move {
            match dispatch(&app, &ctx, Operation::Source(SourceOp::List))? {
                OperationResult::SourceList(value) => Ok(value),
                other => Err(unavailable(&ctx, format!("unexpected result for source.list: {:?}", other))),
            }
        })
    }

    fn inspect<'a>(&'a self, ctx: Ctx, source_id: SourceId) -> BoxFuture<'a, ApiResult<SourceInspection>> {
        let app = Arc::clone(&self.app);
        Box::pin(async move {
            match dispatch(&app, &ctx, Operation::Source(SourceOp::Inspect { source_id }))? {
                OperationResult::SourceInspection(value) => Ok(value),
                other => Err(unavailable(&ctx, format!("unexpected result for source.inspect: {:?}", other))),
            }
        })
    }

    fn update<'a>(&'a self, ctx: Ctx, source_id: SourceId) -> BoxFuture<'a, ApiResult<Accepted>> {
        let app = Arc::clone(&self.app);
        Box::pin(async move {
            match dispatch(&app, &ctx, Operation::Source(SourceOp::Update { source_id }))? {
                OperationResult::Accepted(value) => Ok(value),
                other => Err(unavailable(&ctx, format!("unexpected result for source.update: {:?}", other))),
            }
        })
    }

    fn preview<'a>(&'a self, ctx: Ctx, request: SourcePreviewRequest) -> BoxFuture<'a, ApiResult<SourcePreview>> {
        let app = Arc::clone(&self.app);
        Box::pin(async move {
            match dispatch(&app, &ctx, Operation::Source(SourceOp::Preview { request }))? {
                OperationResult::SourcePreview(value) => Ok(value),
                other => Err(unavailable(&ctx, format!("unexpected result for source.preview: {:?}", other))),
            }
        })
    }
}

#[derive(Clone)]
struct LocalProxyFacet {
    app: Arc<DaemonApp>,
}

impl ProxyFacet for LocalProxyFacet {
    fn nodes<'a>(&'a self, ctx: Ctx, query: NodeQuery) -> BoxFuture<'a, ApiResult<NodePage>> {
        let app = Arc::clone(&self.app);
        Box::pin(async move {
            match dispatch(&app, &ctx, Operation::Proxy(ProxyOp::Nodes { query }))? {
                OperationResult::NodePage(value) => Ok(value),
                other => Err(unavailable(&ctx, format!("unexpected result for proxy.nodes: {:?}", other))),
            }
        })
    }

    fn groups<'a>(&'a self, ctx: Ctx) -> BoxFuture<'a, ApiResult<Vec<GroupView>>> {
        let app = Arc::clone(&self.app);
        Box::pin(async move {
            match dispatch(&app, &ctx, Operation::Proxy(ProxyOp::Groups))? {
                OperationResult::GroupList(value) => Ok(value),
                other => Err(unavailable(&ctx, format!("unexpected result for proxy.groups: {:?}", other))),
            }
        })
    }

    fn select<'a>(&'a self, ctx: Ctx, request: SelectNode) -> BoxFuture<'a, ApiResult<Accepted>> {
        let app = Arc::clone(&self.app);
        Box::pin(async move {
            match dispatch(&app, &ctx, Operation::Proxy(ProxyOp::Select { request }))? {
                OperationResult::Accepted(value) => Ok(value),
                other => Err(unavailable(&ctx, format!("unexpected result for proxy.select: {:?}", other))),
            }
        })
    }

    fn test_delay<'a>(&'a self, ctx: Ctx, request: DelayTestRequest) -> BoxFuture<'a, ApiResult<Accepted>> {
        let app = Arc::clone(&self.app);
        Box::pin(async move {
            match dispatch(&app, &ctx, Operation::Proxy(ProxyOp::TestDelay { request }))? {
                OperationResult::Accepted(value) => Ok(value),
                other => Err(unavailable(&ctx, format!("unexpected result for proxy.test_delay: {:?}", other))),
            }
        })
    }
}

#[derive(Clone)]
struct LocalRoutingFacet {
    app: Arc<DaemonApp>,
}

impl RoutingFacet for LocalRoutingFacet {
    fn rules<'a>(&'a self, ctx: Ctx, query: RuleQuery) -> BoxFuture<'a, ApiResult<RulePage>> {
        let app = Arc::clone(&self.app);
        Box::pin(async move {
            match dispatch(&app, &ctx, Operation::Routing(RoutingOp::Rules { query }))? {
                OperationResult::RulePage(value) => Ok(value),
                other => Err(unavailable(&ctx, format!("unexpected result for routing.rules: {:?}", other))),
            }
        })
    }

    fn explain<'a>(&'a self, ctx: Ctx, request: RouteExplainRequest) -> BoxFuture<'a, ApiResult<RouteExplainResult>> {
        let app = Arc::clone(&self.app);
        Box::pin(async move {
            match dispatch(&app, &ctx, Operation::Routing(RoutingOp::Explain { request }))? {
                OperationResult::RouteExplain(value) => Ok(value),
                other => Err(unavailable(&ctx, format!("unexpected result for routing.explain: {:?}", other))),
            }
        })
    }

    fn validate<'a>(&'a self, ctx: Ctx, profile_id: ProfileId) -> BoxFuture<'a, ApiResult<RoutingValidation>> {
        let app = Arc::clone(&self.app);
        Box::pin(async move {
            match dispatch(&app, &ctx, Operation::Routing(RoutingOp::Validate { profile_id }))? {
                OperationResult::RoutingValidation(value) => Ok(value),
                other => Err(unavailable(&ctx, format!("unexpected result for routing.validate: {:?}", other))),
            }
        })
    }
}

#[derive(Clone)]
struct LocalDnsFacet {
    app: Arc<DaemonApp>,
}

impl DnsFacet for LocalDnsFacet {
    fn status<'a>(&'a self, ctx: Ctx) -> BoxFuture<'a, ApiResult<DnsStatus>> {
        let app = Arc::clone(&self.app);
        Box::pin(async move {
            match dispatch(&app, &ctx, Operation::Dns(DnsOp::Status))? {
                OperationResult::DnsStatus(value) => Ok(value),
                other => Err(unavailable(&ctx, format!("unexpected result for dns.status: {:?}", other))),
            }
        })
    }

    fn explain<'a>(&'a self, ctx: Ctx, request: DnsExplainRequest) -> BoxFuture<'a, ApiResult<DnsExplainResult>> {
        let app = Arc::clone(&self.app);
        Box::pin(async move {
            match dispatch(&app, &ctx, Operation::Dns(DnsOp::Explain { request }))? {
                OperationResult::DnsExplain(value) => Ok(value),
                other => Err(unavailable(&ctx, format!("unexpected result for dns.explain: {:?}", other))),
            }
        })
    }

    fn flush_cache<'a>(&'a self, ctx: Ctx) -> BoxFuture<'a, ApiResult<Accepted>> {
        let app = Arc::clone(&self.app);
        Box::pin(async move {
            match dispatch(&app, &ctx, Operation::Dns(DnsOp::FlushCache))? {
                OperationResult::Accepted(value) => Ok(value),
                other => Err(unavailable(&ctx, format!("unexpected result for dns.flush_cache: {:?}", other))),
            }
        })
    }
}

#[derive(Clone)]
struct LocalNetworkFacet {
    app: Arc<DaemonApp>,
}

impl NetworkFacet for LocalNetworkFacet {
    fn status<'a>(&'a self, ctx: Ctx) -> BoxFuture<'a, ApiResult<NetworkStatus>> {
        let app = Arc::clone(&self.app);
        Box::pin(async move {
            match dispatch(&app, &ctx, Operation::Network(NetworkOp::Status))? {
                OperationResult::NetworkStatus(value) => Ok(value),
                other => Err(unavailable(&ctx, format!("unexpected result for network.status: {:?}", other))),
            }
        })
    }

    fn inspect_plan<'a>(&'a self, ctx: Ctx, profile_id: ProfileId) -> BoxFuture<'a, ApiResult<NetworkPlanView>> {
        let app = Arc::clone(&self.app);
        Box::pin(async move {
            match dispatch(&app, &ctx, Operation::Network(NetworkOp::InspectPlan { profile_id }))? {
                OperationResult::NetworkPlan(value) => Ok(value),
                other => Err(unavailable(&ctx, format!("unexpected result for network.inspect_plan: {:?}", other))),
            }
        })
    }

    fn repair<'a>(&'a self, ctx: Ctx) -> BoxFuture<'a, ApiResult<Accepted>> {
        let app = Arc::clone(&self.app);
        Box::pin(async move {
            match dispatch(&app, &ctx, Operation::Network(NetworkOp::Repair))? {
                OperationResult::Accepted(value) => Ok(value),
                other => Err(unavailable(&ctx, format!("unexpected result for network.repair: {:?}", other))),
            }
        })
    }
}

#[derive(Clone)]
struct LocalCoreFacet {
    app: Arc<DaemonApp>,
}

impl CoreFacet for LocalCoreFacet {
    fn list_installs<'a>(&'a self, ctx: Ctx) -> BoxFuture<'a, ApiResult<Vec<CoreInstallView>>> {
        let app = Arc::clone(&self.app);
        Box::pin(async move {
            match dispatch(&app, &ctx, Operation::Core(CoreOp::ListInstalls))? {
                OperationResult::CoreInstallList(value) => Ok(value),
                other => Err(unavailable(&ctx, format!("unexpected result for core.list_installs: {:?}", other))),
            }
        })
    }

    fn inspect<'a>(&'a self, ctx: Ctx, core_install_id: CoreInstallId) -> BoxFuture<'a, ApiResult<CoreInspection>> {
        let app = Arc::clone(&self.app);
        Box::pin(async move {
            match dispatch(&app, &ctx, Operation::Core(CoreOp::Inspect { core_install_id }))? {
                OperationResult::CoreInspection(value) => Ok(value),
                other => Err(unavailable(&ctx, format!("unexpected result for core.inspect: {:?}", other))),
            }
        })
    }

    fn capabilities<'a>(&'a self, ctx: Ctx, query: CapabilityQuery) -> BoxFuture<'a, ApiResult<CapabilityReport>> {
        let app = Arc::clone(&self.app);
        Box::pin(async move {
            match dispatch(&app, &ctx, Operation::Core(CoreOp::Capabilities { query }))? {
                OperationResult::CapabilityReport(value) => Ok(value),
                other => Err(unavailable(&ctx, format!("unexpected result for core.capabilities: {:?}", other))),
            }
        })
    }
}

#[derive(Clone)]
struct LocalRuntimeFacet {
    app: Arc<DaemonApp>,
}

impl RuntimeFacet for LocalRuntimeFacet {
    fn status<'a>(&'a self, ctx: Ctx) -> BoxFuture<'a, ApiResult<RuntimeStatus>> {
        let app = Arc::clone(&self.app);
        Box::pin(async move {
            match dispatch(&app, &ctx, Operation::Runtime(RuntimeOp::Status))? {
                OperationResult::RuntimeStatus(value) => Ok(value),
                other => Err(unavailable(&ctx, format!("unexpected result for runtime.status: {:?}", other))),
            }
        })
    }

    fn connections<'a>(&'a self, ctx: Ctx, query: ConnectionQuery) -> BoxFuture<'a, ApiResult<ConnectionPage>> {
        let app = Arc::clone(&self.app);
        Box::pin(async move {
            match dispatch(&app, &ctx, Operation::Runtime(RuntimeOp::Connections { query }))? {
                OperationResult::ConnectionPage(value) => Ok(value),
                other => Err(unavailable(&ctx, format!("unexpected result for runtime.connections: {:?}", other))),
            }
        })
    }

    fn close_connection<'a>(&'a self, ctx: Ctx, connection_id: ConnectionId) -> BoxFuture<'a, ApiResult<Accepted>> {
        let app = Arc::clone(&self.app);
        Box::pin(async move {
            match dispatch(&app, &ctx, Operation::Runtime(RuntimeOp::CloseConnection { connection_id }))? {
                OperationResult::Accepted(value) => Ok(value),
                other => Err(unavailable(&ctx, format!("unexpected result for runtime.close_connection: {:?}", other))),
            }
        })
    }

    fn watch<'a>(&'a self, ctx: Ctx, subscription: RuntimeSubscription) -> BoxFuture<'a, ApiResult<WatchOpened>> {
        let app = Arc::clone(&self.app);
        Box::pin(async move {
            match dispatch(&app, &ctx, Operation::Runtime(RuntimeOp::Watch { subscription }))? {
                OperationResult::WatchOpened(value) => Ok(value),
                other => Err(unavailable(&ctx, format!("unexpected result for runtime.watch: {:?}", other))),
            }
        })
    }
}

#[derive(Clone)]
struct LocalDiagnosticsFacet {
    app: Arc<DaemonApp>,
}

impl DiagnosticsFacet for LocalDiagnosticsFacet {
    fn doctor<'a>(&'a self, ctx: Ctx, request: DoctorRequest) -> BoxFuture<'a, ApiResult<DoctorReport>> {
        let app = Arc::clone(&self.app);
        Box::pin(async move {
            match dispatch(&app, &ctx, Operation::Diagnostics(DiagnosticsOp::Doctor { request }))? {
                OperationResult::DoctorReport(value) => Ok(value),
                other => Err(unavailable(&ctx, format!("unexpected result for diagnostics.doctor: {:?}", other))),
            }
        })
    }

    fn explain_pipeline<'a>(&'a self, ctx: Ctx, request: PipelineExplainRequest) -> BoxFuture<'a, ApiResult<PipelineExplain>> {
        let app = Arc::clone(&self.app);
        Box::pin(async move {
            match dispatch(&app, &ctx, Operation::Diagnostics(DiagnosticsOp::ExplainPipeline { request }))? {
                OperationResult::PipelineExplain(value) => Ok(value),
                other => Err(unavailable(
                    &ctx,
                    format!("unexpected result for diagnostics.explain_pipeline: {:?}", other),
                )),
            }
        })
    }

    fn recovery_status<'a>(&'a self, ctx: Ctx) -> BoxFuture<'a, ApiResult<RecoveryStatusView>> {
        let app = Arc::clone(&self.app);
        Box::pin(async move {
            match dispatch(&app, &ctx, Operation::Diagnostics(DiagnosticsOp::RecoveryStatus))? {
                OperationResult::RecoveryStatus(value) => Ok(value),
                other => Err(unavailable(
                    &ctx,
                    format!("unexpected result for diagnostics.recovery_status: {:?}", other),
                )),
            }
        })
    }

    fn follow_job<'a>(&'a self, ctx: Ctx, request: JobFollowRequest) -> BoxFuture<'a, ApiResult<JobFollowView>> {
        let app = Arc::clone(&self.app);
        Box::pin(async move {
            match dispatch(&app, &ctx, Operation::Diagnostics(DiagnosticsOp::FollowJob { request }))? {
                OperationResult::JobFollow(value) => Ok(value),
                other => Err(unavailable(&ctx, format!("unexpected result for diagnostics.follow_job: {:?}", other))),
            }
        })
    }

    fn follow_job_stream<'a>(&'a self, ctx: Ctx, request: JobFollowRequest) -> BoxFuture<'a, ApiResult<WatchOpened>> {
        let app = Arc::clone(&self.app);
        Box::pin(async move {
            match dispatch(&app, &ctx, Operation::Diagnostics(DiagnosticsOp::FollowJobStream { request }))? {
                OperationResult::WatchOpened(value) => Ok(value),
                other => Err(unavailable(&ctx, format!("unexpected result for diagnostics.follow_job_stream: {:?}", other))),
            }
        })
    }

    fn support_bundle<'a>(&'a self, ctx: Ctx) -> BoxFuture<'a, ApiResult<Accepted>> {
        let app = Arc::clone(&self.app);
        Box::pin(async move {
            match dispatch(&app, &ctx, Operation::Diagnostics(DiagnosticsOp::SupportBundle))? {
                OperationResult::Accepted(value) => Ok(value),
                other => Err(unavailable(&ctx, format!("unexpected result for diagnostics.support_bundle: {:?}", other))),
            }
        })
    }
}

#[derive(Clone)]
struct LocalAutomationFacet {
    app: Arc<DaemonApp>,
}

impl AutomationFacet for LocalAutomationFacet {
    fn list_jobs<'a>(&'a self, ctx: Ctx) -> BoxFuture<'a, ApiResult<Vec<AutomationJobView>>> {
        let app = Arc::clone(&self.app);
        Box::pin(async move {
            match dispatch(&app, &ctx, Operation::Automation(AutomationOp::ListJobs))? {
                OperationResult::AutomationJobs(value) => Ok(value),
                other => Err(unavailable(&ctx, format!("unexpected result for automation.list_jobs: {:?}", other))),
            }
        })
    }

    fn patch_job<'a>(&'a self, ctx: Ctx, request: PatchAutomationJob) -> BoxFuture<'a, ApiResult<Accepted>> {
        let app = Arc::clone(&self.app);
        Box::pin(async move {
            match dispatch(&app, &ctx, Operation::Automation(AutomationOp::PatchJob { request }))? {
                OperationResult::Accepted(value) => Ok(value),
                other => Err(unavailable(&ctx, format!("unexpected result for automation.patch_job: {:?}", other))),
            }
        })
    }
}
