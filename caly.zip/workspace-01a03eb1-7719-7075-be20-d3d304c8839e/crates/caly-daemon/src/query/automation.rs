use caly_api::{OperationResult, RequestEnvelope};

use crate::app::DaemonApp;

use super::common::internal_query_error;

pub fn handle_automation(
    app: &DaemonApp,
    envelope: &RequestEnvelope,
    op: &caly_api::AutomationOp,
) -> Result<Option<OperationResult>, caly_api::ApiError> {
    match op {
        caly_api::AutomationOp::ListJobs => Ok(Some(OperationResult::AutomationJobs(
            app.automation_job_views()
                .map_err(|message| internal_query_error(envelope, message))?,
        ))),
        caly_api::AutomationOp::PatchJob { .. } => Ok(None),
    }
}
