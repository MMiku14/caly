use caly_api::{OperationResult, RequestEnvelope, ServerInfo, SystemStatus};

use crate::app::DaemonApp;

use super::common::internal_query_error;

pub fn handle_system(
    app: &DaemonApp,
    envelope: &RequestEnvelope,
    op: &caly_api::SystemOp,
) -> Result<Option<OperationResult>, caly_api::ApiError> {
    match op {
        caly_api::SystemOp::Status => {
            let runtime = app
                .runtime_snapshot()
                .map_err(|message| internal_query_error(envelope, message))?;
            Ok(Some(OperationResult::SystemStatus(SystemStatus {
                daemon_state: format!("{:?}", runtime.lifecycle).to_lowercase(),
                active_profile: runtime.active_profile,
                active_core: runtime.active_core,
                state_revision: runtime.state_revision,
            })))
        }
        caly_api::SystemOp::Info => {
            let runtime = app
                .runtime_snapshot()
                .map_err(|message| internal_query_error(envelope, message))?;
            Ok(Some(OperationResult::ServerInfo(ServerInfo {
                daemon_name: runtime.daemon_name,
                daemon_version: runtime.daemon_version,
                protocol_version: runtime.protocol_version,
                instance_id: runtime.instance_id,
            })))
        }
        caly_api::SystemOp::Shutdown => Ok(None),
    }
}
