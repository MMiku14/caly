use caly_api::{OperationResult, RequestEnvelope, RuntimeStatus};
use caly_engine::EngineLifecycle;

use crate::app::DaemonApp;

use super::common::internal_query_error;

pub fn handle_runtime(
    app: &DaemonApp,
    envelope: &RequestEnvelope,
    op: &caly_api::RuntimeOp,
) -> Result<Option<OperationResult>, caly_api::ApiError> {
    match op {
        caly_api::RuntimeOp::Status => {
            let runtime = app
                .runtime_snapshot()
                .map_err(|message| internal_query_error(envelope, message))?;
            Ok(Some(OperationResult::RuntimeStatus(RuntimeStatus {
                core_running: matches!(runtime.engine_lifecycle, EngineLifecycle::Busy),
                active_profile: runtime.active_profile,
                active_core: runtime.active_core,
                active_snapshot: runtime.active_snapshot,
                last_apply_plan_summary: runtime.last_apply_plan_summary,
                pending_recovery_decisions: runtime.pending_recovery_decisions,
                last_recovery_summary: runtime.last_recovery_summary,
                last_failure: runtime.last_error,
            })))
        }
        caly_api::RuntimeOp::Connections { query } => Ok(Some(OperationResult::ConnectionPage(
            app.connection_page(query.clone())
                .map_err(|message| internal_query_error(envelope, message))?,
        ))),
        caly_api::RuntimeOp::CloseConnection { .. } => Ok(None),
        caly_api::RuntimeOp::Watch { .. } => Ok(None),
    }
}
