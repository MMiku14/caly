use caly_api::{DoctorReport, OperationResult, RecoveryStatusView, RequestEnvelope};

use crate::app::DaemonApp;
use crate::state::DaemonLifecycle;

use super::common::internal_query_error;

pub fn handle_diagnostics(
    app: &DaemonApp,
    envelope: &RequestEnvelope,
    op: &caly_api::DiagnosticsOp,
) -> Result<Option<OperationResult>, caly_api::ApiError> {
    match op {
        caly_api::DiagnosticsOp::Doctor { request } => {
            let runtime = app
                .runtime_snapshot()
                .map_err(|message| internal_query_error(envelope, message))?;
            let recovery = app
                .recovery_scan()
                .map_err(|message| internal_query_error(envelope, message))?;
            let mut warnings = vec!["diagnostics pipeline is still partial; verify against real core runtime later".to_owned()];
            let mut errors = Vec::new();

            if request.include_runtime {
                warnings.push(format!(
                    "runtime active_profile={:?} active_snapshot={:?} pending_recovery_decisions={} engine_lifecycle={:?}",
                    runtime.active_profile, runtime.active_snapshot, runtime.pending_recovery_decisions, runtime.engine_lifecycle
                ));
                warnings.push(format!(
                    "recovery pending_apply={} pending_os={} decisions={}",
                    recovery.pending_apply_journals.len(),
                    recovery.pending_os_journals.len(),
                    recovery.decisions.len(),
                ));
            }

            for decision in &recovery.decisions {
                warnings.push(format!("recovery decision: {:?}", decision));
            }

            if matches!(runtime.lifecycle, DaemonLifecycle::Failed)
                || recovery
                    .decisions
                    .iter()
                    .any(|decision| matches!(decision, caly_storage::RecoveryDecision::EnterFailedState { .. }))
            {
                errors.push("daemon recovery requires operator attention".to_owned());
            }

            Ok(Some(OperationResult::DoctorReport(DoctorReport {
                summary: if request.include_runtime {
                    "doctor with runtime + recovery inspection".to_owned()
                } else {
                    "doctor baseline inspection".to_owned()
                },
                warnings,
                errors,
            })))
        }
        caly_api::DiagnosticsOp::ExplainPipeline { request } => {
            Ok(Some(OperationResult::PipelineExplain(
                caly_engine::explain_pipeline(request.clone())
                    .map_err(|message| internal_query_error(envelope, message))?,
            )))
        }
        caly_api::DiagnosticsOp::RecoveryStatus => {
            let runtime = app
                .runtime_snapshot()
                .map_err(|message| internal_query_error(envelope, message))?;
            let recovery = app
                .recovery_scan()
                .map_err(|message| internal_query_error(envelope, message))?;
            Ok(Some(OperationResult::RecoveryStatus(RecoveryStatusView {
                daemon_lifecycle: format!("{:?}", runtime.lifecycle).to_lowercase(),
                active_profile: runtime.active_profile,
                active_core: runtime.active_core,
                active_snapshot: runtime.active_snapshot,
                last_apply_plan_summary: runtime.last_apply_plan_summary,
                pending_apply_count: recovery.pending_apply_journals.len(),
                pending_os_count: recovery.pending_os_journals.len(),
                decision_count: recovery.decisions.len(),
                decisions: recovery
                    .decisions
                    .iter()
                    .map(|decision| format!("{:?}", decision))
                    .collect(),
                last_recovery_summary: runtime.last_recovery_summary,
            })))
        }
        caly_api::DiagnosticsOp::FollowJob { request } => {
            let projection = app
                .follow_job_projection(request.job_id, request.from_event_index)
                .map_err(|message| internal_query_error(envelope, message))?;
            Ok(projection.map(|projection| OperationResult::JobFollow(projection.summary)))
        }
        caly_api::DiagnosticsOp::FollowJobStream { .. }
        | caly_api::DiagnosticsOp::SupportBundle => Ok(None),
    }
}
