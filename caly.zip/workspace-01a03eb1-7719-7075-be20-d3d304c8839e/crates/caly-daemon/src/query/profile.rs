use caly_api::{OperationResult, RequestEnvelope};
use caly_engine::deployment_plan_view;

use crate::app::DaemonApp;

use super::common::internal_query_error;

pub fn handle_profile(
    app: &DaemonApp,
    envelope: &RequestEnvelope,
    op: &caly_api::ProfileOp,
) -> Result<Option<OperationResult>, caly_api::ApiError> {
    match op {
        caly_api::ProfileOp::List => Ok(Some(OperationResult::ProfileList(
            app.profile_summaries()
                .map_err(|message| internal_query_error(envelope, message))?,
        ))),
        caly_api::ProfileOp::Get { profile_id } => Ok(Some(OperationResult::ProfileView(
            app.profile_view(profile_id.clone())
                .map_err(|message| internal_query_error(envelope, message))?,
        ))),
        caly_api::ProfileOp::Plan { request } => Ok(Some(OperationResult::DeploymentPlan(
            deployment_plan_view(request.clone())
                .map_err(|message| internal_query_error(envelope, message))?,
        ))),
        caly_api::ProfileOp::Apply { .. } | caly_api::ProfileOp::Rollback { .. } => Ok(None),
    }
}
