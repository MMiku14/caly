use caly_api::{OperationResult, RequestEnvelope};

use crate::app::DaemonApp;

use super::common::internal_query_error;

pub fn handle_proxy(
    app: &DaemonApp,
    envelope: &RequestEnvelope,
    op: &caly_api::ProxyOp,
) -> Result<Option<OperationResult>, caly_api::ApiError> {
    match op {
        caly_api::ProxyOp::Nodes { query } => Ok(Some(OperationResult::NodePage(
            app.node_page(query.clone())
                .map_err(|message| internal_query_error(envelope, message))?,
        ))),
        caly_api::ProxyOp::Groups => Ok(Some(OperationResult::GroupList(
            app.group_views()
                .map_err(|message| internal_query_error(envelope, message))?,
        ))),
        caly_api::ProxyOp::Select { .. } | caly_api::ProxyOp::TestDelay { .. } => Ok(None),
    }
}
