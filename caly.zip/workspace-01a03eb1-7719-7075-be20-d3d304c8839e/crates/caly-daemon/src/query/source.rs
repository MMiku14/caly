use caly_api::{OperationResult, RequestEnvelope};

use crate::app::DaemonApp;

use super::common::internal_query_error;

pub fn handle_source(
    app: &DaemonApp,
    envelope: &RequestEnvelope,
    op: &caly_api::SourceOp,
) -> Result<Option<OperationResult>, caly_api::ApiError> {
    match op {
        caly_api::SourceOp::List => Ok(Some(OperationResult::SourceList(
            app.source_summaries()
                .map_err(|message| internal_query_error(envelope, message))?,
        ))),
        caly_api::SourceOp::Inspect { source_id } => Ok(Some(OperationResult::SourceInspection(
            app.source_inspection(source_id.clone())
                .map_err(|message| internal_query_error(envelope, message))?,
        ))),
        caly_api::SourceOp::Preview { request } => Ok(Some(OperationResult::SourcePreview(
            app.source_preview(request.clone())
                .map_err(|message| internal_query_error(envelope, message))?,
        ))),
        caly_api::SourceOp::Update { .. } => Ok(None),
    }
}
