use caly_api::{OperationResult, RequestEnvelope};

use crate::app::DaemonApp;

use super::common::internal_query_error;

pub fn handle_dns(
    app: &DaemonApp,
    envelope: &RequestEnvelope,
    op: &caly_api::DnsOp,
) -> Result<Option<OperationResult>, caly_api::ApiError> {
    match op {
        caly_api::DnsOp::Status => Ok(Some(OperationResult::DnsStatus(
            app.dns_status()
                .map_err(|message| internal_query_error(envelope, message))?,
        ))),
        caly_api::DnsOp::Explain { request } => Ok(Some(OperationResult::DnsExplain(
            app.dns_explain(request.clone())
                .map_err(|message| internal_query_error(envelope, message))?,
        ))),
        caly_api::DnsOp::FlushCache => Ok(None),
    }
}
