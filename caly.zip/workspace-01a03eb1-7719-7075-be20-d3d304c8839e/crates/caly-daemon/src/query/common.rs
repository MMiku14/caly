use caly_api::{ApiError, ErrorCategory, ErrorCode, RequestEnvelope};

pub fn internal_query_error(envelope: &RequestEnvelope, summary: impl Into<String>) -> ApiError {
    ApiError::new(
        ErrorCode::Unavailable,
        ErrorCategory::Internal,
        true,
        summary,
        envelope.trace_id.clone(),
    )
}
