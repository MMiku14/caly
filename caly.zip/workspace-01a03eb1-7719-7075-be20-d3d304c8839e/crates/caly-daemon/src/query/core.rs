use caly_api::{OperationResult, RequestEnvelope};
use caly_engine::capability_report_for_query;

use crate::app::DaemonApp;

use super::common::internal_query_error;

pub fn handle_core(
    app: &DaemonApp,
    envelope: &RequestEnvelope,
    op: &caly_api::CoreOp,
) -> Result<Option<OperationResult>, caly_api::ApiError> {
    match op {
        caly_api::CoreOp::ListInstalls => Ok(Some(OperationResult::CoreInstallList(
            app.core_install_views()
                .map_err(|message| internal_query_error(envelope, message))?,
        ))),
        caly_api::CoreOp::Inspect { core_install_id } => Ok(Some(OperationResult::CoreInspection(
            app.core_inspection(core_install_id.clone())
                .map_err(|message| internal_query_error(envelope, message))?,
        ))),
        caly_api::CoreOp::Capabilities { query } => Ok(Some(OperationResult::CapabilityReport(
            capability_report_for_query(query.clone())
                .map_err(|message| internal_query_error(envelope, message))?,
        ))),
    }
}
