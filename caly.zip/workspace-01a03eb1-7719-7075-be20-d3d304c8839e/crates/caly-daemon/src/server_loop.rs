use caly_common::Actor;
use caly_ipc::{
    classify_client_frame, classify_server_frame, decode_raw_json, encode_raw_json, make_header,
    ClientFrame, ClientHello, ClientSessionConfig, Compression, EncodedFrame, Encoding, FrameType,
    NegotiationPolicy, ServerFrame, SessionCloseReason,
};

use crate::bootstrap::DaemonBootstrapConfig;
use crate::runtime::DaemonRuntime;
use crate::transport::TransportStepOutput;

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct ServerLoopConfig {
    pub actor: Actor,
    pub daemon: DaemonBootstrapConfig,
    pub negotiation: NegotiationPolicy,
    pub hello_timeout_ms: u64,
}

impl Default for ServerLoopConfig {
    fn default() -> Self {
        Self {
            actor: Actor::Cli,
            daemon: DaemonBootstrapConfig {
                instance_id: "server-loop-daemon".to_owned(),
                protocol_version: caly_api::ProtocolVersion { major: 1, minor: 0 },
                recover_on_start: false,
            },
            negotiation: NegotiationPolicy::default(),
            hello_timeout_ms: 5_000,
        }
    }
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct ServerLoopSnapshot {
    pub session_count: usize,
    pub session_ids: Vec<String>,
    pub daemon_lifecycle: String,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub enum ServerLoopStep {
    HelloAck(EncodedFrame),
    ResponseFrames(Vec<EncodedFrame>),
    StreamFrames(Vec<EncodedFrame>),
    Closed(SessionCloseReason),
}

pub struct ServerLoop {
    pub runtime: DaemonRuntime,
    pub actor: Actor,
}

impl ServerLoop {
    pub fn new(config: ServerLoopConfig) -> Self {
        Self {
            runtime: DaemonRuntime::new(
                config.daemon,
                crate::registry::SessionRegistryConfig {
                    negotiation: config.negotiation,
                    hello_timeout_ms: config.hello_timeout_ms,
                },
            ),
            actor: config.actor,
        }
    }

    pub fn open_session(&mut self, session_id: impl Into<String>) -> String {
        self.runtime.open_session(self.actor, session_id)
    }

    pub fn handshake(
        &mut self,
        session_id: &str,
        client_name: impl Into<String>,
    ) -> Result<ServerLoopStep, String> {
        let hello = ClientHello {
            protocol: caly_api::ProtocolVersion { major: 1, minor: 0 },
            client_kind: caly_ipc::ClientKind::Cli,
            client_name: client_name.into(),
            requested_encoding: Encoding::Json,
            requested_compression: Compression::None,
            supported_features: vec![
                "query-command-stream".to_owned(),
                "job-follow".to_owned(),
                "reset".to_owned(),
            ],
            role: caly_api::Role::Admin,
        };
        let header = make_header(0, Encoding::Json, Compression::None);
        let output = self.runtime.handle_hello(session_id, header, hello)?;
        self.encode_transport_step(output)
    }

    pub fn send_client_frame(
        &mut self,
        session_id: &str,
        frame: ClientFrame,
    ) -> Result<ServerLoopStep, String> {
        let header = make_header(0, Encoding::Json, Compression::None);
        let is_control = matches!(classify_client_frame(&frame), FrameType::Request | FrameType::StreamAck);
        let output = self
            .runtime
            .handle_client_frame(session_id, header, frame, is_control)?;
        self.encode_transport_step(output)
    }

    pub fn hello_timeout(&mut self, session_id: &str) -> Result<ServerLoopStep, String> {
        let output = self.runtime.hello_timeout(session_id)?;
        self.encode_transport_step(output)
    }

    pub fn pull_stream(
        &mut self,
        session_id: &str,
        stream_id: caly_api::StreamId,
        from_seq_exclusive: Option<u64>,
    ) -> Result<ServerLoopStep, String> {
        let output = self.runtime.pull_stream(session_id, stream_id, from_seq_exclusive)?;
        self.encode_transport_step(output)
    }

    pub fn close_session(
        &mut self,
        session_id: &str,
        reason: SessionCloseReason,
    ) -> Result<ServerLoopStep, String> {
        let output = self.runtime.close_session(session_id, reason)?;
        self.encode_transport_step(output)
    }

    pub fn inspect(&self) -> ServerLoopSnapshot {
        let runtime = self.runtime.app.runtime_snapshot().ok();
        let sessions = self.runtime.snapshot();
        ServerLoopSnapshot {
            session_count: sessions.session_count,
            session_ids: sessions.session_ids,
            daemon_lifecycle: runtime
                .map(|it| format!("{:?}", it.lifecycle).to_lowercase())
                .unwrap_or_else(|| "unknown".to_owned()),
        }
    }

    pub fn probe_json_roundtrip(&self, json: &str) -> Result<String, String> {
        let encoded = encode_raw_json(json, Encoding::Json, Compression::None);
        decode_raw_json(&encoded).map_err(|error| error.summary)
    }

    fn encode_transport_step(&self, output: TransportStepOutput) -> Result<ServerLoopStep, String> {
        match output {
            TransportStepOutput::HelloAck(ack) => {
                let payload = format!(
                    "{{\"daemon_name\":\"{}\",\"daemon_version\":\"{}\",\"instance_id\":\"{}\"}}",
                    ack.daemon_name, ack.daemon_version, ack.instance_id
                );
                Ok(ServerLoopStep::HelloAck(encode_raw_json(
                    &payload,
                    ack.selected_encoding,
                    ack.selected_compression,
                )))
            }
            TransportStepOutput::ResponseFrames(frames) => Ok(ServerLoopStep::ResponseFrames(
                self.encode_server_frames(frames),
            )),
            TransportStepOutput::StreamFrames(frames) => Ok(ServerLoopStep::StreamFrames(
                self.encode_server_frames(frames),
            )),
            TransportStepOutput::Closed(reason) => Ok(ServerLoopStep::Closed(reason)),
        }
    }

    fn encode_server_frames(&self, frames: Vec<ServerFrame>) -> Vec<EncodedFrame> {
        let mut encoded = Vec::new();
        for frame in frames {
            let frame_type = classify_server_frame(&frame);
            let payload = format!("{{\"frame_type\":\"{:?}\"}}", frame_type);
            encoded.push(encode_raw_json(&payload, Encoding::Json, Compression::None));
        }
        encoded
    }
}

pub fn default_client_session_config() -> ClientSessionConfig {
    ClientSessionConfig::default()
}
