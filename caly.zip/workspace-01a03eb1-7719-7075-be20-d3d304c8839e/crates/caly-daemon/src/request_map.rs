use caly_api::{Operation, RequestEnvelope, Role};
use caly_common::{Actor, RequestContext};
use caly_engine::{Command, CommandId, CommandKind};

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct RequestMapError {
    pub summary: String,
}

pub fn role_satisfies(actual: Role, required: Role) -> bool {
    fn rank(role: Role) -> u8 {
        match role {
            Role::Viewer => 0,
            Role::Operator => 1,
            Role::Admin => 2,
            Role::PrivilegedBroker => 3,
        }
    }

    rank(actual) >= rank(required)
}

pub fn map_request_to_command(actor: Actor, envelope: &RequestEnvelope) -> Result<Option<Command>, RequestMapError> {
    let required = envelope.operation.meta().required_role;
    if !role_satisfies(envelope.role, required) {
        return Err(RequestMapError {
            summary: format!(
                "request role {:?} does not satisfy required role {:?}",
                envelope.role, required
            ),
        });
    }

    let kind = match &envelope.operation {
        Operation::System(op) => match op {
            caly_api::SystemOp::Shutdown => Some(CommandKind::SystemShutdown),
            _ => None,
        },
        Operation::Profile(op) => match op {
            caly_api::ProfileOp::Apply { request } => Some(CommandKind::ProfileApply(request.clone())),
            caly_api::ProfileOp::Rollback { request } => {
                Some(CommandKind::ProfileRollback(request.clone()))
            }
            _ => None,
        },
        Operation::Source(op) => match op {
            caly_api::SourceOp::Update { source_id } => Some(CommandKind::SourceUpdate {
                source_id: source_id.0.clone(),
            }),
            _ => None,
        },
        Operation::Proxy(op) => match op {
            caly_api::ProxyOp::Select { request } => Some(CommandKind::ProxySelect {
                group_id: request.group_id.0.clone(),
                node_id: request.node_id.0.clone(),
            }),
            caly_api::ProxyOp::TestDelay { request } => Some(CommandKind::ProxyTestDelay {
                node_ids: request.node_ids.iter().map(|node_id| node_id.0.clone()).collect(),
            }),
            _ => None,
        },
        Operation::Dns(op) => match op {
            caly_api::DnsOp::FlushCache => Some(CommandKind::DnsFlushCache),
            _ => None,
        },
        Operation::Network(op) => match op {
            caly_api::NetworkOp::Repair => Some(CommandKind::NetworkRepair),
            _ => None,
        },
        Operation::Runtime(op) => match op {
            caly_api::RuntimeOp::CloseConnection { connection_id } => {
                Some(CommandKind::RuntimeCloseConnection {
                    connection_id: connection_id.0.clone(),
                })
            }
            _ => None,
        },
        Operation::Routing(_) => None,
        Operation::Core(_) => None,
        Operation::Diagnostics(op) => match op {
            caly_api::DiagnosticsOp::SupportBundle => Some(CommandKind::DiagnosticsBundle),
            _ => None,
        },
        Operation::Automation(op) => match op {
            caly_api::AutomationOp::PatchJob { request } => Some(CommandKind::AutomationPatch(request.clone())),
            _ => None,
        },
    };

    Ok(kind.map(|kind| Command {
        id: CommandId(format!("req-{}", envelope.request_id.0)),
        request_id: Some(envelope.request_id),
        actor,
        context: RequestContext {
            trace_id: envelope.trace_id.clone(),
            actor,
            deadline_ms: envelope.deadline_ms,
            expected_revision: envelope.expected_revision,
            io_budget: caly_common::IoBudget::unlimited(),
        },
        timeout_ms: envelope.deadline_ms,
        idempotency_key: envelope.idempotency_key.clone().map(caly_engine::IdempotencyKey),
        kind,
    }))
}
