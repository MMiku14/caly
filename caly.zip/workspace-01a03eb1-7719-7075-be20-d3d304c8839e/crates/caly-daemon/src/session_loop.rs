use caly_ipc::{
    close_session, ensure_active_session, ensure_awaiting_hello, handle_hello_timeout,
    snapshot_session_state, SessionLoopError, SessionLoopErrorCode, SessionLoopInput,
    SessionLoopOutput,
};

use crate::app::DaemonApp;
use crate::session::DaemonSession;

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct SessionRuntimeConfig {
    pub session_id: String,
    pub hello_timeout_ms: u64,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct SessionStepReport {
    pub summary: String,
    pub state: caly_ipc::SessionStateSnapshot,
}

pub fn handle_session_input(
    session: &mut DaemonSession,
    app: &DaemonApp,
    config: &SessionRuntimeConfig,
    input: SessionLoopInput,
) -> Result<SessionLoopOutput, SessionLoopError> {
    match input {
        SessionLoopInput::Hello { header, hello } => {
            session
                .validate_frame(&header, true)
                .map_err(|error| SessionLoopError {
                    code: SessionLoopErrorCode::FrameInvalid,
                    summary: error.summary,
                })?;
            ensure_awaiting_hello(&session.machine)?;
            let ack = session
                .accept_hello(app, &hello, config.session_id.clone())
                .map_err(|error| SessionLoopError {
                    code: SessionLoopErrorCode::RequestInvalid,
                    summary: error.summary,
                })?;
            Ok(SessionLoopOutput::HelloAck(ack))
        }
        SessionLoopInput::ClientFrame {
            header,
            frame,
            is_control_message,
        } => {
            ensure_active_session(&session.machine)?;
            session
                .validate_frame(&header, is_control_message)
                .map_err(|error| SessionLoopError {
                    code: SessionLoopErrorCode::FrameInvalid,
                    summary: error.summary,
                })?;
            let frames = session
                .handle_client_frame(app, &frame)
                .map_err(|summary| SessionLoopError {
                    code: SessionLoopErrorCode::RequestInvalid,
                    summary,
                })?;
            Ok(SessionLoopOutput::Frames(frames))
        }
        SessionLoopInput::HelloTimeoutExpired => handle_hello_timeout(&mut session.machine),
        SessionLoopInput::Close { reason } => Ok(close_session(&mut session.machine, reason)),
    }
}

pub fn inspect_session(session: &DaemonSession) -> SessionStepReport {
    let snapshot = snapshot_session_state(&session.machine);
    SessionStepReport {
        summary: format!(
            "session state={:?} can_accept_hello={} can_accept_client_frames={}",
            snapshot.state, snapshot.can_accept_hello, snapshot.can_accept_client_frames,
        ),
        state: snapshot,
    }
}
