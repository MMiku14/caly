use std::sync::{Arc, Mutex};

use caly_api::{
    ApiError, ApplyRequest, AutomationJobView, ConnectionPage, ConnectionQuery, ConnectionView,
    CoreInspection, CoreInstallId, CoreInstallView, DnsExplainRequest, DnsExplainResult,
    DnsStatus, GroupView, JobFollowRequest, JobId, NetworkPlanView, NodePage, NodeQuery,
    NodeView, PatchAutomationJob, ProfileId, ProfileSummary, ProfileView, RequestEnvelope,
    ResponseEnvelope, RouteExplainRequest, RouteExplainResult, RoutingValidation, RulePage,
    RuleQuery, RuleView, RuntimeSubscription, SourceId, SourceInspection, SourcePreview,
    SourcePreviewRequest, SourceSummary,
};
use caly_common::{Actor, TraceId};
use caly_engine::{
    plan_apply_request, Command, CommandId, EngineHandle, EventWindow, JobFollowProjection,
    JobOutcome, SubmitFailure, WorkerPolicy,
};
use caly_storage::{ApplyPhase, RecoveryScanReport, SnapshotRecord};
use caly_ipc::DispatchTarget;

use crate::bootstrap::{bootstrap, DaemonBootstrapConfig};
use crate::error_map::map_overload_report;
use crate::request_map::{map_request_to_command, RequestMapError};
use crate::state::{DaemonLifecycle, DaemonRuntimeState};
use crate::stream::{subscription_kind_name, OpenedStream};

const DEFAULT_PROFILE_ID: &str = "default-profile";
const DEFAULT_PROFILE_LABEL: &str = "Default Profile";
const DEFAULT_CORE_KIND: &str = "mihomo";
const DEFAULT_CORE_VERSION: &str = "0.1.0-dev";
const DEFAULT_BINARY_DIGEST: &str = "mock-core-binary";

#[derive(Clone)]
pub struct DaemonApp {
    runtime: Arc<Mutex<DaemonRuntimeState>>,
    engine: EngineHandle,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct SubmitCommandResponse {
    pub job_id: u64,
    pub reused_existing_job: bool,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct EventFollowResponse {
    pub next_seq: u64,
    pub retained_from: u64,
    pub reset_required: bool,
    pub event_count: usize,
}

impl DaemonApp {
    pub fn bootstrap(config: DaemonBootstrapConfig) -> Self {
        let recover_on_start = config.recover_on_start;
        let boot = bootstrap(config);
        let app = Self {
            runtime: Arc::new(Mutex::new(boot.runtime)),
            engine: EngineHandle::new(boot.engine),
        };
        if recover_on_start {
            let _ = app.recovery_scan().and_then(|report| app.apply_recovery_snapshot(&report));
        }
        app
    }

    pub fn runtime_snapshot(&self) -> Result<DaemonRuntimeState, String> {
        self.runtime
            .lock()
            .map(|guard| guard.clone())
            .map_err(|_| "daemon runtime lock poisoned".to_owned())
    }

    pub fn set_running(&self) -> Result<(), String> {
        let mut guard = self
            .runtime
            .lock()
            .map_err(|_| "daemon runtime lock poisoned".to_owned())?;
        guard.lifecycle = DaemonLifecycle::Running;
        Ok(())
    }

    fn sync_runtime_from_engine(&self) -> Result<(), String> {
        let snapshot = self.engine.snapshot()?;
        let mut runtime = self
            .runtime
            .lock()
            .map_err(|_| "daemon runtime lock poisoned".to_owned())?;
        runtime.engine_lifecycle = snapshot.current_lifecycle();
        runtime.state_revision = snapshot.generation;
        let latest_snapshot = self.engine.latest_last_known_good_snapshot().ok().flatten();
        runtime.active_profile = latest_snapshot
            .as_ref()
            .map(|snapshot| caly_api::ProfileId(snapshot.profile_id.clone()));
        runtime.active_core = latest_snapshot.as_ref().map(|snapshot| snapshot.core_identity.clone());
        runtime.last_apply_plan_summary = latest_snapshot
            .as_ref()
            .map(|snapshot| snapshot.apply_plan_summary.clone());
        runtime.active_snapshot = latest_snapshot.map(|snapshot| snapshot.id.0);
        Ok(())
    }

    pub fn submit_engine_command(&self, command: Command) -> Result<SubmitCommandResponse, ApiError> {
        let trace_id = command.context.trace_id.clone();
        let result = self.engine.submit_checked(command).map_err(|failure| match failure {
            SubmitFailure::Overload(report) => map_overload_report(trace_id, report),
            SubmitFailure::Internal(message) => ApiError::new(
                caly_api::ErrorCode::Unavailable,
                caly_api::ErrorCategory::Internal,
                true,
                message,
                trace_id,
            ),
        })?;
        self.sync_runtime_from_engine().map_err(|message| {
            ApiError::new(
                caly_api::ErrorCode::Unavailable,
                caly_api::ErrorCategory::Internal,
                true,
                message,
                TraceId::new("daemon-sync-runtime"),
            )
        })?;
        Ok(SubmitCommandResponse {
            job_id: result.accepted.job_id.0,
            reused_existing_job: result.reused_existing_job,
        })
    }

    pub fn submit_request_as_command(
        &self,
        actor: Actor,
        envelope: &RequestEnvelope,
    ) -> Result<Option<SubmitCommandResponse>, ApiError> {
        let command = match map_request_to_command(actor, envelope) {
            Ok(value) => value,
            Err(RequestMapError { summary }) => {
                return Err(ApiError::new(
                    caly_api::ErrorCode::Permission,
                    caly_api::ErrorCategory::User,
                    false,
                    summary,
                    envelope.trace_id.clone(),
                ));
            }
        };

        let Some(command) = command else {
            return Ok(None);
        };

        self.submit_engine_command(command).map(Some)
    }

    pub fn drain_engine_once(&self) -> Result<usize, String> {
        let report = self.engine.drain_with_policy(WorkerPolicy::bounded(1))?;
        self.sync_runtime_from_engine()?;
        Ok(report.cycles)
    }

    pub fn recovery_scan(&self) -> Result<RecoveryScanReport, String> {
        self.engine.scan_recovery_state()
    }

    pub fn seed_recovery_fixture(
        &self,
        profile_id: impl Into<String>,
    ) -> Result<RecoveryScanReport, String> {
        let profile_id = profile_id.into();
        let workflow = plan_apply_request(ApplyRequest {
            profile_id: ProfileId(profile_id.clone()),
            dry_run: false,
            strict: false,
        })?;
        let persisted = self
            .engine
            .begin_apply_persistence(workflow.storage_projection.clone())?;
        let cutover = self
            .engine
            .advance_apply_phase(&persisted.journal, ApplyPhase::Cutover, workflow.effect_steps.len().max(1), 1)?;
        let _ = cutover;
        let report = self.engine.scan_recovery_state()?;
        self.apply_recovery_snapshot(&report)?;
        Ok(report)
    }

    pub fn latest_last_known_good_snapshot(&self) -> Result<Option<SnapshotRecord>, String> {
        self.engine.latest_last_known_good_snapshot()
    }

    pub fn latest_last_known_good_snapshot_id(&self) -> Result<Option<String>, String> {
        Ok(self.latest_last_known_good_snapshot()?.map(|snapshot| snapshot.id.0))
    }

    pub fn apply_recovery_snapshot(&self, report: &RecoveryScanReport) -> Result<(), String> {
        for decision in &report.decisions {
            self.engine.push_event(
                caly_engine::EventKind::RecoveryDecision,
                None,
                caly_engine::EventPayload::RecoveryDecision {
                    summary: format!("{:?}", decision),
                },
            )?;
        }
        if let Some(snapshot_id) = &report.latest_last_known_good {
            self.engine.push_event(
                caly_engine::EventKind::JournalRecovered,
                None,
                caly_engine::EventPayload::JournalRecovered {
                    journal_id: format!("lkg:{}", snapshot_id.0),
                },
            )?;
        }

        let mut runtime = self
            .runtime
            .lock()
            .map_err(|_| "daemon runtime lock poisoned".to_owned())?;
        runtime.active_snapshot = report.latest_last_known_good.clone().map(|value| value.0);
        if report.latest_last_known_good.is_none() {
            runtime.active_profile = None;
            runtime.active_core = None;
            runtime.last_apply_plan_summary = None;
        }
        runtime.pending_recovery_decisions = report.decisions.len();
        runtime.last_recovery_summary = if report.decisions.is_empty() {
            Some("recovery scan clean".to_owned())
        } else {
            Some(format!("recovery decisions={}", report.decisions.len()))
        };
        runtime.lifecycle = if report.decisions.is_empty() {
            DaemonLifecycle::Starting
        } else {
            DaemonLifecycle::Recovering
        };
        Ok(())
    }

    pub fn poll_and_complete_one_for_demo(&self) -> Result<Option<u64>, String> {
        let queued = match self.engine.poll_next()? {
            Some(value) => value,
            None => return Ok(None),
        };
        self.engine.mark_running(&queued)?;
        self.engine.mark_finished(&queued, JobOutcome::Succeeded)?;
        self.sync_runtime_from_engine()?;
        Ok(Some(queued.job_id.0))
    }

    pub fn process_next_job(&self) -> Result<bool, String> {
        let cycles = self.drain_engine_once()?;
        Ok(cycles > 0)
    }

    pub fn event_window(&self, from_exclusive: Option<u64>) -> Result<EventWindow, String> {
        let window = self.engine.events_since(from_exclusive.map(caly_engine::EventSeq))?;
        self.sync_runtime_from_engine()?;
        Ok(window)
    }

    pub fn follow_events(&self, from_exclusive: Option<u64>) -> Result<EventFollowResponse, String> {
        let window = self.event_window(from_exclusive)?;
        Ok(EventFollowResponse {
            next_seq: window.next_seq,
            retained_from: window.retained_from.0,
            reset_required: window.reset_required,
            event_count: window.events.len(),
        })
    }

    pub fn follow_job_projection(
        &self,
        job_id: JobId,
        from_event_index: Option<u64>,
    ) -> Result<Option<JobFollowProjection>, String> {
        let projection = self.engine.project_job_follow(job_id, from_event_index)?;
        self.sync_runtime_from_engine()?;
        Ok(projection)
    }

    pub fn route_request(&self, envelope: &RequestEnvelope) -> DispatchTarget {
        caly_ipc::route_operation(&envelope.operation)
    }

    pub fn allocate_stream(&self, subscription: RuntimeSubscription) -> Result<OpenedStream, String> {
        let mut guard = self
            .runtime
            .lock()
            .map_err(|_| "daemon runtime lock poisoned".to_owned())?;
        let stream_id = guard.allocate_stream_id();
        Ok(OpenedStream {
            stream_id,
            subscription_kind: subscription_kind_name(subscription),
        })
    }

    pub fn allocate_job_stream(&self, request: JobFollowRequest) -> Result<OpenedStream, String> {
        let mut guard = self
            .runtime
            .lock()
            .map_err(|_| "daemon runtime lock poisoned".to_owned())?;
        let stream_id = guard.allocate_stream_id();
        Ok(OpenedStream {
            stream_id,
            subscription_kind: format!("job-follow:{}", request.job_id.0),
        })
    }

    pub fn profile_summaries(&self) -> Result<Vec<ProfileSummary>, String> {
        let runtime = self.runtime_snapshot()?;
        let mut items = vec![ProfileSummary {
            id: ProfileId(DEFAULT_PROFILE_ID.to_owned()),
            label: DEFAULT_PROFILE_LABEL.to_owned(),
            active: runtime.active_profile.as_ref().map(|value| value.0.as_str()) == Some(DEFAULT_PROFILE_ID),
        }];
        if let Some(active_profile) = runtime.active_profile {
            if active_profile.0 != DEFAULT_PROFILE_ID {
                items.push(ProfileSummary {
                    id: active_profile.clone(),
                    label: format!("Active Profile {}", active_profile.0),
                    active: true,
                });
            }
        }
        Ok(items)
    }

    pub fn profile_view(&self, profile_id: ProfileId) -> Result<ProfileView, String> {
        let runtime = self.runtime_snapshot()?;
        let active = runtime.active_profile.as_ref() == Some(&profile_id);
        Ok(ProfileView {
            summary: ProfileSummary {
                id: profile_id,
                label: if active {
                    "Active Profile".to_owned()
                } else {
                    DEFAULT_PROFILE_LABEL.to_owned()
                },
                active,
            },
            source_count: usize::from(active) + 1,
            core_target: runtime.active_core.unwrap_or_else(|| "auto".to_owned()),
        })
    }

    pub fn core_install_views(&self) -> Result<Vec<CoreInstallView>, String> {
        let runtime = self.runtime_snapshot()?;
        let active_kind = runtime
            .active_core
            .as_deref()
            .and_then(core_kind_from_identity)
            .unwrap_or(DEFAULT_CORE_KIND);
        let active_version = runtime
            .active_core
            .as_deref()
            .and_then(core_version_from_identity)
            .unwrap_or(DEFAULT_CORE_VERSION);
        Ok(vec![CoreInstallView {
            id: CoreInstallId(format!("{}-install", active_kind)),
            kind: active_kind.to_owned(),
            version: active_version.to_owned(),
            active: runtime.active_core.is_some(),
        }])
    }

    pub fn core_inspection(&self, core_install_id: CoreInstallId) -> Result<CoreInspection, String> {
        let snapshot = self.latest_last_known_good_snapshot()?;
        let runtime = self.runtime_snapshot()?;
        let install = if let Some(snapshot) = &snapshot {
            CoreInstallView {
                id: core_install_id,
                kind: core_kind_from_identity(&snapshot.core_identity)
                    .unwrap_or(DEFAULT_CORE_KIND)
                    .to_owned(),
                version: core_version_from_identity(&snapshot.core_identity)
                    .unwrap_or(DEFAULT_CORE_VERSION)
                    .to_owned(),
                active: true,
            }
        } else {
            CoreInstallView {
                id: core_install_id,
                kind: runtime
                    .active_core
                    .as_deref()
                    .and_then(core_kind_from_identity)
                    .unwrap_or(DEFAULT_CORE_KIND)
                    .to_owned(),
                version: runtime
                    .active_core
                    .as_deref()
                    .and_then(core_version_from_identity)
                    .unwrap_or(DEFAULT_CORE_VERSION)
                    .to_owned(),
                active: runtime.active_core.is_some(),
            }
        };

        Ok(CoreInspection {
            install,
            binary_digest: snapshot
                .map(|value| value.core_binary_digest)
                .unwrap_or_else(|| DEFAULT_BINARY_DIGEST.to_owned()),
        })
    }

    pub fn source_summaries(&self) -> Result<Vec<SourceSummary>, String> {
        let workflow = self.workflow_for_active_or_default_profile()?;
        Ok(workflow
            .resolved_sources
            .into_iter()
            .map(|source| SourceSummary {
                id: SourceId(source.id),
                label: source.label,
                kind: source.kind,
            })
            .collect())
    }

    pub fn source_inspection(&self, source_id: SourceId) -> Result<SourceInspection, String> {
        let workflow = self.workflow_for_active_or_default_profile()?;
        let source = workflow
            .resolved_sources
            .iter()
            .find(|source| source.id == source_id.0)
            .cloned()
            .unwrap_or(caly_engine::ResolvedSourceSummary {
                id: source_id.0.clone(),
                label: format!("Source {}", source_id.0),
                kind: "subscription".to_owned(),
            });
        Ok(SourceInspection {
            summary: SourceSummary {
                id: SourceId(source.id.clone()),
                label: source.label,
                kind: source.kind,
            },
            latest_digest: Some(format!("digest:{}", source.id)),
            warning_count: workflow.diagnostics.len() as u32,
        })
    }

    pub fn source_preview(&self, request: SourcePreviewRequest) -> Result<SourcePreview, String> {
        if let Some(inline_source) = request.inline_source {
            return Ok(SourcePreview {
                node_count: usize::from(!inline_source.trim().is_empty()),
                group_count: usize::from(!inline_source.trim().is_empty()),
                warnings: Vec::new(),
            });
        }

        let workflow = self.workflow_for_active_or_default_profile()?;
        let requested = request.source_id.map(|source_id| source_id.0);
        let included = workflow
            .resolved_sources
            .iter()
            .filter(|source| requested.as_ref().map(|value| value == &source.id).unwrap_or(true))
            .count();
        Ok(SourcePreview {
            node_count: workflow.resolved_nodes.len().min(included.max(1) * 2),
            group_count: workflow.resolved_groups.len().min(included.max(1) * 2),
            warnings: workflow.diagnostics.into_iter().take(4).collect(),
        })
    }

    pub fn node_page(&self, query: NodeQuery) -> Result<NodePage, String> {
        let workflow = self.workflow_for_active_or_default_profile()?;
        let filtered = workflow
            .resolved_nodes
            .into_iter()
            .filter(|node| {
                query
                    .group
                    .as_ref()
                    .map(|group_id| {
                        workflow
                            .resolved_groups
                            .iter()
                            .any(|group| group.id == group_id.0 && group.members.iter().any(|member| member == &node.id))
                    })
                    .unwrap_or(true)
            })
            .filter(|node| {
                query
                    .search
                    .as_ref()
                    .map(|search| node.label.to_ascii_lowercase().contains(&search.to_ascii_lowercase()))
                    .unwrap_or(true)
            })
            .map(|node| NodeView {
                id: caly_api::NodeId(node.id),
                label: node.label,
                protocol: node.protocol,
            })
            .collect::<Vec<_>>();
        paged_node_view(filtered, query.page, self.runtime_snapshot()?.state_revision)
    }

    pub fn group_views(&self) -> Result<Vec<GroupView>, String> {
        let workflow = self.workflow_for_active_or_default_profile()?;
        Ok(workflow
            .resolved_groups
            .into_iter()
            .map(|group| GroupView {
                id: caly_api::GroupId(group.id),
                label: group.label,
                selected: group.selected.map(caly_api::NodeId),
            })
            .collect())
    }

    pub fn rule_page(&self, query: RuleQuery) -> Result<RulePage, String> {
        let workflow = self.workflow_for_active_or_default_profile()?;
        let items = workflow
            .resolved_rules
            .into_iter()
            .map(|rule| RuleView {
                id: rule.id,
                label: format!("{} [{}]", rule.label, rule.action),
            })
            .collect::<Vec<_>>();
        paged_rule_view(items, query.page, self.runtime_snapshot()?.state_revision)
    }

    pub fn route_explain(&self, request: RouteExplainRequest) -> Result<RouteExplainResult, String> {
        let workflow = self.workflow_for_active_or_default_profile()?;
        let matched = workflow
            .resolved_rules
            .iter()
            .find(|rule| {
                rule.label.to_ascii_lowercase().contains(&request.target.to_ascii_lowercase())
                    || rule
                        .target
                        .as_ref()
                        .map(|target| target.to_ascii_lowercase().contains(&request.target.to_ascii_lowercase()))
                        .unwrap_or(false)
            })
            .or_else(|| workflow.resolved_rules.first());

        Ok(RouteExplainResult {
            matched_rule: matched.map(|rule| rule.label.clone()),
            action: matched
                .map(|rule| rule.action.clone())
                .unwrap_or_else(|| "direct".to_owned()),
        })
    }

    pub fn routing_validation(&self, profile_id: ProfileId) -> Result<RoutingValidation, String> {
        let workflow = self.workflow_for_profile(profile_id)?;
        let warning_count = workflow
            .diagnostics
            .iter()
            .filter(|line| line.to_ascii_lowercase().contains("routing") || line.to_ascii_lowercase().contains("rule"))
            .count() as u32;
        Ok(RoutingValidation {
            warning_count,
            error_count: workflow.capability.blocked_count as u32,
        })
    }

    pub fn dns_status(&self) -> Result<DnsStatus, String> {
        let workflow = self.workflow_for_active_or_default_profile()?;
        Ok(DnsStatus {
            fake_ip_enabled: workflow
                .resolved_network
                .dns_mode
                .as_deref()
                .map(|value| matches!(value, "fake-ip" | "mixed"))
                .unwrap_or(false),
            cache_entries: 0,
        })
    }

    pub fn dns_explain(&self, request: DnsExplainRequest) -> Result<DnsExplainResult, String> {
        let workflow = self.workflow_for_active_or_default_profile()?;
        let resolved_via = workflow
            .resolved_network
            .dns_servers
            .first()
            .cloned()
            .or(workflow.resolved_network.dns_mode.clone())
            .unwrap_or_else(|| "system".to_owned());
        Ok(DnsExplainResult {
            resolved_via: format!("{} via {}", request.domain_or_ip, resolved_via),
            outbound: workflow.resolved_groups.first().map(|group| group.label.clone()),
        })
    }

    pub fn network_plan_view(&self, profile_id: ProfileId) -> Result<NetworkPlanView, String> {
        let workflow = self.workflow_for_profile(profile_id)?;
        Ok(NetworkPlanView {
            summary: format!(
                "apply={} steps={} warnings={}",
                workflow.apply_plan_kind,
                workflow.effect_steps.len(),
                workflow.diagnostics.len()
            ),
            requires_privilege: workflow.effect_steps.iter().any(|step| step.contains("net-apply")),
        })
    }

    pub fn connection_page(&self, query: ConnectionQuery) -> Result<ConnectionPage, String> {
        let workflow = self.workflow_for_active_or_default_profile()?;
        let items = workflow
            .resolved_nodes
            .into_iter()
            .map(|node| ConnectionView {
                id: caly_api::ConnectionId(format!("conn-{}", node.id)),
                destination: format!("{}://{}", node.protocol, node.label),
                process: Some(workflow.resolved.profile_id.clone()),
            })
            .collect::<Vec<_>>();
        paged_connection_view(items, query.page, self.runtime_snapshot()?.state_revision)
    }

    pub fn automation_job_views(&self) -> Result<Vec<AutomationJobView>, String> {
        let runtime = self.runtime_snapshot()?;
        let profile_id = runtime
            .active_profile
            .clone()
            .unwrap_or_else(|| ProfileId(DEFAULT_PROFILE_ID.to_owned()));
        let overrides = self.engine.automation_overrides()?;
        let override_map = overrides.into_iter().collect::<std::collections::BTreeMap<_, _>>();

        let defaults = vec![
            AutomationJobView {
                id: format!("automation.apply:{}", profile_id.0),
                label: format!("Auto apply {}", profile_id.0),
                enabled: true,
            },
            AutomationJobView {
                id: format!("automation.sources:{}", profile_id.0),
                label: format!("Refresh sources for {}", profile_id.0),
                enabled: true,
            },
            AutomationJobView {
                id: "automation.recovery.guard".to_owned(),
                label: "Recovery guard".to_owned(),
                enabled: runtime.pending_recovery_decisions == 0,
            },
        ];

        Ok(defaults
            .into_iter()
            .map(|job| AutomationJobView {
                enabled: override_map.get(&job.id).copied().unwrap_or(job.enabled),
                ..job
            })
            .collect())
    }

    pub fn patch_automation_job(&self, request: PatchAutomationJob) -> Result<(), String> {
        self.engine.set_automation_job(&request)
    }

    pub fn make_demo_command(
        &self,
        trace: impl Into<String>,
        kind: caly_engine::CommandKind,
    ) -> Command {
        let trace_id = TraceId::new(trace);
        Command {
            id: CommandId(format!("cmd-{}", trace_id.0)),
            request_id: None,
            actor: Actor::Cli,
            context: caly_common::RequestContext::new(trace_id, Actor::Cli),
            timeout_ms: Some(30_000),
            idempotency_key: None,
            kind,
        }
    }
}

impl DaemonApp {
    fn workflow_for_active_or_default_profile(&self) -> Result<caly_engine::ApplyWorkflowResult, String> {
        let runtime = self.runtime_snapshot()?;
        let profile_id = runtime
            .active_profile
            .unwrap_or_else(|| ProfileId(DEFAULT_PROFILE_ID.to_owned()));
        self.workflow_for_profile(profile_id)
    }

    fn workflow_for_profile(&self, profile_id: ProfileId) -> Result<caly_engine::ApplyWorkflowResult, String> {
        plan_apply_request(ApplyRequest {
            profile_id,
            dry_run: true,
            strict: false,
        })
    }
}

fn paged_node_view(
    items: Vec<NodeView>,
    page: caly_api::PageRequest,
    revision: u64,
) -> Result<NodePage, String> {
    let start = page.cursor.as_deref().unwrap_or("0").parse::<usize>().unwrap_or(0);
    let limit = page.limit.max(1) as usize;
    let next_index = start.saturating_add(limit);
    let page_items = items.into_iter().skip(start).take(limit).collect::<Vec<_>>();
    let next = if page_items.len() == limit {
        Some(next_index.to_string())
    } else {
        None
    };
    Ok(NodePage {
        items: page_items,
        next,
        revision,
    })
}

fn paged_rule_view(
    items: Vec<RuleView>,
    page: caly_api::PageRequest,
    revision: u64,
) -> Result<RulePage, String> {
    let start = page.cursor.as_deref().unwrap_or("0").parse::<usize>().unwrap_or(0);
    let limit = page.limit.max(1) as usize;
    let next_index = start.saturating_add(limit);
    let page_items = items.into_iter().skip(start).take(limit).collect::<Vec<_>>();
    let next = if page_items.len() == limit {
        Some(next_index.to_string())
    } else {
        None
    };
    Ok(RulePage {
        items: page_items,
        next,
        revision,
    })
}

fn paged_connection_view(
    items: Vec<ConnectionView>,
    page: caly_api::PageRequest,
    revision: u64,
) -> Result<ConnectionPage, String> {
    let start = page.cursor.as_deref().unwrap_or("0").parse::<usize>().unwrap_or(0);
    let limit = page.limit.max(1) as usize;
    let next_index = start.saturating_add(limit);
    let page_items = items.into_iter().skip(start).take(limit).collect::<Vec<_>>();
    let next = if page_items.len() == limit {
        Some(next_index.to_string())
    } else {
        None
    };
    Ok(ConnectionPage {
        items: page_items,
        next,
        revision,
    })
}

fn core_kind_from_identity(identity: &str) -> Option<&str> {
    identity.split_once('@').map(|(kind, _)| kind)
}

fn core_version_from_identity(identity: &str) -> Option<&str> {
    identity.split_once('@').map(|(_, version)| version)
}

pub fn unsupported_request_response(envelope: &RequestEnvelope) -> ResponseEnvelope {
    ResponseEnvelope {
        request_id: envelope.request_id,
        trace_id: envelope.trace_id.clone(),
        result: Err(ApiError::new(
            caly_api::ErrorCode::Unavailable,
            caly_api::ErrorCategory::User,
            false,
            format!(
                "operation routed to {:?} but no daemon handler is connected yet",
                caly_ipc::route_operation(&envelope.operation)
            ),
            envelope.trace_id.clone(),
        )),
    }
}
