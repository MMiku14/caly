mod automation;
mod common;
mod core;
mod diagnostics;
mod dns;
mod network;
mod profile;
mod proxy;
mod routing;
mod runtime;
mod source;
mod system;

use caly_api::{Operation, OperationResult, RequestEnvelope};

use crate::app::DaemonApp;

pub fn handle_query(app: &DaemonApp, envelope: &RequestEnvelope) -> Result<Option<OperationResult>, caly_api::ApiError> {
    match &envelope.operation {
        Operation::System(op) => system::handle_system(app, envelope, op),
        Operation::Profile(op) => profile::handle_profile(app, envelope, op),
        Operation::Source(op) => source::handle_source(app, envelope, op),
        Operation::Proxy(op) => proxy::handle_proxy(app, envelope, op),
        Operation::Routing(op) => routing::handle_routing(app, envelope, op),
        Operation::Dns(op) => dns::handle_dns(app, envelope, op),
        Operation::Network(op) => network::handle_network(app, envelope, op),
        Operation::Core(op) => core::handle_core(app, envelope, op),
        Operation::Runtime(op) => runtime::handle_runtime(app, envelope, op),
        Operation::Diagnostics(op) => diagnostics::handle_diagnostics(app, envelope, op),
        Operation::Automation(op) => automation::handle_automation(app, envelope, op),
    }
}
