use caly_api::{ProfileId, ProtocolVersion};
use caly_engine::EngineLifecycle;

#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub enum DaemonLifecycle {
    Stopped,
    Starting,
    Running,
    Recovering,
    Failed,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct DaemonRuntimeState {
    pub lifecycle: DaemonLifecycle,
    pub instance_id: String,
    pub daemon_name: String,
    pub daemon_version: String,
    pub protocol_version: ProtocolVersion,
    pub engine_lifecycle: EngineLifecycle,
    pub state_revision: u64,
    pub next_stream_id: u64,
    pub active_profile: Option<ProfileId>,
    pub active_core: Option<String>,
    pub active_snapshot: Option<String>,
    pub last_apply_plan_summary: Option<String>,
    pub pending_recovery_decisions: usize,
    pub last_recovery_summary: Option<String>,
    pub last_error: Option<String>,
}

impl DaemonRuntimeState {
    pub fn new(instance_id: impl Into<String>, protocol_version: ProtocolVersion) -> Self {
        Self {
            lifecycle: DaemonLifecycle::Stopped,
            instance_id: instance_id.into(),
            daemon_name: "calyd".to_owned(),
            daemon_version: "0.1.0-dev".to_owned(),
            protocol_version,
            engine_lifecycle: EngineLifecycle::Idle,
            state_revision: 0,
            next_stream_id: 1,
            active_profile: None,
            active_core: None,
            active_snapshot: None,
            last_apply_plan_summary: None,
            pending_recovery_decisions: 0,
            last_recovery_summary: None,
            last_error: None,
        }
    }

    pub fn allocate_stream_id(&mut self) -> u64 {
        let next = self.next_stream_id;
        self.next_stream_id = self.next_stream_id.saturating_add(1);
        next
    }
}
