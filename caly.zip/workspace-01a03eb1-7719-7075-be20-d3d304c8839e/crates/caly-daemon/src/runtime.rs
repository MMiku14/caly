use caly_common::Actor;
use caly_ipc::{ClientFrame, ClientHello, FrameHeader, SessionCloseReason};

use crate::app::DaemonApp;
use crate::bootstrap::DaemonBootstrapConfig;
use crate::registry::{SessionRegistry, SessionRegistryConfig, SessionRegistrySnapshot};
use crate::transport::{TransportInspection, TransportStepOutput};

pub struct DaemonRuntime {
    pub app: DaemonApp,
    pub registry: SessionRegistry,
}

impl DaemonRuntime {
    pub fn new(daemon: DaemonBootstrapConfig, registry: SessionRegistryConfig) -> Self {
        Self {
            app: DaemonApp::bootstrap(daemon),
            registry: SessionRegistry::new(registry),
        }
    }

    pub fn open_session(&mut self, actor: Actor, session_id: impl Into<String>) -> String {
        self.registry.open_session(actor, session_id)
    }

    pub fn handle_hello(
        &mut self,
        session_id: &str,
        header: FrameHeader,
        hello: ClientHello,
    ) -> Result<TransportStepOutput, String> {
        self.registry.handle_hello(&self.app, session_id, header, hello)
    }

    pub fn handle_client_frame(
        &mut self,
        session_id: &str,
        header: FrameHeader,
        frame: ClientFrame,
        is_control_message: bool,
    ) -> Result<TransportStepOutput, String> {
        self.registry
            .handle_frame(&self.app, session_id, header, frame, is_control_message)
    }

    pub fn pull_stream(
        &mut self,
        session_id: &str,
        stream_id: caly_api::StreamId,
        from_seq_exclusive: Option<u64>,
    ) -> Result<TransportStepOutput, String> {
        self.registry
            .pull_stream(&self.app, session_id, stream_id, from_seq_exclusive)
    }

    pub fn hello_timeout(&mut self, session_id: &str) -> Result<TransportStepOutput, String> {
        self.registry.force_hello_timeout(&self.app, session_id)
    }

    pub fn close_session(
        &mut self,
        session_id: &str,
        reason: SessionCloseReason,
    ) -> Result<TransportStepOutput, String> {
        self.registry.close_session(&self.app, session_id, reason)
    }

    pub fn inspect_session(&self, session_id: &str) -> Result<TransportInspection, String> {
        self.registry.inspect_session(session_id)
    }

    pub fn snapshot(&self) -> SessionRegistrySnapshot {
        self.registry.snapshot()
    }
}
