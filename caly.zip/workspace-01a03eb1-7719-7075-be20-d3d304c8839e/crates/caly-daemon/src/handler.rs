use caly_api::{OperationMode, RequestEnvelope, ResponseEnvelope};
use caly_common::Actor;

use crate::app::{unsupported_request_response, DaemonApp};
use crate::query::handle_query;
use crate::stream::handle_stream;

pub fn handle_request(app: &DaemonApp, actor: Actor, envelope: &RequestEnvelope) -> ResponseEnvelope {
    match envelope.operation.meta().mode {
        OperationMode::Command => match app.submit_request_as_command(actor, envelope) {
            Ok(Some(accepted)) => ResponseEnvelope {
                request_id: envelope.request_id,
                trace_id: envelope.trace_id.clone(),
                result: Ok(caly_api::OperationResult::Accepted(caly_api::Accepted {
                    job_id: caly_api::JobId(accepted.job_id),
                    state_revision: app
                        .runtime_snapshot()
                        .map(|runtime| runtime.state_revision)
                        .unwrap_or_default(),
                    estimated_impact: caly_api::EstimatedImpact::ReadOnly,
                })),
            },
            Ok(None) => unsupported_request_response(envelope),
            Err(error) => ResponseEnvelope {
                request_id: envelope.request_id,
                trace_id: envelope.trace_id.clone(),
                result: Err(error),
            },
        },
        OperationMode::Query => match handle_query(app, envelope) {
            Ok(Some(result)) => ResponseEnvelope {
                request_id: envelope.request_id,
                trace_id: envelope.trace_id.clone(),
                result: Ok(result),
            },
            Ok(None) => unsupported_request_response(envelope),
            Err(error) => ResponseEnvelope {
                request_id: envelope.request_id,
                trace_id: envelope.trace_id.clone(),
                result: Err(error),
            },
        },
        OperationMode::Stream => match handle_stream(app, envelope) {
            Some(result) => ResponseEnvelope {
                request_id: envelope.request_id,
                trace_id: envelope.trace_id.clone(),
                result: Ok(result),
            },
            None => unsupported_request_response(envelope),
        },
    }
}
