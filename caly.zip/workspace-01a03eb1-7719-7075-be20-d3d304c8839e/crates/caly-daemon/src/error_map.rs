use caly_api::{ApiError, ErrorCategory, ErrorCode, TraceId};
use caly_engine::{OverloadClass, OverloadReport};
use caly_ipc::{FrameValidationError, HandshakeError, SessionLoopError};

pub fn map_handshake_error(trace_id: TraceId, error: HandshakeError) -> ApiError {
    let code = match error.code {
        caly_ipc::HandshakeErrorCode::ProtoMismatch => ErrorCode::ProtoMismatch,
        caly_ipc::HandshakeErrorCode::InvalidClientName => ErrorCode::ConfigInvalid,
        caly_ipc::HandshakeErrorCode::UnsupportedEncoding => ErrorCode::ProtoMismatch,
        caly_ipc::HandshakeErrorCode::UnsupportedCompression => ErrorCode::ProtoMismatch,
    };

    ApiError::new(code, ErrorCategory::User, false, error.summary, trace_id)
}

pub fn map_frame_validation_error(trace_id: TraceId, error: FrameValidationError) -> ApiError {
    let retryable = matches!(error.code, caly_ipc::FrameValidationErrorCode::FrameTooLarge);
    ApiError::new(
        ErrorCode::Unavailable,
        ErrorCategory::Io,
        retryable,
        error.summary,
        trace_id,
    )
}

pub fn map_session_loop_error(trace_id: TraceId, error: SessionLoopError) -> ApiError {
    let code = match error.code {
        caly_ipc::SessionLoopErrorCode::HelloRequired => ErrorCode::ProtoMismatch,
        caly_ipc::SessionLoopErrorCode::HelloInActiveSession => ErrorCode::ProtoMismatch,
        caly_ipc::SessionLoopErrorCode::FrameInvalid => ErrorCode::Unavailable,
        caly_ipc::SessionLoopErrorCode::RequestInvalid => ErrorCode::ConfigInvalid,
        caly_ipc::SessionLoopErrorCode::SessionClosed => ErrorCode::Unavailable,
    };
    ApiError::new(code, ErrorCategory::User, false, error.summary, trace_id)
}

pub fn map_overload_report(trace_id: TraceId, report: OverloadReport) -> ApiError {
    let category = match report.class {
        OverloadClass::QueueFull | OverloadClass::EventBacklog | OverloadClass::StreamBackpressure => {
            ErrorCategory::Internal
        }
        OverloadClass::StorageBusy => ErrorCategory::Io,
    };
    ApiError::new(
        ErrorCode::Unavailable,
        category,
        report.retryable,
        report.summary,
        trace_id,
    )
}
