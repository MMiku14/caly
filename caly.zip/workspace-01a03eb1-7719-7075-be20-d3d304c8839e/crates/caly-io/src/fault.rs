#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub enum IoFaultKind {
    NotFound,
    AlreadyExists,
    PermissionDenied,
    Busy,
    Timeout,
    Cancelled,
    CapacityExceeded,
    Transient,
    Unavailable,
    IntegrityViolation,
    InvalidInput,
    Unsupported,
    InternalIo,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct IoFault {
    pub kind: IoFaultKind,
    pub summary: String,
    pub retryable: bool,
    pub transient: bool,
    pub resource: Option<String>,
    pub source_hint: Option<String>,
    pub trace_id: Option<String>,
}

impl IoFault {
    pub fn new(kind: IoFaultKind, summary: impl Into<String>) -> Self {
        Self {
            kind,
            summary: summary.into(),
            retryable: false,
            transient: false,
            resource: None,
            source_hint: None,
            trace_id: None,
        }
    }
}
