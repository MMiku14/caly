#[derive(Clone, Debug, Eq, PartialEq)]
pub struct VPath {
    segments: Vec<String>,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct VPathError {
    pub message: String,
}

impl VPath {
    pub fn try_from_str(path: &str) -> Result<Self, VPathError> {
        if path.is_empty() {
            return Err(VPathError {
                message: "path must not be empty".to_owned(),
            });
        }

        if path.starts_with('/') {
            return Err(VPathError {
                message: "absolute paths are not allowed".to_owned(),
            });
        }

        let mut segments = Vec::new();
        for segment in path.split('/') {
            if segment.is_empty() || segment == "." || segment == ".." {
                return Err(VPathError {
                    message: format!("invalid path segment: {segment}"),
                });
            }
            segments.push(segment.to_owned());
        }

        Ok(Self { segments })
    }

    pub fn join(&self, segment: &str) -> Result<Self, VPathError> {
        if segment.is_empty() || segment == "." || segment == ".." || segment.contains('/') {
            return Err(VPathError {
                message: format!("invalid path segment: {segment}"),
            });
        }

        let mut segments = self.segments.clone();
        segments.push(segment.to_owned());
        Ok(Self { segments })
    }

    pub fn as_relative_path(&self) -> String {
        self.segments.join("/")
    }
}
