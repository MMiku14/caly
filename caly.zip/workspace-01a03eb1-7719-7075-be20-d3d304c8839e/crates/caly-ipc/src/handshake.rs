use caly_api::{ProtocolVersion, Role};

use crate::frame::{Compression, Encoding};

#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub enum ClientKind {
    Cli,
    Tui,
    Automation,
    Test,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct ClientHello {
    pub protocol: ProtocolVersion,
    pub client_kind: ClientKind,
    pub client_name: String,
    pub requested_encoding: Encoding,
    pub requested_compression: Compression,
    pub supported_features: Vec<String>,
    pub role: Role,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct ServerHelloAck {
    pub protocol: ProtocolVersion,
    pub daemon_name: String,
    pub daemon_version: String,
    pub instance_id: String,
    pub selected_encoding: Encoding,
    pub selected_compression: Compression,
    pub server_features: Vec<String>,
    pub state_revision: u64,
}
