use caly_api::{RequestEnvelope, ResponseEnvelope};

#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub enum Encoding {
    Json,
    MsgPack,
}

#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub enum Compression {
    None,
    Zstd,
}

#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub struct FrameHeader {
    pub length: u32,
    pub encoding: Encoding,
    pub compression: Compression,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub enum ClientFrame {
    Request(RequestEnvelope),
    StreamAck(super::stream::Ack),
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub enum ServerFrame {
    Response(ResponseEnvelope),
    Stream(super::stream::StreamFrame),
}
