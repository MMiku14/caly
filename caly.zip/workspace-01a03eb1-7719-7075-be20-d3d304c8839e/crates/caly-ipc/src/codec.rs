use crate::frame::{ClientFrame, Compression, Encoding, FrameHeader, ServerFrame};

#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub enum FrameSide {
    Client,
    Server,
}

#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub enum FrameType {
    Hello,
    Request,
    Response,
    Stream,
    StreamAck,
    Close,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct EncodedFrame {
    pub header: FrameHeader,
    pub payload: Vec<u8>,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub enum DecodeErrorCode {
    Truncated,
    InvalidLength,
    UnknownFrameType,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct DecodeError {
    pub code: DecodeErrorCode,
    pub summary: String,
}

pub fn classify_client_frame(frame: &ClientFrame) -> FrameType {
    match frame {
        ClientFrame::Request(_) => FrameType::Request,
        ClientFrame::StreamAck(_) => FrameType::StreamAck,
    }
}

pub fn classify_server_frame(frame: &ServerFrame) -> FrameType {
    match frame {
        ServerFrame::Response(_) => FrameType::Response,
        ServerFrame::Stream(_) => FrameType::Stream,
    }
}

pub fn is_control_client_frame(frame: &ClientFrame) -> bool {
    matches!(classify_client_frame(frame), FrameType::Request | FrameType::StreamAck)
}

pub fn is_control_server_frame(frame: &ServerFrame) -> bool {
    matches!(classify_server_frame(frame), FrameType::Response)
}

pub fn make_header(length: usize, encoding: Encoding, compression: Compression) -> FrameHeader {
    FrameHeader {
        length: length as u32,
        encoding,
        compression,
    }
}

pub fn encode_raw_json(payload: &str, encoding: Encoding, compression: Compression) -> EncodedFrame {
    EncodedFrame {
        header: make_header(payload.len(), encoding, compression),
        payload: payload.as_bytes().to_vec(),
    }
}

pub fn decode_raw_json(frame: &EncodedFrame) -> Result<String, DecodeError> {
    if frame.header.length as usize != frame.payload.len() {
        return Err(DecodeError {
            code: DecodeErrorCode::InvalidLength,
            summary: format!(
                "declared frame length {} does not match payload length {}",
                frame.header.length,
                frame.payload.len()
            ),
        });
    }

    String::from_utf8(frame.payload.clone()).map_err(|_| DecodeError {
        code: DecodeErrorCode::Truncated,
        summary: "frame payload is not valid utf-8 json text".to_owned(),
    })
}
