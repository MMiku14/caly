use crate::frame::{ClientFrame, FrameHeader, ServerFrame};
use crate::handshake::{ClientHello, ServerHelloAck};
use crate::session::{SessionMachine, SessionState};

#[derive(Clone, Debug, Eq, PartialEq)]
pub enum SessionLoopInput {
    Hello {
        header: FrameHeader,
        hello: ClientHello,
    },
    ClientFrame {
        header: FrameHeader,
        frame: ClientFrame,
        is_control_message: bool,
    },
    HelloTimeoutExpired,
    Close {
        reason: SessionCloseReason,
    },
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub enum SessionLoopOutput {
    HelloAck(ServerHelloAck),
    Frames(Vec<ServerFrame>),
    Closed {
        reason: SessionCloseReason,
    },
}

#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub enum SessionCloseReason {
    ClientClosed,
    HelloTimeout,
    ProtocolViolation,
    ServerShutdown,
}

#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub enum SessionLoopErrorCode {
    HelloRequired,
    HelloInActiveSession,
    FrameInvalid,
    RequestInvalid,
    SessionClosed,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct SessionLoopError {
    pub code: SessionLoopErrorCode,
    pub summary: String,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct SessionStateSnapshot {
    pub state: SessionState,
    pub can_accept_hello: bool,
    pub can_accept_client_frames: bool,
}

pub fn validate_hello_frame(
    machine: &SessionMachine,
    header: &FrameHeader,
) -> Result<(), SessionLoopError> {
    validate_frame(machine, header, true)
}

pub fn validate_non_hello_frame(
    machine: &SessionMachine,
    header: &FrameHeader,
    is_control_message: bool,
) -> Result<(), SessionLoopError> {
    validate_frame(machine, header, is_control_message)
}

fn validate_frame(
    machine: &SessionMachine,
    header: &FrameHeader,
    is_control_message: bool,
) -> Result<(), SessionLoopError> {
    machine
        .validate_frame(header, is_control_message)
        .map_err(|error| SessionLoopError {
            code: SessionLoopErrorCode::FrameInvalid,
            summary: error.summary,
        })
}

pub fn ensure_awaiting_hello(machine: &SessionMachine) -> Result<(), SessionLoopError> {
    match machine.state {
        SessionState::AwaitingHello => Ok(()),
        SessionState::Active => Err(SessionLoopError {
            code: SessionLoopErrorCode::HelloInActiveSession,
            summary: "hello received after session already became active".to_owned(),
        }),
        SessionState::Closed => Err(SessionLoopError {
            code: SessionLoopErrorCode::SessionClosed,
            summary: "hello received on closed session".to_owned(),
        }),
    }
}

pub fn ensure_active_session(machine: &SessionMachine) -> Result<(), SessionLoopError> {
    match machine.state {
        SessionState::Active => Ok(()),
        SessionState::AwaitingHello => Err(SessionLoopError {
            code: SessionLoopErrorCode::HelloRequired,
            summary: "client frame received before hello negotiation".to_owned(),
        }),
        SessionState::Closed => Err(SessionLoopError {
            code: SessionLoopErrorCode::SessionClosed,
            summary: "client frame received on closed session".to_owned(),
        }),
    }
}

pub fn handle_hello_timeout(machine: &mut SessionMachine) -> Result<SessionLoopOutput, SessionLoopError> {
    match machine.state {
        SessionState::AwaitingHello => {
            machine.close();
            Ok(SessionLoopOutput::Closed {
                reason: SessionCloseReason::HelloTimeout,
            })
        }
        SessionState::Active => Err(SessionLoopError {
            code: SessionLoopErrorCode::RequestInvalid,
            summary: "hello timeout fired after session already became active".to_owned(),
        }),
        SessionState::Closed => Ok(SessionLoopOutput::Closed {
            reason: SessionCloseReason::ClientClosed,
        }),
    }
}

pub fn close_session(machine: &mut SessionMachine, reason: SessionCloseReason) -> SessionLoopOutput {
    machine.close();
    SessionLoopOutput::Closed { reason }
}

pub fn snapshot_session_state(machine: &SessionMachine) -> SessionStateSnapshot {
    SessionStateSnapshot {
        state: machine.state,
        can_accept_hello: matches!(machine.state, SessionState::AwaitingHello),
        can_accept_client_frames: matches!(machine.state, SessionState::Active),
    }
}
