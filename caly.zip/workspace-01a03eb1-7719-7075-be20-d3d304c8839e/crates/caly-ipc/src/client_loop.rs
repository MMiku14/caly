use crate::client::{ClientSession, ClientSessionConfig, ClientSessionState};
use crate::frame::{ClientFrame, ServerFrame};
use crate::handshake::{ClientHello, ServerHelloAck};
use crate::policy::{stream_policy, AckPolicy};
use crate::stream::{Ack, StreamFrame};

#[derive(Clone, Debug, Eq, PartialEq)]
pub enum ClientLoopEvent {
    SendHello(ClientHello),
    SendFrame(ClientFrame),
    ObserveHelloAck(ServerHelloAck),
    ObserveServerFrame(ServerFrame),
    Close,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub enum ClientLoopAction {
    None,
    OutboundHello(ClientHello),
    OutboundFrame(ClientFrame),
    SuggestedAck(Ack),
    Closed,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct ClientLoopSnapshot {
    pub state: ClientSessionState,
    pub next_request_id: u64,
    pub open_stream_count: usize,
    pub daemon_instance_id: Option<String>,
}

pub struct ClientLoop {
    pub session: ClientSession,
}

impl ClientLoop {
    pub fn new(config: ClientSessionConfig) -> Self {
        Self {
            session: ClientSession::new(config),
        }
    }

    pub fn open_handshake(&mut self) -> ClientLoopAction {
        ClientLoopAction::OutboundHello(self.session.build_hello())
    }

    pub fn observe_hello_ack(&mut self, ack: ServerHelloAck) -> Result<ClientLoopAction, String> {
        self.session.apply_hello_ack(&ack).map_err(|e| e.summary)?;
        Ok(ClientLoopAction::None)
    }

    pub fn send_request_frame(
        &mut self,
        trace_id: impl Into<String>,
        operation: caly_api::Operation,
        idempotency_key: Option<String>,
    ) -> Result<ClientLoopAction, String> {
        let frame = self
            .session
            .make_request(trace_id, operation, Some(30_000), None, idempotency_key)
            .map_err(|e| e.summary)?;
        Ok(ClientLoopAction::OutboundFrame(frame))
    }

    pub fn observe_server_frame(&mut self, frame: ServerFrame) -> Result<ClientLoopAction, String> {
        match &frame {
            ServerFrame::Response(_) => {
                self.session.observe_server_frame(&frame).map_err(|e| e.summary)?;
                Ok(ClientLoopAction::None)
            }
            ServerFrame::Stream(stream) => self.observe_stream(stream.clone()),
        }
    }

    pub fn observe_stream(&mut self, stream: StreamFrame) -> Result<ClientLoopAction, String> {
        let stream_id = stream.stream_id;
        self.session.observe_stream_frame(&stream).map_err(|e| e.summary)?;
        let stream_state = self
            .session
            .streams
            .get(&stream_id.0)
            .ok_or_else(|| format!("missing stream state after observing stream {}", stream_id.0))?;

        match stream_policy(stream_state.kind).ack {
            AckPolicy::Required => {
                let upto = stream_state.expected_resume_from().unwrap_or(stream.seq);
                Ok(ClientLoopAction::SuggestedAck(Ack { stream_id, upto_seq: upto }))
            }
            AckPolicy::Optional | AckPolicy::None => Ok(ClientLoopAction::None),
        }
    }

    pub fn register_stream(&mut self, stream_id: caly_api::StreamId, kind: crate::stream::StreamKind) {
        self.session.register_stream(stream_id, kind);
    }

    pub fn apply_ack(&mut self, ack: Ack) -> Result<ClientLoopAction, String> {
        let frame = self
            .session
            .make_stream_ack(ack.stream_id, ack.upto_seq)
            .map_err(|e| e.summary)?;
        Ok(ClientLoopAction::OutboundFrame(frame))
    }

    pub fn close(&mut self) -> ClientLoopAction {
        self.session.close();
        ClientLoopAction::Closed
    }

    pub fn snapshot(&self) -> ClientLoopSnapshot {
        let snapshot = self.session.snapshot();
        ClientLoopSnapshot {
            state: snapshot.state,
            next_request_id: snapshot.next_request_id,
            open_stream_count: snapshot.streams.len(),
            daemon_instance_id: snapshot.daemon.map(|d| d.instance_id),
        }
    }
}
