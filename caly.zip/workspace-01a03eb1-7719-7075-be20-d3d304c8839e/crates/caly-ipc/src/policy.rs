use crate::stream::StreamKind;

pub const MAX_FRAME_SIZE_BYTES: u32 = 4 * 1024 * 1024;
pub const CONTROL_MESSAGES_COMPRESS_BY_DEFAULT: bool = false;
pub const DEFAULT_HELLO_TIMEOUT_MS: u64 = 5_000;

#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub enum DeliveryGuarantee {
    LosslessResumable,
    SnapshotThenPatch,
    LatestValue,
    LossyRing,
}

#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub enum AckPolicy {
    Required,
    Optional,
    None,
}

#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub struct StreamPolicy {
    pub kind: StreamKind,
    pub delivery: DeliveryGuarantee,
    pub ack: AckPolicy,
    pub reset_on_gap: bool,
}

pub const fn stream_policy(kind: StreamKind) -> StreamPolicy {
    match kind {
        StreamKind::Job => StreamPolicy {
            kind,
            delivery: DeliveryGuarantee::LosslessResumable,
            ack: AckPolicy::Required,
            reset_on_gap: false,
        },
        StreamKind::Deployment => StreamPolicy {
            kind,
            delivery: DeliveryGuarantee::LosslessResumable,
            ack: AckPolicy::Required,
            reset_on_gap: false,
        },
        StreamKind::Dashboard => StreamPolicy {
            kind,
            delivery: DeliveryGuarantee::SnapshotThenPatch,
            ack: AckPolicy::Optional,
            reset_on_gap: true,
        },
        StreamKind::Traffic => StreamPolicy {
            kind,
            delivery: DeliveryGuarantee::LatestValue,
            ack: AckPolicy::None,
            reset_on_gap: false,
        },
        StreamKind::Logs => StreamPolicy {
            kind,
            delivery: DeliveryGuarantee::LossyRing,
            ack: AckPolicy::None,
            reset_on_gap: false,
        },
        StreamKind::Connections => StreamPolicy {
            kind,
            delivery: DeliveryGuarantee::SnapshotThenPatch,
            ack: AckPolicy::Optional,
            reset_on_gap: true,
        },
    }
}
