use caly_api::{ApiError, Operation, OperationMode, OperationResult, RequestEnvelope};

#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub enum DispatchTarget {
    System,
    Profile,
    Source,
    Proxy,
    Routing,
    Dns,
    Network,
    Core,
    Runtime,
    Diagnostics,
    Automation,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct DispatchRequest {
    pub envelope: RequestEnvelope,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct DispatchOutcome {
    pub target: DispatchTarget,
    pub mode: OperationMode,
    pub result: Result<OperationResult, ApiError>,
}

pub fn route_operation(operation: &Operation) -> DispatchTarget {
    match operation {
        Operation::System(_) => DispatchTarget::System,
        Operation::Profile(_) => DispatchTarget::Profile,
        Operation::Source(_) => DispatchTarget::Source,
        Operation::Proxy(_) => DispatchTarget::Proxy,
        Operation::Routing(_) => DispatchTarget::Routing,
        Operation::Dns(_) => DispatchTarget::Dns,
        Operation::Network(_) => DispatchTarget::Network,
        Operation::Core(_) => DispatchTarget::Core,
        Operation::Runtime(_) => DispatchTarget::Runtime,
        Operation::Diagnostics(_) => DispatchTarget::Diagnostics,
        Operation::Automation(_) => DispatchTarget::Automation,
    }
}

pub trait OperationHandler: Send + Sync + 'static {
    fn handle(&self, request: DispatchRequest) -> DispatchOutcome;
}
