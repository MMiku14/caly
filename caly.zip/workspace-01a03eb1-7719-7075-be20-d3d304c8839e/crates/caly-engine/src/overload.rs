use caly_api::{ApiError, ErrorCategory, ErrorCode, TraceId};

#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub enum OverloadClass {
    QueueFull,
    EventBacklog,
    StreamBackpressure,
    StorageBusy,
}

#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub enum RetryHint {
    RetryImmediately,
    RetryLater,
    ReopenSession,
    ManualIntervention,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct OverloadReport {
    pub class: OverloadClass,
    pub summary: String,
    pub retry_hint: RetryHint,
    pub retryable: bool,
}

impl OverloadReport {
    pub fn queue_full(max_len: usize) -> Self {
        Self {
            class: OverloadClass::QueueFull,
            summary: format!("command queue full (capacity={max_len})"),
            retry_hint: RetryHint::RetryLater,
            retryable: true,
        }
    }

    pub fn to_api_error(&self, trace_id: TraceId) -> ApiError {
        ApiError::new(
            ErrorCode::Unavailable,
            ErrorCategory::Internal,
            self.retryable,
            self.summary.clone(),
            trace_id,
        )
        .with_remediation(match self.retry_hint {
            RetryHint::RetryImmediately => "retry the request immediately",
            RetryHint::RetryLater => "retry after current queued work drains",
            RetryHint::ReopenSession => "reopen the session and retry",
            RetryHint::ManualIntervention => "inspect daemon status and logs before retrying",
        })
    }
}
