use std::collections::BTreeMap;

use caly_api::JobId;

use crate::command::{Command, CommandId, IdempotencyKey};
use crate::event::EventLog;
use crate::idempotency::IdempotencyTable;
use crate::job::{JobRecord, JobState};
use crate::queue::{CommandQueue, QueuePolicy, QueuePushResult};

#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub enum EngineLifecycle {
    Idle,
    Busy,
    Recovering,
    Failed,
}

#[derive(Clone, Copy, Debug, Eq, PartialEq, Ord, PartialOrd, Hash)]
pub struct EngineGeneration(pub u64);

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct QueuedCommand {
    pub job_id: JobId,
    pub command: Command,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub enum EnqueueResult {
    Accepted,
    RejectedFull { max_len: usize },
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct EngineState {
    pub lifecycle: Option<EngineLifecycle>,
    pub generation: u64,
    pub next_job_id: u64,
    pub queue: CommandQueue,
    pub queued_commands: BTreeMap<u64, Command>,
    pub jobs: BTreeMap<u64, JobRecord>,
    pub automation_overrides: BTreeMap<String, bool>,
    pub idempotency: IdempotencyTable,
    pub events: EventLog,
}

impl Default for EngineState {
    fn default() -> Self {
        Self::new()
    }
}

impl EngineState {
    pub fn new() -> Self {
        Self {
            lifecycle: Some(EngineLifecycle::Idle),
            generation: 0,
            next_job_id: 1,
            queue: CommandQueue::with_policy(QueuePolicy::bounded(256)),
            queued_commands: BTreeMap::new(),
            jobs: BTreeMap::new(),
            automation_overrides: BTreeMap::new(),
            idempotency: IdempotencyTable::default(),
            events: EventLog::with_capacity(256),
        }
    }

    pub fn next_job_id(&mut self) -> JobId {
        let next = self.next_job_id;
        self.next_job_id = self.next_job_id.saturating_add(1);
        JobId(next)
    }

    pub fn bump_generation(&mut self) -> EngineGeneration {
        self.generation = self.generation.saturating_add(1);
        EngineGeneration(self.generation)
    }

    pub fn insert_job(&mut self, record: JobRecord) {
        self.jobs.insert(record.id.0, record);
    }

    pub fn enqueue(&mut self, job_id: JobId, command: Command) -> EnqueueResult {
        match self.queue.push(command.clone()) {
            QueuePushResult::Accepted => {
                self.queued_commands.insert(job_id.0, command);
                EnqueueResult::Accepted
            }
            QueuePushResult::RejectedFull { max_len } => EnqueueResult::RejectedFull { max_len },
        }
    }

    pub fn current_lifecycle(&self) -> EngineLifecycle {
        self.lifecycle.unwrap_or(EngineLifecycle::Idle)
    }

    pub fn set_lifecycle(&mut self, lifecycle: EngineLifecycle) {
        self.lifecycle = Some(lifecycle);
    }

    pub fn dequeue_next(&mut self) -> Option<QueuedCommand> {
        let entry = self.queue.pop()?;
        let command_id = entry.command.id.0.clone();
        let target_job_id = self
            .queued_commands
            .iter()
            .find_map(|(job_id, command)| if command.id.0 == command_id { Some(*job_id) } else { None })?;
        let command = self.queued_commands.remove(&target_job_id)?;
        Some(QueuedCommand {
            job_id: JobId(target_job_id),
            command,
        })
    }

    pub fn get_job_mut(&mut self, job_id: JobId) -> Option<&mut JobRecord> {
        self.jobs.get_mut(&job_id.0)
    }

    pub fn mark_job_state(&mut self, job_id: JobId, state: JobState) {
        if let Some(record) = self.jobs.get_mut(&job_id.0) {
            record.state = state;
        }
    }

    pub fn has_command(&self, command_id: &CommandId) -> bool {
        self.queued_commands.values().any(|command| &command.id == command_id)
    }

    pub fn has_idempotency_key(&self, key: &IdempotencyKey) -> bool {
        self.idempotency
            .get(caly_common::Actor::System, key)
            .is_some()
    }
}
