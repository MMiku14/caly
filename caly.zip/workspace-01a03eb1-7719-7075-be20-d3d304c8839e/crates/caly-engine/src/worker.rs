use caly_api::{ApiError, ErrorCategory, ErrorCode, EstimatedImpact};

use crate::apply::plan_apply_request;
use crate::job::{JobEvent, JobOutcome};
use crate::service::EngineHandle;

#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub struct WorkerPolicy {
    pub max_cycles_per_drain: usize,
}

impl WorkerPolicy {
    pub const fn bounded(max_cycles_per_drain: usize) -> Self {
        Self { max_cycles_per_drain }
    }
}

impl Default for WorkerPolicy {
    fn default() -> Self {
        Self { max_cycles_per_drain: 64 }
    }
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct WorkerCycleResult {
    pub job_id: u64,
    pub outcome: JobOutcome,
    pub impact: EstimatedImpact,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct WorkerDrainReport {
    pub cycles: usize,
    pub exhausted_queue: bool,
    pub limit_hit: bool,
    pub results: Vec<WorkerCycleResult>,
}

pub fn consume_one_skeleton(handle: &EngineHandle) -> Result<Option<WorkerCycleResult>, String> {
    let queued = match handle.poll_next()? {
        Some(value) => value,
        None => return Ok(None),
    };

    handle.mark_running(&queued)?;

    let result = match &queued.command.kind {
        crate::command::CommandKind::ProfileApply(request) => {
            execute_profile_apply(handle, &queued, request.clone())?
        }
        crate::command::CommandKind::ProfileRollback(request) => {
            handle.append_job_event(
                queued.job_id,
                JobEvent::Warning {
                    message: format!("rollback request {:?} is not connected to recovery executor yet", request),
                },
            )?;
            handle.push_event(
                crate::event::EventKind::DeploymentChanged,
                Some(queued.command.id.0.clone()),
                crate::event::EventPayload::DeploymentChanged {
                    summary: "rollback skeleton completed without recovery executor".to_owned(),
                },
            )?;
            handle.mark_finished(&queued, JobOutcome::Succeeded)?;
            WorkerCycleResult {
                job_id: queued.job_id.0,
                outcome: JobOutcome::Succeeded,
                impact: EstimatedImpact::Restart,
            }
        }
        crate::command::CommandKind::DiagnosticsBundle => {
            handle.append_job_event(
                queued.job_id,
                JobEvent::Log {
                    level: "info".to_owned(),
                    message: "support bundle skeleton generated".to_owned(),
                },
            )?;
            handle.mark_finished(&queued, JobOutcome::Succeeded)?;
            WorkerCycleResult {
                job_id: queued.job_id.0,
                outcome: JobOutcome::Succeeded,
                impact: EstimatedImpact::ReadOnly,
            }
        }
        crate::command::CommandKind::ProxySelect { group_id, node_id } => {
            handle.append_job_event(
                queued.job_id,
                JobEvent::Stage {
                    stage: format!("runtime.select {} -> {}", group_id, node_id),
                    pct: Some(100),
                },
            )?;
            handle.mark_finished(&queued, JobOutcome::Succeeded)?;
            WorkerCycleResult {
                job_id: queued.job_id.0,
                outcome: JobOutcome::Succeeded,
                impact: EstimatedImpact::Reload,
            }
        }
        crate::command::CommandKind::ProxyTestDelay { node_ids } => {
            handle.append_job_event(
                queued.job_id,
                JobEvent::Log {
                    level: "info".to_owned(),
                    message: format!("delay test requested for nodes={:?}", node_ids),
                },
            )?;
            handle.mark_finished(&queued, JobOutcome::Succeeded)?;
            WorkerCycleResult {
                job_id: queued.job_id.0,
                outcome: JobOutcome::Succeeded,
                impact: EstimatedImpact::ReadOnly,
            }
        }
        crate::command::CommandKind::DnsFlushCache => {
            handle.append_job_event(
                queued.job_id,
                JobEvent::Stage {
                    stage: "dns.flush-cache".to_owned(),
                    pct: Some(100),
                },
            )?;
            handle.mark_finished(&queued, JobOutcome::Succeeded)?;
            WorkerCycleResult {
                job_id: queued.job_id.0,
                outcome: JobOutcome::Succeeded,
                impact: EstimatedImpact::ReadOnly,
            }
        }
        crate::command::CommandKind::AutomationPatch(request) => {
            handle.set_automation_job(request)?;
            handle.append_job_event(
                queued.job_id,
                JobEvent::Stage {
                    stage: format!("automation.patch {} -> {}", request.job_id, request.enabled),
                    pct: Some(100),
                },
            )?;
            handle.push_event(
                crate::event::EventKind::DeploymentChanged,
                Some(queued.command.id.0.clone()),
                crate::event::EventPayload::DeploymentChanged {
                    summary: format!("automation job {} patched to {}", request.job_id, request.enabled),
                },
            )?;
            handle.mark_finished(&queued, JobOutcome::Succeeded)?;
            WorkerCycleResult {
                job_id: queued.job_id.0,
                outcome: JobOutcome::Succeeded,
                impact: EstimatedImpact::ReadOnly,
            }
        }
        crate::command::CommandKind::RuntimeCloseConnection { connection_id } => {
            handle.append_job_event(
                queued.job_id,
                JobEvent::Stage {
                    stage: format!("runtime.close-connection {}", connection_id),
                    pct: Some(100),
                },
            )?;
            handle.mark_finished(&queued, JobOutcome::Succeeded)?;
            WorkerCycleResult {
                job_id: queued.job_id.0,
                outcome: JobOutcome::Succeeded,
                impact: EstimatedImpact::ReadOnly,
            }
        }
        crate::command::CommandKind::SourceUpdate { source_id } => {
            handle.append_job_event(
                queued.job_id,
                JobEvent::Log {
                    level: "info".to_owned(),
                    message: format!("source update scheduled for {}", source_id),
                },
            )?;
            handle.mark_finished(&queued, JobOutcome::Succeeded)?;
            WorkerCycleResult {
                job_id: queued.job_id.0,
                outcome: JobOutcome::Succeeded,
                impact: EstimatedImpact::ReadOnly,
            }
        }
        crate::command::CommandKind::SystemShutdown => {
            handle.push_event(
                crate::event::EventKind::RuntimeChanged,
                Some(queued.command.id.0.clone()),
                crate::event::EventPayload::RuntimeChanged {
                    summary: "system shutdown skeleton path executed".to_owned(),
                },
            )?;
            handle.mark_finished(&queued, JobOutcome::Succeeded)?;
            WorkerCycleResult {
                job_id: queued.job_id.0,
                outcome: JobOutcome::Succeeded,
                impact: EstimatedImpact::Restart,
            }
        }
        crate::command::CommandKind::NetworkRepair => {
            handle.append_job_event(
                queued.job_id,
                JobEvent::Log {
                    level: "info".to_owned(),
                    message: "network repair skeleton path executed".to_owned(),
                },
            )?;
            handle.mark_finished(&queued, JobOutcome::Succeeded)?;
            WorkerCycleResult {
                job_id: queued.job_id.0,
                outcome: JobOutcome::Succeeded,
                impact: EstimatedImpact::PrivilegedNetworkChange,
            }
        }
    };

    Ok(Some(result))
}

fn execute_profile_apply(
    handle: &EngineHandle,
    queued: &crate::state::QueuedCommand,
    request: caly_api::ApplyRequest,
) -> Result<WorkerCycleResult, String> {
    handle.append_job_event(
        queued.job_id,
        JobEvent::Stage {
            stage: format!("pipeline.resolve profile={}", request.profile_id.0),
            pct: Some(10),
        },
    )?;

    let workflow = match plan_apply_request(request.clone()) {
        Ok(workflow) => workflow,
        Err(message) => {
            let error = ApiError::new(
                ErrorCode::Internal,
                ErrorCategory::Internal,
                false,
                "apply planning failed",
                queued.command.context.trace_id.clone(),
            )
            .with_detail(message);
            handle.append_job_event(queued.job_id, JobEvent::Failed { error })?;
            handle.push_event(
                crate::event::EventKind::DeploymentChanged,
                Some(queued.command.id.0.clone()),
                crate::event::EventPayload::DeploymentChanged {
                    summary: format!("apply planning failed for profile {}", request.profile_id.0),
                },
            )?;
            handle.mark_finished(queued, JobOutcome::Failed)?;
            return Ok(WorkerCycleResult {
                job_id: queued.job_id.0,
                outcome: JobOutcome::Failed,
                impact: EstimatedImpact::Restart,
            });
        }
    };

    handle.append_job_event(
        queued.job_id,
        JobEvent::Stage {
            stage: format!(
                "capability.validate required={} warn={} blocked={}",
                workflow.capability.required_count,
                workflow.capability.warning_count,
                workflow.capability.blocked_count,
            ),
            pct: Some(25),
        },
    )?;

    for decision in workflow.capability.decisions.iter().take(8) {
        handle.append_job_event(
            queued.job_id,
            JobEvent::Log {
                level: "info".to_owned(),
                message: format!("capability {decision}"),
            },
        )?;
    }

    for diagnostic in workflow.diagnostics.iter().take(8) {
        handle.append_job_event(
            queued.job_id,
            JobEvent::Warning {
                message: diagnostic.clone(),
            },
        )?;
    }

    if workflow.capability.blocked_count > 0 {
        let error = ApiError::new(
            ErrorCode::UnsupportedCapability,
            ErrorCategory::Capability,
            false,
            format!(
                "apply blocked by {} capability decision(s)",
                workflow.capability.blocked_count
            ),
            queued.command.context.trace_id.clone(),
        )
        .with_detail(workflow.capability.decisions.join(" | "))
        .with_remediation("switch target core, relax strict mode, or remove blocked features");
        handle.append_job_event(queued.job_id, JobEvent::Failed { error })?;
        handle.push_event(
            crate::event::EventKind::DeploymentChanged,
            Some(queued.command.id.0.clone()),
            crate::event::EventPayload::DeploymentChanged {
                summary: format!(
                    "apply blocked before execution for profile {}",
                    request.profile_id.0
                ),
            },
        )?;
        handle.mark_finished(queued, JobOutcome::Failed)?;
        return Ok(WorkerCycleResult {
            job_id: queued.job_id.0,
            outcome: JobOutcome::Failed,
            impact: impact_from_plan_kind(&workflow.apply_plan_kind),
        });
    }

    handle.append_job_event(
        queued.job_id,
        JobEvent::Stage {
            stage: format!("native.validate accepted={}", workflow.compilation.native_accepted),
            pct: Some(45),
        },
    )?;
    handle.append_job_event(
        queued.job_id,
        JobEvent::Stage {
            stage: format!("apply.plan {}", workflow.apply_plan_kind),
            pct: Some(60),
        },
    )?;
    handle.append_job_event(
        queued.job_id,
        JobEvent::Stage {
            stage: format!(
                "storage.project txn={} snapshot={}",
                workflow.storage.apply_txn_id, workflow.storage.snapshot_id
            ),
            pct: Some(70),
        },
    )?;

    let persisted = match handle.begin_apply_persistence(workflow.storage_projection.clone()) {
        Ok(value) => value,
        Err(message) => {
            let error = ApiError::new(
                ErrorCode::Storage,
                ErrorCategory::Io,
                true,
                "apply persistence begin failed",
                queued.command.context.trace_id.clone(),
            )
            .with_detail(message)
            .with_remediation("inspect object store and apply journal availability");
            handle.append_job_event(queued.job_id, JobEvent::Failed { error })?;
            handle.mark_finished(queued, JobOutcome::Failed)?;
            return Ok(WorkerCycleResult {
                job_id: queued.job_id.0,
                outcome: JobOutcome::Failed,
                impact: impact_from_plan_kind(&workflow.apply_plan_kind),
            });
        }
    };

    handle.append_job_event(
        queued.job_id,
        JobEvent::Log {
            level: "info".to_owned(),
            message: format!(
                "journal.pending {} runtime={}",
                persisted.journal.journal_id.0, persisted.runtime_path
            ),
        },
    )?;

    let prepared = handle.advance_apply_phase(
        &persisted.journal,
        caly_storage::ApplyPhase::Prepare,
        1,
        1,
    )?;
    let cutover = handle.advance_apply_phase(
        &prepared,
        caly_storage::ApplyPhase::Cutover,
        workflow.effect_steps.len().max(1),
        2,
    )?;
    handle.append_job_event(
        queued.job_id,
        JobEvent::Stage {
            stage: format!(
                "journal.cutover step={} net_started={} core_started={}",
                cutover.current_step_index, cutover.net_effect_started, cutover.core_cutover_started
            ),
            pct: Some(82),
        },
    )?;

    for step in workflow.effect_steps.iter().take(12) {
        handle.append_job_event(
            queued.job_id,
            JobEvent::Log {
                level: "info".to_owned(),
                message: format!("effect {step}"),
            },
        )?;
    }

    let finalized = match handle.finalize_apply_persistence(
        &cutover,
        &workflow.storage_projection.snapshot_candidate,
        3,
    ) {
        Ok(value) => value,
        Err(message) => {
            let recovery_failed = handle.mark_apply_recovery_failed(&cutover, 4)?;
            handle.append_job_event(
                queued.job_id,
                JobEvent::Warning {
                    message: format!(
                        "recovery pending: journal={} state={:?}",
                        recovery_failed.journal_id.0, recovery_failed.state
                    ),
                },
            )?;
            handle.push_event(
                crate::event::EventKind::RecoveryDecision,
                Some(queued.command.id.0.clone()),
                crate::event::EventPayload::RecoveryDecision {
                    summary: format!(
                        "apply finalization failed for profile {}; manual recovery may be required",
                        request.profile_id.0
                    ),
                },
            )?;
            let error = ApiError::new(
                ErrorCode::Storage,
                ErrorCategory::Io,
                true,
                "apply finalization failed",
                queued.command.context.trace_id.clone(),
            )
            .with_detail(message)
            .with_remediation("inspect snapshot/revision persistence before retrying apply");
            handle.append_job_event(queued.job_id, JobEvent::Failed { error })?;
            handle.mark_finished(queued, JobOutcome::Failed)?;
            return Ok(WorkerCycleResult {
                job_id: queued.job_id.0,
                outcome: JobOutcome::Failed,
                impact: impact_from_plan_kind(&workflow.apply_plan_kind),
            });
        }
    };

    handle.push_event(
        crate::event::EventKind::DeploymentChanged,
        Some(queued.command.id.0.clone()),
        crate::event::EventPayload::DeploymentChanged {
            summary: format!(
                "persisted apply {} for profile {}",
                workflow.apply_plan_kind, request.profile_id.0
            ),
        },
    )?;
    handle.push_event(
        crate::event::EventKind::SnapshotCommitted,
        Some(queued.command.id.0.clone()),
        crate::event::EventPayload::SnapshotCommitted {
            snapshot_id: finalized.snapshot_id.clone(),
        },
    )?;
    handle.append_job_event(
        queued.job_id,
        JobEvent::Stage {
            stage: format!(
                "snapshot.committed {} revision={}",
                finalized.snapshot_id, finalized.revision_id
            ),
            pct: Some(100),
        },
    )?;
    handle.mark_finished(queued, JobOutcome::Succeeded)?;

    Ok(WorkerCycleResult {
        job_id: queued.job_id.0,
        outcome: JobOutcome::Succeeded,
        impact: impact_from_plan_kind(&workflow.apply_plan_kind),
    })
}

fn impact_from_plan_kind(plan_kind: &str) -> EstimatedImpact {
    match plan_kind {
        "Noop" => EstimatedImpact::Noop,
        "ApiPatch" => EstimatedImpact::Reload,
        "HotReload" => EstimatedImpact::Reload,
        "Restart" => EstimatedImpact::Restart,
        "RebuildAndRestart" => EstimatedImpact::RebuildAndRestart,
        _ => EstimatedImpact::ReadOnly,
    }
}

pub fn drain_skeleton(handle: &EngineHandle, max_cycles: usize) -> Result<Vec<WorkerCycleResult>, String> {
    let mut results = Vec::new();
    for _ in 0..max_cycles {
        match consume_one_skeleton(handle)? {
            Some(result) => results.push(result),
            None => break,
        }
    }
    Ok(results)
}

pub fn drain_with_policy(handle: &EngineHandle, policy: WorkerPolicy) -> Result<WorkerDrainReport, String> {
    let results = drain_skeleton(handle, policy.max_cycles_per_drain)?;
    let cycles = results.len();
    let limit_hit = cycles >= policy.max_cycles_per_drain;
    let exhausted_queue = !limit_hit;
    Ok(WorkerDrainReport {
        cycles,
        exhausted_queue,
        limit_hit,
        results,
    })
}
