use caly_api::{ApplyRequest, PatchAutomationJob, RequestId, RollbackRequest};
use caly_common::{Actor, RequestContext};

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct CommandId(pub String);

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct IdempotencyKey(pub String);

#[derive(Clone, Debug, Eq, PartialEq)]
pub enum CommandKind {
    SystemShutdown,
    ProfileApply(ApplyRequest),
    ProfileRollback(RollbackRequest),
    SourceUpdate { source_id: String },
    ProxySelect { group_id: String, node_id: String },
    ProxyTestDelay { node_ids: Vec<String> },
    DnsFlushCache,
    RuntimeCloseConnection { connection_id: String },
    NetworkRepair,
    DiagnosticsBundle,
    AutomationPatch(PatchAutomationJob),
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct Command {
    pub id: CommandId,
    pub request_id: Option<RequestId>,
    pub actor: Actor,
    pub context: RequestContext,
    pub timeout_ms: Option<u64>,
    pub idempotency_key: Option<IdempotencyKey>,
    pub kind: CommandKind,
}
