use crate::event::{Event, EventSeq};
use crate::service::{EngineHandle, EventWindow};

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct EventFollowRequest {
    pub from_exclusive: Option<EventSeq>,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct EventFollowProjection {
    pub next_seq: u64,
    pub retained_from: EventSeq,
    pub reset_required: bool,
    pub events: Vec<Event>,
}

pub fn project_event_window(window: EventWindow) -> EventFollowProjection {
    EventFollowProjection {
        next_seq: window.next_seq,
        retained_from: window.retained_from,
        reset_required: window.reset_required,
        events: window.events,
    }
}

pub fn follow_events_once(
    handle: &EngineHandle,
    request: EventFollowRequest,
) -> Result<EventFollowProjection, String> {
    let window = handle.events_since(request.from_exclusive)?;
    Ok(project_event_window(window))
}
