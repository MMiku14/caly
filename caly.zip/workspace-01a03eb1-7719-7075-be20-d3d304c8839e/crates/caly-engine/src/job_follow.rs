use crate::job::{JobEvent, JobRecord};

#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub struct JobEventRetentionPolicy {
    pub max_events: usize,
}

impl JobEventRetentionPolicy {
    pub const fn bounded(max_events: usize) -> Self {
        Self { max_events }
    }
}

impl Default for JobEventRetentionPolicy {
    fn default() -> Self {
        Self { max_events: 128 }
    }
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct JobEventWindow {
    pub next_index: u64,
    pub retained_from_index: u64,
    pub reset_required: bool,
    pub events: Vec<JobEvent>,
}

pub fn slice_job_events(
    record: &JobRecord,
    from_event_index: Option<u64>,
    policy: JobEventRetentionPolicy,
) -> JobEventWindow {
    let total = record.events.len();
    let retained_from_index = total.saturating_sub(policy.max_events) as u64;
    let next_index = total as u64;

    if let Some(from) = from_event_index {
        if from.saturating_add(1) < retained_from_index {
            return JobEventWindow {
                next_index,
                retained_from_index,
                reset_required: true,
                events: Vec::new(),
            };
        }
    }

    let requested_start = from_event_index
        .map(|index| index.saturating_add(1) as usize)
        .unwrap_or(0);
    let retained_start = retained_from_index as usize;
    let start = requested_start.max(retained_start);

    JobEventWindow {
        next_index,
        retained_from_index,
        reset_required: false,
        events: record.events.iter().skip(start).cloned().collect(),
    }
}
