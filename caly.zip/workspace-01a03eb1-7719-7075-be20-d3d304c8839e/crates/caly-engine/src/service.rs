use std::sync::{Arc, Mutex};

use caly_api::{Accepted, JobFollowView, JobId, PatchAutomationJob};
use caly_storage::{ApplyStorageProjection, InMemoryStorage, RecoveryScanReport, SnapshotRecord};

use crate::command::{Command, IdempotencyKey};
use crate::event::{Event, EventSeq, ReplayWindow};
use crate::idempotency::IdempotencyStatus;
use crate::job::{JobEvent, JobOutcome, JobRecord, JobState};
use crate::job_follow::{slice_job_events, JobEventRetentionPolicy, JobEventWindow};
use crate::overload::OverloadReport;
use crate::processor::{
    mark_finished, mark_running, poll_next_command, submit_command, ProcessedCommand, SubmitRejected,
};
use crate::recovery::{
    advance_apply_phase, begin_apply_persistence, finalize_apply_persistence,
    mark_apply_recovery_failed, mark_apply_reverted, run_ready, scan_recovery_state,
    FinalizedApplyExecution, PersistedApplyExecution,
};
use crate::state::{EngineLifecycle, EngineState, QueuedCommand};
use crate::worker::{drain_with_policy, WorkerDrainReport, WorkerPolicy};

#[derive(Clone)]
pub struct EngineHandle {
    inner: Arc<Mutex<EngineState>>,
    storage: Arc<InMemoryStorage>,
}

impl Default for EngineHandle {
    fn default() -> Self {
        Self::new(EngineState::new())
    }
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub enum SubmitFailure {
    Overload(OverloadReport),
    Internal(String),
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct SubmitResult {
    pub accepted: Accepted,
    pub reused_existing_job: bool,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct EventWindow {
    pub from_exclusive: Option<EventSeq>,
    pub next_seq: u64,
    pub retained_from: EventSeq,
    pub reset_required: bool,
    pub events: Vec<Event>,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct JobFollow {
    pub job: Option<JobRecord>,
    pub lifecycle: EngineLifecycle,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct JobFollowProjection {
    pub summary: JobFollowView,
    pub window: Option<JobEventWindow>,
}

impl EngineHandle {
    pub fn new(state: EngineState) -> Self {
        Self::with_storage(state, InMemoryStorage::new())
    }

    pub fn with_storage(state: EngineState, storage: InMemoryStorage) -> Self {
        Self {
            inner: Arc::new(Mutex::new(state)),
            storage: Arc::new(storage),
        }
    }

    pub fn storage(&self) -> Arc<InMemoryStorage> {
        Arc::clone(&self.storage)
    }

    pub fn snapshot(&self) -> Result<EngineState, String> {
        self.inner
            .lock()
            .map(|guard| guard.clone())
            .map_err(|_| "engine state lock poisoned".to_owned())
    }

    pub fn submit(&self, command: Command) -> Result<SubmitResult, String> {
        self.submit_checked(command).map_err(|failure| match failure {
            SubmitFailure::Overload(report) => report.summary,
            SubmitFailure::Internal(message) => message,
        })
    }

    pub fn submit_checked(&self, command: Command) -> Result<SubmitResult, SubmitFailure> {
        let mut guard = self
            .inner
            .lock()
            .map_err(|_| SubmitFailure::Internal("engine state lock poisoned".to_owned()))?;

        if let Some(key) = &command.idempotency_key {
            if let Some(existing) = guard.idempotency.get(command.actor, key) {
                let accepted = Accepted {
                    job_id: JobId(existing.job_id),
                    state_revision: guard.generation,
                    estimated_impact: caly_api::EstimatedImpact::ReadOnly,
                };
                return Ok(SubmitResult {
                    accepted,
                    reused_existing_job: true,
                });
            }
        }

        let processed: ProcessedCommand = submit_command(&mut guard, command.clone()).map_err(
            |SubmitRejected { reason, overload }| match overload {
                Some(overload) => SubmitFailure::Overload(overload),
                None => SubmitFailure::Internal(reason),
            },
        )?;

        if let Some(key) = &command.idempotency_key {
            guard.idempotency.put_running(
                command.actor,
                key,
                command.id.clone(),
                processed.accepted.job_id.0,
            );
        }

        Ok(SubmitResult {
            accepted: processed.accepted,
            reused_existing_job: false,
        })
    }

    pub fn poll_next(&self) -> Result<Option<QueuedCommand>, String> {
        let mut guard = self
            .inner
            .lock()
            .map_err(|_| "engine state lock poisoned".to_owned())?;
        Ok(poll_next_command(&mut guard))
    }

    pub fn mark_running(&self, queued: &QueuedCommand) -> Result<(), String> {
        let mut guard = self
            .inner
            .lock()
            .map_err(|_| "engine state lock poisoned".to_owned())?;
        mark_running(&mut guard, queued);
        Ok(())
    }

    pub fn mark_finished(&self, queued: &QueuedCommand, outcome: JobOutcome) -> Result<(), String> {
        let mut guard = self
            .inner
            .lock()
            .map_err(|_| "engine state lock poisoned".to_owned())?;

        let impact = if let Some(job) = guard.jobs.get(&queued.job_id.0) {
            if matches!(job.state, JobState::Running | JobState::Queued | JobState::Accepted) {
                caly_api::EstimatedImpact::Restart
            } else {
                caly_api::EstimatedImpact::ReadOnly
            }
        } else {
            caly_api::EstimatedImpact::ReadOnly
        };

        mark_finished(&mut guard, queued, outcome, impact);

        if let Some(key) = &queued.command.idempotency_key {
            guard.idempotency.mark_finished(queued.command.actor, key, outcome);
        }

        Ok(())
    }

    pub fn append_job_event(&self, job_id: JobId, event: JobEvent) -> Result<(), String> {
        let mut guard = self
            .inner
            .lock()
            .map_err(|_| "engine state lock poisoned".to_owned())?;
        let job = guard
            .jobs
            .get_mut(&job_id.0)
            .ok_or_else(|| format!("unknown job id: {}", job_id.0))?;
        job.events.push(event);
        Ok(())
    }

    pub fn push_event(
        &self,
        kind: crate::event::EventKind,
        command_id: Option<String>,
        payload: crate::event::EventPayload,
    ) -> Result<Event, String> {
        let mut guard = self
            .inner
            .lock()
            .map_err(|_| "engine state lock poisoned".to_owned())?;
        Ok(guard.events.push(kind, command_id, payload))
    }

    pub fn begin_apply_persistence(
        &self,
        projection: ApplyStorageProjection,
    ) -> Result<PersistedApplyExecution, String> {
        run_ready(begin_apply_persistence(self.storage.as_ref(), projection))?
            .map_err(|error| error.summary)
    }

    pub fn advance_apply_phase(
        &self,
        journal: &caly_storage::ApplyJournalRecord,
        phase: caly_storage::ApplyPhase,
        step_index: usize,
        updated_at_unix_ms: i64,
    ) -> Result<caly_storage::ApplyJournalRecord, String> {
        run_ready(advance_apply_phase(
            self.storage.as_ref(),
            journal,
            phase,
            step_index,
            updated_at_unix_ms,
        ))?
        .map_err(|error| error.summary)
    }

    pub fn finalize_apply_persistence(
        &self,
        journal: &caly_storage::ApplyJournalRecord,
        snapshot_candidate: &caly_storage::SnapshotCandidate,
        created_at_unix_ms: i64,
    ) -> Result<FinalizedApplyExecution, String> {
        run_ready(finalize_apply_persistence(
            self.storage.as_ref(),
            journal,
            snapshot_candidate,
            created_at_unix_ms,
        ))?
        .map_err(|error| error.summary)
    }

    pub fn mark_apply_reverted(
        &self,
        journal: &caly_storage::ApplyJournalRecord,
        updated_at_unix_ms: i64,
    ) -> Result<caly_storage::ApplyJournalRecord, String> {
        run_ready(mark_apply_reverted(
            self.storage.as_ref(),
            journal,
            updated_at_unix_ms,
        ))?
        .map_err(|error| error.summary)
    }

    pub fn mark_apply_recovery_failed(
        &self,
        journal: &caly_storage::ApplyJournalRecord,
        updated_at_unix_ms: i64,
    ) -> Result<caly_storage::ApplyJournalRecord, String> {
        run_ready(mark_apply_recovery_failed(
            self.storage.as_ref(),
            journal,
            updated_at_unix_ms,
        ))?
        .map_err(|error| error.summary)
    }

    pub fn scan_recovery_state(&self) -> Result<RecoveryScanReport, String> {
        run_ready(scan_recovery_state(self.storage.as_ref()))?.map_err(|error| error.summary)
    }

    pub fn latest_last_known_good_snapshot(&self) -> Result<Option<SnapshotRecord>, String> {
        use caly_storage::SnapshotStore;
        run_ready(self.storage.latest_last_known_good())?.map_err(|error| error.summary)
    }

    pub fn drain_with_policy(&self, policy: WorkerPolicy) -> Result<WorkerDrainReport, String> {
        drain_with_policy(self, policy)
    }

    pub fn follow_job(&self, job_id: JobId) -> Result<JobFollow, String> {
        let guard = self
            .inner
            .lock()
            .map_err(|_| "engine state lock poisoned".to_owned())?;
        Ok(JobFollow {
            job: guard.jobs.get(&job_id.0).cloned(),
            lifecycle: guard.current_lifecycle(),
        })
    }

    pub fn project_job_follow(
        &self,
        job_id: JobId,
        from_event_index: Option<u64>,
    ) -> Result<Option<JobFollowProjection>, String> {
        let followed = self.follow_job(job_id)?;
        let Some(job) = followed.job else {
            return Ok(None);
        };
        let window = slice_job_events(&job, from_event_index, JobEventRetentionPolicy::default());
        let summary = summarize_job_record(&job);
        Ok(Some(JobFollowProjection {
            summary: JobFollowView {
                job_id,
                state: format!("{:?}", job.state).to_lowercase(),
                lifecycle: format!("{:?}", followed.lifecycle).to_lowercase(),
                next_event_index: window.next_index,
                retained_from_event_index: window.retained_from_index,
                reset_required: window.reset_required,
                event_count: window.events.len(),
                last_stage: summary.last_stage,
                last_stage_pct: summary.last_stage_pct,
                warning_count: summary.warning_count,
                log_count: summary.log_count,
                failure_code: summary.failure_code,
                failure_summary: summary.failure_summary,
            },
            window: Some(window),
        }))
    }

    pub fn events_since(&self, from_exclusive: Option<EventSeq>) -> Result<EventWindow, String> {
        let guard = self
            .inner
            .lock()
            .map_err(|_| "engine state lock poisoned".to_owned())?;
        let replay = guard.events.replay_from(from_exclusive);
        let window = match replay {
            ReplayWindow::Events {
                next_seq,
                retained_from,
                events,
            } => EventWindow {
                from_exclusive,
                next_seq,
                retained_from,
                reset_required: false,
                events,
            },
            ReplayWindow::ResetRequired {
                next_seq,
                retained_from,
                ..
            } => EventWindow {
                from_exclusive,
                next_seq,
                retained_from,
                reset_required: true,
                events: Vec::new(),
            },
        };
        Ok(window)
    }

    pub fn automation_overrides(&self) -> Result<Vec<(String, bool)>, String> {
        let guard = self
            .inner
            .lock()
            .map_err(|_| "engine state lock poisoned".to_owned())?;
        Ok(guard
            .automation_overrides
            .iter()
            .map(|(job_id, enabled)| (job_id.clone(), *enabled))
            .collect())
    }

    pub fn set_automation_job(&self, request: &PatchAutomationJob) -> Result<(), String> {
        let mut guard = self
            .inner
            .lock()
            .map_err(|_| "engine state lock poisoned".to_owned())?;
        guard
            .automation_overrides
            .insert(request.job_id.clone(), request.enabled);
        Ok(())
    }

    pub fn idempotency_status(
        &self,
        actor: caly_common::Actor,
        key: &IdempotencyKey,
    ) -> Result<Option<IdempotencyStatus>, String> {
        let guard = self
            .inner
            .lock()
            .map_err(|_| "engine state lock poisoned".to_owned())?;
        Ok(guard.idempotency.get(actor, key).map(|record| record.status.clone()))
    }
}

#[derive(Default)]
struct JobRecordSummary {
    last_stage: Option<String>,
    last_stage_pct: Option<u8>,
    warning_count: usize,
    log_count: usize,
    failure_code: Option<String>,
    failure_summary: Option<String>,
}

fn summarize_job_record(job: &JobRecord) -> JobRecordSummary {
    let mut summary = JobRecordSummary::default();
    for event in &job.events {
        match event {
            JobEvent::Stage { stage, pct } => {
                summary.last_stage = Some(stage.clone());
                summary.last_stage_pct = *pct;
            }
            JobEvent::Warning { .. } => {
                summary.warning_count = summary.warning_count.saturating_add(1);
            }
            JobEvent::Log { .. } => {
                summary.log_count = summary.log_count.saturating_add(1);
            }
            JobEvent::Failed { error } => {
                summary.failure_code = Some(error.code.as_str().to_owned());
                summary.failure_summary = Some(error.summary.clone());
            }
            JobEvent::Done { .. } => {}
        }
    }
    summary
}
