use caly_api::{Accepted, EstimatedImpact, JobId};
use caly_plan::{ApplyPlan, EffectPlan};
use caly_storage::{ApplyJournalStore, JournalStore, ObjectStore, RevisionStore, SnapshotStore};

use crate::command::Command;
use crate::job::{JobRecord, JobState};

#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub enum CoordinationDomain {
    Config,
    Core,
    Network,
    Subscription,
    Test,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct CoordinationLockSet {
    pub domains: Vec<CoordinationDomain>,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct CoordinationPlan {
    pub apply_plan: Option<ApplyPlan>,
    pub effect_plan: Option<EffectPlan>,
    pub lock_set: CoordinationLockSet,
}

pub trait CoordinatorStorage:
    ObjectStore + RevisionStore + SnapshotStore + JournalStore + ApplyJournalStore + Send + Sync + 'static
{
}

impl<T> CoordinatorStorage for T where
    T: ObjectStore
        + RevisionStore
        + SnapshotStore
        + JournalStore
        + ApplyJournalStore
        + Send
        + Sync
        + 'static
{
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct AcceptedCommand {
    pub accepted: Accepted,
    pub job: JobRecord,
}

pub fn accept_command(job_id: JobId, state_revision: u64, impact: EstimatedImpact) -> AcceptedCommand {
    AcceptedCommand {
        accepted: Accepted {
            job_id,
            state_revision,
            estimated_impact: impact,
        },
        job: JobRecord {
            id: job_id,
            state: JobState::Accepted,
            revision: state_revision,
            events: Vec::new(),
        },
    }
}

pub fn default_lock_set_for_command(command: &Command) -> CoordinationLockSet {
    use crate::command::CommandKind;
    let domains = match &command.kind {
        CommandKind::SystemShutdown => vec![CoordinationDomain::Core, CoordinationDomain::Network],
        CommandKind::ProfileApply(_) | CommandKind::ProfileRollback(_) => {
            vec![CoordinationDomain::Config, CoordinationDomain::Core, CoordinationDomain::Network]
        }
        CommandKind::SourceUpdate { .. } => vec![CoordinationDomain::Subscription, CoordinationDomain::Config],
        CommandKind::ProxySelect { .. } => vec![CoordinationDomain::Config, CoordinationDomain::Core],
        CommandKind::ProxyTestDelay { .. } => vec![CoordinationDomain::Core],
        CommandKind::DnsFlushCache => vec![CoordinationDomain::Core, CoordinationDomain::Network],
        CommandKind::RuntimeCloseConnection { .. } => vec![CoordinationDomain::Core],
        CommandKind::NetworkRepair => vec![CoordinationDomain::Network],
        CommandKind::DiagnosticsBundle => vec![],
        CommandKind::AutomationPatch(_) => vec![CoordinationDomain::Config],
    };

    CoordinationLockSet { domains }
}
