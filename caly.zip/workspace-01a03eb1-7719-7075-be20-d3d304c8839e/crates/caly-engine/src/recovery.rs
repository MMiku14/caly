use std::future::Future;
use std::pin::pin;
use std::sync::Arc;
use std::task::{Context, Poll, Wake, Waker};

use caly_storage::{
    advance_apply_journal_step, build_recovery_scan_report, mark_apply_journal_state,
    snapshot_record_from_candidate, ApplyJournalRecord, ApplyJournalState, ApplyPhase,
    ApplyStorageProjection, ApplyJournalStore, JournalRecordId, JournalStore, ObjectStore,
    RevisionStore, SnapshotStore, StorageError,
};

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct PersistedApplyExecution {
    pub journal: ApplyJournalRecord,
    pub artifact_digest: String,
    pub runtime_path: String,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct FinalizedApplyExecution {
    pub journal: ApplyJournalRecord,
    pub snapshot_id: String,
    pub revision_id: String,
}

pub async fn begin_apply_persistence<S>(
    storage: &S,
    projection: ApplyStorageProjection,
) -> Result<PersistedApplyExecution, StorageError>
where
    S: ObjectStore + ApplyJournalStore + Send + Sync + 'static,
{
    let object = storage.put(projection.artifact_object.clone()).await?;
    storage.materialize(projection.materialization.clone()).await?;
    storage
        .put_apply_journal(projection.apply_journal.clone())
        .await?;
    Ok(PersistedApplyExecution {
        journal: projection.apply_journal,
        artifact_digest: object.digest.0,
        runtime_path: projection.materialization.runtime_path,
    })
}

pub async fn advance_apply_phase<S>(
    storage: &S,
    journal: &ApplyJournalRecord,
    phase: ApplyPhase,
    step_index: usize,
    updated_at_unix_ms: i64,
) -> Result<ApplyJournalRecord, StorageError>
where
    S: ApplyJournalStore + Send + Sync + 'static,
{
    let advanced = advance_apply_journal_step(
        journal,
        phase,
        step_index,
        journal.net_effect_started || matches!(phase, ApplyPhase::Cutover | ApplyPhase::Finalize),
        journal.core_cutover_started || matches!(phase, ApplyPhase::Cutover | ApplyPhase::Finalize),
        updated_at_unix_ms,
    );
    storage.put_apply_journal(advanced.clone()).await?;
    Ok(advanced)
}

pub async fn finalize_apply_persistence<S>(
    storage: &S,
    journal: &ApplyJournalRecord,
    snapshot_candidate: &caly_storage::SnapshotCandidate,
    created_at_unix_ms: i64,
) -> Result<FinalizedApplyExecution, StorageError>
where
    S: SnapshotStore + RevisionStore + ApplyJournalStore + Send + Sync + 'static,
{
    storage
        .put_revision(caly_storage::revision_record_from_candidate(
            snapshot_candidate,
            created_at_unix_ms,
        ))
        .await?;
    storage
        .put_snapshot(snapshot_record_from_candidate(
            snapshot_candidate,
            Some(journal.journal_id.clone()),
            created_at_unix_ms,
            true,
        ))
        .await?;
    let committed = mark_apply_journal_state(
        journal,
        ApplyJournalState::Committed,
        created_at_unix_ms,
    );
    storage.put_apply_journal(committed.clone()).await?;
    Ok(FinalizedApplyExecution {
        journal: committed,
        snapshot_id: snapshot_candidate.snapshot_id.0.clone(),
        revision_id: snapshot_candidate.revision_id.0.clone(),
    })
}

pub async fn mark_apply_reverted<S>(
    storage: &S,
    journal: &ApplyJournalRecord,
    updated_at_unix_ms: i64,
) -> Result<ApplyJournalRecord, StorageError>
where
    S: ApplyJournalStore + Send + Sync + 'static,
{
    let reverted = mark_apply_journal_state(
        journal,
        ApplyJournalState::Reverted,
        updated_at_unix_ms,
    );
    storage.put_apply_journal(reverted.clone()).await?;
    Ok(reverted)
}

pub async fn mark_apply_recovery_failed<S>(
    storage: &S,
    journal: &ApplyJournalRecord,
    updated_at_unix_ms: i64,
) -> Result<ApplyJournalRecord, StorageError>
where
    S: ApplyJournalStore + Send + Sync + 'static,
{
    let failed = mark_apply_journal_state(
        journal,
        ApplyJournalState::RecoveryFailed,
        updated_at_unix_ms,
    );
    storage.put_apply_journal(failed.clone()).await?;
    Ok(failed)
}

pub async fn scan_recovery_state<S>(storage: &S) -> Result<caly_storage::RecoveryScanReport, StorageError>
where
    S: ApplyJournalStore + JournalStore + SnapshotStore + Send + Sync + 'static,
{
    let pending_apply = storage.list_pending_apply().await?;
    let pending_os = storage
        .list_pending()
        .await?
        .into_iter()
        .map(|record| record.id)
        .collect::<Vec<JournalRecordId>>();
    let latest_last_known_good = storage
        .latest_last_known_good()
        .await?
        .map(|snapshot| snapshot.id);
    Ok(build_recovery_scan_report(
        pending_apply,
        pending_os,
        latest_last_known_good,
    ))
}

pub fn run_ready<F>(future: F) -> Result<F::Output, String>
where
    F: Future,
{
    struct NoopWake;
    impl Wake for NoopWake {
        fn wake(self: Arc<Self>) {}
    }

    let waker = Waker::from(Arc::new(NoopWake));
    let mut cx = Context::from_waker(&waker);
    let mut future = pin!(future);
    match future.as_mut().poll(&mut cx) {
        Poll::Ready(value) => Ok(value),
        Poll::Pending => Err("future unexpectedly pending in immediate execution path".to_owned()),
    }
}
