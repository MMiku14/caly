#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub struct EnginePolicies {
    pub queue_capacity: usize,
    pub event_log_capacity: usize,
    pub job_event_retention: usize,
    pub worker_max_cycles_per_drain: usize,
}

impl EnginePolicies {
    pub const fn new(
        queue_capacity: usize,
        event_log_capacity: usize,
        job_event_retention: usize,
        worker_max_cycles_per_drain: usize,
    ) -> Self {
        Self {
            queue_capacity,
            event_log_capacity,
            job_event_retention,
            worker_max_cycles_per_drain,
        }
    }
}

impl Default for EnginePolicies {
    fn default() -> Self {
        Self {
            queue_capacity: 256,
            event_log_capacity: 256,
            job_event_retention: 128,
            worker_max_cycles_per_drain: 64,
        }
    }
}
