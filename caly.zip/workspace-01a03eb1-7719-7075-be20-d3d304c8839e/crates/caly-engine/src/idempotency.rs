use std::collections::BTreeMap;

use caly_common::Actor;

use crate::command::{CommandId, IdempotencyKey};
use crate::job::JobOutcome;

#[derive(Clone, Debug, Eq, PartialEq, Ord, PartialOrd)]
pub struct ActorKey {
    pub actor: Actor,
    pub idempotency_key: String,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub enum IdempotencyStatus {
    Running,
    Finished(JobOutcome),
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct IdempotencyRecord {
    pub command_id: CommandId,
    pub job_id: u64,
    pub status: IdempotencyStatus,
}

#[derive(Clone, Debug, Default, Eq, PartialEq)]
pub struct IdempotencyTable {
    entries: BTreeMap<ActorKey, IdempotencyRecord>,
}

impl IdempotencyTable {
    pub fn make_key(actor: Actor, key: &IdempotencyKey) -> ActorKey {
        ActorKey {
            actor,
            idempotency_key: key.0.clone(),
        }
    }

    pub fn put_running(
        &mut self,
        actor: Actor,
        key: &IdempotencyKey,
        command_id: CommandId,
        job_id: u64,
    ) {
        self.entries.insert(
            Self::make_key(actor, key),
            IdempotencyRecord {
                command_id,
                job_id,
                status: IdempotencyStatus::Running,
            },
        );
    }

    pub fn mark_finished(&mut self, actor: Actor, key: &IdempotencyKey, outcome: JobOutcome) {
        if let Some(record) = self.entries.get_mut(&Self::make_key(actor, key)) {
            record.status = IdempotencyStatus::Finished(outcome);
        }
    }

    pub fn get(&self, actor: Actor, key: &IdempotencyKey) -> Option<&IdempotencyRecord> {
        self.entries.get(&Self::make_key(actor, key))
    }
}
