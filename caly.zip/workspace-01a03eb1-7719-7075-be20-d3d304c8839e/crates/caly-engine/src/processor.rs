use caly_api::{Accepted, EstimatedImpact};

use crate::command::Command;
use crate::coordinator::accept_command;
use crate::dispatch::{classify_command, DispatchDecision};
use crate::event::{EventKind, EventPayload};
use crate::job::{JobEvent, JobOutcome, JobState};
use crate::overload::OverloadReport;
use crate::state::{EnqueueResult, EngineLifecycle, EngineState, QueuedCommand};

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct ProcessedCommand {
    pub accepted: Accepted,
    pub dispatch: DispatchDecision,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct SubmitRejected {
    pub reason: String,
    pub overload: Option<OverloadReport>,
}

pub fn submit_command(state: &mut EngineState, command: Command) -> Result<ProcessedCommand, SubmitRejected> {
    let job_id = state.next_job_id();
    let revision = state.bump_generation().0;
    let dispatch = classify_command(&command);
    let accepted = accept_command(job_id, revision, dispatch.estimated_impact);

    match state.enqueue(job_id, command.clone()) {
        EnqueueResult::Accepted => {
            state.insert_job(accepted.job.clone());
            state.events.push(
                EventKind::CommandAccepted,
                Some(command.id.0.clone()),
                EventPayload::CommandAccepted {
                    job_id,
                    revision,
                },
            );
            Ok(ProcessedCommand {
                accepted: accepted.accepted,
                dispatch,
            })
        }
        EnqueueResult::RejectedFull { max_len } => {
            let overload = OverloadReport::queue_full(max_len);
            state.events.push(
                EventKind::CommandRejected,
                Some(command.id.0.clone()),
                EventPayload::CommandRejected {
                    reason: overload.summary.clone(),
                },
            );
            Err(SubmitRejected {
                reason: overload.summary.clone(),
                overload: Some(overload),
            })
        }
    }
}

pub fn poll_next_command(state: &mut EngineState) -> Option<QueuedCommand> {
    let queued = state.dequeue_next()?;
    state.set_lifecycle(EngineLifecycle::Busy);
    state.mark_job_state(queued.job_id, JobState::Queued);
    Some(queued)
}

pub fn mark_running(state: &mut EngineState, queued: &QueuedCommand) {
    state.mark_job_state(queued.job_id, JobState::Running);
    if let Some(job) = state.get_job_mut(queued.job_id) {
        job.events.push(JobEvent::Stage {
            stage: "running".to_owned(),
            pct: Some(0),
        });
    }
    state.events.push(
        EventKind::JobUpdated,
        Some(queued.command.id.0.clone()),
        EventPayload::JobUpdated {
            job_id: queued.job_id,
            state: "running".to_owned(),
        },
    );
}

pub fn mark_finished(
    state: &mut EngineState,
    queued: &QueuedCommand,
    outcome: JobOutcome,
    impact: EstimatedImpact,
) {
    let next_state = match outcome {
        JobOutcome::Succeeded => JobState::Completed,
        JobOutcome::Failed => JobState::Failed,
        JobOutcome::Cancelled => JobState::Cancelled,
        JobOutcome::TimedOut => JobState::TimedOut,
    };

    let bumped_revision = match impact {
        EstimatedImpact::Noop | EstimatedImpact::ReadOnly => None,
        _ => Some(state.bump_generation().0),
    };

    state.mark_job_state(queued.job_id, next_state);
    if let Some(job) = state.get_job_mut(queued.job_id) {
        job.events.push(JobEvent::Done { outcome });
        if let Some(revision) = bumped_revision {
            job.revision = job.revision.max(revision);
        }
    }
    state.set_lifecycle(EngineLifecycle::Idle);
    state.events.push(
        EventKind::JobUpdated,
        Some(queued.command.id.0.clone()),
        EventPayload::JobUpdated {
            job_id: queued.job_id,
            state: format!("{:?}", next_state).to_lowercase(),
        },
    );
}
