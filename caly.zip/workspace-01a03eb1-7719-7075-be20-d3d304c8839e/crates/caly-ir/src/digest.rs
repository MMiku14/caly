#[derive(Clone, Debug, Eq, PartialEq, Ord, PartialOrd, Hash)]
pub struct Digest(pub String);

#[derive(Clone, Debug, Eq, PartialEq, Ord, PartialOrd, Hash)]
pub struct SemanticDigest(pub String);

#[derive(Clone, Debug, Eq, PartialEq, Ord, PartialOrd, Hash)]
pub struct ArtifactDigest(pub String);

pub trait StableDigest {
    fn stable_digest(&self) -> Digest;
}

impl StableDigest for str {
    fn stable_digest(&self) -> Digest {
        Digest(self.to_owned())
    }
}

impl StableDigest for String {
    fn stable_digest(&self) -> Digest {
        Digest(self.clone())
    }
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct StableBytes {
    pub bytes: Vec<u8>,
}

impl StableBytes {
    pub fn new(bytes: Vec<u8>) -> Self {
        Self { bytes }
    }

    pub fn len(&self) -> usize {
        self.bytes.len()
    }

    pub fn is_empty(&self) -> bool {
        self.bytes.is_empty()
    }
}
