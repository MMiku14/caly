macro_rules! define_id {
    ($name:ident) => {
        #[derive(Clone, Debug, Eq, PartialEq, Ord, PartialOrd, Hash)]
        pub struct $name(pub String);

        impl $name {
            pub fn new(value: impl Into<String>) -> Self {
                Self(value.into())
            }
        }
    };
}

define_id!(ProfileId);
define_id!(SourceId);
define_id!(NodeId);
define_id!(GroupId);
define_id!(RuleId);
define_id!(RuleSetId);
define_id!(OverrideId);
define_id!(CoreInstallId);
define_id!(SnapshotId);
define_id!(CommandId);
define_id!(RevisionId);
define_id!(InboundId);
define_id!(OutboundId);
define_id!(ExtensionKey);
