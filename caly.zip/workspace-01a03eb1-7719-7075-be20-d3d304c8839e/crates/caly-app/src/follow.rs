use caly_api::{JobFollowRequest, JobId, RuntimeSubscription};
use caly_ipc::{StreamFrame, StreamPayload};

use crate::remote::{RemoteSessionClient, RemoteTransport};

#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub enum FollowMode {
    Query,
    Stream,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct FollowSummary {
    pub job_id: JobId,
    pub mode: FollowMode,
    pub lines: Vec<String>,
    pub next_event_index: Option<u64>,
    pub reset_required: bool,
}

pub fn summarize_stream_frames(job_id: JobId, frames: &[StreamFrame]) -> FollowSummary {
    let mut lines = Vec::new();
    let mut next_event_index = None;
    let mut reset_required = false;
    for frame in frames {
        next_event_index = Some(frame.seq.saturating_add(1));
        match &frame.payload {
            StreamPayload::Reset { reason } => {
                lines.push(format!("job={} reset={:?}", job_id.0, reason));
                reset_required = true;
            }
            StreamPayload::JobStage { job_id, stage, pct } => {
                lines.push(format!("job={} stage={} pct={:?}", job_id.0, stage, pct));
            }
            StreamPayload::JobWarning { job_id, message } => {
                lines.push(format!("job={} warning={}", job_id.0, message));
            }
            StreamPayload::JobLog { job_id, level, message } => {
                lines.push(format!("job={} log[{}]={}", job_id.0, level, message));
            }
            StreamPayload::JobFailed {
                job_id,
                code,
                summary,
                remediation,
            } => {
                lines.push(format!("job={} failed code={} summary={}", job_id.0, code, summary));
                if let Some(remediation) = remediation {
                    lines.push(format!("job={} remediation={}", job_id.0, remediation));
                }
            }
            StreamPayload::JobDone { job_id, outcome } => {
                lines.push(format!("job={} done={:?}", job_id.0, outcome));
            }
            StreamPayload::CommandAccepted { job_id, revision } => {
                lines.push(format!("command accepted job={} revision={}", job_id.0, revision));
            }
            StreamPayload::CommandRejected { reason } => {
                lines.push(format!("command rejected reason={}", reason));
            }
            StreamPayload::RuntimeState {
                active_profile,
                active_core,
                active_snapshot,
                state_revision,
                summary,
            } => lines.push(format!(
                "runtime summary={} profile={:?} core={:?} snapshot={:?} rev={}",
                summary, active_profile, active_core, active_snapshot, state_revision
            )),
            StreamPayload::DeploymentEvent { summary } => {
                lines.push(format!("deployment event={}", summary));
            }
            StreamPayload::SnapshotCommitted { snapshot_id } => {
                lines.push(format!("snapshot committed={}", snapshot_id));
            }
            StreamPayload::RecoveryEvent { summary } => {
                lines.push(format!("recovery event={}", summary));
            }
            StreamPayload::SnapshotJson(value) => lines.push(format!("snapshot: {}", value)),
            StreamPayload::PatchJson(value) => lines.push(format!("patch: {}", value)),
        }
    }

    FollowSummary {
        job_id,
        mode: FollowMode::Stream,
        lines,
        next_event_index,
        reset_required,
    }
}

pub fn follow_job_once_query<T: RemoteTransport>(
    client: &mut RemoteSessionClient<T>,
    job_id: JobId,
    from_event_index: Option<u64>,
) -> Result<FollowSummary, String> {
    let view = client.follow_job_query(job_id, from_event_index)?;
    Ok(FollowSummary {
        job_id,
        mode: FollowMode::Query,
        lines: vec![format!(
            "job={} state={} lifecycle={} next={} retained_from={} reset_required={} events={} last_stage={:?} last_stage_pct={:?} warnings={} logs={} failure_code={:?} failure_summary={:?}",
            view.job_id.0,
            view.state,
            view.lifecycle,
            view.next_event_index,
            view.retained_from_event_index,
            view.reset_required,
            view.event_count,
            view.last_stage,
            view.last_stage_pct,
            view.warning_count,
            view.log_count,
            view.failure_code,
            view.failure_summary,
        )],
        next_event_index: Some(view.next_event_index),
        reset_required: view.reset_required,
    })
}

pub fn follow_job_once_stream<T: RemoteTransport>(
    client: &mut RemoteSessionClient<T>,
    job_id: JobId,
    from_event_index: Option<u64>,
) -> Result<FollowSummary, String> {
    let opened = client.open_job_follow_stream(JobFollowRequest {
        job_id,
        from_event_index,
    })?;
    let frames = client.pull_stream_once(opened.stream_id, from_event_index)?;
    summarize_stream_frames(job_id, &frames).pipe(Ok)
}

trait Pipe: Sized {
    fn pipe<R>(self, f: impl FnOnce(Self) -> R) -> R {
        f(self)
    }
}
impl<T> Pipe for T {}

pub fn open_runtime_dashboard<T: RemoteTransport>(
    client: &mut RemoteSessionClient<T>,
) -> Result<caly_api::WatchOpened, String> {
    client.open_runtime_stream(RuntimeSubscription::Dashboard)
}
