use caly_api::{JobFollowRequest, JobId, RuntimeSubscription};
use caly_ipc::StreamPayload;
use caly_daemon::{
    DaemonApp, DaemonBootstrapConfig, LocalFacade, LoopbackHarness, LoopbackHarnessConfig,
};

use crate::contract::{
    run_basic_loopback_parity, run_follow_smoke, run_job_follow_contract,
    run_loopback_remote_contract, run_system_contract, ContractReport,
};
use crate::follow::{follow_job_once_query, follow_job_once_stream};
use crate::loopback::build_loopback_remote_client;
use crate::remote_facade::RemoteFacade;
use crate::wire_probe::run_basic_wire_probe;

#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub enum ScenarioStatus {
    Passed,
    Failed,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct ScenarioEntry {
    pub name: String,
    pub status: ScenarioStatus,
    pub detail: String,
}

#[derive(Clone, Debug, Default, Eq, PartialEq)]
pub struct ScenarioSuite {
    pub entries: Vec<ScenarioEntry>,
}

impl ScenarioSuite {
    pub fn push(&mut self, name: impl Into<String>, status: ScenarioStatus, detail: impl Into<String>) {
        self.entries.push(ScenarioEntry {
            name: name.into(),
            status,
            detail: detail.into(),
        });
    }

    pub fn all_passed(&self) -> bool {
        self.entries
            .iter()
            .all(|entry| matches!(entry.status, ScenarioStatus::Passed))
    }

    pub fn extend_contract(&mut self, prefix: &str, report: ContractReport) {
        for case in report.cases {
            self.push(
                format!("{}.{}", prefix, case.name),
                if case.passed {
                    ScenarioStatus::Passed
                } else {
                    ScenarioStatus::Failed
                },
                case.detail,
            );
        }
    }
}

pub fn run_handshake_scenario() -> Result<ScenarioSuite, String> {
    let mut suite = ScenarioSuite::default();
    let mut harness = LoopbackHarness::new(LoopbackHarnessConfig::default());
    harness.handshake()?;
    let snapshot = harness.snapshot();
    suite.push(
        "handshake.active-client-session",
        if matches!(snapshot.client_state, caly_ipc::ClientSessionState::Active) {
            ScenarioStatus::Passed
        } else {
            ScenarioStatus::Failed
        },
        format!("snapshot={:?}", snapshot),
    );
    Ok(suite)
}

pub fn run_runtime_watch_scenario() -> Result<ScenarioSuite, String> {
    let mut suite = ScenarioSuite::default();
    let mut harness = LoopbackHarness::new(LoopbackHarnessConfig::default());
    harness.handshake()?;
    let accepted = harness.submit_apply(
        caly_api::ApplyRequest {
            profile_id: caly_api::ProfileId("runtime-watch-scenario".to_owned()),
            dry_run: false,
            strict: false,
        },
        Some("runtime-watch-scenario".to_owned()),
    )?;
    let processed = harness.process_next_job()?;
    let opened = harness.open_runtime_stream(RuntimeSubscription::Dashboard)?;
    let frames = harness.follow_stream(opened.stream_id, None)?;
    let has_command_accepted = frames.iter().any(|frame| {
        matches!(frame.payload, StreamPayload::CommandAccepted { .. })
    });
    let has_runtime_state = frames.iter().any(|frame| {
        matches!(frame.payload, StreamPayload::RuntimeState { .. })
    });
    let has_deployment_event = frames.iter().any(|frame| {
        matches!(frame.payload, StreamPayload::DeploymentEvent { .. })
    });
    let has_snapshot_event = frames.iter().any(|frame| {
        matches!(frame.payload, StreamPayload::SnapshotCommitted { .. })
    });
    let ack_result = harness.ack_stream(opened.stream_id, 0);
    suite.push(
        "runtime.watch.open",
        if processed {
            ScenarioStatus::Passed
        } else {
            ScenarioStatus::Failed
        },
        format!("accepted_job={} stream_id={} frames={}", accepted.job_id.0, opened.stream_id.0, frames.len()),
    );
    suite.push(
        "runtime.watch.structured-command-accepted",
        if has_command_accepted {
            ScenarioStatus::Passed
        } else {
            ScenarioStatus::Failed
        },
        format!("frames={:?}", frames),
    );
    suite.push(
        "runtime.watch.structured-runtime-state",
        if has_runtime_state {
            ScenarioStatus::Passed
        } else {
            ScenarioStatus::Failed
        },
        format!("frames={:?}", frames),
    );
    suite.push(
        "runtime.watch.structured-deployment",
        if has_deployment_event {
            ScenarioStatus::Passed
        } else {
            ScenarioStatus::Failed
        },
        format!("frames={:?}", frames),
    );
    suite.push(
        "runtime.watch.structured-snapshot",
        if has_snapshot_event {
            ScenarioStatus::Passed
        } else {
            ScenarioStatus::Failed
        },
        format!("frames={:?}", frames),
    );
    suite.push(
        "runtime.watch.ack-path",
        if ack_result.is_ok() {
            ScenarioStatus::Passed
        } else {
            ScenarioStatus::Failed
        },
        format!("ack_result={:?}", ack_result),
    );
    Ok(suite)
}

pub fn run_job_follow_query_stream_scenario(_job_id: JobId) -> Result<ScenarioSuite, String> {
    let mut suite = ScenarioSuite::default();
    let mut remote = build_loopback_remote_client();
    remote.handshake()?;
    let accepted = remote.submit_apply(
        caly_api::ApplyRequest {
            profile_id: caly_api::ProfileId("job-follow-scenario-profile".to_owned()),
            dry_run: false,
            strict: false,
        },
        Some("job-follow-scenario".to_owned()),
    )?;
    let processed = remote.process_next_job()?;
    suite.push(
        "job-follow.process",
        if processed {
            ScenarioStatus::Passed
        } else {
            ScenarioStatus::Failed
        },
        format!("accepted_job={} processed={}", accepted.job_id.0, processed),
    );

    let query = follow_job_once_query(&mut remote, accepted.job_id, None)?;
    suite.push(
        "job-follow.query",
        if !query.reset_required && query.lines.iter().any(|line| line.contains("state=completed")) {
            ScenarioStatus::Passed
        } else {
            ScenarioStatus::Failed
        },
        format!("summary={:?}", query),
    );

    let stream = follow_job_once_stream(&mut remote, accepted.job_id, None)?;
    suite.push(
        "job-follow.stream",
        if !stream.reset_required && !stream.lines.is_empty() {
            ScenarioStatus::Passed
        } else {
            ScenarioStatus::Failed
        },
        format!("summary={:?}", stream),
    );

    Ok(suite)
}

pub fn run_wire_probe_scenario() -> Result<ScenarioSuite, String> {
    let mut suite = ScenarioSuite::default();
    let probe = run_basic_wire_probe()?;
    suite.push(
        "wire-probe.hello",
        if probe.hello_payload_len > 0 {
            ScenarioStatus::Passed
        } else {
            ScenarioStatus::Failed
        },
        format!("probe={:?}", probe),
    );
    suite.push(
        "wire-probe.response",
        if probe.response_frame_count > 0 {
            ScenarioStatus::Passed
        } else {
            ScenarioStatus::Failed
        },
        format!("probe={:?}", probe),
    );
    Ok(suite)
}

pub fn run_timeout_scenario() -> Result<ScenarioSuite, String> {
    let mut suite = ScenarioSuite::default();
    let mut harness = LoopbackHarness::new(LoopbackHarnessConfig::default());
    let result = harness.force_hello_timeout();
    suite.push(
        "session.hello-timeout",
        if result.is_ok() {
            ScenarioStatus::Passed
        } else {
            ScenarioStatus::Failed
        },
        format!("result={:?}", result),
    );
    Ok(suite)
}

pub async fn run_loopback_contract_scenario() -> Result<ScenarioSuite, String> {
    let report = run_loopback_remote_contract().await?;
    let mut suite = ScenarioSuite::default();
    suite.extend_contract("loopback-contract", report);
    Ok(suite)
}

pub fn run_apply_execution_scenario() -> Result<ScenarioSuite, String> {
    let mut suite = ScenarioSuite::default();
    let mut harness = LoopbackHarness::new(LoopbackHarnessConfig::default());
    harness.handshake()?;
    let accepted = harness.submit_apply(
        caly_api::ApplyRequest {
            profile_id: caly_api::ProfileId("apply-execution-scenario".to_owned()),
            dry_run: false,
            strict: false,
        },
        Some("apply-execution-scenario".to_owned()),
    )?;
    let processed = harness.process_next_job()?;
    let follow = harness.follow_job_query(accepted.job_id, None)?;
    let runtime = harness.runtime_status()?;
    let connections = harness.runtime_connections(caly_api::ConnectionQuery {
        page: caly_api::PageRequest {
            cursor: None,
            limit: 16,
        },
    })?;
    let close_result = if let Some(first) = connections.items.first() {
        let accepted = harness.close_connection(first.id.clone())?;
        let processed = harness.process_next_job()?;
        Some((accepted, processed))
    } else {
        None
    };
    let profiles = harness.profile_list()?;
    let active_profile = profiles.iter().find(|profile| profile.active).cloned();
    let profile_view = if let Some(active) = &active_profile {
        Some(harness.profile_get(active.id.clone())?)
    } else {
        None
    };
    let installs = harness.core_list_installs()?;
    let active_install = installs.iter().find(|install| install.active).cloned();
    let core_inspect = if let Some(active) = &active_install {
        Some(harness.core_inspect(active.id.clone())?)
    } else {
        None
    };
    let recovery = harness.recovery_status()?;

    suite.push(
        "apply.execution.processed",
        if processed {
            ScenarioStatus::Passed
        } else {
            ScenarioStatus::Failed
        },
        format!("accepted_job={} processed={}", accepted.job_id.0, processed),
    );
    suite.push(
        "apply.execution.follow-completed",
        if follow.state == "completed" {
            ScenarioStatus::Passed
        } else {
            ScenarioStatus::Failed
        },
        format!("follow={:?}", follow),
    );
    suite.push(
        "apply.execution.runtime-snapshot",
        if runtime.active_snapshot.is_some() {
            ScenarioStatus::Passed
        } else {
            ScenarioStatus::Failed
        },
        format!("runtime={:?}", runtime),
    );
    suite.push(
        "apply.execution.runtime-connections",
        if !connections.items.is_empty() {
            ScenarioStatus::Passed
        } else {
            ScenarioStatus::Failed
        },
        format!("connections={:?}", connections),
    );
    suite.push(
        "apply.execution.close-connection",
        if close_result.as_ref().map(|(_, processed)| *processed).unwrap_or(false) {
            ScenarioStatus::Passed
        } else {
            ScenarioStatus::Failed
        },
        format!("close_result={:?}", close_result),
    );
    suite.push(
        "apply.execution.profile-active",
        if active_profile.is_some() && profile_view.as_ref().map(|view| view.summary.active).unwrap_or(false) {
            ScenarioStatus::Passed
        } else {
            ScenarioStatus::Failed
        },
        format!("profiles={:?} profile_view={:?}", profiles, profile_view),
    );
    suite.push(
        "apply.execution.core-active",
        if active_install.is_some() && core_inspect.as_ref().map(|view| view.install.active).unwrap_or(false) {
            ScenarioStatus::Passed
        } else {
            ScenarioStatus::Failed
        },
        format!("installs={:?} core_inspect={:?}", installs, core_inspect),
    );
    suite.push(
        "apply.execution.recovery-view",
        if recovery.active_snapshot.is_some() && recovery.decision_count == 0 {
            ScenarioStatus::Passed
        } else {
            ScenarioStatus::Failed
        },
        format!("recovery={:?}", recovery),
    );
    Ok(suite)
}

pub fn run_support_bundle_scenario() -> Result<ScenarioSuite, String> {
    let mut suite = ScenarioSuite::default();
    let mut harness = LoopbackHarness::new(LoopbackHarnessConfig::default());
    harness.handshake()?;
    let accepted = harness.support_bundle()?;
    let processed = harness.process_next_job()?;
    let follow = harness.follow_job_query(accepted.job_id, None)?;

    suite.push(
        "support-bundle.accepted",
        if accepted.job_id.0 > 0 {
            ScenarioStatus::Passed
        } else {
            ScenarioStatus::Failed
        },
        format!("accepted={:?}", accepted),
    );
    suite.push(
        "support-bundle.processed",
        if processed {
            ScenarioStatus::Passed
        } else {
            ScenarioStatus::Failed
        },
        format!("processed={processed}"),
    );
    suite.push(
        "support-bundle.follow-visible",
        if follow.event_count > 0 {
            ScenarioStatus::Passed
        } else {
            ScenarioStatus::Failed
        },
        format!("follow={:?}", follow),
    );
    Ok(suite)
}

pub fn run_automation_scenario() -> Result<ScenarioSuite, String> {
    let mut suite = ScenarioSuite::default();
    let mut harness = LoopbackHarness::new(LoopbackHarnessConfig::default());
    harness.handshake()?;
    let before = harness.automation_list_jobs()?;
    let first = before
        .first()
        .cloned()
        .ok_or_else(|| "automation job list unexpectedly empty".to_owned())?;
    let accepted = harness.automation_patch_job(caly_api::PatchAutomationJob {
        job_id: first.id.clone(),
        enabled: !first.enabled,
    })?;
    let processed = harness.process_next_job()?;
    let after = harness.automation_list_jobs()?;
    let toggled = after
        .iter()
        .find(|job| job.id == first.id)
        .map(|job| job.enabled == !first.enabled)
        .unwrap_or(false);

    suite.push(
        "automation.patch.accepted",
        if accepted.job_id.0 > 0 {
            ScenarioStatus::Passed
        } else {
            ScenarioStatus::Failed
        },
        format!("accepted={:?}", accepted),
    );
    suite.push(
        "automation.patch.processed",
        if processed {
            ScenarioStatus::Passed
        } else {
            ScenarioStatus::Failed
        },
        format!("processed={processed}"),
    );
    suite.push(
        "automation.patch.visible",
        if toggled {
            ScenarioStatus::Passed
        } else {
            ScenarioStatus::Failed
        },
        format!("before={:?} after={:?}", before, after),
    );
    Ok(suite)
}

pub fn run_recovery_scan_scenario() -> Result<ScenarioSuite, String> {
    let mut suite = ScenarioSuite::default();
    let mut harness = LoopbackHarness::new(LoopbackHarnessConfig::default());
    harness.handshake()?;
    let decisions = harness.seed_recovery_fixture("recovery-scan-scenario")?;
    let doctor = harness.doctor(true)?;
    let runtime = harness.runtime_status()?;
    let opened = harness.open_runtime_stream(RuntimeSubscription::Dashboard)?;
    let frames = harness.follow_stream(opened.stream_id, None)?;
    let stream_has_recovery = frames.iter().any(|frame| {
        matches!(frame.payload, StreamPayload::RecoveryEvent { .. })
    });

    suite.push(
        "recovery.scan.seeded",
        if decisions > 0 {
            ScenarioStatus::Passed
        } else {
            ScenarioStatus::Failed
        },
        format!("decisions={decisions}"),
    );
    suite.push(
        "recovery.scan.doctor-visible",
        if doctor.warnings.iter().any(|line| line.contains("recovery decision")) {
            ScenarioStatus::Passed
        } else {
            ScenarioStatus::Failed
        },
        format!("doctor={:?}", doctor),
    );
    suite.push(
        "recovery.scan.runtime-visible",
        if runtime.active_snapshot.is_none() {
            ScenarioStatus::Passed
        } else {
            ScenarioStatus::Failed
        },
        format!("runtime={:?}", runtime),
    );
    suite.push(
        "recovery.scan.stream-visible",
        if stream_has_recovery {
            ScenarioStatus::Passed
        } else {
            ScenarioStatus::Failed
        },
        format!("frames={:?}", frames),
    );
    Ok(suite)
}

pub async fn run_parity_scenarios() -> Result<ScenarioSuite, String> {
    let local = LocalFacade::new(DaemonApp::bootstrap(DaemonBootstrapConfig {
        instance_id: "scenario-local-daemon".to_owned(),
        protocol_version: caly_api::ProtocolVersion { major: 1, minor: 0 },
        recover_on_start: false,
    }));

    let mut remote = build_loopback_remote_client();
    remote.handshake()?;
    let remote_facade = RemoteFacade::new(remote);

    let mut suite = ScenarioSuite::default();

    let system = run_system_contract(&local, &remote_facade)
        .await
        .map_err(|error| error.summary)?;
    suite.extend_contract("contract", system);

    let parity = run_basic_loopback_parity(&local)
        .await
        .map_err(|error| error.summary)?;
    for item in parity.items {
        suite.push(
            format!("parity.{}", item.name),
            if matches!(item.status, crate::parity::ParityStatus::Match) {
                ScenarioStatus::Passed
            } else {
                ScenarioStatus::Failed
            },
            item.detail,
        );
    }

    Ok(suite)
}

pub async fn run_job_follow_contract_scenario(job_id: JobId) -> Result<ScenarioSuite, String> {
    let local = LocalFacade::new(DaemonApp::bootstrap(DaemonBootstrapConfig {
        instance_id: "follow-contract-local".to_owned(),
        protocol_version: caly_api::ProtocolVersion { major: 1, minor: 0 },
        recover_on_start: false,
    }));
    let mut remote = build_loopback_remote_client();
    remote.handshake()?;
    let remote_facade = RemoteFacade::new(remote);
    let report = run_job_follow_contract(
        &local,
        &remote_facade,
        JobFollowRequest {
            job_id,
            from_event_index: None,
        },
    )
    .await
    .map_err(|error| error.summary)?;

    let mut suite = ScenarioSuite::default();
    suite.extend_contract("job-follow-contract", report);
    Ok(suite)
}

pub async fn run_smoke_bundle() -> Result<ScenarioSuite, String> {
    let mut suite = ScenarioSuite::default();
    for entry in run_handshake_scenario()?.entries {
        suite.entries.push(entry);
    }
    for entry in run_runtime_watch_scenario()?.entries {
        suite.entries.push(entry);
    }
    for entry in run_job_follow_query_stream_scenario(JobId(1))?.entries {
        suite.entries.push(entry);
    }
    for entry in run_wire_probe_scenario()?.entries {
        suite.entries.push(entry);
    }
    for entry in run_timeout_scenario()?.entries {
        suite.entries.push(entry);
    }
    for entry in run_apply_execution_scenario()?.entries {
        suite.entries.push(entry);
    }
    for entry in run_support_bundle_scenario()?.entries {
        suite.entries.push(entry);
    }
    for entry in run_automation_scenario()?.entries {
        suite.entries.push(entry);
    }
    for entry in run_recovery_scan_scenario()?.entries {
        suite.entries.push(entry);
    }
    for entry in run_loopback_contract_scenario().await?.entries {
        suite.entries.push(entry);
    }
    for entry in run_parity_scenarios().await?.entries {
        suite.entries.push(entry);
    }
    for entry in run_job_follow_contract_scenario(JobId(1)).await?.entries {
        suite.entries.push(entry);
    }
    let smoke = run_follow_smoke().await?;
    suite.push(
        "follow.smoke",
        if !smoke.reset_required {
            ScenarioStatus::Passed
        } else {
            ScenarioStatus::Failed
        },
        format!("summary={:?}", smoke),
    );
    Ok(suite)
}
