use std::sync::Arc;

use caly_api::{CalyFacade, DiagnosticsFacet, ProfileFacet, RuntimeFacet, SystemFacet};
use caly_daemon::{DaemonApp, LocalFacade};

#[derive(Clone)]
pub struct LocalAppClient {
    facade: LocalFacade,
}

impl LocalAppClient {
    pub fn new(app: DaemonApp) -> Self {
        Self {
            facade: LocalFacade::new(app),
        }
    }

    pub fn facade(&self) -> &LocalFacade {
        &self.facade
    }

    pub fn system(&self) -> Arc<dyn SystemFacet> {
        self.facade.system()
    }

    pub fn profile(&self) -> Arc<dyn ProfileFacet> {
        self.facade.profile()
    }

    pub fn runtime(&self) -> Arc<dyn RuntimeFacet> {
        self.facade.runtime()
    }

    pub fn diagnostics(&self) -> Arc<dyn DiagnosticsFacet> {
        self.facade.diagnostics()
    }
}
