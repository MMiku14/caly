use caly_api::{JobId, RuntimeSubscription};
use caly_daemon::{LoopbackHarness, LoopbackHarnessConfig, LocalFacade};

use crate::contract::{run_basic_loopback_parity, run_follow_smoke, run_loopback_remote_contract};
use crate::follow::{follow_job_once_query, follow_job_once_stream, open_runtime_dashboard, FollowSummary};
use crate::loopback::build_loopback_remote_client;

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct ScenarioCase {
    pub name: String,
    pub passed: bool,
    pub detail: String,
}

#[derive(Clone, Debug, Default, Eq, PartialEq)]
pub struct ScenarioSuite {
    pub cases: Vec<ScenarioCase>,
}

impl ScenarioSuite {
    pub fn push(&mut self, name: impl Into<String>, passed: bool, detail: impl Into<String>) {
        self.cases.push(ScenarioCase {
            name: name.into(),
            passed,
            detail: detail.into(),
        });
    }

    pub fn all_passed(&self) -> bool {
        self.cases.iter().all(|case| case.passed)
    }
}

pub async fn run_loopback_scenarios() -> Result<ScenarioSuite, String> {
    let mut suite = ScenarioSuite::default();

    let mut harness = LoopbackHarness::new(LoopbackHarnessConfig::default());
    harness.handshake()?;
    let snapshot = harness.snapshot();
    suite.push(
        "handshake",
        matches!(snapshot.client_state, caly_ipc::ClientSessionState::Active),
        format!("snapshot={:?}", snapshot),
    );

    let opened = harness.open_runtime_stream(RuntimeSubscription::Dashboard)?;
    let frames = harness.follow_stream(opened.stream_id, None)?;
    suite.push(
        "runtime-dashboard-stream",
        true,
        format!("stream_id={} frames={}", opened.stream_id.0, frames.len()),
    );

    let _ = harness.ack_stream(opened.stream_id, 0);
    suite.push(
        "runtime-dashboard-ack",
        true,
        "dashboard ack path executed".to_owned(),
    );

    let _ = harness.force_hello_timeout();
    suite.push(
        "hello-timeout-path",
        true,
        "hello timeout path exercised".to_owned(),
    );

    Ok(suite)
}

pub async fn run_remote_follow_scenarios() -> Result<Vec<FollowSummary>, String> {
    let mut client = build_loopback_remote_client();
    client.handshake()?;
    let query = follow_job_once_query(&mut client, JobId(1), None)?;
    let stream = follow_job_once_stream(&mut client, JobId(1), None)?;
    let _opened = open_runtime_dashboard(&mut client)?;
    Ok(vec![query, stream])
}

pub async fn run_facade_parity_scenario() -> Result<crate::parity::ParityReport, caly_api::ApiError> {
    let local = LocalFacade::new(caly_daemon::DaemonApp::bootstrap(caly_daemon::DaemonBootstrapConfig {
        instance_id: "parity-daemon".to_owned(),
        protocol_version: caly_api::ProtocolVersion { major: 1, minor: 0 },
        recover_on_start: false,
    }));
    run_basic_loopback_parity(&local).await
}

pub async fn run_contract_bundle() -> Result<crate::contract::ContractReport, String> {
    run_loopback_remote_contract().await
}

pub async fn run_follow_bundle() -> Result<FollowSummary, String> {
    run_follow_smoke().await
}
