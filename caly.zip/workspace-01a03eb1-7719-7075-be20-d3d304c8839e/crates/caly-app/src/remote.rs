use caly_api::{
    Accepted, ApplyRequest, AutomationJobView, ConnectionId, ConnectionPage, ConnectionQuery,
    CoreInspection, CoreInstallView, DiagnosticsOp, DoctorReport, DoctorRequest,
    JobFollowRequest, JobId, Operation, OperationResult, PatchAutomationJob, ProfileSummary,
    ProfileView, RecoveryStatusView, RuntimeOp, RuntimeStatus, RuntimeSubscription, StreamId,
    WatchOpened,
};
use caly_ipc::{
    make_header, ClientFrame, ClientHello, ClientSession, ClientSessionConfig, Compression,
    Encoding, ServerFrame, ServerHelloAck, StreamFrame,
};

pub trait RemoteTransport {
    fn send_hello(&mut self, hello: ClientHello) -> Result<ServerHelloAck, String>;
    fn send_frame(&mut self, frame: ClientFrame, is_control_message: bool) -> Result<Vec<ServerFrame>, String>;
    fn pull_stream(&mut self, stream_id: StreamId, from_seq_exclusive: Option<u64>) -> Result<Vec<StreamFrame>, String>;
    fn close(&mut self) -> Result<(), String>;

    fn process_next_job(&mut self) -> Result<bool, String> {
        Ok(false)
    }

    fn seed_recovery_fixture(&mut self, _profile_id: String) -> Result<usize, String> {
        Ok(0)
    }
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct RemoteSnapshot {
    pub session_state: caly_ipc::ClientSessionState,
    pub open_stream_count: usize,
    pub daemon_instance_id: Option<String>,
}

pub struct RemoteSessionClient<T: RemoteTransport> {
    pub session: ClientSession,
    pub transport: T,
}

impl<T: RemoteTransport> RemoteSessionClient<T> {
    pub fn new(config: ClientSessionConfig, transport: T) -> Self {
        Self {
            session: ClientSession::new(config),
            transport,
        }
    }

    pub fn handshake(&mut self) -> Result<(), String> {
        let hello = self.session.build_hello();
        let ack = self.transport.send_hello(hello)?;
        self.session.apply_hello_ack(&ack).map_err(|e| e.summary)
    }

    pub fn send_operation(
        &mut self,
        trace: impl Into<String>,
        operation: Operation,
        idempotency_key: Option<String>,
    ) -> Result<OperationResult, String> {
        let frame = self
            .session
            .make_request(trace, operation, Some(30_000), None, idempotency_key)
            .map_err(|e| e.summary)?;
        let frames = self.transport.send_frame(frame, true)?;
        let mut result = None;
        for frame in frames {
            self.session.observe_server_frame(&frame).map_err(|e| e.summary)?;
            if let ServerFrame::Response(response) = frame {
                result = Some(response.result.map_err(|e| e.summary)?);
            }
        }
        result.ok_or_else(|| "remote operation returned no response frame".to_owned())
    }

    pub fn submit_apply(
        &mut self,
        request: ApplyRequest,
        idempotency_key: Option<String>,
    ) -> Result<Accepted, String> {
        let result = self.send_operation(
            "remote-profile-apply",
            Operation::Profile(caly_api::ProfileOp::Apply { request }),
            idempotency_key,
        )?;
        match result {
            OperationResult::Accepted(value) => Ok(value),
            other => Err(format!("unexpected apply result: {:?}", other)),
        }
    }

    pub fn open_runtime_stream(&mut self, subscription: RuntimeSubscription) -> Result<WatchOpened, String> {
        let result = self.send_operation(
            "remote-open-runtime-stream",
            Operation::Runtime(RuntimeOp::Watch {
                subscription: subscription.clone(),
            }),
            None,
        )?;
        match result {
            OperationResult::WatchOpened(opened) => {
                let kind = match subscription {
                    RuntimeSubscription::Dashboard => caly_ipc::StreamKind::Dashboard,
                    RuntimeSubscription::Traffic => caly_ipc::StreamKind::Traffic,
                    RuntimeSubscription::Logs => caly_ipc::StreamKind::Logs,
                    RuntimeSubscription::Connections => caly_ipc::StreamKind::Connections,
                };
                self.session.register_stream(opened.stream_id, kind);
                Ok(opened)
            }
            other => Err(format!("unexpected runtime stream open result: {:?}", other)),
        }
    }

    pub fn open_job_follow_stream(&mut self, request: JobFollowRequest) -> Result<WatchOpened, String> {
        let result = self.send_operation(
            "remote-open-job-follow-stream",
            Operation::Diagnostics(DiagnosticsOp::FollowJobStream { request: request.clone() }),
            None,
        )?;
        match result {
            OperationResult::WatchOpened(opened) => {
                self.session.register_stream(opened.stream_id, caly_ipc::StreamKind::Job);
                Ok(opened)
            }
            other => Err(format!("unexpected job follow stream open result: {:?}", other)),
        }
    }

    pub fn pull_stream_once(&mut self, stream_id: StreamId, from_seq_exclusive: Option<u64>) -> Result<Vec<StreamFrame>, String> {
        let frames = self.transport.pull_stream(stream_id, from_seq_exclusive)?;
        for frame in &frames {
            self.session.observe_stream_frame(frame).map_err(|e| e.summary)?;
        }
        Ok(frames)
    }

    pub fn ack_stream_if_needed(&mut self, stream_id: StreamId) -> Result<Option<ClientFrame>, String> {
        let stream = self.session.streams.get(&stream_id.0).ok_or_else(|| {
            format!("unknown stream id: {}", stream_id.0)
        })?;
        let upto = match stream.expected_resume_from() {
            Some(value) => value,
            None => return Ok(None),
        };
        let ack = self.session.make_stream_ack(stream_id, upto).map_err(|e| e.summary)?;
        Ok(Some(ack))
    }

    pub fn follow_job_query(&mut self, job_id: JobId, from_event_index: Option<u64>) -> Result<caly_api::JobFollowView, String> {
        let result = self.send_operation(
            "remote-follow-job-query",
            Operation::Diagnostics(DiagnosticsOp::FollowJob {
                request: JobFollowRequest {
                    job_id,
                    from_event_index,
                },
            }),
            None,
        )?;
        match result {
            OperationResult::JobFollow(view) => Ok(view),
            other => Err(format!("unexpected follow job query result: {:?}", other)),
        }
    }

    pub fn profile_list(&mut self) -> Result<Vec<ProfileSummary>, String> {
        let result = self.send_operation(
            "remote-profile-list",
            Operation::Profile(caly_api::ProfileOp::List),
            None,
        )?;
        match result {
            OperationResult::ProfileList(value) => Ok(value),
            other => Err(format!("unexpected profile list result: {:?}", other)),
        }
    }

    pub fn profile_get(&mut self, profile_id: caly_api::ProfileId) -> Result<ProfileView, String> {
        let result = self.send_operation(
            "remote-profile-get",
            Operation::Profile(caly_api::ProfileOp::Get { profile_id }),
            None,
        )?;
        match result {
            OperationResult::ProfileView(value) => Ok(value),
            other => Err(format!("unexpected profile get result: {:?}", other)),
        }
    }

    pub fn core_list_installs(&mut self) -> Result<Vec<CoreInstallView>, String> {
        let result = self.send_operation(
            "remote-core-list-installs",
            Operation::Core(caly_api::CoreOp::ListInstalls),
            None,
        )?;
        match result {
            OperationResult::CoreInstallList(value) => Ok(value),
            other => Err(format!("unexpected core install list result: {:?}", other)),
        }
    }

    pub fn core_inspect(&mut self, core_install_id: caly_api::CoreInstallId) -> Result<CoreInspection, String> {
        let result = self.send_operation(
            "remote-core-inspect",
            Operation::Core(caly_api::CoreOp::Inspect { core_install_id }),
            None,
        )?;
        match result {
            OperationResult::CoreInspection(value) => Ok(value),
            other => Err(format!("unexpected core inspect result: {:?}", other)),
        }
    }

    pub fn runtime_status(&mut self) -> Result<RuntimeStatus, String> {
        let result = self.send_operation(
            "remote-runtime-status",
            Operation::Runtime(RuntimeOp::Status),
            None,
        )?;
        match result {
            OperationResult::RuntimeStatus(value) => Ok(value),
            other => Err(format!("unexpected runtime status result: {:?}", other)),
        }
    }

    pub fn runtime_connections(&mut self, query: ConnectionQuery) -> Result<ConnectionPage, String> {
        let result = self.send_operation(
            "remote-runtime-connections",
            Operation::Runtime(RuntimeOp::Connections { query }),
            None,
        )?;
        match result {
            OperationResult::ConnectionPage(value) => Ok(value),
            other => Err(format!("unexpected runtime connections result: {:?}", other)),
        }
    }

    pub fn runtime_close_connection(&mut self, connection_id: ConnectionId) -> Result<Accepted, String> {
        let result = self.send_operation(
            "remote-runtime-close-connection",
            Operation::Runtime(RuntimeOp::CloseConnection { connection_id }),
            None,
        )?;
        match result {
            OperationResult::Accepted(value) => Ok(value),
            other => Err(format!("unexpected runtime close-connection result: {:?}", other)),
        }
    }

    pub fn recovery_status(&mut self) -> Result<RecoveryStatusView, String> {
        let result = self.send_operation(
            "remote-recovery-status",
            Operation::Diagnostics(DiagnosticsOp::RecoveryStatus),
            None,
        )?;
        match result {
            OperationResult::RecoveryStatus(value) => Ok(value),
            other => Err(format!("unexpected recovery status result: {:?}", other)),
        }
    }

    pub fn doctor(&mut self, include_runtime: bool) -> Result<DoctorReport, String> {
        let result = self.send_operation(
            "remote-doctor",
            Operation::Diagnostics(DiagnosticsOp::Doctor {
                request: DoctorRequest { include_runtime },
            }),
            None,
        )?;
        match result {
            OperationResult::DoctorReport(value) => Ok(value),
            other => Err(format!("unexpected doctor result: {:?}", other)),
        }
    }

    pub fn support_bundle(&mut self) -> Result<Accepted, String> {
        let result = self.send_operation(
            "remote-support-bundle",
            Operation::Diagnostics(DiagnosticsOp::SupportBundle),
            None,
        )?;
        match result {
            OperationResult::Accepted(value) => Ok(value),
            other => Err(format!("unexpected support bundle result: {:?}", other)),
        }
    }

    pub fn automation_list_jobs(&mut self) -> Result<Vec<AutomationJobView>, String> {
        let result = self.send_operation(
            "remote-automation-list",
            Operation::Automation(caly_api::AutomationOp::ListJobs),
            None,
        )?;
        match result {
            OperationResult::AutomationJobs(value) => Ok(value),
            other => Err(format!("unexpected automation list result: {:?}", other)),
        }
    }

    pub fn automation_patch_job(&mut self, request: PatchAutomationJob) -> Result<Accepted, String> {
        let result = self.send_operation(
            "remote-automation-patch",
            Operation::Automation(caly_api::AutomationOp::PatchJob { request }),
            None,
        )?;
        match result {
            OperationResult::Accepted(value) => Ok(value),
            other => Err(format!("unexpected automation patch result: {:?}", other)),
        }
    }

    pub fn process_next_job(&mut self) -> Result<bool, String> {
        self.transport.process_next_job()
    }

    pub fn seed_recovery_fixture(&mut self, profile_id: impl Into<String>) -> Result<usize, String> {
        self.transport.seed_recovery_fixture(profile_id.into())
    }

    pub fn snapshot(&self) -> RemoteSnapshot {
        let snapshot = self.session.snapshot();
        RemoteSnapshot {
            session_state: snapshot.state,
            open_stream_count: snapshot.streams.len(),
            daemon_instance_id: snapshot.daemon.map(|it| it.instance_id),
        }
    }

    pub fn encode_probe_header(&self, payload_len: usize) -> caly_ipc::FrameHeader {
        make_header(payload_len, Encoding::Json, Compression::None)
    }

    pub fn close(&mut self) -> Result<(), String> {
        self.transport.close()?;
        self.session.close();
        Ok(())
    }
}
