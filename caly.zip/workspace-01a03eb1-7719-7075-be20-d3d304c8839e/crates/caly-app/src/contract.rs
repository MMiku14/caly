use caly_api::{
    default_ctx, ApplyRequest, CalyFacade, CapabilityQuery, ConnectionQuery, JobFollowRequest,
    Operation, PageRequest, PatchAutomationJob, PipelineExplainRequest,
};
use caly_common::Actor;

use crate::follow::{follow_job_once_query, follow_job_once_stream, open_runtime_dashboard, FollowSummary};
use crate::loopback::build_loopback_remote_client;
use crate::parity::{run_basic_parity_check, ParityReport};
use crate::remote_facade::RemoteFacade;

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct ContractCase {
    pub name: String,
    pub detail: String,
    pub passed: bool,
}

#[derive(Clone, Debug, Default, Eq, PartialEq)]
pub struct ContractReport {
    pub cases: Vec<ContractCase>,
}

impl ContractReport {
    pub fn push(&mut self, name: impl Into<String>, detail: impl Into<String>, passed: bool) {
        self.cases.push(ContractCase {
            name: name.into(),
            detail: detail.into(),
            passed,
        });
    }

    pub fn all_passed(&self) -> bool {
        self.cases.iter().all(|case| case.passed)
    }
}

pub async fn run_system_contract(local: &dyn CalyFacade, remote: &dyn CalyFacade) -> Result<ContractReport, caly_api::ApiError> {
    let ctx = default_ctx("contract-system", Actor::Cli);
    let mut report = ContractReport::default();

    let local_status = local.system().status(ctx.clone()).await?;
    let remote_status = remote.system().status(ctx.clone()).await?;
    report.push(
        "system.status",
        format!("local={:?} remote={:?}", local_status, remote_status),
        local_status == remote_status,
    );

    let local_info = local.system().info(ctx.clone()).await?;
    let remote_info = remote.system().info(ctx.clone()).await?;
    report.push(
        "system.info",
        format!("local={:?} remote={:?}", local_info, remote_info),
        local_info == remote_info,
    );

    let local_profiles = local.profile().list(ctx.clone()).await?;
    let remote_profiles = remote.profile().list(ctx.clone()).await?;
    report.push(
        "profile.list",
        format!("local={:?} remote={:?}", local_profiles, remote_profiles),
        local_profiles == remote_profiles,
    );
    if let (Some(local_profile), Some(remote_profile)) = (local_profiles.first(), remote_profiles.first()) {
        let local_profile_view = local.profile().get(ctx.clone(), local_profile.id.clone()).await?;
        let remote_profile_view = remote.profile().get(ctx.clone(), remote_profile.id.clone()).await?;
        report.push(
            "profile.get",
            format!("local={:?} remote={:?}", local_profile_view, remote_profile_view),
            local_profile_view == remote_profile_view,
        );
    }

    let local_installs = local.core().list_installs(ctx.clone()).await?;
    let remote_installs = remote.core().list_installs(ctx.clone()).await?;
    report.push(
        "core.list_installs",
        format!("local={:?} remote={:?}", local_installs, remote_installs),
        local_installs == remote_installs,
    );
    if let (Some(local_install), Some(remote_install)) = (local_installs.first(), remote_installs.first()) {
        let local_inspect = local.core().inspect(ctx.clone(), local_install.id.clone()).await?;
        let remote_inspect = remote.core().inspect(ctx.clone(), remote_install.id.clone()).await?;
        report.push(
            "core.inspect",
            format!("local={:?} remote={:?}", local_inspect, remote_inspect),
            local_inspect == remote_inspect,
        );
    }

    let connection_query = ConnectionQuery {
        page: PageRequest {
            cursor: None,
            limit: 16,
        },
    };
    let local_connections = local.runtime().connections(ctx.clone(), connection_query.clone()).await?;
    let remote_connections = remote.runtime().connections(ctx.clone(), connection_query).await?;
    report.push(
        "runtime.connections",
        format!("local={:?} remote={:?}", local_connections, remote_connections),
        local_connections == remote_connections,
    );

    let plan_request = ApplyRequest {
        profile_id: caly_api::ProfileId("contract-system-profile".to_owned()),
        dry_run: true,
        strict: false,
    };
    let local_plan = local.profile().plan(ctx.clone(), plan_request.clone()).await?;
    let remote_plan = remote.profile().plan(ctx.clone(), plan_request).await?;
    report.push(
        "profile.plan",
        format!("local={:?} remote={:?}", local_plan, remote_plan),
        local_plan == remote_plan,
    );

    let local_explain = local
        .diagnostics()
        .explain_pipeline(
            ctx.clone(),
            PipelineExplainRequest {
                profile_id: caly_api::ProfileId("contract-system-profile".to_owned()),
            },
        )
        .await?;
    let remote_explain = remote
        .diagnostics()
        .explain_pipeline(
            ctx.clone(),
            PipelineExplainRequest {
                profile_id: caly_api::ProfileId("contract-system-profile".to_owned()),
            },
        )
        .await?;
    report.push(
        "diagnostics.explain_pipeline",
        format!("local={:?} remote={:?}", local_explain, remote_explain),
        local_explain == remote_explain,
    );

    let local_capability = local
        .core()
        .capabilities(
            ctx.clone(),
            CapabilityQuery {
                target: "mihomo".to_owned(),
            },
        )
        .await?;
    let remote_capability = remote
        .core()
        .capabilities(
            ctx.clone(),
            CapabilityQuery {
                target: "mihomo".to_owned(),
            },
        )
        .await?;
    report.push(
        "core.capabilities",
        format!("local={:?} remote={:?}", local_capability, remote_capability),
        local_capability == remote_capability,
    );

    let local_recovery = local.diagnostics().recovery_status(ctx.clone()).await?;
    let remote_recovery = remote.diagnostics().recovery_status(ctx.clone()).await?;
    report.push(
        "diagnostics.recovery_status",
        format!("local={:?} remote={:?}", local_recovery, remote_recovery),
        local_recovery == remote_recovery,
    );

    let local_automation = local.automation().list_jobs(ctx.clone()).await?;
    let remote_automation = remote.automation().list_jobs(ctx.clone()).await?;
    report.push(
        "automation.list_jobs",
        format!("local={:?} remote={:?}", local_automation, remote_automation),
        local_automation == remote_automation,
    );

    Ok(report)
}

pub async fn run_job_follow_contract(
    local: &dyn CalyFacade,
    remote: &dyn CalyFacade,
    request: JobFollowRequest,
) -> Result<ContractReport, caly_api::ApiError> {
    let ctx = default_ctx("contract-job-follow", Actor::Cli);
    let mut report = ContractReport::default();
    let local_view = local.diagnostics().follow_job(ctx.clone(), request.clone()).await?;
    let remote_view = remote.diagnostics().follow_job(ctx.clone(), request.clone()).await?;
    report.push(
        "diagnostics.follow_job",
        format!("local={:?} remote={:?}", local_view, remote_view),
        local_view == remote_view,
    );
    Ok(report)
}

pub async fn run_loopback_remote_contract() -> Result<ContractReport, String> {
    let mut client = build_loopback_remote_client();
    client.handshake()?;
    let mut report = ContractReport::default();

    let result = client.send_operation(
        "contract-system-status",
        Operation::System(caly_api::SystemOp::Status),
        None,
    )?;
    report.push(
        "remote.system.status",
        format!("result={:?}", result),
        matches!(result, caly_api::OperationResult::SystemStatus(_)),
    );

    let plan = client.send_operation(
        "contract-profile-plan",
        Operation::Profile(caly_api::ProfileOp::Plan {
            request: ApplyRequest {
                profile_id: caly_api::ProfileId("loopback-plan-profile".to_owned()),
                dry_run: true,
                strict: false,
            },
        }),
        None,
    )?;
    report.push(
        "remote.profile.plan",
        format!("result={:?}", plan),
        matches!(plan, caly_api::OperationResult::DeploymentPlan(_)),
    );

    let explain = client.send_operation(
        "contract-explain-pipeline",
        Operation::Diagnostics(caly_api::DiagnosticsOp::ExplainPipeline {
            request: PipelineExplainRequest {
                profile_id: caly_api::ProfileId("loopback-plan-profile".to_owned()),
            },
        }),
        None,
    )?;
    report.push(
        "remote.diagnostics.explain_pipeline",
        format!("result={:?}", explain),
        matches!(explain, caly_api::OperationResult::PipelineExplain(_)),
    );

    let capabilities = client.send_operation(
        "contract-core-capabilities",
        Operation::Core(caly_api::CoreOp::Capabilities {
            query: CapabilityQuery {
                target: "mihomo".to_owned(),
            },
        }),
        None,
    )?;
    report.push(
        "remote.core.capabilities",
        format!("result={:?}", capabilities),
        matches!(capabilities, caly_api::OperationResult::CapabilityReport(_)),
    );

    let apply = client.submit_apply(
        ApplyRequest {
            profile_id: caly_api::ProfileId("loopback-apply-profile".to_owned()),
            dry_run: false,
            strict: false,
        },
        Some("loopback-apply-contract".to_owned()),
    )?;
    report.push(
        "remote.profile.apply.accepted",
        format!("accepted={:?}", apply),
        apply.job_id.0 > 0,
    );

    let processed = client.process_next_job()?;
    report.push(
        "remote.profile.apply.processed",
        format!("processed={processed}"),
        processed,
    );

    let follow = client.follow_job_query(apply.job_id, None)?;
    report.push(
        "remote.profile.apply.follow",
        format!("follow={:?}", follow),
        follow.state == "completed",
    );

    let stream_follow = follow_job_once_stream(&mut client, apply.job_id, None)?;
    report.push(
        "remote.profile.apply.follow-stream",
        format!("stream_follow={:?}", stream_follow),
        !stream_follow.lines.is_empty(),
    );

    let runtime_status = client.runtime_status()?;
    report.push(
        "remote.runtime.status.after-apply",
        format!("runtime={:?}", runtime_status),
        runtime_status.active_snapshot.is_some(),
    );

    let connections = client.runtime_connections(ConnectionQuery {
        page: PageRequest {
            cursor: None,
            limit: 16,
        },
    })?;
    report.push(
        "remote.runtime.connections",
        format!("connections={:?}", connections),
        !connections.items.is_empty(),
    );
    if let Some(first) = connections.items.first() {
        let close = client.runtime_close_connection(first.id.clone())?;
        report.push(
            "remote.runtime.close_connection.accepted",
            format!("close={:?}", close),
            close.job_id.0 > 0,
        );
        let processed = client.process_next_job()?;
        report.push(
            "remote.runtime.close_connection.processed",
            format!("processed={processed}"),
            processed,
        );
    }

    let doctor = client.doctor(true)?;
    report.push(
        "remote.doctor.runtime",
        format!("doctor={:?}", doctor),
        !doctor.warnings.is_empty(),
    );

    let support_bundle = client.support_bundle()?;
    report.push(
        "remote.diagnostics.support_bundle.accepted",
        format!("bundle={:?}", support_bundle),
        support_bundle.job_id.0 > 0,
    );
    let processed = client.process_next_job()?;
    report.push(
        "remote.diagnostics.support_bundle.processed",
        format!("processed={processed}"),
        processed,
    );

    let automation_before = client.automation_list_jobs()?;
    report.push(
        "remote.automation.list.before",
        format!("automation={:?}", automation_before),
        !automation_before.is_empty(),
    );
    if let Some(first) = automation_before.first() {
        let patch = client.automation_patch_job(PatchAutomationJob {
            job_id: first.id.clone(),
            enabled: !first.enabled,
        })?;
        report.push(
            "remote.automation.patch.accepted",
            format!("patch={:?}", patch),
            patch.job_id.0 > 0,
        );
        let processed = client.process_next_job()?;
        report.push(
            "remote.automation.patch.processed",
            format!("processed={processed}"),
            processed,
        );
        let automation_after = client.automation_list_jobs()?;
        let toggled = automation_after
            .iter()
            .find(|job| job.id == first.id)
            .map(|job| job.enabled == !first.enabled)
            .unwrap_or(false);
        report.push(
            "remote.automation.patch.visible",
            format!("automation={:?}", automation_after),
            toggled,
        );
    }

    let recovery_seeded = client.seed_recovery_fixture("loopback-recovery-profile")?;
    report.push(
        "remote.recovery.seed",
        format!("decisions={recovery_seeded}"),
        recovery_seeded > 0,
    );

    let doctor_after_recovery = client.doctor(true)?;
    report.push(
        "remote.doctor.recovery",
        format!("doctor={:?}", doctor_after_recovery),
        doctor_after_recovery
            .warnings
            .iter()
            .any(|line| line.contains("recovery decision")),
    );

    let opened = open_runtime_dashboard(&mut client)?;
    let frames = client.pull_stream_once(opened.stream_id, None)?;
    report.push(
        "remote.runtime.watch",
        format!("stream_id={} frames={}", opened.stream_id.0, frames.len()),
        true,
    );

    Ok(report)
}

pub async fn run_basic_loopback_parity(local: &dyn CalyFacade) -> Result<ParityReport, caly_api::ApiError> {
    let mut remote = build_loopback_remote_client();
    remote.handshake().map_err(|message| {
        caly_api::ApiError::new(
            caly_api::ErrorCode::Unavailable,
            caly_api::ErrorCategory::Internal,
            true,
            message,
            caly_common::TraceId::new("loopback-parity"),
        )
    })?;
    let remote_facade = RemoteFacade::new(remote);
    run_basic_parity_check(
        local,
        &remote_facade,
        default_ctx("loopback-parity", Actor::Cli),
        None,
    )
    .await
}

pub async fn run_follow_smoke() -> Result<FollowSummary, String> {
    let mut remote = build_loopback_remote_client();
    remote.handshake()?;
    let accepted = remote.submit_apply(
        ApplyRequest {
            profile_id: caly_api::ProfileId("follow-smoke-profile".to_owned()),
            dry_run: false,
            strict: false,
        },
        Some("follow-smoke".to_owned()),
    )?;
    let _ = remote.process_next_job()?;
    follow_job_once_query(&mut remote, accepted.job_id, None)
}
