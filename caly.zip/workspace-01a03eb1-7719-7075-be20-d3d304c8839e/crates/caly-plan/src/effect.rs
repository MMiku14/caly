#[derive(Clone, Debug, Eq, PartialEq, Ord, PartialOrd, Hash)]
pub struct PlanId(pub String);

#[derive(Clone, Debug, Eq, PartialEq, Ord, PartialOrd, Hash)]
pub struct InstanceId(pub String);

#[derive(Clone, Debug, Eq, PartialEq, Ord, PartialOrd, Hash)]
pub struct NetTxnId(pub String);

#[derive(Clone, Debug, Eq, PartialEq, Ord, PartialOrd, Hash)]
pub struct SnapshotId(pub String);

#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub enum Durability {
    D0,
    D1,
    D2,
    D3,
}

#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub enum FileMode {
    ReadOnlyArtifact,
    MutableCopy,
    Executable,
}

#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub enum DeployImpact {
    Noop,
    RuntimePatch,
    Reload,
    Restart,
    RebuildAndRestart,
    NetworkChange,
}

#[derive(Clone, Debug, Default, Eq, PartialEq)]
pub struct PrivilegeSet {
    pub needs_admin: bool,
    pub needs_network_control: bool,
    pub needs_process_control: bool,
    pub needs_secret_access: bool,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct BlobRef {
    pub digest: String,
    pub size_hint: Option<u64>,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub enum DbOp {
    Put {
        table: String,
        key: String,
        value: String,
    },
    Delete {
        table: String,
        key: String,
    },
}

#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub enum CoreKind {
    Mihomo,
    SingBox,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct CoreSpec {
    pub kind: CoreKind,
    pub binary_digest: String,
    pub config_digest: String,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub enum CoreCall {
    Status,
    Reload,
    SelectProxy {
        group_id: String,
        node_id: String,
    },
    CloseConnection {
        connection_id: String,
    },
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct NetworkPlan {
    pub summary: String,
    pub requires_privilege: bool,
}

#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub enum ProbeKind {
    ApiReady,
    ConfigIdentity,
    InboundListening,
    DirectConnectivity,
    ProxyConnectivity,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct ProbeSpec {
    pub kind: ProbeKind,
    pub target: Option<String>,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub enum EffectStep {
    WriteObject {
        digest: String,
        source: BlobRef,
        durability: Durability,
    },
    MaterializeArtifact {
        digest: String,
        at: String,
        mode: FileMode,
    },
    DbTxn {
        ops: Vec<DbOp>,
    },
    SpawnCore {
        spec: CoreSpec,
    },
    StopCore {
        instance: InstanceId,
        grace_ms: u64,
    },
    CoreApiCall {
        instance: InstanceId,
        call: CoreCall,
    },
    NetApply {
        plan: NetworkPlan,
    },
    NetRevert {
        txn_id: NetTxnId,
    },
    Probe {
        probe: ProbeSpec,
        deadline_ms: u64,
    },
    MarkSnapshot {
        snapshot_id: SnapshotId,
    },
    CommitRevision {
        revision: u64,
    },
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct EffectPlan {
    pub id: PlanId,
    pub steps: Vec<EffectStep>,
    pub compensations: Vec<EffectStep>,
    pub requires: PrivilegeSet,
    pub impact: DeployImpact,
}
