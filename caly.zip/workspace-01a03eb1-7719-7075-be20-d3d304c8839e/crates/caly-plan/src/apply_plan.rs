use crate::effect::{DeployImpact, PrivilegeSet};

#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub enum ApplyPlanKind {
    Noop,
    ApiPatch,
    HotReload,
    Restart,
    RebuildAndRestart,
}

#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub enum ApplyIssueLevel {
    Error,
    Warning,
    Info,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct ApplyIssue {
    pub level: ApplyIssueLevel,
    pub code: String,
    pub summary: String,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct ApplyPlan {
    pub kind: ApplyPlanKind,
    pub impact: DeployImpact,
    pub requires: PrivilegeSet,
    pub issues: Vec<ApplyIssue>,
    pub reasons: Vec<String>,
}

impl ApplyPlan {
    pub fn noop() -> Self {
        Self {
            kind: ApplyPlanKind::Noop,
            impact: DeployImpact::Noop,
            requires: PrivilegeSet::default(),
            issues: Vec::new(),
            reasons: Vec::new(),
        }
    }
}
