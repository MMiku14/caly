use std::sync::{Arc, Mutex};

use caly_io::{IoFault, IoFaultKind};

#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub enum FaultKind {
    None,
    Timeout,
    Cancelled,
    NotFound,
    PermissionDenied,
    CapacityExceeded,
    IntegrityViolation,
    Unavailable,
    CrashAfterEffect,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct FaultSpec {
    pub label: String,
    pub kind: FaultKind,
    pub trigger_after_step: Option<u64>,
}

#[derive(Clone, Debug, Default, Eq, PartialEq)]
pub struct FaultInjector {
    pub seed: u64,
    pub faults: Vec<FaultSpec>,
    pub current_step: u64,
}

impl FaultInjector {
    pub fn new(seed: u64) -> Self {
        Self {
            seed,
            faults: Vec::new(),
            current_step: 0,
        }
    }

    pub fn push(&mut self, fault: FaultSpec) {
        self.faults.push(fault);
    }

    pub fn advance_step(&mut self) {
        self.current_step = self.current_step.saturating_add(1);
    }

    pub fn take_matching(&mut self, label: &str) -> Option<FaultSpec> {
        let index = self.faults.iter().position(|fault| {
            fault.label == label
                && fault
                    .trigger_after_step
                    .map(|step| step <= self.current_step)
                    .unwrap_or(true)
        })?;
        Some(self.faults.remove(index))
    }
}

#[derive(Clone, Default)]
pub struct SharedFaults {
    inner: Arc<Mutex<FaultInjector>>,
}

impl SharedFaults {
    pub fn new(injector: FaultInjector) -> Self {
        Self {
            inner: Arc::new(Mutex::new(injector)),
        }
    }

    pub fn maybe_fail(&self, label: &str) -> Result<(), IoFault> {
        let mut guard = self
            .inner
            .lock()
            .map_err(|_| IoFault::new(IoFaultKind::InternalIo, "fault injector lock poisoned"))?;
        guard.advance_step();
        if let Some(spec) = guard.take_matching(label) {
            return Err(spec.into_io_fault());
        }
        Ok(())
    }

    pub fn push(&self, fault: FaultSpec) -> Result<(), IoFault> {
        let mut guard = self
            .inner
            .lock()
            .map_err(|_| IoFault::new(IoFaultKind::InternalIo, "fault injector lock poisoned"))?;
        guard.push(fault);
        Ok(())
    }
}

impl FaultSpec {
    pub fn into_io_fault(self) -> IoFault {
        let kind = match self.kind {
            FaultKind::None => IoFaultKind::InternalIo,
            FaultKind::Timeout => IoFaultKind::Timeout,
            FaultKind::Cancelled => IoFaultKind::Cancelled,
            FaultKind::NotFound => IoFaultKind::NotFound,
            FaultKind::PermissionDenied => IoFaultKind::PermissionDenied,
            FaultKind::CapacityExceeded => IoFaultKind::CapacityExceeded,
            FaultKind::IntegrityViolation => IoFaultKind::IntegrityViolation,
            FaultKind::Unavailable => IoFaultKind::Unavailable,
            FaultKind::CrashAfterEffect => IoFaultKind::InternalIo,
        };

        IoFault::new(kind, format!("simulated fault: {} ({:?})", self.label, self.kind))
    }
}
