use crate::fault::{FaultInjector, FaultKind, FaultSpec};

#[derive(Clone, Debug, Default, Eq, PartialEq)]
pub struct ScenarioBuilder {
    seed: u64,
    faults: Vec<FaultSpec>,
}

impl ScenarioBuilder {
    pub fn new(seed: u64) -> Self {
        Self {
            seed,
            faults: Vec::new(),
        }
    }

    pub fn fail_once(mut self, label: impl Into<String>, kind: FaultKind) -> Self {
        self.faults.push(FaultSpec {
            label: label.into(),
            kind,
            trigger_after_step: None,
        });
        self
    }

    pub fn fail_repeated(
        mut self,
        label: impl Into<String>,
        times: usize,
        kind: FaultKind,
    ) -> Self {
        let label = label.into();
        for _ in 0..times {
            self.faults.push(FaultSpec {
                label: label.clone(),
                kind,
                trigger_after_step: None,
            });
        }
        self
    }

    pub fn fail_many<I, S>(mut self, labels: I, kind: FaultKind) -> Self
    where
        I: IntoIterator<Item = S>,
        S: Into<String>,
    {
        for label in labels {
            self.faults.push(FaultSpec {
                label: label.into(),
                kind,
                trigger_after_step: None,
            });
        }
        self
    }

    pub fn fail_at_step(
        mut self,
        label: impl Into<String>,
        step: u64,
        kind: FaultKind,
    ) -> Self {
        self.faults.push(FaultSpec {
            label: label.into(),
            kind,
            trigger_after_step: Some(step),
        });
        self
    }

    pub fn crash_after_effect_step(mut self, step: u64) -> Self {
        self.faults.push(FaultSpec {
            label: format!("crash-after-step-{step}"),
            kind: FaultKind::CrashAfterEffect,
            trigger_after_step: Some(step),
        });
        self
    }

    pub fn build(self) -> FaultInjector {
        FaultInjector {
            seed: self.seed,
            faults: self.faults,
            current_step: 0,
        }
    }
}

pub fn handshake_timeout_scenario(seed: u64) -> FaultInjector {
    ScenarioBuilder::new(seed)
        .fail_at_step("clock.sleep_until", 0, FaultKind::Timeout)
        .build()
}

pub fn queue_pressure_scenario(seed: u64) -> FaultInjector {
    ScenarioBuilder::new(seed)
        .fail_repeated("fs.write_atomic", 2, FaultKind::CapacityExceeded)
        .fail_once("proc.spawn", FaultKind::Unavailable)
        .build()
}

pub fn watch_gap_scenario(seed: u64) -> FaultInjector {
    ScenarioBuilder::new(seed)
        .fail_many(["http.fetch", "keyring.get"], FaultKind::Timeout)
        .build()
}
