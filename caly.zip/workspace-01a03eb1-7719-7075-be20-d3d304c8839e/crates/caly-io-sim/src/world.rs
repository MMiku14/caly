use caly_io::{Monotonic, Timestamp};

use crate::fault::{FaultInjector, FaultKind, FaultSpec, SharedFaults};

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct VirtualClock {
    pub wall_clock_unix_ms: i64,
    pub monotonic_ms: u64,
}

impl VirtualClock {
    pub fn new(wall_clock_unix_ms: i64) -> Self {
        Self {
            wall_clock_unix_ms,
            monotonic_ms: 0,
        }
    }

    pub fn now(&self) -> Timestamp {
        Timestamp {
            unix_millis: self.wall_clock_unix_ms,
        }
    }

    pub fn mono(&self) -> Monotonic {
        Monotonic {
            ticks_millis: self.monotonic_ms,
        }
    }

    pub fn advance_ms(&mut self, millis: u64) {
        self.monotonic_ms = self.monotonic_ms.saturating_add(millis);
        self.wall_clock_unix_ms = self.wall_clock_unix_ms.saturating_add(millis as i64);
    }
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct MemFile {
    pub path: String,
    pub bytes: Vec<u8>,
}

#[derive(Clone, Debug, Default, Eq, PartialEq)]
pub struct MemFs {
    pub files: Vec<MemFile>,
}

impl MemFs {
    pub fn put(&mut self, path: impl Into<String>, bytes: Vec<u8>) {
        self.files.push(MemFile {
            path: path.into(),
            bytes,
        });
    }
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct ScriptedResponse {
    pub url: String,
    pub status: u16,
    pub body: Vec<u8>,
}

#[derive(Clone, Debug, Default, Eq, PartialEq)]
pub struct ScriptedHttp {
    pub responses: Vec<ScriptedResponse>,
}

impl ScriptedHttp {
    pub fn push(&mut self, response: ScriptedResponse) {
        self.responses.push(response);
    }
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct FakeChild {
    pub pid: u32,
    pub alive: bool,
    pub label: String,
}

#[derive(Clone, Debug, Default, Eq, PartialEq)]
pub struct FakeProc {
    pub children: Vec<FakeChild>,
}

impl FakeProc {
    pub fn spawn_child(&mut self, label: impl Into<String>) -> u32 {
        let pid = (self.children.len() as u32).saturating_add(1000);
        self.children.push(FakeChild {
            pid,
            alive: true,
            label: label.into(),
        });
        pid
    }
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct SimWorld {
    pub seed: u64,
    pub clock: VirtualClock,
    pub fs: MemFs,
    pub http: ScriptedHttp,
    pub proc: FakeProc,
    pub faults: FaultInjector,
}

impl SimWorld {
    pub fn new(seed: u64) -> Self {
        Self {
            seed,
            clock: VirtualClock::new(0),
            fs: MemFs::default(),
            http: ScriptedHttp::default(),
            proc: FakeProc::default(),
            faults: FaultInjector::new(seed),
        }
    }

    pub fn shared_faults(&self) -> SharedFaults {
        SharedFaults::new(self.faults.clone())
    }

    pub fn crash_after_effect_step(&mut self, step: u64) {
        self.faults.push(FaultSpec {
            label: format!("crash-after-step-{step}"),
            kind: FaultKind::CrashAfterEffect,
            trigger_after_step: Some(step),
        });
    }
}
