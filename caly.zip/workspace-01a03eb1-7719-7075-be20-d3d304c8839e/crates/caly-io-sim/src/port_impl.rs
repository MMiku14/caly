use std::collections::BTreeMap;
use std::sync::{Arc, Mutex};

use caly_io::{
    BoxFuture, ByteCap, ByteStream, Bytes, ChildHandle, Clock, Durability, FetchReq, FetchResp,
    FileLock, Fs, Http, IoContext, IoFault, IoFaultKind, Keyring, LinkKind, Meta, Monotonic,
    Proc, Rand, SpawnSpec, Timestamp, VPath,
};

use crate::fault::SharedFaults;
use crate::world::{FakeProc, MemFile, MemFs, ScriptedHttp, VirtualClock};

#[derive(Clone)]
pub struct SimFs {
    state: Arc<Mutex<MemFs>>,
    faults: SharedFaults,
}

impl SimFs {
    pub fn new(state: MemFs, faults: SharedFaults) -> Self {
        Self {
            state: Arc::new(Mutex::new(state)),
            faults,
        }
    }

    pub fn snapshot(&self) -> Result<MemFs, IoFault> {
        self.state.lock().map(|guard| guard.clone()).map_err(|_| {
            IoFault::new(IoFaultKind::InternalIo, "sim fs lock poisoned")
        })
    }
}

impl Fs for SimFs {
    fn read<'a>(&'a self, path: &'a VPath, cap: ByteCap, _ctx: &'a IoContext) -> BoxFuture<'a, Result<Bytes, IoFault>> {
        let state = Arc::clone(&self.state);
        let faults = self.faults.clone();
        let key = path.as_relative_path();
        Box::pin(async move {
            faults.maybe_fail("fs.read")?;
            let guard = state
                .lock()
                .map_err(|_| IoFault::new(IoFaultKind::InternalIo, "sim fs lock poisoned"))?;
            let file = guard
                .files
                .iter()
                .find(|file| file.path == key)
                .ok_or_else(|| IoFault::new(IoFaultKind::NotFound, format!("file not found: {key}")))?;
            if file.bytes.len() as u64 > cap.0 {
                return Err(IoFault::new(
                    IoFaultKind::CapacityExceeded,
                    format!("file exceeds byte cap: {key}"),
                ));
            }
            Ok(file.bytes.clone())
        })
    }

    fn open_stream<'a>(&'a self, path: &'a VPath, _ctx: &'a IoContext) -> BoxFuture<'a, Result<ByteStream, IoFault>> {
        let key = path.as_relative_path();
        let state = Arc::clone(&self.state);
        let faults = self.faults.clone();
        Box::pin(async move {
            faults.maybe_fail("fs.open_stream")?;
            let guard = state
                .lock()
                .map_err(|_| IoFault::new(IoFaultKind::InternalIo, "sim fs lock poisoned"))?;
            if guard.files.iter().any(|file| file.path == key) {
                Ok(ByteStream { label: key })
            } else {
                Err(IoFault::new(IoFaultKind::NotFound, "stream target not found"))
            }
        })
    }

    fn write_atomic<'a>(
        &'a self,
        path: &'a VPath,
        data: Bytes,
        _durability: Durability,
        _ctx: &'a IoContext,
    ) -> BoxFuture<'a, Result<(), IoFault>> {
        let state = Arc::clone(&self.state);
        let faults = self.faults.clone();
        let key = path.as_relative_path();
        Box::pin(async move {
            faults.maybe_fail("fs.write_atomic")?;
            let mut guard = state
                .lock()
                .map_err(|_| IoFault::new(IoFaultKind::InternalIo, "sim fs lock poisoned"))?;
            if let Some(existing) = guard.files.iter_mut().find(|file| file.path == key) {
                existing.bytes = data;
            } else {
                guard.files.push(MemFile { path: key, bytes: data });
            }
            Ok(())
        })
    }

    fn rename<'a>(
        &'a self,
        from: &'a VPath,
        to: &'a VPath,
        _durability: Durability,
        _ctx: &'a IoContext,
    ) -> BoxFuture<'a, Result<(), IoFault>> {
        let state = Arc::clone(&self.state);
        let faults = self.faults.clone();
        let from_key = from.as_relative_path();
        let to_key = to.as_relative_path();
        Box::pin(async move {
            faults.maybe_fail("fs.rename")?;
            let mut guard = state
                .lock()
                .map_err(|_| IoFault::new(IoFaultKind::InternalIo, "sim fs lock poisoned"))?;
            let file = guard
                .files
                .iter_mut()
                .find(|file| file.path == from_key)
                .ok_or_else(|| IoFault::new(IoFaultKind::NotFound, format!("file not found: {from_key}")))?;
            file.path = to_key;
            Ok(())
        })
    }

    fn remove<'a>(&'a self, path: &'a VPath, _ctx: &'a IoContext) -> BoxFuture<'a, Result<(), IoFault>> {
        let state = Arc::clone(&self.state);
        let faults = self.faults.clone();
        let key = path.as_relative_path();
        Box::pin(async move {
            faults.maybe_fail("fs.remove")?;
            let mut guard = state
                .lock()
                .map_err(|_| IoFault::new(IoFaultKind::InternalIo, "sim fs lock poisoned"))?;
            let before = guard.files.len();
            guard.files.retain(|file| file.path != key);
            if guard.files.len() == before {
                Err(IoFault::new(IoFaultKind::NotFound, format!("file not found: {key}")))
            } else {
                Ok(())
            }
        })
    }

    fn stat<'a>(&'a self, path: &'a VPath, _ctx: &'a IoContext) -> BoxFuture<'a, Result<Option<Meta>, IoFault>> {
        let state = Arc::clone(&self.state);
        let faults = self.faults.clone();
        let key = path.as_relative_path();
        Box::pin(async move {
            faults.maybe_fail("fs.stat")?;
            let guard = state
                .lock()
                .map_err(|_| IoFault::new(IoFaultKind::InternalIo, "sim fs lock poisoned"))?;
            Ok(guard.files.iter().find(|file| file.path == key).map(|file| Meta {
                len: file.bytes.len() as u64,
                is_file: true,
                is_dir: false,
            }))
        })
    }

    fn link_or_copy<'a>(&'a self, from: &'a VPath, to: &'a VPath, _ctx: &'a IoContext) -> BoxFuture<'a, Result<LinkKind, IoFault>> {
        let state = Arc::clone(&self.state);
        let faults = self.faults.clone();
        let from_key = from.as_relative_path();
        let to_key = to.as_relative_path();
        Box::pin(async move {
            faults.maybe_fail("fs.link_or_copy")?;
            let mut guard = state
                .lock()
                .map_err(|_| IoFault::new(IoFaultKind::InternalIo, "sim fs lock poisoned"))?;
            let source = guard
                .files
                .iter()
                .find(|file| file.path == from_key)
                .cloned()
                .ok_or_else(|| IoFault::new(IoFaultKind::NotFound, format!("file not found: {from_key}")))?;
            guard.files.push(MemFile {
                path: to_key,
                bytes: source.bytes,
            });
            Ok(LinkKind::Copy)
        })
    }

    fn lock_exclusive<'a>(&'a self, path: &'a VPath, _ctx: &'a IoContext) -> BoxFuture<'a, Result<FileLock, IoFault>> {
        let key = path.as_relative_path();
        let faults = self.faults.clone();
        Box::pin(async move {
            faults.maybe_fail("fs.lock_exclusive")?;
            Ok(FileLock { path: key })
        })
    }
}

#[derive(Clone)]
pub struct SimClock {
    state: Arc<Mutex<VirtualClock>>,
    faults: SharedFaults,
}

impl SimClock {
    pub fn new(clock: VirtualClock, faults: SharedFaults) -> Self {
        Self {
            state: Arc::new(Mutex::new(clock)),
            faults,
        }
    }

    pub fn advance_ms(&self, millis: u64) -> Result<(), IoFault> {
        let mut guard = self
            .state
            .lock()
            .map_err(|_| IoFault::new(IoFaultKind::InternalIo, "sim clock lock poisoned"))?;
        guard.advance_ms(millis);
        Ok(())
    }
}

impl Clock for SimClock {
    fn now(&self) -> Timestamp {
        self.state
            .lock()
            .map(|guard| guard.now())
            .unwrap_or(Timestamp { unix_millis: 0 })
    }

    fn mono(&self) -> Monotonic {
        self.state
            .lock()
            .map(|guard| guard.mono())
            .unwrap_or(Monotonic { ticks_millis: 0 })
    }

    fn sleep_until<'a>(&'a self, at: Monotonic) -> BoxFuture<'a, Result<(), IoFault>> {
        let state = Arc::clone(&self.state);
        let faults = self.faults.clone();
        Box::pin(async move {
            faults.maybe_fail("clock.sleep_until")?;
            let mut guard = state
                .lock()
                .map_err(|_| IoFault::new(IoFaultKind::InternalIo, "sim clock lock poisoned"))?;
            let current = guard.monotonic_ms;
            if current < at.ticks_millis {
                guard.advance_ms(at.ticks_millis - current);
            }
            Ok(())
        })
    }
}

#[derive(Clone, Debug)]
pub struct SimRand {
    counter: Arc<Mutex<u64>>,
}

impl SimRand {
    pub fn new(seed: u64) -> Self {
        Self {
            counter: Arc::new(Mutex::new(seed)),
        }
    }
}

impl Rand for SimRand {
    fn fill(&self, buf: &mut [u8]) {
        if let Ok(mut guard) = self.counter.lock() {
            for byte in buf.iter_mut() {
                *byte = (*guard & 0xff) as u8;
                *guard = guard.wrapping_add(1);
            }
        } else {
            for byte in buf.iter_mut() {
                *byte = 0;
            }
        }
    }

    fn uuid(&self) -> String {
        if let Ok(mut guard) = self.counter.lock() {
            let value = *guard;
            *guard = guard.wrapping_add(1);
            format!("sim-{value:016x}")
        } else {
            "sim-0000000000000000".to_owned()
        }
    }
}

#[derive(Clone)]
pub struct SimHttp {
    state: Arc<Mutex<ScriptedHttp>>,
    faults: SharedFaults,
}

impl SimHttp {
    pub fn new(state: ScriptedHttp, faults: SharedFaults) -> Self {
        Self {
            state: Arc::new(Mutex::new(state)),
            faults,
        }
    }
}

impl Http for SimHttp {
    fn fetch<'a>(&'a self, req: FetchReq, _ctx: &'a IoContext) -> BoxFuture<'a, Result<FetchResp, IoFault>> {
        let state = Arc::clone(&self.state);
        let faults = self.faults.clone();
        Box::pin(async move {
            faults.maybe_fail("http.fetch")?;
            let guard = state
                .lock()
                .map_err(|_| IoFault::new(IoFaultKind::InternalIo, "sim http lock poisoned"))?;
            let response = guard
                .responses
                .iter()
                .find(|response| response.url == req.url)
                .ok_or_else(|| IoFault::new(IoFaultKind::NotFound, format!("no scripted response for {}", req.url)))?;
            if response.body.len() as u64 > req.max_body_bytes {
                return Err(IoFault::new(
                    IoFaultKind::CapacityExceeded,
                    format!("response exceeds max body for {}", req.url),
                ));
            }
            Ok(FetchResp {
                status: response.status,
                etag: None,
                last_modified: None,
                body: ByteStream {
                    label: format!("http:{}", response.url),
                },
            })
        })
    }
}

#[derive(Clone)]
pub struct SimProc {
    state: Arc<Mutex<FakeProc>>,
    faults: SharedFaults,
}

impl SimProc {
    pub fn new(state: FakeProc, faults: SharedFaults) -> Self {
        Self {
            state: Arc::new(Mutex::new(state)),
            faults,
        }
    }
}

impl Proc for SimProc {
    fn spawn<'a>(&'a self, spec: SpawnSpec, _ctx: &'a IoContext) -> BoxFuture<'a, Result<ChildHandle, IoFault>> {
        let state = Arc::clone(&self.state);
        let faults = self.faults.clone();
        Box::pin(async move {
            faults.maybe_fail("proc.spawn")?;
            let mut guard = state
                .lock()
                .map_err(|_| IoFault::new(IoFaultKind::InternalIo, "sim proc lock poisoned"))?;
            let pid = guard.spawn_child(spec.program);
            Ok(ChildHandle {
                pid,
                instance_nonce: format!("child-{pid}"),
            })
        })
    }
}

#[derive(Clone, Default)]
pub struct SimKeyring {
    entries: Arc<Mutex<BTreeMap<String, String>>>,
    faults: SharedFaults,
}

impl SimKeyring {
    pub fn new(faults: SharedFaults) -> Self {
        Self {
            entries: Arc::new(Mutex::new(BTreeMap::new())),
            faults,
        }
    }
}

impl Keyring for SimKeyring {
    fn get<'a>(&'a self, key: &'a str, _ctx: &'a IoContext) -> BoxFuture<'a, Result<Option<String>, IoFault>> {
        let entries = Arc::clone(&self.entries);
        let faults = self.faults.clone();
        let key = key.to_owned();
        Box::pin(async move {
            faults.maybe_fail("keyring.get")?;
            let guard = entries
                .lock()
                .map_err(|_| IoFault::new(IoFaultKind::InternalIo, "sim keyring lock poisoned"))?;
            Ok(guard.get(&key).cloned())
        })
    }

    fn set<'a>(&'a self, key: &'a str, value: String, _ctx: &'a IoContext) -> BoxFuture<'a, Result<(), IoFault>> {
        let entries = Arc::clone(&self.entries);
        let faults = self.faults.clone();
        let key = key.to_owned();
        Box::pin(async move {
            faults.maybe_fail("keyring.set")?;
            let mut guard = entries
                .lock()
                .map_err(|_| IoFault::new(IoFaultKind::InternalIo, "sim keyring lock poisoned"))?;
            guard.insert(key, value);
            Ok(())
        })
    }

    fn delete<'a>(&'a self, key: &'a str, _ctx: &'a IoContext) -> BoxFuture<'a, Result<(), IoFault>> {
        let entries = Arc::clone(&self.entries);
        let faults = self.faults.clone();
        let key = key.to_owned();
        Box::pin(async move {
            faults.maybe_fail("keyring.delete")?;
            let mut guard = entries
                .lock()
                .map_err(|_| IoFault::new(IoFaultKind::InternalIo, "sim keyring lock poisoned"))?;
            guard.remove(&key);
            Ok(())
        })
    }
}
