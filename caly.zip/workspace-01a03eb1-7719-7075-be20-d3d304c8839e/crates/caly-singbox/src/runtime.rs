use caly_core::{
    ControlPlane, CoreResourceSample, GroupRuntimeState, ProbePlane, RuntimeConnection,
    RuntimeDriver, RuntimeLogLine, RuntimeStatusView, TelemetryPlane, TrafficSample,
};

#[derive(Default)]
pub struct SingBoxRuntimeDriver {
    control: SingBoxControlPlane,
    telemetry: SingBoxTelemetryPlane,
    probe: SingBoxProbePlane,
}

impl RuntimeDriver for SingBoxRuntimeDriver {
    fn control(&self) -> &dyn ControlPlane {
        &self.control
    }

    fn telemetry(&self) -> &dyn TelemetryPlane {
        &self.telemetry
    }

    fn probe(&self) -> &dyn ProbePlane {
        &self.probe
    }
}

#[derive(Default)]
pub struct SingBoxControlPlane;

impl ControlPlane for SingBoxControlPlane {
    fn status(&self) -> Result<RuntimeStatusView, String> {
        Ok(RuntimeStatusView {
            running: true,
            healthy: true,
            config_identity: Some("singbox-skeleton-config".to_owned()),
            summary: "sing-box runtime skeleton healthy".to_owned(),
        })
    }

    fn reload(&self) -> Result<(), String> {
        Ok(())
    }

    fn select_proxy(&self, _group_label: &str, _node_label: &str) -> Result<(), String> {
        Ok(())
    }

    fn close_connection(&self, _connection_id: &str) -> Result<(), String> {
        Ok(())
    }
}

#[derive(Default)]
pub struct SingBoxTelemetryPlane;

impl TelemetryPlane for SingBoxTelemetryPlane {
    fn traffic(&self) -> Result<Vec<TrafficSample>, String> {
        Ok(vec![TrafficSample {
            upload_bytes_per_sec: 64,
            download_bytes_per_sec: 128,
            uploaded_total: 512,
            downloaded_total: 1_024,
            timestamp_ms: 0,
        }])
    }

    fn connections(&self) -> Result<Vec<RuntimeConnection>, String> {
        Ok(Vec::new())
    }

    fn groups(&self) -> Result<Vec<GroupRuntimeState>, String> {
        Ok(Vec::new())
    }

    fn logs(&self) -> Result<Vec<RuntimeLogLine>, String> {
        Ok(vec![RuntimeLogLine {
            level: "INFO".to_owned(),
            timestamp_ms: 0,
            component: "sing-box".to_owned(),
            message: "sing-box telemetry skeleton".to_owned(),
        }])
    }

    fn resource(&self) -> Result<Vec<CoreResourceSample>, String> {
        Ok(vec![CoreResourceSample {
            cpu_percent: 1,
            rss_bytes: 10 * 1024 * 1024,
        }])
    }
}

#[derive(Default)]
pub struct SingBoxProbePlane;

impl ProbePlane for SingBoxProbePlane {
    fn api_ready(&self) -> Result<bool, String> {
        Ok(true)
    }

    fn config_identity(&self) -> Result<Option<String>, String> {
        Ok(Some("singbox-skeleton-config".to_owned()))
    }

    fn inbound_listening(&self) -> Result<bool, String> {
        Ok(true)
    }
}
