use std::collections::BTreeMap;

use caly_cap::{
    CapabilityDescriptor, CapabilityDomain, CapabilityKey, CapabilityState, Constraint, EvidenceRef,
    FallbackPolicy, SupportLevel,
};
use caly_core::{
    artifact_digest, stable_checksum_text, ApplyPlanningResult, CapabilitySet, CoreAdapter,
    CoreIdentity, CoreIssue, CoreKind, IssueLevel, NativeValidationReport, RuntimeDriver,
};
use caly_ir::{
    CompiledArtifact, NativeConfigFormat, ProxyProtocol, ResolvedProfile, RuleAction, StableBytes,
};
use caly_plan::{
    ApplyIssue, ApplyIssueLevel, ApplyPlan, ApplyPlanKind, BlobRef, CoreKind as PlanCoreKind,
    CoreSpec, DeployImpact, Durability, EffectPlan, EffectStep, FileMode, InstanceId,
    NetworkPlan, PlanId, PrivilegeSet, ProbeKind, ProbeSpec, SnapshotId,
};

use crate::runtime::SingBoxRuntimeDriver;

#[derive(Default)]
pub struct SingBoxAdapter;

impl CoreAdapter for SingBoxAdapter {
    fn inspect_binary(&self) -> Result<CoreIdentity, String> {
        Ok(CoreIdentity {
            kind: CoreKind::SingBox,
            version: "1.0.0-skeleton".to_owned(),
            build: Some("sing-box".to_owned()),
            binary_digest: "singbox-skeleton-binary".to_owned(),
        })
    }

    fn capability_set(&self, _identity: &CoreIdentity) -> Result<CapabilitySet, String> {
        Ok(CapabilitySet {
            descriptors: vec![
                capability(
                    "dns.fake_ip",
                    "sing-box Fake-IP",
                    CapabilityDomain::Dns,
                    SupportLevel::CalyManaged,
                    CapabilityState::SupportedExact,
                    vec![Constraint {
                        field: "mode".to_owned(),
                        expected: "fake-ip".to_owned(),
                    }],
                    None,
                    vec!["sing-box fake-ip is modeled directly".to_owned()],
                ),
                capability(
                    "outbound.wireguard",
                    "sing-box WireGuard outbound",
                    CapabilityDomain::Outbounds,
                    SupportLevel::NativeManaged,
                    CapabilityState::SupportedNativeOnly,
                    Vec::new(),
                    Some(FallbackPolicy::UseNativeOnlyMode),
                    vec!["wireguard remains native-shaped in this slice".to_owned()],
                ),
                capability(
                    "routing.rules",
                    "sing-box route rules",
                    CapabilityDomain::Routing,
                    SupportLevel::CalyManaged,
                    CapabilityState::SupportedExact,
                    Vec::new(),
                    None,
                    vec!["sing-box route rules are compiled from Caly IR".to_owned()],
                ),
                capability(
                    "network.tun",
                    "sing-box TUN",
                    CapabilityDomain::Tun,
                    SupportLevel::CalyManaged,
                    CapabilityState::SupportedExact,
                    Vec::new(),
                    Some(FallbackPolicy::EscalateToRestart),
                    vec!["tun requires coordinated restart".to_owned()],
                ),
            ],
        })
    }

    fn preflight(
        &self,
        profile: &ResolvedProfile,
        _capabilities: &CapabilitySet,
    ) -> Result<Vec<CoreIssue>, String> {
        let mut issues = vec![CoreIssue {
            level: if profile.outbounds.is_empty() {
                IssueLevel::Warning
            } else {
                IssueLevel::Info
            },
            code: "SINGBOX_PREFLIGHT".to_owned(),
            summary: "sing-box adapter preflight executed".to_owned(),
        }];

        if profile
            .nodes
            .iter()
            .any(|node| matches!(node.protocol, ProxyProtocol::Unknown))
        {
            issues.push(CoreIssue {
                level: IssueLevel::Warning,
                code: "SINGBOX_UNKNOWN_PROTOCOL".to_owned(),
                summary: "some nodes still use unknown protocol in sing-box slice".to_owned(),
            });
        }

        Ok(issues)
    }

    fn compile(
        &self,
        profile: &ResolvedProfile,
        _capabilities: &CapabilitySet,
    ) -> Result<CompiledArtifact, String> {
        let bytes = render_singbox_json(profile);
        let mut annotations = common_annotations(profile);
        annotations.insert("core.kind".to_owned(), "sing-box".to_owned());
        annotations.insert(
            "config.identity".to_owned(),
            format!("singbox-{:016x}", stable_checksum_text(&profile.semantic_digest.0)),
        );
        annotations.insert(
            "contains.wireguard".to_owned(),
            profile
                .nodes
                .iter()
                .any(|node| matches!(node.protocol, ProxyProtocol::WireGuard))
                .to_string(),
        );

        Ok(CompiledArtifact {
            profile_id: profile.profile_id.clone(),
            target_core: CoreKind::SingBox.target(),
            adapter_version: 1,
            artifact_digest: artifact_digest("singbox", &bytes),
            file_name_hint: format!("{}.singbox.json", profile.profile_id.0),
            format: NativeConfigFormat::Json,
            entrypoint: "config.json".to_owned(),
            media_type: "application/json".to_owned(),
            bytes,
            annotations,
        })
    }

    fn validate_native(&self, artifact: &CompiledArtifact) -> Result<NativeValidationReport, String> {
        let body = String::from_utf8_lossy(&artifact.bytes.bytes);
        let accepted = body.contains("\"outbounds\"") && body.contains("\"route\"");
        let mut issues = vec![CoreIssue {
            level: IssueLevel::Info,
            code: "SINGBOX_NATIVE_VALIDATE".to_owned(),
            summary: format!("sing-box validated {}", artifact.file_name_hint),
        }];

        if !accepted {
            issues.push(CoreIssue {
                level: IssueLevel::Error,
                code: "SINGBOX_NATIVE_REJECTED".to_owned(),
                summary: "sing-box native validation expected outbounds and route sections".to_owned(),
            });
        }

        Ok(NativeValidationReport { accepted, issues })
    }

    fn plan_apply(
        &self,
        current: Option<&CompiledArtifact>,
        next: &CompiledArtifact,
    ) -> Result<ApplyPlanningResult, String> {
        let tun_enabled = annotation_bool(next, "tun.enabled");
        let wireguard = annotation_bool(next, "contains.wireguard");
        let selection_only = current
            .map(|artifact| selection_only_change(artifact, next))
            .unwrap_or(false);

        let kind = if current
            .map(|artifact| artifact.artifact_digest == next.artifact_digest)
            .unwrap_or(false)
        {
            ApplyPlanKind::Noop
        } else if current.is_none() {
            if tun_enabled || wireguard {
                ApplyPlanKind::RebuildAndRestart
            } else {
                ApplyPlanKind::Restart
            }
        } else if tun_enabled || wireguard {
            ApplyPlanKind::RebuildAndRestart
        } else {
            ApplyPlanKind::Restart
        };

        let impact = match kind {
            ApplyPlanKind::Noop => DeployImpact::Noop,
            ApplyPlanKind::ApiPatch => DeployImpact::RuntimePatch,
            ApplyPlanKind::HotReload => DeployImpact::Reload,
            ApplyPlanKind::Restart => DeployImpact::Restart,
            ApplyPlanKind::RebuildAndRestart => {
                if tun_enabled {
                    DeployImpact::NetworkChange
                } else {
                    DeployImpact::RebuildAndRestart
                }
            }
        };
        let requires = PrivilegeSet {
            needs_admin: tun_enabled,
            needs_network_control: tun_enabled,
            needs_process_control: !matches!(kind, ApplyPlanKind::Noop),
            needs_secret_access: false,
        };
        let mut reasons = vec!["target core=sing-box".to_owned()];
        if selection_only {
            reasons.push("selection-only delta still requires restart in sing-box slice".to_owned());
        } else {
            reasons.push("native configuration content changed".to_owned());
        }
        if wireguard {
            reasons.push("wireguard outbound is native-only and escalates to rebuild/restart".to_owned());
        }
        if tun_enabled {
            reasons.push("tun is enabled and implies network side effects".to_owned());
        }
        reasons.push(format!("selected apply plan kind={kind:?}"));

        let effect_plan = build_effect_plan(kind, current, next, impact, requires.clone());

        Ok(ApplyPlanningResult {
            apply_plan: ApplyPlan {
                kind,
                impact,
                requires,
                issues: vec![ApplyIssue {
                    level: ApplyIssueLevel::Info,
                    code: "SINGBOX_APPLY_PLAN".to_owned(),
                    summary: format!("sing-box selected {:?}", kind),
                }],
                reasons,
            },
            effect_plan,
        })
    }

    fn runtime(&self) -> Result<Box<dyn RuntimeDriver>, String> {
        Ok(Box::new(SingBoxRuntimeDriver::default()))
    }
}

fn capability(
    key: &str,
    title: &str,
    domain: CapabilityDomain,
    support_level: SupportLevel,
    state: CapabilityState,
    constraints: Vec<Constraint>,
    fallback: Option<FallbackPolicy>,
    notes: Vec<String>,
) -> CapabilityDescriptor {
    CapabilityDescriptor {
        key: CapabilityKey(key.to_owned()),
        title: title.to_owned(),
        domain,
        support_level,
        state,
        constraints,
        fallback,
        evidence_ref: EvidenceRef {
            fixture_id: Some(format!("singbox-{key}")),
            golden_test_id: None,
            native_validation_test_id: None,
            runtime_test_id: None,
        },
        notes,
    }
}

fn render_singbox_json(profile: &ResolvedProfile) -> StableBytes {
    let dns_block = profile.dns.as_ref().map(render_dns_block).unwrap_or_else(|| "{\"strategy\":\"prefer_ipv4\"}".to_owned());
    let tun_block = profile
        .tun
        .as_ref()
        .map(render_tun_block)
        .unwrap_or_else(|| "null".to_owned());

    let mut outbounds = Vec::new();
    for node in &profile.nodes {
        outbounds.push(format!(
            "{{\"type\":\"{}\",\"tag\":\"{}\",\"server\":\"{}\",\"server_port\":{}}}",
            proxy_protocol_name(node.protocol),
            node.id.0,
            node.server,
            node.port
        ));
    }

    for group in &profile.groups {
        let members = group
            .members
            .iter()
            .map(|member| format!("\"{}\"", member.0))
            .collect::<Vec<_>>()
            .join(",");
        let selected = group
            .selected
            .as_ref()
            .map(|node| format!(",\"default\":\"{}\"", node.0))
            .unwrap_or_default();
        outbounds.push(format!(
            "{{\"type\":\"selector\",\"tag\":\"{}\",\"outbounds\":[{}]{} }}",
            group.id.0,
            members,
            selected
        ));
    }

    let rules = profile
        .rules
        .iter()
        .map(|rule| {
            let action = match rule.action {
                RuleAction::UseGroup => rule
                    .target_group
                    .as_ref()
                    .map(|group| format!("\"outbound\":\"{}\"", group.0))
                    .unwrap_or_else(|| "\"action\":\"direct\"".to_owned()),
                RuleAction::Direct => "\"action\":\"direct\"".to_owned(),
                RuleAction::Reject => "\"action\":\"reject\"".to_owned(),
                RuleAction::UseOutbound => rule
                    .target_outbound
                    .as_ref()
                    .map(|outbound| format!("\"outbound\":\"{}\"", outbound.0))
                    .unwrap_or_else(|| "\"action\":\"direct\"".to_owned()),
            };
            format!("{{\"rule_set\":\"{}\",{}}}", rule.matcher, action)
        })
        .collect::<Vec<_>>()
        .join(",");

    let body = format!(
        "{{\"log\":{{\"level\":\"info\"}},\"dns\":{},\"inbounds\":[{{\"type\":\"mixed\",\"listen\":\"127.0.0.1\",\"listen_port\":7890}}],\"outbounds\":[{}],\"route\":{{\"final\":\"direct\",\"rules\":[{}]}},\"experimental\":{{\"cache_file\":{{\"enabled\":true}}}},\"tun\":{}}}",
        dns_block,
        outbounds.join(","),
        rules,
        tun_block,
    );

    StableBytes::new(body.into_bytes())
}

fn render_dns_block(dns: &caly_ir::DnsPolicy) -> String {
    let servers = dns
        .servers
        .iter()
        .map(|server| format!("{{\"tag\":\"remote\",\"address\":\"{}\"}}", server))
        .collect::<Vec<_>>()
        .join(",");
    format!(
        "{{\"strategy\":\"prefer_ipv4\",\"servers\":[{}],\"fakeip\":{{\"enabled\":{}}}}}",
        servers,
        matches!(dns.mode, caly_ir::DnsMode::FakeIp | caly_ir::DnsMode::Mixed)
    )
}

fn render_tun_block(tun: &caly_ir::TunPolicy) -> String {
    format!(
        "{{\"enabled\":{},\"auto_route\":{},\"strict_route\":{}}}",
        tun.enabled, tun.auto_route, tun.strict_route
    )
}

fn common_annotations(profile: &ResolvedProfile) -> BTreeMap<String, String> {
    let mut annotations = BTreeMap::new();
    annotations.insert("semantic_digest".to_owned(), profile.semantic_digest.0.clone());
    annotations.insert(
        "tun.enabled".to_owned(),
        profile
            .tun
            .as_ref()
            .map(|tun| tun.enabled)
            .unwrap_or(false)
            .to_string(),
    );
    annotations.insert("selection_digest".to_owned(), selection_digest(profile));
    annotations.insert("selections".to_owned(), selection_pairs(profile).join(","));
    annotations
}

fn selection_digest(profile: &ResolvedProfile) -> String {
    format!("sel:{:016x}", stable_checksum_text(&selection_pairs(profile).join("|")))
}

fn selection_pairs(profile: &ResolvedProfile) -> Vec<String> {
    profile
        .groups
        .iter()
        .map(|group| {
            format!(
                "{}={}",
                group.id.0,
                group
                    .selected
                    .as_ref()
                    .map(|node| node.0.clone())
                    .unwrap_or_else(|| "none".to_owned())
            )
        })
        .collect()
}

fn selection_only_change(current: &CompiledArtifact, next: &CompiledArtifact) -> bool {
    current.annotations.get("semantic_digest") == next.annotations.get("semantic_digest")
        && current.annotations.get("selection_digest") != next.annotations.get("selection_digest")
}

fn annotation_bool(artifact: &CompiledArtifact, key: &str) -> bool {
    artifact
        .annotations
        .get(key)
        .map(|value| value == "true")
        .unwrap_or(false)
}

fn build_effect_plan(
    kind: ApplyPlanKind,
    current: Option<&CompiledArtifact>,
    next: &CompiledArtifact,
    impact: DeployImpact,
    requires: PrivilegeSet,
) -> Option<EffectPlan> {
    if matches!(kind, ApplyPlanKind::Noop) {
        return None;
    }

    let instance = InstanceId("singbox-core-instance".to_owned());
    let snapshot = SnapshotId(format!("singbox-snapshot-{}", next.profile_id.0));
    let core_spec = CoreSpec {
        kind: PlanCoreKind::SingBox,
        binary_digest: "singbox-skeleton-binary".to_owned(),
        config_digest: next.artifact_digest.0.clone(),
    };
    let blob = BlobRef {
        digest: next.artifact_digest.0.clone(),
        size_hint: Some(next.size_bytes() as u64),
    };

    let mut steps = vec![
        EffectStep::WriteObject {
            digest: next.artifact_digest.0.clone(),
            source: blob,
            durability: Durability::D2,
        },
        EffectStep::MaterializeArtifact {
            digest: next.artifact_digest.0.clone(),
            at: format!("runtime/{}/{}", next.profile_id.0, next.entrypoint),
            mode: FileMode::ReadOnlyArtifact,
        },
    ];

    if annotation_bool(next, "tun.enabled") {
        steps.push(EffectStep::NetApply {
            plan: NetworkPlan {
                summary: "configure TUN + routes for sing-box".to_owned(),
                requires_privilege: true,
            },
        });
    }

    if current.is_some() {
        steps.push(EffectStep::StopCore {
            instance: instance.clone(),
            grace_ms: 2_500,
        });
    }
    steps.push(EffectStep::SpawnCore { spec: core_spec });
    steps.push(EffectStep::Probe {
        probe: ProbeSpec {
            kind: ProbeKind::ApiReady,
            target: None,
        },
        deadline_ms: 3_000,
    });
    steps.push(EffectStep::Probe {
        probe: ProbeSpec {
            kind: ProbeKind::ConfigIdentity,
            target: next.annotations.get("config.identity").cloned(),
        },
        deadline_ms: 3_000,
    });
    steps.push(EffectStep::MarkSnapshot { snapshot_id: snapshot });
    steps.push(EffectStep::CommitRevision { revision: 1 });

    let mut compensations = Vec::new();
    if annotation_bool(next, "tun.enabled") {
        compensations.push(EffectStep::NetRevert {
            txn_id: caly_plan::NetTxnId("singbox-net-revert".to_owned()),
        });
    }
    if current.is_some() {
        compensations.push(EffectStep::StopCore {
            instance,
            grace_ms: 1_000,
        });
    }

    Some(EffectPlan {
        id: PlanId(format!("singbox-effect-plan-{}", next.profile_id.0)),
        steps,
        compensations,
        requires,
        impact,
    })
}

fn proxy_protocol_name(protocol: ProxyProtocol) -> &'static str {
    match protocol {
        ProxyProtocol::Shadowsocks => "shadowsocks",
        ProxyProtocol::Vmess => "vmess",
        ProxyProtocol::Vless => "vless",
        ProxyProtocol::Trojan => "trojan",
        ProxyProtocol::Hysteria2 => "hysteria2",
        ProxyProtocol::Tuic => "tuic",
        ProxyProtocol::WireGuard => "wireguard",
        ProxyProtocol::Unknown => "direct",
    }
}
