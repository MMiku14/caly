use crate::journal::JournalRecordId;
use crate::revision::{RevisionId, RevisionNumber};

#[derive(Clone, Debug, Eq, PartialEq, Ord, PartialOrd, Hash)]
pub struct SnapshotRecordId(pub String);

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct SnapshotRecord {
    pub id: SnapshotRecordId,
    pub revision_id: RevisionId,
    pub revision_number: RevisionNumber,
    pub profile_id: String,
    pub semantic_digest: String,
    pub compiled_artifact_digest: String,
    pub core_binary_digest: String,
    pub core_identity: String,
    pub apply_plan_summary: String,
    pub journal_id: Option<JournalRecordId>,
    pub selection_memory_digest: Option<String>,
    pub validation_summary: String,
    pub created_at_unix_ms: i64,
    pub is_last_known_good: bool,
}
