use std::collections::BTreeMap;
use std::sync::{Arc, Mutex};

use crate::cas::{CasObjectRef, CasWriteIntent, MaterializationRequest};
use crate::execution::{ApplyJournalRecord, ApplyTxnId};
use crate::journal::{JournalRecord, JournalRecordId, JournalState};
use crate::revision::{RevisionId, RevisionRecord};
use crate::snapshot::{SnapshotRecord, SnapshotRecordId};
use crate::store::{
    ApplyJournalStore, BoxFuture, JournalStore, ObjectStore, RevisionStore, SnapshotStore,
    StorageError, StorageErrorKind,
};

#[derive(Clone, Default)]
pub struct InMemoryStorage {
    objects: Arc<Mutex<BTreeMap<String, CasObjectRef>>>,
    revisions: Arc<Mutex<BTreeMap<String, RevisionRecord>>>,
    snapshots: Arc<Mutex<BTreeMap<String, SnapshotRecord>>>,
    journals: Arc<Mutex<BTreeMap<String, JournalRecord>>>,
    apply_journals: Arc<Mutex<BTreeMap<String, ApplyJournalRecord>>>,
}

impl InMemoryStorage {
    pub fn new() -> Self {
        Self::default()
    }
}

impl ObjectStore for InMemoryStorage {
    fn put<'a>(&'a self, intent: CasWriteIntent) -> BoxFuture<'a, Result<CasObjectRef, StorageError>> {
        let objects = Arc::clone(&self.objects);
        Box::pin(async move {
            let mut guard = objects.lock().map_err(|_| {
                StorageError::new(StorageErrorKind::Internal, "object store lock poisoned")
            })?;
            let object = intent.object.clone();
            guard.insert(object.digest.0.clone(), object.clone());
            Ok(object)
        })
    }

    fn get<'a>(&'a self, digest: &'a str) -> BoxFuture<'a, Result<Option<CasObjectRef>, StorageError>> {
        let objects = Arc::clone(&self.objects);
        let digest = digest.to_owned();
        Box::pin(async move {
            let guard = objects.lock().map_err(|_| {
                StorageError::new(StorageErrorKind::Internal, "object store lock poisoned")
            })?;
            Ok(guard.get(&digest).cloned())
        })
    }

    fn materialize<'a>(
        &'a self,
        request: MaterializationRequest,
    ) -> BoxFuture<'a, Result<(), StorageError>> {
        let objects = Arc::clone(&self.objects);
        Box::pin(async move {
            let guard = objects.lock().map_err(|_| {
                StorageError::new(StorageErrorKind::Internal, "object store lock poisoned")
            })?;
            if guard.contains_key(&request.object.digest.0) {
                Ok(())
            } else {
                Err(StorageError::new(
                    StorageErrorKind::NotFound,
                    format!("object {} not found", request.object.digest.0),
                ))
            }
        })
    }
}

impl RevisionStore for InMemoryStorage {
    fn put_revision<'a>(
        &'a self,
        record: RevisionRecord,
    ) -> BoxFuture<'a, Result<(), StorageError>> {
        let revisions = Arc::clone(&self.revisions);
        Box::pin(async move {
            let mut guard = revisions.lock().map_err(|_| {
                StorageError::new(StorageErrorKind::Internal, "revision store lock poisoned")
            })?;
            guard.insert(record.id.0.clone(), record);
            Ok(())
        })
    }

    fn get_revision<'a>(
        &'a self,
        revision_id: &'a RevisionId,
    ) -> BoxFuture<'a, Result<Option<RevisionRecord>, StorageError>> {
        let revisions = Arc::clone(&self.revisions);
        let key = revision_id.0.clone();
        Box::pin(async move {
            let guard = revisions.lock().map_err(|_| {
                StorageError::new(StorageErrorKind::Internal, "revision store lock poisoned")
            })?;
            Ok(guard.get(&key).cloned())
        })
    }
}

impl SnapshotStore for InMemoryStorage {
    fn put_snapshot<'a>(
        &'a self,
        record: SnapshotRecord,
    ) -> BoxFuture<'a, Result<(), StorageError>> {
        let snapshots = Arc::clone(&self.snapshots);
        Box::pin(async move {
            let mut guard = snapshots.lock().map_err(|_| {
                StorageError::new(StorageErrorKind::Internal, "snapshot store lock poisoned")
            })?;
            guard.insert(record.id.0.clone(), record);
            Ok(())
        })
    }

    fn get_snapshot<'a>(
        &'a self,
        snapshot_id: &'a SnapshotRecordId,
    ) -> BoxFuture<'a, Result<Option<SnapshotRecord>, StorageError>> {
        let snapshots = Arc::clone(&self.snapshots);
        let key = snapshot_id.0.clone();
        Box::pin(async move {
            let guard = snapshots.lock().map_err(|_| {
                StorageError::new(StorageErrorKind::Internal, "snapshot store lock poisoned")
            })?;
            Ok(guard.get(&key).cloned())
        })
    }

    fn latest_last_known_good<'a>(&'a self) -> BoxFuture<'a, Result<Option<SnapshotRecord>, StorageError>> {
        let snapshots = Arc::clone(&self.snapshots);
        Box::pin(async move {
            let guard = snapshots.lock().map_err(|_| {
                StorageError::new(StorageErrorKind::Internal, "snapshot store lock poisoned")
            })?;
            let mut values: Vec<_> = guard.values().filter(|it| it.is_last_known_good).cloned().collect();
            values.sort_by_key(|it| it.created_at_unix_ms);
            Ok(values.pop())
        })
    }
}

impl JournalStore for InMemoryStorage {
    fn put_journal<'a>(&'a self, record: JournalRecord) -> BoxFuture<'a, Result<(), StorageError>> {
        let journals = Arc::clone(&self.journals);
        Box::pin(async move {
            let mut guard = journals.lock().map_err(|_| {
                StorageError::new(StorageErrorKind::Internal, "journal store lock poisoned")
            })?;
            guard.insert(record.id.0.clone(), record);
            Ok(())
        })
    }

    fn get_journal<'a>(
        &'a self,
        journal_id: &'a JournalRecordId,
    ) -> BoxFuture<'a, Result<Option<JournalRecord>, StorageError>> {
        let journals = Arc::clone(&self.journals);
        let key = journal_id.0.clone();
        Box::pin(async move {
            let guard = journals.lock().map_err(|_| {
                StorageError::new(StorageErrorKind::Internal, "journal store lock poisoned")
            })?;
            Ok(guard.get(&key).cloned())
        })
    }

    fn list_pending<'a>(&'a self) -> BoxFuture<'a, Result<Vec<JournalRecord>, StorageError>> {
        let journals = Arc::clone(&self.journals);
        Box::pin(async move {
            let guard = journals.lock().map_err(|_| {
                StorageError::new(StorageErrorKind::Internal, "journal store lock poisoned")
            })?;
            Ok(guard
                .values()
                .filter(|record| matches!(record.state, JournalState::Pending))
                .cloned()
                .collect())
        })
    }
}

impl ApplyJournalStore for InMemoryStorage {
    fn put_apply_journal<'a>(
        &'a self,
        record: ApplyJournalRecord,
    ) -> BoxFuture<'a, Result<(), StorageError>> {
        let apply_journals = Arc::clone(&self.apply_journals);
        Box::pin(async move {
            let mut guard = apply_journals.lock().map_err(|_| {
                StorageError::new(StorageErrorKind::Internal, "apply journal store lock poisoned")
            })?;
            guard.insert(record.apply_txn_id.0.clone(), record);
            Ok(())
        })
    }

    fn get_apply_journal<'a>(
        &'a self,
        apply_txn_id: &'a ApplyTxnId,
    ) -> BoxFuture<'a, Result<Option<ApplyJournalRecord>, StorageError>> {
        let apply_journals = Arc::clone(&self.apply_journals);
        let key = apply_txn_id.0.clone();
        Box::pin(async move {
            let guard = apply_journals.lock().map_err(|_| {
                StorageError::new(StorageErrorKind::Internal, "apply journal store lock poisoned")
            })?;
            Ok(guard.get(&key).cloned())
        })
    }

    fn list_pending_apply<'a>(&'a self) -> BoxFuture<'a, Result<Vec<ApplyJournalRecord>, StorageError>> {
        let apply_journals = Arc::clone(&self.apply_journals);
        Box::pin(async move {
            let guard = apply_journals.lock().map_err(|_| {
                StorageError::new(StorageErrorKind::Internal, "apply journal store lock poisoned")
            })?;
            Ok(guard
                .values()
                .filter(|record| {
                    matches!(record.state, crate::execution::ApplyJournalState::Pending)
                })
                .cloned()
                .collect())
        })
    }
}
