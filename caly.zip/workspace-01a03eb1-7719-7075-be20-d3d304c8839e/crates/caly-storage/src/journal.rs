#[derive(Clone, Debug, Eq, PartialEq, Ord, PartialOrd, Hash)]
pub struct JournalRecordId(pub String);

#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub enum JournalState {
    Pending,
    Applied,
    Reverted,
    Abandoned,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub enum JournalAction {
    SetSystemProxy { value: String },
    ClearSystemProxy,
    SetDns { value: String },
    RestoreDns,
    UpTun { device: String },
    DownTun { device: String },
    ApplyRoute { summary: String },
    RestoreRoute { summary: String },
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct JournalRecord {
    pub id: JournalRecordId,
    pub state: JournalState,
    pub actions: Vec<JournalAction>,
    pub created_at_unix_ms: i64,
    pub updated_at_unix_ms: i64,
}
