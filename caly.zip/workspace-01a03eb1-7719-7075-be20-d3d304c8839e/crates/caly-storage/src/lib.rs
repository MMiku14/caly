#![forbid(unsafe_code)]

pub mod cas;
pub mod execution;
pub mod journal;
pub mod memory;
pub mod revision;
pub mod snapshot;
pub mod store;

pub use cas::*;
pub use execution::*;
pub use journal::*;
pub use memory::*;
pub use revision::*;
pub use snapshot::*;
pub use store::*;

pub const STORAGE_SCHEMA_VERSION: u32 = 1;
