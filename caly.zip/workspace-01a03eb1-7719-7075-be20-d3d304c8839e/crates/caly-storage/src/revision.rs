#[derive(Clone, Copy, Debug, Eq, PartialEq, Ord, PartialOrd, Hash)]
pub struct RevisionNumber(pub u64);

#[derive(Clone, Debug, Eq, PartialEq, Ord, PartialOrd, Hash)]
pub struct RevisionId(pub String);

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct RevisionRecord {
    pub id: RevisionId,
    pub number: RevisionNumber,
    pub profile_id: String,
    pub semantic_digest: String,
    pub created_at_unix_ms: i64,
}
