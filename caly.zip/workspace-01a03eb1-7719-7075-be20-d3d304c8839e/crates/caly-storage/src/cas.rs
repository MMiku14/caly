#[derive(Clone, Debug, Eq, PartialEq, Ord, PartialOrd, Hash)]
pub struct ObjectDigest(pub String);

#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub enum ObjectKind {
    RawSource,
    RuleSet,
    CompiledArtifact,
    StageOutput,
    SupportBundle,
}

#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub enum MaterializationMode {
    ReflinkPreferred,
    HardlinkPreferred,
    Copy,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct CasObjectRef {
    pub digest: ObjectDigest,
    pub kind: ObjectKind,
    pub size_bytes: Option<u64>,
    pub content_type: Option<String>,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct CasWriteIntent {
    pub object: CasObjectRef,
    pub source_label: String,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct MaterializationRequest {
    pub object: CasObjectRef,
    pub runtime_path: String,
    pub mode: MaterializationMode,
}
