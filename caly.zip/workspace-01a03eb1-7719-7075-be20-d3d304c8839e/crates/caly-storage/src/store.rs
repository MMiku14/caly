use std::future::Future;
use std::pin::Pin;

use crate::cas::{CasObjectRef, CasWriteIntent, MaterializationRequest};
use crate::execution::{ApplyJournalRecord, ApplyTxnId};
use crate::journal::{JournalRecord, JournalRecordId};
use crate::revision::{RevisionId, RevisionRecord};
use crate::snapshot::{SnapshotRecord, SnapshotRecordId};

pub type BoxFuture<'a, T> = Pin<Box<dyn Future<Output = T> + Send + 'a>>;

#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub enum StorageErrorKind {
    NotFound,
    AlreadyExists,
    Busy,
    Timeout,
    CapacityExceeded,
    IntegrityViolation,
    SchemaMismatch,
    MigrationFailed,
    Internal,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct StorageError {
    pub kind: StorageErrorKind,
    pub summary: String,
}

impl StorageError {
    pub fn new(kind: StorageErrorKind, summary: impl Into<String>) -> Self {
        Self {
            kind,
            summary: summary.into(),
        }
    }
}

pub trait ObjectStore: Send + Sync + 'static {
    fn put<'a>(&'a self, intent: CasWriteIntent) -> BoxFuture<'a, Result<CasObjectRef, StorageError>>;
    fn get<'a>(&'a self, digest: &'a str) -> BoxFuture<'a, Result<Option<CasObjectRef>, StorageError>>;
    fn materialize<'a>(
        &'a self,
        request: MaterializationRequest,
    ) -> BoxFuture<'a, Result<(), StorageError>>;
}

pub trait RevisionStore: Send + Sync + 'static {
    fn put_revision<'a>(
        &'a self,
        record: RevisionRecord,
    ) -> BoxFuture<'a, Result<(), StorageError>>;
    fn get_revision<'a>(
        &'a self,
        revision_id: &'a RevisionId,
    ) -> BoxFuture<'a, Result<Option<RevisionRecord>, StorageError>>;
}

pub trait SnapshotStore: Send + Sync + 'static {
    fn put_snapshot<'a>(
        &'a self,
        record: SnapshotRecord,
    ) -> BoxFuture<'a, Result<(), StorageError>>;
    fn get_snapshot<'a>(
        &'a self,
        snapshot_id: &'a SnapshotRecordId,
    ) -> BoxFuture<'a, Result<Option<SnapshotRecord>, StorageError>>;
    fn latest_last_known_good<'a>(&'a self)
        -> BoxFuture<'a, Result<Option<SnapshotRecord>, StorageError>>;
}

pub trait JournalStore: Send + Sync + 'static {
    fn put_journal<'a>(&'a self, record: JournalRecord)
        -> BoxFuture<'a, Result<(), StorageError>>;
    fn get_journal<'a>(
        &'a self,
        journal_id: &'a JournalRecordId,
    ) -> BoxFuture<'a, Result<Option<JournalRecord>, StorageError>>;
    fn list_pending<'a>(&'a self) -> BoxFuture<'a, Result<Vec<JournalRecord>, StorageError>>;
}

pub trait ApplyJournalStore: Send + Sync + 'static {
    fn put_apply_journal<'a>(
        &'a self,
        record: ApplyJournalRecord,
    ) -> BoxFuture<'a, Result<(), StorageError>>;
    fn get_apply_journal<'a>(
        &'a self,
        apply_txn_id: &'a ApplyTxnId,
    ) -> BoxFuture<'a, Result<Option<ApplyJournalRecord>, StorageError>>;
    fn list_pending_apply<'a>(&'a self)
        -> BoxFuture<'a, Result<Vec<ApplyJournalRecord>, StorageError>>;
}
