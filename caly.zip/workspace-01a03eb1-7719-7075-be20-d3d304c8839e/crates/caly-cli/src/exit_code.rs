use caly_api::{ApiError, ErrorCode};

#[derive(Clone, Copy, Debug, Eq, PartialEq)]
#[repr(i32)]
pub enum ExitCode {
    Success = 0,
    GeneralFailure = 1,
    Usage = 2,
    ConfigInvalid = 3,
    Conflict = 4,
    UnsupportedCapability = 5,
    CoreNotRunning = 6,
    CoreFailed = 7,
    Permission = 8,
    NetOs = 9,
    Storage = 10,
    Timeout = 11,
    Unavailable = 12,
    ProtoMismatch = 13,
    CursorStale = 14,
    Cancelled = 15,
    Internal = 16,
}

impl ExitCode {
    pub const fn as_i32(self) -> i32 {
        self as i32
    }
}

pub const fn from_error_code(code: ErrorCode) -> ExitCode {
    match code {
        ErrorCode::ConfigInvalid => ExitCode::ConfigInvalid,
        ErrorCode::Conflict => ExitCode::Conflict,
        ErrorCode::UnsupportedCapability => ExitCode::UnsupportedCapability,
        ErrorCode::CoreNotRunning => ExitCode::CoreNotRunning,
        ErrorCode::CoreFailed => ExitCode::CoreFailed,
        ErrorCode::Permission => ExitCode::Permission,
        ErrorCode::NetOs => ExitCode::NetOs,
        ErrorCode::Storage => ExitCode::Storage,
        ErrorCode::Timeout => ExitCode::Timeout,
        ErrorCode::Unavailable => ExitCode::Unavailable,
        ErrorCode::ProtoMismatch => ExitCode::ProtoMismatch,
        ErrorCode::CursorStale => ExitCode::CursorStale,
        ErrorCode::Cancelled => ExitCode::Cancelled,
        ErrorCode::Internal => ExitCode::Internal,
    }
}

pub const fn from_api_error(error: &ApiError) -> ExitCode {
    from_error_code(error.code)
}
