use caly_api::{JobFollowView, StreamId};

#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub enum FollowStrategy {
    QueryPolling,
    StreamReplay,
}

#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub enum FollowTerminalState {
    Completed,
    Failed,
    Cancelled,
    TimedOut,
    Running,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct JobFollowPlan {
    pub job_id: caly_api::JobId,
    pub strategy: FollowStrategy,
    pub stream_id: Option<StreamId>,
    pub next_event_index: Option<u64>,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct JobFollowRender {
    pub headline: String,
    pub state: FollowTerminalState,
    pub next_event_index: u64,
    pub reset_required: bool,
}

pub fn classify_job_state(view: &JobFollowView) -> FollowTerminalState {
    match view.state.as_str() {
        "completed" => FollowTerminalState::Completed,
        "failed" => FollowTerminalState::Failed,
        "cancelled" => FollowTerminalState::Cancelled,
        "timedout" | "timed_out" => FollowTerminalState::TimedOut,
        _ => FollowTerminalState::Running,
    }
}

pub fn make_follow_plan(job_id: caly_api::JobId, strategy: FollowStrategy) -> JobFollowPlan {
    JobFollowPlan {
        job_id,
        strategy,
        stream_id: None,
        next_event_index: None,
    }
}

pub fn render_job_follow(view: &JobFollowView) -> JobFollowRender {
    let state = classify_job_state(view);
    JobFollowRender {
        headline: format!(
            "job={} state={} lifecycle={} events={} retained_from={} reset_required={} last_stage={:?} warnings={} logs={} failure_code={:?}",
            view.job_id.0,
            view.state,
            view.lifecycle,
            view.event_count,
            view.retained_from_event_index,
            view.reset_required,
            view.last_stage,
            view.warning_count,
            view.log_count,
            view.failure_code,
        ),
        state,
        next_event_index: view.next_event_index,
        reset_required: view.reset_required,
    }
}

pub fn exit_code_for_follow_state(state: FollowTerminalState) -> i32 {
    match state {
        FollowTerminalState::Completed => 0,
        FollowTerminalState::Failed => 7,
        FollowTerminalState::Cancelled => 15,
        FollowTerminalState::TimedOut => 11,
        FollowTerminalState::Running => 0,
    }
}
