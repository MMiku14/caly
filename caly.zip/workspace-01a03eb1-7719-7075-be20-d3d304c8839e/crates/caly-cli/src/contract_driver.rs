use caly_app::{run_job_follow_query_stream_scenario, run_parity_scenarios, run_smoke_bundle, ScenarioSuite};
use caly_api::JobId;

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct ContractDriverOutput {
    pub headline: String,
    pub lines: Vec<String>,
    pub all_passed: bool,
}

pub fn render_suite(name: &str, suite: &ScenarioSuite) -> ContractDriverOutput {
    let mut lines = Vec::new();
    for case in &suite.entries {
        lines.push(format!(
            "[{:?}] {} :: {}",
            case.status, case.name, case.detail
        ));
    }
    ContractDriverOutput {
        headline: format!("suite={} cases={} all_passed={}", name, suite.entries.len(), suite.all_passed()),
        lines,
        all_passed: suite.all_passed(),
    }
}

pub async fn run_smoke_suite_driver() -> Result<ContractDriverOutput, String> {
    let suite = run_smoke_bundle().await?;
    Ok(render_suite("smoke", &suite))
}

pub async fn run_job_follow_suite_driver(job_id: JobId) -> Result<ContractDriverOutput, String> {
    let suite = run_job_follow_query_stream_scenario(job_id)?;
    Ok(render_suite("job-follow", &suite))
}

pub async fn run_parity_suite_driver() -> Result<ContractDriverOutput, String> {
    let suite = run_parity_scenarios().await?;
    Ok(render_suite("parity", &suite))
}
