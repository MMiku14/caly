use caly_api::JobFollowView;
use caly_ipc::{StreamFrame, StreamPayload};

use crate::follow::{classify_job_state, FollowTerminalState};

#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub enum FollowLoopMode {
    Query,
    Stream,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct FollowLoopState {
    pub mode: FollowLoopMode,
    pub next_event_index: u64,
    pub retained_from_event_index: u64,
    pub reset_required: bool,
    pub terminal: FollowTerminalState,
    pub rendered_lines: Vec<String>,
}

impl FollowLoopState {
    pub fn new(mode: FollowLoopMode) -> Self {
        Self {
            mode,
            next_event_index: 0,
            retained_from_event_index: 0,
            reset_required: false,
            terminal: FollowTerminalState::Running,
            rendered_lines: Vec::new(),
        }
    }

    pub fn apply_job_view(&mut self, view: &JobFollowView) {
        self.next_event_index = view.next_event_index;
        self.retained_from_event_index = view.retained_from_event_index;
        self.reset_required = view.reset_required;
        self.terminal = classify_job_state(view);
        self.rendered_lines.push(format!(
            "job={} state={} lifecycle={} next_event_index={} retained_from={} reset_required={} events={} last_stage={:?} last_stage_pct={:?} warnings={} logs={} failure_code={:?} failure_summary={:?}",
            view.job_id.0,
            view.state,
            view.lifecycle,
            view.next_event_index,
            view.retained_from_event_index,
            view.reset_required,
            view.event_count,
            view.last_stage,
            view.last_stage_pct,
            view.warning_count,
            view.log_count,
            view.failure_code,
            view.failure_summary,
        ));
    }

    pub fn apply_stream_frame(&mut self, frame: &StreamFrame) {
        self.rendered_lines.push(render_stream_frame(frame));
        self.next_event_index = self.next_event_index.max(frame.seq.saturating_add(1));
        if matches!(frame.payload, StreamPayload::Reset { .. }) {
            self.reset_required = true;
        }
    }
}

pub fn render_stream_frame(frame: &StreamFrame) -> String {
    match &frame.payload {
        StreamPayload::SnapshotJson(value) => format!("snapshot: {}", value),
        StreamPayload::PatchJson(value) => format!("patch: {}", value),
        StreamPayload::Reset { reason } => format!("reset: {:?}", reason),
        StreamPayload::JobStage { job_id, stage, pct } => format!(
            "job={} stage={} pct={:?}",
            job_id.0, stage, pct
        ),
        StreamPayload::JobWarning { job_id, message } => {
            format!("job={} warning={}", job_id.0, message)
        }
        StreamPayload::JobLog { job_id, level, message } => {
            format!("job={} log[{}]={}", job_id.0, level, message)
        }
        StreamPayload::JobFailed {
            job_id,
            code,
            summary,
            remediation,
        } => match remediation {
            Some(remediation) => format!(
                "job={} failed code={} summary={} remediation={}",
                job_id.0, code, summary, remediation
            ),
            None => format!("job={} failed code={} summary={}", job_id.0, code, summary),
        },
        StreamPayload::JobDone { job_id, outcome } => {
            format!("job={} done={:?}", job_id.0, outcome)
        }
        StreamPayload::CommandAccepted { job_id, revision } => {
            format!("command accepted job={} revision={}", job_id.0, revision)
        }
        StreamPayload::CommandRejected { reason } => {
            format!("command rejected reason={}", reason)
        }
        StreamPayload::RuntimeState {
            active_profile,
            active_core,
            active_snapshot,
            state_revision,
            summary,
        } => format!(
            "runtime summary={} profile={:?} core={:?} snapshot={:?} rev={}",
            summary, active_profile, active_core, active_snapshot, state_revision
        ),
        StreamPayload::DeploymentEvent { summary } => format!("deployment event={}", summary),
        StreamPayload::SnapshotCommitted { snapshot_id } => {
            format!("snapshot committed={}", snapshot_id)
        }
        StreamPayload::RecoveryEvent { summary } => format!("recovery event={}", summary),
    }
}

pub fn follow_requires_reset(state: &FollowLoopState) -> bool {
    state.reset_required
}

pub fn follow_is_terminal(state: &FollowLoopState) -> bool {
    !matches!(state.terminal, FollowTerminalState::Running)
}
