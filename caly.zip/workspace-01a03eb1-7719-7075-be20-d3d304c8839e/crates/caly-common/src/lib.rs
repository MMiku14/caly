#![forbid(unsafe_code)]

#[derive(Clone, Debug, Eq, PartialEq, Hash)]
pub struct TraceId(pub String);

impl TraceId {
    pub fn new(value: impl Into<String>) -> Self {
        Self(value.into())
    }
}

#[derive(Clone, Copy, Debug, Eq, PartialEq, Ord, PartialOrd, Hash)]
pub enum Actor {
    Cli,
    Tui,
    Timer,
    Recovery,
    Automation,
    System,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct IoBudget {
    pub max_bytes: Option<u64>,
    pub max_requests: Option<u32>,
}

impl IoBudget {
    pub const fn unlimited() -> Self {
        Self {
            max_bytes: None,
            max_requests: None,
        }
    }
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct RequestContext {
    pub trace_id: TraceId,
    pub actor: Actor,
    pub deadline_ms: Option<u64>,
    pub expected_revision: Option<u64>,
    pub io_budget: IoBudget,
}

impl RequestContext {
    pub fn new(trace_id: TraceId, actor: Actor) -> Self {
        Self {
            trace_id,
            actor,
            deadline_ms: None,
            expected_revision: None,
            io_budget: IoBudget::unlimited(),
        }
    }
}
