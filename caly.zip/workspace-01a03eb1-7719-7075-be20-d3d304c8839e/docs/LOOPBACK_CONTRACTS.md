# Caly Loopback Contract Strategy

本文件说明为什么 `LoopbackHarness`、`RemoteSessionClient`、`ServerLoop` 与 `ContractReport` 应共同构成 Caly 在 IPC 层最早期的 contract strategy。

---

## 1. 当前阶段为什么要靠 loopback contract

在还没有：

- 真实 UDS runtime
- Windows Named Pipe runtime
- 完整 async transport loop
- 全量 RemoteApi/CLI 集成

之前，最值得先做的是：

- 验证协议语义
- 验证 local/remote parity
- 验证 hello/request/stream/ack/follow 的闭环

而 loopback contract 正好最适合这件事。

---

## 2. 当前已具备的拼图

当前已开始具备：

- `LoopbackHarness`
- `LoopbackRemoteTransport`
- `RemoteSessionClient`
- `RemoteFacade`
- `LocalFacade`
- `run_basic_parity_check(...)`
- `run_system_contract(...)`
- `run_job_follow_contract(...)`
- `run_loopback_remote_contract(...)`
- `run_basic_wire_probe()`
- `run_loopback_scenarios()`
- `run_remote_follow_scenarios()`
- `run_contract_bundle()`

这意味着：

> Caly 已经有能力在不依赖真实 socket runtime 的情况下，对协议和 facade 路径做高价值 contract 验证。

---

## 3. 推荐 contract 分层

### Layer 1 — Wire/Session Contract

关注：

- hello
- frame validation
- session close
- stream ack legality

### Layer 2 — Request/Response Contract

关注：

- operation dispatch
- request -> command
- response shape
- error mapping

### Layer 3 — Watch/Follow Contract

关注：

- runtime watch
- job follow query
- job follow stream
- replay / reset / retained window

### Layer 4 — Local/Remote Parity Contract

关注：

- 相同输入是否返回同语义输出
- skeleton 阶段是否已经开始出现漂移

---

## 4. 一句话结论

> 在 Caly 当前阶段，loopback contract 不是权宜之计，而是把协议设计真正压实为可验证实现的最短路径。