# Caly Overload and Retry Model

本文件说明当 Caly 遇到：

- queue full
- event backlog
- stream backpressure
- frame too large
- storage busy
- temporary transport pressure
- apply execution resource contention

时，应如何把这些问题表达为**统一可解释的系统状态、协议语义与用户错误**。

---

## 1. 为什么 overload 不能只当内部异常

如果 overload/backpressure 只作为内部日志存在，会出现问题：

- CLI 不知道该不该重试
- Remote client 不知道是配置错了还是系统忙
- session/stream 层会出现模糊失败
- apply job 可能在资源压力下表现为“像配置坏了”

因此，队列满、短时不可用、回放窗口失效、存储繁忙，必须进入公开错误语义和/或事件语义。

---

## 2. 当前代码里已经存在的基础

当前代码已开始出现：

- `QueuePolicy { max_len }`
- bounded event log
- `SubmitRejected`
- `OverloadClass`
  - `QueueFull`
  - `EventBacklog`
  - `StreamBackpressure`
  - `StorageBusy`
- `RetryHint`
  - `RetryImmediately`
  - `RetryLater`
  - `ReopenSession`
  - `ManualIntervention`
- `OverloadReport::to_api_error(...)`
- daemon `submit_request_as_command(...)` 中的 overload -> `ApiError` 映射

这说明 overload 已开始被当作一等系统行为，而不再只是偶发异常。

---

## 3. overload 的公开分类

推荐至少固定以下公开语义：

### 3.1 `QueueFull`

表示：

- daemon/engine 当前命令队列已达到上限
- 请求尚未进入执行态

典型处理：

- 返回 retryable error
- 给出 `RetryLater`
- 不产生 apply side effect

### 3.2 `EventBacklog`

表示：

- 事件窗口已滚动
- 查询/跟随者请求的游标已落在保留区之外

典型处理：

- query 返回 stale / reset-required 语义
- stream 返回 `Reset`
- 用户需重新打开或重新同步

### 3.3 `StreamBackpressure`

表示：

- 客户端消费速度不足
- 无法继续维持预期投递语义

典型处理：

- 对 latest-value stream 可 coalesce
- 对 replayable stream 可 reset
- 对严格有序流可断开并要求 reopen

### 3.4 `StorageBusy`

表示：

- snapshot/journal/object write 所依赖的底层存储当前不可快速获取

典型处理：

- 返回 retryable error
- 禁止把它伪装成配置错误
- 若已进入 cutover 阶段，必须升级为 recovery-sensitive 失败路径

### 3.5 `FrameTooLarge`

表示：

- 请求或响应超过协议允许大小

典型处理：

- 立即拒绝
- 指向协议/客户端行为问题，而非系统忙
- 通常不建议自动重试相同输入

### 3.6 `ProtocolPressure`

表示：

- hello/session/frame 校验失败或 transport runtime 资源受限

典型处理：

- 区分：协议不匹配、会话失效、暂时拥塞
- 只有暂时拥塞可提示重试；协议不匹配应直接失败

---

## 4. RetryHint 的真正语义

`RetryHint` 不应只是 UI 文案，而应是行为建议。

### 4.1 `RetryImmediately`

仅适用于：

- 明确尚未产生副作用
- 且失败高度可能是瞬时争用

不适用于：

- 已触发 apply cutover
- 已触发 stream reset
- 已知协议不兼容

### 4.2 `RetryLater`

适用于：

- queue full
- 短时 storage busy
- daemon 正在 drain backlog

### 4.3 `ReopenSession`

适用于：

- stream cursor 已失效
- session 被服务端关闭
- hello 生命周期需要重新协商

### 4.4 `ManualIntervention`

适用于：

- recovery failed
- 持续 storage integrity 问题
- capability/blocking policy 冲突
- repeated overload 但无法自动收敛

---

## 5. Query / Command / Stream 三类路径中的 overload 表达

### 5.1 Query

Query 路径中的 overload 典型包括：

- stale cursor
- snapshot not retained
- temporary storage busy

表达方式应偏向：

- 结构化错误
- reset-required view field
- 明确 remediation

### 5.2 Command

Command 路径中的 overload 典型包括：

- queue full
- executor busy
- storage busy before prepare begins

表达方式应偏向：

- `ApiError`
- `retryable=true/false`
- `retry hint`
- 不应伪装成 Accepted Job

### 5.3 Stream

Stream 路径中的 overload 典型包括：

- replay gap
- backpressure
- session drift

表达方式应偏向：

- `Reset`
- server close reason
- reopen requirement

---

## 6. apply execution 与 overload 的交叉约束

一旦 apply executor 落地，overload 必须更细化地进入事务模型。

### 6.1 Prepare 前 overload

例如：

- queue full
- storage busy before journal pending

要求：

- 可以安全重试
- 不得污染 active runtime

### 6.2 Cutover 中 overload

例如：

- storage busy while updating journal cursor
- runtime control plane timeout
- privileged helper busy

要求：

- 不得简单提示“稍后再试”就结束
- 必须进入 recovery-aware 失败路径
- job follow 需要看到是 execution failure，不是 validation failure

### 6.3 Verify 后 overload

例如：

- snapshot commit busy
- revision commit contention

要求：

- 若 runtime 已成功切换，则必须优先保证真相提交收敛
- 不允许留下“新 runtime 成功，但 snapshot 未知”的悬空状态

---

## 7. public error 与 internal event 的分层

同一次 overload 可能需要两个出口：

### 7.1 public error

面向：

- CLI
- Remote client
- automation caller

关注：

- 能否重试
- 需要何种动作
- 是否是用户错误

### 7.2 internal event

面向：

- diagnostics
- support bundle
- operator trace

关注：

- backlog 长度
- queue cap
- retained window 起点
- journal cursor 所在阶段

两者都需要，但不能混为一谈。

---

## 8. 推荐的错误映射纪律

### 必须区分

- 配置错误 vs overload
- capability blocked vs temporary busy
- protocol mismatch vs reopen-session
- validation failed vs execution failed vs recovery failed

### 禁止出现

- 只返回一条 `Unavailable`，不给任何细分线索
- 把 queue full 伪装成内部错误
- 把 stream reset 伪装成空结果
- 把 recovery failed 当作普通 apply failed

---

## 9. 对 CLI / TUI 的最低要求

CLI/TUI 至少应能表达：

- 这是不是 overload
- 是否建议重试
- 是立刻重试、稍后重试还是重开 session
- 是否需要人工处理
- 是否可能涉及 apply/recovery 风险

示例语义：

```text
error=queue_full
retryable=true
retry_hint=RetryLater
remediation=wait for current jobs to drain or reduce submit rate
```

```text
error=stream_backpressure
retryable=true
retry_hint=ReopenSession
remediation=reopen watch stream from latest cursor
```

```text
error=recovery_failed
retryable=false
retry_hint=ManualIntervention
remediation=inspect support bundle and last-known-good snapshot state
```

---

## 10. 推荐的下一阶段落地点

### Stage 1

- 把 overload 分类继续贯通到 query/stream path
- 固定 frame too large / protocol pressure 的 public mapping

### Stage 2

- 让 job follow 能区分：
  - validation failed
  - overload rejected
  - execution failed
  - recovery failed

### Stage 3

- 让 apply executor 与 storage/recovery 共享 overload taxonomy
- support bundle / doctor 输出 overload summaries

---

## 11. 一句话结论

> overload 不是神秘失败，而必须被表达成：可分类、可提示、可恢复、可与 apply/recovery 风险区分的公开系统语义。