# Caly CLI Exit Codes

本文件定义 Caly CLI 的稳定退出码策略，用于：

- shell 脚本
- CI/CD
- 系统服务管理器
- 自动化调用
- 故障分类与重试策略

本文件与 `docs/ERRORS.md` 配套：

- `ERRORS.md` 定义公共错误对象与稳定错误码
- `EXIT_CODES.md` 定义 CLI 如何把错误码映射为进程退出码

---

## 1. 设计原则

1. 退出码必须稳定、有限、可脚本判断。
2. 退出码不承载完整错误上下文；详细信息应通过 `ApiError` 或日志获取。
3. 对同一种公共错误码，CLI 应尽量给出一致退出码。
4. `--json` 不改变退出码语义。
5. Job 化写操作在前端等待完成后，再根据最终 outcome 决定退出码。

---

## 2. 成功与通用失败

| Exit Code | 含义 |
|---:|---|
| `0` | 成功 |
| `1` | 未归类的一般失败；仅在没有更具体映射时使用 |
| `2` | CLI 用法错误，如参数不合法、缺失必要参数、命令拼写错误 |

说明：

- `2` 用于**CLI 自身解析/用法错误**，不是业务配置错误。
- 业务层配置问题应使用 `3`（`CONFIG_INVALID`）。

---

## 3. 稳定业务退出码

| Exit Code | ErrorCode | 说明 |
|---:|---|---|
| `3` | `CONFIG_INVALID` | 配置、patch、schema、引用、语义校验失败 |
| `4` | `CONFLICT` | 资源冲突、合并冲突、端口冲突等 |
| `5` | `UNSUPPORTED_CAPABILITY` | Core/平台/版本/strict 模式下能力不足 |
| `6` | `CORE_NOT_RUNNING` | 依赖运行中 Core 的操作，但当前无活动实例 |
| `7` | `CORE_FAILED` | Core 启动、校验、重载、控制或运行失败 |
| `8` | `PERMISSION` | 权限不足、提权失败或访问受限 |
| `9` | `NET_OS` | OS 网络层失败，如 TUN、系统代理、DNS、路由应用失败 |
| `10` | `STORAGE` | DB、文件、CAS、磁盘空间或完整性问题 |
| `11` | `TIMEOUT` | 操作超时 |
| `12` | `UNAVAILABLE` | daemon/helper/service/core API 暂时不可达 |
| `13` | `PROTO_MISMATCH` | CLI 与 daemon 协议/方法不兼容 |
| `14` | `CURSOR_STALE` | 分页 cursor 已过期，需要重新查询 |
| `15` | `CANCELLED` / interrupted | 用户中断、cancel、受控终止 |
| `16` | `INTERNAL` / unknown internal failure | 未分类内部错误 |

---

## 4. 映射规则

### 4.1 从 `ApiError.code` 到退出码

CLI 在接收到稳定公共错误码时，应按上表映射。

若存在多个嵌套错误：

- 优先使用**最终暴露给用户的公共 `ApiError.code`**
- 不应根据内部错误堆栈自行重新推断退出码

### 4.2 没有 `ApiError.code` 的情况

若失败发生在 CLI 本地，且尚未形成公共 `ApiError`：

- 参数/命令用法问题 -> `2`
- 用户中断 -> `15`
- 其他未归类本地异常 -> `1` 或 `16`

### 4.3 Job 模式

对于会进入 Job 管线的命令：

```text
execute -> follow(job) -> outcome/error -> exit code
```

规则：

- Job 成功完成 -> `0`
- Job 明确失败并返回公共错误码 -> 对应映射值
- Job 跟踪超时 -> `11`
- Job 跟踪中连接断开且无法确认最终结果 -> 优先 `12` 或 `11`，并提示用户使用 `status`/`doctor`/`job follow` 再确认

---

## 5. 推荐 shell 语义

### 5.1 可重试类

可考虑自动重试的退出码：

- `11` (`TIMEOUT`)
- `12` (`UNAVAILABLE`)
- 某些场景下 `8` (`PERMISSION`) 若已知可通过补救动作解决

### 5.2 一般不应重试类

默认不应自动重试的退出码：

- `3` (`CONFIG_INVALID`)
- `4` (`CONFLICT`)
- `5` (`UNSUPPORTED_CAPABILITY`)
- `13` (`PROTO_MISMATCH`)
- `14` (`CURSOR_STALE`；应重查而不是重试同命令)

---

## 6. 示例

### 6.1 参数错误

```bash
caly profile apply --unknown-flag
# exit 2
```

### 6.2 Profile 配置非法

```bash
caly profile apply work
# returns CONFIG_INVALID
# exit 3
```

### 6.3 端口冲突

```bash
caly profile apply work
# returns CONFLICT
# exit 4
```

### 6.4 能力不足

```bash
caly profile apply singbox-ech-on-unsupported-core
# returns UNSUPPORTED_CAPABILITY
# exit 5
```

### 6.5 Core 未运行

```bash
caly proxy select auto hk-1
# returns CORE_NOT_RUNNING
# exit 6
```

### 6.6 用户中断

```bash
caly profile apply work
# Ctrl-C
# exit 15
```

---

## 7. 变更规则

以下变更视为外部兼容性事件：

- 修改已有错误码对应的退出码
- 删除已有退出码语义
- 让同一稳定错误码在不同命令上无故映射为不同退出码

以下变更通常兼容：

- 新增新的错误码并分配新的退出码
- 改进 stderr / JSON 中的说明文字

---

## 8. 推荐测试

1. 每个稳定错误码都能映射到预期退出码
2. `--json` 与普通模式退出码一致
3. Job 成功/失败/超时/中断路径退出码正确
4. 本地 CLI 参数错误稳定返回 `2`
5. Ctrl-C 或受控取消返回 `15`

---

## 9. 一句话原则

> 退出码是脚本契约，不是展示文案；少而稳，比多而乱更重要。