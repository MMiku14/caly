# Caly Glossary

本术语表用于统一 Caly 文档、代码、CLI/TUI 文案与测试描述中的核心概念。

规则：

- 中文文档优先保留英文技术名词原文，避免歧义。
- 同一个概念应尽量只用一个主称呼。
- 若出现多个历史称呼，应在本表中指定首选词。

---

## A

### Active Core
当前唯一处于生效状态的 Core 进程。Caly 的架构不允许同一时刻存在两个 Active Core。

### Adapter
适配层。把 Caly 的统一语义转换为 Mihomo/sing-box 的原生配置、校验与运行时 API 交互。

### ADR
Architecture Decision Record，架构决策记录。用于说明“为什么这么设计”，不替代 RFC。

### Apply
将目标配置和相关系统副作用切换为新状态的事务过程。

### ApplyPlan
从当前运行态切换到目标运行态的最小安全部署策略，例如 `Noop`、`ApiPatch`、`Restart`。

---

## C

### CalyIR
Caly 的统一中间表示（IR）。只表达统一语义，不伪装成某个 Core 的原生配置文件。

### Capability
某项功能在给定 Core、版本、平台、权限条件下的支持状态。

### Capability Registry
Capability 的唯一事实来源。用于统一编译、Doctor、CLI/TUI 展示与测试证据。

### CAS
Content-Addressed Storage，内容寻址存储。以内容哈希作为对象标识存放原文、工件与中间结果。

### Command
会引起状态变更或可能引发副作用的请求类型。所有 Command 都应进入 Job 管线。

### Compilation
`Lower + Emit` 后得到的目标 Core 原生产物及其元数据。

### Coordinator
部署与状态变更的显式编排者。负责按顺序调用服务并处理补偿，而不是依赖散乱事件编排。

### Core
本文中指 Mihomo 或 sing-box 的可执行体，而非 Caly 自身。

### Core Identity
描述目标 Core 的身份信息，至少应包含种类、版本、构建特征与二进制摘要等信息。

### Ctx
贯穿 API、Engine 与 IO Port 的统一上下文。承载 `trace_id`、deadline、cancel token、expected revision 等横切信息。

---

## D

### Daemon
常驻后台控制进程，即 `calyd`。它是唯一的可变状态所有者。

### Diagnostic
编译、合并、校验、部署过程中产生的结构化诊断信息，通常分为 `Error` / `Warning` / `Info`。

### DTO
Data Transfer Object，跨 Facade/IPC 使用的稳定数据结构，不应直接泄漏内部领域实现。

---

## E

### EffectPlan
副作用执行计划。描述需要执行的 EffectStep、所需权限和失败时的补偿步骤。

### EffectStep
EffectPlan 中的一步副作用操作，例如写对象、启动 Core、应用网络计划、执行探测等。

### Engine
Caly 的编排核心，负责接收 Command、调度 Pipeline、协调 Storage/Core/Platform 并管理 Job。

### Event
面向观察者的状态变化通知。Event 用于通知，不用于隐藏业务编排。

### Executor
唯一允许把 `EffectStep` 变成真实系统调用的执行器。

### Extension
统一 IR 中用于承载已知但非公共语义、偏向目标 Core 的扩展字段集合。

---

## F

### Facade
对外统一控制面。CLI/TUI 只应依赖 Facade，而不能直接依赖 Engine 或 Adapter。

### Facet
Facade 下按领域拆分的子接口，如 `ProfileFacet`、`RuntimeFacet`。

### Fallback
当目标能力不足时允许采取的显式降级策略。必须可审计、可解释，不允许静默忽略。

---

## H

### Health Probe
部署后用于判定“新状态是否真实可用”的探测流程。进程存在本身不等于健康。

---

## I

### IPC
Inter-Process Communication，CLI/TUI 与 `calyd` 之间的本地进程间通信机制。

### IR
Intermediate Representation，中间表示。Caly IR 是统一语义而非原生 YAML/JSON。

### IoFault
IO 层统一错误分类，用于向上层表达是否可重试、是否权限问题、是否容量不足等。

### Idempotency Key
幂等键。用于确保重复提交高风险 Command 时不会触发重复部署或重复副作用。

---

## J

### Job
异步执行中的工作单元。所有写操作应被建模为 Job，并可被跟踪、订阅与恢复。

### Journal
用于记录可恢复副作用的持久日志。若专指系统网络状态变化日志，则称 `OSJournal`。

---

## L

### Last Known Good
最近一次通过完整健康检查并可作为回滚目标的已验证状态。

### LocalApi
在同进程内直接调用 Engine 的 Facade 实现，通常用于 `--no-daemon` 和测试。

### Lower
将 `ResolvedProfile` 映射到目标 Core 原生 AST 的纯阶段。

---

## M

### Merge
把多来源配置、Override、默认值与安全策略合成为统一对象图的过程。Caly 使用语义合并，不使用无类型 deep merge。

### MergeReport
描述 merge 阶段发生的 rename、drop、override、conflict 与来源信息的结构化报告。

---

## O

### Opaque Preserved
一种支持层级：表示 Caly 可保真保存并回写，但不承诺理解其完整语义或跨 Core 转换。

### Operation
RemoteApi/IPC 对外暴露的统一操作封装。每个 Operation 必须声明其语义与权限属性。

### OSJournal
系统级副作用日志，记录 system proxy、DNS、TUN、路由等可逆操作，用于恢复与回滚。

### Override
用户对 Profile/Source 施加的结构化补丁，不应通过直接改写上游订阅原文实现。

---

## P

### Passthrough
统一层不理解但需要保真保存的原生字段容器。通常以原生路径位置存储并回写。

### Pipeline
配置处理主链路。把不可信输入逐步转换为确定性编译产物。

### Pipeline Epoch
管线缓存与语义兼容纪元。若管线语义变化导致旧缓存不可复用，则需 bump。

### Privilege Helper
按需使用的最小特权助手进程/服务，用于执行 TUN、路由、系统 DNS 等高权限操作。

### Provenance
字段级来源追踪信息，用于解释“这个结果从哪里来、覆盖了什么、经过哪些阶段”。

---

## Q

### Query
只读快照式请求。不会触发持久变更，也不承担副作用语义。

---

## R

### RemoteApi
通过 IPC 与 `calyd` 通信的 Facade 实现。

### ResolvedProfile
完成语义合并、引用解析、默认值注入与能力前置决策后的完整对象图。

### Revision
描述某次可持久化配置状态的版本单位，通常与 Profile 变化、Source 更新或部署提交有关。

### RFC
Request for Comments。Caly 中用作正式架构/契约规范文档。

### Rollback
在新部署失败后恢复到旧的已验证状态，并撤销相关副作用。

### RuntimeDriver
面向具体 Core 的运行时控制/观测适配层，负责状态、流量、连接、选择切换、探测等能力。

### RuntimeView
对运行时状态的统一投影，供 CLI/TUI/Doctor 使用。

---

## S

### Snapshot
经过验证、可作为回滚目标的持久状态快照。

### Source
Profile 所引用的配置来源，可以是订阅、本地文件或内联内容。

### Stage
Pipeline 中的一个稳定处理阶段，如 `MERGE`、`LOWER`、`EMIT`。

### Strict Mode
严格模式。对 `Unknown` / `Experimental` / 能力不足等状态采取更保守的阻断策略。

### Support Level
功能支持层级，区分 `CalyManaged`、`NativeManaged`、`OpaquePreserved`。

### Supervisor
Core 生命周期监督者，负责安装、启动、停止、重载、异常退出分类与进程清理。

---

## T

### Targeted Profile
偏向某一目标 Core 的 Profile 形态，可包含该 Core 的 Native Extension，但仍受统一控制面约束。

### TUI
基于终端的交互式界面，是对 daemon Event/Watch 状态的投影。

---

## V

### VerifyGate
位于纯管线外的原生校验步骤，使用真实 Core 对编译产物做验证。

### VPath
受根目录约束的虚拟路径类型，用于避免路径逃逸、任意绝对路径和符号链接绕过。

---

## W

### Watch
持续订阅某一视图或 Job 事件流的交互语义。

---

## 统一用词建议

| 历史/易混用词 | 建议统一词 |
|---|---|
| 核心 / 内核 / 后端 Core | Core |
| 后台 / 服务 / 守护进程 | Daemon / `calyd` |
| 编译结果 / 生成配置 | Compilation / Artifact |
| 应用配置 / 切换配置 | Apply |
| 热更新 / 热重载 | 优先分清 `ApiPatch` 与 `HotReload` |
| 状态同步 / 推送 | Watch / Stream |
| 恢复 / 修复 | Recovery（全局） / Repair（局部） |
| 规则解释 / 命中分析 | Explain |

---

## 一句话原则

> 如果某个词在不同文档里含义不一致，先修改术语表，再修改正文。