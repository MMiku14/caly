# Caly Roadmap

本文件给出 Caly 从文档冻结走向可运行系统的建议实施路线。

路线的核心原则是：

> **先建立边界与契约，再做最小纵向切片，最后扩展功能面。**

并且在当前阶段还要再补上一条更硬的执行原则：

> **优先持续闭合中心主链，而不是反复扩外围协议壳。**

也就是说，Roadmap 的阶段不是“先界面后底层”，而是：

1. 先让契约可编译
2. 再让 centerline 可解释、可验证、可计划
3. 再让 daemon / IPC / CLI 围绕 centerline 形成真正执行闭环

---

## 1. 路线概览

| 阶段 | 目标 | 核心产物 | 当前状态 |
|---|---|---|---|
| Phase 0 | 文档冻结 | RFC-0001 ~ RFC-0010，ADR-011 ~ ADR-034 | `Done` |
| Phase 1 | 工程边界落地 | workspace、crate 骨架、clippy/arch guardrails | `Done` |
| Phase 2 | 源码级契约落地 | Operation、ApiError、Facet、IoFault、Stage、ApplyPlan、EffectStep、IPC skeleton、registry schema | `Partial` |
| Phase 2.5 | 编译打通与契约收敛 | toolchain、workspace check、依赖修复、命名收敛 | `Done` |
| Phase 3 | 基础设施骨架 | IO、Storage、CAS、Pipeline skeleton、sim world | `Partial` |
| Phase 4 | 控制链与 daemon 骨架 | Command、Job、Coordinator、queue、event、daemon bootstrap | `Partial` |
| Phase 5 | 核心主链纵向切片 | Profile/Source/Override -> IR -> ResolvedProfile -> Native -> ApplyPlan | `In Progress` |
| Phase 6 | Daemon / IPC / CLI 连接 | LocalApi、RemoteApi、Job、watch、CLI 可用 | `In Progress` |
| Phase 7 | 双 Core 纵向切片 | Mihomo / sing-box 两个 core 的第一版 vertical slice | `Partial` |
| Phase 8 | Platform / Recovery | TUN、system proxy、helper、journal、rollback、recovery | `Planned` |
| Phase 9 | TUI / Runtime UX | dashboard、connections、traffic、logs、select/probe UX | `Planned` |
| Phase 10 | 硬化与发布门禁 | fuzz、真核 CI、性能回归、doctor、support bundle | `Planned` |

---

## 2. 已完成的阶段修正

### 2.1 Phase 1 — 工程边界落地

已完成：

- workspace 与 crate 结构建立
- 基本 arch guardrails / clippy 约束建立
- 代码组织已达到可持续迭代的基本形态

因此，Phase 1 不再应视为 `Partial`。

### 2.2 Phase 2.5 — 编译打通与契约收敛

这一阶段现在已经真实完成：

- Rust toolchain 已安装
- `cargo check --workspace` 已跑通
- 多个 crate 间的依赖/导出/类型裂缝已被修补
- 后续推进已可建立在真实编译反馈之上

这一步虽然不是“产品功能”，但它非常关键，因为它把 Caly 从“静态骨架堆积”推进到了“动态可检验骨架”。

---

## 3. Phase 2 — 源码级契约落地

### 当前进展

已完成：

- `caly-common`
- `caly-api` 基础 DTO / Error / Facet / Operation
- `caly-plan` 中 `ApplyPlan` / `EffectPlan`
- `caly-io` 基础 Port / Fault / VPath
- `caly-cap` registry / loader 骨架
- `caly-ipc` frame / handshake / stream / dispatch / codec / client / session primitive
- `caly-cli` exit code / follow / driver / contract_driver 基础骨架

仍需补齐：

- DTO 真正迁移出 `operation.rs`
- DTO 分面之间重复 re-export 与旧定义并存问题
- `caly-api` 对外导出面继续收敛
- 更严格的 schema / validation 层

---

## 4. Phase 3 — 基础设施骨架

### 当前进展

已完成：

- `caly-storage` 基本数据类型、store trait 与 in-memory backend 骨架
- `caly-io-sim` 的世界模型、fault injector、首批 Port impl 与 scenario builder
- workspace 编译已覆盖这些 crate

仍需补齐：

- `caly-io-std`
- storage facade 深化
- provenance/codegen 缓存体系
- 更丰富的 step-aware scenario 与故障回放

---

## 5. Phase 4 — 控制链与 daemon 骨架

### 当前进展

已完成：

- `caly-engine` 的 Command / Queue / Job / Idempotency / Event / Worker 基本骨架
- `caly-daemon` 的 lifecycle / session / transport / registry / runtime / harness 基本骨架
- `caly-app` 的 local/remote/parity/contract/scenario 基本装配

仍需补齐：

- worker consume cycle 深化
- overload/public error 更完整贯通
- daemon 与 engine/storage 的真实装配
- command path 对 apply vertical slice 的执行接线

---

## 6. Phase 5 — 核心主链纵向切片

### 当前进展

这是当前最应该继续投入的主线。

已完成：

- `caly-domain` 可表达 `Profile / Override / SelectionMemory`
- `caly-pipeline` 已开始真实消费 source refs / normalized source / override / selection memory
- merge 阶段开始物化图结构
- resolve 阶段开始做 deterministic manifest / semantic digest / revision
- semantic / capability validation 已开始形成结构性检查
- adapter 开始产出 native artifact bytes
- `ApplyPlan` / `EffectPlan` 已开始有可读步骤投影

### 当前阶段完成定义

本阶段要从 `In Progress` 走向 `Done`，至少还需要：

1. 真实 source parse / normalize
2. registry 驱动的 capability validation
3. apply executor 与 snapshot/journal 的连接
4. daemon command path 触发真实 apply workflow

---

## 7. Phase 6 — Daemon / IPC / CLI 连接

### 当前进展

与之前相比，这一阶段已经不应继续标成 `Planned`。

已完成：

- `LocalFacade` / `RemoteFacade` 均可编译
- loopback transport / harness / client session 已可编译运行于工程骨架层
- parity / contract / scenario 已有真实代码入口
- daemon query path 已接入：
  - `ProfileOp::Plan`
  - `DiagnosticsOp::ExplainPipeline`

### 仍需补齐

- request -> command -> apply workflow 真执行闭环
- stream runtime 的 read/write pump
- reconnect / timeout scheduler
- CLI `apply/status/follow` 与真实 job lifecycle 对接

---

## 8. Phase 7 — 双 Core 纵向切片

### 当前进展

已从 `Planned` 提升到 `Partial`。

当前已有：

- `caly-mihomo`
  - YAML-shaped native artifact
  - native validation
  - apply planning
  - vertical slice helper
- `caly-singbox`
  - JSON-shaped native artifact
  - native validation
  - apply planning
  - vertical slice helper

### 仍需补齐

- 更真实的 capability matrix 差异
- binary inspection / version coverage / native validation fixture
- runtime API model 与 process lifecycle

---

## 9. Phase 8 — Platform / Recovery

### 目标

把平台副作用正式纳入部署事务。

### 当前前置条件已出现

虽然 executor 尚未落地，但 `EffectPlan` 已经开始表达：

- `NetApply`
- `NetRevert`
- `SpawnCore`
- `StopCore`
- `Probe`
- `MarkSnapshot`
- `CommitRevision`

这说明 Platform / Recovery 不再是纯文档概念，而是已经有建模承载位。

---

## 10. Phase 9 — TUI / Runtime UX

### 目标

提供真正可交互的管理体验，但不破坏控制面边界。

### 约束

在 Phase 5 / 6 / 8 未进一步闭环前，不应让 TUI 反向驱动架构偏航。

---

## 11. Phase 10 — 硬化与发布门禁

### 目标

把“能编译、能演示”提升为“可发布、可维护、可回归”。

### 关键门禁

- 真 core fixture
- native validation fixture
- contract/regression suite
- overload/backpressure coverage
- support bundle / doctor / secret redaction

---

## 12. 推荐最小里程碑（更新版 MVP 顺序）

建议按以下顺序继续推进：

1. 继续瘦 `caly-api::operation.rs`
2. 用真实 source parser 替换 `NormalizedSource` stub 入口
3. 让 capability validation 真正读取 registry / coverage matrix
4. 让 `engine::apply` 接 storage snapshot / journal projection
5. 让 daemon command path 接入 apply executor
6. 完成 IPC runtime pump 与 reconnect/timeout 语义
7. 补 CLI `profile plan/apply/status/follow`
8. 再推进 TUI 与 richer runtime UX

---

## 13. 当前最优动作

基于当前 workspace 状态，下一步最值得做的是：

1. **API 收敛**：完成 DTO 迁移，削薄 `operation.rs`
2. **中心主链深化**：真实 parse/normalize/semantic merge
3. **Capability 收敛**：让 registry/coverage 真参与校验
4. **Apply 执行闭环**：接 storage / snapshot / journal / daemon command
5. **Transport runtime**：补 session read/write/timeout/reconnect

---

## 14. 一句话原则

> Caly 的路线图不应再围绕外围接口数量扩张，而应围绕中心主链是否继续闭合来排序。