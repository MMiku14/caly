# Caly API DTO Migration Plan

本文件专门描述 `crates/caly-api/src/operation.rs` 的瘦身路径，以及 `dto/*` 分面迁移的完成标准。

它不是样式建议，而是**源码契约收敛计划**。

---

## 1. 为什么这件事现在必须做

当前 `caly-api` 已经进入一个典型的中途状态：

- `dto/*` 分面模块已经建立
- 但 `operation.rs` 仍保留大量 DTO 定义
- `lib.rs` / `dto/mod.rs` 的导出面还存在历史兼容痕迹
- 编译虽然已通过，但已有重复 re-export warning

这说明当前问题已从“有没有分面模块”变成了：

> **能否把 API 契约从单个大文件的混合定义，收敛为可维护、可迁移、可验证的分层结构。**

如果不继续推进，会导致：

- Facet 边界名义上存在、代码上仍混杂
- DTO 演进时更容易引发 local/remote/cli 多点漂移
- `operation.rs` 同时承担协议枚举与数据对象，修改面过大

---

## 2. 迁移目标

最终目标应是：

### 2.1 `operation.rs` 只保留

- 协议 envelope
- `Operation` 枚举
- `*Op` 枚举
- `OperationMeta`
- 共享 id/newtype
- `OperationResult`（必要时也可进一步拆）
- `default_ctx(...)` 这类协议入口 helper

### 2.2 `dto/*` 负责承载

- Facet 输入 DTO
- Facet 输出 DTO
- page/query/request/view/report 等对象

### 2.3 `facets.rs` 只依赖稳定导出面

也就是说，Facet trait 不应再“无意中”绑定到 `operation.rs` 内部细节。

---

## 3. 当前已知的中途问题

基于当前 workspace，可明确观察到：

### 3.1 `lib.rs` 已停止直接 `pub use dto::*`

这一步已经帮助消除了致命命名歧义，说明迁移已开始收口。

### 3.2 `dto/mod.rs` 内仍存在重复 re-export warning

当前典型重叠包括：

- `profile::*` 与 `source::*`
  - `SourceSummary`
  - `SourceInspection`
  - `SourcePreviewRequest`
  - `SourcePreview`
- `proxy::*` 与 `runtime::*`
  - `NodeQuery`
  - `NodeView`
  - `NodePage`
  - `GroupView`
  - `DelayTestRequest`

这意味着部分 dto 文件仍在“复出”旧定义，而不是只在所属 facet 模块定义一次。

### 3.3 `operation.rs` 仍然过大

它当前仍混合承载：

- operation meta
- request/response envelope
- operation enum
- result enum
- system/profile/source/proxy/routing/dns/network/core/runtime/diagnostics/automation 的大量 DTO

这会让任何一类 DTO 改动都牵连协议总线文件。

---

## 4. 推荐的目标目录语义

建议继续保持当前分面方向，但语义再收紧：

```text
caly-api/src/
  error.rs           错误模型
  facets.rs          facade trait 集合
  operation.rs       envelope/op meta/op enum/result enum/id/newtype
  dto/
    common.rs        Accepted / WatchOpened / PageRequest / shared small DTO
    system.rs        SystemStatus / ServerInfo / ProtocolVersion
    profile.rs       ApplyRequest / RollbackRequest / DeploymentPlanView / Profile*
    source.rs        Source*
    proxy.rs         Node* / GroupView / SelectNode / DelayTestRequest
    diagnostics.rs   Doctor* / PipelineExplain* / Capability* / JobFollow*
    network.rs       DnsStatus / NetworkStatus / NetworkPlanView / CoreInstallView / CoreInspection
    runtime.rs       RuntimeStatus / Connection* / RuntimeSubscription
    stream.rs        streaming-related view-only DTO if later needed
```

关键点：

- **每个 DTO 只定义一次**
- 非所属 facet 模块禁止再 re-export 同名 DTO
- `dto/mod.rs` 只 re-export“权威定义文件”里的类型

---

## 5. 迁移原则

### 5.1 先收口，再拆大

不要先把 `OperationResult` 再拆成很多层，而应先把重复 DTO 收干净。

### 5.2 一次只迁一组 facet

推荐顺序：

1. system/profile/source
2. proxy/runtime
3. diagnostics/network/core
4. automation/stream/common 收尾

### 5.3 Facet trait 与 local/remote facade 同步调整

每次 DTO 迁移时，必须同步检查：

- `caly-api::facets`
- `caly-daemon::local_facade`
- `caly-app::remote_facade`
- `caly-app::parity`
- `caly-app::contract`
- `caly-cli::*`

否则最容易出现“类型搬了，但 façade/CLI 还在引用旧出口”的半迁移状态。

### 5.4 优先维持导出稳定

对外优先保持：

- `caly_api::ApplyRequest`
- `caly_api::ProfileView`
- `caly_api::JobFollowView`

这类稳定名称不变。

变化应该发生在**内部定义位置**，而不是对外 API 名称上。

---

## 6. 推荐的分阶段实施方案

### Phase A — 消除重复定义

目标：让每个 DTO 在一个权威文件中定义。

动作：

- 从 `profile.rs` 删掉 source 相关 DTO
- 从 `runtime.rs` 删掉 proxy 相关 DTO
- `dto/mod.rs` 只 re-export权威定义

完成定义：

- `cargo check --workspace` 不再出现 ambiguous dto re-export warning

### Phase B — 从 `operation.rs` 迁出 DTO 实体

目标：让 `operation.rs` 只保留协议总线定义。

动作：

- 把 system/profile/source/proxy/runtime/diagnostics/network/core 相关 DTO 迁移到 `dto/*`
- `operation.rs` 改为引用这些 DTO
- `OperationResult` 仍可暂时保留在 `operation.rs`

完成定义：

- `operation.rs` 明显缩小
- DTO 新增/修改时无需大面积编辑 `operation.rs`

### Phase C — 收敛对外 re-export 面

目标：让 `lib.rs` / `dto/mod.rs` / `operation.rs` 的导出层次明确。

动作：

- `lib.rs` 继续只 `pub use operation::*`、`error::*`、`facets::*`
- 仅在 `operation.rs` 内 re-export 被外部需要直接访问的 DTO，或直接 `use crate::dto::*` 引用
- 评估是否保留 `dto/mod.rs` 的全量 `pub use *`

完成定义：

- 导出路径稳定
- 不再依赖“多个模块恰好都导出同名项”维持兼容

### Phase D — 评估 `OperationResult` 是否继续拆分

目标：只在前面完成后，再判断是否要进一步细化结果层。

可选方向：

- 继续保留统一 `OperationResult`
- 或引入按 facet 的 result payload enum，再由 `OperationResult` 组合

当前不建议抢跑这一阶段。

---

## 7. 迁移时必须守住的约束

### 7.1 不改变 Query / Command / Stream 语义

DTO 迁移是结构收敛，不是协议语义重写。

### 7.2 不让 CLI/TUI 持有 daemon 内部类型

所有外部层继续只依赖 `caly-api`。

### 7.3 不让 `dto/*` 反向依赖 daemon/app/engine

`caly-api` 仍必须保持纯契约定位。

### 7.4 不因为迁移而引入“大统一 DTO 文件”回退

分面拆分的目标就是避免重新回到单一巨型文件。

---

## 8. 建议的检查清单

每迁移一批 DTO，都应检查：

1. `cargo check --workspace`
2. `facets.rs` 是否只引用稳定导出面
3. `local_facade.rs` / `remote_facade.rs` 是否仍可编译
4. parity / contract / scenario 是否仍可编译
5. CLI follow / driver / contract_driver 是否仍可编译
6. `docs/IMPLEMENTATION_STATUS.md` 与 `docs/ROADMAP.md` 是否需要同步更新

---

## 9. 当前最优先的具体动作

如果下一轮直接动代码，优先顺序建议是：

1. 清掉 `dto/mod.rs` 的重复导出 warning
2. 明确 `profile.rs`、`source.rs`、`proxy.rs`、`runtime.rs` 的权威归属
3. 把 `operation.rs` 中已在 `dto/*` 存在的定义真正删除
4. 让 `facets.rs` 与 façade 层只通过最终导出面引用这些 DTO

---

## 10. 完成定义

只有满足以下条件，才能说 DTO 迁移完成：

1. `operation.rs` 只保留协议总线定义与必要共享类型
2. 每个 DTO 只有一个权威定义位置
3. `dto/mod.rs` 不再有重复导出 warning
4. local/remote façade、contract、scenario、CLI 均使用统一稳定导出面
5. 新增某个 facet DTO 时，不需要再去修改一整个巨型 `operation.rs`

---

## 11. 一句话结论

> `caly-api` 下一步最重要的不是再扩 operation 数量，而是把 DTO 从 `operation.rs` 里真正迁出来，让 API 契约边界收敛为“总线定义”和“分面数据”两层。