# Caly IPC Loopback Harness Model

本文件说明为什么在真正接入 OS 级 UDS / Named Pipe 之前，Caly 应先拥有一个 **client-session ↔ daemon-transport ↔ daemon-app** 的 loopback harness。

---

## 1. 目标

Loopback harness 解决的问题不是“替代真实 IPC”，而是：

- 在无真实 transport runtime 的情况下提前验证协议时序
- 快速调试 hello / request / stream / ack / close
- 为 deterministic simulation 和协议回归测试提供稳定入口

---

## 2. 推荐结构

```text
ClientSession
   -> ClientFrame
   -> DaemonTransport
   -> DaemonSession / SessionLoop
   -> DaemonApp
   -> ServerFrame
   -> ClientSession observe
```

这条路径的价值在于：

- 它同时覆盖 client 与 server 视角
- 它不依赖真实 socket/pipe 即可验证大量协议语义
- 它适合做 job follow / watch replay / ack 策略测试

---

## 3. 当前 skeleton 已具备的能力

当前骨架已开始具备：

- handshake roundtrip
- request roundtrip
- runtime stream open
- job follow stream open
- stream pull
- stream ack
- hello timeout 模拟
- client snapshot / transport inspect

这说明 loopback harness 已开始成为 IPC 测试的合理落脚点。

---

## 4. 为什么它比直接上真实 transport 更适合当前阶段

因为当前最重要的是验证：

- session 状态机是否正确
- request -> command -> response 是否对齐
- stream policy / ack / resume 是否一致
- job follow 的 retained/reset 语义是否合理

而不是先陷入：

- OS socket 细节
- named pipe 细节
- runtime async loop 细节

---

## 5. 后续可以如何演进

1. 为 loopback harness 增加 scripted scenario
2. 接入 `caly-io-sim` 的 step-aware fault model
3. 扩展到 CLI follow / RemoteApi 骨架测试
4. 与真实 transport loop 做 contract parity 测试

---

## 6. 一句话结论

> 在 Caly 当前阶段，loopback harness 是把协议语义从文档推到可验证代码的重要桥梁。