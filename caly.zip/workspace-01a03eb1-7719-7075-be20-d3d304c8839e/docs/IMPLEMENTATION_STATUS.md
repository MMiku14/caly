# Caly Implementation Status

本文件用于跟踪 Caly 从“架构冻结”走向“可编译、可验证、可演进控制平面”的当前实现状态。

**重要说明**：

> 本状态表反映当前 workspace 内可见的真实工程推进情况。它不是发布说明，而是工程盘点、差距列表与下一阶段排序表。

与之前相比，当前阶段已经发生了一个关键变化：

- Rust toolchain 已安装
- workspace 已能执行 `cargo check --workspace`
- 中心主链已不再只是名义上的 skeleton，而开始产出更真实的 IR / resolved profile / native artifact / apply plan / effect plan

因此，当前项目状态应被理解为：

- 文档体系：已冻结第一版
- 代码体系：已进入**可编译骨架 + 中心主链 partial vertical slice**阶段
- 运行体系：仍未进入真实 core / OS side effect / transport runtime 完成阶段

---

## 1. 状态标签

| 状态 | 含义 |
|---|---|
| `Documented` | 规范已写出，但尚未进入代码骨架 |
| `Planned` | 已列入实施顺序，但未开始 |
| `Skeleton` | 目录/接口骨架已建立，但实质逻辑很弱 |
| `In Progress` | 已开始实现，且正在替换 placeholder |
| `Partial` | 已具备部分可验证行为或纵向切片 |
| `Done` | 已达到当前阶段的完成定义 |
| `Blocked` | 因上游契约、平台或外部依赖受阻 |

---

## 2. 当前总体快照

| 维度 | 当前状态 | 说明 |
|---|---|---|
| 架构总纲 RFC | `Done` | RFC-0001 已形成 |
| 子系统 RFC | `Done` | RFC-0002 ~ RFC-0010 已形成第一版 |
| 核心 ADR | `Done` | ADR-011 ~ ADR-034 已落地 |
| 术语/风格文档 | `Done` | `GLOSSARY.md` / `STYLEGUIDE.md` 已形成 |
| Cargo workspace | `Partial` | workspace 已建立，且 `cargo check --workspace` 已通过 |
| 源码级契约 | `Partial` | `caly-api` / `caly-plan` / `caly-ipc` / `caly-io` 等接口层已可编译 |
| IO 仿真层 | `Partial` | `caly-io-sim` 已有 SimWorld / FaultInjector / Port impl 且已通过编译检查 |
| 共享上下文模型 | `Partial` | `TraceId` / `Actor` / `RequestContext` / `IoBudget` 已在 API/IO/engine/daemon 间贯通 |
| 通信协议分析 | `Done` | framed JSON over UDS / Named Pipe 路线已文档冻结并下沉代码 |
| App client layer | `Partial` | local/remote facade、loopback transport、contract/parity/scenario 已可编译 |
| Domain / IR / Core | `Partial` | 已从纯类型骨架推进到 centerline vertical slice |
| Pipeline / Apply 主链 | `In Progress` | merge/resolve/validate/compile/apply 已形成更真实投影 |
| RuntimeDriver | `Skeleton` | trait 与 mock/runtime slice 已有，但未接真实 runtime API |
| CLI | `Partial` | follow/driver/contract_driver 已可编译，功能仍偏演示与 contract 驱动 |
| 真实部署与回滚 | `Skeleton` | effect plan 已建模，但 executor / journal / rollback 仍未实接 |

---

## 3. 编译与检查状态

### 3.1 当前结果

当前 workspace 已可执行：

```bash
cargo check --workspace
```

结果：**通过**。

这意味着至少以下事实已成立：

1. workspace 依赖关系已收敛到可编译状态
2. `caly-engine` / `caly-daemon` / `caly-app` / `caly-cli` 的主干装配没有继续停留在断裂状态
3. centerline 推进可以开始基于真实编译反馈，而不是只靠静态阅读

### 3.2 当前仍存在的编译告警

目前仍存在若干 warning，主要属于：

- DTO 模块间重复 re-export
- unused import / unused variable
- 若干旧 skeleton 路径尚未被真实调用

这些告警**不阻塞编译**，但表明：

- `caly-api::operation.rs` 的瘦身还未完成
- DTO 分面迁移仍处于中途状态
- 一些旧 skeleton 入口需要继续清理或收敛

---

## 4. RFC 实施状态矩阵

| RFC | 标题 | 状态 | 当前落地情况 |
|---|---|---|---|
| RFC-0001 | Core Architecture | `Partial` | workspace、依赖方向、engine/daemon/app/domain/core 主骨架已成型 |
| RFC-0002 | API / Facade / IPC | `Partial` | `caly-api` / `caly-ipc` / local/remote facade / loopback contract 已可编译 |
| RFC-0003 | Pipeline / Provenance | `In Progress` | merge / resolve / validate / compile / flow 已从空骨架推进到 partial vertical slice |
| RFC-0004 | Capability / Coverage | `Skeleton` | `caly-cap` schema/loader/validator 已有，但尚未深度驱动 pipeline |
| RFC-0005 | Deployment / Recovery | `In Progress` | `ApplyPlan` / `EffectPlan` 已进入 richer projection，executor/journal 尚未打通 |
| RFC-0006 | IO Port / IoFault | `Partial` | `caly-io` + `caly-io-sim` 已可编译且 fault injection 已可用 |
| RFC-0007 | Storage / CAS / Snapshot | `Skeleton` | store trait 与 in-memory backend 已有，尚未接入 apply 主链 |
| RFC-0008 | RuntimeDriver / Telemetry | `Skeleton` | trait / mock/runtime skeleton 已存在，真实 runtime API 未接 |
| RFC-0009 | Profile Patch / Override | `In Progress` | override selectors、selection memory replay、merge/resolve 已开始消费 |
| RFC-0010 | Security / Secret / Redaction | `Documented` | 边界已文档化，代码层尚未系统推进 |

---

## 5. 按 crate 分组的真实推进状态

### 5.1 基础层

| 模块 | 状态 | 当前情况 |
|---|---|---|
| `caly-arch-test` | `Skeleton` | allow-list 已扩展，但自动依赖检查仍待深化 |
| `caly-common` | `Partial` | 共享上下文模型已被多个 crate 实际使用 |
| `caly-io` | `Partial` | Port / Fault / VPath 契约稳定 |
| `caly-io-sim` | `Partial` | SimWorld、FaultInjector、scenario builder、port impl 已可编译 |
| `caly-ir` | `In Progress` | `CompiledArtifact` 已开始承载 native bytes / media type / annotations |
| `caly-domain` | `In Progress` | `Profile` / `OverrideRule` / `SelectionMemory` 与 builder helper 已服务 pipeline |

### 5.2 控制平面核心

| 模块 | 状态 | 当前情况 |
|---|---|---|
| `caly-pipeline` | `In Progress` | merge / resolve / semantic validate / capability validate / compile / flow 已形成 partial vertical slice |
| `caly-cap` | `Skeleton` | registry schema 在，但还未成为 capability validation 的唯一事实源 |
| `caly-plan` | `Partial` | `ApplyPlan` / `EffectPlan` 已被 adapter 和 engine::apply 实际投影使用 |
| `caly-storage` | `Skeleton` | CAS / snapshot / journal / revision 已建模，尚未接入 apply 执行闭环 |
| `caly-engine` | `In Progress` | queue/job/idempotency/event 已成型，`engine::apply` 已输出 richer workflow summary |
| `caly-daemon` | `In Progress` | query/stream/session/runtime/local facade 已接入更多 centerline 查询结果 |

### 5.3 Core 适配层

| 模块 | 状态 | 当前情况 |
|---|---|---|
| `caly-core` | `In Progress` | CoreAdapter / RuntimeDriver / mock adapter 已开始承载 native artifact helper |
| `caly-mihomo` | `Partial` | YAML-shaped artifact、native validation、apply planning、vertical slice 已形成 |
| `caly-singbox` | `Partial` | JSON-shaped artifact、native validation、apply planning、vertical slice 已形成 |

### 5.4 对外接口层

| 模块 | 状态 | 当前情况 |
|---|---|---|
| `caly-api` | `Partial` | Facet/DTO/Operation 可编译，但 `operation.rs` 仍偏大，DTO 迁移未完成 |
| `caly-ipc` | `Partial` | frame/session/stream/client primitive 可编译，真实 transport runtime 未完成 |
| `caly-app` | `Partial` | local/remote facade、loopback transport、parity/contract/scenario 已编译打通 |
| `caly-cli` | `Partial` | driver/follow/contract_driver 已编译通过，仍偏 contract/demo 使用 |
| `caly-tui` | `Planned` | 尚未进入代码阶段 |

---

## 6. 当前中心主链的真实进度

当前已能明确描述这条线：

```text
Profile / Source / Override
  -> Caly IR
  -> ResolvedProfile
  -> Capability Validation
  -> CoreAdapter
  -> NativeValidation
  -> ApplyPlan / EffectPlan
  -> Daemon Query
  -> Local / Remote Facade
```

### 6.1 已经落实的能力

- `Profile.source_refs` 与 `NormalizedSource` 可被 merge 阶段共同消费
- `OverrideRule` 已开始支持若干中心字段 selector
- merge 阶段不再默认产空图，而会物化：
  - nodes
  - groups
  - rules
  - rulesets
  - outbounds
  - dns / tun / inbound
- resolve 阶段开始承担：
  - `SelectionMemory` replay
  - group default recovery
  - reference integrity check
  - deterministic manifest / digest / revision 生成
- adapter 编译结果已开始承载真实 native artifact bytes
- adapter apply planning 已开始区分：
  - `Noop`
  - `ApiPatch`
  - `HotReload`
  - `Restart`
  - `RebuildAndRestart`
- `engine::apply` 已汇总：
  - resolved summary
  - compile summary
  - native validation
  - effect steps
  - compensation steps
- daemon query path 已接入：
  - `ProfileOp::Plan`
  - `DiagnosticsOp::ExplainPipeline`
- local/remote facade parity 已开始覆盖：
  - `system.status`
  - `system.info`
  - `runtime.status`
  - `profile.plan`
  - `diagnostics.explain_pipeline`

### 6.2 仍未完成的部分

- 真实 source parse / decode / normalize
- capability registry 对 profile feature 的系统性驱动校验
- apply executor / storage snapshot / journal 实接
- daemon command path 驱动真实 apply 执行
- real core integration

---

## 7. 当前已完成的高价值文档冻结资产

以下资产已形成并可继续作为实现依据：

- 总体架构边界
- API / Facade / IPC 语义
- Pipeline / Provenance 模型
- Capability / Coverage 模型
- Deployment / Recovery 模型
- IO Port / IoFault 语义
- Storage / CAS / Snapshot 语义
- RuntimeDriver / Telemetry 语义
- Patch / Override 语义
- Security / Secret / Redaction 边界
- IPC transport decision / session model / job follow / stream policy / implementation plan
- app client layer / local-remote parity / overload-retry / loopback contracts / scenario suite

---

## 8. 关键阻塞项（已更新）

相比之前，**“无法执行 cargo check” 已不再是阻塞项**。

当前真实阻塞项改为：

1. `operation.rs` 仍过大，DTO 迁移未完成
2. `caly-api::dto/*` 仍有重复导出与结构收敛问题
3. pipeline 仍未接真实 source parse / normalize
4. capability validation 仍部分依赖 slice 规则而非 registry 驱动
5. `caly-storage` 未接入 apply workflow
6. `caly-engine` 尚无真实 effect executor
7. `caly-daemon` command path 尚未驱动真实 apply 执行
8. `caly-ipc` 仍缺真实双工 transport runtime 与调度器
9. `caly-mihomo` / `caly-singbox` 仍未接真实 binary/runtime API
10. security / secret / redaction 尚未系统进入实现层

---

## 9. 建议的下一实现阶段

### Phase 2.5 — 契约收敛与警告清理

目标：

- 继续瘦 `operation.rs`
- 解除 DTO 双定义与重复 re-export
- 清理编译 warning
- 把 API 语义层进一步稳固

### Phase 3.5 — 中心主链深化

目标：

- 让 pipeline 处理更真实的 source 内容
- 让 capability validation 从“slice 规则”过渡到“registry 驱动”
- 让 `CompiledArtifact` / `EffectPlan` 更贴近真实部署事务

### Phase 4.5 — 执行闭环接线

目标：

- `daemon command -> engine apply -> storage/journal/snapshot`
- 形成真正的 apply vertical slice

---

## 10. 维护规则

更新此状态表时，应遵循：

- 只有文档落地 -> `Documented`
- 只有目录和空文件 -> `Skeleton`
- 有可编译的部分逻辑或 partial slice -> `Partial`
- 有持续替换 placeholder 的中心逻辑 -> `In Progress`
- 满足 RFC 当前阶段完成定义且有验证支撑 -> `Done`

不要把“代码变多了”误标为 `Done`。

---

## 11. 一句话原则

> Caly 现在已经跨过“只会写文档和空骨架”的阶段，下一步的关键是继续把中心主链压实为真正可执行的 apply vertical slice。