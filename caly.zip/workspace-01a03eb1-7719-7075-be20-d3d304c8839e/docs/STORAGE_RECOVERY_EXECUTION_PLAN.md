# Caly Storage and Recovery Execution Plan

本文件专门描述 `caly-storage`、`apply execution` 与 `daemon recovery` 三者之间应该如何接线。

它关注的是中心主链里最容易被拖延、但又最关键的一截：

```text
EffectPlan
  -> Journal Pending
  -> Runtime Cutover
  -> Snapshot Commit
  -> Crash Recovery
  -> Last Known Good
```

---

## 1. 为什么需要单独计划

虽然 RFC-0005 与 RFC-0007 已冻结：

- Apply / Rollback / Recovery
- Snapshot / Journal / CAS / Revision

但当前代码层仍主要停留在：

- plan 对象存在
- storage trait 存在
- snapshot / journal 类型存在

真正缺少的是：

> 如何把 storage 变成 apply execution 的事务底座，而不是与中心主链平行漂浮的一组类型。

---

## 2. 当前已有的工程承载位

### 2.1 `caly-storage`

当前已有：

- `ObjectStore`
- `RevisionStore`
- `SnapshotStore`
- `JournalStore`
- `InMemoryStorage`
- CAS / revision / snapshot / journal 基础对象

### 2.2 `caly-plan`

当前已有：

- `EffectPlan`
- `EffectStep`
- `MarkSnapshot`
- `CommitRevision`
- `NetApply`
- `NetRevert`
- `SpawnCore`
- `StopCore`

### 2.3 `caly-engine::apply`

当前已有：

- apply workflow summary
- effect step projection
- compensation step projection

### 2.4 `caly-daemon`

当前已有：

- daemon 是唯一状态所有者
- request -> command 边界
- job follow / event stream 基础模型

---

## 3. 当前最关键的缺口

### 3.1 缺 pending journal 生命周期

当前还没有真正的：

- begin journal pending
- update step cursor
- mark committed / reverted / abandoned

### 3.2 缺 snapshot 提交边界

当前还没有真正区分：

- compiled but not committed
- cutover in progress
- verified succeeded
- snapshot committed as last-known-good

### 3.3 缺 recovery scanner

当前 daemon 启动时还没有一个明确的：

- scan pending journal
- inspect runtime leftovers
- choose rollback / takeover / cleanup
- emit recovery diagnostics

### 3.4 缺 storage-backed apply event proof

当前 job follow 还主要围绕内存态 skeleton。
后续必须让部分 apply/recovery 关键节点有持久证据可读。

---

## 4. 建议的最小事务对象

### 4.1 `ApplyJournalRecord`

建议至少包含：

- `journal_id`
- `apply_txn_id`
- `trace_id`
- `job_id`
- `profile_id`
- `revision_id`
- `semantic_digest`
- `compiled_artifact_digest`
- `core_identity`
- `effect_plan_id`
- `current_phase`
- `current_step_index`
- `net_effect_started`
- `core_cutover_started`
- `previous_snapshot_id`
- `created_at`
- `updated_at`
- `state: pending | committed | reverted | abandoned | recovery_failed`

### 4.2 `SnapshotCandidate`

建议在正式 commit 前先有临时投影：

- revision id
- semantic digest
- compiled artifact digest
- core binary digest
- validation summary
- selection memory digest
- effect plan summary

### 4.3 `RecoveryDecision`

建议至少表达：

- `TakeoverRunningInstance`
- `RollbackToLastKnownGood`
- `RevertOsEffectsOnly`
- `CleanupAbandonedRuntime`
- `EnterFailedState`

---

## 5. 执行与存储的正确接线顺序

### 5.1 Prepare 阶段

目标：

- 不动 active runtime
- 只做可重复准备动作

建议顺序：

1. 写 compiled artifact 到 object store
2. 物化 runtime candidate 文件
3. 创建 `ApplyJournalRecord(state=pending)`
4. 写入 effect plan cursor=0

此阶段失败要求：

- 当前 active snapshot 不变
- pending journal 可删除或标记 abandoned

### 5.2 Cutover 阶段

目标：

- 执行真正影响 runtime / OS 的动作

建议顺序：

1. 标记 `core_cutover_started=true`
2. 若需要，记录 `net_effect_started=true`
3. 执行 `StopCore` / `SpawnCore` / `Reload` / `NetApply`
4. 每完成一步都更新 step cursor

此阶段要求：

- journal 必须始终领先或同步于不可逆副作用
- recovery scanner 必须能仅靠 journal 决定下一步

### 5.3 Verify / Finalize 阶段

目标：

- 只在验证成功后提交新真相

建议顺序：

1. 运行 probe
2. 生成 `SnapshotCandidate`
3. 写 snapshot record
4. 更新 last-known-good marker
5. commit revision
6. 标记 journal=committed

此阶段失败要求：

- 不得留下“已经新 snapshot commit，但 runtime 未验证”的状态

---

## 6. crash recovery 的最小算法

### 6.1 启动入口

daemon 启动时第一件事不是接受新 apply，而是：

1. 扫描 pending journal
2. 扫描 runtime 目录残留
3. 扫描上一个 active snapshot / last-known-good snapshot

### 6.2 决策规则

#### 情况 A：只有 prepare 完成，cutover 未开始

处理：

- 清理 runtime candidate
- journal -> abandoned
- 保持旧 active snapshot

#### 情况 B：cutover 已开始，但 verify 未完成

处理：

- 优先 rollback 到 last-known-good
- 无法 rollback 则至少 revert OS side effects
- 标记 recovery result

#### 情况 C：新 runtime 看似在跑，但 snapshot 未提交

处理：

- 通过 config identity / instance identity 判断是否可接管
- 若不能证明一致，则回滚或进入 failed state

#### 情况 D：journal 显示已 committed，但 runtime 目录部分损坏

处理：

- 基于 snapshot + object store 重建 runtime materialization
- 不依赖 runtime 目录作为最终真相来源

---

## 7. last-known-good 的维护纪律

last-known-good 必须满足：

1. 只有 verify 成功的 snapshot 才能升级为 LKG
2. 新部署成功前，旧 LKG 不得移除
3. GC 不得删除任何被 LKG 引用的对象
4. recovery 优先回到 LKG，而不是回到“最近一次尝试”

这条纪律是 Caly “失败不污染运行态” 的核心承诺之一。

---

## 8. 与 CAS / GC 的关系

### 8.1 apply 执行时的 root 集

在 apply 执行期间，以下对象必须被视为 GC root：

- 当前 active snapshot 引用对象
- pending journal 引用对象
- 新 compiled artifact
- runtime candidate materialization source
- previous snapshot / LKG 引用对象

### 8.2 完成后 root 切换

只有在：

- snapshot committed
- journal committed or archived
- recovery not needed

之后，旧对象才可在未来 GC 周期中根据可达性决定是否删除。

---

## 9. job follow / doctor / support bundle 的持久化视角

一旦 storage/recovery 接线，以下对外能力就能显著提升：

### 9.1 job follow

可以观察：

- journal pending
- current step cursor
- probe passed/failed
- snapshot committed
- recovery started/succeeded/failed

### 9.2 doctor

可以诊断：

- dangling pending journal
- abandoned runtime directory
- no valid last-known-good
- snapshot/object mismatch

### 9.3 support bundle

可以导出：

- recent apply journal summaries
- active snapshot metadata
- last-known-good metadata
- recovery incident summary

---

## 10. 推荐的三阶段实施顺序

### Stage 1 — Projection First

交付物：

- `EffectPlan -> ApplyJournalRecord` projection helper
- `ApplyWorkflowResult -> SnapshotCandidate` projection helper
- journal step cursor model

完成定义：

- 虽然 executor 还没落地，但 storage 写入对象已可被结构化描述

### Stage 2 — InMemory Recovery Skeleton

交付物：

- 基于 `InMemoryStorage` 的 pending journal begin/update/commit/revert
- daemon boot recovery scan skeleton
- recovery decision enum

完成定义：

- recovery path 已从文档概念进入可编译代码骨架

### Stage 3 — Executor Integration

交付物：

- effect executor 每步推进 journal cursor
- probe 成功后写 snapshot
- 失败时写 recovery outcome

完成定义：

- apply command path 可产出持久化事务痕迹

---

## 11. 当前阶段完成定义

只有满足以下条件，才能说 storage/recovery 不再是漂浮层：

1. apply 执行前会创建 pending journal
2. effect steps 执行过程中会推进 journal cursor
3. verify 成功后才会 commit snapshot / revision
4. daemon 启动时能扫描 pending journal 并做恢复决策
5. last-known-good 真正参与 rollback / recovery

---

## 12. 一句话结论

> `caly-storage` 下一步最重要的不是再补更多静态类型，而是成为 `apply execution -> snapshot/journal -> crash recovery` 这条中心执行链的真实事务底座。