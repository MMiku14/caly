# Caly Apply Execution Centerline

本文件专门定义 Caly 从 `Profile / Source / Override` 走到 `ApplyPlan / EffectPlan / 执行与恢复` 的中心执行主链。

它的目的不是重复 RFC-0005，而是把当前代码状态、后续实施顺序、执行边界与完成定义收敛成一份**工程推进基线**。

---

## 1. 本文关注的主链

```text
Profile / Source / Override
  -> Caly IR
  -> ResolvedProfile
  -> Capability Validation
  -> CoreAdapter
  -> NativeValidation
  -> ApplyPlan
  -> EffectPlan
  -> Effect Executor
  -> Snapshot / Journal
  -> Runtime Cutover / Recovery
```

这条链是 Caly 的真正中心。

如果这条链没有闭合，那么：

- IPC 再完整也只是外壳
- CLI/TUI 再多也只是表面
- watcher / contract / scenario 再丰富也只是围绕空心骨架转

---

## 2. 当前已经达到的位置

基于当前 workspace，已经具备：

### 2.1 输入侧

- `caly-domain::Profile`
- `caly-domain::OverrideRule`
- `caly-domain::SelectionMemory`
- `caly-pipeline::PipelineRequest`

### 2.2 中间表示

- `caly-pipeline::merge_profile(...)`
  - 已开始消费 profile source refs
  - 已开始消费 normalized source estimates
  - 已开始消费部分 override selector
  - 已开始物化 nodes / groups / rules / rulesets / outbounds / dns / tun
- `caly-pipeline::resolve_ir(...)`
  - 已开始 replay `SelectionMemory`
  - 已开始 default selection recovery
  - 已开始 reference integrity check
  - 已生成 deterministic manifest / semantic digest / revision
- `caly-pipeline::validate_semantic(...)`
- `caly-pipeline::validate_capabilities(...)`

### 2.3 core 侧

- `caly-core::CoreAdapter`
- `caly-core::MockCoreAdapter`
- `caly-mihomo::MihomoAdapter`
- `caly-singbox::SingBoxAdapter`

### 2.4 编译结果与部署计划侧

- `caly_ir::CompiledArtifact`
  - `format`
  - `entrypoint`
  - `media_type`
  - `bytes`
  - `annotations`
- `caly_plan::ApplyPlan`
- `caly_plan::EffectPlan`
- `caly-engine::apply`
  - `plan_apply_request(...)`
  - `deployment_plan_view(...)`
  - `explain_pipeline(...)`

### 2.5 门面接入侧

- daemon query 已接入：
  - `ProfileOp::Plan`
  - `DiagnosticsOp::ExplainPipeline`
- local/remote facade parity 已开始比较这些结果

---

## 3. 当前真正缺的不是“更多 plan”，而是“执行闭环”

当前最关键的差口在于：

```text
ApplyPlan / EffectPlan
  -> Effect Executor
  -> Storage Snapshot / Journal
  -> Runtime Cutover
  -> Rollback / Recovery
```

也就是说，当前系统已经会：

- 解释
- 编译
- 校验
- 规划

但还没有真正稳定地：

- 执行副作用
- 记录事务状态
- 在失败后恢复到 last-known-good

---

## 4. 执行主链中的职责切分

### 4.1 `caly-domain`

负责：

- Profile/Override/SelectionMemory 的领域表达

不负责：

- native config 细节
- effect 执行
- rollback 执行

### 4.2 `caly-pipeline`

负责：

- 输入合并
- resolve
- semantic validation
- capability validation
- adapter compile orchestration

不负责：

- spawn core
- 写 runtime 文件
- OS 网络副作用
- snapshot/journal 提交

### 4.3 `caly-core` / `caly-mihomo` / `caly-singbox`

负责：

- core identity
- capability set
- native compile
- native validation
- apply planning differences

不负责：

- 直接拥有系统状态
- 自行做最终存储提交
- 跨 core 的全局协调

### 4.4 `caly-plan`

负责：

- 表达 `ApplyPlan` 与 `EffectPlan`
- 表达副作用步骤与补偿步骤

不负责：

- 真实执行这些步骤

### 4.5 `caly-engine`

负责：

- command / job / event
- apply workflow orchestration
- effect executor 的调度入口
- 事务生命周期事件

应该成为：

> 从“会产出计划”到“会协调执行与记录”的第一所有者。

### 4.6 `caly-storage`

负责：

- object store
- revision store
- snapshot store
- journal store

应该承载：

- pending apply journal
- committed snapshot
- last-known-good marker
- crash recovery input

### 4.7 `caly-daemon`

负责：

- 唯一状态所有者
- request -> command 边界
- apply job 提交与 follow
- recovery on boot

不应：

- 在 façade 层直接拼 effect 执行细节

---

## 5. 目标执行模型

### 5.1 建议的高层状态机

```text
DraftRequest
  -> PipelineResolved
  -> NativeValidated
  -> Planned
  -> JournalPending
  -> EffectsRunning
  -> RuntimeVerified
  -> SnapshotCommitted
  -> Succeeded
```

失败分支：

```text
EffectsRunning
  -> EffectFailed
  -> CompensationRunning
  -> Recovered | RecoveryFailed
```

### 5.2 推荐 typestate 方向

后续实现可考虑：

- `ApplyTxn<Draft>`
- `ApplyTxn<Validated>`
- `ApplyTxn<Planned>`
- `ApplyTxn<Journaled>`
- `ApplyTxn<Committed>`

目的：

- 防止跳过 native validation 就执行 effect
- 防止未 journal 就切 runtime
- 防止未 snapshot 就宣告成功

---

## 6. `EffectPlan` 的执行分层

### 6.1 建议的三段执行模型

#### Phase A — Prepare

只允许执行“可重复、可验证、尚未切换运行态”的步骤：

- `WriteObject`
- `MaterializeArtifact`
- `DbTxn`（prepare/pending）
- pre-spawn verify

要求：

- 此阶段失败不得改变当前 active runtime
- 可以安全重试

#### Phase B — Cutover

真正影响 active runtime / OS state 的关键步骤：

- `StopCore`
- `SpawnCore`
- `CoreApiCall::Reload`
- `CoreApiCall::SelectProxy`
- `NetApply`

要求：

- 必须有 journal pending guard
- 必须定义明确顺序
- 必须允许 crash recovery 识别执行到哪一步

#### Phase C — Finalize

只有在 runtime verify 成功后才能做：

- `Probe`
- `MarkSnapshot`
- `CommitRevision`
- update last-known-good
- clear pending journal

要求：

- Finalize 前不能对外宣告 apply succeeded

---

## 7. Snapshot / Journal 的最小接线方案

这是下一步最该落地的部分。

### 7.1 journal 需要至少记录

- apply transaction id
- request trace id
- target profile id
- semantic digest
- compiled artifact digest
- target core identity
- selected `ApplyPlanKind`
- effect plan id
- effect step cursor
- whether net side effects have happened
- previous last-known-good snapshot

### 7.2 snapshot 需要至少记录

- revision id / revision number
- semantic digest
- compiled artifact digest
- core binary digest
- core identity string
- apply plan summary
- validation summary
- selection memory digest
- created_at
- is_last_known_good

### 7.3 最小恢复策略

daemon 启动时：

1. 读取 pending journal
2. 判断 cutover 是否已开始
3. 若未开始：丢弃 pending，保留现状
4. 若已开始但 verify 未完成：
   - 优先回到 last-known-good snapshot
   - 如无法回滚，标记 `RecoveryFailed`
5. 发出恢复事件供 doctor/support bundle 观察

---

## 8. daemon command path 最终应如何接入

目标链应为：

```text
RequestEnvelope(Profile.Apply)
  -> request_map
  -> CommandKind::ProfileApply
  -> engine submit
  -> worker consume
  -> apply workflow
  -> effect executor
  -> job events / follow / stream
```

当前缺口：

- `submit_request_as_command(...)` 已有
- job/event/follow 已有
- 但 worker 还未真正跑 apply executor

所以正确下一步不是再加一个新的 façade，而是：

> 让已有 command path 真正调起 apply workflow 与 effect execution。

---

## 9. Job follow 对 apply 执行的要求

一旦 apply 真执行，job follow 至少要能表达：

- `pipeline.resolved`
- `capability.validated`
- `native.validated`
- `effects.prepare.started`
- `effects.cutover.started`
- `effects.verify.started`
- `snapshot.committed`
- `recovery.started`
- `recovery.succeeded`
- `recovery.failed`

建议：

- query path 返回聚合视图
- stream path 返回阶段事件
- 两者共用同一内部 job event source，而不是各自生成一套状态

---

## 10. 与 overload/retry 的关系

apply 执行主链必须和 overload/public error 对齐：

### 应公开区分的失败类型

- 用户配置错误
- capability blocked
- native validation rejected
- queue full / overload
- storage busy
- runtime unavailable
- effect execution failed
- recovery failed

### 不应混淆的点

- `Plan` 失败 ≠ `Execute` 失败
- `Validate` 失败 ≠ `RuntimeProbe` 失败
- `QueueFull` ≠ `ProfileInvalid`
- `RecoveryFailed` 必须高于普通 apply failed

---

## 11. 推荐的最近三阶段实施顺序

### Stage 1 — storage projection 接线

交付物：

- apply journal record DTO
- snapshot projection helper
- effect execution cursor model

完成定义：

- effect plan 已可投影为 journal/snapshot input

### Stage 2 — in-memory effect executor

交付物：

- 基于 `InMemoryStorage` 的 executor skeleton
- prepare/cutover/finalize 三阶段执行器
- job event 发射

完成定义：

- daemon command path 可触发一个 end-to-end 的 mock apply execution

### Stage 3 — recovery loop skeleton

交付物：

- boot recovery path
- pending journal scan
- last-known-good rollback skeleton
- recovery event reporting

完成定义：

- “崩溃后恢复” 已从文档概念进入可编译实现骨架

---

## 12. 本文的完成定义

只有在满足以下条件后，才能说 apply centerline 进入下一阶段：

1. daemon command path 能触发真实 apply workflow
2. effect execution 不再只是字符串投影
3. pending journal 能记录执行中事务
4. snapshot 能标记 last-known-good
5. recovery path 能消费 pending journal
6. job follow 能观察执行与恢复阶段

---

## 13. 一句话结论

> Caly 的下一步不是再写更多“计划对象”，而是把 `ApplyPlan / EffectPlan -> Executor -> Snapshot / Journal -> Recovery` 这半条中心线真正接起来。