# Caly Robustness and Advanced Implementation Guide

本文件不是新的 RFC，而是对现有 RFC/ADR 的工程化补充说明。

目标：

- 帮助实现者把“架构正确”落实为“工程上更不容易出错”
- 总结 Caly 中**鼓励使用的高级技巧**
- 强调哪些技巧服务于健壮性，哪些做法会破坏健壮性

这份文档偏工程实践，不替代 RFC 的正式语义边界。

---

## 1. 健壮性优先级

在 Caly 中，健壮性的优先级高于：

- 快速堆功能
- 表面上更简短的代码
- 为 demo 而牺牲边界

具体表现为：

1. **可恢复** 优先于“跑起来一次”。
2. **可解释** 优先于“凑合能工作”。
3. **可测试** 优先于“先别抽象”。
4. **边界清晰** 优先于“先直接调一下内部对象”。

---

## 2. 推荐使用的高级技巧

以下技巧在 Caly 中是鼓励使用的，但前提是：

- 不破坏 RFC 约束
- 不引入隐式全局状态
- 不牺牲可测试性和可恢复性

### 2.1 Typestate / Phantom Type

适用场景：

- Apply / deploy 生命周期
- Verify 前后状态
- 已校验 / 未校验的配置对象
- 已提交 / 未提交的事务对象

示例用途：

- `ApplyTransaction<Draft>`
- `ApplyTransaction<Validated>`
- `ApplyTransaction<Committed>`

好处：

- 把非法状态转移提前到编译期
- 减少“运行时才发现顺序错了”

---

### 2.2 Newtype Everywhere

适用场景：

- `ProfileId`
- `JobId`
- `StreamId`
- `SnapshotId`
- `TraceId`
- `CapabilityKey`

好处：

- 防止字符串或整数被误用
- API 更自解释
- 迁移时更容易定位影响范围

---

### 2.3 Monotonic Sequence / Generation Counter

适用场景：

- Event 序号
- Stream patch 序号
- Job event 顺序
- Runtime generation / snapshot generation

好处：

- 重连恢复更可靠
- 能显式判断“视图是否已经失效”
- Reset 和 stale 检测更容易实现

注意：

- generation bump 必须在语义边界上发生，而不是到处自增
- sequence 与 timestamp 不能混用，各自用途不同

---

### 2.4 RAII Guard / Drop Cleanup Guard

适用场景：

- 临时工件文件
- Journal pending guard
- Core child process 句柄
- runtime 目录临时占用

好处：

- 避免忘记清理
- 提高错误路径健壮性

注意：

- Drop cleanup 不能替代正式回滚逻辑
- 正式可恢复状态仍必须进入 Journal / Snapshot

---

### 2.5 Arena / Interner / `Arc<str>` / `Bytes`

适用场景：

- 高频重复字符串
- Provenance path 段
- Capability key、字段名、节点标签
- 大量事件广播载荷

好处：

- 降低重复分配
- 降低拷贝成本
- 更适合低资源目标

注意：

- 优化不能破坏稳定序列化顺序
- interner 的 key 顺序不应泄漏进对外工件

---

### 2.6 Bounded Queue + Coalescing

适用场景：

- traffic stream
- logs stream
- runtime patch stream
- TUI event feed
- command queue overflow保护

好处：

- 防止慢客户端拖垮服务端
- 与 Reset 语义配合自然
- 能把资源压力提前转为可解释拒绝

注意：

- 必须显式区分：
  - 无损流
  - 最新值流
  - 可丢弃流
- command queue 的满载拒绝应进入统一错误与事件路径

---

### 2.7 In-Memory Backend for Early Integration

适用场景：

- `InMemoryStorage`
- LocalApi/Engine 集成
- Job/command 路径验证

好处：

- 能在 SQLite/CAS 未完成前先把系统链路接起来
- 更适合快速集成测试

注意：

- in-memory backend 不等于最终恢复语义已完成
- 不能因为有内存后端就跳过 Journal/Snapshot 正式设计

---

### 2.8 Structured Validation Layer

适用场景：

- capability registry loader
- coverage matrix validator
- patch selector validator
- IPC frame validator

好处：

- 把“文档约束”变成“代码约束”
- 更早失败、更可解释

---

### 2.9 Explicit Lock Ordering and State Assembly

适用场景：

- `EngineState`
- daemon runtime state
- queue / job / event 协调路径

好处：

- 降低未来并发实现中的死锁风险
- 让“先更新 job、再发 event”这类顺序固定下来

建议：

- 尽早把共享状态聚合成较少的 owner 对象
- 对跨锁路径制定统一顺序，例如：runtime -> engine -> storage
- 不要在持有锁时调用可能阻塞的 IO

---

### 2.10 Event Log Window and Replay Cursor

适用场景：

- job follow
- watch reconnect
- diagnostics event replay

好处：

- 可精确定义“从哪里继续”
- 更容易支持 `from_seq` / Reset / gap detection

注意：

- replay window 必须有界
- 超出保留范围时应显式 Reset，而不是静默丢事件

---

### 2.11 Command Mapping as a Dedicated Boundary

适用场景：

- daemon request handler
- IPC request -> Command 转换
- 权限与 role 校验入口

好处：

- 把“外部协议对象”与“内部命令对象”显式隔离
- 更容易做审计、拒绝、重试与错误归一化

建议：

- 不要在随机业务函数里直接从 `RequestEnvelope` 拼 `Command`
- request mapping 应视为 daemon 边界层的一部分

---

### 2.12 Watch Bridge as an Explicit Translation Layer

适用场景：

- engine event -> IPC stream frame
- runtime watch -> TUI/CLI stream
- reset / replay / retained window 暴露

好处：

- 把内部事件语义与外部流语义显式分层
- 更容易处理 reset、窗口裁剪和 payload 变换
- 避免 UI 直接理解内部 event 结构

建议：

- watch bridge 应明确声明 retained window 与 reset 条件
- 不要让 engine 内部事件格式直接泄漏到最终外部流协议

---

### 2.13 DTO Migration by Facet Instead of Big-Bang Rewrite

适用场景：

- `operation.rs` 很大时的逐步瘦身
- Facet / DTO 模块化拆分

好处：

- 避免一次性大重写导致接口漂移
- 允许文档、handler、CLI/TUI 逐步跟上
- 更适合在骨架阶段保持稳定推进

建议：

- 先建立 `dto/*` 分面模块
- 再逐批迁移类型定义
- 每迁移一批都同步更新 handler / tests / docs

---

### 2.14 Policy Object over Ad-Hoc Protocol Branching

适用场景：

- IPC frame size
- hello timeout
- stream ack 策略
- queue capacity
- replay retention

好处：

- 把协议行为和资源限制集中管理
- 更容易测试不同策略组合
- 更容易在 debug / strict / release 模式下切换行为

建议：

- 优先把这些限制抽成 `Policy` 对象或常量表
- 避免把协议分支散落在 handler / stream / engine 多处

---

## 3. 强烈不建议的实现方式

### 3.1 直接 shell 拼命令

禁止原因：

- 可移植性差
- 安全边界差
- 错误难归一化

### 3.2 无界 channel / 无界日志缓存

禁止原因：

- 最容易违反低资源目标
- 慢客户端会拖垮整个系统

### 3.3 在 Query 路径里偷偷做重副作用

禁止原因：

- 破坏 Query / Command / Stream 三分模型
- 前端与脚本很难推理行为

### 3.4 在 UI 里直接拼内部逻辑

禁止原因：

- 业务逻辑回流
- LocalApi / RemoteApi 漂移

### 3.5 为了方便跳过 Journal / Snapshot / Verify

禁止原因：

- 会直接破坏 Caly 的恢复主张

### 3.6 在持锁状态下执行长耗时逻辑

禁止原因：

- 会把未来真正的并发与事件流实现拖入脆弱状态
- 最容易形成“偶现卡死”和顺序反转问题

### 3.7 在多个边界重复做 request -> command 映射

禁止原因：

- 容易导致权限、幂等、日志、错误处理分叉
- 会削弱 daemon 边界的可审计性

### 3.8 让外部 Watch 直接依赖内部 Event 结构

禁止原因：

- 内部事件格式会反向锁死外部协议
- reset / replay / payload 演进会变得困难

### 3.9 一次性大迁移全部 DTO 与协议定义

禁止原因：

- 在骨架阶段容易引入过大变动面
- handler / CLI / docs 很难同步验证
- 容易破坏尚未编译验证的结构稳定性

### 3.10 在没有集中 policy 的情况下四处分散写协议限制

禁止原因：

- frame size、ack、compression、queue cap 会逐步失去一致性
- 测试难以覆盖真实组合
- 最终会造成“文档说一种，代码多处分支各自一种”

---

## 4. 健壮性检查清单

在实现任何新模块前，建议先问：

1. 这个对象是否应该是 newtype？
2. 这个阶段是否可以用 typestate 限制非法顺序？
3. 这条路径是否需要 monotonic seq / generation？
4. 是否应该是 bounded queue，而不是 Vec 无限堆？
5. 错误是否已经在边界脱敏？
6. 是否能在仿真环境里注入失败？
7. 是否会把外部类型泄漏到 Domain？
8. 是否会让 Query 偷偷带副作用？
9. 是否在持锁时执行了耗时或阻塞操作？
10. replay / reset / stale 语义是否被显式建模？
11. request -> command 映射是否被集中在边界层？
12. watch / stream 转换是否有独立 bridge 层？
13. DTO 拆分是否按 Facet 渐进推进，而不是一次性重写？
14. 协议限制是否已经集中到 policy 层，而不是散落在多处条件分支？

---

## 5. 当前建议优先落地的“高级技巧”

基于当前工程状态，最值得优先落地的技巧是：

1. `ApplyTransaction` typestate
2. Job / Event monotonic sequence
3. InMemoryStorage + future SQLite backend 双轨
4. `RequestContext` 统一下沉
5. capability registry validator
6. `SimFs` / `SimClock` / `SimProc` 故障注入点
7. engine / daemon 状态装配中的显式锁顺序
8. bounded replay window + Reset 语义
9. daemon `request_map` 作为独立边界层
10. watch bridge 作为 event -> stream 的显式翻译层
11. DTO 按 Facet 渐进迁移
12. 协议/资源限制通过 policy object 收口

---

## 6. 一句话原则

> 高级技巧在 Caly 中不是为了炫技，而是为了把“正确性、恢复性、低资源”这些要求前移到类型系统、结构边界、策略对象和测试骨架里。