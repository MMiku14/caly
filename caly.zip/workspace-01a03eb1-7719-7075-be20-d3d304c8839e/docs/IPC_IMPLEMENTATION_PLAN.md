# Caly IPC Implementation Plan

本文件把当前 IPC 相关的 RFC、ADR 与 skeleton 代码收敛成一份**实现计划**，目标是减少后续实现时的来回摇摆。

---

## 1. 目标

把目前的协议分析和代码骨架推进成：

- 可维护的本地 IPC 栈
- 可恢复的 Job follow / watch 体系
- 可严格校验的 session / frame / request 三层模型
- 可明确桥接的核心协议，而不是被 gRPC/HTTP 倒逼设计

---

## 2. 已经具备的骨架

当前已具备：

- `RequestEnvelope` / `ResponseEnvelope`
- `ClientHello` / `ServerHelloAck`
- `SessionMachine`
- `SessionLoopInput` / `SessionLoopOutput`
- `StreamFrame` / `Ack`
- `StreamPolicy`
- `DaemonSession`
- `watch_bridge`
- Job follow query + stream skeleton
- `idempotency_key` 的外部承载位

这意味着 IPC 最难的结构层已经基本齐了。

---

## 3. 剩余关键工作按顺序排布

### Phase A — Session Runtime Completion

1. 接 transport read/write loop
2. hello timeout 真正进入调度
3. close reason 与 reconnect 规则固定
4. frame kind / frame side 校验继续下沉

### Phase B — Stream Runtime Completion

1. ACK 与 resend/resume 语义
2. stream open 后第一帧规则
3. reset reason 固定
4. dashboard / connections snapshot-first 策略

### Phase C — Job Follow Completion

1. query + stream 行为完全对齐
2. `from_event_index` retained/reset 规则固定
3. CLI follow UX 与 exit code 对齐
4. Job event DTO 细化

### Phase D — RemoteApi/CLI Integration

1. request/session glue
2. follow loop
3. retry/idempotency path
4. JSON 输出与错误映射

---

## 4. 决策约束

实现时必须继续遵守：

- 核心本地协议使用 framed JSON over UDS / Named Pipe
- gRPC/HTTP 仅作为未来 bridge 候选
- stream policy 不得散落在多处 ad-hoc 分支中
- request -> command / event -> stream / job -> follow 三个边界必须保持独立

---

## 5. 一句话结论

> 现在 IPC 最重要的不是再扩 operation 数量，而是把 session、stream、job follow 和 ack/resume 这四条主线做严谨。