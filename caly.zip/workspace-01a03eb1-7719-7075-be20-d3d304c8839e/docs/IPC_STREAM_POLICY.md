# Caly IPC Stream Policy Model

本文件补充说明 Caly IPC 中最容易被低估的一层：**每种 stream 不只是 payload 不同，可靠性、ACK、Reset 和 replay 语义也不同。**

---

## 1. 为什么 stream policy 必须显式化

如果所有流都只抽象成“服务端不断发消息”，会很快出现问题：

- 有的流其实需要无损续传
- 有的流只需要最新值
- 有的流在 gap 后应 Reset
- 有的流根本不值得逐条 ACK

因此，`StreamKind` 之外还必须有 `StreamPolicy`。

---

## 2. 当前建议模型

当前代码骨架中，`StreamPolicy` 至少表达：

- `DeliveryGuarantee`
- `AckPolicy`
- `reset_on_gap`

这三者共同决定：

- 客户端是否要持久维护 seq/cursor
- 服务端是否需要保留 replay window
- slow client 时是 drop / reset / resumable 哪一种

---

## 3. 推荐默认策略

| StreamKind | Delivery | ACK | Gap |
|---|---|---|---|
| Job | LosslessResumable | Required | Resume/Retry |
| Deployment | LosslessResumable | Required | Resume/Retry |
| Dashboard | SnapshotThenPatch | Optional | Reset |
| Traffic | LatestValue | None | Drop middle values |
| Logs | LossyRing | None | Drop old values |
| Connections | SnapshotThenPatch | Optional | Reset |

---

## 4. 与 watch bridge 的关系

watch bridge 不应只做 payload 翻译，还应该知道：

- 当前 stream kind 的 policy
- 当前 seq / retained window
- 是否需要 reset
- 是否允许 ack

否则协议行为会散落到：

- session
- handler
- engine event layer
- UI client

多处条件分支里。

---

## 5. 与 session cursor 的关系

对支持 replay 的流，session 层通常还需要维护：

- `last_emitted_seq`
- `acked_upto`
- reopen / reconnect 时的 preferred resume position

这说明 `StreamPolicy` 不只是“静态说明”，还会影响 session runtime 行为。

---

## 6. 当前 skeleton 已有基础

当前骨架已开始具备：

- `StreamKind`
- `StreamPolicy`
- `AckPolicy`
- `DaemonSession::opened_streams`
- `StreamCursorState`
- `watch_bridge`

这说明 stream 已经不再是“单向打印消息”，而开始接近正式协议对象。

---

## 7. 仍需补齐的关键点

1. ACK 的推进窗口与 resend 语义
2. job stream retained/reset 细则
3. dashboard/connections 的 snapshot first frame 约定
4. slow client 触发 reset 的正式策略

---

## 8. 一句话结论

> Caly 的 stream 不是一个统一广播管道，而是一组带有不同可靠性契约的协议面。