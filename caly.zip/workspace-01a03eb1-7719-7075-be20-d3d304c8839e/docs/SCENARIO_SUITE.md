# Caly Scenario Suite Strategy

本文件说明为什么在 Caly 当前阶段，需要一个围绕 loopback harness、remote client、facade parity 和 centerline plan/explain 组织起来的 scenario suite。

---

## 1. 目标

scenario suite 的目标不是替代真实 integration tests，而是：

- 在骨架阶段提前验证跨层时序
- 把协议和 facade 行为做成可回归的组合场景
- 尽早发现 local/remote 语义漂移
- 尽早发现 centerline 输出在 query / remote / contract 层的裂缝

---

## 2. 当前建议覆盖面

当前至少应覆盖：

1. handshake
2. runtime watch open
3. runtime watch ack path
4. job follow query
5. job follow stream
6. hello timeout
7. wire probe
8. local/remote parity
9. contract bundle
10. plan/explain 相关 parity

---

## 3. 当前代码入口

当前已具备的 scenario / suite 入口包括：

- `run_handshake_scenario()`
- `run_runtime_watch_scenario()`
- `run_job_follow_query_stream_scenario()`
- `run_wire_probe_scenario()`
- `run_timeout_scenario()`
- `run_parity_scenarios()`
- `run_job_follow_contract_scenario()`
- `run_smoke_bundle()`

这意味着 scenario suite 已不再只是文档建议，而是已经有真实代码入口，并且当前 workspace 可通过 `cargo check --workspace` 验证其编译完整性。

---

## 4. 当前 scenario suite 的角色

在当前阶段，scenario suite 的主要职责是三层：

### Layer A — IPC / Session 行为回归

关注：

- hello
- timeout
- open stream
- ack path
- reset / resume 入口

### Layer B — Facade / Contract 行为回归

关注：

- local facade 与 remote facade 是否仍然共享同一语义结果
- request/response 组合在 loopback 路径上是否断裂

### Layer C — Centerline 输出回归

关注：

- `profile.plan`
- `diagnostics.explain_pipeline`
- `job follow`

也就是说，scenario suite 现在已经开始承担“外围协议层 + 中心主链查询层”的双重回归作用。

---

## 5. 当前仍未覆盖的关键场景

还应继续补：

1. queue full / overload 场景
2. stale cursor / reset required 场景
3. protocol mismatch 场景
4. frame too large 场景
5. capability blocked / strict mode 场景
6. daemon command path 触发 apply workflow 的场景
7. effect plan / rollback 投影场景

---

## 6. 下一阶段推进顺序

建议按以下顺序扩：

1. 先补 centerline 相关场景
2. 再补 overload / reset / protocol mismatch
3. 再补 command/apply/snapshot/journal 场景
4. 最后接真实 transport runtime 下的 integration tests

---

## 7. 一句话结论

> 在 Caly 当前阶段，scenario suite 是把 IPC、facade parity 与 centerline plan/explain 从“静态骨架”推进到“可组合验证骨架”的关键桥梁。