# Caly RFC / ADR / Crate Traceability Index

本文件用于把 **RFC、ADR 与当前 workspace crate** 建立可执行的交叉索引。

目的只有一个：

> 避免文档、决策、代码三条线各自推进，最后重新分叉。

---

## 1. 使用方式

当你准备修改一个模块时，建议按以下顺序查：

1. 先看它受哪些 RFC 约束
2. 再看有哪些 ADR 解释为什么这样设计
3. 最后再看当前主要代码落点在哪些 crate / 文件

---

## 2. 核心中心主链映射

| 主链阶段 | 主要 crate | 关键文件 | 受约束 RFC | 关键 ADR |
|---|---|---|---|---|
| Profile / Override / SelectionMemory | `caly-domain` | `model.rs` `builders.rs` | RFC-0001 RFC-0009 | ADR-029 ADR-030 |
| IR / ResolvedProfile | `caly-ir` | `model.rs` `digest.rs` `ids.rs` | RFC-0001 RFC-0003 | ADR-015 ADR-033 |
| Merge / Resolve / Validate / Compile | `caly-pipeline` | `merge.rs` `resolve.rs` `validate.rs` `compile.rs` `flow.rs` | RFC-0001 RFC-0003 RFC-0004 RFC-0009 | ADR-011 ADR-015 ADR-023 ADR-024 ADR-029 |
| Core capability / compile / runtime abstraction | `caly-core` | `adapter.rs` `runtime.rs` `mock.rs` | RFC-0001 RFC-0004 RFC-0008 | ADR-023 ADR-024 ADR-029 |
| Mihomo vertical slice | `caly-mihomo` | `adapter.rs` `runtime.rs` `vertical.rs` | RFC-0004 RFC-0005 RFC-0008 | ADR-023 ADR-024 ADR-029 |
| sing-box vertical slice | `caly-singbox` | `adapter.rs` `runtime.rs` `vertical.rs` | RFC-0004 RFC-0005 RFC-0008 | ADR-023 ADR-024 ADR-029 |
| Apply workflow / jobs / queue / events | `caly-engine` | `apply.rs` `command.rs` `job.rs` `event.rs` `service.rs` | RFC-0001 RFC-0002 RFC-0005 | ADR-012 ADR-018 ADR-028 |
| Snapshot / Journal / CAS | `caly-storage` | `cas.rs` `snapshot.rs` `journal.rs` `store.rs` | RFC-0005 RFC-0006 RFC-0007 | ADR-011 ADR-014 ADR-022 |
| Daemon state owner / request boundary | `caly-daemon` | `app.rs` `request_map.rs` `query.rs` `session.rs` | RFC-0001 RFC-0002 RFC-0005 | ADR-017 ADR-018 ADR-020 ADR-021 ADR-026 ADR-027 |
| Local/Remote client assembly | `caly-app` | `remote.rs` `remote_facade.rs` `parity.rs` `contract.rs` | RFC-0002 RFC-0008 | ADR-017 ADR-019 ADR-025 ADR-026 |
| IPC protocol / session / stream | `caly-ipc` | `frame.rs` `handshake.rs` `stream.rs` `session.rs` | RFC-0002 | ADR-019 ADR-034 |
| CLI follow / status / contract driver | `caly-cli` | `driver.rs` `follow.rs` `follow_loop.rs` `contract_driver.rs` | RFC-0002 | ADR-017 ADR-018 ADR-027 |
| Shared request context / trace | `caly-common` | `lib.rs` | RFC-0002 RFC-0006 RFC-0010 | ADR-020 ADR-021 |
| IO abstraction / faults / path boundary | `caly-io` | `port.rs` `fault.rs` `vpath.rs` | RFC-0005 RFC-0006 | ADR-011 ADR-013 ADR-021 |
| Deterministic sim / faults / scenarios | `caly-io-sim` | `world.rs` `fault.rs` `scenario.rs` `port_impl.rs` | RFC-0005 RFC-0006 RFC-0007 | ADR-013 ADR-022 |
| Architecture dependency guard | `caly-arch-test` | `lib.rs` | RFC-0001 | ADR-025 ADR-029 ADR-033 |

---

## 3. RFC -> crate 索引

### RFC-0001 Core Architecture

主要对应：

- `caly-domain`
- `caly-ir`
- `caly-pipeline`
- `caly-core`
- `caly-engine`
- `caly-daemon`
- `caly-app`
- `caly-arch-test`

最关键问题：

- 状态所有权
- 边界分层
- anti-corruption
- centerline 优先级

### RFC-0002 API / Facade / IPC

主要对应：

- `caly-api`
- `caly-ipc`
- `caly-daemon`
- `caly-app`
- `caly-cli`
- `caly-common`

最关键问题：

- Query/Command/Stream
- Facet / Operation / Envelope
- local/remote parity
- stream/reset/ack/follow

### RFC-0003 Pipeline / Provenance

主要对应：

- `caly-ir`
- `caly-pipeline`
- `caly-domain`

最关键问题：

- merge/resolve/validate/compile
- deterministic digest
- provenance / stage discipline

### RFC-0004 Capability / Coverage

主要对应：

- `caly-cap`
- `caly-core`
- `caly-pipeline`
- `caly-mihomo`
- `caly-singbox`

最关键问题：

- registry single source of truth
- support level / capability state
- strict mode gate
- evidence binding

### RFC-0005 Deployment / Recovery

主要对应：

- `caly-plan`
- `caly-engine`
- `caly-storage`
- `caly-daemon`
- `caly-core`
- `caly-mihomo`
- `caly-singbox`

最关键问题：

- ApplyPlan / EffectPlan
- executor
- health probe
- rollback / recovery

### RFC-0006 IO Port / IoFault

主要对应：

- `caly-io`
- `caly-io-sim`
- `caly-common`
- `caly-storage`

最关键问题：

- single IO gateway
- ctx propagation
- fault normalization
- bounded execution domains

### RFC-0007 Storage / CAS / Snapshot

主要对应：

- `caly-storage`
- `caly-engine`
- `caly-daemon`

最关键问题：

- object store vs DB
- snapshot / journal
- recovery truth sources

### RFC-0008 RuntimeDriver / Telemetry

主要对应：

- `caly-core`
- `caly-mihomo`
- `caly-singbox`
- `caly-app`

最关键问题：

- runtime abstraction
- telemetry / probe / control plane
- watch exposure

### RFC-0009 Profile Patch / Override

主要对应：

- `caly-domain`
- `caly-pipeline`
- `caly-api`

最关键问题：

- override selector
- patch mutation boundary
- native-only / opaque preservation

### RFC-0010 Security / Secret / Redaction

主要对应：

- `caly-common`
- `caly-io`
- `caly-daemon`
- `caly-app`
- future helper / keyring integration

最关键问题：

- trace redaction
- support bundle hygiene
- keyring / download / IPC output hygiene

---

## 4. ADR -> crate 索引

### ADR-011 / ADR-012 / ADR-014

关注：

- effect-first thinking
- apply/recovery transaction
- durability tiers

主要 crate：

- `caly-plan`
- `caly-engine`
- `caly-storage`

### ADR-017 / ADR-018 / ADR-019 / ADR-026 / ADR-027

关注：

- single facade
- jobs for writes
- stream reset/ack/replay
- operation envelope
- Query/Command/Stream discipline

主要 crate：

- `caly-api`
- `caly-ipc`
- `caly-daemon`
- `caly-app`
- `caly-cli`

### ADR-021 / ADR-022

关注：

- context propagation
- deterministic simulation as gate

主要 crate：

- `caly-common`
- `caly-io`
- `caly-io-sim`
- `caly-daemon`
- `caly-engine`

### ADR-023 / ADR-024

关注：

- capability support levels
- registry as single source of truth

主要 crate：

- `caly-cap`
- `caly-core`
- `caly-pipeline`
- `caly-mihomo`
- `caly-singbox`

### ADR-029 / ADR-030 / ADR-033

关注：

- anti-corruption layer
- structured patch as唯一入口
- version lines independent evolution

主要 crate：

- `caly-domain`
- `caly-ir`
- `caly-pipeline`
- `caly-arch-test`
- `caly-api`

### ADR-034

关注：

- local IPC transport route freeze

主要 crate：

- `caly-ipc`
- `caly-daemon`
- `caly-app`

---

## 5. 当前最值得盯紧的三条 traceability 链

### 5.1 API 收敛链

```text
RFC-0002
  -> ADR-017 / ADR-025 / ADR-026 / ADR-027
  -> caly-api / caly-daemon / caly-app / caly-cli
```

对应当前工程任务：

- `operation.rs` 瘦身
- DTO 分面迁移
- local/remote facade 稳定导出面统一

### 5.2 Capability 决策链

```text
RFC-0004
  -> ADR-023 / ADR-024
  -> caly-cap / caly-pipeline / caly-core / adapters
```

对应当前工程任务：

- registry-driven evaluation
- strict mode gate
- fallback -> apply planning integration

### 5.3 Apply / Recovery 执行链

```text
RFC-0005 + RFC-0007
  -> ADR-011 / ADR-012 / ADR-014 / ADR-022
  -> caly-plan / caly-engine / caly-storage / caly-daemon
```

对应当前工程任务：

- effect executor
- pending journal
- snapshot commit
- daemon boot recovery

---

## 6. 推荐维护规则

每次修改某个 crate 时，至少同步检查：

1. 对应 RFC 是否被违反
2. 关联 ADR 是否需要补解释
3. 对应工程文档是否需要更新
4. 是否影响 centerline / parity / scenario / contract

---

## 7. 一句话结论

> Caly 的文档、决策与代码不应是三套平行宇宙；这份索引的作用，就是把 RFC -> ADR -> crate 的责任链固定下来。