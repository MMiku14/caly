# Caly Local/Remote Facade Parity Notes

本文件用于说明 `LocalFacade`、`RemoteFacade` 与 `LoopbackHarness` 在当前阶段的关系，以及 parity 已经推进到哪里。

---

## 1. 为什么这份文档仍然重要

Caly 的一个核心目标是：

- LocalApi / RemoteApi 语义一致
- CLI/TUI 不因为 transport 不同而拥有不同业务逻辑
- facade 只是 transport 差异的边界，不是业务逻辑分叉点

因此，parity 不是锦上添花，而是控制平面架构的核心质量约束。

---

## 2. 当前已经具备的基础

当前已形成：

- `LocalFacade`
- `RemoteSessionClient<T>`
- `RemoteFacade<T>`
- `LoopbackRemoteTransport`
- `LoopbackHarness`
- `run_basic_parity_check(...)`
- `run_system_contract(...)`
- `run_job_follow_contract(...)`
- `run_loopback_remote_contract(...)`

这意味着：

- 本地调用路径已经不是 ad-hoc helper，而是 facade 入口
- 远程调用路径已经不是纯 DTO 结构，而是 session + transport + client glue
- local/remote 之间已经有最小 contract 验证层

---

## 3. 与之前相比的实际推进

当前 parity 面已经从：

- `system.status`
- `system.info`
- `runtime.status`
- `diagnostics.follow_job`

继续扩展到：

- `profile.plan`
- `diagnostics.explain_pipeline`

这很重要，因为这两个接口已经直接贴近中心主链：

- `profile.plan` 能暴露 apply planning 结果
- `diagnostics.explain_pipeline` 能暴露 pipeline / compile / effect projection

也就是说，parity 开始不再只是外围系统状态，而是在比较 centerline 的输出。

---

## 4. 当前 parity 的真实边界

当前已经成立的结论：

1. local facade 可通过 daemon query path 获取 centerline plan/explain 结果
2. remote facade 可通过 IPC operation 获取相同语义结果
3. parity / contract / loopback scenario 已有代码入口并可编译验证

但当前**尚未**宣称：

- 所有 Facet 都已 parity
- stream runtime 行为已完全一致
- reconnect / retry / reset 策略已完全固定
- apply command 执行路径已 local/remote 同步闭环

---

## 5. 当前仍然不是完全 parity 的地方

仍有明显差距：

1. `operation.rs` 仍偏大，DTO 迁移未完成
2. local/remote 两侧仍有若干 skeleton 值直接返回
3. command path 的真实 apply 执行尚未接好
4. stream runtime 的更丰富行为还未完全对齐
5. overload/public error 仍未在所有 operation 路径完全一致地体现

---

## 6. 为什么 loopback harness 仍然关键

Loopback harness 的价值在于：

- 能让 remote path 在无真实 UDS/Named Pipe runtime 的阶段先跑起来
- 能把 hello/request/stream/ack/follow 串起来
- 能作为 local/remote parity 的低成本回归底座

也就是说：

> loopback harness 不是过渡玩具，而是 parity 收敛的前置基础设施。

---

## 7. 下一阶段该怎么推进 parity

正确顺序应是：

1. 完成 `caly-api` DTO 收敛
2. 让更多 Facet 的 query/command 统一走 operation 驱动
3. 继续把 `plan` / `explain` / `follow` / `watch` 纳入 contract
4. 在 daemon command path 接上真实 apply 后，再比较 local/remote 的 job lifecycle 输出

---

## 8. 一句话结论

> Local/Remote parity 已经从“外围状态对照”推进到“中心主链结果对照”，下一步要做的是把这种对照扩展到真实 apply 执行闭环。