# Caly IPC Transport Decision Analysis

本文件专门回答一个当前非常关键的问题：

> **Caly 的本地控制面通信，应该选 gRPC，还是 JSON 帧 + HTTP，还是继续坚持自定义长度前缀 JSON 帧？**

本文结合 Caly 当前的架构目标、运行环境和已经形成的 RFC/ADR，给出系统性分析与建议。

---

## 1. 先给结论

### 1.1 推荐结论

对于 **Caly v1 的本机单用户 daemon 控制面**，推荐：

> **主协议使用：基于 Unix Domain Socket / Windows Named Pipe 的长度前缀 JSON 帧协议**

而不是：

- 直接以 **gRPC** 作为核心本地 IPC
- 或直接以 **HTTP + JSON** 作为核心本地 IPC

### 1.2 更细的策略建议

建议分三层：

1. **核心本地控制面**  
   使用：`length-prefixed framed JSON` over UDS / Named Pipe

2. **可选调试/桥接层**（未来）  
   可以增加：HTTP/JSON bridge

3. **可选远程/生态层**（未来）  
   如确有多语言远程 API 诉求，再评估 gRPC bridge

也就是说：

> **v1 不建议把 gRPC 或 HTTP 变成 Caly 本地 IPC 的基础传输层；它们更适合作为未来的桥接层，而不是核心控制面。**

---

## 2. 这个决策要满足什么目标

Caly 的 IPC 不是普通 Web API。它要满足的目标包括：

1. **本机、本地、单用户优先**
2. **低常驻开销**
3. **对 CLI/TUI 友好**
4. **支持 Query / Command / Stream 三类语义**
5. **支持 Job follow / event replay / Reset**
6. **要能处理 daemon 重启、gap、slow client、backpressure**
7. **要能利用 UDS / Named Pipe 的本机权限与身份边界**
8. **要易于调试、易于演进、易于做故障注入测试**

这几个目标叠在一起后，就会发现：

- 这不是一个典型“浏览器调用后端”的 HTTP 场景
- 也不是一个典型“多语言微服务网格”的 gRPC 场景
- 它更像是一个**强本地语义、强状态同步、强恢复要求**的控制通道

---

## 3. 三个候选方案

为了避免概念混淆，建议明确区分三个候选：

### 方案 A：gRPC

```text
gRPC over HTTP/2
transport: UDS (Unix) / TCP / platform bridge
payload: protobuf
streaming: native streaming
```

### 方案 B：HTTP + JSON

```text
HTTP/1.1 or HTTP/2 over UDS / localhost bridge
payload: JSON
streaming: SSE / WebSocket / long-poll / chunked
```

### 方案 C：自定义长度前缀 JSON 帧

```text
UDS / Named Pipe
u32 length + payload
payload: JSON (default)
streaming: same framed protocol within one session
```

当前 Caly 的 skeleton 其实更接近 **方案 C**。

---

## 4. gRPC 的优点与问题

### 4.1 gRPC 的优点

gRPC 的优势是真实存在的：

1. **IDL 清晰**：protobuf schema 很适合生成代码
2. **双向流支持成熟**
3. **跨语言生态很好**
4. **工具链丰富**
5. **错误码/metadata/interceptor 体系成熟**

如果 Caly 的主要目标是：

- 多语言 SDK
- 远程控制面
- 多进程/多机服务调用
- 企业级平台接口

那么 gRPC 会非常有吸引力。

### 4.2 gRPC 对 Caly v1 的主要问题

但对于 **Caly v1 的本地 daemon 控制面**，gRPC 有几个明显问题：

#### 问题 1：它引入的复杂度明显高于收益

Caly 当前最核心的对象已经是 Rust DTO + Operation + Job + Stream。

如果再引入 protobuf/gRPC：

- 你会得到第二套 schema 语言
- 需要处理 codegen
- 需要处理 Rust DTO 和 protobuf DTO 的映射
- 需要处理 stream / reset / replay 的二次语义封装

这会显著增加协议维护成本。

#### 问题 2：对 Named Pipe / peer credential / 本地权限边界并不天然友好

Unix 下 gRPC over UDS 还算可行；
但 Windows 下如果你想自然接 Named Pipe，本地权限模型与实现复杂度会明显上升。

而 Caly 当前正是明确要求：

- Unix 用 UDS
- Windows 用 Named Pipe
- 权限边界走本机 peer credential / SID

自定义本地 framed protocol 对这些需求更自然。

#### 问题 3：gRPC streaming 不等于“直接满足 Caly 的 replay/reset 模型”

Caly 的 stream 不是普通 server streaming 那么简单，它还有：

- replay window
- retained_from
- reset_required
- slow client policy
- stream kind 不同 delivery guarantee
- event -> stream bridge
- job follow

这些语义仍然需要你在 gRPC 层自己定义一套消息协议。也就是说：

> gRPC 只替你解决了“消息怎么送”，没有替你解决“流语义是什么”。

#### 问题 4：调试与人工审查成本更高

当前 Caly 的 JSON framed protocol 非常适合：

- 打日志
- 抓包（本地）
- 审查 request/response/event
- 快速理解协议演进

而 gRPC/protobuf 会让调试门槛更高，尤其在早期架构收敛阶段。

#### 问题 5：低资源和最小依赖目标更容易被侵蚀

gRPC 栈通常意味着：

- 更重的依赖
- 更多抽象层
- 更高的实现复杂度
- 更难控制“本地 IPC 只是本地 IPC”的轻量边界

Caly 当前更需要的是：

> 用最少机制精确定义本地控制语义

而不是引入服务网格级协议栈。

---

## 5. HTTP + JSON 的优点与问题

### 5.1 HTTP + JSON 的优点

HTTP + JSON 的优点主要是：

1. **人类可读、调试容易**
2. **工具丰富（curl、浏览器、代理、日志）**
3. **Query/Command 很自然**
4. **以后做 bridge 很方便**

### 5.2 HTTP + JSON 对 Caly v1 的主要问题

#### 问题 1：本地 IPC 场景下，HTTP 语义层有点多余

Caly 当前不是一个公网 API 服务，而是本机控制面。

如果只是在：

- CLI ↔ daemon
- TUI ↔ daemon

之间通信，那么 HTTP 会额外带来：

- method/path/header/status code 语义层
- 连接管理和升级语义
- SSE/WebSocket/long-poll 的二次选择

这些都不是当前最核心的问题。

#### 问题 2：Stream 语义反而更复杂

如果用 HTTP + JSON，你还得再选：

- SSE
- WebSocket
- chunked streaming
- 轮询

而 Caly 的核心流语义又不是“简单广播一段文本”，而是：

- watch open
- replay from seq
- reset
- retained window
- per-stream policy
- job follow

这些语义用自定义 frame 反而更直接。

#### 问题 3：Windows Named Pipe 上的 HTTP 体验并不优雅

Unix 上 HTTP over UDS 还可接受；
Windows 下想把 Named Pipe + HTTP 做得自然，复杂度也会上来。

#### 问题 4：本地身份认证未必更简单

Caly 依赖的是本机边界，不是 bearer token 为主的网络服务边界。

自定义 framed protocol 可以更自然地绑定：

- peer credential
- current uid/SID
- daemon instance id
- 本地单用户权限模型

HTTP 并不会自动帮你把这些问题变简单。

---

## 6. 自定义长度前缀 JSON 帧的优点与问题

### 6.1 优点

#### 优点 1：最贴合 Caly 的本地控制面需求

它天然适合：

- UDS
- Named Pipe
- request/response
- job/event stream
- watch/replay/reset
- 本地权限边界

#### 优点 2：协议层可完全围绕 Caly 语义设计

可以精确控制：

- hello
- session state machine
- request envelope
- response envelope
- stream frame
- ack policy
- reset semantics
- replay window
- bounded payload policy
- job follow

#### 优点 3：JSON 调试友好

在早期迭代阶段，JSON payload 的可读性非常有价值。

#### 优点 4：不用引入第二套 schema 语言

当前 Rust DTO + JSON schema 快照已经是清晰路径。

#### 优点 5：更适合先把协议做对，再考虑桥接

Caly 当前最大风险不是“生态不够大”，而是：

- 语义不清
- 流重连不稳
- reset 不正确
- idempotency 没处理好
- job follow 不一致

自定义 framed protocol 更适合先把这些做扎实。

### 6.2 问题

它也不是没有代价：

#### 问题 1：很多机制要自己设计

比如：

- 握手
- frame size
- 协商
- ack 策略
- replay 语义
- reset 语义
- session 状态机

#### 问题 2：多语言生态不如 gRPC

如果未来真要给外部生态开放多语言 SDK，gRPC 的吸引力会变大。

#### 问题 3：如果 discipline 不够，容易协议漂移

所以才必须有：

- RFC-0002
- IPC protocol analysis
- policy 层
- negotiation 层
- session 层
- schema 快照

也就是说，自定义协议不是不能做，而是**必须认真做**。

---

## 7. 三方案对比矩阵

| 维度 | gRPC | HTTP + JSON | Framed JSON over UDS/Pipe |
|---|---|---|---|
| 本地 IPC 贴合度 | 中 | 中 | 高 |
| UDS 支持 | 高 | 高 | 高 |
| Windows Named Pipe 适配自然度 | 中/低 | 中/低 | 高 |
| 调试可读性 | 中/低 | 高 | 高 |
| 流语义定制能力 | 中 | 中 | 高 |
| Reset / replay 语义表达 | 仍需自定义 | 仍需自定义 | 原生可围绕需求设计 |
| 依赖与复杂度 | 高 | 中 | 低/中 |
| 多语言生态 | 高 | 中 | 低 |
| 本地权限边界适配 | 中 | 中 | 高 |
| 早期架构收敛成本 | 高 | 中 | 低/中 |
| 长期 bridge 扩展 | 高 | 高 | 可通过桥接补齐 |

---

## 8. 推荐的正式决策

建议正式决策写成：

> **Caly v1 的本地控制面 IPC 采用 length-prefixed framed JSON over UDS / Named Pipe。**  
> gRPC 不作为 v1 核心本地 IPC。  
> HTTP/JSON 与 gRPC 如有需要，作为未来桥接层而不是基础协议层。

这个决策的核心理由有三条：

1. **最贴合 Caly 的本地状态同步、session 与恢复语义**
2. **最低复杂度下保留最高协议定制度**
3. **最符合当前 Rust-first、low-overhead、single-daemon 架构目标**

---

## 9. 如果将来要支持 HTTP 或 gRPC，正确姿势是什么

### 9.1 不要反过来让核心协议为桥接协议让路

正确方式应是：

```text
Facade / Operation / Job / Stream 语义
        ↓
核心本地 framed JSON protocol
        ↓
可选 HTTP/JSON bridge
可选 gRPC bridge
```

而不是：

```text
gRPC or HTTP first
  ↓
本地 daemon 核心协议被迫围着桥接层设计
```

### 9.2 适合未来引入 gRPC 的条件

只有当以下需求明显成立时，再认真考虑 gRPC bridge：

- 需要多语言 SDK
- 需要远程控制平面
- 需要外部平台程序集成
- 需要把 Caly 当作被别的系统调用的服务

即便如此，也更推荐：

- 核心本地协议保持不变
- 在 daemon 外层或并行实现 gRPC bridge

---

## 10. 当前代码层建议

基于现有 skeleton，建议继续沿这个方向推进：

### 10.1 应继续保留并强化

- `RequestEnvelope` / `ResponseEnvelope`
- `StreamFrame` / `Ack` / `Reset`
- `watch_bridge`
- `EventLog::replay_from`
- `StreamPolicy`
- `NegotiationPolicy`
- `SessionMachine`
- `validate_frame_header`

### 10.2 应尽快补上的协议承载位

建议下一步尽快考虑加入：

- 更明确的 session / connection state
- query + stream 的 revision 对齐说明
- job follow stream retained/reset 规则
- hello/session loop 的执行路径

### 10.3 应继续避免

- 让 Query 偷带副作用
- 让 watch 直接暴露 engine event
- 用 HTTP path/method 反向塑造内部语义
- 因为“未来可能有 gRPC”就过早引入 protobuf/gRPC 栈

---

## 11. 最终建议

如果你现在要做一个**明确工程决策**，我建议是：

### v1

- **核心本地协议：自定义长度前缀 JSON 帧**
- **传输：Unix UDS / Windows Named Pipe**
- **session：Hello/HelloAck + explicit session machine**
- **stream：统一 frame + explicit reset + replay window**
- **command：job 化**
- **query：snapshot/revision 语义**

### v1.x / v2 以后如有需要

- 增加 **HTTP/JSON bridge** 供调试和生态接入
- 再评估是否需要 **gRPC bridge**

### 不建议

- 现在就把 gRPC 作为核心本地 IPC
- 现在就把 HTTP 当成本地控制面的基础协议壳

---

## 12. 一句话结论

> 对 Caly 这样的本机 daemon 控制面，**优先做对本地 framed JSON 协议**，比过早切到 gRPC 或 HTTP 更重要；gRPC/HTTP 更适合作为未来桥接层，而不是 v1 的核心本地 IPC。