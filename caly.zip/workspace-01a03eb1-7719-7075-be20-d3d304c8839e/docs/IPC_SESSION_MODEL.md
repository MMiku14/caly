# Caly IPC Session Model

本文件补充说明 Caly IPC 在“消息结构”之外更关键的一层：**会话状态机**。

它回答的问题包括：

- 连接建立后，哪些消息顺序是合法的？
- `Hello / HelloAck` 之后，session 到底进入什么状态？
- 普通 request 在什么条件下才允许处理？
- frame 校验、协议协商、request 校验分别发生在哪一层？

---

## 1. 为什么需要单独的 session 模型

如果只有：

- `ClientHello`
- `RequestEnvelope`
- `StreamFrame`

而没有会话状态机，那么实现很容易出现这些问题：

1. 客户端没 hello 就直接发 request
2. 服务端没有把协商结果固定下来
3. hello 后的 encoding/compression/protocol 没被持续约束
4. session close 后仍然意外处理 request
5. request 校验和 frame 校验散落在多处

因此，Caly 的 IPC 不应仅仅是“几种消息结构”，还必须有明确的会话状态语义。

---

## 2. 推荐状态机

建议最小 session 状态机如下：

```text
AwaitingHello
   -> Active
   -> Closed

Active
   -> Closed
```

### 2.1 `AwaitingHello`

表示：

- 连接已建立
- 尚未完成协议协商
- 仅允许接收 `ClientHello`

### 2.2 `Active`

表示：

- 已完成握手
- 已确定 protocol / encoding / compression / role 等协商结果
- 才允许处理普通 request / stream ack

### 2.3 `Closed`

表示：

- session 已终止
- 不应再处理新消息

---

## 3. 协商结果应固定到 SessionInfo

建议协商成功后，至少固定以下字段：

- `session_id`
- `daemon_instance_id`
- `protocol_version`
- `client_kind`
- `role`
- `selected_encoding`
- `selected_compression`
- `state_revision_at_hello`

这意味着：

> 协商结果不是只回一条 `HelloAck` 就结束，而是要变成 session 的持续约束条件。

---

## 4. 三层校验顺序

推荐按以下顺序校验：

### 第 1 层：Session State Validation

检查：

- 是否已完成 hello
- session 是否已关闭
- 当前消息类型在此状态是否合法

### 第 2 层：Frame Validation

检查：

- frame size
- compression policy
- control frame 是否允许压缩

### 第 3 层：Request Validation

检查：

- request protocol 是否与 session 协商结果兼容
- role 是否满足 operation 要求
- request envelope 是否完整
- operation metadata 是否匹配后续 handler 路径

---

## 5. 为什么这层对 Caly 特别重要

Caly 的 IPC 不是 stateless HTTP 调用，它还要承载：

- daemon instance id
- replay / reset
- watch reconnect
- 本地权限边界
- Query / Command / Stream 三类语义

如果没有 session state machine：

- reconnect 语义会变得混乱
- 协议协商无法稳定持续
- stream 会话和普通 request 会话容易相互污染

---

## 6. 与 gRPC / HTTP 的关系

无论未来是否加 gRPC bridge 或 HTTP bridge，**核心本地 IPC** 仍然需要这层 session 语义。

换句话说：

- gRPC 不会自动替你定义这些本地会话状态
- HTTP 也不会自动替你定义 replay/reset/watch 语义

因此，先把 session state machine 做清楚，是正确顺序。

---

## 7. 当前 skeleton 对应关系

目前代码骨架中，已开始对应到：

- `caly-ipc::session::SessionMachine`
- `caly-ipc::negotiate::*`
- `caly-ipc::session_loop::*`
- `caly-daemon::session::DaemonSession`
- `caly-daemon::session_loop::*`

但仍缺：

- 真正的 transport loop
- hello timeout 的执行调度
- close / shutdown / reconnect 流程
- stream ack 的更细粒度会话策略
- `ClientFrame` 级统一处理入口的进一步完整化

---

## 8. 推荐下一步

建议继续按以下顺序推进：

1. `SessionMachine` 接入 transport/session loop
2. `ClientFrame::Request` 与 `ClientFrame::StreamAck` 的统一 session handling
3. hello timeout 与 close path
4. session-aware stream replay / ack 策略

---

## 9. 一句话结论

> Caly IPC 的正确性，不只取决于消息格式，还取决于：每条连接是否被一个明确的 session state machine 严格约束。