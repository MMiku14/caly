# RFC-0009: Caly Profile Patch / Override 规范

- Status: Draft
- Version: 1.0.0-draft
- Depends-On: RFC-0001, RFC-0003, RFC-0004
- Last-Updated: 2026-08-23

---

## 摘要

本文冻结 Caly 的结构化配置修改模型，包括：

- Profile Patch
- Source Override
- Runtime Override
- Selector
- Native Patch 的允许范围

本文旨在确保 Caly 的配置编辑行为具有稳定语义、可解释性、可迁移性和可回滚性，而不是退化为“直接修改生成后的 YAML/JSON”或“对整棵树做任意 JSON Patch”。

---

## 1. 目标

本文冻结：

- Caly 中唯一合法的配置修改入口
- Patch 与 Override 的职责边界
- Selector 的基本语义
- 持久 override 与临时 runtime override 的差异
- Native Patch 的受限边界
- Patch 的校验与 explain 要求

---

## 2. 非目标

本文不冻结：

- 完整 CLI 参数形式
- TUI 交互流程
- 具体 Rust enum 代码细节
- 复杂脚本语言设计

---

## 3. 设计原则

1. 生成后的原生配置文件 **MUST NOT** 成为用户主要编辑入口。
2. Patch **MUST** 是结构化的，而不是无约束文本替换。
3. Override **MUST** 以业务语义表达，而不是任意脚本。
4. Runtime override 与持久 override **MUST** 明确区分。
5. Native Patch **MUST** 受限，不能绕过统一层边界。

---

## 4. 修改入口分层

Caly 的配置修改分为三层：

| 层级 | 作用 | 生命周期 |
|---|---|---|
| `ProfilePatch` | 修改 Profile 结构与声明 | 持久 |
| `SourceOverride` | 修改来源内容的解释/筛选/重命名结果 | 持久 |
| `RuntimeOverride` | 本次运行的临时选择/策略调整 | 临时 |

### 4.1 `ProfilePatch`

用于修改：

- Profile 基本属性
- source 列表
- core target
- routing mode
- tun/dns/inbound 策略
- 用户规则段

### 4.2 `SourceOverride`

用于修改：

- 节点过滤
- 节点重命名
- 分组归属调整
- 设置某些可公开建模字段
- 丢弃某些 extension

### 4.3 `RuntimeOverride`

用于：

- 当前运行组选中节点
- 当前临时 routing mode
- 某些明确声明为 runtime-scoped 的可热切换参数

RuntimeOverride 默认不写回上游 source 原文。

---

## 5. `ProfilePatch` 基本语义

`ProfilePatch` 是唯一合法的 Profile 修改抽象。典型操作包括：

- `AddSource`
- `RemoveSource`
- `ReorderSources`
- `SetCoreTarget`
- `SetCoreVersionPin`
- `SetRoutingMode`
- `SetTunPolicy`
- `SetDnsPolicy`
- `SetInboundPolicy`
- `AddRule`
- `RemoveRule`
- `ReplaceRule`
- `PatchNativeExtension`

### 5.1 语义要求

- Patch MUST 作用于强类型对象，而不是弱文本片段
- Patch MUST 能进行引用重写与一致性检查
- Patch SHOULD 带有可解释的目标路径或目标对象标识

---

## 6. `SourceOverride` 基本语义

`SourceOverride` 是“对来源解释结果施加用户规则”的抽象。典型动作包括：

- `Include`
- `Exclude`
- `Rename`
- `SetGroup`
- `SetField`
- `DropExtension`
- `DropPassthrough`（需显式）

### 6.1 约束

- `SourceOverride` 作用于 source 导入结果，而非直接改写原 source 文本
- 同一 override 的适用范围 MUST 可由 selector 明确表达
- 作用结果 MUST 进入 Provenance 与 MergeReport

---

## 7. Selector 规范

### 7.1 角色

Selector 用于定义某条 Override/Patch 针对哪些对象生效。

### 7.2 允许的匹配维度

最低建议支持：

- by stable id
- by source id
- by display name / alias
- by protocol
- by transport/security feature
- by group membership
- by geographic / tag metadata（若已建模）

### 7.3 正则

若支持正则匹配：

- MUST 有复杂度限制
- MUST 使用线性时间或受控引擎
- MUST 在 RFC-0003 的输入边界内执行

### 7.4 解释能力

Selector 命中结果 SHOULD 能通过 explain 输出展示：

- 命中了哪些对象
- 哪些对象被排除
- 冲突时谁覆盖了谁

---

## 8. Runtime Override 规范

### 8.1 角色

`RuntimeOverride` 表达“本次运行的临时偏好”，例如：

- 某个 selector 组选中节点
- 临时切换到 Global / Direct
- 某些允许热切换的 DNS/测试策略

### 8.2 约束

- RuntimeOverride 优先级高于 ProfileOverride
- 默认不污染持久 Profile
- 若用户选择持久化，则必须显式转换为 ProfilePatch 或 SelectionMemory

### 8.3 Selection Memory

组选择记忆属于受限持久状态，介于 runtime 与 profile 之间：

- 它记录用户选择结果
- 但不修改上游 source
- 它应在 Snapshot/Revision 中受控持久化

---

## 9. Native Patch 边界

### 9.1 目标

Native Patch 用于支持某些目标 Core 专属能力，但不能破坏 Caly 的统一边界。

### 9.2 允许范围

v1 Native Patch 仅应允许受限操作，例如：

- 替换 scalar
- 添加/删除有 key 的对象项
- 替换整个受限 opaque block

### 9.3 禁止项

- 任意深层 JSON Patch
- 无约束 deep merge
- 任意脚本变换 native tree
- 跨 Core 自动迁移未知 native 块

### 9.4 能力约束

Native Patch 命中 `passthrough` 或 `extension` 时，必须受 Capability 体系约束。

---

## 10. Patch 校验

所有 Patch/Override 在进入编译前都必须通过至少以下校验：

1. 目标对象存在性
2. 目标字段可修改性
3. selector 合法性
4. 引用完整性
5. 目标 Core capability 允许性
6. 与 SafetyPolicy 的不冲突性

失败必须返回结构化错误，而不是悄悄忽略。

---

## 11. Explain 与可观测性

Patch/Override 的效果必须可解释。至少应支持：

- 哪条 patch 生效了
- 它作用于哪些对象
- 它覆盖了哪个低优先级来源
- 它是否触发 rename/drop/conflict
- 它为何被拒绝

这些信息应进入：

- MergeReport
- PipelineExplain
- Doctor
- TUI 对应明细页

---

## 12. 与 Capability / Passthrough 的关系

### 12.1 强类型字段

对强类型字段的 patch，优先按 `CalyManaged` 语义处理。

### 12.2 Native 扩展字段

若 patch 目标是 native extension / passthrough：

- 同 Core 目标下 MAY 允许
- 跨 Core MUST 默认失败，除非有显式 mapping
- `drop` 操作必须显式且可解释

---

## 13. 与版本迁移的关系

Patch/Override 设计必须支持版本迁移：

- Patch SHOULD 指向稳定 ID 与结构化字段
- Patch MUST NOT 依赖易变字符串路径作为唯一语义锚点
- Migration 后 patch 语义如改变，必须显式转换或拒绝加载

---

## 14. 测试与门禁

最低测试门槛：

1. ProfilePatch 可重放且结果稳定
2. SourceOverride 不直接污染原始 source 原文
3. RuntimeOverride 不默认持久化
4. selector 命中可解释
5. 非法 patch 被结构化拒绝
6. native patch 跨 Core 无 mapping 时失败
7. patch 效果进入 MergeReport / Provenance

---

## 15. 冻结范围

本文冻结：

- `ProfilePatch` / `SourceOverride` / `RuntimeOverride` 三分模型
- Selector 的职责边界
- Native Patch 的受限原则
- Patch/Override 的校验与 explain 要求
- “禁止直接编辑生成配置”这一边界

本文暂不冻结完整 patch 枚举全集与 CLI/TUI 参数形态。

---

## 16. 一句话结论

Caly 的配置编辑必须收敛为：

> 改的是结构化语义对象，而不是生成后的原生文本；改动必须可验证、可解释、可迁移、可回滚。