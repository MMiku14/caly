# RFC-0010: Caly Security / Secret / Redaction 规范

- Status: Draft
- Version: 1.0.0-draft
- Depends-On: RFC-0001, RFC-0002, RFC-0005, RFC-0006
- Last-Updated: 2026-08-23

---

## 摘要

本文冻结 Caly 的安全边界，重点关注：

- Secret 分类与存储优先级
- Redaction（脱敏）原则
- 日志、错误、IPC、诊断包的敏感信息处理
- Core 下载与来源校验
- 本地通信与权限边界
- SSRF、路径逃逸、任意命令执行等常见控制面风险

本文不试图给出完整的系统安全证明，但它定义了 Caly 在控制平面层面必须遵守的最低安全规范。

---

## 1. 目标

本文冻结：

- 什么属于 Secret
- Secret 在存储、传输、日志与 UI 中的处理规则
- 脱敏发生的时机与责任边界
- 下载、导入、IPC、本地提权通信的最低安全要求
- 诊断导出与 support bundle 的最小安全原则

---

## 2. 非目标

本文不冻结：

- 所有密码学算法细节
- 企业级多用户权限系统
- 远程 SaaS 安全模型
- 完整供应链安全方案

---

## 3. 设计原则

1. 订阅输入与导入配置 **MUST** 视为不可信。
2. Secret **MUST** 默认不进入普通日志、默认 IPC 输出、TUI 历史。
3. 脱敏 **MUST** 在对象构造或边界转换时完成，而不是仅在显示阶段处理。
4. 高权限能力 **MUST** 最小化并隔离。
5. 下载与导入 **MUST** 尽量绑定来源、哈希与验证信息。
6. 任意 shell、任意路径、任意 URL **MUST NOT** 成为内部特权接口的输入。

---

## 4. Secret 分类

至少以下信息应被视为 Secret：

- 订阅 URL 中的 token/query secret
- Authorization header / bearer token
- 节点密码、私钥、UUID、密钥材料
- Core 控制 token / API secret
- 本地加密 secrets store 的解锁材料
- 某些可识别个人或设备身份的信息（按上下文）

### 4.1 准 Secret

以下信息可视上下文视为“需谨慎展示”：

- 用户名
- 目标域名（某些隐私模式下）
- 进程名/路径
- 局域网地址

这些信息不一定永远视作 Secret，但必须允许在 support bundle 或严格模式下被额外收敛。

---

## 5. Secret 存储优先级

### 5.1 优先级

Secret 存储优先级应为：

1. OS keyring / keychain / credential manager
2. 本地加密存储（机器绑定或用户绑定）
3. 明文磁盘存储：默认禁止，仅在极端降级模式下经显式确认

### 5.2 约束

- 普通 Profile、Snapshot、日志文件 MUST NOT 保存可直接复用的 Secret 明文
- 若平台无 keyring，降级存储方案 MUST 有最小权限控制
- Secret 的持久化位置必须可被 Doctor 与 Support Bundle 区分对待

---

## 6. Redaction 规范

### 6.1 Redaction 的位置

脱敏应尽可能在以下边界发生：

- `ApiError` 构造时
- `LogLine` 构造时
- support bundle 生成时
- 对外 DTO 映射时

### 6.2 Redaction 的目标

至少要掩码或替换：

- URL query/token
- Authorization 值
- 密码
- UUID / 私钥 / 公钥片段（按策略）
- Core API token

### 6.3 表现形式

Redaction 的表现形式 SHOULD 稳定，例如：

- `***REDACTED***`
- 部分保留前后缀的 mask

关键在于：

- 同一路径输出行为一致
- 不因前端不同而一处脱敏、一处泄漏

---

## 7. 日志与错误输出

### 7.1 日志

- 普通日志 MUST 默认脱敏
- Debug 日志也 MUST NOT 直接输出完整 Secret
- Core stdout/stderr 若被转发，MUST 经统一 redactor 处理

### 7.2 错误

- `ApiError.summary/detail` MUST 已脱敏
- `Internal` 类错误可隐藏细节，仅暴露 `trace_id`
- CLI `--json` 与 TUI 的错误展示必须共享同一脱敏结果

---

## 8. IPC 与本地通信安全

### 8.1 Frontend ↔ daemon

- UDS / Named Pipe 权限 MUST 受当前用户边界约束
- 握手 MUST 包含协议协商
- 默认不向未授权客户端暴露敏感详情

### 8.2 daemon ↔ Privilege Helper

- MUST 使用受限协议
- MUST 验证 daemon 身份、plan、有效期与作用范围
- MUST NOT 接受任意 shell、路径、URL、环境变量

### 8.3 daemon ↔ Core

- Core 管理 API SHOULD 绑定 loopback only
- 控制 token SHOULD 为每实例随机
- token MUST NOT 写入用户可复制的普通 profile

---

## 9. 下载与导入安全

### 9.1 Core 下载

Core 下载：

- MUST 使用 HTTPS
- SHOULD 验证 checksum/signature（若上游提供）
- MUST 记录来源
- MUST 原子安装
- MUST NOT 静默跟踪 `latest`

### 9.2 Subscription / RuleSet

订阅与规则集：

- MUST 执行大小限制
- MUST 执行超时
- MUST 执行解压比例限制
- MUST 视为不可信输入
- SHOULD 在连接建立后做 SSRF 防护

### 9.3 导入本地文件

本地导入文件：

- MUST 通过受控路径或显式用户输入
- MUST 经同样的解析边界与限额策略处理
- MUST NOT 因“来自本地”而默认可信

---

## 10. 路径与命令执行安全

### 10.1 路径

- 所有内部文件访问 MUST 通过 `VPath` 或等价受限路径模型
- 任何来自外部的路径输入都必须做规范化与逃逸检查

### 10.2 命令执行

- 子进程启动 MUST 直接传 argv
- MUST NOT 使用 shell 字符串拼接
- Helper/Platform 接口 MUST NOT 接受任意命令文本

---

## 11. SSRF 与网络访问边界

Caly 作为控制平面，仍需防止通过下载路径访问敏感本地/内网目标。

### 11.1 最低要求

- 连接后地址校验
- loopback 限制（除显式允许的 active core 管理地址）
- link-local / metadata 地址限制
- 私有网段访问策略可配置，但默认保守

### 11.2 重定向

跨 origin 重定向时 SHOULD 剥离敏感认证头，避免 token 泄漏到错误目标。

---

## 12. Support Bundle 规范

### 12.1 原则

诊断包必须“足够排障”，但不能把用户密钥一并打包出去。

### 12.2 默认应包含

- 架构状态摘要
- 版本信息
- capability 摘要
- 脱敏后的日志
- 脱敏后的 merge/apply 报告
- 资源统计

### 12.3 默认不应包含

- 完整订阅 URL
- 节点密码/私钥
- API token
- 原始 secrets store 内容

若用户显式选择导出敏感内容，系统 MUST 再次确认并清晰标注风险。

---

## 13. 角色与权限边界

虽然 v1 默认单用户本机，系统仍应保持角色分层：

- `Viewer`
- `Operator`
- `Admin`
- `PrivilegedBroker`

安全相关高风险操作至少应满足：

- Core 安装/删除：`Admin`
- 网络修复：`Admin`
- 提权动作执行：仅 `PrivilegedBroker`

---

## 14. 测试与门禁

最低测试门槛：

1. 日志输出默认脱敏
2. `ApiError` 默认脱敏
3. support bundle 不包含明文 secret
4. UDS/Pipe 权限不对其他用户裸开放
5. helper 协议拒绝任意 shell/路径
6. SSRF 防护对危险地址生效
7. Core 下载缺失校验信息时按策略告警或拒绝
8. 本地导入仍受输入限额约束

---

## 15. 冻结范围

本文冻结：

- Secret 的最低分类
- 存储优先级
- Redaction 的责任边界与发生时机
- 日志/错误/IPC/support bundle 的敏感信息规则
- 下载、路径、命令执行、SSRF 的最低安全要求
- Privilege Helper 的受限输入边界

本文暂不冻结具体加密算法与复杂多用户安全策略。

---

## 16. 一句话结论

Caly 的安全边界必须收敛为：

> 不信任输入，不扩散 Secret，不把脱敏留给最后一层，不把高权限留给整个系统。