# RFC-0002: Caly API / Facade / IPC 规范

- Status: Draft
- Version: 1.0.0-draft
- Depends-On: RFC-0001
- Last-Updated: 2026-08-23

---

## 摘要

本文冻结 Caly 的对外控制面契约，包括：

- Facade / Facet 拆分
- Operation Envelope
- Query / Command / Stream 三种执行语义
- Job 与幂等模型
- DTO 稳定性规则
- 错误门面与稳定错误码
- IPC 握手、帧格式、流恢复与 Reset 语义

本文目标是让 CLI、TUI、LocalApi、RemoteApi、Daemon 可以并行开发，并保证语义一致而不把业务状态机泄漏到前端。

---

## 1. 设计原则

1. 外部调用 **MUST** 只经过 Facade，不得直连 Engine、Storage、Adapter 或 Platform。
2. 所有对外变更 **MUST** 归类为 `Command`。
3. 所有对外只读快照 **MUST** 归类为 `Query`。
4. 所有持续推送 **MUST** 归类为 `Stream`。
5. CLI/TUI 与 Daemon 通信语义 **MUST** 与 `LocalApi` 语义一致。
6. 写操作 **MUST** Job 化，避免 IPC 长连接承担同步事务语义。
7. DTO 版本演进 **MUST** 可检测，不允许静默变更。
8. 错误 **MUST** 在跨门面时统一归一化并脱敏。

---

## 2. 顶层 Facade

Caly 对外暴露统一门面 `CalyFacade`，内部拆分为多个按领域划分的 Facet：

```text
CalyFacade
├── SystemFacet
├── ProfileFacet
├── SourceFacet
├── ProxyFacet
├── RoutingFacet
├── DnsFacet
├── NetworkFacet
├── CoreFacet
├── RuntimeFacet
├── DiagnosticsFacet
└── AutomationFacet
```

### 2.1 Facet 约束

每个 Facet：

- MUST 只暴露其领域内稳定能力。
- MUST NOT 暴露底层实现对象，如 SQLite 连接、Core 原生 client、平台句柄。
- SHOULD 返回 DTO，而非 Domain 内部结构。
- MAY 在实现内部组合多个 Engine service，但该组合对调用方不可见。

---

## 3. Facet 规范

### 3.1 SystemFacet

负责：

- daemon 状态与版本信息
- 协议协商结果
- 全局状态摘要
- daemon 退出/重启控制

最小能力：

- `status(ctx) -> SystemStatus`
- `info(ctx) -> ServerInfo`
- `shutdown(ctx) -> Accepted`

### 3.2 ProfileFacet

负责：

- profile CRUD
- 激活 profile
- 计划/应用/回滚
- revision 历史与导入导出

最小能力：

- `list`
- `get`
- `create`
- `patch`
- `activate`
- `plan`
- `apply`
- `rollback`

### 3.3 SourceFacet

负责：

- source / subscription CRUD
- 手动更新
- 预览解析结果
- 更新历史与差异

### 3.4 ProxyFacet

负责：

- 节点浏览
- 策略组状态
- 手动选择节点
- 延迟测试与节点健康

### 3.5 RoutingFacet

负责：

- 规则浏览
- 路由命中解释
- 路由校验报告

### 3.6 DnsFacet

负责：

- DNS 状态
- DNS explain
- cache flush
- leak diagnostic

### 3.7 NetworkFacet

负责：

- TUN / System Proxy / System DNS 状态
- NetworkPlan 预览
- 网络修复
- 权限诊断

### 3.8 CoreFacet

负责：

- core 安装/导入/枚举
- pin / inspect
- capability report
- binary verification

### 3.9 RuntimeFacet

负责：

- runtime 总状态
- connections
- traffic
- logs
- close connection
- runtime watch

### 3.10 DiagnosticsFacet

负责：

- doctor
- pipeline explain
- merge report
- support bundle
- 崩溃恢复状态

### 3.11 AutomationFacet

负责：

- 自动化规则查询与修改
- 调度任务状态
- 自动切换/自恢复控制

---

## 4. LocalApi 与 RemoteApi

系统 **MUST** 同时存在两种实现：

| 实现 | 场景 | 语义要求 |
|---|---|---|
| `LocalApi` | `--no-daemon`、测试、嵌入式 | 与 RemoteApi 等价 |
| `RemoteApi` | 常规 CLI/TUI | 与 LocalApi 等价 |

### 4.1 一致性要求

Local/Remote **MUST** 共享：

- DTO
- ErrorCode
- Job 状态机
- Query/Command/Stream 语义
- 权限检查语义
- `expected_revision` CAS 语义
- `idempotency_key` 处理语义

### 4.2 非保证项

Local/Remote 不保证：

- 相同延迟特征
- 流断线后的零损耗连续性
- 跨进程对象身份共享
- 大对象零拷贝

---

## 5. 三种执行语义

### 5.1 Query

`Query` 表示：

- 只读
- 快照式
- 不产生持久副作用
- 不启动长期任务

`Query`：

- MUST 在一致性边界内返回单一 revision 视图。
- MAY 支持分页。
- MUST NOT 隐式变更 runtime 状态。

### 5.2 Command

`Command` 表示：

- 可能变更持久状态
- 可能触发编译、部署、订阅更新或系统副作用
- 返回 `Accepted { job_id, ... }`

`Command`：

- MUST 被记录为 Job。
- MUST 支持取消/超时语义（如果命令类型允许）。
- SHOULD 支持 `idempotency_key`。

### 5.3 Stream

`Stream` 表示：

- 持续订阅某一 View 或 Job 事件
- 从“快照 + 增量”或“增量-only”模型中选择一种已声明策略
- 可能在过载时返回 `Reset`

---

## 6. 请求上下文 `Ctx`

所有调用 **MUST** 透传统一上下文：

```text
trace_id
actor
deadline
cancel_token
expected_revision
io_budget
role / auth context
```

约束：

1. `deadline` MUST 单调缩减，子调用不得放大超时。
2. `expected_revision` 用于比较并交换（CAS）语义。
3. `trace_id` MUST 在日志、错误、Job、IPC 之间保持一致。
4. `io_budget` SHOULD 用于限制单次调用的资源消耗。

---

## 7. Operation Envelope

所有 RemoteApi 请求 **MUST** 使用统一 Envelope：

```text
RequestEnvelope {
  protocol,
  request_id,
  trace_id,
  deadline_ms?,
  expected_revision?,
  auth,
  operation,
}
```

响应：

```text
ResponseEnvelope {
  request_id,
  trace_id,
  result: Result<OperationResult, ApiError>,
}
```

### 7.1 Operation 分类

```text
System(SystemOp)
Profile(ProfileOp)
Source(SourceOp)
Proxy(ProxyOp)
Routing(RoutingOp)
Dns(DnsOp)
Network(NetworkOp)
Core(CoreOp)
Runtime(RuntimeOp)
Diagnostics(DiagnosticsOp)
Automation(AutomationOp)
```

### 7.2 Operation 元数据

每个 Operation **MUST** 具备静态元数据：

```text
mode: Query | Command | Stream
idempotency: Required | Optional | NotApplicable
required_role: Viewer | Operator | Admin | PrivilegedBroker
mutates_revision: bool
supports_dry_run: bool
max_cost: Tiny | Small | Medium | Large | Privileged
```

该元数据是：

- 调度器上锁
- 权限检查
- 前端交互提示
- 审计
- 资源预算

的统一依据。

---

## 8. Job 模型

### 8.1 Job 生命周期

Job 至少具有以下状态：

```text
Accepted
Queued
Running
WaitingInput      (可选)
Completed
Failed
Cancelled
TimedOut
```

### 8.2 Job 事件

Job 事件流至少支持：

- `Stage { name, pct? }`
- `Log { level, msg }`
- `Warning { diagnostic }`
- `ResetHint { reason }`（可选）
- `Done { outcome }`
- `Failed { error }`

### 8.3 幂等

高风险 Command **MUST** 支持幂等去重。Daemon 必须维护最近窗口：

```text
(actor_id, idempotency_key) -> job_id + final_or_current_state
```

重复命令：

- MUST 返回原 JobId 或等价 outcome
- MUST NOT 再次触发第二次部署

### 8.4 CLI 同步体验

CLI 的同步行为由前端组合实现：

```text
execute -> follow(job) -> 渲染 -> 映射退出码
```

协议层本身不提供“同步命令执行”特权通道。

---

## 9. Query 与分页规范

大集合查询（节点、规则、连接、日志等）**MUST** 支持分页或流式语义。

### 9.1 PageRequest

最小分页输入：

```text
cursor?
limit
sort[]
```

### 9.2 Page

最小分页输出：

```text
items[]
next?
total?
revision
```

### 9.3 Cursor 约束

Cursor：

- MUST 为不可伪造 opaque token
- MUST 绑定 query fingerprint
- MUST 绑定生成它的 revision
- MUST 有失效时间

若基础状态变化过大，服务端 MUST 返回 `CURSOR_STALE` 或等价错误。

---

## 10. Watch / Stream 规范

### 10.1 Stream 统一帧

```text
StreamFrame {
  stream_id,
  seq,
  kind,
  data,
}
```

### 10.2 Reset

`Reset` 是一等协议消息，表示：

- 增量不再连续
- 客户端本地 view 不再可信
- 客户端必须重取 snapshot

客户端 **MUST** 实现 `Reset` 处理，不得假设流永远连续。

### 10.3 流策略分类

| 流 | 策略 | 慢客户端处理 |
|---|---|---|
| Dashboard | snapshot + patch | 缓冲溢出 -> Reset |
| Jobs | 无损 | 可续传 |
| Traffic | 最新值合并 | 丢中间值 |
| Connections | 差分 | 溢出 -> Reset |
| Logs | 有界 ring | 丢历史并附 `dropped` |

### 10.4 ACK

ACK 仅用于必要的可恢复流，例如 Job/Deployment；Telemetry 高频流默认不逐条 ACK。

---

## 11. IPC 传输规范

### 11.1 传输介质

- Unix: UDS
- Windows: Named Pipe

Socket/Pipe 权限 **MUST** 限制为当前用户边界。

### 11.2 帧格式

```text
u32 big-endian length
payload bytes
```

### 11.3 编码

- 默认编码 MUST 为 JSON。
- 可选编码 MAY 为 msgpack。
- 压缩 MAY 支持 zstd，但默认应关闭。
- 控制消息 SHOULD NOT 压缩。
- 单帧大小 MUST 有上限。

### 11.4 大对象传输

大对象（如支持包、导出文件）MUST NOT 直接以内嵌超大 IPC 帧返回。应使用：

- 分页
- 令牌化导出
- Job 产物路径

---

## 12. 握手与兼容性

### 12.1 Hello / HelloAck

握手至少包含：

- `protocol_version`
- `client_kind`
- `client_features`
- `requested_encoding/compression`
- `daemon_instance_id`
- `server_features`
- `snapshot_revision`

### 12.2 兼容规则

- 旧客户端遇到未知方法，服务端 MUST 返回 `PROTO_MISMATCH` 或 `METHOD_UNAVAILABLE`。
- 未协商成功的编码/压缩 MUST 回退到 JSON/none 或拒绝连接。
- 若 `daemon_instance_id` 改变，客户端 MUST 丢弃增量状态缓存。

---

## 13. DTO 设计规则

### 13.1 一般规则

- 请求 DTO MUST `deny_unknown_fields`
- 响应枚举 SHOULD `non_exhaustive`
- DTO 不得直接暴露内部数据库主键实现细节
- DTO 字段命名必须稳定，修改需要协议版本变更策略

### 13.2 映射层

DTO 与 Domain 之间 **MUST** 有集中 mapping 层。`caly-api` 允许一个映射模块同时依赖两边类型，其他模块不允许同时触碰两边。

### 13.3 Schema 快照

JSON Schema **SHOULD** 自动生成并纳入 CI：

- 新增可选字段：兼容
- 删除字段：破坏性
- 改字段类型：破坏性
- 改枚举含义：破坏性

---

## 14. 错误模型

### 14.1 `ApiError`

跨门面后的标准错误结构应包含：

```text
code
category
retryable
summary
detail?
remediation?
diagnostics[]
trace_id
```

### 14.2 错误类别

- User
- Config
- Capability
- Core
- Io
- Platform
- Internal

### 14.3 脱敏规则

脱敏 MUST 在 `ApiError` 构造时完成，而不是在打印阶段才做。这样才能保证：

- `--json`
- TUI
- IPC
- 日志

四条路径一致安全。

### 14.4 稳定错误码

至少冻结：

- `CONFIG_INVALID`
- `CONFLICT`
- `UNSUPPORTED_CAPABILITY`
- `CORE_NOT_RUNNING`
- `CORE_FAILED`
- `PERMISSION`
- `NET_OS`
- `STORAGE`
- `TIMEOUT`
- `UNAVAILABLE`
- `PROTO_MISMATCH`
- `CURSOR_STALE`

---

## 15. 角色与权限

内部角色模型：

- `Viewer`
- `Operator`
- `Admin`
- `PrivilegedBroker`

### 15.1 基本规则

- Query/Watch 默认最低 `Viewer`
- 节点切换/订阅更新/profile apply 至少 `Operator`
- core install/delete/network repair 至少 `Admin`
- privileged helper 仅接受 `PrivilegedBroker` 发起的受限请求

权限检查 **MUST** 在 Operation Dispatch 层执行，而不是散落在业务逻辑深处。

---

## 16. 冻结内容与后续工作

本 RFC 冻结以下接口方向：

1. Facade / Facet 边界
2. Query / Command / Stream 三分语义
3. Operation Envelope
4. Job 与幂等模型
5. DTO 稳定性原则
6. IPC 握手、Reset、分页与流恢复语义
7. ApiError 与错误码边界

后续需补充的实现级文件：

- `caly-api/src/operation.rs`
- `caly-api/src/facets/*.rs`
- `caly-api/src/dto/*.rs`
- `caly-ipc/src/frame.rs`
- `caly-ipc/src/handshake.rs`
- `caly-ipc/src/stream.rs`
- `caly-cli/src/exit_code.rs`

---

## 17. 一句话结论

Caly 的对外交互必须收敛为：

> 领域化 Facet + 统一 Operation Envelope + Query/Command/Stream 三种语义 + 可恢复的 Job 模型。

只有这样，CLI/TUI、本地模式与 daemon 模式才能在不复制业务逻辑的前提下保持一致。