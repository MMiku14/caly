# Caly RFC Index

本目录用于冻结 Caly 的核心架构与关键契约。

RFC 是 Caly 的规范性文档。它们定义：

- 系统边界
- 外部契约
- 状态语义
- 协议与版本
- 能力承诺
- 部署与恢复规则

若实现与 RFC 冲突，以 RFC 为准；若必须偏离，应先修改 RFC，再修改实现。

---

## 1. RFC 列表

| RFC | 标题 | 状态 | 作用 |
|---|---|---|---|
| RFC-0001 | Core Architecture | Draft | 总体边界、依赖方向、不变量、状态模型、实施顺序 |
| RFC-0002 | API / Facade / IPC | Draft | Facet、Operation、Query/Command/Stream、Job、错误门面、IPC |
| RFC-0003 | Pipeline / Provenance | Draft | Stage、DAG、CacheKey、Provenance、Diagnostics、决定性要求 |
| RFC-0004 | Capability / Coverage | Draft | Capability Registry、Support Level、Evidence、Coverage Matrix |
| RFC-0005 | Deployment / Recovery | Draft | ApplyPlan、EffectPlan、Rollback、OSJournal、Recovery、Privilege 边界 |
| RFC-0006 | IO Port / IoFault | Draft | IO 边界、Port 职责、VPath、Ctx 传播、统一 IO 错误模型 |
| RFC-0007 | Storage / CAS / Snapshot | Draft | 本地状态、对象存储、Revision、Snapshot、Journal、迁移与 GC |
| RFC-0008 | RuntimeDriver / Telemetry | Draft | 运行时控制、观测、Probe、限流、统一 RuntimeView |
| RFC-0009 | Profile Patch / Override | Draft | 结构化配置修改入口、Selector、RuntimeOverride、Native Patch 边界 |
| RFC-0010 | Security / Secret / Redaction | Draft | Secret、脱敏、下载安全、IPC 边界、SSRF、Support Bundle |

---

## 2. 文件映射

- `RFC-0001-core-architecture.md`
- `RFC-0002-api-facade-ipc.md`
- `RFC-0003-pipeline-provenance.md`
- `RFC-0004-capability-coverage.md`
- `RFC-0005-deployment-recovery.md`
- `RFC-0006-io-port-iofault.md`
- `RFC-0007-storage-cas-snapshot.md`
- `RFC-0008-runtimedriver-telemetry.md`
- `RFC-0009-profile-patch-override.md`
- `RFC-0010-security-secret-redaction.md`
- `RFC-TEMPLATE.md`

---

## 3. 推荐阅读顺序

### 3.1 第一层：总纲

1. RFC-0001：理解 Caly 的总体边界与不变量

### 3.2 第二层：四条主链路

2. RFC-0002：外部控制面与 IPC 契约
3. RFC-0003：配置处理与解释主链路
4. RFC-0004：能力承诺与支持证据模型
5. RFC-0005：部署、回滚、恢复与特权边界

### 3.3 第三层：实现支撑契约

6. RFC-0006：IO Port 与统一 IO 错误
7. RFC-0007：本地存储、CAS、Snapshot 与 Journal
8. RFC-0008：RuntimeDriver、Telemetry 与 Probe
9. RFC-0009：Profile Patch / Override / Selector
10. RFC-0010：安全、Secret、Redaction 与导出边界

---

## 4. 何时修改哪份 RFC

- 修改 CLI/TUI/daemon 外部行为、DTO、错误码、IPC：更新 RFC-0002
- 修改 Stage、缓存、Explain、Provenance、决定性规则：更新 RFC-0003
- 修改支持声明、CapabilityKey、版本约束、Evidence：更新 RFC-0004
- 修改 Apply/Rollback/Recovery/Privilege 语义：更新 RFC-0005
- 修改 IO Port、IoFault、路径/timeout/cancel 语义：更新 RFC-0006
- 修改存储目录、CAS、Revision、Snapshot、Journal、迁移：更新 RFC-0007
- 修改 RuntimeDriver、Telemetry、Probe、运行时 DTO：更新 RFC-0008
- 修改 ProfilePatch、Override、Selector、Native Patch：更新 RFC-0009
- 修改 Secret、Redaction、下载安全、support bundle、SSRF：更新 RFC-0010
- 修改跨层依赖、单一状态所有权、总体边界：更新 RFC-0001

---

## 5. RFC 状态建议

建议流程：

```text
Draft -> Review -> Accepted -> Superseded / Deprecated
```

当前文档仍处于 `Draft` 阶段，原因是：

- 源码级契约文件尚未完全冻结
- DTO / ErrorCode / Capability Registry / Port trait 还未形成最终代码骨架
- 部分 RFC 之间仍需做交叉引用与重复收敛

---

## 6. 后续建议工作

在 RFC-0001 ~ RFC-0010 基础上，建议下一步推进：

1. 抽取 ADR-011 ~ ADR-033 为独立 ADR 文件
2. 生成源码级契约草案：`operation.rs` / `effect.rs` / `stage.rs` / `capability-registry.json`
3. 统一错误码表与退出码映射表
4. 为 RFC 附加“实现状态”追踪表

---

## 7. 一句话原则

> RFC 不是实现笔记，而是未来实现必须服从的边界。