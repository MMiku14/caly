# RFC-0008: Caly RuntimeDriver / Telemetry 规范

- Status: Draft
- Version: 1.0.0-draft
- Depends-On: RFC-0001, RFC-0002, RFC-0004
- Last-Updated: 2026-08-23

---

## 摘要

本文冻结 Caly 对运行时控制与观测的统一抽象，即 `RuntimeDriver`。它定义：

- Core 运行时控制能力如何被统一表达
- 哪些运行时观测对象属于 Caly 的稳定视图
- 如何处理部分支持与不支持
- Telemetry 如何限流、采样、裁剪与脱敏
- Watch/Stream 与 Runtime 之间的责任边界

本文的目标不是把不同 Core 的 API 强行抹平，而是为上层提供一个**可判定、可降级、可观测**的运行时门面。

---

## 1. 目标

本文冻结：

- `RuntimeDriver` 的职责边界
- Control / Telemetry / Probe 三平面模型
- 统一 RuntimeView 的最小对象集
- 流量、连接、日志、组选中态的最小语义
- 资源预算与限流原则
- 部分能力的呈现方式

---

## 2. 非目标

本文不冻结：

- 具体 Core API 的路径与参数
- TUI 页面布局
- CLI 命令最终参数形式
- RuntimeDriver 的完整 Rust trait 签名

---

## 3. 设计原则

1. 运行时抽象 **MUST** 通过 Adapter 暴露，不得在 Engine/CLI/TUI 中散落 Core 专属 API 调用。
2. 不支持的能力 **MUST** 明示，不得伪装成功。
3. stdout/stderr 只能作为辅助诊断，**MUST NOT** 伪装成完整 Runtime API。
4. 运行时高频数据 **MUST** 受采样与有界缓存控制。
5. 任何进入 RuntimeView 的敏感信息 **MUST** 先脱敏。

---

## 4. 三平面模型

`RuntimeDriver` 至少分为三类能力：

```text
ControlPlane
TelemetryPlane
ProbePlane
```

### 4.1 ControlPlane

负责可执行控制动作，例如：

- status
- select proxy
- reload
- stop
- close connection
- flush DNS cache（若核心支持）

### 4.2 TelemetryPlane

负责持续观测与订阅，例如：

- traffic
- connections
- logs
- group state
- delay test result
- core resource usage

### 4.3 ProbePlane

负责部署后和运行中的真实性检查，例如：

- API readiness
- config identity
- inbound listening
- optional probe target reachability

---

## 5. Capability 与 RuntimeDriver

RuntimeDriver 的每项运行时能力都应受 Capability 约束，例如：

- `runtime.group.select`
- `runtime.connections.list`
- `runtime.connections.close`
- `runtime.logs.stream`
- `runtime.traffic.stream`
- `runtime.delay_test`
- `runtime.config_identity`

### 5.1 部分支持

如果某 Core 仅支持部分观测：

- MUST 在 Capability 中标记
- MUST 在 Query/Watch 中返回统一“部分支持”视图或可判别错误
- MUST NOT 以空数据假装“支持但当前没有内容”

---

## 6. 统一 RuntimeView

Caly 对外暴露的稳定运行时对象至少包括：

- `RuntimeStatus`
- `TrafficSample`
- `Connection`
- `ProxyDelay`
- `GroupState`
- `LogLine`
- `CoreResource`

### 6.1 `RuntimeStatus`

至少应表达：

- 当前 Core 是否 running
- active profile
- active mode / routing mode
- tun / system proxy 状态摘要
- last failure reason（若有）
- 当前 snapshot/revision 摘要

### 6.2 `TrafficSample`

至少应表达：

- up/down instant
- up/down total
- sample timestamp

### 6.3 `Connection`

至少应表达：

- connection id
- destination
- process info（若可用）
- selected chain / outbound
- matched rule（若可用）
- start time
- upload/download counters

### 6.4 `GroupState`

至少应表达：

- group id
- selected node id
- group type
- current effective member set 摘要

### 6.5 `LogLine`

至少应表达：

- level
- timestamp
- component
- redacted message

### 6.6 `CoreResource`

至少应表达：

- child cpu
- child rss
- optional file descriptor / handle count

---

## 7. 查询与订阅边界

### 7.1 Query

Runtime Query 用于：

- 一次性状态快照
- 分页连接查询
- 当前组选择态查询
- 最近日志窗口查询

### 7.2 Watch

Runtime Watch 用于：

- traffic 连续推送
- log stream
- connection diff stream
- dashboard 汇总推送

### 7.3 约束

- Query MUST 是快照式
- Watch MUST 声明流策略
- 慢客户端处理 MUST 使用 RFC-0002 中定义的 `Reset` 或丢弃策略

---

## 8. Telemetry 限流与预算

### 8.1 原则

运行时高频数据必须在源头或汇聚点受控，避免：

- UI 页面未显示仍持续高频推送
- daemon 为每个客户端单独重复拉流
- 连接列表无限增长
- 日志历史无限堆积

### 8.2 最低要求

- traffic fps MUST 有上限
- log ring MUST 有上限
- connection buffer MUST 有上限
- delay test MUST 全局限流
- 隐藏页 SHOULD 取消不必要的订阅

### 8.3 聚合策略

建议：

- traffic：可合并最新值
- logs：有界 ring + dropped count
- connections：差分更新 + Reset fallback
- group state：保留最新状态

---

## 9. Delay Test 规范

### 9.1 角色

延迟测试是 RuntimeDriver 的运行时功能，而不是前端自己发请求测试。

### 9.2 约束

- MUST 通过统一 Command 或 Runtime API 发起
- MUST 受全局并发与速率限制
- MUST 返回节点级成功/失败与时间戳
- SHOULD 允许复用缓存结果并标示其年龄

---

## 10. Connection 管理规范

### 10.1 枚举

若 Core 支持连接列表，则应提供：

- 分页查询
- 过滤
- 排序
- 关闭连接（若支持）

### 10.2 不支持时

若 Core 不支持连接管理：

- MUST 显示 Unsupported/Partial
- MUST NOT 伪造空连接列表作为“正常”结果

---

## 11. Probe 规范

ProbePlane 至少支持：

- API ready probe
- config identity probe
- inbound listening probe

更高级的 direct/proxy 网络探测 MAY 实现，但必须：

- 有明确超时
- 有明确失败分类
- 不与常规 Telemetry 混为一谈

---

## 12. 日志与脱敏

### 12.1 原则

进入 `LogLine` 前必须完成脱敏。日志脱敏不应依赖 UI 展示时再处理。

### 12.2 至少需要脱敏的内容

- URL query token
- Authorization
- 节点密码
- UUID / 密钥材料
- Core 控制 token

### 12.3 日志来源

运行时日志可来自：

- Core API
- Core stdout/stderr
- Caly 自身 tracing/logging

但 UI/CLI 看到的统一日志流，应尽量以同一 `LogLine` 结构呈现。

---

## 13. 进程与系统资源观测

### 13.1 范围

Caly 可暴露对子进程的资源观测，例如：

- CPU
- RSS
- optional fd/handle count

### 13.2 平台差异

若某平台无法稳定提供部分指标：

- MUST 在 Capability 或字段可用性上标明
- MUST NOT 用伪零值替代“不可用”

---

## 14. 测试与门禁

最低测试门槛：

1. RuntimeDriver 不支持项会显式暴露
2. traffic/log/connection 缓冲均有上限
3. 慢客户端不会导致服务端无界内存增长
4. 日志进入 RuntimeView 前已脱敏
5. delay test 受全局限流
6. config identity probe 可区分通过/失败/未知
7. LocalApi 与 RemoteApi 的 runtime DTO 行为一致

---

## 15. 冻结范围

本文冻结：

- RuntimeDriver 的职责边界
- Control / Telemetry / Probe 三平面模型
- 统一 RuntimeView 最小对象集
- 高速 Telemetry 的预算与削峰规则
- 不支持/部分支持的表达原则
- 运行时日志与连接的最小安全语义

本文不冻结具体 Core runtime trait 签名与单个 API endpoint。

---

## 16. 一句话结论

Caly 的运行时抽象必须收敛为：

> 有能力声明的控制面、有边界的观测面、可证明的探测面，而不是把不同 Core 的 API 混成一团“尽量兼容”的薄包装。