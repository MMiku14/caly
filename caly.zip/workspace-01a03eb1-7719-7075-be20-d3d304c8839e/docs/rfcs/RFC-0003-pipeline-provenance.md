# RFC-0003: Caly Pipeline / Provenance 规范

- Status: Draft
- Version: 1.0.0-draft
- Depends-On: RFC-0001
- Last-Updated: 2026-08-23

---

## 摘要

本文冻结 Caly 的纯管线规范，包括：

- Stage 模型
- Pipeline DAG
- 输入/输出分层
- CacheKey 与 Pipeline Epoch
- Diagnostics
- Provenance
- 输入边界与恶意输入防线
- 决定性编译要求
- `--explain` / `MergeReport` / `Doctor` 所依赖的解释基础设施

Caly 的中心不是“原生配置文件拼接”，而是一个**纯函数、可缓存、可解释、可验证**的配置处理内核。

---

## 1. 目标

本 RFC 旨在保证以下特性：

1. 相同输入产生相同输出。
2. 管线结果可被缓存，但缓存不改变语义。
3. 任一编译产物都可追溯其来源与覆盖过程。
4. 纯管线不依赖运行时环境状态。
5. 非法输入、恶意输入、超限输入在管线中被拒绝，而不是外溢到部署阶段。

---

## 2. 基本原则

1. 纯 Stage **MUST** 无 IO、无时钟、无随机。
2. 纯 Stage **MUST** 只依赖其输入与显式上下文。
3. 所有重要阶段 **MUST** 产出 Diagnostics。
4. 字段级来源追踪 **MUST** 为一等能力。
5. Verify 属于 IO 阶段，**MUST NOT** 混入纯 Stage。
6. `--no-cache` 与默认模式输出 **MUST** 字节一致。

---

## 3. 管线分层

Caly 配置处理分为三条管线：

| 管线 | 输入 | 输出 | 是否副作用 |
|---|---|---|---|
| P1 Ingest | URL / 文件 / Inline | `RawSource` + CAS digest | 是 |
| P2 Materialize | Revision / Profile | `Compilation` + diagnostics + `EffectPlan` | 纯（Verify 除外） |
| P3 Deploy | `EffectPlan` | Deployment result | 是 |

本文聚焦 P1/P2 的规范边界，尤其是 P2 的纯管线部分。

---

## 4. 规范化数据层次

```text
RawSource
  原始字节、哈希、来源元数据

NormalizedSource
  解析后的半结构化树，仍保留较强源格式痕迹

CalyIR
  统一领域对象图，仅保留统一语义 + extension/passthrough

UserOverride
  结构化补丁集合

ResolvedProfile
  合并、引用解析后的完整对象图

Compilation
  Lower/Emit 后的目标 Core 原生产物与元数据
```

约束：

- `RawSource -> NormalizedSource` 仍允许 source-format-aware 逻辑。
- `CalyIR` 开始进入统一语义世界。
- `ResolvedProfile` 是语义决策完成点。
- `Compilation` 是部署与 Verify 的输入。

---

## 5. Stage DAG

规范化 DAG 如下：

```text
Sources
  -> Ingest
  -> Decode
  -> Normalize
  -> Identify
  -> Merge
  -> Resolve
  -> ValidateSemantic
  -> ValidateCapability
  -> Lower
  -> Emit
  -> Compilation
  -> VerifyGate
```

### 5.1 各 Stage 说明

| Stage | 作用 |
|---|---|
| Ingest | 获取原始来源，写入 CAS，生成 `RawSource` |
| Decode | 语法解析、解压、结构化读取 |
| Normalize | 转换到源无关的半结构表示 |
| Identify | 稳定 ID 分配、对象定位、类型识别 |
| Merge | 多源 + Override + SafetyPolicy 语义合并 |
| Resolve | 引用解析、依赖关系闭包、选择记忆注入 |
| ValidateSemantic | 与目标 Core 无关的语义校验 |
| ValidateCapability | 结合 CapabilitySet 做能力校验 |
| Lower | `ResolvedProfile -> native AST` |
| Emit | `native AST -> stable bytes` |
| VerifyGate | 调真实 Core 做原生校验 |

### 5.2 VerifyGate 位置

`VerifyGate` MUST 位于纯管线之外。其结果可以被缓存，但不能把“真实二进制可用性”引入纯阶段输入。

---

## 6. Stage 接口规范

纯 Stage 的规范性接口如下：

```text
Stage {
  id: StageId,
  run(input, stage_context) -> StageResult<Output>
}
```

`StageResult` 至少包含：

- `out`：成功输出
- `diagnostics[]`
- `provenance_delta`

### 6.1 StageContext 约束

`StageContext` MAY 提供：

- pipeline constants
- capability snapshot
- deterministic feature flags
- string/path interner

`StageContext` MUST NOT 提供：

- filesystem
- network
- process launch
- current wall clock
- monotonic clock
- randomness

---

## 7. 稳定 StageId

StageId 必须稳定且可用于缓存键与 explain 输出。建议冻结以下标识：

```text
INGEST
DECODE
NORMALIZE
IDENTIFY
MERGE
RESOLVE
VALIDATE_SEMANTIC
VALIDATE_CAPABILITY
LOWER
EMIT
VERIFY_NATIVE
```

变更 StageId 语义属于兼容性事件，应同步评估 Pipeline Epoch 是否需要 bump。

---

## 8. CacheKey 与 Pipeline Epoch

### 8.1 CacheKey

Stage 级缓存键 **MUST** 至少由以下元素组成：

```text
stage_id
pipeline_epoch
adapter_version
input_digest
```

建议整体哈希为：

```text
hash(stage_id || pipeline_epoch || adapter_version || input_digest)
```

### 8.2 Pipeline Epoch

`PIPELINE_EPOCH` 表示管线级兼容纪元。出现下列变更时 **MUST** bump：

- 同一输入在新代码中应产生不同输出
- Provenance/Diagnostics 语义被有意改变且旧缓存不可复用
- Stage 语义被重定义

纯性能优化且语义不变时 SHOULD NOT bump。

### 8.3 缓存原则

- 缓存仅用于加速。
- 命中与未命中输出 MUST 完全一致。
- 缓存损坏 MUST 可通过重算恢复。
- 缓存对象可放入 CAS，索引可放入 SQLite。

---

## 9. 决定性要求

### 9.1 决定性定义

在以下固定时，输出必须字节稳定：

- 相同 `ResolvedProfile`
- 相同目标 Core Identity/Version
- 相同 Compiler/Adapter Version
- 相同 Pipeline Epoch

### 9.2 必要规则

为满足决定性，系统 MUST：

- 使用稳定排序
- 使用稳定 ID 分配
- 禁止序列化时间戳噪音
- 禁止 hash-map 无序输出泄漏到工件字节
- 对集合输出进行显式排序
- 对默认值写出策略保持一致

### 9.3 禁止项

纯管线 MUST NOT 读取：

- 当前时间
- 当前随机数
- 机器 hostname
- 临时文件路径
- 当前 PID

---

## 10. Provenance 模型

### 10.1 目的

Provenance 用于回答：

- 这个字段来自哪个 Source/Override/Default？
- 它是否覆盖了别的候选值？
- 它经历了哪些转换阶段？
- 为什么这个冲突被判定为错误？

### 10.2 最小结构

字段级 Provenance 至少应表达：

```text
field: IrPath
origin: Source | Override | Default | Safety
transform: [StageId...]
superseded: [Origin...]
```

### 10.3 IrPath 规则

`IrPath` 应为结构化路径，而非自由字符串拼接。其实现 SHOULD 支持：

- interned 段
- 前缀共享
- 稳定比较与序列化

### 10.4 按需生成

Provenance 可能较大。系统 MAY：

- 默认仅在内存中保留必要摘要
- 在 `--explain` / `doctor` / TUI explain 请求时按需重放或重建

但无论采用何种节省策略，对用户暴露的 explain 结果都必须一致。

---

## 11. Diagnostics 模型

### 11.1 分级

诊断应至少分为：

- `Error`
- `Warning`
- `Info`

### 11.2 结构

Diagnostic 应至少包含：

- code
- level
- summary
- detail?
- related_path?
- origin/provenance 摘要
- remediation?

### 11.3 阶段责任

- `Decode` 负责语法与格式错误
- `Normalize` 负责结构映射与输入限额错误
- `Merge` 负责冲突、重命名、覆盖报告
- `Resolve` 负责引用缺失与循环
- `ValidateSemantic` 负责核心无关语义约束
- `ValidateCapability` 负责目标能力不足
- `VerifyGate` 负责原生 Core 校验与兼容性失败

---

## 12. Merge 与 Resolve 规范

### 12.1 Merge 输入顺序

合并优先级冻结为：

```text
SafetyPolicy
  > RuntimeOverride
  > ProfileOverride
  > LocalInline
  > Subscription[n]
  > BuiltinDefault
```

### 12.2 Merge 产物

`Merge` 阶段除 `ResolvedProfile` 前体外，还 MUST 产出 `MergeReport`。至少含：

- rename
- drop
- override
- conflict
- source order summary

### 12.3 Resolve 责任

`Resolve` MUST 负责：

- 引用闭包计算
- group member 解析
- outbound / rule-set / dns reference 校验
- 循环依赖检测
- 必要的降级判定（如允许的 fallback）

---

## 13. Lower / Emit 规范

### 13.1 Lower

`Lower` 将 `ResolvedProfile` 映射到目标 Core native AST。此阶段：

- MAY 使用 CapabilitySet
- MUST 不执行 IO
- MUST 保持 `passthrough` / `extensions` 的目标约束

### 13.2 Emit

`Emit` 将 native AST 稳定序列化为字节：

- YAML/JSON 输出顺序 MUST 稳定
- 无关空白与风格策略 MUST 一致
- 发射器变化如果改变输出字节，应评估是否 bump adapter version 或 pipeline epoch

---

## 14. VerifyGate 规范

### 14.1 输入

VerifyGate 输入至少包括：

- 目标 Core 二进制身份/摘要
- 编译产物 digest
- 校验模式（strict / permissive）

### 14.2 结果

Verify 结果至少分为：

- Pass
- Fail
- Unknown

`Unknown` 典型来源：

- 超时
- 二进制不可执行
- API 不可用
- 环境不足以完成校验

Strict 模式下 `Unknown` MUST 阻止部署。

### 14.3 缓存键

Verify 缓存 MUST 至少包含：

```text
core_binary_sha256
artifact_digest
verify_mode
```

---

## 15. 输入边界与恶意输入防线

以下限制应内建在管线而非交由调用方自觉处理：

| 检查项 | 阶段 | 要求 |
|---|---|---|
| 原始字节大小 | Ingest | MUST 有上限 |
| 解压比例 | Decode | MUST 有上限 |
| 解压后体积 | Decode | MUST 有上限 |
| 嵌套深度 | Decode | MUST 有上限 |
| 节点数 | Normalize | MUST 有上限 |
| 规则数 | Normalize | MUST 有上限 |
| YAML 别名展开 | Decode | MUST 防递归/爆炸 |
| 正则复杂度 | Identify/Override | MUST 拒绝病态模式 |
| 引用环 | Resolve | MUST 检测并拒绝 |

所有超限输入均应返回可读 `ConfigError`，包括：

- 触发的限额名
- 实际值
- 上限值

---

## 16. Explain 能力

管线原生支持以下解释能力：

- `MergeReport`
- `PipelineExplain`
- `RouteExplain`
- `DnsExplain`
- `CapabilityExplain`

这些能力的共同基础是：

- Provenance
- Diagnostics
- 稳定 StageId
- 可重放或可按需展开的中间结果

解释能力不得依赖“反向猜测编译器做了什么”。

---

## 17. 测试与门禁

以下测试是本 RFC 的最低实现门槛：

1. 同输入重复编译字节一致
2. `--no-cache` 与命中缓存输出一致
3. 单 Override 变更只重算下游阶段
4. Provenance 中字段来源可追溯
5. passthrough 字段不丢失
6. 无 mapping 的跨 Core passthrough 编译失败
7. 超限输入在正确阶段报错
8. Verify 缓存键变更能触发重验

---

## 18. 冻结内容与后续工作

本 RFC 冻结：

- Stage DAG
- StageId 基本集合
- CacheKey 要素
- Pipeline Epoch 策略
- Provenance 最小语义
- Diagnostics 分层与阶段责任
- VerifyGate 的边界位置
- 输入边界防护责任

后续需继续细化的文件：

- `caly-pipeline/src/stage.rs`
- `caly-pipeline/src/cache_key.rs`
- `caly-pipeline/src/provenance.rs`
- `caly-pipeline/src/diagnostic.rs`
- `caly-pipeline/src/limits.rs`

---

## 19. 一句话结论

Caly 的配置处理核心必须收敛为：

> 可追溯来源、可增量缓存、可原生验证、纯函数驱动的确定性管线。

只要这个内核保持纯净，Capability、Explain、Rollback 与多 Core 支持才不会相互牵连。