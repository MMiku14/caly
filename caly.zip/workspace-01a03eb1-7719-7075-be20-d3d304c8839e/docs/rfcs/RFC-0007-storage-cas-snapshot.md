# RFC-0007: Caly Storage / CAS / Snapshot 规范

- Status: Draft
- Version: 1.0.0-draft
- Depends-On: RFC-0001, RFC-0005, RFC-0006
- Last-Updated: 2026-08-23

---

## 摘要

本文冻结 Caly 的本地存储模型，包括：

- 数据目录结构
- SQLite 与对象存储的职责分工
- CAS（Content-Addressed Storage）规则
- Revision / Snapshot / Journal 的边界
- 持久化等级与提交时机
- 垃圾回收与迁移原则

本 RFC 的核心目标是：

> 让 Caly 的本地状态既能支持低开销日常运行，也能支持部署事务、回滚、崩溃恢复和可验证迁移。

---

## 1. 目标

本文冻结：

- Caly 数据目录的逻辑布局
- 哪些内容进入 DB，哪些内容进入对象存储
- CAS 的写入、物化、校验与 GC 规则
- Revision / Snapshot / OSJournal 的持久边界
- Schema version 与迁移原则

---

## 2. 非目标

本文不冻结：

- 具体 SQL 表结构
- Secret 加密算法选择
- 单个业务对象的最终 Rust 类型
- 具体 WAL checkpoint 参数实现细节

---

## 3. 设计原则

1. 大对象 **MUST NOT** 直接塞进 SQLite。
2. 持久状态 **MUST** 可区分“索引/关系”和“内容对象”。
3. 可恢复事务边界 **MUST** 通过 Snapshot 与 Journal 明确落盘。
4. 所有工件与原文 **SHOULD** 可通过 digest 识别与去重。
5. 存储损坏或迁移失败时 **MUST** fail closed，而不是带病启动。

---

## 4. 数据目录布局

逻辑目录布局如下：

```text
$XDG_DATA_HOME/caly/
  state.db
  objects/
  cores/
  runtime/
  snapshots/
  journals/
  logs/
  secrets/          (若未使用 OS keyring 的本地回退)
```

### 4.1 职责划分

- `state.db`：索引、关系、状态、revision、job、cache 索引
- `objects/`：原始 source、规则集、编译工件、序列化中间结果
- `cores/`：已安装 Core 二进制与元数据
- `runtime/`：当前实例运行时物化文件与临时目录
- `snapshots/`：可回滚状态的元数据或引用
- `journals/`：未完成或已完成的 OS/network 副作用日志
- `logs/`：本地日志文件

---

## 5. SQLite 与对象存储分工

### 5.1 SQLite 负责

SQLite 至少存储：

- Profile / Source / Override 元信息
- 对象引用关系
- Digest 索引
- Revision 元信息
- Snapshot 索引
- Journal 索引
- Job 元信息
- Capability/memo 索引
- selection memory

### 5.2 对象存储负责

对象存储至少存储：

- 原始订阅文本或二进制内容
- 规则集原文
- 编译产物
- 稳定序列化的中间结果
- explain / report 所需大对象缓存（如采用对象化存储）

### 5.3 约束

- 大对象 MUST 以 digest 引用，不直接内联进 DB 行。
- DB 中可存 size/hash/content_type 等元数据。
- DB 中如需保存少量 JSON 摘要，应仅限索引与查询必要字段。

---

## 6. CAS 规范

### 6.1 对象身份

CAS 对象身份由内容摘要决定。建议主路径模型：

```text
objects/<algo>/<p1>/<p2>/<digest>
```

例如：

```text
objects/sha256/ab/cd/abcd...
```

### 6.2 写入规则

写入 CAS 时：

1. MUST 写入与目标同目录的临时文件
2. MUST 完成摘要校验
3. MUST 原子 rename 到目标位置
4. SHOULD 根据 durability 级别执行 fsync
5. 若对象已存在，可直接复用而不重写

### 6.3 完整性

- 对象内容与路径 digest 不匹配时 MUST 视为 `IntegrityViolation`
- 部分写、截断、损坏文件不得静默容忍

### 6.4 物化

从 CAS 到 `runtime/` 的物化可采用：

- reflink
- hardlink
- copy

具体方式由平台能力决定，但对上层必须表现为“得到可供目标消费者使用的工件副本”。

### 6.5 大对象处理

规则集、Core 下载等大对象 SHOULD 流式写入 CAS。默认不应整体读入内存。

---

## 7. Revision 规范

### 7.1 定义

Revision 表示一次可持久化的逻辑配置状态版本。它不是“某一个文件版本”，而是由以下内容共同定义：

- Profile 语义状态
- Source 引用状态
- Override 状态
- 目标 Core/Version 相关决策输入

### 7.2 Revision 要求

- Revision SHOULD 具有稳定 digest 或 semantic hash
- Query 结果可带 `revision`，用于 CAS/并发控制
- Apply 与 Rollback 应以 Revision 或 Snapshot 为边界，而不是裸文件名

---

## 8. Snapshot 规范

### 8.1 角色

Snapshot 是“已验证可回滚状态”的持久记录。它是恢复与回滚的权威依据之一。

### 8.2 最小字段

Snapshot 至少应引用或包含：

- snapshot id
- revision id / semantic digest
- compiled artifact digest
- core identity / binary digest
- apply plan 摘要
- journal reference
- selection memory
- created_at
- validation summary

### 8.3 Last Known Good

只有通过完整健康检查的部署才可写入 Last Known Good 集合。

### 8.4 保留策略

系统 SHOULD 保留最近 N 份成功 Snapshot，并支持显式清理策略。清理不得删除当前 Active 所依赖的对象。

---

## 9. OSJournal 规范

### 9.1 角色

OSJournal 用于记录系统层副作用，例如：

- system proxy
- DNS override
- TUN up/down
- route apply/restore

### 9.2 与存储的关系

Journal 记录 MUST 可在 daemon 崩溃后恢复读取。因此：

- 不得只存在内存
- 不得只作为普通日志文本
- 应具备明确状态，如 `pending` / `applied` / `reverted` / `abandoned`

### 9.3 清理规则

- 已完成且被新 Snapshot 覆盖的 Journal 可被归档或删除
- 未完成 Journal 在下次启动前 MUST 优先检查

---

## 10. 持久化等级

持久化等级与 RFC-0006 保持一致：

| 等级 | 语义 | 典型对象 |
|---|---|---|
| D0 | 可丢缓冲 | telemetry、普通日志 |
| D1 | tmp + rename | 临时生成工件 |
| D2 | 文件级耐久 | CAS 对象 |
| D3 | 文件 + DB 事务级耐久 | Journal、Revision 提交、Snapshot 提交 |

### 10.1 关键原则

- 对“将决定恢复结果”的记录，SHOULD 至少达到 D3
- 对可重建对象，可接受 D2
- 对纯观测数据，可接受 D0/D1

---

## 11. SQLite 运行纪律

SQLite 运行规则 SHOULD 包括：

- WAL 模式
- foreign keys 打开
- 单写连接串行写入
- 读连接池只读查询
- busy 重试由写队列和连接模型避免，而不是到处散落手写重试逻辑

### 11.1 禁止项

- MUST NOT 把大对象 blob 长期塞进 state.db
- MUST NOT 允许多个无序写者争用同一 DB 文件

---

## 12. Schema Version 与迁移

### 12.1 版本分离

Storage Schema Version 必须与以下版本分离：

- IR Schema Version
- API Protocol Version
- Core Compatibility Version
- Pipeline Epoch

### 12.2 迁移原则

启动时若发现 schema 版本不匹配：

1. MUST 先进行兼容性检查
2. MUST 在迁移前创建备份或可回退点
3. MUST 在迁移失败时拒绝启动
4. SHOULD 在迁移成功后执行必要一致性检查

### 12.3 向后兼容

新代码不得静默把未知旧 schema 当作当前 schema 使用。

---

## 13. GC 规范

### 13.1 Root 集

CAS 垃圾回收的 root 至少包括：

- 当前 Active Snapshot
- Last Known Good 集
- 已登记 Revision
- Journal 引用对象
- 正在执行中的 Job / EffectPlan 引用对象
- 尚在 grace period 内的新对象

### 13.2 行为规则

- GC MUST 不得删除 root 可达对象
- GC SHOULD 在 idle 且无 pending deployment 时运行
- GC 删除应先标记再清扫，必要时记录统计

---

## 14. Runtime 目录规范

`runtime/` 目录用于：

- 当前部署物化配置
- 临时 socket/pid/port metadata
- Core 实例工作目录

### 14.1 约束

- `runtime/` 不是长期真相来源
- daemon 启动恢复时 SHOULD 能基于 `state.db + snapshots + journals` 重建其含义
- 失效 runtime 目录可被清理

---

## 15. 测试与门禁

最低测试门槛：

1. CAS 对同内容去重
2. 损坏对象被识别为完整性错误
3. Snapshot 提交前崩溃不会污染 Last Known Good
4. Journal 未完成时重启可恢复
5. Schema 迁移失败会拒绝启动
6. GC 不删除被 Active/Snapshot/Journal 引用对象
7. Runtime 目录损坏时仍能从持久状态恢复

---

## 16. 冻结范围

本文冻结：

- 存储目录逻辑布局
- DB 与 CAS 的职责边界
- CAS 的身份/写入/物化/校验原则
- Revision / Snapshot / Journal 的持久角色
- Schema Version 与迁移原则
- GC 的基本 root 语义

本文暂不冻结具体 SQL 表结构与本地加密实现细节。

---

## 17. 一句话结论

Caly 的本地存储必须收敛为：

> SQLite 管关系与状态，CAS 管内容与工件，Snapshot 管回滚点，Journal 管副作用恢复。