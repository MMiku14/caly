# RFC-0005: Caly Deployment / Rollback / Recovery 规范

- Status: Draft
- Version: 1.0.0-draft
- Depends-On: RFC-0001
- Last-Updated: 2026-08-23

---

## 摘要

本文冻结 Caly 的部署与恢复主链路，包括：

- ApplyPlan
- EffectPlan
- Executor
- Core Supervisor 交互边界
- Snapshot
- OSJournal
- Health Probe
- Rollback
- Crash Recovery
- Privilege Helper 边界

本文的核心目标是保证：**任何失败的部署都不会把系统留在“看上去还活着、实际上已损坏”的中间状态。**

---

## 1. 设计目标

部署与恢复系统必须保证：

1. 失败的 Apply 不改变当前已验证运行态。
2. 所有 OS 网络副作用都可回滚。
3. Core 秒退、卡死、校验失败、健康检查失败都能统一处理。
4. 崩溃恢复后状态只能收敛到旧部署或新部署之一。
5. 权限提升边界最小化，不把整个 daemon 变成长期高权限进程。

---

## 2. 核心概念

### 2.1 ApplyPlan

`ApplyPlan` 是“从当前运行态到目标运行态”的最小安全切换策略。它回答：

- 是否无需操作
- 是否可 API patch
- 是否可 hot reload
- 是否必须 restart
- 是否必须 rebuild + restart

### 2.2 EffectPlan

`EffectPlan` 是具体副作用执行计划，描述：

- 要执行哪些步骤
- 执行顺序
- 失败时如何补偿
- 需要哪些权限
- 预期影响是什么

### 2.3 Snapshot

`Snapshot` 是经验证可作为回滚目标的持久记录。

### 2.4 OSJournal

`OSJournal` 是对系统代理、TUN、DNS、路由等副作用的可逆操作日志。

---

## 3. 生命周期与参与者

```text
Profile / Revision
   -> Pipeline / Compile
   -> ApplyPlan
   -> EffectPlan
   -> Executor
   -> Core Supervisor
   -> Platform / Privilege Helper
   -> Health Probe
   -> Commit or Rollback
```

参与者职责：

- Pipeline：产出确定性工件
- Adapter：提供原生校验与 ApplyPlan 建议
- Engine/Coordinator：编排部署事务
- Executor：执行 EffectPlan
- Supervisor：管理 Core 进程生命周期
- Platform：执行网络层副作用
- Priv Helper：执行需要特权的受限操作

---

## 4. ApplyPlan 规范

### 4.1 枚举

`ApplyPlan` 至少包含：

```text
Noop
ApiPatch
HotReload
Restart
RebuildAndRestart
```

### 4.2 选择原则

- 如果语义等价且目标状态已满足，则使用 `Noop`
- 如果仅涉及 Runtime 可安全热切换项，则优先 `ApiPatch`
- 如果 Core 支持安全重载且变更范围允许，则优先 `HotReload`
- 若 HotReload 不能证明安全，则使用 `Restart`
- 若涉及二进制变化、权限模型变化、TUN/关键 Inbound 变化，则使用 `RebuildAndRestart`

### 4.3 保守性原则

当系统无法证明较低成本路径安全时，**MUST** 升级为更保守路径，而不是冒险做热更新。

---

## 5. EffectPlan 规范

### 5.1 最小结构

`EffectPlan` 至少包括：

- `id`
- `steps[]`
- `compensations[]`
- `requires`
- `impact`

### 5.2 典型步骤集合

规范建议至少覆盖以下 EffectStep 类别：

- `WriteObject`
- `MaterializeArtifact`
- `DbTxn`
- `SpawnCore`
- `StopCore`
- `CoreApiCall`
- `NetApply`
- `NetRevert`
- `Probe`
- `MarkSnapshot`
- `CommitRevision`

### 5.3 规划要求

EffectPlan：

- MUST 在执行前完全构建
- MUST 包含逆序补偿信息
- MUST 能被 `--dry-run` 与 `--explain` 重用
- SHOULD 标明对运行流量的影响级别

---

## 6. 补偿矩阵

每个可失败步骤都应具备可定义的补偿动作。最低矩阵要求如下：

| 正向步骤 | 典型补偿 |
|---|---|
| WriteObject | 无需删除或标记可 GC |
| MaterializeArtifact | 删除未提交运行时文件 |
| DbTxn | 依赖事务回滚 |
| SpawnCore | 停止并回收该实例 |
| StopCore | 若旧实例已停且新实例失败，恢复旧版本 |
| CoreApiCall | 若为可逆操作则反向调用，否则升级为整体回滚 |
| NetApply | `NetRevert(txn)` |
| Probe | 失败触发整体回滚 |
| CommitRevision | 仅在全部成功后执行，不做提前提交 |

若某步骤无可靠补偿，则该步骤前移/后移策略必须重新设计，直到事务可推理。

---

## 7. 标准部署流程

部署流程固定为：

```text
1. begin snapshot context
2. compile deterministic artifacts
3. native validate
4. materialize runtime artifacts
5. core preflight
6. execute effect plan
7. run health probe
8. success -> commit snapshot/revision
9. failure -> rollback runtime + rollback OSJournal + mark failed
```

### 7.1 关键要求

- 提交动作 MUST 晚于健康检查成功。
- 网络副作用 MUST 进入 Journal。
- 旧的 Last Known Good 在新部署提交前 MUST 保持可恢复。

---

## 8. Snapshot 规范

### 8.1 最小字段

Snapshot 至少包括：

- snapshot id
- resolved profile digest
- compiled config digest
- core identity / binary digest
- apply plan summary
- os journal reference
- selection memory
- created_at metadata
- validation proof summary

### 8.2 Last Known Good

只有通过完整健康检查的部署才可成为 Last Known Good。

### 8.3 回滚边界

`caly rollback` 只能回滚到已验证 Snapshot。任何“构建了一半但没通过校验”的状态都不可被标记为回滚点。

---

## 9. OSJournal 规范

### 9.1 目标

OSJournal 用于纳管所有对系统网络状态的副作用，使其可恢复、可撤销、可审计。

### 9.2 Journal 动作类型

至少包括：

- `set_system_proxy`
- `clear_system_proxy`
- `set_dns`
- `restore_dns`
- `up_tun`
- `down_tun`
- `apply_route`
- `restore_route`

### 9.3 记录时机

Journal 必须在副作用真正落地前或与之原子协调的边界上写入，确保 daemon 崩溃后仍能知道如何恢复。

### 9.4 恢复顺序

恢复顺序 SHOULD 为逆序补偿，以避免资源依赖关系倒置。

---

## 10. Health Probe 规范

### 10.1 最低要求

部署完成后至少检查：

1. Core 进程仍存活
2. 控制 API Ready
3. 目标配置身份与预期工件一致
4. 关键 Inbound 正在监听
5. 必要网络路径可用（按配置）

### 10.2 非充分条件

以下任一情况都不构成成功：

- 仅进程存在
- 仅配置文件成功写入
- 仅 API 端口可连但配置未生效

### 10.3 超时

Probe 超时视为失败，不得“默认认为应该已经好了”。

---

## 11. Core Supervisor 边界

### 11.1 状态机

```text
Absent -> Installed -> Stopped <-> Starting -> Running <-> Reloading
                             \-> Failed -> Recovering -> Stopped/Running
Running -> Stopping -> Stopped
```

### 11.2 与部署链路的关系

Supervisor 负责：

- 二进制生命周期
- 子进程启动/停止/重载
- stdout/stderr 采集
- 异常退出分类
- 清理临时目录与 orphan 子进程

Coordinator 负责：

- 何时开始部署
- 是否回滚
- 是否选用不同 ApplyPlan

二者职责 MUST 分离。

---

## 12. 崩溃恢复规范

### 12.1 恢复入口

Daemon 启动时 **MUST** 优先进入恢复检查，而不是立即启动新 Core。

### 12.2 恢复步骤

建议顺序：

1. 检查未完成 Journal
2. 检查未完成 Deployment / Snapshot 标记
3. 清理孤儿 runtime 目录与临时文件
4. 修复 system proxy / DNS / TUN / route
5. 检查旧 Core 是否仍存活且身份匹配
6. 决定接管、回滚或冷启动

### 12.3 孤儿进程判断

接管旧进程时应至少校验：

- pid
- start_time
- instance_nonce

三者都匹配才可视为同一实例。

### 12.4 收敛性要求

恢复完成后状态 MUST 收敛到：

- 旧 Snapshot Active，或
- 新 Snapshot Active，或
- 明确 Failed + OS 已恢复干净

不得停留在“未知但看起来还能用”的悬空状态。

---

## 13. Privilege Helper 边界

### 13.1 原则

`calyd` 默认 MUST NOT 持续以 root/Admin 常驻。需要提升权限的动作必须下放给 Helper。

### 13.2 Helper 允许的操作

仅允许受限结构化计划，例如：

- 应用已验证的 NetworkPlan
- 回滚已登记的 NetTxn
- 启停已登记 Core 实例（若平台确需）

### 13.3 Helper 禁止项

Helper MUST NOT 接受：

- 任意 shell
- 任意文件路径
- 任意 URL
- 任意环境变量
- 任意命令行拼接

### 13.4 请求验证

Helper 请求 SHOULD 至少携带：

- request id
- daemon instance id
- signed plan
- expiry
- artifact/core digest

---

## 14. 幂等与重试

### 14.1 Apply 幂等

Apply/Rollback/Repair 等高风险命令必须具备幂等键。重复提交：

- MUST 返回原 Job
- MUST NOT 并发执行第二套部署事务

### 14.2 自动重试

自动重试只允许用于：

- 明确瞬态 IO 错误
- 可证明未产生不可逆副作用的步骤

对于已影响 OS 状态或已部分切换流量的步骤，默认不自动重试，而是进入回滚或人工确认路径。

---

## 15. 可观测性

部署系统至少应记录：

- apply plan 类型
- effect step 序列
- 当前步骤
- rollback 原因
- health probe 结果
- snapshot 提交结果
- os journal 恢复结果
- trace id / job id

这些信息必须可被：

- `caly doctor`
- TUI Diagnostics
- support bundle

读取。

---

## 16. 测试门禁

本 RFC 最低测试门槛：

1. Native validate 失败 -> 不改变 Active
2. Health probe 失败 -> 回滚成功
3. Core 秒退 -> 回滚成功
4. 任意 EffectStep 后崩溃 -> 恢复收敛
5. OSJournal 未完成 -> 启动后恢复干净
6. Privileged step 失败 -> 整体失败且可恢复
7. 幂等重发 Apply -> 不触发第二次部署
8. 慢/挂起 Core API -> 超时并回滚

---

## 17. 冻结内容与后续工作

本 RFC 冻结：

- ApplyPlan 基本级别
- EffectPlan 最小结构
- 补偿矩阵原则
- Snapshot 与 Last Known Good 语义
- OSJournal 的职责与最低动作集
- Health Probe 成功判据
- Crash Recovery 基本顺序
- Privilege Helper 的信任边界

后续实现文件建议：

- `caly-plan/src/apply_plan.rs`
- `caly-plan/src/effect.rs`
- `caly-plan/src/compensation.rs`
- `caly-engine/src/coordinator.rs`
- `caly-engine/src/recovery.rs`
- `caly-storage/src/journal.rs`
- `caly-storage/src/snapshot.rs`

---

## 18. 一句话结论

Caly 的部署系统必须收敛为：

> 先计划、后执行、全程记账、失败补偿、成功再提交、崩溃可恢复。

只有这样，Caly 才配得上“低资源但强可靠”的目标。