# RFC-0004: Caly Capability / Coverage 规范

- Status: Draft
- Version: 1.0.0-draft
- Depends-On: RFC-0001
- Last-Updated: 2026-08-23

---

## 摘要

本文冻结 Caly 的 Capability 与功能覆盖模型。其目标是把“支持 Mihomo 和 sing-box 的高级能力”从口头承诺变成可审计、可测试、可分级的正式系统。

Capability 体系回答三个问题：

1. 某个功能在给定 Core/版本/平台上是否支持？
2. 该支持属于 Caly Managed、Native Managed 还是 Opaque Preserved？
3. 这一支持结论由什么测试和证据证明？

---

## 1. 设计原则

1. 功能支持状态 **MUST** 由 Registry 推导，而不是散落在 Adapter 代码和文档中。
2. “能写进 YAML/JSON” **MUST NOT** 被视为“已支持”。
3. 所有支持声明 **SHOULD** 绑定测试证据。
4. 未知、原生独占、版本相关能力 **MUST** 有显式状态，而不是隐含成功。
5. 严格模式下，`Unknown` **MUST NOT** 部署。

---

## 2. 支持层级（Support Level）

每项功能必须归类为下列之一：

| Level | 含义 |
|---|---|
| `CalyManaged` | Caly 理解该语义，能够校验、合并、解释、跨版本维护，通常可跨 Core 处理 |
| `NativeManaged` | Caly 能在目标 Core 上保存、注入、验证和部署，但不一定完全结构化编辑 |
| `OpaquePreserved` | Caly 只承诺保真保存并在同类目标 Core 回写，不承诺跨 Core 转换 |

### 2.1 层级约束

- `CalyManaged` SHOULD 有强类型 IR 支撑。
- `NativeManaged` MAY 依赖 extension/passthrough 保持目标语义。
- `OpaquePreserved` MUST NOT 被误展示为“可跨 Core 编辑”。

---

## 3. Capability 状态（Capability State）

Capability 判定结果至少包括：

```text
SupportedExact
SupportedNativeOnly
PreservedOpaque
Experimental
Unsupported
Unknown
```

### 3.1 语义定义

- `SupportedExact`：有完整支持证据，语义明确。
- `SupportedNativeOnly`：可部署到目标 Core，但通用层理解有限。
- `PreservedOpaque`：仅保真保存与同目标回写。
- `Experimental`：存在实现但证据或稳定性不足。
- `Unsupported`：明确不支持。
- `Unknown`：信息不足，无法安全判断。

### 3.2 Strict Mode

Strict Mode 下：

- `SupportedExact`、`SupportedNativeOnly` 可以部署
- `PreservedOpaque` 仅在目标匹配且策略允许时可部署
- `Experimental` SHOULD 默认阻止，除非显式放行
- `Unknown` MUST 阻止部署
- `Unsupported` MUST 阻止部署

---

## 4. Capability Key 空间

CapabilityKey 必须稳定、可枚举、可分域。建议命名：

```text
<domain>.<feature>[.<variant>...]
```

示例：

- `proxy.vmess`
- `proxy.vless.reality`
- `proxy.shadowsocks2022`
- `outbound.wireguard`
- `group.selector`
- `group.urltest`
- `group.relay`
- `routing.process_name`
- `routing.process_path`
- `routing.rule_set.remote`
- `dns.fake_ip`
- `dns.doh`
- `dns.doq`
- `dns.dnscrypt`
- `inbound.mixed`
- `inbound.tproxy`
- `tun.auto_route`
- `tun.strict_route`
- `tun.gso`
- `runtime.connections.close`
- `runtime.group.select`

命名一旦公开，应视为稳定标识。

---

## 5. Capability Registry

### 5.1 Registry 角色

Registry 是 Capability 的唯一事实来源。Adapter、CLI、TUI、Doctor、Compiler 都应通过 Registry 查询，而不是重复编码判断逻辑。

### 5.2 最小字段

每条 CapabilityDescriptor 至少应包含：

- `key`
- `title`
- `domain`
- `support_level`
- `constraints[]`
- `fallback?`
- `evidence_ref`
- `notes[]`

### 5.3 约束维度

Capability 状态应由下列条件综合判定：

- `core_kind`
- `core_version`
- `build_tags`
- `os`
- `arch`
- `privilege_model`
- `adapter_version`
- `platform_capability`

不能把 Capability 写成“某 Core 大体支持某模块”这种粗粒度结论。

---

## 6. Coverage Matrix

### 6.1 目的

Coverage Matrix 用于回答：

- 某功能在 Mihomo 与 sing-box 上分别达到什么层级
- 哪些平台/版本组合可以声明支持
- 哪些功能需要降级、保真、或显式失败

### 6.2 结构建议

Coverage Matrix 至少表达：

- capability key
- target core
- version range
- support level
- capability state
- platform selector
- evidence references
- known limitations

### 6.3 典型使用方

- `caly doctor`
- `caly core capabilities`
- Apply 前 `ValidateCapability`
- TUI 中功能可用性提示
- 文档站自动导出支持表

---

## 7. 功能域划分

Capability 不以原生配置章节分组，而以用户感知领域分组：

- CoreLifecycle
- Profiles
- Sources
- Proxies
- ProxyGroups
- Routing
- RuleSets
- DNS
- Inbounds
- Outbounds
- TUN
- SystemProxy
- SystemDNS
- Traffic
- Connections
- Logs
- Health
- CoreUpgrade
- BackupRestore
- Automation
- Diagnostics
- Security

每个领域都应对应：

- 领域模型
- Facet
- CLI 命名空间
- TUI 页面/视图
- Capability Key 集
- 测试集

---

## 8. Fallback Policy

Capability 可以定义 `fallback`，但 fallback 必须是显式、可解释、可审计的。

允许的 fallback 示例：

- `PreserveOpaqueSameCore`
- `RequireDropFlag`
- `UseNativeOnlyMode`
- `EscalateToRestart`
- `DisableRuntimeFeature`

禁止的 fallback：

- 静默忽略字段
- 静默替换为看似相近但语义不同的功能
- 为了“尽量能跑”而绕过 ValidateCapability

---

## 9. Capability 与 IR / Passthrough 的关系

### 9.1 已知字段

已知且进入强类型 IR 的能力，优先争取 `CalyManaged` / `SupportedExact`。

### 9.2 Native 扩展

需要保留目标 Core 细节但统一层不完全理解的能力，可通过：

- `extensions`
- `passthrough`

进入 `NativeManaged` 或 `OpaquePreserved`。

### 9.3 跨 Core 编译

若能力仅在源 Core 可表达且无显式 mapping，则跨 Core 编译 MUST 失败，而不是部分丢弃。

---

## 10. Capability 证据模型

### 10.1 Evidence 结构

每条能力的支持声明 SHOULD 绑定证据：

- compile fixture
- native validation test
- runtime integration test
- supported version range
- platform selectors
- known limitations

### 10.2 `SupportedExact` 最低门槛

一个能力只有在满足以下多数或全部条件时，才应标记为 `SupportedExact`：

1. 有标准输入 fixture
2. 有 IR -> native golden
3. 有真实 Core 原生校验
4. 有运行时功能验证（若适用）
5. 有不支持场景的失败测试

### 10.3 `Experimental`

`Experimental` 必须说明：

- 缺失哪类证据
- 已知风险
- 平台/版本边界
- 是否默认关闭

---

## 11. Capability 在编译链中的位置

Capability 体系至少参与以下阶段：

1. `ValidateCapability`
2. `Lower`
3. `Emit`（必要时）
4. `ApplyPlan` 选择
5. Runtime view 能力暴露
6. Doctor / Explain

### 11.1 编译行为要求

- `Unsupported` MUST 失败
- `Unknown` 在 Strict 下 MUST 失败
- `SupportedNativeOnly` MAY 继续，但需提示能力受限
- `PreservedOpaque` 仅在目标一致且策略允许时可继续

---

## 12. 平台 Capability

平台能力必须与 Core 能力共用统一视图，而不是另起一套不可比较的状态机。

典型平台能力：

- `platform.system_proxy`
- `platform.system_dns`
- `platform.tun`
- `platform.process_info`
- `platform.autostart`
- `platform.keyring`

示例：

- `routing.process_name` 可能取决于 Core 支持 + OS process info 支持
- `tun.gso` 可能取决于 sing-box 版本 + Linux 内核能力 + 权限模型

---

## 13. UI 与 CLI 呈现原则

CLI/TUI/Doctor 对 Capability 的展示 **MUST** 使用统一语义：

- 显示状态
- 显示 support level
- 显示失败原因或限制条件
- 显示来源证据摘要（至少测试/版本/平台）
- 必要时给出 remediation

不得在 UI 层自行推断“看起来应该支持”。

---

## 14. 测试门禁

Capability 体系最低门禁：

1. Registry 中所有 key 可解析且唯一
2. Coverage Matrix 可由机器读取并生成报表
3. `SupportedExact` 项目必须有关联证据
4. 版本边界测试可触发支持/不支持切换
5. 跨 Core 无映射能力编译失败
6. Passthrough 同 Core 回写成功
7. Doctor/CLI/TUI 对同一能力显示一致结论

---

## 15. Registry 维护规则

新增 capability 时：

1. 分配稳定 key
2. 指定领域 domain
3. 标记 support level
4. 添加约束条件
5. 填写 fallback
6. 绑定 evidence
7. 更新 coverage matrix
8. 补充测试

删除或改名 capability key 视为兼容性事件，必须显式迁移并更新相关 Schema/RFC。

---

## 16. 冻结内容与后续工作

本 RFC 冻结：

- Support Level 三分模型
- Capability State 六分模型
- CapabilityKey 命名规则
- Registry 是唯一事实来源
- Evidence 绑定原则
- Coverage Matrix 的职责
- Strict Mode 的行为边界
- Fallback 的合法范围

后续实现文件建议：

- `caly-cap/capability-registry.json`
- `caly-cap/coverage-matrix.json`
- `caly-cap/src/eval.rs`
- `caly-cap/src/evidence.rs`
- `caly-cap/src/fallback.rs`

---

## 17. 一句话结论

Caly 对“功能支持”的承诺必须收敛为：

> 注册表可查、版本/平台可判、证据可审、失败可解释、降级可控。

只有这样，“支持 Mihomo 与 sing-box 高级功能”才是工程事实，而不是文案表述。