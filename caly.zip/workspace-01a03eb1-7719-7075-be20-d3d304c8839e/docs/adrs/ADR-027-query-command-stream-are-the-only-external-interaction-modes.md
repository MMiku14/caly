# ADR-027: Query / Command / Stream 是唯一三类对外交互语义

- Status: Accepted
- Date: 2026-08-23
- Decision-Makers: Caly Architecture
- Related-RFCs: RFC-0002
- Supersedes: None

---

## 1. Context

Caly 面向 CLI/TUI/automation/exported tooling 提供多种交互：

- 查询状态
- 修改配置
- 订阅日志/流量/连接
- 观察长任务进度

如果不先冻结这些交互的语义类别，接口会逐渐混乱：

1. 某些“查询”可能偷偷触发变更或缓存写入。
2. 某些“命令”可能阻塞很久，却又不暴露 Job 语义。
3. 某些“订阅”既不像快照也不像流，前端只能猜测怎么处理。
4. 不同模块会发明自己的调用模式，增加认知负担。

Caly 需要一套足够简单、但能覆盖所有对外交互的统一分类。

---

## 2. Decision

Caly 采纳以下决策：

1. **对外交互只允许三种模式：**
   - `Query`
   - `Command`
   - `Stream`
2. `Query` 表示：
   - 只读
   - 快照式
   - 无持久副作用
3. `Command` 表示：
   - 可能修改状态或触发副作用
   - 返回 `Accepted` / Job 追踪语义
4. `Stream` 表示：
   - 持续订阅某类更新
   - 拥有明确流策略与 Reset 语义
5. 新增对外能力时，必须首先归类为三者之一，而不是发明第四种隐含模式。

---

## 3. Alternatives Considered

### 方案 A：不做固定分类，按方法名字和文档说明区分

- 优点：
  - 最灵活
- 缺点：
  - 语义不稳定
  - 客户端实现难以统一
- 不采纳原因：
  - 不适合长期协议演进

### 方案 B：只有同步 RPC 与流，没有独立 Command/Job 语义

- 优点：
  - 概念少
- 缺点：
  - 长操作表达差
  - 幂等、进度、恢复语义缺失
- 不采纳原因：
  - 与部署事务模型不兼容

### 方案 C：按资源类别划分大量操作模式

- 优点：
  - 更细
- 缺点：
  - 外部认知成本高
  - 难以形成统一调度与文档结构
- 不采纳原因：
  - 复杂度收益比过低

---

## 4. Consequences

### Positive

- 外部 API 心智模型清晰
- Local/Remote 更容易保持一致
- 权限、超时、幂等、分页、Reset 等规则可按模式复用
- 文档、Schema 与代码生成更容易组织

### Negative / Trade-offs

- 某些边界案例需要强制归类
- 需要防止实现者给 Query 偷塞副作用
- 某些短命令也要接受 Job 语义约束

### Follow-up Work

- 为所有 Operation 标注 mode
- 在测试中检查 Query 是否保持只读语义
- 为 Command/Stream 构建统一客户端辅助逻辑

---

## 5. Compatibility and Migration

这三类模式构成对外协议的顶层分类。

未来若想引入“第四类模式”，应默认视为架构异常，除非能证明 Query/Command/Stream 不能覆盖其需求，并需通过 RFC 重新论证。

---

## 6. Notes

本 ADR 支撑：

- RFC-0002 中 Query / Command / Stream 的顶层分类
- Job、分页、Watch、Reset 等规则按模式归属的设计

一句话总结：

> 外部接口可以很多，但语义模式只能很少；越少，越稳定，越可维护。