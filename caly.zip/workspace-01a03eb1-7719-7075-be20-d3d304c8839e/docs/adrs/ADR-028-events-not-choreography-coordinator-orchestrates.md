# ADR-028: Event 只用于通知；显式 Coordinator 负责状态变更编排

- Status: Accepted
- Date: 2026-08-23
- Decision-Makers: Caly Architecture
- Related-RFCs: RFC-0001, RFC-0002, RFC-0005
- Supersedes: None

---

## 1. Context

Caly 的核心链路涉及多种高风险状态变化：

- source 更新
- profile 变更
- merge / compile
- apply / rollback
- core start / stop / restart
- system proxy / TUN / DNS 变更
- health probe 与 recovery

在这类系统中，最容易失控的一种模式是“事件编排”（event choreography）：

```text
SourceUpdated
  -> 某服务收到后改 DB
  -> 另一个服务收到后自动编译
  -> 第三个服务收到后改系统代理
  -> 第四个服务收到后写 UI 状态
```

这种模式短期灵活，但会迅速带来问题：

1. 真正的事务边界隐藏在事件链中，难以推理。
2. 部署顺序分散在多个订阅者里，失败补偿困难。
3. 多事件竞争时很难保证资源锁与先后顺序。
4. “谁负责决定是否 apply”变得不清晰。
5. 代码阅读时很难看出一次命令最终会触发哪些副作用。

Caly 已经明确要求：

- 所有 mutation 进入 Command
- 写路径需要串行化
- 部署必须有补偿与 rollback

这些要求都与“隐式事件编排”天然冲突。

---

## 2. Decision

Caly 采纳以下决策：

1. **Event 仅用于通知，不用于隐藏业务编排。**
2. 所有跨模块的关键状态变更，必须由显式 Coordinator / Engine 驱动。
3. 典型流程是：

```text
Command
  -> Coordinator
  -> 显式步骤调用
  -> 成功/失败判定
  -> 必要补偿或回滚
  -> 最后发出 Event
```

4. Event 可用于：
   - UI 更新
   - 诊断与监控
   - 审计流
   - 非关键派生视图刷新
5. Event 不应用于：
   - 触发新的关键部署决策
   - 隐式追加系统副作用
   - 绕开命令锁与事务边界

---

## 3. Alternatives Considered

### 方案 A：广泛采用事件驱动编排，模块各自订阅与反应

- 优点：
  - 模块解耦表面上更强
  - 扩展看似方便
- 缺点：
  - 真正控制流被分散
  - 事务边界不可见
  - 失败补偿复杂
- 不采纳原因：
  - 不适合需要 rollback 与恢复语义的控制平面

### 方案 B：所有逻辑都写进单个巨大 service，不发事件

- 优点：
  - 控制流清晰
- 缺点：
  - 容易变成 God Service
  - UI 与观测难以订阅状态变化
- 不采纳原因：
  - 需要编排中心，但不需要放弃事件通知机制

### 方案 C：事件仅用于某些“安全”的自动流程，其余仍由 coordinator 管理

- 优点：
  - 似乎更灵活
- 缺点：
  - “哪些算安全”边界会逐渐滑坡
  - 系统最终仍可能回到隐式编排
- 不采纳原因：
  - 对 Caly 这种高风险副作用系统，不应留下模糊地带

---

## 4. Consequences

### Positive

- 状态变更路径更可推理
- 回滚与补偿更容易集中实现
- 并发控制与锁域管理更清晰
- UI 仍可通过 Event 获得低耦合通知
- Support bundle / doctor 更容易还原命令链路

### Negative / Trade-offs

- 需要维护 Coordinator 层
- 某些开发者会觉得“事件触发下一步”更方便，但被明确禁止
- 模块间扩展需要更多显式 API，而不是偷懒靠广播

### Follow-up Work

- 冻结 Command -> Coordinator -> Event 的标准流程
- 为自动化规则明确“动作再次进入 Command 管线”的要求
- 在代码审查中把“事件触发关键副作用”视为架构违规模式

---

## 5. Compatibility and Migration

该 ADR 是内部控制流设计原则，不直接影响外部协议，但会强烈影响实现结构。

未来若引入新模块或自动化子系统，应首先回答：

- 它是产生通知，还是承担编排？
- 如果承担编排，它是否应进入 Coordinator，而不是订阅某个 Event 后私自行动？

---

## 6. Notes

本 ADR 支撑：

- RFC-0001 中的 Command / serialized mutation / Event 模型
- RFC-0002 中 Job 与 Watch 的分工
- RFC-0005 中部署与恢复需要显式补偿链路的要求

一句话总结：

> Event 可以广播结果，但不能偷偷决定结果；真正的状态变化必须由显式编排器负责。