# ADR-011: 纯内核 / 效果描述 / 单一 IO 网关

- Status: Accepted
- Date: 2026-08-23
- Decision-Makers: Caly Architecture
- Related-RFCs: RFC-0001, RFC-0003, RFC-0005, RFC-0006
- Supersedes: None

---

## 1. Context

Caly 的核心目标包含四个彼此高度耦合的要求：

- 低资源常驻
- 确定性编译
- 失败可回滚
- 崩溃可恢复

如果文件系统、网络、数据库、进程、时钟、随机数可以在任意 crate、任意 service、任意 helper 中直接出现，那么上述目标会迅速失去可验证性：

1. **确定性无法证明**：编译代码可能偷偷读取时间、路径、随机数、机器状态。
2. **恢复边界无法收敛**：副作用散落在各处，无法统一记账和补偿。
3. **低资源目标无法审计**：任何模块都可能自行轮询、起阻塞线程、直接发网络请求。
4. **测试无法仿真**：如果 IO 不被收口，就无法用 `caly-io-sim` 替换整个外部世界。
5. **前后期重构成本极高**：一旦 Adapter、Engine、Storage、CLI/TUI 都直接操作 IO，后续再收口几乎等于重写。

在早期设计演进中，已经明确 Caly 不能只是“若干 service + 若干 util”的普通工程结构，而必须让“纯语义内核”和“副作用执行”彻底分离。

---

## 2. Decision

Caly 采纳以下架构决策：

1. **Pure Core**：
   `caly-domain`、`caly-ir`、`caly-pipeline`、`caly-cap`、`caly-plan` 组成纯内核层。该层：
   - 不直接访问文件系统、网络、数据库、进程、时钟、随机数
   - 不包含隐式环境依赖
   - 以确定性函数和显式输入输出为边界

2. **Effect Description**：
   纯内核不能执行副作用，但必须能产出副作用描述，即 `EffectPlan` / `EffectStep`。这样部署、dry-run、explain、仿真测试共享同一计划对象。

3. **Single IO Gateway**：
   所有外部世界交互都必须通过 `caly-io` 中定义的 Port 完成，由 `caly-io-std`、`caly-io-sim` 等实现提供具体行为。

4. **Executor Monopoly**：
   只有执行器（通常位于 `caly-engine`）可以把 `EffectStep` 变成真实副作用。其他层只能“描述需要做什么”，不能自行“顺手做掉”。

5. **Mechanical Enforcement**：
   上述边界不是风格建议，而是工程约束。必须通过依赖图检查、clippy disallow list、crate 层 forbid 配置等方式强制执行。

---

## 3. Alternatives Considered

### 方案 A：允许 Engine/Adapter 直接做 IO，只要求“尽量克制”

- 优点：
  - 早期实现更快
  - 写起来更接近普通应用架构
- 缺点：
  - 边界退化成口头约定
  - 难以证明纯度与决定性
  - 难以做统一超时、取消、预算与错误模型
- 不采纳原因：
  - 与 Caly 的可验证性目标冲突

### 方案 B：只把部分 IO 包进工具函数，不建立完整 Port 层

- 优点：
  - 代码量较少
  - 对调用点侵入性看似更低
- 缺点：
  - 仍然无法形成统一语义边界
  - 调用方仍可能绕过工具函数直接访问底层库
  - 仿真实现与真实实现无法共享统一契约
- 不采纳原因：
  - 不能真正提供可替换性与可测试性

### 方案 C：所有逻辑都做成 Actor/Service，IO 是否直接调用无所谓

- 优点：
  - 服务边界清晰
  - 并发模型容易想象
- 缺点：
  - Service 化不等于纯度
  - 仍无法阻止时间、随机数、磁盘访问渗透到业务语义层
- 不采纳原因：
  - 解决的是编排问题，不是副作用隔离问题

---

## 4. Consequences

### Positive

- 决定性编译更容易证明
- 副作用统一进入可补偿执行器
- `dry-run`、`explain`、真实部署、仿真测试共享同一计划模型
- `caly-io-sim` 成为可行的、系统级测试工具
- 前端、适配器、平台层职责边界更清晰

### Negative / Trade-offs

- 初期抽象成本更高
- 需要维护 Port trait、标准实现与仿真实现三套心智模型
- 对“快速写一个能跑 demo”的节奏有约束
- 开发者需要适应“先描述效果，再执行效果”的风格

### Follow-up Work

- 在 `caly-io` 中冻结 Port trait 与 `IoFault`
- 在 `caly-plan` 中冻结 `EffectPlan` / `EffectStep`
- 在 `caly-arch-test` 中增加依赖白名单测试
- 在 clippy 配置中加入禁止调用列表

---

## 5. Compatibility and Migration

这是 Caly 的基线架构决策，不涉及向后兼容旧实现的迁移。

若未来某模块需要直接访问 IO，则应视为对 RFC-0001 / RFC-0006 的破坏性偏离，必须先修改对应 RFC 与本 ADR，而不能以“实现方便”为理由绕过。

---

## 6. Notes

本 ADR 是以下规范的背景依据：

- RFC-0001 中的分层与依赖法则
- RFC-0003 中纯管线与 VerifyGate 的边界
- RFC-0005 中 EffectPlan/Executor 的事务模型
- RFC-0006 中统一 Port/IoFault 规范

一句话总结：

> Caly 的正确性来自“纯语义内核 + 显式效果计划 + 单一 IO 网关”，而不是来自开发者对副作用的自律。