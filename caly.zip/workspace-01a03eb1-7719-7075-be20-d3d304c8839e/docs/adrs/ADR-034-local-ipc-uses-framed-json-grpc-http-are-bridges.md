# ADR-034: 本地 IPC 采用 framed JSON over UDS / Named Pipe；gRPC 与 HTTP 作为未来桥接层

- Status: Accepted
- Date: 2026-08-23
- Decision-Makers: Caly Architecture
- Related-RFCs: RFC-0002
- Supersedes: None

---

## 1. Context

Caly 需要一个长期稳定的本地控制面协议，用于：

- CLI ↔ daemon
- TUI ↔ daemon
- LocalApi / RemoteApi 语义对齐
- Job follow / watch / replay / reset
- 本机权限边界与单用户场景

候选方向主要有三种：

1. gRPC
2. HTTP + JSON
3. 自定义长度前缀 JSON 帧协议

直觉上，gRPC 或 HTTP 看起来“更标准”，但 Caly 当前的主要场景不是：

- 多语言远程服务网格
- 浏览器优先 Web API
- 跨网络企业级服务互调

而是：

- 本机 daemon 控制面
- UDS / Named Pipe
- 低开销
- 强状态同步与 replay/reset
- Query / Command / Stream 三分语义

因此，需要一个更贴合本地语义、并且不把额外协议栈复杂度过早引入核心路径的方案。

---

## 2. Decision

Caly 采纳以下决策：

1. **Caly v1 的核心本地 IPC 使用长度前缀 framed JSON 协议。**
2. 传输层为：
   - Unix Domain Socket（Unix）
   - Named Pipe（Windows）
3. 默认 payload 编码为 JSON。
4. Query / Command / Stream 的语义由 Caly 自身协议定义，而不是交给 HTTP 或 gRPC 语义层隐含表达。
5. **gRPC 不作为 v1 核心本地 IPC。**
6. **HTTP + JSON 也不作为 v1 核心本地 IPC。**
7. 如果未来需要远程集成、多语言 SDK 或调试桥接，可在核心协议之外增加：
   - HTTP/JSON bridge
   - gRPC bridge

---

## 3. Alternatives Considered

### 方案 A：gRPC 作为核心本地 IPC

- 优点：
  - protobuf schema 明确
  - 多语言生态好
  - streaming 成熟
- 缺点：
  - 引入第二套 schema / codegen / 映射层
  - 对 Windows Named Pipe 和本地权限边界不够自然
  - 并不会自动解决 replay/reset/watch 语义
- 不采纳原因：
  - 对 Caly v1 的本地控制面来说复杂度高于收益

### 方案 B：HTTP + JSON 作为核心本地 IPC

- 优点：
  - 易调试
  - 工具成熟
  - Query/Command 表面自然
- 缺点：
  - 对本地 IPC 场景语义层偏重
  - Stream 需要再选 SSE/WebSocket/long-poll 等方案
  - Named Pipe 场景不优雅
- 不采纳原因：
  - 对 Caly 当前问题空间不是最贴合的基础协议壳

### 方案 C：framed JSON 作为核心本地 IPC

- 优点：
  - 最贴合 UDS / Named Pipe 场景
  - 最容易围绕 Query/Command/Stream/replay/reset 设计
  - 调试友好，早期演进成本低
- 缺点：
  - 需要自己定义更多协议细节
  - 多语言生态不如 gRPC
- 采纳原因：
  - 最符合 Caly v1 的 low-overhead、本地控制面与可恢复目标

---

## 4. Consequences

### Positive

- 核心协议能更贴合本地控制面需求
- replay / reset / watch / idempotency 等语义更容易精确定义
- 调试和演进成本更低
- 不会过早引入额外协议栈复杂度

### Negative / Trade-offs

- 协议细节需要自行维护
- 若未来要对外开放多语言生态，需要额外 bridge 层
- 必须用 RFC/analysis/policy 约束避免自定义协议失控

### Follow-up Work

- 完善 `policy` / `negotiate` / `session` skeleton
- 继续细化 stream delivery / ack / reset 规则
- 为未来 bridge 保留稳定 Operation/DTO 层

---

## 5. Compatibility and Migration

该 ADR 固定的是 **核心本地 IPC 的方向**。

未来如果引入 HTTP/gRPC，也应视为：

- 新增桥接层
- 而不是替换核心本地协议层

除非 Caly 的产品定位发生根本变化，否则不应轻易推翻该决策。

---

## 6. Notes

本 ADR 与以下文档共同构成该决策的说明基础：

- `docs/IPC_PROTOCOL_ANALYSIS.md`
- `docs/IPC_TRANSPORT_DECISION.md`
- `docs/IPC_SESSION_MODEL.md`

一句话总结：

> Caly v1 先把本地 framed JSON 协议做对，再考虑 HTTP/gRPC bridge；不要反过来让桥接层塑造核心本地协议。