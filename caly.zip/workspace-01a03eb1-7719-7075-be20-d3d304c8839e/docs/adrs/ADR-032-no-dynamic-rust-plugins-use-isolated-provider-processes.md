# ADR-032: 不加载动态 Rust 插件；未来扩展优先采用隔离 Provider Process

- Status: Accepted
- Date: 2026-08-23
- Decision-Makers: Caly Architecture
- Related-RFCs: RFC-0001, RFC-0010
- Supersedes: None

---

## 1. Context

随着 Caly 能力扩展，自然会出现“第三方扩展/插件”的需求，例如：

- 自定义 source provider
- 特殊订阅格式转换器
- 实验性 capability 探测
- 定制化导出或诊断扩展

最直接的方案似乎是：

- 在主进程里 `dlopen`/`libloading` 动态加载 Rust `.so/.dll`

但这种方案会带来长期问题：

1. Rust ABI 不稳定，版本兼容难以保证。
2. 动态库可直接共享进程内存和权限边界，安全隔离差。
3. 一旦插件崩溃或死锁，主进程稳定性直接受损。
4. 复现、调试、跨平台打包与签名都更复杂。
5. 与 Caly 强调的最小权限、可恢复和可观测目标不一致。

如果未来要留扩展口，扩展必须在失败隔离、资源约束和版本协商上更可控。

---

## 2. Decision

Caly 采纳以下决策：

1. **v1 不支持动态 Rust 插件加载。**
2. 如未来需要扩展能力，优先采用 **隔离 Provider Process** 模型，而不是进程内动态库。
3. Provider Process 应通过受限协议与主进程通信，至少应具备：
   - capability declaration
   - version negotiation
   - timeout
   - resource budget
   - sandbox / isolation 可能性
4. 主进程不得把任意内部对象或权限直接暴露给扩展。

---

## 3. Alternatives Considered

### 方案 A：直接支持动态 Rust 插件

- 优点：
  - 扩展开发体验好
  - 共享内存、调用开销低
- 缺点：
  - ABI 不稳定
  - 安全边界差
  - 进程稳定性受插件拖累
- 不采纳原因：
  - 与 Caly 的可靠性/安全目标冲突

### 方案 B：完全不预留扩展路径

- 优点：
  - 系统更简单
- 缺点：
  - 未来功能扩展压力会全部压回主仓库
- 不采纳原因：
  - 需要保留长期扩展方向，只是不采用进程内插件

### 方案 C：使用脚本扩展替代插件

- 优点：
  - 开发门槛低
- 缺点：
  - 仍有安全和语义漂移问题
  - 不适合作为系统级扩展边界
- 不采纳原因：
  - 不优于受限 provider process

---

## 4. Consequences

### Positive

- 主进程稳定性更高
- 权限与资源边界更容易控制
- 版本协商与兼容管理更清晰
- 更利于未来第三方扩展的可审计性

### Negative / Trade-offs

- 扩展开发体验不如进程内插件直接
- 协议与子进程管理会增加复杂度
- 某些高性能共享内存场景不易直接实现

### Follow-up Work

- 若未来进入 v2/vNext，定义 provider protocol RFC
- 明确可扩展领域清单，避免过早泛化插件体系
- 在安全文档中补充 provider process 的资源与权限模型

---

## 5. Compatibility and Migration

该 ADR 明确了 v1 的“不支持动态插件”边界。

未来若新增 provider process 扩展机制，应作为新增能力引入，而不是向后兼容某种进程内插件 ABI。

---

## 6. Notes

本 ADR 支撑：

- RFC-0001 中“不加载动态 Rust 插件”的非目标
- RFC-0010 中最小权限、隔离与受限输入边界的安全原则

一句话总结：

> 需要扩展，不等于要把不受控代码装进主进程。