# ADR-016: VerifyGate 属于 IO 阶段，并按二进制摘要缓存结果

- Status: Accepted
- Date: 2026-08-23
- Decision-Makers: Caly Architecture
- Related-RFCs: RFC-0003, RFC-0006
- Supersedes: None

---

## 1. Context

Caly 的编译链路既要保持纯函数特性，又必须对目标 Core 的原生配置进行真实校验。

这里存在天然张力：

- 一方面，`Lower` / `Emit` 必须保持无 IO、可缓存、可重放、可确定性测试。
- 另一方面，真正验证“这份产物是否被 Mihomo/sing-box 接受”必须依赖：
  - 真实二进制
  - 真实进程启动或原生校验入口
  - IO、超时、环境状态

如果把原生校验混入纯管线，会产生问题：

1. 纯管线不再纯，决定性边界被打破。
2. 缓存键会隐式依赖机器环境，却没有显式建模。
3. `--no-cache` 与缓存命中结果更难证明一致。
4. 单元测试与仿真测试无法可靠替换真实验证行为。
5. 编译失败到底是“语义错误”还是“目标二进制不接受”会变得模糊。

因此，原生校验必须被视为纯管线之后的独立阶段，而不是编译器内部偷偷做的副作用。

---

## 2. Decision

Caly 采纳以下决策：

1. **原生验证步骤命名为 `VerifyGate`，并明确属于 IO 阶段。**
2. `VerifyGate` 位于：

```text
Pure Pipeline (Lower -> Emit -> Compilation)
  -> VerifyGate
```

3. `VerifyGate` 的输入至少包括：
   - 目标 Core 二进制身份
   - Core 二进制摘要
   - 编译产物摘要
   - 验证模式（如 strict / permissive）
4. `VerifyGate` 的结果 **按 `(core_binary_digest, artifact_digest, verify_mode)` 缓存**。
5. 校验结果至少分为：
   - `Pass`
   - `Fail`
   - `Unknown`
6. 超时、环境不足、校验入口不可用等情况不得伪装成通过，应返回 `Unknown` 或明确失败。

---

## 3. Alternatives Considered

### 方案 A：把 Verify 混入编译器内部，作为 `compile()` 的一部分

- 优点：
  - 调用路径看起来更短
  - “编译成功”似乎更完整
- 缺点：
  - 纯/IO 边界混淆
  - 编译缓存语义被污染
  - 单元测试与仿真测试变重
- 不采纳原因：
  - 破坏 RFC-0003 的纯管线原则

### 方案 B：完全不做真实二进制校验，只依赖 emit 成功

- 优点：
  - 速度快
  - 实现简单
- 缺点：
  - “支持”承诺失真
  - 很多 native incompatibility 只能在部署后暴露
- 不采纳原因：
  - 不符合 Caly 的可靠性与证据要求

### 方案 C：每次都重新验证，不做缓存

- 优点：
  - 语义简单
- 缺点：
  - 重复代价高
  - 同一二进制 + 同一产物会重复支付启动/校验成本
- 不采纳原因：
  - 与低开销和增量目标冲突

---

## 4. Consequences

### Positive

- 纯管线与真实验证边界清晰
- 缓存语义可推理且可测试
- `Pass/Fail/Unknown` 区分更明确
- 真核验证可以纳入 CI 与 Capability 证据体系
- 同一二进制/产物组合避免重复校验

### Negative / Trade-offs

- 需要维护独立的 Verify 缓存索引
- 某些平台/环境下 `Unknown` 结果会增加状态复杂度
- 编译成功但 Verify 未通过的两阶段语义需要前端正确展示

### Follow-up Work

- 在 `caly-pipeline` 或相邻模块中明确 `VerifyGate` DTO
- 建立 verify cache 存储规则
- 在 Strict Mode 中定义 `Unknown` 的阻断策略

---

## 5. Compatibility and Migration

若未来改变 Verify 输入、模式语义或结果语义，应同步评估 verify cache key 是否需要调整。

若旧缓存不再可信，应通过版本字段或 schema 迁移使其失效，而不是继续混用。

---

## 6. Notes

本 ADR 支撑：

- RFC-0003 中 VerifyGate 位于纯管线外的设计
- RFC-0006 中 IO 与超时/取消语义的统一要求

一句话总结：

> 原生验证是真实世界检查，不是纯编译的一部分；它必须单独建模，并按二进制与产物摘要缓存。