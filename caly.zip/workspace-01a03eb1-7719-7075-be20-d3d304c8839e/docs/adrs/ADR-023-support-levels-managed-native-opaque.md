# ADR-023: 功能支持分为 CalyManaged / NativeManaged / OpaquePreserved

- Status: Accepted
- Date: 2026-08-23
- Decision-Makers: Caly Architecture
- Related-RFCs: RFC-0001, RFC-0004, RFC-0009
- Supersedes: None

---

## 1. Context

Caly 的定位之一，是“统一管理 Mihomo 与 sing-box”。但这种“统一”很容易被误解成：

- 做一份看起来通用的大配置格式
- 只要字段能写进目标 YAML/JSON，就算支持
- 即便不理解语义，只要不报错就宣称兼容

这种做法在早期也许显得灵活，但会迅速带来承诺失真：

1. 用户会以为某功能可以跨 Core 迁移、编辑、解释，实际上并不能。
2. UI/CLI 容易错误展示“已支持”。
3. Unknown/native-only 字段在迁移时容易被误丢或误改。
4. 测试难以判断“支持”的真正含义。

Caly 需要一种比“支持/不支持”更细的语言，来表达自己到底掌握了多少语义。

---

## 2. Decision

Caly 采纳三层支持级别模型：

1. **`CalyManaged`**
   - Caly 理解该功能的统一语义
   - 能进行校验、合并、解释、编译
   - 通常可在多版本或跨 Core 场景下受控演进

2. **`NativeManaged`**
   - Caly 能在目标 Core 上保存、注入、验证与部署该功能
   - 但不一定完整理解其内部每个字段，也不承诺统一 UI 编辑能力

3. **`OpaquePreserved`**
   - Caly 仅承诺保真保存并在同目标 Core 回写
   - 不承诺跨 Core 转换、结构化编辑、统一解释

并进一步作出以下决策：

- 对外不得笼统宣称“已支持”，必须带上支持层级或等价解释。
- `OpaquePreserved` 不得被前端误展示成“可以自由编辑/迁移”的能力。
- 跨 Core 编译遇到仅 `OpaquePreserved` 且无映射的能力时，默认失败。

---

## 3. Alternatives Considered

### 方案 A：只有 Supported / Unsupported 二分法

- 优点：
  - 概念少
  - UI 展示简单
- 缺点：
  - 无法表达“可保真但不可统一理解”的中间地带
  - 容易夸大 Caly 对目标能力的掌控程度
- 不采纳原因：
  - 对复杂配置生态过于粗糙

### 方案 B：所有能力一律进入统一强类型 IR

- 优点：
  - 理论上最一致
- 缺点：
  - 现实上难以覆盖目标 Core 的所有独占能力
  - 过早强建模会导致大量错误抽象
- 不采纳原因：
  - 不符合“保真优先、统一建模逐步扩展”的策略

### 方案 C：只要能 passthrough 就都算支持

- 优点：
  - 短期最容易扩大“支持范围”
- 缺点：
  - 支持承诺失真
  - 迁移和编辑风险极高
- 不采纳原因：
  - 这是文案上的支持，不是工程上的支持

---

## 4. Consequences

### Positive

- 对“支持”给出更精确、诚实的定义
- 可逐步提升某功能从 Opaque -> Native -> CalyManaged 的成熟度
- UI/CLI/Doctor 更容易正确展示限制条件
- 测试证据可与支持级别绑定

### Negative / Trade-offs

- 文档和 Capability 展示会更复杂
- 用户需要理解不同支持层级的差异
- 实现方需要为同一功能维护更多元信息

### Follow-up Work

- 在 Capability Registry 中增加 support level 字段
- 在 CLI/TUI capability 展示中显示层级说明
- 为 Patch/Override 行为增加对不同支持层级的限制

---

## 5. Compatibility and Migration

这项决策改变的是“如何定义支持”，不是具体协议字段。

未来若某功能的实现成熟度提升，可从 `OpaquePreserved` 提升到 `NativeManaged` 或 `CalyManaged`；反之若发现原承诺过度，也必须允许降级并明确告知，而不能保持模糊支持说法。

---

## 6. Notes

本 ADR 支撑：

- RFC-0004 中的 Support Level 模型
- RFC-0009 中 Native Patch / Passthrough 的边界
- RFC-0001 中“未知字段保真但不伪统一”的整体原则

一句话总结：

> “能保存”不等于“能理解”，而“能理解”也不自动等于“能跨 Core 迁移”；支持必须分层表达。