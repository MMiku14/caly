# ADR-013: IO 按 C1–C6 分类，并使用独立有界执行域

- Status: Accepted
- Date: 2026-08-23
- Decision-Makers: Caly Architecture
- Related-RFCs: RFC-0001, RFC-0006, RFC-0008
- Supersedes: None

---

## 1. Context

Caly 是一个长期运行的本地控制平面。它同时处理多种性质截然不同的 IO：

- IPC 与 Core API，要求低延迟
- 文件与对象存储，可能阻塞
- SQLite，写路径高度串行
- 下载、解压、解析，既吃 CPU 又可能吃 IO
- 子进程 stdio，若不持续读取会反压导致假死

若把这些工作混进同一个“通用异步运行时”或“通用 blocking 线程池”，会出现一系列典型问题：

1. 文件阻塞拖慢控制面响应
2. 下载与解压占满线程池，导致 IPC 或健康检查延迟抖动
3. SQLite 写竞争导致到处补 `busy retry`
4. `spawn_blocking` 默认大池掩盖背压问题，最终形成资源尖峰
5. 子进程输出无人读取时反向阻塞 Core 本身

因此，Caly 不能只说“全部异步化”，而必须明确不同 IO 类别的执行域与上限。

---

## 2. Decision

Caly 采纳以下分类模型：

| 类别 | 内容 | 执行域 |
|---|---|---|
| C1 | 控制 IO：IPC、Core API | reactor |
| C2 | 文件 IO：CAS、配置、日志落盘 | bounded fs pool |
| C3 | 数据库 IO：SQLite | 单 writer + reader pool |
| C4 | CPU/IO 混合：解压、解析、编译、digest | bounded cpu pool |
| C5 | 网络 IO：订阅、规则集、Core 下载 | reactor + streaming |
| C6 | 子进程 IO：stdio、helper 通信 | 专用 reader task |

并进一步作出以下决定：

1. 不同类别 SHOULD 使用独立执行域。
2. 所有执行域 MUST 有上限，不得无界增长。
3. 禁止裸用默认无界语义的 `spawn_blocking` 作为通用解法。
4. SQLite 写路径采用单写者模型，而不是多写者竞争同一 DB。
5. 子进程 stdout/stderr 必须有专用持续消费路径。

---

## 3. Alternatives Considered

### 方案 A：所有东西都放进单个 Tokio runtime

- 优点：
  - 实现简单
  - 心智模型统一
- 缺点：
  - 阻塞与高负载任务容易污染控制路径
  - 调优困难
- 不采纳原因：
  - 不适合 Caly 的低资源、低抖动目标

### 方案 B：需要时到处 `spawn_blocking`

- 优点：
  - 开发方便
  - 容易快速把阻塞代码“挪出去”
- 缺点：
  - 缺少全局并发预算
  - 默认大池会隐藏问题直到负载升高
  - 无法清楚地区分文件/CPU/数据库等资源压力
- 不采纳原因：
  - 不具备可审计性与可控性

### 方案 C：每个模块自己管理线程池

- 优点：
  - 模块自治
- 缺点：
  - 全局资源预算不可控
  - 模块之间相互不了解，容易总量超配
  - 监控与测试复杂
- 不采纳原因：
  - 与系统级资源控制目标冲突

---

## 4. Consequences

### Positive

- 控制面延迟更容易稳定
- 高开销任务不会轻易淹没关键路径
- 资源预算可观测、可压测、可回归
- IO 性能问题更容易归因
- 慢客户端与大下载更容易隔离影响

### Negative / Trade-offs

- 运行时结构更复杂
- 需要额外维护 pool 指标、队列深度和拒绝策略
- 开发者需要理解任务应进入哪个执行域

### Follow-up Work

- 为 `caly-io-std` 定义统一的 bounded blocking pool
- 为 `caly doctor --io` 暴露各执行域指标
- 为性能回归测试加入队列深度与唤醒计数

---

## 5. Compatibility and Migration

该 ADR 属于内部架构决策，不直接影响外部协议。

若未来引入新的 IO 类别，原则上应先判断它归属于 C1–C6 中的哪一类；若无法合理归类，再考虑扩展分类，而不是直接塞入现有任意线程池。

---

## 6. Notes

本 ADR 支撑：

- RFC-0001 的低资源与事件驱动目标
- RFC-0006 的 Port 分层与 IO 边界
- RFC-0008 的高频 Telemetry 限流与运行时稳定性要求

一句话总结：

> IO 不只是“异步”或“阻塞”的二分法，而是多种延迟和失败语义完全不同的工作负载，必须分域并限流。