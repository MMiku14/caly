# ADR-017: CalyApi 作为唯一门面；LocalApi 与 RemoteApi 共享 DTO 语义

- Status: Accepted
- Date: 2026-08-23
- Decision-Makers: Caly Architecture
- Related-RFCs: RFC-0001, RFC-0002
- Supersedes: None

---

## 1. Context

Caly 同时存在两种运行方式：

- daemon 模式：CLI/TUI 通过 IPC 与 `calyd` 通信
- oneshot / 测试模式：调用方可能直接在同进程内执行逻辑

如果这两种路径分别发展为两套 API 形态，就会很快产生一组高成本问题：

1. CLI/TUI 会开始依赖 daemon 专属调用细节。
2. `--no-daemon` 会逐渐演变成“另一套实现”，而不是“同一语义的另一种传输方式”。
3. 集成测试为了绕过 IPC，往往直接调用内部 service，导致测试覆盖的不是用户真实接口。
4. DTO、错误码、Job 状态、分页与 Watch 行为会在本地/远程两条路径上逐步漂移。
5. 一旦 UI 团队发现“直接调某内部 service 更方便”，业务逻辑就会回流到前端。

Caly 的目标不是提供几种“差不多能用”的入口，而是提供**唯一的控制面语义**。传输方式可以不同，但接口语义不能分裂。

---

## 2. Decision

Caly 采纳以下决策：

1. **CalyApi / CalyFacade 是唯一对外业务门面**。
2. 系统同时提供两种实现：
   - `LocalApi`
   - `RemoteApi`
3. 二者 **必须共享同一套 DTO、错误码、Job 语义、Query/Command/Stream 语义和版本策略**。
4. CLI/TUI 只依赖 `Arc<dyn CalyFacade>` 或等价门面抽象，不直接依赖 Engine、Storage、Adapter 或 IPC client 细节。
5. `--no-daemon` 不是“特殊业务模式”，而只是选择 `LocalApi` 作为传输/执行后端。
6. 集成测试优先通过 `LocalApi` 驱动，而不是越过门面直接调用内部模块。

换句话说：

> 本地与远程只有“调用路径”不同，不得有“业务语义”不同。

---

## 3. Alternatives Considered

### 方案 A：CLI/TUI 直接各自调用 IPC 方法，不建立统一门面

- 优点：
  - 看似简单直接
  - 早期开发速度快
- 缺点：
  - UI 逻辑容易知道过多协议细节
  - `--no-daemon` 无法自然复用
  - DTO、错误与流语义容易分叉
- 不采纳原因：
  - 与“前端不持有业务逻辑”的原则冲突

### 方案 B：本地模式直接调用内部 service，远程模式走另一套 IPC DTO

- 优点：
  - 本地模式实现快捷
  - 测试看起来更容易写
- 缺点：
  - 本地与远程语义漂移几乎不可避免
  - 测试覆盖不到真实用户路径
- 不采纳原因：
  - 破坏统一对外契约

### 方案 C：只保留 daemon + IPC，不做 LocalApi

- 优点：
  - 架构单一
  - 不需要考虑两种实现一致性
- 缺点：
  - `--no-daemon` 和嵌入式测试体验差
  - 集成测试更重、更慢、更难控
- 不采纳原因：
  - 不利于开发效率与确定性测试

---

## 4. Consequences

### Positive

- CLI/TUI 与测试共享同一业务入口
- `--no-daemon` 成本显著降低
- DTO 与错误模型更稳定
- 前端更难越权接触内部实现细节
- Local/Remote 契约一致性可通过统一测试验证

### Negative / Trade-offs

- 需要维护门面层与映射层
- RemoteApi 需要处理 IPC 特有故障，但仍需表现出与 LocalApi 一致的高层语义
- 设计初期需要花更多精力冻结 DTO 与错误模型

### Follow-up Work

- 冻结 `caly-api` 中 Facet/DTO 结构
- 建立 LocalApi / RemoteApi 契约对齐测试
- 在 CLI/TUI 中移除任何对内部 service 或 adapter 的直接依赖

---

## 5. Compatibility and Migration

该 ADR 是 Caly 对外接口的基础设计，不涉及旧版本兼容迁移。

若未来出现某个能力只能在 LocalApi 或只能在 RemoteApi 可用，应优先视为设计异常，除非该差异属于传输层天然限制且已被 RFC-0002 明确声明。

---

## 6. Notes

本 ADR 支撑：

- RFC-0002 中统一 Facade、Facet、DTO 和 Operation Envelope 的设计
- RFC-0001 中“CLI/TUI 不持有业务逻辑”的原则

一句话总结：

> Caly 只能有一种控制面语义；本地与远程只是不同实现，不是不同产品。