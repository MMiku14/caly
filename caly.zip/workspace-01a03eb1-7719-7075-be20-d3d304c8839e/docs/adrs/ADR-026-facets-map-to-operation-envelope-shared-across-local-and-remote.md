# ADR-026: Facet 统一映射到 Operation Envelope，Local/Remote 共享协议语义

- Status: Accepted
- Date: 2026-08-23
- Decision-Makers: Caly Architecture
- Related-RFCs: RFC-0002
- Supersedes: None

---

## 1. Context

即使 Facade 已按 Facet 拆分，仍有一个实现层问题：

- `LocalApi` 可以直接调用 trait 方法
- `RemoteApi` 需要把这些方法映射到 IPC 请求

如果为每个 Facet 方法单独手写一套 IPC 编码和分发逻辑，会产生问题：

1. RemoteApi 的协议语义容易与 LocalApi 漂移。
2. 权限、幂等、dry-run、revision CAS 等元信息难以统一表达。
3. 新增方法需要在多处重复加胶水代码。
4. dispatch、审计、指标统计缺少统一观察点。

因此，Facade 的业务语义需要进一步收敛到一层统一操作封装之上。

---

## 2. Decision

Caly 采纳以下决策：

1. 所有 Facet 对外能力最终统一映射为 `Operation Envelope`。
2. `Operation` 按领域枚举组织，例如：
   - `System(...)`
   - `Profile(...)`
   - `Source(...)`
   - `Proxy(...)`
   - `Routing(...)`
   - `Dns(...)`
   - `Network(...)`
   - `Core(...)`
   - `Runtime(...)`
   - `Diagnostics(...)`
   - `Automation(...)`
3. `LocalApi` 与 `RemoteApi` 共享同一组 `Operation` / `OperationResult` / `ApiError` 语义。
4. 每个 Operation 必须带有静态元信息，如：
   - mode
   - idempotency
   - required_role
   - mutates_revision
   - supports_dry_run
   - max_cost
5. IPC dispatch、审计、权限检查、资源控制应尽量围绕 Operation 层统一进行。

---

## 3. Alternatives Considered

### 方案 A：每个 Facet 方法独立写 IPC 编码与路由

- 优点：
  - 看起来最直接
- 缺点：
  - 胶水层快速膨胀
  - 语义与元信息分散
  - Local/Remote 对齐成本高
- 不采纳原因：
  - 不利于长期维护和协议一致性

### 方案 B：RemoteApi 直接传 trait 名 + 方法名字符串

- 优点：
  - 灵活
- 缺点：
  - 缺乏稳定类型边界
  - 元信息和版本控制更脆弱
- 不采纳原因：
  - 太动态，难以冻结规范

### 方案 C：只对 RemoteApi 建立 Operation，本地路径直接绕过

- 优点：
  - 本地实现看起来更简洁
- 缺点：
  - Local/Remote 语义容易分叉
  - 测试无法共享同一逻辑层
- 不采纳原因：
  - 违背 ADR-017 的统一语义目标

---

## 4. Consequences

### Positive

- 协议语义更统一
- 权限/幂等/审计/指标可在统一层处理
- Local/Remote 对齐更容易测试
- 新能力扩展时结构更清晰

### Negative / Trade-offs

- 需要维护 Operation 与 Facet 方法的映射层
- 初看会觉得“多了一层抽象”
- DTO 设计必须更严谨

### Follow-up Work

- 冻结 `Operation` 枚举与分类
- 冻结 `OperationMeta`
- 在 IPC 层建立统一 dispatch
- 为 Local/Remote operation parity 编写契约测试

---

## 5. Compatibility and Migration

Operation 枚举与结果类型属于协议语义的重要部分。

未来若变更某 Operation 的含义、模式或元信息，应同步更新 RFC-0002、Schema、客户端适配与相关测试。

---

## 6. Notes

本 ADR 支撑：

- RFC-0002 中 Operation Envelope 的设计
- LocalApi / RemoteApi 共享协议语义的实现基础

一句话总结：

> Facet 是给人看的领域边界，Operation 是给系统执行和传输用的统一语义载体。