# Caly ADR Index

本目录用于记录 Caly 的架构决策记录（ADR）。

RFC 负责定义“系统必须是什么”，ADR 负责说明“为什么定成这样”。两者互补，但权威性不同：

```text
RFC > ADR > implementation note
```

---

## 1. 当前状态

当前已完成核心 ADR 的抽取，基本覆盖 Caly v1 架构骨架中的关键决策。

建议策略：

- RFC 先冻结边界
- ADR 再解释关键设计取舍
- 后续若 RFC 发生重大变更，应同步检查对应 ADR 是否需要更新或废弃

---

## 2. 已抽取 ADR

| ADR | 标题 | 关联 RFC | 状态 |
|---|---|---|---|
| ADR-011 | 纯内核 / 效果描述 / 单一 IO 网关 | RFC-0001 / RFC-0003 / RFC-0005 / RFC-0006 | Accepted |
| ADR-012 | EffectPlan 为一等对象；dry-run 与 explain 复用同一计划 | RFC-0005 | Accepted |
| ADR-013 | IO 按 C1–C6 分类，各自独立有界执行域 | RFC-0001 / RFC-0006 / RFC-0008 | Accepted |
| ADR-014 | 持久化分 D0–D3，按对象显式声明耐久语义 | RFC-0005 / RFC-0006 / RFC-0007 | Accepted |
| ADR-015 | 管线为 DAG + digest 记忆化；缓存仅加速，不改变语义 | RFC-0001 / RFC-0003 / RFC-0004 | Accepted |
| ADR-016 | VerifyGate 属于 IO 阶段，并按二进制摘要缓存结果 | RFC-0003 / RFC-0006 | Accepted |
| ADR-017 | CalyApi 为唯一门面，LocalApi/RemoteApi 共享 DTO 语义 | RFC-0001 / RFC-0002 | Accepted |
| ADR-018 | 写操作一律 Job 化；同步体验由前端组合而成 | RFC-0002 / RFC-0005 | Accepted |
| ADR-019 | 流具有显式投递策略，Reset 是一等协议语义 | RFC-0002 / RFC-0008 | Accepted |
| ADR-020 | 错误在门面边界归一化，并在该处完成脱敏 | RFC-0002 / RFC-0006 / RFC-0010 | Accepted |
| ADR-021 | Ctx 携带 deadline/cancel/budget，并贯穿到每个 Port 调用 | RFC-0002 / RFC-0006 / RFC-0010 | Accepted |
| ADR-022 | 确定性仿真是 PR 级门禁，而不是可选附加测试 | RFC-0001 / RFC-0005 / RFC-0006 / RFC-0007 | Accepted |
| ADR-023 | 功能支持分为 CalyManaged / NativeManaged / OpaquePreserved | RFC-0001 / RFC-0004 / RFC-0009 | Accepted |
| ADR-024 | Capability Registry 是功能支持事实的唯一来源，并必须绑定证据 | RFC-0004 / RFC-0008 | Accepted |
| ADR-025 | 顶层门面按 Facet 拆分，禁止演化为 God Interface | RFC-0002 | Accepted |
| ADR-026 | Facet 统一映射到 Operation Envelope，Local/Remote 共享协议语义 | RFC-0002 | Accepted |
| ADR-027 | Query / Command / Stream 是唯一三类对外交互语义 | RFC-0002 | Accepted |
| ADR-028 | Event 只用于通知；显式 Coordinator 负责编排 | RFC-0001 / RFC-0002 / RFC-0005 | Accepted |
| ADR-029 | 外部 Core / 平台 / 订阅格式必须经 Anti-Corruption Layer 隔离 | RFC-0001 / RFC-0003 / RFC-0004 / RFC-0008 | Accepted |
| ADR-030 | 结构化 Profile Patch 是唯一合法配置修改入口 | RFC-0001 / RFC-0009 | Accepted |
| ADR-031 | 自动化采用受限声明式 DSL，而不是任意脚本引擎 | RFC-0001 | Accepted |
| ADR-032 | 不加载动态 Rust 插件；未来扩展优先采用隔离 Provider Process | RFC-0001 / RFC-0010 | Accepted |
| ADR-033 | API / IR / Storage / Core Compatibility / Pipeline Epoch 必须独立演进 | RFC-0001 / RFC-0002 / RFC-0003 / RFC-0007 | Accepted |
| ADR-034 | 本地 IPC 采用 framed JSON over UDS / Named Pipe；gRPC 与 HTTP 作为未来桥接层 | RFC-0002 | Accepted |

对应文件：

- `ADR-011-pure-core-effect-plan-io-gateway.md`
- `ADR-012-effect-plan-as-first-class.md`
- `ADR-013-io-classification-and-bounded-execution-domains.md`
- `ADR-014-explicit-durability-tiers-d0-d3.md`
- `ADR-015-pipeline-dag-and-digest-memoization.md`
- `ADR-016-verifygate-is-io-stage-and-cached-by-binary-digest.md`
- `ADR-017-single-facade-local-remote-shared-dto.md`
- `ADR-018-write-operations-are-jobs-sync-is-frontend-composed.md`
- `ADR-019-streams-have-explicit-delivery-policies-and-reset-is-first-class.md`
- `ADR-020-errors-are-normalized-and-redacted-at-facade-boundary.md`
- `ADR-021-ctx-carries-deadline-cancel-budget-through-all-ports.md`
- `ADR-022-deterministic-simulation-is-a-pr-gate.md`
- `ADR-023-support-levels-managed-native-opaque.md`
- `ADR-024-capability-registry-as-single-source-of-truth.md`
- `ADR-025-facade-is-decomposed-into-facets-not-god-interface.md`
- `ADR-026-facets-map-to-operation-envelope-shared-across-local-and-remote.md`
- `ADR-027-query-command-stream-are-the-only-external-interaction-modes.md`
- `ADR-028-events-not-choreography-coordinator-orchestrates.md`
- `ADR-029-anti-corruption-layer-for-core-platform-and-subscription-worlds.md`
- `ADR-030-structured-profile-patch-is-the-only-config-mutation-entry.md`
- `ADR-031-automation-uses-restricted-declarative-dsl.md`
- `ADR-032-no-dynamic-rust-plugins-use-isolated-provider-processes.md`
- `ADR-033-version-lines-evolve-independently.md`
- `ADR-034-local-ipc-uses-framed-json-grpc-http-are-bridges.md`

---

## 3. 下一步建议

虽然核心 ADR 已补齐，但文档体系仍可继续增强：

1. 为每份 RFC 增加 `Related ADRs` 小节
2. 增加 `docs/ERRORS.md` 与 `docs/EXIT_CODES.md`
3. 增加 `docs/IMPLEMENTATION_STATUS.md`
4. 为 RFC 与 ADR 建立交叉引用索引表
5. 将 Accepted ADR 提炼成一页“架构原则总表”

---

## 4. ADR 编写要求

每份 ADR 至少回答：

1. 背景是什么？
2. 决策是什么？
3. 为什么不是其他方案？
4. 会带来什么后果？
5. 对哪些 RFC 有影响？

模板见：

- `docs/adrs/ADR-TEMPLATE.md`

---

## 5. 一句话原则

> RFC 冻结边界，ADR 解释边界。没有 ADR，边界会失去来由；没有 RFC，边界会失去约束。