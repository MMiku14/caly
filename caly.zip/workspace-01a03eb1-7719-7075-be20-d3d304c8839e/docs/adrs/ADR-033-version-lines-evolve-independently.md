# ADR-033: API / IR / Storage / Core Compatibility / Pipeline Epoch 必须独立演进

- Status: Accepted
- Date: 2026-08-23
- Decision-Makers: Caly Architecture
- Related-RFCs: RFC-0001, RFC-0002, RFC-0003, RFC-0007
- Supersedes: None

---

## 1. Context

Caly 同时拥有多条“版本线”：

- API Protocol
- IR Schema
- Storage Schema
- Core Compatibility
- Pipeline Epoch

很多项目在早期会偷懒，把这些变化都塞进一个笼统的 `version` 字段。但在 Caly 里，这会很快造成混乱：

1. 存储迁移和 API 不兼容并不是同一类事件。
2. Pipeline 语义变更可能只影响缓存，不应等同于 DB schema 变更。
3. Core 兼容矩阵变化不必然意味着外部协议变更。
4. IR 迁移可能发生在本地对象层，而与 IPC 无关。
5. “版本号变了，到底该升级什么、迁移什么、拒绝什么”会变得模糊。

Caly 需要把不同性质的兼容性事件分开管理，才能维持系统可演进性和可解释性。

---

## 2. Decision

Caly 采纳以下决策：

1. 以下版本线必须独立管理：
   - `API Protocol Version`
   - `IR Schema Version`
   - `Storage Schema Version`
   - `Core Compatibility Version`
   - `Pipeline Epoch`
2. 它们不得被压缩为单一全局 `version` 字段。
3. 每条版本线的 bump 条件、兼容策略和迁移方式应分别定义。
4. 文档、错误消息、doctor 输出和迁移逻辑应尽量指出究竟是哪条版本线不兼容。

---

## 3. Alternatives Considered

### 方案 A：只有一个全局版本号

- 优点：
  - 表面简单
- 缺点：
  - 语义混乱
  - 不能精确说明兼容性问题发生在哪一层
  - 容易导致过度迁移或错误拒绝
- 不采纳原因：
  - 不适合多层架构系统

### 方案 B：只有 API 和 Storage 两个版本，其他隐含处理

- 优点：
  - 较简单
- 缺点：
  - IR、Pipeline、Core Compatibility 仍会模糊化
- 不采纳原因：
  - 无法覆盖 Caly 的关键演进面

### 方案 C：每个模块各自定义版本，但不建立统一文档语义

- 优点：
  - 模块自治
- 缺点：
  - 用户与维护者难以理解整体兼容状态
  - doctor 与迁移逻辑难统一呈现
- 不采纳原因：
  - 需要独立版本线，也需要统一命名和解释框架

---

## 4. Consequences

### Positive

- 兼容性问题定位更清晰
- 迁移策略更精确
- 可以避免无意义的全局“版本升级焦虑”
- pipeline/cache/storage/api 的变化能够被分别治理

### Negative / Trade-offs

- 文档与实现中需要维护多条版本线
- doctor / status 输出需要更清晰的版本摘要
- 开发者需要理解不同版本线的职责范围

### Follow-up Work

- 在对应模块中定义各版本线的 bump 规则
- 在 doctor / status 中汇总版本兼容状态
- 为迁移与协议协商提供更明确的错误消息

---

## 5. Compatibility and Migration

本 ADR 本身就是兼容与迁移策略的一部分。

未来若新增新的独立兼容维度，应优先考虑是否需要引入新的版本线，而不是硬塞进现有几条之一。

---

## 6. Notes

本 ADR 支撑：

- RFC-0001 中独立版本演进原则
- RFC-0002 中 API Protocol 版本与协商
- RFC-0003 中 Pipeline Epoch
- RFC-0007 中 Storage Schema Version

一句话总结：

> 不同层次的兼容性问题，必须有不同的版本线；一个总版本号只会掩盖真实边界。