# ADR-020: 错误在门面边界归一化，并在该处完成脱敏

- Status: Accepted
- Date: 2026-08-23
- Decision-Makers: Caly Architecture
- Related-RFCs: RFC-0002, RFC-0006, RFC-0010
- Supersedes: None

---

## 1. Context

Caly 内部会产生来自多个世界的错误：

- 领域语义错误
- Capability 错误
- IO 错误
- Core 原生校验错误
- 平台权限错误
- IPC/传输错误
- 内部实现错误

如果这些错误未经统一处理就直接暴露给 CLI/TUI/IPC，会带来严重问题：

1. 外部调用方必须理解大量内部错误类型。
2. 同一个错误在 LocalApi 与 RemoteApi 上表现不同。
3. 错误文本可能携带敏感信息，例如：
   - 订阅 URL token
   - Authorization
   - 节点密码
   - Core 控制 token
4. 前端或日志输出层若忘记脱敏，就会造成泄漏。
5. 退出码和自动化调用无法建立稳定映射。

Caly 需要一个明确的边界：

- 内部错误可以多样
- 跨越对外门面后必须统一
- 脱敏必须尽早、一次性完成

---

## 2. Decision

Caly 采纳以下决策：

1. **内部错误类型可以自由分层，但跨越 Facade/API 边界时必须统一映射为 `ApiError`。**
2. `ApiError` 至少包含：
   - `code`
   - `category`
   - `retryable`
   - `summary`
   - `detail?`
   - `remediation?`
   - `diagnostics[]`
   - `trace_id`
3. **脱敏在构造 `ApiError` 时完成**，而不是在打印、渲染或 JSON 序列化时才补做。
4. 稳定错误码是外部契约的一部分，CLI 退出码、TUI 展示、自动化与文档均依赖这些错误码。
5. 对 `Internal` 类错误，可隐藏内部细节，仅暴露 `trace_id` 与受控摘要。

---

## 3. Alternatives Considered

### 方案 A：直接把内部错误透出，由调用方自行判断与展示

- 优点：
  - 实现快
  - 调试信息完整
- 缺点：
  - 外部语义不稳定
  - 容易泄漏敏感信息
  - Local/Remote 表现不一致
- 不采纳原因：
  - 与对外稳定契约要求冲突

### 方案 B：到展示层再做脱敏

- 优点：
  - 错误对象保留更多原始信息
- 缺点：
  - CLI / TUI / JSON / log 四条路径容易漏掉一条
  - 审计和中继日志中也可能早已泄漏
- 不采纳原因：
  - 脱敏太晚，不可靠

### 方案 C：只统一错误字符串，不定义稳定错误码

- 优点：
  - 表面上更灵活
- 缺点：
  - 机器不可读
  - 退出码与自动化难以稳定映射
  - 国际化或措辞变化会破坏脚本兼容性
- 不采纳原因：
  - 不符合 CLI/IPC 机器可读目标

---

## 4. Consequences

### Positive

- 外部错误语义统一
- 敏感信息泄漏风险显著降低
- CLI/TUI/RemoteApi/LocalApi 可共享错误展示和退出码映射
- 支持包与审计记录更易控制
- 自动化与脚本可依赖稳定错误码

### Negative / Trade-offs

- 需要维护集中错误映射层
- 原始内部调试细节不能随意直接透出
- Redactor 需要持续跟进新的敏感字段形态

### Follow-up Work

- 冻结错误码表与分类表
- 为 `ApiError` 建立统一 redactor
- 在 CLI 中建立错误码到退出码的稳定映射
- 为 LocalApi / RemoteApi 做错误一致性测试

---

## 5. Compatibility and Migration

`ApiError.code` 属于对外兼容接口。

未来若要重命名、删除或改变某个公开错误码的语义，应视为协议兼容性事件，必须同步更新 RFC-0002、文档和退出码映射。

---

## 6. Notes

本 ADR 支撑：

- RFC-0002 中 Facade 错误门面与稳定 ErrorCode
- RFC-0006 中 IO 错误向 `ApiError` 的归一化
- RFC-0010 中 Redaction 的“边界即脱敏”原则

一句话总结：

> 错误可以在内部复杂，但一旦越过门面，就必须统一、稳定、脱敏。