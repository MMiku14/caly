# ADR-015: 管线采用 DAG 与摘要记忆化；缓存仅加速，不改变语义

- Status: Accepted
- Date: 2026-08-23
- Decision-Makers: Caly Architecture
- Related-RFCs: RFC-0001, RFC-0003, RFC-0004
- Supersedes: None

---

## 1. Context

Caly 的配置处理不是“读一份文件，改几处，再输出 YAML/JSON”这么简单。它要同时满足：

- 多 source 合并
- 强类型语义校验
- capability 验证
- 解释来源（provenance）
- dry-run / doctor / explain
- 大输入下的可接受性能
- 修改局部 override 后的增量重算

如果把整个处理链做成一串松散函数调用或单次全量黑箱编译，会出现问题：

1. 无法知道哪些阶段可复用
2. 无法只重跑受影响的后半段
3. 无法稳定输出阶段级诊断与来源信息
4. 难以解释“为什么这次编译结果与上次不同”
5. `--no-cache` 与缓存命中的一致性难以验证

因此，管线必须是稳定可枚举的阶段图，而不是实现细节里的函数链。

---

## 2. Decision

Caly 采纳以下决策：

1. 配置处理主链路采用 **Stage DAG** 模型。
2. 每个 Stage 拥有稳定 `StageId`。
3. 每个 Stage 的输出可由输入摘要和上下文版本号计算缓存键。
4. 记忆化缓存以摘要为基础，缓存命中仅跳过计算，不改变结果。
5. `--no-cache` 必须产生与默认模式字节一致的最终输出。
6. 若管线语义发生不兼容变化，必须 bump `Pipeline Epoch`。

缓存键至少由以下元素构成：

- `stage_id`
- `pipeline_epoch`
- `adapter_version`
- `input_digest`

---

## 3. Alternatives Considered

### 方案 A：每次都全量重编译，不做阶段缓存

- 优点：
  - 简单
  - 不存在缓存失效问题
- 缺点：
  - 大配置下性能浪费
  - explain/provenance 难以做得系统化
  - 修改局部 override 仍需重复 ingest/decode/normalize
- 不采纳原因：
  - 不符合 Caly 的增量和低资源目标

### 方案 B：保留若干 ad hoc 缓存，但不冻结 Stage DAG

- 优点：
  - 可以按热点加速
- 缺点：
  - 缓存策略散落，不可证明一致性
  - 不易测试 `--no-cache` 对比
  - 阶段语义不稳定，解释能力脆弱
- 不采纳原因：
  - 这是性能技巧，不是架构级解决方案

### 方案 C：只缓存最终编译结果

- 优点：
  - 实现容易
- 缺点：
  - 无法支持细粒度增量
  - provenance 与阶段级 diagnostics 仍然缺失
- 不采纳原因：
  - 无法支撑 explain 与中间可观测性

---

## 4. Consequences

### Positive

- 可以精确支持增量重算
- cache hit/miss 行为可测试、可解释
- provenance 和 diagnostics 有稳定阶段锚点
- `doctor` / `explain` / `merge report` 更容易复用中间结果
- 大型配置编译性能更容易优化且不破坏语义

### Negative / Trade-offs

- 需要维护稳定的 StageId 与 Pipeline Epoch 策略
- 缓存索引与对象存储管理更复杂
- 开发者在修改阶段语义时必须考虑缓存兼容性

### Follow-up Work

- 冻结 StageId 列表
- 冻结 CacheKey 结构
- 为 memo 索引与对象存储定义落盘格式
- 为 `--no-cache` 增加回归测试

---

## 5. Compatibility and Migration

若某次改动会导致：

- 相同输入产生不同阶段输出
- provenance 语义发生不兼容变化
- diagnostics 含义被重定义

则必须评估并在需要时 bump `Pipeline Epoch`。

仅性能优化且不改变语义时，不应 bump。

---

## 6. Notes

本 ADR 支撑：

- RFC-0003 中的 Stage DAG、CacheKey、Pipeline Epoch
- RFC-0001 中的决定性编译主张
- RFC-0004 中 capability 验证在管线中的稳定位置

一句话总结：

> 缓存只能是纯管线的加速层，不能成为另一套隐含语义。