# ADR-014: 持久化采用显式耐久等级 D0–D3

- Status: Accepted
- Date: 2026-08-23
- Decision-Makers: Caly Architecture
- Related-RFCs: RFC-0001, RFC-0005, RFC-0006, RFC-0007
- Supersedes: None

---

## 1. Context

Caly 的本地状态既包括：

- 可丢的观测数据，如部分日志与 telemetry
- 可重建的工件，如某些中间产物与 CAS 对象
- 一旦丢失就会破坏恢复语义的关键记录，如 Snapshot、Revision 提交、OSJournal

如果系统对所有写入都采用同一种模糊策略，就会落入两个常见极端：

1. **到处 fsync**：
   - 性能差
   - 放大磁盘压力
   - 让普通写入承担不必要的耐久成本

2. **默认不 fsync**：
   - 在崩溃或断电后无法判断哪些状态真正提交过
   - 回滚/恢复语义失真
   - “看起来写成功了”但实际上并未耐久

Caly 需要的是：

- 明确区分不同数据的恢复价值
- 让写入方声明它需要的耐久级别
- 让测试可以围绕这些级别构造故障场景

---

## 2. Decision

Caly 采用四级显式耐久模型：

| 等级 | 语义 | 典型对象 |
|---|---|---|
| D0 | 可丢缓冲写 | telemetry、普通日志缓冲 |
| D1 | tmp + rename | 中间工件、非关键物化 |
| D2 | 文件级耐久：fsync(file) + rename + fsync(dir) | CAS 对象、可校验工件 |
| D3 | 文件耐久 + DB 提交耐久协同 | Journal、Revision 提交、Snapshot 提交 |

并作出以下决策：

1. 写入动作必须显式选择其耐久等级。
2. 与恢复正确性相关的提交点，原则上至少达到 D3。
3. 可校验、可重建的内容对象可采用 D2。
4. 普通观测数据可采用 D0 或 D1，不强制升级。

---

## 3. Alternatives Considered

### 方案 A：所有写入一律尽量 fsync

- 优点：
  - 心理上“最安全”
- 缺点：
  - 成本过高
  - 不能反映数据的重要性差异
  - 低资源目标受损
- 不采纳原因：
  - 过度保守，不符合 Caly 的资源目标

### 方案 B：只依赖 rename 原子性，不定义耐久语义

- 优点：
  - 实现简单
  - 常见于很多工具型程序
- 缺点：
  - rename 原子不等于数据持久
  - 断电后恢复语义不清晰
- 不采纳原因：
  - 无法支撑 Snapshot/Journal 的正确性主张

### 方案 C：把耐久策略埋在具体实现里，不对上层暴露

- 优点：
  - 调用方简单
- 缺点：
  - 上层无法表达对象重要性
  - 测试难以验证何时应该持久、何时允许丢失
- 不采纳原因：
  - 耐久级别是语义决策，不只是实现细节

---

## 4. Consequences

### Positive

- 持久化成本与数据价值对应
- 崩溃/断电场景更容易测试和推理
- Storage/Executor/Recovery 对“什么算提交”拥有统一语言
- 性能与可靠性之间的取舍可显式化

### Negative / Trade-offs

- 开发者必须理解不同等级的适用场景
- 实现层需要为不同平台映射等价或近似语义
- 某些平台上 D2/D3 的严格等价实现可能较复杂

### Follow-up Work

- 在 `Fs` Port 中为写入/rename 明确 durability 参数
- 在 Storage 层标注各类对象默认耐久等级
- 在仿真测试中加入 “fsync 后崩溃 / rename 前崩溃 / DB 提交中断” 等场景

---

## 5. Compatibility and Migration

该决策主要影响内部实现与测试。

如果未来发现某类对象的恢复重要性被错误分级，应通过 RFC/ADR 和实现共同调整其默认耐久等级，而不是局部偷偷加 `fsync` 或偷偷省略。

---

## 6. Notes

本 ADR 支撑：

- RFC-0005 中“成功后提交、失败后回滚”的恢复语义
- RFC-0006 中 `Fs.write_atomic` 的 durability 语义
- RFC-0007 中 CAS、Snapshot、Journal 的存储分层

一句话总结：

> 持久化不是“写盘/不写盘”二选一，而是必须按恢复价值显式分层。