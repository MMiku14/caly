# ADR-XXXX: <Title>

- Status: Proposed
- Date: YYYY-MM-DD
- Decision-Makers: <names or team>
- Related-RFCs: RFC-0001, ...
- Supersedes: <optional>

---

## 1. Context

描述促成该决策的背景：

- 现状与约束
- 目标与风险
- 需要解决的歧义或冲突

---

## 2. Decision

清晰陈述本 ADR 采纳的决策。

应尽量写成一句或几句可直接引用的架构结论。

---

## 3. Alternatives Considered

列出被评估但未采纳的备选方案，并说明拒绝原因。

建议格式：

- 方案 A：...
  - 优点：...
  - 缺点：...
  - 不采纳原因：...
- 方案 B：...

---

## 4. Consequences

说明该决策带来的影响：

### Positive

- ...

### Negative / Trade-offs

- ...

### Follow-up Work

- ...

---

## 5. Compatibility and Migration

如果该决策会影响现有文档、实现或协议，应说明：

- 是否破坏兼容
- 是否需要迁移
- 是否需要 bump 版本或更新 RFC

---

## 6. Notes

补充说明、关联 issue、测试门禁或实现注意事项。
