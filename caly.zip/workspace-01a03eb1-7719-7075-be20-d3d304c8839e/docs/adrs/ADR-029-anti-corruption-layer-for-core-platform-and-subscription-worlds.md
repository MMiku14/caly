# ADR-029: 外部 Core / 平台 / 订阅格式必须经 Anti-Corruption Layer 隔离

- Status: Accepted
- Date: 2026-08-23
- Decision-Makers: Caly Architecture
- Related-RFCs: RFC-0001, RFC-0003, RFC-0004, RFC-0008
- Supersedes: None

---

## 1. Context

Caly 所处的外部世界并不统一，至少包括四类异构体系：

- Mihomo 原生配置与运行时 API
- sing-box 原生配置与运行时 API
- 各平台系统 API（TUN、DNS、系统代理、路由、进程信息等）
- 用户输入的订阅格式、导入文件和非标准变体

如果这些外部类型与语义直接渗透进领域模型，就会形成长期污染：

1. Domain 类型开始携带 Mihomo/sing-box 的字段结构。
2. CLI/TUI 开始知道平台或 Core 特有概念。
3. 合并与能力校验被外部格式绑架。
4. 新增第三个 Core 或新增平台支持时，上层逻辑需要大面积重写。
5. 未知字段和非标准订阅逻辑更容易在各层散落。

Caly 的定位是控制平面，而不是某个外部格式的薄包装器。因此需要一层明确的“防腐层”，把外部世界隔离在边界组件内。

---

## 2. Decision

Caly 采纳以下决策：

1. **外部世界必须通过 Anti-Corruption Layer 进入系统。**
2. 至少以下四类外部世界需要独立防腐：
   - Core native config/API
   - platform API
   - subscription/import formats
   - privileged helper protocol（若其结构与内部领域不同）
3. Domain / IR 层禁止直接暴露外部类型。
4. 外部类型只允许出现在边界组件中，例如：
   - decode adapters
   - core compilers
   - runtime drivers
   - platform adapters
5. 任何从外部世界进入统一语义层的内容，都必须：
   - 经过结构转换
   - 经过能力/兼容性判断
   - 必要时进入 extension / passthrough，而不是污染核心模型

---

## 3. Alternatives Considered

### 方案 A：直接在 Domain 里复用 Mihomo/sing-box 配置结构

- 优点：
  - 初期开发快
  - 序列化/反序列化复用多
- 缺点：
  - 域模型被外部格式绑死
  - 跨 Core 统一语义几乎无法建立
- 不采纳原因：
  - 与 Caly 的 Core-agnostic 目标冲突

### 方案 B：只对部分世界做隔离，其他“先凑合”

- 优点：
  - 早期速度快
- 缺点：
  - 最终仍会形成跨层污染
  - 后续重构成本更高
- 不采纳原因：
  - 防腐层最怕“半做不做”

### 方案 C：强行把所有外部特性都塞进统一强类型模型

- 优点：
  - 表面上最统一
- 缺点：
  - 很多 Core/platform 专属差异不适合强行抽象
  - 会制造错误统一
- 不采纳原因：
  - 应允许 extension / passthrough 保真，而不是伪统一

---

## 4. Consequences

### Positive

- 领域模型更稳定
- 新 Core / 新平台接入成本更可控
- UI 与上层逻辑更少知道外部实现细节
- capability、merge、patch 边界更清晰

### Negative / Trade-offs

- 边界转换代码会增多
- 需要维护更多 adapter / mapping 层
- 某些问题需要明确决定是“建模”还是“透传”

### Follow-up Work

- 为 decode adapter / compiler / runtime driver / platform adapter 明确所有权边界
- 审计当前文档和后续代码，禁止外部类型渗入 Domain/DTO
- 为 passthrough 与 extension 提供更清晰的使用准则

---

## 5. Compatibility and Migration

该 ADR 是长期架构边界决策。

若未来发现某个外部类型已经渗透到核心模型，应优先视为技术债并回收，而不是继续在其上叠加更多抽象。

---

## 6. Notes

本 ADR 支撑：

- RFC-0001 中 Core-agnostic 与 Anti-Corruption Layer 原则
- RFC-0003 中从 RawSource 到 CalyIR 的边界设计
- RFC-0004 中 capability 与 passthrough 的处理原则
- RFC-0008 中 RuntimeDriver 统一观测抽象

一句话总结：

> Caly 可以适配很多外部世界，但不能把自己变成外部世界的混合体。