# ADR-019: 流具有显式投递策略，Reset 是一等协议语义

- Status: Accepted
- Date: 2026-08-23
- Decision-Makers: Caly Architecture
- Related-RFCs: RFC-0002, RFC-0008
- Supersedes: None

---

## 1. Context

Caly 需要向 CLI/TUI 暴露多种持续流：

- Dashboard 汇总状态
- Job 进度与结果
- Traffic
- Logs
- Connections
- Deployment 状态

这些流的性质并不相同：

- 有的必须无损可续传
- 有的天然允许丢中间值
- 有的集合变化过大时，增量补丁不如直接重置快照
- 有的如果按每条都 ACK，会带来明显 IPC 开销

如果所有流都被当作一种“永远连续、尽量别断”的抽象，会导致：

1. 客户端错误假设本地视图始终可持续增量更新。
2. 慢客户端把服务端内存拖向无界积压。
3. 实现者为了“尽量不断流”而复杂化协议，却仍无法保证一致性。
4. 不同流的正确性成本被错误拉平。

因此，流必须按类型声明自己的投递语义，而“重置并重取快照”必须成为协议层明确支持的合法路径。

---

## 2. Decision

Caly 采纳以下决策：

1. **每类 Stream 必须声明明确的投递策略。**
2. 允许的主策略至少包括：
   - 无损可续传
   - 最新值合并
   - 有界差分
   - 有界丢弃
3. **`Reset` 是一等协议消息**，其语义是：
   - 当前增量链不再可信或不再连续
   - 客户端必须丢弃本地视图并重新获取快照
4. 客户端必须实现 `Reset` 处理，不得假设流永远连续。
5. 对高频 telemetry，默认不逐条 ACK；对 Job/Deployment 等关键流，可使用 ACK/续传语义。

---

## 3. Alternatives Considered

### 方案 A：所有流都尽量做成无损连续流

- 优点：
  - 概念统一
- 缺点：
  - 实现复杂度与资源消耗高
  - 对 traffic/logs 这类流意义不大
  - 慢客户端风险大
- 不采纳原因：
  - 与 Caly 的低资源目标不匹配

### 方案 B：所有流都允许随时断，客户端自行凑合

- 优点：
  - 服务端简单
- 缺点：
  - 客户端一致性难以保证
  - UI 容易显示错误状态
- 不采纳原因：
  - 缺少正式语义，导致实现随意

### 方案 C：只在实现里内部重置，不把 Reset 暴露为协议消息

- 优点：
  - 表面上协议更简洁
- 缺点：
  - 客户端无法可靠知道何时必须重取快照
  - 状态漂移难以调试
- 不采纳原因：
  - Reset 必须对客户端可见

---

## 4. Consequences

### Positive

- 不同流的可靠性成本可按需配置
- 慢客户端处理更可控
- Dashboard/Connections 这类增量视图更容易保持正确
- 前端状态机更清晰，可明确处理“快照失效”

### Negative / Trade-offs

- 客户端必须实现更多流状态逻辑
- 协议文档需要明确区分不同 stream class
- 某些开发者会误以为 Reset 是“错误”，实际上它是正常机制

### Follow-up Work

- 冻结 stream metadata 与策略枚举
- 在 CLI/TUI watch client 中实现统一 Reset 处理
- 为慢客户端和溢出场景增加集成测试

---

## 5. Compatibility and Migration

一旦某个 Stream 被定义为支持 `Reset`，客户端就必须把它当作正常协议路径，而不是异常分支。

未来若调整某流的投递策略，应视为协议行为变更，并同步更新 RFC-0002 / RFC-0008 与相应客户端实现。

---

## 6. Notes

本 ADR 支撑：

- RFC-0002 中 Watch/Stream/Reset/ACK 语义
- RFC-0008 中 Traffic/Logs/Connections 等 runtime telemetry 的限流与一致性要求

一句话总结：

> 流不必都无损，但每种流都必须明确告诉客户端：它究竟保证什么，又何时必须重置。