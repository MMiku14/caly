# ADR-021: Ctx 携带 deadline / cancel / budget，并贯穿到每个 Port 调用

- Status: Accepted
- Date: 2026-08-23
- Decision-Makers: Caly Architecture
- Related-RFCs: RFC-0002, RFC-0006, RFC-0010
- Supersedes: None

---

## 1. Context

Caly 的操作往往跨越多个层次：

- Facade
- Engine / Coordinator
- Pipeline
- Storage
- Http / Fs / Proc / Platform Port

如果每层各自发明超时、取消、资源预算和 trace 传播方式，就会出现典型问题：

1. 某个子操作忘了设超时，导致整条命令悬挂。
2. 外层请求取消了，里层下载、进程等待、文件写入仍继续运行。
3. 单条命令可能在重定向、重试或大文件处理上无限消耗资源。
4. trace_id 在跨层时丢失，导致诊断和审计链断裂。
5. 不同 Port 对“剩余时间”理解不一致，出现子调用放大超时的情况。

因此，Caly 需要一个统一上下文对象，把这些横切语义贯穿到底层。

---

## 2. Decision

Caly 采纳以下决策：

1. **统一上下文对象 `Ctx` 是跨门面、引擎、执行器与 Port 的标准调用上下文。**
2. `Ctx` 至少包含：
   - `trace_id`
   - `actor`
   - `deadline`
   - `cancel_token`
   - `expected_revision`（适用时）
   - `io_budget`
3. 所有 IO Port 调用必须接受或隐式继承 `Ctx`。
4. `deadline` 在下层调用中只能缩减，不能放大。
5. 支持取消的 Port 应在合理边界检查 `cancel_token`。
6. `io_budget` 用于限制单条命令可消耗的字节数、请求数或其他重要配额。

---

## 3. Alternatives Considered

### 方案 A：每个模块自行传 timeout / cancel 参数

- 优点：
  - 局部实现灵活
- 缺点：
  - 容易遗漏
  - 风格不统一
  - trace 和 budget 难以一致传播
- 不采纳原因：
  - 不能形成系统级约束

### 方案 B：只在最外层做超时控制，底层不感知

- 优点：
  - API 表面简单
- 缺点：
  - 底层可能继续运行浪费资源
  - 某些不可中断操作更难治理
- 不采纳原因：
  - 不能满足低资源与取消要求

### 方案 C：只传播 trace_id，不传播 budget/cancel/deadline

- 优点：
  - 可观测性部分改善
- 缺点：
  - 不能解决悬挂和资源失控问题
- 不采纳原因：
  - 只解决一部分问题

---

## 4. Consequences

### Positive

- 超时与取消语义一致
- trace 链更完整
- 资源预算可下沉到真正消耗资源的地方
- Doctor / support bundle 更容易还原调用路径
- Port 契约更清晰

### Negative / Trade-offs

- 函数签名或调用环境会更“重”
- 某些不易中断的底层库仍需适配或包装
- 预算模型需要谨慎设计，避免过细导致实现负担过高

### Follow-up Work

- 冻结 `Ctx` 字段与派生规则
- 为 Port 契约测试加入 timeout/cancel/budget 案例
- 在 tracing 中统一使用 `trace_id`

---

## 5. Compatibility and Migration

`Ctx` 属于内部跨层契约，但其行为会影响外部 API 的 deadline/取消语义。

未来若扩展 `Ctx` 字段，应优先保持向后兼容的默认语义，而不是让旧调用点隐式失效。

---

## 6. Notes

本 ADR 支撑：

- RFC-0002 中 `Ctx` 的横切上下文语义
- RFC-0006 中 Port deadline/cancel/budget 规则
- RFC-0010 中 trace 与安全审计链路的一致性要求

一句话总结：

> 超时、取消、预算和追踪不是各层自己的小参数，而是一次调用从入口到底层的统一语义。