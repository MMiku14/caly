# ADR-025: 顶层门面按 Facet 拆分，禁止演化为 God Interface

- Status: Accepted
- Date: 2026-08-23
- Decision-Makers: Caly Architecture
- Related-RFCs: RFC-0002
- Supersedes: None

---

## 1. Context

Caly 需要对外提供统一控制面，但其功能域很多：

- system
- profile
- source
- proxy
- routing
- dns
- network
- core
- runtime
- diagnostics
- automation

如果把这些能力都堆进一个不断膨胀的大 trait 或大 service 接口，就会出现典型问题：

1. 接口体积快速失控，难以阅读和维护。
2. 前端实现者会拿到不该直接关心的一大堆方法。
3. 某个领域的改动容易影响无关领域的编译与审查成本。
4. 权限、分页、stream 语义、测试都更难按领域组织。
5. 最终“统一门面”会沦为 God Interface，而不是清晰的外部边界。

因此，统一门面必须保留，但它内部必须是按领域拆分的 Facet 组合，而不是一个无限长的接口列表。

---

## 2. Decision

Caly 采纳以下决策：

1. 对外存在统一入口 `CalyFacade`。
2. `CalyFacade` 不直接承载所有业务方法，而是暴露多个领域化 `Facet`：
   - `SystemFacet`
   - `ProfileFacet`
   - `SourceFacet`
   - `ProxyFacet`
   - `RoutingFacet`
   - `DnsFacet`
   - `NetworkFacet`
   - `CoreFacet`
   - `RuntimeFacet`
   - `DiagnosticsFacet`
   - `AutomationFacet`
3. 新增对外能力时，优先扩展已有 Facet；只有在确实形成新领域边界时才引入新 Facet。
4. CLI/TUI 仍只依赖顶层门面，但可按 Facet 获得更清晰的模块化接口。

---

## 3. Alternatives Considered

### 方案 A：一个大 `CalyApi` trait，所有方法平铺

- 优点：
  - 概念少
  - 查找入口直接
- 缺点：
  - 方法数量会持续膨胀
  - 领域边界模糊
  - 容易形成 God Interface
- 不采纳原因：
  - 不利于长期维护

### 方案 B：完全没有统一门面，前端分别依赖多个 service

- 优点：
  - service 复用灵活
- 缺点：
  - UI 容易依赖内部实现细节
  - 统一权限/DTO/错误语义更难
- 不采纳原因：
  - 破坏对外边界收敛

### 方案 C：按技术层而不是按业务域拆接口

- 优点：
  - 接近内部实现结构
- 缺点：
  - 前端看到的是实现细节，不是用户语义
  - 容易把 Storage/Core/Platform 暴露出去
- 不采纳原因：
  - Facade 应按用户可感知领域组织

---

## 4. Consequences

### Positive

- 外部接口可扩展且不易失控
- 权限、测试、文档可按领域组织
- 前端依赖更清晰
- 每个 Facet 都更容易单独冻结 DTO 与操作集合

### Negative / Trade-offs

- 需要维护 Facet 与 Operation 的映射关系
- 某些跨域操作需要额外思考应归属哪个 Facet
- 顶层门面与领域拆分之间需要保持平衡

### Follow-up Work

- 冻结各 Facet 的最小方法集合
- 为每个 Facet 生成单独 DTO/Schema 区域
- 在文档和代码审查中把“新增顶层散装方法”视为坏味道

---

## 5. Compatibility and Migration

Facet 名称与边界属于长期 API 设计的一部分。

未来若发现某 Facet 过大，应考虑继续拆分；若某两个 Facet 实际无法分离，也应经过 RFC/ADR 讨论后合并，而不能任意漂移。

---

## 6. Notes

本 ADR 支撑：

- RFC-0002 中 Facade / Facet 的整体设计
- CLI/TUI 与 DTO 按领域组织的结构

一句话总结：

> 统一门面不意味着单一巨型接口；它应该是稳定入口下的领域化分面。