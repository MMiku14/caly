# ADR-024: Capability Registry 是功能支持事实的唯一来源，并必须绑定证据

- Status: Accepted
- Date: 2026-08-23
- Decision-Makers: Caly Architecture
- Related-RFCs: RFC-0004, RFC-0008
- Supersedes: None

---

## 1. Context

在支持 Mihomo 与 sing-box 的过程中，功能差异来源很多：

- Core 种类不同
- Core 版本不同
- 构建选项不同
- 平台不同
- 权限模型不同
- Adapter 成熟度不同

如果 Capability 判断散落在 Adapter 的 `match` 分支、UI 的灰显逻辑、CLI 的文案、测试注释和 issue 讨论中，就会产生严重问题：

1. 不同位置对同一功能得出不同结论。
2. 功能支持状态无法被机器导出、检查和测试。
3. 前端很容易根据经验“猜测支持”，而不是查询事实来源。
4. 某项功能即使只在一个特定版本、特定平台可用，也会被错误泛化。
5. “看起来能跑”会被误当作“正式支持”。

Caly 需要一个统一、可查询、可导出、可绑定证据的能力事实层。

---

## 2. Decision

Caly 采纳以下决策：

1. **Capability Registry 是功能支持结论的唯一事实来源。**
2. 所有以下组件都应查询 Registry，而不是各自编码判断逻辑：
   - compiler / validate
   - doctor
   - CLI/TUI capability 展示
   - runtime feature exposure
   - tests / coverage export
3. Registry 的每个 capability 至少包含：
   - 稳定 key
   - domain
   - support level
   - capability state
   - constraints
   - fallback
   - evidence reference
4. **被标记为正式支持的能力必须绑定证据**，至少包括 fixture、golden、native validate、runtime test 或其适用子集。
5. 如果没有足够证据，不应标记为 `SupportedExact`；应降级为 `Experimental`、`SupportedNativeOnly` 或其他更保守状态。

---

## 3. Alternatives Considered

### 方案 A：Adapter 自己维护支持判断，UI 只做文案映射

- 优点：
  - 实现上看似更直接
- 缺点：
  - 逻辑散落
  - 外部无法统一导出支持矩阵
  - 测试与实现不易对齐
- 不采纳原因：
  - 不满足单一事实来源要求

### 方案 B：只维护一份人工文档表，不进入系统逻辑

- 优点：
  - 成本低
- 缺点：
  - 文档极易过期
  - 实现与文档分裂
  - 无法驱动编译/doctor/前端行为
- 不采纳原因：
  - 只解决说明，不解决系统一致性

### 方案 C：所有能力一律在运行时探测，不维护静态 Registry

- 优点：
  - 结果更接近真实环境
- 缺点：
  - 许多能力无法仅靠运行时探测准确判断
  - 版本/平台/适配器成熟度信息难以结构化表达
- 不采纳原因：
  - 需要 Registry + 运行时信息结合，而不是纯运行时猜测

---

## 4. Consequences

### Positive

- 功能支持结论统一且可审计
- 可自动生成 Coverage Matrix
- CLI/TUI/Doctor 的展示依据一致
- 支持状态与测试证据能直接关联
- 更容易识别“实现存在但尚不应宣称正式支持”的能力

### Negative / Trade-offs

- 需要维护 Registry 与测试证据索引
- 新能力接入流程更严格
- 某些灰色能力需要更细的状态区分与说明

### Follow-up Work

- 冻结 capability registry schema
- 冻结 evidence schema
- 生成 coverage matrix 导出工具
- 在 CI 中检查 `SupportedExact` 项是否具备所需证据

---

## 5. Compatibility and Migration

Capability key 与状态语义属于长期兼容接口的一部分。

未来若重命名 key、修改状态含义或调整支持级别，必须同步更新：

- RFC-0004
- coverage matrix
- capability explain / doctor / CLI/TUI 展示
- 相关测试与文档

---

## 6. Notes

本 ADR 支撑：

- RFC-0004 中 Registry、Evidence、Coverage Matrix 的设计
- RFC-0008 中 runtime capability 暴露的一致性要求

一句话总结：

> 能力支持不能散落在代码角落和文档角落里，它必须有一个可查询、可验证、可追责的唯一事实来源。