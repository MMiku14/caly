# ADR-030: 结构化 Profile Patch 是唯一合法配置修改入口

- Status: Accepted
- Date: 2026-08-23
- Decision-Makers: Caly Architecture
- Related-RFCs: RFC-0001, RFC-0009
- Supersedes: None

---

## 1. Context

Caly 的一项核心价值，是把多源不可信配置转为统一语义并安全部署。因此，“用户如何修改配置”本身就是架构问题。

如果允许以下做法成为主路径：

- 直接编辑生成后的 Mihomo YAML / sing-box JSON
- 对整棵 Profile 树做任意 JSON Patch
- 在 UI 里以自由文本方式做无约束改写

会产生明显问题：

1. 变更缺乏稳定业务语义，难以迁移。
2. 引用重写、能力校验、merge report、provenance 都难以可靠支持。
3. 用户轻易绕过 SafetyPolicy 和 capability 边界。
4. 同一操作在不同 Core/版本下语义不稳定。
5. 回滚与 explain 只能看到“结果变了”，难以知道“为什么变”。

Caly 需要的是：

- 以结构化、可验证、可解释的方式表达配置修改
- 明确区分持久修改、来源覆盖和运行时临时偏好

---

## 2. Decision

Caly 采纳以下决策：

1. **结构化 `ProfilePatch` / `SourceOverride` / `RuntimeOverride` 是唯一合法的配置修改入口。**
2. 生成后的原生配置文件不得作为用户主要编辑入口。
3. 任意 JSON Patch、任意文本替换、任意 deep merge 不作为 v1 的主修改模型。
4. Native Patch 仅允许在受限范围内存在，并受 capability 与 explain 约束。
5. 所有修改必须能进入：
   - 校验
   - MergeReport
   - Provenance
   - Rollback / Revision / Snapshot 语义

---

## 3. Alternatives Considered

### 方案 A：允许用户主要编辑原生 YAML/JSON

- 优点：
  - 立刻可用
  - 与现有生态文件直接兼容
- 缺点：
  - 绕过统一语义层
  - 无法稳定做 merge/explain/patch migration
- 不采纳原因：
  - 与 Caly 的统一控制面定位冲突

### 方案 B：通用 JSON Patch 作为主要配置修改接口

- 优点：
  - 技术通用
  - 表达能力强
- 缺点：
  - 业务语义弱
  - 不利于版本迁移与引用校验
- 不采纳原因：
  - 过于底层，不适合作为长期对外主接口

### 方案 C：允许脚本语言任意修改配置树

- 优点：
  - 灵活
- 缺点：
  - 不可控
  - 难审计、难解释、难测试
- 不采纳原因：
  - 不符合 v1 的可维护性与安全目标

---

## 4. Consequences

### Positive

- 配置变更语义稳定
- 迁移与版本演进更可控
- patch 结果更容易 explain 与测试
- SafetyPolicy 与 capability 更容易统一执行

### Negative / Trade-offs

- 初期 patch 模型设计成本较高
- 某些高级用户会觉得不如直接改 YAML 灵活
- 需要逐步补齐 Patch 枚举覆盖面

### Follow-up Work

- 冻结 Patch / Override / Selector 的代码级 schema
- 在 CLI/TUI 中围绕结构化 patch 组织交互
- 为 Native Patch 补充更多能力与限制文档

---

## 5. Compatibility and Migration

该 ADR 直接影响未来 API 和 CLI/TUI 设计。

若未来确需支持“导入并编辑 native targeted profile”，也应将其重新包装进受限结构化 patch 语义中，而不是回退到自由文本主路径。

---

## 6. Notes

本 ADR 支撑：

- RFC-0009 中 Patch / Override / Selector 的设计
- RFC-0001 中“不直接污染上游订阅”和“统一语义中心”的原则

一句话总结：

> Caly 编辑的是结构化语义，不是生成后的原生文本。