# ADR-012: EffectPlan 作为一等对象；dry-run 与 explain 复用同一计划

- Status: Accepted
- Date: 2026-08-23
- Decision-Makers: Caly Architecture
- Related-RFCs: RFC-0001, RFC-0005
- Supersedes: None

---

## 1. Context

Caly 的部署系统不仅要“能执行”，还要满足以下要求：

- `--dry-run` 必须真实可信，而不是“少执行几个函数”的伪预演
- `--explain` 必须解释实际会发生的步骤，而不是一段手写说明文案
- 部署失败后必须可补偿、可回滚
- 仿真测试必须能在不触碰真实系统的情况下覆盖部署全过程

如果部署逻辑只是散落在若干 service 函数中的一系列副作用调用，那么会产生常见问题：

1. dry-run 往往只是加一堆 `if dry_run { return; }`
2. explain 文本和真实执行流程容易漂移
3. 补偿逻辑只能在 `catch`/`match err` 中临时拼凑
4. 测试只能 mock 某个子函数成功，无法验证完整步骤序列

因此，部署过程必须先被“描述”为一个稳定对象，再由执行器消费。

---

## 2. Decision

Caly 采纳以下决策：

1. **EffectPlan 是一等对象**。部署前必须先生成完整 `EffectPlan`。
2. `EffectPlan` 至少包含：
   - 正向步骤 `steps[]`
   - 补偿步骤 `compensations[]`
   - 所需权限 `requires`
   - 影响摘要 `impact`
3. **dry-run 直接返回同一个 `EffectPlan`**，而不是走单独的“预估逻辑”。
4. **explain 直接渲染同一个 `EffectPlan`**，而不是维护第二套说明代码。
5. **真实部署由 Executor 执行同一个 `EffectPlan`**。
6. 仿真测试同样消费 `EffectPlan`，通过注入故障验证补偿与恢复路径。

这意味着：

- 计划生成是纯逻辑或近似纯逻辑步骤
- 执行是单独职责
- 解释是对同一对象的只读投影

---

## 3. Alternatives Considered

### 方案 A：部署函数内部用 `dry_run: bool` 分支

- 优点：
  - 实现门槛低
  - 代码看起来直接
- 缺点：
  - dry-run 与真实执行极易分叉
  - 很难保证所有副作用点都被正确跳过
  - explain 无法复用
- 不采纳原因：
  - 不满足“同一语义、不同消费方式”的要求

### 方案 B：先生成一部分计划，剩余步骤执行时动态追加

- 优点：
  - 某些路径可能更灵活
- 缺点：
  - 计划不完整，解释不完整
  - 补偿边界难以提前推理
  - 故障注入测试无法固定步骤空间
- 不采纳原因：
  - 削弱事务可推理性

### 方案 C：只保留 ApplyPlan，不区分 EffectPlan

- 优点：
  - 概念更少
- 缺点：
  - ApplyPlan 只表达“切换等级/策略”，不能表达完整副作用序列
  - 无法承担 dry-run/explain/补偿载体角色
- 不采纳原因：
  - ApplyPlan 与 EffectPlan 抽象层级不同，不能混为一体

---

## 4. Consequences

### Positive

- dry-run 语义可信且天然完备
- explain 不再维护第二套逻辑
- 补偿步骤可在计划阶段显式生成
- 仿真测试可以在步骤级注入崩溃/失败
- 部署审计更清晰

### Negative / Trade-offs

- 需要先设计 `EffectStep` 枚举与补偿矩阵
- 计划对象可能较大，需要考虑摘要视图与详细视图
- 执行器实现必须更严格地处理步骤状态与中断语义

### Follow-up Work

- 冻结 `EffectStep` 全集与补偿原则
- 为 CLI/TUI 提供计划可视化 DTO
- 为仿真测试世界提供 step-level fault injection

---

## 5. Compatibility and Migration

该决策是部署体系的基础抽象，不涉及旧接口迁移。

若未来有人提议新增“特殊 dry-run 路径”或“手写 explain 文本”，应视为对该 ADR 的偏离，必须先证明为何不能复用 `EffectPlan`，否则不应采纳。

---

## 6. Notes

本 ADR 解释了 RFC-0005 中以下要求的来由：

- `EffectPlan` 与 `ApplyPlan` 的分离
- `--dry-run` 与 `--explain` 复用同一计划
- 补偿动作在规划期生成而非失败时临时拼接

一句话总结：

> 计划、解释、执行、仿真必须共享同一个部署对象，否则它们迟早会互相漂移。