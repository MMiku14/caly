# ADR-031: 自动化采用受限声明式 DSL，而不是任意脚本引擎

- Status: Accepted
- Date: 2026-08-23
- Decision-Makers: Caly Architecture
- Related-RFCs: RFC-0001
- Supersedes: None

---

## 1. Context

Caly 需要一定程度的自动化能力，例如：

- 定时更新订阅
- 延迟测试后选择更优节点
- Core 异常退出后恢复动作
- 某些条件触发 profile apply

直觉上，引入 Lua、JS 或 shell 脚本似乎最灵活。但这会立即带来一系列问题：

1. 自动化行为变得不可预测，难以审计。
2. 任意脚本天然容易绕过权限边界与资源预算。
3. 失败语义、幂等、回滚、速率限制难以统一。
4. 自动化与普通 Command/Job 管线脱节。
5. 调试和测试复杂度显著上升。

Caly v1 的目标不是做一个可任意编程的自动化平台，而是做一个可靠的本地控制平面。因此自动化能力必须受限、可解释，并且复用现有控制语义。

---

## 2. Decision

Caly 采纳以下决策：

1. **v1 自动化采用受限声明式 DSL。**
2. 自动化规则由以下要素组成：
   - trigger
   - condition
   - action
   - cooldown
   - max_runs
3. 自动化动作不能直接执行任意系统操作，而必须重新进入普通 `Command -> Job` 管线。
4. v1 明确不支持：
   - 任意 Lua / JS
   - shell command
   - 任意 HTTP 调用
   - 任意文件写入
   - 任意数据库操作
5. 自动化规则必须可审计、可限流、可禁用、可测试。

---

## 3. Alternatives Considered

### 方案 A：直接提供脚本引擎（Lua/JS）

- 优点：
  - 灵活度高
- 缺点：
  - 权限和资源边界极难约束
  - 可维护性差
  - 用户脚本质量不可控
- 不采纳原因：
  - 超出 v1 控制平面的可靠性目标

### 方案 B：允许 shell hook

- 优点：
  - 实现简单
  - 对高级用户吸引力高
- 缺点：
  - 安全风险高
  - 跨平台差
  - 审计与回滚能力弱
- 不采纳原因：
  - 与最小权限和结构化控制原则冲突

### 方案 C：完全不做自动化

- 优点：
  - 最简单
- 缺点：
  - 缺乏关键实用性，如自动恢复、定时更新、策略自动切换
- 不采纳原因：
  - 会削弱 Caly 的控制面价值

---

## 4. Consequences

### Positive

- 自动化行为更可控
- 可复用 Command/Job/权限/幂等/审计体系
- 更容易在 TUI/CLI 中做结构化编辑与展示
- 更适合未来逐步扩展而不失控

### Negative / Trade-offs

- 灵活性不如脚本系统
- 需要逐步扩展 DSL 才能覆盖更多场景
- 某些高级用户需求可能需要等 v2 或外部 provider 方案

### Follow-up Work

- 冻结 AutomationRule schema
- 冻结触发器、条件和动作枚举
- 为自动化运行加入 cooldown / retry / audit 测试

---

## 5. Compatibility and Migration

v1 的自动化 DSL 应优先保证结构稳定与可迁移，而不是快速增加过多自由度。

未来若确需更强扩展能力，应优先考虑独立 provider process，而不是在主进程内嵌任意脚本引擎。

---

## 6. Notes

本 ADR 支撑：

- RFC-0001 中“自动化复用普通 Command 管线”和“v1 不做脚本引擎”的原则

一句话总结：

> Caly 的自动化应当是受限控制面能力的组合，而不是一门嵌入式脚本语言。