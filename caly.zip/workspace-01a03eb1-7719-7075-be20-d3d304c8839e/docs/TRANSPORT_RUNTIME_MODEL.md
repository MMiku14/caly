# Caly Transport Runtime Model

本文件说明为什么在 `SessionMachine`、`DaemonSession`、`DaemonTransport` 之外，还需要更高一层的 **transport runtime / session registry**。

---

## 1. 背景

单个 session 的状态机已经能表达：

- hello
- active
- close
- frame validation
- request handling
- stream follow

但 daemon 真正运行时还需要处理：

- 多个并发 session
- session id 到 transport 的映射
- hello timeout 的触发目标
- close / reconnect 的全局清理
- session inspection / diagnostics

因此，需要一个 registry/runtime 层，而不是让这些逻辑散落在各 handler 中。

---

## 2. 推荐层次

```text
SessionMachine     单会话状态约束
DaemonSession      单会话 server-side glue
DaemonTransport    单会话 transport boundary
SessionRegistry    多会话索引与调度
DaemonRuntime      runtime-level app + registry assembly
ServerLoop         client/server protocol loopback harness over runtime
```

---

## 3. 当前 skeleton 已有能力

当前代码已开始具备：

- `SessionRegistry`
- `SessionRegistryConfig`
- `SessionRegistrySnapshot`
- `DaemonRuntime`
- `ServerLoop`
- open / hello / frame / pull_stream / timeout / close / inspect / snapshot

这说明 transport runtime 已经开始从“概念”进入可实现结构。

---

## 4. 为什么这层重要

没有 registry/runtime 层时，容易出现：

- session id 管理分散
- reconnect 清理不一致
- timeout 和 close 路径无全局入口
- diagnostics 很难回答“当前有哪些打开的 session”

---

## 5. 一句话结论

> 如果 `SessionMachine` 解决的是“单连接是否合法”，那么 `SessionRegistry` 解决的是“整个 daemon 当前如何管理所有连接”，而 `ServerLoop` 负责把这些能力串成可验证的协议执行路径。