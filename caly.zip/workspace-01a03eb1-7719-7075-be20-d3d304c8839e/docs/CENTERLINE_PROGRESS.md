# Caly Centerline Progress

本文件专门跟踪 Caly 最重要的一条中心主链：

```text
Profile / Source / Override
  -> Caly IR
  -> ResolvedProfile
  -> Capability Validation
  -> CoreAdapter
  -> NativeValidation
  -> ApplyPlanning
  -> EffectPlan
  -> Daemon Query / Local+Remote Facade
```

---

## 1. 为什么要单独跟踪这条线

因为 Caly 最容易掉入的工程陷阱是：

- UI 和 daemon 看起来很忙
- IPC、watch、loopback、scenario 都很多
- 但真正的中心主链还没有接起来

所以需要一份专门文档回答：

> 中心主链到底接到哪一步了？

---

## 2. 当前已经接上的部分

当前已经具备：

- `caly-domain`
  - `Profile / Override / SelectionMemory`
  - group selection / tun builder helpers
- `caly-ir`
  - `CalyIr / ResolvedProfile / CompiledArtifact`
  - `CompiledArtifact` 已承载：
    - native format
    - entrypoint
    - media type
    - stable bytes
    - annotations
- `caly-pipeline`
  - `merge_profile(...)` 已开始真实消费：
    - profile attached sources
    - normalized source estimates
    - profile selections
    - override selectors
  - `resolve_ir(...)` 已开始执行：
    - selection memory replay
    - default selection recovery
    - reference integrity check
    - deterministic manifest / semantic digest / revision generation
  - `validate_semantic(...)` / `validate_capabilities(...)` 已开始做结构性检查
- `caly-core`
  - `CoreAdapter` / mock adapter / native helper 已开始承载更真实 artifact 语义
- `caly-mihomo`
  - 产出 YAML-shaped native artifact bytes
  - 区分 `ApiPatch / HotReload / Restart`
  - 产出 `EffectPlan`
- `caly-singbox`
  - 产出 JSON-shaped native artifact bytes
  - 区分 `Restart / RebuildAndRestart`
  - 产出 `EffectPlan`
- `caly-engine::apply`
  - 已能汇总：
    - resolved summary
    - compile summary
    - native validation result
    - apply reasons
    - effect steps / compensation steps
- `caly-daemon`
  - query path 已接入：
    - `ProfileOp::Plan`
    - `DiagnosticsOp::ExplainPipeline`
- `caly-app`
  - local/remote facade parity 已开始覆盖：
    - `profile.plan`
    - `diagnostics.explain_pipeline`

这意味着：

> 中心主链已经从“首次贯通骨架”推进到“能产出较真实的 resolved profile / native artifact / apply plan / effect plan，并被 daemon facade 调用”的状态。

---

## 3. 本轮新增的工程验证结论

当前 workspace 已能执行：

```bash
cargo check --workspace
```

这件事对 centerline 很关键，因为它意味着：

- 这条主链不再只是文档叙事
- 它已经能被真实编译检查约束
- `engine / daemon / app / cli` 的装配至少在类型层已闭合

换句话说：

> “中心线已接上” 现在不是主观判断，而是已有真实编译证据支撑。

---

## 4. 当前仍然缺的关键部分

仍需补齐：

1. 真实 parse / decode / normalize
2. 基于真实 source 内容的 typed semantic merge
3. capability registry / coverage matrix 驱动的系统校验
4. apply workflow 与 engine worker / storage snapshot / journal 的实接
5. daemon command path 对真实 apply 执行的闭环
6. real core integration（下载、校验、spawn、runtime API、回滚）

---

## 5. 本阶段的关键结论

本阶段已经明确把推进重心从外围协议壳拉回中心主链本身：

- merge 不再返回空图
- resolve 不再只拼占位 digest
- artifact 不再只是文件名 hint
- adapter 不再只返回一条 “accepted” 字符串
- apply 不再只返回 `kind + bool`
- daemon/local/remote facade 已经能直接拿中心线结果
- workspace 已能真实编译这条链

---

## 6. 一句话结论

> Caly 的真正进度，不取决于页面或命令数量，而取决于 `Profile / Source / Override -> IR -> ResolvedProfile -> Capability -> Native -> ApplyPlan -> EffectPlan -> Facade` 这条中心主链是否持续闭合。