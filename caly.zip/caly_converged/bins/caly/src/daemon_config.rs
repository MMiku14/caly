//! Daemon boot settings, resolved from the layered config.
//!
//! P8a: the read/parse surface (load_from + per-field parsers + error
//! type) moved up to `caly-cli::config` so offline CLI commands share one
//! loader with boot. This module keeps only the daemon-side model and the
//! boot-only resolution that touches `caly-server`/`caly-backends`
//! material (TLS paths, TUN mapping, dns_env, declared proxy groups).

use std::{net::SocketAddr, path::PathBuf};

use caly_daemon::composition::RuntimeTuning;
use caly_core::dns::DnsSettings;
use caly_core::domain::{Controllers, CoreKind, TunConfig};
use caly_daemon::platform::paths::CoreBinaryPaths;
use caly_core::profile::schema::AppConfig;
use caly_daemon::server::tcp::TlsMaterialPaths;

/// Every daemon boot setting, resolved from a single layered config load.
///
/// The per-field `*_from(root)` getters in [`caly_cli::ops::config`] remain
/// available for one-off CLI commands, but the daemon boot path must not
/// re-read and re-parse the same layered config once per field:
/// `resolve_daemon` loads once and derives every value (including the
/// environment overrides applied by each field getter) from that single
/// snapshot.
pub(crate) struct DaemonSettings {
    pub(crate) core_override: Option<CoreKind>,
    pub(crate) listen: Option<SocketAddr>,
    /// TLS material for the TCP listener (`None` = plaintext,
    /// loopback-only deployments, #57).
    pub(crate) tls_material: Option<TlsMaterialPaths>,
    /// Configured `daemon.auth_token`; when `Some` every
    /// transport demands it in the handshake (#58).
    pub(crate) auth_token: Option<String>,
    /// Daemon-side periodic subscription refresh cadence
    /// (`subscriptions.refresh_interval_minutes`, #59); `None`
    /// disables the background timer.
    pub(crate) subscription_refresh: Option<std::time::Duration>,
    pub(crate) tun: Option<TunConfig>,
    pub(crate) controllers: Controllers,
    pub(crate) binaries: CoreBinaryPaths,
    /// Declared subscription URLs: the legacy scalar first, then the
    /// `subscriptions.sources` entries in declaration order. Every entry
    /// is registered (and its cache revived) at daemon start — before
    /// this, `sources` were never registered and their caches were
    /// treated as ghosts (user-flow audit).
    pub(crate) subscription_urls: Vec<String>,
    pub(crate) tuning: RuntimeTuning,
    pub(crate) auto_start_core: bool,
}

/// Resolves all boot settings from one layered config load; an invalid config
/// fails the whole boot.
pub(crate) fn resolve_daemon(
    root: PathBuf,
) -> Result<DaemonSettings, caly_cli::ops::config::DaemonConfigError> {
    let config = caly_cli::ops::config::load_from(root)?;
    let kernel = caly_cli::ops::config::kernel_from_config(config.as_ref());
    let (system_proxy_host, system_proxy_port) =
        caly_cli::ops::config::system_proxy_endpoint_from_config(config.as_ref());
    let tuning = RuntimeTuning {
        dns: dns_settings_from_config(config.as_ref()),
        mixed_port: kernel.mixed_port,
        allow_lan: kernel.allow_lan,
        bind_address: kernel.bind_address.clone(),
        log_level: kernel.log_level,
        fetch_policy: caly_cli::ops::config::fetch_policy_from_config(config.as_ref()),
        system_proxy_host,
        system_proxy_port,
        tun_escalation: caly_cli::ops::config::tun_escalation_from_config(config.as_ref()),
        restart_initial_backoff_ms: kernel.restart.initial_backoff_ms,
        restart_max_backoff_ms: kernel.restart.max_backoff_ms,
        rules: caly_cli::ops::config::routing_rules_from_config(config.as_ref()),
        declared_groups: config.as_ref().map_or_else(Vec::new, |config| {
            caly_daemon::backends::core::declared_groups_to_domain(&config.proxy_groups)
        }),
        rule_providers: caly_cli::ops::config::rule_providers_from_config(config.as_ref()),
        sniffer: caly_cli::ops::config::sniffer_from_config(config.as_ref()),
        transparent: kernel.transparent,
        start_timeout_ms: kernel.start_timeout_ms,
        stop_timeout_ms: kernel.stop_timeout_ms,
        system_proxy_enabled: system_proxy_enabled_from_config(config.as_ref()),
    };
    Ok(DaemonSettings {
        core_override: caly_cli::ops::config::core_override_from_config(config.as_ref())?,
        listen: listen_from_config(config.as_ref())?,
        auth_token: caly_cli::ops::config::auth_token_from_config(config.as_ref()),
        tls_material: tls_material_from_config(config.as_ref()),
        subscription_refresh: subscription_refresh_from_config(config.as_ref()),
        tun: tun_config_from_config(config.as_ref()),
        controllers: caly_cli::ops::config::controllers_from_config(config.as_ref()),
        binaries: caly_cli::ops::config::core_binaries_from_config(config.as_ref()),
        subscription_urls: subscription_urls_from_config(config.as_ref()),
        tuning,
        auto_start_core: auto_start_core_from_config(config.as_ref()),
    })
}

/// Resolves the optional TCP listen address from an explicit config root.
///
/// Fails closed on non-loopback addresses unless the TCP transport's
/// protections are fully configured (TLS material plus an auth token);
/// see `listen_from_config` for the reconciled gate (#17/#57/#58).
#[cfg(test)]
pub fn listen_from(
    root: PathBuf,
) -> Result<Option<SocketAddr>, caly_cli::ops::config::DaemonConfigError> {
    listen_from_config(caly_cli::ops::config::load_from(root)?.as_ref())
}

/// Fails closed on non-loopback addresses unless BOTH transport
/// protections are configured: TLS (`daemon.tls_enabled`, #57)
/// and a handshake admission token (`daemon.auth_token`, #58).
/// Serving a remote control plane without both would expose an
/// unauthenticated endpoint per the schema's own contract; a
/// loopback listener needs neither (local-only trust model).
pub(crate) fn listen_from_config(
    config: Option<&AppConfig>,
) -> Result<Option<SocketAddr>, caly_cli::ops::config::DaemonConfigError> {
    let Some(config) = config else {
        return Ok(None);
    };
    let address = config
        .daemon
        .listen
        .parse::<SocketAddr>()
        .map_err(|_| caly_cli::ops::config::DaemonConfigError::InvalidListenAddress)?;
    if address.ip().is_loopback() {
        return Ok(Some(address));
    }
    // Remote listen: honoured exactly when the schema's own
    // contract is fully configured — TLS on, cert + key present,
    // and an admission token set (#17 reconciled with #57/#58).
    let tls_ready = config.daemon.tls_enabled
        && config.daemon.tls_cert_path.is_some()
        && config.daemon.tls_key_path.is_some();
    if tls_ready && caly_cli::ops::config::auth_token_from_config(Some(config)).is_some() {
        return Ok(Some(address));
    }
    Err(caly_cli::ops::config::DaemonConfigError::RemoteListenUnavailable)
}

/// Daemon-side periodic subscription refresh cadence (#59):
/// `Some(duration)` when `subscriptions.refresh_interval_minutes`
/// is a positive number of minutes, `None` when the operator
/// left the timer disabled (the default).
pub(crate) fn subscription_refresh_from_config(
    config: Option<&AppConfig>,
) -> Option<std::time::Duration> {
    let minutes = config?.subscriptions.refresh_interval_minutes;
    if minutes == 0 {
        return None;
    }
    Some(std::time::Duration::from_secs(minutes.saturating_mul(60)))
}

/// Whether the daemon serves the TCP listener through TLS
/// (#57). Mirrors the schema gate: needs `tls_enabled` plus both
/// material paths.
pub(crate) fn tls_enabled_from_config(config: Option<&AppConfig>) -> bool {
    config.is_some_and(|config| {
        config.daemon.tls_enabled
            && config.daemon.tls_cert_path.is_some()
            && config.daemon.tls_key_path.is_some()
    })
}

/// TLS material for the TCP listener (`None` when TLS is off or
/// incompletely configured).
pub(crate) fn tls_material_from_config(config: Option<&AppConfig>) -> Option<TlsMaterialPaths> {
    if !tls_enabled_from_config(config) {
        return None;
    }
    let daemon = &config?.daemon;
    Some(TlsMaterialPaths {
        certificate_chain: std::path::PathBuf::from(daemon.tls_cert_path.as_ref()?),
        private_key: std::path::PathBuf::from(daemon.tls_key_path.as_ref()?),
    })
}

pub(crate) fn subscription_urls_from_config(config: Option<&AppConfig>) -> Vec<String> {
    let Some(config) = config else {
        return Vec::new();
    };
    let mut urls = Vec::new();
    if let Some(legacy) = config.subscriptions.url.clone() {
        urls.push(legacy);
    }
    urls.extend(
        config
            .subscriptions
            .sources
            .iter()
            .map(|source| source.url.clone()),
    );
    urls
}

pub(crate) fn auto_start_core_from_config(config: Option<&AppConfig>) -> bool {
    config
        .as_ref()
        .is_none_or(|config| config.daemon.auto_start_core)
}

/// Resolves DNS settings from an explicit config root.
#[cfg(test)]
pub fn dns_settings_from(root: PathBuf) -> Option<DnsSettings> {
    if std::env::var_os("CALY_DNS_ENABLE").is_some() {
        return caly_daemon::backends::dns_env::dns_from_env();
    }
    dns_settings_from_config(caly_cli::ops::config::load_from(root).ok().flatten().as_ref())
}

pub(crate) fn dns_settings_from_config(config: Option<&AppConfig>) -> Option<DnsSettings> {
    if std::env::var_os("CALY_DNS_ENABLE").is_some() {
        return caly_daemon::backends::dns_env::dns_from_env();
    }
    let config = config.as_ref()?;
    config.dns.to_settings()
}

fn tun_config_from_config(config: Option<&AppConfig>) -> Option<caly_core::domain::TunConfig> {
    let config = config?;
    // Shared with the per-apply re-read in the config backends, so the boot
    // resolution and every later `config apply` agree on the same mapping.
    caly_daemon::backends::config::tun_config_from_schema(config)
}

/// Whether the desktop system proxy should be engaged during boot.
fn system_proxy_enabled_from_config(config: Option<&AppConfig>) -> bool {
    config
        .as_ref()
        .is_some_and(|config| config.system_proxy.enabled)
}

#[cfg(test)]
mod daemon_config_tests {
//! Unit tests for the daemon boot settings module (P8a: the read/parse
//! surface tests moved to caly-cli/src/config/tests.rs; these cover the
//! host-side model: listen gate, TLS, TUN mapping, single-load resolve).

use super::*;
use std::{
    fs,
    time::{SystemTime, UNIX_EPOCH},
};

fn temp_root(tag: &str) -> PathBuf {
    let nanos = SystemTime::now()
        .duration_since(UNIX_EPOCH)
        .map_or_else(|_| 0, |duration| duration.as_nanos());
    let dir = std::env::temp_dir().join(format!("caly-daemon-config-{tag}-{nanos}"));
    fs::create_dir_all(&dir).unwrap_or_default();
    dir
}

#[test]
fn absent_config_yields_no_tcp_listen() -> Result<(), String> {
    let root = temp_root("listen-absent");
    assert_eq!(
        listen_from(root.clone()).map_err(|e| format!("{e:?}"))?,
        None
    );
    fs::remove_dir_all(&root).ok();
    Ok(())
}

#[test]
fn non_loopback_listen_fails_closed() {
    let root = temp_root("listen-remote");
    // Non-loopback is only served when TLS AND the admission
    // token are BOTH configured; anything less must fail closed
    // at boot (#17). TLS + auth but NO certificate/key material
    // still refuses.
    fs::write(
        root.join("config.yaml"),
        "schema_version: 1\ncore: mihomo\ndaemon:\n  listen: 192.168.1.10:17890\n  tls_enabled: true\n  auth_token: secret\n",
    )
    .unwrap_or_default();
    // Fail closed: the strict layered load itself rejects the
    // TLS-without-material config (`TlsMaterialMissing`), so the
    // address never even reaches the listen gate. Either a
    // schema-layer or a listen-layer error is correct here —
    // the contract is "boot refuses", which both honour.
    assert!(
        matches!(
            listen_from(root.clone()),
            Err(caly_cli::ops::config::DaemonConfigError::RemoteListenUnavailable
                | caly_cli::ops::config::DaemonConfigError::Layered(_))
        ),
        "remote listen with incomplete TLS material must fail closed"
    );
    fs::remove_dir_all(&root).ok();
}

#[test]
fn non_loopback_listen_with_tls_and_auth_is_served() {
    let root = temp_root("listen-remote-ok");
    // The full contract satisfied: TLS enabled with cert/key
    // paths plus an admission token. The boot path must honour
    // the address (the schema validates the same combination).
    fs::write(
        root.join("config.yaml"),
        "schema_version: 1\ncore: mihomo\ndaemon:\n  listen: 192.168.1.10:17890\n  tls_enabled: true\n  tls_cert_path: /tmp/daemon.pem\n  tls_key_path: /tmp/daemon-key.pem\n  auth_token: secret\n",
    )
    .unwrap_or_default();
    assert_eq!(
        listen_from(root.clone()).map_err(|error| format!("{error:?}")),
        Ok(Some(
            "192.168.1.10:17890"
                .parse()
                .expect("static socket addr parses")
        ))
    );
    fs::remove_dir_all(&root).ok();
}

#[test]
fn config_listen_parses_socket_address() -> Result<(), String> {
    let root = temp_root("listen");
    fs::write(
        root.join("config.yaml"),
        "schema_version: 1\ncore: mihomo\ndaemon:\n  listen: 127.0.0.1:18080\n",
    )
    .map_err(|e| e.to_string())?;
    assert_eq!(
        listen_from(root.clone()).map_err(|e| format!("{e:?}"))?,
        Some(
            "127.0.0.1:18080"
                .parse::<std::net::SocketAddr>()
                .map_err(|e| e.to_string())?
        )
    );
    fs::remove_dir_all(&root).ok();
    Ok(())
}

#[test]
fn config_tun_mtu_is_parsed() -> Result<(), String> {
    let root = temp_root("tun");
    fs::write(
        root.join("config.yaml"),
        "schema_version: 1\ncore: mihomo\ntun:\n  enabled: true\n  mtu: 1400\n",
    )
    .map_err(|e| e.to_string())?;
    let config = caly_cli::ops::config::load_from(root.clone())
        .map_err(|e| format!("{e:?}"))?
        .ok_or("no config")?;
    assert_eq!(config.tun.mtu, 1400);
    assert!(config.tun.enabled);
    fs::remove_dir_all(&root).ok();
    Ok(())
}

#[test]
fn tun_config_maps_stack_and_routes() -> Result<(), String> {
    let root = temp_root("tunstack");
    fs::write(
            root.join("config.yaml"),
            "schema_version: 1\ncore: mihomo\ntun:\n  enabled: true\n  mtu: 1400\n  stack: mixed\n  auto_route: false\n  strict_route: true\n",
        )
        .map_err(|e| e.to_string())?;
    let config = tun_config_from_config(
        caly_cli::ops::config::load_from(root.clone())
            .map_err(|e| format!("{e:?}"))?
            .as_ref(),
    )
    .ok_or("no tun config")?;
    assert_eq!(config.stack(), caly_core::domain::TunStack::Mixed);
    assert!(!config.auto_route());
    assert!(config.strict_route());
    assert_eq!(config.mtu(), 1400);
    fs::remove_dir_all(&root).ok();
    Ok(())
}

#[test]
fn dns_settings_resolve_from_config() {
    let root = temp_root("dns-config");
    fs::write(
        root.join("config.yaml"),
        "schema_version: 1\ncore: mihomo\ndns:\n  enabled: true\n  mode: standard\n  nameservers:\n    - 8.8.8.8\n",
    )
    .unwrap_or_default();
    let settings = dns_settings_from(root.clone());
    let settings =
        settings.unwrap_or_else(|| panic!("dns settings must resolve from an enabled config"));
    assert!(settings.enabled());
    assert_eq!(settings.nameservers().len(), 1);
    fs::remove_dir_all(&root).ok();

    let root = temp_root("dns-disabled");
    fs::write(
        root.join("config.yaml"),
        "schema_version: 1\ncore: mihomo\ndns:\n  enabled: false\n",
    )
    .unwrap_or_default();
    assert!(dns_settings_from(root.clone()).is_none());
    fs::remove_dir_all(&root).ok();
}

#[test]
fn resolve_daemon_matches_per_field_getters() -> Result<(), String> {
    // A single layered load must derive every boot setting consistently with
    // the per-field getters (the getters themselves re-load, so any drift
    // between the two paths is a real bug).
    let root = temp_root("resolve-single-load");
    fs::write(
        root.join("config.yaml"),
        "schema_version: 1\ncore: mihomo\n\
         daemon:\n  listen: 127.0.0.1:17890\n\
         controllers:\n  mihomo: 127.0.0.1:9991\n  sing_box: 127.0.0.1:9992\n\
         kernel:\n  mixed_port: 8899\n  restart:\n    initial_backoff_ms: 300\n    max_backoff_ms: 5000\n\
         system_proxy:\n  enabled: false\n  host: 127.0.0.1\n\
         subscriptions:\n  url: https://example.invalid/sub\n",
    )
    .map_err(|e| e.to_string())?;

    let resolved = resolve_daemon(root.clone()).map_err(|e| format!("{e:?}"))?;
    let reloaded = caly_cli::ops::config::load_from(root.clone()).map_err(|e| format!("{e:?}"))?;

    assert_eq!(
        resolved.core_override,
        caly_cli::ops::config::core_override_from_config(reloaded.as_ref())
            .map_err(|e| format!("{e:?}"))?
    );
    assert_eq!(
        resolved.listen,
        listen_from_config(reloaded.as_ref()).map_err(|e| format!("{e:?}"))?
    );
    assert_eq!(
        resolved.controllers,
        caly_cli::ops::config::controllers_from_config(reloaded.as_ref())
    );
    assert_eq!(
        resolved.binaries,
        caly_cli::ops::config::core_binaries_from_config(reloaded.as_ref())
    );
    assert_eq!(
        resolved.subscription_urls,
        subscription_urls_from_config(reloaded.as_ref())
    );
    assert_eq!(
        resolved.auto_start_core,
        auto_start_core_from_config(reloaded.as_ref())
    );
    assert_eq!(resolved.tun, tun_config_from_config(reloaded.as_ref()));
    assert_eq!(
        resolved.tuning.dns,
        dns_settings_from_config(reloaded.as_ref())
    );
    assert_eq!(
        resolved.tuning.fetch_policy,
        caly_cli::ops::config::fetch_policy_from_config(reloaded.as_ref())
    );
    assert_eq!(resolved.tuning.mixed_port, 8899);
    assert_eq!(resolved.tuning.restart_initial_backoff_ms, 300);
    assert_eq!(resolved.tuning.restart_max_backoff_ms, 5000);
    assert_eq!(
        resolved.tuning.rules,
        caly_cli::ops::config::routing_rules_from_config(reloaded.as_ref())
    );
    assert_eq!(
        resolved.tuning.rule_providers,
        caly_cli::ops::config::rule_providers_from_config(reloaded.as_ref())
    );

    fs::remove_dir_all(&root).ok();
    Ok(())
}

#[test]
fn resolve_daemon_absent_config_falls_back_to_defaults() -> Result<(), String> {
    let root = temp_root("resolve-absent");
    let resolved = resolve_daemon(root.clone()).map_err(|e| format!("{e:?}"))?;
    assert_eq!(resolved.core_override, None);
    assert_eq!(resolved.listen, None);
    assert_eq!(resolved.tun, None);
    assert_eq!(resolved.subscription_urls, Vec::<String>::new());
    assert!(resolved.auto_start_core);
    assert_eq!(
        resolved.tuning.fetch_policy,
        caly_core::subscription::FetchPolicy::direct_default()
    );
    // The unconfigured daemon still carries the geo-only default rules
    // (kernel-native, no backing providers) so private/CN traffic is
    // DIRECT from the first start.
    assert_eq!(
        resolved.tuning.rules.len(),
        caly_core::profile::schema::default_rule_lines().len()
    );
    assert!(resolved.tuning.rule_providers.is_empty());
    fs::remove_dir_all(&root).ok();
    Ok(())
}

#[test]
fn rule_providers_resolve_into_runtime_tuning() -> Result<(), String> {
    use caly_core::domain::{RuleProviderBehavior, RuleProviderFormat, RuleProviderSource};
    let root = temp_root("rule-providers-tuning");
    fs::write(
        root.join("config.yaml"),
        "schema_version: 1\n\
         core: mihomo\n\
         rule_providers:\n\
         \x20 - name: my-google\n\
         \x20\x20\x20 type: http\n\
         \x20\x20\x20 behavior: domain\n\
         \x20\x20\x20 format: source\n\
         \x20\x20\x20 url: https://example.com/g.yaml\n\
         \x20\x20\x20 interval_ms: 86400000\n\
         \x20 - name: local\n\
         \x20\x20\x20 type: file\n\
         \x20\x20\x20 behavior: domain_suffix\n\
         \x20\x20\x20 format: source\n\
         \x20\x20\x20 path: /etc/caly/local.yaml\n\
         \x20 - name: inline-ads\n\
         \x20\x20\x20 type: inline\n\
         \x20\x20\x20 behavior: ip_cidr\n\
         \x20\x20\x20 format: binary\n\
         \x20\x20\x20 payload: 10.0.0.0/8\n\
         rules:\n\
         \x20 - RULE-SET,my-google,DIRECT\n\
         \x20 - GEOSITE,private,DIRECT\n\
         \x20 - GEOIP,CN,DIRECT\n\
         \x20 - MATCH,PROXY\n",
    )
    .map_err(|error| error.to_string())?;
    let settings = resolve_daemon(root.clone()).map_err(|error| error.to_string())?;
    fs::remove_dir_all(&root).ok();

    // Three user-declared rule providers reach the runtime tuning bundle
    // in declaration order.
    let tuning = settings.tuning;
    assert_eq!(tuning.rule_providers.len(), 3);
    assert_eq!(tuning.rule_providers[0].name.as_str(), "my-google");
    assert!(matches!(
        tuning.rule_providers[0].source,
        RuleProviderSource::Http { .. }
    ));
    assert!(matches!(
        tuning.rule_providers[0].behavior,
        RuleProviderBehavior::Domain
    ));
    assert!(matches!(
        tuning.rule_providers[0].format,
        RuleProviderFormat::Source
    ));
    assert!(matches!(
        tuning.rule_providers[1].source,
        RuleProviderSource::File { .. }
    ));
    assert!(matches!(
        tuning.rule_providers[1].behavior,
        RuleProviderBehavior::DomainSuffix
    ));
    // The inline provider's payload survives the round trip into the
    // domain `BoundedText` (the test never reaches the OS because the
    // bounded constructor has room for 256 KiB).
    if let RuleProviderSource::Inline { payload } = &tuning.rule_providers[2].source {
        assert_eq!(payload.as_str(), "10.0.0.0/8");
    } else {
        return Err("third provider must be inline".to_owned());
    }
    if let RuleProviderBehavior::IpCidr = tuning.rule_providers[2].behavior {
    } else {
        return Err("third provider must be ipcidr".to_owned());
    }

    // The four declared rules parse into the domain model in order; the
    // new RULE-SET and GEOSITE matchers reach the runtime rule list
    // alongside the legacy GEOIP and MATCH matchers.
    assert_eq!(tuning.rules.len(), 4);
    assert!(matches!(
        tuning.rules[0].matcher,
        caly_core::domain::RuleMatch::RuleSet(_)
    ));
    assert!(matches!(
        tuning.rules[1].matcher,
        caly_core::domain::RuleMatch::Geosite(_)
    ));
    assert!(matches!(
        tuning.rules[2].matcher,
        caly_core::domain::RuleMatch::Geoip(_)
    ));
    assert!(matches!(
        tuning.rules[3].matcher,
        caly_core::domain::RuleMatch::Match
    ));
    Ok(())
}

#[test]
fn rule_providers_unknown_reference_fails_validation() -> Result<(), String> {
    let root = temp_root("rule-providers-unknown");
    fs::write(
        root.join("config.yaml"),
        "schema_version: 1\ncore: mihomo\n\
         rules:\n\
         \x20\x20- RULE-SET,not-declared,DIRECT\n\
         \x20\x20- MATCH,PROXY\n",
    )
    .map_err(|error| error.to_string())?;
    let error = resolve_daemon(root.clone()).err();
    fs::remove_dir_all(&root).ok();
    let message = error.ok_or("expected validation failure")?;
    assert!(
        format!("{message:?}").contains("UnknownRuleProvider"),
        "expected UnknownRuleProvider, got {message:?}"
    );
    Ok(())
}

}
