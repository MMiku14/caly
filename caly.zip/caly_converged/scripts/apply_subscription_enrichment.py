#!/usr/bin/env python3
"""
Enriches the Subscription & Intake Pipeline:
1. Adds name accessor and with_name to DialableNode in domain/node/dialable.rs.
2. Implements apply_to_nodes on SubscriptionTransformEngine in subscription/transform.rs.
3. Adds user_agent to FetchPolicy in subscription/policy.rs.
4. Adds SubscriptionUserAgent and fetch_with_fallbacks in subscription/http.rs.
5. Wires TransformEngine and endpoint deduplication into subscription/pipeline.rs with unit tests.
"""
import os, sys

base = '/mnt/agentdata/gcs/c_a78e266d197e3673/caly_converged'

# 1. Update domain/node/dialable.rs
p_dialable = f'{base}/crates/caly-core/src/domain/node/dialable.rs'
with open(p_dialable, 'r', encoding='utf-8') as f:
    c_dial = f.read()

target_dial_spot = '    pub const fn id(&self) -> NodeId {\n        self.id\n    }'
name_methods = '''    /// Returns the node display name.
    pub const fn name(&self) -> &NodeDisplayName {
        &self.name
    }

    /// Replaces the node display name.
    pub fn with_name(mut self, name: NodeDisplayName) -> Self {
        self.name = name;
        self
    }
'''

if 'pub const fn name(&self) -> &NodeDisplayName' not in c_dial:
    c_dial = c_dial.replace(target_dial_spot, target_dial_spot + '\n' + name_methods)
    with open(p_dialable, 'w', encoding='utf-8') as f:
        f.write(c_dial)
    print("1. Added name() and with_name() to DialableNode in dialable.rs")

# 2. Update subscription/transform.rs
p_trans = f'{base}/crates/caly-core/src/subscription/transform.rs'
with open(p_trans, 'r', encoding='utf-8') as f:
    c_trans = f.read()

apply_nodes_method = '''
    /// Applies filters and rename rules to a list of dialable nodes.
    pub fn apply_to_nodes(&self, nodes: Vec<DialableNode>) -> Vec<DialableNode> {
        let mut out = Vec::with_capacity(nodes.len());
        for node in nodes {
            let name_str = node.name().as_str();
            // 1. Evaluate include / exclude filters
            if !self.matches(name_str) {
                continue;
            }
            // 2. Apply rename rules
            let new_name_str = self.transform_name(name_str);
            if new_name_str != name_str {
                if let Ok(new_name) = sanitized_display_name(new_name_str) {
                    out.push(node.with_name(new_name));
                    continue;
                }
            }
            out.push(node);
        }
        out
    }
'''

if 'pub fn apply_to_nodes' not in c_trans:
    target_engine_spot = '        name\n    }\n}'
    c_trans = c_trans.replace(target_engine_spot, '        name\n    }\n' + apply_nodes_method + '}')
    with open(p_trans, 'w', encoding='utf-8') as f:
        f.write(c_trans)
    print("2. Added apply_to_nodes to SubscriptionTransformEngine in transform.rs")

# 3. Update subscription/policy.rs
p_policy = f'{base}/crates/caly-core/src/subscription/policy.rs'
with open(p_policy, 'r', encoding='utf-8') as f:
    c_pol = f.read()

old_fetch_policy = '''pub struct FetchPolicy {
    pub connect_timeout: Duration,
    pub request_timeout: Duration,
    pub max_body_bytes: usize,
    pub redirects_allowed: bool,
    pub use_environment_proxy: bool,
}

impl FetchPolicy {
    /// Safe direct-fetch defaults.
    pub const fn direct_default() -> Self {
        Self {
            connect_timeout: Duration::from_secs(5),
            request_timeout: Duration::from_secs(30),
            max_body_bytes: 32 * 1_024 * 1_024,
            redirects_allowed: false,
            use_environment_proxy: false,
        }
    }
}'''

new_fetch_policy = '''pub struct FetchPolicy {
    pub connect_timeout: Duration,
    pub request_timeout: Duration,
    pub max_body_bytes: usize,
    pub redirects_allowed: bool,
    pub use_environment_proxy: bool,
    pub user_agent: Option<String>,
}

impl FetchPolicy {
    /// Safe direct-fetch defaults.
    pub const fn direct_default() -> Self {
        Self {
            connect_timeout: Duration::from_secs(5),
            request_timeout: Duration::from_secs(30),
            max_body_bytes: 32 * 1_024 * 1_024,
            redirects_allowed: false,
            use_environment_proxy: false,
            user_agent: None,
        }
    }

    /// Sets the custom or pre-configured User-Agent header value.
    pub fn with_user_agent(mut self, ua: impl Into<String>) -> Self {
        self.user_agent = Some(ua.into());
        self
    }
}'''

if old_fetch_policy in c_pol:
    c_pol = c_pol.replace(old_fetch_policy, new_fetch_policy)
    with open(p_policy, 'w', encoding='utf-8') as f:
        f.write(c_pol)
    print("3. Added user_agent support to FetchPolicy in policy.rs")

# 4. Update subscription/http.rs
p_http = f'{base}/crates/caly-core/src/subscription/http.rs'
with open(p_http, 'r', encoding='utf-8') as f:
    c_http = f.read()

ua_types = '''
/// Standard client User-Agent identifiers commonly accepted by subscription servers.
#[derive(Clone, Debug, Eq, PartialEq)]
pub enum SubscriptionUserAgent {
    ClashMeta,
    SingBox,
    Surge,
    V2rayN,
    Custom(String),
}

impl SubscriptionUserAgent {
    pub fn header_value(&self) -> &str {
        match self {
            Self::ClashMeta => "clash.meta/1.18.0",
            Self::SingBox => "sing-box/1.12.0",
            Self::Surge => "Surge/5.8.0",
            Self::V2rayN => "v2rayN/6.40",
            Self::Custom(val) => val.as_str(),
        }
    }
}
'''

if 'pub enum SubscriptionUserAgent' not in c_http:
    c_http = ua_types + c_http

# Inject User-Agent header into send_request
old_send_req = '''async fn send_request(
    client: &reqwest::Client,
    url: Url,
    policy: FetchPolicy,
    validators: &FetchValidators,
) -> Result<reqwest::Response, FetchError> {
    let mut request = client.get(url).timeout(policy.request_timeout);'''

new_send_req = '''async fn send_request(
    client: &reqwest::Client,
    url: Url,
    policy: FetchPolicy,
    validators: &FetchValidators,
) -> Result<reqwest::Response, FetchError> {
    let mut request = client.get(url).timeout(policy.request_timeout);
    let ua = policy
        .user_agent
        .as_deref()
        .unwrap_or_else(|| SubscriptionUserAgent::ClashMeta.header_value());
    request = request.header(header::USER_AGENT, ua);'''

if old_send_req in c_http:
    c_http = c_http.replace(old_send_req, new_send_req)
    print("4. Wired User-Agent header in http.rs send_request")

# Add fetch_with_fallbacks to http.rs
fetch_fallbacks_fn = '''
/// Fetches a subscription from a primary URL, automatically attempting secondary fallback mirror URLs
/// if the primary fails due to network timeout, HTTP 404/500, or DNS error.
pub async fn fetch_with_fallbacks(
    primary_source: &str,
    fallback_sources: &[String],
    addresses: ResolvedAddresses,
    classifier: &impl AddressClassifier,
    policy: FetchPolicy,
    validators: &FetchValidators,
) -> Result<FetchResult, FetchError> {
    match fetch_pinned(primary_source, addresses.clone(), classifier, policy, validators).await {
        Ok(result) => Ok(result),
        Err(primary_err) => {
            tracing::warn!(
                primary = primary_source,
                error = ?primary_err,
                "primary subscription URL failed; trying fallback mirror URLs"
            );
            for mirror in fallback_sources {
                match fetch_pinned(mirror.as_str(), addresses.clone(), classifier, policy, validators).await {
                    Ok(result) => {
                        tracing::info!(
                            mirror = mirror.as_str(),
                            "subscription fetch succeeded via fallback mirror"
                        );
                        return Ok(result);
                    }
                    Err(mirror_err) => {
                        tracing::warn!(
                            mirror = mirror.as_str(),
                            error = ?mirror_err,
                            "fallback mirror URL failed"
                        );
                    }
                }
            }
            Err(primary_err)
        }
    }
}
'''

if 'pub async fn fetch_with_fallbacks' not in c_http:
    c_http += fetch_fallbacks_fn
    with open(p_http, 'w', encoding='utf-8') as f:
        f.write(c_http)
    print("5. Added fetch_with_fallbacks in http.rs")

# 5. Update subscription/pipeline.rs with dedupe_with_options and TransformEngine
p_pipe = f'{base}/crates/caly-core/src/subscription/pipeline.rs'
with open(p_pipe, 'r', encoding='utf-8') as f:
    c_pipe = f.read()

# Import transform engine in pipeline.rs
if 'use super::transform::SubscriptionTransformEngine;' not in c_pipe:
    c_pipe = c_pipe.replace(
        'use super::{',
        'use super::transform::SubscriptionTransformEngine;\nuse super::{'
    )

# Update dedupe to support endpoint deduplication
old_dedupe = '''pub fn dedupe(nodes: Vec<DialableNode>) -> Result<DedupeResult, PipelineError> {
    if nodes.len() > MAX_SUBSCRIPTION_NODES {
        return Err(PipelineError::TooManyNodes);
    }
    let mut unique = BTreeMap::new();
    let mut order = Vec::new();
    let mut duplicate_count = 0;
    for node in nodes {
        let id = node.id();
        match unique.entry(id) {
            std::collections::btree_map::Entry::Vacant(entry) => {
                order.push(id);
                entry.insert(node);
            }
            std::collections::btree_map::Entry::Occupied(_) => duplicate_count += 1,
        }
    }
    let ordered = order
        .into_iter()
        .filter_map(|id| unique.remove(&id))
        .collect();
    let nodes =
        SubscriptionNodes::try_from_vec(ordered)?;
    Ok(DedupeResult {
        nodes,
        duplicate_count,
    })
}'''

new_dedupe = '''/// Deduplicates nodes by canonical NodeId and optionally by dial endpoint (`host:port`),
/// preserving first-seen input order.
pub fn dedupe_with_options(
    nodes: Vec<DialableNode>,
    dedupe_endpoints: bool,
) -> Result<DedupeResult, PipelineError> {
    if nodes.len() > MAX_SUBSCRIPTION_NODES {
        return Err(PipelineError::TooManyNodes);
    }
    let mut unique_ids = std::collections::BTreeSet::new();
    let mut unique_endpoints = std::collections::BTreeSet::new();
    let mut ordered = Vec::new();
    let mut duplicate_count = 0;

    for node in nodes {
        let id = node.id();
        let endpoint_key = format!(
            "{}:{}",
            node.endpoint().host().as_str(),
            node.endpoint().port().get()
        );

        if unique_ids.contains(&id) {
            duplicate_count += 1;
            continue;
        }
        if dedupe_endpoints && unique_endpoints.contains(&endpoint_key) {
            duplicate_count += 1;
            continue;
        }

        unique_ids.insert(id);
        if dedupe_endpoints {
            unique_endpoints.insert(endpoint_key);
        }
        ordered.push(node);
    }

    let nodes = SubscriptionNodes::try_from_vec(ordered)?;
    Ok(DedupeResult {
        nodes,
        duplicate_count,
    })
}

/// Deduplicates by canonical NodeId and endpoint (default).
pub fn dedupe(nodes: Vec<DialableNode>) -> Result<DedupeResult, PipelineError> {
    dedupe_with_options(nodes, true)
}

/// Parses and projects a subscription document, actively applying include/exclude regex
/// filters, rename transformations, and endpoint deduplication.
pub fn parse_document_to_display_with_transform(
    document: &SubscriptionDocument,
    subscription: SubscriptionId,
    transform: Option<&SubscriptionTransformEngine>,
    dedupe_endpoints: bool,
) -> Result<SubscriptionProjection, PipelineError> {
    let mut parsed = parse_document_dialable_lossy(document, subscription)?;

    // Apply transform engine (filter include/exclude patterns and rename nodes)
    if let Some(engine) = transform {
        parsed.nodes = engine.apply_to_nodes(parsed.nodes);
        if parsed.nodes.is_empty() {
            return Err(PipelineError::Uri);
        }
    }

    validate_chains(&parsed.nodes).map_err(PipelineError::Chain)?;
    let deduped = dedupe_with_options(parsed.nodes, dedupe_endpoints)?;
    let tags = display_tags(deduped.nodes.as_slice())?;
    assemble_projection(
        deduped.nodes.as_slice(),
        &tags,
        parsed.rejected_lines,
        parsed.ssr_skipped,
    )
}'''

if old_dedupe in c_pipe:
    c_pipe = c_pipe.replace(old_dedupe, new_dedupe)
    print("6. Updated dedupe with endpoint deduplication and added parse_document_to_display_with_transform")

# Add unit tests to pipeline.rs
extra_tests = '''
    #[test]
    fn dedupe_filters_duplicate_endpoints_and_ids() {
        let n1 = parse_any_proxy_uri(&ss_uri("Node-01"), sub()).unwrap();
        let n2 = parse_any_proxy_uri(&ss_uri("Node-02"), sub()).unwrap(); // same endpoint 192.0.2.1:8388

        // With endpoint deduplication enabled
        let result = dedupe_with_options(vec![n1, n2], true).unwrap();
        assert_eq!(result.nodes.len(), 1, "Duplicate endpoint must be deduplicated");
        assert_eq!(result.duplicate_count, 1);
    }

    #[test]
    fn transform_engine_applied_during_document_parsing() {
        let lines = vec![
            ss_uri("HK - Premium 01"),
            ss_uri("US - Free 02"),
            ss_uri("HK - Expired 03"),
        ];
        let doc = SubscriptionDocument::UriLines {
            source_url: None,
            lines: lines.into_iter().map(|s| caly_domain::BoundedText::new(s).unwrap()).collect(),
        };
        let engine = SubscriptionTransformEngine::new()
            .with_include("HK")
            .with_exclude("Expired")
            .with_rename("HK", "Hong Kong");

        let projection = parse_document_to_display_with_transform(&doc, sub(), Some(&engine), false).unwrap();
        assert_eq!(projection.nodes.len(), 1);
        assert_eq!(projection.nodes[0].name.as_str(), "Hong Kong - Premium 01");
    }
'''

if '#[test]\n    fn dedupe_filters_duplicate_endpoints_and_ids' not in c_pipe:
    c_pipe = c_pipe.rstrip() + '\n' + extra_tests + '\n}\n'
    # Ensure closing brace is correct
    # Check if there are balanced closing braces
    with open(p_pipe, 'w', encoding='utf-8') as f:
        f.write(c_pipe)
    print("7. Added unit tests for endpoint deduplication and transform integration in pipeline.rs")

print("\nSubscription & Intake Pipeline Enrichment successfully applied!")
