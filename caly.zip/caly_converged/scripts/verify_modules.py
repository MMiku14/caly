#!/usr/bin/env python3
"""
Module Tree Consistency Verifier for Rust.
Scans all `mod <name>;` declarations across crates and verifies physical file existence.
"""
import os, sys, re

def verify_crate_modules(crate_src_dir):
    pattern = re.compile(r'(?:#\[path\s*=\s*\"([^\"]+)\"\]\s*)?(?:pub(?:\([^\)]+\))?\s+)?\bmod\s+([a-zA-Z_][a-zA-Z0-9_]*)\s*;', re.MULTILINE)
    missing = []
    
    for root, _, files in os.walk(crate_src_dir):
        for f in files:
            if not f.endswith('.rs'): continue
            path = os.path.join(root, f)
            with open(path, 'r', errors='ignore') as fh: content = fh.read()
            stripped = re.sub(r'//.*', '', content)
            matches = pattern.findall(stripped)
            current_dir = root if f in ('mod.rs', 'lib.rs', 'main.rs') else os.path.join(root, f[:-3])
            for exp, m in matches:
                if exp:
                    cand = os.path.join(root, exp)
                    if not os.path.exists(cand): missing.append((path, m, exp))
                else:
                    f_cand = os.path.join(current_dir, f'{m}.rs')
                    d_cand = os.path.join(current_dir, m, 'mod.rs')
                    alt_f = os.path.join(root, f'{m}.rs')
                    alt_d = os.path.join(root, m, 'mod.rs')
                    if not (os.path.exists(f_cand) or os.path.exists(d_cand) or os.path.exists(alt_f) or os.path.exists(alt_d)):
                        missing.append((path, m, None))
    return missing

def main():
    root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    crates = ['caly-core', 'caly-kernel', 'caly-daemon', 'caly-cli']
    total_missing = []
    for c in crates:
        src = os.path.join(root, 'crates', c, 'src')
        if os.path.exists(src):
            missing = verify_crate_modules(src)
            if missing:
                total_missing.extend(missing)
    if total_missing:
        print(f"[FAIL] Found {len(total_missing)} unresolvable module declarations:")
        for path, m, exp in total_missing:
            print(f"  In {path}: mod {m} (path={exp})")
        sys.exit(1)
    print(f"[PASS] All module trees in all {len(crates)} converged crates are 100% resolved.")

if __name__ == "__main__":
    main()
