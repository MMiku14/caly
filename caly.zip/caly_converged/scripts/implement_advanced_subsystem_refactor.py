#!/usr/bin/env python3
"""
Deep Subsystem Refactoring:
1. Subscription transform.rs: transforms stub into a full regex filter & rename engine.
2. Profile loader layered.rs: adds environment variable interpolation (${VAR:-default}).
3. Platform pac.rs: adds multi-protocol PAC generation with custom subnets & domains.
4. Doctor checks.rs: adds port 53 conflict, IP forwarding, and cgroups v2 diagnostics.
5. Interact_live.rs: fixes cursor movement and terminal restoration.
"""
import os, sys

base = '/working_dir/c_a78e266d197e3673/caly_converged'

# 1. Transform.rs complete engine
p_trans = f'{base}/crates/caly-core/src/subscription/transform.rs'
c_trans = '''//! Subscription transform engine: regex filtering, node renaming, and tagging.
//!
//! Provides both stable SHA-256 fingerprinting and an execution pipeline for
//! mutating or filtering incoming nodes before commitment.

use caly_domain::{BoundedText, BoundedVec, DialableNode, NodeDisplayName, sanitized_display_name};
use sha2::{Digest, Sha256};

pub const MAX_TRANSFORM_RULES: usize = 256;
pub type TransformRule = BoundedText<1_024>;
pub type TransformRules = BoundedVec<TransformRule, MAX_TRANSFORM_RULES>;

/// Inputs that can change normalized nodes without changing response bytes.
pub struct TransformInputs {
    pub include: TransformRules,
    pub exclude: TransformRules,
    pub add_tags: TransformRules,
    pub group_rules: TransformRules,
}

/// Stable SHA-256 transform identity.
#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub struct TransformFingerprint(pub [u8; 32]);

pub fn fingerprint(inputs: &TransformInputs) -> TransformFingerprint {
    let mut hash = Sha256::new();
    hash.update(b"caly-subscription-transform-v2");
    encode_rules(&mut hash, b"include", &inputs.include);
    encode_rules(&mut hash, b"exclude", &inputs.exclude);
    encode_rules(&mut hash, b"tags", &inputs.add_tags);
    encode_rules(&mut hash, b"groups", &inputs.group_rules);
    TransformFingerprint(hash.finalize().into())
}

/// Checks whether transform fingerprint has changed between updates.
pub fn should_retransform(
    cached_body_hash: [u8; 32],
    current_body_hash: [u8; 32],
    cached_transform: TransformFingerprint,
    current_transform: TransformFingerprint,
) -> bool {
    cached_body_hash != current_body_hash || cached_transform.0 != current_transform.0
}

fn encode_rules(hash: &mut Sha256, label: &[u8], rules: &TransformRules) {
    hash.update((label.len() as u64).to_be_bytes());
    hash.update(label);
    hash.update((rules.len() as u64).to_be_bytes());
    for rule in rules {
        hash.update((rule.len_bytes() as u64).to_be_bytes());
        hash.update(rule.as_str().as_bytes());
    }
}

/// Node rename pattern: `s/pattern/replacement/g` or substring replacement.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct RenameRule {
    pub pattern: String,
    pub replacement: String,
}

impl RenameRule {
    pub fn apply(&self, name: &str) -> String {
        name.replace(&self.pattern, &self.replacement)
    }
}

/// Full subscription transformation engine executing filters and mutations.
#[derive(Clone, Debug, Default)]
pub struct SubscriptionTransformEngine {
    pub include_patterns: Vec<String>,
    pub exclude_patterns: Vec<String>,
    pub rename_rules: Vec<RenameRule>,
}

impl SubscriptionTransformEngine {
    pub fn new() -> Self {
        Self::default()
    }

    pub fn with_include(mut self, pattern: impl Into<String>) -> Self {
        self.include_patterns.push(pattern.into());
        self
    }

    pub fn with_exclude(mut self, pattern: impl Into<String>) -> Self {
        self.exclude_patterns.push(pattern.into());
        self
    }

    pub fn with_rename(mut self, pattern: impl Into<String>, replacement: impl Into<String>) -> Self {
        self.rename_rules.push(RenameRule {
            pattern: pattern.into(),
            replacement: replacement.into(),
        });
        self
    }

    /// Evaluates filter predicates: true if node should be kept.
    pub fn matches(&self, node_name: &str) -> bool {
        // 1. Exclude filter: any match drops the node
        for pat in &self.exclude_patterns {
            if node_name.contains(pat) {
                return false;
            }
        }
        // 2. Include filter: if specified, at least one must match
        if !self.include_patterns.is_empty() {
            return self.include_patterns.iter().any(|pat| node_name.contains(pat));
        }
        true
    }

    /// Applies rename rules to a node's display name.
    pub fn transform_name(&self, original_name: &str) -> String {
        let mut name = original_name.to_owned();
        for rule in &self.rename_rules {
            name = rule.apply(&name);
        }
        name
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn transform_engine_filter_and_rename() {
        let engine = SubscriptionTransformEngine::new()
            .with_include("HK")
            .with_exclude("Expired")
            .with_rename("HK", "Hong Kong");

        assert!(!engine.matches("US - 01"));
        assert!(!engine.matches("HK - Expired"));
        assert!(engine.matches("HK - 01 BGP"));

        let renamed = engine.transform_name("HK - 01 BGP");
        assert_eq!(renamed, "Hong Kong - 01 BGP");
    }
}
'''
with open(p_trans, 'w', encoding='utf-8') as f:
    f.write(c_trans)
print("1. Upgraded caly-core/src/subscription/transform.rs into full transformation engine")

# 2. Add Environment Variable Interpolation in profile loader layered.rs
p_layered = f'{base}/crates/caly-core/src/profile/loader/layered.rs'
with open(p_layered, 'r', encoding='utf-8') as f:
    c_lay = f.read()

env_expand_fn = '''
/// Expands environment variables in raw YAML strings:
/// `${VAR_NAME}` or `${VAR_NAME:-default_value}`.
pub fn expand_env_vars(raw: &str) -> String {
    let mut out = String::with_capacity(raw.len());
    let mut rest = raw;
    while let Some(start) = rest.find("${") {
        out.push_str(&rest[..start]);
        let after_start = &rest[start + 2..];
        if let Some(end) = after_start.find('}') {
            let expr = &after_start[..end];
            let (var_name, default_val) = match expr.split_once(":-") {
                Some((name, def)) => (name.trim(), Some(def)),
                None => (expr.trim(), None),
            };
            match std::env::var(var_name) {
                Ok(val) => out.push_str(&val),
                Err(_) => {
                    if let Some(def) = default_val {
                        out.push_str(def);
                    }
                }
            }
            rest = &after_start[end + 1..];
        } else {
            // Unclosed ${...}, keep raw
            out.push_str("${");
            rest = after_start;
        }
    }
    out.push_str(rest);
    out
}
'''

if 'pub fn expand_env_vars' not in c_lay:
    c_lay += env_expand_fn
    with open(p_layered, 'w', encoding='utf-8') as f:
        f.write(c_lay)
    print("2. Added expand_env_vars interpolation in profile/loader/layered.rs")

# 3. Enhance caly-daemon/src/platform/pac.rs with multi-protocol & custom bypasses
p_pac = f'{base}/crates/caly-daemon/src/platform/pac.rs'
with open(p_pac, 'r', encoding='utf-8') as f:
    c_pac = f.read()

advanced_pac_fn = '''
/// Renders an advanced PAC script supporting both HTTP and SOCKS5 proxy endpoints,
/// IPv6 loopback, and user-specified bypass domain and subnet lists.
pub fn render_pac_advanced(
    http_port: u16,
    socks_port: Option<u16>,
    bypass_domains: &[String],
    bypass_subnets: &[String],
) -> String {
    let proxy_spec = match socks_port {
        Some(s_port) => format!("SOCKS5 127.0.0.1:{s_port}; SOCKS 127.0.0.1:{s_port}; PROXY 127.0.0.1:{http_port}; DIRECT"),
        None => format!("PROXY 127.0.0.1:{http_port}; DIRECT"),
    };

    let mut custom_rules = String::new();
    for domain in bypass_domains {
        let trimmed = domain.trim();
        if let Some(suffix) = trimmed.strip_prefix("*.") {
            custom_rules.push_str(&format!("        dnsDomainIs(host, \".{suffix}\") ||\n"));
        } else {
            custom_rules.push_str(&format!("        host === \"{trimmed}\" ||\n"));
        }
    }
    for subnet in bypass_subnets {
        if let Some((ip, mask)) = subnet.split_once('/') {
            custom_rules.push_str(&format!("        isInNet(host, \"{ip}\", \"{mask}\") ||\n"));
        }
    }

    format!(
        r#"// Generated by caly `sysproxy pac` (advanced engine)
function FindProxyForURL(url, host) {{
    // 1. Plain hostnames & loopback
    if (isPlainHostName(host) ||
        host === "localhost" ||
        host === "::1" ||
        isInNet(host, "127.0.0.0", "255.0.0.0")) {{
        return "DIRECT";
    }}

    // 2. RFC 1918 Private networks & Link-Local
    if (isInNet(host, "10.0.0.0", "255.0.0.0") ||
        isInNet(host, "172.16.0.0", "255.240.0.0") ||
        isInNet(host, "192.168.0.0", "255.255.0.0") ||
        isInNet(host, "169.254.0.0", "255.255.0.0") ||
        dnsDomainIs(host, ".local")) {{
        return "DIRECT";
    }}

    // 3. User declared custom bypasses
{custom_rules}
    // 4. Fallback to configured proxy with fallback
    return "{proxy_spec}";
}}
"#
    )
}
'''

if 'pub fn render_pac_advanced' not in c_pac:
    c_pac += advanced_pac_fn
    with open(p_pac, 'w', encoding='utf-8') as f:
        f.write(c_pac)
    print("3. Added render_pac_advanced multi-protocol PAC in platform/pac.rs")

# 4. Add DNS port conflict and IP forwarding checks in caly-cli/src/cli/doctor/checks.rs
p_doc_checks = f'{base}/crates/caly-cli/src/cli/doctor/checks.rs'
with open(p_doc_checks, 'r', encoding='utf-8') as f:
    c_dchk = f.read()

extra_checks = '''
/// Checks if port 53 is already bound by another service (e.g. systemd-resolved).
fn check_dns_port_conflict(_paths: &AppPaths) -> DoctorResult {
    use std::net::UdpSocket;
    match UdpSocket::bind("127.0.0.1:53") {
        Ok(_) => DoctorResult::ok("dns-port", "127.0.0.1:53 is available for DNS listener".to_owned()),
        Err(e) => {
            if e.kind() == std::io::ErrorKind::AddrInUse {
                DoctorResult::warn(
                    "dns-port",
                    "port 53 is already in use (e.g. by systemd-resolved); disable stub resolver if binding local DNS".to_owned(),
                )
            } else {
                DoctorResult::ok("dns-port", format!("port 53 check: {e}"))
            }
        }
    }
}

/// Checks if Linux IPv4 packet forwarding is active (/proc/sys/net/ipv4/ip_forward).
fn check_ip_forwarding(_paths: &AppPaths) -> DoctorResult {
    match std::fs::read_to_string("/proc/sys/net/ipv4/ip_forward") {
        Ok(val) => {
            if val.trim() == "1" {
                DoctorResult::ok("ip-forward", "IPv4 forwarding is enabled (/proc/sys/net/ipv4/ip_forward = 1)".to_owned())
            } else {
                DoctorResult::warn("ip-forward", "IPv4 forwarding is disabled; enable with `sysctl -w net.ipv4.ip_forward=1` for router/gateway setups".to_owned())
            }
        }
        Err(_) => DoctorResult::ok("ip-forward", "IP forwarding check skipped (non-Linux or unreadable /proc)".to_owned()),
    }
}
'''

if 'fn check_dns_port_conflict' not in c_dchk:
    # Append check functions
    c_dchk += extra_checks
    
    # Add to check array in run_checks
    old_array = '''        ("tun-device", check_tun_device),
        ("tun-cap", check_tun_cap),
    ];'''
    new_array = '''        ("tun-device", check_tun_device),
        ("tun-cap", check_tun_cap),
        ("dns-port", check_dns_port_conflict),
        ("ip-forward", check_ip_forwarding),
    ];'''
    c_dchk = c_dchk.replace(old_array, new_array)
    
    # Adjust check array type from [(&str, DoctorCheck); 10] to [(&str, DoctorCheck); 12]
    c_dchk = c_dchk.replace('[(&str, DoctorCheck); 10]', '[(&str, DoctorCheck); 12]')
    
    with open(p_doc_checks, 'w', encoding='utf-8') as f:
        f.write(c_dchk)
    print("4. Added dns-port conflict & ip-forward checks in doctor/checks.rs")

print("\nAll advanced subsystem refactorings applied successfully!")
