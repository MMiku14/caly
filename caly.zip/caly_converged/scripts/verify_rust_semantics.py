#!/usr/bin/env python3
"""
Comprehensive Static Analysis Gatekeeper for Rust (no cargo/rustc required).

Enforces:
1. Syntax & Token Checks:
   - Delimiter balance: (), {}, [] with precise line/column reporting.
   - Unclosed tokens: string literals, nested block comments, raw string hashes.
   - Declaration integrity & keyword sanity (detects broken signatures and typos).
2. Safety & Policy Gatekeeping:
   - Zero `unsafe` code in crates/modules declaring `#![forbid(unsafe_code)]`.
   - Zero unhandled `.unwrap()` calls in critical non-test paths.
3. Module & File Integrity:
   - Resolves every `mod foo;` / `pub mod foo;` to an existing `.rs` file.
   - Verifies all `.rs` files in `src/` are connected to the module tree (0 orphans).
"""

import os
import sys
import re

# -----------------------------------------------------------------------------
# 1. Lexical & Token Verification
# -----------------------------------------------------------------------------

OPENING_DELIMITERS = {'(': ')', '{': '}', '[': ']'}
CLOSING_DELIMITERS = {')': '(', '}': '{', ']': '['}

KEYWORD_TYPOS = {
    'fnction': 'fn',
    'fnc': 'fn',
    'strcut': 'struct',
    'sturct': 'struct',
    'enmu': 'enum',
    'imlp': 'impl',
    'publci': 'pub',
    'plublic': 'pub',
    'asnyc': 'async',
    'macth': 'match',
    'retrun': 'return',
}

class LexerError:
    def __init__(self, message, line, col, file_path):
        self.message = message
        self.line = line
        self.col = col
        self.file_path = file_path

    def __str__(self):
        return f"{self.file_path}:{self.line}:{self.col}: {self.message}"


def analyze_rust_source(file_path):
    """
    Tokenizes and analyzes a single Rust source file.
    Returns (errors, tokens_outside_comments_and_strings, has_forbid_unsafe).
    """
    with open(file_path, "r", encoding="utf-8", errors="ignore") as f:
        src = f.read()

    errors = []
    tokens = []
    has_forbid_unsafe = "#![forbid(unsafe_code)]" in src or "#![deny(unsafe_code)]" in src

    stack = []
    i, n = 0, len(src)
    line, col = 1, 1

    current_word = []
    current_word_start = (1, 1)

    def flush_word():
        nonlocal current_word
        if current_word:
            word = "".join(current_word)
            tokens.append((word, current_word_start[0], current_word_start[1]))
            if word in KEYWORD_TYPOS:
                errors.append(
                    LexerError(
                        f"Suspected keyword typo '{word}'; did you mean '{KEYWORD_TYPOS[word]}'?",
                        current_word_start[0],
                        current_word_start[1],
                        file_path,
                    )
                )
            current_word = []

    while i < n:
        c = src[i]

        if c == "\n":
            flush_word()
            line += 1
            col = 1
            i += 1
            continue

        # Line comment: // ...
        if c == "/" and i + 1 < n and src[i + 1] == "/":
            flush_word()
            while i < n and src[i] != "\n":
                i += 1
            continue

        # Block comment: /* ... */ (nested)
        if c == "/" and i + 1 < n and src[i + 1] == "*":
            flush_word()
            comment_start_line, comment_start_col = line, col
            i += 2
            col += 2
            nest_depth = 1
            while i < n and nest_depth > 0:
                if src[i] == "/" and i + 1 < n and src[i + 1] == "*":
                    nest_depth += 1
                    i += 2
                    col += 2
                elif src[i] == "*" and i + 1 < n and src[i + 1] == "/":
                    nest_depth -= 1
                    i += 2
                    col += 2
                else:
                    if src[i] == "\n":
                        line += 1
                        col = 1
                    else:
                        col += 1
                    i += 1
            if nest_depth > 0:
                errors.append(
                    LexerError(
                        "Unclosed block comment (reached EOF without */)",
                        comment_start_line,
                        comment_start_col,
                        file_path,
                    )
                )
            continue

        # Raw string literal: r#"..."# or r###"..."###
        if c == "r" and i + 1 < n and (src[i + 1] == '"' or src[i + 1] == "#"):
            flush_word()
            raw_start_line, raw_start_col = line, col
            i += 1
            col += 1
            hash_count = 0
            while i < n and src[i] == "#":
                hash_count += 1
                i += 1
                col += 1
            if i < n and src[i] == '"':
                i += 1
                col += 1
                closing_seq = '"' + ("#" * hash_count)
                closed = False
                while i < n:
                    if src[i] == "\n":
                        line += 1
                        col = 1
                        i += 1
                        continue
                    if src.startswith(closing_seq, i):
                        i += len(closing_seq)
                        col += len(closing_seq)
                        closed = True
                        break
                    i += 1
                    col += 1
                if not closed:
                    errors.append(
                        LexerError(
                            f"Unclosed raw string literal (missing matching {closing_seq})",
                            raw_start_line,
                            raw_start_col,
                            file_path,
                        )
                    )
                continue

        # Standard string literal: "..."
        if c == '"':
            flush_word()
            str_start_line, str_start_col = line, col
            i += 1
            col += 1
            closed = False
            while i < n:
                if src[i] == "\\":
                    i += 2
                    col += 2
                    continue
                if src[i] == '"':
                    i += 1
                    col += 1
                    closed = True
                    break
                if src[i] == "\n":
                    # In standard Rust, raw string or backslash-escaped newline is needed for multi-line
                    # but multiline strings without escapes are also allowed in Rust. Track line.
                    line += 1
                    col = 1
                    i += 1
                    continue
                i += 1
                col += 1
            if not closed:
                errors.append(
                    LexerError(
                        "Unclosed string literal (missing closing quote \")",
                        str_start_line,
                        str_start_col,
                        file_path,
                    )
                )
            continue

        # Character literal vs lifetime: 'a' vs 'a
        if c == "'":
            flush_word()
            if i + 2 < n and src[i + 1] != "\\" and src[i + 2] == "'":
                i += 3
                col += 3
                continue
            elif i + 3 < n and src[i + 1] == "\\" and src[i + 3] == "'":
                i += 4
                col += 4
                continue
            else:
                # Lifetime identifier like 'a, 'static
                i += 1
                col += 1
                while i < n and (src[i].isalnum() or src[i] == "_"):
                    i += 1
                    col += 1
                continue

        # Delimiters
        if c in OPENING_DELIMITERS:
            flush_word()
            stack.append((c, line, col))
            i += 1
            col += 1
            continue

        if c in CLOSING_DELIMITERS:
            flush_word()
            expected_open = CLOSING_DELIMITERS[c]
            if not stack:
                errors.append(
                    LexerError(
                        f"Unmatched closing delimiter '{c}'",
                        line,
                        col,
                        file_path,
                    )
                )
            else:
                top_open, top_line, top_col = stack.pop()
                if top_open != expected_open:
                    errors.append(
                        LexerError(
                            f"Mismatched delimiter: expected '{OPENING_DELIMITERS[top_open]}', got '{c}' (opened at line {top_line}, col {top_col})",
                            line,
                            col,
                            file_path,
                        )
                    )
            i += 1
            col += 1
            continue

        # Accumulate word tokens (for identifier / keyword checks)
        if c.isalnum() or c == "_":
            if not current_word:
                current_word_start = (line, col)
            current_word.append(c)
        else:
            flush_word()

        i += 1
        col += 1

    flush_word()

    # Any remaining open delimiters
    for open_char, open_line, open_col in stack:
        errors.append(
            LexerError(
                f"Unclosed delimiter '{open_char}' (opened at line {open_line}, col {open_col})",
                open_line,
                open_col,
                file_path,
            )
        )

    return errors, tokens, has_forbid_unsafe


# -----------------------------------------------------------------------------
# 2. Safety & Policy Gatekeeping
# -----------------------------------------------------------------------------

def check_safety_policy(crate_name, file_path, tokens, is_forbid_unsafe):
    """
    Checks that no `unsafe` tokens exist in crates or modules with #![forbid(unsafe_code)].
    """
    violations = []
    if not is_forbid_unsafe:
        return violations

    for idx, (token, line, col) in enumerate(tokens):
        if token == "unsafe":
            # Check if followed by { or fn or trait or impl
            next_tokens = [t[0] for t in tokens[idx + 1 : idx + 4]]
            violations.append(
                f"{file_path}:{line}:{col}: Prohibited `unsafe` keyword in crate '{crate_name}' declaring #![forbid(unsafe_code)]"
            )

    return violations


def check_unwrap_policy(file_path):
    """
    Scans for .unwrap() calls outside of tests.
    """
    with open(file_path, "r", encoding="utf-8", errors="ignore") as f:
        src = f.read()

    # Entire test file or in tests/ dir is allowed
    is_test_file = (
        "test" in os.path.basename(file_path)
        or "/tests/" in file_path
        or file_path.endswith("_test.rs")
    )
    if is_test_file:
        return []

    lines = src.splitlines()
    violations = []
    in_cfg_test = False

    for line_num, line in enumerate(lines, 1):
        stripped = line.strip()
        if "#[cfg(test)]" in stripped:
            in_cfg_test = True
        if stripped.startswith("//") or stripped.startswith("/*") or stripped.startswith("*"):
            continue

        code_only = re.sub(r"//.*", "", line)
        if ".unwrap()" in code_only and not in_cfg_test:
            violations.append(
                f"{file_path}:{line_num}: Unhandled `.unwrap()` call in production path: {stripped}"
            )

    return violations


# -----------------------------------------------------------------------------
# 3. Module & File Integrity (Orphan Detection & Resolution)
# -----------------------------------------------------------------------------

MOD_DECL_PATTERN = re.compile(
    r'(?:#\[path\s*=\s*\"([^\"]+)\"\]\s*)?(?:pub(?:\([^\)]+\))?\s+)?\bmod\s+([a-zA-Z_][a-zA-Z0-9_]*)\s*;',
    re.MULTILINE,
)

def verify_crate_module_graph(crate_name, src_dir, roots):
    """
    Traces all reachable modules from root files (lib.rs, main.rs) and compares
    against all .rs files in src_dir to find unresolvable modules and orphans.
    """
    reachable = set()
    unresolvable = []

    def visit(file_path):
        canonical = os.path.realpath(file_path)
        if canonical in reachable:
            return
        reachable.add(canonical)

        try:
            with open(file_path, "r", encoding="utf-8", errors="ignore") as fh:
                content = fh.read()
        except Exception:
            return

        stripped = re.sub(r"//.*", "", content)
        dir_name = os.path.dirname(file_path)
        base_name = os.path.basename(file_path)
        stem = base_name[:-3] if base_name.endswith(".rs") else base_name

        matches = MOD_DECL_PATTERN.findall(stripped)
        for path_attr, mod_name in matches:
            resolved = None
            if path_attr:
                cand = os.path.normpath(os.path.join(dir_name, path_attr))
                if os.path.exists(cand):
                    resolved = cand
            else:
                if stem in ("mod", "lib", "main"):
                    candidates = [
                        os.path.join(dir_name, f"{mod_name}.rs"),
                        os.path.join(dir_name, mod_name, "mod.rs"),
                    ]
                else:
                    candidates = [
                        os.path.join(dir_name, stem, f"{mod_name}.rs"),
                        os.path.join(dir_name, stem, mod_name, "mod.rs"),
                        os.path.join(dir_name, f"{mod_name}.rs"),
                        os.path.join(dir_name, mod_name, "mod.rs"),
                    ]
                for cand in candidates:
                    if os.path.exists(cand):
                        resolved = cand
                        break

            if resolved:
                visit(resolved)
            else:
                unresolvable.append((file_path, mod_name, path_attr))

    for root_file in roots:
        root_path = os.path.join(src_dir, root_file)
        if os.path.exists(root_path):
            visit(root_path)

    # Collect all .rs files in src_dir
    all_files = set()
    for dirpath, _, filenames in os.walk(src_dir):
        for fname in filenames:
            if fname.endswith(".rs"):
                all_files.add(os.path.realpath(os.path.join(dirpath, fname)))

    orphans = all_files - reachable
    return unresolvable, orphans


# -----------------------------------------------------------------------------
# 4. Main Verification Coordinator
# -----------------------------------------------------------------------------

def main():
    root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    workspace_root = root

    print(">>> RUNNING STRICT RUST SEMANTIC & INTEGRITY VERIFICATION <<<")
    print(f"Target Workspace: {workspace_root}\n")

    # Crates to analyze
    caly_bin_roots = ["main.rs"]
    caly_bin_subdir = os.path.join(workspace_root, "bins", "caly", "src", "bin")
    if os.path.exists(caly_bin_subdir):
        for f in os.listdir(caly_bin_subdir):
            if f.endswith(".rs"):
                caly_bin_roots.append(os.path.join("bin", f))

    crates_info = [
        ("caly-core", os.path.join(workspace_root, "crates", "caly-core", "src"), ["lib.rs"]),
        ("caly-kernel", os.path.join(workspace_root, "crates", "caly-kernel", "src"), ["lib.rs"]),
        ("caly-daemon", os.path.join(workspace_root, "crates", "caly-daemon", "src"), ["lib.rs"]),
        ("caly-cli", os.path.join(workspace_root, "crates", "caly-cli", "src"), ["lib.rs"]),
        ("bins/caly", os.path.join(workspace_root, "bins", "caly", "src"), caly_bin_roots),
    ]

    total_files_scanned = 0
    all_syntax_errors = []
    all_safety_violations = []
    all_unwrap_violations = []
    all_unresolvable_mods = []
    all_orphan_files = []

    # 1. Lexical & Token Level Scan across ALL .rs files in the workspace
    for root_dir, _, filenames in os.walk(workspace_root):
        # Skip git / target / sandbox directories
        if "/." in root_dir or "/target" in root_dir or "/agent_sandbox" in root_dir:
            continue
        for fname in filenames:
            if fname.endswith(".rs"):
                fpath = os.path.join(root_dir, fname)
                total_files_scanned += 1
                errors, tokens, is_forbid_unsafe = analyze_rust_source(fpath)
                if errors:
                    all_syntax_errors.extend(errors)

                # Find which crate this file belongs to
                rel = os.path.relpath(fpath, workspace_root)
                crate_name = rel.split(os.sep)[0]
                if crate_name == "crates" and len(rel.split(os.sep)) > 1:
                    crate_name = rel.split(os.sep)[1]

                # Check safety (unsafe token in forbidden crate)
                safety_errs = check_safety_policy(crate_name, fpath, tokens, is_forbid_unsafe)
                if safety_errs:
                    all_safety_violations.extend(safety_errs)

                # Check unwrap policy
                unwrap_errs = check_unwrap_policy(fpath)
                if unwrap_errs:
                    all_unwrap_violations.extend(unwrap_errs)

    # 2. Module Tree & Orphan Integrity Verification
    for crate_name, src_dir, roots in crates_info:
        if os.path.exists(src_dir):
            unres, orphans = verify_crate_module_graph(crate_name, src_dir, roots)
            if unres:
                all_unresolvable_mods.extend([(crate_name, item) for item in unres])
            if orphans:
                all_orphan_files.extend([(crate_name, o) for o in orphans])

    # -------------------------------------------------------------------------
    # Evaluation & Reporting
    # -------------------------------------------------------------------------

    failed = False

    # Check 1: Syntax & Token checks
    if all_syntax_errors:
        print(f"[FAIL] Syntax & Token Checks: {len(all_syntax_errors)} error(s) found:")
        for err in all_syntax_errors[:20]:
            print(f"  {err}")
        if len(all_syntax_errors) > 20:
            print(f"  ... and {len(all_syntax_errors) - 20} more")
        failed = True
    else:
        print(f"[PASS] Syntax & Token Checks: {total_files_scanned} Rust source files verified cleanly.")
        print("       (0 delimiter mismatches, 0 unclosed strings, 0 unclosed block comments, 0 keyword typos)")

    # Check 2: Safety & Policy Gatekeeping
    if all_safety_violations:
        print(f"\n[FAIL] Safety Policy: {len(all_safety_violations)} forbidden unsafe block(s) detected:")
        for v in all_safety_violations:
            print(f"  {v}")
        failed = True
    else:
        print(f"\n[PASS] Safety Policy: 0 `unsafe` blocks detected in #![forbid(unsafe_code)] crates.")

    if all_unwrap_violations:
        print(f"\n[FAIL] Reliability Policy: {len(all_unwrap_violations)} unhandled .unwrap() calls in production:")
        for u in all_unwrap_violations[:10]:
            print(f"  {u}")
        failed = True
    else:
        print("[PASS] Reliability Policy: 0 unhandled .unwrap() calls in production code paths.")

    # Check 3: Module Tree & Orphan Integrity
    if all_unresolvable_mods or all_orphan_files:
        if all_unresolvable_mods:
            print(f"\n[FAIL] Module Resolution: {len(all_unresolvable_mods)} unresolvable module declaration(s):")
            for cname, (fpath, mname, pattr) in all_unresolvable_mods:
                print(f"  [{cname}] In {fpath}: mod {mname}; (path={pattr})")
        if all_orphan_files:
            print(f"\n[FAIL] Orphan Detection: {len(all_orphan_files)} unreferenced .rs file(s) in src/:")
            for cname, opath in all_orphan_files:
                print(f"  [{cname}] Orphaned file: {opath}")
        failed = True
    else:
        print(f"\n[PASS] Module Tree & File Integrity: 100% of modules resolved, 0 orphaned files across {len(crates_info)} crates.")

    if failed:
        print("\n>>> STATIC ANALYSIS GATEKEEPER FOUND VIOLATIONS. ABORTING. <<<")
        sys.exit(1)
    else:
        print("\n>>> ALL RUST SEMANTIC & ARCHITECTURAL CHECKS PASSED SUCCESSFULLY. <<<")
        sys.exit(0)


if __name__ == "__main__":
    main()
