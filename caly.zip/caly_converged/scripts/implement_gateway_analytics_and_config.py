#!/usr/bin/env python3
"""
Comprehensive Optimization:
1. Config layout: clean single-file default config.yaml mapping all capabilities.
2. Daemon runtime overhead: reduces idle actor poll wakeups from 100ms to 1000ms (90% reduction).
3. Gateway & Traffic Analytics: adds GatewayConfig, TrafficAnalyticsSnapshot, and rich flow analytics CLI commands.
"""
import os, sys

base = '/working_dir/c_a78e266d197e3673/caly_converged'

# 1. Update caly-core/src/profile/schema/settings/defaults.rs
p_defaults = f'{base}/crates/caly-core/src/profile/schema/settings/defaults.rs'
with open(p_defaults, 'r', encoding='utf-8') as f:
    c_def = f.read()

unified_base_config = '''pub fn render_default_base() -> String {
    r#"# ==============================================================================
# Caly Unified Configuration (config.yaml)
# Single-file layout with all core, TUN, DNS, and routing capabilities mapped
# ==============================================================================
schema_version: 1

# Managed proxy core: mihomo | sing-box
core: mihomo

# Routing rule precedence: hybrid (local rules win, then profile rules) | local_only | profile_only
rule_preference: hybrid

# DNS precedence: local (local DNS engine wins, Fake-IP & DoH) | merge | profile
dns_preference: local

# Kernel listening ports and inbound adapters
kernel:
  mixed_port: 7890
  tproxy_port: 0
  redir_port: 0
  socks_port: 0
  http_port: 0
  allow_lan: false
  bind_address: "127.0.0.1"
  log_level: info

# TUN Virtual Network Interface (Transparent Gateway Mode)
tun:
  enabled: true
  stack: gvisor
  device: caly0
  auto_route: true
  auto_redirect: false
  strict_route: true
  endpoint_independent_mapping: true
  mtu: 9000
  gso: true
  route_address: []
  route_exclude_address: []
  include_uid: []
  exclude_uid: []

# High-Performance DNS Engine
dns:
  enabled: true
  mode: fake-ip
  listen: "127.0.0.1:53"
  ipv6: false
  prefer_h3: true
  strategy: prefer_ipv4
  client_subnet: "114.114.114.0/24"
  fake_ip_range: "198.18.0.1/16"
  cache:
    algorithm: lru
    size: 4096
    min_ttl: 60
    max_ttl: 86400
    negative_ttl: 10
    stale_cache: true
    respect_rules: true
  hosts:
    "router.local": "192.168.1.1"
  nameservers:
    - https://dns.alidns.com/dns-query
    - https://doh.pub/dns-query
  fallback:
    - https://cloudflare-dns.com/dns-query
    - https://dns.google/dns-query
  nameserver_policy:
    "geosite:cn":
      - 223.5.5.5
      - 119.29.29.29
    "geosite:geolocation-!cn":
      - 8.8.8.8
      - 1.1.1.1

# Gateway & LAN Devices Settings
gateway:
  enabled: false
  ip_forwarding: true
  masquerade: true
  bypass_ips: []
  proxied_ips: []

# Unified Profiles & Subscriptions
profiles: []

# Proxy Groups
proxy_groups: []

# Custom Routing Rules (Preceded by local preference)
rules:
  - GEOIP,private,DIRECT
  - GEOSITE,cn,DIRECT
  - GEOIP,CN,DIRECT
  - MATCH,DIRECT
"#.to_owned()
}'''

old_base_marker = 'pub fn render_default_base() -> String {'
if old_base_marker in c_def:
    start = c_def.find(old_base_marker)
    end = c_def.find('/// Renders the generated feature-file layout', start)
    c_def = c_def[:start] + unified_base_config + '\n\n' + c_def[end:]

# Update render_default_config_files to return empty (single config.yaml layout)
old_files_fn = '''pub fn render_default_config_files() -> Vec<(PathBuf, String)> {
    let mut fragments = core_and_transport_fragments();
    fragments.extend(effect_and_observability_fragments());
    fragments
}'''

new_files_fn = '''pub fn render_default_config_files() -> Vec<(PathBuf, String)> {
    // Optimized single-file layout: all configurations are unified in config.yaml.
    // config.d/ remains available for optional user-defined fragment overrides.
    Vec::new()
}'''

if old_files_fn in c_def:
    c_def = c_def.replace(old_files_fn, new_files_fn)

with open(p_defaults, 'w', encoding='utf-8') as f:
    f.write(c_def)
print("1. Streamlined defaults.rs into a comprehensive single-file config.yaml layout")

# 2. Add GatewayConfig to caly-core/src/profile/schema/mod.rs
p_sch = f'{base}/crates/caly-core/src/profile/schema/mod.rs'
with open(p_sch, 'r', encoding='utf-8') as f:
    c_sch = f.read()

gateway_schema = '''/// Gateway & transparent network router settings.
#[derive(Clone, Debug, Default, Deserialize, Eq, PartialEq, Serialize)]
#[serde(default, deny_unknown_fields)]
pub struct GatewayConfig {
    pub enabled: bool,
    pub lan_interface: Option<String>,
    pub ip_forwarding: bool,
    pub masquerade: bool,
    pub bypass_ips: Vec<String>,
    pub proxied_ips: Vec<String>,
}
'''

if 'pub struct GatewayConfig' not in c_sch:
    c_sch = gateway_schema + '\n' + c_sch
    target_pos = '    #[serde(default)]\n    pub tun: TunConfig,'
    c_sch = c_sch.replace(target_pos, target_pos + '\n    #[serde(default)]\n    pub gateway: GatewayConfig,')
    with open(p_sch, 'w', encoding='utf-8') as f:
        f.write(c_sch)
    print("2. Added GatewayConfig to AppConfig in profile/schema/mod.rs")

# 3. Create caly-core/src/domain/analytics.rs for Gateway & Traffic Analysis
p_ana = f'{base}/crates/caly-core/src/domain/analytics.rs'
c_ana = '''//! Traffic flow analytics and gateway device monitoring.

use std::collections::BTreeMap;
use serde::{Deserialize, Serialize};

/// High-level traffic analytics computed from active connections.
#[derive(Clone, Debug, Default, Eq, PartialEq, Serialize, Deserialize)]
pub struct TrafficAnalyticsSnapshot {
    pub total_upload_bytes: u64,
    pub total_download_bytes: u64,
    pub active_connections: usize,
    /// Client IP -> (upload, download, connection_count)
    pub client_traffic: BTreeMap<String, ClientStats>,
    /// Protocol name -> total_bytes
    pub protocol_breakdown: BTreeMap<String, u64>,
    /// Target domain -> (hit_count, total_bytes)
    pub top_domains: Vec<DomainStats>,
}

#[derive(Clone, Debug, Default, Eq, PartialEq, Serialize, Deserialize)]
pub struct ClientStats {
    pub upload_bytes: u64,
    pub download_bytes: u64,
    pub active_connections: usize,
}

#[derive(Clone, Debug, Default, Eq, PartialEq, Serialize, Deserialize)]
pub struct DomainStats {
    pub domain: String,
    pub total_bytes: u64,
    pub connections: usize,
}

/// Computes analytics summary from a slice of connection items.
pub fn compute_traffic_analytics<T, F>(
    connections: &[T],
    mut extractor: F,
) -> TrafficAnalyticsSnapshot
where
    F: FnMut(&T) -> (String, String, String, u64, u64), // (client_ip, host, protocol, upload, download)
{
    let mut snap = TrafficAnalyticsSnapshot::default();
    snap.active_connections = connections.len();
    let mut domain_map: BTreeMap<String, (usize, u64)> = BTreeMap::new();

    for conn in connections {
        let (client_ip, host, proto, up, down) = extractor(conn);
        let total = up.saturating_add(down);
        snap.total_upload_bytes = snap.total_upload_bytes.saturating_add(up);
        snap.total_download_bytes = snap.total_download_bytes.saturating_add(down);

        // Per-client LAN IP tracking
        let ip_key = if client_ip.is_empty() { "127.0.0.1".to_owned() } else { client_ip };
        let client_stat = snap.client_traffic.entry(ip_key).or_default();
        client_stat.upload_bytes = client_stat.upload_bytes.saturating_add(up);
        client_stat.download_bytes = client_stat.download_bytes.saturating_add(down);
        client_stat.active_connections += 1;

        // Protocol breakdown
        let proto_key = if proto.is_empty() { "TCP".to_owned() } else { proto.to_uppercase() };
        let proto_total = snap.protocol_breakdown.entry(proto_key).or_insert(0);
        *proto_total = (*proto_total).saturating_add(total);

        // Domain tracking
        if !host.is_empty() && host != "-" {
            let entry = domain_map.entry(host).or_insert((0, 0));
            entry.0 += 1;
            entry.1 = entry.1.saturating_add(total);
        }
    }

    let mut domains: Vec<DomainStats> = domain_map
        .into_iter()
        .map(|(domain, (conns, total_bytes))| DomainStats {
            domain,
            total_bytes,
            connections: conns,
        })
        .collect();
    domains.sort_by(|a, b| b.total_bytes.cmp(&a.total_bytes));
    snap.top_domains = domains;

    snap
}
'''
with open(p_ana, 'w', encoding='utf-8') as f:
    f.write(c_ana)
print("3. Created caly-core/src/domain/analytics.rs for Gateway & Traffic Analysis")

# Export analytics in domain/mod.rs
p_dom_mod = f'{base}/crates/caly-core/src/domain/mod.rs'
with open(p_dom_mod, 'r', encoding='utf-8') as f:
    c_dm = f.read()

if 'mod analytics;' not in c_dm:
    c_dm = c_dm.replace('mod inbound;', 'mod analytics;\nmod inbound;')
    c_dm = c_dm.replace('pub use inbound::*;', 'pub use analytics::{ClientStats, DomainStats, TrafficAnalyticsSnapshot, compute_traffic_analytics};\npub use inbound::*;')
    with open(p_dom_mod, 'w', encoding='utf-8') as f:
        f.write(c_dm)
    print("4. Exported analytics in caly-core/src/domain/mod.rs")

# 4. Reduce daemon runtime overhead in caly-daemon/src/composition/handlers.rs
p_hand = f'{base}/crates/caly-daemon/src/composition/handlers.rs'
with open(p_hand, 'r', encoding='utf-8') as f:
    c_hand = f.read()

old_idle_poll = 'Duration::from_millis(100),'
new_idle_poll = 'Duration::from_secs(1), // Reduced idle wakeup overhead by 90%'

if old_idle_poll in c_hand:
    c_hand = c_hand.replace(old_idle_poll, new_idle_poll)
    with open(p_hand, 'w', encoding='utf-8') as f:
        f.write(c_hand)
    print("5. Reduced daemon runtime overhead in handlers.rs (100ms -> 1000ms idle poll)")

# 5. Enhance caly-cli/src/cli/commands/flow.rs with gateway client device breakdown
p_flow = f'{base}/crates/caly-cli/src/cli/commands/flow.rs'
with open(p_flow, 'r', encoding='utf-8') as f:
    c_flow = f.read()

flow_analytics_helpers = '''
/// Renders a Gateway LAN Client device traffic breakdown.
pub fn render_gateway_clients(details: &[ConnectionDetail], output: CliOutput) {
    let snap = caly_domain::compute_traffic_analytics(details, |c| {
        let client_ip = c.source.split(':').next().unwrap_or("127.0.0.1").to_owned();
        (client_ip, c.host.clone(), c.protocol_type.clone(), c.upload_bytes, c.download_bytes)
    });

    if output.is_json() {
        output.success("clients", serde_json::json!({ "clients": snap.client_traffic }));
        return;
    }

    if snap.client_traffic.is_empty() {
        output.info("no active gateway client traffic");
        return;
    }

    let mut rows = Vec::new();
    for (ip, stats) in &snap.client_traffic {
        rows.push(vec![
            ip.clone(),
            stats.active_connections.to_string(),
            caly_layout::human_bytes(stats.upload_bytes),
            caly_layout::human_bytes(stats.download_bytes),
            caly_layout::human_bytes(stats.upload_bytes + stats.download_bytes),
        ]);
    }
    let headers: [&str; 5] = ["CLIENT IP", "CONNS", "UPLOAD", "DOWNLOAD", "TOTAL DATA"];
    println!("Gateway LAN Client Traffic ({} active devices):", rows.len());
    caly_layout::print_table(
        caly_layout::TableMode::Table,
        &headers,
        &rows,
        caly_layout::term::term_width(),
    );
}
'''

if 'pub fn render_gateway_clients' not in c_flow:
    c_flow += flow_analytics_helpers
    with open(p_flow, 'w', encoding='utf-8') as f:
        f.write(c_flow)
    print("6. Added render_gateway_clients to commands/flow.rs")

print("\nGateway, Analytics, Config Layout, and Runtime optimizations applied successfully!")
