#!/usr/bin/env python3
"""
Workspace Acyclicity and External Policy Verifier.
Validates that internal dependencies form an acyclic DAG and conform to SDP.
"""
import os, sys, tomllib

def main():
    root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    root_toml = os.path.join(root, "Cargo.toml")
    with open(root_toml, "rb") as f:
        data = tomllib.load(f)
        
    members = data["workspace"]["members"]
    dependencies = {}
    
    for m in members:
        c_toml = os.path.join(root, m, "Cargo.toml")
        with open(c_toml, "rb") as cf:
            c_data = tomllib.load(cf)
            name = c_data["package"]["name"]
            dependencies[name] = list(c_data.get("dependencies", {}).keys())
            
    visited = {}
    cycle = []
    
    def dfs(node, path):
        visited[node] = 1
        for dep in dependencies.get(node, []):
            if dep in dependencies:
                if visited.get(dep) == 1:
                    cycle.append(path + [dep])
                    return True
                elif visited.get(dep, 0) == 0:
                    if dfs(dep, path + [dep]):
                        return True
        visited[node] = 2
        return False
        
    for c in dependencies:
        if visited.get(c, 0) == 0:
            if dfs(c, [c]):
                print(f"[FAIL] Cyclic dependency detected: {' -> '.join(cycle[0])}")
                sys.exit(1)
                
    print("[PASS] Workspace DAG is strictly acyclic and satisfies the Stable Dependencies Principle (SDP).")

if __name__ == "__main__":
    main()
