#!/usr/bin/env python3
"""
Applies Daemon Runtime Overhead & Resource Optimization:
1. bus.rs: Replace 1s busy sleep loop in run_reconciler with blocking recv() on futex.
2. store.rs: Add active_order queue for O(1) early-exit in expire_stale_operations.
3. dual.rs: Add switch_lock to serialize switching without holding active_core lock during start/stop I/O.
4. telemetry.rs & handlers.rs: Adaptive telemetry backoff (idle 8-10s vs active 1-2s).
5. framing.rs & service.rs: Add read_frame_into for zero-reallocation buffer reuse.
"""
import os, sys

base = '/mnt/agentdata/tiered/c_a78e266d197e3673/caly_converged'

# 1. Update bus.rs
p_bus = f'{base}/crates/caly-daemon/src/application/events/bus.rs'
with open(p_bus, 'r', encoding='utf-8') as f:
    c_bus = f.read()

old_run_rec = '''pub fn run_reconciler(
    events: &crossbeam_channel::Receiver<DaemonEvent>,
    interval: std::time::Duration,
    mut on_changed: impl FnMut(),
) {
    loop {
        match events.recv_timeout(interval) {
            Ok(DaemonEvent::SubscriptionRefreshed { changed: true }) => on_changed(),
            Ok(_) => {}
            Err(crossbeam_channel::RecvTimeoutError::Timeout) => {}
            Err(crossbeam_channel::RecvTimeoutError::Disconnected) => break,
        }
    }
}'''

new_run_rec = '''pub fn run_reconciler(
    events: &crossbeam_channel::Receiver<DaemonEvent>,
    _interval: std::time::Duration,
    mut on_changed: impl FnMut(),
) {
    // Blocking receive on kernel futex: 0 CPU cycles and 0 wakeups when idle.
    // Exits cleanly when the bus is dropped on daemon shutdown.
    while let Ok(event) = events.recv() {
        if let DaemonEvent::SubscriptionRefreshed { changed: true } = event {
            on_changed();
        }
    }
}'''

if old_run_rec in c_bus:
    c_bus = c_bus.replace(old_run_rec, new_run_rec)
    with open(p_bus, 'w', encoding='utf-8') as f:
        f.write(c_bus)
    print("1. Optimized run_reconciler in bus.rs to blocking recv (0 idle CPU wakeups)")

# 2. Update store.rs with active_order
p_store = f'{base}/crates/caly-daemon/src/application/operations/store.rs'
with open(p_store, 'r', encoding='utf-8') as f:
    c_store = f.read()

old_struct = '''pub struct OperationStore {
    records: HashMap<OperationId, OperationRecord>,
    terminal_order: VecDeque<OperationId>,
    total_capacity: usize,
    terminal_capacity: usize,
}'''

new_struct = '''pub struct OperationStore {
    records: HashMap<OperationId, OperationRecord>,
    terminal_order: VecDeque<OperationId>,
    active_order: VecDeque<(OperationId, UnixMillis)>,
    total_capacity: usize,
    terminal_capacity: usize,
}'''

if old_struct in c_store:
    c_store = c_store.replace(old_struct, new_struct)
    # in new()
    c_store = c_store.replace(
        'terminal_order: VecDeque::with_capacity(terminal_capacity),\n            total_capacity,',
        'terminal_order: VecDeque::with_capacity(terminal_capacity),\n            active_order: VecDeque::new(),\n            total_capacity,'
    )
    # in insert()
    c_store = c_store.replace(
        'self.records.insert(record.id(), record);\n        Ok(InsertOutcome::Inserted)',
        'self.active_order.push_back((record.id(), record.created_at()));\n        self.records.insert(record.id(), record);\n        Ok(InsertOutcome::Inserted)'
    )

old_expire = '''    pub fn expire_stale_operations(&mut self, now: UnixMillis, ttl_ms: u64) -> usize {
        let mut expired = Vec::new();
        for (id, record) in &self.records {
            if !record.state().is_terminal() {
                let age = now.as_u64().saturating_sub(record.created_at().as_u64());
                if age > ttl_ms {
                    expired.push(*id);
                }
            }
        }
        let count = expired.len();
        for id in expired {
            let _ = self.transition(
                id,
                OperationState::Failed,
                now,
                Some(caly_domain::OperationFailure::clamped(
                    caly_domain::OperationFailureKind::DeadlineExceeded,
                    "operation timed out in store",
                    "retry operation",
                )),
            );
        }
        count
    }'''

new_expire = '''    pub fn expire_stale_operations(&mut self, now: UnixMillis, ttl_ms: u64) -> usize {
        let mut count = 0;
        // Fast-path O(1) early exit: since operations are appended in chronological order,
        // if the front element has not timed out, no subsequent operations have timed out.
        while let Some(&(id, created_at)) = self.active_order.front() {
            let age = now.as_u64().saturating_sub(created_at.as_u64());
            if age <= ttl_ms {
                break;
            }
            self.active_order.pop_front();
            if let Some(rec) = self.records.get(&id) {
                if !rec.state().is_terminal() {
                    let _ = self.transition(
                        id,
                        OperationState::Failed,
                        now,
                        Some(caly_domain::OperationFailure::clamped(
                            caly_domain::OperationFailureKind::DeadlineExceeded,
                            "operation timed out in store",
                            "retry operation",
                        )),
                    );
                    count += 1;
                }
            }
        }
        count
    }'''

if old_expire in c_store:
    c_store = c_store.replace(old_expire, new_expire)
    with open(p_store, 'w', encoding='utf-8') as f:
        f.write(c_store)
    print("2. Optimized expire_stale_operations in store.rs to O(1) queue inspection")

# 3. Update dual.rs with switch_lock
p_dual = f'{base}/crates/caly-daemon/src/backends/dual.rs'
with open(p_dual, 'r', encoding='utf-8') as f:
    c_dual = f.read()

old_dual_struct = '''pub struct DualCoreLifecycle {
    active: SharedActiveCore,
    mihomo: SharedCoreLifecycleBackend,
    sing_box: SharedCoreLifecycleBackend,
}'''

new_dual_struct = '''pub struct DualCoreLifecycle {
    active: SharedActiveCore,
    switch_lock: std::sync::Mutex<()>,
    mihomo: SharedCoreLifecycleBackend,
    sing_box: SharedCoreLifecycleBackend,
}'''

if old_dual_struct in c_dual:
    c_dual = c_dual.replace(old_dual_struct, new_dual_struct)
    c_dual = c_dual.replace(
        'Self {\n            active,\n            mihomo,\n            sing_box,\n        }',
        'Self {\n            active,\n            switch_lock: std::sync::Mutex::new(()),\n            mihomo,\n            sing_box,\n        }'
    )

old_switch_to = '''    pub fn switch_to(&self, target: CoreKind) -> Result<AppliedState, ActorFailure> {
        let mut active = self.active.lock().map_err(|poisoned| {
            failure(
                &format!("active-core lock poisoned ({poisoned})"),
                "restart daemon",
            )
        })?;
        if *active == target {
            return self.backend_for(target).restart();
        }
        // Gracefully stop the previously active kernel before switching so two
        // kernels never race for the same mixed/controller ports.
        let previous = *active;
        self.backend_for(previous).stop()?;
        match self.backend_for(target).start() {
            Ok(state) => {
                // Flip active cell ONLY after new core is running and ready!
                *active = target;
                Ok(state)
            }
            Err(failure) => {
                // Target failed to start; restore previous core while keeping active cell pointing to previous
                if let Err(restore_error) = self.backend_for(previous).start() {
                    tracing::error!(
                        restore_error = %restore_error,
                        "also failed to restore the previous core after a failed switch"
                    );
                }
                Err(failure)
            }
        }
    }'''

new_switch_to = '''    pub fn switch_to(&self, target: CoreKind) -> Result<AppliedState, ActorFailure> {
        // Hold the serialization switch lock to prevent concurrent switches,
        // but DO NOT hold active lock during long stop() and start() I/O.
        let _switch_guard = self.switch_lock.lock().map_err(|_| {
            failure("dual core switch lock poisoned", "restart daemon")
        })?;
        let current = *self.active.lock().map_err(|poisoned| {
            failure(
                &format!("active-core lock poisoned ({poisoned})"),
                "restart daemon",
            )
        })?;
        if current == target {
            return self.backend_for(target).restart();
        }
        let previous = current;
        self.backend_for(previous).stop()?;
        match self.backend_for(target).start() {
            Ok(state) => {
                let mut active = self.active.lock().map_err(|poisoned| {
                    failure(
                        &format!("active-core lock poisoned ({poisoned})"),
                        "restart daemon",
                    )
                })?;
                *active = target;
                Ok(state)
            }
            Err(failure) => {
                if let Err(restore_error) = self.backend_for(previous).start() {
                    tracing::error!(
                        restore_error = %restore_error,
                        "also failed to restore the previous core after a failed switch"
                    );
                }
                Err(failure)
            }
        }
    }'''

if old_switch_to in c_dual:
    c_dual = c_dual.replace(old_switch_to, new_switch_to)
    with open(p_dual, 'w', encoding='utf-8') as f:
        f.write(c_dual)
    print("3. Reduced lock contention in DualCoreLifecycle (active lock held only for atomic swap)")

# 4. Update telemetry.rs and handlers.rs
p_telem = f'{base}/crates/caly-daemon/src/backends/telemetry.rs'
with open(p_telem, 'r', encoding='utf-8') as f:
    c_telem = f.read()

old_shared_obs = '''#[derive(Clone, Default)]
pub struct SharedObservedState(pub Arc<Mutex<ObservedState>>);

impl SharedObservedState {
    /// Returns a snapshot of the current observed state. a
    /// poisoned cell used to report a zeroed default (observed counters blink
    /// to 0 after any writer panic); recovering the guard keeps the last
    /// coherent values instead — poison remains surfaced by the runtime as a
    /// fault.
    pub fn value(&self) -> ObservedState {
        self.0
            .lock()
            .map_or_else(|poison| *poison.into_inner(), |guard| *guard)
    }
}'''

new_shared_obs = '''use std::sync::atomic::{AtomicU64, AtomicUsize, Ordering};

/// Shares the current observed runtime state with adaptive client activity tracking.
#[derive(Clone)]
pub struct SharedObservedState {
    pub inner: Arc<Mutex<ObservedState>>,
    pub active_watchers: Arc<AtomicUsize>,
    pub last_activity_unix_secs: Arc<AtomicU64>,
}

impl Default for SharedObservedState {
    fn default() -> Self {
        Self {
            inner: Arc::new(Mutex::new(ObservedState::default())),
            active_watchers: Arc::new(AtomicUsize::new(0)),
            last_activity_unix_secs: Arc::new(AtomicU64::new(0)),
        }
    }
}

impl SharedObservedState {
    pub fn new(inner: Arc<Mutex<ObservedState>>) -> Self {
        Self {
            inner,
            active_watchers: Arc::new(AtomicUsize::new(0)),
            last_activity_unix_secs: Arc::new(AtomicU64::new(0)),
        }
    }

    pub fn value(&self) -> ObservedState {
        self.inner
            .lock()
            .map_or_else(|poison| *poison.into_inner(), |guard| *guard)
    }

    /// Records client telemetry activity.
    pub fn mark_activity(&self) {
        let now = std::time::SystemTime::now()
            .duration_since(std::time::UNIX_EPOCH)
            .map_or(0, |d| d.as_secs());
        self.last_activity_unix_secs.store(now, Ordering::Relaxed);
    }

    /// Tracks an active watching client lease.
    pub fn track_watcher(&self) -> WatcherLease {
        self.active_watchers.fetch_add(1, Ordering::Relaxed);
        self.mark_activity();
        WatcherLease {
            counter: Arc::clone(&self.active_watchers),
        }
    }

    /// Returns true if an active client stream is attached OR recent activity occurred.
    pub fn is_active(&self) -> bool {
        if self.active_watchers.load(Ordering::Relaxed) > 0 {
            return true;
        }
        let now = std::time::SystemTime::now()
            .duration_since(std::time::UNIX_EPOCH)
            .map_or(0, |d| d.as_secs());
        let last = self.last_activity_unix_secs.load(Ordering::Relaxed);
        now.saturating_sub(last) < 15
    }
}

pub struct WatcherLease {
    counter: Arc<AtomicUsize>,
}

impl Drop for WatcherLease {
    fn drop(&mut self) {
        self.counter.fetch_sub(1, Ordering::Relaxed);
    }
}'''

if old_shared_obs in c_telem:
    c_telem = c_telem.replace(old_shared_obs, new_shared_obs)
    c_telem = c_telem.replace('self.observed.0.lock()', 'self.observed.inner.lock()')
    with open(p_telem, 'w', encoding='utf-8') as f:
        f.write(c_telem)
    print("4. Added client activity tracking to SharedObservedState in telemetry.rs")

# Update handlers.rs for adaptive telemetry scheduler
p_handlers = f'{base}/crates/caly-daemon/src/composition/handlers.rs'
with open(p_handlers, 'r', encoding='utf-8') as f:
    c_handlers = f.read()

old_sched = '''                let mut interval = tokio::time::interval(interval);
                interval.set_missed_tick_behavior(tokio::time::MissedTickBehavior::Delay);
                // 刀 6 (CPU audit): only project the observed state when it
                // actually changed — an unchanged sample must not re-report
                // an identical snapshot every tick (wasted wire frames and
                // projector work).
                let mut last_observed: Option<caly_domain::ObservedState> = None;
                while !cancellation.is_cancelled() {
                    interval.tick().await;
                    if cancellation.is_cancelled() {
                        break;
                    }
                    let _ =
                        telemetry.try_send(caly_application::actors::TelemetryActorCommand::Sample);
                    let state = observed.value();
                    if last_observed.as_ref() == Some(&state) {
                        continue;
                    }
                    last_observed = Some(state);
                    let Ok(deltas) = ResultDeltas::try_from_vec(vec![
                        caly_domain::PresentationDelta::ObservedReplaced(state),
                    ]) else {
                        continue;
                    };
                    let _ =
                        results.try_report(caly_application::actor_result::ActorReport::Observed {
                            deltas,
                        });
                }'''

new_sched = '''                // Adaptive telemetry cadence:
                // Active mode (client watching or querying): frequent updates (e.g. 1-2s).
                // Idle mode (no clients): back off to 8-10s, reducing idle CPU & HTTP poll load by 80%.
                let active_cadence = interval;
                let idle_cadence = interval.max(std::time::Duration::from_secs(8));
                let mut last_observed: Option<caly_domain::ObservedState> = None;

                while !cancellation.is_cancelled() {
                    let sleep_duration = if observed.is_active() {
                        active_cadence
                    } else {
                        idle_cadence
                    };
                    tokio::time::sleep(sleep_duration).await;
                    if cancellation.is_cancelled() {
                        break;
                    }
                    let _ =
                        telemetry.try_send(caly_application::actors::TelemetryActorCommand::Sample);
                    let state = observed.value();
                    if last_observed.as_ref() == Some(&state) {
                        continue;
                    }
                    last_observed = Some(state);
                    let Ok(deltas) = ResultDeltas::try_from_vec(vec![
                        caly_domain::PresentationDelta::ObservedReplaced(state),
                    ]) else {
                        continue;
                    };
                    let _ =
                        results.try_report(caly_application::actor_result::ActorReport::Observed {
                            deltas,
                        });
                }'''

if old_sched in c_handlers:
    c_handlers = c_handlers.replace(old_sched, new_sched)
    with open(p_handlers, 'w', encoding='utf-8') as f:
        f.write(c_handlers)
    print("5. Implemented adaptive telemetry cadence in handlers.rs (idle 8s vs active 1-2s)")

# 5. Update framing.rs for read_frame_into
p_framing = f'{base}/crates/caly-daemon/src/protocol/framing.rs'
with open(p_framing, 'r', encoding='utf-8') as f:
    c_framing = f.read()

old_read_frame = '''pub async fn read_frame<R>(reader: &mut R, max_bytes: usize) -> Result<Vec<u8>, FrameError>
where
    R: AsyncRead + Unpin,
{
    let mut header = [0_u8; HEADER_BYTES];
    match reader.read_exact(&mut header).await {
        Ok(_) => {}
        Err(error) if error.kind() == std::io::ErrorKind::UnexpectedEof => {
            return Err(FrameError::Closed);
        }
        Err(error) => return Err(FrameError::from(error)),
    }
    let length = u32::from_le_bytes(header) as usize;
    if length > max_bytes {
        return Err(FrameError::Oversized {
            limit: max_bytes,
            actual: length,
        });
    }
    let mut payload = Vec::with_capacity(length.min(64 * 1024));
    let mut chunk = [0_u8; 8192];
    let mut remaining = length;
    while remaining > 0 {
        let to_read = remaining.min(chunk.len());
        match reader.read(&mut chunk[..to_read]).await {
            Ok(0) => return Err(FrameError::Closed),
            Ok(n) => {
                payload.extend_from_slice(&chunk[..n]);
                remaining -= n;
            }
            Err(error) if error.kind() == std::io::ErrorKind::UnexpectedEof => return Err(FrameError::Closed),
            Err(error) => return Err(FrameError::from(error)),
        }
    }
    Ok(payload)
}'''

new_read_frame = '''/// Reads one length-prefixed frame into a caller-supplied reusable buffer,
/// avoiding per-frame heap reallocations.
pub async fn read_frame_into<R>(
    reader: &mut R,
    max_bytes: usize,
    buffer: &mut Vec<u8>,
) -> Result<(), FrameError>
where
    R: AsyncRead + Unpin,
{
    buffer.clear();
    let mut header = [0_u8; HEADER_BYTES];
    match reader.read_exact(&mut header).await {
        Ok(_) => {}
        Err(error) if error.kind() == std::io::ErrorKind::UnexpectedEof => {
            return Err(FrameError::Closed);
        }
        Err(error) => return Err(FrameError::from(error)),
    }
    let length = u32::from_le_bytes(header) as usize;
    if length > max_bytes {
        return Err(FrameError::Oversized {
            limit: max_bytes,
            actual: length,
        });
    }
    if buffer.capacity() < length.min(64 * 1024) {
        buffer.reserve(length.min(64 * 1024) - buffer.capacity());
    }
    let mut chunk = [0_u8; 8192];
    let mut remaining = length;
    while remaining > 0 {
        let to_read = remaining.min(chunk.len());
        match reader.read(&mut chunk[..to_read]).await {
            Ok(0) => return Err(FrameError::Closed),
            Ok(n) => {
                buffer.extend_from_slice(&chunk[..n]);
                remaining -= n;
            }
            Err(error) if error.kind() == std::io::ErrorKind::UnexpectedEof => {
                return Err(FrameError::Closed);
            }
            Err(error) => return Err(FrameError::from(error)),
        }
    }
    Ok(())
}

pub async fn read_frame<R>(reader: &mut R, max_bytes: usize) -> Result<Vec<u8>, FrameError>
where
    R: AsyncRead + Unpin,
{
    let mut buf = Vec::with_capacity(max_bytes.min(64 * 1024));
    read_frame_into(reader, max_bytes, &mut buf).await?;
    Ok(buf)
}'''

if old_read_frame in c_framing:
    c_framing = c_framing.replace(old_read_frame, new_read_frame)
    with open(p_framing, 'w', encoding='utf-8') as f:
        f.write(c_framing)
    print("6. Added read_frame_into in framing.rs for zero-reallocation buffer reuse")

print("\nDaemon runtime optimization script completed successfully!")
