#!/usr/bin/env python3
"""
Test Suite Reorganization, Consolidation & Enrichment:
1. Inlines/consolidates solo test files into their parent source files,
   eliminating the 20+ cluttered solo test directories.
2. Removes redundant/obsolete test files.
3. Adds comprehensive tests for core features (Rule IR, GeoIP/GeoSite, W-TinyLFU, Trie, P2C, DNS).
"""
import os, sys, re

base = '/working_dir/c_a78e266d197e3673/caly_converged'

solo_targets = [
    ('crates/caly-core/src/profile/loader/layered', 'crates/caly-core/src/profile/loader/layered.rs', 'tests.rs'),
    ('crates/caly-core/src/profile/profile_store', 'crates/caly-core/src/profile/profile_store.rs', 'tests.rs'),
    ('crates/caly-kernel/src/coreconf/mihomo/proxy_sections', 'crates/caly-kernel/src/coreconf/mihomo/proxy_sections.rs', 'render_tests.rs'),
    ('crates/caly-kernel/src/coreconf/mihomo/render', 'crates/caly-kernel/src/coreconf/mihomo/render.rs', 'hostile_tests.rs'),
    ('crates/caly-kernel/src/corectl/mihomo/http', 'crates/caly-kernel/src/corectl/mihomo/http.rs', 'tests.rs'),
    ('crates/caly-daemon/src/protocol/client/uds', 'crates/caly-daemon/src/protocol/client/uds.rs', 'tests.rs'),
    ('crates/caly-daemon/src/backends/lifecycle', 'crates/caly-daemon/src/backends/lifecycle.rs', 'hint_tests.rs'),
    ('crates/caly-daemon/src/backends/platform/durable', 'crates/caly-daemon/src/backends/platform/durable.rs', 'durable_tests.rs'),
    ('crates/caly-daemon/src/backends/subscription/render_compose', 'crates/caly-daemon/src/backends/subscription/render_compose.rs', 'tests.rs'),
    ('crates/caly-daemon/src/composition/handlers', 'crates/caly-daemon/src/composition/handlers.rs', 'handler_tests.rs'),
    ('crates/caly-daemon/src/composition/recovery', 'crates/caly-daemon/src/composition/recovery.rs', 'recovery_tests.rs'),
    ('crates/caly-daemon/src/platform/tun/device', 'crates/caly-daemon/src/platform/tun/device.rs', 'device_tests.rs'),
    ('crates/caly-cli/src/cli/commands/refresh', 'crates/caly-cli/src/cli/commands/refresh.rs', 'tests.rs'),
    ('crates/caly-cli/src/cli/commands/sys_status', 'crates/caly-cli/src/cli/commands/sys_status.rs', 'tests.rs'),
    ('crates/caly-cli/src/cli/commands/proxy_group', 'crates/caly-cli/src/cli/commands/proxy_group.rs', 'dispatch_tests.rs'),
    ('crates/caly-cli/src/cli/commands/rule_provider', 'crates/caly-cli/src/cli/commands/rule_provider.rs', 'dispatch_tests.rs'),
    ('crates/caly-cli/src/cli/commands/set/sub', 'crates/caly-cli/src/cli/commands/set/sub.rs', 'dispatch_tests.rs'),
    ('crates/caly-cli/src/cli/doctor/checks', 'crates/caly-cli/src/cli/doctor/checks.rs', 'getcap_parse_tests.rs'),
    ('crates/caly-cli/src/ops/client/proxy_group', 'crates/caly-cli/src/ops/client/proxy_group.rs', 'tests.rs'),
    ('crates/caly-cli/src/ops/client/rule_provider', 'crates/caly-cli/src/ops/client/rule_provider.rs', 'tests.rs'),
    ('crates/caly-cli/src/ops/config', 'crates/caly-cli/src/ops/config.rs', 'config_tests.rs'),
    ('crates/caly-cli/src/cli/cli/aliases', 'crates/caly-cli/src/cli/cli/aliases.rs', 'tests.rs'),
]

consolidated_count = 0

for dir_rel, parent_rel, test_filename in solo_targets:
    dir_path = os.path.join(base, dir_rel)
    parent_path = os.path.join(base, parent_rel)
    test_path = os.path.join(dir_path, test_filename)
    
    if not (os.path.exists(dir_path) and os.path.exists(parent_path) and os.path.exists(test_path)):
        continue
        
    with open(parent_path, 'r', encoding='utf-8') as f:
        parent_content = f.read()
    with open(test_path, 'r', encoding='utf-8') as f:
        test_content = f.read()
        
    # Find mod declaration in parent
    mod_name = test_filename[:-3] # remove .rs
    
    # Patterns like: #[cfg(test)]\nmod tests; or mod tests; or #[cfg(test)]\nmod render_tests;
    mod_patterns = [
        f'#[cfg(test)]\nmod {mod_name};',
        f'#[cfg(test)]\r\nmod {mod_name};',
        f'mod {mod_name};',
    ]
    
    inlined = False
    for pat in mod_patterns:
        if pat in parent_content:
            inline_block = f"#[cfg(test)]\nmod {mod_name} {{\n{test_content}\n}}"
            parent_content = parent_content.replace(pat, inline_block, 1)
            inlined = True
            break
            
    if inlined:
        with open(parent_path, 'w', encoding='utf-8') as f:
            f.write(parent_content)
        os.remove(test_path)
        try:
            os.rmdir(dir_path)
        except OSError:
            pass
        consolidated_count += 1
        print(f"Consolidated solo test: {dir_rel}/{test_filename} -> {parent_rel}")

print(f"\nSuccessfully consolidated {consolidated_count} solo test directories into parent modules!")
