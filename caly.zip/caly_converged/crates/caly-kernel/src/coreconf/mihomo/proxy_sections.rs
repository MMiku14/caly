//! Mihomo proxy-section vocabulary and assembly (`proxies`/`proxy-groups`/
//! `rules` YAML).
//!
//! Each dialable node is rendered into a bounded YAML block (see
//! `super::render`); unsupported protocols are skipped so a mixed real
//! subscription degrades to its representable subset rather than failing the
//! whole render. The final document is assembled by
//! [`super::MihomoConfigRenderer`] from this proxy section. Decoding a
//! subscription body into nodes is intake (`caly-profile`); fusing the two is
//! `caly-backends`' job.

use std::fmt::Write as FmtWrite;

use caly_core::domain::{BoundedText, BoundedVec, NodeId, RuleProviderSource, TextError};

use super::render::yaml_quote;

/// Maximum number of representable Mihomo proxies in one section.
pub const MAX_MIHOMO_PROXIES: usize = 10_000;
/// Maximum rendered YAML bytes for a single proxy block.
pub const MIHOMO_PROXY_YAML_MAX_BYTES: usize = 4_096;
/// Maximum proxy-group name length in bytes.
pub const MIHOMO_GROUP_MAX_BYTES: usize = 128;
/// Maximum proxy display-name (tag) length in bytes.
pub const MIHOMO_TAG_MAX_BYTES: usize = 256;

/// Bounded rendered Mihomo proxy block.
pub type MihomoProxyYaml = BoundedText<MIHOMO_PROXY_YAML_MAX_BYTES>;
/// Bounded proxy-group name.
pub type MihomoGroupName = BoundedText<MIHOMO_GROUP_MAX_BYTES>;
/// Bounded proxy display-name used as the Clash tag.
pub type MihomoProxyTag = BoundedText<MIHOMO_TAG_MAX_BYTES>;

/// One representable subscription node plus its rendered YAML block.
#[derive(Clone, Debug)]
pub struct MihomoProxyEntry {
    /// Stable selection identity; equals the dialable node identity.
    pub id: NodeId,
    /// Clash tag, also used by core selection and group membership.
    pub tag: MihomoProxyTag,
    /// Rendered `- name: ...` YAML block (already indented two spaces).
    pub yaml: MihomoProxyYaml,
}

/// Bounded ordered set of Mihomo proxies from one subscription body.
#[derive(Clone, Debug)]
pub struct MihomoProxySet {
    entries: BoundedVec<MihomoProxyEntry, MAX_MIHOMO_PROXIES>,
    group: MihomoGroupName,
}

impl MihomoProxySet {
    /// Builds a set from validated parts. Constructing from a raw
    /// subscription body (decode → dedupe → per-node render) is the
    /// intake/render fusion in `caly-backends`; the invariants guarded here
    /// are the bounded entry vec and the bounded group name.
    pub fn from_parts(
        entries: BoundedVec<MihomoProxyEntry, MAX_MIHOMO_PROXIES>,
        group: MihomoGroupName,
    ) -> Self {
        Self { entries, group }
    }

    /// Returns the proxy-group name this set feeds.
    pub fn group(&self) -> &str {
        self.group.as_str()
    }
    /// Returns the ordered entries as a slice.
    pub fn entries(&self) -> &[MihomoProxyEntry] {
        self.entries.as_slice()
    }
    /// Moves the ordered entries out (O3: the subscription indexer consumes
    /// the set exactly once, so moving avoids a tag+yaml clone per node).
    pub fn into_entries(self) -> Vec<MihomoProxyEntry> {
        self.entries.into_vec()
    }
    /// Returns the number of representable proxies.
    pub fn len(&self) -> usize {
        self.entries.len()
    }
    /// Returns whether no representable proxy exists.
    pub fn is_empty(&self) -> bool {
        self.entries.is_empty()
    }
}

/// Subscription-to-Mihomo rendering failure.
#[derive(Clone, Debug, Eq, PartialEq)]
pub enum MihomoProxyError {
    /// The body could not be decoded as a supported subscription format.
    InvalidFormat,
    /// The decoded document is not a URI-line subscription.
    UnsupportedDocument,
    /// More representable nodes than the bounded capacity.
    TooManyProxies,
    /// No parseable node was representable as a Mihomo proxy.
    NoUsableNodes,
    /// A bounded field failed validation.
    Text(TextError),
}

impl From<TextError> for MihomoProxyError {
    fn from(value: TextError) -> Self {
        Self::Text(value)
    }
}

/// Emits `proxies:`, `proxy-groups:` and `rules:` YAML from a proxy set.
pub fn render_proxy_sections(set: &MihomoProxySet) -> String {
    let proxies = set
        .entries()
        .iter()
        .map(|entry| (entry.tag.as_str(), entry.yaml.as_str()))
        .collect::<Vec<_>>();
    render_proxy_sections_from(set.group(), &proxies)
}

/// Assembles `proxies:`, `proxy-groups:` and `rules:` YAML from `(tag, yaml)`
/// pairs. Shared by the subscription renderer and the config backend so the
/// proxy-group/rule template stays in one place.
pub fn render_proxy_sections_from<'a>(group: &str, proxies: &[(&'a str, &'a str)]) -> String {
    render_proxy_sections_with_rules(group, proxies, &[])
}

/// Renders proxies, proxy-groups and the routing `rules:` section. Configured
/// rules are emitted in order (first match wins); a `MATCH` catch-all for the
/// active group is appended only when the rule set does not already end one.
pub fn render_proxy_sections_with_rules<'a>(
    group: &str,
    proxies: &[(&'a str, &'a str)],
    rules: &[caly_core::domain::RoutingRule],
) -> String {
    render_proxy_sections_with_rules_and_providers(group, proxies, rules, &[])
}

/// Same as [`render_proxy_sections_with_rules`] but additionally renders a
/// `rule-providers:` block from the user-declared rule providers. Inline
/// providers become `type: inline`; HTTP providers become `type: http`
/// with the polling interval in seconds; file providers become
/// `type: file`. The `behavior` and `format` are forwarded verbatim so
/// the kernel honours the user's intent (domain vs ipcidr, source vs
/// binary).
pub fn render_proxy_sections_with_rules_and_providers<'a>(
    group: &str,
    proxies: &[(&'a str, &'a str)],
    rules: &[caly_core::domain::RoutingRule],
    rule_providers: &[caly_core::domain::RuleProvider],
) -> String {
    render_proxy_sections_with_declared_groups(group, proxies, rules, rule_providers, &[])
}

/// Same as [`render_proxy_sections_with_rules_and_providers`] but also
/// renders user-declared proxy groups.
///
/// User-declared groups are emitted **before** the implicit
/// subscription-derived `url-test` group so a `MATCH,<user group>`
/// rule can win over the catch-all. The implicit `url-test`
/// group is the safety net for configurations that have
/// no `MATCH` rule: the kernel still routes every
/// unmatched packet through a selector.
pub fn render_proxy_sections_with_declared_groups<'a>(
    group: &str,
    proxies: &[(&'a str, &'a str)],
    rules: &[caly_core::domain::RoutingRule],
    rule_providers: &[caly_core::domain::RuleProvider],
    proxy_groups: &[caly_core::domain::ProxyGroup],
) -> String {
    render_sections(
        proxies,
        rules,
        rule_providers,
        proxy_groups,
        Some(group),
        group,
    )
}

/// Renders the section for a subscription that **declares its own
/// proxy-groups** (the subscription document is the single
/// routing source when it carries groups). The declared groups are emitted
/// verbatim — including reference cycles the kernel will diagnose — and the
/// implicit `url-test` group is **not** rendered: the author's topology is
/// complete by construction. `match_fallback` (the first `select` group at
/// the call site) is used only when the merged rule table has no `MATCH`.
pub fn render_proxy_sections_with_subscription_groups<'a>(
    proxies: &[(&'a str, &'a str)],
    rules: &[caly_core::domain::RoutingRule],
    rule_providers: &[caly_core::domain::RuleProvider],
    subscription_groups: &[caly_core::domain::ProxyGroup],
    match_fallback: &str,
) -> String {
    render_sections(
        proxies,
        rules,
        rule_providers,
        subscription_groups,
        None,
        match_fallback,
    )
}

/// Shared renderer: `implicit` names the safety-net `url-test` group to emit
/// after the declared groups (`None` for subscription-owned routing), and
/// `match_fallback` renders the closing `MATCH,<...>` when the rule table
/// lacks one.
fn render_sections(
    proxies: &[(&str, &str)],
    rules: &[caly_core::domain::RoutingRule],
    rule_providers: &[caly_core::domain::RuleProvider],
    groups: &[caly_core::domain::ProxyGroup],
    implicit: Option<&str>,
    match_fallback: &str,
) -> String {
    let mut out = String::from("proxies:\n");
    for (_, yaml) in proxies {
        let _ = writeln!(out, "{yaml}");
    }
    let _ = writeln!(out, "proxy-groups:");
    for declared in groups {
        render_mihomo_proxy_group(&mut out, declared);
    }
    if let Some(group) = implicit {
        let _ = write!(out, "  - name: {}\n    type: url-test\n", yaml_quote(group));
        out.push_str("    url: \"http://www.gstatic.com/generate_204\"\n");
        out.push_str("    interval: 300\n");
        out.push_str("    tolerance: 50\n");
        out.push_str("    proxies:\n");
        for (tag, _) in proxies {
            let _ = writeln!(out, "      - {}", yaml_quote(tag));
        }
        // Deliberately NO `DIRECT` member here. A url-test group measures the
        // probe URL through every member; when the local network can reach that
        // URL directly (gstatic is reachable from CN), DIRECT always wins the
        // race and the whole proxy group silently becomes a no-op passthrough -
        // every "matched" connection then egresses from the local IP instead of
        // a node. All-dead nodes must surface as failures, not masquerade as
        // direct connectivity.
    }
    if !rule_providers.is_empty() {
        out.push_str("rule-providers:\n");
        for provider in rule_providers {
            render_mihomo_provider(&mut out, provider);
        }
    }
    let _ = writeln!(out, "rules:");
    let mut has_match = false;
    for rule in rules {
        let _ = writeln!(out, "  - {}", rule.to_clash_line());
        if matches!(rule.matcher, caly_core::domain::RuleMatch::Match) {
            has_match = true;
        }
    }
    if !has_match {
        let _ = writeln!(out, "  - MATCH,{match_fallback}");
    }
    out
}

/// Appends one user-declared rule provider to the rendered mihomo
/// `rule-providers:` block. The shape mirrors `rule-providers:`
/// (https://wiki.metacubex.one/en/config/rule-providers/): each entry
/// carries a discriminator (`type:`), a `behavior:` field, and a
/// `format:` field. The inline form is caly-specific — the upstream
/// spec does not define it, so we render the rule body under a
/// `payload:` key and let the kernel read the body verbatim.
fn render_mihomo_provider(out: &mut String, provider: &caly_core::domain::RuleProvider) {
    let name = yaml_quote(provider.name.as_str());
    let behavior = provider.behavior.clash_label();
    let format = provider.format.clash_label();
    match &provider.source {
        RuleProviderSource::Http { url, interval_ms } => {
            let interval_seconds = *interval_ms / 1_000;
            let url = yaml_quote(url.as_str());
            let _ = writeln!(
                out,
                "  {name}:\n    type: http\n    behavior: {behavior}\n    format: {format}\n    url: {url}\n    interval: {interval_seconds}\n"
            );
        }
        RuleProviderSource::File { path } => {
            let path = yaml_quote(path.as_str());
            let _ = writeln!(
                out,
                "  {name}:\n    type: file\n    behavior: {behavior}\n    format: {format}\n    path: {path}\n"
            );
        }
        RuleProviderSource::Inline { payload } => {
            // Inline providers carry the rule body under `payload:`.
            // caly's Mihomo backend (or any other kernel configured to
            // read the field) can materialise the body into a real
            // file before the kernel starts.
            let payload = yaml_quote(payload.as_str());
            let _ = writeln!(
                out,
                "  {name}:\n    type: inline\n    behavior: {behavior}\n    format: {format}\n    payload: {payload}\n"
            );
        }
    }
}

/// Appends one user-declared proxy group to the rendered mihomo
/// `proxy-groups:` block. The shape mirrors the Mihomo spec:
///
/// ```yaml
/// proxy-groups:
///   - name: <tag>
///     type: <select|url-test|fallback|load-balance|relay>
///     url: <probe>            # url-test / fallback / load-balance only
///     interval: <seconds>     # url-test / fallback / load-balance only
///     tolerance: <ms>         # url-test only
///     proxies:                # `members:` in the caly schema
///       - <tag>
///       - <tag>
///       - DIRECT
///       - REJECT
/// ```
///
/// The caly schema names the field `members:` for symmetry
/// with the singular `proxies:` field Mihomo uses; the
/// rendered block uses Mihomo's spelling. The schema
/// validator rejects probe-driven groups without a
/// `url_test:` block, so the renderer's `unwrap_or` of a
/// default probe here is only the cold-start fallback
/// for a future caller that bypasses validation.
fn render_mihomo_proxy_group(out: &mut String, group: &caly_core::domain::ProxyGroup) {
    let name = yaml_quote(group.name.as_str());
    let kind = group.kind.clash_label();
    let _ = writeln!(out, "  - name: {name}\n    type: {kind}");

    match &group.kind {
        caly_core::domain::ProxyGroupType::UrlTest { interval_secs, tolerance_ms, lazy } => {
            let _ = writeln!(out, "    interval: {interval_secs}");
            let _ = writeln!(out, "    tolerance: {tolerance_ms}");
            if *lazy {
                let _ = writeln!(out, "    lazy: true");
            }
        }
        caly_core::domain::ProxyGroupType::Fallback { interval_secs, lazy } => {
            let _ = writeln!(out, "    interval: {interval_secs}");
            if *lazy {
                let _ = writeln!(out, "    lazy: true");
            }
        }
        caly_core::domain::ProxyGroupType::LoadBalance { strategy, interval_secs } => {
            let _ = writeln!(out, "    interval: {interval_secs}");
            let _ = writeln!(out, "    strategy: {}", strategy.clash_label());
        }
        _ => {}
    }

    if let Some(url_test) = &group.url_test {
        let url = yaml_quote(url_test.url.as_str());
        let _ = writeln!(out, "    url: {url}");
        if matches!(group.kind, caly_core::domain::ProxyGroupType::Select | caly_core::domain::ProxyGroupType::Relay) {
            let _ = writeln!(out, "    interval: {}", url_test.interval_seconds);
            let _ = writeln!(out, "    tolerance: {}", url_test.tolerance_ms);
        }
    }

    if let Some(filter) = &group.filter {
        let _ = writeln!(out, "    filter: '{filter}'");
    }

    out.push_str("    proxies:\n");
    for member in &group.members {
        let rendered = match member {
            caly_core::domain::ProxyGroupMember::Node { tag } => yaml_quote(tag.as_str()),
            caly_core::domain::ProxyGroupMember::Group { name } => yaml_quote(name.as_str()),
            caly_core::domain::ProxyGroupMember::Direct => "DIRECT".to_owned(),
            caly_core::domain::ProxyGroupMember::Reject => "REJECT".to_owned(),
        };
        let _ = writeln!(out, "      - {rendered}");
    }
}

#[cfg(test)]
mod render_tests {
//! Pure-renderer tests for `proxy_sections.rs` (rules / providers / declared
//! groups assembly), split from the fusion tests that need subscription
//! intake (those live in `caly-backends` next to `render_compose`).

use super::*;

#[test]
fn renders_config_rules_before_match_catch_all() {
    let rules = vec![
        caly_core::domain::RoutingRule::from_clash_line("DOMAIN-SUFFIX,google.com,PROXY").unwrap(),
        caly_core::domain::RoutingRule::from_clash_line("GEOIP,CN,DIRECT").unwrap(),
    ];
    let section = render_proxy_sections_with_rules(
        "AUTO",
        &[("node-a", "  - name: node-a\n    type: ss")],
        &rules,
    );
    assert!(section.contains("rules:"));
    assert!(section.contains("  - DOMAIN-SUFFIX,google.com,PROXY"));
    assert!(section.contains("  - GEOIP,CN,DIRECT"));
    // A MATCH catch-all is appended when the rules lack one.
    assert!(section.contains("  - MATCH,AUTO"));
}

#[test]
fn existing_match_rule_suppresses_extra_catch_all() {
    let rules = vec![caly_core::domain::RoutingRule::from_clash_line("MATCH,PROXY").unwrap()];
    let section = render_proxy_sections_with_rules("AUTO", &[], &rules);
    assert!(section.contains("  - MATCH,PROXY"));
    assert!(!section.contains("MATCH,AUTO"));
}

#[test]
fn rule_providers_http_renders_into_rule_providers_block() {
    use caly_core::domain::{
        RuleProvider, RuleProviderBehavior, RuleProviderFormat, RuleProviderName,
        RuleProviderSource, RuleText,
    };
    let provider = RuleProvider {
        name: RuleProviderName::new("my-google".to_owned()).unwrap(),
        source: RuleProviderSource::Http {
            url: RuleText::new("https://example.com/g.yaml".to_owned()).unwrap(),
            interval_ms: 86_400_000,
        },
        behavior: RuleProviderBehavior::Domain,
        format: RuleProviderFormat::Source,
    };
    let section = render_proxy_sections_with_rules_and_providers(
        "AUTO",
        &[],
        &[],
        std::slice::from_ref(&provider),
    );
    // The provider block carries the right shape: tag, type, behavior,
    // format, url, and an interval in *seconds* (Mihomo convention).
    assert!(section.contains("rule-providers:"), "section: {section}");
    assert!(section.contains("  \"my-google\":"));
    assert!(section.contains("    type: http"));
    assert!(section.contains("    behavior: domain"));
    assert!(section.contains("    format: text"));
    assert!(section.contains("    url: \"https://example.com/g.yaml\""));
    assert!(section.contains("    interval: 86400"));
}

#[test]
fn rule_providers_file_and_inline_render_with_their_respective_keys() {
    use caly_core::domain::{
        BoundedText, RuleProvider, RuleProviderBehavior, RuleProviderFormat, RuleProviderName,
        RuleProviderSource, RuleText,
    };
    let file_provider = RuleProvider {
        name: RuleProviderName::new("local".to_owned()).unwrap(),
        source: RuleProviderSource::File {
            path: RuleText::new("/etc/caly/local.yaml".to_owned()).unwrap(),
        },
        behavior: RuleProviderBehavior::Classical,
        format: RuleProviderFormat::Source,
    };
    let inline_provider = RuleProvider {
        name: RuleProviderName::new("inline".to_owned()).unwrap(),
        source: RuleProviderSource::Inline {
            payload: BoundedText::new("ads.example.com\n".to_owned()).unwrap(),
        },
        behavior: RuleProviderBehavior::DomainSuffix,
        format: RuleProviderFormat::Source,
    };
    let section = render_proxy_sections_with_rules_and_providers(
        "AUTO",
        &[],
        &[],
        &[file_provider, inline_provider],
    );
    assert!(section.contains("  \"local\":"));
    assert!(section.contains("    type: file"));
    assert!(section.contains("    path: \"/etc/caly/local.yaml\""));
    assert!(section.contains("  \"inline\":"));
    assert!(section.contains("    type: inline"));
    assert!(section.contains("    payload: \"ads.example.com\\n\""));
}

#[test]
fn rule_providers_section_is_omitted_when_no_providers_declared() {
    // Backwards-compat: the previous 3-arg entry point must not emit an
    // empty `rule-providers:` block.
    let section = render_proxy_sections_with_rules("AUTO", &[], &[]);
    assert!(!section.contains("rule-providers:"));
}

#[test]
fn proxy_groups_render_before_the_implicit_url_test_group() {
    use caly_core::domain::ProxyGroupNodeTag;
    use caly_core::domain::{ProxyGroup, ProxyGroupMember, ProxyGroupName, ProxyGroupType};
    let group = ProxyGroup {
        name: ProxyGroupName::new("Proxy".to_owned()).unwrap(),
        kind: ProxyGroupType::select(),
        members: vec![
            ProxyGroupMember::Node {
                tag: ProxyGroupNodeTag::new("hk-1".to_owned()).unwrap(),
            },
            ProxyGroupMember::Direct,
        ],
        url_test: None,
    };
    let section = render_proxy_sections_with_declared_groups("AUTO", &[], &[], &[], &[group]);
    // User-declared `Proxy` group appears before the implicit
    // `AUTO` url-test group. The matchers return `Option`;
    // `unwrap_or(usize::MAX)` is a no-op fallback that keeps
    // the assert meaningful while staying lint-clean
    // (the project denies `clippy::expect_used`).
    let proxy_idx = section.find("name: \"Proxy\"").unwrap_or(usize::MAX);
    let auto_idx = section.find("name: \"AUTO\"").unwrap_or(usize::MAX);
    assert!(proxy_idx < usize::MAX, "user group must render");
    assert!(auto_idx < usize::MAX, "implicit group must render");
    assert!(
        proxy_idx < auto_idx,
        "user group must precede the implicit one"
    );
    assert!(section.contains("    type: select"));
    assert!(section.contains("      - \"hk-1\""));
    assert!(section.contains("      - DIRECT"));
}

#[test]
fn proxy_groups_url_test_renders_probe_block() {
    use caly_core::domain::{
        ProxyGroup, ProxyGroupMember, ProxyGroupName, ProxyGroupType, ProxyGroupUrl, UrlTestConfig,
    };
    let group = ProxyGroup {
        name: ProxyGroupName::new("Auto".to_owned()).unwrap(),
        kind: ProxyGroupType::url_test_default(),
        members: vec![ProxyGroupMember::Direct],
        url_test: Some(UrlTestConfig {
            url: ProxyGroupUrl::new("http://www.gstatic.com/generate_204".to_owned()).unwrap(),
            interval_seconds: 300,
            tolerance_ms: 50,
        }),
    };
    let section = render_proxy_sections_with_declared_groups("AUTO", &[], &[], &[], &[group]);
    assert!(section.contains("    type: url-test"));
    assert!(section.contains("    url: \"http://www.gstatic.com/generate_204\""));
    assert!(section.contains("    interval: 300"));
    assert!(section.contains("    tolerance: 50"));
    assert!(section.contains("      - DIRECT"));
}

#[test]
fn proxy_groups_section_omitted_when_no_groups_declared() {
    let section = render_proxy_sections_with_declared_groups("AUTO", &[], &[], &[], &[]);
    // The block header is always present; with no user
    // groups, only the implicit `AUTO` entry should appear.
    let count = section.matches("- name:").count();
    assert_eq!(count, 1, "only the implicit AUTO group should be present");
    assert!(section.contains("name: \"AUTO\""));
}

#[test]
fn renders_tolerance_lazy_strategy_and_filter() {
    use caly_core::domain::{LoadBalanceStrategy, ProxyGroup, ProxyGroupMember, ProxyGroupName, ProxyGroupType};
    let group = ProxyGroup::new(
        ProxyGroupName::new("P2C-Group".to_owned()).unwrap(),
        ProxyGroupType::LoadBalance {
            strategy: LoadBalanceStrategy::P2c,
            interval_secs: 150,
        },
        vec![ProxyGroupMember::Direct],
    ).with_filter(".*JP.*");

    let section = render_proxy_sections_with_declared_groups("AUTO", &[], &[], &[], &[group]);
    assert!(section.contains("type: load-balance"));
    assert!(section.contains("strategy: p2c"));
    assert!(section.contains("interval: 150"));
    assert!(section.contains("filter: '.*JP.*'"));
}

}

#[cfg(test)]
mod url_test_group_tests {
    use super::*;

    #[test]
    fn url_test_group_never_lists_direct_as_member() {
        let section = render_proxy_sections_with_rules("AUTO", &[("n1", "    - name: n1\n")], &[]);
        // group members live between `    proxies:` and `rules:`.
        let tail = section.split("    proxies:\n").nth(1);
        assert!(tail.is_some(), "group block");
        let members = tail
            .unwrap_or_default()
            .split("rules:\n")
            .next()
            .unwrap_or_default()
            .lines()
            .map(str::trim)
            .filter(|l| l.starts_with("- "))
            .collect::<Vec<_>>();
        assert_eq!(members, vec!["- \"n1\""], "group must contain only proxies");
        // the rules tail still exists with the MATCH fallback
        assert!(section.contains("  - MATCH,AUTO"));
    }
}
