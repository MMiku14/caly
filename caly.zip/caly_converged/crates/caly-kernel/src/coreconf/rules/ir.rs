//! Unified Rule Intermediate Representation (Rule IR).
//!
//! Provides a core-agnostic AST for routing rules that both Mihomo and sing-box
//! can compile from without semantic divergence or asymmetric feature loss.
//!
//! Supports rich matchers:
//! - Domain (Full, Suffix, Keyword, Regex)
//! - IP CIDR (Destination & Source)
//! - GeoIP & GeoSite (Country code, category, private IP)
//! - Process (Name, Path)
//! - Port (Destination & Source)
//! - Protocol / Network (TCP / UDP)
//! - Inbound tag routing & DNS hijacking

use serde::{Deserialize, Serialize};
use std::collections::BTreeSet;

/// Core-agnostic traffic matcher in the Intermediate Representation.
#[derive(Clone, Debug, Eq, PartialEq, Serialize, Deserialize)]

/// Unified Rule Set Provider definition directly attached to a rule or referenced.
#[derive(Clone, Debug, Eq, PartialEq, Serialize, Deserialize)]
pub struct RuleSetProviderIr {
    pub tag: String,
    pub source: ProviderSourceIr,
    pub behavior: ProviderBehaviorIr,
    pub format: ProviderFormatIr,
}

#[derive(Clone, Debug, Eq, PartialEq, Serialize, Deserialize)]
pub enum ProviderSourceIr {
    Http { url: String, interval_secs: u32 },
    File { path: String },
    Inline { payload: Vec<String> },
}

#[derive(Clone, Copy, Debug, Default, Eq, PartialEq, Serialize, Deserialize)]
#[serde(rename_all = "lowercase")]
pub enum ProviderBehaviorIr {
    #[default]
    Domain,
    IpCidr,
    Classical,
}

#[derive(Clone, Copy, Debug, Default, Eq, PartialEq, Serialize, Deserialize)]
#[serde(rename_all = "lowercase")]
pub enum ProviderFormatIr {
    #[default]
    Text,
    Binary,
}

pub enum MatcherIr {
    /// Unified self-contained Rule-Set Provider (unifies Rule and RuleProvider).
    Provider(Box<RuleSetProviderIr>),
    /// Exact full domain match (e.g. `DOMAIN,example.com`).
    Domain(String),
    /// Domain suffix match (`.example.com` or `example.com`).
    DomainSuffix(String),
    /// Domain keyword match anywhere in hostname.
    DomainKeyword(String),
    /// Regular expression hostname match.
    DomainRegex(String),
    /// Destination IP CIDR block (e.g. `192.168.0.0/16` or `2001:db8::/32`).
    IpCidr(String),
    /// Source IP CIDR block.
    SourceIpCidr(String),
    /// Private / reserved IP address check (RFC 1918, loopback, link-local).
    IpIsPrivate,
    /// GeoIP match: country code (e.g. `CN`, `US`, `PRIVATE`).
    GeoIp {
        code: String,
        is_private: bool,
    },
    /// GeoSite match: category (e.g. `cn`, `google`, `apple`, `category-ads-all`).
    GeoSite {
        category: String,
    },
    /// Named Rule-Set reference (`RULE-SET,<name>`).
    RuleSet {
        tag: String,
    },
    /// Process name pattern (e.g. `curl`, `telegram`, `chrome.exe`).
    ProcessName(String),
    /// Full process executable path.
    ProcessPath(String),
    /// Destination port.
    Port(u16),
    /// Source port.
    SourcePort(u16),
    /// L4 Transport Protocol: "tcp", "udp".
    Network(String),
    /// Inbound interface/listener tag (e.g. `tun-in`, `mixed-in`).
    Inbound(String),
    /// Catch-all match (Clash `MATCH`).
    Match,
}

/// Core-agnostic routing action in the Intermediate Representation.
#[derive(Clone, Debug, Eq, PartialEq, Serialize, Deserialize)]
pub enum ActionIr {
    /// Direct, unproxied outbound.
    Direct,
    /// Block / Reject traffic.
    Reject,
    /// Steer traffic to a named outbound (node tag or proxy group name).
    Outbound(String),
    /// Intercept DNS queries and steer into internal DNS resolver.
    DnsHijack,
}

/// A complete, normalized routing rule in the Intermediate Representation.
#[derive(Clone, Debug, Eq, PartialEq, Serialize, Deserialize)]
pub struct RuleIr {
    /// What traffic this rule matches.
    pub matcher: MatcherIr,
    /// What action to take when matched.
    pub action: ActionIr,
    /// Prevents DNS resolution during IP-based rule evaluation.
    pub no_resolve: bool,
    /// Inverts matcher predicate (logical NOT).
    pub invert: bool,
}

impl RuleIr {
    /// Constructs a basic RuleIr.
    pub fn new(matcher: MatcherIr, action: ActionIr) -> Self {
        Self {
            matcher,
            action,
            no_resolve: false,
            invert: false,
        }
    }

    /// Sets the `no_resolve` flag.
    pub fn with_no_resolve(mut self, no_resolve: bool) -> Self {
        self.no_resolve = no_resolve;
        self
    }

    /// Sets the `invert` flag.
    pub fn with_invert(mut self, invert: bool) -> Self {
        self.invert = invert;
        self
    }

    /// Emits a Clash/Mihomo compatible rule line.
    pub fn to_clash_line(&self) -> String {
        let action_str = match &self.action {
            ActionIr::Direct => "DIRECT",
            ActionIr::Reject => "REJECT",
            ActionIr::Outbound(tag) => tag.as_str(),
            ActionIr::DnsHijack => "DIRECT",
        };
        let mut line = match &self.matcher {
            MatcherIr::Domain(domain) => format!("DOMAIN,{domain},{action_str}"),
            MatcherIr::DomainSuffix(suffix) => format!("DOMAIN-SUFFIX,{suffix},{action_str}"),
            MatcherIr::DomainKeyword(keyword) => format!("DOMAIN-KEYWORD,{keyword},{action_str}"),
            MatcherIr::DomainRegex(regex) => format!("DOMAIN-REGEX,{regex},{action_str}"),
            MatcherIr::IpCidr(cidr) => format!("IP-CIDR,{cidr},{action_str}"),
            MatcherIr::SourceIpCidr(cidr) => format!("SRC-IP-CIDR,{cidr},{action_str}"),
            MatcherIr::IpIsPrivate => format!("GEOIP,PRIVATE,{action_str}"),
            MatcherIr::GeoIp { code, is_private } => {
                if *is_private {
                    format!("GEOIP,PRIVATE,{action_str}")
                } else {
                    format!("GEOIP,{code},{action_str}")
                }
            }
            MatcherIr::GeoSite { category } => format!("GEOSITE,{category},{action_str}"),
            MatcherIr::RuleSet { tag } => format!("RULE-SET,{tag},{action_str}"),
            MatcherIr::Provider(p) => format!("RULE-SET,{},{action_str}", p.tag),
            MatcherIr::ProcessName(name) => format!("PROCESS-NAME,{name},{action_str}"),
            MatcherIr::ProcessPath(path) => format!("PROCESS-PATH,{path},{action_str}"),
            MatcherIr::Port(port) => format!("DST-PORT,{port},{action_str}"),
            MatcherIr::SourcePort(port) => format!("SRC-PORT,{port},{action_str}"),
            MatcherIr::Network(net) => format!("NETWORK,{net},{action_str}"),
            MatcherIr::Inbound(inb) => format!("INBOUND-PORT,{inb},{action_str}"),
            MatcherIr::Match => format!("MATCH,{action_str}"),
        };
        if self.no_resolve && matches!(self.matcher, MatcherIr::IpCidr(_) | MatcherIr::GeoIp { .. }) {
            line.push_str(",no-resolve");
        }
        line
    }
}

/// Normalized collection of rules and rule providers in the Intermediate Representation.
#[derive(Clone, Debug, Default, Eq, PartialEq)]
pub struct RuleSetIr {
    /// Ordered list of normalized rules.
    pub rules: Vec<RuleIr>,
    /// Referencable user-declared or auto-emitted rule-provider tags.
    pub providers: BTreeSet<String>,
    /// Fallback outbound for traffic matching no explicit rule.
    pub default_outbound: String,
}

impl RuleSetIr {
    pub fn new(default_outbound: impl Into<String>) -> Self {
        Self {
            rules: Vec::new(),
            providers: BTreeSet::new(),
            default_outbound: default_outbound.into(),
        }
    }

    pub fn push(&mut self, rule: RuleIr) {
        self.rules.push(rule);
    }
}


/// Compiles a domain `RoutingRule` into an intermediate representation (`RuleIr`).
pub fn compile_domain_rule(rule: &caly_core::domain::RoutingRule) -> RuleIr {
    use caly_core::domain::RuleMatch;
    let matcher = match &rule.matcher {
        RuleMatch::Domain(d) => MatcherIr::Domain(d.as_str().to_owned()),
        RuleMatch::DomainSuffix(d) => MatcherIr::DomainSuffix(d.as_str().trim_start_matches('.').to_owned()),
        RuleMatch::DomainKeyword(d) => MatcherIr::DomainKeyword(d.as_str().to_owned()),
        RuleMatch::IpCidr(c) => MatcherIr::IpCidr(c.as_str().to_owned()),
        RuleMatch::SourceIpCidr(c) => MatcherIr::SourceIpCidr(c.as_str().to_owned()),
        RuleMatch::Geoip(g) => {
            if g.as_str().eq_ignore_ascii_case("private") {
                MatcherIr::IpIsPrivate
            } else {
                MatcherIr::GeoIp {
                    code: g.as_str().to_ascii_uppercase(),
                    is_private: false,
                }
            }
        }
        RuleMatch::Geosite(g) => MatcherIr::GeoSite {
            category: g.as_str().to_ascii_lowercase(),
        },
        RuleMatch::RuleSet(r) => MatcherIr::RuleSet {
            tag: r.as_str().to_owned(),
        },
        RuleMatch::ProcessName(p) => MatcherIr::ProcessName(p.as_str().to_owned()),
        RuleMatch::Match => MatcherIr::Match,
    };
    let action = match &rule.policy {
        caly_core::domain::RulePolicy::Direct => ActionIr::Direct,
        caly_core::domain::RulePolicy::Reject => ActionIr::Reject,
        caly_core::domain::RulePolicy::Proxy(p) => ActionIr::Outbound(p.as_str().to_owned()),
    };
    RuleIr::new(matcher, action).with_no_resolve(rule.flags.no_resolve)
}
