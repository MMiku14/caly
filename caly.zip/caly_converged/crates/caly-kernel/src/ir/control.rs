//! Unified Control & Node Selection Intermediate Representation (Control IR).
//!
//! Bridges application-level node selection and mode switching intents
//! to kernel-specific primitives, normalizing the differences in how Mihomo
//! (display names) and sing-box (hex tags) address proxy group members.

use caly_core::domain::{CoreKind, NodeId, ProxyMode};
use serde::{Deserialize, Serialize};

/// Canonical target for a node selection intent.
#[derive(Clone, Debug, Eq, PartialEq, Serialize, Deserialize)]
pub struct NodeSelectionIntent {
    pub node_id: NodeId,
    pub display_name: String,
    pub group_name: String,
}

impl NodeSelectionIntent {
    pub fn new(node_id: NodeId, display_name: impl Into<String>, group_name: impl Into<String>) -> Self {
        Self {
            node_id,
            display_name: display_name.into(),
            group_name: group_name.into(),
        }
    }

    /// Translates this intent into the exact `(group, member_selector)` tuple
    /// expected by the target kernel's REST control API.
    pub fn compile_for_core(&self, core: CoreKind) -> (String, String) {
        match core {
            CoreKind::Mihomo => {
                // Mihomo addresses nodes by their declared display name
                (self.group_name.clone(), self.display_name.clone())
            }
            CoreKind::SingBox => {
                // sing-box tags individual nodes as `proxy-<hex>` under the PROXY selector
                let tag = format!("proxy-{}", caly_core::domain::to_hex(self.node_id.into_bytes()));
                ("PROXY".to_owned(), tag)
            }
            CoreKind::Xray => (self.group_name.clone(), self.display_name.clone()),
        }
    }

    /// Normalizes built-in targets (DIRECT, REJECT/BLOCK) across both kernels.
    pub fn compile_builtin(member: &str, core: CoreKind) -> String {
        let is_direct = member.eq_ignore_ascii_case("DIRECT");
        let is_reject = member.eq_ignore_ascii_case("REJECT") || member.eq_ignore_ascii_case("BLOCK");

        match core {
            CoreKind::Mihomo => {
                if is_direct {
                    "DIRECT".to_owned()
                } else if is_reject {
                    "REJECT".to_owned()
                } else {
                    member.to_owned()
                }
            }
            CoreKind::SingBox => {
                if is_direct {
                    "direct".to_owned()
                } else if is_reject {
                    "block".to_owned()
                } else {
                    member.to_owned()
                }
            }
            CoreKind::Xray => member.to_owned(),
        }
    }

    /// Normalizes routing mode string across cores.
    pub fn compile_mode(mode: ProxyMode, core: CoreKind) -> &'static str {
        match core {
            CoreKind::Mihomo => match mode {
                ProxyMode::Rule => "rule",
                ProxyMode::Global => "global",
                ProxyMode::Direct => "direct",
            },
            CoreKind::SingBox => match mode {
                ProxyMode::Rule => "Rule",
                ProxyMode::Global => "Global",
                ProxyMode::Direct => "Direct",
            },
            CoreKind::Xray => "rule",
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn translates_intents_for_both_cores() {
        let node_id = NodeId::from_bytes([0xAB; 16]);
        let intent = NodeSelectionIntent::new(node_id, "HK-01-BGP", "PROXY");

        // Mihomo uses display name
        let (group_m, member_m) = intent.compile_for_core(CoreKind::Mihomo);
        assert_eq!(group_m, "PROXY");
        assert_eq!(member_m, "HK-01-BGP");

        // SingBox uses proxy-<hex> tag
        let (group_s, member_s) = intent.compile_for_core(CoreKind::SingBox);
        assert_eq!(group_s, "PROXY");
        assert!(member_s.starts_with("proxy-"));
        assert!(member_s.contains("ababab"));
    }

    #[test]
    fn normalizes_builtins() {
        assert_eq!(NodeSelectionIntent::compile_builtin("DIRECT", CoreKind::Mihomo), "DIRECT");
        assert_eq!(NodeSelectionIntent::compile_builtin("DIRECT", CoreKind::SingBox), "direct");
        assert_eq!(NodeSelectionIntent::compile_builtin("REJECT", CoreKind::Mihomo), "REJECT");
        assert_eq!(NodeSelectionIntent::compile_builtin("REJECT", CoreKind::SingBox), "block");
    }
}
