//! Unified Intermediate Representation (IR) Layer.
//!
//! Provides a canonical, kernel-agnostic bridge between the Application Layer
//! (CLI, TUI, Daemon, Telemetry) and the heterogeneous proxy cores (Mihomo & sing-box).
//!
//! Subsystems:
//! - [`rule`]: Unified Routing Rules AST and compiler.
//! - [`telemetry`]: Unified Connection Metrics & Flow Inspector IR.
//! - [`control`]: Unified Node Selection & Group Control IR.
//! - [`transport`]: Unified Transport Configuration IR.

pub mod control;
pub mod rule;
pub mod telemetry;
pub mod transport;

pub use control::NodeSelectionIntent;
pub use rule::{ActionIr, MatcherIr, RuleIr, RuleSetIr};
pub use telemetry::{ConnectionIr, DeviceTrafficSummary, GatewayFlowSummary, HostTrafficSummary, ProtocolBreakdown, aggregate_by_device, aggregate_by_host, aggregate_by_protocol, parse_connections_ir, summarize_gateway_flow};
pub use transport::TransportIr;

#[cfg(test)]
mod tests {
    use super::*;
    use caly_core::domain::{CoreKind, NodeId};

    #[test]
    fn test_unified_ir_roundtrip() {
        // 1. Control IR Intent compilation
        let node_id = NodeId::from_bytes([0x12; 16]);
        let intent = NodeSelectionIntent::new(node_id, "HK-01-BGP", "PROXY");
        let (grp_m, mem_m) = intent.compile_for_core(CoreKind::Mihomo);
        assert_eq!(grp_m, "PROXY");
        assert_eq!(mem_m, "HK-01-BGP");

        let (grp_s, mem_s) = intent.compile_for_core(CoreKind::SingBox);
        assert_eq!(grp_s, "PROXY");
        assert!(mem_s.starts_with("proxy-"));

        // 2. Builtin mapping
        assert_eq!(NodeSelectionIntent::compile_builtin("DIRECT", CoreKind::Mihomo), "DIRECT");
        assert_eq!(NodeSelectionIntent::compile_builtin("DIRECT", CoreKind::SingBox), "direct");
        assert_eq!(NodeSelectionIntent::compile_builtin("REJECT", CoreKind::SingBox), "block");

        // 3. Transport IR mapping
        let h2 = TransportIr::Http2 {
            path: "/h2".to_owned(),
            hosts: vec!["test.com".to_owned()],
        };
        assert_eq!(h2.mihomo_network(), "h2");
        assert_eq!(h2.sing_box_type(), Some("http"));

        let up = TransportIr::HttpUpgrade {
            path: "/up".to_owned(),
            host: Some("test.com".to_owned()),
        };
        assert_eq!(up.sing_box_type(), Some("httpupgrade"));
    }

    #[test]
    fn test_telemetry_ir_schema_parities() {
        let sing_box_payload = serde_json::json!({
            "connections": [
                {
                    "id": "sb-01",
                    "metadata": {
                        "network": "tcp",
                        "type": "HTTP",
                        "host": "google.com",
                        "destinationPort": 443
                    },
                    "upload": 100,
                    "download": 200,
                    "chains": ["PROXY", "node-hk"]
                }
            ]
        });

        let mihomo_payload = serde_json::json!({
            "connections": [
                {
                    "id": "mh-01",
                    "metadata": {
                        "network": "udp",
                        "type": "DNS",
                        "destinationIP": "8.8.8.8",
                        "destinationPort": "53"
                    },
                    "uploadTotal": 50,
                    "downloadTotal": 150,
                    "outbound": "direct"
                }
            ]
        });

        let sb_conns = parse_connections_ir(&sing_box_payload);
        assert_eq!(sb_conns.len(), 1);
        assert_eq!(sb_conns[0].destination_port, 443);
        assert_eq!(sb_conns[0].display_target(), "google.com:443");
        assert_eq!(sb_conns[0].display_chain(), "PROXY → node-hk");

        let mh_conns = parse_connections_ir(&mihomo_payload);
        assert_eq!(mh_conns.len(), 1);
        assert_eq!(mh_conns[0].destination_port, 53);
        assert_eq!(mh_conns[0].display_target(), "8.8.8.8:53");
        assert_eq!(mh_conns[0].display_chain(), "direct");
    }
}
