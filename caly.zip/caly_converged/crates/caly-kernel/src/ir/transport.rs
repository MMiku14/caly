//! Unified Transport Intermediate Representation (Transport IR).
//!
//! Bridges node transport configurations across Mihomo and sing-box, guaranteeing
//! that HTTP/2, HTTPUpgrade, WebSocket, gRPC, and QUIC transports compile cleanly
//! without protocol conflation or dropped options.

use serde::{Deserialize, Serialize};

/// Core-agnostic transport configuration.
#[derive(Clone, Debug, Eq, PartialEq, Serialize, Deserialize)]
pub enum TransportIr {
    /// Plain TCP stream.
    Tcp,
    /// WebSocket stream with optional Host header and 0-RTT early data.
    WebSocket {
        path: String,
        host: Option<String>,
        max_early_data: Option<u32>,
    },
    /// True HTTP/2 transport (RFC 7540).
    Http2 {
        path: String,
        hosts: Vec<String>,
    },
    /// HTTP/1.1 Upgrade tunnel (RFC 7230).
    HttpUpgrade {
        path: String,
        host: Option<String>,
    },
    /// gRPC streaming transport.
    Grpc {
        service_name: String,
    },
    /// QUIC datagram transport.
    Quic,
}

impl TransportIr {
    /// Returns the primary network name for Mihomo ("ws", "http", "grpc", "tcp").
    pub fn mihomo_network(&self) -> &'static str {
        match self {
            Self::Tcp => "tcp",
            Self::WebSocket { .. } => "ws",
            Self::Http2 { .. } => "h2",
            Self::HttpUpgrade { .. } => "http",
            Self::Grpc { .. } => "grpc",
            Self::Quic => "quic",
        }
    }

    /// Returns the sing-box transport type name ("http", "httpupgrade", "ws", "grpc", "quic").
    pub fn sing_box_type(&self) -> Option<&'static str> {
        match self {
            Self::Tcp => None,
            Self::WebSocket { .. } => Some("ws"),
            Self::Http2 { .. } => Some("http"), // sing-box uses "http" for H2
            Self::HttpUpgrade { .. } => Some("httpupgrade"),
            Self::Grpc { .. } => Some("grpc"),
            Self::Quic => Some("quic"),
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn differentiates_h2_from_httpupgrade() {
        let h2 = TransportIr::Http2 {
            path: "/h2".to_owned(),
            hosts: vec!["example.com".to_owned()],
        };
        let upgrade = TransportIr::HttpUpgrade {
            path: "/up".to_owned(),
            host: Some("example.com".to_owned()),
        };

        // Mihomo mapping
        assert_eq!(h2.mihomo_network(), "h2");
        assert_eq!(upgrade.mihomo_network(), "http");

        // SingBox mapping: must not confuse "http" and "httpupgrade"
        assert_eq!(h2.sing_box_type(), Some("http"));
        assert_eq!(upgrade.sing_box_type(), Some("httpupgrade"));
    }
}
