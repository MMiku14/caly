//! Unified Telemetry & Connection Intermediate Representation (Connection IR).
//!
//! Normalizes connection metrics and routing traces across Mihomo and sing-box
//! so the application layer (CLI flow, TUI, Prometheus exporter, daemon) interacts
//! with a single, schema-drift-immune data model.

use std::collections::{BTreeMap, HashMap};
use serde::{Deserialize, Serialize};

/// Canonical live connection reported by the kernel control plane.
#[derive(Clone, Debug, Default, Eq, PartialEq, Serialize, Deserialize)]
pub struct ConnectionIr {
    /// Unique connection identifier.
    pub id: String,
    /// Client source address (IP).
    pub source_ip: String,
    /// Client source port.
    pub source_port: u16,
    /// Destination hostname if resolved or requested.
    pub destination_host: String,
    /// Destination IP address if known.
    pub destination_ip: String,
    /// Destination port number.
    pub destination_port: u16,
    /// L4 transport protocol ("tcp" or "udp").
    pub network: String,
    /// L7 application protocol ("HTTP", "TLS", "DNS", etc.).
    pub protocol_type: String,
    /// Name or tag of the inbound listener (e.g. "mixed-in", "tun-in").
    pub inbound_tag: String,
    /// Process executable path if kernel supports process sniffing.
    pub process_path: String,
    /// Name of the matched routing rule.
    pub rule: String,
    /// Specific payload or parameter of the matched rule.
    pub rule_payload: String,
    /// Resolved outbound name (direct, reject, or proxy group).
    pub outbound: String,
    /// Outbound proxy chain traversed by this connection.
    pub chains: Vec<String>,
    /// Cumulative uploaded bytes.
    pub upload_bytes: u64,
    /// Cumulative downloaded bytes.
    pub download_bytes: u64,
    /// Connection start timestamp (RFC 3339 / ISO 8601 string).
    pub start_time: String,
}

impl ConnectionIr {
    /// Returns the primary display target (hostname:port, or ip:port).
    pub fn display_target(&self) -> String {
        if !self.destination_host.is_empty() {
            format!("{}:{}", self.destination_host, self.destination_port)
        } else if !self.destination_ip.is_empty() {
            format!("{}:{}", self.destination_ip, self.destination_port)
        } else {
            format!("-:{}", self.destination_port)
        }
    }

    /// Returns the client source representation (`ip:port`).
    pub fn display_source(&self) -> String {
        if self.source_port > 0 {
            format!("{}:{}", self.source_ip, self.source_port)
        } else if !self.source_ip.is_empty() {
            self.source_ip.clone()
        } else {
            "127.0.0.1".to_owned()
        }
    }

    /// Returns the formatted chain string (e.g. `PROXY → HK-01`).
    pub fn display_chain(&self) -> String {
        if self.chains.is_empty() {
            if self.outbound.is_empty() {
                "-".to_owned()
            } else {
                self.outbound.clone()
            }
        } else {
            self.chains.join(" → ")
        }
    }

    /// Returns duration in seconds (always >= 1 to prevent division by zero).
    pub fn duration_secs(&self) -> u64 {
        caly_core::domain::parse_iso_duration_secs(&self.start_time).max(1)
    }

    /// Calculated upload transfer rate in bytes per second.
    pub fn upload_rate_bps(&self) -> u64 {
        self.upload_bytes / self.duration_secs().max(1)
    }

    /// Calculated download transfer rate in bytes per second.
    pub fn download_rate_bps(&self) -> u64 {
        self.download_bytes / self.duration_secs().max(1)
    }

    /// Categorizes this connection into standard L7 protocol buckets.
    pub fn l7_category(&self) -> &'static str {
        caly_core::domain::categorize_l7_protocol(&self.protocol_type, self.destination_port)
    }
}

/// Parses the `/connections` JSON response from either Mihomo or sing-box.
pub fn parse_connections_ir(root: &serde_json::Value) -> Vec<ConnectionIr> {
    let Some(connections) = root.get("connections").and_then(serde_json::Value::as_array) else {
        return Vec::new();
    };
    connections.iter().map(parse_single_connection).collect()
}

fn parse_single_connection(conn: &serde_json::Value) -> ConnectionIr {
    let metadata = conn.get("metadata");

    // Hostname
    let host = meta_string(metadata, "host");
    let mut destination_ip = meta_key_fallbacks(metadata, &["destinationIP", "destination_ip", "dst_ip"]);
    if destination_ip.is_empty() {
        destination_ip = meta_key_fallbacks(Some(conn), &["destinationIP", "destination_ip", "dst_ip"]);
    }

    // Destination port: supports integer and string
    let destination_port = metadata
        .and_then(|m| m.get("destinationPort").or_else(|| m.get("destination_port")))
        .and_then(extract_port)
        .or_else(|| conn.get("destinationPort").and_then(extract_port))
        .unwrap_or(0);

    // Source IP & port
    let source_ip = meta_key_fallbacks(metadata, &["sourceIP", "source_ip", "src_ip"]);
    let source_port = metadata
        .and_then(|m| m.get("sourcePort").or_else(|| m.get("source_port")))
        .and_then(extract_port)
        .unwrap_or(0);

    // Network & type
    let network = meta_string(metadata, "network");
    let protocol_type = meta_string(metadata, "type");
    let inbound_tag = {
        let tag = meta_string(metadata, "inboundName");
        if tag.is_empty() {
            meta_string(metadata, "inbound")
        } else {
            tag
        }
    };
    let process_path = meta_string(metadata, "processPath");

    // Rule & Outbound
    let rule = meta_or_top(metadata, conn, "rule");
    let rule_payload = meta_or_top(metadata, conn, "rulePayload");
    let outbound = meta_or_top(metadata, conn, "outbound");

    // Chain / Chains
    let chains = extract_chains(metadata, conn);

    // Upload / Download bytes
    let upload_bytes = extract_traffic(conn, &["upload", "uploadTotal"]);
    let download_bytes = extract_traffic(conn, &["download", "downloadTotal"]);

    // Start time
    let start_time = conn
        .get("start")
        .or_else(|| conn.get("startTime"))
        .and_then(serde_json::Value::as_str)
        .unwrap_or_default()
        .to_owned();

    ConnectionIr {
        id: conn.get("id").and_then(serde_json::Value::as_str).unwrap_or_default().to_owned(),
        source_ip,
        source_port,
        destination_host: host,
        destination_ip,
        destination_port,
        network,
        protocol_type,
        inbound_tag,
        process_path,
        rule,
        rule_payload,
        outbound,
        chains,
        upload_bytes,
        download_bytes,
        start_time,
    }
}

fn extract_port(val: &serde_json::Value) -> Option<u16> {
    val.as_u64()
        .and_then(|v| u16::try_from(v).ok())
        .or_else(|| val.as_str().and_then(|s| s.parse().ok()))
}

fn meta_string(metadata: Option<&serde_json::Value>, key: &str) -> String {
    metadata
        .and_then(|m| m.get(key))
        .and_then(serde_json::Value::as_str)
        .unwrap_or_default()
        .to_owned()
}

fn meta_key_fallbacks(metadata: Option<&serde_json::Value>, keys: &[&str]) -> String {
    let Some(m) = metadata else {
        return String::new();
    };
    for &k in keys {
        if let Some(s) = m.get(k).and_then(serde_json::Value::as_str) {
            if !s.is_empty() {
                return s.to_owned();
            }
        }
    }
    String::new()
}

fn meta_or_top(metadata: Option<&serde_json::Value>, conn: &serde_json::Value, key: &str) -> String {
    let s = meta_string(metadata, key);
    if !s.is_empty() {
        return s;
    }
    conn.get(key)
        .and_then(serde_json::Value::as_str)
        .unwrap_or_default()
        .to_owned()
}

fn extract_chains(metadata: Option<&serde_json::Value>, conn: &serde_json::Value) -> Vec<String> {
    let arr = metadata
        .and_then(|m| m.get("chains").or_else(|| m.get("chain")))
        .and_then(serde_json::Value::as_array)
        .or_else(|| {
            conn.get("chains")
                .or_else(|| conn.get("chain"))
                .and_then(serde_json::Value::as_array)
        });

    arr.map(|items| {
        items
            .iter()
            .filter_map(serde_json::Value::as_str)
            .map(str::to_owned)
            .collect()
    })
    .unwrap_or_default()
}

fn extract_traffic(conn: &serde_json::Value, keys: &[&str]) -> u64 {
    let mut max_val = 0;
    for &k in keys {
        if let Some(val) = conn.get(k).and_then(serde_json::Value::as_u64) {
            max_val = max_val.max(val);
        }
    }
    max_val
}

/// Aggregated traffic summary for a LAN client device.
#[derive(Clone, Debug, Default, Eq, PartialEq, Serialize, Deserialize)]
pub struct DeviceTrafficSummary {
    pub source_ip: String,
    pub active_connections: usize,
    pub upload_bytes: u64,
    pub download_bytes: u64,
    pub upload_rate_bps: u64,
    pub download_rate_bps: u64,
    pub primary_destination: String,
    pub top_protocol: String,
}

/// Aggregated traffic summary for a destination host (Top Talkers).
#[derive(Clone, Debug, Default, Eq, PartialEq, Serialize, Deserialize)]
pub struct HostTrafficSummary {
    pub destination_host: String,
    pub active_connections: usize,
    pub upload_bytes: u64,
    pub download_bytes: u64,
    pub upload_rate_bps: u64,
    pub download_rate_bps: u64,
    pub outbound_chain: String,
    pub top_client: String,
}

/// L4 and L7 protocol breakdown metrics.
#[derive(Clone, Debug, Default, Eq, PartialEq, Serialize, Deserialize)]
pub struct ProtocolBreakdown {
    pub tcp_connections: usize,
    pub udp_connections: usize,
    pub tcp_bytes: u64,
    pub udp_bytes: u64,
    pub l7_protocols: BTreeMap<String, usize>,
    pub l7_bytes: BTreeMap<String, u64>,
}

/// Overall gateway-level flow summary metrics.
#[derive(Clone, Debug, Default, Eq, PartialEq, Serialize, Deserialize)]
pub struct GatewayFlowSummary {
    pub total_connections: usize,
    pub total_upload_bytes: u64,
    pub total_download_bytes: u64,
    pub total_upload_rate_bps: u64,
    pub total_download_rate_bps: u64,
    pub active_devices: usize,
    pub top_device: String,
    pub top_destination: String,
    pub top_protocol: String,
}

/// Computes the comprehensive gateway flow summary.
pub fn summarize_gateway_flow(connections: &[ConnectionIr]) -> GatewayFlowSummary {
    let mut sum = GatewayFlowSummary::default();
    sum.total_connections = connections.len();

    let mut device_set = HashMap::new();
    let mut dest_set = HashMap::new();
    let mut proto_set = HashMap::new();

    for c in connections {
        sum.total_upload_bytes = sum.total_upload_bytes.saturating_add(c.upload_bytes);
        sum.total_download_bytes = sum.total_download_bytes.saturating_add(c.download_bytes);
        sum.total_upload_rate_bps = sum.total_upload_rate_bps.saturating_add(c.upload_rate_bps());
        sum.total_download_rate_bps = sum.total_download_rate_bps.saturating_add(c.download_rate_bps());

        let dev = if c.source_ip.is_empty() { "127.0.0.1" } else { &c.source_ip };
        *device_set.entry(dev.to_owned()).or_insert(0usize) += 1;

        let host = if !c.destination_host.is_empty() {
            &c.destination_host
        } else if !c.destination_ip.is_empty() {
            &c.destination_ip
        } else {
            "-"
        };
        if host != "-" {
            *dest_set.entry(host.to_owned()).or_insert(0usize) += 1;
        }

        let cat = c.l7_category();
        *proto_set.entry(cat.to_owned()).or_insert(0usize) += 1;
    }

    sum.active_devices = device_set.len();
    sum.top_device = device_set.into_iter().max_by_key(|(_, n)| *n).map(|(d, _)| d).unwrap_or_else(|| "-".to_owned());
    sum.top_destination = dest_set.into_iter().max_by_key(|(_, n)| *n).map(|(d, _)| d).unwrap_or_else(|| "-".to_owned());
    sum.top_protocol = proto_set.into_iter().max_by_key(|(_, n)| *n).map(|(p, _)| p).unwrap_or_else(|| "-".to_owned());

    sum
}

#[derive(Default)]
struct DeviceAccumulator {
    connections: usize,
    upload_bytes: u64,
    download_bytes: u64,
    upload_rate: u64,
    download_rate: u64,
    destinations: HashMap<String, usize>,
    protocols: HashMap<String, usize>,
}

/// Groups live connections by client source IP to identify LAN devices.
pub fn aggregate_by_device(connections: &[ConnectionIr]) -> Vec<DeviceTrafficSummary> {
    let mut map: HashMap<String, DeviceAccumulator> = HashMap::new();
    for c in connections {
        let src = if c.source_ip.is_empty() { "127.0.0.1".to_owned() } else { c.source_ip.clone() };
        let entry = map.entry(src).or_default();
        entry.connections += 1;
        entry.upload_bytes = entry.upload_bytes.saturating_add(c.upload_bytes);
        entry.download_bytes = entry.download_bytes.saturating_add(c.download_bytes);
        entry.upload_rate = entry.upload_rate.saturating_add(c.upload_rate_bps());
        entry.download_rate = entry.download_rate.saturating_add(c.download_rate_bps());

        let target = if !c.destination_host.is_empty() {
            c.destination_host.clone()
        } else if !c.destination_ip.is_empty() {
            c.destination_ip.clone()
        } else {
            "-".to_owned()
        };
        if target != "-" {
            *entry.destinations.entry(target).or_insert(0) += 1;
        }
        *entry.protocols.entry(c.l7_category().to_owned()).or_insert(0) += 1;
    }

    let mut summaries: Vec<DeviceTrafficSummary> = map
        .into_iter()
        .map(|(source_ip, acc)| {
            let primary = acc.destinations
                .into_iter()
                .max_by_key(|(_, count)| *count)
                .map(|(d, _)| d)
                .unwrap_or_else(|| "-".to_owned());
            let top_proto = acc.protocols
                .into_iter()
                .max_by_key(|(_, count)| *count)
                .map(|(p, _)| p)
                .unwrap_or_else(|| "Other".to_owned());
            DeviceTrafficSummary {
                source_ip,
                active_connections: acc.connections,
                upload_bytes: acc.upload_bytes,
                download_bytes: acc.download_bytes,
                upload_rate_bps: acc.upload_rate,
                download_rate_bps: acc.download_rate,
                primary_destination: primary,
                top_protocol: top_proto,
            }
        })
        .collect();

    summaries.sort_by(|a, b| (b.download_bytes + b.upload_bytes).cmp(&(a.download_bytes + a.upload_bytes)));
    summaries
}

#[derive(Default)]
struct HostAccumulator {
    connections: usize,
    upload_bytes: u64,
    download_bytes: u64,
    upload_rate: u64,
    download_rate: u64,
    chains: HashMap<String, usize>,
    clients: HashMap<String, usize>,
}

/// Groups live connections by destination hostname, sorted by total bandwidth (Top Talkers).
pub fn aggregate_by_host(connections: &[ConnectionIr]) -> Vec<HostTrafficSummary> {
    let mut map: HashMap<String, HostAccumulator> = HashMap::new();
    for c in connections {
        let host = if !c.destination_host.is_empty() {
            c.destination_host.clone()
        } else if !c.destination_ip.is_empty() {
            c.destination_ip.clone()
        } else {
            "-".to_owned()
        };
        let entry = map.entry(host).or_default();
        entry.connections += 1;
        entry.upload_bytes = entry.upload_bytes.saturating_add(c.upload_bytes);
        entry.download_bytes = entry.download_bytes.saturating_add(c.download_bytes);
        entry.upload_rate = entry.upload_rate.saturating_add(c.upload_rate_bps());
        entry.download_rate = entry.download_rate.saturating_add(c.download_rate_bps());

        let chain_str = c.display_chain();
        *entry.chains.entry(chain_str).or_insert(0) += 1;

        let client = if c.source_ip.is_empty() { "127.0.0.1".to_owned() } else { c.source_ip.clone() };
        *entry.clients.entry(client).or_insert(0) += 1;
    }

    let mut summaries: Vec<HostTrafficSummary> = map
        .into_iter()
        .map(|(destination_host, acc)| {
            let outbound = acc.chains
                .into_iter()
                .max_by_key(|(_, count)| *count)
                .map(|(ch, _)| ch)
                .unwrap_or_else(|| "-".to_owned());
            let top_c = acc.clients
                .into_iter()
                .max_by_key(|(_, count)| *count)
                .map(|(cl, _)| cl)
                .unwrap_or_else(|| "-".to_owned());
            HostTrafficSummary {
                destination_host,
                active_connections: acc.connections,
                upload_bytes: acc.upload_bytes,
                download_bytes: acc.download_bytes,
                upload_rate_bps: acc.upload_rate,
                download_rate_bps: acc.download_rate,
                outbound_chain: outbound,
                top_client: top_c,
            }
        })
        .collect();

    summaries.sort_by(|a, b| (b.download_bytes + b.upload_bytes).cmp(&(a.download_bytes + a.upload_bytes)));
    summaries
}

/// Computes protocol distributions across L4 and L7 with volume breakdowns.
pub fn aggregate_by_protocol(connections: &[ConnectionIr]) -> ProtocolBreakdown {
    let mut breakdown = ProtocolBreakdown::default();
    for c in connections {
        let total = c.upload_bytes.saturating_add(c.download_bytes);
        if c.network.eq_ignore_ascii_case("tcp") {
            breakdown.tcp_connections += 1;
            breakdown.tcp_bytes = breakdown.tcp_bytes.saturating_add(total);
        } else if c.network.eq_ignore_ascii_case("udp") {
            breakdown.udp_connections += 1;
            breakdown.udp_bytes = breakdown.udp_bytes.saturating_add(total);
        }

        let cat = c.l7_category().to_owned();
        *breakdown.l7_protocols.entry(cat.clone()).or_insert(0) += 1;
        let p_bytes = breakdown.l7_bytes.entry(cat).or_insert(0);
        *p_bytes = (*p_bytes).saturating_add(total);
    }
    breakdown
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn parses_sing_box_integer_port_schema() {
        let json = serde_json::json!({
            "connections": [
                {
                    "id": "conn-001",
                    "metadata": {
                        "network": "tcp",
                        "type": "HTTP",
                        "host": "example.com",
                        "destinationPort": 443,
                        "destinationIP": "93.184.216.34"
                    },
                    "upload": 1024,
                    "download": 4096,
                    "chains": ["PROXY", "node-1"],
                    "rule": "Match",
                    "start": "2026-09-13T10:00:00Z"
                }
            ]
        });

        let ir = parse_connections_ir(&json);
        assert_eq!(ir.len(), 1);
        let c = &ir[0];
        assert_eq!(c.destination_port, 443);
        assert_eq!(c.destination_host, "example.com");
        assert_eq!(c.display_target(), "example.com:443");
        assert_eq!(c.upload_bytes, 1024);
        assert_eq!(c.download_bytes, 4096);
        assert_eq!(c.display_chain(), "PROXY → node-1");
        assert_eq!(c.l7_category(), "TLS/HTTPS");
        assert!(c.duration_secs() >= 1);
        assert!(c.upload_rate_bps() <= 1024);
    }

    #[test]
    fn categorizes_l7_protocols_accurately() {
        assert_eq!(categorize_l7_protocol("http", 80), "HTTP");
        assert_eq!(categorize_l7_protocol("tls", 443), "TLS/HTTPS");
        assert_eq!(categorize_l7_protocol("quic", 443), "QUIC");
        assert_eq!(categorize_l7_protocol("dns", 53), "DNS");
        assert_eq!(categorize_l7_protocol("bittorrent", 6881), "BitTorrent");
        assert_eq!(categorize_l7_protocol("ssh", 22), "SSH");
        assert_eq!(categorize_l7_protocol("unknown", 12345), "Other");
    }

    #[test]
    fn summarizes_gateway_flow_correctly() {
        let conns = vec![
            ConnectionIr {
                source_ip: "192.168.1.100".to_owned(),
                destination_host: "github.com".to_owned(),
                destination_port: 443,
                protocol_type: "tls".to_owned(),
                upload_bytes: 1000,
                download_bytes: 5000,
                ..Default::default()
            },
            ConnectionIr {
                source_ip: "192.168.1.101".to_owned(),
                destination_host: "google.com".to_owned(),
                destination_port: 80,
                protocol_type: "http".to_owned(),
                upload_bytes: 200,
                download_bytes: 800,
                ..Default::default()
            },
        ];

        let sum = summarize_gateway_flow(&conns);
        assert_eq!(sum.total_connections, 2);
        assert_eq!(sum.active_devices, 2);
        assert_eq!(sum.total_upload_bytes, 1200);
        assert_eq!(sum.total_download_bytes, 5800);
    }
}


/// Per-client LAN device network usage statistics.
#[derive(Clone, Debug, Default, Eq, PartialEq, Serialize, Deserialize)]
pub struct LanDeviceStats {
    pub source_ip: String,
    pub active_connections: usize,
    pub upload_bytes: u64,
    pub download_bytes: u64,
    pub total_bytes: u64,
}

/// Gateway traffic analytics and protocol breakdown.
#[derive(Clone, Debug, Default, Eq, PartialEq, Serialize, Deserialize)]
pub struct TrafficAnalytics {
    pub total_connections: usize,
    pub total_upload_bytes: u64,
    pub total_download_bytes: u64,
    pub top_domains: Vec<(String, u64)>,
    pub lan_devices: Vec<LanDeviceStats>,
    pub protocol_breakdown: std::collections::BTreeMap<String, usize>,
}

impl TrafficAnalytics {
    /// Computes full gateway traffic analytics from live connection IRs.
    pub fn analyze(connections: &[ConnectionIr]) -> Self {
        let mut total_upload_bytes = 0_u64;
        let mut total_download_bytes = 0_u64;
        let mut domain_traffic: std::collections::HashMap<String, u64> = std::collections::HashMap::new();
        let mut lan_map: std::collections::HashMap<String, (usize, u64, u64)> = std::collections::HashMap::new();
        let mut proto_map: std::collections::BTreeMap<String, usize> = std::collections::BTreeMap::new();

        for conn in connections {
            total_upload_bytes = total_upload_bytes.saturating_add(conn.upload_bytes);
            total_download_bytes = total_download_bytes.saturating_add(conn.download_bytes);
            let conn_total = conn.upload_bytes.saturating_add(conn.download_bytes);

            // Domain aggregation
            if !conn.destination_host.is_empty() {
                *domain_traffic.entry(conn.destination_host.clone()).or_insert(0) += conn_total;
            }

            // LAN device aggregation
            if !conn.source_ip.is_empty() {
                let entry = lan_map.entry(conn.source_ip.clone()).or_insert((0, 0, 0));
                entry.0 += 1;
                entry.1 = entry.1.saturating_add(conn.upload_bytes);
                entry.2 = entry.2.saturating_add(conn.download_bytes);
            }

            // Protocol distribution
            let proto = if !conn.protocol_type.is_empty() {
                conn.protocol_type.clone()
            } else if !conn.network.is_empty() {
                conn.network.to_uppercase()
            } else {
                "OTHER".to_owned()
            };
            *proto_map.entry(proto).or_insert(0) += 1;
        }

        let mut top_domains: Vec<(String, u64)> = domain_traffic.into_iter().collect();
        top_domains.sort_by(|a, b| b.1.cmp(&a.1));
        top_domains.truncate(10);

        let mut lan_devices: Vec<LanDeviceStats> = lan_map
            .into_iter()
            .map(|(ip, (conns, up, down))| LanDeviceStats {
                source_ip: ip,
                active_connections: conns,
                upload_bytes: up,
                download_bytes: down,
                total_bytes: up.saturating_add(down),
            })
            .collect();
        lan_devices.sort_by(|a, b| b.total_bytes.cmp(&a.total_bytes));

        Self {
            total_connections: connections.len(),
            total_upload_bytes,
            total_download_bytes,
            top_domains,
            lan_devices,
            protocol_breakdown: proto_map,
        }
    }
}
