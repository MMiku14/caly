//! Unified kernel driver contract providing polymorphic lifecycle control
//! and state querying across both Mihomo and sing-box cores.

use std::time::Duration;
use caly_core::domain::CoreKind;
use caly_core::platform::process::ProcessExit;
use super::{KernelControl, KernelFailure, RenderedConfigRef};

/// Common lifecycle and control interface implemented by both MihomoRuntime
/// and SingBoxRuntime, eliminating duplicate driver glue code in the daemon.
pub trait KernelDriver: Send + Sync {
    /// Returns which core family this driver instance manages.
    fn core_kind(&self) -> CoreKind;

    /// Whether the managed core process is actively running.
    fn is_running(&self) -> bool;

    /// Starts the core process and waits until ready or timeout.
    fn start(&mut self, timeout: Duration) -> Result<(), KernelFailure>;

    /// Gracefully stops the core process within timeout.
    fn stop(&mut self, timeout: Duration) -> Result<ProcessExit, KernelFailure>;

    /// Restarts the core process using current configuration.
    fn restart(&mut self, timeout: Duration) -> Result<(), KernelFailure>;

    /// Restarts the core with updated configuration and generation.
    fn restart_with_config(
        &mut self,
        config: &RenderedConfigRef,
        generation: u64,
        timeout: Duration,
    ) -> Result<(), KernelFailure>;

    /// Performs readiness verification against the core control plane.
    fn health_check(&mut self, timeout: Duration) -> Result<(), KernelFailure>;

    /// Borrows the mutable control plane interface for active connection and node selection queries.
    fn control_mut(&mut self) -> &mut dyn KernelControl;
}
