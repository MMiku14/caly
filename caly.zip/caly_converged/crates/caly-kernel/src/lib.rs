//! caly-kernel
//!
//! Consolidated module containing coreconf, corectl.

#![forbid(unsafe_code)]
#![cfg_attr(test, allow(clippy::unwrap_used, clippy::expect_used, clippy::panic, clippy::todo, clippy::unimplemented, clippy::unreachable))]

pub mod coreconf;
pub mod corectl;

pub mod ir;
