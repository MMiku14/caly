//! Traffic flow analytics and gateway device monitoring.

use std::collections::BTreeMap;
use serde::{Deserialize, Serialize};

/// High-level traffic analytics computed from active connections.
#[derive(Clone, Debug, Default, Eq, PartialEq, Serialize, Deserialize)]
pub struct TrafficAnalyticsSnapshot {
    pub total_upload_bytes: u64,
    pub total_download_bytes: u64,
    pub active_connections: usize,
    /// Client IP -> (upload, download, connection_count)
    pub client_traffic: BTreeMap<String, ClientStats>,
    /// Protocol name -> total_bytes
    pub protocol_breakdown: BTreeMap<String, u64>,
    /// Target domain -> (hit_count, total_bytes)
    pub top_domains: Vec<DomainStats>,
}

#[derive(Clone, Debug, Default, Eq, PartialEq, Serialize, Deserialize)]
pub struct ClientStats {
    pub upload_bytes: u64,
    pub download_bytes: u64,
    pub active_connections: usize,
}

#[derive(Clone, Debug, Default, Eq, PartialEq, Serialize, Deserialize)]
pub struct DomainStats {
    pub domain: String,
    pub total_bytes: u64,
    pub connections: usize,
}

/// Computes analytics summary from a slice of connection items.
pub fn compute_traffic_analytics<T, F>(
    connections: &[T],
    mut extractor: F,
) -> TrafficAnalyticsSnapshot
where
    F: FnMut(&T) -> (String, String, String, u64, u64), // (client_ip, host, protocol, upload, download)
{
    let mut snap = TrafficAnalyticsSnapshot::default();
    snap.active_connections = connections.len();
    let mut domain_map: BTreeMap<String, (usize, u64)> = BTreeMap::new();

    for conn in connections {
        let (client_ip, host, proto, up, down) = extractor(conn);
        let total = up.saturating_add(down);
        snap.total_upload_bytes = snap.total_upload_bytes.saturating_add(up);
        snap.total_download_bytes = snap.total_download_bytes.saturating_add(down);

        // Per-client LAN IP tracking
        let ip_key = if client_ip.is_empty() { "127.0.0.1".to_owned() } else { client_ip };
        let client_stat = snap.client_traffic.entry(ip_key).or_default();
        client_stat.upload_bytes = client_stat.upload_bytes.saturating_add(up);
        client_stat.download_bytes = client_stat.download_bytes.saturating_add(down);
        client_stat.active_connections += 1;

        // Protocol breakdown
        let proto_key = if proto.is_empty() { "TCP".to_owned() } else { proto.to_uppercase() };
        let proto_total = snap.protocol_breakdown.entry(proto_key).or_insert(0);
        *proto_total = (*proto_total).saturating_add(total);

        // Domain tracking
        if !host.is_empty() && host != "-" {
            let entry = domain_map.entry(host).or_insert((0, 0));
            entry.0 += 1;
            entry.1 = entry.1.saturating_add(total);
        }
    }

    let mut domains: Vec<DomainStats> = domain_map
        .into_iter()
        .map(|(domain, (conns, total_bytes))| DomainStats {
            domain,
            total_bytes,
            connections: conns,
        })
        .collect();
    domains.sort_by(|a, b| b.total_bytes.cmp(&a.total_bytes));
    snap.top_domains = domains;

    snap
}
