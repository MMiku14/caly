//! Complete inbound listeners configuration model.

use serde::{Deserialize, Serialize};

/// Sniffing options for transparent and mixed inbounds.
#[derive(Clone, Copy, Debug, Default, Eq, PartialEq, Serialize, Deserialize)]
pub struct SniffOptions {
    pub enabled: bool,
    pub override_destination: bool,
}

/// Inbound listeners exposed by the core engine.
#[derive(Clone, Debug, Eq, PartialEq, Serialize, Deserialize)]
pub struct InboundConfig {
    pub mixed_port: u16,
    pub tproxy_port: u16,
    pub redir_port: u16,
    pub socks_port: u16,
    pub http_port: u16,
    pub allow_lan: bool,
    pub bind_address: String,
    pub sniff: SniffOptions,
}

impl Default for InboundConfig {
    fn default() -> Self {
        Self {
            mixed_port: 7890,
            tproxy_port: 0,
            redir_port: 0,
            socks_port: 0,
            http_port: 0,
            allow_lan: false,
            bind_address: "127.0.0.1".to_owned(),
            sniff: SniffOptions::default(),
        }
    }
}

impl InboundConfig {
    pub fn is_any_port_active(&self) -> bool {
        self.mixed_port != 0
            || self.tproxy_port != 0
            || self.redir_port != 0
            || self.socks_port != 0
            || self.http_port != 0
    }
}
