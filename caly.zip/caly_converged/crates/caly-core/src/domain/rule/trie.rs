//! Algorithmic routing lookup structures based on academic literature:
//!
//! 1. Reverse Domain Label Radix Tree (Suffix Trie):
//!    Fast O(L) domain suffix and exact matching, replacing O(N) linear rule scans.
//!    Labels are reversed ("com" -> "google" -> "mail") so suffix lookups follow
//!    a single downward trie path.
//!
//! 2. Bitwise Patricia Trie (Longest Prefix Match - LPM, RFC 1812):
//!    Fast O(32)/O(128) bitwise longest prefix matching for IPv4/IPv6 CIDR routing rules.

use std::{
    collections::HashMap,
    net::{IpAddr, Ipv4Addr, Ipv6Addr},
};

/// Error when parsing or inserting CIDR into the Patricia Trie.
#[derive(Clone, Debug, Eq, PartialEq)]
pub enum IpTrieError {
    InvalidFormat,
    InvalidMask,
}

impl core::fmt::Display for IpTrieError {
    fn fmt(&self, f: &mut core::fmt::Formatter<'_>) -> core::fmt::Result {
        match self {
            Self::InvalidFormat => f.write_str("invalid IP CIDR format"),
            Self::InvalidMask => f.write_str("prefix length exceeds address bit-width"),
        }
    }
}

impl std::error::Error for IpTrieError {}

// ============================================================================
// 1. Reverse Domain Label Radix Tree (Suffix Trie)
// ============================================================================

#[derive(Clone, Debug, Default)]
struct DomainTrieNode<T> {
    exact_value: Option<T>,
    suffix_value: Option<T>,
    children: HashMap<String, DomainTrieNode<T>>,
}

/// A reverse domain label radix tree for O(L) domain suffix and exact lookups.
#[derive(Clone, Debug, Default)]
pub struct DomainRadixTrie<T> {
    root: DomainTrieNode<T>,
    keywords: Vec<(String, T)>,
}

impl<T: Clone> DomainRadixTrie<T> {
    pub fn new() -> Self {
        Self {
            root: DomainTrieNode::default(),
            keywords: Vec::new(),
        }
    }

    pub fn insert_exact(&mut self, domain: &str, value: T) {
        let labels = Self::split_labels_rev(domain);
        if labels.is_empty() {
            return;
        }
        let mut curr = &mut self.root;
        for label in labels {
            curr = curr.children.entry(label).or_default();
        }
        curr.exact_value = Some(value);
    }

    pub fn insert_suffix(&mut self, suffix: &str, value: T) {
        let clean = suffix.trim().trim_start_matches('.');
        let labels = Self::split_labels_rev(clean);
        if labels.is_empty() {
            return;
        }
        let mut curr = &mut self.root;
        for label in labels {
            curr = curr.children.entry(label).or_default();
        }
        curr.suffix_value = Some(value);
    }

    pub fn insert_keyword(&mut self, keyword: &str, value: T) {
        let kw = keyword.trim().to_ascii_lowercase();
        if !kw.is_empty() {
            self.keywords.push((kw, value));
        }
    }

    pub fn match_host(&self, host: &str) -> Option<&T> {
        let clean = host.trim().trim_end_matches('.');
        if clean.is_empty() {
            return None;
        }
        let labels = Self::split_labels_rev(clean);

        let mut curr = &self.root;
        let mut deepest_suffix: Option<&T> = None;

        for (idx, label) in labels.iter().enumerate() {
            if let Some(next) = curr.children.get(label) {
                curr = next;
                if let Some(val) = &curr.suffix_value {
                    deepest_suffix = Some(val);
                }
                if idx + 1 == labels.len() {
                    if let Some(val) = &curr.exact_value {
                        return Some(val);
                    }
                }
            } else {
                break;
            }
        }

        if let Some(val) = deepest_suffix {
            return Some(val);
        }

        let lower = clean.to_ascii_lowercase();
        for (kw, val) in &self.keywords {
            if lower.contains(kw) {
                return Some(val);
            }
        }

        None
    }

    fn split_labels_rev(domain: &str) -> Vec<String> {
        domain
            .split('.')
            .filter(|s| !s.is_empty())
            .map(|s| s.to_ascii_lowercase())
            .rev()
            .collect()
    }
}

// ============================================================================
// 2. IPv4 / IPv6 Bitwise Patricia Trie (LPM, RFC 1812)
// ============================================================================

#[derive(Clone, Debug, Default)]
struct PatriciaNode<T> {
    value: Option<T>,
    prefix_len: u8,
    left: Option<Box<PatriciaNode<T>>>,
    right: Option<Box<PatriciaNode<T>>>,
}

/// A bitwise Patricia Trie implementing RFC 1812 Longest Prefix Match (LPM)
/// for IPv4 and IPv6 routing rules.
#[derive(Clone, Debug, Default)]
pub struct IpPatriciaTrie<T> {
    v4_root: PatriciaNode<T>,
    v6_root: PatriciaNode<T>,
}

impl<T: Clone> IpPatriciaTrie<T> {
    pub fn new() -> Self {
        Self {
            v4_root: PatriciaNode::default(),
            v6_root: PatriciaNode::default(),
        }
    }

    pub fn insert_cidr(&mut self, cidr: &str, value: T) -> Result<(), IpTrieError> {
        let (ip_str, mask_str) = cidr.split_once('/').ok_or(IpTrieError::InvalidFormat)?;
        let ip: IpAddr = ip_str.trim().parse().map_err(|_| IpTrieError::InvalidFormat)?;
        let mask: u8 = mask_str.trim().parse().map_err(|_| IpTrieError::InvalidFormat)?;

        match ip {
            IpAddr::V4(v4) => {
                if mask > 32 {
                    return Err(IpTrieError::InvalidMask);
                }
                let bits = u32::from_be_bytes(v4.octets());
                Self::insert_node(&mut self.v4_root, bits, mask, value, 32);
            }
            IpAddr::V6(v6) => {
                if mask > 128 {
                    return Err(IpTrieError::InvalidMask);
                }
                let bits = u128::from_be_bytes(v6.octets());
                Self::insert_node_v6(&mut self.v6_root, bits, mask, value);
            }
        }
        Ok(())
    }

    fn insert_node(root: &mut PatriciaNode<T>, bits: u32, mask: u8, value: T, total_bits: u8) {
        let mut curr = root;
        for i in 0..mask {
            let bit = (bits >> (total_bits - 1 - i)) & 1;
            if bit == 0 {
                curr = curr.left.get_or_insert_with(|| Box::new(PatriciaNode::default()));
            } else {
                curr = curr.right.get_or_insert_with(|| Box::new(PatriciaNode::default()));
            }
        }
        curr.value = Some(value);
        curr.prefix_len = mask;
    }

    fn insert_node_v6(root: &mut PatriciaNode<T>, bits: u128, mask: u8, value: T) {
        let mut curr = root;
        for i in 0..mask {
            let bit = (bits >> (128 - 1 - i)) & 1;
            if bit == 0 {
                curr = curr.left.get_or_insert_with(|| Box::new(PatriciaNode::default()));
            } else {
                curr = curr.right.get_or_insert_with(|| Box::new(PatriciaNode::default()));
            }
        }
        curr.value = Some(value);
        curr.prefix_len = mask;
    }

    pub fn match_ip(&self, ip: IpAddr) -> Option<&T> {
        match ip {
            IpAddr::V4(v4) => {
                let bits = u32::from_be_bytes(v4.octets());
                let mut curr = &self.v4_root;
                let mut longest: Option<&T> = curr.value.as_ref();

                for i in 0..32 {
                    let bit = (bits >> (31 - i)) & 1;
                    let next = if bit == 0 { &curr.left } else { &curr.right };
                    if let Some(n) = next {
                        curr = n;
                        if curr.value.is_some() {
                            longest = curr.value.as_ref();
                        }
                    } else {
                        break;
                    }
                }
                longest
            }
            IpAddr::V6(v6) => {
                let bits = u128::from_be_bytes(v6.octets());
                let mut curr = &self.v6_root;
                let mut longest: Option<&T> = curr.value.as_ref();

                for i in 0..128 {
                    let bit = (bits >> (127 - i)) & 1;
                    let next = if bit == 0 { &curr.left } else { &curr.right };
                    if let Some(n) = next {
                        curr = n;
                        if curr.value.is_some() {
                            longest = curr.value.as_ref();
                        }
                    } else {
                        break;
                    }
                }
                longest
            }
        }
    }
}

// ============================================================================
// 3. Fast Routing Lookup Table
// ============================================================================

#[derive(Clone, Debug, Default)]
pub struct FastRoutingTable<T> {
    pub domains: DomainRadixTrie<T>,
    pub ips: IpPatriciaTrie<T>,
    pub default_action: Option<T>,
}

impl<T: Clone> FastRoutingTable<T> {
    pub fn new() -> Self {
        Self {
            domains: DomainRadixTrie::new(),
            ips: IpPatriciaTrie::new(),
            default_action: None,
        }
    }

    pub fn lookup(&self, host: Option<&str>, ip: Option<IpAddr>) -> Option<&T> {
        if let Some(h) = host {
            if let Some(val) = self.domains.match_host(h) {
                return Some(val);
            }
        }
        if let Some(addr) = ip {
            if let Some(val) = self.ips.match_ip(addr) {
                return Some(val);
            }
        }
        self.default_action.as_ref()
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn domain_radix_trie_suffix_and_subdomain() {
        let mut trie = DomainRadixTrie::new();
        trie.insert_suffix("google.com", "GoogleProxy");
        trie.insert_exact("special.google.com", "SpecialDirect");
        trie.insert_keyword("adservice", "RejectAds");

        assert_eq!(trie.match_host("mail.google.com"), Some(&"GoogleProxy"));
        assert_eq!(trie.match_host("drive.google.com"), Some(&"GoogleProxy"));
        assert_eq!(trie.match_host("google.com"), Some(&"GoogleProxy"));

        assert_eq!(trie.match_host("special.google.com"), Some(&"SpecialDirect"));

        assert_eq!(trie.match_host("fakegoogle.com"), None);
        assert_eq!(trie.match_host("mygoogle.com.cn"), None);

        assert_eq!(trie.match_host("analytics.adservice.net"), Some(&"RejectAds"));
    }

    #[test]
    fn ip_patricia_trie_lpm_ipv4_and_ipv6() {
        let mut trie = IpPatriciaTrie::new();
        trie.insert_cidr("10.0.0.0/8", "ClassA").unwrap();
        trie.insert_cidr("10.1.0.0/16", "SubnetB").unwrap();
        trie.insert_cidr("10.1.2.3/32", "HostC").unwrap();
        trie.insert_cidr("192.168.0.0/16", "Lan").unwrap();

        assert_eq!(trie.match_ip("10.1.2.3".parse().unwrap()), Some(&"HostC"));
        assert_eq!(trie.match_ip("10.1.2.4".parse().unwrap()), Some(&"SubnetB"));
        assert_eq!(trie.match_ip("10.1.99.1".parse().unwrap()), Some(&"SubnetB"));
        assert_eq!(trie.match_ip("10.2.0.1".parse().unwrap()), Some(&"ClassA"));
        assert_eq!(trie.match_ip("172.16.0.1".parse().unwrap()), None);

        trie.insert_cidr("2001:db8::/32", "DocNet").unwrap();
        trie.insert_cidr("2001:db8:1::/48", "SpecificDocNet").unwrap();

        assert_eq!(trie.match_ip("2001:db8:1::cafe".parse().unwrap()), Some(&"SpecificDocNet"));
        assert_eq!(trie.match_ip("2001:db8:2::1".parse().unwrap()), Some(&"DocNet"));
        assert_eq!(trie.match_ip("2606:4700::".parse().unwrap()), None);
    }
}
