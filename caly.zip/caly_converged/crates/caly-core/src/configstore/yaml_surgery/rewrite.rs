//! The typed patch primitive: decode the located block, mutate, and
//! replace exactly its line span with the re-serialized list.

use std::fmt::Write as _;

use serde::Serialize;
use serde::de::DeserializeOwned;

use super::locate::{KeyBlock, SurgeryError, locate_key_block};

/// Outcome of a patch attempt: the document changed (new bytes) or the
/// mutation was an idempotent no-op (nothing written).
#[derive(Debug, Clone, PartialEq, Eq)]
pub enum EditOutcome {
    /// The block was replaced; carries the new document bytes.
    Changed(Vec<u8>),
    /// The typed before/after lists were identical; no edit happened.
    NoChange,
}

/// Decodes the `{key_path}` list from `text`, runs `mutate`, and — when
/// the result differs — replaces exactly the key block's lines with the
/// serialized list, preserving every other line byte-identically.
///
/// `parse_err` maps a YAML-shape failure onto the caller's error type
/// (the call sites wrap it as `ResourceError::Parse`).
pub fn edit_yaml_list<T, F, E>(
    text: &str,
    key_path: &[&str],
    parse_err: impl Fn(String) -> E,
    mutate: F,
) -> Result<EditOutcome, E>
where
    T: DeserializeOwned + Serialize + Clone + PartialEq,
    F: FnOnce(&[T]) -> Result<Vec<T>, E>,
    E: From<SurgeryError>,
{
    let lines: Vec<&str> = text.lines().collect();
    let current = decode_list::<T, E>(&lines, key_path, &parse_err)?;
    let next = mutate(&current)?;
    if next == current {
        return Ok(EditOutcome::NoChange);
    }
    let new_document = match locate_key_block(&lines, key_path) {
        Some(block) => replace_block(&lines, block, key_path, &next, &parse_err)?,
        // A missing key (first add on a fresh file): append a top-level
        // block at EOF so the document stays valid.
        None => append_block(&lines, key_path, &next, &parse_err)?,
    };
    // Typed self-check: the patched document must decode the same list
    // back (audit: a broken patch would otherwise surface at the next
    // load, far from the write).
    let patched_lines: Vec<&str> = std::str::from_utf8(&new_document)
        .map_err(|error| parse_err(error.to_string()))?
        .lines()
        .collect();
    let redecoded = decode_list::<T, E>(&patched_lines, key_path, &parse_err)?;
    if redecoded != next {
        return Err(parse_err(format!(
            "self-check mismatch after patching `{}`",
            key_path.join(".")
        )));
    }
    Ok(EditOutcome::Changed(new_document))
}

/// Decodes the list at `key_path`; a missing key decodes as an empty
/// list (the writers create the block on first add).
fn decode_list<'a, T, E>(
    lines: &'a [&'a str],
    key_path: &[&str],
    parse_err: &impl Fn(String) -> E,
) -> Result<Vec<T>, E>
where
    T: DeserializeOwned,
{
    let Some(block) = locate_key_block(lines, key_path) else {
        return Ok(Vec::new());
    };
    let mut span = String::new();
    for line in &lines[block.start..block.end] {
        let _ = writeln!(span, "{line}");
    }
    // Wrap the block in a mapping so `serde_norway` decodes it as
    // `{ key: [...] }`, then extract the list.
    let wrapped = format!("{}\n", span.trim_end());
    let value: serde_norway::Value =
        serde_norway::from_str(&wrapped).map_err(|error| parse_err(error.to_string()))?;
    let Some(key) = key_path.last() else {
        return Err(parse_err("empty key path".to_owned()));
    };
    let list = match value.get(key) {
        // An explicit `key:` with no body decodes as Null — treat it as
        // an empty list (the writers fill it on first add).
        Some(serde_norway::Value::Sequence(items)) => items.clone(),
        Some(serde_norway::Value::Null) | None => return Ok(Vec::new()),
        _ => return Err(parse_err("key block is not a YAML list".to_owned())),
    };
    serde_norway::from_value(serde_norway::Value::Sequence(list))
        .map_err(|error| parse_err(error.to_string()))
}

/// Appends a missing `{key}:` block at the end of the document (only
/// valid for a top-level key — nested keys cannot be created without a
/// parent block).
fn append_block<T, E>(
    lines: &[&str],
    key_path: &[&str],
    next: &[T],
    parse_err: &impl Fn(String) -> E,
) -> Result<Vec<u8>, E>
where
    T: Serialize,
{
    // Deepest existing parent block (e.g. `subscriptions: {}` exists but
    // `sources` does not): the new chain is inserted INSIDE that block so
    // the document never ends up with duplicate parent keys.
    let mut existing: Option<(usize, KeyBlock)> = None;
    for depth in (1..key_path.len()).rev() {
        if let Some(block) = locate_key_block(lines, &key_path[..depth]) {
            existing = Some((depth, block));
            break;
        }
    }
    let mut out = String::new();
    for line in lines {
        out.push_str(line);
        out.push('\n');
    }
    if !out.ends_with('\n') {
        out.push('\n');
    }
    let (first_missing, base_indent, insert_after) = match existing {
        Some((depth, block)) => (depth, block.indent + 2, block.end),
        None => (0, 0, lines.len()),
    };
    // Build the chain from the first missing key down to the list leaf.
    let mut chain = String::new();
    for (index, key) in key_path[first_missing..].iter().enumerate() {
        let _ = writeln!(chain, "{}{key}:", " ".repeat(base_indent + index * 2));
    }
    let leaf_indent = base_indent + (key_path.len() - first_missing - 1) * 2;
    if !next.is_empty() {
        let serialized =
            serde_norway::to_string(next).map_err(|error| parse_err(error.to_string()))?;
        for line in serialized.lines() {
            let _ = writeln!(chain, "{}  {line}", " ".repeat(leaf_indent));
        }
    }
    // Splice the chain after `insert_after` lines. When the deepest
    // existing parent is an INLINE block (`subscriptions: {}`), the key
    // line must be expanded to a bare `key:` first — a block body cannot
    // follow an inline value.
    let mut spliced = String::new();
    let mut emitted = 0usize;
    for (index, line) in out.lines().enumerate() {
        if index + 1 == insert_after && existing.is_some() {
            // `existing.is_some()` is checked above, so `None` here means
            // the anchor bookkeeping drifted — refuse the rewrite instead
            // of panicking mid-splice (L1 audit).
            let Some((_, block)) = existing else {
                return Err(parse_err(
                    "append anchor went missing; refusing to rewrite the document".to_owned(),
                ));
            };
            let key_idx = if key_path.is_empty() {
                0
            } else {
                (block.indent / 2).min(key_path.len() - 1)
            };
            let bare = format!(
                "{}{}:",
                " ".repeat(block.indent),
                key_path.get(key_idx).copied().unwrap_or("")
            );
            if line.trim_end() == bare {
                spliced.push_str(line);
                spliced.push('\n');
            } else {
                spliced.push_str(&bare);
                spliced.push('\n');
            }
            spliced.push_str(&chain);
            emitted = index + 1;
        } else {
            spliced.push_str(line);
            spliced.push('\n');
        }
    }
    if emitted < insert_after {
        // Chain belongs at EOF (no existing parent block).
        spliced.push_str(&chain);
    }
    Ok(spliced.into_bytes())
}

/// Replaces `block`'s line span with the serialized list under the same
/// key, indented to the block's nesting depth.
fn replace_block<T, E>(
    lines: &[&str],
    block: KeyBlock,
    key_path: &[&str],
    next: &[T],
    parse_err: &impl Fn(String) -> E,
) -> Result<Vec<u8>, E>
where
    T: Serialize,
{
    let Some(key) = key_path.last() else {
        return Err(parse_err("empty key path".to_owned()));
    };
    let key_line = lines[block.start];
    // The key line keeps its inline suffix (e.g. `: []` is replaced by
    // the block body; a trailing comment is dropped for the block form).
    let mut replacement = String::new();
    let _ = writeln!(replacement, "{}{}:", " ".repeat(block.indent), key);
    if !next.is_empty() {
        let mut serialized =
            serde_norway::to_string(next).map_err(|error| parse_err(error.to_string()))?;
        // serde_norway emits the sequence at indent 0; shift every line
        // right by (key indent + 2) so the entries nest under the key
        // (a top-level key's entries MUST be deeper than the key, or the
        // block scanner truncates at the first entry line).
        let entry_indent = block.indent + 2;
        let mut shifted = String::new();
        for line in serialized.lines() {
            let _ = writeln!(shifted, "{}{}", " ".repeat(entry_indent), line);
        }
        serialized = shifted;
        replacement.push_str(&serialized);
    }
    let _ = key_line; // key_line is preserved implicitly (we re-emit it)
    let mut out = String::new();
    for (index, line) in lines.iter().enumerate() {
        if index == block.start {
            out.push_str(replacement.trim_end());
            out.push('\n');
        } else if index < block.start || index >= block.end {
            out.push_str(line);
            out.push('\n');
        }
        // Lines inside [start+1, end) are dropped (replaced).
    }
    Ok(out.into_bytes())
}

#[cfg(test)]
mod tests {
    use super::*;

    #[derive(Debug, Clone, PartialEq, serde::Deserialize, serde::Serialize)]
    struct Group {
        name: String,
        #[serde(rename = "type")]
        kind: String,
    }

    fn mutate_append(list: &[Group]) -> Vec<Group> {
        let mut next = list.to_vec();
        next.push(Group {
            name: "Auto".to_owned(),
            kind: "select".to_owned(),
        });
        next
    }

    #[test]
    fn appends_to_existing_block_preserving_rest() {
        let doc =
            "# header\ncore: mihomo\nproxy_groups:\n  - name: A\n    type: url-test\nrules: []\n";
        let outcome = edit_yaml_list::<Group, _, _>(
            doc,
            &["proxy_groups"],
            SurgeryError::TypeMismatch,
            |list| Ok(mutate_append(list)),
        )
        .unwrap();
        let EditOutcome::Changed(bytes) = outcome else {
            panic!("expected a change");
        };
        let patched = String::from_utf8(bytes).unwrap();
        assert!(patched.starts_with("# header\ncore: mihomo\nproxy_groups:\n"));
        assert!(patched.contains("  - name: A\n    type: url-test\n"));
        assert!(patched.contains("  - name: Auto\n    type: select\n"));
        assert!(
            patched.ends_with("rules: []\n"),
            "tail must survive: {patched}"
        );
    }

    #[test]
    fn creates_missing_block() {
        let doc = "core: mihomo\n";
        let outcome = edit_yaml_list::<Group, _, _>(
            doc,
            &["proxy_groups"],
            SurgeryError::TypeMismatch,
            |list| Ok(mutate_append(list)),
        )
        .unwrap();
        let EditOutcome::Changed(bytes) = outcome else {
            panic!("expected a change");
        };
        let patched = String::from_utf8(bytes).unwrap();
        assert!(
            patched.contains("proxy_groups:\n  - name: Auto\n"),
            "{patched}"
        );
    }

    #[test]
    fn idempotent_mutation_is_no_change() {
        let doc = "proxy_groups:\n  - name: Auto\n    type: select\n";
        let outcome = edit_yaml_list::<Group, _, _>(
            doc,
            &["proxy_groups"],
            SurgeryError::TypeMismatch,
            |list| Ok(list.to_vec()),
        )
        .unwrap();
        assert_eq!(outcome, EditOutcome::NoChange);
    }
}
