//! Declared subscription-source listing (CLI sinking, 2026-08-14, read
//! path): computes the redacted `sub list` view from the layered config
//! plus the offline cache — ONE implementation used by the daemon
//! (published into the projection) and the CLI's `--offline` fallback.

use crate::domain::SourceView;
use crate::platform::paths::AppPaths;
use crate::profile::schema::SubscriptionConfig;

/// Computes the declared source listing from the process environment: loads
/// the layered config and enriches each source (tolerant of a fresh install —
/// a missing config yields an empty listing).
pub fn compute(paths: &AppPaths) -> Vec<SourceView> {
    let declared = crate::resource_writer::load_app_config(paths)
        .map(|config| config.subscriptions)
        .unwrap_or_default();
    compute_source_views(paths, &declared)
}

/// Computes the declared source listing: legacy scalar first (id 1 when
/// present), then `sources` in declaration order, each enriched with the
/// cache-derived node/group counts, last-refresh mtime and next-refresh
/// timestamp.
pub fn compute_source_views(paths: &AppPaths, declared: &SubscriptionConfig) -> Vec<SourceView> {
    let mut rows: Vec<SourceView> = Vec::new();
    let mut index = 1usize;
    if let Some(url) = &declared.url {
        rows.push(SourceView {
            index,
            name: "#1".to_owned(),
            kind: "subscription".to_owned(),
            url: url.clone(),
            enabled: true,
            nodes: 0,
            groups: Vec::new(),
            last_refresh_unix: None,
            next_refresh_unix: None,
            cached: false,
        });
        index += 1;
    }
    for source in &declared.sources {
        rows.push(SourceView {
            index,
            name: source.name.clone().unwrap_or_else(|| format!("#{index}")),
            kind: "subscription".to_owned(),
            url: source.url.clone(),
            enabled: source.enabled,
            nodes: 0,
            groups: Vec::new(),
            last_refresh_unix: None,
            next_refresh_unix: None,
            cached: false,
        });
        index += 1;
    }
    for row in &mut rows {
        let (nodes, groups, last_refresh, cached) = cache_stats(paths, &row.url);
        row.nodes = nodes;
        row.groups = groups;
        row.last_refresh_unix = last_refresh;
        row.cached = cached;
        row.next_refresh_unix = next_refresh_ts(last_refresh, source_cadence(declared, row.index));
    }
    rows
}

/// Reads the daemon's cached body for one source URL and derives the
/// node/group counts without any live parse trigger. The cache file is
/// `<state>/subscriptions/<hex(subscription_id_for_url(url))>`; its mtime
/// is the last successful refresh. `cached` = a body exists (an enabled
/// source without one has never refreshed — the stale badge).
fn cache_stats(paths: &AppPaths, url: &str) -> (usize, Vec<String>, Option<u64>, bool) {
    let root = paths.state.join("subscriptions");
    let id = crate::subscription::subscription_id_for_url(url);
    let path = root.join(crate::domain::to_hex(id.into_bytes()));
    let Ok(metadata) = std::fs::metadata(&path) else {
        tracing::debug!(?path, "cache_stats: no cache file");
        return (0, Vec::new(), None, false);
    };
    let mtime = metadata
        .modified()
        .ok()
        .and_then(|time| time.duration_since(std::time::UNIX_EPOCH).ok())
        .map(|duration| duration.as_secs());
    let Ok(body) = std::fs::read(&path) else {
        // A body that exists but cannot be read is NOT cached.
        return (0, Vec::new(), mtime, false);
    };
    let subscription = crate::domain::SubscriptionId::from_bytes([0; 16]);
    tracing::debug!(?path, bytes = body.len(), "cache_stats: reading cache body");
    let (nodes, groups) = match crate::subscription::decode_document(&body) {
        Ok(crate::subscription::SubscriptionDocument::ClashYaml(yaml)) => {
            std::str::from_utf8(yaml.as_slice()).map_or((0, Vec::new()), |source| {
                // Lenient counting: the strict import rejects real-world
                // configs whose groups re-list the whole tree (>256 members
                // per group), which would keep these columns at zero for
                // every airport-style source (audit).
                crate::subscription::count_clash_nodes_groups(source).unwrap_or((0, Vec::new()))
            })
        }
        Ok(crate::subscription::SubscriptionDocument::UriLines { .. }) => {
            crate::subscription::parse_uri_body_to_display_lossy(&body, subscription)
                .map_or((0, Vec::new()), |projection| {
                    (projection.nodes.len(), Vec::new())
                })
        }
        _ => (0, Vec::new()),
    };
    (nodes, groups, mtime, true)
}

/// The effective refresh cadence in minutes for one declared source:
/// per-source `refresh_every_minutes`, else the batch cadence.
fn source_cadence(declared: &SubscriptionConfig, index: usize) -> u64 {
    // `index` counts the legacy scalar `subscriptions.url` as 1, so the
    // `sources` list starts at 2 — with a legacy url present, row N maps
    // to source N-2.
    let source_index = if declared.url.is_some() {
        index.saturating_sub(2)
    } else {
        index.saturating_sub(1)
    };
    if let Some(source) = declared.sources.get(source_index)
        && let Some(every) = source.refresh_every_minutes
    {
        return every;
    }
    declared.refresh_interval_minutes
}

/// `last_refresh + cadence`; `None` when there is no cache or the
/// cadence is zero (static / timer disabled).
fn next_refresh_ts(last_refresh: Option<u64>, cadence_minutes: u64) -> Option<u64> {
    match (last_refresh, cadence_minutes) {
        (Some(last), minutes) if minutes > 0 => last.checked_add(minutes.saturating_mul(60)),
        _ => None,
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::test_helpers::{hermetic_paths, temp_root};
    use std::fs;

    fn seed(paths: &crate::platform::paths::AppPaths, url: &str, body: &[u8]) {
        fs::create_dir_all(paths.state.join("subscriptions")).unwrap();
        let id = crate::subscription::subscription_id_for_url(url);
        fs::write(
            paths
                .state
                .join("subscriptions")
                .join(crate::domain::to_hex(id.into_bytes())),
            body,
        )
        .unwrap();
    }

    #[test]
    fn cache_stats_counts_a_real_clash_body() {
        let dir = temp_root("sl-real");
        let paths = hermetic_paths(dir.as_path());
        let body = fs::read("/tmp/cray-test.yaml").unwrap_or_else(|_| {
            // 内联小样本:两个节点一个组
            "proxies:\n  - name: a\n    type: ss\n    server: 1.2.3.4\n    port: 8388\n    cipher: aes-256-gcm\n    password: x\n  - name: b\n    type: ss\n    server: 5.6.7.8\n    port: 8388\n    cipher: aes-256-gcm\n    password: y\nproxy-groups:\n  - name: AUTO\n    type: select\n    proxies:\n      - a\n      - b\n".as_bytes().to_vec()
        });
        seed(
            &paths,
            "https://ghproxy.net/https://raw.githubusercontent.com/free18/v2ray/refs/heads/main/c.yaml",
            &body,
        );
        let (nodes, groups, last, cached) = cache_stats(
            &paths,
            "https://ghproxy.net/https://raw.githubusercontent.com/free18/v2ray/refs/heads/main/c.yaml",
        );
        assert!(cached, "body must be found");
        assert!(last.is_some(), "mtime must be read");
        if body.len() > 2000 {
            assert!(nodes >= 300, "real cray body must count nodes, got {nodes}");
        } else {
            assert_eq!(nodes, 2, "inline sample must count nodes");
        }
        assert!(!groups.is_empty(), "groups must be listed");
    }

    #[test]
    fn compute_full_path_counts_real_cached_body() {
        let dir = temp_root("sl-compute");
        let paths = hermetic_paths(dir.as_path());
        // 配置 + 缓存
        fs::create_dir_all(&paths.config).unwrap();
        fs::write(
            paths.config.join("config.yaml"),
            "schema_version: 1\ncore: mihomo\nsubscriptions:\n  sources:\n    - url: https://ghproxy.net/https://raw.githubusercontent.com/free18/v2ray/refs/heads/main/c.yaml\n      enabled: true\n      name: cray\n",
        )
        .unwrap();
        let body = fs::read("/tmp/cray-test.yaml").unwrap_or_else(|_| vec![b'x']);
        seed(
            &paths,
            "https://ghproxy.net/https://raw.githubusercontent.com/free18/v2ray/refs/heads/main/c.yaml",
            &body,
        );
        let rows = compute(&paths);
        assert_eq!(rows.len(), 1);
        if body.len() > 2000 {
            assert!(
                rows[0].nodes >= 300,
                "compute must count real nodes, got {}",
                rows[0].nodes
            );
        }
    }
}
