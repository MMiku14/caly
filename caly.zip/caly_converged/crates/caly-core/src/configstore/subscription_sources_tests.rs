//! Tests for [`super::subscription_sources`]: token normalization plus
//! the add/resolve/enable/remove write pipeline (extracted sibling: the
//! module plus its locks exceed the file-length budget).

use super::subscription_sources::*;
use crate::test_helpers::{hermetic_paths, temp_root};

#[test]
fn http_urls_pass_through_trimmed() {
    let http = normalize_source_token("  https://example.com/sub  ").unwrap();
    assert_eq!(http.url, "https://example.com/sub");
    assert_eq!(http.kind, SourceKind::Http);
    let plain = normalize_source_token("http://example.com/sub").unwrap();
    assert_eq!(plain.kind, SourceKind::Http);
}

#[test]
fn empty_and_wrong_scheme_rejected() {
    assert!(matches!(
        normalize_source_token("   "),
        Err(SubSourceError::InvalidUrl(_))
    ));
    assert!(matches!(
        normalize_source_token("ftp://example.com/sub"),
        Err(SubSourceError::InvalidUrl(message)) if message.contains("unsupported scheme")
    ));
}

#[test]
fn missing_file_reports_given_and_resolved() {
    let given = "/nonexistent-caly-test-dir/sub.yaml";
    assert!(matches!(
        normalize_source_token(given),
        Err(SubSourceError::SourceFileNotFound { given: g, resolved: r })
            if g == given && r == given
    ));
}

#[test]
fn existing_file_becomes_canonical_file_url() {
    let path =
        std::env::temp_dir().join(format!("caly-normalize-test-{}.yaml", std::process::id()));
    std::fs::write(&path, "proxies: []\n").unwrap();
    let result = normalize_source_token(&path.display().to_string());
    let _ = std::fs::remove_file(&path);
    let file = result.unwrap();
    assert_eq!(file.kind, SourceKind::File);
    assert!(file.url.starts_with("file://"), "url: {}", file.url);
    assert_eq!(
        std::path::Path::new(&file.url)
            .extension()
            .and_then(|e| e.to_str()),
        Some("yaml"),
        "url: {}",
        file.url
    );
}

#[test]
fn file_url_of_missing_file_rejected() {
    assert!(matches!(
        normalize_source_token("file:///nonexistent-caly-test-dir/sub.yaml"),
        Err(SubSourceError::SourceFileNotFound { .. })
    ));
}

fn seed_config(dir: &std::path::Path) -> crate::platform::paths::AppPaths {
    let paths = hermetic_paths(dir);
    std::fs::create_dir_all(&paths.config).unwrap();
    std::fs::write(
        paths.config.join("config.yaml"),
        "schema_version: 1\ncore: mihomo\n",
    )
    .unwrap();
    paths
}

const URL_A: &str = "https://example.com/a.yaml";
const URL_B: &str = "https://example.com/b.yaml";

#[test]
fn add_dry_run_counts_without_touching_disk() {
    let dir = temp_root("ss-dry");
    let paths = seed_config(dir.as_path());
    let before = std::fs::read_to_string(paths.config.join("config.yaml")).unwrap();
    let preview = add_source(&paths, URL_A, Some("a"), None, false).unwrap();
    assert_eq!(preview.source_count, 1);
    assert!(!preview.applied);
    let after = std::fs::read_to_string(paths.config.join("config.yaml")).unwrap();
    assert_eq!(before, after);
}

#[test]
fn add_apply_persists_and_rejects_duplicates() {
    let dir = temp_root("ss-add");
    let paths = seed_config(dir.as_path());
    let preview = add_source(&paths, URL_A, Some("a"), None, true).unwrap();
    assert_eq!(preview.source_count, 1);
    assert!(preview.applied);
    let body = std::fs::read_to_string(paths.config.join("config.yaml")).unwrap();
    assert!(body.contains(URL_A), "config: {body}");
    assert!(matches!(
        add_source(&paths, URL_A, None, None, true),
        Err(SubSourceError::AlreadyDeclared(_))
    ));
    assert!(matches!(
        add_source(&paths, URL_B, Some("a"), None, true),
        Err(SubSourceError::NameTaken(_))
    ));
}

#[test]
fn resolve_addresses_by_id_name_and_url() {
    let dir = temp_root("ss-ref");
    let paths = seed_config(dir.as_path());
    add_source(&paths, URL_A, Some("a"), None, true).unwrap();
    add_source(&paths, URL_B, None, None, true).unwrap();
    assert_eq!(resolve_source_ref(&paths, "1").unwrap(), URL_A);
    assert_eq!(resolve_source_ref(&paths, "a").unwrap(), URL_A);
    assert_eq!(resolve_source_ref(&paths, URL_B).unwrap(), URL_B);
    assert!(matches!(
        resolve_source_ref(&paths, "nope"),
        Err(SubSourceError::NotDeclared(_))
    ));
}

#[test]
fn set_enabled_toggles_and_reports_no_change() {
    let dir = temp_root("ss-en");
    let paths = seed_config(dir.as_path());
    add_source(&paths, URL_A, Some("a"), None, true).unwrap();
    let off = set_enabled(&paths, "a", false, true).unwrap();
    assert!(off.applied);
    let body = std::fs::read_to_string(paths.config.join("config.yaml")).unwrap();
    assert!(body.contains("enabled: false"), "config: {body}");
    let again = set_enabled(&paths, "a", false, true).unwrap();
    assert!(again.unchanged);
}

#[test]
fn remove_by_name_purges_cache_body() {
    let dir = temp_root("ss-rm");
    let paths = seed_config(dir.as_path());
    add_source(&paths, URL_A, Some("a"), None, true).unwrap();
    let cache = paths.state.join("subscriptions");
    std::fs::create_dir_all(&cache).unwrap();
    let id = crate::subscription::subscription_id_for_url(URL_A);
    let cached = cache.join(crate::domain::to_hex(id.into_bytes()));
    std::fs::write(&cached, b"proxies: []").unwrap();
    let preview = remove_source(&paths, "a", true, true).unwrap();
    assert!(preview.applied);
    assert_eq!(preview.source_count, 0);
    assert!(!cached.exists());
    let body = std::fs::read_to_string(paths.config.join("config.yaml")).unwrap();
    assert!(!body.contains(URL_A), "config: {body}");
}
