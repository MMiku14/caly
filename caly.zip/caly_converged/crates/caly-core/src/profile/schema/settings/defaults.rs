//! Generated default-config rendering (`config generate` content).
//!
//! Provides a unified, single-file documented configuration layout mapping all
//! kernel, TUN, DNS, sniffer, profile, and routing features into `config.yaml`.

use std::path::PathBuf;

/// Renders the complete, unified, fully documented `config.yaml`.
///
/// Maps all configurable features:
/// - Core runtime selection (mihomo | sing-box)
/// - Rule and DNS conflict preference policies (hybrid | local_only | profile_only)
/// - Inbound ports, LAN binding, log levels, and transparent ports
/// - Traffic sniffing & domain recovery
/// - Virtual TUN interface (stack, MTU, GSO, routing lists, UID isolation)
/// - High-performance DNS engine (Fake-IP, smart cache, static hosts, policy routing)
/// - Desktop system proxy integration
/// - Unified profiles & subscriptions
/// - Proxy groups (select, url-test, load-balance, fallback)
/// - Ordered routing rules
pub fn render_unified_config() -> String {
    r#"# ==============================================================================
# Caly Unified Configuration (config.yaml)
# Single-file layout with all core, TUN, DNS, and routing capabilities mapped
# ==============================================================================
schema_version: 1

# Managed proxy core runtime: mihomo | sing-box
core: mihomo

# Rule selection strategy when profile rules collide with local rules:
#   hybrid       - Prepend local rules before profile rules (recommended)
#   local_only   - Strictly use local rules, ignore profile rules
#   profile_only - Strictly use profile rules
rule_preference: hybrid

# DNS selection strategy:
#   local   - Retain local anti-poisoning DNS engine, Fake-IP & DoH (recommended)
#   merge   - Merge profile upstream resolvers into local fallback
#   profile - Use profile DNS directly
dns_preference: local

# Kernel listening ports and inbound adapters
kernel:
  mixed_port: 7890
  tproxy_port: 0
  redir_port: 0
  socks_port: 0
  http_port: 0
  allow_lan: false
  bind_address: "127.0.0.1"
  log_level: info

# Traffic sniffing (domain recovery) for bare IP connections
sniffer:
  enabled: true
  override_destination: true
  parse_pure_ip: true
  force_dns_mapping: true
  http_ports:
    - "80"
    - "8080-8880"
  tls_ports:
    - "443"
    - "8443"
  quic_ports:
    - "443"

# Virtual TUN Network Interface (Transparent Gateway Mode)
tun:
  enabled: false
  stack: gvisor # gvisor | mixed | system
  device: caly0
  auto_route: true
  auto_redirect: false
  strict_route: true
  endpoint_independent_mapping: true # Full-Cone NAT for gaming / STUN
  mtu: 9000
  gso: true
  udp_timeout: 300
  route_address: []
  route_exclude_address: []
  include_uid: []
  exclude_uid: []

# High-Performance DNS Engine
dns:
  enabled: true
  mode: fake-ip # fake-ip | redir-host | standard
  listen: "127.0.0.1:53"
  ipv6: false
  prefer_h3: true
  strategy: prefer_ipv4 # prefer_ipv4 | prefer_ipv6 | ipv4_only | ipv6_only
  client_subnet: "114.114.114.0/24"
  fake_ip_range: "198.18.0.1/16"
  cache:
    algorithm: lru # lru | lfu | arc | fifo
    size: 4096
    min_ttl: 60
    max_ttl: 86400
    negative_ttl: 10
    stale_cache: true
    respect_rules: true
  hosts:
    "router.local": "192.168.1.1"
    "*.lan": "127.0.0.1"
  use_hosts: true
  use_system_hosts: true
  nameservers:
    - https://dns.alidns.com/dns-query
    - https://doh.pub/dns-query
  fallback:
    - https://cloudflare-dns.com/dns-query
    - https://dns.google/dns-query
  nameserver_policy:
    "geosite:cn":
      - 223.5.5.5
      - 119.29.29.29
    "geosite:geolocation-!cn":
      - 8.8.8.8
      - 1.1.1.1


# ------------------------------------------------------------------------------
# Transparent Gateway & LAN Router (旁路由 / 网关代理模式)
# ------------------------------------------------------------------------------
gateway:
  enabled: false          # Set to true to activate transparent gateway mode
  lan_interface: "eth0"   # LAN physical adapter to intercept (e.g. eth0, wlan0)
  ip_forwarding: true     # Enable Linux kernel packet forwarding (sysctl)
  disable_icmp_redirects: true # Block ICMP redirect leaks (prevents proxy bypass)
  proxy_arp: false        # Enable proxy-ARP for single-subnet proxy gateway
  dns_hijack: true        # Redirect port 53 UDP/TCP queries to local DNS resolver
  tproxy_port: 7893       # TProxy transparent listening port (Linux IP_TRANSPARENT)
  masquerade: true        # NAT masquerading on outbound WAN interfaces
  bypass_ips: []          # Local device IPs to bypass completely (direct)
  proxied_ips: []         # Local device IPs to force through proxy
  client_policies:        # Per-device access control & policy routing
    - target: "192.168.1.50"
      policy: "direct"
      description: "Smart TV direct streaming"
    - target: "192.168.1.100"
      policy: "rule"
      description: "Development workstation"

# Desktop System Proxy (GNOME / KDE / SessionEnv integration)
system_proxy:
  enabled: false
  host: "127.0.0.1"

# Unified Profiles & Subscriptions
# Supports remote airport subscription links, local YAML files, and composite merges
profiles: []

# Custom Proxy Groups
# Supports: select | url-test | fallback | load-balance | relay
#
# Example:
# proxy_groups:
#   - name: PROXY
#     type: select
#     members:
#       - kind: direct
#   - name: AUTO
#     type: url-test
#     url_test:
#       url: https://www.gstatic.com/generate_204
#       interval_seconds: 300
#       tolerance_ms: 50
#     members:
#       - kind: group
#         name: PROXY
proxy_groups: []

# Custom Routing Rules (processed in top-to-bottom order)
rules:
  - GEOIP,private,DIRECT
  - GEOSITE,cn,DIRECT
  - GEOIP,CN,DIRECT
  - MATCH,DIRECT
"#.to_owned()
}

/// Base `config.yaml` content. Points to [`render_unified_config`].
pub fn render_default_base() -> String {
    r#"# ==============================================================================
# Caly Unified Configuration (Production Specification)
# ==============================================================================
schema_version: 1

# Core Engine: mihomo | sing-box
core: mihomo

# Subsystem Conflict Strategies
rule_preference: hybrid   # hybrid (local prepended) | local_only | profile_only
dns_preference: local     # local (anti-poisoning Fake-IP) | merge | profile

# ------------------------------------------------------------------------------
# Kernel & Inbound Listeners
# ------------------------------------------------------------------------------
kernel:
  mixed_port: 7890        # HTTP + SOCKS5 dual mixed proxy port
  tproxy_port: 0          # Transparent proxy port (Linux IP_TRANSPARENT gateway)
  redir_port: 0           # TCP redirect port (Linux iptables REDIRECT)
  socks_port: 0           # Dedicated SOCKS5 port (0 to disable)
  http_port: 0            # Dedicated HTTP port (0 to disable)
  allow_lan: false        # Share proxy with local area network devices
  bind_address: "127.0.0.1" # "0.0.0.0" when allow_lan is true
  log_level: info         # error | warn | info | debug | silent
  sniffer:
    enable: true
    override_destination: true
    parse_pure_ip: true

# ------------------------------------------------------------------------------
# TUN Virtual Network Adapter (Kernel Gateway Driver)
# ------------------------------------------------------------------------------
tun:
  enabled: true
  stack: gvisor           # gvisor (safe user-space) | system | mixed
  device: caly0           # Virtual TUN interface name
  auto_route: true        # Automatically install default gateway routes
  auto_redirect: false    # Linux nftables/iptables redirect acceleration
  strict_route: true      # Strict routing to prevent direct non-TUN leaks
  endpoint_independent_mapping: true # Full-Cone NAT (NAT1) for gaming/WebRTC
  mtu: 9000               # Jumbo frames supported in gVisor stack
  gso: true               # Generic Segmentation Offload for high throughput
  udp_timeout: 300        # UDP session state tracking timeout in seconds
  route_address: []       # Subnets routed through TUN (empty = all)
  route_exclude_address: [] # Subnets bypassed from TUN
  include_uid: []         # Process socket UIDs to proxy
  exclude_uid: []         # Process socket UIDs to bypass (prevents routing loops)

# ------------------------------------------------------------------------------
# Local DNS Engine & Anti-Poisoning Architecture
# ------------------------------------------------------------------------------
dns:
  enabled: true
  mode: fake-ip           # fake-ip | redir-host | standard
  listen: "127.0.0.1:53"  # Local DNS listener socket
  ipv6: false             # Resolve IPv6 AAAA records
  prefer_h3: true         # Enable HTTP/3 QUIC for DoH upstreams
  strategy: prefer_ipv4   # prefer_ipv4 | prefer_ipv6 | ipv4_only | ipv6_only
  client_subnet: "114.114.114.0/24" # EDNS Client Subnet (ECS) for nearest CDN
  fake_ip_range: "198.18.0.1/16"
  cache:
    algorithm: lru        # lru | lfu | arc | fifo (with TinyLFU admission filter)
    size: 4096            # Maximum cached DNS record entries
    min_ttl: 60           # Minimum TTL clamp in seconds
    max_ttl: 86400        # Maximum TTL clamp (1 day)
    negative_ttl: 10      # NXDOMAIN negative cache TTL
    stale_cache: true     # RFC 8767 Stale-While-Revalidate optimistic caching
    respect_rules: true   # Whether cache lookups respect routing rules
  hosts:
    "router.local": "192.168.1.1"
    "*.internal": "10.0.0.1"
  use_hosts: true
  use_system_hosts: true  # Read local /etc/hosts file

  # Upstream Resolvers (Trusted DoH / DoT endpoints)
  nameservers:
    - "https://dns.alidns.com/dns-query"
    - "https://doh.pub/dns-query"
  fallback:
    - "https://cloudflare-dns.com/dns-query"
    - "https://dns.google/dns-query"

  # Domain-specific DNS Policy Routing
  nameserver_policy:
    "geosite:cn":
      - "223.5.5.5"
      - "119.29.29.29"
    "geosite:geolocation-!cn":
      - "8.8.8.8"
      - "1.1.1.1"


# ------------------------------------------------------------------------------
# Transparent Gateway & LAN Router (旁路由 / 网关代理模式)
# ------------------------------------------------------------------------------
gateway:
  enabled: false          # Set to true to activate transparent gateway mode
  lan_interface: "eth0"   # LAN physical adapter to intercept (e.g. eth0, wlan0)
  ip_forwarding: true     # Enable Linux kernel packet forwarding (sysctl)
  disable_icmp_redirects: true # Block ICMP redirect leaks (prevents proxy bypass)
  proxy_arp: false        # Enable proxy-ARP for single-subnet proxy gateway
  dns_hijack: true        # Redirect port 53 UDP/TCP queries to local DNS resolver
  tproxy_port: 7893       # TProxy transparent listening port (Linux IP_TRANSPARENT)
  masquerade: true        # NAT masquerading on outbound WAN interfaces
  bypass_ips: []          # Local device IPs to bypass completely (direct)
  proxied_ips: []         # Local device IPs to force through proxy
  client_policies:        # Per-device access control & policy routing
    - target: "192.168.1.50"
      policy: "direct"
      description: "Smart TV direct streaming"
    - target: "192.168.1.100"
      policy: "rule"
      description: "Development workstation"

# ------------------------------------------------------------------------------
# System Proxy (Desktop GNOME / KDE / Wayland Integration)
# ------------------------------------------------------------------------------
system_proxy:
  enabled: false

# ------------------------------------------------------------------------------
# Profiles & Remote Subscriptions
# ------------------------------------------------------------------------------
profiles: []

# ------------------------------------------------------------------------------
# Proxy Groups (Traffic Balancing & Health Failover)
# ------------------------------------------------------------------------------
proxy_groups: []

# ------------------------------------------------------------------------------
# Routing Rules (Top to bottom; first match wins)
# ------------------------------------------------------------------------------
rules:
  - "DOMAIN-SUFFIX,local,DIRECT"
  - "IP-CIDR,127.0.0.0/8,DIRECT"
  - "IP-CIDR,192.168.0.0/16,DIRECT"
  - "GEOIP,private,DIRECT"
  - "GEOSITE,category-ads-all,REJECT"
  - "GEOIP,CN,DIRECT"
  - "MATCH,PROXY"
"#.to_owned()
}


