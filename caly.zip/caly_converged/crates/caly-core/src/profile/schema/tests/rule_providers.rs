use super::*;

#[test]
fn rule_providers_http_parses_and_validates() -> Result<(), ConfigError> {
    let parsed = parse_and_validate_json(
        br#"{
            "schema_version": 1,
            "core": "mihomo",
            "rule_providers": [
                {
                    "name": "my-google",
                    "type": "http",
                    "behavior": "domain",
                    "format": "source",
                    "url": "https://example.com/google.yaml",
                    "interval_ms": 86400000
                }
            ]
        }"#,
    )?;
    assert_eq!(parsed.rule_providers.len(), 1);
    let provider = &parsed.rule_providers[0];
    assert_eq!(provider.name, "my-google");
    let domain = provider
        .to_rule_provider()
        .map_err(|error| ConfigError::InvalidRule {
            index: 0,
            reason: error,
        })?;
    assert_eq!(domain.name.as_str(), "my-google");
    assert!(matches!(
        domain.behavior,
        crate::domain::RuleProviderBehavior::Domain
    ));
    Ok(())
}

#[test]
fn rule_providers_file_and_inline_round_trip() -> Result<(), ConfigError> {
    let parsed = parse_and_validate_json(
        br#"{
            "schema_version": 1,
            "core": "mihomo",
            "rule_providers": [
                {
                    "name": "local-rules",
                    "type": "file",
                    "behavior": "classical",
                    "format": "source",
                    "path": "/etc/caly/rules.yaml"
                },
                {
                    "name": "inline-ads",
                    "type": "inline",
                    "behavior": "domain_suffix",
                    "format": "source",
                    "payload": "- example.com\n- ads.example.org\n"
                }
            ]
        }"#,
    )?;
    assert_eq!(parsed.rule_providers.len(), 2);
    let local = &parsed.rule_providers[0];
    let inline = &parsed.rule_providers[1];
    let local_provider = local
        .to_rule_provider()
        .map_err(|error| ConfigError::InvalidRule {
            index: 0,
            reason: error,
        })?;
    let inline_provider = inline
        .to_rule_provider()
        .map_err(|error| ConfigError::InvalidRule {
            index: 1,
            reason: error,
        })?;
    assert!(matches!(
        local_provider.source,
        crate::domain::RuleProviderSource::File { .. }
    ));
    assert!(matches!(
        local_provider.behavior,
        crate::domain::RuleProviderBehavior::Classical
    ));
    assert!(matches!(
        inline_provider.source,
        crate::domain::RuleProviderSource::Inline { .. }
    ));
    assert!(matches!(
        inline_provider.behavior,
        crate::domain::RuleProviderBehavior::DomainSuffix
    ));
    Ok(())
}

#[test]
fn rule_providers_reject_duplicate_names() {
    let bad = br#"{
        "schema_version": 1,
        "core": "mihomo",
        "rule_providers": [
            {
                "name": "shared",
                "type": "inline",
                "behavior": "domain",
                "format": "source",
                "payload": "a.com\n"
            },
            {
                "name": "shared",
                "type": "inline",
                "behavior": "domain_suffix",
                "format": "source",
                "payload": "b.com\n"
            }
        ]
    }"#;
    assert!(matches!(
        parse_and_validate_json(bad),
        Err(ConfigError::DuplicateRuleProvider { .. })
    ));
}

#[test]
fn rule_providers_reject_short_polling_interval() {
    let bad = br#"{
        "schema_version": 1,
        "core": "mihomo",
        "rule_providers": [
            {
                "name": "noisy",
                "type": "http",
                "behavior": "domain",
                "format": "source",
                "url": "https://example.com/r.yaml",
                "interval_ms": 1000
            }
        ]
    }"#;
    assert!(matches!(
        parse_and_validate_json(bad),
        Err(ConfigError::InvalidRuleProviderInterval { .. })
    ));
}

#[test]
fn rule_providers_reject_invalid_http_url() {
    let bad = br#"{
        "schema_version": 1,
        "core": "mihomo",
        "rule_providers": [
            {
                "name": "bad",
                "type": "http",
                "behavior": "domain",
                "format": "source",
                "url": "ftp://example.com/r.yaml"
            }
        ]
    }"#;
    assert!(matches!(
        parse_and_validate_json(bad),
        Err(ConfigError::InvalidRuleProviderUrl { .. })
    ));
}

#[test]
fn rule_providers_reject_empty_inline_payload() {
    let bad = br#"{
        "schema_version": 1,
        "core": "mihomo",
        "rule_providers": [
            {
                "name": "empty",
                "type": "inline",
                "behavior": "domain",
                "format": "source",
                "payload": "   \n"
            }
        ]
    }"#;
    assert!(matches!(
        parse_and_validate_json(bad),
        Err(ConfigError::EmptyRuleProviderPayload { .. })
    ));
}

#[test]
fn rule_set_rule_must_reference_a_known_provider() {
    let unknown = br#"{
        "schema_version": 1,
        "core": "mihomo",
        "rule_providers": [
            {
                "name": "declared",
                "type": "inline",
                "behavior": "domain",
                "format": "source",
                "payload": "a.com\n"
            }
        ],
        "rules": [
            "RULE-SET,declared,DIRECT",
            "RULE-SET,undeclared,DIRECT"
        ]
    }"#;
    assert!(matches!(
        parse_and_validate_json(unknown),
        Err(ConfigError::UnknownRuleProvider { .. })
    ));
}

#[test]
fn rule_set_rule_passes_when_provider_is_declared() {
    let ok = br#"{
        "schema_version": 1,
        "core": "mihomo",
        "rule_providers": [
            {
                "name": "my-prov",
                "type": "inline",
                "behavior": "domain",
                "format": "source",
                "payload": "a.com\n"
            }
        ],
        "rules": [
            "RULE-SET,my-prov,DIRECT",
            "MATCH,PROXY"
        ]
    }"#;
    assert!(parse_and_validate_json(ok).is_ok());
}

#[test]
fn geoip_rule_does_not_require_a_declared_rule_provider() {
    // `geoip-cn` is auto-emitted by the rule renderer (SagerNet's
    // sing-geoip rule-set), so a `GEOIP,CN,…` rule must validate even
    // when the user has not declared it.
    let ok = br#"{
        "schema_version": 1,
        "core": "mihomo",
        "rules": ["GEOIP,CN,DIRECT", "MATCH,PROXY"]
    }"#;
    assert!(parse_and_validate_json(ok).is_ok());
}
