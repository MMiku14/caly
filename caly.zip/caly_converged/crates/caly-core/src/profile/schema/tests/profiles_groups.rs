use super::*;

#[test]
fn profiles_local_and_remote_parse() -> Result<(), ConfigError> {
    let parsed = parse_and_validate_json(
        br#"{
            "schema_version": 1,
            "core": "mihomo",
            "profiles": [
                {
                    "id": "team-shared",
                    "name": "Team shared",
                    "kind": "remote",
                    "url": "https://example.com/team.yaml",
                    "interval_minutes": 60
                },
                {
                    "id": "local-extra",
                    "kind": "local",
                    "path": "extra.yaml"
                }
            ]
        }"#,
    )?;
    assert_eq!(parsed.profiles.len(), 2);
    let team = &parsed.profiles[0];
    let local = &parsed.profiles[1];
    let team_domain = team.to_domain().map_err(|error| ConfigError::InvalidRule {
        index: 0,
        reason: error,
    })?;
    let local_domain = local
        .to_domain()
        .map_err(|error| ConfigError::InvalidRule {
            index: 1,
            reason: error,
        })?;
    assert_eq!(team_domain.id.as_str(), "team-shared");
    assert!(matches!(
        team_domain.source,
        crate::domain::ProfileSource::Remote { .. }
    ));
    assert!(matches!(
        local_domain.source,
        crate::domain::ProfileSource::Local { .. }
    ));
    Ok(())
}

#[test]
fn profiles_merge_parses_and_validates_declaration() -> Result<(), ConfigError> {
    let parsed = parse_and_validate_json(
        br#"{
            "schema_version": 1,
            "core": "mihomo",
            "profiles": [
                {"id": "team", "kind": "remote", "url": "https://example.com/team.yaml", "interval_minutes": 60},
                {"id": "local", "kind": "local", "path": "local.yaml"},
                {"id": "combined", "kind": "merge", "parts": ["team", "local"]}
            ]
        }"#,
    )?;
    assert_eq!(parsed.profiles.len(), 3);
    Ok(())
}

#[test]
fn profiles_reject_duplicate_ids() {
    let bad = br#"{
        "schema_version": 1,
        "core": "mihomo",
        "profiles": [
            {"id": "shared", "kind": "local", "path": "a.yaml"},
            {"id": "shared", "kind": "local", "path": "b.yaml"}
        ]
    }"#;
    assert!(matches!(
        parse_and_validate_json(bad),
        Err(ConfigError::Profile(
            crate::domain::ProfileError::DuplicateId { .. }
        ))
    ));
}

#[test]
fn profiles_reject_non_path_safe_id() {
    let bad = br#"{
        "schema_version": 1,
        "core": "mihomo",
        "profiles": [
            {"id": "with/slash", "kind": "local", "path": "a.yaml"}
        ]
    }"#;
    assert!(matches!(
        parse_and_validate_json(bad),
        Err(ConfigError::Profile(_))
    ));
}

#[test]
fn profiles_reject_empty_local_path() {
    let bad = br#"{
        "schema_version": 1,
        "core": "mihomo",
        "profiles": [
            {"id": "x", "kind": "local", "path": "   "}
        ]
    }"#;
    assert!(matches!(
        parse_and_validate_json(bad),
        Err(ConfigError::InvalidRule { .. })
    ));
}

#[test]
fn profiles_reject_local_path_escape() {
    let bad = br#"{
        "schema_version": 1,
        "core": "mihomo",
        "profiles": [
            {"id": "x", "kind": "local", "path": "../etc/passwd"}
        ]
    }"#;
    assert!(matches!(
        parse_and_validate_json(bad),
        Err(ConfigError::Profile(
            crate::domain::ProfileError::LocalPathEscape { .. }
        ))
    ));
}

#[test]
fn profiles_reject_remote_loopback_url() {
    let bad = br#"{
        "schema_version": 1,
        "core": "mihomo",
        "profiles": [
            {"id": "loopback", "kind": "remote", "url": "http://127.0.0.1/x", "interval_minutes": 60}
        ]
    }"#;
    // URL parses and is http, so the path-traversal guard does not apply.
    // The SSRF containment is enforced by the fetch path (Round 7 E2E),
    // not by the schema validator, so a loopback URL still parses here.
    // The test is here to lock the documented contract: the schema
    // accepts public http(s) URLs; the fetcher rejects private/loopback
    // destinations at runtime.
    assert!(parse_and_validate_json(bad).is_ok());
}

#[test]
fn profiles_reject_remote_zero_interval() {
    let bad = br#"{
        "schema_version": 1,
        "core": "mihomo",
        "profiles": [
            {"id": "x", "kind": "remote", "url": "https://example.com/x", "interval_minutes": 0}
        ]
    }"#;
    assert!(matches!(
        parse_and_validate_json(bad),
        Err(ConfigError::Profile(
            crate::domain::ProfileError::InvalidInterval { .. }
        ))
    ));
}

#[test]
fn profiles_reject_merge_cycle() {
    let bad = br#"{
        "schema_version": 1,
        "core": "mihomo",
        "profiles": [
            {"id": "a", "kind": "merge", "parts": ["b"]},
            {"id": "b", "kind": "merge", "parts": ["a"]}
        ]
    }"#;
    assert!(matches!(
        parse_and_validate_json(bad),
        Err(ConfigError::Profile(
            crate::domain::ProfileError::Cycle { .. }
        ))
    ));
}

#[test]
fn profiles_reject_merge_unknown_part() {
    let bad = br#"{
        "schema_version": 1,
        "core": "mihomo",
        "profiles": [
            {"id": "a", "kind": "merge", "parts": ["ghost"]}
        ]
    }"#;
    assert!(matches!(
        parse_and_validate_json(bad),
        Err(ConfigError::Profile(
            crate::domain::ProfileError::UnknownId { .. }
        ))
    ));
}

#[test]
fn profiles_default_is_empty_list() -> Result<(), ConfigError> {
    let parsed = parse_and_validate_json(br#"{"schema_version":1,"core":"mihomo"}"#)?;
    assert!(parsed.profiles.is_empty());
    Ok(())
}

#[test]
fn profiles_diamond_merge_is_not_a_cycle() -> Result<(), ConfigError> {
    // merged = merge:[base, extra]; base and extra both merge `shared`.
    // The shared profile is *visited twice* through different paths but is
    // never part of a loop — a DFS that never pops its recursion stack used
    // to misreport this as `ProfileError::Cycle`.
    let diamond = br#"{
        "schema_version": 1,
        "core": "mihomo",
        "profiles": [
            {"id": "shared", "kind": "local", "path": "shared.yaml"},
            {"id": "base", "kind": "merge", "parts": ["shared"]},
            {"id": "extra", "kind": "merge", "parts": ["shared"]},
            {"id": "merged", "kind": "merge", "parts": ["base", "extra"]}
        ]
    }"#;
    parse_and_validate_json(diamond)?;
    Ok(())
}

#[test]
fn proxy_groups_diamond_relay_is_not_a_cycle() -> Result<(), ConfigError> {
    // A -> C, B -> C (all relay) — the diamond converges on C, which is
    // legal; only a genuine loop (A -> B -> A) is a RelayCycle.
    let diamond = br#"{
        "schema_version": 1,
        "core": "mihomo",
        "proxy_groups": [
            {
                "name": "C",
                "type": "relay",
                "members": [{"kind": "node", "tag": "n1"}]
            },
            {
                "name": "A",
                "type": "relay",
                "members": [{"kind": "group", "name": "C"}]
            },
            {
                "name": "B",
                "type": "relay",
                "members": [{"kind": "group", "name": "C"}]
            },
            {
                "name": "Z",
                "type": "relay",
                "members": [{"kind": "group", "name": "A"}, {"kind": "group", "name": "B"}]
            }
        ]
    }"#;
    parse_and_validate_json(diamond)?;
    Ok(())
}

#[test]
fn proxy_groups_minimal_select_parses_and_validates() -> Result<(), ConfigError> {
    let yaml = br#"{
        "schema_version": 1,
        "core": "mihomo",
        "proxy_groups": [
            {
                "name": "Proxy",
                "type": "select",
                "members": [
                    {"kind": "node", "tag": "hk-1"},
                    {"kind": "direct"}
                ]
            }
        ]
    }"#;
    let parsed = parse_and_validate_json(yaml)?;
    assert_eq!(parsed.proxy_groups.len(), 1);
    let group = &parsed.proxy_groups[0];
    assert_eq!(group.name, "Proxy");
    assert_eq!(group.members.len(), 2);
    assert!(group.url_test.is_none());
    Ok(())
}

#[test]
fn proxy_groups_url_test_requires_url_test_block() {
    let bad = br#"{
        "schema_version": 1,
        "core": "mihomo",
        "proxy_groups": [
            {"name": "Auto", "type": "url-test", "members": [{"kind": "node", "tag": "n1"}]}
        ]
    }"#;
    assert!(matches!(
        parse_and_validate_json(bad),
        Err(ConfigError::ProxyGroup(
            crate::domain::ProxyGroupError::MissingUrlTest { .. }
        ))
    ));
}

#[test]
fn proxy_groups_rejects_empty_members() {
    // Both kernels refuse a group with an empty member list; the schema
    // validator reports it before the core ever sees the config.
    let bad = br#"{
        "schema_version": 1,
        "core": "mihomo",
        "proxy_groups": [
            {"name": "P", "type": "select", "members": []}
        ]
    }"#;
    assert!(matches!(
        parse_and_validate_json(bad),
        Err(ConfigError::ProxyGroup(
            crate::domain::ProxyGroupError::EmptyMembers { .. }
        ))
    ));
}

#[test]
fn proxy_groups_rejects_invalid_probe_url() {
    let bad = br#"{
        "schema_version": 1,
        "core": "mihomo",
        "proxy_groups": [
            {
                "name": "Auto",
                "type": "url-test",
                "members": [{"kind": "node", "tag": "n1"}],
                "url_test": {"url": "notaurl", "interval_seconds": 300}
            }
        ]
    }"#;
    assert!(matches!(
        parse_and_validate_json(bad),
        Err(ConfigError::ProxyGroup(
            crate::domain::ProxyGroupError::InvalidProbeUrl { .. }
        ))
    ));
}

#[test]
fn proxy_groups_select_rejects_url_test_block() {
    let bad = br#"{
        "schema_version": 1,
        "core": "mihomo",
        "proxy_groups": [
            {
                "name": "P",
                "type": "select",
                "members": [{"kind": "node", "tag": "n1"}],
                "url_test": {"url": "http://example.com"}
            }
        ]
    }"#;
    assert!(matches!(
        parse_and_validate_json(bad),
        Err(ConfigError::ProxyGroup(
            crate::domain::ProxyGroupError::UnexpectedUrlTest { .. }
        ))
    ));
}

#[test]
fn proxy_groups_rejects_duplicate_name() {
    let bad = br#"{
        "schema_version": 1,
        "core": "mihomo",
        "proxy_groups": [
            {"name": "A", "type": "select", "members": [{"kind": "node", "tag": "n1"}]},
            {"name": "A", "type": "select", "members": [{"kind": "node", "tag": "n2"}]}
        ]
    }"#;
    assert!(matches!(
        parse_and_validate_json(bad),
        Err(ConfigError::ProxyGroup(
            crate::domain::ProxyGroupError::DuplicateName { .. }
        ))
    ));
}

#[test]
fn proxy_groups_rejects_unknown_member_reference() {
    let bad = br#"{
        "schema_version": 1,
        "core": "mihomo",
        "proxy_groups": [
            {
                "name": "Outer",
                "type": "select",
                "members": [{"kind": "group", "name": "Ghost"}]
            }
        ]
    }"#;
    assert!(matches!(
        parse_and_validate_json(bad),
        Err(ConfigError::ProxyGroup(
            crate::domain::ProxyGroupError::UnknownMemberGroup { .. }
        ))
    ));
}

#[test]
fn proxy_groups_rejects_relay_cycle() {
    let bad = br#"{
        "schema_version": 1,
        "core": "mihomo",
        "proxy_groups": [
            {
                "name": "A",
                "type": "relay",
                "members": [{"kind": "group", "name": "B"}]
            },
            {
                "name": "B",
                "type": "relay",
                "members": [{"kind": "group", "name": "A"}]
            }
        ]
    }"#;
    assert!(matches!(
        parse_and_validate_json(bad),
        Err(ConfigError::ProxyGroup(
            crate::domain::ProxyGroupError::RelayCycle { .. }
        ))
    ));
}

#[test]
fn proxy_groups_nested_group_reference_resolves() -> Result<(), ConfigError> {
    let yaml = br#"{
        "schema_version": 1,
        "core": "mihomo",
        "proxy_groups": [
            {
                "name": "Proxy",
                "type": "select",
                "members": [
                    {"kind": "node", "tag": "hk-1"},
                    {"kind": "direct"}
                ]
            },
            {
                "name": "Auto",
                "type": "url-test",
                "members": [{"kind": "group", "name": "Proxy"}],
                "url_test": {"url": "http://www.gstatic.com/generate_204"}
            }
        ]
    }"#;
    let parsed = parse_and_validate_json(yaml)?;
    assert_eq!(parsed.proxy_groups.len(), 2);
    Ok(())
}

#[test]
fn proxy_groups_default_is_empty_list() -> Result<(), ConfigError> {
    let parsed = parse_and_validate_json(br#"{"schema_version":1,"core":"mihomo"}"#)?;
    assert!(parsed.proxy_groups.is_empty());
    Ok(())
}
