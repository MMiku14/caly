//! Happy Eyeballs upstream racing engine for low-latency DNS resolution.

use std::time::Duration;
use super::circuit::CircuitBreaker;

#[derive(Clone, Debug)]
pub struct UpstreamCandidate {
    pub tag: String,
    pub address: String,
    pub rtt_estimate: Duration,
    pub circuit_open: bool,
}

pub struct HappyEyeballsRacing {
    stagger_delay: Duration,
}

impl HappyEyeballsRacing {
    pub fn new(stagger_delay: Duration) -> Self {
        Self { stagger_delay }
    }

    pub fn stagger_delay(&self) -> Duration {
        self.stagger_delay
    }

    /// Sorts candidates by health and EWMA latency for staggered dispatch.
    pub fn rank_candidates(&self, mut candidates: Vec<UpstreamCandidate>) -> Vec<UpstreamCandidate> {
        candidates.sort_by(|a, b| {
            match (a.circuit_open, b.circuit_open) {
                (false, true) => std::cmp::Ordering::Less,
                (true, false) => std::cmp::Ordering::Greater,
                _ => a.rtt_estimate.cmp(&b.rtt_estimate),
            }
        });
        candidates
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_candidate_ranking() {
        let racing = HappyEyeballsRacing::new(Duration::from_millis(50));
        let candidates = vec![
            UpstreamCandidate {
                tag: "slow".into(),
                address: "1.1.1.1".into(),
                rtt_estimate: Duration::from_millis(120),
                circuit_open: false,
            },
            UpstreamCandidate {
                tag: "dead".into(),
                address: "8.8.8.8".into(),
                rtt_estimate: Duration::from_millis(10),
                circuit_open: true,
            },
            UpstreamCandidate {
                tag: "fast".into(),
                address: "223.5.5.5".into(),
                rtt_estimate: Duration::from_millis(15),
                circuit_open: false,
            },
        ];

        let ranked = racing.rank_candidates(candidates);
        assert_eq!(ranked[0].tag, "fast");
        assert_eq!(ranked[1].tag, "slow");
        assert_eq!(ranked[2].tag, "dead");
    }
}
