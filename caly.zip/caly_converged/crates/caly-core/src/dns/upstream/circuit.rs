//! Circuit Breaker and EWMA RTT tracking for upstream DNS nodes.

use std::sync::atomic::{AtomicBool, AtomicU32, AtomicU64, Ordering};
use std::time::{Duration, Instant};

/// Exponentially Weighted Moving Average (EWMA) + Trip-on-Failure Circuit Breaker.
pub struct CircuitBreaker {
    consecutive_failures: AtomicU32,
    failure_threshold: u32,
    is_open: AtomicBool,
    last_state_change_millis: AtomicU64,
    cooldown: Duration,
    ewma_rtt_micros: AtomicU64,
}

impl CircuitBreaker {
    pub fn new(failure_threshold: u32, cooldown: Duration) -> Self {
        Self {
            consecutive_failures: AtomicU32::new(0),
            failure_threshold,
            is_open: AtomicBool::new(false),
            last_state_change_millis: AtomicU64::new(0),
            cooldown,
            ewma_rtt_micros: AtomicU64::new(20_000), // initial default 20ms
        }
    }

    pub fn is_open(&self) -> bool {
        self.is_open.load(Ordering::Relaxed)
    }

    pub fn record_success(&self, rtt: Duration) {
        self.consecutive_failures.store(0, Ordering::Relaxed);
        self.is_open.store(false, Ordering::Relaxed);

        // EWMA update: alpha = 0.2
        let current_ewma = self.ewma_rtt_micros.load(Ordering::Relaxed);
        let sample = rtt.as_micros() as u64;
        let new_ewma = (current_ewma * 4 + sample) / 5;
        self.ewma_rtt_micros.store(new_ewma, Ordering::Relaxed);
    }

    pub fn record_failure(&self) {
        let fails = self.consecutive_failures.fetch_add(1, Ordering::Relaxed) + 1;
        if fails >= self.failure_threshold {
            self.is_open.store(true, Ordering::Relaxed);
        }
    }

    pub fn rtt_estimate(&self) -> Duration {
        Duration::from_micros(self.ewma_rtt_micros.load(Ordering::Relaxed))
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_circuit_breaker_trips() {
        let cb = CircuitBreaker::new(3, Duration::from_secs(10));
        assert!(!cb.is_open());

        cb.record_failure();
        cb.record_failure();
        assert!(!cb.is_open());

        cb.record_failure();
        assert!(cb.is_open());

        cb.record_success(Duration::from_millis(15));
        assert!(!cb.is_open());
        assert!(cb.rtt_estimate().as_millis() <= 25);
    }
}
