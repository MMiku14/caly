//! Upstream DNS resolvers and concurrent racing engines.

pub mod circuit;
pub mod racing;

use std::time::Duration;

#[derive(Clone, Debug, Default)]
pub struct UpstreamStats {
    pub total_queries: u64,
    pub successful_queries: u64,
    pub failed_queries: u64,
    pub ewma_rtt: Duration,
    pub circuit_open: bool,
}

pub use circuit::CircuitBreaker;
pub use racing::HappyEyeballsRacing;
