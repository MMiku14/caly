//! Static hosts, wildcard mapping, and domain rewriting engine.
//!
//! Maps domain names directly to static IPv4/IPv6 addresses or CNAME aliases
//! before upstream nameservers are queried. Compatible with both Mihomo's `hosts:`
//! dictionary and sing-box's static DNS routing rules.

use std::{collections::BTreeMap, net::IpAddr};
use serde::{Deserialize, Serialize};

/// Maximum entries in a static hosts mapping.
pub const MAX_HOSTS_ENTRIES: usize = 1024;

/// Target of a static host entry (IP address list or CNAME alias).
#[derive(Clone, Debug, Eq, PartialEq, Serialize, Deserialize)]
pub enum HostTarget {
    /// Resolved IP address list (A / AAAA records).
    Ips(Vec<IpAddr>),
    /// Canonical name alias (CNAME rewrite).
    Alias(String),
}

/// Static hosts table supporting exact domains and wildcard patterns (`*.example.com`).
#[derive(Clone, Debug, Default, Eq, PartialEq, Serialize, Deserialize)]
pub struct DnsHosts {
    /// Domain-to-target map.
    pub entries: BTreeMap<String, HostTarget>,
    /// Whether to consult the operating system's local hosts file (`/etc/hosts`).
    pub use_system_hosts: bool,
    /// Master switch for static hosts resolution.
    pub enabled: bool,
}

impl DnsHosts {
    pub fn new() -> Self {
        Self {
            entries: BTreeMap::new(),
            use_system_hosts: true,
            enabled: true,
        }
    }

    /// Adds an exact or wildcard domain mapping to an IP address.
    pub fn add_ip(&mut self, domain: impl Into<String>, ip: IpAddr) {
        let key = domain.into().to_ascii_lowercase();
        match self.entries.entry(key) {
            std::collections::btree_map::Entry::Vacant(e) => {
                e.insert(HostTarget::Ips(vec![ip]));
            }
            std::collections::btree_map::Entry::Occupied(mut e) => {
                if let HostTarget::Ips(ips) = e.get_mut() {
                    if !ips.contains(&ip) {
                        ips.push(ip);
                    }
                } else {
                    e.insert(HostTarget::Ips(vec![ip]));
                }
            }
        }
    }

    /// Adds an alias / CNAME rewriting rule.
    pub fn add_alias(&mut self, domain: impl Into<String>, alias: impl Into<String>) {
        let key = domain.into().to_ascii_lowercase();
        self.entries.insert(key, HostTarget::Alias(alias.into()));
    }

    /// Resolves a domain against the static hosts table (exact match first, then wildcard).
    pub fn resolve(&self, domain: &str) -> Option<&HostTarget> {
        if !self.enabled {
            return None;
        }
        let lower = domain.to_ascii_lowercase();
        // 1. Exact match
        if let Some(target) = self.entries.get(&lower) {
            return Some(target);
        }
        // 2. Wildcard match (*.domain.com or .domain.com)
        for (pattern, target) in &self.entries {
            if crate::dns::advanced::matches_wildcard_suffix(&lower, pattern) {
                return Some(target);
            }
        }
        None
    }

    /// Number of declared host rules.
    pub fn len(&self) -> usize {
        self.entries.len()
    }

    /// Whether the table has no entries.
    pub fn is_empty(&self) -> bool {
        self.entries.is_empty()
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::net::Ipv4Addr;

    #[test]
    fn exact_and_wildcard_host_matching() {
        let mut hosts = DnsHosts::new();
        hosts.add_ip("router.local", IpAddr::V4(Ipv4Addr::new(192, 168, 1, 1)));
        hosts.add_ip("*.corp.net", IpAddr::V4(Ipv4Addr::new(10, 0, 0, 1)));
        hosts.add_alias("service.local", "real.service.com");

        // Exact match
        assert_eq!(
            hosts.resolve("router.local"),
            Some(&HostTarget::Ips(vec![IpAddr::V4(Ipv4Addr::new(192, 168, 1, 1))]))
        );

        // Wildcard match
        assert_eq!(
            hosts.resolve("mail.corp.net"),
            Some(&HostTarget::Ips(vec![IpAddr::V4(Ipv4Addr::new(10, 0, 0, 1))]))
        );
        assert_eq!(
            hosts.resolve("sub.dept.corp.net"),
            Some(&HostTarget::Ips(vec![IpAddr::V4(Ipv4Addr::new(10, 0, 0, 1))]))
        );

        // Alias CNAME
        assert_eq!(
            hosts.resolve("service.local"),
            Some(&HostTarget::Alias("real.service.com".to_owned()))
        );

        // Unmatched
        assert_eq!(hosts.resolve("external.com"), None);
    }
}
