//! High-performance bidirectional Fake-IP allocation engine.

pub mod pool;
pub mod filter;

pub use pool::{FakeIpEngine, FakeIpRecord, RealFakeIpEngine};
pub use filter::FakeIpFilter;
