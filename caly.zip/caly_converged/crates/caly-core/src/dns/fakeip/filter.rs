//! Domain filtering for Fake-IP allocation bypass.

use std::collections::HashSet;

/// Radix/Suffix pattern matcher for Fake-IP bypass rules.
#[derive(Clone, Debug, Default)]
pub struct FakeIpFilter {
    exact_domains: HashSet<String>,
    suffix_rules: Vec<String>,
}

impl FakeIpFilter {
    pub fn new() -> Self {
        Self::default()
    }

    pub fn add_rule(&mut self, rule: &str) {
        let trimmed = rule.trim().trim_end_matches('.').to_ascii_lowercase();
        if trimmed.starts_with("*.") {
            self.suffix_rules.push(trimmed[2..].to_string());
        } else if trimmed.starts_with("+.") {
            self.suffix_rules.push(trimmed[2..].to_string());
        } else {
            self.exact_domains.insert(trimmed);
        }
    }

    pub fn should_bypass(&self, domain: &str) -> bool {
        let d = domain.trim().trim_end_matches('.').to_ascii_lowercase();
        if self.exact_domains.contains(&d) {
            return true;
        }
        for suffix in &self.suffix_rules {
            if d == *suffix || d.ends_with(&format!(".{suffix}")) {
                return true;
            }
        }
        false
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_bypass_filter() {
        let mut filter = FakeIpFilter::new();
        filter.add_rule("*.apple.com");
        filter.add_rule("captive.apple.com");
        filter.add_rule("+.msftconnecttest.com");

        assert!(filter.should_bypass("captive.apple.com"));
        assert!(filter.should_bypass("music.apple.com"));
        assert!(filter.should_bypass("www.msftconnecttest.com"));
        assert!(!filter.should_bypass("google.com"));
    }
}
