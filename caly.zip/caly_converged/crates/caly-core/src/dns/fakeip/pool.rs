//! Thread-safe continuous CIDR Fake-IP allocation pool.

use std::collections::{HashMap, VecDeque};
use std::net::Ipv4Addr;
use std::sync::atomic::{AtomicU32, Ordering};
use std::sync::RwLock;
use std::path::PathBuf;
use std::time::SystemTime;

use super::filter::FakeIpFilter;

/// Record of an allocated Fake-IP.
#[derive(Clone, Debug)]
pub struct FakeIpRecord {
    pub domain: String,
    pub assigned_at: SystemTime,
    pub last_accessed: SystemTime,
}

pub trait FakeIpEngine: Send + Sync {
    fn allocate(&self, domain: &str) -> Result<Ipv4Addr, String>;
    fn reverse_lookup(&self, ip: Ipv4Addr) -> Option<String>;
    fn contains(&self, ip: Ipv4Addr) -> bool;
    fn should_bypass(&self, domain: &str) -> bool;
    fn persist(&self) -> Result<(), String>;
}

pub struct RealFakeIpEngine {
    start_ip: u32,
    end_ip: u32,
    current_offset: AtomicU32,
    capacity: u32,
    bypass_filter: FakeIpFilter,
    wal_path: Option<PathBuf>,
    state: RwLock<FakeIpState>,
}

struct FakeIpState {
    domain_to_ip: HashMap<String, Ipv4Addr>,
    ip_to_domain: HashMap<Ipv4Addr, FakeIpRecord>,
    lru_queue: VecDeque<Ipv4Addr>,
}

impl RealFakeIpEngine {
    pub fn new(
        cidr_base: Ipv4Addr,
        prefix_len: u8,
        bypass_rules: Vec<String>,
        wal_path: Option<PathBuf>,
    ) -> Result<Self, String> {
        if prefix_len < 8 || prefix_len > 30 {
            return Err("CIDR mask out of bounds (must be 8..=30)".into());
        }
        let mask = !((1u32 << (32 - prefix_len)) - 1);
        let base_num = u32::from(cidr_base) & mask;
        let host_count = 1u32 << (32 - prefix_len);

        let start_ip = base_num + 2;
        let end_ip = base_num + host_count - 2;
        let capacity = end_ip - start_ip + 1;

        let mut filter = FakeIpFilter::new();
        for r in bypass_rules {
            filter.add_rule(&r);
        }

        let engine = Self {
            start_ip,
            end_ip,
            current_offset: AtomicU32::new(0),
            capacity,
            bypass_filter: filter,
            wal_path,
            state: RwLock::new(FakeIpState {
                domain_to_ip: HashMap::new(),
                ip_to_domain: HashMap::new(),
                lru_queue: VecDeque::new(),
            }),
        };

        if let Some(ref path) = engine.wal_path {
            let _ = engine.recover_from_wal(path);
        }

        Ok(engine)
    }

    fn recover_from_wal(&self, path: &PathBuf) -> std::io::Result<()> {
        if !path.exists() {
            return Ok(());
        }
        let bytes = std::fs::read(path)?;
        let mut cursor = 0;
        let mut state = match self.state.write() { Ok(g) => g, Err(p) => p.into_inner() };
        while cursor + 6 <= bytes.len() {
            let Ok(ip_bytes) = <[u8; 4]>::try_from(&bytes[cursor..cursor + 4]) else { break; };
            let ip = Ipv4Addr::from(ip_bytes);
            cursor += 4;
            let Ok(len_slice) = <[u8; 2]>::try_from(&bytes[cursor..cursor + 2]) else { break; };
            let len = u16::from_be_bytes(len_slice) as usize;
            cursor += 2;
            if cursor + len > bytes.len() {
                break;
            }
            if let Ok(domain) = std::str::from_utf8(&bytes[cursor..cursor + len]) {
                let rec = FakeIpRecord {
                    domain: domain.to_string(),
                    assigned_at: SystemTime::now(),
                    last_accessed: SystemTime::now(),
                };
                state.domain_to_ip.insert(domain.to_string(), ip);
                state.ip_to_domain.insert(ip, rec);
                state.lru_queue.push_back(ip);
            }
            cursor += len;
        }
        Ok(())
    }
}

impl FakeIpEngine for RealFakeIpEngine {
    fn should_bypass(&self, domain: &str) -> bool {
        self.bypass_filter.should_bypass(domain)
    }

    fn contains(&self, ip: Ipv4Addr) -> bool {
        let num = u32::from(ip);
        num >= self.start_ip && num <= self.end_ip
    }

    fn reverse_lookup(&self, ip: Ipv4Addr) -> Option<String> {
        let state = match self.state.read() { Ok(g) => g, Err(p) => p.into_inner() };
        state.ip_to_domain.get(&ip).map(|r| r.domain.clone())
    }

    fn allocate(&self, domain: &str) -> Result<Ipv4Addr, String> {
        let normalized = domain.trim_end_matches('.').to_ascii_lowercase();

        // 1. Fast read-lock path
        {
            let state = match self.state.read() { Ok(g) => g, Err(p) => p.into_inner() };
            if let Some(&ip) = state.domain_to_ip.get(&normalized) {
                return Ok(ip);
            }
        }

        // 2. Write-lock path
        let mut state = match self.state.write() { Ok(g) => g, Err(p) => p.into_inner() };
        if let Some(&ip) = state.domain_to_ip.get(&normalized) {
            return Ok(ip);
        }

        let ip = if state.domain_to_ip.len() < self.capacity as usize {
            let offset = self.current_offset.fetch_add(1, Ordering::Relaxed) % self.capacity;
            Ipv4Addr::from(self.start_ip + offset)
        } else {
            let recycled_ip = state.lru_queue.pop_front().ok_or_else(|| {
                "Fake-IP pool exhausted without LRU candidates".to_string()
            })?;
            if let Some(old_rec) = state.ip_to_domain.remove(&recycled_ip) {
                state.domain_to_ip.remove(&old_rec.domain);
            }
            recycled_ip
        };

        let record = FakeIpRecord {
            domain: normalized.clone(),
            assigned_at: SystemTime::now(),
            last_accessed: SystemTime::now(),
        };

        state.domain_to_ip.insert(normalized, ip);
        state.ip_to_domain.insert(ip, record);
        state.lru_queue.push_back(ip);

        Ok(ip)
    }

    fn persist(&self) -> Result<(), String> {
        if let Some(ref path) = self.wal_path {
            let state = match self.state.read() { Ok(g) => g, Err(p) => p.into_inner() };
            let mut buf = Vec::with_capacity(state.ip_to_domain.len() * 32);
            for (ip, rec) in &state.ip_to_domain {
                buf.extend_from_slice(&ip.octets());
                let domain_bytes = rec.domain.as_bytes();
                buf.extend_from_slice(&(domain_bytes.len() as u16).to_be_bytes());
                buf.extend_from_slice(domain_bytes);
            }
            std::fs::write(path, buf).map_err(|e| e.to_string())?;
        }
        Ok(())
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_fakeip_allocation_and_reversal() {
        let engine = RealFakeIpEngine::new(
            Ipv4Addr::new(198, 18, 0, 0),
            15,
            vec!["*.apple.com".to_string()],
            None,
        ).unwrap();

        assert!(engine.should_bypass("api.apple.com"));
        assert!(!engine.should_bypass("github.com"));

        let ip1 = engine.allocate("github.com").unwrap();
        assert!(engine.contains(ip1));
        assert_eq!(engine.reverse_lookup(ip1), Some("github.com".to_string()));

        // Repeated query returns identical IP
        let ip2 = engine.allocate("github.com").unwrap();
        assert_eq!(ip1, ip2);
    }
}
