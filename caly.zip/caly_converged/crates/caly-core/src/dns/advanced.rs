//! Advanced full-featured DNS engine primitives:
//! - Full DNS Record Types (A, AAAA, CNAME, TXT, MX, NS, PTR, SRV, SOA, HTTPS, SVCB)
//! - Reverse DNS (in-addr.arpa / ip6.arpa) PTR generation
//! - CNAME Chain flattening & loop protection
//! - EDNS0 (RFC 6891), DNSSEC validation flags, and ECS (RFC 7871) controls
//! - Ad/Malware domain filtering with temporal policy controls
//! - Recursive root trace diagnostic models (dig +trace)

use std::{
    collections::{BTreeMap, BTreeSet},
    net::{IpAddr, Ipv4Addr, Ipv6Addr},
    time::{Duration, Instant, SystemTime},
};
use serde::{Deserialize, Serialize};

/// Standard and modern DNS Resource Record (RR) types.
#[derive(Clone, Copy, Debug, Eq, Hash, PartialEq, Serialize, Deserialize)]
#[serde(rename_all = "UPPERCASE")]
pub enum DnsRecordType {
    A,
    AAAA,
    CNAME,
    TXT,
    MX,
    NS,
    PTR,
    SRV,
    SOA,
    HTTPS,
    SVCB,
    ANY,
    Other(u16),
}

impl DnsRecordType {
    /// Returns the wire-protocol 16-bit type code (RFC 1035 / RFC 8482 / RFC 9460).
    pub const fn type_code(self) -> u16 {
        match self {
            Self::A => 1,
            Self::NS => 2,
            Self::CNAME => 5,
            Self::SOA => 6,
            Self::PTR => 12,
            Self::MX => 15,
            Self::TXT => 16,
            Self::AAAA => 28,
            Self::SRV => 33,
            Self::ANY => 255,
            Self::SVCB => 64,
            Self::HTTPS => 65,
            Self::Other(code) => code,
        }
    }

    /// Converts wire-protocol 16-bit type code to DnsRecordType, preserving unknown types as Other(code).
    pub const fn from_type_code(code: u16) -> Self {
        match code {
            1 => Self::A,
            2 => Self::NS,
            5 => Self::CNAME,
            6 => Self::SOA,
            12 => Self::PTR,
            15 => Self::MX,
            16 => Self::TXT,
            28 => Self::AAAA,
            33 => Self::SRV,
            64 => Self::SVCB,
            65 => Self::HTTPS,
            255 => Self::ANY,
            other => Self::Other(other),
        }
    }

    /// Parses from common text labels.
    pub fn from_label(label: &str) -> Option<Self> {
        match label.to_ascii_uppercase().as_str() {
            "A" => Some(Self::A),
            "AAAA" => Some(Self::AAAA),
            "CNAME" => Some(Self::CNAME),
            "TXT" => Some(Self::TXT),
            "MX" => Some(Self::MX),
            "NS" => Some(Self::NS),
            "PTR" => Some(Self::PTR),
            "SRV" => Some(Self::SRV),
            "SOA" => Some(Self::SOA),
            "HTTPS" => Some(Self::HTTPS),
            "SVCB" => Some(Self::SVCB),
            "ANY" => Some(Self::ANY),
            _ => None,
        }
    }
}

/// Converts an IP address to its standard Reverse DNS PTR query hostname.
///
/// IPv4: `192.0.2.1` -> `1.2.0.192.in-addr.arpa` (RFC 1035)
/// IPv6: `2001:db8::1` -> `1.0.0.0...0.8.b.d.0.1.0.0.2.ip6.arpa` (RFC 3596)
pub fn reverse_dns_ptr_name(ip: IpAddr) -> String {
    match ip {
        IpAddr::V4(v4) => {
            let octets = v4.octets();
            format!("{}.{}.{}.{}.in-addr.arpa", octets[3], octets[2], octets[1], octets[0])
        }
        IpAddr::V6(v6) => {
            let octets = v6.octets();
            let mut nibbles = Vec::with_capacity(64);
            for byte in octets.iter().rev() {
                let low = byte & 0x0F;
                let high = (byte >> 4) & 0x0F;
                nibbles.push(format!("{low:x}"));
                nibbles.push(format!("{high:x}"));
            }
            format!("{}.ip6.arpa", nibbles.join("."))
        }
    }
}

/// Resolves CNAME alias chains with circular reference / loop protection.
#[derive(Clone, Debug, Default)]
pub struct CnameFlattener {
    /// Max chain depth before declaring an alias loop (RFC standard recommends <= 8).
    pub max_depth: usize,
}

impl CnameFlattener {
    pub fn new(max_depth: usize) -> Self {
        Self {
            max_depth: if max_depth == 0 { 8 } else { max_depth },
        }
    }

    /// Resolves `start_domain` against the provided alias mapping.
    /// Returns the canonical target domain or an error if an alias loop is detected.
    pub fn chase<'a>(&self, start_domain: &'a str, aliases: &'a BTreeMap<String, String>) -> Result<&'a str, &'static str> {
        let mut current = start_domain;
        let mut visited: Vec<&'a str> = Vec::with_capacity(self.max_depth);
        visited.push(current);

        for _ in 0..self.max_depth {
            let target = aliases.iter().find_map(|(k, v)| {
                if k.eq_ignore_ascii_case(current) {
                    Some(v.as_str())
                } else {
                    None
                }
            });
            if let Some(next) = target {
                if visited.iter().any(|v| v.eq_ignore_ascii_case(next)) {
                    return Err("CNAME loop detected");
                }
                visited.push(next);
                current = next;
            } else {
                return Ok(current);
            }
        }
        Err("CNAME chain exceeded maximum resolution depth")
    }
}

/// EDNS0 (RFC 6891) option controls: ECS (RFC 7871), DO bit (DNSSEC), and UDP size.
#[derive(Clone, Debug, Eq, PartialEq, Serialize, Deserialize)]
pub struct Edns0Options {
    /// Client UDP payload buffer size (default 1232 / 4096 bytes).
    pub udp_payload_size: u16,
    /// DNSSEC OK (DO) flag requested in EDNS header.
    pub dnssec_ok: bool,
    /// EDNS Client Subnet (ECS) handling strategy.
    pub ecs_policy: EcsPolicy,
}

impl Default for Edns0Options {
    fn default() -> Self {
        Self {
            udp_payload_size: 1232, // RFC 8900 recommended DNS flag day size to prevent IP fragmentation
            dnssec_ok: true,
            ecs_policy: EcsPolicy::Forward,
        }
    }
}

/// Policy for handling EDNS Client Subnet (ECS, RFC 7871).
#[derive(Clone, Debug, Eq, PartialEq, Serialize, Deserialize)]
#[serde(rename_all = "lowercase")]
pub enum EcsPolicy {
    /// Strip any client ECS to protect user geographic privacy.
    Strip,
    /// Forward client-provided subnet as-is.
    Forward,
    /// Forge a custom prefix CIDR to optimize CDN without revealing user IP.
    Custom(String),
}

/// Domain filtering and parental/temporal policy control.
#[derive(Clone, Debug, Default)]
pub struct DnsSecurityFilter {
    /// Blocked domain exact list and wildcards (e.g. ads, tracking, malware).
    pub blocklist: BTreeSet<String>,
    /// Permitted domain exceptions (allowlist).
    pub allowlist: BTreeSet<String>,
    /// Temporal schedule: start hour and end hour (24h format, UTC) when blocking applies.
    pub schedule: Option<(u8, u8)>,
}

impl DnsSecurityFilter {
    pub fn new() -> Self {
        Self::default()
    }

    pub fn add_blocked(&mut self, domain: impl Into<String>) {
        self.blocklist.insert(domain.into().to_ascii_lowercase());
    }

    pub fn add_allowed(&mut self, domain: impl Into<String>) {
        self.allowlist.insert(domain.into().to_ascii_lowercase());
    }

    /// Sets a time-based blocking window (e.g. 9 to 18 for work hours).
    pub fn with_schedule(mut self, start_hour: u8, end_hour: u8) -> Self {
        self.schedule = Some((start_hour, end_hour));
        self
    }

    /// Evaluates whether a domain query should be blocked.
    pub fn is_blocked(&self, domain: &str, current_utc_hour: u8) -> bool {
        let lower = domain.to_ascii_lowercase();
        // Allowlist takes strict precedence
        if self.allowlist.contains(&lower) {
            return false;
        }
        // Temporal schedule check
        if let Some((start, end)) = self.schedule {
            let in_window = if start <= end {
                current_utc_hour >= start && current_utc_hour < end
            } else {
                current_utc_hour >= start || current_utc_hour < end
            };
            if !in_window {
                return false;
            }
        }
        // Check exact match or suffix wildcard
        if self.blocklist.contains(&lower) {
            return true;
        }
        for blocked in &self.blocklist {
            if matches_wildcard_suffix(&lower, blocked) {
                return true;
            }
        }
        false
    }
}

/// Diagnostic model for iterative recursive root tracing (like `dig +trace`).
#[derive(Clone, Debug, Serialize)]
pub struct RecursiveTraceHop {
    pub stage: &'static str, // "root", "tld", "authoritative"
    pub server: String,
    pub latency_ms: u64,
    pub referrals: Vec<String>,
    pub authoritative: bool,
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_reverse_dns_generation() {
        let v4 = "192.0.2.1".parse::<IpAddr>().unwrap();
        assert_eq!(reverse_dns_ptr_name(v4), "1.2.0.192.in-addr.arpa");

        let v6 = "2001:db8::1".parse::<IpAddr>().unwrap();
        let ptr6 = reverse_dns_ptr_name(v6);
        assert!(ptr6.ends_with(".ip6.arpa"));
        assert!(ptr6.starts_with("1.0.0.0."));
    }

    #[test]
    fn test_cname_chain_flattener() {
        let flattener = CnameFlattener::new(5);
        let mut aliases = BTreeMap::new();
        aliases.insert("alias.com".to_owned(), "middle.com".to_owned());
        aliases.insert("middle.com".to_owned(), "real.com".to_owned());

        let target = flattener.chase("alias.com", &aliases).unwrap();
        assert_eq!(target, "real.com");

        // Loop detection
        aliases.insert("real.com".to_owned(), "alias.com".to_owned());
        assert!(flattener.chase("alias.com", &aliases).is_err());
    }

    #[test]
    fn test_security_filter_with_schedule() {
        let mut filter = DnsSecurityFilter::new().with_schedule(9, 18);
        filter.add_blocked("ads.example.com");
        filter.add_blocked("*.tracker.net");
        filter.add_allowed("safe.tracker.net");

        // During scheduled window (12:00 UTC)
        assert!(filter.is_blocked("ads.example.com", 12));
        assert!(filter.is_blocked("sub.tracker.net", 12));
        assert!(!filter.is_blocked("safe.tracker.net", 12)); // Allowed

        // Outside scheduled window (20:00 UTC)
        assert!(!filter.is_blocked("ads.example.com", 20));
    }
}

/// Zero-allocation wildcard domain suffix matching with exact subdomain boundary checks.
pub fn matches_wildcard_suffix(domain: &str, pattern: &str) -> bool {
    let suffix = pattern.trim_start_matches(|c| c == '*' || c == '.');
    if suffix.is_empty() {
        return false;
    }
    if domain.eq_ignore_ascii_case(suffix) {
        return true;
    }
    if domain.len() > suffix.len() && domain.ends_with(suffix) {
        let prefix_len = domain.len() - suffix.len();
        return domain.as_bytes()[prefix_len - 1] == b'.';
    }
    false
}
