//! DNS caching algorithms, eviction policies, and W-TinyLFU admission filter.
//!
//! Based on:
//! - Gil Einziger, Roy Friedman, Ben Manes — "TinyLFU: A Highly Efficient Cache Admission Policy"
//!   (ACM Transactions on Computer Systems, 2017).
//! - RFC 8767: Serving Stale Data to Improve DNS Resiliency (Stale-While-Revalidate).
//! - RFC 2308: Negative Caching of DNS Queries (DNS NCACHE).
//! - RFC 7871: Client Subnet in DNS Queries (EDNS Client Subnet / ECS partitioning).
//!
//! Provides core-agnostic settings and an in-memory cache engine supporting:
//! - W-TinyLFU 4-bit 4-hash Count-Min Sketch admission policy to filter one-hit wonders.
//! - Cross-record type isolation (`DnsCacheKey`) to eliminate cross-type aliasing.
//! - Rich answer data (`DnsAnswerData`) covering positive IPs/CNAME/TXT and negative NxDomain/NoData.
//! - Stale-While-Revalidate (RFC 8767) with pre-fetch threshold forecasting (remaining TTL <= 10%).
//! - Performance metrics (`DnsCacheMetrics`) and atomic tracking.
//! - Thread-safe concurrent `SharedDnsCache` with lock-poison recovery.

use std::{
    collections::{HashMap, hash_map::DefaultHasher},
    hash::{Hash, Hasher},
    net::IpAddr,
    sync::{
        Arc, RwLock,
        atomic::{AtomicU64, Ordering},
    },
    time::{Duration, Instant},
};
use serde::{Deserialize, Serialize};

use super::advanced::DnsRecordType;

/// Cache eviction and admission algorithm.
#[derive(Clone, Copy, Debug, Default, Eq, PartialEq, Serialize, Deserialize)]
#[serde(rename_all = "lowercase")]
pub enum CacheAlgorithm {
    /// W-TinyLFU (default): LRU eviction paired with a 4-bit Count-Min Sketch admission filter.
    #[default]
    #[serde(rename = "tinylfu")]
    TinyLfu,
    /// Standard Least Recently Used without admission filtering.
    Lru,
    /// Least Frequently Used.
    Lfu,
    /// Adaptive Replacement Cache.
    Arc,
    /// First In First Out.
    Fifo,
}

impl CacheAlgorithm {
    pub const fn label(self) -> &'static str {
        match self {
            Self::TinyLfu => "tinylfu",
            Self::Lru => "lru",
            Self::Lfu => "lfu",
            Self::Arc => "arc",
            Self::Fifo => "fifo",
        }
    }

    pub fn from_label(label: &str) -> Option<Self> {
        match label.to_ascii_lowercase().as_str() {
            "tinylfu" | "w-tinylfu" => Some(Self::TinyLfu),
            "lru" => Some(Self::Lru),
            "lfu" => Some(Self::Lfu),
            "arc" => Some(Self::Arc),
            "fifo" => Some(Self::Fifo),
            _ => None,
        }
    }
}

/// Comprehensive DNS cache settings.
#[derive(Clone, Debug, Eq, PartialEq, Serialize, Deserialize)]
pub struct DnsCacheSettings {
    /// Eviction and admission algorithm.
    pub algorithm: CacheAlgorithm,
    /// Maximum number of cached DNS entries.
    pub size: usize,
    /// Minimum TTL in seconds to clamp short upstream answers.
    pub min_ttl: u32,
    /// Maximum TTL in seconds to prevent stale records from persisting forever.
    pub max_ttl: u32,
    /// TTL in seconds for negative responses (NXDOMAIN / NODATA).
    pub negative_ttl: u32,
    /// Serve stale cached answers optimistically (RFC 8767).
    pub stale_cache: bool,
    /// Allowable window in seconds past TTL where stale answers may still be served (RFC 8767).
    #[serde(default = "default_stale_window")]
    pub stale_window: u32,
    /// Whether cache lookups respect routing rules and policy tags.
    pub respect_rules: bool,
}

fn default_stale_window() -> u32 {
    3600
}

impl Default for DnsCacheSettings {
    fn default() -> Self {
        Self {
            algorithm: CacheAlgorithm::TinyLfu,
            size: 4096,
            min_ttl: 60,
            max_ttl: 86400,
            negative_ttl: 10,
            stale_cache: true,
            stale_window: 3600,
            respect_rules: true,
        }
    }
}

/// Cache lookup key ensuring strict cross-type isolation and ECS partitioning.
///
/// Prevents cross-type aliasing where an 'A' answer could erroneously satisfy
/// an 'AAAA' or 'HTTPS' query for the same hostname.
#[derive(Clone, Debug, Eq, Hash, PartialEq, Serialize, Deserialize)]
pub struct DnsCacheKey {
    /// Requested DNS Record Type (A, AAAA, CNAME, HTTPS, etc.).
    pub record_type: DnsRecordType,
    /// Canonical lowercase domain name (e.g. "example.com").
    pub name: String,
    /// Optional EDNS Client Subnet (ECS, RFC 7871) prefix (e.g. "1.2.3.0/24").
    pub ecs: Option<String>,
}

impl DnsCacheKey {
    /// Constructs a normalized DNS cache key.
    pub fn new(record_type: DnsRecordType, name: impl Into<String>, ecs: Option<String>) -> Self {
        let mut name_str = name.into().trim().to_ascii_lowercase();
        if name_str.ends_with('.') && name_str.len() > 1 {
            name_str.pop();
        }
        let ecs_norm = ecs
            .map(|s| s.trim().to_ascii_lowercase())
            .filter(|s| !s.is_empty());
        Self {
            record_type,
            name: name_str,
            ecs: ecs_norm,
        }
    }

    /// Helper for IPv4 A-record key without ECS.
    pub fn a(name: impl Into<String>) -> Self {
        Self::new(DnsRecordType::A, name, None)
    }

    /// Helper for IPv6 AAAA-record key without ECS.
    pub fn aaaa(name: impl Into<String>) -> Self {
        Self::new(DnsRecordType::AAAA, name, None)
    }

    /// Helper for HTTPS SVCB record key without ECS.
    pub fn https(name: impl Into<String>) -> Self {
        Self::new(DnsRecordType::HTTPS, name, None)
    }

    /// Helper for CNAME-record key without ECS.
    pub fn cname(name: impl Into<String>) -> Self {
        Self::new(DnsRecordType::CNAME, name, None)
    }

    /// Helper for PTR reverse DNS key.
    pub fn ptr(name: impl Into<String>) -> Self {
        Self::new(DnsRecordType::PTR, name, None)
    }
}

/// Answer data for a DNS cache entry.
#[derive(Clone, Debug, Eq, PartialEq, Serialize, Deserialize)]
pub enum DnsAnswerData {
    /// Positive IP address list (A / AAAA records).
    Ips(Vec<IpAddr>),
    /// Canonical Name redirect target (CNAME record).
    Cname(String),
    /// Text records (TXT).
    Txt(Vec<String>),
    /// Raw wire answer bytes.
    Raw(Vec<u8>),
    /// RFC 2308: Negative response — domain does not exist.
    NxDomain,
    /// RFC 2308: Negative response — domain exists but no records of requested type.
    NoData,
}

impl DnsAnswerData {
    /// Whether this is a negative response (RFC 2308).
    pub fn is_negative(&self) -> bool {
        matches!(self, Self::NxDomain | Self::NoData)
    }

    /// Returns the resolved IP addresses if positive IP answer.
    pub fn ips(&self) -> Option<&[IpAddr]> {
        match self {
            Self::Ips(ips) => Some(ips.as_slice()),
            _ => None,
        }
    }

    /// Returns the CNAME target if CNAME answer.
    pub fn cname(&self) -> Option<&str> {
        match self {
            Self::Cname(cname) => Some(cname.as_str()),
            _ => None,
        }
    }
}

/// Rich DNS cache entry value with TTL management, RFC 8767 Stale-While-Revalidate,
/// and pre-fetch threshold forecasting.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct DnsCacheEntryValue {
    /// Cached DNS payload or negative indication.
    pub data: DnsAnswerData,
    /// Original TTL in seconds received from upstream or clamped by policy.
    pub raw_ttl: u32,
    /// Exact moment this entry was inserted/refreshed.
    pub inserted_at: Instant,
    /// Moment when the regular TTL expires.
    pub expires_at: Instant,
    /// Moment until which this entry may be served as stale under RFC 8767.
    pub stale_until: Instant,
}

impl DnsCacheEntryValue {
    /// Creates a new cache entry value.
    ///
    /// `stale_window_secs` defines how long after TTL expiry the record may still
    /// be served optimistically while re-validating in background (default 3600s).
    pub fn new(data: DnsAnswerData, effective_ttl_secs: u32, stale_window_secs: u32) -> Self {
        let now = Instant::now();
        let ttl_dur = Duration::from_secs(u64::from(effective_ttl_secs));
        let stale_dur = Duration::from_secs(u64::from(stale_window_secs));
        let expires_at = now + ttl_dur;
        let stale_until = expires_at + stale_dur;
        Self {
            data,
            raw_ttl: effective_ttl_secs,
            inserted_at: now,
            expires_at,
            stale_until,
        }
    }

    /// Remaining TTL in seconds before regular expiry (0 if already expired).
    pub fn remaining_ttl(&self) -> u32 {
        let now = Instant::now();
        if now >= self.expires_at {
            0
        } else {
            let rem = self.expires_at.duration_since(now).as_secs();
            u32::try_from(rem).unwrap_or(u32::MAX)
        }
    }

    /// Whether the regular TTL has elapsed.
    pub fn is_expired(&self) -> bool {
        Instant::now() >= self.expires_at
    }

    /// Whether the record is expired but still within the allowable RFC 8767 stale window.
    pub fn is_stale(&self) -> bool {
        let now = Instant::now();
        now >= self.expires_at && now < self.stale_until
    }

    /// Whether the record has passed both TTL and the stale window (dead/unusable).
    pub fn is_dead(&self) -> bool {
        Instant::now() >= self.stale_until
    }

    /// Pre-fetch flag: true when remaining TTL <= 10% of initial TTL.
    /// Indicates that background asynchronous refresh should be initiated before expiry.
    pub fn needs_prefetch(&self) -> bool {
        let rem = self.remaining_ttl();
        rem <= (self.raw_ttl / 10)
    }
}

/// Snapshot of DNS cache performance metrics.
#[derive(Clone, Copy, Debug, Default, Eq, PartialEq, Serialize, Deserialize)]
pub struct DnsCacheMetrics {
    pub hits: u64,
    pub misses: u64,
    pub stale_hits: u64,
    pub evictions: u64,
    pub admissions_rejected: u64,
}

impl DnsCacheMetrics {
    /// Ratio of cache hits (including stale hits) to total lookups in [0.0, 1.0].
    pub fn hit_rate(&self) -> f64 {
        let total = self.hits.saturating_add(self.misses);
        if total == 0 {
            0.0
        } else {
            self.hits as f64 / total as f64
        }
    }
}

/// Internal atomic tracker for high-concurrency metric updates.
#[derive(Debug, Default)]
pub struct AtomicDnsCacheMetrics {
    hits: AtomicU64,
    misses: AtomicU64,
    stale_hits: AtomicU64,
    evictions: AtomicU64,
    admissions_rejected: AtomicU64,
}

impl AtomicDnsCacheMetrics {
    pub fn new() -> Self {
        Self::default()
    }

    pub fn record_hit(&self) {
        self.hits.fetch_add(1, Ordering::Relaxed);
    }

    pub fn record_miss(&self) {
        self.misses.fetch_add(1, Ordering::Relaxed);
    }

    pub fn record_stale_hit(&self) {
        self.hits.fetch_add(1, Ordering::Relaxed);
        self.stale_hits.fetch_add(1, Ordering::Relaxed);
    }

    pub fn record_eviction(&self) {
        self.evictions.fetch_add(1, Ordering::Relaxed);
    }

    pub fn record_admission_rejected(&self) {
        self.admissions_rejected.fetch_add(1, Ordering::Relaxed);
    }

    pub fn snapshot(&self) -> DnsCacheMetrics {
        DnsCacheMetrics {
            hits: self.hits.load(Ordering::Relaxed),
            misses: self.misses.load(Ordering::Relaxed),
            stale_hits: self.stale_hits.load(Ordering::Relaxed),
            evictions: self.evictions.load(Ordering::Relaxed),
            admissions_rejected: self.admissions_rejected.load(Ordering::Relaxed),
        }
    }
}

/// 4-bit 4-hash Count-Min Sketch frequency estimator with periodic aging/halving.
///
/// Packed 2 counters per byte (nibbles 0..=15).
/// Seeds implement 4 independent hash functions via Kirsch-Mitzenmacher double-hashing.
#[derive(Clone, Debug)]
pub struct CountMinSketch {
    table: Vec<u8>,
    columns: usize,
    mask: usize,
    additions: usize,
    sample_size: usize,
}

impl CountMinSketch {
    const DEPTH: usize = 4;

    /// Creates a Count-Min Sketch scaled to the target cache capacity.
    pub fn new(capacity: usize) -> Self {
        let cols = capacity
            .max(64)
            .checked_next_power_of_two()
            .unwrap_or(1 << 20)
            .min(1 << 20);
        let bytes_per_row = cols / 2;
        let total_bytes = Self::DEPTH * bytes_per_row;
        Self {
            table: vec![0_u8; total_bytes],
            columns: cols,
            mask: cols - 1,
            additions: 0,
            sample_size: capacity.max(64).saturating_mul(10),
        }
    }

    /// Computes hash coordinates for row `d` in `0..4`.
    #[inline]
    fn mix64(mut z: u64) -> u64 {
        z = (z ^ (z >> 30)).wrapping_mul(0xbf58476d1ce4e5b9);
        z = (z ^ (z >> 27)).wrapping_mul(0x94d049bb133111eb);
        z ^ (z >> 31)
    }

    fn hash_index<K: Hash>(&self, key: &K, d: usize) -> (usize, usize) {
        let mut hasher = DefaultHasher::new();
        key.hash(&mut hasher);
        let h = hasher.finish();
        let h1 = Self::mix64(h);
        let h2 = Self::mix64(h ^ 0x9e3779b97f4a7c15);
        // Double hashing with full 64-bit avalanche, (h2 | 1) ensures coprime step
        let combined = h1.wrapping_add((d as u64).wrapping_mul(h2 | 1));
        let col = (combined as usize) & self.mask;

        let bytes_per_row = self.columns / 2;
        let byte_offset = d * bytes_per_row + (col / 2);
        let is_high_nibble = (col & 1) != 0;
        (byte_offset, if is_high_nibble { 4 } else { 0 })
    }

    /// Returns the estimated frequency of `key` in `0..=15`.
    pub fn estimate<K: Hash>(&self, key: &K) -> u8 {
        let mut min_val = 15u8;
        for d in 0..Self::DEPTH {
            let (offset, shift) = self.hash_index(key, d);
            let val = (self.table[offset] >> shift) & 0x0F;
            if val < min_val {
                min_val = val;
            }
        }
        min_val
    }

    /// Increments the frequency counters for `key` (saturating at 15).
    pub fn increment<K: Hash>(&mut self, key: &K) {
        for d in 0..Self::DEPTH {
            let (offset, shift) = self.hash_index(key, d);
            let val = (self.table[offset] >> shift) & 0x0F;
            if val < 15 {
                let mask = !(0x0Fu8 << shift);
                let new_val = val + 1;
                self.table[offset] = (self.table[offset] & mask) | (new_val << shift);
            }
        }
        self.additions = self.additions.saturating_add(1);
        if self.additions >= self.sample_size {
            self.decay();
        }
    }

    /// Halves all 4-bit counters across the table to decay historical frequency.
    pub fn decay(&mut self) {
        for byte in &mut self.table {
            let low = (*byte & 0x0F) >> 1;
            let high = ((*byte >> 4) & 0x0F) >> 1;
            *byte = (high << 4) | low;
        }
        self.additions = 0;
    }
}

/// One cached entry with timestamps and access statistics.
#[derive(Clone, Debug)]
pub struct CachedEntry<T> {
    pub value: T,
    pub inserted_at: Instant,
    pub expires_at: Instant,
    pub last_accessed: Instant,
    pub hit_count: u64,
}

/// In-memory DNS cache engine with W-TinyLFU Count-Min Sketch admission policy.
pub struct DnsCache<K, V> {
    pub settings: DnsCacheSettings,
    entries: HashMap<K, CachedEntry<V>>,
    insertion_order: Vec<K>,
    sketch: CountMinSketch,
    metrics: DnsCacheMetrics,
}

impl<K: Clone + Hash + Eq, V: Clone> DnsCache<K, V> {
    pub fn new(settings: DnsCacheSettings) -> Self {
        let size = settings.size;
        Self {
            settings,
            entries: HashMap::new(),
            insertion_order: Vec::new(),
            sketch: CountMinSketch::new(size),
            metrics: DnsCacheMetrics::default(),
        }
    }

    /// Records access and retrieves an entry from cache, honoring TTL and stale policy.
    pub fn get(&mut self, key: &K) -> Option<(V, bool)> {
        // Record hit in frequency sketch
        self.sketch.increment(key);

        let now = Instant::now();
        let (val, is_stale) = match self.entries.get_mut(key) {
            Some(entry) => {
                entry.last_accessed = now;
                entry.hit_count = entry.hit_count.saturating_add(1);
                let is_stale = now >= entry.expires_at;
                if is_stale && !self.settings.stale_cache {
                    self.metrics.misses = self.metrics.misses.saturating_add(1);
                    return None;
                }
                if is_stale {
                    self.metrics.hits = self.metrics.hits.saturating_add(1);
                    self.metrics.stale_hits = self.metrics.stale_hits.saturating_add(1);
                } else {
                    self.metrics.hits = self.metrics.hits.saturating_add(1);
                }
                (entry.value.clone(), is_stale)
            }
            None => {
                self.metrics.misses = self.metrics.misses.saturating_add(1);
                return None;
            }
        };
        Some((val, is_stale))
    }

    /// Inserts an entry using W-TinyLFU admission policy.
    ///
    /// When the cache is full, a candidate entry competes with the victim entry
    /// selected by the eviction queue. If the candidate frequency <= victim frequency,
    /// the candidate is REJECTED to preserve the cache working set against one-hit wonders.
    /// Inserts with an explicit effective TTL (avoids re-clamping negative TTL).
    
    pub fn insert(&mut self, key: K, value: V, raw_ttl_seconds: u32) -> bool {
        let effective_ttl = raw_ttl_seconds
            .max(self.settings.min_ttl)
            .min(self.settings.max_ttl);
        self.insert_with_ttl(key, value, effective_ttl)
    }

    pub fn insert_with_ttl(&mut self, key: K, value: V, effective_ttl_seconds: u32) -> bool {
        let now = Instant::now();
        let expires_at = now + Duration::from_secs(u64::from(effective_ttl_seconds));

        // Bug 6: If key is already in cache, update in-place without sketch pollution!
        if let Some(entry) = self.entries.get_mut(&key) {
            entry.value = value;
            entry.expires_at = expires_at;
            entry.last_accessed = now;
            return true;
        }

        // Only new candidates increment frequency sketch
        self.sketch.increment(&key);

        // If cache has space, admit directly
        if self.entries.len() < self.settings.size {
            let entry = CachedEntry {
                value,
                inserted_at: now,
                expires_at,
                last_accessed: now,
                hit_count: 1,
            };
            self.entries.insert(key.clone(), entry);
            self.insertion_order.push(key);
            return true;
        }

        // Cache is FULL: select victim
        let victim_key = self.select_victim();
        let Some(v_key) = victim_key else {
            self.metrics.admissions_rejected = self.metrics.admissions_rejected.saturating_add(1);
            return false;
        };

        // If victim is expired, evict immediately and admit candidate
        let victim_expired = self.entries.get(&v_key).is_some_and(|e| now >= e.expires_at);
        if victim_expired {
            self.evict_key(&v_key);
            self.metrics.evictions = self.metrics.evictions.saturating_add(1);
            let entry = CachedEntry {
                value,
                inserted_at: now,
                expires_at,
                last_accessed: now,
                hit_count: 1,
            };
            self.entries.insert(key.clone(), entry);
            self.insertion_order.push(key);
            return true;
        }

        // W-TinyLFU Admission Filter: compare candidate vs victim frequency
        if self.settings.algorithm == CacheAlgorithm::TinyLfu {
            let candidate_freq = self.sketch.estimate(&key);
            let victim_freq = self.sketch.estimate(&v_key);

            if candidate_freq <= victim_freq {
                // Reject candidate to prevent cache pollution from one-hit wonders!
                self.metrics.admissions_rejected = self.metrics.admissions_rejected.saturating_add(1);
                return false;
            }
        }

        // Candidate won admission: evict victim and insert candidate
        self.evict_key(&v_key);
        self.metrics.evictions = self.metrics.evictions.saturating_add(1);
        let entry = CachedEntry {
            value,
            inserted_at: now,
            expires_at,
            last_accessed: now,
            hit_count: 1,
        };
        self.entries.insert(key.clone(), entry);
        self.insertion_order.push(key);
        true
    }

    /// Selects a victim key according to the active eviction strategy.
    fn select_victim(&self) -> Option<K> {
        if self.entries.is_empty() {
            return None;
        }
        match self.settings.algorithm {
            CacheAlgorithm::TinyLfu | CacheAlgorithm::Lru => {
                self.entries
                    .iter()
                    .min_by_key(|(_, entry)| entry.last_accessed)
                    .map(|(k, _)| k.clone())
            }
            CacheAlgorithm::Lfu => {
                self.entries
                    .iter()
                    .min_by_key(|(_, entry)| entry.hit_count)
                    .map(|(k, _)| k.clone())
            }
            CacheAlgorithm::Fifo | CacheAlgorithm::Arc => {
                self.insertion_order.first().cloned()
            }
        }
    }

    /// Evicts a specific key from the cache and queue.
    fn evict_key(&mut self, key: &K) {
        self.entries.remove(key);
        self.insertion_order.retain(|k| k != key);
    }

    /// Removes a key from the cache, returning its value if present.
    pub fn remove(&mut self, key: &K) -> Option<V> {
        self.insertion_order.retain(|k| k != key);
        self.entries.remove(key).map(|entry| entry.value)
    }

    /// Whether a key exists in the cache.
    pub fn contains_key(&self, key: &K) -> bool {
        self.entries.contains_key(key)
    }

    /// Number of active cache entries.
    pub fn len(&self) -> usize {
        self.entries.len()
    }

    /// Whether the cache is empty.
    pub fn is_empty(&self) -> bool {
        self.entries.is_empty()
    }

    /// Clears all entries.
    pub fn clear(&mut self) {
        self.entries.clear();
        self.insertion_order.clear();
    }

    /// Returns estimated frequency of key from the Count-Min Sketch.
    pub fn estimated_frequency(&self, key: &K) -> u8 {
        self.sketch.estimate(key)
    }

    /// Returns current snapshot of metrics.
    pub fn metrics(&self) -> DnsCacheMetrics {
        self.metrics
    }
}

/// Result of a cache lookup query on `SharedDnsCache`.
#[derive(Clone, Debug, Eq, PartialEq)]
pub enum CacheLookupResult {
    /// Fresh, active answer. `needs_prefetch` indicates remaining TTL <= 10%.
    Fresh {
        value: DnsCacheEntryValue,
        needs_prefetch: bool,
    },
    /// Stale answer under RFC 8767 (expired, but within allowable stale window).
    Stale {
        value: DnsCacheEntryValue,
    },
    /// Cache miss (not present or passed the stale window).
    Miss,
}

/// Thread-safe concurrent DNS cache wrapper.
#[derive(Clone)]
pub struct SharedDnsCache {
    inner: Arc<RwLock<DnsCache<DnsCacheKey, DnsCacheEntryValue>>>,
    metrics: Arc<AtomicDnsCacheMetrics>,
    stale_window_secs: u32,
}

impl Default for SharedDnsCache {
    fn default() -> Self {
        Self::new(DnsCacheSettings::default())
    }
}

impl SharedDnsCache {
    /// Creates a thread-safe shared cache with default stale window (3600s).
    pub fn new(settings: DnsCacheSettings) -> Self {
        let stale_window = settings.stale_window;
        Self {
            inner: Arc::new(RwLock::new(DnsCache::new(settings))),
            metrics: Arc::new(AtomicDnsCacheMetrics::new()),
            stale_window_secs: stale_window,
        }
    }

    /// Sets a custom stale window in seconds.
    #[must_use]
    pub fn with_stale_window(mut self, window_secs: u32) -> Self {
        self.stale_window_secs = window_secs;
        self
    }

    /// Performs a concurrent lookup, updating atomic metrics and returning typed result.
    pub fn lookup(&self, key: &DnsCacheKey) -> CacheLookupResult {
        let mut guard = match self.inner.write() {
            Ok(g) => g,
            Err(p) => p.into_inner(),
        };

        match guard.get(key) {
            Some((val, is_stale)) => {
                if !is_stale {
                    self.metrics.record_hit();
                    let needs_prefetch = val.needs_prefetch();
                    CacheLookupResult::Fresh {
                        value: val,
                        needs_prefetch,
                    }
                } else if !val.is_dead() {
                    self.metrics.record_stale_hit();
                    CacheLookupResult::Stale { value: val }
                } else {
                    self.metrics.record_miss();
                    CacheLookupResult::Miss
                }
            }
            None => {
                self.metrics.record_miss();
                CacheLookupResult::Miss
            }
        }
    }

    /// Inserts or updates an entry into the cache using W-TinyLFU admission.
    pub fn insert(
        &self,
        key: DnsCacheKey,
        data: DnsAnswerData,
        raw_ttl_seconds: u32,
    ) -> bool {
        let mut guard = match self.inner.write() {
            Ok(g) => g,
            Err(p) => p.into_inner(),
        };

        let effective_ttl = if data.is_negative() {
            raw_ttl_seconds
                .min(guard.settings.negative_ttl)
                .max(1)
        } else {
            raw_ttl_seconds
                .max(guard.settings.min_ttl)
                .min(guard.settings.max_ttl)
        };

        let entry = DnsCacheEntryValue::new(data, effective_ttl, self.stale_window_secs);
        let admitted = guard.insert_with_ttl(key, entry, effective_ttl);
        if !admitted {
            self.metrics.record_admission_rejected();
        }
        admitted
    }

    /// Inserts a pre-constructed `DnsCacheEntryValue`.
    pub fn insert_entry(&self, key: DnsCacheKey, entry: DnsCacheEntryValue) -> bool {
        let mut guard = match self.inner.write() {
            Ok(g) => g,
            Err(p) => p.into_inner(),
        };
        let ttl = entry.raw_ttl;
        let admitted = guard.insert(key, entry, ttl);
        if !admitted {
            self.metrics.record_admission_rejected();
        }
        admitted
    }

    /// Convenience helper for positive IP address answers.
    pub fn put_ips(
        &self,
        record_type: DnsRecordType,
        name: &str,
        ips: Vec<IpAddr>,
        raw_ttl_seconds: u32,
        ecs: Option<String>,
    ) -> bool {
        let key = DnsCacheKey::new(record_type, name, ecs);
        self.insert(key, DnsAnswerData::Ips(ips), raw_ttl_seconds)
    }

    /// Convenience helper for CNAME answers.
    pub fn put_cname(
        &self,
        name: &str,
        target: &str,
        raw_ttl_seconds: u32,
        ecs: Option<String>,
    ) -> bool {
        let key = DnsCacheKey::new(DnsRecordType::CNAME, name, ecs);
        self.insert(key, DnsAnswerData::Cname(target.to_owned()), raw_ttl_seconds)
    }

    /// Convenience helper for negative answers (RFC 2308).
    pub fn put_negative(
        &self,
        record_type: DnsRecordType,
        name: &str,
        is_nxdomain: bool,
        raw_ttl_seconds: u32,
        ecs: Option<String>,
    ) -> bool {
        let key = DnsCacheKey::new(record_type, name, ecs);
        let data = if is_nxdomain {
            DnsAnswerData::NxDomain
        } else {
            DnsAnswerData::NoData
        };
        self.insert(key, data, raw_ttl_seconds)
    }

    /// Clears the shared cache.
    pub fn clear(&self) {
        let mut guard = match self.inner.write() {
            Ok(g) => g,
            Err(p) => p.into_inner(),
        };
        guard.clear();
    }

    /// Current number of cached items.
    pub fn len(&self) -> usize {
        let guard = match self.inner.read() {
            Ok(g) => g,
            Err(p) => p.into_inner(),
        };
        guard.len()
    }

    /// Whether the cache is empty.
    pub fn is_empty(&self) -> bool {
        self.len() == 0
    }

    /// Returns unified metrics snapshot (merging atomic hit/miss with inner evictions).
    pub fn metrics(&self) -> DnsCacheMetrics {
        let mut snap = self.metrics.snapshot();
        if let Ok(guard) = self.inner.read() {
            snap.evictions = guard.metrics().evictions;
            snap.admissions_rejected = guard.metrics().admissions_rejected.max(snap.admissions_rejected);
        }
        snap
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::net::Ipv4Addr;

    #[test]
    fn count_min_sketch_saturation_and_decay() {
        let mut cms = CountMinSketch::new(64);
        let key = "example.com";

        for _ in 0..20 {
            cms.increment(&key);
        }
        // Saturates at 15
        assert_eq!(cms.estimate(&key), 15);

        // Decay halves counters: 15 >> 1 = 7
        cms.decay();
        assert_eq!(cms.estimate(&key), 7);

        cms.decay();
        assert_eq!(cms.estimate(&key), 3);
    }

    #[test]
    fn tinylfu_admission_filter_rejects_one_hit_wonder() {
        let mut settings = DnsCacheSettings::default();
        settings.size = 2;
        settings.algorithm = CacheAlgorithm::TinyLfu;
        settings.min_ttl = 300;
        let mut cache = DnsCache::new(settings);

        // Insert two items and build up high frequency
        cache.insert("popular_a.com", "1.1.1.1", 300);
        cache.insert("popular_b.com", "2.2.2.2", 300);

        for _ in 0..10 {
            cache.get(&"popular_a.com");
            cache.get(&"popular_b.com");
        }

        // A one-hit wonder arrives: frequency = 1
        let admitted = cache.insert("one_hit.com", "9.9.9.9", 300);

        // One-hit wonder must be REJECTED!
        assert!(!admitted, "one-hit wonder must be rejected by TinyLFU filter");
        assert!(cache.get(&"one_hit.com").is_none());
        assert!(cache.get(&"popular_a.com").is_some());
        assert!(cache.get(&"popular_b.com").is_some());
    }

    #[test]
    fn tinylfu_admission_filter_admits_frequent_candidate() {
        let mut settings = DnsCacheSettings::default();
        settings.size = 2;
        settings.algorithm = CacheAlgorithm::TinyLfu;
        settings.min_ttl = 300;
        let mut cache = DnsCache::new(settings);

        cache.insert("item_a.com", "1.1.1.1", 300);
        cache.insert("item_b.com", "2.2.2.2", 300);

        // Touch item_a once, item_b not touched
        cache.get(&"item_a.com");

        // Simulate frequent accesses to candidate before insertion
        for _ in 0..8 {
            cache.sketch.increment(&"hot_new.com");
        }

        // Candidate frequency (8) > victim frequency (1) -> Admitted!
        let admitted = cache.insert("hot_new.com", "3.3.3.3", 300);
        assert!(admitted, "high frequency candidate must win admission");
        assert!(cache.get(&"hot_new.com").is_some());
    }

    #[test]
    fn tinylfu_admits_when_victim_is_expired() {
        let mut settings = DnsCacheSettings::default();
        settings.size = 1;
        settings.algorithm = CacheAlgorithm::TinyLfu;
        settings.min_ttl = 0; // Allow 0s TTL
        let mut cache = DnsCache::new(settings);

        cache.insert("old.com", "1.1.1.1", 0);
        std::thread::sleep(Duration::from_millis(5));

        // Even with frequency 1, candidate replaces expired victim
        let admitted = cache.insert("fresh.com", "2.2.2.2", 300);
        assert!(admitted);
        assert!(cache.get(&"fresh.com").is_some());
    }

    #[test]
    fn cross_type_isolation_prevents_cache_pollution() {
        let shared = SharedDnsCache::new(DnsCacheSettings::default());

        let ip_v4 = IpAddr::V4(Ipv4Addr::new(93, 184, 216, 34));
        shared.put_ips(DnsRecordType::A, "example.com", vec![ip_v4], 300, None);

        // Query for A must hit
        let key_a = DnsCacheKey::a("example.com");
        let res_a = shared.lookup(&key_a);
        assert!(matches!(res_a, CacheLookupResult::Fresh { .. }));

        // Query for AAAA must MISS (no cross-type aliasing!)
        let key_aaaa = DnsCacheKey::aaaa("example.com");
        let res_aaaa = shared.lookup(&key_aaaa);
        assert_eq!(res_aaaa, CacheLookupResult::Miss);

        // Query for HTTPS must MISS
        let key_https = DnsCacheKey::https("example.com");
        let res_https = shared.lookup(&key_https);
        assert_eq!(res_https, CacheLookupResult::Miss);
    }

    #[test]
    fn ecs_partitioning_isolates_client_subnets() {
        let shared = SharedDnsCache::new(DnsCacheSettings::default());

        let ip_bj = IpAddr::V4(Ipv4Addr::new(1, 1, 1, 1));
        let ip_sh = IpAddr::V4(Ipv4Addr::new(2, 2, 2, 2));

        shared.put_ips(DnsRecordType::A, "cdn.com", vec![ip_bj], 300, Some("114.114.1.0/24".to_owned()));
        shared.put_ips(DnsRecordType::A, "cdn.com", vec![ip_sh], 300, Some("114.114.2.0/24".to_owned()));

        let key_bj = DnsCacheKey::new(DnsRecordType::A, "cdn.com", Some("114.114.1.0/24".to_owned()));
        let key_sh = DnsCacheKey::new(DnsRecordType::A, "cdn.com", Some("114.114.2.0/24".to_owned()));
        let key_none = DnsCacheKey::a("cdn.com");

        let lookup_bj = shared.lookup(&key_bj);
        if let CacheLookupResult::Fresh { value, .. } = lookup_bj {
            assert_eq!(value.data.ips(), Some(&[ip_bj][..]));
        } else {
            panic!("expected fresh hit for Beijing ECS");
        }

        let lookup_sh = shared.lookup(&key_sh);
        if let CacheLookupResult::Fresh { value, .. } = lookup_sh {
            assert_eq!(value.data.ips(), Some(&[ip_sh][..]));
        } else {
            panic!("expected fresh hit for Shanghai ECS");
        }

        assert_eq!(shared.lookup(&key_none), CacheLookupResult::Miss);
    }

    #[test]
    fn rfc2308_negative_caching_nxdomain_and_nodata() {
        let mut settings = DnsCacheSettings::default();
        settings.negative_ttl = 15;
        let shared = SharedDnsCache::new(settings);

        shared.put_negative(DnsRecordType::A, "nonexistent.org", true, 300, None);

        let key = DnsCacheKey::a("nonexistent.org");
        match shared.lookup(&key) {
            CacheLookupResult::Fresh { value, .. } => {
                assert!(value.data.is_negative());
                assert_eq!(value.data, DnsAnswerData::NxDomain);
                assert!(value.raw_ttl <= 15, "negative TTL must be clamped to negative_ttl setting");
            }
            other => panic!("expected negative fresh hit, got {other:?}"),
        }
    }

    #[test]
    fn rfc8767_stale_while_revalidate_and_prefetch() {
        let mut settings = DnsCacheSettings::default();
        settings.min_ttl = 0;
        settings.stale_cache = true;
        // 1 second stale window
        let shared = SharedDnsCache::new(settings).with_stale_window(1);

        let key = DnsCacheKey::a("stale-test.com");
        // Effective TTL = 0 -> immediately expired
        shared.insert(key.clone(), DnsAnswerData::Cname("target.com".to_owned()), 0);

        std::thread::sleep(Duration::from_millis(5));

        // Expired but within 1-second stale window -> Stale hit!
        match shared.lookup(&key) {
            CacheLookupResult::Stale { value } => {
                assert_eq!(value.data.cname(), Some("target.com"));
                assert!(value.is_expired());
                assert!(value.is_stale());
            }
            other => panic!("expected Stale result, got {other:?}"),
        }

        // Test prefetch threshold on non-expired entry
        let fresh_entry = DnsCacheEntryValue::new(
            DnsAnswerData::Ips(vec![IpAddr::V4(Ipv4Addr::new(1, 2, 3, 4))]),
            100, // 100 seconds initial TTL
            3600,
        );
        // At 100s remaining, 100 > 10, prefetch false
        assert!(!fresh_entry.needs_prefetch());

        // Construct near-expiry entry (5 seconds left)
        let mut near_expiry = DnsCacheEntryValue::new(
            DnsAnswerData::Ips(vec![IpAddr::V4(Ipv4Addr::new(1, 2, 3, 4))]),
            100,
            3600,
        );
        near_expiry.expires_at = Instant::now() + Duration::from_secs(5);
        // 5 <= 10 -> needs_prefetch true!
        assert!(near_expiry.needs_prefetch());
    }

    #[test]
    fn shared_dns_cache_concurrent_multithreaded() {
        use std::thread;

        let shared = SharedDnsCache::new(DnsCacheSettings::default());

        // Pre-populate some entries
        for i in 0..10 {
            let name = format!("domain-{i}.com");
            let ip = IpAddr::V4(Ipv4Addr::new(10, 0, 0, i as u8));
            shared.put_ips(DnsRecordType::A, &name, vec![ip], 300, None);
        }

        let mut handles = Vec::new();
        for t in 0..4 {
            let cache_clone = shared.clone();
            handles.push(thread::spawn(move || {
                for i in 0..25 {
                    let hit_key = DnsCacheKey::a(format!("domain-{}.com", i % 10));
                    let _ = cache_clone.lookup(&hit_key);

                    let miss_key = DnsCacheKey::aaaa(format!("domain-{}.com", i % 10));
                    let _ = cache_clone.lookup(&miss_key);

                    if t == 0 && i % 5 == 0 {
                        let dynamic_key = DnsCacheKey::a(format!("dynamic-{i}.com"));
                        let ip = IpAddr::V4(Ipv4Addr::new(192, 168, 0, i as u8));
                        cache_clone.put_ips(DnsRecordType::A, &dynamic_key.name, vec![ip], 300, None);
                    }
                }
            }));
        }

        for h in handles {
            h.join().unwrap();
        }

        let metrics = shared.metrics();
        assert!(metrics.hits > 0, "must record cache hits");
        assert!(metrics.misses > 0, "must record cache misses");
        assert!(metrics.hit_rate() > 0.0 && metrics.hit_rate() <= 1.0);
    }
}
