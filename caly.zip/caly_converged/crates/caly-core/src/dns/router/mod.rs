pub mod leak_check;
//! Smart DNS split routing and anti-pollution decision rules.

use std::collections::HashMap;

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum DnsRouteTarget {
    Direct,
    Proxy,
    Fallback,
    Reject,
}

/// Rule-based router directing queries to optimal upstream groups.
#[derive(Clone, Debug, Default)]
pub struct SmartDnsRouter {
    rules: HashMap<String, DnsRouteTarget>,
    default_target: Option<DnsRouteTarget>,
}

impl SmartDnsRouter {
    pub fn new() -> Self {
        Self {
            rules: HashMap::new(),
            default_target: Some(DnsRouteTarget::Fallback),
        }
    }

    pub fn add_rule(&mut self, pattern: &str, target: DnsRouteTarget) {
        let norm = pattern.trim().trim_end_matches('.').to_ascii_lowercase();
        self.rules.insert(norm, target);
    }

    pub fn route(&self, domain: &str) -> DnsRouteTarget {
        let norm = domain.trim().trim_end_matches('.').to_ascii_lowercase();
        if let Some(&target) = self.rules.get(&norm) {
            return target;
        }
        // Subdomain matching
        for (pattern, &target) in &self.rules {
            if norm.ends_with(&format!(".{pattern}")) {
                return target;
            }
        }
        self.default_target.unwrap_or(DnsRouteTarget::Fallback)
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_dns_router() {
        let mut router = SmartDnsRouter::new();
        router.add_rule("cn", DnsRouteTarget::Direct);
        router.add_rule("google.com", DnsRouteTarget::Proxy);
        router.add_rule("ad.tracker.net", DnsRouteTarget::Reject);

        assert_eq!(router.route("baidu.cn"), DnsRouteTarget::Direct);
        assert_eq!(router.route("mail.google.com"), DnsRouteTarget::Proxy);
        assert_eq!(router.route("ad.tracker.net"), DnsRouteTarget::Reject);
        assert_eq!(router.route("unknown-service.org"), DnsRouteTarget::Fallback);
    }
}

pub use leak_check::{DnsLeakAuditReport, DnsLeakDetector, DnsLeakVerdict};
