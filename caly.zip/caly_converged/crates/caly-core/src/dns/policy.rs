//! Domain-based nameserver steering policies and resolution strategy settings.
//!
//! Enables routing specific domain patterns or GeoSite categories to dedicated
//! upstream nameservers (Mihomo `nameserver-policy` and sing-box `dns.rules`).

use std::collections::BTreeMap;
use serde::{Deserialize, Serialize};
use super::nameserver::Nameserver;

/// DNS resolution IP preference strategy.
#[derive(Clone, Copy, Debug, Default, Eq, PartialEq, Serialize, Deserialize)]
#[serde(rename_all = "snake_case")]
pub enum ResolveStrategy {
    /// Return IPv4 addresses first, fallback to IPv6.
    #[default]
    PreferIpv4,
    /// Return IPv6 addresses first, fallback to IPv4.
    PreferIpv6,
    /// Query and return IPv4 addresses only (drop AAAA).
    Ipv4Only,
    /// Query and return IPv6 addresses only (drop A).
    Ipv6Only,
}

impl ResolveStrategy {
    pub const fn label(self) -> &'static str {
        match self {
            Self::PreferIpv4 => "prefer_ipv4",
            Self::PreferIpv6 => "prefer_ipv6",
            Self::Ipv4Only => "ipv4_only",
            Self::Ipv6Only => "ipv6_only",
        }
    }

    pub fn from_label(label: &str) -> Option<Self> {
        match label.to_ascii_lowercase().as_str() {
            "prefer_ipv4" | "prefer-ipv4" => Some(Self::PreferIpv4),
            "prefer_ipv6" | "prefer-ipv6" => Some(Self::PreferIpv6),
            "ipv4_only" | "ipv4-only" => Some(Self::Ipv4Only),
            "ipv6_only" | "ipv6-only" => Some(Self::Ipv6Only),
            _ => None,
        }
    }
}

/// A policy mapping domain patterns or GeoSite tags to specific upstream nameservers.
#[derive(Clone, Debug, Default, Eq, PartialEq, Serialize, Deserialize)]
pub struct NameserverPolicy {
    /// Mapping: pattern (e.g. `geosite:cn`, `*.corp.net`, `example.com`) to nameservers.
    pub policies: BTreeMap<String, Vec<Nameserver>>,
}

impl NameserverPolicy {
    pub fn new() -> Self {
        Self {
            policies: BTreeMap::new(),
        }
    }

    pub fn insert(&mut self, pattern: impl Into<String>, servers: Vec<Nameserver>) {
        self.policies.insert(pattern.into(), servers);
    }

    pub fn get(&self, pattern: &str) -> Option<&[Nameserver]> {
        self.policies.get(pattern).map(|v| v.as_slice())
    }

    pub fn is_empty(&self) -> bool {
        self.policies.is_empty()
    }

    pub fn len(&self) -> usize {
        self.policies.len()
    }
}
