//! DNS capability crate: the bounded model (settings, filters, structured
//! nameserver values) plus caching engine, static hosts, steering policies,
//! advanced record types, DNSSEC/ECS options, security filters,
//! the reachability probe and its wire codec.

#![forbid(unsafe_code)]
#![cfg_attr(test, allow(clippy::unwrap_used, clippy::expect_used, clippy::panic, clippy::todo, clippy::unimplemented, clippy::unreachable))]

pub mod advanced;
pub mod fakeip;
pub mod upstream;
pub mod router;
pub mod cache;
mod filter;
pub mod hosts;
mod nameserver;
pub mod policy;
pub mod probe;
mod settings;

pub use advanced::{
    CnameFlattener, DnsRecordType, DnsSecurityFilter, EcsPolicy, Edns0Options,
    RecursiveTraceHop, reverse_dns_ptr_name,
};
pub use cache::{CacheAlgorithm, CachedEntry, DnsCache, DnsCacheSettings};
pub use filter::{
    DNS_LISTEN_MAX_BYTES, DNS_PATTERN_MAX_BYTES, DnsFilterError, DnsPattern, FallbackFilter,
    MAX_DNS_FILTER_ENTRIES,
};
pub use hosts::{DnsHosts, HostTarget, MAX_HOSTS_ENTRIES};
pub use nameserver::{
    DNS_TEXT_MAX_BYTES, FAKE_IP_RANGE_MAX_BYTES, FakeIpRange, FakeIpRangeError, Nameserver,
    NameserverError, NameserverKind, NameserverShape,
};
pub use policy::{NameserverPolicy, ResolveStrategy};
pub use settings::{
    DnsError, DnsMode, DnsSettings, DnsSettingsBuilder, MAX_DNS_SERVERS, default_tun_dns,
};
pub use probe::{
    DnsAnswerData, DnsProbeOutcome, DnsProbeReport, DnsRecordAnswer, DnsRecordProbeOutcome,
    build_query_typed, parse_record_answers, probe_nameserver, probe_nameserver_record,
    probe_nameserver_timed,
};

pub use fakeip::{FakeIpEngine, FakeIpRecord, RealFakeIpEngine, FakeIpFilter};
pub use upstream::{CircuitBreaker, HappyEyeballsRacing, UpstreamStats};
pub use router::{DnsLeakAuditReport, DnsLeakDetector, DnsLeakVerdict, DnsRouteTarget, SmartDnsRouter};
