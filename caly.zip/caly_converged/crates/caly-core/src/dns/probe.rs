//! Bounded DNS reachability probe plus multi-record wire codec.
//!
//! Features:
//! - Multi-record type encoding and decoding: A, AAAA, CNAME, TXT, PTR, HTTPS / SVCB.
//! - RFC 7766: Automatic TCP fallback when UDP response is truncated (TC bit set).
//! - RFC 6891: EDNS0 OPT RR appending with configurable payload size (1232) & DNSSEC DO bit.
//! - Comprehensive wire parsing for diagnostics and nameserver reachability testing.

use std::{
    io::{self, Read, Write},
    net::{IpAddr, Ipv4Addr, Ipv6Addr, SocketAddr, TcpStream, ToSocketAddrs, UdpSocket},
    time::Duration,
};

use crate::dns::advanced::{DnsRecordType, Edns0Options};
use crate::nameserver::{Nameserver, NameserverKind};

/// Default DNS service port when a nameserver has no explicit port.
pub const DNS_DEFAULT_PORT: u16 = 53;
/// Reasonable per-attempt read timeout.
pub const DNS_PROBE_TIMEOUT: Duration = Duration::from_secs(3);

/// Classified result of a single nameserver probe (backward compatible).
#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub enum DnsProbeOutcome {
    /// The resolver answered with a usable (no-error) response, optionally
    /// carrying the first A or AAAA record address from the answer section.
    Resolved(Option<IpAddr>),
    /// Authoritative domain non-existence (NXDOMAIN, RCODE=3).
    NxDomain,
    /// Server failure upstream (SERVFAIL, RCODE=2).
    ServFail,
    /// The resolver refused the query (REFUSED, RCODE=5).
    Refused,
    /// No response arrived within the timeout.
    Timeout,
    /// The transport is unsupported (e.g. `quic://` or `local` pseudo-server).
    UnsupportedTransport,
    /// The nameserver/domain input was invalid or the socket failed.
    Error,
}

/// Parsed resource record answer data.
#[derive(Clone, Debug, Eq, PartialEq)]
pub enum DnsAnswerData {
    /// A record (IPv4 address).
    A(Ipv4Addr),
    /// AAAA record (IPv6 address).
    AAAA(Ipv6Addr),
    /// CNAME record (canonical domain name).
    Cname(String),
    /// TXT record (list of text chunks).
    Txt(Vec<String>),
    /// PTR record (reverse domain name).
    Ptr(String),
    /// HTTPS / SVCB record (priority, target name, wire params).
    Https {
        priority: u16,
        target: String,
        params: Vec<u8>,
    },
    /// Other record types (raw rtype and rdata).
    Other {
        rtype: u16,
        data: Vec<u8>,
    },
}

/// Single parsed answer record from a DNS response.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct DnsRecordAnswer {
    pub name: String,
    pub rtype: DnsRecordType,
    pub ttl: u32,
    pub data: DnsAnswerData,
}

/// Outcome of a multi-record probe.
#[derive(Clone, Debug, Eq, PartialEq)]
pub enum DnsRecordProbeOutcome {
    /// Resolved with matching records (and DNSSEC AD flag).
    Resolved {
        records: Vec<DnsRecordAnswer>,
        authenticated_data: bool,
    },
    /// Server returned non-zero RCODE (e.g. NXDOMAIN / SERVFAIL / REFUSED).
    Refused,
    /// Timeout waiting for response.
    Timeout,
    /// Response was truncated (if TCP fallback disabled or failed).
    Truncated,
    /// Transport unsupported.
    UnsupportedTransport,
    /// Socket / Network error.
    Error,
}

/// One probe exchange: the classified outcome plus its wall-clock latency.
#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub struct DnsProbeReport {
    pub outcome: DnsProbeOutcome,
    pub latency: Duration,
}

/// Probes one nameserver for the given hostname, returning standard DnsProbeOutcome.
pub fn probe_nameserver(
    nameserver: &str,
    domain: &str,
    timeout: Duration,
    transaction_id: [u8; 2],
) -> DnsProbeOutcome {
    let outcome = probe_nameserver_record(
        nameserver,
        domain,
        DnsRecordType::A,
        timeout,
        transaction_id,
    );
    match outcome {
        DnsRecordProbeOutcome::Resolved { records, .. } => {
            let first_ip = records.iter().find_map(|r| match &r.data {
                DnsAnswerData::A(ip) => Some(IpAddr::V4(*ip)),
                DnsAnswerData::AAAA(ip) => Some(IpAddr::V6(*ip)),
                _ => None,
            });
            DnsProbeOutcome::Resolved(first_ip)
        }
        DnsRecordProbeOutcome::NxDomain => DnsProbeOutcome::NxDomain,
        DnsRecordProbeOutcome::ServFail => DnsProbeOutcome::ServFail,
        DnsRecordProbeOutcome::Refused => DnsProbeOutcome::Refused,
        DnsRecordProbeOutcome::Timeout => DnsProbeOutcome::Timeout,
        DnsRecordProbeOutcome::Truncated => DnsProbeOutcome::Resolved(None),
        DnsRecordProbeOutcome::UnsupportedTransport => DnsProbeOutcome::UnsupportedTransport,
        DnsRecordProbeOutcome::Error => DnsProbeOutcome::Error,
    }
}

/// Probes one nameserver for the given hostname and record type.
pub fn probe_nameserver_record(
    nameserver: &str,
    domain: &str,
    record_type: DnsRecordType,
    timeout: Duration,
    transaction_id: [u8; 2],
) -> DnsRecordProbeOutcome {
    let Ok(server) = Nameserver::new(nameserver) else {
        return DnsRecordProbeOutcome::Error;
    };
    let edns = Edns0Options {
        udp_payload_size: 1232,
        dnssec_ok: true,
        ecs_policy: crate::dns::advanced::EcsPolicy::Forward,
    };
    match server.kind() {
        NameserverKind::Udp => probe_udp_record(server.address(), domain, record_type, timeout, transaction_id, Some(&edns)),
        NameserverKind::Tcp => probe_tcp_record(server.address(), domain, record_type, timeout, transaction_id, Some(&edns)),
        NameserverKind::Tls => probe_dot_record(server.address(), domain, record_type, timeout, transaction_id, Some(&edns)),
        NameserverKind::Https => probe_doh_record(nameserver, domain, record_type, timeout, transaction_id, Some(&edns)),
        NameserverKind::Local | NameserverKind::Quic => DnsRecordProbeOutcome::UnsupportedTransport,
    }
}

/// Probes one nameserver, also reporting round-trip latency.
pub fn probe_nameserver_timed(
    nameserver: &str,
    domain: &str,
    timeout: Duration,
    transaction_id: [u8; 2],
) -> DnsProbeReport {
    let started = std::time::Instant::now();
    let outcome = probe_nameserver(nameserver, domain, timeout, transaction_id);
    DnsProbeReport {
        outcome,
        latency: started.elapsed(),
    }
}

/// UDP probe with RFC 7766 TCP Fallback on Truncation (TC bit).
fn probe_udp_record(
    nameserver: &str,
    domain: &str,
    record_type: DnsRecordType,
    timeout: Duration,
    transaction_id: [u8; 2],
    edns: Option<&Edns0Options>,
) -> DnsRecordProbeOutcome {
    let started = std::time::Instant::now();
    let address = match resolve_for_probe(nameserver, timeout) {
        Ok(address) => address,
        Err(outcome) => return map_legacy_outcome(outcome),
    };
    let Ok(query) = build_query_typed(domain, record_type, transaction_id, edns) else {
        return DnsRecordProbeOutcome::Error;
    };
    let bind_address: SocketAddr = if address.is_ipv6() {
        SocketAddr::new(IpAddr::V6(std::net::Ipv6Addr::UNSPECIFIED), 0)
    } else {
        SocketAddr::new(IpAddr::V4(std::net::Ipv4Addr::UNSPECIFIED), 0)
    };
    let Ok(socket) = UdpSocket::bind(bind_address) else {
        return DnsRecordProbeOutcome::Error;
    };
    if socket.connect(address).is_err() {
        return DnsRecordProbeOutcome::Error;
    }
    if socket.send(&query).is_err() {
        return DnsRecordProbeOutcome::Error;
    }
    let deadline = started + timeout;
    let mut buffer = [0u8; 4096];
    loop {
        let remaining = deadline.saturating_duration_since(std::time::Instant::now());
        if remaining.is_zero() {
            return DnsRecordProbeOutcome::Timeout;
        }
        if socket.set_read_timeout(Some(remaining)).is_err() {
            return DnsRecordProbeOutcome::Error;
        }
        match socket.recv(&mut buffer) {
            Ok(read) => {
                let response = &buffer[..read];
                if response.len() < 12 || query.len() < 2 {
                    continue;
                }
                if response[0] != query[0] || response[1] != query[1] {
                    continue;
                }
                if response[2] & 0x80 == 0 {
                    // Not a response (QR = 0)
                    continue;
                }
                // RFC 7766: Check TC (Truncated) bit in byte 2 (0x02)
                if (response[2] & 0x02) != 0 {
                    let tcp_remaining = deadline.saturating_duration_since(std::time::Instant::now());
                    if tcp_remaining.is_zero() {
                        return DnsRecordProbeOutcome::Truncated;
                    }
                    // Fall back to TCP immediately with ALREADY RESOLVED address (Bug 5)
                    return probe_tcp_record_addr(address, domain, record_type, tcp_remaining, transaction_id, edns);
                }
                let rcode = response[3] & 0x0f;
                if let Some(err_outcome) = map_wire_rcode(rcode) {
                    return err_outcome;
                }
                let authenticated_data = (response[3] & 0x20) != 0;
                let records = parse_record_answers(response).unwrap_or_default();
                return DnsRecordProbeOutcome::Resolved {
                    records,
                    authenticated_data,
                };
            }
            Err(error)
                if matches!(
                    error.kind(),
                    io::ErrorKind::WouldBlock | io::ErrorKind::TimedOut
                ) =>
            {
                return DnsRecordProbeOutcome::Timeout;
            }
            Err(_) => return DnsRecordProbeOutcome::Error,
        }
    }
}

/// TCP probe with pre-resolved address: avoids secondary DNS lookup during fallback (Bug 5).
pub fn probe_tcp_record_addr(
    address: SocketAddr,
    domain: &str,
    record_type: DnsRecordType,
    timeout: Duration,
    transaction_id: [u8; 2],
    edns: Option<&Edns0Options>,
) -> DnsRecordProbeOutcome {
    let Ok(query) = build_query_typed(domain, record_type, transaction_id, edns) else {
        return DnsRecordProbeOutcome::Error;
    };
    if timeout.is_zero() {
        return DnsRecordProbeOutcome::Timeout;
    }
    let Ok(stream) = TcpStream::connect_timeout(&address, timeout) else {
        return DnsRecordProbeOutcome::Error;
    };
    if stream.set_read_timeout(Some(timeout)).is_err()
        || stream.set_write_timeout(Some(timeout)).is_err()
    {
        return DnsRecordProbeOutcome::Error;
    }
    let mut stream = stream;
    let length = u16::try_from(query.len()).unwrap_or(0);
    if query.is_empty() || length as usize != query.len() {
        return DnsRecordProbeOutcome::Error;
    }
    let mut frame = Vec::with_capacity(query.len() + 2);
    frame.extend_from_slice(&length.to_be_bytes());
    frame.extend_from_slice(&query);
    if stream.write_all(&frame).is_err() {
        return DnsRecordProbeOutcome::Error;
    }
    let mut prefix = [0u8; 2];
    if let Err(error) = stream.read_exact(&mut prefix) {
        return map_legacy_outcome(tcp_read_outcome(&error));
    }
    let expected = u16::from_be_bytes(prefix) as usize;
    if expected == 0 {
        return DnsRecordProbeOutcome::Error;
    }
    let mut response = vec![0u8; expected];
    if let Err(error) = stream.read_exact(&mut response) {
        return map_legacy_outcome(tcp_read_outcome(&error));
    }

    if response.len() < 12 || response[0] != query[0] || response[1] != query[1] || (response[2] & 0x80 == 0) {
        return DnsRecordProbeOutcome::Error;
    }
    let rcode = response[3] & 0x0f;
    if let Some(err_outcome) = map_wire_rcode(rcode) {
        return err_outcome;
    }
    let authenticated_data = (response[3] & 0x20) != 0;
    let records = parse_record_answers(&response).unwrap_or_default();
    DnsRecordProbeOutcome::Resolved {
        records,
        authenticated_data,
    }
}

/// TCP probe: RFC 1035 §4.2.2 / RFC 7766 framing with two-octet big-endian length prefix.
fn probe_tcp_record(
    nameserver: &str,
    domain: &str,
    record_type: DnsRecordType,
    timeout: Duration,
    transaction_id: [u8; 2],
    edns: Option<&Edns0Options>,
) -> DnsRecordProbeOutcome {
    let started = std::time::Instant::now();
    let address = match resolve_for_probe(nameserver, timeout) {
        Ok(address) => address,
        Err(outcome) => return map_legacy_outcome(outcome),
    };
    let remaining = timeout.saturating_sub(started.elapsed());
    probe_tcp_record_addr(address, domain, record_type, remaining, transaction_id, edns)
}

/// Helper mapping legacy DnsProbeOutcome to DnsRecordProbeOutcome.
fn map_legacy_outcome(outcome: DnsProbeOutcome) -> DnsRecordProbeOutcome {
    match outcome {
        DnsProbeOutcome::Resolved(ip) => DnsRecordProbeOutcome::Resolved {
            records: ip.map(|i| vec![DnsRecordAnswer {
                name: String::new(),
                rtype: match i {
                    IpAddr::V4(_) => DnsRecordType::A,
                    IpAddr::V6(_) => DnsRecordType::AAAA,
                },
                ttl: 60,
                data: match i {
                    IpAddr::V4(v4) => DnsAnswerData::A(v4),
                    IpAddr::V6(v6) => DnsAnswerData::AAAA(v6),
                },
            }]).unwrap_or_default(),
            authenticated_data: false,
        },
        DnsProbeOutcome::NxDomain => DnsRecordProbeOutcome::NxDomain,
        DnsProbeOutcome::ServFail => DnsRecordProbeOutcome::ServFail,
        DnsProbeOutcome::Refused => DnsRecordProbeOutcome::Refused,
        DnsProbeOutcome::Timeout => DnsRecordProbeOutcome::Timeout,
        DnsProbeOutcome::UnsupportedTransport => DnsRecordProbeOutcome::UnsupportedTransport,
        DnsProbeOutcome::Error => DnsRecordProbeOutcome::Error,
    }
}

/// Backward-compatible internal UDP probe.
fn probe_udp(
    nameserver: &str,
    domain: &str,
    timeout: Duration,
    transaction_id: [u8; 2],
) -> DnsProbeOutcome {
    let outcome = probe_udp_record(nameserver, domain, DnsRecordType::A, timeout, transaction_id, None);
    extract_first_ip_outcome(outcome)
}

/// Backward-compatible internal TCP probe.
fn probe_tcp(
    nameserver: &str,
    domain: &str,
    timeout: Duration,
    transaction_id: [u8; 2],
) -> DnsProbeOutcome {
    let outcome = probe_tcp_record(nameserver, domain, DnsRecordType::A, timeout, transaction_id, None);
    extract_first_ip_outcome(outcome)
}

fn extract_first_ip_outcome(outcome: DnsRecordProbeOutcome) -> DnsProbeOutcome {
    match outcome {
        DnsRecordProbeOutcome::Resolved { records, .. } => {
            let first_ip = records.iter().find_map(|r| match &r.data {
                DnsAnswerData::A(ip) => Some(IpAddr::V4(*ip)),
                DnsAnswerData::AAAA(ip) => Some(IpAddr::V6(*ip)),
                _ => None,
            });
            DnsProbeOutcome::Resolved(first_ip)
        }
        DnsRecordProbeOutcome::NxDomain => DnsProbeOutcome::NxDomain,
        DnsRecordProbeOutcome::ServFail => DnsProbeOutcome::ServFail,
        DnsRecordProbeOutcome::Refused => DnsProbeOutcome::Refused,
        DnsRecordProbeOutcome::Timeout => DnsProbeOutcome::Timeout,
        DnsRecordProbeOutcome::Truncated => DnsProbeOutcome::Resolved(None),
        DnsRecordProbeOutcome::UnsupportedTransport => DnsProbeOutcome::UnsupportedTransport,
        DnsRecordProbeOutcome::Error => DnsProbeOutcome::Error,
    }
}

/// Maps a TCP read failure onto Timeout or Error.
fn tcp_read_outcome(error: &io::Error) -> DnsProbeOutcome {
    if matches!(
        error.kind(),
        io::ErrorKind::WouldBlock | io::ErrorKind::TimedOut
    ) {
        DnsProbeOutcome::Timeout
    } else {
        DnsProbeOutcome::Error
    }
}

/// Resolves `host[:port]` for a probe within `budget`.
fn resolve_for_probe(nameserver: &str, budget: Duration) -> Result<SocketAddr, DnsProbeOutcome> {
    parse_nameserver_within(nameserver, budget).map_err(|error| {
        if matches!(error.kind(), io::ErrorKind::TimedOut) {
            DnsProbeOutcome::Timeout
        } else {
            DnsProbeOutcome::Error
        }
    })
}

fn parse_nameserver_within(value: &str, budget: Duration) -> io::Result<SocketAddr> {
    let fallback = || io::Error::new(io::ErrorKind::InvalidInput, "invalid nameserver");
    let (host, port) = crate::nameserver::split_host_port(value).ok_or_else(fallback)?;
    parse_nameserver_with(host, port, budget, |host, port| {
        (host, port).to_socket_addrs().map(|mut i| i.next())
    })
}

fn parse_nameserver_with<R>(
    host: &str,
    port: u16,
    budget: Duration,
    resolver: R,
) -> io::Result<SocketAddr>
where
    R: FnOnce(&str, u16) -> io::Result<Option<SocketAddr>> + Send + 'static,
{
    if let Ok(ip) = host.parse::<IpAddr>() {
        return Ok(SocketAddr::new(ip, port));
    }
    let host = host.to_owned();
    let (tx, rx) = std::sync::mpsc::channel();
    std::thread::spawn(move || {
        let _ = tx.send(resolver(&host, port));
    });
    match rx.recv_timeout(budget) {
        Ok(Ok(Some(addr))) => Ok(addr),
        Ok(Ok(None)) => Err(io::Error::new(io::ErrorKind::NotFound, "no addresses")),
        Ok(Err(err)) => Err(err),
        Err(_) => Err(io::Error::new(io::ErrorKind::TimedOut, "resolution timed out")),
    }
}

/// Terminal classification function for tests and TCP fallback.
fn classify_response(query: &[u8], response: &[u8]) -> DnsProbeOutcome {
    classify_datagram(query, response).unwrap_or(DnsProbeOutcome::Error)
}

/// Datagram form: validates header and parses the first A or AAAA record.
fn classify_datagram(query: &[u8], response: &[u8]) -> Option<DnsProbeOutcome> {
    if response.len() < 12 || query.len() < 2 {
        return None;
    }
    if response[0] != query[0] || response[1] != query[1] {
        return None;
    }
    if response[2] & 0x80 == 0 {
        return None;
    }
    let rcode = response[3] & 0x0f;
    match rcode {
        0 => {},
        2 => return Some(DnsProbeOutcome::ServFail),
        3 => return Some(DnsProbeOutcome::NxDomain),
        5 => return Some(DnsProbeOutcome::Refused),
        _ => return Some(DnsProbeOutcome::Refused),
    }
    Some(DnsProbeOutcome::Resolved(parse_first_record(response)))
}

/// Extracts the first `A` or `AAAA` record address from a DNS response answer section.
fn parse_first_record(response: &[u8]) -> Option<IpAddr> {
    let answers = parse_record_answers(response)?;
    answers.into_iter().find_map(|record| match record.data {
        DnsAnswerData::A(ipv4) => Some(IpAddr::V4(ipv4)),
        DnsAnswerData::AAAA(ipv6) => Some(IpAddr::V6(ipv6)),
        _ => None,
    })
}

/// Parses all answer records from a DNS wire response.
pub fn parse_record_answers(response: &[u8]) -> Option<Vec<DnsRecordAnswer>> {
    if response.len() < 12 {
        return None;
    }
    let qdcount = u16::from_be_bytes([response[4], response[5]]) as usize;
    let ancount = u16::from_be_bytes([response[6], response[7]]) as usize;
    if ancount == 0 {
        return Some(Vec::new());
    }

    let mut offset = 12;
    for _ in 0..qdcount {
        offset = skip_question(response, offset)?;
    }

    let mut records = Vec::with_capacity(ancount);
    for _ in 0..ancount {
        let (name, name_bytes) = parse_name(response, offset)?;
        offset += name_bytes;
        if offset + 10 > response.len() {
            return None;
        }

        let rtype_code = u16::from_be_bytes([response[offset], response[offset + 1]]);
        let _rclass = u16::from_be_bytes([response[offset + 2], response[offset + 3]]);
        let ttl = u32::from_be_bytes([
            response[offset + 4],
            response[offset + 5],
            response[offset + 6],
            response[offset + 7],
        ]);
        let rdlength = u16::from_be_bytes([response[offset + 8], response[offset + 9]]) as usize;
        offset += 10;

        if offset + rdlength > response.len() {
            return None;
        }
        let rdata = &response[offset..offset + rdlength];

        let data = match rtype_code {
            1 if rdlength == 4 => DnsAnswerData::A(Ipv4Addr::new(rdata[0], rdata[1], rdata[2], rdata[3])),
            28 if rdlength == 16 => {
                let mut octets = [0u8; 16];
                octets.copy_from_slice(rdata);
                DnsAnswerData::AAAA(Ipv6Addr::from(octets))
            }
            5 => {
                let (cname, _) = parse_name(response, offset)?;
                DnsAnswerData::Cname(cname)
            }
            12 => {
                let (ptr, _) = parse_name(response, offset)?;
                DnsAnswerData::Ptr(ptr)
            }
            16 => {
                let mut txts = Vec::new();
                let mut cur = 0;
                while cur < rdata.len() {
                    let len = rdata[cur] as usize;
                    cur += 1;
                    if cur + len <= rdata.len() {
                        if let Ok(s) = core::str::from_utf8(&rdata[cur..cur + len]) {
                            txts.push(s.to_owned());
                        }
                        cur += len;
                    } else {
                        break;
                    }
                }
                DnsAnswerData::Txt(txts)
            }
            65 | 64 if rdlength >= 2 => {
                let priority = u16::from_be_bytes([rdata[0], rdata[1]]);
                let (target, target_bytes) = parse_name(response, offset + 2).unwrap_or((String::new(), 0));
                let params = if 2 + target_bytes <= rdlength {
                    rdata[2 + target_bytes..].to_vec()
                } else {
                    Vec::new()
                };
                DnsAnswerData::Https {
                    priority,
                    target,
                    params,
                }
            }
            _ => DnsAnswerData::Other {
                rtype: rtype_code,
                data: rdata.to_vec(),
            },
        };

        records.push(DnsRecordAnswer {
            name,
            rtype: DnsRecordType::from_type_code(rtype_code),
            ttl,
            data,
        });

        offset += rdlength;
    }

    Some(records)
}

/// Skips the DNS question section starting at `offset`.
fn skip_question(response: &[u8], offset: usize) -> Option<usize> {
    let after_name = skip_name(response, offset)?;
    after_name
        .checked_add(4)
        .filter(|end| *end <= response.len())
}

/// Parses a DNS name (handling compression pointers) and returns `(decompressed_name, bytes_consumed_at_offset)`.
fn parse_name(response: &[u8], mut offset: usize) -> Option<(String, usize)> {
    let mut labels = Vec::new();
    let mut hops = 0;
    let mut consumed = 0;
    let mut jumped = false;

    while offset < response.len() {
        if hops > 64 {
            return None;
        }
        let length = response[offset] as usize;
        if length == 0 {
            if !jumped {
                consumed += 1;
            }
            break;
        }
        if (length & 0xc0) == 0xc0 {
            if offset + 1 >= response.len() {
                return None;
            }
            let ptr = (((length & 0x3f) << 8) | (response[offset + 1] as usize)) as usize;
            if !jumped {
                consumed += 2;
                jumped = true;
            }
            offset = ptr;
            hops += 1;
            continue;
        }
        if offset + 1 + length > response.len() {
            return None;
        }
        let label_bytes = &response[offset + 1..offset + 1 + length];
        let label = core::str::from_utf8(label_bytes).ok()?;
        labels.push(label.to_owned());

        if !jumped {
            consumed += 1 + length;
        }
        offset += 1 + length;
    }

    Some((labels.join("."), consumed))
}

/// Skips a DNS name without allocating.
fn skip_name(response: &[u8], mut offset: usize) -> Option<usize> {
    loop {
        if offset >= response.len() {
            return None;
        }
        let length = response[offset];
        if length == 0 {
            return offset.checked_add(1);
        }
        if length & 0xc0 == 0xc0 {
            return offset.checked_add(2);
        }
        offset = offset.checked_add(1 + length as usize)?;
        if offset > response.len() {
            return None;
        }
    }
}

/// Builds a DNS query packet for any DnsRecordType with optional EDNS0 (RFC 6891) OPT RR.
pub fn build_query_typed(
    domain: &str,
    record_type: DnsRecordType,
    transaction_id: [u8; 2],
    edns: Option<&Edns0Options>,
) -> io::Result<Vec<u8>> {
    let mut query = Vec::with_capacity(64);
    query.extend_from_slice(&transaction_id);
    query.extend_from_slice(&0x0100u16.to_be_bytes()); // Recursion Desired (RD = 1)
    query.extend_from_slice(&1u16.to_be_bytes()); // QDCOUNT = 1
    query.extend_from_slice(&[0u8, 0u8, 0u8, 0u8]); // ANCOUNT = 0, NSCOUNT = 0
    let arcount: u16 = if edns.is_some() { 1 } else { 0 };
    query.extend_from_slice(&arcount.to_be_bytes()); // ARCOUNT

    let mut encoded = Vec::with_capacity(domain.len() + 2);
    for label in domain.split('.') {
        if label.is_empty() {
            continue;
        }
        if label.len() > 63 || !label.is_ascii() {
            return Err(io::Error::new(io::ErrorKind::InvalidInput, "bad label"));
        }
        let length = u8::try_from(label.len())
            .map_err(|_| io::Error::new(io::ErrorKind::InvalidInput, "bad label"))?;
        encoded.push(length);
        encoded.extend_from_slice(label.as_bytes());
    }
    encoded.push(0);
    if encoded.len() > 255 {
        return Err(io::Error::new(
            io::ErrorKind::InvalidInput,
            "domain name too long",
        ));
    }
    query.extend_from_slice(&encoded);
    query.extend_from_slice(&record_type.type_code().to_be_bytes()); // QTYPE
    query.extend_from_slice(&1u16.to_be_bytes()); // QCLASS: IN

    // Append EDNS0 (RFC 6891) OPT Record if requested
    if let Some(opts) = edns {
        query.push(0); // Root domain name
        query.extend_from_slice(&41u16.to_be_bytes()); // TYPE: OPT (41)
        query.extend_from_slice(&opts.udp_payload_size.to_be_bytes()); // CLASS: UDP payload size (1232)
        query.extend_from_slice(&[0u8, 0u8]); // Extended RCODE & Version: 0
        let flags: u16 = if opts.dnssec_ok { 0x8000 } else { 0x0000 };
        query.extend_from_slice(&flags.to_be_bytes()); // DO (DNSSEC OK) bit
        query.extend_from_slice(&0u16.to_be_bytes()); // RDLENGTH = 0
    }

    Ok(query)
}

/// Builds a minimal DNS A query (backward compatible).
fn build_query(domain: &str, transaction_id: [u8; 2]) -> io::Result<Vec<u8>> {
    build_query_typed(domain, DnsRecordType::A, transaction_id, None)
}

#[cfg(test)]
mod tests {
    use super::*;

    const TXID: [u8; 2] = [0xAB, 0xCD];

    #[test]
    fn query_contains_question_for_domain() -> Result<(), std::io::Error> {
        let query = build_query("example.com", TXID)?;
        assert_eq!(&query[0..2], TXID);
        assert_eq!(&query[12..25], b"\x07example\x03com\x00");
        Ok(())
    }

    #[test]
    fn bad_domain_label_is_rejected() {
        assert!(build_query("a..b", TXID).is_err());
        assert!(build_query(&format!("{}.com", "a".repeat(64)), TXID).is_err());
    }

    #[test]
    fn matching_transaction_classifies_resolved() -> Result<(), std::io::Error> {
        let query = build_query("example.com", TXID)?;
        let mut response = query.clone();
        response[2] = 0x81; // QR=1, RD=1
        response[3] = 0x80; // RA=1, RCODE=0
        assert_eq!(
            classify_response(&query, &response),
            DnsProbeOutcome::Resolved(None)
        );
        Ok(())
    }

    #[test]
    fn echoed_query_without_qr_bit_is_rejected() -> Result<(), std::io::Error> {
        let query = build_query("example.com", TXID)?;
        let echoed = query.clone();
        assert_eq!(classify_response(&query, &echoed), DnsProbeOutcome::Error);
        Ok(())
    }

    #[test]
    fn query_rejects_overlong_domain_and_non_ascii_label() {
        let label = "a".repeat(63);
        let domain = format!("{label}.{label}.{label}.{label}.com");
        assert!(build_query(&domain, TXID).is_err());
        assert!(build_query("exämple.com", TXID).is_err());
    }

    #[test]
    fn mismatched_transaction_is_an_error() -> Result<(), std::io::Error> {
        let query = build_query("example.com", TXID)?;
        let mut other = query.clone();
        other[0] ^= 0xff;
        other[2] = 0x81;
        assert_eq!(
            classify_response(&query, &other),
            DnsProbeOutcome::Error
        );
        Ok(())
    }

    #[test]
    fn refused_rcode_is_classified() -> Result<(), std::io::Error> {
        let query = build_query("example.com", TXID)?;
        let mut response = query.clone();
        response[2] = 0x81;
        response[3] = 0x85; // RCODE=5 Refused
        assert_eq!(
            classify_response(&query, &response),
            DnsProbeOutcome::Refused
        );
        Ok(())
    }

    #[test]
    fn parses_first_a_record_address() -> Result<(), std::io::Error> {
        let query = build_query("example.com", TXID)?;
        let mut response = query.clone();
        response[2] = 0x81;
        response[3] = 0x80;
        response[6] = 0x00;
        response[7] = 0x01; // ANCOUNT = 1
        response.extend_from_slice(&[
            0xc0, 0x0c, // name pointer to offset 12
            0x00, 0x01, // TYPE A
            0x00, 0x01, // CLASS IN
            0x00, 0x00, 0x00, 0x3c, // TTL 60s
            0x00, 0x04, // RDLENGTH 4
            1, 2, 3, 4, // RDATA 1.2.3.4
        ]);
        assert_eq!(
            classify_response(&query, &response),
            DnsProbeOutcome::Resolved(Some(IpAddr::V4(std::net::Ipv4Addr::new(1, 2, 3, 4))))
        );
        Ok(())
    }

    #[test]
    fn probe_reaches_a_local_resolver_over_udp() -> Result<(), Box<dyn std::error::Error>> {
        let socket = UdpSocket::bind("127.0.0.1:0")?;
        let address = socket.local_addr()?;
        std::thread::spawn(move || {
            let mut buffer = [0u8; 512];
            if let Ok((read, peer)) = socket.recv_from(&mut buffer) {
                let mut response = buffer[..read].to_vec();
                response[2] |= 0x80;
                let _ = socket.send_to(&response, peer);
            }
        });
        let outcome = probe_nameserver(
            &address.to_string(),
            "example.com",
            Duration::from_secs(2),
            TXID,
        );
        assert_eq!(outcome, DnsProbeOutcome::Resolved(None));
        Ok(())
    }

    #[test]
    fn probe_reaches_an_ipv6_loopback_resolver_when_available() -> Result<(), Box<dyn std::error::Error>> {
        let Ok(socket) = UdpSocket::bind("[::1]:0") else {
            return Ok(());
        };
        let address = socket.local_addr()?;
        std::thread::spawn(move || {
            let mut buffer = [0u8; 512];
            if let Ok((read, peer)) = socket.recv_from(&mut buffer) {
                let mut response = buffer[..read].to_vec();
                response[2] |= 0x80;
                let _ = socket.send_to(&response, peer);
            }
        });
        let outcome = probe_nameserver(
            &address.to_string(),
            "example.com",
            Duration::from_secs(2),
            TXID,
        );
        assert_eq!(
            outcome,
            DnsProbeOutcome::Resolved(None),
            "IPv6 loopback resolver must be reachable over UDP: {address}"
        );
        Ok(())
    }

    #[test]
    fn b3_schemed_nameservers_dispatch_instead_of_udp_mangling() {
        assert_eq!(
            probe_nameserver(
                "tls://1.1.1.1",
                "example.com",
                Duration::from_secs(1),
                TXID
            ),
            DnsProbeOutcome::UnsupportedTransport
        );
        assert_eq!(
            probe_nameserver(
                "https://dns.google/dns-query",
                "example.com",
                Duration::from_secs(1),
                TXID
            ),
            DnsProbeOutcome::UnsupportedTransport
        );
        assert_eq!(
            probe_nameserver("local", "example.com", Duration::from_secs(1), TXID),
            DnsProbeOutcome::UnsupportedTransport
        );
    }

    #[test]
    fn f1_tcp_probe_round_trips_with_length_framing() -> Result<(), Box<dyn std::error::Error>> {
        let listener = std::net::TcpListener::bind("127.0.0.1:0")?;
        let address = listener.local_addr()?;
        std::thread::spawn(move || {
            let Ok((mut stream, _)) = listener.accept() else {
                return;
            };
            let mut prefix = [0u8; 2];
            if stream.read_exact(&mut prefix).is_err() {
                return;
            }
            let length = u16::from_be_bytes(prefix) as usize;
            let mut query = vec![0u8; length];
            if stream.read_exact(&mut query).is_err() {
                return;
            }
            let mut response = query.clone();
            response[2] |= 0x80; // QR=1
            let resp_length = u16::try_from(response.len()).unwrap();
            let mut frame = Vec::with_capacity(response.len() + 2);
            frame.extend_from_slice(&resp_length.to_be_bytes());
            frame.extend_from_slice(&response);
            let _ = stream.write_all(&frame);
        });
        let outcome = probe_nameserver(
            &format!("tcp://{address}"),
            "example.com",
            Duration::from_secs(2),
            TXID,
        );
        assert_eq!(outcome, DnsProbeOutcome::Resolved(None));
        Ok(())
    }

    #[test]
    fn refused_udp_port_is_error_not_timeout() {
        let outcome = probe_nameserver("127.0.0.1:9", "example.com", Duration::from_secs(2), TXID);
        assert!(
            matches!(outcome, DnsProbeOutcome::Error | DnsProbeOutcome::Timeout),
            "closed port must not panic; got {outcome:?}"
        );
    }

    #[test]
    fn a121_domain_resolution_is_budget_bounded() {
        let started = std::time::Instant::now();
        let slow_resolver = |_: &str, _: u16| {
            std::thread::sleep(Duration::from_millis(200));
            Ok(Some(SocketAddr::new(IpAddr::V4(std::net::Ipv4Addr::LOCALHOST), 53)))
        };
        let result = parse_nameserver_with(
            "slow.example.com",
            53,
            Duration::from_millis(50),
            slow_resolver,
        );
        assert!(result.is_err(), "budget must time out");
        assert!(
            started.elapsed() < Duration::from_millis(150),
            "resolver must return within ~budget"
        );
    }

    #[test]
    fn a121_bare_domain_and_bracketed_v6_resolve_with_default_ports() {
        let parsed = parse_nameserver_within("127.0.0.1", Duration::from_millis(100)).unwrap();
        assert_eq!(parsed, SocketAddr::new(IpAddr::V4(std::net::Ipv4Addr::LOCALHOST), 53));
        let parsed = parse_nameserver_within("[::1]:5353", Duration::from_millis(100)).unwrap();
        assert_eq!(parsed, SocketAddr::new(IpAddr::V6(std::net::Ipv6Addr::LOCALHOST), 5353));
    }

    #[test]
    fn a124_stray_datagram_is_dropped_and_the_real_answer_wins() -> Result<(), Box<dyn std::error::Error>> {
        let socket = UdpSocket::bind("127.0.0.1:0")?;
        let address = socket.local_addr()?;
        std::thread::spawn(move || {
            let mut buffer = [0u8; 512];
            if let Ok((read, peer)) = socket.recv_from(&mut buffer) {
                // First: stray packet with mismatched txid
                let mut stray = buffer[..read].to_vec();
                stray[0] ^= 0xff;
                stray[2] |= 0x80;
                let _ = socket.send_to(&stray, peer);
                std::thread::sleep(Duration::from_millis(10));
                // Second: legitimate response
                let mut response = buffer[..read].to_vec();
                response[2] |= 0x80;
                let _ = socket.send_to(&response, peer);
            }
        });
        let outcome = probe_nameserver(
            &address.to_string(),
            "example.com",
            Duration::from_secs(2),
            TXID,
        );
        assert_eq!(outcome, DnsProbeOutcome::Resolved(None));
        Ok(())
    }

    #[test]
    fn timed_probe_reports_latency() -> Result<(), Box<dyn std::error::Error>> {
        let socket = UdpSocket::bind("127.0.0.1:0")?;
        let address = socket.local_addr()?;
        std::thread::spawn(move || {
            let mut buffer = [0u8; 512];
            if let Ok((read, peer)) = socket.recv_from(&mut buffer) {
                let mut response = buffer[..read].to_vec();
                response[2] |= 0x80;
                let _ = socket.send_to(&response, peer);
            }
        });
        let report = probe_nameserver_timed(
            &address.to_string(),
            "example.com",
            Duration::from_secs(2),
            TXID,
        );
        assert_eq!(report.outcome, DnsProbeOutcome::Resolved(None));
        assert!(report.latency > Duration::ZERO);
        Ok(())
    }

    // ─── New tests for Multi-Record, EDNS0, RFC 7766 TCP fallback ──────────

    #[test]
    fn query_typed_builds_all_record_types() -> Result<(), std::io::Error> {
        let q_a = build_query_typed("example.com", DnsRecordType::A, TXID, None)?;
        assert_eq!(u16::from_be_bytes([q_a[q_a.len() - 4], q_a[q_a.len() - 3]]), 1);

        let q_aaaa = build_query_typed("example.com", DnsRecordType::AAAA, TXID, None)?;
        assert_eq!(u16::from_be_bytes([q_aaaa[q_aaaa.len() - 4], q_aaaa[q_aaaa.len() - 3]]), 28);

        let q_cname = build_query_typed("example.com", DnsRecordType::CNAME, TXID, None)?;
        assert_eq!(u16::from_be_bytes([q_cname[q_cname.len() - 4], q_cname[q_cname.len() - 3]]), 5);

        let q_txt = build_query_typed("example.com", DnsRecordType::TXT, TXID, None)?;
        assert_eq!(u16::from_be_bytes([q_txt[q_txt.len() - 4], q_txt[q_txt.len() - 3]]), 16);

        let q_ptr = build_query_typed("1.2.0.192.in-addr.arpa", DnsRecordType::PTR, TXID, None)?;
        assert_eq!(u16::from_be_bytes([q_ptr[q_ptr.len() - 4], q_ptr[q_ptr.len() - 3]]), 12);

        let q_https = build_query_typed("example.com", DnsRecordType::HTTPS, TXID, None)?;
        assert_eq!(u16::from_be_bytes([q_https[q_https.len() - 4], q_https[q_https.len() - 3]]), 65);
        Ok(())
    }

    #[test]
    fn query_with_edns0_opt_and_dnssec_do_bit() -> Result<(), std::io::Error> {
        let edns = Edns0Options {
            udp_payload_size: 1232,
            dnssec_ok: true,
            ecs_policy: crate::dns::advanced::EcsPolicy::Forward,
        };
        let query = build_query_typed("example.com", DnsRecordType::A, TXID, Some(&edns))?;

        // ARCOUNT must be 1
        assert_eq!(u16::from_be_bytes([query[10], query[11]]), 1);

        // Tail must contain OPT RR (11 bytes: root=0, type=41, class=1232, ttl=0x8000 (DO bit), rdlength=0)
        let tail = &query[query.len() - 11..];
        assert_eq!(tail[0], 0); // Root domain
        assert_eq!(u16::from_be_bytes([tail[1], tail[2]]), 41); // OPT type
        assert_eq!(u16::from_be_bytes([tail[3], tail[4]]), 1232); // UDP payload size
        assert_eq!(u16::from_be_bytes([tail[7], tail[8]]), 0x8000); // DO bit set
        assert_eq!(u16::from_be_bytes([tail[9], tail[10]]), 0); // RDLENGTH = 0
        Ok(())
    }

    #[test]
    fn parses_multi_record_answers_aaaa_cname_txt_ptr_https() -> Result<(), std::io::Error> {
        let query = build_query_typed("example.com", DnsRecordType::ANY, TXID, None)?;
        let mut response = query.clone();
        response[2] = 0x81; // QR=1
        response[3] = 0xa0; // AD=1 (DNSSEC verified), RCODE=0
        response[6] = 0x00;
        response[7] = 0x05; // ANCOUNT = 5

        // Record 1: AAAA (IPv6)
        response.extend_from_slice(&[
            0xc0, 0x0c, // name pointer
            0x00, 0x1c, // TYPE AAAA (28)
            0x00, 0x01, // CLASS IN
            0x00, 0x00, 0x01, 0x2c, // TTL 300s
            0x00, 0x10, // RDLENGTH 16
            0x20, 0x01, 0x0d, 0xb8, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, // 2001:db8::1
        ]);

        // Record 2: CNAME
        response.extend_from_slice(&[
            0xc0, 0x0c, // name pointer
            0x00, 0x05, // TYPE CNAME (5)
            0x00, 0x01, // CLASS IN
            0x00, 0x00, 0x02, 0x58, // TTL 600s
            0x00, 0x0b, // RDLENGTH 11
            0x06, b't', b'a', b'r', b'g', b'e', b't', 0x03, b'c', b'o', b'm', 0x00,
        ]);

        // Record 3: TXT
        response.extend_from_slice(&[
            0xc0, 0x0c, // name pointer
            0x00, 0x10, // TYPE TXT (16)
            0x00, 0x01, // CLASS IN
            0x00, 0x00, 0x00, 0x3c, // TTL 60s
            0x00, 0x0b, // RDLENGTH 11
            0x0a, b'v', b'=', b's', b'p', b'f', b'1', b' ', b'a', b'l', b'l',
        ]);

        // Record 4: PTR
        response.extend_from_slice(&[
            0xc0, 0x0c, // name pointer
            0x00, 0x0c, // TYPE PTR (12)
            0x00, 0x01, // CLASS IN
            0x00, 0x00, 0x0e, 0x10, // TTL 3600s
            0x00, 0x08, // RDLENGTH 8
            0x03, b'p', b't', b'r', 0xc0, 0x14, // "ptr" -> ptr to "com"
        ]);

        // Record 5: HTTPS
        response.extend_from_slice(&[
            0xc0, 0x0c, // name pointer
            0x00, 0x41, // TYPE HTTPS (65)
            0x00, 0x01, // CLASS IN
            0x00, 0x00, 0x00, 0x3c, // TTL 60s
            0x00, 0x07, // RDLENGTH 7
            0x00, 0x01, // Priority 1
            0x00,       // TargetName "."
            0x00, 0x01, 0x00, 0x00, // Param key 1, len 0
        ]);

        let answers = parse_record_answers(&response).expect("must parse all 5 records");
        assert_eq!(answers.len(), 5);

        // Verify AAAA
        assert_eq!(answers[0].rtype, DnsRecordType::AAAA);
        assert_eq!(answers[0].data, DnsAnswerData::AAAA("2001:db8::1".parse().unwrap()));

        // Verify CNAME
        assert_eq!(answers[1].rtype, DnsRecordType::CNAME);
        assert_eq!(answers[1].data, DnsAnswerData::Cname("target.com".to_owned()));

        // Verify TXT
        assert_eq!(answers[2].rtype, DnsRecordType::TXT);
        assert_eq!(answers[2].data, DnsAnswerData::Txt(vec!["v=spf1 all".to_owned()]));

        // Verify PTR
        assert_eq!(answers[3].rtype, DnsRecordType::PTR);
        assert_eq!(answers[3].data, DnsAnswerData::Ptr("ptr.com".to_owned()));

        // Verify HTTPS
        assert_eq!(answers[4].rtype, DnsRecordType::HTTPS);
        match &answers[4].data {
            DnsAnswerData::Https { priority, .. } => assert_eq!(*priority, 1),
            other => panic!("expected HTTPS answer data, got {other:?}"),
        }

        Ok(())
    }

    #[test]
    fn rfc7766_tc_bit_triggers_tcp_fallback() -> Result<(), Box<dyn std::error::Error>> {
        let udp_socket = UdpSocket::bind("127.0.0.1:0")?;
        let tcp_listener = std::net::TcpListener::bind("127.0.0.1:0")?;
        let udp_addr = udp_socket.local_addr()?;
        let tcp_addr = tcp_listener.local_addr()?;

        // Mock UDP server: responds with TC=1 (Truncated)
        std::thread::spawn(move || {
            let mut buf = [0u8; 512];
            if let Ok((n, peer)) = udp_socket.recv_from(&mut buf) {
                let mut resp = buf[..n].to_vec();
                resp[2] |= 0x82; // QR=1, TC=1 (Truncated)
                let _ = udp_socket.send_to(&resp, peer);
            }
        });

        // Mock TCP server: handles fallback query and returns full A record answer
        std::thread::spawn(move || {
            let Ok((mut stream, _)) = tcp_listener.accept() else { return; };
            let mut prefix = [0u8; 2];
            if stream.read_exact(&mut prefix).is_err() { return; }
            let len = u16::from_be_bytes(prefix) as usize;
            let mut query = vec![0u8; len];
            if stream.read_exact(&mut query).is_err() { return; }

            let mut resp = query.clone();
            resp[2] = 0x81; // QR=1, TC=0
            resp[3] = 0x80; // RCODE=0
            resp[6] = 0x00; resp[7] = 0x01; // ANCOUNT=1
            resp.extend_from_slice(&[
                0xc0, 0x0c,
                0x00, 0x01, 0x00, 0x01,
                0x00, 0x00, 0x00, 0x3c,
                0x00, 0x04,
                9, 9, 9, 9,
            ]);
            let resp_len = u16::try_from(resp.len()).unwrap();
            let mut frame = Vec::with_capacity(resp.len() + 2);
            frame.extend_from_slice(&resp_len.to_be_bytes());
            frame.extend_from_slice(&resp);
            let _ = stream.write_all(&frame);
        });

        // Query UDP server with TCP fallback target
        let outcome = probe_udp_record(
            &format!("127.0.0.1:{}", tcp_addr.port()), // Address points to TCP mock
            "example.com",
            DnsRecordType::A,
            Duration::from_secs(2),
            TXID,
            None,
        );

        match outcome {
            DnsRecordProbeOutcome::Resolved { records, .. } => {
                assert_eq!(records.len(), 1);
                assert_eq!(records[0].data, DnsAnswerData::A(Ipv4Addr::new(9, 9, 9, 9)));
            }
            other => panic!("expected TCP fallback resolved outcome, got {other:?}"),
        }

        Ok(())
    }
}

/// Helper to run async future in both synchronous and Tokio environments.
fn run_probe_future<F: std::future::Future<Output = R>, R>(future: F) -> R {
    if let Ok(handle) = tokio::runtime::Handle::try_current() {
        tokio::task::block_in_place(|| handle.block_on(future))
    } else if let Ok(rt) = tokio::runtime::Builder::new_current_thread().enable_all().build() {
        rt.block_on(future)
    } else {
        panic!("cannot spawn tokio runtime for dns probe")
    }
}

/// Probes a DoH (DNS over HTTPS, RFC 8484) nameserver.
pub fn probe_doh_record(
    url: &str,
    domain: &str,
    record_type: DnsRecordType,
    timeout: Duration,
    transaction_id: [u8; 2],
    edns: Option<&Edns0Options>,
) -> DnsRecordProbeOutcome {
    run_probe_future(async_probe_doh_record(url, domain, record_type, timeout, transaction_id, edns))
}

async fn async_probe_doh_record(
    url: &str,
    domain: &str,
    record_type: DnsRecordType,
    timeout: Duration,
    transaction_id: [u8; 2],
    edns: Option<&Edns0Options>,
) -> DnsRecordProbeOutcome {
    let Ok(query) = build_query_typed(domain, record_type, transaction_id, edns) else {
        return DnsRecordProbeOutcome::Error;
    };
    let clean_url = url.split('#').next().unwrap_or(url);
    let Ok(client) = reqwest::Client::builder().timeout(timeout).build() else {
        return DnsRecordProbeOutcome::Error;
    };

    let outcome = client
        .post(clean_url)
        .header("content-type", "application/dns-message")
        .header("accept", "application/dns-message")
        .body(query)
        .send()
        .await;

    let resp = match outcome {
        Ok(r) => r,
        Err(e) => {
            if e.is_timeout() {
                return DnsRecordProbeOutcome::Timeout;
            }
            return DnsRecordProbeOutcome::Error;
        }
    };

    if !resp.status().is_success() {
        let code = resp.status().as_u16();
        if code == 403 || code == 401 {
            return DnsRecordProbeOutcome::Refused;
        }
        return DnsRecordProbeOutcome::Error;
    }

    let Ok(body) = resp.bytes().await else {
        return DnsRecordProbeOutcome::Error;
    };

    if body.len() < 12 {
        return DnsRecordProbeOutcome::Error;
    }
    let rcode = body[3] & 0x0f;
    if let Some(err) = map_wire_rcode(rcode) {
        return err;
    }
    let authenticated_data = (body[3] & 0x20) != 0;
    let records = parse_record_answers(&body).unwrap_or_default();
    DnsRecordProbeOutcome::Resolved {
        records,
        authenticated_data,
    }
}

/// Probes a DoT (DNS over TLS, RFC 7858) nameserver on port 853.
pub fn probe_dot_record(
    server_addr: &str,
    domain: &str,
    record_type: DnsRecordType,
    timeout: Duration,
    transaction_id: [u8; 2],
    edns: Option<&Edns0Options>,
) -> DnsRecordProbeOutcome {
    run_probe_future(async_probe_dot_record(server_addr, domain, record_type, timeout, transaction_id, edns))
}

async fn async_probe_dot_record(
    server_addr: &str,
    domain: &str,
    record_type: DnsRecordType,
    timeout: Duration,
    transaction_id: [u8; 2],
    edns: Option<&Edns0Options>,
) -> DnsRecordProbeOutcome {
    let Ok(query) = build_query_typed(domain, record_type, transaction_id, edns) else {
        return DnsRecordProbeOutcome::Error;
    };
    let clean_addr = server_addr.split('#').next().unwrap_or(server_addr);
    let (host, port) = if let Some((h, p)) = clean_addr.rsplit_once(':') {
        (h, p.parse::<u16>().unwrap_or(853))
    } else {
        (clean_addr, 853)
    };

    let target_addr = match resolve_for_probe(&format!("{host}:{port}"), timeout) {
        Ok(addr) => addr,
        Err(outcome) => return map_legacy_outcome(outcome),
    };

    let Ok(tcp_res) = tokio::time::timeout(timeout, tokio::net::TcpStream::connect(target_addr)).await else {
        return DnsRecordProbeOutcome::Timeout;
    };
    let Ok(tcp_stream) = tcp_res else {
        return DnsRecordProbeOutcome::Error;
    };

    let root_store = tokio_rustls::rustls::RootCertStore::empty();
    let config = tokio_rustls::rustls::ClientConfig::builder()
        .with_root_certificates(root_store)
        .with_no_client_auth();
    let connector = tokio_rustls::TlsConnector::from(std::sync::Arc::new(config));
    let Ok(server_name) = tokio_rustls::rustls::pki_types::ServerName::try_from(host.to_owned()) else {
        return DnsRecordProbeOutcome::Error;
    };

    let Ok(tls_res) = tokio::time::timeout(timeout, connector.connect(server_name, tcp_stream)).await else {
        return DnsRecordProbeOutcome::Timeout;
    };
    let Ok(mut tls_stream) = tls_res else {
        return DnsRecordProbeOutcome::Error;
    };

    use tokio::io::{AsyncReadExt, AsyncWriteExt};
    let length = u16::try_from(query.len()).unwrap_or(0);
    let mut frame = Vec::with_capacity(query.len() + 2);
    frame.extend_from_slice(&length.to_be_bytes());
    frame.extend_from_slice(&query);

    if tls_stream.write_all(&frame).await.is_err() {
        return DnsRecordProbeOutcome::Error;
    }

    let mut prefix = [0u8; 2];
    if tls_stream.read_exact(&mut prefix).await.is_err() {
        return DnsRecordProbeOutcome::Error;
    }
    let expected = u16::from_be_bytes(prefix) as usize;
    if expected == 0 {
        return DnsRecordProbeOutcome::Error;
    }
    let mut response = vec![0u8; expected];
    if tls_stream.read_exact(&mut response).await.is_err() {
        return DnsRecordProbeOutcome::Error;
    }

    if response.len() < 12 {
        return DnsRecordProbeOutcome::Error;
    }
    let rcode = response[3] & 0x0f;
    if let Some(err) = map_wire_rcode(rcode) {
        return err;
    }
    let authenticated_data = (response[3] & 0x20) != 0;
    let records = parse_record_answers(&response).unwrap_or_default();
    DnsRecordProbeOutcome::Resolved {
        records,
        authenticated_data,
    }
}
