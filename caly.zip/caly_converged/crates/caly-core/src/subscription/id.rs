//! Stable source-URL identity (P8b: moved up from `caly-backends` so the
//! presentation layer can derive subscription ids without reaching into
//! adapters — this is intake-domain function, not a port implementation).

use crate::domain::SubscriptionId;

/// Stable 16-byte `SubscriptionId` from a source URL digest.
///
/// hash the *normalised* URL so equivalent spellings of one
/// source share the id/cache entry instead of fragmenting validators and
/// cached bodies across duplicates.
/// Folded by `Url` serialization (one id): scheme/host case, a redundant
/// default port, leading/trailing whitespace, and the empty-path vs `/`
/// distinction. NOT folded (distinct ids): fragment presence, trailing
/// slashes on non-root paths, percent-escape spellings (`%78` vs `x`),
/// userinfo case, and query order. Both sets are locked by unit tests so
/// a `url` upgrade that changes serialization fails loudly (M2).
pub fn subscription_id_for_url(url: &str) -> SubscriptionId {
    use sha2::{Digest, Sha256};
    let normalized =
        url::Url::parse(url).map_or_else(|_| url.to_owned(), |parsed| parsed.to_string());
    let mut hasher = Sha256::new();
    hasher.update(normalized.as_bytes());
    let digest = hasher.finalize();
    let mut bytes = [0_u8; 16];
    bytes.copy_from_slice(&digest[..16]);
    SubscriptionId::from_bytes(bytes)
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn id_is_stable_across_equivalent_spellings() {
        let sub_id = subscription_id_for_url("https://example.com/sub");
        // url::Url normalisation lowercases the host and strips the
        // redundant default port; both spellings must share one id
        // (audit #120: no cache fragmentation across duplicates).
        let equivalent_id = subscription_id_for_url("HTTPS://EXAMPLE.COM:443/sub");
        assert_eq!(sub_id, equivalent_id);
        // Distinct sources stay distinct.
        let other_id = subscription_id_for_url("https://example.com/other");
        assert_ne!(sub_id, other_id);
        // Unparseable input degrades to hashing the raw string (stable).
        let raw_id = subscription_id_for_url("not a url");
        let raw_id_again = subscription_id_for_url("not a url");
        assert_eq!(raw_id, raw_id_again);
    }

    #[test]
    fn id_folds_url_serialization_equivalents() {
        // M2: the folded set — spellings `Url` serialization maps to one
        // string share one id (and one cache entry).
        let base = subscription_id_for_url("https://example.com/sub");
        // Leading/trailing whitespace is trimmed by WHATWG parsing.
        assert_eq!(base, subscription_id_for_url("  https://example.com/sub\t\n"));
        // Empty path and "/" serialize identically.
        assert_eq!(
            subscription_id_for_url("https://example.com"),
            subscription_id_for_url("https://example.com/")
        );
    }

    #[test]
    fn id_keeps_known_non_folded_distinctions() {
        // M2: the NOT-folded set — `Url` serialization preserves these
        // distinctions, so each spelling yields a distinct id (and a
        // distinct cache entry). Locked here so a `url` upgrade that
        // changes serialization fails loudly instead of silently
        // merging or splitting cache entries.
        let base = subscription_id_for_url("https://example.com/x");
        // Fragment (present vs absent).
        assert_ne!(base, subscription_id_for_url("https://example.com/x#frag"));
        // Trailing slash is a distinct path.
        assert_ne!(base, subscription_id_for_url("https://example.com/x/"));
        // Percent-escapes are preserved byte-wise, never decoded.
        assert_ne!(base, subscription_id_for_url("https://example.com/%78"));
        // Userinfo case is preserved (only scheme/host fold).
        assert_ne!(
            subscription_id_for_url("https://user@example.com/x"),
            subscription_id_for_url("https://USER@example.com/x")
        );
        // Query order is preserved.
        assert_ne!(
            subscription_id_for_url("https://example.com/x?a=1&b=2"),
            subscription_id_for_url("https://example.com/x?b=2&a=1")
        );
    }
}
