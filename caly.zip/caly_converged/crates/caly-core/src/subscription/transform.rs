//! Subscription transform engine: regex filtering, node renaming, and tagging.
//!
//! Provides both stable SHA-256 fingerprinting and an execution pipeline for
//! mutating or filtering incoming nodes before commitment.

use crate::domain::{BoundedText, BoundedVec, DialableNode, NodeDisplayName, sanitized_display_name};
use sha2::{Digest, Sha256};

pub const MAX_TRANSFORM_RULES: usize = 256;
pub type TransformRule = BoundedText<1_024>;
pub type TransformRules = BoundedVec<TransformRule, MAX_TRANSFORM_RULES>;

/// Inputs that can change normalized nodes without changing response bytes.
pub struct TransformInputs {
    pub include: TransformRules,
    pub exclude: TransformRules,
    pub add_tags: TransformRules,
    pub group_rules: TransformRules,
}

/// Stable SHA-256 transform identity.
#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub struct TransformFingerprint(pub [u8; 32]);

pub fn fingerprint(inputs: &TransformInputs) -> TransformFingerprint {
    let mut hash = Sha256::new();
    hash.update(b"caly-subscription-transform-v2");
    encode_rules(&mut hash, b"include", &inputs.include);
    encode_rules(&mut hash, b"exclude", &inputs.exclude);
    encode_rules(&mut hash, b"tags", &inputs.add_tags);
    encode_rules(&mut hash, b"groups", &inputs.group_rules);
    TransformFingerprint(hash.finalize().into())
}

/// Checks whether transform fingerprint has changed between updates.
pub fn should_retransform(
    cached_body_hash: [u8; 32],
    current_body_hash: [u8; 32],
    cached_transform: TransformFingerprint,
    current_transform: TransformFingerprint,
) -> bool {
    cached_body_hash != current_body_hash || cached_transform.0 != current_transform.0
}

fn encode_rules(hash: &mut Sha256, label: &[u8], rules: &TransformRules) {
    hash.update((label.len() as u64).to_be_bytes());
    hash.update(label);
    hash.update((rules.len() as u64).to_be_bytes());
    for rule in rules {
        hash.update((rule.len_bytes() as u64).to_be_bytes());
        hash.update(rule.as_str().as_bytes());
    }
}

/// Node rename pattern: `s/pattern/replacement/g` or substring replacement.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct RenameRule {
    pub pattern: String,
    pub replacement: String,
}

impl RenameRule {
    pub fn apply(&self, name: &str) -> String {
        name.replace(&self.pattern, &self.replacement)
    }
}

/// Full subscription transformation engine executing filters and mutations.
#[derive(Clone, Debug, Default)]
pub struct SubscriptionTransformEngine {
    pub include_patterns: Vec<String>,
    pub exclude_patterns: Vec<String>,
    pub rename_rules: Vec<RenameRule>,
}

impl SubscriptionTransformEngine {
    pub fn new() -> Self {
        Self::default()
    }

    pub fn with_include(mut self, pattern: impl Into<String>) -> Self {
        self.include_patterns.push(pattern.into());
        self
    }

    pub fn with_exclude(mut self, pattern: impl Into<String>) -> Self {
        self.exclude_patterns.push(pattern.into());
        self
    }

    pub fn with_rename(mut self, pattern: impl Into<String>, replacement: impl Into<String>) -> Self {
        self.rename_rules.push(RenameRule {
            pattern: pattern.into(),
            replacement: replacement.into(),
        });
        self
    }

    /// Evaluates filter predicates: true if node should be kept.
    pub fn matches(&self, node_name: &str) -> bool {
        // 1. Exclude filter: any match drops the node
        for pat in &self.exclude_patterns {
            if node_name.contains(pat) {
                return false;
            }
        }
        // 2. Include filter: if specified, at least one must match
        if !self.include_patterns.is_empty() {
            return self.include_patterns.iter().any(|pat| node_name.contains(pat));
        }
        true
    }

    /// Applies rename rules to a node's display name.
    pub fn transform_name(&self, original_name: &str) -> String {
        let mut name = original_name.to_owned();
        for rule in &self.rename_rules {
            name = rule.apply(&name);
        }
        name
    }

    /// Applies filters and rename rules to a list of dialable nodes.
    pub fn apply_to_nodes(&self, nodes: Vec<DialableNode>) -> Vec<DialableNode> {
        let mut out = Vec::with_capacity(nodes.len());
        for node in nodes {
            let name_str = node.name().as_str();
            // 1. Evaluate include / exclude filters
            if !self.matches(name_str) {
                continue;
            }
            // 2. Apply rename rules
            let new_name_str = self.transform_name(name_str);
            if new_name_str != name_str {
                if let Ok(new_name) = sanitized_display_name(new_name_str) {
                    out.push(node.with_name(new_name));
                    continue;
                }
            }
            out.push(node);
        }
        out
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn transform_engine_filter_and_rename() {
        let engine = SubscriptionTransformEngine::new()
            .with_include("HK")
            .with_exclude("Expired")
            .with_rename("HK", "Hong Kong");

        assert!(!engine.matches("US - 01"));
        assert!(!engine.matches("HK - Expired"));
        assert!(engine.matches("HK - 01 BGP"));

        let renamed = engine.transform_name("HK - 01 BGP");
        assert_eq!(renamed, "Hong Kong - 01 BGP");
    }
}
