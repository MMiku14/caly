//! Bounded NodeId dedupe, subscription normalization, and presentation projection.

use std::collections::BTreeMap;

use crate::domain::{
    BoundedVec, DialableNode, DisplayNode, NodeDisplayName, NodeProtocolLabel, SnapshotNodes,
    SubscriptionId,
};

use super::transform::SubscriptionTransformEngine;
use super::{
    chain::{ChainError, validate_chains},
    clash::parse_clash_yaml,
    format::{FormatError, SubscriptionDocument, decode_document},
    uri::parse_any_proxy_uri,
};

pub const MAX_SUBSCRIPTION_NODES: usize = 10_000;
pub type SubscriptionNodes = BoundedVec<DialableNode, MAX_SUBSCRIPTION_NODES>;

/// Deterministic first-seen dedupe result.
pub struct DedupeResult {
    pub nodes: SubscriptionNodes,
    pub duplicate_count: usize,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub enum PipelineError {
    TooManyNodes,
    UnsupportedDocument,
    Format(FormatError),
    Uri,
    /// Every recognized line was `ssr://`; SSR is not representable, so no
    /// usable node exists. Carries the number of skipped SSR entries.
    SsrOnly(usize),
    Display,
    Clash,
    /// The chain (dialer-proxy dependency) graph is invalid.
    Chain(ChainError),
}

impl From<crate::domain::CapacityError> for PipelineError {
    fn from(_: crate::domain::CapacityError) -> Self {
        Self::TooManyNodes
    }
}

impl core::fmt::Display for PipelineError {
    fn fmt(&self, formatter: &mut core::fmt::Formatter<'_>) -> core::fmt::Result {
        match self {
            Self::TooManyNodes => formatter.write_str("subscription has too many nodes"),
            Self::UnsupportedDocument => formatter.write_str("document format is not supported"),
            Self::Format(error) => write!(formatter, "subscription decode failed: {error}"),
            Self::Uri => formatter.write_str("no parseable proxy nodes"),
            Self::SsrOnly(count) => write!(
                formatter,
                "all {count} nodes are SSR, which is not representable"
            ),
            Self::Display => formatter.write_str("node display projection failed"),
            Self::Clash => formatter.write_str("Clash YAML parsing failed"),
            Self::Chain(error) => write!(formatter, "chain validation failed: {error}"),
        }
    }
}

/// Redacted subscription projection with explicit rejected-line count.
#[derive(Clone, Debug)]
pub struct SubscriptionProjection {
    pub nodes: SnapshotNodes,
    pub rejected_lines: usize,
    /// Recognized `ssr://` lines: SSR is not representable, so they are
    /// skipped deliberately rather than counted as parse rejections.
    pub ssr_skipped: usize,
}

/// Decodes a subscription while retaining bounded diagnostics for rejected
/// lines. URI-line bodies count individually rejected lines; Clash-YAML bodies
/// parse as a whole document (a parse failure rejects the document).
pub fn parse_uri_body_to_display_lossy(
    body: &[u8],
    subscription: SubscriptionId,
) -> Result<SubscriptionProjection, PipelineError> {
    let document = decode_document(body).map_err(PipelineError::Format)?;
    parse_document_to_display_lossy(&document, subscription)
}

/// [`parse_uri_body_to_display_lossy`] on an already-decoded document —
/// the single-pass pipeline entry: the daemon decodes a subscription body
/// once per refresh and shares the document across the projection, Mihomo
/// render, sing-box render and routing consumers (refactor;
/// the body used to be decoded up to four times per refresh).
/// Dialable nodes parsed once from a document, with lossy counters.
/// P2: the daemon parses each body exactly once and shares these nodes
/// across the projection and both kernel renderers — the pre-optimization
/// shape ran this same loop 2-4× per refresh (projection + each kernel,
/// plus a YAML re-parse for routing on Clash bodies).
pub struct LossyDialable {
    /// Successfully parsed nodes, in document order (pre-dedupe).
    pub nodes: Vec<DialableNode>,
    /// URI lines that failed to parse (Clash/SIP008 fail atomically instead).
    pub rejected_lines: usize,
    /// Recognized `ssr://` lines, skipped deliberately (never rejections).
    pub ssr_skipped: usize,
}

/// Parses every representable node out of a decoded document, tolerating
/// unparseable URI lines. An unusable body is an error, never an empty
/// success (the `SsrOnly` / `Uri` arms below are the contract the display
/// wrapper and the daemon refresh path share).
pub fn parse_document_dialable_lossy(
    document: &SubscriptionDocument,
    subscription: SubscriptionId,
) -> Result<LossyDialable, PipelineError> {
    let (nodes, rejected_lines, ssr_skipped) = match document {
        SubscriptionDocument::UriLines { lines, .. } => {
            let mut nodes = Vec::new();
            let mut rejected = 0_usize;
            let mut ssr = 0_usize;
            for line in lines {
                // SSR is recognized but not representable; skip it without
                // counting it as a parse rejection.
                if line.as_str().starts_with("ssr://") {
                    ssr = ssr.saturating_add(1);
                    continue;
                }
                match parse_any_proxy_uri(line.as_str(), subscription) {
                    Ok(node) => nodes.push(node),
                    Err(_) => rejected = rejected.saturating_add(1),
                }
            }
            (nodes, rejected, ssr)
        }
        SubscriptionDocument::ClashYaml(body) => {
            let source = core::str::from_utf8(body.as_slice()).map_err(|_| PipelineError::Clash)?;
            (
                parse_clash_yaml(source, subscription).map_err(|_| PipelineError::Clash)?,
                0,
                0,
            )
        }
        SubscriptionDocument::Sip008(body) => {
            let source = core::str::from_utf8(body.as_slice()).map_err(|_| PipelineError::Uri)?;
            let (nodes, skipped) = super::parse_sip008(source, subscription);
            (nodes, skipped, 0)
        }
        // URL lists are expanded by the daemon fetch path before node
        // parsing; reaching this point means an unsupported nested list.
        SubscriptionDocument::UrlList(_) => return Err(PipelineError::UnsupportedDocument),
    };
    if nodes.is_empty() {
        if ssr_skipped > 0 && rejected_lines == 0 {
            return Err(PipelineError::SsrOnly(ssr_skipped));
        }
        return Err(PipelineError::Uri);
    }
    Ok(LossyDialable {
        nodes,
        rejected_lines,
        ssr_skipped,
    })
}

pub fn parse_document_to_display_lossy(
    document: &SubscriptionDocument,
    subscription: SubscriptionId,
) -> Result<SubscriptionProjection, PipelineError> {
    let parsed = parse_document_dialable_lossy(document, subscription)?;
    validate_chains(&parsed.nodes).map_err(PipelineError::Chain)?;
    let deduped = dedupe(parsed.nodes)?;
    let tags = display_tags(deduped.nodes.as_slice())?;
    assemble_projection(
        deduped.nodes.as_slice(),
        &tags,
        parsed.rejected_lines,
        parsed.ssr_skipped,
    )
}

/// Derives the canonical display tags (`#N` suffixes in first-seen order)
/// for deduped nodes. Shared by the projection and the Mihomo/registry
/// renderer so list UIs and kernel configs address identical names.
/// Fails closed on a display failure (fail-closed like the projection's
/// old `collect::<Result>`; the Mihomo path's old `filter_map`+`zip`
/// truncation arm is dead — protocol labels are ≤11 bytes against a
/// 32-byte cap, so `display()` cannot fail — and is not preserved).
pub fn display_tags(nodes: &[DialableNode]) -> Result<Vec<String>, PipelineError> {
    let names = nodes
        .iter()
        .map(|node| {
            node.display(true, None)
                .map(|display| display.name().as_str().to_owned())
                .map_err(|_| PipelineError::Display)
        })
        .collect::<Result<Vec<_>, _>>()?;
    Ok(dedupe_name_tags(names.iter().map(String::as_str)))
}

/// Assembles the redacted projection from deduped nodes plus their tags.
/// `tags` must align 1:1 with `nodes` (both come from one [`display_tags`]
/// call); a length mismatch fails closed rather than mislabeling nodes.
pub fn assemble_projection(
    nodes: &[DialableNode],
    tags: &[String],
    rejected_lines: usize,
    ssr_skipped: usize,
) -> Result<SubscriptionProjection, PipelineError> {
    if tags.len() != nodes.len() {
        return Err(PipelineError::Display);
    }
    let display = nodes
        .iter()
        .zip(tags.iter())
        .map(|(node, tag)| {
            let name = NodeDisplayName::new(tag.clone()).map_err(|_| PipelineError::Display)?;
            let protocol = NodeProtocolLabel::new(node.protocol().label().to_owned())
                .map_err(|_| PipelineError::Display)?;
            Ok::<_, PipelineError>(DisplayNode::new(node.id(), name, protocol, true, None))
        })
        .collect::<Result<Vec<_>, _>>()?;
    let nodes = SnapshotNodes::try_from_vec(display)?;
    Ok(SubscriptionProjection {
        nodes,
        rejected_lines,
        ssr_skipped,
    })
}

/// Assigns deterministic `#N` suffixes to repeated display names in first-seen
/// order, keeping human-readable names unique without losing the base name.
///
/// [`display_tags`] funnels through here, so the projection (list UIs) and
/// the Mihomo/registry renderer number suffixes identically for every node.
///
/// the suffix budget is reserved *before* appending — a base name
/// at the 256-byte display cap used to become a 259-byte tag that every
/// downstream `NodeDisplayName::new`/`MihomoProxyTag::new` rejected (whole
/// refresh failed, or nodes were silently dropped on the Mihomo path).
pub fn dedupe_name_tags<'a>(names: impl IntoIterator<Item = &'a str>) -> Vec<String> {
    let mut counts: std::collections::HashMap<&str, usize> = std::collections::HashMap::new();
    names
        .into_iter()
        .map(|name| {
            let seen = counts.entry(name).or_insert(0);
            *seen += 1;
            if *seen == 1 {
                name.to_owned()
            } else {
                let suffix = format!(" #{seen}");
                let budget = crate::domain::NODE_DISPLAY_NAME_MAX_BYTES.saturating_sub(suffix.len());
                let mut base: String = name
                    .chars()
                    .scan(0_usize, |used, ch| {
                        let width = ch.len_utf8();
                        if *used + width <= budget {
                            *used += width;
                            Some(ch)
                        } else {
                            None
                        }
                    })
                    .collect();
                base.push_str(&suffix);
                base
            }
        })
        .collect()
}

/// Deduplicates by complete canonical NodeId, preserving first input order.
/// Deduplicates nodes by canonical NodeId and optionally by dial endpoint (`host:port`),
/// preserving first-seen input order.
pub fn dedupe_with_options(
    nodes: Vec<DialableNode>,
    dedupe_endpoints: bool,
) -> Result<DedupeResult, PipelineError> {
    if nodes.len() > MAX_SUBSCRIPTION_NODES {
        return Err(PipelineError::TooManyNodes);
    }
    let mut unique_ids = std::collections::BTreeSet::new();
    let mut unique_endpoints = std::collections::BTreeSet::new();
    let mut ordered = Vec::new();
    let mut duplicate_count = 0;

    for node in nodes {
        let id = node.id();
        let endpoint_key = format!(
            "{}:{}",
            node.endpoint().host().as_str(),
            node.endpoint().port().get()
        );

        if unique_ids.contains(&id) {
            duplicate_count += 1;
            continue;
        }
        if dedupe_endpoints && unique_endpoints.contains(&endpoint_key) {
            duplicate_count += 1;
            continue;
        }

        unique_ids.insert(id);
        if dedupe_endpoints {
            unique_endpoints.insert(endpoint_key);
        }
        ordered.push(node);
    }

    let nodes = SubscriptionNodes::try_from_vec(ordered)?;
    Ok(DedupeResult {
        nodes,
        duplicate_count,
    })
}

/// Deduplicates by canonical NodeId and endpoint (default).
pub fn dedupe(nodes: Vec<DialableNode>) -> Result<DedupeResult, PipelineError> {
    dedupe_with_options(nodes, true)
}

/// Parses and projects a subscription document, actively applying include/exclude regex
/// filters, rename transformations, and endpoint deduplication.
pub fn parse_document_to_display_with_transform(
    document: &SubscriptionDocument,
    subscription: SubscriptionId,
    transform: Option<&SubscriptionTransformEngine>,
    dedupe_endpoints: bool,
) -> Result<SubscriptionProjection, PipelineError> {
    let mut parsed = parse_document_dialable_lossy(document, subscription)?;

    // Apply transform engine (filter include/exclude patterns and rename nodes)
    if let Some(engine) = transform {
        parsed.nodes = engine.apply_to_nodes(parsed.nodes);
        if parsed.nodes.is_empty() {
            return Err(PipelineError::Uri);
        }
    }

    validate_chains(&parsed.nodes).map_err(PipelineError::Chain)?;
    let deduped = dedupe_with_options(parsed.nodes, dedupe_endpoints)?;
    let tags = display_tags(deduped.nodes.as_slice())?;
    assemble_projection(
        deduped.nodes.as_slice(),
        &tags,
        parsed.rejected_lines,
        parsed.ssr_skipped,
    )
}

#[cfg(test)]
mod tests {
    use super::*;

    fn sub() -> SubscriptionId {
        SubscriptionId::from_bytes([0; 16])
    }

    fn ss_uri(name: &str) -> String {
        use base64::Engine as _;
        let credential =
            base64::engine::general_purpose::STANDARD.encode("aes-256-gcm:pw".as_bytes());
        format!("ss://{credential}@192.0.2.1:8388#{name}")
    }

    #[test]
    fn dedupe_suffix_stays_within_the_display_byte_cap() {
        // two 256-byte identical names must not produce a
        // rejectable (over-cap) suffixed tag.
        let long = "我".repeat(85); // 255 bytes
        let long = format!("{long}x"); // 256 bytes, at NODE_DISPLAY_NAME_MAX_BYTES
        let tags = dedupe_name_tags([long.as_str(), long.as_str()]);
        assert!(tags[1].len() <= crate::domain::NODE_DISPLAY_NAME_MAX_BYTES);
        assert!(tags[1].ends_with(" #2"));
        assert!(std::str::from_utf8(tags[1].as_bytes()).is_ok());
    }

    #[test]
    fn ssr_lines_are_skipped_and_counted_in_mixed_documents() {
        let body = format!("{}\nssr://cGxhY2Vob2xkZXI\n", ss_uri("keep"));
        let projection = parse_uri_body_to_display_lossy(body.as_bytes(), sub())
            .unwrap_or_else(|e| panic!("parse failed: {e:?}"));
        assert_eq!(projection.nodes.len(), 1);
        assert_eq!(projection.rejected_lines, 0);
        assert_eq!(projection.ssr_skipped, 1);
    }

    #[test]
    fn pure_ssr_documents_report_ssr_only() {
        let body = "ssr://cGxhY2Vob2xkZXI\nssr://YW5vdGhlcg\n";
        let result = parse_uri_body_to_display_lossy(body.as_bytes(), sub());
        assert!(matches!(result, Err(PipelineError::SsrOnly(2))));
    }

    /// A minimal Clash YAML subscription with two representable proxies.
    fn clash_yaml_body() -> Vec<u8> {
        br#"proxies:
  - name: "hk-01"
    type: ss
    server: example.com
    port: 8388
    cipher: aes-128-gcm
    password: secret
  - name: "jp-02"
    type: trojan
    server: example.org
    port: 443
    password: pass
"#
        .to_vec()
    }

    #[test]
    fn clash_yaml_lossy_projection_reports_no_rejected_lines() -> Result<(), String> {
        let id = SubscriptionId::from_bytes([10; 16]);
        let projection =
            parse_uri_body_to_display_lossy(&clash_yaml_body(), id).map_err(|e| format!("{e:?}"))?;
        assert_eq!(projection.nodes.len(), 2);
        assert_eq!(projection.rejected_lines, 0);
        Ok(())
    }
    #[test]
    fn supplied_subscription_projects_redacted_nodes() {
        let body = include_bytes!("../../../fixtures/subscription-20260803.txt").to_vec();
        let projection = parse_uri_body_to_display_lossy(&body, SubscriptionId::from_bytes([3; 16]));
        assert!(projection.is_ok());
        let projection = projection.map_or_else(|_| SnapshotNodes::new(), |value| value.nodes);
        assert!(!projection.is_empty());
    }

    #[test]
    fn duplicate_names_receive_deterministic_numeric_suffixes() {
        let names = ["a", "b", "a", "a", "b", "c"];
        let tags = dedupe_name_tags(names.iter().copied());
        assert_eq!(
            tags,
            vec![
                "a".to_owned(),
                "b".to_owned(),
                "a #2".to_owned(),
                "a #3".to_owned(),
                "b #2".to_owned(),
                "c".to_owned()
            ]
        );
    }

    #[test]
    fn dedupe_filters_duplicate_endpoints_and_ids() {
        let n1 = parse_any_proxy_uri(&ss_uri("Node-01"), sub()).unwrap();
        let n2 = parse_any_proxy_uri(&ss_uri("Node-02"), sub()).unwrap();

        let result = dedupe_with_options(vec![n1, n2], true).unwrap();
        assert_eq!(result.nodes.len(), 1, "Duplicate endpoint must be deduplicated");
        assert_eq!(result.duplicate_count, 1);
    }

    #[test]
    fn transform_engine_applied_during_document_parsing() {
        let lines = vec![
            ss_uri("HK - Premium 01"),
            ss_uri("US - Free 02"),
            ss_uri("HK - Expired 03"),
        ];
        let doc = SubscriptionDocument::UriLines {
            source_url: None,
            lines: lines.into_iter().map(|s| crate::domain::BoundedText::new(s).unwrap()).collect(),
        };
        let engine = SubscriptionTransformEngine::new()
            .with_include("HK")
            .with_exclude("Expired")
            .with_rename("HK", "Hong Kong");

        let projection = parse_document_to_display_with_transform(&doc, sub(), Some(&engine), false).unwrap();
        assert_eq!(projection.nodes.len(), 1);
        assert_eq!(projection.nodes[0].name.as_str(), "Hong Kong - Premium 01");
    }
}
