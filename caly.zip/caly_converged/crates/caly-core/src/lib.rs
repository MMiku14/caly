//! caly-core
//!
//! Consolidated module containing domain, ports, dns, subscription, profile, configstore.

#![forbid(unsafe_code)]
#![cfg_attr(test, allow(clippy::unwrap_used, clippy::expect_used, clippy::panic, clippy::todo, clippy::unimplemented, clippy::unreachable))]

pub mod domain;
pub mod ports;
pub mod dns;
pub mod subscription;
pub mod profile;
pub mod configstore;

pub mod platform;
