//! caly-daemon
//!
//! Consolidated module containing platform, application, backends, composition, protocol, server.

#![forbid(unsafe_code)]
#![cfg_attr(test, allow(clippy::unwrap_used, clippy::expect_used, clippy::panic, clippy::todo, clippy::unimplemented, clippy::unreachable))]

pub mod platform;
pub mod application;
pub mod backends;
pub mod composition;
pub mod protocol;
pub mod server;
