//! Transparent Gateway Router & LAN Management Subsystem.
//!
//! Controls Linux kernel IP packet forwarding, anti-leak ICMP redirect disabling,
//! Proxy ARP, port 53 DNS hijacking, TProxy socket redirection, and real-time
//! LAN client discovery via `/proc/net/arp`.

use std::collections::HashMap;
use std::fs;
use std::net::{IpAddr, Ipv4Addr};
use std::process::Command;
use serde::{Deserialize, Serialize};

use caly_core::domain::gateway::{ArpEntry, ClientPolicyKind, GatewayDevice, GatewayPolicyRule};
use crate::PlatformFailure;

/// Gateway configuration and routing rules.
#[derive(Clone, Debug, Default, Eq, PartialEq, Serialize, Deserialize)]
pub struct GatewayConfig {
    pub enabled: bool,
    pub lan_interface: Option<String>,
    pub ip_forwarding: bool,
    pub disable_icmp_redirects: bool,
    pub proxy_arp: bool,
    pub dns_hijack: bool,
    pub tproxy_port: Option<u16>,
    pub masquerade: bool,
    pub preserve_client_ip: bool,
    pub client_policies: Vec<GatewayPolicyRule>,
}

/// Runtime status of the Gateway subsystem.
#[derive(Clone, Debug, Default, Serialize, Deserialize)]
pub struct GatewayStatus {
    pub enabled: bool,
    pub lan_interface: Option<String>,
    pub ip_forwarding_active: bool,
    pub icmp_redirects_disabled: bool,
    pub proxy_arp_active: bool,
    pub dns_hijack_active: bool,
    pub tproxy_port: Option<u16>,
    pub active_rules_count: usize,
    pub discovered_clients_count: usize,
}

/// Transparent Gateway Manager managing kernel forwarding and firewall rules.
pub struct GatewayManager {
    config: GatewayConfig,
    tun_interface: String,
    applied_rules: Vec<Vec<String>>,
    original_sysctl: HashMap<String, String>,
}

impl GatewayManager {
    pub fn new(config: GatewayConfig, tun_interface: impl Into<String>) -> Self {
        Self {
            config,
            tun_interface: tun_interface.into(),
            applied_rules: Vec::new(),
            original_sysctl: HashMap::new(),
        }
    }

    /// Enables kernel packet forwarding and activates gateway rules.
    pub fn enable_gateway(&mut self) -> Result<(), PlatformFailure> {
        if !self.config.enabled {
            return Ok(());
        }

        // 1. Enable IPv4 and IPv6 packet forwarding
        if self.config.ip_forwarding {
            self.set_sysctl("/proc/sys/net/ipv4/ip_forward", "1");
            self.set_sysctl("/proc/sys/net/ipv6/conf/all/forwarding", "1");
        }

        // 2. Disable ICMP redirects to prevent bypass leaks in gateway mode
        if self.config.disable_icmp_redirects {
            self.set_sysctl("/proc/sys/net/ipv4/conf/all/send_redirects", "0");
            self.set_sysctl("/proc/sys/net/ipv4/conf/all/accept_redirects", "0");
            self.set_sysctl("/proc/sys/net/ipv4/conf/default/send_redirects", "0");
            self.set_sysctl("/proc/sys/net/ipv4/conf/default/accept_redirects", "0");
            if let Some(lan) = &self.config.lan_interface {
                self.set_sysctl(&format!("/proc/sys/net/ipv4/conf/{lan}/send_redirects"), "0");
            }
        }

        // 3. Enable proxy ARP if requested (single-subnet gateway)
        if self.config.proxy_arp {
            self.set_sysctl("/proc/sys/net/ipv4/conf/all/proxy_arp", "1");
        }

        // 4. Setup forwarding rules between LAN interface and TUN device
        if let Some(lan) = &self.config.lan_interface {
            let tun = &self.tun_interface;
            self.run_iptables(&["-A", "FORWARD", "-i", lan, "-o", tun, "-j", "ACCEPT"])?;
            self.run_iptables(&[
                "-A", "FORWARD", "-i", tun, "-o", lan, "-m", "state", "--state", "RELATED,ESTABLISHED", "-j", "ACCEPT",
            ])?;

            // 5. DNS Hijack: Redirect port 53 UDP & TCP to local DNS resolver
            if self.config.dns_hijack {
                self.run_iptables(&[
                    "-t", "nat", "-A", "PREROUTING", "-i", lan, "-p", "udp", "--dport", "53", "-j", "REDIRECT", "--to-ports", "53",
                ])?;
                self.run_iptables(&[
                    "-t", "nat", "-A", "PREROUTING", "-i", lan, "-p", "tcp", "--dport", "53", "-j", "REDIRECT", "--to-ports", "53",
                ])?;
            }

            // 6. TProxy rule if port configured
            if let Some(tproxy_port) = self.config.tproxy_port {
                let port_s = tproxy_port.to_string();
                self.run_iptables(&[
                    "-t", "mangle", "-A", "PREROUTING", "-i", lan, "-p", "tcp", "-m", "socket", "--transparent", "-j", "MARK", "--set-mark", "0x2022",
                ])?;
                self.run_iptables(&[
                    "-t", "mangle", "-A", "PREROUTING", "-i", lan, "-p", "tcp", "-j", "TPROXY", "--tproxy-mark", "0x2022/0x2022", "--on-port", &port_s,
                ])?;
            }
        }

        // 7. Setup NAT masquerade if enabled
        if self.config.masquerade {
            self.run_iptables(&[
                "-t", "nat", "-A", "POSTROUTING", "-o", &self.tun_interface, "-j", "MASQUERADE",
            ])?;
        }

        Ok(())
    }

    /// Safely reverts all injected firewall rules and restores kernel sysctl parameters.
    pub fn teardown(&mut self) {
        while let Some(rule) = self.applied_rules.pop() {
            let mut del_args = Vec::with_capacity(rule.len());
            for token in &rule {
                if token == "-A" {
                    del_args.push("-D".to_owned());
                } else {
                    del_args.push(token.clone());
                }
            }
            let str_refs: Vec<&str> = del_args.iter().map(String::as_str).collect();
            let _ = Command::new("iptables").args(&str_refs).status();
        }

        // Restore original sysctls
        for (path, val) in &self.original_sysctl {
            let _ = fs::write(path, val);
        }
        self.original_sysctl.clear();
    }

    /// Scans `/proc/net/arp` and returns discovered LAN client devices.
    pub fn discover_lan_devices(&self) -> Vec<GatewayDevice> {
        let arp_entries = Self::read_arp_table();
        let mut devices = Vec::new();

        for entry in arp_entries {
            if entry.mac == "00:00:00:00:00:00" || entry.flags == 0 {
                continue;
            }
            // Check if this matches a configured client policy
            let ip_str = entry.ip.to_string();
            let policy = self.config.client_policies.iter().find_map(|rule| {
                if rule.target == ip_str || rule.target == entry.mac {
                    Some(rule.policy)
                } else {
                    None
                }
            }).unwrap_or(ClientPolicyKind::Rule);

            let dev = GatewayDevice::new(entry.ip)
                .with_mac(entry.mac)
                .with_policy(policy);
            devices.push(dev);
        }

        devices
    }

    /// Reads and parses `/proc/net/arp`.
    pub fn read_arp_table() -> Vec<ArpEntry> {
        let content = match fs::read_to_string("/proc/net/arp") {
            Ok(c) => c,
            Err(_) => return Vec::new(),
        };

        let mut entries = Vec::new();
        // Skip header: IP address HW type Flags HW address Mask Device
        for line in content.lines().skip(1) {
            let parts: Vec<&str> = line.split_whitespace().collect();
            if parts.len() < 6 {
                continue;
            }
            if let Ok(ip) = parts[0].parse::<IpAddr>() {
                let hw_type = u32::from_str_radix(parts[1].trim_start_matches("0x"), 16).unwrap_or(1);
                let flags = u32::from_str_radix(parts[2].trim_start_matches("0x"), 16).unwrap_or(0);
                entries.push(ArpEntry {
                    ip,
                    hw_type,
                    flags,
                    mac: parts[3].to_ascii_lowercase(),
                    mask: parts[4].to_owned(),
                    device: parts[5].to_owned(),
                });
            }
        }
        entries
    }

    /// Queries live gateway status.
    pub fn status(&self) -> GatewayStatus {
        let ip_fwd = fs::read_to_string("/proc/sys/net/ipv4/ip_forward")
            .map_or(false, |v| v.trim() == "1");
        let icmp_redir = fs::read_to_string("/proc/sys/net/ipv4/conf/all/send_redirects")
            .map_or(false, |v| v.trim() == "0");
        let proxy_arp = fs::read_to_string("/proc/sys/net/ipv4/conf/all/proxy_arp")
            .map_or(false, |v| v.trim() == "1");

        let clients = self.discover_lan_devices();

        GatewayStatus {
            enabled: self.config.enabled,
            lan_interface: self.config.lan_interface.clone(),
            ip_forwarding_active: ip_fwd,
            icmp_redirects_disabled: icmp_redir,
            proxy_arp_active: proxy_arp,
            dns_hijack_active: self.config.dns_hijack && !self.applied_rules.is_empty(),
            tproxy_port: self.config.tproxy_port,
            active_rules_count: self.applied_rules.len(),
            discovered_clients_count: clients.len(),
        }
    }

    fn set_sysctl(&mut self, path: &str, value: &str) {
        if let Ok(orig) = fs::read_to_string(path) {
            if !self.original_sysctl.contains_key(path) {
                self.original_sysctl.insert(path.to_owned(), orig.trim().to_owned());
            }
        }
        let _ = fs::write(path, value);
    }

    fn run_iptables(&mut self, args: &[&str]) -> Result<(), PlatformFailure> {
        let str_args: Vec<String> = args.iter().map(|&s| s.to_owned()).collect();
        let status = Command::new("iptables")
            .args(args)
            .status()
            .map_err(|e| PlatformFailure::from_message(format!("cannot invoke iptables: {e}")))?;

        if status.success() {
            self.applied_rules.push(str_args);
            Ok(())
        } else {
            Err(PlatformFailure::from_message(format!(
                "iptables command returned non-zero status: {status}"
            )))
        }
    }
}

impl Drop for GatewayManager {
    fn drop(&mut self) {
        self.teardown();
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_gateway_manager_creation() {
        let cfg = GatewayConfig {
            enabled: true,
            lan_interface: Some("eth0".into()),
            ip_forwarding: true,
            disable_icmp_redirects: true,
            proxy_arp: false,
            dns_hijack: true,
            tproxy_port: Some(7893),
            masquerade: true,
            preserve_client_ip: true,
            client_policies: Vec::new(),
        };
        let mgr = GatewayManager::new(cfg, "caly0");
        assert_eq!(mgr.tun_interface, "caly0");
    }
}
