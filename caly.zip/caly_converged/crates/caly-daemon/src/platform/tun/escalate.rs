
/// Validates an argument passed to privileged `ip` execution to prevent command injection.
/// Enforces strict argument whitelisting for `sudo -n ip` or `pkexec ip`:
/// - Whitelisted operations: `tuntap add/del`, `link set ... up/down/mtu`, `addr add/del`, `route add/del`
/// - Validates device names (e.g. `caly0`) against `^[a-zA-Z0-9_-]{1,15}$`
/// - Rejects any argument containing shell metacharacters (`;|&<>$\`\n`)
pub fn validate_whitelisted_ip_command(args: &[&str]) -> Result<(), PlatformFailure> {
    if args.is_empty() {
        return Err(failure("empty ip command rejected"));
    }

    // 1. Reject any shell metacharacters in any argument
    for &arg in args {
        if arg.chars().any(|c| matches!(c, ';' | '&' | '|' | '<' | '>' | '$' | '`' | '\n' | '\r' | '\t')) {
            return Err(failure(&format!("insecure shell metacharacter detected in TUN command argument: {arg}")));
        }
    }

    // Helper for device name regex validation: ^[a-zA-Z0-9_-]{1,15}$
    let is_valid_device_name = |name: &str| -> bool {
        !name.is_empty()
            && name.len() <= 15
            && name.chars().all(|c| c.is_ascii_alphanumeric() || c == '_' || c == '-')
    };

    // 2. Enforce strictly whitelisted TUN operations
    match args[0] {
        "tuntap" => {
            if args.len() < 2 || !matches!(args[1], "add" | "del") {
                return Err(failure(&format!("unsupported tuntap operation: {:?}", args)));
            }
            for i in 0..args.len() {
                if (args[i] == "dev" || args[i] == "name") && i + 1 < args.len() {
                    if !is_valid_device_name(args[i + 1]) {
                        return Err(failure(&format!("invalid TUN device name: {}", args[i + 1])));
                    }
                }
            }
        }
        "link" => {
            if args.len() < 2 || args[1] != "set" {
                return Err(failure(&format!("unsupported link operation: {:?}", args)));
            }
            for i in 0..args.len() {
                if args[i] == "dev" && i + 1 < args.len() {
                    if !is_valid_device_name(args[i + 1]) {
                        return Err(failure(&format!("invalid TUN device name: {}", args[i + 1])));
                    }
                }
            }
        }
        "addr" => {
            if args.len() < 2 || !matches!(args[1], "add" | "del") {
                return Err(failure(&format!("unsupported addr operation: {:?}", args)));
            }
            for i in 0..args.len() {
                if args[i] == "dev" && i + 1 < args.len() {
                    if !is_valid_device_name(args[i + 1]) {
                        return Err(failure(&format!("invalid TUN device name: {}", args[i + 1])));
                    }
                }
            }
        }
        "route" => {
            if args.len() < 2 || !matches!(args[1], "add" | "del") {
                return Err(failure(&format!("unsupported route operation: {:?}", args)));
            }
            for i in 0..args.len() {
                if args[i] == "dev" && i + 1 < args.len() {
                    if !is_valid_device_name(args[i + 1]) {
                        return Err(failure(&format!("invalid TUN device name: {}", args[i + 1])));
                    }
                }
            }
        }
        other => {
            return Err(failure(&format!("unwhitelisted ip subcommand: {other}")));
        }
    }
    Ok(())
}

//! Privilege escalation pipeline for the TUN backend.
//!
//! the TUN backend's `run_ip` /
//! `run_ip_sequence` / `escalation_prefixes` /
//! `attempt` / `attempt_batch` helpers used to
//! live in `linux.rs` (an 871-line monolith that
//! exceeded the 400-line hard cap — S4.1
//! advisory). The escalation policy and the
//! per-attempt / per-batch runners extract into
//! this file so the engage / restore pipelines
//! in `device.rs` can drive the right policy
//! without dragging the 200-line per-attempt
//! mechanics with them.
//!
//! The policy: try the `ip` command directly
//! first (a daemon with `CAP_NET_ADMIN` never
//! prompts), then escalate through the configured
//! chain (`pkexec` for desktop polkit, then
//! `sudo -n` for headless / CI). Batching the
//! remaining commands as one `sh -c` script keeps
//! the operator's `pkexec` prompts to one per
//! engage rather than one per `ip` subcommand.

use std::path::PathBuf;

use caly_core::domain::BoundedText;

use crate::PlatformFailure;
use crate::command::{CommandArguments, CommandRequest, CommandRunner};

use super::capability::{failure, failure_with_detail};
use super::script::{build_arguments, build_arguments_strs, build_batch_script, first_line};

/// Direct timeout for one `ip` command; escalation
/// prompts may wait for the user, so escalated
/// attempts get a longer budget.
pub(super) const DIRECT_TIMEOUT: std::time::Duration = std::time::Duration::from_secs(3);
pub(super) const ESCALATED_TIMEOUT: std::time::Duration = std::time::Duration::from_secs(60);

/// the privilege-escalation policy the
/// TUN backend threads through every `ip`
/// command. The pre-Round 31 enum lived at the
/// top of `linux.rs`; the extraction into this
/// file keeps the policy declaration next to the
/// runners that consume it.
#[derive(Clone, Copy, Debug, Default, Eq, PartialEq)]
pub enum TunEscalation {
    /// Direct first, then `pkexec` (desktop polkit prompt), then `sudo -n`.
    #[default]
    Auto,
    /// Escalate only through `pkexec`.
    Pkexec,
    /// Escalate only through passwordless `sudo -n`.
    Sudo,
    /// Never escalate; report remediation instead.
    None,
}

impl TunEscalation {
    /// stable diagnostic label. The
    /// pre-Round 31 inline `label()` method
    /// lived on the same enum in `linux.rs`;
    /// the extraction keeps the test
    /// `escalation_labels_are_stable` green.
    pub const fn label(self) -> &'static str {
        match self {
            Self::Auto => "auto",
            Self::Pkexec => "pkexec",
            Self::Sudo => "sudo",
            Self::None => "none",
        }
    }
}

/// runs one `ip` command, escalating
/// through the policy when the direct attempt
/// fails (typically a missing `CAP_NET_ADMIN`).
pub(super) fn run_ip(
    runner: &mut impl CommandRunner,
    escalation: TunEscalation,
    values: Vec<&str>,
) -> Result<(), PlatformFailure> {
    validate_whitelisted_ip_command(&values)?;
    let arguments = build_arguments(&values)?;
    // chain failures so the returned error is the LAST attempt's
    // real cause (a cancelled pkexec prompt, a missing sudo binary), not the
    // stale "operation not permitted" from the direct try that shadowed the
    // actual escalation failure behind a misleading remediation.
    let mut last = match attempt(runner, "ip", &[], &arguments, DIRECT_TIMEOUT) {
        Ok(()) => return Ok(()),
        Err(error) => error,
    };
    let mut escalated = false;
    for (executable, prefix) in escalation_prefixes(escalation) {
        escalated = true;
        match attempt(runner, executable, prefix, &arguments, ESCALATED_TIMEOUT) {
            Ok(()) => return Ok(()),
            Err(error) => last = error,
        }
    }
    if escalated {
        Err(failure_with_detail(last.message.as_str()))
    } else {
        Err(last)
    }
}

/// runs an ordered sequence of `ip`
/// commands, trying every command directly first
/// and, on the first direct failure, escalating
/// the REMAINING commands as one `sh -c` batch.
/// Batching matters: without it, an escalated
/// engage prompts for the root password once per
/// `ip` command (up to four prompts); with it
/// the user authenticates at most once.
pub(super) fn run_ip_sequence(
    runner: &mut impl CommandRunner,
    escalation: TunEscalation,
    commands: &[Vec<String>],
) -> Result<(), PlatformFailure> {
    // Phase 1: direct attempts in order; commands before the first failure
    // were applied without privileges and must not run again escalated.
    let mut pending_from = 0_usize;
    for (index, command) in commands.iter().enumerate() {
        let arguments = build_arguments_strs(command)?;
        if attempt(runner, "ip", &[], &arguments, DIRECT_TIMEOUT).is_err() {
            pending_from = index;
            break;
        }
        pending_from = index + 1;
    }
    if pending_from == commands.len() {
        return Ok(());
    }
    let script = build_batch_script(&commands[pending_from..])?;
    let mut script_argument = CommandArguments::new();
    let script_text =
        BoundedText::new(script).map_err(|_| failure("TUN escalation script is too long"))?;
    script_argument
        .try_push(script_text)
        .map_err(|_| failure("TUN escalation argument list is full"))?;
    let mut escalated = false;
    for (executable, prefix) in escalation_prefixes(escalation) {
        escalated = true;
        if attempt_batch(
            runner,
            executable,
            prefix,
            &script_argument,
            ESCALATED_TIMEOUT,
        )
        .is_ok()
        {
            return Ok(());
        }
    }
    if escalated {
        Err(failure_with_detail(
            "Linux ip TUN commands failed and every escalation attempt failed",
        ))
    } else {
        Err(failure(
            "Linux ip TUN commands failed and no escalation policy is configured",
        ))
    }
}

/// ordered escalation candidates for a
/// policy. Spawn failures (missing binary) are
/// handled by the caller skipping a failed
/// attempt, so availability needs no separate
/// probing.
pub(super) fn escalation_prefixes(
    policy: TunEscalation,
) -> Vec<(&'static str, &'static [&'static str])> {
    match policy {
        TunEscalation::Auto => vec![("pkexec", &[] as &[_]), ("sudo", &["-n"])],
        TunEscalation::Pkexec => vec![("pkexec", &[] as &[_])],
        TunEscalation::Sudo => vec![("sudo", &["-n"])],
        TunEscalation::None => Vec::new(),
    }
}

/// executes one attempt —
/// `executable [prefix...] ip [arguments...]`.
pub(super) fn attempt(
    runner: &mut impl CommandRunner,
    executable: &str,
    prefix: &[&str],
    arguments: &CommandArguments,
    timeout: std::time::Duration,
) -> Result<(), PlatformFailure> {
    let mut full = CommandArguments::new();
    for value in prefix {
        let argument = BoundedText::new((*value).to_owned())
            .map_err(|_| failure("TUN escalation argument is too long"))?;
        full.try_push(argument)
            .map_err(|_| failure("TUN escalation argument list is full"))?;
    }
    // The `ip` program name is the first argument once a helper (pkexec/sudo)
    // fronts the command; it is the executable for the direct attempt.
    let direct = executable == "ip" && prefix.is_empty();
    if !direct {
        let ip_argument = BoundedText::new("ip".to_owned())
            .map_err(|_| failure("TUN escalation argument is too long"))?;
        full.try_push(ip_argument)
            .map_err(|_| failure("TUN escalation argument list is full"))?;
    }
    for argument in arguments {
        validate_safe_ip_argument(argument.as_str())?;
        full.try_push(argument.clone())
            .map_err(|_| failure("TUN command argument list is full"))?;
    }
    let program = if direct { "ip" } else { executable };
    let result = runner.run_bounded(CommandRequest {
        executable: PathBuf::from(program),
        arguments: full,
        timeout,
    })?;
    if result.exit_code == Some(0) {
        Ok(())
    } else {
        let detail = first_line(&result.stderr);
        Err(failure(&format!("Linux ip TUN command failed{detail}")))
    }
}

/// executes one escalated `sh -c <script>`
/// batch — the single password prompt that
/// replaces per-command escalation during a TUN
/// engage.
pub(super) fn attempt_batch(
    runner: &mut impl CommandRunner,
    executable: &str,
    prefix: &[&str],
    script: &CommandArguments,
    timeout: std::time::Duration,
) -> Result<(), PlatformFailure> {
    let mut full = CommandArguments::new();
    for value in prefix {
        let argument = BoundedText::new((*value).to_owned())
            .map_err(|_| failure("TUN escalation argument is too long"))?;
        full.try_push(argument)
            .map_err(|_| failure("TUN escalation argument list is full"))?;
    }
    for value in ["sh", "-c"] {
        let argument = BoundedText::new(value.to_owned())
            .map_err(|_| failure("TUN escalation argument is too long"))?;
        full.try_push(argument)
            .map_err(|_| failure("TUN escalation argument list is full"))?;
    }
    for argument in script {
        full.try_push(argument.clone())
            .map_err(|_| failure("TUN command argument list is full"))?;
    }
    let result = runner.run_bounded(CommandRequest {
        executable: PathBuf::from(executable),
        arguments: full,
        timeout,
    })?;
    if result.exit_code == Some(0) {
        Ok(())
    } else {
        let detail = first_line(&result.stderr);
        Err(failure(&format!(
            "Linux ip TUN batch command failed{detail}"
        )))
    }
}

#[cfg(test)]
mod escalate_tests {
    //! the escalation policy + the
    //! per-attempt runners are the single source
    //! of truth for the TUN backend's
    //! "one-password-prompt" guarantee. The tests
    //! pin the policy labels (the JSON error
    //! envelope surfaces `tun.escalation` to
    //! `doctor` / `set`); the batching behaviour
    //! is exercised transitively by the
    //! `engage_without_privileges_escalates_one_batch_not_per_command`
    //! test in `device.rs`.

    use super::TunEscalation;

    #[test]
    fn escalation_labels_are_stable() {
        assert_eq!(TunEscalation::Auto.label(), "auto");
        assert_eq!(TunEscalation::Pkexec.label(), "pkexec");
        assert_eq!(TunEscalation::Sudo.label(), "sudo");
        assert_eq!(TunEscalation::None.label(), "none");
    }

    /// The escalation chain shape is the
    /// operator-visible contract: `Auto`
    /// tries `pkexec` before `sudo -n`,
    /// `Pkexec` / `Sudo` are 1-element
    /// chains, `None` is empty. A future
    /// change to the order (e.g. "try
    /// passwordless sudo before polkit")
    /// would land in `escalation_prefixes`
    /// and the test would surface the
    /// change.
    #[test]
    fn escalation_prefixes_match_documented_order() {
        use super::escalation_prefixes;
        let auto = escalation_prefixes(TunEscalation::Auto);
        assert_eq!(auto.len(), 2);
        assert_eq!(auto[0].0, "pkexec");
        assert_eq!(auto[1].0, "sudo");

        let pkexec = escalation_prefixes(TunEscalation::Pkexec);
        assert_eq!(pkexec.len(), 1);
        assert_eq!(pkexec[0].0, "pkexec");

        let sudo = escalation_prefixes(TunEscalation::Sudo);
        assert_eq!(sudo.len(), 1);
        assert_eq!(sudo[0].0, "sudo");
        assert_eq!(sudo[0].1, &["-n"]);

        let none = escalation_prefixes(TunEscalation::None);
        assert!(none.is_empty());
    }

    #[test]
    fn whitelisted_ip_command_allows_safe_tun_operations() {
        use super::validate_whitelisted_ip_command;
        assert!(validate_whitelisted_ip_command(&["tuntap", "add", "dev", "caly0", "mode", "tun"]).is_ok());
        assert!(validate_whitelisted_ip_command(&["tuntap", "del", "dev", "caly0", "mode", "tun"]).is_ok());
        assert!(validate_whitelisted_ip_command(&["link", "set", "dev", "caly0", "up"]).is_ok());
        assert!(validate_whitelisted_ip_command(&["link", "set", "dev", "caly0", "mtu", "9000"]).is_ok());
        assert!(validate_whitelisted_ip_command(&["addr", "add", "198.18.0.1/30", "dev", "caly0"]).is_ok());
        assert!(validate_whitelisted_ip_command(&["route", "add", "198.18.0.0/16", "dev", "caly0"]).is_ok());
    }

    #[test]
    fn whitelisted_ip_command_rejects_insecure_commands() {
        use super::validate_whitelisted_ip_command;
        // Shell metacharacters
        assert!(validate_whitelisted_ip_command(&["tuntap", "add", "dev", "caly0; rm -rf /"]).is_err());
        assert!(validate_whitelisted_ip_command(&["link", "set", "dev", "caly0 | sh"]).is_err());
        assert!(validate_whitelisted_ip_command(&["link", "set", "dev", "root"]).is_err());

        // Invalid device names
        assert!(validate_whitelisted_ip_command(&["tuntap", "add", "dev", "caly/tmp/subagent_run_call_682676.sh"]).is_err());
        assert!(validate_whitelisted_ip_command(&["tuntap", "add", "dev", "this_name_is_way_too_long_for_linux_tun"]).is_err());

        // Unwhitelisted operations
        assert!(validate_whitelisted_ip_command(&["netns", "add", "foo"]).is_err());
        assert!(validate_whitelisted_ip_command(&["link", "delete", "caly0"]).is_err());
    }

}
