//! Real-time statistics and throughput metrics for virtual TUN interfaces (e.g. `caly0`).
//!
//! Directly reads the Linux kernel `/sys/class/net/<iface>/statistics/` metrics,
//! providing zero-overhead, sub-millisecond hardware-level network telemetry.

use std::fs;
use std::path::PathBuf;
use serde::{Deserialize, Serialize};

/// Kernel network device statistics.
#[derive(Clone, Debug, Default, Eq, PartialEq, Serialize, Deserialize)]
pub struct TunInterfaceStats {
    /// Interface name (e.g. "caly0").
    pub interface: String,
    /// Interface operational state ("up", "down", "unknown").
    pub operstate: String,
    /// Maximum Transmission Unit (MTU).
    pub mtu: u32,
    /// Total received bytes.
    pub rx_bytes: u64,
    /// Total transmitted bytes.
    pub tx_bytes: u64,
    /// Total received packets.
    pub rx_packets: u64,
    /// Total transmitted packets.
    pub tx_packets: u64,
    /// Received packets dropped by the kernel.
    pub rx_dropped: u64,
    /// Transmitted packets dropped by the kernel.
    pub tx_dropped: u64,
    /// Total receive errors.
    pub rx_errors: u64,
    /// Total transmit errors.
    pub tx_errors: u64,
}

impl TunInterfaceStats {
    /// Returns true if the interface is marked up.
    pub fn is_up(&self) -> bool {
        self.operstate.eq_ignore_ascii_case("up")
    }

    /// Calculates instantaneous throughput relative to an earlier sample.
    pub fn throughput_since(&self, previous: &Self, elapsed_secs: f64) -> TunThroughput {
        if elapsed_secs <= 0.0 {
            return TunThroughput::default();
        }
        let rx_bps = (self.rx_bytes.saturating_sub(previous.rx_bytes) as f64) / elapsed_secs;
        let tx_bps = (self.tx_bytes.saturating_sub(previous.tx_bytes) as f64) / elapsed_secs;
        let rx_pps = (self.rx_packets.saturating_sub(previous.rx_packets) as f64) / elapsed_secs;
        let tx_pps = (self.tx_packets.saturating_sub(previous.tx_packets) as f64) / elapsed_secs;

        TunThroughput {
            rx_bytes_per_sec: rx_bps,
            tx_bytes_per_sec: tx_bps,
            rx_packets_per_sec: rx_pps,
            tx_packets_per_sec: tx_pps,
        }
    }
}

/// Instantaneous throughput rate calculated between two statistics samples.
#[derive(Clone, Copy, Debug, Default, PartialEq, Serialize, Deserialize)]
pub struct TunThroughput {
    pub rx_bytes_per_sec: f64,
    pub tx_bytes_per_sec: f64,
    pub rx_packets_per_sec: f64,
    pub tx_packets_per_sec: f64,
}

/// Reads current interface statistics from sysfs.
pub fn read_tun_stats(interface: &str) -> Option<TunInterfaceStats> {
    let sysfs = PathBuf::from(format!("/sys/class/net/{interface}"));
    if !sysfs.exists() {
        return None;
    }

    let operstate = fs::read_to_string(sysfs.join("operstate"))
        .map(|s| s.trim().to_owned())
        .unwrap_or_else(|_| "unknown".to_owned());

    let mtu = fs::read_to_string(sysfs.join("mtu"))
        .ok()
        .and_then(|s| s.trim().parse::<u32>().ok())
        .unwrap_or(0);

    let stats_dir = sysfs.join("statistics");
    let read_u64 = |file: &str| -> u64 {
        fs::read_to_string(stats_dir.join(file))
            .ok()
            .and_then(|s| s.trim().parse::<u64>().ok())
            .unwrap_or(0)
    };

    Some(TunInterfaceStats {
        interface: interface.to_owned(),
        operstate,
        mtu,
        rx_bytes: read_u64("rx_bytes"),
        tx_bytes: read_u64("tx_bytes"),
        rx_packets: read_u64("rx_packets"),
        tx_packets: read_u64("tx_packets"),
        rx_dropped: read_u64("rx_dropped"),
        tx_dropped: read_u64("tx_dropped"),
        rx_errors: read_u64("rx_errors"),
        tx_errors: read_u64("tx_errors"),
    })
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_throughput_math() {
        let prev = TunInterfaceStats {
            rx_bytes: 1000,
            tx_bytes: 500,
            rx_packets: 10,
            tx_packets: 5,
            ..Default::default()
        };
        let curr = TunInterfaceStats {
            rx_bytes: 3000,
            tx_bytes: 1500,
            rx_packets: 30,
            tx_packets: 15,
            ..Default::default()
        };
        let tp = curr.throughput_since(&prev, 2.0);
        assert_eq!(tp.rx_bytes_per_sec, 1000.0);
        assert_eq!(tp.tx_bytes_per_sec, 500.0);
        assert_eq!(tp.rx_packets_per_sec, 10.0);
        assert_eq!(tp.tx_packets_per_sec, 5.0);
    }
}
