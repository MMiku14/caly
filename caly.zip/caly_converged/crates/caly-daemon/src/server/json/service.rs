//! Shared JSON-framed service owner, per-connection dispatch and watch stream.
//!
//! One `JsonService` owns the application adapter and the bounded session
//! registry shared by every transport connection. Each accepted connection
//! runs one task that reads length-prefixed JSON request frames and writes
//! result/error frames; a `WatchEvents` request switches the connection to a
//! continuous watch stream on a dedicated connection until the peer
//! disconnects.

use std::sync::{Arc, Mutex};

use crate::application::service::ApplicationServicePort;
use caly_core::domain::UnixMillis;
use crate::protocol::{
    framing::{FrameError, decode_json, encode_json, read_frame, write_frame},
    protocol::v2::HandshakeRequest,
    wire_frames::{
        ClientFrame, JsonRequest, JsonResponse, ServerFrame, WireError, WireErrorCode, wire_error,
        wire_error_with_domain,
    },
};
use tokio::io::{AsyncRead, AsyncWrite};

use super::{
    ProtocolSession, ServiceAdapter, ServiceError, ServiceV2, SessionError, SessionRegistry,
    event_to_wire, parse_session_token, unix_millis,
};
use crate::json::SESSION_TTL_MS;

/// Shared JSON-framed service owner.
pub struct JsonService<A> {
    state: Arc<Mutex<ServiceState<A>>>,
    /// Bounded global connection slots shared by every transport. Acquired
    /// by the accept loops *before* `tokio::spawn`, so a connection flood
    /// cannot spawn unbounded tasks even when each task immediately fails.
    connections: Arc<tokio::sync::Semaphore>,
}

struct ServiceState<A> {
    adapter: ServiceAdapter<A>,
    stop_notifier: Option<Arc<tokio::sync::Notify>>,
    registry: SessionRegistry,
}

impl<A> Clone for JsonService<A> {
    fn clone(&self) -> Self {
        Self {
            state: Arc::clone(&self.state),
            connections: Arc::clone(&self.connections),
        }
    }
}

/// Idle connections are dropped after this long without a frame
/// (a peer that connects and never sends a
/// frame must not pin a session task forever).
const IDLE_TIMEOUT: std::time::Duration = std::time::Duration::from_secs(60);
/// A response write must make progress or the peer is treated as dead.
/// Tokio socket writes can otherwise await forever once the peer stops
/// reading and the kernel send buffer fills.
const WRITE_TIMEOUT: std::time::Duration = std::time::Duration::from_secs(10);
/// A peer may send a few malformed frames (version skew / partial write),
/// but a continuous flood must not pin the per-connection task in an
/// error-response loop forever.
const MAX_CONSECUTIVE_BAD_FRAMES: u32 = 8;
/// Valid JSON with an invalid/missing session token is also a potential
/// lock-and-lookup spin; the same bounded-error discipline applies.
const MAX_CONSECUTIVE_AUTH_FAILURES: u32 = 8;

impl<A> JsonService<A> {
    /// Wraps one application adapter in a shared service owner. The bounded
    /// session registry capacity is a compile-time constant, so construction
    /// only fails if that bound is ever violated; the error is surfaced
    /// instead of aborting the daemon.
    ///
    /// `stop_notifier` : the daemon runtime
    /// passes its `Notify` here. When a `StopDaemon`
    /// operation completes successfully, `execute`
    /// triggers the notifier, which breaks the
    /// transport's serve loop and lets the daemon
    /// exit cleanly. `None` disables the stop signal
    /// (used by tests that don't run a transport).
    pub fn new(
        adapter: ServiceAdapter<A>,
        stop_notifier: Option<Arc<tokio::sync::Notify>>,
    ) -> Result<Self, SessionError> {
        Ok(Self {
            state: Arc::new(Mutex::new(ServiceState {
                adapter,
                stop_notifier,
                // Bounded; token collisions are resolved by refresh-on-handshake.
                registry: SessionRegistry::new(super::MAX_PROTOCOL_SESSIONS)?,
            })),
            connections: Arc::new(tokio::sync::Semaphore::new(
                super::MAX_CONCURRENT_CONNECTIONS,
            )),
        })
    }

    /// Tries to reserve one global connection slot. Accept loops call this
    /// before spawning a per-connection task; a full budget drops the new
    /// connection immediately instead of queueing an unbounded number of
    /// tasks behind the semaphore.
    pub fn try_acquire_connection(
        &self,
    ) -> Result<tokio::sync::OwnedSemaphorePermit, tokio::sync::TryAcquireError> {
        self.connections.clone().try_acquire_owned()
    }

    /// Transport message ceiling (bytes) derived from the decode limits.
    pub fn message_ceiling(&self) -> usize {
        self.state
            .lock()
            .map_or(0, |state| state.adapter.limits().max_message_bytes)
    }

    /// Serves one accepted connection until the peer disconnects or the frame
    /// stream becomes unrecoverable.
    pub async fn handle_connection<S>(&self, stream: S)
    where
        A: ApplicationServicePort + Send,
        S: AsyncRead + AsyncWrite + Unpin,
    {
        let (mut reader, mut writer) = tokio::io::split(stream);
        let ceiling = self.message_ceiling();
        let (mut bad_frames, mut auth_failures, mut handshake_complete) = (0_u32, 0_u32, false);
        // Debug: every CLI invocation opens one connection, so info here
        // would spam; debug keeps connect/disconnect visible on demand.
        tracing::debug!("client connection opened");
        // Per-connection protocol gate: each connection must handshake itself.
        loop {
            // Idle timeout: a peer that connects and never sends a frame
            // must not pin a task (and a session slot) forever — 2026-08-12
            // agent audit: repeated idle connections could exhaust the
            // session registry. 60s of silence ends the connection.
            let payload =
                match tokio::time::timeout(IDLE_TIMEOUT, read_frame(&mut reader, ceiling)).await {
                    Ok(Ok(payload)) => payload,
                    Ok(Err(FrameError::Closed | FrameError::Io { .. })) => break,
                    Ok(Err(FrameError::Oversized { .. })) => {
                        // Framing cannot resynchronize after an oversized header.
                        let frame = ServerFrame::Error(wire_error(
                            WireErrorCode::InvalidArgument,
                            "frame exceeds the negotiated message ceiling",
                        ));
                        let _ = write_json_frame(&mut writer, &frame).await;
                        break;
                    }
                    // Timeout or an internal error: drop the connection.
                    Err(_) => break,
                };
            let client = match decode_json::<ClientFrame>(&payload) {
                Ok(client) => {
                    bad_frames = 0;
                    client
                }
                Err(error) => {
                    bad_frames = bad_frames.saturating_add(1);
                    let frame = ServerFrame::Error(wire_error(
                        WireErrorCode::InvalidArgument,
                        format!("malformed request frame: {error}"),
                    ));
                    if !send_frame(&mut writer, frame).await
                        || bad_frames >= MAX_CONSECUTIVE_BAD_FRAMES
                    {
                        break;
                    }
                    continue;
                }
            };
            if !self
                .handle_request_frame(
                    &mut writer,
                    client,
                    &mut auth_failures,
                    &mut handshake_complete,
                )
                .await
            {
                break;
            }
        }
        tracing::debug!("client connection closed");
    }

    /// Handles one decoded request frame. Returns `true` to continue reading
    /// the connection and `false` to close it (watch success, peer write
    /// failure, or an authentication error budget exhausted).
    async fn handle_request_frame<W>(
        &self,
        writer: &mut W,
        client: ClientFrame,
        auth_failures: &mut u32,
        handshake_complete: &mut bool,
    ) -> bool
    where
        A: ApplicationServicePort + Send,
        W: AsyncWrite + Unpin,
    {
        match client.request {
            JsonRequest::Handshake(request) => {
                let (frame, rejected) = match self.handshake(request) {
                    Ok(response) => (
                        ServerFrame::Result(Box::new(JsonResponse::Handshake(response))),
                        false,
                    ),
                    Err(error) => {
                        tracing::debug!(
                            code = error.code,
                            detail = error.message.as_str(),
                            "client handshake rejected"
                        );
                        (ServerFrame::Error(error), true)
                    }
                };
                if rejected {
                    *auth_failures = auth_failures.saturating_add(1);
                } else {
                    *auth_failures = 0;
                    *handshake_complete = true;
                }
                let sent = send_frame(writer, frame).await;
                auth_gate(sent, *auth_failures)
            }
            JsonRequest::WatchEvents(request) => {
                if let Err(error) = require_connection_handshake(*handshake_complete) {
                    *auth_failures = auth_failures.saturating_add(1);
                    let sent = send_frame(writer, ServerFrame::Error(error)).await;
                    return auth_gate(sent, *auth_failures);
                }
                if let Err(error) = self.validate_session(client.session) {
                    *auth_failures = auth_failures.saturating_add(1);
                    let sent = send_frame(writer, ServerFrame::Error(error)).await;
                    return auth_gate(sent, *auth_failures);
                }
                // The connection becomes a dedicated watch stream.
                tracing::debug!("client subscribed to the event stream");
                self.stream_watch(writer, request).await;
                false
            }
            other => {
                if let Err(error) = require_connection_handshake(*handshake_complete) {
                    *auth_failures = auth_failures.saturating_add(1);
                    return send_frame(writer, ServerFrame::Error(error)).await
                        && *auth_failures < MAX_CONSECUTIVE_AUTH_FAILURES;
                }
                let outcome = match self.validate_session(client.session) {
                    Ok(()) => {
                        *auth_failures = 0;
                        self.dispatch(other).await
                    }
                    Err(error) => {
                        *auth_failures = auth_failures.saturating_add(1);
                        Err(error)
                    }
                };
                let frame = match outcome {
                    Ok(response) => ServerFrame::Result(Box::new(response)),
                    Err(error) => {
                        tracing::debug!(
                            code = error.code,
                            detail = error.message.as_str(),
                            "request dispatch failed"
                        );
                        ServerFrame::Error(error)
                    }
                };
                let sent = send_frame(writer, frame).await;
                auth_gate(sent, *auth_failures)
            }
        }
    }

    /// Registers (or refreshes) the daemon session token with a real expiry so
    /// subsequent requests are validated against the live registry.
    fn handshake(
        &self,
        request: HandshakeRequest,
    ) -> Result<crate::protocol::protocol::v2::HandshakeResponse, WireError>
    where
        A: ApplicationServicePort,
    {
        let mut state = lock_state(&self.state)?;
        let response = state.adapter.handshake(request).map_err(service_to_wire)?;
        let now = unix_millis();
        state.registry.purge_expired(now);
        let session = ProtocolSession {
            token: response.session_token,
            version: response.negotiated_version,
            features: response.enabled_features.clone(),
            expires_at: UnixMillis::new(now.value().saturating_add(SESSION_TTL_MS)),
        };
        state.registry.refresh(session).map_err(session_to_wire)?;
        Ok(response)
    }

    /// Validates the request's hex session token against the live registry.
    fn validate_session(&self, session: Option<String>) -> Result<(), WireError> {
        let value = session.ok_or_else(|| {
            wire_error(WireErrorCode::Unauthenticated, "session token is required")
        })?;
        let token = parse_session_token(&value)
            .map_err(|_| wire_error(WireErrorCode::Unauthenticated, "session token is invalid"))?;
        let mut state = lock_state(&self.state)?;
        let now = unix_millis();
        state.registry.purge_expired(now);
        state
            .registry
            .validate(token, now)
            .map(|_| ())
            .map_err(session_to_wire)
    }
}

mod rpc;
mod watch;

pub use watch::WatchStream;

/// Serializes and writes one JSON-framed server frame.
async fn write_json_frame<W>(writer: &mut W, frame: &ServerFrame) -> Result<(), FrameError>
where
    W: AsyncWrite + Unpin,
{
    tokio::time::timeout(WRITE_TIMEOUT, async {
        let payload = encode_json(frame).map_err(|error| FrameError::Io {
            reason: format!("response serialization failed: {error}"),
        })?;
        write_frame(writer, &payload).await
    })
    .await
    .map_err(|_| FrameError::Io {
        reason: "response write timed out".to_owned(),
    })?
}

fn require_connection_handshake(complete: bool) -> Result<(), WireError> {
    complete.then_some(()).ok_or_else(handshake_required_error)
}

fn handshake_required_error() -> WireError {
    wire_error(
        WireErrorCode::HandshakeRequired,
        "handshake required before this method",
    )
}

/// Writes one frame and reports whether the peer is still usable. Keeping
/// the boolean shape here collapses every "send result/error, break on
/// failed write" branch into one line in [`JsonService::handle_connection`].
/// Continues the connection while the peer write succeeded and the auth
/// budget holds. Warns once when the budget — not a peer disconnect —
/// closes the connection, so brute-force handshakes are visible.
fn auth_gate(sent: bool, auth_failures: u32) -> bool {
    let within_budget = sent && auth_failures < MAX_CONSECUTIVE_AUTH_FAILURES;
    if sent && !within_budget {
        tracing::warn!(
            auth_failures,
            "closing the connection after repeated authentication failures"
        );
    }
    within_budget
}

async fn send_frame<W>(writer: &mut W, frame: ServerFrame) -> bool
where
    W: AsyncWrite + Unpin,
{
    write_json_frame(writer, &frame).await.is_ok()
}

fn lock_state<A>(
    state: &Arc<Mutex<ServiceState<A>>>,
) -> Result<std::sync::MutexGuard<'_, ServiceState<A>>, WireError> {
    state.lock().map_err(|_| {
        wire_error(
            WireErrorCode::ApplicationUnavailable,
            "service state lock poisoned",
        )
    })
}

fn service_to_wire(error: ServiceError) -> WireError {
    match error {
        ServiceError::Unauthenticated => wire_error(
            WireErrorCode::Unauthenticated,
            "handshake or session authentication required",
        ),
        ServiceError::HandshakeRequired => wire_error(
            WireErrorCode::HandshakeRequired,
            "handshake required before this method",
        ),
        ServiceError::PermissionDenied => {
            wire_error(WireErrorCode::PermissionDenied, "permission denied")
        }
        ServiceError::ResourceExhausted => wire_error(
            WireErrorCode::ResourceExhausted,
            "bounded resource exhausted",
        ),
        ServiceError::InvalidArgument { reason, domain } => {
            wire_error_with_domain(WireErrorCode::InvalidArgument, domain, reason)
        }
        ServiceError::IncompatibleVersion => wire_error(
            WireErrorCode::IncompatibleVersion,
            "incompatible protocol version",
        ),
        ServiceError::ApplicationUnavailable => wire_error(
            WireErrorCode::ApplicationUnavailable,
            "application unavailable",
        ),
    }
}

fn session_to_wire(error: SessionError) -> WireError {
    match error {
        SessionError::CapacityReached => {
            wire_error(WireErrorCode::ResourceExhausted, "session capacity reached")
        }
        SessionError::TokenCollision | SessionError::InvalidToken => wire_error(
            WireErrorCode::Unauthenticated,
            "session token collision or invalid",
        ),
        SessionError::Missing | SessionError::Expired => wire_error(
            WireErrorCode::Unauthenticated,
            "session token is missing or expired",
        ),
    }
}

#[cfg(test)]
mod tests;

#[cfg(test)]
mod handshake_gate_tests;

#[cfg(test)]
mod live_watch_tests;
