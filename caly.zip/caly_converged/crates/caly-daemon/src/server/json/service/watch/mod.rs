//! Continuous watch stream for `JsonService` connections.
//!
//! Split out of `json/service.rs` (audit #70 file-length budget):
//! yields the initial replay/snapshot, then follows live projection
//! events. A slow subscriber that lags the broadcast ring is sent a
//! fresh full snapshot and re-subscribes, so a slow client only drops
//! best-effort live events and never blocks the authoritative
//! projector.

use std::{
    pin::Pin,
    sync::{Arc, Mutex},
    task::{Context, Poll},
};

use crate::application::{events::SequencedEvent, service::ApplicationServicePort};
use crate::protocol::protocol::v2::{WatchResponse, WireProjectionEvent};
use tokio_stream::{Stream, wrappers::BroadcastStream};

use super::{ServiceError, ServiceState, lock_state};
use super::{ServiceV2, event_to_wire};

/// Yields the initial replay/snapshot, then follows live projection events.
pub struct WatchStream<A> {
    pub(super) initial: std::vec::IntoIter<Result<WatchResponse, ServiceError>>,
    pub(super) live: BroadcastStream<SequencedEvent>,
    pub(super) state: Arc<Mutex<ServiceState<A>>>,
    /// Optional projection-event kind filter. `FullSnapshot` recovery frames
    /// always pass so a filtered client can rebuild authoritative state.
    pub(super) filter: Option<Vec<String>>,
}

impl<A> WatchStream<A> {
    /// Returns whether a watch item passes the configured event-kind filter.
    fn passes_filter(
        item: &Result<WatchResponse, ServiceError>,
        filter: Option<&[String]>,
    ) -> bool {
        let Some(filter) = filter else {
            return true;
        };
        let Ok(WatchResponse::Event(event)) = item else {
            // Errors and full-snapshot recovery always pass.
            return true;
        };
        let kind = match &event.event {
            WireProjectionEvent::DesiredReplaced(_) => "DesiredReplaced",
            WireProjectionEvent::AppliedReplaced(_) => "AppliedReplaced",
            WireProjectionEvent::ObservedReplaced(_) => "ObservedReplaced",
            WireProjectionEvent::PlatformReplaced(_) => "PlatformReplaced",
            WireProjectionEvent::CapabilitiesReplaced(_) => "CapabilitiesReplaced",
            WireProjectionEvent::NodesReplaced(_) => "NodesReplaced",
            WireProjectionEvent::GroupsReplaced(_) => "GroupsReplaced",
            WireProjectionEvent::ConfigMutated(_) => "ConfigMutated",
            WireProjectionEvent::SourcesReplaced(_) => "SourcesReplaced",
            WireProjectionEvent::Unknown { .. } => "Unknown",
        };
        filter.iter().any(|candidate| candidate == kind)
    }

    /// Fetches the current authoritative snapshot as a wire watch response.
    fn fetch_snapshot(&self) -> Option<Result<WatchResponse, ServiceError>>
    where
        A: ApplicationServicePort,
    {
        let mut state = lock_state(&self.state).ok()?;
        let wire = ServiceV2::snapshot(&mut state.adapter).ok()?;
        Some(Ok(WatchResponse::FullSnapshot(Box::new(wire))))
    }

    /// Re-subscribes to the live broadcast after a lag recovery.
    fn resubscribe(&self) -> Option<BroadcastStream<SequencedEvent>>
    where
        A: ApplicationServicePort,
    {
        lock_state(&self.state)
            .ok()?
            .adapter
            .subscribe_live()
            .ok()
            .map(BroadcastStream::new)
    }
}

impl<A> Stream for WatchStream<A>
where
    A: ApplicationServicePort + Send,
{
    type Item = Result<WatchResponse, ServiceError>;

    fn poll_next(self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Option<Self::Item>> {
        let this = self.get_mut();
        for item in this.initial.by_ref() {
            if Self::passes_filter(&item, this.filter.as_deref()) {
                return Poll::Ready(Some(item));
            }
        }
        loop {
            match Pin::new(&mut this.live).poll_next(cx) {
                Poll::Pending => return Poll::Pending,
                Poll::Ready(None) => return Poll::Ready(None),
                Poll::Ready(Some(Err(_))) => {
                    let snapshot = this.fetch_snapshot();
                    this.live = match this.resubscribe() {
                        Some(stream) => stream,
                        None => return Poll::Ready(None),
                    };
                    if let Some(snapshot) = snapshot {
                        return Poll::Ready(Some(snapshot));
                    }
                }
                Poll::Ready(Some(Ok(event))) => {
                    let Ok(wire) = event_to_wire(&event) else {
                        return Poll::Ready(Some(Err(ServiceError::ApplicationUnavailable)));
                    };
                    if !Self::passes_filter(
                        &Ok(WatchResponse::Event(wire.clone())),
                        this.filter.as_deref(),
                    ) {
                        continue;
                    }
                    return Poll::Ready(Some(Ok(WatchResponse::Event(wire))));
                }
            }
        }
    }
}
