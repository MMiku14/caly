//! Sequential batch admission (`execute_batch`).

use crate::application::service::ApplicationServicePort;
use crate::protocol::protocol::v2::{
    ExecuteBatchRequest, ExecuteBatchResponse, ExecuteBatchResult, WireBatchRejection,
};
use crate::protocol::wire_frames::JsonResponse;

use super::super::{JsonService, ServiceV2, lock_state, service_to_wire};

impl<A> JsonService<A> {
    pub(super) fn dispatch_execute_batch(
        &self,
        request: ExecuteBatchRequest,
    ) -> Result<JsonResponse, crate::protocol::wire_frames::WireError>
    where
        A: ApplicationServicePort,
    {
        let mut results = caly_core::domain::BoundedVec::new();
        let mut stopped_early = false;
        for item in request.operations.into_vec() {
            let operation_id = item.operation_id;
            let outcome = {
                let mut state = lock_state(&self.state)?;
                state.adapter.execute(item).map_err(service_to_wire)
            };
            let result = match outcome {
                Ok(response) => ExecuteBatchResult::Accepted(response),
                Err(error) => {
                    let rejection = WireBatchRejection {
                        code: error.code,
                        domain: error.domain,
                        message: error.message,
                    };
                    ExecuteBatchResult::Rejected {
                        operation_id,
                        rejection,
                    }
                }
            };
            let rejected = matches!(result, ExecuteBatchResult::Rejected { .. });
            let _ = results.try_push(result);
            if rejected && request.stop_on_error {
                stopped_early = true;
                break;
            }
        }
        Ok(JsonResponse::ExecuteBatch(ExecuteBatchResponse {
            results,
            stopped_early,
        }))
    }
}
