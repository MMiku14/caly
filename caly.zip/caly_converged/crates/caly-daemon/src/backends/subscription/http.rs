//! Direct HTTP subscription backend using the repository's SSRF-safe fetch policy.

use crate::core::CoreNodeRegistry;
use caly_core::domain::SubscriptionId;
use crate::platform::paths::{AppPaths, SafeName};
use caly_core::ports::{ActorFailure, RefreshOutcome, SubscriptionCommandBackend};
use caly_core::profile::loader::{LayeredConfigPaths, LoaderLimits, load_layered_yaml_strict};
use caly_core::subscription::net::{prefer_public_addresses, resolve_host_with_retry};
/// P8b: intake-domain function moved up to `caly_core::subscription::id`;
/// re-exported here so adapter internals keep their call sites.
use caly_core::subscription::subscription_id_for_url;
use caly_core::subscription::{
    FetchPolicy, FetchResult, FetchValidators, INLINE_SUBSCRIPTION_ID, ResolvedAddresses,
    fetch_pinned, read_inline_body,
};

use super::PublicAddressClassifier;
use super::render_compose::uri_body_to_sing_box_json_with;

mod expansion;

/// HTTP fetch attempts before surfacing a failure (absorbs transient blips).
const FETCH_ATTEMPTS: usize = 2;
/// Ceiling for parallel fetch waves (bounded thread fan-out).
const MAX_CONCURRENT_FETCHES: usize = 8;
/// Inter-attempt delay in milliseconds for a transient fetch failure.
const FETCH_RETRY_MILLIS: u64 = 250;

/// Audit M7: exponential backoff (x2 per attempt, capped) with a small
/// clock-seeded jitter, so several clients refreshing the same source at
/// once do not stampede it in lockstep.
#[allow(clippy::cast_possible_truncation)] // jitter seed: low bits of the clock are fine
fn retry_backoff_millis(attempt: usize) -> u64 {
    let base = FETCH_RETRY_MILLIS.saturating_mul(1u64 << attempt.min(5));
    let seed = std::time::SystemTime::now()
        .duration_since(std::time::UNIX_EPOCH)
        .map_or(0, |duration| duration.as_nanos() as u64)
        ^ (attempt as u64).wrapping_mul(0x9E37_79B9_7F4A_7C15);
    let mut state = seed | 1;
    state ^= state >> 12;
    state ^= state << 25;
    state ^= state >> 27;
    let jitter = state.wrapping_mul(0x2545_F491_4F6C_DD1D) >> 33;
    base + (jitter % (base + 1))
}

/// A fetch attempt result carrying an explicit transient flag, so retry
/// decisions are structural rather than string-matched.
type Attempt<T> = Result<T, (bool, ActorFailure)>;

/// Runs `attempt` with up to `max_attempts` tries, retrying only transient
/// failures with exponential backoff + jitter (audit M7). Non-transient
/// failures surface immediately. The `T` payload is the last attempt's
/// result (e.g. the "content updated" flag or the fetched body). Pure and
/// testable without network I/O.
fn retry_fetch<T, F>(max_attempts: usize, mut attempt: F) -> Result<T, ActorFailure>
where
    F: FnMut() -> Attempt<T>,
{
    let mut last = crate::failure("fetch failed", "retry");
    for index in 0..max_attempts {
        match attempt() {
            Ok(changed) => return Ok(changed),
            Err((transient, error)) if index + 1 < max_attempts && transient => {
                last = error;
                std::thread::sleep(std::time::Duration::from_millis(retry_backoff_millis(
                    index,
                )));
            }
            Err((_, error)) => return Err(error),
        }
    }
    Err(last)
}

/// Direct HTTP subscription backend using the repository's SSRF-safe fetch policy.
pub struct HttpSubscriptionBackend {
    sources: std::collections::BTreeMap<SubscriptionId, String>,
    /// W2-β2b: per-source last-successful-fetch ledger, consulted
    /// only by scheduled (`#59` timer) refreshes. Memory-only: a
    /// daemon restart treats every source as due once, which matches
    /// "the source may have changed while we were down".
    last_refresh: std::collections::BTreeMap<SubscriptionId, std::time::Instant>,
    cache: super::CachedSubscriptionBackend,
    /// Declared subscription ids (config.yaml `subscriptions`) the cache
    /// restore is allowed to revive; anything else is a ghost cache
    /// (user-flow audit).
    declared: std::collections::BTreeSet<caly_core::domain::SubscriptionId>,
    handle: tokio::runtime::Handle,
    policy: FetchPolicy,
}

impl HttpSubscriptionBackend {
    /// Creates an HTTP backend using the current application runtime handle.
    pub fn new() -> Result<Self, ActorFailure> {
        let handle = tokio::runtime::Handle::try_current().map_err(|_| {
            crate::failure(
                "subscription backend requires a Tokio runtime",
                "construct it inside daemon runtime composition",
            )
        })?;
        Ok(Self {
            sources: std::collections::BTreeMap::new(),
            last_refresh: std::collections::BTreeMap::new(),
            cache: super::CachedSubscriptionBackend::new(),
            declared: std::collections::BTreeSet::new(),
            handle,
            policy: FetchPolicy::direct_default(),
        })
    }

    /// Overrides the SSRF-safe fetch policy bounds (timeouts, body cap,
    /// redirects, environment proxy) from configuration.
    #[must_use]
    pub fn with_policy(mut self, policy: FetchPolicy) -> Self {
        self.policy = policy;
        self
    }

    /// Shares an automatic NodeId → Mihomo group/node registry.
    #[must_use]
    pub fn with_node_registry(mut self, registry: CoreNodeRegistry) -> Self {
        self.cache = self.cache.with_node_registry(registry);
        self
    }

    /// Shares the subscription-author routing registry (groups + rules) so a
    /// refresh indexes author-declared topology alongside the nodes.
    #[must_use]
    pub fn with_routing_registry(mut self, registry: crate::core::CoreRoutingRegistry) -> Self {
        self.cache = self.cache.with_routing_registry(registry);
        self
    }

    /// Enables a persistent raw-body cache directory so the node registry can
    /// be rebuilt after a daemon restart without re-fetching.
    #[must_use]
    pub fn with_cache_dir(mut self, cache_dir: std::path::PathBuf) -> Self {
        self.cache = self.cache.with_cache_dir(cache_dir);
        self
    }

    /// Restores every persisted subscription body into the node registry.
    /// Best-effort: unreadable entries are skipped with a warning. Returns
    /// the restored projection slices for seeding the presentation snapshot.
    pub fn restore_cached(&mut self) -> Result<Vec<caly_core::domain::SnapshotNodes>, ActorFailure> {
        let declared = self.declared.clone();
        let mut restored = self.cache.restore_from_cache(&declared)?;
        // Inline entries are operator state, not cache: revive them
        // through the same fold. A corrupt body warns (like an
        // un-restorable cache entry) — user files are never deleted.
        let inline_body = read_inline_body(&AppPaths::from_env().state);
        if !inline_body.is_empty() {
            self.cache
                .put_source_memory(INLINE_SUBSCRIPTION_ID, inline_body);
            match self.cache.refresh_projection(INLINE_SUBSCRIPTION_ID) {
                Ok(projection) => restored.push(projection.nodes),
                Err(error) => tracing::warn!(
                    subscription = %INLINE_SUBSCRIPTION_ID,
                    reason = %error.message,
                    hint = %error.suggested_action,
                    "inline entries are not restorable; they stay out of the registry until fixed"
                ),
            }
        }
        Ok(restored)
    }

    /// Declares a subscription id as live (config.yaml), so cache
    /// restore revives it; used by `register_subscription_url`.
    pub fn declare_id(&mut self, id: caly_core::domain::SubscriptionId) {
        self.declared.insert(id);
    }

    /// Registers a source URL for a subscription id.
    pub fn put_url(&mut self, id: SubscriptionId, url: String) {
        self.sources.insert(id, url);
    }

    /// Returns the last committed generation.
    pub fn generation(&self, id: SubscriptionId) -> u64 {
        self.cache.generation(id)
    }

    /// Fetches the source and generates a sing-box JSON config from dialable
    /// nodes, rendering the document header from `tuning`.
    pub fn refresh_sing_box_config(
        &mut self,
        id: SubscriptionId,
        tuning: &caly_kernel::coreconf::sing_box::SingBoxRenderTuning,
    ) -> Result<Vec<u8>, ActorFailure> {
        let mut touched = std::collections::BTreeSet::new();
        self.fetch(id, &mut touched)?;
        let body = self.cache.cached_body_bytes(id).map_err(|_| {
            crate::failure(
                "sing-box raw subscription cache is missing",
                "retry the source fetch",
            )
        })?;
        uri_body_to_sing_box_json_with(&body, id, tuning).map_err(|error| {
            crate::failure(
                &format!("sing-box outbound rendering failed: {error}"),
                "inspect subscription protocol support",
            )
        })
    }

    fn fetch(
        &mut self,
        id: SubscriptionId,
        touched: &mut std::collections::BTreeSet<SubscriptionId>,
    ) -> Result<bool, ActorFailure> {
        let source = self.sources.get(&id).cloned().ok_or_else(|| {
            crate::failure(
                "subscription URL is not configured",
                "configure a source URL",
            )
        })?;
        let addresses = resolve_addresses(&source)?;
        touched.insert(id);
        let validators = self.cache.validators(id);
        let outcome = retry_fetch(FETCH_ATTEMPTS, || {
            request_body(&self.handle, self.policy, &source, &addresses, &validators)
        })?;
        // URL-list children are conditionally fetched too: a fresh child
        // counts as content change even when the parent answered 304.
        self.commit_fetch_result(id, outcome, touched)
    }

    /// Commits one fetched outcome into the cache and expands URL-list
    /// children. The network half (`fetch_network`/`request_body`) touches
    /// no backend state, so many fetches can run concurrently; every cache
    /// write funnels through here single-threaded. Returns whether the
    /// source's node set may have moved (fresh body or fresh child).
    fn commit_fetch_result(
        &mut self,
        id: SubscriptionId,
        outcome: FetchResult,
        touched: &mut std::collections::BTreeSet<SubscriptionId>,
    ) -> Result<bool, ActorFailure> {
        let updated = if let FetchResult::Updated {
            body,
            etag,
            last_modified,
            userinfo,
        } = outcome
        {
            self.cache.put_source(id, body.into_vec());
            self.cache.put_userinfo(id, userinfo);
            // Feed the validators back into the next conditional request:
            // without this the server never sees If-None-Match again and
            // every refresh pulls the full body (and the NotModified arm
            // stays dead code).
            self.cache.put_validators(
                id,
                FetchValidators {
                    etag,
                    last_modified,
                },
            );
            true
        } else {
            false
        };
        // A fresh body OR a fresh URL-list child counts as content
        // change (the Updated flag was dropped,
        // so every real refresh published `changed: false` and the
        // reconciler never re-rendered).
        Ok(updated || self.expand_url_list(id, touched)?)
    }
}

/// One SSRF-safe pinned HTTP request shared by the primary fetch, the
/// parallel refresh fan-out and the URL-list child fetches. `validators`
/// carries the conditional-request metadata from the previous successful
/// fetch of the same URL. Touches no backend state, so many requests can
/// run concurrently on scoped threads.
fn request_body(
    handle: &tokio::runtime::Handle,
    policy: FetchPolicy,
    source: &str,
    addresses: &ResolvedAddresses,
    validators: &FetchValidators,
) -> Result<FetchResult, (bool, ActorFailure)> {
    // The backend runs inside a `spawn_blocking` actor, so a direct
    // `block_on` is safe and avoids the multi-thread-runtime dependency of
    // `block_in_place` (which would panic on a current-thread runtime).
    handle
        .block_on(fetch_pinned(
            source,
            addresses.clone(),
            &PublicAddressClassifier,
            policy,
            validators,
        ))
        .map_err(|error| {
            let transient = is_transient_fetch(&error);
            let failure = crate::failure(
                &format!("subscription fetch failed: {error}"),
                "inspect HTTP, DNS, and source policy",
            );
            (transient, failure)
        })
}

/// Resolves and retrieves one source body with the shared retry policy,
/// touching no backend state: safe to call concurrently from the refresh
/// fan-out threads. `validators` is the pre-read conditional metadata.
fn fetch_network(
    handle: &tokio::runtime::Handle,
    policy: FetchPolicy,
    source: &str,
    validators: &FetchValidators,
) -> Result<FetchResult, ActorFailure> {
    let addresses = resolve_addresses(source)?;
    retry_fetch(FETCH_ATTEMPTS, || {
        request_body(handle, policy, source, &addresses, validators)
    })
}

/// Runs `fetch` for every item in bounded parallel waves of scoped threads:
/// each wave's items run concurrently and the call joins the wave before
/// starting the next, so at most `concurrency` fetches are ever in flight
/// and the outcome order matches the item order. A panicking worker turns
/// into a per-item failure instead of poisoning the whole refresh.
fn fetch_waves<T, F>(
    items: &[T],
    concurrency: usize,
    fetch: &F,
) -> Vec<Result<FetchResult, ActorFailure>>
where
    F: Fn(&T) -> Result<FetchResult, ActorFailure> + Sync,
    T: Sync,
{
    let concurrency = concurrency.max(1);
    let mut outcomes = Vec::with_capacity(items.len());
    for wave in items.chunks(concurrency) {
        let wave_outcomes: Vec<Result<FetchResult, ActorFailure>> = std::thread::scope(|scope| {
            let mut handles = Vec::with_capacity(wave.len());
            for item in wave {
                handles.push(scope.spawn(move || fetch(item)));
            }
            handles
                .into_iter()
                .map(|handle| match handle.join() {
                    Ok(outcome) => outcome,
                    Err(_) => Err(crate::failure(
                        "subscription fetch thread panicked",
                        "report a bug",
                    )),
                })
                .collect()
        });
        outcomes.extend(wave_outcomes);
    }
    outcomes
}

/// Whether a fetch error is transient and worth retrying: connect/request
/// timeouts and temporary (5xx) server statuses. Policy rejections (bad URL,
/// unsupported scheme, non-public address, body too large) are not retried.
fn is_transient_fetch(error: &caly_core::subscription::FetchError) -> bool {
    use caly_core::subscription::FetchError;
    match error {
        FetchError::RequestFailed(_) | FetchError::ClientBuild => true,
        FetchError::UnexpectedStatus(status) => (500..600).contains(status),
        _ => false,
    }
}

fn resolve_addresses(source: &str) -> Result<ResolvedAddresses, ActorFailure> {
    let parsed = url::Url::parse(source)
        .map_err(|_| crate::failure("subscription URL is invalid", "use an HTTP(S) URL"))?;
    // W2-β2a (Q5): `file://` sources skip DNS entirely — the fetch
    // half reads from disk before it would touch the resolved set.
    if parsed.scheme() == "file" {
        return ResolvedAddresses::try_from_vec(Vec::new())
            .map_err(|_| crate::failure("empty DNS-answer set is out of bounds", "report a bug"));
    }
    let host = parsed
        .host_str()
        .ok_or_else(|| crate::failure("subscription URL has no host", "configure a valid host"))?;
    let port = parsed.port_or_known_default().ok_or_else(|| {
        crate::failure(
            "subscription URL has no port",
            "configure a valid HTTP(S) URL",
        )
    })?;
    // Shared resolver (single implementation lives in caly_core::subscription::net):
    // retries transient/empty lookups, then filters to public addresses with
    // IPv4 preferred.
    let addresses = resolve_host_with_retry(host, port).map_err(|rejection| {
        let detail = match rejection {
            caly_core::subscription::net::ResolveRejection::Empty => {
                "subscription DNS returned no answers"
            }
            caly_core::subscription::net::ResolveRejection::Lookup => {
                "subscription DNS resolution failed"
            }
        };
        crate::failure(detail, "inspect DNS and source availability")
    })?;
    let addresses = prefer_public_addresses(addresses, &PublicAddressClassifier);
    if addresses.is_empty() {
        return Err(crate::failure(
            "subscription resolved only to non-public addresses",
            "use a public subscription host",
        ));
    }
    ResolvedAddresses::try_from_vec(addresses).map_err(|_| {
        crate::failure(
            "subscription has too many DNS answers",
            "use a bounded source host",
        )
    })
}

impl SubscriptionCommandBackend for HttpSubscriptionBackend {
    fn refresh(
        &mut self,
        subscription: SubscriptionId,
        mode: caly_core::ports::RefreshMode,
    ) -> Result<RefreshOutcome, ActorFailure> {
        // Re-resolve the sources each refresh: env wins, then layered config,
        // so a config edit takes effect without a daemon restart.
        let sources = resolve_sources()?;
        for resolved in &sources {
            self.sources.insert(resolved.id, resolved.url.clone());
        }
        let mut declared: std::collections::BTreeSet<SubscriptionId> =
            sources.iter().map(|source| source.id).collect();
        let targets = self.select_targets(&sources, subscription, mode)?;
        // 刀 6 (memory audit): ids touched by this refresh (top-level and
        // URL-list children). Retain runs AFTER the fetch loop so `touched`
        // carries the real child ids; running it before would wipe URL-list
        // children and defeat their conditional requests.
        let mut touched: std::collections::BTreeSet<SubscriptionId> =
            std::collections::BTreeSet::new();
        // Operator-declared inline entries fold in as a synthetic source
        // on full refreshes (manual, scheduled, boot); a narrow
        // single-source refresh stays narrow. Runs BEFORE the scheduled
        // quiet-success return so inline edits converge on ticks too.
        let all_zero = subscription.into_bytes() == [0_u8; 16];
        let (inline_nodes, inline_changed, inline_active, inline_error) = if all_zero {
            self.refresh_inline_source(&AppPaths::from_env().state)
        } else {
            // Targeted refresh stays narrow (no inline re-read — inline
            // edits converge on full refreshes), but the cached inline
            // generation must stay alive: without this `retain_declared`
            // below evicts the inline registry entries and the outcome
            // carries only the target's nodes, so `sub refresh <id>`
            // silently drops every inline node from the kernel config
            // until the next full refresh (bug ⑧ — live-verified
            // `smoke-node` eviction from mihomo.yaml).
            match self.cache.refresh_projection(INLINE_SUBSCRIPTION_ID) {
                Ok(projection) => (projection.nodes.into_vec(), false, true, None),
                Err(_) => (Vec::new(), false, false, None),
            }
        };
        if inline_active {
            // Retain drops undeclared records AND their registry entries,
            // so an active inline generation must be declared (same as a
            // URL source); an inactive one is deliberately absent so
            // `retain_declared` releases the stale inline state.
            declared.insert(INLINE_SUBSCRIPTION_ID);
            touched.insert(INLINE_SUBSCRIPTION_ID);
        }
        // Scheduled ticks with nothing due are a quiet success.
        if targets.is_empty() && mode.scheduled && !inline_changed {
            return caly_core::domain::SnapshotNodes::try_from_vec(Vec::new())
                .map(|nodes| RefreshOutcome {
                    nodes,
                    changed: false,
                })
                .map_err(|_| crate::failure("empty snapshot is out of bounds", "report a bug"));
        }
        let (mut merged, mut any_changed, first_error) =
            self.fetch_targets(&targets, mode.force, &mut touched);
        merged.extend(inline_nodes);
        // Targeted refresh: fold the other declared sources' cached
        // projections back in, restoring `RefreshOutcome.nodes`'s
        // documented "already merged" contract — otherwise the
        // `NodesReplaced` delta narrows the live node table (and the
        // reconciler's re-render) to the refreshed target alone
        // (bug ⑧). Cached bodies short-circuit on fingerprint: no
        // re-parse, no network.
        if !all_zero {
            merged.extend(self.merge_kept_projections(&declared, &targets));
        }
        any_changed |= inline_changed;
        let first_error = first_error.or(inline_error);
        // A release is a change (bug ⑩): without this a removal-only
        // refresh reports `changed: false` and neither the projection
        // nor the kernel config drops the removed nodes.
        any_changed |= self.cache.retain_declared(&declared, &touched);
        if merged.is_empty() {
            // "no sources at all" is an error; "sources exist but came back
            // empty" is a legitimate refresh outcome (audit).
            if let Some(error) = first_error {
                return Err(error);
            }
            return caly_core::domain::SnapshotNodes::try_from_vec(Vec::new())
                .map(|nodes| RefreshOutcome {
                    nodes,
                    changed: true,
                })
                .map_err(|_| crate::failure("empty snapshot is out of bounds", "report a bug"));
        }
        let nodes = caly_core::domain::SnapshotNodes::try_from_vec(merged).map_err(|_| {
            crate::failure(
                "merged subscription nodes exceeded the snapshot bound",
                "reduce the number of subscription sources or their node counts",
            )
        })?;
        Ok(RefreshOutcome {
            nodes,
            changed: any_changed,
        })
    }
}

impl HttpSubscriptionBackend {
    /// Selects the refresh target set: all-zero means every enabled source
    /// (narrowed to the due subset on a scheduled run); a concrete id selects
    /// exactly one source and unknown ids fail hard.
    /// Folds the operator-declared inline files into the pipeline as
    /// the reserved [`INLINE_SUBSCRIPTION_ID`] source: read, stage via
    /// `put_source_memory`, re-project. Returns the folded nodes,
    /// whether the generation moved, whether the source is active (a
    /// non-empty body — only active sources are declared to retain),
    /// and any projection failure (warned inside; the last good
    /// generation stays indexed, mirroring the fetch path).
    fn refresh_inline_source(
        &mut self,
        state_dir: &std::path::Path,
    ) -> (
        Vec<caly_core::domain::DisplayNode>,
        bool,
        bool,
        Option<ActorFailure>,
    ) {
        let id = INLINE_SUBSCRIPTION_ID;
        let body = read_inline_body(state_dir);
        if body.is_empty() {
            // No files: quiet when never folded (`generation == 0`);
            // changed when the last entry was just removed, and left
            // out of `declared` so retain releases the stale record.
            return (Vec::new(), self.cache.generation(id) > 0, false, None);
        }
        let before = self.cache.generation(id);
        self.cache.put_source_memory(id, body);
        match self.cache.refresh_projection(id) {
            Ok(projection) => (
                projection.nodes.into_vec(),
                self.cache.generation(id) != before,
                true,
                None,
            ),
            Err(error) => {
                tracing::warn!(
                    subscription = %id,
                    error = %error.message,
                    stage = "inline fold",
                    "inline entries are undecodable; keeping the last folded nodes"
                );
                (Vec::new(), false, true, Some(error))
            }
        }
    }

    fn select_targets<'a>(
        &self,
        sources: &'a [ResolvedSource],
        subscription: SubscriptionId,
        mode: caly_core::ports::RefreshMode,
    ) -> Result<Vec<&'a ResolvedSource>, ActorFailure> {
        let all_zero = subscription.into_bytes() == [0_u8; 16];
        if all_zero {
            return Ok(if mode.scheduled {
                let now = std::time::Instant::now();
                sources
                    .iter()
                    .filter(|source| {
                        due_for_scheduled_refresh(
                            source.every_minutes,
                            self.last_refresh.get(&source.id),
                            now,
                        )
                    })
                    .collect()
            } else {
                sources.iter().collect()
            });
        }
        let one = sources
            .iter()
            .find(|source| source.id == subscription)
            .ok_or_else(|| {
                crate::failure(
                    "subscription source is not configured",
                    "check `caly sub list` for the enabled sources",
        //
                )
            })?;
        Ok(vec![one])
    }

    /// Fetches selected sources in bounded parallel waves and commits each
    /// result through the single-threaded cache. A failing source never
    /// aborts the rest; the first structured failure is returned for the
    /// all-failed path.
    fn fetch_targets(
        &mut self,
        targets: &[&ResolvedSource],
        force: bool,
        touched: &mut std::collections::BTreeSet<SubscriptionId>,
    ) -> (Vec<caly_core::domain::DisplayNode>, bool, Option<ActorFailure>) {
        if force {
            for source in targets {
                self.cache.clear_validators(source.id);
            }
        }
        let mut merged: Vec<caly_core::domain::DisplayNode> = Vec::new();
        let mut any_changed = false;
        let mut first_error: Option<ActorFailure> = None;
        // Pre-read conditional metadata once, up front; only this function's
        // commit stage mutates the cache.
        tracing::debug!(targets = targets.len(), force, "refresh fetch stage");
        let pairs: Vec<(&ResolvedSource, FetchValidators)> = targets
            .iter()
            .map(|source| (*source, self.cache.validators(source.id)))
            .collect();
        for wave in pairs.chunks(MAX_CONCURRENT_FETCHES) {
            let outcomes = fetch_waves(wave, MAX_CONCURRENT_FETCHES, &|(source, validators)| {
                fetch_network(&self.handle, self.policy, &source.url, validators)
            });
            for (source, outcome) in wave.iter().map(|(source, _)| source).zip(outcomes) {
                let id = source.id;
                tracing::debug!(
                    subscription = %id,
                    ok = outcome.is_ok(),
                    updated = matches!(outcome, Ok(FetchResult::Updated { .. })),
                    "fetch wave outcome"
                );
                match outcome {
                    Ok(result) => match self.commit_fetch_result(id, result, touched) {
                        Ok(changed) => any_changed |= changed,
                        Err(error) => {
                            Self::warn_fetch_failure(source, &error, "cache commit");
                            if first_error.is_none() {
                                first_error = Some(error);
                            }
                            continue;
                        }
                    },
                    Err(error) => {
                        Self::warn_fetch_failure(source, &error, "network fetch");
                        if first_error.is_none() {
                            first_error = Some(error);
                        }
                        continue;
                    }
                }
                self.last_refresh.insert(id, std::time::Instant::now());
                match self.cache.refresh_projection(id) {
                    Ok(projection) => merged.extend(projection.nodes.into_vec()),
                    Err(error) => {
                        Self::warn_fetch_failure(source, &error, "re-projection");
                        if first_error.is_none() {
                            first_error = Some(error);
                        }
                    }
                }
            }
        }
        (merged, any_changed, first_error)
    }

    /// Re-projects every declared source the refresh did NOT target
    /// (the inline generation is handled by the caller — it is already
    /// folded above). Unprojectable sources warn and skip: a source
    /// never fetched this boot has no cached body, and that must not
    /// fail someone else's targeted refresh.
    fn merge_kept_projections(
        &mut self,
        declared: &std::collections::BTreeSet<SubscriptionId>,
        targets: &[&ResolvedSource],
    ) -> Vec<caly_core::domain::DisplayNode> {
        let target_ids: std::collections::BTreeSet<SubscriptionId> =
            targets.iter().map(|source| source.id).collect();
        let mut kept = Vec::new();
        for id in declared
            .iter()
            .filter(|id| **id != INLINE_SUBSCRIPTION_ID && !target_ids.contains(id))
        {
            match self.cache.refresh_projection(*id) {
                Ok(projection) => kept.extend(projection.nodes.into_vec()),
                Err(error) => tracing::warn!(
                    subscription = %id,
                    error = %error.message,
                    "kept source has no cached projection; skipping it in the targeted refresh outcome"
                ),
            }
        }
        kept
    }

    fn warn_fetch_failure(source: &ResolvedSource, error: &ActorFailure, stage: &'static str) {
        tracing::warn!(
            subscription = %source.id,
            source = %source.url,
            error = %error.message,
            stage,
            "subscription source fetch failed; keeping any cached nodes"
        );
    }
}

/// W2-β2b (Q5 cadence consumption): whether the `#59` periodic tick
/// should fetch this source now. `Some(0)` pins the source static
/// (never scheduled); `None` inherits the batch tick (always due);
/// `Some(m)` is due only after `m` minutes since the last successful
/// fetch — a source never fetched (daemon restart) is due.
fn due_for_scheduled_refresh(
    every_minutes: Option<u64>,
    last: Option<&std::time::Instant>,
    now: std::time::Instant,
) -> bool {
    match every_minutes {
        Some(0) => false,
        Some(minutes) => {
            let interval = std::time::Duration::from_secs(minutes.saturating_mul(60));
            last.is_none_or(|since| now.duration_since(*since) >= interval)
        }
        None => true,
    }
}

/// Resolves every enabled subscription source: `CALY_SUBSCRIPTION_URL` first
/// (single-source override), then the layered config (`subscriptions.url` plus
/// each enabled `subscriptions.sources` entry). Each URL maps to a stable
/// `SubscriptionId` derived from its SHA-256 digest, so the same URL always
/// targets the same cache entry across restarts; re-evaluated per refresh.
/// A present-but-broken `config.yaml` is a hard error: swallowing it used to
/// bury the parse failure behind a misleading "no subscription source" hint.
fn resolve_sources() -> Result<Vec<ResolvedSource>, ActorFailure> {
    let mut urls: Vec<(String, Option<u64>)> = Vec::new();
    if let Ok(value) = std::env::var("CALY_SUBSCRIPTION_URL") {
        urls.push((value, None));
    } else {
        let app_paths = AppPaths::from_env();
        let root = app_paths.config.clone();
        if root.join("config.yaml").is_file() {
            let profile = std::env::var("CALY_PROFILE")
                .ok()
                .and_then(|v| SafeName::new(v).ok());
            let paths = LayeredConfigPaths::new(root, profile);
            let config =
                load_layered_yaml_strict(&paths, LoaderLimits::secure_default(), &app_paths.state)
                    .map_err(|error| {
                        crate::failure(
                            &format!("config load failed while resolving subscriptions: {error}"),
                            "run `caly config validate` and fix the configuration",
                        )
                    })?;
            // W2-β2b: keep the per-source cadence alongside the URL so
            // the scheduled-refresh filter can gate on it; the legacy
            // singular `subscriptions.url` has no per-source fields.
            urls.extend(
                config
                    .subscriptions
                    .sources
                    .iter()
                    .filter(|source| source.enabled)
                    .map(|source| (source.url.clone(), source.refresh_every_minutes)),
            );
            urls.extend(
                config
                    .subscriptions
                    .enabled_source_urls()
                    .into_iter()
                    .filter(|url| {
                        !config
                            .subscriptions
                            .sources
                            .iter()
                            .any(|source| source.enabled && &source.url == url)
                    })
                    .map(|url| (url, None)),
            );
        }
    }
    let mut out: Vec<ResolvedSource> = Vec::new();
    let mut seen: std::collections::BTreeSet<SubscriptionId> = std::collections::BTreeSet::new();
    for (url, every) in urls {
        let id = subscription_id_for_url(&url);
        if seen.insert(id) {
            out.push(ResolvedSource {
                id,
                url,
                every_minutes: every,
            });
        }
    }
    Ok(out)
}

/// W2-β2b: one enabled subscription source plus its per-source
/// refresh cadence (`refresh_every_minutes`; `None` inherits the
/// batch timer cadence, `Some(0)` pins the source static).
struct ResolvedSource {
    id: SubscriptionId,
    url: String,
    every_minutes: Option<u64>,
}

#[cfg(test)]
mod tests;
