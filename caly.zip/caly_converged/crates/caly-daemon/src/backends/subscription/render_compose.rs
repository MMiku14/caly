//! Subscription-intake × coreconf-renderer fusion (the daemon path).
//!
//! The pure renderers live in `caly-coreconf` (domain values in, config bytes
//! out); intake of a fetched subscription body (decode → dialable nodes)
//! lives in `caly-profile`. This module is the single meeting point: it
//! drives the coreconf renderers with intake output so the rest of the
//! backend never re-implements either half.

use std::collections::BTreeMap;

use caly_kernel::coreconf::{
    mihomo::{
        proxy_sections::{
            MihomoGroupName, MihomoProxyEntry, MihomoProxyError, MihomoProxySet, MihomoProxyTag,
        },
        render::proxy_to_entry,
    },
    sing_box::{
        SingBoxOutboundError, SingBoxRenderTuning, node_to_json, nodes_to_outbounds,
        sing_box_document,
    },
};
use caly_core::domain::{BoundedVec, DialableNode, NodeId, SubscriptionId};
use serde_json::Value;
use caly_core::subscription::{
    PipelineError, SubscriptionDocument, decode_document, dedupe, display_tags,
    parse_document_dialable_lossy,
};

/// Kernel-agnostic shape of the two subscription-render errors: both the
/// Mihomo and sing-box error types expose `InvalidFormat`/`UnsupportedDocument`
/// variants with the same meaning, which is all the shared extraction needs.
trait DialableExtraction {
    const INVALID_FORMAT: Self;
    const UNSUPPORTED_DOCUMENT: Self;
}

impl DialableExtraction for SingBoxOutboundError {
    const INVALID_FORMAT: Self = Self::InvalidFormat;
    const UNSUPPORTED_DOCUMENT: Self = Self::UnsupportedDocument;
}

impl DialableExtraction for MihomoProxyError {
    const INVALID_FORMAT: Self = Self::InvalidFormat;
    const UNSUPPORTED_DOCUMENT: Self = Self::UnsupportedDocument;
}

/// Decodes a raw subscription body exactly once, then hands the document to
/// `decode` — the single-pass entry point shared by the kernel renderers
/// (see [`sing_box_outbound_map_from_document`] for the pipeline rule).
fn decode_once<D, E>(
    body: &[u8],
    decode: impl FnOnce(&SubscriptionDocument) -> Result<D, E>,
) -> Result<D, E>
where
    E: DialableExtraction,
{
    let document = decode_document(body).map_err(|_| E::INVALID_FORMAT)?;
    decode(&document)
}

/// Generates a bounded sing-box JSON document from URI subscription lines.
pub fn uri_body_to_sing_box_json(
    body: &[u8],
    subscription: SubscriptionId,
) -> Result<Vec<u8>, SingBoxOutboundError> {
    uri_body_to_sing_box_json_with(body, subscription, &SingBoxRenderTuning::standard())
}

/// Generates the document with config-driven header tuning (controller, secret,
/// log level, mixed inbound).
pub fn uri_body_to_sing_box_json_with(
    body: &[u8],
    subscription: SubscriptionId,
    tuning: &SingBoxRenderTuning,
) -> Result<Vec<u8>, SingBoxOutboundError> {
    let nodes = decode_once(body, |document| {
        dialable_nodes::<SingBoxOutboundError>(document, subscription)
    })?;
    let outbounds = nodes_to_outbounds(nodes)?;
    sing_box_document(tuning, outbounds)
}

/// One node a kernel renderer skipped, with the reason the operator can
/// act on. Shared by the sing-box and Mihomo compose paths: both carry the
/// display tag plus a stable reason label (the unsupported protocol label,
/// possibly refined — `shadowsocks+plugin`, … — or `tag-rejected` when the
/// display name cannot become a tag).
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct NodeSkip {
    /// The node's display tag (what lists and groups show).
    pub tag: String,
    /// Stable reason label (see above).
    pub reason: &'static str,
}

/// Renders per-node sing-box outbound JSON values keyed by canonical
/// `NodeId`, skipping nodes the strict renderer cannot represent, and
/// returning the skip list alongside so the caller can warn with the
/// reason (a silently shrinking node pool is a routing change the
/// operator cannot see). The registry stores the map so a config backend
/// can rebuild the outbounds array without re-parsing the subscription
/// body (mirrors the Mihomo yaml field). Values (not strings) are stored:
/// the config backend assembles `Value`s, so strings would pay a
/// serialize→parse roundtrip per node per refresh+apply (O1).
pub fn uri_body_to_sing_box_outbound_map(
    body: &[u8],
    subscription: SubscriptionId,
) -> Result<(BTreeMap<NodeId, Value>, Vec<NodeSkip>), SingBoxOutboundError> {
    decode_once(body, |document| {
        sing_box_outbound_map_from_document(document, subscription)
    })
}

/// [`uri_body_to_sing_box_outbound_map`] on an already-decoded document —
/// the single-pass pipeline entry (`cached.rs` decodes once per refresh and
/// shares the document across the projection / mihomo / sing-box / routing
/// consumers instead of decoding the body up to four times).
pub fn sing_box_outbound_map_from_document(
    document: &SubscriptionDocument,
    subscription: SubscriptionId,
) -> Result<(BTreeMap<NodeId, Value>, Vec<NodeSkip>), SingBoxOutboundError> {
    let nodes = dialable_nodes::<SingBoxOutboundError>(document, subscription)?;
    Ok(sing_box_outbound_map_from_nodes(&nodes))
}

/// Renders the outbound map from already-parsed nodes (P2: the daemon parses
/// once and shares the nodes across the projection and both renderers).
/// Infallible: unrepresentable nodes land in the skip list, never in `Err`.
/// Accepts raw or deduped nodes — the first-seen guard below keeps both
/// shapes identical.
pub fn sing_box_outbound_map_from_nodes(
    nodes: &[DialableNode],
) -> (BTreeMap<NodeId, Value>, Vec<NodeSkip>) {
    let mut map = BTreeMap::new();
    let mut skipped = Vec::new();
    for node in nodes {
        if map.contains_key(&node.id()) {
            continue;
        }
        if let Ok(outbound) = node_to_json(node) {
            map.insert(node.id(), outbound);
        } else {
            let tag = node.display(true, None).map_or_else(
                |_| format!("node-{}", caly_core::domain::to_hex(node.id().into_bytes())),
                |display| display.name().as_str().to_owned(),
            );
            // A finer label than the bare protocol: a shadowsocks node
            // with a v2ray-plugin/obfs parameter is *not* a plain ss
            // node — the warning must say which variant lost.
            let reason = match node.protocol() {
                caly_core::domain::Protocol::Shadowsocks {
                    plugin: Some(_), ..
                } => "shadowsocks+plugin",
                // Legacy CFB ciphers: Mihomo dials them, sing-box does
                // not — name the exact cipher so the operator can see
                // why the node pool differs between cores.
                caly_core::domain::Protocol::Shadowsocks {
                    method: caly_core::domain::ShadowsocksCipher::Aes128Cfb,
                    plugin: None,
                    ..
                } => "shadowsocks+aes-128-cfb",
                caly_core::domain::Protocol::Shadowsocks {
                    method: caly_core::domain::ShadowsocksCipher::Aes256Cfb,
                    plugin: None,
                    ..
                } => "shadowsocks+aes-256-cfb",
                other => other.label(),
            };
            skipped.push(NodeSkip { tag, reason });
        }
    }
    (map, skipped)
}

/// Renders a Mihomo proxy section (proxies/groups/rules) from a subscription
/// body, reusing the same dialable pipeline as the sing-box renderer.
/// Skipped nodes ride along for the caller to warn about.
pub fn uri_body_to_mihomo_proxy_set(
    body: &[u8],
    subscription: SubscriptionId,
) -> Result<(MihomoProxySet, Vec<NodeSkip>), MihomoProxyError> {
    decode_once(body, |document| {
        mihomo_proxy_set_from_document(document, subscription)
    })
}

/// [`uri_body_to_mihomo_proxy_set`] on an already-decoded document (single-
/// pass pipeline; see [`sing_box_outbound_map_from_document`]).
/// Nodes the Mihomo renderer cannot represent (unsupported protocol, tag
/// rejection) are collected into the skip list instead of vanishing.
pub fn mihomo_proxy_set_from_document(
    document: &SubscriptionDocument,
    subscription: SubscriptionId,
) -> Result<(MihomoProxySet, Vec<NodeSkip>), MihomoProxyError> {
    // Dedupe by NodeId with the same first-seen order the projection uses, so
    // the `#N` suffix numbering assigned below matches what list UIs show.
    let deduped = dedupe(dialable_nodes::<MihomoProxyError>(document, subscription)?)
        .map_err(|_| MihomoProxyError::InvalidFormat)?;
    let nodes = deduped.nodes.as_slice();
    // Fail-closed like the projection (the old `filter_map`+`zip` truncation
    // arm is dead — `display()` cannot fail — and is not preserved; P2).
    let tags = display_tags(nodes).map_err(|_| MihomoProxyError::InvalidFormat)?;
    mihomo_proxy_set_from_nodes(nodes, &tags)
}

/// Renders the proxy set from already-parsed, already-tagged nodes (P2: the
/// daemon parses/dedupes/tags once and shares them across the projection and
/// both renderers). `tags` must align 1:1 with `nodes`; a length mismatch
/// fails closed rather than mislabeling proxies.
pub fn mihomo_proxy_set_from_nodes(
    nodes: &[DialableNode],
    tags: &[String],
) -> Result<(MihomoProxySet, Vec<NodeSkip>), MihomoProxyError> {
    if tags.len() != nodes.len() {
        return Err(MihomoProxyError::InvalidFormat);
    }
    let mut entries: Vec<MihomoProxyEntry> = Vec::with_capacity(nodes.len());
    let mut skipped = Vec::new();
    for (node, tag_text) in nodes.iter().zip(tags) {
        let Ok(tag) = MihomoProxyTag::new(tag_text.clone()) else {
            skipped.push(NodeSkip {
                tag: tag_text.clone(),
                reason: "tag-rejected",
            });
            continue;
        };
        match proxy_to_entry(node, tag) {
            Ok(entry) => entries.push(entry),
            Err(MihomoProxyError::NoUsableNodes) => {
                skipped.push(NodeSkip {
                    tag: tag_text.clone(),
                    reason: node.protocol().label(),
                });
            }
            Err(error) => return Err(error),
        }
    }
    if entries.is_empty() {
        return Err(MihomoProxyError::NoUsableNodes);
    }
    let entries =
        BoundedVec::try_from_vec(entries).map_err(|_| MihomoProxyError::TooManyProxies)?;
    let group = MihomoGroupName::new(group_name())?;
    Ok((MihomoProxySet::from_parts(entries, group), skipped))
}

/// Extracts dialable nodes through the canonical lossy intake so body-level
/// renders parse exactly what the daemon projection parses — no second
/// traversal to drift. A body with zero usable nodes now fails closed
/// instead of rendering hollow (the bootstrap maps that to
/// `BackendUnavailable`). `Clash` keeps today's `UNSUPPORTED_DOCUMENT`
/// label for unparseable YAML; every other unusable shape is
/// `INVALID_FORMAT`, matching the previous arms.
fn dialable_nodes<E: DialableExtraction>(
    document: &SubscriptionDocument,
    subscription: SubscriptionId,
) -> Result<Vec<DialableNode>, E> {
    parse_document_dialable_lossy(document, subscription)
        .map(|lossy| lossy.nodes)
        .map_err(|error| match error {
            PipelineError::UnsupportedDocument | PipelineError::Clash => E::UNSUPPORTED_DOCUMENT,
            _ => E::INVALID_FORMAT,
        })
}

/// Selects the configured Clash proxy-group name with a safe default.
fn group_name() -> String {
    match std::env::var("CALY_MIHOMO_PROXY_GROUP").as_deref() {
        Ok(value) if !value.trim().is_empty() => value.trim().to_owned(),
        _ => "AUTO".to_owned(),
    }
}

#[cfg(test)]
mod tests {
//! Fusion tests for `render_compose` (subscription intake × coreconf
//! renderers), relocated from `caly-profile` during the P3a split: pre-split
//! they lived next to the renderers; post-split they must cross intake and
//! rendering, which only this crate may do.

use super::*;

/// Subscription-intake leg reused by the consistency test below.
use caly_core::subscription::parse_uri_body_to_display_lossy;

#[test]
fn projection_tags_repeated_names_like_the_kernel_renderer() -> Result<(), String> {
    // The list projection and the Mihomo renderer must number repeated
    // names identically, otherwise `delay`/`select` names never match.
    let body = [
        "ss://YWVzLTI1Ni1nY206cGFzc3dvcmQ@203.0.113.1:8388#dup",
        "vless://00000000-0000-0000-0000-000000000001@203.0.113.2:443#dup",
    ]
    .join("\n")
    .into_bytes();
    let id = SubscriptionId::from_bytes([7; 16]);
    let projection =
        parse_uri_body_to_display_lossy(&body, id).map_err(|e| format!("{e:?}"))?;
    let (set, _) = uri_body_to_mihomo_proxy_set(&body, id).map_err(|e| format!("{e:?}"))?;
    let projected = projection
        .nodes
        .iter()
        .map(|node| node.name().as_str().to_owned())
        .collect::<Vec<_>>();
    let rendered = set
        .entries()
        .iter()
        .map(|entry| entry.tag.as_str().to_owned())
        .collect::<Vec<_>>();
    assert_eq!(projected, rendered, "projection and kernel tags must match");
    Ok(())
}

mod sing_box_fusion {
    //! Former `caly-profile::subscription::sing_box` tests (document header
    //! and whole-document renders through intake).

    use super::*;
    use serde_json::Value;

    fn ss_uri(name: &str) -> String {
        use base64::{Engine as _, engine::general_purpose};
        let credentials = general_purpose::STANDARD.encode("aes-256-gcm:pw");
        format!("ss://{credentials}@example.com:8388#{name}")
    }

    #[test]
    fn document_renders_tun_inbound_and_dns_block() {
        use caly_core::domain::{TunConfig, TunStack};
        // P3b: tuning hands the bounded DNS settings and typed route rules to
        // the renderer directly (no more pre-rendered JSON fragments).
        let dns = caly_core::dns::DnsSettingsBuilder::new()
            .enabled(true)
            .push_nameserver("8.8.8.8")
            .unwrap()
            .build()
            .unwrap()
            .unwrap();
        let tun = TunConfig::new(TunStack::Gvisor, true, true, 1400).unwrap();
        let tuning = SingBoxRenderTuning {
        default_mode: caly_core::domain::ProxyMode::Rule,
            controller: "127.0.0.1:9291".to_owned(),
            secret: "topsecret".to_owned(),
            log_level: "warn".to_owned(),
            mixed_port: 8899,
            allow_lan: false,
            bind_address: "*".to_owned(),
            tun: Some(tun),
            tun_interface: "caly0".to_owned(),
            dns: Some(dns),
            sniff: true,
            sniff_override_destination: true,
            route_rules: vec![caly_kernel::coreconf::rules::RouteRule {
                domain: None,
                domain_keyword: None,
                domain_suffix: Some(vec!["example.com".to_owned()]),
                ip_cidr: None,
                outbound: "block".to_owned(),
                rule_set: None,
                ip_is_private: None,
            }],
            rule_sets: Vec::new(),
            route_final: "block".to_owned(),
            block_outbound: true,
        };
        let body = ss_uri("node-a").into_bytes();
        let json =
            uri_body_to_sing_box_json_with(&body, SubscriptionId::from_bytes([1; 16]), &tuning)
                .unwrap_or_else(|error| panic!("render failed: {error:?}"));
        let value: Value = serde_json::from_slice(&json).unwrap();
        let inbounds = value["inbounds"].as_array().unwrap();
        assert_eq!(inbounds.len(), 2, "mixed + tun inbounds expected");
        assert_eq!(inbounds[0]["listen_port"], 8899);
        assert_eq!(inbounds[0]["sniff"], true);
        assert_eq!(inbounds[0]["sniff_override_destination"], true);
        assert_eq!(inbounds[1]["type"], "tun");
        assert_eq!(inbounds[1]["interface_name"], "caly0");
        assert_eq!(inbounds[1]["mtu"], 1400);
        assert!(value["dns"]["servers"].is_array());
        assert_eq!(value["route"]["default_domain_resolver"], "nameserver-0");
        assert_eq!(value["experimental"]["clash_api"]["secret"], "topsecret");
        assert_eq!(value["log"]["level"], "warn");
        // Route rules: clash_mode entries first, then config-driven rules.
        let rules = value["route"]["rules"].as_array().unwrap();
        assert_eq!(rules.len(), 3);
        assert_eq!(rules[2]["domain_suffix"][0], "example.com");
        assert_eq!(rules[2]["outbound"], "block");
        assert_eq!(value["route"]["final"], "block");
        let outbound_tags: Vec<&str> = value["outbounds"]
            .as_array()
            .unwrap()
            .iter()
            .filter_map(|outbound| outbound["tag"].as_str())
            .collect();
        assert!(outbound_tags.contains(&"block"));
    }

    #[test]
    fn trojan_and_vmess_render_tls_alter_id_and_transport() -> Result<(), String> {
        let body = "trojan://secret-pass@example.com:443?security=tls&sni=example.com&type=ws&path=%2Fstream#trojan-ws\n\
                    vmess://eyJhZGQiOiJleGFtcGxlLmNvbSIsInBvcnQiOjQ0MywiaWQiOiI2YTg5YTIxNS0yMmJmLTRiZDctOTY0Mi1iOTViMmUwOTU4M2EiLCJhaWQiOjAsIm5ldCI6IndzIiwicGF0aCI6Ii9zIiwiaG9zdCI6ImV4YW1wbGUuY29tIiwidGxzIjoidGxzIiwicHMiOiJ2bWVzLW5vZGUifQ==\n"
            .as_bytes()
            .to_vec();
        let id = SubscriptionId::from_bytes([8; 16]);
        let json = uri_body_to_sing_box_json(&body, id).map_err(|e| format!("{e:?}"))?;
        let text = String::from_utf8_lossy(&json);
        assert!(text.contains("\"tls\""), "trojan/vmess TLS must render");
        assert!(text.contains("\"alter_id\""), "vmess alter_id must render");
        assert!(text.contains("\"security\""), "vmess security must render");
        assert!(text.contains("\"transport\""), "ws transport must render");
        Ok(())
    }

    #[test]
    fn hysteria2_and_tuic_render() -> Result<(), String> {
        let body = "hysteria2://secret@example.com:443?security=tls&sni=example.com&obfs=salamander&obfs-password=obfspass&upmbps=50&downmbps=100#hy2\n\
                    tuic://2DD61D93-75D8-4DA4-AC0E-6AECE7EAC365:hello@example.com:443?congestion_control=bbr#tuic\n"
            .as_bytes()
            .to_vec();
        let id = SubscriptionId::from_bytes([9; 16]);
        let json = uri_body_to_sing_box_json(&body, id).map_err(|e| format!("{e:?}"))?;
        let text = String::from_utf8_lossy(&json);
        assert!(text.contains("\"type\":\"hysteria2\""));
        assert!(text.contains("\"password\":\"secret\""));
        assert!(text.contains("\"up_mbps\":50"));
        assert!(text.contains("\"obfs\""));
        assert!(text.contains("\"type\":\"tuic\""));
        assert!(text.contains("\"congestion_control\":\"bbr\""));
        Ok(())
    }

    #[test]
    fn emits_global_selector_and_clash_mode_rules() -> Result<(), String> {
        let body = "vless://2DD61D93-75D8-4DA4-AC0E-6AECE7EAC365@example.com:443?security=tls#n1\n\
                    vless://2DD61D93-75D8-4DA4-AC0E-6AECE7EAC365@example.org:443?security=tls#n2\n"
            .as_bytes()
            .to_vec();
        let id = SubscriptionId::from_bytes([10; 16]);
        let json = uri_body_to_sing_box_json(&body, id).map_err(|e| format!("{e:?}"))?;
        let text = String::from_utf8_lossy(&json);
        // A GLOBAL selector over all nodes enables the Global routing mode.
        assert!(
            text.contains("\"tag\":\"GLOBAL\""),
            "must emit a GLOBAL selector"
        );
        // The clash_mode rules make rule/global/direct switchable at runtime.
        assert!(text.contains("\"clash_mode\":\"Global\",\"outbound\":\"GLOBAL\""));
        assert!(text.contains("\"clash_mode\":\"Direct\",\"outbound\":\"direct\""));
        Ok(())
    }

    #[test]
    fn outbound_map_indexes_deduped_nodes() -> Result<(), String> {
        let body = "ss://YWVzLTEyOC1nY206cGFzc3dvcmQ=@example.com:8388#first\n\
                    ss://YWVzLTEyOC1nY206cGFzc3dvcmQ=@example.com:8388#duplicate\n\
                    ss://YWVzLTEyOC1nY206cGFzc3dvcmQ=@example.net:443#second\n"
            .as_bytes()
            .to_vec();
        let id = SubscriptionId::from_bytes([9; 16]);
        let (map, _skipped) =
            uri_body_to_sing_box_outbound_map(&body, id).map_err(|e| format!("{e:?}"))?;
        // Two distinct canonical nodes (duplicate lines collapse to one).
        assert_eq!(map.len(), 2, "deduplicated nodes expected");
        for value in map.values() {
            let tag = value.get("tag").and_then(Value::as_str).ok_or("missing tag")?;
            assert!(tag.starts_with("proxy-"), "tag must be proxy-<id>");
            assert_eq!(value.get("type").and_then(Value::as_str), Some("shadowsocks"));
        }
        Ok(())
    }
}

mod mihomo_fusion {
    //! Former `caly-profile::subscription::mihomo` tests that cross intake
    //! and rendering (pure-renderer tests moved with the renderer to
    //! `caly-coreconf`).

    use super::*;
    use caly_kernel::coreconf::mihomo::proxy_sections::render_proxy_sections;

    /// A mixed, minimal, deterministic subscription body.
    fn mini_body() -> Vec<u8> {
        let ss = "ss://Y2hhY2hhMjAtaWV0Zi1wb2x5MTMwNTpzZWNyZXRwYXNz@example.com:8443#ss-node";
        format!(
            "vless://a5ea9247-79f3-4655-aece-3fb51e1e669e@example.com:443?security=tls#vless-node\n\
             trojan://secret-pass@example.com:443?security=tls#trojan-node\n{ss}\n"
        )
        .into_bytes()
    }

    #[test]
    fn clash_yaml_renders_a_proxy_set() -> Result<(), String> {
        let body = br#"proxies:
  - name: "hk-ss"
    type: ss
    server: example.com
    port: 8388
    cipher: aes-128-gcm
    password: secret
  - name: "jp-trojan"
    type: trojan
    server: example.org
    port: 443
    password: pass
"#
        .to_vec();
        let id = SubscriptionId::from_bytes([6; 16]);
        let (set, _) = uri_body_to_mihomo_proxy_set(&body, id).map_err(|e| format!("{e:?}"))?;
        assert_eq!(set.len(), 2, "clash yaml must render both proxies");
        let section = render_proxy_sections(&set);
        assert!(section.contains("type: ss"));
        assert!(section.contains("type: trojan"));
        Ok(())
    }

    #[test]
    fn vless_ws_reality_renders_flow_tls_reality_and_transport() -> Result<(), String> {
        let body = "vless://a5ea9247-79f3-4655-aece-3fb51e1e669e@example.com:443?security=reality&flow=xtls-rprx-vision&sni=example.com&pbk=zT7a-PnmIWP4c-G1EDUT3KZ7URi1kc8EppAWPr3h5lk&sid=afeed89ae23b36ed&type=ws&path=%2Fstream&host=example.com#reality-ws\n"
            .as_bytes()
            .to_vec();
        let id = SubscriptionId::from_bytes([7; 16]);
        let (set, _) = uri_body_to_mihomo_proxy_set(&body, id).map_err(|e| format!("{e:?}"))?;
        assert_eq!(set.len(), 1);
        let section = render_proxy_sections(&set);
        // XTLS flow, Reality public key, and WS transport must all survive into
        // the rendered config, otherwise the outbound is incomplete.
        assert!(
            section.contains("flow: xtls-rprx-vision"),
            "flow must render"
        );
        assert!(section.contains("tls: true"), "TLS must render");
        assert!(section.contains("reality-opts:"), "reality must render");
        assert!(
            section.contains("public-key:"),
            "reality public key must render"
        );
        assert!(section.contains("network: ws"), "ws transport must render");
        assert!(section.contains("path:"), "ws path must render");
        Ok(())
    }

    #[test]
    fn renders_representable_proxies_and_group() -> Result<(), String> {
        let id = SubscriptionId::from_bytes([3; 16]);
        let (set, _) = uri_body_to_mihomo_proxy_set(&mini_body(), id).map_err(|e| format!("{e:?}"))?;
        assert_eq!(set.len(), 3, "vless, trojan and ss must all render");
        assert_eq!(set.group(), "AUTO");
        let section = render_proxy_sections(&set);
        assert!(section.contains("type: vless"));
        assert!(section.contains("type: trojan"));
        assert!(section.contains("type: ss"));
        assert!(section.contains("proxy-groups:"));
        assert!(section.contains("rules:"));
        assert!(section.contains("MATCH,AUTO"));
        Ok(())
    }

    #[test]
    fn unsupported_document_is_rejected() {
        let id = SubscriptionId::from_bytes([4; 16]);
        let body = b"this is not a subscription format".to_vec();
        let result = uri_body_to_mihomo_proxy_set(&body, id);
        assert!(matches!(result, Err(MihomoProxyError::InvalidFormat)));
    }

    #[test]
    fn http_proxy_uri_now_renders() {
        let id = SubscriptionId::from_bytes([5; 16]);
        // An HTTP proxy URI maps to `Protocol::Http`, which Mihomo can dial.
        let body = b"http://user:pass@example.com:8080#http-node\n".to_vec();
        let result = uri_body_to_mihomo_proxy_set(&body, id);
        assert!(result.is_ok(), "http proxy nodes must render: {result:?}");
    }

    #[test]
    fn unsupported_nodes_are_reported_as_skips() -> Result<(), String> {
        // P2: a WireGuard node has no Mihomo representation; it must be
        // reported (like the sing-box skip list), not silently dropped.
        let id = SubscriptionId::from_bytes([6; 16]);
        let body = b"vless://a5ea9247-79f3-4655-aece-3fb51e1e669e@example.com:443#vl\nwireguard://abcdef0123456789abcdef0123456789@example.com:51820?private-key=BBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBB=&public-key=AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA=#wg\n".to_vec();
        let (set, skipped) =
            uri_body_to_mihomo_proxy_set(&body, id).map_err(|e| format!("{e:?}"))?;
        assert_eq!(set.len(), 1);
        assert_eq!(skipped.len(), 1);
        assert_eq!(skipped[0].reason, "wireguard");
        assert_eq!(skipped[0].tag, "wg");
        Ok(())
    }

    #[test]
    fn unparseable_body_fails_closed_like_the_projection() {
        let id = SubscriptionId::from_bytes([6; 16]);
        // A WireGuard URI parses nowhere, so the canonical intake
        // rejects the body — the render fails closed with the same
        // unusable-body shape the daemon projection reports, instead
        // of falling through to `NoUsableNodes` (which now means only
        // "parsed, but nothing renderable").
        let body = b"wireguard://abcdef0123456789abcdef0123456789@example.com:51820?public-key=AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA=#wg\n".to_vec();
        let result = uri_body_to_mihomo_proxy_set(&body, id);
        assert!(matches!(result, Err(MihomoProxyError::InvalidFormat)));
    }

    #[test]
    fn trojan_and_vmess_render_tls_and_transport() -> Result<(), String> {
        // Trojan over TLS with a ws transport, and a vmess with alterId/cipher/tls.
        let body = "trojan://secret-pass@example.com:443?security=tls&sni=example.com&type=ws&path=%2Fstream#trojan-ws\n\
                    vmess://eyJhZGQiOiJleGFtcGxlLmNvbSIsInBvcnQiOjQ0MywiaWQiOiI2YTg5YTIxNS0yMmJmLTRiZDctOTY0Mi1iOTViMmUwOTU4M2EiLCJhaWQiOjAsIm5ldCI6IndzIiwicGF0aCI6Ii9zIiwiaG9zdCI6ImV4YW1wbGUuY29tIiwidGxzIjoidGxzIiwicHMiOiJ2bWVzLW5vZGUifQ==\n"
            .as_bytes()
            .to_vec();
        let id = SubscriptionId::from_bytes([8; 16]);
        let (set, _) = uri_body_to_mihomo_proxy_set(&body, id).map_err(|e| format!("{e:?}"))?;
        assert_eq!(set.len(), 2);
        let section = render_proxy_sections(&set);
        assert!(section.contains("type: trojan"));
        assert!(section.contains("type: vmess"));
        assert!(
            section.contains("tls: true"),
            "trojan/vmess TLS must render"
        );
        assert!(section.contains("network: ws"), "ws transport must render");
        assert!(section.contains("alterId: 0"), "vmess alterId must render");
        assert!(section.contains("cipher: auto"), "vmess cipher must render");
        Ok(())
    }

    #[test]
    fn hysteria2_and_tuic_render() -> Result<(), String> {
        let body = "hysteria2://secret@example.com:443?security=tls&sni=example.com&obfs=salamander&obfs-password=obfspass&upmbps=50&downmbps=100#hy2\n\
                    tuic://2DD61D93-75D8-4DA4-AC0E-6AECE7EAC365:hello@example.com:443?congestion_control=bbr#tuic\n"
            .as_bytes()
            .to_vec();
        let id = SubscriptionId::from_bytes([9; 16]);
        let (set, _) = uri_body_to_mihomo_proxy_set(&body, id).map_err(|e| format!("{e:?}"))?;
        assert_eq!(set.len(), 2, "hysteria2 and tuic must render");
        let section = render_proxy_sections(&set);
        assert!(section.contains("type: hysteria2"));
        // Passwords render through yaml_quote like every other credential.
        assert!(section.contains("password: \"secret\""));
        assert!(section.contains("obfs-password: \"obfspass\""));
        assert!(section.contains("obfs: salamander"));
        assert!(section.contains("type: tuic"));
        assert!(section.contains("password: \"hello\""));
        assert!(section.contains("congestion-controller: bbr"));
        Ok(())
    }
}

/// 2026-08-12: http/socks5 nodes render into the sing-box map (they
/// are first-class sing-box outbounds) instead of being skipped.
#[test]
fn http_and_socks5_nodes_render_in_sing_box_map() -> Result<(), String> {
    let id = SubscriptionId::from_bytes([7; 16]);
    let body = b"http://user:pass@a.example.com:8080#HTTP - a\nsocks5://u:p@b.example.com:1080#SOCKS - b\n"
            .to_vec();
    let (map, skipped) =
        uri_body_to_sing_box_outbound_map(&body, id).map_err(|e| format!("{e:?}"))?;
    assert_eq!(map.len(), 2, "both proxy nodes must render");
    assert!(skipped.is_empty(), "no skips expected: {skipped:?}");
    let json = map
        .values()
        .map(serde_json::Value::to_string)
        .collect::<Vec<_>>()
        .join(",");
    assert!(json.contains("\"type\":\"http\""), "{json}");
    assert!(json.contains("\"type\":\"socks\""), "{json}");
    Ok(())
}

/// 2026-08-12: a shadowsocks node with a v2ray-plugin parameter is
/// labelled `shadowsocks+plugin` in the skip list — the warning must
/// say which variant lost, not a bare protocol name.
#[test]
fn ss_plugin_nodes_are_skipped_with_variant_label() -> Result<(), String> {
    let id = SubscriptionId::from_bytes([8; 16]);
    let body =
        b"ss://bm9uZTpwYXNz@1.2.3.4:443?plugin=v2ray-plugin%3Bmode%3Dwebsocket#ss-plug\n".to_vec();
    let (map, skipped) =
        uri_body_to_sing_box_outbound_map(&body, id).map_err(|e| format!("{e:?}"))?;
    assert!(map.is_empty(), "plugin ss must not render: {map:?}");
    assert_eq!(skipped.len(), 1, "{skipped:?}");
    assert_eq!(skipped[0].reason, "shadowsocks+plugin");
    Ok(())
}

/// 2026-08-12: a legacy-CFB ss node is skipped with the exact cipher
/// in the label (`shadowsocks+aes-128-cfb`) — Mihomo dials CFB,
/// sing-box does not, so the diagnostic must name the cipher, not
/// the generic protocol.
#[test]
fn cfb_ss_nodes_are_skipped_with_cipher_label() -> Result<(), String> {
    let id = SubscriptionId::from_bytes([10; 16]);
    // aes-128-cfb: YWVzLTEyOC1jZmI6cGFzcw== = "aes-128-cfb:pass"
    let body = b"ss://YWVzLTEyOC1jZmI6cGFzcw@1.2.3.4:443#cfb-node\n".to_vec();
    let (map, skipped) =
        uri_body_to_sing_box_outbound_map(&body, id).map_err(|e| format!("{e:?}"))?;
    assert!(map.is_empty(), "cfb ss must not render");
    assert_eq!(skipped.len(), 1, "{skipped:?}");
    assert_eq!(skipped[0].reason, "shadowsocks+aes-128-cfb");
    Ok(())
}

}
