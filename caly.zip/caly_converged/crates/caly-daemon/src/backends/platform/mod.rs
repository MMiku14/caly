//! Linux desktop system-proxy backend (GNOME family / KDE Plasma /
//! session-env fallback for desktops without a proxy database).

use caly_core::domain::{BoundedText, PlatformEffectView};
use crate::platform::command::{
    CommandArguments, CommandRequest, CommandResult, CommandRunner, LinuxCommandRunner,
};
use crate::platform::desktop::{
    DesktopProxyMode, capture_proxy_state, desktop_session_id, detect_desktop_mode,
};
use caly_core::ports::{ActorFailure, PlatformCommandBackend};

/// Linux desktop system-proxy backend using shell-free bounded commands.
pub struct LinuxSystemProxyBackend {
    runner: LinuxCommandRunner,
    host: String,
    port: u16,
    mode: DesktopProxyMode,
}

impl LinuxSystemProxyBackend {
    /// Detects the desktop and prepares the matching backend.
    pub fn new(host: String, port: u16) -> Result<Self, ActorFailure> {
        if host.is_empty() || port == 0 {
            return Err(crate::failure(
                "system proxy endpoint is invalid",
                "configure a non-empty host and port",
            ));
        }
        Ok(Self {
            runner: LinuxCommandRunner,
            host,
            port,
            mode: detect_desktop_mode(),
        })
    }

    /// Returns the detected desktop mode (used by tests and diagnostics).
    pub const fn mode(&self) -> DesktopProxyMode {
        self.mode
    }

    /// Returns the configured proxy host (used by durable recovery records).
    pub fn host(&self) -> &str {
        self.host.as_str()
    }

    /// Returns the configured proxy port (used by durable recovery records).
    pub const fn port(&self) -> u16 {
        self.port
    }
}

impl PlatformCommandBackend for LinuxSystemProxyBackend {
    fn set_system_proxy(&mut self, enabled: bool) -> Result<PlatformEffectView, ActorFailure> {
        let result = match self.mode {
            DesktopProxyMode::Gnome => self.set_gnome(enabled),
            DesktopProxyMode::Kde => self.set_kde(enabled),
            DesktopProxyMode::SessionEnv => self.set_session_env(enabled),
            DesktopProxyMode::Unsupported => Err(unsupported_desktop()),
        };
        result?;
        Ok(PlatformEffectView::proxy(enabled))
    }

    fn set_system_proxy_pac(&mut self, url: &str) -> Result<PlatformEffectView, ActorFailure> {
        // Shared gate with the CLI pre-check: a garbage URL stored as
        // `autoconfig-url` breaks the desktop proxy with no further
        // diagnostics, so it never reaches a desktop writer.
        crate::platform::pac::validate_pac_url(url).map_err(|error| {
            crate::failure(
                &error.to_string(),
                "pass an http(s) PAC URL or `file://` path",
            )
        })?;
        match self.mode {
            // GNOME and KDE Plasma both have first-class PAC settings
            // (mode=auto + autoconfig URL / `Proxy Config Script`).
            DesktopProxyMode::Gnome => gnome::apply_pac(&mut self.runner, url)?,
            DesktopProxyMode::Kde => {
                let tool = kde::kwriteconfig_tool();
                kde::apply_pac(&mut self.runner, tool, url)?;
            }
            // Session-env desktops have no proxy database;
            // environment.d can only carry fixed proxy variables, not
            // a PAC URL. Keep this an explicit, actionable error
            // instead of silently pretending a fixed proxy endpoint is
            // equivalent to PAC evaluation.
            DesktopProxyMode::SessionEnv | DesktopProxyMode::Unsupported => {
                return Err(crate::unsupported_failure(
                    &format!(
                        "system proxy PAC mode is not available on this desktop ({})",
                        self.mode.label()
                    ),
                    "use GNOME or KDE Plasma for PAC mode, or `caly sysproxy on` for a manual endpoint",
                ));
            }
        }
        Ok(PlatformEffectView::proxy(true))
    }
}

impl LinuxSystemProxyBackend {
    /// GNOME: write `org.gnome.system.proxy` via gsettings.
    fn set_gnome(&mut self, enabled: bool) -> Result<(), ActorFailure> {
        gnome::apply(&mut self.runner, &self.host, self.port, enabled)
    }

    /// KDE Plasma: write `kioslaverc` via kwriteconfig and notify KIO.
    fn set_kde(&mut self, enabled: bool) -> Result<(), ActorFailure> {
        let tool = kde::kwriteconfig_tool();
        kde::apply_kde_proxy(&mut self.runner, tool, &self.host, self.port, enabled)
    }

    /// Session-env desktops: write a user `environment.d` proxy file
    /// consumed by the session (takes effect at the next login).
    fn set_session_env(&mut self, enabled: bool) -> Result<(), ActorFailure> {
        let contents = session_env::proxy_environment_contents(&self.host, self.port, enabled);
        session_env::write_environment_d(&contents)
    }

    /// Captures the current desktop proxy state as `(mode, endpoint)` before
    /// engagement. Best-effort: unreadable state degrades to `("none", "")`,
    /// which restores as a disabled proxy, never blocking engagement.
    pub fn capture_original_state(&mut self) -> (String, String) {
        // P8b: read side lives in caly-platform::desktop (single source of
        // truth for both the daemon capture and the CLI's offline view).
        capture_proxy_state(self.mode)
    }

    /// Restores a previously captured desktop proxy state. `manual` with an
    /// empty endpoint degrades to disabling the proxy (no guessed endpoints).
    pub fn restore_original(
        &mut self,
        mode: &str,
        endpoint: &str,
    ) -> Result<PlatformEffectView, ActorFailure> {
        match self.mode {
            DesktopProxyMode::Gnome => gnome::restore(&mut self.runner, mode, endpoint),
            DesktopProxyMode::Kde => kde::restore(&mut self.runner, mode, endpoint),
            DesktopProxyMode::SessionEnv => session_env::restore(endpoint, mode == "manual"),
            DesktopProxyMode::Unsupported => Err(unsupported_desktop()),
        }?;
        Ok(PlatformEffectView::none())
    }
}

/// Capability-gap failure naming the detected session so the operator
/// knows *which* desktop is unsupported (shared by engage and restore
/// so the wording cannot drift).
fn unsupported_desktop() -> ActorFailure {
    crate::unsupported_failure(
        &format!(
            "no supported system-proxy backend for desktop '{}'",
            desktop_session_id()
        ),
        "use GNOME, MATE, KDE Plasma, XFCE, LXQt, or a Wayland compositor \
         (niri, sway, Hyprland, …); otherwise configure the proxy manually",
    )
}

fn push_argument(
    arguments: &mut CommandArguments,
    value: &str,
    message: &str,
    action: &str,
) -> Result<(), ActorFailure> {
    let argument =
        BoundedText::new(value.to_owned()).map_err(|_| crate::failure(message, action))?;
    arguments.try_push(argument).map_err(|_| {
        crate::failure(
            "system proxy argument list is full",
            "reduce system proxy arguments",
        )
    })
}

/// Runs one desktop-backend command and requires exit code zero. Shared by
/// the GNOME and KDE backends so the failure wording cannot drift.
///
/// Failures name the executable and carry a bounded stderr tail: a bare
/// "command failed" leaves the operator (and the bug report) with no
/// actionable detail, while gsettings/kwriteconfig usually say exactly
/// what is wrong (missing schema, unwritable config, …).
pub(super) fn run_ok<R: CommandRunner>(
    runner: &mut R,
    request: CommandRequest,
) -> Result<CommandResult, ActorFailure> {
    let executable = request.executable.display().to_string();
    let result = runner.run_bounded(request).map_err(|_| {
        crate::failure(
            &format!("system proxy command '{executable}' could not start"),
            "install the desktop backend or use a supported desktop",
        )
    })?;
    if result.exit_code != Some(0) {
        let code = result
            .exit_code
            .map_or_else(|| "signal".to_owned(), |code| code.to_string());
        return Err(crate::failure(
            &format!(
                "system proxy command '{executable}' failed (exit {code}): {}",
                stderr_tail(&result)
            ),
            "inspect desktop proxy permissions",
        ));
    }
    Ok(result)
}

/// Bounded one-line stderr tail for failure messages (`FailureMessage`
/// clamps again downstream, so this is about readability, not safety).
fn stderr_tail(result: &CommandResult) -> String {
    let single_line = String::from_utf8_lossy(result.stderr.as_slice())
        .split_whitespace()
        .collect::<Vec<_>>()
        .join(" ");
    if single_line.is_empty() {
        "no error output".to_owned()
    } else {
        single_line.chars().take(160).collect()
    }
}

/// Builds a bounded argument vector from string slices.
pub(crate) fn argv(parts: &[&[&str]]) -> Result<CommandArguments, ActorFailure> {
    let mut arguments = CommandArguments::new();
    for part in parts {
        for value in *part {
            push_argument(
                &mut arguments,
                value,
                "system proxy argument is too long",
                "shorten the system proxy command",
            )?;
        }
    }
    Ok(arguments)
}

mod durable;
mod durable_support;
mod durable_tun;
mod gnome;
mod kde;
mod session_env;
mod tun;

pub use durable::{DesktopProxyControl, DurableSystemProxyBackend, SharedProxyRecoveryStore};
pub use durable_tun::{DurableTunBackend, SharedTunRecoveryStore, TunControl};
pub use tun::LinuxTunCommandBackend;

/// The durable platform backend used by the daemon composition.
pub type PlatformBackend = DurableSystemProxyBackend<LinuxSystemProxyBackend>;

#[cfg(test)]
mod tests {
    use super::*;
    use std::path::PathBuf;

    use caly_core::domain::BoundedVec;
    use crate::platform::command::CommandResult;

    struct ScriptedRunner {
        exit_code: Option<i32>,
        stderr: &'static str,
    }

    impl CommandRunner for ScriptedRunner {
        fn run_bounded(
            &mut self,
            _request: CommandRequest,
        ) -> Result<CommandResult, crate::platform::PlatformFailure> {
            Ok(CommandResult {
                exit_code: self.exit_code,
                stdout: BoundedVec::new(),
                stderr: BoundedVec::try_from_vec(self.stderr.as_bytes().to_vec())
                    .unwrap_or_default(),
            })
        }
    }

    fn request(executable: &str) -> CommandRequest {
        CommandRequest {
            executable: PathBuf::from(executable),
            arguments: CommandArguments::new(),
            timeout: std::time::Duration::from_secs(2),
        }
    }

    #[test]
    fn run_ok_reports_executable_and_stderr_on_failure() {
        let mut runner = ScriptedRunner {
            exit_code: Some(1),
            stderr: "Schema 'org.gnome.system.proxy' is not installed\n",
        };
        let Err(error) = run_ok(&mut runner, request("gsettings")) else {
            panic!("a nonzero exit must fail");
        };
        assert!(
            error.message.as_str().contains("'gsettings'"),
            "{}",
            error.message.as_str()
        );
        assert!(
            error.message.as_str().contains("not installed"),
            "{}",
            error.message.as_str()
        );
    }

    #[test]
    fn run_ok_reports_silent_failures_without_stderr() {
        let mut runner = ScriptedRunner {
            exit_code: Some(2),
            stderr: "",
        };
        let Err(error) = run_ok(&mut runner, request("kwriteconfig5")) else {
            panic!("a nonzero exit must fail");
        };
        assert!(
            error.message.as_str().contains("no error output"),
            "{}",
            error.message.as_str()
        );
    }

    #[test]
    fn set_system_proxy_pac_rejects_garbage_urls_before_dispatch() {
        // Validation runs before desktop dispatch, so this holds on
        // every desktop (the test host's session is irrelevant).
        let mut backend =
            LinuxSystemProxyBackend::new("127.0.0.1".to_owned(), 7890).expect("valid endpoint");
        let Err(error) = PlatformCommandBackend::set_system_proxy_pac(&mut backend, "not a url")
        else {
            panic!("a garbage PAC URL must fail validation");
        };
        assert!(
            error.message.as_str().contains("invalid PAC URL"),
            "{}",
            error.message.as_str()
        );
    }
}
