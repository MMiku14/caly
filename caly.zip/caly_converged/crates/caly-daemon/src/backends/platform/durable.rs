//! Durable system-proxy backend: persists a recovery record on engagement and
//! restores it on startup, so a daemon crash never leaves the desktop proxy in
//! an unknown state.

use std::sync::Arc;

use caly_core::domain::PlatformEffectView;
use crate::platform::{
    PlatformFailure,
    recovery::{ProxyRecoveryAction, ProxyRecoveryRecord, ProxyRecoveryStore, RecoveryPhase},
};
use caly_core::ports::{ActorFailure, PlatformCommandBackend};

use super::{
    LinuxSystemProxyBackend,
    durable_support::{actor_to_platform, durable_failure},
};

/// Shared durable proxy recovery store handle.
pub type SharedProxyRecoveryStore = Arc<dyn ProxyRecoveryStore + Send + Sync>;

/// The desktop proxy operations needed for durable recovery.
pub trait DesktopProxyControl {
    fn set_system_proxy(&mut self, enabled: bool) -> Result<PlatformEffectView, ActorFailure>;
    /// PAC mode (auto + autoconfig-url). Defaults to an unsupported
    /// failure so backends opt in per desktop.
    fn set_system_proxy_pac(&mut self, _url: &str) -> Result<PlatformEffectView, ActorFailure> {
        Err(crate::unsupported_failure(
            "system proxy PAC mode is not supported on this desktop",
            "use GNOME or KDE Plasma for PAC mode, or pass a manual proxy endpoint",
        ))
    }
    fn host(&self) -> &str;
    fn port(&self) -> u16;
    /// Captures the desktop's current proxy state as `(mode, endpoint)` so a
    /// graceful shutdown can restore exactly what was found before engagement.
    fn capture_original_state(&mut self) -> (String, String);
    /// Restores a previously captured state; the durable wrapper degrades
    /// `manual` with an empty endpoint to a plain disable.
    fn restore_original(
        &mut self,
        mode: &str,
        endpoint: &str,
    ) -> Result<PlatformEffectView, ActorFailure>;
}

impl DesktopProxyControl for LinuxSystemProxyBackend {
    fn set_system_proxy(&mut self, enabled: bool) -> Result<PlatformEffectView, ActorFailure> {
        PlatformCommandBackend::set_system_proxy(self, enabled)
    }
    // Without this delegation the trait *default* (unsupported) would
    // win and GNOME PAC support would be unreachable through the
    // durable daemon path (agent audit — a niri-hosted
    // functional test masked it because both paths error).
    fn set_system_proxy_pac(&mut self, url: &str) -> Result<PlatformEffectView, ActorFailure> {
        PlatformCommandBackend::set_system_proxy_pac(self, url)
    }
    fn host(&self) -> &str {
        self.host()
    }
    fn port(&self) -> u16 {
        self.port()
    }
    fn capture_original_state(&mut self) -> (String, String) {
        self.capture_original_state()
    }
    fn restore_original(
        &mut self,
        mode: &str,
        endpoint: &str,
    ) -> Result<PlatformEffectView, ActorFailure> {
        self.restore_original(mode, endpoint)
    }
}

/// Wraps a desktop proxy control with an owner-only durable recovery store.
pub struct DurableSystemProxyBackend<C> {
    inner: C,
    store: SharedProxyRecoveryStore,
    owner_token: [u8; 16],
}

impl<C: DesktopProxyControl> DurableSystemProxyBackend<C> {
    /// Wraps `inner` with `store` and a fresh owner token.
    pub fn new(inner: C, store: SharedProxyRecoveryStore) -> Self {
        let owner_token = crate::platform::entropy::random_bytes::<16>();
        Self {
            inner,
            store,
            owner_token,
        }
    }

    /// Re-applies any pending proxy recovery record (restore-first startup gate).
    pub fn restore_first(
        &mut self,
    ) -> Result<
        crate::platform::recovery::ProxyRecoveryOutcome,
        crate::platform::recovery::ProxyRecoveryFailure,
    > {
        let store = Arc::clone(&self.store);
        crate::platform::recovery::proxy_restore_first(store.as_ref(), self)
    }

    /// Persists a recovery record for an enabled proxy side effect, capturing
    /// the desktop state found before engagement. Capture is best-effort: an
    /// unreadable state degrades to `("none", "")` (restore = disable) and
    /// never blocks engagement. `pac_url` is non-empty when the side effect
    /// is PAC mode; crash recovery then replays PAC instead of the manual
    /// endpoint (2026-08-12).
    fn persist_enabled_record(&mut self, pac_url: &str) -> Result<(), ActorFailure> {
        let (original_mode, original_endpoint) = self.inner.capture_original_state();
        let record = ProxyRecoveryRecord {
            owner_token: self.owner_token,
            phase: RecoveryPhase::Applied,
            host: self.inner.host().to_owned(),
            port: self.inner.port(),
            enabled: true,
            original_mode,
            original_endpoint,
            pac_url: pac_url.to_owned(),
        };
        self.store
            .persist(&record)
            .map_err(|e| durable_failure(e, "proxy"))?;
        Ok(())
    }

    /// Clears the recovery record when the side effect is no longer pending.
    fn clear_record(&mut self) {
        // A failed clear leaves the record behind; restore-first on the next
        // boot then re-applies the proxy. That is safe (idempotent) but
        // undesired after a successful disable — surface it instead of
        // swallowing it silently.
        if let Err(error) = self.store.clear_if_owner(self.owner_token) {
            tracing::warn!(
                error = ?error,
                "could not clear the durable system-proxy record; restore-first \
                 will re-apply it on the next daemon boot"
            );
        }
    }
}

impl<C: DesktopProxyControl> PlatformCommandBackend for DurableSystemProxyBackend<C> {
    fn set_system_proxy_pac(&mut self, url: &str) -> Result<PlatformEffectView, ActorFailure> {
        // PAC mode engages the system proxy like the manual mode: the
        // durable record is persisted the same way so a crash between
        // apply and projection stays recoverable.
        let existing = self
            .store
            .load()
            .map_err(|e| durable_failure(e, "proxy"))?
            .is_some();
        if !existing {
            // The PAC URL must reach the record: crash recovery replays
            // PAC mode via it, and an empty value would silently fall
            // back to the manual endpoint (agent audit —
            // the parameter was dropped by an earlier mechanical edit).
            self.persist_enabled_record(url)?;
        }
        match self.inner.set_system_proxy_pac(url) {
            Ok(view) => Ok(view),
            Err(error) => {
                if !existing {
                    self.clear_record();
                }
                Err(error)
            }
        }
    }

    fn set_system_proxy(&mut self, enabled: bool) -> Result<PlatformEffectView, ActorFailure> {
        if enabled {
            // Persist the intent durably before applying, so a crash between
            // apply and the projection still leaves a recoverable record. A
            // re-engagement keeps the existing record: re-capturing would
            // overwrite the user's true original state with caly's own proxy.
            let existing = self
                .store
                .load()
                .map_err(|e| durable_failure(e, "proxy"))?
                .is_some();
            if !existing {
                self.persist_enabled_record("")?;
            }
            match self.inner.set_system_proxy(true) {
                Ok(view) => Ok(view),
                Err(error) => {
                    if !existing {
                        self.clear_record();
                    }
                    Err(error)
                }
            }
        } else {
            // `sysproxy off` restores the desktop state captured before
            // engagement (the documented disable contract), then clears the
            // record. A failed restore retains the record so restore-first on
            // a later daemon boot can retry; a missing record is a no-op
            // because this daemon never engaged the proxy — touching the
            // desktop could clobber a proxy the user configured.
            self.restore_recorded_state()
        }
    }
}

impl<C: DesktopProxyControl> DurableSystemProxyBackend<C> {
    /// Graceful-shutdown restore: returns the desktop to the exact state
    /// captured before engagement, then clears the record. A failed restore
    /// retains the record so restore-first on the next boot can retry; a
    /// missing record is a no-op success.
    pub fn restore_original_and_clear(&mut self) -> Result<PlatformEffectView, ActorFailure> {
        self.restore_recorded_state()
    }

    /// Restores the desktop to the captured pre-engagement state and clears
    /// the record. Shared by `sysproxy off` and the graceful-shutdown restore
    /// so both "undo" paths behave identically: a failed restore retains the
    /// record (restore-first on a later daemon boot retries), a missing
    /// record is a no-op success.
    fn restore_recorded_state(&mut self) -> Result<PlatformEffectView, ActorFailure> {
        let Some(record) = self.store.load().map_err(|e| durable_failure(e, "proxy"))? else {
            // No record means this daemon never engaged the proxy: touching
            // the desktop here could clobber a proxy the user configured.
            return Ok(PlatformEffectView::none());
        };
        match self
            .inner
            .restore_original(&record.original_mode, &record.original_endpoint)
        {
            Ok(view) => {
                self.clear_record();
                Ok(view)
            }
            Err(error) => Err(error),
        }
    }
}

impl<C: DesktopProxyControl> ProxyRecoveryAction for DurableSystemProxyBackend<C> {
    fn restore_proxy(&mut self, record: &ProxyRecoveryRecord) -> Result<(), PlatformFailure> {
        // A PAC-mode record replays PAC (auto + autoconfig-url); the
        // manual-endpoint fallback only handles non-PAC records. Before
        // the `pac_url` field existed every record was manual, so legacy
        // records keep the old behaviour.
        let outcome = if record.pac_url.is_empty() {
            self.inner.set_system_proxy(record.enabled)
        } else {
            self.inner.set_system_proxy_pac(&record.pac_url)
        };
        outcome
            .map(|_| ())
            .map_err(|e| actor_to_platform(e, "restore-proxy", "system-proxy"))
    }

    fn current_owner_token(&self) -> [u8; 16] {
        self.owner_token
    }
}

#[cfg(test)]
mod durable_tests {
//! Tests for the durable system-proxy backend: engage/disable record
//! lifecycle, restore-first, and graceful-shutdown fidelity restore.

use std::sync::Arc;

use caly_core::domain::PlatformEffectView;
use crate::platform::recovery::{FileRecoveryStore, ProxyRecoveryRecord, RecoveryPhase};
use caly_core::ports::ActorFailure;

use super::{DesktopProxyControl, DurableSystemProxyBackend, SharedProxyRecoveryStore};
use crate::platform::recovery::ProxyRecoveryAction;
use caly_core::ports::PlatformCommandBackend;

struct FakeControl {
    fail: bool,
    enabled: bool,
    host: String,
    port: u16,
    capture_state: (String, String),
    restore_fail: bool,
    restored: Option<(String, String)>,
}

impl DesktopProxyControl for FakeControl {
    fn set_system_proxy(&mut self, enabled: bool) -> Result<PlatformEffectView, ActorFailure> {
        if self.fail {
            return Err(ActorFailure::new(
                caly_core::ports::ActorFailureKind::Infrastructure,
                "apply failed",
                "retry",
            )
            .unwrap());
        }
        self.enabled = enabled;
        Ok(PlatformEffectView::proxy(enabled))
    }
    fn host(&self) -> &str {
        &self.host
    }
    fn port(&self) -> u16 {
        self.port
    }
    fn capture_original_state(&mut self) -> (String, String) {
        self.capture_state.clone()
    }
    fn restore_original(
        &mut self,
        mode: &str,
        endpoint: &str,
    ) -> Result<PlatformEffectView, ActorFailure> {
        if self.restore_fail {
            return Err(ActorFailure::new(
                caly_core::ports::ActorFailureKind::Infrastructure,
                "restore failed",
                "retry",
            )
            .unwrap());
        }
        self.restored = Some((mode.to_owned(), endpoint.to_owned()));
        Ok(PlatformEffectView::none())
    }
}

fn fake_control(fail: bool) -> FakeControl {
    FakeControl {
        fail,
        enabled: false,
        host: "127.0.0.1".to_owned(),
        port: 7890,
        capture_state: ("none".to_owned(), String::new()),
        restore_fail: false,
        restored: None,
    }
}

fn store_path(label: &str) -> std::path::PathBuf {
    // The recovery store refuses a parent directory it cannot tighten to
    // 0700 (audit #104): root every test record in its own fresh
    // subdirectory instead of the shared temp dir itself.
    crate::platform::paths::test_helpers::unique_path_under("caly-durable-proxy", label)
        .join("record.json")
}

fn shared_store(path: &std::path::Path) -> Result<SharedProxyRecoveryStore, String> {
    FileRecoveryStore::<crate::platform::recovery::ProxyRecoveryRecord>::new(path.to_path_buf())
        .map(|store| Arc::new(store) as SharedProxyRecoveryStore)
        .map_err(|e| format!("{e:?}"))
}

fn record(seed: u8) -> ProxyRecoveryRecord {
    ProxyRecoveryRecord {
        owner_token: [seed; 16],
        phase: RecoveryPhase::Applied,
        host: "127.0.0.1".to_owned(),
        port: 7890,
        enabled: true,
        original_mode: "manual".to_owned(),
        original_endpoint: String::new(),
        pac_url: String::new(),
    }
}

fn cleanup(path: &std::path::Path) {
    let _ = std::fs::remove_file(path);
}

#[test]
fn engage_persists_record_and_disable_clears_it() -> Result<(), String> {
    let path = store_path("engage");
    let store = shared_store(&path)?;
    let mut backend = DurableSystemProxyBackend::new(fake_control(false), store);
    backend
        .set_system_proxy(true)
        .map_err(|e| format!("{e:?}"))?;
    assert!(
        backend
            .store
            .load()
            .map_err(|e| format!("{e:?}"))?
            .is_some()
    );
    backend
        .set_system_proxy(false)
        .map_err(|e| format!("{e:?}"))?;
    assert!(
        backend
            .store
            .load()
            .map_err(|e| format!("{e:?}"))?
            .is_none()
    );
    cleanup(&path);
    Ok(())
}

#[test]
fn engage_persists_captured_original_state() -> Result<(), String> {
    let path = store_path("capture");
    let store = shared_store(&path)?;
    let mut control = fake_control(false);
    control.capture_state = ("manual".to_owned(), "10.0.0.1:8080".to_owned());
    let mut backend = DurableSystemProxyBackend::new(control, store);
    backend
        .set_system_proxy(true)
        .map_err(|e| format!("{e:?}"))?;
    let stored = backend
        .store
        .load()
        .map_err(|e| format!("{e:?}"))?
        .ok_or("record missing")?;
    assert_eq!(stored.original_mode, "manual");
    assert_eq!(stored.original_endpoint, "10.0.0.1:8080");
    cleanup(&path);
    Ok(())
}

#[test]
fn failed_apply_clears_record() -> Result<(), String> {
    let path = store_path("failapply");
    let store = shared_store(&path)?;
    let mut backend = DurableSystemProxyBackend::new(fake_control(true), store);
    assert!(backend.set_system_proxy(true).is_err());
    assert!(
        backend
            .store
            .load()
            .map_err(|e| format!("{e:?}"))?
            .is_none()
    );
    cleanup(&path);
    Ok(())
}

#[test]
fn failed_disable_retains_recovery_record() -> Result<(), String> {
    let path = store_path("faildisable");
    let store = shared_store(&path)?;
    let mut backend = DurableSystemProxyBackend::new(fake_control(false), store.clone());
    backend
        .set_system_proxy(true)
        .map_err(|e| format!("{e:?}"))?;
    // Disable restores the captured state; a failed restore must keep the
    // record so restore-first on the next boot can retry.
    backend.inner.restore_fail = true;
    assert!(backend.set_system_proxy(false).is_err());
    assert!(store.load().map_err(|e| format!("{e:?}"))?.is_some());
    cleanup(&path);
    Ok(())
}

#[test]
fn disable_restores_captured_state_and_clears_record() -> Result<(), String> {
    let path = store_path("disrestore");
    let store = shared_store(&path)?;
    let mut control = fake_control(false);
    control.capture_state = ("manual".to_owned(), "10.0.0.1:8080".to_owned());
    let mut backend = DurableSystemProxyBackend::new(control, store);
    backend
        .set_system_proxy(true)
        .map_err(|e| format!("{e:?}"))?;
    backend
        .set_system_proxy(false)
        .map_err(|e| format!("{e:?}"))?;
    // The desktop must be restored to the pre-engagement state, not merely
    // disabled, and the record must be cleared.
    assert_eq!(
        backend.inner.restored,
        Some(("manual".to_owned(), "10.0.0.1:8080".to_owned()))
    );
    assert!(
        backend
            .store
            .load()
            .map_err(|e| format!("{e:?}"))?
            .is_none()
    );
    cleanup(&path);
    Ok(())
}

#[test]
fn disable_without_record_never_touches_the_desktop() -> Result<(), String> {
    let path = store_path("disnoop");
    let store = shared_store(&path)?;
    let mut backend = DurableSystemProxyBackend::new(fake_control(false), store);
    let view = backend
        .set_system_proxy(false)
        .map_err(|e| format!("{e:?}"))?;
    // No record means this daemon never engaged the proxy: disabling must not
    // clobber a proxy the user configured outside caly.
    assert_eq!(view, PlatformEffectView::none());
    assert_eq!(backend.inner.restored, None);
    assert!(!backend.inner.enabled);
    cleanup(&path);
    Ok(())
}

#[test]
fn restore_proxy_reapplies_enabled_state() -> Result<(), String> {
    let path = store_path("restore");
    let store = shared_store(&path)?;
    let mut backend = DurableSystemProxyBackend::new(fake_control(false), store);
    backend
        .restore_proxy(&record(3))
        .map_err(|e| format!("{e:?}"))?;
    assert!(backend.inner.enabled);
    cleanup(&path);
    Ok(())
}

#[test]
fn restore_first_reapplies_and_keeps_record() -> Result<(), String> {
    let path = store_path("first");
    let store = shared_store(&path)?;
    store.persist(&record(7)).map_err(|e| format!("{e:?}"))?;
    let mut backend = DurableSystemProxyBackend::new(fake_control(false), store);
    backend.restore_first().map_err(|e| format!("{e:?}"))?;
    // The record must survive with phase `Applied`: the re-applied proxy
    // stays undoable via `sysproxy off` / graceful shutdown (a cleared
    // record would orphan the engaged side effect forever).
    let kept = backend
        .store
        .load()
        .map_err(|e| format!("{e:?}"))?
        .expect("record must be kept after restore-first");
    assert_eq!(kept.phase, crate::platform::recovery::RecoveryPhase::Applied);
    assert!(backend.inner.enabled);
    cleanup(&path);
    Ok(())
}

#[test]
fn restore_original_and_clear_restores_captured_state() -> Result<(), String> {
    let path = store_path("fidelity");
    let store = shared_store(&path)?;
    let mut control = fake_control(false);
    control.capture_state = ("manual".to_owned(), "10.0.0.1:8080".to_owned());
    let mut backend = DurableSystemProxyBackend::new(control, store);
    backend
        .set_system_proxy(true)
        .map_err(|e| format!("{e:?}"))?;
    backend
        .restore_original_and_clear()
        .map_err(|e| format!("{e:?}"))?;
    assert_eq!(
        backend.inner.restored,
        Some(("manual".to_owned(), "10.0.0.1:8080".to_owned()))
    );
    assert!(
        backend
            .store
            .load()
            .map_err(|e| format!("{e:?}"))?
            .is_none()
    );
    cleanup(&path);
    Ok(())
}

#[test]
fn restore_original_and_clear_retains_record_on_failure() -> Result<(), String> {
    let path = store_path("fidfail");
    let store = shared_store(&path)?;
    let mut control = fake_control(false);
    control.capture_state = ("manual".to_owned(), "10.0.0.1:8080".to_owned());
    let mut backend = DurableSystemProxyBackend::new(control, store);
    backend
        .set_system_proxy(true)
        .map_err(|e| format!("{e:?}"))?;
    backend.inner.restore_fail = true;
    assert!(backend.restore_original_and_clear().is_err());
    assert!(
        backend
            .store
            .load()
            .map_err(|e| format!("{e:?}"))?
            .is_some()
    );
    cleanup(&path);
    Ok(())
}

#[test]
fn restore_original_and_clear_without_record_is_noop() -> Result<(), String> {
    let path = store_path("fidnoop");
    let store = shared_store(&path)?;
    let mut backend = DurableSystemProxyBackend::new(fake_control(false), store);
    backend
        .restore_original_and_clear()
        .map_err(|e| format!("{e:?}"))?;
    assert_eq!(backend.inner.restored, None);
    cleanup(&path);
    Ok(())
}

#[test]
fn reengage_keeps_first_captured_original_state() -> Result<(), String> {
    let path = store_path("reengage");
    let store = shared_store(&path)?;
    let mut control = fake_control(false);
    control.capture_state = ("manual".to_owned(), "10.0.0.1:8080".to_owned());
    let mut backend = DurableSystemProxyBackend::new(control, store);
    backend
        .set_system_proxy(true)
        .map_err(|e| format!("{e:?}"))?;
    // A re-engagement must not re-capture: the desktop now carries caly's own
    // proxy, which must never overwrite the user's true original state.
    backend.inner.capture_state = ("none".to_owned(), String::new());
    backend
        .set_system_proxy(true)
        .map_err(|e| format!("{e:?}"))?;
    let stored = backend
        .store
        .load()
        .map_err(|e| format!("{e:?}"))?
        .ok_or("record missing")?;
    assert_eq!(stored.original_mode, "manual");
    assert_eq!(stored.original_endpoint, "10.0.0.1:8080");
    cleanup(&path);
    Ok(())
}

#[test]
fn failed_reengage_retains_recovery_record() -> Result<(), String> {
    let path = store_path("refail");
    let store = shared_store(&path)?;
    let mut backend = DurableSystemProxyBackend::new(fake_control(false), store);
    backend
        .set_system_proxy(true)
        .map_err(|e| format!("{e:?}"))?;
    backend.inner.fail = true;
    assert!(backend.set_system_proxy(true).is_err());
    assert!(
        backend
            .store
            .load()
            .map_err(|e| format!("{e:?}"))?
            .is_some(),
        "a failed re-engagement must not destroy crash-recovery evidence"
    );
    cleanup(&path);
    Ok(())
}

}
