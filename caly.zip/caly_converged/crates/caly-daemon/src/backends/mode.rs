//! Durable proxy routing mode (bug ⑪).
//!
//! `set_mode` used to PATCH the kernel and forget: a daemon restart
//! re-seeded `rule`, every re-render pushed the hardcoded `mode: rule`
//! back over a live `global`, and sing-box (runtime-only mode) forgot
//! it on every restart. Three cooperating pieces:
//!
//! - [`remember`] persists the mode record after a successful PATCH;
//! - the renderers embed [`current`] (mihomo `mode:`, sing-box
//!   `experimental.clash_api.default_mode`), so re-renders and fresh
//!   starts carry the intent;
//! - [`sync_rendered_configs`] rewrites the mode field of the two
//!   on-disk kernel configs in place, so starts between renders
//!   (boot, `core restart`, `core switch`) also land correctly.
//!
//! All disk writes are best-effort: the kernel PATCH already succeeded
//! when they run, so a failure warns and the next render converges.

use caly_core::domain::ProxyMode;

/// Clash API mode label for a routing mode.
pub(crate) fn label(mode: ProxyMode) -> &'static str {
    match mode {
        ProxyMode::Rule => "rule",
        ProxyMode::Global => "global",
        ProxyMode::Direct => "direct",
    }
}

/// Parses a Clash API mode label; anything else is `None`.
pub(crate) fn parse_label(label: &str) -> Option<ProxyMode> {
    match label {
        "rule" => Some(ProxyMode::Rule),
        "global" => Some(ProxyMode::Global),
        "direct" => Some(ProxyMode::Direct),
        _ => None,
    }
}

/// Persists the mode record (best-effort, warns on failure).
pub(crate) fn remember(mode: ProxyMode) {
    let path = crate::platform::paths::AppPaths::from_env().proxy_mode_path();
    let record = crate::platform::proxy_mode::ProxyModeRecord::new(label(mode));
    if let Err(error) = crate::platform::proxy_mode::save_proxy_mode(&path, &record) {
        tracing::warn!(
            message = %error,
            operation = ?error.operation,
            "could not persist proxy mode"
        );
    }
}

/// Loads the persisted mode; missing/corrupt records mean `Rule`.
pub fn current() -> ProxyMode {
    let path = crate::platform::paths::AppPaths::from_env().proxy_mode_path();
    crate::platform::proxy_mode::load_proxy_mode(&path)
        .and_then(|mode| parse_label(&mode))
        .unwrap_or(ProxyMode::Rule)
}

/// Rewrites the mode field of both rendered kernel configs in place
/// (best-effort per file). Mode is daemon-global intent, not per-core
/// state, so the inactive core's file is synced too — a later `core
/// switch` must land on the current mode, not on a stale render.
pub(crate) fn sync_rendered_configs(
    mihomo_path: &std::path::Path,
    sing_box_path: &std::path::Path,
    mode: ProxyMode,
) {
    let text = label(mode);
    match std::fs::read_to_string(mihomo_path) {
        Ok(contents) => match rewrite_mihomo_mode_text(&contents, text) {
            Some(updated) if updated != contents => {
                if let Err(error) = std::fs::write(mihomo_path, updated) {
                    tracing::warn!(path = %mihomo_path.display(), %error, "could not sync the mode into the rendered Mihomo config");
                }
            }
            Some(_) => {}
            None => tracing::warn!(
                path = %mihomo_path.display(),
                "rendered Mihomo config has no unique `mode:` line; leaving it for the next render"
            ),
        },
        Err(error) => tracing::warn!(path = %mihomo_path.display(), %error, "could not read the rendered Mihomo config for a mode sync"),
    }
    match std::fs::read(sing_box_path) {
        Ok(contents) => match rewrite_sing_box_default_mode(&contents, text) {
            Some(updated) if updated != contents => {
                if let Err(error) = std::fs::write(sing_box_path, updated) {
                    tracing::warn!(path = %sing_box_path.display(), %error, "could not sync the mode into the rendered sing-box config");
                }
            }
            Some(_) => {}
            None => tracing::warn!(
                path = %sing_box_path.display(),
                "rendered sing-box config is not editable JSON; leaving it for the next render"
            ),
        },
        Err(error) => tracing::warn!(path = %sing_box_path.display(), %error, "could not read the rendered sing-box config for a mode sync"),
    }
}

/// Replaces the single top-level `mode:` line of a rendered Mihomo
/// document. `None` unless exactly one `mode:` line exists — a
/// hand-edited file must not gain a second `mode:` key.
fn rewrite_mihomo_mode_text(contents: &str, mode: &str) -> Option<String> {
    if contents.lines().filter(|line| line.starts_with("mode:")).count() != 1 {
        return None;
    }
    Some(
        contents
            .lines()
            .map(|line| {
                if line.starts_with("mode:") {
                    format!("mode: {mode}")
                } else {
                    line.to_owned()
                }
            })
            .collect::<Vec<_>>()
            .join("\n")
            + if contents.ends_with('\n') { "\n" } else { "" },
    )
}

/// Sets `experimental.clash_api.default_mode` in a rendered sing-box
/// document, creating the parent objects when an older render lacks
/// them — mirroring the renderer, `rule` (the kernel default) REMOVES
/// the key instead of writing it. Returns the input unchanged when
/// there is nothing to do, so the caller skips the write. `None` when
/// the file is not a JSON object.
fn rewrite_sing_box_default_mode(contents: &[u8], mode: &str) -> Option<Vec<u8>> {
    let mut document: serde_json::Value = serde_json::from_slice(contents).ok()?;
    let root = document.as_object_mut()?;
    let clash_api = root
        .entry("experimental")
        .or_insert_with(|| serde_json::Value::Object(Default::default()))
        .as_object_mut()?
        .entry("clash_api")
        .or_insert_with(|| serde_json::Value::Object(Default::default()))
        .as_object_mut()?;
    if mode == "rule" {
        if clash_api.remove("default_mode").is_none() {
            return Some(contents.to_vec());
        }
    } else {
        clash_api.insert(
            "default_mode".to_owned(),
            serde_json::Value::String(mode.to_owned()),
        );
    }
    // Compact, exactly like the renderer: the boot secret re-key used
    // to string-match compact `"secret":"..."`, and a pretty file
    // killed the daemon boot (bug ⑬ — the re-key is hardened now,
    // but byte-shape stability stays a good idea).
    serde_json::to_vec(&document).ok()
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn labels_round_trip() {
        for mode in [ProxyMode::Rule, ProxyMode::Global, ProxyMode::Direct] {
            assert_eq!(parse_label(label(mode)), Some(mode));
        }
        assert_eq!(parse_label("turbo"), None);
    }

    #[test]
    fn mihomo_rewrite_replaces_the_mode_line() {
        let before = "mixed-port: 7890\nmode: rule\nlog-level: info\n";
        let after = rewrite_mihomo_mode_text(before, "global").expect("rewrites");
        assert!(after.contains("\nmode: global\n"), "{after}");
        assert!(!after.contains("mode: rule"), "{after}");
    }

    #[test]
    fn mihomo_rewrite_refuses_ambiguous_files() {
        assert_eq!(rewrite_mihomo_mode_text("mode: rule\nmode: direct\n", "global"), None);
        assert_eq!(rewrite_mihomo_mode_text("mixed-port: 1\n", "global"), None);
    }

    #[test]
    fn sing_box_rewrite_sets_default_mode() {
        let before = serde_json::json!({
            "experimental": {"clash_api": {"external_controller": "127.0.0.1:9091"}},
            "outbounds": [],
        });
        let after = rewrite_sing_box_default_mode(&serde_json::to_vec(&before).expect("json"), "direct")
            .expect("rewrites");
        let document: serde_json::Value = serde_json::from_slice(&after).expect("still json");
        assert_eq!(
            document["experimental"]["clash_api"]["default_mode"],
            serde_json::Value::String("direct".to_owned())
        );
        assert_eq!(
            document["experimental"]["clash_api"]["external_controller"],
            serde_json::Value::String("127.0.0.1:9091".to_owned())
        );
    }

    #[test]
    fn sing_box_rewrite_creates_missing_parents() {
        let after = rewrite_sing_box_default_mode(b"{\"outbounds\":[]}", "global").expect("rewrites");
        let document: serde_json::Value = serde_json::from_slice(&after).expect("still json");
        assert_eq!(
            document["experimental"]["clash_api"]["default_mode"],
            serde_json::Value::String("global".to_owned())
        );
    }

    #[test]
    fn sing_box_rewrite_emits_compact_json() {
        let after =
            rewrite_sing_box_default_mode(b"{\"outbounds\":[]}", "global").expect("rewrites");
        assert!(!after.contains(&b'\n'), "compact like the renderer");
    }

    #[test]
    fn sing_box_rewrite_removes_the_key_for_rule() {
        let before = br#"{"experimental":{"clash_api":{"default_mode":"global"}}}"#;
        let after = rewrite_sing_box_default_mode(before, "rule").expect("rewrites");
        let document: serde_json::Value = serde_json::from_slice(&after).expect("still json");
        assert!(
            document["experimental"]["clash_api"]
                .get("default_mode")
                .is_none(),
            "rule omits the key like the renderer"
        );
        // Nothing to do: byte-identical, so the caller skips the write.
        let untouched = br#"{"outbounds":[]}"#;
        assert_eq!(
            rewrite_sing_box_default_mode(untouched, "rule").expect("ok"),
            untouched
        );
    }

    #[test]
    fn sing_box_rewrite_refuses_non_objects() {
        assert_eq!(rewrite_sing_box_default_mode(b"[1,2]", "global"), None);
        assert_eq!(rewrite_sing_box_default_mode(b"not json", "global"), None);
    }
}
