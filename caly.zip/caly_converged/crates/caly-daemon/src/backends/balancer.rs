//! Production-grade Load Balancer & Node Selection Engine.
//!
//! Grounded in established computer science literature:
//! 1. Power of Two Random Choices (P2C) algorithm (Michael Mitzenmacher, IEEE TPDS).
//! 2. RFC 6298 EWMA Latency Tracker:
//!    - Smooth RTT with alpha = 0.125
//!    - RTT variance (RTTVAR) with beta = 0.25
//!    - Composite penalty score = EWMA_RTT + weight * in_flight_requests
//! 3. Outlier Detection & 3-State Circuit Breaker (Michael Nygard, "Release It!"):
//!    - States: Closed (healthy), Open (tripped), HalfOpen (probing)
//!    - Tripped on consecutive failures or error rate threshold
//!    - Exponential backoff before probing trial

use std::{
    collections::HashMap,
    sync::{Arc, Mutex, RwLock},
    sync::atomic::{AtomicU32, AtomicU64, Ordering},
    time::{Duration, Instant},
};

use caly_core::domain::NodeId;

/// RFC 6298 constant alpha = 1/8 = 0.125.
const RFC6298_ALPHA: f64 = 0.125;
/// RFC 6298 constant beta = 1/4 = 0.25.
const RFC6298_BETA: f64 = 0.25;

/// High-performance non-cryptographic PRNG (XorShift64) seeded from system entropy.
struct FastRng {
    state: u64,
}

impl FastRng {
    fn new() -> Self {
        let raw = crate::platform::entropy::random_bytes::<8>();
        let mut seed = u64::from_le_bytes(raw);
        if seed == 0 {
            seed = 0x8a5cd789635d2dff;
        }
        Self { state: seed }
    }

    fn next_u64(&mut self) -> u64 {
        let mut x = self.state;
        x ^= x << 13;
        x ^= x >> 7;
        x ^= x << 17;
        self.state = x;
        x
    }

    fn gen_range(&mut self, upper_bound: usize) -> usize {
        if upper_bound <= 1 {
            return 0;
        }
        (self.next_u64() as usize) % upper_bound
    }
}

/// Circuit Breaker state machine (Michael Nygard, "Release It!").
#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub enum CircuitState {
    /// Normal operation; all requests routed.
    Closed,
    /// Outlier/unhealthy; traffic rejected or steered away.
    Open,
    /// Probing canary phase; single request permitted to test recovery.
    HalfOpen,
}

/// Configuration tuning parameters for Circuit Breaker and outlier detection.
#[derive(Clone, Debug)]
pub struct CircuitBreakerConfig {
    /// Number of consecutive failures to trip circuit from Closed to Open.
    pub consecutive_failures_threshold: u32,
    /// Minimum samples required in the rolling window before error rate trips circuit.
    pub min_samples: u32,
    /// Ratio of failures over window to trip circuit (e.g. 0.5 = 50%).
    pub error_rate_threshold: f64,
    /// Initial backoff duration before trial probe in HalfOpen.
    pub base_backoff: Duration,
    /// Maximum backoff duration under repeated failures.
    pub max_backoff: Duration,
    /// Multiplier for exponential backoff.
    pub backoff_factor: f64,
}

impl Default for CircuitBreakerConfig {
    fn default() -> Self {
        Self {
            consecutive_failures_threshold: 5,
            min_samples: 10,
            error_rate_threshold: 0.5,
            base_backoff: Duration::from_secs(5),
            max_backoff: Duration::from_secs(300),
            backoff_factor: 2.0,
        }
    }
}

/// Sliding window record for error rate calculation.
#[derive(Clone, Debug, Default)]
struct SlidingWindow {
    success_count: u32,
    failure_count: u32,
}

impl SlidingWindow {
    fn record_success(&mut self) {
        self.success_count = self.success_count.saturating_add(1);
    }

    fn record_failure(&mut self) {
        self.failure_count = self.failure_count.saturating_add(1);
    }

    fn total(&self) -> u32 {
        self.success_count.saturating_add(self.failure_count)
    }

    fn failure_rate(&self) -> f64 {
        let total = self.total();
        if total == 0 {
            0.0
        } else {
            f64::from(self.failure_count) / f64::from(total)
        }
    }

    fn reset(&mut self) {
        self.success_count = 0;
        self.failure_count = 0;
    }
}

/// Individual node Circuit Breaker runtime state.
#[derive(Debug)]
pub struct NodeCircuitBreaker {
    config: CircuitBreakerConfig,
    state: CircuitState,
    consecutive_failures: u32,
    current_backoff: Duration,
    last_state_change: Instant,
    window: SlidingWindow,
    half_open_active: bool,
}

impl NodeCircuitBreaker {
    pub fn new(config: CircuitBreakerConfig) -> Self {
        let base = config.base_backoff;
        Self {
            config,
            state: CircuitState::Closed,
            consecutive_failures: 0,
            current_backoff: base,
            last_state_change: Instant::now(),
            window: SlidingWindow::default(),
            half_open_active: false,
        }
    }

    /// Evaluates current state and checks if canary trial probe is permitted.
    pub fn check_permission(&mut self, now: Instant) -> bool {
        match self.state {
            CircuitState::Closed => true,
            CircuitState::Open => {
                if now.duration_since(self.last_state_change) >= self.current_backoff {
                    self.state = CircuitState::HalfOpen;
                    self.last_state_change = now;
                    self.half_open_active = true;
                    true
                } else {
                    false
                }
            }
            CircuitState::HalfOpen => {
                if !self.half_open_active {
                    self.half_open_active = true;
                    true
                } else {
                    false
                }
            }
        }
    }

    /// Records successful transmission.
    pub fn record_success(&mut self, now: Instant) {
        self.consecutive_failures = 0;
        self.window.record_success();
        match self.state {
            CircuitState::HalfOpen => {
                self.state = CircuitState::Closed;
                self.last_state_change = now;
                self.current_backoff = self.config.base_backoff;
                self.half_open_active = false;
                self.window.reset();
            }
            CircuitState::Open => {
                self.state = CircuitState::Closed;
                self.last_state_change = now;
                self.current_backoff = self.config.base_backoff;
                self.half_open_active = false;
            }
            CircuitState::Closed => {}
        }
    }

    /// Records failed transmission.
    pub fn record_failure(&mut self, now: Instant) {
        self.consecutive_failures = self.consecutive_failures.saturating_add(1);
        self.window.record_failure();

        match self.state {
            CircuitState::Closed => {
                let should_trip = self.consecutive_failures >= self.config.consecutive_failures_threshold
                    || (self.window.total() >= self.config.min_samples
                        && self.window.failure_rate() >= self.config.error_rate_threshold);
                if should_trip {
                    self.trip_open(now);
                }
            }
            CircuitState::HalfOpen => {
                self.current_backoff = Duration::from_secs_f64(
                    (self.current_backoff.as_secs_f64() * self.config.backoff_factor)
                        .min(self.config.max_backoff.as_secs_f64()),
                );
                self.trip_open(now);
            }
            CircuitState::Open => {
                self.last_state_change = now;
            }
        }
    }

    fn trip_open(&mut self, now: Instant) {
        self.state = CircuitState::Open;
        self.last_state_change = now;
        self.half_open_active = false;
        self.window.reset();
    }

    pub fn state(&self) -> CircuitState {
        self.state
    }

    pub fn consecutive_failures(&self) -> u32 {
        self.consecutive_failures
    }
}

/// RFC 6298 EWMA Latency and Jitter Tracker.
#[derive(Debug)]
pub struct LatencyTracker {
    /// Smoothed Round Trip Time (SRTT) in milliseconds.
    srtt_ms: Option<f64>,
    /// Round Trip Time Variation (RTTVAR) in milliseconds.
    rttvar_ms: f64,
    /// Last measured raw RTT sample in milliseconds.
    last_rtt_ms: f64,
    /// Total successful measurement count.
    sample_count: u64,
}

impl Default for LatencyTracker {
    fn default() -> Self {
        Self {
            srtt_ms: None,
            rttvar_ms: 0.0,
            last_rtt_ms: 0.0,
            sample_count: 0,
        }
    }
}

impl LatencyTracker {
    /// Updates smoothed RTT and variance per RFC 6298 specifications.
    pub fn update(&mut self, rtt_sample: Duration) {
        let r_ms = rtt_sample.as_secs_f64() * 1_000.0;
        self.last_rtt_ms = r_ms;
        self.sample_count = self.sample_count.saturating_add(1);

        match self.srtt_ms {
            None => {
                // First measurement: SRTT <- R, RTTVAR <- R / 2
                self.srtt_ms = Some(r_ms);
                self.rttvar_ms = r_ms / 2.0;
            }
            Some(prev_srtt) => {
                // Subsequent measurements:
                // RTTVAR <- (1 - beta) * RTTVAR + beta * |SRTT - R'|
                let diff = (prev_srtt - r_ms).abs();
                self.rttvar_ms = (1.0 - RFC6298_BETA) * self.rttvar_ms + RFC6298_BETA * diff;
                // SRTT <- (1 - alpha) * SRTT + alpha * R'
                self.srtt_ms = Some((1.0 - RFC6298_ALPHA) * prev_srtt + RFC6298_ALPHA * r_ms);
            }
        }
    }

    /// Returns the smoothed RTT (SRTT) or default if no samples recorded.
    pub fn srtt_ms(&self, default_ms: f64) -> f64 {
        self.srtt_ms.unwrap_or(default_ms)
    }

    /// Returns the RTT variance (RTTVAR).
    pub fn rttvar_ms(&self) -> f64 {
        self.rttvar_ms
    }

    /// RFC 6298 Retransmission Timeout upper bound: SRTT + 4 * RTTVAR.
    pub fn rto_bound_ms(&self, default_ms: f64) -> f64 {
        match self.srtt_ms {
            Some(srtt) => srtt + 4.0 * self.rttvar_ms,
            None => default_ms,
        }
    }

    pub fn sample_count(&self) -> u64 {
        self.sample_count
    }
}

/// Internal metrics and health record for a single managed proxy node.
#[derive(Debug)]
pub struct NodeRecord {
    pub latency: LatencyTracker,
    pub circuit: NodeCircuitBreaker,
    pub in_flight: AtomicU32,
    pub total_dispatched: AtomicU64,
}

impl NodeRecord {
    pub fn new(circuit_config: CircuitBreakerConfig) -> Self {
        Self {
            latency: LatencyTracker::default(),
            circuit: NodeCircuitBreaker::new(circuit_config),
            in_flight: AtomicU32::new(0),
            total_dispatched: AtomicU64::new(0),
        }
    }

    /// Computes composite penalty score: score = EWMA_RTT + weight * in_flight
    pub fn penalty_score(&self, default_latency_ms: f64, in_flight_weight: f64) -> f64 {
        let latency_ms = self.latency.srtt_ms(default_latency_ms);
        let in_flight = f64::from(self.in_flight.load(Ordering::Relaxed));
        latency_ms + (in_flight_weight * in_flight)
    }
}

/// RAII Guard tracking concurrent in-flight requests.
pub struct InFlightLease {
    node_id: NodeId,
    start_time: Instant,
    node_record: Arc<RwLock<NodeRecord>>,
    completed: bool,
}

impl InFlightLease {
    pub fn node_id(&self) -> NodeId {
        self.node_id
    }

    /// Marks the execution as completed with measured RTT latency.
    pub fn record_success(mut self) {
        let rtt = self.start_time.elapsed();
        let now = Instant::now();
        if let Ok(mut record) = self.node_record.write() {
            record.latency.update(rtt);
            record.circuit.record_success(now);
        }
        self.cleanup();
    }

    /// Marks the execution as failed (network error, handshake timeout).
    pub fn record_failure(mut self) {
        let now = Instant::now();
        if let Ok(mut record) = self.node_record.write() {
            record.circuit.record_failure(now);
        }
        self.cleanup();
    }

    fn cleanup(&mut self) {
        if !self.completed {
            if let Ok(record) = self.node_record.read() {
                record.in_flight.fetch_sub(1, Ordering::Relaxed);
            }
            self.completed = true;
        }
    }
}

impl Drop for InFlightLease {
    fn drop(&mut self) {
        self.cleanup();
    }
}

/// Error outcomes from load balancer selection.
#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub enum BalancerError {
    /// No candidates were provided in the candidate list.
    EmptyCandidateList,
    /// All candidate nodes are in Open (tripped) circuit breaker state.
    AllNodesCircuitTripped,
    /// Node record not registered in the balancer registry.
    NodeNotRegistered,
}

impl core::fmt::Display for BalancerError {
    fn fmt(&self, f: &mut core::fmt::Formatter<'_>) -> core::fmt::Result {
        match self {
            Self::EmptyCandidateList => f.write_str("candidate node list is empty"),
            Self::AllNodesCircuitTripped => f.write_str("all candidate nodes are circuit tripped"),
            Self::NodeNotRegistered => f.write_str("node ID not registered in balancer"),
        }
    }
}

impl std::error::Error for BalancerError {}

/// Cutting-edge production load balancer implementing:
/// - Power of Two Random Choices (P2C)
/// - RFC 6298 EWMA latency smoothing
/// - Outlier Detection & 3-state Circuit Breaker
pub struct LoadBalancer {
    circuit_config: CircuitBreakerConfig,
    default_latency_ms: f64,
    in_flight_weight: f64,
    records: RwLock<HashMap<NodeId, Arc<RwLock<NodeRecord>>>>,
    rng: Mutex<FastRng>,
}

impl LoadBalancer {
    pub fn new(
        circuit_config: CircuitBreakerConfig,
        default_latency_ms: f64,
        in_flight_weight: f64,
    ) -> Self {
        Self {
            circuit_config,
            default_latency_ms,
            in_flight_weight,
            records: RwLock::new(HashMap::new()),
            rng: Mutex::new(FastRng::new()),
        }
    }

    /// Registers a node ID into the tracker.
    pub fn register_node(&self, id: NodeId) {
        if let Ok(mut map) = self.records.write() {
            map.entry(id).or_insert_with(|| {
                Arc::new(RwLock::new(NodeRecord::new(self.circuit_config.clone())))
            });
        }
    }

    /// Obtains an Arc handle to the node's record, registering if absent.
    fn get_or_register(&self, id: NodeId) -> Arc<RwLock<NodeRecord>> {
        if let Ok(map) = self.records.read() {
            if let Some(record) = map.get(&id) {
                return Arc::clone(record);
            }
        }
        let mut map = self.records.write().unwrap_or_else(|p| p.into_inner());
        map.entry(id)
            .or_insert_with(|| Arc::new(RwLock::new(NodeRecord::new(self.circuit_config.clone()))))
            .clone()
    }

    /// Selects an optimal node from  using Power of Two Random Choices (P2C).
    pub fn select_p2c(&self, candidates: &[NodeId]) -> Result<InFlightLease, BalancerError> {
        if candidates.is_empty() {
            return Err(BalancerError::EmptyCandidateList);
        }

        let now = Instant::now();

        if candidates.len() == 1 {
            let id = candidates[0];
            let record_arc = self.get_or_register(id);
            let allowed = {
                let mut record = record_arc.write().unwrap_or_else(|p| p.into_inner());
                record.circuit.check_permission(now)
            };
            if !allowed {
                return Err(BalancerError::AllNodesCircuitTripped);
            }
            return Ok(self.create_lease(id, record_arc));
        }

        // P2C: pick two distinct random candidate indices
        let (idx1, idx2) = {
            let mut rng_guard = self.rng.lock().unwrap_or_else(|p| p.into_inner());
            let i1 = rng_guard.gen_range(candidates.len());
            let mut i2 = rng_guard.gen_range(candidates.len().saturating_sub(1));
            if i2 >= i1 {
                i2 += 1;
            }
            (i1, i2)
        };

        let node1 = candidates[idx1];
        let node2 = candidates[idx2];

        let record1 = self.get_or_register(node1);
        let record2 = self.get_or_register(node2);

        let (allowed1, score1) = {
            let mut r1 = record1.write().unwrap_or_else(|p| p.into_inner());
            let allowed = r1.circuit.check_permission(now);
            let score = r1.penalty_score(self.default_latency_ms, self.in_flight_weight);
            (allowed, score)
        };

        let (allowed2, score2) = {
            let mut r2 = record2.write().unwrap_or_else(|p| p.into_inner());
            let allowed = r2.circuit.check_permission(now);
            let score = r2.penalty_score(self.default_latency_ms, self.in_flight_weight);
            (allowed, score)
        };

        match (allowed1, allowed2) {
            (true, true) => {
                if score1 <= score2 {
                    Ok(self.create_lease(node1, record1))
                } else {
                    Ok(self.create_lease(node2, record2))
                }
            }
            (true, false) => Ok(self.create_lease(node1, record1)),
            (false, true) => Ok(self.create_lease(node2, record2)),
            (false, false) => {
                self.fallback_search(candidates, now)
            }
        }
    }

    fn fallback_search(&self, candidates: &[NodeId], now: Instant) -> Result<InFlightLease, BalancerError> {
        for &id in candidates {
            let record = self.get_or_register(id);
            let mut guard = record.write().unwrap_or_else(|p| p.into_inner());
            if guard.circuit.check_permission(now) {
                drop(guard);
                return Ok(self.create_lease(id, record));
            }
        }
        Err(BalancerError::AllNodesCircuitTripped)
    }

    fn create_lease(&self, node_id: NodeId, record: Arc<RwLock<NodeRecord>>) -> InFlightLease {
        if let Ok(r) = record.read() {
            r.in_flight.fetch_add(1, Ordering::Relaxed);
            r.total_dispatched.fetch_add(1, Ordering::Relaxed);
        }
        InFlightLease {
            node_id,
            start_time: Instant::now(),
            node_record: record,
            completed: false,
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    fn dummy_node_id(byte: u8) -> NodeId {
        NodeId::from_bytes([byte; 16])
    }

    #[test]
    fn rfc6298_ewma_latency_calculations() {
        let mut tracker = LatencyTracker::default();
        assert_eq!(tracker.srtt_ms(100.0), 100.0);

        tracker.update(Duration::from_millis(40));
        assert_eq!(tracker.srtt_ms(0.0), 40.0);
        assert_eq!(tracker.rttvar_ms(), 20.0);
        assert_eq!(tracker.rto_bound_ms(0.0), 40.0 + 4.0 * 20.0);

        tracker.update(Duration::from_millis(80));
        assert_eq!(tracker.srtt_ms(0.0), 45.0);
        assert_eq!(tracker.rttvar_ms(), 25.0);
    }

    #[test]
    fn circuit_breaker_three_states_and_backoff() {
        let config = CircuitBreakerConfig {
            consecutive_failures_threshold: 3,
            min_samples: 5,
            error_rate_threshold: 0.5,
            base_backoff: Duration::from_millis(100),
            max_backoff: Duration::from_secs(1),
            backoff_factor: 2.0,
        };
        let mut cb = NodeCircuitBreaker::new(config);
        let mut now = Instant::now();

        assert_eq!(cb.state(), CircuitState::Closed);
        assert!(cb.check_permission(now));

        cb.record_failure(now);
        cb.record_failure(now);
        assert_eq!(cb.state(), CircuitState::Closed);
        assert!(cb.check_permission(now));

        cb.record_failure(now);
        assert_eq!(cb.state(), CircuitState::Open);
        assert!(!cb.check_permission(now));

        now += Duration::from_millis(50);
        assert!(!cb.check_permission(now));

        now += Duration::from_millis(60);
        assert!(cb.check_permission(now));
        assert_eq!(cb.state(), CircuitState::HalfOpen);

        cb.record_success(now);
        assert_eq!(cb.state(), CircuitState::Closed);
        assert_eq!(cb.consecutive_failures(), 0);
    }

    #[test]
    fn p2c_selection_favors_lower_penalty_score() {
        let balancer = LoadBalancer::new(CircuitBreakerConfig::default(), 50.0, 10.0);
        let node_a = dummy_node_id(1);
        let node_b = dummy_node_id(2);
        let candidates = [node_a, node_b];

        balancer.register_node(node_a);
        balancer.register_node(node_b);

        {
            let lease_a = balancer.create_lease(node_a, balancer.get_or_register(node_a));
            std::thread::sleep(Duration::from_millis(20));
            lease_a.record_success();

            let lease_b = balancer.create_lease(node_b, balancer.get_or_register(node_b));
            std::thread::sleep(Duration::from_millis(100));
            lease_b.record_success();
        }

        let lease = balancer.select_p2c(&candidates);
        assert!(lease.is_ok());
        assert_eq!(lease.unwrap().node_id(), node_a);
    }

    #[test]
    fn in_flight_penalty_biases_selection() {
        let balancer = LoadBalancer::new(CircuitBreakerConfig::default(), 50.0, 50.0);
        let node_a = dummy_node_id(1);
        let node_b = dummy_node_id(2);
        let candidates = [node_a, node_b];

        {
            let la = balancer.create_lease(node_a, balancer.get_or_register(node_a));
            la.record_success();
            let lb = balancer.create_lease(node_b, balancer.get_or_register(node_b));
            lb.record_success();
        }

        let held_lease_a = balancer.select_p2c(&[node_a]).unwrap();
        let selected = balancer.select_p2c(&candidates).unwrap();
        assert_eq!(selected.node_id(), node_b);

        drop(held_lease_a);
    }
}
