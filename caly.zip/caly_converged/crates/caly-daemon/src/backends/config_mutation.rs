//! ConfigMutation backend (CLI sinking, 2026-08-14): the daemon's
//! single writer for `subscriptions.sources`.
//!
//! The semantics live in `caly-configstore::subscription_sources` — ONE
//! implementation shared with the CLI's `--offline` escape hatch (step
//! 2b converged the second copy). This module only adapts the shared
//! functions to the `ConfigMutationBackend` port and maps the shared
//! error type onto `ActorFailure`.

use caly_core::domain::{MutationOutcome, SubscriptionMutation};
use crate::platform::paths::AppPaths;
use caly_core::ports::ActorFailure;

use caly_core::configstore::subscription_sources as sources;

/// Owns config.yaml subscription mutations for the ConfigMutationActor.
pub struct ConfigMutationBackendImpl {
    paths: AppPaths,
}

impl ConfigMutationBackendImpl {
    /// Resolves paths from the process environment once.
    pub fn from_env() -> Self {
        Self {
            paths: AppPaths::from_env(),
        }
    }

}

impl caly_core::ports::ConfigMutationBackend for ConfigMutationBackendImpl {
    fn mutate(
        &mut self,
        mutation: caly_core::domain::ConfigMutation,
        apply: bool,
    ) -> Result<MutationOutcome, ActorFailure> {
        match mutation {
            caly_core::domain::ConfigMutation::Subscription(sub) => self.mutate_subscription(sub, apply),
            caly_core::domain::ConfigMutation::ProxyGroup(group) => {
                self.mutate_proxy_group(&group, apply)
            }
            caly_core::domain::ConfigMutation::RuleProvider(provider) => {
                self.mutate_rule_provider(&provider, apply)
            }
        }
    }
}

impl ConfigMutationBackendImpl {
    /// `set sub …`: the subscription-source pipeline (shared with the
    /// CLI's offline path).
    fn mutate_subscription(
        &self,
        mutation: SubscriptionMutation,
        apply: bool,
    ) -> Result<MutationOutcome, ActorFailure> {
        let preview = match mutation {
            SubscriptionMutation::Add {
                token,
                name,
                refresh_every_minutes,
            } => sources::add_source(
                &self.paths,
                &token,
                name.as_deref(),
                refresh_every_minutes,
                apply,
            ),
            SubscriptionMutation::Remove { target, purge } => {
                sources::remove_source(&self.paths, &target, purge, apply)
            }
            SubscriptionMutation::Set {
                target,
                url,
                name,
                refresh_every_minutes,
            } => sources::set_source(
                &self.paths,
                &target,
                url.as_deref(),
                name.as_deref(),
                refresh_every_minutes,
                apply,
            ),
            SubscriptionMutation::Enable { target } => {
                sources::set_enabled(&self.paths, &target, true, apply)
            }
            SubscriptionMutation::Disable { target } => {
                sources::set_enabled(&self.paths, &target, false, apply)
            }
        }
        .map_err(map_source_error)?;
        Ok(MutationOutcome {
            resource: caly_core::domain::ConfigResource::Subscription,
            count: preview.source_count,
            url: preview.url,
            applied: preview.applied,
            unchanged: preview.unchanged,
        })
    }

    /// `set proxy-group …` via the shared configstore pipeline.
    fn mutate_proxy_group(
        &self,
        mutation: &caly_core::domain::ProxyGroupMutation,
        apply: bool,
    ) -> Result<MutationOutcome, ActorFailure> {
        let outcome =
            caly_core::configstore::resource_mutations::mutate_proxy_group(&self.paths, mutation, apply)
                .map_err(map_resource_error)?;
        Ok(MutationOutcome {
            resource: caly_core::domain::ConfigResource::ProxyGroup,
            count: count_proxy_groups(&self.paths),
            url: Some(proxy_group_name(mutation)),
            applied: outcome == caly_core::configstore::resource_writer::ResourceWriteOutcome::Applied,
            unchanged: outcome == caly_core::configstore::resource_writer::ResourceWriteOutcome::NoChange,
        })
    }

    /// `set rule-provider …` via the shared configstore pipeline.
    fn mutate_rule_provider(
        &self,
        mutation: &caly_core::domain::RuleProviderMutation,
        apply: bool,
    ) -> Result<MutationOutcome, ActorFailure> {
        let outcome = caly_core::configstore::resource_mutations::mutate_rule_provider(
            &self.paths,
            mutation,
            apply,
        )
        .map_err(map_resource_error)?;
        Ok(MutationOutcome {
            resource: caly_core::domain::ConfigResource::RuleProvider,
            count: count_rule_providers(&self.paths),
            url: Some(rule_provider_name(mutation)),
            applied: outcome == caly_core::configstore::resource_writer::ResourceWriteOutcome::Applied,
            unchanged: outcome == caly_core::configstore::resource_writer::ResourceWriteOutcome::NoChange,
        })
    }
}

/// The mutated proxy group's name, for the outcome envelope.
fn proxy_group_name(mutation: &caly_core::domain::ProxyGroupMutation) -> String {
    match mutation {
        caly_core::domain::ProxyGroupMutation::Add { name, .. }
        | caly_core::domain::ProxyGroupMutation::Remove { name }
        | caly_core::domain::ProxyGroupMutation::Enable { name }
        | caly_core::domain::ProxyGroupMutation::Disable { name } => name.clone(),
    }
}

/// The mutated rule provider's name, for the outcome envelope.
fn rule_provider_name(mutation: &caly_core::domain::RuleProviderMutation) -> String {
    match mutation {
        caly_core::domain::RuleProviderMutation::Add { name, .. }
        | caly_core::domain::RuleProviderMutation::Remove { name }
        | caly_core::domain::RuleProviderMutation::Enable { name }
        | caly_core::domain::RuleProviderMutation::Disable { name } => name.clone(),
    }
}

/// Post-mutation declared proxy-group count (lenient: a config that no
/// longer parses counts as zero, mirroring the subscription cache_stats
/// leniency).
fn count_proxy_groups(paths: &AppPaths) -> usize {
    caly_core::configstore::resource_writer::load_app_config(paths)
        .map_or(0, |config| config.proxy_groups.len())
}

/// Post-mutation declared rule-provider count (lenient, see above).
fn count_rule_providers(paths: &AppPaths) -> usize {
    caly_core::configstore::resource_writer::load_app_config(paths)
        .map_or(0, |config| config.rule_providers.len())
}

fn map_source_error(error: sources::SubSourceError) -> ActorFailure {
    crate::failure(
        &error.to_string(),
        "fix the argument and retry `caly sub …`",
    )
}

fn map_resource_error(
    error: caly_core::configstore::resource_mutations::ResourceMutationError,
) -> ActorFailure {
    crate::failure(
        &error.to_string(),
        "fix the argument and retry the resource `set` command",
    )
}
