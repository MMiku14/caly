//! Strict typed projection-event conversion with unknown preservation.

use caly_core::domain::{EventCursor, MutationOutcome, ObservedState, PresentationDelta};

use crate::protocol::v2::{DecodeBudget, WireEvent, WirePayload, WireProjectionEvent};

use super::snapshot::plain_text;
use super::{
    DecodeError, applied_from_wire, capabilities_from_wire, cursor_from_wire, desired_from_wire,
    nodes_from_wire, platform_from_wire, proxy_groups_from_wire, sources_from_wire,
};

/// Known Domain delta or preserved future event.
#[derive(Debug)]
pub enum DecodedProjectionEvent {
    Known {
        cursor: EventCursor,
        delta: PresentationDelta,
    },
    Unknown {
        cursor: EventCursor,
        raw_kind: i32,
        payload: WirePayload,
    },
}

/// Converts known events strictly and preserves unknown payloads.
pub fn event_from_wire(
    wire: WireEvent,
    budget: &mut DecodeBudget,
) -> Result<DecodedProjectionEvent, DecodeError> {
    let cursor = cursor_from_wire(wire.cursor);
    let delta = match wire.event {
        WireProjectionEvent::DesiredReplaced(value) => {
            PresentationDelta::DesiredReplaced(desired_from_wire(value)?)
        }
        WireProjectionEvent::AppliedReplaced(value) => {
            PresentationDelta::AppliedReplaced(applied_from_wire(value)?)
        }
        WireProjectionEvent::ObservedReplaced(value) => {
            PresentationDelta::ObservedReplaced(ObservedState::with_self_heal(
                value.upload_bytes_per_second,
                value.download_bytes_per_second,
                value.active_connections,
                value.telemetry_dropped,
                value.core_restart_count,
                value.core_restart_backoff_ms,
            ))
        }
        WireProjectionEvent::PlatformReplaced(value) => {
            PresentationDelta::PlatformReplaced(platform_from_wire(value, budget)?)
        }
        WireProjectionEvent::CapabilitiesReplaced(values) => {
            PresentationDelta::CapabilitiesReplaced(capabilities_from_wire(
                values.into_vec(),
                budget,
            )?)
        }
        WireProjectionEvent::NodesReplaced(values) => {
            PresentationDelta::NodesReplaced(nodes_from_wire(values.into_vec(), budget)?)
        }
        WireProjectionEvent::GroupsReplaced(values) => {
            PresentationDelta::GroupsReplaced(proxy_groups_from_wire(values.into_vec(), budget)?)
        }
        WireProjectionEvent::ConfigMutated(outcome) => {
            // The wire DTO leaves `url` as a plain String (legacy shape);
            // charge it through the same decode budget as every other
            // dynamic string before it enters Domain.
            let url = outcome
                .url
                .map(|value| plain_text(value, budget))
                .transpose()?;
            PresentationDelta::ConfigMutated(MutationOutcome {
                resource: outcome.resource,
                count: outcome.count,
                url,
                applied: outcome.applied,
                unchanged: outcome.unchanged,
            })
        }
        WireProjectionEvent::SourcesReplaced(values) => {
            PresentationDelta::SourcesReplaced(sources_from_wire(values.into_vec(), budget)?)
        }
        WireProjectionEvent::Unknown { raw_kind, payload } => {
            budget.charge_bytes(payload.len())?;
            return Ok(DecodedProjectionEvent::Unknown {
                cursor,
                raw_kind,
                payload,
            });
        }
    };
    Ok(DecodedProjectionEvent::Known { cursor, delta })
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::protocol::v2::{DecodeLimits, MAX_WIRE_SOURCES, WireEventCursor, WireSourceView};
    use caly_core::domain::{BoundedText, BoundedVec, ConfigResource, EventSequence, SourceView};

    fn test_cursor() -> EventCursor {
        EventCursor::new(
            caly_core::domain::DaemonInstanceId::from_bytes([1; 16]),
            EventSequence::new(1),
        )
    }

    fn wire_event(event: WireProjectionEvent) -> WireEvent {
        WireEvent {
            cursor: WireEventCursor {
                daemon_instance_id: [1; 16],
                sequence: 1,
            },
            event,
        }
    }

    #[test]
    fn config_mutation_event_round_trips_and_charges_url() -> Result<(), DecodeError> {
        let outcome = MutationOutcome {
            resource: ConfigResource::Subscription,
            count: 3,
            url: Some("https://example.com/sub".to_owned()),
            applied: true,
            unchanged: false,
        };
        let decoded = event_from_wire(
            wire_event(WireProjectionEvent::ConfigMutated(outcome.clone())),
            &mut DecodeBudget::new(DecodeLimits::v2_default()),
        )?;
        let DecodedProjectionEvent::Known { cursor, delta } = decoded else {
            panic!("config mutation must decode as a known delta");
        };
        assert_eq!(cursor, test_cursor());
        assert_eq!(delta, PresentationDelta::ConfigMutated(outcome));
        Ok(())
    }

    #[test]
    fn oversized_mutation_url_is_rejected_before_domain_construction() {
        let outcome = MutationOutcome {
            resource: ConfigResource::RuleProvider,
            count: 1,
            url: Some("https://example.com/oversized".to_owned()),
            applied: false,
            unchanged: false,
        };
        let limits = DecodeLimits {
            max_string_bytes: 8,
            ..DecodeLimits::v2_default()
        };
        let error = event_from_wire(
            wire_event(WireProjectionEvent::ConfigMutated(outcome)),
            &mut DecodeBudget::new(limits),
        )
        .expect_err("URL exceeds the negotiated string budget");
        assert!(matches!(error, DecodeError::Budget(_)));
    }

    #[test]
    fn sources_replaced_event_decodes_bounded_sources() -> Result<(), DecodeError> {
        let source = WireSourceView {
            index: 1,
            name: BoundedText::new("first").expect("bounded name"),
            kind: BoundedText::new("subscription").expect("bounded kind"),
            url: BoundedText::new("https://example.com/sub").expect("bounded url"),
            enabled: true,
            nodes: 7,
            groups: BoundedVec::new(),
            last_refresh_unix: Some(1_700_000_000),
            next_refresh_unix: None,
            cached: true,
        };
        let values = BoundedVec::<WireSourceView, MAX_WIRE_SOURCES>::try_from_vec(vec![source])
            .expect("one source fits");
        let decoded = event_from_wire(
            wire_event(WireProjectionEvent::SourcesReplaced(values)),
            &mut DecodeBudget::new(DecodeLimits::v2_default()),
        )?;
        let DecodedProjectionEvent::Known { delta, .. } = decoded else {
            panic!("sources must decode as a known delta");
        };
        let PresentationDelta::SourcesReplaced(sources) = delta else {
            panic!("expected SourcesReplaced delta");
        };
        assert_eq!(sources.len(), 1);
        let expected = SourceView {
            index: 1,
            name: "first".to_owned(),
            kind: "subscription".to_owned(),
            url: "https://example.com/sub".to_owned(),
            enabled: true,
            nodes: 7,
            groups: Vec::new(),
            last_refresh_unix: Some(1_700_000_000),
            next_refresh_unix: None,
            cached: true,
        };
        assert_eq!(sources[0], expected);
        Ok(())
    }
}
