//! Strict typed snapshot conversion.

use caly_core::domain::{
    AppliedState, BoundedText, BoundedVec, Capability, CapabilitySet, CapabilityStatus,
    ConfiguredSupport, CoreKind, CoreRunState, DesiredState, DisplayNode, LiveConnection, NodeId,
    ObservedState, PlatformEffectView, PresentationSnapshot, ProxyGroupView, ProxyMode,
    RuntimeAvailability, SnapshotRevision, SourceView, SubscriptionId,
};

use super::{DecodeError, cursor_from_wire};
use crate::protocol::v2::{
    CollectionKind, DecodeBudget, WireAppliedState, WireCapabilityStatus, WireDesiredState,
    WireDisplayNode, WireLiveConnection, WirePlatformEffect, WirePresentationSnapshot,
    WireProxyGroup, WireSourceView,
};

/// Converts a complete snapshot or rejects the entire payload.
pub fn snapshot_from_wire(
    wire: WirePresentationSnapshot,
    budget: &mut DecodeBudget,
) -> Result<PresentationSnapshot, DecodeError> {
    budget.check_count(CollectionKind::Nodes, wire.nodes.len())?;
    budget.check_count(CollectionKind::Groups, wire.proxy_groups.len())?;
    budget.check_count(CollectionKind::Subscriptions, wire.sources.len())?;
    let cursor = cursor_from_wire(wire.cursor);
    let daemon = caly_core::domain::DaemonInstanceId::from_bytes(wire.daemon_instance_id);
    if cursor.daemon_instance() != daemon {
        return Err(DecodeError::EpochMismatch);
    }
    let desired = desired_from_wire(wire.desired)?;
    let applied = applied_from_wire(wire.applied)?;
    let observed = ObservedState::with_self_heal(
        wire.observed.upload_bytes_per_second,
        wire.observed.download_bytes_per_second,
        wire.observed.active_connections,
        wire.observed.telemetry_dropped,
        wire.observed.core_restart_count,
        wire.observed.core_restart_backoff_ms,
    );
    let platform = platform_from_wire(wire.platform, budget)?;
    let capabilities = capabilities_from_wire(wire.capabilities.into_vec(), budget)?;
    let nodes = nodes_from_wire(wire.nodes.into_vec(), budget)?;
    let proxy_groups = proxy_groups_from_wire(wire.proxy_groups.into_vec(), budget)?;
    let sources = sources_from_wire(wire.sources.into_vec(), budget)?;
    Ok(PresentationSnapshot::new(
        daemon,
        SnapshotRevision::new(wire.revision),
        cursor,
        desired,
        applied,
        observed,
        platform,
        capabilities,
        nodes,
    )
    .with_proxy_groups(proxy_groups)
    .with_sources(sources))
}

/// Strictly decodes the daemon-mediated live connection slice. Every string
/// and chain entry is charged against the negotiated decode budget before
/// Domain construction.
pub fn live_connections_from_wire(
    values: Vec<WireLiveConnection>,
    budget: &mut DecodeBudget,
) -> Result<Vec<LiveConnection>, DecodeError> {
    budget.check_count(CollectionKind::Connections, values.len())?;
    let mut converted = Vec::with_capacity(values.len());
    for wire in values {
        let mut chain = Vec::with_capacity(wire.chain.len());
        for item in wire.chain {
            chain.push(plain_text(item, budget)?);
        }
        converted.push(LiveConnection {
            id: plain_text(wire.id, budget)?,
            host: plain_text(wire.host, budget)?,
            destination_port: wire.destination_port,
            network: plain_text(wire.network, budget)?,
            protocol_type: plain_text(wire.protocol_type, budget)?,
            inbound_name: plain_text(wire.inbound_name, budget)?,
            process_path: plain_text(wire.process_path, budget)?,
            rule: plain_text(wire.rule, budget)?,
            rule_payload: plain_text(wire.rule_payload, budget)?,
            outbound: plain_text(wire.outbound, budget)?,
            chain,
            upload_bytes: wire.upload_bytes,
            download_bytes: wire.download_bytes,
        });
    }
    Ok(converted)
}

/// Strictly decodes the kernel proxy-group slice. Unlike the wire DTO's
/// per-item count bound, the domain shape keeps plain strings, so the
/// decode budget charges every field before any allocation.
pub fn proxy_groups_from_wire(
    values: Vec<WireProxyGroup>,
    budget: &mut DecodeBudget,
) -> Result<Vec<ProxyGroupView>, DecodeError> {
    budget.check_count(CollectionKind::Groups, values.len())?;
    let mut converted = Vec::with_capacity(values.len());
    for wire in values {
        let name = plain_text(wire.name, budget)?;
        let kind = plain_text(wire.kind, budget)?;
        let selected = wire
            .selected
            .map(|value| plain_text(value, budget))
            .transpose()?;
        let mut members = Vec::with_capacity(wire.members.len());
        for member in wire.members {
            members.push(plain_text(member, budget)?);
        }
        converted.push(ProxyGroupView {
            name,
            kind,
            selected,
            members,
        });
    }
    Ok(converted)
}

/// Strictly decodes the declared subscription-source listing. Wire fields
/// are already bounded by their DTO types; the decode budget still charges
/// every string and group name before Domain construction.
pub fn sources_from_wire(
    values: Vec<WireSourceView>,
    budget: &mut DecodeBudget,
) -> Result<Vec<SourceView>, DecodeError> {
    budget.check_count(CollectionKind::Subscriptions, values.len())?;
    let mut converted = Vec::with_capacity(values.len());
    for wire in values {
        let mut groups = Vec::with_capacity(wire.groups.len());
        for group in &wire.groups {
            groups.push(plain_text(group.as_str().to_owned(), budget)?);
        }
        converted.push(SourceView {
            index: usize::try_from(wire.index).map_err(|_| DecodeError::InvalidState {
                reason: "source index does not fit usize".to_owned(),
            })?,
            name: bounded_wire_text(&wire.name, budget)?,
            kind: bounded_wire_text(&wire.kind, budget)?,
            url: bounded_wire_text(&wire.url, budget)?,
            enabled: wire.enabled,
            nodes: usize::try_from(wire.nodes).map_err(|_| DecodeError::InvalidState {
                reason: "source node count does not fit usize".to_owned(),
            })?,
            groups,
            last_refresh_unix: wire.last_refresh_unix,
            next_refresh_unix: wire.next_refresh_unix,
            cached: wire.cached,
        });
    }
    Ok(converted)
}

/// Strictly decodes persisted intent.
pub fn desired_from_wire(wire: WireDesiredState) -> Result<DesiredState, DecodeError> {
    Ok(DesiredState::new(
        proxy_mode(wire.mode)?,
        wire.selected_node_id.map(NodeId::from_bytes),
        wire.active_subscription_id.map(SubscriptionId::from_bytes),
        wire.tun_requested,
        wire.system_proxy_requested,
    ))
}

/// Strictly decodes runtime-applied state.
pub fn applied_from_wire(wire: WireAppliedState) -> Result<AppliedState, DecodeError> {
    let core = wire.core_kind.map(core_kind).transpose()?;
    AppliedState::new(
        core,
        run_state(wire.run_state)?,
        wire.selected_node_id.map(NodeId::from_bytes),
        wire.config_generation,
    )
    .map_err(|error| DecodeError::InvalidState {
        reason: error.to_string(),
    })
}

/// Strictly decodes redacted platform effects.
pub fn platform_from_wire(
    wire: WirePlatformEffect,
    budget: &mut DecodeBudget,
) -> Result<PlatformEffectView, DecodeError> {
    let reason = wire
        .degraded_reason
        .map(|value| bounded_text(value, "platform.degraded_reason", budget))
        .transpose()?;
    Ok(PlatformEffectView::new(
        wire.proxy_engaged,
        wire.tun_engaged,
        wire.recovery_pending,
        reason,
    ))
}

/// Strictly decodes bounded capability assessments.
pub fn capabilities_from_wire(
    values: Vec<WireCapabilityStatus>,
    budget: &mut DecodeBudget,
) -> Result<CapabilitySet, DecodeError> {
    let mut converted = Vec::with_capacity(values.len());
    for wire in values {
        let caveat = wire
            .caveat
            .map(|value| bounded_text(value, "capability.caveat", budget))
            .transpose()?;
        converted.push(CapabilityStatus::new(
            capability(wire.capability)?,
            configured(wire.configured)?,
            runtime(wire.runtime)?,
            caveat,
        ));
    }
    let bounded =
        BoundedVec::try_from_vec(converted).map_err(|error| DecodeError::InvalidState {
            reason: error.to_string(),
        })?;
    CapabilitySet::new(bounded).map_err(|error| DecodeError::InvalidState {
        reason: error.to_string(),
    })
}

/// Strictly decodes bounded display nodes.
pub fn nodes_from_wire(
    values: Vec<WireDisplayNode>,
    budget: &mut DecodeBudget,
) -> Result<caly_core::domain::SnapshotNodes, DecodeError> {
    let mut converted = Vec::with_capacity(values.len());
    for wire in values {
        converted.push(DisplayNode::new(
            NodeId::from_bytes(wire.node_id),
            bounded_text(wire.name, "node.name", budget)?,
            bounded_text(wire.protocol, "node.protocol", budget)?,
            wire.available,
            wire.latency_ms,
        ));
    }
    BoundedVec::try_from_vec(converted).map_err(|error| DecodeError::InvalidState {
        reason: error.to_string(),
    })
}

/// Charges and returns an unbounded wire string before it reaches Domain.
pub fn plain_text(value: String, budget: &mut DecodeBudget) -> Result<String, DecodeError> {
    budget.check_string(value.len())?;
    budget.charge_bytes(value.len())?;
    Ok(value)
}

/// Charges and unwraps a wire-side `BoundedText` into an owned String.
fn bounded_wire_text<const MAX: usize>(
    value: &BoundedText<MAX>,
    budget: &mut DecodeBudget,
) -> Result<String, DecodeError> {
    plain_text(value.as_str().to_owned(), budget)
}

fn bounded_text<const MAX: usize>(
    value: String,
    field: &'static str,
    budget: &mut DecodeBudget,
) -> Result<BoundedText<MAX>, DecodeError> {
    budget.check_string(value.len())?;
    budget.charge_bytes(value.len())?;
    BoundedText::new(value).map_err(|error| DecodeError::InvalidText {
        field,
        reason: error.to_string(),
    })
}

fn proxy_mode(raw: i32) -> Result<ProxyMode, DecodeError> {
    use crate::protocol::v2::WireMode;
    WireMode::from_wire(raw)
        .map(ProxyMode::from)
        .ok_or_else(|| unknown_value("desired.mode", raw))
}

fn core_kind(raw: i32) -> Result<CoreKind, DecodeError> {
    use crate::protocol::v2::WireCoreKind;
    WireCoreKind::from_wire(raw)
        .map(CoreKind::from)
        .ok_or_else(|| unknown_value("applied.core_kind", raw))
}

fn run_state(raw: i32) -> Result<CoreRunState, DecodeError> {
    use crate::protocol::v2::WireRunState;
    WireRunState::from_wire(raw)
        .map(CoreRunState::from)
        .ok_or_else(|| unknown_value("applied.run_state", raw))
}

fn capability(raw: i32) -> Result<Capability, DecodeError> {
    match raw {
        1 => Ok(Capability::TunConfiguration),
        2 => Ok(Capability::DnsConfiguration),
        3 => Ok(Capability::RuntimeModeSwitch),
        4 => Ok(Capability::ProxyGroups),
        5 => Ok(Capability::ProxySelection),
        6 => Ok(Capability::UrlTest),
        7 => Ok(Capability::Connections),
        8 => Ok(Capability::ConnectionClose),
        9 => Ok(Capability::Traffic),
        10 => Ok(Capability::Logs),
        11 => Ok(Capability::Rules),
        value => unknown("capability.kind", value),
    }
}

fn configured(raw: i32) -> Result<ConfiguredSupport, DecodeError> {
    match raw {
        1 => Ok(ConfiguredSupport::Unsupported),
        2 => Ok(ConfiguredSupport::Supported),
        3 => Ok(ConfiguredSupport::Partial),
        value => unknown("capability.configured", value),
    }
}

fn runtime(raw: i32) -> Result<RuntimeAvailability, DecodeError> {
    match raw {
        1 => Ok(RuntimeAvailability::NotRequired),
        2 => Ok(RuntimeAvailability::Available),
        3 => Ok(RuntimeAvailability::Unavailable),
        4 => Ok(RuntimeAvailability::Unknown),
        value => unknown("capability.runtime", value),
    }
}

fn unknown<T>(field: &'static str, raw: i32) -> Result<T, DecodeError> {
    Err(DecodeError::UnknownEnum { field, raw })
}

fn unknown_value(field: &'static str, raw: i32) -> DecodeError {
    DecodeError::UnknownEnum { field, raw }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::conversion::snapshot_to_wire;
    use crate::protocol::v2::DecodeLimits;
    use caly_core::domain::{
        BoundedVec, CapabilitySet, DaemonInstanceId, DesiredState, EventCursor, EventSequence,
        ObservedState, PlatformEffectView, ProxyMode, SourceView,
    };

    #[test]
    fn snapshot_round_trip_preserves_proxy_groups_and_sources()
    -> Result<(), Box<dyn std::error::Error>> {
        let daemon = DaemonInstanceId::from_bytes([7; 16]);
        let cursor = EventCursor::new(daemon, EventSequence::new(3));
        let snapshot = PresentationSnapshot::new(
            daemon,
            SnapshotRevision::new(9),
            cursor,
            DesiredState::new(ProxyMode::Rule, None, None, false, false),
            AppliedState::stopped(),
            ObservedState::default(),
            PlatformEffectView::none(),
            CapabilitySet::new(BoundedVec::new())?,
            BoundedVec::new(),
        )
        .with_proxy_groups(vec![ProxyGroupView {
            name: "select".to_owned(),
            kind: "Selector".to_owned(),
            selected: Some("A".to_owned()),
            members: vec!["A".to_owned(), "B".to_owned()],
        }])
        .with_sources(vec![SourceView {
            index: 1,
            name: "first".to_owned(),
            kind: "subscription".to_owned(),
            url: "https://example.com/sub".to_owned(),
            enabled: true,
            nodes: 7,
            groups: vec!["select".to_owned()],
            last_refresh_unix: Some(1_700_000_000),
            next_refresh_unix: None,
            cached: true,
        }]);
        let wire = snapshot_to_wire(&snapshot)?;
        let decoded = snapshot_from_wire(wire, &mut DecodeBudget::new(DecodeLimits::v2_default()))?;
        assert_eq!(decoded.proxy_groups(), snapshot.proxy_groups());
        assert_eq!(decoded.sources(), snapshot.sources());
        Ok(())
    }
}
