//! Replay and full-snapshot recovery stream values.

use super::snapshot::{MAX_WIRE_SOURCES, WireSourceView};
use caly_core::domain::BoundedVec;

use super::{
    MAX_WIRE_PROXY_GROUPS, WireAppliedState, WireCapabilityStatus, WireDesiredState,
    WireDisplayNode, WireEventCursor, WireObservedState, WirePayload, WirePlatformEffect,
    WirePresentationSnapshot, WireProxyGroup,
};

/// Maximum event-kind filters accepted in one watch request.
pub const MAX_WATCH_FILTERS: usize = 32;
/// Maximum bytes accepted in one watch filter entry.
pub const MAX_WATCH_FILTER_BYTES: usize = 64;

/// Starts live delivery after an optional last-applied cursor. An optional
/// event-kind filter selects projection variants by their wire name
/// (`NodesReplaced`, `AppliedReplaced`, …); recovery `FullSnapshot` frames are
/// always delivered so a filtered client can still rebuild authoritative state.
#[derive(Clone, Debug, Eq, PartialEq, serde::Serialize, serde::Deserialize)]
pub struct WatchEventsRequest {
    pub after: Option<WireEventCursor>,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub filter: Option<Vec<String>>,
}

/// Typed projection delta or preserved unknown future event.
#[derive(Clone, Debug, Eq, PartialEq, serde::Serialize, serde::Deserialize)]
pub enum WireProjectionEvent {
    DesiredReplaced(WireDesiredState),
    AppliedReplaced(WireAppliedState),
    ObservedReplaced(WireObservedState),
    PlatformReplaced(WirePlatformEffect),
    CapabilitiesReplaced(BoundedVec<WireCapabilityStatus, 64>),
    NodesReplaced(BoundedVec<WireDisplayNode, 10_000>),
    /// W3b: the kernel proxy-group slice after a selection refresh.
    GroupsReplaced(BoundedVec<WireProxyGroup, MAX_WIRE_PROXY_GROUPS>),
    /// CLI sinking (2026-08-14): a config.yaml mutation outcome
    /// (declared count per resource) so watch clients re-render
    /// `sub list` without reading the file.
    ConfigMutated(caly_core::domain::MutationOutcome),
    /// CLI sinking (2026-08-14, read path): the declared subscription
    /// source listing was recomputed.
    SourcesReplaced(BoundedVec<WireSourceView, MAX_WIRE_SOURCES>),
    Unknown {
        raw_kind: i32,
        payload: WirePayload,
    },
}

/// Ordered event payload.
#[derive(Clone, Debug, Eq, PartialEq, serde::Serialize, serde::Deserialize)]
pub struct WireEvent {
    pub cursor: WireEventCursor,
    pub event: WireProjectionEvent,
}

/// Watch stream recovery contract.
#[derive(Clone, Debug, Eq, PartialEq, serde::Serialize, serde::Deserialize)]
pub enum WatchResponse {
    /// One ordered event.
    Event(WireEvent),
    /// Authoritative replacement after epoch mismatch or replay gap
    /// (boxed: the full snapshot is the largest wire payload by far).
    FullSnapshot(Box<WirePresentationSnapshot>),
}
