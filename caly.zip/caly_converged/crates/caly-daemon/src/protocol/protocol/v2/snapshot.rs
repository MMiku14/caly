//! Typed snapshot wire projection with raw enum preservation.

use caly_core::domain::BoundedVec;

use super::{WireEventCursor, WireId};

/// Maximum nodes accepted in one wire snapshot.
pub const MAX_WIRE_NODES: usize = 10_000;
/// Maximum live connections accepted in one daemon-mediated flow read.
pub const MAX_WIRE_LIVE_CONNECTIONS: usize = 4_096;
/// Maximum group-chain entries per live connection.
pub const MAX_WIRE_CONNECTION_CHAIN: usize = 32;
/// Maximum wire size for one live connection text field.
pub const MAX_WIRE_CONNECTION_TEXT_BYTES: usize = 1_024;
/// Maximum capability assessments accepted in one wire snapshot.
pub const MAX_WIRE_CAPABILITIES: usize = 64;
/// W3b: sane ceiling for kernel proxy groups (Selector/URLTest/…).
pub const MAX_WIRE_PROXY_GROUPS: usize = 256;

/// One live connection detail projected by the daemon. Strings are checked
/// against the negotiated decode limits before Domain conversion.
#[derive(Clone, Debug, Eq, PartialEq, serde::Serialize, serde::Deserialize)]
pub struct WireLiveConnection {
    pub id: String,
    pub host: String,
    pub destination_port: u16,
    pub network: String,
    pub protocol_type: String,
    pub inbound_name: String,
    pub process_path: String,
    pub rule: String,
    pub rule_payload: String,
    pub outbound: String,
    pub chain: Vec<String>,
    pub upload_bytes: u64,
    pub download_bytes: u64,
}

/// Requests the current live connection-detail slice.
#[derive(Clone, Copy, Debug, Default, Eq, PartialEq, serde::Serialize, serde::Deserialize)]
pub struct GetLiveConnectionsRequest;

/// Bounded live connection response for flow UIs.
#[derive(Clone, Debug, Eq, PartialEq, serde::Serialize, serde::Deserialize)]
pub struct LiveConnectionsResponse {
    pub connections: BoundedVec<WireLiveConnection, MAX_WIRE_LIVE_CONNECTIONS>,
}

/// Requests the current immutable presentation snapshot.
#[derive(Clone, Copy, Debug, Default, Eq, PartialEq, serde::Serialize, serde::Deserialize)]
pub struct GetSnapshotRequest;

/// Complete typed presentation snapshot envelope.
#[derive(Clone, Debug, Eq, PartialEq, serde::Serialize, serde::Deserialize)]
pub struct WirePresentationSnapshot {
    #[serde(with = "crate::json_serde::hex_id")]
    pub daemon_instance_id: WireId,
    pub revision: u64,
    pub cursor: WireEventCursor,
    pub desired: WireDesiredState,
    pub applied: WireAppliedState,
    pub observed: WireObservedState,
    pub platform: WirePlatformEffect,
    pub capabilities: BoundedVec<WireCapabilityStatus, MAX_WIRE_CAPABILITIES>,
    pub nodes: BoundedVec<WireDisplayNode, MAX_WIRE_NODES>,
    pub proxy_groups: BoundedVec<WireProxyGroup, MAX_WIRE_PROXY_GROUPS>,
    /// CLI sinking (2026-08-14, read path): declared subscription-source
    /// listing so `sub list` renders from the snapshot.
    pub sources: BoundedVec<WireSourceView, MAX_WIRE_SOURCES>,
}

/// Persisted intent projection using raw enum values.
#[derive(Clone, Debug, Eq, PartialEq, serde::Serialize, serde::Deserialize)]
pub struct WireDesiredState {
    pub mode: i32,
    #[serde(with = "crate::json_serde::hex_id_opt")]
    pub selected_node_id: Option<WireId>,
    #[serde(with = "crate::json_serde::hex_id_opt")]
    pub active_subscription_id: Option<WireId>,
    pub tun_requested: bool,
    pub system_proxy_requested: bool,
}

/// Runtime-applied projection using raw enum values.
#[derive(Clone, Debug, Eq, PartialEq, serde::Serialize, serde::Deserialize)]
pub struct WireAppliedState {
    pub core_kind: Option<i32>,
    pub run_state: i32,
    #[serde(with = "crate::json_serde::hex_id_opt")]
    pub selected_node_id: Option<WireId>,
    pub config_generation: Option<u64>,
}

/// Runtime observations.
#[derive(Clone, Copy, Debug, Eq, PartialEq, serde::Serialize, serde::Deserialize)]
pub struct WireObservedState {
    pub upload_bytes_per_second: u64,
    pub download_bytes_per_second: u64,
    pub active_connections: u32,
    pub telemetry_dropped: u64,
    pub core_restart_count: u64,
    pub core_restart_backoff_ms: u64,
}

/// Redacted platform side-effect projection.
#[derive(Clone, Debug, Eq, PartialEq, serde::Serialize, serde::Deserialize)]
pub struct WirePlatformEffect {
    pub proxy_engaged: bool,
    pub tun_engaged: bool,
    pub recovery_pending: bool,
    pub degraded_reason: Option<String>,
}

/// Configured/runtime capability assessment with raw enums.
#[derive(Clone, Debug, Eq, PartialEq, serde::Serialize, serde::Deserialize)]
pub struct WireCapabilityStatus {
    pub capability: i32,
    pub configured: i32,
    pub runtime: i32,
    pub caveat: Option<String>,
}

/// Credential-free node projection.
#[derive(Clone, Debug, Eq, PartialEq, serde::Serialize, serde::Deserialize)]
pub struct WireDisplayNode {
    #[serde(with = "crate::json_serde::hex_id")]
    pub node_id: WireId,
    pub name: String,
    pub protocol: String,
    pub available: bool,
    pub latency_ms: Option<u32>,
}

/// W3b enrichment: a proxy group as seen by the kernel (kind,
/// kernel-side membership, current selection).
#[derive(Clone, Debug, Eq, PartialEq, serde::Serialize, serde::Deserialize)]
pub struct WireProxyGroup {
    pub name: String,
    /// Kernel group kind: `Selector`, `URLTest`, `Fallback`, `LoadBalance`.
    pub kind: String,
    pub selected: Option<String>,
    pub members: Vec<String>,
}

/// One declared subscription source in the presentation snapshot. The
/// wire form is bounded (names ≤64 chars, URLs ≤2048, ≤64 group names)
/// so a hostile config cannot balloon the snapshot.
#[derive(Clone, Debug, Eq, PartialEq, serde::Serialize, serde::Deserialize)]
pub struct WireSourceView {
    /// 1-based add-order id shown in `sub list`'s ID column.
    pub index: u32,
    /// Display name (`--name`) or the `#N` fallback.
    pub name: caly_core::domain::BoundedText<64>,
    /// Row kind: `"subscription"`.
    pub kind: caly_core::domain::BoundedText<16>,
    /// The stored source URL (`http(s)://` or `file://`).
    pub url: caly_core::domain::BoundedText<2048>,
    /// Whether the source is fetched on refresh.
    pub enabled: bool,
    /// Number of parsed nodes in the cached body (0 when never cached).
    pub nodes: u32,
    /// Proxy-group names the cached body declares.
    pub groups: caly_core::domain::BoundedVec<caly_core::domain::BoundedText<64>, 64>,
    /// Last successful refresh (cache mtime, unix seconds).
    pub last_refresh_unix: Option<u64>,
    /// Next scheduled refresh, unix seconds.
    pub next_refresh_unix: Option<u64>,
    /// A cached body exists (an enabled source without one is "stale").
    pub cached: bool,
}

/// Cap on declared sources in one snapshot (config.yaml `sources` list).
pub const MAX_WIRE_SOURCES: usize = 256;
