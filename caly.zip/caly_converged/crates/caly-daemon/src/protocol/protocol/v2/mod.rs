//! Protocol v2 transport-neutral DTOs.

use caly_core::domain::BoundedVec;

mod budget;
mod handshake;
mod negotiation;
mod operation;
mod snapshot;
mod watch;
mod wire;

pub use budget::{BudgetError, CollectionKind, DecodeBudget, DecodeLimits};
pub use handshake::{
    Feature, FeatureList, HandshakeRequest, HandshakeResponse, ProtocolVersion, RawFeature,
    all_features,
};
pub use negotiation::{HandshakeError, negotiate_handshake};
pub use operation::{
    CancelOperationRequest, CancelOperationResponse, CancelOutcome, CommandKind,
    ExecuteBatchRequest, ExecuteBatchResponse, ExecuteBatchResult, ExecuteRequest, ExecuteResponse,
    ExecuteSyncRequest, ExecuteSyncResponse, GetOperationStatusRequest, MAX_WIRE_BATCH,
    MAX_WIRE_OPERATION_LIST, OperationListResponse, RawCancelOutcome, RawCommandKind,
    RawFailureCode, RawOperationState, WireBatchRejection, WireCommand, WireOperationFailure,
    WireOperationStatus,
};
pub use snapshot::{
    GetLiveConnectionsRequest, GetSnapshotRequest, LiveConnectionsResponse,
    MAX_WIRE_CONNECTION_CHAIN, MAX_WIRE_CONNECTION_TEXT_BYTES, MAX_WIRE_LIVE_CONNECTIONS,
    MAX_WIRE_PROXY_GROUPS, MAX_WIRE_SOURCES, WireAppliedState, WireCapabilityStatus,
    WireDesiredState, WireDisplayNode, WireLiveConnection, WireObservedState, WirePlatformEffect,
    WirePresentationSnapshot, WireProxyGroup, WireSourceView,
};
pub use watch::{
    MAX_WATCH_FILTER_BYTES, MAX_WATCH_FILTERS, WatchEventsRequest, WatchResponse, WireEvent,
    WireProjectionEvent,
};
pub use wire::{WireCoreAction, WireCoreKind, WireMode, WireOperationState, WireRunState};

/// Maximum opaque payload accepted by a typed v2 DTO.
pub const MAX_WIRE_PAYLOAD_BYTES: usize = 16 * 1_024 * 1_024;
/// Capacity-enforced opaque payload.
pub type WirePayload = BoundedVec<u8, MAX_WIRE_PAYLOAD_BYTES>;
/// Opaque wire representation of a 128-bit identity.
pub type WireId = [u8; 16];

/// Epoch-aware wire cursor.
#[derive(Clone, Copy, Debug, Eq, PartialEq, serde::Serialize, serde::Deserialize)]
pub struct WireEventCursor {
    /// Daemon epoch bytes.
    #[serde(with = "crate::json_serde::hex_id")]
    pub daemon_instance_id: WireId,
    /// Sequence within the daemon epoch.
    pub sequence: u64,
}
