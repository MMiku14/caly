//! Bootstrap assembly: channels, auto-start, dispatcher and runtime startup.

use super::{
    ApplicationComposition, CommandReceiver, CompositionError, RunningApplication,
    RuntimeCapacities, RuntimeService, WallClock, task_name,
};
use crate::application::{
    ActorCommandFanout,
    actor_result::{ActorResultClient, ActorResultReceiver, actor_result_mailbox},
    projection::ProjectionRuntime,
    runtime::{
        ActorIngress, ActorReceiver, CancellationToken, TokioTaskFailure, TokioTaskGroup,
        actor_mailbox,
    },
};
use crate::backends::dual::DualCoreLifecycle;

/// Actor channels opened once during runtime bootstrap.
struct ActorChannels {
    fanout: ActorCommandFanout,
    result_client: ActorResultClient,
    result_receiver: ActorResultReceiver,
    core_lifecycle_receiver:
        crate::application::runtime::ActorReceiver<crate::application::routing::RoutedCommand>,
    config_receiver:
        crate::application::runtime::ActorReceiver<crate::application::routing::RoutedCommand>,
    core_receiver:
        crate::application::runtime::ActorReceiver<crate::application::routing::RoutedCommand>,
    subscription_receiver:
        crate::application::runtime::ActorReceiver<crate::application::routing::RoutedCommand>,
    platform_receiver:
        crate::application::runtime::ActorReceiver<crate::application::routing::RoutedCommand>,
    config_mutation_receiver:
        crate::application::runtime::ActorReceiver<crate::application::routing::RoutedCommand>,
    telemetry_receiver:
        crate::application::runtime::ActorReceiver<crate::application::actors::TelemetryActorCommand>,
    telemetry_ingress:
        crate::application::runtime::ActorIngress<crate::application::actors::TelemetryActorCommand>,
}

fn open_channels(capacities: RuntimeCapacities) -> Result<ActorChannels, CompositionError> {
    let (core_lifecycle, core_lifecycle_receiver) = open_mailbox(capacities.actor_mailbox)?;
    let (config, config_receiver) = open_mailbox(capacities.actor_mailbox)?;
    let (core, core_receiver) = open_mailbox(capacities.actor_mailbox)?;
    let (subscription, subscription_receiver) = open_mailbox(capacities.actor_mailbox)?;
    let (platform, platform_receiver) = open_mailbox(capacities.actor_mailbox)?;
    let (config_mutation, config_mutation_receiver) = open_mailbox(capacities.actor_mailbox)?;
    let (result_ingress, result_receiver) = actor_result_mailbox(capacities.actor_mailbox)
        .map_err(|_| CompositionError::MailboxCapacity)?;
    let (telemetry_ingress, telemetry_receiver) = open_mailbox(capacities.actor_mailbox)?;
    Ok(ActorChannels {
        fanout: ActorCommandFanout {
            core_lifecycle,
            config,
            core,
            subscription,
            platform,
            config_mutation,
        },
        result_client: ActorResultClient::new(result_ingress),
        result_receiver,
        core_lifecycle_receiver,
        config_receiver,
        core_receiver,
        subscription_receiver,
        platform_receiver,
        config_mutation_receiver,
        telemetry_receiver,
        telemetry_ingress,
    })
}

/// Opens a bounded actor mailbox, mapping a capacity failure to the
/// composition error.
fn open_mailbox<M: Send>(
    capacity: usize,
) -> Result<(ActorIngress<M>, ActorReceiver<M>), CompositionError> {
    actor_mailbox(capacity).map_err(|_| CompositionError::MailboxCapacity)
}

mod boot_gate;

use boot_gate::boot_sequence;

/// Spawns the command dispatcher task and registers it on the task group.
fn spawn_dispatcher(
    tasks: &mut TokioTaskGroup,
    service: std::sync::Arc<std::sync::Mutex<RuntimeService<WallClock, ProjectionRuntime>>>,
    command_receiver: CommandReceiver,
    fanout: ActorCommandFanout,
    result_receiver: ActorResultReceiver,
    cancellation: CancellationToken,
    runtime_guard: std::sync::Arc<std::sync::Mutex<crate::application::runtime::RuntimeGuard>>,
) -> Result<(), CompositionError> {
    // Resolve the bounded task name once and reuse it for the outer
    // registration and the inner Join error path.
    let dispatcher_name = task_name("command-dispatcher")?;
    let join_name = dispatcher_name.clone();
    let dispatcher_cancellation = cancellation;
    let dispatcher = tokio::spawn(async move {
        super::handlers::dispatch_loop(
            service,
            command_receiver,
            fanout,
            result_receiver,
            dispatcher_cancellation,
            runtime_guard,
        )
        .await
    });
    tasks
        .spawn_owned_with_fault(
            dispatcher_name,
            crate::application::runtime::FatalFault::CommandDispatch,
            async move {
                dispatcher
                    .await
                    .map_err(|_| TokioTaskFailure::Join { name: join_name })??;
                Ok(())
            },
        )
        .map_err(|_| CompositionError::TaskCapacity)
}

impl ApplicationComposition {
    /// Starts the application runtime.
    ///
    /// `auto_start` engages the configured core (Mihomo/sing-box) during
    /// bootstrap. Hermetic composition tests pass `false`; the daemon passes
    /// `true`.
    pub fn start_runtime(self, auto_start: bool) -> Result<RunningApplication, CompositionError> {
        let channels = open_channels(self.capacities)?;
        let mut runtime_backends = super::backends::build_runtime_backends(
            self.configured_core,
            self.tun,
            &self.controllers,
            &self.binaries,
            self.subscription_urls.as_slice(),
            &self.tuning,
        )?;
        let core_backend = runtime_backends.core;
        let registry = runtime_backends.registry;
        let mut subscription_backend = runtime_backends.subscription;
        restore_cached_subscriptions(&self.service, &mut subscription_backend);
        let config_backend = runtime_backends.config;
        let lifecycle_handle = runtime_backends.lifecycle.clone();
        // Restore-first + config effects + auto-start run before any task is
        // spawned; only the core auto-start itself is optional.
        boot_sequence(
            &mut runtime_backends.platform,
            &mut runtime_backends.tun,
            &lifecycle_handle,
            &self.service,
            self.tuning.system_proxy_enabled,
            auto_start,
            self.configured_core,
        )?;
        let platform_backend = super::SharedPlatformBackend::new(runtime_backends.platform);
        let tun_backend = super::SharedTunBackend::new(runtime_backends.tun);
        let controller_secret = runtime_backends.controller_secret.clone();
        // Persist the controller secret so offline CLI queries can authenticate
        // against the running core's controller.
        if let Some(secret) = &controller_secret {
            super::publish_controller_secret(secret);
        }
        let lifecycle_backend = lifecycle_handle.clone();
        install_live_connection_query(
            &self.service,
            &lifecycle_handle,
            &self.controllers,
            controller_secret.as_ref(),
        );
        super::publish_boot_capabilities(
            &self.service,
            self.configured_core,
            self.tuning.dns.is_some(),
        )?;
        let runtime_guard = std::sync::Arc::new(std::sync::Mutex::new(
            crate::application::runtime::RuntimeGuard::new(),
        ));
        let mut tasks = TokioTaskGroup::with_runtime_guard(runtime_guard.clone());
        let cancellation = tasks.cancellation();
        let handles = spawn_runtime_tasks(
            &mut tasks,
            self.service.clone(),
            self.command_receiver,
            channels,
            &lifecycle_backend,
            core_backend,
            subscription_backend,
            platform_backend.clone(),
            tun_backend.clone(),
            config_backend,
            registry,
            &lifecycle_handle,
            self.configured_core,
            controller_secret,
            &self.controllers,
            self.telemetry_interval,
            cancellation,
            runtime_guard.clone(),
            self.tuning.restart_backoffs(),
        )?;
        Ok(RunningApplication {
            tasks,
            runtime_guard,
            service: self.service,
            lifecycle: lifecycle_handle,
            platform: platform_backend,
            tun: tun_backend,
            _result_client: handles.result_client,
            telemetry_ingress: handles.telemetry_ingress,
        })
    }
}

/// Installs the shared live-connection query on the service so the
/// `connections` RPC reads live kernel controller data.
/// Mirrors the telemetry control construction (same endpoints, same clamped
/// secret): a control that cannot be constructed (bad address) leaves the
/// query uninstalled and the RPC keeps failing as `Unavailable` instead of
/// failing startup.
fn install_live_connection_query(
    service: &std::sync::Arc<std::sync::Mutex<RuntimeService<WallClock, ProjectionRuntime>>>,
    lifecycle_handle: &DualCoreLifecycle,
    controllers: &caly_core::domain::Controllers,
    controller_secret: Option<&String>,
) {
    let mihomo = caly_kernel::corectl::mihomo::MihomoHttpControl::new(
        controllers.mihomo.clone(),
        controller_secret
            .cloned()
            .map(super::handlers::clamp_secret::<4_096>),
    )
    .map(|control| Box::new(control) as Box<dyn caly_kernel::corectl::contract::KernelControl + Send>);
    let sing_box = caly_kernel::corectl::sing_box::SingBoxHttpControl::new(
        controllers.sing_box.clone(),
        controller_secret
            .cloned()
            .map(super::handlers::clamp_secret::<4_096>),
    )
    .map(|control| Box::new(control) as Box<dyn caly_kernel::corectl::contract::KernelControl + Send>);
    if let (Ok(mihomo), Ok(sing_box)) = (mihomo, sing_box) {
        let query: crate::application::service::SharedLiveConnectionQuery =
            std::sync::Arc::new(std::sync::Mutex::new(
                crate::backends::dual::SwitchableKernelControl::new(
                    lifecycle_handle.active_cell(),
                    mihomo,
                    sing_box,
                ),
            ));
        match service.lock() {
            Ok(mut service) => service.set_live_connection_query(query),
            Err(error) => tracing::warn!(
                error = ?error,
                "service lock poisoned; live connection query not installed",
            ),
        }
    } else {
        tracing::warn!(
            "live connection query unavailable: check controllers.* addresses (connections RPC stays Unavailable)"
        );
    }
}

/// Restores cached subscriptions into the node registry before any command
/// can be served, so list-nodes/delay/select work immediately after a daemon
/// restart. The restored projection also seeds the presentation snapshot.
fn restore_cached_subscriptions(
    service: &std::sync::Arc<std::sync::Mutex<RuntimeService<WallClock, ProjectionRuntime>>>,
    subscription_backend: &mut crate::backends::HttpSubscriptionBackend,
) {
    match subscription_backend.restore_cached() {
        Ok(restored) if !restored.is_empty() => {
            let mut merged = Vec::new();
            for nodes in restored {
                merged.extend(nodes.as_slice().iter().cloned());
            }
            match caly_core::domain::SnapshotNodes::try_from_vec(merged) {
                Ok(nodes) => {
                    if let Ok(mut service) = service.lock()
                        && let Err(error) = service
                            .projection_mut()
                            .publish(caly_core::domain::PresentationDelta::NodesReplaced(nodes))
                    {
                        tracing::warn!(error = ?error, "cached nodes did not seed projection");
                    }
                }
                Err(error) => {
                    tracing::warn!(error = ?error, "cached node snapshot exceeded bounds");
                }
            }
            tracing::info!("restored cached subscriptions");
        }
        Ok(_) => {}
        Err(error) => {
            tracing::warn!(error = %error, "cached subscription restore failed; nodes start empty");
        }
    }
}
/// Ingress handles kept alive for the runtime lifetime.
struct RuntimeHandles {
    result_client: ActorResultClient,
    telemetry_ingress:
        crate::application::runtime::ActorIngress<crate::application::actors::TelemetryActorCommand>,
}

/// Spawns dispatcher, exit monitor, owner handlers and supervision actors.
fn spawn_runtime_tasks(
    tasks: &mut TokioTaskGroup,
    service: std::sync::Arc<std::sync::Mutex<RuntimeService<WallClock, ProjectionRuntime>>>,
    command_receiver: CommandReceiver,
    channels: ActorChannels,
    lifecycle_backend: &DualCoreLifecycle,
    core_backend: crate::backends::dual::SwitchableCoreBackend,
    subscription_backend: crate::backends::HttpSubscriptionBackend,
    platform_backend: super::SharedPlatformBackend,
    tun_backend: super::SharedTunBackend,
    config_backend: crate::backends::config::ActiveConfigBackend,
    registry: crate::backends::CoreNodeRegistry,
    lifecycle_handle: &DualCoreLifecycle,
    configured_core: caly_core::domain::CoreKind,
    controller_secret: Option<String>,
    controllers: &caly_core::domain::Controllers,
    telemetry_interval: std::time::Duration,
    cancellation: crate::application::runtime::CancellationToken,
    runtime_guard: std::sync::Arc<std::sync::Mutex<crate::application::runtime::RuntimeGuard>>,
    restart_backoffs: (u64, u64),
) -> Result<RuntimeHandles, CompositionError> {
    // 刀 2 (pipeline design): the shared event bus carries
    // pipeline facts; the config reconciler subscribes and reacts to a
    // changed subscription refresh by re-rendering the kernel config. The
    // config mailbox is cloned before the dispatcher takes ownership of the
    // fanout below.
    let fanout = channels.fanout;
    let result_receiver = channels.result_receiver;
    let config_mailbox = fanout.config.clone();
    let event_bus = crate::application::events::EventBus::new();
    // CLI sinking (2026-08-14): the publisher recomputes `sub list` from
    // the daemon projection after a refresh or config mutation. It is a
    // best-effort thread (not a fatal task): a projection hiccup must not
    // take the daemon down.
    super::source_listing_publisher::spawn(event_bus.clone(), service.clone());
    spawn_dispatcher(
        tasks,
        service,
        command_receiver,
        fanout,
        result_receiver,
        cancellation.clone(),
        runtime_guard,
    )?;
    super::handlers::spawn_exit_monitor(
        tasks,
        lifecycle_backend.clone(),
        channels.result_client.clone(),
        cancellation.clone(),
        restart_backoffs.0,
        restart_backoffs.1,
    )?;
    // Explicit publish→subscribe contract replacing the ad-hoc hook:
    // `SubscriptionRefreshed { changed: true }` → `ReloadConfig`, and the
    // selection reconciler follows node renames by stable id (刀 3).
    crate::application::reconciler::ConfigReconciler::spawn(event_bus.clone(), config_mailbox);
    super::selection_reconciler::spawn(
        event_bus.clone(),
        registry,
        lifecycle_backend.active_cell(),
    );
    super::handlers::spawn_handlers(
        tasks,
        super::handlers::HandlerReceivers {
            core_lifecycle: channels.core_lifecycle_receiver,
            config: channels.config_receiver,
            core: channels.core_receiver,
            subscription: channels.subscription_receiver,
            platform: channels.platform_receiver,
            config_mutation: channels.config_mutation_receiver,
        },
        cancellation.clone(),
        channels.result_client.clone(),
        core_backend,
        subscription_backend,
        platform_backend,
        tun_backend,
        lifecycle_backend.clone(),
        config_backend,
        lifecycle_backend.active_cell(),
        event_bus,
        crate::backends::ConfigMutationBackendImpl::from_env(),
    )?;
    super::handlers::spawn_supervision(
        tasks,
        channels.telemetry_receiver,
        channels.telemetry_ingress.clone(),
        lifecycle_handle,
        channels.result_client.clone(),
        configured_core,
        controller_secret,
        controllers,
        telemetry_interval,
        cancellation,
    )?;
    Ok(RuntimeHandles {
        result_client: channels.result_client,
        telemetry_ingress: channels.telemetry_ingress,
    })
}
