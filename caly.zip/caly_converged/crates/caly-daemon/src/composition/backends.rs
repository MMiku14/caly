use std::path::PathBuf;

use crate::backends::{HttpSubscriptionBackend, LinuxSystemProxyBackend};
use crate::platform::paths::AppPaths;

use super::CompositionError;

mod lifecycle;
mod lifecycle_support;

/// Bounds a controller secret for the core control clients. A generated hex
/// secret always fits; the clamped constructor keeps this infallible.
fn bounded_text(value: &str) -> caly_core::domain::BoundedText<4_096> {
    caly_core::domain::BoundedText::from_nonempty_clamped(value.to_owned(), "invalid")
}

/// Builds both core command adapters (Mihomo + sing-box) sharing one node
/// registry, so a runtime core switch keeps the subscription index intact.
fn build_dual_core_backend(
    controllers: &caly_core::domain::Controllers,
    secret: &str,
    active_cell: crate::backends::dual::SharedActiveCore,
) -> Result<
    (
        crate::backends::dual::SwitchableCoreBackend,
        crate::backends::CoreNodeRegistry,
    ),
    CompositionError,
> {
    let secret_text = bounded_text(secret);
    let mihomo_control = caly_kernel::corectl::mihomo::MihomoHttpControl::new(
        controllers.mihomo.clone(),
        Some(secret_text.clone()),
    )
    .map_err(|error| {
        tracing::error!(%error, "cannot build the Mihomo control client");
        CompositionError::BackendUnavailable
    })?;
    let mihomo = crate::backends::MihomoCoreBackend::new(mihomo_control);
    let registry = mihomo.registry();
    let sing_box_control = caly_kernel::corectl::sing_box::SingBoxHttpControl::new(
        controllers.sing_box.clone(),
        Some(secret_text),
    )
    .map_err(|error| {
        tracing::error!(%error, "cannot build the sing-box control client");
        CompositionError::BackendUnavailable
    })?;
    let sing_box =
        crate::backends::SingBoxCoreBackend::new_with_registry(sing_box_control, registry.clone());
    // Bug ⑪: the rendered configs' mode fields stay synced in place on
    // `set_mode`, so starts between renders land on the current mode.
    let paths = AppPaths::from_env();
    Ok((
        crate::backends::dual::SwitchableCoreBackend::new(mihomo, sing_box, active_cell)
            .with_config_paths(
                paths.config.join("mihomo.yaml"),
                paths.config.join("sing-box.json"),
            ),
        registry,
    ))
}

pub(crate) struct RuntimeBackends {
    pub(crate) core: crate::backends::dual::SwitchableCoreBackend,
    pub(crate) subscription: HttpSubscriptionBackend,
    pub(crate) config: crate::backends::config::ActiveConfigBackend,
    pub(crate) platform:
        crate::backends::platform::DurableSystemProxyBackend<LinuxSystemProxyBackend>,
    pub(crate) tun:
        crate::backends::platform::DurableTunBackend<crate::backends::LinuxTunCommandBackend>,
    pub(crate) lifecycle: crate::backends::dual::DualCoreLifecycle,
    /// Shared node registry (node_id → registered proxy), consumed by the
    /// selection reconciler to follow renames after subscription refreshes.
    pub(crate) registry: crate::backends::CoreNodeRegistry,
    /// Shared controller auth secret, also used by the telemetry control client.
    pub(crate) controller_secret: Option<String>,
}

pub(super) fn build_runtime_backends(
    configured_core: caly_core::domain::CoreKind,
    tun: Option<caly_core::domain::TunConfig>,
    controllers: &caly_core::domain::Controllers,
    binaries: &super::CoreBinaryPaths,
    subscription_urls: &[String],
    tuning: &super::RuntimeTuning,
) -> Result<RuntimeBackends, CompositionError> {
    // A shared, fail-closed controller auth secret. It is embedded in the core
    // config and sent by the control clients; it is never part of the
    // projection or any PresentationSnapshot.
    let secret = crate::platform::secrets::generate_secret_hex().map_err(|error| {
        tracing::error!(%error, "cannot generate the controller auth secret");
        CompositionError::SecretUnavailable
    })?;
    // The active-core cell is created here and shared by the lifecycle,
    // command and telemetry adapters so a runtime switch is atomic everywhere.
    let active_cell: crate::backends::dual::SharedActiveCore =
        std::sync::Arc::new(std::sync::Mutex::new(configured_core));
    let (core, registry) = build_dual_core_backend(controllers, &secret, active_cell.clone())
        .inspect_err(|error| tracing::error!("build_dual_core_backend failed: {error}"))?;
    // Subscription-author routing surface (规划): populated by
    // subscription refresh alongside the node registry, consumed by the
    // mihomo config backend so author-declared groups render verbatim.
    let routing = crate::backends::shared_routing_registry();
    let mut subscription = HttpSubscriptionBackend::new()
        .inspect_err(|error| tracing::error!("subscription backend failed: {error}"))
        .map_err(|_| CompositionError::BackendUnavailable)?
        .with_policy(tuning.fetch_policy)
        // Persist fetched bodies so the node registry survives a daemon
        // restart without a re-fetch; restored in `start_runtime`.
        .with_cache_dir(AppPaths::from_env().state.join("subscriptions"))
        .with_node_registry(registry.clone())
        .with_routing_registry(routing.clone());
    register_subscription_urls(&mut subscription, subscription_urls);
    let proxy_backend =
        LinuxSystemProxyBackend::new(tuning.system_proxy_host.clone(), tuning.system_proxy_port)
            .map_err(|error| {
                tracing::error!(%error, "cannot build the Linux system-proxy backend");
                CompositionError::BackendUnavailable
            })?;
    let proxy_store = open_recovery_store()
        .inspect_err(|error| tracing::error!("proxy recovery store failed: {error}"))?;
    let platform =
        crate::backends::platform::DurableSystemProxyBackend::new(proxy_backend, proxy_store);
    let lifecycle = lifecycle::build_dual_core_lifecycle(
        &mut subscription,
        configured_core,
        Some(secret.clone()),
        controllers,
        binaries,
        tuning,
        tun.clone(),
        active_cell.clone(),
    )?;
    let config = build_config_owner(
        registry.clone(),
        routing,
        active_cell.clone(),
        configured_core,
        tun.clone(),
        binaries,
        tuning,
        controllers,
        &secret,
    )?;
    let tun = build_tun_owner(tun, open_tun_recovery_store()?, tuning.tun_escalation)?;
    Ok(RuntimeBackends {
        core,
        subscription,
        config,
        platform,
        tun,
        lifecycle,
        registry,
        controller_secret: Some(secret),
    })
}

/// Builds the durable TunActor owner with the configured MTU (or a safe default).
fn build_tun_owner(
    tun: Option<caly_core::domain::TunConfig>,
    store: crate::backends::platform::SharedTunRecoveryStore,
    escalation: crate::platform::tun::TunEscalation,
) -> Result<
    crate::backends::platform::DurableTunBackend<crate::backends::LinuxTunCommandBackend>,
    CompositionError,
> {
    let mtu = tun.map_or(1_500, |tun| tun.mtu());
    let interface = crate::platform::tun::InterfaceName::new(lifecycle::TUN_INTERFACE.to_owned())
        .map_err(|error| {
            tracing::error!(%error, "cannot validate the TUN interface name");
            CompositionError::BackendUnavailable
        })?;
    let inner =
        crate::backends::LinuxTunCommandBackend::new_with_escalation(interface, mtu, escalation)
            .map_err(|error| {
                tracing::error!(%error, mtu, "cannot build the Linux TUN backend");
                CompositionError::BackendUnavailable
            })?;
    Ok(crate::backends::platform::DurableTunBackend::new(
        inner, store,
    ))
}

/// Opens the owner-only durable TUN recovery store under the XDG state root.
fn open_tun_recovery_store()
-> Result<crate::backends::platform::SharedTunRecoveryStore, CompositionError> {
    use crate::platform::recovery::{FileRecoveryStore, TunRecoveryRecord};
    let path = crate::platform::paths::AppPaths::from_env().tun_recovery_record_path();
    let store = FileRecoveryStore::<TunRecoveryRecord>::new(path).map_err(|error| {
        tracing::error!(%error, "cannot open the TUN recovery store");
        CompositionError::BackendUnavailable
    })?;
    Ok(std::sync::Arc::new(store) as crate::backends::platform::SharedTunRecoveryStore)
}

/// Opens the owner-only durable proxy recovery store under the XDG state root.
fn open_recovery_store()
-> Result<crate::backends::platform::SharedProxyRecoveryStore, CompositionError> {
    use crate::platform::recovery::FileRecoveryStore;
    let path = crate::platform::paths::AppPaths::from_env().recovery_record_path();
    let store = FileRecoveryStore::<crate::platform::recovery::ProxyRecoveryRecord>::new(path)
        .map_err(|error| {
            tracing::error!(%error, "cannot open the system-proxy recovery store");
            CompositionError::BackendUnavailable
        })?;
    Ok(std::sync::Arc::new(store) as crate::backends::platform::SharedProxyRecoveryStore)
}

/// Registers a configured source URL for the default `refresh` subscription.
fn register_subscription_urls(subscription: &mut HttpSubscriptionBackend, urls: &[String]) {
    for url in urls {
        let id = crate::backends::subscription::subscription_id_for_url(url);
        subscription.put_url(id, url.clone());
        // The declared id set gates cache restore: only live (declared)
        // subscriptions revive their cached bodies at boot — ghosts are
        // skipped with a one-shot summary (user-flow audit).
        subscription.declare_id(id);
    }
}

/// Locates a bundled development core relative to the executable before using
/// the historical current-working-directory fallback. This makes
/// `target/debug/caly daemon` work regardless of the shell's current directory.
pub(super) fn bundled_binary(name: &str) -> PathBuf {
    resolve_bundled_binary(
        name,
        std::env::current_dir().ok().as_deref(),
        std::env::current_exe().ok().as_deref(),
    )
}

/// Resolves a kernel binary: an explicit config path wins, then the
/// `CALY_*_BIN` environment override, then the bundled development binary.
/// Resolves a kernel binary using hierarchical discovery:
/// 1. Explicit config path (`core_binaries.<name>`)
/// 2. Environment variable (`CALY_*_BIN`)
/// 3. Installed/upgraded version in local store (`<data>/kernels/<name>/<version>/<name>`)
/// 4. System PATH (`/usr/local/bin`, `/usr/bin`, `~/.local/bin`)
/// 5. Bundled development fallback in `vendor/bin/<name>`
pub(super) fn kernel_binary(explicit: Option<PathBuf>, env_var: &str, name: &str) -> PathBuf {
    if let Some(path) = explicit {
        return path;
    }
    if let Some(env_path) = std::env::var_os(env_var).map(PathBuf::from) {
        return env_path;
    }
    let paths = crate::platform::paths::AppPaths::from_env();
    if let Some(installed) = find_highest_installed_kernel(&paths.data, name) {
        return installed;
    }
    if let Some(sys_bin) = find_in_system_path(name) {
        return sys_bin;
    }
    bundled_binary(name)
}

/// Scans `<data>/kernels/<name>/` for the highest installed version from `core install`/`core upgrade`.
fn find_highest_installed_kernel(data_dir: &std::path::Path, name: &str) -> Option<PathBuf> {
    let kernel_dir = data_dir.join("kernels").join(name);
    let mut versions: Vec<String> = std::fs::read_dir(&kernel_dir)
        .ok()?
        .filter_map(|entry| entry.ok())
        .filter(|entry| entry.file_type().map_or(false, |t| t.is_dir()))
        .filter_map(|entry| entry.file_name().into_string().ok())
        .collect();
    if versions.is_empty() {
        return None;
    }
    versions.sort();
    while let Some(ver) = versions.pop() {
        let candidate = kernel_dir.join(&ver).join(name);
        if candidate.is_file() {
            return Some(candidate);
        }
    }
    None
}

/// Looks up the executable in standard system PATH locations.
fn find_in_system_path(name: &str) -> Option<PathBuf> {
    if let Some(path_var) = std::env::var_os("PATH") {
        for dir in std::env::split_paths(&path_var) {
            let candidate = dir.join(name);
            if candidate.is_file() {
                return Some(candidate);
            }
        }
    }
    for dir in ["/usr/local/bin", "/usr/bin", "/bin"] {
        let candidate = PathBuf::from(dir).join(name);
        if candidate.is_file() {
            return Some(candidate);
        }
    }
    None
}

pub(super) fn resolve_bundled_binary(
    name: &str,
    cwd: Option<&std::path::Path>,
    executable: Option<&std::path::Path>,
) -> PathBuf {
    if let Some(directory) = cwd {
        let candidate = directory.join("vendor").join("bin").join(name);
        if candidate.is_file() {
            return candidate;
        }
    }
    if let Some(executable) = executable {
        for directory in executable.ancestors() {
            let candidate = directory.join("vendor").join("bin").join(name);
            if candidate.is_file() {
                return candidate;
            }
        }
    }
    PathBuf::from("vendor").join("bin").join(name)
}

/// Builds the config-apply owner under the XDG config root. It shares the
/// subscription proxy registry and validates every candidate against the
/// configured core's real binary before committing; the active backend is
/// selected by the configured core (sing-box is no longer a fail-fast).
fn build_config_owner(
    registry: crate::backends::CoreNodeRegistry,
    routing: crate::backends::CoreRoutingRegistry,
    active: crate::backends::dual::SharedActiveCore,
    configured_core: caly_core::domain::CoreKind,
    tun: Option<caly_core::domain::TunConfig>,
    binaries: &super::CoreBinaryPaths,
    tuning: &super::RuntimeTuning,
    controllers: &caly_core::domain::Controllers,
    secret: &str,
) -> Result<crate::backends::config::ActiveConfigBackend, CompositionError> {
    let paths = crate::platform::paths::AppPaths::from_env();
    // Mihomo does not understand caly's inline rule-provider payload key, so
    // the config-apply owner receives the same materialised file providers
    // the lifecycle renderer uses (`<workdir>/rule-providers/<name>.yaml`).
    // sing-box consumes inline rule-sets natively and keeps the original
    // inline providers.
    let mihomo_work = std::env::var_os("CALY_MIHOMO_DIR")
        .map_or_else(|| paths.core_work_dir().join("mihomo"), PathBuf::from);
    let (mihomo_rule_providers, _) =
        crate::rule_provider_materialize::materialize_inline_providers(
            &mihomo_work,
            &tuning.rule_providers,
        )
        .inspect_err(|error| {
            tracing::error!(%error, "inline rule provider materialization failed");
        })
        .map_err(|_| CompositionError::BackendUnavailable)?;
    let mihomo_port = controllers
        .mihomo
        .parse::<std::net::SocketAddr>()
        .map_or(9090, |address| address.port());
    let mut mihomo = crate::backends::MihomoConfigBackend::new(paths.config.join("mihomo.yaml"))
        .with_registry(registry.clone())
        .with_routing(routing.clone())
        .with_tun(tun.clone())
        .with_kernel(
            tuning.mixed_port,
            tuning.allow_lan,
            tuning.bind_address.clone(),
            tuning.log_level.clone(),
            mihomo_port,
            tuning.dns.clone(),
        )
        .with_secret(Some(secret.to_owned()))
        .with_rules(tuning.rules.clone())
        .with_rule_providers(mihomo_rule_providers)
        .with_declared_groups(tuning.declared_groups.clone())
        .with_transparent(tuning.transparent)
        .with_sniffer(tuning.sniffer.clone());
    let sing_box_port = controllers
        .sing_box
        .parse::<std::net::SocketAddr>()
        .map_or(9091, |address| address.port());
    let mut sing_box = crate::backends::config::sing_box::SingBoxConfigBackend::new(
        paths.config.join("sing-box.json"),
    )
    .with_registry(registry)
    .with_routing(routing)
    .with_tun(tun)
    .with_kernel(
        tuning.mixed_port,
        tuning.allow_lan,
        tuning.bind_address.clone(),
        tuning.log_level.clone(),
        sing_box_port,
        tuning.dns.clone(),
    )
    .with_secret(Some(secret.to_owned()))
    .with_rules(tuning.rules.clone())
    .with_rule_providers(tuning.rule_providers.clone())
    .with_declared_groups(tuning.declared_groups.clone())
    .with_sniffer(tuning.sniffer.clone());
    if configured_core == caly_core::domain::CoreKind::Mihomo {
        let binary = kernel_binary(binaries.mihomo.clone(), "CALY_MIHOMO_BIN", "mihomo");
        // Best-effort: seed the kind data a `mihomo -t` may need (the
        // geodata store, else a known-good system database) so the
        // validator never attempts a network download that can hang past
        // its timeout. Missing or unusable sources are skipped silently —
        // validation still proceeds.
        provision_geodata(&mihomo_work);
        mihomo = mihomo.with_validation(binary, mihomo_work, std::time::Duration::from_secs(10));
    } else {
        let binary = kernel_binary(binaries.sing_box.clone(), "CALY_SINGBOX_BIN", "sing-box");
        let working_directory = std::env::var_os("CALY_SINGBOX_DIR")
            .map_or_else(|| paths.core_work_dir().join("sing-box"), PathBuf::from);
        sing_box = sing_box.with_validation(
            binary,
            working_directory,
            std::time::Duration::from_secs(10),
        );
    }
    Ok(crate::backends::config::ActiveConfigBackend::new(
        active, mihomo, sing_box,
    ))
}

/// Best-effort seed of a usable `geoip.metadb` into the Mihomo working
/// directory so a validated config referencing GEOIP data does not hang on
/// a network fetch (a blocked network can stall past the bounded validator
/// timeout). Every failure is silently ignored, falling back to Mihomo's own
/// behavior; a pre-existing target smaller than the 1 MiB sanity bound (a
/// stub or an aborted copy) is removed before the copy so it cannot
/// masquerade as a healthy database.
fn provision_geoip_metadb(working_directory: &std::path::Path) -> bool {
    provision_geoip_metadb_with_sources(working_directory, default_geoip_sources())
}

/// Default source list: a system Mihomo database is preferred (verified,
/// complete) over the shared caly cache from earlier test downloads.
fn default_geoip_sources() -> [std::path::PathBuf; 2] {
    [
        std::path::PathBuf::from("/etc/mihomo/geoip.metadb"),
        std::env::temp_dir().join("caly-geoip-cache/geoip.metadb"),
    ]
}

/// The testable core of `provision_geoip_metadb`. Accepts an explicit source
/// list so tests can exercise every branch without depending on whatever
/// `/etc/mihomo/geoip.metadb` happens to exist in the test environment.
fn provision_geoip_metadb_with_sources<I>(working_directory: &std::path::Path, sources: I) -> bool
where
    I: IntoIterator,
    I::Item: AsRef<std::path::Path>,
{
    let target = working_directory.join("geoip.metadb");
    if let Ok(meta) = target.metadata() {
        if meta.len() >= 1_000_000 {
            return true;
        }
        // Corrupt/stub target: never reuse it, even though `is_file()` would
        // otherwise short-circuit the copy loop below. A partial file from an
        // interrupted earlier run would otherwise block the seed indefinitely.
        let _ = std::fs::remove_file(&target);
    }
    if let Err(error) = std::fs::create_dir_all(working_directory) {
        // Seeding cannot proceed without the workdir; report loudly instead
        // of silently continuing into a guaranteed-failing copy loop.
        tracing::warn!(
            "geoip.metadb provisioning skipped: cannot create {}: {error}",
            working_directory.display()
        );
        return false;
    }
    for source in sources {
        let source = source.as_ref();
        let Ok(meta) = source.metadata() else {
            continue;
        };
        // A stub (sub-1 MiB) copy is corrupt; never reuse it.
        if meta.len() < 1_000_000 {
            continue;
        }
        if std::fs::copy(source, &target).is_ok()
            && target.metadata().map_or(0, |m| m.len()) >= 1_000_000
        {
            return true;
        }
        let _ = std::fs::remove_file(&target);
    }
    false
}

/// Store→workdir geodata rows: `(store name, mihomo workdir name)`.
/// Mirrors `caly-ops`' `kernels::geo::GEO_ASSETS` (composition must not
/// depend on caly-ops; the two tables stay in sync by review).
const GEODATA_SEED_FILES: &[(&str, &str)] = &[
    ("geoip.dat", "GeoIP.dat"),
    ("geosite.dat", "GeoSite.dat"),
    ("geoip.metadb", "geoip.metadb"),
];

/// Minimum plausible database size: a smaller file is a stub or an
/// aborted copy and must never be seeded (same bound as the metadb
/// fallback below; every real database is several MiB).
const GEODATA_MIN_BYTES: u64 = 1_000_000;

/// Seeds the ephemeral mihomo work dir from the durable `<data>/geo`
/// store (`caly core upgrade` refreshes it). Runs at daemon boot (the
/// mihomo lifecycle builder) and before config validation (the config
/// owner); best-effort throughout — when files are absent mihomo falls
/// back to its own download behavior.
pub(super) fn provision_geodata(working_directory: &std::path::Path) {
    let store = crate::platform::paths::AppPaths::from_env().data.join("geo");
    provision_geodata_with_store(working_directory, &store);
}

/// The testable core of [`provision_geodata`]: an explicit store path
/// keeps tests hermetic (no dependence on the ambient data dir).
fn provision_geodata_with_store(working_directory: &std::path::Path, store: &std::path::Path) {
    for (name, work_name) in GEODATA_SEED_FILES {
        seed_geodata_file(working_directory, &store.join(name), work_name);
    }
    // Legacy fallback: a system metadb (or the shared test cache) still
    // rescues validation when the store holds no metadb yet. Returns
    // immediately when the store seed above already landed.
    provision_geoip_metadb(working_directory);
}

/// Copies one store file to its workdir name; skips silently when the
/// source is missing or a stub. The store is the source of truth, so a
/// present source always overwrites (a daemon restart reusing a runtime
/// dir picks up a refreshed store this way).
fn seed_geodata_file(
    working_directory: &std::path::Path,
    source: &std::path::Path,
    work_name: &str,
) {
    let Ok(meta) = source.metadata() else {
        return;
    };
    if meta.len() < GEODATA_MIN_BYTES {
        return;
    }
    if std::fs::create_dir_all(working_directory).is_err() {
        return;
    }
    let target = working_directory.join(work_name);
    if std::fs::copy(source, &target).is_err() {
        let _ = std::fs::remove_file(&target);
        return;
    }
    if target.metadata().map_or(0, |meta| meta.len()) < GEODATA_MIN_BYTES {
        let _ = std::fs::remove_file(&target);
    }
}

#[cfg(test)]
mod tests;

#[cfg(test)]
mod bundled_binary_tests;

#[cfg(test)]
mod provision_geoip_tests;
