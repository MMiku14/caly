//! Concrete single-owner Application service facade.


use caly_core::domain::{
    EventCursor, OperationFailure, OperationFailureCode, OperationId, OperationState,
    OperationStatus, PresentationSnapshot,
};

use crate::{
    command_bus::CommandEnvelope,
    events::SequencedEvent,
    operations::{AdmissionController, AdmissionError, StoreError, TimeSource},
    routing::{CommandSink, RouteDispatchError, route},
    service::{
        ApplicationServiceError, ApplicationServicePort, ApplicationWatch, CancellationResult,
        CommandSupportPolicy, SharedLiveConnectionQuery,
    },
};

/// Projection/replay reader owned by the runtime thread.
pub trait ProjectionService {
    fn snapshot(&self) -> Result<PresentationSnapshot, ApplicationServiceError>;
    fn watch_after(
        &self,
        cursor: Option<EventCursor>,
    ) -> Result<ApplicationWatch, ApplicationServiceError>;
    /// Subscribes to live projection events after the current position.
    fn subscribe_live(&self) -> tokio::sync::broadcast::Receiver<SequencedEvent>;
}

/// Serial facade joining atomic mutation admission with read projection.
pub struct RuntimeService<T, P> {
    admission: AdmissionController<T>,
    projection: P,
    command_support: CommandSupportPolicy,
    live_connections: Option<SharedLiveConnectionQuery>,
}

impl<T, P> RuntimeService<T, P> {
    /// Creates a service with all commands enabled. This constructor is kept
    /// for isolated tests/embedders that supply every owner; daemon composition
    /// must use `new_with_policy`.
    pub const fn new(admission: AdmissionController<T>, projection: P) -> Self {
        Self::new_with_policy(admission, projection, CommandSupportPolicy::All)
    }

    /// Creates a service with an explicit admission-time command surface.
    pub const fn new_with_policy(
        admission: AdmissionController<T>,
        projection: P,
        command_support: CommandSupportPolicy,
    ) -> Self {
        Self {
            admission,
            projection,
            command_support,
            live_connections: None,
        }
    }

    /// Executor/actor owner uses this path for legal operation transitions.
    pub const fn admission_mut(&mut self) -> &mut AdmissionController<T> {
        &mut self.admission
    }

    pub const fn projection_mut(&mut self) -> &mut P {
        &mut self.projection
    }

    /// Installs the shared live kernel query owner. The composition root
    /// calls this after controller construction; until then live connection
    /// reads fail as [`ApplicationServiceError::Unavailable`].
    pub fn set_live_connection_query(&mut self, query: SharedLiveConnectionQuery) {
        self.live_connections = Some(query);
    }
}

/// One bounded command-dispatch cycle result.
pub enum DispatchOutcome {
    Idle,
    IngressClosed,
    /// The operation was cancelled while Pending; its queued envelope was
    /// consumed without reaching an owner actor.
    CancelledBeforeDispatch(OperationStatus),
    Dispatched(OperationStatus),
    Rejected {
        status: OperationStatus,
        reason: DispatchRejectReason,
    },
}

#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub enum DispatchRejectReason {
    ResourceExhausted,
    TargetClosed,
}

#[derive(Debug)]
pub enum RuntimeDispatchError {
    InvalidTimeout,
    Admission(AdmissionError),
}

impl core::fmt::Display for RuntimeDispatchError {
    fn fmt(&self, formatter: &mut core::fmt::Formatter<'_>) -> core::fmt::Result {
        match self {
            Self::InvalidTimeout => formatter.write_str("runtime dispatch timeout is invalid"),
            Self::Admission(error) => write!(formatter, "runtime dispatch failed: {error}"),
        }
    }
}

impl std::error::Error for RuntimeDispatchError {}

impl<T: TimeSource, P> RuntimeService<T, P> {
    /// Starts an admitted operation, then routes it to one bounded owner mailbox.
    /// Dispatches one already-received envelope to its owner actor.
    ///
    /// Lock discipline: the caller receives the envelope WITHOUT the
    /// service lock ([`crate::command_bus::CommandReceiver::receive_timeout`])
    /// and locks only for this call, which never blocks. Receiving
    /// under the lock used to gate every transport read (snapshot,
    /// status, …) behind the 100 ms poll budget — and behind every
    /// other waiter ahead of it — so idle RPCs took seconds.
    /// The dispatch loop is the sole mailbox consumer, so no envelope
    /// is lost or double-dispatched between the two steps.
    pub fn dispatch_envelope(
        &mut self,
        envelope: CommandEnvelope,
        sink: &mut impl CommandSink,
    ) -> Result<DispatchOutcome, RuntimeDispatchError> {
        let current = self
            .admission
            .status(envelope.operation_id)
            .map_err(RuntimeDispatchError::Admission)?;
        if current.state() == OperationState::Cancelled {
            // Cancellation won the single-owner race while this envelope was
            // still queued. Consume it without starting or dispatching work.
            return Ok(DispatchOutcome::CancelledBeforeDispatch(current));
        }
        let operation_cancellation = self
            .admission
            .cancellation_token(envelope.operation_id)
            .map_err(RuntimeDispatchError::Admission)?;
        let running = self
            .admission
            .start(envelope.operation_id)
            .map_err(RuntimeDispatchError::Admission)?;
        let operation_id = envelope.operation_id;
        match sink.try_dispatch(route(envelope, operation_cancellation)) {
            Ok(()) => Ok(DispatchOutcome::Dispatched(running)),
            Err(error) => self.reject_dispatch(operation_id, error),
        }
    }

    fn reject_dispatch(
        &mut self,
        operation_id: OperationId,
        error: RouteDispatchError,
    ) -> Result<DispatchOutcome, RuntimeDispatchError> {
        let (reason, failure) = match error {
            RouteDispatchError::ResourceExhausted(_) => (
                DispatchRejectReason::ResourceExhausted,
                dispatch_failure(
                    OperationFailureCode::ResourceExhausted,
                    "target mailbox is full",
                    "query this operation, then retry later with a new operation id",
                ),
            ),
            RouteDispatchError::TargetClosed(_) => (
                DispatchRejectReason::TargetClosed,
                dispatch_failure(
                    OperationFailureCode::Infrastructure,
                    "target actor is closed",
                    "restart or reconnect to the daemon",
                ),
            ),
        };
        let status = self
            .admission
            .fail(operation_id, failure)
            .map_err(RuntimeDispatchError::Admission)?;
        Ok(DispatchOutcome::Rejected { status, reason })
    }
}

fn dispatch_failure(
    code: OperationFailureCode,
    message: &'static str,
    action: &'static str,
) -> OperationFailure {
    // Static literals, well within the bounded capacities; the infallible
    // `clamped` constructor replaces the old `BoundedText::new(...)?`
    // daemon-fatal early return (an unapplied dispatch would leave the
    // operation Started-not-Failed until the next cancel).
    OperationFailure::clamped(code, message, action)
}

impl<T, P> ApplicationServicePort for RuntimeService<T, P>
where
    T: TimeSource,
    P: ProjectionService,
{
    fn submit(
        &mut self,
        envelope: CommandEnvelope,
    ) -> Result<caly_core::domain::OperationStatus, ApplicationServiceError> {
        // Reject contract-only commands before reserving an Operation or
        // enqueueing work. A rejected command therefore cannot become a
        // permanently Running operation or reach an incompatible actor.
        self.command_support.validate(envelope.command.clone())?;
        self.admission.submit(envelope).map_err(map_admission)
    }

    fn cancel(
        &mut self,
        operation_id: OperationId,
    ) -> Result<CancellationResult, ApplicationServiceError> {
        let (decision, status) = self.admission.cancel(operation_id).map_err(map_admission)?;
        Ok(CancellationResult { decision, status })
    }

    fn operation_status(
        &self,
        operation_id: OperationId,
    ) -> Result<caly_core::domain::OperationStatus, ApplicationServiceError> {
        self.admission.status(operation_id).map_err(map_admission)
    }

    fn list_operations(&self) -> Result<caly_core::domain::OperationList, ApplicationServiceError> {
        Ok(self
            .admission
            .recent_operations(caly_core::domain::MAX_OPERATION_LIST))
    }

    fn live_connections(
        &self,
    ) -> Result<Vec<caly_core::domain::LiveConnection>, ApplicationServiceError> {
        let Some(query) = &self.live_connections else {
            return Err(ApplicationServiceError::Unavailable);
        };
        query
            .lock()
            .map_err(|_| ApplicationServiceError::InternalInvariant)?
            .connection_details(std::time::Duration::from_secs(2))
            .map_err(|_| ApplicationServiceError::InternalInvariant)
    }

    fn snapshot(&self) -> Result<PresentationSnapshot, ApplicationServiceError> {
        self.projection.snapshot()
    }

    fn watch_after(
        &self,
        cursor: Option<EventCursor>,
    ) -> Result<ApplicationWatch, ApplicationServiceError> {
        self.projection.watch_after(cursor)
    }

    fn subscribe_live(&self) -> tokio::sync::broadcast::Receiver<SequencedEvent> {
        self.projection.subscribe_live()
    }
}

fn map_admission(error: AdmissionError) -> ApplicationServiceError {
    match error {
        AdmissionError::Store(StoreError::ResourceExhausted) | AdmissionError::Queue(_) => {
            ApplicationServiceError::ResourceExhausted
        }
        AdmissionError::Store(StoreError::NotFound) => ApplicationServiceError::OperationNotFound,
        AdmissionError::Store(StoreError::IdempotencyConflict) => {
            ApplicationServiceError::IdempotencyConflict
        }
        AdmissionError::QueueRollback { .. }
        | AdmissionError::Store(_)
        | AdmissionError::InvalidKind(_)
        | AdmissionError::Status(_) => ApplicationServiceError::InternalInvariant,
    }
}

#[cfg(test)]
mod runtime_service_tests {
use super::*;
use std::time::Duration;
use crate::{
    command_bus::{Command, CommandReceiveError, command_bus},
    events::SequencedEvent,
    operations::{CancelDecision, OperationStore},
    routing::{CommandSink, RouteDispatchError, RoutedCommand},
};
use caly_core::domain::{LiveConnection, OperationId, OperationState};
use crate::test_support::Clock;
use caly_core::ports::{ActorFailure, LiveConnectionQuery};

struct FullSink;
impl CommandSink for FullSink {
    fn try_dispatch(&mut self, command: RoutedCommand) -> Result<(), RouteDispatchError> {
        Err(RouteDispatchError::ResourceExhausted(command))
    }
}

#[derive(Default)]
struct CaptureSink(Option<RoutedCommand>);
impl CommandSink for CaptureSink {
    fn try_dispatch(&mut self, command: RoutedCommand) -> Result<(), RouteDispatchError> {
        self.0 = Some(command);
        Ok(())
    }
}

struct TestProjection;
impl ProjectionService for TestProjection {
    fn snapshot(&self) -> Result<PresentationSnapshot, ApplicationServiceError> {
        Err(ApplicationServiceError::Unavailable)
    }

    fn watch_after(
        &self,
        _cursor: Option<EventCursor>,
    ) -> Result<ApplicationWatch, ApplicationServiceError> {
        Err(ApplicationServiceError::Unavailable)
    }

    fn subscribe_live(&self) -> tokio::sync::broadcast::Receiver<SequencedEvent> {
        let (tx, rx) = tokio::sync::broadcast::channel(1);
        drop(tx);
        rx
    }
}

#[test]
fn list_operations_returns_recent_first_within_domain_bound()
-> Result<(), Box<dyn std::error::Error>> {
    let (ingress, _receiver) = command_bus(4)?;
    let admission = AdmissionController::new(OperationStore::new(8, 4)?, ingress, Clock(0));
    let mut service = RuntimeService::new(admission, TestProjection);
    let first = OperationId::from_bytes([1; 16]);
    let second = OperationId::from_bytes([2; 16]);
    service.submit(CommandEnvelope {
        operation_id: first,
        command: Command::SetTun { enabled: true },
    })?;
    service.submit(CommandEnvelope {
        operation_id: second,
        command: Command::SetMode {
            mode: caly_core::domain::ProxyMode::Rule,
        },
    })?;
    let operations = service.list_operations()?;
    assert_eq!(operations.len(), 2);
    assert_eq!(operations[0].id(), second);
    assert_eq!(operations[1].id(), first);
    Ok(())
}

#[test]
fn unsupported_command_is_rejected_before_operation_reservation()
-> Result<(), Box<dyn std::error::Error>> {
    let (ingress, receiver) = command_bus(2)?;
    let admission = AdmissionController::new(OperationStore::new(4, 2)?, ingress, Clock(0));
    let mut service = RuntimeService::new_with_policy(
        admission,
        TestProjection,
        CommandSupportPolicy::lifecycle_only(caly_core::domain::CoreKind::Mihomo),
    );
    let id = OperationId::from_bytes([9; 16]);
    let result = service.submit(CommandEnvelope {
        operation_id: id,
        command: Command::SetTun { enabled: true },
    });
    assert!(matches!(
        result,
        Err(ApplicationServiceError::InvalidCommand(_))
    ));
    assert!(matches!(
        service.operation_status(id),
        Err(ApplicationServiceError::OperationNotFound)
    ));
    assert_eq!(
        receiver.receive_timeout(Duration::from_millis(1)),
        Err(CommandReceiveError::TimedOut)
    );
    Ok(())
}

#[test]
fn dispatcher_token_observes_running_cancellation() -> Result<(), Box<dyn std::error::Error>> {
    let (ingress, receiver) = command_bus(2)?;
    let admission = AdmissionController::new(OperationStore::new(4, 2)?, ingress, Clock(0));
    let mut service = RuntimeService::new(admission, TestProjection);
    let id = OperationId::from_bytes([6; 16]);
    service.submit(CommandEnvelope {
        operation_id: id,
        command: Command::SetTun { enabled: true },
    })?;
    let expected = service.admission_mut().cancellation_token(id)?;
    let mut sink = CaptureSink::default();
    let envelope = receiver
        .receive_timeout(Duration::from_millis(1))
        .map_err(|_| "receive failed")?;
    let outcome = service.dispatch_envelope(envelope, &mut sink)?;
    assert!(matches!(outcome, DispatchOutcome::Dispatched(_)));
    let routed = sink.0.ok_or("routed command missing")?;
    assert_eq!(routed.cancellation, expected);
    assert!(!routed.cancellation.is_cancel_requested());
    let cancelled = service.cancel(id)?;
    assert_eq!(cancelled.decision, CancelDecision::Cancelled);
    assert_eq!(cancelled.status.state(), OperationState::Cancelled);
    assert!(routed.cancellation.is_cancel_requested());
    Ok(())
}

#[test]
fn pending_cancel_consumes_envelope_without_dispatch() -> Result<(), Box<dyn std::error::Error>> {
    let (ingress, receiver) = command_bus(2)?;
    let admission = AdmissionController::new(OperationStore::new(4, 2)?, ingress, Clock(0));
    let mut service = RuntimeService::new(admission, TestProjection);
    let id = OperationId::from_bytes([8; 16]);
    service.submit(CommandEnvelope {
        operation_id: id,
        command: Command::SetTun { enabled: true },
    })?;
    let cancelled = service.cancel(id)?;
    assert_eq!(cancelled.decision, CancelDecision::Cancelled);
    assert_eq!(cancelled.status.state(), OperationState::Cancelled);

    let envelope = receiver
        .receive_timeout(Duration::from_millis(1))
        .map_err(|_| "receive failed")?;
    let outcome = service.dispatch_envelope(envelope, &mut FullSink)?;
    assert!(matches!(
        outcome,
        DispatchOutcome::CancelledBeforeDispatch(ref status)
            if status.state() == OperationState::Cancelled
    ));
    assert_eq!(
        service.operation_status(id)?.state(),
        OperationState::Cancelled
    );
    Ok(())
}

#[test]
fn target_backpressure_finishes_operation_as_failed() -> Result<(), Box<dyn std::error::Error>> {
    let (ingress, receiver) = command_bus(2)?;
    let admission = AdmissionController::new(OperationStore::new(4, 2)?, ingress, Clock(0));
    let mut service = RuntimeService::new(admission, ());
    let id = OperationId::from_bytes([1; 16]);
    service.admission_mut().submit(CommandEnvelope {
        operation_id: id,
        command: Command::SetTun { enabled: true },
    })?;
    let envelope = receiver
        .receive_timeout(Duration::from_millis(1))
        .map_err(|_| "receive failed")?;
    let outcome = service.dispatch_envelope(envelope, &mut FullSink)?;
    assert!(matches!(outcome, DispatchOutcome::Rejected {
            ref status,
            reason: DispatchRejectReason::ResourceExhausted,
        } if status.state() == OperationState::Failed));
    Ok(())
}

struct StubConnectionQuery(Vec<LiveConnection>);
impl LiveConnectionQuery for StubConnectionQuery {
    fn connection_details(
        &mut self,
        _timeout: std::time::Duration,
    ) -> Result<Vec<LiveConnection>, ActorFailure> {
        Ok(self.0.clone())
    }
}

fn canned_connection() -> LiveConnection {
    LiveConnection {
        id: "conn-1".to_owned(),
        host: "example.com".to_owned(),
        destination_port: 443,
        network: "tcp".to_owned(),
        protocol_type: "tls".to_owned(),
        inbound_name: "mixed".to_owned(),
        process_path: String::new(),
        rule: "MATCH".to_owned(),
        rule_payload: String::new(),
        outbound: "proxy".to_owned(),
        chain: vec!["PROXY".to_owned()],
        upload_bytes: 7,
        download_bytes: 11,
    }
}

#[test]
fn live_connections_without_installed_query_fails_unavailable()
-> Result<(), Box<dyn std::error::Error>> {
    let (ingress, _receiver) = command_bus(4)?;
    let admission = AdmissionController::new(OperationStore::new(8, 4)?, ingress, Clock(0));
    let service = RuntimeService::new(admission, TestProjection);
    assert!(matches!(
        service.live_connections(),
        Err(ApplicationServiceError::Unavailable)
    ));
    Ok(())
}

#[test]
fn installed_live_connection_query_serves_kernel_details()
-> Result<(), Box<dyn std::error::Error>> {
    let (ingress, _receiver) = command_bus(4)?;
    let admission = AdmissionController::new(OperationStore::new(8, 4)?, ingress, Clock(0));
    let mut service = RuntimeService::new(admission, TestProjection);
    let query: SharedLiveConnectionQuery =
        std::sync::Arc::new(std::sync::Mutex::new(StubConnectionQuery(vec![
            canned_connection(),
        ])));
    service.set_live_connection_query(query);
    let connections = service.live_connections()?;
    assert_eq!(connections.len(), 1);
    assert_eq!(connections[0].id, "conn-1");
    assert_eq!(connections[0].download_bytes, 11);
    Ok(())
}

}
