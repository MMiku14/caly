//! Shared transport facade for the daemon composition root.

use std::{
    sync::{Arc, Mutex, MutexGuard},
    time::{SystemTime, UNIX_EPOCH},
};

use caly_core::domain::{EventCursor, OperationId, OperationStatus, PresentationSnapshot, UnixMillis};

use crate::projection::ProjectionRuntime;
use crate::{
    command_bus::CommandEnvelope,
    events::SequencedEvent,
    operations::TimeSource,
    service::runtime_service::RuntimeService,
    service::{
        ApplicationServiceError, ApplicationServicePort, ApplicationWatch, CancellationResult,
    },
};

/// Locks the shared service, mapping a poisoned mutex to the facade error.
fn lock_service(
    service: &Arc<Mutex<RuntimeService<WallClock, ProjectionRuntime>>>,
) -> Result<MutexGuard<'_, RuntimeService<WallClock, ProjectionRuntime>>, ApplicationServiceError> {
    service
        .lock()
        .map_err(|_| ApplicationServiceError::InternalInvariant)
}

impl ApplicationServicePort for Arc<Mutex<RuntimeService<WallClock, ProjectionRuntime>>> {
    fn submit(
        &mut self,
        envelope: CommandEnvelope,
    ) -> Result<OperationStatus, ApplicationServiceError> {
        lock_service(self)?.submit(envelope)
    }
    fn cancel(&mut self, id: OperationId) -> Result<CancellationResult, ApplicationServiceError> {
        lock_service(self)?.cancel(id)
    }
    fn operation_status(
        &self,
        id: OperationId,
    ) -> Result<OperationStatus, ApplicationServiceError> {
        lock_service(self)?.operation_status(id)
    }
    fn list_operations(&self) -> Result<caly_core::domain::OperationList, ApplicationServiceError> {
        lock_service(self)?.list_operations()
    }
    fn live_connections(
        &self,
    ) -> Result<Vec<caly_core::domain::LiveConnection>, ApplicationServiceError> {
        lock_service(self)?.live_connections()
    }
    fn snapshot(&self) -> Result<PresentationSnapshot, ApplicationServiceError> {
        lock_service(self)?.snapshot()
    }
    fn watch_after(
        &self,
        cursor: Option<EventCursor>,
    ) -> Result<ApplicationWatch, ApplicationServiceError> {
        lock_service(self)?.watch_after(cursor)
    }
    fn subscribe_live(&self) -> tokio::sync::broadcast::Receiver<SequencedEvent> {
        let Ok(guard) = self.lock() else {
            // Poisoned service cannot publish; return a channel that yields no
            // events by creating a detached receiver.
            let (tx, rx) = tokio::sync::broadcast::channel(1);
            drop(tx);
            return rx;
        };
        guard.subscribe_live()
    }
}

// P7 composition 抽离的接缝:上面的 `ApplicationServicePort` facade impl 只能
// 落在 trait 属主 crate(`Arc` 非 fundamental,orphan 规则),具体时钟随之
// 留下;caly-composition 组装根经 `service::WallClock` 重导出取用原类型。
/// Monotonic wall clock used only by the composition root.
/// The raw system clock can step backwards (NTP correction, VM
/// suspend/resume, manual change); operation timestamps must never move
/// backwards (`OperationStatus` rejects `updated < created`, and the
/// operation list sorts by time). Each reading is therefore clamped to
/// be at least the previous one (D2 audit), so the daemon observes a
/// non-decreasing clock while staying anchored to wall time.
#[derive(Default)]
pub struct WallClock {
    last_millis: u64,
}

impl WallClock {
    /// Creates a clock that has not observed any reading yet.
    pub const fn new() -> Self {
        Self { last_millis: 0 }
    }

    /// Folds one wall reading into the monotonic state. Split from
    /// [`TimeSource::now`] so the step-back behaviour is deterministically
    /// testable without moving the system clock.
    fn observe(&mut self, wall_millis: u64) -> UnixMillis {
        let clamped = wall_millis.max(self.last_millis);
        self.last_millis = clamped;
        UnixMillis::new(clamped)
    }
}

impl TimeSource for WallClock {
    fn now(&mut self) -> UnixMillis {
        self.observe(read_wall_millis())
    }
}

fn read_wall_millis() -> u64 {
    SystemTime::now().duration_since(UNIX_EPOCH).map_or(0, |duration| {
        u64::try_from(duration.as_millis().min(u128::from(u64::MAX))).unwrap_or(u64::MAX)
    })
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn clock_back_step_never_moves_observed_time_backwards() {
        // D2 regression: a wall-clock step-back (NTP/VM/manual) must not
        // move operation timestamps backwards — `OperationStatus` rejects
        // `updated < created`, so an unclamped clock wedges operations in
        // `Running` and jitters the time-sorted operation list.
        let mut clock = WallClock::new();
        assert_eq!(clock.observe(100).value(), 100);
        assert_eq!(clock.observe(50).value(), 100);
        assert_eq!(clock.observe(100).value(), 100);
        assert_eq!(clock.observe(150).value(), 150);
    }

    #[test]
    fn successive_live_readings_are_non_decreasing() {
        let mut clock = WallClock::new();
        let first = clock.now().value();
        let second = clock.now().value();
        assert!(second >= first, "clock moved backwards: {first} -> {second}");
    }
}
