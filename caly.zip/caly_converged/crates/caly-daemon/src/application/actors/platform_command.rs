//! PlatformActor mailbox commands.

/// Platform side-effect requests; concrete snapshots stay in Infrastructure.
#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub enum PlatformActorCommand {
    EngageSystemProxy { operation: caly_core::domain::OperationId },
    RestoreSystemProxy { operation: caly_core::domain::OperationId },
    EngageTun { operation: caly_core::domain::OperationId },
    RestoreTun { operation: caly_core::domain::OperationId },
    RecoverPendingEffects,
    Shutdown,
}
