//! caly-cli — Presentation, commands, formatting layout, and client operations.

#![forbid(unsafe_code)]
#![cfg_attr(test, allow(clippy::unwrap_used, clippy::expect_used, clippy::panic, clippy::todo, clippy::unimplemented, clippy::unreachable))]

pub mod layout;
pub mod ops;
pub mod cli;

pub use cli::{grammar, run, suggest};
pub use layout::CliOutput;
pub use ops::client::ClientCommand;
