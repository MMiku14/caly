use super::*;

// ── CliOptions default works (the original SIGABRT) ────────────

#[test]
fn cli_options_default_is_constructible() {
    // Regression: CliOptions lost its Default derive during the rewrite.
    // Every parse-level test that compares against `CliOptions::default()`
    // depends on this.
    let default = CliOptions::default();
    assert!(default.socket.is_none());
    assert!(!default.json);
    assert!(default.core.is_none());
    assert!(default.mihomo_bin.is_none());
    assert!(default.sing_box_bin.is_none());
}

// ── Round 13: `set` module split + `Refreshable` trait wiring ──

#[test]
fn set_dispatch_routes_to_every_resource_module() {
    // Round 13 regression: every `SetCmd` variant must be
    // dispatchable. The resource families (core / proxy /
    // tun / sub / profile / config / daemon / rule-provider /
    // proxy-group / provider) are the public dispatch surface; the
    // Round 12 monolithic `commands::set` was split into
    // them, and a typo'd `super::super::bridge` path would
    // otherwise only surface in `cargo build`.
    use crate::cli::{
        SetCmd, SetConfigCmd, SetCoreCmd, SetDaemonCmd, SetProfileCmd, SetProxyCmd,
        SetRuleProviderCmd, SetSubCmd,
    };
    use crate::layout::CliOutput;

    fn empty_output() -> CliOutput {
        CliOutput::Human
    }
    fn empty_options() -> crate::cli::CliOptions {
        crate::cli::CliOptions::default()
    }

    let cases: Vec<(&str, SetCmd)> = vec![
        ("set core start", SetCmd::Core(SetCoreCmd::Start)),
        ("set proxy on", SetCmd::Proxy(SetProxyCmd::On)),
        ("set proxy off", SetCmd::Proxy(SetProxyCmd::Off)),
        ("set tun on", SetCmd::Tun(true)),
        ("set tun off", SetCmd::Tun(false)),
        (
            "set sub refresh",
            SetCmd::Sub(SetSubCmd::Refresh {
                target: None,
                force: false,
                asynchronous: false,
            }),
        ),
        (
            "set sub add https://x",
            SetCmd::Sub(SetSubCmd::Add {
                url: "https://x".to_owned(),
                name: None,
                refresh_every_minutes: None,
                apply: false,
                dry_run: false,
            }),
        ),
        (
            "set profile add x remote:y",
            SetCmd::Profile(SetProfileCmd::Add {
                id: "x".to_owned(),
                source: "remote:y".to_owned(),
                apply: false,
                dry_run: false,
            }),
        ),
        ("set config apply", SetCmd::Config(SetConfigCmd::Apply)),
        (
            "set config diff",
            SetCmd::Config(SetConfigCmd::Diff { file: None }),
        ),
        ("set daemon stop", SetCmd::Daemon(SetDaemonCmd::Stop)),
        (
            "set rule-provider list",
            SetCmd::RuleProvider(SetRuleProviderCmd::List),
        ),
        (
            "set rule-provider refresh",
            SetCmd::RuleProvider(SetRuleProviderCmd::Refresh { name: None }),
        ),
    ];
    for (label, cmd) in cases {
        // The dispatch must not panic on construction; the
        // exit code is `SUCCESS` for `planned_ok` stubs and
        // any failure code for the daemon-routed ones (no
        // daemon running in tests). The point is the path
        // through `set::run` — every variant must reach its
        // resource module.
        let _ = crate::commands::set::run(cmd, empty_options(), empty_output());
        // Suppress the unused `label` warning while keeping
        // it for human inspection if the test ever panics.
        let _ = label;
    }
}

#[test]
fn set_mod_exposes_six_sub_modules() {
    // Round 13: the `commands::set` module tree was
    // originally 8 resource sub-modules (one per
    // resource). Round 29: the `proxy_group` and
    // `rule_provider` sub-modules were removed —
    // they were 1-line passthroughs to
    // `commands::proxy_group::dispatch` /
    // `commands::rule_provider::dispatch`, and the
    // `commands::set::run` match now calls those
    // canonical dispatchers directly. The
    // `set/<resource>.rs` files that stayed are the
    // ones that own dispatch logic: the `core` /
    // `tun` / `daemon` / `config` / `profile` /
    // `proxy` / `sub` resources each have
    // resource-specific grammar mapping (the
    // `proxy` resource has `add` / `edit` /
    // `remove` / `import` / `on` / `off`; the
    // `profile` resource has `add` / `remove` /
    // `edit` / `export` / `enable` / `disable` /
    // `refresh`; the `sub` resource has the
    // bespoke `Import` path that drives the
    // `import_preview` CLI; the `common` module
    // is the shared `run_writer` / `run_standard_writer`
    // envelope). The two removed sub-modules
    // were pure indirection: the `set/proxy_group.rs`
    // and `set/rule_provider.rs` files contained
    // 1-line `dispatch` functions that just
    // delegated to the canonical
    // `commands::proxy_group::dispatch` /
    // `commands::rule_provider::dispatch`. The
    // `set::run` match now uses
    // `super::proxy_group::dispatch` /
    // `super::rule_provider::dispatch` directly,
    // saving two `.rs` files and two `mod
    // <resource>` declarations in `set/mod.rs`.
    // Round 33: `tun.rs` was inlined into
    // `set::run`'s `SetCmd::Tun` arm (the file
    // was a 9-line one-call-site shim). The
    // expected-file list dropped the entry.
    let set_dir = std::path::Path::new(env!("CARGO_MANIFEST_DIR")).join("src/commands/set");
    for resource in &[
        "common.rs",
        "config.rs",
        "core.rs",
        "daemon.rs",
        "profile.rs",
        "proxy.rs",
        "sub.rs",
    ] {
        let path = set_dir.join(resource);
        assert!(
            path.is_file(),
            "commands/set/{resource} must exist (set/proxy_group.rs and set/rule_provider.rs were removed in Round 29 — pure-indirection wrappers)"
        );
    }
    // The three removed sub-modules must NOT exist
    // (the test catches a future re-introduction
    // of the indirection).
    for removed in &["proxy_group.rs", "rule_provider.rs", "tun.rs"] {
        let path = set_dir.join(removed);
        assert!(
            !path.is_file(),
            "commands/set/{removed} must NOT exist (Round 29: indirection wrappers removed for proxy_group/rule_provider; Round 33: tun.rs inlined into set::run's `SetCmd::Tun` arm)"
        );
    }
}

#[test]
fn refreshable_trait_is_wired_into_set_dispatch() {
    // Round 13: the `Refreshable` trait is the unified
    // shape for "declare a remote source + refresh it".
    // Round 28: the third impl (`SubscriptionRefresh`)
    // was removed because `set sub refresh` still drives
    // the daemon RPC directly through `run_client` (the
    // trait's `refresh` only forwards `CliOptions::default()`
    // to the daemon RPC, losing the operator's `--json`
    // / `--core` flags). The two live impls are wired
    // through the `set profile refresh` / `set
    // rule-provider refresh` dispatchers; a future Round
    // that threads the operator's options through the
    // trait will re-add the sub impl.
    use crate::commands::refresh::Refreshable;
    fn assert_impl<T: Refreshable>() {}
    assert_impl::<crate::commands::refresh::ProfileRefresh>();
    assert_impl::<crate::commands::refresh::RuleProviderRefresh>();
}

// ── v3 resource-domain tree (cli-v3-design.md, W1-β) ──────────

#[test]
fn bare_invocation_runs_the_daemon() {
    // Q3: a bare `caly` is the foreground daemon.
    assert_eq!(parse(&[]).command, Command::Daemon);
    assert_eq!(parse(&["daemon"]).command, Command::Daemon);
}

#[test]
fn top_level_lifecycle_and_status() {
    assert_eq!(
        parse(&["stop"]).command,
        Command::Set(SetCmd::Daemon(SetDaemonCmd::Stop))
    );
    assert_eq!(
        parse(&["reload"]).command,
        Command::Set(SetCmd::Daemon(SetDaemonCmd::Reload))
    );
    assert_eq!(
        parse(&["restart"]).command,
        Command::Set(SetCmd::Daemon(SetDaemonCmd::Restart))
    );
    assert_eq!(
        parse(&["status"]).command,
        Command::Show(ShowCmd::Status { watch: false })
    );
    assert_eq!(
        parse(&["status", "--watch"]).command,
        Command::Show(ShowCmd::Status { watch: true })
    );
    // C-J: --verbose is the health snapshot (v1 `show core health`
    // and `set daemon status` both delegated here).
    assert_eq!(
        parse(&["status", "--verbose"]).command,
        Command::Show(ShowCmd::Core(ShowCoreCmd::Health))
    );
}

#[test]
fn node_domain_picks_by_default() {
    // A bare `caly node` / `caly n` opens the interactive live picker
    // (node select without an argument); listing stays explicit.
    assert_eq!(
        parse(&["node"]).command,
        Command::Set(SetCmd::Core(SetCoreCmd::Select {
            node: None,
            delay: false,
            poll: false,
        }))
    );
    assert_eq!(
        parse(&["node", "list"]).command,
        Command::Show(ShowCmd::Core(ShowCoreCmd::Nodes))
    );
    // T-1 transitional leaf.
    assert_eq!(
        parse(&["node", "groups"]).command,
        Command::Show(ShowCmd::Core(ShowCoreCmd::Groups))
    );
    // the offline inline-entries list.
    assert_eq!(
        parse(&["node", "inline"]).command,
        Command::Show(ShowCmd::Proxy(ShowProxyCmd::List))
    );
    // C-O W1 compromise: the only offline projection is the
    // declared `proxy_groups:` list.
    assert_eq!(
        parse(&["node", "list", "--offline"]).command,
        Command::Set(SetCmd::ProxyGroup(SetProxyGroupCmd::List {
            enabled_only: false
        }))
    );
    assert_eq!(
        parse(&["node", "list", "--offline", "--enabled"]).command,
        Command::Set(SetCmd::ProxyGroup(SetProxyGroupCmd::List {
            enabled_only: true
        }))
    );
    assert_eq!(
        parse(&["node", "show", "hk-01"]).command,
        Command::Show(ShowCmd::Proxy(ShowProxyCmd::Show {
            id: "hk-01".to_owned()
        }))
    );
}

#[test]
fn node_select_ping_test_parse() {
    assert_eq!(
        parse(&["node", "select", "hk-01"]).command,
        Command::Set(SetCmd::Core(SetCoreCmd::Select {
            node: Some("hk-01".to_owned()),
            delay: false,
            poll: false,
        }))
    );
    assert_eq!(
        parse(&["node", "select", "--delay"]).command,
        Command::Set(SetCmd::Core(SetCoreCmd::Select {
            node: None,
            delay: true,
            poll: false,
        }))
    );
    assert_eq!(
        parse(&["node", "ping", "hk-01", "--samples", "5"]).command,
        Command::Set(SetCmd::Core(SetCoreCmd::Delay {
            name: Some("hk-01".to_owned()),
            all: false,
            url: None,
            samples: Some(5),
        }))
    );
    assert_eq!(
        parse(&["node", "test", "hk-01", "--url", "https://x/"]).command,
        Command::Set(SetCmd::Core(SetCoreCmd::UrlTest {
            name: "hk-01".to_owned(),
            url: Some("https://x/".to_owned()),
            samples: None,
            apply: false
        }))
    );
    // W4 group face: `--apply` commits the re-test.
    assert_eq!(
        parse(&["node", "test", "auto-test", "--apply"]).command,
        Command::Set(SetCmd::Core(SetCoreCmd::UrlTest {
            name: "auto-test".to_owned(),
            url: None,
            samples: None,
            apply: true
        }))
    );
    // W4 (`node pick`): dry-run by default; `--apply` commits.
    assert_eq!(
        parse(&["node", "pick", "selector-main", "DIRECT"]).command,
        Command::Set(SetCmd::Core(SetCoreCmd::Pick {
            group: "selector-main".to_owned(),
            member: Some("DIRECT".to_owned()),
            apply: false,
            dry_run: false,
        }))
    );
    assert_eq!(
        parse(&["node", "pick", "selector-main", "--apply"]).command,
        Command::Set(SetCmd::Core(SetCoreCmd::Pick {
            group: "selector-main".to_owned(),
            member: None,
            apply: true,
            dry_run: false,
        }))
    );
    assert_eq!(
        parse(&["node", "pick", "selector-main", "DIRECT", "--dry-run"]).command,
        Command::Set(SetCmd::Core(SetCoreCmd::Pick {
            group: "selector-main".to_owned(),
            member: Some("DIRECT".to_owned()),
            apply: false,
            dry_run: true,
        }))
    );
}

#[test]
fn node_add_dual_form_parses() {
    assert_node_add_uri_form();
    assert_node_add_group_forms();
    // The target slot is required either way.
    let err = parse_err(&["node", "add"]);
    assert!(err.to_string().contains("required"));
    // --group (join) conflicts with --type (group form).
    let _err = parse_err(&[
        "node",
        "add",
        "vmess://x",
        "--group",
        "g",
        "--type",
        "select",
    ]);
}

fn assert_node_add_uri_form() {
    assert_eq!(
        parse(&["node", "add", "vmess://x", "--group", "节点选择"]).command,
        Command::Set(SetCmd::Proxy(SetProxyCmd::Add {
            uri: "vmess://x".to_owned(),
            group: Some("节点选择".to_owned()),
            apply: false,
            dry_run: false,
        }))
    );
}

fn assert_node_add_group_forms() {
    assert_eq!(
        parse(&[
            "node",
            "add",
            "自动选择",
            "--type",
            "url-test",
            "--members",
            "node:hk,direct",
            "--url",
            "https://x/",
        ])
        .command,
        Command::Set(SetCmd::ProxyGroup(SetProxyGroupCmd::Add {
            name: "自动选择".to_owned(),
            group_type: ProxyGroupTypeSpec::UrlTest,
            members: Ok(vec![
                ProxyGroupMemberSpec::Node {
                    tag: "hk".to_owned()
                },
                ProxyGroupMemberSpec::Direct,
            ]),
            url: Some("https://x/".to_owned()),
            interval_seconds: None,
            tolerance_ms: None,
            apply: false,
            dry_run: false,
        }))
    );
    assert_eq!(
        parse(&[
            "node",
            "add",
            "--type",
            "selector",
            "--name",
            "节点选择",
            "--members",
            "direct",
        ])
        .command,
        Command::Set(SetCmd::ProxyGroup(SetProxyGroupCmd::Add {
            name: "节点选择".to_owned(),
            group_type: ProxyGroupTypeSpec::Select,
            members: Ok(vec![ProxyGroupMemberSpec::Direct]),
            url: None,
            interval_seconds: None,
            tolerance_ms: None,
            apply: false,
            dry_run: false,
        }))
    );
    assert_eq!(
        parse(&[
            "node",
            "add",
            "--type",
            "urltest",
            "--name",
            "自动选择",
            "--members",
            "direct",
        ])
        .command,
        parse(&[
            "node",
            "add",
            "--type",
            "url-test",
            "--name",
            "自动选择",
            "--members",
            "direct",
        ])
        .command,
    );
}

#[test]
fn mode_connections_rules_traffic_top_level() {
    assert_eq!(
        parse(&["mode"]).command,
        Command::Show(ShowCmd::Core(ShowCoreCmd::Mode))
    );
    assert_eq!(
        parse(&["mode", "global"]).command,
        Command::Set(SetCmd::Core(SetCoreCmd::Mode("global".to_owned())))
    );
    assert_eq!(
        parse(&["connections"]).command,
        Command::Show(ShowCmd::Core(ShowCoreCmd::Connections { watch: false }))
    );
    assert_eq!(
        parse(&["connections", "--watch"]).command,
        Command::Show(ShowCmd::Core(ShowCoreCmd::Connections { watch: true }))
    );
    assert_eq!(
        parse(&["connections", "close"]).command,
        Command::Set(SetCmd::Core(SetCoreCmd::CloseConnections { id: None }))
    );
    assert_eq!(
        parse(&["connections", "close", "abc123"]).command,
        Command::Set(SetCmd::Core(SetCoreCmd::CloseConnections {
            id: Some("abc123".to_owned())
        }))
    );
    assert_eq!(parse(&["op"]).command, Command::Op(OpCmd::List));
    assert_eq!(parse(&["op", "list"]).command, Command::Op(OpCmd::List));
    assert_eq!(
        parse(&["op", "status", "abc"]).command,
        Command::Op(OpCmd::Status {
            id: "abc".to_owned()
        })
    );
    assert_eq!(
        parse(&["op", "cancel", "abc"]).command,
        Command::Op(OpCmd::Cancel {
            id: "abc".to_owned()
        })
    );
    assert_eq!(
        parse(&["traffic"]).command,
        Command::Show(ShowCmd::Core(ShowCoreCmd::Traffic { watch: false }))
    );
    assert_eq!(
        parse(&["traffic", "--watch"]).command,
        Command::Show(ShowCmd::Core(ShowCoreCmd::Traffic { watch: true }))
    );
    assert_eq!(
        parse(&["rules", "--match", "example.com"]).command,
        Command::Show(ShowCmd::Core(ShowCoreCmd::Rules {
            r#match: Some("example.com".to_owned())
        }))
    );
}

#[test]
fn sysproxy_tun_doctor_dns_top_level() {
    assert_eq!(
        parse(&["sysproxy", "on"]).command,
        Command::Set(SetCmd::Proxy(SetProxyCmd::On))
    );
    assert_eq!(
        parse(&["sysproxy", "off"]).command,
        Command::Set(SetCmd::Proxy(SetProxyCmd::Off))
    );
    // W-PAC (2026-08-12): `sysproxy pac [url]`.
    assert_eq!(
        parse(&["sysproxy", "pac"]).command,
        Command::Set(SetCmd::Proxy(SetProxyCmd::Pac { url: None }))
    );
    assert_eq!(
        parse(&["sysproxy", "pac", "file:///tmp/x.pac"]).command,
        Command::Set(SetCmd::Proxy(SetProxyCmd::Pac {
            url: Some("file:///tmp/x.pac".to_owned())
        }))
    );
    assert_eq!(
        parse(&["tun", "on"]).command,
        Command::Set(SetCmd::Tun(true))
    );
    assert_eq!(
        parse(&["doctor"]).command,
        Command::Tool(ToolCmd::Doctor { fix: false })
    );
    assert_eq!(
        parse(&["doctor", "--fix"]).command,
        Command::Tool(ToolCmd::Doctor { fix: true })
    );
    assert_eq!(
        parse(&["dns", "example.com"]).command,
        Command::Tool(ToolCmd::Dns(Some("example.com".to_owned())))
    );
}

#[test]
fn core_domain_keeps_kernel_lifecycle() {
    assert_eq!(
        parse(&["core", "start"]).command,
        Command::Set(SetCmd::Core(SetCoreCmd::Start))
    );
    assert_eq!(
        parse(&["core", "stop"]).command,
        Command::Set(SetCmd::Core(SetCoreCmd::Stop))
    );
    assert_eq!(
        parse(&["core", "restart"]).command,
        Command::Set(SetCmd::Core(SetCoreCmd::Restart))
    );
    assert_eq!(
        parse(&["core", "switch", "sing-box"]).command,
        Command::Set(SetCmd::Core(SetCoreCmd::Switch("sing-box".to_owned())))
    );
}

#[test]
fn profile_use_and_bare_domains() {
    assert_eq!(
        parse(&["profile", "use", "home"]).command,
        Command::Set(SetCmd::Profile(SetProfileCmd::Use {
            id: "home".to_owned()
        }))
    );
    assert_eq!(
        parse(&["profile"]).command,
        Command::Show(ShowCmd::Profile(ShowProfileCmd::List))
    );
    assert_eq!(
        parse(&["sub"]).command,
        Command::Show(ShowCmd::Sub(ShowSubCmd::Providers))
    );
    assert_eq!(
        parse(&["config"]).command,
        Command::Show(ShowCmd::Config(ShowConfigCmd::Files))
    );
    assert_eq!(
        parse(&["config", "show"]).command,
        Command::Show(ShowCmd::Config(ShowConfigCmd::Files))
    );
    assert_eq!(
        parse(&["config", "get", "kernel.mixed_port"]).command,
        Command::Show(ShowCmd::Config(ShowConfigCmd::Get {
            key: "kernel.mixed_port".to_owned()
        }))
    );
    assert_eq!(
        parse(&["config", "set", "kernel.mixed_port", "8888"]).command,
        Command::Set(SetCmd::Config(SetConfigCmd::Set {
            key: "kernel.mixed_port".to_owned(),
            value: "8888".to_owned(),
            apply: false
        }))
    );
    assert_eq!(
        parse(&["config", "set", "kernel.mixed_port", "8888", "--apply"]).command,
        Command::Set(SetCmd::Config(SetConfigCmd::Set {
            key: "kernel.mixed_port".to_owned(),
            value: "8888".to_owned(),
            apply: true
        }))
    );
}

#[test]
fn deprecated_paths_parse_identically_to_canonical() {
    // Every v1 path parses through the expansion layer to the
    // exact Invocation the canonical v3 path produces.
    let pairs: [(&[&str], &[&str]); 13] = [
        (&["show", "core", "nodes"], &["node", "list"]),
        (&["show", "core", "groups"], &["node", "groups"]),
        (
            &["show", "sub", "parse", "f.yaml"],
            &["sub", "parse", "f.yaml"],
        ),
        (&["show", "sub", "import"], &["sub", "import"]),
        (&["show", "config", "validate"], &["config", "validate"]),
        (&["set", "core", "select", "hk"], &["node", "select", "hk"]),
        (
            &["set", "core", "delay", "--all"],
            &["node", "ping", "--all"],
        ),
        (&["set", "proxy", "on"], &["sysproxy", "on"]),
        (&["set", "sub", "refresh"], &["sub", "refresh"]),
        (
            &["set", "proxy-group", "list"],
            &["node", "list", "--offline"],
        ),
        (
            &["set", "rule-provider", "list"],
            &["rule-provider", "list"],
        ),
        (&["tool", "doctor", "--fix"], &["doctor", "--fix"]),
        (&["set", "proxy", "list"], &["node", "inline"]),
    ];
    for (old, new) in pairs {
        assert_eq!(
            parse(old),
            parse(new),
            "deprecated {old:?} != canonical {new:?}",
        );
    }
}

#[test]
fn builtin_shortcuts_expand_to_canonical_paths() {
    // W3a: `t` entered the table with `--format=tree` (§9.1 终值 10 条).
    let pairs: [(&[&str], &[&str]); 10] = [
        (&["st"], &["status"]),
        // Bare `n` opens the live picker (`node` with no subcommand).
        (&["n"], &["node"]),
        (&["n", "s", "hk"], &["node", "select", "hk"]),
        (&["n", "p", "hk"], &["node", "ping", "hk"]),
        (&["n", "t", "hk"], &["node", "test", "hk"]),
        (&["t"], &["node", "list", "--format=tree"]),
        (&["s"], &["sub", "list"]),
        (&["s", "r"], &["sub", "refresh"]),
        (&["d"], &["doctor"]),
        (&["c"], &["config", "diff"]),
    ];
    for (shortcut, canonical) in pairs {
        assert_eq!(
            parse(shortcut),
            parse(canonical),
            "shortcut {shortcut:?} != canonical {canonical:?}",
        );
    }
}

#[test]
fn expansion_preserves_leading_global_flags() {
    let invocation = parse(&["--json", "show", "core", "nodes"]);
    assert!(invocation.options.json);
    assert_eq!(
        invocation.command,
        Command::Show(ShowCmd::Core(ShowCoreCmd::Nodes))
    );
}

#[test]
fn format_flag_pins_the_list_output_mode() {
    // §5.1: both spellings (`--format=tsv`, `--format table`)
    // parse; the flag rides through the alias layer untouched.
    let invocation = parse(&["node", "list", "--format=tsv"]);
    assert_eq!(invocation.options.format, Some(OutputFormat::Tsv));
    let invocation = parse(&["--format", "table", "node", "list"]);
    assert_eq!(invocation.options.format, Some(OutputFormat::Table));
    let invocation = parse(&["n", "--format=tsv"]);
    assert_eq!(invocation.options.format, Some(OutputFormat::Tsv));
    // The alias engine must skip the flag's value token (W2 adds
    // `--format` to VALUE_FLAGS): `table` here is the value, not
    // a (nonexistent) command head.
    let invocation = parse(&["--format", "tsv", "show", "proxy", "list"]);
    assert_eq!(invocation.options.format, Some(OutputFormat::Tsv));
    assert_eq!(
        invocation.command,
        Command::Show(ShowCmd::Core(ShowCoreCmd::Nodes))
    );
}

#[test]
fn c_l_prime_status_leaves_parse() {
    // C-L′: `sysproxy status` / `tun status` are offline
    // projections; `on`/`off` keep their v1 behaviour.
    let invocation = parse(&["sysproxy", "status"]);
    assert_eq!(invocation.command, Command::Show(ShowCmd::SysproxyStatus));
    let invocation = parse(&["tun", "status"]);
    assert_eq!(invocation.command, Command::Show(ShowCmd::TunStatus));
    let invocation = parse(&["sysproxy", "on"]);
    assert_eq!(
        invocation.command,
        Command::Set(SetCmd::Proxy(SetProxyCmd::On))
    );
    let invocation = parse(&["set", "proxy", "off"]);
    assert_eq!(
        invocation.command,
        Command::Set(SetCmd::Proxy(SetProxyCmd::Off))
    );
    let invocation = parse(&["tun", "off"]);
    assert_eq!(invocation.command, Command::Set(SetCmd::Tun(false)));
}
