//! `caly flow` — the live traffic processing flow.
//!
//! Every active connection is rendered with the routing metadata the kernel
//! reports for it: which rule matched, which outbound chain it is dialed
//! through. This is the data-plane half of the pipeline observability work
//! (pipeline design): the CLI polls the kernel's
//! Clash-compatible `/connections` directly, the daemon stays untouched,
//! and the renderer reuses the narrow-terminal table logic.

use std::io::IsTerminal;
use std::process::ExitCode;
use std::time::Duration;

use caly_kernel::corectl::contract::ConnectionDetail;

use crate::cli::CliOptions;
use crate::layout::{CliOutput, table_mode};
use crate::ops::client::query::{QUERY_TIMEOUT, build_control};

/// Watch-mode redraw interval.
const WATCH_INTERVAL: Duration = Duration::from_secs(1);
/// Consecutive query failures tolerated in watch mode before giving up
/// (transient kernel restarts must not kill `caly flow --watch`).
const WATCH_MAX_CONSECUTIVE_FAILURES: u32 = 3;
/// Single-shot mode: `--watch` repeats the query forever.
fn is_watch(watch: bool) -> bool {
    watch
}

/// Resolves the controller target exactly like the read-only query path:
/// `--core` flag → `CALY_CORE` → daemon snapshot label → `mihomo`.
fn resolve_core(options: &CliOptions) -> String {
    options.core.clone().unwrap_or_else(|| {
        std::env::var("CALY_CORE").unwrap_or_else(|_| {
            crate::ops::client::active_core_kind_label(options.socket.as_ref()).unwrap_or_else(|| "mihomo".to_owned())
        })
    })
}

/// Runs one flow snapshot and renders it (or the whole watch loop).
pub fn run(options: CliOptions, output: CliOutput, watch: bool, devices: bool, hosts: bool, protocols: bool, interface: bool) -> ExitCode {
    let core = resolve_core(&options);
    let json = output.is_json();
    let mut consecutive_failures = 0u32;
    let mut control = match build_control(&core) {
        Ok(control) => control,
        Err(error) => {
            return crate::ops::client::output::report_failure(
                &format!("flow query failed: {error}"),
                json,
            );
        }
    };
    loop {
        match control.connection_details(QUERY_TIMEOUT) {
            Ok(details) => {
                consecutive_failures = 0;
                if interface {
                    if json {
                        output.success("flow_interface", get_interface_stats_json("caly0"));
                        return ExitCode::SUCCESS;
                    }
                    render_interface_stats("caly0", output);
                    if !is_watch(watch) { return ExitCode::SUCCESS; }
                } else if devices {
                    let dev_summaries = caly_kernel::ir::aggregate_by_device(&details);
                    if json {
                        output.success("flow_devices", serde_json::json!({ "devices": dev_summaries }));
                        return ExitCode::SUCCESS;
                    }
                    render_device_table(&dev_summaries, output);
                } else if hosts {
                    let host_summaries = caly_kernel::ir::aggregate_by_host(&details);
                    if json {
                        output.success("flow_hosts", serde_json::json!({ "hosts": host_summaries }));
                        return ExitCode::SUCCESS;
                    }
                    render_host_table(&host_summaries, output);
                } else if protocols {
                    let proto_breakdown = caly_kernel::ir::aggregate_by_protocol(&details);
                    if json {
                        output.success("flow_protocols", serde_json::json!({ "protocols": proto_breakdown }));
                        return ExitCode::SUCCESS;
                    }
                    render_protocol_table(&proto_breakdown, output);
                } else {
                    if json {
                        output.success("flow", serde_json::json!({ "connections": details }));
                        return ExitCode::SUCCESS;
                    }
                    render_flow_table(&details, output);
                }
            }
            Err(error) => {
                if !is_watch(watch) {
                    return crate::ops::client::output::report_failure(
                        &format!("flow query failed: {error}"),
                        json,
                    );
                }
                consecutive_failures += 1;
                if consecutive_failures >= 5 {
                    // Attempt to reconnect controller before failing
                    if let Ok(new_control) = build_control(&core) {
                        control = new_control;
                        consecutive_failures = 0;
                    } else {
                        return crate::ops::client::output::report_failure(
                            &format!("flow query keeps failing: {error}"),
                            json,
                        );
                    }
                }
            }
        }
        if !is_watch(watch) {
            return ExitCode::SUCCESS;
        }
        // TTY watch mode clears between frames; piped output prints each
        // snapshot sequentially so it stays greppable.
        if std::io::stdout().is_terminal() {
            print!("\x1b[2J\x1b[H");
        }
        std::thread::sleep(WATCH_INTERVAL);
    }
}

/// Renders the connection table with the narrow-terminal contraction used
/// across the CLI (`render_table`). Columns: host:port, net/proto, rule,
/// outbound chain, up/down bytes.
fn render_flow_table(details: &[ConnectionDetail], output: CliOutput) {
    if details.is_empty() {
        output.info("no active connections");
        return;
    }
    let mut rows: Vec<Vec<String>> = Vec::with_capacity(details.len());
    for connection in details {
        let target = if connection.host.is_empty() {
            "-".to_owned()
        } else {
            format!("{}:{}", connection.host, connection.destination_port)
        };
        let protocol = if connection.protocol_type.is_empty() {
            connection.network.clone()
        } else {
            format!("{}/{}", connection.network, connection.protocol_type)
        };
        let rule = if connection.rule.is_empty() {
            "-".to_owned()
        } else if connection.rule_payload.is_empty() {
            connection.rule.clone()
        } else {
            format!("{},{}", connection.rule, connection.rule_payload)
        };
        let chain = if connection.chain.is_empty() {
            if connection.outbound.is_empty() {
                "-".to_owned()
            } else {
                connection.outbound.clone()
            }
        } else {
            connection.chain.join(" → ")
        };
        rows.push(vec![
            target,
            protocol,
            rule,
            chain,
            crate::layout::human_bytes(connection.upload_bytes),
            crate::layout::human_bytes(connection.download_bytes),
        ]);
    }
    let headers: [&str; 6] = ["HOST:PORT", "NET/PROTO", "RULE", "OUTBOUND", "UP", "DOWN"];
    let lines = crate::layout::render_table(table_mode(None), &headers, &rows, None);
    for line in lines {
        println!("{line}");
    }
}

/// Resolves one connection by exact id, then by `host:port` (host matched
/// case-insensitively), and renders its full processing chain.
pub fn trace(options: CliOptions, output: CliOutput, selector: &str, watch: bool) -> ExitCode {
    if watch {
        // A trace is a single snapshot; `--watch` has nothing to redraw
        // (the flag used to be dropped
        // silently).
        crate::layout::note_err("`--watch` does not apply to `flow trace`; showing one snapshot");
    }
    let core = resolve_core(&options);
    let json = output.is_json();
    let mut control = match build_control(&core) {
        Ok(control) => control,
        Err(error) => {
            return crate::ops::client::output::report_failure(
                &format!("flow trace failed: {error}"),
                json,
            );
        }
    };
    let details = match control.connection_details(QUERY_TIMEOUT) {
        Ok(details) => details,
        Err(error) => {
            return crate::ops::client::output::report_failure(
                &format!("flow trace failed: {error}"),
                json,
            );
        }
    };
    let found = details
        .iter()
        .find(|connection| connection.id == selector)
        .or_else(|| {
            // `host:port` selector: host is case-insensitive, port must
            // match exactly; the first match wins (flows to the same
            // target are rare and the chain is usually identical).
            let (host, port) = split_host_port(selector)?;
            details.iter().find(|connection| {
                connection.host.eq_ignore_ascii_case(host) && connection.destination_port == port
            })
        });
    let Some(connection) = found else {
        return crate::ops::client::output::report_failure(
            &format!("no active connection matches `{selector}`"),
            json,
        );
    };
    if json {
        output.success("flow", serde_json::json!(connection));
        return ExitCode::SUCCESS;
    }
    render_trace(connection);
    ExitCode::SUCCESS
}

/// Splits a `host:port` selector; the port must parse as a u16.
fn split_host_port(selector: &str) -> Option<(&str, u16)> {
    let (host, port) = selector.rsplit_once(':')?;
    if host.is_empty() {
        return None;
    }
    let port: u16 = port.parse().ok()?;
    // Port 0 is not a real endpoint; treat it as an invalid selector
    // (boundary audit).
    if port == 0 {
        return None;
    }
    Some((host, port))
}

/// Renders one connection's processing chain as labeled lines:
/// inbound → sniff → dns → rule → group → node, plus traffic totals.
fn render_trace(connection: &ConnectionDetail) {
    let mut block = crate::layout::KvBlock::plain()
        .indent(0)
        .row("connection", &connection.id);
    if !connection.inbound_name.is_empty() {
        block = block.row("inbound", &connection.inbound_name);
    }
    if !connection.process_path.is_empty() {
        block = block.row("process", &connection.process_path);
    }
    let sniff = if connection.protocol_type.is_empty() {
        connection.network.clone()
    } else {
        format!("{}/{}", connection.network, connection.protocol_type)
    };
    block = block.row("sniff", sniff).row(
        "target",
        format!("{}:{}", connection.host, connection.destination_port),
    );
    let rule = if connection.rule.is_empty() {
        "-".to_owned()
    } else if connection.rule_payload.is_empty() {
        connection.rule.clone()
    } else {
        format!("{},{}", connection.rule, connection.rule_payload)
    };
    block = block.row("rule", rule);
    let chain = if connection.chain.is_empty() {
        if connection.outbound.is_empty() {
            "-".to_owned()
        } else {
            connection.outbound.clone()
        }
    } else {
        connection.chain.join(" → ")
    };
    block = block.row("chain", chain).row(
        "traffic",
        format!(
            "↑{} ↓{}",
            crate::layout::human_bytes(connection.upload_bytes),
            crate::layout::human_bytes(connection.download_bytes)
        ),
    );
    block.print();
}

#[cfg(test)]
mod tests {
    use super::split_host_port;
    use crate::layout::human_bytes;

    #[test]
    fn splits_host_port_selectors() {
        assert_eq!(
            split_host_port("example.com:443"),
            Some(("example.com", 443))
        );
        assert_eq!(split_host_port("1.2.3.4:80"), Some(("1.2.3.4", 80)));
        // rsplit takes the LAST colon, so a bare IPv6 host parses too.
        assert_eq!(split_host_port("::1:443"), Some(("::1", 443)));
        // Missing port / non-numeric port: not a valid selector.
        assert_eq!(split_host_port("example.com"), None);
        assert_eq!(split_host_port("example.com:notaport"), None);
    }

    #[test]
    fn formats_human_bytes() {
        assert_eq!(human_bytes(0), "0 B");
        assert_eq!(human_bytes(512), "512 B");
        assert_eq!(human_bytes(1024), "1.0 KB");
        assert_eq!(human_bytes(1_048_576), "1.0 MB");
        assert_eq!(human_bytes(5_242_880), "5.0 MB");
        assert_eq!(human_bytes(1_073_741_824), "1.0 GB");
    }
}

/// Renders a Gateway LAN Client device traffic breakdown.
pub fn render_gateway_clients(details: &[ConnectionDetail], output: CliOutput) {
    let snap = caly_core::domain::compute_traffic_analytics(details, |c| {
        let client_ip = if c.source_ip.is_empty() { "127.0.0.1".to_owned() } else { c.source_ip.clone() };
        (client_ip, c.host.clone(), c.protocol_type.clone(), c.upload_bytes, c.download_bytes)
    });

    if output.is_json() {
        output.success("clients", serde_json::json!({ "clients": snap.client_traffic }));
        return;
    }

    if snap.client_traffic.is_empty() {
        output.info("no active gateway client traffic");
        return;
    }

    let mut rows = Vec::new();
    for (ip, stats) in &snap.client_traffic {
        rows.push(vec![
            ip.clone(),
            stats.active_connections.to_string(),
            crate::layout::human_bytes(stats.upload_bytes),
            crate::layout::human_bytes(stats.download_bytes),
            crate::layout::human_bytes(stats.upload_bytes + stats.download_bytes),
        ]);
    }
    let headers: [&str; 5] = ["CLIENT IP", "CONNS", "UPLOAD", "DOWNLOAD", "TOTAL DATA"];
    println!("Gateway LAN Client Traffic ({} active devices):", rows.len());
    crate::layout::print_table(
        crate::layout::TableMode::Table,
        &headers,
        &rows,
    );
}

fn render_device_table(devices: &[caly_kernel::ir::DeviceTrafficSummary], output: CliOutput) {
    if devices.is_empty() {
        output.info("no active client devices");
        return;
    }
    let mut rows: Vec<Vec<String>> = Vec::with_capacity(devices.len());
    for d in devices {
        rows.push(vec![
            d.source_ip.clone(),
            d.active_connections.to_string(),
            crate::layout::human_bytes(d.upload_bytes),
            crate::layout::human_bytes(d.download_bytes),
            d.primary_destination.clone(),
        ]);
    }
    let headers: [&str; 5] = ["CLIENT DEVICE (IP)", "CONNS", "UP", "DOWN", "TOP DESTINATION"];
    output.table(&headers, &rows);
}

fn render_host_table(hosts: &[caly_kernel::ir::HostTrafficSummary], output: CliOutput) {
    if hosts.is_empty() {
        output.info("no active host traffic");
        return;
    }
    let mut rows: Vec<Vec<String>> = Vec::with_capacity(hosts.len());
    for h in hosts {
        rows.push(vec![
            h.destination_host.clone(),
            h.active_connections.to_string(),
            crate::layout::human_bytes(h.upload_bytes),
            crate::layout::human_bytes(h.download_bytes),
            h.outbound_chain.clone(),
        ]);
    }
    let headers: [&str; 5] = ["DESTINATION HOST", "CONNS", "UP", "DOWN", "OUTBOUND CHAIN"];
    output.table(&headers, &rows);
}

fn render_protocol_table(breakdown: &caly_kernel::ir::ProtocolBreakdown, output: CliOutput) {
    println!("Traffic Protocol Breakdown:");
    println!("  L4 Transport: TCP: {} conns ({}), UDP: {} conns ({})",
        breakdown.tcp_connections, crate::layout::human_bytes(breakdown.tcp_bytes),
        breakdown.udp_connections, crate::layout::human_bytes(breakdown.udp_bytes),
    );
    if !breakdown.l7_protocols.is_empty() {
        println!("  L7 Application Protocols:");
        for (proto, count) in &breakdown.l7_protocols {
            println!("    - {proto:<10}: {count} active connections");
        }
    }
}

fn get_interface_stats_json(iface: &str) -> serde_json::Value {
    let (rx_b, rx_p, rx_d, tx_b, tx_p, tx_d) = read_iface_dev(iface);
    serde_json::json!({
        "interface": iface,
        "rx_bytes": rx_b,
        "rx_packets": rx_p,
        "rx_drops": rx_d,
        "tx_bytes": tx_b,
        "tx_packets": tx_p,
        "tx_drops": tx_d,
    })
}

fn render_interface_stats(iface: &str, _output: CliOutput) {
    let (rx_b, rx_p, rx_d, tx_b, tx_p, tx_d) = read_iface_dev(iface);
    println!("Virtual Network Interface [{iface}] Statistics:");
    println!("  RX (Inbound):  {} ({} packets, {} drops)", crate::layout::human_bytes(rx_b), rx_p, rx_d);
    println!("  TX (Outbound): {} ({} packets, {} drops)", crate::layout::human_bytes(tx_b), tx_p, tx_d);
}

fn read_iface_dev(iface: &str) -> (u64, u64, u64, u64, u64, u64) {
    let Ok(content) = std::fs::read_to_string("/proc/net/dev") else {
        return (0, 0, 0, 0, 0, 0);
    };
    for line in content.lines() {
        let trimmed = line.trim();
        if let Some((name, stats)) = trimmed.split_once(':') {
            if name.trim() == iface {
                let parts: Vec<&str> = stats.split_whitespace().collect();
                if parts.len() >= 12 {
                    let rx_b = parts[0].parse().unwrap_or(0);
                    let rx_p = parts[1].parse().unwrap_or(0);
                    let rx_d = parts[3].parse().unwrap_or(0);
                    let tx_b = parts[8].parse().unwrap_or(0);
                    let tx_p = parts[9].parse().unwrap_or(0);
                    let tx_d = parts[11].parse().unwrap_or(0);
                    return (rx_b, rx_p, rx_d, tx_b, tx_p, tx_d);
                }
            }
        }
    }
    (0, 0, 0, 0, 0, 0)
}
