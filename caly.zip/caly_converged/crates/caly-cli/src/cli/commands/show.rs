//! `caly show …` — read-only queries.
//!
//! every read-only leaf now routes through
//! the typed `client::run_client` / `client::profile` /
//! `client::config_generate` helpers directly. The
//! `bridge` shim was retired for the 5 `old_*`
//! functions; the 3 `sub_*` shims stay (used by
//! `show sub` / `set sub import` which still need the
//! legacy `SubCmd` enum until Round 16+ folds them).

use std::io::IsTerminal;
use std::process::ExitCode;

use crate::cli::{
    SetSubCmd, ShowCmd, ShowConfigCmd, ShowCoreCmd, ShowProfileCmd, ShowProxyCmd, ShowSubCmd,
};
use crate::ops::client::{Query, run_query};
use crate::layout::CliOutput;

pub fn run(cmd: ShowCmd, options: crate::cli::CliOptions, output: CliOutput) -> ExitCode {
    match cmd {
        ShowCmd::Status { watch } => super::status::run(options, output, watch),
        ShowCmd::Core(c) => core(c, options, output),
        ShowCmd::Sub(c) => sub(c, options, output),
        ShowCmd::Profile(c) => profile(c, options, output),
        ShowCmd::Proxy(c) => proxy(c, options, output),
        ShowCmd::Config(c) => config(c, options, output),
        ShowCmd::SysproxyStatus => super::sys_status::run_sysproxy(&options),
        ShowCmd::TunStatus => super::sys_status::run_tun(&options),
    }
}

fn core(c: ShowCoreCmd, options: crate::cli::CliOptions, output: CliOutput) -> ExitCode {
    use crate::ops::client::legacy::CoreCmd;
    // Translate `show core X` to the existing `client::run_client` CoreCmd shape.
    let mapped = match c {
        ShowCoreCmd::Nodes => {
            // W3a: `node list --format=tree` renders the offline declared
            // entry tree (the online wire carries no group membership until
            // W3b); bare `node --format=tree` reaches the same projection.
            if options.format == Some(crate::cli::OutputFormat::Tree) {
                let paths = caly_daemon::platform::paths::AppPaths::from_env();
                return super::node_tree::render_declared_tree(&paths, false, output.is_json());
            }
            CoreCmd::ListNodes
        }
        ShowCoreCmd::Groups => CoreCmd::ProxyGroups,
        ShowCoreCmd::Connections { watch } => {
            return watch_query(options, output, watch, Query::Connections);
        }
        ShowCoreCmd::Flow {
            watch,
            devices,
            hosts,
            protocols,
            interface,
        } => return super::flow::run(options, output, watch, devices, hosts, protocols, interface),
        ShowCoreCmd::FlowTrace { id, watch } => {
            return super::flow::trace(options, output, &id, watch);
        }
        ShowCoreCmd::Traffic { watch } => {
            return watch_query(options, output, watch, Query::Traffic);
        }
        ShowCoreCmd::Mode => return show_mode(&options, output),
        ShowCoreCmd::Rules { r#match: None } => CoreCmd::Rules,
        ShowCoreCmd::Rules { r#match: Some(t) } => CoreCmd::RuleMatch(t),
        ShowCoreCmd::Health => return health(options, output),
    };
    crate::ops::client::run_client(crate::ClientCommand::Core(mapped), options)
}

/// Prints the live routing mode (read-only — this used to route through
/// the SetMode executor, resetting the mode on every bare `caly mode`).
fn show_mode(options: &crate::cli::CliOptions, output: CliOutput) -> ExitCode {
    crate::ops::client::execute::with_uds_snapshot(options.socket.as_ref(), |_client, snapshot| {
        use caly_daemon::protocol::protocol::v2::WireMode;
        let raw = snapshot.desired.mode;
        let label = WireMode::from_wire(raw)
            .map_or_else(|| format!("unknown ({raw})"), |mode| mode.label().to_owned());
        if output.is_json() {
            println!("{}", serde_json::json!({ "mode": label }));
        } else {
            println!("mode: {label}");
        }
        ExitCode::SUCCESS
    })
}

fn health(options: crate::cli::CliOptions, output: CliOutput) -> ExitCode {
    // read the daemon snapshot directly via the
    // UDS path the daemon publishes. The snapshot carries
    // every field the operator wants at a glance (uptime,
    // restart count, applied core, observed rates, node
    // count). If the daemon is unreachable, surface a
    // typed `core.daemon_unreachable` error.
    //
    // connect + handshake + snapshot boilerplate
    // moved to `client::execute::with_uds_snapshot` so
    // every read-only `show` leaf reuses one error envelope.
    crate::ops::client::execute::with_uds_snapshot(options.socket.as_ref(), |_client, snapshot| {
        // The wire snapshot carries a raw `CoreKind` discriminant — decode
        // it through the shared wire enum so `show` prints `mihomo` (the
        // same label the daemon logs) instead of the raw `1`.
        let core_label = snapshot.applied.core_kind.map_or_else(
            || "none".to_owned(),
            |raw| {
                caly_daemon::protocol::protocol::v2::WireCoreKind::from_wire(raw).map_or_else(
                    || format!("unknown ({raw})"),
                    |kind| caly_core::domain::CoreKind::from(kind).label().to_owned(),
                )
            },
        );
        let summary = format!(
            "daemon: {}\n  revision: {}\n  applied core: {}\n  nodes: {}\n  up: {} B/s\n  down: {} B/s\n  restarts: {}\n  restart backoff: {} ms",
            caly_core::domain::to_hex(snapshot.daemon_instance_id),
            snapshot.revision,
            core_label,
            snapshot.nodes.len(),
            snapshot.observed.upload_bytes_per_second,
            snapshot.observed.download_bytes_per_second,
            snapshot.observed.core_restart_count,
            snapshot.observed.core_restart_backoff_ms,
        );
        if output.is_json() {
            let payload = serde_json::json!({
                "daemon_instance_id": caly_core::domain::to_hex(snapshot.daemon_instance_id),
                "revision": snapshot.revision,
                "applied_core": core_label,
                "nodes": snapshot.nodes.len(),
                "up_bps": snapshot.observed.upload_bytes_per_second,
                "down_bps": snapshot.observed.download_bytes_per_second,
                "restarts": snapshot.observed.core_restart_count,
                "restart_backoff_ms": snapshot.observed.core_restart_backoff_ms,
            });
            println!("{payload}");
        } else {
            println!("{summary}");
        }
        ExitCode::SUCCESS
    })
}

/// Runs one of the short-lived core queries, optionally repeating forever.
fn watch_query(
    options: crate::cli::CliOptions,
    output: CliOutput,
    watch: bool,
    query: Query,
) -> ExitCode {
    let core = options.core.clone().unwrap_or_else(|| {
        std::env::var("CALY_CORE").unwrap_or_else(|_| {
            crate::ops::client::active_core_kind_label(options.socket.as_ref()).unwrap_or_else(|| "mihomo".to_owned())
        })
    });
    let json = output.is_json();
    loop {
        let exit = run_query(&core, query.clone(), json);
        if !watch || exit != ExitCode::SUCCESS {
            return exit;
        }
        if std::io::stdout().is_terminal() && !json {
            print!("\x1b[2J\x1b[H");
        }
        std::thread::sleep(std::time::Duration::from_secs(1));
    }
}

fn sub(c: ShowSubCmd, options: crate::cli::CliOptions, output: CliOutput) -> ExitCode {
    let json = options.json;
    match c {
        ShowSubCmd::Providers => crate::ops::client::subscription::list_providers(json, options.format, options.socket.as_ref()),
        ShowSubCmd::Parse {
            path,
            userinfo,
            apply,
            name,
        } => {
            if apply {
                // `--apply` registers the parsed file as a subscription
                // source — the same path as `sub add <path> --apply`, with
                // the name defaulting to the file stem so batch use stays
                // deterministic (no interactive naming prompt).
                let default_name = path
                    .file_stem()
                    .map(|stem| stem.to_string_lossy().into_owned());
                return super::set::sub::dispatch(
                    SetSubCmd::Add {
                        url: path.display().to_string(),
                        name: name.or(default_name),
                        refresh_every_minutes: None,
                        apply: true,
                        dry_run: false,
                    },
                    options,
                    output,
                );
            }
            crate::ops::client::subscription::check_subscription(&path, userinfo.as_deref(), json)
        }
    }
}

fn profile(c: ShowProfileCmd, options: crate::cli::CliOptions, output: CliOutput) -> ExitCode {
    // directly call `client::profile`
    // functions, bypassing the `bridge` shim.
    let paths = crate::ops::client::profile::resolve_paths();
    match c {
        ShowProfileCmd::List => {
            // Render declared profiles in human or JSON mode.
            let config = match crate::ops::client::profile::load_declared_profiles(&paths) {
                Ok((c, _)) => c,
                Err(e) => {
                    return crate::layout::report_error_returning(
                        output,
                        crate::layout::CliError::new(
                            "profile.load_failed",
                            format!("profile list failed: {e}"),
                            "profile list",
                        ),
                    );
                }
            };
            let profiles = crate::ops::client::profile::list_declared(&config);
            if output.is_json() {
                let items: Vec<serde_json::Value> = profiles
                    .iter()
                    .map(|p| {
                        serde_json::json!({
                            "id": p.id,
                            "name": p.name,
                            "description": p.description,
                            "source": p.source.kind_label().to_owned(),
                        })
                    })
                    .collect();
                let payload = serde_json::json!({
                    "profiles": items,
                    "count": items.len(),
                });
                println!("{payload}");
                ExitCode::SUCCESS
            } else {
                // W2 (cli-v3-design.md §5.1, Q6): adaptive
                // table/TSV replaces the v1 `profile: <id> …`
                // lines and the trailing count line.
                let mode = crate::layout::table_mode(options.format);
                let rows: Vec<Vec<String>> = profiles
                    .iter()
                    .map(|p| {
                        vec![
                            p.id.clone(),
                            p.name.clone().unwrap_or_else(|| "-".to_owned()),
                            p.source.kind_label().to_owned(),
                        ]
                    })
                    .collect();
                let headers: &[&str] = match mode {
                    crate::layout::TableMode::Tsv => &["id", "name", "source"],
                    crate::layout::TableMode::Table => &["ID", "NAME", "SOURCE"],
                };
                crate::layout::print_table(mode, headers, &rows);
                ExitCode::SUCCESS
            }
        }
        ShowProfileCmd::Show { id } => {
            let (config, _store) = match crate::ops::client::profile::load_declared_profiles(&paths) {
                Ok(v) => v,
                Err(e) => {
                    return crate::layout::report_error_returning(
                        output,
                        crate::layout::CliError::new(
                            "profile.load_failed",
                            format!("profile show failed: {e}"),
                            "profile show",
                        ),
                    );
                }
            };
            if let Some(p) = crate::ops::client::profile::find_declared(&config, &id) {
                println!(
                    "profile: {} ({})",
                    p.id,
                    p.source.kind_label().to_owned()
                );
                ExitCode::SUCCESS
            } else {
                crate::layout::report_error_returning(
                    output,
                    crate::layout::CliError::new(
                        "profile.not_declared",
                        format!("profile `{id}` is not declared"),
                        "profile show",
                    )
                    .with_hint("run `profile list` to see declared profiles"),
                )
            }
        }
    }
}

fn proxy(c: ShowProxyCmd, options: crate::cli::CliOptions, output: CliOutput) -> ExitCode {
    match c {
        // W1-β: the online single-entry detail (`node show <id>`);
        // the v1 list/groups leaves moved to the node domain
        // (`node list` / `node groups`).
        ShowProxyCmd::Show { id } => show_proxy_id(&id, output, options.socket.as_ref()),
        // the offline inline-entries list (`node inline`).
        ShowProxyCmd::List => super::show_inline::run(output, options.format),
    }
}

fn show_proxy_id(id: &str, output: CliOutput, socket: Option<&std::path::PathBuf>) -> ExitCode {
    // read the snapshot, find the node by 32-hex
    // id, print its protocol + latency + name. Falls back
    // to a name-prefix match when the id isn't a 32-hex
    // string (mirrors `core select` matching).
    //
    // connect + handshake + snapshot boilerplate
    // moved to `client::execute::with_uds_snapshot` so
    // every read-only `show` leaf reuses one error envelope.
    crate::ops::client::execute::with_uds_snapshot(socket, |_client, snapshot| {
        let node = snapshot.nodes.iter().find(|n| caly_core::domain::to_hex(n.node_id) == id);
        let resolved = if let Some(n) = node {
            n.clone()
        } else {
            // Fall back to name prefix match.
            let prefix_matches: Vec<_> = snapshot
                .nodes
                .iter()
                .filter(|n| n.name.to_lowercase().starts_with(&id.to_lowercase()) || n.name == id)
                .collect();
            match prefix_matches.len() {
                0 => {
                    return crate::layout::report_error_returning(
                        output,
                        crate::layout::CliError::new(
                            "node.not_found",
                            format!("no node matches `{id}`"),
                            "node show",
                        )
                        .with_hint("run `node list` to see available nodes"),
                    );
                }
                1 => prefix_matches[0].clone(),
                _ => {
                    let ids: Vec<String> = prefix_matches
                        .iter()
                        .map(|n| format!("  {} ({})", caly_core::domain::to_hex(n.node_id), n.name.as_str()))
                        .collect();
                    return crate::layout::report_error_returning(
                        output,
                        crate::layout::CliError::new(
                            "node.ambiguous",
                            format!(
                                "{} nodes match `{id}`:\n{}",
                                prefix_matches.len(),
                                ids.join("\n")
                            ),
                            "node show",
                        )
                        .with_hint("use a longer prefix or a 32-hex id"),
                    );
                }
            }
        };
        let latency = resolved
            .latency_ms
            .map_or_else(|| "-".to_owned(), |ms| format!("{ms} ms"));
        let availability = if resolved.available { "yes" } else { "no" };
        if output.is_json() {
            let payload = serde_json::json!({
                "id": caly_core::domain::to_hex(resolved.node_id),
                "name": resolved.name.as_str(),
                "protocol": resolved.protocol,
                "available": resolved.available,
                "latency_ms": resolved.latency_ms,
            });
            println!("{payload}");
        } else {
            crate::layout::KvBlock::plain()
                .indent(0)
                .row("node", caly_core::domain::to_hex(resolved.node_id))
                .row("name", resolved.name.as_str())
                .row("protocol", resolved.protocol)
                .row("available", availability)
                .row("latency", latency)
                .print();
        }
        ExitCode::SUCCESS
    })
}

fn config(c: ShowConfigCmd, options: crate::cli::CliOptions, _output: CliOutput) -> ExitCode {
    let json = options.json;
    match c {
        ShowConfigCmd::Get { key } => crate::ops::client::config_kv::config_get(json, &key),
        ShowConfigCmd::Path => crate::ops::client::config_generate::config_path(json),
        ShowConfigCmd::Files => crate::ops::client::config_generate::config_files(json),
        ShowConfigCmd::Validate { file: None } => {
            crate::ops::client::config_generate::validate_active_config(json)
        }
        ShowConfigCmd::Validate { file: Some(p) } => {
            crate::ops::client::execute::check_single_config_file(&p, json)
        }
    }
}
