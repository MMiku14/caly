//! `caly op …` — follow up on daemon operations.
//!
//! Thin dispatch: validates the op id (a malformed id is a usage
//! error that never dials the daemon), then runs the query through
//! the shared connected-command path.

use std::process::ExitCode;

use crate::cli::OpCmd;
use crate::ops::client::op::{OpQuery, parse_op_id};

pub fn run(cmd: OpCmd, options: crate::cli::CliOptions) -> ExitCode {
    let query = match cmd {
        OpCmd::List => OpQuery::List,
        OpCmd::Status { id } => match parse_op_id(&id) {
            Ok(id) => OpQuery::Status { id },
            Err(reason) => return usage_error(reason, "op status"),
        },
        OpCmd::Cancel { id } => match parse_op_id(&id) {
            Ok(id) => OpQuery::Cancel { id },
            Err(reason) => return usage_error(reason, "op cancel"),
        },
    };
    crate::ops::client::run_client(crate::ClientCommand::Op(query), options)
}

/// Usage-class failure (exit 2 via the `usage.` prefix rule).
fn usage_error(reason: String, command: &'static str) -> ExitCode {
    crate::layout::report_error_returning(
        crate::layout::CliOutput::Human,
        crate::layout::CliError::new("usage.op_bad_id", reason, command),
    )
}
