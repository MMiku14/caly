//! `set config …` dispatch.
//!
//! `apply` / `generate` / `default` / `edit` route
//! through the typed `client::run_client` / `client::*`
//! helpers (the `bridge` shim was retired). 
//! `diff` is a real line-by-line diff (current vs
//! `--file <PATH>` or vs the documented default).

use std::process::ExitCode;

use crate::cli::SetConfigCmd;
use crate::ops::client::legacy::ConfigCmd;
use crate::layout::CliOutput;

pub fn dispatch(c: SetConfigCmd, options: crate::cli::CliOptions, _output: CliOutput) -> ExitCode {
    match c {
        SetConfigCmd::Apply => {
            crate::ops::client::run_client(crate::ClientCommand::Config(ConfigCmd::Apply), options)
        }
        SetConfigCmd::Generate => crate::ops::client::config_generate::generate_config(options.json),
        SetConfigCmd::Default => crate::ops::client::config_generate::reset_default_config(options.json),
        SetConfigCmd::Edit(editor) => {
            let editor = match editor {
                crate::cli::Editor::Vim => crate::ops::types::Editor::Vim,
                crate::cli::Editor::Nvim => crate::ops::types::Editor::Nvim,
            };
            crate::ops::client::config_generate::edit_config(editor, options.json)
        }
        SetConfigCmd::Diff { file } => {
            crate::ops::client::config_generate::diff_config(file.as_deref(), options.json)
        }
        SetConfigCmd::Set { key, value, apply } => {
            crate::ops::client::config_kv::config_set(options.json, &key, &value, apply)
        }
    }
}
