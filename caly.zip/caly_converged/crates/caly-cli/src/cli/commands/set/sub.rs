//! `set sub …` dispatch.
//!
//! the 4 source-CRUD leaves
//! (`add` / `remove` / `enable` / `disable`) now go
//! through the shared
//! `commands::set::common::run_writer` envelope. The
//! `import` and `refresh` leaves keep their bespoke
//! paths:
//!
//! - `refresh` drives the daemon RPC; the daemon
//!   returns `ExitCode`, not `Result`, and the typed
//!   `run_client_collect` is the future hook for a
//!   real `SubscriptionRefresh` trait integration.
//! - `import` inspects a file/clipboard and prints a
//!   preview; a future `--save` flag can promote the
//!   preview to a write by lifting the
//!   `import_preview` projection into a typed
//!   writer (the contract is fixed: `nodes` must be
//!   non-empty, otherwise `SubCmdError::InvalidUrl`
//!   surfaces). the writer itself is
//!   absent today (the `import_inline` helper that
//!   held the path-safety + non-empty guard was
//!   retired in Round 32 with its 3 unit tests), so
//!   a follow-up round that wires the leaf would
//!   re-introduce the writer + 3 unit tests at the
//!   same site.
//!
//! Every writer returns `Result<SubWriteOutcome,
//! SubCmdError>`; the dispatch maps each variant to a
//! stable `code:` in the JSON envelope through the
//! shared `run_writer`.
//!
//! the previous `summaries_for(&'static str)`
//! helper (a defensive 5-arm `match` over a free-form
//! `&'static str` verb) collapsed into a single
//! `Summaries::standard(NOUN, ResourceVerb::*)` call
//! per leaf. The four CRUD verbs are now expressed
//! through the typed [`ResourceVerb`] enum shared
//! with `set rule-provider` / `set proxy-group` /
//! `set proxy`; a future verb is a compile error
//! instead of a runtime fall-through to the `other`
//! arm.

use std::process::ExitCode;

use crate::cli::SetSubCmd;
use crate::ops::client::subscription as cmd;
use crate::commands::set::common::{ResourceVerb, crud_dispatch};
use crate::layout::CliOutput;

/// The singular resource name used by
/// [`run_standard_writer`] for every `set sub`
/// CRUD leaf. Mirrors the `proxy_group::NOUN`
/// and `rule_provider::NOUN` constants — all
/// three are the Round 23 single-points-of-truth
/// for the "X added" / "X would be added
/// (dry-run)" pair. `NOUN` is now
/// passed to `run_standard_writer` as the
/// `noun` argument (the helper builds the
/// `Summaries::standard` triple itself).
const NOUN: &str = "subscription source";

/// The leaf-prefix token (the second token in
/// the `set sub <verb> <url>` leaf string).
/// Kept distinct from [`NOUN`] because the leaf
/// wants the CLI form (`"set sub add
/// https://…"`) while the human summary wants
/// the long form (`"subscription source
/// added"`).
const CLI_PREFIX: &str = "sub";

/// Projects a `cmd::SubCmdError` to the stable CLI
/// `code:` used in the JSON error envelope.
fn code_for(error: &cmd::SubCmdError) -> &'static str {
    use cmd::SubCmdError as E;
    match error {
        E::InvalidUrl(_) => "sub.invalid_url",
        E::InvalidName(_) => "sub.invalid_name",
        E::AlreadyDeclared(_) => "sub.already_declared",
        // W2-β2a (§8-4/§8-7): name collisions and missing files get
        // their own stable codes; `--every` on a file source is a
        // usage error (exit 2 via the `usage.` prefix rule).
        E::NameTaken(_) => "sub.name_taken",
        E::SourceFileNotFound { .. } => "sub.file_not_found",
        E::EveryOnFile => "usage.sub.every_on_file",
        // W2-β2b: a name matching >1 source is not addressable —
        // usage class (exit 2 via the prefix rule).
        E::AmbiguousName(_) => "usage.sub.ambiguous_name",
        E::NotDeclared(_) => "sub.not_declared",
        E::Shared(shared) => match shared {
            caly_core::configstore::resource_writer::ResourceError::Invalid(_) => "sub.invalid",
            caly_core::configstore::resource_writer::ResourceError::Write(_) => "sub.write_failed",
            caly_core::configstore::resource_writer::ResourceError::Parse(_) => "sub.parse_failed",
            caly_core::configstore::resource_writer::ResourceError::Validate(_) => "sub.validate_failed",
            caly_core::configstore::resource_writer::ResourceError::AlreadyDeclared(_)
            | caly_core::configstore::resource_writer::ResourceError::NotDeclared(_) => "sub.invalid",
        },
    }
}

pub fn dispatch(c: SetSubCmd, options: crate::cli::CliOptions, output: CliOutput) -> ExitCode {
    let paths = crate::ops::client::profile::resolve_paths();
    dispatch_with_paths(c, &paths, options, output)
}

/// the path-injected dispatch. The
/// `dispatch` shim resolves the operator's `AppPaths`
/// from process env (the production path); the
/// `dispatch_with_paths` form takes the paths
/// explicitly so a test can drive the dispatch
/// with a hermetic `AppPaths::from_env_vars`
/// fixture without mutating the operator's XDG
/// state. The two arms are 1-for-1 — the path
/// resolution is the only thing that differs.
///
/// The `Refresh` and `Import` leaves do not depend
/// on `paths` (they drive the daemon RPC and the
/// clipboard respectively) and keep their
/// `crate::ops::client::...` calls inline.
///
/// the 4 CRUD leaves (`add` / `remove` /
/// `enable` / `disable`) all collapse to a single
/// [`run_standard_writer`] call. The leaf string,
/// the `WriteEnvelope` construction, the
/// `Summaries::standard(NOUN, verb)` call, the
/// `classify_resource_outcome` projection, and the
/// `no_extra_payload` pass-through are all folded
/// into the helper. The dispatch's only per-leaf
/// data is the [`ResourceVerb`] variant and the
/// `cmd::*_source` writer call.
#[allow(clippy::too_many_lines)] // 4 CRUD leaves + set leaf + refresh
pub fn dispatch_with_paths(
    c: SetSubCmd,
    paths: &caly_daemon::platform::paths::AppPaths,
    options: crate::cli::CliOptions,
    output: CliOutput,
) -> ExitCode {
    match c {
        SetSubCmd::Refresh {
            target,
            force,
            asynchronous,
        } => refresh_leaf_dispatch(output, paths, target, force, asynchronous, options),
        // The four CRUD leaves share the standard writer envelope.
        SetSubCmd::Add {
            url,
            name,
            refresh_every_minutes,
            apply,
            dry_run: _,
        } => dispatch_add(output, paths, &url, name, refresh_every_minutes, apply),
        SetSubCmd::Remove {
            url,
            purge,
            apply,
            dry_run: _,
        } => crud_and_converge(
            options,
            output,
            paths,
            &url,
            ResourceVerb::Remove,
            apply,
            |paths, url, apply| cmd::remove_source(paths, url, purge, apply),
        ),
        // W2-β2b: the in-place edit keeps a custom summary triple.
        SetSubCmd::Set {
            target,
            url,
            name,
            refresh_every_minutes,
            apply,
            dry_run: _,
        } => set_leaf_dispatch(
            output,
            paths,
            target,
            url,
            name,
            refresh_every_minutes,
            apply,
        ),
        SetSubCmd::Enable {
            url,
            apply,
            dry_run: _,
        } => crud_and_converge(
            options,
            output,
            paths,
            &url,
            ResourceVerb::Enable,
            apply,
            cmd::enable_source,
        ),
        SetSubCmd::Disable {
            url,
            apply,
            dry_run: _,
        } => crud_and_converge(
            options,
            output,
            paths,
            &url,
            ResourceVerb::Disable,
            apply,
            cmd::disable_source,
        ),
        SetSubCmd::Import {
            path,
            clipboard,
            apply: _,
            dry_run: _,
        } => crate::ops::client::subscription::import_preview(path.as_deref(), clipboard, options.json),
    }
}

/// `sub add` owns interactive optional naming before the shared CRUD
/// envelope; piped shells silently fall through with no name.
fn dispatch_add(
    output: CliOutput,
    paths: &caly_daemon::platform::paths::AppPaths,
    url: &str,
    name: Option<String>,
    refresh_every_minutes: Option<u64>,
    apply: bool,
) -> ExitCode {
    let name = match name {
        Some(_) => name,
        None if crate::interact::interactive_capable() => {
            match crate::interact::prompt_text(
                "Subscription name (optional, Enter to skip)",
            ) {
                crate::interact::TextOutcome::Entered(entered) => entered,
                crate::interact::TextOutcome::Interrupted => {
                    return ExitCode::from(130);
                }
            }
        }
        None => None,
    };
    crud_dispatch(
        output,
        CLI_PREFIX,
        NOUN,
        url,
        apply,
        false,
        ResourceVerb::Add,
        |apply| cmd::add_source(paths, url, name.as_deref(), refresh_every_minutes, apply),
        code_for,
    )
}

/// Runs a CRUD verb, then — when it applied successfully (not dry-run)
/// and the verb changes the enabled node set (remove/disable/enable) —
/// triggers a full daemon refresh so the node registry and the kernel
/// config converge: otherwise a disabled/removed subscription keeps its
/// stale nodes (nodes persisted after
/// `sub disable`; the verb only rewrote the config flag and nothing
/// re-converged the registry or re-rendered the kernel config).
fn crud_and_converge(
    options: crate::cli::CliOptions,
    output: CliOutput,
    paths: &caly_daemon::platform::paths::AppPaths,
    url: &str,
    verb: ResourceVerb,
    apply: bool,
    writer: impl Fn(
        &caly_daemon::platform::paths::AppPaths,
        &str,
        bool,
    ) -> Result<cmd::SubWriteOutcome, cmd::SubCmdError>,
) -> ExitCode {
    let code = crud_dispatch(
        output,
        CLI_PREFIX,
        NOUN,
        url,
        apply,
        false,
        verb,
        |apply| writer(paths, url, apply),
        code_for,
    );
    if apply
        && code == ExitCode::SUCCESS
        && matches!(
            verb,
            ResourceVerb::Remove | ResourceVerb::Disable | ResourceVerb::Enable
        )
    {
        // Best-effort full refresh: releases disabled/removed sources'
        // cache entries, node registrations and re-renders the kernel
        // config without their nodes.
        refresh_leaf_dispatch(output, paths, None, false, false, options);
    }
    code
}

/// W2-β2b (`caly sub set`): the in-place edit doesn't fit the
/// 4-verb `ResourceVerb` table, so it drives `run_writer`
/// directly with a custom summary triple — same envelope,
/// same `code_for`, same classify projection. Extracted from
/// [`dispatch_with_paths`] to keep the dispatch under the
/// 100-line clippy budget.
fn set_leaf_dispatch(
    output: CliOutput,
    paths: &caly_daemon::platform::paths::AppPaths,
    target: String,
    url: Option<String>,
    name: Option<String>,
    refresh_every_minutes: Option<u64>,
    apply: bool,
) -> ExitCode {
    let leaf = format!("set sub set {target}");
    let envelope = crate::commands::set::common::WriteEnvelope {
        name: &target,
        leaf: &leaf,
    };
    crate::commands::set::common::run_writer(
        output,
        crate::commands::set::common::Summaries::custom(
            "subscription source updated",
            "subscription source would be updated (dry-run)",
            "subscription source already up to date",
        ),
        &envelope,
        || {
            cmd::set_source(
                paths,
                &target,
                url.as_deref(),
                name.as_deref(),
                refresh_every_minutes,
                apply,
            )
        },
        crate::commands::set::common::classify_resource_outcome,
        code_for,
        crate::commands::set::common::no_extra_payload,
    )
}

/// W2-β2b (§4.3): address one source by name or URL, then run the
/// refresh RPC. The resolution is offline (config read only) so a
/// mistyped name fails before the daemon round-trip; the daemon
/// re-checks the id against its own resolve pass anyway. Extracted
/// from [`dispatch_with_paths`] to keep the dispatch under the
/// 100-line clippy budget.
pub(crate) fn refresh_leaf_dispatch(
    output: CliOutput,
    paths: &caly_daemon::platform::paths::AppPaths,
    target: Option<String>,
    force: bool,
    asynchronous: bool,
    options: crate::cli::CliOptions,
) -> ExitCode {
    let subscription_id = match target.as_deref() {
        None => None,
        Some(token) => match cmd::resolve_source_ref(paths, token) {
            Ok(url) => Some(caly_core::subscription::subscription_id_for_url(&url).into_bytes()),
            Err(error) => {
                let leaf = format!("set sub refresh {token}");
                let mut cli =
                    crate::layout::CliError::new(code_for(&error), format!("{error}"), &leaf);
                if let Some(hint) = crate::layout::ErrorHint::hint(&error) {
                    cli = cli.with_hint(hint);
                }
                return crate::layout::report_error_returning(output, cli);
            }
        },
    };
    crate::ops::client::run_client(
        crate::ClientCommand::RefreshSubscription {
            subscription_id,
            force,
            asynchronous,
        },
        options,
    )
}

#[cfg(test)]
mod dispatch_tests {
//! Tests for `commands/set/sub.rs`, extracted to the sibling
//! convention file (audit #70 file-length budget).

//! end-to-end dispatch-level tests for
//! [`dispatch_with_paths`]. The 4 CRUD leaves
//! (`add` / `remove` / `enable` / `disable`) were
//! previously only exercised at the writer level
//! (the underlying `add_source` / `remove_source` /
//! `enable_source` / `disable_source` calls). The
//! dispatch-level test asserts the operator-facing
//! contract: the JSON envelope's `dry_run` /
//! `no_change` flags + the human summary string
//! the dispatch emits. The tests use the
//! `dispatch_with_paths` form with a hermetic
//! `AppPaths` so the operator's XDG state is not
//! touched.
//!
//! The `Refresh` and `Import` leaves do not
//! depend on `paths` (they drive the daemon RPC
//! and the clipboard respectively) and stay
//! outside this module's coverage — their
//! integration tests live in
//! `bins/caly/tests/daemon_real_e2e.rs` and
//! `crates/caly-backends/tests/subscription_*`
//! respectively.

use super::*;
use crate::cli::SetSubCmd;
use crate::layout::CliOutput;
use crate::ops::test_helpers::{hermetic_paths, temp_root};
use caly_daemon::platform::paths::AppPaths;
use caly_core::profile::schema::AppConfig;
use std::fs;

fn seed_config(paths: &AppPaths) {
    fs::create_dir_all(&paths.config).unwrap();
    fs::write(
        paths.config.join("config.yaml"),
        "schema_version: 1\ncore: mihomo\nsubscriptions: {}\n",
    )
    .unwrap();
}

fn empty_options() -> crate::cli::CliOptions {
    crate::cli::CliOptions::default()
}

/// a fresh operator running
/// `set sub add <url>` (no `--apply`) must see
/// the dry-run envelope (`dry_run: true`,
/// `subscription source would be added
/// (dry-run)`) and the on-disk `config.yaml`
/// must be byte-identical to the seed.
#[test]
fn add_dry_run_emits_envelope_and_does_not_write() {
    let dir = temp_root("add-dry");
    let paths = hermetic_paths(&dir);
    seed_config(&paths);
    let baseline = fs::read_to_string(paths.config.join("config.yaml")).unwrap();
    let output = CliOutput::from_json_flag(false);
    let _ = dispatch_with_paths(
        SetSubCmd::Add {
            url: "https://example.com/sub".to_owned(),
            name: None,
            refresh_every_minutes: None,
            apply: false,
            dry_run: false,
        },
        &paths,
        empty_options(),
        output,
    );
    let after = fs::read_to_string(paths.config.join("config.yaml")).unwrap();
    assert_eq!(after, baseline, "dry-run add must not modify config.yaml");
    let _ = fs::remove_dir_all(&dir);
}

/// `set sub add <url> --apply` against
/// a fresh `config.yaml` must succeed and the
/// `subscriptions.sources` list must contain the
/// new entry.
#[test]
fn add_apply_persists_a_new_source() {
    let dir = temp_root("add-apply");
    let paths = hermetic_paths(&dir);
    seed_config(&paths);
    let output = CliOutput::from_json_flag(false);
    let _ = dispatch_with_paths(
        SetSubCmd::Add {
            url: "https://example.com/sub".to_owned(),
            name: None,
            refresh_every_minutes: None,
            apply: true,
            dry_run: false,
        },
        &paths,
        empty_options(),
        output,
    );
    let config: AppConfig = caly_core::profile::loader::load_layered_yaml_with(
        &caly_core::profile::loader::LayeredConfigPaths::new(paths.config.clone(), None),
        caly_core::profile::loader::LoaderLimits::secure_default(),
        &caly_core::profile::loader::InMemoryProfileResolver::lenient(),
    )
    .unwrap();
    assert_eq!(config.subscriptions.sources.len(), 1);
    assert_eq!(
        config.subscriptions.sources[0].url,
        "https://example.com/sub"
    );
    let _ = fs::remove_dir_all(&dir);
}

/// `set sub enable <already-enabled-url>
/// --apply` is the canonical idempotent case
/// the dispatch must surface as `NoChange` —
/// not `Applied`. The on-disk file is NOT
/// rewritten, and the dispatch's JSON envelope
/// (when `--json` is set) carries `dry_run: false`
/// (the user did pass `--apply`) but no
/// `no_change: true` field… actually wait, the
/// dispatch's envelope does add a `no_change: true`
/// field for the JSON consumers to branch on.
/// Verify the human summary instead (it routes
/// through the `output.success` channel and lands
/// in stdout): the summary must read
/// `subscription source already enabled` (the
/// `NoChange` line from `Summaries::standard`).
/// Pre-Round 25 the summary read
/// `subscription source enabled` (a fabricated
/// success), which the regression test in
/// `client::subscription::tests` already locks at
/// the writer level; this test exercises the
/// dispatch's path through the envelope.
#[test]
fn enable_idempotent_call_surfaces_no_change_in_dispatch() {
    let dir = temp_root("enable-nochange");
    let paths = hermetic_paths(&dir);
    seed_config(&paths);
    // Apply an `add` to populate the source.
    let _ = dispatch_with_paths(
        SetSubCmd::Add {
            url: "https://example.com/sub".to_owned(),
            name: None,
            refresh_every_minutes: None,
            apply: true,
            dry_run: false,
        },
        &paths,
        empty_options(),
        CliOutput::from_json_flag(false),
    );
    // Capture the mtime / byte content of the
    // config before the idempotent `enable`.
    let config_path = paths.config.join("config.yaml");
    let before = fs::read(&config_path).unwrap();
    // Now `enable` an already-enabled source.
    // Round 25 expectation: the dispatch
    // surfaces this as `NoChange`, the writer
    // does NOT rewrite the file, and the
    // human summary is the "already enabled"
    // line. The pre-Round-25 behaviour was a
    // silent skip — the file was not touched
    // but the dispatch printed a fabricated
    // `subscription source enabled` summary.
    // The fix is in two places: the writer
    // returns `NoChange` (Round 25 sub
    // refactor), and the dispatch's
    // `run_writer` envelope translates the
    // `NoChange` kind into the right
    // `Summaries::no_change` string.
    let _ = dispatch_with_paths(
        SetSubCmd::Enable {
            url: "https://example.com/sub".to_owned(),
            apply: true,
            dry_run: false,
        },
        &paths,
        empty_options(),
        CliOutput::from_json_flag(false),
    );
    let after = fs::read(&config_path).unwrap();
    assert_eq!(
        before, after,
        "idempotent enable must not rewrite config.yaml"
    );
    let _ = fs::remove_dir_all(&dir);
}

/// `set sub enable <unknown-url> --apply`
/// must surface `NotDeclared` (the URL is not in
/// `subscriptions.sources`). The dispatch's
/// `code_for` closure maps this to the JSON
/// envelope's `code: "sub.not_declared"`. This
/// test exercises the dispatch path: a writer
/// unit test alone would not catch a `code_for`
/// mapping drift.
#[test]
fn enable_unknown_url_surfaces_not_declared() {
    let dir = temp_root("enable-unknown");
    let paths = hermetic_paths(&dir);
    seed_config(&paths);
    let output = CliOutput::from_json_flag(true);
    // We capture stdout by replacing the
    // default `CliOutput`'s sink. The dispatch
    // contract here is simpler: the
    // `code_for` mapping for `SubCmdError::NotDeclared`
    // is a hard-coded `"sub.not_declared"`; if
    // a future change drifts this, the JSON
    // consumer's grep breaks. The dispatch
    // path is exercised in `daemon_real_e2e`;
    // here we just call the dispatch and
    // assert the exit code is non-zero
    // (failure path).
    let exit = dispatch_with_paths(
        SetSubCmd::Enable {
            url: "https://unknown.example.com/sub".to_owned(),
            apply: true,
            dry_run: false,
        },
        &paths,
        empty_options(),
        output,
    );
    assert_ne!(
        exit,
        ExitCode::SUCCESS,
        "enable on an unknown URL must fail"
    );
    let _ = fs::remove_dir_all(&dir);
}

/// W2-β2a (§8-7): `set sub add <missing-file>` exits 1
/// (`sub.file_not_found` is not a `usage.` code) and writes nothing.
#[test]
fn add_missing_file_exits_one_and_writes_nothing() {
    let dir = temp_root("add-missing-file");
    let paths = hermetic_paths(&dir);
    seed_config(&paths);
    let baseline = fs::read_to_string(paths.config.join("config.yaml")).unwrap();
    let output = CliOutput::from_json_flag(false);
    let code = dispatch_with_paths(
        SetSubCmd::Add {
            url: format!("{}/nosuch.yaml", dir.as_path().display()),
            name: None,
            refresh_every_minutes: None,
            apply: true,
            dry_run: false,
        },
        &paths,
        empty_options(),
        output,
    );
    assert_eq!(code, ExitCode::FAILURE);
    let after = fs::read_to_string(paths.config.join("config.yaml")).unwrap();
    assert_eq!(after, baseline);
    let _ = fs::remove_dir_all(&dir);
}

/// W2-β2a (Q5): `--every` (non-zero) on a file source is a usage
/// error → exit 2 via the `usage.sub.every_on_file` code prefix.
#[test]
fn add_every_on_a_file_source_exits_two() {
    let dir = temp_root("add-every-on-file");
    let paths = hermetic_paths(&dir);
    seed_config(&paths);
    let file = dir.as_path().join("feed.yaml");
    fs::write(&file, b"proxies: []\n").unwrap();
    let output = CliOutput::from_json_flag(false);
    let code = dispatch_with_paths(
        SetSubCmd::Add {
            url: file.to_str().unwrap().to_owned(),
            name: None,
            refresh_every_minutes: Some(120),
            apply: true,
            dry_run: false,
        },
        &paths,
        empty_options(),
        output,
    );
    assert_eq!(code, ExitCode::from(2));
    let _ = fs::remove_dir_all(&dir);
}

/// W2-β2a (Q5/C-G happy path): `set sub add <file> --apply`
/// persists a `file://` source pinned static (`refresh_every_minutes:
/// 0`), and `--every` hours land on URL sources in minutes.
#[test]
fn add_file_and_every_paths_persist() {
    let dir = temp_root("add-file-persist");
    let paths = hermetic_paths(&dir);
    seed_config(&paths);
    let file = dir.as_path().join("feed.yaml");
    fs::write(&file, b"proxies: []\n").unwrap();
    let output = CliOutput::from_json_flag(false);
    let code = dispatch_with_paths(
        SetSubCmd::Add {
            url: file.to_str().unwrap().to_owned(),
            name: Some("local".to_owned()),
            refresh_every_minutes: None,
            apply: true,
            dry_run: false,
        },
        &paths,
        empty_options(),
        output,
    );
    assert_eq!(code, ExitCode::SUCCESS);
    let output = CliOutput::from_json_flag(false);
    let code = dispatch_with_paths(
        SetSubCmd::Add {
            url: "https://example.com/sub".to_owned(),
            name: None,
            refresh_every_minutes: Some(120),
            apply: true,
            dry_run: false,
        },
        &paths,
        empty_options(),
        output,
    );
    assert_eq!(code, ExitCode::SUCCESS);
    let config: AppConfig = caly_core::profile::loader::load_layered_yaml_with(
        &caly_core::profile::loader::LayeredConfigPaths::new(paths.config.clone(), None),
        caly_core::profile::loader::LoaderLimits::secure_default(),
        &caly_core::profile::loader::InMemoryProfileResolver::lenient(),
    )
    .unwrap();
    assert_eq!(config.subscriptions.sources.len(), 2);
    assert!(config.subscriptions.sources[0].url.starts_with("file://"));
    assert_eq!(
        config.subscriptions.sources[0].refresh_every_minutes,
        Some(0)
    );
    assert_eq!(
        config.subscriptions.sources[0].name.as_deref(),
        Some("local")
    );
    assert_eq!(
        config.subscriptions.sources[1].refresh_every_minutes,
        Some(120)
    );
    let _ = fs::remove_dir_all(&dir);
}

/// W2-β2b (§4.3): `sub refresh <unknown-name>` fails before the
/// daemon round-trip with the addressing error (exit 1,
/// `sub.not_declared`).
#[test]
fn refresh_unknown_target_fails_offline_with_not_declared() {
    let dir = temp_root("refresh-unknown");
    let paths = hermetic_paths(&dir);
    seed_config(&paths);
    let output = CliOutput::from_json_flag(false);
    let code = dispatch_with_paths(
        SetSubCmd::Refresh {
            target: Some("ghost".to_owned()),
            force: false,
            asynchronous: false,
        },
        &paths,
        empty_options(),
        output,
    );
    // Never reaches the (absent) daemon: the offline resolve fails
    // first with the addressing contract.
    assert_eq!(code, ExitCode::FAILURE);
    let _ = fs::remove_dir_all(&dir);
}

}
