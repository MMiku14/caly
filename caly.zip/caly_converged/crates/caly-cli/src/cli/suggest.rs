//! "Did you mean?" command and entity suggestion engine based on Levenshtein distance.
//!
//! Provides Git-style command error feedback and typo correction for CLI subcommands,
//! proxy groups, nodes, and profile names.

/// Computes the Levenshtein edit distance between two strings using O(min(M, N)) space.
pub fn levenshtein_distance(a: &str, b: &str) -> usize {
    let a_chars: Vec<char> = a.chars().collect();
    let b_chars: Vec<char> = b.chars().collect();
    let m = a_chars.len();
    let n = b_chars.len();

    if m == 0 {
        return n;
    }
    if n == 0 {
        return m;
    }

    let mut prev_row: Vec<usize> = (0..=n).collect();
    let mut curr_row: Vec<usize> = vec![0; n + 1];

    for (i, &ca) in a_chars.iter().enumerate() {
        curr_row[0] = i + 1;
        for (j, &cb) in b_chars.iter().enumerate() {
            let cost = if ca == cb { 0 } else { 1 };
            curr_row[j + 1] = (prev_row[j + 1] + 1)
                .min(curr_row[j] + 1)
                .min(prev_row[j] + cost);
        }
        prev_row.copy_from_slice(&curr_row);
    }

    prev_row[n]
}

/// Finds the most similar candidate to  from a candidate list if within similarity threshold.
pub fn find_most_similar<'a>(target: &str, candidates: &[&'a str]) -> Option<&'a str> {
    if candidates.is_empty() || target.is_empty() {
        return None;
    }

    let target_len = target.chars().count();
    let max_allowed_distance = match target_len {
        0..=2 => 1,
        3..=5 => 2,
        6..=10 => 3,
        _ => 4,
    };

    let mut best_match: Option<(&'a str, usize)> = None;

    for &candidate in candidates {
        let dist = levenshtein_distance(target, candidate);
        if dist <= max_allowed_distance {
            match best_match {
                None => best_match = Some((candidate, dist)),
                Some((_, best_dist)) if dist < best_dist => {
                    best_match = Some((candidate, dist));
                }
                _ => {}
            }
        }
    }

    best_match.map(|(c, _)| c)
}

/// Formats a Git-style error message for an unknown command with a suggestion if available.
pub fn format_command_error(unknown: &str, valid_commands: &[&str]) -> String {
    if let Some(similar) = find_most_similar(unknown, valid_commands) {
        format!("error: '{unknown}' is not a caly command. The most similar command is '{similar}'.")
    } else {
        format!("error: '{unknown}' is not a caly command. See 'caly --help'.")
    }
}

/// Formats a suggestion for any entity (e.g., node, proxy group, profile).
pub fn format_entity_suggestion(unknown: &str, candidates: &[&str], entity_kind: &str) -> Option<String> {
    find_most_similar(unknown, candidates)
        .map(|similar| format!("The most similar {entity_kind} is '{similar}'."))
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_levenshtein_distance() {
        assert_eq!(levenshtein_distance("", ""), 0);
        assert_eq!(levenshtein_distance("status", "status"), 0);
        assert_eq!(levenshtein_distance("statsu", "status"), 2);
        assert_eq!(levenshtein_distance("statu", "status"), 1);
        assert_eq!(levenshtein_distance("doctor", "doctor"), 0);
    }

    #[test]
    fn test_find_most_similar() {
        let commands = &["status", "node", "sub", "profile", "config", "tun", "doctor"];
        assert_eq!(find_most_similar("statsu", commands), Some("status"));
        assert_eq!(find_most_similar("docotr", commands), Some("doctor"));
        assert_eq!(find_most_similar("tnu", commands), Some("tun"));
        assert_eq!(find_most_similar("prfile", commands), Some("profile"));
        assert_eq!(find_most_similar("zzzzzzzzzzzz", commands), None);
    }

    #[test]
    fn test_format_command_error() {
        let commands = &["status", "node", "sub"];
        assert_eq!(
            format_command_error("statsu", commands),
            "error: 'statsu' is not a caly command. The most similar command is 'status'."
        );
        assert_eq!(
            format_command_error("random_xyz", commands),
            "error: 'random_xyz' is not a caly command. See 'caly --help'."
        );
    }
}
