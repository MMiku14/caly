//! `caly doctor` — offline daemon/environment diagnostics.
//!
//! Each check runs without a running daemon and reports a stable verdict, so a
//! user can diagnose a broken install or runtime path before starting the
//! daemon. Output is human text by default and structured JSON with `--json`.

use std::{
    path::{Path, PathBuf},
    process::Command,
};

use serde::Serialize;

use caly_daemon::platform::paths::AppPaths;

#[cfg(test)]
use checks::{check_tun_cap, resolve_ip_binary};
use checks::{has_cap_net_admin, tun_capability_targets};

/// Stable diagnostic verdict for one check.
#[derive(Clone, Debug, Eq, PartialEq, Serialize)]
#[serde(rename_all = "snake_case")]
pub enum DoctorVerdict {
    Ok,
    Warn,
    Fail,
}

/// Machine-readable evidence attached to an individual diagnostic.
#[derive(Clone, Debug, Eq, PartialEq, Serialize)]
#[serde(tag = "kind", rename_all = "snake_case")]
pub enum DoctorDetail {
    Path {
        path: PathBuf,
        exists: bool,
    },
    UdsPath {
        path: PathBuf,
        safe_to_bind: bool,
    },
    Desktop {
        mode: String,
        supported_backends: Vec<String>,
    },
}

/// One diagnostic result with a stable identifier, human summary and optional
/// structured evidence for scripts.
#[derive(Clone, Debug, Eq, PartialEq, Serialize)]
pub struct DoctorResult {
    #[serde(rename = "check")]
    pub name: String,
    pub category: &'static str,
    pub verdict: DoctorVerdict,
    pub detail: String,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub data: Option<DoctorDetail>,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub remediation: Option<String>,
}

impl DoctorResult {
    fn make(name: &str, verdict: DoctorVerdict, detail: String) -> Self {
        let category = match name {
            "runtime-dir" | "state-dir" | "config-dir" | "core-workdir" => "filesystem",
            "socket" | "uds-safe" => "security",
            "system-proxy" => "desktop",
            _ => "runtime",
        };
        let remediation = match (&verdict, name) {
            (DoctorVerdict::Warn, "config-dir") => Some("run `caly config generate` to create a documented config".to_owned()),
            (DoctorVerdict::Warn, "runtime-dir" | "state-dir" | "core-workdir") => Some("start `caly daemon`; required directories are created automatically".to_owned()),
            (DoctorVerdict::Warn, "socket") => Some("start `caly daemon` if you intend to use client commands".to_owned()),
            (DoctorVerdict::Warn, "system-proxy") => Some("use GNOME, MATE, KDE Plasma, XFCE, LXQt, or a Wayland compositor (niri, sway, Hyprland, …); otherwise configure the system proxy manually".to_owned()),
            (DoctorVerdict::Warn, "core-binaries") | (DoctorVerdict::Fail, "core-binaries") => Some("run scripts/fetch-test-kernels.sh, or point core_binaries at installed executables in the config".to_owned()),
            (DoctorVerdict::Warn, "tun-device") => Some("load the tun kernel module (modprobe tun) or run in an environment that exposes /dev/net/tun; or set tun.enabled to false".to_owned()),
            (DoctorVerdict::Warn, "tun-cap") => Some("run `caly doctor --fix` to grant CAP_NET_ADMIN to ip and the core binaries with a single sudo prompt".to_owned()),
            (DoctorVerdict::Warn, "rp-filter") => Some("run `sysctl -w net.ipv4.conf.all.rp_filter=2` to prevent asymmetric packet drops in TUN policy routing".to_owned()),
            (DoctorVerdict::Warn, "dns-port") => Some("stop systemd-resolved (`systemctl stop systemd-resolved`) or disable DNS stub listener in /etc/systemd/resolved.conf".to_owned()),
            (DoctorVerdict::Warn, "ip-forward") => Some("enable IPv4 packet forwarding with `sysctl -w net.ipv4.ip_forward=1`".to_owned()),
            (DoctorVerdict::Warn, "fake-ip-overlap") => Some("adjust fake-ip-range CIDR in config.yaml to an unused subnet (e.g. 198.18.0.0/15)".to_owned()),
            (DoctorVerdict::Warn, "dns-leak") => Some("ensure nameservers point to the TUN listener or encrypted proxy endpoints to prevent ISP snooping".to_owned()),
            (DoctorVerdict::Fail, "uds-safe") => Some("remove the unsafe socket path only after confirming no daemon owns it, then restart caly".to_owned()),
            (DoctorVerdict::Fail, _) => Some("inspect the diagnostic detail and report a reproducible failure".to_owned()),
            _ => None,
        };
        Self {
            name: name.to_owned(),
            category,
            verdict,
            detail,
            data: None,
            remediation,
        }
    }

    fn with_data(mut self, data: DoctorDetail) -> Self {
        self.data = Some(data);
        self
    }

    fn ok(name: &str, detail: String) -> Self {
        Self::make(name, DoctorVerdict::Ok, detail)
    }
    fn warn(name: &str, detail: String) -> Self {
        Self::make(name, DoctorVerdict::Warn, detail)
    }
    fn fail(name: &str, detail: String) -> Self {
        Self::make(name, DoctorVerdict::Fail, detail)
    }
}

mod checks;

pub use checks::run_checks;

/// Grants `CAP_NET_ADMIN` to every binary that needs it for TUN (the `ip`
/// binary plus the managed core binaries), through ONE sudo prompt. All
/// `setcap` calls run inside a single escalated `sh -c`, so the user
/// authenticates once; sudo's credential cache covers the whole batch.
/// Idempotent: binaries that already carry the capability are skipped.

/// Strictly verifies that a binary path is safe to receive elevated privileges via `sudo setcap`.
/// Rejects symlinks, world-writable files, and binaries in temporary or untrusted directories.
/// Strictly verifies that a binary path is safe to receive elevated privileges via `sudo setcap`.
/// Rejects symlinks, world-writable or untrusted group-writable files, binaries in temporary or
/// shared directories, and files outside trusted root prefixes.
pub fn verify_safe_setcap_target(path: &Path, paths: &AppPaths) -> Result<(), String> {
    let symlink_meta = std::fs::symlink_metadata(path)
        .map_err(|e| format!("cannot read metadata for {}: {e}", path.display()))?;
    if symlink_meta.file_type().is_symlink() {
        return Err(format!("refusing to grant capability to symlink: {}", path.display()));
    }
    if !symlink_meta.is_file() {
        return Err(format!("target is not a regular file: {}", path.display()));
    }
    #[cfg(unix)]
    {
        use std::os::unix::fs::PermissionsExt as _;
        let mode = symlink_meta.permissions().mode();
        if (mode & 0o002) != 0 {
            return Err(format!("refusing to grant capability to world-writable file: {}", path.display()));
        }
        if (mode & 0o020) != 0 {
            use std::os::unix::fs::MetadataExt as _;
            let gid = symlink_meta.gid();
            // Reject group-writable files unless owned by root (GID 0)
            if gid != 0 {
                return Err(format!(
                    "refusing to grant capability to group-writable file owned by non-root GID {gid}: {}",
                    path.display()
                ));
            }
        }
    }
    let canonical = path.canonicalize()
        .map_err(|e| format!("cannot canonicalize path {}: {e}", path.display()))?;
    let canonical_str = canonical.to_string_lossy();
    if canonical_str.starts_with("/tmp")
        || canonical_str.starts_with("/var/tmp")
        || canonical_str.starts_with("/dev/shm")
        || canonical_str.starts_with("/run/user")
    {
        return Err(format!(
            "refusing to grant capability to binary in temporary directory: {canonical_str}"
        ));
    }
    // Verify canonical path belongs to safe roots (/usr, /opt, /bin, /sbin, or AppPaths data/core dirs)
    let safe_system_roots = [
        Path::new("/usr"),
        Path::new("/opt"),
        Path::new("/bin"),
        Path::new("/sbin"),
    ];
    let is_safe_system = safe_system_roots.iter().any(|root| canonical.starts_with(root));
    let is_safe_app_data = canonical.starts_with(&paths.data);
    let is_safe_app_core = paths.core_binaries_dir().canonicalize().map_or(false, |p| canonical.starts_with(p));

    if !is_safe_system && !is_safe_app_data && !is_safe_app_core {
        return Err(format!(
            "refusing to grant capability: path {canonical_str} is outside trusted roots (/usr, /opt, and app data)"
        ));
    }
    Ok(())
}

pub fn grant_tun_capabilities() -> Result<(), String> {
    let paths = AppPaths::from_env();
    let targets = tun_capability_targets(&paths);
    let mut missing = Vec::new();
    for (label, path) in &targets {
        if !path.exists() {
            println!("doctor: {label} {} — missing, skipping", path.display());
            continue;
        }
        if let Err(err) = verify_safe_setcap_target(path, &paths) {
            println!("doctor: {label} {} — insecure target skipped: {err}", path.display());
            continue;
        }
        if has_cap_net_admin(path) {
            println!(
                "doctor: {label} {} — already has CAP_NET_ADMIN",
                path.display()
            );
        } else {
            println!("doctor: {label} {} — needs CAP_NET_ADMIN", path.display());
            missing.push(path.clone());
        }
    }
    if missing.is_empty() {
        crate::layout::ok("nothing to grant");
        return Ok(());
    }
    // One escalated batch: quote every path as a single shell word.
    for path in &missing {
        let status = Command::new("sudo")
            .args(["setcap", "cap_net_admin=+ep"])
            .arg(path)
            .status()
            .map_err(|error| format!("cannot run sudo setcap on {}: {error}", path.display()))?;
        if !status.success() {
            return Err(format!(
                "sudo setcap failed for {} (check password and that setcap is installed)",
                path.display()
            ));
        }
    }
    crate::layout::ok(&format!(
        "granted CAP_NET_ADMIN to {} binary(ies)",
        missing.len()
    ));
    Ok(())
}

/// Quotes a path for embedding into a shell word, escaping single quotes.
fn shell_quote(path: &Path) -> String {
    path.to_string_lossy().replace('\'', "'\\''")
}

/// Mirrors the composition-root fallback resolution for a managed
/// core executable, in priority order:
///
/// 1. `vendor/bin/<name>` next to any ancestor of the running
///    executable (covers the dev tree: `target/debug/caly`'s
///    ancestors include the repository root that
///    `scripts/fetch-test-kernels.sh` populates).
/// 2. A `PATH` lookup (distro-packaged / manually installed
///    `mihomo` / `sing-box`).
/// 3. `<XDG_DATA_HOME>/caly/vendor/bin/<name>` — the stable,
///    CWD-independent install location used as the eventual
///    report path when nothing resolvable exists yet.
///
/// The previous shape's final fallback was the bare CWD-relative
/// `vendor/bin/<name>`, so doctor's core-binaries verdict changed
/// with the directory the operator happened to run it from (#51).
pub(crate) fn bundled_core_binary(name: &str, data_dir: &Path) -> PathBuf {
    // 1. Check local kernel store from `core install`/`core upgrade`
    let kernel_dir = data_dir.join("kernels").join(name);
    if let Ok(entries) = std::fs::read_dir(&kernel_dir) {
        let mut versions: Vec<String> = entries
            .filter_map(|e| e.ok())
            .filter(|e| e.file_type().map_or(false, |t| t.is_dir()))
            .filter_map(|e| e.file_name().into_string().ok())
            .collect();
        versions.sort();
        while let Some(ver) = versions.pop() {
            let candidate = kernel_dir.join(&ver).join(name);
            if candidate.is_file() && is_executable(&candidate) {
                return candidate;
            }
        }
    }
    // 2. Check system PATH
    if let Some(found) = lookup_path(name) {
        return found;
    }
    // 3. Check vendor/bin in executable ancestors (development fallback)
    if let Ok(executable) = std::env::current_exe() {
        for directory in executable.ancestors() {
            let candidate = directory.join("vendor").join("bin").join(name);
            if candidate.is_file() {
                return candidate;
            }
        }
    }
    data_dir.join("vendor").join("bin").join(name)
}

pub(crate) fn lookup_path(name: &str) -> Option<PathBuf> {
    let path_var = std::env::var_os("PATH")?;
    for directory in std::env::split_paths(&path_var) {
        if directory.as_os_str().is_empty() {
            continue;
        }
        let candidate = directory.join(name);
        if candidate.is_file() && is_executable(&candidate) {
            return Some(candidate);
        }
    }
    None
}

pub(crate) fn is_executable(path: &Path) -> bool {
    use std::os::unix::fs::PermissionsExt;
    path.metadata()
        .is_ok_and(|meta| meta.is_file() && meta.permissions().mode() & 0o111 != 0)
}

/// Renders the diagnostics as human-readable lines.
pub fn render_human(results: &[DoctorResult]) -> String {
    // One adaptive table instead of the hand-aligned lanes; verdicts
    // take the suite palette (paint is TTY-gated inside the style).
    let rows: Vec<Vec<String>> = results
        .iter()
        .map(|result| {
            let mark = match result.verdict {
                DoctorVerdict::Ok => crate::layout::Style::Green.apply("ok"),
                DoctorVerdict::Warn => crate::layout::Style::Yellow.apply("warn"),
                DoctorVerdict::Fail => crate::layout::Style::Red.apply("fail"),
            };
            vec![
                mark,
                crate::layout::strip_controls(&result.name),
                crate::layout::strip_controls(&result.detail),
            ]
        })
        .collect();
    let mut out = crate::layout::render_table(
        crate::layout::TableMode::Table,
        &["STATUS", "CHECK", "DETAIL"],
        &rows,
        None,
    )
    .join("\n");
    out.push('\n');
    out
}

/// Renders the diagnostics as one-line JSON.
pub fn render_json(results: &[DoctorResult]) -> Result<String, serde_json::Error> {
    serde_json::to_string(results)
}

/// Returns whether any check failed (used for the process exit code).
pub fn any_failed(results: &[DoctorResult]) -> bool {
    results.iter().any(|r| r.verdict == DoctorVerdict::Fail)
}

#[cfg(test)]
mod doctor_tests;
