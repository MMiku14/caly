//! The Subs tab: `sub list` rows inside the TUI.
//!
//! Same columns, same cells, same helpers as the one-shot listing —
//! the only difference is the sink (screen lines instead of stdout),
//! so the two faces can never disagree. Read-only in v1: `R`
//! refreshes every source, per-source actions stay in `caly sub`.

use super::Snapshot;

pub(super) const HEADERS: [&str; 9] = [
    "ID",
    "NAME",
    "TYPE",
    "SOURCE",
    "NODES",
    "GROUPS",
    "LAST REFRESH",
    "NEXT REFRESH",
    "STATUS",
];

/// Table rows for every declared source, mirroring
/// `subscription::listing` cell-for-cell (relative times, joined group
/// names, suite status badge).
pub(super) fn render_rows(snapshot: &Snapshot) -> Vec<Vec<String>> {
    let now = crate::layout::now_unix();
    snapshot
        .sources
        .iter()
        .map(|source| {
            let groups = source
                .groups
                .iter()
                .map(caly_core::domain::BoundedText::as_str)
                .collect::<Vec<_>>()
                .join(", ");
            vec![
                source.index.to_string(),
                source.name.as_str().to_owned(),
                source.kind.as_str().to_owned(),
                source.url.as_str().to_owned(),
                source.nodes.to_string(),
                groups,
                crate::layout::relative_time(now, source.last_refresh_unix),
                crate::layout::relative_time(now, source.next_refresh_unix),
                crate::layout::source_badge(source.enabled, source.cached),
            ]
        })
        .collect()
}

#[cfg(test)]
mod tests {
    use super::super::fixtures::tests::fixture_snapshot;
    use super::*;

    #[test]
    fn rows_mirror_sub_list_cells() {
        let rows = render_rows(&fixture_snapshot(1));
        assert_eq!(rows.len(), 1);
        assert_eq!(
            rows[0][..7],
            [
                "1".to_owned(),
                "demo".to_owned(),
                "subscription".to_owned(),
                "https://example.com/sub".to_owned(),
                "2".to_owned(),
                "select".to_owned(),
                crate::layout::relative_time(crate::layout::now_unix(), Some(1_700_000_000)),
            ]
        );
        // Off-terminal the badge is the bare glyph (paint gates on TTY).
        assert_eq!(rows[0][8], "●");
    }
}
