//! Frame assembly: header, tab bar, rule, body window, footer.
//!
//! The only impure input is the [`Tui`](super::app::Tui) state —
//! [`frame`] itself is a pure function of (state, width, height), so
//! every layout rule is unit-tested without a terminal. Screen chrome
//! costs four lines (header, tab bar, rule, footer); the body list
//! comes memoized from [`super::body`] and is sliced here to the
//! visible window, clamped to its real line count so `G` on a short tab
//! cannot overscroll into blankness. An open popup dims the body and
//! splices its box over the center.

use super::{Snapshot, Tab, app::Tui};

/// Screen lines outside the body: header, tab bar, rule, footer.
const CHROME_LINES: usize = 4;

/// Every screen line: exactly `height` lines (padded, then truncated).
pub(super) fn frame(tui: &Tui, width: usize, height: usize) -> Vec<String> {
    let mut lines = Vec::new();
    if let Some(snapshot) = tui.snapshot.as_ref() {
        lines.push(header_line(snapshot, width));
        lines.push(tabs_line(tui.tab));
        lines.push(crate::layout::paint("2", &"─".repeat(width)));
        let body_height = height.saturating_sub(CHROME_LINES).max(1);
        let (full, rows) = super::body::full_body(tui, snapshot, width);
        let mut body = window(
            &full,
            super::body::cursor_abs(tui, rows, full.len()),
            tui.scroll[tui.tab.index()],
            body_height,
        );
        if let Some(popup) = tui.popup.as_ref() {
            for line in &mut body {
                *line = crate::layout::paint("2", line);
            }
            if let Some(view) = super::popup::view(popup, snapshot, &tui.sweep_overlay) {
                let box_lines =
                    super::popup::boxed(&view, super::popup::scroll_of(popup), width, body_height);
                super::popup::overlay_centered(&mut body, &box_lines, width);
            }
        }
        lines.extend(body);
    } else {
        lines.push(crate::layout::paint("1", "caly tui (offline)"));
        lines.push(String::new());
        lines.push(
            tui.fetch_error
                .clone()
                .unwrap_or_else(|| "connecting…".to_owned()),
        );
        lines.push(String::new());
        lines.push("start the daemon (`caly daemon`) or press r to retry.".to_owned());
    }
    while lines.len() + 1 < height {
        lines.push(String::new());
    }
    lines.push(super::footer::footer_line(tui, width));
    lines.truncate(height.max(1));
    lines
}

/// One-line status header from the shared projections.
fn header_line(snapshot: &Snapshot, width: usize) -> String {
    let mode = crate::ops::client::output::mode_label(snapshot.desired.mode);
    let core = snapshot.applied.core_kind.map_or_else(
        || "core: —".to_owned(),
        |kind| format!("core: {}", crate::ops::client::output::core_label(kind)),
    );
    let traffic = format!(
        "↓{} ↑{}",
        crate::layout::human_bytes(snapshot.observed.download_bytes_per_second),
        crate::layout::human_bytes(snapshot.observed.upload_bytes_per_second)
    );
    let line = format!(
        "{}  {core}  mode: {mode}  nodes: {}  {traffic}  rev: {}",
        crate::layout::paint("1", "caly tui"),
        snapshot.nodes.len(),
        snapshot.revision
    );
    crate::layout::truncate_visible(&line, width)
}

fn tabs_line(active: Tab) -> String {
    Tab::ALL
        .iter()
        .enumerate()
        .map(|(index, tab)| {
            let token = format!("{}:{}", index + 1, tab.title());
            if *tab == active {
                crate::layout::paint("1", &token)
            } else {
                crate::layout::paint("2", &token)
            }
        })
        .collect::<Vec<_>>()
        .join("  ")
}

fn window(
    all: &[String],
    cursor_abs: Option<usize>,
    scroll: usize,
    body_height: usize,
) -> Vec<String> {
    if all.is_empty() {
        return Vec::new();
    }
    let mut start = scroll.min(all.len().saturating_sub(1));
    if let Some(cursor) = cursor_abs {
        let cursor = cursor.min(all.len().saturating_sub(1));
        if cursor < start {
            start = cursor;
        } else if cursor >= start + body_height {
            start = cursor + 1 - body_height.min(all.len());
        }
    }
    all.iter()
        .skip(start)
        .take(body_height)
        .enumerate()
        .map(|(index, line)| {
            if cursor_abs.is_some_and(|cursor| start + index == cursor.min(all.len() - 1)) {
                crate::layout::paint("7", line)
            } else {
                line.clone()
            }
        })
        .collect()
}

#[cfg(test)]
mod tests {
    use super::super::app::Tui;
    use super::super::fixtures::tests::fixture_snapshot;
    use super::*;

    fn online_tui() -> Tui {
        let mut tui = Tui::new(None);
        tui.snapshot = Some(fixture_snapshot(3));
        tui
    }

    #[test]
    fn offline_frame_explains_and_offers_retry() {
        let mut tui = Tui::new(None);
        tui.fetch_error = Some("daemon unreachable: nope".to_owned());
        let frame = frame(&tui, 80, 24);
        assert_eq!(frame.len(), 24);
        assert!(frame[0].contains("offline"));
        assert!(frame[2].contains("nope"));
        assert!(frame[23].contains('q'));
    }

    #[test]
    fn online_frame_marks_the_cursor_row() {
        let mut tui = online_tui();
        tui.cursor[Tab::Nodes.index()] = 1;
        let frame = frame(&tui, 100, 24);
        assert!(frame[0].contains("nodes: 3"));
        assert!(frame[1].contains("2:Groups"), "{}", frame[1]);
        assert!(frame[2].contains('─'), "{}", frame[2]);
        let highlighted: Vec<&String> = frame
            .iter()
            .filter(|line| line.contains("\x1b[7m"))
            .collect();
        assert_eq!(highlighted.len(), 1);
        assert!(highlighted[0].contains("node-1"));
    }

    #[test]
    fn help_popup_overlays_a_dimmed_body() {
        let mut tui = online_tui();
        tui.popup = Some(super::super::popup::Popup::Help { scroll: 0 });
        let frame = frame(&tui, 100, 24);
        assert!(frame.iter().any(|line| line.contains("Shift-Tab")));
        assert!(frame.iter().any(|line| line.contains('╭')), "box top");
        assert!(
            frame.iter().any(|line| line.contains("\x1b[2m")),
            "dimmed body"
        );
    }

    #[test]
    fn node_popup_shows_identity_with_its_box() {
        let mut tui = online_tui();
        tui.popup = Some(super::super::popup::Popup::Node {
            node_id: [2u8; 16],
            scroll: 0,
        });
        let frame = frame(&tui, 100, 24);
        assert!(frame.iter().any(|line| line.contains("node-2")));
        assert!(
            frame
                .iter()
                .any(|line| line.contains(&caly_core::domain::to_hex([2u8; 16])))
        );
    }

    #[test]
    fn empty_filter_result_explains_the_escape_hatch() {
        let mut tui = online_tui();
        tui.filter = "hk".to_owned();
        let frame = frame(&tui, 100, 24);
        assert!(
            frame
                .iter()
                .any(|line| line.contains("no node matches `hk`"))
        );
        assert!(frame[23].contains("filter: hk"), "{}", frame[23]);
    }
}
