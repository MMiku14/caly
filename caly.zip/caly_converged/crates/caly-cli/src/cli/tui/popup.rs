//! Secondary windows: centered modal popups over a dimmed body.
//!
//! Four windows: node details (`v`), source details (`Enter` on Subs),
//! core switch (`C`, radio + two-step confirm), and help (`?`). A popup
//! is content ([`PopupView`]) plus chrome ([`boxed`]): the frame dims
//! the body, splices the box over its center, and routes keys to the
//! popup until `Esc`/`q` closes it (all other keys are swallowed —
//! popups are modal, except Ctrl-C which always quits).
//!
//! Geometry: the box hugs its content (title, longest line, and hint
//! all count toward the inner width), clamped to the terminal minus a
//! margin; over-tall content scrolls with `▲`/`▼` borrowed from the
//! corner glyphs so no column math can wobble.

use std::collections::HashMap;

use super::Snapshot;

/// Switchable cores (Xray stays out: unsupported-vs-alias is undecided).
pub(super) const CORES: [&str; 2] = ["mihomo", "sing-box"];

/// An open secondary window with its interaction state.
#[derive(Clone, Debug, Eq, PartialEq)]
pub(super) enum Popup {
    Help { scroll: usize },
    Node { node_id: [u8; 16], scroll: usize },
    Source { index: u32, scroll: usize },
    Cores { selected: usize, armed: bool },
    Settings { selected: usize },
}

/// Settings rows, in display order. `from_index` wraps so cursor
/// movement never needs a bounds check.
#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub(super) enum SettingsRow {
    Mode,
    Tun,
    SysProxy,
    Core,
    RefreshAll,
}

impl SettingsRow {
    pub(super) const COUNT: usize = 5;

    pub(super) fn from_index(index: usize) -> Self {
        match index % Self::COUNT {
            0 => Self::Mode,
            1 => Self::Tun,
            2 => Self::SysProxy,
            3 => Self::Core,
            _ => Self::RefreshAll,
        }
    }
}

/// Popup content before chrome: title, plain lines, footer hint.
pub(super) struct PopupView {
    pub(super) title: String,
    pub(super) lines: Vec<String>,
    pub(super) hint: String,
}

/// Builds the popup content for the live snapshot. Returns `None` when
/// the popup's target vanished (node/source gone from a fresh
/// snapshot) — the caller closes the popup instead of showing ghosts.
pub(super) fn view(
    popup: &Popup,
    snapshot: &Snapshot,
    overlay: &HashMap<String, Option<u32>>,
) -> Option<PopupView> {
    match popup {
        Popup::Help { .. } => Some(PopupView {
            title: "keys".to_owned(),
            lines: super::popup_views::HELP_LINES.map(str::to_owned).to_vec(),
            hint: "Esc close".to_owned(),
        }),
        Popup::Node { node_id, .. } => {
            let node = snapshot
                .nodes
                .iter()
                .find(|node| node.node_id == *node_id)?;
            let selected = snapshot.applied.selected_node_id == Some(*node_id);
            Some(super::popup_views::node_view(node, selected, overlay))
        }
        Popup::Source { index, .. } => {
            let source = snapshot
                .sources
                .iter()
                .find(|source| source.index == *index)?;
            Some(super::popup_views::source_view(source))
        }
        Popup::Cores { selected, armed } => {
            Some(super::popup_views::cores_view(snapshot, *selected, *armed))
        }
        Popup::Settings { selected } => {
            Some(super::popup_views::settings_view(snapshot, *selected))
        }
    }
}

/// Content scroll offset (the radio and settings popups never scroll).
pub(super) fn scroll_of(popup: &Popup) -> usize {
    match popup {
        Popup::Help { scroll } | Popup::Node { scroll, .. } | Popup::Source { scroll, .. } => {
            *scroll
        }
        Popup::Cores { .. } | Popup::Settings { .. } => 0,
    }
}

/// Wraps content in a bordered, titled box clamped to the terminal. The
/// hint renders dimmed; over-tall content scrolls from `scroll`
/// (clamped), with `▲`/`▼` replacing the corner glyphs.
pub(super) fn boxed(
    view: &PopupView,
    scroll: usize,
    width: usize,
    body_height: usize,
) -> Vec<String> {
    let inner_max = width.saturating_sub(4).max(8);
    let mut inner = crate::layout::visible_width(&view.title) + 2;
    inner = inner.max(crate::layout::visible_width(&view.hint));
    for line in &view.lines {
        inner = inner.max(crate::layout::visible_width(line));
    }
    let inner = inner.min(inner_max).max(4);

    // Every row is exactly `inner + 4` columns: content rows are
    // `│␣…inner…␣│`, and both rules match that width.
    let title_text = crate::layout::truncate_visible(&view.title, inner.saturating_sub(1).max(1));
    let dashes =
        "─".repeat((inner + 3).saturating_sub(3 + crate::layout::visible_width(&title_text) + 1));

    let visible_rows = body_height.saturating_sub(3).max(1);
    let start = scroll.min(view.lines.len().saturating_sub(1));
    let end = (start + visible_rows).min(view.lines.len());
    let more_above = start > 0;
    let more_below = end < view.lines.len();

    let mut out = Vec::new();
    out.push(format!(
        "╭─ {title_text} {dashes}{}",
        if more_above { "▲" } else { "╮" }
    ));
    for line in view.lines.iter().skip(start).take(visible_rows) {
        out.push(format!("│ {} │", pad_to(line, inner)));
    }
    out.push(format!(
        "│ {} │",
        crate::layout::paint("2", &pad_to(&view.hint, inner))
    ));
    out.push(format!(
        "╰{}{}",
        "─".repeat(inner + 2),
        if more_below { "▼" } else { "╯" }
    ));
    out
}

/// Truncates to `inner` visible columns, then space-pads to exactly that.
fn pad_to(text: &str, inner: usize) -> String {
    let cell = crate::layout::truncate_visible(text, inner);
    format!(
        "{cell}{}",
        " ".repeat(inner.saturating_sub(crate::layout::visible_width(&cell)))
    )
}

/// Splices the box over the vertical + horizontal center of the body
/// window (the body is already dimmed by the caller).
pub(super) fn overlay_centered(body: &mut [String], box_lines: &[String], width: usize) {
    if body.is_empty() || box_lines.is_empty() {
        return;
    }
    let box_width = box_lines
        .iter()
        .map(|line| crate::layout::visible_width(line))
        .max()
        .unwrap_or(0);
    let left = (width.saturating_sub(box_width)) / 2;
    let start_row = (body.len().saturating_sub(box_lines.len())) / 2;
    for (offset, line) in box_lines.iter().enumerate() {
        let row = start_row + offset;
        if row >= body.len() {
            break;
        }
        let padded = format!(
            "{line}{}",
            " ".repeat(box_width.saturating_sub(crate::layout::visible_width(line)))
        );
        body[row] = format!("{}{padded}", " ".repeat(left));
    }
}

#[cfg(test)]
mod tests {
    use super::super::fixtures::tests::fixture_snapshot;
    use super::*;

    fn snapshot() -> Snapshot {
        fixture_snapshot(2)
    }

    #[test]
    fn vanished_targets_close_instead_of_ghosting() {
        let popup = Popup::Node {
            node_id: [9u8; 16],
            scroll: 0,
        };
        assert!(view(&popup, &snapshot(), &HashMap::new()).is_none());
        let popup = Popup::Source {
            index: 99,
            scroll: 0,
        };
        assert!(view(&popup, &snapshot(), &HashMap::new()).is_none());
    }

    #[test]
    fn settings_view_dispatches_with_five_rows() {
        let popup = Popup::Settings { selected: 0 };
        let view = view(&popup, &snapshot(), &HashMap::new()).expect("settings view");
        assert_eq!(view.title, "settings");
        assert_eq!(view.lines.len(), SettingsRow::COUNT);
    }

    #[test]
    fn box_hugs_content_and_clamps_to_the_terminal() {
        let view = PopupView {
            title: "t".to_owned(),
            lines: vec!["hi".to_owned()],
            hint: "q".to_owned(),
        };
        let narrow = boxed(&view, 0, 80, 20);
        assert!(narrow[0].starts_with("╭─ t "), "{}", narrow[0]);
        assert!(narrow[1].contains("hi"), "{}", narrow[1]);
        assert!(narrow.last().expect("bottom").starts_with('╰'));
        for line in &narrow {
            assert!(crate::layout::visible_width(line) <= 80, "{line}");
        }
        let tiny = boxed(&view, 0, 20, 20);
        for line in &tiny {
            assert!(crate::layout::visible_width(line) <= 20, "{line}");
        }
    }

    #[test]
    fn tall_content_scrolls_with_corner_indicators() {
        let view = PopupView {
            title: "t".to_owned(),
            lines: (0..30).map(|i| format!("line-{i}")).collect(),
            hint: "q".to_owned(),
        };
        let first = boxed(&view, 0, 80, 10);
        assert!(first[0].ends_with('╮'), "{}", first[0]);
        assert!(first.last().expect("bottom").ends_with('▼'));
        assert!(first[1].contains("line-0"));
        let scrolled = boxed(&view, 25, 80, 10);
        assert!(scrolled[0].ends_with('▲'), "{}", scrolled[0]);
        assert!(scrolled[1].contains("line-25"));
    }

    #[test]
    fn overlay_lands_centered_over_the_body() {
        let mut body: Vec<String> = (0..20).map(|i| format!("body-{i}")).collect();
        let view = PopupView {
            title: "t".to_owned(),
            lines: vec!["hi".to_owned()],
            hint: "q".to_owned(),
        };
        let box_lines = boxed(&view, 0, 80, 20);
        overlay_centered(&mut body, &box_lines, 80);
        assert_eq!(body.len(), 20);
        // Box is 4 lines tall over a 20-line body: starts at row 8.
        assert!(body[8].contains("╭"), "{}", body[8]);
        assert!(body[7].contains("body-"), "{}", body[7]);
        assert!(body[8].starts_with(' '), "{}", body[8]);
    }
}
