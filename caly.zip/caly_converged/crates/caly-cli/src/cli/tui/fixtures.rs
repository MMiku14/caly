//! Shared snapshot fixtures for the TUI view tests.
//!
//! One minimal-but-complete [`Snapshot`](super::Snapshot): every nested
//! state struct is filled (never `Default`), so a test that reads a new
//! field fails loudly here instead of silently rendering a default.

#[cfg(test)]
pub(crate) mod tests {
    use super::super::{Snapshot, Tab};
    use caly_daemon::protocol::protocol::v2;

    /// Minimal snapshot with `nodes` display nodes (`node-0…`) plus one
    /// group, one source, and one capability. Node `i` has id `[i; 16]`
    /// and latency `10*i` ms, so tests can address rows by index.
    pub(crate) fn fixture_snapshot(nodes: usize) -> Snapshot {
        Snapshot {
            daemon_instance_id: [0u8; 16],
            revision: 7,
            cursor: v2::WireEventCursor {
                daemon_instance_id: [0u8; 16],
                sequence: 1,
            },
            desired: v2::WireDesiredState {
                mode: 1,
                selected_node_id: None,
                active_subscription_id: None,
                tun_requested: false,
                system_proxy_requested: false,
            },
            applied: v2::WireAppliedState {
                core_kind: None,
                run_state: 0,
                selected_node_id: None,
                config_generation: None,
            },
            observed: v2::WireObservedState {
                upload_bytes_per_second: 0,
                download_bytes_per_second: 0,
                active_connections: 0,
                telemetry_dropped: 0,
                core_restart_count: 0,
                core_restart_backoff_ms: 0,
            },
            platform: v2::WirePlatformEffect {
                proxy_engaged: false,
                tun_engaged: false,
                recovery_pending: false,
                degraded_reason: None,
            },
            capabilities: caly_core::domain::BoundedVec::try_from_vec(vec![v2::WireCapabilityStatus {
                capability: 4,
                configured: 1,
                runtime: 1,
                caveat: None,
            }])
            .expect("fixture capability fits the bound"),
            nodes: caly_core::domain::BoundedVec::try_from_vec(
                (0..nodes)
                    .map(|index| v2::WireDisplayNode {
                        node_id: [u8::try_from(index).unwrap_or(0); 16],
                        name: format!("node-{index}"),
                        protocol: "vmess".to_owned(),
                        available: true,
                        latency_ms: Some(10 * u32::try_from(index).unwrap_or(0)),
                    })
                    .collect::<Vec<_>>(),
            )
            .expect("fixture nodes fit the bound"),
            proxy_groups: caly_core::domain::BoundedVec::try_from_vec(vec![v2::WireProxyGroup {
                name: "select".to_owned(),
                kind: "Selector".to_owned(),
                selected: Some("node-0".to_owned()),
                members: vec!["node-0".to_owned(), "node-1".to_owned()],
            }])
            .expect("fixture group fits the bound"),
            sources: caly_core::domain::BoundedVec::try_from_vec(vec![v2::WireSourceView {
                index: 1,
                name: caly_core::domain::BoundedText::new("demo").expect("fixture name fits"),
                kind: caly_core::domain::BoundedText::new("subscription").expect("fixture kind fits"),
                url: caly_core::domain::BoundedText::new("https://example.com/sub")
                    .expect("fixture url fits"),
                enabled: true,
                nodes: 2,
                groups: caly_core::domain::BoundedVec::try_from_vec(vec![
                    caly_core::domain::BoundedText::new("select").expect("fixture group fits"),
                ])
                .expect("fixture groups fit the bound"),
                last_refresh_unix: Some(1_700_000_000),
                next_refresh_unix: None,
                cached: true,
            }])
            .expect("fixture source fits the bound"),
        }
    }

    /// Simulates one modifier-free keypress, returning the quit flag.
    pub(crate) fn press(tui: &mut super::super::app::Tui, code: crossterm::event::KeyCode) -> bool {
        tui.handle_key(code, crossterm::event::KeyModifiers::empty())
    }

    /// Asserts every tab index round-trips (keeps `Tab::ALL` and the
    /// cursor/scroll arrays honest when a tab is added).
    #[test]
    fn every_tab_round_trips_through_its_index() {
        for tab in [Tab::Nodes, Tab::Groups, Tab::Status, Tab::Subs] {
            assert_eq!(Tab::from_index(tab.index()), tab);
        }
    }
}
