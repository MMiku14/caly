//! Offline subscription parsing diagnostics (`caly sub check`).
//!
//! Reads a subscription file (Clash YAML, direct URI lines, or Base64 URI
//! aggregate), detects its format, and reports the parsed node count and any
//! rejected lines. This is a pure, offline preview of what the daemon's
//! subscription pipeline would ingest.

use std::path::Path;

use caly_core::domain::SubscriptionId;
use caly_core::subscription::{SubscriptionFormat, decode_document, parse_uri_body_to_display_lossy};

/// Outcome of parsing a subscription file.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct SubscriptionSummary {
    pub format: String,
    pub node_count: usize,
    pub rejected_lines: usize,
    /// Recognized `ssr://` nodes skipped (SSR is not representable).
    pub ssr_skipped: usize,
    pub names: Vec<String>,
    /// Optional Clash subscription quota metadata (upload/download/total/expire).
    pub userinfo: caly_core::subscription::SubscriptionUserInfo,
}

/// Reads and parses `path`, returning a human-readable summary. An optional
/// The summary userinfo when no `subscription-userinfo` header was present.
fn userinfo_or_default(userinfo_header: Option<&str>) -> caly_core::subscription::SubscriptionUserInfo {
    userinfo_header.map_or_else(
        || caly_core::subscription::SubscriptionUserInfo {
            upload_bytes: None,
            download_bytes: None,
            total_bytes: None,
            expire_unix: None,
        },
        caly_core::subscription::parse_subscription_userinfo,
    )
}

/// The url-list summary shape: no offline nodes, entries only (the daemon
/// fetches and merges the children during refresh).
fn url_list_summary<'a>(
    lines: impl Iterator<Item = &'a str>,
    userinfo: caly_core::subscription::SubscriptionUserInfo,
) -> SubscriptionSummary {
    SubscriptionSummary {
        format: "url-list".to_owned(),
        node_count: 0,
        rejected_lines: 0,
        ssr_skipped: 0,
        names: lines.map(str::to_owned).collect(),
        userinfo,
    }
}

/// The ssr-only summary shape: all lines were SSR nodes.
fn ssr_only_summary(
    count: usize,
    userinfo: caly_core::subscription::SubscriptionUserInfo,
) -> SubscriptionSummary {
    SubscriptionSummary {
        format: "ssr-only".to_owned(),
        node_count: 0,
        rejected_lines: 0,
        ssr_skipped: count,
        names: Vec::new(),
        userinfo,
    }
}

/// The §6.1 face name for a decoded document format.
fn format_name(format: SubscriptionFormat) -> &'static str {
    match format {
        SubscriptionFormat::UriLines => "uri-lines",
        SubscriptionFormat::Base64UriLines => "base64-uri-lines",
        // The classifier only yields UriLines for these two.
        SubscriptionFormat::ClashYaml => "clash-yaml",
    }
}

/// Stamps the quota fields onto the §6.1 envelope when the userinfo header
/// carried a total (backward-compatible with the pre-W3a `sub parse --json`).
fn apply_quota(value: &mut serde_json::Value, userinfo: &caly_core::subscription::SubscriptionUserInfo) {
    if let Some(total) = userinfo.total_bytes {
        let used = userinfo
            .upload_bytes
            .unwrap_or(0)
            .saturating_add(userinfo.download_bytes.unwrap_or(0));
        value["quota_total"] = serde_json::json!(total);
        value["quota_used"] = serde_json::json!(used);
        value["quota_remaining"] = serde_json::json!(total.saturating_sub(used));
    }
}

/// Reads and parses `path`, returning a human-readable summary. An optional
/// `subscription-userinfo` header value supplies quota metadata.
pub fn inspect_subscription_with_userinfo(
    path: &Path,
    userinfo_header: Option<&str>,
) -> Result<SubscriptionSummary, String> {
    let body =
        std::fs::read(path).map_err(|error| format!("cannot read {}: {error}", path.display()))?;
    inspect_subscription(body, userinfo_header)
}

/// Reads proxy URIs from the system clipboard and parses them as a synthetic
/// document. Tries Wayland (`wl-paste`) first, then X11 (`xclip`, `xsel`).
/// Returns an error that also suggests `caly sub check <file>` as a fallback.
pub fn read_clipboard() -> Result<SubscriptionSummary, String> {
    const TOOLS: [(&str, &[&str]); 3] = [
        ("wl-paste", &[]),
        ("xclip", &["-selection", "clipboard", "-o"]),
        ("xsel", &["--clipboard", "--output"]),
    ];
    read_clipboard_with(&TOOLS)
}

/// Core implementation of `read_clipboard` over an injectable candidate list,
/// so the fallback-error path is unit-testable without mutating `PATH`.
pub(crate) fn read_clipboard_with(tools: &[(&str, &[&str])]) -> Result<SubscriptionSummary, String> {
    use std::process::{Command, Stdio};
    let mut errors = Vec::new();
    for &(tool, args) in tools {
        let output = Command::new(tool)
            .args(args)
            .stdout(Stdio::piped())
            .stderr(Stdio::null())
            .output();
        match output {
            Ok(output) if output.status.success() => {
                return inspect_subscription(output.stdout, None);
            }
            Ok(_) => errors.push(tool.to_owned()),
            Err(_) => errors.push(format!("{tool}: not found")),
        }
    }
    Err(format!(
        "no clipboard tool available (tried {}); paste the URIs into a file and run `caly sub check <file>`",
        errors.join(", ")
    ))
}

/// Parses an in-memory subscription body (from a file or clipboard) into a
/// summary, sharing the offline pipeline with `caly sub check`.
pub fn inspect_subscription(
    body: Vec<u8>,
    userinfo_header: Option<&str>,
) -> Result<SubscriptionSummary, String> {
    let userinfo = userinfo_or_default(userinfo_header);
    // URL-list documents carry no nodes offline; the daemon fetches and merges
    // the children during refresh. Report the entries instead of parsing.
    if let Ok(caly_core::subscription::SubscriptionDocument::UrlList(lines)) =
        decode_document(&body)
    {
        return Ok(url_list_summary(
            lines.iter().map(caly_core::domain::BoundedText::as_str),
            userinfo,
        ));
    }
    let format = detect_format(&body).unwrap_or_else(|| "unknown".to_owned());
    // A stable, all-zero subscription id for an offline preview.
    let subscription = SubscriptionId::from_bytes([0; 16]);
    let projection = match parse_uri_body_to_display_lossy(&body, subscription) {
        Ok(projection) => projection,
        Err(caly_core::subscription::PipelineError::SsrOnly(count)) => {
            return Ok(ssr_only_summary(count, userinfo));
        }
        Err(error) => return Err(format!("subscription parse failed: {error}")),
    };
    let names = projection
        .nodes
        .iter()
        .map(|node| node.name().as_str().to_owned())
        .collect();
    Ok(SubscriptionSummary {
        format,
        node_count: projection.nodes.len(),
        rejected_lines: projection.rejected_lines,
        ssr_skipped: projection.ssr_skipped,
        names,
        userinfo,
    })
}

/// Outcome of the W3a tree-format parse (`sub parse`).
///
/// `Tree` carries the full entry tree (three-zone human layout or the
/// §6.1 JSON contract) plus the bounded diagnostics URI-line documents
/// retain; `Summary` is the pre-W3a shape kept for documents that have
/// no tree at all (`url-list` — a fetchable source with no offline
/// nodes — and `ssr-only`).
#[derive(Debug)]
pub enum ParseOutcome {
    /// Full entry tree (Clash YAML / URI lines / base64).
    Tree {
        tree: crate::entry_tree::EntryTree,
        rejected_lines: usize,
        ssr_skipped: usize,
        userinfo: caly_core::subscription::SubscriptionUserInfo,
    },
    /// Non-tree legacy shape (url-list / ssr-only).
    Summary(SubscriptionSummary),
}

impl ParseOutcome {
    /// Whether the parsed document is usable (mirrors the summary
    /// semantics: dialable nodes, or a URL list the daemon expands).
    pub fn is_usable(&self) -> bool {
        match self {
            Self::Tree { tree, .. } => tree.protocol_count() > 0,
            Self::Summary(summary) => is_usable(summary),
        }
    }
}

/// W3a (`cli-v3-design.md` G1/§5.3/§6.1): parses a subscription file into
/// the entry tree. Clash YAML gets the full three-zone tree; URI-line and
/// base64 documents degrade to the protocol-only listing; url-list and
/// ssr-only keep the legacy summary shape. The optional `userinfo` header
/// value supplies quota metadata (kept in the JSON envelope for
/// backward compatibility).
pub fn parse_subscription_tree(
    path: &Path,
    userinfo_header: Option<&str>,
) -> Result<ParseOutcome, String> {
    let body =
        std::fs::read(path).map_err(|error| format!("cannot read {}: {error}", path.display()))?;
    parse_subscription_tree_body(body, userinfo_header)
}

/// [`parse_subscription_tree`] over an in-memory body (unit-testable).
pub fn parse_subscription_tree_body(
    body: Vec<u8>,
    userinfo_header: Option<&str>,
) -> Result<ParseOutcome, String> {
    let userinfo = userinfo_or_default(userinfo_header);
    let subscription = SubscriptionId::from_bytes([0; 16]);
    match decode_document(&body) {
        // URL-list documents carry no nodes offline; the daemon fetches
        // and merges the children during refresh. Keep the legacy
        // summary render.
        Ok(caly_core::subscription::SubscriptionDocument::UrlList(lines)) => Ok(ParseOutcome::Summary(
            url_list_summary(lines.iter().map(caly_core::domain::BoundedText::as_str), userinfo),
        )),
        // Clash YAML: the full tree — groups, ungrouped nodes, rules.
        Ok(caly_core::subscription::SubscriptionDocument::ClashYaml(yaml)) => {
            let source = String::from_utf8(yaml.to_vec())
                .map_err(|_| "subscription parse failed: Clash body is not UTF-8".to_owned())?;
            let import = caly_core::subscription::parse_clash_config(&source, subscription)
                .map_err(|error| format!("subscription parse failed: {error}"))?;
            Ok(ParseOutcome::Tree {
                tree: crate::entry_tree::from_clash_import(&import, "clash-yaml"),
                rejected_lines: 0,
                ssr_skipped: 0,
                userinfo,
            })
        }
        // URI lines / base64 aggregates: the degenerate protocol-only
        // listing (no group zone, no rule zone — G-§3.2).
        Ok(caly_core::subscription::SubscriptionDocument::UriLines { source_format, .. }) => {
            match parse_uri_body_to_display_lossy(&body, subscription) {
                Ok(projection) => {
                    let nodes: Vec<(String, String)> = projection
                        .nodes
                        .iter()
                        .map(|node| {
                            (
                                node.name().as_str().to_owned(),
                                crate::entry_tree::badge_kind(node.protocol().as_str()),
                            )
                        })
                        .collect();
                    let format = format_name(source_format);
                    Ok(ParseOutcome::Tree {
                        tree: crate::entry_tree::from_uri_nodes(format, nodes),
                        rejected_lines: projection.rejected_lines,
                        ssr_skipped: projection.ssr_skipped,
                        userinfo,
                    })
                }
                Err(caly_core::subscription::PipelineError::SsrOnly(count)) => {
                    Ok(ParseOutcome::Summary(ssr_only_summary(count, userinfo)))
                }
                Err(error) => Err(format!("subscription parse failed: {error}")),
            }
        }
        // Sip008 and undecodable documents keep the pre-W3a summary
        // path (the tree faces only cover Clash YAML and URI lines).
        _ => {
            let summary = inspect_subscription(body, userinfo_header)?;
            Ok(ParseOutcome::Summary(summary))
        }
    }
}

/// Renders a tree parse outcome as human text: the entry tree plus a
/// trailing diagnostic note when URI-line documents rejected or skipped
/// lines (never on the JSON face).
pub fn render_tree_human(outcome: &ParseOutcome) -> String {
    match outcome {
        ParseOutcome::Tree {
            tree,
            rejected_lines,
            ssr_skipped,
            ..
        } => {
            let mut out = crate::entry_tree::render_human(tree);
            if *rejected_lines > 0 {
                let _ = std::fmt::Write::write_fmt(
                    &mut out,
                    format_args!("# {rejected_lines} line(s) rejected\n"),
                );
            }
            if *ssr_skipped > 0 {
                let _ = std::fmt::Write::write_fmt(
                    &mut out,
                    format_args!("# {ssr_skipped} SSR node(s) skipped (not representable)\n"),
                );
            }
            out
        }
        ParseOutcome::Summary(summary) => render_human(summary),
    }
}

/// Renders a tree parse outcome as §6.1 JSON. The quota fields are
/// appended at the top level only when the userinfo header carried a
/// total (backward-compatible with the pre-W3a `sub parse --json`
/// envelope).
pub fn render_tree_json(outcome: &ParseOutcome) -> String {
    match outcome {
        ParseOutcome::Tree { tree, userinfo, .. } => {
            let mut value = crate::entry_tree::render_json(tree);
            apply_quota(&mut value, userinfo);
            value.to_string()
        }
        ParseOutcome::Summary(summary) => render_json(summary),
    }
}

/// Detects the top-level subscription format without failing on parse details.
fn detect_format(body: &[u8]) -> Option<String> {
    use caly_core::subscription::SubscriptionDocument;
    match decode_document(body) {
        Ok(SubscriptionDocument::ClashYaml(_)) => Some("clash-yaml".to_owned()),
        Ok(SubscriptionDocument::UrlList(_)) => Some("url-list".to_owned()),
        Ok(SubscriptionDocument::Sip008(_)) => Some("sip008".to_owned()),
        Ok(SubscriptionDocument::UriLines { source_format, .. }) => Some(match source_format {
            SubscriptionFormat::UriLines => "uri-lines".to_owned(),
            SubscriptionFormat::Base64UriLines => "base64-uri-lines".to_owned(),
            SubscriptionFormat::ClashYaml => "clash-yaml".to_owned(),
        }),
        Err(_) => None,
    }
}

/// Renders a summary as human-readable text.
pub fn render_human(summary: &SubscriptionSummary) -> String {
    let mut out = format!(
        "format:      {}\nnodes:       {}\nrejected:    {}\n",
        summary.format, summary.node_count, summary.rejected_lines
    );
    if summary.format == "ssr-only" {
        let _ = std::fmt::Write::write_fmt(
            &mut out,
            format_args!(
                "note:        all {} nodes are SSR, which caly cannot represent;\n             convert the subscription to a supported format\n",
                summary.ssr_skipped
            ),
        );
    } else if summary.ssr_skipped > 0 {
        let _ = std::fmt::Write::write_fmt(
            &mut out,
            format_args!(
                "ssr-skipped: {} (SSR nodes are recognized but not representable)\n",
                summary.ssr_skipped
            ),
        );
    }
    if summary.format == "url-list" {
        let _ = std::fmt::Write::write_fmt(
            &mut out,
            format_args!(
                "entries:     {} (child subscriptions; the daemon fetches and merges them on refresh)\n",
                summary.names.len()
            ),
        );
    }
    let usage = caly_core::subscription::render_usage_human(&summary.userinfo);
    if !usage.is_empty() {
        out.push_str(&usage);
        out.push('\n');
    }
    for (index, name) in summary.names.iter().enumerate() {
        let _ = std::fmt::Write::write_fmt(&mut out, format_args!("  {index}: {name}\n"));
    }
    out
}

/// Renders a summary as one-line JSON.
pub fn render_json(summary: &SubscriptionSummary) -> String {
    let mut value = serde_json::json!({
        "format": summary.format,
        "nodes": summary.node_count,
        "rejected": summary.rejected_lines,
        "ssr_skipped": summary.ssr_skipped,
        "names": summary.names,
    });
    apply_quota(&mut value, &summary.userinfo);
    value.to_string()
}

/// Returns whether the subscription parsed into something the refresh path can
/// use: dialable nodes, or a URL list the daemon expands at fetch time.
pub fn is_usable(summary: &SubscriptionSummary) -> bool {
    summary.node_count > 0 || summary.format == "url-list"
}
