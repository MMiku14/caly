//! Proxy-node selection for the daemon execute path (`node select`).
//!
//! Split out of `client/execute/ops` (audit #70 file-length budget):
//! ID/name/prefix resolution plus the interactive no-argument picker face.

use std::process::ExitCode;

use caly_daemon::protocol::{
    client::{ClientContract, UdsClient},
    protocol::v2::WireCommand,
};

use super::super::super::output;
use super::super::super::picker::{
    LiveItem, LiveOutcome, LivePicker, PingState, interactive_capable,
};
use super::super::{delay::sweep_snapshot_delays_with, lowest_latency_node};
use super::{execute_operation, execute_sync_operation};

/// Selects a proxy node: by ID/name/prefix, or automatically the lowest
/// latency node (never direct) with `--delay`.
pub(crate) fn execute_select_proxy(
    client: &mut UdsClient,
    node: Option<&str>,
    delay: bool,
    poll: bool,
    json: bool,
    picker: &mut dyn LivePicker,
) -> ExitCode {
    if delay {
        let Some(best) = lowest_latency_node(client, json) else {
            return ExitCode::from(2);
        };
        let label = best.1;
        return execute_sync_operation(client, json, &format!("select node `{label}`"), || {
            WireCommand::SelectProxy { node_id: best.0 }
        });
    }
    let Some(node) = node else {
        // W2 (cli-v3-design.md §7): no argument on a live terminal
        // opens the interactive picker; piped/non-TTY gets the
        // usage error with the available entries, exit 2 (C-A).
        return select_without_argument(client, poll, json, picker);
    };
    let Some((node_id, label)) = resolve_node(client, node, json) else {
        return ExitCode::from(2);
    };
    execute_sync_operation(client, json, &format!("select node `{label}`"), || {
        WireCommand::SelectProxy { node_id }
    })
}

/// The `caly node select` no-argument face (§7). The picker lists
/// the online snapshot (`[protocol] name latency`); non-TTY never
/// blocks and reports the available names instead.
fn select_without_argument(
    client: &mut UdsClient,
    poll: bool,
    json: bool,
    picker: &mut dyn LivePicker,
) -> ExitCode {
    use std::collections::HashMap;
    use std::sync::{Arc, Mutex};
    let snapshot = match client.snapshot() {
        Ok(snapshot) => snapshot,
        Err(error) => {
            let _ = output::report_error(error, json);
            return ExitCode::FAILURE;
        }
    };
    let names: Vec<String> = snapshot
        .nodes
        .iter()
        .map(|node| crate::client::output::decode_display_name(&node.name))
        .collect();
    // The empty pool is reported before the gate: with nothing to
    // offer, even a script should hear "refresh a subscription",
    // not "give me a name from this empty list".
    if names.is_empty() {
        return output::report_usage_error(
            "no entries to select; refresh a subscription with `caly sub refresh` first",
            json,
        );
    }
    if !interactive_capable() {
        return output::report_usage_error(
            &format!(
                "node select requires <name> in non-interactive mode. Available: {}",
                names.join(", ")
            ),
            json,
        );
    }
    let entries: Vec<LiveItem> = snapshot
        .nodes
        .iter()
        .map(|node| LiveItem {
            name: crate::client::output::decode_display_name(&node.name),
            protocol: node.protocol.clone(),
            latency_ms: node.latency_ms,
            payload: caly_core::domain::to_hex(node.node_id),
        })
        .collect();
    let latencies = Arc::new(Mutex::new(HashMap::new()));
    let ping = Arc::new(Mutex::new(PingState::default()));
    // `-p` pre-freshens latencies with a full sweep before the picker
    // opens — the same sweep the in-picker feature row re-runs, sharing
    // the `latencies` map so the picker shows live pinged delays.
    if poll {
        pre_sweep_latencies(client, &latencies);
    }
    // Bug ⑭: the sweep worker must redial the SAME daemon the picker
    // is attached to — the default socket path broke `--socket` users.
    let mut start_ping = build_start_ping(latencies.clone(), ping.clone(), client.socket().clone());
    match picker.pick(&entries, &ping, &latencies, &mut start_ping) {
        Ok(LiveOutcome::Selected(index)) => {
            let Some(entry) = entries.get(index) else {
                return output::report_usage_error(
                    "internal picker index out of range; nothing changed",
                    json,
                );
            };
            let Some(node_id) = parse_node_id(&entry.payload) else {
                return output::report_usage_error(
                    "internal picker payload is not a node id; nothing changed",
                    json,
                );
            };
            let label = &entry.name;
            execute_operation(
                client,
                json,
                &format!("select node `{label}`"),
                false,
                |_| WireCommand::SelectProxy { node_id },
            )
        }
        Ok(LiveOutcome::Escaped) => {
            eprintln!("\n{}", crate::layout::CANCELLED_NOTHING_CHANGED);
            ExitCode::FAILURE
        }
        Ok(LiveOutcome::Interrupted) => ExitCode::from(130),
        Err(_) => {
            eprintln!("picker failed; nothing changed");
            ExitCode::FAILURE
        }
    }
}

/// `-p` pre-sweep: fills the shared `latencies` map with a full delay
/// sweep before the picker opens — the same sweep the in-picker feature
/// row re-runs, so the picker opens with live pinged delays.
fn pre_sweep_latencies(
    client: &mut UdsClient,
    latencies: &std::sync::Arc<std::sync::Mutex<std::collections::HashMap<String, Option<u32>>>>,
) {
    match sweep_snapshot_delays_with(
        client,
        None,
        None,
        Some(&**latencies),
        Some(&|done, total, dead| {
            eprint!("\rprobed {done}/{total} · {dead} unreachable");
        }),
    ) {
        Ok(_) => eprint!("\r\x1b[K"),
        Err(_) => crate::layout::note_err("delay sweep failed; showing cached latencies"),
    }
}

/// In-picker ping launcher: Enter on the feature row spawns a background
/// sweep that publishes per-node medians into `latencies` and progress
/// into `ping`; the picker's poll-timeout redraw loop picks both up.
fn build_start_ping(
    latencies: std::sync::Arc<std::sync::Mutex<std::collections::HashMap<String, Option<u32>>>>,
    ping: std::sync::Arc<std::sync::Mutex<PingState>>,
    socket: std::path::PathBuf,
) -> impl FnMut() {
    let (lat2, ping2) = (latencies, ping);
    move || {
        // Reset the sweep state synchronously on this (main) thread before
        // the worker spawns: the picker's Enter handler checks `running`
        // under the same lock, so a double-Enter can never launch two
        // sweeps, and the header can never show a previous sweep's totals
        // as if they belonged to the new one.
        *ping2
            .lock()
            .unwrap_or_else(std::sync::PoisonError::into_inner) = PingState {
            running: true,
            done: 0,
            total: 0,
            dead: 0,
            ever_ran: true,
            failed: false,
        };
        let lat = lat2.clone();
        let pg = ping2.clone();
        let path = socket.clone();
        std::thread::spawn(move || {
            let Ok(mut probe) = caly_daemon::protocol::client::UdsClient::connect(path) else {
                // Daemon unreachable: say so honestly (the feature row must
                // not present `0 unreachable` as a real result).
                let mut state = pg.lock().unwrap_or_else(std::sync::PoisonError::into_inner);
                state.running = false;
                state.failed = true;
                return;
            };
            let sweep = sweep_snapshot_delays_with(
                &mut probe,
                None,
                None,
                Some(&lat),
                Some(&|done, total, dead| {
                    *pg.lock().unwrap_or_else(std::sync::PoisonError::into_inner) = PingState {
                        running: true,
                        done,
                        total,
                        dead,
                        ever_ran: true,
                        failed: false,
                    };
                }),
            );
            let mut state = pg.lock().unwrap_or_else(std::sync::PoisonError::into_inner);
            state.running = false;
            // A failed sweep must surface as failure in the feature row,
            // not as a fake `0 unreachable` result.
            if sweep.is_err() {
                state.failed = true;
            }
        });
    }
}

/// Resolves a `select` argument: a 32-hex node ID is used as-is; anything
/// else is matched against the snapshot's node display names (exact match
/// first, then a unique case-insensitive match).
fn resolve_node(client: &mut UdsClient, node: &str, json: bool) -> Option<([u8; 16], String)> {
    if let Some(id) = parse_node_id(node) {
        return Some((id, node.to_owned()));
    }
    let snapshot = match client.snapshot() {
        Ok(snapshot) => snapshot,
        Err(error) => {
            let _ = output::report_error(error, json);
            return None;
        }
    };
    let exact: Vec<_> = snapshot
        .nodes
        .iter()
        .filter(|candidate| {
            candidate.name == node || output::decode_display_name(&candidate.name) == node
        })
        .collect();
    if exact.len() == 1 {
        return Some((exact[0].node_id, exact[0].name.clone()));
    }
    if exact.len() > 1 {
        let ids = exact
            .iter()
            .map(|candidate| {
                format!(
                    "  {} ({})",
                    caly_core::domain::to_hex(candidate.node_id),
                    candidate.protocol
                )
            })
            .collect::<Vec<_>>()
            .join("\n");
        output::report_usage_error(
            &format!(
                "{} nodes share the name `{node}`; select one by ID:\n{ids}",
                exact.len()
            ),
            json,
        );
        return None;
    }
    let fuzzy: Vec<_> = snapshot
        .nodes
        .iter()
        .filter(|candidate| {
            // Compare the *decoded* display name everywhere: a
            // percent-encoded tag (`HK%2D01` in the registry, `HK-01`
            // on screen) must match the operator's typing (2026-08-12
            // agent audit — the exact branch decoded, the fuzzy/prefix
            // branches did not).
            candidate.name.eq_ignore_ascii_case(node)
                || output::decode_display_name(&candidate.name).eq_ignore_ascii_case(node)
        })
        .collect();
    if fuzzy.len() == 1 {
        return Some((fuzzy[0].node_id, fuzzy[0].name.clone()));
    }
    // Unique case-insensitive prefix match: select by a short unambiguous
    // fragment of the display name (e.g. the country flag or keyword).
    let prefix: Vec<_> = snapshot
        .nodes
        .iter()
        .filter(|candidate| {
            candidate
                .name
                .to_lowercase()
                .starts_with(&node.to_lowercase())
                || output::decode_display_name(&candidate.name)
                    .to_lowercase()
                    .starts_with(&node.to_lowercase())
        })
        .collect();
    if prefix.len() == 1 {
        return Some((prefix[0].node_id, prefix[0].name.clone()));
    }
    if prefix.len() > 1 {
        let ids = prefix
            .iter()
            .take(8)
            .map(|candidate| {
                format!(
                    "  {} ({})",
                    caly_core::domain::to_hex(candidate.node_id),
                    candidate.name
                )
            })
            .collect::<Vec<_>>()
            .join("\n");
        output::report_usage_error(
            &format!(
                "`{node}` matches {} nodes; use a longer prefix or an ID:\n{ids}",
                prefix.len()
            ),
            json,
        );
        return None;
    }
    output::report_usage_error(
        &format!("no node named `{node}`; list nodes with `caly core list-nodes`"),
        json,
    );
    None
}

/// Parses a 32-hex-character node id into its 16-byte wire form.
pub(crate) fn parse_node_id(hex_value: &str) -> Option<[u8; 16]> {
    if hex_value.len() != 32 {
        return None;
    }
    let mut id = [0_u8; 16];
    for (index, pair) in hex_value.as_bytes().chunks(2).enumerate() {
        let hi = u8::try_from((pair[0] as char).to_digit(16)?).ok()?;
        let lo = u8::try_from((pair[1] as char).to_digit(16)?).ok()?;
        id[index] = (hi << 4) | lo;
    }
    Some(id)
}

#[cfg(test)]
mod tests {
//! Tests for `client/execute/ops.rs`, extracted to the child
//! convention file (audit #70 file-length budget).

use super::*;

/// A failed daemon connect in the sweep worker must surface as a
/// failed state (honest feature row), never as a fake `0 unreachable`
/// result — and `running` must always be cleared so the header can
/// never stay stuck on "testing...".
#[test]
fn start_ping_connect_failure_marks_state_failed() {
    let ping = std::sync::Arc::new(std::sync::Mutex::new(
        crate::client::picker::PingState::default(),
    ));
    let latencies = std::sync::Arc::new(std::sync::Mutex::new(std::collections::HashMap::new()));
    let mut start_ping = build_start_ping(
        latencies,
        ping.clone(),
        std::path::PathBuf::from("/nonexistent/caly-live-test.sock"),
    );
    start_ping();
    let deadline = std::time::Instant::now() + std::time::Duration::from_secs(5);
    loop {
        let state = *ping
            .lock()
            .unwrap_or_else(std::sync::PoisonError::into_inner);
        if !state.running || std::time::Instant::now() > deadline {
            break;
        }
        std::thread::sleep(std::time::Duration::from_millis(5));
    }
    let state = *ping
        .lock()
        .unwrap_or_else(std::sync::PoisonError::into_inner);
    assert!(
        !state.running,
        "worker must clear running on connect failure"
    );
    assert!(state.failed, "connect failure must mark the sweep failed");
    assert!(state.ever_ran);
}

}
