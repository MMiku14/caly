//! `config get <dotted.key>` — print the effective value and the
//! layer file that declares it.

use std::process::ExitCode;

use caly_daemon::platform::paths::{AppPaths, SafeName};
use serde_norway::Value;

use super::{
    Layer, active_profile, display_scalar, is_scalar, load_layers, parse_key, relative_to, report,
    to_json, walk,
};

/// `config get <dotted.key>`.
pub fn config_get(json: bool, key: &str) -> ExitCode {
    let paths = AppPaths::from_env();
    let profile = match active_profile() {
        Ok(profile) => profile,
        Err(reason) => {
            return report("usage.config_bad_profile", "config get", reason, None, json);
        }
    };
    config_get_under(&paths, profile.as_ref(), json, key)
}

pub(super) fn config_get_under(
    paths: &AppPaths,
    profile: Option<&SafeName>,
    json: bool,
    key: &str,
) -> ExitCode {
    let segments = match parse_key(key) {
        Ok(segments) => segments,
        Err(reason) => return report("usage.config_bad_key", "config get", reason, None, json),
    };
    let layers = match load_layers(paths, profile) {
        Ok(layers) => layers,
        Err(reason) => return report("config.get_failed", "config get", reason, None, json),
    };
    if layers.is_empty() {
        return report(
            "config.get_failed",
            "config get",
            format!("no config files under {}", paths.config.display()),
            Some("run `caly config generate` to create the default layout"),
            json,
        );
    }
    let resolved = match resolve_key(&layers, &segments) {
        Ok(resolved) => resolved,
        Err(failure) => {
            return report(
                "config.unknown_key",
                "config get",
                failure.message,
                failure.hint.as_deref(),
                json,
            );
        }
    };
    let file = relative_to(&paths.config, &resolved.file);
    let value = &resolved.value;
    if json {
        println!(
            "{}",
            crate::layout::CliOutput::success_envelope(serde_json::json!({
                "command": "config get",
                "key": key,
                "value": to_json(value),
                "file": file,
            }))
        );
    } else if is_scalar(value) || matches!(value, Value::Null) {
        println!("{key} = {}  # from {file}", display_scalar(value));
    } else {
        println!("{key}:  # from {file} (this layer's fragment; siblings merge)");
        for line in display_scalar(value).lines() {
            println!("  {line}");
        }
    }
    ExitCode::SUCCESS
}

/// A resolved key: the winning layer file plus its (cloned) value.
#[derive(Debug)]
pub(super) struct Resolved {
    pub file: std::path::PathBuf,
    pub value: Value,
}

/// Lookup failure: message plus the top-level-sections hint.
#[derive(Debug)]
pub(super) struct ResolveFailure {
    pub message: String,
    pub hint: Option<String>,
}

/// Resolves `segments` to the winning layer's value. Pure over the
/// loaded layers (the test seam); rendering stays in the caller.
pub(super) fn resolve_key(layers: &[Layer], segments: &[&str]) -> Result<Resolved, ResolveFailure> {
    // Last layer declaring the full path wins — `deep_merge`'s rule
    // for scalar leaves.
    let mut hit: Option<(&Layer, &Value)> = None;
    for layer in layers {
        if let Some(value) = walk(&layer.value, segments) {
            hit = Some((layer, value));
        }
    }
    let Some((layer, value)) = hit else {
        return Err(ResolveFailure {
            message: format!("unknown config key `{}`", segments.join(".")),
            hint: Some(format!("top-level sections: {}", top_level_keys(layers))),
        });
    };
    Ok(Resolved {
        file: layer.path.clone(),
        value: value.clone(),
    })
}

/// Union of top-level mapping keys across layers, for the
/// unknown-key hint.
fn top_level_keys(layers: &[Layer]) -> String {
    let mut keys: Vec<String> = Vec::new();
    for layer in layers {
        if let Some(mapping) = layer.value.as_mapping() {
            for key in mapping.keys() {
                if let Value::String(name) = key
                    && !keys.contains(name)
                {
                    keys.push(name.clone());
                }
            }
        }
    }
    keys.sort();
    if keys.is_empty() {
        "(none)".to_owned()
    } else {
        keys.join(", ")
    }
}
