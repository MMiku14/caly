//! Hermetic tests for `config get` / `config set` (no env, no daemon).

use std::fs;
use std::process::ExitCode;

use caly_daemon::platform::paths::AppPaths;

use super::get::{config_get_under, resolve_key};
use super::set::config_set_under;
use super::{load_layers, parse_key};
use crate::test_helpers::{hermetic_paths, temp_root};

const TAG: &str = "config-kv";

fn seed(root: &std::path::Path, base: &str, fragment: Option<(&str, &str)>) -> AppPaths {
    let paths = hermetic_paths(root);
    fs::create_dir_all(&paths.config).unwrap();
    fs::write(paths.config.join("config.yaml"), base).unwrap();
    if let Some((name, body)) = fragment {
        let dir = paths.config.join("config.d");
        fs::create_dir_all(&dir).unwrap();
        fs::write(dir.join(name), body).unwrap();
    }
    paths
}

const BASE: &str = "schema_version: 1\ncore: mihomo\n";

#[test]
fn resolve_last_layer_wins() {
    let dir = temp_root(TAG);
    let paths = seed(
        dir.as_path(),
        "schema_version: 1\ncore: mihomo\nkernel:\n  mixed_port: 1111\n",
        Some(("15-kernel.yaml", "kernel:\n  mixed_port: 2222\n")),
    );
    let layers = load_layers(&paths, None).unwrap();
    let resolved = resolve_key(&layers, &["kernel", "mixed_port"]).unwrap();
    assert_eq!(resolved.value, serde_norway::Value::from(2222));
    assert!(resolved.file.ends_with("15-kernel.yaml"));
}

#[test]
fn resolve_missing_reports_sections() {
    let dir = temp_root(TAG);
    let paths = seed(
        dir.as_path(),
        BASE,
        Some(("15-kernel.yaml", "kernel:\n  mixed_port: 2222\n")),
    );
    let layers = load_layers(&paths, None).unwrap();
    let failure = resolve_key(&layers, &["dns", "mode"]).unwrap_err();
    assert!(failure.message.contains("dns.mode"), "{}", failure.message);
    assert!(failure.hint.unwrap_or_default().contains("kernel"));
}

#[test]
fn get_missing_key_is_exit_1() {
    let dir = temp_root(TAG);
    let paths = seed(dir.as_path(), BASE, None);
    assert_eq!(
        config_get_under(&paths, None, false, "dns.mode"),
        ExitCode::from(1)
    );
}

#[test]
fn set_replace_preserves_comment_and_backs_up() {
    let dir = temp_root(TAG);
    let paths = seed(
        dir.as_path(),
        BASE,
        Some((
            "15-kernel.yaml",
            "kernel:\n  mixed_port: 7890      # the inbound\n",
        )),
    );
    let code = config_set_under(&paths, None, false, "kernel.mixed_port", "8888", true);
    assert_eq!(code, ExitCode::SUCCESS);
    let after = fs::read_to_string(paths.config.join("config.d/15-kernel.yaml")).unwrap();
    assert!(after.contains("mixed_port: 8888 # the inbound"), "{after}");
    let backup = fs::read_to_string(paths.config.join("config.d/15-kernel.yaml.bak")).unwrap();
    assert!(backup.contains("mixed_port: 7890"), "{backup}");
    // The edit is effective: the winner now reads back the new value.
    let layers = load_layers(&paths, None).unwrap();
    let resolved = resolve_key(&layers, &["kernel", "mixed_port"]).unwrap();
    assert_eq!(resolved.value, serde_norway::Value::from(8888));
}

#[test]
fn set_insert_lands_under_the_parent_block() {
    let dir = temp_root(TAG);
    let paths = seed(
        dir.as_path(),
        BASE,
        Some(("15-kernel.yaml", "kernel:\n  mixed_port: 7890\n")),
    );
    let code = config_set_under(&paths, None, false, "kernel.log_level", "debug", true);
    assert_eq!(code, ExitCode::SUCCESS);
    let after = fs::read_to_string(paths.config.join("config.d/15-kernel.yaml")).unwrap();
    assert!(after.contains("  log_level: debug"), "{after}");
    let layers = load_layers(&paths, None).unwrap();
    let resolved = resolve_key(&layers, &["kernel", "log_level"]).unwrap();
    assert_eq!(resolved.value, serde_norway::Value::from("debug"));
}

#[test]
fn set_dry_run_writes_nothing() {
    let dir = temp_root(TAG);
    let before = "kernel:\n  mixed_port: 7890\n";
    let paths = seed(dir.as_path(), BASE, Some(("15-kernel.yaml", before)));
    let code = config_set_under(&paths, None, false, "kernel.mixed_port", "8888", false);
    assert_eq!(code, ExitCode::SUCCESS);
    let after = fs::read_to_string(paths.config.join("config.d/15-kernel.yaml")).unwrap();
    assert_eq!(after, before);
    assert!(!paths.config.join("config.d/15-kernel.yaml.bak").exists());
}

#[test]
fn set_noop_reports_unchanged_without_a_write() {
    let dir = temp_root(TAG);
    let paths = seed(
        dir.as_path(),
        BASE,
        Some(("15-kernel.yaml", "kernel:\n  mixed_port: 7890\n")),
    );
    let code = config_set_under(&paths, None, false, "kernel.mixed_port", "7890", true);
    assert_eq!(code, ExitCode::SUCCESS);
    assert!(!paths.config.join("config.d/15-kernel.yaml.bak").exists());
}

#[test]
fn set_unknown_parent_fails_clean() {
    let dir = temp_root(TAG);
    let before = "kernel:\n  mixed_port: 7890\n";
    let paths = seed(dir.as_path(), BASE, Some(("15-kernel.yaml", before)));
    let code = config_set_under(&paths, None, false, "telemetry.interval", "30", true);
    assert_eq!(code, ExitCode::from(1));
    let after = fs::read_to_string(paths.config.join("config.d/15-kernel.yaml")).unwrap();
    assert_eq!(after, before);
}

#[test]
fn set_invalid_value_restores_the_original() {
    let dir = temp_root(TAG);
    let before = "kernel:\n  mixed_port: 7890\n";
    let paths = seed(dir.as_path(), BASE, Some(("15-kernel.yaml", before)));
    // `mixed_port` is a u16: 99999 fails the merged validation.
    let code = config_set_under(&paths, None, false, "kernel.mixed_port", "99999", true);
    assert_eq!(code, ExitCode::from(1));
    let after = fs::read_to_string(paths.config.join("config.d/15-kernel.yaml")).unwrap();
    assert_eq!(after, before);
}

#[test]
fn set_failure_preserves_an_earlier_backup() {
    let dir = temp_root(TAG);
    let paths = seed(
        dir.as_path(),
        BASE,
        Some(("15-kernel.yaml", "kernel:\n  mixed_port: 7890\n")),
    );
    let target = paths.config.join("config.d/15-kernel.yaml");
    let backup = paths.config.join("config.d/15-kernel.yaml.bak");
    // An earlier apply leaves a backup of the 7890 bytes.
    let code = config_set_under(&paths, None, false, "kernel.mixed_port", "8888", true);
    assert_eq!(code, ExitCode::SUCCESS);
    assert!(backup.is_file());
    // A failing set must not eat it: file and backup both survive.
    let code = config_set_under(&paths, None, false, "kernel.mixed_port", "99999", true);
    assert_eq!(code, ExitCode::from(1));
    let after = fs::read_to_string(&target).unwrap();
    assert!(after.contains("mixed_port: 8888"), "{after}");
    let kept = fs::read_to_string(&backup).unwrap();
    assert!(kept.contains("mixed_port: 7890"), "{kept}");
}

#[test]
fn malformed_keys_are_usage_errors() {
    assert!(parse_key("").is_err());
    assert!(parse_key("kernel..port").is_err());
    let dir = temp_root(TAG);
    let paths = seed(dir.as_path(), BASE, None);
    assert_eq!(
        config_set_under(&paths, None, false, "kernel..port", "1", true),
        ExitCode::from(2)
    );
}

#[test]
fn set_section_is_a_usage_error() {
    let dir = temp_root(TAG);
    let paths = seed(
        dir.as_path(),
        BASE,
        Some(("15-kernel.yaml", "kernel:\n  mixed_port: 7890\n")),
    );
    let code = config_set_under(&paths, None, false, "kernel", "x", true);
    assert_eq!(code, ExitCode::from(2));
}

#[test]
fn set_inserts_under_empty_flow_parent() {
    // The generated default ships `core_binaries: {}` (config.d/10-core.yaml):
    // inserting a leaf must first expand the parent to block form, or the
    // patched file is invalid YAML and the trial write fails.
    let dir = temp_root(TAG);
    let paths = seed(
        dir.as_path(),
        BASE,
        Some(("10-core.yaml", "core_binaries: {}  # pinned executables\n")),
    );
    let code = config_set_under(
        &paths,
        None,
        false,
        "core_binaries.mihomo",
        "/data/kernels/mihomo/1.19.29/mihomo",
        true,
    );
    assert_eq!(code, ExitCode::SUCCESS);
    let after = fs::read_to_string(paths.config.join("config.d/10-core.yaml")).unwrap();
    assert!(
        after.contains("  mihomo: /data/kernels/mihomo/1.19.29/mihomo") && !after.contains("{}"),
        "{after}"
    );
    assert!(
        after.contains("# pinned executables"),
        "comment preserved: {after}"
    );
}

#[test]
fn apply_scalar_reports_quietly() {
    use super::set::{ScalarOutcome, apply_scalar};
    let dir = temp_root(TAG);
    let paths = seed(
        dir.as_path(),
        BASE,
        Some(("15-kernel.yaml", "kernel:\n  mixed_port: 7890\n")),
    );
    match apply_scalar(&paths, None, "kernel.mixed_port", "8888", true) {
        Ok(ScalarOutcome::Changed {
            old,
            rendered,
            applied,
            ..
        }) => {
            assert_eq!(old, "7890");
            assert_eq!(rendered, "8888");
            assert!(applied);
        }
        other => panic!("expected Changed, got {other:?}"),
    }
    let failure = apply_scalar(&paths, None, "kernel.missing_deep.leaf", "1", true)
        .expect_err("missing parent must fail quietly");
    assert_eq!(failure.code, "config.unknown_key");
}
