//! Offline routing-rule commands: list configured rules and diagnose which
//! rule a host, IP, GeoIP country, GeoSite category, or process hits.
//! Both run without a daemon, reading the configured rules and applying the
//! unified domain/geo matching engine.

use std::process::ExitCode;

use caly_core::domain::RoutingRule;
use caly_core::profile::rule_match::{match_host, match_ip};

/// Executes an offline rule command (`core rules` / `core rule-match`).
pub(super) fn run_rules(cmd: &super::legacy::CoreCmd, json: bool) -> ExitCode {
    use super::legacy::CoreCmd;
    let rules = crate::config::routing_rules();
    match cmd {
        CoreCmd::Rules => list_rules(&rules, json),
        CoreCmd::RuleMatch(target) => rule_match(&rules, target, json),
        _ => ExitCode::FAILURE,
    }
}

fn list_rules(rules: &[RoutingRule], json: bool) -> ExitCode {
    if json {
        let entries: Vec<serde_json::Value> = rules
            .iter()
            .map(|rule| serde_json::json!({ "rule": rule.to_clash_line() }))
            .collect();
        println!("{}", serde_json::json!({ "rules": entries }));
    } else if rules.is_empty() {
        crate::layout::empty("routing rules", Some("add a `rules:` list to the config"));
    } else {
        let geo_count = rules.iter().filter(|r| matches!(r.matcher, caly_core::domain::RuleMatch::Geoip(_) | caly_core::domain::RuleMatch::Geosite(_))).count();
        let domain_count = rules.iter().filter(|r| matches!(r.matcher, caly_core::domain::RuleMatch::Domain(_) | caly_core::domain::RuleMatch::DomainSuffix(_) | caly_core::domain::RuleMatch::DomainKeyword(_))).count();
        let ip_count = rules.iter().filter(|r| matches!(r.matcher, caly_core::domain::RuleMatch::IpCidr(_) | caly_core::domain::RuleMatch::SourceIpCidr(_))).count();
        let proc_count = rules.iter().filter(|r| matches!(r.matcher, caly_core::domain::RuleMatch::ProcessName(_))).count();
        println!("routing rules ({} total: {} domain, {} geo, {} ip, {} process; first match wins):", rules.len(), domain_count, geo_count, ip_count, proc_count);
        for (index, rule) in rules.iter().enumerate() {
            println!("  {index}: {}", rule.to_clash_line());
        }
    }
    ExitCode::SUCCESS
}

fn rule_match(rules: &[RoutingRule], target: &str, json: bool) -> ExitCode {
    // Supports multi-prefix matching:
    // - `geosite:<category>` (e.g. `geosite:google`, `geosite:cn`)
    // - `geoip:<code>` (e.g. `geoip:cn`, `geoip:private`)
    // - `process:<name>` (e.g. `process:telegram`, `process:curl`)
    // - IP literal -> IP-CIDR matcher
    // - Hostname -> Domain / DomainSuffix / DomainKeyword
    let hit = if let Some(cat) = target.strip_prefix("geosite:") {
        rules.iter().find(|rule| rule.matches_geosite(cat))
    } else if let Some(code) = target.strip_prefix("geoip:") {
        rules.iter().find(|rule| rule.matches_geoip(code))
    } else if let Some(proc) = target.strip_prefix("process:") {
        rules.iter().find(|rule| rule.matches_process(proc))
    } else if target.parse::<std::net::IpAddr>().is_ok() {
        match_ip(rules, target)
    } else {
        match_host(rules, target)
    };

    if let Some(rule) = hit {
        if json {
            println!(
                "{}",
                serde_json::json!({
                    "target": target,
                    "matched": true,
                    "rule": rule.to_clash_line(),
                    "policy": rule.policy.to_clash(),
                })
            );
        } else {
            println!(
                "{target} -> {} ({})",
                rule.to_clash_line(),
                rule.policy.to_clash()
            );
        }
        return ExitCode::SUCCESS;
    }

    if json {
        println!(
            "{}",
            serde_json::json!({ "target": target, "matched": false })
        );
    } else {
        println!("{target} -> no rule matched");
    }
    // Not matching is a valid diagnostic outcome, not an error.
    ExitCode::SUCCESS
}
