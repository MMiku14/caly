//! Offline rule-provider writer for the `set rule-provider …` leaves.
//!
//! Since the CLI-sinking round 2, the write semantics live
//! in ONE shared implementation, `caly_core::configstore::resource_mutations`
//! (the same code the daemon's config-mutation actor runs); this module
//! is the CLI's thin offline adapter: it maps the CLI grammar types
//! (`RpSourceSpec` / `RpBehavior`) onto the wire payloads and projects
//! the shared error enum onto the stable `RpWriteError` codes.

use std::path::PathBuf;

use caly_core::domain::{RuleProviderMutation, RuleProviderSourceRef};
use caly_daemon::platform::paths::AppPaths;

use caly_core::configstore::resource_mutations::ResourceMutationError;
use caly_core::configstore::resource_writer::{ResourceError, ResourceWriteOutcome};

/// Rule-provider-specific error variants. Some variants are only
/// constructed under `cfg(test)`; the allow keeps non-test builds quiet.
#[allow(dead_code)]
#[derive(Debug)]
pub enum RpWriteError {
    InvalidName(String),
    AlreadyDeclared(String),
    NotDeclared(String),
    InvalidBehavior(String),
    InvalidUrl(String),
    Shared(ResourceError),
}

impl core::fmt::Display for RpWriteError {
    fn fmt(&self, formatter: &mut core::fmt::Formatter<'_>) -> core::fmt::Result {
        match self {
            Self::InvalidName(name) => write!(
                formatter,
                "rule provider name `{name}` is not path-safe ASCII"
            ),
            Self::AlreadyDeclared(name) => {
                write!(formatter, "rule provider `{name}` is already declared")
            }
            Self::NotDeclared(name) => write!(formatter, "rule provider `{name}` is not declared"),
            Self::InvalidBehavior(reason) => {
                write!(formatter, "invalid rule provider behavior: {reason}")
            }
            Self::InvalidUrl(reason) => write!(formatter, "invalid rule provider URL: {reason}"),
            Self::Shared(shared) => write!(formatter, "{shared}"),
        }
    }
}

impl std::error::Error for RpWriteError {}

impl crate::layout::ErrorHint for RpWriteError {}

impl From<ResourceError> for RpWriteError {
    fn from(value: ResourceError) -> Self {
        match value {
            ResourceError::AlreadyDeclared(name) => Self::AlreadyDeclared(name),
            ResourceError::NotDeclared(name) => Self::NotDeclared(name),
            other => Self::Shared(other),
        }
    }
}

impl From<ResourceMutationError> for RpWriteError {
    fn from(value: ResourceMutationError) -> Self {
        match value {
            ResourceMutationError::InvalidName(name) => Self::InvalidName(name),
            ResourceMutationError::AlreadyDeclared(name) => Self::AlreadyDeclared(name),
            ResourceMutationError::NotDeclared(name) => Self::NotDeclared(name),
            ResourceMutationError::InvalidUrl(reason) => Self::InvalidUrl(reason),
            ResourceMutationError::InvalidKind(kind) => {
                Self::Shared(ResourceError::Invalid(format!("unknown kind `{kind}`")))
            }
            ResourceMutationError::MissingUrl(name) => Self::Shared(ResourceError::Invalid(
                format!("entry `{name}` requires --url"),
            )),
            ResourceMutationError::UnexpectedUrl(name) => Self::Shared(ResourceError::Invalid(
                format!("entry `{name}` is a select/relay; --url is ignored"),
            )),
            ResourceMutationError::Shared(shared) => Self::Shared(shared),
        }
    }
}

/// Source-kind spec for the CLI writer. Mirrors
/// `cli::RuleProviderSourceSpec` but erases the bounded text / path.
#[derive(Debug, Clone)]
pub enum RpSourceSpec {
    Http { url: String, interval_ms: u64 },
    File { path: PathBuf },
    Inline { payload: String },
}

impl RpSourceSpec {
    /// Maps to the wire source ref.
    pub fn to_ref(&self) -> RuleProviderSourceRef {
        match self {
            Self::Http { url, interval_ms } => RuleProviderSourceRef::Http {
                url: url.clone(),
                interval_ms: *interval_ms,
            },
            Self::File { path } => RuleProviderSourceRef::File {
                path: path.display().to_string(),
            },
            Self::Inline { payload } => RuleProviderSourceRef::Inline {
                payload: payload.clone(),
            },
        }
    }
}

/// The behavior the rule body contains. Non-default variants are
/// currently only constructed by tests; see above.
#[allow(dead_code)]
#[derive(Debug, Clone, Copy)]
pub enum RpBehavior {
    Domain,
    DomainSuffix,
    IpCidr,
    Classical,
}

impl RpBehavior {
    /// Default when the operator does not pass `--behavior` explicitly.
    pub const DEFAULT: Self = Self::Domain;

    /// The wire `--behavior` spelling (kebab-case).
    pub const fn cli_name(self) -> &'static str {
        match self {
            Self::Domain => "domain",
            Self::DomainSuffix => "domain-suffix",
            Self::IpCidr => "ip-cidr",
            Self::Classical => "classical",
        }
    }
}

/// Re-export of the unified `Outcome` shape.
pub type RpWriteOutcome = ResourceWriteOutcome;

/// `set rule-provider add-http|add-file|add-inline`.
pub fn add_provider(
    paths: &AppPaths,
    name: &str,
    source: &RpSourceSpec,
    behavior: RpBehavior,
    apply: bool,
) -> Result<RpWriteOutcome, RpWriteError> {
    let mutation = RuleProviderMutation::Add {
        name: name.to_owned(),
        source: source.to_ref(),
        behavior: Some(behavior.cli_name().to_owned()),
    };
    caly_core::configstore::resource_mutations::mutate_rule_provider(paths, &mutation, apply)
        .map_err(RpWriteError::from)
}

/// `set rule-provider remove` — filters the `rule_providers:` list.
pub fn remove_provider(
    paths: &AppPaths,
    name: &str,
    apply: bool,
) -> Result<RpWriteOutcome, RpWriteError> {
    let mutation = RuleProviderMutation::Remove {
        name: name.to_owned(),
    };
    caly_core::configstore::resource_mutations::mutate_rule_provider(paths, &mutation, apply)
        .map_err(RpWriteError::from)
}

/// `set rule-provider enable|disable` — flips the `enabled` flag.
pub fn set_enabled(
    paths: &AppPaths,
    name: &str,
    enabled: bool,
    apply: bool,
) -> Result<RpWriteOutcome, RpWriteError> {
    let mutation = if enabled {
        RuleProviderMutation::Enable {
            name: name.to_owned(),
        }
    } else {
        RuleProviderMutation::Disable {
            name: name.to_owned(),
        }
    };
    caly_core::configstore::resource_mutations::mutate_rule_provider(paths, &mutation, apply)
        .map_err(RpWriteError::from)
}

#[cfg(test)]
mod tests {
//! Tests for `client/rule_provider.rs`, extracted to the sibling
//! convention file (audit #70 file-length budget).

use super::*;
use crate::test_helpers::temp_root;
use std::fs;

fn seed_at_roots(dir: &std::path::Path) -> AppPaths {
    let paths = crate::test_helpers::hermetic_paths(dir);
    let target = paths.config.join("config.yaml");
    fs::create_dir_all(&paths.config).unwrap();
    fs::write(
        &target,
        "schema_version: 1\ncore: mihomo\nrule_providers: []\n",
    )
    .unwrap();
    paths
}

#[test]
fn add_http_dry_run_does_not_touch_disk() {
    let dir = temp_root("__FUNC__");
    let paths = seed_at_roots(dir.as_path());
    let outcome = add_provider(
        &paths,
        "geoip-cn",
        &RpSourceSpec::Http {
            url: "https://example.com/geoip-cn".to_owned(),
            interval_ms: 86_400_000,
        },
        RpBehavior::Domain,
        false,
    )
    .unwrap();
    assert_eq!(outcome, RpWriteOutcome::DryRun);
    let expected = "schema_version: 1\ncore: mihomo\nrule_providers: []\n";
    let after = std::fs::read_to_string(paths.config.join("config.yaml")).unwrap();
    assert_eq!(after, expected);
}

#[test]
fn add_http_apply_persists_a_new_provider() {
    let dir = temp_root("__FUNC__");
    let paths = seed_at_roots(dir.as_path());
    let outcome = add_provider(
        &paths,
        "geoip-cn",
        &RpSourceSpec::Http {
            url: "https://example.com/geoip-cn".to_owned(),
            interval_ms: 86_400_000,
        },
        RpBehavior::DomainSuffix,
        true,
    )
    .unwrap();
    assert_eq!(outcome, RpWriteOutcome::Applied);
    let bytes = std::fs::read(paths.config.join("config.yaml")).unwrap();
    let value: serde_norway::Value = serde_norway::from_slice(&bytes).unwrap();
    let providers = value
        .get("rule_providers")
        .and_then(|v| v.as_sequence())
        .unwrap_or_else(|| panic!("rule_providers must exist after a successful write"));
    assert_eq!(providers.len(), 1);
    assert_eq!(
        providers[0].get("name").and_then(|v| v.as_str()),
        Some("geoip-cn")
    );
    assert_eq!(
        providers[0].get("type").and_then(|v| v.as_str()),
        Some("http")
    );
    assert_eq!(
        providers[0].get("behavior").and_then(|v| v.as_str()),
        Some("domain_suffix")
    );
    // The default `enabled: true` is preserved.
    assert_eq!(
        providers[0]
            .get("enabled")
            .and_then(serde_norway::Value::as_bool),
        Some(true)
    );
    // A backup sidecar must exist.
    let backup = paths.config.join("config.yaml.bak");
    assert!(backup.exists(), "backup sidecar must be written");
}

#[test]
fn add_inline_apply_writes_an_inline_provider() {
    let dir = temp_root("__FUNC__");
    let paths = seed_at_roots(dir.as_path());
    let outcome = add_provider(
        &paths,
        "local-rules",
        &RpSourceSpec::Inline {
            payload: "DOMAIN,example.com,auto\n".to_owned(),
        },
        RpBehavior::Classical,
        true,
    )
    .unwrap();
    assert_eq!(outcome, RpWriteOutcome::Applied);
    let bytes = std::fs::read(paths.config.join("config.yaml")).unwrap();
    let value: serde_norway::Value = serde_norway::from_slice(&bytes).unwrap();
    let providers = value
        .get("rule_providers")
        .and_then(|v| v.as_sequence())
        .unwrap_or_else(|| panic!("rule_providers must exist after a successful write"));
    assert_eq!(providers.len(), 1);
    assert_eq!(
        providers[0].get("type").and_then(|v| v.as_str()),
        Some("inline")
    );
}

#[test]
fn add_provider_rejects_duplicate_name() {
    let dir = temp_root("__FUNC__");
    let paths = seed_at_roots(dir.as_path());
    add_provider(
        &paths,
        "geoip-cn",
        &RpSourceSpec::Http {
            url: "https://example.com/geoip-cn".to_owned(),
            interval_ms: 86_400_000,
        },
        RpBehavior::Domain,
        true,
    )
    .unwrap();
    let result = add_provider(
        &paths,
        "geoip-cn",
        &RpSourceSpec::Http {
            url: "https://example.com/other".to_owned(),
            interval_ms: 86_400_000,
        },
        RpBehavior::Domain,
        true,
    );
    // the duplicate check now surfaces
    // `AlreadyDeclared` (not the generic `Write`).
    assert!(matches!(result, Err(RpWriteError::AlreadyDeclared(_))));
}

#[test]
fn add_provider_rejects_unsafe_name() {
    let dir = temp_root("__FUNC__");
    let paths = seed_at_roots(dir.as_path());
    let result = add_provider(
        &paths,
        "../escape",
        &RpSourceSpec::Http {
            url: "https://example.com/x".to_owned(),
            interval_ms: 86_400_000,
        },
        RpBehavior::Domain,
        true,
    );
    assert!(matches!(result, Err(RpWriteError::InvalidName(_))));
}

#[test]
fn add_provider_rejects_non_http_url() {
    let dir = temp_root("__FUNC__");
    let paths = seed_at_roots(dir.as_path());
    let result = add_provider(
        &paths,
        "x",
        &RpSourceSpec::Http {
            url: "file:///etc/passwd".to_owned(),
            interval_ms: 86_400_000,
        },
        RpBehavior::Domain,
        true,
    );
    assert!(matches!(result, Err(RpWriteError::InvalidUrl(_))));
}

#[test]
fn remove_provider_filters_a_matching_name() {
    let dir = temp_root("__FUNC__");
    let paths = seed_at_roots(dir.as_path());
    add_provider(
        &paths,
        "a",
        &RpSourceSpec::Http {
            url: "https://example.com/a".to_owned(),
            interval_ms: 86_400_000,
        },
        RpBehavior::Domain,
        true,
    )
    .unwrap();
    add_provider(
        &paths,
        "b",
        &RpSourceSpec::Http {
            url: "https://example.com/b".to_owned(),
            interval_ms: 86_400_000,
        },
        RpBehavior::Domain,
        true,
    )
    .unwrap();
    let outcome = remove_provider(&paths, "a", true).unwrap();
    assert_eq!(outcome, RpWriteOutcome::Applied);
    let bytes = std::fs::read(paths.config.join("config.yaml")).unwrap();
    let value: serde_norway::Value = serde_norway::from_slice(&bytes).unwrap();
    let providers = value
        .get("rule_providers")
        .and_then(|v| v.as_sequence())
        .unwrap_or_else(|| panic!("rule_providers must exist after a successful write"));
    assert_eq!(providers.len(), 1);
    assert_eq!(providers[0].get("name").and_then(|v| v.as_str()), Some("b"));
}

#[test]
fn remove_provider_rejects_unknown_name() {
    let dir = temp_root("__FUNC__");
    let paths = seed_at_roots(dir.as_path());
    let result = remove_provider(&paths, "nope", true);
    // the unknown-name check now surfaces
    // `NotDeclared` (not the generic `Write`).
    assert!(matches!(result, Err(RpWriteError::NotDeclared(_))));
}

#[test]
fn set_enabled_flips_the_flag() {
    let dir = temp_root("__FUNC__");
    let paths = seed_at_roots(dir.as_path());
    add_provider(
        &paths,
        "a",
        &RpSourceSpec::Http {
            url: "https://example.com/a".to_owned(),
            interval_ms: 86_400_000,
        },
        RpBehavior::Domain,
        true,
    )
    .unwrap();
    let outcome = set_enabled(&paths, "a", false, true).unwrap();
    assert_eq!(outcome, RpWriteOutcome::Applied);
    let bytes = std::fs::read(paths.config.join("config.yaml")).unwrap();
    let value: serde_norway::Value = serde_norway::from_slice(&bytes).unwrap();
    let providers = value
        .get("rule_providers")
        .and_then(|v| v.as_sequence())
        .unwrap_or_else(|| panic!("rule_providers must exist after a successful write"));
    assert_eq!(
        providers[0]
            .get("enabled")
            .and_then(serde_norway::Value::as_bool),
        Some(false)
    );
}

#[test]
fn set_enabled_dry_run_against_unknown_name_surfaces_not_declared() {
    // Round 27 (debug): the pre-Round 27 shape
    // returned `DryRun` (success) for an unknown
    // name on the dry-run path, but `NotDeclared`
    // (error) on the apply path. The dry-run now
    // previews the apply outcome: an unknown
    // name surfaces `NotDeclared` regardless of
    // `apply`, matching the `add_provider` /
    // `remove_provider` writers' contract. The
    // `set_enabled_flips_the_flag` positive test
    // above locks the `apply` path; this test
    // locks the `dry-run` path's existence
    // check.
    let dir = temp_root("__FUNC__");
    let paths = seed_at_roots(dir.as_path());
    let result = set_enabled(&paths, "nope", false, false);
    assert!(
        matches!(result, Err(RpWriteError::NotDeclared(_))),
        "dry-run enable on an unknown name must fail with NotDeclared, got {result:?}"
    );
    let _ = fs::remove_dir_all(&dir);
}

}
