//! Offline proxy-group writer for the `set proxy-group …` leaves.
//!
//! The 5 CRUD leaves (`add` / `remove` / `enable` / `disable` /
//! `list`) round-trip `proxy_groups: Vec<ProxyGroupConfig>` in
//! `config.yaml`. Since the CLI-sinking round 2, the
//! write semantics live in ONE shared implementation,
//! `caly_core::configstore::resource_mutations` (the same code the daemon's
//! config-mutation actor runs); this module is the CLI's thin
//! offline adapter: it maps the CLI grammar types (`PgTypeSpec` /
//! `PgMemberSpec`) onto the wire payloads and projects the shared
//! error enum onto the stable `PgWriteError` codes.

use caly_core::domain::{ProxyGroupMemberRef, ProxyGroupMutation};
use caly_daemon::platform::paths::AppPaths;
use caly_core::profile::schema::ProxyGroupTypeConfig;

use caly_core::configstore::resource_mutations::ResourceMutationError;
use caly_core::configstore::resource_writer::{ResourceError, ResourceWriteOutcome};

/// Proxy-group-specific error variants. The shared
/// [`ResourceError`] cases flow through the `Shared(_)` arm so
/// the dispatch has one `match` instead of two parallel enums.
#[derive(Debug)]
pub enum PgWriteError {
    /// The id is empty or not path-safe ASCII.
    InvalidName(String),
    /// `add` on a name that's already in `proxy_groups:`.
    AlreadyDeclared(String),
    /// `remove` / `enable` / `disable` on a name that's not in
    /// `proxy_groups:`.
    NotDeclared(String),
    /// A `url-test` / `fallback` / `load-balance` group was
    /// added without a `--url` flag.
    MissingUrl(String),
    /// A `select` / `relay` group was added with a `--url`
    /// flag.
    UnexpectedUrl(String),
    /// Any other failure the shared writer surfaces.
    Shared(ResourceError),
}

impl core::fmt::Display for PgWriteError {
    fn fmt(&self, formatter: &mut core::fmt::Formatter<'_>) -> core::fmt::Result {
        match self {
            Self::InvalidName(name) => {
                write!(
                    formatter,
                    "proxy group name `{name}` is not path-safe ASCII"
                )
            }
            Self::AlreadyDeclared(name) => {
                write!(formatter, "proxy group `{name}` is already declared")
            }
            Self::NotDeclared(name) => write!(formatter, "proxy group `{name}` is not declared"),
            Self::MissingUrl(name) => write!(
                formatter,
                "proxy group `{name}` requires --url (url-test / fallback / load-balance)"
            ),
            Self::UnexpectedUrl(name) => write!(
                formatter,
                "proxy group `{name}` is a select/relay; --url is ignored (drop the flag)"
            ),
            Self::Shared(shared) => write!(formatter, "{shared}"),
        }
    }
}

impl std::error::Error for PgWriteError {}

impl crate::layout::ErrorHint for PgWriteError {}

impl From<ResourceError> for PgWriteError {
    fn from(value: ResourceError) -> Self {
        match value {
            ResourceError::AlreadyDeclared(name) => Self::AlreadyDeclared(name),
            ResourceError::NotDeclared(name) => Self::NotDeclared(name),
            other => Self::Shared(other),
        }
    }
}

impl From<ResourceMutationError> for PgWriteError {
    fn from(value: ResourceMutationError) -> Self {
        match value {
            ResourceMutationError::InvalidName(name) => Self::InvalidName(name),
            ResourceMutationError::AlreadyDeclared(name) => Self::AlreadyDeclared(name),
            ResourceMutationError::NotDeclared(name) => Self::NotDeclared(name),
            ResourceMutationError::MissingUrl(name) => Self::MissingUrl(name),
            ResourceMutationError::UnexpectedUrl(name) => Self::UnexpectedUrl(name),
            ResourceMutationError::InvalidKind(kind) => {
                Self::Shared(ResourceError::Invalid(format!("unknown kind `{kind}`")))
            }
            ResourceMutationError::InvalidUrl(reason) => {
                Self::Shared(ResourceError::Invalid(reason))
            }
            ResourceMutationError::Shared(shared) => Self::Shared(shared),
        }
    }
}

/// Type-kind spec for the CLI writer. Mirrors
/// `cli::ProxyGroupTypeSpec` but stays a CLI-side enum.
#[derive(Debug, Clone, Copy, Eq, PartialEq)]
pub enum PgTypeSpec {
    Select,
    UrlTest,
    Fallback,
    LoadBalance,
    Relay,
}

impl PgTypeSpec {
    pub const fn to_schema(self) -> ProxyGroupTypeConfig {
        match self {
            Self::Select => ProxyGroupTypeConfig::Select,
            Self::UrlTest => ProxyGroupTypeConfig::UrlTest,
            Self::Fallback => ProxyGroupTypeConfig::Fallback,
            Self::LoadBalance => ProxyGroupTypeConfig::LoadBalance,
            Self::Relay => ProxyGroupTypeConfig::Relay,
        }
    }

    /// The wire `kind:` spelling (kebab-case), shared by the daemon RPC
    /// payload and the offline writer.
    pub const fn clash_label(self) -> &'static str {
        self.to_schema().clash_label()
    }
}

impl From<crate::types::ProxyGroupTypeSpec> for PgTypeSpec {
    fn from(value: crate::types::ProxyGroupTypeSpec) -> Self {
        match value {
            crate::types::ProxyGroupTypeSpec::Select => Self::Select,
            crate::types::ProxyGroupTypeSpec::UrlTest => Self::UrlTest,
            crate::types::ProxyGroupTypeSpec::Fallback => Self::Fallback,
            crate::types::ProxyGroupTypeSpec::LoadBalance => Self::LoadBalance,
            crate::types::ProxyGroupTypeSpec::Relay => Self::Relay,
        }
    }
}

/// Member spec for the CLI writer. Mirrors
/// `cli::ProxyGroupMemberSpec` but erases the CLI grammar.
#[derive(Debug, Clone, Eq, PartialEq)]
pub enum PgMemberSpec {
    Node { tag: String },
    Group { name: String },
    Direct,
    Reject,
}

impl PgMemberSpec {
    /// Maps to the wire `members:` ref.
    pub fn to_ref(&self) -> ProxyGroupMemberRef {
        match self {
            Self::Node { tag } => ProxyGroupMemberRef::Node(tag.clone()),
            Self::Group { name } => ProxyGroupMemberRef::Group(name.clone()),
            Self::Direct => ProxyGroupMemberRef::Direct,
            Self::Reject => ProxyGroupMemberRef::Reject,
        }
    }
}

/// What an `add` / `remove` / `enable` / `disable` call did.
pub type PgWriteOutcome = ResourceWriteOutcome;

/// `set proxy-group add <name> --type <kind> [--members …] [--url …]`.
pub fn add_group(
    paths: &AppPaths,
    name: &str,
    group_type: PgTypeSpec,
    members: &[PgMemberSpec],
    url: Option<&str>,
    interval_seconds: Option<u32>,
    tolerance_ms: Option<u32>,
    apply: bool,
) -> Result<PgWriteOutcome, PgWriteError> {
    let mutation = ProxyGroupMutation::Add {
        name: name.to_owned(),
        kind: group_type.clash_label().to_owned(),
        members: members.iter().map(PgMemberSpec::to_ref).collect(),
        url: url.map(str::to_owned),
        interval_seconds,
        tolerance_ms,
    };
    caly_core::configstore::resource_mutations::mutate_proxy_group(paths, &mutation, apply)
        .map_err(PgWriteError::from)
}

/// `set proxy-group remove` — filters the `proxy_groups:` list by name.
pub fn remove_group(
    paths: &AppPaths,
    name: &str,
    apply: bool,
) -> Result<PgWriteOutcome, PgWriteError> {
    let mutation = ProxyGroupMutation::Remove {
        name: name.to_owned(),
    };
    caly_core::configstore::resource_mutations::mutate_proxy_group(paths, &mutation, apply)
        .map_err(PgWriteError::from)
}

/// `set proxy-group enable|disable` — flips the `enabled` flag.
pub fn set_enabled(
    paths: &AppPaths,
    name: &str,
    enabled: bool,
    apply: bool,
) -> Result<PgWriteOutcome, PgWriteError> {
    let mutation = if enabled {
        ProxyGroupMutation::Enable {
            name: name.to_owned(),
        }
    } else {
        ProxyGroupMutation::Disable {
            name: name.to_owned(),
        }
    };
    caly_core::configstore::resource_mutations::mutate_proxy_group(paths, &mutation, apply)
        .map_err(PgWriteError::from)
}

/// Reads the declared `proxy_groups:` list from the layered config.
pub fn probe_layered_config(paths: &AppPaths) -> Result<(), String> {
    super::load_layered_lenient(&paths.config, None).map(|_| ())
}

pub fn read_declared(paths: &AppPaths) -> Vec<(String, bool, String, usize, bool)> {
    match super::load_layered_lenient(&paths.config, None) {
        Ok(config) => config
            .proxy_groups
            .into_iter()
            .map(|g| {
                let kind = g.group_type.clash_label().to_owned();
                let member_count = g.members.len();
                let has_url_test = g.url_test.is_some();
                (g.name, g.enabled, kind, member_count, has_url_test)
            })
            .collect(),
        Err(_) => Vec::new(),
    }
}

#[cfg(test)]
mod tests {
//! Tests for `client/proxy_group.rs`, extracted to the sibling
//! convention file (audit #70 file-length budget).

use super::*;
use crate::test_helpers::temp_root;
use std::fs;

fn seed_at_roots(dir: &std::path::Path) -> AppPaths {
    let paths = crate::test_helpers::hermetic_paths(dir);
    let target = paths.config.join("config.yaml");
    fs::create_dir_all(&paths.config).unwrap();
    fs::write(
        &target,
        "schema_version: 1\ncore: mihomo\nproxy_groups: []\n",
    )
    .unwrap();
    paths
}

#[test]
fn add_select_dry_run_does_not_touch_disk() {
    let dir = temp_root("__FUNC__");
    let paths = seed_at_roots(dir.as_path());
    let outcome = add_group(
        &paths,
        "Proxy",
        PgTypeSpec::Select,
        &[PgMemberSpec::Direct],
        None,
        None,
        None,
        false,
    )
    .unwrap();
    assert_eq!(outcome, PgWriteOutcome::DryRun);
    let expected = "schema_version: 1\ncore: mihomo\nproxy_groups: []\n";
    let after = std::fs::read_to_string(paths.config.join("config.yaml")).unwrap();
    assert_eq!(after, expected);
}

#[test]
fn add_url_test_without_url_is_rejected_early() {
    let dir = temp_root("__FUNC__");
    let paths = seed_at_roots(dir.as_path());
    let result = add_group(
        &paths,
        "Auto",
        PgTypeSpec::UrlTest,
        &[PgMemberSpec::Direct],
        None,
        None,
        None,
        true,
    );
    assert!(matches!(result, Err(PgWriteError::MissingUrl(_))));
}

#[test]
fn add_select_with_url_is_rejected_early() {
    let dir = temp_root("__FUNC__");
    let paths = seed_at_roots(dir.as_path());
    let result = add_group(
        &paths,
        "Proxy",
        PgTypeSpec::Select,
        &[PgMemberSpec::Direct],
        Some("http://example.com/probe"),
        None,
        None,
        true,
    );
    assert!(matches!(result, Err(PgWriteError::UnexpectedUrl(_))));
}

#[test]
fn add_url_test_apply_persists_a_group() {
    let dir = temp_root("__FUNC__");
    let paths = seed_at_roots(dir.as_path());
    let outcome = add_group(
        &paths,
        "Auto",
        PgTypeSpec::UrlTest,
        &[PgMemberSpec::Direct],
        Some("http://www.gstatic.com/generate_204"),
        Some(300),
        Some(50),
        true,
    )
    .unwrap_or_else(|error| panic!("must succeed: {error}"));
    assert_eq!(outcome, PgWriteOutcome::Applied);
    let bytes = std::fs::read(paths.config.join("config.yaml")).unwrap();
    let value: serde_norway::Value = serde_norway::from_slice(&bytes).unwrap();
    let groups = value
        .get("proxy_groups")
        .and_then(|v| v.as_sequence())
        .unwrap_or_else(|| panic!("proxy_groups must exist after a successful write"));
    assert_eq!(groups.len(), 1);
    assert_eq!(groups[0].get("name").and_then(|v| v.as_str()), Some("Auto"));
    assert_eq!(
        groups[0].get("type").and_then(|v| v.as_str()),
        Some("url-test")
    );
    let url_test = groups[0]
        .get("url_test")
        .and_then(|v| v.as_mapping())
        .unwrap();
    assert_eq!(
        url_test.get("url").and_then(|v| v.as_str()),
        Some("http://www.gstatic.com/generate_204")
    );
    assert_eq!(
        url_test
            .get("interval_seconds")
            .and_then(serde_norway::Value::as_u64),
        Some(300)
    );
    assert_eq!(
        url_test
            .get("tolerance_ms")
            .and_then(serde_norway::Value::as_u64),
        Some(50)
    );
    // The backup sidecar must exist.
    let backup = paths.config.join("config.yaml.bak");
    assert!(backup.exists(), "backup sidecar must be written");
}

#[test]
fn add_group_rejects_unsafe_name() {
    let dir = temp_root("__FUNC__");
    let paths = seed_at_roots(dir.as_path());
    let result = add_group(
        &paths,
        "../escape",
        PgTypeSpec::Select,
        &[PgMemberSpec::Direct],
        None,
        None,
        None,
        true,
    );
    assert!(matches!(result, Err(PgWriteError::InvalidName(_))));
}

#[test]
fn add_group_rejects_duplicate_name() {
    let dir = temp_root("__FUNC__");
    let paths = seed_at_roots(dir.as_path());
    add_group(
        &paths,
        "Proxy",
        PgTypeSpec::Select,
        &[PgMemberSpec::Direct],
        None,
        None,
        None,
        true,
    )
    .unwrap();
    let result = add_group(
        &paths,
        "Proxy",
        PgTypeSpec::Select,
        &[PgMemberSpec::Direct],
        None,
        None,
        None,
        true,
    );
    assert!(matches!(result, Err(PgWriteError::AlreadyDeclared(_))));
}

#[test]
fn remove_group_filters_a_matching_name() {
    let dir = temp_root("__FUNC__");
    let paths = seed_at_roots(dir.as_path());
    add_group(
        &paths,
        "a",
        PgTypeSpec::Select,
        &[PgMemberSpec::Direct],
        None,
        None,
        None,
        true,
    )
    .unwrap();
    add_group(
        &paths,
        "b",
        PgTypeSpec::Select,
        &[PgMemberSpec::Direct],
        None,
        None,
        None,
        true,
    )
    .unwrap();
    let outcome = remove_group(&paths, "a", true).unwrap();
    assert_eq!(outcome, PgWriteOutcome::Applied);
    let bytes = std::fs::read(paths.config.join("config.yaml")).unwrap();
    let value: serde_norway::Value = serde_norway::from_slice(&bytes).unwrap();
    let groups = value
        .get("proxy_groups")
        .and_then(|v| v.as_sequence())
        .unwrap_or_else(|| panic!("proxy_groups must exist after a successful write"));
    assert_eq!(groups.len(), 1);
    assert_eq!(groups[0].get("name").and_then(|v| v.as_str()), Some("b"));
}

#[test]
fn remove_group_rejects_unknown_name() {
    let dir = temp_root("__FUNC__");
    let paths = seed_at_roots(dir.as_path());
    let result = remove_group(&paths, "nope", true);
    assert!(matches!(result, Err(PgWriteError::NotDeclared(_))));
}

#[test]
fn set_enabled_flips_the_flag() {
    let dir = temp_root("__FUNC__");
    let paths = seed_at_roots(dir.as_path());
    add_group(
        &paths,
        "Proxy",
        PgTypeSpec::Select,
        &[PgMemberSpec::Direct],
        None,
        None,
        None,
        true,
    )
    .unwrap();
    let outcome = set_enabled(&paths, "Proxy", false, true).unwrap();
    assert_eq!(outcome, PgWriteOutcome::Applied);
    let bytes = std::fs::read(paths.config.join("config.yaml")).unwrap();
    let value: serde_norway::Value = serde_norway::from_slice(&bytes).unwrap();
    let groups = value
        .get("proxy_groups")
        .and_then(|v| v.as_sequence())
        .unwrap_or_else(|| panic!("proxy_groups must exist after a successful write"));
    assert_eq!(
        groups[0]
            .get("enabled")
            .and_then(serde_norway::Value::as_bool),
        Some(false)
    );
}

#[test]
fn set_enabled_dry_run_against_unknown_name_surfaces_not_declared() {
    // Round 27 (debug): the pre-Round 27 shape
    // returned `DryRun` (success) for an unknown
    // name on the dry-run path, but `NotDeclared`
    // (error) on the apply path. The dry-run
    // now previews the apply outcome: an
    // unknown name surfaces `NotDeclared`
    // regardless of `apply`, matching the
    // `add_group` / `remove_group` writers'
    // contract. The `set_enabled_flips_the_flag`
    // positive test above locks the `apply`
    // path; this test locks the `dry-run`
    // path's existence check.
    let dir = temp_root("__FUNC__");
    let paths = seed_at_roots(dir.as_path());
    let result = set_enabled(&paths, "nope", false, false);
    assert!(
        matches!(result, Err(PgWriteError::NotDeclared(_))),
        "dry-run enable on an unknown name must fail with NotDeclared, got {result:?}"
    );
    let _ = fs::remove_dir_all(&dir);
}

/// an idempotent `set proxy-group
/// enable <already-enabled-group>` is a
/// `NoChange` (not `Applied`). The pre-Round 31
/// shape returned `Applied` even when the
/// on-disk `enabled` flag was already the
/// target value, so the operator saw
/// `proxy group enabled` after a redundant
/// call. The Round 25 sub writer already
/// surfaces `NoChange` for the analogous
/// `set sub enable <already-enabled-url>`;
/// the proxy-group writer now matches that
/// contract. The dispatch's `run_writer`
/// envelope maps the `NoChange` kind to the
/// `Summaries::no_change` line, so the
/// operator-visible summary is
/// `proxy group already enabled`.
#[test]
fn set_enabled_idempotent_call_surfaces_no_change_in_dispatch() {
    let dir = temp_root("__FUNC__");
    let paths = seed_at_roots(dir.as_path());
    // Apply an `add` to populate the group
    // (default `enabled: true` per the schema).
    add_group(
        &paths,
        "Proxy",
        PgTypeSpec::Select,
        &[PgMemberSpec::Direct],
        None,
        None,
        None,
        true,
    )
    .unwrap();
    // Capture the on-disk bytes so the
    // idempotent `enable` does not rewrite
    // them (the pre-Round 31 shape silently
    // rewrote the file even when the state
    // was already the target).
    let config_path = paths.config.join("config.yaml");
    let before = fs::read(&config_path).unwrap();
    // The idempotent call: `enable` on an
    // already-enabled group with
    // `apply: true`. Round 31 expectation:
    // `NoChange` (not `Applied`), the
    // on-disk file is NOT rewritten, and the
    // dispatch's envelope surfaces
    // `no_change: true` for JSON consumers.
    let result = set_enabled(&paths, "Proxy", true, true);
    assert!(
        matches!(result, Ok(PgWriteOutcome::NoChange)),
        "idempotent enable must surface NoChange, got {result:?}"
    );
    let after = fs::read(&config_path).unwrap();
    assert_eq!(
        before, after,
        "idempotent enable must not rewrite config.yaml"
    );
    let _ = fs::remove_dir_all(&dir);
}

/// the symmetric `set proxy-group
/// disable <already-disabled-group>` also
/// surfaces `NoChange`. The pre-Round 31
/// shape returned `Applied` for the
/// idempotent disable as well; the new
/// shape is symmetric across the two
/// verbs.
#[test]
fn set_disabled_idempotent_call_surfaces_no_change_in_dispatch() {
    let dir = temp_root("__FUNC__");
    let paths = seed_at_roots(dir.as_path());
    add_group(
        &paths,
        "Proxy",
        PgTypeSpec::Select,
        &[PgMemberSpec::Direct],
        None,
        None,
        None,
        true,
    )
    .unwrap();
    // First `disable` flips the flag to
    // `enabled: false`.
    set_enabled(&paths, "Proxy", false, true).unwrap();
    // Second `disable` is the idempotent
    // call: the group is already disabled.
    let result = set_enabled(&paths, "Proxy", false, true);
    assert!(
        matches!(result, Ok(PgWriteOutcome::NoChange)),
        "idempotent disable must surface NoChange, got {result:?}"
    );
    let _ = fs::remove_dir_all(&dir);
}

}
