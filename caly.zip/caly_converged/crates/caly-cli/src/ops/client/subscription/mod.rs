//! Offline subscription writer for the `set sub …` leaves.
//!
//! also owns the offline subscription
//! **inspection** surface (`list` / `check` / `import`)
//! that `show sub …` and the legacy `set sub import`
//! preview path go through. The previous home
//! (`commands::bridge`) is being retired; the helpers
//! below are the source of truth.
//!
//! The 5 CRUD writers round-trip
//! `subscriptions.sources: Vec<SubscriptionSource>` and
//! the `providers:` list when an `import` writes inline
//! nodes. The per-source writers live in [`sources`]
//! (audit #70 file-length budget); the inspection
//! surface lives in [`listing`].

use caly_daemon::platform::paths::AppPaths;

use caly_core::configstore::resource_writer::{ResourceError, ResourceWriteOutcome};

#[cfg(test)]
use caly_core::configstore::resource_writer::is_http_url;

mod sources;

pub use sources::{
    add_source, disable_source, enable_source, remove_source, resolve_source_ref, set_source,
};

mod listing;

pub use listing::list_providers;

/// Subscription-specific error variants. The shared
/// [`ResourceError`] cases flow through the `Shared(_)` arm.
#[derive(Debug)]
pub enum SubCmdError {
    /// The URL is empty, missing a scheme, or points at a
    /// non-HTTP(S) scheme (the SSRF guard refuses
    /// `file://` and `data://`).
    InvalidUrl(String),
    /// The optional `--name` display name is empty after
    /// trimming, over-long, or contains control characters.
    InvalidName(String),
    /// `add` on a URL that's already in
    /// `subscriptions.sources`.
    AlreadyDeclared(String),
    /// W2-β2a (§8-4): `add --name` collides with the display name
    /// of an existing source.
    NameTaken(String),
    /// W2-β2a (§8-7): the three-segment `add` token resolved to a
    /// local file that does not exist. `given` is the token as
    /// typed, `resolved` its absolute form.
    SourceFileNotFound { given: String, resolved: String },
    /// W2-β2b: a name-shaped addressing token matched more than one
    /// source (hand-edited configs can duplicate names; `add` keeps
    /// them unique). Address by URL instead.
    AmbiguousName(String),
    /// W2-β2a: `--every` (non-zero) was passed for a file source,
    /// which is always static. Classed as usage → exit 2.
    EveryOnFile,
    /// `remove` / `enable` / `disable` on a URL that's
    /// not in `subscriptions.sources`.
    NotDeclared(String),
    /// Any other failure the shared writer surfaces
    /// (read / parse / validate / IO). Carries the
    /// human-readable reason.
    Shared(ResourceError),
}

impl core::fmt::Display for SubCmdError {
    fn fmt(&self, formatter: &mut core::fmt::Formatter<'_>) -> core::fmt::Result {
        match self {
            Self::InvalidUrl(reason) => write!(formatter, "invalid subscription URL: {reason}"),
            Self::InvalidName(reason) => write!(formatter, "invalid source name: {reason}"),
            Self::AlreadyDeclared(url) => {
                write!(formatter, "subscription source `{url}` is already declared")
            }
            // §8-4 contract, verbatim wording ("subscription \"N\"
            // already exists.").
            Self::NameTaken(name) => write!(formatter, "subscription \"{name}\" already exists."),
            // §8-7 contract: the error block itself is three lines —
            // what / resolved-absolute / how to disambiguate.
            Self::SourceFileNotFound { given, resolved } => write!(
                formatter,
                "file not found: {given}\nResolved absolute: {resolved}\nIf you meant a URL, include the scheme: https://..."
            ),
            Self::EveryOnFile => write!(
                formatter,
                "`--every` has no effect on file sources: a local file never changes upstream, so the source stays static (every: 0)."
            ),
            Self::AmbiguousName(name) => write!(
                formatter,
                "multiple subscription sources are named \"{name}\"; address the one you mean by its URL."
            ),
            Self::NotDeclared(url) => {
                write!(formatter, "subscription source `{url}` is not declared")
            }
            Self::Shared(shared) => write!(formatter, "{shared}"),
        }
    }
}

impl std::error::Error for SubCmdError {}

impl crate::layout::ErrorHint for SubCmdError {
    fn hint(&self) -> Option<String> {
        match self {
            // §8-4: point at `sub set` (β2b, same window) or a fresh
            // name.
            Self::NameTaken(name) => Some(format!(
                "Use `caly sub set {name} --url <new-url>` to update, or `caly sub add <url> --name <other>` to rename."
            )),
            Self::AlreadyDeclared(url) => Some(format!(
                "Use `caly sub set {url} --every <hours>` to change its cadence, or `caly sub remove {url}` to delete it first."
            )),
            Self::EveryOnFile => Some("Drop `--every` to accept the static pin.".to_owned()),
            Self::AmbiguousName(_) => Some(
                "Re-run with the source URL instead of the name; `caly sub list` shows both."
                    .to_owned(),
            ),
            _ => None,
        }
    }
}

impl From<ResourceError> for SubCmdError {
    fn from(value: ResourceError) -> Self {
        match value {
            ResourceError::AlreadyDeclared(name) => Self::AlreadyDeclared(name),
            ResourceError::NotDeclared(name) => Self::NotDeclared(name),
            other => Self::Shared(other),
        }
    }
}

/// Projects the shared writer's error onto the stable CLI codes. The
/// two enums are variant-for-variant mirrors, so the delegation is a
/// pure rename — every `code_for` mapping downstream is unchanged.
impl From<caly_core::configstore::subscription_sources::SubSourceError> for SubCmdError {
    fn from(value: caly_core::configstore::subscription_sources::SubSourceError) -> Self {
        use caly_core::configstore::subscription_sources::SubSourceError as E;
        match value {
            E::InvalidUrl(reason) => Self::InvalidUrl(reason),
            E::InvalidName(reason) => Self::InvalidName(reason),
            E::AlreadyDeclared(url) => Self::AlreadyDeclared(url),
            E::NameTaken(name) => Self::NameTaken(name),
            E::SourceFileNotFound { given, resolved } => {
                Self::SourceFileNotFound { given, resolved }
            }
            E::EveryOnFile => Self::EveryOnFile,
            E::AmbiguousName(token) => Self::AmbiguousName(token),
            E::NotDeclared(target) => Self::NotDeclared(target),
            E::Shared(error) => Self::Shared(error),
        }
    }
}

impl From<caly_core::configstore::config_writer::ConfigWriteError> for SubCmdError {
    fn from(value: caly_core::configstore::config_writer::ConfigWriteError) -> Self {
        Self::Shared(ResourceError::from(value))
    }
}

/// Prints a check/import failure in the requested mode and returns the
/// generic-failure exit code (usage errors already folded to 2 upstream).
fn report_sub_failure(
    code: &'static str,
    command: &'static str,
    message: String,
    hint: Option<&str>,
    json: bool,
) -> std::process::ExitCode {
    let output = crate::layout::CliOutput::from_json_flag(json);
    let mut failure = crate::layout::CliError::new(code, message, command);
    if let Some(hint) = hint {
        failure = failure.with_hint(hint);
    }
    crate::layout::report_error_returning(output, failure)
}

/// Ensures `config.yaml` exists, bootstrapping the default layout on a
/// fresh install so the first `sub add` works out of the box
/// (用户动线 audit). Split out of [`load_declared_with`] for the
/// delegating writers, which need the bootstrap side effect without
/// paying for a full layered load they would discard.
pub fn ensure_config(paths: &AppPaths) -> Result<(), SubCmdError> {
    if !paths.config.join("config.yaml").exists() {
        crate::client::config_generate::load_config_with_bootstrap(paths, false)
            .map_err(SubCmdError::InvalidUrl)?;
    }
    Ok(())
}

/// Loads the active `AppConfig` from `paths` (so the
/// tests can inject a hermetic root via
/// `AppPaths::from_env_vars(&test_env())`).
pub fn load_declared_with(
    paths: &AppPaths,
) -> Result<caly_core::profile::schema::AppConfig, SubCmdError> {
    ensure_config(paths)?;
    super::load_layered_lenient(&paths.config, None).map_err(|error| {
        SubCmdError::Shared(ResourceError::Write(format!(
            "load layered config: {error}"
        )))
    })
}

/// What an `add` / `remove` / `enable` / `disable` /
/// `import` call did. `DryRun` is what `--dry-run` (the
/// default) returns when the call would have written.
pub type SubWriteOutcome = ResourceWriteOutcome;

/// The usability exit code: dialable nodes or a URL list → 0, else 1
/// (the document parsed but offers nothing refreshable).
fn usable_exit(usable: bool) -> std::process::ExitCode {
    if usable {
        std::process::ExitCode::SUCCESS
    } else {
        std::process::ExitCode::from(1)
    }
}

/// `show sub parse <path>` — offline subscription tree (W3a,
/// cli-v3-design.md G1/§5.3/§6.1). Human default is the three-zone
/// entry tree; `--json` is the §6.1 contract. url-list and ssr-only
/// documents keep the legacy summary shape.
pub fn check_subscription(
    path: &std::path::Path,
    userinfo: Option<&str>,
    json: bool,
) -> std::process::ExitCode {
    match crate::subscription::parse_subscription_tree(path, userinfo) {
        Ok(outcome) => {
            if json {
                println!("{}", crate::subscription::render_tree_json(&outcome));
            } else {
                print!("{}", crate::subscription::render_tree_human(&outcome));
            }
            if outcome.is_usable() {
                usable_exit(true)
            } else {
                usable_exit(false)
            }
        }
        Err(error) => report_sub_failure(
            "sub.check_failed",
            "show sub parse",
            format!("subscription check failed: {error}"),
            None,
            json,
        ),
    }
}

/// `show sub import <path>` / `--clipboard` — parse a
/// URI list and print a preview.
pub fn import_preview(
    path: Option<&std::path::Path>,
    clipboard: bool,
    json: bool,
) -> std::process::ExitCode {
    use std::process::ExitCode;
    let summary = match (clipboard, path) {
        (true, Some(_)) => {
            crate::layout::error("`sub import --clipboard` takes no path argument");
            return ExitCode::from(2);
        }
        (true, None) | (false, None) => crate::subscription::read_clipboard(),
        (false, Some(path)) => crate::subscription::inspect_subscription_with_userinfo(path, None),
    };
    match summary {
        Ok(summary) => {
            if json {
                println!("{}", crate::subscription::render_json(&summary));
            } else {
                print!("{}", crate::subscription::render_human(&summary));
                if summary.format == "url-list" {
                    println!(
                        "This is a subscription *source* (fetchable URL). It is not persisted by `import`; add its URL to `subscriptions.sources` in config.yaml and it will appear in `caly sub list` as the default provider."
                    );
                } else {
                    println!(
                        "Preview only — nothing was saved. These are proxy node URIs (no upstream subscription URL), so they cannot form a subscription provider and won't appear in `sub list`. Paste a source subscription URL for a refreshable provider."
                    );
                }
            }
            usable_exit(crate::subscription::is_usable(&summary))
        }
        Err(error) => report_sub_failure(
            "sub.import_failed",
            "set sub import",
            format!("subscription import failed: {error}"),
            None,
            json,
        ),
    }
}

#[cfg(test)]
mod tests;
