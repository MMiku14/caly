//! Tests for `client/subscription.rs`, extracted to the sibling
//! convention file (audit #70 file-length budget).

#[test]
fn disabled_and_named_rows_survive_the_projection() {
    let declared = caly_core::profile::schema::SubscriptionConfig {
        url: None,
        sources: vec![
            caly_core::profile::schema::SubscriptionSource {
                url: "https://a.example.com/sub".to_owned(),
                enabled: true,
                name: Some("alpha".to_owned()),
                refresh_every_minutes: None,
            },
            caly_core::profile::schema::SubscriptionSource {
                url: "https://b.example.com/sub".to_owned(),
                enabled: false,
                name: None,
                refresh_every_minutes: None,
            },
        ],
        ..caly_core::profile::schema::SubscriptionConfig::default()
    };
    // Offline rows come from the shared configstore pipeline (same as
    // the daemon publishes): 1-based ids, `#N` name fallback, and the
    // uncached flags — the fake URLs have no cache bodies anywhere.
    let paths = caly_daemon::platform::paths::AppPaths::from_env();
    let projected: Vec<serde_json::Value> =
        caly_core::configstore::source_listing::compute_source_views(&paths, &declared)
            .into_iter()
            .map(super::source_view_row)
            .collect();
    assert_eq!(projected.len(), 2, "one row per declared source");
    assert_eq!(projected[0]["index"].as_u64(), Some(1));
    assert_eq!(projected[0]["name"].as_str(), Some("alpha"));
    assert_eq!(projected[0]["enabled"].as_bool(), Some(true));
    assert_eq!(projected[1]["index"].as_u64(), Some(2));
    assert_eq!(projected[1]["enabled"].as_bool(), Some(false));
    assert_eq!(projected[1]["name"].as_str(), Some("#2"));
    assert_eq!(projected[1]["cached"].as_bool(), Some(false));
}
