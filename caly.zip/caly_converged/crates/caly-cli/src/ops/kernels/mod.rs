//! Kernel version management (mihomo / sing-box).
//!
//! Local multi-version store under the data dir ([`store`]), version probing
//! by executing the binary's version flag ([`probe`]), official-release
//! download with hash verification ([`install`], fetching through
//! `caly-subscription`'s release client), and `core_binaries` selection via
//! the config-KV quiet writer — shared by the CLI (`core
//! versions|install|use|remove|upgrade`) and the TUI.
//!
//! Facts, not replicated daemon logic: `versions` shows the configured path,
//! the environment override, the store contents and the manifest pin side by
//! side, and lets the operator see what the daemon would resolve
//! (config > `CALY_*_BIN` > bundled `vendor/bin`).
//!
//! Mihomo geodata rides along ([`geo`]): `core upgrade` refreshes the
//! `<data>/geo` store after the kernel binaries, `core versions` lists it,
//! and the daemon seeds its ephemeral mihomo work dir from the store at
//! boot (see `caly-composition`'s `backends::provision_geodata`).

pub mod geo;
pub mod install;
pub mod manifest;
pub mod probe;
pub mod store;

use std::path::{Path, PathBuf};
use std::process::ExitCode;

pub use install::{InstallReport, VerifiedBy, install_latest, install_version, install_selective};
pub use store::KERNELS;

use geo::GeoOutcome;
use manifest::latest;
use probe::probe_version;
use store::{normalize_kernel, scan_store};

/// Sync→async bridge shared by the installers: the CLI is synchronous, so
/// build a private current-thread runtime and drive it with
/// `Runtime::block_on` (NOT `Handle::block_on`, which parks without polling
/// spawned tasks — hyper's connection driver never runs and the fetch stalls
/// forever). An ambient runtime means we are inside async code: fail loudly
/// instead of nesting (async callers must `spawn_blocking`).
pub(crate) fn block_on_fetch(url: &str, expected_sha256: Option<&str>) -> Result<Vec<u8>, String> {
    if tokio::runtime::Handle::try_current().is_ok() {
        return Err(
            "cannot download inside an async runtime; wrap the installer in spawn_blocking"
                .to_owned(),
        );
    }
    let runtime = tokio::runtime::Builder::new_current_thread()
        .enable_all()
        .build()
        .map_err(|error| format!("cannot start download runtime: {error}"))?;
    runtime
        .block_on(caly_core::subscription::fetch_release(url, expected_sha256))
        .map_err(|error| error.to_string())
}

/// Lowercase hex sha256 (release verification + local freshness checks).
pub(crate) fn hex_sha256(bytes: &[u8]) -> String {
    use sha2::{Digest, Sha256};
    let mut hasher = Sha256::new();
    hasher.update(bytes);
    let digest = hasher.finalize();
    let mut out = String::with_capacity(digest.len() * 2);
    for byte in digest {
        use std::fmt::Write as _;
        let _ = write!(out, "{byte:02x}");
    }
    out
}

/// A locally stored kernel binary.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct StoredKernel {
    /// `mihomo` or `sing-box`.
    pub kernel: String,
    /// Probed self-reported version (falls back to the directory name when
    /// the binary does not self-report).
    pub version: String,
    /// Absolute path to the executable.
    pub path: PathBuf,
}

/// Everything `versions` knows about one kernel. Data only (the TUI
/// renders it its own way); [`print_versions`] is the CLI renderer.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct KernelStatus {
    pub kernel: String,
    pub configured_path: Option<PathBuf>,
    pub configured_version: Option<String>,
    pub env_override: Option<PathBuf>,
    pub store: Vec<StoredKernel>,
    pub latest: Option<String>,
    pub store_has_latest: bool,
}

/// Parses a `<kernel>[@<version>]` spec (normalized kernel, optional version).
/// `install` accepts the bare kernel (manifest pin); `use`/`remove` go
/// through [`parse_pinned_spec`], which requires the version.
pub fn parse_kernel_spec(spec: &str) -> Result<(String, Option<String>), String> {
    let (kernel, version) = match spec.split_once('@') {
        Some((kernel, version)) => {
            if version.is_empty() {
                return Err(format!(
                    "bad kernel spec `{spec}` (expected <kernel> or <kernel>@<version>)"
                ));
            }
            (kernel, Some(version.to_owned()))
        }
        None => (spec, None),
    };
    let kernel = normalize_kernel(kernel).map_err(|_| {
        format!("bad kernel spec `{spec}` (expected mihomo or sing-box)")
    })?;
    Ok((kernel.to_owned(), version))
}

/// Parses a `<kernel>@<version>` spec with a REQUIRED version (`use`,
/// `remove` cannot act on an unpinned kernel).
pub fn parse_pinned_spec(spec: &str) -> Result<(String, String), String> {
    let (kernel, version) = parse_kernel_spec(spec)?;
    match version {
        Some(version) => Ok((kernel, version)),
        None => Err(format!(
            "bad kernel spec `{spec}` (a version is required: {kernel}@<version>)"
        )),
    }
}

/// Gathers the per-kernel status facts.
pub fn kernel_status(paths: &caly_daemon::platform::paths::AppPaths) -> Vec<KernelStatus> {
    let configured = crate::config::load_from(paths.config.clone())
        .ok()
        .flatten()
        .map(|config| crate::config::core_binaries_from_config(Some(&config)));
    let store = scan_store(&paths.data);
    KERNELS
        .iter()
        .map(|kernel| {
            let configured_path = configured.as_ref().and_then(|binaries| {
                if *kernel == "sing-box" {
                    binaries.sing_box.clone()
                } else {
                    binaries.mihomo.clone()
                }
            });
            let configured_version = configured_path
                .as_ref()
                .and_then(|path| probe_version(path).version);
            let env_name = if *kernel == "sing-box" {
                "CALY_SINGBOX_BIN"
            } else {
                "CALY_MIHOMO_BIN"
            };
            let env_override = std::env::var_os(env_name).map(PathBuf::from);
            let pinned = latest(kernel).map(|release| release.version.to_owned());
            let store_here: Vec<StoredKernel> = store
                .iter()
                .filter(|entry| entry.kernel == *kernel)
                .cloned()
                .collect();
            let store_has_latest = pinned.as_ref().is_some_and(|version| {
                store_here.iter().any(|entry| &entry.version == version)
            });
            KernelStatus {
                kernel: (*kernel).to_owned(),
                configured_path,
                configured_version,
                env_override,
                store: store_here,
                latest: pinned,
                store_has_latest,
            }
        })
        .collect()
}

/// `core versions`: the per-kernel fact table.
pub fn print_versions(paths: &caly_daemon::platform::paths::AppPaths, json: bool) -> ExitCode {
    let statuses = kernel_status(paths);
    let geodata = geo::scan_geo(&paths.data);
    if json {
        println!(
            "{}",
            crate::layout::CliOutput::success_envelope(serde_json::json!({
                "command": "core versions",
                "kernels": statuses.iter().map(status_json).collect::<Vec<_>>(),
                "geo": geo::GEO_ASSETS.iter().map(|asset| geo_json(asset, &geodata)).collect::<Vec<_>>(),
            }))
        );
        return ExitCode::SUCCESS;
    }
    let mut blocks: Vec<crate::layout::KvBlock> = Vec::with_capacity(statuses.len() + 1);
    for status in &statuses {
        let mut block = crate::layout::KvBlock::section(status.kernel.clone()).row(
            "configured",
            match (&status.configured_path, &status.configured_version) {
                (Some(path), Some(version)) => {
                    format!("{version} ({})", path.display())
                }
                (Some(path), None) => {
                    format!("unknown version ({})", path.display())
                }
                (None, _) => "(unset — daemon falls back to vendor/bin)".to_owned(),
            },
        );
        if let Some(path) = &status.env_override {
            block = block.row("env override", path.display().to_string());
        }
        if status.store.is_empty() {
            block = block.row("store", "(empty)");
        } else {
            for entry in &status.store {
                let marker = status.configured_path.as_ref().is_some_and(|current| {
                    same_file(current, &entry.path)
                });
                block = block.row(
                    "store",
                    format!(
                        "{}{} ({})",
                        entry.version,
                        if marker { " *" } else { "" },
                        entry.path.display()
                    ),
                );
            }
        }
        block = block.row(
            "latest",
            match (&status.latest, status.store_has_latest) {
                (Some(pinned), true) => format!("{pinned} (in store)"),
                (Some(pinned), false) => format!("{pinned} (run `caly core upgrade`)"),
                (None, _) => "(no pin recorded)".to_owned(),
            },
        );
        blocks.push(block);
    }
    let mut geo_block = crate::layout::KvBlock::section("geo");
    for asset in geo::GEO_ASSETS {
        geo_block = geo_block.row(
            asset.name,
            match geodata.iter().find(|file| file.name == asset.name) {
                Some(file) => format!(
                    "{} bytes (sha256:{}…)",
                    file.bytes,
                    file.sha256.get(..16).unwrap_or(&file.sha256)
                ),
                None => "(missing — run `caly core upgrade`)".to_owned(),
            },
        );
    }
    blocks.push(geo_block);
    crate::layout::print_blocks(&blocks);
    ExitCode::SUCCESS
}

fn geo_json(asset: &geo::GeoAsset, geodata: &[geo::GeoFile]) -> serde_json::Value {
    match geodata.iter().find(|file| file.name == asset.name) {
        Some(file) => serde_json::json!({
            "name": file.name,
            "present": true,
            "bytes": file.bytes,
            "sha256": file.sha256,
            "path": file.path.display().to_string(),
        }),
        None => serde_json::json!({
            "name": asset.name,
            "present": false,
        }),
    }
}

fn status_json(status: &KernelStatus) -> serde_json::Value {
    serde_json::json!({
        "kernel": status.kernel,
        "configured_path": status.configured_path.as_ref().map(|path| path.display().to_string()),
        "configured_version": status.configured_version,
        "env_override": status.env_override.as_ref().map(|path| path.display().to_string()),
        "store": status.store.iter().map(|entry| serde_json::json!({
            "version": entry.version,
            "path": entry.path.display().to_string(),
        })).collect::<Vec<_>>(),
        "latest": status.latest,
        "store_has_latest": status.store_has_latest,
    })
}

/// `core use <kernel>@<version>`: points the layered config's
/// `core_binaries` at a stored binary (after probing it). The daemon picks
/// the new binary up on restart.
pub fn use_version(
    paths: &caly_daemon::platform::paths::AppPaths,
    kernel: &str,
    version: &str,
    json: bool,
) -> ExitCode {
    let kernel = match normalize_kernel(kernel) {
        Ok(kernel) => kernel,
        Err(reason) => return super::client::output::report_usage_error(&reason, json),
    };
    let store = scan_store(&paths.data);
    let entry = match store
        .iter()
        .find(|entry| entry.kernel == kernel && entry.version == version)
    {
        Some(entry) => entry,
        None => {
            let available: Vec<&str> = store
                .iter()
                .filter(|entry| entry.kernel == kernel)
                .map(|entry| entry.version.as_str())
                .collect();
            let hint = if available.is_empty() {
                format!("install one first: `caly core install {kernel}`")
            } else {
                format!("installed: {}", available.join(", "))
            };
            return super::client::output::report_usage_error(
                &format!("{kernel} {version} is not installed. {hint}"),
                json,
            );
        }
    };
    let Some(probed) = probe_version(&entry.path).version else {
        return super::client::output::report_failure(
            &format!(
                "refusing to select {}: it reports no version (unrunnable?)",
                entry.path.display()
            ),
            json,
        );
    };
    if probed != version {
        return super::client::output::report_failure(
            &format!(
                "refusing to select {}: it reports {probed}, not {version}",
                entry.path.display()
            ),
            json,
        );
    }
    let profile = match crate::client::config_kv::active_profile() {
        Ok(profile) => profile,
        Err(reason) => {
            return super::client::output::report_failure(
                &format!("cannot resolve the active profile: {reason}"),
                json,
            );
        }
    };
    let key = if kernel == "sing-box" {
        "core_binaries.sing_box"
    } else {
        "core_binaries.mihomo"
    };
    let path_text = entry.path.display().to_string();
    match crate::client::config_kv::apply_scalar(paths, profile.as_ref(), key, &path_text, true) {
        Err(failure) => {
            let mut error = crate::layout::CliError::new(failure.code, failure.reason, "core use");
            if let Some(hint) = failure.hint {
                error = error.with_hint(hint);
            }
            crate::layout::report_error_returning(
                crate::layout::CliOutput::from_json_flag(json),
                error,
            )
        }
        Ok(_) => {
            if json {
                println!(
                    "{}",
                    crate::layout::CliOutput::success_envelope(serde_json::json!({
                        "command": "core use",
                        "kernel": kernel,
                        "version": version,
                        "path": path_text,
                    }))
                );
            } else {
                crate::layout::ok(&format!("now using {kernel} {version}"));
                crate::layout::hint("restart the daemon (`caly core restart`) to switch binaries");
            }
            ExitCode::SUCCESS
        }
    }
}

/// `core remove <kernel>@<version>`: deletes one installed version.
/// Refuses the currently configured binary unless `force` is set.
pub fn remove_kernel(
    paths: &caly_daemon::platform::paths::AppPaths,
    kernel: &str,
    version: &str,
    force: bool,
    json: bool,
) -> ExitCode {
    let normalized = match normalize_kernel(kernel) {
        Ok(kernel) => kernel,
        Err(reason) => return super::client::output::report_usage_error(&reason, json),
    };
    let candidate = store::kernels_dir(&paths.data)
        .join(normalized)
        .join(version);
    if !force && is_configured(paths, &candidate) {
        return super::client::output::report_usage_error(
            &format!(
                "{normalized} {version} is the configured binary; pass --force to remove it anyway"
            ),
            json,
        );
    }
    match store::remove_version(&paths.data, normalized, version) {
        Ok(removed) => {
            if json {
                println!(
                    "{}",
                    crate::layout::CliOutput::success_envelope(serde_json::json!({
                        "command": "core remove",
                        "kernel": normalized,
                        "version": version,
                        "removed": removed.display().to_string(),
                    }))
                );
            } else {
                crate::layout::ok(&format!("removed {normalized} {version}"));
            }
            ExitCode::SUCCESS
        }
        Err(reason) => super::client::output::report_usage_error(&reason, json),
    }
}

/// `core upgrade [kernel]`: installs the manifest pin for every kernel
/// (or one) whose store lacks it, then refreshes the mihomo geodata store
/// ([`geo`]) — the geo phase always runs, even for a single-kernel upgrade,
/// so one command leaves the box fully current. Already-current items are
/// skipped with a note; any failure fails the run (exit 1) after attempting
/// the rest.
pub fn upgrade_kernels(
    paths: &caly_daemon::platform::paths::AppPaths,
    kernel: Option<&str>,
    json: bool,
) -> ExitCode {
    let targets: Vec<&str> = match kernel {
        Some(name) => match normalize_kernel(name) {
            Ok(kernel) => vec![kernel],
            Err(reason) => return super::client::output::report_usage_error(&reason, json),
        },
        None => KERNELS.to_vec(),
    };
    let statuses = kernel_status(paths);
    let mut failed = false;
    for target in targets {
        let status = statuses.iter().find(|entry| entry.kernel == target);
        let pinned = status.and_then(|entry| entry.latest.clone());
        let Some(pinned) = pinned else {
            failed = true;
            if !json {
                crate::layout::error(&format!("{target}: no pinned release recorded; skipping"));
            }
            continue;
        };
        if status.is_some_and(|entry| entry.store_has_latest) {
            if !json {
                println!("{target}: already at {pinned}");
            }
            continue;
        }
        if !json {
            println!("{target}: installing {pinned}…");
        }
        match install_latest(&paths.data, target, false) {
            Ok(report) => {
                if json {
                    println!(
                        "{}",
                        crate::layout::CliOutput::success_envelope(serde_json::json!({
                            "command": "core upgrade",
                            "kernel": report.kernel,
                            "version": report.version,
                            "path": report.path.display().to_string(),
                        }))
                    );
                } else {
                    crate::layout::ok(&format!(
                        "{target} {pinned} installed ({})",
                        report.path.display()
                    ));
                }
            }
            Err(reason) => {
                failed = true;
                if json {
                    eprintln!(
                        "{}",
                        crate::layout::CliError::new(
                            crate::error::core::RUNTIME_FAILED,
                            format!("{target}: {reason}"),
                            "core upgrade"
                        )
                        .to_json()
                    );
                } else {
                    crate::layout::error(&format!("{target}: {reason}"));
                }
            }
        }
    }
    run_geo_upgrade(&paths.data, json, &mut failed);
    if failed {
        ExitCode::FAILURE
    } else {
        ExitCode::SUCCESS
    }
}

/// The `core upgrade` geo phase: same per-item reporting contract as the
/// kernel phase (notes for current items, `ok:` lines for updates, stderr
/// for failures, exit 1 if anything failed).
fn run_geo_upgrade(data_dir: &Path, json: bool, failed: &mut bool) {
    for outcome in geo::update_geo(data_dir) {
        match outcome {
            GeoOutcome::UpToDate { name } => {
                if !json {
                    println!("{name}: already current");
                }
            }
            GeoOutcome::Updated { name, bytes } => {
                if json {
                    println!(
                        "{}",
                        crate::layout::CliOutput::success_envelope(serde_json::json!({
                            "command": "core upgrade",
                            "geo": name,
                            "bytes": bytes,
                        }))
                    );
                } else {
                    crate::layout::ok(&format!("{name} updated ({bytes} bytes)"));
                }
            }
            GeoOutcome::Failed { name, reason } => {
                *failed = true;
                if json {
                    eprintln!(
                        "{}",
                        crate::layout::CliError::new(
                            crate::error::core::RUNTIME_FAILED,
                            format!("{name}: {reason}"),
                            "core upgrade"
                        )
                        .to_json()
                    );
                } else {
                    crate::layout::error(&format!("{name}: {reason}"));
                }
            }
        }
    }
}

/// `core install <kernel>[@<version>]`: manifest pin by default,
/// explicit version from the official URL template otherwise.
pub fn install_kernel(
    paths: &caly_daemon::platform::paths::AppPaths,
    kernel: &str,
    version: Option<&str>,
    force: bool,
    json: bool,
) -> ExitCode {
    let outcome = match version {
        Some(version) => install_version(&paths.data, kernel, version, force),
        None => install_latest(&paths.data, kernel, force),
    };
    match outcome {
        Ok(report) => {
            if json {
                println!(
                    "{}",
                    crate::layout::CliOutput::success_envelope(serde_json::json!({
                        "command": "core install",
                        "kernel": report.kernel,
                        "version": report.version,
                        "path": report.path.display().to_string(),
                        "verified": match report.verified {
                            VerifiedBy::ManifestHash => "manifest-hash",
                            VerifiedBy::SelfReport => "self-report",
                        },
                    }))
                );
            } else {
                crate::layout::ok(&format!(
                    "installed {} {} ({})",
                    report.kernel,
                    report.version,
                    report.path.display()
                ));
                if matches!(report.verified, VerifiedBy::SelfReport) {
                    crate::layout::note(
                        "no recorded hash for this version — verified by self-report only",
                    );
                }
                crate::layout::hint(&format!(
                    "select it with `caly core use {}@{}`",
                    report.kernel, report.version
                ));
            }
            ExitCode::SUCCESS
        }
        Err(reason) => {
            if reason.contains("already installed") || reason.contains("unknown kernel") {
                super::client::output::report_usage_error(&reason, json)
            } else {
                super::client::output::report_failure(&reason, json)
            }
        }
    }
}

fn is_configured(paths: &caly_daemon::platform::paths::AppPaths, version_dir: &PathBuf) -> bool {
    let configured = crate::config::load_from(paths.config.clone())
        .ok()
        .flatten()
        .map(|config| crate::config::core_binaries_from_config(Some(&config)));
    let Some(binaries) = configured else {
        return false;
    };
    [&binaries.mihomo, &binaries.sing_box]
        .into_iter()
        .flatten()
        .any(|current| {
            current == &version_dir.join("mihomo")
                || current == &version_dir.join("sing-box")
                || same_file(current, &version_dir.join("mihomo"))
                || same_file(current, &version_dir.join("sing-box"))
        })
}

fn same_file(a: &PathBuf, b: &PathBuf) -> bool {
    if a == b {
        return true;
    }
    match (std::fs::canonicalize(a), std::fs::canonicalize(b)) {
        (Ok(x), Ok(y)) => x == y,
        _ => false,
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn specs_parse() {
        assert_eq!(
            parse_kernel_spec("mihomo"),
            Ok(("mihomo".to_owned(), None))
        );
        assert_eq!(
            parse_kernel_spec("singbox@1.13.14"),
            Ok(("sing-box".to_owned(), Some("1.13.14".to_owned())))
        );
        assert!(parse_kernel_spec("xray").is_err());
        assert!(parse_kernel_spec("mihomo@").is_err());
        assert!(parse_kernel_spec("@1.2.3").is_err());
        assert_eq!(
            parse_pinned_spec("mihomo@1.19.29"),
            Ok(("mihomo".to_owned(), "1.19.29".to_owned()))
        );
        assert!(parse_pinned_spec("mihomo").is_err());
    }
}
