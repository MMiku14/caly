//! Layered `config.yaml` read/parse surface, shared by the CLI (offline
//! commands) and the daemon host boot path (P8a: moved up from
//! `bins/caly/src/daemon_config.rs`).
//!
//! Loads the XDG `AppConfig` (base `config.yaml`, optional active profile,
//! then `config.d/*.yaml` fragments) using the bounded layered loader, and
//! exposes per-field `*_from_config` parsers so the daemon boot resolves
//! everything from ONE load (single-snapshot invariant: the host's
//! `resolve_daemon` calls [`load_from`] once and derives every value).
//!
//! A present-but-invalid config fails boot so a broken bootstrap never
//! silently runs on stale env defaults; an absent `config.yaml` means "no
//! configuration" and the caller falls back to env, except that routing
//! keeps the built-in local/private default rule sets so a fresh daemon
//! already has safe DIRECT rules before any operator config exists.

use std::{fmt, path::{Path, PathBuf}};

use caly_core::domain::{Controllers, CoreKind};
use caly_daemon::platform::paths::CoreBinaryPaths;
use caly_daemon::platform::paths::{AppPaths, SafeName};
use caly_daemon::platform::tun::TunEscalation;
use caly_core::profile::{
    loader::{
        ConfigFileError, LayeredConfigPaths, LoaderLimits, load_config_file,
        load_layered_yaml_strict,
    },
    schema::{AppConfig, CoreConfig, KernelConfig, SnifferConfig, default_rule_lines},
};
use caly_core::subscription::FetchPolicy;

/// Layered configuration load/resolution failure.
#[derive(Debug)]
pub enum DaemonConfigError {
    /// The `CALY_PROFILE` value is not a safe profile name.
    InvalidProfile,
    /// The configured core is recognized but not yet supported by the daemon.
    UnsupportedCore,
    /// The layered loader rejected the configuration.
    Layered(caly_core::profile::loader::LayeredConfigError),
    /// The validated `daemon.listen` did not parse as a socket address.
    InvalidListenAddress,
    /// `daemon.listen` is non-loopback while the required transport
    /// protections are incomplete: enforced TLS (#57) and auth-token
    /// admission (#58) must both be configured for a remote endpoint;
    /// the daemon fails closed instead of serving one unauthenticated.
    RemoteListenUnavailable,
}

impl fmt::Display for DaemonConfigError {
    fn fmt(&self, formatter: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            Self::InvalidProfile => formatter.write_str("CALY_PROFILE must be a safe profile name"),
            Self::UnsupportedCore => formatter.write_str("configured core is not supported"),
            Self::InvalidListenAddress => {
                formatter.write_str("daemon.listen is not a valid socket address")
            }
            Self::RemoteListenUnavailable => formatter.write_str(
                "daemon.listen must be a loopback address: remote listening requires enforced \
                 TLS (cert + key) and a configured auth-token admission",
            ),
            Self::Layered(error) => write!(formatter, "layered configuration error: {error}"),
        }
    }
}

impl std::error::Error for DaemonConfigError {}

/// Loads the layered config from an explicit config root, returning `Ok(None)`
/// when no `config.yaml` exists (env-driven fallback).
pub fn load_from(root: PathBuf) -> Result<Option<AppConfig>, DaemonConfigError> {
    let base = root.join("config.yaml");
    if !base.is_file() {
        return Ok(None);
    }
    // W2/D10 (cli-v3-design.md §10): CALY_PROFILE stays an
    // explicit override; absent it, the `caly profile use` context
    // becomes the fallback selector, so the context takes effect
    // on the next daemon start ("daemon 重启后有效").
    let active_profile = match std::env::var("CALY_PROFILE") {
        Ok(value) => Some(SafeName::new(value).map_err(|_| DaemonConfigError::InvalidProfile)?),
        Err(_) => crate::client::context::active_profile(),
    };
    let paths = LayeredConfigPaths::new(root, active_profile);
    // Strict production resolution: declared `profiles:` bodies come from the
    // on-disk ProfileStore cache, so a config the CLI previewed boots
    // identically here.
    load_layered_yaml_strict(
        &paths,
        LoaderLimits::secure_default(),
        &AppPaths::from_env().state,
    )
    .map(Some)
    .map_err(DaemonConfigError::Layered)
}

/// Resolves the managed core from an explicit config root. Returns `None` when
/// no config exists (env drives selection). Precedence between configuration
/// and the `CALY_CORE` environment variable is applied by the application
/// composition, which keeps a single source of truth.
#[cfg(test)]
pub fn core_override_from(root: PathBuf) -> Result<Option<CoreKind>, DaemonConfigError> {
    core_override_from_config(load_from(root)?.as_ref())
}

pub fn core_override_from_config(
    config: Option<&AppConfig>,
) -> Result<Option<CoreKind>, DaemonConfigError> {
    let Some(config) = config else {
        return Ok(None);
    };
    match config.core {
        CoreConfig::Mihomo => Ok(Some(CoreKind::Mihomo)),
        CoreConfig::SingBox => Ok(Some(CoreKind::SingBox)),
        CoreConfig::Xray => Err(DaemonConfigError::UnsupportedCore),
    }
}

/// Parses the effective routing rules. An absent `config.yaml` falls back
/// to the geo-only defaults so a fresh, unconfigured daemon still keeps
/// private addresses and mainland-China traffic DIRECT; an explicitly
/// configured (even empty) `rules:` list is authoritative.
pub fn routing_rules() -> Vec<caly_core::domain::RoutingRule> {
    routing_rules_from_config(
        load_from(AppPaths::from_env().config)
            .ok()
            .flatten()
            .as_ref(),
    )
}

pub fn routing_rules_from_config(config: Option<&AppConfig>) -> Vec<caly_core::domain::RoutingRule> {
    let rules = match config {
        Some(config) => config.rules.clone(),
        None => default_rule_lines(),
    };
    rules
        .iter()
        .filter_map(|line| caly_core::domain::RoutingRule::from_clash_line(line).ok())
        // A `RULE-SET` rule whose provider is disabled is skipped together
        // with the provider. Schema validation accepts the reference (the
        // declaration still exists for re-enable), but rendering the rule
        // without its provider would make Mihomo/sing-box fail at startup.
        .filter(|rule| match &rule.matcher {
            caly_core::domain::RuleMatch::RuleSet(name)
                if !rule_provider_is_enabled(config, name.as_str()) =>
            {
                tracing::warn!(
                    provider = name.as_str(),
                    "RULE-SET rule skipped because its provider is disabled"
                );
                false
            }
            _ => true,
        })
        .collect()
}

/// Whether the named rule provider is enabled in the effective config. An
/// absent config declares no providers (the geo-only default rules need
/// none), so every name resolves to disabled.
fn rule_provider_is_enabled(config: Option<&AppConfig>, name: &str) -> bool {
    match config {
        Some(config) => config
            .rule_providers
            .iter()
            .any(|provider| provider.name == name && provider.enabled),
        None => false,
    }
}

/// Resolves the effective rule providers from a layered config. When no
/// `config.yaml` exists, the built-in default rule sets are used so the
/// default routing rules have their providers; when a config exists, its
/// `rule_providers:` list (even empty) is authoritative.
/// Each entry was already validated by `validate_rule_providers` in the
/// schema layer; the loader only translates the deserialized
/// `RuleProviderConfig` into the domain [`caly_core::domain::RuleProvider`]
/// for the runtime tuning bundle.
pub fn rule_providers_from_config(config: Option<&AppConfig>) -> Vec<caly_core::domain::RuleProvider> {
    let providers = match config {
        Some(config) => config.rule_providers.clone(),
        None => Vec::new(),
    };
    let mut out = Vec::with_capacity(providers.len());
    for provider in &providers {
        // `enabled: false` keeps the declaration visible for `caly
        // rule-provider enable`, but the daemon skips the provider at boot.
        if !provider.enabled {
            continue;
        }
        match provider.to_rule_provider() {
            Ok(domain) => out.push(domain),
            // Validation runs at parse time; reaching this branch means
            // the layered config is inconsistent with the runtime
            // domain bounds, which is a daemon-internal contract failure.
            // Skip the entry rather than abort boot — the broken provider
            // stays absent from the rendered kernel config and the
            // operator sees the skipped count through existing
            // diagnostics.
            Err(error) => {
                tracing::warn!(
                    provider = provider.name.as_str(),
                    error = %error,
                    "rule provider dropped at boot; check the config"
                );
            }
        }
    }
    out
}

/// Client-side mirror of [`auth_token_from_config`]: reads the
/// layered config and returns the token a handshake must
/// present. A config that fails to load degrades to `None`
/// (the resulting handshake will fail admission against a
/// token-enforcing daemon instead of crashing the client).
pub fn auth_token() -> Option<String> {
    let root = caly_daemon::platform::paths::AppPaths::from_env().config;
    auth_token_from_config(load_from(root).ok().flatten().as_ref())
}

/// Resolves `daemon.auth_token` (the handshake admission token)
/// from the layered config, redacting nothing structurally:
/// `SecretText` is revealed exactly once at boot and handed to
/// the service adapter; it is never logged.
pub fn auth_token_from_config(config: Option<&AppConfig>) -> Option<String> {
    config
        .and_then(|config| {
            // `with_exposed` scopes the plaintext to this trim/clone;
            // the value is never logged and the config's `SecretText`
            // wrapper stays redacted in every Debug/Display path.
            config
                .daemon
                .auth_token
                .as_ref()
                .map(|token| token.with_exposed(|exposed| exposed.trim().to_owned()))
        })
        .filter(|token| !token.is_empty())
}

/// Resolves core executable paths from an explicit config root.
pub fn core_binaries_from(root: PathBuf) -> Result<CoreBinaryPaths, DaemonConfigError> {
    Ok(core_binaries_from_config(load_from(root)?.as_ref()))
}

pub fn core_binaries_from_config(config: Option<&AppConfig>) -> CoreBinaryPaths {
    config.map_or_else(CoreBinaryPaths::default, |value| CoreBinaryPaths {
        mihomo: value.core_binaries.mihomo.clone(),
        sing_box: value.core_binaries.sing_box.clone(),
    })
}

/// Resolves the controller endpoints from the config file (falling back to the
/// environment and then built-in defaults).
pub fn controllers() -> Result<caly_core::domain::Controllers, DaemonConfigError> {
    controllers_from(AppPaths::from_env().config)
}

/// Resolves the controller endpoints from an explicit config root.
pub fn controllers_from(root: PathBuf) -> Result<Controllers, DaemonConfigError> {
    Ok(controllers_from_config(load_from(root)?.as_ref()))
}

pub fn controllers_from_config(config: Option<&AppConfig>) -> Controllers {
    let defaults = Controllers::defaults();
    let mihomo = std::env::var("CALY_MIHOMO_CONTROLLER").unwrap_or_else(|_| {
        config.map_or(defaults.mihomo.clone(), |c| c.controllers.mihomo.clone())
    });
    let sing_box = std::env::var("CALY_SINGBOX_CONTROLLER").unwrap_or_else(|_| {
        config.map_or(defaults.sing_box.clone(), |c| {
            c.controllers.sing_box.clone()
        })
    });
    Controllers { mihomo, sing_box }
}

/// Resolves kernel tuning from an explicit config root.
#[cfg(test)]
pub fn kernel_from(root: PathBuf) -> caly_core::profile::schema::KernelConfig {
    kernel_from_config(load_from(root).ok().flatten().as_ref())
}

pub fn kernel_from_config(config: Option<&AppConfig>) -> KernelConfig {
    let mut kernel = config
        .as_ref()
        .map_or_else(KernelConfig::default, |config| config.kernel.clone());
    // e2e isolation / operator override: `CALY_MIXED_PORT` env wins over
    // the config value, mirroring the controller env overrides — lets test
    // suites bind an ephemeral mixed port instead of racing for the fixed
    // 7890 (see daemon_mock_e2e). Invalid values are ignored (config wins).
    if let Ok(port) = std::env::var("CALY_MIXED_PORT") {
        kernel.mixed_port = port.parse().unwrap_or(kernel.mixed_port);
    }
    kernel
}

pub fn sniffer_from_config(config: Option<&AppConfig>) -> SnifferConfig {
    config
        .as_ref()
        .map_or_else(SnifferConfig::default, |config| config.sniffer.clone())
}

/// Resolves the configured nameserver references for diagnostics. Unlike
/// `dns_settings`, this does not require `dns.enabled` and never consults the
/// environment: it exists so `caly dns` can probe user-listed resolvers.
pub fn dns_nameservers() -> Vec<String> {
    load_from(AppPaths::from_env().config)
        .ok()
        .flatten()
        .map(|config| config.dns.nameservers)
        .unwrap_or_default()
}

/// Resolves the fetch policy from an explicit config root.
#[cfg(test)]
pub fn fetch_policy_from(root: PathBuf) -> caly_core::subscription::FetchPolicy {
    fetch_policy_from_config(load_from(root).ok().flatten().as_ref())
}

pub fn fetch_policy_from_config(config: Option<&AppConfig>) -> FetchPolicy {
    let Some(config) = config else {
        return FetchPolicy::direct_default();
    };
    let subscriptions = &config.subscriptions;
    FetchPolicy {
        connect_timeout: std::time::Duration::from_millis(subscriptions.connect_timeout_ms),
        request_timeout: std::time::Duration::from_millis(subscriptions.request_timeout_ms),
        // Mebibytes → bytes with a saturating fallback: the schema
        // caps `max_body_mb` at 256, but a 32-bit `usize` build
        // would have silently wrapped the multiply and the old
        // `try_from(..).unwrap_or(32)` conflated "huge" with
        // "negative" into the same fallback (#56).
        max_body_bytes: usize::try_from(subscriptions.max_body_mb)
            .ok()
            .and_then(|megabytes: usize| megabytes.checked_mul(1024 * 1024))
            .unwrap_or(32 * 1024 * 1024),
        redirects_allowed: subscriptions.follow_redirects,
        use_environment_proxy: subscriptions.use_environment_proxy,
    }
}

/// Resolves the system-proxy endpoint from an explicit config root.
#[cfg(test)]
pub fn system_proxy_endpoint_from(root: PathBuf) -> (String, u16) {
    system_proxy_endpoint_from_config(load_from(root).ok().flatten().as_ref())
}

/// Resolves the effective system-proxy endpoint, honouring the same
/// precedence the daemon boot uses: `CALY_SYSTEM_PROXY_HOST`/
/// `CALY_SYSTEM_PROXY_PORT` env overrides, then `config.yaml`, then
/// `127.0.0.1` / `kernel.mixed_port` (default 7890). Shared by the
/// daemon boot path and `sysproxy status` so both agree on the endpoint.
pub fn system_proxy_endpoint_from_config(config: Option<&AppConfig>) -> (String, u16) {
    let default_port = config
        .as_ref()
        .map_or(7890, |value| value.kernel.mixed_port);
    let host = std::env::var("CALY_SYSTEM_PROXY_HOST").unwrap_or_else(|_| {
        config.as_ref().map_or_else(
            || "127.0.0.1".to_owned(),
            |value| value.system_proxy.host.clone(),
        )
    });
    let port = std::env::var("CALY_SYSTEM_PROXY_PORT")
        .ok()
        .and_then(|value| value.parse().ok())
        .or_else(|| config.as_ref().and_then(|value| value.system_proxy.port))
        .unwrap_or(default_port);
    (host, port)
}

/// Resolves the TUN escalation policy from an explicit config root.
#[cfg(test)]
pub fn tun_escalation_from(root: PathBuf) -> caly_daemon::platform::tun::TunEscalation {
    tun_escalation_from_config(load_from(root).ok().flatten().as_ref())
}

pub fn tun_escalation_from_config(config: Option<&AppConfig>) -> TunEscalation {
    let Some(config) = config else {
        return TunEscalation::default();
    };
    match config.tun.escalation.as_str() {
        "pkexec" => TunEscalation::Pkexec,
        "sudo" => TunEscalation::Sudo,
        "none" => TunEscalation::None,
        _ => TunEscalation::Auto,
    }
}

/// Resolves the configured log level (defaults to `info`).
pub fn log_level() -> String {
    let default = "info".to_owned();
    let Some(config) = load_from(AppPaths::from_env().config).ok().flatten() else {
        return default;
    };
    config.log.level
}

/// Resolves the configured telemetry sampling interval in milliseconds
/// (defaults to 2000; 刀 6 CPU audit — the previous 1s default made the
/// telemetry actor do two HTTP round-trips per second and kept it busy
/// ~2s per sample under sing-box).
pub fn telemetry_interval_ms() -> u64 {
    let Some(config) = load_from(AppPaths::from_env().config).ok().flatten() else {
        return 2_000;
    };
    config.telemetry.interval_ms
}

/// Validates that `path` parses as a config file (existence + YAML shape).
pub fn check_config_file(path: &Path) -> Result<(), ConfigFileError> {
    load_config_file(path).map(|_| ())
}

#[cfg(test)]
mod config_tests {
//! Unit tests for the layered config read/parse surface (P8a: moved up
//! from the daemon host so offline CLI commands share one loader).

use super::*;
use std::{
    fs,
    time::{SystemTime, UNIX_EPOCH},
};

fn temp_root(tag: &str) -> PathBuf {
    let nanos = SystemTime::now()
        .duration_since(UNIX_EPOCH)
        .map_or_else(|_| 0, |duration| duration.as_nanos());
    let dir = std::env::temp_dir().join(format!("caly-config-{tag}-{nanos}"));
    fs::create_dir_all(&dir).unwrap_or_default();
    dir
}

#[test]
fn absent_config_yields_no_override() -> Result<(), String> {
    let root = temp_root("absent");
    assert_eq!(
        core_override_from(root.clone()).map_err(|e| format!("{e:?}"))?,
        None
    );
    fs::remove_dir_all(&root).ok();
    Ok(())
}

#[test]
fn config_core_selects_mihomo() -> Result<(), String> {
    let root = temp_root("mihomo");
    fs::write(
        root.join("config.yaml"),
        "schema_version: 1\ncore: mihomo\n",
    )
    .map_err(|e| e.to_string())?;
    assert_eq!(
        core_override_from(root.clone()).map_err(|e| format!("{e:?}"))?,
        Some(CoreKind::Mihomo)
    );
    fs::remove_dir_all(&root).ok();
    Ok(())
}

#[test]
fn config_core_selects_sing_box() -> Result<(), String> {
    let root = temp_root("sing");
    fs::write(
        root.join("config.yaml"),
        "schema_version: 1\ncore: sing-box\n",
    )
    .map_err(|e| e.to_string())?;
    assert_eq!(
        core_override_from(root.clone()).map_err(|e| format!("{e:?}"))?,
        Some(CoreKind::SingBox)
    );
    fs::remove_dir_all(&root).ok();
    Ok(())
}

#[test]
fn config_xray_is_rejected_as_unsupported() {
    let root = temp_root("xray");
    fs::write(root.join("config.yaml"), "schema_version: 1\ncore: xray\n").unwrap_or_default();
    assert!(matches!(
        core_override_from(root.clone()),
        Err(DaemonConfigError::UnsupportedCore)
    ));
    fs::remove_dir_all(&root).ok();
}

#[test]
fn invalid_config_fails_boot() {
    let root = temp_root("bad");
    fs::write(
        root.join("config.yaml"),
        "schema_version: 1\ncore: [not-a-scalar\n",
    )
    .unwrap_or_default();
    assert!(matches!(
        core_override_from(root.clone()),
        Err(DaemonConfigError::Layered(_))
    ));
    fs::remove_dir_all(&root).ok();
}

#[test]
fn controllers_from_config_falls_back_to_defaults() -> Result<(), String> {
    let root = temp_root("controllers");
    // Absent config -> built-in defaults.
    let absent = controllers_from(root.clone()).map_err(|e| format!("{e:?}"))?;
    assert_eq!(absent.mihomo, "127.0.0.1:9090");
    assert_eq!(absent.sing_box, "127.0.0.1:9091");
    // Present config -> configured addresses.
    fs::write(
            root.join("config.yaml"),
            "schema_version: 1\ncore: mihomo\ncontrollers:\n  mihomo: 127.0.0.1:9200\n  sing_box: 127.0.0.1:9201\n",
        )
        .map_err(|e| e.to_string())?;
    let configured = controllers_from(root.clone()).map_err(|e| format!("{e:?}"))?;
    assert_eq!(configured.mihomo, "127.0.0.1:9200");
    assert_eq!(configured.sing_box, "127.0.0.1:9201");
    fs::remove_dir_all(&root).ok();
    Ok(())
}

#[test]
fn kernel_defaults_apply_without_config() {
    let root = temp_root("kernel-absent");
    let kernel = kernel_from(root.clone());
    assert_eq!(kernel.mixed_port, 7890);
    assert!(!kernel.allow_lan);
    assert_eq!(kernel.log_level, "error");
    fs::remove_dir_all(&root).ok();
}

#[test]
fn kernel_values_load_from_config() {
    let root = temp_root("kernel-config");
    fs::write(
        root.join("config.yaml"),
        "schema_version: 1\ncore: mihomo\nkernel:\n  mixed_port: 8899\n  allow_lan: true\n  log_level: warn\n",
    )
    .unwrap_or_default();
    let kernel = kernel_from(root.clone());
    assert_eq!(kernel.mixed_port, 8899);
    assert!(kernel.allow_lan);
    assert_eq!(kernel.log_level, "warn");
    fs::remove_dir_all(&root).ok();
}

#[test]
fn kernel_restart_bounds_load_from_config() {
    let root = temp_root("restart-bounds");
    fs::write(
        root.join("config.yaml"),
        "schema_version: 1\ncore: mihomo\nkernel:\n  restart:\n    initial_backoff_ms: 250\n    max_backoff_ms: 4000\n",
    )
    .unwrap_or_default();
    let kernel = kernel_from(root.clone());
    assert_eq!(kernel.restart.initial_backoff_ms, 250);
    assert_eq!(kernel.restart.max_backoff_ms, 4000);
    fs::remove_dir_all(&root).ok();
}

#[test]
fn fetch_policy_defaults_and_overrides() {
    let root = temp_root("fetch-absent");
    let policy = fetch_policy_from(root.clone());
    assert_eq!(policy.connect_timeout.as_millis(), 5000);
    assert_eq!(policy.max_body_bytes, 32 * 1024 * 1024);
    assert!(!policy.redirects_allowed);
    fs::remove_dir_all(&root).ok();

    let root = temp_root("fetch-config");
    fs::write(
        root.join("config.yaml"),
        "schema_version: 1\ncore: mihomo\nsubscriptions:\n  connect_timeout_ms: 900\n  request_timeout_ms: 2000\n  max_body_mb: 4\n  follow_redirects: true\n",
    )
    .unwrap_or_default();
    let policy = fetch_policy_from(root.clone());
    assert_eq!(policy.connect_timeout.as_millis(), 900);
    assert_eq!(policy.request_timeout.as_millis(), 2000);
    assert_eq!(policy.max_body_bytes, 4 * 1024 * 1024);
    assert!(policy.redirects_allowed);
    fs::remove_dir_all(&root).ok();
}

#[test]
fn system_proxy_endpoint_defaults_to_mixed_port() {
    let root = temp_root("proxy-endpoint-default");
    let (host, port) = system_proxy_endpoint_from(root.clone());
    assert_eq!(host, "127.0.0.1");
    assert_eq!(port, 7890);
    fs::remove_dir_all(&root).ok();

    let root = temp_root("proxy-endpoint-config");
    fs::write(
        root.join("config.yaml"),
        "schema_version: 1\ncore: mihomo\nkernel:\n  mixed_port: 8899\nsystem_proxy:\n  enabled: false\n  host: 10.0.0.2\n",
    )
    .unwrap_or_default();
    let (host, port) = system_proxy_endpoint_from(root.clone());
    assert_eq!(host, "10.0.0.2");
    assert_eq!(port, 8899);
    fs::remove_dir_all(&root).ok();

    let root = temp_root("proxy-endpoint-port");
    fs::write(
        root.join("config.yaml"),
        "schema_version: 1\ncore: mihomo\nsystem_proxy:\n  enabled: false\n  host: 127.0.0.1\n  port: 1080\n",
    )
    .unwrap_or_default();
    let (host, port) = system_proxy_endpoint_from(root.clone());
    assert_eq!(host, "127.0.0.1");
    assert_eq!(port, 1080);
    fs::remove_dir_all(&root).ok();
}

#[test]
fn dns_nameservers_lists_configured_resolvers() {
    let root = temp_root("dns-nameservers");
    fs::write(
        root.join("config.yaml"),
        "schema_version: 1\ncore: mihomo\ndns:\n  enabled: false\n  nameservers:\n    - 9.9.9.9\n",
    )
    .unwrap_or_default();
    // dns_nameservers reads the raw config section even when disabled.
    let config = load_from(root.clone())
        .ok()
        .flatten()
        .unwrap_or_else(|| panic!("config must load"));
    assert_eq!(config.dns.nameservers, vec!["9.9.9.9"]);
    fs::remove_dir_all(&root).ok();
}

#[test]
fn tun_escalation_maps_config_values() {
    use caly_daemon::platform::tun::TunEscalation;
    let root = temp_root("escalation-absent");
    assert_eq!(tun_escalation_from(root.clone()), TunEscalation::Auto);
    fs::remove_dir_all(&root).ok();

    for (value, expected) in [
        ("sudo", TunEscalation::Sudo),
        ("pkexec", TunEscalation::Pkexec),
        ("none", TunEscalation::None),
        ("auto", TunEscalation::Auto),
    ] {
        let root = temp_root(&format!("escalation-{value}"));
        fs::write(
            root.join("config.yaml"),
            format!(
                "schema_version: 1\ncore: mihomo\ntun:\n  enabled: false\n  escalation: {value}\n"
            ),
        )
        .unwrap_or_default();
        assert_eq!(
            tun_escalation_from(root.clone()),
            expected,
            "escalation `{value}` must map correctly"
        );
        fs::remove_dir_all(&root).ok();
    }
}

#[test]
fn absent_config_uses_geo_only_default_rules_without_providers() {
    // A daemon boot with no config.yaml still gets the geo-only
    // default rules; they are kernel-native and need no providers.
    let root = temp_root("rules-absent");
    let rules = routing_rules_from_config(None);
    assert_eq!(rules.len(), 3);
    assert!(matches!(
        rules[0].matcher,
        caly_core::domain::RuleMatch::Geoip(_)
    ));
    assert!(matches!(
        rules[1].matcher,
        caly_core::domain::RuleMatch::Geosite(_)
    ));
    assert!(matches!(
        rules[2].matcher,
        caly_core::domain::RuleMatch::Geoip(_)
    ));

    assert!(rule_providers_from_config(None).is_empty());
    fs::remove_dir_all(&root).ok();
}

#[test]
fn explicit_empty_rules_and_providers_stay_empty() {
    let root = temp_root("rules-empty");
    fs::write(
        root.join("config.yaml"),
        "schema_version: 1\ncore: mihomo\nrules: []\nrule_providers: []\n",
    )
    .unwrap_or_default();
    let config = load_from(root.clone())
        .ok()
        .flatten()
        .unwrap_or_else(|| panic!("config must load"));
    assert!(routing_rules_from_config(Some(&config)).is_empty());
    assert!(rule_providers_from_config(Some(&config)).is_empty());
    fs::remove_dir_all(&root).ok();
}

#[test]
fn generated_config_resolves_default_rule_sets() {
    use caly_core::profile::schema::default_rule_lines;
    let root = temp_root("rules-generated");
    crate::client::config_generate::generate_config_at(root.clone(), false);
    let config = load_from(root.clone())
        .ok()
        .flatten()
        .unwrap_or_else(|| panic!("generated config must load"));

    let parsed = routing_rules_from_config(Some(&config));
    let expected = default_rule_lines();
    assert_eq!(parsed.len(), expected.len());
    for (rule, line) in parsed.iter().zip(expected.iter()) {
        assert_eq!(
            rule.to_clash_line(),
            line.as_str(),
            "generated rules must resolve exactly the documented defaults"
        );
    }

    let providers = rule_providers_from_config(Some(&config));
    assert!(
        providers.is_empty(),
        "generated config ships no providers: geo-only defaults are kernel-native"
    );
    fs::remove_dir_all(&root).ok();
}

#[test]
fn disabled_rule_provider_is_skipped_with_its_rules() {
    let root = temp_root("rules-disabled");
    fs::write(
        root.join("config.yaml"),
        "schema_version: 1\ncore: mihomo\n\
         rule_providers:\n\
         \x20 - name: local-rules\n\
         \x20   type: inline\n\
         \x20   behavior: domain\n\
         \x20   payload: example.com\n\
         \x20   enabled: false\n\
         rules:\n\
         \x20 - RULE-SET,local-rules,DIRECT\n\
         \x20 - MATCH,PROXY\n",
    )
    .unwrap_or_default();
    let config = load_from(root.clone())
        .ok()
        .flatten()
        .unwrap_or_else(|| panic!("config must load"));

    // The declaration stays in the schema but never reaches the runtime
    // tuning bundle, and its referencing rule is dropped as well so the
    // rendered kernel does not reference a missing rule-set.
    assert!(rule_providers_from_config(Some(&config)).is_empty());
    let rules = routing_rules_from_config(Some(&config));
    assert_eq!(rules.len(), 1);
    assert!(matches!(rules[0].matcher, caly_core::domain::RuleMatch::Match));
    fs::remove_dir_all(&root).ok();
}

}
