//! Terminal detection: TTY, width and color policy.
//!
//! Single source of truth so tables, badges and latency colors can
//! never disagree about whether stdout is a terminal.

use std::io::IsTerminal;

/// Whether stdout is a real terminal. Piped output stays plain and
/// script-friendly; only a TTY gets aligned tables and paint.
pub fn stdout_is_tty() -> bool {
    std::io::stdout().is_terminal()
}

/// Usable terminal width on a real terminal (piped output keeps full
/// widths). An explicit `$COLUMNS` wins as an operator override; otherwise
/// the width is queried from the terminal itself — `$COLUMNS`-only used to
/// leave every table untruncated on terminals that do not export it
/// (bug ①). Values under 20 columns are ignored (a degenerate width
/// must not collapse every column to its floor).
pub fn term_width() -> Option<usize> {
    if !stdout_is_tty() {
        return None;
    }
    if let Some(cols) = columns_override() {
        return Some(cols);
    }
    ioctl_columns().map(|cols| cols.max(20))
}

/// Queries the terminal width via `TIOCGWINSZ` (columns only — rows
/// are irrelevant to line width, and degenerate pseudo-terminals may
/// report zero rows while carrying a valid width).
#[cfg(unix)]
fn ioctl_columns() -> Option<usize> {
    let winsize = rustix::termios::tcgetwinsize(std::io::stdout()).ok()?;
    Some(usize::from(winsize.ws_col)).filter(|cols| *cols > 0)
}

/// Non-Unix builds have no `TIOCGWINSZ`: `$COLUMNS` is the only source.
#[cfg(not(unix))]
fn ioctl_columns() -> Option<usize> {
    None
}

/// Explicit `$COLUMNS` override (valid values only).
fn columns_override() -> Option<usize> {
    std::env::var("COLUMNS")
        .ok()
        .and_then(|value| value.trim().parse::<usize>().ok())
        .filter(|cols| *cols >= 20)
}

/// Whether ANSI color may be emitted: a real terminal, no non-empty
/// `NO_COLOR` in the environment (https://no-color.org), and not a
/// `dumb` terminal.
/// Whether ANSI color may be emitted.
///
/// Implements standard command line color policy:
/// 1. `NO_COLOR` (https://no-color.org): if set and non-empty, NO color under any circumstances.
/// 2. `CLICOLOR_FORCE != "0"`: forces color on even if stdout is redirected / piped.
/// 3. Standard TTY check: requires stdout to be a real terminal.
/// 4. `CLICOLOR == "0"`: explicit disable on interactive TTY.
/// 5. `TERM == "dumb"`: disabled.
pub fn colors_enabled() -> bool {
    // 1. NO_COLOR takes absolute precedence per https://no-color.org
    if std::env::var_os("NO_COLOR").is_some_and(|value| !value.is_empty()) {
        return false;
    }
    // 2. CLICOLOR_FORCE != "0" overrides TTY detection
    if let Ok(force) = std::env::var("CLICOLOR_FORCE") {
        if force != "0" {
            return true;
        }
    }
    // 3. TTY check for standard interactive sessions
    if !stdout_is_tty() {
        return false;
    }
    // 4. CLICOLOR == "0" disables color on interactive TTY
    if let Ok(clicolor) = std::env::var("CLICOLOR") {
        if clicolor == "0" {
            return false;
        }
    }
    // 5. TERM == "dumb" disables color
    if std::env::var("TERM").is_ok_and(|term| term == "dumb") {
        return false;
    }
    true
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn no_tty_no_width_no_color() {
        // Under `cargo test` stdout is captured (not a TTY): both
        // gates must agree on "plain".
        assert!(!stdout_is_tty());
        assert_eq!(term_width(), None);
        assert!(!colors_enabled());
    }

    #[test]
    fn color_policy_gates_off_terminal_by_default() {
        // Under test runner, stdout is not a TTY and no force flags are set
        if std::env::var_os("CLICOLOR_FORCE").is_none() {
            assert!(!colors_enabled());
        }
    }

}
