//! CLI 排版套件: every human-readable line caly prints.
//!
//! One crate owns the whole terminal face so `sub list`, `node list`,
//! `status`, `core versions` and friends can never drift apart again:
//!
//! - [`table`]: the adaptive Table/TSV list engine (`sub list` is the
//!   reference look — space-aligned columns on a TTY, verbatim TSV
//!   when piped, `--format` pins either).
//! - [`kv`]: titled fact blocks (`status`, `core versions`, `flow trace`
//!   …): `title:` + colon-aligned `  key:  value` rows, blank line
//!   between blocks.
//! - [`tree`]: branch-glyph trees (`node list --format=tree`).
//! - [`lines`]: the one-line vocabulary — `ok:` / `hint:` / `note:` /
//!   `error:` — with fixed stdout/stderr routing.
//! - [`theme`]: the palette, status badges (●○⚠) and latency bands.
//! - [`term`]: TTY/width/color detection (`$COLUMNS`, `NO_COLOR`).
//! - [`text`]: width math (CJK-aware, ANSI-transparent), truncation
//!   and hostile-input sanitizers.
//! - [`time`]: human relative times (`2h ago`).
//! - [`envelope`]: the stable JSON contract (`{ok, version, …}`) and
//!   the typed error renderer.
//!
//! # Contracts the suite guarantees
//!
//! - JSON and TSV bytes are script contracts: stable, verbatim, never
//!   painted. Human Table/KV/tree faces may be re-aligned by the
//!   suite without a contract bump.
//! - Errors always go to stderr; stdout carries successful data only.
//! - Paint happens on a real terminal only, and never under `NO_COLOR`
//!   or `TERM=dumb`. An explicit `--format=table` into a pipe stays
//!   clean bytes.
//! - Every renderer sanitizes untrusted text at its own entry (table
//!   cells, KV values, tree labels): callers never pre-clean.
//!
//! Renderers return lines (`render_*`) separately from printing them
//! (`print_*`) so tests assert layout without capturing stdout.

#![forbid(unsafe_code)]

pub mod envelope;
pub mod kv;
pub mod lines;
pub mod size;
pub mod table;
pub mod term;
pub mod text;
pub mod theme;
pub mod time;
pub mod tree;

// The daily-use surface, re-exported flat so call sites read
// `crate::layout::print_table` instead of `crate::layout::table::print_table`.
pub use envelope::{
    CANCELLED_NOTHING_CHANGED, CliError, CliOutput, ErrorHint, JSON_CONTRACT_VERSION,
    print_ok_envelope, report_error, report_error_returning,
};
pub use kv::{KvBlock, print_blocks, render_blocks};
pub use lines::{blank, empty, error, hint, note, note_err, ok, warning};
pub use size::human_bytes;
pub use table::{OutputFormat, TableMode, print_table, render_table, table_mode};
pub use text::{
    char_width, pad_end_visible, sanitize_cell, strip_controls, truncate_visible, visible_width,
};
pub use theme::{Style, latency, paint, source_badge, source_word, status_badge};
pub use time::{now_unix, relative_time};
pub use tree::{TreeRow, badge_lane, render_tree};

#[cfg(test)]
mod render_tests;
