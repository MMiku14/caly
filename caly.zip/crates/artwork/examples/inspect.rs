//! Diagnostic: prints artwork info for a file.
fn main() {
    let mut args = std::env::args().skip(1);
    let Some(path) = args.next() else {
        eprintln!("usage: inspect <media-or-image-path>");
        std::process::exit(2);
    };
    let cache = std::env::temp_dir().join("caly-art-example-cache");
    match caly_artwork::load(&path, &cache) {
        Some(art) => println!(
            "ok: {}x{} ({} bytes RGBA)",
            art.width,
            art.height,
            art.rgba.len()
        ),
        None => println!("no artwork"),
    }
}
