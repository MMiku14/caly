//! Album artwork for the TUI.
#![warn(missing_docs, rust_2018_idioms)]

mod decode;
use decode::{first_frame_rgba, MAX_DIM};
use std::path::{Path, PathBuf};

/// A decoded RGBA image.
#[derive(Debug, Clone)]
pub struct Artwork {
    /// Pixel width.
    pub width: u32,
    /// Pixel height.
    pub height: u32,
    /// RGBA bytes.
    pub rgba: Vec<u8>,
}

const SIDECAR_NAMES: [&str; 6] = ["cover", "folder", "front", "album", "albumart", "artwork"];
const SIDECAR_EXTS: [&str; 5] = ["jpg", "jpeg", "png", "webp", "avif"];

/// Best-effort artwork for a track.
pub fn load(uri: &str, cache_dir: &Path) -> Option<Artwork> {
    let path = Path::new(uri);
    if !path.is_absolute() || !path.is_file() {
        return None;
    }
    let source = sidecar(path).unwrap_or_else(|| path.to_path_buf());
    let cache_path = cache_path(cache_dir, uri);
    if let Some(art) = read_cache(&cache_path, &source) {
        return Some(art);
    }
    let art = first_frame_rgba(&source).map(|img| Artwork {
        width: img.width,
        height: img.height,
        rgba: img.rgba,
    });
    if let Some(art) = &art {
        write_cache(&cache_path, &source, art);
    }
    art
}

fn sidecar(media: &Path) -> Option<PathBuf> {
    let dir = media.parent()?;
    let track_stem = media
        .file_stem()
        .and_then(|s| s.to_str())
        .map(str::to_lowercase);
    let entries = std::fs::read_dir(dir).ok()?;
    let mut found: Option<(PathBuf, usize)> = None;
    for e in entries.flatten() {
        let p = e.path();
        if !p.is_file() || p == media {
            continue;
        }
        let Some(ext) = p
            .extension()
            .and_then(|x| x.to_str())
            .map(str::to_lowercase)
        else {
            continue;
        };
        if !SIDECAR_EXTS.contains(&ext.as_str()) {
            continue;
        }
        let Some(stem) = p
            .file_stem()
            .and_then(|x| x.to_str())
            .map(str::to_lowercase)
        else {
            continue;
        };
        // Top priority: file named after the audio track itself (e.g. song.jpg for song.flac)
        if track_stem.as_deref() == Some(&stem) {
            return Some(p);
        }
        if let Some(rank) = SIDECAR_NAMES.iter().position(|n| *n == stem) {
            let rank = rank + 1; // 1-indexed to keep 0 for exact track stem
            let better = found.as_ref().map_or(true, |(_, r)| rank < *r);
            if better {
                found = Some((p, rank));
            }
        }
    }
    found.map(|(p, _)| p)
}

const MAGIC: &[u8; 8] = b"CALYART2";

struct SourceId {
    path: PathBuf,
    mtime_secs: u64,
    len: u64,
}

impl SourceId {
    fn of(path: &Path) -> Option<Self> {
        let meta = std::fs::metadata(path).ok()?;
        let mtime = meta
            .modified()
            .ok()?
            .duration_since(std::time::UNIX_EPOCH)
            .ok()?
            .as_secs();
        Some(Self {
            path: path.to_path_buf(),
            mtime_secs: mtime,
            len: meta.len(),
        })
    }
}

fn cache_path(cache_dir: &Path, uri: &str) -> PathBuf {
    use std::collections::hash_map::DefaultHasher;
    use std::hash::{Hash, Hasher};
    let mut h = DefaultHasher::new();
    uri.hash(&mut h);
    cache_dir.join(format!("{:016x}.art", h.finish()))
}

fn read_cache(path: &Path, source: &Path) -> Option<Artwork> {
    let bytes = std::fs::read(path).ok()?;
    if bytes.len() < 8 || &bytes[..8] != MAGIC {
        return None;
    }
    let mut rest = &bytes[8..];
    let path_len = u32::from_le_bytes(rest[..4].try_into().ok()?).min(4096) as usize;
    rest = &rest[4..];
    if rest.len() < path_len + 16 {
        return None;
    }
    let entry_path = PathBuf::from(String::from_utf8(rest[..path_len].to_vec()).ok()?);
    rest = &rest[path_len..];
    let mtime = u64::from_le_bytes(rest[..8].try_into().ok()?);
    let len = u64::from_le_bytes(rest[8..16].try_into().ok()?);
    rest = &rest[16..];
    let width = u32::from_le_bytes(rest[..4].try_into().ok()?);
    let height = u32::from_le_bytes(rest[4..8].try_into().ok()?);
    rest = &rest[8..];
    let need = (width as usize) * (height as usize) * 4;
    if rest.len() != need || width == 0 || height == 0 || width > MAX_DIM || height > MAX_DIM {
        return None;
    }
    let current = SourceId::of(source)?;
    if current.path != entry_path || (current.mtime_secs, current.len) != (mtime, len) {
        return None;
    }
    Some(Artwork {
        width,
        height,
        rgba: rest.to_vec(),
    })
}

fn write_cache(path: &Path, source: &Path, art: &Artwork) {
    let Some(dir) = path.parent() else {
        return;
    };
    if std::fs::create_dir_all(dir).is_err() {
        return;
    }
    let Some(src) = SourceId::of(source) else {
        return;
    };
    let src_name = src.path.to_string_lossy();
    let src_bytes = src_name.as_bytes();
    let mut bytes = Vec::with_capacity(32 + src_bytes.len() + art.rgba.len());
    bytes.extend_from_slice(MAGIC);
    bytes.extend_from_slice(&(src_bytes.len() as u32).to_le_bytes());
    bytes.extend_from_slice(src_bytes);
    bytes.extend_from_slice(&src.mtime_secs.to_le_bytes());
    bytes.extend_from_slice(&src.len.to_le_bytes());
    bytes.extend_from_slice(&art.width.to_le_bytes());
    bytes.extend_from_slice(&art.height.to_le_bytes());
    bytes.extend_from_slice(&art.rgba);
    let tmp_path = format!("{}.tmp", path.display());
    if std::fs::write(&tmp_path, &bytes).is_ok() {
        let _ = std::fs::rename(&tmp_path, path);
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn http_and_relative_uris_have_no_artwork() {
        let dir = std::env::temp_dir().join("caly-art-test");
        assert!(load("https://example.com/a.mp3", &dir).is_none());
    }
}
