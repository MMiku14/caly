//! Control commands sent from any thread to the engine worker.
use std::time::Duration;
use caly_core::queue::{RepeatMode, Track};

/// Commands understood by the engine worker thread.
#[derive(Debug, Clone)]
pub enum Control {
    /// Start playing the item at queue index `i`.
    PlayIndex(usize),
    /// Play the next item (aborting the current one).
    Next,
    /// Restart the current item, or move to the previous one.
    Prev,
    /// Pause the current stream (device keeps its clock).
    Pause,
    /// Resume from pause.
    Resume,
    /// Toggle pause/resume.
    TogglePause,
    /// Stop playback and reset the queue cursor semantics.
    Stop,
    /// Seek to an absolute position.
    Seek(Duration),
    /// Append tracks at the end of the queue.
    AddBack(Vec<Track>),
    /// Prepend tracks at the front of the queue.
    AddFront(Vec<Track>),
    /// Insert tracks at index `i`.
    Insert(usize, Vec<Track>),
    /// Remove the item at index `i`.
    Remove(usize),
    /// Move item from index `from` to `to` (Vim-style line move).
    Move(usize, usize),
    /// Clear the queue.
    Clear,
    /// Set the repeat mode.
    SetRepeat(RepeatMode),
    /// Flip shuffle.
    ToggleShuffle,
    /// Set master volume (linear `0.0..=2.0`).
    SetVolume(f32),
    /// Adjust master volume by a relative amount.
    AdjustVolume(f32),
    /// Stop the worker thread (engine teardown; ignores queue state).
    Shutdown,
}

impl Control {
    /// Human-readable one-liner for logs.
    pub fn describe(&self) -> String {
        match self {
            Control::PlayIndex(i) => format!("play #{i}"),
            Control::Next => "next".into(),
            Control::Prev => "prev".into(),
            Control::Pause => "pause".into(),
            Control::Resume => "resume".into(),
            Control::TogglePause => "toggle pause".into(),
            Control::Stop => "stop".into(),
            Control::Seek(d) => format!("seek {}", d.as_secs_f64()),
            Control::AddBack(v) => format!("add {} to back", v.len()),
            Control::AddFront(v) => format!("add {} to front", v.len()),
            Control::Insert(i, v) => format!("insert {} at {i}", v.len()),
            Control::Remove(i) => format!("remove #{i}"),
            Control::Move(from, to) => format!("move #{from} to #{to}"),
            Control::Clear => "clear".into(),
            Control::SetRepeat(m) => format!("repeat {m:?}"),
            Control::ToggleShuffle => "toggle shuffle".into(),
            Control::SetVolume(v) => format!("volume {v}"),
            Control::AdjustVolume(d) => format!("volume {d:+}"),
            Control::Shutdown => "shutdown".into(),
        }
    }
}
