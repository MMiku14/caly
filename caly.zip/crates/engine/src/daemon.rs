//! Background daemon service (`calyd`) for headless audio engine hosting and IPC dispatch.

use std::io::{BufRead, BufReader, Write};
use std::os::unix::net::{UnixListener, UnixStream};
use std::sync::atomic::{AtomicBool, Ordering};
use std::sync::Arc;
use std::thread;
use std::time::Duration;

use caly_core::ipc::{default_socket_path, DaemonStatus, IpcRequest};
use caly_core::queue::{RepeatMode, Track, TrackId};
use crate::control::Control;
use crate::engine::{Engine, EngineConfig};
use crate::registry::Registry;

/// Background audio playback daemon.
pub struct CalyDaemon {
    engine: Engine,
    running: Arc<AtomicBool>,
}

impl CalyDaemon {
    /// Initializes and starts the daemon listener.
    pub fn start(registry: Registry, config: EngineConfig) -> std::io::Result<Self> {
        let engine = Engine::start(registry, config);
        let socket_path = default_socket_path();

        if let Some(parent) = socket_path.parent() {
            let _ = std::fs::create_dir_all(parent);
        }
        let _ = std::fs::remove_file(&socket_path);

        let listener = UnixListener::bind(&socket_path)?;
        listener.set_nonblocking(true)?;

        let running = Arc::new(AtomicBool::new(true));
        let running_clone = running.clone();
        let engine_clone = engine.clone();

        thread::Builder::new()
            .name("caly-daemon-ipc".into())
            .spawn(move || {
                log::info!("calyd: listening on {}", socket_path.display());
                while running_clone.load(Ordering::Acquire) {
                    match listener.accept() {
                        Ok((stream, _)) => {
                            let eng = engine_clone.clone();
                            let run_flag = running_clone.clone();
                            thread::spawn(move || {
                                handle_client(stream, eng, run_flag);
                            });
                        }
                        Err(ref e) if e.kind() == std::io::ErrorKind::WouldBlock => {
                            thread::sleep(Duration::from_millis(50));
                        }
                        Err(e) => {
                            log::warn!("calyd accept error: {e}");
                            thread::sleep(Duration::from_millis(100));
                        }
                    }
                }
                let _ = std::fs::remove_file(&socket_path);
                log::info!("calyd: stopped");
            })?;

        Ok(Self { engine, running })
    }

    /// Access engine handle.
    pub fn engine(&self) -> &Engine {
        &self.engine
    }

    /// Shuts down the daemon.
    pub fn shutdown(&self) {
        self.running.store(false, Ordering::Release);
        self.engine.shutdown();
    }
}

fn handle_client(mut stream: UnixStream, engine: Engine, running: Arc<AtomicBool>) {
    let _ = stream.set_read_timeout(Some(Duration::from_secs(30)));
    let _ = stream.set_write_timeout(Some(Duration::from_secs(5)));
    let reader_stream = match stream.try_clone() {
        Ok(s) => s,
        Err(e) => {
            log::warn!("calyd: failed to clone client stream: {e}");
            return;
        }
    };
    let mut reader = BufReader::new(reader_stream);

    let mut line = String::new();
    while let Ok(n) = reader.read_line(&mut line) {
        if n == 0 {
            break;
        }

        if let Some(req) = IpcRequest::from_line(&line) {
            match req {
                IpcRequest::Play => engine.send(Control::Resume),
                IpcRequest::Pause => engine.send(Control::Pause),
                IpcRequest::TogglePause => engine.send(Control::TogglePause),
                IpcRequest::Stop => engine.send(Control::Stop),
                IpcRequest::Next => engine.send(Control::Next),
                IpcRequest::Prev => engine.send(Control::Prev),
                IpcRequest::Seek(d) => engine.send(Control::Seek(d)),
                IpcRequest::SetVolume(v) => engine.send(Control::SetVolume(v)),
                IpcRequest::AdjustVolume(d) => engine.send(Control::AdjustVolume(d)),
                IpcRequest::Enqueue(uris) => {
                    let tracks: Vec<Track> = uris
                        .into_iter()
                        .map(|u| Track::from_uri(TrackId(0), u))
                        .collect();
                    engine.enqueue(tracks, false);
                }
                IpcRequest::PlayIndex(i) => engine.send(Control::PlayIndex(i)),
                IpcRequest::ClearQueue => engine.send(Control::Clear),
                IpcRequest::ToggleRepeat => {
                    let next = match engine.snapshot().repeat {
                        RepeatMode::Off => RepeatMode::All,
                        RepeatMode::All => RepeatMode::One,
                        RepeatMode::One => RepeatMode::Off,
                    };
                    engine.send(Control::SetRepeat(next));
                }
                IpcRequest::ToggleShuffle => engine.send(Control::ToggleShuffle),
                IpcRequest::GetStatus => {
                    let snap = engine.snapshot();
                    let st = DaemonStatus {
                        state: format!("{:?}", snap.state),
                        title: snap.current.as_ref().map(|c| c.title.clone()).unwrap_or_default(),
                        artist: snap.current.as_ref().and_then(|c| c.artist.clone()).unwrap_or_default(),
                        album: snap.current.as_ref().and_then(|c| c.album.clone()).unwrap_or_default(),
                        uri: snap.current.as_ref().map(|c| c.uri.clone()).unwrap_or_default(),
                        elapsed_secs: snap.position.position.as_secs_f64(),
                        duration_secs: snap.position.duration.map(|d| d.as_secs_f64()).unwrap_or(0.0),
                        volume: snap.volume,
                        repeat: format!("{:?}", snap.repeat),
                        shuffle: snap.shuffle,
                        is_bit_perfect: snap.is_bit_perfect,
                        queue_len: snap.queue_len,
                        queue_cursor: snap.queue_cursor,
                    };
                    let _ = stream.write_all(st.to_line().as_bytes());
                    let _ = stream.flush();
                }
                IpcRequest::GetQueue => {
                    let snap = engine.snapshot();
                    let titles = snap.queue_titles.join("	");
                    let _ = writeln!(stream, "QUEUE	{}	{}", snap.queue_len, titles);
                    let _ = stream.flush();
                }
                IpcRequest::Subscribe => {
                    let mut last_rev = 0u64;
                    while running.load(Ordering::Acquire) {
                        let snap = engine.snapshot();
                        if snap.revision != last_rev {
                            last_rev = snap.revision;
                            let st = DaemonStatus {
                                state: format!("{:?}", snap.state),
                                title: snap.current.as_ref().map(|c| c.title.clone()).unwrap_or_default(),
                                artist: snap.current.as_ref().and_then(|c| c.artist.clone()).unwrap_or_default(),
                                album: snap.current.as_ref().and_then(|c| c.album.clone()).unwrap_or_default(),
                                uri: snap.current.as_ref().map(|c| c.uri.clone()).unwrap_or_default(),
                                elapsed_secs: snap.position.position.as_secs_f64(),
                                duration_secs: snap.position.duration.map(|d| d.as_secs_f64()).unwrap_or(0.0),
                                volume: snap.volume,
                                repeat: format!("{:?}", snap.repeat),
                                shuffle: snap.shuffle,
                                is_bit_perfect: snap.is_bit_perfect,
                                queue_len: snap.queue_len,
                                queue_cursor: snap.queue_cursor,
                            };
                            if stream.write_all(st.to_line().as_bytes()).is_err() {
                                return;
                            }
                            if stream.flush().is_err() {
                                return;
                            }
                        }
                        thread::sleep(Duration::from_millis(100));
                    }
                    return;
                }
                IpcRequest::Shutdown => {
                    let _ = writeln!(stream, "OK");
                    running.store(false, Ordering::Release);
                    engine.send(Control::Shutdown);
                    break;
                }
                IpcRequest::Ping => {
                    let _ = writeln!(stream, "PONG");
                    let _ = stream.flush();
                }
            }
        }
        line.clear();
    }
}
