//! The engine: command loop, playback state machine and sink feeding.

use caly_core::flow::SignalFlow;
use std::sync::atomic::Ordering;
use std::sync::mpsc::{channel, Receiver, Sender, TryRecvError};
use std::sync::{Arc, Condvar, Mutex, RwLock};
use std::thread;
use std::time::{Duration, Instant};
use caly_core::backend::{AudioBackend, EngineSink, OutputConfig, StreamParams, StreamState};
use caly_core::graph::{AudioGraph, FlushState};
use caly_core::media::DEFAULT_SAMPLE_RATE;
use caly_core::progress::Progress;
use caly_core::queue::{Queue, Track};
use caly_core::source::SourceBackend;
use crate::control::Control;
use crate::registry::Registry;
use crate::snapshot::{CurrentTrack, PlayState, Snapshot};

const PRIME_FRACTION: f64 = 0.5;
const DECODE_FRAMES: usize = 4096;
const MIN_FEED_FRAMES: usize = 512;
const LOOP_TIMEOUT: Duration = Duration::from_millis(100);
const DRAIN_TIMEOUT: Duration = Duration::from_secs(2);
const MAX_CONSECUTIVE_ERRORS: u8 = 3;
const DEFAULT_VOLUME: f32 = 0.8;

/// Engine configuration.
#[derive(Debug, Clone)]
pub struct EngineConfig {
    /// Output negotiation.
    pub output: OutputConfig,
    /// Decoder order by id, e.g. `["ffmpeg", "symphonia"]`.
    pub source_order: Vec<String>,
}

impl Default for EngineConfig {
    fn default() -> Self {
        Self {
            output: OutputConfig::default(),
            source_order: vec!["ffmpeg".into(), "symphonia".into()],
        }
    }
}

#[derive(Default)]
struct Kick {
    m: Mutex<()>,
    cv: Condvar,
}

impl Kick {
    fn wake(&self) {
        let _g = self.m.lock().unwrap();
        self.cv.notify_all();
    }
}

/// Handle to a running engine.
#[derive(Clone)]
pub struct Engine {
    tx: Sender<Control>,
    kick: Arc<Kick>,
    snap: Arc<RwLock<Snapshot>>,
    join: Arc<Mutex<Option<thread::JoinHandle<()>>>>,
}

impl Engine {
    /// Spawns the engine worker.
    pub fn start(registry: Registry, config: EngineConfig) -> Engine {
        let (tx, rx) = channel();
        let kick = Arc::new(Kick::default());
        let snap = Arc::new(RwLock::new(Snapshot::default()));
        let join = Arc::new(Mutex::new(None));
        let handle = Engine {
            tx: tx.clone(),
            kick: kick.clone(),
            snap: snap.clone(),
            join: join.clone(),
        };
        let registry = Arc::new(registry);
        let worker = thread::Builder::new()
            .name("caly-engine".into())
            .spawn(move || {
                let mut ctx = Ctx::new(registry, config, snap);
                run(rx, kick, &mut ctx);
            })
            .expect("failed to spawn engine thread");
        *join.lock().unwrap() = Some(worker);
        handle
    }

    /// Sends a command (non-blocking).
    pub fn send(&self, cmd: Control) {
        let _ = self.tx.send(cmd);
        self.kick.wake();
    }

    /// Current snapshot.
    pub fn snapshot(&self) -> Snapshot {
        self.snap.read().unwrap().clone()
    }

    /// Appends tracks and optionally starts playback.
    pub fn enqueue(&self, tracks: Vec<Track>, play: bool) {
        if tracks.is_empty() {
            return;
        }
        let start_idx = self.snapshot().queue_len;
        self.send(Control::AddBack(tracks));
        if play && start_idx > 0 {
            self.send(Control::PlayIndex(start_idx));
        }
    }

    /// Shutdown.
    pub fn shutdown(&self) {
        self.send(Control::Shutdown);
        let handle = self.join.lock().unwrap().take();
        if let Some(h) = handle {
            let deadline = std::time::Instant::now() + Duration::from_secs(3);
            loop {
                if h.is_finished() {
                    let _ = h.join();
                    break;
                }
                if std::time::Instant::now() >= deadline {
                    log::debug!("engine worker did not finish in time; detaching");
                    break;
                }
                std::thread::sleep(Duration::from_millis(10));
            }
        }
    }

    /// Convenience: current snapshot's state.
    pub fn state(&self) -> PlayState {
        self.snapshot().state
    }
}

struct Ctx {
    registry: Arc<Registry>,
    config: EngineConfig,
    queue: Queue,
    active: Option<Active>,
    pending_start: bool,
    pending_install: Option<Prepared>,
    prefetch: Option<Prefetch>,
    prefetch_failed_for: Option<String>,
    backend: Option<Box<dyn AudioBackend>>,
    backend_id: Option<&'static str>,
    volume: f32,
    snap: Arc<RwLock<Snapshot>>,
    dirty: bool,
    titles: Arc<Vec<String>>,
    titles_dirty: bool,
    last_publish: Instant,
    errors: u8,
    last_error: Option<String>,
    shutdown_requested: bool,
}

struct Active {
    source: Box<dyn SourceBackend>,
    source_id: &'static str,
    sink: EngineSink,
    graph: AudioGraph,
    scratch: Vec<f32>,
    scratch_offset: usize,
    book: PositionBook,
}

impl Active {
    #[inline]
    fn has_scratch(&self) -> bool {
        self.scratch_offset < self.scratch.len()
    }
    #[inline]
    fn clear_scratch(&mut self) {
        self.scratch.clear();
        self.scratch_offset = 0;
    }
}

struct PositionBook {
    rate: u32,
    base_pos: Duration,
    base_reported: u64,
}

impl PositionBook {
    fn new(rate: u32, base_pos: Duration) -> Self {
        Self {
            rate: rate.max(1),
            base_pos,
            base_reported: 0,
        }
    }
    fn position(&self, reported: u64) -> Duration {
        let frames = reported.saturating_sub(self.base_reported);
        let nanos = (frames as u128 * 1_000_000_000) / (self.rate as u128);
        self.base_pos + Duration::from_nanos(nanos as u64)
    }
}

struct Prepared {
    uri: String,
    source_id: &'static str,
    source: Box<dyn SourceBackend>,
    graph: AudioGraph,
    pre: Vec<f32>,
    rate: u32,
    ch: usize,
}

struct Prefetch {
    uri: String,
    rx: std::sync::mpsc::Receiver<Result<Prepared, String>>,
    cancel: Arc<std::sync::atomic::AtomicBool>,
}

fn buffer_frames_for(buffer_ms: u32, rate: u32) -> usize {
    let ms = buffer_ms.clamp(16, 4000) as u64;
    let f = ms * rate as u64 / 1000;
    let hi = (rate as u64 * 4).max(4096);
    f.clamp(4096, hi) as usize
}

fn prepare_track(
    registry: &Registry,
    source_order: &[String],
    uri: &str,
    output: &OutputConfig,
    volume: f32,
) -> Result<Prepared, String> {
    let (mut source, source_id) = registry
        .open_source(uri, source_order)
        .map_err(|e| format!("cannot open {uri:?}: {e}"))?;
    let rate = output.sample_rate.unwrap_or(DEFAULT_SAMPLE_RATE);
    let ch: usize = output.channels.count().get() as usize;
    let buffer_frames = buffer_frames_for(output.buffer_ms, rate);
    let mut graph = AudioGraph::new(rate, ch).map_err(|e| e.to_string())?;
    graph.set_gain_linear(volume, 10);
    let mut pre = Vec::new();
    let want = (buffer_frames as f64 * PRIME_FRACTION) as usize + DECODE_FRAMES;
    prime(&mut source, &mut graph, want, &mut pre).map_err(|e| e.to_string())?;
    if pre.is_empty() {
        return Err("no audio could be decoded".into());
    }
    Ok(Prepared {
        uri: uri.to_string(),
        source_id,
        source,
        graph,
        pre,
        rate,
        ch,
    })
}

fn spawn_prefetch(
    uri: String,
    registry: Arc<Registry>,
    order: Vec<String>,
    output: OutputConfig,
    volume: f32,
    cancel: Arc<std::sync::atomic::AtomicBool>,
) -> std::io::Result<std::sync::mpsc::Receiver<Result<Prepared, String>>> {
    let (tx, rx) = std::sync::mpsc::channel();
    thread::Builder::new()
        .name("caly-prefetch".into())
        .spawn(move || {
            if cancel.load(Ordering::Acquire) {
                return;
            }
            let res = prepare_track(&registry, &order, &uri, &output, volume);
            if !cancel.load(Ordering::Acquire) {
                let _ = tx.send(res);
            }
        })?;
    Ok(rx)
}

impl Ctx {
    fn new(registry: Arc<Registry>, config: EngineConfig, snap: Arc<RwLock<Snapshot>>) -> Self {
        Self {
            registry,
            config,
            queue: Queue::new(),
            active: None,
            pending_start: false,
            pending_install: None,
            prefetch: None,
            prefetch_failed_for: None,
            backend: None,
            backend_id: None,
            volume: DEFAULT_VOLUME,
            snap,
            dirty: true,
            titles: Arc::new(Vec::new()),
            titles_dirty: true,
            last_publish: Instant::now(),
            errors: 0,
            last_error: None,
            shutdown_requested: false,
        }
    }

    fn handle(&mut self, cmd: Control) {
        log::debug!("engine: {}", cmd.describe());
        match cmd {
            Control::PlayIndex(i) => match self.queue.play_at(i) {
                Ok(()) => {
                    self.abort_active(false);
                    self.prefetch = None;
                    self.prefetch_failed_for = None;
                    self.pending_install = None;
                    self.pending_start = true;
                }
                Err(e) => self.set_error(e.to_string()),
            },
            Control::Next => {
                self.abort_active(false);
                if self.queue.advance().is_some() {
                    if let Some(p) = self.poll_prefetch() {
                        self.pending_install = Some(p);
                    } else {
                        self.prefetch = None;
                    }
                    self.pending_start = true;
                } else {
                    self.stop_idle();
                }
            }
            Control::Prev => {
                let keep_playing = self
                    .active
                    .as_ref()
                    .map(|a| {
                        let s = a.sink.shared();
                        a.book.position(s.reported_total.load(Ordering::Acquire))
                            > Duration::from_secs(3)
                    })
                    .unwrap_or(false);
                if keep_playing {
                    self.seek(Duration::ZERO);
                } else {
                    self.abort_active(false);
                    self.queue.rewind();
                    self.pending_start = true;
                }
            }
            Control::Pause => self.pause(),
            Control::Resume => self.resume(),
            Control::TogglePause => match self.active.as_ref().map(|a| a.sink.shared().state()) {
                Some(StreamState::Playing) => self.pause(),
                Some(StreamState::Paused) => self.resume(),
                _ => {}
            },
            Control::Stop => {
                self.pending_start = false;
                self.pending_install = None;
                self.prefetch = None;
                self.prefetch_failed_for = None;
                self.abort_active(false);
                self.stop_idle();
            }
            Control::Seek(pos) => self.seek(pos),
            Control::AddBack(t) => {
                let was_idle = self.active.is_none();
                self.queue.push(t);
                self.dirty = true;
                self.titles_dirty = true;
                if was_idle && !self.queue.is_empty() {
                    let idx = self.queue.cursor().unwrap_or(0).min(self.queue.len() - 1);
                    if self.queue.play_at(idx).is_ok() {
                        self.pending_start = true;
                    }
                }
            }
            Control::AddFront(t) => {
                self.queue.insert(0, t);
                self.dirty = true;
                self.titles_dirty = true;
            }
            Control::Insert(i, t) => {
                self.queue.insert(i, t);
                self.dirty = true;
                self.titles_dirty = true;
            }
            Control::Move(from, to) => {
                let _ = self.queue.move_item(from, to);
                self.dirty = true;
                self.titles_dirty = true;
            }
            Control::Remove(i) => {
                let is_current = self.queue.cursor() == Some(i);
                if self.queue.remove(i).is_ok() {
                    if is_current {
                        self.abort_active(false);
                        self.pending_install = None;
                        self.prefetch = None;
                        if self.queue.cursor().is_some() {
                            self.pending_start = true;
                        } else {
                            self.stop_idle();
                        }
                    }
                    self.dirty = true;
                    self.titles_dirty = true;
                }
            }
            Control::Clear => {
                self.pending_start = false;
                self.pending_install = None;
                self.prefetch = None;
                self.prefetch_failed_for = None;
                self.abort_active(false);
                self.queue.clear();
                self.stop_idle();
                self.titles_dirty = true;
            }
            Control::SetRepeat(m) => {
                self.queue.set_repeat(m);
                self.dirty = true;
            }
            Control::ToggleShuffle => {
                self.queue.set_shuffle(!self.queue.shuffle());
                self.dirty = true;
            }
            Control::SetVolume(v) => self.set_volume(v),
            Control::AdjustVolume(d) => self.set_volume(self.volume + d),
            Control::Shutdown => {
                self.shutdown_requested = true;
            }
        }
    }

    fn pause(&mut self) {
        if let Some(a) = &self.active {
            a.sink
                .shared()
                .state
                .store(StreamState::Paused as u8, Ordering::Release);
            if let Some(b) = &mut self.backend {
                let _ = b.pause();
            }
            self.dirty = true;
        }
    }

    fn resume(&mut self) {
        if let Some(a) = &self.active {
            a.sink
                .shared()
                .state
                .store(StreamState::Playing as u8, Ordering::Release);
            if let Some(b) = &mut self.backend {
                let _ = b.resume();
            }
            self.dirty = true;
        }
    }

    fn set_volume(&mut self, v: f32) {
        self.volume = v.clamp(0.0, 2.0);
        if let Some(a) = &mut self.active {
            a.graph.set_gain_linear(self.volume, 30);
        }
        self.dirty = true;
    }

    fn seek(&mut self, mut pos: Duration) {
        let Some(a) = &mut self.active else { return };
        let was_paused = a.sink.shared().state() == StreamState::Paused;
        if let Some(d) = a.source.track_meta().duration {
            pos = pos.min(d);
        }
        match a.source.seek(pos) {
            Ok(()) => {
                a.graph.reset();
                a.clear_scratch();
                a.sink.bump_generation();
                a.book.base_pos = pos;
                a.book.base_reported = a.sink.shared().reported_total.load(Ordering::SeqCst);
                a.sink.shared().state.store(
                    if was_paused {
                        StreamState::Paused as u8
                    } else {
                        StreamState::Playing as u8
                    },
                    Ordering::Release,
                );
                self.dirty = true;
            }
            Err(e) => self.set_error(format!("seek failed: {e}")),
        }
    }

    fn abort_active(&mut self, graceful: bool) {
        let Some(a) = self.active.take() else { return };
        let shared = a.sink.shared().clone();
        if graceful {
            shared
                .state
                .store(StreamState::Draining as u8, Ordering::Release);
            let deadline = Instant::now() + DRAIN_TIMEOUT;
            while Instant::now() < deadline && !shared.finished.load(Ordering::Acquire) {
                thread::sleep(Duration::from_millis(5));
            }
        } else {
            shared
                .state
                .store(StreamState::Stopping as u8, Ordering::Release);
        }
        if let Some(b) = &mut self.backend {
            if let Err(e) = b.stop() {
                log::warn!("backend stop: {e}");
            }
        }
        self.dirty = true;
    }

    fn stop_idle(&mut self) {
        self.errors = 0;
        self.dirty = true;
    }

    fn start_current(&mut self) {
        let Some(track) = self.queue.current().cloned() else {
            self.stop_idle();
            return;
        };
        self.errors = 0;
        match prepare_track(
            &self.registry,
            &self.config.source_order,
            &track.uri,
            &self.config.output,
            self.volume,
        ) {
            Ok(p) => self.install(p),
            Err(e) => {
                self.set_error(e);
                self.handle_track_failure();
            }
        }
    }

    fn install(&mut self, prepared: Prepared) {
        let Prepared {
            uri,
            source_id,
            source,
            graph,
            pre,
            rate,
            ch,
        } = prepared;
        let (ch_u8, ch_usize) = (ch as u8, ch);
        let buffer_frames = buffer_frames_for(self.config.output.buffer_ms, rate);
        let params = StreamParams {
            sample_rate: rate,
            channels: self.config.output.channels.count(),
            layout: self.config.output.channels.layout(),
            buffer_frames,
            stream_name: "caly",
        };
        let candidates = self.registry.create_backends(&self.config.output);
        if candidates.is_empty() {
            self.set_error("no output backend available".into());
            self.handle_track_failure();
            return;
        }
        let mut spare = self.backend.take();
        let spare_id: Option<&'static str> = self.backend_id;
        let mut last_err = String::from("no candidate started");
        for (info, fresh) in candidates {
            let mut backend = if spare_id == Some(info.id) {
                match spare.take() {
                    Some(b) => b,
                    None => fresh,
                }
            } else {
                fresh
            };
            let (mut sink, reader) = EngineSink::new(buffer_frames, ch_u8);
            let primed = sink.write(&pre, ch_u8);
            if let Err(e) = backend.start(&params, reader) {
                log::warn!("backend {} failed to start: {e}", info.id);
                last_err = e.to_string();
                continue;
            }
            log::info!("playing {uri:?} via {} / {source_id}", info.id);
            sink.shared()
                .state
                .store(StreamState::Playing as u8, Ordering::Release);
            let mut scratch = Vec::new();
            let consumed = primed * ch_usize;
            if consumed < pre.len() {
                scratch.extend_from_slice(&pre[consumed..]);
            }
            let active = Active {
                source,
                source_id,
                sink,
                graph,
                scratch,
                scratch_offset: 0,
                book: PositionBook::new(rate, Duration::ZERO),
            };
            self.backend = Some(backend);
            self.backend_id = Some(info.id);
            self.active = Some(active);
            self.dirty = true;
            return;
        }
        self.set_error(format!("all backends failed: {last_err}"));
        self.handle_track_failure();
    }

    fn handle_track_failure(&mut self) {
        self.abort_active(false);
        self.errors += 1;
        if self.errors <= MAX_CONSECUTIVE_ERRORS && self.queue.advance().is_some() {
            log::warn!(
                "auto-skipping to next track ({}/{})",
                self.errors,
                MAX_CONSECUTIVE_ERRORS
            );
            self.start_current();
            return;
        }
        self.stop_idle();
    }

    fn start_prefetch(&mut self) {
        if self.prefetch.is_some() || self.queue.cursor().is_none() {
            return;
        }
        let Some(idx) = self.queue.peek_next_index() else {
            return;
        };
        let Some(track) = self.queue.items().get(idx) else {
            return;
        };
        let uri = track.uri.clone();
        if self.prefetch_failed_for.as_deref() == Some(&uri) {
            return;
        }
        let order = self.config.source_order.clone();
        let output = self.config.output.clone();
        log::debug!("prefetch: opening next track {uri:?}");
        let cancel = Arc::new(std::sync::atomic::AtomicBool::new(false));
        match spawn_prefetch(
            uri.clone(),
            self.registry.clone(),
            order,
            output,
            self.volume,
            cancel.clone(),
        ) {
            Ok(rx) => self.prefetch = Some(Prefetch { uri, rx, cancel }),
            Err(e) => {
                log::warn!("prefetch spawn failed: {e}");
                self.prefetch_failed_for = Some(uri);
            }
        }
    }

    fn poll_prefetch(&mut self) -> Option<Prepared> {
        let p = self.prefetch.take()?;
        match p.rx.try_recv() {
            Ok(Ok(prep)) => {
                let matches = self
                    .queue
                    .current()
                    .map(|t| t.uri == prep.uri)
                    .unwrap_or(false);
                if matches {
                    log::debug!("prefetch: hit for {}", prep.uri);
                    Some(prep)
                } else {
                    log::debug!("discarding stale prefetch for {}", p.uri);
                    p.cancel.store(true, Ordering::Release);
                    None
                }
            }
            Ok(Err(e)) => {
                log::debug!("prefetch failed for {}: {e}", p.uri);
                self.prefetch_failed_for = Some(p.uri);
                None
            }
            Err(std::sync::mpsc::TryRecvError::Empty) => {
                self.prefetch = Some(p);
                None
            }
            Err(std::sync::mpsc::TryRecvError::Disconnected) => None,
        }
    }

    fn set_error(&mut self, msg: String) {
        log::warn!("engine error: {msg}");
        self.dirty = true;
        self.last_error = Some(msg);
    }

    fn step(&mut self) {
        if self.pending_start {
            self.pending_start = false;
            if self.active.is_none() {
                if let Some(p) = self.pending_install.take() {
                    self.install(p);
                } else {
                    self.start_current();
                }
            }
        }
        let mut eos = false;
        let mut near_end = false;
        let mut failed: Option<String> = None;
        {
            let Some(a) = &mut self.active else { return };
            match a.sink.shared().state() {
                StreamState::Playing => {
                    let ch = a.graph.output_channels;
                    let mut iterations = 0usize;
                    while a.sink.free_frames() >= MIN_FEED_FRAMES && iterations < 64 {
                        iterations += 1;
                        if !a.has_scratch() {
                            match decode_into(a) {
                                Ok(true) => {}
                                Ok(false) => {
                                    a.sink
                                        .shared()
                                        .state
                                        .store(StreamState::Draining as u8, Ordering::Release);
                                    break;
                                }
                                Err(e) => {
                                    failed = Some(e.to_string());
                                    break;
                                }
                            }
                        }
                        if !a.has_scratch() {
                            continue;
                        }
                        write_scratch(a, ch);
                    }
                    if let Some(d) = a.source.track_meta().duration {
                        let pos = a
                            .book
                            .position(a.sink.shared().reported_total.load(Ordering::Acquire));
                        if d.saturating_sub(pos) < Duration::from_millis(2500) {
                            near_end = true;
                        }
                    }
                }
                StreamState::Draining => {
                    if a.has_scratch() {
                        if a.sink.free_frames() >= MIN_FEED_FRAMES {
                            write_scratch(a, a.graph.output_channels);
                        } else {
                            let _ = a.sink.wait_room(MIN_FEED_FRAMES, Duration::from_millis(5));
                        }
                        eos = false;
                    } else {
                        eos = a.sink.shared().finished.load(Ordering::Acquire);
                        if eos && a.sink.shared().state() == StreamState::Stopping {
                            eos = false;
                        }
                    }
                }
                _ => {}
            }
        }
        if near_end {
            self.start_prefetch();
        }
        if let Some(err) = failed {
            let _ = self.active.take();
            self.set_error(err);
            self.handle_track_failure();
        } else if eos {
            self.on_eos();
        }
    }

    fn on_eos(&mut self) {
        self.start_prefetch();
        self.abort_active(true);
        if self.queue.advance().is_some() {
            if let Some(p) = self.poll_prefetch() {
                self.install(p);
            } else {
                self.prefetch = None;
                self.start_current();
            }
        } else {
            self.stop_idle();
        }
    }

    fn publish(&mut self) {
        let mut snap = self.snap.write().unwrap();
        let queue_len = self.queue.len();
        let queue_duration = self.queue.total_duration();
        let cursor = self.queue.cursor();
        let (state, position, current, stream) = match &self.active {
            Some(a) => {
                let s = a.sink.shared();
                let st = match s.state() {
                    StreamState::Playing | StreamState::Draining => PlayState::Playing,
                    StreamState::Paused => PlayState::Paused,
                    _ => PlayState::Stopped,
                };
                let reported = s.reported_total.load(Ordering::Acquire);
                let position = a.book.position(reported);
                let meta = a.source.track_meta();
                let queued = self.queue.items();
                let fallback = cursor.and_then(|i| queued.get(i));
                let current = cursor.map(|i| CurrentTrack {
                    index: i,
                    title: meta
                        .title
                        .clone()
                        .or_else(|| fallback.map(|t| t.title.clone()))
                        .unwrap_or_default(),
                    artist: meta
                        .artist
                        .clone()
                        .or_else(|| fallback.and_then(|t| t.artist.clone())),
                    album: meta
                        .album
                        .clone()
                        .or_else(|| fallback.and_then(|t| t.album.clone())),
                    duration: meta.duration.or_else(|| fallback.and_then(|t| t.duration)),
                    uri: fallback.map(|t| t.uri.clone()).unwrap_or_default(),
                });
                let stream = a.source.stream_info().cloned();
                (st, Progress::new(position, meta.duration), current, stream)
            }
            None => (PlayState::Stopped, Progress::default(), None, None),
        };
        let output = self.active.as_ref().map(|a| {
            format!(
                "{} Hz / {} ch",
                a.graph.output_rate, a.graph.output_channels
            )
        });
        let underruns = self
            .active
            .as_ref()
            .map(|a| a.sink.shared().underruns.load(Ordering::Relaxed))
            .unwrap_or(0);
        let (signal_flow, flow_summary, is_bit_perfect) = match &self.active {
            Some(a) => {
                let stream_info = a.source.stream_info();
                let uri = current.as_ref().map(|c| c.uri.as_str()).unwrap_or("");
                let res = self.backend.as_ref().map(|b| b.info().resource).unwrap_or("Audio Server");
                let flow = a.graph.build_signal_flow(
                    uri,
                    a.source_id,
                    stream_info,
                    self.backend_id.unwrap_or("default"),
                    res,
                );
                let summary = flow.arrow_summary();
                let bp = flow.is_bit_perfect;
                (flow, summary, bp)
            }
            None => (SignalFlow::default(), "Idle".to_string(), false),
        };
        snap.state = state;
        snap.position = position;
        snap.queue_len = queue_len;
        snap.queue_duration = queue_duration;
        snap.queue_cursor = cursor;
        if self.titles_dirty {
            self.titles = Arc::new(self.queue.items().iter().map(|t| t.title.clone()).collect());
            self.titles_dirty = false;
        }
        snap.queue_titles = self.titles.clone();
        snap.current = current;
        snap.volume = self.volume;
        snap.repeat = self.queue.repeat();
        snap.shuffle = self.queue.shuffle();
        snap.backend = self.backend_id;
        snap.source = self.active.as_ref().map(|a| a.source_id);
        snap.output = output;
        snap.stream = stream;
        snap.underruns = underruns;
        snap.flow_summary = flow_summary;
        snap.is_bit_perfect = is_bit_perfect;
        snap.signal_flow = signal_flow;
        snap.last_error = self.last_error.clone();
        snap.revision += 1;
        self.dirty = false;
        self.last_publish = Instant::now();
    }
}

fn write_scratch(active: &mut Active, ch: usize) {
    for _ in 0..8 {
        let remaining = &active.scratch[active.scratch_offset..];
        if remaining.is_empty() {
            active.clear_scratch();
            break;
        }
        let n = active.sink.write(remaining, ch as u8);
        if n == 0 {
            break;
        }
        let consumed = n * ch;
        active.scratch_offset += consumed;
        if active.scratch_offset >= active.scratch.len() {
            active.clear_scratch();
            break;
        }
    }
}

fn prime(
    source: &mut Box<dyn SourceBackend>,
    graph: &mut AudioGraph,
    want_frames: usize,
    pre: &mut Vec<f32>,
) -> Result<(), String> {
    let ch = graph.output_channels;
    let mut guard = 0usize;
    while pre.len() / ch < want_frames && guard < 512 {
        guard += 1;
        match source.next_chunk(DECODE_FRAMES) {
            Ok(Some(buf)) => {
                let out = graph.process(&buf).map_err(|e| e.to_string())?;
                pre.extend_from_slice(out);
            }
            Ok(None) => {
                if graph.flush().map_err(|e| e.to_string())? == FlushState::Produced {
                    pre.extend_from_slice(&graph.take_flush_output());
                }
                break;
            }
            Err(e) => return Err(format!("{e}")),
        }
    }
    Ok(())
}

fn decode_into(active: &mut Active) -> Result<bool, caly_core::CalyError> {
    loop {
        match active.source.next_chunk(DECODE_FRAMES) {
            Ok(Some(buf)) => {
                let out = active.graph.process(&buf)?;
                if out.is_empty() {
                    continue;
                }
                active.scratch_offset = 0;
                active.scratch.extend_from_slice(out);
                return Ok(true);
            }
            Ok(None) => match active.graph.flush()? {
                FlushState::Produced => {
                    active.scratch = active.graph.take_flush_output();
                    active.scratch_offset = 0;
                    return Ok(true);
                }
                FlushState::Drained => return Ok(false),
            },
            Err(e) => return Err(caly_core::CalyError::Decode(e.to_string())),
        }
    }
}

fn run(rx: Receiver<Control>, kick: Arc<Kick>, ctx: &mut Ctx) {
    log::info!("engine worker started");
    let mut publish_now = true;
    'outer: loop {
        loop {
            match rx.try_recv() {
                Ok(cmd) => {
                    ctx.handle(cmd);
                    if ctx.shutdown_requested {
                        break 'outer;
                    }
                    publish_now = true;
                }
                Err(TryRecvError::Empty) => break,
                Err(TryRecvError::Disconnected) => break 'outer,
            }
        }
        if publish_now {
            ctx.publish();
            publish_now = false;
        }
        ctx.step();
        publish_now |= ctx.dirty;
        if publish_now || ctx.last_publish.elapsed() > Duration::from_millis(200) {
            ctx.publish();
            publish_now = false;
        }
        let guard = kick.m.lock().unwrap();
        if let Ok(cmd) = rx.try_recv() {
            drop(guard);
            ctx.handle(cmd);
            if ctx.shutdown_requested {
                break 'outer;
            }
            continue;
        }
        let (g, _) = kick.cv.wait_timeout(guard, LOOP_TIMEOUT).unwrap();
        drop(g);
    }
    if let Some(a) = ctx.active.take() {
        a.sink
            .shared()
            .state
            .store(StreamState::Stopping as u8, Ordering::Release);
    }
    ctx.prefetch = None;
    ctx.pending_install = None;
    ctx.publish();
    log::info!("engine worker stopped");
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn position_book_works() {
        let mut b = PositionBook::new(48000, Duration::ZERO);
        assert_eq!(b.position(48000), Duration::from_secs(1));
        b.base_reported = 96000;
        b.base_pos = Duration::from_secs(10);
        assert_eq!(b.position(96000 + 4800 * 2), Duration::from_millis(10200));
    }
}
