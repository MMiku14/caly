//! The component registry: transports, decoders and output backends.
use caly_core::backend::{AudioBackend, BackendFactory, BackendInfo, OutputConfig};
use caly_core::source::{ProbeInfo, SourceBackend, SourceFactory, SourceResult};
use caly_core::transport::{Transport, TransportFactory};
use caly_core::CalyError;
use caly_core::Result;

/// One registered output backend, with its factory.
pub struct BackendEntry {
    /// Static info.
    pub info: BackendInfo,
    /// Factory used to create instances.
    pub factory: Box<dyn BackendFactory>,
}

impl BackendEntry {
    /// Creates an entry.
    pub fn new(factory: Box<dyn BackendFactory>) -> Self {
        Self {
            info: *factory.info(),
            factory,
        }
    }
}

/// Holds every plugin of the application.
pub struct Registry {
    transports: Vec<Box<dyn TransportFactory>>,
    sources: Vec<Box<dyn SourceFactory>>,
    backends: Vec<BackendEntry>,
}

/// Builder for [`Registry`].
#[derive(Default)]
pub struct RegistryBuilder {
    transports: Vec<Box<dyn TransportFactory>>,
    sources: Vec<Box<dyn SourceFactory>>,
    backends: Vec<BackendEntry>,
}

impl RegistryBuilder {
    /// Creates an empty builder.
    pub fn new() -> Self {
        Self::default()
    }
    /// Registers a transport factory.
    pub fn transport(mut self, t: Box<dyn TransportFactory>) -> Self {
        self.transports.push(t);
        self
    }
    /// Registers a decoder factory.
    pub fn source(mut self, s: Box<dyn SourceFactory>) -> Self {
        self.sources.push(s);
        self
    }
    /// Registers an output backend factory.
    pub fn backend(mut self, b: Box<dyn BackendFactory>) -> Self {
        self.backends.push(BackendEntry::new(b));
        self
    }
    /// Builds the registry.
    pub fn build(self) -> Registry {
        Registry {
            transports: self.transports,
            sources: self.sources,
            backends: self.backends,
        }
    }
}

impl Registry {
    /// Opens a transport for `uri`.
    pub fn open_transport(&self, uri: &str) -> Result<Box<dyn Transport>> {
        if uri.is_empty() {
            return Err(CalyError::Config("empty uri".into()));
        }
        for t in &self.transports {
            if t.can_open(uri) {
                return t
                    .open(uri)
                    .map_err(|e| CalyError::Unavailable(format!("{}: {e}", t.kind())));
            }
        }
        Err(CalyError::Unavailable(format!(
            "no transport registered for {uri:?}"
        )))
    }

    /// Opens a decoding session.
    pub fn open_source(
        &self,
        uri: &str,
        order: &[String],
    ) -> Result<(Box<dyn SourceBackend>, &'static str)> {
        let mut last_err: Option<SourceResult<Box<dyn SourceBackend>>> = None;
        for f in self.sources_in_order(order) {
            if !f.can_open(uri) {
                continue;
            }
            log::debug!("trying decoder {} for {uri}", f.id());
            let transport = self.open_transport(uri)?;
            match f.open(uri, transport) {
                Ok(b) => return Ok((b, f.id())),
                Err(e) => {
                    log::warn!("decoder {} failed for {uri}: {e}", f.id());
                    last_err = Some(Err(e));
                }
            }
        }
        let detail = last_err
            .map(|e| e.err().map(|x| x.to_string()).unwrap_or_default())
            .unwrap_or_else(|| "no decoder accepted the file".into());
        Err(CalyError::Decode(format!("cannot open {uri:?}: {detail}")))
    }

    /// Probes `uri`.
    pub fn probe(&self, uri: &str, order: &[String]) -> Result<ProbeInfo> {
        let mut last_err: Option<String> = None;
        for f in self.sources_in_order(order) {
            if !f.can_open(uri) {
                continue;
            }
            let transport = self.open_transport(uri)?;
            match f.probe(uri, transport) {
                Ok(p) => return Ok(p),
                Err(e) => last_err = Some(e.to_string()),
            }
        }
        Err(CalyError::Decode(format!(
            "probe failed for {uri:?}: {}",
            last_err.unwrap_or_else(|| "no decoder accepted the file".into())
        )))
    }

    fn sources_in_order(&self, order: &[String]) -> Vec<&dyn SourceFactory> {
        let mut chosen: Vec<&dyn SourceFactory> = Vec::new();
        for id in order {
            if let Some(f) = self.sources.iter().find(|f| f.id() == id.as_str()) {
                chosen.push(f.as_ref());
            }
        }
        for f in &self.sources {
            if !chosen.iter().any(|c| c.id() == f.id()) {
                chosen.push(f.as_ref());
            }
        }
        chosen
    }

    /// Output backends.
    pub fn backend_entries(&self) -> &[BackendEntry] {
        &self.backends
    }

    /// Creates configured backend instances.
    pub fn create_backends(
        &self,
        config: &OutputConfig,
    ) -> Vec<(&BackendInfo, Box<dyn AudioBackend>)> {
        let mut entries: Vec<&BackendEntry> = self.backends.iter().collect();
        if let Some(id) = &config.backend {
            entries.retain(|e| e.info.id == id.as_str());
            if entries.is_empty() {
                log::error!("backend {id:?} is not registered");
                return Vec::new();
            }
        } else {
            entries.sort_by_key(|e| std::cmp::Reverse(e.info.priority));
        }
        let mut out = Vec::new();
        for e in entries {
            match e.factory.create(config) {
                Ok(b) => out.push((&e.info, b)),
                Err(err) => log::debug!("creating backend {} failed: {err}", e.info.id),
            }
        }
        out
    }

    /// All registered transport factories.
    pub fn transports(&self) -> &[Box<dyn TransportFactory>] {
        &self.transports
    }

    /// All registered decoder factories.
    pub fn sources(&self) -> &[Box<dyn SourceFactory>] {
        &self.sources
    }

    /// All registered backend factories.
    pub fn backends(&self) -> &[BackendEntry] {
        &self.backends
    }
}

impl Default for Registry {
    fn default() -> Self {
        RegistryBuilder::new().build()
    }
}
