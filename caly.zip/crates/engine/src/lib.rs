//! `caly-engine` - the playback state machine.
#![forbid(unsafe_code)]
#![warn(missing_docs, rust_2018_idioms)]

pub mod control;
pub mod engine;
pub mod registry;
pub mod snapshot;

pub use control::Control;
pub use engine::{Engine, EngineConfig};
pub use registry::{Registry, RegistryBuilder};
pub use snapshot::{CurrentTrack, PlayState, Snapshot};
