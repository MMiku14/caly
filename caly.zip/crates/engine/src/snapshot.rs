//! Read-only snapshots of engine state, polled by the UI.

use caly_core::flow::SignalFlow;
use std::sync::Arc;
use std::time::Duration;
use caly_core::progress::Progress;
use caly_core::queue::RepeatMode;
use caly_core::source::StreamInfo;

/// High-level playback state.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Default)]
pub enum PlayState {
    /// No stream active.
    #[default]
    Stopped,
    /// Currently playing.
    Playing,
    /// Currently paused.
    Paused,
}

impl PlayState {
    /// One-letter/symbol display.
    pub fn symbol(&self) -> &'static str {
        match self {
            PlayState::Stopped => "\u{25a0}",
            PlayState::Playing => "\u{25b6}",
            PlayState::Paused => "\u{23f8}",
        }
    }
}

/// Info about the currently playing queue item.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct CurrentTrack {
    /// Queue index.
    pub index: usize,
    /// Display title.
    pub title: String,
    /// Artist (optional).
    pub artist: Option<String>,
    /// Album (optional).
    pub album: Option<String>,
    /// Duration when known.
    pub duration: Option<Duration>,
    /// Track URI.
    pub uri: String,
}

/// Complete engine state for the UI.
#[derive(Debug, Clone, Default)]
pub struct Snapshot {
    /// Playback state.
    pub state: PlayState,
    /// Current position / duration.
    pub position: Progress,
    /// Total queue length.
    pub queue_len: usize,
    /// Total duration of all queued tracks when known.
    pub queue_duration: Option<Duration>,
    /// Display titles.
    pub queue_titles: Arc<Vec<String>>,
    /// Current queue index.
    pub queue_cursor: Option<usize>,
    /// Current track view.
    pub current: Option<CurrentTrack>,
    /// Master volume (linear).
    pub volume: f32,
    /// Repeat mode.
    pub repeat: RepeatMode,
    /// Shuffle flag.
    pub shuffle: bool,
    /// Active output backend id.
    pub backend: Option<&'static str>,
    /// Active decoding backend id.
    pub source: Option<&'static str>,
    /// Output format string.
    pub output: Option<String>,
    /// Stream layout of the current track.
    pub stream: Option<StreamInfo>,
    /// Audio processing flow summary (e.g. "Bit-Perfect (44100 Hz, 2ch)").
    pub flow_summary: String,
    /// True when the signal flow is 100% Bit-Perfect passthrough.
    pub is_bit_perfect: bool,
    /// Full end-to-end signal flow chain.
    pub signal_flow: SignalFlow,
    /// Last non-fatal error.
    pub last_error: Option<String>,
    /// Cumulative device underruns since start.
    pub underruns: u64,
    /// Monotonic revision.
    pub revision: u64,
}
