//! The **null** output backend: consumes audio at real-time pace and discards it.
#![forbid(unsafe_code)]
#![warn(missing_docs)]

use std::sync::atomic::{AtomicBool, Ordering};
use std::sync::Arc;
use std::thread;
use std::time::{Duration, Instant};
use caly_core::backend::{
    AudioBackend, BackendError, BackendFactory, BackendInfo, BackendResult, OutputConfig,
    SinkReader, StreamParams, StreamState,
};

const INFO: BackendInfo = BackendInfo {
    id: "null",
    name: "Null (dry-run)",
    description: "Discards audio at real-time pace; useful for testing",
    priority: -100,
    resource: "<null>",
};

/// Backend factory for the null sink.
pub struct NullFactory;

impl BackendFactory for NullFactory {
    fn info(&self) -> &BackendInfo {
        &INFO
    }
    fn create(&self, _config: &OutputConfig) -> Result<Box<dyn AudioBackend>, BackendError> {
        Ok(Box::new(NullSink {
            stop: None,
            thread: None,
        }))
    }
}

/// A null sink instance.
pub struct NullSink {
    stop: Option<Arc<AtomicBool>>,
    thread: Option<thread::JoinHandle<()>>,
}

impl NullSink {
    fn spawn(&mut self, params: &StreamParams, mut reader: SinkReader) -> BackendResult<()> {
        let stop = Arc::new(AtomicBool::new(false));
        let stop2 = stop.clone();
        let shared = reader.shared_mut().clone();
        let quantum = 1024usize;
        let ch = params.channels.get() as usize;
        let frame_time = Duration::from_secs_f64(1.0 / params.sample_rate as f64);
        let handle = thread::Builder::new()
            .name("caly-sink-null".into())
            .spawn(move || {
                let mut scratch = vec![0.0f32; quantum * ch];
                let mut next_deadline = Instant::now();
                while !stop2.load(Ordering::Acquire) {
                    let state = shared.state();
                    match state {
                        StreamState::Stopped | StreamState::Stopping => break,
                        StreamState::Playing | StreamState::Draining => {
                            let n = reader.read(&mut scratch);
                            if n > 0 {
                                reader.note_reported(n as u64);
                            } else if state == StreamState::Draining {
                                reader.note_finished();
                            } else {
                                reader.note_underrun();
                            }
                            let now = Instant::now();
                            if next_deadline < now {
                                next_deadline = now;
                            }
                            next_deadline +=
                                Duration::from_secs_f64(quantum as f64 * frame_time.as_secs_f64());
                            thread::sleep(next_deadline.saturating_duration_since(now));
                        }
                        StreamState::Paused => {
                            thread::sleep(Duration::from_millis(20));
                        }
                    }
                }
            })
            .map_err(|e| BackendError::State(format!("spawn failed: {e}")))?;
        self.stop = Some(stop);
        self.thread = Some(handle);
        Ok(())
    }
}

impl AudioBackend for NullSink {
    fn info(&self) -> &BackendInfo {
        &INFO
    }
    fn start(&mut self, params: &StreamParams, reader: SinkReader) -> BackendResult<()> {
        self.stop()?;
        self.spawn(params, reader)
    }
    fn pause(&mut self) -> BackendResult<()> {
        Ok(())
    }
    fn resume(&mut self) -> BackendResult<()> {
        Ok(())
    }
    fn stop(&mut self) -> BackendResult<()> {
        if let Some(s) = &self.stop {
            s.store(true, Ordering::Release);
        }
        if let Some(h) = self.thread.take() {
            let _ = h.join();
        }
        self.stop = None;
        Ok(())
    }
}

impl Drop for NullSink {
    fn drop(&mut self) {
        let _ = self.stop();
    }
}
