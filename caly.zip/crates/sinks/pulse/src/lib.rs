//! **PulseAudio** output backend.
#![warn(missing_docs, rust_2018_idioms)]

use std::ffi::{c_int, c_void, CString};
use std::sync::atomic::{AtomicBool, Ordering};
use std::sync::Arc;
use std::thread;
use libpulse_sys as pulse;
use caly_core::backend::{
    AudioBackend, BackendError, BackendFactory, BackendInfo, BackendResult, OutputConfig,
    SinkReader, StartAck, StreamParams, StreamState,
};

const INFO: BackendInfo = BackendInfo {
    id: "pulse",
    name: "PulseAudio",
    description: "PulseAudio compatibility (simple API)",
    priority: 60,
    resource: "PulseAudio server",
};

/// Factory for [`PulseSink`].
pub struct PulseFactory;

impl BackendFactory for PulseFactory {
    fn info(&self) -> &BackendInfo {
        &INFO
    }
    fn create(&self, config: &OutputConfig) -> Result<Box<dyn AudioBackend>, BackendError> {
        Ok(Box::new(PulseSink {
            device: config.device.clone(),
            thread: None,
            stop_flag: None,
            ack: None,
        }))
    }
}

/// A single PulseAudio output session.
pub struct PulseSink {
    device: Option<String>,
    thread: Option<thread::JoinHandle<()>>,
    stop_flag: Option<Arc<AtomicBool>>,
    ack: Option<Arc<StartAck>>,
}

struct Simple(*mut libpulse_simple_sys::pa_simple);
unsafe impl Send for Simple {}

impl PulseSink {
    fn spawn(
        &mut self,
        params: &StreamParams,
        mut reader: SinkReader,
        device: &Option<String>,
    ) -> BackendResult<()> {
        let stop = Arc::new(AtomicBool::new(false));
        let stop2 = stop.clone();
        let rate = params.sample_rate;
        let ch = params.channels.get() as usize;
        let ch_u8 = params.channels.get();
        let quantum = 1024usize;
        let dev_c = device.as_deref().and_then(|d| CString::new(d).ok());
        let ack = Arc::new(StartAck::new());
        let ack2 = ack.clone();
        let handle = thread::Builder::new()
            .name("caly-sink-pulse".into())
            .spawn(move || {
                let simple = open_simple(&dev_c, rate, ch_u8);
                if simple.is_null() {
                    ack2.fail("pa_simple_new failed");
                    return;
                }
                ack2.ready();
                let simple = Simple(simple);
                let silence = vec![0.0f32; quantum * ch];
                let mut scratch = vec![0.0f32; quantum * ch];
                while !stop2.load(Ordering::Acquire) {
                    let state = reader.shared().state();
                    match state {
                        StreamState::Stopped | StreamState::Stopping => break,
                        StreamState::Playing | StreamState::Draining => {
                            let n = reader.read(&mut scratch);
                            let bytes: &[u8] = if n > 0 {
                                reader.note_reported(n as u64);
                                as_bytes(&scratch[..n * ch])
                            } else if state == StreamState::Draining {
                                reader.note_finished();
                                as_bytes(&silence)
                            } else {
                                reader.note_underrun();
                                as_bytes(&silence)
                            };
                            if write_simple(simple.0, bytes).is_err() {
                                log::warn!("pulse: write failed: {}", pulse_error());
                                break;
                            }
                        }
                        StreamState::Paused => {
                            if write_simple(simple.0, as_bytes(&silence)).is_err() {
                                log::warn!("pulse: write(paused) failed: {}", pulse_error());
                                break;
                            }
                        }
                    }
                }
                unsafe {
                    libpulse_simple_sys::pa_simple_drain(simple.0, std::ptr::null_mut());
                    libpulse_simple_sys::pa_simple_free(simple.0);
                }
            })
            .map_err(|e| BackendError::State(format!("spawn: {e}")))?;
        self.thread = Some(handle);
        self.stop_flag = Some(stop);
        self.ack = Some(ack);
        Ok(())
    }
}

fn as_bytes(s: &[f32]) -> &[u8] {
    unsafe { std::slice::from_raw_parts(s.as_ptr() as *const u8, s.len() * 4) }
}

fn open_simple(dev: &Option<CString>, rate: u32, ch: u8) -> *mut libpulse_simple_sys::pa_simple {
    unsafe {
        let ss = pulse::sample::pa_sample_spec {
            format: pulse::sample::pa_sample_format_t::F32le,
            rate,
            channels: ch,
        };
        #[allow(clippy::cast_possible_truncation)]
        let mut map = pulse::channelmap::pa_channel_map {
            channels: ch,
            map: [pulse::channelmap::pa_channel_position_t::Invalid; 32],
        };
        let pos_fl = pulse::channelmap::pa_channel_position_t::FrontLeft;
        let pos_fr = pulse::channelmap::pa_channel_position_t::FrontRight;
        let pos_mono = pulse::channelmap::pa_channel_position_t::Mono;
        if ch == 1 {
            map.map[0] = pos_mono;
        } else {
            map.map[0] = pos_fl;
            map.map[1] = pos_fr;
        }
        let mut err: c_int = 0;
        let app_name = CString::new("caly").unwrap();
        let stream_title = CString::new("Caly playback").unwrap();
        libpulse_simple_sys::pa_simple_new(
            std::ptr::null(),
            app_name.as_ptr(),
            pulse::stream::pa_stream_direction_t::Playback,
            dev.as_ref().map_or(std::ptr::null(), |c| c.as_ptr()),
            stream_title.as_ptr(),
            &ss,
            &map,
            std::ptr::null(),
            &mut err,
        )
    }
}

fn write_simple(
    simple: *mut libpulse_simple_sys::pa_simple,
    bytes: &[u8],
) -> std::result::Result<(), ()> {
    let mut err: c_int = 0;
    let r = unsafe {
        libpulse_simple_sys::pa_simple_write(
            simple,
            bytes.as_ptr() as *const c_void,
            bytes.len(),
            &mut err,
        )
    };
    if r < 0 {
        Err(())
    } else {
        Ok(())
    }
}

fn pulse_error() -> String {
    "pa_simple op failed".to_string()
}

impl AudioBackend for PulseSink {
    fn info(&self) -> &BackendInfo {
        &INFO
    }
    fn start(&mut self, params: &StreamParams, reader: SinkReader) -> BackendResult<()> {
        self.stop()?;
        let device = self.device.clone();
        self.spawn(params, reader, &device)?;
        self.ack
            .as_ref()
            .ok_or_else(|| BackendError::State("no ack".into()))?
            .wait(std::time::Duration::from_secs(5))
    }
    fn pause(&mut self) -> BackendResult<()> {
        Ok(())
    }
    fn resume(&mut self) -> BackendResult<()> {
        Ok(())
    }
    fn stop(&mut self) -> BackendResult<()> {
        if let Some(s) = &self.stop_flag {
            s.store(true, Ordering::Release);
        }
        if let Some(h) = self.thread.take() {
            let _ = h.join();
        }
        self.stop_flag = None;
        self.ack = None;
        Ok(())
    }
}

impl Drop for PulseSink {
    fn drop(&mut self) {
        let _ = self.stop();
    }
}
