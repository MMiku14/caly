//! Live smoke test for the PipeWire backend.
use std::sync::atomic::Ordering;
use std::time::{Duration, Instant};
use caly_core::backend::{BackendFactory, EngineSink, OutputChannels, OutputConfig, StreamParams};

fn main() {
    let rate = 48000u32;
    let ch = 2u8;
    let frames_total = rate * 2;
    let (mut sink, reader) = EngineSink::new(frames_total as usize, ch);
    let mut buf = Vec::with_capacity((rate / 20) as usize * ch as usize);
    for i in 0..(rate / 20) {
        let s = (i as f32 * 2.0 * std::f32::consts::PI * 1000.0 / rate as f32).sin() * 0.4;
        buf.push(s);
        buf.push(s);
    }
    for _ in 0..20 {
        sink.write(&buf, ch);
    }
    let shared = sink.shared().clone();
    shared.state.store(
        caly_core::backend::StreamState::Playing as u8,
        Ordering::Release,
    );
    println!("ring prefilled: {} frames", sink.total_written());
    let factory = caly_sink_pipewire::PipewireFactory;
    let config = OutputConfig {
        backend: Some("pipewire".into()),
        device: None,
        ..Default::default()
    };
    let mut backend = factory.create(&config).expect("create");
    assert_eq!(backend.info().id, "pipewire");
    let params = StreamParams {
        sample_rate: rate,
        channels: OutputChannels::Stereo.count(),
        layout: OutputChannels::Stereo.layout(),
        buffer_frames: frames_total as usize,
        stream_name: "caly-smoke",
    };
    backend.start(&params, reader).expect("start");
    let deadline = Instant::now() + Duration::from_secs(5);
    let mut reported = 0u64;
    while Instant::now() < deadline {
        reported = shared.reported_total.load(Ordering::Acquire);
        let under = shared.underruns.load(Ordering::Relaxed);
        println!(
            "reported={reported} underruns={under} state={:?}",
            shared.state()
        );
        if reported > 0 {
            break;
        }
        std::thread::sleep(Duration::from_millis(200));
    }
    backend.stop().expect("stop");
    println!(
        "SMOKE {}: reported {} frames, state {:?}",
        if reported > 0 { "OK" } else { "FAIL" },
        reported,
        shared.state()
    );
    std::process::exit(if reported > 0 { 0 } else { 1 });
}
