//! The classic pipeline API.
pub use crate::graph::FlushState;
use crate::audio::AudioBuffer;
use crate::graph::AudioGraph;
use crate::media::SampleRate;
use crate::CalyError;

/// Turns variable-length decoded chunks into fixed-form output frames for the sink.
pub struct Pipeline {
    graph: AudioGraph,
}

impl Pipeline {
    /// Creates a pipeline.
    pub fn new(output_rate: SampleRate, output_channels: usize) -> Result<Self, CalyError> {
        Ok(Self {
            graph: AudioGraph::new(output_rate, output_channels)?,
        })
    }

    /// Human-readable configuration.
    pub fn describe(&self) -> String {
        self.graph.describe()
    }

    /// Sets the output gain.
    pub fn set_gain_linear(&mut self, gain: f32, ramp_ms: u32) {
        self.graph.set_gain_linear(gain, ramp_ms);
    }

    /// Current gain.
    pub fn gain(&self) -> f32 {
        self.graph.gain()
    }

    /// Resets transient state.
    pub fn reset(&mut self) {
        self.graph.reset();
    }

    /// Processes a decoded chunk.
    pub fn process(&mut self, input: &AudioBuffer) -> Result<&[f32], CalyError> {
        self.graph.process(input)
    }

    /// Flushes pending input.
    pub fn flush(&mut self) -> Result<FlushState, CalyError> {
        self.graph.flush()
    }

    /// Takes ownership of the last flush output.
    pub fn take_flush_output(&mut self) -> Vec<f32> {
        self.graph.take_flush_output()
    }
}
