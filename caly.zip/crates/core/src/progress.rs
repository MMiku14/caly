//! Playback position / duration bookkeeping.
use std::fmt;
use std::time::Duration;

/// Position and duration of the current track in wall-clock time.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub struct Progress {
    /// Playback position.
    pub position: Duration,
    /// Total duration.
    pub duration: Option<Duration>,
}

impl Progress {
    /// Creates a progress value.
    pub fn new(position: Duration, duration: Option<Duration>) -> Self {
        Self { position, duration }
    }

    /// Remaining time.
    pub fn remaining(&self) -> Option<Duration> {
        self.duration.and_then(|d| d.checked_sub(self.position))
    }

    /// Progress in `0.0..=1.0`.
    pub fn ratio(&self) -> f32 {
        match self.duration {
            Some(d) if !d.is_zero() => {
                (self.position.as_secs_f64() / d.as_secs_f64()).clamp(0.0, 1.0) as f32
            }
            _ => 0.0,
        }
    }

    /// `true` when the stream has a finite known duration.
    pub fn is_finite(&self) -> bool {
        self.duration.map(|d| !d.is_zero()).unwrap_or(false)
    }
}

impl Default for Progress {
    fn default() -> Self {
        Progress::new(Duration::ZERO, None)
    }
}

/// Formats a duration as `m:ss` or `h:mm:ss`.
pub fn format_time(d: Duration) -> String {
    let total = d.as_secs();
    let h = total / 3600;
    let m = (total % 3600) / 60;
    let s = total % 60;
    if h > 0 {
        format!("{h}:{m:02}:{s:02}")
    } else {
        format!("{m}:{s:02}")
    }
}

/// Formats a progress pair like `1:23 / 4:56`.
pub fn format_progress(p: &Progress) -> String {
    match p.duration {
        Some(d) => format!("{} / {}", format_time(p.position), format_time(d)),
        None => format!("{} / --:--", format_time(p.position)),
    }
}

impl fmt::Display for Progress {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(f, "{}", format_progress(self))
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn progress_math() {
        let p = Progress::new(Duration::from_secs(90), Some(Duration::from_secs(180)));
        assert_eq!(p.remaining(), Some(Duration::from_secs(90)));
        assert!((p.ratio() - 0.5).abs() < 1e-6);
    }
}
