//! `caly-core` - the heart of Caly.
#![forbid(unsafe_code)]
#![warn(missing_docs, rust_2018_idioms, unused_lifetimes)]

pub mod audio;
pub mod backend;
pub mod error;
pub mod flow;
pub mod gain;
pub mod graph;
pub mod media;
pub mod mix;
pub mod pipeline;
pub mod progress;
pub mod queue;
pub mod resample;
pub mod source;
pub mod stream;
pub mod transport;

pub use audio::AudioBuffer;
pub use backend::{
    AudioBackend, BackendError, BackendFactory, BackendId, BackendInfo, EngineSink, OutputChannels,
    OutputConfig, SinkReader, SinkShared, StartAck, StreamParams, StreamState,
};
pub use error::{CalyError, Result};
pub use flow::{AudioFlow, Fidelity, FlowStep, SignalFlow};
pub use graph::{AudioGraph, AudioNode, Chain, FlushState};
pub use media::{ChannelLayout, Channels, SampleFormat, SampleRate};
pub use progress::Progress;
pub use queue::{Queue, QueueError, RepeatMode, Track};
pub use source::{ProbeInfo, SourceBackend, SourceError, SourceFactory, StreamInfo, TrackMeta};
pub use transport::{Transport, TransportError, TransportFactory, TransportKind};
