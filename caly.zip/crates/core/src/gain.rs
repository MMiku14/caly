//! Click-free gain ramping (sample-accurate, per-frame linear ramp).

/// Linear-gain smoother with a per-frame interpolation step.
#[derive(Debug, Clone)]
pub struct GainSmoother {
    target: f32,
    gain: f32,
    step: f32,
    frames_remaining: usize,
}

impl GainSmoother {
    /// Creates a smoother starting already at `gain`.
    pub fn new(gain: f32) -> Self {
        Self {
            target: gain.clamp(0.0, 4.0),
            gain: gain.clamp(0.0, 4.0),
            step: 0.0,
            frames_remaining: 0,
        }
    }

    /// Current instantaneous gain.
    pub fn current(&self) -> f32 {
        self.gain
    }

    /// Target gain.
    pub fn target(&self) -> f32 {
        self.target
    }

    /// Begins a ramp from the current gain to `target` over `ramp_frames` frames.
    pub fn set_target(&mut self, target: f32, ramp_frames: usize) {
        let target = target.clamp(0.0, 4.0);
        if ramp_frames == 0 || (self.gain - target).abs() < 1e-9 {
            self.gain = target;
            self.target = target;
            self.step = 0.0;
            self.frames_remaining = 0;
            return;
        }
        self.step = (target - self.gain) / ramp_frames as f32;
        self.target = target;
        self.frames_remaining = ramp_frames;
    }

    /// Applies the ramp to a block of interleaved samples with the given channel count.
    pub fn apply_interleaved(&mut self, samples: &mut [f32], channels: usize) {
        if channels == 0 || samples.is_empty() {
            return;
        }
        if self.frames_remaining == 0 {
            if self.gain != 1.0 {
                for s in samples.iter_mut() {
                    *s *= self.gain;
                }
            }
            return;
        }
        for frame in samples.chunks_exact_mut(channels) {
            for s in frame.iter_mut() {
                *s *= self.gain;
            }
            if self.frames_remaining > 0 {
                self.gain += self.step;
                self.frames_remaining -= 1;
                if self.frames_remaining == 0 {
                    self.gain = self.target;
                }
            }
        }
    }

    /// Backward-compatible single-channel/interleaved apply.
    pub fn apply(&mut self, samples: &mut [f32]) {
        self.apply_interleaved(samples, 1);
    }
}

/// Converts a volume in decibels to linear gain.
pub fn db_to_linear(db: f32) -> f32 {
    if db <= f32::NEG_INFINITY || db < -120.0 {
        return 0.0;
    }
    10f32.powf(db / 20.0)
}

/// Converts linear gain to decibels.
pub fn linear_to_db(v: f32) -> f32 {
    if v <= 0.0 {
        return f32::NEG_INFINITY;
    }
    20.0 * v.log10()
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn ramps_linearly() {
        let mut g = GainSmoother::new(0.0);
        g.set_target(1.0, 4);
        let mut block = [1.0f32; 4];
        g.apply(&mut block);
        assert_eq!(block, [0.0, 0.25, 0.5, 0.75]);
        assert_eq!(g.current(), 1.0);
        let mut block2 = [1.0f32; 2];
        g.apply(&mut block2);
        assert_eq!(block2, [1.0, 1.0]);
    }

    #[test]
    fn ramps_stereo_interleaved() {
        let mut g = GainSmoother::new(0.0);
        g.set_target(1.0, 2); // 2 frames
        let mut block = [1.0f32; 4]; // 2 frames * 2 channels
        g.apply_interleaved(&mut block, 2);
        assert_eq!(block, [0.0, 0.0, 0.5, 0.5]);
        assert_eq!(g.current(), 1.0);
    }

    #[test]
    fn instant_set() {
        let mut g = GainSmoother::new(1.0);
        g.set_target(0.5, 0);
        assert_eq!(g.current(), 0.5);
        let mut b = [1.0f32; 3];
        g.apply(&mut b);
        assert_eq!(b, [0.5, 0.5, 0.5]);
    }

    #[test]
    fn db_roundtrip() {
        let db = -6.0;
        let lin = db_to_linear(db);
        assert!((linear_to_db(lin) - db).abs() < 1e-3);
    }
}
