//! The **output** layer: [`AudioBackend`] and the lock-free [`EngineSink`]
//! bridge between the engine thread and the audio-device callback.
use std::fmt;
use std::sync::atomic::{AtomicBool, AtomicU64, AtomicU8, Ordering};
use std::sync::{Arc, Condvar, Mutex};
use crate::media::{ChannelLayout, Channels, SampleRate};

/// Unique id of a registered backend, e.g. `"pipewire"`.
pub type BackendId = &'static str;

/// Playback state communicated from the engine to the backend thread.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
#[repr(u8)]
pub enum StreamState {
    /// No stream active.
    Stopped = 0,
    /// Engine expects the device to be fed; the ring may briefly underrun.
    Playing = 1,
    /// Device keeps its clock but plays silence; ring is preserved.
    Paused = 2,
    /// Engine stopped feeding: play out remaining frames, then signal
    /// [`SinkShared::finished`] when the ring has been drained.
    Draining = 3,
    /// Engine wants the stream torn down immediately.
    Stopping = 4,
}

impl StreamState {
    /// Decodes from the raw atomic representation.
    pub fn from_u8(v: u8) -> Self {
        match v {
            1 => StreamState::Playing,
            2 => StreamState::Paused,
            3 => StreamState::Draining,
            4 => StreamState::Stopping,
            _ => StreamState::Stopped,
        }
    }
}

impl fmt::Display for StreamState {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        let s = match self {
            StreamState::Stopped => "stopped",
            StreamState::Playing => "playing",
            StreamState::Paused => "paused",
            StreamState::Draining => "draining",
            StreamState::Stopping => "stopping",
        };
        write!(f, "{s}")
    }
}

/// Target channel layout of an output stream.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum OutputChannels {
    /// Single-channel output.
    Mono,
    /// Two-channel output (the default).
    Stereo,
}

impl OutputChannels {
    /// Channel count.
    pub fn count(self) -> Channels {
        match self {
            OutputChannels::Mono => Channels::MONO,
            OutputChannels::Stereo => Channels::STEREO,
        }
    }

    /// Canonical layout for this configuration.
    pub fn layout(self) -> ChannelLayout {
        match self {
            OutputChannels::Mono => ChannelLayout::MONO,
            OutputChannels::Stereo => ChannelLayout::STEREO,
        }
    }
}

impl fmt::Display for OutputChannels {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(f, "{self:?}")
    }
}

/// Everything needed to open an output stream: negotiated by the engine.
#[derive(Debug, Clone, Copy)]
pub struct StreamParams {
    /// Sample rate after resampling.
    pub sample_rate: SampleRate,
    /// Channel count after mixing.
    pub channels: Channels,
    /// Layout of the mixed stream.
    pub layout: ChannelLayout,
    /// Ring capacity in frames (the backend's max "ahead" distance).
    pub buffer_frames: usize,
    /// Human-readable stream name (shown in e.g. `pw-top`).
    pub stream_name: &'static str,
}

/// Output configuration (device selection, format negotiation hints).
#[derive(Debug, Clone)]
pub struct OutputConfig {
    /// Desired backend id, or `None` for automatic selection.
    pub backend: Option<String>,
    /// Device name (backend-specific), or `None` for default.
    pub device: Option<String>,
    /// Desired sample rate, or `None` for automatic.
    pub sample_rate: Option<SampleRate>,
    /// Desired channel layout.
    pub channels: OutputChannels,
    /// Ring capacity in milliseconds (clamped to a sane range).
    pub buffer_ms: u32,
    /// Desired device integer period in frames (0 = let the device choose).
    pub period_frames: u32,
}

impl Default for OutputConfig {
    fn default() -> Self {
        Self {
            backend: None,
            device: None,
            sample_rate: None,
            channels: OutputChannels::Stereo,
            buffer_ms: 500,
            period_frames: 0,
        }
    }
}

/// Static description of an [`AudioBackend`] implementation.
#[derive(Debug, Clone, Copy)]
pub struct BackendInfo {
    /// Stable id, e.g. `"pipewire"`.
    pub id: BackendId,
    /// Human-readable name.
    pub name: &'static str,
    /// One-line description.
    pub description: &'static str,
    /// Priority for automatic selection (higher wins).
    pub priority: i32,
    /// Resource this backend writes to.
    pub resource: &'static str,
}

/// Creates backend instances on demand.
pub trait BackendFactory: Send + Sync {
    /// Static info.
    fn info(&self) -> &BackendInfo;
    /// Creates a fresh backend instance (stateless until [`AudioBackend::start`]).
    fn create(&self, config: &OutputConfig) -> Result<Box<dyn AudioBackend>, BackendError>;
}

/// Result alias for output-backend operations.
pub type BackendResult<T> = std::result::Result<T, BackendError>;

/// Errors produced by output backends.
#[derive(Debug, thiserror::Error)]
pub enum BackendError {
    /// Could not connect to the audio server / open the device.
    #[error("connect failed: {0}")]
    Connect(String),
    /// A stream/latency parameter was rejected.
    #[error("stream failed: {0}")]
    Stream(String),
    /// A runtime failure in the device callback.
    #[error("callback error: {0}")]
    Callback(String),
    /// The backend was asked to start twice / stop when not running.
    #[error("state error: {0}")]
    State(String),
}

/// Startup handshake for backends that open their device **asynchronously**.
#[derive(Debug, Default)]
pub struct StartAck {
    state: Mutex<Option<Result<(), String>>>,
    cv: Condvar,
}

impl StartAck {
    /// Creates an unanswered ack.
    pub fn new() -> Self {
        Self::default()
    }

    /// Reports that the device is up and the backend may start pulling.
    pub fn ready(&self) {
        *self.state.lock().unwrap() = Some(Ok(()));
        self.cv.notify_all();
    }

    /// Reports that the device could not be opened.
    pub fn fail(&self, msg: impl Into<String>) {
        *self.state.lock().unwrap() = Some(Err(msg.into()));
        self.cv.notify_all();
    }

    /// Blocks until the writer thread reports, or `timeout` elapses.
    pub fn wait(&self, timeout: std::time::Duration) -> BackendResult<()> {
        let deadline = std::time::Instant::now() + timeout;
        let mut guard = self.state.lock().unwrap();
        loop {
            if let Some(res) = &*guard {
                return match res {
                    Ok(()) => Ok(()),
                    Err(e) => Err(BackendError::Connect(e.clone())),
                };
            }
            let now = std::time::Instant::now();
            if now >= deadline {
                return Err(BackendError::Stream(
                    "timed out waiting for device startup".into(),
                ));
            }
            let (g, _) = self
                .cv
                .wait_timeout(guard, deadline.saturating_duration_since(now))
                .unwrap();
            guard = g;
        }
    }
}

/// State shared between the engine-side writer and the device-side reader.
pub struct SinkShared {
    /// Current [`StreamState`].
    pub state: AtomicU8,
    /// Generation counter.
    pub generation: AtomicU64,
    /// Total frames the backend delivered to the device.
    pub reported_total: AtomicU64,
    /// Set by the backend once the ring drained after [`StreamState::Draining`].
    pub finished: AtomicBool,
    /// Cumulative underrun counter.
    pub underruns: AtomicU64,
}

impl SinkShared {
    fn new() -> Arc<Self> {
        Arc::new(Self {
            state: AtomicU8::new(StreamState::Stopped as u8),
            generation: AtomicU64::new(1),
            reported_total: AtomicU64::new(0),
            finished: AtomicBool::new(false),
            underruns: AtomicU64::new(0),
        })
    }

    /// Current state.
    pub fn state(&self) -> StreamState {
        StreamState::from_u8(self.state.load(Ordering::Acquire))
    }

    /// Current generation.
    pub fn generation(&self) -> u64 {
        self.generation.load(Ordering::Acquire)
    }

    /// No-op placeholder for backward compatibility.
    pub fn notify_reader(&self) {}
}

/// Writer side, owned by the engine thread.
pub struct EngineSink {
    shared: Arc<SinkShared>,
    writer: rtrb::Producer<f32>,
    channels: u8,
    capacity_frames: usize,
    total_written: u64,
}

impl EngineSink {
    /// Creates a ring with `capacity_frames` frames.
    pub fn new(capacity_frames: usize, channels: u8) -> (Self, super::SinkReader) {
        let shared = SinkShared::new();
        let samples = capacity_frames
            .checked_mul(channels as usize)
            .expect("ring capacity overflow");
        let (writer, reader) = rtrb::RingBuffer::<f32>::new(samples);
        let gen = shared.generation();
        (
            Self {
                shared: shared.clone(),
                writer,
                channels,
                capacity_frames,
                total_written: 0,
            },
            super::SinkReader {
                shared,
                reader,
                channels,
                seen_generation: gen,
            },
        )
    }

    /// Shared state (also reachable through the reader).
    pub fn shared(&self) -> &Arc<SinkShared> {
        &self.shared
    }

    /// Free capacity in frames.
    pub fn free_frames(&self) -> usize {
        self.writer.slots() / self.channels as usize
    }

    /// Cumulative frames written.
    pub fn total_written(&self) -> u64 {
        self.total_written
    }

    /// Ring capacity in frames.
    pub fn capacity_frames(&self) -> usize {
        self.capacity_frames
    }

    /// Non-blocking write of interleaved frames, ensuring whole-frame alignment.
    pub fn write(&mut self, interleaved: &[f32], channels: u8) -> usize {
        let ch = channels as usize;
        let max_frames = self.writer.slots() / ch;
        let available_frames = interleaved.len() / ch;
        let frames_to_write = available_frames.min(max_frames);
        let samples_to_write = frames_to_write * ch;

        if samples_to_write == 0 {
            return 0;
        }

        let (pushed, _) = self.writer.push_partial_slice(&interleaved[..samples_to_write]);
        let frames = pushed.len() / ch;
        self.total_written += frames as u64;
        self.shared.notify_reader();
        frames
    }

    /// Waits until at least `frames` frames can be written, or `timeout` elapses.
    pub fn wait_room(&self, frames: usize, timeout: std::time::Duration) -> bool {
        let needed_slots = frames * self.channels as usize;
        let start = std::time::Instant::now();
        while self.writer.slots() < needed_slots {
            if start.elapsed() >= timeout {
                return false;
            }
            std::thread::yield_now();
            if self.writer.slots() < needed_slots {
                std::thread::sleep(std::time::Duration::from_micros(500));
            }
        }
        true
    }

    /// Atomically marks the sink as a new generation (seek / track switch).
    pub fn bump_generation(&self) {
        self.shared.generation.fetch_add(1, Ordering::AcqRel);
    }
}

/// Reader side, owned by the backend's device callback thread.
pub struct SinkReader {
    shared: Arc<SinkShared>,
    reader: rtrb::Consumer<f32>,
    channels: u8,
    seen_generation: u64,
}

impl SinkReader {
    /// Number of channels of this stream.
    pub fn channels(&self) -> usize {
        self.channels as usize
    }

    /// Reads up to `dst.len()` samples worth of frames.
    pub fn read(&mut self, dst: &mut [f32]) -> usize {
        let gen = self.shared.generation();
        if gen != self.seen_generation {
            self.seen_generation = gen;
            loop {
                let (popped, _) = self.reader.pop_partial_slice(dst);
                if popped.is_empty() {
                    break;
                }
            }
        }
        let ch = self.channels as usize;
        let max_samples = (dst.len() / ch) * ch;
        if max_samples == 0 {
            return 0;
        }
        let (popped, _) = self.reader.pop_partial_slice(&mut dst[..max_samples]);
        popped.len() / ch
    }

    /// Total frames delivered so far.
    pub fn reported_total(&self) -> u64 {
        self.shared.reported_total.load(Ordering::Acquire)
    }

    /// Shared state.
    pub fn shared(&self) -> &Arc<SinkShared> {
        &self.shared
    }

    /// Shared state (mutable handle for the backend thread).
    pub fn shared_mut(&self) -> &Arc<SinkShared> {
        &self.shared
    }

    /// Marks `n` frames as delivered to the device.
    pub fn note_reported(&self, n: u64) {
        self.shared.reported_total.fetch_add(n, Ordering::Release);
    }

    /// Records one underrun.
    pub fn note_underrun(&self) {
        self.shared.underruns.fetch_add(1, Ordering::Relaxed);
    }

    /// Signals drain completion.
    pub fn note_finished(&self) {
        self.shared.finished.store(true, Ordering::Release);
    }
}

impl fmt::Debug for SinkReader {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("SinkReader")
            .field("generation", &self.seen_generation)
            .finish()
    }
}

/// The output-backend trait.
pub trait AudioBackend {
    /// Static info.
    fn info(&self) -> &BackendInfo;
    /// Opens the device/connection and starts a playback stream fed by `reader`.
    fn start(&mut self, params: &StreamParams, reader: SinkReader) -> BackendResult<()>;
    /// Pauses playback (device keeps running, outputs silence).
    fn pause(&mut self) -> BackendResult<()>;
    /// Resumes playback.
    fn resume(&mut self) -> BackendResult<()>;
    /// Stops the stream and releases the device.
    fn stop(&mut self) -> BackendResult<()>;
    /// Current backend latency estimate once started, in frames.
    fn latency_frames(&self) -> u32 {
        0
    }
}
