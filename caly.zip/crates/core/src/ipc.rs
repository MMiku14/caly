//! Lightweight UNIX domain socket IPC protocol between `calyd` daemon and `caly` client.

use std::io::{BufRead, BufReader, Write};
use std::os::unix::net::UnixStream;
use std::path::PathBuf;
use std::time::Duration;

/// Default socket path resolution ($XDG_RUNTIME_DIR/caly.sock or ~/.config/caly/caly.sock).
pub fn default_socket_path() -> PathBuf {
    if let Some(runtime_dir) = std::env::var_os("XDG_RUNTIME_DIR").filter(|v| !v.is_empty()) {
        return PathBuf::from(runtime_dir).join("caly.sock");
    }
    if let Some(home) = std::env::var_os("HOME").filter(|v| !v.is_empty()) {
        return PathBuf::from(home).join(".config").join("caly").join("caly.sock");
    }
    std::env::temp_dir().join("caly.sock")
}

/// Commands sent from client to daemon.
#[derive(Debug, Clone, PartialEq)]
pub enum IpcRequest {
    /// Resume or start playback.
    Play,
    /// Pause playback.
    Pause,
    /// Toggle play / pause.
    TogglePause,
    /// Stop playback.
    Stop,
    /// Advance to next track.
    Next,
    /// Return to previous track.
    Prev,
    /// Absolute seek in seconds.
    Seek(Duration),
    /// Set master volume (0.0 .. 2.0).
    SetVolume(f32),
    /// Relative volume change (-0.05 .. +0.05).
    AdjustVolume(f32),
    /// Enqueue tracks by file paths or URLs.
    Enqueue(Vec<String>),
    /// Jump to specific queue index (0-based).
    PlayIndex(usize),
    /// Clear entire queue.
    ClearQueue,
    /// Cycle repeat mode.
    ToggleRepeat,
    /// Toggle shuffle mode.
    ToggleShuffle,
    /// Query current playback telemetry and status.
    GetStatus,
    /// Query queue track list.
    GetQueue,
    /// Subscribe to continuous status broadcasts.
    Subscribe,
    /// Terminate daemon process.
    Shutdown,
    /// Health check ping.
    Ping,
}

impl IpcRequest {
    /// Formats command into a clean, newline-terminated line.
    pub fn to_line(&self) -> String {
        match self {
            Self::Play => "PLAY
".to_string(),
            Self::Pause => "PAUSE
".to_string(),
            Self::TogglePause => "TOGGLE
".to_string(),
            Self::Stop => "STOP
".to_string(),
            Self::Next => "NEXT
".to_string(),
            Self::Prev => "PREV
".to_string(),
            Self::Seek(d) => format!("SEEK {}
", d.as_secs_f64()),
            Self::SetVolume(v) => format!("VOLUME {}
", v),
            Self::AdjustVolume(v) => format!("VOLUMENUDGE {}
", v),
            Self::Enqueue(uris) => format!("ENQUEUE {}
", uris.join("	")),
            Self::PlayIndex(i) => format!("PLAYINDEX {}
", i),
            Self::ClearQueue => "CLEAR
".to_string(),
            Self::ToggleRepeat => "REPEAT
".to_string(),
            Self::ToggleShuffle => "SHUFFLE
".to_string(),
            Self::GetStatus => "STATUS
".to_string(),
            Self::GetQueue => "QUEUE
".to_string(),
            Self::Subscribe => "SUBSCRIBE
".to_string(),
            Self::Shutdown => "SHUTDOWN
".to_string(),
            Self::Ping => "PING
".to_string(),
        }
    }

    /// Parses command from a raw line.
    pub fn from_line(line: &str) -> Option<Self> {
        let trimmed = line.trim();
        let mut parts = trimmed.splitn(2, ' ');
        let cmd = parts.next()?.to_ascii_uppercase();
        let arg = parts.next().unwrap_or("").trim();

        match cmd.as_str() {
            "PLAY" => Some(Self::Play),
            "PAUSE" => Some(Self::Pause),
            "TOGGLE" => Some(Self::TogglePause),
            "STOP" => Some(Self::Stop),
            "NEXT" => Some(Self::Next),
            "PREV" => Some(Self::Prev),
            "SEEK" => {
                let secs = arg.parse::<f64>().ok()?;
                if secs.is_finite() && secs >= 0.0 {
                    Some(Self::Seek(Duration::from_secs_f64(secs)))
                } else {
                    None
                }
            }
            "VOLUME" => arg.parse::<f32>().ok().map(Self::SetVolume),
            "VOLUMENUDGE" => arg.parse::<f32>().ok().map(Self::AdjustVolume),
            "ENQUEUE" => {
                let uris = arg.split('	').filter(|s| !s.is_empty()).map(str::to_string).collect();
                Some(Self::Enqueue(uris))
            }
            "PLAYINDEX" => arg.parse::<usize>().ok().map(Self::PlayIndex),
            "CLEAR" => Some(Self::ClearQueue),
            "REPEAT" => Some(Self::ToggleRepeat),
            "SHUFFLE" => Some(Self::ToggleShuffle),
            "STATUS" => Some(Self::GetStatus),
            "QUEUE" => Some(Self::GetQueue),
            "SUBSCRIBE" => Some(Self::Subscribe),
            "SHUTDOWN" => Some(Self::Shutdown),
            "PING" => Some(Self::Ping),
            _ => None,
        }
    }
}

/// Daemon status response payload.
#[derive(Debug, Clone, PartialEq)]
pub struct DaemonStatus {
    pub state: String,
    pub title: String,
    pub artist: String,
    pub album: String,
    pub uri: String,
    pub elapsed_secs: f64,
    pub duration_secs: f64,
    pub volume: f32,
    pub repeat: String,
    pub shuffle: bool,
    pub is_bit_perfect: bool,
    pub queue_len: usize,
    pub queue_cursor: Option<usize>,
}

impl DaemonStatus {
    /// Serializes status into a single tab-separated line.
    pub fn to_line(&self) -> String {
        format!(
            "STATUS	{}	{}	{}	{}	{}	{}	{}	{}	{}	{}	{}	{}	{}
",
            self.state,
            self.title.replace('	', " "),
            self.artist.replace('	', " "),
            self.album.replace('	', " "),
            self.uri.replace('	', " "),
            self.elapsed_secs,
            self.duration_secs,
            self.volume,
            self.repeat,
            self.shuffle,
            self.is_bit_perfect,
            self.queue_len,
            self.queue_cursor.map(|c| c.to_string()).unwrap_or_default()
        )
    }

    /// Parses from a status line.
    pub fn from_line(line: &str) -> Option<Self> {
        let trimmed = line.trim_end_matches(['
', '
']);
        let parts: Vec<&str> = trimmed.split('	').collect();
        if parts.first()? != &"STATUS" || parts.len() < 14 {
            return None;
        }

        Some(Self {
            state: parts[1].to_string(),
            title: parts[2].to_string(),
            artist: parts[3].to_string(),
            album: parts[4].to_string(),
            uri: parts[5].to_string(),
            elapsed_secs: parts[6].parse().unwrap_or(0.0),
            duration_secs: parts[7].parse().unwrap_or(0.0),
            volume: parts[8].parse().unwrap_or(1.0),
            repeat: parts[9].to_string(),
            shuffle: parts[10].parse().unwrap_or(false),
            is_bit_perfect: parts[11].parse().unwrap_or(false),
            queue_len: parts[12].parse().unwrap_or(0),
            queue_cursor: parts[13].parse().ok(),
        })
    }
}

/// Synchronous IPC Client connection to `calyd`.
pub struct IpcClient {
    stream: UnixStream,
}

impl IpcClient {
    /// Connects to daemon socket.
    pub fn connect() -> std::io::Result<Self> {
        let path = default_socket_path();
        let stream = UnixStream::connect(&path)?;
        stream.set_read_timeout(Some(Duration::from_secs(3)))?;
        stream.set_write_timeout(Some(Duration::from_secs(3)))?;
        Ok(Self { stream })
    }

    /// Checks if daemon is actively responding.
    pub fn is_alive() -> bool {
        Self::connect().is_ok()
    }

    /// Sends a request and receives response line.
    pub fn send(&mut self, req: &IpcRequest) -> std::io::Result<String> {
        let line = req.to_line();
        self.stream.write_all(line.as_bytes())?;
        self.stream.flush()?;

        let mut reader = BufReader::new(&mut self.stream);
        let mut resp = String::new();
        reader.read_line(&mut resp)?;
        Ok(resp)
    }

    /// Queries parsed daemon status.
    pub fn status(&mut self) -> std::io::Result<Option<DaemonStatus>> {
        let resp = self.send(&IpcRequest::GetStatus)?;
        Ok(DaemonStatus::from_line(&resp))
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn ipc_request_roundtrip() {
        let requests = [
            IpcRequest::Play,
            IpcRequest::Pause,
            IpcRequest::TogglePause,
            IpcRequest::Stop,
            IpcRequest::Next,
            IpcRequest::Prev,
            IpcRequest::Seek(Duration::from_secs(45)),
            IpcRequest::SetVolume(1.2),
            IpcRequest::AdjustVolume(0.05),
            IpcRequest::Enqueue(vec!["/music/a.flac".into(), "/music/b.mp3".into()]),
            IpcRequest::PlayIndex(3),
            IpcRequest::ClearQueue,
            IpcRequest::ToggleRepeat,
            IpcRequest::ToggleShuffle,
            IpcRequest::GetStatus,
            IpcRequest::GetQueue,
            IpcRequest::Subscribe,
            IpcRequest::Shutdown,
            IpcRequest::Ping,
        ];

        for req in requests {
            let line = req.to_line();
            let parsed = IpcRequest::from_line(&line).expect("should parse");
            assert_eq!(req, parsed);
        }
    }

    #[test]
    fn ipc_status_roundtrip() {
        let st = DaemonStatus {
            state: "Playing".into(),
            title: "Test Track".into(),
            artist: "Test Artist".into(),
            album: "Test Album".into(),
            uri: "file:///a.flac".into(),
            elapsed_secs: 12.34,
            duration_secs: 180.0,
            volume: 0.85,
            repeat: "All".into(),
            shuffle: true,
            is_bit_perfect: true,
            queue_len: 10,
            queue_cursor: Some(2),
        };

        let line = st.to_line();
        let parsed = DaemonStatus::from_line(&line).expect("should parse status");
        assert_eq!(st, parsed);
    }

    #[test]
    fn rejects_invalid_seek_floats() {
        assert!(IpcRequest::from_line("SEEK -5").is_none());
        assert!(IpcRequest::from_line("SEEK NaN").is_none());
    }
}
