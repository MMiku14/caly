//! Unified high-fidelity audio flow pipeline facade.
//!
//! Exposes a structured, end-to-end signal flow:
//! `Source File -> Decoder (native rate/format) -> Resampler (algorithm, rate) -> Channel Matrix -> Gain -> Output (device, rate)`

use crate::audio::AudioBuffer;
use crate::gain::linear_to_db;
use crate::graph::{Chain, FlushState};
use crate::media::{ChannelLayout, SampleFormat, SampleRate};
use crate::source::StreamInfo;
use crate::CalyError;

/// Processing fidelity classification of the audio flow.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash, Default)]
pub enum Fidelity {
    /// Direct bit-exact passthrough from decoder to audio hardware (zero DSP alteration).
    #[default]
    BitPerfect,
    /// High fidelity with bit-depth or volume adjustment only; no sample rate conversion.
    HighFidelity,
    /// Sample rate conversion active (bandlimited Sinc resampler).
    Resampled,
    /// Channel downmixing or upmixing active.
    Mixed,
}

impl Fidelity {
    /// Display badge string.
    pub fn badge(&self) -> &'static str {
        match self {
            Fidelity::BitPerfect => "Bit-Perfect",
            Fidelity::HighFidelity => "Hi-Fi Direct",
            Fidelity::Resampled => "Resampled",
            Fidelity::Mixed => "Channel Mixed",
        }
    }
}

/// Detailed telemetry for one stage in the end-to-end signal flow.
#[derive(Debug, Clone, PartialEq, Eq, Default)]
pub struct FlowStep {
    /// Stage title, e.g. "File", "Decoder", "Resampler", "Mixer", "Gain", "Output".
    pub stage: &'static str,
    /// Processor or algorithm, e.g. "FLAC (libavcodec)", "Sinc 256-tap Blackman-Harris", "PipeWire".
    pub processor: String,
    /// Input parameters description, e.g. "44100 Hz, 2ch, 24-bit".
    pub input_spec: String,
    /// Output parameters description, e.g. "48000 Hz, 2ch, f32".
    pub output_spec: String,
    /// Whether this stage is in pure bit-perfect passthrough mode.
    pub is_passthrough: bool,
    /// Additional algorithmic or technical details.
    pub details: String,
}

/// The complete end-to-end signal flow chain from source file to hardware.
#[derive(Debug, Clone, PartialEq, Eq, Default)]
pub struct SignalFlow {
    /// Ordered processing stages: [File] -> [Decoder] -> [Resampler] -> [Mixer] -> [Gain] -> [Output].
    pub steps: Vec<FlowStep>,
    /// Whether the entire chain is 100% Bit-Perfect (zero alteration).
    pub is_bit_perfect: bool,
}

impl SignalFlow {
    /// Produces a compact arrow representation:
    /// e.g. "FLAC(44.1k/24b) ➔ Sinc(44.1k➔48k) ➔ Stereo(pass) ➔ Gain(0dB) ➔ PipeWire(48k)"
    pub fn arrow_summary(&self) -> String {
        if self.steps.is_empty() {
            return "Idle".to_string();
        }
        self.steps
            .iter()
            .map(|s| {
                if s.is_passthrough {
                    format!("{}(pass)", s.stage)
                } else {
                    format!("{}({})", s.stage, s.processor)
                }
            })
            .collect::<Vec<_>>()
            .join(" ➔ ")
    }

    /// Single-line concise path for status line.
    pub fn concise_path(&self) -> String {
        if self.is_bit_perfect {
            "Bit-Perfect Direct".to_string()
        } else {
            let active_dsps: Vec<&str> = self
                .steps
                .iter()
                .filter(|s| !s.is_passthrough && s.stage != "Source" && s.stage != "Output")
                .map(|s| s.stage)
                .collect();
            if active_dsps.is_empty() {
                "Hi-Fi Direct".to_string()
            } else {
                format!("DSP: {}", active_dsps.join(" + "))
            }
        }
    }
}

/// The unified high-fidelity audio flow processing facade.
pub struct AudioFlow {
    /// Target output sample rate.
    pub output_rate: SampleRate,
    /// Target output channel count.
    pub output_channels: usize,
    chain: Chain,
    stage_out: AudioBuffer,
    out: Vec<f32>,
    flushed: bool,
    last_input_rate: SampleRate,
    last_input_channels: usize,
    last_input_layout: ChannelLayout,
    last_input_format: SampleFormat,
}

impl AudioFlow {
    /// Assembles an audio flow for the given output configuration.
    pub fn new(output_rate: SampleRate, output_channels: usize) -> Result<Self, CalyError> {
        let chain = Chain::new(output_rate, output_channels)?;
        let stage_out = AudioBuffer::new(
            crate::media::Channels::new(output_channels as u8)?,
            output_rate,
            crate::media::ChannelLayout::STEREO,
            4096,
        );
        Ok(Self {
            output_rate,
            output_channels,
            chain,
            stage_out,
            out: Vec::new(),
            flushed: false,
            last_input_rate: output_rate,
            last_input_channels: output_channels,
            last_input_layout: ChannelLayout::STEREO,
            last_input_format: SampleFormat::F32,
        })
    }

    /// Human-readable configuration.
    pub fn describe(&self) -> String {
        format!("{} Hz, {}ch [Hi-Fi Flow]", self.output_rate, self.output_channels)
    }

    /// Sets the output gain (linear) with a ramp.
    pub fn set_gain_linear(&mut self, gain: f32, ramp_ms: u32) {
        self.chain.set_gain_linear(gain, ramp_ms);
    }

    /// Current target gain.
    pub fn gain(&self) -> f32 {
        self.chain.gain()
    }

    /// Resets transient state.
    pub fn reset(&mut self) {
        self.chain.reset();
        self.out.clear();
        self.flushed = false;
    }

    /// Processes a decoded audio chunk with automatic Bit-Perfect bypass detection.
    pub fn process(&mut self, input: &AudioBuffer) -> Result<&[f32], CalyError> {
        self.flushed = false;
        self.last_input_rate = input.sample_rate;
        self.last_input_channels = input.channels.get() as usize;
        self.last_input_layout = input.layout;

        let is_rate_match = input.sample_rate == self.output_rate;
        let is_ch_match = input.channels.get() as usize == self.output_channels;
        let is_unity_gain = (self.gain() - 1.0).abs() < 1e-6;

        // Bit-Perfect Fast-Path: when sample rate matches, channels match, and gain is unity,
        // copy raw samples directly without touching resampler or mixer matrices!
        if is_rate_match && is_ch_match && is_unity_gain {
            self.out.clear();
            self.out.extend_from_slice(&input.samples);
            return Ok(&self.out);
        }

        // Standard DSP pipeline processing (zero heap allocation steady-state)
        self.chain.process(input, &mut self.stage_out)?;
        self.out.clear();
        self.out.extend_from_slice(&self.stage_out.samples);
        Ok(&self.out)
    }

    /// Flushes pending input at end of stream.
    pub fn flush(&mut self) -> Result<FlushState, CalyError> {
        if self.flushed {
            return Ok(FlushState::Drained);
        }
        self.flushed = true;
        match self.chain.flush(&mut self.stage_out)? {
            Some(()) => {
                self.out.clear();
                self.out.extend_from_slice(&self.stage_out.samples);
                Ok(FlushState::Produced)
            }
            None => Ok(FlushState::Drained),
        }
    }

    /// Takes ownership of the last flush output.
    pub fn take_flush_output(&mut self) -> Vec<f32> {
        std::mem::take(&mut self.out)
    }

    /// Builds a full end-to-end `SignalFlow` from file to soundcard device.
    pub fn build_signal_flow(
        &self,
        uri: &str,
        decoder_id: &str,
        stream_info: Option<&StreamInfo>,
        backend_id: &str,
        backend_resource: &str,
    ) -> SignalFlow {
        let (in_rate, in_ch, layout, format_str) = match stream_info {
            Some(info) => (
                info.sample_rate,
                info.channels.get() as usize,
                info.layout,
                format!("{:?}", info.format),
            ),
            None => (
                self.last_input_rate,
                self.last_input_channels,
                self.last_input_layout,
                format!("{:?}", self.last_input_format),
            ),
        };

        let out_rate = self.output_rate;
        let out_ch = self.output_channels;
        let gain = self.gain();

        let is_rate_match = in_rate == out_rate;
        let is_ch_match = in_ch == out_ch;
        let is_unity_gain = (gain - 1.0).abs() < 1e-6;
        let is_bit_perfect = is_rate_match && is_ch_match && is_unity_gain;

        let filename = uri.rsplit('/').next().unwrap_or(uri);

        let steps = vec![
            FlowStep {
                stage: "Source",
                processor: if uri.starts_with("http") { "HTTP Stream" } else { "Local File" }.into(),
                input_spec: filename.to_string(),
                output_spec: "Raw Bytes".into(),
                is_passthrough: true,
                details: format!("URI: {uri}"),
            },
            FlowStep {
                stage: "Decoder",
                processor: format!("{decoder_id} engine"),
                input_spec: "Compressed / Container".into(),
                output_spec: format!("{in_rate} Hz, {in_ch}ch, {format_str}"),
                is_passthrough: true,
                details: "Lossless / High-fidelity decoding into canonical f32".into(),
            },
            FlowStep {
                stage: "Resampler",
                processor: if is_rate_match {
                    "Bit-Perfect Passthrough".into()
                } else {
                    "Bandlimited Sinc (256-tap, Blackman-Harris 2)".into()
                },
                input_spec: format!("{in_rate} Hz"),
                output_spec: format!("{out_rate} Hz"),
                is_passthrough: is_rate_match,
                details: if is_rate_match {
                    "Exact rate match: Zero interpolation / zero phase distortion".into()
                } else {
                    format!(
                        "Ratio: {:.4}x, Cutoff: 0.96 Nyquist, Stopband: -100 dB",
                        out_rate as f64 / in_rate as f64
                    )
                },
            },
            FlowStep {
                stage: "Channel Matrix",
                processor: if is_ch_match {
                    "Bit-Perfect Passthrough".into()
                } else {
                    "ITU-R BS.775 Equal-Power Downmix".into()
                },
                input_spec: format!("{in_ch}ch (layout 0x{:04x})", layout.mask()),
                output_spec: format!("{out_ch}ch"),
                is_passthrough: is_ch_match,
                details: if is_ch_match {
                    "Direct 1:1 channel mapping (zero arithmetic error)".into()
                } else {
                    "Headroom-safe matrix downmix (L=1.0, R=1.0, C=0.7071, S=0.5)".into()
                },
            },
            FlowStep {
                stage: "Gain & Volume",
                processor: if is_unity_gain {
                    "Unity Gain (Bit-Perfect)".into()
                } else {
                    "Linear Frame Smoother".into()
                },
                input_spec: "Interleaved f32".into(),
                output_spec: "Interleaved f32".into(),
                is_passthrough: is_unity_gain,
                details: if is_unity_gain {
                    "0.0 dB (100% volume, zero multiplication)".into()
                } else {
                    format!("{:.1} dB ({:.0}% linear)", linear_to_db(gain), gain * 100.0)
                },
            },
            FlowStep {
                stage: "Audio Output",
                processor: format!("{backend_id} ({backend_resource})"),
                input_spec: format!("{out_rate} Hz, {out_ch}ch"),
                output_spec: format!("{backend_resource} ({out_rate} Hz)"),
                is_passthrough: true,
                details: "Wait-free SPSC lock-free ringbuffer device delivery".into(),
            },
        ];

        SignalFlow {
            steps,
            is_bit_perfect,
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::media::Channels;

    #[test]
    fn bit_perfect_flow_built() {
        let mut flow = AudioFlow::new(48000, 2).unwrap();
        flow.set_gain_linear(1.0, 0);

        let buf = AudioBuffer::new(Channels::STEREO, 48000, ChannelLayout::STEREO, 128);
        let _ = flow.process(&buf).unwrap();

        let sig = flow.build_signal_flow("file:///music/test.flac", "ffmpeg", None, "pipewire", "PipeWire Server");
        assert!(sig.is_bit_perfect);
        assert_eq!(sig.steps.len(), 6);
        assert!(sig.steps[2].is_passthrough); // Resampler
        assert!(sig.steps[3].is_passthrough); // Mixer
        assert!(sig.steps[4].is_passthrough); // Gain
    }
}
