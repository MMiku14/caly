//! [`StreamInfo`] helpers.
use crate::media::{Channels, SampleFormat, SampleRate};
use crate::source::StreamInfo;

impl StreamInfo {
    /// Creates a [`StreamInfo`] with a default layout derived from the channel count.
    pub fn with_default_layout(
        sample_rate: SampleRate,
        channels: Channels,
        format: SampleFormat,
    ) -> Self {
        Self {
            sample_rate,
            channels,
            layout: crate::media::default_layout_for(channels),
            format,
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn defaults_are_sane() {
        let info = StreamInfo::with_default_layout(44100, Channels::STEREO, SampleFormat::F32);
        assert_eq!(info.channels, Channels::STEREO);
        assert_eq!(info.layout.count(), 2);
    }
}
