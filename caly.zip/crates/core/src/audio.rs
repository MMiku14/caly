//! The canonical [`AudioBuffer`]: interleaved `f32`, plane conversion helpers.
use crate::media::{ChannelLayout, Channels, SampleRate};

/// An interleaved, `f32`, canonical-order audio block.
#[derive(Debug, Clone, PartialEq)]
pub struct AudioBuffer {
    /// Number of channels (`>= 1`).
    pub channels: Channels,
    /// Sample rate of the samples.
    pub sample_rate: SampleRate,
    /// Channel layout in canonical (ascending mask) order.
    pub layout: ChannelLayout,
    /// Interleaved samples, length is a strict multiple of `channels`.
    pub samples: Vec<f32>,
}

impl AudioBuffer {
    /// Creates an empty buffer with the given capacity (in frames), zero-filled.
    pub fn new(
        channels: Channels,
        sample_rate: SampleRate,
        layout: ChannelLayout,
        capacity_frames: usize,
    ) -> Self {
        Self {
            channels,
            sample_rate,
            layout,
            samples: vec![0.0; capacity_frames * channels.get() as usize],
        }
    }

    /// Creates a buffer holding `fill` frames of silence (no spare capacity).
    pub fn silence(
        channels: Channels,
        sample_rate: SampleRate,
        layout: ChannelLayout,
        fill_frames: usize,
    ) -> Self {
        Self::new(channels, sample_rate, layout, fill_frames)
    }

    /// Number of complete frames.
    pub fn frames(&self) -> usize {
        self.samples.len() / self.channels.get() as usize
    }

    /// `true` when there are no complete frames.
    pub fn is_empty(&self) -> bool {
        self.samples.is_empty()
    }

    /// Removes all samples.
    pub fn clear(&mut self) {
        self.samples.clear();
    }

    /// Appends a single frame.
    pub fn push_frame(&mut self, frame: &[f32]) {
        debug_assert_eq!(frame.len(), self.channels.get() as usize);
        self.samples.extend_from_slice(frame);
    }

    /// Appends interleaved samples (must contain whole frames).
    pub fn extend_from_slice(&mut self, interleaved: &[f32]) {
        debug_assert_eq!(interleaved.len() % self.channels.get() as usize, 0);
        self.samples.extend_from_slice(interleaved);
    }

    /// Appends `n` frames of silence.
    pub fn push_silence(&mut self, n: usize) {
        self.samples
            .resize(self.samples.len() + n * self.channels.get() as usize, 0.0);
    }

    /// Truncates to `n` frames.
    pub fn truncate_frames(&mut self, n: usize) {
        let end = n * self.channels.get() as usize;
        self.samples.truncate(end);
    }

    /// Removes and returns the first `n` frames, leaving the rest in `self`.
    pub fn split_off_frames(&mut self, n: usize) -> Self {
        let cut = n * self.channels.get() as usize;
        let samples = self.samples.split_off(cut);
        let rest = std::mem::replace(&mut self.samples, samples);
        AudioBuffer {
            channels: self.channels,
            sample_rate: self.sample_rate,
            layout: self.layout,
            samples: rest,
        }
    }

    /// Interleaved view of the whole buffer.
    pub fn interleaved(&self) -> &[f32] {
        &self.samples
    }

    /// Decodes the buffer into planar vectors (reusing `scratch` capacity).
    pub fn deinterleave_into(&self, scratch: &mut Vec<Vec<f32>>) {
        let ch = self.channels.get() as usize;
        scratch.clear();
        scratch.resize_with(ch, Vec::new);
        for (i, plane) in scratch.iter_mut().enumerate() {
            plane.extend(self.samples.iter().skip(i).step_by(ch).copied());
        }
    }

    /// Creates an interleaved buffer from planar data.
    pub fn from_planes(
        channels: Channels,
        sample_rate: SampleRate,
        layout: ChannelLayout,
        planes: &[Vec<f32>],
    ) -> Self {
        let ch = channels.get() as usize;
        debug_assert_eq!(planes.len(), ch);
        let frames = planes.first().map(|p| p.len()).unwrap_or(0);
        let mut samples = Vec::with_capacity(frames * ch);
        for f in 0..frames {
            for p in planes {
                samples.push(p[f]);
            }
        }
        Self {
            channels,
            sample_rate,
            layout,
            samples,
        }
    }
}

/// Converts any supported PCM sample format into interleaved `f32` samples.
pub fn convert_to_f32(input: &[u8], format: crate::media::SampleFormat) -> Vec<f32> {
    use crate::media::SampleFormat::*;
    match format {
        U8 => input.iter().map(|b| (*b as f32 - 128.0) / 128.0).collect(),
        S16 => input
            .chunks_exact(2)
            .map(|c| i16::from_le_bytes([c[0], c[1]]) as f32 / 32768.0)
            .collect(),
        S24 => input
            .chunks_exact(3)
            .map(|c| {
                let v = (i32::from(c[0])) | (i32::from(c[1]) << 8) | (i32::from(c[2]) << 16);
                let v = (v << 8) >> 8;
                v as f32 / 8_388_608.0
            })
            .collect(),
        S32 => input
            .chunks_exact(4)
            .map(|c| i32::from_le_bytes([c[0], c[1], c[2], c[3]]) as f32 / 2_147_483_648.0)
            .collect(),
        F32 => input
            .chunks_exact(4)
            .map(|c| f32::from_le_bytes([c[0], c[1], c[2], c[3]]))
            .collect(),
        F64 => input
            .chunks_exact(8)
            .map(|c| f64::from_le_bytes(c.try_into().unwrap()) as f32)
            .collect(),
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::media::SampleFormat;

    #[test]
    fn buffer_frame_ops() {
        let mut b = AudioBuffer::new(Channels::STEREO, 48000, ChannelLayout::STEREO, 0);
        b.push_frame(&[0.5, -0.5]);
        b.push_frame(&[0.25, -0.25]);
        assert_eq!(b.frames(), 2);
        let head = b.split_off_frames(1);
        assert_eq!(head.samples, vec![0.5, -0.5]);
        assert_eq!(b.samples, vec![0.25, -0.25]);
        b.push_silence(3);
        assert_eq!(b.frames(), 4);
    }

    #[test]
    fn s16_conversion() {
        let raw = [0x00u8, 0x80, 0x00, 0x40]; // -32768, 16384
        let v = convert_to_f32(&raw, SampleFormat::S16);
        assert_eq!(v, vec![-1.0, 0.5]);
    }

    #[test]
    fn planes_roundtrip() {
        let mut b = AudioBuffer::new(Channels::STEREO, 44100, ChannelLayout::STEREO, 0);
        b.extend_from_slice(&[0.0, 1.0, 2.0, 3.0, 4.0, 5.0]);
        let mut scratch = Vec::new();
        b.deinterleave_into(&mut scratch);
        assert_eq!(scratch[0], vec![0.0, 2.0, 4.0]);
        assert_eq!(scratch[1], vec![1.0, 3.0, 5.0]);
        let rt = AudioBuffer::from_planes(Channels::STEREO, 44100, ChannelLayout::STEREO, &scratch);
        assert_eq!(rt, b);
    }
}
