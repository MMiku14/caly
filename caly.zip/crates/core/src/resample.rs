//! Sinc-based sample-rate conversion (built on `rubato`).
use rubato::{
    Resampler as _, SincFixedIn, SincInterpolationParameters, SincInterpolationType, WindowFunction,
};
use crate::media::SampleRate;
use crate::CalyError;

/// Frames per chunk fed to the converter.
pub const RESAMPLE_CHUNK_FRAMES: usize = 1024;

/// A sample-rate converter for a fixed ratio.
pub struct Resampler {
    inner: SincFixedIn<f32>,
    /// Input sample rate.
    pub input_rate: SampleRate,
    /// Output sample rate.
    pub output_rate: SampleRate,
    /// Channel count.
    pub channels: usize,
    /// Filter latency in output frames.
    delay_frames: usize,
    planes: Vec<Vec<f32>>,
    out_planes: Vec<Vec<f32>>,
}

impl Resampler {
    /// Creates a resampler.
    pub fn new(
        input_rate: SampleRate,
        output_rate: SampleRate,
        channels: u8,
    ) -> Result<Self, CalyError> {
        if input_rate == 0 || output_rate == 0 {
            return Err(CalyError::Config("resampler rates must be non-zero".into()));
        }
        if input_rate == output_rate {
            return Err(CalyError::Config(
                "resampler constructed for identical rates".into(),
            ));
        }
        let ratio = output_rate as f64 / input_rate as f64;
        let params = SincInterpolationParameters {
            sinc_len: 256,
            f_cutoff: 0.95,
            interpolation: SincInterpolationType::Cubic,
            oversampling_factor: 256,
            window: WindowFunction::BlackmanHarris2,
        };
        let inner = SincFixedIn::<f32>::new(
            ratio,
            1.0,
            params,
            RESAMPLE_CHUNK_FRAMES,
            channels as usize,
        )
        .map_err(|e| CalyError::Resample(format!("rubato init failed: {e:?}")))?;
        let delay_frames = inner.output_delay();
        Ok(Self {
            inner,
            input_rate,
            output_rate,
            channels: channels as usize,
            delay_frames,
            planes: Vec::new(),
            out_planes: Vec::new(),
        })
    }

    /// Filter latency in output frames.
    pub fn delay_frames(&self) -> usize {
        self.delay_frames
    }

    /// Resets the filter state.
    pub fn reset(&mut self) -> Result<(), CalyError> {
        let channels = self.channels;
        let rate_in = self.input_rate;
        let rate_out = self.output_rate;
        *self = Self::new(rate_in, rate_out, channels as u8)?;
        Ok(())
    }

    /// Number of output frames produced for one chunk of input.
    pub fn output_frames_per_chunk(&self) -> usize {
        let ratio = self.output_rate as f64 / self.input_rate as f64;
        (RESAMPLE_CHUNK_FRAMES as f64 * ratio).ceil() as usize
    }

    /// Converts one chunk of interleaved input and appends to `dst`.
    pub fn process_chunk(&mut self, input: &[f32], dst: &mut Vec<f32>) -> Result<usize, CalyError> {
        debug_assert_eq!(input.len(), RESAMPLE_CHUNK_FRAMES * self.channels);
        let ch = self.channels;
        self.planes.clear();
        self.planes.resize_with(ch, Vec::new);
        for (i, plane) in self.planes.iter_mut().enumerate() {
            plane.extend(input.iter().skip(i).step_by(ch).copied());
        }
        self.out_planes.clear();
        let out_planes = self
            .inner
            .process(&self.planes, None)
            .map_err(|e| CalyError::Resample(format!("rubato process failed: {e:?}")))?;
        self.out_planes = out_planes;
        let frames = self.out_planes.first().map(|p| p.len()).unwrap_or(0);

        let old_len = dst.len();
        dst.resize(old_len + frames * ch, 0.0);
        for f in 0..frames {
            for (p, slot) in self
                .out_planes
                .iter()
                .zip(dst[old_len + f * ch..].iter_mut().take(ch))
            {
                *slot = p[f];
            }
        }

        if self.delay_frames > 0 {
            let skip = self.delay_frames.min(frames);
            self.delay_frames -= skip;
            let skip_samples = skip * ch;
            if skip_samples < frames * ch {
                dst.drain(old_len..old_len + skip_samples);
                return Ok(frames - skip);
            }
            dst.truncate(old_len);
            return Ok(0);
        }
        Ok(frames)
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn reset_clears_state() {
        let mut r = Resampler::new(44100, 48000, 2).unwrap();
        let chunk = vec![0.0; RESAMPLE_CHUNK_FRAMES * 2];
        let mut out = Vec::new();
        r.process_chunk(&chunk, &mut out).unwrap();
        r.reset().unwrap();
        r.process_chunk(&chunk, &mut out).unwrap();
    }
}
