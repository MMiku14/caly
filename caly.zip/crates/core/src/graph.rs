//! The **unified audio-path facade**: composable, zero-allocation DSP node assembly.

use crate::audio::AudioBuffer;
use crate::gain::GainSmoother;
use crate::media::{ChannelLayout, Channels, SampleRate, SAMPLE_RATE_MAX};
use crate::mix::Mixer;
use crate::resample::{Resampler, RESAMPLE_CHUNK_FRAMES};
use crate::CalyError;

/// Result of an end-of-stream [`Chain::flush`] / [`AudioFlow::flush`].
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum FlushState {
    /// The chain was already flushed; no more audio will be produced.
    Drained,
    /// Audio was produced.
    Produced,
}

/// A single audio processing stage in the pipeline.
///
/// Implementations are stateful per stream and write output into a caller-supplied
/// [`AudioBuffer`], allowing complete buffer reuse without heap allocation in steady-state.
pub trait AudioNode: Send {
    /// Processes `input` audio and writes transformed samples into `output`.
    fn process(&mut self, input: &AudioBuffer, output: &mut AudioBuffer) -> Result<(), CalyError>;
    /// Ends the stream: writes any buffered tail into `output`. Returns `true` if audio was produced.
    fn flush(&mut self, output: &mut AudioBuffer) -> Result<bool, CalyError>;
    /// Resets stream-to-stream state, keeping pre-allocated buffer capacity.
    fn reset(&mut self);
    /// Stage identifier.
    fn name(&self) -> &'static str;
    /// Estimated internal group delay / latency in frames.
    fn latency_frames(&self) -> usize {
        0
    }
}

/// High-fidelity rate conversion node (passthrough when rates match).
pub struct ResampleNode {
    target_rate: SampleRate,
    resampler: Option<Resampler>,
    pending: Vec<f32>,
    pending_rate: SampleRate,
    pending_channels: usize,
    pending_layout: ChannelLayout,
    resampled: Vec<f32>,
}

impl ResampleNode {
    /// Creates a node targeting `target_rate`.
    pub fn new(target_rate: SampleRate) -> Self {
        Self {
            target_rate,
            resampler: None,
            pending: Vec::with_capacity(RESAMPLE_CHUNK_FRAMES * 4),
            pending_rate: 0,
            pending_channels: 0,
            pending_layout: ChannelLayout::MONO,
            resampled: Vec::with_capacity(RESAMPLE_CHUNK_FRAMES * 4),
        }
    }

    /// The node's target output rate.
    pub fn rate(&self) -> SampleRate {
        self.target_rate
    }

    fn ensure_resampler(&mut self, src_rate: SampleRate, src_ch: usize) -> Result<(), CalyError> {
        let needs_new = match &self.resampler {
            None => true,
            Some(r) => r.input_rate != src_rate || r.channels != src_ch,
        };
        if needs_new {
            self.resampler = Some(Resampler::new(src_rate, self.target_rate, src_ch as u8)?);
            self.pending.clear();
            self.pending_rate = src_rate;
            self.pending_channels = src_ch;
        }
        Ok(())
    }

    /// Consumes whole `RESAMPLE_CHUNK_FRAMES` blocks from `pending` without heap allocations.
    fn drain_pending(&mut self) -> Result<(), CalyError> {
        let full_bytes = RESAMPLE_CHUNK_FRAMES * self.pending_channels;
        let mut consumed = 0usize;
        while self.pending.len() - consumed >= full_bytes {
            // Zero-allocation slice view into pending buffer
            let chunk = &self.pending[consumed..consumed + full_bytes];
            consumed += full_bytes;
            self.resampler
                .as_mut()
                .expect("resampler exists when pending is non-empty")
                .process_chunk(chunk, &mut self.resampled)?;
        }
        if consumed > 0 {
            if consumed == self.pending.len() {
                self.pending.clear();
            } else {
                self.pending.copy_within(consumed.., 0);
                self.pending.truncate(self.pending.len() - consumed);
            }
        }
        Ok(())
    }
}

impl AudioNode for ResampleNode {
    fn process(&mut self, input: &AudioBuffer, output: &mut AudioBuffer) -> Result<(), CalyError> {
        if input.frames() == 0 {
            output.clone_from(input);
            return Ok(());
        }
        if input.sample_rate == self.target_rate {
            // Bit-perfect passthrough for matching rate
            output.clone_from(input);
            return Ok(());
        }
        let src_ch = input.channels.get() as usize;
        self.ensure_resampler(input.sample_rate, src_ch)?;
        self.pending_layout = input.layout;
        self.pending.extend_from_slice(&input.samples);
        self.resampled.clear();
        self.drain_pending()?;

        output.channels = Channels::new(src_ch as u8)?;
        output.sample_rate = self.target_rate;
        output.layout = input.layout;
        output.samples.clear();
        output.samples.extend_from_slice(&self.resampled);
        Ok(())
    }

    fn flush(&mut self, output: &mut AudioBuffer) -> Result<bool, CalyError> {
        if self.resampler.is_none() || self.pending.is_empty() {
            return Ok(false);
        }
        let ch = self.pending_channels;
        let full_bytes = RESAMPLE_CHUNK_FRAMES * ch;
        self.resampled.clear();
        self.drain_pending()?;
        if !self.pending.is_empty() {
            assert!(self.pending.len() < full_bytes);
            self.pending.resize(full_bytes, 0.0);
            let chunk = &self.pending[..full_bytes];
            self.resampler
                .as_mut()
                .expect("resampler exists when pending is non-empty")
                .process_chunk(chunk, &mut self.resampled)?;
            self.pending.clear();
        }
        if self.resampled.is_empty() {
            return Ok(false);
        }
        output.channels = Channels::new(ch as u8)?;
        output.sample_rate = self.target_rate;
        output.layout = self.pending_layout;
        output.samples.clear();
        output.samples.extend_from_slice(&self.resampled);
        Ok(true)
    }

    fn reset(&mut self) {
        self.resampler = None;
        self.pending.clear();
        self.pending_rate = 0;
        self.pending_channels = 0;
        self.resampled.clear();
    }

    fn name(&self) -> &'static str {
        "resample"
    }

    fn latency_frames(&self) -> usize {
        self.resampler.as_ref().map(|r| r.delay_frames()).unwrap_or(0)
    }
}

/// Down/up-mixes any input layout to the node's channel count with zero-allocation steady-state.
pub struct MixNode {
    mixer: Mixer,
    channels: usize,
}

impl MixNode {
    /// Creates a node targeting `channels` (1 or 2).
    pub fn new(channels: usize) -> Result<Self, CalyError> {
        if channels != 1 && channels != 2 {
            return Err(CalyError::Config(format!(
                "invalid output channel count {channels} (1 or 2)"
            )));
        }
        Ok(Self {
            mixer: Mixer::new(channels),
            channels,
        })
    }

    /// The node's output channel count.
    pub fn channels(&self) -> usize {
        self.channels
    }
}

impl AudioNode for MixNode {
    fn process(&mut self, input: &AudioBuffer, output: &mut AudioBuffer) -> Result<(), CalyError> {
        let layout = if self.channels == 1 {
            ChannelLayout::MONO
        } else {
            ChannelLayout::STEREO
        };
        output.channels = Channels::new(self.channels as u8)?;
        output.sample_rate = input.sample_rate;
        output.layout = layout;
        output.samples.clear();

        if input.frames() == 0 {
            return Ok(());
        }
        self.mixer.mix(input, &mut output.samples)?;
        Ok(())
    }

    fn flush(&mut self, _output: &mut AudioBuffer) -> Result<bool, CalyError> {
        Ok(false)
    }

    fn reset(&mut self) {}

    fn name(&self) -> &'static str {
        "mix"
    }
}

/// Applies ramped output volume in-place with zero heap allocations.
pub struct GainNode {
    smoother: GainSmoother,
    ramp_ms: u32,
    pending_target: Option<f32>,
    default_rate: SampleRate,
}

impl GainNode {
    /// Creates a node whose gain starts at `initial`.
    pub fn new(initial: f32, default_rate: SampleRate) -> Self {
        Self {
            smoother: GainSmoother::new(initial),
            ramp_ms: 10,
            pending_target: None,
            default_rate,
        }
    }

    /// Sets the target gain (linear) with a ramp over `ramp_ms`.
    pub fn set_gain_linear(&mut self, gain: f32, ramp_ms: u32) {
        self.pending_target = Some(gain);
        self.ramp_ms = ramp_ms;
    }

    /// Current target gain.
    pub fn gain(&self) -> f32 {
        self.pending_target
            .unwrap_or_else(|| self.smoother.target())
    }
}

impl AudioNode for GainNode {
    fn process(&mut self, input: &AudioBuffer, output: &mut AudioBuffer) -> Result<(), CalyError> {
        if let Some(target) = self.pending_target.take() {
            let rate = if input.sample_rate > 0 {
                input.sample_rate
            } else {
                self.default_rate
            };
            let frames = (rate as f32 * self.ramp_ms as f32 / 1000.0) as usize;
            self.smoother.set_target(target, frames);
        }
        output.clone_from(input);
        if !output.samples.is_empty() {
            self.smoother.apply_interleaved(&mut output.samples, output.channels.get() as usize);
        }
        Ok(())
    }

    fn flush(&mut self, _output: &mut AudioBuffer) -> Result<bool, CalyError> {
        Ok(false)
    }

    fn reset(&mut self) {}

    fn name(&self) -> &'static str {
        "gain"
    }
}

/// An ordered assembly of nodes with ping-pong scratch buffers.
pub struct Chain {
    stages: Vec<Box<dyn AudioNode>>,
    gain: GainNode,
    output_rate: SampleRate,
    output_channels: usize,
    ping: AudioBuffer,
    pong: AudioBuffer,
}

impl Chain {
    /// Assembles a chain with pre-allocated scratch buffers.
    pub fn new(output_rate: SampleRate, output_channels: usize) -> Result<Self, CalyError> {
        if output_rate == 0 || output_rate > SAMPLE_RATE_MAX {
            return Err(CalyError::Config(format!(
                "invalid output sample rate {output_rate}"
            )));
        }
        let stages: Vec<Box<dyn AudioNode>> = vec![
            Box::new(ResampleNode::new(output_rate)),
            Box::new(MixNode::new(output_channels)?),
        ];
        let default_ch = Channels::new(output_channels as u8)?;
        let ping = AudioBuffer::new(default_ch, output_rate, ChannelLayout::STEREO, 4096);
        let pong = AudioBuffer::new(default_ch, output_rate, ChannelLayout::STEREO, 4096);

        Ok(Self {
            stages,
            gain: GainNode::new(1.0, output_rate),
            output_rate,
            output_channels,
            ping,
            pong,
        })
    }

    /// Output sample rate.
    pub fn output_rate(&self) -> SampleRate {
        self.output_rate
    }

    /// Output channel count.
    pub fn output_channels(&self) -> usize {
        self.output_channels
    }

    /// Pushes one chunk through every stage with zero heap allocations in steady-state.
    pub fn process(&mut self, input: &AudioBuffer, output: &mut AudioBuffer) -> Result<(), CalyError> {
        if self.stages.is_empty() {
            return self.gain.process(input, output);
        }

        // First stage: input -> ping
        self.stages[0].process(input, &mut self.ping)?;

        let mut use_ping_as_input = true;
        for stage in self.stages.iter_mut().skip(1) {
            if use_ping_as_input {
                stage.process(&self.ping, &mut self.pong)?;
                use_ping_as_input = false;
            } else {
                stage.process(&self.pong, &mut self.ping)?;
                use_ping_as_input = true;
            }
        }

        let final_stage_out = if use_ping_as_input {
            &self.ping
        } else {
            &self.pong
        };

        self.gain.process(final_stage_out, output)
    }

    /// Flushes the chain at end of stream.
    pub fn flush(&mut self, output: &mut AudioBuffer) -> Result<Option<()>, CalyError> {
        let mut has_audio = false;
        for stage in &mut self.stages {
            if !has_audio {
                if stage.flush(&mut self.ping)? {
                    has_audio = true;
                }
            } else {
                stage.process(&self.ping, &mut self.pong)?;
                std::mem::swap(&mut self.ping, &mut self.pong);
            }
        }
        if has_audio {
            self.gain.process(&self.ping, output)?;
            Ok(Some(()))
        } else {
            Ok(None)
        }
    }

    /// Resets every stage.
    pub fn reset(&mut self) {
        for stage in &mut self.stages {
            stage.reset();
        }
        self.gain.reset();
        self.ping.clear();
        self.pong.clear();
    }

    /// Sets the chain output gain with a ramp.
    pub fn set_gain_linear(&mut self, gain: f32, ramp_ms: u32) {
        self.gain.set_gain_linear(gain, ramp_ms);
    }

    /// Current chain gain.
    pub fn gain(&self) -> f32 {
        self.gain.gain()
    }

    /// Total filter latency across all stages in frames.
    pub fn latency_frames(&self) -> usize {
        self.stages.iter().map(|s| s.latency_frames()).sum()
    }

    /// Human-readable assembly.
    pub fn describe(&self) -> String {
        let mut names: Vec<&str> = self.stages.iter().map(|n| n.name()).collect();
        names.push(self.gain.name());
        format!(
            "{} Hz, {}ch ({})",
            self.output_rate,
            self.output_channels,
            names.join(" -> ")
        )
    }
}

/// The unified per-track audio path facade, powered by [`crate::flow::AudioFlow`].
pub type AudioGraph = crate::flow::AudioFlow;

#[cfg(test)]
mod tests {
    use super::*;

    fn silence_buf(rate: SampleRate, frames: usize) -> AudioBuffer {
        AudioBuffer::silence(Channels::STEREO, rate, ChannelLayout::STEREO, frames)
    }

    #[test]
    fn resample_node_passthrough_at_target_rate() {
        let mut n = ResampleNode::new(48000);
        let buf = silence_buf(48000, 64);
        let mut out = AudioBuffer::new(Channels::STEREO, 48000, ChannelLayout::STEREO, 64);
        n.process(&buf, &mut out).unwrap();
        assert_eq!(out.samples, buf.samples);
        assert_eq!(out.sample_rate, 48000);
    }

    #[test]
    fn chain_assembles_resample_mix_gain() {
        let c = Chain::new(48000, 2).unwrap();
        assert_eq!(c.describe(), "48000 Hz, 2ch (resample -> mix -> gain)");
    }
}
