//! Unified error type for every Caly crate.
use std::path::PathBuf;

/// The canonical error type of the Caly workspace.
#[derive(Debug, thiserror::Error)]
pub enum CalyError {
    /// Underlying I/O failure.
    #[error("I/O error: {0}")]
    Io(#[from] std::io::Error),
    /// The media is not recognised or not supported by this backend.
    #[error("unsupported media: {0}")]
    UnsupportedMedia(String),
    /// The media could not be decoded.
    #[error("decode error: {0}")]
    Decode(String),
    /// The audio output device failed.
    #[error("audio output error: {0}")]
    Output(String),
    /// The engine was asked to do something invalid for its current state.
    #[error("state error: {0}")]
    State(String),
    /// A configuration value is invalid.
    #[error("configuration error: {0}")]
    Config(String),
    /// A feature is not available in this build.
    #[error("feature unavailable: {0}")]
    Unavailable(String),
    /// Resampling failed.
    #[error("resampling error: {0}")]
    Resample(String),
    /// No more frames (end of stream).
    #[error("end of stream")]
    EndOfStream,
    /// The stream was aborted (e.g. by a seek or a stop).
    #[error("stream aborted")]
    Aborted,
    /// A backend is not connected or not available.
    #[error("backend {0} unavailable: {1}")]
    Backend(String, String),
}

/// Convenience alias.
pub type Result<T> = std::result::Result<T, CalyError>;

impl CalyError {
    /// `true` when the error is an expected stream-termination reason
    /// rather than a real failure.
    pub fn is_end_of_stream(&self) -> bool {
        matches!(self, CalyError::EndOfStream | CalyError::Aborted)
    }
}

/// Thrown right away when a file argument / element name can't be resolved.
#[derive(Debug)]
pub struct NotFoundError(pub PathBuf);
