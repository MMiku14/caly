//! Playback queue: track model + pure queue logic.
use std::time::Duration;

/// Unique id of a queue entry.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash, PartialOrd, Ord)]
pub struct TrackId(pub u64);

/// Repeat behaviour at end of queue / track.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Default)]
pub enum RepeatMode {
    /// Stop after the last track.
    #[default]
    Off,
    /// Repeat the current track forever.
    One,
    /// Wrap around the queue.
    All,
}

impl RepeatMode {
    /// Cycles Off -> All -> One -> Off.
    pub fn next(self) -> Self {
        match self {
            RepeatMode::Off => RepeatMode::All,
            RepeatMode::All => RepeatMode::One,
            RepeatMode::One => RepeatMode::Off,
        }
    }
}

/// A queue entry.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct Track {
    /// Stable id.
    pub id: TrackId,
    /// URI.
    pub uri: String,
    /// Display title.
    pub title: String,
    /// Artist.
    pub artist: Option<String>,
    /// Album.
    pub album: Option<String>,
    /// Duration when known.
    pub duration: Option<Duration>,
}

impl Track {
    /// Creates a track from a URI.
    pub fn from_uri(id: TrackId, uri: impl Into<String>) -> Self {
        let uri = uri.into();
        let title = crate::transport::file_uri_to_path(&uri)
            .file_stem()
            .map(|s| s.to_string_lossy().into_owned())
            .unwrap_or_else(|| uri.clone());
        Self {
            id,
            uri,
            title,
            artist: None,
            album: None,
            duration: None,
        }
    }

    /// `Artist - Title` style summary.
    pub fn display(&self) -> String {
        match (&self.artist, &self.title) {
            (Some(a), t) if !a.is_empty() => format!("{a} - {t}"),
            _ => self.title.clone(),
        }
    }
}

/// Result alias for queue operations.
pub type QueueResult<T> = std::result::Result<T, QueueError>;

/// Errors produced by [`Queue`].
#[derive(Debug, thiserror::Error, PartialEq, Eq)]
pub enum QueueError {
    /// Index out of bounds.
    #[error("index out of bounds: {0}")]
    IndexOutOfBounds(usize),
    /// No items in the queue.
    #[error("queue is empty")]
    Empty,
}

/// The playback queue with repeat/shuffle semantics.
#[derive(Debug, Clone)]
pub struct Queue {
    items: Vec<Track>,
    cursor: Option<usize>,
    repeat: RepeatMode,
    shuffle: bool,
    shuffle_order: Vec<usize>,
    shuffle_cursor: usize,
    next_id: u64,
}

impl Default for Queue {
    fn default() -> Self {
        Self::new()
    }
}

impl Queue {
    /// Creates an empty queue.
    pub fn new() -> Self {
        Self {
            items: Vec::new(),
            cursor: None,
            repeat: RepeatMode::Off,
            shuffle: false,
            shuffle_order: Vec::new(),
            shuffle_cursor: 0,
            next_id: 1,
        }
    }

    /// Number of items.
    pub fn len(&self) -> usize {
        self.items.len()
    }

    /// `true` when empty.
    pub fn is_empty(&self) -> bool {
        self.items.is_empty()
    }

    /// Index of the current item.
    pub fn cursor(&self) -> Option<usize> {
        self.cursor
    }

    /// Repeat mode.
    pub fn repeat(&self) -> RepeatMode {
        self.repeat
    }

    /// Shuffle flag.
    pub fn shuffle(&self) -> bool {
        self.shuffle
    }

    /// Items in queue order.
    pub fn items(&self) -> &[Track] {
        &self.items
    }

    /// The current item.
    pub fn current(&self) -> Option<&Track> {
        self.cursor.and_then(|i| self.items.get(i))
    }

    /// Next id to assign.
    pub fn next_id(&mut self) -> TrackId {
        let id = TrackId(self.next_id);
        self.next_id += 1;
        id
    }

    /// Adds tracks at the end.
    pub fn push(&mut self, mut tracks: Vec<Track>) {
        for t in tracks.iter_mut() {
            t.id = self.next_id();
        }
        self.items.extend(tracks);
        self.rebuild_shuffle_if_active();
    }

    /// Inserts tracks at `index` (clamped).
    pub fn insert(&mut self, index: usize, mut tracks: Vec<Track>) {
        let count = tracks.len();
        for t in tracks.iter_mut() {
            t.id = self.next_id();
        }
        let idx = index.min(self.items.len());
        self.items.splice(idx..idx, tracks);
        if let Some(c) = self.cursor {
            if c >= idx {
                self.cursor = Some(c + count);
            }
        }
        self.rebuild_shuffle_if_active();
    }

    /// Removes the item at `index`.
    pub fn remove(&mut self, index: usize) -> QueueResult<Track> {
        if index >= self.items.len() {
            return Err(QueueError::IndexOutOfBounds(index));
        }
        let removed = self.items.remove(index);
        if let Some(c) = self.cursor {
            if c == index {
                self.cursor = if index < self.items.len() {
                    Some(index)
                } else if !self.items.is_empty() {
                    Some(self.items.len() - 1)
                } else {
                    None
                };
            } else if c > index {
                self.cursor = Some(c - 1);
            }
        }
        self.rebuild_shuffle_if_active();
        Ok(removed)
    }

    /// Moves an item from `from` to `to` (Vim-style line move).
    pub fn move_item(&mut self, from: usize, to: usize) -> QueueResult<()> {
        if from >= self.items.len() || to >= self.items.len() {
            return Err(QueueError::IndexOutOfBounds(from.max(to)));
        }
        if from == to {
            return Ok(());
        }
        let item = self.items.remove(from);
        self.items.insert(to, item);
        if let Some(c) = self.cursor {
            if c == from {
                self.cursor = Some(to);
            } else if from < c && to >= c {
                self.cursor = Some(c - 1);
            } else if from > c && to <= c {
                self.cursor = Some(c + 1);
            }
        }
        self.rebuild_shuffle_if_active();
        Ok(())
    }

    /// Total duration of all tracks in the queue when known.
    pub fn total_duration(&self) -> Option<Duration> {
        let mut total = Duration::ZERO;
        let mut any = false;
        for t in &self.items {
            if let Some(d) = t.duration {
                total += d;
                any = true;
            }
        }
        if any {
            Some(total)
        } else {
            None
        }
    }

    /// Removes everything.
    pub fn clear(&mut self) {
        self.items.clear();
        self.cursor = None;
        self.shuffle_order.clear();
        self.shuffle_cursor = 0;
    }

    /// Starts playback at `index`.
    pub fn play_at(&mut self, index: usize) -> QueueResult<()> {
        if index >= self.items.len() {
            return Err(QueueError::IndexOutOfBounds(index));
        }
        self.cursor = Some(index);
        self.rebuild_shuffle_if_active();
        if self.shuffle {
            if let Some(pos) = self.shuffle_order.iter().position(|&i| i == index) {
                self.shuffle_cursor = pos;
            }
        }
        Ok(())
    }

    fn next_cursor_state(&self) -> Option<(usize, usize)> {
        if self.is_empty() {
            return None;
        }
        if self.repeat == RepeatMode::One {
            if let Some(c) = self.cursor {
                return Some((c, self.shuffle_cursor));
            }
            return None;
        }
        if self.shuffle {
            let next = self.shuffle_cursor + 1;
            if next < self.shuffle_order.len() {
                return Some((self.shuffle_order[next], next));
            }
            return match self.repeat {
                RepeatMode::Off => None,
                RepeatMode::All => Some((self.shuffle_order[0], 0)),
                RepeatMode::One => self.cursor.map(|c| (c, self.shuffle_cursor)),
            };
        }
        let c = self.cursor?;
        if c + 1 < self.items.len() {
            return Some((c + 1, 0));
        }
        match self.repeat {
            RepeatMode::Off => None,
            RepeatMode::All => Some((0, 0)),
            RepeatMode::One => Some((c, 0)),
        }
    }

    /// Index of the item `advance` would move to.
    pub fn peek_next_index(&self) -> Option<usize> {
        self.next_cursor_state().map(|(c, _)| c)
    }

    /// Advances to the next item.
    pub fn advance(&mut self) -> Option<usize> {
        let (next, shuffle_next) = self.next_cursor_state()?;
        self.cursor = Some(next);
        self.shuffle_cursor = shuffle_next;
        self.cursor
    }

    /// Moves to previous item.
    pub fn rewind(&mut self) -> Option<usize> {
        if self.is_empty() {
            return None;
        }
        if self.shuffle {
            if self.shuffle_cursor > 0 {
                self.shuffle_cursor -= 1;
            }
            self.cursor = Some(self.shuffle_order[self.shuffle_cursor]);
            return self.cursor;
        }
        let c = self.cursor.unwrap_or(0);
        self.cursor = Some(c.saturating_sub(1));
        self.cursor
    }

    /// Sets repeat mode.
    pub fn set_repeat(&mut self, mode: RepeatMode) {
        self.repeat = mode;
    }

    /// Sets shuffle mode.
    pub fn set_shuffle(&mut self, on: bool) {
        self.shuffle = on;
        if on {
            self.rebuild_shuffle_if_active();
        } else {
            self.shuffle_order.clear();
            self.shuffle_cursor = 0;
        }
    }

    fn rebuild_shuffle_if_active(&mut self) {
        if self.shuffle {
            let len = self.items.len();
            let mut order: Vec<usize> = (0..len).collect();
            if let Some(c) = self.cursor {
                if let Some(pos) = order.iter().position(|&i| i == c) {
                    order.swap(0, pos);
                }
            }
            let mut seed = 0x9E3779B97F4A7C15u64 ^ self.next_id.wrapping_mul(0x517cc1b727220a95);
            for i in (1..order.len()).rev() {
                seed = seed
                    .wrapping_mul(6364136223846793005)
                    .wrapping_add(1442695040888963407);
                let j = (seed >> 33) as usize % (i + 1);
                order.swap(i, j);
            }
            if let Some(c) = self.cursor {
                if let Some(pos) = order.iter().position(|&i| i == c) {
                    self.shuffle_cursor = pos;
                } else {
                    self.shuffle_cursor = 0;
                }
            } else {
                self.shuffle_cursor = 0;
            }
            self.shuffle_order = order;
        }
    }
}
