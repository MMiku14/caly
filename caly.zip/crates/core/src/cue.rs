//! CUE sheet parsing for multi-track single-file albums (TAK, FLAC, APE, WAV).

use std::path::{Path, PathBuf};
use std::time::Duration;

/// One track defined inside a CUE sheet.
#[derive(Debug, Clone, PartialEq)]
pub struct CueTrack {
    /// 1-based track sequence number.
    pub number: u32,
    /// Title of this track.
    pub title: String,
    /// Performer / artist of this track.
    pub performer: Option<String>,
    /// Start timestamp in seconds from file beginning.
    pub start_secs: f64,
    /// Duration in seconds when computable (from next track start or file length).
    pub duration_secs: Option<f64>,
}

/// Parsed CUE sheet representing multiple tracks in a single audio file.
#[derive(Debug, Clone, PartialEq, Default)]
pub struct CueSheet {
    /// Target audio file name referenced in the CUE sheet.
    pub file: Option<String>,
    /// Album title.
    pub title: Option<String>,
    /// Album artist / performer.
    pub performer: Option<String>,
    /// Parsed tracks in playback order.
    pub tracks: Vec<CueTrack>,
}

impl CueSheet {
    /// Attempts to locate and parse a sibling CUE file for `audio_path`.
    pub fn find_sibling(audio_path: &Path) -> Option<Self> {
        let mut candidate = audio_path.to_path_buf();
        candidate.set_extension("cue");
        if candidate.is_file() {
            if let Ok(content) = std::fs::read_to_string(&candidate) {
                return Self::parse(&content).ok();
            }
        }
        None
    }

    /// Parses a CUE sheet from string content.
    pub fn parse(content: &str) -> Result<Self, String> {
        let mut sheet = CueSheet::default();
        let mut current_track: Option<CueTrack> = None;

        for line in content.lines() {
            let line = line.trim();
            if line.is_empty() || line.starts_with("REM") {
                continue;
            }

            let mut tokens = line.split_whitespace();
            let Some(cmd) = tokens.next() else { continue; };

            match cmd.to_ascii_uppercase().as_str() {
                "PERFORMER" => {
                    let val = extract_quoted_or_rest(line, "PERFORMER");
                    if let Some(track) = &mut current_track {
                        track.performer = Some(val);
                    } else {
                        sheet.performer = Some(val);
                    }
                }
                "TITLE" => {
                    let val = extract_quoted_or_rest(line, "TITLE");
                    if let Some(track) = &mut current_track {
                        track.title = val;
                    } else {
                        sheet.title = Some(val);
                    }
                }
                "FILE" => {
                    sheet.file = Some(extract_quoted_or_rest(line, "FILE"));
                }
                "TRACK" => {
                    if let Some(prev) = current_track.take() {
                        sheet.tracks.push(prev);
                    }
                    let num = tokens.next().and_then(|s| s.parse::<u32>().ok()).unwrap_or(sheet.tracks.len() as u32 + 1);
                    current_track = Some(CueTrack {
                        number: num,
                        title: format!("Track {:02}", num),
                        performer: sheet.performer.clone(),
                        start_secs: 0.0,
                        duration_secs: None,
                    });
                }
                "INDEX" => {
                    let idx_num = tokens.next().unwrap_or("");
                    let stamp = tokens.next().unwrap_or("");
                    if idx_num == "01" || (idx_num == "1" && current_track.as_ref().map(|t| t.start_secs == 0.0).unwrap_or(false)) {
                        if let Some(secs) = parse_cue_timestamp(stamp) {
                            if let Some(track) = &mut current_track {
                                track.start_secs = secs;
                            }
                        }
                    }
                }
                _ => {}
            }
        }

        if let Some(last) = current_track {
            sheet.tracks.push(last);
        }

        if sheet.tracks.is_empty() {
            return Err("No tracks found in CUE sheet".to_string());
        }

        // Calculate track durations from next track start times
        let len = sheet.tracks.len();
        for i in 0..len.saturating_sub(1) {
            let next_start = sheet.tracks[i + 1].start_secs;
            let cur_start = sheet.tracks[i].start_secs;
            if next_start >= cur_start {
                sheet.tracks[i].duration_secs = Some(next_start - cur_start);
            }
        }

        Ok(sheet)
    }

    /// Converts parsed CUE tracks into virtual playable [`crate::queue::Track`] instances for the single audio file.
    pub fn to_tracks(&self, audio_uri: &str) -> Vec<crate::queue::Track> {
        self.tracks
            .iter()
            .map(|t| {
                let dur = t.duration_secs.map(Duration::from_secs_f64);
                let virtual_uri = format!(
                    "{}#cue_track={}&start={:.3}{}",
                    audio_uri,
                    t.number,
                    t.start_secs,
                    t.duration_secs.map(|d| format!("&dur={:.3}", d)).unwrap_or_default()
                );
                crate::queue::Track {
                    id: crate::queue::TrackId(0),
                    uri: virtual_uri,
                    title: t.title.clone(),
                    artist: t.performer.clone().or_else(|| self.performer.clone()),
                    album: self.title.clone(),
                    duration: dur,
                }
            })
            .collect()
    }
}

/// Parses "mm:ss:ff" timestamp (75 frames per second).
fn parse_cue_timestamp(s: &str) -> Option<f64> {
    let parts: Vec<&str> = s.split(':').collect();
    if parts.len() != 3 {
        return None;
    }
    let m: f64 = parts[0].trim().parse().ok()?;
    let sec: f64 = parts[1].trim().parse().ok()?;
    let f: f64 = parts[2].trim().parse().ok()?;
    Some(m * 60.0 + sec + f / 75.0)
}

fn extract_quoted_or_rest(line: &str, prefix: &str) -> String {
    let after = line.trim_start().strip_prefix(prefix).unwrap_or(line).trim();
    if let Some(first_quote) = after.find('"') {
        if let Some(second_quote) = after[first_quote + 1..].find('"') {
            return after[first_quote + 1..first_quote + 1 + second_quote].to_string();
        }
    }
    after.split_whitespace().next().unwrap_or(after).to_string()
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn parses_standard_cuesheet() {
        let cue = r#"
PERFORMER "Various Artists"
TITLE "Lossless Compilation"
FILE "album.tak" WAVE
  TRACK 01 AUDIO
    TITLE "First Movement"
    PERFORMER "Composer A"
    INDEX 01 00:00:00
  TRACK 02 AUDIO
    TITLE "Second Movement"
    PERFORMER "Composer B"
    INDEX 01 04:30:00
"#;
        let sheet = CueSheet::parse(cue).expect("valid cuesheet");
        assert_eq!(sheet.title.as_deref(), Some("Lossless Compilation"));
        assert_eq!(sheet.tracks.len(), 2);
        assert_eq!(sheet.tracks[0].title, "First Movement");
        assert_eq!(sheet.tracks[0].start_secs, 0.0);
        assert_eq!(sheet.tracks[0].duration_secs, Some(270.0));
        assert_eq!(sheet.tracks[1].title, "Second Movement");
        assert_eq!(sheet.tracks[1].start_secs, 270.0);

        let tracks = sheet.to_tracks("file:///music/album.tak");
        assert_eq!(tracks.len(), 2);
        assert!(tracks[0].uri.contains("#cue_track=1"));
        assert!(tracks[1].uri.contains("#cue_track=2"));
    }
}
