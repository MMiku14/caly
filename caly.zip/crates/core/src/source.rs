//! The **decoder** layer: [`SourceBackend`] and [`SourceFactory`].
use std::fmt;
use std::time::Duration;
use crate::audio::AudioBuffer;
use crate::media::{ChannelLayout, Channels, SampleFormat, SampleRate};
use crate::transport::Transport;

/// Result alias for source operations.
pub type SourceResult<T> = std::result::Result<T, SourceError>;

/// Errors produced by decoding backends.
#[derive(Debug, thiserror::Error)]
pub enum SourceError {
    /// The media/probe failed.
    #[error("decode error: {0}")]
    Decode(String),
    /// The resource was not recognized as audio.
    #[error("unsupported media: {0}")]
    Unsupported(String),
    /// I/O failure while reading from the transport.
    #[error("transport error: {0}")]
    Transport(#[from] crate::transport::TransportError),
    /// A seek failed.
    #[error("seek error: {0}")]
    Seek(String),
}

/// Per-track metadata gathered by probing.
#[derive(Debug, Clone, Default, PartialEq, Eq)]
pub struct TrackMeta {
    /// Track title.
    pub title: Option<String>,
    /// Artist name.
    pub artist: Option<String>,
    /// Album name.
    pub album: Option<String>,
    /// Total duration, when known.
    pub duration: Option<Duration>,
    /// Year, when known.
    pub year: Option<u32>,
    /// Extra tags.
    pub extra: Vec<(String, String)>,
}

impl TrackMeta {
    /// Display string like `"Artist - Title"`.
    pub fn display(&self, fallback_title: &str) -> String {
        match (&self.artist, &self.title) {
            (Some(a), Some(t)) => format!("{a} - {t}"),
            (Some(a), None) => a.clone(),
            (None, Some(t)) => t.clone(),
            (None, None) => fallback_title.to_string(),
        }
    }
}

/// Static properties of the decoded stream.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub struct StreamInfo {
    /// Sample rate in Hz.
    pub sample_rate: SampleRate,
    /// Channel count.
    pub channels: Channels,
    /// Channel layout.
    pub layout: ChannelLayout,
    /// Native sample format before conversion to `f32`.
    pub format: SampleFormat,
}

/// A live decoding session for one track.
pub trait SourceBackend: Send {
    /// Requests the next block of decoded audio.
    fn next_chunk(&mut self, max_frames: usize) -> SourceResult<Option<AudioBuffer>>;
    /// Seeks to `pos`.
    fn seek(&mut self, pos: Duration) -> SourceResult<()>;
    /// Rewinds to the start of the stream.
    fn reset(&mut self) -> SourceResult<()>;
    /// Immutable metadata.
    fn track_meta(&self) -> &TrackMeta;
    /// Static stream properties.
    fn stream_info(&self) -> Option<&StreamInfo> {
        None
    }
}

/// Info collected during a cheap pre-play probe.
#[derive(Debug, Clone, Default)]
pub struct ProbeInfo {
    /// Metadata tags.
    pub meta: TrackMeta,
    /// Duration when known.
    pub duration: Option<Duration>,
    /// Static stream info when known.
    pub sample: Option<StreamInfo>,
}

/// A factory of [`SourceBackend`]s.
pub trait SourceFactory: Send + Sync {
    /// Stable identifier, e.g. `"ffmpeg"`.
    fn id(&self) -> &'static str;
    /// Human-readable display name.
    fn name(&self) -> &'static str;
    /// `true` when this factory can plausibly open `uri`.
    fn can_open(&self, uri: &str) -> bool;
    /// Probe `uri` without starting playback.
    fn probe(&self, uri: &str, transport: Box<dyn Transport>) -> SourceResult<ProbeInfo>;
    /// Opens a decoding session.
    fn open(
        &self,
        uri: &str,
        transport: Box<dyn Transport>,
    ) -> SourceResult<Box<dyn SourceBackend>>;
}

impl fmt::Debug for dyn SourceBackend {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(f, "SourceBackend")
    }
}
