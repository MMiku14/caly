//! Synced and plain lyrics parser, timestamp alignment, and karaoke interpolation.

use std::path::{Path, PathBuf};
use std::time::Duration;

/// Parsed lyrics representation.
#[derive(Debug, Clone, PartialEq)]
pub enum Lyrics {
    /// Timestamp-synchronized lines.
    Synced(Vec<SyncedLine>),
    /// Plain un-timed lines.
    Plain(Vec<String>),
}

/// A single timestamped line in a synced lyrics file.
#[derive(Debug, Clone, PartialEq)]
pub struct SyncedLine {
    /// Timestamp in seconds.
    pub time_secs: f64,
    /// Estimated or calculated end time in seconds.
    pub end_secs: f64,
    /// Text of the lyric line.
    pub text: String,
    /// Word-level timestamps for karaoke rendering.
    pub words: Option<Vec<Word>>,
}

/// Word-level timing metadata for karaoke highlights.
#[derive(Debug, Clone, PartialEq)]
pub struct Word {
    /// Start timestamp in seconds.
    pub start_secs: f64,
    /// End timestamp in seconds.
    pub end_secs: f64,
    /// Word text.
    pub text: String,
}

impl Lyrics {
    /// Total number of lines.
    pub fn line_count(&self) -> usize {
        match self {
            Lyrics::Synced(lines) => lines.len(),
            Lyrics::Plain(lines) => lines.len(),
        }
    }

    /// Index of the active line corresponding to playback position.
    pub fn active_index(&self, elapsed: Duration) -> Option<usize> {
        let Lyrics::Synced(lines) = self else {
            return None;
        };
        let secs = elapsed.as_secs_f64();
        let mut active = None;
        for (index, line) in lines.iter().enumerate() {
            if line.time_secs <= secs + 0.25 {
                active = Some(index);
            } else {
                break;
            }
        }
        let index = active?;
        let time = lines[index].time_secs;
        let mut start = index;
        while start > 0 && lines[start - 1].time_secs == time {
            start -= 1;
        }
        Some(start)
    }

    /// Range `[start, end)` of lines sharing identical timestamps (e.g. bilingual pairs).
    pub fn active_group(&self, elapsed: Duration) -> Option<(usize, usize)> {
        let start = self.active_index(elapsed)?;
        self.item_group(start)
    }

    /// Range `[start, end)` of lines grouped into a logical item.
    pub fn item_group(&self, index: usize) -> Option<(usize, usize)> {
        match self {
            Lyrics::Synced(lines) => {
                let time = lines.get(index)?.time_secs;
                let mut start = index;
                while start > 0 && lines[start - 1].time_secs == time {
                    start -= 1;
                }
                let mut end = index + 1;
                while end < lines.len() && lines[end].time_secs == time {
                    end += 1;
                }
                Some((start, end))
            }
            Lyrics::Plain(lines) => (index < lines.len()).then_some((index, index + 1)),
        }
    }

    /// Steps `delta` logical lyric items forward or backward.
    pub fn move_item_index(&self, index: usize, delta: i32) -> Option<usize> {
        let (mut start, mut end) = self.item_group(index)?;
        if delta < 0 {
            for _ in 0..delta.unsigned_abs() {
                if start == 0 {
                    break;
                }
                start = self.item_group(start - 1)?.0;
            }
        } else {
            for _ in 0..delta as usize {
                if end >= self.line_count() {
                    break;
                }
                let next_group = self.item_group(end)?;
                start = next_group.0;
                end = next_group.1;
            }
        }
        Some(start)
    }

    /// Number of characters sung so far for karaoke color highlighting.
    pub fn karaoke_at(&self, index: usize, elapsed: Duration) -> usize {
        let Lyrics::Synced(lines) = self else {
            return 0;
        };
        let Some(line) = lines.get(index) else {
            return 0;
        };
        let secs = elapsed.as_secs_f64();
        let total = line.text.chars().count();
        if secs < line.time_secs {
            return 0;
        }
        if let Some(words) = &line.words {
            let mut count = 0;
            for word in words {
                if word.start_secs <= secs {
                    count += word.text.chars().count();
                } else {
                    break;
                }
            }
            return count.min(total);
        }
        let span = (line.end_secs - line.time_secs).max(0.001);
        let fraction = ((secs - line.time_secs) / span).clamp(0.0, 1.0);
        ((fraction * total as f64).round() as usize).min(total)
    }

    /// Text of the lyric line at `index`.
    pub fn line(&self, index: usize) -> Option<&str> {
        match self {
            Lyrics::Synced(lines) => lines.get(index).map(|l| l.text.as_str()),
            Lyrics::Plain(lines) => lines.get(index).map(String::as_str),
        }
    }


    /// Returns the start timestamp in seconds of the line at `index` if available.
    pub fn line_time(&self, index: usize) -> Option<f64> {
        match self {
            Lyrics::Synced(lines) => lines.get(index).map(|l| l.time_secs),
            Lyrics::Plain(_) => None,
        }
    }

    /// Attempts to load lyrics from a sibling `.lrc` file.
    pub fn load_sibling(audio_path: &Path) -> Option<Self> {
        let mut candidate = audio_path.to_path_buf();
        candidate.set_extension("lrc");
        if candidate.is_file() {
            if let Ok(body) = std::fs::read_to_string(&candidate) {
                return Self::parse(&body).ok();
            }
        }
        None
    }

    /// Parses LRC content string into [`Lyrics`].
    pub fn parse(body: &str) -> Result<Self, String> {
        let mut timed: Vec<SyncedLine> = Vec::new();
        let mut plain: Vec<String> = Vec::new();

        for line in body.lines() {
            let line = line.trim_end_matches('\r');
            let (times, text, words) = parse_lrc_line(line);
            if times.is_empty() {
                plain.push(line.to_string());
            } else {
                let words_opt = if times.len() == 1 { words } else { None };
                for time in times {
                    timed.push(SyncedLine {
                        time_secs: time,
                        end_secs: 0.0,
                        text: text.clone(),
                        words: words_opt.clone(),
                    });
                }
            }
        }

        if timed.is_empty() {
            if plain.iter().all(|line| line.trim().is_empty()) {
                return Err("lyrics file is empty".to_string());
            }
            return Ok(Lyrics::Plain(
                plain.into_iter().filter(|line| !line.trim().is_empty()).collect(),
            ));
        }

        timed.sort_by(|a, b| {
            a.time_secs
                .partial_cmp(&b.time_secs)
                .unwrap_or(std::cmp::Ordering::Equal)
        });

        let len = timed.len();
        for i in 0..len {
            let start = timed[i].time_secs;
            let fallback_end = start + 5.0;
            let end = timed[i + 1..]
                .iter()
                .find(|next| next.time_secs > start)
                .map(|next| next.time_secs.max(start + 0.05))
                .unwrap_or(fallback_end);
            timed[i].end_secs = end;

            if let Some(words) = &mut timed[i].words {
                let wlen = words.len();
                for w in 0..wlen {
                    let word_end = words
                        .get(w + 1)
                        .map(|next| next.start_secs.max(words[w].start_secs))
                        .unwrap_or(end);
                    words[w].end_secs = word_end;
                }
            }
        }

        Ok(Lyrics::Synced(timed))
    }
}

fn parse_lrc_line(line: &str) -> (Vec<f64>, String, Option<Vec<Word>>) {
    let mut rest = line;
    let mut times = Vec::new();

    while let Some(after) = rest.strip_prefix('[') {
        let Some((stamp, tail)) = after.split_once(']') else {
            break;
        };
        if let Some(time) = parse_lrc_timestamp(stamp) {
            times.push(time);
            rest = tail;
        } else {
            rest = tail;
        }
    }

    if times.is_empty() {
        return (Vec::new(), line.to_string(), None);
    }

    let mut words: Vec<Word> = Vec::new();
    let mut segment = String::new();
    let mut plain = String::new();
    let mut chars = rest.chars().peekable();

    while let Some(ch) = chars.next() {
        if ch != '<' {
            segment.push(ch);
            plain.push(ch);
            continue;
        }
        let mut stamp = String::new();
        let mut closed = false;
        for tag_ch in chars.by_ref() {
            if tag_ch == '>' {
                closed = true;
                break;
            }
            stamp.push(tag_ch);
        }
        match (closed, parse_lrc_timestamp(&stamp)) {
            (true, Some(start)) => {
                if let Some(last) = words.last_mut() {
                    last.text.push_str(&segment);
                }
                segment.clear();
                words.push(Word {
                    start_secs: start,
                    end_secs: 0.0,
                    text: String::new(),
                });
            }
            _ => {
                let literal = format!("<{stamp}>");
                segment.push_str(&literal);
                plain.push_str(&literal);
            }
        }
    }

    if let Some(last) = words.last_mut() {
        last.text.push_str(&segment);
    }

    if !words.is_empty() {
        (times, plain, Some(words))
    } else {
        (times, rest.to_string(), None)
    }
}

fn parse_lrc_timestamp(stamp: &str) -> Option<f64> {
    let (minutes, seconds) = stamp.split_once(':')?;
    let min: f64 = minutes.trim().parse().ok()?;
    let sec: f64 = seconds.trim().parse().ok()?;
    Some(min * 60.0 + sec)
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn parses_synced_and_plain_lyrics() {
        let synced = Lyrics::parse("[00:01.50]Hello\n[00:04.00]World\n").unwrap();
        assert_eq!(synced.line_count(), 2);
        assert_eq!(synced.active_index(Duration::from_secs(2)), Some(0));
        assert_eq!(synced.active_index(Duration::from_secs(5)), Some(1));

        let plain = Lyrics::parse("Just plain text\nSecond line\n").unwrap();
        assert_eq!(plain.line_count(), 2);
        assert!(matches!(plain, Lyrics::Plain(_)));
    }

    #[test]
    fn parses_word_timed_karaoke() {
        let body = "[00:10.00]<00:10.00>word <00:11.00>two\n[00:20.00]next line\n";
        let lyrics = Lyrics::parse(body).unwrap();
        assert_eq!(lyrics.karaoke_at(0, Duration::from_secs_f64(10.5)), 5); // "word "
        assert_eq!(lyrics.karaoke_at(0, Duration::from_secs_f64(11.5)), 8); // "word two"
    }

    #[test]
    fn handles_bilingual_shared_timestamp_groups() {
        let body = "[00:02.00]Original lyrics\n[00:02.00]Translated lyrics\n[00:08.00]Next\n";
        let lyrics = Lyrics::parse(body).unwrap();
        assert_eq!(lyrics.active_group(Duration::from_secs(3)), Some((0, 2)));
    }
}
