//! Sample-rate, channel and format vocabulary.
use std::fmt;
use std::str::FromStr;

/// Sample rate in Hz.
pub type SampleRate = u32;

/// Highest sample rate Caly will ever try to configure.
pub const SAMPLE_RATE_MAX: SampleRate = 384_000;

/// The sample rate used when the output device does not negotiate one.
pub const DEFAULT_SAMPLE_RATE: SampleRate = 48_000;

/// Decoder-side sample format (always converted to the canonical `f32`
/// interleaved representation before it reaches the engine).
#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash)]
pub enum SampleFormat {
    /// Unsigned 8-bit PCM.
    U8,
    /// Signed 16-bit little-endian PCM.
    S16,
    /// Signed 24-bit PCM (in 32-bit words).
    S24,
    /// Signed 32-bit PCM.
    S32,
    /// 32-bit float.
    F32,
    /// 64-bit float.
    F64,
}

impl SampleFormat {
    /// Bytes per single sample of this format.
    pub fn bytes_per_sample(self) -> u8 {
        match self {
            SampleFormat::U8 => 1,
            SampleFormat::S16 => 2,
            SampleFormat::S24 => 3,
            SampleFormat::S32 | SampleFormat::F32 => 4,
            SampleFormat::F64 => 8,
        }
    }
}

impl fmt::Display for SampleFormat {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(f, "{self:?}")
    }
}

/// Number of channels, validated to `1..=32`.
#[derive(Debug, Clone, Copy, PartialEq, Eq, PartialOrd, Ord, Hash)]
pub struct Channels(u8);

impl Channels {
    /// One channel.
    pub const MONO: Channels = Channels(1);
    /// Two channels.
    pub const STEREO: Channels = Channels(2);

    /// Creates a channel count, rejecting `0` and values above 32.
    pub fn new(n: u8) -> Result<Self, crate::CalyError> {
        if n == 0 || n > 32 {
            return Err(crate::CalyError::Config(format!(
                "invalid channel count {n} (allowed: 1..=32)"
            )));
        }
        Ok(Channels(n))
    }

    /// Raw value.
    pub fn get(self) -> u8 {
        self.0
    }

    /// Zero-based index of the last channel.
    pub fn last_index(self) -> usize {
        self.0 as usize - 1
    }
}

impl From<Channels> for u8 {
    fn from(c: Channels) -> Self {
        c.0
    }
}

impl TryFrom<u8> for Channels {
    type Error = crate::CalyError;
    fn try_from(n: u8) -> Result<Self, Self::Error> {
        Channels::new(n)
    }
}

impl fmt::Display for Channels {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(f, "{}", self.0)
    }
}

impl FromStr for Channels {
    type Err = crate::CalyError;
    fn from_str(s: &str) -> Result<Self, Self::Err> {
        match s {
            "mono" => Ok(Channels::MONO),
            "stereo" => Ok(Channels::STEREO),
            _ => s
                .parse::<u8>()
                .ok()
                .and_then(|n| Channels::new(n).ok())
                .ok_or_else(|| crate::CalyError::Config(format!("invalid channels: {s:?}"))),
        }
    }
}

/// A channel-layout mask. Bit `i` set means "channel `i` is present".
#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash)]
pub struct ChannelLayout(u32);

#[allow(missing_docs)]
impl ChannelLayout {
    pub const FRONT_LEFT: u32 = 1 << 0;
    pub const FRONT_RIGHT: u32 = 1 << 1;
    pub const FRONT_CENTER: u32 = 1 << 2;
    pub const LFE: u32 = 1 << 3;
    pub const BACK_LEFT: u32 = 1 << 4;
    pub const BACK_RIGHT: u32 = 1 << 5;
    pub const FRONT_LEFT_CENTER: u32 = 1 << 6;
    pub const FRONT_RIGHT_CENTER: u32 = 1 << 7;
    pub const BACK_CENTER: u32 = 1 << 8;
    pub const SIDE_LEFT: u32 = 1 << 9;
    pub const SIDE_RIGHT: u32 = 1 << 10;

    /// A single front-centre channel.
    pub const MONO: ChannelLayout = ChannelLayout(Self::FRONT_CENTER);
    /// Classic stereo.
    pub const STEREO: ChannelLayout = ChannelLayout(Self::FRONT_LEFT | Self::FRONT_RIGHT);
    /// 5.1 surround.
    pub const FIVE_POINT_ONE: ChannelLayout = ChannelLayout(
        Self::FRONT_LEFT
            | Self::FRONT_RIGHT
            | Self::FRONT_CENTER
            | Self::LFE
            | Self::BACK_LEFT
            | Self::BACK_RIGHT,
    );

    /// Creates a layout from a raw mask.
    pub const fn from_mask(mask: u32) -> Self {
        ChannelLayout(mask)
    }

    /// Raw mask value.
    pub const fn mask(self) -> u32 {
        self.0
    }

    /// Number of present channels.
    pub fn count(self) -> u8 {
        self.0.count_ones() as u8
    }

    /// `true` if the given flag bit is present.
    pub fn contains(self, flag: u32) -> bool {
        self.0 & flag != 0
    }

    /// Index of the channel carrying `flag` (ascending order), if present.
    pub fn index_of(self, flag: u32) -> Option<usize> {
        if self.0 & flag == 0 {
            return None;
        }
        Some((self.0 & (flag - 1)).count_ones() as usize)
    }

    /// Index of the front-left channel (or the first channel as fallback).
    pub fn front_left_index(self) -> usize {
        self.index_of(Self::FRONT_LEFT)
            .or_else(|| self.index_of(Self::FRONT_CENTER))
            .unwrap_or(0)
    }

    /// Index of the front-right channel (fallback: same as left).
    pub fn front_right_index(self) -> usize {
        self.index_of(Self::FRONT_RIGHT)
            .unwrap_or_else(|| self.front_left_index())
    }
}

impl fmt::Display for ChannelLayout {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(f, "0x{:04x}", self.0)
    }
}

/// A sensible default layout for a raw channel count.
pub fn default_layout_for(channels: Channels) -> ChannelLayout {
    let mask = match channels.get() {
        1 => ChannelLayout::FRONT_CENTER,
        2 => ChannelLayout::FRONT_LEFT | ChannelLayout::FRONT_RIGHT,
        n => {
            let mut m = 0u32;
            for i in 0..n {
                let flag = 1u32 << i;
                m |= flag;
            }
            m
        }
    };
    ChannelLayout::from_mask(mask)
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn layout_indexing() {
        let l = ChannelLayout::STEREO;
        assert_eq!(l.count(), 2);
        assert_eq!(l.index_of(ChannelLayout::FRONT_LEFT), Some(0));
        assert_eq!(l.index_of(ChannelLayout::FRONT_RIGHT), Some(1));
        assert_eq!(l.front_left_index(), 0);
        assert_eq!(l.front_right_index(), 1);
    }

    #[test]
    fn layout_indexing_51() {
        let l = ChannelLayout::FIVE_POINT_ONE;
        assert_eq!(l.count(), 6);
        assert_eq!(l.index_of(ChannelLayout::LFE), Some(3));
        assert_eq!(l.index_of(ChannelLayout::BACK_LEFT), Some(4));
        assert_eq!(l.front_left_index(), 0);
        assert_eq!(l.front_right_index(), 1);
    }

    #[test]
    fn channels_validation() {
        assert!(Channels::new(0).is_err());
        assert!(Channels::new(33).is_err());
        assert_eq!(Channels::new(6).unwrap().get(), 6);
        assert_eq!(Channels::STEREO.get(), 2);
    }
}
