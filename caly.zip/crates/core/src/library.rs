//! Music library management, recursive scanning, and metadata classification.

use std::collections::BTreeMap;
use std::path::Path;
use std::time::Duration;

/// A single song entry in the library.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct Song {
    /// Absolute file path or URI.
    pub uri: String,
    /// Song title (falling back to filename stem).
    pub title: String,
    /// Artist name.
    pub artist: Option<String>,
    /// Album name.
    pub album: Option<String>,
    /// Release year.
    pub year: Option<u32>,
    /// Duration when known.
    pub duration: Option<Duration>,
    /// Track number if present.
    pub track_number: Option<u32>,
    /// Music genre if present.
    pub genre: Option<String>,
}

/// A structured album in the library.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct Album {
    /// Album title.
    pub title: String,
    /// Album artist.
    pub artist: Option<String>,
    /// Release year.
    pub year: Option<u32>,
    /// Tracks belonging to this album (in order).
    pub songs: Vec<Song>,
}

/// The indexed music library supporting one-key directory scanning and multi-dimensional classification.
#[derive(Debug, Clone, Default)]
pub struct Library {
    /// All indexed songs.
    songs: Vec<Song>,
}

impl Library {
    /// Creates an empty library.
    pub fn new() -> Self {
        Self::default()
    }

    /// Recursively scans a root directory for all audio tracks.
    pub fn scan_dir(root: &Path, extensions: &[String]) -> Self {
        let mut out_paths = Vec::new();
        let mut stack = vec![root.to_path_buf()];
        while let Some(dir) = stack.pop() {
            let Ok(rd) = std::fs::read_dir(&dir) else { continue; };
            for entry in rd.flatten() {
                let p = entry.path();
                if p.is_symlink() { continue; }
                if p.is_dir() {
                    stack.push(p);
                } else if p.is_file() {
                    if let Some(ext) = p.extension().and_then(|e| e.to_str()) {
                        let ext_l = ext.to_ascii_lowercase();
                        if extensions.iter().any(|x| x.to_ascii_lowercase() == ext_l) {
                            out_paths.push(p);
                        }
                    }
                }
            }
        }
        out_paths.sort();

        let mut songs = Vec::with_capacity(out_paths.len());
        for p in out_paths {
            let stem = p.file_stem().and_then(|s| s.to_str()).unwrap_or("Unknown").to_string();
            let uri = p.to_string_lossy().into_owned();
            songs.push(Song {
                uri,
                title: stem,
                artist: None,
                album: None,
                year: None,
                duration: None,
                track_number: None,
                genre: None,
            });
        }

        Self { songs }
    }

    /// Adds a song to the library.
    pub fn add_song(&mut self, song: Song) {
        self.songs.push(song);
    }

    /// All songs currently indexed.
    pub fn songs(&self) -> &[Song] {
        &self.songs
    }

    /// Number of tracks in library.
    pub fn len(&self) -> usize {
        self.songs.len()
    }

    /// True if library has no tracks.
    pub fn is_empty(&self) -> bool {
        self.songs.is_empty()
    }

    /// Classifies and groups songs by Artist.
    pub fn by_artist(&self) -> BTreeMap<String, Vec<&Song>> {
        let mut map: BTreeMap<String, Vec<&Song>> = BTreeMap::new();
        for song in &self.songs {
            let key = song.artist.as_deref().unwrap_or("Unknown Artist").to_string();
            map.entry(key).or_default().push(song);
        }
        map
    }

    /// Classifies and groups songs into structured Albums.
    pub fn by_album(&self) -> BTreeMap<String, Album> {
        let mut map: BTreeMap<String, Album> = BTreeMap::new();
        for song in &self.songs {
            let key = song.album.as_deref().unwrap_or("Unknown Album").to_string();
            let entry = map.entry(key.clone()).or_insert_with(|| Album {
                title: key,
                artist: song.artist.clone(),
                year: song.year,
                songs: Vec::new(),
            });
            entry.songs.push(song.clone());
        }
        map
    }

    /// Classifies songs by Year.
    pub fn by_year(&self) -> BTreeMap<Option<u32>, Vec<&Song>> {
        let mut map: BTreeMap<Option<u32>, Vec<&Song>> = BTreeMap::new();
        for song in &self.songs {
            map.entry(song.year).or_default().push(song);
        }
        map
    }

    /// Classifies songs by Genre.
    pub fn by_genre(&self) -> BTreeMap<String, Vec<&Song>> {
        let mut map: BTreeMap<String, Vec<&Song>> = BTreeMap::new();
        for song in &self.songs {
            let key = song.genre.as_deref().unwrap_or("Unknown Genre").to_string();
            map.entry(key).or_default().push(song);
        }
        map
    }
}

/// Helper for space-insensitive and case-insensitive matching across song metadata.
#[derive(Debug, Clone)]
pub struct StrippedText {
    lowered: String,
    origins: Vec<(usize, usize)>,
}

impl StrippedText {
    /// Prepares text for space-insensitive matching.
    pub fn new(text: &str) -> Self {
        let mut lowered = String::new();
        let mut origins = Vec::new();
        for (start, ch) in text.char_indices() {
            if ch.is_whitespace() {
                continue;
            }
            let end = start + ch.len_utf8();
            for low in ch.to_lowercase() {
                lowered.push(low);
                origins.push((start, end));
            }
        }
        Self { lowered, origins }
    }

    /// True if `term` matches the text, ignoring spaces and casing.
    pub fn matches(&self, term: &str) -> bool {
        self.first_range(term).is_some()
    }

    /// First byte range in the original text matching `term`.
    pub fn first_range(&self, term: &str) -> Option<(usize, usize)> {
        self.find_all(term).into_iter().next()
    }

    /// All occurrence byte ranges of `term` in coordinates of the original text.
    pub fn find_all(&self, term: &str) -> Vec<(usize, usize)> {
        let needle = StrippedText::new(term);
        if needle.lowered.is_empty() || self.lowered.is_empty() {
            return Vec::new();
        }
        let mut out = Vec::new();
        let mut from = 0;
        while let Some(relative) = self.lowered[from..].find(needle.lowered.as_str()) {
            let start = from + relative;
            let end = start + needle.lowered.len();
            let first_char = self.lowered[..start].chars().count();
            let last_char = self.lowered[..end].chars().count().saturating_sub(1);
            if let (Some(o_start), Some(o_end)) = (self.origins.get(first_char), self.origins.get(last_char)) {
                out.push((o_start.0, o_end.1));
            }
            from = end;
        }
        out
    }
}

impl From<&Song> for crate::queue::Track {
    fn from(song: &Song) -> Self {
        Self {
            id: crate::queue::TrackId(0),
            uri: song.uri.clone(),
            title: song.title.clone(),
            artist: song.artist.clone(),
            album: song.album.clone(),
            duration: song.duration,
        }
    }
}

impl From<Song> for crate::queue::Track {
    fn from(song: Song) -> Self {
        Self {
            id: crate::queue::TrackId(0),
            uri: song.uri,
            title: song.title,
            artist: song.artist,
            album: song.album,
            duration: song.duration,
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn stripped_text_matches_space_and_case_insensitively() {
        let text = StrippedText::new("Love  Story");
        assert!(text.matches("lovestory"));
        assert!(text.matches("Love Story"));
        assert!(text.matches("love"));
        assert!(text.matches("story"));
        assert!(!text.matches("story love"));
    }

    #[test]
    fn library_groups_by_metadata() {
        let mut lib = Library::new();
        lib.add_song(Song {
            uri: "a.mp3".into(),
            title: "Song A".into(),
            artist: Some("Artist 1".into()),
            album: Some("Album X".into()),
            year: Some(2024),
            duration: None,
            track_number: None,
            genre: Some("Rock".into()),
        });
        lib.add_song(Song {
            uri: "b.mp3".into(),
            title: "Song B".into(),
            artist: Some("Artist 1".into()),
            album: Some("Album Y".into()),
            year: Some(2025),
            duration: None,
            track_number: None,
            genre: Some("Jazz".into()),
        });

        let by_artist = lib.by_artist();
        assert_eq!(by_artist.get("Artist 1").unwrap().len(), 2);

        let by_album = lib.by_album();
        assert_eq!(by_album.len(), 2);
    }
}
