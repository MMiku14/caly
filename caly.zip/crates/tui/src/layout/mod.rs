//! Configurable pane layout tree and DSL parser: `H(2:1, queue, V(2:1, cover, lyrics))`.

mod parser;
pub use parser::parse;

/// Different UI panes available for display.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash)]
pub enum PaneKind {
    /// Playback queue track list.
    Queue,
    /// Music library collection table.
    Library,
    /// Album artwork cover pane.
    Cover,
    /// Synced or plain lyrics pane.
    Lyrics,
    /// Audio signal flow & metadata pane.
    Metadata,
    /// Frequency spectrum visualizer pane.
    Visualizer,
}

impl PaneKind {
    /// Parses pane name.
    pub fn parse(s: &str) -> Option<Self> {
        match s.trim().to_ascii_lowercase().as_str() {
            "queue" => Some(Self::Queue),
            "library" => Some(Self::Library),
            "cover" => Some(Self::Cover),
            "lyrics" => Some(Self::Lyrics),
            "metadata" => Some(Self::Metadata),
            "visualizer" => Some(Self::Visualizer),
            _ => None,
        }
    }

    /// Display title for the pane header.
    pub fn title(self) -> &'static str {
        match self {
            Self::Queue => "Queue",
            Self::Library => "Library",
            Self::Cover => "Cover",
            Self::Lyrics => "Lyrics",
            Self::Metadata => "Metadata",
            Self::Visualizer => "Visualizer",
        }
    }
}

/// Data source target for data-driven panes (Cover, Lyrics, Metadata).
#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash, Default)]
pub enum PaneSource {
    /// Currently playing song (default).
    #[default]
    Playing,
    /// Currently selected/hovered item in the queue or library.
    Hovered,
}

impl PaneSource {
    /// Parses data source suffix.
    pub fn parse(s: &str) -> Option<Self> {
        match s.trim().to_ascii_lowercase().as_str() {
            "playing" => Some(Self::Playing),
            "hovered" | "hover" => Some(Self::Hovered),
            _ => None,
        }
    }
}

/// Split orientation.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum SplitDir {
    /// Horizontal split: left and right panes.
    Horizontal,
    /// Vertical split: top and bottom panes.
    Vertical,
}

/// Recursive layout tree node.
#[derive(Debug, Clone, PartialEq)]
pub enum PaneLayout {
    /// Leaf pane.
    Pane(PaneKind, PaneSource),
    /// Container split node.
    Split {
        dir: SplitDir,
        ratio: (u32, u32),
        first: Box<PaneLayout>,
        second: Box<PaneLayout>,
    },
}

impl PaneLayout {
    /// Default standard layout: `H(1:2, cover, queue)`
    pub fn default_standard() -> Self {
        Self::Split {
            dir: SplitDir::Horizontal,
            ratio: (1, 2),
            first: Box::new(Self::Pane(PaneKind::Cover, PaneSource::Playing)),
            second: Box::new(Self::Pane(PaneKind::Queue, PaneSource::Playing)),
        }
    }

    /// Full layout with library: `H(1:2, library, V(1:1, cover, lyrics))`
    pub fn default_split() -> Self {
        Self::Split {
            dir: SplitDir::Horizontal,
            ratio: (1, 2),
            first: Box::new(Self::Pane(PaneKind::Library, PaneSource::Playing)),
            second: Box::new(Self::Split {
                dir: SplitDir::Vertical,
                ratio: (1, 1),
                first: Box::new(Self::Pane(PaneKind::Cover, PaneSource::Playing)),
                second: Box::new(Self::Pane(PaneKind::Lyrics, PaneSource::Playing)),
            }),
        }
    }
}
