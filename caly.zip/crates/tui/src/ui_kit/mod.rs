//! Modern TUI component kit: interactive prompt, auto-completion, key hints, and bounded popups.

pub mod model;
pub mod render;

pub use model::{CommandCompletion, KeyHelpEntry, KeyHint, Prompt, PromptBuffer};
pub use render::*;
