//! Reusable rendering primitives for prompts, popups, key hints, and completion menus.

use ratatui::{
    layout::Rect,
    style::{Color, Modifier, Style},
    text::{Line, Span, Text},
    widgets::{Block, Borders, Clear, Paragraph, Wrap},
    Frame,
};

use crate::ui_kit::model::{CommandCompletion, KeyHelpEntry, KeyHint, Prompt};

/// Styling properties for the single-line command prompt.
#[derive(Debug, Clone)]
pub struct PromptLineStyle {
    /// Base input text style.
    pub base: Style,
    /// Prefix style (e.g. bold cyan ":").
    pub prefix: Style,
    /// Ghost-text autocomplete suggestion style.
    pub suggestion: Style,
}

impl Default for PromptLineStyle {
    fn default() -> Self {
        Self {
            base: Style::default().fg(Color::Rgb(192, 202, 245)),
            prefix: Style::default()
                .fg(Color::Rgb(125, 207, 255))
                .add_modifier(Modifier::BOLD),
            suggestion: Style::default()
                .fg(Color::Rgb(86, 95, 137))
                .add_modifier(Modifier::DIM),
        }
    }
}

/// Styling properties for the command autocompletion menu.
#[derive(Debug, Clone)]
pub struct CompletionListStyle {
    /// Base unselected candidate style.
    pub base: Style,
    /// Active selected candidate style.
    pub selected: Style,
}

impl Default for CompletionListStyle {
    fn default() -> Self {
        Self {
            base: Style::default().fg(Color::White).bg(overlay_background()),
            selected: default_completion_selected_style(),
        }
    }
}

/// Styling properties for bottom hotkey hint cells.
#[derive(Debug, Clone)]
pub struct KeyHintsStyle {
    /// Base background/text style.
    pub base: Style,
    /// Key character style (e.g. bold yellow).
    pub key: Style,
    /// Separator style.
    pub separator: Style,
    /// Action description style.
    pub description: Style,
    /// Separator string (e.g. " ").
    pub separator_text: String,
    /// Maximum configured columns.
    pub columns: usize,
}

impl Default for KeyHintsStyle {
    fn default() -> Self {
        Self {
            base: Style::default().fg(Color::Rgb(192, 202, 245)).bg(overlay_background()),
            key: Style::default()
                .fg(Color::Rgb(224, 175, 104))
                .add_modifier(Modifier::BOLD),
            separator: Style::default().fg(Color::Rgb(86, 95, 137)),
            description: Style::default().fg(Color::Rgb(192, 202, 245)),
            separator_text: " ".to_string(),
            columns: 5,
        }
    }
}

/// Styling properties for keybinding help dialogs.
#[derive(Debug, Clone)]
pub struct KeyHelpDialogStyle {
    /// Underlying popup dialog frame style.
    pub popup: PopupDialogStyle,
    /// Keybinding label style.
    pub key: Style,
    /// Functional description style.
    pub description: Style,
    /// Subdued / dimmed text style.
    pub muted: Style,
    /// Hint text pinned to the bottom of the dialog.
    pub close_hint: String,
    /// Maximum visual width of key labels column.
    pub max_key_width: usize,
}

impl Default for KeyHelpDialogStyle {
    fn default() -> Self {
        Self {
            popup: PopupDialogStyle {
                min_height: 8,
                max_height: 34,
                ..PopupDialogStyle::default()
            },
            key: Style::default()
                .fg(Color::Rgb(224, 175, 104))
                .add_modifier(Modifier::BOLD),
            description: Style::default().fg(Color::Rgb(192, 202, 245)),
            muted: Style::default()
                .fg(Color::Rgb(86, 95, 137))
                .add_modifier(Modifier::DIM),
            close_hint: "esc / q / enter / f1 close".to_string(),
            max_key_width: 24,
        }
    }
}

/// Layout and style bounds for centered popup dialogs.
#[derive(Debug, Clone)]
pub struct PopupDialogStyle {
    /// Dialog container base style.
    pub base: Style,
    /// Border style.
    pub border: Style,
    /// Minimum allowable width.
    pub min_width: u16,
    /// Maximum allowable width.
    pub max_width: u16,
    /// Minimum allowable height.
    pub min_height: u16,
    /// Maximum allowable height.
    pub max_height: u16,
    /// Minimum margin from horizontal window borders.
    pub horizontal_margin: u16,
    /// Minimum margin from vertical window borders.
    pub vertical_margin: u16,
}

impl Default for PopupDialogStyle {
    fn default() -> Self {
        let base = Style::default().bg(overlay_background());
        Self {
            base,
            border: Style::default().fg(Color::Rgb(125, 207, 255)),
            min_width: 40,
            max_width: 96,
            min_height: 6,
            max_height: 12,
            horizontal_margin: 4,
            vertical_margin: 2,
        }
    }
}

/// Keep overlay surfaces on the terminal's configured default background.
pub const fn overlay_background() -> Color {
    Color::Reset
}

/// Helper building a CompletionListStyle with custom foreground color.
pub fn completion_list_style(foreground: Color) -> CompletionListStyle {
    CompletionListStyle {
        base: Style::default().fg(foreground).bg(overlay_background()),
        selected: default_completion_selected_style(),
    }
}

/// Computes the bounded centered popup area adhering to min/max/margin constraints.
pub fn centered_popup_area(area: Rect, style: &PopupDialogStyle) -> Option<Rect> {
    if area.width < style.min_width.min(20) || area.height < style.min_height {
        return None;
    }
    let available_width = area.width.saturating_sub(style.horizontal_margin).max(1);
    let available_height = area.height.saturating_sub(style.vertical_margin).max(1);
    let width = available_width
        .min(style.max_width)
        .max(available_width.min(style.min_width));
    let height = available_height
        .min(style.max_height)
        .max(available_height.min(style.min_height));
    Some(Rect::new(
        area.x + area.width.saturating_sub(width) / 2,
        area.y + area.height.saturating_sub(height) / 2,
        width,
        height,
    ))
}

/// Renders a centered popup dialog.
pub fn draw_popup_dialog(
    frame: &mut Frame<'_>,
    area: Rect,
    title: &str,
    text: Text<'static>,
    style: &PopupDialogStyle,
) -> Option<Rect> {
    draw_popup_dialog_scrolled(frame, area, title, text, style, 0)
}

/// Like [`draw_popup_dialog`] but scrolls the text content vertically by `scroll` rows.
pub fn draw_popup_dialog_scrolled(
    frame: &mut Frame<'_>,
    area: Rect,
    title: &str,
    text: Text<'static>,
    style: &PopupDialogStyle,
    scroll: usize,
) -> Option<Rect> {
    let popup = centered_popup_area(area, style)?;
    frame.render_widget(Clear, popup);
    frame.render_widget(Block::default().style(style.base), popup);
    frame.render_widget(
        Paragraph::new(text)
            .block(
                Block::default()
                    .borders(Borders::ALL)
                    .title(title.to_string())
                    .border_style(style.border),
            )
            .style(style.base)
            .scroll((scroll as u16, 0))
            .wrap(Wrap { trim: true }),
        popup,
    );
    Some(popup)
}

/// Renders a keybinding help dialog.
pub fn draw_key_help_dialog(
    frame: &mut Frame<'_>,
    area: Rect,
    title: &str,
    entries: &[KeyHelpEntry],
    style: &KeyHelpDialogStyle,
) -> Option<Rect> {
    draw_key_help_dialog_scrolled(frame, area, title, entries, style, 0)
}

/// Like [`draw_key_help_dialog`] but scrolls the entry list by `scroll` rows.
pub fn draw_key_help_dialog_scrolled(
    frame: &mut Frame<'_>,
    area: Rect,
    title: &str,
    entries: &[KeyHelpEntry],
    style: &KeyHelpDialogStyle,
    scroll: usize,
) -> Option<Rect> {
    let key_width = entries
        .iter()
        .map(|entry| entry.keys.chars().count())
        .max()
        .unwrap_or(0)
        .min(style.max_key_width);
    let mut lines = Vec::with_capacity(entries.len().saturating_add(2));
    if entries.is_empty() {
        lines.push(Line::from(Span::styled(
            "No bindings available",
            style.muted,
        )));
    } else {
        for entry in entries {
            let keys = truncate_for_width(&entry.keys, key_width.max(1));
            let padding = " ".repeat(key_width.saturating_sub(keys.chars().count()) + 2);
            lines.push(Line::from(vec![
                Span::styled(keys, style.key),
                Span::styled(padding, style.popup.base),
                Span::styled(entry.description.clone(), style.description),
            ]));
        }
    }
    if !style.close_hint.is_empty() {
        lines.push(Line::from(Span::styled(
            style.close_hint.clone(),
            style.muted,
        )));
    }
    draw_popup_dialog_scrolled(frame, area, title, Text::from(lines), &style.popup, scroll)
}

/// Renders the interactive command prompt with prefix, text, ghost suggestion, and hardware cursor position.
pub fn draw_prompt_line(
    frame: &mut Frame<'_>,
    prompt: &Prompt,
    completion: Option<&CommandCompletion>,
    area: Rect,
    style: &PromptLineStyle,
) -> Option<(u16, u16)> {
    if area.width == 0 || area.height == 0 {
        return None;
    }

    let mut spans = vec![
        Span::styled(prompt_prefix(prompt), style.prefix),
        Span::styled(prompt.buffer().input.clone(), style.base),
    ];
    if prompt.is_command() && prompt.buffer().cursor == prompt.buffer().input.len() {
        if let Some(completion) = completion {
            let suggestion = completion.suggestion_suffix();
            if !suggestion.is_empty() {
                spans.push(Span::styled(suggestion, style.suggestion));
            }
        }
    }

    frame.render_widget(Paragraph::new(Line::from(spans)).style(style.base), area);
    let input_width = prompt.buffer().cursor_columns() as u16;
    let prefix_width = prompt_prefix(prompt).chars().count() as u16;
    let cursor_x = prefix_width
        .saturating_add(input_width)
        .min(area.width.saturating_sub(1));
    let position = (area.x.saturating_add(cursor_x), area.y);
    frame.set_cursor_position(position);
    Some(position)
}

/// Calculates required rows to display completion list up to max_rows.
pub fn completion_rows(completion: Option<&CommandCompletion>, max_rows: usize) -> u16 {
    completion
        .filter(|completion| !completion.candidates.is_empty())
        .map(|completion| completion.candidates.len().min(max_rows) as u16)
        .unwrap_or(0)
}

/// Renders the dropdown autocompletion candidate list.
pub fn draw_completion_list(
    frame: &mut Frame<'_>,
    completion: &CommandCompletion,
    area: Rect,
    style: &CompletionListStyle,
) {
    if completion.candidates.is_empty() || area.width == 0 || area.height == 0 {
        return;
    }

    frame.render_widget(Block::default().style(style.base), area);

    let visible = area.height as usize;
    let selected = completion.selected.min(completion.candidates.len().saturating_sub(1));
    let start = selected.saturating_sub(visible.saturating_sub(1));
    let mut lines = Vec::with_capacity(visible);
    for row in 0..visible {
        let index = start + row;
        let Some(candidate) = completion.candidates.get(index) else {
            lines.push(Line::from(Span::styled(
                " ".repeat(area.width as usize),
                style.base,
            )));
            continue;
        };
        let selected_row = index == selected;
        let row_style = if selected_row {
            style.selected
        } else {
            style.base
        };
        let marker = if selected_row { "> " } else { "  " };
        let mut text = truncate_for_width(&format!("{marker}{candidate}"), area.width as usize);
        let used = text.chars().count();
        if used < area.width as usize {
            text.push_str(&" ".repeat(area.width as usize - used));
        }
        lines.push(Line::from(Span::styled(text, row_style)));
    }

    frame.render_widget(Paragraph::new(Text::from(lines)).style(style.base), area);
}

/// Calculates visual columns for hotkey hints based on screen width.
pub fn key_hint_columns(configured: usize, width: u16) -> usize {
    let configured = configured.max(1);
    let max_by_width = (usize::from(width) / 24).max(1);
    configured.min(max_by_width).max(1)
}

/// Calculates required rows to display hints.
pub fn key_hint_rows(count: usize, columns: usize) -> u16 {
    count.div_ceil(columns.max(1)).max(1) as u16
}

/// Renders responsive multi-column hotkey hints.
pub fn draw_key_hints(frame: &mut Frame<'_>, hints: &[KeyHint], area: Rect, style: &KeyHintsStyle) {
    if hints.is_empty() || area.width == 0 || area.height == 0 {
        return;
    }

    frame.render_widget(Block::default().style(style.base), area);

    let columns = key_hint_columns(style.columns, area.width);
    let rows = key_hint_rows(hints.len(), columns).min(area.height);
    let cell_width = (area.width as usize / columns.max(1)).max(1);
    let mut lines = Vec::with_capacity(rows as usize);
    for row in 0..rows as usize {
        let mut spans = Vec::new();
        for col in 0..columns {
            let index = row * columns + col;
            if let Some(hint) = hints.get(index) {
                push_key_hint_cell(&mut spans, hint, cell_width, style);
            } else if col + 1 < columns {
                spans.push(Span::styled(" ".repeat(cell_width), style.base));
            }
        }
        lines.push(Line::from(spans));
    }

    frame.render_widget(Paragraph::new(Text::from(lines)).style(style.base), area);
}

/// Default highlight style for selected completion candidates.
pub fn default_completion_selected_style() -> Style {
    Style::default()
        .fg(Color::Black)
        .bg(Color::White)
        .add_modifier(Modifier::BOLD)
}

fn push_key_hint_cell(
    spans: &mut Vec<Span<'static>>,
    hint: &KeyHint,
    cell_width: usize,
    style: &KeyHintsStyle,
) {
    let key = truncate_for_width(&hint.key, cell_width);
    let key_width = key.chars().count();
    spans.push(Span::styled(key, style.key));

    let mut used = key_width;
    if used < cell_width {
        let separator = truncate_for_width(&style.separator_text, cell_width - used);
        used += separator.chars().count();
        spans.push(Span::styled(separator, style.separator));
    }
    if used < cell_width {
        let desc = truncate_for_width(&hint.label, cell_width - used);
        used += desc.chars().count();
        spans.push(Span::styled(desc, style.description));
    }
    if used < cell_width {
        spans.push(Span::styled(" ".repeat(cell_width - used), style.base));
    }
}

fn prompt_prefix(prompt: &Prompt) -> &str {
    prompt.prefix()
}

fn truncate_for_width(value: &str, width: usize) -> String {
    if width == 0 {
        return String::new();
    }
    if width <= 3 {
        return value.chars().take(width).collect();
    }
    let mut out = String::new();
    for ch in value.chars() {
        if out.chars().count() + 1 >= width {
            out.push_str("...");
            return out;
        }
        out.push(ch);
    }
    out
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn overlay_background_uses_terminal_reset() {
        assert_eq!(overlay_background(), Color::Reset);
        assert_eq!(PopupDialogStyle::default().base.bg, Some(Color::Reset));
    }

    #[test]
    fn completion_style_uses_shared_reset_background() {
        let style = completion_list_style(Color::Cyan);
        assert_eq!(style.base.fg, Some(Color::Cyan));
        assert_eq!(style.base.bg, Some(Color::Reset));
        assert_eq!(style.selected, default_completion_selected_style());
    }
}
