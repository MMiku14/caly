//! Data models for interactive command prompt, auto-completion, and key hints.

/// Text buffer and cursor tracker for the prompt input.
#[derive(Debug, Clone, Default, PartialEq, Eq)]
pub struct PromptBuffer {
    /// The user input string.
    pub input: String,
    /// Byte offset of the cursor.
    pub cursor: usize,
}

impl PromptBuffer {
    /// Returns the number of visual columns up to the current cursor position.
    pub fn cursor_columns(&self) -> usize {
        let up_to_cursor = if self.cursor >= self.input.len() {
            &self.input[..]
        } else {
            &self.input[..self.cursor]
        };
        up_to_cursor.chars().count()
    }

    /// Appends a character at the cursor position.
    pub fn insert_char(&mut self, c: char) {
        if self.cursor >= self.input.len() {
            self.input.push(c);
            self.cursor = self.input.len();
        } else {
            let mut new_str = String::with_capacity(self.input.len() + c.len_utf8());
            new_str.push_str(&self.input[..self.cursor]);
            new_str.push(c);
            new_str.push_str(&self.input[self.cursor..]);
            self.input = new_str;
            self.cursor += c.len_utf8();
        }
    }

    /// Deletes the character immediately preceding the cursor.
    pub fn backspace(&mut self) {
        if self.cursor == 0 || self.input.is_empty() {
            return;
        }
        let prev_char_boundary = self.input[..self.cursor]
            .char_indices()
            .last()
            .map(|(idx, _)| idx)
            .unwrap_or(0);
        self.input.replace_range(prev_char_boundary..self.cursor, "");
        self.cursor = prev_char_boundary;
    }
}

/// Interactive command or search prompt.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct Prompt {
    prefix: String,
    buffer: PromptBuffer,
    is_command: bool,
}

impl Prompt {
    /// Creates a new prompt.
    pub fn new(prefix: impl Into<String>, is_command: bool) -> Self {
        Self {
            prefix: prefix.into(),
            buffer: PromptBuffer::default(),
            is_command,
        }
    }

    /// Returns the prompt prefix (e.g. ":" or "/").
    pub fn prefix(&self) -> &str {
        &self.prefix
    }

    /// Immutable reference to the input buffer.
    pub fn buffer(&self) -> &PromptBuffer {
        &self.buffer
    }

    /// Mutable reference to the input buffer.
    pub fn buffer_mut(&mut self) -> &mut PromptBuffer {
        &mut self.buffer
    }

    /// True if this prompt represents a shell command line.
    pub fn is_command(&self) -> bool {
        self.is_command
    }

    /// Replaces the input string and moves cursor to the end.
    pub fn set_input(&mut self, text: impl Into<String>) {
        let s = text.into();
        self.buffer.cursor = s.len();
        self.buffer.input = s;
    }
}

/// Completion suggestions for the current command prompt.
#[derive(Debug, Clone, Default, PartialEq, Eq)]
pub struct CommandCompletion {
    /// List of matched candidate strings.
    pub candidates: Vec<String>,
    /// Index of the currently highlighted candidate.
    pub selected: usize,
    /// Active query prefix.
    pub query: String,
}

impl CommandCompletion {
    /// Creates a completion state.
    pub fn new(candidates: Vec<String>, query: impl Into<String>) -> Self {
        Self {
            candidates,
            selected: 0,
            query: query.into(),
        }
    }

    /// Computes the ghost-text suffix for inline auto-completion.
    pub fn suggestion_suffix(&self) -> &str {
        if let Some(candidate) = self.candidates.get(self.selected) {
            if candidate.starts_with(&self.query) {
                return &candidate[self.query.len()..];
            }
        }
        ""
    }

    /// Selects the next candidate wrapping around.
    pub fn select_next(&mut self) {
        if !self.candidates.is_empty() {
            self.selected = (self.selected + 1) % self.candidates.len();
        }
    }

    /// Selects the previous candidate wrapping around.
    pub fn select_prev(&mut self) {
        if !self.candidates.is_empty() {
            self.selected = if self.selected == 0 {
                self.candidates.len() - 1
            } else {
                self.selected - 1
            };
        }
    }
}

/// Context-aware hotkey hint item shown in the bottom bar.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct KeyHint {
    /// Short key representation (e.g. "Space", "Enter", "Tab", "q").
    pub key: String,
    /// Human-readable action label (e.g. "Play/Pause", "Select", "Help").
    pub label: String,
}

impl KeyHint {
    /// Constructs a key hint.
    pub fn new(key: impl Into<String>, label: impl Into<String>) -> Self {
        Self {
            key: key.into(),
            label: label.into(),
        }
    }
}

/// Detailed keybinding entry for the help dialog.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct KeyHelpEntry {
    /// Keybinding label (e.g. "<Space>", "j / k", ":volume").
    pub keys: String,
    /// Functional description.
    pub description: String,
}

impl KeyHelpEntry {
    /// Constructs a help entry.
    pub fn new(keys: impl Into<String>, description: impl Into<String>) -> Self {
        Self {
            keys: keys.into(),
            description: description.into(),
        }
    }
}
