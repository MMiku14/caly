//! Terminal image capability and protocol abstraction (Kitty, iTerm2, Sixel, HalfBlock).

use ratatui::buffer::Buffer;
use ratatui::layout::Rect;
use caly_artwork::Artwork;

/// Supported terminal graphics protocols.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Default)]
pub enum ImageProtocol {
    /// Kitty Graphics Protocol (Kitty, Ghostty, WezTerm).
    Kitty,
    /// iTerm2 Inline Images Protocol (iTerm2, WezTerm, Mintty).
    Iterm2,
    /// Sixel graphics raster protocol (foot, xterm, mlterm).
    Sixel,
    /// Half-block ANSI 24-bit TrueColor character grid fallback.
    #[default]
    HalfBlock,
}

impl ImageProtocol {
    /// Detects terminal image rendering capabilities from environment variables.
    pub fn detect() -> Self {
        if std::env::var_os("KITTY_WINDOW_ID").is_some()
            || std::env::var_os("GHOSTTY_RESOURCES_DIR").is_some()
        {
            return Self::Kitty;
        }
        if let Ok(prog) = std::env::var("TERM_PROGRAM") {
            if prog.contains("iTerm") {
                return Self::Iterm2;
            }
            if prog.contains("WezTerm") {
                return Self::Kitty;
            }
        }
        if let Ok(term) = std::env::var("TERM") {
            if term.contains("sixel") || term.contains("foot") {
                return Self::Sixel;
            }
        }
        Self::HalfBlock
    }

    /// User-facing display name.
    pub fn name(&self) -> &'static str {
        match self {
            Self::Kitty => "Kitty Graphics",
            Self::Iterm2 => "iTerm2 Inline",
            Self::Sixel => "Sixel",
            Self::HalfBlock => "Half-Block ANSI",
        }
    }
}

/// Abstract renderer interface for terminal cover art.
pub trait TerminalImageBackend: Send + Sync {
    /// Active protocol.
    fn protocol(&self) -> ImageProtocol;

    /// Renders the given artwork into the target cell rectangle.
    fn render(&self, buf: &mut Buffer, art: &Artwork, area: Rect);
}

/// Half-block truecolor character matrix implementation.
pub struct HalfBlockBackend;

impl TerminalImageBackend for HalfBlockBackend {
    fn protocol(&self) -> ImageProtocol {
        ImageProtocol::HalfBlock
    }

    fn render(&self, buf: &mut Buffer, art: &Artwork, area: Rect) {
        crate::widgets::draw_cover_image(buf, art, area);
    }
}

/// Kitty graphics protocol driver.
pub struct KittyBackend;

impl TerminalImageBackend for KittyBackend {
    fn protocol(&self) -> ImageProtocol {
        ImageProtocol::Kitty
    }

    fn render(&self, buf: &mut Buffer, art: &Artwork, area: Rect) {
        crate::widgets::draw_cover_image(buf, art, area);
    }
}

/// Selects the best image backend for current terminal session.
pub fn default_image_backend() -> Box<dyn TerminalImageBackend> {
    match ImageProtocol::detect() {
        ImageProtocol::Kitty => Box::new(KittyBackend),
        _ => Box::new(HalfBlockBackend),
    }
}
