//! Music library table view: multi-column track list with artist, album, and btop scrollbar.

use caly_core::library::Library;
use ratatui::layout::{Constraint, Rect};
use ratatui::style::{Modifier, Style};
use ratatui::text::{Line, Span};
use ratatui::widgets::{Block, BorderType, Borders, Cell, Row, Table, TableState};
use ratatui::Frame;

use crate::state::UiState;
use crate::theme::color;

/// Renders the library table pane.
pub fn draw_library_pane(
    f: &mut Frame<'_>,
    area: Rect,
    ui: &mut UiState,
    library: &Library,
    table_state: &mut TableState,
) {
    let border_type = match ui.settings.border_style.as_str() {
        "plain" => BorderType::Plain,
        "thick" => BorderType::Thick,
        "double" => BorderType::Double,
        _ => BorderType::Rounded,
    };

    let mut block = Block::default().title(format!(" Music Library ({} tracks) ", library.len()));
    if ui.settings.borders {
        block = block
            .borders(Borders::ALL)
            .border_type(border_type)
            .border_style(Style::new().fg(color::ACCENT_CYAN));
    }
    if ui.settings.bg_coverage {
        block = block.style(Style::new().bg(color::SURFACE));
    }

    let inner = block.inner(area);
    f.render_widget(block, area);

    if inner.height <= 2 || inner.width == 0 {
        return;
    }

    if library.is_empty() {
        let hint = "  Library is empty. Press ':' and run ':scan <directory>' to index audio files.";
        f.render_widget(ratatui::widgets::Paragraph::new(hint).style(Style::new().fg(color::MUTED)), inner);
        return;
    }

    let header_style = Style::new()
        .fg(color::ACCENT_PURPLE)
        .add_modifier(Modifier::BOLD);

    let header = Row::new(vec![
        Cell::from(Span::styled(" #", header_style)),
        Cell::from(Span::styled("Title", header_style)),
        Cell::from(Span::styled("Artist", header_style)),
        Cell::from(Span::styled("Album", header_style)),
    ])
    .height(1)
    .bottom_margin(1);

    let songs = library.songs();
    let rows: Vec<Row> = songs
        .iter()
        .enumerate()
        .map(|(idx, song)| {
            let num = format!("{:>3}", idx + 1);
            let title = song.title.clone();
            let artist = song.artist.clone().unwrap_or_else(|| "--".to_string());
            let album = song.album.clone().unwrap_or_else(|| "--".to_string());

            Row::new(vec![
                Cell::from(Span::styled(num, Style::new().fg(color::MUTED))),
                Cell::from(Span::styled(title, Style::new().fg(color::FG))),
                Cell::from(Span::styled(artist, Style::new().fg(color::ACCENT_BLUE))),
                Cell::from(Span::styled(album, Style::new().fg(color::MUTED))),
            ])
        })
        .collect();

    let widths = [
        Constraint::Length(4),
        Constraint::Percentage(45),
        Constraint::Percentage(25),
        Constraint::Percentage(25),
    ];

    let table = Table::new(rows, widths)
        .header(header)
        .highlight_style(
            Style::new()
                .bg(color::ACTIVE_BG)
                .fg(color::ACCENT_CYAN)
                .add_modifier(Modifier::BOLD),
        );

    f.render_stateful_widget(table, inner, table_state);

    // Render btop scrollbar
    let visible_rows = inner.height.saturating_sub(2) as usize;
    let offset = table_state.offset();
    crate::widgets::render_btop_scrollbar(
        f.buffer_mut(),
        area,
        songs.len(),
        visible_rows,
        offset,
        color::ACCENT_CYAN,
        color::MUTED,
    );
}
