//! View layout coordinator and rendering pipeline.

pub mod browser;
pub mod modals;
pub mod now_playing;
pub mod queue;

use caly_engine::Engine;
use ratatui::layout::{Constraint, Direction, Layout, Rect};
use ratatui::Frame;

use crate::state::{FrameRects, InputKind, Mode, UiState};

/// Central drawing dispatcher.
pub fn draw(f: &mut Frame<'_>, ui: &mut UiState, engine: &Engine) {
    let snap = engine.snapshot();
    let area = f.area();
    ui.frame = Some(FrameRects::default());

    let main_area = if ui.show_browser && ui.browser.is_some() {
        let w = ui.browser_width.min(area.width.saturating_sub(34).max(24));
        let chunks = Layout::horizontal([Constraint::Length(w), Constraint::Min(0)]).split(area);
        if let Some(fr) = ui.frame.as_mut() {
            fr.browser = Some(chunks[0]);
        }
        browser::draw_browser(f, chunks[0], ui);
        chunks[1]
    } else {
        area
    };

    if let Some(fr) = ui.frame.as_mut() {
        fr.main = main_area;
    }

    draw_main(f, main_area, ui, &snap);

    match ui.mode {
        Mode::Input if ui.input_kind == InputKind::QueueFilter => {
            modals::draw_telescope_modal(f, area, ui, &snap);
        }
        Mode::Input => {
            modals::draw_simple_input(f, area, ui);
        }
        Mode::Help => {
            modals::draw_which_key_modal(f, area, ui);
        }
        Mode::SignalFlow => {
            modals::draw_signal_flow_modal(f, area, ui, &snap);
        }
        Mode::Queue => {}
    }
}

fn draw_main(f: &mut Frame<'_>, area: Rect, ui: &mut UiState, snap: &caly_engine::Snapshot) {
    let card_height = if area.height < 22 { 6 } else { 8 };
    let chunks = Layout::default()
        .direction(Direction::Vertical)
        .constraints([
            Constraint::Length(card_height),
            Constraint::Min(5),
            Constraint::Length(1),
        ])
        .split(area);

    now_playing::draw_now_playing(f, chunks[0], ui, snap);
    queue::draw_queue(f, chunks[1], ui, snap);
    queue::draw_statusline(f, chunks[2], ui, snap);
}

/// Helper calculating centered modal rectangle.
pub fn centered_rect(percent_x: u16, percent_y: u16, r: Rect) -> Rect {
    let popup_layout = Layout::default()
        .direction(Direction::Vertical)
        .constraints([
            Constraint::Percentage((100 - percent_y) / 2),
            Constraint::Percentage(percent_y),
            Constraint::Percentage((100 - percent_y) / 2),
        ])
        .split(r);

    Layout::default()
        .direction(Direction::Horizontal)
        .constraints([
            Constraint::Percentage((100 - percent_x) / 2),
            Constraint::Percentage(percent_x),
            Constraint::Percentage((100 - percent_x) / 2),
        ])
        .split(popup_layout[1])[1]
}
