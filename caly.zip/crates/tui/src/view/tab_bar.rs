//! Tab bar navigation and mouse hit testing.

use ratatui::layout::Rect;
use ratatui::style::{Modifier, Style};
use ratatui::text::{Line, Span};
use ratatui::widgets::Paragraph;
use ratatui::Frame;

use crate::state::UiState;
use crate::theme::color;

/// Renders the top tab bar.
pub fn draw_tab_bar(f: &mut Frame<'_>, ui: &mut UiState, area: Rect) {
    let tabs = ["1: Playlist", "2: Library", "3: Lyrics", "4: Explorer"];
    let mut spans = Vec::new();

    for (idx, name) in tabs.iter().enumerate() {
        if idx > 0 {
            spans.push(Span::styled("   ", Style::new().fg(color::MUTED)));
        }
        let is_active = ui.active_tab == idx;
        let style = if is_active {
            Style::new()
                .fg(color::ACCENT_CYAN)
                .add_modifier(Modifier::BOLD)
        } else {
            Style::new().fg(color::MUTED)
        };
        spans.push(Span::styled(format!(" {name} "), style));
    }

    f.render_widget(Paragraph::new(Line::from(spans)), area);
}
