//! Overlay modals: Telescope fuzzy search, Which-Key help, Signal Flow, and text input.

use caly_engine::Snapshot;
use ratatui::layout::{Constraint, Direction, Layout, Rect};
use ratatui::style::{Color, Modifier, Style};
use ratatui::text::{Line, Span};
use ratatui::widgets::{Block, BorderType, Borders, Clear, List, ListItem, ListState, Paragraph, Wrap};
use ratatui::Frame;

use crate::state::{InputKind, UiState};
use crate::theme::{color, icon, style};
use crate::view::centered_rect;

/// Renders the audio processing flow modal dialog.
pub fn draw_signal_flow_modal(
    f: &mut Frame<'_>,
    area: Rect,
    ui: &mut UiState,
    snap: &Snapshot,
) {
    let modal_area = centered_rect(82, 80, area);
    f.render_widget(Clear, modal_area);

    let (border_color, banner_text, banner_style) = if snap.is_bit_perfect {
        (
            color::ACCENT_GREEN,
            format!(
                " {} 100% BIT-PERFECT DIRECT SIGNAL PATH (ZERO ALTERATION) ",
                icon::BIT_PERFECT
            ),
            Style::new().bg(color::ACCENT_GREEN).fg(Color::Black).add_modifier(Modifier::BOLD),
        )
    } else {
        (
            color::ACCENT_CYAN,
            format!(
                " {} HIGH-FIDELITY DSP AUDIO FLOW (STUDIO SINC / BS.775) ",
                icon::FLOW
            ),
            Style::new().bg(color::ACCENT_CYAN).fg(Color::Black).add_modifier(Modifier::BOLD),
        )
    };

    let block = Block::default()
        .borders(Borders::ALL)
        .border_type(BorderType::Rounded)
        .border_style(Style::new().fg(border_color))
        .title(format!(
            " {} Audio Processing Flow Pipeline (Press 'i' or 'Esc' to exit) ",
            icon::FLOW
        ));

    let mut lines = Vec::new();
    lines.push(Line::raw(""));
    lines.push(Line::from(vec![Span::styled(banner_text, banner_style)]));
    lines.push(Line::raw(""));

    let steps = &snap.signal_flow.steps;
    if steps.is_empty() {
        lines.push(Line::from(Span::styled(
            "  Idle - No active audio stream.",
            Style::new().fg(color::MUTED),
        )));
    } else {
        for (idx, step) in steps.iter().enumerate() {
            let num = idx + 1;
            let (status_badge, status_style) = if step.is_passthrough {
                (" [Bit-Perfect] ", Style::new().fg(color::ACCENT_GREEN).add_modifier(Modifier::BOLD))
            } else {
                (" [DSP Active]  ", Style::new().fg(color::ACCENT_YELLOW).add_modifier(Modifier::BOLD))
            };

            lines.push(Line::from(vec![
                Span::styled(format!("  [{num}] "), Style::new().fg(color::ACCENT_CYAN).add_modifier(Modifier::BOLD)),
                Span::styled(format!("{:<15}", step.stage), Style::new().fg(color::FG).add_modifier(Modifier::BOLD)),
                Span::styled(format!("  {}  ", step.processor), Style::new().fg(color::ACCENT_PURPLE)),
                Span::styled(status_badge, status_style),
            ]));

            lines.push(Line::from(vec![
                Span::styled("      IN:  ", Style::new().fg(color::MUTED)),
                Span::styled(format!("{:<28}", step.input_spec), Style::new().fg(color::FG)),
                Span::styled(" OUT: ", Style::new().fg(color::MUTED)),
                Span::styled(&step.output_spec, Style::new().fg(color::FG)),
            ]));

            if !step.details.is_empty() {
                lines.push(Line::from(vec![
                    Span::styled("      NOTE: ", Style::new().fg(color::MUTED)),
                    Span::styled(&step.details, Style::new().fg(color::MUTED)),
                ]));
            }

            if idx + 1 < steps.len() {
                lines.push(Line::from(Span::styled("       |", Style::new().fg(color::MUTED))));
                lines.push(Line::from(Span::styled("       v", Style::new().fg(color::ACCENT_CYAN))));
            }
        }
    }

    f.render_widget(
        Paragraph::new(lines)
            .block(block)
            .scroll((ui.help_scroll, 0)),
        modal_area,
    );
}

/// Renders the Telescope fuzzy-finder modal dialog.
pub fn draw_telescope_modal(
    f: &mut Frame<'_>,
    area: Rect,
    ui: &mut UiState,
    snap: &Snapshot,
) {
    let modal_area = centered_rect(65, 60, area);
    f.render_widget(Clear, modal_area);

    ui.update_telescope_matches(&snap.queue_titles);
    let match_count = ui.telescope.matches.len();

    let chunks = Layout::default()
        .direction(Direction::Vertical)
        .constraints([Constraint::Length(3), Constraint::Min(3)])
        .split(modal_area);

    let prompt_block = Block::default()
        .borders(Borders::ALL)
        .border_type(BorderType::Rounded)
        .border_style(Style::new().fg(color::ACCENT_CYAN))
        .title(format!(
            " {} Telescope: Filter Queue (Matches: {}/{}) ",
            icon::SEARCH,
            match_count,
            snap.queue_len
        ));

    let prompt_text = format!(" {} > {}", icon::PROMPT, ui.input);
    f.render_widget(Paragraph::new(prompt_text).block(prompt_block), chunks[0]);

    let list_block = Block::default()
        .borders(Borders::ALL)
        .border_type(BorderType::Rounded)
        .border_style(Style::new().fg(color::MUTED))
        .title(" Results (<Enter>: Jump & Play, <C-j>/<C-k>: Select, <Esc>: Close) ");

    let items: Vec<ListItem<'static>> = ui
        .telescope
        .matches
        .iter()
        .enumerate()
        .map(|(rank, &orig_idx)| {
            let title = snap.queue_titles.get(orig_idx).cloned().unwrap_or_default();
            let is_sel = rank == ui.telescope.selection;
            let st = if is_sel {
                Style::new().fg(color::ACCENT_CYAN).add_modifier(Modifier::BOLD)
            } else {
                Style::new().fg(color::FG)
            };
            ListItem::new(Line::from(vec![
                Span::styled(format!("{:>3}. ", orig_idx + 1), Style::new().fg(color::MUTED)),
                Span::styled(title, st),
            ]))
        })
        .collect();

    let mut state = ListState::default();
    if match_count > 0 {
        state.select(Some(ui.telescope.selection.min(match_count - 1)));
    }

    let list = List::new(items)
        .block(list_block)
        .highlight_style(Style::new().bg(color::ACTIVE_BG))
        .highlight_symbol("  ");

    f.render_stateful_widget(list, chunks[1], &mut state);
}

/// Renders single-line text input popup.
pub fn draw_simple_input(f: &mut Frame<'_>, area: Rect, ui: &mut UiState) {
    let modal_area = centered_rect(50, 20, area);
    f.render_widget(Clear, modal_area);

    let title = match ui.input_kind {
        InputKind::AddPath => format!(" {} Add Path / URL ", icon::PLAY),
        InputKind::QueueFilter => format!(" {} Filter Queue ", icon::SEARCH),
        InputKind::BrowserFilter => format!(" {} Filter Files ", icon::SEARCH),
    };

    let block = Block::default()
        .borders(Borders::ALL)
        .border_type(BorderType::Rounded)
        .title(title)
        .border_style(Style::new().fg(color::ACCENT_CYAN));

    let line = format!("{}{}", ui.input_label, ui.input);
    f.render_widget(
        Paragraph::new(line).block(block).wrap(Wrap { trim: false }),
        modal_area,
    );
}

/// Renders Which-Key keyboard shortcuts popup.
pub fn draw_which_key_modal(f: &mut Frame<'_>, area: Rect, ui: &mut UiState) {
    let modal_area = centered_rect(76, 76, area);
    f.render_widget(Clear, modal_area);

    let block = Block::default()
        .borders(Borders::ALL)
        .border_type(BorderType::Rounded)
        .border_style(Style::new().fg(color::ACCENT_PURPLE))
        .title("   Which-Key: Caly Keybindings (Press Esc / q to close) ");

    let keybinds = vec![
        Line::from(Span::styled(format!("  {} Playback Controls", icon::PLAY), style::section_header())),
        Line::from(vec![
            Span::styled("    <Space>      ", style::key_tag()),
            Span::raw("Toggle Play / Pause        "),
            Span::styled("n / p        ", style::key_tag()),
            Span::raw("Next / Previous track"),
        ]),
        Line::from(vec![
            Span::styled("    s            ", style::key_tag()),
            Span::raw("Stop playback              "),
            Span::styled("+ / -        ", style::key_tag()),
            Span::raw("Volume Up / Down (1%/5%)"),
        ]),
        Line::from(vec![
            Span::styled("    r            ", style::key_tag()),
            Span::raw("Cycle Repeat (Off/All/One) "),
            Span::styled("x            ", style::key_tag()),
            Span::raw("Toggle Shuffle"),
        ]),
        Line::raw(""),
        Line::from(Span::styled(format!("  {} Navigation (Vim Motion)", icon::SHUFFLE), style::section_header())),
        Line::from(vec![
            Span::styled("    j / k        ", style::key_tag()),
            Span::raw("Move cursor down / up      "),
            Span::styled("g / G        ", style::key_tag()),
            Span::raw("Jump to Top / Bottom"),
        ]),
        Line::from(vec![
            Span::styled("    Ctrl-d / u   ", style::key_tag()),
            Span::raw("Scroll half page down / up "),
            Span::styled("<Enter>      ", style::key_tag()),
            Span::raw("Play selected track"),
        ]),
        Line::from(vec![
            Span::styled("    h / l (Left/Right) ", style::key_tag()),
            Span::raw("Seek -5s / +5s in track    "),
            Span::styled("H / L        ", style::key_tag()),
            Span::raw("Seek -30s / +30s"),
        ]),
        Line::raw(""),
        Line::from(Span::styled("    Queue Management (Vim Style)", style::section_header())),
        Line::from(vec![
            Span::styled("    J / K        ", style::key_tag()),
            Span::raw("Move track Down / Up       "),
            Span::styled("d            ", style::key_tag()),
            Span::raw("Delete / Remove track"),
        ]),
        Line::from(vec![
            Span::styled("    /            ", style::key_tag()),
            Span::raw("Telescope Fuzzy Filter     "),
            Span::styled("i            ", style::key_tag()),
            Span::raw("Signal Flow (Hi-Fi Path)"),
        ]),
        Line::from(vec![
            Span::styled("    a            ", style::key_tag()),
            Span::raw("Enqueue new Path or URL    "),
            Span::styled("q            ", style::key_tag()),
            Span::raw("Quit player"),
        ]),
        Line::raw(""),
        Line::from(Span::styled(format!("  {} File Explorer (Neo-Tree)", icon::FOLDER), style::section_header())),
        Line::from(vec![
            Span::styled("    f            ", style::key_tag()),
            Span::raw("Toggle Explorer sidebar    "),
            Span::styled("<Tab>/<C-w>  ", style::key_tag()),
            Span::raw("Switch Focus (Main <-> Tree)"),
        ]),
        Line::from(vec![
            Span::styled("    h / l        ", style::key_tag()),
            Span::raw("Parent dir / Open directory"),
            Span::styled("a            ", style::key_tag()),
            Span::raw("Add file/folder to queue"),
        ]),
        Line::from(vec![
            Span::styled("    .            ", style::key_tag()),
            Span::raw("Toggle hidden dotfiles     "),
            Span::styled("r            ", style::key_tag()),
            Span::raw("Refresh directory tree"),
        ]),
    ];

    f.render_widget(
        Paragraph::new(keybinds)
            .block(block)
            .scroll((ui.help_scroll, 0)),
        modal_area,
    );
}
