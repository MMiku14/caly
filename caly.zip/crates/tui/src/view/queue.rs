//! Queue list and footer statusline rendering.

use caly_core::progress::format_time;
use caly_core::queue::RepeatMode;
use caly_engine::Snapshot;
use ratatui::layout::Rect;
use ratatui::style::{Color, Modifier, Style};
use ratatui::text::{Line, Span};
use ratatui::widgets::{Block, BorderType, Borders, List, ListItem, Paragraph};
use ratatui::Frame;

use crate::state::{Focus, Mode, UiState};
use crate::theme::{color, icon};

/// Renders the playback queue list widget.
pub fn draw_queue(f: &mut Frame<'_>, area: Rect, ui: &mut UiState, snap: &Snapshot) {
    let dur_str = snap
        .queue_duration
        .map(|d| format!("   {}", format_time(d)))
        .unwrap_or_default();
    let title = format!("   Queue ({} tracks{}) ", snap.queue_len, dur_str);
    let is_focused = ui.focus == Focus::Main;
    let block = Block::default()
        .borders(Borders::ALL)
        .border_type(BorderType::Rounded)
        .border_style(if is_focused {
            Style::new().fg(color::ACCENT_CYAN)
        } else {
            Style::new().fg(color::MUTED)
        })
        .title(title);

    ui.queue_row_map.clear();
    let items: Vec<ListItem<'static>> = build_queue_items(snap, &ui.filter, &mut ui.queue_row_map);

    let list = List::new(items)
        .block(block)
        .highlight_style(
            Style::new()
                .bg(color::ACTIVE_BG)
                .fg(color::ACCENT_CYAN)
                .add_modifier(Modifier::BOLD),
        )
        .highlight_symbol("  ");

    f.render_stateful_widget(list, area, &mut ui.list);

    if let Some(fr) = ui.frame.as_mut() {
        fr.queue_inner = Block::default().borders(Borders::ALL).inner(area);
        fr.queue_offset = ui.list.offset();
    }
}

fn build_queue_items(
    snap: &Snapshot,
    filter: &str,
    row_map: &mut Vec<usize>,
) -> Vec<ListItem<'static>> {
    let mut items = Vec::new();
    let (queue_len, cursor) = (snap.queue_len, snap.queue_cursor);
    let filter_l = filter.to_lowercase();
    let mut pos = 0usize;

    for (idx, title) in snap.queue_titles.iter().enumerate() {
        if idx >= queue_len {
            break;
        }
        let is_current = cursor == Some(idx);
        let mat = filter_l.is_empty() || title.to_lowercase().contains(&filter_l);
        pos += 1;
        if !mat {
            continue;
        }

        let (prefix, prefix_style) = if is_current {
            (
                format!("{} ", icon::PLAY),
                Style::new().fg(color::ACCENT_GREEN).add_modifier(Modifier::BOLD),
            )
        } else {
            ("  ".into(), Style::new().fg(color::MUTED))
        };

        let style = if is_current {
            Style::new().fg(color::ACCENT_GREEN).add_modifier(Modifier::BOLD)
        } else {
            Style::new().fg(color::FG)
        };

        row_map.push(idx);
        items.push(ListItem::new(Line::from(vec![
            Span::styled(prefix, prefix_style),
            Span::styled(format!("{pos:>3}. "), Style::new().fg(color::MUTED)),
            Span::styled(title.clone(), style),
        ])));
    }

    if items.is_empty() {
        let hint = if filter_l.is_empty() {
            "  Queue is empty. Press 'a' to add a path or 'f' for explorer."
        } else {
            "  No matching tracks found."
        };
        items.push(ListItem::new(Line::from(Span::styled(
            hint,
            Style::new().fg(color::MUTED),
        ))));
    }

    items
}

/// Renders the single-line footer status bar.
pub fn draw_statusline(f: &mut Frame<'_>, area: Rect, ui: &UiState, snap: &Snapshot) {
    let mode_str = match ui.mode {
        Mode::Queue if ui.focus == Focus::Browser => " FILES ",
        Mode::Queue => " NORMAL ",
        Mode::Input => " TELESCOPE ",
        Mode::Help => " WHICH-KEY ",
        Mode::SignalFlow => " SIGNAL-FLOW ",
    };

    let mode_color = match ui.mode {
        Mode::Queue if ui.focus == Focus::Browser => color::ACCENT_PURPLE,
        Mode::Queue => color::ACCENT_CYAN,
        Mode::Input => color::ACCENT_YELLOW,
        Mode::Help => color::ACCENT_GREEN,
        Mode::SignalFlow => color::ACCENT_CYAN,
    };

    let vol_pct = (snap.volume.clamp(0.0, 2.0) * 100.0).round() as u32;
    let repeat_str = match snap.repeat {
        RepeatMode::Off => "OFF",
        RepeatMode::All => "ALL",
        RepeatMode::One => "ONE",
    };
    let shuf_str = if snap.shuffle { "ON" } else { "OFF" };

    let line = Line::from(vec![
        Span::styled(
            mode_str,
            Style::new().bg(mode_color).fg(Color::Black).add_modifier(Modifier::BOLD),
        ),
        Span::raw(" "),
        Span::styled(
            if ui.show_browser { "Tab: Focus " } else { "f: Explorer " },
            Style::new().fg(color::MUTED),
        ),
        Span::styled("i: Flow ", Style::new().fg(color::ACCENT_CYAN)),
        Span::styled("?: Help ", Style::new().fg(color::MUTED)),
        if let Some(err) = &snap.last_error {
            Span::styled(format!("   {err} "), Style::new().fg(color::ACCENT_RED))
        } else if !ui.status.is_empty() {
            Span::styled(format!(" {} ", ui.status), Style::new().fg(color::ACCENT_YELLOW))
        } else {
            Span::raw("")
        },
        Span::styled("  |  ", Style::new().fg(color::MUTED)),
        Span::styled(
            format!("{} {repeat_str}  {} {shuf_str}", icon::REPEAT, icon::SHUFFLE),
            Style::new().fg(color::FG),
        ),
        Span::styled("  |  ", Style::new().fg(color::MUTED)),
        Span::styled(format!("{} {vol_pct}%", icon::VOLUME), Style::new().fg(color::ACCENT_CYAN)),
        Span::styled("  |  ", Style::new().fg(color::MUTED)),
        Span::styled(
            if snap.is_bit_perfect {
                format!("{} Bit-Perfect", icon::BIT_PERFECT)
            } else {
                format!("{} Hi-Fi Flow", icon::FLOW)
            },
            if snap.is_bit_perfect {
                Style::new().bg(color::ACCENT_GREEN).fg(Color::Black).add_modifier(Modifier::BOLD)
            } else {
                Style::new().bg(color::SURFACE).fg(color::ACCENT_CYAN)
            },
        ),
        Span::raw(" "),
        Span::styled(
            format!("{} {}", icon::TIME, format_time(snap.position.position)),
            Style::new().fg(color::FG),
        ),
    ]);

    f.render_widget(Paragraph::new(line), area);
}
