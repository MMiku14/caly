//! LazyVim-inspired categorized secondary menu: structured sections, instant hotkeys, and live toggles.

use ratatui::layout::{Constraint, Direction, Layout, Rect};
use ratatui::style::{Modifier, Style};
use ratatui::text::{Line, Span};
use ratatui::widgets::{Block, BorderType, Borders, Clear, Paragraph};
use ratatui::Frame;

use crate::state::UiState;
use crate::theme::{color, style};
use crate::view::centered_rect;

/// Renders the LazyVim-inspired categorized settings secondary menu.
pub fn draw_settings_modal(f: &mut Frame<'_>, area: Rect, ui: &mut UiState) {
    let modal_area = centered_rect(80, 80, area);
    f.render_widget(Clear, modal_area);

    let border_type = match ui.settings.border_style.as_str() {
        "plain" => BorderType::Plain,
        "thick" => BorderType::Thick,
        "double" => BorderType::Double,
        _ => BorderType::Rounded,
    };

    let block = Block::default()
        .borders(Borders::ALL)
        .border_type(border_type)
        .border_style(Style::new().fg(color::ACCENT_CYAN))
        .title(" ⚙ LazyVim Settings Menu (Direct Keys: [b],[t],[f],[s],[l],[S] | Esc: Close) ");

    let inner = block.inner(modal_area);
    f.render_widget(block, modal_area);

    if inner.width < 10 || inner.height < 6 {
        return;
    }

    // Split into 2 columns (Left: Appearance & Typography, Right: Playback & System)
    let cols = Layout::default()
        .direction(Direction::Horizontal)
        .constraints([Constraint::Percentage(50), Constraint::Percentage(50)])
        .split(inner);

    // Left Column: UI & Font
    let mut left_lines = Vec::new();
    left_lines.push(Line::from(Span::styled("  +ui: Appearance & View", style::section_header())));
    left_lines.push(render_toggle_line("b", "Borders", ui.settings.borders, ui.settings_cursor == 0));
    left_lines.push(render_cycle_line("B", "Border Style", &ui.settings.border_style, ui.settings_cursor == 1));
    left_lines.push(render_toggle_line("t", "Transparent Bg", !ui.settings.bg_coverage, ui.settings_cursor == 2));
    left_lines.push(render_cycle_line("s", "Scrollbar", &ui.settings.scrollbar, ui.settings_cursor == 3));
    left_lines.push(Line::raw(""));

    left_lines.push(Line::from(Span::styled("  +assets: Fonts & Cover", style::section_header())));
    left_lines.push(render_cycle_line("f", "Font Symbols", &ui.settings.symbols, ui.settings_cursor == 4));
    left_lines.push(render_cycle_line("p", "Image Protocol", &ui.settings.image_protocol, ui.settings_cursor == 5));
    left_lines.push(render_toggle_line("a", "Album Artwork", ui.settings.artwork, ui.settings_cursor == 6));

    f.render_widget(Paragraph::new(left_lines), cols[0]);

    // Right Column: Playback & Config Actions
    let mut right_lines = Vec::new();
    right_lines.push(Line::from(Span::styled("  +playback: Audio & Lyrics", style::section_header())));
    right_lines.push(render_toggle_line("v", "1% Volume Steps", ui.settings.volume_percent, ui.settings_cursor == 7));
    right_lines.push(render_toggle_line("m", "Mouse Mode", ui.settings.mouse, ui.settings_cursor == 8));
    right_lines.push(render_cycle_line("l", "Lyrics Follow", &ui.settings.lyrics_follow_mode, ui.settings_cursor == 9));
    right_lines.push(Line::raw(""));

    right_lines.push(Line::from(Span::styled("  +config: Persistence & Sync", style::section_header())));
    let save_desc = if ui.settings_dirty {
        Span::styled("* Unsaved (Press 'S')", Style::new().fg(color::ACCENT_YELLOW).add_modifier(Modifier::BOLD))
    } else {
        Span::styled("✓ Synced to Disk", Style::new().fg(color::ACCENT_GREEN))
    };
    right_lines.push(Line::from(vec![
        Span::styled("    [S] ", style::key_tag()),
        Span::styled("Save to TOML       ", Style::new().fg(color::FG)),
        save_desc,
    ]));

    right_lines.push(Line::from(vec![
        Span::styled("    [E] ", style::key_tag()),
        Span::styled("Open in $EDITOR     ", Style::new().fg(color::FG)),
        Span::styled("~/.config/caly", Style::new().fg(color::MUTED)),
    ]));

    f.render_widget(Paragraph::new(right_lines), cols[1]);
}

fn render_toggle_line(key: &str, label: &str, enabled: bool, is_cursor: bool) -> Line<'static> {
    let pointer = if is_cursor { "▶ " } else { "  " };
    let tag = format!("[{key}] ");
    let (state_text, state_color) = if enabled {
        ("[✓] Enabled ", color::ACCENT_GREEN)
    } else {
        ("[ ] Disabled", color::MUTED)
    };

    Line::from(vec![
        Span::styled(pointer, Style::new().fg(color::ACCENT_CYAN)),
        Span::styled(tag, style::key_tag()),
        Span::styled(format!("{:<18}", label), Style::new().fg(color::FG)),
        Span::styled(state_text, Style::new().fg(state_color).add_modifier(Modifier::BOLD)),
    ])
}

fn render_cycle_line(key: &str, label: &str, val: &str, is_cursor: bool) -> Line<'static> {
    let pointer = if is_cursor { "▶ " } else { "  " };
    let tag = format!("[{key}] ");
    let val_str = format!("< {val} >");

    Line::from(vec![
        Span::styled(pointer, Style::new().fg(color::ACCENT_CYAN)),
        Span::styled(tag, style::key_tag()),
        Span::styled(format!("{:<18}", label), Style::new().fg(color::FG)),
        Span::styled(val_str, Style::new().fg(color::ACCENT_CYAN)),
    ])
}
