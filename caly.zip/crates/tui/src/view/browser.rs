//! File explorer sidebar rendering.

use ratatui::layout::Rect;
use ratatui::style::{Modifier, Style};
use ratatui::text::{Line, Span};
use ratatui::widgets::{Block, BorderType, Borders, List, ListItem};
use ratatui::Frame;

use crate::state::{Focus, UiState};
use crate::theme::{color, icon};

/// Renders the Neo-Tree inspired file explorer sidebar.
pub fn draw_browser(f: &mut Frame<'_>, area: Rect, ui: &mut UiState) {
    let Some(browser) = &ui.browser else {
        return;
    };

    let mut title = format!(" {} Explorer: {} ", icon::FOLDER, browser.cwd().display());
    if browser.show_hidden() {
        title.push_str(" [hidden: on] ");
    }
    if !browser.filter().is_empty() {
        title.push_str(&format!(" [filter: {}] ", browser.filter()));
    }

    let focused = ui.focus == Focus::Browser;
    let block = Block::default()
        .borders(Borders::ALL)
        .border_type(BorderType::Rounded)
        .title(title)
        .border_style(if focused {
            Style::new().fg(color::ACCENT_PURPLE)
        } else {
            Style::new().fg(color::MUTED)
        });

    let vis = browser.visible_indices();
    let items: Vec<ListItem<'static>> = vis
        .iter()
        .map(|&i| {
            let e = &browser.entries()[i];
            let (ico, name, st) = if e.is_dir {
                (
                    icon::FOLDER,
                    e.display_name(),
                    Style::new().fg(color::ACCENT_BLUE).add_modifier(Modifier::BOLD),
                )
            } else if e.is_audio {
                (
                    icon::TRACK,
                    e.display_name(),
                    Style::new().fg(color::ACCENT_CYAN),
                )
            } else {
                (icon::FILE, e.name.clone(), Style::new().fg(color::MUTED))
            };

            let size = e.size_str();
            ListItem::new(Line::from(vec![
                Span::styled(format!("  {ico} "), st),
                Span::styled(name, st),
                Span::styled(
                    if size.is_empty() {
                        String::new()
                    } else {
                        format!("  {size}")
                    },
                    Style::new().fg(color::MUTED),
                ),
            ]))
        })
        .collect();

    let list = List::new(items)
        .block(block)
        .highlight_style(
            Style::new()
                .bg(color::ACTIVE_BG)
                .fg(color::ACCENT_PURPLE)
                .add_modifier(Modifier::BOLD),
        )
        .highlight_symbol("  ");

    ui.browser_list
        .select(Some(browser.selected_index_for_draw()));
    f.render_stateful_widget(list, area, &mut ui.browser_list);

    if let Some(fr) = ui.frame.as_mut() {
        fr.browser_inner = Some(Block::default().borders(Borders::ALL).inner(area));
        fr.browser_offset = ui.browser_list.offset();
    }
}
