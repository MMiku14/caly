//! Unified footer: which-key hints, status line, command prompt, completion popup, and seek progress band.

use std::time::Duration;
use caly_core::progress::format_time;
use caly_core::queue::RepeatMode;
use caly_engine::Snapshot;
use ratatui::layout::{Alignment, Constraint, Direction, Layout, Rect};
use ratatui::style::{Color, Modifier, Style};
use ratatui::text::{Line, Span};
use ratatui::widgets::Paragraph;
use ratatui::Frame;

use crate::state::{Focus, Mode, UiState};
use crate::theme::{color, icon};
use crate::ui_kit::{
    completion_rows, draw_completion_list, draw_key_hints, draw_prompt_line,
    CompletionListStyle, KeyHintsStyle, PromptLineStyle,
};

/// Renders the footer composite (hints, status, prompt, and bottom progress band).
pub fn draw_footer(
    f: &mut Frame<'_>,
    area: Rect,
    ui: &UiState,
    snap: &Snapshot,
) -> Option<(u16, u16)> {
    let hints = ui.active_key_hints();
    let show_hints = !hints.is_empty() && area.height >= 4;
    let hint_h = if show_hints { 1 } else { 0 };

    let chunks = Layout::default()
        .direction(Direction::Vertical)
        .constraints([
            Constraint::Length(hint_h),
            Constraint::Length(1), // Status / prompt line
            Constraint::Length(1), // Full-width seek progress band
        ])
        .split(area);

    if show_hints {
        let style = KeyHintsStyle::default();
        draw_key_hints(f, &hints, chunks[0], &style);
    }

    let mut cursor_pos = None;

    // Line 1: Interactive Prompt OR Status Line
    if let Some(prompt) = &ui.prompt {
        let prompt_style = PromptLineStyle::default();
        cursor_pos = draw_prompt_line(f, prompt, ui.completion.as_ref(), chunks[1], &prompt_style);

        if let Some(comp) = &ui.completion {
            let comp_style = CompletionListStyle::default();
            let rows = completion_rows(Some(comp), 6);
            if rows > 0 {
                let comp_area = Rect {
                    x: area.x + 2,
                    y: chunks[1].y.saturating_sub(rows),
                    width: 36.min(area.width),
                    height: rows,
                };
                draw_completion_list(f, comp, comp_area, &comp_style);
            }
        }
    } else {
        draw_status_line(f, chunks[1], ui, snap);
    }

    // Line 2: Full-width seek progress band
    draw_progress_band(f, chunks[2], snap);

    cursor_pos
}

fn draw_status_line(f: &mut Frame<'_>, area: Rect, ui: &UiState, snap: &Snapshot) {
    let icons = crate::theme::Icons::for_set(crate::theme::SymbolSet::parse(&ui.settings.symbols));
    let mode_str = match ui.mode {
        Mode::Queue if ui.focus == Focus::Browser => " FILES ",
        Mode::Queue => " NORMAL ",
        Mode::Input => " TELESCOPE ",
        Mode::Help => " WHICH-KEY ",
        Mode::SignalFlow => " SIGNAL-FLOW ",
    };

    let mode_color = match ui.mode {
        Mode::Queue if ui.focus == Focus::Browser => color::ACCENT_PURPLE,
        Mode::Queue => color::ACCENT_CYAN,
        Mode::Input => color::ACCENT_YELLOW,
        Mode::Help => color::ACCENT_GREEN,
        Mode::SignalFlow => color::ACCENT_CYAN,
    };

    let vol_pct = (snap.volume.clamp(0.0, 2.0) * 100.0).round() as u32;
    let repeat_str = match snap.repeat {
        RepeatMode::Off => "OFF",
        RepeatMode::All => "ALL",
        RepeatMode::One => "ONE",
    };
    let shuf_str = if snap.shuffle { "ON" } else { "OFF" };

    let line = Line::from(vec![
        Span::styled(
            mode_str,
            Style::new().bg(mode_color).fg(Color::Black).add_modifier(Modifier::BOLD),
        ),
        Span::raw(" "),
        Span::styled("Tab: Switch  ", Style::new().fg(color::MUTED)),
        Span::styled(":: Command  ", Style::new().fg(color::ACCENT_CYAN)),
        Span::styled("?: Help ", Style::new().fg(color::MUTED)),
        if let Some(err) = &snap.last_error {
            Span::styled(format!("   {err} "), Style::new().fg(color::ACCENT_RED))
        } else if !ui.status.is_empty() {
            Span::styled(format!(" {} ", ui.status), Style::new().fg(color::ACCENT_YELLOW))
        } else {
            Span::raw("")
        },
        Span::styled("  |  ", Style::new().fg(color::MUTED)),
        Span::styled(
            format!("{} {repeat_str}  {} {shuf_str}", icons.repeat, icons.shuffle),
            Style::new().fg(color::FG),
        ),
        Span::styled("  |  ", Style::new().fg(color::MUTED)),
        Span::styled(format!("{} {vol_pct}%", icons.volume), Style::new().fg(color::ACCENT_CYAN)),
        Span::styled("  |  ", Style::new().fg(color::MUTED)),
        Span::styled(
            if snap.is_bit_perfect {
                format!("{} Bit-Perfect", icons.bit_perfect)
            } else {
                format!("{} Hi-Fi Flow", icons.flow)
            },
            if snap.is_bit_perfect {
                Style::new().bg(color::ACCENT_GREEN).fg(Color::Black).add_modifier(Modifier::BOLD)
            } else {
                Style::new().bg(color::SURFACE).fg(color::ACCENT_CYAN)
            },
        ),
    ]);

    f.render_widget(Paragraph::new(line), area);
}

/// Full-width continuous seek band with sub-cell precision.
fn draw_progress_band(f: &mut Frame<'_>, area: Rect, snap: &Snapshot) {
    if area.width == 0 || area.height == 0 {
        return;
    }

    let elapsed = snap.position.position.as_secs_f64();
    let total = snap.position.duration.map(|d| d.as_secs_f64()).unwrap_or(0.0);
    let ratio = if total > 0.0 {
        (elapsed / total).clamp(0.0, 1.0)
    } else {
        0.0
    };

    let filled_cells = ratio * f64::from(area.width);
    let whole = filled_cells.floor() as u16;
    let fraction = filled_cells - f64::from(whole);

    let mut spans: Vec<Span> = Vec::new();
    let remaining = area.width.saturating_sub(whole);

    if whole > 0 {
        spans.push(Span::styled(
            " ".repeat(whole as usize),
            Style::new().bg(color::ACCENT_CYAN),
        ));
    }

    if remaining > 0 && fraction >= 0.5 {
        spans.push(Span::styled(
            "▌",
            Style::new().fg(color::ACCENT_CYAN).bg(color::SURFACE),
        ));
        if remaining > 1 {
            spans.push(Span::styled(
                " ".repeat((remaining - 1) as usize),
                Style::new().bg(color::SURFACE),
            ));
        }
    } else if remaining > 0 {
        spans.push(Span::styled(
            " ".repeat(remaining as usize),
            Style::new().bg(color::SURFACE),
        ));
    }

    f.render_widget(Paragraph::new(Line::from(spans)), area);

    // Overlay centered time label
    let label_str = format!(
        " {} / {} ",
        format_time(snap.position.position),
        snap.position.duration.map(format_time).unwrap_or_else(|| "--:--".to_string())
    );

    if area.width as usize >= label_str.len() + 4 {
        let label = Line::from(Span::styled(
            label_str,
            Style::new().fg(color::FG).add_modifier(Modifier::BOLD),
        ));
        f.render_widget(Paragraph::new(label).alignment(Alignment::Center), area);
    }
}
