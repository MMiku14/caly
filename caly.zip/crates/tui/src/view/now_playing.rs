//! Now Playing card, progress bar, album artwork, and audio visualizer.

use caly_engine::{PlayState, Snapshot};
use ratatui::layout::{Alignment, Constraint, Direction, Layout, Rect};
use ratatui::style::{Modifier, Style};
use ratatui::text::{Line, Span};
use ratatui::widgets::{Block, BorderType, Borders, Gauge, Paragraph};
use ratatui::Frame;

use crate::state::{Focus, UiState};
use crate::theme::{color, icon};
use crate::widgets::{
    draw_cover_image, draw_cover_placeholder, format_volume_bar, render_visualizer,
};

/// Renders the upper Now Playing card and progress bar.
pub fn draw_now_playing(f: &mut Frame<'_>, area: Rect, ui: &mut UiState, snap: &Snapshot) {
    let title = match &snap.current {
        Some(c) => match (&c.artist, &c.title) {
            (Some(a), t) => format!("{a} - {t}"),
            (None, t) => t.clone(),
        },
        None => "Caly - Ready to play".to_string(),
    };

    let (state_symbol, state_style) = match snap.state {
        PlayState::Playing => (
            format!("{} PLAYING", icon::PLAY),
            Style::new().fg(color::ACCENT_GREEN).add_modifier(Modifier::BOLD),
        ),
        PlayState::Paused => (
            format!("{} PAUSED", icon::PAUSE),
            Style::new().fg(color::ACCENT_YELLOW).add_modifier(Modifier::BOLD),
        ),
        PlayState::Stopped => (
            format!("{} STOPPED", icon::STOP),
            Style::new().fg(color::MUTED),
        ),
    };

    let (hifi_badge, hifi_style) = if snap.is_bit_perfect {
        (
            format!("{} BIT-PERFECT", icon::BIT_PERFECT),
            Style::new().fg(color::ACCENT_GREEN).add_modifier(Modifier::BOLD),
        )
    } else {
        (
            format!("{} HI-FI DSP", icon::FLOW),
            Style::new().fg(color::ACCENT_CYAN),
        )
    };

    let border_color = if ui.focus == Focus::Main && snap.state == PlayState::Playing {
        color::ACCENT_CYAN
    } else {
        color::MUTED
    };

    let block = Block::default()
        .borders(Borders::ALL)
        .border_type(BorderType::Rounded)
        .border_style(Style::new().fg(border_color))
        .title(Line::from(vec![
            Span::styled(
                format!(" {} Now Playing ", icon::TRACK),
                Style::new().fg(color::ACCENT_CYAN).add_modifier(Modifier::BOLD),
            ),
            Span::styled(format!(" [{state_symbol}] "), state_style),
            Span::styled(format!(" [{hifi_badge}] "), hifi_style),
        ]))
        .title_alignment(Alignment::Left);

    f.render_widget(block, area);

    let inner = Block::default().borders(Borders::ALL).inner(area);
    let content_area = {
        let areas = Layout::default()
            .direction(Direction::Vertical)
            .constraints([Constraint::Min(2), Constraint::Length(1)])
            .split(inner);
        areas[0]
    };

    let (cover_cw, has_art) = if content_area.width < 14 {
        (0, false)
    } else {
        match &ui.cover {
            Some(art) if art.width > 0 && art.height > 0 => {
                let cell_h = content_area.height as usize * 2;
                let fit_h = (art.height as usize).min(cell_h);
                let cw = (((fit_h as f64) * art.width as f64 / art.height as f64).round() as usize)
                    .clamp(6, 24)
                    .min(content_area.width as usize) as u16;
                (cw, true)
            }
            _ => (10, false),
        }
    };

    let text_area = Rect {
        x: content_area.x + cover_cw,
        y: content_area.y,
        width: content_area.width.saturating_sub(cover_cw).max(1),
        height: content_area.height,
    };

    let visualizer_line = render_visualizer(snap.state, snap.position.position.as_millis());
    let mut meta_lines = vec![
        Line::from(vec![
            Span::styled(format!("  {} ", icon::TRACK), Style::new().fg(color::ACCENT_PURPLE)),
            Span::styled(title, Style::new().fg(color::FG).add_modifier(Modifier::BOLD)),
            Span::raw("   "),
            visualizer_line.spans.into_iter().collect::<Vec<_>>().pop().unwrap_or_else(|| Span::raw("")),
        ]),
        Line::from(vec![
            Span::styled(format!("  {} ", icon::TIME), Style::new().fg(color::ACCENT_CYAN)),
            Span::styled(caly_core::progress::format_progress(&snap.position), Style::new().fg(color::FG)),
            Span::raw("   "),
            Span::styled(format!("{} ", icon::BIT_PERFECT), Style::new().fg(color::ACCENT_BLUE)),
            Span::styled(
                match (snap.backend, snap.source) {
                    (Some(b), Some(s)) => format!("{b}   {s}"),
                    (Some(b), None) => b.to_string(),
                    _ => "idle".to_string(),
                },
                Style::new().fg(color::MUTED),
            ),
            Span::raw("   "),
            Span::styled(format!("{} ", icon::FLOW), Style::new().fg(color::ACCENT_GREEN)),
            Span::styled(snap.signal_flow.concise_path(), Style::new().fg(color::FG)),
            Span::raw("  "),
            Span::styled("[i: Flow Detail]", Style::new().fg(color::ACCENT_CYAN)),
        ]),
    ];

    if area.height >= 8 {
        let vol_line = format_volume_bar(snap.volume, 10);
        meta_lines.push(Line::from(vec![
            Span::raw("  "),
            vol_line.spans[0].clone(),
            vol_line.spans[1].clone(),
            vol_line.spans[2].clone(),
        ]));
    }

    f.render_widget(Paragraph::new(meta_lines), text_area);

    if cover_cw > 0 {
        let art_rect = Rect {
            x: content_area.x,
            y: content_area.y,
            width: cover_cw,
            height: content_area.height,
        };
        if has_art {
            if let Some(art) = &ui.cover {
                draw_cover_image(f.buffer_mut(), art, art_rect);
            }
        } else {
            draw_cover_placeholder(f, art_rect);
        }
    }

    let ratio = snap.position.ratio();
    let bar_area = Rect {
        x: inner.x,
        y: inner.y + inner.height.saturating_sub(1),
        width: inner.width,
        height: 1,
    };
    f.render_widget(
        Gauge::default()
            .ratio(f64::from(ratio.clamp(0.0, 1.0)))
            .label(format!("{:.1}%", ratio * 100.0))
            .gauge_style(Style::new().fg(color::ACCENT_CYAN).bg(color::SURFACE)),
        bar_area,
    );
}
