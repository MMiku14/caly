//! Synced and plain lyrics pane rendering with word-by-word or sentence-by-sentence follow.

use std::time::Duration;
use caly_core::lyrics::Lyrics;
use ratatui::layout::Rect;
use ratatui::style::{Modifier, Style};
use ratatui::text::{Line, Span};
use ratatui::widgets::{Block, BorderType, Borders, Paragraph, Wrap};
use ratatui::Frame;

use crate::state::UiState;
use crate::theme::color;

/// Renders the synchronized lyrics pane with sentence or word follow modes and interactive cursor.
pub fn draw_lyrics_pane(
    f: &mut Frame<'_>,
    area: Rect,
    ui: &mut UiState,
    lyrics: Option<&Lyrics>,
    elapsed: Duration,
) {
    let mode_label = if ui.settings.lyrics_follow_mode.eq_ignore_ascii_case("sentence") {
        "Sentence"
    } else {
        "Word"
    };

    let follow_status = if ui.lyrics_follow {
        "Auto-Follow"
    } else {
        "Manual [F: Follow, Enter: Seek]"
    };

    let border_type = match ui.settings.border_style.as_str() {
        "plain" => BorderType::Plain,
        "thick" => BorderType::Thick,
        "double" => BorderType::Double,
        _ => BorderType::Rounded,
    };

    let mut block = Block::default().title(format!(" Lyrics ({mode_label} | {follow_status}) "));
    if ui.settings.borders {
        block = block
            .borders(Borders::ALL)
            .border_type(border_type)
            .border_style(Style::new().fg(color::ACCENT_CYAN));
    }
    if ui.settings.bg_coverage {
        block = block.style(Style::new().bg(color::SURFACE));
    }

    let inner = block.inner(area);
    f.render_widget(block, area);

    if inner.height == 0 || inner.width == 0 {
        return;
    }

    let Some(lyrics) = lyrics else {
        let hint = "  No synchronized lyrics found (.lrc). Place a sibling .lrc next to the audio file.";
        f.render_widget(
            Paragraph::new(hint).style(Style::new().fg(color::MUTED)),
            inner,
        );
        return;
    };

    let line_count = lyrics.line_count();
    let group = lyrics.active_group(elapsed);
    let (group_start, group_end) = group.unwrap_or((usize::MAX, usize::MAX));

    // Determine scroll offset: auto-follow centers the playing group; manual uses ui.lyrics_scroll
    let scroll = if ui.lyrics_follow {
        let s = group
            .map(|(start, _)| start.saturating_sub(inner.height as usize / 2))
            .unwrap_or(0);
        ui.lyrics_scroll = s;
        s
    } else {
        ui.lyrics_scroll
    };

    let is_sentence_mode = ui.settings.lyrics_follow_mode.eq_ignore_ascii_case("sentence");

    let mut lines = Vec::new();
    for row in 0..inner.height as usize {
        let index = scroll + row;
        if index >= line_count {
            break;
        }

        let is_active = index >= group_start && index < group_end;
        let is_cursor = ui.lyrics_cursor == Some(index);
        let mut spans = Vec::new();
        let text = lyrics.line(index).unwrap_or_default();

        let marker = if is_cursor {
            "▶ "
        } else if is_active {
            "● "
        } else {
            "  "
        };

        if is_sentence_mode {
            let style = if is_cursor {
                Style::new()
                    .fg(color::ACCENT_YELLOW)
                    .add_modifier(Modifier::BOLD)
            } else if is_active {
                Style::new()
                    .fg(color::ACCENT_CYAN)
                    .add_modifier(Modifier::BOLD)
            } else if index < group_start {
                Style::new().fg(color::FG)
            } else {
                Style::new().fg(color::MUTED)
            };
            spans.push(Span::styled(marker, Style::new().fg(if is_cursor { color::ACCENT_YELLOW } else { color::ACCENT_CYAN })));
            spans.push(Span::styled(text.to_string(), style));
        } else {
            let sung = if is_active {
                lyrics.karaoke_at(index, elapsed)
            } else {
                0
            };

            let marker_color = if is_cursor {
                color::ACCENT_YELLOW
            } else if is_active {
                color::ACCENT_CYAN
            } else {
                color::MUTED
            };
            spans.push(Span::styled(marker, Style::new().fg(marker_color)));

            if is_active && sung > 0 {
                let chars: Vec<char> = text.chars().collect();
                let split = sung.min(chars.len());
                spans.push(Span::styled(
                    chars[..split].iter().collect::<String>(),
                    Style::new()
                        .fg(color::ACCENT_CYAN)
                        .add_modifier(Modifier::BOLD),
                ));
                spans.push(Span::styled(
                    chars[split..].iter().collect::<String>(),
                    Style::new().fg(color::FG),
                ));
            } else {
                let style = if is_cursor {
                    Style::new().fg(color::ACCENT_YELLOW).add_modifier(Modifier::BOLD)
                } else if is_active {
                    Style::new().fg(color::FG).add_modifier(Modifier::BOLD)
                } else if index < group_start {
                    Style::new().fg(color::FG)
                } else {
                    Style::new().fg(color::MUTED)
                };
                spans.push(Span::styled(text.to_string(), style));
            }
        }

        lines.push(Line::from(spans));
    }

    f.render_widget(Paragraph::new(lines).wrap(Wrap { trim: false }), inner);

    // Render btop scrollbar for lyrics pane
    let visible_rows = inner.height as usize;
    crate::widgets::render_btop_scrollbar(
        f.buffer_mut(),
        area,
        line_count,
        visible_rows,
        scroll,
        color::ACCENT_CYAN,
        color::MUTED,
    );
}
