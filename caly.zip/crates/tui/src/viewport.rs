//! Shared viewport math for stateful panes (Queue list, Library table, Lyrics):
//! wheel scrolling moves the viewport while selection passively follows,
//! scrollbar drags jump it, and mouse hit tests locate panes and rows.

use ratatui::layout::Rect;

/// Clamps a pane's `(selected, offset)` pair after its row list changed length.
/// When the selection falls outside the new list, lands on the top of the list
/// instead of pinning to the last row. Returns `None` for an empty list.
pub fn clamp_selection(
    selected: Option<usize>,
    offset: usize,
    len: usize,
    height: usize,
) -> Option<(usize, usize)> {
    if len == 0 {
        return None;
    }
    let height = height.max(1);
    let offset = offset.min(len.saturating_sub(height));
    let selected = match selected {
        Some(sel) if sel < len => {
        let upper = (offset + height - 1).min(len - 1).max(offset);
        sel.clamp(offset, upper)
    },
        _ => return Some((0, 0)),
    };
    Some((selected, offset))
}

/// Wheel scroll: moves viewport offset by `delta` rows; selection follows inside visible window.
pub fn scroll_viewport(
    offset: &mut usize,
    selected: &mut Option<usize>,
    len: usize,
    height: usize,
    delta: i32,
) -> bool {
    if len == 0 {
        return false;
    }
    let height = height.max(1);
    let max_offset = len.saturating_sub(height);
    let next_offset = ((*offset as i32) + delta).clamp(0, max_offset as i32) as usize;
    if next_offset == *offset {
        return false;
    }
    *offset = next_offset;

    let sel = selected.unwrap_or(next_offset);
    let upper = (next_offset + height - 1).min(len - 1).max(next_offset);
    let clamped_sel = sel.clamp(next_offset, upper);
    *selected = Some(clamped_sel);
    true
}

/// Maps a scrollbar track click/drag to a proportional viewport offset.
pub fn bar_jump(
    offset: &mut usize,
    selected: &mut Option<usize>,
    len: usize,
    height: usize,
    track: Rect,
    click_y: u16,
) -> bool {
    if len == 0 || track.height <= 1 {
        return false;
    }
    let track_span = track.height.saturating_sub(1) as f64;
    let ratio = (click_y.saturating_sub(track.y) as f64 / track_span).clamp(0.0, 1.0);
    let max_offset = len.saturating_sub(height);
    let target_center = ratio * (len.saturating_sub(1)) as f64;
    let next_offset = (target_center - height as f64 / 2.0)
        .round()
        .clamp(0.0, max_offset as f64) as usize;

    if next_offset == *offset {
        return false;
    }
    *offset = next_offset;
    let sel = selected.unwrap_or(next_offset);
    let upper = (next_offset + height - 1).min(len - 1).max(next_offset);
    *selected = Some(sel.clamp(next_offset, upper));
    true
}

/// Maps a screen pointer Y coordinate to the visible data row index under it.
pub fn row_at(area: Rect, pointer_y: u16, offset: usize, len: usize) -> Option<usize> {
    if pointer_y < area.y || pointer_y >= area.y + area.height {
        return None;
    }
    let row = (pointer_y - area.y) as usize + offset;
    (row < len).then_some(row)
}
