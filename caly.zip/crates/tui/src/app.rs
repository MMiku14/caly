//! TUI application runner and terminal event loop.

use std::time::Instant;

use crossterm::event::{self, Event, KeyEventKind};

use caly_engine::Engine;

use crate::settings::Settings;
use crate::state::UiState;
use crate::view::draw;
use crate::{artwork_cache_dir, TICK};

/// The TUI application runner bound to an audio engine handle.
pub struct Tui {
    /// Associated audio engine handle.
    pub engine: Engine,
    /// Complete UI state model.
    pub ui: UiState,
    /// Runtime settings.
    pub settings: Settings,
}

impl Tui {
    /// Creates the TUI for an engine with settings.
    pub fn new(engine: Engine, settings: Settings) -> Self {
        let artwork_ok = settings.artwork;
        let initial_cursor = engine.snapshot().queue_cursor;
        let cache_dir = artwork_cache_dir().filter(|_| artwork_ok);

        Self {
            engine,
            settings,
            ui: UiState::new(initial_cursor, cache_dir),
        }
    }

    /// The key event loop; blocks until the user quits.
    pub fn run(&mut self) {
        let mut terminal = ratatui::init();
        if self.settings.mouse {
            let _ = crossterm::execute!(std::io::stdout(), crossterm::event::EnableMouseCapture);
        }
        let res = self.event_loop(&mut terminal);
        if self.settings.mouse {
            let _ = crossterm::execute!(std::io::stdout(), crossterm::event::DisableMouseCapture);
        }
        ratatui::restore();
        if let Err(e) = res {
            eprintln!("caly: TUI error: {e}");
        }
    }

    fn event_loop<B: ratatui::backend::Backend>(
        &mut self,
        terminal: &mut ratatui::Terminal<B>,
    ) -> std::io::Result<()> {
        loop {
            self.publish_if_due(terminal)?;
            let has_event = event::poll(TICK)?;
            if !has_event {
                continue;
            }
            match event::read()? {
                Event::Key(key) if key.kind == KeyEventKind::Press => {
                    if self.handle_key(key)? {
                        return Ok(());
                    }
                }
                Event::Mouse(m) if self.settings.mouse => {
                    if self.handle_mouse(m)? {
                        return Ok(());
                    }
                }
                Event::Resize(_, _) => {
                    self.ui.frame = None;
                }
                _ => {}
            }
        }
    }

    fn publish_if_due<B: ratatui::backend::Backend>(
        &mut self,
        terminal: &mut ratatui::Terminal<B>,
    ) -> std::io::Result<()> {
        let due = self.ui.last_render.elapsed() >= TICK;
        if due {
            self.sync_volume_intent();
            self.tick_artwork();
            terminal.draw(|f| draw(f, &mut self.ui, &self.engine))?;
            self.ui.last_render = Instant::now();
        }
        Ok(())
    }

    fn sync_volume_intent(&mut self) {
        if let Some(t) = self.ui.vol_target {
            if (self.engine.snapshot().volume - t).abs() < 1e-4 {
                self.ui.vol_target = None;
            }
        }
    }

    fn tick_artwork(&mut self) {
        let snap = self.engine.snapshot();
        let current = snap.current.as_ref().map(|c| c.uri.clone());
        let Some(uri) = current else {
            self.ui.cover = None;
            self.ui.cover_uri.clear();
            return;
        };

        if uri != self.ui.cover_uri {
            self.ui.cover = None;
            self.ui.cover_uri.clear();
        }

        if let Some(rx) = &self.ui.cover_rx {
            match rx.try_recv() {
                Ok(art) => {
                    self.ui.cover_rx = None;
                    self.ui.cover_loading = None;
                    if uri == self.ui.cover_uri {
                        if art.is_none() {
                            self.ui.artwork_failed.insert(uri.clone());
                        }
                        self.ui.cover = art;
                    }
                }
                Err(std::sync::mpsc::TryRecvError::Empty) => {}
                Err(std::sync::mpsc::TryRecvError::Disconnected) => {
                    self.ui.cover_rx = None;
                    self.ui.cover_loading = None;
                    self.ui.artwork_failed.insert(uri.clone());
                }
            }
        }

        if self.ui.cover.is_none()
            && self.ui.cover_loading.as_deref() != Some(uri.as_str())
            && self.ui.cover_uri != uri
            && self.ui.cache_dir.is_some()
            && !self.ui.artwork_failed.contains(&uri)
        {
            let cache = self.ui.cache_dir.clone().expect("checked above");
            let (tx, rx) = std::sync::mpsc::channel();
            self.ui.cover_rx = Some(rx);
            self.ui.cover_loading = Some(uri.clone());
            self.ui.cover_uri = uri.clone();
            std::thread::spawn(move || {
                let art = caly_artwork::load(&uri, &cache);
                let _ = tx.send(art);
            });
        }
    }
}
