//! Unified action model for keyboard shortcuts, mouse events, command lines, and IPC requests.

use std::path::PathBuf;
use std::time::Duration;
use caly_core::queue::RepeatMode;
use crate::state::InputKind;

/// Semantic actions that can be dispatched to the TUI application.
#[derive(Debug, Clone, PartialEq)]
pub enum Action {
    /// Toggle playback between playing and paused.
    TogglePlay,
    /// Resume playback.
    Resume,
    /// Pause playback.
    Pause,
    /// Stop playback.
    Stop,
    /// Advance to next track.
    Next,
    /// Return to previous track or track start.
    Prev,
    /// Seek to an absolute timestamp.
    Seek(Duration),
    /// Seek relative delta in seconds (+5s, -5s, +30s, etc.).
    SeekDelta(i64),
    /// Set volume to target linear level (0.0 ..= 2.0).
    SetVolume(f32),
    /// Adjust volume by relative delta (+0.05, -0.05).
    NudgeVolume(f32),
    /// Cycle repeat mode (Off -> All -> One -> Off).
    CycleRepeat,
    /// Set explicit repeat mode.
    SetRepeat(RepeatMode),
    /// Toggle shuffle mode.
    ToggleShuffle,
    /// Play track at specific queue index.
    PlayQueueIndex(usize),
    /// Remove track at index from queue.
    RemoveQueueIndex(usize),
    /// Reorder track from index to index.
    MoveQueueTrack(usize, usize),
    /// Enqueue file paths or stream URLs.
    Enqueue(Vec<String>),
    /// Clear entire playback queue.
    ClearQueue,
    /// Switch to specific tab index (0=Playlist, 1=Library, 2=Lyrics, 3=Explorer).
    SwitchTab(usize),
    /// Advance to next tab.
    NextTab,
    /// Return to previous tab.
    PrevTab,
    /// Open the interactive command prompt with prefix.
    OpenPrompt(String),
    /// Open input filter dialog.
    OpenFilter(InputKind),
    /// Toggle file explorer sidebar.
    ToggleExplorer,
    /// Toggle secondary settings configuration panel.
    ToggleSettings,
    /// Save settings to config.toml.
    SaveSettings,
    /// Toggle keybindings help dialog.
    ToggleHelp,
    /// Toggle audio signal flow pipeline inspector.
    ToggleSignalFlow,
    /// Scan directory into library collection.
    ScanLibrary(PathBuf),
    /// Exit the application.
    Quit,
    /// No-op.
    None,
}

impl Action {
    /// Parses an action from a command line string like "play", "volume 50", "seek 120".
    pub fn from_command_str(s: &str) -> Self {
        let parts: Vec<&str> = s.trim().split_whitespace().collect();
        if parts.is_empty() {
            return Self::None;
        }

        let verb = parts[0].to_ascii_lowercase();
        let arg = parts.get(1).copied().unwrap_or("");

        match verb.as_str() {
            "q" | "quit" | "exit" => Self::Quit,
            "play" => {
                if let Ok(idx) = arg.parse::<usize>() {
                    Self::PlayQueueIndex(idx.saturating_sub(1))
                } else {
                    Self::Resume
                }
            }
            "pause" => Self::Pause,
            "toggle" | "play_pause" => Self::TogglePlay,
            "stop" => Self::Stop,
            "next" => Self::Next,
            "prev" => Self::Prev,
            "clear" => Self::ClearQueue,
            "repeat" => Self::CycleRepeat,
            "shuffle" => Self::ToggleShuffle,
            "explorer" | "tree" => Self::ToggleExplorer,
            "flow" => Self::ToggleSignalFlow,
            "help" => Self::ToggleHelp,
            "settings" | "config" => Self::ToggleSettings,
            "save" => Self::SaveSettings,
            "vol" | "volume" => {
                if let Some(delta) = arg.strip_prefix(['+', '-']) {
                    if let Ok(pct) = delta.parse::<f32>() {
                        let sign = if arg.starts_with('-') { -1.0 } else { 1.0 };
                        return Self::NudgeVolume(sign * (pct / 100.0));
                    }
                }
                if let Ok(pct) = arg.parse::<f32>() {
                    Self::SetVolume((pct / 100.0).clamp(0.0, 2.0))
                } else {
                    Self::None
                }
            }
            "seek" => {
                if let Some(delta) = arg.strip_prefix(['+', '-']) {
                    if let Ok(secs) = delta.parse::<i64>() {
                        let sign = if arg.starts_with('-') { -1 } else { 1 };
                        return Self::SeekDelta(sign * secs);
                    }
                }
                if let Ok(secs) = arg.parse::<u64>() {
                    Self::Seek(Duration::from_secs(secs))
                } else {
                    Self::None
                }
            }
            "tab" => {
                if let Ok(idx) = arg.parse::<usize>() {
                    Self::SwitchTab(idx.saturating_sub(1).min(3))
                } else {
                    Self::NextTab
                }
            }
            "add" => {
                if !arg.is_empty() {
                    Self::Enqueue(vec![arg.to_string()])
                } else {
                    Self::None
                }
            }
            "scan" => {
                if !arg.is_empty() {
                    Self::ScanLibrary(PathBuf::from(arg))
                } else {
                    Self::None
                }
            }
            _ => Self::None,
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn parses_command_actions() {
        assert_eq!(Action::from_command_str("play"), Action::Resume);
        assert_eq!(Action::from_command_str("play 3"), Action::PlayQueueIndex(2));
        assert_eq!(Action::from_command_str("pause"), Action::Pause);
        assert_eq!(Action::from_command_str("stop"), Action::Stop);
        assert_eq!(Action::from_command_str("next"), Action::Next);
        assert_eq!(Action::from_command_str("prev"), Action::Prev);
        assert_eq!(Action::from_command_str("vol 80"), Action::SetVolume(0.8));
        assert_eq!(Action::from_command_str("vol +10"), Action::NudgeVolume(0.1));
        assert_eq!(Action::from_command_str("vol -5"), Action::NudgeVolume(-0.05));
        assert_eq!(Action::from_command_str("seek 120"), Action::Seek(Duration::from_secs(120)));
        assert_eq!(Action::from_command_str("seek +15"), Action::SeekDelta(15));
        assert_eq!(Action::from_command_str("tab 2"), Action::SwitchTab(1));
        assert_eq!(Action::from_command_str("settings"), Action::ToggleSettings);
        assert_eq!(Action::from_command_str("quit"), Action::Quit);
        assert_eq!(Action::from_command_str("unknown_cmd"), Action::None);
    }
}
