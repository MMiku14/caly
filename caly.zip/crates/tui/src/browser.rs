//! LazyVim-style file browsing for the TUI.
use std::path::{Path, PathBuf};

/// One directory listing entry.
#[derive(Debug, Clone)]
pub struct DirEntry {
    /// File name.
    pub name: String,
    /// Full path.
    pub path: PathBuf,
    /// Is directory.
    pub is_dir: bool,
    /// Is audio file.
    pub is_audio: bool,
    /// Size in bytes.
    pub size: u64,
}

impl DirEntry {
    /// Name with trailing `/` for directories.
    pub fn display_name(&self) -> String {
        if self.is_dir {
            format!("{}/", self.name)
        } else {
            self.name.clone()
        }
    }
    /// Human-readable size.
    pub fn size_str(&self) -> String {
        if self.is_dir {
            return String::new();
        }
        const KB: f64 = 1024.0;
        const MB: f64 = 1024.0 * 1024.0;
        let b = self.size as f64;
        if b >= MB {
            format!("{:.1}M", b / MB)
        } else if b >= KB {
            format!("{:.0}K", b / KB)
        } else {
            format!("{}B", self.size)
        }
    }
}

/// Audio extensions considered audio by the browser.
pub const DEFAULT_EXTS: &[&str] = &[
    "mp3", "flac", "ogg", "oga", "opus", "m4a", "aac", "wav", "wma", "ape", "mpc", "aiff", "alac",
];

/// `true` when `p`'s extension is in `exts`.
pub fn ext_matches(p: &Path, exts: &[String]) -> bool {
    p.extension()
        .and_then(|e| e.to_str())
        .map(|e| exts.iter().any(|x| x == &e.to_ascii_lowercase()))
        .unwrap_or(false)
}

/// Recursively collects audio files below `dir`.
pub fn walk_audio_dir(dir: &Path, exts: &[String], out: &mut Vec<PathBuf>) {
    let mut stack = vec![dir.to_path_buf()];
    while let Some(cur) = stack.pop() {
        let Ok(rd) = std::fs::read_dir(&cur) else {
            continue;
        };
        for e in rd.flatten() {
            let p = e.path();
            if p.is_symlink() {
                continue;
            }
            if p.is_dir() {
                stack.push(p);
            } else if p.is_file() && ext_matches(&p, exts) {
                out.push(p);
            }
        }
    }
}

/// The browser model.
#[derive(Debug, Clone)]
pub struct BrowserState {
    cwd: PathBuf,
    entries: Vec<DirEntry>,
    sel: usize,
    filter: String,
    show_hidden: bool,
    exts: Vec<String>,
    cached_visible: Vec<usize>,
}

impl BrowserState {
    /// Starts browsing at `start`.
    pub fn new(start: PathBuf, exts: &[String]) -> Self {
        let start = if start.is_dir() {
            start
        } else {
            std::env::current_dir().unwrap_or_else(|_| PathBuf::from("/"))
        };
        let mut b = Self {
            cwd: start,
            entries: Vec::new(),
            sel: 0,
            filter: String::new(),
            show_hidden: false,
            exts: exts.to_vec(),
            cached_visible: Vec::new(),
        };
        b.refresh();
        b
    }

    /// Music or home directory.
    pub fn music_or_home() -> PathBuf {
        if let Some(home) = std::env::var_os("HOME") {
            let home = PathBuf::from(home);
            let music = home.join("Music");
            if music.is_dir() {
                return music;
            }
            return home;
        }
        std::env::current_dir().unwrap_or_else(|_| PathBuf::from("/"))
    }

    /// Current directory.
    pub fn cwd(&self) -> &Path {
        &self.cwd
    }

    /// All entries.
    pub fn entries(&self) -> &[DirEntry] {
        &self.entries
    }

    /// Current filter string.
    pub fn filter(&self) -> &str {
        &self.filter
    }

    /// Hidden files shown?
    pub fn show_hidden(&self) -> bool {
        self.show_hidden
    }

    /// Selection index in visible list.
    pub fn selected_index_for_draw(&self) -> usize {
        let n = self.visible_indices().len();
        self.sel.min(n.saturating_sub(1))
    }

    /// Indices of matching entries (O(1) cached slice borrow, zero-allocation).
    pub fn visible_indices(&self) -> &[usize] {
        &self.cached_visible
    }

    fn recompute_visible(&mut self) {
        if self.filter.is_empty() {
            self.cached_visible = (0..self.entries.len()).collect();
            return;
        }
        let f = self.filter.to_lowercase();
        self.cached_visible = self.entries
            .iter()
            .enumerate()
            .filter(|(_, e)| e.name.to_lowercase().contains(&f))
            .map(|(i, _)| i)
            .collect();
    }

    /// Selected entry.
    pub fn selected(&self) -> Option<&DirEntry> {
        self.visible_indices()
            .get(self.sel)
            .and_then(|&i| self.entries.get(i))
    }

    /// Selects a row.
    pub fn select_visible(&mut self, row: usize) {
        let n = self.visible_indices().len();
        self.sel = row.min(n.saturating_sub(1));
    }

    /// Moves selection.
    pub fn move_sel(&mut self, delta: isize) {
        let n = self.visible_indices().len();
        if n == 0 {
            self.sel = 0;
            return;
        }
        self.sel = (self.sel as isize + delta).clamp(0, n as isize - 1) as usize;
    }

    /// First/last entry.
    pub fn jump(&mut self, top: bool) {
        let n = self.visible_indices().len();
        self.sel = if n > 0 && !top { n - 1 } else { 0 };
    }

    /// Refreshes current directory.
    pub fn refresh(&mut self) {
        self.entries.clear();
        if let Ok(rd) = std::fs::read_dir(&self.cwd) {
            for e in rd.flatten() {
                let p = e.path();
                let name = e.file_name().to_string_lossy().into_owned();
                if !self.show_hidden && name.starts_with('.') {
                    continue;
                }
                let is_dir = p.is_dir();
                let size = if is_dir {
                    0
                } else {
                    e.metadata().map(|m| m.len()).unwrap_or(0)
                };
                self.entries.push(DirEntry {
                    name,
                    path: p,
                    is_dir,
                    is_audio: !is_dir && ext_matches(&e.path(), &self.exts),
                    size,
                });
            }
        }
        self.entries.sort_by(|a, b| {
            b.is_dir
                .cmp(&a.is_dir)
                .then_with(|| a.name.to_lowercase().cmp(&b.name.to_lowercase()))
        });
        self.recompute_visible();
        let n = self.cached_visible.len();
        if self.sel >= n {
            self.sel = n.saturating_sub(1);
        }
    }

    fn select_path(&mut self, path: &Path) {
        let vis = self.visible_indices();
        if let Some(pos) = vis.iter().position(|&i| self.entries[i].path == path) {
            self.sel = pos;
        }
    }

    /// Enters selected directory.
    pub fn enter_selected(&mut self) -> bool {
        let Some(e) = self.selected() else {
            return false;
        };
        if !e.is_dir {
            return false;
        }
        let target = e.path.clone();
        self.cwd = target;
        self.sel = 0;
        self.filter.clear();
        self.refresh();
        true
    }

    /// Moves to parent directory.
    pub fn go_up(&mut self) -> bool {
        let Some(parent) = self.cwd.parent().map(|p| p.to_path_buf()) else {
            return false;
        };
        let back = self.cwd.clone();
        self.cwd = parent;
        self.sel = 0;
        self.refresh();
        self.select_path(&back);
        true
    }

    /// Goes home.
    pub fn go_home(&mut self) {
        self.cwd = Self::music_or_home();
        self.sel = 0;
        self.filter.clear();
        self.refresh();
    }

    /// Sets filter.
    pub fn set_filter(&mut self, filter: String) {
        self.filter = filter;
        self.recompute_visible();
        self.sel = 0;
    }

    /// Toggles hidden files.
    pub fn toggle_hidden(&mut self) {
        self.show_hidden = !self.show_hidden;
        self.refresh();
    }

    /// Paths to enqueue.
    pub fn selected_paths(&self) -> Vec<PathBuf> {
        let Some(e) = self.selected() else {
            return Vec::new();
        };
        if e.is_dir {
            let mut out = Vec::new();
            walk_audio_dir(&e.path, &self.exts, &mut out);
            out.sort();
            out
        } else {
            vec![e.path.clone()]
        }
    }
}
