//! Key and mouse event dispatching and action handlers.

use std::time::{Duration, Instant};

use crossterm::event::{KeyCode, KeyEvent, KeyModifiers, MouseButton, MouseEvent, MouseEventKind};
use ratatui::layout::Rect;

use caly_core::progress::format_time;
use caly_core::queue::RepeatMode;
use caly_engine::control::Control;

use crate::app::Tui;
use crate::browser;
use crate::state::{Focus, InputKind, Mode};
use crate::theme::icon;

impl Tui {
    /// Handles keyboard input events.
    pub fn handle_key(&mut self, key: KeyEvent) -> std::io::Result<bool> {
        if key.modifiers.contains(KeyModifiers::CONTROL) && key.code == KeyCode::Char('c') {
            return Ok(true);
        }

        let wants_focus_switch = key.code == KeyCode::Tab
            || (key.modifiers.contains(KeyModifiers::CONTROL) && key.code == KeyCode::Char('w'));

        if wants_focus_switch && self.ui.mode == Mode::Queue && self.ui.show_browser {
            self.ui.focus = match self.ui.focus {
                Focus::Main => Focus::Browser,
                Focus::Browser => Focus::Main,
            };
            return Ok(false);
        }

        match self.ui.mode {
            Mode::Input => self.handle_input_key(key),
            Mode::Help => self.handle_help_key(key),
            Mode::SignalFlow => self.handle_signal_flow_key(key),
            Mode::Queue if self.ui.focus == Focus::Browser => self.handle_browser_key(key),
            Mode::Queue => self.handle_queue_key(key),
        }
    }

    fn handle_signal_flow_key(&mut self, key: KeyEvent) -> std::io::Result<bool> {
        match key.code {
            KeyCode::Esc | KeyCode::Char('q') | KeyCode::Char('i') | KeyCode::Char('?') => {
                self.ui.mode = Mode::Queue;
            }
            KeyCode::Down | KeyCode::Char('j') => {
                self.ui.help_scroll = self.ui.help_scroll.saturating_add(2);
            }
            KeyCode::Up | KeyCode::Char('k') => {
                self.ui.help_scroll = self.ui.help_scroll.saturating_sub(2);
            }
            _ => {}
        }
        Ok(false)
    }

    fn handle_input_key(&mut self, key: KeyEvent) -> std::io::Result<bool> {
        let snap = self.engine.snapshot();
        self.ui.update_telescope_matches(&snap.queue_titles);
        let matches_count = self.ui.telescope.matches.len();

        match key.code {
            KeyCode::Esc => {
                self.ui.mode = Mode::Queue;
                self.ui.status.clear();
            }
            KeyCode::Down | KeyCode::Char('j')
                if key.modifiers.contains(KeyModifiers::CONTROL)
                    || self.ui.input_kind == InputKind::QueueFilter =>
            {
                if matches_count > 0 {
                    self.ui.telescope.selection =
                        (self.ui.telescope.selection + 1).min(matches_count - 1);
                }
            }
            KeyCode::Up | KeyCode::Char('k')
                if key.modifiers.contains(KeyModifiers::CONTROL)
                    || self.ui.input_kind == InputKind::QueueFilter =>
            {
                self.ui.telescope.selection = self.ui.telescope.selection.saturating_sub(1);
            }
            KeyCode::Enter => {
                let value = self.ui.input.trim().to_string();
                match self.ui.input_kind {
                    InputKind::AddPath => {
                        if !value.is_empty() {
                            let tracks = vec![caly_core::queue::Track::from_uri(
                                caly_core::queue::TrackId(0),
                                value.clone(),
                            )];
                            self.engine.enqueue(tracks, true);
                            self.ui.status = format!("{} Enqueued: {value}", icon::PLAY);
                        }
                    }
                    InputKind::QueueFilter => {
                        if let Some(&target_idx) =
                            self.ui.telescope.matches.get(self.ui.telescope.selection)
                        {
                            self.ui.list.select(Some(target_idx));
                            self.engine.send(Control::PlayIndex(target_idx));
                            self.ui.status = format!("{} Jumped to track #{target_idx}", icon::PLAY);
                        }
                        self.ui.filter = value;
                    }
                    InputKind::BrowserFilter => {
                        if let Some(b) = &mut self.ui.browser {
                            b.set_filter(value.clone());
                            self.ui.status = format!("{} File filter: {value}", icon::SEARCH);
                        }
                    }
                }
                self.ui.input.clear();
                self.ui.mode = Mode::Queue;
                self.ui.last_render = Instant::now() - crate::TICK;
            }
            KeyCode::Char(c) => {
                self.ui.input.push(c);
                self.ui.update_telescope_matches(&snap.queue_titles);
            }
            KeyCode::Backspace => {
                self.ui.input.pop();
                self.ui.update_telescope_matches(&snap.queue_titles);
            }
            _ => {}
        }
        Ok(false)
    }

    fn handle_browser_key(&mut self, key: KeyEvent) -> std::io::Result<bool> {
        let Some(browser) = &mut self.ui.browser else {
            self.ui.focus = Focus::Main;
            return Ok(false);
        };
        let engine = &self.engine;

        match key.code {
            KeyCode::Down | KeyCode::Char('j') => browser.move_sel(1),
            KeyCode::Up | KeyCode::Char('k') => browser.move_sel(-1),
            KeyCode::Char('g') => browser.jump(true),
            KeyCode::Char('G') => browser.jump(false),
            KeyCode::PageDown | KeyCode::Char('d') if key.modifiers.contains(KeyModifiers::CONTROL) => {
                browser.move_sel(10);
            }
            KeyCode::PageUp | KeyCode::Char('u') if key.modifiers.contains(KeyModifiers::CONTROL) => {
                browser.move_sel(-10);
            }
            KeyCode::Left | KeyCode::Char('h') | KeyCode::Backspace => {
                browser.go_up();
            }
            KeyCode::Enter | KeyCode::Char('l') | KeyCode::Right => {
                if !browser.enter_selected() {
                    if let Some(t) = browser.selected().filter(|e| !e.is_dir) {
                        let track = caly_core::queue::Track::from_uri(
                            caly_core::queue::TrackId(0),
                            t.path.to_string_lossy().into_owned(),
                        );
                        engine.enqueue(vec![track], true);
                        self.ui.status = format!("{} Playing {}", icon::PLAY, t.name);
                    }
                }
            }
            KeyCode::Char('a') => {
                let paths = browser.selected_paths();
                let n = paths.len();
                if n > 0 {
                    let tracks = paths
                        .into_iter()
                        .map(|p| {
                            caly_core::queue::Track::from_uri(
                                caly_core::queue::TrackId(0),
                                p.to_string_lossy().into_owned(),
                            )
                        })
                        .collect();
                    engine.enqueue(tracks, false);
                    self.ui.status = format!("Added {n} item(s) to queue");
                }
            }
            KeyCode::Char('.') => {
                browser.toggle_hidden();
                self.ui.status.clone_from(&if browser.show_hidden() {
                    "Hidden files visible".into()
                } else {
                    "Hidden files hidden".into()
                });
            }
            KeyCode::Char('/') => {
                self.ui.mode = Mode::Input;
                self.ui.input_kind = InputKind::BrowserFilter;
                self.ui.input_label = format!(" {} Search files > ", icon::SEARCH);
                self.ui.input.clear();
            }
            KeyCode::Char('r') => {
                browser.refresh();
                self.ui.status = "Refreshed explorer".into();
            }
            KeyCode::Char('+') | KeyCode::Char('=') => {
                self.ui.browser_width = (self.ui.browser_width + 4).min(60);
            }
            KeyCode::Char('-') => {
                self.ui.browser_width = self.ui.browser_width.saturating_sub(4).max(20);
            }
            KeyCode::Char('f') => {
                self.toggle_browser();
            }
            KeyCode::Esc | KeyCode::Char('q') => {
                self.ui.focus = Focus::Main;
            }
            _ => {}
        }
        Ok(false)
    }

    fn handle_help_key(&mut self, key: KeyEvent) -> std::io::Result<bool> {
        match key.code {
            KeyCode::Esc | KeyCode::Char('q') | KeyCode::Char('?') => {
                self.ui.mode = Mode::Queue;
            }
            KeyCode::Down | KeyCode::Char('j') => {
                self.ui.help_scroll = self.ui.help_scroll.saturating_add(3);
            }
            KeyCode::Up | KeyCode::Char('k') => {
                self.ui.help_scroll = self.ui.help_scroll.saturating_sub(3);
            }
            _ => {}
        }
        Ok(false)
    }

    fn handle_queue_key(&mut self, key: KeyEvent) -> std::io::Result<bool> {
        let snap = self.engine.snapshot();
        let len = snap.queue_len;
        let sel = self.ui.list.selected();

        match key.code {
            KeyCode::Char('q') => return Ok(true),
            KeyCode::Char('?') => {
                self.ui.mode = Mode::Help;
                self.ui.help_scroll = 0;
                return Ok(false);
            }
            KeyCode::Char('i') => {
                self.ui.mode = Mode::SignalFlow;
                self.ui.help_scroll = 0;
                return Ok(false);
            }
            KeyCode::Down | KeyCode::Char('j') => {
                let next = sel
                    .unwrap_or(0)
                    .saturating_add(1)
                    .min(len.saturating_sub(1));
                self.ui.list.select(Some(next));
            }
            KeyCode::Up | KeyCode::Char('k') => {
                let prev = sel.unwrap_or(0).saturating_sub(1);
                self.ui.list.select(Some(prev));
            }
            KeyCode::Char('g') => {
                self.ui.list.select(Some(0));
            }
            KeyCode::Char('G') => {
                if len > 0 {
                    self.ui.list.select(Some(len - 1));
                }
            }
            KeyCode::Char('d') if key.modifiers.contains(KeyModifiers::CONTROL) => {
                let next = sel.unwrap_or(0).saturating_add(8).min(len.saturating_sub(1));
                self.ui.list.select(Some(next));
            }
            KeyCode::Char('u') if key.modifiers.contains(KeyModifiers::CONTROL) => {
                let prev = sel.unwrap_or(0).saturating_sub(8);
                self.ui.list.select(Some(prev));
            }
            KeyCode::Char('J') => {
                if let Some(i) = sel {
                    if i + 1 < len {
                        self.engine.send(Control::Move(i, i + 1));
                        self.ui.list.select(Some(i + 1));
                    }
                }
            }
            KeyCode::Char('K') => {
                if let Some(i) = sel {
                    if i > 0 {
                        self.engine.send(Control::Move(i, i - 1));
                        self.ui.list.select(Some(i - 1));
                    }
                }
            }
            KeyCode::Enter => {
                if let Some(i) = sel {
                    if i < len {
                        self.engine.send(Control::PlayIndex(i));
                    }
                }
            }
            KeyCode::Char(' ') => self.engine.send(Control::TogglePause),
            KeyCode::Char('s') => self.engine.send(Control::Stop),
            KeyCode::Char('n') => self.engine.send(Control::Next),
            KeyCode::Char('p') => self.engine.send(Control::Prev),
            KeyCode::Left | KeyCode::Char('h') => {
                let cur = snap.position.position;
                let target = cur.saturating_sub(Duration::from_secs(5));
                self.engine.send(Control::Seek(target));
                self.ui.status = format!("  Seek -5s ({})", format_time(target));
            }
            KeyCode::Right | KeyCode::Char('l') => {
                let cur = snap.position.position;
                let target = cur + Duration::from_secs(5);
                self.engine.send(Control::Seek(target));
                self.ui.status = format!("  Seek +5s ({})", format_time(target));
            }
            KeyCode::Char('H') => {
                let cur = snap.position.position;
                let target = cur.saturating_sub(Duration::from_secs(30));
                self.engine.send(Control::Seek(target));
                self.ui.status = format!("  Seek -30s ({})", format_time(target));
            }
            KeyCode::Char('L') => {
                let cur = snap.position.position;
                let target = cur + Duration::from_secs(30);
                self.engine.send(Control::Seek(target));
                self.ui.status = format!("  Seek +30s ({})", format_time(target));
            }
            KeyCode::Char('+') | KeyCode::Char('=') => {
                self.bump_volume(snap.volume, 1.0);
            }
            KeyCode::Char('-') => {
                self.bump_volume(snap.volume, -1.0);
            }
            KeyCode::Char('r') => {
                let next = match snap.repeat {
                    RepeatMode::Off => RepeatMode::All,
                    RepeatMode::All => RepeatMode::One,
                    RepeatMode::One => RepeatMode::Off,
                };
                self.engine.send(Control::SetRepeat(next));
            }
            KeyCode::Char('x') => self.engine.send(Control::ToggleShuffle),
            KeyCode::Char('d') => {
                if let Some(i) = sel {
                    self.engine.send(Control::Remove(i));
                }
            }
            KeyCode::Char('a') => {
                self.ui.mode = Mode::Input;
                self.ui.input_kind = InputKind::AddPath;
                self.ui.input_label = format!(" {} Add Path/URL > ", icon::PLAY);
                self.ui.input.clear();
            }
            KeyCode::Char('/') => {
                self.ui.mode = Mode::Input;
                self.ui.input_kind = InputKind::QueueFilter;
                self.ui.input_label = format!(" {} Telescope Search > ", icon::SEARCH);
                self.ui.input.clear();
                self.ui.telescope.selection = 0;
                self.ui.update_telescope_matches(&snap.queue_titles);
            }
            KeyCode::Char('f') => {
                self.toggle_browser();
            }
            _ => {}
        }
        Ok(false)
    }

    /// Handles mouse events (scrolling, clicking, double-click to play).
    pub fn handle_mouse(&mut self, m: MouseEvent) -> std::io::Result<bool> {
        if self.ui.mode == Mode::Help || self.ui.mode == Mode::SignalFlow {
            self.ui.mode = Mode::Queue;
            self.ui.last_render = Instant::now();
            return Ok(false);
        }

        if self.ui.mode != Mode::Queue {
            return Ok(false);
        }

        if matches!(
            m.kind,
            MouseEventKind::ScrollUp | MouseEventKind::ScrollDown
        ) {
            let d = if matches!(m.kind, MouseEventKind::ScrollUp) {
                -1isize
            } else {
                1isize
            };
            if self.ui.focus == Focus::Browser {
                if let Some(b) = &mut self.ui.browser {
                    b.move_sel(d);
                }
            } else {
                let len = self.engine.snapshot().queue_len;
                let sel = self.ui.list.selected().unwrap_or(0);
                let next = if d > 0 {
                    sel.saturating_add(1).min(len.saturating_sub(1))
                } else {
                    sel.saturating_sub(1)
                };
                self.ui.list.select(Some(next));
            }
            self.ui.last_render = Instant::now();
            return Ok(false);
        }

        if !matches!(m.kind, MouseEventKind::Down(MouseButton::Left)) {
            return Ok(false);
        }

        let Some(fr) = self.ui.frame else {
            return Ok(false);
        };

        let now = Instant::now();
        let dbl = self
            .ui
            .last_click
            .map(|(t, c, r)| now - t < Duration::from_millis(400) && c == m.column && r == m.row)
            .unwrap_or(false);
        self.ui.last_click = Some((now, m.column, m.row));

        let (x, y) = (m.column as i32, m.row as i32);
        let in_rect = |r: Rect| {
            x >= r.x as i32
                && x < (r.x + r.width) as i32
                && y >= r.y as i32
                && y < (r.y + r.height) as i32
        };

        if let Some(binner) = fr.browser_inner {
            if in_rect(binner) {
                self.ui.focus = Focus::Browser;
                let row = (y - binner.y as i32).max(0) as usize + fr.browser_offset;
                if let Some(b) = &mut self.ui.browser {
                    b.select_visible(row);
                }
                if dbl {
                    self.browser_activate();
                }
                self.ui.last_render = Instant::now();
                return Ok(false);
            }
        }

        if in_rect(fr.queue_inner) {
            self.ui.focus = Focus::Main;
            let row = (y - fr.queue_inner.y as i32).max(0) as usize + fr.queue_offset;
            if let Some(&real) = self.ui.queue_row_map.get(row) {
                self.ui.list.select(Some(real));
                if dbl {
                    self.engine.send(Control::PlayIndex(real));
                }
            }
            self.ui.last_render = Instant::now();
            return Ok(false);
        }

        if in_rect(fr.main) {
            self.ui.focus = Focus::Main;
            self.ui.last_render = Instant::now();
        }

        Ok(false)
    }

    fn browser_activate(&mut self) {
        let engine = &self.engine;
        let Some(browser) = &mut self.ui.browser else {
            return;
        };
        if browser.enter_selected() {
            return;
        }
        if let Some(t) = browser.selected().filter(|e| !e.is_dir) {
            let track = caly_core::queue::Track::from_uri(
                caly_core::queue::TrackId(0),
                t.path.to_string_lossy().into_owned(),
            );
            engine.enqueue(vec![track], true);
            self.ui.status = format!("{} Playing {}", icon::PLAY, t.name);
        }
    }

    fn bump_volume(&mut self, current: f32, dir: f32) {
        let base = self.ui.vol_target.unwrap_or(current);
        let target = crate::volume_step(base, dir, self.settings.volume_percent);
        self.ui.vol_target = Some(target);
        self.engine.send(Control::SetVolume(target));
    }

    fn toggle_browser(&mut self) {
        if self.ui.show_browser {
            self.ui.show_browser = false;
            if self.ui.focus == Focus::Browser {
                self.ui.focus = Focus::Main;
            }
            return;
        }
        if self.ui.browser.is_none() {
            let exts = browser::DEFAULT_EXTS
                .iter()
                .map(|s| s.to_string())
                .collect::<Vec<_>>();
            self.ui.browser = Some(browser::BrowserState::new(
                browser::BrowserState::music_or_home(),
                &exts,
            ));
        }
        self.ui.browser_list = ratatui::widgets::ListState::default();
        self.ui.show_browser = true;
        self.ui.focus = Focus::Browser;
        self.ui.status.clear();
    }
}
