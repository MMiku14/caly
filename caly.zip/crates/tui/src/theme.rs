//! TokyoNight & Catppuccin inspired unified design palette and icon constants.
use ratatui::style::{Color, Modifier, Style};

/// Central palette.
pub mod color {
    use super::Color;
    /// Terminal transparent background.
    pub const BG: Color = Color::Reset;
    /// Primary text foreground.
    pub const FG: Color = Color::Rgb(192, 202, 245);
    /// Electric cyan accent.
    pub const ACCENT_CYAN: Color = Color::Rgb(125, 207, 255);
    /// Soft blue accent (headings & directories).
    pub const ACCENT_BLUE: Color = Color::Rgb(122, 162, 247);
    /// TokyoNight purple accent (focus & keymaps).
    pub const ACCENT_PURPLE: Color = Color::Rgb(187, 154, 247);
    /// Emerald green accent (playing & bit-perfect).
    pub const ACCENT_GREEN: Color = Color::Rgb(158, 206, 106);
    /// Warm amber/yellow accent (paused & warnings).
    pub const ACCENT_YELLOW: Color = Color::Rgb(224, 175, 104);
    /// Coral red accent (errors & stopped).
    pub const ACCENT_RED: Color = Color::Rgb(247, 118, 142);
    /// Muted slate gray (borders, secondary text).
    pub const MUTED: Color = Color::Rgb(86, 95, 137);
    /// Deep surface container background.
    pub const SURFACE: Color = Color::Rgb(36, 40, 59);
    /// Highlighted list item background.
    pub const ACTIVE_BG: Color = Color::Rgb(41, 46, 66);
}

/// Modern NerdFont / Unicode iconography.
pub mod icon {
    /// Play icon.
    pub const PLAY: &str = "󰐊";
    /// Pause icon.
    pub const PAUSE: &str = "󰏤";
    /// Stop icon.
    pub const STOP: &str = "󰓛";
    /// Audio track glyph.
    pub const TRACK: &str = "󰎆";
    /// Vinyl record / disc.
    pub const DISC: &str = "󰝚";
    /// Folder directory.
    pub const FOLDER: &str = "";
    /// Generic file.
    pub const FILE: &str = "";
    /// Telescope search icon.
    pub const SEARCH: &str = "";
    /// Prompt cursor arrow.
    pub const PROMPT: &str = "";
    /// Volume speaker.
    pub const VOLUME: &str = "󰕾";
    /// Repeat mode.
    pub const REPEAT: &str = "󰑖";
    /// Shuffle mode.
    pub const SHUFFLE: &str = "󰒞";
    /// Clock / duration.
    pub const TIME: &str = "󰥔";
    /// Audio flow pipeline node.
    pub const FLOW: &str = "󰄰";
    /// Bit-perfect audiophile badge.
    pub const BIT_PERFECT: &str = "󰓃";
}

/// Standardized styles.
pub mod style {
    use super::color::*;
    use super::{Modifier, Style};

    /// Highlighted list item style.
    pub fn active_selection() -> Style {
        Style::new().bg(ACTIVE_BG).fg(ACCENT_CYAN).add_modifier(Modifier::BOLD)
    }

    /// Keybinding tag style in Which-Key.
    pub fn key_tag() -> Style {
        Style::new().fg(ACCENT_YELLOW).add_modifier(Modifier::BOLD)
    }

    /// Section header style.
    pub fn section_header() -> Style {
        Style::new().fg(ACCENT_PURPLE).add_modifier(Modifier::BOLD)
    }

    /// Subdued hint style.
    pub fn muted() -> Style {
        Style::new().fg(MUTED)
    }
}
