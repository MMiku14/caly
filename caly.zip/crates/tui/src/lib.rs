//! The **Caly TUI**: a modern, LazyVim-inspired ratatui frontend.
#![forbid(unsafe_code)]
#![warn(missing_docs, rust_2018_idioms)]

pub mod app;
pub mod browser;
pub mod handler;
pub mod settings;
pub mod state;
pub mod theme;
pub mod view;
pub mod widgets;

use std::time::Duration;

pub use app::Tui;
pub use state::{Focus, Mode, UiState};

use caly_engine::{PlayState, Snapshot};
use theme::icon;

/// Refresh interval (100 ms).
pub const TICK: Duration = Duration::from_millis(100);

/// Locates default album artwork cache path.
pub fn artwork_cache_dir() -> Option<std::path::PathBuf> {
    if let Some(x) = std::env::var_os("XDG_CACHE_HOME").filter(|v| !v.is_empty()) {
        return Some(std::path::PathBuf::from(x).join("caly").join("artwork"));
    }
    std::env::var_os("HOME").filter(|v| !v.is_empty()).map(|h| {
        std::path::PathBuf::from(h)
            .join(".cache")
            .join("caly")
            .join("artwork")
    })
}

/// Computes next volume step according to user percentage preference.
pub fn volume_step(current: f32, dir: f32, percent: bool) -> f32 {
    let (step, max) = if percent { (0.01, 1.0) } else { (0.05, 2.0) };
    (current + dir * step).clamp(0.0, max)
}

/// Convenience formatter for headless CLI status display.
pub fn headless_status(snap: &Snapshot) -> String {
    match (&snap.current, snap.state) {
        (Some(c), PlayState::Playing) => format!(
            "{} {}   {}   [{}]",
            icon::PLAY,
            c.title,
            caly_core::progress::format_progress(&snap.position),
            snap.output.clone().unwrap_or_default()
        ),
        (Some(c), PlayState::Paused) => format!("{} {}   {}", icon::PAUSE, c.title, snap.position),
        (None, _) => "caly: idle".to_string(),
        _ => String::new(),
    }
}
