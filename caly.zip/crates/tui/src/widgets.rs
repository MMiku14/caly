//! Reusable widgets: visualizer spectrum, volume gauge, and cover art renderer.
use ratatui::buffer::Buffer;
use ratatui::layout::{Alignment, Rect};
use ratatui::style::{Color, Modifier, Style};
use ratatui::text::{Line, Span};
use ratatui::widgets::{Block, BorderType, Borders, Paragraph};
use ratatui::Frame;

use caly_artwork::Artwork;
use caly_engine::PlayState;
use crate::theme::{color, icon};

const SPECTRUM_BARS: [&str; 8] = [" ", "▂", "▃", "▄", "▅", "▆", "▇", "█"];

/// Renders a responsive 8-band animated audio spectrum equalizer.
pub fn render_visualizer(state: PlayState, elapsed_millis: u128) -> Line<'static> {
    match state {
        PlayState::Playing => {
            let mut spans = Vec::with_capacity(9);
            spans.push(Span::styled(" ", Style::new().fg(color::ACCENT_CYAN)));
            // Deterministic audio-reactive pseudo-spectrum derived from playback clock
            for i in 0..8 {
                let t = (elapsed_millis as f64) / 160.0 + (i as f64) * 0.95;
                let height = (((t.sin() * 0.5 + 0.5) * 0.6 + (t * 1.7).cos() * 0.2) * 7.0)
                    .clamp(1.0, 7.0) as usize;
                let glyph = SPECTRUM_BARS[height];
                let c = match height {
                    0..=3 => color::ACCENT_GREEN,
                    4..=5 => color::ACCENT_CYAN,
                    _ => color::ACCENT_PURPLE,
                };
                spans.push(Span::styled(glyph, Style::new().fg(c)));
            }
            Line::from(spans)
        }
        PlayState::Paused => {
            Line::from(vec![
                Span::styled(" [", Style::new().fg(color::MUTED)),
                Span::styled("▃▅▆▅▃", Style::new().fg(color::ACCENT_YELLOW)),
                Span::styled("]", Style::new().fg(color::MUTED)),
            ])
        }
        PlayState::Stopped => {
            Line::from(Span::styled("  ──────  ", Style::new().fg(color::MUTED)))
        }
    }
}

/// Formats a mini volume progress bar like `[██████░░░░] 60%`.
pub fn format_volume_bar(volume: f32, bar_width: usize) -> Line<'static> {
    let pct = (volume.clamp(0.0, 2.0) * 100.0).round() as u32;
    let norm = (volume / 1.0).clamp(0.0, 1.0);
    let filled = ((bar_width as f32) * norm).round() as usize;
    let empty = bar_width.saturating_sub(filled);

    let bar_str = format!("[{}{}]", "█".repeat(filled), "░".repeat(empty));
    Line::from(vec![
        Span::styled(format!("{} ", icon::VOLUME), Style::new().fg(color::ACCENT_CYAN)),
        Span::styled(bar_str, Style::new().fg(color::ACCENT_CYAN)),
        Span::styled(format!(" {pct}%"), Style::new().fg(color::FG)),
    ])
}

/// Renders a stylized vinyl disc placeholder when artwork is loading or absent.
pub fn draw_cover_placeholder(f: &mut Frame<'_>, area: Rect) {
    if area.width < 6 || area.height < 3 {
        return;
    }
    let block = Block::default()
        .borders(Borders::ALL)
        .border_type(BorderType::Rounded)
        .border_style(Style::new().fg(color::MUTED));

    let text = vec![
        Line::raw(""),
        Line::from(Span::styled(
            format!(" {} ", icon::TRACK),
            Style::new().fg(color::ACCENT_PURPLE).add_modifier(Modifier::BOLD),
        )),
        Line::from(Span::styled("DISC", Style::new().fg(color::MUTED))),
    ];
    let p = Paragraph::new(text).block(block).alignment(Alignment::Center);
    f.render_widget(p, area);
}

/// Renders truecolor half-block album cover with bilinear nearest-neighbor scaling.
pub fn draw_cover_image(buf: &mut Buffer, art: &Artwork, area: Rect) {
    if area.width == 0 || area.height == 0 {
        return;
    }
    let (w, h_px) = (art.width as usize, art.height as usize);
    let cw = (area.width as usize).min(w);
    let ch = ((area.height as usize) * 2).min(h_px);
    if cw == 0 || ch == 0 {
        return;
    }
    let cells_h = ch.div_ceil(2);
    let ox = area.x + (area.width - cw as u16) / 2;
    let oy = area.y + (area.height - cells_h as u16) / 2;

    for cy in 0..cells_h {
        let py_top = (cy * 2 * h_px) / ch;
        let py_bottom = ((cy * 2 + 1) * h_px) / ch;
        for cx in 0..cw {
            let px = ((cx * w) / cw).min(w.saturating_sub(1));
            let py_t = py_top.min(h_px.saturating_sub(1));
            let py_b = py_bottom.min(h_px.saturating_sub(1));
            let i_top = (py_t * w + px) * 4;
            let i_bottom = (py_b * w + px) * 4;

            let top = if i_top + 3 < art.rgba.len() {
                [art.rgba[i_top], art.rgba[i_top + 1], art.rgba[i_top + 2]]
            } else {
                [0, 0, 0]
            };
            let bottom = if cy * 2 + 1 < ch && i_bottom + 3 < art.rgba.len() {
                [art.rgba[i_bottom], art.rgba[i_bottom + 1], art.rgba[i_bottom + 2]]
            } else {
                top
            };

            if let Some(cell) = buf.cell_mut((ox + cx as u16, oy + cy as u16)) {
                cell.set_symbol("\u{2580}");
                cell.set_fg(Color::Rgb(top[0], top[1], top[2]));
                cell.set_bg(Color::Rgb(bottom[0], bottom[1], bottom[2]));
            }
        }
    }
}
