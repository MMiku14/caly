//! TUI state models, active modes, focus, and modal dialogues.

use std::collections::HashSet;
use std::path::PathBuf;
use std::sync::mpsc::Receiver;
use std::time::Instant;

use caly_artwork::Artwork;
use ratatui::layout::Rect;
use ratatui::widgets::ListState;

use crate::browser::BrowserState;

/// Interaction and navigation modes of the TUI.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum Mode {
    /// Normal queue inspection and playback control.
    Queue,
    /// Modal input dialog (Telescope filter, Add Path, File Search).
    Input,
    /// Which-Key keybindings helper cheat sheet.
    Help,
    /// Audio signal flow pipeline graph inspector.
    SignalFlow,
}

/// Focused UI pane for keyboard input routing.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum Focus {
    /// Main view (Now Playing & Queue).
    Main,
    /// Neo-tree file browser sidebar.
    Browser,
}

/// Target purpose of text input modal.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum InputKind {
    /// Enqueueing a local file path or stream URL.
    AddPath,
    /// Telescope fuzzy filtering of the active queue.
    QueueFilter,
    /// Substring search within the file explorer.
    BrowserFilter,
}

/// Bounding boxes of interactive panes recorded during the last render pass.
#[derive(Debug, Clone, Copy, Default)]
pub struct FrameRects {
    /// Entire main workspace area.
    pub main: Rect,
    /// Inner content rectangle of the queue list widget.
    pub queue_inner: Rect,
    /// First visible queue item offset.
    pub queue_offset: usize,
    /// Explorer sidebar outer boundary.
    pub browser: Option<Rect>,
    /// Explorer sidebar list inner content area.
    pub browser_inner: Option<Rect>,
    /// Explorer sidebar scroll offset.
    pub browser_offset: usize,
}

/// Cached Telescope search state to eliminate per-frame filtering overhead.
#[derive(Debug, Default, Clone)]
pub struct TelescopeState {
    /// Last filtered query string.
    pub last_query: String,
    /// Matching indices in the queue.
    pub matches: Vec<usize>,
    /// Selected index within the matches slice.
    pub selection: usize,
}

/// Complete UI state owned by the TUI runner.
pub struct UiState {
    /// Current interaction mode.
    pub mode: Mode,
    /// Current keyboard input focus pane.
    pub focus: Focus,
    /// Whether file explorer sidebar is visible.
    pub show_browser: bool,
    /// Explorer sidebar width in terminal columns.
    pub browser_width: u16,
    /// Ratatui list state for queue scrolling.
    pub list: ListState,
    /// Persisted queue filter string.
    pub filter: String,
    /// Active text in input modal.
    pub input: String,
    /// Prompt prefix label for input modal.
    pub input_label: String,
    /// Active input category.
    pub input_kind: InputKind,
    /// Cached Telescope fuzzy search state.
    pub telescope: TelescopeState,
    /// LazyVim-style file explorer model.
    pub browser: Option<BrowserState>,
    /// List state for file explorer.
    pub browser_list: ListState,
    /// Scroll offset for help and flow modals.
    pub help_scroll: u16,
    /// Ephemeral status bar notification.
    pub status: String,
    /// Timestamp of last successful render.
    pub last_render: Instant,
    /// Cached view rectangles from previous frame.
    pub frame: Option<FrameRects>,
    /// Double-click tracking: (Instant, column, row).
    pub last_click: Option<(Instant, u16, u16)>,
    /// Visual row to real queue index mapping for hit-testing.
    pub queue_row_map: Vec<usize>,
    /// Decoded album cover artwork.
    pub cover: Option<Artwork>,
    /// URI associated with current cover.
    pub cover_uri: String,
    /// URI currently being loaded asynchronously.
    pub cover_loading: Option<String>,
    /// Receiver channel for background cover extraction.
    pub cover_rx: Option<Receiver<Option<Artwork>>>,
    /// Artwork disk cache directory.
    pub cache_dir: Option<PathBuf>,
    /// URIs that failed artwork decoding (avoids repeated thread spawning).
    pub artwork_failed: HashSet<String>,
    /// Target volume for smooth user adjustment.
    pub vol_target: Option<f32>,
}

impl UiState {
    /// Constructs initial UI state.
    pub fn new(initial_cursor: Option<usize>, cache_dir: Option<PathBuf>) -> Self {
        let mut list = ListState::default();
        list.select(initial_cursor.or(Some(0)));
        Self {
            mode: Mode::Queue,
            focus: Focus::Main,
            show_browser: false,
            browser_width: 38,
            list,
            filter: String::new(),
            input: String::new(),
            input_label: String::new(),
            input_kind: InputKind::AddPath,
            telescope: TelescopeState::default(),
            browser: None,
            browser_list: ListState::default(),
            help_scroll: 0,
            status: String::new(),
            last_render: Instant::now(),
            frame: None,
            last_click: None,
            queue_row_map: Vec::new(),
            cover: None,
            cover_uri: String::new(),
            cover_loading: None,
            cover_rx: None,
            cache_dir,
            artwork_failed: HashSet::new(),
            vol_target: None,
        }
    }

    /// Recomputes Telescope matches only when the query string changes.
    pub fn update_telescope_matches(&mut self, titles: &[String]) {
        let query = self.input.trim().to_lowercase();
        if self.telescope.last_query != query {
            self.telescope.matches = titles
                .iter()
                .enumerate()
                .filter(|(_, t)| query.is_empty() || t.to_lowercase().contains(&query))
                .map(|(i, _)| i)
                .collect();
            self.telescope.last_query = query;
            self.telescope.selection = 0;
        }
    }
}
