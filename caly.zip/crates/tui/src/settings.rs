//! User-facing settings.
use serde::Deserialize;
use std::path::{Path, PathBuf};

/// Effective settings.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub struct Settings {
    /// 1%-step volume.
    pub volume_percent: bool,
    /// Mouse interaction.
    pub mouse: bool,
    /// Album artwork.
    pub artwork: bool,
}

impl Default for Settings {
    fn default() -> Self {
        Self {
            volume_percent: false,
            mouse: true,
            artwork: true,
        }
    }
}

#[derive(Debug, Default, Deserialize)]
#[serde(default)]
struct Toml {
    volume: VolumeSection,
    ui: UiSection,
}

#[derive(Debug, Default, Deserialize)]
#[serde(default)]
struct VolumeSection {
    percent: Option<bool>,
}

#[derive(Debug, Default, Deserialize)]
#[serde(default)]
struct UiSection {
    mouse: Option<bool>,
    artwork: Option<bool>,
}

impl Settings {
    /// Loads settings from path.
    pub fn load(path: Option<&Path>) -> Self {
        let Some(path) = path.map(Path::to_path_buf).or_else(default_path) else {
            return Self::default();
        };
        let Ok(text) = std::fs::read_to_string(&path) else {
            return Self::default();
        };
        match toml::from_str::<Toml>(&text) {
            Ok(t) => Self {
                volume_percent: t.volume.percent.unwrap_or(false),
                mouse: t.ui.mouse.unwrap_or(true),
                artwork: t.ui.artwork.unwrap_or(true),
            },
            Err(e) => {
                log::warn!("caly: ignoring {}: {e}", path.display());
                Self::default()
            }
        }
    }

    /// Applies CLI overrides.
    pub fn with_overrides(
        mut self,
        volume_percent: Option<bool>,
        mouse: Option<bool>,
        artwork: Option<bool>,
    ) -> Self {
        if let Some(v) = volume_percent {
            self.volume_percent = v;
        }
        if let Some(v) = mouse {
            self.mouse = v;
        }
        if let Some(v) = artwork {
            self.artwork = v;
        }
        self
    }
}

fn default_path() -> Option<PathBuf> {
    let xdg = std::env::var_os("XDG_CONFIG_HOME");
    let home = std::env::var_os("HOME");
    config_path_from(xdg.as_deref(), home.as_deref())
}

fn config_path_from(
    xdg: Option<&std::ffi::OsStr>,
    home: Option<&std::ffi::OsStr>,
) -> Option<PathBuf> {
    let base = xdg
        .filter(|v| !v.is_empty())
        .map(PathBuf::from)
        .or_else(|| home.map(|h| PathBuf::from(h).join(".config")))?;
    Some(base.join("caly").join("config.toml"))
}
