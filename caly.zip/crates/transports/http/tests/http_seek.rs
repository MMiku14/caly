//! Integration tests for HTTP Range seeking using an in-process server.
use std::io::{Read, Write};
use std::net::{TcpListener, TcpStream};
use std::sync::atomic::{AtomicBool, AtomicUsize, Ordering};
use std::sync::Arc;
use std::thread;
use caly_core::transport::{Transport, TransportError};
use caly_transport_http::HttpTransport;

const BODY: &[u8] = b"0123456789abcdefghijklmnopqrstuvwxyz";

struct MiniServer {
    addr: String,
    requests: Arc<AtomicUsize>,
    stop: Arc<AtomicBool>,
    handle: Option<thread::JoinHandle<()>>,
}

impl MiniServer {
    fn start(ignore_ranges: bool) -> Self {
        let listener = TcpListener::bind("127.0.0.1:0").unwrap();
        listener.set_nonblocking(true).unwrap();
        let addr = format!("http://{}", listener.local_addr().unwrap());
        let requests = Arc::new(AtomicUsize::new(0));
        let stop = Arc::new(AtomicBool::new(false));
        let reqs = requests.clone();
        let done = stop.clone();
        let handle = thread::spawn(move || {
            while !done.load(Ordering::SeqCst) {
                let stream = match listener.accept() {
                    Ok((s, _)) => s,
                    Err(e) if e.kind() == std::io::ErrorKind::WouldBlock => {
                        thread::sleep(std::time::Duration::from_millis(10));
                        continue;
                    }
                    Err(_) => break,
                };
                let mut s: TcpStream = stream;
                reqs.fetch_add(1, Ordering::SeqCst);
                let mut buf = [0u8; 4096];
                let n = s.read(&mut buf).unwrap_or(0);
                let head = String::from_utf8_lossy(&buf[..n]);
                let range = head
                    .lines()
                    .find(|l| l.to_lowercase().starts_with("range:"))
                    .map(|l| l.split_whitespace().nth(1).unwrap_or("").to_string());
                let resp = if ignore_ranges {
                    let mut r = format!(
                        "HTTP/1.1 200 OK\r\nContent-Length: {}\r\nConnection: close\r\n\r\n",
                        BODY.len()
                    )
                    .into_bytes();
                    r.extend_from_slice(BODY);
                    r
                } else {
                    match range {
                        Some(r) if r.starts_with("bytes=") => {
                            let from: usize = r["bytes=".len()..]
                                .trim_end_matches('-')
                                .parse()
                                .unwrap_or(0);
                            let slice = &BODY[from.min(BODY.len())..];
                            let mut resp = format!(
                                "HTTP/1.1 206 Partial Content\r\nContent-Length: {}\r\nContent-Range: bytes {}-{}/{}\r\nConnection: close\r\n\r\n",
                                slice.len(),
                                from,
                                BODY.len() - 1,
                                BODY.len()
                            )
                            .into_bytes();
                            resp.extend_from_slice(slice);
                            resp
                        }
                        _ => {
                            let mut r = format!("HTTP/1.1 200 OK\r\nContent-Length: {}\r\nConnection: close\r\n\r\n", BODY.len())
                                .into_bytes();
                            r.extend_from_slice(BODY);
                            r
                        }
                    }
                };
                let _ = s.write_all(&resp);
            }
        });
        Self {
            addr,
            requests,
            stop,
            handle: Some(handle),
        }
    }
}

impl Drop for MiniServer {
    fn drop(&mut self) {
        self.stop.store(true, Ordering::SeqCst);
        let _ = TcpStream::connect(self.addr.trim_start_matches("http://"));
        let _ = self.handle.take().map(|h| h.join());
    }
}

#[test]
fn range_server_seeks_and_reads() {
    let srv = MiniServer::start(false);
    let mut t = HttpTransport::open(&srv.addr).unwrap();
    assert_eq!(t.len(), Some(BODY.len() as u64));
    let mut buf = [0u8; 10];
    let n = t.read(&mut buf).unwrap();
    assert_eq!(n, 10);
    let p = t.seek(20).unwrap();
    assert_eq!(p, 20);
    assert!(t.seekable());
    let n = t.read(&mut buf).unwrap();
    assert_eq!(n, 10);
    assert_eq!(&buf[..n], &b"klmnopqrst"[..n]);
    let before = srv.requests.load(Ordering::SeqCst);
    let p = t.seek(BODY.len() as u64).unwrap();
    assert_eq!(p, BODY.len() as u64);
    assert_eq!(srv.requests.load(Ordering::SeqCst), before);
    let n = t.read(&mut buf).unwrap();
    assert_eq!(n, 0, "expected EOF after seek-to-end");
}

#[test]
fn range_ignoring_server_is_not_seekable() {
    let srv = MiniServer::start(true);
    let mut t = HttpTransport::open(&srv.addr).unwrap();
    let mut buf = [0u8; 4];
    let _ = t.read(&mut buf).unwrap();
    let res = t.seek(10);
    assert!(
        matches!(res, Err(TransportError::Unsupported)),
        "expected Unsupported, got {res:?}"
    );
}
