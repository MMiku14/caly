//! HTTP(S) transport for Caly.
#![forbid(unsafe_code)]
#![warn(missing_docs)]

use std::io::Read;
use caly_core::transport::{
    is_http_uri, Transport, TransportError, TransportFactory, TransportKind, TransportResult,
};

const USER_AGENT: &str = concat!("caly/", env!("CARGO_PKG_VERSION"));

/// An HTTP(S) byte stream with optional Range-based seeking.
pub struct HttpTransport {
    url: String,
    agent: ureq::Agent,
    reader: Box<dyn Read + Send>,
    pos: u64,
    len: Option<u64>,
    seekable: bool,
}

impl HttpTransport {
    /// Opens `url` and issues a `GET` request immediately.
    pub fn open(url: &str) -> TransportResult<Self> {
        let agent = ureq::AgentBuilder::new()
            .user_agent(USER_AGENT)
            .timeout_connect(std::time::Duration::from_secs(10))
            .timeout_read(std::time::Duration::from_secs(30))
            .build();
        Self::open_with(url, agent)
    }

    fn open_with(url: &str, agent: ureq::Agent) -> TransportResult<Self> {
        let req = agent.get(url);
        let resp = req
            .call()
            .map_err(|e| TransportError::Other(format!("GET {url}: {e}")))?;
        let len = resp
            .header("Content-Length")
            .and_then(|v| v.parse::<u64>().ok());
        let status = resp.status();
        match status {
            200 | 206 => {}
            _ => {
                return Err(TransportError::Other(format!(
                    "GET {url}: HTTP status {status}"
                )));
            }
        }
        let seekable = resp
            .header("Accept-Ranges")
            .map(|v| v.eq_ignore_ascii_case("bytes"))
            .unwrap_or(false)
            || status == 206;
        let reader: Box<dyn Read + Send> = Box::new(resp.into_reader());
        Ok(Self {
            url: url.to_string(),
            agent,
            reader,
            pos: 0,
            len,
            seekable,
        })
    }

    fn reopen_at(&mut self, pos: u64) -> TransportResult<()> {
        let req = self
            .agent
            .get(&self.url)
            .set("Range", &format!("bytes={pos}-"));
        let resp = req
            .call()
            .map_err(|e| TransportError::Other(format!("GET {}: {e}", self.url)))?;
        let status = resp.status();
        match status {
            206 => {
                self.seekable = true;
                self.pos = pos;
                if let Some(l) = resp.header("Content-Range") {
                    if let Some(total) = l.rsplit('/').next().and_then(|t| t.parse::<u64>().ok()) {
                        self.len = Some(total);
                    }
                }
                self.reader = Box::new(resp.into_reader());
                Ok(())
            }
            200 => Err(TransportError::Unsupported),
            _ => Err(TransportError::Other(format!(
                "GET {} bytes={pos}-: HTTP status {status}",
                self.url
            ))),
        }
    }
}

impl Transport for HttpTransport {
    fn read(&mut self, buf: &mut [u8]) -> TransportResult<usize> {
        let n = self
            .reader
            .read(buf)
            .map_err(|e| TransportError::Other(format!("read: {e}")))?;
        self.pos += n as u64;
        Ok(n)
    }

    fn seek(&mut self, pos: u64) -> TransportResult<u64> {
        if pos == self.pos {
            return Ok(self.pos);
        }
        if let Some(len) = self.len {
            if pos >= len {
                self.pos = len;
                self.reader = Box::new(std::io::empty());
                return Ok(len);
            }
        }
        // Small forward skip optimization (skip up to 64 KB by consuming current stream)
        if self.seekable && pos > self.pos && pos - self.pos <= 64 * 1024 {
            let skip = pos - self.pos;
            let mut sink = std::io::sink();
            if let Ok(n) = std::io::copy(&mut self.reader.by_ref().take(skip), &mut sink) {
                self.pos += n;
                if self.pos == pos {
                    return Ok(self.pos);
                }
            }
        }
        self.reopen_at(pos)?;
        Ok(self.pos)
    }

    fn len(&self) -> Option<u64> {
        self.len
    }

    fn seekable(&self) -> bool {
        self.seekable
    }

    fn origin(&self) -> &str {
        &self.url
    }
}

/// Factory of HTTP(S) transports.
pub struct HttpTransportFactory;

impl TransportFactory for HttpTransportFactory {
    fn kind(&self) -> TransportKind {
        TransportKind::Http
    }
    fn can_open(&self, uri: &str) -> bool {
        is_http_uri(uri)
    }
    fn open(&self, uri: &str) -> TransportResult<Box<dyn Transport>> {
        HttpTransport::open(uri).map(|t| Box::new(t) as Box<dyn Transport>)
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn kind_matches() {
        assert_eq!(HttpTransportFactory.kind(), TransportKind::Http);
    }
}
