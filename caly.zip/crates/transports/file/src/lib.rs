//! Local-filesystem [`TransportFactory`] for Caly.
#![forbid(unsafe_code)]
#![warn(missing_docs)]

use caly_core::transport::{
    is_file_uri, is_http_uri, FileTransport, Transport, TransportFactory, TransportKind,
    TransportResult,
};

/// Factory producing [`FileTransport`]s.
pub struct FileTransportFactory;

impl TransportFactory for FileTransportFactory {
    fn kind(&self) -> TransportKind {
        TransportKind::File
    }
    fn can_open(&self, uri: &str) -> bool {
        !is_http_uri(uri) && is_file_uri(uri)
    }
    fn open(&self, uri: &str) -> TransportResult<Box<dyn Transport>> {
        FileTransport::open(uri).map(|t| Box::new(t) as Box<dyn Transport>)
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::io::Write;

    #[test]
    fn opens_a_real_file() {
        let dir = std::env::temp_dir().join("caly-file-test");
        std::fs::create_dir_all(&dir).unwrap();
        let path = dir.join("a.bin");
        {
            let mut f = std::fs::File::create(&path).unwrap();
            f.write_all(&[1, 2, 3, 4]).unwrap();
        }
        let f = FileTransportFactory;
        assert!(f.can_open(path.to_str().unwrap()));
        let mut t = f.open(path.to_str().unwrap()).unwrap();
        let mut buf = [0u8; 4];
        assert_eq!(t.read(&mut buf).unwrap(), 4);
        assert_eq!(buf, [1, 2, 3, 4]);
        assert_eq!(t.len(), Some(4));
        assert_eq!(t.seek(2).unwrap(), 2);
    }
}
