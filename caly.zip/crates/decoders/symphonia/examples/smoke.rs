//! Decodes a file through the Symphonia source until EOF.
use caly_core::source::{SourceBackend, SourceFactory};
use caly_core::transport::FileTransport;
use caly_source_symphonia::SymphoniaFactory;

fn main() {
    let uri = std::env::args().nth(1).expect("usage: smoke <file>");
    let f = SymphoniaFactory;
    let t = FileTransport::open(uri.as_str()).unwrap();
    let mut src: Box<dyn SourceBackend> = f.open(uri.as_str(), Box::new(t)).unwrap();
    println!("info: {:?}", src.stream_info());
    let mut total: u64 = 0;
    let mut n = 0;
    loop {
        match src.next_chunk(4096) {
            Ok(Some(buf)) => {
                total += buf.frames() as u64;
                n += 1;
            }
            Ok(None) => {
                println!("EOF at chunk {n}, total {total} frames");
                break;
            }
            Err(e) => {
                println!("ERR: {e}");
                std::process::exit(1);
            }
        }
    }
}
