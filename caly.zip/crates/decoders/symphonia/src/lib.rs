//! **Symphonia** decoding backend.
#![forbid(unsafe_code)]
#![warn(missing_docs, rust_2018_idioms)]

use std::io::{self, Read, Seek, SeekFrom};
use std::sync::Mutex;
use std::time::Duration;
use symphonia::core::audio::{SampleBuffer, SignalSpec};
use symphonia::core::codecs::{Decoder, DecoderOptions, CODEC_TYPE_NULL};
use symphonia::core::errors::Error as SymError;
use symphonia::core::formats::{FormatOptions, FormatReader, SeekMode, SeekTo};
use symphonia::core::io::{MediaSource, MediaSourceStream, MediaSourceStreamOptions};
use symphonia::core::meta::MetadataOptions;
use symphonia::core::probe::Hint;
use caly_core::audio::AudioBuffer;
use caly_core::media::{ChannelLayout, Channels, SampleFormat};
use caly_core::source::{
    ProbeInfo, SourceBackend, SourceError, SourceFactory, StreamInfo, TrackMeta,
};
use caly_core::transport::Transport;

const SUPPORTED_EXT: &[&str] = &[
    "mp3", "flac", "ogg", "oga", "opus", "m4a", "aac", "wav", "aiff", "aif", "alac", "mp4", "mka",
];

/// Factory for [`SymphoniaSource`].
pub struct SymphoniaFactory;

impl SourceFactory for SymphoniaFactory {
    fn id(&self) -> &'static str {
        "symphonia"
    }
    fn name(&self) -> &'static str {
        "Symphonia (pure Rust)"
    }
    fn can_open(&self, uri: &str) -> bool {
        let path = caly_core::transport::file_uri_to_path(uri);
        match path.extension().and_then(|e| e.to_str()) {
            Some(ext) => SUPPORTED_EXT.contains(&ext.to_ascii_lowercase().as_str()),
            None => false,
        }
    }
    fn probe(&self, uri: &str, transport: Box<dyn Transport>) -> Result<ProbeInfo, SourceError> {
        let reader = Reader::open(uri, transport)?;
        let (sample, duration, meta) = reader.probe();
        Ok(ProbeInfo {
            meta,
            duration,
            sample,
        })
    }
    fn open(
        &self,
        uri: &str,
        transport: Box<dyn Transport>,
    ) -> Result<Box<dyn SourceBackend>, SourceError> {
        let reader = Reader::open(uri, transport)?;
        Ok(Box::new(SymphoniaSource {
            inner: reader,
            eof: false,
            pending: Vec::new(),
        }))
    }
}

/// A live Symphonia decoding session.
pub struct SymphoniaSource {
    inner: Reader,
    eof: bool,
    pending: Vec<f32>,
}

impl SourceBackend for SymphoniaSource {
    fn next_chunk(&mut self, max_frames: usize) -> Result<Option<AudioBuffer>, SourceError> {
        if self.eof {
            return Ok(None);
        }
        let info = self
            .inner
            .info()
            .ok_or_else(|| SourceError::Decode("stream has no audio (yet)".into()))?;
        let ch = info.channels.get() as usize;
        let channels = info.channels;
        let rate = info.sample_rate;
        let mut samples: Vec<f32> = Vec::with_capacity(max_frames * ch);
        if !self.pending.is_empty() {
            let room = max_frames * ch;
            let take = room.min(self.pending.len());
            samples.extend_from_slice(&self.pending[..take]);
            self.pending.drain(..take);
        }
        while samples.len() / ch < max_frames {
            match self.inner.decode_one()? {
                Some((interleaved, _)) => {
                    if interleaved.is_empty() {
                        continue;
                    }
                    let room = max_frames * ch - samples.len();
                    if interleaved.len() <= room {
                        samples.extend_from_slice(&interleaved);
                    } else {
                        samples.extend_from_slice(&interleaved[..room]);
                        self.pending = interleaved[room..].to_vec();
                    }
                }
                None => {
                    self.eof = true;
                    break;
                }
            }
        }
        if samples.is_empty() && self.eof && self.pending.is_empty() {
            return Ok(None);
        }
        Ok(Some(AudioBuffer {
            channels,
            sample_rate: rate,
            layout: ChannelLayout::from_mask(default_mask(channels)),
            samples,
        }))
    }

    fn seek(&mut self, pos: Duration) -> Result<(), SourceError> {
        self.inner.seek(pos)?;
        self.eof = false;
        self.pending.clear();
        Ok(())
    }

    fn reset(&mut self) -> Result<(), SourceError> {
        self.inner.seek(Duration::ZERO)?;
        self.eof = false;
        self.pending.clear();
        Ok(())
    }

    fn track_meta(&self) -> &TrackMeta {
        self.inner.meta()
    }

    fn stream_info(&self) -> Option<&StreamInfo> {
        self.inner.info()
    }
}

struct Reader {
    format: Box<dyn FormatReader>,
    decoder: Box<dyn Decoder>,
    meta: TrackMeta,
    duration: Option<Duration>,
    info: Option<StreamInfo>,
    spec: Option<SignalSpec>,
    track_id: u32,
}

impl Reader {
    fn open(_uri: &str, transport: Box<dyn Transport>) -> Result<Self, SourceError> {
        let hint = Hint::new();
        let stream = MediaSourceStream::new(
            Box::new(TransportAdapter::new(transport)),
            MediaSourceStreamOptions::default(),
        );
        let fmt_opts = FormatOptions::default();
        let meta_opts = MetadataOptions::default();
        let probed = symphonia::default::get_probe()
            .format(&hint, stream, &fmt_opts, &meta_opts)
            .map_err(|e| SourceError::Decode(format!("probe: {e}")))?;
        let mut format = probed.format;
        let track = format
            .tracks()
            .iter()
            .find(|t| t.codec_params.codec != CODEC_TYPE_NULL)
            .ok_or_else(|| SourceError::Decode("no audio track".into()))?;
        let track_id = track.id;
        let codec_params = &track.codec_params;
        let decoder = symphonia::default::get_codecs()
            .make(codec_params, &DecoderOptions::default())
            .map_err(|e| SourceError::Decode(format!("codec: {e}")))?;
        let info = codec_params
            .sample_rate
            .zip(codec_params.channels.map(|c| c.count()))
            .and_then(|(r, n)| {
                Channels::new(n as u8).ok().map(|ch| StreamInfo {
                    sample_rate: r,
                    channels: ch,
                    layout: ChannelLayout::from_mask(default_mask(ch)),
                    format: SampleFormat::F32,
                })
            });
        let duration = codec_params.n_frames.map(|n| {
            Duration::from_secs_f64(n as f64 / codec_params.sample_rate.unwrap_or(44100) as f64)
        });
        let meta = read_meta(&format.metadata());
        Ok(Self {
            format,
            decoder,
            meta,
            duration,
            info,
            spec: None,
            track_id,
        })
    }

    fn probe(&self) -> (Option<StreamInfo>, Option<Duration>, TrackMeta) {
        (self.info, self.duration, self.meta.clone())
    }

    fn meta(&self) -> &TrackMeta {
        &self.meta
    }

    fn info(&self) -> Option<&StreamInfo> {
        self.info.as_ref()
    }

    #[allow(clippy::type_complexity)]
    fn decode_one(&mut self) -> Result<Option<(Vec<f32>, SignalSpec)>, SourceError> {
        loop {
            let packet = match self.format.next_packet() {
                Ok(p) => p,
                Err(SymError::IoError(e)) if e.kind() == io::ErrorKind::UnexpectedEof => {
                    return Ok(None);
                }
                Err(SymError::ResetRequired) => {
                    self.decoder.reset();
                    continue;
                }
                Err(e) => return Err(SourceError::Decode(format!("packet: {e}"))),
            };
            if packet.track_id() != self.track_id {
                continue;
            }
            match self.decoder.decode(&packet) {
                Ok(decoded) => {
                    let spec = *decoded.spec();
                    self.spec = Some(spec);
                    let mut buf = SampleBuffer::<f32>::new(decoded.capacity() as u64, spec);
                    buf.copy_interleaved_ref(decoded);
                    let samples = buf.samples().to_vec();
                    return Ok(Some((samples, spec)));
                }
                Err(SymError::DecodeError(_)) => continue,
                Err(SymError::IoError(e)) if e.kind() == io::ErrorKind::UnexpectedEof => {
                    return Ok(None);
                }
                Err(e) => return Err(SourceError::Decode(format!("decode: {e}"))),
            }
        }
    }

    fn seek(&mut self, pos: Duration) -> Result<(), SourceError> {
        let time = symphonia::core::units::Time {
            seconds: pos.as_secs(),
            frac: pos.subsec_nanos() as f64 / 1e9,
        };
        self.format
            .seek(
                SeekMode::Accurate,
                SeekTo::Time {
                    time,
                    track_id: None,
                },
            )
            .map_err(|e| SourceError::Seek(format!("{e}")))?;
        self.decoder.reset();
        self.spec = None;
        Ok(())
    }
}

struct TransportAdapter {
    inner: Mutex<TransportBox>,
}

struct TransportBox {
    transport: Box<dyn Transport>,
    pos: u64,
}

impl TransportAdapter {
    fn new(transport: Box<dyn Transport>) -> Self {
        Self {
            inner: Mutex::new(TransportBox { transport, pos: 0 }),
        }
    }
}

impl Read for TransportAdapter {
    fn read(&mut self, buf: &mut [u8]) -> io::Result<usize> {
        let mut b = self.inner.lock().unwrap();
        match b.transport.read(buf) {
            Ok(n) => {
                b.pos += n as u64;
                Ok(n)
            }
            Err(_) => Err(io::Error::other("transport read failed")),
        }
    }
}

impl Seek for TransportAdapter {
    fn seek(&mut self, pos: SeekFrom) -> io::Result<u64> {
        let mut b = self.inner.lock().unwrap();
        let target = match pos {
            SeekFrom::Start(p) => p,
            SeekFrom::Current(d) => {
                let base = b.pos as i64;
                let p = base
                    .checked_add(d)
                    .ok_or_else(|| io::Error::new(io::ErrorKind::InvalidInput, "seek overflow"))?;
                if p < 0 {
                    return Err(io::Error::new(io::ErrorKind::InvalidInput, "seek < 0"));
                }
                p as u64
            }
            SeekFrom::End(d) => {
                let len = b.transport.len().unwrap_or(b.pos) as i64;
                let p = len
                    .checked_add(d)
                    .ok_or_else(|| io::Error::new(io::ErrorKind::InvalidInput, "seek overflow"))?;
                if p < 0 {
                    return Err(io::Error::new(io::ErrorKind::InvalidInput, "seek < 0"));
                }
                p as u64
            }
        };
        b.transport
            .seek(target)
            .map_err(|_| io::Error::other("transport seek failed"))?;
        b.pos = target;
        Ok(target)
    }
}

impl MediaSource for TransportAdapter {
    fn is_seekable(&self) -> bool {
        self.inner.lock().unwrap().transport.seekable()
    }
    fn byte_len(&self) -> Option<u64> {
        self.inner.lock().unwrap().transport.len()
    }
}

fn default_mask(channels: Channels) -> u32 {
    let n = channels.get() as usize;
    if n == 4 {
        return ChannelLayout::FRONT_LEFT
            | ChannelLayout::FRONT_RIGHT
            | ChannelLayout::BACK_LEFT
            | ChannelLayout::BACK_RIGHT;
    }
    let flags = [
        ChannelLayout::FRONT_LEFT,
        ChannelLayout::FRONT_RIGHT,
        ChannelLayout::FRONT_CENTER,
        ChannelLayout::LFE,
        ChannelLayout::BACK_LEFT,
        ChannelLayout::BACK_RIGHT,
        ChannelLayout::SIDE_LEFT,
        ChannelLayout::SIDE_RIGHT,
    ];
    let n = n.min(flags.len());
    flags.iter().take(n).fold(1u32, |m, f| m | f)
}

fn read_meta(m: &symphonia::core::meta::Metadata<'_>) -> TrackMeta {
    let mut meta = TrackMeta::default();
    let Some(rev) = m.current() else {
        return meta;
    };
    let mut title = None;
    let mut artist = None;
    let mut album = None;
    let mut date = None;
    for tag in rev.tags() {
        let key = tag.key.to_ascii_lowercase();
        let value = tag.value.to_string();
        match key.as_str() {
            "title" => title = Some(value),
            "artist" | "album_artist" => artist = Some(value),
            "album" => album = Some(value),
            "date" | "year" => date = Some(value),
            _ => {}
        }
    }
    meta.title = title.filter(|s| !s.is_empty());
    meta.artist = artist.filter(|s| !s.is_empty());
    meta.album = album.filter(|s| !s.is_empty());
    if let Some(d) = date {
        let year: String = d.chars().take(4).collect();
        meta.year = year.parse::<u32>().ok();
    }
    meta
}
