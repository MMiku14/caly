//! End-to-end decode tests against real media.
use std::path::PathBuf;
use std::process::Command;
use std::time::Duration;
use caly_core::audio::AudioBuffer;
use caly_core::source::{SourceBackend, SourceFactory};
use caly_core::transport::FileTransport;
use caly_source_ffmpeg::FfmpegFactory;

fn ffmpeg() -> Option<Command> {
    if Command::new("ffmpeg").arg("-version").output().is_err() {
        return None;
    }
    Some(Command::new("ffmpeg"))
}

fn make_wav(dir: &std::path::Path) -> Option<PathBuf> {
    let path = dir.join("sine-44100-2ch.wav");
    let mut cmd = ffmpeg()?;
    let status = cmd
        .args(["-y", "-f", "lavfi", "-i"])
        .arg("sine=frequency=440:duration=2")
        .args(["-f", "lavfi", "-i"])
        .arg("sine=frequency=660:duration=2")
        .args([
            "-filter_complex",
            "[0:a][1:a]amerge=inputs=2[a]",
            "-map",
            "[a]",
        ])
        .args(["-ar", "44100", "-ac", "2", "-c:a", "pcm_s16le"])
        .arg(&path)
        .output()
        .ok()?;
    if !status.status.success() {
        return None;
    }
    Some(path)
}

fn make_flac(dir: &std::path::Path) -> Option<PathBuf> {
    let wav = make_wav(dir)?;
    let path = dir.join("sine.flac");
    let mut cmd = ffmpeg()?;
    let status = cmd
        .args(["-y", "-i"])
        .arg(&wav)
        .args(["-c:a", "flac"])
        .arg(&path)
        .output()
        .ok()?;
    if !status.status.success() {
        return None;
    }
    Some(path)
}

fn decode_all(mut src: Box<dyn SourceBackend>) -> (Vec<f32>, AudioBuffer, usize) {
    let mut all = Vec::new();
    let mut last: Option<AudioBuffer> = None;
    let mut chunks = 0usize;
    while let Some(buf) = src.next_chunk(4096).expect("decode") {
        all.extend_from_slice(&buf.samples);
        last = Some(buf);
        chunks += 1;
    }
    (all, last.expect("at least one chunk"), chunks)
}

#[test]
fn decodes_wav_via_custom_avio() {
    let dir = std::env::temp_dir().join(format!("caly-ffmpeg-{}", std::process::id()));
    std::fs::create_dir_all(&dir).unwrap();
    let Some(path) = make_wav(&dir) else {
        eprintln!("ffmpeg not available; skipping");
        return;
    };
    let factory = FfmpegFactory::new();
    assert!(factory.can_open(path.to_str().unwrap()));
    let transport = FileTransport::open(path.to_str().unwrap()).unwrap();
    let src: Box<dyn SourceBackend> = factory
        .open(path.to_str().unwrap(), Box::new(transport))
        .unwrap();
    let info = src.stream_info().cloned().expect("stream info");
    assert_eq!(info.sample_rate, 44100);
    assert_eq!(info.channels.get(), 2);
    let (all, _last, chunks) = decode_all(src);
    assert!(chunks >= 2, "expected several chunks, got {chunks}");
    let frames = all.len() / 2;
    assert!(
        (frames as i64 - 88200).abs() < 100,
        "expected ~88200 frames, got {frames}"
    );
    let peak = all.iter().fold(0.0f32, |m, s| m.max(s.abs()));
    assert!(peak > 0.05 && peak <= 1.5, "peak {peak}");
    let first_diff = all
        .chunks_exact(2)
        .take(4410)
        .any(|f| (f[0] - f[1]).abs() > 0.05);
    assert!(first_diff, "stereo channels should differ");
    std::fs::remove_dir_all(&dir).ok();
}

#[test]
fn decodes_flac_and_probes_metadata() {
    let dir = std::env::temp_dir().join(format!("caly-ffmpeg-f-{}", std::process::id()));
    std::fs::create_dir_all(&dir).unwrap();
    let Some(path) = make_flac(&dir) else {
        eprintln!("ffmpeg not available; skipping");
        return;
    };
    let factory = FfmpegFactory::new();
    let transport = FileTransport::open(path.to_str().unwrap()).unwrap();
    let probe = factory
        .probe(path.to_str().unwrap(), Box::new(transport))
        .expect("probe");
    assert!(probe.duration.is_some());
    assert_eq!(probe.sample.map(|s| s.sample_rate), Some(44100));
    let transport = FileTransport::open(path.to_str().unwrap()).unwrap();
    let src: Box<dyn SourceBackend> = factory
        .open(path.to_str().unwrap(), Box::new(transport))
        .unwrap();
    let (all, _, _) = decode_all(src);
    let frames = all.len() / 2;
    assert!(
        (frames as i64 - 88200).abs() < 1500,
        "expected ~88200 frames, got {frames}"
    );
    std::fs::remove_dir_all(&dir).ok();
}

#[test]
fn seek_is_repeatable_and_near_target() {
    let dir = std::env::temp_dir().join(format!("caly-ffmpeg-s-{}", std::process::id()));
    std::fs::create_dir_all(&dir).unwrap();
    let Some(path) = make_wav(&dir) else {
        eprintln!("ffmpeg not available; skipping");
        return;
    };
    let factory = FfmpegFactory::new();
    let transport = FileTransport::open(path.to_str().unwrap()).unwrap();
    let mut src: Box<dyn SourceBackend> = factory
        .open(path.to_str().unwrap(), Box::new(transport))
        .unwrap();
    src.seek(Duration::from_millis(1000)).expect("seek");
    let mut got = Vec::new();
    while let Some(b) = src.next_chunk(4096).expect("decode after seek") {
        got.extend_from_slice(&b.samples);
        if got.len() >= 4096 * 2 {
            break;
        }
    }
    assert!(got.len() >= 4096, "no audio after seek");
    src.seek(Duration::from_millis(500)).expect("second seek");
    let mut got2 = Vec::new();
    while let Some(b) = src.next_chunk(4096).expect("decode after second seek") {
        got2.extend_from_slice(&b.samples);
        if got2.len() >= 4096 * 2 {
            break;
        }
    }
    assert!(got2.len() >= 4096);
    std::fs::remove_dir_all(&dir).ok();
}

#[test]
fn rejects_garbage_input() {
    let dir = std::env::temp_dir().join(format!("caly-ffmpeg-g-{}", std::process::id()));
    std::fs::create_dir_all(&dir).unwrap();
    let path = dir.join("garbage.bin");
    std::fs::write(&path, vec![0u8; 4096]).unwrap();
    let factory = FfmpegFactory::new();
    let transport = FileTransport::open(path.to_str().unwrap()).unwrap();
    let res = factory.open(path.to_str().unwrap(), Box::new(transport));
    assert!(res.is_err(), "garbage must not open");
    std::fs::remove_dir_all(&dir).ok();
}
