//! FFmpeg decoding backend.
#![deny(unsafe_code)]
#![warn(missing_docs, rust_2018_idioms)]

mod ffi;

use std::time::Duration;
use caly_core::audio::AudioBuffer;
use caly_core::media::SampleFormat;
use caly_core::source::{
    ProbeInfo, SourceBackend, SourceError, SourceFactory, StreamInfo, TrackMeta,
};
use caly_core::transport::Transport;

pub use ffi::FfmpegReader;

const PREFERRED_EXTS: &[&str] = &[
    "mp3", "flac", "ogg", "oga", "opus", "m4a", "aac", "wav", "wma", "ape", "mpc", "aiff", "aif",
    "ac3", "dts", "alac", "mp4", "mka", "webm", "m4b", "wv", "tta", "dsf", "dff",
];

/// Factory for FFmpeg-based decoding sessions.
#[derive(Debug, Default, Clone)]
pub struct FfmpegFactory;

impl FfmpegFactory {
    /// Creates the factory.
    pub fn new() -> Self {
        Self
    }
}

impl SourceFactory for FfmpegFactory {
    fn id(&self) -> &'static str {
        "ffmpeg"
    }
    fn name(&self) -> &'static str {
        "FFmpeg (libavformat/libavcodec)"
    }
    fn can_open(&self, uri: &str) -> bool {
        let path = caly_core::transport::file_uri_to_path(uri);
        match path.extension().and_then(|e| e.to_str()) {
            Some(ext) => PREFERRED_EXTS.contains(&ext.to_ascii_lowercase().as_str()),
            None => true,
        }
    }
    fn probe(&self, uri: &str, transport: Box<dyn Transport>) -> Result<ProbeInfo, SourceError> {
        let reader = ffi::FfmpegReader::open(uri, transport)?;
        let (meta, info) = reader.probe_meta();
        Ok(ProbeInfo {
            meta,
            duration: reader.duration(),
            sample: info,
        })
    }
    fn open(
        &self,
        uri: &str,
        transport: Box<dyn Transport>,
    ) -> Result<Box<dyn SourceBackend>, SourceError> {
        let reader = ffi::FfmpegReader::open(uri, transport)?;
        Ok(Box::new(FfmpegSource { inner: reader }))
    }
}

/// A live FFmpeg decoding session.
pub struct FfmpegSource {
    inner: FfmpegReader,
}

impl SourceBackend for FfmpegSource {
    fn next_chunk(&mut self, max_frames: usize) -> Result<Option<AudioBuffer>, SourceError> {
        self.inner.next_chunk(max_frames)
    }
    fn seek(&mut self, pos: Duration) -> Result<(), SourceError> {
        self.inner.seek(pos)
    }
    fn reset(&mut self) -> Result<(), SourceError> {
        self.inner.reset()
    }
    fn track_meta(&self) -> &TrackMeta {
        self.inner.track_meta()
    }
    fn stream_info(&self) -> Option<&StreamInfo> {
        self.inner.stream_info()
    }
}

impl FfmpegSource {
    pub(crate) fn map_sample_format(v: i32) -> SampleFormat {
        match v & 7 {
            0 => SampleFormat::U8,
            1 => SampleFormat::S16,
            2 => SampleFormat::S32,
            3 => SampleFormat::F32,
            4 => SampleFormat::F64,
            _ => SampleFormat::F32,
        }
    }
}
