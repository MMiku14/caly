//! Decodes a file through the FFmpeg source until EOF.
use caly_core::source::{SourceBackend, SourceFactory};
use caly_core::transport::FileTransport;
use caly_source_ffmpeg::FfmpegFactory;

fn main() {
    let uri = std::env::args().nth(1).expect("usage: decode_all <file>");
    let f = FfmpegFactory::new();
    let t = FileTransport::open(uri.as_str()).unwrap();
    let mut src: Box<dyn SourceBackend> = f.open(uri.as_str(), Box::new(t)).unwrap();
    println!("info: {:?}", src.stream_info());
    let mut total: u64 = 0;
    let mut n = 0;
    loop {
        match src.next_chunk(4096) {
            Ok(Some(buf)) => {
                total += buf.frames() as u64;
                n += 1;
                if n % 20 == 0 {
                    println!("  chunk {n}: total {total}");
                }
            }
            Ok(None) => {
                println!("EOF at chunk {n}, total {total} frames");
                break;
            }
            Err(e) => {
                println!("ERR at chunk {n}: {e}");
                break;
            }
        }
    }
}
