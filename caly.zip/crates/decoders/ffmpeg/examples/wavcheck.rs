//! Diagnostic: check WAV decoding.
use caly_core::source::{SourceBackend, SourceFactory};
use caly_core::transport::FileTransport;
use caly_source_ffmpeg::FfmpegFactory;

fn main() {
    let dir = std::env::temp_dir().join("wavcheck");
    std::fs::create_dir_all(&dir).unwrap();
    let wav = dir.join("sine.wav");
    let status = std::process::Command::new("ffmpeg")
        .args(["-y", "-f", "lavfi", "-i"])
        .arg("sine=frequency=440:duration=2")
        .args(["-f", "lavfi", "-i"])
        .arg("sine=frequency=660:duration=2")
        .args([
            "-filter_complex",
            "[0:a][1:a]amerge=inputs=2[a]",
            "-map",
            "[a]",
        ])
        .args(["-ar", "44100", "-ac", "2", "-c:a", "pcm_s16le"])
        .arg(&wav)
        .output();
    println!("ffmpeg gen: {:?}", status.as_ref().map(|s| s.status));
    let f = FfmpegFactory::new();
    let t = FileTransport::open(wav.to_str().unwrap()).unwrap();
    let mut src: Box<dyn SourceBackend> = f.open(wav.to_str().unwrap(), Box::new(t)).unwrap();
    println!("opened; info={:?}", src.stream_info());
    let mut n = 0usize;
    let mut total = 0usize;
    while n < 10 {
        match src.next_chunk(4096) {
            Ok(Some(buf)) => {
                total += buf.frames();
                n += 1;
                println!("chunk {} frames={}", n, buf.frames());
            }
            Ok(None) => {
                println!("eos at total {total}");
                break;
            }
            Err(e) => {
                println!("err: {e}");
                break;
            }
        }
    }
    println!("done");
}
