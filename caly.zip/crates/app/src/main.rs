//! Caly - a modular TUI music player for Linux.
use std::path::{Path, PathBuf};
use std::time::Duration;
use std::time::Instant;
use clap::Parser;
use caly_core::backend::{OutputChannels, OutputConfig};
use caly_core::queue::{Track, TrackId};
use caly_engine::{Engine, EngineConfig, PlayState, Registry, RegistryBuilder};

/// CLI arguments of Caly.
#[derive(Parser, Debug)]
#[command(
    name = "caly",
    version,
    about = "A modular TUI music player (PipeWire + FFmpeg first)"
)]
struct Args {
    /// Files, directories or http(s) URLs to enqueue.
    #[arg(value_name = "PATH_OR_URL")]
    inputs: Vec<String>,
    /// Output backend: pipewire | pulse | alsa | null
    #[arg(long, default_value = "auto")]
    backend: String,
    /// Output device
    #[arg(long)]
    device: Option<String>,
    /// Output sample rate in Hz (default 48000)
    #[arg(long)]
    rate: Option<u32>,
    /// Output channels: mono | stereo
    #[arg(long, default_value = "stereo")]
    channels: String,
    /// Ring buffer size in milliseconds (16..=4000)
    #[arg(long, default_value_t = 500)]
    buffer_ms: u32,
    /// Decoder priority order: comma-separated ids, e.g. "ffmpeg,symphonia"
    #[arg(long, default_value = "ffmpeg,symphonia")]
    decoders: String,
    /// Run without the TUI (prints one status line per tick instead)
    #[arg(long)]
    headless: bool,
    /// List registered output backends and exit
    #[arg(long)]
    list_backends: bool,
    /// List registered decoders and transports and exit
    #[arg(long)]
    list_sources: bool,
    /// Filter directories to these extensions (comma separated)
    #[arg(
        long,
        default_value = "mp3,flac,ogg,oga,opus,m4a,aac,wav,wma,ape,mpc,aiff,alac"
    )]
    extensions: String,
    /// Path to the config file
    #[arg(long)]
    config: Option<std::path::PathBuf>,
    /// Fine-grained 1%-step volume (0-100)
    #[arg(long)]
    volume_percent: bool,
    /// Disable mouse/click interaction
    #[arg(long)]
    no_mouse: bool,
    /// Disable album artwork rendering
    #[arg(long)]
    no_artwork: bool,
    /// Start with shuffle enabled
    #[arg(long)]
    shuffle: bool,
    /// Initial repeat mode: off | all | one
    #[arg(long, default_value = "off")]
    repeat: String,
    /// Verbose logging (repeat for more)
    #[arg(short = 'v', long, action = clap::ArgAction::Count)]
    verbose: u8,
}

fn main() {
    let args = Args::parse();
    init_logging(args.verbose);
    let registry = build_registry();
    run_listing(&args, &registry);
    let order = parse_decoder_order(&args.decoders);
    let output = OutputConfig {
        backend: match args.backend.as_str() {
            "auto" => None,
            other => Some(other.to_string()),
        },
        device: args.device.clone(),
        sample_rate: args.rate.filter(|r| *r != 0),
        channels: match parse_channels(&args.channels) {
            Ok(c) => c,
            Err(e) => {
                eprintln!("caly: {e}");
                std::process::exit(2);
            }
        },
        buffer_ms: args.buffer_ms,
        period_frames: 0,
    };
    let engine_cfg = EngineConfig {
        output,
        source_order: order,
    };
    let engine = Engine::start(registry, engine_cfg);
    let tracks = collect_tracks(&args.inputs, &args.extensions);
    let queue_len = tracks.len();
    if !tracks.is_empty() {
        engine.enqueue(tracks, true);
        log::info!("enqueued {queue_len} item(s)");
    }
    if args.shuffle {
        engine.send(caly_engine::Control::ToggleShuffle);
    }
    match args.repeat.to_lowercase().as_str() {
        "all" => engine.send(caly_engine::Control::SetRepeat(caly_core::queue::RepeatMode::All)),
        "one" => engine.send(caly_engine::Control::SetRepeat(caly_core::queue::RepeatMode::One)),
        _ => {}
    }
    if args.headless || !is_terminal() {
        run_headless(engine);
    } else {
        let settings = caly_tui::settings::Settings::load(args.config.as_deref()).with_overrides(
            args.volume_percent.then_some(true),
            args.no_mouse.then_some(false),
            args.no_artwork.then_some(false),
        );
        let mut tui = caly_tui::Tui::new(engine.clone(), settings);
        tui.run();
        engine.shutdown();
    }
}

fn init_logging(verbose: u8) {
    let level = match verbose {
        0 => "warn",
        1 => "info",
        _ => "debug",
    };
    env_logger::Builder::from_env(env_logger::Env::default().default_filter_or(level))
        .format_timestamp(None)
        .init();
}

fn build_registry() -> Registry {
    let mut builder = RegistryBuilder::new();
    builder = builder.transport(Box::new(caly_transport_file::FileTransportFactory));
    builder = builder.transport(Box::new(caly_transport_http::HttpTransportFactory));
    builder = builder.source(Box::new(caly_source_ffmpeg::FfmpegFactory::new()));
    builder = builder.source(Box::new(caly_source_symphonia::SymphoniaFactory));
    builder = builder.backend(Box::new(caly_sink_pipewire::PipewireFactory));
    builder = builder.backend(Box::new(caly_sink_pulse::PulseFactory));
    builder = builder.backend(Box::new(caly_sink_alsa::AlsaFactory));
    builder = builder.backend(Box::new(caly_sink_null::NullFactory));
    builder.build()
}

fn run_listing(args: &Args, registry: &Registry) {
    if args.list_backends {
        println!("output backends:");
        for b in registry.backends() {
            println!(
                "  {:<10} {:<28} priority {:>4}  {}",
                b.info.id, b.info.name, b.info.priority, b.info.description
            );
        }
    }
    if args.list_sources {
        println!("decoders:");
        for s in registry.sources() {
            println!("  {:<10} {}", s.id(), s.name());
        }
        println!("transports:");
        for t in registry.transports() {
            println!("  {:<10}", t.kind());
        }
    }
    if args.list_backends || args.list_sources {
        std::process::exit(0);
    }
}

fn parse_decoder_order(s: &str) -> Vec<String> {
    s.split(',')
        .map(|x| x.trim().to_string())
        .filter(|x| !x.is_empty())
        .collect()
}

fn parse_channels(s: &str) -> Result<OutputChannels, String> {
    match s.to_lowercase().as_str() {
        "mono" => Ok(OutputChannels::Mono),
        "stereo" => Ok(OutputChannels::Stereo),
        other => Err(format!(
            "invalid --channels {other:?} (expected \"mono\" or \"stereo\")"
        )),
    }
}

fn is_terminal() -> bool {
    use std::io::IsTerminal;
    std::io::stdout().is_terminal() && std::io::stdin().is_terminal()
}

fn collect_tracks(inputs: &[String], extensions: &str) -> Vec<Track> {
    let exts: Vec<String> = extensions
        .split(',')
        .map(|e| e.trim().trim_start_matches('.').to_ascii_lowercase())
        .collect();
    let mut urls: Vec<Track> = Vec::new();
    let mut paths: Vec<PathBuf> = Vec::new();
    for input in inputs {
        if caly_core::transport::is_http_uri(input) {
            let mut t = Track::from_uri(TrackId(0), input.clone());
            if let Some(seg) = input.rsplit('/').find(|s| !s.is_empty()) {
                t.title = seg.to_string();
            }
            urls.push(t);
            continue;
        }
        let path = caly_core::transport::file_uri_to_path(input);
        if path.is_dir() {
            collect_dir(&path, &exts, &mut paths);
        } else if path.is_file() {
            paths.push(path);
        } else {
            eprintln!("caly: skipping (not found): {}", path.display());
        }
    }
    paths.sort();
    let files: Vec<Track> = paths
        .into_iter()
        .map(|p| Track::from_uri(TrackId(0), p.to_string_lossy().into_owned()))
        .collect();
    urls.extend(files);
    urls
}

fn collect_dir(dir: &Path, exts: &[String], out: &mut Vec<PathBuf>) {
    if std::fs::read_dir(dir).is_err() {
        eprintln!("caly: cannot read directory {}", dir.display());
        return;
    }
    caly_tui::browser::walk_audio_dir(dir, exts, out);
}

fn run_headless(engine: Engine) {
    use std::io::Write;
    let started = Instant::now();
    let mut last = Duration::from_millis(u64::MAX);
    let grace = Duration::from_millis(600);
    let mut saw_playback = false;
    loop {
        let snap = engine.snapshot();
        if matches!(snap.state, PlayState::Playing | PlayState::Paused) {
            saw_playback = true;
        }
        let now = snap.position.position;
        if now != last {
            last = now;
            let line = caly_tui::headless_status(&snap);
            let mut out = std::io::stdout().lock();
            let _ = writeln!(out, "{line}");
            let _ = out.flush();
        }
        if started.elapsed() > grace {
            let failed = snap.state == caly_engine::PlayState::Stopped && snap.last_error.is_some();
            let done = if saw_playback {
                snap.state == caly_engine::PlayState::Stopped
            } else {
                snap.queue_len == 0 || failed
            };
            if done {
                if failed {
                    eprintln!("caly: {}", snap.last_error.unwrap_or_default());
                }
                break;
            }
        }
        std::thread::sleep(Duration::from_millis(100));
    }
    engine.shutdown();
}
