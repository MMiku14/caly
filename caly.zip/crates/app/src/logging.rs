//! Application logging: redirects log output to `caly.log` in TUI mode to avoid corrupting the terminal display.

use std::fs::OpenOptions;
use std::path::PathBuf;

/// Resolves the default log file path (`~/.cache/caly/caly.log`).
pub fn default_log_path() -> PathBuf {
    if let Some(cache_dir) = std::env::var_os("XDG_CACHE_HOME").filter(|v| !v.is_empty()) {
        return PathBuf::from(cache_dir).join("caly").join("caly.log");
    }
    if let Some(home) = std::env::var_os("HOME").filter(|v| !v.is_empty()) {
        return PathBuf::from(home).join(".cache").join("caly").join("caly.log");
    }
    std::env::temp_dir().join("caly.log")
}

/// Initializes application logging.
/// When `to_file` is true (TUI mode), writes to `caly.log` so the Ratatui terminal screen is protected.
/// When false (headless / CLI mode), outputs directly to standard error.
pub fn init_logging(verbose: u8, to_file: bool) -> Option<PathBuf> {
    let level = match verbose {
        0 => log::LevelFilter::Warn,
        1 => log::LevelFilter::Info,
        _ => log::LevelFilter::Debug,
    };

    if to_file {
        let log_path = default_log_path();
        if let Some(parent) = log_path.parent() {
            let _ = std::fs::create_dir_all(parent);
        }
        if let Ok(file) = OpenOptions::new().create(true).append(true).open(&log_path) {
            let target = env_logger::Target::Pipe(Box::new(file));
            let _ = env_logger::Builder::from_env(env_logger::Env::default().default_filter_or(level.as_str()))
                .format_timestamp_secs()
                .target(target)
                .try_init();
            return Some(log_path);
        }
    }

    let _ = env_logger::Builder::from_env(env_logger::Env::default().default_filter_or(level.as_str()))
        .format_timestamp(None)
        .try_init();
    None
}
