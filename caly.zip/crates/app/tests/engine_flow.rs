//! Engine-level integration tests.
use std::time::{Duration, Instant};
use caly_core::backend::OutputConfig;
use caly_core::queue::{Track, TrackId};
use caly_engine::{Engine, EngineConfig, PlayState, Registry, RegistryBuilder};

fn registry() -> Registry {
    let mut b = RegistryBuilder::new();
    b = b.transport(Box::new(caly_transport_file::FileTransportFactory));
    b = b.source(Box::new(caly_source_ffmpeg::FfmpegFactory::new()));
    b = b.backend(Box::new(caly_sink_null::NullFactory));
    b.build()
}

fn wav_bytes(freq: f64, seconds: f64, rate: u32) -> Vec<u8> {
    let n = (rate as f64 * seconds) as usize;
    let data_len = n * 4;
    let mut w = Vec::with_capacity(44 + data_len);
    w.extend_from_slice(b"RIFF");
    w.extend_from_slice(&(36 + data_len as u32).to_le_bytes());
    w.extend_from_slice(b"WAVEfmt ");
    w.extend_from_slice(&16u32.to_le_bytes());
    w.extend_from_slice(&1u16.to_le_bytes());
    w.extend_from_slice(&2u16.to_le_bytes());
    w.extend_from_slice(&rate.to_le_bytes());
    w.extend_from_slice(&(rate * 4).to_le_bytes());
    w.extend_from_slice(&4u16.to_le_bytes());
    w.extend_from_slice(&16u16.to_le_bytes());
    w.extend_from_slice(b"data");
    w.extend_from_slice(&(data_len as u32).to_le_bytes());
    for i in 0..n {
        let t = i as f64 / rate as f64;
        let s = (0.3 * (2.0 * std::f64::consts::PI * freq * t).sin()) as f32;
        w.extend_from_slice(&s.to_le_bytes());
        w.extend_from_slice(&s.to_le_bytes());
    }
    w
}

fn make_track(dir: &std::path::Path, name: &str, freq: f64) -> Track {
    let path = dir.join(name);
    std::fs::write(&path, wav_bytes(freq, 0.8, 44100)).unwrap();
    Track::from_uri(TrackId(0), path.to_string_lossy().into_owned())
}

fn wait_for(
    engine: &Engine,
    pred: impl Fn(&caly_engine::Snapshot) -> bool,
    what: &str,
) -> caly_engine::Snapshot {
    let deadline = Instant::now() + Duration::from_secs(8);
    loop {
        let snap = engine.snapshot();
        if pred(&snap) {
            return snap;
        }
        if Instant::now() > deadline {
            panic!("timeout waiting for {what}; last snapshot: {snap:?}");
        }
        std::thread::sleep(Duration::from_millis(25));
    }
}

#[test]
fn play_index_switches_immediately() {
    let dir = std::env::temp_dir().join(format!("caly-it-playindex-{}", std::process::id()));
    std::fs::create_dir_all(&dir).unwrap();
    let cfg = EngineConfig {
        output: OutputConfig {
            backend: Some("null".into()),
            buffer_ms: 200,
            ..Default::default()
        },
        source_order: vec!["ffmpeg".into()],
    };
    let engine = Engine::start(registry(), cfg);
    engine.enqueue(
        vec![
            make_track(&dir, "a.wav", 440.0),
            make_track(&dir, "b.wav", 660.0),
            make_track(&dir, "c.wav", 880.0),
        ],
        true,
    );
    let s = wait_for(
        &engine,
        |s| s.state == PlayState::Playing && s.queue_cursor == Some(0),
        "first track playing",
    );
    assert_eq!(s.current.unwrap().title, "a");
    engine.send(caly_engine::Control::PlayIndex(2));
    let s = wait_for(
        &engine,
        |s| s.state == PlayState::Playing && s.queue_cursor == Some(2),
        "play index 2",
    );
    assert_eq!(s.current.unwrap().title, "c");
    assert_eq!(s.queue_len, 3);
    engine.send(caly_engine::Control::Stop);
    wait_for(&engine, |s| s.state == PlayState::Stopped, "stopped");
    engine.shutdown();
    let _ = std::fs::remove_dir_all(&dir);
}

#[test]
fn eos_advances_gap_free_via_prefetch() {
    let dir = std::env::temp_dir().join(format!("caly-it-eos-{}", std::process::id()));
    std::fs::create_dir_all(&dir).unwrap();
    let cfg = EngineConfig {
        output: OutputConfig {
            backend: Some("null".into()),
            buffer_ms: 200,
            ..Default::default()
        },
        source_order: vec!["ffmpeg".into()],
    };
    let engine = Engine::start(registry(), cfg);
    engine.enqueue(
        vec![
            make_track(&dir, "x.wav", 330.0),
            make_track(&dir, "y.wav", 550.0),
        ],
        true,
    );
    wait_for(
        &engine,
        |s| s.state == PlayState::Playing && s.queue_cursor == Some(0),
        "first track playing",
    );
    let s = wait_for(
        &engine,
        |s| s.state == PlayState::Playing && s.queue_cursor == Some(1),
        "auto-advance to second track",
    );
    assert_eq!(s.current.unwrap().title, "y");
    wait_for(
        &engine,
        |s| s.state == PlayState::Stopped,
        "idle after queue end",
    );
    engine.shutdown();
    let _ = std::fs::remove_dir_all(&dir);
}
