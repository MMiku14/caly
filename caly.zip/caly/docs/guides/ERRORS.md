# Caly Error Model and Public Error Codes

本文件定义 Caly 的**公共错误语义**，用于统一：

- CLI 输出
- TUI 错误展示
- `--json` 机器可读结果
- IPC / RemoteApi 响应
- support bundle / doctor 中的错误摘要

本文件是 RFC-0002、RFC-0006、RFC-0010 的工程执行补充，不替代这些 RFC。

---

## 1. 目标

Caly 的错误体系需要同时满足：

1. **对外稳定**：脚本、自动化、TUI、RemoteApi 可依赖稳定错误码。
2. **对内分层**：内部实现可以保留更细粒度错误类型。
3. **可脱敏**：错误对象跨门面时即完成 redaction。
4. **可恢复判断**：调用方可根据 `retryable` 和 `category` 做保守决策。
5. **可追踪**：所有公共错误都应关联 `trace_id`。

---

## 2. 公共错误对象

对外统一错误对象为 `ApiError`，其语义字段至少包括：

```text
code
category
retryable
summary
detail?
remediation?
diagnostics[]
trace_id
```

### 2.1 字段语义

| 字段 | 含义 |
|---|---|
| `code` | 稳定、机器可读的错误码 |
| `category` | 错误大类，用于聚合与 UI 呈现 |
| `retryable` | 是否可能通过稍后重试成功 |
| `summary` | 单行摘要，必须已脱敏 |
| `detail` | 可选多行详情，必须已脱敏 |
| `remediation` | 可执行建议，例如命令提示、权限提示、升级建议 |
| `diagnostics` | 结构化诊断项，适合 explain/doctor/JSON 输出 |
| `trace_id` | 端到端追踪 ID |

---

## 3. 错误分类（Category）

公共错误分类如下：

| Category | 含义 |
|---|---|
| `User` | 用户输入或调用方式错误 |
| `Config` | 配置解析、校验、冲突、引用或迁移错误 |
| `Capability` | 目标 Core/平台/版本能力不足或不确定 |
| `Core` | 目标 Core 原生校验、启动、运行、控制失败 |
| `Io` | 文件、网络、数据库、进程、下载等 IO 相关错误 |
| `Platform` | OS 网络、权限、TUN、DNS、系统代理等平台错误 |
| `Internal` | 实现错误、不可分类错误、应报告的异常状态 |

### 3.1 分类原则

- 分类用于**聚合与解释**，不是替代错误码。
- 外部自动化应优先基于 `code`，其次参考 `category` 和 `retryable`。
- `Internal` 类错误默认不暴露内部堆栈或敏感原文。

---

## 4. 稳定公共错误码

以下错误码应视为 v1 的公共稳定错误码最小集合。

| ErrorCode | Category | Retryable | 含义 |
|---|---|---:|---|
| `CONFIG_INVALID` | Config | 否 | 输入配置、patch、规则、引用或语义校验失败 |
| `CONFLICT` | Config | 否 | 合并冲突、端口冲突、资源冲突、命名冲突等 |
| `UNSUPPORTED_CAPABILITY` | Capability | 否 | 目标 Core/平台/版本不支持请求功能 |
| `CORE_NOT_RUNNING` | Core | 否 | 请求依赖运行中的 Core，但当前不存在可用实例 |
| `CORE_FAILED` | Core | 视场景 | Core 启动、重载、校验、控制或运行失败 |
| `PERMISSION` | Platform | 可能 | 权限不足、提权失败、访问受限 |
| `NET_OS` | Platform | 可能 | TUN、系统代理、系统 DNS、路由等 OS 网络层失败 |
| `STORAGE` | Io | 可能 | DB、对象存储、文件、磁盘空间、完整性等失败 |
| `TIMEOUT` | Io | 是 | 操作超时，可能来自下载、校验、部署、IPC 或等待 |
| `UNAVAILABLE` | Io | 是 | 服务暂时不可用、远端无响应、daemon/core/helper 不可达 |
| `PROTO_MISMATCH` | User | 否 | 客户端与 daemon 协议不兼容 |
| `CURSOR_STALE` | User | 否 | 分页 cursor 对应的 revision 已过期，需重新查询 |

### 4.1 保留码位

以下语义可以在需要时以新 RFC 或 RFC-0002 修订方式正式引入：

- `CANCELLED`
- `INTERRUPTED`
- `RATE_LIMITED`
- `NOT_FOUND`
- `ALREADY_EXISTS`
- `INTERNAL`

在它们正式冻结之前，建议通过现有分类与 `summary/detail/remediation` 表达，而不要随意公开新错误码。

---

## 5. 错误码使用规则

### 5.1 `CONFIG_INVALID`

适用于：

- source / profile / override 解析失败
- patch 目标不存在或非法
- 引用不完整
- 规则、DNS、inbound/outbound 语义校验失败
- schema 迁移后的对象不合法
- 查询自己划的界限被写成非法值（如 `DiagnosticsOp::ReadJobEvents` 的 `max_lines` / `max_bytes` 为 0）。
  超出上限但非零的值**不是**错误：服务端收窄到上限，并在响应里报告"还有更多"，因为客户端能自己接着走
- 命令的 `Ctx::io_budget` 花光：次数（`max_requests`，由引擎在计费处拒）与单次载荷的字节数（`max_bytes`，
  由**端口**按 `RFC-0006 §5.3` 拒，第二十九轮起），两者都是 `CONFIG_INVALID` + `User` + `retryable=false`，
  remediation 指向那个字段本身。端口层的 `CapacityExceeded` 到这里不换成"容量"码，因为 `RFC-0002 §14.4`
  没有那个码；这一处**有意的落差**与被拒方能看到什么，见 `docs/engineering/OVERLOAD_AND_RETRY_MODEL.md §3.7` 与
  `ADR-036 §6bis-decies`

不适用于：

- 明确的多方冲突，应优先用 `CONFLICT`
- 目标能力不支持，应优先用 `UNSUPPORTED_CAPABILITY`

### 5.2 `CONFLICT`

适用于：

- 同端口监听冲突
- 同名资源冲突且无法自动 rename
- RuleSet URL/hash 不一致
- TUN/DNS/system resource 排他冲突

### 5.3 `UNSUPPORTED_CAPABILITY`

适用于：

- Core 不支持某协议特性
- 平台不支持某 TUN / DNS / process info 能力
- capability 为 `Unsupported`
- strict 模式下 capability 为 `Unknown` 或不可接受状态

### 5.4 `CORE_NOT_RUNNING` 与 `CORE_FAILED`

区分原则：

- **未运行**：请求依赖 Core，但当前无活动实例 -> `CORE_NOT_RUNNING`
- **运行失败/控制失败**：核心应当工作但未成功，或正在失败中 -> `CORE_FAILED`

### 5.5 `PERMISSION` 与 `NET_OS`

区分原则：

- **权限问题主导** -> `PERMISSION`
- **平台网络能力执行失败主导** -> `NET_OS`

例如：

- 无管理员权限导致 TUN 无法拉起：可优先 `PERMISSION`
- 已有权限但路由应用失败：可优先 `NET_OS`

### 5.6 `STORAGE`

适用于：

- 数据库打不开或提交失败
- 对象存储写入失败
- 磁盘满
- 文件损坏或摘要不匹配
- Snapshot / Journal 持久化失败

### 5.7 `TIMEOUT`

适用于：

- 下载超时
- VerifyGate 超时
- apply health probe 超时
- IPC / job follow 等待超时

`TIMEOUT` 不表示操作一定已回滚成功；应结合命令语义和后续状态查询确认最终状态。

### 5.8 `UNAVAILABLE`

适用于：

- daemon 不可达
- helper 暂时不可达
- 外部服务暂时不可访问
- Core API 暂时无响应，但尚不足以归类为 `CORE_FAILED`
- 引擎主动拒绝（过载）：队列满、事件积压、流侧背压、存储繁忙

  这一类**必须**在 `detail` 里带出可分类的信息，形状是
  `error=<class> retry_hint=<Hint> [queue_len=… queue_cap=…] at_generation=…`，
  并在 `diagnostics[]` 里放一条 `code=<class>`；`category` 按类别取
  （`storage_busy` → `Io`，其余 → `Internal`）；`storage_busy` 的第一个生产者是回收周期在引擎忙时的
  入队前拒绝（`ADR-038 §8`），它同时是「拒绝必须可重试」的样板：`retryable=true` +
  `retry_hint=RetryLater`，且拒绝不推进任何 revision。只回一句 `UNAVAILABLE` 是
  `docs/engineering/OVERLOAD_AND_RETRY_MODEL.md §8` 的禁止项。出处：`caly_engine::OverloadReport::to_api_error`
  （daemon 的 `map_overload_report` 只转发，不再自己建一份）

### 5.9 `PROTO_MISMATCH`

适用于：

- 客户端版本过旧或过新
- method / operation 不存在或协议能力不兼容
- wire schema 或 handshake 协商失败

### 5.10 `CURSOR_STALE`

适用于：

- 分页查询的 cursor 与当前 revision 不再一致
- 需要客户端重新获取第一页或新快照

不适用于作业事件窗口：那里走视图字段 `JobFollowView::reset_required` / `JobEventsView::reset_required`
（配对 `retained_from_event_index`，并区分"到末尾"与"太旧"——到末尾是空窗口且 `reset_required = false`）。
这是 `RFC-0002 §9.3` 允许的「`CURSOR_STALE` 或等价错误」，与 `§10.2` 把 `Reset` 定为一等协议消息一致；
`docs/engineering/OVERLOAD_AND_RETRY_MODEL.md §5.1` 也点名要 "reset-required view field"。

---

## 6. Redaction 规则

所有公共错误必须在构造 `ApiError` 时完成脱敏，而不是在显示阶段临时处理。

### 6.1 默认必须脱敏的内容

- 订阅 URL query token
- Authorization 头值
- 节点密码
- UUID / 密钥材料
- Core API token
- secrets store 明文内容

### 6.2 `summary` 与 `detail`

- `summary` 必须始终可安全输出到 CLI/TUI/JSON/log
- `detail` 也必须已脱敏；它可以更长，但不应包含原始 secret

### 6.3 `Internal` 类错误

对 `Internal` 类错误，建议：

- `summary` 给出简短受控提示
- `detail` 省略或给出受控上下文
- 强调 `trace_id`
- 详细内部错误进入本地受控日志而非公共响应

---

## 7. Retryable 语义

`retryable=true` 表示：

- 该错误有可能通过稍后重试成功
- 但调用方不应默认盲目重试

### 7.1 典型可重试

- `TIMEOUT`
- `UNAVAILABLE`
- 某些 `STORAGE` 暂时性错误
- 某些 `PERMISSION`（如 helper 未启动但可补救）

### 7.2 典型不可重试

- `CONFIG_INVALID`
- `CONFLICT`
- `UNSUPPORTED_CAPABILITY`
- `PROTO_MISMATCH`
- `CURSOR_STALE`（应改为重新查询，而不是重放同请求）

---

## 8. 向用户展示的推荐策略

### CLI

CLI 建议默认展示：

- `summary`
- `code`
- 必要时 `remediation`
- `trace_id`（对 Internal 或复杂失败尤其重要）

### TUI

TUI 建议展示：

- 用户可读摘要
- 结构化诊断摘要
- 可折叠详细信息
- 若可用，给出 remediation

### JSON

`--json` 输出应保留完整公共错误对象字段，便于脚本和上层工具消费。

---

## 9. 变更规则

下列变更视为外部兼容性事件，需要同步更新 RFC/文档/测试：

- 删除已有公共错误码
- 更改已有错误码语义
- 更改错误码到退出码映射
- 把原本稳定错误改成不稳定文字提示

下列变更通常是兼容的：

- 新增可选 `detail`
- 改进 `remediation` 文案
- 增加诊断细节但不改变 `code`

---

## 10. 推荐测试

1. LocalApi / RemoteApi 对同一失败返回相同 `code`
2. `summary/detail` 默认脱敏
3. `trace_id` 在错误路径可追踪
4. `retryable` 标注符合预期
5. CLI `--json` 输出包含公共错误对象必需字段
6. `PROTO_MISMATCH` 与 `CURSOR_STALE` 等协议级错误可稳定复现

---

## 11. 一句话原则

> 内部错误可以复杂，但对外错误必须稳定、可脱敏、可脚本化、可追踪。