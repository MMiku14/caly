# Caly 脚本化运维合同（Scripting Contract）

本文件定义**脚本/CI 可以依赖什么、不可以假设什么**。凡本文件未列出的输出细节，一律视为
随实现演进的展示层，脚本不得解析。

配套文件：`docs/guides/EXIT_CODES.md`（退出码策略）、`docs/guides/ERRORS.md`（公共错误码）、
`docs/engineering/OPERATOR_SCENARIO_REPORT.md`（实测体验与发现清单）。

---

## 1. 退出码是合同

脚本判断成败只信**进程退出码**（`EXIT_CODES.md`）：

- `caly job <id>`（一次性查询）、`caly follow <id>`、`caly apply --wait` 对**同一失败作业
  给出同一退出码**（ADR-058，R116 起）：已识别公共码落该码号（如 `CONFLICT`→4、`PERMISSION`→8），
  缺失→1（旧 daemon 的诚实降级）、未识别→13。
- `--json` 不改变退出码语义。

## 2. 稳定的事实字段

以下字段是稳定合同（键名即 wire 拼写；`--json` 下值全为字符串）：

- **acceptance**（`caly apply` / `gc` / `rollback` 等的接受帧）：`job_id`、`state_revision`、
  `estimated_impact`。
- **jobs.follow 摘要**：`job_id`、`state`、`lifecycle`、`next_event_index`、
  `retained_from_event_index`、`reset_required`、`event_count`、`last_stage`、
  `last_stage_pct`、`warning_count`、`log_count`、`failure_code`、`failure_summary`。
- **流 END 帧**：`stream_id`、`seq`、`state`、`outcome`，以及 failed 终局才出现的
  `failure_code`。

## 3. 事件行是工作量的投影，不是常量

实测（`OPERATOR_SCENARIO_REPORT` 发现 #7）：同一 profile 二次 apply 的事件数是 **25**，
首版是 **44**——第二次没有配置变更，工作更少，事件就更少。这不是缺陷，是正确行为。

因此脚本**不得**假设：

- 事件数恒定（不许 `grep -c` 事件行做判断）；
- stage 序列固定、某个百分比必然出现（`[stage 50%]` 只是进度投影）；
- `event_count` 与上次相等。

脚本**可以**依赖：

- 终局事件行 `[done] Succeeded/Failed/Cancelled/TimedOut`（终局判决的渲染）；
- 进程退出码（§1）与 `--json` 的 END 帧字段（§2）；
- `job_id` / `state_revision` / 幂等键（§4）。

## 4. 幂等键是脚本自己的重试保险

写命令的 `--idempotency-key` 是**脚本生成并持有**的：同一键重放同一 job（不产生第二次部署），
新键是新 job。网络超时后的重试请复用同一键，而不是换键再打。

## 5. 组合姿势

- 同步等待：`caly apply <id> --idempotency-key <k> --wait`（acceptance 照打，随后同会话跟流到
  终态，退出码=流判决）。
- 异步 + 回看：`apply` 拿 `job_id` → 稍后 `caly job <id>` 或 `caly follow <id> [--from N]`。
- 断线续传：`caly follow --resume <stream-id>`（流 id 在 stderr 的
  `caly: stream <id> (resumed=...)` 行）；`--from` 游标是 exclusive 的。
- 逐帧程序消费：`--json`——daemon 帧原文一行一个（acceptance JSON 行在前，流帧在后）。

## 6. 反模式清单

- ❌ 用事件数/事件行内容判断成败 —— 用退出码与 END 帧。
- ❌ 假设第二次 apply 与第一次一样多的事件 —— 见 §3。
- ❌ 解析人类渲染的对齐/缩进（如 `  - ` 前缀、列宽）—— 那些是展示层。
- ❌ 把 `[stage N%]` 当进度条读 —— 它是离散 stage 的标记，不是 0–100 的连续刻度。
- ❌ 用 `job_id` 猜测顺序/复用 —— id 是单调铸号，但脚本只该把它当不透明句柄。
