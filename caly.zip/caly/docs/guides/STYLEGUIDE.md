# Caly Documentation and Naming Style Guide

本指南用于统一 Caly 的文档风格、命名风格、Schema 表达方式与 RFC/ADR 写作规范。

它不是对架构语义的替代；语义以 RFC 为准，本指南负责“如何写得一致、可维护、可搜索”。

---

## 1. 总原则

1. **中文叙述，英文标识**：正文以中文为主，类型名、枚举名、错误码、协议字段名保留英文原文。
2. **先定义再使用**：首次出现的重要术语应链接或引用 `docs/guides/GLOSSARY.md`。
3. **一文一职责**：每份 RFC 只冻结一类边界，不把多个主题混成一篇巨文。
4. **规范与解释分离**：RFC 写“必须是什么”，ADR 写“为什么这样定”。
5. **命名先稳定，再优化实现**：一旦进入公开 DTO / CapabilityKey / ErrorCode，应优先保持稳定。

---

## 2. 文档分类

### 2.1 RFC

RFC 用于冻结：

- 架构边界
- 协议
- 状态机
- 对外 DTO
- 编译语义
- 部署/恢复语义
- 能力与支持承诺

### 2.2 ADR

ADR 用于记录：

- 某个设计决策为什么成立
- 备选方案与被拒绝原因
- 当时的权衡背景

ADR 不应承载完整规范正文。

### 2.3 Guide / Glossary / Template

此类文档用于：

- 降低阅读门槛
- 统一命名和书写方式
- 支持新贡献者快速上手

---

## 3. RFC 文件规范

### 3.1 文件命名

RFC 文件名格式：

```text
RFC-<4 digits>-<short-kebab-name>.md
```

示例：

- `RFC-0001-core-architecture.md`
- `RFC-0002-api-facade-ipc.md`
- `RFC-0005-deployment-recovery.md`

### 3.2 标题头

每份 RFC 顶部应包含：

- RFC 编号与标题
- Status
- Version
- Depends-On（如有）
- Supersedes（如有）
- Last-Updated

### 3.3 推荐章节顺序

1. 摘要
2. 背景/目标
3. 设计原则
4. 规范正文
5. 兼容性/迁移/测试门禁
6. 冻结范围
7. 一句话结论

### 3.4 约束词

RFC 中的约束词统一使用：

- MUST
- MUST NOT
- SHOULD
- SHOULD NOT
- MAY

不要混用：

- “应该必须”
- “尽量一定”
- “原则上必须尽量”

一句要求最好只使用一组明确的强度。

---

## 4. ADR 文件规范

### 4.1 文件命名

ADR 文件名格式：

```text
ADR-<4 digits>-<short-kebab-name>.md
```

### 4.2 状态

ADR 推荐状态：

- Proposed
- Accepted
- Superseded
- Deprecated

### 4.3 写法建议

ADR 应回答：

1. 背景是什么？
2. 决策是什么？
3. 为什么不是别的方案？
4. 代价和后果是什么？

---

## 5. 命名约定

### 5.1 Rust 类型

- 类型、trait、enum、struct：`PascalCase`
- 模块、文件、函数：`snake_case`
- 常量：`SCREAMING_SNAKE_CASE`
- Cargo crate：`kebab-case` 或工作区约定下的 `caly-foo`

### 5.2 DTO / JSON 字段

推荐统一使用：

- JSON 字段：`snake_case`
- Rust DTO 字段：`snake_case`

理由：

- 与 Rust/serde 自然对齐
- CLI `--json` 输出可保持稳定
- 避免部分字段 camelCase、部分 snake_case 的长期混乱

若未来必须对接外部生态采用其他风格，必须在单独 RFC 中明确。

### 5.3 ID 类型

ID 类型应使用强类型名称：

- `ProfileId`
- `NodeId`
- `RuleSetId`
- `JobId`

禁止在规范正文中长期使用模糊写法如 `String id` 代替强类型概念。

### 5.4 错误码

稳定错误码使用：

```text
SCREAMING_SNAKE_CASE
```

示例：

- `CONFIG_INVALID`
- `PROTO_MISMATCH`
- `CURSOR_STALE`

错误码一旦公开，应视为兼容性接口。

### 5.5 CapabilityKey

CapabilityKey 统一使用：

```text
lowercase.dot.separated
```

示例：

- `dns.fake_ip`
- `routing.rule_set.remote`
- `runtime.connections.close`

### 5.6 StageId

StageId 使用：

```text
SCREAMING_SNAKE_CASE
```

示例：

- `MERGE`
- `LOWER`
- `VERIFY_NATIVE`

### 5.7 文件与目录名

一般规则：

- 文档文件：`kebab-case`
- Rust 源文件：`snake_case`
- 规范目录：`rfcs/`、`adrs/`

---

## 6. 表格与列表风格

### 6.1 表格

适合用于：

- 对比
- 状态枚举
- 权限矩阵
- 能力覆盖矩阵

避免用表格承载长段解释。长解释应放在表后补充。

### 6.2 列表

- 顺序步骤：使用编号列表
- 同级要点：使用无序列表
- 一项一义，不在单个 bullet 中混入过多并列结论

---

## 7. 术语与中英混排规则

### 7.1 保留英文原文的内容

以下内容通常不翻译：

- 类型名
- trait 名
- 枚举名
- crate 名
- RFC/ADR 编号
- CapabilityKey
- ErrorCode
- StageId

### 7.2 中文优先描述的内容

以下内容优先用中文说明：

- 设计目标
- 设计原则
- 行为约束
- 风险说明
- 实施建议

### 7.3 统一格式

推荐写法：

- `ApplyPlan`
- `ProfileFacet`
- `Strict Mode`
- `Last Known Good`

不要在同一文档中混写为：

- apply plan / Apply plan / APPLYPLAN

---

## 8. 图示风格

### 8.1 ASCII 图优先

在 RFC 中优先使用纯文本图，原因：

- diff 友好
- 审查友好
- 无渲染依赖

### 8.2 图示要求

图中的命名必须与正文一致，例如：

- 正文写 `RuntimeDriver`，图里就不要写 `Runtime Adapter` 除非已定义同义关系
- 正文写 `Privilege Helper`，图中不要改成 `root service` 造成语义漂移

---

## 9. Schema 与接口展示风格

### 9.1 伪结构体

当需要表达协议或数据结构，但又不想过早绑定具体语言实现时，优先使用：

```text
TypeName {
  field_a
  field_b?
  nested
}
```

### 9.2 代码块的用途

- `text`：协议、枚举、流程、伪结构
- `rust`：仅在需要说明 Rust 级接口形态时使用
- 不要在 RFC 中贴大量无关示例代码

### 9.3 字段可选性

可选字段在伪结构中可用 `?` 表示，例如：

```text
detail?
next?
```

---

## 10. 一致性检查清单

在提交 RFC/ADR 前，建议逐项检查：

1. 文件名是否符合编号规范？
2. 标题头是否包含状态与日期？
3. 是否明确了 MUST/SHOULD 级别？
4. 是否与术语表中的主称呼一致？
5. 是否引用了已有 RFC，而不是重复定义？
6. 是否明确说明了冻结范围？
7. 是否指出了兼容性或迁移影响？
8. 是否给出了最小测试门禁？

---

## 11. 推荐写作模式

建议使用下面的节奏：

```text
先定义目标
再定义不变量
再定义对象/接口
再定义行为约束
最后定义测试与冻结范围
```

这比“先铺背景故事、最后补约束”更适合长期维护。

---

## 12. 不推荐的写法

以下写法应避免：

1. 用自然语言描述协议，但没有字段级结构。
2. 用“以后补”代替关键失败语义。
3. 把 UI 行为和后端状态机混在同一段规范里。
4. 在不同文档里给同一概念不同名字。
5. 用“实现细节”掩盖尚未冻结的对外语义。

---

## 13. 一句话原则

> 命名一致性不是文风问题，而是架构稳定性问题。