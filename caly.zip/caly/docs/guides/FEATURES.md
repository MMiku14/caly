# Caly 功能说明书（Feature Reference）

> 这份文档回答三个问题：**这个功能为什么需要（解决什么问题）？面向什么使用需求？现在是什么状态？**
>
> 它是给「想知道 caly 现在能做什么、还差什么、去哪验证」的读者的入口——新人上手、运维评估、接续开发量选都从这里开始。权威顺序仍是 **RFC > ADR > 工程文档 > 代码注释**；本文件只**描述**状态，不**规定**边界（边界看 RFC/ADR）。
>
> 状态快照日期：**2026-09-01（文档重整后）**。量化基线：**890 个测试** / floor 890 / 20 个 crate / 10 份 RFC / 编号 ADR 到 ADR-057。
>
> 状态图例：
> - **可用（Done）**：生产路径已接、有真实裁判覆盖。
> - **部分（Partial）**：主链可跑，但完整面/硬场景缺（每行写明缺什么）。
> - **已规划未实现（Planned）**：有规划文档，代码不存在或未接生产。
> - **不做 / 显式推迟**：有 ADR/规则说明为什么不做。

---

## 0. 先读：caly 是什么、不是什么

**为什么需要 caly**：代理客户端（mihomo/clash、sing-box）的配置部署长期是「写配置文件 + 重启内核」，缺乏事务、回滚、崩溃恢复与多内核确定性。`RFC-0001 §4.2/§36` 把 caly 定位为一条**控制平面主链路**：

> 不可信输入（多源订阅/补丁）→ 统一语义 IR → 冲突与能力约束 → 确定性原生产物 → 最小代价部署计划 → 可补偿执行 → 可证明恢复。

**面向什么需求**：**网关/服务器/无头环境**下，把代理配置当「可审计、可回滚、可恢复的部署事务」来管理，支持 mihomo 与 sing-box 双内核、可脚本/CI/远程多客户端操作。它**不是**又一个桌面 GUI 客户端（对比 Clash Verge Rev：那是单用户桌面图形界面；caly 是 headless 守护进程 + 无状态客户端，详见 `docs/engineering/TUI_PLAN.md` 的定位与 ROADMAP Phase 9）。

**形态**：一个守护进程 `calyd`（唯一状态所有者）+ 一个 CLI `caly`（无状态 wire 客户端）+ 未来的 TUI。进程监督分两层（`ADR-055`）：**systemd 等 init 系统监督 calyd 进程**；**calyd 内部的 Core Supervisor 监督代理内核子进程**。

---

## 1. 守护进程与部署（Daemon / Deployment）

### 1.1 calyd 守护进程（前台、可被 init 托管）
| | |
|---|---|
| **为什么需要** | 代理控制面需要一个长期运行、唯一持有状态、可被监督重启的服务；CLI/TUI/脚本都是它的无状态客户端。 |
| **面向需求** | 网关/服务器上常驻运行；SSH/CI/多客户端远程操作；崩溃后自动恢复。 |
| **当前状态** | **可用**。`calyd` 是纯前台进程（不 fork/pidfile/自守护），`--bind` 支持 TCP 与 Unix 域套接字（`unix:/path`），`--port-file` 写监听点，`--data-dir` 状态目录。日志走 stdout/stderr（journald 友好）。 |
| **验证/位置** | `crates/caly-daemon/src/bin/calyd.rs`；`crates/caly-daemon/tests/calyd_wire.rs`（spawn 真二进制端到端）。 |

### 1.2 systemd 托管（外部 init 监督）
| | |
|---|---|
| **为什么需要** | 生产部署需要开机自启、崩溃重启、日志聚合；`RFC-0005 §12` 的崩溃恢复本就假定 daemon 会被外部重启。 |
| **面向需求** | Linux 服务器/网关用 `systemctl enable/restart` 运维。 |
| **当前状态** | **可用（Linux）**。交付 `packaging/systemd/calyd.service`（`Type=simple`、`Restart=on-failure`、UDS `/run/calyd/calyd.sock`、StateDirectory/RuntimeDirectory、real 运行时显式 opt-in）+ 部署 runbook `docs/guides/DEPLOYMENT_SYSTEMD.md`。unit 内容由结构门禁裁判（旗标白名单、real+双路径、不得直拉内核）。 |
| **验证/位置** | `packaging/systemd/calyd.service`、`docs/guides/DEPLOYMENT_SYSTEMD.md`、`ADR-055`；门禁 `the_systemd_unit_is_a_foreground_managed_calyd_supervising_the_core`。 |
| **非 Linux** | macOS launchd / Windows SCM / 容器镜像：**Planned**（同一分层原则，工件未做）。 |

### 1.3 SIGTERM 优雅关停
| | |
|---|---|
| **为什么需要** | `systemctl stop/restart` 发 SIGTERM；不捕获就硬杀 daemon、活内核留给下次崩溃恢复。 |
| **面向需求** | 干净运维停机、重启时优雅停内核而非制造孤儿。 |
| **当前状态** | **可用（Unix）**。主线程 `pthread_sigmask` 阻塞 TERM/INT，waiter 线程 `sigwait` 收信号 → `StdEffectRuntime::shutdown(10s)` 优雅停内核撤路由 → exit 0。手写最小 FFI（不引信号 crate，unsafe 局部封装）。 |
| **验证/位置** | `crates/caly-daemon/src/bin/support/signal.rs`；集成裁判 `sigterm_shuts_calyd_down_gracefully_with_exit_zero`（发真 SIGTERM 断言 exit 0 非 signal 15）；`ADR-056`。 |
| **缺** | in-flight 请求/连接的优雅排空（stop accepting→服务完当前会话→退）；Windows SCM 关停。**Partial**。 |

### 1.4 双运行时：simulated（默认）/ real（显式）
| | |
|---|---|
| **为什么需要** | 开发/CI 不能在宿主机真起内核改代理；生产又必须真管 mihomo/sing-box。 |
| **面向需求** | 测试与演练零副作用；生产显式开真实副作用。 |
| **当前状态** | **可用**。默认 `--effect-runtime simulated`（绝不触碰宿主）；`--effect-runtime real` 必须同时给 `--runtime-root` 与 `--assets-dir`（缺失/多余都按名拒绝，防止「看起来只是启动 daemon 却改了系统」）。 |
| **验证/位置** | `ADR-050`；`calyd.rs` 的 `EffectRuntimeSelection`；单测 `simulated_is_the_only_default_and_rejects_hidden_real_settings`。 |

---

## 2. 配置主链路：订阅 → IR → 编译 → 部署

### 2.1 多源订阅接入与解析（Source）
| | |
|---|---|
| **为什么需要** | 订阅 URL 是**不可信输入**（`RFC-0001` 不变量 5）；需要拉取、解析、规范化并记录来源 provenance。 |
| **面向需求** | 从远程订阅/本地文件导入多内核配置，跨重启可复用。 |
| **当前状态** | **部分（Partial）**。真实 source parse/normalize、HTTP→parser→CAS 落盘、durable source index 跨重启恢复、source inspection projection 已接入；source worker 后台刷新。系统代理走 source Http 端口。**用户面（R114）**：`caly sources`/`caly source <id>`（wire `sources.list`/`sources.inspect`）——注册端点未拉取即列得出来、单源视图展示拉取/解析事实；注册表之外的 id 按名拒绝（`no such source`，CONFLICT/exit 4）。 |
| **验证/位置** | `caly-engine` source worker / `caly-io-std` StdHttp；相关 durable source 裁判；`ADR-053`（SSRF 网络访问边界）。 |

### 2.2 统一 IR 与确定性编译（Pipeline/Compiler）
| | |
|---|---|
| **为什么需要** | 不同内核配置方言不同；需要把不可信多源配置收敛为带能力约束的**确定性中间表示**，再编译成各内核原生配置（不变量 6/7：内核独占字段不静默丢失、相同输入稳定输出）。 |
| **面向需求** | 一份语义配置，可确定性地产出 mihomo 或 sing-box 原生配置。 |
| **当前状态** | **部分（Partial）**。Pipeline DAG、Stage 缓存（digest memoization）、ResolveProfile、Native 产物主链已接通并有 golden/parity 裁判；完整能力面覆盖仍在扩。 |
| **验证/位置** | `caly-ir`、`caly-pipeline`、`caly-plan`、`caly-domain`；`RFC-0003`（pipeline provenance）、`RFC-0009`（profile patch/override）。 |

### 2.3 能力注册表（Capability Registry）
| | |
|---|---|
| **为什么需要** | 不是每个内核都支持每种配置能力；需要显式声明「谁支持什么、支持到什么程度」，编译期约束而非运行时踩坑。 |
| **面向需求** | 跨内核迁移时知道哪些能力可用/会被保真/需拒绝。 |
| **当前状态** | **可用（注册表本体）/ 部分（apply 升级 fallback）**。registry 是单一事实源、产物为导出物（`ADR-051`：不被运行时当输入读）；RequiredCapability 集与 doctor explain 出口可用；fallback 影响 apply 升级仍部分。 |
| **验证/位置** | `caly-cap`；`RFC-0004`；`registry_drift.rs`（registry JSON 与内建 default 双向一致）。 |

### 2.4 Profile 应用 / 回滚（apply / rollback，事务化）
| | |
|---|---|
| **为什么需要** | 配置变更必须是**事务**：失败的 apply 不得改变运行配置、不得留下坏的系统代理/DNS/TUN/路由（不变量 3/4）；要能回滚到上一个好快照。 |
| **面向需求** | 安全地切换配置；出错一键回滚；幂等重试不重复触发。 |
| **当前状态** | **部分（Partial）**。`profiles.apply` / `profiles.rollback` 命令、acceptance job、幂等键（同 key 重放同 job、新 key 新 job）、Snapshot、回滚复活目标部署（`ADR-045`）已在内存/落盘后端闭合；命令以 Job 异步执行、CLI 前端组合「同步体验」。 |
| **验证/位置** | `caly apply` / `caly rollback --snapshot`；`RFC-0005`、`RFC-0007`；`ADR-018`（写操作即 Job）。 |

### 2.5 内核适配器：mihomo + sing-box 双内核
| | |
|---|---|
| **为什么需要** | 控制面要能驱动两种主流内核，且新增内核不重写上层。 |
| **面向需求** | 同一控制面下按环境选择 mihomo 或 sing-box。 |
| **当前状态** | **部分（Partial，真实内核切片）**。内核资产 sha256 钉死、真实 spawn/控制器 probe/stop/rollback 真核裁判已存在（`real_core.rs`/`real_apply.rs`）；spawn 面（`ADR-046` sing-box、`ADR-042` 进程网关）、路由诚实（`ADR-047`）、系统代理/直连模式（`ADR-048`）。完整 runtime API 与 artifact golden 仍缺。 |
| **验证/位置** | `caly-mihomo`、`caly-singbox`、`caly-core`；`assets/`（内核与 geo 资产，digest 钉在裁判里）；`ADR-023`（support levels）。 |

---

## 3. 作业与事件（Jobs / Events / Follow）

> 成本收益评估（用户实测便利 vs 代码量/维护难度，含「是否必要」的判定与冻结/转向建议）见
> `docs/engineering/JOB_FLOW_COST_BENEFIT_REPORT.md`。

### 3.1 写操作即 Job + 同步前端组合
| | |
|---|---|
| **为什么需要** | apply/gc/rollback 等耗时写操作不能阻塞；协议层不提供「同步命令」特权通道（`RFC-0002 §8.4`：execute→follow→渲染→映射退出码）。 |
| **面向需求** | 命令行「看起来同步」地跑完一个部署并给出成败退出码。 |
| **当前状态** | **可用**。写命令返回 acceptance（job_id），worker 线程 drain 引擎，CLI `follow` 作业流到终态并按判决给退出码。 |
| **验证/位置** | `caly apply`/`gc`/`rollback` 的 acceptance 三字段；`ADR-018`；worker drain 见 `calyd.rs`。 |

### 3.2 事件分页查询（jobs / jobs --from/--max）
| | |
|---|---|
| **为什么需要** | 作业事件（Stage/Log/Warning/Done/Failed）是可分页的大集合（`RFC-0002 §9`）。 |
| **面向需求** | 脚本/UI 分页拉取事件、平铺拼接不丢不重。 |
| **当前状态** | **可用**。`jobs.events` 分页（游标 exclusive），两页拼接==整窗、截断页游标非空；`caly jobs <id>` 与 `caly follow` 行级 parity（两个动词一个投影）。**作业发现面（R106）**：`caly jobs`（无 id）走新 `jobs.list`，返回当前 daemon 持有作业的摘要（job_id/state/进度%/事件数/失败码），新→旧、daemon 端 cap 64——丢了 shell 历史也能先列出 id 再分页。 |
| **验证/位置** | `caly jobs`（列表，`jobs.list`）/ `caly jobs <id> [--from N] [--max N]`（事件分页）；发现面 e2e + 结构门禁 `the_jobs_discovery_verb_is_wired_end_to_end_under_a_daemon_cap`、分页平铺裁判、跨 op 一致性裁判。**注意**：终态作业跨重启持久化已落地（ADR-057 切片 1/2/4：`mark_finished` 写 D3 记录、`restore_job_logs` 启动载入、真二进制 kill-9 重启三查询面全命中裁判）——`jobs`/`jobs <id>` 覆盖的不只是本次 daemon 生命；进行中作业仍在恢复扫描中收敛为终态。 |

### 3.3 流式跟随（follow，可断点续传）
| | |
|---|---|
| **为什么需要** | 长部署要实时看进度；断线/慢客户端要能无损续传（`RFC-0002` stream delivery policy、Reset 一等公民）。 |
| **面向需求** | `caly follow <id>` 实时跟踪；网络抖动后 `--resume <stream-id>` 零重印续传。 |
| **当前状态** | **可用**。follow 流 opened→DATA→END/ACK 帧；DATA/END 按 `stream_id` 关联、opened/refusal 按 `request_id` 关联、resume 核对流 id 与 resumed 标志、ack 确认帧核对流 id；游标 ack 后 resume 空 delta、未 ack 全量重放；state-gap 返回 CURSOR_STALE(14) + resume 提示；流表有界（超 cap 拒绝）。**R116（ADR-058）**：END 帧在 failed 终局携带 `failure_code`，流式失败按公共码落精确退出码（与 `caly job` 同一数字；缺失→1、未识别→13）。 |
| **验证/位置** | `caly follow <id> [--from N]`、`caly follow --resume <stream-id>`；`docs/engineering/IPC_STREAM_POLICY.md`；R94–R97 关联裁判族。 |

### 3.4 一次性作业摘要（job 查询）
| | |
|---|---|
| **为什么需要** | 不跟流也要能查一个作业的摘要（状态、进度、失败身份）。 |
| **面向需求** | `caly job <id>` 快速查作业成败与失败码。 |
| **当前状态** | **可用**。`jobs.follow` 摘要视图（state/lifecycle/事件计数/last_stage/failure_code/failure_summary 全字段），失败作业按 `failure_code` 映射退出码（records 与 `--json` 一致）。 |
| **验证/位置** | `caly job <id>`；R99（一次性查询 failure_code→退出码）。 |

### 3.5 退出码诚实性（CLI exit codes）
| | |
|---|---|
| **为什么需要** | shell/CI 靠退出码判断成败；必须区分「没权限」「配置错」「超时」「协议不符」「作业失败」，不能一律 0 或一律 1。 |
| **面向需求** | 脚本/CI/运维据此分流处理。 |
| **当前状态** | **可用**。17 个退出码（0 成功 / 1 一般失败 / 2 用法 / 3 配置无效 / 4 冲突 / 5 不支持能力 / 6 核心未运行 / 7 核心失败 / 8 权限 / 9 网络/OS / 10 存储 / 11 超时 / 12 不可用 / 13 协议不符 / 14 游标陈旧 / 15 取消 / 16 内部）。daemon REFUSAL 稳定公共码→退出号（R98）；一次性 job 失败码（R99）；流式 follow verdict（records 早已映射，`--json` R103 补齐）；流式 END `failure_code`（R116/ADR-058：failed 终局按公共码落号、三条路径同一数字）；`--json` 不改变退出码语义（`docs/guides/EXIT_CODES.md §1.4`）。 |
| **验证/位置** | `docs/guides/EXIT_CODES.md`、`crates/caly-cli/src/exit_code.rs`；`exit_code_table.rs`（文档表↔枚举双向裁判）。 |
| **已知缺** | （原「END 帧无 failure_code」缺口已由 R116/ADR-058 关闭。）兼容期行为：旧 daemon 不发该字段时流式失败仍落 exit 1（有意降级，非缺陷）；未识别码落 13。 |

---

## 4. IPC / Wire 协议

### 4.1 v0 wire：framed records + JSON 双编码
| | |
|---|---|
| **为什么需要** | 本地/远程客户端与 daemon 之间需要一个简单、可握手协商、人类可调试的帧协议。 |
| **面向需求** | CLI/TUI/脚本通过 TCP loopback 或 UDS 与 calyd 对话。 |
| **当前状态** | **可用（v0 slice）**。单字节帧 kind + 长度前缀 + records（`k=v` 行）或 JSON 负载；hello/hello_ack 握手协商编码/版本/压缩（records 元语言，JSON 仅答案体）；v0 JSON 值全为字符串。帧类型：HELLO(1)/HELLO_ACK(2)/REQUEST(3)/RESPONSE(4)/REFUSAL(5)/STREAM_DATA(6)/STREAM_END(7)/STREAM_ACK(8)。 |
| **验证/位置** | `caly-ipc`（`dialect.rs`、`endpoint.rs` BindSpec TCP+UDS、FramePump）；`docs/engineering/IPC_TRANSPORT_DECISION.md`；握手内容校验裁判。 |

### 4.2 帧关联与「信内容不信 kind」
| | |
|---|---|
| **为什么需要** | wire 单会话多路复用；错帧/串帧/外国外 id 的帧不能被当成本次答案（R71 握手洞在请求/流路径的同族残留）。 |
| **面向需求** | 防止混乱/恶意/有 bug 的对端把别的流/请求的数据当成本次结果打印或定退出码。 |
| **当前状态** | **可用**。请求-应答按 `request_id` 关联（一问一答）；流 DATA/END/ack 按 `stream_id` 关联；opened/refusal 补 request_id；resume/ack 确认逐帧核对；不符即 PROTO_MISMATCH(13)。daemon 帧分派 fail-closed（二次 HELLO/未握手请求/未知 kind 全拒）。 |
| **验证/位置** | R71、R94–R98 裁判族（假 daemon 外国外 id/缺 id 帧 e2e + 结构门禁）。 |

### 4.3 传输健壮性：有界期限、防挂死
| | |
|---|---|
| **为什么需要** | 不回答/不读取的对端不能让客户端或服务端线程无限挂起（R44「不会回答的 daemon 不许挂死客户端」）。 |
| **面向需求** | 慢/死对端、静默长作业下都能 bounded 返回。 |
| **当前状态** | **可用**。客户端全会话走共享 `FramePump`（read+write 双向有界、读前探活）；daemon 服务端 `set_transport_deadlines` 对称界 read+write；握手 5s、请求 3s、follow 流 opened 后加宽到 30s 空闲（静默内核 spawn/probe 不误判超时）；入站帧超 cap 即拒。 |
| **验证/位置** | R89–R91；`FramePump`/`set_transport_deadlines`；静默间隙 e2e、写半挂死裁判。 |
| **缺（§13#3 大活）** | 共享 timeout scheduler 统一生产化、typed `send_request_frame` 生产化（现硬编码 30s）、多请求复用/递增 request_id、多流并发关联、UDS peek。**Partial/Planned**。 |

### 4.4 角色授权（Admin / Operator / Viewer）
| | |
|---|---|
| **为什么需要** | 远程多客户端下，不是每个对等端都能执行高危写操作（`ADR-037`、`RFC-0002 §7.2`）。 |
| **面向需求** | 只读监控客户端（Viewer）、运维客户端（Operator）、管理端（Admin）分权。 |
| **当前状态** | **可用**。hello 协商角色，daemon 信任边界 **fail-closed**：未知角色按名拒绝、缺失角色降为最小权限 Viewer（不是 lenient 默认 Admin）；请求信封角色取自 hello 协商（不硬编码 Admin）；Admin-only 命令对低权限回 PERMISSION。生产 CLI 默认以 Admin 握手、可用 `--role viewer|operator|admin` 显式声明角色（R112：`caly --role viewer gc` → PERMISSION/exit 8、`--role viewer status` → 正常；坏角色值客户端 usage exit 2，不浪费往返）。 |
| **验证/位置** | R92/R93 正反双胎 wire e2e + 结构门禁；`caly-ipc` `server_hello_role`；R112 CLI 可达性 e2e 四胎（viewer 读+拒写、operator 拒写、坏角色 usage、admin 默认反空转，`caly_cli_e2e`）。principal/凭据认证（v1「谁在调用=一个角色」）**不做**（ADR-037）。 |

---

## 5. 存储、恢复与运维

### 5.1 落盘存储 / CAS / Snapshot / Journal
| | |
|---|---|
| **为什么需要** | 部署要可审计、可回滚、崩溃后知道做到哪一步（`RFC-0007`）。 |
| **面向需求** | 配置/快照/作业历史持久化；崩溃恢复有据可依。 |
| **当前状态** | **部分（Partial）**。`FsStore` 落盘后端、CAS 内容寻址、Revision、Snapshot、ApplyJournal，D0–D3 持久化分级（`ADR-014`）；存储钟由 calyd 注入（只有 caly-io-std 读宿主时钟）。schema migration 与性能面仍缺。 |
| **验证/位置** | `caly-storage`；`docs/engineering/STORAGE_RECOVERY_EXECUTION_PLAN.md`；存储契约/恢复裁判。 |

### 5.2 崩溃恢复（启动恢复扫描）
| | |
|---|---|
| **为什么需要** | daemon/内核可能在部署中途崩溃；重启必须收敛到 Last-Known-Good 或干净 Failed，不能停在「未知但看起来能用」（不变量 10、`RFC-0005 §12`）。 |
| **面向需求** | 异常断电/被 kill/升级重启后自动修复系统代理/DNS、接管或清理孤儿内核。 |
| **当前状态** | **部分（Partial）**。calyd 启动先进恢复检查（`recover_on_start`）：未完成 journal/deployment 标记、孤儿 runtime 清理、旧内核身份校验（pid+start_time+instance_nonce）后决定接管/回滚/冷启动。内存/落盘后端闭合；**跨进程 adoption 未完成**。 |
| **验证/位置** | `DaemonBootstrapConfig.recover_on_start`；`RFC-0005 §12`；recovery 裁判。 |

### 5.3 垃圾回收（gc-plan / gc，先规划后执行）
| | |
|---|---|
| **为什么需要** | CAS/快照/日志会累积；删除是破坏性操作，必须先出计划、可审计、有权限门。 |
| **面向需求** | 运维安全地回收空间，先看会删什么再执行。 |
| **当前状态** | **可用**。`system.gc-plan` 只读出计划（标量 + 删除清单 + gap，查询两遍除活钟外全同）；`system.gc` 执行（`max_deletions=0` 是 CONFIG_INVALID 点名且不产 job、缺幂等键拒绝、同键重放、跑过 plan 的 last_run 变 Some）。读侧有角色门（`ADR-038`）。 |
| **验证/位置** | `caly gc-plan` / `caly gc --idempotency-key ... [--max-deletions N] [--grace-ms ...]`；gc 计划/执行裁判。 |

### 5.4 诊断 doctor 与支持包 support-bundle
| | |
|---|---|
| **为什么需要** | 出问题时要能自诊断、打包脱敏后的现场给维护者（`RFC-0010`）。 |
| **面向需求** | `caly doctor` 一键体检；`caly support-bundle` 导出脱敏诊断包。 |
| **当前状态** | **可用**。doctor 三层行与计数、gc 行活时钟段；support-bundle 是命令（接受 job、产物进 CAS）、support-bundle-read 读回（digest 回显、content sha256 校验、`--max-bytes` 截断如实报）；密钥/Token/UUID/订阅 URL 不进日志/IPC/包（redaction 门禁）。 |
| **验证/位置** | `caly doctor`、`caly support-bundle`、`caly bundle [<digest>] [--max-bytes N]`；`docs/engineering/REDACTION_AND_SUPPORT_BUNDLE.md`；RFC-0010 §12.3/§14。 |

### 5.5 系统代理 / DNS / TUN（Platform 面）
| | |
|---|---|
| **为什么需要** | 代理真正生效要改系统代理/DNS/路由/TUN。 |
| **面向需求** | 网关/桌面透明代理、系统代理切换。 |
| **当前状态** | **部分（Partial）**。recovery、Direct/ActiveCore/SystemProxy 已有 slice（`ADR-048` 系统代理与直连模式）；**Platform/TUN/Privilege Helper 未完成**。长期降权路径是 Privilege Helper（`RFC-0005 §13`：最小化长期高权限进程），当前 real 模式需 root。 |
| **验证/位置** | `caly-engine` Platform/effect；`RFC-0005 §13`；TUN/helper 为 Planned。 |

---

## 6. 安全

| 功能 | 为什么需要 | 当前状态 |
|---|---|---|
| **密钥脱敏**（RFC-0010） | 密钥/Token/密码/UUID/订阅 URL 不得泄漏到日志、默认 IPC、TUI 历史（不变量 8）。 | **可用**。redaction 在门面边界（`ADR-020` 错误规范化+脱敏）；support bundle 脱敏；门禁钉脱敏边界。 |
| **角色授权**（ADR-037） | 远程分权，低权限不能执行高危写。 | **可用**（见 §4.4）；principal/凭据认证显式**不做**（v1 一个角色）。 |
| **SSRF 网络边界**（ADR-053） | source 拉取/内核控制器 HTTP 访问不能被诱导打内网。 | **可用**。连接后 peer 校验、默认保守拒绝、显式放行裁判。 |
| **不可信输入**（不变量 5） | 订阅/补丁一律视为不可信，未知字段不静默丢失。 | **可用**（编译链 + 能力注册表 + OpaquePreserved 保真，RFC-0004）。 |
| **最小特权**（RFC-0005 §13） | 不让整个 daemon 成为长期高权限进程。 | **Planned**。Privilege Helper 未实现；real 模式当前 root，systemd unit 带部分硬化（PrivateTmp/ProtectSystem/ProtectHome）。 |
| **下载校验**（RFC-0010 §14） | 内核/geo 资产下载必须校验 sha256。 | **可用**。资产 digest 钉在裁判里，spawn 时对完整 bytes 复核、错配按 binary-digest-mismatch 拒。 |

---

## 7. TUI / 交互 UX

| 功能 | 为什么需要 | 当前状态 |
|---|---|---|
| **CLI（caly）** | 非交互、脚本友好的控制面（`RFC-0001 §6.1`：CLI 不含领域状态机，只发 Command/Query/Watch）。 | **可用**。见 §8 命令清单；records 人类渲染 + `--json` 原文双形态。 |
| **TUI（caly-tui）** | 交互式 dashboard（connections/traffic/logs/select/probe）。 | **Planned（未实现）**。`caly-tui` crate 不存在；规划见 `docs/engineering/TUI_PLAN.md`，ROADMAP 排在 **Phase 9 / 里程碑 7（最后）**，硬约束「不让 TUI 反向驱动架构偏航」；实现前须先有渲染栈/数据通路 ADR。定位为 calyd 的又一个无状态 wire 客户端。 |

---

## 8. CLI 命令清单（用户面速查）

连接：所有命令带 `--addr <host:port>` 或 `--addr unix:<path>`；`--json` 切换 JSON 原文输出（不改退出码）；`--role viewer|operator|admin` 声明握手角色（默认 admin；低角色打 Admin-only 命令被 PERMISSION 拒、exit 8）。

| 命令 | 操作 | 作用 | 关键旗标 |
|---|---|---|---|
| `caly status` | `runtime.status` | 运行时状态九字段 | `--addr` |
| `caly doctor` | `diagnostics.doctor` | 三层体检 | |
| `caly profiles` | `profiles.list` | 配置清单 | |
| `caly profile <id>` | `profiles.get` | 单个配置视图 | |
| `caly sources` | `sources.list` | 订阅源注册表（已注册端点 ∪ 已索引 ∪ profile 引用；注册即可见，无需等拉取） | |
| `caly source <id>` | `sources.inspect` | 单源视图（locator/etag/节点数/诊断/来源；未拉取时 durable 事实显式为空） | |
| `caly apply` | `profiles.apply` | 应用配置（异步 job）；`--wait` 把「apply+follow」两行组合收成一条命令——acceptance 照打、同一会话跟流到终态、按流判决退出码 | `--idempotency-key`（必填）、`--dry-run`、`--strict`、`--runtime`、`--wait` |
| `caly rollback --snapshot <id>` | `profiles.rollback` | 回滚到快照 | `--idempotency-key`（必填） |
| `caly jobs` | `jobs.list` | 列出最近部署作业（新→旧，cap 64） | `--addr` |
| `caly jobs <id>` | `jobs.events` | 某作业事件分页 | `--from <idx>`、`--max <n>` |
| `caly job <id>` | `jobs.follow` | 作业摘要（含失败码） | |
| `caly follow <id>` | `jobs.follow-stream` | 实时跟随作业流 | `--from <idx>` |
| `caly follow --resume <stream-id>` | （resume） | 断点续传、零重印 | |
| `caly gc-plan` | `system.gc-plan` | 垃圾回收计划（只读） | `--grace-period-ms`、`--max-deletions` |
| `caly gc` | `system.gc` | 执行垃圾回收 | `--idempotency-key`（必填）、`--max-deletions` |
| `caly support-bundle` | `diagnostics.support-bundle` | 导出脱敏诊断包 | `--idempotency-key` |
| `caly bundle [<digest>]` | `diagnostics.support-bundle-read` | 读回诊断包 | `--max-bytes <n>` |

daemon 端旗标：`--bind`、`--data-dir`、`--port-file`、`--effect-runtime simulated|real`、`--runtime-root`、`--assets-dir`、`--source-endpoint`、`--session-idle-ms`、`--worker-tick-ms`。

---

## 9. 已知缺口与「显式不做」（量选/规划用）

**仍在推进（Partial 的缺角）**：
- 流式 END 帧携带稳定 failure_code（须 wire 形状 ADR；现状流式失败只 exit 1）。
- 共享 timeout scheduler、typed `send_request_frame` 生产化、多请求复用/递增 request_id、多流并发关联、UDS peek（ROADMAP §13#3）。
- 跨进程 adoption（崩溃恢复的跨进程接管）、Platform/TUN/Privilege Helper、schema migration、完整内核 runtime API/artifact golden。
- **作业事件持久化跨重启**（R105 实测 P0 主体）：部署状态（active profile/snapshot）持久，但 Job 事件流内存态——`kill -9` 后 `caly job <id>` 返回「no such job」，`caly jobs`/follow/resume 只覆盖本次 daemon 生命。**决策已立 `ADR-057`（Accepted），切片 1（存储 primitive，R108）与切片 2（引擎终态写入 + 启动恢复，R109）已落地**：`caly-storage` 有纯存储类型 `JobLogRecord/JobEventRecord` 与 `JobLogStore` trait（put/get/list，Fs 终态 D3 + InMemory 双实现同契约、坏记录重启扫描点名拒绝、list newest-first）；引擎在 `mark_finished` 终态提交点写 D3 记录（`job_persistence.rs` 做 typed 映射、只持久化终态、failed 落稳定公共码+脱敏 summary），daemon `startup_recovery` 在对外服务前 `restore_job_logs()` 把终态记录读回 `state.jobs`（最旧先插入、next_job_id 推过最高恢复 id、坏记录=启动错误）。真引擎+仿真盘 e2e 已钉「写终态→新开 EngineHandle 同 backend→jobs.list/follow 命中、恢复作业保终态不重放、failure_code 跨重启在」。**切片 4 裁判已落地（2026-09-01）**：真二进制 e2e「apply→SIGKILL→同 data-dir 重启→`jobs.list`/`jobs.events`/`jobs.follow` 三面全命中」（`calyd_wire::a_terminal_job_survives_a_kill_9_restart_and_answers_every_query_surface`）与「真实 collect 后历史仍可答」（`calyd_wire::a_gc_collect_cycle_never_reclaims_the_durable_job_history`），falsify 三变异全 BIT。**仍未做**：切片 3 剩 support bundle 收录作业轨迹——见 ADR-057 §5。终态事件 D3 落盘（有界、随 GC 回收、与 snapshot 同档）；进行中增量 D1 best-effort（可选增量面，未开工），进行中作业仍由恢复扫描收敛。发现面 `jobs.list`（R106）已就位。
- calyd in-flight 请求优雅排空、Windows SCM 关停、launchd/容器部署工件、`.deb`/`make install` 打包。
- 远程强制 CI/fuzz/性能回归门禁（本地 `check.sh` 已全绿，远程强制仍缺）。

**显式不做 / 推迟（有 ADR/规则依据）**：
- calyd **不自我守护**（不 fork/pidfile/自装服务）——交给 systemd（`ADR-055`）。
- mihomo/sing-box **不做成独立 systemd unit**——内核生命周期耦合 apply 事务，由 calyd 内 Core Supervisor 管（`ADR-055`/`RFC-0005 §11.2`）。
- 生产代码**不经 `/bin/kill` 发 TERM**、不引信号 crate（`ADR-043 §2.5`/`ADR-056`）。
- v1 **不做** principal/凭据认证（「谁在调用=一个角色」，`ADR-037`）。
- TUI 排最后、**不让 TUI 反向驱动架构**（`docs/engineering/TUI_PLAN.md`/ROADMAP Phase 9）。
- 外部 crate 须先有 ADR（目前唯一直接外部依赖是 ADR-046 授权的 `serde_json`，仅 caly-daemon）。

---

## 10. 去哪验证 / 深入阅读

- **用户面实测**：`docs/engineering/OPERATOR_SCENARIO_REPORT.md`（全产品五场景实测与发现清单）、`JOB_FLOW_COST_BENEFIT_REPORT.md`（Job/Flow 成本收益）、`JOB_FLOW_SCENARIO_REVIEW.md`（Job/Flow 机制重估）。
- **架构边界**：`docs/rfcs/RFC-0001`（不变量）…`RFC-0010`；决策来由：`docs/adrs/ADR-011`…`ADR-056`。
- **当前实现状态**：`docs/status/IMPLEMENTATION_STATUS.md`（§3.3 测试普查、§8 逐轮收口）、`docs/status/CENTERLINE_PROGRESS.md`（主链接到哪）。
- **路线**：`docs/status/ROADMAP.md`（Phase 0–10 与完成度；注意其量化快照为 2026-08-30，最新数字以 `docs/status/CENTERLINE_PROGRESS.md`/本文件为准）。
- **接手/踩坑**：`docs/history/ONBOARDING_NOTES.md`（§4 偏差留档、§6 处置表）、`docs/guides/DEVELOPMENT_WORKFLOW.md`（接续流程）。
- **部署**：`docs/guides/DEPLOYMENT_SYSTEMD.md`；**退出码**：`docs/guides/EXIT_CODES.md`；**错误码**：`docs/guides/ERRORS.md`。
- **每轮改动**：`DEVELOPMENT_LOG_2026-08-31-round90..103.md`。
