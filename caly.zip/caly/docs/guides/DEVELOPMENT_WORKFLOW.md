# Caly 开发工作流与门禁（Development Workflow）

> 本文是**开发范式的唯一入口**：怎么接活、怎么写代码、怎么改文档、怎么通过门禁、怎么提交。
> 它取代 2026-09-01 之前的 `docs/history/CONTINUATION_PLAYBOOK.md`（后者归档于 `docs/history/`，
> 其方法论经验保留在本文 §4–§7，其过程记录保留在 `docs/history/ONBOARDING_NOTES.md`）。
>
> 权威顺序不变：RFC > ADR > 工程文档 > 代码；本文属于「工程文档」一档。

---

## 1. 五条铁律

1. **Git 是唯一事实来源**。仓库演进只通过提交表达：「这轮改了什么」用 `git diff` / `git status`
   回答，不再依赖文件时间戳或备份目录。基线 `caly.zip` 保留在仓库根但不再跟踪（见 `.gitignore`）。
2. **先量，再决定**。任何「文档说没做 / 我记得做了」都不作数：用 grep、一次跑测、生成器 `--check`
   把现状钉住，再决定这轮做什么。
3. **裁判先行**。每个新性质都要有能变红的测试或门禁；每条新门禁都要有一个能让它变红的变异
   （一次一个变异，见 §6）。
4. **本地门禁即 CI**。`scripts/check.sh` 在本地和 CI 跑的是同一套；本地不绿不提交，`main` 永远绿。
5. **权威顺序不绕行**。撞上冻结边界（RFC 签名、错误码表、依赖清单、时钟纪律）时：要么写 ADR，
   要么改 RFC，不允许在代码层悄悄绕。

---

## 2. 仓库与分支模型

- `main`：唯一长期分支，永远处于「门禁全绿」状态。
- 功能分支：`feat/<目标>`、`fix/<目标>`、`docs/<目标>`，短命，一个分支一个目标，完成后合并回 `main`。
- 提交规范（Conventional Commits）：

```text
<type>(<scope>): <一句话主题>

<可选：为什么这么改、判据是什么、证伪结果>
```

- `type`：`feat` / `fix` / `docs` / `refactor` / `test` / `chore` / `gate`（门禁本身）/ `adr`。
- `scope`：改动所在的 crate 名或 docs 目录（如 `caly-daemon`、`guides`、`status`）。
- **一条提交一个逻辑变化**。「顺手」改的东西开下一条提交，混在一起的分复用不了。
- 发版：合并后更新根 `CHANGELOG.md`（格式见 §8），重要决策另写 ADR。

---

## 3. 工具链与环境

- 工具链由 `rust-toolchain.toml` 钉死：`stable` + `rustfmt` + `clippy`；升级工具链是单独一条提交，
  升级后必须重测 clippy 基线（见 §7）。
- 首次安装：

```bash
curl -sSf https://sh.rustup.rs | sh -s -- -y --profile minimal --default-toolchain stable
rustup component add rustfmt clippy
```

- 每个 bash 会话先 `export PATH="$HOME/.cargo/bin:$PATH"`——工具链在会话中消失过，`check.sh` 的第一步
  会**报错并附恢复命令**而不是静默绿。
- 空输出不等于通过：`cargo … | grep …` 什么都不印，很可能是 cargo 根本没跑（它的报错写在自己的
  stderr 里被管道吞了）。

---

## 4. 一轮开发的标准循环（七步）

| 步 | 做什么 | 判据 |
|---|---|---|
| 1 | 量现状：grep / 一次跑测 / 生成器 `--check`，把「现在是什么」钉住 | 现状写进本轮记录 |
| 2 | 写靶子：一句可证伪的目标 + 让它成立的裁判（测试/门禁） | 裁判先红 |
| 3 | 实现：只做靶子这一件事 | `cargo check --workspace --all-targets` 0 warning |
| 4 | 文档同步：census / doc-index 生成器、CHANGELOG、必要时 ADR | 两个生成器 `--check` 退出 0 |
| 5 | 门禁：`bash scripts/check.sh` 连跑两次 | 第二次与第一次一致且全绿 |
| 6 | 证伪：每个新断言一个变异，一次一个（§6） | 变异全部咬住 |
| 7 | 提交：一条逻辑提交，附本轮日志 | `git status` 干净 |

顺序是硬的：第 4 步在第 6 步前（证伪会改文件）；第 5 步在提交前（提交的就是绿的那棵树）。
顺手重构不是本轮的便利，是下一轮的靶子。

---

## 5. 数字纪律

1. **只抄裁判自报的数**：`check.sh` 输出的数字、生成器打印的 `files=N total=M`、`cargo test` 的
   `test result:`——不做加法，不做「差不多」。
2. **重抄放在最后一次改动之后**（包括「为文档补的那条测试」这种小改动）。
3. **一个数带口径**：输出行数、hunk 数、文件数是三个不同的数，写清楚是哪个。
4. **常数关系写进编译期**：`const _: () = assert!(A >= B, "为什么")`，别用运行期断言拴两个常数。
5. **测不到的数字不写**：拿不出可复现命令的数字一律删掉，宁缺毋滥。

---

## 6. 证伪规程（falsification）

每个新测试/门禁都要回答「什么改动会让它变红」。规程：

1. **一次一个变异，一个变异只改一个文件**（两个文件同时改，红了不知道是谁）。
2. 变异必须保住绑定、类型、调用 arity——目标是「性质不成立」，不是「程序坏掉」；「没编译」和
   「没咬住」要分开报告。
3. 每个变异列出**期望变红的测试名**，命中才算咬住（bit）。
4. 一个变异不咬时，先改变异、别急着改测试：多半是断言还没长在正确的分支上。
5. 变异脚本一次性用完可以留在 `scripts/archive/`（历轮 `falsify_round*.py` 是现成范例），
   不进入常规流程。

---

## 7. 门禁清单（新增门禁前先查这张表）

| 门禁 | 判什么 | 失效形状（怎么知道它在工作） |
|---|---|---|
| `scripts/check.sh`：build 0 warning / `TEST_FLOOR` 不降 / clippy 位置棘轮 / fmt 硬门禁 | 编译干净、测试数不下限、告警不增、格式零欠账 | 把 floor +1 应看到 FAIL 原文 |
| `regenerate_test_census.py --check` + `status_table_test_counts_match_the_tree` | `IMPLEMENTATION_STATUS §3.3` 每行测试数与树一致，无未登记文件 | 加一个 `#[test]` 不改表 |
| `regenerate_doc_index.py --check` + `the_document_index_lists_every_document` | `docs/README.md §1` 树与 `docs/` 全树双向一致 | 加一篇文档不改索引 |
| `every_documented_path_reference_resolves` | 文档里 `crates/…` / `docs/…` / `scripts/…` 引用都存在 | 删掉一个被引用的文件 |
| `doc_tables_and_lists_are_well_formed` | 表格列数/分隔行、列表连号、小节号唯一、表行单行 | 删掉某表的分隔行 |
| `check_disposition_ledger` | 接手笔记处置表行号连续、行相邻、每行以 `\|` 收尾 | 在两行之间插一个空行 |
| `the_centerline_assertion_count_matches_the_tree` | CENTERLINE 的「这 N 个断言是否依然成立」= 树内实际数 | 把那个数改错 |
| `crate_names_in_docs_are_members_or_documented_as_absent` | 文档里的 crate 名是成员，或已登记为「计划中」 | 文档里写一个不存在的 crate |
| `the_doc_tree_is_actually_scanned` | 文档门禁不是空转（文件数/引用数/行数下限） | 把 `docs/` 目录改坏 |
| `dependency_direction.rs` 一组 | 依赖边、纯核不碰 IO/墙钟、效应计划走游标入口、store 走共享预算、registry 工件方向、CLI 全帧走泵、期限对称、hello 角色 fail-closed、systemd unit 形状、信号面等 | 往 `ALLOWED_*` 塞一条没用的边 |

**新增门禁的三条要求**：① 有单元测试说明它判什么；② 有一个「让它变红」的变异；③ 带一条反空转
断言（扫到的对象数 ≥ 下限），否则目录一改它就静默变成扫 0 个。

---

## 8. 变更记录与发布

- 根 `CHANGELOG.md` 按日期分段；每段写「新增 / 修复 / 变更」三类，一句话一条，附依据（测试名/门禁名）。
- 2026-09-01 之前的逐轮明细在 `docs/history/logs/`（只读）。
- 发布 = 打 tag + CHANGELOG 补发布节；systemd 部署工件在 `packaging/systemd/`，
  runbook 在 `docs/guides/DEPLOYMENT_SYSTEMD.md`。

---

## 9. 代码规范要点

- **clippy**：0 新告警。棘轮只允许随修代码下降，不允许上升、不允许 `#[allow]` 消音。
- **rustfmt**：全仓干净（硬门禁）。2026-09-01 起不再有「格式欠账」这个概念。
- **依赖边界**：新外部依赖必须先有 ADR（当前唯一授权例外是 `caly-daemon` 的 `serde_json`，ADR-046）。
- **时钟纪律**：只有 `caly-io-std` 读宿主时钟；其余地方没有时钟就没有期限判断，「不可判」要如实报告。
- **单一 IO 网关**：生产代码禁止 `std::fs` / `std::process` / `SystemTime::now`（`clippy.toml` 钉死），
  IO 一律走 `caly-io` Port。
- **unsafe**：最小化，每处必须有注释说明为什么安全。
- **测试命名**：描述性质的句子（`the_xxx_yyy`），不用 `test_1` / `test_2`。

---

## 10. 一句话原则

> 文档是代码的一部分，门禁是编译器；数字不许手抄，历史不许改写，本地绿了才提交。
