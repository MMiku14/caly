# 开发日志 — 第九十九轮（R99）

- **日期**：2026-08-31
- **一句话**：一次性 `caly job <id>`（`jobs.follow` 查询）描述终态失败作业时，按响应里已携带的稳定 `failure_code` 映射退出码（PERMISSION→8、STORAGE→10、TIMEOUT→11…），不再打印了失败码却 exit 0 报成功；空/缺 `failure_code` = 未失败仍 exit 0；`--json` 语义相同。
- **数字**：`cargo test --workspace` **851 → 856**（CLI 假 daemon e2e +3、退出码表单测 +1、arch 结构门禁 +1）；`TEST_FLOOR` 851 → **856**；clippy 去重源码位置 **31 持平**；fmt clean。

---

## 1. 靶子

R98 收口了 daemon **主动 REFUSAL 帧**的码映射（daemon 拒绝执行 → 公共码 → 退出号）。量选转向对称问题：**daemon 成功应答体里携带的作业失败判决**。

一次性 `caly job <id>` 是 `jobs.follow` 查询（走 `ask()`，**不是**流式 `follow_stream`）。daemon 的 `job_follow_records`（calyd.rs）**恒发 `failure_code`/`failure_summary` 两个字段**：失败作业填引擎 `JobEvent::Failed` 的 `error.code.as_str()`（`caly-engine/service.rs::summarize_job_record`，值域就是 14 个公共 `ErrorCode`），成功作业填空串。`print_job_follow` 也确实把 `failure_code` 逐行打印出来。

但 main 的 `Ok(Answer::Records)` 两个应答臂（人类 records 渲染、`--json` 原文）打印后都**一律 `exit_code(ExitCode::Success)`(0)**：

```rust
Ok(Answer::Records(records)) if json_mode => { println!("{json}"); exit_code(ExitCode::Success) }
Ok(Answer::Records(records))               => { print_job_follow(&records); ...; exit_code(ExitCode::Success) }
```

于是查询一个终态失败作业时，纸上印着 `failure_code: PERMISSION`，退出码却是 0——shell/CI 拿 `caly job <id>` 探作业成败会得**假阴性**。这违反：

- `EXIT_CODES.md §4.3`「失败作业按其公共码映射退出号」；
- `EXIT_CODES.md §1.4`「`--json` 不改变退出码语义」。

对照：流式 `caly follow <id>` 早已按 END 帧 `outcome` 定判（Succeeded 0/Failed 1/Cancelled 15/TimedOut 11），一次性查询这条路漏了失败判决。**wire 上码已在，纯粹是 CLI 没用它**——不改 wire、不改 daemon、无新依赖/ADR。

## 2. 修复

`crates/caly-cli/src/bin/caly.rs` 加助手：

```rust
fn job_follow_failure_exit_code(operation: &str, records: &[(String, String)]) -> ExitCode {
    let failure_code = if operation == "jobs.follow" {
        wire_field(records, "failure_code").filter(|code| !code.is_empty())
    } else {
        None
    };
    match failure_code {
        Some(code) => caly_cli::from_wire_refusal_code(code),
        None => ExitCode::Success,
    }
}
```

- **仅** `jobs.follow` 读失败判决：status/doctor/profiles/gc-plan… 都是成功查询，恒 exit 0。
- **判空**：daemon 恒发 `failure_code` 字段、成功时为空串，故用「非空」而非「字段存在」判失败。
- **复用 R98 的 `from_wire_refusal_code`**：`failure_code` 与 REFUSAL 的 `code` 同属 14 个公共 `ErrorCode` 词汇，走同一张表，不另立映射（两张表会漂移）。空/缺 = Success；未识别码仍回落 ProtoMismatch(13)。
- json 与 records 两应答臂都在打印后 `exit_code(job_follow_failure_exit_code(wire.name, &records))`。

不新增/重命名任何退出码或错误码；不改 wire 帧形状、不改 daemon；无新依赖、无新 ADR。

## 3. 裁判

- **单测** `exit_code_table::a_job_failure_code_uses_the_same_public_code_table_as_a_refusal`：钉 failure_code 经 R98 表各落其文档退出号（CONFIG_INVALID→3、CORE_FAILED→7、PERMISSION→8、NET_OS→9、STORAGE→10、TIMEOUT→11、INTERNAL→16），failure_code 不是独立词汇表。
- **假 daemon e2e 三胎**：
  - `a_one_shot_job_query_for_a_failed_job_maps_its_failure_code`：daemon 回 jobs.follow RESPONSE(kind 4) 带 `failure_code=PERMISSION` → **exit 8 非 0**、`failure_code: PERMISSION` 行仍打印给人看；
  - `a_one_shot_job_query_for_a_non_failed_job_stays_exit_zero`（反空转）：`state=completed`、`failure_code=` 空字段 → exit 0（防「凡 job 查询都非零」）；
  - `a_one_shot_json_job_query_for_a_failed_job_maps_its_failure_code_too`：`--json` 会话 hello_ack 须答 `encoding=json`、v0 JSON 值全为字符串（含 `request_id`，整数会被 v0 方言拒）、回 json `failure_code=STORAGE` → exit 10。
- **结构门禁** `the_cli_maps_a_one_shot_job_follow_failure_code_to_an_exit_code`：助手存在、仅 `jobs.follow`、判空闭包、**「调用 `from_wire_refusal_code`」的断言限定在 helper 函数体内**（见 §5-M3）、两应答臂都调用（助手名出现 ≥3 处）。

既有真 daemon e2e 无回归（成功 job 查询仍 exit 0）。

## 4. 证伪（scripts/falsify_round99.py）

| 变异 | 改动 | 被咬的裁判 | 结果 |
|---|---|---|---|
| **M1** | 助手塌成恒 `ExitCode::Success`（撤失败映射） | 失败 PERMISSION e2e（得 0 非 8）+ json STORAGE e2e（得 0 非 10）；非失败胎**仍绿** | BIT |
| **M2** | 去掉判空过滤（空串也进表 → `from_wire_refusal_code("")` 落 13） | 成功 job e2e（空 `failure_code=` 得 13 非 0） | BIT |
| **M3** | 助手内硬编码 `Success`、绕过 `from_wire_refusal_code` | 结构门禁（体内断言） | BIT |

M1 里非失败胎仍绿是关键：证明 M1 撤的**只是失败判决**、不是把退出码逻辑整个删了。M2 证明判空闭包是「健康作业保持 exit 0」的那一层。

## 5. 本轮踩到的坑（留档）

- **M3 门禁第一版假绿**：门禁最初在**整个 bin 文件**里 `text.contains("from_wire_refusal_code(code)")`，但 bin 的 R98 两个 REFUSAL 臂（caly.rs:397、1194）也调同名函数——助手内被硬编码绕过时，全文件仍命中，门禁不红。收紧成「提取 `fn job_follow_failure_exit_code` 的函数体、在**体内**断言调用」后 M3 才咬。教训（已入 `ONBOARDING §4.173` 规则①）：**凡「某函数必须调用 X」而 X 在同文件别处也被调用，全文件 contains 就是空裁判，必须圈定函数体。**
- **v0 JSON 方言只接受字符串值**：json e2e 胎第一版回 `{"request_id":1,...}`（整数）被 CLI 以「v0 JSON values are strings, nothing else」拒成 exit 13；改 `"request_id":"1"` 后通。
- **json 会话的 hello_ack 必须答 `encoding=json`**：`write_hello_ack` 助手写死 records，json 测试须手写 `encoding=json` 的 hello_ack，否则握手即对线分歧。
- **census 表格单元格里的裸 `|` 截断 markdown 行**：R99 门禁描述里写了 `filter(|code| ...)`，闭包的裸管道符被当成表格列分隔符、整行截断（doc 形状损坏）。改写为不含裸 `|` 的措辞（「判空闭包」）后修复。**表格内的代码片段一律避开裸管道符或转义。**

## 6. 明确没做（范围纪律）

- **流式 follow 的 END 帧不携带 failure_code**：`PumpStep::End{seq, outcome, state}` 与 v0 END 帧只有 outcome 枚举、无 code；`JobEventsView` 流窗 schema 也没有 failure_code 字段。要给流式 follow 也按公共码细化退出码（而非现在的 Failed→1），须在 END 帧加字段 = `JobEventsView` + PumpStep + wire 三处跨层扩展，属 wire 形状变更，须先 ADR/RFC（`RFC-0002 §8.2` 规定流终态 `Failed { error }` 带码，但 v0 泵把终态折叠成 outcome 枚举）。**记为后续大活，不在现有 v0 帧硬塞 code。**
- 不新增/重命名退出码或错误码；未识别 failure_code 仍回落 ProtoMismatch(13)（与 R98 统一：wire 上不可识别码 = 对线分歧；引擎正常只产公共码，此为防御）。
- 不改 daemon、不改 wire、无新依赖/ADR。

## 7. 收尾

- census：`regenerate_test_census.py` 三行手写描述（dependency_direction 22 / caly_cli_e2e 45 / exit_code_table 5），`--check` 一致（files=105 total=856）。
- 文档：STATUS §8.33、ONBOARDING §4.173 + 处置表 6.125（「不做」标题 6.125→6.126）、CENTERLINE 计数 851→856、本日志、README 三索引。
- `check.sh` 连跑两次全绿（856/floor 856/clippy 31/fmt 0）；floor 撕开测试见 FAIL 后还原；无 `.r99bak/.orig` 残留。
