# Caly Loopback Contract Strategy

本文件说明为什么 `LoopbackHarness`、`RemoteSessionClient`、`ServerLoop` 与 `ContractReport` 应共同构成 Caly 在 IPC 层最早期的 contract strategy。

---

## 1. 当前阶段为什么要靠 loopback contract

在还没有：

- 真实 UDS runtime
- Windows Named Pipe runtime
- 完整 async transport loop
- 全量 RemoteApi/CLI 集成

之前，最值得先做的是：

- 验证协议语义
- 验证 local/remote parity
- 验证 hello/request/stream/ack/follow 的闭环

而 loopback contract 正好最适合这件事。

---

## 2. 当前已具备的拼图

当前已开始具备：

- `LoopbackHarness`
- `LoopbackRemoteTransport`
- `RemoteSessionClient`
- `RemoteFacade`
- `LocalFacade`
- `run_basic_parity_check(...)`
- `run_system_contract(...)`
- `run_job_follow_contract(...)`
- `run_loopback_remote_contract(...)`
- `run_basic_wire_probe()`
- `run_smoke_bundle()`（scenario 束，128 行，由 `every_scenario_suite_row_passes` 逐行判定）
- `run_remote_follow_scenarios()`
- `run_contract_bundle()`

这意味着：

> Caly 已经有能力在不依赖真实 socket runtime 的情况下，对协议和 facade 路径做高价值 contract 验证。

---

## 3. 推荐 contract 分层

### Layer 1 — Wire/Session Contract

关注：

- hello
- frame validation
- session close
- stream ack legality

### Layer 2 — Request/Response Contract

关注：

- operation dispatch
- request -> command
- response shape
- error mapping

### Layer 3 — Watch/Follow Contract

关注：

- runtime watch
- job follow query
- job follow stream
- replay / reset / retained window

**本版状态（第十二轮）**：follow 一侧现在有**六条** contract 断言在同一条 loopback 上跑（名字逐个来自
`run_loopback_remote_contract`）：

1. `remote.profile.apply.follow` —— 摘要计数；
2. `remote.diagnostics.job_events` —— 事件行本身，并要求 `snapshot.committed` 这类关键行真的出现在文本里；
3. `remote.diagnostics.job_events.unknown_job` —— 未知 job 是拒绝，不是空窗口；
4. `remote.diagnostics.job_events.bounded` —— 要 3 行就只给 3 行，且 `next_from_event_index` 恰是本项
   最后返回的索引、`byte_len` 等于返回文本长度；
5. `remote.diagnostics.job_events.walk` —— 按这个游标走到结束，必须逐行拼回整窗；
6. `remote.profile.apply.follow-stream` —— 流侧仍然只到"有行"这一层（见本节末）。

第 4、5 条是分页读的全部价值所在：一个只在本地生效的上界，会伪装成"远端日志少了"。
另外 `with_client` 那层"把 daemon 的 `ApiError` 压成 String"的包装已经从 façade 移除，
所以 contract 里出现的拒绝带着 code/category/remediation，而不只是一句话。
watch 一侧**部分**补上：本轮起 `runtime.watch.structured-runtime-state` 是真的（部署会在快照提交后
发出 runtime-state patch，`§10.3` 的"snapshot + patch"不再是空头承诺），并且这一行由 scenario 判定者逐行
判定。仍未覆盖的是**跨路径逐帧比对**：`pull_stream` 拿到的帧只检查"非空与行数"，两条路径的帧序列没有被
一帧一帧地对齐过。

### Layer 4 — Local/Remote Parity Contract

关注：

- 相同输入是否返回同语义输出
- skeleton 阶段是否已经开始出现漂移

---

## 4. 一句话结论

> 在 Caly 当前阶段，loopback contract 不是权宜之计，而是把协议设计真正压实为可验证实现的最短路径。