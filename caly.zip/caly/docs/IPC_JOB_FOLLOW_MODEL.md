# Caly IPC Job Follow Model

本文件补充说明 Caly 协议中一个高价值但容易被忽视的部分：**Job follow**。

它回答的问题包括：

- Command 返回 `Accepted` 之后，客户端如何观察最终结果？
- Job follow 用 query 还是 stream？
- event index / replay / reset 要如何建模？
- CLI 的同步体验如何基于 Job follow 组合出来？

---

## 1. 为什么 Job follow 是协议一级问题

Caly 的 Command 不是短同步 RPC，而可能触发：

- 编译
- 原生验证
- 核心启停
- 系统副作用
- 健康检查
- 回滚

因此，`Accepted` 只是开始，不是结果。

如果没有正式的 Job follow 模型，就会出现：

1. CLI 不知道该如何等待
2. TUI 不知道如何看进度
3. reconnect 后无法继续跟踪
4. 同一 command 的最终结果无法统一暴露

---

## 2. 推荐模型

建议 Job follow 分两层：

### 2.1 Job summary query

用于获取：

- 当前 job state
- 当前 lifecycle
- next event index
- retained_from_event_index
- reset_required
- 当前可见事件数量摘要

### 2.2 Job event follow

用于获取：

- 从某个 event index 继续读取的 job 事件窗口
- 若事件被裁剪，则返回 reset 或 stale 语义

**本版状态（2026-08-27，第十二轮）**：§2.1 与 §2.2 的读取面都已经有实现，**两条 façade 都能用**，并且 §2.2 的读是**有界且可续读**的。

| 模型条目 | 落点 | 说明 |
|---|---|---|
| §2.1 摘要查询 | `DiagnosticsOp::FollowJob` → `JobFollowView` | 只有计数与末段状态；第十一轮之前这是**唯一**跨 façade 可读的东西。**仍然无界**：它是摘要，不是日志 |
| §2.2 事件窗口 | `DiagnosticsOp::ReadJobEvents` → `JobEventsView` | 返回渲染后的行；`LocalFacade` 与 `RemoteFacade` 同一条 Query |
| `from_event_index` 语义 | `slice_job_events` | **排他**：给 `n` 表示"从 `n+1` 起"；越界到末尾 → 空窗口且 `reset_required = false`（"没有新东西"不是"你掉线了"） |
| 裁剪与 reset | 同上 | 游标比保留窗口起点还旧 → `reset_required = true` 且**不返回半截列表**；默认窗口 128 行 |
| 事件文本的唯一写法 | `caly_engine::bundle::render_job_event` | follow / stream / support bundle / 本查询共用一个渲染器，避免同一事件三种拼法 |
| 一次读多少 | `caly_daemon::paging::EventPagePolicy` → `caly_engine::page_job_events` | **第十二轮**：`JobEventsRequest.max_lines` / `max_bytes`，默认 64 行 / 64 KiB，上限 512 行 / 1 MiB（由 `caly-ipc` 的 4 MiB 帧上限反推）；超限被**收窄**而不是报错，`0` 被 `CONFIG_INVALID` 拒绝而不是被猜 |
| 续读游标 | `JobEventsView.next_from_event_index` | 本项**最后**返回的索引（请求游标是排他的，所以名字与字段配对，客户端不必算 `±1`）；`None` = 已到窗口末尾；`is_truncated()` 就是它的 `is_some()`，不另设 `truncated` 布尔 |

规则来源是 `RFC-0002 §9`（日志这类大集合 MUST 分页或流式）与 `§11.4`（大对象 MUST NOT 以内嵌超大 IPC 帧
返回）；上限由**两条 façade 共同经过的 daemon 出口**施加，因此本地与远端不可能对"一页多大"各说一套。
两条边界规则各自有断言：单行超过字节预算时**仍然返回该行**（空页 + 不动的游标 = 客户端活锁），
以及 reset 分支**不产生**一个看起来能续读的游标（陈旧游标的回答是"从头重取"，见 `§10.2`）。

仍未做的：ACK 与重放窗口细则、reconnect 场景。`§5` 里的第 2 条（`from_event_index` 越界规则）第十一轮
已落到实现与单元测试，第 3 条（流侧逐帧内容比对）仍未做 —— 现在帧只被检查"非空与行数"。

---

## 3. 当前 skeleton 已有基础

当前代码骨架已开始具备：

- `Accepted { job_id, ... }`
- `JobFollowRequest`
- `JobFollowView`
- `DiagnosticsOp::FollowJob`
- `DiagnosticsOp::FollowJobStream`
- engine 内部 `slice_job_events(...)` with retention policy
- daemon query path 中的 follow job skeleton
- daemon stream / watch bridge 中的 job stream skeleton

这说明 Job follow 已经开始从“架构概念”进入“协议对象”。

---

## 4. CLI 的同步体验应如何建立

建议保持：

```text
submit command
  -> receive Accepted(job_id)
  -> follow job summary / events
  -> render progress
  -> on completed/failed map exit code
```

这意味着：

- CLI 的“同步感”来自 follow 逻辑
- 协议本身仍保持 command 与 result 的解耦

---

## 5. 当前仍缺的关键点

虽然已有骨架，但仍缺：

1. Job stream 的 ACK 与重放窗口细则
2. `from_event_index` 超出保留范围时的正式 reset/stale 规则
3. query 与 stream 组合时的客户端最佳实践
4. job event DTO 的进一步细化

---

## 6. 下一步建议

1. 补充 Job event stream 的 reset/stale 规则
2. 明确 `from_event_index` 的边界语义
3. 把 job follow 与 CLI `--json` / exit code 映射对齐
4. 为 job follow 增加 reconnect 场景测试

---

## 7. 一句话结论

> Command 的结果不是 Response 本身，而是 Job follow 过程中的收敛结果；因此 Job follow 必须被当作正式协议能力设计。