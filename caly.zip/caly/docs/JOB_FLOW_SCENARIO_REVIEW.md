# Job / Flow 实战场景测试与功能必要性重估

> 本文不是设计稿，而是一次**动手实测**的记录与据此的重估：构造一个真实依赖 **Job（异步作业）** 与 **Flow（follow 流式跟随 / 断点续传 / 事件分页）** 的运维场景，用构建出来的 `calyd`/`caly` 真二进制跑通，再用观察到的行为回答两个问题——
>
> 1. **这些功能在真实使用里到底解决了什么、哪些是真必要、哪些当前够不到或被架空？**
> 2. **下一步发展方向应该往哪走？**
>
> 方法：不用测试 harness，直接后台起 `calyd`、用 `caly` CLI 与一个最小裸 wire 客户端（Python，帧格式见 `caly_cli_e2e.rs` 顶部 oracle）驱动。日期 2026-08-31，基线 862 测试 / floor 862，`--effect-runtime simulated`（默认，零宿主副作用；真实内核时长差异在文中标注）。

---

## 1. 场景设定：一次网关「部署日」

> 角色：管理一台无头 Linux 网关上 calyd 的运维。这天要切换代理配置、观察部署过程、出问题回滚、清理垃圾、打包诊断、期间可能断线/重启 daemon。

剧本（全部真实执行）：

| 步 | 动作 | 命令 |
|---|---|---|
| 0 | 起 daemon（ephemeral TCP + port-file） | `calyd --data-dir D --bind 127.0.0.1:0 --port-file P` |
| 1 | 查状态 | `caly status` |
| 2 | 应用配置（铸一个 Job） | `caly apply demo-tun-profile --idempotency-key k1` |
| 3 | 列配置 | `caly profiles` |
| 4 | 一次性作业摘要 | `caly job 1` / `--json` |
| 5 | 事件分页 | `caly jobs 1` / `--json --from 0 --max 2` |
| 6 | 流式跟随（重放已终态作业） | `caly follow 1` |
| 7 | 断点续传 | `caly follow --resume 1` |
| 8 | 幂等重放 / 新键 | 同 key 重放 `apply`；换 key 再 apply；缺 key |
| 9 | 回滚 | `caly rollback --snapshot <snap> --idempotency-key k` |
| 10 | 垃圾回收 | `caly gc-plan`；`caly gc --idempotency-key k` |
| 11 | 诊断 | `caly doctor`；`caly support-bundle`；`caly bundle` |
| 12 | 角色分权（裸 wire） | Viewer/Operator 握手试 Admin-only `system.gc` |
| 13 | 崩溃恢复 | `kill -9 calyd` → 同 data-dir 重启 → `status` / `job 1` |
| 14 | 慢 worker 实时 attach | `--worker-tick-ms 400` 下 apply 后快查 state |
| 15 | 边界 | follow 不存在的 job；follow 超大 `--from` 游标 |

---

## 2. 实测观察（证据）

### 2.1 Job 主链：真的在跑、可见、可审计 ✅
- `apply demo-tun-profile` 返回 `job_id: 1 / state_revision: 1 / estimated_impact: Restart`，作业被后台 worker 逐 stage drain。
- 作业事件**丰富且有信息量**：`caly jobs 1` 给出 **44 个事件**，完整覆盖
  `running → pipeline.resolve → capability.validate(required=8 warn=1 blocked=0) → native.validate → apply.plan(Restart) → storage.project(txn/snapshot) → effects.prepare(11 steps) → cutover(net-apply/spawn-core) → 5 个 probe(ApiReady/InboundListening/ConfigIdentity/CoreIdentity/TelemetryTraffic) → mark-snapshot → commit-revision → snapshot.committed → Succeeded`。
- `caly job 1` 摘要字段齐：`state/lifecycle/next_event_index=44/event_count=44/last_stage/last_stage_pct=100/warning_count=8/log_count=25/failure_code/failure_summary`；`--json` 同体。
- **分页游标正确**：`--from 0 --max 2` 回 2 个事件、`next_from_event_index=2`，可逐页拼接。

> 结论：Job 化（ADR-018）不是摆设——它把一次部署变成一条**可分页、可审计、带进度百分比与能力判定的事件流**，这正是同步 RPC 给不了的。

### 2.2 Flow：follow / resume 的核心价值被证实 ✅
- `caly follow 1`（对已终态作业）：stderr `stream 1 (resumed=false)`，stdout 无损重放 44 行。
- `caly follow --resume 1`：stderr `stream 1 (resumed=true)`，stdout **0 行**——已 ack 的事件**零重印**，证明 daemon 端记住了该流消费到哪。
- 再 `caly follow 1`（fresh）：分配**新流 stream 3**、全量 44 行——resume 走的是有记忆的同一条流，fresh 另开。
- 慢 worker（`--worker-tick-ms 400`）下 apply 后快查：**poll 1 抓到 `state: accepted`（非终态），poll 2 起才 `completed`**——证明确有一个「作业在后台跑、客户端可中途 attach」的真实窗口。

> 结论：lossless-resumable 流模型在**真实内核长部署**（spawn/probe 可达数十秒，正是 stream idle 30s 加宽的理由）与**断线重连续传**场景下是真必要的基础设施，不是过度设计。

### 2.3 幂等 / 回滚 / GC / 诊断：事务纪律落地 ✅
- 同 `--idempotency-key` 重放 → **同一个 job_id: 1、state_revision 不变**；换新 key → 新 job 2 / revision 3；缺 key → **exit 2（usage）**，stderr 明确提示。
- `rollback --snapshot <snap>` → 铸 job 3（estimated_impact: Restart），回滚复活目标部署。
- `gc-plan` 只读给出完整计划（objects/snapshots/revisions/unfinished_journals/grace/would_run…）；`gc` 铸 job 4（ReadOnly impact）；`max_deletions=0` 之类的破坏性门已在测试层钉住。
- `doctor` 三层体检（storage audit / recovery / idempotency entries=4 / gc plan / gc cycle…）；`support-bundle` 铸 job 5 并进 CAS，`caly bundle` 读回 **digest 与 content_sha256 一致**、96 行脱敏内容。

### 2.4 角色分权：wire 层有效，但**生产 CLI 够不到** ⚠️
裸 wire 客户端实测：
- `role=Viewer` 打 Admin-only `system.gc` → **REFUSAL `code=PERMISSION`**：「request role Viewer does not satisfy required role Admin」。
- `role=Operator` 同样被拒；`role=Viewer` 打只读 `runtime.status` → 正常返回。
- **但 `caly --help` / `caly apply --help` 里没有 `--role` 旗标**——生产 CLI 握手恒为 Admin。

> 结论：分权机制（ADR-037，R92/R93 fail-closed）在协议与 daemon 侧是真的、且测过；可**真实用户用官方 CLI 无法以 Viewer/Operator 身份连接**，分权在当前用户面**不可达**。要落地「监控机只读、运维机可写」，CLI 必须能声明角色（并配套认证，见 §4）。

### 2.5 崩溃恢复：部署状态持久，但**作业事件历史跨重启丢失** ⚠️（最重要发现）
- `kill -9 calyd` → 同 `--data-dir` 重启：`status` 显示 **active_profile / active_core / active_snapshot 都还在**、`last_recovery_summary: recovery scan clean`——**部署目标状态持久**。
- **但 `caly job 1` / `caly jobs 1` 重启后被拒：`refused (CONFLICT): no such job: 1`（exit 4）**。作业事件流是**内存态**，daemon 一重启，历史 Job 及其 44 个事件全部消失。
- 且全库**没有 `jobs.list` 操作**（CLI 也无 `jobs` 无参列表）：你必须**已经知道 job_id** 才能查；重启后既列不出历史、也查不到旧 job。

> 影响：在「daemon 升级 / 崩溃重启 / 跨天回看」这些 flow 最该发光的场景里，follow/resume 的对象（历史作业流）**没了**。resume 只能在「同一次 daemon 生命内断线重连」工作；一旦 daemon 重启，`--resume <旧流>` 无流可续。这与「可审计部署事务」的定位存在缺口：**状态可审计（snapshot/revision 持久），过程（job events）当前不可跨重启审计**。

### 2.6 其它边界观察
- follow 不存在的 job → `refused (NOT_FOUND) ... a stream cannot open on a job that was never accepted`，**exit 13**（合理）。
- `follow 1 --from 999999`（超出末尾）→ **exit 0、0 行**：`--from` 是开流起点游标，超出即「从末尾之后开始」、无 delta、干净结束；state-gap(exit 14) 只在 *resume 时 daemon 端游标已被 GC 截断* 才触发。语义自洽，但**退出码 0 不区分「没有新事件」与「游标本就非法」**，脚本难以分辨「真的没事」还是「我给错游标了」。
- `--json` 输出是「JSON 值全为字符串」（v0 记录方言），如 `"event_count":"44"`——机器消费方要自己转型，这是 v0 的已知简化。

---

## 3. 功能必要性重估（基于实测，不凭印象）

| 功能 | 实测判定 | 必要性评估 |
|---|---|---|
| **写操作即 Job + 事件流** | ✅ 44 事件、进度%、能力判定、probe 全可见 | **核心刚需**。同步 RPC 无法表达长部署的进度/警告/阶段；这是 caly 相对「改配置重启」的根本差异。 |
| **jobs.events 分页** | ✅ 游标 exclusive、`next_from` 正确 | **必要**，大事件集与脚本/UI 分页的底座。但**需要先能发现 job_id**（见下）。 |
| **follow 实时流 + idle 加宽** | ✅ accepted→completed 窗口真实存在 | **在真实内核下刚需**（spawn/probe 数十秒）；simulated 下窗口亚秒、价值不明显，容易误判为多余。 |
| **follow --resume 断点续传** | ✅ resumed=true、零重印 | **同生命内断线重连刚需**；但**跨 daemon 重启失效**（事件内存态），价值当前被腰斩。 |
| **幂等键** | ✅ 同键同 job、新键新 job、缺键 exit 2 | **刚需**（CI/脚本重试不重复触发部署）。无可挑剔。 |
| **rollback 事务** | ✅ 铸 job、复活 snapshot | **刚需**。 |
| **gc-plan/gc 分离** | ✅ 计划只读、执行铸 job | **必要且设计正确**（破坏性操作先计划）。 |
| **doctor / support-bundle** | ✅ digest 校验、脱敏 | **运维刚需**。 |
| **角色授权（RBAC）** | ⚠️ wire 有效、CLI 够不到 | **方向必要、当前半成品**。没有 CLI `--role` + 认证，三角色在用户面不存在；要么补可达性，要么暂时别把它当已交付能力宣传。 |
| **崩溃恢复（状态面）** | ✅ active profile/snapshot 持久、scan clean | **刚需且生效**。 |
| **作业历史持久化 / jobs.list** | ❌ 重启即 `no such job`、无列表 | **当前缺口，且与 flow/审计定位直接冲突**。这是本轮实测暴露的最高优先级落差。 |

**一句话**：Job/事件/幂等/回滚/诊断这条事务主链是**真必要且已跑通**；flow 的实时与续传机制设计正确，但它的价值在两个地方被当前实现**架空**——(a) 作业历史不跨重启、(b) CLI 够不到角色分权。

---

## 4. 未来发展方向（按实测优先级排序）

> 排序原则：先补「让已建机制真正可用、可达」的落差，再扩面。不是去加新协议壳。

**P0 — 让作业历史可跨重启、可发现（补齐 flow/审计的地基）**

> **（R109 更新）第 2 项「`jobs.list` 发现面」已落地（R106）**：只读 `jobs.list` 操作与 `caly jobs`（无 id）列表（新→旧、daemon cap 64、Viewer 可读）。**第 1 项「作业事件跨重启持久化」已立 `ADR-057`（Accepted），切片 1（存储 primitive，R108）与切片 2（引擎终态写入 + 启动恢复，R109）已落地**：`caly-storage` 的 `JobLogStore`（终态 D3、Fs+Memory 双实现、坏记录重启点名拒绝、list newest-first）+ 引擎在 `mark_finished` 写终态记录、daemon `startup_recovery` 读回 `state.jobs`（真引擎+仿真盘 e2e 已钉「写→新开实例→jobs.list/follow 命中、保终态不重放、failure_code 跨重启在」）。**但真二进制端到端仍未闭环**——切片 3（GC root + support bundle + 留存回收）、切片 4（真二进制「写作业→kill -9→同 data-dir 重启→jobs.list/events/resume 命中」e2e）完成前，线上 daemon 重启后列表是否可查还缺最后一道真核验证。详见 `DEVELOPMENT_LOG_2026-08-31-round109.md` 与 `ADR-057 §5`。
1. **作业事件持久化**：把终态（理想含进行中）Job 的事件落进现有 `FsStore`/journal（存储底座已在，D0–D3 分级 ADR-014 已立），daemon 重启后 `caly job <id>` / `caly jobs <id>` 仍可查、`follow --resume` 可跨重启续传。这是把「过程可审计」从口号变事实的关键一步。
2. **新增 `jobs.list` 操作 + `caly jobs`（无 id）列表**：支持按状态/时间分页列出近期作业（带 retention 窗口），让人/UI **能发现** job_id，而不是只能靠 apply 的 stdout 记下。
3. 二者合起来，flow 才在「升级/崩溃/跨天」这些真场景闭环。

**P1 — 让角色分权在用户面可达**
4. CLI 增加 `--role viewer|operator|admin`（默认 viewer 更安全，写操作显式提权），并在 ADR-037 已预告的方向上补**认证/凭据**（否则角色是客户端自报、无防伪造意义）。先让只读监控可达，再谈认证强度。

**P2 — 把实时流的价值在真实内核下坐实并可测**
5. 用 `--effect-runtime real` + 钉死资产做一条「真核长部署 + 中途 attach follow + 杀 caly 重连续传」的 e2e 裁判（现在长窗口只在真核下出现，simulated 亚秒覆盖不到 resume 的时间维度）。
6. 明确 `follow --from` 非法/越界游标的退出码语义（越界 0 vs 非法是否该 14/2），让脚本能分辨「无新事件」与「游标错」。

**P3 — 收掉 ROADMAP §13#3 的协议生产化尾巴**
7. 共享 timeout scheduler、typed `send_request_frame`、多请求复用/递增 request_id、多流并发关联——这些是「一个客户端同时跟多个作业 / 一个连接发多个请求」（TUI 与批量脚本需要）的前提；当前单请求单流已够 CLI 串行用，但 TUI（Phase 9）会立刻撞上。

**P4 — 面向 TUI / 多观察者**
8. 等 P0 的 jobs.list + P3 的多流并发就位后，TUI 的 dashboard（connections/traffic/logs 多流同屏）才有地基；在此之前 TUI 应继续排在最后（`TUI_PLAN.md` 的纪律不变）。

**显式不因此改变的判断**：calyd 不自我守护（systemd 托管，ADR-055）、v1 不做完整 principal 认证体系（ADR-037，但 P1 的「角色可达 + 轻认证」是它的自然下一步而非违背）、不把内核做成独立 unit——这些在实测中都没有被推翻。

---

## 5. 复现方式

```bash
cargo build --bin calyd --bin caly
export PATH="$PWD/target/debug:$PATH"
D=$(mktemp -d); mkdir -p "$D/data"
calyd --data-dir "$D/data" --bind 127.0.0.1:0 --port-file "$D/port" >"$D/d.log" 2>&1 &
PORT=$(cat "$D/port"); A="127.0.0.1:$PORT"
caly apply demo-tun-profile --idempotency-key k1 --addr "$A"
caly job 1 --addr "$A"
caly follow 1 --addr "$A" 2>"$D/fe"          # stderr: stream 1 (resumed=false)
caly follow --resume 1 --addr "$A"           # 0 行、resumed=true
# 崩溃恢复：
kill -9 %1; calyd --data-dir "$D/data" --bind 127.0.0.1:0 --port-file "$D/port2" &
caly job 1 --addr "127.0.0.1:$(cat $D/port2)"   # 实测：refused (CONFLICT) no such job: 1
```

角色分权用裸 wire 客户端：帧 = `kind:u8 || len:u32 BE || body`，hello 帧 kind=1（body 含 `role=Viewer`），请求帧 kind=3（body 含 `operation=system.gc`），kind=5 回包即 REFUSAL（见 `caly_cli_e2e.rs` 顶部 oracle 注释）。
