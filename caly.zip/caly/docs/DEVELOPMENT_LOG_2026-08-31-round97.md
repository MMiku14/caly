# 开发日志 — 第九十七轮（R97）

- **日期**：2026-08-31
- **一句话**：follow 的 **opened 帧（REFUSAL 帧同理）补上 `request_id` 关联**——R94 只在一次性动词 `ask()` 关了「应答帧必须 request_id 匹配」，follow 打开帧是 follow 请求的直接应答、daemon 在其上回显 request_id，但 follow 臂 R95/R96 只校了 stream_id/resumed、漏校 request_id。同时把 follow 发请求的字面量 `1` 换成 R94 的命名常量 `REQUEST_ID`。
- **数字**：`cargo test --workspace` **842 → 846**（CLI 假 daemon e2e +3、arch 结构门禁 +1）；`TEST_FLOOR` 842 → **846**；clippy 去重源码位置 **31 持平**；fmt clean。

---

## 1. 靶子

量选沿整条 follow 会话逐帧过一遍（R94/R95/R96 都是「上轮划范围、这轮发现同形残留在隔壁帧」）：

- follow 打开请求 `session.send(WIRE_KIND_REQUEST, &request_payload(1, ..))` 带 request_id=1；
- 它的直接应答——opened 帧（`WIRE_KIND_RESPONSE`）——daemon 在其上回显 `request_id=response.request_id.0` + `stream_id` + `resumed`（`calyd.rs` WatchOpened 帧）；
- 但 `follow_stream` 的 opened 臂 R95（stream_id）/R96（resume stream_id + resumed flag）**都没读 request_id**。于是带合法流（stream_id=7、resumed 正常）但**外国/缺失 request_id**（999 或无记录）的 opened 帧会被当成本次 follow 的打开接受、进流模式打印。
- 另有符号漂移：follow 发请求用字面量 `1`，而 `ask()` 用 R94 命名常量 `REQUEST_ID`——发出值与校验值不是同一个符号（R94 规则②）。

v0 一连接一在途请求，外国 request_id 的 response 帧到达 = 错帧/困惑对端，与 R94 判定同形；且 daemon 本就回显 request_id，是客户端漏读内容、非协议缺字段。

## 2. 修复（`crates/caly-cli/src/bin/caly.rs`）

- follow 打开请求改经 `request_payload(REQUEST_ID, wire.name, ..)` 发出（与 `ask()` 同一常量）；
- opened 帧分支在 stream_id/resumed 处理**之前**解析 request_id：
  ```rust
  let opened_request_id = wire_field(&records, "request_id").and_then(|v| v.parse::<u64>().ok());
  if opened_request_id != Some(REQUEST_ID) { return Err(... "opened a stream for request id {..}, but this follow sent {REQUEST_ID} ... (PROTO_MISMATCH)"); }
  ```
- follow 路径 REFUSAL 帧（follow 请求的拒绝应答）同样校验 `refused_request_id != Some(REQUEST_ID)`；
- 流 DATA/END/ack 帧仍按 `stream_id` 关联（R95/96），不按 request_id（ack 确认帧 daemon 不回显 request_id）。

wire 形状零变更、daemon 零改动、无新依赖、无新 ADR。

## 3. 裁判

### 3.1 假 daemon e2e 三胎（36 → 39）

- `a_follow_opened_frame_with_a_foreign_request_id_is_refused`：opened 带合法流 7 但 `request_id=999`，随后正常推完流 7 → exit 13、不打印 FOREIGN-REQUEST-OPEN、stderr 点名 999。
- `a_follow_opened_frame_with_no_request_id_is_refused`：opened 带合法流 7 但**无** request_id 记录，随后推完 → exit 13（缺失 = None ≠ Some(1)）。
- `a_follow_opened_frame_with_the_sent_request_id_is_accepted`（反空转）：opened `request_id=1` + 流 7 正常推完 → exit 0 并打印。

**一个信号**：R97 加严后，R95/R96 的八个假 daemon follow 测试**立即全红**——它们的 opened 帧都没带 request_id（`b"stream_id=7\nresumed=false"`）。这说明那些测试一直在演真实 wire 上**不合法**的 opened 帧（真 daemon 总回显 request_id，所以真 daemon follow/resume e2e 全绿、无回归）。把八个 opened 帧统一补 `request_id=1` 前缀后全绿——补字段就是把假对端拉回真实协议。

### 3.2 结构门禁（19 → 20）

`the_cli_correlates_the_follow_opened_frame_by_its_request_id`：钉 follow 用 `request_payload(REQUEST_ID` 发出（非字面量 1）、opened 区（文档锚到 STREAM_DATA 臂之间）与 REFUSAL 臂各含 `Some(REQUEST_ID)` 真实比较。

## 4. 证伪（`scripts/falsify_round97.py`）

| 变异 | 改动 | 咬住 | 结果 |
|---|---|---|---|
| **M1** 删 opened 比较 | `if opened_request_id != Some(REQUEST_ID)` → `if false` | foreign-id + missing-id e2e 红（接受并跟流 exit 0）+ 门禁红；happy 仍绿 | **BIT** |
| **M2** 改比外国常量 | `Some(REQUEST_ID)` → `Some(999)` | happy e2e 红（正确 id=1 的 opened 被误拒）——证明校验值必须 = 发出值 | **BIT** |
| **M3** 接受缺失 id | 解析后 `.or(Some(REQUEST_ID))` | missing-id e2e 红（无 id 的 opened exit 0）；foreign-id 仍拒、happy 仍绿——证明缺失≠默认 | **BIT** |

## 5. 明确没做

- **多请求复用/递增 request_id**：仍 REQUEST_ID=1（v0 一连接一在途，每次动词新鲜握手）；多态化属 typed `send_request_frame`/共享 timeout scheduler §13#3 主体。
- **流 DATA/END/ack 帧不按 request_id 关联**：它们由 stream_id 关联（R95/96）；ack 确认帧 daemon 不回显 request_id。
- 不改 wire 帧形状、不改 daemon（daemon opened 帧本就回显 request_id）、无新依赖、无新 ADR。

至此「关联 id 必须在客户端校验、不能只信帧 kind」原则在五类帧上全部落地：握手协议/编码（R71）→ 一次性应答 request_id（R94）→ 流 DATA/END stream_id（R95）→ resume 与 ack 确认 stream_id（R96）→ follow 打开帧 request_id（R97）。

## 6. 收尾

- `regenerate_test_census.py` → `files=105 total=846 rows=105`；`--check` 一致。
- `scripts/check.sh`：`TEST_FLOOR` 842 → 846；clippy 基线 31 不动。
- 文档：STATUS §8.31（新；§8.30 历史 census 数字 837→842 保留）+ census 两行描述（dependency_direction 20 / caly_cli_e2e 39）、CENTERLINE/ROADMAP/ONBOARDING 数字 842→846；ONBOARDING §4.171（新）+ 处置表 6.123（新）、「不做」标题 6.123→6.124；本日志入 README 三索引。
- `falsify_round97.py` M1/M2/M3 全 BIT；`.r97bak` 收尾 sweep 干净。
