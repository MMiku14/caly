# Caly Documentation Guide

本目录是 Caly 的规范与工程文档入口。

Caly 的文档体系遵循一个原则：

> **架构结论先冻结，再进入代码实现；外部契约先冻结，再扩展内部实现。**

同时，当前工程阶段还要额外遵守：

> **实现排序优先围绕中心主链，而不是在外围协议壳反复盘旋。**

因此，`docs/` 下的文档分为两类：

- **Normative（规范性）**：定义必须遵守的边界、契约、协议与状态语义。
- **Informative（说明性）**：解释设计背景、推进顺序、当前状态与实施路径。

---

## 1. 目录结构

```text
docs/
├── README.md
├── FEATURES.md
├── GLOSSARY.md
├── STYLEGUIDE.md
├── ERRORS.md
├── EXIT_CODES.md
├── IMPLEMENTATION_STATUS.md
├── ONBOARDING_NOTES.md
├── DEVELOPMENT_LOG_2026-08-27.md
├── DEVELOPMENT_LOG_2026-08-30.md
├── DEVELOPMENT_LOG_2026-08-31.md
├── DEVELOPMENT_LOG_2026-08-31-round90.md
├── DEVELOPMENT_LOG_2026-08-31-round91.md
├── DEVELOPMENT_LOG_2026-08-31-round92.md
├── DEVELOPMENT_LOG_2026-08-31-round93.md
├── DEVELOPMENT_LOG_2026-08-31-round94.md
├── DEVELOPMENT_LOG_2026-08-31-round95.md
├── DEVELOPMENT_LOG_2026-08-31-round96.md
├── DEVELOPMENT_LOG_2026-08-31-round97.md
├── DEVELOPMENT_LOG_2026-08-31-round98.md
├── DEVELOPMENT_LOG_2026-08-31-round99.md
├── DEVELOPMENT_LOG_2026-08-31-round100.md
├── DEVELOPMENT_LOG_2026-08-31-round101.md
├── DEVELOPMENT_LOG_2026-08-31-round102.md
├── DEVELOPMENT_LOG_2026-08-31-round103.md
├── DEVELOPMENT_LOG_2026-08-31-round106.md
├── DEVELOPMENT_LOG_2026-08-31-round108.md
├── DEVELOPMENT_LOG_2026-08-31-round109.md
├── DEPLOYMENT_SYSTEMD.md
├── TUI_PLAN.md
├── ROADMAP.md
├── CONTINUATION_PLAYBOOK.md
├── ROBUSTNESS_GUIDE.md
├── CENTERLINE_PROGRESS.md
├── APPLY_EXECUTION_CENTERLINE.md
├── STORAGE_RECOVERY_EXECUTION_PLAN.md
├── CAPABILITY_VALIDATION_EXECUTION_PLAN.md
├── API_DTO_MIGRATION_PLAN.md
├── RFC_ADR_CRATE_INDEX.md
├── CORE_VERTICAL_SLICES.md
├── IPC_PROTOCOL_ANALYSIS.md
├── IPC_TRANSPORT_DECISION.md
├── IPC_SESSION_MODEL.md
├── IPC_JOB_FOLLOW_MODEL.md
├── IPC_STREAM_POLICY.md
├── IPC_IMPLEMENTATION_PLAN.md
├── IPC_LOOPBACK_HARNESS.md
├── APP_CLIENT_LAYER.md
├── REMOTE_FACADE_PARITY.md
├── TRANSPORT_RUNTIME_MODEL.md
├── OVERLOAD_AND_RETRY_MODEL.md
├── LOOPBACK_CONTRACTS.md
├── REDACTION_AND_SUPPORT_BUNDLE.md
├── SCENARIO_SUITE.md
├── JOB_FLOW_SCENARIO_REVIEW.md
├── rfcs/
└── adrs/
```

---

## 2. 推荐阅读顺序

> **无论哪种角色，想先快速知道「caly 现在能做什么、还差什么」都先读 `docs/FEATURES.md`（功能说明书）**，再按下面的角色路径深入。

### 2.1 架构读者

总入口：`docs/FEATURES.md`（功能面速查）。
1. `docs/rfcs/RFC-0001-core-architecture.md`
2. `docs/rfcs/RFC-0002-api-facade-ipc.md`
3. `docs/rfcs/RFC-0003-pipeline-provenance.md`
4. `docs/rfcs/RFC-0004-capability-coverage.md`
5. `docs/rfcs/RFC-0005-deployment-recovery.md`
6. `docs/rfcs/RFC-0006-io-port-iofault.md`
7. `docs/rfcs/RFC-0007-storage-cas-snapshot.md`
8. `docs/rfcs/RFC-0008-runtimedriver-telemetry.md`
9. `docs/rfcs/RFC-0009-profile-patch-override.md`
10. `docs/rfcs/RFC-0010-security-secret-redaction.md`
11. `docs/CENTERLINE_PROGRESS.md`
12. `docs/APPLY_EXECUTION_CENTERLINE.md`
13. `docs/STORAGE_RECOVERY_EXECUTION_PLAN.md`
14. `docs/CAPABILITY_VALIDATION_EXECUTION_PLAN.md`
15. `docs/API_DTO_MIGRATION_PLAN.md`
16. `docs/RFC_ADR_CRATE_INDEX.md`
17. `docs/CORE_VERTICAL_SLICES.md`
18. `docs/IPC_PROTOCOL_ANALYSIS.md`
19. `docs/IPC_TRANSPORT_DECISION.md`
20. `docs/IPC_SESSION_MODEL.md`
21. `docs/IPC_JOB_FOLLOW_MODEL.md`
22. `docs/IPC_STREAM_POLICY.md`
23. `docs/IPC_IMPLEMENTATION_PLAN.md`
24. `docs/IPC_LOOPBACK_HARNESS.md`
25. `docs/APP_CLIENT_LAYER.md`
26. `docs/REMOTE_FACADE_PARITY.md`
27. `docs/TRANSPORT_RUNTIME_MODEL.md`
28. `docs/OVERLOAD_AND_RETRY_MODEL.md`
29. `docs/LOOPBACK_CONTRACTS.md`
30. `docs/SCENARIO_SUITE.md`
31. `docs/REDACTION_AND_SUPPORT_BUNDLE.md`
32. `docs/adrs/README.md`
33. `docs/GLOSSARY.md`
34. `docs/STYLEGUIDE.md`
35. `docs/ROBUSTNESS_GUIDE.md`
36. `docs/IMPLEMENTATION_STATUS.md`
37. `docs/ROADMAP.md`

### 2.2 编译链路实现者

1. `docs/CENTERLINE_PROGRESS.md`
2. `docs/APPLY_EXECUTION_CENTERLINE.md`
3. `docs/STORAGE_RECOVERY_EXECUTION_PLAN.md`
4. `docs/CAPABILITY_VALIDATION_EXECUTION_PLAN.md`
5. `docs/API_DTO_MIGRATION_PLAN.md`
6. `docs/RFC_ADR_CRATE_INDEX.md`
7. `docs/CORE_VERTICAL_SLICES.md`
8. `docs/rfcs/RFC-0003-pipeline-provenance.md`
9. `docs/rfcs/RFC-0004-capability-coverage.md`
10. `docs/rfcs/RFC-0005-deployment-recovery.md`
11. `docs/rfcs/RFC-0007-storage-cas-snapshot.md`
12. `docs/rfcs/RFC-0009-profile-patch-override.md`
13. `docs/ROBUSTNESS_GUIDE.md`

### 2.3 前端/交互实现者

1. `docs/rfcs/RFC-0002-api-facade-ipc.md`
2. `docs/API_DTO_MIGRATION_PLAN.md`
3. `docs/IPC_PROTOCOL_ANALYSIS.md`
4. `docs/IPC_TRANSPORT_DECISION.md`
5. `docs/IPC_SESSION_MODEL.md`
6. `docs/IPC_JOB_FOLLOW_MODEL.md`
7. `docs/IPC_STREAM_POLICY.md`
8. `docs/IPC_IMPLEMENTATION_PLAN.md`
9. `docs/IPC_LOOPBACK_HARNESS.md`
10. `docs/APP_CLIENT_LAYER.md`
11. `docs/REMOTE_FACADE_PARITY.md`
12. `docs/OVERLOAD_AND_RETRY_MODEL.md`
13. `docs/LOOPBACK_CONTRACTS.md`
14. `docs/SCENARIO_SUITE.md`
15. `docs/ERRORS.md`
16. `docs/EXIT_CODES.md`

### 2.4 部署/平台实现者

1. `docs/rfcs/RFC-0005-deployment-recovery.md`
2. `docs/rfcs/RFC-0007-storage-cas-snapshot.md`
3. `docs/APPLY_EXECUTION_CENTERLINE.md`
4. `docs/STORAGE_RECOVERY_EXECUTION_PLAN.md`
5. `docs/OVERLOAD_AND_RETRY_MODEL.md`
6. `docs/rfcs/RFC-0006-io-port-iofault.md`
7. `docs/rfcs/RFC-0010-security-secret-redaction.md`
8. `docs/ROBUSTNESS_GUIDE.md`

### 2.5 工程管理 / 实施推进

先看功能面总盘点：`docs/FEATURES.md`（各功能状态 Done·Partial·Planned + 已知缺口）。
1. `docs/CONTINUATION_PLAYBOOK.md`（怎么接续：每轮流程、数字纪律、证伪规程、门禁清单）
2. `docs/IMPLEMENTATION_STATUS.md`
3. `docs/ONBOARDING_NOTES.md`
4. `docs/ROADMAP.md`（§1bis 是按阶段量的完成度）
5. `docs/CENTERLINE_PROGRESS.md`
6. `docs/APPLY_EXECUTION_CENTERLINE.md`
7. `docs/STORAGE_RECOVERY_EXECUTION_PLAN.md`
8. `docs/CAPABILITY_VALIDATION_EXECUTION_PLAN.md`
9. `docs/API_DTO_MIGRATION_PLAN.md`
10. `docs/RFC_ADR_CRATE_INDEX.md`
11. `docs/REDACTION_AND_SUPPORT_BUNDLE.md`
12. `docs/REMOTE_FACADE_PARITY.md`
13. `docs/SCENARIO_SUITE.md`
14. `docs/ROBUSTNESS_GUIDE.md`

---

## 3. 规范文档分工

| 文档 | 类型 | 作用 |
|---|---|---|
| `FEATURES.md` | Informative + Feature Reference | **功能说明书（第一入口）**：逐功能回答「为什么需要 / 面向什么需求 / 现在什么状态（Done·Partial·Planned，可由树复算）」，附 CLI 命令速查、已知缺口与「显式不做」清单；想知道 caly 现在能做什么先读它 |
| `RFC-0001-core-architecture.md` | Normative | 总体架构边界、依赖方向、不变量、状态模型与实施顺序 |
| `RFC-0002-api-facade-ipc.md` | Normative | Facet、Operation、Query/Command/Stream、Job、IPC、错误门面 |
| `RFC-0003-pipeline-provenance.md` | Normative | Stage、DAG、CacheKey、Provenance、Diagnostics、决定性要求 |
| `RFC-0004-capability-coverage.md` | Normative | Capability Registry、Support Level、Evidence、Coverage Matrix |
| `RFC-0005-deployment-recovery.md` | Normative | ApplyPlan、EffectPlan、Rollback、OSJournal、Recovery、Privilege 边界 |
| `RFC-0006-io-port-iofault.md` | Normative | IO Port、IoFault、VPath、Ctx 传播、统一 IO 边界 |
| `RFC-0007-storage-cas-snapshot.md` | Normative | Storage、CAS、Revision、Snapshot、Journal、GC、迁移 |
| `RFC-0008-runtimedriver-telemetry.md` | Normative | RuntimeDriver、Telemetry、Probe、统一 RuntimeView |
| `RFC-0009-profile-patch-override.md` | Normative | Patch/Override/Selector/Native Patch 边界 |
| `RFC-0010-security-secret-redaction.md` | Normative | Security、Secret、Redaction、Support Bundle、下载与通信安全 |
| `CENTERLINE_PROGRESS.md` | Informative + Engineering | 中心主链当前已经接到哪一步 |
| `APPLY_EXECUTION_CENTERLINE.md` | Informative + Engineering | 从 ApplyPlan/EffectPlan 到 Executor/Snapshot/Recovery 的推进基线 |
| `STORAGE_RECOVERY_EXECUTION_PLAN.md` | Informative + Engineering | storage 如何成为 apply/recovery 的事务底座 |
| `CAPABILITY_VALIDATION_EXECUTION_PLAN.md` | Informative + Engineering | capability 如何进入真正的执行链与 apply gate |
| `API_DTO_MIGRATION_PLAN.md` | Informative + Engineering | `operation.rs` 瘦身与 DTO 分面迁移计划 |
| `RFC_ADR_CRATE_INDEX.md` | Informative + Engineering | RFC / ADR / crate 的交叉索引 |
| `CORE_VERTICAL_SLICES.md` | Informative + Engineering | mihomo / sing-box / mock adapter 的 vertical slice 推进策略 |
| `IPC_PROTOCOL_ANALYSIS.md` | Informative + Engineering | 协议现状、风险点、协商/重放/Reset/ACK 分析 |
| `IPC_TRANSPORT_DECISION.md` | Informative + Decision Support | gRPC vs HTTP+JSON vs framed JSON 的选择结论 |
| `IPC_SESSION_MODEL.md` | Informative + Engineering | Hello/HelloAck 之后的 session state machine |
| `IPC_JOB_FOLLOW_MODEL.md` | Informative + Engineering | Job follow、event index、reset/replay 行为 |
| `IPC_STREAM_POLICY.md` | Informative + Engineering | stream delivery/ack/reset/replay 策略 |
| `IPC_IMPLEMENTATION_PLAN.md` | Informative + Engineering | IPC 从 skeleton 到 runtime 的实施顺序 |
| `APP_CLIENT_LAYER.md` | Informative + Engineering | local/remote client 组装层职责 |
| `REMOTE_FACADE_PARITY.md` | Informative + Engineering | local/remote façade parity 推进状态 |
| `OVERLOAD_AND_RETRY_MODEL.md` | Informative + Engineering | overload/backpressure 的公开表达与 retry hint |
| `LOOPBACK_CONTRACTS.md` | Informative + Engineering | loopback contract 的验证层次 |
| `SCENARIO_SUITE.md` | Informative + Engineering | scenario bundle 的组合策略 |
| `JOB_FLOW_SCENARIO_REVIEW.md` | Informative + Engineering | 用真二进制跑通一个依赖 Job/Flow 的网关「部署日」场景，实测观察 + 据此重估功能必要性与未来方向（含两处落差：作业历史不跨重启、CLI 够不到角色分权） |
| `REDACTION_AND_SUPPORT_BUNDLE.md` | Engineering | `RFC-0010` 脱敏边界的落点、support bundle 内容与 `§14` 门禁↔测试映射 |
| `IMPLEMENTATION_STATUS.md` | Informative + Process | 当前实现盘点、阶段状态与阻塞项 |
| `ONBOARDING_NOTES.md` | Informative + Audit | 接手过程中遇到的文档/代码偏差、结构坑与已修缺陷留档 |
| `DEVELOPMENT_LOG_2026-08-27.md` | Informative + Log | 历史接续开发的改动、验证结果与未尽事项 |
| `DEVELOPMENT_LOG_2026-08-30.md` | Informative + Log | durable source index/provenance、caller phase-boundary control、durable source inspection 与 `calyd` 真实 effect runtime 显式组合接入轮次的改动、验证结果与未尽事项 |
| `DEVELOPMENT_LOG_2026-08-31.md` | Informative + Log | 第八十八轮环境接手（工具链/钉死资产重建）与第八十九轮生产 CLI 全会话走共享 `FramePump`（关闭写半无超时面）的改动、证伪与未尽事项 |
| `DEVELOPMENT_LOG_2026-08-31-round90.md` | Informative + Log | 第九十轮 daemon 服务端写半对称期限（`set_transport_deadlines` read+write 同点、进程内 socket-pair 确定性裁判）的改动、证伪与未尽事项 |
| `DEVELOPMENT_LOG_2026-08-31-round91.md` | Informative + Log | 第九十一轮 follow 流静默期限（opened 后 `set_idle` 双向加宽到 30s）与 `FramePump::recv` 探活 peek 不借用读预算（50ms 短窗口后恢复）两处叠加缺陷的改动、证伪（4s 静默间隙 e2e + 期限调用序列单测 + 结构门禁）与未尽事项 |
| `DEVELOPMENT_LOG_2026-08-31-round92.md` | Informative + Log | 第九十二轮安全面：线端 daemon 请求信封的角色取自 hello 协商（`DaemonTransport::peer_role()`）而非硬编码 Admin（修 Operator 远端客户端对 Admin-only 命令静默提权），改动、正反双胎 wire e2e + 结构门禁、证伪（含一条"结构绿、行为红"变异）与未尽事项（principal/凭据层不做） |
| `DEVELOPMENT_LOG_2026-08-31-round93.md` | Informative + Log | 第九十三轮安全面（R92 同族 fail-open）：hello 角色在信任边界 fail-closed 解析（`server_hello_role` 未知按名拒绝、缺失降为 Viewer、覆盖 lenient Admin 默认），改动、dialect 单测 + wire e2e + 结构门禁、证伪（含"缺失默认安全"半条变异）与未尽事项 |
| `DEVELOPMENT_LOG_2026-08-31-round94.md` | Informative + Log | 第九十四轮：CLI 校验回包 `request_id` 与发出请求关联（foreign id / 缺失 id 即 PROTO_MISMATCH exit 13，正确 id 才当答案），假 daemon 三胎 e2e + 结构门禁、证伪与未尽事项（多请求 request_id 多态化属 §13#3） |
| `DEVELOPMENT_LOG_2026-08-31-round95.md` | Informative + Log | 第九十五轮：CLI follow 流校验 DATA/END 帧 `stream_id` 等于 opened 帧命名的流（别流事件不打印、别流 END 的 outcome 不定退出码，不符即 PROTO_MISMATCH exit 13），假 daemon follow 三胎 e2e + 结构门禁（接受路径恰好一条）、证伪与未尽事项（多流并发属 typed loop streams 表生产化 §13#3 主体） |
| `DEVELOPMENT_LOG_2026-08-31-round96.md` | Informative + Log | 第九十六轮：CLI follow 的 resume 核对 opened 流 id 与 resumed 标志、ack 确认帧核对 stream_id（不符即 PROTO_MISMATCH exit 13），假 daemon 四胎 e2e + 结构门禁、证伪三半各咬一半，及被拒裁判须演完 happy 后续防假绿的测试设计留档 |
| `DEVELOPMENT_LOG_2026-08-31-round97.md` | Informative + Log | 第九十七轮：CLI follow 的 opened/refusal 帧补 request_id 关联（R94 应答关联只覆盖 ask() 的残留），follow 改用 REQUEST_ID 常量发出，假 daemon 三胎 e2e + 结构门禁、证伪三变异全 BIT，及「给假 daemon 补 wire 字段一片变红=它们一直在演不合法帧」的留档 |
| `DEVELOPMENT_LOG_2026-08-31-round98.md` | Informative + Log | 第九十八轮：CLI 把 daemon REFUSAL 的稳定公共码映射到 EXIT_CODES.md 文档退出码（PERMISSION→8 等，不再一律 13；帧层/未知码回落 13），单测+假 daemon 三胎+结构门禁、证伪三变异全 BIT |
| `DEVELOPMENT_LOG_2026-08-31-round99.md` | Informative + Log | 第九十九轮：一次性 `caly job <id>`（jobs.follow 查询）失败作业按响应里已携带的 failure_code 映射退出码（PERMISSION→8、STORAGE→10 等，不再打印失败码却 exit 0；空/缺=未失败 exit 0；--json 同），复用 R98 公共码表；单测+假 daemon 三胎+结构门禁（体内断言）、证伪三变异全 BIT |
| `DEVELOPMENT_LOG_2026-08-31-round100.md` | Normative + Log | 第一百轮：systemd 托管 calyd（ADR-055，部署工件不改 Rust）——交付 packaging/systemd/calyd.service + DEPLOYMENT_SYSTEMD.md + ADR-055，钉死两层监督：systemd 管 calyd 进程（Type=simple+Restart=on-failure+journald、calyd 不自我守护），calyd 继续管 mihomo/sing-box 子进程（禁做成独立 unit，会切断 apply 事务）；real 显式 opt-in、UDS、崩溃恢复承接重启；测试 856 持平 |
| `DEVELOPMENT_LOG_2026-08-31-round101.md` | Normative + Log | 第一百零一轮：给 R100 的 systemd unit 补内容裁判门禁（dependency_direction +1，857）——读 calyd.service 钉 Type=simple/Restart/enable、ExecStart 旗标全在 calyd 白名单、real+runtime-root+assets-dir 齐、UDS unix:/run/calyd、ExecStart* 指令不得含 mihomo/sing-box（两层边界 ADR-055）；证伪 M1 撤 Restart/M2 real→simulated/M3 ExecStartPre 直拉核心 全 BIT；SIGTERM 优雅关停记为 ADR-056 方向跨轮大活 |
| `DEVELOPMENT_LOG_2026-08-31-round102.md` | Normative + Log | 第一百零二轮（ADR-056）：calyd 捕获 SIGTERM/SIGINT 优雅关停——主线程 pthread_sigmask 阻塞 TERM/INT、waiter 线程 sigwait 收信号后 StdEffectRuntime::shutdown(10s) 优雅停核撤路由再 exit 0（systemctl stop 不再硬杀核心进崩溃恢复）；手写最小 FFI（不引 libc/信号 crate、unsafe 局部封装、模块放 bin/support 经 #[path] 引入）；集成裁判发真 SIGTERM 断言 exit 0 非 signal 15 + 结构门禁；证伪 M1/M2 全 BIT；857→859 |
| `DEVELOPMENT_LOG_2026-08-31-round103.md` | Normative + Log | 第一百零三轮：`caly follow --json` 结束帧退出码按 verdict 映射——json 分支曾打印后无条件 exit 0 不读 outcome（人类 records 分支早已 Failed→1/Cancelled→15/TimedOut→11），失败作业用 --json 跟流也报成功；抽共享 stream_end_exit_code、两形态统一走判决（--json 不改退出码语义，EXIT_CODES §1.4）；假 daemon json 两胎（Failed→1/Succeeded→0 反空转）+ 结构门禁（json 打印点到共享判决间禁提前 return，专咬死代码绕过）；证伪 M1/M2 全 BIT；859→862 |
| `DEVELOPMENT_LOG_2026-08-31-round106.md` | Normative + Log | 第一百零六轮：部署作业发现面 `jobs.list`（R105 场景重估 P0 半截）——新增只读 query 贯通 engine/api/daemon/ipc/cli，`caly jobs` 无 id 列作业（新→旧、有界 cap 64）、`<id>` 仍分页事件；engine 单测 2 + 真二进制 e2e + wire roundtrip + 结构门禁，证伪 M1–M4 全 BIT；两测试设计坑（变异要打真实路径分支、列表首字段不得前导填充）；862→866 |
| `DEPLOYMENT_SYSTEMD.md` | Normative + Ops | systemd 托管 `calyd` 的部署 runbook（第一百轮，ADR-055）：两层监督边界（systemd 管 calyd 进程、calyd 管 mihomo/sing-box 子进程，勿把核心做成独立 unit）、文件布局、安装启用、UDS 连接、journald 日志、simulated 变体、关停/崩溃恢复语义、权限加固、非 Linux（launchd/SCM/容器）说明与排障 |
| `TUI_PLAN.md` | Informative + Planned | Phase 9 `caly-tui` 规划（未实现）：定位为 calyd 的又一个 wire 客户端、非目标、依赖边界、屏↔op 映射、T0–T5 里程碑与实现前须先有的 ADR（渲染栈/数据通路）；ROADMAP 把 TUI 排最后 |
| `ROADMAP.md` | Informative + Process | 建议实施路线与里程碑定义，含 §1bis 按阶段量的完成度与阻塞点 |
| `CONTINUATION_PLAYBOOK.md` | Informative + Process | 接续开发的工作流程：数字纪律、证伪规程、文档手术规程、现有门禁清单 |
| `ROBUSTNESS_GUIDE.md` | Informative + Engineering | 健壮性优先策略与高级技巧 |

---

## 4. 当前最关键的阅读组合

如果只看最关键的七份文档，建议按这个顺序：

1. `docs/rfcs/RFC-0001-core-architecture.md`
2. `docs/CENTERLINE_PROGRESS.md`
3. `docs/APPLY_EXECUTION_CENTERLINE.md`
4. `docs/STORAGE_RECOVERY_EXECUTION_PLAN.md`
5. `docs/CAPABILITY_VALIDATION_EXECUTION_PLAN.md`
6. `docs/API_DTO_MIGRATION_PLAN.md`
7. `docs/ROADMAP.md`

这七份足以回答：

- Caly 的中心是什么
- 目前中心线接到了哪里
- 后半截 apply/recovery 怎么补
- capability 决策怎么变成真正 gate
- API 结构债该怎么还
- 下一步代码优先级是什么

---

## 5. 哪些文档是“权威来源”

文档的权威级别如下：

1. **RFC**：对架构边界与外部契约具有最高优先级。
2. **ADR**：记录为什么做出某项架构决策。
3. **工程执行文档**：说明当前状态、实施顺序与具体推进路径，但不得推翻 RFC/ADR。
4. **实现代码注释**：只能细化 RFC/ADR，不得推翻 RFC。
5. **Issue / PR 描述**：仅用于讨论，不构成正式规范。

`ONBOARDING_NOTES.md` 与 `DEVELOPMENT_LOG_*.md` 属于**审计与过程记录**，
不进入上面的权威链；它们可以指出“文档与代码不一致”，但不能替代 RFC/ADR 的结论。

若出现冲突：

```text
RFC > ADR > Engineering Docs > Code Comment > Issue/PR text
```

---

## 6. 当前文档体系的阶段

当前文档体系已覆盖：

- **功能说明书**（`FEATURES.md`：逐功能的「为什么需要 / 面向什么需求 / 现在什么状态」，新人与量选的第一入口）
- 总体架构
- API / IPC
- Pipeline / Provenance
- Capability / Coverage
- Deployment / Recovery
- IO Port / IoFault
- Storage / CAS / Snapshot
- RuntimeDriver / Telemetry
- Profile Patch / Override
- Security / Secret / Redaction
- 中心主链进度
- apply execution 主链推进基线
- storage/recovery 接线计划
- capability validation 执行计划
- API DTO 迁移计划
- RFC/ADR/crate 交叉索引
- core vertical slices
- IPC transport / session / follow / stream / loopback
- app client layer / local-remote parity / scenario / contract
- overload/retry
- 实施状态与路线图
- 健壮性与高级实现技巧
- 接手审计与开发留档（`ONBOARDING_NOTES.md` / `DEVELOPMENT_LOG_2026-08-27.md` / `DEVELOPMENT_LOG_2026-08-30.md` / `DEVELOPMENT_LOG_2026-08-31.md` / `DEVELOPMENT_LOG_2026-08-31-round90.md` / `DEVELOPMENT_LOG_2026-08-31-round91.md` / `DEVELOPMENT_LOG_2026-08-31-round92.md` / `DEVELOPMENT_LOG_2026-08-31-round93.md` / `DEVELOPMENT_LOG_2026-08-31-round94.md` / `DEVELOPMENT_LOG_2026-08-31-round95.md` / `DEVELOPMENT_LOG_2026-08-31-round96.md` / `DEVELOPMENT_LOG_2026-08-31-round97.md` / `DEVELOPMENT_LOG_2026-08-31-round98.md` / `DEVELOPMENT_LOG_2026-08-31-round99.md` / `DEVELOPMENT_LOG_2026-08-31-round100.md` / `DEVELOPMENT_LOG_2026-08-31-round101.md` / `DEVELOPMENT_LOG_2026-08-31-round102.md` / `DEVELOPMENT_LOG_2026-08-31-round103.md` / `DEVELOPMENT_LOG_2026-08-31-round106.md`）
- 本地质量门禁入口 `scripts/check.sh`（以及生成 `IMPLEMENTATION_STATUS.md §3.3` 实测表的
  `scripts/regenerate_test_census.py`，`--check` 只报不改）

也就是说，Caly 的文档现在已经不只是“总体设计稿”，而是开始具备**面向当前实现推进的中心化工程导航**。

---

## 7. 一句话导航

如果只记一条：

> **想知道「caly 现在能做什么、还差什么」先看 `FEATURES.md`；定边界看 RFC，定推进顺序看 centerline/apply/storage/capability/API 迁移文档，落地实现看 IPC、parity、scenario 和 roadmap。**
