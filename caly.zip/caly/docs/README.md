# Caly Documentation Guide

本目录是 Caly 的规范与工程文档入口。

Caly 的文档体系遵循一个原则：

> **架构结论先冻结，再进入代码实现；外部契约先冻结，再扩展内部实现。**

同时，当前工程阶段还要额外遵守：

> **实现排序优先围绕中心主链，而不是在外围协议壳反复盘旋。**

因此，`docs/` 下的文档分为两类：

- **Normative（规范性）**：定义必须遵守的边界、契约、协议与状态语义。
- **Informative（说明性）**：解释设计背景、推进顺序、当前状态与实施路径。

---

## 1. 目录结构

```text
docs/
├── README.md
├── GLOSSARY.md
├── STYLEGUIDE.md
├── ERRORS.md
├── EXIT_CODES.md
├── IMPLEMENTATION_STATUS.md
├── ONBOARDING_NOTES.md
├── DEVELOPMENT_LOG_2026-08-27.md
├── ROADMAP.md
├── CONTINUATION_PLAYBOOK.md
├── ROBUSTNESS_GUIDE.md
├── CENTERLINE_PROGRESS.md
├── APPLY_EXECUTION_CENTERLINE.md
├── STORAGE_RECOVERY_EXECUTION_PLAN.md
├── CAPABILITY_VALIDATION_EXECUTION_PLAN.md
├── API_DTO_MIGRATION_PLAN.md
├── RFC_ADR_CRATE_INDEX.md
├── CORE_VERTICAL_SLICES.md
├── IPC_PROTOCOL_ANALYSIS.md
├── IPC_TRANSPORT_DECISION.md
├── IPC_SESSION_MODEL.md
├── IPC_JOB_FOLLOW_MODEL.md
├── IPC_STREAM_POLICY.md
├── IPC_IMPLEMENTATION_PLAN.md
├── IPC_LOOPBACK_HARNESS.md
├── APP_CLIENT_LAYER.md
├── REMOTE_FACADE_PARITY.md
├── TRANSPORT_RUNTIME_MODEL.md
├── OVERLOAD_AND_RETRY_MODEL.md
├── LOOPBACK_CONTRACTS.md
├── REDACTION_AND_SUPPORT_BUNDLE.md
├── SCENARIO_SUITE.md
├── rfcs/
└── adrs/
```

---

## 2. 推荐阅读顺序

### 2.1 架构读者

1. `docs/rfcs/RFC-0001-core-architecture.md`
2. `docs/rfcs/RFC-0002-api-facade-ipc.md`
3. `docs/rfcs/RFC-0003-pipeline-provenance.md`
4. `docs/rfcs/RFC-0004-capability-coverage.md`
5. `docs/rfcs/RFC-0005-deployment-recovery.md`
6. `docs/rfcs/RFC-0006-io-port-iofault.md`
7. `docs/rfcs/RFC-0007-storage-cas-snapshot.md`
8. `docs/rfcs/RFC-0008-runtimedriver-telemetry.md`
9. `docs/rfcs/RFC-0009-profile-patch-override.md`
10. `docs/rfcs/RFC-0010-security-secret-redaction.md`
11. `docs/CENTERLINE_PROGRESS.md`
12. `docs/APPLY_EXECUTION_CENTERLINE.md`
13. `docs/STORAGE_RECOVERY_EXECUTION_PLAN.md`
14. `docs/CAPABILITY_VALIDATION_EXECUTION_PLAN.md`
15. `docs/API_DTO_MIGRATION_PLAN.md`
16. `docs/RFC_ADR_CRATE_INDEX.md`
17. `docs/CORE_VERTICAL_SLICES.md`
18. `docs/IPC_PROTOCOL_ANALYSIS.md`
19. `docs/IPC_TRANSPORT_DECISION.md`
20. `docs/IPC_SESSION_MODEL.md`
21. `docs/IPC_JOB_FOLLOW_MODEL.md`
22. `docs/IPC_STREAM_POLICY.md`
23. `docs/IPC_IMPLEMENTATION_PLAN.md`
24. `docs/IPC_LOOPBACK_HARNESS.md`
25. `docs/APP_CLIENT_LAYER.md`
26. `docs/REMOTE_FACADE_PARITY.md`
27. `docs/TRANSPORT_RUNTIME_MODEL.md`
28. `docs/OVERLOAD_AND_RETRY_MODEL.md`
29. `docs/LOOPBACK_CONTRACTS.md`
30. `docs/SCENARIO_SUITE.md`
31. `docs/REDACTION_AND_SUPPORT_BUNDLE.md`
32. `docs/adrs/README.md`
33. `docs/GLOSSARY.md`
34. `docs/STYLEGUIDE.md`
35. `docs/ROBUSTNESS_GUIDE.md`
36. `docs/IMPLEMENTATION_STATUS.md`
37. `docs/ROADMAP.md`

### 2.2 编译链路实现者

1. `docs/CENTERLINE_PROGRESS.md`
2. `docs/APPLY_EXECUTION_CENTERLINE.md`
3. `docs/STORAGE_RECOVERY_EXECUTION_PLAN.md`
4. `docs/CAPABILITY_VALIDATION_EXECUTION_PLAN.md`
5. `docs/API_DTO_MIGRATION_PLAN.md`
6. `docs/RFC_ADR_CRATE_INDEX.md`
7. `docs/CORE_VERTICAL_SLICES.md`
8. `docs/rfcs/RFC-0003-pipeline-provenance.md`
9. `docs/rfcs/RFC-0004-capability-coverage.md`
10. `docs/rfcs/RFC-0005-deployment-recovery.md`
11. `docs/rfcs/RFC-0007-storage-cas-snapshot.md`
12. `docs/rfcs/RFC-0009-profile-patch-override.md`
13. `docs/ROBUSTNESS_GUIDE.md`

### 2.3 前端/交互实现者

1. `docs/rfcs/RFC-0002-api-facade-ipc.md`
2. `docs/API_DTO_MIGRATION_PLAN.md`
3. `docs/IPC_PROTOCOL_ANALYSIS.md`
4. `docs/IPC_TRANSPORT_DECISION.md`
5. `docs/IPC_SESSION_MODEL.md`
6. `docs/IPC_JOB_FOLLOW_MODEL.md`
7. `docs/IPC_STREAM_POLICY.md`
8. `docs/IPC_IMPLEMENTATION_PLAN.md`
9. `docs/IPC_LOOPBACK_HARNESS.md`
10. `docs/APP_CLIENT_LAYER.md`
11. `docs/REMOTE_FACADE_PARITY.md`
12. `docs/OVERLOAD_AND_RETRY_MODEL.md`
13. `docs/LOOPBACK_CONTRACTS.md`
14. `docs/SCENARIO_SUITE.md`
15. `docs/ERRORS.md`
16. `docs/EXIT_CODES.md`

### 2.4 部署/平台实现者

1. `docs/rfcs/RFC-0005-deployment-recovery.md`
2. `docs/rfcs/RFC-0007-storage-cas-snapshot.md`
3. `docs/APPLY_EXECUTION_CENTERLINE.md`
4. `docs/STORAGE_RECOVERY_EXECUTION_PLAN.md`
5. `docs/OVERLOAD_AND_RETRY_MODEL.md`
6. `docs/rfcs/RFC-0006-io-port-iofault.md`
7. `docs/rfcs/RFC-0010-security-secret-redaction.md`
8. `docs/ROBUSTNESS_GUIDE.md`

### 2.5 工程管理 / 实施推进

1. `docs/CONTINUATION_PLAYBOOK.md`（怎么接续：每轮流程、数字纪律、证伪规程、门禁清单）
2. `docs/IMPLEMENTATION_STATUS.md`
3. `docs/ONBOARDING_NOTES.md`
4. `docs/ROADMAP.md`（§1bis 是按阶段量的完成度）
5. `docs/CENTERLINE_PROGRESS.md`
6. `docs/APPLY_EXECUTION_CENTERLINE.md`
7. `docs/STORAGE_RECOVERY_EXECUTION_PLAN.md`
8. `docs/CAPABILITY_VALIDATION_EXECUTION_PLAN.md`
9. `docs/API_DTO_MIGRATION_PLAN.md`
10. `docs/RFC_ADR_CRATE_INDEX.md`
11. `docs/REDACTION_AND_SUPPORT_BUNDLE.md`
12. `docs/REMOTE_FACADE_PARITY.md`
13. `docs/SCENARIO_SUITE.md`
14. `docs/ROBUSTNESS_GUIDE.md`

---

## 3. 规范文档分工

| 文档 | 类型 | 作用 |
|---|---|---|
| `RFC-0001-core-architecture.md` | Normative | 总体架构边界、依赖方向、不变量、状态模型与实施顺序 |
| `RFC-0002-api-facade-ipc.md` | Normative | Facet、Operation、Query/Command/Stream、Job、IPC、错误门面 |
| `RFC-0003-pipeline-provenance.md` | Normative | Stage、DAG、CacheKey、Provenance、Diagnostics、决定性要求 |
| `RFC-0004-capability-coverage.md` | Normative | Capability Registry、Support Level、Evidence、Coverage Matrix |
| `RFC-0005-deployment-recovery.md` | Normative | ApplyPlan、EffectPlan、Rollback、OSJournal、Recovery、Privilege 边界 |
| `RFC-0006-io-port-iofault.md` | Normative | IO Port、IoFault、VPath、Ctx 传播、统一 IO 边界 |
| `RFC-0007-storage-cas-snapshot.md` | Normative | Storage、CAS、Revision、Snapshot、Journal、GC、迁移 |
| `RFC-0008-runtimedriver-telemetry.md` | Normative | RuntimeDriver、Telemetry、Probe、统一 RuntimeView |
| `RFC-0009-profile-patch-override.md` | Normative | Patch/Override/Selector/Native Patch 边界 |
| `RFC-0010-security-secret-redaction.md` | Normative | Security、Secret、Redaction、Support Bundle、下载与通信安全 |
| `CENTERLINE_PROGRESS.md` | Informative + Engineering | 中心主链当前已经接到哪一步 |
| `APPLY_EXECUTION_CENTERLINE.md` | Informative + Engineering | 从 ApplyPlan/EffectPlan 到 Executor/Snapshot/Recovery 的推进基线 |
| `STORAGE_RECOVERY_EXECUTION_PLAN.md` | Informative + Engineering | storage 如何成为 apply/recovery 的事务底座 |
| `CAPABILITY_VALIDATION_EXECUTION_PLAN.md` | Informative + Engineering | capability 如何进入真正的执行链与 apply gate |
| `API_DTO_MIGRATION_PLAN.md` | Informative + Engineering | `operation.rs` 瘦身与 DTO 分面迁移计划 |
| `RFC_ADR_CRATE_INDEX.md` | Informative + Engineering | RFC / ADR / crate 的交叉索引 |
| `CORE_VERTICAL_SLICES.md` | Informative + Engineering | mihomo / sing-box / mock adapter 的 vertical slice 推进策略 |
| `IPC_PROTOCOL_ANALYSIS.md` | Informative + Engineering | 协议现状、风险点、协商/重放/Reset/ACK 分析 |
| `IPC_TRANSPORT_DECISION.md` | Informative + Decision Support | gRPC vs HTTP+JSON vs framed JSON 的选择结论 |
| `IPC_SESSION_MODEL.md` | Informative + Engineering | Hello/HelloAck 之后的 session state machine |
| `IPC_JOB_FOLLOW_MODEL.md` | Informative + Engineering | Job follow、event index、reset/replay 行为 |
| `IPC_STREAM_POLICY.md` | Informative + Engineering | stream delivery/ack/reset/replay 策略 |
| `IPC_IMPLEMENTATION_PLAN.md` | Informative + Engineering | IPC 从 skeleton 到 runtime 的实施顺序 |
| `APP_CLIENT_LAYER.md` | Informative + Engineering | local/remote client 组装层职责 |
| `REMOTE_FACADE_PARITY.md` | Informative + Engineering | local/remote façade parity 推进状态 |
| `OVERLOAD_AND_RETRY_MODEL.md` | Informative + Engineering | overload/backpressure 的公开表达与 retry hint |
| `LOOPBACK_CONTRACTS.md` | Informative + Engineering | loopback contract 的验证层次 |
| `SCENARIO_SUITE.md` | Informative + Engineering | scenario bundle 的组合策略 |
| `REDACTION_AND_SUPPORT_BUNDLE.md` | Engineering | `RFC-0010` 脱敏边界的落点、support bundle 内容与 `§14` 门禁↔测试映射 |
| `IMPLEMENTATION_STATUS.md` | Informative + Process | 当前实现盘点、阶段状态与阻塞项 |
| `ONBOARDING_NOTES.md` | Informative + Audit | 接手过程中遇到的文档/代码偏差、结构坑与已修缺陷留档 |
| `DEVELOPMENT_LOG_2026-08-27.md` | Informative + Log | 本轮接续开发的改动、验证结果与未尽事项 |
| `ROADMAP.md` | Informative + Process | 建议实施路线与里程碑定义，含 §1bis 按阶段量的完成度与阻塞点 |
| `CONTINUATION_PLAYBOOK.md` | Informative + Process | 接续开发的工作流程：数字纪律、证伪规程、文档手术规程、现有门禁清单 |
| `ROBUSTNESS_GUIDE.md` | Informative + Engineering | 健壮性优先策略与高级技巧 |

---

## 4. 当前最关键的阅读组合

如果只看最关键的七份文档，建议按这个顺序：

1. `docs/rfcs/RFC-0001-core-architecture.md`
2. `docs/CENTERLINE_PROGRESS.md`
3. `docs/APPLY_EXECUTION_CENTERLINE.md`
4. `docs/STORAGE_RECOVERY_EXECUTION_PLAN.md`
5. `docs/CAPABILITY_VALIDATION_EXECUTION_PLAN.md`
6. `docs/API_DTO_MIGRATION_PLAN.md`
7. `docs/ROADMAP.md`

这七份足以回答：

- Caly 的中心是什么
- 目前中心线接到了哪里
- 后半截 apply/recovery 怎么补
- capability 决策怎么变成真正 gate
- API 结构债该怎么还
- 下一步代码优先级是什么

---

## 5. 哪些文档是“权威来源”

文档的权威级别如下：

1. **RFC**：对架构边界与外部契约具有最高优先级。
2. **ADR**：记录为什么做出某项架构决策。
3. **工程执行文档**：说明当前状态、实施顺序与具体推进路径，但不得推翻 RFC/ADR。
4. **实现代码注释**：只能细化 RFC/ADR，不得推翻 RFC。
5. **Issue / PR 描述**：仅用于讨论，不构成正式规范。

`ONBOARDING_NOTES.md` 与 `DEVELOPMENT_LOG_*.md` 属于**审计与过程记录**，
不进入上面的权威链；它们可以指出“文档与代码不一致”，但不能替代 RFC/ADR 的结论。

若出现冲突：

```text
RFC > ADR > Engineering Docs > Code Comment > Issue/PR text
```

---

## 6. 当前文档体系的阶段

当前文档体系已覆盖：

- 总体架构
- API / IPC
- Pipeline / Provenance
- Capability / Coverage
- Deployment / Recovery
- IO Port / IoFault
- Storage / CAS / Snapshot
- RuntimeDriver / Telemetry
- Profile Patch / Override
- Security / Secret / Redaction
- 中心主链进度
- apply execution 主链推进基线
- storage/recovery 接线计划
- capability validation 执行计划
- API DTO 迁移计划
- RFC/ADR/crate 交叉索引
- core vertical slices
- IPC transport / session / follow / stream / loopback
- app client layer / local-remote parity / scenario / contract
- overload/retry
- 实施状态与路线图
- 健壮性与高级实现技巧
- 接手审计与开发留档（`ONBOARDING_NOTES.md` / `DEVELOPMENT_LOG_2026-08-27.md`）
- 本地质量门禁入口 `scripts/check.sh`（以及生成 `IMPLEMENTATION_STATUS.md §3.3` 实测表的
  `scripts/regenerate_test_census.py`，`--check` 只报不改）

也就是说，Caly 的文档现在已经不只是“总体设计稿”，而是开始具备**面向当前实现推进的中心化工程导航**。

---

## 7. 一句话导航

如果只记一条：

> **先看 RFC 定边界，再看 centerline/apply/storage/capability/API 迁移文档定推进顺序，最后再看 IPC、parity、scenario 和 roadmap 落地实现。**
