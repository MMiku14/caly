# Caly 开发日志 — 2026-08-31（第八十九轮：生产 CLI 全会话走共享泵）

本轮在第八十八轮（环境接手，见 `ONBOARDING_NOTES §4.162`）把工具链与四份钉死真核资产
重建、完整门禁复现到 813/31/0 之后，沿 `ROADMAP §13#3`（通用 IPC transport runtime）挑了
一个**可量出错、修法在冻结边界内、可被红断言钉住**的小切片。无新 ADR、无新依赖、无 wire
形状变更。

---

## 1. 本轮靶子（第 1–2 步：量选与判据）

### 1.1 现象

第八十七轮把握手收进共享 `caly_ipc::FramePump`（构造时同时设 read+write 超时、读前
`probe_peer`），但 CLI 里那个泵是 `handshake()` **临时借用** `&mut session.stream` 建的，
握手结束即 drop。会话其余整段——`ask()` 的请求帧、`follow_stream()` 的流数据帧、
`ack_and_confirm()` 的 stream-ack——走 `Session::send/recv`，它直调裸 codec
`wire_write_frame`/`wire_read_frame`。而 `Session::open` 只调 `set_read_timeout(3s)`，
**从不调 `set_write_timeout`**。

### 1.2 为什么是性质缺口

读有 3s 上限、写没有。一个停止读取的对端（TCP 接收窗口耗尽、进程僵死但不断开）会让
`write_all` **无限阻塞**——这是第四十四轮 falsify 抓到的「不会回答的 daemon 不许挂死
客户端」（读半）的**写半**遗漏。R44 的修法是读超时；写半从来没被同一条规则覆盖。
`calyd` 侧每连接设 read+write，不对称只在客户端。

### 1.3 靶子判据（可证伪）

> 连接建立后，生产 CLI 的每一个帧（请求、stream-ack、follow 流数据）都必须经共享
> `FramePump` 收发：read 与 write 都受同一个有界超时约束，读前探活；生产 `caly-cli`
> 源码不得绕开泵直接调裸 `wire_read_frame`/`wire_write_frame`。

量选命令：`grep -n "wire_write_frame\|wire_read_frame\|FramePump\|set_write_timeout"
crates/caly-cli/src/bin/caly.rs` —— 命中：握手用泵、会话直调裸 codec、无 set_write_timeout。

---

## 2. 实现（第 3–4 步）

### 2.1 `Session` 持有泵而非裸流

`crates/caly-cli/src/bin/caly.rs`：

- `struct Session { pump: FramePump<WireStream> }`（原为 `stream: WireStream`）。
- `Session::open`：`FramePump::new(stream, Some(READ_TIMEOUT))` —— 构造即同时设 read 与
  write 上限（`FramePump::new` 内部 `set_read_timeout` + `set_write_timeout`）；删掉单独的
  `set_read_timeout` 调用。
- `Session::recv` 委托 `self.pump.recv()`（带读前 `probe_peer`，TCP peek 0 字节=对端已走、
  UDS Indeterminate 落到读）；`Session::send` 委托 `self.pump.send(...)`。
- `handshake()` 直接驱动 `&mut session.pump`，删掉临时 `FramePump::new(&mut session.stream,…)`。
- 移除不再使用的 import：`wire_read_frame`、`wire_write_frame`、`WireIo`（`FramePump`/
  `WireStream` 仍用）。

读超时文案保持 R44 措辞（`timed out after …ms waiting for the daemon to speak`，
`EXIT_CODES.md` 11 仍匹配 `starts_with("timed out")`）。`FramePump::recv` 的
`WireFrameError.timed_out` 映射不变。

### 2.2 wire 形状零变更

帧布局、kind、records/json 编码、cap 检查全部在共享 codec/pump 内，未触碰；`caly_cli_e2e`
25 条真二进制链路（status/doctor/profiles/apply/jobs/follow/gc/bundle/JSON/UDS 等）全绿。

---

## 3. 门禁（第 5、7 步）

### 3.1 新 arch-test 裁判

`crates/caly-arch-test/tests/dependency_direction.rs`
`the_cli_drives_every_frame_through_the_shared_pump`：

- 扫 `caly-cli/src/**`（`tests/` 目录取外——e2e 的独立 oracle reader 自持最小 wire 实现是
  「两实现一致才是证据」，不是生产回路），任何非 `use ` 行出现
  `wire_read_frame(` / `wire_write_frame(` 调用即违规。
- 两条反空转断言：`caly-cli/Cargo.toml` 必须存在（crate 移走不静默扫 0）；扫到源文件 ≥ 3。

### 3.2 证伪（`scripts/falsify_round89.py`，2 变异全咬）

- **M1（反空转）**：把扫描根改成一个不存在的 crate 目录名（在真名后缀加 `-missing`）⇒ 门禁在「caly-cli crate」
  反空转断言处红、**编译绿**（`build_failed=False, gate_passed=False, bit=True`）。
  （初稿把检测条件改成 `if … && False`，在干净树上 offenders 仍为空、门禁照绿——「必为空」型
  门禁靠引入真实违规来证，那是 M2；反空转才是 M1 的正确形状，`§4` 旧族「断言要长在分支上」。）
- **M2（真接缝）**：把 `Session::send` 改回 `caly_ipc::wire_write_frame(self.pump.inner_mut(), …)`
  （编译合法、wire 行为不变）⇒ 门禁在 `wire_write_frame` 违规处红、**编译绿**（R76 同族：
  行为不变的第二接缝只有这条门咬得住）。

两变异均保绑定/类型/arity；备份-还原按内容+mtime 双还原（`shutil.move` + `os.utime`），
sha256 断言还原一致；收尾 `*.r89bak` 扫描为空。

### 3.3 数字

- 测试普查：`files=105 total=814 rows=105`（新增 1 个 `#[test]` 在既有文件
  `dependency_direction.rs`，该文件 12 个）；`TEST_FLOOR` 813 → **814**。
- §3.3 普查表该文件行的新描述为人工手写（普查脚本只重算数量列）。

---

## 4. 文档收口（第 6 步）

- `ONBOARDING_NOTES.md`：新增 `§4.163`（写半无超时的现象/量选/修法/门禁/规则）+ 处置表
  `6.115`（一轮一行）；「历史上明确不做」标题顺延 `6.115 → 6.116`（`check_disposition_ledger`
  要求标题=最高行+1）；当前快照 census 行 813→814。
- `IMPLEMENTATION_STATUS.md`：§3.1/§3.3/§2 可验证性/收尾原则数字 813→814；新增 `§8.23`
  记录本切片；§2 未覆盖清单与 §5.4 caly-ipc 行更新为「CLI 全会话经同一泵收发」。
- `CENTERLINE_PROGRESS.md`：§7 收尾块 813→814、轮次注记加第八十九轮。
- `ROADMAP.md`：§1bis Phase-2/Phase-10 数字 813→814；§13#3 残余项注明第八十九轮已闭合
  「CLI 全会话走泵/写半超时」，残余仍是 timeout scheduler、typed send_request_frame、UDS peek。

历史数字一律不改写（`dialect` 行数 `1,813 → 2,306`、第八十八/八十七轮日志原文保留）。

---

## 5. 验证与收尾（第 8 步）

- `cargo check --workspace --all-targets`：0 warning。
- `cargo test`：814 passed / 0 failed（floor 814）。
- clippy：31 个 distinct locations（基线 31，未抬）。
- `cargo fmt --all -- --check`：0 行（本轮只 `rustfmt` 碰过的两个文件）。
- 证伪 harness：`all mutations bit: True`；还原后工作树无 `.r89bak` 残留。

## 6. 明确没做（范围控制）

- 共享 timeout scheduler（服务端/客户端统一的期限调度）——`§13#3` 主体，下一轮。
- typed `send_request_frame` 生产化——R76 已排除 naive 接线（v0 是字符串 op + extras，
  双表是 API 增长不是复用）；需要先定型 typed 帧层。
- `SessionRegistry` 生产化（calyd 目前每连接一线程各自 `DaemonTransport`，registry 仅 harness 用）。
- UDS peek（std 无 `UnixStream::peek`，需 libc/nix，先有 ADR）。
- 无新 ADR（本轮闭合 R87 既有泵的覆盖范围，不引入新架构决策或外部依赖）。
