# Caly IPC Protocol Analysis and Hardening Notes

本文件用于**认真分析 Caly 的通信协议**，并把当前 RFC 与代码骨架中的协议语义、风险点、缺口与建议补强项系统化整理出来。

它不是新的 RFC，但它应作为：

> **📌 阅读提示（2026-08-31 更新）**：本文是协议加固**分析**，其中多处补强已在第 88–103 轮落地（fail-closed 帧分派、帧关联、传输有界期限、角色降权、stream resume/ack）。已做/未做清单见 `FEATURES.md §4` 与 `IMPLEMENTATION_STATUS.md` 逐轮收口；仍缺 timeout scheduler、typed send_request_frame（`ROADMAP §13#3`）。


- IPC 实现者的设计审查清单
- RemoteApi / daemon / CLI/TUI 对齐时的参考
- 后续把 skeleton 变成可运行协议栈时的风险地图

---

## 1. 分析范围

本分析覆盖四层：

1. **握手层**：`Hello / HelloAck`
2. **请求响应层**：`RequestEnvelope / ResponseEnvelope`
3. **流层**：`StreamFrame / Ack / Reset`
4. **装配层**：daemon request mapping、engine event bridge、watch/replay

本分析同时结合：

- RFC-0002
- 现有 `caly-ipc` skeleton
- 现有 `caly-daemon` request/stream/handler skeleton
- 现有 `caly-engine` event/replay skeleton

---

## 2. 当前协议骨架的优点

当前设计已经具备几个正确方向：

### 2.1 三分语义明确

外部交互分为：

- `Query`
- `Command`
- `Stream`

这让：

- 权限
- 超时
- 幂等
- 重连
- CLI 行为

可以按语义分层实现，而不是靠方法名猜。

### 2.2 Envelope 化是正确的

`RequestEnvelope` / `ResponseEnvelope` 已经把以下关键元信息固定下来：

- protocol version
- request id
- trace id
- deadline
- expected revision
- role
- operation
- idempotency key（已开始进入骨架）

这是协议能长期演进的基础。

### 2.3 Stream Reset 已经是显式语义

这一点很关键。很多系统的问题恰恰是：

- 增量流断了
- 服务端缓存裁剪了
- 客户端还以为自己的本地视图是连续可信的

Caly 当前已经明确：

> gap / retention overflow 不是“偶发异常”，而是协议的第一类路径。

### 2.4 内部 event 与外部 watch 已开始分层

`watch_bridge` 已经说明一个正确趋势：

- engine 内部 event 结构
- IPC 最终对外 stream frame

不应直接等价。

这能显著降低未来演进时的耦合度。

### 2.5 session 模型已经开始出现

当前 skeleton 已经不只是消息结构，而是开始有：

- `SessionMachine`
- `AwaitingHello / Active / Closed`
- frame validation
- request validation
- session loop helper

这是非常关键的方向，因为 Caly 的本地 IPC 不是 stateless request/response，而是持久会话。

### 2.6 job follow 已开始进入 query + stream 双轨

这说明 command 结果的协议化路径开始成形，而不是仍然依赖“以后再说”。

---

## 3. 当前协议最需要警惕的风险

### 3.1 握手虽已出现，但仍未进入完整 transport loop

当前已有：

- `ClientHello`
- `ServerHelloAck`
- `SessionMachine`
- `NegotiationPolicy`
- `session_loop` skeleton

但仍缺：

- 会话级 hello timeout 真正执行路径
- transport loop 中“先 hello 后 request”的强约束
- close / reconnect / daemon restart 处理

### 3.2 `RequestEnvelope` 的幂等承载位刚出现，尚未全面贯通

现在 `idempotency_key` 已进入 envelope，并能映射到 command，但仍缺：

- CLI/RemoteApi 统一注入策略
- 哪些 operation 必填、哪些可选的正式规则
- reconnect/retry 时的完整行为说明

### 3.3 Query 一致性边界尚未系统化

当前 query skeleton 可以返回数据，但仍缺更明确的：

- revision 绑定策略
- 分页 cursor 生命周期
- Query 与 runtime snapshot 的一致性界限
- Query 和 Stream 的组合语义

### 3.4 Job follow 虽已进入骨架，但重连语义仍需继续固定

现在已开始有：

- job follow query
- job follow stream skeleton
- job event slicing

但仍缺：

- `from_event_index` retention overflow 的明确定义
- job stream reset 规则
- CLI follow 默认策略

### 3.5 Stream seq 与 event seq 的关系仍需持续谨慎

当前 watch bridge 直接使用 engine event seq 生成 stream frame seq，是合理 skeleton，但长期要明确：

- stream seq 是否等同 engine event seq
- 不同 stream kind 是否共享同一 seq 空间
- reset 后 seq 规则如何处理

### 3.6 ACK 策略虽然已有 policy，但尚未进入完整 session 行为

`StreamPolicy` 已开始出现，但仍缺：

- ACK 的实际接收和推进逻辑
- 不同 stream kind 的 ACK enforcement
- ACK 与 replay window 的结合

### 3.7 backpressure 与 frame size 规则还需继续下沉

协议若没有明确执行：

- max frame size
- control frame 是否允许压缩
- stream payload 大小策略
- slow client 策略

最终就会把资源压力推到实现细节里，难以测试和一致化。

---

## 4. 当前 skeleton 已经出现的正确补强方向

### 4.1 `caly-ipc::policy`

协议策略不应散落在 handler/bridge 中。现在已经开始抽：

- `MAX_FRAME_SIZE_BYTES`
- `AckPolicy`
- `DeliveryGuarantee`
- `StreamPolicy`
- `stream_policy(kind)`

### 4.2 `caly-ipc::negotiate`

协议协商不应依赖调用方“自己记得检查一下”。现在已经开始有：

- `NegotiationPolicy`
- `HandshakeError`
- `validate_frame_header(...)`
- `negotiate_hello(...)`

### 4.3 `caly-ipc::session`

session 状态机已经开始形成：

- `AwaitingHello`
- `Active`
- `Closed`
- `SessionInfo`
- `validate_request(...)`

### 4.4 `caly-ipc::session_loop`

会话执行辅助层开始出现，说明协议从“结构存在”往“时序执行”迈进。

### 4.5 `watch_bridge` 显式翻译层

这说明协议边界开始具备：

- 内部 event 可以演化
- 外部 stream payload 可以演化
- 两者不必一一对应

### 4.6 replay window 已经有 reset 语义

当前 engine 事件日志已经具备：

- retention window
- retained_from_seq
- reset_required

### 4.7 job follow 也开始具备协议化趋势

当前已出现：

- `JobFollowRequest`
- `JobFollowView`
- `FollowJobStream`
- engine job event slicing
- daemon job watch bridge

---

## 5. 推荐冻结的协议行为细则

以下内容建议尽快从“工程约定”提升为更明确的固定规则。

### 5.1 握手规则

建议固定为：

1. 连接建立后第一条消息必须是 `ClientHello`
2. daemon 在 `HELLO_TIMEOUT` 内必须返回 `ServerHelloAck` 或错误
3. major 版本不一致直接拒绝
4. minor 版本不一致由服务端决定是否向下兼容
5. 未协商成功的 encoding/compression 直接拒绝，不要静默半成功

### 5.2 帧规则

建议固定为：

- 默认上限 `4 MiB`
- 控制消息默认不压缩
- 大对象不直接走普通 Response frame
- 压缩策略必须显式协商，不允许隐式猜测

### 5.3 Command 规则

建议固定为：

- Response 只返回 `Accepted`
- 最终结果通过 Job follow / stream 获得
- 高风险 command 必须带 `idempotency_key`

### 5.4 Stream 规则

建议按 `StreamKind` 固定 delivery policy：

| StreamKind | Delivery | ACK | Gap 处理 |
|---|---|---|---|
| Job | LosslessResumable | Required | Retry/Resume |
| Deployment | LosslessResumable | Required | Retry/Resume |
| Dashboard | SnapshotThenPatch | Optional | Reset |
| Traffic | LatestValue | None | 丢中间值 |
| Logs | LossyRing | None | 丢旧值 |
| Connections | SnapshotThenPatch | Optional | Reset |

### 5.5 Reset 规则

建议固定为：

- `Reset` 不是错误，而是正常协议事件
- Reset 后客户端必须重取 snapshot
- Reset 必须携带原因
- 客户端不得尝试从旧本地视图继续 patch

---

## 6. 现阶段最重要的协议缺口

如果按“真正能运行的 RemoteApi/daemon”视角看，目前最缺的是：

### 6.1 缺少 query/command/stream 的统一 session + handler 装配规范

目前已有 skeleton，但还没有一层更完整的：

- session state machine
- hello timeout
- frame validation
- request validation
- dispatch routing
- handler execution
- stream bridge

统一管线。

### 6.2 缺少 stream open 与 stream follow 的完整会话语义

当前 `WatchOpened` 只是表示“流开了”，但还没有完全固定：

- server 何时开始推送第一帧
- snapshot 是否作为第一帧
- `from_seq` 何时使用
- watch 重连时 client 应该怎么做

### 6.3 缺少 job follow 的完整 retained/reset 策略

当前有 query skeleton 与 stream skeleton，但还缺：

- `from_event_index` 超出保留范围时的行为固定
- job stream reset 行为
- job follow 对 ACK 的使用策略

### 6.4 缺少 queue full / overload 的对外协议稳定表达

当前 engine 内部已有 queue reject 路径，但还需确定：

- 是否统一映射为 `UNAVAILABLE` 或更明确错误码
- 是否应给出 retry hint
- 是否记录 overload 诊断事件

---

## 7. 建议的下一步协议实现顺序

建议按这个顺序推进：

1. **先把 `caly-ipc::policy`、`negotiate`、`session`、`session_loop` 接进 daemon 会话入口**
2. **再把 `Runtime::Watch` 的 open + replay + reset 语义补完整**
3. **再把 Job follow 扩展为更完整的 query + stream 模型**
4. **最后再逐步扩大 Query/Command 资源面**

不要反过来先把 operation 数量堆满，再回头补协议底层行为。

---

## 8. 推荐测试清单

从协议角度，最值得优先做的自动化测试是：

1. hello major mismatch -> 明确拒绝
2. unsupported compression -> 明确拒绝
3. frame too large -> 明确拒绝
4. queue full -> command reject + 事件记录
5. watch replay from valid seq -> 返回增量 frames
6. watch replay from stale seq -> 返回 reset
7. query / command / stream mode mismatch -> 明确拒绝
8. role 不满足 -> 明确拒绝
9. daemon instance 改变 -> 客户端需要丢弃增量状态
10. duplicated command with same idempotency key -> 返回同一 job
11. job follow from valid event index -> 返回增量 job event
12. job follow from stale event index -> 返回 reset/stale 语义

---

## 9. 当前总结

从架构和 skeleton 现状来看，Caly 的通信协议方向是对的，尤其是：

- Query / Command / Stream 三分
- Envelope 化
- Reset 一等语义
- watch bridge 分层
- replay window 有界化
- policy / negotiation / session / session_loop 层开始出现
- job follow 已开始协议化

但要真正把它变成“可运行且稳定的协议”，最关键的是：

1. 把协商、frame policy、stream policy 做成显式代码层规则
2. 把 request -> command / event -> stream / job -> follow 三个边界继续做厚做稳
3. 继续补上 job follow 与 idempotency 的对外协议承载与重连语义
4. 把大而全的 `operation.rs` 继续按 Facet 渐进拆解

---

## 10. 一句话结论

> Caly 的协议设计最重要的不是“消息长什么样”，而是：握手怎么协商、流怎么重放、何时必须 Reset、哪些边界必须显式分层。