# Caly Roadmap

本文件给出 Caly 从文档冻结走向可运行系统的建议实施路线。

路线的核心原则是：

> **先建立边界与契约，再做最小纵向切片，最后扩展功能面。**

并且在当前阶段还要再补上一条更硬的执行原则：

> **优先持续闭合中心主链，而不是反复扩外围协议壳。**

也就是说，Roadmap 的阶段不是“先界面后底层”，而是：

1. 先让契约可编译
2. 再让 centerline 可解释、可验证、可计划
3. 再让 daemon / IPC / CLI 围绕 centerline 形成真正执行闭环

---

## 1. 路线概览

| 阶段 | 目标 | 核心产物 | 当前状态 |
|---|---|---|---|
| Phase 0 | 文档冻结 | RFC-0001 ~ RFC-0010，ADR-011 ~ ADR-034（现为 ADR-011 ~ ADR-038） | `Done`（第三十一轮复核：10 份 RFC、28 份 ADR，`grep -m1 -o "Status: [A-Za-z]*" docs/adrs/ADR-0*.md` **28 个 Accepted、0 个 Proposed**——原记的"ADR-035 / 036 待确认"已过时，两份都已定稿并进入实现） |
| Phase 1 | 工程边界落地 | workspace、crate 骨架、clippy/arch guardrails | `Done` |
| Phase 2 | 源码级契约落地 | Operation、ApiError、Facet、IoFault、Stage、ApplyPlan、EffectStep、IPC skeleton、registry schema | `Partial` |
| Phase 2.5 | 编译打通与契约收敛 | toolchain、workspace check、依赖修复、命名收敛 | `Done` |
| Phase 3 | 基础设施骨架 | IO、Storage、CAS、Pipeline skeleton、sim world | `Partial`（IO 网关已有生产实现 + 跨后端契约测试；第二十八轮起落盘 store 能容忍会挂起的端口，`Http` / `Proc` / 阻塞池不再被「一挂起就报内部错误」堵住） |
| Phase 4 | 控制链与 daemon 骨架 | Command、Job、Coordinator、queue、event、daemon bootstrap | `Partial` |
| Phase 5 | 核心主链纵向切片 | Profile/Source/Override -> IR -> ResolvedProfile -> Native -> ApplyPlan -> EffectPlan | `Partial`（已可执行并验证，真后端未接） |
| Phase 5.5 | Effect 执行与恢复闭环 | Effect executor、journal/snapshot 提交、补偿回滚、启动恢复扫描 | `Partial`（内存后端已完成；第二十七轮起 cutover 窗口的游标是**执行中**落盘的，所以启动恢复扫描读得到"跑到第几步"而不是只有"开始了没有"——见 `ADR-036 §6bis-octies`） |
| Phase 6 | Daemon / IPC / CLI 连接 | LocalApi、RemoteApi、Job、watch、CLI 可用 | `In Progress`（daemon command path 已闭环；IPC runtime 未接） |
| Phase 7 | 双 Core 纵向切片 | Mihomo / sing-box 两个 core 的第一版 vertical slice | `Partial` |
| Phase 8 | Platform / Recovery | TUN、system proxy、helper、journal、rollback、recovery | `Planned` |
| Phase 9 | TUI / Runtime UX | dashboard、connections、traffic、logs、select/probe UX | `Planned` |
| Phase 10 | 硬化与发布门禁 | fuzz、真核 CI、性能回归、doctor、support bundle | `In Progress`（doctor 的审计项、support bundle 与 secret redaction 三条已有实现与门禁断言；fuzz / 真核 CI / 性能回归未做；第三十轮起两条批量诊断查询有响应上界且报告截断） |

---

## 1bis. 按阶段量的完成度（第三十一轮复核）

这一节只写**能量出来的东西**，每条附产出它的命令；状态词沿用 §1 的表，但把"依据"补上。它替代了
"从文档里读一句旧结论"的做法——本轮复核就发现 §1 的 Phase 0 行还写着两份 Proposed（实际 0 份）。

| 阶段 | 量的东西（命令） | 实测 | 由此可下的结论 |
|---|---|---|---|
| 0 文档 | `ls docs/rfcs/*.md`、`ls docs/adrs/ADR-*.md`、`grep -m1 -o "Status: [A-Za-z]*"` | RFC 10（+README+TEMPLATE）、ADR 28、Accepted 28 / Proposed 0 | 冻结层完整，无待确认 ADR；`ADR-036` 的**第 4 步**仍未开始（唯一未走完决策的 ADR） |
| 1 工程边界 | `grep -rn "^[a-z-]* *= *{" crates/*/Cargo.toml \| grep -v "path = "`；`ls crates` | 外部依赖 **0**、成员 **20** | 零依赖是事实而非口号；`check.sh` 与 `caly-arch-test` 的门禁都在跑 |
| 2 源码级契约 | `grep -c`：`Operation` 变体、`ErrorCode`、`EffectStep`、IPC frame/stream kind、registry schema | 全部有类型且有跨门面/跨后端断言（`caly-app/tests/*`、`caly-io-sim/tests/contract.rs`） | `Partial`：契约齐，但**公开码表被 `RFC-0002 §14.4` 冻住**（没有容量类码），这条落差是有意的、已记档 |
| 3 IO / Storage | `grep -c "^impl .* for Std\|impl .* for Sim" crates/caly-io-std/src/lib.rs crates/caly-io-sim/src/port_impl.rs` | 端口 trait 7 个；生产适配器实现 **2**（`Fs`、`Clock`）；仿真实现 **6**（多 `Rand`/`Http`/`Proc`/`Keyring`）；`Platform` **0/2** | 单一 IO 网关成立（`std::fs`/墙钟在 `caly-io-std` 之外 0 命中）；但"真后端"只覆盖 Fs+Clock，`Http`/`Proc`/`Platform` 缺实现——这正是 Phase 8 的入口 |
| 4 控制链 / daemon 骨架 | 每 crate 的 `#[test]` 计数 | `caly-daemon` 94、`caly-engine` 148、`caly-storage` 78（本轮全仓 503） | 命令路径在**进程内**闭环（queue/job/coordinator/event/bootstrap/恢复扫描）；`daemon bootstrap` 有实现但无进程入口 |
| 5 / 5.5 主链与恢复闭环 | `grep -n "pub fn execute_effect_plan_with_cursor\|fn drive_port\|fn byte_ceiling"` | 三处都在（游标 guard、store 有界驱动、端口字节上限）；cutover 逐步游标第二十七轮、崩溃可见性同轮 | "会规划 → 会执行 → 会记账 → 会恢复"成立，且**执行中的证据是落盘的**（不是事后补的） |
| 6 Daemon / IPC / CLI | `grep -rn "UnixStream\|TcpStream\|std::net" crates/`、`grep -rn "\[\[bin\]\]" crates/*/Cargo.toml` | socket 使用 **0**、`[[bin]]` **0** | IPC 只有框架与状态机（`caly-ipc` 18 条测试），**传输运行时未接**；CLI/daemon 无 bin ⇒ 不可 `cargo run`，真机组装根缺（`clock-timeline` 与 `[[bin]]` 边界两个缺口都源于此） |
| 7 双 Core | `ls crates/caly-mihomo/src crates/caly-singbox/src` + 各自测试数 | 两个 adapter 都渲染原生配置（如 `render_mihomo_yaml`），**每 crate 0 个测试** | 逻辑在 `caly-engine`/`caly-app` 侧被间接覆盖；原生字节 golden 与真核下载/spawn 未做 |
| 8 Platform / Recovery | `grep -rn "impl .* for Std" crates/caly-io-std/src/lib.rs` | `Platform` 无实现；recovery 侧（journal/snapshot/回滚/启动扫描）已成环 | Recovery 可交付，Platform（TUN/system proxy/helper）**未开始**，且需要权限决策 |
| 9 TUI / Runtime UX | `ls crates` | `caly-tui` **不存在**；`caly-cli` 无 bin | 未开始（阶段本身未被任何 ADR 绑定） |
| 10 硬化与发布门禁 | `ls -a`（无 CI 目录）、`grep -rn "check.sh" docs/`、`crates/caly-daemon/tests/*` | 门禁：`check.sh` 四步 + `caly-arch-test` 21 条（文档形状 7 条、依赖/覆盖 5 条、门面契约若干）；**无 CI、无 fuzz、无性能回归** | 门禁体系可用且在每轮跑；但"跑门禁"目前依赖人（无 CI），`§4.65` 记过把判定塞进管道导致的误判 |

### 1bis.1 阻塞点（三件事卡在同一道门上）

~~`RFC-0007` 冻结的 `StorageBackend` 签名不带 `Ctx`，于是这三件都动不了~~ **已决策并落地第 1 步**：
`ADR-039`（第三十三轮）把调用方 Context 送进 store 接缝——23 个方法签名全链带 `ctx`、
`FsStore` 的伪造身份删除、`StorageErrorKind::Cancelled` 取消门落在内容半、端口归属真实化有裁判。
剩下的按其 §4 阶段表走，**四步已全部落地**：

1. 打断一次已经开始的 store 调用 → 第 1 步已给接缝（取消门先落内容半；第三十四轮把取消随
   drive 恒挂、`Cancelled→Cancelled` 映射有裁判）；
2. 按调用方累计 store 预算 → 第 2 步（`ctx.io_budget` 在 fs-store/memory 计费，第三十四轮）；
3. 给 store 接缝一个真正的等待时限 → 第 3 步（第三十五轮：期限由持时钟方判、轮询间读钟即可，
   `ADR-013` 有界池这个继承来的前提经实证**不必要**，见 ADR-039 §8）；
4. daemon 门面把调用方 ctx 送到端口 → 第 4 步（第三十六轮：查询路径 `caller_ctx` 三规则、
   引擎三方法的幽灵 ctx 移除、端到端裁判在 `facade_store_ctx.rs`）。

### 1bis.3 需要决策而非代码的缺口（第三十八轮登记；本节是登记处，已决项标注去向）

- ~~**`FsStore::sanitize` 非单射，对象名可撞文件**~~ **已决策并落地**：`ADR-041`（第三十九轮）
  选单射百分转义 + boot 名↔记录校验（被否决：put 拒撞名——修不了别名读；入口拒特殊字符——
  `mihomo:*` 命名惯例是更大契约）。测量细节与四个后果（静默互覆/别名命中/两后端分歧/重启
  不定）见其 §1。anchor 读侧校验（第三十八轮）不涉此题：content anchor 由 store 自算自校，
  对象 digest 才是调用方名字。

### 1bis.2 一句话完成度

> 中心主链（Phase 2–5.5 + 10 的门禁面）已经**可交付给下一个实现者**：契约有类型、执行有门禁、崩溃现场
> 可读、诊断有界且如实报告截断。外围（Phase 6 的传输运行时、Phase 7 的原生 golden、Phase 8 的 Platform、
> Phase 9 的 TUI）**仍未开始**，其中两项需要决策而非代码。按"能否运行"衡量：**库与门禁可运行，
> 可执行程序 0 → 1**——第四十三轮的 `calyd`：真 bin、真 TCP、v0 记录帧，一条白名单查询
> （`runtime.status`）端到端经完整 daemon 传输（握手/会话序/角色门是未来一切 op 将走的那套），
> 其余 op 明确拒；E2E 裁判 spawn 真 binary（`calyd_wire.rs`）。第四十四轮可执行 **1 → 2**：
> `caly` CLI（`caly status --addr`）对真 calyd 互通，退出码按 `EXIT_CODES.md`（0/2/11/12），
> wire 编解码提取为 `caly_ipc::wire` 单一真源（E2E oracle 故意独立实现作对照）。第四十五轮：
> wire 第二个 op `diagnostics.doctor`（三层计数+索引行）、CLI `caly doctor`、daemon **thread-per-connection**
> （哑客户端只花自己的超时，不再挡别人的路——裁判钉住）。第四十六轮：
> wire 第三/四个 op `profiles.list`/`profiles.get`（**第一个带请求参的 op**——缺参点名拒绝、视图回显所问
> id）、CLI `caly profiles`/`caly profile <id>`、期限一分为二（`HELLO_TIMEOUT` 5s 陌生者 /
> `--session-idle-ms` 30s 会话——一个常量两种策略是藏在名字里的策略，拆开后才有可证伪性）。第四十七轮：
wire 第五/六个 op `profiles.apply`（**第一个 command**——idempotency key 是调用方对这次写的命名，`ADR-037`
不代铸；接收连接**内联 drain**，读到的 acceptance 已跑完——第五十三轮起由 worker 线程接掌，acceptance=已排队）
与 `jobs.events`（事件分页面全上 wire）、
CLI `caly apply`/`caly jobs`——request → command → apply 执行闭环从 daemon command path（既有）延伸到了
真客户端。第四十八轮：`jobs.follow`（摘要+**跨 op 一致性**裁判）、`profiles.rollback`（第二个 command——
点名快照反猜：吞 snapshot_id 恒用 LKG 的变异可咬）、`caly job`/`caly rollback`/`caly jobs --from/--max`
（分页平铺裁判：两页拼接==整窗）。第四十九轮：维护对与导出对上 wire——`system.gc-plan`/`system.gc`
（plan 是查询：问两遍除活钟外全同；collect 是 command：门口 bounds 拒绝不产生 job）、
`diagnostics.support-bundle`/`diagnostics.support-bundle-read`（无 key 也收——Optional；digest 上 job
事件行；读回 content 锚==digest、截断如实、伪 digest 拒绝不读）、CLI 四动词。第五十轮：
**JSON 载荷编码第一刀**（`ADR-034` 兑现）——hello `encoding=json` 协商、op 载荷（请求/响应/拒绝）
换编码不换事实（键值集等同裁判钉死）、握手帧恒 records（元语言不随载荷编码变）、CLI 全动词 `--json`。
第五十一轮：**第一个流**——`jobs.follow-stream` 上 wire（帧类 6/7：DATA/END）、job-stream 泵
（`IPC_STREAM_POLICY` 首段真实现：无损续传、gap 报 resume 不跳、先行后终）、CLI `caly follow`
（退出码=判决）。第五十二轮：**reconnect/resume 路**——帧类 8（ACK，一问一答有确认）、服务端
流表（有界 64，满了点名拒）、resume 从 acked 游标续（未 ack 全量重放——至少一次投递）、CLI
`caly follow --resume <stream-id>`。第五十三轮：**worker 线程**（acceptance=已排队，
`--worker-tick-ms` 一个节奏一个活窗口——活增量流从裁判不可达变为可判，泵的 Wait 分支真行使）、
**断线收割**（泵 Wait 期零字节探活——弃线客户端花费一个 wait tick 而非整个预算或下一次写失败）、
**`ADR-042`**（`StdProc` 落 std：shell-free/cwd 网关根/共享 spawn 契约两后端同判，契约表七条全齐；
`Platform` 决策性缺席）、**非数值参数点名拒**（在场但不可解析=USAGE，绝不静默默认——垃圾游标
静默变全量重放是最糟的一个）。第五十四轮：**`ADR-043` Proc supervision 最小面**（`try_wait`/
`stop`＋`ChildExit`，宽限=自然退出窗口期满 SIGKILL，TERM 显式推迟）、**真内核真跑**（mihomo
v1.19.30＋geoip/geosite 资产 sha256 钉死入库；spawn→控制器 `/version` 经 Http 端口答 200→
stop→端口归还，全生命周期经端口可判）、**geo 承重**（缺 geo=确定性 fatal，下载回退指向不可达
地址——沙箱有网，「顺手下载」必须结构上不可行）。


---

## 2. 已完成的阶段修正

### 2.1 Phase 1 — 工程边界落地

已完成：

- workspace 与 crate 结构建立
- 基本 arch guardrails / clippy 约束建立
- 代码组织已达到可持续迭代的基本形态

因此，Phase 1 不再应视为 `Partial`。

### 2.2 Phase 2.5 — 编译打通与契约收敛

这一阶段现在已经真实完成：

- Rust toolchain 已安装
- `cargo check --workspace` 已跑通
- 多个 crate 间的依赖/导出/类型裂缝已被修补
- 后续推进已可建立在真实编译反馈之上

这一步虽然不是“产品功能”，但它非常关键，因为它把 Caly 从“静态骨架堆积”推进到了“动态可检验骨架”。

---

## 3. Phase 2 — 源码级契约落地

### 当前进展

已完成：

- `caly-common`
- `caly-api` 基础 DTO / Error / Facet / Operation
- `caly-plan` 中 `ApplyPlan` / `EffectPlan`
- `caly-io` 基础 Port / Fault / VPath
- `caly-cap` registry / loader 骨架
- `caly-ipc` frame / handshake / stream / dispatch / codec / client / session primitive
- `caly-cli` exit code / follow / driver / contract_driver 基础骨架

仍需补齐：

- DTO 真正迁移出 `operation.rs`
- DTO 分面之间重复 re-export 与旧定义并存问题
- `caly-api` 对外导出面继续收敛
- 更严格的 schema / validation 层

---

## 4. Phase 3 — 基础设施骨架

### 当前进展

已完成：

- `caly-storage` 基本数据类型、store trait 与 in-memory backend 骨架
- `caly-io-sim` 的世界模型、fault injector、首批 Port impl 与 scenario builder
- workspace 编译已覆盖这些 crate

仍需补齐：

- `caly-io-std` 的 `Http` / `Proc` / `Platform` 适配器（`Fs` + `Clock` 已完成，
  并与 `caly-io-sim` 共用 `RFC-0006 §15` 契约测试）
- ~~storage facade 深化~~ → 已有第二个后端 `FsStore`（经 `caly-io::Fs` 落盘、内容寻址、写入即校验），
  并已实现 `§8` / `RFC-0007 §13` 的 GC root 集与回收计划（store 侧为此补了 `list_objects`/`delete`）。
  ~~剩余：给 `Fs` 补 `list`/mtime，以去掉 `manifest/*.idx`~~ → 第十五轮加能力、第十六轮删清单层
  （`ADR-035 §6bis-ter`），第 3 步 grace period 改取端口 mtime 也已在第十七轮落地
  （`§6bis-quater`）。GC 的生产接线与 idle 自动触发已在第十八–二十轮 + 第二十五轮落地
  （`ADR-038 §6/§7/§8/§9`：`system.gc-plan` 给报告、`system.gc-collect` 真删、`§13.2` **默认关闭**、由
  role-gated `AutomationPatch(gc.idle)` 打开）。剩余：孤儿内容清扫、`stat_many`（年龄目前每条记录一次
  `stat`）；`§7.3` schema 迁移
- provenance/codegen 缓存体系
- 更丰富的 step-aware scenario 与故障回放

---

## 5. Phase 4 — 控制链与 daemon 骨架

### 当前进展

已完成：

- `caly-engine` 的 Command / Queue / Job / Idempotency / Event / Worker 基本骨架
- `caly-daemon` 的 lifecycle / session / transport / registry / runtime / harness 基本骨架
- `caly-app` 的 local/remote/parity/contract/scenario 基本装配

仍需补齐：

- worker consume cycle 深化
- overload/public error 更完整贯通
- daemon 与 engine/storage 的真实装配
- command path 对 apply vertical slice 的执行接线

---

## 6. Phase 5 — 核心主链纵向切片

### 当前进展

这是当前最应该继续投入的主线。

已完成：

- `caly-domain` 可表达 `Profile / Override / SelectionMemory`
- `caly-pipeline` 已开始真实消费 source refs / normalized source / override / selection memory
- merge 阶段开始物化图结构
- resolve 阶段开始做 deterministic manifest / semantic digest / revision
- semantic / capability validation 已开始形成结构性检查
- adapter 开始产出 native artifact bytes
- `ApplyPlan` / `EffectPlan` 已开始有可读步骤投影

### 当前阶段完成定义

原始四条的实测状态：

1. 真实 source parse / normalize —— **未达成**（仍是 estimate 级）
2. registry 驱动的 capability validation —— **已达成**（`caly-cap` 求值进 pipeline；JSON 工件漂移已有门禁）
3. apply executor 与 snapshot/journal 的连接 —— **已达成**（`caly-engine::executor` + `recovery`，见 `tests/apply_execution_gate.rs`）
4. daemon command path 触发真实 apply workflow —— **已达成**（见 `caly-daemon/tests/apply_command_path.rs`）

因此 Phase 5 记 `Partial` 而不是 `In Progress`：中心线已能执行并验证，
但“真后端”仍缺，故不能记 `Done`。

---

## 7. Phase 6 — Daemon / IPC / CLI 连接

### 当前进展

与之前相比，这一阶段已经不应继续标成 `Planned`。

已完成：

- `LocalFacade` / `RemoteFacade` 均可编译
- loopback transport / harness / client session 已可编译运行于工程骨架层
- parity / contract / scenario 已有真实代码入口
- daemon query path 已接入：
  - `ProfileOp::Plan`
  - `DiagnosticsOp::ExplainPipeline`

### 仍需补齐

- request -> command -> apply workflow 真执行闭环
- stream runtime 的 read/write pump
- reconnect / timeout scheduler
- CLI `apply/status/follow` 与真实 job lifecycle 对接

---

## 8. Phase 7 — 双 Core 纵向切片

### 当前进展

已从 `Planned` 提升到 `Partial`。

当前已有：

- `caly-mihomo`
  - YAML-shaped native artifact
  - native validation
  - apply planning
  - vertical slice helper
- `caly-singbox`
  - JSON-shaped native artifact
  - native validation
  - apply planning
  - vertical slice helper

### 仍需补齐

- 更真实的 capability matrix 差异
- binary inspection / version coverage / native validation fixture
- runtime API model 与 process lifecycle

---

## 9. Phase 8 — Platform / Recovery

### 目标

把平台副作用正式纳入部署事务。

### 当前前置条件已出现

虽然 executor 尚未落地，但 `EffectPlan` 已经开始表达：

- `NetApply`
- `NetRevert`
- `SpawnCore`
- `StopCore`
- `Probe`
- `MarkSnapshot`
- `CommitRevision`

这说明 Platform / Recovery 不再是纯文档概念，而是已经有建模承载位。

---

## 10. Phase 9 — TUI / Runtime UX

### 目标

提供真正可交互的管理体验，但不破坏控制面边界。

### 约束

在 Phase 5 / 6 / 8 未进一步闭环前，不应让 TUI 反向驱动架构偏航。

---

## 11. Phase 10 — 硬化与发布门禁

### 目标

把“能编译、能演示”提升为“可发布、可维护、可回归”。

### 关键门禁

- 真 core fixture
- native validation fixture
- contract/regression suite
- overload/backpressure coverage
- support bundle / doctor / secret redaction
  —— 2026-08-27 已落地：`RFC-0010 §14` 的第 1/2/3 条成为断言（`caly-common::redact` +
  `caly-engine::bundle` + `caly-daemon/tests/redaction_boundary.rs`）；第 4–8 条（UDS 权限、helper 输入、
  SSRF、下载校验、导入限额）仍待平台层决策。`doctor` 的四项诊断另见
  `STORAGE_RECOVERY_EXECUTION_PLAN.md §9.2`。

---

## 12. 推荐最小里程碑（更新版 MVP 顺序）

建议按以下顺序继续推进：

1. 继续瘦 `caly-api::operation.rs`
2. 用真实 source parser 替换 `NormalizedSource` stub 入口
3. 让 capability validation 真正读取 registry / coverage matrix
4. 让 `engine::apply` 接 storage snapshot / journal projection
5. 让 daemon command path 接入 apply executor
6. 完成 IPC runtime pump 与 reconnect/timeout 语义
7. 补 CLI `profile plan/apply/status/follow`
8. 再推进 TUI 与 richer runtime UX

---

## 13. 当前最优动作

基于本版 workspace 状态（`IMPLEMENTATION_STATUS.md §7` 的阻塞项排序），下一步依次是：

1. **后端可替换性**：`EngineHandle` 与 `InMemoryStorage` 解绑，并解决 `run_ready` 的同步/异步矛盾
2. **真 effect 后端**：用 `caly-io` 的 `Fs` / `Proc` / `Platform` Port 实现 `EffectRuntime`，
   让现有 47 个断言在真后端上重跑（`ADR-022` 的对偶要求）
3. **中心主链深化**：真实 source parse / normalize / semantic merge
4. **Capability 来源决策**：registry 从文件加载，或明确“文件是导出物”，并同步 ADR-024 措辞
5. **Transport runtime**：补 session read/write/timeout/reconnect
6. **CI**：把 `scripts/check.sh` 接进 workflow，clippy 改为“新增即红”

已不再是下一步的事项：**effect 执行闭环与 apply 接线（已完成）**、
**清 DTO 编译告警（当前无告警）**、**让 capability registry 参与校验（已参与）**。
接手时请先读 `ONBOARDING_NOTES.md`，避免按旧排序重复施工。

---

## 14. 一句话原则

> Caly 的路线图不应再围绕外围接口数量扩张，而应围绕中心主链是否继续闭合来排序。