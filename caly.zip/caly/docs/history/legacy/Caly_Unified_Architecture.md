# Caly Unified Architecture Specification

> **归档说明（2026-09-01）**：本文件原位于仓库根目录，是被后续规范取代的旧合并草稿，已归档于此仅作历史参考。
> 现行权威是 `docs/rfcs/` 下的全部 RFC（尤其 RFC-0001 核心架构规范）；本文与 RFC 冲突时以 RFC 为准。

> Status: Consolidated draft
> Scope: unified from Core Design v0.1 / v0.2 / v0.4 / v0.5
> Goal: freeze architecture boundaries, core contracts, IO rules, pipeline model, facade/API boundaries, and implementation slices before large-scale coding

---

## 0. Document Purpose

This document consolidates the previous Caly design iterations into a single architecture specification.

It replaces narrative evolution with one coherent model and establishes the rules that all future implementation work must follow.

Caly is defined as:

> A Rust-based, low-overhead, event-driven control plane for Mihomo and sing-box that transforms untrusted multi-source configurations into capability-constrained, deterministic native artifacts, then deploys them through a compensatable execution plan with rollback, recovery, and platform side-effect control.

Caly does **not** reimplement proxy protocols or data plane behavior. It manages:

- configuration modeling
- subscription ingestion and caching
- semantic merge and conflict handling
- capability validation
- deterministic compilation
- core lifecycle supervision
- platform integration
- runtime observability
- CLI/TUI control surfaces
- crash recovery and rollback

---

## 1. Product Boundary

### 1.1 In scope

Caly v1 supports:

- Core targets:
  - Mihomo
  - sing-box
- Control surfaces:
  - full non-interactive CLI
  - interactive TUI
  - daemon mode
  - oneshot `--no-daemon` mode
  - read-only doctor mode
- Configuration sources:
  - remote subscriptions
  - local files
  - inline sources
- Profile composition:
  - multiple profiles
  - multiple subscriptions per profile
  - structured overrides
  - profile import/export
  - backup/migration
- Routing and policy:
  - nodes
  - proxy groups
  - route rules
  - rule sets / rule providers
  - automatic selection and latency test
- DNS:
  - Fake-IP
  - DoH / DoT / DoQ where supported
  - DNS routing / split DNS
  - leak protection policies
- Network integration:
  - TUN enable/disable
  - system proxy enable/disable
  - system DNS override where applicable
  - privilege handling and recovery
- Core management:
  - install / import / pin / upgrade
  - start / stop / reload / restart
  - version-aware capability handling
- Observability:
  - logs
  - traffic
  - connections
  - core resource usage
  - core/daemon health
- Reliability:
  - atomic apply
  - rollback
  - crash recovery
  - OS side-effect journal

### 1.2 Out of scope for v1

Explicitly not included:

- reimplementing Mihomo or sing-box protocol stacks
- replacing core rule engines with Caly-native packet/rule engines
- multi-user remote control panel
- running two active cores simultaneously
- JS/Lua scripting for overrides or automation
- arbitrary shell execution in automation
- automatic silent tracking of upstream latest core releases
- dynamic Rust plugins via `.so` / `.dll`
- direct UI-side modification of generated native config files

---

## 2. Core Architectural Principles

1. **Single state owner**: all mutable state belongs to `calyd`.
2. **Core-agnostic control plane**: Caly models control semantics, not core-specific file formats.
3. **Deterministic compilation**: same inputs must produce byte-stable outputs.
4. **No unsafe hidden IO**: IO is allowed only behind explicit ports.
5. **No silent degradation**: unsupported features must fail explicitly unless user-approved fallback exists.
6. **Atomic deployment**: failed apply must not alter active runtime or OS network state.
7. **Effect isolation**: pure core logic cannot access filesystem, network, process, clock, or randomness.
8. **Low steady-state overhead**: no fixed high-frequency polling; bounded buffers everywhere.
9. **Recoverability**: all OS/network side effects must be journaled and reversible.
10. **UI as projection only**: CLI/TUI issue commands, queries, subscriptions; they do not own business logic.

---

## 3. Non-Negotiable Invariants

Any implementation violating one of the following is considered architecturally incorrect:

1. At most one active core process exists at a time.
2. All mutable state belongs to `calyd`.
3. Any failed apply must leave the current running config and OS network state unchanged.
4. Subscription input is always untrusted.
5. Unknown or core-exclusive fields must never be silently dropped by the unified layer.
6. Compilation must be deterministic with respect to:
   - `ResolvedProfile`
   - target core identity/version
   - Caly compiler version
7. Secrets must not appear in:
   - regular logs
   - TUI history
   - default IPC responses
   - crash dumps where avoidable
8. CLI/TUI contain no business state machine.
9. Core, platform, subscription format, and storage schema evolution must remain explicitly versioned.
10. Recovery logic is mandatory, not a best-effort feature.

---

## 4. Runtime Topology

```text
caly (CLI) ──┐
             ├─ IPC ── calyd ── Privilege Helper (optional)
caly tui ────┘            │
                          ├─ Storage
                          ├─ Engine / Coordinator
                          ├─ Pipeline / Compiler
                          ├─ Core Supervisor
                          ├─ Core Adapter (Mihomo | sing-box)
                          └─ Platform Facade
```

### 4.1 Modes

| Mode | Purpose |
|---|---|
| daemon | default long-lived background controller |
| oneshot | `caly --no-daemon ...`; same API semantics, local execution path |
| doctor | read-only diagnostics; must not mutate OS state |

### 4.2 Ownership model

- `calyd` is the only owner of mutable state.
- CLI and TUI are clients.
- Adapter crates do not depend on CLI/TUI.
- UI code must never directly operate on core processes, storage, or OS networking.

---

## 5. Layering and Dependency Rules

```text
┌───────────────────────────────────────────────┐
│ Frontends        caly-cli / caly-tui          │
│                  depend only on Facade        │
├───────────────────────────────────────────────┤
│ Facade/API       caly-api                     │
│                  Facets + DTO + errors        │
│                  LocalApi / RemoteApi         │
├───────────────────────────────────────────────┤
│ Shell            caly-engine / caly-daemon    │
│                  caly-ipc / supervisor        │
├───────────────────────────────────────────────┤
│ Ports            caly-io                      │
│                  Fs/Http/Proc/Db/Clock/Rand   │
│                  Platform/Priv/Keyring/...    │
├───────────────────────────────────────────────┤
│ Adapters         caly-io-std / caly-io-sim    │
│                  platform-* / core-* impls    │
├───────────────────────────────────────────────┤
│ Pure Core        caly-domain / caly-ir        │
│                  caly-pipeline / compile      │
│                  caly-cap / caly-plan         │
└───────────────────────────────────────────────┘
```

### 5.1 Hard prohibitions

#### Pure core crates must not use:

- `std::fs`
- `std::net`
- `std::process`
- `tokio`
- `reqwest`
- `rusqlite`
- `SystemTime::now`
- `Instant::now`
- `thread_rng`
- `async fn`
- hidden mutable globals

#### Shell layer must not:

- perform direct filesystem/network/process calls outside ports
- bypass executor or platform facade

#### Frontends must not:

- import domain state machines
- compile configs
- manipulate storage
- call core APIs directly

### 5.2 Enforcement

Architecture constraints must be machine-checked via:

- clippy disallow lists
- dependency graph tests (`cargo metadata` + whitelist assertions)
- crate-level `#![forbid(unsafe_code)]` where possible
- CI failure on illegal dependency edges

---

## 6. Workspace Layout

```text
crates/
├── caly-domain/
├── caly-ir/
├── caly-cap/
├── caly-pipeline/
├── caly-plan/
├── caly-storage/
├── caly-io/
├── caly-io-std/
├── caly-io-sim/
├── caly-platform/
├── caly-platform-linux/
├── caly-platform-macos/
├── caly-platform-windows/
├── caly-core/
├── caly-mihomo/
├── caly-singbox/
├── caly-api/
├── caly-ipc/
├── caly-engine/
├── caly-daemon/
├── caly-priv-proto/
├── caly-priv/
├── caly-cli/
├── caly-tui/
└── caly-arch-test/
```

### 6.1 Responsibility summary

| Crate | Responsibility | Must not do |
|---|---|---|
| `caly-domain` | semantic model and invariants | IO / IPC / core API |
| `caly-ir` | structured IR types and stable serialization | runtime effects |
| `caly-cap` | capability registry and coverage matrix | UI logic |
| `caly-pipeline` | decode/normalize/merge/resolve/lower/emit stages | spawn core / mutate OS |
| `caly-plan` | effect plan, apply plan, compensation model | execute effects |
| `caly-storage` | SQLite, CAS, snapshots, journal | business decisions |
| `caly-io` | port traits and fault taxonomy | concrete implementations |
| `caly-engine` | jobs, coordination, state transitions | platform syscalls |
| `caly-core-*` | compiler/runtime driver per core | UI DTO / storage policy |
| `caly-platform-*` | system proxy, TUN, DNS, privilege bridge | profile semantics |
| `caly-api` | facade, DTO, errors, schema | engine internals |
| `caly-ipc` | framing, handshake, dispatch, streams | profile semantics |
| `caly-cli/tui` | UX and rendering | state ownership |

---

## 7. Functional Completeness Model

Caly must classify support for advanced core features instead of claiming generic support.

### 7.1 Support levels

| Level | Meaning |
|---|---|
| L1 `Caly Managed` | Caly understands, validates, merges, compiles, and presents the feature semantically |
| L2 `Core Native Managed` | Caly preserves, validates, and deploys it for the target core, but may not fully model/edit it structurally |
| L3 `Opaque Preserved` | Caly preserves and redeploys it faithfully for the same core, but does not promise cross-core conversion or semantic editing |

No feature may be marked “supported” if Caly only serializes a field without native validation evidence.

### 7.2 Functional domains

Capabilities and UI/API boundaries are organized by user-visible domains:

- CoreLifecycle
- Profiles
- Sources
- Proxies
- ProxyGroups
- Routing
- RuleSets
- DNS
- Inbounds
- Outbounds
- TUN
- SystemProxy
- SystemDNS
- Traffic
- Connections
- Logs
- Health
- CoreUpgrade
- BackupRestore
- Automation
- Diagnostics
- Security

Each domain must correspond to:

- domain model
- pipeline handling
- capability entries
- API facet
- CLI namespace
- TUI view
- tests

---

## 8. Unified Domain Model and IR

### 8.1 Stable identities

All objects use stable IDs, not display names as primary keys.

```text
ProfileId
SourceId
SubscriptionId
NodeId
GroupId
RuleId
RuleSetId
OverrideId
CoreInstallId
SnapshotId
CommandId
JobId
```

Display names may duplicate. References are ID-based.

### 8.2 IR layers

```text
RawSource          original text/blob + hash + source metadata
NormalizedSource   parsed semi-structured representation
CalyIR             unified semantic object graph
UserOverride       structured patch set
ResolvedProfile    merged complete semantic model
CompiledConfig     native config artifact + metadata
RuntimeView        runtime projection for UI/CLI
```

### 8.3 Core semantic types

Caly IR centers on common semantics, including but not limited to:

- `Profile`
- `Source`
- `Subscription`
- `ProxyNode`
- `ProxyGroup`
- `RouteRule`
- `RuleSet`
- `DnsPolicy`
- `Inbound`
- `Outbound`
- `TunPolicy`
- `SystemProxyPolicy`
- `CoreOptions`

### 8.4 Unknown/core-exclusive field preservation

Caly must preserve fields it does not model:

```text
extensions:  BTreeMap<ExtensionKey, ExtensionValue>
passthrough: BTreeMap<JsonPointer, RawValue>
```

Rules:

- known fields enter strong typed IR
- unknown fields enter `passthrough`
- when compiling back to the same core, `passthrough` is restored to original native positions
- when compiling to another core, `passthrough` causes `CapabilityError` unless:
  - explicit mapping exists, or
  - user explicitly marked it droppable
- partial “best-effort” conversion is forbidden unless surfaced as an explicit supported policy

### 8.5 Profile semantics

A profile is not a single config file. It is a composition:

```text
Profile
  core_target: Mihomo | SingBox | Auto
  core_version_pin: Option<VersionReq>
  sources: [Subscription | LocalFile | Inline]
  overrides: [Override]
  routing_mode: Rule | Global | Direct
  tun: inherited | explicit
  dns: inherited | explicit
  inbound: inherited | explicit
  selection_memory: persist group→node
```

---

## 9. Capability System and Registry

Capability handling must be registry-driven, not scattered `if core == ...` logic.

### 9.1 Registry model

```rust
CapabilityKey
CapabilityDescriptor {
  key,
  title,
  domain,
  support,
  constraints,
  evidence,
  fallback,
}
```

Representative capability keys:

- `proxy.vless.reality`
- `dns.fake_ip`
- `dns.doh`
- `dns.doq`
- `routing.process_name`
- `routing.rule_set.remote`
- `tun.auto_route`
- `tun.gso`
- `inbound.mixed`
- `group.relay`
- `runtime.connections.close`
- `runtime.group.select`

### 9.2 Inputs to capability evaluation

Capability state is a function of:

- core kind
- core version
- build tags / build flavor
- OS
- CPU architecture
- privilege model
- adapter version
- platform capability

### 9.3 Capability states

```text
SupportedExact
SupportedNativeOnly
PreservedOpaque
Experimental
Unsupported
Unknown
```

`Unknown` must block deploy in strict mode.

### 9.4 Capability evidence requirements

A feature marked `SupportedExact` must have evidence, ideally all of:

1. input fixture
2. IR → native golden output
3. real native validation by core binary
4. runtime integration test when applicable
5. negative test for unsupported versions/platforms

---

## 10. Configuration Processing Pipeline

The pipeline is a DAG, not an ad hoc function chain.

```text
Source(s)
  └─► Ingest ─► Decode ─► Normalize ─► Identify ─► Merge ─► Resolve
                                                           ├─► Semantic Validate
                                                           ├─► Capability Validate
                                                           └─► Lower ─► Emit
                                                                          │
                                                                          ▼
                                                                     Compilation
                                                                          │
                                                                          ▼
                                                                       Verify
```

### 10.1 Three pipeline families

| Pipeline | Input | Output | Side effects |
|---|---|---|---|
| P1 Ingest | URL / file / inline | CAS object + `RawSource` | yes |
| P2 Materialize | revision / profile state | `Compilation` + `EffectPlan` | pure except VerifyGate |
| P3 Deploy | `EffectPlan` | active deployment result | yes |

### 10.2 Pure stage contract

Stages in the pure pipeline must be deterministic and IO-free.

Each stage produces:

- output object
- diagnostics
- provenance delta

### 10.3 Cache and incremental rules

Each stage result is memoized by stable digest:

```text
CacheKey = hash(stage_id, pipeline_epoch, adapter_version, input_digest)
```

Properties:

- cache is acceleration only
- `--no-cache` must produce byte-identical results
- changing one override should only rerun downstream affected stages
- memoized outputs are stored in CAS; indexes live in SQLite

### 10.4 Provenance

Every meaningful field can be traced to:

- source subscription/file location
- override
- default
- safety policy
- transformation stage history

This powers:

- merge reports
- `--explain`
- conflict diagnostics
- route/DNS explanation

### 10.5 VerifyGate

Native validation is IO and therefore lives outside pure stages.

`Verify` caches results by:

- core binary digest
- compiled artifact digest

Timeout or hang yields `Unknown`, not `Passed`.

### 10.6 Input hard limits

Pipeline-enforced limits include:

- subscription body size
- decompression ratio
- nesting depth
- node count
- rule count
- YAML anchor expansion limit
- regex complexity limit
- cycle detection in references

Exceeding limits is a hard configuration error.

---

## 11. Merge and Conflict Algebra

### 11.1 Precedence

```text
SafetyPolicy
  > RuntimeOverride
  > ProfileOverride
  > LocalInline
  > Subscription[n]   (in declared source order)
  > BuiltinDefault
```

### 11.2 Semantic merge only

Caly must not use generic deep merge for native config trees.

### 11.3 Conflict policy by object family

| Object | Conflict key | Strategy |
|---|---|---|
| Node | explicit ID or semantic identity | merge same entity; true semantic conflict => error |
| Node label | display name | auto-rename, keep alias |
| Group | ID/name | union members; strategy fields follow precedence |
| Rule | order position | concatenate by sections, not name-based merge |
| RuleSet | URL/hash | deduplicate by URL; hash mismatch => error |
| Port/Listen | bind+port | hard error |
| TUN | singleton resource | later source may replace only by explicit override |
| DNS | module scoped | structured field override, server list by declared policy |
| Secret | secret ref | never downgraded into plaintext loggable value |

### 11.4 Rule section order

```text
prepend_user
subscription_rules in source order
append_user
final_safety
```

### 11.5 Reference integrity checks

After merge:

- group members must resolve
- outbound references must resolve
- DNS outbound references must resolve
- ruleset references must resolve
- cycles must be rejected

Failure yields `ConflictError`; Caly must not generate a half-valid native config.

### 11.6 Merge report

Every merge produces a structured report including:

- rename actions
- dropped fields/objects
- overrides
- conflicts
- provenance references

This report must be visible in doctor and TUI.

---

## 12. Compilation and Apply Planning

### 12.1 CoreAdapter contract

The adapter is more than a serializer. It provides:

- core identity inspection
- capability lookup
- preflight issue generation
- compile/lower/emit
- native validation
- apply plan selection
- apply execution support
- runtime driver access

### 12.2 ApplyPlan levels

Deployment uses the cheapest safe plan:

```text
Noop
ApiPatch
HotReload
Restart
Rebuild+Restart
```

Principles:

- prefer API patch when semantics are provably safe
- prefer hot reload over restart when safe
- if safety cannot be proven, escalate to a more conservative plan
- changing core version, inbound shape, privilege model, or TUN generally requires rebuild/restart

### 12.3 Issues

Preflight and validation issues are classified as:

- `Error` — blocks apply
- `Warning` — deployable but surfaced prominently
- `Info` — diagnostic only

---

## 13. Effect Plan and Executor

The pure core may not perform IO, but it must describe required effects.

### 13.1 EffectPlan

An `EffectPlan` contains:

- ordered execution steps
- reverse-order compensations
- required privilege set
- deployment impact summary

Representative effect steps:

- write object to CAS
- materialize artifact to runtime path
- DB transaction
- spawn/stop core
- call core control API
- apply/revert network plan
- probe runtime health

### 13.2 Rules

- `--dry-run` returns the same `EffectPlan` without executing it
- `--explain` renders the same plan
- compensation is generated at planning time, not improvised during failure handling
- only the executor may turn `EffectStep` into syscalls or process/network actions

---

## 14. Transactional Apply and Rollback

### 14.1 Apply sequence

```text
begin snapshot
compile deterministically
native validate
materialize generated artifacts
core preflight
execute apply plan
health probe
  success -> commit snapshot
  failure -> rollback config + rollback OS journal + mark failed
```

### 14.2 Snapshot contents

Each verified snapshot stores at minimum:

- `ResolvedProfile` hash
- `CompiledConfig` hash
- core identity
- OS journal reference
- selection memory
- timestamp / revision metadata

Caly keeps recent Last Known Good snapshots.

### 14.3 Health probe minimum

A deployment is considered successful only if all required checks pass:

1. process is alive
2. control API is ready if expected
3. loaded config identity matches expected artifact
4. required inbounds are listening
5. optional direct/proxy probes pass when configured

“process exists” alone is not success.

### 14.4 Rollback rules

On failure:

- active runtime returns to previously committed good snapshot
- OS network changes are reverted through journal actions
- partially materialized files remain safe and recoverable
- no unverified snapshot becomes active

---

## 15. Core Supervisor

### 15.1 State machine

```text
Absent → Installed → Stopped ⇄ Starting → Running ⇄ Reloading
                              ↘ Failed → Recovering → Stopped/Running
Running → Stopping → Stopped
```

Illegal transitions must panic in debug and be rejected in release.

### 15.2 Responsibilities

Supervisor manages:

- core binary installation/import/verification
- runtime directory allocation
- temporary controller credentials/tokens
- stdout/stderr bounded collection
- abnormal exit classification
- cooldown and retry policy
- guaranteed process cleanup and temp file cleanup

### 15.3 Core binary policy

Core install path must support:

- explicit download or local import
- HTTPS for downloads
- checksum/signature verification when available
- atomic install
- version pinning
- no silent tracking of `latest`

### 15.4 Runtime control channels

- external controller / management API binds loopback only
- per-instance token is random and ephemeral
- tokens must not leak into user-editable profile files or normal logs

---

## 16. IO Architecture

IO is centralized in `caly-io` ports and concrete adapters.

### 16.1 IO classes

| Class | Examples | Execution domain |
|---|---|---|
| C1 control | IPC, core API | async reactor |
| C2 filesystem | CAS, config files, logs | bounded blocking fs pool |
| C3 database | SQLite | single writer + reader pool |
| C4 CPU-mixed | parse/hash/compile/decompress | bounded CPU pool |
| C5 network | subscriptions, rulesets, core downloads | async reactor + streaming |
| C6 subprocess | core stdio, priv helper stdio | dedicated reader tasks |

### 16.2 Port categories

At minimum the IO layer defines ports for:

- `Fs`
- `Http`
- `Proc`
- `Db`
- `Clock`
- `Rand`
- `Platform`
- `Keyring`
- `Privileged transport`
- `Signal / process observation`

### 16.3 Design rules

- every IO call returns structured `IoFault`
- deadlines/cancellation must flow from a shared context
- path handling must use restricted virtual paths, not raw user-supplied paths
- no unbounded `spawn_blocking`
- all heavy queues and rings are bounded

### 16.4 Durability classes

| Level | Meaning | Typical use |
|---|---|---|
| D0 | buffered / lossy acceptable | telemetry/log buffers |
| D1 | temp + rename | intermediate generated artifacts |
| D2 | temp + fsync(file) + rename + fsync(dir) | CAS objects |
| D3 | D2 + DB transaction durability | deployment journal / committed revisions |

### 16.5 CAS rules

- content-addressed storage by digest
- atomic write in target directory
- dedupe by digest
- runtime materialization via reflink/hardlink/copy where safe
- GC uses mark-and-sweep with grace period
- large objects are streamed, not fully buffered or mmapped by default

### 16.6 SQLite rules

- WAL mode
- foreign keys ON
- single dedicated writer thread
- reader pool for reads
- no large blobs in DB
- group commit allowed within small latency window
- checkpoint in idle periods

### 16.7 Network fetch rules

- streaming HTTP only
- route-aware pools: direct / system proxy / active core
- strict timeouts, body caps, redirect caps, decompression caps
- SSRF checks on resolved addresses, not only URL strings
- auth stripping on cross-origin redirects

### 16.8 Subprocess rules

- no shell invocation
- argv direct only
- stdout/stderr continuously drained
- bounded log ring with drop count
- controlled stop sequence
- orphan avoidance via platform-specific process-group/job handling

---

## 17. Storage Layout and Persistence Model

```text
$XDG_DATA_HOME/caly/
  state.db
  objects/
  cores/
  runtime/
  snapshots/
  journals/
  logs/
```

### 17.1 Stored categories

- SQLite stores:
  - metadata
  - object relationships
  - revisions
  - capability cache indexes
  - selection memory
  - job metadata
  - snapshot indexes
- CAS/object store stores:
  - raw sources
  - compiled artifacts
  - large rulesets
  - serialized stage outputs

### 17.2 Secrets

Secrets include at least:

- subscription URLs/tokens
- node passwords/UUIDs/private auth data
- controller/API tokens

Storage priority:

1. OS keyring
2. local encrypted secrets store with strict file permissions

Secrets must not be stored plaintext in ordinary profile artifacts or regular logs.

### 17.3 Schema versioning

Storage schema version is distinct from:

- IR schema version
- API protocol version
- core compatibility version

Migration must:

- snapshot before migration
- fail closed on migration error
- recompute semantic digests after successful migration

---

## 18. IPC, Facade, and Operation Model

### 18.1 External API philosophy

Externally, Caly presents a unified facade. Internally, this facade is decomposed into domain facets to avoid a god interface.

### 18.2 Top-level facade

```text
CalyFacade
├── SystemFacet
├── ProfileFacet
├── SourceFacet
├── ProxyFacet
├── RoutingFacet
├── DnsFacet
├── NetworkFacet
├── CoreFacet
├── RuntimeFacet
├── DiagnosticsFacet
└── AutomationFacet
```

### 18.3 Facet purpose summary

| Facet | Responsibility |
|---|---|
| System | daemon info, protocol negotiation, shutdown, global status |
| Profile | profile CRUD, activate, apply, rollback, revision history |
| Source | subscription CRUD, update, preview, inspect |
| Proxy | nodes, groups, selection, delay test |
| Routing | rules, explain, validation |
| DNS | DNS status, explanation, cache control |
| Network | TUN/system proxy/system DNS/repair |
| Core | install/import/pin/inspect/capability report |
| Runtime | connections, traffic, logs, runtime watch |
| Diagnostics | doctor, explain pipeline, support bundle |
| Automation | scheduled and rule-based automation |

### 18.4 Local and remote implementations

The same DTO and semantic contracts are exposed through:

- `LocalApi` — in-process execution for oneshot/tests
- `RemoteApi` — IPC client for daemon mode

UI code depends only on the facade abstractions.

### 18.5 Communication semantics

There are exactly three interaction modes:

- `Query`
- `Command`
- `Stream`

Commands are accepted asynchronously and tracked as jobs.

### 18.6 Operation envelope

IPC transport uses a unified operation envelope rather than per-method ad hoc encoding.

Each request carries at least:

- protocol version
- request ID
- trace ID
- optional deadline
- optional expected revision
- auth context
- operation enum

Each operation declares metadata including:

- mode: Query / Command / Stream
- idempotency behavior
- required role
- whether it mutates revision
- whether it supports dry-run
- estimated cost class

### 18.7 Job model

Command execution returns acceptance, not immediate completion.

A job exposes events such as:

- stage progress
- warnings
- logs
- completion outcome
- failure error

CLI may simulate synchronous UX by following the job until completion.

---

## 19. IPC Transport Details

### 19.1 Client ↔ daemon transport

- Unix domain socket on Unix
- named pipe on Windows
- socket/pipe permissions restricted to current user context

### 19.2 Framing

- length-prefixed frames
- JSON as default payload encoding
- optional future messagepack/zstd negotiation for large payloads
- small control messages remain uncompressed
- frame size limits enforced

### 19.3 Handshake

Handshake includes:

- protocol version negotiation
- client kind
- client feature set
- selected encoding/compression
- daemon instance ID
- current state revision

If daemon instance changes, clients must discard incremental view state and resync from snapshot.

### 19.4 Idempotency

High-risk commands must carry idempotency keys, including:

- profile apply
- rollback
- core install/upgrade
- network repair
- daemon shutdown

Daemon persists a recent idempotency window mapping:

```text
(actor_id, idempotency_key) -> job_id/outcome
```

Repeated delivery must not trigger duplicated effects.

### 19.5 Stream behavior

Different streams have different reliability rules:

| Stream | Policy |
|---|---|
| Job | resumable, ACKed |
| Deployment | resumable from journal state |
| Dashboard | snapshot + patches; resettable |
| Traffic | latest-value coalescing |
| Logs | bounded lossy with drop counts |
| Connections | bounded diff, reset on overflow |

`Reset` is first-class and clients must support it.

---

## 20. Internal Coordination Model

### 20.1 Command-only mutation

All mutations enter the engine as commands.

Each command carries:

- command ID
- actor
- kind
- payload
- timeout/deadline
- idempotency key

### 20.2 Serialized write path

Writes are serialized by resource domain.

Representative lock domains:

- `cfg`
- `core`
- `net`
- `sub`
- `test`

Some commands take multiple domains, e.g. apply may require `cfg + core + net`.

### 20.3 Event role

Events are for notification, not choreography.

Forbidden pattern:

- service A emits event
- service B mutates state because of that event
- service C performs side effects from another event

Correct pattern:

- coordinator receives command
- coordinator executes explicit steps
- on success/failure, emits state events for observers

---

## 21. Runtime Observability

Runtime projection should normalize core-specific APIs into common views where possible.

### 21.1 Runtime objects

Representative runtime views:

- `TrafficSample`
- `Connection`
- `ProxyDelay`
- `GroupState`
- `LogLine`
- `CoreResource`
- `RuntimeStatus`

### 21.2 Constraints

- all history buffers are bounded
- unsubscribed streams must stop producing high-frequency data
- hidden TUI pages must not keep full-rate telemetry subscriptions
- delay tests must be globally rate-limited
- secrets/tokens/passwords must be redacted before they become API/log objects

### 21.3 Adapter runtime model

Core runtime communication goes through a `RuntimeDriver` with planes:

- `ControlPlane`
- `TelemetryPlane`
- `ProbePlane`

If a core lacks reliable runtime APIs, support must be explicitly partial or unsupported.

stdout parsing alone does not qualify as full runtime management.

---

## 22. Platform and Privilege Model

### 22.1 Platform abstraction

Platform capabilities are abstracted as services such as:

- system proxy
- DNS override
- TUN device management
- auto-start
- keyring
- process info for process-based rules
- notifications

Unsupported platform features must enter the same capability/error system, not be silently assumed.

### 22.2 Privilege separation

`calyd` should not run as root/admin permanently.

Privileged actions are delegated to a minimal helper/service with:

- restricted command schema
- no arbitrary shell
- explicit audit trail
- plan verification
- limited allowed operations

Helper may be launched on-demand or supervised, depending on platform.

### 22.3 Privileged request restrictions

Helper accepts only narrow, prevalidated operations such as:

- apply compiled network plan
- revert known network transaction
- start/stop verified core instance when required

Helper must not accept arbitrary paths, URLs, env vars, or shell snippets.

### 22.4 Recovery priority

On daemon restart, OS/network repair has priority over starting a new core.

---

## 23. Subscription, RuleSet, and Override Model

### 23.1 Subscription state machine

```text
Idle → Fetching → Parsing → Diffing → Ready
                 ↘ Failed (old cache remains usable)
```

### 23.2 Requirements

- ETag / If-Modified-Since support
- size limits
- deadlines and cancellation
- unchanged content hash must not trigger recompilation
- multiple source updates may run concurrently
- final commit into config state is transactional
- update failure must not disrupt current running profile

### 23.3 RuleSet caching

Rulesets are cached by content hash and only trigger downstream recompute when effective referenced content changes.

### 23.4 Overrides

Overrides are structured and declarative, not script-based.

Representative override actions:

- include/exclude nodes by selectors
- rename nodes
- set group
- set field
- drop extension
- patch safe native blocks

v1 does not support JS/Lua override engines.

---

## 24. CLI and TUI Rules

### 24.1 CLI

Representative CLI surface:

```text
caly status
caly doctor
caly start|stop|restart|reload|rollback
caly core ...
caly profile ...
caly sub ...
caly proxy ...
caly rule ...
caly dns ...
caly connection ...
caly log
caly tui
```

All commands that mutate state should support as applicable:

- `--json`
- `--quiet`
- stable exit codes
- `--dry-run`

### 24.2 TUI

The TUI is an event-driven projection of daemon state, built on shared API contracts.

Representative views:

- Dashboard
- Proxies
- Proxy Groups
- Profiles
- Subscriptions
- Connections
- Rules
- DNS
- Traffic
- Logs
- Core
- Settings / Diagnostics

The first screen must surface at least:

- active core
- active profile
- mode
- TUN status
- proxy status
- traffic summary
- last failure reason

### 24.3 Shared rule

CLI and TUI must reuse the same application/facade contracts and must not each implement business logic separately.

---

## 25. Security Model

### 25.1 Trust boundaries

Untrusted inputs include:

- subscriptions
- rulesets
- imported configs
- remote core metadata unless verified

### 25.2 Security rules

- downloads must use HTTPS
- checksums/signatures must be verified when provided
- source origin must be explicit
- installs are atomic
- secrets are redacted at API error construction time, not only display time
- subscription URLs are treated as secrets
- privilege escalation scope must be minimized
- UI processes must not require long-running elevated privileges

### 25.3 Roles

Internal authorization model:

- `Viewer`
- `Operator`
- `Admin`
- `PrivilegedBroker`

Even if local single-user default maps to Admin, permission checks remain explicit in code.

---

## 26. Automation Model

Automation is declarative and restricted.

### 26.1 Trigger/condition/action form

Automation rules are composed from:

- triggers
- conditions
- actions
- cooldown/max-run limits

Supported trigger families include:

- subscription updated
- core health changed
- delay test completed
- network changed
- schedule
- daemon started

Supported action families include:

- run delay test
- select best node
- apply profile
- restart core
- update source
- notify

### 26.2 Restrictions

Automation may not execute:

- shell commands
- arbitrary HTTP
- arbitrary file writes
- arbitrary DB mutations

Automation actions must re-enter the normal command/job pipeline and obey the same permissions, idempotency, audit, rollback, and rate limits.

---

## 27. Error System

### 27.1 Internal error categories

At minimum:

- `ConfigError`
- `ConflictError`
- `CapabilityError`
- `CoreError`
- `NetworkError`
- `StorageError`
- `PlatformError`
- `PermissionError`
- `IPCError`

### 27.2 API error normalization

Across the facade boundary, errors are normalized into a stable public error form containing:

- stable error code
- category
- retryability
- redacted summary/detail
- remediation hint when possible
- diagnostics
- trace ID

### 27.3 Protocol-visible error codes

Representative stable codes:

- `CONFIG_INVALID`
- `CONFLICT`
- `UNSUPPORTED_CAPABILITY`
- `CORE_NOT_RUNNING`
- `CORE_FAILED`
- `PERMISSION`
- `NET_OS`
- `STORAGE`
- `TIMEOUT`
- `UNAVAILABLE`
- `PROTO_MISMATCH`

Old clients speaking unsupported protocol/method versions must fail explicitly with protocol mismatch rather than degraded execution.

---

## 28. Performance and Resource Budget

Targets apply to Caly itself, excluding child core processes.

### 28.1 Goals

- idle CPU approximately 0
- idle RSS under 30 MB target
- daemon idle wakeups near 0
- no periodic high-frequency polling when no network activity or subscriptions demand work

### 28.2 Rules

- bounded queues everywhere
- bounded log/connection/traffic histories
- traffic sampling capped
- dirty-driven TUI redraw
- no 1-second full proxy list refresh loops
- no daemon-side retention of full UI history
- no repeated full config tree cloning for small updates

### 28.3 Measurement

Resource behavior should be verified with instrumentation/CI regression, including syscall and wakeup counters where practical.

---

## 29. Testing and Release Gates

Architecture claims require corresponding tests.

### 29.1 Test layers

| Level | Scope |
|---|---|
| T0 | compile / clippy / dependency graph |
| T1 | pure domain and pipeline tests |
| T2 | API contract tests |
| T3 | IO port contract tests |
| T4 | adapter golden tests |
| T5 | simulated crash/fault tests |
| T6 | real core integration tests |
| T7 | privileged/platform tests |
| T8 | performance regression tests |

### 29.2 Mandatory focus areas

- merge precedence laws
- deterministic compile goldens
- passthrough roundtrip preservation
- cross-core compile rejection without explicit mapping
- apply rollback on native validate/health failure
- journal crash recovery after forced kill
- IPC concurrency with multiple CLI/TUI clients
- subscription damage/oversize/truncation handling
- parser/merge/IPC fuzzing

### 29.3 Real binary rule

An adapter is not considered complete unless it passes:

- native config validation with real Mihomo/sing-box binaries
- relevant runtime integration tests
- unsupported-version negative tests

---

## 30. Deterministic Simulation

Because IO is isolated behind ports, Caly must support deterministic simulation via in-memory/fault-injected implementations.

Simulation world includes:

- virtual clock
- in-memory FS
- scripted HTTP
- fake processes
- fault injection

This enables high-volume crash/recovery matrix testing in CI, including:

- crash after any effect step
- power-loss-like fsync/rename interruption
- SQLite WAL recovery cases
- core starts but never becomes healthy
- ENOSPC / EIO failures
- NTP wall-clock jumps with monotonic timeout correctness
- slow clients without server OOM

Expected recovery convergence is binary:

- old deployment active, or
- new deployment active

No third partially-applied state is acceptable.

---

## 31. Versioning Strategy

The following evolve independently:

- storage schema version
- IR schema version
- API protocol version
- core compatibility version
- pipeline epoch for cache invalidation

These must never collapse into a single global `version` field.

---

## 32. Anti-Corruption Layers

There are four external worlds that must not leak into domain semantics:

- Mihomo native config/API
- sing-box native config/API
- OS platform APIs
- user subscription formats

External types may only appear in boundary components such as:

- decode adapters
- core compilers
- runtime drivers
- platform adapters

They must not appear in domain objects.

---

## 33. Contract Freeze Priority

Before large-scale implementation, the following contracts should be frozen first:

### 33.1 Highest priority

1. `Operation`, `OperationResult`, `ApiError`
2. Command / Query / Stream semantics
3. Job state machine and idempotency model
4. Facet DTOs and API version strategy
5. capability registry and coverage matrix schema
6. `RuntimeDriver` and `Platform` facade contracts

### 33.2 Next priority

7. `caly-io` port signatures and `IoFault` taxonomy
8. pipeline stage list, stage IDs, cache key formula, pipeline epoch policy
9. full `EffectStep` set and compensation matrix
10. snapshot/journal semantics
11. provenance schema
12. structured profile patch schema

---

## 34. Recommended Implementation Slices

Implementation should proceed in verifiable slices, not UI-first slices.

1. `caly-io` ports + std/sim implementations
2. arch test + clippy architectural guards
3. `caly-ir` + stable serialization + digests
4. pipeline skeleton + memo + provenance
5. effect plan + executor + compensation + simulated crash matrix
6. facade/API DTO + schema snapshots + LocalApi/RemoteApi parity tests
7. Mihomo compiler + verify + golden tests
8. deployment saga + supervisor + rollback integration
9. daemon IPC + concurrency/reset/slow-client tests
10. sing-box compiler + verify + golden tests
11. subscription/override manager
12. CLI
13. TUI
14. privilege helper / TUN / system proxy
15. automation, doctor, recovery hardening, fuzz, performance gates

Completion criteria for each slice are test-based, not demo-based.

---

## 35. Final Definition

Caly is not merely “another Clash-like GUI.”

Its core value is:

> turning untrusted, multi-source, semantically conflicting proxy configurations into a deterministic, capability-checked intermediate representation, compiling that representation into native Mihomo or sing-box artifacts, and deploying them with the minimum safe cost under a rollback-capable, journaled, low-overhead control plane.

Everything else—CLI, TUI, subscriptions, runtime status, platform integration—must remain subordinate to that center.

---

## Appendix A. Canonical Design Summary

### A.1 Single sentence

Caly = **pure compilation core + capability registry + structured pipeline + effect plan executor + single state-owning daemon + facet-based facade + strict IO boundary + recoverable deployment saga**.

### A.2 Architectural intent checklist

A change is aligned only if it preserves all of the following:

- pure core remains IO-free
- UI remains stateless with respect to business mutation
- deployment remains transactional and recoverable
- unsupported features fail explicitly
- unknown native fields are preserved intentionally
- cache affects speed only, not semantics
- platform side effects remain journaled
- tests can prove or falsify correctness claims

---

## Appendix B. Files to Freeze Next

Recommended initial freeze targets:

```text
caly-api/src/operation.rs
caly-api/src/facets/*.rs
caly-api/src/dto/*.rs
caly-api/schema/v1/*.json

caly-cap/capability-registry.json
caly-cap/coverage-matrix.json

caly-io/src/*.rs

caly-ipc/src/frame.rs
caly-ipc/src/handshake.rs
caly-ipc/src/stream.rs

caly-engine/src/command_dispatch.rs
caly-engine/src/job.rs
caly-engine/src/coordinator.rs

caly-plan/src/effect.rs
caly-plan/src/compensation.rs

caly-pipeline/src/stage.rs
caly-pipeline/src/cache_key.rs
caly-pipeline/src/provenance.rs
```

These contracts form the minimum stable spine required for parallel implementation without cross-contamination.
