# RFC-0001: Caly 核心架构规范

> **归档说明（2026-09-01）**：本文件原位于仓库根目录，与 `docs/rfcs/RFC-0001-core-architecture.md`
> 逐字节相同，属重复副本，已归档于此仅作历史留痕。现行权威版本是 `docs/rfcs/RFC-0001-core-architecture.md`，
> 后续修改一律只改那里。

- Status: Draft
- Version: 1.0.0-draft
- Authors: Caly Architecture
- Supersedes: Core Design v0.1 / v0.2 / v0.4 / v0.5
- Last-Updated: 2026-08-23

---

## 摘要

本文档定义 Caly 的核心架构规范。Caly 是一个以 Rust 实现的高性能、低资源占用、可恢复的代理控制平面，用于统一管理 Mihomo 与 sing-box。Caly **不实现数据面协议栈**，而是负责多源配置接入、语义建模、冲突合并、能力校验、确定性编译、核心生命周期控制、平台副作用管理、运行时观测，以及 CLI/TUI/Daemon 的统一控制接口。

本文档的目标不是罗列功能，而是**冻结系统边界、依赖方向、状态模型、部署事务、IO 纪律与外部契约**，使后续各模块能够并行开发且不会相互污染。

---

## 1. 规范术语

本文使用以下术语表达强制级别：

- **MUST**：必须满足，否则视为架构错误。
- **MUST NOT**：禁止出现，否则视为架构错误。
- **SHOULD**：强烈建议满足；若偏离，必须有明确理由与替代保证。
- **SHOULD NOT**：原则上不应出现；若确需存在，必须受控。
- **MAY**：可选实现。

除非另有说明，本文所有要求均针对 Caly v1 主线实现。

---

## 2. 设计目标

Caly 的设计目标如下：

1. **统一控制平面**：以统一的抽象管理 Mihomo 与 sing-box。
2. **低资源常驻**：Daemon 在空闲状态下 CPU 唤醒和内存占用尽可能接近零增长。
3. **确定性编译**：相同输入在相同上下文下产生字节级稳定输出。
4. **事务化部署**：任何失败的 Apply 均不得污染当前运行状态或 OS 网络状态。
5. **能力显式化**：不同 Core/版本/平台的功能差异必须进入 Capability 系统，禁止散落在条件分支中。
6. **未知字段保真**：统一层不理解的 Core 独占字段也不得被默默丢弃。
7. **可恢复**：崩溃、超时、秒退、磁盘故障、权限中断后系统必须可恢复。
8. **前端无业务逻辑**：CLI/TUI 只做交互与渲染，不拥有业务状态机。
9. **长期可演进**：Schema、协议、存储、能力矩阵、Adapter 可独立演进。

---

## 3. 非目标

以下内容不属于 Caly v1：

1. 自研代理协议栈或转发数据面。
2. 替代 Mihomo/sing-box 的规则引擎。
3. 同时运行两个 Active Core。
4. 多用户远程控制面板。
5. JS/Lua 任意脚本覆写系统。
6. 自动静默跟踪 upstream latest Core。
7. UI 进程直接操作系统代理、路由或 TUN。
8. 动态 Rust `.so/.dll` 插件加载。

---

## 4. 产品边界

### 4.1 首期支持范围

Caly v1 支持：

- Core：Mihomo、sing-box
- 模式：daemon / oneshot / doctor
- 控制面：CLI、TUI、IPC
- Sources：远程订阅、本地文件、内联配置
- Profiles：多 Profile、多 Source 组合、导入导出、备份迁移
- Routing：节点、策略组、规则、规则集、自动选择、延迟测试
- DNS：Fake-IP、DoH/DoT/DoQ（以 Capability 为准）、分流 DNS、泄漏防护
- 平台集成：TUN、System Proxy、System DNS（平台允许时）
- Core 生命周期：安装、导入、Pin、升级、启动、停止、重载、重启
- 运行时观测：日志、连接、流量、组选中态、核心资源、健康状态
- 恢复：Last Known Good、Rollback、OS Journal、Crash Recovery

### 4.2 核心定位

Caly 是：

> 把不可信的多源代理配置，转化为带能力约束的确定性 IR，再以最小安全代价将其部署到 Mihomo 或 sing-box，并把系统层副作用纳入同一事务中的控制平面。

---

## 5. 架构不变量

以下不变量 **MUST** 被实现与测试共同保证：

1. 任一时刻最多只有一个 Active Core 进程。
2. 所有可变状态仅属于 `calyd`。
3. 失败的 Apply 不得改变当前运行配置。
4. 失败的 Apply 不得留下错误的系统代理、TUN、DNS 或路由状态。
5. 所有订阅输入均视为不可信。
6. 未知字段与 Core 独占字段不得在统一层静默丢失。
7. 相同 `ResolvedProfile + CoreIdentity + CalyCompilerVersion` 必须产生稳定输出。
8. 密钥、Token、密码、UUID、订阅 URL 不得泄漏到普通日志、默认 IPC 输出、TUI 历史。
9. CLI/TUI 不含领域状态机，只能发送 Command、执行 Query、订阅 Watch。
10. 恢复优先于“尽快重新拉起 Core”。

任何实现若违反其中任一条，应视为架构缺陷，而不是“后续优化项”。

---

## 6. 总体架构

```text
caly (CLI) ──┐
             ├─ IPC ── calyd ── Privilege Helper (optional)
caly tui ────┘            │
                          ├─ Engine / Coordinator
                          ├─ Pipeline / Compiler
                          ├─ Storage / CAS / Journal
                          ├─ Core Supervisor
                          ├─ Core Adapter (Mihomo | sing-box)
                          └─ Platform Facade
```

### 6.1 角色说明

- `calyd`：唯一状态所有者与调度器。
- CLI：非交互与脚本友好控制面。
- TUI：交互式管理界面。
- Core Adapter：连接统一语义与目标 Core 原生配置/API。
- Platform Facade：管理 TUN、系统代理、系统 DNS、权限与恢复。
- Privilege Helper：按需使用的最小特权执行体。

### 6.2 运行模式

| 模式 | 用途 | 说明 |
|---|---|---|
| daemon | 默认 | 常驻，CLI/TUI 通过 IPC 连接 |
| oneshot | `--no-daemon` | 不经 daemon 进程，但 API 语义保持一致 |
| doctor | 诊断 | 只读，不改 OS 状态 |

---

## 7. 分层与依赖法则

```text
Frontends   : caly-cli / caly-tui
Facade/API  : caly-api
Shell       : caly-engine / caly-daemon / caly-ipc / supervisor
Ports       : caly-io
Adapters    : caly-io-std / caly-io-sim / core-* / platform-*
Pure Core   : caly-domain / caly-ir / caly-pipeline / caly-cap / caly-plan
```

### 7.1 强制依赖方向

依赖 **MUST** 仅允许从上层指向下层。禁止反向依赖。

### 7.2 Pure Core 约束

`caly-domain`、`caly-ir`、`caly-pipeline`、`caly-cap`、`caly-plan`：

- MUST NOT 依赖 Tokio、文件系统、网络、数据库、进程管理。
- MUST NOT 调用系统时钟或随机数。
- MUST NOT 暴露 `async fn` 作为纯语义边界。
- SHOULD 尽量保持确定性、无副作用、可属性测试。

### 7.3 Shell 层约束

`caly-engine`、`caly-daemon`：

- MUST 通过 Port 使用 IO。
- MUST NOT 直接 `std::fs` / `tokio::fs` / `std::process::Command`。
- MUST 通过 Executor 执行副作用。

### 7.4 Frontend 约束

CLI/TUI：

- MUST 仅依赖 Facade。
- MUST NOT 直接操作 Storage/Core/Platform。
- MUST NOT 维护业务状态机。

### 7.5 机械化约束

以上规则 **SHOULD** 通过以下方式强制：

- clippy disallow list
- cargo metadata 依赖图白名单
- crate-level `forbid(unsafe_code)`（适用处）
- CI 架构测试

---

## 8. Workspace 与模块职责

```text
crates/
├── caly-domain/
├── caly-ir/
├── caly-cap/
├── caly-pipeline/
├── caly-plan/
├── caly-storage/
├── caly-io/
├── caly-io-std/
├── caly-io-sim/
├── caly-platform/
├── caly-platform-linux/
├── caly-platform-macos/
├── caly-platform-windows/
├── caly-core/
├── caly-mihomo/
├── caly-singbox/
├── caly-api/
├── caly-ipc/
├── caly-engine/
├── caly-daemon/
├── caly-priv-proto/
├── caly-priv/
├── caly-cli/
├── caly-tui/
└── caly-arch-test/
```

### 8.1 模块职责摘要

| 模块 | 负责 | 禁止 |
|---|---|---|
| `caly-domain` | 领域模型、约束、不变量 | IO、IPC、平台、Core API |
| `caly-ir` | IR、稳定序列化、Digest | 副作用 |
| `caly-cap` | Capability Registry、Coverage Matrix | UI 逻辑 |
| `caly-pipeline` | Ingest/Decode/Normalize/Merge/Resolve/Lower/Emit | 启动 Core、改 OS |
| `caly-plan` | EffectPlan、ApplyPlan、补偿矩阵 | 执行副作用 |
| `caly-storage` | SQLite、CAS、Snapshot、Journal | 业务决策 |
| `caly-io` | Port trait 与 `IoFault` 分类 | 具体实现 |
| `caly-engine` | Command/Job/Coordinator/状态流转 | 平台系统调用细节 |
| `caly-core-*` | Core 编译、验证、RuntimeDriver | UI DTO、DB 策略 |
| `caly-platform-*` | TUN/System Proxy/System DNS/Privilege Bridge | Merge/Compile 语义 |
| `caly-api` | Facade、Facet、DTO、Error 门面 | Adapter 细节 |
| `caly-ipc` | IPC 编解码、握手、多路复用、流 | 领域语义 |
| `caly-cli`/`caly-tui` | 用户交互与渲染 | 状态所有权 |

---

## 9. 领域模型与 IR

### 9.1 身份模型

所有核心对象 **MUST** 使用稳定 ID，而非“名称即主键”：

- `ProfileId`
- `SourceId`
- `NodeId`
- `GroupId`
- `RuleId`
- `RuleSetId`
- `OverrideId`
- `CoreInstallId`
- `SnapshotId`
- `CommandId`
- `JobId`

显示名允许重复；引用必须走 ID。

### 9.2 IR 分层

```text
RawSource
NormalizedSource
CalyIR
UserOverride
ResolvedProfile
CompiledConfig
RuntimeView
```

### 9.3 核心对象

Caly IR 至少覆盖以下统一语义：

- `Profile`
- `Source`
- `Subscription`
- `ProxyNode`
- `ProxyGroup`
- `RouteRule`
- `RuleSet`
- `DnsPolicy`
- `Inbound`
- `Outbound`
- `TunPolicy`
- `SystemProxyPolicy`
- `CoreOptions`

### 9.4 未知字段保真

统一层 **MUST** 支持：

```text
extensions:  BTreeMap<ExtensionKey, ExtensionValue>
passthrough: BTreeMap<JsonPointer, RawValue>
```

规则如下：

1. 已知字段进入强类型 IR。
2. 未知字段进入 `passthrough`。
3. 面向同一 Core 编译时，`passthrough` MUST 原位写回。
4. 面向另一 Core 编译时，若无显式映射，则 MUST 报 `CapabilityError`。
5. 禁止“能转多少算多少”的静默容错。

### 9.5 Profile 语义

Profile 不是一份配置文件，而是一份组合声明：

```text
Profile
  core_target
  core_version_pin
  sources[]
  overrides[]
  routing_mode
  tun
  dns
  inbound
  selection_memory
```

---

## 10. 功能完整性与 Capability 模型

### 10.1 支持层级

所有功能必须标记为以下三类之一：

| 级别 | 含义 |
|---|---|
| L1 Caly Managed | Caly 理解、校验、合并、编译、展示该功能 |
| L2 Core Native Managed | Caly 可保存、验证、部署到目标 Core，但不一定完整建模 |
| L3 Opaque Preserved | Caly 保证保真保存与同 Core 回写，但不承诺跨 Core 语义转换 |

### 10.2 Capability Registry

Capability 的唯一事实来源 **MUST** 是注册表，而不是散落的 `match` 分支或文档说明。

示例键：

- `proxy.vless.reality`
- `dns.fake_ip`
- `dns.doh`
- `dns.doq`
- `routing.process_name`
- `routing.rule_set.remote`
- `tun.auto_route`
- `tun.gso`
- `group.relay`
- `runtime.connections.close`

### 10.3 判定维度

Capability 状态 **MUST** 由以下因素共同决定：

- CoreKind
- CoreVersion
- BuildTags
- OS
- CPU Architecture
- Privilege Model
- Adapter Version
- Platform Capability

### 10.4 Capability 状态

```text
SupportedExact
SupportedNativeOnly
PreservedOpaque
Experimental
Unsupported
Unknown
```

`Unknown` 在 Strict Mode 下 **MUST NOT** 部署。

### 10.5 证据要求

若某 Capability 被声明为 `SupportedExact`，则 **SHOULD** 具备：

1. 输入 Fixture
2. Golden 编译产物
3. 真实 Core 原生校验
4. 运行时集成测试（若适用）
5. 负向失败测试

---

## 11. 配置处理管线

### 11.1 总体形态

Caly 管线是 DAG，而不是松散的函数调用链：

```text
Source(s)
  → Ingest
  → Decode
  → Normalize
  → Identify
  → Merge
  → Resolve
  → Semantic Validate
  → Capability Validate
  → Lower
  → Emit
  → Compilation
  → Verify
```

### 11.2 三类管线

| 管线 | 输入 | 输出 | 副作用 |
|---|---|---|---|
| P1 Ingest | URL / 文件 / Inline | CAS 对象 + `RawSource` | 有 |
| P2 Materialize | Revision/Profile | `Compilation` + `EffectPlan` | 纯，除 VerifyGate |
| P3 Deploy | `EffectPlan` | Deployment 结果 | 有 |

### 11.3 Stage 约束

纯 Stage：

- MUST 是确定性函数。
- MUST NOT 访问 IO、时钟、随机源。
- MUST 输出 `diagnostics` 与 `provenance`。

### 11.4 增量与缓存

每个 Stage 输出 **SHOULD** 使用 Digest 做记忆化缓存：

```text
CacheKey = hash(stage_id, pipeline_epoch, adapter_version, input_digest)
```

缓存只影响性能，**MUST NOT** 影响结果语义。`--no-cache` 输出必须与启用缓存时字节一致。

### 11.5 Provenance

字段级来源追踪 **MUST** 是一等能力，支持：

- merge report
- route explain
- DNS explain
- pipeline explain
- 冲突来源展示

### 11.6 VerifyGate

原生校验属于 IO，必须位于纯管线之外。其缓存键至少包含：

- `core_binary_sha256`
- `artifact_digest`

校验超时只能得出 `Unknown`，不得当作通过。

### 11.7 输入边界防护

以下上限必须由管线内建控制：

- 原始字节大小
- 解压比例
- 嵌套深度
- 节点数
- 规则数
- YAML 锚点展开上限
- 正则复杂度
- 引用环检测

超限即 `ConfigError`。

---

## 12. 合并与冲突代数

### 12.1 优先级

```text
SafetyPolicy
  > RuntimeOverride
  > ProfileOverride
  > LocalInline
  > Subscription[n]
  > BuiltinDefault
```

### 12.2 语义合并规则

Caly **MUST NOT** 对原生 YAML/JSON 执行无类型 deep merge。合并必须按对象语义进行。

### 12.3 对象族冲突策略

| 对象 | 冲突键 | 策略 |
|---|---|---|
| Node | 显式 ID 或语义身份 | 同实体合并；真冲突报错 |
| Node Label | name | 自动重命名并保留别名 |
| Group | ID/name | 成员并集；策略字段按优先级覆盖 |
| Rule | 顺序位置 | 按规则段拼接，不按 name 合并 |
| RuleSet | URL/hash | 同 URL 去重；hash 不一致报错 |
| Port/Listen | bind+port | 报错 |
| TUN | 单实例资源 | 必须显式 override 才能覆盖 |
| DNS | 模块级 | 结构化覆盖；server 列表按策略替换/追加 |
| Secret | secret ref | 禁止被降级为明文可记录值 |

### 12.4 规则段顺序

```text
prepend_user
subscription_rules in source order
append_user
final_safety
```

### 12.5 引用完整性

Merge 完成后 **MUST** 检查：

- group 成员存在性
- outbound 引用存在性
- DNS outbound 引用存在性
- ruleset 引用存在性
- 引用环

否则返回 `ConflictError`。

### 12.6 MergeReport

每次合并 **MUST** 产出 `MergeReport`，至少包含：

- rename
- drop
- override
- conflict
- provenance 摘要

---

## 13. 编译与 ApplyPlan

### 13.1 CoreAdapter 职责

Adapter 不是简单“生成 YAML/JSON 的函数”，而是：

- 识别 Core 身份
- 查询 CapabilitySet
- Preflight
- Lower/Emit
- Native Validate
- 生成 ApplyPlan
- 提供 RuntimeDriver

### 13.2 ApplyPlan 等级

Caly **MUST** 选择最小安全代价的部署路径：

```text
Noop
ApiPatch
HotReload
Restart
Rebuild+Restart
```

### 13.3 选择原则

- 能安全 API Patch，则不重启。
- 能安全 HotReload，则不 Restart。
- 无法证明安全时，必须升级到更保守路径。
- 修改 Core 版本、TUN、权限模型、关键 Inbound 结构时，通常需要 `Rebuild+Restart`。

### 13.4 诊断分级

Preflight 与 Validate 的诊断分级：

- `Error`：阻止 Apply
- `Warning`：允许继续，但必须在 UI/Doctor 可见
- `Info`：仅诊断信息

---

## 14. EffectPlan 与执行器

### 14.1 设计原则

Pure Core 不执行副作用，但 **MUST** 能精确描述“需要做什么”。

### 14.2 EffectPlan

`EffectPlan` 应至少包含：

- `steps[]`：正向执行步骤
- `compensations[]`：补偿步骤
- `requires`：权限需求
- `impact`：影响摘要

典型步骤：

- 写 CAS 对象
- 物化运行时配置
- DB 事务
- 启停 Core
- 调用 Core API
- 应用/回滚网络计划
- 健康探测

### 14.3 统一用途

`EffectPlan` **MUST** 同时服务于：

- `--dry-run`
- `--explain`
- 真正部署
- 仿真测试

### 14.4 执行边界

只有 Executor 可以把 `EffectStep` 变成实际系统调用。其他层必须产出计划，而不能直接越界执行。

---

## 15. 事务型 Apply 与回滚

### 15.1 标准流程

```text
begin snapshot
compile deterministic
native validate
write artifacts
core preflight
execute apply plan
health probe
  success → commit snapshot
  failure → rollback artifacts + rollback OS journal + mark failed
```

### 15.2 Snapshot

快照至少包含：

- `ResolvedProfile` digest
- `CompiledConfig` digest
- `CoreIdentity`
- `OSJournal`
- `SelectionMemory`
- 版本与时间元数据

### 15.3 Last Known Good

系统 **MUST** 保存最近若干份已验证成功的快照，并允许回滚到这些快照之一。不得回滚到未完成验证的半成品状态。

### 15.4 Health Probe

部署完成不以“进程仍在”作为成功标准。最小检查项：

1. 进程仍在。
2. API Ready。
3. 配置身份与目标工件一致。
4. 关键 Inbound 正在监听。
5. 可选 Direct/Proxy 探针通过。

任一关键检查失败则 **MUST** 回滚。

---

## 16. Core Supervisor

### 16.1 生命周期状态机

```text
Absent → Installed → Stopped ⇄ Starting → Running ⇄ Reloading
                              ↘ Failed → Recovering → Stopped/Running
Running → Stopping → Stopped
```

非法转移在 Debug 下 SHOULD panic，在 Release 下 MUST 拒绝。

### 16.2 Supervisor 职责

- Core 二进制下载/导入/校验/安装
- 运行时目录生成
- API token/监听端口注入
- stdout/stderr 有界采集
- 异常退出分类
- 冷却与有限重试
- stop 时确保 child 回收

### 16.3 Core 二进制策略

Core 安装 **MUST** 支持：

- HTTPS 下载
- checksum/signature 验证（上游提供时）
- 原子安装
- 版本 Pin
- 来源可追踪

系统 **MUST NOT** 静默跟踪 latest。

---

## 17. IO 架构

### 17.1 基本原则

IO 必须集中在 Port 层定义，并由具体 Adapter 实现。系统正确性不应依赖“开发者自觉不在别处写 `fs`/`spawn`”。

### 17.2 IO 分类

| 类别 | 例子 | 执行域 |
|---|---|---|
| C1 控制 | IPC、Core API | reactor |
| C2 文件 | CAS、配置落盘、日志 | bounded fs pool |
| C3 数据库 | SQLite | 1 writer + reader pool |
| C4 CPU 混合 | 解压、解析、编译、Digest | bounded cpu pool |
| C5 网络 | 订阅、规则集、Core 下载 | reactor + streaming |
| C6 子进程 | Core stdio、priv helper | 专用 reader task |

### 17.3 Port 范围

`caly-io` 至少定义：

- `Fs`
- `Http`
- `Proc`
- `Db`
- `Clock`
- `Rand`
- `Platform`
- `Keyring`
- `Signal`

### 17.4 约束

- 所有 IO 返回结构化 `IoFault`。
- 所有 IO MUST 支持 deadline/cancel 语义。
- 所有用户路径 MUST 通过受限 `VPath`。
- MUST NOT 使用无界 `spawn_blocking`。
- 所有高频流与缓冲 MUST 有上限。

### 17.5 Durability 等级

| 等级 | 语义 | 用途 |
|---|---|---|
| D0 | 可丢缓冲 | telemetry/log buffer |
| D1 | tmp + rename | 中间工件 |
| D2 | tmp + fsync(file) + rename + fsync(dir) | CAS/Artifact |
| D3 | D2 + DB durability | Deployment Journal / Revision Commit |

进入可观测状态变更前的关键持久化 SHOULD 至少达到 D3。

### 17.6 CAS

对象存储采用内容寻址：

```text
objects/sha256/ab/cd/<digest>
```

要求：

- 同内容只写一次
- 同目录内 tmp→rename 保证原子
- 支持 link/reflink/copy 物化策略
- GC 使用 mark-sweep + grace period
- 大对象流式处理，不整体入内存

### 17.7 SQLite 纪律

- WAL 模式
- 单写者线程
- 读写分离
- 预编译语句缓存
- 大对象不入库
- Idle 时 checkpoint

### 17.8 网络规则

HTTP 获取必须：

- 流式
- 有全局并发限制
- 有 body cap
- 有 redirect cap
- 有 decompression cap
- 在连接后做 SSRF 地址校验

### 17.9 子进程规则

- 不使用 shell
- stdout/stderr 必须持续读取
- 停止序列必须可回收
- 崩溃后不能留下孤儿进程

---

## 18. 存储、快照与 Journal

### 18.1 数据目录

```text
$XDG_DATA_HOME/caly/
  state.db
  objects/
  cores/
  runtime/
  snapshots/
  journals/
  logs/
```

### 18.2 存储策略

- SQLite 存元数据、关系、Revision、索引、Selection、Job 元信息。
- 大对象、原文、编译产物、规则集落在 CAS。
- 文件写入 MUST 使用 `tmp + fsync + rename` 纪律。

### 18.3 Secrets

Secrets 优先进入 OS keyring。若平台不可用，可退化到本地加密存储，但必须：

- 权限最小化
- 默认掩码显示
- 脱敏输出

### 18.4 版本分离

以下版本 **MUST** 独立管理：

- Storage Schema Version
- IR Schema Version
- API Protocol Version
- Core Compatibility Version
- Pipeline Epoch

---

## 19. IPC 与外部门面

### 19.1 统一门面，分散 Facet

对外是统一门面，对内按领域拆分 Facet，避免单一 God Interface。

```text
CalyFacade
├── SystemFacet
├── ProfileFacet
├── SourceFacet
├── ProxyFacet
├── RoutingFacet
├── DnsFacet
├── NetworkFacet
├── CoreFacet
├── RuntimeFacet
├── DiagnosticsFacet
└── AutomationFacet
```

### 19.2 Local/Remote 双实现

- `LocalApi`：本地直接调用 Engine
- `RemoteApi`：通过 IPC 调用 `calyd`

两者 **MUST** 使用同一份 DTO 与错误语义。

### 19.3 三种交互语义

系统只定义三类对外交互：

- `Query`
- `Command`
- `Stream`

禁止在协议层引入第四种隐含语义。

### 19.4 Operation Envelope

IPC MUST 使用统一 Envelope 承载操作，而不是每个方法各写一套协议。Envelope 至少包括：

- protocol version
- request id
- trace id
- deadline
- expected revision
- auth context
- operation

每个 Operation 必须声明：

- mode
- idempotency
- required role
- mutates revision
- supports dry-run
- max cost

### 19.5 Job 模型

写操作 MUST 异步 Job 化。

同步 CLI 体验通过：

```text
execute → follow job → render progress → map outcome to exit code
```

### 19.6 DTO 原则

- 请求 DTO `deny_unknown_fields`
- 响应枚举 `non_exhaustive`
- JSON Schema 快照进入 CI
- DTO 与 Domain 通过集中 mapping 层解耦

---

## 20. IPC 传输细节

### 20.1 A 类通信：Frontend ↔ calyd

- Unix 使用 UDS
- Windows 使用 Named Pipe
- 认证依赖本机 peer credential / SID

### 20.2 Frame

```text
u32 length (BE) + payload bytes
```

默认 JSON。未来可协商 MsgPack/Zstd，但：

- 控制消息默认不压缩
- 大对象不直接经 IPC 传输
- 单帧上限必须受控

### 20.3 握手

握手内容至少包括：

- 协议版本协商
- 客户端类型
- 特性协商
- daemon instance id
- 当前 state revision

若 `daemon_instance_id` 改变，客户端 MUST 丢弃本地增量视图并重取快照。

### 20.4 幂等

高风险命令 MUST 携带 `idempotency_key`，包括：

- apply
- rollback
- core install/upgrade
- network repair
- daemon shutdown

### 20.5 Stream 策略

| Stream | 要求 |
|---|---|
| Job | 可续传、可 ACK |
| Deployment | 可由 Journal 恢复 |
| Dashboard | Snapshot + Patch，支持 Reset |
| Traffic | 最新值合并，可丢中间态 |
| Logs | 有界丢弃，带 dropped 计数 |
| Connections | 差分推送，溢出时 Reset |

`Reset` 是协议一等公民，客户端必须实现。

---

## 21. 命令、串行化与协调器

### 21.1 命令模型

所有写入与状态变更必须由 `Command` 驱动，Command 至少包含：

- `id`
- `actor`
- `kind`
- `payload`
- `timeout/deadline`
- `idempotency_key`

### 21.2 串行化策略

写路径默认串行，但按资源域上锁：

- `cfg`
- `core`
- `net`
- `sub`
- `test`

跨域命令必须显式声明占用集。例如 Apply 同时占用 `cfg + core + net`。

### 21.3 Event 的角色

Event 仅用于通知，不用于业务编排。部署与副作用链必须由显式 Coordinator 驱动。

---

## 22. 运行时观测

### 22.1 统一 RuntimeView

Caly 对运行时观测的统一投影包括：

- `TrafficSample`
- `Connection`
- `ProxyDelay`
- `GroupState`
- `LogLine`
- `CoreResource`
- `RuntimeStatus`

### 22.2 RuntimeDriver 分层

Adapter RuntimeDriver 应按平面划分：

- `ControlPlane`
- `TelemetryPlane`
- `ProbePlane`

如果某 Core 缺乏可靠 API，则能力状态必须降为 Partial/Unsupported，而不是用 stdout 解析伪装完整支持。

### 22.3 资源约束

- ring buffer 必须有上限
- 未订阅流必须停
- 隐藏页面应取消高频订阅
- delay test 必须限流
- 敏感字段在进入 RuntimeView 前即脱敏

---

## 23. 平台与特权分离

### 23.1 平台抽象

平台层应统一抽象以下能力：

- `SystemProxy`
- `DnsOverride`
- `TunDevice`
- `AutoStart`
- `Keyring`
- `ProcessInfo`
- `Notify`

### 23.2 特权分离原则

`calyd` 默认 MUST NOT 长期以 root/Admin 常驻。需要提权的操作通过最小能力 Helper 执行。

### 23.3 Helper 约束

Helper：

- MUST 仅接受受限结构化请求
- MUST NOT 接受任意 shell、路径、URL、环境变量
- MUST 校验 plan 身份、签名、有效期、artifact digest
- SHOULD 提供审计日志

### 23.4 恢复优先级

恢复顺序 MUST 为：

1. 修复遗留系统代理/TUN/DNS/路由状态
2. 清理孤儿进程与无效 runtime 状态
3. 再决定是否恢复或重新启动 Core

---

## 24. Sources、RuleSet 与 Override

### 24.1 Subscription 状态机

```text
Idle → Fetching → Parsing → Diffing → Ready
                 ↘ Failed (旧缓存保留)
```

### 24.2 更新规则

- 支持 ETag / If-Modified-Since
- 内容哈希不变不得触发重新编译
- 多源可并行更新
- Commit 必须并入统一配置事务
- 更新失败不得打断当前运行态

### 24.3 RuleSet

规则集缓存按内容哈希组织，仅在引用结果变化时触发下游编译。

### 24.4 Override

Override MUST 为结构化补丁，且 v1 不引入脚本引擎。允许：

- include/exclude
- rename
- set_group
- set_field
- drop_extension
- 受限 native patch

禁止任意 JSON Patch 直接改整棵 Profile 树。

---

## 25. CLI / TUI 规范

### 25.1 CLI

CLI 至少支持：

```text
status
doctor
start|stop|restart|reload|rollback
core ...
profile ...
sub ...
proxy ...
rule ...
dns ...
connection ...
log
tui
```

所有变更命令 SHOULD 支持：

- `--json`
- `--quiet`
- `--dry-run`
- 稳定退出码

### 25.2 TUI

TUI 使用共享 API，只做事件投影。主要页面包括：

- Dashboard
- Proxies
- Groups
- Profiles
- Subscriptions
- Connections
- Rules
- DNS
- Traffic
- Logs
- Core
- Diagnostics

首屏 MUST 可见：

- active core
- active profile
- routing mode
- tun state
- system proxy state
- traffic summary
- latest failure reason

---

## 26. 安全模型

### 26.1 不可信输入

以下输入默认不可信：

- 订阅内容
- 规则集内容
- 导入配置
- 下载元数据

### 26.2 安全约束

- Core 下载 MUST 使用 HTTPS
- 校验信息存在时 MUST 验证 checksum/signature
- 订阅 URL 应视为 secret
- 日志 MUST 脱敏
- 错误对象 MUST 在构造时脱敏，而不是打印时才脱敏
- 提权范围必须最小化

### 26.3 角色模型

内部角色：

- `Viewer`
- `Operator`
- `Admin`
- `PrivilegedBroker`

即使默认本机用户等同 `Admin`，权限检查机制仍必须保留。

---

## 27. 自动化模型

### 27.1 设计原则

v1 自动化仅允许受限声明式 DSL，不允许任意脚本执行。

### 27.2 组成

自动化规则：

- `trigger`
- `condition`
- `action`
- `cooldown`
- `max_runs`

### 27.3 触发器与动作

典型触发器：

- `SubscriptionUpdated`
- `CoreHealthChanged`
- `DelayTestCompleted`
- `NetworkChanged`
- `Schedule`
- `DaemonStarted`

典型动作：

- `RunDelayTest`
- `SelectBestNode`
- `ApplyProfile`
- `RestartCore`
- `UpdateSource`
- `Notify`

### 27.4 约束

自动化动作 MUST 重新进入普通 Command/Job 管线，从而共享：

- 审计
- 幂等
- 权限
- 回滚
- 速率限制

---

## 28. 错误体系

### 28.1 内部类型

系统至少区分：

- `ConfigError`
- `ConflictError`
- `CapabilityError`
- `CoreError`
- `NetworkError`
- `StorageError`
- `PlatformError`
- `PermissionError`
- `IPCError`

### 28.2 门面错误

跨 Facade 边界后 MUST 归一化为 `ApiError`，携带：

- `code`
- `category`
- `retryable`
- `summary`
- `detail`
- `remediation`
- `diagnostics`
- `trace_id`

### 28.3 稳定错误码

至少冻结以下公共错误码：

- `CONFIG_INVALID`
- `CONFLICT`
- `UNSUPPORTED_CAPABILITY`
- `CORE_NOT_RUNNING`
- `CORE_FAILED`
- `PERMISSION`
- `NET_OS`
- `STORAGE`
- `TIMEOUT`
- `UNAVAILABLE`
- `PROTO_MISMATCH`

---

## 29. 性能与资源预算

### 29.1 目标

目标针对 Caly 自身，不含 Core 子进程：

- Idle CPU 约等于 0
- Idle RSS 目标 `< 30 MB`
- 无活动时无周期性高频轮询
- Idle wakeup 尽可能接近 0

### 29.2 约束

- 所有 channel/ring buffer 有界
- log/connection/traffic 历史有界
- TUI redraw 仅 dirty 驱动
- traffic fps 限制
- 无订阅不拉取 runtime 高速流
- 不在 daemon 内保存完整 UI 历史

### 29.3 验证

性能目标 SHOULD 通过以下方式纳入回归：

- syscall/wakeup 计数
- 缓冲区深度指标
- 编译耗时基准
- 慢客户端/多客户端压力测试

---

## 30. 测试与发布门禁

### 30.1 分层测试

| 层级 | 内容 |
|---|---|
| T0 | Compile / Clippy / Dependency Graph |
| T1 | Pure Domain / Pipeline |
| T2 | API Contract |
| T3 | IO Port Contract |
| T4 | Adapter Golden |
| T5 | Simulated Crash/Fault |
| T6 | Real Core Integration |
| T7 | Privileged / Platform |
| T8 | Performance Regression |

### 30.2 必测项目

1. Merge 优先级定律
2. Compile 决定性 Golden
3. Passthrough 往返保真
4. 跨 Core 无映射即失败
5. Validate/Health 失败即回滚
6. Kill -9 后 Journal 恢复
7. 多 CLI + TUI 并发 IPC
8. 超大/损坏/截断订阅
9. Parser/Merge/IPC/Fuzz
10. 真核测试固定版本验证

### 30.3 完成定义

没有 Golden + 真 Core 验证的 Adapter，不算完成。

---

## 31. 确定性仿真

### 31.1 目标

由于 IO 已完全收口至 Port，系统 MUST 支持确定性仿真测试环境：

- VirtualClock
- MemFs
- ScriptedHttp
- FakeProc
- FaultInjector

### 31.2 关键断言

对于任意 EffectStep 后崩溃，恢复后状态必须收敛到二者之一：

- 旧版本 Active
- 新版本 Active

不存在第三种“半应用状态”。

### 31.3 覆盖场景

- fsync 后 rename 前崩溃
- SQLite 提交中断
- Core 启动后不响应 API
- ENOSPC / EIO
- 时钟跳变
- 慢客户端

---

## 32. 反腐层（Anti-Corruption Layer）

以下外部世界必须通过防腐层隔离：

1. Mihomo 原生配置/API
2. sing-box 原生配置/API
3. OS 平台 API
4. 用户订阅格式

外部类型 MUST NOT 泄漏进 Domain 模型。它们只能出现在：

- Decode Adapter
- Core Compiler
- Runtime Driver
- Platform Adapter

---

## 33. 版本演进策略

以下版本号独立演进：

- Storage Schema Version
- IR Schema Version
- API Protocol Version
- Core Compatibility Version
- Pipeline Epoch

旧 IR → 新 IR 需要显式 Migration；新 IR → 旧 IR 不允许静默降级。

---

## 34. 建议冻结的契约

在继续大规模实现之前，以下契约应优先冻结：

### 34.1 第一优先级

1. `Operation` / `OperationResult` / `ApiError`
2. `Command` / `Query` / `Stream` 语义
3. Job 状态机与幂等模型
4. Facet DTO 与 Schema v1
5. Capability Registry 与 Coverage Matrix
6. RuntimeDriver 与 Platform Facade 契约

### 34.2 第二优先级

7. `caly-io` Port 签名与 `IoFault`
8. Stage 列表、StageId、CacheKey、Pipeline Epoch
9. `EffectStep` 全集与补偿矩阵
10. Snapshot 与 OSJournal 语义
11. Provenance Schema
12. Profile Patch Schema

---

## 35. 推荐实施顺序

实现顺序应按可验证增量推进：

1. `caly-io` + `caly-io-std` + `caly-io-sim`
2. 架构测试与 clippy 禁止表
3. `caly-ir` + 稳定序列化 + Digest
4. Pipeline 骨架 + Memo + Provenance
5. `EffectPlan` + Executor + 补偿 + 仿真崩溃矩阵
6. `caly-api` + DTO + Schema + Local/Remote 契约对齐
7. Mihomo Compiler + Verify + Golden
8. Supervisor + Deployment Saga + Rollback
9. IPC + daemon 并发/Reset/慢客户端测试
10. sing-box Compiler + Verify + Golden
11. Source/RuleSet/Override Manager
12. CLI
13. TUI
14. Priv Helper / TUN / System Proxy
15. Automation / Doctor / Recovery / Fuzz / Performance Gate

每一阶段的完成定义 MUST 是测试通过，而不是“界面可以打开”。

---

## 36. 结论

Caly 的本质不是“再做一个 Clash 客户端界面”，而是建立一条严谨的控制平面主链路：

> 不可信输入 → 统一语义 IR → 冲突与能力约束 → 确定性原生产物 → 最小代价部署计划 → 可补偿执行 → 可证明恢复。

CLI、TUI、订阅、流量、日志、平台集成，都应服从这条主链，而不能反过来侵蚀它。

当这份 RFC 被遵守时，Caly 才能同时满足：

- 支持 Mihomo 与 sing-box 的高级能力
- 长期维持低资源占用
- 对失败和崩溃具备强恢复能力
- 在未来新增 Core/平台/能力时不重写上层控制面

---

## Appendix A. 术语表

| 术语 | 定义 |
|---|---|
| Core | Mihomo 或 sing-box 可执行体 |
| IR | Intermediate Representation，统一中间表示 |
| Capability | 某功能在特定 Core/版本/平台下的支持状态 |
| Apply | 将目标配置与网络副作用切换为新状态的事务过程 |
| ApplyPlan | 针对当前运行态选择的最小安全部署策略 |
| EffectPlan | 描述副作用执行步骤及补偿的计划对象 |
| Snapshot | 已验证可回滚状态的持久记录 |
| OSJournal | 对系统代理/TUN/DNS/路由等副作用的可逆操作日志 |
| RuntimeDriver | 对目标 Core 控制、观测、探测的统一适配层 |
| Facet | 对外 API 的领域化子接口 |
| Provenance | 字段级来源追踪信息 |

---

## Appendix B. 后续建议文档拆分

本 RFC 冻结后，建议拆分以下子规范：

1. `api-rfc.md`：Facet/DTO/错误码/Job/Stream
2. `pipeline-rfc.md`：Stage、Digest、Memo、Provenance
3. `capability-rfc.md`：Registry、Coverage Matrix、Evidence
4. `deployment-rfc.md`：ApplyPlan、EffectPlan、OSJournal、Rollback
5. `storage-rfc.md`：CAS、SQLite、Snapshot、Migration
6. `runtime-rfc.md`：RuntimeDriver、事件流、资源预算

这些子文档应视为本 RFC 的派生实现规范，而不是替代物。
