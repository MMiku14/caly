# 逐轮开发日志索引

> 本目录是逐轮开发日志的**历史留档**：只追加、不改写。每轮改了什么、证伪了什么、未尽事项是什么，
> 看对应文件的开头摘要与正文；跨轮总览看 `docs/history/ONBOARDING_NOTES.md §6` 处置表；
> 2026-09-01 之后的变更记录以仓库根 `CHANGELOG.md` 为准（git 历史取代逐轮日志成为主记录）。

## 1. 文件与轮次

| 文件 | 轮次 | 一句话 |
|---|---|---|
| `DEVELOPMENT_LOG_2026-08-27.md` | 第一批接续（至第六十二轮） | 环境接手、effect 执行闭环、契约/parity/scenario 与门禁体系建立 |
| `DEVELOPMENT_LOG_2026-08-30.md` | 第六十三～六十九轮 | durable source index、caller phase-boundary、calyd 真实 effect runtime（第七十～八十七轮无独立日志，记录散见 ADR 与 `docs/status/`） |
| `DEVELOPMENT_LOG_2026-08-31.md` | 第八十八、八十九轮 | 环境接手（工具链/钉死资产重建）与 CLI 全会话走共享 FramePump |
| `DEVELOPMENT_LOG_2026-08-31-round90.md` | 第九十轮 | daemon 服务端写半对称期限 |
| `DEVELOPMENT_LOG_2026-08-31-round91.md` | 第九十一轮 | follow 流静默期限与探活 peek |
| `DEVELOPMENT_LOG_2026-08-31-round92.md` | 第九十二轮 | 请求信封角色取自 hello 协商 |
| `DEVELOPMENT_LOG_2026-08-31-round93.md` | 第九十三轮 | hello 角色 fail-closed 解析 |
| `DEVELOPMENT_LOG_2026-08-31-round94.md` | 第九十四轮 | CLI 回包 request_id 关联 |
| `DEVELOPMENT_LOG_2026-08-31-round95.md` | 第九十五轮 | follow 帧 stream_id 关联 |
| `DEVELOPMENT_LOG_2026-08-31-round96.md` | 第九十六轮 | follow resume/ack 关联 |
| `DEVELOPMENT_LOG_2026-08-31-round97.md` | 第九十七轮 | opened/refusal 帧 request_id 关联 |
| `DEVELOPMENT_LOG_2026-08-31-round98.md` | 第九十八轮 | REFUSAL 码→文档退出码映射 |
| `DEVELOPMENT_LOG_2026-08-31-round99.md` | 第九十九轮 | jobs.follow 失败码→退出码 |
| `DEVELOPMENT_LOG_2026-08-31-round100.md` | 第一百轮 | systemd 托管 calyd（ADR-055） |
| `DEVELOPMENT_LOG_2026-08-31-round101.md` | 第一百零一轮 | systemd unit 内容裁判门禁 |
| `DEVELOPMENT_LOG_2026-08-31-round102.md` | 第一百零二轮 | SIGTERM/SIGINT 优雅关停（ADR-056） |
| `DEVELOPMENT_LOG_2026-08-31-round103.md` | 第一百零三轮 | follow --json 退出码按 verdict 映射 |
| `DEVELOPMENT_LOG_2026-08-31-round106.md` | 第一百零六轮 | jobs.list 部署作业发现面 |
| `DEVELOPMENT_LOG_2026-08-31-round108.md` | 第一百零八轮 | JobLogStore 存储 primitive（ADR-057 切片 1） |
| `DEVELOPMENT_LOG_2026-08-31-round109.md` | 第一百零九轮 | 引擎终态写入 + 启动恢复（ADR-057 切片 2） |

## 2. 阅读约定

- 每份日志自述当轮：目标 → 改动 → 裁判 → 证伪变异 → 未尽事项。
- 轮次编号有缺口（104/105/107 等）：对应轮次的记录不在本交付物内，属上游交付缺口，不在此补写。
- 日志中引用的 `§4.NNN` 是 `docs/history/ONBOARDING_NOTES.md §4` 的缺陷留档条目号。
