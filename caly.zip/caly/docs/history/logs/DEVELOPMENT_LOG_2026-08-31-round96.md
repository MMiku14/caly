# 开发日志 — 第九十六轮（R96）

- **日期**：2026-08-31
- **一句话**：把 follow/reconnect 路径上**最后两处**流关联缺口收口——`--resume` 核对 opened 帧回报的流 id 与 `resumed` 标志、ack 确认帧核对 `stream_id`。至此「关联 id 必须在客户端校验、不能只信帧 kind」这一原则在握手（R71）、请求-应答 `request_id`（R94）、流 DATA/END `stream_id`（R95）、resume 与 ack 确认（本轮）四类帧上全部落地。
- **数字**：`cargo test --workspace` **837 → 842**（CLI 假 daemon e2e +4、arch 结构门禁 +1）；`TEST_FLOOR` 837 → **842**；clippy 去重源码位置 **31 持平**（caly-cli 零新增 warning）；fmt clean。

---

## 1. 靶子

R95 收口 follow 的 DATA/END 帧 `stream_id` 关联后，量选同一 `follow_stream` 的其余帧：

- **resume opened 帧不核对**：`caly follow --resume 7` 请求恢复流 7。daemon 正确时 opened 帧回报 `stream_id=7, resumed=true`；daemon 侧 `streams.get(7)` 早已对未知流拒 NOT_FOUND（`calyd.rs`，`caly_follow_acks_and_a_resume...` 里 `--resume 424242` → exit 13 已有）。但**客户端**把 opened 的 id 当权威存下，从不核对它等于请求 resume 的 7、也不核对 `resumed` 标志。错路/困惑对端回报 `stream_id=9`（或 id 匹配但 `resumed=false`）会被当成「成功恢复」，客户端从错误游标重连。
- **ack 确认帧不核对**：`ack_and_confirm` 发 STREAM_ACK（带流 id + `next_event_index`）后，收到 RESPONSE 确认帧只校 `acked_upto == upto`，不校确认帧的 `stream_id`。daemon 成功确认时两字段都回显（`calyd.rs` KIND_STREAM_ACK 分支写 `stream_id=id, acked_upto=consumed_to`）；别流确认带匹配的 `acked_upto` 会被当成本流游标已落地，resume 从未 ack 的位置错误重放。

两者都是 R94/R95「信 kind/游标、不读关联 id」的同族残留，且 typed 状态机 / daemon 侧关联早已正确（又是「正确实现在别处、生产裸路径缺这层」）。

## 2. 修复（`crates/caly-cli/src/bin/caly.rs`）

1. **resume**：`follow_stream` 捕获 `let resume_expect: Option<&str> = resume;`；opened 帧分支内
   ```rust
   if let Some(expected) = resume_expect {
       if stream_id != expected { return Err(..."asked to resume stream {expected}, but the daemon opened stream {stream_id} ... (PROTO_MISMATCH)"); }
       if resumed != "true"   { return Err(..."did not flag the opened frame as resumed ... (PROTO_MISMATCH)"); }
   }
   ```
   fresh open（无 `--resume`）时 `resume_expect = None`，opened 帧仍为权威分配，不受影响。
2. **ack 确认**：`ack_and_confirm` 在校验 `acked_upto` 后，再读确认帧 `stream_id` 为 `confirmed_stream`，`confirmed_stream != stream_id` 即 PROTO_MISMATCH（点名确认流与 ack 流）。

wire 形状零变更（daemon 本就回显同一 `stream_id` 与 `resumed` 标志）、daemon 零改动、无新依赖、无新 ADR。

## 3. 裁判

### 3.1 假 daemon e2e 四胎（32 → 36）

- `a_resume_opening_a_different_stream_is_refused`：`--resume 7`，opened 报 `stream_id=9 resumed=true`，随后**正常推完流 9**（data/end 都带 9，与 opened id 一致故不被 R95 拒）→ 断言 exit 13 而非跟流 9 到 0、stderr 点名 7/9/resume。
- `a_resume_opened_without_the_resumed_flag_is_refused`：`--resume 7`，opened 报 `stream_id=7 resumed=false`，随后**正常推完流 7** → exit 13（匹配 id 但不挂 resumed 标志的是新流不是恢复）。
- `a_resume_opening_the_requested_stream_flagged_resumed_is_accepted`（反空转）：`--resume 7`，opened `stream_id=7 resumed=true` 后 Succeeded end（读 ack 回确认）→ exit 0。
- `an_ack_confirmation_for_a_different_stream_is_refused`：follow 1 正常推完流 7（data cursor 1 + Succeeded end），客户端 ack 流 7 游标 1，确认帧回 `stream_id=9 acked_upto=1` → exit 13（只回显匹配 `acked_upto` 的别流确认不是本流游标落地）。

真 daemon 的 `caly_follow_acks_and_a_resume_prints_nothing_new` 等既有 resume/follow e2e 全绿（真 daemon 回显正确 id 与 `resumed=true`），无回归。

### 3.2 结构门禁（18 → 19）

`the_cli_correlates_resumes_and_ack_confirmations_to_their_stream`：钉 follow 体内出现 resume 期望捕获、`stream_id != expected` 真实比较、`resumed != "true"` 检查、错误点名 resume；`ack_and_confirm` 体内出现 `confirmed_stream` 绑定与 `confirmed_stream != stream_id` 真实比较、PROTO_MISMATCH（比较表达式，非符号出现）。

## 4. 证伪（`scripts/archive/falsify_round96.py`）

| 变异 | 改动 | 咬住 | 结果 |
|---|---|---|---|
| **M1** 删 resume id 比较 | `if stream_id != expected` → `if false` | resume-异流 e2e 红（跟流 9 到 0）+ 门禁红；resumed-flag/happy/ack e2e 仍正确 | **BIT** |
| **M2** 删 resumed-flag 比较 | `if resumed != "true"` → `if false` | resume-无标志 e2e 红（接受 resumed=false）+ 门禁红；异流/happy/ack 仍正确 | **BIT** |
| **M3** 删 ack 确认 id 比较 | `if confirmed_stream != stream_id` → `if false` | foreign-确认 e2e 红（信任别流确认 exit 0）+ 门禁红；三个 resume e2e 不受影响 | **BIT** |

三半（resume-id / resumed-flag / ack-确认-id）各自独立钉住、互不连带。

### 4.1 当轮留档：一条险些假绿的测试设计教训

M2 第一次跑**没咬**（rflag e2e 在变异下仍 ok）。排查发现：第一版 resume 两胎的假 daemon 在 opened 帧之后**只 `sleep(5s)`、不再发流帧**。于是无论校验在不在：

- 校验在 → 在 opened 分支 exit 13；
- 校验被删 → CLI 进流模式等 data/end，假 daemon 什么都不发，CLI 走读超时（exit 11）或连接关闭路径——**仍然是非 0**。

两种代码测试都「绿」，裁判根本没区分它们。根因是**被拒路径的假 daemon 没有走到「若接受会发生什么」的 happy 后续**。修法：被拒裁判必须让假 daemon 在校验点之后**正常把流推完**（data + Succeeded end + 读 ack 回确认）。这样校验存在时在校验点 exit 13、校验被删时 CLI 接受并一路 exit 0——裁判才真的因「接受了本该拒绝的东西」而红。

**规则**：变异下的「绿」必须来自「接受了本该拒绝的东西」（exit 0 / 打印了错帧），而不是来自另一条失败路径（超时、连接关闭）。构造被拒裁判时，假对端要把「假如这条校验不存在、对话本该如何成功收尾」也演完。

（另：`cargo test` 只接受一个位置 TESTNAME 过滤器，证伪脚本里不能并排传 `resume ack_confirmation`；改为跑整个 e2e 二进制再按测试名匹配 FAILED 行。）

## 5. 明确没做

- **多流并发关联**：仍单值 `opened_stream` / 单 resume 期望；v0 一次 follow 一条流。单会话多流并发需 typed loop `streams` 表（`HashMap<stream_id, state>`）生产化——§13#3 主体。
- **不改 wire 帧形状、不改 daemon**：daemon 侧 resume（`streams.get`）与 ack（`apply_ack` + 回显同一 `stream_id`）关联早已正确；本轮纯 CLI 客户端边界防错。
- **无新依赖、无新 ADR**：对齐 typed 状态机既有不变量，不引新决策。
- trace_id 常量化（非洞）、`client_loop.rs` 硬编码 30_000 deadline（在未启用 typed 骨架里）仍记录为后续 §13#3。

## 6. 收尾

- `regenerate_test_census.py` → `files=105 total=842 rows=105`；`--check` 一致。
- `scripts/check.sh`：`TEST_FLOOR` 837 → 842；clippy 基线 31 不动。
- 文档：STATUS §8.30（新）+ census 两行描述（dependency_direction 19 / caly_cli_e2e 36）、CENTERLINE/ROADMAP/STATUS/ONBOARDING 数字 837→842；ONBOARDING §4.170（新）+ 处置表 6.122（新）、「不做」标题 6.122→6.123；本日志入 README 三索引。
- `falsify_round96.py` M1/M2/M3 全 BIT；`.r96bak` 收尾 sweep 干净。
