# 开发日志 — 第一百零二轮（R102）

- **日期**：2026-08-31
- **一句话**：让 `calyd` 捕获 **SIGTERM/SIGINT 优雅关停**——systemd（ADR-055）`systemctl stop/restart` 不再用信号默认动作硬杀 daemon、把活核心留给崩溃恢复，而是 `sigwait` 收信号 → `StdEffectRuntime::shutdown(grace)` 优雅停核撤路由 → exit 0。这是 `ADR-043 §2.5/§5` 显式推迟、由 systemd 触发的 TERM 信号面，伴 **ADR-056** 收束。
- **数字**：`cargo test --workspace` **857 → 859**（calyd_wire 42→43 集成裁判 +1、dependency_direction 23→24 结构门禁 +1）；`TEST_FLOOR` 857 → **859**；clippy **31 持平**；fmt clean。

---

## 1. 缘起与量选

R100 交付 systemd 托管、R101 给 unit 上了内容裁判。R101 量选时识别并显式推迟了邻居：calyd 不捕获 SIGTERM。`systemctl stop/restart calyd` 每次发 SIGTERM；此前 calyd 不装任何信号处理器，SIGTERM 走默认动作（立即终止）：

- 活的代理 Core 子进程不经 `StdEffectRuntime::shutdown(grace_ms)` 优雅停——该方法**早已存在**（取走活核心句柄、撤路由、`proc.stop(grace)` 宽限自然退出/期满击杀、reap），且被每个 spawn 真核的裁判调用，但 calyd **进程关停路径从不调它**；
- 每次干净的运维停机都走「硬杀 → 孤儿 Core → 下次启动崩溃恢复（RFC-0005 §12）」。

这正是 `ADR-043 §5` 的原话：「TERM/信号面：等第一个真正需要优雅关停语义的调用方（届时伴 ADR）」。systemd 就是那个调用方 → **ADR-056**。

硬约束（代码核实）：std 无 Unix 信号 API；`caly-io-std` 与 caly-daemon **lib** 都 `forbid(unsafe_code)`；全仓无 libc/signal-hook crate（外部 crate 须 ADR）；引擎/门面从不请求「等信号」。

## 2. 决策（ADR-056）与实现

- **信号面放 calyd bin 组合根，不进 caly-io Port**：引擎/门面不消费「等进程信号」，那是顶层进程控制（与 `Proc::spawn/stop` 管**子进程**不同），符合 ADR-011「bin 是唯一接触宿主进程控制处」。
- **sigwait 形态**（非自管道/非 handler）：主线程在 spawn 任何 accept/worker 线程**之前** `pthread_sigmask(SIG_BLOCK, {SIGTERM,SIGINT})`（新线程继承掩码，默认动作杀不到任何线程）；专用 waiter 线程 `sigwait` 收信号——POSIX 推荐的「非处理器上下文同步等信号」，闭包可自由加锁/打印（无 async-signal-safe 约束）。收到即 `shutdown(10s)` → `process::exit(0)`。
- **手写最小 FFI、不引 crate**：`extern "C"` 仅 `pthread_sigmask`/`sigwait`/`sigaddset` + 常量 SIGTERM=15/SIGINT=2；sigset 用 128 字节不透明 `#[repr(C)]` 结构、只整体传指针、**不读写字段**（平台布局交 libc）。unsafe 局部封装在模块内，对外只暴露安全 `install_term_handler`。
- **文件**：
  - 新增 `crates/caly-daemon/src/bin/support/signal.rs`（cfg unix FFI waiter + 非 unix no-op）；
  - `calyd.rs`：`#[path = "support/signal.rs"] mod signal;`、`SHUTDOWN_GRACE_MS=10_000`（取 < unit `TimeoutStopSec=15s`）、`bootstrap_app` 改为返回 `(DaemonApp, Option<Arc<StdEffectRuntime>>)`（引擎仍收 `Arc<dyn EffectRuntime>`；关停需要具体类型的 `shutdown`）、main 在绑定监听/spawn worker 之前安装处理器。

### 踩到的结构坑（留档）

1. **`src/bin/` 下每个 `.rs` 都被 cargo 当独立 binary**：第一版放 `src/bin/signal.rs` 直接 `E0601: main function not found in crate signal`。改 `src/bin/calyd/main.rs` 子目录虽合法，却把 3 个既有 gate 定位的 `src/bin/calyd.rs` 路径打断（全红）。最终：main 保持 `src/bin/calyd.rs`，信号模块放 `src/bin/support/signal.rs`（无 main.rs 的 support/ 子目录不被当 bin），`#[path]` 引入——既有 gate 路径零破坏。
2. 集成裁判 `wait` 掉的子进程不要用占位进程替换：Drop 对已 reap 子进程的 kill/wait 返回 Err 已被 `let _` 忽略，且 Drop 还负责清理 scratch 目录。

## 3. 裁判

- **集成** `calyd_wire::sigterm_shuts_calyd_down_gracefully_with_exit_zero`：spawn 真二进制 → 等 port-file（=已监听）→ `/bin/kill -TERM <pid>` 发真信号 → bounded 15s wait，断言 `status.code()==Some(0)`（优雅）而非 `status.signal()==Some(15)`（默认动作杀）。测试侧 `/bin/kill` 是 harness（文件级 `disallowed_methods` 豁免）；生产用 sigwait 接收、`Proc::stop` 停核，不 spawn kill（ADR-043 §2.5 否决的生产 `/bin/kill` 不复活）。
- **结构门禁** `dependency_direction::the_daemon_installs_a_term_signal_handler_that_shuts_the_core_down`：bin 声明并调用 `signal::install_term_handler(`、关停闭包调 `.shutdown(`、有界 `SHUTDOWN_GRACE_MS`；信号模块含 `sigwait`/`pthread_sigmask`/安全 `fn install_term_handler`。

## 4. 证伪（scripts/archive/falsify_round102.py）

| 变异 | 改动 | 被咬裁判 | 结果 |
|---|---|---|---|
| **M1** | 删 install 调用（编译仍过、不装处理器） | 集成（死于 signal 15）+ 门禁（无 install_term_handler） | BIT/BIT |
| **M2** | 闭包内去掉 `.shutdown(`（仍 exit 0） | 门禁（关停路径不调 shutdown）；集成仍绿（退出码没变） | BIT |

M2 集成保持绿是关键：证明结构门禁独立钉住「优雅停核」这个动作，而不只是「退出码 0」。还原 sha256 校验。

## 5. 收尾

- census：`regenerate_test_census.py` + 两行手写描述（calyd_wire 43 / dependency_direction 24），`--check` 一致（files=105 total=859）。
- 文档：ADR-056、STATUS §8.36、ONBOARDING §4.176 + 处置表 6.128（「不做」标题 6.128→6.129）、CENTERLINE 859、本日志、README 索引。
- `check.sh` 全绿（859/floor 859/clippy 31/fmt clean）；floor 撕开测试见 FAIL 后还原；无 `.r102bak/.orig` 残留。

## 6. 明确没做（后续）

- in-flight 请求/流连接的优雅排空（stop accepting → 服务完当前会话 → 退）。
- Windows SCM 关停面（非 unix 当前是 no-op）。
- 信号面提升为 `caly-io` Port（仅当未来引擎/门面逻辑需要复用「等信号」）。
- 子进程 TERM 面：`Proc::stop` 对 Core 仍期满 SIGKILL（ADR-043 那条边界不变——本轮是 calyd **进程**收信号优雅退出，不是改停子进程的方式）。
