# 开发日志 — 第一百零三轮（R103）

- **日期**：2026-08-31
- **一句话**：`caly follow <id> --json` 的流式结束帧退出码改为按 verdict 映射——json 分支此前打印 payload 后无条件 exit 0、完全不读 outcome（人类 records 分支早已 Failed→1/Cancelled→15/TimedOut→11），失败作业用 `--json` 跟流也报成功；现在 json 与 records 共用同一判决函数（`--json` 只改渲染不改退出码，EXIT_CODES §1.4）。
- **数字**：`cargo test --workspace` **859 → 862**（caly_cli_e2e 45→47 两胎 +1 组、dependency_direction 24→25 结构门禁 +1）；`TEST_FLOOR` 859 → **862**；clippy **31 持平**；fmt clean。

---

## 1. 缘起与量选

R100–R102 完成 systemd 三连后回到退出码诚实性主线。R99 修了一次性 `caly job <id>`（records + json 两应答臂都按 failure_code 映射）。本轮量选「R99 的流式对位」时，先丈量了更大的缺口——流式 END 帧只携带 outcome 枚举、不携带稳定 failure_code（要让 `caly follow` 失败也按公共码 exit 而非笼统 1，须 END 帧加字段，跨 caly-api DTO / daemon PumpStep / wire / CLI，属 wire 形状扩展、先 ADR；本轮丈量确认失败码数据在 daemon `projection.summary.failure_code` 手边但不上 END 帧）——判为跨轮大活。

但丈量中发现一个**纯 CLI、不改 wire、可独立收口**的同族洞：STREAM_END 帧处理里**非 json 分支早已正确映射 outcome，json 分支却无条件 `return Ok(ExitCode::Success)`**。这与 R99 是同一族（「json 分支习惯打印原文就 exit 0，把渲染和判决错误耦合」），只是发生在流式 follow 的结束帧。既有 `caly_follow_exits_nonzero_for_a_failed_job` 只测非 json，故漏网。

## 2. 修复（`crates/caly-cli/src/bin/caly.rs`）

抽共享助手：

```rust
fn stream_end_exit_code(records) -> Result<ExitCode, String> {
    if reason == "state-gap" { 提示 resume; return Ok(CursorStale); }   // 14，两形态共用
    match outcome { "Succeeded"=>Success(0), "Failed"=>GeneralFailure(1),
                    "Cancelled"=>Cancelled(15), "TimedOut"=>Timeout(11),
                    other=>Err("the stream ended without a verdict") } // → 13
}
```

STREAM_END 臂改为：先打印（json 逐字 payload / records 的 data 帧此前已打）→ ack 已消费游标 → **两形态都 `return stream_end_exit_code(&records);`**。json 分支不再提前返 Success。不改 wire（END 帧仍只 outcome 枚举）、无新依赖。

## 3. 裁判

- **假 daemon e2e 两胎**（json 会话 hello_ack `encoding=json`、opened/data/END/ACK 帧皆 json、v0 JSON 值全字符串）：
  - `a_json_follow_of_a_failed_job_exits_nonzero_like_the_human_render`：END `outcome=Failed` → exit **1 非 0**；
  - 反空转 `a_json_follow_of_a_succeeded_job_stays_exit_zero`：END `outcome=Succeeded` → exit 0。
- **结构门禁** `the_follow_stream_end_exit_code_is_shared_between_json_and_records`：助手存在、四 outcome 映射臂齐、state-gap→CursorStale、臂内 `return stream_end_exit_code(&records);`，且**从 json 逐字打印点（`String::from_utf8_lossy(&payload)`）到共享判决点之间不得出现 `return Ok`**。

## 4. 证伪（scripts/archive/falsify_round103.py）

| 变异 | 改动 | 被咬裁判 | 结果 |
|---|---|---|---|
| **M1** | json 打印后提前 `return Ok(ExitCode::Success)`（编译过，共享调用沦为死代码） | 失败 e2e（得 0 非 1）+ 门禁（json 打印→判决间出现 return）；成功 e2e 仍绿 | BIT/BIT |
| **M2** | 删共享调用、两形态改无条件 Success | 失败 e2e + 门禁（`return stream_end_exit_code` 消失） | BIT/BIT |

M1 第一版门禁假绿（只 contains 共享调用，但提前 return 后调用仍在死代码里）；收紧成「两点之间禁 `return Ok`」才咬。还原 sha256 校验。

## 5. 留档规则

1. **「调用了共享函数」的断言抓不到「提前 return 让共享调用成死代码」**：凡要求「两条路径都经过共享判决」，除断言共享判决存在，还要断言**没有分支能绕过它**（界定两点之间禁止提前返回）。
2. **json/records 双形态退出码必须共用同一判决函数**：R99（一次性查询）与 R103（流式 follow）同族——json 分支历史上习惯「打印原文就 exit 0」。修法都是抽共享判决、两形态打印后统一走它。
3. **找缺口手法**：对每个「操作 × 编码（records/json）」组合问「失败时退出码非 0 吗」。R99 覆盖一次性 job 两形态，R103 补流式 follow 的 json 形态。

## 6. 收尾

- census：`regenerate_test_census.py` + 两行手写描述（caly_cli_e2e 47 / dependency_direction 25），`--check` 一致（files=105 total=862）。
- 文档：STATUS §8.37、ONBOARDING §4.177 + 处置表 6.129（「不做」标题 6.129→6.130）、CENTERLINE 862、本日志、README 索引。
- `check.sh` 全绿（862/floor 862/clippy 31/fmt clean）；floor 撕开测试见 FAIL 后还原；无 `.r103bak/.orig` 残留。

## 7. 明确没做（后续）

- **流式 END 帧携带稳定 failure_code**：仍只 outcome 枚举；要让 `caly follow` 失败按公共码 exit（而非笼统 1）须 END 帧加字段（跨 caly-api DTO / daemon `PumpStep::End` / wire / CLI follow 映射），属 wire 形状扩展、先 ADR。失败码数据在 daemon `projection.summary.failure_code` 手边。
- in-flight 请求/连接的优雅排空（R102 follow-up）。
