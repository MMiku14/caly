# Caly 开发日志 — 2026-08-31（第九十轮：daemon 服务端写半对称期限）

第八十九轮给生产 CLI 全会话接上共享 `FramePump`（关闭客户端写半无超时面）。本轮沿同一条
`ROADMAP §13#3` 做**服务端对位**：daemon 写方向的期限。无新 ADR、无新依赖、无 wire 形状变更。

---

## 1. 靶子（量选与判据）

### 1.1 现象

`crates/caly-daemon/src/bin/calyd.rs` 在两个相位点设**读**期限（R45/46：accept 后
`HELLO_TIMEOUT` 5s 给陌生人；hello 成功后提升 `--session-idle-ms` 默认 30s 给会话），但
`grep set_write_timeout` 全文件零命中——**写方向没有任何期限**。

### 1.2 为什么是缺口

一个 accept 后停止读取的对端（TCP 接收窗口耗尽但连接不关）会让内核发送缓冲填满，此后
`write_all` 无限阻塞。calyd 是**每连接一线程**，所以这等于：一个不读的客户端永久占住一个
daemon 线程。R53 的 dead-peer 探针（`probe_peer`）救不了它——探针只在**流泵的 Wait 分支**
跑，普通响应/ack 路径不探活。这正是 R89 客户端写半缺口的服务端镜像。

### 1.3 判据（可证伪）

> daemon 每个连接相位都必须与读期限**对称**地安装写期限：peer 不读时，写在有限时间内以
> `WouldBlock`/`TimedOut` 返回并回收线程；hello 阶段 5s、会话阶段 idle（默认 30s），与读同值。

---

## 2. 实现

`crates/caly-daemon/src/bin/calyd.rs`：

- 新增 `set_transport_deadlines(stream: &impl WireIo, deadline) -> io::Result<()>`：同一点
  **同时**设 `set_read_timeout` + `set_write_timeout`。一个相位一个 setter——两处分别设会漂移。
- accept 循环：`set_transport_deadlines(&stream, HELLO_TIMEOUT)`（陌生人读写都得快；失败即
  记日志 `continue`，不入线程）。
- hello 成功后：`set_transport_deadlines(stream, session_idle)?`（会话两方向同 idle 上限）。
- 流泵 Wait 的 50ms `set_read_timeout` **保持不动**——那是 peek（读）用的收窄，写期限全程保持
  会话 idle 值。
- 合法慢客户端不受影响：正常响应/ack 远小于 30s，只是与读同一上限。

## 3. 裁判

### 3.1 确定性机制测试（避开 flake，`§4.157` 教训）

`calyd.rs` 单测 `a_peer_that_never_reads_blocks_the_daemon_write_only_until_the_write_deadline`
（`#[cfg(unix)]`）：进程内 `UnixStream::pair()`，一端交给 `WireStream::Unix`、另一端**持有但
永不读**；`set_transport_deadlines(200ms)` 后连续 `write_all` 直至缓冲填满，断言：

- 返回的错误 kind ∈ {`WouldBlock`, `TimedOut`}（有界超时，不挂起）；
- 整体在 5s 内返回（相对 200ms 期限宽松，防沙箱抖动，但远低于无期限的永久挂起）。

不用「灌满真实 TCP 缓冲看线程死没死」的 E2E——那依赖缓冲尺寸与睡眠时序，是 R53/R72 judge 竞态
同族；socket pair 让「写阻塞 + 写期限有界返回」在进程内 0.4s 确定可判。

### 3.2 结构门禁

`dependency_direction.rs::the_daemon_bounds_the_write_deadline_symmetrically_with_the_read_one`：
生产 calyd bin 必须定义 `set_transport_deadlines` 且函数体同时含 `set_read_timeout`/`set_write_timeout`，
并在 accept/hello 与会话两个相位点都安装（调用点 ≥2）；带「calyd bin 必须存在」反空转断言。

### 3.3 证伪（`scripts/archive/falsify_round90.py`，3 变异全咬，均编译绿、判据红）

- **M1**：从 helper 删 `set_write_timeout` 行 ⇒ 结构门禁在「write deadline」断言处红。
- **M2**：删 accept 相位的安装调用（只剩会话一个相位点）⇒ 门禁「两个相位点」断言红。
- **M3**：机制测试里去掉 `set_transport_deadlines` ⇒ 测试挂起/失败（写无期限则永不返回——证明
  期限是唯一有界来源）。

备份-还原按内容+mtime 双还原、sha256 校验；收尾 `*.r90bak` 为空。

## 4. 数字与文档

- 测试普查：`files=105 total=816 rows=105`（+2：calyd bin 单测、arch 门禁；两文件分别 3 与 13）；
  `TEST_FLOOR` 814 → **816**。
- `ONBOARDING_NOTES`：`§4.164` + 处置表 `6.116`（「不做」标题顺延 6.117）+ 当前快照数字。
- `IMPLEMENTATION_STATUS`：§3/§2 数字 816、新增 `§8.24`、§2 未覆盖清单与 §5.4 措辞；
  `CENTERLINE_PROGRESS`、`ROADMAP`（§1bis + §13#3 残余）同步。

## 5. 验证

- `cargo check --workspace --all-targets`：0 warning；`cargo fmt --all -- --check`：0 行。
- `scripts/check.sh` 连跑两次：**816 passed / floor 816 / clippy 31 / fmt clean**，结论一致。

## 6. 明确没做

共享 timeout scheduler、typed `send_request_frame` 生产化、`SessionRegistry` 生产化、UDS peek
（`§13#3` 主体）；无新 ADR。
