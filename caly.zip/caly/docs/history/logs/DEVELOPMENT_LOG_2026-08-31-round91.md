# Caly 开发日志 — 2026-08-31（第九十一轮：follow 流静默期限 + recv 探活不借用读预算）

第九十轮给 daemon 服务端补了写半对称期限（R89 的服务端对位）。本轮沿同一条 `ROADMAP §13#3`
做**客户端 follow 流对位**：一个被跟踪的 Job 流，等待对端说话的期限应该是**流的静默期限**，
不是请求-应答的 3s。过程中证伪「不咬」逼出了第二处、也是更深的根因——`FramePump::recv` 的
探活 peek 借用了调用方的整段读预算。无新 ADR、无新依赖、无 wire 形状变更。

---

## 1. 靶子（量选与判据）

### 1.1 现象（第一处缺陷：流期限错配）

`caly follow <job>` 打开一个 Job 事件流。Job 流是 lossless-resumable 流
（`IPC_STREAM_POLICY`：`LosslessResumable`/`AckRequired`/gap→Resume），**不是**一问一答。
daemon 侧的流泵在没有新事件时走 `PumpStep::Wait`，而 `job_stream.rs` 的 Wait **不发帧**——
空 Data 等于谎称有进展。真实核心的 spawn/probe（如 mihomo apply）可以几十秒没有事件。

但 CLI 的 `Session` 用 `FramePump::new(stream, Some(READ_TIMEOUT))`，`READ_TIMEOUT=3s`；follow
循环读每一帧都沿用这个 3s 读期限，opened 帧之后也不切换。于是跟踪一个**健康的长作业**会在
3s 静默后误报：

```
caly: timed out after 3000ms waiting for the daemon to speak   (exit 11)
```

现有的 follow e2e 全用快 simulated 作业（事件瞬间到齐），这个面从来没被跑过。

### 1.2 判据（可证伪）

> follow 在 opened 帧之后，单帧读期限必须是**流的静默期限**（容忍 Wait 级的静默），而不是请求/
> 应答的 3s；同时不回归——hello/请求阶段静默的 daemon 仍须在短期限内 exit 11。

### 1.3 证伪「不咬」逼出第二处缺陷（探活借用读预算）

第一版修复只做了「opened 后加宽到 30s」（`STREAM_IDLE_TIMEOUT` + `enter_stream_mode` +
`set_idle`），并写了 e2e：假 daemon opened 后**静默 4s**（>3s 请求期限、<30s 流期限）再推
data/end。修复后 e2e 过；但做证伪变异（**删掉** `enter_stream_mode()` 调用）时，e2e **仍然
通过**——4s 静默并没有在 3s 超时。

顺着「裁判测的性质和改的性质差一层」查下去（`§4.157` 同族），定位到 `FramePump::recv`：

```rust
pub fn recv(&mut self) -> ... {
    match self.stream.probe_peer() {   // TCP: peek 1 字节
        ...
        Ok(Alive|Indeterminate) => wire_read_frame(&mut self.stream),  // read_exact
    }
}
```

TCP 的 `probe_peer` 是 `peek`：阻塞到「来一个字节」或**读超时**；超时时 `WouldBlock/TimedOut`
被映射成 `PeerProbe::Alive`（对端还在，只是没说话）。旧代码让这个 peek 用**调用方的整段读
期限**。于是静默对端：

1. 先在 `peek` 里阻塞满一个读期限（超时 → 映成 Alive，吞掉）；
2. 再在 `read_exact` 里阻塞满**第二个**读期限（这次超时才作为 read 错误上抛）。

有效静默预算 ≈ **2× 读期限**。所以 4s 间隙 < 2×3s=6s，第一版只加宽流期限对这个间隙**根本不起
作用**，证伪当然不咬。daemon 的流泵早就用了正确形状（Wait 分支把读期限收窄到 50ms 做 peek、
随后恢复 `session_idle`），共享的 `FramePump::recv` 却没有对位。

---

## 2. 实现

### 2.1 `crates/caly-ipc/src/duplex.rs`

- **`FramePump::set_idle(Option<Duration>) -> io::Result<()>`**：与 `new` 同形状——`Some(d)` 同点
  设 read+write，`None` 双向清空；更新 `self.idle`。`idle()` 回报实时期限。
- **`FramePump::recv` 探活收窄/恢复**：新增 `const PROBE_WINDOW: Duration = 50ms`（对齐 daemon
  流泵 Wait 的 50ms peek）。recv 先把读期限设成 `PROBE_WINDOW`、peek、**恢复调用方读期限**
  （`self.idle`）再进 `wire_read_frame` 的阻塞读。探活不再花读预算。收窄/恢复各自的 setter
  失败都显式报错（不静默）。
- **`MemoryIo`（测试双工）**：新增 `read_deadline`/`write_deadline: Cell<Option<Duration>>` 与
  `deadlines()`；新增 `read_deadline_history: RefCell<Vec<Option<Duration>>>` 与
  `read_deadline_history()`（WireIo 是 `&self`，故用 Cell/RefCell 内部可变性），记录每次
  `set_read_timeout` 的值，供「探活短窗口 + 读后恢复 idle」的进程内裁判断言。

### 2.2 `crates/caly-cli/src/bin/caly.rs`

- 新增常量 `STREAM_IDLE_TIMEOUT = Duration::from_secs(30)`（`CONNECT_TIMEOUT`/`READ_TIMEOUT` 仍
  各 3s，不动）。
- 新增 `Session::enter_stream_mode()`：调 `pump.set_idle(Some(STREAM_IDLE_TIMEOUT))`，双向加宽。
- follow 循环在 `WIRE_KIND_RESPONSE`（opened 帧）分支调 `session.enter_stream_mode()?;`——只在
  流打开后加宽；请求/应答动词（status/apply/…）不经此路径，保持 3s。
- `Session::recv()` 的超时文案改用 `self.pump.idle()` 的实时毫秒数（原来写死 3000ms，流模式会
  说谎）；`idle()` 为 `None` 时回退 `READ_TIMEOUT`。

wire 形状、握手、ack/confirm 对话均不变。

---

## 3. 裁判

### 3.1 e2e（真实跨进程，含静默间隙）

`caly_cli_e2e.rs::caly_follow_survives_a_silent_gap_longer_than_the_request_deadline`：假 daemon
（裸 TCP，测试自带最小 wire 写法）走完整 follow 对话——

1. 收 hello、回合法 records hello_ack（CLI 会校验，R71）；
2. 收 follow open 请求；
3. 发 opened 帧（kind 4，`stream_id=7 resumed=false`）；
4. **静默 4s**（`sleep`）；
5. 发一行 data（kind 6）+ Succeeded end（kind 7）；
6. **读 CLI 的 ack 帧（kind 8）并回确认帧（kind 4，`acked_upto=1`）**——CLI 在 end 后发一次
   ack 并等确认作为对话最后一帧（`ack_and_confirm`），少了这步会撞上 broken pipe 变 exit 13
   （本轮 e2e 的第二个坑，见 §5）。

断言：总耗时 ≥ 4s（真的穿过静默间隙，不是竞态绕过）、exit 0、gap 后那行被打印。删
`enter_stream_mode` 的变异下：3.16s 以 `timed out after 3000ms` exit 11。静默 daemon 仍 exit 11
由既有 `a_silent_daemon_times_out_as_exit_11_not_a_hang` 另守（不回归）。

### 3.2 duplex 进程内单测（确定性，无墙钟/无 socket 时序）

- `set_idle_rebounds_both_directions_and_reports_the_live_deadline`：3s→30s，断言
  `deadlines()` 双向同步、`idle()` 报新值。
- `set_idle_none_clears_both_deadlines`：清双向 + `idle()==None`。
- `recvs_probe_uses_a_short_window_and_restores_the_idle_deadline`：以 30s idle 构造 pump，recv
  （Alive 探针 + 空 cursor = Ok(None)）后断言 `read_deadline_history()`：**末尾**是 idle 30s
  （阻塞读跑在调用方预算上），且序列中**出现过**短于 idle 的期限（探活窗口）。不收窄/不恢复
  的变异下历史只有 `[Some(30s)]`，断言红。

### 3.3 结构门禁

`dependency_direction.rs::the_cli_widens_a_follow_stream_to_its_own_idle_deadline_when_opened`
（生产 `caly` bin）：

- (a) 含 `STREAM_IDLE_TIMEOUT` 常量，且 `READ_TIMEOUT` 仍在（加宽只对流，不是撤掉快答期限）；
- (b) `fn enter_stream_mode(` 函数体内调 `set_idle` 且引用 `STREAM_IDLE_TIMEOUT`（read-only 绕行
  加宽即红——对称规则）；
- (c) follow opened 分支经接收者调用 `.enter_stream_mode()`（≥1 调用点）；
- bin 存在性反空转。

### 3.4 证伪 `scripts/archive/falsify_round91.py`（3 变异全 BIT，均编译绿、判据红）

- **M1**（删 follow opened 分支的 `enter_stream_mode()` 调用）：e2e 在 3.16s "3000ms" 超时
  exit 11 **且** 门禁失调用点——双咬。
- **M2**（recv 探活不收窄/不恢复，peek 借用调用方整段读期限）：duplex 期限序列断言红
  （历史只剩 `[Some(30s)]`，无短窗口）。
- **M3**（`enter_stream_mode` 改为 `inner_mut().set_read_timeout(..)` 的 read-only 绕行，绕过
  对称的 `set_idle`）：门禁 (b)「必须经 set_idle 双向」断言红。

---

## 4. 收口数字

- `cargo test --workspace`：816 → **821**（+5：e2e 1、duplex 单测 3、arch 门禁 1）；
  `check.sh TEST_FLOOR=821`。
- clippy 唯一源码位置：**31**（= 基线，未抬；新增代码首版 `map_or(false,..)` 触发一条
  `unnecessary_map_or`，按纪律改 `is_some_and` 修代码，不加 `#[allow]`）。
- rustfmt：只对本轮碰过的文件跑 `rustfmt --edition 2021`（duplex.rs、caly.rs、
  caly_cli_e2e.rs、dependency_direction.rs），不用 `cargo fmt --all`。
- 普查 `regenerate_test_census.py` 重新生成（files=105 total=821 rows=105），描述列手写补
  R91。

## 5. 本轮踩到的坑（留档 `ONBOARDING_NOTES §4.165`）

1. **证伪「不咬」是信号，不是流程失败**。第一版只加宽流期限，删加宽的变异却让 4s 间隙 e2e
   仍然过——说明裁判测的性质和改的差一层。顺藤摸到 `recv` 的 peek 吞读预算（有效静默预算
   2×）。把裁判放宽到能过是错的，挖到第二根因才是对的。
2. **假 daemon 编排多帧对话要对齐「谁是最后一帧」**。CLI 在 STREAM_END 后发 ack 并**等确认帧**
   才退出（`ack_and_confirm`，确认是对话最后一帧）。假 daemon 发完 end 就关连接，CLI 撞
   broken pipe / "peer closed" 变 exit 13。必须读 ack（kind **8**，不是 9——第一轮按 9 写，
   `WIRE_KIND_STREAM_ACK=8`）再回确认帧（kind 4，`acked_upto` 与 data 的 `next_event_index`
   一致）。
3. **进程内记录 setter 调用序列**是判「期限被怎么设置」的确定性手法（MemoryIo 的
   `RefCell<Vec<_>>` 历史），比灌 TCP 缓冲/睡眠时序稳（`§4.157`/`§4.164` 同族）。

## 6. 明确没做

共享 timeout scheduler（统一期限调度）、typed `send_request_frame` 生产化（R76 排除 naive
接线）、UDS peek（std 无 peek，需 libc/nix，须先 ADR）；`SessionRegistry` 生产化已否决（仅
harness 用是设计）。本轮 wire 形状不变、无新 ADR、无新依赖。
