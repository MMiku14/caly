# 开发日志 — 第九十五轮（R95）

- **日期**：2026-08-31
- **一句话**：CLI 的 `caly follow` 现在校验每个 STREAM_DATA / STREAM_END 帧的 `stream_id` 等于 opened 帧命名的流——把 R71（握手）/R94（请求-应答 `request_id`）的「只信帧类型、不读关联内容」同族洞，在 lossless-resumable **流**路径上收口。
- **数字**：`cargo test --workspace` **833 → 837**（CLI 假 daemon follow e2e +3、arch 结构门禁 +1）；`TEST_FLOOR` 833 → **837**；clippy 去重源码位置 **31 持平**（caly-cli 零新增 warning）；fmt clean。

---

## 1. 靶子是怎么量出来的

R94 收口 `ask()` 的 `request_id` 关联时，显式把 follow 流路径划出范围（「follow 流不涉及——流帧/ack 确认不按请求 id 关联」）。本轮回到 §13#3 残余候选清单量选：

- **trace_id 恒 `caly-cli-{request_id}`**：查 `dialect::request_payload` 发现 trace_id 是从 request_id 派生（`format!("caly-cli-{request_id}")`），daemon 逐字转发（`handler.rs`「identity is forwarded, never fabricated」）。v0 每次动词都是新鲜连接、单在途，request_id=1 关联成立，trace_id 只是日志名——**不是安全洞，排除**。
- **`client_loop.rs:64` 硬编码 `Some(30_000)` deadline**：在 R87 明确**未启用**的 handshake-only `ClientLoop::send_request_frame` 里。这是闲置的 typed loop 骨架，生产 CLI 走自己的收发，不调它。生产化（deadline 透传 + 接线）是 §13#3 大活「typed send_request_frame 生产化 / 共享 timeout scheduler」，不适合一轮——**记录为后续，不在本轮**。
- **follow 流的帧关联**：通读 `follow_stream()` 发现真洞——

  opened 帧（`WIRE_KIND_RESPONSE`）带回的 `stream_id` 只 `eprintln!` 到 stderr 供 `--resume` 用，**从不存为本次会话的权威 id**。此后：

  - `WIRE_KIND_STREAM_DATA` 帧：`note_consumed` 读各自的 `stream_id` 去拼 ack 游标，但**从不与 opened 的 id 比对**——别流（如 999）的事件行会被当成本流事件 `println!` 出去；
  - `WIRE_KIND_STREAM_END` 帧：`reason`/`outcome` 直接决定退出码（state-gap→14、Succeeded→0、Failed→1、Cancelled→15、TimedOut→11），也**不核对 stream_id**——对端推一个别流的 `outcome=Succeeded` END 帧，CLI 会当成被 follow 的作业成功而 `exit 0`。

  **为什么这是真边界而非误判**：wire 协议单会话多路复用——typed 状态机 `caly_ipc::client.rs` 的 `ClientSession::streams` 按 `stream_id.0` 键控，`observe_stream_frame` 对未知流 id 返回 `UnexpectedStream`（"stream frame for unknown stream {}"）；daemon 侧 `calyd.rs` 在 opened（1183）、data（1260）、end（1299 state-gap / 1331 outcome）三帧上都写同一 `logical_stream`。所以「别流帧在协议上合法可达」，而生产 CLI 的手写 follow 裸路径（R89 后虽经共享 `FramePump` 收发，但帧的**内容**关联仍缺）没有 typed 状态机那层 streams 表核对。这又是「正确的实现（typed loop）已存在、但没接到生产裸路径上」的一例（ONBOARDING `§2.2` 同类问题）。

这是 **R71（握手）→ R94（request_id）→ R95（stream_id）** 同一原则「关联 id 必须在客户端校验、不能只信帧 kind」在三种时序形状（握手 / 请求-应答 / lossless-resumable 流）上的第三次应用。

## 2. 修复（`crates/caly-cli/src/bin/caly.rs`）

- `follow_stream` 新增 `let mut opened_stream: Option<String> = None;`，在 opened 帧（`WIRE_KIND_RESPONSE`）分支：
  - `stream_id` 改为 `wire_field(&records, "stream_id").ok_or("the daemon opened a stream without naming its stream_id")?`——opened 帧**必须**命名流（它是后续每帧的关联锚），缺 id 即拒（fail-closed，不再 `unwrap_or("?")`）；
  - `opened_stream = Some(stream_id.clone());` 存为权威 id。
- 合并 `--json` / records 两个 STREAM_DATA 臂与两个 STREAM_END 臂为各一个臂，在**打印事件 / 采用判决之前**统一调用：
  `stream_frame_id_matches(&records, opened_stream.as_deref())?;`
- 新 helper `stream_frame_id_matches(records, opened) -> Result<(), String>`：
  - 读帧 `stream_id`（`wire_field(records, "stream_id")`）；
  - 唯一接受路径：`(Some(frame_id), Some(opened)) if frame_id == opened => Ok(())`；
  - 外国 id：报 "the daemon sent a stream frame for stream {frame_id}, but this follow opened {opened} … (PROTO_MISMATCH)"；
  - 缺帧 id / opened 前到达：报 "a stream frame arrived with no correlated stream id … (PROTO_MISMATCH)"。
  - 两种错误都沿 `?` 上抛为 `Err(String)` → main 映射 **exit 13（PROTO_MISMATCH）**。

wire 形状零变更（daemon 三帧本就带同一 `stream_id`）、daemon 零改动、无新依赖、无新 ADR（这是 CLI 侧边界防错，对齐 typed 状态机既有不变量，不引新架构决策）。

## 3. 裁判

### 3.1 假 daemon follow e2e 三胎（`crates/caly-cli/tests/caly_cli_e2e.rs`，29 → 32）

新增四个共享小助手（`read_hello` / `write_hello_ack` / `read_request` / `read_ack` / `write_frame`）把 R91 静默间隙测试里内联的帧编排收编复用：

1. `a_follow_data_frame_with_a_foreign_stream_id_is_refused_not_printed`：opened 报 stream 7，DATA 帧回 `stream_id=999` 带别流事件行 `event_0=FOREIGN-STREAM-EVENT` → 断言 **exit 13**、stdout **不含**该事件行、stderr 同时含 `999` 与 `7`。
2. `a_follow_end_frame_with_a_foreign_stream_id_does_not_set_the_verdict`：opened 7、DATA 7（正常打印）、END 帧回 `stream_id=999` 且 `outcome=Succeeded` → 断言 **exit 13 而非 0**（别流判决不得定退出码）、stderr 点名 999 与 7。
3. `a_follow_data_and_end_with_the_opened_stream_id_are_accepted`（**反空转**）：opened 7、DATA 7、END 7 Succeeded（结尾读 STREAM_ACK 并回 `acked_upto=1` 确认帧，避免 broken pipe）→ 断言 **exit 0** 且打印数据行——防「凡流帧全拒」把正确流也拒了。

真 daemon 既有 4 个 follow e2e（含 R91 静默 4s 间隙，opened/data/end 全 id 7）与假 daemon 静默间隙测试修复后全绿，无回归。

### 3.2 结构门禁（`crates/caly-arch-test/tests/dependency_direction.rs`，17 → 18）

`the_cli_correlates_each_follow_frame_with_its_opened_stream_id`：
- `follow_stream` 体内必须出现 `opened_stream`、必须处理 `WIRE_KIND_STREAM_DATA` 与 `WIRE_KIND_STREAM_END`；
- DATA 臂区间（data_arm..end_arm）与 END 臂区间（end_arm..）都必须含 `stream_frame_id_matches(`（调用点在打印/判决之前）；
- helper `stream_frame_id_matches` 体内：`=> Ok(())` 接受路径**恰好一条**（`matches("=> Ok(())").count() == 1`）、`frame_id == opened` 守卫**恰好一条**、且 `wire_field(records, "stream_id")` 的读取位置先于守卫位置。

**门禁为什么要计数而不是 contains**：见 §4.1 教训。

## 4. 证伪（`scripts/archive/falsify_round95.py`）

三条变异，cargo 全程编译绿、裁判红；还原按内容 + mtime + sha256 校验；收尾 sweep 清 `.r95bak`：

| 变异 | 改动 | 咬住的裁判 | 结果 |
|---|---|---|---|
| **M1** 删比较 | helper 整段 match 替换为 `let _frame_id = wire_field(..); let _ = opened; Ok(())` | foreign-data e2e 红 + foreign-end e2e 红（happy 仍绿）+ 门禁红（无 `=> Ok(())` 守卫/无 `frame_id == opened`） | **BIT** |
| **M2** 接受缺失 id | 加一条 `(None, _) => Ok(())` 接受手臂 | 门禁红（`=> Ok(())` 计数变 2）；e2e 三胎不受影响（wire 帧总带 id）——「缺失≠默认」这半由门禁独立钉住 | **BIT** |
| **M3** 只删 END 臂关联 | 删 STREAM_END 臂那一行 `stream_frame_id_matches(..)?` | foreign-end e2e 红（别流 Succeeded 定判 0）；foreign-data / happy 仍正确 + 门禁红（END 区间无调用）——证明判决路径被独立覆盖、不只是打印路径 | **BIT** |

### 4.1 两版裁判暴露的两条留档教训

1. **前置 `return Ok(())` 留死代码会骗过文本门禁**。M1 第一版我把变异写成「在 match 前插 `return Ok(())`，旧 match 留在后面（成 unreachable 死代码）」。结果 e2e 正确地红了，但**门禁假绿**——死代码里仍含 `frame_id == opened` 子串、仍含一条 `=> Ok(())`。这和 R94 「门禁令钉真实比较表达式、非符号出现（`_answer_id` 改名漏判）」同族：**contains/子串断言分不清活代码与死代码**。修法双管：
   - 变异侧：改为**整段替换 match 为无条件 `Ok(())`**（真删比较体，不靠 unreachable 兜底）；
   - 门禁侧：从「contains 比较表达式」加强为**计数不变量**——helper 内接受路径（`=> Ok(())`）**恰好一条**、守卫表达式（`frame_id == opened`）**恰好一条**、且读取先于比较。这样「前置 return 留死代码」（接受路径数错 / 守卫在死代码里）与「加第二条接受手臂」（M2，接受路径变 2）都被结构计数咬住。
2. **证伪变异要真的删/改逻辑体，不要用 `let _ = x;` + 前置 return 配 unreachable 旧码**——那会把旧表达式留在死代码里，既不影响运行（e2e 能红是因为运行时走了前置 return）又骗过文本门禁。变异的意图是「生产代码少了这条性质」，那就让源码文本里这条性质也真的不存在。

## 5. 明确没做（范围边界）

- **多流并发关联**：v0 一次 `follow` 一条流，`opened_stream: Option<String>` 单值即够。若将来单会话并发多流（CLI 目前不这么用），需要的是 typed loop `streams` 表那种 `HashMap<stream_id, state>` 的生产化——属 §13#3 主体「typed `send_request_frame` / SessionRegistry 生产化 / 共享 timeout scheduler」，不在本轮。
- **不改 wire 帧形状**：daemon 在 opened/data/end 三帧本就写同一 `logical_stream`，无需协议变更。
- **不改 daemon**：daemon 的 `streams`/pump 关联早已正确（typed 侧 `client.rs`/`session.rs` 都按 stream_id 键控）；本轮纯 CLI 客户端边界防错。
- **R94 的 request_id 关联与本轮 stream_id 关联互不重复**：一个校请求/应答、一个校流帧；follow 的 opened 帧虽也是 RESPONSE kind，但它走 `follow_stream` 的流分支、由 `opened_stream` 关联，不走 `ask()`。
- trace_id 常量化（非洞）、`client_loop.rs` 硬编码 30_000 deadline（在未启用的 typed 骨架里）均记录为后续，不在本轮。

## 6. 收尾

- `python3 scripts/regenerate_test_census.py` → `files=105 total=837 rows=105`；`--check` 一致。
- `scripts/check.sh`：`TEST_FLOOR` 833 → 837；clippy 基线 31 不动。
- 文档：IMPLEMENTATION_STATUS §8.29（新）、census 两行描述（dependency_direction 18 / caly_cli_e2e 32）、CENTERLINE/ROADMAP/STATUS/ONBOARDING 数字 833→837；ONBOARDING §4.169（新）+ 处置表 6.121 行（新）、「历史上明确不做」标题 6.121→6.122；本日志入 README 三索引。
- `falsify_round95.py` M1/M2/M3 全 BIT；`.r95bak` 收尾 sweep 干净。
