# 开发日志 — 第一百零一轮（R101）

- **日期**：2026-08-31
- **一句话**：给第一百轮交付的 systemd 部署工件（`calyd.service`）补上**内容裁判**结构门禁——doc gate 之前只验证文件「存在」，本轮读 unit 内容钉死前台被监督形状、real 运行时显式 opt-in、UDS/目录声明与「init 不得直拉核心」的两层边界；不改运行时/wire/依赖。
- **数字**：`cargo test --workspace` **856 → 857**（arch 结构门禁 +1：dependency_direction 22→23）；`TEST_FLOOR` 856 → **857**；clippy **31 持平**；fmt clean。

---

## 1. 缘起

第一百轮交付了 `packaging/systemd/calyd.service` + runbook + ADR-055，但复盘点出一个防线缺口：`doc_consistency::every_documented_path_reference_resolves` 只证明 runbook 引用的 `.service`/ADR 文件**真实存在**，完全不看 unit 内容。于是这些坏工件都能静默通过：

- ExecStart 里旗标拼错、或用了 calyd 根本不解析的 `--xxx`（drift/typo）；
- 丢掉 `Restart=`——systemd 不再在崩溃后拉起 calyd，外部监督（RFC-0005 §12 崩溃恢复的触发器）名存实亡；
- 生产单元被改成 `--effect-runtime simulated`——`systemctl enable` 后跑着一个不碰代理的空转发 daemon；
- 把 mihomo/sing-box 写成独立 `ExecStartPre/ExecStart`——init 直接拉起核心，破坏 ADR-055 的两层监督边界。

部署工件是运维直接 `systemctl enable` 的，腐烂的代价比代码 bug 更隐蔽。

## 2. 量选时排除的邻居：SIGTERM 优雅关停

systemd 语境还冒出「calyd 捕获 SIGTERM 优雅停核」（`effect_std::shutdown(grace_ms)` 已能优雅停核，缺 main 信号处理）。评估为**跨轮大活**，本轮不做：

- std 标准库无 Unix 信号 API（ADR-043 §2.5 明说 TERM 面显式推迟，「等第一个真正需要优雅关停的调用方，届时伴 ADR」）；
- 须手写 libc FFI 或引信号 crate（外部 crate 须 ADR，全仓目前无 libc/signal-hook）；
- 还要非阻塞 accept（accept 阻塞中信号到来）、shutdown 句柄穿透组合根、真实内核信号集成裁判（沙箱时序易 flake）。

systemd 现在确实是 ADR-043 预告的那个调用方，该特性成立，但按 ADR 流程单独立项（ADR-056 方向），不塞进本轮内容裁判。

## 3. 裁判（结构门禁）

`crates/caly-arch-test/tests/dependency_direction.rs::the_systemd_unit_is_a_foreground_managed_calyd_supervising_the_core`：读 `packaging/systemd/calyd.service`，剥注释行、合并反斜杠续行后逐指令断言：

1. `Type=simple`（前台、不自我守护，ADR-055 §2.1）；
2. `Restart=on-failure|always`（外部监督=崩溃恢复触发器）；
3. `WantedBy=multi-user.target`（可 enable）；
4. ExecStart 启动 `calyd`（不是 caly CLI），且每个 `--flag` token 都在 calyd 真实解析白名单内（`--bind/--data-dir/--effect-runtime/--runtime-root/--assets-dir/--port-file/--source-endpoint/--session-idle-ms/--worker-tick-ms`）——旗标 drift/typo 即红；
5. `--effect-runtime real` 且同带 `--runtime-root` 与 `--assets-dir`（ADR-050 §2.1 real 必填两路径）；
6. `--bind unix:/run/calyd/` 且声明 `RuntimeDirectory`/`StateDirectory`；
7. **两层边界**：所有 `ExecStart/ExecStartPre/ExecStartPost/ExecReload/ExecStop` 指令文本不得出现 `mihomo`/`sing-box`（核心必须是 calyd 子进程由 Core Supervisor 在 apply 事务内管，init 不得直拉，`RFC-0005 §11.2`/ADR-055）。

带 anti-vacuity（unit 文件必须存在）。

## 4. 证伪（scripts/archive/falsify_round101.py）

| 变异 | 改动 | 被咬断言 | 结果 |
|---|---|---|---|
| **M1** | `Restart=on-failure` → `Restart=no` | ② 外部监督 | BIT |
| **M2** | `--effect-runtime real` → `simulated` | ⑤ 生产空转 | BIT |
| **M3** | 注入 `ExecStartPre=/usr/bin/mihomo -d ...` | ⑦ 两层边界 | BIT |

三变异全 BIT，unit 内容 sha256 还原校验。

## 5. 留档规则

1. **交付任何被运维直接使用的声明式工件（unit/plist/Dockerfile/CI yaml）都要有内容裁判**，不能只靠「路径引用存在」——存在性门禁对腐烂零防御。
2. **内容裁判的白名单要对齐被调用方真实接受的输入**（calyd 实际解析的旗标集，经 grep 代码核实），否则防不住 drift。
3. **边界类不变量适合做文本断言**：「ExecStart* 指令不得含核心二进制名」一行断言就把 ADR-055 两层边界钉成可机器检查的工件。

## 6. 收尾

- census：`regenerate_test_census.py` + dependency_direction 行手写描述（23），`--check` 一致（files=105 total=857）。
- 文档：STATUS §8.35、ONBOARDING §4.175 + 处置表 6.127（「不做」标题 6.127→6.128）、CENTERLINE 857、本日志、README 索引。
- `check.sh` 全绿（857/floor 857/clippy 31/fmt clean）；floor 撕开测试见 FAIL 后还原；无 `.r101bak/.orig` 残留。

## 7. 环境插曲

本轮工作区 Rust 工具链两次被环境重置（`~/.rustup/toolchains` 目录消失、`~/.cargo/bin/rustup` 失执行位）。恢复套路固定：`chmod +x ~/.cargo/bin/rustup` → `rustup default stable`（拉回 rustc/cargo/rustfmt 1.98.0），PATH 用工具链 bin 直路径 `~/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/bin`。
