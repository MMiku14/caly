# Caly 开发日志 — 2026-08-31（第九十二轮：线端请求角色取自 hello 协商，而非硬编码 Admin）

本轮做一件安全面的事：`calyd` 的生产**线端帧循环**重建每个请求信封时把 `role` 写死成
`Role::Admin`，于是一个在握手时声明 `Operator`（或 `Viewer`）的远端客户端，对 `Admin`-only
命令也照发照过——`required_role` 授权闸（`RFC-0002 §7.2` / `ADR-037`）在 wire 上不可失败。
这是静默提权。无 wire 形状变更、无新依赖、无新 ADR（实现 `ADR-037` 已 Accepted 的决策）。

---

## 1. 靶子（量选与判据）

### 1.1 现象

`crates/caly-daemon/src/bin/calyd.rs` 的 `KIND_REQUEST` 分支把 wire 记录解码成 `Operation`，
再手工重建 `caly_api::RequestEnvelope`，其中：

```rust
let envelope = RequestEnvelope {
    ...
    role: Role::Admin,   // <— 硬编码
    ...
};
```

这个信封交给 `transport.on_client_frame(..)` → `DaemonSession::handle_request` →
`handle_request` / `map_request_to_command`，两处都调 `request_map::require_role(envelope)`。
`require_role` 按 `envelope.role` 与 `meta.required_role` 比较（`role_satisfies`：Viewer 0 /
Operator 1 / Admin 2）。信封里恒为 `Admin`，所以线端授权恒真。

### 1.2 为什么既有测试没抓到

- **客户端 hello 本来就带角色**：`client_hello_records` 写 `role=`，dialect 的
  `server_hello_from_records` 把 `Operator`/`Viewer`/其它映射成 `Role`。
- **typed 状态机本来也存了**：`SessionMachine::accept_hello` 把 `hello.role` 记进
  `SessionInfo.role`（`caly-ipc/src/session.rs`）。
- **但生产帧循环没用它**。更微妙的是：`LoopbackHarness`（`harness.rs`）和 typed
  `DaemonTransport` 路径**正确**透传角色——harness 经 `client.make_request(..)` 构造信封，
  角色来自协商会话。所以 `idempotency_and_roles.rs` 的 loopback parity 测试（声明 Operator →
  PERMISSION）一直绿，而它**不经过** calyd 里那段手写帧循环。真实 TCP 客户端走的正是那段。
- 本地门面的对位缺口已在 `ADR-037 §2.2` 闭合（角色在组装根 `local_role`，默认 Operator）。

教训（入 `ONBOARDING_NOTES §4.166`）：**当有两条到达同一授权判定的路径时，裁判必须分别覆盖
每条**；typed/loopback 路径绿 ≠ wire 帧循环绿。这与 R89/R90/R91 的「生产路径与测试 harness
之间的接缝」同族。

### 1.3 判据（可证伪）

> 线端请求信封的 `role` 必须是对端在 hello 里协商的角色（typed 会话已记录），不得硬编码
> `Admin`；于是声明 `Operator` 的对端发 Admin-only 命令必须收到 `PERMISSION` 拒绝，而声明
> `Admin` 的对端同一命令不得被权限闸拒绝。

---

## 2. 实现

### 2.1 `crates/caly-daemon/src/transport.rs`

新增 `DaemonTransport::peer_role(&self) -> Option<caly_api::Role>`：读
`self.session.machine.info.as_ref().map(|info| info.role)`。hello 被接受前 `info` 为 `None`
（帧循环只在 `hello_seen` 后建信封，彼时为 `Some`）。文档注释写明：线端对端的角色**唯一诚实
来源**是握手协商值，硬编码 Admin 会让 `required_role` 在 wire 上不可失败。

### 2.2 `crates/caly-daemon/src/bin/calyd.rs`

`KIND_REQUEST` 分支：

```rust
let peer_role = transport.peer_role().unwrap_or(Role::Admin);
let envelope = RequestEnvelope { ..., role: peer_role, .. };
```

`unwrap_or(Role::Admin)` 只是 hello 前不可达路径的防御默认（该分支已在 `hello_seen` 守卫内），
不是常态硬编码——结构门禁据此区分「信封字段引用 peer_role」与「信封字段写死字面 Admin」。

---

## 3. 裁判

### 3.1 真实 daemon 的 wire e2e（`crates/caly-daemon/tests/calyd_wire.rs`，真 TCP + 真 calyd）

- `a_wire_peer_declaring_operator_is_refused_an_admin_command`：发 `role=Operator` 的 hello，
  再发带 `idempotency_key` 的 Admin-only `system.gc`。**带 key** 是刻意的：`map_request_to_command`
  里 `require_role` 在 idempotency 解析之前，key 在场保证"被拒的唯一原因是角色"可判定（否则
  无 key 的 Operator 可能撞 key 拒绝，分不清）。断言回包是 `KIND_REFUSAL`、`request_id=3`、
  `code=PERMISSION`、summary 点名 `Admin`。硬编码 Admin 的变异下：回包变成 `KIND_RESPONSE`
  （kind 4 vs 5），裁判红。
- `a_wire_peer_declaring_admin_is_not_refused_by_the_role_gate`（**反空转 twin**）：`role=Admin`
  的 hello + 同一命令，断言回包**不是** `PERMISSION`。没有它，"干脆把每个 gc 都拒掉"也能让
  上一条变绿；它钉死"闸是按角色放行/拒绝"，不是"一律拒绝"。

### 3.2 结构门禁

`dependency_direction.rs::the_wire_daemon_carries_the_hello_negotiated_role_into_request_envelopes`
（生产 calyd bin + transport.rs）：

- 帧循环含 `transport.peer_role()`；
- `let envelope = RequestEnvelope {` 起的 700 字节窗体内含 `role: peer_role`，且**不含**字面
  `role: Role::Admin`；
- `transport.rs` 暴露 `pub fn peer_role(` 且其体读取会话角色（`.role`）。

### 3.3 证伪 `scripts/falsify_round92.py`（3 变异全 BIT，均编译绿、判据红）

- **M1**（envelope 字段改回 `role: Role::Admin`）：Operator e2e 变红（回 response 非 refusal）
  **且** 结构门禁变红（信封体内出现字面 Admin）。
- **M2**（删掉 `transport.peer_role()` 调用，`let peer_role = Role::Admin;`）：Operator e2e 红
  **且** 门禁找不到 `peer_role()` 调用点。
- **M3**（`peer_role()` 恒返 `Some(Role::Admin)`，无视协商会话）：Operator e2e 红，而**结构
  门禁保持绿**——这条故意证明行为 e2e 覆盖了结构门禁看不到的一层（访问器返回值是否真来自 hello
  协商）。结构串线检查与行为正确性是两层，缺一不可。

---

## 4. 收口数字

- `cargo test --workspace`：821 → **824**（+3：calyd_wire e2e 2、arch 门禁 1）；
  `check.sh TEST_FLOOR=824`。
- clippy 唯一源码位置：**31**（= 基线，未抬、无 `#[allow]`）。
- rustfmt：只对本轮碰过的文件跑（`transport.rs`、`calyd.rs`、`calyd_wire.rs`、
  `dependency_direction.rs`），不用 `cargo fmt --all`。
- 普查 `regenerate_test_census.py` 重新生成（files=105 total=824 rows=105），描述列手写补 R92。

## 5. 本轮踩到的点（留档 `ONBOARDING_NOTES §4.166`）

1. **typed 模型对 ≠ 线上对**。角色在 `SessionMachine.info.role` 里是对的、loopback harness 也是
   对的，但生产帧循环是手写的**第二条**建信封路径，绕过了它。授权/安全属性要追到"数据真正进入
   授权判定的那一行"。
2. **裁判要正/反双胎**。只有"Operator 被拒"会让"拒绝一切"蒙混过关；加一条"Admin 不被拒"才钉住
   闸是按角色工作。
3. **排除并列闸的干扰**。命令路径上 `require_role` 之后还有 idempotency 闸；给 Operator 请求带
   上 idempotency key，被拒原因才唯一归于角色。
4. **保留一条"结构门禁绿、行为裁判红"的变异（M3）**，证明两类裁判互补。

## 6. 明确没做

- **principal / 凭据层不做**：`ADR-037` 明确 v1 "谁在调用 = 一个角色，仅此而已"；认证 / OS 凭据
  / principal 身份留给后续（需要时用 `AuthContext` **替换** `role`，不与之并存）。本轮只闭合
  "角色在 wire 上是否被诚实使用"，不发明认证。
- 不改 `require_role` / `role_satisfies` 的判定本身，不改本地门面；无 wire 形状变更、无新依赖。
