# Caly Storage and Recovery Execution Plan

> 
> **📌 阅读提示（2026-08-31 更新）**：下方「本版状态」停留在 **2026-08-27**，仅作历史记录。
> 最新功能面与状态请以 `FEATURES.md`（功能说明书）与 `IMPLEMENTATION_STATUS.md`（逐轮收口）、`CENTERLINE_PROGRESS.md`（主链进度）为准；量化基线为 **862 测试 / floor 862**。本文保留其设计与实施基线价值。


> **本版状态（2026-08-27）**：`§4.1` 的 `ApplyJournalRecord`、`§4.2` 的 `SnapshotCandidate`、
> `§4.3` 的 `RecoveryDecision`、`§5` 的三阶段接线与 `§6.2` 的决策规则均已在
> `caly-storage/src/execution.rs` + `caly-engine/src/{recovery,worker}.rs` 落地，
> 并有“每个 EffectStep 崩溃后 LKG 不被污染”的穷举测试。
> `§9.2`（doctor 可诊断项）也已从清单变为实现：`caly_storage::audit` 计算 dangling pending journal /
> abandoned runtime / no valid last-known-good / snapshot-object mismatch 四类发现；`FsStore` 用
> materialization marker 让"runtime 目录被清空"成为可观测事实；内存后端对答不出的问题回答
> "不可观测"，而不是"一切正常"。
> `§7` 的 last-known-good 纪律已进入断言，`§8`/`RFC-0007 §13` 的 GC root 集也已实现（`caly-storage/src/gc.rs`，
> 9 条断言覆盖六类 root、宽限期、上限与"共享内容不被误删"）。后端可替换性早已成立
> （`EngineHandle::with_backend`，第二轮），本轮补的是**导出侧**：`§9.3` 四项现由 `caly-engine::bundle`
> 提供（见下），为此 `ApplyJournalStore` 补了 `list_apply_journals`——"最近 apply 摘要"要看到
> `Committed`，而那正是 `list_pending_apply` / `list_unresolved_apply` 排除的部分。
> 第十轮补上了 `ObjectStore::read_object`（内容读回，读时按锚点校验，默认 `Unsupported`）与
> `DiagnosticsOp::ReadSupportBundle`，于是 `§9.3` 的导出真正可达；跨后端语义由
> `caly-storage/tests/object_contract.rs` 统一约束（它当场抓出两处后端各说各话，见 `ONBOARDING §4.46`）。
> 仍未做：把 bundle 写到调用方指定的路径（`ADR-011` 下 daemon 无平台层），以及 `§7.3` 的**数据**迁移
> （只有门禁与回退点，没有迁移器）。

本文件专门描述 `caly-storage`、`apply execution` 与 `daemon recovery` 三者之间应该如何接线。

它关注的是中心主链里最容易被拖延、但又最关键的一截：

```text
EffectPlan
  -> Journal Pending
  -> Runtime Cutover
  -> Snapshot Commit
  -> Crash Recovery
  -> Last Known Good
```

---

## 1. 为什么需要单独计划

虽然 RFC-0005 与 RFC-0007 已冻结：

- Apply / Rollback / Recovery
- Snapshot / Journal / CAS / Revision

但当前代码层仍主要停留在：

- plan 对象存在
- storage trait 存在
- snapshot / journal 类型存在

真正缺少的是：

> 如何把 storage 变成 apply execution 的事务底座，而不是与中心主链平行漂浮的一组类型。

> 本节描述的是进入本版之前的差距；其中“缺 journal 生命周期 / 缺 snapshot 提交边界 /
> 缺 recovery scanner”三条已在 `caly-storage` + `caly-engine` 落地，见文首状态说明。

---

## 2. 当前已有的工程承载位

### 2.1 `caly-storage`

当前已有：

- `ObjectStore`
- `RevisionStore`
- `SnapshotStore`
- `JournalStore`
- `InMemoryStorage`
- CAS / revision / snapshot / journal 基础对象

### 2.2 `caly-plan`

当前已有：

- `EffectPlan`
- `EffectStep`
- `MarkSnapshot`
- `CommitRevision`
- `NetApply`
- `NetRevert`
- `SpawnCore`
- `StopCore`

### 2.3 `caly-engine::apply`

当前已有：

- apply workflow summary
- effect step projection
- compensation step projection

### 2.4 `caly-daemon`

当前已有：

- daemon 是唯一状态所有者
- request -> command 边界
- job follow / event stream 基础模型

---

## 3. 当前最关键的缺口

### 3.1 缺 pending journal 生命周期

当前还没有真正的：

- begin journal pending
- update step cursor
- mark committed / reverted / abandoned

### 3.2 缺 snapshot 提交边界

当前还没有真正区分：

- compiled but not committed
- cutover in progress
- verified succeeded
- snapshot committed as last-known-good

### 3.3 缺 recovery scanner

当前 daemon 启动时还没有一个明确的：

- scan pending journal
- inspect runtime leftovers
- choose rollback / takeover / cleanup
- emit recovery diagnostics

### 3.4 缺 storage-backed apply event proof

当前 job follow 还主要围绕内存态 skeleton。
后续必须让部分 apply/recovery 关键节点有持久证据可读。

---

## 4. 建议的最小事务对象

### 4.1 `ApplyJournalRecord`

建议至少包含：

- `journal_id`
- `apply_txn_id`
- `trace_id`
- `job_id`
- `profile_id`
- `revision_id`
- `semantic_digest`
- `compiled_artifact_digest`
- `core_identity`
- `effect_plan_id`
- `current_phase`
- `current_step_index`
- `net_effect_started`
- `core_cutover_started`
- `previous_snapshot_id`
- `created_at`
- `updated_at`
- `state: pending | committed | reverted | abandoned | recovery_failed`

### 4.2 `SnapshotCandidate`

建议在正式 commit 前先有临时投影：

- revision id
- semantic digest
- compiled artifact digest
- core binary digest
- validation summary
- selection memory digest
- effect plan summary

### 4.3 `RecoveryDecision`

建议至少表达：

- `TakeoverRunningInstance`
- `RollbackToLastKnownGood`
- `RevertOsEffectsOnly`
- `CleanupAbandonedRuntime`
- `EnterFailedState`

---

## 5. 执行与存储的正确接线顺序

### 5.1 Prepare 阶段

目标：

- 不动 active runtime
- 只做可重复准备动作

建议顺序：

1. 写 compiled artifact 到 object store
2. 物化 runtime candidate 文件
3. 创建 `ApplyJournalRecord(state=pending)`
4. 写入 effect plan cursor=0

此阶段失败要求：

- 当前 active snapshot 不变
- pending journal 可删除或标记 abandoned

### 5.2 Cutover 阶段

目标：

- 执行真正影响 runtime / OS 的动作

建议顺序：

1. 标记 `core_cutover_started=true`
2. 若需要，记录 `net_effect_started=true`
3. 执行 `StopCore` / `SpawnCore` / `Reload` / `NetApply`
4. 每完成一步都更新 step cursor

此阶段要求：

- journal 必须始终领先或同步于不可逆副作用
- recovery scanner 必须能仅靠 journal 决定下一步

### 5.3 Verify / Finalize 阶段

目标：

- 只在验证成功后提交新真相

建议顺序：

1. 运行 probe
2. 生成 `SnapshotCandidate`
3. 写 snapshot record
4. 更新 last-known-good marker
5. commit revision
6. 标记 journal=committed

此阶段失败要求：

- 不得留下“已经新 snapshot commit，但 runtime 未验证”的状态

---

## 6. crash recovery 的最小算法

### 6.1 启动入口

daemon 启动时第一件事不是接受新 apply，而是：

1. 扫描 pending journal
2. 扫描 runtime 目录残留
3. 扫描上一个 active snapshot / last-known-good snapshot

### 6.2 决策规则

#### 情况 A：只有 prepare 完成，cutover 未开始

处理：

- 清理 runtime candidate
- journal -> abandoned
- 保持旧 active snapshot

#### 情况 B：cutover 已开始，但 verify 未完成

处理：

- 优先 rollback 到 last-known-good
- 无法 rollback 则至少 revert OS side effects
- 标记 recovery result

#### 情况 C：新 runtime 看似在跑，但 snapshot 未提交

处理：

- 通过 config identity / instance identity 判断是否可接管
- 若不能证明一致，则回滚或进入 failed state

#### 情况 D：journal 显示已 committed，但 runtime 目录部分损坏

处理：

- 基于 snapshot + object store 重建 runtime materialization
- 不依赖 runtime 目录作为最终真相来源

---

## 7. last-known-good 的维护纪律

last-known-good 必须满足：

1. 只有 verify 成功的 snapshot 才能升级为 LKG
2. 新部署成功前，旧 LKG 不得移除
3. GC 不得删除任何被 LKG 引用的对象
4. recovery 优先回到 LKG，而不是回到“最近一次尝试”

这条纪律是 Caly “失败不污染运行态” 的核心承诺之一。

---

## 8. 与 CAS / GC 的关系

### 8.1 apply 执行时的 root 集

在 apply 执行期间，以下对象必须被视为 GC root：

- 当前 active snapshot 引用对象
- pending journal 引用对象
- 新 compiled artifact
- runtime candidate materialization source
- previous snapshot / LKG 引用对象

### 8.2 完成后 root 切换

只有在：

- snapshot committed
- journal committed or archived
- recovery not needed

之后，旧对象才可在未来 GC 周期中根据可达性决定是否删除。

---

## 9. job follow / doctor / support bundle 的持久化视角

一旦 storage/recovery 接线，以下对外能力就能显著提升：

### 9.1 job follow

可以观察：

- journal pending
- current step cursor
- probe passed/failed
- snapshot committed
- recovery started/succeeded/failed

### 9.2 doctor

可以诊断：

- dangling pending journal
- abandoned runtime directory
- no valid last-known-good
- snapshot/object mismatch

### 9.3 support bundle

可以导出：

- recent apply journal summaries
- active snapshot metadata
- last-known-good metadata
- recovery incident summary

**本版状态（2026-08-27）**：四条均已实现并有断言，落在 `crates/caly-engine/src/bundle.rs`
（12 段固定清单：另含 `header`/`architecture`/`capability`/`effect-plan`/`runtime-log`/`resources`/`overload`/
`storage-audit`，即 `RFC-0010 §12.2` 要求的其余项）。三点与本文其余部分一致的纪律：

1. 导出物只有一个合法形态 —— `BundleDraft` 是未掩草稿且永不写盘，`SupportBundle` 只能经
   `finish(&Redactor)` 得到，因此"bundle 不含明文 secret"（`§14.3`）在类型上而非流程上成立；
2. 段内容全部来自注入的后端，`audit` 与 `doctor` 共用同一个 `caly_storage::audit_backend`，
   两条视图不一致会被 `caly-daemon/tests/redaction_boundary.rs` 抓住；
3. 后端答不出的问题写成 `not enumerable on this backend` / `unavailable: …`，不写成"没有"。
   真损坏（记录解不开）则**整个导出失败**：诊断工具把一个读不出的 store 渲染成"一切正常"比没有工具更糟。

---

## 10. 推荐的三阶段实施顺序

### Stage 1 — Projection First

交付物：

- `EffectPlan -> ApplyJournalRecord` projection helper
- `ApplyWorkflowResult -> SnapshotCandidate` projection helper
- journal step cursor model

完成定义：

- 虽然 executor 还没落地，但 storage 写入对象已可被结构化描述

### Stage 2 — InMemory Recovery Skeleton

交付物：

- 基于 `InMemoryStorage` 的 pending journal begin/update/commit/revert
- daemon boot recovery scan skeleton
- recovery decision enum

完成定义：

- recovery path 已从文档概念进入可编译代码骨架

### Stage 3 — Executor Integration

交付物：

- effect executor 每步推进 journal cursor
- probe 成功后写 snapshot
- 失败时写 recovery outcome

完成定义：

- apply command path 可产出持久化事务痕迹

---

## 11. 当前阶段完成定义

只有满足以下条件，才能说 storage/recovery 不再是漂浮层：

1. apply 执行前会创建 pending journal
2. effect steps 执行过程中会推进 journal cursor
3. verify 成功后才会 commit snapshot / revision
4. daemon 启动时能扫描 pending journal 并做恢复决策
5. last-known-good 真正参与 rollback / recovery

---

## 12. 一句话结论

> `caly-storage` 下一步最重要的不是再补更多静态类型，而是成为 `apply execution -> snapshot/journal -> crash recovery` 这条中心执行链的真实事务底座。