# Caly 接手开发笔记与问题留档

> 本文件是**接手方（第二轮接续开发）在“读文档 → 建环境 → 核对代码 → 动手改动”过程中遇到的全部问题**的留档。
>
> 它不属于规范层（不进入 `RFC > ADR > Engineering Docs` 的权威链），而是一份**工程审计记录**：
> 记录文档与代码的真实差异、可验证性缺口、接手时会踩的坑，以及本轮为解决这些问题所做的处置。
>
> 状态标记沿用 `IMPLEMENTATION_STATUS.md §1` 的同一套标签。

- Archive-Date: 2026-08-27
- Baseline: `MMiku14/caly@e5413f2`（`caly.zip`：247 文件 / 154 个 `.rs` / 20,677 行 Rust / 68 个 `.md`）
- Toolchain: `rustc 1.98.0 (88d9e12ae 2026-08-18)` / `cargo 1.98.0`
- 本轮改动明细见 `docs/DEVELOPMENT_LOG_2026-08-27.md`

---

## 0. 如何使用本文

每条固定四段：

```text
现象（Observed） -> 复现方式（Reproducer） -> 影响（Impact） -> 处置（Disposition）
```

`Reproducer` 都是可直接复制执行的命令。凡是我没能亲自复现的判断，一律标 `unchecked`。
**本文不采信任何“文档说已经做了”的说法**：§2 的每一条都用 grep 或编译结果重新确认过。

---

## 1. 环境与上手门槛

### 1.1 仓库只有一个 `caly.zip`，没有可 `git clone` 的源码树

- **Observed**：仓库根目录只有一个约 468 KB 的 `caly.zip`（6 commits / 1 branch）。
  `git clone` 拿不到可编辑源码树，必须先解压；解压出来的是
  `workspace-01a03eb1-7719-7075-be20-d3d304c8839e/` 这种沙箱目录名。
- **Reproducer**：
  ```bash
  curl -sL -o caly.zip https://github.com/MMiku14/caly/raw/main/caly.zip
  unzip -q caly.zip && ls
  ```
- **Impact**：没有 git 历史、没有 blame、**没有任何 CI 配置文件**
  （无 `.github/workflows`、无 `Makefile`、无 `justfile`、无 `deny.toml`）。
  而 `ADR-022` 明确要求“确定性仿真是 PR 级门禁”，`STYLEGUIDE.md` 要求统一格式：
  这些要求在交付物里**没有承载体**。
- **Disposition**：本轮新增 `scripts/check.sh` 作为本地可执行门禁（§6.5）。
  目录改名属于交付流程问题，留给上游。

### 1.2 打包时混入了环境残留文件

- **Observed**：zip 内有一层 `workspace-…/.profile`（21 字节）。
- **Reproducer**：`unzip -l caly.zip | grep .profile`
- **Impact**：说明打包没有 exclude 白名单；与 1.1 相互印证：当前交付缺少“可发布工件”的门禁。
- **Disposition**：留档，未删除（避免与上游无谓分叉）。

### 1.3 文档说“Rust toolchain 已安装”，接手环境里并没有

- **Observed**：`IMPLEMENTATION_STATUS.md §2` 把“Rust toolchain 已安装 / `cargo check` 已通过”
  当作项目状态描述。干净环境里 `cargo` 直接 `command not found`。
- **Impact**：把“作者机器上的状态”记成“项目状态”，接手方会误判前置条件已满足。
- **Disposition**：本轮安装 `stable` + `rustfmt` + `clippy`，版本写入本文件头部。
  建议补 `rust-toolchain.toml`（已确认当前**不存在**：`ls caly/rust-toolchain.toml` 无输出）。

### 1.4 全 workspace 零外部依赖 —— 文档没强调，但它是最硬的约束

- **Observed**：`Cargo.lock` 仅 2,058 字节，19 个成员全是 path 依赖；没有 `serde` / `tokio` /
  `thiserror` / `clap`。
  ```bash
  grep -c '^\[\[package\]\]' Cargo.lock      # 19
  ```
- **Impact**：这条约束决定了很多文档条目能否落地：
  - framed JSON over UDS（`IPC_TRANSPORT_DECISION.md`）只能用 `std` 手写；
  - `async` 全是手写 `BoxFuture` + 自造 waker（见 3.3），因为没有 executor 依赖；
  - 没有 `serde`，所以 `capability-registry.json` 需要手写解析器（见 3.5）；
  - 没有 `clap`，CLI 只能手搓参数解析。
- **Disposition**：本轮新增代码**同样零外部依赖**，包括自写的 JSON 读写器。

---

## 2. 文档与代码的偏差（本轮最重要的问题类别）

> 结论先行：**文档落后于代码至少一个阶段，且方向是“保守”**。
> 反直觉的后果是：照 `ROADMAP.md §13` 的“下一步”做，会重做已经存在的东西。

### 2.1 `cargo check` 实际 0 warning，但文档专设一节说“仍存在若干 warning”

- **Observed**：`IMPLEMENTATION_STATUS.md §3.2` 列出 DTO 重复 re-export、unused import 等告警。
  实测全量重编后 **0 条**。
- **Reproducer**：
  ```bash
  find . -name '*.rs' -exec touch {} +          # 必须先 touch，否则 cargo 命中缓存不重放 warning
  cargo check --workspace --all-targets 2>&1 | grep -cE '^(warning|error)'   # 0
  ```
- **注意**：`touch` 这一步本身就是坑——不加它会误以为“没有 warning 是因为没重新编译”，
  而加不加结论相同。本轮的结论来自**强制全量重编**。
- **Impact**：`API_DTO_MIGRATION_PLAN.md` 的立项动因（“重复导出导致 warning”）在当前快照已不成立；
  继续按它做“清 warning”是空转。
- **Disposition**：`IMPLEMENTATION_STATUS.md §3` 已改为记录实测值 + 复现命令。

### 2.2 storage / recovery / daemon 已接线，文档仍标 `Skeleton` 并列为阻塞项

- **Observed**：三份文档一致声称这一截没做：
  `IMPLEMENTATION_STATUS.md §8`（`caly-storage 未接入 apply workflow`、`caly-engine 尚无真实 effect executor`）、
  `CENTERLINE_PROGRESS.md §4`、`STORAGE_RECOVERY_EXECUTION_PLAN.md §3`（缺 journal 生命周期 / 缺 snapshot 提交边界 / 缺 recovery scanner）。
- **实测**：三者**均有代码**：
  ```text
  crates/caly-storage/src/execution.rs   begin_apply_journal / advance_apply_journal_step
                                         mark_apply_journal_state / build_recovery_scan_report
  crates/caly-engine/src/recovery.rs     begin_apply_persistence / advance_apply_phase
                                         finalize_apply_persistence / mark_apply_reverted
                                         mark_apply_recovery_failed / scan_recovery_state
  crates/caly-engine/src/worker.rs:350   handle.begin_apply_persistence(...)
  crates/caly-daemon/src/app.rs:176      .begin_apply_persistence(...)   (seed_recovery_fixture)
  ```
- **但要注意区分粒度**：已接线的是 **journal cursor 级**（“推进游标 + 落状态”），
  不是 **effect 执行级**——见 2.3。文档的“没打通”在语义上部分成立，但表述方式（标成 `Skeleton`、
  列入“阻塞项”）会让人误判为“这块还是空的”。
- **Disposition**：`IMPLEMENTATION_STATUS.md` / `CENTERLINE_PROGRESS.md` 已按实测重写，
  并显式区分这两级。

### 2.3 effect 执行确实还只是字符串投影（文档这点是对的，但说得太轻）

- **Observed**：`ApplyWorkflowResult` 只有 `effect_steps: Vec<String>` / `compensation_steps: Vec<String>`，
  类型信息在 engine 边界就被 `render_effect_step()` 抹掉：
  ```bash
  grep -n "effect_steps: Vec<String>" crates/caly-engine/src/apply.rs   # 124
  grep -rn "match step" crates/caly-engine/src/worker.rs                 # 无匹配
  ```
  `APPLY_EXECUTION_CENTERLINE.md §6.1` 的 Prepare/Cutover/Finalize 三段模型**零代码承载**：
  没有阶段单调性检查、没有“未 verify 不得 commit”门禁、失败后不执行 `compensations`。
  rollback 分支原话是 `"... is not connected to recovery executor yet"`。
- **Impact**：中心主链“会规划、不会执行”，与 `§12` 完成定义差一整截。
- **Disposition**：本轮补齐（§6.1 / §6.2）。

### 2.4 `caly-io-sim` 是孤儿 crate：没有任何成员依赖它

- **Observed**：
  ```bash
  grep -rn "caly-io-sim" --include=Cargo.toml crates/    # 只命中它自己的 name =
  ```
  `FaultInjector` 的 `CrashAfterEffect` / `trigger_after_step` 无任何生产/测试调用点。
- **Impact**：`ADR-022` 的仿真门禁是**零接线**；其 Follow-up Work 中
  “增加『任意 EffectStep 后崩溃』回归测试”完全未落地。
- **Disposition**：本轮把 io-sim 接成 engine 的 dev-dependency 并写了桥接测试（§6.3 / §6.4）。

### 2.5 架构守卫 `caly-arch-test` 有检查函数、没有调用者，因此 10 条越界依赖一直无人发现

- **Observed**：`check_dependency_edges()` / `check_forbidden_symbol_usage()` 都在，
  `ALLOWED_DEPENDENCY_EDGES` 有 41 条，但**没有任何 `#[test]` 调用**，也没有读 manifest 的代码
  （`WorkspaceMeta` 需调用方手工构造，而无人构造）。`ViolationKind::MissingAllowedEdge` 定义了但从未使用。
- **实测后果**：把真实 manifest 喂进去，当时即有 10 条越界 + 1 条陈旧允许边：
  ```text
  caly-cli->caly-common   caly-daemon->caly-storage   caly-engine->caly-cap
  caly-engine->caly-mihomo caly-engine->caly-singbox  caly-ir->caly-common
  caly-mihomo->caly-domain caly-mihomo->caly-pipeline
  caly-singbox->caly-domain caly-singbox->caly-pipeline
  陈旧：caly-storage -> caly-plan（manifest 里根本没有）
  ```
- **Impact**：**RFC-0001 的“依赖方向不变量”当时是纸面的**。其中
  `caly-engine -> caly-mihomo` / `caly-engine -> caly-singbox` 不是“文档忘了登记”，而是真实的
  依赖倒置违背：engine 在 `apply.rs::adapter_for_target()` 里 `match target` 直接 `Box::new(MihomoAdapter)`。
- **Disposition**：本轮
  1. arch-test 真正解析 `crates/*/Cargo.toml` 并在测试中断言（守卫从函数变门禁）；
  2. 8 条方向合理的既成边补入 allow-list；
  3. 2 条 `engine -> 具体 adapter` **不静默放行**：移入 `KNOWN_ARCH_DEBT`，
     并有 `adapter_wiring_debt_is_declared_and_bounded` 做**棘轮**（新增越界即红，消除债务也必须显式改表）；
  4. 删除陈旧边，并把 `MissingAllowedEdge` 接进 `check_missing_allowed_edges`。

---

## 3. 实现层的结构性问题

### 3.1 全 workspace 零测试，`cargo test` 是“空绿”

- **Observed**：
  ```bash
  grep -rn "#\[test\]\|mod tests" --include=*.rs . | wc -l   # 0
  grep -rn "assert" --include=*.rs crates/ | wc -l           # 0
  cargo test --workspace | grep "test result"                # ok. 0 passed; 0 failed
  ```
- **Impact**：**比没有测试更危险**——空绿会在 CI 上显示通过。文档里所有“已可验证”的主张
  实际只有 `cargo check` 一种支撑。
- **Disposition**：第一轮补 47 个测试、第二轮增至 81 个，并让 `scripts/check.sh` 显式断言“测试数 > 0”。

### 3.2 `caly-cli` 没有 `[[bin]]`，`caly-tui` 整个 crate 不存在

- **Observed**：`grep -rn "\[\[bin\]\]" crates/*/Cargo.toml` 无输出；19 个成员全是 `[lib]`。
  `caly-tui` 只出现在 `IMPLEMENTATION_STATUS.md §5.4` 的 crate 表里（workspace 无此成员）。
- **Impact**：`cargo run` 跑不起任何东西；“CLI `profile plan/apply/status/follow`”只是函数库。
- **Disposition**：留档。本轮不补 bin（不改变中心线正确性，且引入 I/O 与参数解析独立决策面），
  改由 `scripts/check.sh` 提供等价可执行入口；`§5.4` 的 tui 行已标注“(未创建)”。

### 3.3 `run_ready()`：手写 noop-waker，抽象是 async、执行模型是同步

- **Observed**：`crates/caly-engine/src/recovery.rs` 用 `Waker::from(Arc::new(NoopWake))` 只 poll 一次，
  `Poll::Pending` 直接返回 `Err("future unexpectedly pending in immediate execution path")`。
  `EngineHandle` 的全部 apply 相关方法都走这条路径。
- **Impact**：storage trait 设计成 `async`（`BoxFuture`），但引擎只能消费“永不挂起”的实现。
  任何真实后端一旦在 `.await` 让出，就得到运行时错误而非被调度。
  clippy 亦以 `manual_implementation_of_noop_waker` 标记此处。
- **Disposition**：本轮不引入 executor（违反 1.4）；新增 executor 保持**纯同步**，
  不再扩大 `run_ready` 调用面；已在 `service.rs` 注释写明该不变量。

### 3.4 `EngineHandle` 绑死具体 `InMemoryStorage`，storage trait 形同虚设

- **Observed**：`service.rs` 里 `storage: Arc<InMemoryStorage>` 与
  `with_storage(state, storage: InMemoryStorage)` 都是**具体类型**。
- **Impact**：五个 store trait 声称后端可替换，引擎却拿不到这个可替换性；
  `STORAGE_RECOVERY_EXECUTION_PLAN.md` 的“事务底座落盘”第一步就得先改这里。
- **Disposition**：留档并列为下一轮第一项（本轮不碰，避免牵动 daemon/app/parity 全链）。

### 3.5 `capability-registry.json` / `coverage-matrix.json` 当时无人解析，且与代码不一致

- **Observed**：`caly-cap` 有 `REGISTRY_PATH` / `COVERAGE_MATRIX_PATH` 常量与
  `validate_registry_document(&RegistryDocument)`（**校验内存结构**），但**没有任何 JSON 解析代码**：
  ```bash
  grep -rn "read_to_string\|from_json\|serde" crates/caly-cap/src/    # 无匹配
  ```
  实际执行路径是 `merged_registry_document(&default_registry_document(), &descriptors)`，即读**代码内建**那份。
- **两份数据当时的差异**（逐字段核对结果）：
  - 代码内建 registry 有 **15** 个 capability；JSON 文件只写了 **3** 个。
  - `evidence_ref` 也不一致：JSON 给 `dns.fake_ip` 写了 golden / native-validation / runtime 三个 id，
    而 `descriptor()` 只会填 `fixture_id`，其余为 `None`。
- **Impact**：`ADR-024` 的“Registry 是唯一事实来源”当时指的是**代码里那份**；
  改 JSON 不产生任何效果、也不报错——数据文件是“伪装成数据的文档”。
- **Disposition**：本轮补了 `caly-cap/src/json.rs`（零依赖 JSON 读写器，15 项 registry / 25 行
  coverage 现由它双向校验）+
  `crates/caly-cap/tests/registry_drift.rs`（`parse(file) == default`、`emit == file` 的**双向**断言，
  以及 `CALY_REGENERATE_CAPABILITY_ARTIFACTS=1` 再生成入口），并据此重新生成了两份 JSON。
  **注意**：pipeline 仍从 `default_*_document()` 取值；本轮修的是“漂移不可见”这个问题，
  把执行路径改成“读文件”仍待决策（需要决定加载失败/离线首启动语义）。

### 3.6 `clippy.toml` 的禁用清单没人执行；“no clock”靠魔数意外成立

- **Observed**：禁用 `std::fs::File` / `PathBuf` / `Command` / `SystemTime::now` / `Instant::now`，
  但无 `#![deny(clippy::all)]`、无 CI。实测 clippy 报告 33 处不同位置告警。
  更要紧的是时间戳：`apply.rs` 传 `created_at_unix_ms: 0`，`worker.rs` 传 `1,2,3,4`。
- **Impact**：`ADR-011/013` 的“纯核心 + IO 网关”靠自觉；
  “确定性”是被魔数**意外**保证的，而不是由 `Clock` port 保证的。
- **Disposition**：本轮 executor 把时钟改成 `ExecutionPolicy::clock_start_unix_ms` 显式注入，
  并新增测试 `journal_time_comes_from_the_injected_clock_not_the_host` 断言“journal 时间来自注入时钟”；
  门禁脚本对 clippy 位置数做**棘轮**（基线 33，禁止增长）。

### 3.7 `cargo fmt` 从未执行

- **Observed**：`cargo fmt --all -- --check | wc -l` → 基线 **7,723** 行 diff。
- **Disposition**：本轮**有意不**对全仓格式化（会与功能改动混成不可审阅的巨 diff）；
  只对新增文件执行 rustfmt，并在 `scripts/check.sh` 里“报告但不 fail”。
  需要一次独立的 `cargo fmt --all` 提交收口。

---

## 4. 本轮通过写测试才暴露出来的 3 个真实缺陷

> 这一节是“零测试”最直接的代价：这三个缺陷都在**已存在代码**里，
> 文档、评审、`cargo check` 都没能发现，是本轮写断言时才撞出来的。

### 4.1 ConfigIdentity 探针在任何真实计划上都必然失败（已修）

- **Observed**：两个适配器 `compile()` 写入的 `config.identity` 注解是
  `format!("{core}-{:016x}", stable_checksum_text(&profile.semantic_digest.0))`（**语义摘要**的校验和），
  而 `apply_planning()` 里 `SpawnCore.spec.config_digest` 是 **artifact digest**。
  `Probe(ConfigIdentity).target` 取前者，被 spawn 的 core 只会报告后者
  （`RFC-0008` 要求该探针由 runtime 的 `config_identity()` 回答）。
- **Reproducer**（修复前）：给 executor 的模拟 world 一个真实 mihomo 计划，
  第 6 步 `Finalize probe ConfigIdentity target=mihomo-bea95410789e53bb` 必然
  `identity-mismatch`（live 报 `mihomo:657b42af62d91e30`），apply 失败。
- **Impact**：**“验证后才提交”这一整条门禁在生产计划上永远不通过**——
  只要真的按 typed plan 执行，任何 apply 都会被自己的 identity 探针打死。
  在字符串投影时代它不可见，因为没人解释这个步骤。
- **Disposition**：三处（`caly-mihomo` / `caly-singbox` / `caly-core::mock`）改为
  以 artifact digest 作为 `config.identity`，使“注解 = 探针目标 = spawn 时交给 core 的 config”。
  并补 `stale_live_identity_blocks_a_reload_apply_before_commit`：
  只在**热路径**（reload / api patch，无 SpawnCore）验证“陈旧 identity 必须阻断 apply”——
  因为 Restart 计划里新 core 报告新 identity 本就是正确行为。
- **残留**：`RuntimeDriver::config_identity()` 仍返回骨架常量（`"mihomo-skeleton-config"`），
  与 plan 侧无连接；这是 Phase 8 真接 runtime 时要对齐的边界，已写入待办。

### 4.2 `SimWorld::crash_after_effect_step` 注册了一个没人查询的 label，永远不可能触发（已修）

- **Observed**：`FaultInjector::take_matching(label)` 按 **label 全等**匹配，
  而该 helper 注册的 label 是 `format!("crash-after-step-{step}")`；
  调用方只会以 `"fs.write_atomic"` / `"proc.spawn"` 这类 **port 名**查询。
- **Reproducer**（修复前）：注册 `crash_after_effect_step(3)` 后反复
  `maybe_fail("effect.step")`，永远 `Ok`。
- **Impact**：`ADR-022` 的“可在任意 `EffectStep` 后触发崩溃”设施在 API 层就不可达。
- **Disposition**：引入共享常量 `caly_io_sim::EFFECT_STEP_LABEL = "effect.step"`，
  `world.rs` 与 `scenario.rs` 的 `crash_after_effect_step` 都改用它注册；
  并由 `port_level_and_executor_level_crash_injection_agree` 断言
  “port 级注入点 == executor 记录的中止游标”。

### 4.3 `VirtualClock::advance_ms` 会把虚拟墙上时钟**往回拨**（已修）

- **Observed**：`wall_clock_unix_ms.saturating_add(millis as i64)`，
  而 `millis: u64 > i64::MAX` 时 `as i64` 变成负数。
- **Reproducer**（修复前）：
  ```text
  VirtualClock::new(i64::MAX - 10).advance_ms(u64::MAX)
  -> wall = 9223372036854775796（比调用前更小），monotonic = u64::MAX
  ```
- **Impact**：`ADR-014` 的 `D0`（纯内存、无期限等待）与所有 deadline/timeout 逻辑
  都依赖“墙上时钟单调不减”。一个能倒退的虚拟时钟会让仿真**系统性地产生假通过/假失败**。
- **Disposition**：改为 `i64::try_from(millis).unwrap_or(i64::MAX)` 饱和化，
  并由 `virtual_clock_advance_saturates_and_never_goes_backwards` 固化。

### 4.4 附带记录的一个语义陷阱（未改，只文档化）

`SharedFaults::maybe_fail(label)` **先 `advance_step()` 再匹配**，
因此 `trigger_after_step: Some(N)` 的含义是“第 N 次调用时触发”，而不是“N 步之后触发”（差一）。
改匹配顺序会影响所有 fault kind 的既有语义，收益不抵风险，故在
`crates/caly-io-sim/tests/simulation_primitives.rs` 里用注释 + 断言把真实语义钉住。

---

## 4bis. 第二轮（effect 执行 + 门禁之后）新发现的问题

> 这一轮的多数条目是**写测试和做重构时**撞出来的，与 §4 同一性质：静态阅读和 `cargo check` 都不会报。

### 4.5 `caly-engine` 里有第二份 storage supertrait 合集，而且没有任何人用它

- **Observed**：`coordinator.rs` 定义 `pub trait CoordinatorStorage: ObjectStore + RevisionStore +
  SnapshotStore + JournalStore + ApplyJournalStore + Send + Sync` + blanket impl，
  但 `grep -rn "CoordinatorStorage" --include=*.rs crates/` 只命中定义处本身。
- **Impact**：死抽象 + 重复定义。真正的可替换性缺口（§3.4）它一点没帮上：`EngineHandle` 仍持具体类型。
  这类"看着像扩展点、其实是装饰"的 trait 会让下一位读者以为后端已经可换。
- **Disposition**：删除，把这一份定义收敛成 `caly_storage::StorageBackend`（放在拥有这些 trait 的 crate 里）。

### 4.6 恢复扫描只看 `Pending`，于是"补偿也失败了"的事务从扫描里消失（已修）

- **Observed**：`scan_recovery_state` 用 `list_pending_apply()`（过滤 `state == Pending`）。
  而 `commit_snapshot` 失败时会把 journal 标成 `RecoveryFailed` —— **不再是 Pending**，
  于是 `STORAGE_RECOVERY_EXECUTION_PLAN.md §6.2` 情况 B（最严重的一种）在启动扫描里完全不可见。
- **Reproducer**：写 `a_busy_snapshot_store_leaves_a_recovery_trace_not_a_fake_success`
  注入 `put_snapshot` 失败，断言"扫描必须还能看见它"——第一次跑就红了。
- **Impact**：文档承诺"失败不污染运行态 + 崩溃可恢复"，但最需要人工介入的事务被静默吞掉；
  doctor / support bundle（§9.2）也读不到它。
- **Disposition**：`ApplyJournalStore` 新增 `list_unresolved_apply()`（`Pending | RecoveryFailed`），
  扫描改用它；`build_recovery_scan_report` 对 `RecoveryFailed` 产出
  `RecoveryDecision::EnterFailedState`（不自动重试回滚，只持续报警）。
  报告字段随之改名 `unresolved_apply_journals`；**daemon 的公开 DTO 字段 `pending_apply_count` 名称不动**
  （`STYLEGUIDE.md`：进入公开 DTO 的名字优先稳定）。

### 4.7 `make_header` 把 `usize` 长度截断成 `u32`（已修）

- **Observed**：`FrameHeader { length: length as u32, .. }`。
- **Impact**：载荷 > 4 GiB 时长度回绕成小值，`validate_frame_header` 的 `FrameTooLarge` 门禁
  就被绕过，问题推迟成一个语义完全不同的 "declared length does not match payload" 错误。
  本仓库当前不会构造这种帧，但这是 transport 层将来接真 I/O 时的典型陷阱。
- **Disposition**：改为 `u32::try_from(length).unwrap_or(u32::MAX)`（饱和化），
  并由 `header_length_saturates_instead_of_wrapping` 断言"超限帧在 header 校验处就被拒"。

### 4.8 本轮对我自己上一轮产物的返工（自我审计）

上一轮我批评了别人的结构与验证问题，但**我自己写的东西也有该返工的**。逐条列出，避免"只留档别人"：

| 问题 | 为什么算质量问题 | 处置 |
|---|---|---|
| `execute_profile_apply` 长到 **383 行** | 相位推进、事件格式化、错误翻译三件事交织；新增一个阶段要读懂全文 | 拆成 `gate_capability` / `report_planning` / `persist_projection` / `execute_effects` / `commit_snapshot`，事件与 `mark_finished` 只存在于 `ApplyRun` 一处；最大函数约 55 行 |
| `executor.rs` 1398 行，同时是"解释器"和"世界模拟器" | 生产逻辑与测试替身混在一处，换后端时看不出哪些是要替换的 | 拆出 `sim_runtime.rs`，并给它补 9 个针对世界模型自身的测试 |
| `ApplyFailure { error: ApiError, .. }` 未装箱 | 直接把 clippy `result_large_err` 从 23 顶到 34，等于用"提高基线"掩盖自己引入的问题 | 装箱 `error: Box<ApiError>` + builder 化，lint 回到 33（**没动基线**） |
| `StepOutcome::Rejected` 同时表示"门禁拒绝"和"崩溃注入" | 两种运维含义相反的东西共用一个外观 | 改为 `Skipped { skip: StepSkip::{Gate{..} \| CrashInjected} }`，并加测试断言二者可区分 |
| `next_clock_tick` 要在成功/失败两条路径手工同步 | 典型的"可派生状态被存下来"，迟早漂 | 改为派生方法 `clock_ticks()` |
| `apply.rs::render_effect_step` 与 `executor::step_label` 是同一枚举的两份 match | 两份文本必然分叉（文档 §3.3 说代码注释只能细化规范，同理内部投影也只能有一处权威） | `render_effect_step` 委托 `step_label`。注意：**`DeploymentPlanView.steps` 的展示文本随之变化**（信息更全，字段与类型不变） |
| 重构第一稿里我写了 `let _ = run.stage(..)` | 吞错误比重构前更糟：事件写失败会被静默丢掉，正是我上一轮批评的"fail-open" | 定稿前全部改为 `?`，并加 `impl From<String> for ApplyFailure`，让"记录进度失败"成为显式的内部故障而不是噪声 |

留一条通用教训：**重构时最容易从 `?` 退化成 `let _ =`**，因为签名换了以后编译器会诱导你"先让它过"。

### 4.9 根目录 `clippy.toml` 的禁令把 IO 网关自己也封死了（已解决）

- **Observed**：要写 `caly-io-std`，`ADR-014` 的 D2/D3 需要 `fsync`（必须有 `std::fs::File`），
  `RFC-0006 §15.5` 需要单调时钟（必须有 `Instant::now` / `SystemTime::now`）——
  而这四个符号被工作区根的 `clippy.toml` **无差别禁用**。也就是说，照禁令写，网关永远写不出来。
- **Impact**：`ADR-011` 的意图是“只有网关能碰世界”，但禁令的写法是“谁都不许碰”，
  包括那个唯一被授权的地方。这类“守卫规则与其保护对象冲突”的情况，只有在真要写实现时才会暴露。
- **Disposition**：新增 `crates/caly-io-std/clippy.toml`（clippy 会从源文件目录向上查找配置），
  只在该 crate 放开 `fs::File` 与两个 `now`，**保留** `std::process::Command` 与 `PathBuf` 禁令；
  文件头写明依据。这样豁免是**位置受限且自述**的，而不是散落的 `#[allow]`。

### 4.10 `SimFs::lock_exclusive` 永远成功，锁语义在仿真里不可证（已修）

- **Observed**：`port_impl.rs` 的实现只是把 `FileLock{path}` 原样返回，不检查是否已被持有。
- **Impact**：任何“持锁期间第二个写入者被拒”的场景在仿真里**永远测不到**；而崩溃恢复恰恰依赖
  “锁仍在”这一事实。更结构性的是：`Fs::lock_exclusive` 返回的是普通值 `FileLock { path }`，
  既没有 guard 也没有 `Drop`，所以 trait 层面**根本没有 release 这半边** —— 无法释放的独占锁
  在重启后就是永久死锁。
- **Disposition**：新增 `caly_io::contract::FsLocking { lock, release, release_path }`
  （`release_path` 供崩溃后的清理使用），两个后端都实现；仿真侧把锁建模为 `MemFs` 里的一条
  锁文件记录，于是与 `StdFs` 的 `create_new` 行为等价。
  把 release 折进 `Fs` 本体是破坏性改动，需单独 ADR，已在 trait 文档中注明。

### 4.11 `RFC-0006 §15` 的契约测试没有任何承载体（已建）

- **Observed**：RFC 明确要求“`caly-io-std` 与 `caly-io-sim` **SHOULD 通过同一套契约测试**”，
  但仓库里既没有 `caly-io-std`（`ROADMAP.md §4` 列为待补），也没有任何跨后端共享测试。
- **Impact**：两个实现各写各的，语义分歧不会被发现；而 `ADR-022` 让**仿真**成为发布门禁——
  门禁于是校验了一个生产实现并不存在的世界。
- **Disposition**：新增 `caly-io/src/contract.rs`（与 trait 同处，供两个后端共同调用）+
  `caly-io-std/tests/contract.rs`、`caly-io-sim/tests/contract.rs`。
  覆盖 RFC 七条中的 1/2/5/7 与锁语义；3（`Http` body 上限）、4（`Proc` 不经 shell）显式标注为
  未实现（`caly-io-std` 目前只提供 `Fs` + `Clock`），不做假覆盖。

### 4.12 我自己写的门禁脚本有个 fail-open 变体（已修，教训记录）

- **Observed**：`scripts/check.sh` 统计 clippy 告警位置数做棘轮。但 cargo 会**按 crate 缓存 lint 结果**：
  同一份代码，全量重编的那次报 34，缓存命中的那次报 32 —— 数字随缓存状态漂移。
  更早一版在 `cargo` 不在 `PATH` 时还打印出 “check is clean”（工具缺失被当成通过）。
- **Impact**：门禁数字不稳定 = 可以随时靠“再跑一次”变绿；这比没有门禁更危险，因为它看起来是绿的。
- **Disposition**：lint 阶段改为在一次性 `CARGO_TARGET_DIR`（`mktemp -d`）里跑，每次都是全量 lint；
  测试阶段仍用常规 target 目录（测试结果不依赖 lint 缓存）。
  **并且用一条人为插入的 `let unused_binding = 1u8;` 验证门禁确实会红**（实测：`FAIL cargo check
  produced warnings/errors` + `FAIL clippy locations grew: 33 > baseline 32`，退出码 1；撤销后恢复绿）。
  教训：**任何“检查”在被证伪之前不算存在**——`§2.5` 的 arch 守卫、`§3.1` 的空绿测试、这条门禁，
  是同一个错误的三个实例。

### 4.13 一条纯操作性教训：改动被 rustfmt 重排过的文件时别用单行锚点

- **Observed**：我给 `ALLOWED_DEPENDENCY_EDGES` 加新边时，用单行
  `DependencyEdge { from: "caly-io", to: "caly-common" },` 作锚点做替换；而该常量早已被 rustfmt
  重排成多行形式，替换静默未命中（脚本只 `replace` 未断言），结果 `caly-io-std -> caly-io` 漏登记。
- **抓到它的**：正是上一轮加的 `no_undeclared_production_dependency_edges` /
  `adapter_wiring_debt_is_declared_and_bounded` 两个测试。
- **Disposition**：此后所有脚本化改动一律 `assert old in s`；且**先跑门禁再看结果**，而不是相信编辑成功。

### 4.14 `ObjectStore::put` 根本没有载荷：所谓 CAS 只是一份 digest 索引（已修）

- **Observed**：`CasWriteIntent { object, source_label }` 里**没有字节字段**，`ObjectStore::put`
  收到的只是"关于某个对象的元数据"。`build_apply_storage_projection` 因此也只填了
  `digest / size / content_type`，`CompiledArtifact.bytes` 从未进入存储。
- **Reproducer**（修法之前）：`grep -n "pub struct CasWriteIntent" -A 4 crates/caly-storage/src/cas.rs`
  —— 没有 payload；而 `memory.rs::materialize` 的实现只是
  `if guard.contains_key(digest) { Ok(()) } else { Err(NotFound) }`，**没有内容可产出**。
- **Impact**：`RFC-0007 §6.4` 要求物化"得到可供目标消费者使用的工件副本"，但在只有索引的存储上
  这是**不可能兑现**的：`materialize` 只能回答"我知道这个 digest"，不能回答"文件在这儿"。
  这也解释了为什么"可落盘"长期停在 `Skeleton`：不是没写完执行器，而是存储接口没有内容通道。
- **Disposition**：`CasWriteIntent` 增加 `payload: Vec<u8>`（并提供 `metadata()` / `with_payload()`
  两种构造，纯索引场景仍然合法）；`ApplyStorageProjectionInput` 增加 `artifact_bytes`，由
  `caly-engine::apply` 从 `compile.artifact.bytes` 填入。两个后端都改为：写入时由**存储**计算
  `sha256:<hex>` 作为 `content_sha256`（而不是信任调用方），`materialize` 前重新校验；
  校验不过 → `IntegrityViolation`，与 `§6.3`"部分写、截断、损坏不得静默容忍"一致。

### 4.15 `Fs` Port 没有目录列举能力，任何持久化后端都得自己造索引（已修）
> **第十六轮更新**：`ADR-035` 第 2 步已落地 —— `manifest/*.idx` 的读写与 `load_manifest` /
> `save_manifest` / `manifest_add` 一起删掉，集合枚举改走 `Fs::list`，`fs_store::list_directory` 是端口根
> 与 store 根之间唯一的换算点。本条描述的绕行**已不存在**；`open()` 的校验语义随之从「清单与实体一致」
> 改为「实体自洽」，保留项、放弃项与一个未解决的孤儿内容问题都写在 `ADR-035 §6bis-ter`。
> 下面 §4.15 正文保留原样，因为它记的是「当时为什么只能那么做」——那是这段历史的唯一记录。
> **第十五轮更新**：`ADR-035` 第 1 步已落地 —— `Fs::list` + `ListCap` 进入端口，两个后端跑同一套共享契约（`caly_io::contract::fs_listing_violations`）。本条的**根因**（端口没有列举能力）已消除；但 `manifest/*.idx` 本身还在（第 2 步未做），所以状态是「缺口已可修，尚未修」，不是「已修」。
> —— 本条的"尚未修"已被上一条（第十六轮）取代；保留是为了记下"补了能力并不等于绕行的那层消失了"。

- **Observed**：`caly_io::Fs` 有 read / write_atomic / rename / remove / stat / link_or_copy /
  open_stream / lock_exclusive，**没有 readdir/list**。于是"当前有哪些 pending journal"这类
  问题在端口层无法通过扫目录回答。
- **Impact**：任何真实后端要么被迫维护一份"索引文件"，要么绕过网关直接摸 `std::fs`（后者违反
  `ADR-011`）。前者是本仓库现在选的路：`caly-storage/src/fs_store.rs` 用
  `manifest/<kind>.idx` 充当可枚举集合，代价是"清单与实体不一致"成为新的失效模式
  （因此 `open()` 会在加载阶段逐条校验内容摘要，宁可拒绝启动也不静默跳过）。
- **Disposition（第十六轮：已按建议落地）**：留档为端口能力缺口。当时建议「后续在 `Fs` 上补 `list(prefix) -> Vec<String>`
  （含 `Ctx`、按 `ByteCap`/条目数限流），届时可移除清单文件；这需要改冻结的 trait，应走 ADR。

### 4.16 现有 `artifact_digest` 是 64 位非密码学校验和，不能兼任完整性校验

- **Observed**：`caly-core::native::artifact_digest` = `"{core}:{:016x}"`，来自
  `stable_checksum_bytes`（FNV 型）。`RFC-0007 §6.2` 却要求写入时"完成摘要校验"。
- **Impact**：64 位非密码学校验和无法可靠发现截断/篡改；拿它做"校验"只会给人已经校验过的错觉。
- **Disposition**：**没有**替换主流水线里的 digest（它是当前 profile 语义一致性的标识，牵动
  revision/snapshot id 与既有断言），而是在存储层**另加** `content_sha256` 承担完整性职责，并在
  `caly-common::digest` 内实现 SHA-256（纯 std，零依赖，用 NIST 向量证伪实现）。
  两者职责分离已在类型注释写明。是否统一为一个真摘要，留给后续 ADR。

### 4.17 `MaterializationRequest::runtime_path` 的基准没有定义（已定明并留档）

- **Observed**：`RFC-0007 §6.4` 只说"从 CAS 到 `runtime/` 的物化"，**没说这个路径相对谁**。
  `caly-ir` 侧填的是 `format!("runtime/{profile}/{entry}")`（不带根），而 `caly_io::Fs` 的路径相对
  *端口自己的* 根；`FsStore` 又再加一次 store 根。两层都有根，接口里却没写清基准。
- **怎么发现的**：只有真文件系统能暴露。给 `FsStore` 传已带前缀的 `runtime_path`，在仿真后端上
  "看起来正常"（`SimFs` 没有自己的根，键就是相对路径），在 `StdFs` 上却写出 `<root>/store/store/runtime/...`。
  `crates/caly-storage/tests/fs_store_on_real_disk.rs` 第一次跑就因此红。
- **Disposition**：在 `fs_store.rs` 模块文档与测试注释两处写明 —— **`runtime_path` 相对 store 根**，
  前缀由 `FsStore` 负责；并让真盘测试断言最终落点。
  建议把该约定写入 `RFC-0007 §6.4`，否则下一个后端作者仍会踩。

### 4.18 `ObjectStore` 既不能枚举也不能删除：`RFC-0007 §13` 的 GC 在接口上就无法实现（已补）

- **Observed**：`ObjectStore` 只有 `put / get / materialize`。GC 需要两件它都没有的能力：
  **候选集**（store 里到底有哪些对象）与**删除**。`grep -rn "gc\|garbage" crates/` 在动手前**零命中**。
- **Impact**：`§13.1` 的 root 集与 `§15.6` 的验收条款（"GC 不删除被 Active/Snapshot/Journal 引用对象"）
  在任何后端上都无法落实 —— 不是"实现得弱"，是**没有入口**。
- **Disposition**：`ObjectStore` 增加 `list_objects()` 与 `delete(digest) -> bool`；
  GC 策略单独成模块 `caly-storage/src/gc.rs`（`collect_gc_roots` / `plan_object_gc` / `run_object_gc`），
  **store 保持无策略**：它不知道什么是 root，所以"随手 delete"不会被误当成 GC 安全操作。
  实现顺序也按 `§13.2`：先算计划再删除；删除失败不中断整轮，但会计入 `GcReport.failed`。

### 4.19 daemon 恢复只回填 `active_snapshot`，不回填 `active_profile`：重启后状态视图是假的（已修）

- **Observed**：`apply_recovery_snapshot` 里是
  ```text
  runtime.active_snapshot = report.latest_last_known_good.map(|id| id.0);
  if report.latest_last_known_good.is_none() { active_profile = None; ... }
  ```
  —— 有 LKG 时**只设了 snapshot 一项**；`active_profile / active_core / last_apply_plan_summary`
  只在 `sync_runtime_from_engine()`（submit/drain 路径）里才被填。
- **后果**：重启后 `system.status` 报"没有活动 profile"，而同一个 daemon 又能立刻在其上继续 apply。
  同一个问题两个答案，取决于进程是否重启过。此前测不到，因为**没有"重启"这条路径**：
  `DaemonApp` 的存储后端一直是 `InMemoryStorage`，其生命周期等于进程生命周期。
- **Reproducer**：`crates/caly-daemon/tests/durable_boot.rs::a_restarted_daemon_rediscovers_the_committed_deployment`
  第一次跑即红（`active_profile: None`）。
- **Disposition**：恢复时按 snapshot id 读回完整记录并回填三项；**若 marker 指向读不回的记录，
  daemon 直接进入 `Failed` 并写 `last_error`**，而不是安静地报告一个"空但健康"的运行态。
  顺带把 `bootstrap` 里 `let _ = app.recovery_scan().and_then(...)` 这个 fail-open 去掉：
  `try_bootstrap` 对扫描失败**拒绝启动**（`DaemonStartError.store_unusable = true`）。

### 4.20 grace period 需要时间，而存储层被禁止读时钟（用注入时钟解决，并定义"未知即保守"）
> **第十七轮更新**：`ADR-035` 第 3 步已落地 —— `FsStore` 交出对象记录前用 `Fs::stat` 的 mtime 定年，
> 与调用方声明冲突时取**较新**的一侧（比 ADR 字面更保守，理由见 `ADR-035 §6bis-quater`）。本条的
> 「注入值可以被谎报」这一半已修；「**`now` 仍是调用方给的**」与「**GC 没有生产调用者**」两半没修，
> 记在 `§4.72` / `§4.73`。「未知年龄保守不删」仍是兜底行为。
> **第十五轮更新**：`Meta.modified_at_unix_ms` 已存在，`StdFs` 读真实 mtime、`SimFs` 只认注入的虚拟时钟，且只在 `write_atomic` 时盖章。GC 改用它属于 `ADR-035` 第 3 步，尚未做。

- **Observed**：`§13.1` 要保护"尚在 grace period 内"的对象，但 `clippy.toml` 禁 `SystemTime::now`，
  `Fs::stat` 返回的 `Meta` 也只有 `len/is_file/is_dir`（**没有 mtime**）。所以"这个对象多新"无法查询。
- **Disposition**：`CasObjectRef.stored_at_unix_ms` 由**写入方**带入（`apply` 路径用与 journal 相同的
  注入时钟），GC 用 `GcPolicy::now_unix_ms` 比较。关键取舍：**年龄未知 = 永久在 grace 内**，
  即"不可判定"永远倒向不删除 —— 多留一轮是可逆的，误删是不可逆的。
  这条判断写在 `gc.rs` 模块头，并有一条专门测试钉住（`an_object_of_unknown_age_is_never_collectable`）。

### 4.21 `apply_recovery_snapshot` 末尾无条件覆盖 `lifecycle`，前面写好的 `Failed` 被抹掉（已修）

- **Observed**：函数体末尾一直是
  ```text
  runtime.lifecycle = if report.decisions.is_empty() { Starting } else { Recovering };
  ```
  任何在前面分支里设置的 `Failed` 都会被这一行覆盖。
- **怎么发现的**：不是读代码读出来的，是我给"marker 指向读不回的快照"写断言时红的
  （`left: Starting, right: Failed`）。也就是说：**这个函数当时没有任何方式表达"恢复没成功"**，
  即便有别的代码想标 Failed 也标不上。
- **Disposition**：改成单一出口 —— 先算 `unresolvable: Option<String>`，最后**一次**决定 lifecycle
  （`Failed` > `Recovering` > `Starting`），并把原因同时写进 `last_error` 与 `last_recovery_summary`，
  使 `system.status` 与 `doctor` 看到的是同一个故事。

### 4.22 我用"再读一次同一条路径"当校验，被自己的测试否掉了（教训）

- **Observed**：为了让"快照读不回"这一分支更宽容，我第一版加了 fallback：
  `get_snapshot_by_id` 失败就退回 `latest_last_known_good_snapshot()` 再取一次。
- **为什么错**：`report.latest_last_known_good` **本来就是**从 `latest_last_known_good()` 算出来的。
  拿同一条读路径当"独立证据"，等于用一个说法印证它自己 —— 后端自相矛盾时它会一致地返回同一个值，
  于是 `Failed` 分支永远不会触发，测试也就永远测不到我想测的东西。
- **Disposition**：删掉 fallback，并在代码里写明"故意不做回退"的理由。
  留作通用教训：**校验必须来自第二条独立路径，否则它就是装饰。**

### 4.23 契约 / parity / scenario 三套报告机制**没有任何判定者**

- **Observed**：`ContractReport::all_passed`、`ParityReport::all_match`、`ScenarioSuite::all_passed`
  三个判定函数都存在，但 `grep -rn "all_passed\|all_match" --include=*.rs crates/` 显示
  **只有定义处，零调用处**。它们生成的报告被丢弃。
- **Impact**：`LOOPBACK_CONTRACTS.md` 与 `SCENARIO_SUITE.md` 把这套东西描述成质量门，实际上
  任何用例失败都不会让任何东西变红 —— 与 `§2.5`（arch 守卫无人调用）、`§3.1`（0 测试空绿）同族。
- **Disposition**：新增 `crates/caly-app/tests/contract_gate.rs`（6 条），要求 bundle 至少覆盖
  N 个用例、**并且每一项都通过**；失败时打印不通过用例的名字与 detail，而不是一个 `false`。

### 4.24 parity 比对的是**两个不同的 daemon**，因此它结构上不可能发现分歧（已修）

- **Observed**：`build_loopback_remote_client()` 内部自己 `DaemonApp::bootstrap(...)` 造了一个
  `"loopback-daemon"`，而 `run_basic_loopback_parity(&local)` 的 local 来自调用方的另一个 daemon
  （`run_facade_parity_scenario` 里是 `"parity-daemon"`）。两侧从来不是同一份状态。
- **Reproducer**：把 `contract_gate` 的断言打开即见 —— `system.info` 永远 Mismatch：
  `local instance_id: "parity-daemon"` vs `remote instance_id: "loopback-daemon"`。
- **Impact**：这比"测试没写"更糟：**parity 检查一直有一个稳定失败项**，而真正的分歧
  （同一个状态在 local/remote 两条路径上给出不同答案）会被这堆噪声淹没。ADR-017 的
  "local/remote 共享同一 DTO 语义"因此实际处于未验证状态。
- **Disposition**：`LoopbackRemoteTransport::with_app(daemon)` + `build_loopback_remote_client_with(daemon)`，
  parity 入口改为接收 **一个 daemon**，两侧都从它构造；`run_parity_scenarios` 同样共享。
  现在 `loopback_parity_matches_after_a_real_deployment` 在**部署过之后**比对 4+ 字段且全 Match。

### 4.25 "查到了，但没有这个对象"被上报成"这个操作没人处理"（已修）

- **Observed**：`handle_request` 对三条路径的 `Ok(None)` 一律回
  `unsupported_request_response`（"operation routed to X but no daemon handler is connected yet"）。
  而 `handle_diagnostics(FollowJob)` 在 job 不存在时正是返回 `Ok(None)`。
- **连带**：`run_remote_follow_scenarios` follow 的是硬编码的 `JobId(1)`，**从来没有提交过 job** ——
  所以这条 scenario 一旦真被断言就必然红（本报告 4.23 之前没人断言，所以它一直"静默失败"）。
- **Impact**：两个语义被压成同一个错误：客户端拿到"未实现"会以为别调用这个 API；
  实现者拿到"未实现"会以为还有活没干完 —— 两个方向都被误导。
- **Disposition**：`FollowJob` 的 None 改为带对象的类型化错误
  （`Conflict` + `"no such job: 4242"` + `remediation: job history is not durable`），
  `unsupported_request_response` 只留给真正没有 handler 的操作（如 `SupportBundle`）；
  scenario 改为**先提交 apply、拿到真实 job id 再 follow**，并断言 job 被处理。

### 4.26 `doctor` 有一条永久占位 warning，于是"没有告警"不再是信息（已修）

- **Observed**：`handle_diagnostics::Doctor` 起手就是
  `let mut warnings = vec!["diagnostics pipeline is still partial; verify against real core runtime later"]`。
  任何一次 `doctor` 都非空 ⇒ 真实发现与占位符不可区分；`REMOTE_FACADE_PARITY` / contract 里
  `!doctor.warnings.is_empty()` 这类断言因此**恒真**（我改完之后它立刻变假，见 4.27 的下半段）。
- **Disposition**：
  - 新增 `caly-storage::audit`：纯函数计算 `STORAGE_RECOVERY §9.2` 承诺的四项发现
    （dangling pending journal / abandoned runtime / no valid last-known-good / snapshot-object mismatch），
    `§9.2` 四条现已全部有实现与断言；
  - `DaemonApp::storage_audit()` 通过后端自省的 hook 收集，**内存后端如实回答"不可观测"**，
    不编造一个"一切正常"；
  - `DoctorReport` 增加 `notes` 字段（第三档）。信息性内容以前只能塞进 warnings，
    那正是占位符存在的理由。

### 4.27 两处与 trait 设计有关的硬事实

1. **`impl<T: 五个store trait> StorageBackend for T {}` 让"带默认实现的可覆盖 hook"不可能存在。**
   我想给后端加"默认回答 unknown、真后端覆写为真话"的自省方法，结果：blanket impl 已覆盖所有类型，
   `impl StorageBackend for FsStore { …覆写… }` 直接 `E0119 conflicting implementations`
   —— Rust 没有 specialization。要么放弃覆写（所有后端永远回答 unknown，包括唯一知道答案的那个），
   要么改为**显式 opt-in**。选了后者；代价立刻可见：三个测试替身缺 `impl StorageBackend for X {}` 编不过。
   这也顺带变成一个优点：那一行现在是"本类型是一个完整可替换后端"的显式声明。
2. **`StorageErrorKind` 没有 `Unsupported`，而 `SchemaMismatch` / `MigrationFailed` 两个变体零使用。**
   "后端不支持"只能挤进 `Internal`，语义丢失。已加 `Unsupported`，用于
   `list_snapshots` 这类"可选能力"的默认回答：**不支持 ≠ 空**，混淆这两者会让调用方把
   "没实现"读成"确实没有"。（两个死变体保留，它们属于尚未实现的 `§7.3` 迁移路径。）

### 4.28 `RFC-0010` 要求的脱敏机制在代码里完全不存在（已补）

- **Observed**：`RFC-0010 §3.3` 用 MUST 规定「脱敏 **MUST** 在对象构造或边界转换时完成，而不是仅在
  显示阶段处理」，`§6.1` 点名四个边界（`ApiError` 构造、`LogLine` 构造、support bundle 生成、对外 DTO
  映射），`ADR-020 §4` 的 Follow-up Work 里还留着「为 `ApiError` 建立统一 redactor」。
  本轮实测：`grep -rn 'redact\|Redact\|Secret' crates --include='*.rs'` → **0 命中**（本轮之前）。
  同时存在真实的泄漏通道，而且不是理论上的：
  - `worker.rs` 把客户端传入的 `node_ids` 原样 `format!` 进 job 日志；
  - `app.rs::refusal_for_lifecycle` 把 `command_line(kind)`（含请求里的 profile id）原样放进
    `ApiError.detail`。
  两者都会经 follow 投影、事件流与（当时的）bundle 出口送到操作员眼前。
- **Why the docs said nothing**：`IMPLEMENTATION_STATUS` 的 `§14` 门禁表只写「待补」，没有写「一行代码
  都没有」；读文档得到的印象是「有一个不完善的 redactor」，实际是没有。
- **Disposition**：`caly-common::redact`（20 个测试）+ 三条出口各自接线，见 `docs/REDACTION_AND_SUPPORT_BUNDLE.md`。
  本轮两次实测的失败注入证明三条边界互相独立（撤掉 `append_job_event` 的掩码，只有那两条测试炸）。

### 4.29 `DiagnosticsOp::SupportBundle` 是「被接受、执行成功、什么都没导出」的三步空转（已修）

- **Observed**：`request_map` 把它路由成 `CommandKind::DiagnosticsBundle`，worker 只追加一条
  `Log{"support bundle skeleton generated"}` 就 `mark_finished(Succeeded)`；
  `contract.rs` 的断言是 `processed == true`，`scenario_suite` 的断言是 `event_count > 0` ——
  两者对这条 skeleton 恒真。上一轮我把 `§9.3` 记成「只欠组装与脱敏」，实测连「原料读取」都没有：
  bundle 段里该有的 apply journal 摘要无法读出（见 4.30）。
- **Disposition**：新增 `caly-engine/src/bundle.rs`：10 个固定段（`BUNDLE_SECTIONS`）、`draft → finish(redactor)`
  两段式（导出物只有「已掩过」这一种合法形态）、字节走 `ObjectStore::put` 的 `ObjectKind::SupportBundle`
  对象，作业上报内容摘要。旧 skeleton 换回来时
  `remote.diagnostics.support_bundle.committed` 立刻失败（本轮实测），因此这条断言不是摆设。

### 4.30 `ApplyJournalStore` 无法枚举「已提交」的 journal：`§9.3` 第 1 项在接口上就做不到（已补）

- **Observed**：trait 只有 `list_pending_apply` / `list_unresolved_apply` / `get_apply_journal`。
  「最近若干次 apply 的摘要」恰恰需要看到 `Committed`，而它正是两个 list 排除的那部分。与 `§4.18`
  （`ObjectStore` 不能枚举所以 GC 无处下手）是同一类缺口。
- **Disposition**：新增 `list_apply_journals`，默认回答 `Unsupported`（不是空列表）；
  `InMemoryStorage` 从内存表回答，`FsStore` **重新经 manifest 读盘**而不是交回缓存 ——
  这样一条记录损坏会在导出时报 `IntegrityViolation` 而不是被静默跳过（新增测试
  `a_torn_record_aborts_the_list_instead_of_being_skipped`）。`bundle::enumeration` 把
  「不支持 / 读不到 / 有内容」三分开，与 `§9.2` 的 `Observation` 同一原则。

### 4.31 `doctor` 与 bundle 会各自拼一份 `AuditInput`（已抽公共函数）

- **Observed**：`DaemonApp::storage_audit()` 里有 ~60 行「读后端自省 + 组装 `AuditInput`」的逻辑。
  bundle 需要同样的审计结论；照抄一份 = 将来任一侧改动就出现两个视图对同一个 store 说法不一。
- **Disposition**：下沉为 `caly_storage::audit_backend(backend, now)`，daemon 变薄壳；
  `StorageAudit` 补 `finding_lines()`（按发生顺序的全量视图，doctor 的三档分层是给人 triage 用的，
  导出物重排三份列表会把 info 读成 error）。新增测试 `doctor_and_the_bundle_report_the_same_finding`
  同时比对 finding 与 **同一行 summary**，一旦有人再抄一份组装就会漂移。

### 4.32 本轮我自己写出的两个反模式（同轮内发现并改掉）

1. `collect_header` 初稿写 `handle.bundle_identity().unwrap_or_default()`：又一个 `let _ =` 式
   fail-open（第 4.19 条刚修过同类）。改成显式分支，读不到时在 `header` 段里写
   `instance identity unavailable: engine state lock was poisoned`。
2. `ApiError::redacted` 初稿顺手写了 `.filter(|value| value.is_empty())`：脱敏**不是**丢弃数据的许可，
   一个空 `detail` 与一个不存在的 `detail` 在 DTO 上是两件事。删掉。

### 4.33 两条 `RFC-0010` 落地时撞到的规范空白（留档待决）

1. **`§4` 把 UUID 列为 Secret，`§4.1` 又把「可识别身份的信息」列为准 secret。** 二者对
   「默认策略是否掩 UUID」没有一致答案。本轮取「带 key 名的（`uuid = "…"`）默认就掩；裸 UUID
   只在 Strict 掩」，理由是本仓大量诊断以 hex id 作关联线索，而 `looks_like_uuid` 明确拒绝匹配
   更长 hex 串（对象摘要不是 UUID）。**这是一次解读，需要 maintainer 确认**，见
   `docs/REDACTION_AND_SUPPORT_BUNDLE.md §2.3`。
2. **`§6.2` 未提 percent-encoded 值，`§12.3` 只列内容类别、没给「哪些字段算 secret」的机器可检定义。**
   本轮的处理：嵌套 `url=` 值整段掩；其余只按字面字节匹配。并把「opaque path token 必须由持有者
   `register_secret`」写成显式契约而不是隐藏启发式。

### 4.34 文档编号缺陷（已修）

- `ONBOARDING_NOTES.md §6` 的处置表用 6.1…6.22 编号，而表后另一个小节标题也叫 `### 6.10`
  （「明确**不做**的项」）——同一文件两个 6.10。本文档正是用来留档「文档与代码不符」的，
  自身编号必须唯一，已把该小节改到表尾编号之后。
- 同轮在 `docs/README.md §2.5` 也发现一个 `3.` 重复（`ROADMAP.md` 与 `CENTERLINE_PROGRESS.md` 都编成 3），
  以及我自己在 §2.1 插条目时把后续编号顶歪（出现两个 `33.`）。两处已改为连续编号，
  并用「逐个有序列表必须连号」的脚本复查过：`non-contiguous: none`。
  教训与 `§4.13` 同源：**改文档也要有可执行的自检**，人眼看不出众号错误。

---

### 4.35 状态表自身也过期了：三处"未做"其实早已做完（已修）

本轮按惯例复核各状态文档的断言时，发现即使是**我们自己前几轮写下的**实测结论，也已经与代码不符：

| 文档原话 | 实测 | 处置 |
|---|---|---|
| `STORAGE_RECOVERY §` 头部：「`§8` 的 GC root 集仍未实现」 | `crates/caly-storage/src/gc.rs` 存在，`tests/gc.rs` 9 条测试 | 头部改写为"已实现" |
| 同一处：「仍未做的是把 `InMemoryStorage` 换成可替换后端」 | `EngineHandle::with_backend`（第二轮）+ `tests/storage_backend_swap.rs` | 同上 |
| `IMPLEMENTATION_STATUS §2`：「19 成员」 | `cargo metadata`：20（第三轮加了 `caly-io-std`） | 改为 20 并注记为何会错 |

这条对自己的教训比对外面那条更硬：**"实测过"不等于"现在是对的"**。凡是写进文档的实测结论，
改动它的那个人才有义务在下一轮复核时更新 —— 所以本轮把这些数字与"未做清单"集中重跑了一遍
（`find`/`wc`/`grep -c` 三项见 `IMPLEMENTATION_STATUS §3.3` 与本文末）。

**顺带把这类检查变成门禁**：`crates/caly-arch-test/src/docs.rs` + `tests/doc_consistency.rs`
（13 条单元 + 5 条 gate）现在每次 `cargo test` 都会扫 `docs/**` 全部 72 篇 Markdown，检查四件事：
表格每行列数一致且有分隔行、有序列表连号、同一文件内小节号唯一、以及反引号引用的
`crates/…`/`docs/…`/`scripts/…` 路径必须真的存在（本轮实测：198 处此类片段，其中 154 处是可直接判定的
引用，0 处失配）。最后一条正是这套文档最容易烂掉的地方：改名或删文件会立刻让断言失败，而不是等下一个人踩。
两处 `README` 编号重复与本文两处 `6.10` 都是它现在能自动抓到、而人眼会漏过的形状。
两个设计点：① 规则函数全是 `fn(text) -> Vec<DocIssue>` 纯函数，文件系统访问留在测试侧，
所以每条规则都能在单元测试里被**证伪**；② 有一条反-vacuity 断言（文件数 ≥60 / 引用数 ≥100 / 行数 ≥8000），
否则"扫到 0 个问题"可以只是"什么都没扫"。
例外写成常量 `DOCUMENTED_NON_MEMBER_CRATES`（`caly-tui` / `caly-foo`）：**允许"文档提到但不存在"，但必须写明理由**（`§5.3`）。
### 4.36 `§3.3` 的"实测数字"表本身在漂移（已改为门禁复算）

写文档计数门禁时顺手让程序数了一遍 `docs/IMPLEMENTATION_STATUS.md §3.3`，结果这张号称
「按文件实测、逐行相加核对一致」的表：

| 问题 | 表里写的 | 树里实际 |
|---|---|---|
| 总数 | 合计 **129** | 231 个 `#[test]`（上一轮末） |
| `caly-storage/tests/gc.rs` | 9 | 10 |
| `caly-daemon/tests/durable_boot.rs` | 6 | 10 |
| `caly-storage/tests/schema.rs` | **整行缺失** | 13 |
| `caly-arch-test/src/docs.rs` 等本轮新文件 | 无行 | 12 / 5 / 20 / 8 / 6 / 4 |

也就是说：**只有"这一行的数字对不对"被反复检查，"表还全不全"从来没人检查** —— 新增测试文件时忘记加行，
比写错数字更常见，因为它不会让任何东西变红。

**Disposition**：表已按口径重写（29 行、合计 231、逐行相加一致），并把三件事交给门禁
`caly-arch-test/tests/doc_consistency.rs::status_table_test_counts_match_the_tree`：
每行的数字必须等于该文件行首 `#[test]` 的条数（`count_test_attributes`）、表内提到的文件必须存在、
**有测试的文件必须有行**；合计标记必须等于行和。两条实测的证伪：把某行改成 24、删掉一行，
门禁分别报 `stale-count`、`broken-path-reference` 与"合计 231 vs 行和 222"。


### 4.37 `RemoteFacade` 给每类写操作伪造了一个常量 idempotency key（已修）

- **Observed**：`remote_facade.rs` 五处写操作分别传了 `"profile-apply"` / `"profile-rollback"` /
  `"source-update"` / `"network-repair"` / `"system-shutdown"` 作为 key，而 `LocalFacade` 传 `None`。
  引擎侧 `submit_checked` 按 `(actor, key)` 去重且**不比较载荷**，所以
  `("Cli", "profile-apply")` 是整个 daemon 的一个槽位：**同一个 daemon 上第二次远端 apply（无论哪个 profile、
  哪个调用方）直接返回第一次的 job 并原地完成**，不部署、不报错。本地路径同一对调用两次都跑。
  `RFC-0002 §4.1` 把「`idempotency_key` 处理语义」列为 Local/Remote **MUST** 共享项。
- **How it stayed invisible**：parity 只比查询（`status`/`list`/`plan(dry_run)`），写侧一次都没比过；
  而 contract 里那条 `remote.profile.apply.accepted` 断言的是 `job_id > 0`，去重后的旧 job 同样 > 0。
- **Disposition**：key 只从 `Ctx` 来（两条路径读同一个字段）；`a_constant_key_would_swallow_the_second_deployment`
  把「常量 key = 静音按钮」这件事作为行为永久钉住（而不是写在注释里）。

### 4.38 `Accepted.estimated_impact` 被 daemon 重建并硬编码成 `ReadOnly`（已修）

- **Observed**：引擎已经算了分类（`dispatch::classify_command`：`ProfileApply`→`Restart`、
  `ProxySelect`→`Reload`、`NetworkRepair`→`PrivilegedNetworkChange`），但
  `submit_engine_command` 只留下 `job_id`，`handler.rs` 再自己拼一个 `Accepted{ estimated_impact: ReadOnly,
  state_revision: runtime_snapshot()… }`。于是「这次改动会不会重启 core」这个调用方唯一能提前看到的字段，
  对所有命令恒为「什么都不会变」。
  同一处还有第二个后果：幂等重放路径也是**重建**一份 `Accepted`（用当前 generation + ReadOnly），
  所以同一个请求第一次和第二次拿到的答案不一样 —— `§8.3` 要求「重复命令 MUST 返回原 JobId 或等价 outcome」。
- **Disposition**：`SubmitCommandResponse` 改为携带 `caly_api::Accepted`（`handler` 原样转发），
  `IdempotencyRecord` 记下**原始那份** `Accepted` 并在重放时逐字返回。断言：
  `each_command_kind_reports_the_impact_the_engine_classified`（三类命令各自的影响）、
  `a_repeated_key_replays_the_original_answer_on_both_paths`（含 impact/revision 全等）。

### 4.39 远端 façade 把 `ApiError` 压成 String，再包成「可重试的传输失败」（已修）

- **Observed**：`RemoteSessionClient::send_operation` 一路是 `Result<_, String>`
  （`response.result.map_err(|e| e.summary)`），façade 再把这个 String 交给 `remote_unavailable`
  → 一律 `UNAVAILABLE / Internal / retryable=true`。也就是说 daemon 明确拒绝的 `CONFLICT`
  （例如本轮新增的 CAS 拒绝、第七轮修的 "no such job"）在远端变成了「不确定，可以重试」——
  这是最糟的组合：它会诱导对**被有意拒绝**的操作自动重试。`ADR-020` 与 `docs/ERRORS.md` 的整个前提
  （稳定错误码、退出码映射）在远端路径上不可达。
- **Disposition**：新增 `send_operation_checked` / `with_client_api`，façade 的 37 处调用全部改走它，
  daemon 的 code/category/retryable/remediation/diagnostics 原样到达；只有真正的调用失败
  （没握手、无响应帧、锁中毒）才合成 `Unavailable`。有损的 `with_client` 被限制在两个 stream 打开处，
  并有一条测试数它的出现次数（`the_lossy_wrapper_is_confined_to_the_two_stream_opens`），
  多一处就失败。**这条处置在第十一轮被推翻并加强**：那两个"剩下的"stream 打开处也接上了类型化路径，
  计数棘轮改为 0 值断言（`no_facade_path_flattens_a_daemon_error`），见 `§4.51`。历史记录保留原样，
  是为了留下"当时为什么觉得 2 处是终点"这个判断本身。
- **一个必须记下的测量教训**：改完 `Box<ApiError>` 后门禁报 "locations shrank: 23 < baseline 32"，
  我据此准备下调基线 —— 但把同一棵树连跑两遍，另一遍是 **32**。`cargo clippy` 会按 crate 重放缓存的
  lint，所以 23 是**漏计**，不是改善（本轮新代码其实一处 `result_large_err` 都没消掉，也没新增）。
  差点把"工具没看到"当成"代码变好了"写进基线。修法在 `scripts/check.sh`：同一次门禁里跑两遍 clippy
  取**最大值**，缓存只能让数字变大、不能让它变小。见 `§4.44`。

### 4.40 `Ctx` 的三样东西在两条路径上被丢弃或改写（已修两处，一处留档）

`RFC-0002 §6` 要求「所有调用 **MUST** 透传统一上下文」。实测本轮之前：

| 字段 | 本地 façade | 远端 façade | 处置 |
|---|---|---|---|
| `deadline_ms` | 透传 | **硬编码 `Some(30_000)`** | 改为 `ctx.deadline_ms.unwrap_or(DEFAULT)` |
| `expected_revision` | 透传 | **恒为 `None`** | 改为透传；并在 `submit_checked` 里真正实现 CAS 检查 |
| `trace_id` | 透传 | **被每方法字面量顶掉**（`"remote-profile-apply"`） | 改为 `ctx.trace_id`，37 处 tag 删除 |
| `role` | 硬编码 `Admin` | 取 `ClientSessionConfig::default().role`，也是 `Admin` | **未改**：`Ctx` 里没有 role/auth 的位置，见 `ADR-037`（Proposed） |

`expected_revision` 那条尤其值得记：它从 `Ctx` → `RequestEnvelope` → `Command.context` 一路传得好好的，
**没有任何人读它**，所以「只有状态还在 revision N 时才执行」在两条路径上都是装饰。
本轮实现检查时有一个顺序决定要写下来：**重放查找在前、CAS 检查在后** ——
带 key 的重试必然携带第一次读到的 revision，若先查 CAS，每一次重试都会变成冲突，
幂等窗口反而变成失败来源（`a_replayed_command_is_not_blocked_by_the_cas_check`）。

### 4.41 `Idempotency::Required` 声明了 4 个操作，读它的人有 0 个（留档待决）

`ops.rs` 给 `system.shutdown`、`profile.apply`、`profile.rollback`、`network.repair` 标了
`Idempotency::Required`，`grep -rn '\.idempotency\b' crates` 在生产代码里**只命中一处**：
`caly-daemon/tests/apply_command_path.rs` 断言元数据本身。也就是说这个标志位既不校验缺 key 的请求，
也不触发任何派生 key。三条可选路径（拒绝无 key 的 Required 命令 / 由边界派生 key / 把标志含义降级为
「daemon 维持窗口」）影响面完全不同，见 `ADR-037`（Proposed）。本轮只把「key 从哪来、去重发生在哪、
重放答什么」这三件事做实，不动标志语义。

### 4.42 我自己第一版写侧 parity 是"绿但没测到东西"的（自查）

最初 `run_write_parity` 让两条路径用**同一个** dedup key 跑四条 case：于是远端的 `dedup-a`
命中的是本地路径刚写进窗口的那条 job —— `reused_previous_job=false`、`revision_delta=0`，
本地 `delta=2`，比对**看起来**失败了一次、被我"修"成各用各的 key 之后才真正表达意图。
教训两条：① 写侧 parity 的公平性要显式设计（窗口是 daemon 级的，不是路径级的），
② 「跨路径共享同一个 key 会去重」这件事本身是 `§8.3` 的要求，值得单独一条断言
（`write.dedup_spans_access_paths`），而不是被当成比对噪声消掉。

### 4.43 接手环境会退化：工具链与可执行位都不在快照里（本轮实测）

第九轮开局 `./scripts/check.sh` 直接 `Permission denied`，随后 `cargo not found on PATH`。实测：
快照保留了 `~/.cargo/bin/rustup`（一个 20 MB 的真实文件），但 `~/.rustup`（整套 toolchain）没进快照，
于是 `~/.cargo/bin/{cargo,rustc,…}` 这些指向它的软链全部失效；文件模式位同样没保住。
处置：`chmod +x scripts/check.sh`，并按 `§1.3` 的命令重装 toolchain + `rustfmt`/`clippy`。
**给下一个接手者**：新开一轮时先跑一次 `bash scripts/check.sh`（用 `bash` 显式解释，绕开模式位），
失败先看它是缺 cargo 还是缺执行位，两者都是环境而非代码问题。

### 4.44 门禁自己的读数会漏计：同一棵树报 23 与 32（已修）

- **Observed**：第九轮改完 `RemoteSessionClient` 的错误形状后，`./scripts/check.sh` 报
  `clippy locations shrank: 23 < baseline 32`。按"代码变好才下调基线"的规则，我准备把基线写成 23。
  把同一条命令在同一个一次性 target 目录里再跑一遍，得到 **32**。差的那 9 处不是被消掉了，
  而是**那一遍没被重放**：`cargo clippy` 对每个 crate 从缓存里回放 lint，一旦某些 crate 在该次调用中
  没有重新走 check 阶段，它们的历史 lint 就不会出现在输出里。这与 `§4.x` 记过的"计数随缓存变化"
  是同一个机制，只是这次它把**下降**伪装出来了。
- **Impact**：棘轮的价值全在"数字可信"。一个会向下波动的读数，等于允许任何人把自己那轮的改动
  说成"顺带修好了 9 处 lint"，并据此放松基线 —— 这正是这条门禁设立要防的事。
- **Disposition**：`scripts/check.sh` 在同一 `GATE_DIR` 内跑两遍 clippy，取 `-->` 去重行数的**最大值**
  作为读数；注释里写明为什么是 max 而不是第一次。基线维持 32，本轮新增代码贡献 0 处。
- **给下一个接手者**：任何"数量类"门禁（clippy 位置、覆盖率、测试数、格式化 diff）都要先问一句
  **"同一个输入跑两遍会不会给出不同答案"**；会的话，它必须对自身取 max/min 或强制冷跑，
  否则它会奖励错误的乐观读数。

**第二十五轮补记（同一课的新形态：新 lint 不在基线里）**：`clippy` 1.98 的 `manual_is_multiple_of` 与
`explicit_auto_deref` 各命中本轮新写的代码，位置数漂到 35 —— 而仓库里已有的同类写法一个都没被算进基线。
这不是棘轮失效，正是它的设计：**基线只豁免存量，新代码必须当场过**。所以顺序永远是「先让门禁跑在自己改过的
文件上，再谈别的」。本轮两条都改代码（`checks.is_multiple_of(N)`、`&*clock` → `&clock`），基线仍是 32。

### 4.45 存储层没有"把内容读回来"的路径：上一轮的导出是只写不读的（已补）

- **Observed**：`ObjectStore` 当时有 `put` / `get`（只有元数据）/ `materialize`（写到 runtime 路径）/
  `list_objects` / `delete`。也就是说：bundle 的字节确实进了 CAS、摘要确实印在作业上，但**没有任何人能把
  内容取走** —— `materialize` 回答的是"core 去哪儿读工件"，不是"操作员怎么拿到诊断包"。
  第八轮我在 `docs/REDACTION_AND_SUPPORT_BUNDLE.md §4.2` 把这写成"导出位置需要平台决策"，
  那个理由只对"写到用户指定路径"成立；对"读回给客户端"而言，缺的只是接口，不需要平台层。
- **Disposition**：新增 `ObjectStore::read_object(digest, max_bytes)`，默认 `Unsupported`
  （不是 `Ok(None)`）；两个后端都**先按记录锚点校验再交出生成**（`RFC-0007 §6.3` 的完整性要求延伸到读）；
  `DiagnosticsOp::ReadSupportBundle { request }` 是 Query，`digest: None` 表示"store 里最新的那个"。
  测试：`crates/caly-storage/tests/object_contract.rs`（8 条，同一断言跑两个后端）、
  `crates/caly-daemon/tests/support_bundle_readback.rs`（5 条）。

### 4.46 同一场景，两个后端给出不同答案（已对齐，并有契约测试）

补 `read_object` 时顺手把两个后端放在同一组断言下跑，立刻浮出两处不一致：

| 场景 | `InMemoryStorage` | `FsStore` | 采纳 |
|---|---|---|---|
| `materialize` 一个 metadata-only 记录 | `Ok(())`（"没内容可校验"） | `Err(IntegrityViolation)` | 拒绝（`§6.3`：不得静默容忍） |
| `put` 时调用方声明的 `content_sha256` 与载荷不符 | 静默用实际值覆盖声明 | `Err(IntegrityViolation)` | 拒绝（调用方不能指定一个假锚点） |

这两条都不是新代码引入的，是**过去各测各的**才一直没被发现：`storage_backend_swap.rs` 只证明了
"中心线能换后端跑通"，没有约束后端的错误语义。`object_contract.rs` 补的就是这一层，并且它现在
会抓到任何一侧单独改行为。

### 4.47 超限读把存储内部路径泄进错误消息（已修）

- **Observed**：`FsStore::read_object` 最初直接把端口的 `CapacityExceeded` 冒泡出去，消息是
  `file exceeds byte cap: var/caly/objects/sha256/15/93/304496…`。这条文本会经过 façade 到客户端，
  而 `RFC-0010 §4.1` 正是把"进程名/路径"列为需谨慎展示的准 secret；顺带它的措辞与内存后端完全不同，
  跨后端不可比对。
- **Disposition**：读之前先 `stat_size`，在 store 层给出与内存后端**逐字同构**的消息
  （`object <digest> is <size> bytes and the caller allowed <max>`）。契约测试要求两边都同时报出
  实际大小与上限，因此这条既治泄漏也治漂移。

### 4.48 导出读回必须按对象类别收窄：否则诊断查询会变成 secret reader（已实现并有断言）

- **Why**：CAS 里除了 bundle 还有 `CompiledArtifact` 与 `RawSource` 对象 —— 那是 core 真正要跑的配置，
  **按设计不脱敏**（节点密码、订阅 token 就在里面）。如果 `ReadSupportBundle` 接受"任意 digest"，
  就等于开了一个"给我摘要我就把原文给你"的接口，`RFC-0010 §12.2/§12.3` 的"脱敏导出"会被自己的
  读接口推翻。
- **Disposition**：`DaemonApp::read_support_bundle` 在**碰任何字节之前**检查
  `meta.kind == ObjectKind::SupportBundle`；拒绝时消息只说"它是 `CompiledArtifact`"，
  绝不回显内容，并带 remediation 说明为什么收窄
  （`a_digest_that_is_not_a_bundle_is_refused_before_any_bytes_are_read`）。
  同一个测试还钉住"错误文本里没有 payload"。
- **另一条设计约束**：`max_bytes` 只截断**响应**，不截断**校验**。若让 store 直接按 `max_bytes` 读，
  调用方就能用"我只要前 120 字节"绕开完整性检查 —— 所以 daemon 先按自身上限读全并校验，再截；
  `a_truncated_read_says_so_and_stays_a_prefix` 断言截断视图的 `content_sha256` 仍是**整包**的锚点。

### 4.49 文档门禁自己的列数算错了：每一行都被少算一列（已修，并加了语义测试）

第十轮给 `docs/ONBOARDING_NOTES.md` 加处置表行时，门禁报 `row has 1 column(s), header has 2`。
查下去发现**报错的行列数与我看到的都对不上**：`table_cells` 在收尾处对 `| a | b |` 这种行会把最后
一个真实单元格 `pop` 掉（因为行尾的 `|` 之后 remainder 为空），于是**每一行都被少算一列**。
表格越规整，错得越隐蔽 —— 所有行同时少 1，比对"看起来"仍然成立；只有当某行**结尾形态与其他行不同**
（例如我新加的那行少了一个单元格）才偶然暴露。

修法是取消那个 `else { cells.pop() }`，并给"边界竖线是分隔符不是单元格"这一条**单独加测试**：

```text
column_counting_treats_the_edge_pipes_as_delimiters
  | a | b | c |      -> 3
  | a |               -> 1
  | `x | y` | b |     -> 2   （行内代码里的竖线不算）
  | a \| b | c |      -> 2   （转义竖线不算）
  not a row          -> 不是表格行
```

记这一条是因为它和 `§4.44`（clippy 读数漏计）属于同一类错误：**门禁的计量函数本身没被测过**。
一个只检查别人、不检查自己的工具，出错时的表现是"别人被冤枉"，而不是"它自己变红"。

### 4.50 job follow 只有计数器，没有行；本地路径连"读流"的入口都没有（已补）

- **Observed**：`JobFollowView` 交出 `log_count` / `warning_count` / `last_stage` / `event_count`，
  `JobFollowProjection.window` 里**明明有全部 `JobEvent`**，却没有任何 façade 方法把它交给调用方。
  流式路径 (`FollowJobStream`) 在远端能用 `pull_stream` 拉；`LocalFacade` 只返回一个
  `WatchOpened{stream_id}` —— 本地调用方拿到一个**没有泵可开的句柄**，等于死路。
  `docs/IPC_JOB_FOLLOW_MODEL.md` 通篇讲的是"如何 follow"，没人注意到"事件内容"这条读路径只在
  *有 transport 的那一侧* 存在。
- **Why it mattered now**：第九轮的写侧 parity 只能比计数器。两个路径各自"14 条日志、8 条告警"
  完全可以一条改了名、一条丢了 `snapshot.committed` —— 比对全绿。内容才是能让断言失败的东西。
- **Disposition**：新增 Query `DiagnosticsOp::ReadJobEvents { request: JobFollowRequest }` →
  `JobEventsView { state, events, next_event_index, retained_from_event_index, reset_required }`，
  两条 façade 都有；渲染复用 `caly_engine::bundle::render_job_event`（原来是 `pub(crate)`，
  现在公开），**一个事件在本仓只有一种写法**。
  刻意做成 Query 而不是"给本地也加个流"：要回答的问题是"这个 job 已经产生了哪些行"，
  那是快照读取，不是订阅（`ADR-027` 的三类语义各归其位）。

### 4.51 有损包装从"限制在 2 处"变成"必须为 0 处"（已修）

第九轮把 daemon 错误压成 String 的问题修掉后，还剩两个 stream 打开点走
`with_client`（当时给它们的理由是"daemon 那侧还没有类型化拒绝可丢"）。本轮补 `ReadJobEvents` 时
必须给 `runtime.watch` / `follow_job_stream` 加 typed 变体，顺手把这两个点也换掉，
于是 `remote_facade.rs` 里 `with_client` 整个函数都不需要存在了。

对应测试也从"数到 2 就放行"改成**断言 0**：

```text
no_facade_path_flattens_a_daemon_error
  - `with_client(&client` 出现次数 == 0
  - `fn with_client<` 不得存在
  - 三个路径必须点名 typed 包装：open_runtime_stream_checked /
    open_job_follow_stream_checked / read_job_events
```

计数的棘轮会安静地接受它自己的上限；这里的上限本该是 0。

### 4.52 `retention` 的 reset 分支在生产尺寸下不可达（已用单元测试钉住）

`slice_job_events` 的 `reset_required` 只在"游标比保留窗口起点还旧"时置位，而窗口默认 128 条。
一条真实 apply job 大约 33 行，所以**任何端到端测试都碰不到这个分支** ——
`ADR-019` 把 reset 列为 first-class，它却只在单元测试里存在。本轮在 `job_follow.rs` 加了 3 条
单元测试（游标过旧→reset 且空列表；游标在窗口内→从 `from+1` 续上；游标在末尾→空但**不是** reset），
并且其中两条立刻抓到了"把 `from_event_index` 当包含语义"的一次误改（off-by-one）。

### 4.53 我的验证方式出了错：被过滤掉的编译失败差点被我读成"通过"（记为流程教训）

写 `job_follow` 单元测试时我漏了 `JobState` 的 import，于是
`cargo test -p caly-engine --lib 2>&1 | grep -E 'test result|FAILED'` **一行都没输出**
（编译错误既不匹配 `test result` 也不匹配 `FAILED`）。我当时把它读成了"跑了，没结果可报"，
并在草稿里写下"engine 单元测试通过"。实际上那个测试二进制连续几步都没编译成功。
教训：**验证用的过滤器必须能让失败可见**；本轮之后所有验证一律看 `tail` 原文或检查退出码，
并且这一条本身就成了"`docs/` 说做过 ≠ 做过"在方法论层面的镜像。

### 4.54 `ReadJobEvents` 一次返回整个窗口，而"从哪里续读"的算术存在两份（已修）

**现象**：第十一轮引入的这条 Query 没有任何响应上限：窗口有多大就返回多大。同时
`slice_job_events` 内部算了一次 `start = max(from + 1, retained_from)`，而
`crates/caly-daemon/src/watch_bridge.rs` 为了得到同一个数又算了一遍
（`window.retained_from_index.max(from_event_index.map(|i| i + 1).unwrap_or(0))`）—— 但窗口本身
并没有把起点交出来。

**复现**（改动前）：

```bash
grep -n "retained_from_index" crates/caly-daemon/src/watch_bridge.rs   # 消费端自己重算
grep -n "pub struct JobEventWindow" -A 6 crates/caly-engine/src/job_follow.rs   # 没有起点字段
```

**影响**：两条都不是"风格问题"。

- `RFC-0002 §9` 把"日志"列入**必须**分页或流式的大集合，`§11.4` 又规定大对象 MUST NOT 以内嵌超大
  IPC 帧返回；保留窗口只约束**条数**（128 条），单行长度无人管，所以"有界"当时只是巧合成立。
- 同一份算术写在两处，意味着改一处就能让**流帧的 `seq`** 与**分页读回的游标**指向不同的行 ——
  而这两者正是本轮要保证一致的东西。

**处置**：`JobEventWindow` 新增 `first_index`（切片真正的第一行），`watch_bridge` 与新的
`page_job_events` 都只读它；`crates/caly-daemon/src/paging.rs` 拥有默认页与上限并**拒绝** 0 值，
引擎只执行交给它的策略（`JobEventPagePolicy` 刻意没有 `Default`，否则"常用尺寸"就有两个出处）；
请求 DTO 拆成 `JobEventsRequest`（有界）与 `JobFollowRequest`（无界），否则 follow 一侧要背两个
它从不读取的字段 —— 那是 `§4.38` 那一类"字段没人读"的原样复现。

**一条诚实的注记**：页数上限（512）**无法**经公共路径观察到，因为保留窗口只有 128 条 ——
任何真实 job 都填不满它。因此该 clamp 由 `paging.rs` 的单元测试钉住，而不是"集成测试也证明了"。
把它写成后者就是把单元测试的覆盖面说成端到端。

### 4.55 scenario suite 有一半从来没有判定者（已补，并当场抓出 3 个真缺陷）

**现象**：`scenario_suite::run_smoke_bundle()`（聚合 ~14 个 `run_*_scenario`、发现时 123 行，
含支持包读回、
分页读回、两套 parity/contract 束）在本仓库里**只被 `caly-cli::contract_driver` 调用**，而
`caly-cli` 没有 `[[bin]]`。`crates/caly-app/tests/contract_gate.rs` 判定的是另一个函数：
`scenario::run_loopback_scenarios`，手写五行。

**复现**（改动前）：

```bash
grep -rn "run_smoke_bundle" crates --include='*.rs' | grep "tests"     # 空
grep -rn "fn run_loopback_scenarios" crates/caly-app/src/scenario.rs
```

**影响**：这个盲区至少藏住三个真实缺陷，都是加上判定者的**第一次运行**就露出来的：

1. `run_job_follow_contract_scenario(JobId(1))` 在它自己新起的 daemon 上跟一个不存在的 job。第十轮
   把"未知 job"从 `Ok(None)` 改成拒绝之后，整个 smoke bundle 直接返回 `Err("no such job: 1")`；
   没人调用它，所以没人知道。而且它原先用 `build_loopback_remote_client()` 造了**第二个** daemon，
   于是"同一个 job id 两条路径"这句前提本身不成立。
2. `runtime.watch.structured-runtime-state` 从写下那天起就是 `Failed`：部署路径里没有任何地方发出
   runtime-state patch，而 `RFC-0002 §10.3` 把 Dashboard 流描述成"snapshot + patch"。
3. `LoopbackHarness` 把 `ApiError` 折成 `error.summary` 字符串，于是**任何** scenario 都无法断言
   "到达的是哪一个错误码"——这一层与 `§4.40` 修掉的 façade 有损包装是同一件事，只是搬到了测试基座里。

**处置**：新增 `every_scenario_suite_row_passes`，并对行数设下限（100）——否则"聚三行必过项"也能
冒充套件；scenario 现在自建 job 并让两条 façade 包在**同一个** `DaemonApp` 上；`worker.rs` 在快照
提交后推 `RuntimeChanged`（`watch_bridge` 把它渲染成 `StreamPayload::RuntimeState`）；harness 的
错误文本改为 `CODE: summary`，且用 `docs/ERRORS.md` 的**稳定码**（`as_str()`）而不是 Debug 拼写
（`contract.rs::describe` / `read_through` 同步，并由 `write_parity.rs` 断言 `refused CONFLICT ` 前缀
钉住）。

### 4.56 遗留 scenario 里三行的状态是硬编码 `true`（已删）

`crates/caly-app/src/scenario.rs` 的 `run_loopback_scenarios()` 有五行，其中三行是：

```rust
suite.push("runtime-dashboard-stream", true, ..);   // 拿到了 frames，从不检查
suite.push("runtime-dashboard-ack", true, ..);      // let _ = harness.ack_stream(..)
suite.push("hello-timeout-path", true, ..);         // let _ = harness.force_hello_timeout()
```

它们**永远为绿**，而且恰好是本文件 `§4.23`（"报告有人产出、无人判定"）与第八轮"accepted→succeeded→
什么都没写"同一族的缺陷：动作发生了，结论是常量。同一 crate 里还有两个不同形状的 `ScenarioSuite`
（`passed: bool` 与 `status: ScenarioStatus`），被两个不同的测试分别判定 —— 一个是五行的假绿，
一个是 123 行的真断言，而唯一被门禁信任的是前者。

**处置**：删掉 `ScenarioCase` / `scenario::ScenarioSuite` / `run_loopback_scenarios` 与其门禁测试，
同一批场景在 `scenario_suite.rs` 里已有可失败的版本（`runtime.watch.*`、`session.hello-timeout`），
由 `every_scenario_suite_row_passes` 统一判定。`run_job_follow_query_stream_scenario(_job_id)` 同时
去掉那个"收了但不读"的参数：它让调用方以为自己在选 job，实际选的是场景自己造的 job。

### 4.57 我的流程错误：先把"接入 scenario"写进文档，再去确认有没有人判定它（记为教训）

上一轮我把事件内容"接入 scenario 三条"记为完成项，但当时 `run_job_events_scenario` 的产出**没有任何
判定者**（见 `§4.55`），也就是说那三条断言写下去时是否成立无人可查。本轮加判定者时它们才第一次运行。
另外，我第一次做失败注入时用了 `cargo test -p caly-app --test write_parity --test contract_gate`，
只读到 `contract_gate` 的红名单，就以为"路径专属的分页不会被任何测试抓到"——`cargo test` 是
**fail-fast** 的：`write_parity` 根本没跑到。加 `--no-fail-fast` 重跑之后，`write_parity` 里红了 3 条
（`event_content_is_compared_not_merely_counted`、`every_write_case_matches_across_the_two_paths`、
`walking_the_window_in_pages_agrees_across_the_two_paths`），scenario 判定者另外红 1 行。

两条教训与 `§4.53` 同源，都记在这里：

- "把 X 接进 Y"只有在 Y 会被判定时才是一句可核对的话；接进去之后必须**先看它红过一次**。
- 用于验证的管道（过滤、截断、fail-fast）必须让失败可见；否则空输出与"通过"无法区分。

### 4.58 队列满时的拒绝会推进 revision：一个"没发生"的请求改了别人的 CAS 前提（已修）

**现象**：`processor::submit_command` 先 `next_job_id()` 再 `bump_generation()`，然后才 `enqueue`，
而容量判断在 `enqueue` 里面。于是被拒的命令已经改过状态了。

**复现**：灌到上限再拒一次，看 revision 有没有动（本轮之前它会动）。

```bash
grep -n "next_job_id\|bump_generation\|has_capacity" crates/caly-engine/src/processor.rs
```

顺序即结论：**改前** `next_job_id()` 与 `bump_generation()` 排在最前，容量判断藏在 `enqueue` 的返回值里；
**改后** `has_capacity` 先出现。今天跑这条 grep 看到的是修好的顺序。

两条断言把这件事钉住：`processor::tests::a_refusal_for_a_full_queue_advances_nothing…`（引擎内）与
`overload.rs::a_refusal_does_not_turn_a_valid_cas_expectation_into_a_conflict`（走完整 daemon 路径）。

**影响**：`generation` 就是 `expected_revision` 比的那个值（`RFC-0002 §6.2`），也是 daemon 对外发布的
`state_revision`。所以"引擎忙"会**污染别的客户端**合法的 CAS 预期：拒一次，下一个持旧 revision 的
调用者收到 `CONFLICT`——一个什么都没改的操作，把别人的前置条件改坏了。次要的一条：job id 也被消耗掉，
两条本来应当一致的 daemon 的 id 序列会分叉。`OVERLOAD_AND_RETRY_MODEL §3.1` 写的"不产生 apply side
effect"因此不是措辞问题。

**处置**：判断容量在任何改写之前（`CommandQueue::has_capacity()`），拒绝走独立的
`rejected_for_full_queue`；`enqueue` 的 `RejectedFull` 分支保留为显式内部错误（同一 `&mut` 借用下不可能
发生，但发生了也不能答"是"或"否"）。三条测试分别钉住：revision 不动、job id 不消耗、拒完之后的
`expected_revision` 仍然是 `UNAVAILABLE`（容量）而不是 `CONFLICT`（CAS）。另有一条差分测试
（`refusals_are_invisible_in_the_revision_history_of_the_work_that_did_run`）：同样灌满、只拒 vs 只 drain，
两条 daemon 之后接受的 `state_revision` 与 `job_id` 必须逐项相等。

### 4.59 overload 有两个映射器，接在线上的是丢信息的那个（已合成一个）

**现象**：`OverloadReport::to_api_error` 会带上 `remediation`（由 `RetryHint` 推），但**没有任何生产者调用它**
——改动前 `grep -rn "to_api_error" crates --include='*.rs'` 只有一行，就是它的定义本身（今天这条 grep 会
多命中 daemon 的转发与单元测试，那是本轮修完的结果）；daemon 的 `error_map::map_overload_report`
自己另建一个 `ApiError`，只保留 code / category / retryable / summary —— 类别、hint、队列深度、上限
全部丢掉。`OVERLOAD_AND_RETRY_MODEL §8` 把"只返回一条 `Unavailable`，不给任何细分线索"列为禁止项，
而 §9 直接给出了 `error=queue_full / retry_hint=RetryLater / remediation=…` 这个期望形状。

**复现**：`grep -n "map_overload_report" -A 14 crates/caly-daemon/src/error_map.rs`（改前）——没有
`with_detail` / `with_remediation` / `with_diagnostic`。

**影响**：CLI/TUI 按文档要求该能回答"能不能重试、怎么重试"，但它拿到的文本里没有任何可分类的东西；
同一个 `§7` 要求的两个出口（给调用者的错误、给诊断的记录）一个都没有：既没有细节，也没有留存记录。

**处置**：`to_api_error` 成为唯一映射，daemon 的 `map_overload_report` 只负责转发；`detail` 写
`error=<class> retry_hint=<Hint> queue_len=… queue_cap=… at_generation=…`，`diagnostics[]` 里放一条
`code=<class>`，`category` 由类别决定（`StorageBusy` → `Io`，其余 `Internal`）。`RetryHint::remediation()`
放在 hint 旁边而不是 daemon 里，免得两处文案各写一份。稳定码在**报告文本**里也只有一处口径：harness
与 `read_through` 都用 `as_str()`（`§4.55` 第三条同源）。

### 4.60 我的失败注入脚本自己就是错的：同一文件多次编辑会毁掉快照（记为流程教训）

第一次批量注入时，一个 mutation 对 `processor.rs` 做了三处编辑，而脚本按"文件名→原文"存快照：第二次编辑
保存的已经是**第一次改坏后的内容**，于是还原只回到半坏状态；后面三个 mutation 因此跑在同一棵坏树上，
红名单完全相同。如果我只看红名单，会得出"这些断言互相耦合"的结论——真相是我的还原没还回去。

发现它靠的是**看原文尾部**：还原之后的编译输出里出现 `warning: function
rejected_for_full_queue is never used`——这在修好的代码里不可能成立。

处置：注入脚本改成「一次一个 mutation、一个 mutation 只碰一个文件」，并且每次还原后**再跑一遍测试确认
全绿**（`/tmp/falsify13.py` 现在会打印 `restored : red=[]`）。这条与 `§4.53`/`§4.57` 同族，但对象是我自己的
工具：验证装置也要能被证伪，否则它给出的是噪音而不是证据。

### 4.61 本地 façade 的 `request_id` 恒为 0，于是所有本地命令共用一个 `Command.id`（已修）

**现象**：`crates/caly-daemon/src/local_facade.rs` 的 envelope 构造函数（当时叫 `admin_request`）写死
`request_id: RequestId(0)`，而 `request_map` 用 `CommandId(format!("req-{}", envelope.request_id.0))` 派生
命令 id。远端路径的 request id 来自 `ClientSession::next_request_id()`，本地路径则是常量。

**复现**（改动前）：

```bash
grep -n "request_id: RequestId(0)" crates/caly-daemon/src/local_facade.rs
grep -n 'CommandId(format!' crates/caly-daemon/src/request_map.rs
```

**影响**：三条，没有一条是装饰性的。

1. 引擎事件里的 `Event.command_id` 对**所有**本地命令相同 ⇒ "这条事件属于哪个命令"在本地路径上无法回答；
   `RFC-0002 §6` 把 request id 列为必须贯穿的字段，本地等于没贯穿。
2. `ResponseEnvelope.request_id` 恒 0，两个并发本地调用无法把响应配回请求。
3. 它挡住了一种"看起来更宽松"的幂等实现：缺 key 时从 request id 派生 key（见 `§4.62`）。

**处置**：`DaemonRuntimeState::next_request_id` + `allocate_request_id()`（单调、无时钟、无随机），
`local_request` 每次调用取一个。判定在 `local_calls_get_their_own_request_identity`：三次本地写必须产生
三个 job，事件日志里的 `command_id` 两两不同，且没有一个等于 `req-0`。

### 4.62 我想用更宽松的语义实现 `Idempotency::Required`，被 parity 门禁当场否掉（记为决策证据）

定稿 `ADR-037 §2.3` 时我不愿把"没带 key 的高危写"变成非法输入，于是先实现成：缺 key 时由 daemon 派生
`req:<request_id>`。写完跑全量，`run_write_parity` 立刻红：

```text
Mismatch write.fresh-a :: local=(… revision_delta: 2 …) remote=(… revision_delta: 0 …)
Mismatch write.local.cas_current :: expected refused=false; got refused=false … advanced=false
```

机制：request id 是**每条访问路径各自计数**的（本地一个计数器、远端 session 一个计数器，都从 1 起），
而去重窗口按 `(actor, key)` 是 **daemon 全局**的。于是本地 `fresh-a` 派生出 `req:1`，远端 `fresh-a` 也派生出
`req:1` ⇒ 远端那次部署静默复用了本地的 job（revision 没动，CAS 探针随之发现"什么都没推进"）。

派生 key 的两种可能形状因此都不成立：跨路径碰撞（不安全），或每次调用唯一（等价于没有 key，`Required`
又退回装饰）。所以 `§2.3` 的"拒绝"不是保守选择，是**唯一自洽的读法**；`ADR-037 §2bis` 把这段写成了定稿
记录，而不是事后修饰。

教训与 `§4.53` / `§4.57` / `§4.60` 同族，但对象换成了设计本身：**想用宽松语义绕开一条约束时，先问它会不会
把两个身份空间当成一个** —— 这条约束存在的理由恰恰是"不同来源的 id 不可互换"。

### 4.63 空白 key 是合法输入，却是共享桶；而 `request_map` 把一切拒绝都报成 `PERMISSION`（已修）

**现象**（同一批）：

```bash
grep -n "idempotency_key: envelope" crates/caly-daemon/src/request_map.rs
grep -n "Err(RequestMapError { summary })" -A 3 crates/caly-daemon/src/app.rs
```

`RequestEnvelope.idempotency_key: Option<String>` 允许 `Some("")` 与 `Some("   ")`，而 `request_map` 原样
搬进 `Command.idempotency_key`。一个空白 key 让**所有**这样调的调用者落进同一个去重桶 —— 与 `§4.37`
那个"每类操作一个常量 key"完全同形，只是换了一件合法值的衣服。
第二条：`RequestMapError` 只有一个 `summary` 字段，`app.rs` 把它的任何失败都映射成 `PERMISSION`。当时
只有角色检查会失败，所以无害；但这是"只有一种情况"的隐含假设 —— 第二条拒绝理由一出现就会误报类别、
重试性与退出码（`docs/ERRORS.md §5.1` / `§5.6` 给这两个码的处置完全不同）。

**处置**：`resolve_idempotency_key` 对**任何**命令拒绝空白 key（`CONFIG_INVALID`，并说明"要么给一个能标识
这次逻辑操作的值，要么整个字段省略"），`Required` 缺 key 同样拒绝；`RequestMapError` 带
`kind: Permission | InvalidRequest`，`app.rs` 按 kind 选码 —— kind 是在第二个拒绝理由出现**之前**加好的。
判定在 `crates/caly-daemon/tests/idempotency_and_roles.rs`（7 条，含三道门禁的顺序：角色 → 请求形状 → 状态，
以及"同一角色在两条路径上拒绝文本逐字节相同"）。

顺带记一条被否掉的"顺手改进"：不在 façade 层替 `Required` 自动补 key。那会让本地路径补、远端路径不补，
`RFC-0002 §4.1` 要的正是同一套语义；而且它只是把 `§4.62` 的身份混淆换了个发生地点。

### 4.64 一次注入跑出一个活锁：淘汰循环的终止依赖"上限"与"受害者集合"保持一致（已加固）

**现象**：为验证"运行中的记录不能被淘汰"这条规则，我把 `evict_finished_over_window` 的受害者过滤去掉
（让运行中的记录也成为候选人）。预期是两条断言变红，实际是**测试挂死**：

```text
test idempotency::tests::a_running_record_is_never_the_eviction_victim has been running for over 60 seconds
```

**机制**：`while` 循环的退出条件是 `over == 0`，而 `over` 只数**已完成**记录；受害者集合一旦被放宽到
包含运行中的记录，删掉一条并**不会**让 `over` 变小 ⇒ 循环永不退出。代码今天是对的（两个集合由同一个
过滤条件定义），但这份正确性没有任何东西守着：把"数已完成条数"和"挑受害者"分开改一处，就会从
"红一条测试"升级成"整个套件挂住"。

**处置**：淘汰循环改为按条目数限界（一趟扫完候选人，最多 `entries.len()` 轮）。正常路径行为不变，
坏路径的失败形态从活锁变成 `len()` 断言失配。加固之后重跑同一个注入，结果就是两条红测试而不是挂死。

**同一条记录也要写给我自己**：第一次跑这个注入脚本时它在超时里被杀掉，`restore` 没执行，坏改动留在了
树里 —— 症状是"一个我没碰过的断言变红 + 一条测试挂死"。所以注入装置现在遵守三条：一次只改一个文件、
`try/finally` 还原、启动时先扫一遍上一次遗留的备份。**能被中断的验证工具等于没有验证**，这条与
`§4.53` / `§4.57` / `§4.60` 是同一族教训的第四次出现。

### 4.65 门禁自己有两处毛病：clippy 跑的目录与注释不符，而判定是从 shell 变量里算出来的（已修）

**现象一（注释与代码不一致）**：`scripts/check.sh` 的注释写着"build 与 clippy 都在一次性空目录里跑"，
但代码是 `export CARGO_TARGET_DIR="$GATE_DIR"` → 测试段 `unset CARGO_TARGET_DIR` → clippy 段**再没有设回去**。
于是第十轮为"缓存重放导致漏计"加的"两遍取最大值"其实一直在给一个本不该发生的现象打补丁。

**复现**（改前）：

```bash
grep -n 'CARGO_TARGET_DIR' scripts/check.sh      # export → unset，clippy 段没有 export
```

**现象二（判定来自被截断的字符串）**：三个段落都用 `out="$(cargo … 2>&1)"` 再从变量里 grep。同一棵不变的树上，
一次报 `no test results parsed`（而它自己 `tail` 出来的日志里明明有 `test result:` 行），一次报
`clippy did not run`；两次的 cargo 退出码都是 0。改成"写文件 + 记退出码 + 解析不到就重试一次并说出来 +
失败信息带日志路径"之后，连跑 5 次门禁全部一致（313 / 32 / 1774）。

**处置**：每步一个明确的 target dir（clippy 第二遍刻意复用第一遍的目录 —— 冷/热对照才是要测的东西，
第二个冷目录只是多付一次全量编译）；日志落在 `target/gate-logs/`（放 `GATE_ROOT` 里会被 `trap` 删掉，
"告诉你看日志"却日志已不存在，等于没告诉）；失败信息带上状态码与日志行数，并打印首 10 行 + 末 20 行。
`unset CARGO_TARGET_DIR` 用 `env -u` 在单条命令上表达，不再污染后续段落。

**加固之后反过来验一次门禁本身**：把 `local_role` 默认从 `Operator` 改成 `Viewer`（真会让本轮那批断言失配），
门禁必须红 —— 结果 `FAIL test failures present`，并点名 `every_scenario_suite_row_passes`；改回后全绿。
一个只会变绿的门禁不如没有，这条与 `§4.23`（判定者缺席）是同一个问题的另一端：**判定者自己也要被判定**。

**成因后来查明了，而且比"cargo 不稳"难看**：是我自己那行判定
`printf '%s\n' "$out" | grep -qE '^test result'`。脚本开着 `set -o pipefail`，`grep -q` 命中第一条就退出，
`printf` 随后被 `SIGPIPE` 打死（141），`pipefail` 把 141 提成整条管道的状态，于是 `if !` 把一次
**成功**的运行读成失败。日志里有 737 行、有 70 条 `test result:`、cargo 退出码是 0 —— 三件事同时成立，
只有这一种解释。它天生间歇：能不能撞上取决于 `printf` 有没有在 `grep` 关门之前写完，所以"再跑一次就好"
完全正常，而这正是不该留在门禁里的性质。

修法不是加 `|| true` 糊过去，而是**判定不经过管道也不经过 shell 变量**：`grep -qPATTERN 文件`。
只用于打印摘录的管道一律 `|| true`（丢一行上下文不能改变结论）。修完连跑 5 次结果完全一致
（313 / 32 / 1,774），再做一次反向验证：把 `local_role` 默认改成 `Viewer` → 门禁红并点名
`every_scenario_suite_row_passes`；改回 → 全绿。

教训：`pipefail` 与 `grep -q` 是有冲突的组合（`-q` 提前退出是它的本职，不是异常），任何"用管道把一大段
文本喂给 `grep -q` 来判定成败"的写法都是一次竞态。凡是判定，读文件；凡是摘录，允许失败。

### 4.66 一次索引拼接的补丁删掉了 4 个契约测试，而没有任何判定者发现（已加下限门禁）

**现象**：本轮给 `caly-io-std/tests/contract.rs` 插入新测试时，我用的是
`s[:start] + new_block + s[end:]` 这种**按索引切**的写法，`start` / `end` 是从别的字符串算出来的位置。
结果四个既有测试（`exclusive_lock_contract_passes`、`clock_contract_passes`、
`fault_vocabulary_contract_passes`、`write_atomic_leaves_no_temporary_debris`）被整段带走。

**为什么没被发现**：`cargo test` 全绿（少跑的几个测试不会让任何东西变红），clippy 全绿，
`§3.3` 的实测表**也全绿** —— 因为那张表是我用 `scripts/regenerate_test_census.py` 从树里重算出来的，
它如实报告了"少了四个"。也就是说，所有判定者都只检查"树与文档一致"，没有一个检查"测试数没有下降"。

**复现**（改前的判据缺口）：

```bash
grep -n "no test results parsed\|zero tests executed" scripts/check.sh   # 只有"为零才红"
```

**处置**：`scripts/check.sh` 增加 `TEST_FLOOR`：测试数低于下限直接红，并注明"下调必须在同一次改动里
给理由"。反向验证：把下限临时抬到 400 → `FAIL test count fell below the floor: 321 < floor 400`；
改回 321 → 全绿。四个测试也已恢复（顺带说：它们被误删之后，我最初的重建版本靠的是**终端里回读过的原文**，
不是凭记忆重写 —— 凭记忆重写测试是另一个坑）。

方法论上的收获：**生成式的表只保证"和树一致"，不保证"树没有变差"**。凡是"数量"类断言，要么配下限，
要么就只是快照。

### 4.67 `ADR-035` 把 RFC-0006 的约束写重了：trait 签名本来就没被冻结（已在 RFC 里澄清）

**现象**：`ADR-035 §6` 写"本 ADR 修改了 `RFC-0006` 冻结过的端口形状，所以需要维护者确认"。落地前复核
`RFC-0006 §16`，原文是：

> 本文暂不冻结具体 trait 代码签名与平台专属细节。

也就是说 RFC 冻结的是**能力边界与语义**（§8.1 还是"至少应支持"的写法），加一个方法是 ADR 层要决定的事，
不是 RFC 层要改的事。真正需要修订 RFC 的是**语义**变化 —— 例如"允许截断式列举"或"`NotFound` 与空列表可以
混用"，那才是本文的范围。

**影响**：这类"把约束写得比自己实际有的更严"的记录，代价是它会把可做的改动挂在等人批准上（本仓库已经
为此停了三轮）。反方向同样糟：把 RFC 没说的东西说成它说了。

**处置**：在 `RFC-0006 §16` 末尾加了一段澄清（谁改语义、谁加能力），并把 `§8.4` 的**语义**写成规范条文
（有序 / 可预算 / 只一层 / 空与不存在可区分 / 文件不是目录 + 错误映射表）—— 加了能力之后，让语义反过来
进 RFC，才算闭环。`ADR-035` 的 `Status` 与落地记录同批更新。

### 4.68 锚点式补丁仍然吃掉了测试里的一行 fixture：锚点只保证"打中了"，不保证"没少写"（已修）

**现象**：为了把 `manifest/snapshot.idx` 从 `crates/caly-storage/tests/schema.rs` 的 fixture 里去掉，
我用「注释 + 两行 `write`」整块作锚点，而替换文本里只写了新注释 —— 于是那行**记录文件**的
`write(&fs, "records/snapshot/a.rec", ...)` 一起被删了。所有 `assert old in s` 都通过，
因为锚点本来就"打中了"；删掉的那一行从来不是断言的对象。

发现方式不是门禁，是脚本在中途崩了（下一个锚点没匹配上），我回头读那一段才看见。如果那一步没崩，
这一行会带着一条"看起来合理"的测试继续存在，而且它未必立刻变红 —— 它只在 `has_any` 也改完之后才红。

**影响**：这是 `§4.66`（索引切片删掉 4 个测试）的**同族**缺陷，只是更隐蔽：那次是切片写错了边界，
这次是"锚点覆盖范围 > 替换文本覆盖范围"。`TEST_FLOOR` 对两者都无效，因为**测试条数没变**，
变的是一条测试内部的语句数。

**处置**：当场把那一行补回并核对了 diff。此后新增两条自用规则：
① 锚点覆盖几行，替换文本就必须显式重写这几行里要保留的每一行 —— 宁可把锚点缩小到"只包含要改的那一行"，
也不要让"保留"变成隐式；
② 打完补丁**立刻**跑受影响的那个 test target，不要攒到下一批补丁之后（本轮就是"崩在中间"导致测试
根本没机会说话）。数量型下限（`TEST_FLOOR`）之外，没有别的判定者能发现"少了一条断言"——
这本身就是本仓库反复付学费换来的结论，见 `§4.66`。

### 4.69 三条"没有变红"的证伪里，两条是我的变异无效、一条是断言太弱（已改）

本轮 9 条变异里 3 条一开始报 `NO EFFECT`。逐条追下去，三种不同的原因，都值一条：

1. **变异打偏**（M5）：我只想证明"回退点真的抄了记录"，却把 `ROLLBACK_DIRECTORIES` 的**第一个**元素
   （`meta/objects`）改坏了，而断言看的是 apply-journal 那一项。红不了不是断言弱，是我在测另一件事。
2. **变异没编译**（M6）：我把参数改名成 `_name` 却仍在函数体里用 `name`。cargo 返回非零，输出里
   没有 `test ... FAILED` 行，于是被我的判定"没有失败测试 = 没咬"吞成了"断言无效"。
   现在 harness 见到 `error[` 就单独报告「变异没编译，它什么也没证明」—— 否则一次编译错误会被误读成
   一条**关于代码**的结论，比没有结论更糟。
3. **断言太弱**（M8，唯一一条真的要改代码的）：我用"重启后能看见带外写入的记录"来证明"枚举来自目录"。
   但 `open()` 里的 `load()` 本身就是用 `list` 填缓存的 —— 于是"读缓存"与"读目录"在重启点**必然同值**，
   那条断言在任何一种实现下都绿。改成同时对**运行中的 store** 断言（缓存里没有那条记录、目录里有），
   M8 立刻变红。

教训：**"重启后正确"不等于"来自枚举"。** 凡断言"这里不再依赖缓存 / 快照 / 第二份真相"，都必须制造一个
两份真相在**运行中**分岔的窗口；否则它测的是启动路径，不是被测的那一处。同族的旧例是 `§4.57`
（写死 `true` 的行）与 `§4.62`（派生 idempotency key 的"看起来更安全"版本）。

### 4.70 同一份 ADR 里，状态行说"第 1 步已落地"、Notes 说"实现尚未开始"（已修，并给出自检动作）

**现象**：第十五轮更新 `ADR-035` 时我只改了 `Status` 行并追加了落地记录；文末 `## 6. Notes` 里那句
"§2 描述的能力今天都还不存在"（接手时写的、当时为真）没人回头看。于是同一份文件里两个段落对同一事实
各说各话，而**读到 Notes 的人会得出"能力还没落地"的结论，进而重做已经做完的事**。本轮复核把它翻了出来。

**影响**：这类漂移是文档的常态失效，而它对本仓库特别贵 —— 每一轮的输入就是文档，我自己也在这条链上
（第十五轮就是因为先读了旧结论而多绕了一步）。

**处置**：改为指向 §6bis-bis / §6bis-ter。并把一条机械动作固化下来：只要改了一个"状态"，就对**整个文件**跑
`grep -n '尚未\|还未\|未开始\|不做\|目前没有\|未落地\|仍'`，逐条判定那句话今天是否还成立。
高发处是四个：`Status` 行、`## 6. Notes`、`Consequences`、以及 `IMPLEMENTATION_STATUS.md` 的"未覆盖"清单 ——
最后一处最危险，因为它会反过来**指控已完成的代码**（本轮就把"`list` 与 mtime 没有生产调用者"降级成
"只有 mtime 没有"，否则下一个人会去撤掉一个正在被使用的端口方法）。

### 4.71 证伪 harness 用 `mv` 恢复文件，把改坏的构建产物留在了树里（已修 harness，加了两条规则）

**现象**：9 条变异全部跑完、两个源文件按 sha256 校验"与改动前一致"，我把 harness 收进 `scripts/` 之后
跑门禁 —— `a_committed_apply_leaves_readable_artifacts_on_disk` 红，报的是本轮**自己刚写的**断言：
`var/caly/manifest/snapshot.idx` 出现在 store 的文件清单里。可是磁盘上根本没有这一层（第 2 步就是删它）。

**根因**：`shutil.move(backup, path)` 是 rename，**保留备份自己的 mtime**，而备份是在"变异 → 编译"之前
复制的。于是恢复之后的源文件 mtime 比变异版本的构建产物（rlib）**更旧**，cargo 判定"产物是新的"，
不再重编 `caly-storage`；而它接着把这份**带着 M9 变异的 rlib** 链进了之后重建的每一个下游测试二进制
（引擎的测试二进制就是那时建的，`grep -c manifest/snapshot.idx` 在里面数到 1）。也就是说：
我验证了**源码字节**恢复正确，而门禁跑的是**没有恢复的构建图**。

**证据**（不是推测）：`fs_store.rs` mtime `04:25:52` < `libcaly_storage-*.rlib` `04:25:53`；
`grep -c` 在引擎测试二进制里命中 1 次；`touch crates/caly-storage/src/fs_store.rs` 之后重跑 →
全绿，同一处 grep 命中 0 次。内容自始至终没变过。

**处置**：harness 的 `finally` 改成 `shutil.move` 之后补 `os.utime(path, None)`；并且新增第二步验证 ——
恢复后不只跑被改的那个包，而是跑 `cargo test --workspace`，红就判整轮失败。本轮结束时
`python3 scripts/falsify_round16.py` 的输出是 `all mutations bit: True` +
`post-restore caly-storage: green` + `post-restore workspace: green` + 两个 `digest ok`。

**可复用的规则**（补进 `§4.60` / `§4.64` 那两条）：
① 恢复必须让 mtime 变新（写内容、或 rename 后 `utime`），否则你恢复的是字节、不是构建；
② "恢复后验证"的范围是**整个工作区**，不是被改的那个 crate —— 变异污染的是下游链接，只跑本包看不见；
③ 门禁若在源码不变的情况下变红，先怀疑产物（`target/`）而不是怀疑源码：比对 mtime 与 `grep -c`
到二进制里的字面量，比读代码快且能给出结论。

### 4.72 `CasWriteIntent::stored_at_unix_ms` 是一个可以被谎报的输入，而它守着"不许删"的闸门（已修）

**现象**：`ADR-035 §1` 说的"grace period 依赖调用方守纪律"，实际比"依赖纪律"更糟：
`FsStore::put` 把 `intent.stored_at_unix_ms` **原样写进记录并原样报告**，于是任何调用方都能用
一个 1970 年的时间戳，让一个刚写完的对象在 GC 眼里"早就过了宽限期"。而此刻它可能还没有任何
root 引用它（snapshot / journal 是之后才写的）—— 也就是说：**grace period 唯一保护的正是这个窗口，
而窗口里的对象是否安全，取决于写它的人填了什么。**

**怎么发现的**：不是读代码看出来的，是写第 3 步的测试时 —— 我需要一个"记录里时间很旧"的对象来测
兜底路径，于是随手填了 `stored_at_unix_ms: 0`，然后按 `§2.4`（端口覆盖声明）写断言，
先跑 `plan_object_gc` 的反向情形，发现"填 0 就够了"。也就是说这条缺陷一直躺在设计里，
是**测试要构造反例**才把它照出来的。

**处置**：`FsStore::dated`（唯一的定年处），规则 `max(端口 mtime, 记录声明)`，两边都缺才保守。
选 `max` 而不是 ADR 字面的"端口覆盖"，是因为两个来源会朝不同方向说谎：声明可以被填旧，mtime 会因为
备份恢复 / 时钟回跳而偏旧；这个字段唯一会丢数据的错法是"看起来更旧"。`a_claim_newer_than_the_port_
is_kept_and_a_missing_one_is_filled_in` 钉住方向，证伪里把实现改回"端口直接覆盖"确实会红（M2）。

**可复用的判断**：凡是"闸门类"字段（决定要不要删、要不要放行），**不要接受调用方传入的时间、
大小或计数**而不与观测比对。本仓库同族的正面例子是 `content_sha256`：调用方可以声明锚点，但存储层
**自己重算**，声明不符就拒（`object_contract.rs` 有专门一条测这个）。同一个模式当时就该套到时间戳上。

### 4.73 又一个"整条链只有测试调用"的模块：`caly-storage::gc`（第十八、二十轮修完，见 `ADR-038 §1/§2`）

**现象**：本轮要给 GC 接年龄时顺手查调用者：`grep -rn 'run_object_gc' crates/` 在
`crates/caly-storage/tests/gc.rs` 之外**零命中**。也就是说 `RFC-0007 §13` 的"先标记再清扫"、
`§15.6` 的验收、资格门禁（idle + 无 pending deployment）、单轮上限，全部是**能力**而非**行为**：
真跑起来时没有任何东西会去删。

**影响**：这不是"功能没做全"，是**磁盘只增不减**在生产上不可见，直到某天塞满。而且它会误导后续判断：
文档里 `§13` 记为已实现（确实实现了），未覆盖清单里也没写（因为写的都是"GC 的 grace period 依赖注入
时间"这类**细节**缺口，缺口列表里没有"整个入口不存在"这一条 —— 列表在细节上诚实、在结构上漏项）。

**处置**：本轮只把它记下来，并同时把 `IMPLEMENTATION_STATUS` 未覆盖清单的第一条改成
"GC 整条链没有生产调用者"（原先那条只讲了时间来源）。接线本身需要一次独立决策：GC 是命令还是任务？
按 `ADR-018`"写操作即任务"，它应该是 job（要进度、要可取消、要计入 overload 出口），
还要 `§13.2` 的 idle 判定 —— 那是第 18 轮的候选，不该塞进"给年龄换来源"这一轮。

### 4.74 对象年龄来自端口、`now` 来自注入时钟：两条时间线从未被对齐过（第十九轮修好接缝，检出规则保留）

**现象**：`ADR-035` 第 3 步把对象年龄换成端口证据（真盘 = 文件 mtime）之后，GC 计划的另一侧
`GcPolicy::now_unix_ms` 仍取 `ExecutionPolicy.clock_start_unix_ms`（默认 0，确定性仿真用同一基数）。
于是在真实目录上 `now=0` 而年龄 ≈ 1.78e12 —— **每个对象都"诞生在未来"**，`now - age < grace` 恒成立，
所有对象被 grace 保护，计划永远"没有可回收的东西"。第十七轮的 6 条证伪变异一条都抓不到它：
仿真盘的 mtime 与策略时钟同源，这个错只在真盘上出现，而那正是本轮写消费者时才第一次走到的路径。

**危险方向是反的**：如果注入时钟比真实时间超前（测试里设个大数、或将来 `ADR-036` 把 deadline 接到
一个自定的单调基准上），那么**真实对象会全部看起来过期**，grace period 静默失效并删除刚发布的对象。
这个方向今天不可达（没有任何生产代码改过 `clock_start_unix_ms`），但它一步之遥。

**处置**：`build_gc_plan` 检出"年龄晚于 now"即记 `clock-timeline` 缺口、清空删除列表并在 `refusal` 里
写明两条时间线不同源；单元测试与 `a_real_disk_plan_refuses_when_the_clocks_are_not_the_same_timeline`
各钉一头。根因没修（修法 = 组装根把 `Clock` 注进引擎，使 `now` 与 mtime 同源），记在
`ADR-038 §2` 的第 3 步 —— 真实部署上现在**必然**看到这条缺口，那是事实而不是回归。
**可复用**：任何"用 A 的读数与 B 的读数比大小"的代码，都要问一句这两个读数是否同一时钟、同一条时间线。
本仓库同类的前例是 `§4.20`（时间不许在网关外读）—— 那条规则解决了"从哪读"，没解决"两边是不是同一个源"。
> **第十九轮更新**：接缝已落地 —— `EngineHandle::storage_now()` 优先取注入的 `Clock`（由组装根决定给
> 谁：真机 `StdClock`、仿真门禁里与 `SimFs` 同一个 `SimClock`），并在报告里写明 `now_source`；
> `caly-daemon::set_storage_clock` 只做转发，类型走 `caly_engine::Clock` 这个 re-export，以免为省一行
> import 新增一条受 `ALLOWED_DEPENDENCY_EDGES` 管辖的依赖边。journal 的时间戳**故意不换**（它与 `audit`
> 的 `now` 同源，换了会让确定性回放把每个 journal 都说成陈旧）—— 这条区分写在 `ADR-038 §7` 的表里。
> 剩下的不是设计问题而是入口问题：本仓库没有 `[[bin]]`，因此真实部署还没人填这个参数；在那之前计划
> 继续带着 `clock-timeline` 拒绝，而这是**报告出来的**状态。

### 4.75 `required_role` 写在 `OperationMeta` 里，但只有命令路径执行它（已修，并加了一次结构排除）

**现象**：角色检查当时只在 `map_request_to_command` 里，`handle_request` 对 `Query` / `Stream` 直接分派。
`ProfileOp::Plan` 从第一天起声明 `Role::Operator`，**从未被执行过**；`OperationMeta` 里那个字段在读侧
纯粹是文档。我给它加 `system.gc-plan`（同样声明 `Operator`）时顺手写了"Viewer 应该被拒"的断言，
第一次跑就绿不了 —— 于是缺陷不是推测出来的，是断言逼出来的。

**影响**：读侧只要声明高于 `Viewer` 的角色就是空头承诺；反过来说，任何"这个读需要更高权限"的设计
在这套边界上都不成立。这不是风格问题：删除决策的输入如果被当成公开读，就绕开了 `RFC-0002 §7.2`。

**处置**：`require_role` 提到 `handler.rs`，对 `Query` / `Stream` 生效；命令路径**保留**自己那一次检查，
因为 `submit_request_as_command` 是公开入口（测试与将来的 CLI 会直接调它），只放在 `handle_request`
会让那条入口绕过门禁。两处调用、一份实现、一个 `api_error_for` —— 于是"同一个拒绝在两条路长得不一样"
被结构排除。两条路径各有一条测试钉住：`a_viewer_cannot_ask_for_a_deletion_plan`（读）与既有的
`an_unauthorised_role_cannot_enqueue_an_apply`（命令，证伪 M8 只让它变红，说明两处都不能省）。

### 4.76 我给 `doctor` 加了一条"每个真实部署都恒真"的 warning，被最有价值的断言挡下（已改设计）

**现象**：第一版把"GC 不能运行"升级成 warning。`durable_boot::the_doctor_reports_storage_findings_
instead_of_a_placeholder` 立刻变红 —— 它断言的是"健康的落盘 store 不产生 warning"，而这条断言的存在
理由写在它自己的注释里：曾经有一句固定占位 warning，让"有发现"和"是占位"再也分不开。

**为什么不能靠放宽那条测试解决**：查下去发现更结构性的事实 —— 凡是能让计划拒绝的 store 状态
（快照记录读不到、LKG 指针解析失败），`storage_audit` 会先把整个 doctor 请求打成 `UNAVAILABLE`。
也就是说 warning 分支要么重复审计的结论，要么**永不触发**。我第一版写的 `has_actionable_gap()` 正是后者。

**处置**：删掉那个方法（不留永不触发的分支），保留 `GcRootGap.actionable` 作为**数据**：计划一行永远是
note，拒绝原因写在这行文本里（`... refused: root set incomplete: clock-timeline …`），需要分层的是客户端；
`summary_line` 里 `actionable=N` 让分层可见。同时把"`doctor` 不为 GC 报警"的理由写进代码注释与
`ADR-038 §4` 的 Negative，而不是留给下一个人重新发现。
**可复用**：往任何"健康/不健康"的判定里加信号之前，先问它对健康系统是否恒假 —— 若恒真，它就是新的占位噪声。

### 4.77 掩码器把给调用方的 `remediation` 文字也掩了（记录，未修）

**现象**：`Idempotency::Required` 缺 key 的拒绝，其 `remediation` 以
`"pass idempotency_key: Some(..) with a value that identifies …"` 开头。经 `error_response` 的
`Redactor` 之后变成 `pass idempotency_key: ***REDACTED***) with a value …` —— `key: value` 形状命中了
"idempotency_key 是敏感键名"的规则，被掩的是**我们自己的说明文字**。实测输出：
```text
remediation: Some("pass idempotency_key: ***REDACTED***) with a value that identifies this logical operation, …")
```

**影响**：不致命（句子仍可懂），但把"照我说的做"变成"照 `***REDACTED***` 做"，正是文档里反复警告的
"掩码让诊断信息失去作用"。今天没有任何测试断言这段文字未被掩，所以它一直存在。

**为什么不顺手修**：豁免哪个字段是 `ADR-020 §3`（在边界统一掩）的范围决策 —— 要么"`detail` /
`remediation` 只允许常量，故不过掩码器"（需要一条 lint 或构造上的保证），要么"`summary` 才可能带
调用方数据"（要逐个字段证明）。两者都超出"把 GC 计划接上"这一步，留待单独一轮；本轮只把
`KEY_REMEDIATION` 提成 `concat!` 常量（避免下一次又有人为了改一个字去改六处），并在此留档。

### 4.78 连续两轮，处置表的行被粘进上一段：所有门禁全绿（已修 + 新加一条门禁）

**现象**：我给 `§6` 处置表加行时，锚点是"空行 + `### 6.4x 明确**不做**的项`"，而替换文本以 `| 6.4x | … |`
**开头**却不含那两个前导换行 —— 于是行被接到上一个段落（一条 `>` 引用）的尾巴上，两轮如此。
`grep -n '^| 6\.'` 找不到它们，`check_markdown_tables` 也找不到：它只把**以 `|` 开头**的行当表格行。
文件确实变长了，内容却不再是表。

**发现方式**：本轮写 §4.74 时想核对"上一轮的处置行在不在"，`grep '^| 6\.4'` 只数到 6.41。

**处置**：拆开粘住的行、放回表里（第十八轮的行也补上），并给 `caly_arch_test::docs` 加
`check_stray_table_rows`：一行若以 `|` 结尾、含 ≥3 个不在行内代码段里的 `|`、且不以 `|` 开头，即为
"粘住的表行"（代码围栏内不判；少于 3 个不判，因为散文里出现一个 `|` 完全正常，例如被引号包住的 shell 交替；
行内代码段里的 `|` 也不判，第二十一轮就是这么把 `§4.89` 的一句引文当成候选的）。**这条规则本身在第二十一轮
又被撕开一次，见 `§4.90`**——判据从「` | ` 分隔的个数」改成「管道符的个数」，因为真实的粘法根本没空格。
它接进 `doc_tables_and_lists_are_well_formed`，并证伪过：把 `| 6.99 | x | y |` 粘到一条引用行末尾 →
`stray-table-row: docs/ONBOARDING_NOTES.md:1499 …`，还原后全绿。
**可复用**：**"文本变长"不等于"内容生效"**；凡是靠行首形态识别的结构（表、列表、标题、`#[test]`），
锚点替换都必须把分隔用的空行**一起吃进去再吐出来** —— 我的补丁规则里之前只有"锚点必须唯一"，
现在加一条：**替换文本的首尾空白必须与锚点一致**。

### 4.79 从补丁脚本里生成 Rust 字符串时，反斜杠续行会被折成一行并留下连续空格（第二次发生，已加自检）

**现象**：两处同类。① 第十八轮把 `Idempotency` 的 remediation 提成 `KEY_REMEDIATION` 常量时，
`"...identifies "` + 换行 + 缩进 的写法在生成后变成一行、中间夹着 6 个连续空格 —— 是测试
`a_required_command_without_a_key_is_refused_before_the_engine_sees_it` 变红才看见的。② 本轮写
`clock-timeline` 的拒绝消息时同样中招（`-- the ages and` 后面一串空格），这次是**我读文件时**发现的，
断言恰好查的是另一段连续文本，所以它没红。**一个没红的形状错误，比一个红的更贵。**

**根因**：不是忘了 Rust 的续行语义，而是补丁通道本身失真：脚本里的字符串被压平之后，反斜杠没了、
缩进留下了。也就是说**「用脚本写代码」这条通道会系统性地破坏多行字面量**，与我是否懂 Rust 无关。

**处置**：两处都改成单行字符串（常量用 `concat!`，消息用单行 `format!`）；并在
`the_now_source_is_reported_and_the_refusal_names_the_fix` 里加一条渲染自检
`assert!(!detail.contains("  "))` —— 让"最终字节"成为断言对象而不是靠我目视。规则补一条：
**生成 Rust 字符串字面量时不使用行内续行**，长文本一律 `concat!` 或多参数 `format!`。这与 `§4.68`
（锚点吃行）、`§4.78`（表格行粘段）同族：补丁的失败模式不是"没打上"，而是"打上了但形状错了"，
只有对渲染结果下断言才拦得住。
> **第二十轮的复现**：同一族缺陷第三次出现——我给处置表加行时，锚点是"空行 + `### 6.4x 明确**不做**的项`"，
> 而那个标题在表**之后**的另一个小节里，于是新行被贴到段落尾巴上、并且脱离表格；`check_stray_table_rows`
> 与 `check_markdown_tables` 各报一次（后者报 `table-shape: a table needs a |---| separator row`，因为
> 脱离的行自己成了"新表的第一行"）。规则改成：**处置表的新行必须插在最后一行 `^| 6\.\d+ \|` 之后**，
> 而不是插在某个标题之前 —— 表的成员资格由相邻性决定，不由内容决定。

### 4.80 时间线检出只认一个方向；我把测试写反了一次（已改测试，方向性写进 ADR）

**现象**：为了测"没注入时钟就会拒绝"，我先写对象、再推进仿真时钟。断言没红 —— 推进时钟不会改动
已经盖好的日期：对象年龄恰好**等于**策略基准，`age > now` 不成立，于是计划只是"仍在 grace 内、
无事可删"，而不是"检出跨时间线"。两种状态在 `collect` 上长得一模一样（都是空），区别全在 `gaps`
与 `skipped_for_grace` 里。

**为什么值得记**：`clock-timeline` 是**单向**探测器（只抓"年龄来自未来"）。反方向 —— `now` 超前、
真实对象全部看起来过期 —— 从 store 内部不可判定，而那才是删除风险所在。如果我把它理解成
"两边不同源总能查出"，就会写出一份看似严格、实则只在半个区间生效的门禁，并据此放心地把第 2 步
（删除）接上。真实关系是：**探测器负责报告它看得见的一半，另一半靠顺序保证** —— 同源时钟没接好之前
不许落地删除。这句写进了 `ADR-038 §7`。测试因此改成"先推进时钟、再写对象"，并额外断言注入之后
"仍然在 grace 内、时间走完才变可回收"，把三种状态区分开而不是只看列表是否为空。

### 4.81 「daemon 拥有当前快照」这句我自己写错了，而且写进了 ADR 与代码注释（已修）

**现象**：第十八轮把 GC 计划接成 `storage_gc_plan(bounds, active_snapshot_id)` 时，我在 `ADR-038 §6` 和
方法文档里都写了理由：「daemon 拥有这个事实，引擎没有」。本轮要把收集变成**任务**（任务在引擎里执行，
拿不到 daemon 的参数）时，那句话必须被验证 —— 一验证就碎了：
`grep -n 'active_snapshot = ' crates/caly-daemon/src/app.rs` 只有两处赋值，一处来自
`latest_last_known_good_snapshot()`，一处来自 `report.latest_last_known_good`。**两处都是从 store 推出来的**，
daemon 并不拥有它，它只是镜像。

**为什么这个错误值得单独一条**：它当时是"合理"的 —— 参数确实由 daemon 传，看起来就像它知道。危险在于
它把一份**必须同步的副本**留在了更高的层：任何新的提交路径只要忘了更新那份镜像，root 集就安静地少一类
保护，而少一类保护在这套设计里等于可以删掉正在使用的对象。真相应该长在**产生它的那一刻**：
现在 `active_snapshot_id` 是 `EngineState` 的字段，由 `finalize_apply_persistence` 成功之后写入，
恢复路径在同步镜像时一并告知；计划不再收参数。

**可复用**：每次用"某某层拥有这个事实"为参数传递辩护时，去 grep 那个"所有者"到底有几分是自己算出来的。
镜像不是所有权。（同族的旧账：`§4.22` 用"再读一次同一路径"当校验。）

### 4.82 检查跑进被检查的东西里：周期一开始把自己算作"在飞工作"，于是每次都拒绝自己（已修）

**现象**：`StorageGc` 变成任务之后，第一个端到端测试就红了 —— `objects_total` 纹丝不动。原因不是拒绝逻辑
写错，而是它**太对了**：`has_work_in_flight` 看见一个 `Running` 的 job（就是这次收集自己），于是判"引擎不
空闲"→ 记 `running-job-artifacts` 缺口 → 清空删除列表 → 拒绝。

**修法与它的边界**：`work_in_flight_except(state, excluding_job)`，只用于**执行期**；入队前那道门**不继承**
豁免（否则两个排队中的收集会互相放行，各自以为对方是别人）。这条边界写在函数文档里，因为一眼看去
"两处都调同一个函数"才像是对的。

**可复用**：把一个守卫从"外部调用者"移进"被守卫的流程内部"时，必须重问一遍：这个谓词数的是谁？
同一份状态在被检查者自己手里读出来时，常常包含它自己。测试上的表现是"断言恒真或恒假"，所以本轮
`a_busy_engine_refuses_the_cycle_and_changes_nothing` 与
`an_ineligible_store_state_refuses_the_cycle_at_both_ends` 同时钉住**入队前拒绝**与**执行期拒绝**两侧
—— 只测一侧的话，另一侧的反向错误（入队门也豁免自己）不会响。

### 4.83 复用同一个拒绝类别 = 复用它的说明文字与计数器（差点让 `doctor` 报出一个假原因）

**现象**：把 `max_deletions: 0` 这类越界也走 `RequestMapErrorKind::InvalidRequest` 是最省事的写法 —— 同码
`CONFIG_INVALID`，映射表一行都不用改。差点就那样交了，因为测试只看得到"被拒了"。停下来看调用方会读到什么，
才发现两处会撒谎：① `api_error_for` 对 `ConfigInvalid` 一律附 `KEY_REMEDIATION`，于是越界的调用方被告知
"请带上 idempotency_key"，照做之后会**因为同一个理由再次被拒**；② `doctor` 的
`idempotency_key_refusals` 计数按 `code == ConfigInvalid` 累加，于是有人多问了几次"能不能多删点"就会显示成
"一批调用方在忘记带 key"。

**处置**：加第三个 kind（`InvalidBounds`），共用 `CONFIG_INVALID` 但各配自己的 remediation；计数器改为
按 kind 判，只数 key 拒绝。两个 remediation 常量各一处定义，且计划的查询路径与收集的命令路径**共用**
`BOUNDS_REMEDIATION` —— 两个操作对同一对数字许诺同一个上限，这件事得由一个字符串保证。

**可复用**：新增拒绝理由时，顺着旧 kind 把所有**消费者**列一遍（错误文本、remediation、计数器、
`doctor` 行、退出码映射），而不是只把 `match` 补全到能编译。本仓库的教训反复在同一处：能编译 ≠ 不说谎。

> **§4.79 的补记（第二十轮）**：同一轮里我又踩了它两次 —— 一次是补丁脚本里的 ASCII 双引号截断单行
> Python 字符串，一次是把 `\` 续行写进生成的字符串。规则再加一条：**脚本里的字符串参数一律用三引号，
> 生成的 Rust 字符串一律单行或 `concat!`**；并且写完立刻 `python3 -c "import ast; ast.parse(open(f).read())"`
> 与编译各跑一次，让形状错误停在工具里而不是停在树里。

### 4.84 证伪工具自己撒了一次谎：把「测试红了」当成「没能编译」，于是九个变异里前九个读数全错

**现象**：harness 第一轮报 M6 `NO EFFECT`。我第一反应是"断言不够强"，正准备去加断言 —— 真因是
`build_failed` 的判定：为了区分"编译失败"与"测试失败"我写了 `"\nerror:" in out`，而 `cargo test`
在一个测试目标失败时**本来就会打印** `error: test failed, to rerun pass …` 与 `error: 1 target failed:`。
于是每一次"红"都被判成"没编译"，而"没编译"按规则记作 `NO EFFECT`。修完判定后第二轮更清楚：九个变异
全部显示 `MUTATION DID NOT BUILD`，同时 `red=` 里明明列着变红的测试名 —— 两个字段互相打脸，
而我差点只信其中一个。

**同时暴露的三件真事**：M2/M6/M8/M9 一开始确实没被测住，不是工具的错，是我的断言缺了三条 ——
被拒的周期没断言"记录已写下"、`would_run` 的**资格**半边没有独立用例（root 完整但引擎忙这一状态没人测）、
越界拒绝没断言"不污染 key 计数器 / 不借用 key 的 remediation"。补齐之后它们才各自变红。

**处置**：判定收窄成只认编译器口径（`error[` 或 `could not compile`），并把这个区别写进 harness 注释；
补三条断言；本轮总数从"我以为的 11 条"改成实测 10 条。

**可复用**：**证伪工具必须自己也被证伪** —— 拿一个已知会红的变异和一个故意写到不能编译的变异各跑一遍，
看它能否把两者分开。判读器有两种失败读数，而其中一种（"没红"）恰好是最容易被误读成"我的断言很强"的那种。
这与 `§4.65`（`pipefail` + `grep -q` 竞态让门禁两次给出错误结论）是同一课：
**判定逻辑的错误比代码的错误更贵，因为它替错误背书。**

### 4.85 「计划有人看」与「删除有人按」是两件事：`§4.73` 的账分两轮才还完

**补记（第二十轮）**：`§4.73` 记的是"整条链只有测试调用"。第十八轮还了一半（计划被引擎算、被门面传、
被 `doctor` 与 `storage-gc` 段导出），第二十轮才把另一半接上：`SystemOp::CollectGarbage` →
`CommandKind::StorageGc` → 任务 → `caly_storage::gc::sweep_objects`。
值得注意的是 `run_object_gc` **仍然**只有测试调用（实测 `grep -rn 'run_object_gc' crates/`：定义 + 自己的测试）——
这不是遗漏，而是分工：那个函数的语义是"自己算一轮再删"，而引擎需要的是"算一次、报告、只删报告里那份"，
所以它改用被拆出来的 `sweep_objects`。留这条是为了避免下一个人把"某个入口没人调"当成"该入口的语义没人用"，
或者反过来为了"让它有调用者"而把两条语义混成一条。


### 4.86 有些字段只能待在会解释它的那一层：deadline 与 cancel 的落点（记 `ADR-036` 的一处偏离）

**现象**：`ADR-036 §2.2` 要求 `RequestContext` 带 `deadline: Option<Deadline>`（"绝对期限，由单调时钟
计算"）。落地时这句话在本仓库**没人能满足**：把 `deadline_ms` 换算成绝对值需要一个单调时钟，而
`clippy.toml` 只给 `caly-io-std` 开了读时钟的豁免 —— daemon、storage、engine 都没有单调时钟。

**两种坏选择**：① 在 daemon 边界算一个"绝对"值（那需要一个它并不拥有的零点）；② 给 `caly-io` 或 daemon
开同样的豁免（正是 `ADR-036 §6bis.1` 已经否掉的路：确定性仿真退化成约定）。落地形状因此是：
`Ctx` 存 `deadline_mono_ms: Option<u64>`，**由持有 `Clock` 的驱动者填写**，daemon 边界明确写 `None` 并注释
为什么；相对值 `deadline_ms` 照旧透传。这与 `§4.81` 同一课：**派生值必须住在有源的层**，否则它是一份要求
别人记得更新的副本 —— 而时钟零点错位时，"忘记更新"的两个方向都错（零点为 0 会取消一切，零点很大则从不取消）。

**同一处的另一半：`CancelToken` 不能过线。** 它是句柄不是数据，所以远端路径安装一个**惰性** token 而不是
假装转发调用方的。跨进程的"取消"在语义上就是会话断开，那条映射属于 `ADR-036` 第 2/4 步。把字段加上就
宣称"取消已贯穿"是不诚实的，所以这里点名，并让单元测试钉住"默认必须是不取消"（一个默认已取消的 token 会
让每一条入站命令在开始前就死掉）。

**代价（写清楚，不藏）**：`caly-app::remote` 里 `Some(ctx.io_budget.clone())` 这一行**没有端到端断言**。
预算当时没有任何可观察后果（记账是第 3 步），要断言就只能暴露一个内部值或为测试造一个公开 API，两者都比

**第二十四轮补记（这条账还掉了）**：第 3 步给预算装上后果之后，那条端到端断言按原本的形状写出来了 ——
`crates/caly-app/tests/budget_parity.rs` 比较两条门面上「预算花光的 `profile.apply`」的公开读数
（`JobFollowView` 的 state / failure_code / failure_summary / event_count 全等），不碰任何私有字段；
并且证伪跑过 `remote.rs` 那一行改回 `None` 的变异，确实红了（M12）。**「当时无法诚实断言」不是**
永久免检的理由：它是「等谁能观察了再补」的挂账，而挂账要写进未覆盖清单、并在能还的时候还。
"暂时没测"更贵。它记在 `IMPLEMENTATION_STATUS` 未覆盖清单里，第 3 步落地时必须连断言一起做。

### 4.87 机械 sweep 报的"成功计数"会骗人：正则漏掉了字段简写，而我一度信了自己的 tail

**现象两件，同一族**：
① 给 `RequestEnvelope` 加 `io_budget` 时，我写脚本在所有 `RequestEnvelope {` 块里找 `role:` 行、在其后插入
`io_budget: None,`，脚本报告 `updated: 21`。它漏掉的正是那些写成**字段初始化简写** `role,`（而不是
`role: role,`）的字面量：正则只认 `role:`，简写行在它眼里不存在。**漏了几处我不写在这里** —— 那个数字
本来就只有一个可信来源，就是编译器逐条列出的 `error[E0063]: missing field io_budget`；我按报错位置迭代到
零报错才收干净，验收标准是「编译器对该字段不再报错」而不是「我改了几处」。
② 同一轮里我把一个补丁脚本的输出用 `tail -12` 截断后继续干活，而那个脚本其实**在中途断言失败退出了**，
后半批补丁一条都没打上（症状是"我以为已经加好的两个测试根本不在文件里"）。

**为什么值得记**：两次都是"工具给了我一个像成功的数字"。①的教训是**批量结构改写必须以编译器为裁判**：
正则只能提候选，完成标准是 `cargo check --all-targets` 对该字段零报错，而不是改了多少处；②的教训是
**不要截断自己工具的输出** —— 每个补丁脚本都约定"每成功一处打印一行 `patched: …`"，行数与预期不符就是
信号，把它 `tail` 掉等于主动放弃一次判定（与 `§4.53`「过滤 grep 掩盖编译失败」同源，与 `§4.84`
「证伪工具也要被证伪」同族：**判定被削弱时，错误读数会被我当成证据**）。

**处置**：sweep 改成"读编译报错 → 插入 → 再编译"的循环（迭代到无报错）；本文件与 `§4.78` / `§4.79` 的
规则合并成一条习惯：**任何自动改写的验收标准都必须来自一个独立判定者（编译器 / 断言），不能来自工具自己的
统计。**

### 4.88 两条断言是证伪跑出来的（第一次全绿之后我又改了两处测试）

**现象**：M1（"先判期限再判取消"）与 M7（"挂起扫描吞掉同 label 的下一个故障"）第一轮都**没有任何测试变红**。
不是变异无效，是断言不够精确：

- M1 逃过去是因为我构造的"取消优先"用例里，期限是 `Deadline(1)` 而时钟第一次读数是 0 —— 期限**还没到**，
  所以先查谁都一样。要让顺序可测，两个条件必须**同时为真**（时钟已到点且 token 已触发）。
- M7 逃过去是因为我把用例写成"hang 与另一个 label 上的故障互不干扰"，而那从来不是有 bug 的那条路径。
  真正的区别在同 label 上：**挂起扫描不得消费别的故障**。写出来才发现我原先连"谁先回答"都没有定义 ——
  现在的定义是"hang 先被检查"，所以第一条断言只能是"队列里那个故障**还活着**"，不是"它先回答"。

**顺手的一条**：修 M7 时我先按"谁先入队谁先回答"写了断言，测试直接红 —— 那不是我实现的行为。
也就是说：**测试在告诉我设计里没写明的部分**。把这句写进注释（"设计的承诺不是顺序，是不吞噬"），
否则下一个人会照着测试去改实现。

**可复用**：证伪跑完，凡是"没红"的变异，第一嫌疑是**断言没落在被改的那条分支上**，而不是实现太健壮。
本轮 9 条里有 2 条属于这种，都是同一个原因：条件的边界（未到期 / 不同 label）。补完之后 9 条全红。

### 4.89 我为了修"粘住的表行"写的脚本，把散文里的一个代码片段当成表行搬走了（脚本已删）

**现象**：本轮第四次撞上同一处（行被贴到段落尾巴上）。因为手工修过三次，我写了
`scripts/reattach_table_rows.py`：扫描"整行里出现 `| 6.<n> |` 且该行不以 `|` 开头"，把那段搬到表格末尾。
它跑了，报告"reattached 3 row(s)"，`check_stray_table_rows` 也绿了 —— 但 §4.78 的一段散文被啃掉了：
那句话说"把 `` `| 6.99 | x | y |` `` 粘到引用行末尾"，**代码片段里的 `| 6.99 |` 正好符合它的匹配式**。
于是表里多出一行伪记录，散文少了一截，而且没有任何判定者报错（伪行是合法表格行；残缺的散文不是表行）。

**为什么"合法"的判定者抓不到它**：所有现存检查都只看**形状**（是否以 `|` 开头、分隔数、表格是否连续）。
两个破坏都是形状合法的：一行伪记录 + 一句缺了中间内容的散文。这是"语义正确但内容是垃圾"的老问题，
和 `§4.57`（写死 `true` 的行）、`§4.64`（可推断路径的测试）同一个形状。

**处置**：① 手工把散文补回、伪行删掉（已做，`doc_tables_and_lists_are_well_formed` 与 census 全绿）；
② **删掉那个脚本**——它的正确做法是"只处理整行由若干 `| … |` 片段拼接而成、且片段数 ≥2"的行，
但在只发生过 3 次、每次一行的场合，一个会啃散文的自动化比手工更贵；判定者（`check_stray_table_rows`）
保留，它才是该留的那一半。

**可复用（比前几条更一般）**：**给一次性修补写自动化之前，先问它误伤的代价。** 这次误伤的是文档内容，
而且不会被任何检查抓到 —— 如果我把脚本留下，下一次它还会在别的散文上开洞。规则：**修形自动化必须
"整行匹配才动手"，且要有人读一遍它改过的每一行**；否则宁可不自动化。同族账：`§4.65`、`§4.84`、`§4.87`
都在说"判定/工具的读数不能当验收标准"。

### 4.90 为这个失效专门写的门禁，仍然没看见失效：判据数的是「` | ` 分隔」，而粘上去的行没有空格

**现象**：`§4.89` 记的是我用脚本修表行时的破坏，修完之后我确认过「散文手工补回」，也确认过处置表
`| 6.1 |`–`| 6.51 |` 都在。本轮收尾时用 `grep -c '^| 6\.5'` 数一遍，**只数到 6.50**——`| 6.51 |` 那一行
被接到了 `§6` 末尾那条 `>` 引用的尾巴上（`…的理由。| 6.51 | … | 4.89 |`）。而 `check_stray_table_rows`
就是 `§4.78` 为了"表行被粘进上一段"这个失效专门加的门禁，它当时**全绿**。

**为什么漏**：它的判据是 `trimmed.matches(" | ").count() >= 3`。被粘的行里，第一个 `|` 直接紧贴中文句号
（没有空格），最后一个 cell 又结束在行尾（后面也没有空格），于是三个真实存在 cell 边界只数出**两个**
` | ` 串。规则的形状是对的（不以 `|` 开头 + 以 `|` 结尾 + 三个 cell），错的是**用什么去数**。

**处置**：判据改成数「不在行内代码段里的 `|` 个数」≥3（新增 `pipes_outside_code_spans`，反引号按开关处理，
与 `table_cells` 同一口径），并补一条单元测试用**真实形状**（`> prose。| 6.51 | x | y |`）而不是我上一轮
编的整齐形状（`prose | 6.42 | x | y |`）。改前先跑：新测试红（`left: 0, right: 1`）→ 证明缺口真实存在；
改后全语料只报一行，正是 `docs/ONBOARDING_NOTES.md:1826`——即"门禁变宽"与"损坏被看见"是同一次运行里
互相印证的两个读数，而不是我先修文档再补测试。

**可复用**：**为某个失效加门禁时，测试用的输入必须是那个失效的真实形状，不能是我想象中的整齐形状。**
一条只在"教科书形状"上有效的规则，等于把同一个坑再挖一遍。与 `§4.84`（证伪工具也要被证伪）、
`§4.88`（变异没咬住时先怀疑断言不精确）同族；这条是它的第三条腿——**判据的度量口径也要被证伪**。


**收尾时同一族又发生一次（记在这里，因为它证明上面那套「用哈希判定还原」是真的有用）**：证伪
`TEST_FLOOR` 时我先 `sed` 成 400 跑红（`FAIL test count fell below the floor: 384 < floor 400`），再用
`cp /tmp/check.sh.bak scripts/check.sh 2>/dev/null` 还原 —— 而那个备份**从来没被创建过**，`2>/dev/null`
把这个事实吃掉了。是紧随其后的 `sha256sum -c` 报 `FAILED` 才拦住我：文件当时还停在 400。同一个习惯问题：
**还原要按内容判定（哈希 / `diff -q`），不能按"我调用过还原命令"判定**；`§4.60`/`§4.64` 的 mtime 教训
是它的另一半 —— 只比内容不比 mtime，cargo 会继续复用被污染产物；只比 mtime 不比内容，就轮到我今天这样
差点把一份被改坏的门禁脚本留下。
### 4.91 我断言了一个我没读过的生产者：仿真故障的 `retryable` 是假的，我猜它是真的

**现象**：写"端口故障穿过执行器不变形"这条断言时，我第一反应是 `assert!(fault.retryable)` —— 因为
`Unavailable` 听起来就该可重试。它红了。真相在 `caly-io-sim` 的 `FaultSpec::into_io_fault`：它只调
`IoFault::new(kind, text)`，一个标志位都不设，所以 `retryable == false`、`transient == false`。

**修法不是把断言删掉或改成 `!retryable`**（那只是把猜测翻了个方向）。改后的测试**先问端口本身**：
同一个 `FaultSpec` 走一次不经执行器的直接读，拿到 `direct`，再走执行器拿一份，然后
`assert_eq!(executor_fault, &direct)` —— "不变形"于是成了两个产物的相等关系，而不是我对某个位的意见。
它还顺手抓住另一件我没想到的事：故障只被消费一次，所以第三次读必须成功（= 执行器没重试）。

**可复用**：**要断言"某个包装层不改变被包装者的输出"，就比较两层的输出，别去断言输出的某个字段。**
比字段就是把"我以为的语义"写成事实；比两次产出，判据就落在生产者身上。与 `§4.88`（变异没咬住先怀疑
断言不精确）同族，但这条更早：**断言在写出来的那一刻就该有生产者可指**。

### 4.92 `dead_code` 警告 = 我写了夹具、计划了断言，却忘了把断言写下来

**现象**：`crates/caly-io/src/executor.rs` 的测试模块里我定义了 `SleepFaults`（一个 `sleep_until` 必然
失败的时钟），打算测"睡眠那条路本身故障时不许被说成 `Busy`"。写完一批测试就收工了，`cargo clippy` 报
`struct SleepFaults is never constructed`。

**为什么这不是"顺手加个 `#[allow(dead_code)]`"的事**：未使用的夹具在这里的含义是**承诺没有见证人**。
`run_until_idle` 里那段 sleep 分支的返回值处理（`Ok(Err(fault)) | Err(fault) => stop = Some(fault)`）
当时一行断言都没有 —— 也就是说，"执行器不会把端口故障重标成 `Busy`"这条我在模块文档里写下的语义，
只有跑在端口调用上的测试、没有跑在睡眠调用上。补出来的 `a_fault_from_the_sleep_port_ends_the_run_as_that_not_as_busy`
第一次就断言了 `ticks == 1`（故障当场终止，不重试）与 `busy_stops == 0`（这不叫拥塞）—— 两条都是
没有这个警告就不会存在的断言。

**可复用**：**零依赖工作区里的 `dead_code` / `unused` 警告是免费的覆盖率检查器**。它报"你写的东西没人用"，
而在测试代码里，那几乎总是"你想测的东西没人测"。修法是补断言，不是压警告。

### 4.93 多处修改放一个脚本、末尾只写一次盘：`AssertionError` 就等于"什么都没发生"

**现象**：一次五个替换的补丁脚本，第三个的锚点找不到 —— 因为我上一轮跑过 `rustfmt`，它把
`Poll::Ready(Err(IoFault::new(IoFaultKind::Unavailable, "the port said no")))` 折成了三行，我的锚点还是单行版。
脚本在 assert 处退出，**前两个替换也没写盘**。

**这次这是好事**：与 `§4.87` 那次"脚本中途 abort、后半批没打上、而我把输出 `tail` 掉继续干活"对照，
差别不在会不会 abort（一定会），而在 **abort 之后文件是否处于半改状态**。把 `write_text` 留到最后一次，
半改状态就不存在：要么五处都改，要么一处都没改。

**可复用（两条硬约定，本轮起对自己的补丁脚本一律适用）**：
① **一个脚本 = 一次写盘**，中间只改内存里的字符串；② **锚点必须是"当前文件的样子"而不是"我以为的样子"**——
凡跑过 `rustfmt` 的文件，先 `sed -n`/打印 `repr` 看清那几行再写锚点（本轮就是这么找回头绪的）；
③ 看到 `AssertionError` 一律当作"什么都没发生"重跑，而不是"大概改了几处"。

---

### 4.94 一个谁也关不掉的合取项不是安全属性：`is_immediate` 里多出来的那一条

**现象**：`RunLimits::is_immediate()` 我写成 `cancel.is_none() && deadline.is_none() && clock.is_none() && !unjudged`。
证伪变异把 `!unjudged` 删掉，**没有一个测试变红**。

**为什么测不出来**：`for_command` 永远会把 `ctx.cancel` 装进去（哪怕没取消），所以对任何由它构造的
`RunLimits`，`cancel.is_none()` 早就是 false —— `unjudged` 那一项在**每一个可达状态**上都是冗余的。
它看起来像"不可判的情形我要单独处理"，实际是死代码。

**处置**：把合取项删掉，并在定义处写下为什么这里只有三条（连带指回本节）。**没有**为了"让那条有用"
去新增一个"只带时钟不带 token"的构造器 —— 那个状态没有生产者，加它就是在给一个不存在的场景写测试。

**可复用**：**判断一个条件是否真的在保护什么，办法是把它取反然后看有没有东西变红。**证伪跑不出来的
分支要么已经被别的条件覆盖了（那就是冗余，删掉并说明），要么根本不可达（那就是死代码，更该删）。
与 `§4.88`（变异没咬住先怀疑断言）、`§4.90`（度量口径要能被证伪）同族，这条是它的第三种形态：
**变异没咬住，也可能是那个变异在语义上是空操作**。

### 4.95 我的断言只读了 cycle 结果，于是 `fail()` 把 job 记录写成 `Failed` 也没人管

**现象**：M14 把 `mark_finished(self.queued, failure.settle)` 改成硬写 `JobOutcome::Failed`（cycle
返回值仍然报 `Cancelled`），14 条测试**全绿**。这条变异不是假设的：`WorkerCycleResult.outcome` 和
`JobRecord.state` 本来就是两个读者各看一个，而我在 `fail()` 里只改了其中一处的来源。

**补的断言**：`assert_settled_state(handle, job, JobState::Cancelled | TimedOut)` —— 同一个结算必须在
"调用方拿到的 cycle 结果"和"job 记录"两处一致。补完之后 M14 立刻变红。

**可复用**：**新写一条"某处被改成 X"的通道时，把所有会读到这条通道的地方都列出来，逐个断言一致**。
只断言离我最近的那个读者（这一轮的 `result.outcome`）等于什么都没保证：`watch_bridge`、support bundle、
`job follow` 读的是记录，不是返回值。`§4.81`（活动快照被两处赋值各推一遍）是同一形状的另一版：那时是
"两处写一处真"，这次是"两处读一处测"。

**顺带一条手法**：M14 一开始是我打算做而没做的第 15 条变异 —— 因为我觉得"这个分支的两句改起来太像"。
**觉得像就跳过的那条，往往正是没被断言的那条**：写变异清单时，优先给"同一个值有两个去处"的形状各来一刀。

### 4.96 "接了限制"的可测定义：能不能不靠我自己造的 future 就让拒绝发生

**现象**：把 `Ctx` 的 deadline/cancel 接进 `run_ready_in` 之后，`cargo test` 全绿，看起来"超时已经能
打断 store 访问"。真相是：本仓每个后端在引擎这一层首次 poll 即就绪 —— `FsStore` 内部自己用
`block_on_ready` 驱动端口，挂起在那一层就被摊平成 `StorageError`（`suspension(...)`）。所以**已经
开始的**调用一次也没被打断过，能观察到的只有"开始前就被拒"。

**这一轮怎么处理**：把边界写成三样东西，而不是写成一句乐观的注释 ——
① `recovery.rs` 里用**手写挂起 future** 证明"驱动器确实在驱动"（`a_suspending_store_call_is_driven_to_readiness_within_the_budget`：
预算 4 次就成功、`immediate()` 就 `NotReady`），并让"文案与 `block_on_ready` 逐字相同"也进断言；
② `ADR-036 §6bis-quinque` 明写"要进端口就得先给 `StorageBackend` 的签名带上 `Ctx`，那动的是 `RFC-0007`
冻结过的形状"；③ 未覆盖清单同句同步（`IMPLEMENTATION_STATUS` 开头那段）。

**可复用**：**给"强制执行 X"这件事写验收标准时，先问：不加夹具的话，有没有一条测试能让 X 真的触发？**
没有就说明 X 目前只在**接缝的语义**上成立，不在**世界**上成立 —— 那要把"在哪个语义层生效"写进 ADR 与
状态文档，别让一个词（enforced）替两个不同的承诺背书。反面教材就在 `ADR-036 §1` 那张表里：
`deadline_ms` 被逐层传递而无人读取，正是"传下去"被当成了"做到了"。

**同族的另一半**：本轮还专门断言了"**限制在场但没被触发时，答案与不设限制逐字节相同**"
（`limits_that_are_present_and_not_violated_answer_exactly_like_having_none`）。一个会在没违规时改变行为的
检查，本身就是一个 bug —— 这条断言成本 10 行，能挡住"加了校验顺手改了语义"。

### 4.97 我在 doc 注释里写过一个"本轮实测 23 个文件"，下一轮就过期了：数字必须带着它的命令一起住

**现象**：第二十二轮我把 `caly-io/src/runtime.rs` 模块文档里那句"三个调用点"改成了"23 files, measured"，
当时确实实测过。本轮复核同一条命令：排除 `runtime.rs` 自身读 **26**，不排除读 **27**（23 那个数是带排除条件
测出来的）。没有任何门禁会为此抱怨 —— 那是注释里的一个数。

**更难看的一半**：我第一版给这个变化编了原因（"中间两轮各新增了调用者"，并点了两个文件名）。查下去只对
一半：`crates/caly-io-sim/tests/executor.rs` 与 `crates/caly-engine/tests/ctx_limits_in_apply.rs` 确实新增
了命中（4 处与 2 处），但余下的差额我没有再查，也**不必**再查 —— 因为这条留档的正题不是"谁改了"，而是：
**一个没写口径的计数，连"它为什么变了"都无法被回答**（同一句"实测 23 → 27"里还混着口径差 1 这件事）。
编原因这一步和我在 `§4.87` 记过的"把工具的自报数当证据"是同一双手。

**为什么会发生**：我以为 `§4.87` 那条纪律（不复述自数的成功数）已经学会了，实际只学会了文档正文那一半 ——
代码注释里的数字完全没人管。它们比 `§3.3` 的 census 表更危险：census 有 `--check` 与门禁，注释里没有任何裁判。

**处置**：数字换成**带过滤条件的完整命令**，并注明两种口径各读多少：

```bash
# 27 this way, 26 with `runtime.rs` itself dropped -- state the filter or the number
# cannot even be argued about
grep -rn block_on_ready crates/ --include='*.rs' | cut -d: -f1 | sort -u | wc -l
```

并让那句话自己承认会过期。这与 `ONBOARDING_NOTES`
规模段本轮采用的写法一致："每条数字后面跟着产出它的命令"。

**可复用**：**代码注释里的数字只有两种安全形态** —— ① 裁判会核对的（census、`#[cfg(test)]` 断言、门禁输出）；
② 旁边放着可复制的命令，且命令写全（含过滤条件）。两者都不是的数字，要么删掉要么改成命令：一个过期过的数字
会连同一整段话的可信度一起赔进去，因为它教会下一个读者"这里的实测是修辞"。

**可复用**：**写进代码注释的数字只有两种安全形态**：① 裁判会核对的（census / `#[cfg(test)]` 断言 /
门禁输出）；② 旁边放着可复制的命令，读者能自己重跑。两者都不是的数字，要么删掉要么改成命令 —— 一个
过期过的数字会连同一整段话的可信度一起赔进去，因为它教会下一个读者"这里的实测是修辞"。

**同族**：`§4.87`（工具自报的成功数）、`§4.78`/`§4.89`（"文本变长"当证据）、`IMPLEMENTATION_STATUS §3.3`
用生成器代替手写表格 —— 同一个原则的第四次落地：**能被独立复算的才写下来，不能复算的就写清怎么复算**。

### 4.98 一个"什么都不做"的守卫，没有计数者就没有证人：`charge` 在 `drive` 之前

**现象**：本轮 M9 那条变异（把 `limits.charge()` 从 `drive` 之前挪到之后 —— 也就是"store 被问了，然后才
说预算不够"）跑出来后 **14 条测试全绿**。我的断言看的是拒绝的 kind、消息里的两个数字、`billed()` 的值：
`async { 6u8 }` 这种被跑一次和被跳过在**这些读数上一模一样**。

**修法**：给那个测试换成一个会自报被 poll 次数的 fixture（`CountsPolls`），断言"被预算拒掉的那次，
future 一次都没被 poll"。M9 立刻变红。

**可复用**：**任何以"不做某事"为内容的守卫（限流、预算门、幂等短路、取消检查），它的测试必须包含一个
能记录"那件事有没有发生"的观察者**。断言返回值只能证明守卫*说了什么*，证明不了它*拦住了什么* —— 而拦住
才是它的职责。与 `§4.95`（两处读者只断言一处）、`§4.88`（变异没红先怀疑断言不在分支上）同族；这条是
"变异没红"的第三种成因：**被改的行为根本不可观察**。

**顺带**：这个缺口是证伪跑出来的，不是写完时想到的 —— 所以"先写完再跑变异"这个顺序本轮又救了一次。

### 4.99 我用正则折叠两行字符串，吃掉了一个 `.expect(...)`；是警告拦下的

**现象**：为了把两处 `-- otherwise a \\` 续行合并成单行，我写了 `re.sub` 的两条规则。跑完 `cargo test`
是绿的（因为丢掉的正是内层 `.expect("the store accepts it")`，而它丢掉的 `Result` 只在 `--all-targets`
下产生 `unused_must_use` 警告，不在 `cargo test` 的输出里被我的 grep 命中）。下一句 `billed()==1` 仍然
成立，于是"测试全绿"。

**怎么被抓到的**：我随后跑 `cargo check --workspace --all-targets | grep -cE "^warning|^error"` 读出 1
条 `unused \`Result\` that must be used`，回头一看那个语句只剩一个 `.expect`。手工补回。

**可复用（`§4.89` 的第二次落地，比上次更具体）**：**跨行改写字符串/表达式的正则不允许**——要合并续行
就整块重写那个断言，写完立刻读一遍改动处的上下文；而 **`cargo check --all-targets` 的警告必须看**，
它是"我删掉了半个表达式"这类破坏的免费检测器（本轮的 `is_immediate` 与这次都是）。凡是自动改写之后
测试仍然全绿，先怀疑改写吃了内容，而不是怀疑内容本来无用。

### 4.100 `cargo: command not found` 被我的 grep 管道吞掉，于是我读了个"编译干净"

**现象**：本轮中途工具链消失（`~/.rustup/toolchains` 不存在，只剩 `rustup` shim）。我连着两条命令
`cargo test --workspace 2>&1 | grep -E "^test result|FAILED|^error"` 都返回**空**，我据此认为"改动没破坏
任何东西"。真相是 bash 把 `command not found` 写到了**自己的** stderr，管道里什么都没有。

**怎么暴露的**：下一步我要看警告，用了不带 grep 的 `cargo check ... | tail -3`，第一行就是
`cargo: command not found`。重装工具链（`rustup toolchain install stable --profile minimal --no-update`，
10 秒）之后重跑，才看到真实读数 —— 而我之前那次"clean"的 check 其实根本没跑过。

**可复用**：**空输出不是通过，是没有运行。**两条硬习惯：① 判定类命令要么看原始输出的尾部，要么把
`exit code` 和"有没有出现预期的行"一起校验（`§4.84` 的 `build_failed` 就是这套）；② 每轮开头先跑一条
`cargo --version`，把工具链存在性当成交接动作 —— `scripts/check.sh` 的 `== toolchain` 那一步早就在做，
我这次是绕过了门禁自己跑命令才踩的。**绕过门禁的手势，门禁的护栏也不在**。

### 4.101 同一条状态在索引里有两个住处，上一轮我只改了一处

**现象**：第二十三轮我把 ADR-036 的落地状态推进到"第 2 步已落地"，改了 `docs/adrs/README.md` 的条目行，
但**表格那一行**（同一文件第 54 行）还写着"第 2–4 步未开始"。本轮复核时发现，门禁全绿 —— `check_heading_numbers`
管编号唯一，`check_path_references` 管路径存在，没有一条管"同一事实在两处一致"。

**处置**：本轮两处一起改，并把"**改任何 ADR 状态时先 `grep` 该编号在 `docs/**` 的全部出现**"写进 §6.56 的
处置行。做法上就是把一次"我以为只有一处"的编辑，换成一次"先看有几处"的编辑。

**可复用**：一个事实有多个住处时，**先数住处再动手**（`grep -rn "ADR-036" docs/` 是一条命令的事）。这与
`§4.81`（活动快照被两处赋值各推一遍 → 搬回唯一所有者）是同一诊断的文档版：区别只在代码那侧能靠"改
表示层"消掉重复，文档这侧消不掉，只能靠"改之前先数"。

**第二十五轮补记（同一条规矩当轮命中三次）**：改 `ADR-038 §13.2` 的状态之前先 grep，发现
`IMPLEMENTATION_STATUS` 的未覆盖清单里还挂着三句过期话：`Ctx.deadline_ms` "今天仍不取消任何东西"
（第二十三轮就能拒未开始的访问了）、`caly-app::remote` 的预算转发"没有端到端断言"（第二十四轮补上了）、
"预算记账与默认值收窄仍未做"（同样是第二十四轮）。三句都写在我自己的轮次记录里，**没有一条门禁会抱怨**，
因为它们是散文。修法不是「再补一轮」，而是把 `§4.101` 那句「改状态前先数住处」当成动手的第一步 —— 本轮
它一次就捞出三处，值。

### 4.102 一个 DTO 有一份"渲染同一事实"的函数，却从来没有生产者 —— 它可以永远悄悄分叉

**现象**：本轮要给回收记录加 `triggered_by`（`caller` 还是 `automation:gc.idle`）。grep 时发现
`caly_api::GcRunView` 是 `caly_engine::gc_plan::GcRunRecord` 的双胞胎 DTO，**连一份 `summary_line()`**，
而 `grep -rn "GcRunView" crates/` 只有它的定义与一行 re-export：**没有一处构造它，也没有一处调用它的方法**。
于是"两句一样的话"这件事没有任何断言能碰到 —— 引擎那份加不加 `triggered_by`，DTO 那份都不会响。

**为什么这比"少个功能"贵**：`doctor` 的 note 和 bundle 的 `storage-gc` 段打的是**引擎那份**行；哪天有人把
DTO 接到 `system.gc-collect` 的答案上（很自然的下一步），客户端就会看到一句**没有归属**的回收记录 —— 而"谁
允许它删的"正是本轮加这个字段的全部理由。分叉不是发生在写下的那天，是发生在没人能检查它的那天。

**处置**：给 DTO 补同一个字段，并在 `gc_plan.rs` 加一条断言 `view.summary_line() == record.summary_line()`
（构造 view 的代码就写在测试里，字段一多或少一处就会红）。**没有删掉这个死 DTO** —— 它是 RFC-0002 侧的
形状，删除是另一件事；但把它"无生产者"这件事写进 `ADR-038 §9`，让下一个接手的人知道那条断言为什么存在。

**可复用**：**给一个事实加可观察字段时，先 grep 有没有第二处也在渲染它，再 grep 那处有没有生产者。**
"有类型、有渲染、无生产者"是同一个坑的第四次出现（`StorageBusy` 第二十轮、`JobOutcome::Cancelled`/`TimedOut`
第二十三轮、`required_role` 第十八轮），区别只在前三次是枚举变体、这次是 DTO。修法也一样：要么接上生产者，
要么用断言把重复的两句话钉在一起 —— 唯独不能放着不管，因为**没有生产者的代码不会被测到，只会被读到**。

### 4.103 两次红测试都是我的 fixture 不满足判定条件，不是代码没生效

**现象**：自动收集的第一版测试全红：对象没被删。我读成"gate 没接上"。实际有两个 fixture 级原因，
各自都会单独造成同样的红：① 没 `set_storage_clock` ⇒ 计划比较的是"文件日期(START)"与"policy 基准(0)"
两条时间线，`would_run` 直接**拒绝**（这是第十九轮故意做的保守方向）；② 注入了时钟之后，对象年龄 = 0，
仍在默认 15 分钟 grace 之内 ⇒ 计划说得出"不能收"。两处都改完才有东西可删。

**怎么定位的**：不是靠重读代码，是靠我在同一批测试里顺手写的那条**人工对照** ——
`an_automation_cycle_never_precedes_a_callers_command` 用同一种对象、同一个 fixture 走**人工**收集，
它成功删掉了东西。于是"fixture 不产生可收集状态"这个假设被当场否证，剩下的差别只可能在自动化那侧 ——
而真相是两侧都没错，是我的前提不成立。

**可复用**：**写"自动做 X"的测试时，先写一条"人工做 X 也成功"的对照测试。**它把"世界不具备可观察条件"
和"自动化没接上"分开；少了它，我会花一整轮去改一个本来正确的 gate。同理，涉及阈值（grace、上限、时限）
的断言，要把阈值本身写成 fixture 里能读出来的数（本轮 `put_aged` 直接推进 `GRACE + 1`，并在注释里说为什么），
否则下一个人只会看到"没删"。

### 4.104 "何时发生"的断言要在"何时"读：我拿循环结束后的计数器去证明一次触发是准点的

**现象**：一条断言 `fired_at % INTERVAL == 0` 红了，报的是 `9`。而 9 才是对的 —— 我把 `fired_at` 读在
"跑完 8 次 drain 之后"，那里面包含了触发**之后**继续走的检查。代码没错，我的读数位置错了。

**为什么会写成这样**：我用 `for _ in 0..N` 去**猜**"drain 次数 → 检查次数"的对应关系（`enable()` 已经消耗了
一次检查，循环里每次 drain 又恰好走一次……）。凡是这种"A 的整数倍等于 B"的心算等价关系，都是一处没写下来的
假设（`§4.87` 的同一族：把方便的读法当证据）。

**处置**：把驱动改成按**不变式**走 —— `while checks % INTERVAL != 0 { drain_one() }`，再断言 `checks % INTERVAL == 0`。
两个好处：不再依赖 setup 消耗了几次检查；如果 cadence 哪天变了（常量或取模被改），这个 while 会自己走到新的
due 点，而断言仍然只说真话。另一处同类修正：把 `after.checks >= fired_at + 2 * INTERVAL` 改成
`>= fired_at + INTERVAL`（我按"5 次 drain = 5 次检查"算了个不存在的余量，实测 4+5=9 才看见）。

**可复用**：**关于"何时"的断言，读数要取在事件那一刻，或者干脆把驱动写成不变式循环。**固定次数的循环 +
事后读状态，等于让 setup 的细节进入断言 —— setup 一改它就假红/假绿，正是这类测试最难查的那种。

**同一族的第二次（M6 连跑两次都没咬）**：为了证明"每次自动周期用的是新 key"，我先加了"记录必须更新"
又加了"必须多一个 job 行"，两条都被 M6 溜过去了 —— 因为计数器一重置，触发点自己也跟着移动，fixture 的
循环长度**恰好**让两次触发落在不同的检查号上，key 自然不撞。真正的修法是把两次触发**钉死**：`enable()`
之后固定 drain `interval - 1` 次（第一次触发必落在 check 4），再 drain 恰好 `interval` 次（正确代码走到
check 8、M6 回到 check 4）—— 这时 M6 立刻变红。**"证明两个东西不一样"的测试，必须自己控制这两个东西
的位置**；把位置交给循环次数，等于让被变异的对象决定证人站在哪里。
事后读状态，等于让 setup 的细节进入断言 —— setup 一改它就假红/假绿，正是这类测试最难查的那种。

### 4.105 我差点在报告里写「已补两处」，grep 发现那两个 edit 一次都没跑：同一个毛病的第五、第六次

**现象一（动作没发生，却以为发生了）**：本轮我准备在总结里写「`§4.102` 的补记与 `executor.rs` 的措辞修正已应用」。
写之前按 `§4.101` 的习惯先 grep 了一遍要引的那句话 —— **两个字符串在文件里都是 0 次**。真相是那两个 edit 我
**只写了脚本、没有跑**（当时执行的是另一份修复脚本）。没有编译错误、没有门禁失败，因为「少了一段散文」从来不
会让任何东西变红。

**现象二（自数的合计）**：我在文档里写了 `446` 与「新增 12 条断言」。而两个裁判早就各自给出：生成器
`files=59 total=447`、门禁 `447 tests passed`。我算的是 434 + 4 + 6 + 3 = 447，写下来的是 446 —— 因为我先按
「探针文件 5 条」算过一版，后来加了第 6 条测试，**改的是代码，没回头改脑中的算式**。

**同一族的账**：`§4.53`（过滤 grep 掩盖编译失败）、`§4.87`（工具自报的成功数 + 被我 `tail` 掉的 abort）、
`§4.97`（注释里的裸数字）、`§4.99`（自动改写吃掉半个表达式）、`§4.101`（同一条状态两处住处）—— 本条是把它们
合起来看时的缺口：**「我以为我做过」和「我以为数得对」是同一件事，都没有裁判。**

**可复用（本轮起当成硬规定）**：
① 文档与报告里每一句「已改 X」，落笔前先 grep X 那句话；命中数不是 1 就是没做（或者做了两处）。
② **不写自己算出来的合计**。总数只从两个来源抄：门禁的读数与生成器的读数；二者不一致就停手。
③ 写完文档再跑一次 `check.sh`：本轮它把 `TEST_FLOOR=446` 与实测 447 并排摆着，一眼就能看出不对。
④ **重抄要放在最后一次改动之后**：本条写下之后我又给这个毛病加了门禁（`check_disposition_ledger`，3 条测试），
于是刚抄进来的 447 立刻又过期，最终裁判读数是 450 —— 也就是说规矩 ② 不是「抄一次就完」，而是「交付前重抄一次」。
本轮最终所有数字都是在代码定型之后写的，且 `TEST_FLOOR` 与两个来源同值。

### 4.106 给一个 DTO 加字段，改坏的是两个我没碰过的文件：响应尺寸是跨 crate 的性质

**现象**：本轮给 `GcPlanView` 加了 `last_run: Option<GcRunView>`（`GcRunView` 里有三个 `Vec` 两个 `String`）。
编译干净、测试全绿，`check.sh` 却报 `clippy locations grew: 34 > baseline 32` —— 两条新告警落在
`crates/caly-ipc/src/frame.rs` 与 `client_loop.rs` 的枚举上（`large_size_difference_between_variants`）：
`ServerFrame::Response(ResponseEnvelope)` 从阈值以下被顶到 424 字节。**我一行都没改那两个文件。**

**为什么会这样**：`ResponseEnvelope → OperationResult → GcPlanView → GcRunView` 是一条尺寸链。IPC 的枚举
变体大小等于它装的东西的大小，所以"在最外层给一个内嵌 DTO 加 150 字节"这件事，物理上发生在传输层的枚举里。
基线棘轮抓得正好：它不看谁改了哪个文件，只看**这个仓库现在的形状**。

**处置**：`last_run: Option<Box<GcRunView>>`（+8 字节而不是 +150），字段注释写明为什么是 Box。类型上对使用方
几乎不可见（`Box` 自动 deref，`expect`/`clone`/逐字段比较都不用改），但把 `caly-ipc` 的两个枚举拉回阈值以内，
clippy 回到 32。**没有抬基线，也没有在两处 `#[allow]`。**

**可复用**：**在会穿过边界的类型上加字段之前，先量一次代价**：`cargo clippy --workspace --all-targets` 跑在
改动之后（本轮就是它先发现的），或者干脆按 `ApplyFailure.error: Box<ApiError>` 的先例做 —— 那个注释写的
就是同一件事（"装箱让错误通道保持小，而不动任何公开 DTO"）。反过来说，如果一个新字段确实把某个传输层枚举顶过
阈值，那**它就不是"加一个字段"，而是"改一次协议形状"**，该在 ADR 里说一句；本轮把它写在这里并同步进 DTO 注释。

**与 `§4.78`/`§4.89` 的关系**：那两条说"文本变长不是证据"；这条是它的物理版 —— **"编译通过也不是证据"**，
因为有些后果（尺寸、变体比例）根本不在类型检查的射程里，只在门禁的射程里。

---

### 4.107 「`ADR-038 §6.2`」是我自己写下的错引：ADR-038 没有 §6.2，那条待办的锚点在 `OVERLOAD_AND_RETRY_MODEL §6.2`

**现象**：第二十六轮收尾时我把下一步写成「`ADR-038 §6.2` 的 cutover 存储争用模型」，dev-log、
`IMPLEMENTATION_STATUS`、`CENTERLINE_PROGRESS` 跟着抄了一串。本轮开工前去读那一节，
`grep -n '^### 6\.2' docs/adrs/ADR-038-storage-gc-plan-and-role-gate-on-reads.md` **0 命中**；
`grep -n '6\.2' 同一文件` 只命中 `§8` 里的小节标题「`StorageBusy` 第一次有了生产者，以及它与 `§6.2` 的区别」——
而那一句里的 `§6.2` 指的是 `docs/OVERLOAD_AND_RETRY_MODEL.md §6.2`（`IMPLEMENTATION_STATUS` 第 187 行写的正是全名）。

**为什么会这样**：抄上一条待办时，我把「ADR-038 第 2 步里提到的那个 `§6.2`」缩写成「ADR-038 §6.2」。
缩写是免费的，所以它会传染：一处省略，三处跟着错，而且读起来都通顺。

**处置**：本轮把所有引用改成带文件名的 `docs/OVERLOAD_AND_RETRY_MODEL.md §6.2`，并在 ADR-038 `§8` 的
小节标题里补上文件名（那处本来就是歧义的源头）。

**可复用**：**写 `§n.m` 必须带文件名**。`every_documented_path_reference_resolves` 只检查文件是否存在，
节号没有任何裁判 —— 而裁判很便宜：`grep -n '^#\+.*6\.2' <那个文件>` 一行就能证伪一句引用。

---

### 4.108 第 23 轮我写下「`advance_apply_phase` 由 `worker.rs` 填」，而 worker 从没调用过它：一句「已接线」活了四轮

**现象**：`ADR-036 §6bis-quinque` 的「接线」段说 `begin_apply_persistence` 与 `advance_apply_phase` 都由
`worker.rs` 用 `run.store_limits()` 填。本轮复核：

```text
$ grep -rn "advance_apply_phase" --include=*.rs crates/
crates/caly-daemon/src/app.rs:647          # seed_recovery_fixture
crates/caly-engine/src/recovery.rs:75/90   # 定义与内部
crates/caly-engine/src/service.rs:534/549  # handle 上的包装
crates/caly-engine/tests/{apply_execution_gate,ctx_limits_in_apply,durable_centerline}.rs
```

`worker.rs` 一次都没有。也就是说逐步游标四轮以来**只有测试与一个"模拟崩溃现场"的 fixture 在走**，
真实 apply 全程只在计划跑完后写一次 journal —— 这正是 `OVERLOAD §6.2` 一直挂着「未落地」的原因。

**处置**：本轮把它变成真的（见 `§6.59` 那一行），并在 `ADR-036 §6bis-quinque` 原句下面**追加**一条更正而不是
改写历史（那句话是当时的判断记录，改写它就会丢掉"为什么当初会这样以为"）。

**可复用**：形如「已接到 X / 由 X 调用」的句子，**必须能被一条 grep 复现**，而且那条 grep 要写进文档同一处。
不能复现的它就是叙事，不是事实；叙事会活着穿过四轮，事实不会。

---

### 4.109 「一份命令一个预算计数器」在第二个接缝出现之前是不被检验的：`Clone` 共享只是意图，不是性质

**现象**：`RunLimits` 的注释写着上限「属于这次命令执行，而不是某个副本」，实现靠 `billed: Arc<AtomicU32>` +
`Clone` 共享。第 23 轮只有一个有界接缝（`begin_apply_persistence`），于是这句话**没有第二个使用者可以去检验**。
本轮要给游标接缝加限制时，最省事的写法是在 `execute_effects` 里再调一次 `run.store_limits()` —— 而
`RunLimits::for_command` 每次都新建 `billed: Arc::new(0)`，于是"64 次 store 访问"悄悄变成"每个接缝 64 次"。
没有任何测试会红：默认预算足够大，两个接缝各自都花不完。

**处置**：`run_apply` 里建一次 `limits`，以 `&RunLimits` 传给两个接缝；
`crates/caly-engine/tests/cutover_intent_guard.rs` 的 `the_callers_budget_bounds_the_cutover_window_too`
用 `max_requests = 1` 把它钉住 —— 旧写法下第二个接缝会从头计数、apply 会跑完，断言的那一条 intent 记录数
（1 对 2）正是分歧点。

**可复用**：**共享状态的设计，要在"第二个使用者"出现的那一轮补一条跨使用者断言**；在那之前它只是意图。
同一族的还有 `§4.81`（两处各写一遍同一个数）—— 那条是"重复"，这条是"只有一个人用到的共享"。

---

### 4.110 我自己搭的夹具先骗了我两次：断言写成子集、手搭的计划没过自己的门禁

**现象**：新加的三条断言第一遍跑就红，两次都是夹具而不是实现：① 我拿 `TracedRuntime` 的 trace 断言
「intent 与 exec 的交错」，但只列了 cutover 相关的条目，`exec Prepare` 一出现就炸 —— 我实际上写的是
**子集断言**，它既看不见顺序也看不见多余的那一次；② 手搭的 plan 以 `MarkSnapshot` 结尾，而
`require_probe_before_commit` 默认为真，于是执行结果是 `RollbackFailed`，我却断言 `succeeded()`。

**处置**：①改成断言**整条 trace**（`["exec Prepare", "intent 1 (Cutover)", "exec Cutover", ...]`），
交错与「不多写一次」同时被钉住；②在 plan 里补一个 `Probe`（`deadline_ms: 1_000`，顺带满足第 26 轮
`deadline_ms == 0` 在计划校验阶段就被拒那条规则）。

**可复用**：**手工夹具必须过它自己声明的门禁**，否则"红"会被误读成实现坏了；断言交互顺序要断**整条序列**，
子集断言是顺序问题的天然藏身处（`§4.98` 那条"用会自报的 fixture"是同一族的另一面）。

---

### 4.111 在同一列上追加写之后，「这一列仍然单调」要重新证明：我把它写成断言而不是注释

**现象**：`journal_after_execution` 的 `updated_at` 一直是 `policy.timestamp_at(clock_ticks.max(1))`；本轮插入的
逐条 intent 写用 `policy.timestamp_at(step_index + 1)`。若后者更大，**最后那条"真相记录"的时间就会倒退**，
而没有任何东西会发现：`advance_apply_journal_step` 只是逐字段赋值，不比大小，也不要求单调。

**处置**：先算清关系（`step_index + 1 <= plan.steps.len() <= execution.clock_ticks()`，因为 `clock_ticks`
把解释过与被跳过的步骤都计入），再把它写成断言：`a_real_apply_writes_the_cutover_window_into_the_store_as_it_goes`
里那条 `writes[first_intent].updated_at_unix_ms <= writes[last].updated_at_unix_ms`。

**可复用**：**追加写路径会改变"某列有序"这类性质的成立条件**。这类性质只要没被断言过，就是在假设读者会
自己推导（`§4.55` 的同一形状：能推导的东西不该靠读者推）。

---

### 4.112 一条证伪变异因为不编译而作废：变异也要保持形状，否则它测的是 rustc

**现象**：M7 想证明「把 guard 的专门分支折回通用失败路径」会被抓到，写法是把

```text
if let Some(refusal) = cursor.refusal.clone() {
```

换成

```text
if cursor.refusal.is_some() && false {
```

条件确实恒假了，但 `if let` 的**绑定**也一起没了 —— `cargo test` 报 `E0425: cannot find value
refusal`，harness 如实记成「MUTATION DID NOT BUILD」，于是 13 条里只有 12 条算数。

**处置**：换成保住形状与类型的等价式 `cursor.refusal.clone().filter(|_| false)`，重跑 → 三条预期断言全红
（外加一条我没预期会红的 `the_callers_budget_bounds_the_cutover_window_too` —— 说明这个分支同时是两条
性质的裁判，那更好，不必改断言）。

**可复用**：**变异的目标是"让某条性质不再成立"，不是"让程序坏掉"**，所以改写必须保住绑定、类型与调用
arity。harness 把「没编译」与「没咬住」分开报是第七轮立的规矩（`§4.60` 一族），本轮是它第一次真的救我 ——
否则一条**无效的证伪**会被我记成通过。附一条顺序：报 `did not build` 之后先改变异，别急着改测试。

---

### 4.113 为了数一个 target 数而 `touch` 了全仓 `.rs`，于是「我只改了这些文件」再也没法复核

**现象**：本轮要重抄 `IMPLEMENTATION_STATUS §3.1` 里那句「60 个可执行 + 20 个 doc-test」，但 cargo 在缓存热的
时候不重印 `Executable unittests` 那些行（第一次 `grep -c` 得 0 —— `§4.100`「空输出不等于通过」的又一例）。
于是照文档自己给的配方跑了 `find . -name '*.rs' -exec touch {} +`，数字拿到了（实测 20 + 41 = 61 个可执行
+ 20 个 doc-test = 81 个 target）。代价是本轮收尾时 `find -newermt '-2 hours'` 列出 210 多个文件：我本来打算
用它复核「这一轮我只动了这些文件」。

**为什么会这样**：一次性取证手段污染了取证要用的那个信号。mtime 是这个仓库里唯一没有版本控制替我记的东西
（工作区不是 git 仓库），一旦被动过就补不回来。

**处置**：改用**编辑记录本身**复核。本轮的每个改动都是 `write_file` / `edit_file` / python 补丁脚本做的，
清单因此是已知的：`crates/caly-engine/src/` 下的 `executor.rs` / `worker.rs` / `service.rs` / `run_limits.rs` / `overload.rs`、
`crates/caly-engine/tests/cutover_intent_guard.rs`（新）、`crates/caly-arch-test/tests/dependency_direction.rs`、
`scripts/check.sh`、7 篇文档。另外两处「临时改过又改回」的（`service.rs` 的 `PROBE27` 打印、证伪 harness 的
13 次变异）各有 sha256 复核，`grep -rn PROBE27` 现在只命中 dev-log 里那段被引用的证据。

**可复用**：**取证之前先给信号拍照**——要 `touch` 就先把 `find -newermt` 的输出存盘，之后再比；或者干脆别依赖
mtime：在这个仓库里能证明「改了什么」的是 sha256 与门禁，不是时间戳。

---

### 4.114 只有一个"永不就绪"的仿真端口，就没办法验证任何"上限"：预算必须两侧都推得动

**现象**：本轮要给 store 的 poll 预算加断言。仿真器已有的注入只有 `hang`（端口永不就绪）。用它写出来的测试
只能证明"会被拒"，于是**把预算改成 1 也全绿** —— 因为"驱动器放弃太早"与"端口卡死了"在只有 `hang` 的世界里
是同一个读数：同一句 `Busy`、同一条 `still pending` 文案、同一个 `retryable`。换句话说，我差点写了一条
**只测下界的门禁**。

**处置**：给 `caly-io-sim` 加第二种形状 `stall(label, polls)`（一次性、可数的挂起），并把边界从两侧量：
`polls = 预算 - 1` 必须成功、`polls = 预算` 必须被拒（`the_budget_is_measured_from_both_sides`）。
再加两条编译期锚点（`> 0` 与 **`>= 2`**），因为"一次 poll 的预算"就是旧行为披了个名字。

**可复用**：**凡是一个数被叫作上限，测试就必须从两侧推它**；只有"超过它会拒"的断言不构成对那个数的检验
（`§4.98` 说守卫要有计数者，这条说守卫还要有"能被跨过"的形状）。同一族还有 `§4.110`（子集断言看不见顺序）。

---

### 4.115 信息被抹平的地方，往往不是读它的那一层：`suspension()` 与一次类型降级

**现象**：`caly-storage` 里的 `fn suspension(message: String) -> StorageError { Internal }` 看上去只是
一个粗糙的错误转换 —— 端口没就绪，报内部错误，读者不会停下。真正付账的是**上一层**：
`StoreRefusal::from_storage_error`（第二十七轮加的）只在 `StorageErrorKind::Busy` 时把拒绝升级成
`RefusalKind::StorageBusy`，也就是 `doctor` 的过载账本、`§3.4` 的类别、"重试还是修盘"的判断都挂在这个位上。
`Internal` 一进来，这些全部降级成 `Backend`，而且**没有任何测试会红**——因为文案仍然写着 `still pending after 1 poll(s)`。

**处置**：把 `suspension` 删掉，驱动器自己的拒绝走端口答案用的同一张 `from_iofault` 表；
新增一条反向断言（`assert_ne!(error.kind, Internal)`）与一条引擎层断言（`kind == StorageBusy`），
让"类型没被抹掉"成为可证伪的事而不是风格。

**可复用**：评估"这层要不要保留下游的类型信息"时，**顺着它被读到的方向再走一层**看那里还有没有别的东西能替代；
如果替代品是一段字符串，那答案是没有 —— 一个必须靠 `contains()` 才成立的判断，等于没有判断（`RFC-0006 §5.2`
在本仓被反复引用正是这个原因）。

---

### 4.116 `rustfmt` 必须是每个文件的**最后一次写**：我在同一轮里两次把它跑到改动之前

**现象**：格式化欠账（门禁那句 `note  1685 formatting diff lines remain`）本轮一度变成 1,696。原因是顺序：
我先 `rustfmt` 了 `fs_store.rs`，之后又为消掉一个 `unused_imports` 告警用 python 改了那行 `use`，
**没有再跑一次** —— 于是 import 从多行变成"rustfmt 想合成一行、但没合"的形状，欠账 +11。

**处置**：把 `fs_store.rs`/`schema.rs`/`port_drive.rs`/`lib.rs` 再 `rustfmt` 一遍，欠账回到 1,685，
且 `cargo fmt --all -- --check` 的 `Diff in` 清单里没有任何本轮文件。

**可复用**：**"写完 = 格式化过"要当成一次写操作的收尾**，任何后续 edit（哪怕只删一个标识符）都使上一次
`rustfmt` 失效。这一条与 `§4.105` 的"交付前重抄数字"是同一族：**收尾动作必须在最后一次改动之后**，
无论收尾的是格式还是数字。

---

### 4.117 同一族的第七、第八次：我把下限算成 472（裁判 473），改完又加了 1 条门禁测试（裁判变 474）

**现象**：本轮先新增 10 条测试，我按 463 + 10 心算出 **472** 写进 `TEST_FLOOR`，而
`regenerate_test_census.py` 自报的却是 `files=62 total=473 rows=62` —— 差的那一条是
`caly-io-sim/tests/contract.rs` 里我加的那条 —— 我在心里把它算进了"存储层 6 条"。**改完之后**为了给处置表补相邻性检查，我又加了一条 `docs.rs` 的单元
测试，裁判变成 474 —— 于是本轮全部数字重抄第三次。

**处置**：下限 474，取自 census 的自报数与门禁那行 `474 tests passed (floor 474)`；文档里的总数同一次改完，
改完再 grep 一遍旧值（那条规矩见 `§4.119`）。

**可复用**：这条规矩从第二轮立到本轮，第七、第八次生效：**总数、下限、行数一律取裁判的自报值，我的加法
不是裁判**；而且**每次改动之后都要再问一次**，不是只在"我以为写完了"时问一次 —— 那 1 条之差正是第二次问出来的。
`§4.87` / `§4.105` 是同一个毛病的两种表现；第二十六轮加的 `check_disposition_ledger` 之所以值得，就是它把
"表行与标题对不对得上"变成机器的事，而这一条提醒我：**能被机器判的事，别留在手上**。

---

### 4.118 一个数必须带口径：`cargo fmt --check` 的"1,685 行"与 `grep '^Diff in'` 的"122 处"是两件事

**现象**：本轮我用 `cargo fmt --all -- --check | grep '^Diff in' | wc -l` 复核"我的文件干净"，得到 122；
同一条门禁的 `note` 说的是 1,685。我差点在文档里写下"欠账 122 行"——那既不是门禁的数也不是任何人的数。
两者的差别是：前者数的是 **diff hunk 数**，后者是 **`cargo fmt --check` 输出的行数**（每个 hunk 会打出
`Diff in ...`、`-`/`+` 若干行等）。

**处置**：文档里的欠账一律沿用门禁口径（输出行数），并在句子旁边写清怎么产出；本轮把
"`grep '^Diff in'` 只用于回答'我的文件在不在清单里'"这句写进 `§3.1` 的注释里，不再产出第二个数。

**可复用**：**同一个现象有两种数法时，任何一个数字都必须带口径**，否则读者只能猜，而猜错的方向永远是
"看起来更好"的那一边（`§4.87` 的补记讲过重抄；这条讲的是重抄之前先把尺子说清楚）。

---

### 4.119 我按 `§4.105` 去重抄数字，结果只重抄了四处里的两处：同一个文件里同时留着 462 与 463

**现象**：本轮开工复核时，`ONBOARDING_NOTES.md` 自己的三处数字是矛盾的 ——
处置表 `| 6.59 |` 那行写 `450 → **463**，门禁自报 \`463 tests passed (floor 463)\``（第二十七轮最后一遍改的），
而「门禁结果」段的链尾仍是 `450 → **462** passed（**81** 个 test target`，规模段仍是
`files=60 total=462 rows=60` / `462 tests passed (floor 462)` / `= **81** 个 test target`。
也就是说：上一轮我确实执行了「交付前重抄」，也确实重抄了 IMPLEMENTATION_STATUS 与 dev-log，
**但这个文件里的两处被漏掉了**，而且它们互相矛盾（同一文件的相邻两段）。

**为什么会漏**：我把"重抄"当成一次针对**数字**的动作，而不是针对**住处**的动作。正确顺序是先
`grep -n "462\|463" docs/`（或任何旧值）把住处列出来，再逐条改完 —— 这正是 `§4.105` ① 立的那条，
本轮证明它在"我已经知道这条规矩"的情况下仍然会漏。

**处置**：本轮把三处一并改成第二十八轮的实测值**处置**：本轮把三处一并改成第二十八轮的实测值（474 / 83 个 target / 62 个文件 / 217 个 `.rs` / / 62 个文件 / 217 个 `.rs` /
60,686 行），并把这条规矩改成可执行的形式：**"重抄"的完成判据是旧值的 grep 命中数为 0**，不是"我改过了"。

**可复用**：任何"把同一批数字改到最新"的收尾，都按这个顺序做 ——
① 列出旧值的所有住处（跨文件！`grep -rn '<旧值>' docs/ crates/`）；② 逐条替换；③ 再 grep 一次旧值，
命中 0 才算完。本轮之前我是先改再抽查，所以漏了两处。

---

### 4.120 一条断言可以一直为真，而它旁边的解释已经变成假的

**现象**：`crates/caly-daemon/src/request_map.rs` 里有一条从第二十四轮活到本轮的断言：

```rust
assert!(
    command.context.io_budget.max_bytes.is_none(),
    "bytes are deliberately uncapped at this layer; the asymmetry is documented in\\
     `ADR-036 §6bis-sexies`, not buried in a number"
);
```

断言本身本轮之后**仍然成立**（默认值确实不设字节上限），但消息里那句"bytes are deliberately uncapped at
**this layer**"曾经是"这一层没人执行"的同义反复，第二十九轮之后就是**假话** —— 字节现在是可执行的，
只是默认不设限。测试全绿，文档里的语义已经换了一格。

**处置**：消息改成"the default states no per-call byte ceiling -- bytes are enforceable (by the ports,
since round 29) but unbounded unless the caller asks"，并把引用的 ADR 小节从 `§6bis-sexies` 换到
`§6bis-decies`。**断言不动，措辞必须动**。

**可复用**：改语义的那一轮，除了找"会失败的断言"，还要找**围绕它的句子**：`grep -rn "<字段名>" crates/ docs/`
之后逐条读消息文本。一条 `assert!(x.is_none(), "...")` 的第二个参数是给人读的契约，它过期时没有任何机器会喊。

---

### 4.121 共享 helper + 两个后端：新检查必须逐个后端删一次来证伪，否则你测的是 helper 而不是"两边都调它"

**现象**：`fs_byte_budget_violations` 写完，`StdFs` 与 `SimFs` 第一次就跑过了。看着像好消息，其实是
**这条检查还没有证明任何关于"两个后端"的事** —— 它证明的是 helper 自洽。真正把"两边都调"变成事实的，
是证伪跑里那四条按后端分开的变异（M1/M2 删真实盘的那两处调用 → 只有 `caly-io-std` 的套件红；
M3/M4 删仿真盘的两处 → 只有 `caly-io-sim` 的红）。

**处置**：把这四条写进本轮证伪清单，并另加一条 M10 专门证伪"门禁本身"：把 `caly-io-std/tests/contract.rs`
里那句 `fs_byte_budget_violations(...)` 换成另一个已存在的检查调用（**行为等价**、编译通过、测试全绿），
红的只有新加的门禁 `every_backend_that_runs_the_fs_suite_runs_the_byte_budget_check_too`。

**可复用**：**"两个实现跑同一组断言"这种性质，裁判必须能对每个实现单独失效**；一条只在"两边都坏"时才红的
断言，等于没有断言。与 `§4.98`（守卫要有计数者）、`§4.114`（上限要能两侧推）同族，这条说的是**覆盖面**。

---

### 4.122 取最小值的组合规则要单独测"宽松的那条不许放大另一条"

**现象**：`byte_ceiling(ctx, requested)` 的实现里最容易写错的一行是
`Some(budget) if budget < requested`。写成 `budget > requested`（M5）或干脆写成"取 max"，都不会让
"预算更紧时按预算"这一类断言变红 —— 它们只让**另一件事**变红：预算比 cap 宽松时，调用自带的 cap 必须仍然作数。
换句话说，"min"有两个方向的错法，而常规测试只盯得住一个方向。

**处置**：`the_tighter_bound_wins_and_says_which_it_is` 显式写了三种组合（预算更紧 / 预算更松 / 未设预算），
并让 `sim` 与 `std` 的契约各断一次"预算宽松时仍按 cap 拒，且文案点名 cap"。

**可复用**：**任何"两条规则取更严的一条"的地方，都要有一条"较松的那条不得生效"的断言**；
只测"较严的生效"是半个性质（同 `§4.114`，但那里说的是边界，这里说的是取法）。

---

### 4.123 多行锚点第三次咬我：补丁脚本要先按行证明锚点存在，再替换

**现象**：本轮 `write_file` 出来的 python 补丁脚本连续三次在同一类问题上失败：锚点里有 `**`（我凭记忆漏了）、
缩进是 3 个空格而我写了 2 个、Python 非 raw 三引号串里的 `\\` + 换行被当成续行吃掉。前两次是整脚本 abort
（好在脚本是"最后一次性写"，没有留下半改状态），第三次我在**同一个脚本里**误改了一处已经应用过的 hunk，
导致重复插入检测变成 `hits=2`。

**处置**：换成两种打法并固定下来 ——
① 短锚点 + 按行定位：`needle in line` 找到行，再 `assert old in line` 校验内容，然后只在那一行里替换；
② 表格行加句：定位行 → 断言以 ` |` 结尾 → 在结尾之前插入。两种都在**改之前**断言命中数恰好 1。

**可复用**：能从 `sed` 输出肉眼复制多行文本，是错觉的来源；**先让程序证明锚点存在，再让它动手**。
另外"一次写一个文件"救了我三次：脚本 abort 时文件是干净的，可以改完锚点重跑，不需要"撤销"。
**同一条纪律的后半段本轮又演了一次**：`r29i.py` 里两条规则命中同一行（一条改行数、一条改文件数），
于是那一行被写成了 `` `wc -l` = `wc -l` = **61,269** 行； 行；`` —— 重复插入而不是替换失败。
教训的形状与前面一致：**一行只归一条规则管**；多条规则可能落到同一行时，合并成一条规则，
或者改完立刻把受影响的那行打印出来看。本轮是靠"改完把 2529-2533 行读一遍"抓到的，门禁抓不到
（它读的是数字对不对，不是句子通不通）。

---

### 4.124 工具链第三次消失；这次 `check.sh` 的报错形态值得抄

**现象**：本轮开工第一条命令就是 `FAIL  cargo not found on PATH`，`ls ~/.cargo/bin` 只剩 `rustup` 一个 shim。
恢复（约 10 秒）：

```text
export RUSTUP_HOME=$HOME/.rustup CARGO_HOME=$HOME/.cargo
chmod +x $HOME/.cargo/bin/rustup
$HOME/.cargo/bin/rustup toolchain install stable --profile minimal --no-update
$HOME/.cargo/bin/rustup component add rustfmt clippy
```

**值得记的不是消失，是报错的形状**：`check.sh` 第一步就叫 toolchain 检查，它**失败并打印恢复命令**，
所以我不需要猜"为什么所有 gate 都绿了但测试数不对"——对比 `§4.100`（空输出不等于通过）。
**环境类前置条件应该做成一个会喊的 gate 步骤，而不是依赖每个命令自己的错误信息。**

---

### 4.125 测不到的守卫必须把规则命名出来，才可能拥有裁判

**现象**：本轮在 `doctor` 的占位行前加了 `&& !truncated`（"答案被截断时不许宣称无事发生"），并写了一条断言
说洪水场景下不该出现那句话。证伪 M9（把 `&& !truncated` 删掉）**不咬**：那条断言通过的理由是
`warnings` 非空 → 占位行本来就不会出现，`truncated` 参与不参与都一样。追下去是结构性的：audit 会把
info 级 finding 聚合成几条汇总行，所以"三层全空 + 被截断"这个组合在 daemon 层**造不出来**。

**处置**：把规则从调用点的 `&&` 提出来，命名成 `paging::may_claim_clean(warnings_empty, errors_empty,
truncated)`，四种组合各一条单元测试；`doctor` 只负责调用。M9 换成改这个函数之后立刻咬住。

**可复用**：**一条规则若在当前数据形状下不可达，它就没有裁判**，无论旁边堆了多少断言。两种出路都比留着强：
改形状让它可达，或者把规则命名成可单独测的函数——**最糟的是留一个"看起来有实现、实际没人判"的守卫**，
因为下一次"顺手简化"会把它当成冗余删掉，而全仓不会红。

---

### 4.126 断言不许写死"哪个界生效"

**现象**：新加的界是"128 行 / 单行 4 KiB / 整层 512 KiB"三个上限，我第一版断言写
`assert_eq!(view.decisions.len(), DIAGNOSTIC_MAX_LINES)`，跑出来是 127 —— 在这个夹具里先咬住的是**字节**预算
（每行被缩短到 ~4 KiB，127 行 ≈ 522 KiB 就顶到预留后的预算）。红的是我的断言，不是实现。

**处置**：改成守恒律 `carried + omitted == decision_count`，加上"答案非空"与"每行 ≤ 单行上限"。
两个界谁先咬是实现细节，守恒律在两种情况下都成立；另外单独造了一个"只有行数咬"的夹具
（200 条短行）去测 `omitted == 72 && shortened == 0`，于是两个界各自有主场。

**可复用**：**写断言时先问"这个数是谁决定的"**——如果被实现细节（哪个分支先命中、字典序、迭代顺序）决定，
就断言那个**不变式**（守恒、有序、互斥），把细节留给专门的夹具去钉。与 `§4.110`（子集断言看不见顺序）、
`§4.122`（组合规则要两个方向）同族。

---

### 4.127 加界类改动必须带一条"没有界就会越界"的对照

**现象**：`without_the_bound_this_answer_would_have_exceeded_the_frame_cap` 是本轮最有价值的一条断言，
因为它量的不是被界的回答，而是**同一份数据在不设界时的大小**（900 条 × ~6 KiB > 4 MiB 帧上限）。
少了它，其余五条在"数据本来就很小时"全部为真 —— 界成了纯粹装饰，而且没人会察觉。

**可复用**：**任何"N 以内"的断言都该配一条"不限制时是 M > N"**。同族的还有 `§4.114`（上限要两侧推）、
`§4.121`（覆盖面要按实现逐个失效）。区别在于这条针对的是**夹具强度**：断言写得对，数据选小了照样空转。

---

### 4.128 新增测试要立刻跑门禁，不能留到收尾：一次 `unused Result` 就是 3 个 clippy 位置

**现象**：本轮新测试引入两条 `unused `Result` that must be used` 警告（`block_on_ready(...).expect(..)`
返回的内层 `Result` 被我丢了）和一条 `assertions_on_constants`（`assert!(JOURNALS > DIAGNOSTIC_MAX_LINES)`
两个都是常数）。`cargo test` 全绿，`check.sh` 却报 **build 不干净 + clippy 35 > 32**。

**处置**：三处都改成正确形状——内层 `Result` 也 `expect`；常数关系改成 `const _: () = assert!(..)`
（这正是本仓早已写死的规矩，clippy 只是把它机器化了）。

**可复用**：**"写完测试"和"跑过门禁"之间不许插入别的活儿**；`assertions_on_constants` 不是风格洁癖，它在提醒
"这条断言在运行期永远不会失败，所以它不是断言而是文档，该写成编译期事实"。`§4.100`（空输出不等于通过）的
另一面：**绿也不等于通过**，要看是哪几个 gate 绿的。

---

### 4.129 上一轮的两处文档改动根本没写进去而门禁全绿；本轮补了一条判据，也补了一条习惯

**现象**：整理本轮文档时发现 `docs/adrs/README.md` 里"第二十九轮"出现 **0** 次、CENTERLINE 也没有第二十九轮
那段；同时 §7 那行被写成"…这 474 个断言是否依然成立**是否依然成立**"。三处同一个原因：第二十九轮的补丁脚本
是"最后一次性写"的写法，中途 `assert` 失败就 abort —— **abort 保护了已写的文件，也静默吞掉了未跑到的文件**，
而我当时只看了"门禁绿"就收工。

**处置**：① 补回两处改动，并把被写坏的那行修好；② 新加门禁 `the_centerline_assertion_count_matches_the_tree`
（判据由 `paging`/`docs.rs::check_round_claim` 计算），它在本轮就抓到了我自己刚写下的 `499`（树里是 501），
也就是说**它上线的第一次工作就是修作者**；③ 习惯上补一条：**脚本 abort 之后必须重跑同一个脚本**（幂等的
assert 会让已应用的部分报 hits=0，据此可判断哪些还没落盘），或者干脆在收尾时按"本轮应该改动的文件清单"逐个
`grep` 关键词，而不是只看门禁颜色。

**与 `§4.105` 的关系**：那条说"改完要重抄数字、并且 grep 住处"。这条是它的执行漏洞：**grep 住处必须在写完之后
做一次，而不是在写之前想清楚**。本轮我在写之前想清楚了 6 个文件，写完之后一个都没复查，于是丢了两个。

---

### 4.130 新加的门禁当天就咬了加它的人；顺带一条关于"断言里引用的文本要复制不要凭记忆"

**现象**：第三十一轮写 `the_document_index_lists_every_top_level_document` 的动机是"新文档必须被索引收录"。
门禁接好之后我写下 `docs/CONTINUATION_PLAYBOOK.md` —— **还没去改 README，门禁当场变红**：
「`docs/CONTINUATION_PLAYBOOK.md` exists but `§1` does not list it」。这是本轮最满意的一刻：一条门禁的
价值就体现在它上线当天拦住作者，而不是写在文档里等人遵守。

同轮另外两处小教训，形状老但每次都新鲜：

- 我给门禁写的单元测试里断言 `"ROADMAP.md, which is not in the tree"`，而实现发出的文本带反引号
  （`` `docs/ROADMAP.md`, which is not in the tree ``）→ 红。**断言里引用的消息文本必须从实现里复制**，
  凭记忆写等于测我自己脑子里的版本（`§4.91` 的同族：断言要参照被检对象的真值，不是参照我对它的印象）。
- 接线时写了 `.then(|| path.file_name()?.to_string_lossy().into_owned())` —— `?` 在返回 `String` 的闭包里
  非法，编译直接拒。这是好事：**build 门禁比我的推理快**。它同时说明"给门禁写实现"和"给门禁写夹具"是两件事，
  夹具的每个 API 用法都会被编译检查，而文档里的说法不会。

**可复用**：新加一条判据之后，**立刻用它检查一次当前状态**（本轮 = 加索引门禁 → 马上加文档 → 看它红）。
一条从没红过的门禁与一条从没被用过的规则等价；本轮的两种红（真缺陷 / 假断言）都比不红有价值。

---

### 4.131 片段替换会把那一行变成重复片段：改一行就重写那一行

**现象**：本轮修 ONBOARDING 里两处手抄数字时，我用「找到含 needle 的行 → 在该行里 `replace(old, new)`」。
有一对的 `old` 与 `new` 共享前缀（`499 → **501** passed` → `499 → 501 → **503** passed`），而那行里
**本来就有同样的子串**，于是替换之后得到 `… 450 → 463 → 434 → 447 → 450 → 463 → 474 …`：片段被复制了一份。
门禁全绿——它们查数字对不对、表格形状对不对，不查同一句是否读两遍。是本轮收尾把整行读出来时看见的。

**处置**：把那两段改成 `lines[i] = new_line` 的**整行重写**；`§4.129` 的"一行只归一条规则"升级成
"**改一行就重写那一行**"。四处例外保留片段替换，且只在能证明 `old` 在该行唯一且不是 `new` 的子串时——
本轮 `docs/ROADMAP.md` 那一行有 4 列，整行重写会吃掉最后一列，所以那里明确用了带 `count == 1` 断言的
子串替换，并把理由写进脚本注释。

**可复用**：文档手术的两个不变动作 ——**改前断言唯一命中，改后把那一行读出来**。这两步比任何正则技巧
都便宜，而本轮已经是第三次因为跳过它们而返工（`§4.89`、`§4.129`、本条）。

---

## 5. 文档导航层面的问题

1. `docs/README.md §2.1` 列了一份 37 篇的必读顺序（本轮补入 `REDACTION_AND_SUPPORT_BUNDLE.md` 后实测：`python3` 数 `### 2.1` 小节内的 `^\d+\. ` 行 = 37；接手时为 36 篇），但没有“30 分钟上手摘要”；
   而读的过程中会发现内容已过期（见 §2）。本文件即为补齐的入口之一。
2. `docs/README.md §3` 的分工表缺 `ERRORS.md` / `EXIT_CODES.md`，且 `STYLEGUIDE.md` 描述重复；
   新增的 `ONBOARDING_NOTES.md` / `DEVELOPMENT_LOG_*.md` 已补入该表。
3. `caly-tui` 出现在“按 crate 分组的真实推进状态”表里但没有 workspace 成员，易被误读为目录已存在。
4. `DependencyEdge{from,to}` 用 `&'static str` 而 `CrateMeta.dependencies` 用 `String`，
   构造 `WorkspaceMeta` 时无法复用常量（小摩擦，本轮用字符串比较绕过）。

---

## 6. 本轮处置结果（可核对）

| # | 改动 | 对应条目 |
|---|---|---|
| 6.1 | `crates/caly-engine/src/executor.rs`：typed `EffectStep` 执行器——阶段分类与单调性门禁、verify-before-commit 门禁、`validate_resume_boundary`、失败后反向补偿、journal 折叠、可注入时钟、`fail_after_step` 崩溃注入；附 7 个单元测试 | 2.3 / 3.6 |
| 6.2 | `apply.rs` 携带 typed `effect_plan`；`worker.rs` apply 走 executor、rollback 真执行补偿并结算 journal；`state.rs` 记录 `last_effect_plan`；`service.rs` 暴露 runtime/policy/journal 写入口 | 2.3 / 2.2 |
| 6.3 | `crates/caly-engine/tests/`：`apply_execution_gate.rs`（EffectStep 全步崩溃矩阵 + LKG 不被污染 + 恢复决策 + 确定性 + 回滚）、`simulated_clock_execution.rs`（时钟注入与 port 级/executor 级注入一致性） | 2.4 / 3.1 |
| 6.4 | `crates/caly-io-sim/tests/simulation_primitives.rs` + 接为 engine 的 dev-dependency | 2.4 / 4.2 / 4.3 |
| 6.5 | `scripts/check.sh`：工具链存在性、0-warning 构建、测试数 > 0、clippy 位置棘轮（33→32）、fmt 报告 | 1.1 / 3.1 / 3.7 |
| 6.6 | `crates/caly-arch-test`：manifest 解析 + 依赖方向/纯核心符号/陈旧允许边/债务棘轮 7 个测试 | 2.5 |
| 6.7 | `crates/caly-daemon/tests/apply_command_path.rs`：envelope→command→job→执行→snapshot、回滚保留快照、越权拒绝、启动恢复 | 2.2 |
| 6.8 | `crates/caly-cap/src/json.rs` + `tests/registry_drift.rs` + 重新生成的两份 JSON | 3.5 |
| 6.9 | 修复 §4.1 / §4.2 / §4.3 三个真实缺陷 | 4 |
| 6.10 | 第二轮：`StorageBackend` 可替换后端 + 换后端跑同一套断言 + `Busy` 失败路径 | 3.4 / 4.5 |
| 6.11 | 第二轮：恢复扫描覆盖 `RecoveryFailed`（`list_unresolved_apply` + `EnterFailedState`） | 4.6 |
| 6.12 | 第二轮：`caly-ipc` 18 个测试（framing / 协商 / 会话状态机 / 流策略）+ `make_header` 饱和化 | 4.7 / 3.1 |
| 6.13 | 第二轮：对上述 §4.8 各条的自我返工 | 4.8 |
| 6.14 | 第三轮：`caly-io-std`（`StdFs` 全 8 法 + `StdClock`）+ `caly-io::contract` 跨后端契约套件；`SimFs` 锁可竞争化；`clippy.toml` 网关豁免；门禁确定性化 + 自我证伪 | 4.9–4.13 |
| 6.15 | 第四轮：`CasWriteIntent` 载荷 + `content_sha256` + `caly-common::digest`（SHA-256，NIST 向量）+ `FsStore` 落盘后端；重启恢复测试同时跑仿真盘与真盘 | 4.14–4.17 |
| 6.16 | `caly_io::block_on_ready` 收敛三处重复的"驱动一次即完成"实现 | 3.3 |
| 6.17 | 第五轮：`ObjectStore::list_objects/delete` + `caly-storage::gc`（root 集、计划、上限、资格门禁）+ 9 条测试 | 4.18 / 4.20 |
| 6.18 | 第五轮：`DaemonApp::try_bootstrap(config, backend)` 注入后端、启动即从盘恢复；修 `active_profile` 回填缺口与 `let _ =` fail-open | 4.19 |
| 6.19 | 第五轮：lifecycle 闸门 —— `Recovering` 只拒 `ProfileApply`（保留 rollback 这条出路）+ 查询不受影响；`Failed` 拒所有命令；修末尾无条件覆盖 lifecycle 的缺陷 | 4.21 / 4.22 |
| 6.20 | 第六轮：`caly-storage/src/schema.rs`（RFC-0007 §12 全部四条 + §12.3 + §15.5）与 13 条测试；为 §3.3 / 端口能力缺口提交 ADR-035、ADR-036（Proposed） | 3.3 / 4.15 / 4.17 / 4.20 |
| 6.21 | 第七轮：`caly-app/tests/contract_gate.rs` 让 contract/parity/scenario 报告第一次被判定；parity 改为共享同一个 daemon | 4.23 / 4.24 |
| 6.22 | 第七轮：`caly-storage::audit`（STORAGE_RECOVERY §9.2 四项全部可实现并有断言）+ `DoctorReport.notes` 第三档 + 类型化 "no such job"；`StorageBackend` 显式 opt-in、新增 `StorageErrorKind::Unsupported` | 4.25 / 4.26 / 4.27 |
| 6.23 | 第八轮：`caly-common::redact`（`Redactor` + `Default/Strict` 两档策略，20 测试）；`ApiError::redacted` 在门面边界生效；`append_job_event` 成为 job 日志的唯一掩码点 | 4.28 |
| 6.24 | 第八轮：`caly-engine::bundle`（10 段导出 + `BundleDraft::finish` 两段式 + CAS 落盘），替换 `DiagnosticsBundle` skeleton；`CommandKind` 侧新增 `put_object/get_object` | 4.29 |
| 6.25 | 第八轮：`ApplyJournalStore::list_apply_journals`（默认 `Unsupported`）+ `bundle::enumeration` 三分法 + `caly-storage/tests/apply_journal_listing.rs` | 4.30 |
| 6.26 | 第八轮：`caly_storage::audit_backend` 抽公共装配 + `StorageAudit::finding_lines`；`doctor` 与 bundle 断言同一行 summary | 4.31 |
| 6.27 | 第八轮：`docs/REDACTION_AND_SUPPORT_BUNDLE.md` 记录规则表、三条出口、`§14` 门禁↔测试映射与两处需确认的解读 | 4.32 / 4.33 / 4.34 |
| 6.28 | 第八轮：复核状态文档自身的断言，改掉三处已过期结论（GC、后端可替换性、成员数），并在文末复跑规模数字 | 4.35 |
| 6.29 | 第八轮：`caly-arch-test::docs` 门禁（表格列数 / 列表连号 / 小节号唯一 / 文档引用的路径必须存在 / crate 名必须是成员或有意的"尚不存在"清单 / **实测数字表由程序复算**），5 条 gate 测试 + 单元测试，跑遍 `docs/**` 全部 Markdown（当时 71 篇，现 72 篇） | 4.34 / 4.35 / 4.36 |
| 6.30 | 第八轮：`caly-storage/tests/apply_journal_listing.rs`（默认 `Unsupported`）与 `StorageAudit::finding_lines`，把 bundle 与 doctor 的审计装配并成一个 `audit_backend` | 4.30 / 4.31 |
| 6.31 | 第九轮：`Ctx` 新增 `idempotency_key`（`ADR-021` 末尾允许的向后兼容扩展）；`RemoteFacade` 停止伪造常量 key，37 处统一走 `send_operation_checked`；`Ctx` 的 deadline / expected_revision / trace_id 在两条路径上一致 | 4.37 / 4.40 |
| 6.32 | 第九轮：`SubmitCommandResponse` 携带引擎的 `Accepted`（影响分类不再被丢弃），`IdempotencyRecord` 记住原始 `Accepted` 并逐字重放；`with_client` 的有损包装被限制在 2 处并计数 | 4.38 / 4.39 |
| 6.33 | 第九轮：`submit_checked` 实现 `expected_revision` CAS（重放优先于 CAS），新错误 `SubmitFailure::StaleRevision` → `CONFLICT/Config/不可重试` + remediation | 4.40 |
| 6.34 | 第九轮：写侧 parity —— `run_write_parity`（四条 case + 两条 CAS 探针 + 信封比对 `parity_of`/`ENVELOPE_PARITY_CASES`）、`crates/caly-app/tests/write_parity.rs` 与 `crates/caly-app/tests/error_identity.rs`、`caly-daemon/tests/cas_and_impact.rs`，并接入 `run_parity_scenarios` | 4.41 / 4.42 |
| 6.35 | 第九轮：`ADR-037`（Proposed）记录 `Idempotency::Required` 与 `Ctx` 缺 role/auth 的两种走法；`scripts/check.sh` 的 clippy 读数改为两遍取最大值（修掉漏计），基线维持 32 | 4.41 / 4.39 / 4.43 / 4.44 |
| 6.36 | 第十轮：`ObjectStore::read_object`（默认 `Unsupported`，读时校验锚点）+ `DiagnosticsOp::ReadSupportBundle`（kind 收窄、`digest: None` 取最新、截断不跳校验）+ `crates/caly-storage/tests/object_contract.rs` 跨后端契约 + `crates/caly-daemon/tests/support_bundle_readback.rs` | 4.45 / 4.46 / 4.47 / 4.48 |
| 6.37 | 第十一轮：`DiagnosticsOp::ReadJobEvents`（Query，两条 façade 都有；复用引擎唯一的事件渲染器）+ `read_job_events` 进入 parity/contract/scenario；`with_client` 从 façade 彻底移除（计数棘轮→断言 0）；`slice_job_events` 的 reset/续读语义补 3 条单元测试 | 4.50 / 4.51 / 4.52 |
| 6.38 | 第十二轮：`ReadJobEvents` 改为有界分页读——`JobEventsRequest`（`max_lines` / `max_bytes`，0 值拒绝、超上限收窄）+ `JobEventsView.next_from_event_index` / `byte_len`、`JobEventWindow.first_index` 成为唯一的"切片起点"、`caly-daemon::paging` 持有默认与上限并给出 `CONFIG_INVALID`；同时补上 scenario 判定者 `every_scenario_suite_row_passes`、删掉三行硬编码 `true` 的遗留场景、harness 保留稳定错误码、部署后发出 runtime-state patch | 4.54 / 4.55 / 4.56 / 4.57 |
| 6.39 | 第十三轮：overload 出口补齐——`processor::submit_command` 先判容量再改状态（拒绝不再推进 generation / 不消耗 job id），`OverloadReport::to_api_error` 成为唯一映射（`error=<class>` / `retry_hint` / `queue_len` / `queue_cap` 进 `detail`，类别进 `diagnostics`，`StorageBusy` 归 `Io`），拒绝记入有界日志并按类别汇总进 `doctor` 与 bundle 新增的 `overload` 段；`crates/caly-daemon/tests/overload.rs`（4 条）+ 引擎单元 3 条 + bundle 1 条 + scenario `overload.*` 5 行 | 4.58 / 4.59 / 4.60 |
| 6.40 | 第十四轮：`ADR-035 / 036 / 037` 三份草案由维护者授权定稿（037 Accepted 并已落地，035 / 036 Accepted 但实现未开始，各自记下定稿偏离）；037 的落地内容 = `required_role` 成为可失败的门禁（两条路径默认 `Operator`，角色由组装根 `set_local_role` 声明）+ `Idempotency::Required` 缺 key 拒绝、空白 key 对任何命令拒绝 + `RequestMapError` 带 kind + 去重窗口只淘汰已完成条目并报告 `evictions` + 本地 `request_id` 单调分配；新增 `crates/caly-daemon/tests/idempotency_and_roles.rs`（7 条）、`crates/caly-engine/src/idempotency.rs`（单元 5 条）、`error_identity.rs` 的 keyless parity（1 条），并把 `§3.3` 的表改成由 `scripts/regenerate_test_census.py` 生成（`--check` 只报不改） | 4.61 / 4.62 / 4.63 / 4.64 / 4.65 |
| 6.41 | 第十五轮：`ADR-035` 第 1 步落地——`caly-io::Fs` 增 `list(dir, ListCap, ctx)`、`Meta` 增 `modified_at_unix_ms: Option<i64>`，两个后端同时实现并跑同一套共享契约（`fs_listing_violations` / `fs_mtime_violations`）；`RFC-0006` 补 `§8.4`（含错误映射表）与 `§15` 第 8 条、`§16` 澄清"冻结的是语义不是签名"；`RFC-0007 §6.4` 冻结 `runtime_path` 的路径基准；仿真侧为此让 `MemFs` 记录被创建过的目录（否则"空目录"与"不存在"无法区分）；门禁新增 `TEST_FLOOR`（见 `§4.66`） | 4.66 / 4.67 |
| 6.42 | 第十六轮：`ADR-035` 第 2 步落地——`caly-storage` 删除 `manifest/*.idx` 清单层，集合枚举（`list_objects` / `list_snapshots` / `list_*_apply` / `open()` 校验）全部改走 `Fs::list`；新增唯一的基准换算点 `fs_store::list_directory`；启动时回收 `StdFs` 的改名残留、把「布局解释不了的文件名」变成拒启理由；回退点从「抄清单」改为「抄记录」，`schema::has_any` 改为真列举且「列举失败 = 有数据」；四类枚举查询不再读进程内缓存；`MAX_ENTRIES_PER_DIRECTORY` 取代清单文件字节上限成为目录预算；新增 5 条断言，9 条变异全部咬住；harness 自身两个缺陷被查出并修掉（恢复要碰 mtime、验证要跑全工作区） | 4.68 / 4.69 / 4.70 / 4.71 |
| 6.43 | 第十七轮：`ADR-035` 第 3 步落地——`FsStore::dated` 用 `Fs::stat` 的 mtime 为对象记录定年，与调用方声明取 `max`（保守方向），`put` / `get` / `list_objects` / 启动填缓存四条路共用它；`RFC-0007 §13.2` 补入"年龄 MUST 优先取端口证据"的规范条文；新增 5 条断言（含真盘 mtime 落在写入窗口内、无时钟不伪造、以及 GC 反事实：只用声明就会被删），6 条变异全部咬住；同时记下两个未修的相邻缺口：`now` 仍由调用方给、GC 整条链无生产调用者 | 4.72 / 4.73 |
| 6.44 | 第十八轮：`ADR-038` 第 1 步落地——`RevisionStore::list_revisions` 补上 `§13.1` 缺的那类 root（默认 `Unsupported` 而非空集）；新增 `SystemOp::GcPlan` 查询与 `GcPlanView`（有界采样、回显边界、`actionable` 分层），root 集不全时 `collect` 被清空而非缩小；`now` 只取注入时钟并检出跨时间线；`required_role` 提到 `handle_request` 使读与流同样受门（命令路径保留自己那一次，因为 `submit_request_as_command` 是公开入口）；`caly-daemon` 新增 `gc_plan.rs`（8 条）、`caly-engine` 新增 `gc_plan.rs`（单元 8 条）、`caly-storage` 新增 `revision_listing.rs`（4 条），11 条变异全部咬住 | 4.74 / 4.75 / 4.76 / 4.77 / 4.78 |
| 6.45 | 第十九轮：`ADR-038` 第 3 步（引擎侧）落地 —— `EngineHandle::set_storage_clock` / `storage_now()`，回收计划优先用注入的端口时钟并在 `now_source` 里报告来源，`doctor` 那行 note 与 `summary_line` 一并带上；`caly-daemon` 只转发（类型走 `caly_engine::Clock` re-export，不动依赖边）；journal 时间戳故意不换（见 `ADR-038 §7` 的两条 `now` 对照表）；新增 4 条断言（引擎单元 1 + `tests/gc_plan_and_clock.rs` 2 + 门面 1），6 条变异全部咬住 | 4.79 / 4.80 |
| 6.46 | 第二十轮：`ADR-038` 第 2 步落地 —— `SystemOp::CollectGarbage`（`Idempotency::Required` + `Role::Admin` + `mutates_revision`，无 `dry_run`）→ `CommandKind::StorageGc` → 任务；周期执行它刚报告的那份清单（`sweep_objects` 从 `run_object_gc` 拆出），root 不全或引擎忙时**什么都不删**并留下 `GcRunRecord`；`StorageBusy` 第一次有生产者（入队前拒绝，`generation` 不推进）；`active_snapshot_id` 从"daemon 传的"改成"提交那一刻由引擎记的"（`§4.81`）；周期不再把自己算作在飞工作（`§4.82`）；越界拒绝新增 `InvalidBounds` kind，remediation 与计数器各归其位（`§4.83`）；新增 10 条断言（引擎 4、门面 6）+ 支持包第 12 段 `storage-gc` + 两条 envelope 比对用例；4 条新留档 | 4.81 / 4.82 / 4.83 |
| 6.47 | 第二十轮补记：证伪 harness 自己误报（把「测试红了」读成「没能编译」），顺带暴露三条缺失断言（记录未写下、资格半边、计数器范围）；判定口径收窄、断言补齐、计数改回实测值 | 4.84 |
| 6.48 | 第二十轮收尾补记：`§4.73` 的账分两轮还完（计划→第十八轮、删除→第二十轮），并说清 `run_object_gc` 仍只被测试调用是**分工**而非遗漏 | 4.85 |
| 6.49 | 第二十一轮：`ADR-036` 第 0 步落地 —— `caly_io::runtime::drive`（`Cancelled` / `Timeout` / `Busy` 三种可区分出路；`block_on_ready` 与 `caly-engine::recovery::run_ready` 都改成它的包装，消掉第三份手写 poll 循环）、`caly_common::CancelToken`（父→子单向派生、默认不取消）、`caly-io-sim` 一次性 `hang(label)` 注入、`RequestEnvelope.io_budget` 与边界透传；`Ctx` 不存绝对 deadline、token 不过线（`§4.86`）；新增 16 条断言（驱动器 6、仿真契约 2、边界 6、上下文 2） | 4.86 / 4.87 |
| 6.50 | 第二十一轮收尾：9 条证伪里两条第一轮没红，追下去是断言不精确（期限未到期、label 不同），补完才全红；顺带发现"谁先回答"根本没定义，测试反过来把设计说清楚了（`§4.88`） | 4.88 |
| 6.51 | 第二十一轮再补：我自己写的 reattach 脚本啃掉了 §4.78 的一句散文（代码片段里的 `| 6.99 |` 撞上它的匹配式），且没有任何判定者报错 —— 脚本已删，散文手工补回（`§4.89`） | 4.89 |
| 6.52 | 第二十一轮再补（收尾）：`check_stray_table_rows` 的判据从「` | ` 分隔个数」改为「不在行内代码段里的 `|` 个数」，并加一条按真实形状（无空格粘连 + 行尾闭合）写的单元测试；顺带把本轮写进文档的四处失准数字改成实测值（`request_map` 单元 4 而非 6、测试数 383→384 与规模行数、`ONBOARDING §4` 条数 89→90、格式化欠账 1,760→1,685），并把 `§4.87` 里「漏了 8 处」改成不自我计数的说法 | 4.90 |
| 6.53 | 第二十二轮：`ADR-036` 第 1 步落地 —— `caly_io::BoundedExecutor`（`submit` 有界准入、满了 `Busy` 且不消耗 `TaskId`；`tick` 每任务每轮 `polls_per_task` 次、提交序即完成序；`run_until_idle` 的 `Advance::{None, StepMillis}` 只调用注入的 `Clock::sleep_until`，`caly-io` 零 clippy 豁免）、`ExecutorMetrics` 四类出路分开计数且相加等于 `submitted`、`runtime::drive_pinned`（`drive` 的循环抽出来复用，所有权原因），端口故障原样交出不重试；新增 13 条单元 + 4 条 `SimFs` 集成断言；`max_tasks` 今天只被测试触到（第 2 步接 `run_ready` 才有生产调用者） | 4.91 / 4.92 / 4.93 |
| 6.54 | 第二十三轮：`ADR-036` 第 2 步落地 —— `caly-engine::run_limits`（`RunLimits::for_command` 把命令的 `Ctx` 换算成 store 访问的限制：相对期限只在有注入时钟时锚定、没有时钟记为 `unjudged` 并如实上报）、`recovery::run_ready_in`（`run_ready` 文案不变）、`StoreRefusal` 把拒绝原因作为**数据**带到 job 结算，`JobOutcome::Cancelled` / `TimedOut` 第一次有生产者；新规则：拒绝只阻止"开始下一步"，`advance_records_touched_world` 为真的写不可拒绝，`finalize` / `mark_apply_reverted` / `mark_apply_recovery_failed` 连 `limits` 参数都没有；新增 15 条断言，14 条证伪变异全咬住（两条是跑完后补的断言缺口） | 4.94 / 4.95 / 4.96 |
| 6.55 | 第二十三轮补记：本轮把上一轮写进 `runtime.rs` 模块文档的一个计数（"23 files, measured"）改成产出它的命令 —— 注释里的数字没有裁判，两轮之间就已经过期；`§3.3` 的 census 之所以可信是因为它有 `--check` 与门禁，同一条纪律应该同样用在代码注释上 | 4.97 |
| 6.56 | 第二十四轮：`ADR-036` 第 3 步落地 —— `IoBudget::default_command()`（64 次计入的 store 访问、不设字节上限）成为 `RequestContext::new` / `caly_api::default_ctx` / `request_map` 回落**共用的同一个常量**；`RunLimits` 计费 + `run_ready_in` 在驱动 future 之前扣，`RefusalKind::BudgetExhausted` → `CONFIG_INVALID` + `retryable=false` + job 结算 `Failed`；只给可被拒的访问计费、「已计费=已尝试」、预算门先于取消/期限，三条规则各有一条断言；`max_bytes` 仍不生效并写进 release note（`IMPLEMENTATION_STATUS §6bis`）与 `§6bis-sexies`；补上第二十一轮欠的 façade 端到端断言；新增 6 条断言，14 条证伪变异全咬住 | 4.98 / 4.99 / 4.100 / 4.101 |
| 6.57 | 第二十五轮：`ADR-038 §13.2` 落地为**默认关闭的自动化任务** —— `AutomationPatch(gc.idle)`（`Role::Admin`）是唯一入口；cadence 按 idle 检查次数计（`IDLE_GC_INTERVAL_CHECKS = 4`，检查点唯一在 `consume_one_skeleton` 的空队列处，所以永不插到调用方之前），计数器只在启用时前进、且**单调不重置**（自动周期的幂等 key 由它派生，重置 = 第二次被 dedup 吞成重放 = 收集器安静停摆）；`tick` 只排队、`cycle` 才删除，二者共用同一条 `would_run` 判定不重算；新增 `GcRunRecord::triggered_by` 并把它写进 `summary_line`，同时给无生产者的孪生 DTO `GcRunView` 补上同字段 + 一条「两句话必须相同」的断言（`§4.102`）；`ADR-038` 四步全部落地 | 4.102 / 4.103 / 4.104 |
| 6.58 | 第二十六轮：`ADR-036 §2.5` 的探针时限落地 —— `StepEvidence::elapsed_ms`（**运行时报告、执行器判定**，于是每个适配器都没有「忘记检查」的余地）、超限走既有验证失败分支（`probe_passed` 保持假 ⇒ 快照不标、修订不提交）、`elapsed <= deadline` 的边界、合并证据取 max、`deadline_ms == 0` 在计划校验阶段拒且不受 `enforce_phase_order` 影响；同轮把 `caly_api::GcRunView` 接上生产者（`system.gc-plan` 带 `last_run`，逐字段映射 + 两个渲染器同一句话）；`ADR-036 §1` 表里五个「没人读」的字段只剩字节预算一项；本轮另有一课：给 DTO 加字段把两个没碰过的 `caly-ipc` 枚举顶过 clippy 阈值，处置是 `Option<Box<…>>`（见 `§4.106`）| 4.105 / 4.106 |
| 6.59 | 第二十七轮：`APPLY_EXECUTION_CENTERLINE §6.1` Phase B 的 pending guard 接进生产路径 —— `EffectCursor`（**执行这一步之前**先把意图写进 journal，写不成就 refuse 这一步，`needs_intent_record` 只管 Cutover 窗口并带编译期锚）、`JournalIntentCursor`（链住自己的 journal 副本，所以第一条记录之后 `advance_records_touched_world` 如实转假）、`CursorRefusal` 把拒绝原因当数据带回来（job 因此能结算成 `Cancelled` / `TimedOut` 而不是笼统 `Failed`）、`settle_for_refusal` / `public_shape_for_refusal` 两张表两个接缝共用、`StorageErrorKind::Busy` 是唯一被升级的 store 答案（`RefusalKind::StorageBusy`）并据此写 `doctor` 读的过载行（`OverloadReport::journal_pressure` + `OverloadReport::detail`，一处拼写两处出口）；同一轮把 `run_apply` 改成"一份命令一个预算计数器"（`§4.109`），并更正第 23 轮那句不实的接线（`§4.108`）与满仓的 `§6.2` 错引（`§4.107`）；新增 13 条断言（`cutover_intent_guard.rs` 11 条 + `run_limits` 1 条 + `dependency_direction` 门禁 1 条；`cargo test --workspace` 450 → **463**，门禁自报 `463 tests passed (floor 463)`），13 条证伪变异全咬住（M7 的第一版因不编译而作废重跑，见 `§4.112`）；收尾时又栽一次：为取一个 target 数而 `touch` 全仓，把「本轮改了什么」的最后一个信号弄丢了（`§4.113`） | 4.107 / 4.108 / 4.109 / 4.110 / 4.111 / 4.112 / 4.113 |
| 6.60 | 第二十八轮：`ADR-036 §2.6` 前半落地 —— `crates/caly-storage/src/port_drive.rs` 用**唯一的** poll 循环（`caly_io::drive`）有界驱动端口（`STORE_PORT_POLL_BUDGET = 64`，两条编译期锚点 `> 0` 与 `>= 2`，后者专门拦"把上限写成 1"），超预算把驱动器自己的 `Busy` 经**同一张** `from_iofault` 表报上去；把 `Busy` 改写成 `Internal` 的那 3 行 `suspension()` 删除，`fs_store.rs` 8 处 + `schema.rs` 4 处全走 `drive_port`；`caly-io-sim` 新增 `stall(label, polls)`（一次性、可数的挂起），于是"上限"第一次能从**两侧**量（`SimFs::write_atomic` 从此也认 `hang`/`stall`）；新门禁 `the_durable_store_drives_ports_through_the_shared_budget`（唯一豁免 `audit.rs` 并写明理由，附"扫到文件数 ≥ 8"的反空转断言）；11 条证伪变异全咬住（主线 9 条，其中 M5 只有门禁能抓；给相邻性检查另加 2 条）；`cargo test --workspace` 463 → 474（两次改数都以 census 与门禁的自报值为准：第一次算成 472，第二次是补完门禁测试之后重问的）；本轮还把它暴露的门禁空隙补上了 —— `check_disposition_ledger` 从此也查**相邻性**：处置表行之间隔一个空行就等于表格到此为止，编号检查看不出来，现在多一条单元测试钉住 | 4.114 / 4.115 / 4.116 / 4.117 / 4.118 / 4.119 |
| 6.61 | 第二十九轮：`ADR-036 §1` 表里最后一行接上 —— `caly_io::budget` 把 `RFC-0006 §5.3` 的字节上限交给**端口自己**：`byte_ceiling`（读侧取更紧的一条，宽松的那条**不得放大**调用自带的 cap）与 `check_payload`（写侧在**任何字节落地之前**拒），`StdFs` 与 `SimFs` 调同一份实现；`fs_byte_budget_violations` 在两个后端上跑同一组断言（含"被拒之后 `stat` 必须说没有这个文件"与"精确等于上限放行"）；引擎把端口的 `CapacityExceeded` 认成新的 `RefusalKind::PayloadTooBig`（`CONFIG_INVALID` + `User` + `retryable=false`，remediation 指向 `max_bytes`），与 `BudgetExhausted` 分开是因为旋钮不同，`remediation` 本轮并进 `public_shape_for_refusal` 那张共用表；新门禁要求"跑了 fs 套件的后端必须也跑新的字节检查"，门禁自己带一条"应找到 2 个后端"的断言；`§2.4` 的"累加字节数"**没有**照做，偏离与结构原因记在 `ADR-036 §6bis-decies`；新增 11 条断言（474 → 485），10 条证伪变异全咬住（4 条按后端分开、1 条只有门禁能抓） | 4.120 / 4.121 / 4.122 / 4.123 / 4.124 |
| 6.62 | 第三十轮：`OVERLOAD §5.1` 的 Query 那一格判完并落地 —— `RFC-0002 §11.4` 在 daemon 侧第一次有承载体： `caly-daemon/src/paging.rs` 的 `DiagnosticBudget`（128 行 / 单行 4 KiB / 整层 512 KiB，其中 1 KiB 是留给截断 说明自己的**预留**——"我截断了"那句不许把自己顶出预算）管住两条由 store 决定大小的诊断查询 （`diagnostics.doctor` / `diagnostics.recovery-status`）；上界按**来源**施加而不是按组装好的答案施加， 所以洪水挤不掉 daemon 自己要说的三句（recovery 计数、idempotency 窗口、gc 计划与上一轮周期）； 截断被写进答案本身（`truncated` + `omitted_*` + 落在被截那一层的说明行），`decision_count` 与 summary 里的总数 保持真实值，未截断时占位行照旧、被截断时"no findings requiring action"必须闭嘴； `&& !truncated` 那条守卫在 daemon 层造不出可达用例，于是规则被命名成 `may_claim_clean` 单独测四种组合 （`§4.125`）；新增门禁 `the_centerline_assertion_count_matches_the_tree`，它上线当轮就抓到作者写的 499 （树里 501，`§4.129`）；`cargo test --workspace` 485 → 501，11 条证伪变异全咬住（M9 第一版不咬，命名之后才咬） | 4.125 / 4.126 / 4.127 / 4.128 / 4.129 |
| 6.63 | 第三十一轮：本轮不新增功能，做两件"让经验不再只活在人脑里"的事 —— ① 新增 `docs/CONTINUATION_PLAYBOOK.md`：八步每轮流程、不可协商边界、数字纪律（11 次犯错的形状）、断言/门禁纪律、证伪 harness 规程、文档手术规程、**现有门禁清单**（每条写明它判什么与它的失效形状）、环境与工具链恢复、"怎么挑下一件事"（阻塞点梯 + 需要决策 vs 需要写代码）、缺口三个登记处的分工、收尾清单；② `ROADMAP` 加 `§1bis` 按阶段量的完成度（每条附产出命令），并修掉一行过时结论（原写"ADR-035/036 两份 Proposed 待确认"，实测 28 个 Accepted / 0 Proposed）；③ 新门禁 `the_document_index_lists_every_top_level_document`（README §1 目录树 ↔ `docs/*.md` 双向一致 + "至少 30 篇"反空转），它上线当天就咬住作者新加的这份文档（`§4.130`）；`cargo test --workspace` 501 → 504（三次以裁判自报值重抄，最后一次是加完门禁测试之后再问一次普查） | 4.130 / 4.131 |


**门禁结果**（第三十轮实测）：`cargo check --workspace --all-targets` 0 warning；
`cargo test --workspace`：47 → 81 → 95 → 129 → 144 → 157 → 168 → 213 → 231 → 251 → 265 → 274 → 290 →
298 → 310 → 313 → 321 → 326 → 331 → 353 → 357 → 366 → 367 → 383 → 384 → 401 → 416 → 422 → 433 → 434 → 447 → 450 → 463 → 474 → 485 → 499 → 501 → **504** passed（**84** 个 test
target（64 个可执行 + 20 个 doc-test，`cargo test --workspace --no-run` 自报 `Executable unittests` 20 行 +
`Executable tests/` 44 行），各轮均 0 failed；第十五轮起门禁另有 `TEST_FLOOR`，第二十七轮抬到 463、
第二十八轮抬到 474、第二十九轮抬到 485、第三十轮抬到 501、第三十一轮抬到 504——低于下限即红；这一串里每一格
不是加法（`§4.117`），而 462 那一格本轮被删掉是因为它从没被改到（`§4.119`））；clippy 位置数 33 → 32（第八轮 8 处自造
lint 全改代码修掉；第十一轮漂到 33、第十三轮漂到 34、第十四轮漂到 33、第十五轮漂到 37、第十六轮漂到 33，
每次都
是自己的写法问题（`items_after_test_module`、`assertions_on_constants`、`result_large_err`、
`doc_lazy_continuation`、`doc_overindented_list_items`、`needless_borrow`、`unused_variable`、
`redundant_closure`）——
改的都是代码而不是基线，见 `§4.44` 同源教训；第十四轮还把**判定本身**从管道里搬了出来，
因为 `pipefail` 与 `grep -q` 会竞态（`§4.65`））；
`scripts/check.sh` → all gates passed。格式化欠账 5,476 → 5,300 → 2,785 → 2,168 → 2,089 → 1,847 → 1,774 →
1,760 → **1,685** 行（口径 = 门禁所用的 `cargo fmt --all -- --check` **输出行数**；第二十二到三十轮重跑均为 1,685（本轮一度 1,761，原因还是 `§4.116` 那条：格式化必须排在最后一次写之后） ——
本轮一度是 1,696，原因是先 `rustfmt` 之后又用 python 删了一个 unused import 却没再格式化一遍（`§4.116`）。
另一个常见误读：`grep '^Diff in' | wc -l` 数的是 hunk 数（本轮同一状态是 122），不是这个口径（`§4.118`）。第十六轮
新增的存储层与测试代码一度把欠账顶到 1,853，`rustfmt --edition 2021` 只跑本轮触碰的文件后回落 —— 只格式化
自己碰过的文件是既定策略（仓库级 rustfmt 单列一轮，见 `IMPLEMENTATION_STATUS §8.6`），所以这串数字每轮只会降。

规模（第三十一轮实测，每条附上产出它的命令）：`find crates -name '*.rs' | wc -l` = **219**；全部 `.rs` 喂给
`wc -l` = **62,374** 行；`python3 scripts/regenerate_test_census.py` 自报 `files=65 total=504 rows=65`；
门禁自报 `504 tests passed (floor 504)`；成员 20；`find crates/*/tests -maxdepth 1 -name '*.rs' | wc -l` = **44**
个集成测试文件，加 20 个单测目标 = 64 个可执行，再加 20 个 doc-test 目标 = **84** 个 test target；
`find docs -name '*.md' | wc -l` = **74** 篇（第三十一轮新增一篇 `CONTINUATION_PLAYBOOK.md`，其余改动仍落在既有文件里，
所以「留档」到第 131 条；而新增那篇必须写进 `docs/README.md §1`，由本轮加的门禁 `the_document_index_lists_every_top_level_document` 守着）。

§4 由 106 → **131**（`§4.107`–`§4.113` → `| 6.59 |`、`§4.114`–`§4.119` → `| 6.60 |`、`§4.120`–`§4.124` → `| 6.61 |`、`§4.125`–`§4.129` → `| 6.62 |`、`§4.130`–`§4.131` → `| 6.63 |`）。第三十一轮的两条留档记在 `| 6.63 |` 那一行里（一行对一轮，条目对条目）——上一轮我把处置表写成多行，`check_disposition_ledger` 用「行必须以 `|` 收尾」把那个形状也管起来了。
（一行对一轮，条目对条目），`### 6.59 明确不做` 让位 `### 6.60` —— 这一步不再是我手工核对的：
上一轮加的 `check_disposition_ledger` 会在编号接不上时直接变红，本轮它是绿的，而它的存在就是这两处
（表行与收尾标题）不再可能各说各话的原因 —— 本轮它就咬了我一次：加了第 7 条留档却没加处置表行，我却顺手把收尾标题又推了一格，门禁当场报「标题必须正好是最后一行 +1」。**标题跟着表行走，不跟着 §4 的条数走**。第二十六轮的账：那条「先数住处」的规矩又抓到三句过期话（`§4.101` 的补记），而同一轮我自己犯了`§4.105` 记的两件事 —— 说了没做的 edit，和自算的合计。按 `§4.101` 的规矩，本轮动手前先 `grep -rn "ADR-038" docs/` 数了一遍住处，结果又抓到三句上一轮之后就该改而没人改的话（见 `§4.101` 的补记）—— **那条规矩不是仪式，它本轮直接命中了三次。**
上一段这种"数字后面跟着命令"的写法是 `§4.87` 的直接后果：能被复算的数才算数，不能复算的就别写。

clippy 基线仍是 32 处（第二十二轮那 5 条告警全部改代码修掉：`redundant_pattern_matching` 1、`explicit_auto_deref` 2、
`dead_code` 1 —— 最后那条值得单记，见 `§4.92`）。**没有动过 `CLIPPY_BASELINE`，也没有加过一处 `#[allow]`。**

第二十三轮漂到 33 一次，门禁当场报 `clippy locations grew: 33 > baseline 32`：新加的是测试里一处
`map_err(|text| text)`（`unnecessary_map`）。改代码后回到 32。上面那份 lint 名单因此再加两个名字：
`unnecessary_map`、`dead_code`（`§4.92`）。顺带一条本轮的教训：告警清单里有 23 条 `result_large_err`
是既有的（`ApiError` 本来就 128 字节起），我一度以为自己也新增了其中一条并准备去缩 `StoreRefusal`——
**先数出真正的增量再看要不要动手**，`--message-format short` 加一次 `sort -u` 就够了（本轮就是这么定位到
唯一那条新告警的）。

> 本轮起 `§3.3` 的实测表由 `scripts/regenerate_test_census.py` 生成，`--check` 只报不改；门禁那条
> `status_table_test_counts_match_the_tree` 仍是唯一的裁判。上一轮我数出来的 45,839 / 290 等数字，是
> 用一次性脚本临时算的 —— 那一轮之后 `/tmp` 被清，脚本就没了，这正是把它收进 `scripts/` 的理由。

### 6.64 明确**不做**的项（避免范围漂移，留档理由）

| 项 | 为什么本轮不做 |
|---|---|
| 引入 tokio / serde 等外部 crate | 与 1.4 冲突，属独立决策，需要 ADR |
| 用真 executor 替换 `run_ready` | 同上；先把不变量写清楚，不偷偷改语义 |
| `EngineHandle` 改 `dyn StorageBackend` | 牵动 daemon/app/parity 全链，单列一轮（3.4） |
| 把 capability 执行路径改成“读 JSON 文件” | 需先定义加载失败/首启动语义；本轮先让漂移可见（3.5） |
| 全仓 `cargo fmt` | 7.7k 行噪声 diff 会淹没功能改动，独立提交（3.7） |
| 新增 `[[bin]]` / TUI | 不改变中心线正确性（3.2），优先级低于门禁 —— 第二十七轮补：本轮之后它也开始挡别的事（`clock-timeline` 的注入者、`caly doctor --io` 的实际读者），但仍需要一个 bin 边界的决策，不属于某一轮顺手加 |
| 消除 `engine -> 具体 adapter` 依赖 | 需要 adapter registry/factory 设计，已用 `KNOWN_ARCH_DEBT` 显式钉住 |
| 真实 core 集成（下载/spawn/runtime API） | 属 Phase 8，需要平台与权限决策 |
| 让 `Idempotency::Required` 真正拒绝无 key 的命令 | 会立刻打断 CLI/TUI 与全部本地调用；语义本身待 `ADR-037` 决策 |
| 把 `role` 放进 `Ctx` | `Ctx` 同时是 `IoContext`（端口层别名），把门面角色塞进去等于让 port 看见 CLI 概念；`ADR-037` 给了另一条（envelope 侧 `AuthContext`） |
| 给 `deadline_ms` 找执行者 | 现在两条路径都把它写进 envelope 而无人据此取消；取消语义属 `ADR-036` 的执行器决策 |
| bundle 写到用户指定路径 | 需要平台/导出位置决策，`ADR-011` 下 daemon 无平台层；本轮只做 CAS + 摘要上报 |
| GC 为 bundle 开根 | 导出物不该永久占盘；`§13` 的 grace period 即其生命周期（`REDACTION_AND_SUPPORT_BUNDLE §4.2`） |
| 给 `LogLine` 造一个新类型来承载脱敏 | `RFC-0010 §6.1` 要的是"构造时掩"这一职责，`JobEvent` 已是本仓的日志行；再加一层只多一个漏点 |

---

## 7. 一句话给下一个接手者

> 这个仓库的文档写得比代码好，但也**比代码旧**：先跑 `scripts/check.sh`，
> 再用 grep 确认文档说法，最后才动手——`§4` 里三个缺陷都是“看起来没问题、写断言才炸”的东西。
