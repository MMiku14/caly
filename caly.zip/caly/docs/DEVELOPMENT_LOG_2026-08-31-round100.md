# 开发日志 — 第一百轮（R100）

- **日期**：2026-08-31
- **一句话**：把守护进程 `calyd` 交给 **systemd** 托管——交付 `packaging/systemd/calyd.service` + 部署 runbook + **ADR-055**，钉死「systemd 监督 calyd 进程、calyd 继续监督代理 Core 子进程」的两层边界；不改 Rust、不改 wire、无新依赖，测试数 856 持平。
- **性质**：运维提议驱动的**部署工件 + 文档 + ADR** 轮（不是行为/协议轮，无新断言、census 不动）。

---

## 1. 缘起与量选

运维视角：「守护进程不如直接用 systemctl 托管」。按权威序（RFC > ADR > 文档 > 代码）先深读，不臆动：

- `RFC-0005`：§3 参与者里 **Supervisor** 管 Core 进程生命周期；§11 Core Supervisor 边界（子进程启停/重载、stdout 采集、异常退出分类、orphan 清理；Coordinator 管「何时部署/回滚」，二者 **MUST 分离**）；§12 崩溃恢复（daemon 启动 MUST 先进恢复检查：孤儿 Core、proxy/DNS/TUN 修复、按 pid+start_time+instance_nonce 校验、收敛 LKG/干净 Failed）。
- `ADR-042`（进程 spawn 网关）、`ADR-043`（Proc 最小监督面 `try_wait/stop`，std 无 TERM 面显式推迟）、`ADR-050`（real effect runtime 显式组合根，默认 simulated fail-safe）。
- 代码核实：calyd 是**纯前台进程**——全仓 grep 不到 daemonize/double-fork/`setsid`/pidfile/服务自安装；`main` 直接 `BindSpec::parse(&bind)` + `WireListener::bind` + accept 循环；日志走 `eprintln!`（stdout/stderr）；`--bind` 支持 TCP 与 `unix:/path`（`caly-ipc::BindSpec`）；自身无 SIGTERM 处理。

**结论**：方向正确（RFC-0005 §12 的崩溃恢复本就假定 daemon 会被外部重启，systemd 即那个监督器），但存在**两层监督**，边界必须钉死，否则有人会把 mihomo/sing-box 也做成独立 unit 而切断 apply 事务。

## 2. 两层监督边界（ADR-055 决策核心）

```text
systemd (PID 1 / init)
   │  监督：calyd 进程存活、开机自启、崩溃重启(Restart=on-failure)、stdout→journald
   │  手段：Type=simple；不 socket activation、不 Type=notify
   ▼
calyd（前台进程，不自我守护）
   │  监督：mihomo/sing-box 子进程
   │  手段：Core Supervisor + Proc::try_wait/stop（ADR-042/043）
   │  耦合：apply 事务、Health Probe、rollback/补偿、orphan 收割
   ▼
mihomo / sing-box（calyd spawn 的子进程，不是独立服务）
```

- **外包给 init 的**（A 层）：进程活没活、开机起没起、日志去哪、崩溃后谁拉起。
- **绝不外包的**（B 层）：Core 子进程属于**哪一次部署事务**——Health Probe（spawn 成功≠配置合法）、失败部署要 stop 掉刚拉起的坏核心、rollback 换核心。init 只看「进程活着」，看不到这些；把 Core 做成独立 systemd unit 违反 `RFC-0005 §11.2`。
- **关停**：systemd stop 发 SIGTERM；calyd 不拦截（ADR-043 §2.5 std 无 TERM 面）。语义仍正确——calyd 死后**下次启动崩溃恢复**接管/清理孤儿 Core、修复 proxy/DNS、收敛状态。未来 SIGTERM 优雅 shutdown 属 ADR-043 预告的信号端口生长，另立 ADR。

## 3. 落地工件

| 文件 | 内容 |
|---|---|
| `packaging/systemd/calyd.service` | `Type=simple`、`Restart=on-failure`(RestartSec=2s、StartLimit 5/60s)、`StateDirectory=calyd`(/var/lib/calyd)、`RuntimeDirectory=calyd`(/run/calyd)、`--bind unix:/run/calyd/calyd.sock`（UDS 无 TCP 端口、文件权限控访问）、`--effect-runtime real --runtime-root /var/lib/calyd/core --assets-dir /usr/lib/calyd/assets`（real 显式 opt-in）、`TimeoutStopSec=15`、`KillSignal=SIGTERM`、安全子集（PrivateTmp/ProtectSystem=full/ProtectHome）、当前 `User=root`（待 Privilege Helper 降权） |
| `docs/DEPLOYMENT_SYSTEMD.md` | 监督模型图、文件/资产布局（ADR-050 §2.2 固定资产布局）、安装启用、UDS 连接（`caly status --addr unix:/run/calyd/calyd.sock`）、journald 日志、simulated 覆盖变体（`systemctl edit` 清空 ExecStart）、关停/崩溃恢复语义、权限加固、非 Linux（launchd/SCM/容器同原则；容器勿把 Core 拆 sidecar）、排障表 |
| `docs/adrs/ADR-055-external-init-supervises-calyd-two-layer-supervision.md` | Status Accepted；Context（两层现状，代码核实）、Decision（两层边界 + 关停语义）、Alternatives（A 自我守护=反 12-factor；B 核心独立 unit=切 apply 事务；C supervisord/容器=同原则异工件）、Consequences、Compatibility（不破坏兼容/不改 wire/无迁移/测试照旧 spawn） |

README 登记：`DEPLOYMENT_SYSTEMD.md` 进 §1 目录树 + §信息表一行（ADR 在 `adrs/` 子目录，不进顶层树，符合 R31 门禁只扫顶层）。

## 4. 校验（本轮无新 Rust 断言）

- 文档门禁 `doc_consistency` 7/7 全绿：
  - `every_documented_path_reference_resolves`：runbook 引用的 `../packaging/systemd/calyd.service` 与 ADR 文件**真实存在**（gate 校验路径，故 .service 必须落成真文件而非文档里画饼）；
  - `the_document_index_lists_every_top_level_document`：新顶层 doc 已登记 README；
  - `doc_tables_and_lists_are_well_formed`、crate 名、census/centerline 计数（856 持平）全过。
- unit 里每个 flag 经 grep 核对为 calyd/caly 真实支持（`--bind/--data-dir/--effect-runtime/--runtime-root/--assets-dir`；`--addr` 属 CLI）。
- `check.sh` 全绿：856 tests / floor 856 / clippy 31 / fmt clean（无 Rust 改动，计数不变）。

## 5. 留档规则（本轮学到的）

1. **运维/部署提议先过权威序**：「换个东西托管」表面是运维选择，实则顶到既有 ADR（ADR-042/043 子进程监督契约）。不读 RFC-0005 §11/§12 就动手，极易把 Core 也做成 systemd unit，切断 apply 事务。
2. **两层监督判据**：init 管「进程活着/开机起/日志去哪」，应用内 supervisor 管「这个子进程属于哪次事务、该不该换/停/回滚」。前者可外包，后者绝不能。
3. **崩溃恢复设计是监督模型的反证**：一个启动即做 orphan 接管 + 状态收敛的 daemon，天然假设有外部重启者——这是「该接 systemd、不要自我 daemonize」的信号。
4. **文档/部署轮的纪律**：即使不改 Rust，也要一篇 ADR 钉边界 + runbook + README 索引登记；文档门禁会强制「引用的路径真实存在」与「顶层 doc 进索引」。这类轮不加测试断言、census 数字持平。

## 6. 环境插曲

本轮工作区工具链被重置（`~/.cargo/bin/rustup` 丢执行位、`~/.rustup` 工具链目录消失）。恢复：`chmod +x ~/.cargo/bin/rustup` → `rustup default stable`（拉回 rustc/cargo 1.98.0，与基线同版）；cargo shim 未建到 `~/.cargo/bin`，改用工具链 bin 直路径 `~/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/bin` 进 PATH。

## 7. 明确没做（后续工件）

- macOS launchd plist / Windows SCM（NSSM）/ Docker 镜像：同一分层原则的其它监督器实例化。
- 可安装打包（`.deb` / `make install`：装二进制 + assets + `caly` 用户 + enable unit）。
- calyd 的 SIGTERM 优雅关停面（ADR-043 预告的信号端口生长）：让 `systemctl stop` 先优雅 shutdown Core 再退，缩短恢复周期。
- Privilege Helper 降权（`RFC-0005 §13`）：让 unit 可去 root / 最小 capabilities。

各需独立切片；其中 SIGTERM 面与 Privilege Helper 涉及 Rust + ADR。
