# 部署 `calyd` 到 systemd（Linux）

本文说明如何用 **systemd** 托管 Caly 控制面守护进程 `calyd`。监督边界与依据见
[`docs/adrs/ADR-055-external-init-supervises-calyd-two-layer-supervision.md`](adrs/ADR-055-external-init-supervises-calyd-two-layer-supervision.md)。

> **两层监督，别混**：systemd 监督 **`calyd` 进程**（开机自启、崩溃重启、日志）；
> `calyd` 自己继续监督代理核心 **mihomo/sing-box 子进程**。**不要**把 mihomo/sing-box
> 也做成独立 systemd unit——它们的生命周期耦合在每一次 apply 部署事务里（健康探测、
> 回滚、补偿），init 系统看不到这些边界（`RFC-0005 §11.2`）。

---

## 1. 监督模型

```text
systemd (PID 1)
   │  自启 / 崩溃重启(Restart=on-failure) / stdout→journald
   ▼
calyd（前台进程，不自我守护；Type=simple）
   │  Core Supervisor + Proc 端口 try_wait/stop（ADR-042/043）
   ▼
mihomo / sing-box（calyd spawn 的子进程，不是独立服务）
```

`calyd` 是纯前台进程：不 fork、不写 pidfile、不自装服务，日志走 stdout/stderr。
它启动时**先做崩溃恢复**（`RFC-0005 §12`：接管/清理孤儿核心、修复 system proxy/DNS、
收敛到 Last-Known-Good 或干净 Failed）——所以被 systemd 重启是安全的、是设计内路径。

---

## 2. 先决条件：文件布局

服务单元假设以下布局（可按需调整 `ExecStart`）：

```text
/usr/bin/calyd                     # daemon 二进制
/usr/bin/caly                      # CLI 二进制（可选，同机管理用）
/usr/lib/calyd/assets/cores/...    # mihomo / sing-box 资产（见 ADR-050 §2.2 固定布局）
/usr/lib/calyd/assets/geo/...      # geoip.metadb / geosite.dat
/var/lib/calyd/                    # StateDirectory（systemd 自动创建，持久状态）
/run/calyd/calyd.sock              # UDS 监听点（RuntimeDirectory，tmpfs，重启清空）
```

资产固定布局（`--assets-dir` 指向的目录）：

```text
<assets-dir>/cores/mihomo-linux-amd64-v1.19.30.gz
<assets-dir>/cores/sing-box-1.13.20-linux-amd64.tar.gz
<assets-dir>/geo/geoip.metadb
<assets-dir>/geo/geosite.dat
```

> 真实 spawn 时 calyd 会对**将要部署的完整 bytes**算 sha256 并与计划 digest 比对
> （`RFC-0010 §14` 下载校验 + ADR-050）。资产只放文件、digest 在 spawn 时复核。

---

## 3. 安装与启用

单元文件：[`packaging/systemd/calyd.service`](../packaging/systemd/calyd.service)。

```bash
# 1. 安装二进制与资产（打包/deb 会自动做；手工部署时）
sudo install -m 0755 target/release/calyd /usr/bin/calyd
sudo install -m 0755 target/release/caly  /usr/bin/caly
sudo mkdir -p /usr/lib/calyd/assets/cores /usr/lib/calyd/assets/geo
sudo cp <assets>/cores/* /usr/lib/calyd/assets/cores/
sudo cp <assets>/geo/*   /usr/lib/calyd/assets/geo/

# 2. 安装单元
sudo install -m 0644 packaging/systemd/calyd.service /etc/systemd/system/calyd.service

# 3. 重载、开机自启并立即启动
sudo systemctl daemon-reload
sudo systemctl enable --now calyd.service

# 4. 查看状态
systemctl status calyd.service
```

---

## 4. 连接 CLI（UDS）

单元默认让 daemon 监听 Unix 域套接字（无 TCP 端口、靠文件权限访问控制）：

```bash
sudo caly status --addr unix:/run/calyd/calyd.sock
sudo caly doctor --addr unix:/run/calyd/calyd.sock
```

> 想用 TCP loopback 代替 UDS：把 `ExecStart` 的 `--bind unix:/run/calyd/calyd.sock`
> 改成 `--bind 127.0.0.1:<port>`，CLI 用 `--addr 127.0.0.1:<port>`。TCP 会暴露一个
> 本机端口；UDS + 文件权限是更小的攻击面。

---

## 5. 日志

前台进程的 stdout/stderr 由 systemd 收进 journald：

```bash
journalctl -u calyd.service -f          # 跟踪
journalctl -u calyd.service --since "10 min ago"
systemctl status calyd.service          # 最近若干行 + 监督状态
```

daemon 启动行会打印监听点与 effect-runtime：
`calyd: listening on unix:/run/calyd/calyd.sock (data: ..., effect-runtime: real)`。

---

## 6. simulated 变体（本地 / CI / 演练）

仓库默认 `--effect-runtime simulated`（ADR-050：裸 `calyd` 绝不触碰宿主机）。生产单元
显式写了 `real`；本地/CI 演练用 simulated 覆盖单元：

```bash
sudo systemctl edit calyd.service
```

```ini
[Service]
ExecStart=
ExecStart=/usr/bin/calyd --bind unix:/run/calyd/calyd.sock --data-dir /var/lib/calyd/data --effect-runtime simulated
```

simulated 模式**不得**带 `--runtime-root`/`--assets-dir`（带了会被按名拒绝，
ADR-050 §2.1），也不需要资产/特权。

---

## 7. 停止 / 重启语义

- `systemctl restart calyd`：发 SIGTERM。calyd 当前**不拦截** SIGTERM（std 标准库面
  无 TERM，ADR-043 §2.5 显式推迟），因此停止走「kill → 下次启动崩溃恢复」：下一次
  启动会接管/清理孤儿核心、修复 proxy/DNS、收敛状态。`TimeoutStopSec=15s` 后 SIGKILL。
- 崩溃后 `Restart=on-failure`（`RestartSec=2s`，`StartLimitBurst=5/60s`）自动拉起，
  每次拉起都先跑 §12 恢复。
- 未来让 calyd 在 SIGTERM 上主动优雅 shutdown Core，属 ADR-043 预告的「带信号面的
  端口生长」，需另立 ADR。

---

## 8. 权限与加固

real 模式要改 system proxy / DNS / TUN，当前单元以 `root` 运行（`User=root`）。
更长期的降权路径是 Privilege Helper（`RFC-0005 §13`：最小化长期高权限进程），
本轮未实现 helper。单元已带一组安全子集（`PrivateTmp`、`ProtectSystem=full`、
`ProtectHome=true`）；进一步收紧（专用 `User=caly` + 仅授予所需 capabilities）
需要 helper 落地后再开，否则 TUN/proxy 副作用会失败。

---

## 9. 非 Linux 平台

systemd 单元只覆盖 Linux。监督**原则**相同（外部 init 监督 calyd，calyd 监督 Core），
但监督器实例不同，本轮不提供对应工件：

- **macOS**：launchd（`~/Library/LaunchDaemons` plist，`KeepAlive=true` 对应
  `Restart=on-failure`，UDS 放 `/var/run` 或 `~/Library/...`）。
- **Windows**：SCM 服务 / NSSM；注意 named pipes 是本主机 v0 不支持的传输
  （`BindSpec` 明确拒绝 npipe，用 TCP loopback）。
- **容器 / 编排**：同一原则——容器前台跑 calyd（PID 1 或 tini），探针/重启策略交给
  编排器；不要把 Core 拆成 sidecar 由编排器重启（理由同 §1，会切断 apply 事务）。

---

## 10. 排障速查

| 现象 | 排查 |
|---|---|
| 启动即退出、status 显示 usage | real 模式缺 `--runtime-root`/`--assets-dir`，或 simulated 误带了这两个 flag（ADR-050 按名拒绝，exit 2） |
| `bind ...: Address already in use` | 旧 UDS 文件残留/端口占用；UDS 在 `/run`（tmpfs）重启即清，TCP 需确认端口空闲 |
| apply 失败、提示资产 digest | 资产版本与计划不符；核对 `<assets-dir>` 固定布局与 sha256（`RFC-0010 §14`） |
| 无核心权限/TUN 起不来 | 见 §8：当前需 root；降权待 Privilege Helper |
| 想看 daemon 判定 | `caly doctor --addr unix:/run/calyd/calyd.sock` |
