# 开发日志 — 第九十八轮（R98）

- **日期**：2026-08-31
- **一句话**：CLI 收到 daemon REFUSAL 帧时，把其上的稳定公共错误码映射到 `EXIT_CODES.md §3` 定义的退出码（PERMISSION→8、CONFIG_INVALID→3、TIMEOUT→11…），不再把所有拒绝一律报成 PROTO_MISMATCH(13)；帧层/未知码仍回落 13。
- **数字**：`cargo test --workspace` **846 → 851**（CLI 假 daemon e2e +3、退出码表单测 +1、arch 结构门禁 +1）；`TEST_FLOOR` 846 → **851**；clippy 去重源码位置 **31 持平**；fmt clean。

---

## 1. 靶子

「信 kind 不信内容」关联族在客户端（R71/94/95/96/97）与 daemon 帧分派（fail-closed，二次 HELLO/未握手 request/未知 kind 全拒）两侧系统收口后，量选转到退出码诚实性。

`ask()` 返回 `Answer::Refused{code: String, summary: String}`，`code` 是 daemon REFUSAL 帧上的 `code` 记录——daemon 操作失败时 `calyd` 经 `refusal(.., error.code.as_str(), ..)` 放的是稳定公共码（PERMISSION/CONFIG_INVALID/CONFLICT/STORAGE/TIMEOUT/UNAVAILABLE/CURSOR_STALE/CANCELLED/INTERNAL…）。但 main 对它一律：

```rust
Ok(Answer::Refused { code, summary }) => {
    eprintln!("caly: refused ({code}): {summary}");
    exit_code(ExitCode::ProtoMismatch)   // 注释明说 "whatever the wire called it"
}
```

这违反 `EXIT_CODES.md §4.1`「CLI 在接收到稳定公共错误码时，应按上表映射」：PERMISSION 该落 8、CONFIG_INVALID 该落 3……shell 脚本/CI 无法据此区分「你没权限」与「双方对线不一致」。基础设施其实已齐——`caly-cli::exit_code.rs` 有完整 17 个 `ExitCode` 枚举、`from_error_code(ErrorCode)→ExitCode`、且 §3 表与枚举由 `exit_code_table.rs` 双向裁判盯着——**只缺「wire 码字符串 → 退出码」的反查这一段**。

## 2. 修复

- `crates/caly-cli/src/exit_code.rs` 加 `pub fn from_wire_refusal_code(code: &str) -> ExitCode`：用 14 个 `ErrorCode::as_str()` 反查识别公共码，命中即 `from_error_code`；**未命中回落 `ExitCode::ProtoMismatch`(13)**。未命中包括帧层/会话码（USAGE、UNSUPPORTED、NOT_FOUND、HANDSHAKE、HELLO_REQUIRED、PROTOCOL、TRANSPORT、STREAM_CAPACITY——它们是对线分歧，不是公共 `ApiError.code`）以及空/未知/未来码（新 daemon 的码不许猜）。
- `crates/caly-cli/src/bin/caly.rs` 两处 REFUSAL 消费点改经它路由，不再硬编码：main 的 `Answer::Refused`、follow 的 `WIRE_KIND_REFUSAL` 臂（在 request_id 关联通过之后）。
- **request_id 关联（R94/97）仍先于码映射**：外国 request_id 的 REFUSAL 即使带 PERMISSION 也先以 PROTO_MISMATCH 拒。

不新增/重命名任何退出码或错误码；不改 wire 帧形状、不改 daemon（daemon 本就在 REFUSAL 帧放正确公共码）；无新依赖、无新 ADR。

## 3. 裁判

- **单测** `exit_code_table::wire_refusal_codes_map_to_their_documented_exit_codes`：14 个公共码各落其文档退出码（且字符串 == `ErrorCode::as_str()`）；8 个帧层码 + 空串/`UNKNOWN`/`SOME_FUTURE_CODE` → 13。
- **假 daemon e2e 三胎**：
  - `a_permission_refusal_maps_to_exit_8_not_protocol_mismatch`：关联正确的 `code=PERMISSION` REFUSAL（request_id=1）→ **exit 8 非 13**、code 上 stderr、不打印事实；
  - `a_transport_layer_refusal_code_still_maps_to_protocol_mismatch`：`code=NOT_FOUND` 帧层码 → 仍 13；
  - `a_foreign_request_refusal_is_protocol_mismatch_even_with_a_public_code`：`request_id=999 但 code=PERMISSION` → 13 非 8（关联先于映射）。
- **结构门禁** `the_cli_maps_a_wire_refusal_code_to_its_documented_exit_code`：bin 有 ≥2 处 `from_wire_refusal_code(` 调用点（ask + follow），库内函数用 `.as_str()` 识别且回落 `ProtoMismatch`。

既有测试无回归：resume 未知流 `--resume 424242` → NOT_FOUND 仍 exit 13（非公共码）；编码/协议谎言（R71）与 over-cap 是本地 `Err` 仍 13。

## 4. 证伪（`scripts/falsify_round98.py`）

| 变异 | 改动 | 咬住 | 结果 |
|---|---|---|---|
| **M1** 映射塌成总回落 ProtoMismatch | find 变 `.find(\|_error_code\| false)` | PERMISSION e2e 红（得 13 非 8）+ 单测红（公共码全落 13）+ 门禁红（`.as_str()` 识别消失）；TRANSPORT 仍 13（正确） | **BIT** |
| **M2** ask() 硬编码回 ProtoMismatch | `exit_code(from_wire_refusal_code(&code))` → `exit_code(ExitCode::ProtoMismatch)` | PERMISSION e2e 红（status 动词走 ask）+ 门禁红（调用点 <2）；TRANSPORT 本就 13 不红、单测不红（库未动） | **BIT** |
| **M3** 未知回落改 GENERAL_FAILURE | `map_or(ProtoMismatch, ..)` → `map_or(GeneralFailure, ..)` | TRANSPORT e2e 红（NOT_FOUND 得 1 非 13）+ 单测红；PERMISSION 仍绿（识别还在）——证明回落是独立行为、不是顺带 | **BIT** |

## 5. 明确没做

- 不新增/重命名退出码或错误码：只把既有 14 个公共码接上映射，§3 表与枚举早已一致。
- 帧层码（NOT_FOUND/USAGE/HANDSHAKE…）不提升为公共 `ErrorCode`：它们是对线分歧，落 13 语义正确。
- 不改 wire 帧形状、不改 daemon、无新依赖、无新 ADR。

## 6. 留档规则

1. **映射链的每一段都得接上**：`ErrorCode→ExitCode` 有了、文档表↔枚举双向裁判有了，唯独「wire 字符串→ErrorCode」缺一段，CLI 就只能用一个码敷衍。查契约偏离要沿「输入(wire 记录)→解析→枚举→退出码」整条链走，不能只看枚举存在。
2. **识别不到的外部输入要安全回落到已知语义**（未知码=对线分歧=13），但不能把**已知**公共码也一并吞进回落——识别与回落分开测（M3 专咬回落、不伤识别）。
3. 一处契约修复若注释/文案明写了「whatever the wire called it」这种**有意的信息丢弃**，那往往就是契约偏离的自供。

## 7. 收尾

- `regenerate_test_census.py` → `files=105 total=851 rows=105`；`--check` 一致。
- `scripts/check.sh`：`TEST_FLOOR` 846 → 851；clippy 基线 31 不动。
- 文档：STATUS §8.32（新；§8.29 R95 历史 833→837、§8.31 R97 历史 842→846 保留）+ census 三行描述（dependency_direction 21 / caly_cli_e2e 42 / exit_code_table 4）、CENTERLINE/ROADMAP/STATUS/ONBOARDING 数字 846→851；ONBOARDING §4.172（新）+ 处置表 6.124（新）、「不做」标题 6.124→6.125；本日志入 README 三索引。
- `falsify_round98.py` M1/M2/M3 全 BIT；`.r98bak` 收尾 sweep 干净。
