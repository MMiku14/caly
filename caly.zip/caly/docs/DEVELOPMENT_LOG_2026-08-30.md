# Caly 开发日志 — 2026-08-30（durable source index / provenance 持久化）

本轮任务：**继续读代码与规范、沿中心主链接续开发，并使用 `fixtures/subscription-20260803.txt` 作为真实测试输入**。
本文件记录本轮实际实现、证据、发现的问题与尚未完成的边界；接手审计的长背景仍在
`docs/ONBOARDING_NOTES.md`。第六十二轮原始记录保留在 §1–§6；第六十三轮续接与新问题 `§4.147`–`§4.151` 追加在 §7；第六十四轮真实 runtime 组合与 `§4.152`–`§4.154` 追加在 §8，避免覆盖原始交付物。

---

## 1. 本轮接手判断

上一轮已经把显式 source endpoint、bounded HTTP body、parser、RawSource CAS、normalized
cache、条件请求和 locator invalidation 接成了 process-local 的纵向切片，但有一个不能继续以
“后续缺口”带过的事实：**如果 source index 只存在于进程内存，重启后无法诚实地发送
`ETag`/`Last-Modified`，也无法在 `304` 没有 body 时证明自己仍持有可复用内容。**

因此本轮没有另起 parser 或协议外壳，而是沿既有 storage seam 完成 source 的 durable publish /
restore 语义：source index 是条件请求与 raw CAS 之间的持久化事实索引，process-local cache
只是它的加速镜像。

接手时特别重新检查了以下真实代码边界，而不是只依据状态文档：

- `caly-storage::StorageBackend` 的对象、snapshot、journal、GC API 以及 FsStore 的 D3
  原子记录路径；
- `caly-storage::record` 的 primitive/opaque record codec 与拒绝损坏记录的启动行为；
- `caly-engine::source_worker` 的 200/304 publish、endpoint registry、restore 与 cache
  consumption；
- `caly-engine::source_persistence` 的 normalized/provenance/diagnostics 转换及 digest
  anchor；
- `service` 的 GC root 枚举与 `EngineHandle` worker 安装路径；
- `fixtures/subscription-20260803.txt` 的真实解析结果（严格解析为 **30 个节点**）。

---

## 2. 实现内容

### 2.1 在既有 `StorageBackend` 上开 source-index seam

没有新增独立的 `SourceIndexStore` supertrait。那会复制后端边界、破坏已有可替换性，并要求
所有自定义测试后端同时实现新 supertrait。最终选择是在已有 `StorageBackend` 上增加四个
默认返回 `Unsupported` 的方法：

- `put_source_index`
- `get_source_index`
- `list_source_indexes`
- `delete_source_index`

`FsStore` 与 `InMemoryStorage` 显式实现；旧的后端仍可编译，并会在真正请求 durable source
index 时点名“不支持”，而不是假装写入成功。删除只删除 index record，**不删除 raw CAS
对象**，因为 raw 对象的生命周期由 GC root 语义统一管理。

### 2.2 `SourceIndexRecord` 与 typed codec

`caly-storage::source::SourceIndexRecord` 只保存 storage 层能理解的 primitive / opaque
字符串，不把 pipeline、IR 或 parser 类型倒灌进 `caly-storage`。记录包含：

- source identity、kind、label、locator、route、body cap、media type 与 strict policy；
- ETag / Last-Modified 条件字段；
- raw CAS object digest、object kind、content SHA-256、byte length 与 stored-at 时间；
- normalized cache、parser provenance、diagnostics 的 opaque 编码及各自 digest。

record v1 是 field-whitelist 的 typed codec，unknown field、缺字段、空 identity/locator、
非法 cap、错误 SHA-256 anchor、损坏 opaque cache 都拒绝。`raw_stored_at` 作为可选兼容字段
保留，使旧记录可以解码，同时让跨重启的 `SourceUpdateReport.raw_object.stored_at` 不因
重新恢复而悄悄改变。

### 2.3 D3 发布顺序与跨重启恢复

200 响应的顺序现在是：

1. bounded body 经 parser，生成 raw/normalized/provenance/diagnostics；
2. raw bytes 写入 CAS，并校验写入意图与 parser raw digest；
3. source index 以 D3 原子记录写入，作为 durable publish point；
4. 更新 process-local worker cache；
5. EngineHandle 安装 worker 时再把 durable normalized entries 镜像进 engine cache。

恢复顺序是：

1. `list_source_indexes`；
2. typed decode、identity 与 metadata anchor 检查；
3. `get(raw_object_digest)` 确认对象存在；
4. `read_object(raw_object_digest)` 读回 bytes；
5. 校验 raw length 与 SHA-256，随后恢复 endpoint、validators、report 与 cache。

任一步失败都拒绝启动。尤其不能只相信 FsStore open 时的对象扫描，也不能只相信 record 里
写下来的摘要；worker 自己必须对它实际要在 304 路径复用的 raw bytes 再做证据检查。

### 2.4 304、locator invalidation 与 GC

恢复后的 worker 只有在 raw CAS 通过两个锚点校验后，才允许 304 复用同一个 report，并继续
携带 ETag / Last-Modified。304 空 body 不会进入 parser，也不会被当作无条件成功。

同 source id 的完整 `SourceEndpoint` 发生变化时，注册路径同时清理 process-local cache 与
对应 durable source index；同 locator 重注册保留缓存。旧 raw CAS 对象不在 endpoint 注册时
删除，交由下一轮 GC。source index 引用的 raw digest 是独立 `GcRootReason::SourceIndex`
root，因此 source index 存活期间，GC 不能回收它指向的 raw body；枚举 source roots 失败
时形成 gap，不能伪装成空列表。

### 2.5 Engine cache 恢复

此前 durable worker 即使恢复了 report，`EngineHandle` 仍可能只有空的 process-local
normalized cache。`set_source_update_worker` 现在消费 worker 的 `restored_sources()`，
把验证过的 normalized entries 安装进 engine cache。这样重启后的 source update 与后续
apply planning 看到的是同一份已验证 source，而不是“worker 有、engine 不知道”的双重事实。

---

## 3. 真实 fixture 裁判与新增测试

`crates/caly-engine/tests/source_durable.rs` 使用 workspace 内真实文件：

```text
fixtures/subscription-20260803.txt
```

裁判通过 `SimFs + FsStore` 模拟跨重启，但不伪造订阅内容：

1. 第一次请求返回 200，严格 parser 解析出 30 个节点；
2. raw body、normalized nodes、parser provenance、diagnostics、validators 与 source index
   写入 durable storage；
3. 关闭第一个 worker，重新打开同一 FsStore；
4. 新 worker 恢复 endpoint、ETag、Last-Modified、raw object 与全部 report；
5. EngineHandle 安装 worker 时恢复 30 个 normalized nodes；
6. 第二次请求发送两个条件字段并收到 304，复用与第一次完全相同的 raw/report 证据；
7. 改变 locator 后 durable index 被删除，重启不会恢复旧 endpoint；
8. 把 source record 替换成错误 record tag 后，下一次 FsStore open 明确拒绝启动。

同时新增/补齐：

- `caly-storage/tests/record_codec.rs`：source-index v1 round-trip、field whitelist、bad
  anchor、缺字段、`raw_stored_at` 兼容与坏记录拒绝；
- `caly-storage/tests/gc.rs`：source-index raw root 保护、index 删除后 root 解除、source
  root 与其他 root 的并集语义；
- `caly-engine/src/source_persistence.rs`：opaque normalized/provenance/diagnostics
  编解码和 raw SHA-256 anchor 的单测；
- `caly-engine/tests/source_durable.rs`：真实 fixture 的 200→重启→304，以及 locator
  invalidation 与坏记录拒启。

本轮把测试 census 从上一轮的 91 文件 / 691 个行首 `#[test]` 推进到 **93 文件 / 698 个
行首 `#[test]`**；该数字由 `scripts/regenerate_test_census.py` 生成，不手算。

---

## 4. 本轮发现并修复的问题（已同步 ONBOARDING_NOTES）

### 4.1 raw stored-at 在首次设计中会丢失（`§4.143`）

CAS object metadata 里已经有 `stored_at_unix_ms`，但 source-index 初稿没有保存它。重启
restore 后报告看似内容相同，时间事实却变成恢复时刻，破坏 report 的可审计性。修法是给
record 增加可选 `raw_stored_at`，旧记录仍可读，新发布完整保留时间；codec 与 durable
裁判均覆盖。

### 4.2 durable worker 恢复但 Engine cache 为空（`§4.144`）

第一版只把 durable report 装回 worker。实际调用者通过 `EngineHandle::cached_source`
读取 normalized source，因此重启后仍会看到空 cache。修法是让 worker 暴露验证过的
`restored_sources()`，由 `EngineHandle::set_source_update_worker` 在安装时镜像；这也把
“durable record 存在”与“上层确实消费它”分开验证。

### 4.3 独立 source-index supertrait 破坏可替换后端（`§4.145`）

把 source index 新做成强制 supertrait 会让已有 storage test double 失去可替换性，并复制
StorageBackend 的边界。改为既有 trait 上的默认 `Unsupported` 方法，只有支持该能力的
后端实现真实存储；这是兼容性与能力缺席都可观察的形状。

### 4.4 record codec 编辑损坏导致编译失败（`§4.146`）

在修改 `record_codec.rs` 时，`apply_journal` 结构体初始化的 `ApplyJournalRecord {`
被误删，造成 `unexpected closing delimiter`。编译器首个报错指向收尾分隔符，真正缺失
在更早的构造点。已恢复结构体起始并先跑该 crate 的定向测试；后续完整文档/测试门禁仍
需重新执行。

---

## 5. 验证结果

已完成的定向验证：

```text
cargo test -p caly-engine --test source_durable -- --nocapture       # passed
cargo test -p caly-storage --test gc --test record_codec -- --nocapture # passed
cargo test -p caly-engine source_persistence -- --nocapture          # passed
```

文档与门禁数字已同步到：

- `IMPLEMENTATION_STATUS.md`：93 个测试文件、698 个断言，durable source index/provenance
  已完成；剩余项改为 caller deadline、cancellation 与 inspection read model；
- `ROADMAP.md`、`CENTERLINE_PROGRESS.md`、`ADR-049-bounded-http-body-carrier.md`：durable
  source index 已完成，后续转向全链 deadline/inspection；
- `scripts/check.sh`：`TEST_FLOOR=698`；
- `ONBOARDING_NOTES.md`：disposition ledger `6.88`、当前快照、§4.143–§4.146；
- `docs/README.md`：本日志已纳入目录、文档表与接手导航。

完整门禁已在文档收口后执行并通过：

```text
./scripts/check.sh
  cargo check --workspace --all-targets       ok（0 warning）
  cargo test --workspace                      ok（698 passed / 0 failed，floor 698）
  cargo clippy --workspace --all-targets      ok（31 distinct locations，baseline 31）
  cargo fmt --all -- --check                  note（1,656 行既有 advisory 漂移，非阻断）
  result                                      all gates passed
```

另外单独重跑了 `cargo test --workspace` 与 `python3 scripts/regenerate_test_census.py --check`，均返回成功。
收口过程中第一遍完整门禁暴露了两个可修复的工程问题：CENTERLINE 唯一的机器断言锚在文档片段
替换中被误删，已恢复为“这 698 个断言是否依然成立”；`source_persistence` 新增解码循环触发
一个 `chunks_exact` clippy location，改为保持同一字段守恒语义的 `chunks(2)`，没有抬高基线。
第一遍 real-core route 裁判还短暂得到 example.com 的 502；目标测试单独重跑和随后完整
workspace 测试均通过，未将一次外部网络瞬态误判为 source/storage 回归，也没有因此放宽裁判。

`cargo fmt --all -- --check` 的既有 advisory 漂移仍不应通过全仓格式化擅自改写。

---

## 6. 明确未做

1. caller deadline 从 HTTP→parser→CAS→D3 全链贯通；
2. cancellation / 中止语义及其与 D3 publish 的竞态裁判；
3. source inspection read model（按 source id、locator、validator、raw/normalized
   provenance 的公开只读面）；
4. 默认把 `calyd` 的 effect runtime 改成 `StdEffectRuntime`，或补齐 Platform/TUN/helper；
5. 通用 IPC transport runtime、stream 生产语义、capability JSON 输入模式、schema migration、
   `stat_many`、CI/fuzz/performance。

下一轮应先用完整门禁确认本轮文档与 census 全部一致，再沿“全链 deadline/cancellation →
inspection read model”顺序推进；不要把 process-local cache 重新提升为 source 事实来源。

---

## 7. 第六十三轮续接：caller phase boundaries 与 durable source inspection

### 7.1 先核对真实代码边界

第六十二轮日志把 caller deadline/cancellation 与 inspection read model 列为“明确未做”。继续开发前重新读取了 `caly-engine/src/source_worker.rs`、`caly-engine/src/run_limits.rs`、`caly-daemon/src/app.rs`、`caly-daemon/src/query/source.rs`、`caly-io-std/src/http.rs`、`caly-io-sim/src/port_impl.rs` 及对应 contract tests，而没有把状态文档当作实现证据。核对结果是：source worker 已经具备 `RunLimits` 的单次事务边界和 durable record 读取入口，本轮应补的是 HTTP adapter 的 clock-aware caller control、worker phase probes、API 投影的真实门面裁判，而不是另造第二套 source pipeline。

### 7.2 统一 Http caller control

`caly_io::caller_deadline_mono_ms` 与 `caly_io::check_caller_control` 现在是 Std/Sim Http 共用的实现处：

- `deadline_mono_ms` 已存在时直接使用；只有相对 `deadline_ms` 时，才用 composition root 注入的 monotonic clock 在 fetch 开始锚定一次；
- 没有 clock 时不猜 deadline；取消仍可在没有 clock 时立即被观察；
- `StdHttp` 在 route、connect、header、body 等边界检查，并把有 clock 时的剩余期限收紧到单次 socket timeout；
- `SimHttp` 在消费 scripted response 前后走同一个 helper，因此仿真不是另一套 deadline 语义。

这项修改没有把 `Clock` 塞进冻结的 `Http` trait 签名，也没有把 blocking `std::net` 伪装成异步 reader。一个已经开始的 OS blocking syscall 仍只能在 socket timeout 或 syscall 返回后由外层 probe 观察取消/过期；这条限制写入 `ADR-049`，不能用“支持 cancellation”四个字掩盖。

### 7.3 Source worker phase probes 与 inspection projection

`HttpSourceUpdateWorker` 继续使用同一个 anchored `RequestContext`，并在以下边界拒绝已取消或过期调用：HTTP admission/return、304 raw-body read 前后、parse 前后、CAS 写入后、以及 200/304 source-index D3 commit 前。这样 D3 commit 前的取消不会留下半份 source index；已完成的 D3 发布不会被事后取消重写成未发布事实。

`SourceOp::Inspect` 的 durable 路径现在由 `get_source_index` → raw metadata/body anchor verification → `project_source_inspection` → daemon `Redactor` 组成，输出 endpoint/validators、latest/raw digest、raw size/stored-at、normalized counts、diagnostics、provenance 与更新时间。它不从 process-local `cached_source` 猜 durable 事实；真实 fixture `fixtures/subscription-20260803.txt` 经过 daemon `handle_request` 的新裁判确认 30 个节点、direct route、validator/provenance 一致性和 secret redaction。

### 7.4 本轮遇到的问题与修复

- **`§4.147`：Std/Sim 的 deadline 逻辑先各写一份，容易漂移。** 修法是把 relative-to-absolute anchoring 和 `Cancelled`/`Timeout` phase check 提取到 `caly-io`，两个 adapter 只负责自己的 transport boundary；对应 Std/Sim contract tests 重新跑通。
- **`§4.148`：missing raw object 测试最初删除了错误的路径。** 测试先按直觉删除 `{ROOT}/objects/<digest>.obj`，FsStore 实际的 raw metadata 位于 `{ROOT}/meta/objects/<escaped digest>.obj`，所以 worker 仍能读到对象。修法是从 FsStore 的 `meta/objects` layout 取出真实 metadata path，再验证 durable worker construction 明确拒绝缺失引用。
- **`§4.149`：corrupt raw bytes 测试最初期待 worker 在 `FsStore::open` 之后才拒绝。** FsStore 启动扫描本身会验证 content digest，直接在 open 阶段报 `content no longer matches`；测试改为验证 store startup refusal，并保留 worker-level missing/anchor refusal 路径，不把失败阶段错报成 worker runtime failure。
- **`§4.150`：新增 daemon integration test 后先跑了 census `--check`，它正确报告新测试文件不在 §3.3。** 修法是先运行 `python3 scripts/regenerate_test_census.py`，再同步状态文档与 `TEST_FLOOR=710`；生成后的 `--check` 和完整 workspace gate 已在本节收口后复核，不能只引用生成器输出。
- **`§4.151`：第一遍完整 gate 因新 source query handler 直接返回宽 `ApiError` 把 clippy location 从 31 推到 32。** 修法是让内部 `handle_source` 返回 `Box<ApiError>`，在统一 dispatcher 边界一次 unbox；不抬高 baseline，第二遍 gate 回到 31。

### 7.5 定向证据

```text
cargo test -p caly-io-std --test http_contract -- --nocapture   # 6 passed / 0 failed
cargo test -p caly-io-sim --test contract -- --nocapture        # 22 passed / 0 failed
cargo test -p caly-engine --test source_durable -- --nocapture  # 9 passed / 0 failed
cargo test -p caly-daemon --test source_inspection -- --nocapture # 1 passed / 0 failed
python3 scripts/regenerate_test_census.py                     # files=94 total=710 rows=94
```

这些是 targeted results，不提前替代完整 workspace gate；文档修改完成后已执行 census `--check` 与完整 `scripts/check.sh`，结果记录在 §7.7，不能沿用第六十二轮的 698 结论。

### 7.6 本轮收口后的当前边界

已完成：带注入 clock 的同步 HTTP→parser→CAS→D3 caller phase-boundary control，以及 durable source inspection 的 bounded projection/redaction。仍未完成：让 `CancelToken` 中途打断一个已经进入 `std::net` blocking syscall 的通用 runtime；让 `caly-ipc` 成为完整 production transport；以及真实 effect runtime 的生产默认、Platform/TUN、安全平台面、schema migration、CI/fuzz/performance 等既有范围项。当前 source 的 parser/record 上限仍是读侧有界性，不应因为没有 pagination 就虚构一个未定义的无限记录语义。

### 7.7 最终门禁结果

```text
python3 scripts/regenerate_test_census.py --check
  files=94 total=710 rows=94

./scripts/check.sh
  cargo check --workspace --all-targets       ok（0 warning）
  cargo test --workspace                      ok（710 passed / 0 failed，floor 710）
  cargo clippy --workspace --all-targets      ok（31 distinct locations，baseline 31）
  cargo fmt --all -- --check                  note（1,555 行既有 advisory 漂移，非阻断）
  result                                      all gates passed
```

第一遍完整 gate 在 clippy ratchet 处得到 32 个 location，原因是新 `source` query handler 直接返回宽的 `ApiError`；没有抬高 baseline，而是沿仓库已有的 `Box<ApiError>` 边界让该内部 handler 返回 `Box<ApiError>`，在统一 query dispatcher 处一次 unbox。修复后第二遍完整 gate 回到 baseline 31。这个失败与 source runtime 无关，但已作为本轮可复用的 clippy 证据留档。

为减少本轮新增测试造成的格式欠账，按既有“只格式化本轮触碰文件”的策略格式化了 source durable/daemon inspection tests 与 Http adapter contract；全仓仍保留 1,555 行 advisory 漂移，没有借功能变更偷偷提交全仓格式化。

---

## 8. 第六十四轮：`calyd` 真实 effect runtime 的显式组合根

### 8.1 先复读真实边界

接续开发没有把“`StdEffectRuntime` 已经存在”当成“`calyd` 已经接入”。重新核对了
`crates/caly-daemon/src/bin/calyd.rs`、`crates/caly-daemon/src/app.rs`、
`crates/caly-engine/src/service.rs`、`crates/caly-daemon/src/effect_std.rs`、
`crates/caly-engine/src/worker.rs` 及 `calyd_wire`/`real_apply` 裁判。核对得到的实际边界是：
engine 默认仍绑定 `SimulatedRuntime`；真实 runtime 的构造需要共享 engine storage、runtime
root 和固定 CoreAssets；现有启动 recovery 只扫描 durable journal/snapshot 并更新 lifecycle，
不做跨进程 core adoption、attach、stop 或 TUN。因而本轮接入的是显式 apply composition
root，而不是把“可启动”扩大解释为“已完成真实重启恢复”。

### 8.2 实现

`calyd` 现在解析：

```text
--effect-runtime simulated|real       默认 simulated
--runtime-root <path>                 real 必填
--assets-dir <path>                   real 必填
```

- simulated 模式携带 runtime/assets 参数会按名拒绝，不能静默忽略；未知 mode 也是启动前
  usage refusal；
- real 模式要求两个非空 operator-supplied path；runtime root 启动前创建、确认是目录、做
  process-unique create/remove 写入探针；assets directory 通过 `CoreAssets::from_directory`
  和 `validate_readable` 预检固定 mihomo/sing-box/geodata 布局；
- `StdEffectRuntime` 与 engine 共享同一 `Arc<dyn StorageBackend>`，通过新增的
  `DaemonApp::try_bootstrap_with_effect_runtime` 在 startup recovery 前构造并注入；没有
  把 runtime 先用 simulated recovery 再在返回后换成 real；
- 启动日志报告 `effect-runtime: simulated|real`；preflight 或 bootstrap 失败发生在
  listener publish 之前；真实模式不下载资产、不自动提权、不把 Platform/TUN 缺席改成假成功；
- real-only 选择与固定资产/运行目录/失败阶段语义冻结在 `docs/adrs/ADR-050-calyd-real-effect-runtime-composition.md`。

现有 source production 组合仍保持显式 `--source-endpoint source-id=locator`，并用共享
`StdHttp`/clock/storage；fixture `fixtures/subscription-20260803.txt` 的 source durable 与
inspection 证据没有被新 runtime 分支替代。

### 8.3 本轮遇到的问题与修复

- **`§4.152`：recovery 后注入 real runtime 的构造顺序。** 初版先调用
  `try_bootstrap(recover_on_start=true)`，再 `set_effect_runtime`；当前 recovery 虽然是
  scan-only，没有真实 effect 调用，但这个入口会让未来 recovery effect 看到 simulated
  world。修法是 `EngineHandle::with_effect_runtime` + `DaemonApp::try_bootstrap_with_effect_runtime`
  组成先注入后 recovery 的路径，并把跨进程 adoption 明确留给后续 ADR/实现。
- **`§4.153`：新增 3 条裁判后仍沿用 710 floor。** 两个 `calyd` mode parser 单测加一个
  missing-assets binary E2E 使 census 从 94/710 变成 95/713。修法是先运行 generator，再
  抬 `TEST_FLOOR` 到 713，刷新状态/路线/中心线/接手文档；不手算或只改总数。
- **`§4.154`：资产预检直接使用 `std::fs::File` 触发 disallowed type。** 第一遍完整 gate
  得到 32 个 clippy locations；保留“实际打开并验证可读”的语义，改用
  `OpenOptions::new().read(true).open(path)`，不通过抬高 baseline 把错误 host IO 接缝合法化。

### 8.4 定向证据

```text
cargo check -p caly-daemon --all-targets                           # passed
cargo test -p caly-daemon --bin calyd -- --nocapture               # 2 passed
cargo test -p caly-daemon --test calyd_wire \
  real_effect_runtime_preflight_refuses_missing_assets_before_listening \
  -- --nocapture                                                    # 1 passed / 32 filtered
python3 scripts/regenerate_test_census.py                          # files=95 total=713 rows=95
```

上述定向证据已执行并通过；完整 workspace gate、clippy、fmt 和 census `--check` 已在本节
文档收口后执行，最终结果见 §8.6。`real_apply` 的既有真实 core evidence 继续是
`StdEffectRuntime` 的 apply/rollback/probe 裁判，不由 missing-assets preflight 测试替代。

### 8.5 当前边界

已完成：`calyd` 显式 real/simulated 选择、real-only 参数拒绝、runtime root 可写性预检、
固定 CoreAssets 可读性预检、共享 storage runtime 构造，以及 preflight 失败前不监听；默认
仍为 simulated。未完成且不被本轮“real 可启动”覆盖：startup recovery 对真实宿主进程的
跨进程 adoption/attach/stop、process identity/lock、Platform/TUN/helper、完整 OS 网络
副作用、统一 RuntimeDriver telemetry、通用 IPC transport、source blocking syscall 中途
取消、schema migration、CI/fuzz/performance。当前 startup recovery 是 durable scan/state
projection，不是 process-level real recovery；这一点由 `ADR-050` 明确保留。

### 8.6 最终门禁结果

```text
python3 scripts/regenerate_test_census.py --check
  files=95 total=713 rows=95

./scripts/check.sh
  cargo check --workspace --all-targets       ok（0 warning）
  cargo test --workspace                      ok（713 passed / 0 failed，floor 713）
  cargo clippy --workspace --all-targets      ok（31 distinct locations，baseline 31）
  cargo fmt --all -- --check                  note（1,684 行既有 advisory 漂移，非阻断）
  result                                      all gates passed
```

收口过程中的失败已分别登记在 `ONBOARDING_NOTES.md §4.152–§4.155`：先是 recovery 前的
runtime 注入顺序、随后是 census/floor 漂移、资产预检触发 disallowed type，最后是一次
真实 core 外部 round-trip 的瞬时 502。第一遍完整 gate 的 32 个 clippy locations 没有抬成
新基线；`OpenOptions` 修复后回到 31。文档 consistency 的 ledger heading 也曾因新增 `6.90`
行而撞到同号，改为 `6.91` 后由完整 gate 复核通过；502 记录后定向测试和第二次完整 gate
均通过。
---

## 9. 第六十五轮：source-index 损坏形态的参数化拒启证伪（收口 `IMPLEMENTATION_STATUS §8.4` 第一条）

### 9.1 选事与判据（可证伪的一句话）

source-index 记录的每种损坏形态（opaque cache 锚点失配、raw anchor 非 sha256 格式、未知字段、
缺字段、空 identity、零上限、坏时间戳）必须在 codec 层被**点名**拒绝；worker 恢复必须拒绝 raw
对象 metadata 与 durable anchors 不一致；304 复用必须拒绝丢失/未校验的 raw body——且每条断言
都有一条让它变红的变异。选事依据：`ROADMAP §13` 第一位 + `IMPLEMENTATION_STATUS §8.4` 第一条
（第 64 轮时点下 source 耐久链的“还差一层”缺口）。

### 9.2 做了什么

**① codec 层（`crates/caly-storage/tests/record_codec.rs`，11→17）**：新增 `tamper_field` helper
（按 `k=v` 行精确替换），六个参数化测试覆盖：cache 锚三字段各自失配（
`source_index_rejects_cache_fields_detached_from_their_anchors`）、raw anchor 非 sha256 格式
（前缀/长度/hex 三形）、未知字段点名、缺字段按名（`missing required field "K"`）、空 identity /
空 locator / `max_body_bytes=0`、坏时间戳与坏标志。

**② worker 与 304 层（`crates/caly-engine/tests/source_durable.rs`，9→13）**：
- `disagreeing_raw_object_metadata_refuses_durable_worker_restore`——**FsStore 开库只对内容校验
  content_sha256、不查 size 行**，所以篡改 `meta/objects/*.obj` 的 `size=` 能过 open、被 worker
  恢复的 metadata 锚抓住（`raw object metadata disagrees with its durable anchors`）。
- `corrupt_raw_bytes_between_restore_and_304_refuse_reuse_on_the_durable_store`——经真实
  content_sha256 得内容后缀、`write_atomic` 覆盖盘上字节后，304 复用报
  `cached raw-body read failed` + `failed integrity verification on read`（FsStore 读回校验层）。
- `a_304_reuse_with_a_lost_raw_body_is_refused_by_name`（`cached raw body is missing`）与
  `a_304_reuse_with_unverified_bytes_is_refused_by_the_worker_anchor`（
  `cached raw body failed its digest anchor on 304 reuse`）——两个 worker 级守卫在
  FsStore/InMemory 上**不可达**（`read_object` 自带读回校验，store 先拒），故新增
  `UnverifiedRawStorage` 撒谎后端（全部 store trait 委托 InMemoryStorage、只覆盖 `read_object`：
  missing 返 `Ok(None)`、tampered 返未校验字节）——正是“每个实现失效地测”（§4.121）：守卫在
  shipping 后端不可达不等于没有守卫，要给它找得到裁判。

### 9.3 证伪（`scripts/falsify_round65.py`，9 变异全咬）

M1 删 cache 锚检查 / M2 删 raw sha256 格式检查 / M3 缺字段返空 / M4 删空身份零 cap 检查 /
M5 时间戳默认 0 / M6 删 worker metadata 锚 / M7 304 digest 守卫恒 false / M8 缺 body 变空 body /
M9 删 FsStore 读回校验。首跑 M3/M8 是**编译错误变异**（`unwrap_or("")` 把 Result 变 `&str` 的
E0308、`ok_or_else(|| Vec::new())?` 产生 `Result<Vec<u8>, Vec<u8>>` 无法转 String 的 E0277）——
按 §4.112 改形状（`Ok(…unwrap_or(""))` / `unwrap_or_default()`）后全咬；M9 的 extra 裁判名首跑
写错（`tampered_bytes_are_refused_on_read_back` 不存在，真名
`tampered_content_is_refused_on_read_rather_than_handed_back`），grep 真名修正。终态：
**9/9 bit，`all mutations bit: True`**，逐突变 `.r65bak` 备份/恢复，sha256 校验，无残留。

### 9.4 收口中的三个环境/卫生发现

**① 交付物不含真核资产**：第一次完整 `./scripts/check.sh` 在 `caly-daemon` `effect_std` 两个
测试处红（`asset-read` 而非 `binary-digest-mismatch`）——`caly.zip` 里 `assets/` 是空目录，
第 54 轮的真核资产是外部下载、从没进包；“缺资产=按名红、绝不 skip”是设计，不是回归。恢复：
mihomo v1.19.30 gz 与 sing-box 1.13.20 tgz 从官方 release 精确重建；`geoip.metadb`/`geosite.dat`
（08-29 版本）的上游**不可得**（滚动 `latest` 已更新、release 分支 force-push 压平为单提交、
git tags 仅 `latest`、Actions artifacts 无、Wayback 无缓存），最终 `cdn.jsdelivr.net` 主节点
边缘缓存仍是 08-29 版本——四文件 sha256 与裁判常量**全等**（详见 `ONBOARDING §4.156`）。

**② clippy 新 location 不抬基线**：`UnverifiedRawStorage` 的 `tampered_read:
Arc<Mutex<Option<(String, Vec<u8>)>>>` 触发 `type_complexity`（第 32 个 location）——按不变式
“不抬 CLIPPY_BASELINE、不加 `#[allow]`”提成 `type TamperedRead = …` 别名归零，clippy 回到 31。

**③ executable targets 实测 87 而非 85**：`cargo test --workspace --no-run` 实测 22 unittests +
65 integration（`contract.rs` 与 `selfcheck.rs` 各有两个 crate 的同名文件、各算一个 target）；
第 64 轮快照的“63”是同名合并误数。按数字纪律以实测为准更新（历史行不改写）。

### 9.5 最终门禁结果

```text
python3 scripts/regenerate_test_census.py --check
  files=95 total=723 rows=95

./scripts/check.sh（连跑两次，结论一致）
  cargo check --workspace --all-targets       ok（0 warning）
  cargo test --workspace                      ok（723 passed / 0 failed，floor 723）
  cargo clippy --workspace --all-targets      ok（31 distinct locations，baseline 31）
  cargo fmt --all -- --check                  note（1,684 行既有 advisory 漂移，非阻断）
  result                                      all gates passed
```

### 9.6 明确未做 / 下一步

- source 方向剩余（`ROADMAP §13`）：blocking syscall 的诚实中断/回收边界仍是记录在案的缺口；
  real runtime 跨进程 core adoption/ownership 未宣称（`ADR-050` 边界不变）。
- 本轮的 `falsify_round65.py` 保留在 `scripts/`（9 变异模板，含备份/恢复/编译错区分），
  后续轮次可作 harness 参照。

---

## 10. 第六十六轮：job 流帧逐字断言（收口 `IMPLEMENTATION_STATUS §8.4` 第二条的一半）

### 10.1 选事与判据（可证伪的一句话）

`jobs.follow-stream` 的每个 DATA 帧 `event_{i}` 行必须与 `jobs.events` 页（同一 job、整窗）的
`event_{i}` 行**逐行逐字**一致（unescape 语义面、顺序、帧拼接==整窗页），且帧内 `event_count`
必须等于该帧 `event_<digit>` 行数——且上述每条断言都有一条让它变红的变异。选事：`§8.4`
测试补面第二条点名「逐帧 stream payload 断言」；既有 e2e 只比 count==count。

### 10.2 量现状（先行）

一次性探测脚本（真 `calyd` binary + v0 帧协议 + 独立 unescape）对 `demo-tun-profile` apply
的 37 行事件：**现状逐行一致（1 DATA 帧）**——契约已成立、**断言缺口而非缺陷**：
行序翻转/截断/多发一行在 count-vs-count 裁判面前全绿。

### 10.3 做了什么（`calyd_wire.rs` +1，21→22）

新增 `the_stream_data_payload_matches_the_events_page_line_for_line`：
- 自持 oracle `unescape`（解码 `%25`/`%3D`/`%0A`、其余字面——独立实现，转义停止/双重转义
  无法与它一致；`escape` 一直存在于此文件，本轮补上解码侧）；
- 整窗流（无 `from_event_index`）DATA 帧拼接 == events 整窗页行序列（逐字、顺序）；
- 帧内计数==行：`event_count` 必须等于该帧 `event_<digit>` 行数（从帧的 record 列表独立数）；
- 帧内每行非空。

### 10.4 证伪（`scripts/falsify_round66.py`，4 变异全咬）

V1 行序翻转（`iter().rev()`）/ V2 行截断 16 字符 / V3 `event_count` 少报一 / V4 循环多跑一行
（空 `event_i`）——全部只在 `calyd.rs` 的 DATA 帧装配处、保类型保编译；点名裁判逐变异单跑，
**4/4 全咬**（2.6s/1.0s/0.9s/0.9s）。V2 的 16 字符是否“有杀伤力”是**事前量过行长度**定的
（34/37 行 >16）——不是咬合事故。

### 10.5 最终门禁结果

```text
python3 scripts/regenerate_test_census.py --check
  files=95 total=724 rows=95（calyd_wire 34；文件数不变）

./scripts/check.sh（连跑两次，结论一致）
  cargo check --workspace --all-targets       ok（0 warning）
  cargo test --workspace                      ok（724 passed / 0 failed，floor 724）
  cargo clippy --workspace --all-targets      ok（31 distinct locations，baseline 31）
  cargo fmt --all -- --check                  note（1,672 行既有 advisory 漂移，非阻断——本轮 rustfmt 了 calyd_wire.rs，漂移自 1,684 收窄 12 行）
  result                                      all gates passed
```

### 10.5bis 门禁观察

收尾第一次完整 `./scripts/check.sh` 在 `a_fetch_through_the_active_core_really_rides_the_core`
处红（真实 core 经 mixed inbound 访问 `http://example.com/` 的瞬时 502）——**即 `§4.155`
已登记的旧患**（外部 round-trip 环境波动），不是本轮回归；随后的连续三次完整 gate
全绿。按 §4.155 的 Disposition：保留该测试与 200 断言，不降级不抬高。

### 10.6 明确未做 / 下一步

- `caly-ipc` 通用 transport runtime（UDS/双工调度）仍未接入——`§8.4` 第二条剩下的那一半；
  逐帧断言现在是 e2e 级，transport 级逐帧生产语义仍待通用 runtime。
- 下一轮候选（`ROADMAP §13` 顺位）：source blocking 边界扩展、real runtime 跨进程
  core adoption/ownership、capability registry JSON 加载（`§8.4` 第四条）。

---

## 11. 第六十七轮：spawn 产物字节 golden（收口 `IMPLEMENTATION_STATUS §8.4`「mihomo / sing-box 产物字节 golden」）

### 11.1 选事与判据（可证伪的一句话）

一次真 apply 之后，runtime root 必须持有**钉死资产的精确字节**——gz/tgz 拷贝、gunzip/tar
解压出的二进制、两个 geo 库——以及合并配置（mihomo=artifact 字节+文档化 envelope 模板；
sing-box=artifact JSON 与部署端口的结构化 merge），且目录里**没有计划外的产物**。资产
digest 裁判只证明「资产=钉住的字节」，本轮 golden 证明「**部署**确实把那些字节带上盘、
并按文档合并了配置」。

### 11.2 量现状（先行）

一次性 probe（`spawn_probe.rs`，已删）真 apply 后扫 runtime root：mihomo 树
`runtime/nightshift/` = `config.yaml`（artifact 本体）/`caly-run.yaml`（artifact+envelope
拼接）/`core.gz`/`core`/`geoip.metadb`/`geosite.dat`/`cache.db`（核心运行时自产）；sing-box
树同构且 tar 解出三成员（`sing-box`/`libcronet.so`/`LICENSE`）。**现状全绿=契约已成立、
断言缺口而非缺陷**：任何一轮「把资产字节写错/漏写/合并错」都不会被现有裁判看见。

### 11.3 做了什么（新文件 `spawn_artifacts.rs`，2 测试；census 95→96 文件、724→726）

- `the_spawned_mihomo_artifacts_are_the_pinned_assets_byte_for_byte`：`core.gz`/`geoip.metadb`/
  `geosite.dat` 与工作区资产**逐字节**；`core` 与**独立** `gunzip`（`-kf` 保留归档）结果逐字节；
  `caly-run.yaml` **以** `config.yaml` 字节开头，且 == artifact + 文档化 envelope 模板
  （端口从部署文件读回后**重建全等**——golden 快照性质，模板改动须两侧同步）；
- `the_spawned_singbox_artifacts_are_the_pinned_assets_byte_for_byte`：`core.tar.gz` 与资产
  逐字节；`sing-box`/`libcronet.so`/`LICENSE` 与**独立** `tar xzf` 解出的成员逐字节；
  `caly-run.json` 由**独立 oracle** 再合并（读回部署端口 → 对 artifact JSON 做同样注入 →
  `serde_json::Value` 全等）；
- 两者都做**目录白名单**断言（无计划外文件；`cache.db` 白名单内但明确排除在 golden 外——
  它是核心运行时的东西，本步不写它）。

### 11.4 证伪（`scripts/falsify_round67.py`，5 变异全咬）

M1 geoip 拷贝载 geosite 字节（交叉写）/ M2 envelope 漏 geox-url 块 / M3 merge 漏 clash_api /
M4 `--strip-components` 丢失（成员落在子目录）/ M5 `log-level: info`→`debug`——全部只改
`effect_std.rs` SpawnCore、保编译；点名裁判逐变异单跑 **5/5 全咬**（6.4–7.2s）。这些变异
对「只校验资产 digest」的裁判全部隐身——正是本轮补的洞。（harness 首轮把 `error: test
failed` 误判为编译错——§4.112 族既有判据：只认 `error[E`。）

### 11.5 最终门禁结果

```text
python3 scripts/regenerate_test_census.py --check
  files=96 total=726 rows=96（spawn_artifacts 2；文件 95→96）

./scripts/check.sh（连跑两次，结论一致）
  cargo check --workspace --all-targets       ok（0 warning）
  cargo test --workspace                      ok（726 passed / 0 failed，floor 726）
  cargo clippy --workspace --all-targets      ok（31 distinct locations，baseline 31）
  cargo fmt --all -- --check                  note（1,672 行既有 advisory 漂移，非阻断）
  result                                      all gates passed
```

### 11.6 明确未做 / 下一步

- `§8.4` 该条剩余：RuntimeDriver identity/telemetry（`RuntimeDriver` 的统一 identity /
  telemetry API 仍未统一）；`§8.4` 第 4 条：纯核心缓存/记忆化与 capability 文件加载失败语义
  （后者牵连 `§8.3` 的决策——registry 从文件加载 vs 「文件仅由代码生成」）。
- 下一轮候选（`ROADMAP §13` 顺位）：source blocking 边界扩展、real runtime 跨进程
  core adoption/ownership、`caly-ipc` 通用 transport runtime、capability registry JSON 加载。

---

## 12. 第六十八轮：Capability registry 工件方向决策（收口 `IMPLEMENTATION_STATUS §8.3`）

### 12.1 选事与判据（可证伪的一句话）

**决策缺口**（§8.3 悬置）：registry 从文件加载 vs 文件仅由代码生成。判据——若工件是
导出物，则：①生产 `src/` 不得从工件读取（arch-test 裁判，且只拦「命名+取数同一行」、
不拦纯引用——避免过度）；②工件内容必须等于代码文档（`registry_drift.rs` 已有）；③
「文件加载失败/离线语义」无运行时面，不凭空造契约。

### 12.2 量现状（先行）

- `REGISTRY_PATH`/`COVERAGE_MATRIX_PATH` 在全部生产 `crates/*/src/**` 中**零引用**（仅
  `lib.rs` 定义 + `json.rs` 模块注释提及）；运行时代码都用 `default_registry_document()`/
  `merged_registry_document()` 等**编译期 Rust 文档值**；
- `json.rs` 模块注释明说：工件曾是「文档假装成数据、会静默漂移」；修复 = `parse(file) ==
  default()` 把漂移变构建失败——即**导出物**方向已被代码事实选定；
- `§6.2` 却把「capability 执行仍读代码内建 registry/coverage default，而不是从 JSON 工件
  加载」当**未完成项**记账——文档与事实漂移（读代码内建正是 ADR-024 单一事实源的正确形态）；
- `ROADMAP §1bis` 表「ADR 39 / Accepted 39」是文档数字漂移（实测 41 编号 ADR 全 Accepted
  + 模板 1 份自身 Proposed；第 65 轮发现未同步——本轮一并修正为 41/41 + 模板注）。

### 12.3 做了什么

1. **`docs/adrs/ADR-051-capability-registry-artifacts-are-exports.md`**：Decision §2——单一
   事实源 = `caly_cap` 编译期文档；工件 = 导出物（生成器重写 + drift 门禁保证一致）；生产
   `src/` 不得从工件读取；「文件加载失败/离线语义」无运行时面（未来引入须按 §2.4 另立 ADR）；
   工件在 `crates/caly-cap/` 下是随 crate 走的导出路径。Alternatives：运行时加载（无消费者、
   确定性不可保持，否）、悬置（持续漂移，否）、删工件（丢可读导出物与「双份一致才是证据」
   裁判，否）。`ADR-024` 的单一事实源/绑定证据两条不动（本 ADR 是澄清+补决策，正文不改写历史）。
2. **arch-test 裁判**（`dependency_direction.rs` +1，第 68 轮 10→11 条——第 67 轮门禁日志
   `running 10 tests` 实测；此前记录的 11→12 是记述错误）：
   `the_registry_artifacts_are_exports_not_runtime_inputs`——扫描 `crates/*/src/**` 全部 `.rs` 文件，
   逐行判「工件 token（常量名或字面文件名）与取数调用（`read_to_string`/`fs::read`/
   `File::open`/`include_str!`/`include_bytes!`）同行」即违规；**只引用常量名不算**（命名≠读取）。
   行级判据避免把注释/引用误杀（json.rs 模块注释含常量名、lib.rs 定义行——都无取数调用，不红）。
3. **`caly-cap/src/lib.rs`**：两个常量补导出物文档注释（`ADR-051` 决策直接要求的「导出物而非
   输入物」语义落到代码）。
4. **文档收口**：`§8.3` 划线 + ADR-051 注；`§6.2`/`§8.4` 第 4 条 capability 半改写（不再把
   「读代码内建」当缺陷；「文件加载失败语义」记为不适用）；`ROADMAP` Phase 0 表（ADR-011~051、
   41 份）、§1bis 表第 0 行（41/41 + 模板注）、§1bis.3 加去向、L87/L197/L246 表述对齐；
   CENTERLINE/快照/`check.sh` 723→727 同步。

### 12.4 证伪（`scripts/falsify_round68.py`，双检）

- M1（应咬）：`catalog.rs` 的 `default_registry_document()` 内加
  `let _ = std::fs::read_to_string(REGISTRY_PATH);`——运行时取数潜入 → 裁判 **红**；
- M2（应不咬）：`executor.rs` 追加 `const _REF: &str = caly_cap::REGISTRY_PATH;`——仅命名
  常量、无取数 → 裁判**保持绿**（门禁不越界：命名 ≠ 读取）。
- 两者都按「文本门禁无需编译」设计（0.1s/条），判定仍区分编译错（`error[E`）。

### 12.5 最终门禁结果

```text
python3 scripts/regenerate_test_census.py --check
  files=96 total=727 rows=96（dependency_direction 10→11；文件数不变）
  （注：本段收口前的第一次 `--check` 曾报 stale，根因未定位（疑为 falsify 变异还原
  与重生成的交错时序）；重生成后 `--check` 通过，且重生成的表与树上内容一致——按「以树为准、
  重生成即修复」处理，不再回查。）

./scripts/check.sh（连跑两次，结论一致）
  cargo check --workspace --all-targets       ok（0 warning）
  cargo test --workspace                      ok（727 passed / 0 failed，floor 727）
  cargo clippy --workspace --all-targets      ok（31 distinct locations，baseline 31）
  cargo fmt --all -- --check                  note（1,672 行既有 advisory 漂移，非阻断）
  result                                      all gates passed
```

### 12.6 明确未做 / 下一步

- `§8.4` 余额：RuntimeDriver identity/telemetry、纯核心缓存/记忆化（性能面）；
  `§1bis.2` 的「capability 文件加载」不再是目标（ADR-051）；
- 下一轮候选（`ROADMAP §13` 顺位）：source blocking 边界扩展、real runtime 跨进程
  core adoption/ownership、`caly-ipc` 通用 transport runtime。

---

## 13. 第六十九轮：RuntimeDriver identity/telemetry（真核心身份与自有计数器）

### 13.1 选事与判据（可证伪的一句话）

§8.4 剩余面 = 第 67 轮把「mihomo/sing-box 产物字节 golden、RuntimeDriver
identity/telemetry」整行划线，但只覆盖了 golden 部分——identity/telemetry 是粒度错记
留下的真缺口（`ONBOARDING §2.2` 的教训）。判据：真 apply 后，计划里的新探针
`CoreIdentity` 与 `TelemetryTraffic` 让「live core 的身份与遥测」成为 job 日志里可断言的
证据——身份来自 `GET /version` 响应体（kind=计划钉的 kind + version=核心自报），遥测来自
`GET /connections` 的累计计数器；sim 与 real 双侧执行；4 个证伪变异每边至少一咬。

### 13.2 量现状（先行）

- 生产零网络栈疑虑排除：`caly-io-std` 已有 `StdHttp`（单 IO 网关），daemon 的
  `controller_answers` 已真发 `GET /version`——**但只判 200，body 丢掉**（身份未知）；
- 计划侧：apply 计划由 **adapter 构建**（`caly-mihomo`/`caly-singbox` 的 `build_effect_plan`），
  尾 = ApiReady → InboundListening → ConfigIdentity → MarkSnapshot → CommitRevision；
  `worker.rs redeploy_rollback_target`（复活）同样以三探针收尾；sim 计划在 `mock.rs`（按
  自身风格镜像，不与 adapter 逐格相同——parity 是语义不是字面）；
- 探针观测值（StepEvidence）从不进 job 日志：`report_execution` 只记 step 标签
  （`.take(12)`）——探针在日志里「证明了什么」是空的；
- 实地量出两个真核心的 API 形态（assets 真二进制 + 最小配置）：
  - `/version`：mihomo=`{"meta":true,"version":"v1.19.30"}`；sing-box=
    `{"meta":true,"premium":true,"version":"sing-box 1.13.20"}`；
  - `/connections`：两端同形 `{"connections":[…],"downloadTotal":N,"uploadTotal":M,…}`，
    累计、单调、可按 (0,0) 基线断言因果；`/traffic`：mihomo 含总量、sing-box **只有速率**
    ——所以遥测选 /connections（两端唯一同形累计面）；
  - `/logs`：SSE 推流（curl 需 `-N` 才见输出；首次订阅只见新行）——推流模型不适合
    探针的一次性读取，记录为超范围（日志面在 `RuntimeLogLine`，留给消费方）；
- 端口残留教训：固定端口手工复现时旧进程残留会给出「幽灵计数」（75/873 = 上一进程的
  example.com 字节数）——daemon 全部用 `free_port()`，不受影响。

### 13.3 做了什么

1. `caly_plan::ProbeKind` + `CoreIdentity`、`TelemetryTraffic`（带 R69 语义文档注释）；
2. 计划发射：mihomo/singbox adapter `build_effect_plan` 尾部 + `worker.rs` 复活计划各加
   两探针（deadline 3_000）；`mock.rs` sim 计划按自身风格镜像（ApiPatch / Restart 两臂）；
3. 真实实现（`effect_std.rs`，全部过 caly-io-std 单网关）：`LiveInstance` 记 `core_kind`；
   `controller_version`/`controller_totals`/`fetch_controller_json` 私有解析；探针臂把结果
   写成 `probe.core-identity kind=… version=… controller=127.0.0.1:…` 与
   `probe.telemetry-traffic upload_total=… download_total=…`（`StepEvidence::took`，带耗时）；
   200 但 body 不是 `/version`/`/connections` 的 JSON = `core-identity-unreadable`/
   `telemetry-unreadable` 拒绝（不是骨架静默通过）；`core_kind_name` 拼 kind 标签；
   公共读面补 `controller_identity()`/`controller_traffic_totals()`（测试与探针同路径）；
4. sim 实现（`sim_runtime.rs`）：`SimulatedCore` 记 `kind`；ProbeCode 臂给出确定性答案
   （`core.identity simulated kind=… instance=…`；`telemetry.traffic simulated upload=0
   download=0 (the simulator keeps no counters)`——模拟器无计数器，如实声明）；
5. `worker.rs report_execution`：probe 步的观测值进 job 日志（仅 `label.starts_with(
   "probe ")` 的步——其他步的标签就是摘要；这是「探针证据必须可见」的收口，此前证据只在
   执行记录里、job 日志看不到）；
6. `real_apply` 新裁判 `the_applied_core_names_itself_and_counts_its_own_traffic`（judge 10，
   两真核心 ~10s）：mihomo 半场——evidence 含 `probe.core-identity`（kind=mihomo 且版本含
   "1.19.30"）+ `probe.telemetry-traffic`（两个计数字段）；先读计数器→经 core 取
   example.com 200→计数器严格大于；`controller_identity()` 回读一致；shutdown 后
   sing-box 半场同构（版本含 "1.13.20"）。

### 13.4 证伪（`scripts/falsify_round69.py`，4 变异全咬）

- M1（应咬）：CoreIdentity 臂不读 `/version`、硬编码版本 → 「版本=钉住版本」断言红；
- M2（应咬）：`controller_totals` 恒返 (0,0) → 取数后严格增长断言红；
- M3（应咬）：mihomo 计划删 CoreIdentity 步 → mihomo 半场找不到身份证据；
- M4（应咬）：singbox 计划删 TelemetryTraffic 步 → singbox 半场找不到遥测证据。
- **M4 首跑不咬**：第 69 轮自己的判据在 singbox 半场漏了 telemetry 存在性断言
  （只有身份 + 公共读面因果）——恰是 `§4.125`「报错先改变异/断言没长在分支上」的标准
  演练；补上断言（与 mihomo 半场同构）后 4/4 咬。修自身两个问题：版本提取
  `split_whitespace` 吃不下 "sing-box 1.13.20" 的空格（改 `split(" controller=")`）；
  M1/M2 硬编码变异的锚点与文件现状核对后逐条锚检。

### 13.5 最终门禁结果

```text
python3 scripts/regenerate_test_census.py --check
  files=96 total=728 rows=96（real_apply 9→10；文件数不变）

cargo test --workspace                       （先跑：全绿；随后 check.sh 门禁复跑）
./scripts/check.sh（连跑两次，结论一致）
  cargo check --workspace --all-targets       ok（0 warning）
  cargo test --workspace                      ok（728 passed / 0 failed，floor 728）
  cargo clippy --workspace --all-targets      ok（31 distinct locations，baseline 31）
  cargo fmt --all -- --check                  note（670 行既有 advisory 漂移，非阻断——本轮 rustfmt 带了旧漂移的
                                                  effect_std/real_apply/singbox adapter，全局 1,672→670）
  result                                      all gates passed
```

### 13.6 明确未做 / 下一步

- `/logs`（推流型）不进一次性探针——留 `RuntimeLogLine` 消费侧（进程外 UI/日志面）；
- §8.4 余额只剩 **纯核心缓存/记忆化（性能面）**；
- `§10` 一句话原则的下一步判据原样：source blocking 边界诚实扩展、真 effect runtime
  的跨进程 core adoption/ownership（`ROADMAP §13` #3，现在身份/遥测探针已把「谁在跑、
  计数多少」变成证据，adoption 差的就是 ownership 语义本身）、`caly-ipc` 通用
  transport runtime。

---

## 14. 第七十轮：纯核心缓存/记忆化（§8.4 收官）

### 14.1 选事与判据（可证伪的一句话）

§8.4 最后一条余额：「纯核心缓存/记忆化（性能面，未开始）——caly-core 无缓存/记忆化实现」。
量现状（先量再决定）：缺口不在「caly-core 无缓存」的泛泛表述，而在具体热点——`caly-cap`
的 `default_registry_document()` / `default_coverage_matrix_document()` **每次调用整份重建**
（18 个 descriptor + 全部字符串），而 `apply.rs`/`validate.rs`/`bundle.rs` 每次合并 base 都
从它开始。判据：内置文档是常量 → **进程内只构建一次**；两次调用返回同一实例（指针判等）；
证伪变异（改回每次新建）必须咬。

### 14.2 做了什么

1. `catalog.rs`：两个访问器返回 `&'static`，内部 `OnceLock::get_or_init` 记忆化；原函数体
   改名 `build_default_registry_document`/`build_default_coverage_matrix_document`；文档注释
   写明「记忆化的是常量，不是从文件加载——`ADR-051` 的编译期 Rust 值事实不变」；
2. 调用点同步（类型系统驱动，全部编译期发现）：`apply.rs`×2、`validate.rs`×2（去掉多余
   `&`）；`bundle.rs`（字段访问透传，无需改）；`registry_drift.rs` 测试 7 处（比较改
   `*built_in`、`registry_to_json(registry)` 等）；
3. 裁判：`registry_drift::the_builtin_documents_are_constructed_once_per_process`
   ——两次调用指针判等（registry 与 coverage 各一对）。为什么选指针判等：漂移测试只比
   **值**，逐次重建也值相等，「构建一次」只有判等能区分；
4. 顺带核实并标注 §13 第 2 条（真实 runtime 生产组合根）**已实现**：
   `--effect-runtime real` + `--runtime-root`/`--assets-dir` 显式配对（其余组合命名拒绝）、
   启动前置写探针 + `CoreAssets::validate_readable`、默认仍 simulated、二元级 E2E
   `real_effect_runtime_preflight_refuses_missing_assets_before_listening`——旧建议清单
   未标注属 §2.2 类「已实现未标注」漂移，本轮修正。

### 14.3 证伪（`scripts/falsify_round70.py`，2 变异全咬）

- M1（应咬）：registry 访问器改 `Box::leak(Box::new(build…()))`（每次新建）→ 指针判等红；
- M2（应咬）：coverage 访问器同样改法 → 指针判等红。
- 均 0.4s 内咬（`cargo test -p caly-cap --test registry_drift` 单测过滤）。

### 14.4 最终门禁结果

```text
python3 scripts/regenerate_test_census.py --check
  files=96 total=729 rows=96（registry_drift 7→8；文件数不变）

cargo test --workspace                       （全绿；随后 check.sh 门禁复跑）
./scripts/check.sh（连跑两次，结论一致）
  cargo check --workspace --all-targets       ok（0 warning）
  cargo test --workspace                      ok（729 passed / 0 failed，floor 729）
  cargo clippy --workspace --all-targets      ok（31 distinct locations，baseline 31）
  cargo fmt --all -- --check                  note（670 行既有 advisory 漂移，非阻断）
  result                                      all gates passed
```

### 14.5 明确未做 / 下一步

- `IMPLEMENTATION_STATUS §8.4` **全部测试补面项已收口**；§8.4 之后的主链下一步仍按
  `ROADMAP §13` 顺位：source blocking 边界诚实扩展、真 effect runtime 跨进程
  core adoption/ownership（现在身份/遥测证据已就位）、`caly-ipc` 通用 transport runtime
  （读写泵/timeout/生产会话统一）与剩余 backpressure producer；平台面（TUN/helper、
  keyring/SSRF/UDS 权限）与 storage schema/performance 仍在清单上。

---

## §15 第七十一轮：v0 wire 记录方言统一 + hello_ack 内容校验

### 15.1 量选（`ROADMAP §13` 顺位）

先按 §13 顺位量「caly-ipc 通用 transport runtime」（§13#3）：

- **生产缺口确为传输运行时**：`calyd.rs` 生产连接侧手写 TCP 帧循环（write_frame/read_frame
  L267-284），`serve_connection` 自解析 records + match kind；`caly-cli/bin/caly.rs` 手写
  Session（open/recv/send L33-161）+ hello()/op_request()/ask()/follow_stream()；caly-ipc 的
  ClientLoop/ClientSessionConfig/SessionMachine 均**生产未引用**（只有 session_and_frames.rs
  19 个单测）。
- **§13#2 已实现并标注**（`--effect-runtime real` 显式配对、写探针、资产预检，二元 E2E 在）。
- 因此定靶为 transport runtime 的**可证伪小切片**：连接两侧各写一份的 v0 wire 记录方言
  （hello/hello_ack/请求头）——量选时发现**真洞**：CLI 从不读 hello_ack 内容，只认帧 kind，
  一个自报协议 2.x 或换了编码的 daemon 也会被接受。

### 15.2 实现（单一实现、字节不变、一处刻意加宽）

- 新 `caly_ipc::dialect`（14 个 pub mod；crate 1,813→2,306 行；13 个单测）：
  `client_hello_records/payload`、`server_hello_session_json`、`server_hello_from_records`、
  `server_hello_ack_records`、`server_hello_ack_from_records`（→ `HelloAckView`）、
  `client_validate_hello_ack`、`request_payload`、`request_head_from_records`（→ `RequestHead`）。
- `calyd.rs`：encoding 协商、hello→ClientHello、ack 构造、请求头提取 4 处改用 dialect
  （键序、缺省值、宽容量——含未知 role→Admin、缺 request_id→0、缺 trace_id→calyd-wire——
  与旧手势逐字节一致）。
- `caly.rs`：`hello()`/`op_request()` 删除 → `handshake()`（发送 + **强制解析并校验** ack，
  connected 信息去 stderr）+ `request_payload(...)`；`ask()` 与 `follow_stream()` 均走它。
- **刻意加宽**：ack 在旧 3 键后回显 `major`/`minor`/`encoding`/`compression`——CLI 校验的
  素材；客户端解析严格（缺键=按名拒绝「不是 v0 方言」）。

### 15.3 证伪（`scripts/falsify_round71.py`，2 变异全咬，各 0.5s）

- M1（应咬）：CLI 跳过 `client_validate_hello_ack`（回到 v0「只看 kind」）→
  `caly_refuses_a_hello_ack_that_contradicts_the_session` 红（CLI 接受了谎言、exit 0）。
- M2（应咬）：`server_hello_ack_records` 丢回显键（回到旧 3 键 ack）→
  `server_hello_ack_records_keep_the_legacy_keys_first_then_echo_the_session` 红。

### 15.4 最终门禁结果

```text
python3 scripts/regenerate_test_census.py --check
  files=97 total=743 rows=97（dialect.rs 新文件 +13；caly_cli_e2e +1）

cargo test --workspace                       （全绿；随后 check.sh 门禁复跑）
./scripts/check.sh（连跑两次，结论一致）
  cargo check --workspace --all-targets       ok（0 warning）
  cargo test --workspace                      ok（743 passed / 0 failed，floor 743）
  cargo clippy --workspace --all-targets      ok（31 distinct locations，baseline 31）
  cargo fmt --all -- --check                  note（553 行既有 advisory 漂移；本轮 rustfmt 了
                                               calyd/caly/caly_cli_e2e，670→553）
  result                                      all gates passed
```

### 15.5 明确未做 / 下一步

- ClientLoop 接入与 UDS/双工读写泵（§13#3 主体）未做——本轮只收口其方言前置；
- source blocking 中断/资源回收边界（§13#1）仍未量；platform/security/CI-fuzz-perf 在清单上。

---

## §16 第七十二轮：blocking syscall 中断/回收语义（ADR-052）+ 对端挂起裁判

### 16.1 量选（`ROADMAP §13#1`）

§13#1 三小项逐一量过：

- **caller control 保持**：`source_worker::update` 链的检查点已很密（update admission /
  after HTTP fetch / before+after cached raw-body read / before 304 commit / before+after
  parse / CAS 前后——每阶段双探针）；生产 `StdHttp` connect/read/write 三处 socket
  timeout 全由 `CallerControl::timeout(peer) = min(deadline 剩余, peer 上限)` 产生。
  → **已落地，维护项，无新缺口**。
- **损坏形态参数化证伪**：第六十五轮（6.91）已收口 codec 层 6 形态 + worker/store 层
  3+1 形态；残余仅为「随新字段扩展覆盖」。→ **无新缺口**。
- **blocking syscall 中断/回收语义的明确决策**：语义只存在于两处实现注释
  （`CallerControl`：「a blocking syscall cannot observe a token until the OS returns」；
  `source_worker`：「outer post-call probe is the honest boundary」），**从未成文**；
  且最坏形态——**对端 accept 后挂住不响应**——没有端到端裁判：既有测试只覆盖
  「发起前已取消/已过期」与「连接被拒」，没有真正阻塞住 syscall 的形态。
  → **靶**。

### 16.2 实现（决策 + 裁判，不改行为）

- **ADR-052**（新增，`docs/adrs/`）：语义决策——①进行中 syscall 不可中断（诚实边界）
  ②有界回收 `min(caller deadline 剩余, peer 上限)`，deadline 优先 ③上限触发 →
  `IoFaultKind::Timeout` ④fault 后连接关闭（对端见 EOF，无跨请求复用）⑤阶段内只用
  注入 clock（不读宿主时钟）。本地文件 IO 不在范围（无 socket 超时概念，视作有界）。
- **裁判**（`caly-io-std/tests/http_contract.rs` +2）：
  - `a_stalled_peer_is_reclaimed_by_the_caller_deadline`：真 TCP 服务器 accept 后挂住；
    deadline 600ms、peer 上限 10s。断言 Timeout + 用时 < 5s（**min 语义证伪面**：若实现
    无视 deadline 只用 IO_TIMEOUT，则 10s 才回、红）+ 服务器侧读到 EOF（§2.4 回收）。
  - `a_cancel_during_a_blocked_read_does_not_claim_interruption`：fetch 在独立线程，
    服务器确认收到完整请求头后置位 cancel（此刻客户端必已阻塞在 status-line read）。
    断言 Timeout（非 Cancelled）+ 用时 >= 400ms（**不可中断诚实性**：不是「取消即中断」
    的假报告；`CancelToken` clone 共享同一 AtomicBool，跨线程置位有效）。
- 既有注释锚定 ADR-052（`CallerControl::timeout`、`source_worker` after-HTTP 探针）。

### 16.3 证伪（`scripts/falsify_round72.py`，2 变异全咬）

- M1（应咬）：`set_read_timeout(Some(control.timeout(IO_TIMEOUT)))` → `set_read_timeout(None)`：
  对端挂住 → 客户端永阻塞 → 裁判进程 30s 被杀（挂死 = 无有界回收；脚本用
  `start_new_session` + `killpg` 清进程组）。修复了 TimeoutExpired 无 .pid 的细节。
- M2（应咬）：read 错误映射 `Timeout` → `Unavailable`：1.1s 红（kind 断言）。

### 16.4 最终门禁结果

```text
python3 scripts/regenerate_test_census.py --check
  files=97 total=745 rows=97（http_contract 6→8；无新文件）

cargo test --workspace                       （全绿；随后 check.sh 门禁复跑）
./scripts/check.sh（连跑两次，结论一致）
  cargo check --workspace --all-targets       ok（0 warning）
  cargo test --workspace                      ok（745 passed / 0 failed，floor 745）
  cargo clippy --workspace --all-targets      ok（31 distinct locations，baseline 31）
  cargo fmt --all -- --check                  note（403 行既有 advisory 漂移；本轮 rustfmt 了
                                               http.rs/http_contract.rs/source_worker.rs，
                                               553→403；注意这几个文件有 async move，
                                               rustfmt 需 --edition 2021 在 crate 目录跑）
  result                                      all gates passed
```

### 16.5 明确未做 / 下一步

- UDS/双工 transport 本体仍未接入（§13#3 主体；届时直接沿用 ADR-052 §2 语义）；
- §13#1 剩余：损坏形态的「随新字段扩展」维护动作；
- 跨进程 core adoption/ownership（§13 后续）、capability 导入导出身份、platform/security 面。

---

## §17 第七十三轮：SSRF 网络访问边界（ADR-053 / RFC-0010 §11.1）

### 17.1 量选（`ROADMAP §13#4` 安全平台面头一项）

- `RFC_ADR_CRATE_INDEX.md` 明确登记「§11（SSRF）仍无对应实现」——查上证：
  `StdHttp` 的 Direct 路由对任意目标直连（`connect_timeout` 无地址面校验），
  `FetchReq` 无策略字段。RFC-0010 §11.1 四条（连接后校验 / loopback 限制 /
  link-local+metadata 限制 / 私有网段默认保守）零落地。
- 生产调用面仅 4 处（effect_std×3 + source_worker×1），改动可控；sim 契约测试全用
  `example.test` 假域名，不受影响 → **定靶**。

### 17.2 实现

- `FetchReq.scope: FetchScope { Default, AnyPeer }`（caly-io/port.rs）——Default 保守
  （仅 Public），AnyPeer 显式放行；9 个构造点（4 生产 + 5 测试）全部显式表态。
- `caly_io_std::{classify_peer_address, peer_allowed_in_scope, PeerClass}`：
  Loopback（127.0.0.0/8、::1）/ LinkLocalOrMetadata（169.254.0.0/16 含云 metadata、
  fe80::/10）/ Private（RFC-1918、CGNAT 100.64/10、ULA fc00::/7）/ Public。
- `StdHttp` 连接**后**取 `peer_addr()` 校验（connect_timeout(&SocketAddr) 无第二次 DNS，
  连接后校验即防重绑定的实际对端规则）；不达标：关闭 + `PermissionDenied`，summary
  指名类别与「RFC-0010 §11.1 SSRF boundary」，发生在写任何字节之前。
- 豁免：ActiveCore（RFC 管理地址明文豁免）；SystemProxy（代理地址=显式信任配置、
  目标不可见，明确记录不适用而非假装校验）；calyd core controller 探针
  （effect_std×2、real_core）用 Direct + AnyPeer（显式管理地址 = RFC 豁免用例）。
- 生产默认：`source_worker` 用户 locator = Default（内网/本机/元数据源默认按名拒绝
  = 安全优先的行为变更）。
- sim 不实现校验（无真实网络副作用）；共享契约不含 SSRF；字段仅记录。

### 17.3 证伪（`scripts/falsify_round73.py`，2 变异全咬，各 0.6s）

- M1（应咬）：`if !exempt_from_peer_check` → `if false && …`（摘除连接后校验）→
  loopback 拒绝测试红（请求到达服务器，0 字节断言失败）。
- M2（应咬）：分类把 `127.0.0.0/8` 判为 Public → 分类钉住测试与拒绝测试双红。

### 17.4 最终门禁结果

```text
python3 scripts/regenerate_test_census.py --check
  files=97 total=748 rows=97（http_contract 8→11；无新文件）

cargo test --workspace                       （全绿；随后 check.sh 门禁复跑）
./scripts/check.sh（连跑两次，结论一致）
  cargo check --workspace --all-targets       ok（0 warning）
  cargo test --workspace                      ok（748 passed / 0 failed，floor 748）
  cargo clippy --workspace --all-targets      ok（31 distinct locations，baseline 31；
                                               中途新增 1 个 unused_mut 已修回）
  cargo fmt --all -- --check                  note（380 行既有 advisory 漂移；本轮 rustfmt 了
                                               io-std/io/sim/daemon/engine 相关 6 文件，
                                               403→380；async move 文件需在 crate 目录用
                                               --edition 2021）
  result                                      all gates passed
```

### 17.5 明确未做 / 下一步

- redirect（RFC-0010 §11.2 SHOULD）：当前实现不跟随重定向 → 无自动跨 origin 请求的
  泄漏面，条款因语义不适用（§8.8 如实记录，不声称已实现）；若未来引入跟随需
  重新评审。
- keyring、UDS 权限（随 transport runtime）、导入限额、Platform/TUN/helper 仍在清单；
- §13#3 transport 主体（ClientLoop 接入 + UDS 泵）仍为最大未动项；
- 跨进程 core adoption/ownership 未动。

---

## §18 第七十四轮：Fs 批量 stat 面（ADR-054 / stat_many）

### 18.1 量选（`ROADMAP §13#5` schema/performance 头项）

- **ClientLoop 接入（§13#3 最小闭合）先量后弃**：`ClientLoop` 是同步状态机
  （open_handshake/observe_hello_ack/send_request_frame/observe_stream/apply_ack），
  但其 `send_request_frame` 收 **typed `caly_api::Operation`**，而 v0 wire 是字符串 op +
  各 op 专属 extra 记录（profile_id/job_id/grace_period_ms/max_lines…）——两层之间的
  双表接线是新 API 增长而非「复用现有循环」，工程量大、可证伪面弱（第 71 轮已字节钉过
  wire 形状）。**不选**。
- **stat_many 是已登记债务**：`ADR-035 §3`（拒富 list 时写明「批量 stat 属于后续
  stat_many 的优化」）与 `§6bis-quater`（第十七轮 dated 落地时「stat_many 因此是这条
  链上明确记下的下一步优化」）；现状：`object_records` 对 N 条对象记录每次一个 stat 端口
  调用；`Fs` trait 实现者仅 2 个；GC 引用判定已是内存集合（无 stat 热点，不涉）。
  → **定靶**。

### 18.2 实现

- `Fs::stat_many(&[VPath], ctx) -> Vec<Option<Meta>>`：同长同序、每项 == 逐条 stat、
  Err=整批失败、空输入=空输出、**一次逻辑端口调用**（SimFs 单点 `maybe_fail("fs.stat_many")` +
  单次锁内批查询；StdFs 底层循环但抽象为一次调用）。
- `SimFs` 的 `stat`/`stat_many` 共用同一 `sim_meta` 判定函数——「每项等于逐条 stat」
  是同一答案而非巧合。
- `fs_store.rs`：`object_records` 改为 list → 逐条 read+decode（`read_object_record_undated`）
  → 一次 `stat_many` → 逐条 `date_object`；`dated` 拆出纯函数 `date_object`
  （which-ever-is-newer 不变），单对象路径（get/put/open）保持单次 `dated`。
- 3 个测试 wrapper（content_sweep ProbeFs、facade_store_ctx ProbeFs、新增 CountingFs）
  同步实现 stat_many（编译期强制）。

### 18.3 证伪（`scripts/falsify_round74.py`，2 变异全咬）

- M1（应咬）：`object_records` 批量退化回逐条 stat → 计数裁判红（stat>0），1.4s；
- M2（应咬）：`SimFs::stat_many` 返回长度错 → 共享契约红，0.6s。

### 18.4 最终门禁结果

```text
python3 scripts/regenerate_test_census.py --check
  files=98 total=750 rows=98（stat_many.rs 新文件 +2；契约项不增 test 计数）

cargo test --workspace                       （全绿；随后 check.sh 门禁复跑）
./scripts/check.sh（连跑两次，结论一致）
  cargo check --workspace --all-targets       ok（0 warning）
  cargo test --workspace                      ok（750 passed / 0 failed，floor 750）
  cargo clippy --workspace --all-targets      ok（31 distinct locations，baseline 31）
  cargo fmt --all -- --check                  note（331 行既有 advisory 漂移；本轮 rustfmt 了
                                               io/sim/io-std/storage/daemon 相关 8 文件，
                                               380→331）
  result                                      all gates passed
```

### 18.5 明确未做 / 下一步

- `list` 形状不动、递归列举/孤儿清扫（需再一条 ADR）未做；GC 引用判定未涉；
  复杂度类未变（仍 N 次 read+decode——ADR-035 自己写明）；
- §13#3 transport 主体（ClientLoop 接入 + UDS 泵，接 typed 层回程）仍最大；
- storage schema migration、artifact golden、CI/fuzz/perf 待后续；
- 跨进程 core adoption/ownership 未动。

---

## §19 第七十五轮：source-index 锚格式校验缺口补面

### 19.1 量选（`ROADMAP §13#1` 残余）

候选逐一量过，多数排除：

- ClientLoop 接入（§13#3）：`send_request_frame` 收 typed `Operation`，v0 wire 是字符串
  op + 各 op 专属 extra——两层双表接线，新 API 增长而非复用（第 74 轮同样结论）。
- serve_connection 帧循环重构成状态机驱动：行为已由 `calyd_wire` 34 测试钉住，重构
  不产生新裁判（证伪价值低）。
- 孤儿内容清扫：已有 `plan_orphan_content`/`sweep_orphan_content`/`list_content`
  （content_sweep.rs 测试）；解压比例限制（RFC §9.2）无输入面（订阅不经过解压）；
  keyring std 实现要外部依赖（workspace 只授权 serde_json）；schema migration 框架在
  测试用假钩子——真实 v2 迁移是大决策。
- **定靶**：§13#1「沿 durable projection 扩展损坏形态参数化拒启」——量选发现第 65 轮
  的「残余仅为随新字段扩展」并不完整，有两类**旧字段空白**：
  ① `decode_source_index` 对 `raw_object_digest` **只查非空不查锚格式**——而该字段是
     worker 后来 `storage.get(record.raw_object_digest)` 的**寻址锚**，与 `raw_content_sha256`
     完全不对称；缺口实锤：`record_codec.rs` 的 fixture 自己就带着
     `sha256:raw-object`（非锚）且全部测试通过。
  ② 三个 cache digest（`normalized_digest`/`provenance_digest`/`diagnostics_digest`）
     畸形值虽被拒绝（内容锚比较不等），但诊断是「does not match its content anchor」
     ——说「你改了值」，不是「这不是锚」；ADR-035 的规则是重启不该猜哪部分坏。

### 19.2 实现

- `record.rs::decode_source_index`：`raw_object_digest` 加 `source_anchor` 检查（与
  `raw_content_sha256` 同规则，错误按名「is not a sha256 anchor」）；三个 cache digest
  在 verify 前加同样的按名格式检查（verify 保留，锚匹配语义不变）。
- fixture `raw_object_digest` 改为合法锚（`sha256_digest(b"raw-body")`——与
  `raw_content_sha256` 同值，即生产语义：CAS 对象内容就是 raw body）。
- 生产写入侧恒为 `sha256:` 前缀（`sha256_digest`），零兼容风险；存储层重启打开遇到
  旧非法记录 → 按名拒绝（既有「重启坏记录拒绝」特性，不新增放宽）。

### 19.3 证伪（`scripts/falsify_round75.py`，2 变异全咬）

- M1（应咬）：删 `raw_object_digest` 格式检查 →
  `source_index_rejects_a_raw_object_digest_that_is_not_a_sha256_anchor` 红（0.8s）；
- M2（应咬）：删三个 cache digest 格式环 →
  `source_index_rejects_malformed_cache_digests_by_name` 红（0.9s，诊断退回 mismatch）。

### 19.4 最终门禁结果

```text
python3 scripts/regenerate_test_census.py --check
  files=98 total=752 rows=98（record_codec 17→19；无新文件）

cargo test --workspace                       （全绿；随后 check.sh 门禁复跑）
./scripts/check.sh（连跑两次，结论一致）
  cargo check --workspace --all-targets       ok（0 warning）
  cargo test --workspace                      ok（752 passed / 0 failed，floor 752）
  cargo clippy --workspace --all-targets      ok（31 distinct locations，baseline 31）
  cargo fmt --all -- --check                  note（331 行既有 advisory 漂移；record.rs/
                                               record_codec.rs 已规范，值不变）
  result                                      all gates passed
```

**门禁插曲（三起，均已记录归档）**：

1. **§4.155 已登记旧患**（第 b 遍）：`a_fetch_through_the_active_core_really_rides_the_core`
   处红——mihomo direct 模式经 mixed inbound 访问 `http://example.com/` 得 502（期望 200）。
   失败日志副本 `/home/user/rt75_502_failure.tests.log`；定向重跑 1/1 绿（10.9s）。第
   66/69 轮为同一环境波动，不降级不抬高。
2. **新发现——R72 judge 的真实竞态**（第 d 遍）：`a_cancel_during_a_blocked_read_
   does_not_claim_interruption` 红——期望 `Timeout` 实得 `Cancelled`（"caller cancelled
   before HTTP response headers"）。诊断见下 §19.6；修复后（第 f/g 遍）两遍完整门禁全绿
   且日志逐字节一致。失败日志副本 `/home/user/rt75_cancel_failure.tests.log`。
3. **§4.158 真核 cutover 瞬态**（第 e 遍）：`real_apply` 的 sing-box direct 半场
   apply `failed`（`UNAVAILABLE`，"effect execution failed (apply.recovered)"，停在
   `effects.cutover.started step=4 net_effect_started=false`）；无残留核心进程，
   未改代码定向重跑 `real_apply` 10/10 绿（38.6s）。同 §4.155 族（真核 E2E 环境敏感），
   处置同：留日志、定向重跑、完整 gate 复跑。

**最终门禁（第 f/g 遍，修复后）**：两次 exit=0、`diff` 空（752 / 31 / 331）。
`falsify_round72.py` 复验：M1 挂死签名（30s，stalled 裁判保留）+ M2 1.2s 红，全咬。

### 19.5 明确未做 / 下一步

- 残余仍为「随新字段扩展覆盖」（§8.4 首条，今回修正了它「仅此而已」的过时表述）；
- §13#3 transport 主体（ClientLoop typed 层接线）仍最大未动项；
- schema 真实迁移、CI/fuzz/perf、跨进程 core adoption/ownership 未动。

### 19.6 门禁发现：R72 judge 的既有竞态（`a_cancel_during_a_blocked_read`）

- **症状**：完整门禁第 d 遍红——期望 `IoFaultKind::Timeout`（有界回收）实得
  `Cancelled` + "caller cancelled before HTTP response headers"（即时返回）。其余 751
  绿；该测试 R72 至 R74 均曾通过，属低概率已存在竞态。
- **诊断**：R72 的同步假设「stalled server 收到完整请求头 ⇒ 客户端已阻塞在
  status-line read」是近似——`flush` 返回到 `read_line` 入 syscall 之间有两个阶段
  边界检查（`HTTP response headers`；`read_head` 顶部的 `the HTTP status line`），
  fetch 线程可在该窗口被调度出去（gate 在 2 核/宿主 oversubscription 下）。
  取消落窗口 = 边界前取消 → `Cancelled` 是**诚实**答案（ADR-052 §1 只禁止声称在途
  syscall 可中断；`fault.rs` 的边界检查前置本就是设计），但 **不是被测交错**。窗口
  外部不可观测（无客户端侧信号）。
- **复现**：独立跑 40 次全过（窗口需争用）；6 并发 × 20 轮（120 次）**32 次红（27%）**
  → 竞态确认；宿主负载来自沙箱多租户，非本仓可控。
- **修复（judge 侧，不动实现）**：重试闭合——①`Timeout`+摘要含 "read status line"+
  用时 ≥400ms+对端 EOF → 通过（被测交错）；②`Cancelled`/`Timeout`+摘要点名
  `HTTP response headers`/`before the HTTP status line` → 诚实的非目标交错，记录并
  重试（≤10 次，健康实现 P(耗尽)≈0.27^10≈2e-6）；③其余答案立即红。声称在途中断的
  回归**每次**落入 ② → 上限必红（确定性失败，不遮蔽回归）。fetch 答复等待改为
  **5s 有界**（原无界 `join`：无界回收回归会挂死门禁；现 5s 快红——M1 变异下实测
  5.00s 红；`falsify_round72.py` M1 的 30s 挂死签名由 stalled 裁判保留，复验仍咬）。
- **验证**：修复后真实门禁条件（全量 check.sh）连跑两遍 **exit=0 且日志逐字节一致**
  （752 / 31 / 331）；修复前同条件 120 次并行压测 32 红 → 修复后 0 红。
- **归档**：`ONBOARDING_NOTES §4.157`（新条目：对端可见事件≠客户端内部状态的判据
  准则）；失败日志 `/home/user/rt75_cancel_failure.tests.log`。测试数不变（752）。

## §20 第七十六轮：v0 wire 请求形状单源化

### 20.1 量选（`ROADMAP §13#3` 切片）

- 主体（transport/ClientLoop）仍是双表接线，不选；「wire 请求形状」是三处知识
  （CLI 手拼 extras / daemon 门字段表 / 文档）各持一份的真实漂移面。
- 缺口实锤（falsify 先行）：把 op 名 typo 成 `profiles.applyx`、或把 apply 的记录名
  `profile_id` 写成 `profile`——编译器与既有测试都不红，只有运行时真 daemon 门
  （UNSUPPORTED / USAGE）拒收。形状错误编译不出来，所以裁判必须是真门。

### 20.2 实现

- `crates/caly-ipc/src/wire_ops.rs`：`WireRequest{name,extras}` + 13 op 编码表 +
  未知 op 按名拒绝 + bool `"true"`/`"false"`；单测 5 条（每 op 契约、按名拒绝、
  optional iff `Some`、bool 无小数）。
- `crates/caly-cli/src/bin/caly.rs`：删手拼 extras 表；子命令表仍是唯一手写表
  （13 op → typed `Operation` 构造 + `Err` 汇总，`main` 返回 `ExitCode` 故包闭包）；
  `idempotency_key` 仅 keyed ops 且非空时追加；ask/print 以 `wire.name` 分发；
  `wire_number`/`wire_required_number` 客户端 usage；`JobId` 用 `wire_required_number`。
- `crates/caly-daemon/tests/calyd_wire.rs`：扫门判官
  `every_request_op_encoded_by_the_single_source_passes_the_daemons_door`——13 个
  `wire_request` 输出逐一送进真 calyd 门（KIND_REQUEST + request_payload），排干
  KIND_STREAM_DATA/END 流帧后断言非 USAGE/UNSUPPORTED 且 request_id 回声。
- `lib.rs`：`pub mod wire_ops; pub use wire_ops::*;`（否则 `calyd_wire` 找不到
  `wire_request`）。

### 20.3 证伪

- `scripts/falsify_round76.py`：M1（op 名 typo）/ M2（apply 记录名 `profile_id`→
  `profile`）均被真门咬（各 ~1.3-1.7s，Popen + start_new_session + killpg）。
- **restore 漏洞（过程缺陷）**：首版 `apply(backup_taken, …)` 在 M1 restore 删除备份后
  M2 不再备份——M2 变异残留进树；judge 全红只证明咬力，`check.sh` tests 门红才揪出
  （`wire_ops` apply 单测 `left=[("profile", …)]` vs `right=[("profile_id", …)]`）。
  修复：每次变异前无条件快照；复跑双咬 + 内容级核对干净。归档 `ONBOARDING §4.159`。

### 20.4 验证

- `cargo test -p caly-ipc --lib wire_ops`：5 绿；`calyd_wire`：35 绿；
  `caly_cli_e2e`：22 绿；`cargo test --workspace`：758 绿。
- `./scripts/check.sh`：**all gates passed**（758 / floor 758 / clippy 31 / fmt 331 advisory）。
- `regenerate_test_census.py`：files=99 total=758（新行 `crates/caly-ipc/src/wire_ops.rs`）。

### 20.5 归档

- `ONBOARDING_NOTES §4.159`（restore 漏洞）、`§6.102`（第七十六轮表行）；
  `IMPLEMENTATION_STATUS §8.11`；`CENTERLINE_PROGRESS §4`（当前快照小节）；
  `ROADMAP` 源码级契约一行的计数与描述。

## §21 第七十七轮：wire 形状对称闭包

### 21.1 量选（`ROADMAP §13#3` 第二切片）

第七十六轮封住编码侧后，量选直接暴露「单源」的另一半——三处实证缺口：

- `calyd.rs` 的解码 match 表 213 行/20 臂仍是手写的**第二份字段知识**（编码表在
  `wire_ops`，解码表在 daemon，中间只隔着 e2e 测试）；
- `caly.rs::follow_stream` 的 open/resume 两形状**仍在手拼 extras**（第七十六轮的
  `wire_request` 只覆盖了主 ask 路径，流路径是漏网——resume 的 `stream_id`+`resume=true`
  与 open 的 `job_id`+`from_event_index` 都没有 typed 载体）；
- daemon 的 UNSUPPORTED 文案列举 12 个 op，**漏掉自己支持的 `jobs.follow-stream`**
  （文案与 13-op 表不一致）。

transport 主体（UDS/双工调度）照例量弃（双表接线、无新裁判）；「编码器与解码器互为
镜像」才是可证伪的主张：此前没有任何裁判能证明或证伪它。

### 21.2 实现

- `crates/caly-ipc/src/wire_ops.rs`：
  - `decode_request(records) -> Result<DecodedRequest, WireDecodeError>`——12 个无状态 op
    的 records→typed `Operation`（字段名/布尔 `"true"`/数字解析与编码表严格镜像）；
  - `wire_stream_request`/`decode_stream_request`——`StreamRequest::{Open,Resume}` 双形状
    的编码与解码（此前 CLI 手拼、daemon 手读）；
  - `WIRE_OPERATION_NAMES: [&str; 13]`——文档名单（daemon 的 UNSUPPORTED 文案改由它
    生成，补回漏写的 `jobs.follow-stream`）；
  - `WireDecodeError::{UnknownOperation, MissingField, BadNumber}`——按名报字段
    （`codec` 模块已有 `DecodeError`，取名带 `Wire` 前缀避免 glob 冲突）。
- `crates/caly-daemon/src/bin/calyd.rs`：删除 213 行手写解码表（含 `numbered_bound`
  本地函数）；改调 `decode_request`，门内只留会话状态（`streams` 表查询）、
  错误→refusal 文案映射（`decode_usage_summary`，逐字保持——35 条 e2e 断言按 contains
  钉住措辞）、NOT_FOUND/UNSUPPORTED/USAGE 分类。
- `crates/caly-cli/src/bin/caly.rs`：`follow_stream` 删除手拼 extras，改
  `wire_stream_request`（main 分派处已校验数字，解析失败仅剩防御路径）。

### 21.3 证伪

- `scripts/falsify_round77.py`：M1（编码侧 resume 记录名 `stream_id`→`stream_id_x`）→
  round-trip 裁判红；M2（解码侧 apply 记录名 `profile_id`→`profile`）→ round-trip 红
  **且**真 daemon 门红（daemon 现经 decode 解码）。双咬各 ~0.3s，restore 后内容级核对
  干净（sha256 比对 + grep 键名 + 无 stray bak）。
- 过程自纠：falsify 首版把「judge 绿 = 没咬」写成 `not bit`，双咬时 exit 1——同轮
  修复为 `bit`（与 round 76 脚本一致），未成形状。

### 21.4 验证

- `cargo test -p caly-ipc --lib wire_ops`：10 绿（原 5 + 新 5 对称裁判）。
- `calyd_wire`：35 绿；`caly_cli_e2e`：22 绿（解码/流迁移行为零变化）。
- `./scripts/check.sh`：**all gates passed**（763 / floor 763 / clippy 31 / fmt 331 advisory）。
- `regenerate_test_census.py`：files=99 total=763（+5 全在 wire_ops）。

### 21.5 归档

- `IMPLEMENTATION_STATUS §8.12`；`ONBOARDING_NOTES` 轮次表 §6.103（无新增 §4 条目）；
  `CENTERLINE_PROGRESS §4`（当前快照小节）；`ROADMAP` 源码级契约与门禁行计数更新；
  残余登记：`§13#3` transport 主体仍为最大未动项。

## §22 第七十八轮：doctor runtime 投影可达化

### 22.1 量选

- 多候选量弃（transport 主体第三次量弃：双表接线无新裁判；RuntimeDriver 真接入：
  mihomo/singbox 实现是硬编码 skeleton stub 且**全库无消费者**——接入前先要立消费点；
  schema migration 大决策；CI 工作流无法本地验证）。
- **定靶**：`diagnostics.doctor` 的 `include_runtime`——「实现了但接口不可达」：daemon
  分支在（`query/diagnostics.rs`），五处 harness 测试断言过 true 形状，但 v0 wire 形状
  从未携带该记录（编码器 `plain`、解码器固定 `false`、`caly doctor` 硬编码 `false`，
  而同 crate 库路径 `caly-cli/src/driver.rs` 用 `true`——同一客户端两种默认）。

### 22.2 实现

- v0 wire 加宽：`diagnostics.doctor` 可选记录 `include_runtime`（`"true"` 生效、
  缺席=false，bool 族同款语义）。
- `wire_ops.rs`：encode 恒写 `"true"`/`"false"`、decode 按名读（同 `dry_run` 先例）；
  opt-in round-trip 单测（编码写出记录→解码读回同一 typed 请求）。
- `caly.rs`：`doctor --runtime` 开关（默认 false，向后兼容）。
- `calyd_wire.rs`：门裁判 `a_doctor_request_can_opt_into_the_runtime_projection`——
  同一真门两个请求：默认形状 summary 不含投影，opt-in 形状 summary 命名
  `runtime active_profile/engine_lifecycle`（断言用转义无关 token——oracle 的最小
  reader 故意不 unescape）。
- `caly_cli_e2e.rs`：`caly_doctor_runtime_flag_names_the_runtime_projection`（真二进制，
  默认不加宽 + `--runtime` 加宽）。

### 22.3 证伪

- `scripts/falsify_round78.py`：M1（解码臂丢记录）→ round-trip 红 **且** 真 daemon 门
  红（daemon 经 decode 解码，手写 opt-in payload 的 summary 不再加宽）；M2（编码臂退
  `plain`）→ opt-in round-trip 红。双咬各 ~0.4s，restore 后内容级核对干净。

### 22.4 验证

- `cargo test -p caly-ipc --lib wire_ops`：11 绿；`calyd_wire`：36 绿；
  `caly_cli_e2e`：23 绿；`cargo test --workspace`：766 绿。
- `./scripts/check.sh`：**all gates passed**（766 / floor 766 / clippy 31 / fmt 331 advisory）。
- `regenerate_test_census.py`：files=99 total=766（+3：wire_ops/calyd_wire/cli_e2e 各 1）。
- 修订：CENTERLINE 的 §4 快照 check.sh 注释行此前残留 758 数字（门禁判官只查
  「这 N 个断言」行，注释行不在检查范围）——本轮一并修正为 766。
- 过程教训（与第 76/77 轮同族）：falsify restore 回相同内容后，`cargo test` 复用旧产物
  的现象再次出现（wire_ops 的 opt-in 单测在单跑时绿、workspace 全量红且 extras=[]——
  运行的是变异态编出的旧二进制）；处置：`touch` 源码强制重编后全绿。收口惯例再确认：
  falsify 之后、门禁之前必须有一次内容级 + 强制重编级核对。

### 22.5 归档

- `IMPLEMENTATION_STATUS §8.13`；`ONBOARDING_NOTES` 轮次表 §6.104（无新增 §4 条目）；
  `CENTERLINE_PROGRESS §4`（当前快照小节）；`ROADMAP` 计数行更新；残余登记：
  RuntimeDriver（skeleton stub、无消费者）与 §13#3 transport 主体。

## §23 第七十九轮：EXIT_CODES 表↔代码对照裁判

### 23.1 量选

- RuntimeDriver 真接入再量：mihomo/singbox 实现是硬编码 stub 且**全库无消费者**——
  接入前须立消费点（留作大切片）；transport 主体第四次量弃；fmt/CI 收口是维护轮
  （无 falsify 对象）；schema migration 是大决策。
- **定靶**：`EXIT_CODES.md` 表内容↔代码无对照——文档门禁（`caly-arch-test`）只查
  形状（列数/分隔行/编号），不查内容；把表里 `CURSOR_STALE` 改名或把代码
  `Timeout=11` 改成 21，所有既有门禁照常全绿。运维脚本按文档写重试策略，漂移
  静默伤害的是脚本。

### 23.2 实现

- `crates/caly-cli/tests/exit_code_table.rs`（纯文档读取裁判，不 spawn 进程）：
  最小解析器读表（`| N | NAME | 说明 |`，名字取首个反引号 token——`CANCELLED` /
  interrupted 的后缀不算名字；解析先 split 后剥反引号，闭合反引号在斜杠前）。
  断言一：文档 (名字→数字) map == `from_error_code` 的 (as_str→数字) map（双向
  双射，BTreeMap 相等）；断言二：`ExitCode` 值集合 == 0..=16、唯一、无遗漏。
  行数断言 14 == ErrorCode 变体数。

### 23.3 证伪

- `scripts/falsify_round79.py`：M1（文档侧 `CURSOR_STALE`→`CURSOR_STALEX`）→ 对照
  红；M2（代码侧 `Timeout=11`→`Timeout=21`）→ 范围完整性与映射双红（`21` 对不上
  文档的 `11`）。双咬（0.1s/0.9s），restore 后内容级核对干净。
- 首版 M1 needle 撞正文（`CURSOR_STALE` 在表格行与 §重试建议各出现一次）——改用
  带 `| 14 |` 前缀的表格行锚，同轮自纠。
- restore 的「内容级干净」后来被证明不够：copy2 保留原 mtime 留下 stale
  fingerprint 时间炸弹，见 §23.5.1（终跑排雷）。

### 23.4 验证

- `cargo test -p caly-cli --test exit_code_table`：2 绿；`cargo test --workspace`：768 绿。
- `regenerate_test_census.py`：files=100 total=768（新文件
  `crates/caly-cli/tests/exit_code_table.rs`，+2 断言）。

### 23.5 终跑排雷（三次，全部在未改任何被证伪语义的前提下）

1. **stale fingerprint 时间炸弹（真 bug，在 falsify 脚本里）**：终跑首跑 tests 门红，
   裁判右值 `TIMEOUT=21`、范围断言「11 缺失」。源码 grep 却是 `Timeout = 11`——根因：
   `falsify_round79.py` 的 restore 用 `shutil.copy2`（保留**原 mtime**），M2 恢复后
   exit_code.rs 的 mtime 回到旧值（09:17），比 M2 期间编译出的含 `21` 的 rlib
   （11:54）**旧** → cargo 判定 lib 新鲜、永不重编，`21` 从此泄漏进一切复用仓库
   target 的构建。这正是 R78 记录过的 stale-fingerprint 陷阱，被 restore 的
   mtime 回拨重新引爆。修复：`restore_one` 在 copy2 恢复后 `os.utime(path, None)`
   把 mtime 拨到当前；现场对 `exit_code.rs`/`EXIT_CODES.md` 各 utime 一次排雷，
   重跑裁判 2/2 绿。修好的脚本重跑 falsify：双咬（0.1s/0.6s）exit 0，digest
   仍为 c6ec314d5152…/9b83f6e461e6…，且 restore 后 mtime 已是当前时间。
   教训：工作树的「内容干净」不等于「构建干净」——拷贝式恢复必须同时恢复
   时间戳的单调性。
2. **clippy 基线违例（新测试自身）**：`workspace_root()` 返回
   `std::path::PathBuf` 触发仓库 `disallowed_types`——clippy 位置数 31→32。
   修复：改返回 `&'static std::path::Path`（`parent()` 保持生命周期），读文档改
   `format!("{}/docs/…", root.display())`，全程无 PathBuf。clippy 回基线 31。
   （首版测试过审时该 lint 未计入位置数——ratchet 只数 `-->` 位置，实际是以
   终跑为准。）
3. **real_apply 502 瞬态（环境，非回归）**：第二跑 tests 门红，
   `the_applied_core_names_itself_and_counts_its_own_traffic` 经真核代理访问
   example.com 得 502（期望 200）。与 §4.155/§4.158 同族（真核 E2E 依赖出口网络）。
   未改任何代码隔离重跑该测试 10/10 绿，随后全量重跑全绿。
4. 顺带：终跑期间临时未 rustfmt 测试文件使 fmt advisory 331→343，rustfmt 后
   回 331（advisory 数值本身在终跑中只能来自真实改动）。

### 23.6 终跑结论

- `./scripts/check.sh`：**all gates passed**（768 / floor 768 / clippy 31 /
  fmt 331 advisory，95.3s）。数列与 §23.4 预记一致，但达成路径是三连排雷后的
  第三次全量跑——门禁结论以本节为准。

### 23.7 归档

- `IMPLEMENTATION_STATUS §8.14`；`ONBOARDING_NOTES` 轮次表 §6.105（无新增 §4 条目）；
  `CENTERLINE_PROGRESS §4`（当前快照小节）；`ROADMAP` 计数行更新；残余登记：
  `ERRORS.md`/ApiError↔ErrorCode 的同类对照裁判（尚未有）、RuntimeDriver 消费点、
  §13#3 transport 主体。

## §24 第八十轮：ERRORS.md §4/§4.1 名称闭包裁判

### 24.1 量选

`docs/ERRORS.md §4` 声明 v1 公共稳定错误码最小集合（12 个码 × Category × Retryable），
`§4.1` 声明 6 个保留码位；`caly_api::ErrorCode`（14 变体）是实现。文档门禁只查表格
形状，两边名称无任何对照——enum 加未入档码、§4 拼错码名、保留码偷偷转正都静默通过。
与 R79 同族，但量选撞见关键边界：代码侧**没有**按码的分类/可重试权威——(category,
retryable) 由每个 `ApiError::new` 构造点逐例裁定（`error_map.rs` 是「错误类型→
ApiError」的逐点映射，不是按码分类表），且至少三处与 §4 相左：`map_handshake_error`
（InvalidClientName→ConfigInvalid 归 User）、`map_session_loop_error`（RequestInvalid
→ConfigInvalid 归 User）、`error_identity.rs:121`（未知 job 的 follow = CONFLICT+User，
被测试钉住）。因此本轮不发明权威，只做「两边都已存在」的名称闭包；Category/Retryable
列的对照需要 (code→category) 权威与 RetryPolicy 型，登记为 §8.15 残余。

### 24.2 实现

`crates/caly-api/tests/error_doc.rs`（纯文档读取裁判，不 spawn 进程；无生产代码改动）。
闭包是**方向性**的（首跑把「全等」写法当场纠正，见 24.4）：
① 已实现 ⊄ §4∪§4.1 = 无名码；② §4 稳定码 ⊄ 已实现 = 文档有不存在的码；
③ 保留↔实现中点钉死：恰好 `CANCELLED`+`INTERNAL` 已实现（其余四个保留位实现前必须
转正或改文）；④ §4 行数 12、§4.1 六项、两集合不相交；⑤ §4 每行 Category ∈ §3 七
分类表、Retryable ∈ {否,视场景,可能,是}（文档内部自洽）；⑥ `ALL_CODES`+穷举
`match` 见证：enum 加新变体 → 测试编译失败，列表不会悄然过时。

### 24.3 证伪

`scripts/falsify_round80.py` 4 变异全咬：
- M1 文档侧 §4 `CONFIG_INVALID`→`CONFIG_INVALIDX`（闭包红，0.1s）；
- M2 文档侧给 §4 加 `RATE_LIMITED` 行（保留位未除名：行数 13 + 中点红，0.1s）；
- M3 文档侧 §3 分类名 `Config`→`Configs`（§4 行 Category 落空，0.1s）；
- M4 代码侧 `as_str` 把 `Timeout` 输出为 `TIMEOUT_`——R80 闭包红 **且** R79
  EXIT_CODES 裁判也红（1.3s/4.0s），首次记录跨轮裁判协同：一个漂移被两层裁判同时抓住。
restore 内建 `os.utime(path, None)` mtime 单调（R79.5.1 教训直接固化），4 变异后
内容级 digest 干净、无 `.r80bak` 残留。

### 24.4 自纠

首版闭包写成「已实现 == §4∪§4.1」全等——首跑即红：§4.1 的四个保留码
（RATE_LIMITED/NOT_FOUND/ALREADY_EXISTS/INTERRUPTED）**按设计**未实现，全等断言
把「保留」错当成「已文档化即已实现」。改为方向性闭包 + 中点钉死。教训：文档的
「保留/计划」集合与「现状」集合是**两种语法**，闭包必须按各自的蕴含方向写。

### 24.5 验证与归档

- `cargo test -p caly-api --test error_doc`：2 绿；census files=101 total=770；
  TEST_FLOOR 768→770；`./scripts/check.sh` all gates passed（770/770、clippy 31、
  fmt 331 advisory）。
- `IMPLEMENTATION_STATUS §8.15`（残余三条：(code→category) 权威缺失与三处相左未裁决、
  retryable 4 值 vs bool 需 RetryPolicy 型、§4.1 措辞与 CANCELLED/INTERNAL 已投入
  使用的张力）；`ONBOARDING` 轮次表 §6.106（「不做」标题顺延 6.107）；
  `CENTERLINE_PROGRESS §4`（当前快照小节，R79 降为上一轮快照）。

## §25 第八十一轮：EXIT_CODES §2 名字列 + 双胎名一致裁判

### 25.1 量选

R79 的残余之一：`EXIT_CODES.md §2` 表 1（0/1/2）「只做数字存在性对照（无名字列）」——
§2 只有 `0/1/2` 数字与含义，码名只存在于枚举（`Success`/`GeneralFailure`/`Usage`），
文档侧数字对不上、代码改名全静默。量选又暴露一层：`ExitCode`（caly-cli）与
`ErrorCode`（caly-api）各有一套名字，3..=16 经 `from_error_code` 指**同一字符串**，
但两套 `as_str` 各写各的、无裁判钉住——任何一侧漂移都会让「CLI 退出名」与
「API 错误名」分裂，而两边各自的裁判只看自己那一侧。

### 25.2 实现

- 生产代码：`crates/caly-cli/src/exit_code.rs` 加 `ExitCode::as_str()`（17 臂；
  3..=16 的字符串与 `ErrorCode::as_str` 逐字相同，由裁判钉住）。
- 文档：`EXIT_CODES.md §2` 表加「名称」列（`0 SUCCESS` / `1 GENERAL_FAILURE` /
  `2 USAGE`），与原含义列并存。
- 裁判：`exit_code_table.rs` +1 条（`the_zero_one_two_names_are_documented_and_twinned`）：
  ① §2 (数字→名称) map == 枚举 (as_i32→as_str) map；② 对全部 14 个 ErrorCode 断言
  `ExitCode::as_str(from_error_code(ec)) == ec.as_str()`。
- **必要配套**：R79 裁判的 `parse_error_code_table` 按全文扫描时靠「2 格跳过」避开
  §2；§2 加名字列后变 3 格会被误收（地图会混入 0/1/2）。收窄为只解析
  「## 3. 稳定业务退出码 ↔ ## 4. 映射规则」区段；R79 的 M1/M2 变异锚点都在 §3
  表内、不受影响，旧证伪脚本重跑仍 2/2 咬（0.1s/0.7s）。

### 25.3 证伪

`scripts/falsify_round81.py` 3 变异全咬：
- M1 文档侧 §2 `SUCCESS`→`SUCCEED`（R81 裁判红，0.1s）；
- M2 代码侧 `ExitCode::Usage`→`USAGE_`（R81 裁判红，0.6s）；
- M3 代码侧 `ErrorCode::Timeout`→`TIMEOUT_`——R81 双胎断言红 **且** R80 闭包裁判红
  （0.2s/2.3s），第二次记录跨轮裁判协同（第一次在 R80 的 M4）。
restore 内建 mtime 单调，digest 干净，无 `.r81bak`。

### 25.4 验证与归档

- `cargo test -p caly-cli --test exit_code_table`：3 绿；`python3
  scripts/regenerate_test_census.py`：files=101 total=771 rows=101；TEST_FLOOR
  770→771；`check.sh` all gates passed（771/771、clippy 31、fmt 331 advisory）。
- 规模实测跟新：.rs 258 / 90,243 行 / 91 executable targets（22+69）/ 93 篇 Markdown
  （§8.14 的「87」是旧值，本轮一并纠正）。
- `IMPLEMENTATION_STATUS §8.16`（§8.14 残余「§2 无名字列」正式关账）；
  `ONBOARDING` 轮次表 §6.107（「不做」标题顺延 6.108）；`CENTERLINE_PROGRESS §4`
  （当前快照小节，R80 降为上一轮快照）。

## §26 第八十二轮：§4↔§5.x 使用规则覆盖裁判

### 26.1 量选

`ERRORS.md §4`（稳定码集合）与 `§5.x`（各码使用规则小节）之间没有覆盖关系裁判：
§4 里删掉一个码而 §5 还留着它的规则、给 §5 新开小节写保留码（如 §5.11
`CANCELLED`）的使用规则、§5 标题把码名拼错——全部静默。§5 的规则是实现的逐条
判据（`error_identity` 引用 §5.2 的 CAS-miss 归类「§5.2 puts a compare-and-swap miss
under CONFLICT/Config」），规则集与码集脱钩意味着实现失去了可对照的锚。

### 26.2 实现

`crates/caly-api/tests/error_doc.rs` +1 条（`the_usage_rules_cover_exactly_the_stable_codes`）：
- §5 小节恰 10 个、编号 5.1..=5.10 唯一、无空名小节；
- 每个 §5 标题点名的码必须 ∈ §4 稳定码（保留码/未入档码不得有规则小节——后门转正
  的第一个哨点）；
- 每个 §4 稳定码恰好出现在一个 §5 小节（删码留规则、码改名、重复小节都红）。

现状核实：§5.1-5.10 覆盖 12 码（5.4/5.5 各含两个码），覆盖恰好一一对应。

### 26.3 证伪

`scripts/falsify_round82.py` 2 变异全咬——M1 §5.7 标题 `TIMEOUT`→`TIMEOUTX`
（TIMEOUT 失去规则 + TIMEOUTX 非稳定码，0.0s）；M2 后门转正：在 §6 前插入
`### 5.11 \`CANCELLED\`` 规则小节（10 节断言 + CANCELLED ∉ §4，0.1s）。
restore 内建 mtime 单调，digest 干净（bf3f34e8ee37…），无 `.r82bak`。

### 26.4 验证与归档

- `cargo test -p caly-api --test error_doc`：3 绿；census files=101 total=772
  rows=101；TEST_FLOOR 771→772；`check.sh` all gates passed（772/772、clippy 31、
  fmt 331 advisory）。
- `IMPLEMENTATION_STATUS §8.17`；`ONBOARDING` 轮次表 §6.108（「不做」标题顺延
  6.109）；`CENTERLINE_PROGRESS §4`（当前快照小节，R81 降为上一轮快照）；
  `ROADMAP` 第 2 行裁判枚举追加。

## §27 第八十三轮：`ErrorCode::category()` 默认权威 + §4↔默认双向裁判

### 27.1 量选与裁决（§8.15 残余①关账）

§8.15 残余①：`(code→category)` 逐点权威不存在，构造点与 §4 至少三处相左未裁决。
本轮先读文档再动代码，得到关键语义证据：`ERRORS.md §5.1` **自己钉了**
`CONFIG_INVALID` + `User` 的实例用例（io_budget 超限）——分类在本文档语义里是
**逐例**的，§4 的 Category 列是每个码的**规范默认类**，不是强制归类。据此把全部
11 处 User/分类偏差点逐一核查，结论：**9 处**为文档先例内的 caller-mistake 类
（misrouted support-bundle、bad_page_request、no-such-job、read_bundle_refusal、
bad_gc_request、idempotency 拒收、handshake InvalidClientName、session
RequestInvalid、routed-but-no-handler）；**1 处**恰好等于 §4 默认（CAS-miss =
CONFLICT/Config，构造点注释引用 §5.2）；**1 处真实待议**：`app.rs` 生命周期拒收 =
CONFLICT + `Platform` + retryable=true（既非 §4 默认也非 caller-mistake 类，
「状态冲突」还是「暂不可用」需产品语义裁决，本轮不动、登记 §8.18 残余②）。
结论：不是「构造点不守 §4」，而是「§4 是默认、偏差须有据」——零行为变更。

### 27.2 实现

- `caly-api/src/error.rs`：`ErrorCategory::as_str()`（7 臂）+
  `ErrorCode::category()`（14 臂 = §4 默认；`Cancelled`→User / `Internal`→Internal
  为代码侧裁定并在注释注明，§4.1 未列它们）。
- 裁判 `error_doc.rs` +1（`the_stable_categories_match_the_code_defaults`）：§4
  (名→类) map == (名→`category().as_str()`) map，双向双射（12 稳定码）。

### 27.3 证伪

`scripts/falsify_round83.py` 2 变异全咬——M1 文档侧 §4 `PERMISSION` Platform→User
（0.1s）；M2 代码侧 `category()` 的 Timeout 臂 Io→User（0.4s）。restore 内建
mtime 单调，digest 干净（doc=bf3f34e8ee37… / code=0d183b44013e…），无 `.r83bak`。

### 27.4 验证与归档

- `cargo test -p caly-api --test error_doc`：4 绿；census files=101 total=773
  rows=101；TEST_FLOOR 772→773；`check.sh` all gates passed（773/773、clippy 31、
  fmt 331 advisory）。
- `IMPLEMENTATION_STATUS §8.18`（含待议项与残余②③）；`ONBOARDING` 轮次表
  §6.109（「不做」标题顺延 6.110）；`CENTERLINE_PROGRESS §4`（当前快照小节，R82
  降为上一轮快照）；`ROADMAP` 第 2 行裁判枚举追加。
- 终跑插曲：新裁判的 `documented.iter()` 触发 clippy「iterating on a map's keys」，
  位置数 31→32——改 `documented.keys()` 后回 31（R79.5.2 同类：检查器只在终跑时看到）。
- 终跑二跑：`real_apply` 的 `the_applied_core_names_itself_and_counts_its_own_traffic`
  再次 502（`example.com answers through the core`，期望 200）——与 R79 门禁同型，
  今日第二次、log 家族第三发。未改码重跑全量门禁即绿（773/773）。该瞬态已「频发」，
  治理候选登记 §8.18 残余④（测试内单次重试或前置连通性探针，需权衡「放松裁判」）。
- 操作教训：R82 的 ONBOARDING/ROADMAP 插入曾因同批次前面的锚点断言失败被跳过
  （批次中途退出），文件缺失直到 R83 核查才被发现——本轮起叙事批次改为「每步
  独立脚本 + 完成后立即验证」。

## §28 第八十四轮：RetryPolicy 型 + §4↔默认双向裁判

### 28.1 量选（§8.18 残余①关账）

`ERRORS.md §4` 的 Retryable 列（否/视场景/可能/是）是每码的**重试性质**，比
`ApiError::retryable` 的 bool 丰富：「可能」「视场景」无法扁平化为 bool——R80 起
该列就被列为「无任何裁判」的残余（若要对照，代码侧必须先有可表达四值的类型）。
本轮补上这一层。

### 28.2 实现与证伪

- `caly-api`：`RetryPolicy`（Never/Maybe/Depends/Always 四值；`pub use error::*`
  自动导出）+ `ErrorCode::retry_policy()`（14 臂 = §4 默认；`Cancelled`/`Internal`
  代码侧裁定 Never，注释注明理由）。
- 裁判 `error_doc.rs` +1：§4 (名→词) map == (名→`retry_policy()` 词) map，双向。
  **词→变体映射住在裁判里**——文档的词永远是文档的，代码只输出变体；两侧任一
  漂移（文档改词、代码改臂）都被抓。
- `scripts/falsify_round84.py` 2 变异全咬：M1 文档 §4 `TIMEOUT` 是→否（0.1s）；
  M2 代码 `retry_policy()` Timeout 臂 Always→Never（0.4s）。restore 内建 mtime
  单调，digest 干净（doc=bf3f34e8ee37… / code=f7eea161c5c4…）。
- 零行为变更：`ApiError.retryable` 的 bool 保持实例级 wire 字段，不从此权威派生。

### 28.3 验证与归档

- `cargo test -p caly-api --test error_doc`：5 绿；census files=101 total=774
  rows=101；TEST_FLOOR 773→774；`check.sh` all gates passed（774/774、clippy 31、
  fmt 331 advisory）。
- 本轮按用户要求压缩仪式：一次写码、一次裁判、一次 falsify、五文件**原子化**
  统一文档写入（全部替换先验算、任一不匹配即整体放弃，杜绝 R82 的批次半途缺失）、
  终跑一次。DEVLOG 仅记录事实与结果，不再逐步复述过程。
- `IMPLEMENTATION_STATUS §8.19`；`ONBOARDING` 轮次表 §6.110（「不做」标题顺延
  6.111）；`CENTERLINE_PROGRESS §4`（当前快照小节，R83 降为上一轮快照）；
  `ROADMAP` 第 2 行裁判枚举追加。
