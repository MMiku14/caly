# ADR-035: `Fs` Port 增加目录列举与 mtime，并冻结 `runtime_path` 的基准

- Status: Accepted（2026-08-28 定稿；分阶段落地见 §6bis。**第 1、2、3 步已落地（第十五、十六、十七轮）**：`Fs::list` / `ListCap` / `Meta.modified_at_unix_ms` 已在两个后端实现并通过共享契约；第 2 步（删清单层）已于第十六轮落地（§6bis-ter）；第 2 步（删清单层）已于第十六轮落地（§6bis-ter）；第 3 步（grace period 取端口 mtime）已于
  **第十七轮**落地（§6bis-quater，含一处对 §2.4 字面的保守化偏离，已记在那一节）。
  **本 ADR 三步全部落地**；两个已知遗留（孤儿内容清扫、`stat_many`）写在 §6bis-quater 末）
- Date: 2026-08-27
- Decision-Makers: Caly 接续开发方
- Related-RFCs: RFC-0006, RFC-0007
- Supersedes: None

---

## 1. Context

`caly-storage::fs_store` 落地时撞到 `caly-io::Fs` 的两处能力缺口，两者都不是实现风格问题，而是**端口接口本身缺操作**：

1. **没有目录列举。** `Fs` 只有 `read / open_stream / write_atomic / rename / remove / stat / link_or_copy / lock_exclusive`。
   而"当前有哪些 pending journal""store 里存在哪些对象"这类问题必须由集合运算回答。
   现有绕法是给每个集合维护一个清单文件（`manifest/<kind>.idx`），写入时同时更新清单。
   代价是新增一类失效模式：**清单与实体不一致**。当前用"`open()` 时全量校验，宁可拒绝启动"兜底
   （见 `docs/ONBOARDING_NOTES.md §4.15`），但那是补丁不是语义。
2. **`stat` 不返回 mtime。** `Meta { len, is_file, is_dir }`。于是 `RFC-0007 §13.1` 要求的
   "尚在 grace period 内的新对象"无法判定 —— 目前只能让调用方注入 `stored_at_unix_ms`，
   未知年龄一律保守不删（`§4.20`）。

同一批实现还暴露了一处**规范空洞**：`MaterializationRequest::runtime_path` 相对谁，`RFC-0007 §6.4`
没说。实践中有两层根：`Fs` 的根（`StdFs::new(root)`）与 store 的根（`FsStore::open(_, root)`）。
基准未定义时，同一份代码在仿真盘上"看着正常"、在真盘上写出 `<root>/<root>/...`
（本仓库真实发生过，见 `§4.17`）。

约束：工作区**零外部依赖**（`docs/ONBOARDING_NOTES.md §1.4`），且 `ADR-011/013` 要求所有宿主接触
只经端口层。任何方案都不得让 `caly-storage` 自己去摸 `std::fs`。

---

## 2. Decision

1. `caly_io::Fs` 增加一个操作：

   ```text
   fn list<'a>(&'a self, dir: &'a VPath, cap: ListCap, ctx: &'a IoContext)
       -> BoxFuture<'a, Result<Vec<VPath>, IoFault>>
   ```

   - `dir` 必须是相对路径；越界与 `..` 复用现有 `VPath` 规则。
   - `ListCap { max_entries: u32 }`：**列举必须可预算**，与 `ByteCap` 同理（`RFC-0006 §5.3`）。
     超出时返回 `CapacityExceeded`，而不是截断后返回"看起来完整"的结果。
   - 返回**排序后**的条目（按 `as_relative_path()` 字典序）。顺序不是审美问题：GC 与 recovery
     扫描要在两个后端上得到同一个候选集，`ADR-022` 的可重复性也依赖它。
   - 不返回"目录条目"与"文件条目"的区分：需要类型时用现有 `stat`。避免一个操作承担两件事。
2. `caly_io::Meta` 增加 `modified_at_unix_ms: Option<i64>`。
   - `Option`：并非所有平台/所有实现能廉价提供（仿真世界就没有真实时间）。
   - 语义是"最后一次成功 `write_atomic` 的时间"，由端口实现记录，不读宿主时钟之外的来源。
3. `caly-storage` 移除清单文件层：`list_objects` / `list_*_apply` 改为 `list(root/<kind>)` + 逐条解码。
   **`open()` 的全量摘要校验保留** —— 它防的是磁盘损坏，不是防"少了清单"。
4. `grace period` 改为优先用 `Meta.modified_at_unix_ms`；仅当端口返回 `None` 时退回调用方注入值，
   两者都缺时继续"保守不删"。
5. 冻结路径基准，并把这句话写进 `RFC-0007 §6.4`：
   `runtime_path` 与一切 `VPath` 一样**相对其端口的根**；`FsStore` 在调用前**只加自己一次的**前缀，
   因此传给 `materialize` 的路径**不得**再包含 store 根。

---

## 3. Alternatives Considered

- **方案 A：保持现状（清单文件 + 注入 `stored_at`）**
  - 优点：不动已冻结的 trait；已经实现且被测试覆盖。
  - 缺点：清单是第二份真相，"与实体不一致"成为常态失效模式；grace period 依赖调用方守纪律。
  - 不采纳原因：把一个端口能力缺口转嫁成每个后端的义务，且随集合增多而恶化。

- **方案 B：让 `caly-storage` 直接用 `std::fs::read_dir`**
  - 优点：最小改动。
  - 缺点：违反 `ADR-011`"单一 IO 网关"；仿真后端将无法注入列举故障，`ADR-022` 的门禁失去一半效力。
  - 不采纳原因：为了少改一个 trait 而破坏整个分层前提。

- **方案 C：把列举能力做成独立端口 `DirectoryListing`（可选实现）**
  - 优点：`Fs` 不扩张；不支持的平台可以不实现。
  - 缺点：可选能力在 Rust 里最终要么 `Option<&dyn Trait>` 到处传，要么默认实现返回 `Unsupported` ——
    而 `Unsupported` 会让 GC 在每个后端上都不可用，形同没有。
  - 不采纳原因：`Fs` 的读侧本来就该包含"有什么"，拆开只增加调用侧分支。

- **方案 D：让 `list` 返回富条目（名字 + `Meta`）**
  - 优点：省一次 `stat`，GC 与恢复扫描更省。
  - 缺点：端口实现被迫一次性 stat 全目录（NFS/网络盘上代价显著）；返回类型与 `stat` 重复。
  - 不采纳原因：先要最小可用；批量 stat 属于后续 `stat_many` 的优化，不该由本决策绑死。

---

## 4. Consequences

### Positive

- 清单层消失，"清单与实体不一致"这一类失效模式随之消失；`backups/` 只需覆盖真实文件。
- GC 的 grace period 获得独立于调用方的证据；"保守不删"退化为兜底而非常态。
- `runtime_path` 双重前缀这类错误不再依赖"两个后端表现不一致"才被发现 —— 语义被写进 RFC。
- 仿真后端必须实现 `list`，于是 `ADR-006 §15` 的契约测试可以新增"列举有序且可预算"一条，
  跨后端一致性再少一处靠约定维持。

### Negative / Trade-offs

- 这是**破坏性 trait 变更**：`Fs` 的每个实现（`StdFs`、`SimFs`，以及将来任何平台实现）都要加一个方法。
- 真实现要处理"目录不存在"（应映射 `NotFound`，而非返回空列表——空列表会让调用者以为"确实没有"）。
- mtime 在仿真里是**编造的时间**；必须明确它只保证单调与可注入，不假装对应真实时钟。

### Follow-up Work

- `RFC-0006` 增加 `list` 的契约小节与错误映射表；`RFC-0007 §6.4` 补上路径基准那句话。
- `SimFs` 的 `MemFs` 需要目录视图（当前是扁平 `Vec<MemFile>`，`list` 可由前缀过滤实现，但需要定义
  "目录存在但没有子文件"是否可列举 —— 建议：不可，与 `StdFs` 的空目录行为对齐）。
- `caly-storage` 侧：删除 `manifest/*.idx` 读写路径，并保留/迁移 `backups/` 语义（`§12.2.2`）。

---

## 5. Compatibility and Migration

- 破坏兼容：`Fs` 新增必需方法，属于 crate 间接口变更；`caly-io` 无公开协议版本，因此只需 bump crate 版本。
- 数据兼容：清单文件是**派生数据**，删除它不丢信息；为兼容旧目录，`FsStore::open` 应保留一个
  过渡期：若 `list` 返回 `Unsupported` 而清单存在，则退回读清单（并在 `doctor` 里记一条告警）。
- 无需 bump API Protocol / IR schema / storage schema：路径语义变更不改记录布局。
  （若维护者认为"旧目录可能带着双重前缀写坏的文件"需要显式处理，则必须 bump storage schema 并走
  `ADR-036` 之外的迁移路径 —— 见 §6。）

---

## 6bis. 定稿结果与一处偏离

维护者把这三份（035 / 036 / 037）的决定权交给接续开发方（2026-08-28），本条**照 §2 采纳**，两点写清楚：

1. **偏离 §5 的过渡期设计**：原文明确"若 `list` 返回 `Unsupported` 而清单存在，则退回读清单"。**不做**。
   两个后端都由本仓库实现，`list` 不会返回 `Unsupported`；而保留一条"读清单"的回退路径，就是把这个 ADR
   要消灭的第二真相永久留在代码里 —— 它还会有自己的测试、自己的失效模式，以及一句"其实没坏，回退了"。
   `FsStore::open` 现有的全量摘要校验（`docs/ONBOARDING_NOTES.md §4.15`）保留，那是防磁盘损坏的，
   与"少了清单"无关；清单层与它是两件事。
2. **阶段不可合并**（照 §6 的顺序，每步独立可回退，本仓库一轮做一步）：
   - 第 1 步：`Fs::list` + `Meta.modified_at_unix_ms` + `ListCap`，两个后端同时实现，
     `caly-io` 契约套件加三条（有序、`ListCap` 生效、"空目录"与"不存在"可区分）。**端口能力先落地，
     调用方仍走清单**——这一步只加能力，不改语义，因此红 nothing。
   - 第 2 步：`caly-storage` 的列举改走 `list`，删掉 `manifest/*.idx` 读写；`open()` 校验语义随之一变
     （从"清单必须与实体一致"变成"实体必须自洽"），这一步要独立回归，理由见 `§4.15` / `§4.18`。
   - 第 3 步：grace period 改取 `Meta.modified_at_unix_ms`，注入值退为兜底（`§4.20`），并把路径基准那句
     写进 `RFC-0007 §6.4`（第 4 项冻结的语义，纯文档，可以搭在任何一步）。
   - `RFC-0006` 的 `list` 契约小节与错误映射表随第 1 步一起提交，不留"文档说 SHALL、代码里没这个方法"
     的窗口。
3. 本 ADR 落地前，**现状不变**：清单层继续存在，继续被 `open()` 校验；`ListCap` / `mtime` 都还没有。
   `docs/IMPLEMENTATION_STATUS.md` 的未覆盖清单同步记着这一条，别让"ADR 已 Accepted"被读成"已实现"。

## 6bis-bis. 第 1 步落地记录（第十五轮）

落地的内容与本 ADR 的差别，只有一处是**设计之外的必然后果**：

- **仿真端必须记录"被创建过的目录"。** 本 ADR 要求 `list` 区分"空目录"与"不存在"，而 `MemFs` 原来是
  一张扁平文件表 —— 两种情况在纯文件模型里根本无法区分。现在 `MemFs` 多了一个 `dirs` 集合，
  `write_atomic` / `rename` / `link_or_copy` / 锁获取都会登记祖先路径。等价性来自这一点：
  在两个后端里，目录都只能因为一次写入而存在（`StdFs` 的 `ensure_parent` 与之一致）。
  `Meta` 对目录返回 `is_dir: true, len: 0`，并且 `len` 对目录**无语义**（真盘上是目录项大小），
  契约里没有任何一条比较它。
- 契约测试按 §6 的要求落了三条，另加两条本 ADR 没写但落地时必需的：
  **"恰好等于上限不算超"**（否则每次"给我全部"的调用都会在满目录上失败）与
  **"对文件调用 `list` 是 `InvalidInput` 而不是 `NotFound`"**（后者会让调用方以为整棵子树可以放弃；
  两个后端各自的直觉实现正好在这里分岔，是共享契约第一次跑出结论的地方）。
- `RFC-0006` 已补 `§8.4`（含错误映射表）与 `§15` 第 8 条；`§16` 加了"冻结的是语义不是签名"的澄清
  （本 ADR 原先把 RFC 的约束写重了，见 `docs/ONBOARDING_NOTES.md §4.67`）。
  `RFC-0007 §6.4` 已写入路径基准那一句。

**当时的状态**（已被 §6bis-ter 改变）：`caly-storage` 仍在使用 `manifest/*.idx`，`FsStore` 仍把 `stored_at_unix_ms` 作为注入值
传给 GC。也就是说 `list` 与 mtime 目前是**有契约、有测试、无生产调用者**的能力。这一点在
`docs/IMPLEMENTATION_STATUS.md` 的未覆盖清单里有对应条目；第 2、3 步若不落地，这两个新增就必须撤掉，
而不是留成"看起来已经做了"。


## 6bis-ter. 第 2 步落地记录（第十六轮）

清单层已删除，`caly-storage` 的集合枚举全部走 `Fs::list`。与 §2 的差异、以及落地时才看清的必然后果：

- **删掉的东西**：`manifest/<kind>.idx` 的读写路径与 `load_manifest` / `save_manifest` /
  `manifest_add`，连带每条记录写入时那一次额外的 D3 索引写。注意说清楚节省的是什么：一次写入
  少的是**清单同步**，`put_snapshot` 把快照标为 last-known-good 时仍然会再写一次指针 —— 那是一次
  真实的指针更新，不是第二份真相。文件总数（6：标记、内容、对象元数据、快照记录、journal 记录、
  指针）由 `the_store_writes_no_index_of_anything_it_wrote` 钉住，写放大一旦回来就会被看见。
- **枚举入口只有一个**：`fs_store::list_directory(fs, root, ctx, dir, cap)`。它同时负责把端口的
  「相对端口根」换成 store 的「相对 store 根」，是全仓库唯一一处两种基准相遇的地方 —— §2.5 冻结的语义
  因此是一段代码，而不是散在各处的字符串拼接。
- **`open()` 的语义确实变了**（§6bis 第 2 步预告过）：从「清单必须与实体一致」变成「实体必须自洽」。
  保留：记录解不开、内容对不上锚点 —— 仍然拒启。新增：目录里出现布局解释不了的文件名
  （`unexpected file in records/snapshot: README.txt`）也拒启 —— 这是清单时代**根本看不见**的一类损坏。
  放弃：某个记录文件被带外删除，今天没有任何东西能发现它，因为没有第二份名单可以说「这里本该有一个」。
  这是本步唯一的能力退化，写清楚而不是含混过去：LKG 指针指向缺失记录仍然拒启、锚点仍然校验，
  所以「损坏」大体仍抓得住，但「少一个文件」抓不住了。
- **两类文件必须区分，否则新检查比原缺陷更糟**：`StdFs::write_atomic` 的改名残留
  `<target>.tmp-<n>` 是崩溃副产品，不是数据；把它当损坏拒启，等于让一次崩溃就能让 store 永远起不来。
  因此启动时先扫一遍并删除（`reap_residue`）—— 这也正是 `ListCap` 预算成立的前提：残留若不计入预算
  就无人管，若计入又永不回收，最终 `open` 会因为「目录太大」而失败在一个并非记录的数字上。
- **回退点从「抄清单」改为「抄记录」**（§4 Follow-up 里「保留/迁移 `backups/` 语义」的迁移分支）：
  `create_rollback_point` 现在枚举 `meta/objects` 与四个记录目录逐个 `link_or_copy`，仍不抄对象内容
  （不可变、内容寻址，抄一份只把目录翻倍），单文件大小上限沿用 `MAX_ROLLBACK_FILE_BYTES`。
  `schema::has_any`（「这个目录到底是不是空的」）也一并从「探测五个已知清单名」升级为真列举，
  并且**列举失败按「有数据」处理**：猜「是空的」正是把已有记录初始化掉的那条路。
- **缓存不再是枚举的答案**：`list_pending_apply` / `list_unresolved_apply` / `list_snapshots` 的兜底
  分支过去读进程内缓存，而 `list_apply_journals` 读盘 —— 一个 store、两个答案，而拒绝启动用的是前者。
  现在每个集合只有一个 loader（`load_snapshots` / `load_apply_journals` / `load_os_journals` /
  `object_records`），该集合的全部查询都从它出发 —— 于是"同一个集合的两个视图"在结构上不存在了。
  缓存只留给 `get_*` 与删除时的共享内容判定：后者保留缓存是**性能决定**
  （GC 每删一条都要问「还有谁引用这块内容」，改成读盘是 O(n²)，而在仿真盘上每次读还要线性扫文件表），
  这个不对称写在 `list_objects_inline` 的文档里，而不是留给读者猜。

**未一并解决**（写在这里，别让「第 2 步完成」被读成「清单层的所有后果都处理完了」）：

1. **孤儿内容没有清扫者。** 删除对象是先删元数据、再删无人引用的内容；两步之间崩溃就留下一个没有任何
   元数据引用、也没有任何清单会提到的内容文件。以前没有 `list` 时无法检测，现在仍然无法**廉价**检测：
   内容在 `objects/sha256/<aa>/<bb>/<rest>` 三层目录下，而端口只保证「一层列举」（§2.1），遍历需要
   至多 256×256 次 `list`。需要的是递归列举 / `stat_many` 一类的端口能力，或把内容目录拍平 ——
   都不该塞进本步（要再动端口形状就得再来一条 ADR）。
2. **第 3 步**（grace period 取 `Meta.modified_at_unix_ms`）仍未开始，所以 `mtime` 依旧是
   「有契约、有测试、无生产调用者」。§6bis-bis 末尾那句对本步同样成立：不做就撤，别留成「看起来已经做了」。

## 6bis-quater. 第 3 步落地记录（第十七轮）

对象的年龄现在由**端口证据**决定，不再是调用方的声明。落点只有一个：`FsStore::dated`，
所有会交出 `CasObjectRef` 的路径（`put` 的返回值、`get`、`list_objects`、`open()` 填缓存）都过它，
因此同一个对象不可能因为"哪次调用问的"而有不同年龄。

- **一处对 §2.4 字面的偏离（有意，且被测试钉住）**：原文是"优先用 `Meta.modified_at_unix_ms`；
  仅当端口返回 `None` 时退回调用方注入值"，即端口**覆盖**声明。落地时改成**取两者中较新的一个**。
  理由是这两个来源各有会说谎的方式：声明可以是旧的（调用方随手写 0，本轮就是这么测的），
  而 mtime 也可能偏旧（从备份恢复、时钟回跳）。这个字段唯一会造成数据损失的方向是"看起来比实际更旧"
  ——那会让 grace period 形同虚设并删掉刚发布的对象；而"看起来更新"最多让对象多留一轮。
  所以规则是 `max(evidence, claim)`，缺一个就用另一个，两个都没有就保守不删。
  证伪里有一条专门测这个：把实现改回"端口直接覆盖"（§2.4 的字面版）会让
  `a_claim_newer_than_the_port_is_kept_and_a_missing_one_is_filled_in` 变红 —— 也就是说这条偏离
  不是嘴上说的，是被断言着的。
- **`None` 仍然是 `None`**：没有时钟的端口（`SimFs` 默认、任何 `MemFs` 世界）答不出 mtime，
  存储层**不伪造**一个"现在"。这既保住了 `object_contract.rs` 跨后端同答（`InMemoryStorage` 与无时钟
  的 `FsStore` 都只报告记录里的值），也是本轮唯一一条"什么都不做"的正确处置。
- **代价说清楚**：每个对象记录多一次 `Fs::stat`。`ADR-035 §3` 拒绝过"让 `list` 返回富条目"，
  并写下"批量 stat 属于后续 `stat_many` 的优化"—— 本步正是按那句做的：不趁第 3 步偷偷改端口形状。
  `object_records` 本来就对每条记录做一次 read + decode，所以复杂度类别没变（在仿真盘上两者都是
  对文件表的线性扫）。`stat_many` 因此是这条链上明确记下的下一步优化，而不是遗漏。

**本步没有解决的（读到这里就该停一下，别把"第 3 步完成"读成"grace period 已经安全"）**：

1. `GcPolicy::now_unix_ms` 当时仍是调用方给的 —— **第十九轮由 `ADR-038 §3` 落地**：引擎的回收计划改为
   优先取注入的 `Clock`（与 store 记日期用的是同一个端口时钟），没注入则退回执行策略基准，并在报告里
   写明用的是哪一个（`GcPlanSummary::now_source`）。本条留下的教训被单独记档：把一侧的读数换成端口证据
   之后，另一侧的读数必须同源，否则比较本身没有意义（`docs/ONBOARDING_NOTES.md §4.74`）。
2. **`run_object_gc` 仍无生产调用者**（`grep -rn 'run_object_gc' crates/` 在第十八轮实测只命中定义与
   自己的测试）。`ADR-038` 分两轮把这条账还完：§1 让**计划**被消费（`caly-engine::gc_plan` →
   `system.gc-plan` / `doctor`），§2 让**删除**被消费（`system.gc-collect` → `sweep_objects`）。
   `run_object_gc` 本身仍只有测试调用 —— 那是分工不是遗漏：它的语义是"自己算一轮再删"，而引擎需要
   "算一次、报告、只删报告里那份"，所以用被拆出来的 `sweep_objects`（见 `docs/ONBOARDING_NOTES.md §4.85`）。
3. **孤儿内容**（§6bis-ter 第 1 条）不变，本步没有触碰。

## 6. Notes

- 本 ADR 由接续开发方提出，提出时标为 **Proposed**（它修改了 `RFC-0006` 冻结过的端口形状，需要维护者
  确认）。2026-08-28 维护者把裁决权交给接续开发方，**状态改为 Accepted**；阶段划分与一处被否掉的过渡期
  设计写在 §6bis，逐步的落地记录写在 §6bis-bis（第 1 步）与 §6bis-ter（第 2 步）。
   （这一句此前写的是「**实现尚未开始**，所以 §2 描述的能力今天都还不存在」，而同一份文件的状态行已经改成
   「第 1 步已落地」—— 同一份文件里两个段落对同一事实各说各话，因为更新时只改了开头那行：见
  `docs/ONBOARDING_NOTES.md §4.70`。）
- 三个差距已全部落地并各自留档：`docs/ONBOARDING_NOTES.md §4.15`（清单层，第十六轮已修）、
  `§4.17`（路径基准，写进 `RFC-0007 §6.4`）、`§4.20`（grace period 的时间来源，第十七轮已修）。
- 实现顺序建议：先 `list` + mtime + 契约测试（后端两侧），再删清单层，最后改 grace period 取时来源。
  不要一次全改：清单层删除本身会让 `open()` 的校验语义变化，需要独立回归。
- 测试门禁：`Fs` 契约套件（`caly_io::contract`）新增"列举有序 / `ListCap` 生效 / 空目录与不存在目录可区分"三条，
  且必须在 `StdFs` 与 `SimFs` 上同时通过。
