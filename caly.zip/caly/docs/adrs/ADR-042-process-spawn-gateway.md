# ADR-042: 进程生成经 Proc 网关（StdProc），Platform 特权面不落 std

- Status: Accepted（第五十三轮落地：`StdProc` 真子进程、共享 spawn 契约两后端同判、
  `caly-io-std/clippy.toml` 的 `Command::new` 禁令按既有先例定点豁免；裁判 5 处、
  证伪全咬）
- Date: 2026-08-29
- Decision-Makers: Caly 接续开发方（维护者已把此类裁决交由此方自行决定，见 `ADR-035 §6bis`）
- Related-ADR: ADR-011（纯核心、世界接触全走 `caly-io` 端口）、ADR-013（IO 分类与有界执行域）、
  ADR-022（仿真门必须校验生产端口实现的世界）、ADR-035（网关根与 `clippy.toml` 定点豁免先例）、
  ADR-032（隔离 provider 进程——未来的消费方）
- Supersedes: "`Proc` 仍需要 Platform 决策（`Command::new` 全仓禁用是有意的）"这条悬置
  （`DEVELOPMENT_LOG_2026-08-27.md` 多轮"下一步"里的原话）

---

## 1. Context

`caly_io::Proc` 端口自 RFC-0006 起就存在（`spawn(SpawnSpec) -> ChildHandle`），仿真侧
`SimProc` 也早已在跑；但 std 侧一直空着，因为全仓 `clippy.toml` 禁用
`std::process::Command::new`——这条禁令是 `ADR-011`"核心纯度"的机械化，而 `caly-io-std`
自己的 `clippy.toml` 里写着："spawning is a Platform concern and has no implementation in
this crate"。悬置的理由是"要等 Platform 决策"，但这句话把两件事捆成了一件：

1. **spawn 一个进程**（无特权：fork/exec 一个给定的 argv）；
2. **Platform 特权面**（tun 设备、系统代理、DNS 覆写——需要 root/系统能力探测）。

捆着的结果是契约表 `RFC-0006 §15` 第 4 条（"`Proc` shell-free spawn"）空着载体，
`SimProc` 与不存在的 std 后端无从对判——恰好是 `ADR-022` 反对的形状：仿真门校验一个
生产端口没有实现的世界。

## 2. Decision

**两件事拆开：spawn 归 `Proc`（本轮落 std），特权归 `Platform`（明确不落 std）。**

### 2.1 `StdProc`（`caly-io-std/src/proc.rs`）

- **豁免按 `ADR-035`/`ADR-014` 先例**：`caly-io-std/clippy.toml` 从禁用表移除
  `std::process::Command::new`（该 crate 的表本来就是对全仓禁令的定点收窄：`File`
  与两个 `now` 早已这样豁免）。工作区其余 crate 的禁令一个不动——网关外的一次
  stray spawn 仍是 lint 错误，不是 code review 的希望。
- **Shell-free**（契约第 4 条的字面）：`program` 直接 exec、`argv` 是字面参数向量，
  没有 `/bin/sh -c` 包裹——daemon 与 core 之间的一个 shell 会把路径里的每个空格
  变成端口契约看不见的注入面。
- **子进程活在网关根内**：spec 的 `cwd` 用 `StdFs::resolve` 同一套规则解析（相对、
  无 `..`、绝不绝对），且 spawn 前显式查存在性——OS 层"程序不存在"与"cwd 不存在"
  是同一个 ENOENT，不预查就把两者都归因给程序名是撒谎；预查后 `NotFound` 就真的
  是程序不存在。
- **子进程不继承 daemon 的任何东西**：stdin/stdout/stderr 全部 `/dev/null`——一个
  fire-and-forget 子进程若握着 daemon 的 socket，会替 daemon 把客户端连接多握 exactly
  它的整个生命周期。
- **不是 supervisor**：端口形状就是 fire-and-forget（`ChildHandle` 只有 pid 与
  instance_nonce，没有 wait/kill/signal）。等待策略、退出状态、重启与收割（僵尸
  进程在此形状下会积累）是未来的端口生长决策，到时自带 ADR，不在这里悄悄多发一份
  能力。`instance_nonce` = 进程内 spawn 序号 + pid——宿主会回收 pid，单 pid 不足以
  区分实例。
- **空程序名是 `InvalidInput` 点名拒绝**：端口不许猜一个默认二进制；`SimProc` 同步
  对齐，共享契约 `proc_spawn_contract_violations`（`caly-io/src/contract.rs`，签名为
  两个闭包——仿真侧"能跑的程序"是一个标签，std 侧是一个真二进制，同一先例：
  fetch 契约）两后端同判：空程序名拒绝且点名、成功手柄 pid≥1 且 nonce 非空。
  shell-free 本身是结构性的（`Command::new(program)` 直 exec），由 std 侧看真子进程
  的测试裁判（cwd/env 落盘证明）。

### 2.2 `Platform` 不落 std

`PlatformCaps` / `apply_network` / `revert_network` 保持无 std 实现。理由不是"难"，
是"诚实答案不存在"：capability 探测（tun 可用吗？系统代理可设吗？）需要按 OS、按
特权、按发行版作答，一个装模作样的 `StdPlatform`（比如恒报 `false`，或 `apply_network`
假装成功）会比缺席更糟——它会让"能力存在"变成一个没人核对过的承诺。**缺一个诚实的
std 实现不是缺口，伪造的 std 实现才是。** 落地条件与 `SpawnCore`/`StopCore`（效果建模
位已在 `caly-plan`/executor）的真实接线一起到：谁消费 `Platform`，谁带来它的决策。

## 3. 被否决的备选

- **继续捆着等"Platform 决策"**：让契约第 4 条继续空载、仿真门继续单独作答——
  `ADR-022` 明文反对的形状，且 spawn（无特权）与特权面本就无依赖关系。
- **在 `caly-io-std` 全仓豁免 `Command::new` 且不做契约**：豁免必须有裁判跟着，
  否则下次有人在网关里 spawn 出网关根之外的进程，没有任何东西会红。
- **`StdProc` 顺手带上 wait/kill**：端口形状是既有决策（fire-and-forget 手柄），
  适配器自加能力=适配器改契约；supervision 是 `SpawnCore` 消费方到来时的新决策。
- **`StdPlatform` 恒报 false**：见 §2.2——一个没人核对过的能力承诺比缺席更糟。

## 4. 落地记录（第五十三轮）

- `crates/caly-io-std/src/proc.rs`：`StdProc`（new(root)/root()/resolve_cwd/Proc::spawn，
  cwd 预查、stdio null、`NotFound`/`PermissionDenied`/`InternalIo` 点名映射、nonce=
  序号+pid）；`lib.rs` `pub use proc::StdProc`；`clippy.toml` 豁免改写（头注同步，不
  留"spawning … has no implementation"旧账）。
- `crates/caly-io-sim/src/port_impl.rs`：`SimProc` 空程序名拒绝（与 std 同词）。
- `crates/caly-io/src/contract.rs`：`proc_spawn_contract_violations`（两闭包形状），
  契约表第 4 条从"not yet"改为指向该载体。
- 裁判五处：`caly-io-std/tests/proc_std.rs` ×4（共享契约真二进制、**真子进程的 cwd/env
  落盘证明**（`/bin/sh -c` 是调用方自己选的程序，不是端口包的 shell）、缺程序点名
  `NotFound`、缺 cwd 点名 cwd 不赖程序）、`caly-io-sim/tests/contract.rs` +1（仿真侧
  同判）。证伪见 `scripts/falsify_round53.py` M4/M5（spawn 失败被吞成假手柄 / env 或
  cwd 被丢弃）。

## 5. 后果

- 契约表 `RFC-0006 §15` 七条全部有载体（第 4 条本轮补齐）。
- `IMPLEMENTATION_STATUS` 的"IO 网关实现"行改写：`Proc` 有 std 后端，`Platform` 仍缺
  ——且是**决策性缺席**（本 ADR §2.2），不是欠账。
- 谁先消费 `StdProc`（大概率是 `SpawnCore` 接线，`ADR-032` 的隔离 provider 进程），
  谁就带来自 wait/kill/收割的新决策；届时本 ADR 的 fire-and-forget 划线按新 ADR 修订。
