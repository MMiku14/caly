# ADR-054: Fs::stat_many 批量 stat 面（ADR-035 登记的下一步）

- Status: Accepted
- Date: 2026-08-30
- Decision-Makers: Caly Architecture
- Related-RFCs: RFC-0006（IO 端口契约）
- Supersedes: None（本 ADR 是 `ADR-035 §3 / §6bis-quater` 两次写下的「批量 stat 属于后续
  `stat_many` 的优化」的实现决策；ADR-035 正文作为历史不改写。）

---

## 1. Context

`ADR-035 §3` 拒绝过「让 `list` 返回富条目」（单层列举 + 每条记录独立 read/decode/stat），
并写下「批量 stat 属于后续 `stat_many` 的优化」。后来的 `§6bis-quater`（第十七轮，
`FsStore::dated` 用端口证据决定对象年龄）把这句话变成了一条明确的链：

> 每个对象记录多一次 `Fs::stat`……`stat_many` 因此是这条链上明确记下的下一步优化。

2026-08-30 实测现状：`Fs::stat` 是单路径；`FsStore::object_records`（list_objects 的
实现）对 N 条对象记录循环 `read_object_record` → `dated` → 每次一个 `stat` 端口调用。
`Fs` trait 只有两个实现（`SimFs`、`StdFs`），改动面窄。GC 引用判定已是内存集合
（`BTreeSet`），无 stat 热点——本 ADR 不触及 GC 面。

## 2. Decision

1. **端口形状**：`Fs::stat_many(&self, paths: &[VPath], ctx) -> BoxFuture<Result<Vec<Option<Meta>>, IoFault>>`。
2. **语义**：
   - 输出与输入**同长同序**；每项 == 逐条 `stat` 的答案（`None` = 不存在——不存在是值，
     不是错误，与 `stat` 一致）；
   - `Err` = 整批失败（取消、锁毒化、真实 IO 错），与 `stat` 同为整体语义；
   - 空输入 → `Ok(vec![])`，无副作用；
   - **一次逻辑端口调用**：调用方为 N 个事实付一次端口操作，而不是 N 次往返。端口
     底层可以循环（POSIX 无批量 metadata syscall），但**调用方契约**是一次操作；fault
     注入世界对一个 batch 报告一个操作点（`SimFs` 单点 `maybe_fail`），而不是 N 个。
   - **两条实现共享一条判定**：`SimFs` 的 `stat` 与 `stat_many` 都走同一 `sim_meta`
     函数——「每项等于逐条 stat」在实现上不是巧合而是同一答案。
3. **存储层采用**：`FsStore::object_records` 改为「list → 逐条 read+decode（各记录是
   独立文件，无法合并）→ 一次 `stat_many` 拿全部年龄 → 逐条合并」。行为与旧的逐条
   `dated` **逐字段一致**（合并规则仍是 `ADR-035 §6bis-quater` 的 whichever-is-newer）。
   单对象路径（`get`/`put`/`open`）继续用 `dated`（单次 `stat` 不批）。
4. **不做什么**：不改 `list` 的形状；不引入递归列举；GC 引用判定不动（已是内存集）；
   不承诺复杂度类变化（还要 N 次 read+decode，ADR-035 自己说的「复杂度类别没变」）。

## 3. Verification

- **契约（共享套件，两端跑）**：`fs_contract_violations` 新增 `stat_many` 项——
  批量结果 == 逐个 stat（含 None 项与重复输入的顺序保持）、空输入 == 空输出。
- **存储层裁判**（`caly-storage/tests/stat_many.rs`，CountingFs 包装计数）：
  - `object_records_dates_its_whole_directory_with_one_stat_many`：2 个对象枚举后
    `stat_many` 调用次数 == 1、`stat` == 0；
  - `object_records_batch_matches_individual_reads`：批量结果与单条 `get` 的
    `stored_at_unix_ms` 逐条相等（行为等价）。
- `scripts/archive/falsify_round74.py`：M1 调用点退化（批量改回逐条 `dated`）→ 计数裁判红；
  M2 `SimFs::stat_many` 返回长度错误 → 契约红（存储层病态输出也红）。

## 4. Consequences

- `list_objects`（support bundle、audit、GC 预览、枚举面）从「每对象一次 stat 端口调用」
  变为「每目录一次」——调用方成本从 O(N) 次端口往返降为 O(1) 次 + N 次记录读。
- `Fs` trait 加方法：全部实现者（2 个）必须实现；测试 wrapper（3 个）同步补
  delegate，未来新增 `Fs` 实现者在编译期就会被提醒。
- 行为无变化（契约逐字段钉住）；`open`/`get`/`put` 的单点 dated 保持每次一个 stat
  （无批量形态可合并）。
