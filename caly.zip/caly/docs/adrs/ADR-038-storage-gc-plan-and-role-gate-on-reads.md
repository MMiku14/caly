# ADR-038: 存储回收的计划先于删除落地，并把 `required_role` 变成读侧也生效的门禁

- Status: Accepted（第 1 步第十八轮、第 3 步第十九轮、第 2 步第二十轮、`§13.2` idle 自动触发第二十五轮已落地 —— 本 ADR 四步全部落地；自动化的策略与理由见 §9）
- Date: 2026-08-28
- Decision-Makers: Caly 接续开发方（维护者已把此类裁决交由此方自行决定，见 `ADR-035 §6bis`）
- Related-RFCs: RFC-0002, RFC-0006, RFC-0007, RFC-0010
- Supersedes: None

> **当前状态（2026-08-29）**：本 ADR 的 GC plan/collect、root completeness、role gate、storage-clock 注入与默认关闭的 `gc.idle` 均已落地。`FsStore`/`calyd` 的真实组合根已经提供持久化后端与 `StdClock`；本文第 1、6、7、8 节描述的是当时的发现与分阶段落地证据，其中“无生产者”“无 bin”“真实部署必然 `clock-timeline` 拒绝”等表述不得再当作当前快照。当前剩余项是 schema migration、`stat_many` 性能与 Platform/security 面，不是 GC 生产接线。

---

## 1. Context

`RFC-0007 §13` 规定了 GC 的 root 集与行为规则，`caly-storage::gc` 自第五轮起就把它们实现成了纯策略并有测试。
但到第十七轮结束时，`grep -rn 'run_object_gc' crates/` 在 `crates/caly-storage/tests/gc.rs` 之外**零命中**：
没有生产者，也没有消费者。后果不是"少一个功能"，而是**一个只会变大的磁盘从所有观测面上看都是健康的**
（`docs/ONBOARDING_NOTES.md §4.73`）。

接线时又撞出两个更基础的问题：

1. **`§13.1` 的六类 root 里有一类根本组装不出来。** `RevisionStore` 只有 `put` / `get`：没有任何办法问
   "这个 store 登记了哪些修订"，因此"已登记 Revision 引用的对象"这条 root 无从计算。缺它的时候，任何
   诚实的实现只有两条路——要么假装该类为空（等价于授权删除被它保护的对象），要么不落地 GC。
2. **`required_role` 只写在 `OperationMeta` 里，没有写在边界上。** 角色检查当时只存在于
   `map_request_to_command`，而 `handle_request` 对 `Query` / `Stream` 直接分派 —— 也就是说
   `ProfileOp::Plan` 声明的 `Role::Operator` 在本仓库全部历史里从未被执行过（`§4.75`）。新加的
   `system.gc-plan` 是一个声明 `Operator` 的读，如果先接线再补门禁，就会造出一个"看起来受控、实际敞开"
   的删除决策入口。

---

## 2. Decision

1. `RevisionStore` 增加 `list_revisions()`，**默认实现返回 `Unsupported`**，而不是空集合。
   理由与 `list_snapshots` / `list_apply_journals` 一致，但这里更尖锐：空集合在这条链上不是"没数据"，
   而是"这些对象没人引用，可以删"。两个内置后端都实现它（`FsStore` 复用 `ADR-035` 的目录枚举）。
2. 新增 `SystemOp::GcPlan { request }`（query，`Role::Operator`，`CostClass::Medium`）返回 `GcPlanView`。
   它**只计算、只报告，不删除**。有界的三件事：`retained_sample`（`GC_PLAN_SAMPLE_LIMIT = 32`，超出部分
   `is_truncated()` 自证）、`max_deletions`（默认 256，上限 4096）、`grace_period_ms`（默认 15 分钟，
   上限 30 天，`0` 合法但要回显）。请求参数越界是 `CONFIG_INVALID`，不是 store 故障。
3. **root 集是全有或全无。** 任何一类 root 读不到（后端答 `Unsupported`、或运行时指向 store 造不出的记录）
   都记为 `GcRootGap { class, detail, actionable }`，并且 `collect` 被**清空**：一个部分 root 集算出来的
   删除列表比"没有列表"更危险，因为它看起来可执行。
4. **`now` 不由调用方给。** `GcPlan` 的时间来自引擎注入的执行时钟（与 apply journal、支持包同一条时间线）。
   同时加一条一致性检查：若 store 报告的对象年龄**晚于** `now`，说明两侧不同源，此时不猜，而是记为
   `clock-timeline` 缺口并拒绝（`§4.74`）。
5. **`required_role` 提到 `handle_request` 上，对 `Query` 与 `Stream` 生效**，与命令路径共用同一个
   `require_role` / `api_error_for`。命令路径**保留**它自己的那一次检查：`submit_request_as_command` 是
   公开入口（测试与未来的 CLI 会直接调它），把检查只放在 `handle_request` 会让那条入口绕过门禁 ——
   两处调用、一份实现，不是重复。
6. `GcRootGap.actionable` 区分"运维能补的"（记录丢失 = 损坏）与"要改代码/配置才能消的"（后端没有该查询、
   时钟不同源）。`doctor` 把计划作为**一条 note** 报告（拒绝原因写在同一行文本里），不加 warning：见 `§4.6`。

### 分阶段

- **第 1 步（本轮）**：`list_revisions` + 计划查询 + root 完整性门禁 + 读侧角色门禁 + `doctor` 那条 note。
  删除路径仍不存在。
- **第 2 步**（第二十轮已落地，见 §8）：`SystemOp::CollectGarbage` 作为**任务**（`ADR-018`「写操作即任务」）：进度事件、可取消、
  资格门禁复用本 ADR 的 `eligibility_of`，被拒时走第十三轮的 overload 出口；执行的是**它刚取到的那份计划**
  （`would_run == true` 才动，且不重新推导一份）。同时把计划与结果作为支持包新段 `storage-gc` 导出。
- **第 3 步**：`§13.2` 的 idle 自动触发（低优先级后台任务），以及把 `Clock` 从组装根注入引擎，
  让 `now` 与端口 mtime 同源 —— 这一步做完之前，真实部署上的计划会一直带着 `clock-timeline` 缺口而拒绝运行。

---

## 3. Alternatives Considered

- **方案 A：一步到位，直接实现 GC 任务与删除**
  - 优点：一次闭环，`§15.6` 的验收可以直接测。
  - 缺点：删除是唯一不可逆的那一半；在没有"计划可读"之前上线它，等于让第一次评审在**已经删完**之后进行。
  - 不采纳原因：本仓库对不可逆操作的一致做法是先给可核对的报告（`profile.apply` 有 `dry_run`，
    `storage-audit` 段先于删除存在）。
- **方案 B：把计划算在 `caly-daemon` 里，engine 不动**
  - 优点：改动面最小。
  - 缺点：本地门面与 session 门面会各算一遍（`ADR-017`/`ADR-026` 反对的正是这个），而且支持包（引擎侧）
    拿不到同一份结果。
  - 不采纳原因：同一事实必须有一个计算处，放在持有 store 与状态的引擎里，门面只做映射。
- **方案 C：root 类读不到就跳过该类，继续给列表**
  - 优点：GC 在更多后端上"可用"。
  - 缺点：把"我不知道"变成"没有引用"，即授权删除。
  - 不采纳原因：与 `list_*` 系列一律 `Unsupported` 而非空集的既有裁决直接冲突。
- **方案 D：`system.gc-plan` 声明 `Role::Viewer`（与其余诊断读一致），从而不必处理读侧门禁**
  - 优点：不动 `handle_request`。
  - 缺点：把一个"删除决策的输入"放进无人可拒的公开读；而且读侧不执行 `required_role` 这个既存缺陷会
    继续留着，`profile.plan` 的声明继续是装饰品。
  - 不采纳原因：本 ADR 宁可多改一处边界，也不新造一个"声明了但没人执行"的字段。
- **方案 E：`list_revisions` 默认返回空集合，让"没有修订"成为合理答案**
  - 不采纳原因：见 `§2.1`；空集会在 GC 语境里被读成许可。

---

## 4. Consequences

### Positive

- "磁盘只增不减"从不可见变成**一行可读的报告**：`objects / collect / retained / deferred / gaps /
  would_run` 进入 `doctor` 与 `system.gc-plan`，两条门面给出同一个视图（`system.gc-plan` 已进
  `run_system_contract` 与 `ENVELOPE_PARITY_CASES`）。
- 六类 root 里第一次**每一类都有来源**，缺哪一类会指名道姓地说出来。
- `required_role` 对读与流成立；`OperationMeta` 里那个字段从此在所有三种模式下都被执行。
- 命令与读共用同一个 `api_error_for`，"同一个拒绝在两条路上长得不一样"这一类缺陷被结构排除。

### Negative / Trade-offs

- `GcPlanView` 字段多（18 个）。刻意如此：每一项都是"能不能删"这个问题的一部分，折掉任何一项都会让
  剩下的字段被误读（例如去掉 `gaps` 后，`collect=[]` 就分不清"没有可删"与"不能判断"）。
- 每条对象记录一次 `Fs::stat`（`ADR-035 §6bis-quater` 记过的账），`stat_many` 之前不变。
- **历史上的 `clock-timeline` 拒绝已不再是 calyd 组合根的当前状态**：真实 `calyd` 已注入 `StdClock`；若其他组合根不提供与对象 mtime 同源的 clock，仍必须保留拒绝而不得猜测。`§15.6` 的剩余限制是 schema migration / `stat_many` 与 Platform/security，不是 GC 没有生产者。
- `doctor` **不**为 GC 报警：凡是能让计划拒绝的 store 状态，`storage_audit` 已经先把整个 doctor 请求
  失败了（实测：`UNAVAILABLE / last-known-good pointer names a missing snapshot record`）。在这里加
  warning 只会二选一——重复审计的结论，或者成为一条永远不触发的死分支（`§4.76`）。

### Follow-up Work

- `docs/ERRORS.md` 不需要新码：越界是 `CONFIG_INVALID`，越权是 `PERMISSION`，store 读不到是
  `UNAVAILABLE`（retryable），都已存在。
- 后续工作转为 storage schema migration、`stat_many`/批量定年与 Platform/security；GC plan/collect/idle 的生产接线不再列为 follow-up。

---

## 5. Compatibility and Migration

- 不破坏数据：`records/revision/*.rec` 布局未变，只是多了一个查询。
- 破坏 API（源码级）：`SystemFacet` 多一个方法，`Operation` / `OperationResult` 多一个变体。本仓库无外部
  消费者，且 `RFC-0002 §4.1` 要求的是共享 DTO 的**语义**一致；变体追加不改既有语义，因此不 bump
  `ProtocolVersion`。
- `OperationMeta.required_role` 对读开始生效，是一次**行为收紧**：任何以 `Role::Viewer` 调
  `profile.plan` 或 `system.gc-plan` 的调用方会开始收到 `PERMISSION`。今天两条门面的默认角色都是
  `Operator`（`ADR-037 §2.2`），因此实际调用方不受影响；若有第三方以 `Viewer` 调它们，那是它们本就该被拒。
- 无需 storage schema 迁移。

---

## 6. 落地记录（第十八轮，第 1 步）

落地的内容与本 ADR 文本没有偏离。补记三条落地时才确定的事实：

- `has_actionable_gap` 这样的**方法**在第一版里存在，落地时发现它只有一个调用点、而那个调用点在本轮
  永远走不到（原因见 `§4` 的 Negative 第三条），于是**删掉方法、保留字段**：`actionable` 作为 gap 的
  属性被报告、被 `summary_line` 计数、被测试核对，但"要不要升级成 warning"留给第 2 步与客户端决定。
  与其留一条永不触发的分支，不如把判断留在数据里。
- `GcPlanSummary::would_run()` 是派生的（`roots_complete() && eligibility.check().is_ok()`），DTO 里的
  `would_run` 是它的一次性快照；`deferred_over_cap` 单列，因为 `GcPlan::blocked` 把"被 root 保护"与
  "本轮容量已满所以推迟"混在同一列表里（理由为空的条目 = 后者）。把后者计入 `retained` 会谎称有东西
  保护着它。
- （第 3 步另有一段落地记录，见 §7：接缝已就位、组装根仍缺。）
- 计划查询本身**不会**因为 store 有损坏而失败（`§8` 把同一条规则也用在周期上：周期把拒绝写进记录，而不是让请求失败）；只有"候选集取不到"才是错误。分界是：
  **说不出 store 里有什么 → 错误；说不出谁引用着它们 → 缺口 + 拒绝。**

---

## 7. 第 3 步落地记录（第十九轮，历史证据）

> 本节记录当时尚无 binary 组合根的状态；`calyd` 与 `caly` binary 现已存在，当前组成根事实见本文开头。

`§2` 的第 3 步原文是「把 `Clock` 从组装根注入引擎，让 `now` 与 mtime 同源」。落地时把它拆成两截，
因为本仓库**没有组装根**：`DaemonApp::bootstrap` 的调用者只有库内 `runtime.rs`、`caly-app` 的
loopback / 场景与测试 —— `caly-cli` 至今没有 `[[bin]]`。

- **已落地**：接缝与语义。`EngineHandle::set_storage_clock(Option<Arc<dyn Clock>>)` 与 `storage_now()`；
  回收计划优先用注入的时钟，并在 `now_source` 里写明用的是哪一个（`storage-clock` / `execution-policy-base`），
  `doctor` 的那行 note 与 `summary_line` 一并带上：`now=1700000000000@execution-policy-base`。
  `DaemonApp::set_storage_clock` 只做转发，参数类型写成 `caly_engine::Clock`（引擎对端口 trait 的一次
  re-export），**不给 `caly-daemon` 新增指向 `caly-io` 的依赖边** —— 那条边受 `ALLOWED_DEPENDENCY_EDGES`
  管辖，为省一行 import 去动架构门禁是本末倒置。
- **当时未落地**：真实部署填上它。在 `calyd` 组合根加入 `StdClock` 之后，注入路径已成为可用计划；对没有同源 clock 的其他组合根，仍必须拒绝并说明使用的基准。测试两侧都钉住：不注入 → 拒绝；注入 → 同一份 store 状态成为可用计划（`crates/caly-engine/tests/gc_plan_and_clock.rs` 与 `crates/caly-daemon/tests/gc_plan.rs`）。

### 为什么只有一条 `now` 被换掉，而 journal 时间戳不动

这是本节最需要写清的地方，否则下一个人会顺手把两边统一掉。引擎里存在两个 `now` 是**有意的**：

| 比较 | 两侧来源 | 结论 |
|---|---|---|
| journal 是否陈旧（`audit`） | 两侧都来自 `ExecutionPolicy::clock_start_unix_ms` + `clock_step_ms` | 同源自洽；改成宿主时钟会让确定性回放门禁（`ADR-022`）失配，把每个 journal 都说成陈旧 |
| 对象是否在 grace 内 | 一侧是文件日期（`Fs::stat`），另一侧必须**也是**记这些日期的那个钟 | 所以新增 `storage_now()`，而不是把 `clock_start_unix_ms` 改成读时钟 |

### 检出规则的方向（诚实的局限）

`clock-timeline` 只在**某个对象的年龄晚于 `now`** 时触发，即"年龄来自未来"这一向。反方向 —— `now`
超前、真实对象全部看起来过期 —— 从 store 内部**不可判定**。这正是本 ADR 把第 2 步（删除）排在第 3 步
**之后**的硬理由：同源时钟没接好之前，不许把删除接上。本轮写测试时被这一点绊了一次（先推进时钟再写
对象才构造得出 `age > now`；反过来只会得到"年龄恰等于基准、仍在 grace 内"），见
`docs/ONBOARDING_NOTES.md §4.80`。

### 证伪

6 条变异全部咬住：`storage_now` 忽略注入的钟；`now_source` 标签写反；检出条件从 `>` 改成 `>=`
（会把"年龄恰等于基准"这一合法情形误判成不同源）；拒绝文本不再写明来源；消息里出现连续空格（新加的
渲染自检因此变红）；门面转发丢掉时钟参数。

---

## 8. 第 2 步落地记录（第二十轮）

`SystemOp::CollectGarbage`（`Idempotency::Required`、`Role::Admin`、`mutates_revision: true`、
`CostClass::Large`、**没有** `dry_run` 字段）→ `CommandKind::StorageGc` → 一次任务。落地时的四处决定，
都不是风格问题：

- **没有 `dry_run`。** `system.gc-plan` 就是 dry run。同一个语义留两个入口（一个 flag、一个操作），第一次
  有人只改其中一个时，报告与删除就开始说的是两件事。
- **周期执行的就是它报告的那份清单。** `GcPlanSummary` 同时带 `collect`（给人看的字符串）与 `sweep`
  （给 store 的 `ObjectDigest` 列表），两者由同一次计算产生；删除走
  `caly_storage::gc::sweep_objects(store, plan.sweep, …)` —— 从 `run_object_gc` 里拆出来的那一半。
  `run_object_gc` 仍然是"自己算自己删"，因为它的语义就是"跑一轮"；引擎这条路径不能那样，
  因为它多了一条**root 不全就清空**的规则，那是 `§2.3` 而不是 `§13.2`。
- **周期不得把自己算作在飞工作。** 一旦收集是任务，`has_work_in_flight` 就会把它自己数进去，于是
  每个周期都拒绝自己。修法是 `work_in_flight_except(state, excluding_job)`，而**入队前那道门
  不继承这个豁免**（否则两个排队中的收集会互相放行）。见 `docs/ONBOARDING_NOTES.md §4.82`。
- **拒绝是记录，不是失败请求。** 忙或 root 不全时，任务被接受、执行、然后以 `JobOutcome::Failed`
  结束并留下 `GcRunRecord { refused: Some(..) }`；`doctor` 与 `storage-gc` 段都写明"refused: …"，
  与"跑了、但无事可做"（`deleted=0` 且无 refused）区分开。入队前那一道则是 overload 拒绝（下一节）。

### `StorageBusy` 第一次有了生产者，以及它与 `OVERLOAD_AND_RETRY_MODEL §6.2` 的区别

`OVERLOAD_AND_RETRY_MODEL §3.4` 的 `StorageBusy` 自第十三轮起有分类、有映射、**没有生产者**。本轮给它
接上第一个：`submit_command` 在看到 `StorageGc` 且引擎有在飞工作时，于**任何改写之前**拒绝
（`§3.1` 对 `QueueFull` 立的规矩，`§4.58` 记过违反它的代价：拒绝不得推进 `generation`，否则中毒别人的
`expected_revision`）。测试同时钉住"什么都没删"和"`state_revision` 没动"。

它**不是** `docs/OVERLOAD_AND_RETRY_MODEL.md §6.2` 设想的那个争用（cutover 期间对同一份存储的写争用 +
recovery-sensitive 升级）。那句话当时留在 `§6.2` 与未覆盖清单里，不许因为类别名相同就被读成已完成。

> **第二十七轮更新**：那一个争用已经落地，落点不在本 ADR —— 见
> `docs/adrs/ADR-036-bounded-port-executor-and-enforced-ctx-limits.md §6bis-octies`
> （逐步意图记录 + 写不下去就 refuse 那一步 + `§6.2` 三条要求各有裁判）。本 ADR 这边**没有**新增东西：
> 回收周期仍然只在引擎 idle 时跑，那条拒绝仍然只是入队前的准入拒绝。
> 编号本身也留了一条教训：本节此前写作「`§6.2`」而不带文件名，于是被抄成了「`ADR-038 §6.2`」，
> 而 ADR-038 没有 §6.2（`docs/ONBOARDING_NOTES.md §4.107`）。

### 顺带纠正一处本 ADR 写错的事实（`§4.81`）

`§6` 曾写"计划需要 daemon 告诉它哪个快照是 active 的，因为那是 daemon 拥有的事实"。**错了**：daemon 里
两处 `runtime.active_snapshot = …` 都来自 `latest_last_known_good`，也就是说这件事本来就由 store 回答。
于是本轮把它移进 `EngineState::active_snapshot_id`，由**产生它的那一刻**写入（`finalize_apply_persistence`
成功之后），恢复路径在同步镜像时一并告知；`storage_gc_plan` 不再收参数。留着旧写法会怎样：daemon 与引擎
各持一份"当前快照"，一旦某个提交路径忘了更新镜像，root 集就安静地少一类保护 —— 而少一类保护在这套设计里
意味着可以删掉正在用的东西。

### 未随本轮落地的部分（第二十轮当时的记录）

- `§13.2` 的 **idle 自动触发**（低优先级后台任务）：机制都已就位（同一个 `would_run` 判定、同一个
  `sweep`），当时缺的是"谁在什么时候允许系统自己动数据"的策略决定；该策略已在第二十五轮以默认关闭、
  role-gated `AutomationPatch(gc.idle)` 落地。
- 真实部署的 `Clock` 注入当时仍等组装根；`calyd` binary 后续已提供 `StdClock`，因此旧的“无 bin / 必然
  `clock-timeline` 拒绝”只保留为历史证据，不是当前快照。

### 本轮证伪（第 2 步）

9 条变异全部咬住：被拒的周期不写记录 / `would_run` 只看 root 不看资格 / 周期把自己算作在飞工作 /
入队门被去掉 / 入队门改成也推进 `generation` / 边界值不在入队前校验 / root 不全时只清 `collect`
不清 `sweep` / 越界拒绝借用 key 的 remediation / 越界拒绝被计入 key 计数器。

其中四条（记录是否写下、资格半边、remediation、计数器范围）**一开始没有对应断言**，是这轮证伪把它们逼出来
之后补的；而 harness 本身也误报过一次 —— 它把 `cargo test` 的 `error: test failed` 当成编译失败，于是
"红"被读成"没咬"。两条都记在 `docs/ONBOARDING_NOTES.md §4.84`，教训按惯例写在这里：
**证伪工具也要被证伪**，否则它的假阴性会被我读成"断言已经够了"


## 9. `§13.2` idle 自动触发落地记录（第二十五轮）

第 8 节末尾把这条留在"需要 `Roadmap` 级别的一次讨论"上。本节就是那次讨论 + 落地（维护者已把此类裁决
交由此方自行决定，`ADR-035 §6bis` 是同一个授权来源）。

**谁允许系统自己动数据**：不是新加一个配置开关，而是**已有的 role-gated 自动化面** ——
`AutomationPatch { job_id: "gc.idle", enabled: true }`（`Role::Admin`）。理由：那条命令本身就是"允许 daemon
自己动数据"的一次可归责记录（进 idempotency 表、进事件流、进 support bundle），再做一个隐式开关只是多出
第二个需要授权的地方，而两处授权迟早不一致（`§4.81` 的形状）。**默认关闭**：没有那条命令的部署行为与本轮之前
逐字节相同 —— 全套 433 条断言在启用与否两种情况下都通过，这就是"默认关闭"的实测读法。

**什么时候算 idle**：不在这里重新判定。`storage_gc_plan_except(bounds, None)` 已经算了
`would_run = roots_complete && eligibility(idle, pending_deployments)`，本轮的 gate 只读它的结论。于是
"引擎忙 / 有 pending deployment / root 集不全"这三种情况下自动周期**根本不会排队**，而不是排了队再被拒 ——
两者的观测差别很大：前者不产生 job 行，后者留下一次"refused"。

**多久一次**：`IDLE_GC_INTERVAL_CHECKS`（4）次 **idle 检查**，不是毫秒。本引擎没有可轮询的宿主时钟
（根 `clippy.toml` 只豁免 `caly-io-std`），而按真实时间调度会让崩溃矩阵失去可复现性（`ADR-022`）。
检查点唯一：`consume_one_skeleton` 在 `poll_next()` 说"没活了"的那一刻 —— 所以自动化永不插到调用方命令之前。
两条配套规定：
① 计数器**只在启用时**前进（未授权期间的计数会把第一次启用变成"立刻就跑"）；
② 计数器**单调、永不重置**，到期判据是 `checks % interval == 0`。第二条不是风格问题：自动周期的幂等 key 由它
派生，一个会在触发后归零的计数器让第二次自动周期拿到与第一次相同的 key，被 dedup 吞成**重放** ——
收集器从此安静停摆，而 `last_gc_run` 看起来仍然正常。两头各有一条断言
（`the_key_of_each_due_check_is_unique_for_the_whole_process`、`a_second_cycle_is_not_a_replay_of_the_first`）。

**tick 与 cycle 分家**：tick 只 `submit_checked` 一条正常的 `StorageGc` 命令；删除由那条命令执行时走的
**同一条**路径完成（同一个 `would_run` 门、同一份 sweep 清单、同一条 `GcRunRecord`）。自动化没有自己的删除
实现 —— 有一份就意味着有一份会漂移。

**归属与一句重复的话**：`GcRunRecord::triggered_by`（`caller` / `automation:gc.idle`）写进 `summary_line`，
`doctor` 的 note 与 bundle 的 `storage-gc` 段因此看到同一句。判定方式是"这条周期的 job id 是否等于
`state.idle_gc_claim`"，不是"谁去清一个标志位" —— 后者会让一条恰好排在自动周期之前的人工收集把标签抢走。
顺带处理了本 ADR 自己埋着的一处漂移：`caly_api::GcRunView` 是这份记录的双胞胎 DTO，**从来没有生产者**，
它的 `summary_line` 于是可以长期与引擎那份悄悄分家而没人报错（`docs/ONBOARDING_NOTES.md §4.102`）。本轮给它
补上同一字段，并用一条断言把两句话钉在一起，而不是留给下一个人去踩。

**第二十六轮补记（它现在有生产者了）**：`system.gc-plan` 的答案带上了 `last_run: Option<GcRunView>`，
于是「两个渲染器一条断言」从预防性变成真的在守一条路径 —— 客户端那一行由 DTO 渲染、`doctor` 那一行由
引擎记录渲染，两者读的是同一次周期。同时 `None`（这个进程没跑过）与 `Some(deleted = 0)`（跑过、无事可做）
在客户端侧也分开了：过去只有 operator 侧分得清，这正是第 2 步立意的延伸。字段级映射由
`crates/caly-daemon/tests/gc_run_view.rs` 逐条钉住（含 `triggered_by`：映射时最容易丢的就是这种没人读的字段）。

### 本轮证伪（`§13.2`）

11 条变异全咬住：due 判据偏一格 / 启用位不再参与判定 / 空仓库也照样排周期 / 拒绝原因的顺序被换 /
未启用时也推进计数器 / 计数器触发后归零 / claim 不写 / 标签按"清标志位"而不是按 job id 匹配 / 引擎那份行
丢掉归属 / DTO 那份行与它分家 / 两个 trigger 字符串互换。

**两条没有对应断言的性质，是结构性的，本轮不补测试**（写在这里，免得下一个读者以为漏了）：

- *"检查点唯一在队列空的那一刻"*：把 `idle_gc_tick()` 挪到 `consume_one_skeleton` 的任何位置都不改变可观察
  行为 —— 因为计划自己会因 `work_in_flight != 0` 判定 non-idle 而拒绝排队。两道防线各自成立，所以单点变异
  测不出来；真要退化需要两道同时被改。
- *"自动周期不会与调用方争抢"*：同上，且 dedup 表在这里反而是第二道锁（同一 key 不会排两次队）。

而 **M6 跑了三次才咬住**这件事不是变异的问题，是我前两次断言的位置问题（`docs/ONBOARDING_NOTES.md §4.104`
的补记）：计数器一重置，触发点就跟着移动，固定长度的 drain 循环恰好让两次触发落在不同的检查号上。第三次把
两次触发钉到确定的 check 数（`interval - 1` 与 `interval`），它立刻变红。

**没做的事**：不做"自动 dry-run 再自动执行"的两段式（`would_run` 就是那个 gate，多一段流程只多一处可失败）；
不给自动周期设 `Ctx.deadline_ms` 覆盖（它没有调用方，用引擎默认，含第二十四轮的 64 次预算 —— 那条路径今天
也**不接** `RunLimits`，因为 `sweep_objects` 走的是 `run_ready`：既不被告绝也就不可计费，符合第 24 轮定的
"只给可被拒的访问计费"）；`Roadmap` 的对应条目已改，不留"剩余：GC 生产接线"这种过期句子。

## 10. 第 4 步落地记录（第三十二轮）：内容树的另一半

`RFC-0007 §6.1` 把 GC 的根分两半：对象记录的半边（第 3 步落地）与**内容树的半边**——本轮补上。
计划不再"只扫元数据"：孤儿内容与写残留进入同一份 plan、同一条 summary、同一个门。

**端口**：`ObjectStore` 增 `list_content()`（枚举内容树，产出 `gc::ContentEntry`：anchor、
`modified_at_unix_ms`——未知即 `None`）与 `delete_content(&target)`。两者默认
`Err(Unsupported)`——能力缺口必须显式：engine 读到 `Unsupported` 记 `GcRootGap::new
("content-tree", …)` 并判 `roots_complete = false`（周期照旧可跑，但计划自认瞎了一只眼），
绝不让缺口静默变成"空树所以没孤儿"。

**fs-store 的走树**：`objects/sha256` 无 `read_dir` 递归（端口层只有单级 `Fs::list`），于是
逐级枚举：level-0（`00`–`ff`）→ level-1 → 叶级。每级——含 level-0——都计入目录预算
（`MAX_CONTENT_WALK_DIRECTORIES = 1024`）：超限即 `CapacityExceeded`，**不部分遍历**（半棵树
算出来的"无孤儿"比不算更危险）；叶里出现既非 hex 叶名也非写残留的名字即
`IntegrityViolation`，**不静默跳过**。anchor 形状在入口就有门：hex 撑不起两级前缀（<5 位）
⇒ `IntegrityViolation`——这条是契约测试写成的当轮抓到的真缺陷（`ONBOARDING_NOTES §4.132`）：
短 anchor 曾拼出 `objects/sha256/00//` 的空路径段。

**InMemory**：内容按 anchor 重键（原布局按对象 id 埋内容，无法回答"哪些 anchor 在树里"）；
`delete_content` 与 fs-store 同形拒绝仍被对象记录引用的 anchor；`keep_orphan_content(anchor, bytes)`
是测试后门，生产语义为零。

**计划与预算**：`plan_orphan_content` 与对象半边同规则——被引用者永不入围、未知年龄者永不入围
（`None => false`，与 `collect_gc_roots` 同句理由）、过 grace 者入围、残单列为
`ContentTarget::Residue`。**删除预算是共享的**：`remaining_budget = max_deletions −
plan.collect.len()`，对象先花、内容花剩下的——一轮 `max_deletions = 1` 时，第二个孤儿内容
必须 deferred，这条有专门的裁判（`objects_and_content_share_one_deletion_budget`）。

**执行与可见性**：`GcRunRecord.summary_line` 与 `GcRunView.summary_line` 仍逐字同源，新增
`content_deleted={} content_failed={}` 段；两条 plan summary（计划侧/周期侧）有意不同渲染，
各自携带 `content_orphans= content_collect= content_grace= content_deferred=`。daemon 的
`GcPlanView` 增 `content_total / orphan_collect / orphan_skipped_for_grace /
orphan_deferred_over_cap`，与 engine 侧一一对应（parity 测试钉死）。

**叶子字母表**：走查与删除门共用一条常量关系——anchor 是 64 位 hex（`caly_common::digest`），
两级前缀花掉 4 位，所以叶子名恰为 60 位（`CONTENT_LEAF_HEX_LEN`，`const _` 断言钉住 64−4=60）。
错长 hex 叶与半长 stem 的残渣都是损伤（`IntegrityViolation`），不是可删目标：`ab/cd/ff`
不是 anchor `sha256:abcdff`。这是第三十二轮复核清单上唯一遗留项，本轮内收口（两条门禁
`a_leaf_of_the_wrong_hex_length_is_damage_not_an_anchor` /
`a_residue_whose_stem_is_not_a_full_leaf_is_damage`，各自变红过一次再入库）。

**本轮证伪**：`scripts/falsify_round32.py`，15 条变异全部咬住（walk 不达叶级 / 引用判失忆 /
未知年龄可删 / grace 反转 / 两后端各一条"引用中内容可删" / 残留误分类 / 非法形状放行 /
预算永不触发 / 能力缺口改类名 / 执行跳过内容清扫 / 预算翻倍 / 记录句子丢内容半 /
叶子错长放行 / 残渣半长 stem 放行）。
其中"引用中内容可删"在 fs-store 与 InMemory 各验一次——同一性质两个接缝，`§4.121` 的规矩。
M8（字母表门）的第一版在长度门收紧后不咬：`NOT-HEX` 先被长度挡住，字母门需要 64 位非 hex
的输入才有牙——门各有其输入，清单里两条现在各咬各的。
