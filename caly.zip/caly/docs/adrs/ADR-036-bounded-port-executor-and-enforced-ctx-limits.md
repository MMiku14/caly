# ADR-036: 端口调用需要有界执行器；`Ctx` 的 deadline / cancel / budget 必须被真正执行

- Status: Accepted（2026-08-28 定稿；§6bis 记录唯一需要表态的技术点与两步前置修正；**第 0 步已于第二十一轮落地**（§6bis-ter），**第 1 步已于第二十二轮落地**（§6bis-quater），**第 2 步已于第二十三轮落地**（§6bis-quinque，含它到不了的那一半），**第 3 步已于第二十四轮落地**（§6bis-sexies：`max_requests` 生效、默认值收窄并写进 release note；`max_bytes` 当时仍未生效，后由 §6bis-decies 接入端口并固定为单次上限）；**`§2.5` 的探针时限已于第二十六轮落地**（§6bis-septies，至此 `§1` 表格里五个"没人读"的字段只剩字节预算一项）；
  **第 2 步剩下的那一半（逐步游标）已于第二十七轮落地**（§6bis-octies：cutover 窗口先记账后动手，一条命令一个预算计数器，
  `OVERLOAD_AND_RETRY_MODEL §6.2` 的三条要求各有裁判）；**`§2.6` 那句"`block_on_ready` 必须升级为在期限内轮询到 ready"
  已于第二十八轮落地**（§6bis-novies：store 接缝改为有界轮询，挂起保住它自己的类型；"在 `Deadline` 内"这一半仍未做，
  理由与它缺的东西写在一起）；**`§1` 表格里最后一个"没人读"的字段（`IoBudget.max_bytes`）已于第二十九轮接上**
  （§6bis-decies：由端口自己执行、两个后端跑同一组契约断言；记账形状与 `§2.4` 的"累加"不同，偏离写在同一节）；
  第 4 步的通用阻塞池/transport runtime 仍未开始；`StdProc` 已有独立的 spawn/try_wait/stop 真核 slice，但不等于通用池已落地；第六十三轮另以 `ADR-049 §2.4` 落地 `StdHttp`/`SimHttp` 共享 `caly_io` helper 的 caller deadline anchoring/check 与 `HttpSourceUpdateWorker` 的 HTTP→parse→CAS→D3 phase probes；这是 source 纵向切片的 phase-boundary 落地，不是把单个 blocking syscall 说成可被 token 即时中断）
- Date: 2026-08-27
- Decision-Makers: Caly 接续开发方
- Related-RFCs: RFC-0001, RFC-0006, RFC-0007, RFC-0008
- Supersedes: None

---

## 1. Context

`RFC-0006 §5` 规定所有端口调用共享 `deadline / cancel_token / io_budget`，`ADR-021` 进一步要求它们
"贯穿到每个 Port 调用"，`ADR-013` 的 Follow-up 里写着"为 `caly-io-std` 定义统一的 bounded blocking pool"。
这三条今天都**没有承载体**。逐条实测（不是推测）：

| 要求 | 现状 | 复现 |
|---|---|---|
| `Ctx.deadline_ms` 限制调用时长 | 值被逐层传递（envelope → `RequestContext` → `Command.timeout_ms`），但**没有任何一处读取它做超时** | `grep -rn "deadline_ms" crates/ \| grep -v "None\|Option\|:"` 只剩赋值 |
| `Ctx.cancel_token` 支持协作取消 | 字段**不存在**：`RequestContext { trace_id, actor, deadline_ms, expected_revision, io_budget }` | `grep -rn "cancel" --include=*.rs crates/` 仅命中 CLI 的字符串映射 |
| `io_budget` 限制单次 IO | `IoBudget::unlimited()` 是**唯一**构造方式，且 `request_map.rs:99` 把入站请求的预算直接写死为 unlimited | `grep -rn "io_budget" crates/` |
| 端口 `BoxFuture` 可挂起 | 没有执行器。`caly_io::runtime::block_on_ready` 只 poll 一次，`Pending` 直接返回错误 | `crates/caly-io/src/runtime.rs` |
| `Probe { deadline_ms }`（`ADR-016` verify gate 的时限） | 值存在于计划里、出现在日志里，`SimulatedRuntime` 只把它打印出来 | `crates/caly-engine/src/sim_runtime.rs` 的 probe 分支 |

> **已修（第二十六轮）**：这一行现在成立了 —— 耗时由运行时报告、由执行器判定，超限走既有验证失败分支；
> 落地形状与理由见 `§6bis-septies`。上面那段保留原样，因为它是本 ADR 立项的依据，不是一句过期的抱怨。

这不是"实现还没写到那么细"，而是**结构上无法写对**：一个只能"poll 一次且要求立刻 ready"的执行模型，
没法表达"等到 deadline 为止"，也没法表达"被取消后返回 `Cancelled` 而不是 `Timeout`"
（`RFC-0006 §5.2` 要求两者可区分）。

它同时是三个待办的共同阻塞点（见 `docs/DEVELOPMENT_LOG_2026-08-27.md`）：

1. `caly-io-std` 的 `Http` / `Proc` 适配器 —— 订阅下载与 core 进程等待必然要挂起；
2. `caly-ipc` 的 transport 运行时（读写泵、reconnect、timeout 调度）；
3. 用端口实现真实 `EffectRuntime`（现在只有确定性仿真后端）；
4. `ADR-014` 的 D3 语义里"fsync 之后再决定"的等待。

约束：工作区零外部依赖（`docs/ONBOARDING_NOTES.md §1.4`），且 `ADR-022` 要求这套东西**可仿真、可复现**：
执行器不能引入真实时钟不确定性，否则崩溃矩阵回归测试失去意义。

---

## 2. Decision

1. **端口保持 `async` 形状**（`BoxFuture` 签名不变），但增加一个**自有、有界、可注入时钟**的执行器：
   `caly-io` 内提供 `BoundedExecutor`，规则写死如下：

   - 单线程、任务队列长度固定（默认 `max_tasks = 64`），**超出即拒绝**并返回
     `IoFaultKind::Busy`，而不是无界排队（对齐 `ADR-013` 的"有界执行域"）。
   - 时钟与睡眠来自 `Clock` 端口，不自建真实调度：仿真下 `sleep_until` 由虚拟时钟推进，
     因此"超时"在测试里是确定的、可穷举的。
   - 只保证**公平推进**，不保证吞吐：它的作用是"让挂起可表达"，不是替代 tokio。
2. **`Ctx` 补齐两个字段**（`RFC-0006 §5` 已列为最低要求）：

   ```text
   pub struct RequestContext {
       ...,
       pub deadline: Option<Deadline>,        // 绝对期限，由单调时钟计算
       pub cancel: CancelToken,               // 默认未取消；可被父调用派生子令牌
   }
   ```

   - `CancelToken` 是 `Arc<AtomicBool>` + `Arc<Notify>` 级别的最小实现，可克隆、可派生
     （子调用的 token 在父取消时一起取消）。
   - `deadline_ms` 保留为入站字段，但在边界处换算成绝对 `Deadline`，避免"每层各自减剩余时间"的漂移。
3. **超时/取消由执行器统一施加**，不由每个端口自己实现：
   `spawn_bounded(ctx, fut)` 在 `Deadline` 到期或 token 触发时把 future 丢弃并返回
   `Timeout` / `Cancelled` —— 二者必须是不同 `IoFaultKind`，这是 `§5.2` 的硬要求。
4. **预算真正记账**：`IoBudget` 由执行器持有计数器，`Fs.read` / `Http.fetch` 前后累加字节数与请求数；

   > **第二十九轮的偏离（§6bis-decies）**：`max_requests` 按这句话做（执行侧计数，第二十四轮）；`max_bytes`
   > **不做成累加计数器**，而是每次调用的上限，由端口自己执行。原因是这句话预设的"执行器持有计数器"在这一层
   > 拿不到调用方的作用域：`StorageBackend` 的方法不带 `Ctx`（`RFC-0007` 冻结），而挂到 store 上的计数器会跨
   > 进程累计、把下一个无辜调用方拒掉 —— 那不是预算，是停机。字节的执行点因此下沉到端口，`RFC-0006 §5.3`
   > 要求的正是"单次操作的资源消耗"。
   >
   > **第三十四轮补记**：上段的理由（store 签名不带 `Ctx`）已被 `ADR-039` 第 1 步消除，累计的那
   >   一半在第 2 步补上——meter 挂在 `RequestContext.byte_meter`（克隆共享、调用方作用域），规则
   >   收在 `caly_io::budget` 的 `admit_bytes`/`admit_unit`/`charge`，fs 与 memory 同门。单次上限
   >   （端口）与累计 meter（store 接缝）并存：前者仍是一次操作的硬界，后者是命令作用域的账。
   `request_map` 不再写死 `unlimited()`，而是从 `RequestEnvelope.io_budget` 透传；缺失时才用默认值，
   且默认值**必须在文档里写明**（不再是无限）。
5. **`Probe { deadline_ms }` 由 `EffectRuntime` 执行**：探针超过时限记 `Timeout`，
   按 `ADR-016` 走"验证失败 → 不提交快照"这条既有分支，而不是新增状态。
6. `caly-io-std` 的阻塞式宿主调用（`File::sync_all`、`thread::sleep`）放进**一个专用阻塞线程 + 有界队列**
   （`ADR-013` 的 Follow-up 项），端口只提交任务、不阻塞驱动线程。
   在没有该线程池之前，`StdFs` 允许继续"同步且立即 ready"，但 `block_on_ready` 的
   "只 poll 一次"必须升级为"在 `Deadline` 内轮询到 ready"，以免新后端一挂起就报内部错误。

   > **第二十八轮：这句话的"以免新后端一挂起就报内部错误"那一半已经落地** —— store 接缝不再要求端口首次
   > poll 即就绪，而是有界轮询到 ready，超预算如实报 `Busy`。"在 `Deadline` 内"那一半**故意没做**：
   > 判期限要有时钟，而这一层没有（也不该有 —— `clippy.toml` 禁宿主时钟，`§4.86` 说只有拿时钟的那一层能判时间），
   > 更根本的是**今天没有任何东西值得等**：所有真实端口都在第一次 poll 里做完了活。等一个"完成事件"是第 4 步
   > 阻塞池的事，那时 `caly-storage/src/port_drive.rs` 的预算会长出一个来自注入 `Clock` 的期限，
   >
   > **第三十五轮补记**：期限那一半先于阻塞池落地——`ADR-039` 第 3 步：store 以 `with_clock` 注入
   >   钟、`drive_port` 把 ctx 的期限与取消一并递给 `Drive`。轮询之间读钟即可判限，不必等完成事件
   >   （"有界池"实证为该步的不必要前提）；无钟 ⇒ 期限忽略不猜。阻塞池仍是真阻塞调用的前提。
   > 而不是在这里数墙上的时间。见 §6bis-novies。

---

## 3. Alternatives Considered

- **方案 A：维持现状（只 poll 一次，端口一律不许挂起）**
  - 优点：零依赖、零调度、确定性天然成立；今天的 157 个测试全部基于它。
  - 缺点：`deadline` / `cancel` / `budget` 永远只能是装饰；`Http` / `Proc` / transport 三项被永久阻塞。
  - 不采纳原因：把一个临时限制变成架构前提。

- **方案 B：引入 tokio（或 async-std）**
  - 优点：一次解决调度、超时、取消、阻塞池，生态成熟。
  - 缺点：与"零外部依赖"的既有前提正面冲突；更关键的是**破坏确定性仿真**：真实定时器与多线程调度
    让 `ADR-022` 的崩溃矩阵回归不可复现，除非再造一层抽象，而那一层的复杂度已经接近方案 C。
  - 不采纳原因：代价不是"多一个依赖"，而是把可复现性换成便利性；本项目最核心的承诺恰恰依赖前者。

- **方案 C：把端口改成同步 trait（去掉 `BoxFuture`）**
  - 优点：与执行模型完全一致，删掉一整层适配代码（现在有三处在手写 poll/驱动），实现最简单。
  - 缺点：流式读取、下载进度、`open_stream` 的背压、跨进程等待都无法表达；
    `RFC-0006` 冻结的签名要全面改写；取消只能在调用边界外粗暴 kill。
  - 不采纳原因：端口层的目标就是"隔离世界"，同步化会把世界的阻塞性直接搬进控制面。

- **方案 D：执行器放在引擎（`caly-engine`）而非端口层**
  - 优点：引擎已经有 job/queue/worker 概念，看起来能复用。
  - 缺点：`ADR-011` 的分层是"端口是唯一 IO 网关"；把调度放在网关**之上**意味着每个网关使用者
    都要依赖引擎，`caly-storage::fs_store` 首当其冲（它现在只依赖 `caly-io`）。
  - 不采纳原因：方向反了；调度属于"如何执行 IO"，属于网关自身职责。

---

## 4. Consequences

### Positive

- deadline / cancel / budget 从"字段"变成"行为"，`RFC-0006 §5` 与 `ADR-021` 首次可被测试证伪。
- 阻塞项一次性松动：`Http` / `Proc` 适配器、IPC transport、真 `EffectRuntime` 都只需实现端口，
  不必各自发明调度。
- 超时与取消在仿真里由虚拟时钟驱动 ⇒ **可以确定性测**："deadline 到期正好落在第 3 个 effect step"
  这类用例进入崩溃矩阵的同一套机制。
- 队列有界 + 预算记账，使 `OVERLOAD_AND_RETRY_MODEL.md` 里"IO 侧过载"有真实数据来源。

### Negative / Trade-offs

- 多一份要长期维护的调度代码；它的正确性（公平性、无饥饿、无泄漏）本身需要测试。
- 丢弃已挂起的 future 会遗留**未完成的宿主操作**（例如 rename 到一半）：必须由端口的
  `write_atomic` 之类的幂等语义兜底，而不是执行器解决。这正是"先写内容、后写元数据"的顺序
  （`caly-storage::fs_store`）成为硬性要求的原因。
- 单线程有界执行器在真负载下会成为瓶颈；本决策明确它**不是**吞吐组件，扩容属于后续 ADR。
- `IoBudget` 默认值不再是无限，可能让既有调用方在预算耗尽时首次收到 `CapacityExceeded`。
  这是修正而非回归，但需要 release note。

### Follow-up Work

- `RFC-0006`：补 `Deadline`/`CancelToken` 的字段定义与错误映射表（`Timeout` vs `Cancelled`）。
- 契约测试新增三条（必须在 `StdFs` 与 `SimFs` 同时通过）：
  deadline 到期返回 `Timeout`；取消返回 `Cancelled`；预算耗尽返回 `CapacityExceeded` 且不产生部分写入。
- `caly-io-std`：有界阻塞线程池 + 指标（队列深度、拒绝计数），供 `caly doctor --io` 读取（`ADR-013`）。
- 引擎侧：`Probe` 超时接入既有 `ExecutionStatus`，并进入 effect 崩溃矩阵。

---

## 5. Compatibility and Migration

- 破坏兼容：`RequestContext` 增加字段、`IoBudget` 默认值改变。二者都不是公开 DTO 字段
  （`RequestEnvelope` 保持现有 `deadline_ms` / `io_budget` 线格式），因此**不影响 API 协议版本**。
- 迁移顺序（每步独立可回退）：
  1. 先加 `BoundedExecutor` 与 `Deadline/CancelToken` 字段，端口行为不变（继续立即 ready）。
  2. 再把 `block_on_ready` 换成执行器驱动，`caly-engine::recovery::run_ready` 改为委托。
  3. 然后接 `request_map` 的预算透传与默认值变更。
  4. 最后引入 `Http` / `Proc` 适配器与阻塞线程池。
- 不需要数据迁移：本决策不改存储布局，因此不动 `STORAGE_SCHEMA_VERSION`。
- 与 `ADR-035` 的关系：那一条改**端口能力**（list/mtime/路径基准），本条改**端口执行模型**；
  两者互不依赖，但 `Http` 的 body 上限契约（`RFC-0006 §15.3`）必须等本条落地后才能测。

---

## 6bis. 定稿：那个需要表态的技术点、两处必须先行修正的事实

1. **`§6` 留白的那一点，决定如下：时钟由端口注入，不给 `caly-io` 开 clippy 豁免。**
   根 `clippy.toml` 禁 `Instant::now` 只豁免了 `caly-io-std`（真盘实现读宿主时钟是它的职责）。
   执行器如果自己数时间，"确定性仿真"（`ADR-022`）就从设计上退化为约定：崩溃矩阵、超时用例都要靠
   "碰巧调度一致"才复现。所以 `BoundedExecutor` 的等待/到期判定一律来自 `Clock` 端口，测试里是虚拟时钟，
   `caly-io` 也不新增任何豁免条目。
2. **§2.4 与 §5 各有一处与代码不符的说法，实现前必须先改**（本轮复核 `grep` 出来的）：
   - "`request_map` 不再写死 `unlimited()`，而是从 `RequestEnvelope.io_budget` 透传" —— `RequestEnvelope`
     **没有** `io_budget` 字段（`crates/caly-api/src/envelope.rs` 的字段是 protocol / request_id / trace_id /
     deadline_ms / expected_revision / idempotency_key / role / operation）。`Ctx.io_budget` 因此今天
     根本没有抵达 daemon 的路径：它不是"被写死覆盖"，而是**到了 `Command.context` 就没人再读**。
     落地要先给 envelope 加一个可选字段（`Option<IoBudget>`，`None` = daemon 默认），再谈默认值。
   - "`RequestEnvelope` 保持现有 `deadline_ms` / `io_budget` 线格式" —— 同理，`io_budget` 不在现有线格式里。
3. **落地顺序不变（§5 的四步），但第 1 步之前插一步"只加不改"**：先加 `Deadline` / `CancelToken` 类型与
   `Option<IoBudget>` 字段并让 `Timeout` / `Cancelled` 两个 `IoFaultKind` 在**契约测试**里可达（用一个故意的
   挂起端口），端口行为仍全部立即 ready。理由：没有可挂起的被测对象就先谈"执行器正确施加超时"，等于给
   一段无人调度的代码写单测。
4. **本 ADR 实现状态（第十八轮记）：未开始。** 当前 `block_on_ready` 仍只 poll 一次、`Pending` 即错误；`deadline_ms`
   仍被透传而无人据以取消；`IoBudget` 仍是 `unlimited()` 唯一构造方式。这三句每一条都是本轮 `grep`
   复核过的，`docs/IMPLEMENTATION_STATUS.md` 的未覆盖清单同此。

## 6. Notes

- 提出时标为 **Proposed**：本 ADR 会修改 `RFC-0006` 冻结过的端口语义（虽然不改签名），按
  `docs/README.md §5` 的权威顺序需要维护者确认。**2026-08-28 状态改为 Accepted**，定稿与两处事实修正见
  §6bis，**实现未开始**。在实现之前，代码侧的正确做法仍是把限制写清楚
  （`caly-io/src/runtime.rs` 的文档 + `caly-engine/src/recovery.rs` 的 `run_ready` invariant），
  而不是各处偷偷加 `#[allow]` 或自建小调度 —— 本轮依旧没有一处豁免或私有轮询。
- 现状证据集中在 `docs/ONBOARDING_NOTES.md §3.3 / §3.6 / §6.10`。
- 一条实现注意事项：`caly-io` 目前**不能**读宿主时钟（根 `clippy.toml` 禁 `Instant::now`，
  仅 `caly-io-std` 有豁免）。执行器若要自己数时间，要么把计时能力也做成端口注入（推荐，
  与 `ADR-022` 一致），要么在 `caly-io` 增加同样的 crate 级豁免并在 `ADR-011` 下说明理由。
  这是本 ADR 唯一需要维护者明确表态的技术点。

---

## 6bis-ter. 第 0 步落地记录（第二十一轮）

`§6bis.3` 要求的第 0 步是「只加不改：类型 + `Option<IoBudget>` 字段 + 让 `Timeout` / `Cancelled`
在契约测试里可达」。落地内容与该条一致，另有三处必须写下来。

### 有了什么

- `caly_io::runtime::drive(fut, Drive)`：一个**有界轮询**驱动器，三种出路互相可区分 ——
  `Cancelled`（先看取消）、`Timeout`（只有给了时钟才判期限）、`Busy`（预算耗尽且没有任何限制说过话）。
  `block_on_ready` 现在是它的 `Drive::immediate()` 包装 —— 两处 `poll` 循环合成一处，
  顺带修掉了 `caly-engine::recovery::run_ready` 那份自己手写的第三份拷贝（它连 `Wake` 都自己实现过）。
- `caly_common::CancelToken`：两个 `Arc<AtomicBool>`（自身 + 父），`child()` 只在父取消时取消。
  没有 waker 注册表，因为**没有东西会 park**：那需要 §2.1 的 `BoundedExecutor`。
- `caly_io_sim`：`hang("fs.read")` 注入一次"永远不就绪"。这是第 0 步真正买到的东西 ——
  在此之前 `Timeout` / `Cancelled` 只能由后端**自己声称**，于是"驱动器能否区分二者"这个问题无法被提出。
  `crates/caly-io-sim/tests/contract.rs` 里两条新用例把四种结局都跑在真后端上。
- `RequestEnvelope.io_budget: Option<IoBudget>`：`§6bis.2` 指出的那处与代码不符的说法就此成立；
  `request_map` 不再写死 `unlimited()`（有单元测试钉住"入站的预算抵达 `Command.context`"）。

### 一处偏离：`Ctx` 不存绝对 deadline

`§2.2` 写的是 `pub deadline: Option<Deadline>`（绝对期限，由单调时钟计算）。落地时 `Ctx` 只多了
`deadline_mono_ms: Option<u64>` 的**解释**留在驱动器一侧，daemon 边界**不填**它。理由是第二十一轮
`§4.81` 刚记过的同一件事：**把一个派生值放在没有它的源的层，就等于要求那一层记得刷新它**。daemon 没有
单调时钟（`clippy.toml` 只豁免 `caly-io-std`），所以它算不出绝对期限；而 `clock.mono()` 归零点是每个
`Clock` 实现自己的事，提前换算会把"谁的零点"藏进一个整数里。因此：入站的相对 `deadline_ms` 原样传递，
`drive` 在它**已有** `clock` 的调用点换算并判定（今天等价于不判定，因为引擎侧还没接 —— 见下）。
`§2.2` 的字段名保留为文档意图，实现里的形状是"相对值 + 由驱动器换算"。

### 一处未测的线，和为什么先留着

`caly-app::remote` 那一行 `Some(ctx.io_budget.clone())`（远端 façade 把预算放上 envelope）**没有单独断言**。
原因不是省事：在预算**没有任何可观察后果**之前（记账是第 3 步），任何端到端断言都只能断言"值被搬过去了"，
而那需要么暴露一个内部值、么造一个只服务于测试的公开 API。两个 façade 侧的单元测试已经钉住了
"同一请求两侧答案相同"这一半（本地：`Ctx` → envelope；边界：envelope → `Command.context`）。
第 3 步落地记账时，端到端那条必须一起补 —— 这一条写在 `docs/IMPLEMENTATION_STATUS.md` 未覆盖清单里，
不藏在代码注释里。

### 还没有的（第 1–4 步原样待办）

1. `BoundedExecutor`（有界任务队列 + 满了就 `Busy`）；`drive` 现在是"就地把一个 future 推到底"，
   不是调度器，也不并发。
2. 让 `caly-engine::recovery::run_ready` 换成带 `Ctx` 限制的驱动（即把命令的 deadline / token 接到
   引擎的每一次 store 访问上）——`run_ready` 的文档现在明确写了这一句。
3. `IoBudget` 记账与默认值收窄（`None` → 有界默认，需要 release note）。
4. `caly-io-std` 的有界阻塞池 + `Http` / `Proc` 适配器；`Probe { deadline_ms }` 接入验证门禁分支。


## 6bis-quater. 第 1 步落地记录（第二十二轮）

**有了什么**（`crates/caly-io/src/executor.rs`）：

- `BoundedExecutor<'a, T>`：`submit(label, TaskLimits, BoxFuture)` / `tick()` / `run_until_idle(max_ticks)`。
  准入上限 `ExecutorLimits::max_tasks`（默认 `DEFAULT_MAX_TASKS = 64`，与 `§2.1` 写死的数字一致），
  每轮每任务的轮询预算 `polls_per_task`，公平性 = 提交序 + 每任务每轮一次 `drive`。
- `ExecutorMetrics`：`submitted / rejected / completed / port_faults / timeouts / cancellations /
  peak_depth / ticks / advances / busy_stops`。四类出路各自计数，且 `submitted` 等于后四类之和 ——
  这是 `§4` Follow-up 要交给 `caly doctor --io` 的那份数据。
- `Advance::{None, StepMillis(ms)}`：**唯一**允许"世界自己走一步"的入口，且它调用的是注入的
  `Clock::sleep_until`，不是任何宿主计时器 —— `§6bis.1` 表态的那一点就此落地，`caly-io` 没有新增
  任何 `clippy.toml` 豁免。
- `crate::runtime::drive_pinned(Pin<&mut F>, Drive)`：把 `drive` 的循环抽出来给执行器复用。
  必要性不在措辞而在所有权：`drive` 按值取 future，一轮没就绪就把调用方等的东西销毁了；执行器要的是
  "还没就绪，还你"。**生产路径里的 poll 循环仍只有一份**（`Waker::noop` 命中数：1）。

**两条 `§2` 没写死、本轮定下来的语义**（各有一条断言，措辞同步写在 `executor.rs` 的模块文档里）：

1. **执行器不制造进展**。没有 `Advance::StepMillis` 时时间一格都不走，挂着的任务就是挂着，跑完预算仍以
   `Busy` 收尾（文本写明 `advance=` 与 `clock=`，即哪些限制在场）。理由：任何"再试一次也许就好了"的循环
   都是把调度器的责任偷进网关，而 `ADR-022` 要的正是可复现。
2. **端口自己的故障不改写、不重试**。`Ok(Err(fault))` 直接交给调用方（`port_faults` +1），只有驱动器的
   `Busy` 才回队。重试策略在调用方（`OVERLOAD_AND_RETRY_MODEL §4`）；`Unavailable` 被悄悄重试三次，是过载
   信号最容易消失的地方。仿真端口的 `Unavailable` **`retryable` 为假**（`FaultSpec::into_io_fault` 一个位都
   不设），所以本轮的断言比的是"两份故障相等"而不是"我以为的重试位"（`ONBOARDING_NOTES §4.91`）。

**没有时钟就不判期限**（`§4.86` 在这一层同样成立）：`TaskLimits.deadline` 有值而执行器没被注入时钟时，期限
被忽略、结果是 `Busy`；`a_deadline_without_a_clock_is_never_called_a_timeout` 钉住它。

**第 1 步故意还没做的事**：① 没有生产调用者 —— 下一个调用它的是第 2 步的 `run_ready`，在那之前 `max_tasks`
这个界只会被测试触到（与 `run_object_gc` 同类，`§4.85` 说清那是分工不是遗漏）；② 不做 `IoBudget` 记账
（第 3 步；`TaskLimits` 因此只有 deadline 与 cancel 两项）；③ 不引入 `caly-io-std` 的阻塞池（第 4 步）；
④ `Probe { deadline_ms }` 仍未接进验证门禁（`§2.5`）。


## 6bis-quinque. 第 2 步落地记录（第二十三轮）：`Ctx` 抵达 store 接缝，以及它到不了的那一半

**有了什么**：

- `crates/caly-engine/src/run_limits.rs`：`RunLimits`（`immediate()` / `for_command(&Ctx, Option<Arc<dyn Clock>>)`）、
  `StoreRefusal { kind: RefusalKind, message, limits, retryable }`。相对期限在这里、也只在这里被锚定成
  绝对 `Deadline`；**没给时钟就记为 `unjudged`**，既不当成"没有期限"也不当成"期限已过`（§4.86 的第三条腿：
  不可判要**说出来**）。
- `recovery::run_ready_in(future, &RunLimits)`：`run_ready` 保持不变（仍逐字等于 `block_on_ready` 的文案），
  新接缝才有取消与期限。拒绝原因是**数据**不是字符串 —— `RFC-0006 §5.2` 要的"二者可区分"必须活到 job 记录，
  否则只是文案上可区分。
- 接线：`EngineHandle::begin_apply_persistence(projection, &RunLimits)` 与 `advance_apply_phase(..., &RunLimits)`
  由 `worker.rs` 用 `run.store_limits()`（= `for_command(&command.context, self.storage_clock())`）填。
  `JobOutcome::Cancelled` / `TimedOut` 这两个此前**没有生产者**的变体，第一次有了。

  > **第二十七轮更正（`docs/ONBOARDING_NOTES.md §4.108`）**：上面那句里只有 `begin_apply_persistence` 是真的。
  > 本轮复核：`grep -rn "advance_apply_phase" --include=*.rs crates/` 当时只命中
  > `crates/caly-daemon/src/app.rs:647`（`seed_recovery_fixture`，一个"模拟崩溃现场"的夹具）与四个测试文件，
  > `worker.rs` 一次都没有 —— 也就是说逐步游标四轮以来只有测试在走，真实 apply 全程只在计划跑完之后写一次 journal。
  > 那句「已接线」因此不是笔误而是**未被检验的叙事**：它描述的是"接缝已经备好"，读起来却像"生产路径已经在用"。
  > 第二十七轮把它变成真的（§6bis-octies）。原句保留，因为"当初为什么会这样以为"本身是要留的东西。
- **一条 ADR 没写、本轮补上的规则**：拒绝只能阻止"开始下一步"，永远不能阻止"记下已经发生了什么"。
  所以 `finalize_apply_persistence` / `mark_apply_reverted` / `mark_apply_recovery_failed` 根本没有
  `limits` 参数（签名让错的事无法表达），而 `advance_apply_phase` 仅在
  `recovery::advance_records_touched_world(journal, phase)` 为假时才 obey 调用方 —— 判据与写记录用的是
  同一个 `phase_starts_world_effects`，两处不可能各说各话。理由：那两个 flag 是重启后的进程判断
  "核心可能已经是新的"的唯一证据，把它删掉的风险落在下一个进程头上，不在当前调用方身上。

**第 2 步到不了的地方（写清楚，别让"enforced"被读成"已经能打断一切"）**：

1. **不能打断已经开始的 store 调用**。`run_ready_in` 在首次 poll 前判取消与期限，而今天所有后端首次 poll 就
   就绪：`FsStore` 自己在内部用 `block_on_ready` 驱动端口，挂起在那一层就被摊平成 `StorageError`
   （`crates/caly-storage/src/fs_store.rs` 的 `suspension`）。于是限制要真正抵达"端口内部"，必须先让
   `StorageBackend` 的方法带上 `Ctx` —— 那动的是 `RFC-0007` 冻结过的签名，属于另一次决策，不在本步偷偷做。
   本轮的可达性证据因此分两头：`StoreRefusal`/`NotReady` 这一头用**手写挂起 future** 在
   `recovery.rs` 的单测里证明"驱动器真的在驱动"（`a_suspending_store_call_is_driven_to_readiness_within_the_budget`），
   而不是留一句"以后接上就能用"。
2. **查询侧不接限制**。daemon 的 query handler 手上是 `RequestEnvelope` 而不是 `Command.context`，
   而且"哪些查询值得被拒"是策略问题（拒一次读回，用户看到的是错误而不是重试）。留给下一步与 `ADR-037` 一起判。

   > **第三十轮的判决**（写在被引用的那一格旁边，免得"留给下一步"活成永久状态）：真正的问题不是"要不要给
   > 查询接上*调用方的*预算"，而是"查询的回答有没有上界"。本轮答的是后者 —— 两条由 store 决定大小的诊断查询
   > （`diagnostics.doctor` / `diagnostics.recovery-status`）现在带上界，且**截断必须被报告**
   > （`RFC-0002 §9` / `§11.4`，落点是 `caly-daemon/src/paging.rs` 的 `DiagnosticBudget`）。
   > 前者仍然没做，而且理由比"没空"更硬：`DoctorRequest` 没有可填的字段，加一个 `max_lines` 要动线格式，
   > 换来的能力（"给我全部"）已经由 support bundle 提供 —— 它把未截断的 audit 全文放进一个存储对象，
   > 本来就不是一帧。所以"调用方自选查询规模"现在的状态是**不需要**，不是没做到。

**本轮由证伪跑出来的两处修正**（详见 `ONBOARDING_NOTES §4.94 / §4.95`）：`is_immediate` 里一个谁也关不掉的
合取项被删掉；`fail()` 只把结算写进 cycle 结果、没写进 job 记录这一分裂被补了断言。14 条变异最终全咬住。


## 6bis-sexies. 第 3 步落地记录（第二十四轮）：预算从"字段"变成"someone reads it"

**有了什么**：

- `caly_common::IoBudget::default_command()`（`max_requests = Some(64)`，`max_bytes = None`）与
  `is_unlimited()`；`RequestContext::new`、`caly_api::default_ctx`、`request_map` 的缺省回落**共用这一个
  常量**，两处各自写死数字就是下一次漂移（`§4.81` 的同一形状）。
- `RunLimits` 多了一项**计费**：`budget` + `billed: Arc<AtomicU32>`（克隆共享，上限属于"这次命令执行"
  而不是某个副本）。`recovery::run_ready_in` 在驱动 future **之前**调用 `limits.charge()`，所以
  "预算耗尽"意味着 store 一次也没被问 —— 这条是用一个会自报被 poll 次数的 fixture 断言的
  （`CountsPolls`，`§4.98`），不是靠读代码看出来的。
- 新的拒绝种类：`RefusalKind::BudgetExhausted`，公开码 `CONFIG_INVALID` + `ErrorCategory::User` +
  `retryable=false`，job 结算 `Failed`。
- `describe()` 的预算半句永远是 `<已用>/<上限>`，未设上限也照数（`budget=5/uncapped`）：**"没设上限"与
  "没在数"是两件事**，把 uncapped 显示成没有数字就等于让运维无法区分二者。

**三条本轮定下来的解释（`§2.4` 只写了原则）**：

1. **只给"可以被拒"的访问计费。** 记真相的那几条既不拒也不计；否则调用方的上限会变成对引擎簿记的
   上限（而簿记是必须发生的）。这条是 `§6bis-quinque` 那条规则的镜像：一条规则两种用途，共用同一个
   "有没有 limits 参数"的事实，不需要第二个开关。
2. **"已计费"= 已尝试，不是已成功。** 被 `drive` 拒掉（取消/超时）的那次仍然计入 —— 因为它确实开始过。
   而被预算拒掉的那次**不计**（先把乐观的 +1 减回去），否则重试循环会被自己的拒绝反复抽税，
   第 N+1 次尝试会显示 `used=N+k`，那个数字就不叫"用了多少预算"了。
3. **预算门在取消/期限之前判。** 前者问的是过去（我已经花了几次），后者问的是现在（你放弃了 / 时间到了）。
   两真取其一时的选择必须写下来并有一条断言，否则下一个人会"顺手"改成另一序，而两种顺序在不同调用上
   会给出不同的公开码。

**没做的事，以及为什么不是遗漏**：

- `max_bytes` 不生效。引擎这一层看不见全部字节：只有一条路径（bundle 读回）知道自己拿到多大 payload，
  在那一处统计会产生"数字在涨但没数全"的假保险。端口层记账属第 4 步（`Http` / `Proc` 与 `caly-io-std`
  阻塞池），届时的落点是 `BoundedExecutor::TaskLimits`（那里已经留了位置：`TaskLimits` 今天只有 deadline
  与 cancel，注释里写明字节预算属第 3/4 步）。
- 公开错误码表**没有**加 `CAPACITY_EXCEEDED`：`RFC-0002 §14.4` 冻结了稳定码表，加一个码是 RFC 级决定，
  不由 ADR 代行。因此 `IoFaultKind::CapacityExceeded`（`RFC-0006 §5.3` 要求的端口层答案）与 API 层的
  `CONFIG_INVALID` 之间有一处**有意的落差**，两边都能解释为什么：`docs/ERRORS.md §5.1` 加了适用例。
- `OverloadClass` 没有新增预算类：那四类是**系统侧**压力（`OVERLOAD_AND_RETRY_MODEL §3`），而这里是
  调用方自己划的界限；把它塞进 overload 会让"提示重试"的语义说谎。见 `§3.7`。


## 6bis-septies. 探针时限落地记录（第二十六轮）：`§1` 表格里最后一行装饰性字段接上了

`§1` 那张表列了五个"传下去但没人读"的字段；第 0–3 步逐个收掉了四个，最后一行是 `Probe { deadline_ms }`
（"值存在于计划里、出现在日志里，`SimulatedRuntime` 只把它打印出来"）。本轮把它接上，形状如下：

- `StepEvidence` 多一个 `elapsed_ms`：**运行时报告耗时，执行器判定是否超限**。这个分工是全部要点 ——
  判定写在每个适配器里，就等于每个适配器都有一次忘记它的机会（`caly-core` 的 mock、`mihomo`、`singbox`
  各有各的探针路径），而这个字段一开始就是这么变成交代的。
- 超限 = **验证失败**，走 `§2.5` 指定的既有分支（`FailedBeforeCutover`，`retryable=true`），不新增执行状态；
  `probe_passed` 保持假，所以 `require_probe_before_commit` 那道门也一起关着 ⇒ 快照不标、修订不提交。
- 边界取 `elapsed <= deadline` 放行：用了刚好等于预算的时间不算超。差一格就是"因为你花了我给你的时间而拒绝你"。
- 合并证据时耗时取 **max**，不求和也不取最后一段：求和会凭空造出没人等过的时间，取最后一段会把真正超时那一段藏起来。
- `deadline_ms == 0` 在**计划校验**阶段拒（`validate_probe_deadlines`），且不受 `enforce_phase_order` 影响。
  两种省事读法都不行：当"无限制"就是让缺省值关掉门禁；当"零时间"就是让每个这种计划必然失败。与
  `ADR-038 §2` 拒 `max_deletions: Some(0)` 同形：**越界的上限是策略问题，缺失的上限是计划缺陷**，后者要在碰运行时之前停。

**世界模型那一侧**：`SimulatedRuntime::make_next_probe_slow(ms)` 是一次性的，与 `fail_next_probe` 同理；
被测的是"这一次探针慢"，不是"从这之后都慢"。真实适配器该用注入的 `Clock` 量出来 —— 这也是为什么耗时是
运行时*报*的数而不是执行器*读*的数：执行器没有时钟，也不该有（`§6bis.1`、`§4.86`）。

**没做**：不给 `Probe` 的超时另设 `ExecutionStatus` 变体；不把 `deadline_ms` 变成 `Option`（改成可选会让"缺失"
重新变成一个可读成两种意思的值，而校验拒 0 已经把这件事说死了）；不做"超时后重试探针"—— 重试是调用方的事
（`OVERLOAD_AND_RETRY_MODEL §4`）。

**顺带**：`caly_api::GcRunView` 在本轮拿到了生产者（`system.gc-plan` 的答案带 `last_run`），所以第二十五轮为它
加的那条"两个渲染器必须同一句话"的断言从"预防性"变成"真的在守一条路径"（`§4.102`）。

---

## 6bis-octies. 第 2 步剩下的那一半落地记录（第二十七轮）：cutover 窗口先记账，后动手

`§5` 的第 2 步写的是「把 `block_on_ready` 换成执行器驱动，`caly-engine::recovery::run_ready` 改为委托」。
第 23 轮做掉了后半（`run_ready_in` + `RunLimits`），前半（**执行过程中的游标**）留到了本轮 —— 因为它的
真正读者不是 `run_ready`，而是 `APPLY_EXECUTION_CENTERLINE.md §6.1` Phase B 的第三句要求
「必须允许 crash recovery 识别执行到哪一步」，以及 `docs/OVERLOAD_AND_RETRY_MODEL.md §6.2` 那个
"存储忙发生在游标更新时"的场景。本轮之前的实测证据（给 `EngineHandle::put_apply_journal` 临时加一行打印、
跑一次 apply）是：执行期间 store 只收到**一条** journal 写，内容是
`phase=Finalize cursor=8 net=true cutover=true state=Committed` —— 即"cutover 发生过"这件事是在
cutover **结束之后**才落盘的。进程在中间被 kill，重启读到的仍是 `pending/prepare`，
`STORAGE_RECOVERY_EXECUTION_PLAN §7.3` 的第 3 步据此把事务当成"世界没被动过"丢掉。

### 有了什么

- `caly_engine::executor::EffectCursor`：`record_intent(phase, step_index) -> Result<(), CursorRefusal>`。
  **只有一条方法**，且只在 `needs_intent_record(phase)` 为真的那一步之前调用 —— 该谓词只管 `Cutover`，
  并带一个 `const _: () = assert!(..)` 的编译期锚点。为什么 `Prepare` 不需要（可安全重做）、
  为什么 `Finalize` 不需要（那些步骤**就是**持久化动作，失败已有 `mark_apply_recovery_failed` 这条升级路），
  都写在该谓词的文档里；"没有 step-done 回调"也是同一处写的：下一条意图记录必然涵盖上一条的完成，
  窗口末位由计划结束时的 fold 负责 —— 于是"每步恰好一条"是可断言的数字，而不是"大概够用"。
- `execute_effect_plan` 保留原签名并委托给 `execute_effect_plan_with_cursor(..., &mut NoCursor)`，
  所以仿真与既有测试的输出逐字段不变（有一条断言专门比这两者相等，用来证明本轮是**加了一层**而不是改了一层）。
- `recovery::phase_starts_world_effects` / `advance_records_touched_world` 的既有判定被复用：worker 的游标
  链住自己那份 journal 副本，所以第一条记录之后该谓词自然转假 —— 窗口的**第一条**记录因此既不可被拒也不计费，
  其余各条可被拒（也就要计费）。这正是第 23 轮那条规则的逐步版，没有引入第二个开关。
- 拒绝的形状：`CursorRefusal { kind, message, retryable, caller_side }`（由 `StoreRefusal` 转换而来）。
  `kind` 与 `retryable` 都是从给答案的那一方抄的，`caller_side` 从 `is_caller_side()` 抄的；job 结算因此能继续
  区分 `Cancelled` / `TimedOut` / `Failed`，而公开错误的 code/category 与持久化接缝**共用一张表**
  （`worker.rs::public_shape_for_refusal`），两处各自映射就是下一次漂移。
- `StoreRefusal::from_storage_error`：store 自己说 `StorageErrorKind::Busy` 才升级成新的
  `RefusalKind::StorageBusy`；其余九种一律留作 `Backend`。这不是美化 —— `OVERLOAD_AND_RETRY_MODEL §6.2`
  要的正是"cutover 期间对同一份存储的写争用"这一个类别，而没有 `Ctx` 的 store 签名给不出别的。
- `EngineHandle::record_storage_contention` + `OverloadReport::journal_pressure`：mid-apply 的存储争用因此
  进入 `doctor` 与 bundle 读的过载计数（`retry_hint=ManualIntervention`，因为 `§6.2` 明写
  "不得简单提示稍后再试就结束"），并且调用方的 `detail` 引用的是**同一个** `OverloadReport::detail()`
  —— 那条 `detail()` 是从 `to_api_error` 里抽出来的，所以两个出口共用一份拼写（`§4.59` 的教训）。

### 三条要求，三个裁判

| `§6.2` 的要求 | 现在由谁保证 |
|---|---|
| 不得简单提示"稍后再试"就结束 | `OverloadReport::journal_pressure` 的 hint 是 `ManualIntervention`；`the_refused_record_shows_up_as_storage_pressure_for_the_operator` 同时钉住过载行与 `detail` 里的 `error=storage_busy retry_hint=ManualIntervention`（把 hint 改回 `RetryLater` 会让它红 —— 证伪 M11） |
| 必须进入 recovery-aware 失败路径 | `cursor_guard_failure` 附 `RecoveryDecision` 叙事，并**逐字引用这条进程真的写成功的那条记录**（phase / cursor / 两个 flag）；`a_journal_that_refuses_the_record_costs_the_world_nothing` 钉住"世界一分未动且记录这么说" |
| job follow 看到的是执行失败而非验证失败 | code 走 `public_shape_for_refusal`（`STORAGE` + `Io`，只有调用方预算耗尽才是 `CONFIG_INVALID`），另有一条 `cutover guard` 的 job warning；`only_a_busy_journal_counts_as_pressure_on_the_operator` 反向钉住"损坏记录不算拥塞" |

### 本轮顺带收紧的一处，与它的代价

`run_apply` 现在**一次**构造 `RunLimits` 并把引用交给两个有界接缝。此前每个接缝各调一次
`run.store_limits()`，而 `for_command` 每次都新建 `billed: Arc::new(0)` —— "一条命令 64 次访问"实际是
"每个接缝 64 次"。默认值下没人会撞上，所以它四轮没被发现；`the_callers_budget_bounds_the_cutover_window_too`
用 `max_requests = 1` 把它钉住（旧写法会让整个 apply 跑完）。**对调用方是可观察的行为变更**，故写进
`IMPLEMENTATION_STATUS §6bis`。

代价也要写下来：每次 apply 在 cutover 相多 N 条 journal 写（N = 该相步骤数；默认 profile 实测 2）。
`FsStore` 的 journal 写是 D3，所以这是真实的 fsync 次数增加。`§6.1` 把"必须有 pending guard"写在要求里，
本仓库选择不逃这笔账；若将来要收，得由一条新 ADR 明确改成"每条计划一条批量记录"并说清丢了逐步精度。

### 还没有的

- guard 的覆盖面 = `phase_of` 的分类正确性。一个新步骤种类若被归进 `Prepare`，它就绕开 guard；
  所以那条分类本身有断言（`executor.rs::phase_classification_matches_centerline_document`），
  且 `needs_intent_record` 的编译期锚点让"顺手扩大谓词"必须同时改注释里的理由。
- 补偿（rollback）自己不走意图记录：它的失败已经有 `mark_apply_recovery_failed` 这条升级路径，
  而"正在撤销世界改动"这件事本身由窗口内最后一条意图记录代表 —— 加一条只会多一个 fsync。
- 查询侧仍不接限制（`§6bis-quinque` 第 2 条），字节预算仍在端口层（第 4 步），`BoundedExecutor`
  仍无生产调用者：本轮接的是 `RunLimits` + 注入 sink 这条最小接缝，队列上限依旧只被测试触到。

---

## 6bis-novies. `§2.6` 前半落地记录（第二十八轮）：store 接缝有界轮询端口，挂起保住它自己的类型

### 量出来的起点

`crates/caly-storage/src/fs_store.rs` 里有一个 3 行的函数：

```rust
fn suspension(message: String) -> StorageError {
    StorageError::new(StorageErrorKind::Internal, message)
}
```

它是 `§2.6` 那句"以免新后端一挂起就报内部错误"所防的事的**实现**：`FsStore` 用 `caly_io::block_on_ready`
驱动端口（一次 poll），任何 `Pending` 都从这儿出来，被贴上 `Internal`。而 `caly_io::drive` 给出的明明是
`IoFaultKind::Busy` + `retryable=true` + `transient=true` + 一句写着用了多少 poll 的文本 —— 也就是说
**信息在端口层是存在的，被 store 这一层抹平了**。抹平的代价要到上一层才看得见：`StoreRefusal::from_storage_error`
（第二十七轮加的）认 `Busy`，把它升级成 `storage_busy` 类供 `doctor` 计数；喂给它 `Internal`，它就只能报
`Backend`，于是"盘忙"与"记录坏了"在公开错误、重试建议与运维账本上都是同一件事。

### 有了什么

- `crates/caly-storage/src/port_drive.rs`：`STORE_PORT_POLL_BUDGET = 64`（带两条编译期锚点：`> 0`，以及
  **`>= 2`** —— "一次 poll 的预算"就是旧行为披个名字，锚点让它无法被写成那样）与 `drive_port(future)`：
  调 `caly_io::drive`（生产里唯一的 poll 循环，`Waker::noop` 命中数仍为 1），把**驱动器自己的**拒绝走
  `from_iofault` 这张表，端口自己的答案仍归调用点去解释（两者是两个事实，文案必须分得开）。
  `from_iofault` 从 `fs_store.rs` **移过来**而不是复制，因为它现在有两个使用者，而 `§4.81` 记过两次各写一遍的下场。
- `fs_store.rs` 的 8 个端口驱动点与 `schema.rs` 的 4 个全部改走 `drive_port`；`suspension()` 删除。
  `exists()` 那里原本还有一处自己写的 `Internal` 映射，一并消失。
- 端口层多了一种**形状**：`caly-io-sim` 原来只有 `hang`（永不就绪）。这不足以验证一个"预算"：只有"永远不"
  的话，"驱动器放弃太早"和"端口卡死了"是同一个读数，把预算调成 1 也全绿。所以加了 `stall(label, polls)`
  （一次性、可数的挂起），于是边界从**两侧**量：`polls = 预算 - 1` 必须成功，`polls = 预算` 必须被拒
  （`crates/caly-storage/tests/store_port_budget.rs::the_budget_is_measured_from_both_sides`）。
  `hang` 与 `stall` 各用一次独立的扫描取出，不共用 `take_matching` —— 共用会让一种注入吞掉另一种（证伪 M7 就是
  把它改成共用，两条断言当场红）。
- `SimFs::write_atomic` 现在也认 `hang` / `stall`（以前只有 `read` 认）。写路径才是真 fsync 住的地方，
  "挂起"在那里最可能发生、被误报的代价也最大。
- 门禁 `the_durable_store_drives_ports_through_the_shared_budget`：`crates/caly-storage/src/**` 不许出现
  `block_on_ready(`。唯一豁免 `audit.rs`，豁免的理由写在门禁里（它驱动 `dyn StorageBackend` 的 future，
  那里已经是类型化的 `StorageError`，没有端口层的类型可丢）；另附一条"扫到的文件数 ≥ 8"的反空转断言，
  免得目录一改，门禁悄悄变成扫 0 个文件。

### 三条判断（`§2.6` 没写死的）

1. **预算数的是 poll，不是毫秒。** 见上面那句"没有东西值得等"；把 `Advance::StepMillis`（`BoundedExecutor`
   已有的、经注入 `Clock` 的推进）搬到 store 接缝，等于在没有事件可等的情况下烧 CPU 装作在等。
2. **超预算的答案是 `Busy`，不是 `Timeout`。** 没有时钟说时间到了，就不能说时间到了（`§4.86` 的第三条腿）；
   驱动器的文本（`still pending after 64 poll(s)`）逐字带出，因为它同时是"用了多少"与"上限是多少"。
3. **不引入 per-store 可配的预算。** 一开始想给 `FsStore` 加一个 `with_port_drive(...)`，被自己否了：
   迁移路径（`schema.rs`）在 `open` 里跑，一个够不着的旋钮就是下一处"看起来可配其实写死"的含混；
   常 + 两侧边界断言已经足够，真要按命令收紧，那属于把 `Ctx` 送进 `StorageBackend` 签名的那次决策。

### 证伪

11 条变异全咬住（主线 9 条走 `/tmp/falsify28.py`，一文件一变异、内容 + mtime 还原、sha256 复核；收尾补的相邻性检查另加 2 条：判据改成永不成立 ⇒ 它自带的单元测试红，改成永远成立 ⇒ 连 `doc_tables_and_lists_are_well_formed` 一起红 —— 一条检查若只在夹具上生效，它就还没接线）：把预算调成 2、把
`drive` 换回 `immediate`、把驱动器拒绝重新翻成 `Internal`、让 `fs_store` 的一处退回 `block_on_ready`、
让 `schema.rs` 自己驱动端口（这两条同时被新门禁抓到）、`take_stall` 改成只看不取（挂起泄漏到下一次调用）、
`take_hang` 改成吞掉任何 label 相同的 spec（串味）、读路径忽略 stall、engine 层不再升级 `Busy`。
最后一条是**重复第 27 轮的机制**，但换了一个新裁判：它证明本轮那两条链路断言不是装饰。

---

## 6bis-decies. `§1` 最后一行接上（第二十九轮）：字节预算由端口执行，而不是由谁数着

`§1` 的表从立项起就留着这一行：「`io_budget` 限制单次 IO —— `IoBudget::unlimited()` 是唯一构造方式」。
第二十一到第二十四轮把构造方式和 `max_requests` 的处理做掉了，`max_bytes` 则一直被记作"引擎看不见全部字节，
所以不生效"（`§6bis-sexies`）。本轮它不再是装饰，但落点**不在**本 ADR 原本设想的地方，这件事要先说清楚。

### 为什么落点是端口

`RFC-0006 §5.3` 的原文是「`io_budget` 用于限制**单次操作**的资源消耗……Budget 用尽时，Port **MUST** 返回
容量/预算类 `IoFault`」。三句话各自指向端口：受限的是单次操作、看得见操作大小的是端口、被要求返回那个
`IoFault` 的也是端口。反过来，引擎这一层：

- 它看得见"第几次访问"，看不见"这次访问多少字节"（`StorageBackend` 的方法签名里没有 `Ctx`，也没有返回值
  尺寸的统一位置）；
- 想跨调用累计，就得有个比一次调用活得久的计数器 —— 而唯一能传到端口的那份 `IoContext` 是 `FsStore::open`
  建的、全进程共享的一份。挂上去的结果是：第 N 次大写入之后，所有调用方一起被拒。那不是预算，是停机。

所以 `caly_io::budget` 提供两个函数，两个后端**调同一份实现**：

| 函数 | 语义 | 谁调 |
|---|---|---|
| `byte_ceiling(ctx, requested)` | 读侧上限 = `min(调用自带的 cap, io_budget.max_bytes)`，并记住是哪一条在管 | `Fs::read`、`Http::fetch` |
| `check_payload(ctx, resource, bytes)` | 写侧在**任何字节落地之前**拒绝超限载荷 | `Fs::write_atomic` |

"谁在管"必须进文案：把 `io_budget.max_bytes = 1024` 报成"超过 1024 字节的 cap"，调用方会去找一个它从没传过的
cap。这条区分不是礼貌，是可判定的：`caly_io::contract::fs_byte_budget_violations` 在**两个后端**上断言
文案里出现的是 `io_budget.max_bytes` 还是 `512 byte cap`（`§5.3` 的 MUST 因此有裁判，且两后端无法各说各话）。

### 四条判断（各有一条断言，不在文档里靠话说）

1. **精确等于上限是允许的** —— 与 `ByteCap` / `ListCap` 同规则；`<=` 差一格会变成"因为你正好用了我给的额度而拒绝你"。
2. **上限取更紧的那条，宽松的那条不得放大** —— `max_bytes = 8 KiB` 配 `ByteCap(4 KiB)` 仍是 4 KiB；否则设预算成了提额。
3. **没设预算不拒不截** —— `None` 就是 `None`，读成 0 会让每个未设限的调用方失败，读成"无限且不必检查"则让字段再次变成装饰。
4. **超限的写必须在写之前拒** —— `RFC-0007 §6.2` 要的正是"别留下半份文件"；契约检查里"被拒之后 `stat` 必须说文件不存在"就是这条的裁判。

### `§2.4` 的"前后累加字节数"没有落地，这是偏离而不是遗漏

累加需要一个作用域，字节的可见性在另一层（上面第二节）。把两轴的语义统一成"都累加"要么做不到、要么做错；
把它们统一成"都在 `IoBudget` 的文档里各说清楚"是可检查的。`caly_common::IoBudget` 的字段注释、`budget.rs`
的模块文档、`RFC-0006 §5.3` 的修订注现在说的是同一件事，三处各自被一条断言指着。

### 公开面：端口层的 `CapacityExceeded` 与 API 码表之间的落差照旧，但多了一个入口

`RFC-0002 §14.4` 没有容量码。端口报上来的 `StorageErrorKind::CapacityExceeded` 在引擎里被认成新的
`RefusalKind::PayloadTooBig` —— `CONFIG_INVALID` + `ErrorCategory::User` + `retryable=false`（"再试一次 payload 不会变小"
是推理，不是抄来的位），remediation 直接指向 `Ctx::io_budget.max_bytes`。它与 `BudgetExhausted` 分开的理由
是**旋钮不同**：一个数次数、一个数每次的字节，混成一个就把"拆成更小的操作"当成"减小单次载荷"的建议发出去。
两个接缝共用同一张 `public_shape_for_refusal` 表（本轮把 remediation 也并进表里，因为它是与 code 同一件事的两面）。

### 还没有的

- `link_or_copy` 不经端口搬字节（它让文件系统自己复制），因此不受该上限约束；真正走字节的是
  `materialize` 的 `Copy` 模式，那条路径是 read + write，两端都已被覆盖。
- `Http` 的 body cap 已由 `StdHttp` 与 `SimHttp` 按同一个 `byte_ceiling` 执行，并有对应 contract/parity tests；第六十三轮又把 caller deadline anchoring/check 提取为 `caly_io` 共享 helper。剩余缺口是生产 blocking syscall 的中断式 runtime，不是 `§15.3` 的跨后端 body 形状。
- `IoBudget.max_bytes` 目前**不能由调用方抵达端口**：命令的 `Ctx` 到 `RunLimits` 为止，端口看到的是
  `FsStore` 自己那份 `IoContext`。把它送进去仍然卡在同一条 `RFC-0007` 冻结的签名上（见 `§6bis-quinque`
  与 `CENTERLINE_PROGRESS §5` 第 3 项）。本轮做的是"字段有人执行、执行处只有一处、两个后端跑同一组断言"，
  没有把这条限制说成已经打通。
