# ADR-049: Http 以有界拥有字节承载响应体，不提前伪造读取器

- Status: Accepted（第六十一轮冻结 body carrier；第六十二轮落地 durable source index；第六十三轮落地 Std/Sim 共享 caller deadline anchoring、source phase-boundary cancellation/deadline 与 durable inspection projection；`StdHttp` 单个 OS blocking syscall 的即时中断仍明确不在本 ADR 虚构）
- Date: 2026-08-30
- Decision-Makers: Caly 接续开发方（维护者已把此类裁决交由此方自行决定，见 `ADR-035 §6bis`）
- Related-RFCs: RFC-0003（source pipeline/provenance）、RFC-0006 §9/§15（Http port、body cap、条件请求）、RFC-0007 §6（CAS 完整性）
- Related-ADRs: ADR-011（单一 IO 网关）、ADR-021（Ctx 传播）、ADR-022（仿真是发布门禁）、ADR-039（调用方 Context）、ADR-040（`ByteStream` 标签语义）
- Supersedes: None（是 ADR-040 §2 所说的“存在真实消费者后再决策”的后续决策，不改变 `Fs::open_stream` 的标签句柄）

---

## 1. Context

ADR-040 刻意把 `ByteStream` 保持为标签句柄：当时没有任何生产消费者从 Http 响应取字节，先造一个分块读取器只会制造没有裁判的能力。现在 source ingest 的下一条纵向切片确实需要把 HTTP 响应送入 parser，再送入 CAS；继续只返回 label 会让“取回成功”仍然没有内容证据。

进一步审查冻结层后有四个约束：

1. `FetchReq::max_body_bytes` 已经是 Http port 的请求级上限，`Ctx::io_budget.max_bytes` 是第二个上限；两者取更紧者，不能把调用方明确给出的限制扩大。
2. `StdHttp` 和 `SimHttp` 必须对同一 body 形状作答。只把模拟世界里的 `ScriptedResponse.body` 暴露出来，会使仿真通过、生产仍丢字节，违反 ADR-022 的对偶要求。
3. 当前 workspace 没有 TLS/HTTP client 外部依赖，也没有把异步分块读取器作为稳定 runtime 的执行者。把 `ByteStream` 改成带 poll/close 生命周期的 reader 会同时改 RFC-0006 的 port 形状和 `run_ready` 的执行模型，范围大于本次 source 语义切片。
4. `IoContext::deadline_mono_ms` 只有在持有同一 monotonic clock 的驱动者那里才可判定。`Http` trait 仍不把 `Clock` 放进签名；具体 `StdHttp`/`SimHttp` 由 composition root 可选注入同一 clock，并通过 `caly_io` 共享的 anchoring/check helper 执行 caller cancellation/deadline 边界。固定 socket timeout 仍不等于调用方 deadline：`StdHttp` 只能收紧一次 blocking syscall 的 socket timeout，取消和过期在 syscall 返回后还需由 source worker 的 post-call probe 观察；中途强行打断不在本 ADR 虚构。

---

## 2. Decision

### 2.1 Response body 是有限拥有字节，不是 `ByteStream` reader

`FetchResp.body` 改为 `FetchBody`：

```text
FetchBody {
  label: "http:<request-url>"
  bytes: Vec<u8>
}
```

- `label` 继续遵守 ADR-040，是调用方请求的名字，不是宿主路径。
- `bytes` 只在整个响应体通过有效上限后返回；调用方得到的是完整 body 或错误，不得到“看起来完整”的截断前缀。
- `ByteStream` 仍是 `Fs::open_stream` 的标签句柄；它没有因为 Http source consumer 的出现而被偷换成另一种语义。
- 这是一份**有界 body snapshot**，不是可暂停/可取消的 streaming reader。真正的 chunk/poll/close reader 若有调用方，必须另开 ADR，并携带它自己的 budget、deadline、drop/关闭语义。

### 2.2 两个上限取更紧，超限不返回部分字节

有效上限仍由 `caly_io::byte_ceiling(ctx, req.max_body_bytes)` 计算：

- `Content-Length` 已声明超过上限：读 body 前返回 `CapacityExceeded`。
- chunked 或直到 EOF 的 body：只读取到足以证明超限的边界，不把超过上限的字节放进返回值；返回 `CapacityExceeded`，并说明是请求 cap 还是 `io_budget.max_bytes` 触发。
- 精确等于上限：返回完整 body。
- 无 `io_budget.max_bytes`：不凭空制造一个字节预算，仍遵守请求自己的 `max_body_bytes`。
- 本 ADR 不改变现有 Http 的“单次 fetch 上限”语义，也不把 fetch bytes 偷记到 `ByteMeter`。CAS `ObjectStore::put` 仍在自身 seam 按已有规则核算写入；source ingest 以后若要把网络读取、CAS 写入合成一个调用方总预算，必须在 orchestrator ADR 中明确是两次资源移动还是一次逻辑单位，不能用一次 `charge` 遮掉这个选择。

### 2.3 Std/Sim parity 是实现要求

- `StdHttp` 从真实 HTTP/1.1 peer 收集 body；`SimHttp` 从 `ScriptedResponse.body` 返回同一 `FetchBody.bytes`。
- 共享 contract 同时判：label 的固定形状、成功 body 的实际长度/内容、请求 cap、ctx budget、未设 budget 的成功路径。
- 生产 adapter 仍只支持当前已声明的 `http://` 路径；`https://` 继续按名 `Unsupported`，不能为了 source ingest 偷换 TLS 或静默降级。

### 2.4 Caller deadline / cancellation 的 phase-boundary 语义

本 ADR 不把 `IoContext` 的相对 deadline 误当成 Http 自己拥有的时钟；但带 clock 的 source composition 已有可验证的边界执行：

- `Http` trait 仍不携带 `Clock`。具体 `StdHttp`/`SimHttp` 由 composition root 可选注入同一 monotonic clock；没有 clock 时，`deadline_ms` 无法诚实判定，不能猜成已过期或无限期。
- `caly_io::caller_deadline_mono_ms` 是两种 Http port 共用的 anchoring 规则：已有 `deadline_mono_ms` 直接使用；只有相对 `deadline_ms` 时，在 fetch 开始按注入 clock 加一次当前值，后续不为每个阶段重置计时器。
- 两种 port 都在 fetch 前和 response 边界检查 `CancelToken` / absolute deadline；`StdHttp` 还把剩余期限收紧到单次 connect/read/write socket timeout，`SimHttp` 在消费 scripted response 前后执行同一判定。共享 contract tests 固化取消和过期的 kind/文案形状。
- `HttpSourceUpdateWorker` 把同一个 anchored context 带过 HTTP、parse、CAS 与 source-index D3 commit：HTTP 返回后、parse 前后、CAS 写入后和 D3 commit 前均有 phase probe；因此取消/过期不会在已拒绝的阶段开始新的副作用。304 的 raw-body 读回也走相同边界。
- 这仍是 cooperative boundary control，不是中断式 runtime。`StdHttp` 的单个 OS blocking syscall 可能在 caller 取消或 deadline 到期后才返回；socket timeout 与 worker post-call probe 只能使它最终拒绝，不能声称即时打断。未来若引入可挂起 transport，必须另定中断、资源回收与 D3 竞态语义。

---

## 3. Rejected alternatives

1. **继续返回只有 label 的 `ByteStream`**：source parser 没有输入，所谓“HTTP 成功”没有 raw bytes 证据。
2. **把 `ByteStream` 直接改成复杂 reader**：当前没有消费方、runtime 也没有对应 reader driver；会扩大冻结边界并把未定义的关闭/取消语义藏进类型。
3. **只给 `SimHttp` 加一个 `payload` 字段**：生产与仿真会出现两套事实，违反 ADR-022。
4. **先完整下载再检查 cap**：攻击者可用超大响应把内存打满；声明长度要在 body 前拒，未声明 body 只允许 cap+证明超限所需的最小读取。
5. **把 caller deadline 当作固定 10 秒 timeout**：相对 deadline 与 adapter timeout 不是同一个时钟或同一个策略，名字相同不代表事实相同。

---

## 4. Consequences and recorded gaps

- `FetchResp.body.bytes` 让下一阶段可以把真实响应送入 parser；`ByteStream` 的 Fs 语义不变。
- 两个 Http backend 的共享裁判现在可验证“返回了什么”，不只验证“返回了一个 label”。
- 已完成：`SourceRef.locator`/`source_ref_at` 数据模型、显式 endpoint registry、`SourceUpdate` worker 的 Http→parse→RawSource CAS 接线，以及 durable source index。source-index v1 以 `record:v1` 的白名单 key/value envelope 保存 endpoint kind/label/locator/route/body cap/media type/strict policy、ETag/Last-Modified、raw object digest/content anchor/size/stored-at、normalized/provenance/diagnostics opaque payload 及各自 SHA-256 anchor；`FsStore` 以 D3 原子替换记录，`InMemoryStorage` 提供同一语义。
- worker 构造时枚举并 typed decode source indexes，读取并校验 raw CAS metadata 与 bytes，再恢复 endpoint、conditional validators、normalized/provenance/diagnostics；EngineHandle 安装 worker 时把已验证的 normalized cache 也恢复到 apply planning。200 先写 CAS 再写 source index 后更新过程镜像；304 只有在 raw body 可读且两个内容锚点一致时才复用。locator 变化同时删除 process-local cache 与 durable source index，旧 raw object 留给 GC。
- 已完成当前 bounded source 阶段：带 caller clock 的 HTTP→parser→CAS→D3 phase-boundary deadline/cancellation；source inspection API 从 durable record 投影 endpoint、validators、raw anchors、normalized counts、diagnostics、provenance，并在 daemon 统一 redaction。真实 fixture 的 engine durable 与 daemon facade/query tests 覆盖重启、304、缺失/损坏 raw object、取消和 deadline 边界。
- 仍未完成的边界不是上述 projection 的缺失：`StdHttp` 单个 OS blocking syscall 不能被 `CancelToken` 从中途强行打断；如果未来要支持真正可挂起/可中断的生产 transport，必须另定 runtime、资源回收和 D3 竞态。当前 source parser/record 有明确上限，只有放宽该上限时才需要另加 pagination/stream read contract。
- 任何 source ingest 实现必须使用明确 locator，不能把 `SourceRef.label` 猜成 URL；必须经 Http port 取回，再用 `CasWriteIntent::with_payload` 写入 ObjectStore。
