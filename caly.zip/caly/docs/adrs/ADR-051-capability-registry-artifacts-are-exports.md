# ADR-051: Capability Registry JSON 工件是导出物，不是运行时输入物

- Status: Accepted
- Date: 2026-08-30
- Decision-Makers: Caly Architecture
- Related-RFCs: RFC-0004, RFC-0008
- Supersedes: None（本 ADR 是对 `ADR-024` 的**后续澄清与补决策**：ADR-024 的「单一事实来源」与
  「绑定证据」两条决定不变，本 ADR 决定工件的**方向**——导出物而非输入物，并把
  `docs/status/IMPLEMENTATION_STATUS.md §8.3` 的悬置决策收口；ADR-024 正文作为历史不改写，以本 ADR 为准。）

---

## 1. Context

`docs/status/IMPLEMENTATION_STATUS.md §8.3` 一直登记着一条悬置决策：

> 决策：registry 从文件加载（含失败/离线语义），或明确「文件仅由代码生成」；
> 若保持后者，则把 `REGISTRY_PATH` 改为「导出物」而非「输入物」，并更新 `ADR-024` 措辞。

而代码与测试的事实早已明确回答了它：

- `crates/caly-cap/src/json.rs` 的模块注释说：`.json` 工件曾是「文档假装成数据，会静默漂移」，
  修复方式是用 `parse(file) == default_registry_document()` 把漂移变成构建失败——即**文件由
  代码生成、由门禁校验**，不是运行时读取的输入；`registry_drift.rs` 的再生成入口是
  `CALY_REGENERATE_CAPABILITY_ARTIFACTS=1 cargo test -p caly-cap`（测试时重写，非运行时读）。
- `REGISTRY_PATH` / `COVERAGE_MATRIX_PATH` 在**全部生产 `crates/*/src/**` 中零引用**：
  只出现在 `caly-cap/src/lib.rs`（常量定义）与 `caly-cap/src/json.rs`（模块注释提及）。
  运行时（daemon / CLI / engine）判断能力用的是 `default_registry_document()` /
  `merged_registry_document()` / `evaluate_required_capabilities()`——编译期 Rust 文档值。
- 与 `§8.4`「capability 文件加载失败语义」对应：**没有生产加载器，就没有「文件加载失败」
  这一运行时面**；`registry_from_json`/`coverage_matrix_from_json` 的解析失败语义
  （畸形/未知枚举/缺字段按名拒绝）已被 `registry_drift.rs` 钉住，但那只服务于生成器路径。

于是 `§6.2` 把「capability 执行仍读代码内建 registry/coverage default，而不是从 JSON 工件」
当作**未完成项**记账——这是文档与事实的漂移：读代码内建 **是** ADR-024 单一事实源的
正确形态，JSON 工件本就是导出物。本次决策就是把这个漂移收口。

## 2. Decision

1. **单一事实来源是 `caly_cap` 的编译期 Rust 文档**（`default_registry_document` /
   `merged_registry_document` / `canonical_registry_document`）；「查询 Registry」（`ADR-024`
   §2.1）指查询这个文档值，**不是**从 JSON 文件读取。
2. `capability-registry.json` 与 `coverage-matrix.json`（位于 `crates/caly-cap/`）是**导出物**：
   由生成器在 `CALY_REGENERATE_CAPABILITY_ARTIFACTS=1` 时重写，`registry_drift.rs` 门禁
   保证它们与 Rust 文档逐键一致；不一致=构建失败（导出物漂移即红）。
3. **生产 `src/` 代码不得从工件读取**：不得对 `REGISTRY_PATH`/`COVERAGE_MATRIX_PATH`
   （或其字面文件名）出现 `read` / `File::open` / `include_str!` / `include_bytes!`
   形式的取数调用，由 `caly-arch-test` 的
   `the_registry_artifacts_are_exports_not_runtime_inputs` 每条 `cargo test` 强制执行。
4. **「文件加载失败 / 离线语义」没有运行时面**：工件只被两处消费——生成器写、门禁读，
   两者都是测试/工具路径；读取失败 = 测试或生成器错误，不是产品行为。任何未来
   「运行时从文件加载 registry」的需求必须**另立 ADR**，说明：为什么运行时需要这个
   可变输入、确定性如何保持（仓库教义：`Args`/文件系统不是一个时钟注入点）、以及
   缺失/畸形/版本不符时的失败语义——并同步修订第 3 条的 arch-test 检查。
5. 工件在 `crates/caly-cap/` 下（随 crate 走）是它们的正确位置：`REGISTRY_PATH` 是
   **相对 crate 根的导出物路径**，不是 workspace 根路径；任何引用方若以 workspace 根
   相对解析，就是一次方向误读（§8.3 说的「改为导出物而非输入物」）。

## 3. Alternatives Considered

### 方案 A：运行时从文件加载 registry（含失败/离线语义）

- 优点：文件可被外部工具改写后热更新 registry。
- 缺点：把「能力事实」从编译期变成运行时可变输入——与仓库的确定性教义相悖
  （能力判断影响规划/校验/doctor/gate，一个会随文件系统变动的输入让同一份档案
  在不同机器上给出不同答案）；而且**没有消费者**（daemon/CLI 零引用），凭空造契约
  即是「为不存在的调用方发明语义」。失败语义（缺失/畸形/离线）无处落脚。
- 不采纳：无消费者；确定性不可保持；§8.3 的「失败/离线语义」是伪装成需求的实现面。
  若未来出现消费者，按 §2.4 另立 ADR。

### 方案 B：维持 §8.3 悬置，不加决策

- 缺点：`§6.2` 继续把「读代码内建」当缺陷记账，文档与事实持续漂移；
  `REGISTRY_PATH` 的「输入物」暗示继续误导读者。
- 不采纳：悬置的成本是每轮重新核对（正是 §2.2 记过的那类）。

### 方案 C：删除 JSON 工件，只留 Rust 文档

- 优点：消除「双份」。
- 缺点：coverage matrix 与能力注册表是人类可读的导出物（CLI/审计面），
  删除后失去可读性；且 `registry_drift.rs` 已把「双份」从隐患变成裁判
  （两份一致才是证据）——删除是放弃已有裁判。
- 不采纳：导出物价值仍在，drift 门禁已让双份健康。

## 4. Consequences

### Positive

- `IMPLEMENTATION_STATUS §8.3` 决策收口；`§6.2` / `§8.4` 的措辞与事实对齐；
- 「工件方向」成为可强制条件（arch-test 裁判），任何「运行时读取」的红线一旦被跨
  即红，且红线由 ADR 而非个人偏好背书；
- `REGISTRY_PATH` 常量注释（`lib.rs`）与 json.rs 模块注释补上导出物语义，阅读者不再
  被「路径常量=输入」的直觉误导。

### Negative / Trade-offs

- 想从文件加载的人多一道 ADR 手续（这是本决策的本意：除非真有必要，否则不引入）；
- arch-test 检查以行内 token+取数调用判定，若未来生成器/门禁逻辑改写导致误报，
  修订检查需同时更新 ADR-051 的 §2.3 表述（文档与门禁保持同一事实）。

### Follow-up Work

- 无（本 ADR 落地的 arch-test 裁判与文档同步即完成项）。

## 5. Compatibility and Migration

- 公共 API 不变（`REGISTRY_PATH` 仍是 `&str` 常量，值不变）；
- 既有 `registry_drift.rs` 门禁不变；
- `ADR-024` 的「单一事实来源」「绑定证据」「SupportedExact⇒证据」全部不变；
  本 ADR 只补「工件方向」并澄清「查询」的词义。

## 6. Notes

本 ADR 支撑：

- `docs/status/IMPLEMENTATION_STATUS.md §8.3`（决策收口）与 `§6.2`/`§8.4`（措辞对齐）；
- `tests/registry_drift.rs` 的「文件==代码文档」门禁的语义定位（导出物一致性，而非
  「运行时数据源一致性」）。

一句话总结：

> 能力事实在代码里，JSON 是它的导出照片——运行时谁也别去读照片，要读说明书。
