# ADR-041: 存储记录文件名的单射转义（两个名字不许共用一个文件）

- Status: Accepted（第三十九轮落地：`sanitize` 压平 → `escape_component` 百分转义，六处调用点
  统一；boot 校验"文件名必须是它的 digest 会占据的名字"，旧式/伪造命名拒绝启动；三处裁判、
  四条证伪全咬；夹具迁移八处——本仓无可执行程序与外部用户，旧树不存在，迁移零成本）
- Date: 2026-08-29
- Decision-Makers: Caly 接续开发方（维护者已把此类裁决交由此方自行决定，见 `ADR-035 §6bis`）
- Related-ADR: ADR-035（§6bis boot 自洽校验教义、§2.5 路径基址）、ADR-038（GC 的 anchor 准入先例）
- Supersedes: `FsStore` 内部 `sanitize` 压平命名（`RFC-0007 §6.4` 冻结的是
  `meta/objects/<digest>.obj` 的**形状**；digest 如何渲染成一个文件名是实现细节，本 ADR 记录
  对它的修订——与 `ADR-039` 对冻结签名带 `ctx` 的处置方式相同）

---

## 1. Context

第三十八轮测量 anchor 读侧时登记（`ROADMAP §1bis.3`）：对象 digest 是**调用方自铸名**
（`obj:orphan`、`mihomo:aa11` 皆合法），落盘时 `sanitize` 把 `/ \ : 空格 .` 全部压成 `_`——
**非单射**。后果四个，全部可复现：

1. **静默互覆**：`obj:orphan` 与 `obj/orphan` 落同一个 `meta/objects/obj_orphan.obj`，第二个
   put 覆盖第一个的记录；
2. **别名命中**：`get("obj_orphan")` 经压平路径读到 `obj:orphan` 的记录——返回一条 digest 字段
   与所问名字**不符**的记录；`delete("obj_orphan")` 删掉 `obj:orphan` 的文件；
3. **两后端分歧**：fs 经压平路径别名命中，in-memory 按精确键未命中——同一个问题两种答案；
4. **重启不定**：互覆后运行期内存 map 仍有两个键，重启后目录里只剩一个文件——同一问题在
   重启前后答案不同。

`records/{kind}/{id}.rec` 与 `materialized/{digest}.ok` 走同一 `sanitize`（id 同为自铸
String，实测 `rev:01`、`snapshot:ghost` 带冒号），只是尚无两 id 压平相撞的现场——同病潜伏。

## 2. Decision

**记录文件名 = 名字的单射转义（百分号转义），且 boot 校验"文件名必须是它的记录里的名字会
占据的名字"。**

- `escape_component`：`%`→`%25` 先行，`/ \ : 空格 .`→`%2F %5C %3A %20 %2E`，其余原样。
  单射性由 `%` 先转保证——字面 `probe%2Fpath` 永远不可能伪装成转义后的 `probe/path`。
- 六处调用点统一（对象记录四处的 `meta/objects/<esc>.obj`、`records/{kind}/<esc>.rec`、
  `materialized/<esc>.ok`）：读写同门，别名不再可达。
- boot（`load()`）：对象记录的文件名 stem 必须 == `escape_component(记录内 digest)`，否则报
  `object record {file} is not the name its digest ({digest}) would occupy -- legacy or forged
  naming` 并拒绝启动——legacy 压平树与伪造命名在同一道门被点名。其余记录族本轮不加大名单
  校验（其 id 由引擎侧自铸、暴露面小），转义已统一、后续需要再加。

## 3. 被否决的备选

- **put 时拒绝"压平相撞"**：需要在每次 put 枚举既有名字维护反向映射，且**修不了别名读**——
  `get("obj_orphan")` 仍会命中；治了互覆不治别名，成本更高、覆盖更小。
- **入口拒绝带特殊字符的 digest**：对象名惯用 `mihomo:*`、`obj:*` 前缀（跨 engine/daemon 十余
  处夹具与语义），入口收窄是比落盘命名更大的契约变更，方向就错。
- **维持现状**：四个后果（互覆/别名/两后端分歧/重启不定）每一个都违反"两后端同门同词"与
  "重启后答案不变"两条既有契约教义。

## 4. 落地记录（第三十九轮）

- `crates/caly-storage/src/fs_store.rs`：`escape_component`（pub——测试需要计算记录文件名，
  命名规则只许有一份真源）替换 `sanitize` 六处；boot 名↔记录校验入 `load()`，在 anchor
  准入（第三十八轮）之前。
- 裁判三处：`object_contract.rs`（**两后端同问**）别名 `get`→`None`、别名 `delete`→`false`、
  幸存者完好；同文件 durable 侧四个名字（`obj:orphan`/`obj_orphan`/`probe%2Fpath`/
  `probe/path`，两对单射边界）put 后**重启**仍四条俱全；`fs_store_on_real_disk.rs` 旧式名/
  伪造名（记录放到压平时代的文件名下）boot 点名拒绝。契约 559 → **562**。
- 证伪：`scripts/falsify_round39.py` 4/4 全咬（压平回归 / boot 校验解除 / 单字符半吊子转义——
  `:` 仍压 `_`，单射性悄悄丢失 / `%` 转义缺席——字面名可伪装转义名）。
- 夹具迁移八处：三份**各自手写的压平规则副本**（gc_plan.rs 两处——其中一份还漏了 `\`、
  durable_centerline.rs 一处）改为调用真源 `escape_component`；五处手写记录路径与一处断言
  字面量随新命名更新。旧命名树：本仓可执行程序为 0、无外部用户，boot 会以
  `legacy or forged naming` 点名拒绝——诚实冷启动，不留静默迁移。

## 5. Consequences

- "名字"成为 store 的可判性质：两个名字共用一个文件、一条记录顶着别人的名字，都会被裁判或
  boot 咬住，而不是靠 review。
- 命名规则从此只有一份真源（`escape_component` 公开）；测试再手写一份转义副本就是违规。
- 若未来出现真实旧树迁移需求（外部用户出现），本 ADR 的 boot 拒词就是迁移检测器——先点名、
  再决定，不静默。
