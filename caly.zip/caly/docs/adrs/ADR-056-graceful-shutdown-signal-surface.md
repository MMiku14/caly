# ADR-056: `calyd` 的信号面（SIGTERM/SIGINT 优雅关停）——最小 `sigwait` 端口生长，bin 组合根持有，不引入信号 crate

- Status: Accepted（第一百零二轮落地：bin 内 cfg(unix) 信号等待模块 + 信号线程优雅关停 + 集成/结构裁判；不引入 libc/信号 crate）
- Date: 2026-08-31
- Decision-Makers: Caly 接续开发方（维护者已把此类裁决交由此方自行决定，见 `ADR-035 §6bis`）
- Related-ADR: ADR-043（Proc 最小监督面，§2.5/§5 显式推迟 TERM 面并预告「等第一个真正需要优雅关停的调用方，届时伴 ADR」——本 ADR 即那次到来）、ADR-011（单一 IO 网关/组合根持有宿主适配）、ADR-050（calyd 真实运行时组合根）、ADR-055（外部 init 监督 calyd 的两层边界）
- Related-RFC: RFC-0001（架构不变量：恢复优先、失败 Apply 不留坏副作用）、RFC-0005 §11（Core Supervisor）/§12（崩溃恢复）

---

## 1. Context

`ADR-043` 落地 `Proc::try_wait/stop` 时明确：std 的 `Child::kill` 只有 SIGKILL，**没有 TERM**；
它把「优雅关停（让核心冲刷状态再走）」的 TERM 面显式推迟，并在 §5 写下：

> TERM/信号面：等第一个真正需要优雅关停语义的调用方（届时伴 ADR；`/bin/kill` 路线已在此存档否决理由）。

这个调用方在第一百轮出现了：systemd（ADR-055）托管 calyd，`systemctl stop/restart` 会向
calyd 发 **SIGTERM**。在此之前 calyd 不安装任何信号处理器，SIGTERM 走默认动作（立即终止），
于是：

- 正在运行的代理 Core 子进程不被优雅 `stop()`（`StdEffectRuntime::shutdown(grace_ms)`
  早已存在并被每个 spawn 真核的裁判调用，但 calyd 进程关停路径从不调它）；
- 系统代理/DNS/路由不在 daemon 退出前收敛，只能靠**下一次启动的崩溃恢复**（RFC-0005 §12）
  兜底——语义正确，但每次 `systemctl stop` 都走一遍「硬杀 → 孤儿 Core → 重启恢复」。

目标：calyd 收到 SIGTERM/SIGINT 时，在退出前优雅 stop Core（`shutdown(grace)`），然后以
**退出码 0 干净退出**；没有 Core 时（simulated）也干净退出。

约束：

- 全仓无 libc / signal-hook 等外部信号 crate；外部 crate 须先有 ADR（依赖纪律）。
- `caly-io-std` 是 `#![forbid(unsafe_code)]`，`caly-daemon` 的 **lib** 也是
  `forbid(unsafe_code)`。信号等待在 Rust std 中没有安全 API，必须 FFI。
- 引擎/门面（engine/facade）从不请求「等待一个进程信号」——这是顶层进程生命周期关切，
  不是可移植 Port 语义（与 `Proc::spawn/stop` 管理**子进程**不同）。

## 2. Decision

### 2.1 信号等待是 calyd **bin 组合根**的一个 cfg(unix) 模块，不进 caly-io Port

新增 `crates/caly-daemon/src/bin/support/signal.rs`（`src/bin/` 下每个 `.rs` 都会被 cargo 当作独立 binary，故模块放在 `support/` 子目录，由 `calyd.rs` 以 `#[path = "support/signal.rs"] mod signal;` 引入；仅 unix 编译 FFI waiter），暴露两个**安全**函数：

- `block_term_signals()`：在**主线程、任何其他线程 spawn 之前**调用，用 `pthread_sigmask`
  阻塞 SIGTERM/SIGINT。新线程继承掩码，因此这两个信号不会被默认动作杀死任何线程。
- `spawn_term_waiter(on_term: impl FnOnce() + Send + 'static)`：spawn 一个专用线程，
  在该线程上 `sigwait`（阻塞等待被阻塞的 SIGTERM/SIGINT）；等到任一信号即调用 `on_term`
  再 `std::process::exit(0)`。

unsafe 被**局部封装**在这个模块内（FFI 绑定 + sigset 操作），对外只暴露安全函数；bin 是
独立编译单元，lib 的 `forbid(unsafe_code)` 不作用于它。这不违反 ADR-011：信号等待不构成
引擎使用的 Port，它和「绑监听端口、读命令行」一样属于 calyd 组合根的宿主进程控制。

### 2.2 不引入 libc / 信号 crate；手写最小 FFI

只 `extern "C"` 三个符号：`pthread_sigmask`、`sigwait`（以及常量 `SIGTERM=15`、
`SIGINT=2`）。sigset 用一个大小由 libc ABI 决定、零初始化的 `#[repr(C)]` 结构，仅在这个
模块内通过 FFI 操作其位（不读不写字段，平台布局正确性交给 libc）。目标平台是
Linux x86_64（项目实际部署目标，ADR-023）；非 unix 平台该模块不编译、信号面不提供
（Windows SCM 是另一套关停语义，见 ADR-055 follow-up）。

### 2.3 优雅关停动作复用既有 `StdEffectRuntime::shutdown`

信号线程收到 TERM 后：调用 real 运行时的 `shutdown(GRACE_MS)`（它已做：取走活核心句柄、
撤路由、`proc.stop(grace)` 宽限自然退出/期满击杀、reap——即 ADR-047/043 的既有语义），
然后 `process::exit(0)`。simulated 模式没有 real 运行时，`shutdown` 这一步是 no-op，仍
`exit(0)`。固定宽限 `SHUTDOWN_GRACE_MS = 10_000`（与 unit 的 `TimeoutStopSec=15s` 对齐：
10s 停核 + 余量 < 15s）。

组合根让 `bootstrap_app` 在构造 real `StdEffectRuntime` 时把一个可调用其 `shutdown` 的
句柄交回 main（simulated 为 None）；信号线程持有它。

## 3. Alternatives Considered

- **引入 libc / signal-hook crate**：优点是不用手写 FFI、sigset 布局由库保证。
  缺点：违反「外部 crate 须先有 ADR、依赖边只能在 ALLOWED_* 表内」的依赖纪律；信号等待
  只需两个符号，为此拉一个传递依赖面不值得。不采纳（手写 FFI 的 unsafe 被局部封装、范围
  极小，且只在 cfg(unix)）。
- **在 caly-io-std 里加信号 Port**：优点是和 StdProc/StdClock 同处。缺点：caly-io-std
  `forbid(unsafe_code)`，要为信号专门放开 crate 级 forbid（等于为一个消费者降低整个生产
  IO crate 的 unsafe 门槛）；且引擎/门面不消费「等信号」，它不是 Port 语义。不采纳。
- **自管道（self-pipe）/ signal handler 写非原子 + 非阻塞 accept**：优点是纯 std（非阻塞
  listener + `try_clone`+select）。缺点：信号处理器（async-signal context）里能做的事极
  少，自管道 + 改 accept 为非阻塞 + 事件循环的改动面大且易错；`sigwait` 专用线程是
  POSIX 推荐的「在非处理器上下文同步等信号」形态，处理器为默认（不安装 handler），无需
  async-signal-safe 约束。选 sigwait。
- **维持现状（硬杀 + 重启崩溃恢复）**：ADR-055 后每次 `systemctl stop/restart` 都制造一个
  孤儿 Core 和一轮恢复，浪费且把优雅关停这一正常运维路径压到崩溃恢复上。不采纳。

## 4. Consequences

### Positive

- `systemctl stop/restart calyd` 走优雅路径：Core 被 `stop(grace)` 宽限停掉、路由撤销、
  daemon 以退出码 0 干净退出，不再每次制造孤儿 Core。
- 信号面只在 cfg(unix) 的组合根，unsafe 局部化、无新依赖；lib 与 caly-io-std 的
  `forbid(unsafe_code)` 不动。
- 行为在真实二进制上由集成裁判钉死（发真 SIGTERM，断言退出码 0），不是仅内部结构。

### Negative / Trade-offs

- 手写 FFI 引入了一小块 unsafe（`extern "C"` + sigset）。已用「安全函数封装 + 仅 cfg(unix)
  + 不读写字段只整体传指针」把风险压到最小；真实二进制集成测试覆盖其外部可观察行为。
- Windows/macOS 之外的平台未覆盖（macOS 是 unix，sigwait 同样可用；Windows SCM 关停
  另议，属 ADR-055 follow-up）。
- 信号线程直接 `process::exit(0)`：不 join accept/worker 线程（进程退出即回收），与
  「硬杀」相比我们已经做了有价值的优雅动作（停核撤路由）；连接的干净排空（drain in-flight
  请求）不在本轮，属后续。

### Follow-up Work

- in-flight 请求/流连接的优雅排空（stop accepting → 服务完当前会话 → 退）。
- Windows SCM 关停面。
- 若未来信号面需要被引擎/门面逻辑复用（而非仅顶层进程控制），再评估提升为 caly-io Port。

## 5. Compatibility and Migration

- **不破坏兼容、不改 wire、不改公开 Port 契约**：纯 calyd bin 行为增强。默认仍 simulated；
  对现有测试（前台 spawn/`kill`+wait 清理）无回归——daemon 现在被 SIGTERM 时优雅 exit 0
  而非死于信号 15（这是改进；测试 harness 的 Drop 仍能干净 wait）。
- 无版本 bump；ADR-043 §2.5 的「TERM 显式不做」由本 ADR 在 calyd 进程关停这一具体消费方上
  收束（`Proc::stop` 对子进程仍只用 SIGKILL 期满击杀，那条边界不变）。

## 6. Notes

- 测试侧发 SIGTERM 用 `/bin/kill`（或 std `Child::kill` 之外的 kill(2)）是**测试基础设施**，
  与 ADR-043 §2.5 否决的「**生产端口**经 `/bin/kill` 触发 TERM」不是一回事——生产路径用
  `sigwait` 接收信号、用既有 `Proc::stop` 停子进程，不在生产代码 spawn kill。
- 裁判：`calyd_wire` 集成测试（spawn 真二进制 → SIGTERM → `wait`，断言 `status.code()==Some(0)`
  而非 `signal()==Some(15)`）+ 结构门禁（bin 在 cfg(unix) 安装 `pthread_sigmask` 阻塞并
  `sigwait`、信号路径调用 `shutdown(`）；证伪 M1 不阻塞信号（集成测试见 signal 15 红）、
  M2 不装等待线程（同上）、M3 收到信号不调 shutdown（结构门禁红）。
