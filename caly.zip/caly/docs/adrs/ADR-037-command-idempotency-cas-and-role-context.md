# ADR-037: Command 的幂等、CAS 与角色上下文由谁提供

- Status: Accepted（2026-08-28 定稿并落地；定稿过程与三处偏离见 §2bis）
- Date: 2026-08-27
- Decision-Makers: Caly 接续开发方
- Related-RFCs: RFC-0002, RFC-0005, RFC-0010
- Supersedes: None

> 本 ADR 与 `ADR-035`（`Fs` 目录列举与路径基准）、`ADR-036`（有界端口执行器与 `Ctx` 限额执行）同批提出，
> 把第九轮实测到的三个"元数据声明了、语义没人实现"的点写成可决策的问题。留档见
> `docs/ONBOARDING_NOTES.md §4.37–§4.41`。
>
> **状态已改为 Accepted**：维护者授权接续开发方自行定稿（2026-08-28），§2 的四条语义决策按原文采纳，
> §2.1 的 `AuthContext` 与 §2.3 的一处"更宽松变体"被否决 —— 理由与证据在 §2bis。实现与判定见
> `docs/DEVELOPMENT_LOG_2026-08-27.md` 的 `AE` 节。

---

## 1. Context

`RFC-0002` 把三件事写成了对外契约的一部分：

```text
§5.2   Command SHOULD 支持 idempotency_key
§6.2   expected_revision 用于比较并交换（CAS）语义
§6     所有调用 MUST 透传统一上下文：trace_id / actor / deadline / cancel_token /
       expected_revision / io_budget / role 或 auth context
§7.2   每个 Operation MUST 具备静态元数据，其中包含 idempotency: Required|Optional|NotApplicable
§8.3   高风险 Command MUST 支持幂等去重；重复命令 MUST 返回原 JobId 或等价 outcome，
       MUST NOT 再次触发第二次部署
```

第九轮把这些说法逐条对到代码上，结果是**三条实现不一致、两条无人执行**：

1. `Idempotency::Required` 被标在 4 个操作上（`system.shutdown`、`profile.apply`、
   `profile.rollback`、`network.repair`），但生产代码里读它的地方是 0（`grep` 只命中一处断言元数据
   自身的测试）。缺 key 不会失败，有 key 也不会有人告诉你"这个命令要求 key"。
2. `expected_revision` 从 `Ctx` 传到 `RequestEnvelope` 再传到 `Command.context`，**没有任何人读**。
   而远端 façade 当时更直接：它把 `None` 写死在请求里，所以远端连"能不能读到"都不成立。
   （CAS 检查本轮已实现，见 §4 的"已落地部分"。）
3. `Ctx` 里没有 `role` / `auth context` 的位置，于是两条路径各自决定角色：
   `LocalFacade` 对每个调用硬编码 `Role::Admin`，`RemoteFacade` 用
   `ClientSessionConfig::default().role`（默认同样是 `Admin`）。结果是 `required_role` 检查
   在两条路径上都永不失败 —— 它现在是文档性的。

同一个根因：`Ctx` 是**跨层共享**的对象（`caly-io` 的 `IoContext` 就是它的别名），所以任何"看起来只属于
门面"的字段加进去，都会同时变成端口层的一部分。这正是 `ADR-021 §6` 写下
「冻结 `Ctx` 字段与派生规则」却没有冻结**谁能读它**的原因。

---

## 2. Decision（已采纳；§2.1 的新类型部分被 §2bis 否决，其余按此落地）

采纳 **方案 B** 的分工：把「调用者身份/权限」与「调用上下文」分开，`Ctx` 保持现状。

1. ~~**`RequestEnvelope` 增补 `auth: AuthContext`**（新类型，落在 `caly-api`），承载 `role` 与将来的
   principal/session 标识~~ —— **定稿时否决**：envelope 已经有 `role: Role`，再加一个带 role 的结构体就是
   同一件事的两个出处。将来真要 principal 时以**替换**的方式引入，见 §2bis 第一行。本条剩下的语义
   （"角色只出现在跨门面的信封上，端口层看不到角色"）已经由现有的 `RequestEnvelope.role` 满足。
2. **`LocalFacade` 不再自赋 `Admin`**：本地入口的 role 由**组装者**给出（`LocalFacade::with_role`
   或构造参数），默认 `Operator`；`--no-daemon` 与嵌入式调用要显式声明更高角色。
   `RemoteFacade` 继续从握手取。两条路径由此共享 §4.1 要求的「权限检查语义」，
   而且 `required_role` 第一次真正有意义。
3. **`Idempotency::Required` 的解释冻结为**：*daemon* 必须维持 `(actor, key) → job` 窗口
   （已实现），且**门面在提交 `Required` 命令时若 `ctx` 无 key 必须拒绝**，错误用
   `CONFIG_INVALID`（`docs/ERRORS.md §5.1`：调用方给的输入不完整属于配置/用法问题），
   remediation 里给出「为这次写操作生成一个 key（例如本次 CLI 调用的 id），重试时复用同一个」。
4. **`expected_revision` 的语义**：只作用于 `Command`，不作用于 `Query`（查询快照式，比较 revision
   没有对象可撤销）。CAS 检查排在幂等查找**之后**：带 key 的重试必然携带第一次读到的 revision，
   先查 CAS 会把每一次重试变成冲突，幂等窗口反而成为失败来源。
5. **窗口淘汰**：`IdempotencyTable` 当时无界增长且永不淘汰；`§8.3` 说的是「最近窗口」。
   定稿策略：超过上限时按 job id 淘汰最旧的**已完成**条目，运行中的永不淘汰。
   **偏离**：原文建议窗口长度由注入时钟提供，定稿改为**只按条数**（`max_finished = 512`），三条理由：
   引擎在 `ADR-036` 落地前没有可用时钟，接一个就会破坏 `ADR-022` 的确定性复现；条数上限已经足够表达
   "最近"；且 512 > 队列上限 256，因此**窗口永远不会成为提交被拒的原因**（容量压力是队列的职责），
   这条不变式由 `idempotency::tests` 里的 `the_window_is_never_the_reason_a_submission_fails` 钉住。
   `evictions()` 与 `doctor` / bundle 的 `finished_window=` 数字负责把"窗口是有限"这件事说给调用者听。

---

## 2bis. 定稿结果、三处偏离，以及一条被自己的门禁否掉的方案

| §2 的条目 | 定稿 | 实际落地 |
|---|---|---|
| 2.1 `RequestEnvelope.auth: AuthContext` | **不采纳**（改为沿用已有的 `role` 字段） | `RequestEnvelope` 已经有 `role: Role`，再加一个带 role 的 `AuthContext` 就是同一件事的两个出处 —— 本仓库反复在修的就是这一类"两个真相"。等真需要 principal / session 标识时，再用 `AuthContext` **替换** `role`，而不是与它并存；在那之前，任何"顺手加个 auth 结构体"的 PR 都应先看这一条 |
| 2.2 本地入口不再自赋 `Admin` | **采纳**，但落点改了 | 角色放在 `DaemonApp`（`local_role`，默认 `Operator`）而不是 `LocalFacade::with_role`：本地 façade 是 11 个 facet 结构体的薄壳，每个都自己重建 envelope，把角色塞进去要么逐个改、要么各写各的默认值 —— 后者正是本轮要修的病。放在组装根上，`Arc<DaemonApp>` 的克隆共享同一份声明，两个 façade 不可能对同一个 daemon 声称不同身份 |
| 2.3 `Required` 缺 key → 拒绝 | **采纳**（照原文，见下方"被否掉的变体"） | `resolve_idempotency_key`；`CONFIG_INVALID` + `remediation`；同时把空白 key 对**任何**命令都拒（它就是一个共享桶） |
| 2.4 CAS 排在幂等查找之后 | **采纳**（第九轮已落地） | `submit_checked` 的顺序不变；本轮补了三道门禁的顺序：角色 → 请求形状 → 状态（CAS/生命周期），因为调用者只能处理自己控制得了的那一件事 |
| 2.5 窗口淘汰 | **采纳，形状收紧** | 只淘汰**已完成**条目，按 job id 从旧到新；运行中的永不淘汰。窗口上限（512）**大于**队列上限（256），因此不会出现"窗口满了所以拒绝提交"这种第二过载类 —— 那需要一个本 ADR 没打算引入的新 `OverloadClass` |

**被否掉的变体（值得留在这里，因为它看起来更好）**：定稿前我先把 §2.3 写成"缺 key 时由 daemon 从
`request_id` 派生一个"，理由是别把 CLI 的一次性调用变成非法输入。写完之后 `run_write_parity` 立刻变红：
request id 是**每条访问路径各自计数**的（本地是 daemon 的计数器，远端是 client session 的），而去重窗口是
**按 actor 全局**的，于是本地 `fresh-a` 与远端 `fresh-a` 都派生出 `req:1`，远端那次静默复用了本地的 job。
派生 key 的两个可能形状因此都不成立：跨路径碰撞（不安全），或者每次调用唯一（等价于没有 key，`Required`
又变回装饰）。见 `docs/ONBOARDING_NOTES.md §4.62`。

**一处新增的硬约束**：`RequestId` 必须每调用一个新值。它原先在本地路径恒为 `0`，而 `Command.id` 由它派生 ——
于是所有本地命令的 id 都是 `req-0`，事件日志与审计无法区分任意两条本地命令（`§4.61`）。这一条与幂等无关，
但它是"元数据要有人读"的同一件事：`request_id` 也是 `RFC-0002 §6` 要求贯穿的字段。

## 3. Alternatives Considered

### 方案 A：把 `role` 与 `idempotency_key` 都放进 `Ctx`

- 优点：一个对象解决全部；两个 façade 只需读 `ctx`。
- 缺点：`Ctx` 是 `IoContext` 的别名，端口与 effect 执行器会看见 CLI 的角色；`ADR-013`/`ADR-021`
  把"端口只拿它需要的东西"当成设计前提。而且一旦放进去，端口层就有了"按角色区别对待"的诱惑。
- 不采纳原因：把边界概念沉到最底层，换来的是以后每个 port 都要解释为什么不看 role。

### 方案 B：`Ctx` 不动，`RequestEnvelope` 带 `auth`（**已采纳**，其中 `auth` 字段本身被 §2bis 否决）

- 优点：角色只出现在跨门面的信封上，与 `§7` 的统一 envelope 一致；`required_role` 与
  `Idempotency::Required` 都在同一个地方被检查（`request_map`），Local/Remote 天然共享。
- 代价：`AuthContext` 是新类型；`caly-daemon` 的两个 façade 构造点要接一个默认值。

### 方案 C：什么都不加，把 `Idempotency::Required` 降级为 `Optional`，删掉 `required_role` 检查

- 优点：代码与文档重新一致，且不需要新类型。
- 缺点：等于承认 v1 没有角色分层，与 `RFC-0010 §13`（`Viewer/Operator/Admin/PrivilegedBroker` 分层
  必须保持）冲突；提权动作的边界将来还要再加回来。
- 不采纳原因：为了消除"未实现"的红灯而删除需求，是本仓库反复反对的那类做法。

---

## 4. Consequences

### 已落地部分（本轮不需要等待决策）

- `Ctx.idempotency_key`：`ADR-021 §5` 明确「未来若扩展 `Ctx` 字段，应优先保持向后兼容的默认语义」，
  `None` 默认即此。两个 façade 读同一字段，`§4.1` 的去重语义第一次可比对（`run_write_parity` 的
  四条 case 里就有两条专测这件事）。
- `deadline_ms` / `expected_revision` / `trace_id`：远端不再改写，全部透传（§1 的第 2、3 条中除
  role 之外的部分）。
- `expected_revision` 的 CAS 检查与 `StaleRevision → CONFLICT/Config` 映射。

### Positive

- `required_role`、`Idempotency::Required`、`expected_revision` 三者从"文档里的名词"变成有执行点、
  有测试、有错误码的语义。
- 角色与幂等键进入 envelope 后，`ADR-026` 的"facets 映射到统一 envelope"才有可比较的对象：
  `run_envelope_parity` 已经能比出 trace 被改写这类差异（本轮就是靠它抓到 §6.3 违规的）。

### Negative / Trade-offs

- 本地调用一旦不再默认 `Admin`，`caly-cli` 的若干演示路径需要显式声明角色（改动面小但会红）。
- 淘汰策略引入"窗口外重复 key 会再执行一次"的新语义：必须写进 `docs/ERRORS.md`/`§8.3` 的说明，
  否则会被误读成 bug。

### Follow-up Work

- 决策后：`AuthContext` 的形状、`ClientSessionConfig.role` 的来源（握手？OS 凭据？）、
  `LocalFacade::with_role` 的默认值。
- 淘汰参数与注入时钟的接线（与 `ADR-036` 的执行器决策有重叠）。

---

## 5. Compatibility and Migration

- 本 ADR 若采纳，`Role` 的取值来源变化是**行为**变化：`--no-daemon` 下用 `Admin` 权限跑的脚本需要显式
  声明角色。建议在 `caly-cli` 里加 `--as-role` 并在 `docs/EXIT_CODES.md` 旁边说明"权限不足的退出码"。
- `Idempotency::Required` 的拒绝语义属于对外契约（`ADR-020 §5`：稳定错误码是外部契约），一旦采纳，
  撤销它算兼容性事件。

---

## 6. Notes

定稿说明：本 ADR 原本把状态选择留给维护者。2026-08-28 维护者把这三份（035 / 036 / 037）的决定权交给
接续开发方，因此状态改为 Accepted，并留下三条可核对的定稿记录：① `AuthContext` 不引入（§2bis 第一行）；
② 派生 key 的方案被 parity 门禁否掉，§2.3 按原文执行（§2bis 末段）；③ 三道门禁的顺序与本地角色落点
（§2bis 第二行）。**这三条都可以被推翻**，推翻时请先看 `crates/caly-daemon/tests/idempotency_and_roles.rs`
与 `crates/caly-app/tests/error_identity.rs` 里为此写的断言 —— 它们是这条语义唯一的执行证据。

仍未做、且明确留给后续的两件事：`required_role` 之外没有 principal 层（谁在调用 = 一个角色，仅此而已）；
`--as-role` 与权限不足的退出码要等 `caly-cli` 有 `[[bin]]`。

一句话总结：

> 元数据只有在某处被读到才是契约；否则它是文档，而文档会腐烂（本轮实测：三个 MUST 全部无人执行）。
