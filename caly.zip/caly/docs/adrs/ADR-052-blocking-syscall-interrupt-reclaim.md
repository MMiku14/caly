# ADR-052: Blocking syscall 的中断/回收语义（诚实边界 + 有界回收）

- Status: Accepted
- Date: 2026-08-30
- Decision-Makers: Caly Architecture
- Related-RFCs: RFC-0002, RFC-0005
- Supersedes: None（本 ADR 是 `ROADMAP §13#1`「若引入可挂起 transport，先定义 blocking syscall
  的中断/回收语义」的**提前决策**：该语义不依赖某个特定 transport 才成立，它是调用方
  deadline/cancellation 契约（`ADR-036 §2.2`、`ADR-049 §2.4`）对**任何会阻塞的端口实现**
  的统一要求。此前该语义只存在于 `caly-io-std/src/http.rs` 的 `CallerControl` 注释与
  `caly-engine/src/source_worker.rs` 的 update 链注释中，从未成为决策。）

---

## 1. Context

Source 主链是 `HTTP → parser → CAS → D3` 的同步阶段序列，由同一个注入 clock 做 caller
deadline/cancellation 边界检查（`ADR-036`、`ADR-049`）。但在**一个阶段内部**，端口实现会
调用会阻塞的 OS syscall（`connect` / `read` / `write`）：

- 这些 syscall **无法被调用者的取消标志或 deadline 观察到**——取消是一个内存 token，
  deadline 是一个时间比较，二者都只在 OS 从 syscall 返回之后才可见。任何声称「调用中
  途取消 fetch」的实现都是在假装做一件它做不到的事。
- 因此存在一个风险：一个**挂住不响应**的对端（accept 后不读不写）可以让调用方无限期
  阻塞——caller deadline 形同虚设。
- 反过来，「回收」也必须有语义：超时/取消之后，socket 与连接去哪了？如果连接被留着
  跨请求复用，一个已超时的连接会污染下一个请求；如果连接不关闭，对端会认为资源仍在。

代码现状（2026-08-30 实测）：

- `CallerControl::timeout(peer)` = **min(caller deadline 剩余, 适配器 peer 上限)**
  （`caly-io-std/src/http.rs`，peer 上限为 `CONNECT_TIMEOUT`/`IO_TIMEOUT`），
  connect/read/write 三处 socket timeout 全部由它产生。
- 每个 blocking 调用返回后立即有一次 `control.check(...)` 事后探针——注释原文：
  「a blocking adapter may return after a caller cancelled or after its socket operation
  crossed the deadline; the outer post-call probe is the honest boundary for the current
  body-snapshot carrier, which cannot interrupt a syscall already in progress」
  （`caly-engine/src/source_worker.rs`）。
- `StdHttp` 无连接池、无 keep-alive 复用：每次 fetch 新建连接，流在作用域结束时 drop。
- **缺口**：语义零散在注释里、从未成文；「对端挂住」这一最坏形态**没有任何端到端裁判**
  （既有测试只覆盖「发起前已取消/已过期」与「连接被拒」——都是没有真正阻塞住的形态）。

## 2. Decision

**语义（对任意会阻塞的端口实现统一适用）：**

1. **不可中断性（诚实边界）**：进行中的 blocking syscall 不可被调用者中断；调用者的
   cancel token 与 deadline 只在 syscall 返回后、下一个阶段**边界**被检查。实现不得
   声称能在 syscall 中途取消。
2. **有界回收（上限）**：每个可能无界阻塞的 syscall 必须有一个确定性上限；
   有 caller deadline 时上限 = `min(peer 上限, deadline 剩余)`——**deadline 优先**，
   不是「peer 上限兜底后 deadline 只是噪声」；无 deadline/clock 时用 peer 上限。
3. **故障归类**：上限触发（socket 超时）→ `IoFaultKind::Timeout`，与其它故障可区分；
   调用方据此区分「对端挂起」与「对端拒绝/不存在」。
4. **连接回收**：fault 返回后连接随即关闭（无跨请求复用、无泄漏）；对端观察到 EOF。
   新 fetch 永远是全新连接，不继承超时状态。
5. **阶段内不作时钟读取**：比较只用注入 clock（`ADR-036`），实现不读宿主时钟。

**本 ADR 不改变现有行为**——现有代码已经实现 1–5（第 1 节）；本 ADR 把它们从注释
升级为决策，并附上此前缺失的端到端裁判（§3）。

## 3. Verification

- `caly-io-std/tests/http_contract.rs`：
  - `a_stalled_peer_is_reclaimed_by_the_caller_deadline`：真 TCP 服务器 accept 后
    **挂住不响应**；caller deadline = now+600ms。裁判断言 (a) 返回
    `IoFaultKind::Timeout`；(b) 实际用时 < 5s（若实现无视 deadline 只用 peer 上限
    10s，此断言红——这正是「min 语义」的证伪面）；(c) 服务器侧读到 **EOF**
    （连接已按 §2.4 回收）。
  - `a_cancel_during_a_blocked_read_does_not_claim_interruption`：同一挂住场景下，
    连接建立后置位 cancel token。裁判断言返回仍是 `Timeout` 且用时仍由上限决定
    （≈600ms，不是立即返回）——**「不可中断」的诚实性**：一个中途取消的调用者
    得到的是「回收」，不是「我取消了」的假报告。

- `scripts/archive/falsify_round72.py`：两个变异必须被上述裁判咬住（M1 摘除 read timeout →
  挂死回收；M2 把超时错误映射为非 Timeout → 裁判红）。

## 4. Consequences

- 调用者永远无法从「一个进行中的 fetch」及时获知取消——这是**特性**，不是缺陷：
  诚实边界保证了「取消一定在下一个阶段边界生效」这个可推理的承诺，而不是
  「看起来取消了，其实 CAS 还在写」的假象。
- 新的 blocking 端口实现（UDS transport、文件端口之外的任何 socket）必须遵守同一
  语义；实现评审以本 ADR 第 2 节为准。
- 本地文件 IO 不在本 ADR 范围：文件 syscall 无 socket 超时概念，视作有界本地操作，
  由阶段边界检查覆盖（`ADR-036` 的既有立场不变）。
