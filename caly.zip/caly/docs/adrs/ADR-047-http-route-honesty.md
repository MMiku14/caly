# ADR-047: Http 路由诚实化——ActiveCore 真经核；apply 完成即代理门开

- Status: Accepted（第五十九轮落地：`StdHttp` 三档路由、活核路由源、InboundListening 真探针、
  幂等 StopCore 对等修正、两核自检裁判、凭据边界裁判）
- Date: 2026-08-29
- Decision-Makers: Caly 接续开发方（维护者已把此类裁决交由此方自行决定，见 `ADR-035 §6bis`）
- Related-ADR: ADR-046（两核 spawn 面——ActiveCore 之所以第一次有真地址可路由）、ADR-040（响应
  label 前缀）、RFC-0006 §15（Http 共享契约）、ADR-011（单一 IO 网关）
- Supersedes: 无

---

## 1. Context

`FetchRoute` 有三档（Direct/SystemProxy/ActiveCore），而 `StdHttp` 只读 `url`——route 列被
静默忽略，ActiveCore 实际走直连。**一列被声明却不被遵守的路由就是谎言**。R54 当时记
"有 Proc 之后路由两级才有意义"——R58 之后两核真跑，意义到了。

## 2. Decision：三档各有真语义，共享一个路由源

1. **Direct**：现状——自解析、自连接、origin-form。
2. **ActiveCore**：向**活核 mixed 入站**发**绝对形式**代理请求（`GET http://host:port/path`）。
   地址来自 `CoreRouteSource`（`Arc<Mutex<Option<SocketAddr>>>`）：`StdEffectRuntime` 在
   spawn 时写入（mixed 口随 LiveInstance 记录）、stop/shutdown 清除、`StdHttp` 持同一单元
   ——一份事实，无双份簿记可漂移。无源＝"no core route source wired"、无核＝"no live
   core"，皆按名拒绝。
3. **SystemProxy**：按名拒绝（"not implemented; refusing rather than silently going
   direct"）。诚实拒绝不是永久耸肩——是等第一个真调用方带需求来。

## 3. 顺裁判咬出的两个产品缺陷（都修在产品侧）

1. **apply 完成≠代理门开**：verify 只探 controller（ApiReady），mihomo 的 mixed 入站晚若干
   毫秒绑好——紧跟 apply 的经核取回撞窗（裁判第一跑即咬出，表象是误导性的 connection
   refused）。修：真后端补 **InboundListening** 探针（原来按名拒绝；300ms 连接尝试轮询至
   deadline），两 adapter 计划＋复活计划都加这一步——apply 完成＝mixed 真在接受连接。
2. **崩核变砖**：核被带外停掉/崩掉后，下一次 apply 的 Restart 计划死在 StopCore
   （"no-running-core"）。sim 从来都说 `already-gone`（幂等成功）——真后端是对等分歧。修：
   停没在跑的核＝已达成（证据行 `already-gone`）；**停别的 id 仍拒**（防孤儿句不变）。

## 4. 核自检与凭据边界

- **自检裁判**：渲染产物必须过**核自己的校验器**（mihomo `-t`、sing-box `check`，钉死资产
  解包执行）——schema 漂移在 spawn 之前就被二进制报警。断言表先由烟测钉死（ADR-046 §1），
  本轮起由核自动复验。
- **凭据边界（§5.2 第一刀）**：demo 口令与真实 passthrough 口令必须**只活在
  artifact 字节里**（核要真值才肯 parse），manifest、annotations、job 事件流一个字都不许带
  ——边界的诚实是**位置性**的：不问"存在吗"，问"在哪"。出口侧的既有脱敏
  （`caly-common::redact` 三出口）继续持有日志/ApiError/bundle 面。

## 5. 记录在案的缺口

1. **sing-box 的 ActiveCore 端到端骑乘暂缺**：demo 拓扑的默认选择是 WireGuard endpoint 且
   peer 是 TEST-NET 惰性地址——经核取回会挂在死隧道上（demo 限制，非路由缺陷）。mihomo
   端到端＋stub 单元裁判持有路由机制；sing-box 段由 apply 内 InboundListening 持门开着。
   等真上游或 direct 路由的 sing-box demo 再补骑乘裁判。
2. **SystemProxy 未实现**（§2.3）。
3. fakeip resolver 链（承 ADR-046 §3.1）仍待 TUN 面一起付。

## 6. Consequences

- 裁判新增：io-std 路由 4（绝对形式/无核/无源/SystemProxy）、real_apply 9（经核取回端到端）
  与 10（凭据边界）、两核自检 3。census 88 文件/676 断言、floor 676、`falsify_round59.py`
  五变异。
- `unsupported-core-call`/`unsupported-probe` 面又窄一格：InboundListing 从拒绝名单毕业。
