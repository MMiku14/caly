# ADR-045: rollback 复活旧部署——同一 executor、同一 runtime；第二核心资产先钉

- Status: Accepted（第五十七轮落地：`redeploy_rollback_target` 经 `execute_effect_plan_
  with_cursor(NoCursor)` 复活 target snapshot 的 deployment、真核复活裁判、快照 LKG
  真相提升、sing-box 资产钉死＋拒绝语点名范围）
- Date: 2026-08-29
- Decision-Makers: Caly 接续开发方（维护者已把此类裁决交由此方自行决定，见 `ADR-035 §6bis`）
- Related-ADR: ADR-044（§5.4 的缺口由本 ADR 结清；§7 的 deployment 记忆由复活路径喂入）、
  ADR-043（真停核经 Proc 端口）、ADR-022（sim 门禁不动——复活在 sim 上同判）
- Supersedes: 无

---

## 1. Context

R56 之后的 rollback 会诚实**拆掉**新部署（补偿停核、撤文件、指针回退），然后停在那里：
宿主黑着。"指针恢复了、流量没有"不是操作员要的答案——rollback 的完整语义是
**回到上一个 deployment**，而不只是"离开这一个"。

同时 ADR-044 §5.4 记录：补偿无法表达"重启旧核"——补偿步骤是**拆**的动作，没有
"装回去"的动作。

## 2. Decision：复活是一次部署，不是一种新模式

`worker::redeploy_rollback_target`（补偿成功后、`recovery.succeeded` 之前）：

1. **原料来自 target snapshot 记录**：`compiled_artifact_digest`、`core_binary_digest`、
   `profile_id`；字节从 CAS 读回（`object_payload`）。记录不在／字节已失／核心非
   mihomo → **跳过并出声**（warn 日志说明为什么），保留 R56 语义——不装会成功。
2. **同一 executor、同一 runtime**：构造五步计划 `WriteObject → Materialize → Spawn →
   Probe(ApiReady) → Probe(ConfigIdentity=target 摘要)`，经
   `execute_effect_plan_with_cursor(NoCursor)` 执行。**identity 探针是整个复活的
   证据**：它证明复活的核心跑的是 *target 的配置*，不是"某个配置"。复活失败＝
   rollback 失败（`recovery.failed`）——补偿已拆、复活未立，这个中间态必须红着可见。
3. **合成 journal、不落盘**：复活运行在真 journal 全部 settle **之后**；为它发明一套
   journal 生命周期是对恢复语义的伪装。代价诚实记档（§3）。
4. **复活喂 deployment 记忆**：成功后 `record_effect_plan(Some(复活计划))`（下一次
   rollback 能补偿复活）＋`record_compiled_artifact(Some(从快照重建的 artifact))`
   ——复活之后再 apply 同 profile 判 **Noop**（R56 语义自然延伸到复活路径）。
5. **快照真相提升**（本轮裁判咬出的产品缺陷）：apply 路径把**每个**提交都标
   `last_known_good` 且无人降级，虚拟钟又按**步数**计时——Noop 的 1 步排在被回滚
   deployment 的 8 步之前，操作员视图一直指着刚被拆掉的部署。修：
   `promote_snapshot_to_last_known_good(target)`——target 的 `created_at` 抬到当前
   最新之上、被替代者降级。ghost target 容忍为 no-op（R56 前的宽容不属于这里的战场）。

## 3. 记录在案的缺口

1. **复活中途崩溃无 journal**：补偿与复活之间、复活执行中崩溃，恢复扫描看到的
   世界是一致的（journal 已 settle），但宿主可能停在"旧核死、新核未立"——下一次
   rollback 或 apply 可修复，但**没有自动恢复**。诚实边界：复活日志明示
   `plan=rollback-redeploy-*`，操作员能看见断点。
2. **复活仅 mihomo**：`core_identity` 非 `mihomo@` 的快照跳过（拒绝语点名）。sing-box
   的复活等它的 spawn 面（§4）。
3. **entrypoint 约定**：复活用 mihomo 的 `config.yaml` 约定重建 artifact 元数据；
   快照记录不携带 entrypoint/format——真值是摘要与字节，元数据是重建的。

## 4. 第二核心第一刀：sing-box 资产先钉，spawn 面拒绝点名

`sing-box 1.13.20 linux-amd64`（tar.gz，sha256 钉死于
`caly_singbox::SINGBOX_BINARY_SHA256`，资产在 `assets/cores/`，`version` 烟测过）。
计划已携带真摘要；真后端仍按名拒绝（`unsupported-core`），拒绝语改为点名实情：
**资产已钉、缺的是 spawn 面**（JSON 信封、`run -c` 旗标、geo 布局都未设计）。
钉死的意义：让这个拒绝成为**有日期的范围决定**，而不是永久的耸肩——spawn 面落地的
那天，供应链核对（R56 的 `binary-digest-mismatch` 机制）随常量即到。

## 5. Consequences

- rollback 三段式定型：**补偿（拆新）→ 指针真相（LKG 提升）→ 复活（装旧）**，
  每段各自可见、各自可失败、失败即红。
- 真核裁判从"拆得干净"升格为"装得回来"（`real_apply.rs` 复活裁判：新核死、旧配置
  活、identity 探针过、文件一清一回、复活后同 profile 再 apply 判 Noop）。
- 顺带修掉：`gunzip -k` 在复用实例目录时拒写已存在的 `core`（复活第一跑即咬出，
  `-kf`）。
- census/TEST_FLOOR 659→660（sing-box 资产钉裁判）；`falsify_round57.py` 五变异。
