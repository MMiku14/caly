# ADR-050: `calyd` 真实 effect runtime 的显式组合根配置

- Status: Accepted（2026-08-30；第六十四轮落地）
- Date: 2026-08-30
- Decision-Makers: Caly 接续开发方（维护者已把此类裁决交由此方自行决定，见 `ADR-035 §6bis`）
- Related-ADR: ADR-011（单一 IO 网关）、ADR-022（确定性仿真门禁）、ADR-036（有界端口调用）、ADR-042（进程生成与 Platform 特权面分离）、ADR-043（进程 supervision）、ADR-044（真实 effect backend）、ADR-046（sing-box spawn 面）、ADR-047（ActiveCore 路由）
- Related-RFC: RFC-0001、RFC-0005、RFC-0006、RFC-0007、RFC-0010

---

## 1. Context

`StdEffectRuntime` 已经能够在同一个 typed `EffectPlan` executor 上执行真实的
mihomo/sing-box asset 校验、artifact 物化、spawn、controller/inbound probe、stop 与
rollback。它仍必须由 composition root 显式注入：`EngineHandle` 和 `DaemonApp` 的默认
路径继续使用 `SimulatedRuntime`，否则一个看起来只是启动 daemon 的命令就会在宿主机上
创建真实进程。

此前 `calyd` 已经显式组合 `FsStore`、`StdFs`、`StdClock` 与 source `StdHttp`，但没有
给真实 effect backend 一个生产入口。仅仅把 `set_effect_runtime` 调到某个无名默认分支
也不能解决资产位置、运行目录、权限和失败阶段的语义；反而会把测试/开发默认悄悄变成
宿主机副作用。

## 2. Decision

### 2.1 真实模式是命令行显式选择，默认仍为 simulated

`calyd` 增加以下 composition-root 选项：

```text
--effect-runtime simulated|real       default: simulated
--runtime-root <path>                 real 模式必填
--assets-dir <path>                   real 模式必填
```

`--effect-runtime real` 必须同时给出两个非空路径；`--runtime-root` 或 `--assets-dir`
在 simulated 模式下不是被忽略，而是按名拒绝。不存在或无法解析的模式也是 usage refusal。
这样一个部署配置的 effect 选择在 listener 启动前已经确定，不能由环境变量或某个 apply
分支隐式改变。

### 2.2 资产目录是固定布局，bytes digest 仍在 spawn 时复核

`--assets-dir` 指向以下固定布局：

```text
<assets-dir>/cores/mihomo-linux-amd64-v1.19.30.gz
<assets-dir>/cores/sing-box-1.13.20-linux-amd64.tar.gz
<assets-dir>/geo/geoip.metadb
<assets-dir>/geo/geosite.dat
```

组合根启动前只验证这些路径是可读取的普通文件。它不根据文件名选择另一个版本，
也不在启动时把资产摘要当成计划摘要；真实 spawn 仍对**将要部署的完整 bytes**计算
sha256，并与 `EffectPlan` 携带的 digest 比较，错配按 `binary-digest-mismatch` 拒绝。
因此“能读到文件”和“该文件就是计划钉住的文件”仍是两个阶段、两个判据。

测试/源码树便利方法 `CoreAssets::workspace_default()` 只供显式测试组合根使用；`calyd`
生产入口不回退到编译时 workspace 路径，避免安装后路径失效或误取开发树资产。

### 2.3 runtime root 与权限

真实 runtime 使用 `--runtime-root` 作为 `StdFs`/`StdProc` 的 gateway root。组合根启动
前会：

1. 创建目录（若不存在）；
2. 拒绝非目录；
3. 创建并删除一个进程唯一的写入探针，确认当前 daemon 用户能写入该目录。

真实模式不自动提权、不切换用户、不下载资产，也不把 `Platform`/TUN 能力伪装成可用。
进程必须以当前用户拥有：资产文件读权限、runtime root 的创建/写入/原子替换权限、
以及实际 spawn 所需的宿主工具/权限。`StdEffectRuntime` 对尚未实现的 `NetApply`、
`NetRevert`、非 `Status` core API 等继续按 ADR-044/042 的拒绝码处理；本 ADR 没有扩大
特权面。

### 2.4 失败阶段与可观察语义

- 参数缺失、模式未知或 simulated 模式携带 real-only 选项：usage refusal，进程以 exit
  code `2` 退出；不创建 store、不监听端口。
- runtime root 或资产 preflight 失败：startup refusal，进程以 exit code `1` 退出；不
  监听端口。root 写探针若已创建但删除失败，会保留该事实并拒绝继续，而不是假定清理
  成功。
- asset 可读取但不匹配计划 digest：apply job 在 `SpawnCore` 处按名失败；executor
  的既有 cutover/compensation 语义负责清理，不能由 composition root 把错误改成成功。
- Platform/TUN 或其他真实 backend 尚未实现：job 以既有 `StepFailure` 拒绝；真实模式
  不把它降级为 simulated 成功。

`calyd` 的 startup log 明确带 `effect-runtime: simulated|real`。这只说明选择了哪一个
backend，不把“real”扩大解释为完整 OS 网络部署。

### 2.5 当前跨进程边界保持显式

`StdEffectRuntime` 当前持有 `StdProc` 的 process-local child handle 与 live route；它
尚未实现从另一个 daemon 进程接管既有 core、恢复 pid/controller/mixed-port 或为跨进程
real recovery 提供安全的 attach 语义。durable snapshot 是配置/部署记录，不是宿主进程
仍存活的证明。

因此本 ADR 只把真实 backend 接入 `calyd` 的**显式 apply composition root**，不宣称
跨重启 core adoption 已完成。任何需要接管旧 core、在 real mode 下执行进程级启动恢复或
避免旧 daemon/新 daemon 并行实例的后续实现，都必须先增加独立的 process identity、lock、
attach/recovery 方案和对应裁判；不能用读取 snapshot 或重新 spawn 代替。

## 3. Alternatives considered

- **默认把 `calyd` 换成 `StdEffectRuntime`**：否决。它会把无参数启动变成真实宿主副作用，
  破坏 ADR-022 的 deterministic default，也没有解决资产/权限/跨进程 recovery。
- **从环境变量或当前工作目录推断资产**：否决。运行位置与 shell 环境不是稳定的供应链
  配置，且会使相同命令选择不同 core bytes。
- **允许只给 runtime root，资产缺失时首个 apply 再报错**：否决。资产配置错误应在
  listener 前尽早、按名失败；延迟到首个 job 会让 daemon 看起来健康且浪费一次 apply
  事务。
- **让 `--runtime-root` 自动落到 `--data-dir` 或把 `--assets-dir` 自动落到 workspace**：
  否决。两个路径都具有安全/发布含义，必须由 operator 明确提供；默认只保留模拟路径。
- **启动时直接把资产完整读入并预先计算 digest**：否决。会重复搬运大型 core archive，
  且 plan digest 的最终核对仍应发生在 SpawnCore 对实际 bytes 的边界；preflight 只负责
  可读性。

## 4. Consequences

- `calyd` 现在有一个可复验的真实 backend 组合入口，使用方式不会改变 library 默认，也
  不会把真实 side effect 藏在 apply 分支。
- assets、runtime root、当前用户权限和失败 exit code 都是明确配置/观测面；部署文档可以
  写出可复制的启动命令，而不是依赖 workspace 布局。
- `StdEffectRuntime` 的真实 mihomo/sing-box 裁判仍是必要门禁；本 ADR 的 composition
  test 只证明选择、preflight 和拒绝阶段，不替代真核测试。
- 跨进程 core adoption、Platform/TUN、HTTPS/安全资产下载、UDS 权限与完整 runtime API
  仍是未完成范围，继续留在 status/roadmap，不被“`calyd --effect-runtime real` 可启动”
  这句话覆盖。

## 5. Reproducible evidence

```text
cargo test -p caly-daemon --bin calyd -- --nocapture
cargo test -p caly-daemon --test calyd_wire real_effect_runtime_preflight_refuses_missing_assets_before_listening -- --nocapture
cargo test -p caly-daemon --test real_apply -- --nocapture
```

第一组覆盖 mode parser 的默认/显式路径与 real-only 选项；第二组从真实 binary 验证
missing-assets 在 listener 前以 exit 1 拒绝；第三组继续验证显式注入后的真实 mihomo/
sing-box apply/rollback/probe/stop。完整 workspace gate 仍是本轮收口的最终判据。
