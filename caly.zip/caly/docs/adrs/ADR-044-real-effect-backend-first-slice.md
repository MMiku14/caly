# ADR-044: 真 effect 后端第一刀——同一 executor 跑真核，拒绝面诚实命名

- Status: Accepted（第五十五轮落地：`StdEffectRuntime` 注入同一命令路径、真核三裁判
  全绿、渲染四处真相修正、spawn 型计划补偿集扩充；第五十六轮结清 §5.1 与 §5.3——apply
  现在对着引擎最后部署的 artifact 规划，见 §7）
- Date: 2026-08-29
- Decision-Makers: Caly 接续开发方（维护者已把此类裁决交由此方自行决定，见 `ADR-035 §6bis`）
- Related-ADR: ADR-042（spawn 网关与 privileged Platform 的**故意缺席**——本 ADR 的拒绝
  面直接引用它）、ADR-043（stop/try_wait——真停核经它的端口面）、ADR-022（确定性模拟是
  PR 门禁——本 ADR 不替代它，只补"模拟说绿还不够"的那一半）、ADR-036（IO gateway——真
  后端必须全部经端口，不许绕行）
- Supersedes: 无（`sim_runtime` 的默认绑定改由组合根显式替换，`ADR-022` 的地位不变）

---

## 1. Context

第五十四轮把真 mihomo（sha256 钉死于 `assets/`）与 `Proc` supervision 面备齐之后，
还差最后一句话：**apply 的绿灯在真后端上意味着什么？**

到 R54 为止，`EngineHandle` 把 effect 后端**绑死**在 `sim_runtime` 上——所有"已验证"
都是模拟世界里的记忆：`proc.spawn` 是往一个 `BTreeMap` 里插一行，probe 的"controller
answered"是一句预置的台词。这个形状有两个问题：

1. **渲染从未被真核读过。** adapter 产出的 YAML 只被 sim 看见过；它能不能让一个真
   mihomo 完成解析，没有任何裁判。（R55 首跑即证：四处渲染真相全部是雷，见 §4。）
2. **拒绝面不可见。** 模拟世界的 `NetApply` 永远成功——"特权网络面还不存在"这个事实
   在绿灯里消失。

R55 第一步把 `effects: Arc<dyn EffectRuntime>` 从引擎解绑（`with_effect_runtime` /
`clone_with_effect_runtime` / trait accessor，sim 世界归测试自持——`effect_runtime_swap.rs`
裁判）。本 ADR 决定的是第二步：**daemon 侧那个"真"字，R55 诚实地兑现到哪一格、
其余各格怎么拒绝。**

## 2. Decision

### 2.1 `StdEffectRuntime`：全部经 IO gateway，组合根显式注入

新 `caly-daemon/src/effect_std.rs`：

- `WriteObject` —— **核实**：对象必须在真 store 里（Phase A 已 `put`；不在＝
  `object-not-found` 点名）。模拟的"insert 一行"换成对 `ObjectStore::get` 的真调用。
- `MaterializeArtifact` —— `read_object` 取真字节，经 `StdFs::write_atomic` 写真文件
  （runtime root 沙箱内，`VPath` 拒绝逃逸形状）。
- `SpawnCore` —— 从钉死资产起真核：`/bin/sh -c "gunzip -k core.gz && chmod +x core &&
  exec ./core -d . -f caly-run.yaml"`（命令行全部是 runtime 自己的固定文件名，**不含
  任何 profile 内容**；`exec` 使 handle 的 pid 就是核的 pid），geo 双件与核经同一写路
  径落进实例目录，端口由 `bind(0)` 现选。
- `Probe{ApiReady}` —— 用 `StdHttp` 真问 controller 的 `/version`，到 deadline 仍无应答
  则 `probe-timeout` 如实报。
- `Probe{ConfigIdentity}` —— 与信封里裹进去的 digest 对账，不一致点名双方。
- `StopCore` —— `ADR-043` 的 `stop(handle, grace)`，收割并报告 `code/signaled`。
- `MarkSnapshot` / `CommitRevision` —— 真相在 executor 驱动的 journal/snapshot 机器里
  （与 sim 同一分工），runtime 只出证据。

注入是**组合根的选择，不是默认**：`DaemonApp::set_effect_runtime(&mut self, …)`。引擎
出厂仍绑 sim（`ADR-022` 的确定性门禁不动）；从换入那一刻起，apply 开始在这台机器上
起进程——这个事实必须由注入者显式签字。

### 2.2 拒绝面：按名拒绝，绝不假装

真后端**没有**的能力，每一步都 `StepFailure` 点名：

| 步骤 | 拒绝码 | 理由 |
| --- | --- | --- |
| `NetApply` / `NetRevert` | `unsupported-net-apply` / `unsupported-net-revert` | 特权 `Platform` 面是**故意缺席**（`ADR-042 §2.2`），拒绝语点着它 |
| `DbTxn` | `unsupported-db` | 没有数据库就没有诚实的 DbTxn |
| `CoreApiCall ≠ Status` | `unsupported-core-call` | 只实现了问 controller；`Reload/SelectProxy/CloseConnection` 不装会 |
| `Probe ≠ ApiReady/ConfigIdentity` | `unsupported-probe` | 其余探针没有真实现 |
| `SpawnCore` 双重起 | `instance-already-running` | 计划在不停的情况下二次 spawn＝孤儿化第一个核；拒绝使其可见 |
| 非 Mihomo 核心 | `unsupported-core` | 只钉了 mihomo 资产 |

配套：失败 job 的 **detail 带步骤自己的话**（`worker.rs` 把 `FailedBeforeCutover` 等状态
里的 step summary 拼进 detail）。此前 detail 只给步骤标签——"`unsupported-net-apply`：特权
面是故意缺席（ADR-042 §2.2）"这句话操作员终于读得到。**一条绿路径因此意味着它说的话。**

### 2.3 信封模型：artifact 是 profile 真相，operational keys 属于 runtime

真核跑的配置＝artifact 原文＋一段信封（`mixed-port`、`external-controller`、`geox-url`
指向 `127.0.0.1:1` 的故意不可达 fallback——**geo 缺席必须是响亮的 fatal，不是静默下载**）。

一个 key 一个 owner：adapter 自本轮起**不再渲染 `mixed-port`**（部署端口不是 profile
内容；信封若与 artifact 撞 key，核会拒绝整个配置）。

### 2.4 补偿集：能 spawn 的计划必须能 un-spawn

`caly-mihomo` 的 Restart/RebuildAndRestart 计划此前补偿集为空（或只有 net-revert）——
rollback 对真核**什么也不补偿**，计划说"recovered"、核照跑。本轮补偿集扩为
（列表序，逆序执行）：

```
[NetRevert?, CoreApiCall(Reload)?, MaterializeArtifact(撤文件), StopCore(停新核)]
```

执行序＝stop-core → un-materialize → …；`StdEffectRuntime::compensate(StopCore)` 真停。
*重启旧核*没有步骤可表达（见 §5 缺口），不装会。

### 2.5 真核裁判（`caly-daemon/tests/real_apply.rs`）

1. **nightshift 全链**：同一 daemon 命令路径 → `snapshot.committed`，pid 在 `/proc`、
   controller 真答 `/version`，测试收尾 `shutdown()` 真停（杀后 sleep 再验，tmpfs 教训
   `DEVELOPMENT_LOG_2026-08-27 §6` 的规程）。
2. **rollback 真停**：补偿序列后进程表里没有旧核、runtime root 里没有 run 文件。
3. **TUN 诚实拒绝**：job 失败、detail 点名 ADR-042 的拒绝语、无核、无信封残留、
   不激活 profile。

## 3. Alternatives considered

- **继续只在 sim 里判**——等于承认"渲染是否被真核接受"永远无人回答；R55 首跑咬出的
  四处雷（§4）就是这条路继续走的价格。
- **engine 直连 OS**（绕过 `caly-io` gateway 起进程/写文件）——破坏 `ADR-036` 的边界，
  sim/std 无法同判，测试时钟与预算无从注入；否决。
- **真后端做全**（NetApply 也"实现"个大概）——特权网络面没有设计就没有真话；那是
  穿着实现外衣的谎言，与模拟的假装同罪。

## 4. 裁判咬出的渲染真相（一并修正）

首跑真核即 fatal，逐个定位（全部对着真二进制验证）：

| 雷 | 真相 | 修正 |
| --- | --- | --- |
| 规则目标指组 **id** | 真核 `proxy not found`（sim 不查） | 渲染组**标签**；未知 id 原样透传＝响亮失败 |
| `dns.enhanced-mode: mixed` / `system` | fatal `invalid mode`；真核只认 `fake-ip/redir-host/normal` | IR 的 System/Mixed 坍缩到 `normal`（IR 比核细，映射处注明） |
| ss/vmess/vless/trojan 缺必填参数 | fatal `unset fields: cipher, password…` | `ProxyNode.passthrough` 逐键透传（`merge.rs` 合成侧填**结构性占位值**——IR 还没有凭据模型，记缺口） |
| 组内 `interface-name: <NodeId>` | 能解析但语义为假（绑不存在的接口） | 删除；选择经组序（首个＝默认）到达核 |

## 5. 记录在案的缺口（靶子）

1. ~~`binary_digest` 仍是 adapter 占位~~ **第五十六轮结清**：计划携带资产钉死的真
   sha256（`caly_mihomo::MIHOMO_BINARY_SHA256`），`SpawnCore` 对**将部署的字节**算哈希
   核对，错配按名拒绝（`binary-digest-mismatch`，两个摘要都在拒绝语里）。
2. **IR 无凭据模型**：demo 合成填的是结构性占位（值惰性、键承重）；真订阅源的参数
   到达路径未设计。
3. ~~apply 规划恒 first-install~~ **第五十六轮结清**（见 §7）：引擎记住最后**提交**的
   artifact，规划以它为 `current`；跨 profile 变更判 Restart（StopCore 可达），同
   artifact 再 apply 判 Noop。
4. **rollback 不重启旧核**：补偿到"新核死、文件清"为止；旧核复活无步骤可表达。

## 7. 第五十六轮增补：current 的真相来源

`current` 不再是占位 None，它的语义是**引擎最后提交的 deployment**：

- **提交时记**（`record_compiled_artifact`）：apply 走到 `snapshot.committed` 才记——
  失败/回滚的 apply 不改写 deployment 记忆。
- **rollback 后忘**（置 None）：补偿把最后的 deployment 拆了，引擎不再"知道"有什么在
  跑；下一个 apply 诚实地按 first install 规划，而不是对着尸体规划热路径。
- **跨 profile 变更判 Restart**：reload 只会重读核心**自己的**配置路径，而换 profile
  换的是物化路径——判 HotReload 的计划等于先设一个必失败的 identity 探针。adapter 的
  plan kind 因此加了 `cross_profile` 卫兵。
- **同 artifact 再 apply 判 Noop**：无步骤、无 spawn、无 stop，journal 以
  `noop:<digest>` 点名（真计划 id 形如 `mihomo-effect-plan-…`，不可碰撞）。
- **parity 的前提升格**：同一操作在两条路径上比较，现在要求**相等初始状态**——
  `run_write_parity` 为 remote 侧配独立 daemon；dedup 跨路径与 bundle 回读这类**以共享
  状态为定义**的断言仍走同一 daemon 的第二个 client。
- **模拟世界的教义守住**：曾试图把 reload 建模成"核心自动采纳新物化身份"，同轮撤销
  ——身份是核心**自报**的（`seed_core_identity`），不是我们写下去的；
  `stale_live_identity_blocks_a_reload_apply_before_commit` 咬住了这一点。

## 6. Consequences

- 引擎 effect 面成为纯注入点；`ADR-022` 的 sim 门禁与真后端裁判**并行**存在（652→656
  条断言，census/TEST_FLOOR 同步）。
- `caly-mihomo` 的渲染从"sim 认就行"升格为"真核认才算"；渲染变更以后要过真核裁判。
- daemon 获得 `effect_std.rs`（+`set_effect_runtime`/`engine_storage` 组合根面）；
  `EngineHandle` re-export `caly-plan` 步骤类型（呈现层重组，依赖箭头不变——daemon 实现
  trait 不需要新边）。
