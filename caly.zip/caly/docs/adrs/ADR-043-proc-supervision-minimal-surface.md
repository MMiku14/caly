# ADR-043: Proc 端口的最小 supervision 面（try_wait / stop），TERM 决策显式推迟

- Status: Accepted（第五十四轮落地：`ChildExit` + `try_wait`/`stop` 双后端同判、共享
  supervision 契约、真内核全生命周期裁判——`ADR-042` 的 fire-and-forget 划线由本 ADR
  按新消费者修订）
- Date: 2026-08-29
- Decision-Makers: Caly 接续开发方（维护者已把此类裁决交由此方自行决定，见 `ADR-035 §6bis`）
- Related-ADR: ADR-042（fire-and-forget 是当时的诚实形状；本 ADR 是它预告的"端口生长
  决策"）、ADR-013（有界执行域——stop 的宽限期是调用方给的界）、ADR-040（标签教义：
  nonce 是调用方能带走的名字）
- Supersedes: `ADR-042 §2.1` 的"不是 supervisor"一段（保留其精神：能力随消费者到来，
  本 ADR 就是那次到来）

---

## 1. Context

第五十三轮 `ADR-042` 把 `Proc` 落成 fire-and-forget：`ChildHandle` 只有 pid+nonce，
显式写着"wait/kill/收割是未来的端口生长决策，自带 ADR"。第五十四轮把真 mihomo
跑起来的第一分钟就用到了那三样：

1. **poll**——"核心起来了吗"不能只看 spawn 成功（fork 成功≠配置合法，geo 缺失的核心
   会自己 fatal）；
2. **stop**——apply 的补偿路径要能停掉一个刚拉起的核心；
3. **收割**——没人 wait 的子进程是僵尸；一个控制面不该泄漏尸体。

同时 `std` 有一个硬约束：`std::process::Child` 只有一个信号（`kill`＝SIGKILL），
**没有 TERM**。优雅关停（让核心冲刷状态再走）在这个标准库面上不存在。

## 2. Decision

**`Proc` 长出两个方法，仅此两个；TERM 显式不做。**

### 2.1 `ChildExit { code, signaled }`

一个子进程怎么离开进程表，unix 的 wait status 只携带两件事：数字、以及数字是它
自己选的（exit code）还是信号替它选的（signal number）。`ChildExit` 原样携带两者；
压平成一个数（shell 的负数约定）会让"退出码 9"与"被 9 号信号杀死"对操作员变成同一
个答案——他们问的本是两个问题。

### 2.2 `try_wait(handle) -> Option<ChildExit>`

非阻塞轮询；`None`＝还在跑，**绝不是猜**。答案**一旦 Some 单调**：同一 handle 的后续
调用回放同一退出。会忘掉退出的端口，让"它死了吗"在最要紧的时刻不可回答。

### 2.3 `stop(handle, grace_ms) -> ChildExit`

宽限窗口属于子进程：期内它**自然退出**（冲刷状态的核心）就被如实报告；期满端口击杀
（SIGKILL——std 唯一的信号）。返回值是"它最终怎么离开的"。std 侧由端口负责 **reap**
（wait），不留给 init 收尸。未知 handle 在两条路径上都 `NotFound` **点名 nonce**——
调用方对"记账丢了"和"spawn 坏了"的重试动作不同。

### 2.4 仿真对偶

`FakeChild` 记 `exit: Option<ChildExit>`；`FakeProc::exit_child` 让世界能编排"宽限期内
自然退出"——确定性门（ADR-022）必须能扮演这个分支，否则 std 的宽限语义永远只有
死亡一支可判。`SimProc::stop` 对未退出子进程记 kill(9)；对已编排的自然退出**原样回放**
（端口不许用自己的击杀覆盖子进程自己的选择）。

### 2.5 明确不做：TERM

- **经 `/bin/kill` 间接触发 TERM**：被否决——它把"发信号"变成"再 spawn 一个进程"，
  信号面的时序、权限与失败语义全都不再是端口语义，而是某个系统工具的 man page。
- **TERM 的诚实来源**是未来带信号面的端口生长（或核心自身的 API 关停——那属
  `CoreApiCall` 面）。`stop` 的文档明说 grace＝自然退出窗口，不暗示优雅 TERM。
- **同步 `wait(timeout)`**：被否决——轮询面（try_wait）+ 带界停止面（stop）已覆盖两个
  消费场景，先长第三个面是给还没到的调用方设计 API。

## 3. 被否决的备选（汇总）

见 §2.5；另：**不把 `ExitStatus` 透出端口**——它是 std 的类型，仿真侧没有对应物，
契约就断在类型系统上；`ChildExit` 是两侧同构的最小载体。

## 4. 落地记录（第五十四轮）

- `crates/caly-io/src/port.rs`：`ChildExit` + `Proc::try_wait/stop`（doc-comment 即契约：
  单调性、宽限语义、NotFound 点名）。
- `crates/caly-io-std/src/proc.rs`：子进程注册表（nonce→`Arc<Mutex<Child>>`），
  spawn 注册、try_wait 轮询即 reap、stop 宽限轮询→期满 kill+wait；`exit_from_status`
  按 cfg(unix) 用 `ExitStatusExt` 分离 code/signal。
- `crates/caly-io-sim`：`FakeChild.exit` + `FakeProc::exit_child` + `SimProc::try_wait/
  stop/exit_child`（编排窗口）。
- 共享契约 `proc_supervision_contract_violations`（`caly-io/src/contract.rs`）：四条共享
  答案（新子未退出／stop 报告怎么离开的／退出单调回放／幽灵 handle 双路径 NotFound
  点名）两后端同判；契约表第 4 条载体更新。
- 裁判七处新增：sim contract +1（含自然退出不被覆盖）、proc_std +1（真 `/bin/sleep`
  活体 + `/bin/true` 自然退出）、**`real_core.rs` 新文件 ×3**（资产 sha256 钉死——
  `RFC-0010 §14` 第 5 条"下载校验"成为门禁；真 mihomo 全生命周期：spawn→try_wait=
  running→控制器 `/version` 经 `Http` 端口答 200→stop 宽限期满击杀→退出单调回放→
  两个端口都归还；geo 承重：`-t` 层点名 GeoSite 缺失 + 端口层观察 fatal 自退）。
- 证伪：`scripts/archive/falsify_round54.py` 5/5（见 DEV LOG）。

## 5. 后果

- 真内核与 geo 资产进入工作区（`assets/`，sha256 钉死在裁判里——漂移即红，信息含
  文件名与两个 digest）。
- `EngineHandle` 的 `EffectRuntime` 解绑（ROADMAP"后端可替换性"effects 半边）现在是
  下一轮的直通路：`SpawnCore/StopCore/Probe` 的 std 后端在本轮已具备全部原语。
- TERM/信号面：等第一个真正需要优雅关停语义的调用方（届时伴 ADR；`/bin/kill` 路线
  已在此存档否决理由）。
