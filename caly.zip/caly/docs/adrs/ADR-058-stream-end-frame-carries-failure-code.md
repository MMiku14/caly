# ADR-058: 流式 END 帧携带作业的公共失败码（failure_code）

- Status: Accepted
- Date: 2026-09-01
- Decision-Makers: Caly Architecture
- Related-RFCs: RFC-0002, RFC-0005
- Supersedes: None

---

## 1. Context

`docs/engineering/OPERATOR_SCENARIO_REPORT.md` 的发现 #6 用真实二进制测出：脚本化运维（场景 E）主链
已通，但**流式失败只有笼统的 exit 1**。对照现状：

- 一次性查询 `jobs.follow`（`caly job <id>`）携带稳定的 `failure_code`（如 `CONFLICT`），CLI 按其
  映射退出码（`EXIT_CODES.md §4.3`：`caly job 1` 对失败作业退出 4，而非 1）。
- 流式 END 帧（`KIND_STREAM_END`）只有 `stream_id` / `seq` / `state` / `outcome` 四个 record。
  `caly follow` 与 `apply --wait` 的终局判决只看 `outcome`：`Failed` → 恒为 exit 1。
- 同一失败作业，`caly job 1` 退 4，`caly follow 1` 退 1——**两条路径对同一事实给出不同退出码**，
  与「对同一种公共错误码，CLI 应给出一致退出码」（`EXIT_CODES.md §1.3`）冲突。
- 长部署失败时，CI 靠 `apply --wait` / `follow` 的退出码分流（重试 / 报障 / 放过），笼统的 1 让脚本
  必须再去 `caly job <id>` 补查——多一次往返，且把「读结论」的责任推回给脚本。

已知约束：

- END 帧是终局判决帧：resume / `--from` 可能跳过中途事件（含已有的 `JobFailed` 事件，它已经携带
  code/summary/remediation），所以退出码**必须**来自终局帧自身，不能依赖「流里见过某个事件」。
- `failure_code` 早已耐存在 `JobLogRecord`（ADR-057），重启恢复的 `JobRecord` 会重建 `Failed` 事件，
  `JobRecordSummary.failure_code` 活体与重启后一致。
- records 方言是字段可加的：旧客户端只读自己认识的字段，多余 record 天然被忽略（`wire_field` 按 key
  取）；旧 daemon 不发新字段，新客户端把「缺字段」降级为 exit 1。
- 14 个公共 `ErrorCode` 到退出码的映射表已存在（`EXIT_CODES.md §3`，`from_wire_refusal_code`）。

---

## 2. Decision

1. **流式 END 帧增加可选 record `failure_code`**：仅当终局状态是 `failed` **且**作业携带公共失败码
   时存在；值为稳定 wire 拼写（与 `jobs.follow` 的 `failure_code` 同一拼写，如 `CONFLICT`）。
   `Succeeded` / `Cancelled` / `TimedOut` 的 END 帧**永不**携带该 record。
2. **daemon 从 `JobRecordSummary.failure_code` 取码**（即 `jobs.follow` 的同一来源），不新增流专用的
   来源——一个失败作业在全系统只有一个码。
3. **CLI 的流式判决**：`Failed` 且携带已识别公共码 → 该码的退出码号（§3 表）；携带未识别码 → 13
   （`PROTO_MISMATCH`，与一次性路径的未知码降级一致）；不带码 → 1（现状不变）。三条路径（`caly job`、
   `caly follow`、`apply --wait`）对同一失败作业给出**同一退出码**。
4. **兼容性为纯字段可加**：无 wire 版本升级、无 journal 格式改动（码已耐存在 ADR-057 记录里）。
   旧 daemon + 新 CLI：END 无码 → exit 1。新 daemon + 旧 CLI：旧 CLI 忽略未知 record → exit 1。
5. **判决仍是 `outcome` 枚举**：`failure_code` 只细化 `Failed`。客户端对非 Failed 的 END 上的
   杂散 `failure_code` 一律忽略（daemon 永不发出；防御性忽略，不让杂散字段推翻判决）。

---

## 3. Alternatives Considered

- **方案 A：把码放进新增的中途 `JobFailed` 事件（流内）**
  - 优点：复用已有事件形状（`JobFailed { code, summary, remediation }` 已在流里）。
  - 缺点：事件可能落在保留窗口外 / resume 跳过，退出码不能依赖「恰好见过」；END 才是终局帧。
  - 不采纳原因：判决必须来自终局帧自身（见 Context 约束）。
- **方案 B：改引擎 `JobEvent::Done { outcome, failure_code }`**
  - 优点：码随 Done 事件进流、进 journal。
  - 缺点：journal 事件行格式变更（迁移面）、所有 render/summarize 点都要穿线；码本已耐存在
    `JobLogRecord`，END 时刻可直接取，不必动引擎。
  - 不采纳原因：为取一个已知事实改事件格式，收益不成比例。
- **方案 C：给 failure_code 另开一段专属退出码（如 64+）**
  - 优点：不与现有表冲突。
  - 缺点：§3 已把公共码固定到 3–16；再开一段意味着同一码在一次性/流式两条路径两个数字，
    恰恰制造本 ADR 要消灭的分叉。
  - 不采纳原因：违反一致性原则，脚本要记两套表。
- **方案 D：只打印不映射（END 打印码但退出码仍 1）**
  - 优点：改动最小。
  - 缺点：发现 #6 的需求就是 CI 可用的精确退出码；打印解决不了 `$?` 分流。
  - 不采纳原因：没修到缺口本身。（人类输出其实已经能从 `[failed CODE]` 事件行看到码。）

---

## 4. Consequences

- `caly follow <failed>` / `apply --wait` 对失败作业按公共码退出（如 `CONFLICT` → 4），
  与 `caly job <id>` 一致；不带码的失败保持 exit 1。
- 新契约点（judge 目标）：END 帧 record 形状、只属 `failed` 的守卫、三条路径退出码一致、
  旧行为（无码 → 1）不被破坏、`--json` 的 END 行含码且退出码同人类渲染。
- 文档：`EXIT_CODES.md §4.3` 增补流式判决规则；`OPERATOR_SCENARIO_REPORT.md` 发现 #6 收口。
