# ADR-057: 部署作业事件的持久化（Job Log Durability）

- Status: Accepted
- Date: 2026-08-31
- Decision-Makers: Caly Architecture
- Related-RFCs: RFC-0002, RFC-0005, RFC-0007
- Supersedes: None

---

## 1. Context

`JOB_FLOW_SCENARIO_REVIEW.md` 用真二进制端到端实测一个「网关部署日」场景，暴露出
R105 的最高优先级落差：

- 一次 `profiles.apply` 铸出的部署 **Job**（`caly-engine` 的 `JobRecord { id, state,
  revision, events: Vec<JobEvent> }`）当前**只活在引擎内存**（`EngineState.jobs:
  BTreeMap<u64, JobRecord>` + `EventLog`）。
- 部署**目标状态**（active profile / core / snapshot / revision）是耐久的（`FsStore`，
  启动恢复扫描会重建），但作业**过程事件**（44 个 stage/log/warn/probe/done 行）在
  `calyd` 进程退出后即失。
- 实测：`kill -9 calyd` 后同 `--data-dir` 重启，`caly job 1` / `caly jobs 1` 被拒
  `refused (CONFLICT): no such job: 1`。
- 后果：
  1. `jobs.follow` / `jobs.events` / follow-stream 的 **resume 只在同一次 daemon 生命内
     有效**；daemon 升级/崩溃/跨天回看这些 flow 最该发光的场景里，无流可续。
  2. `jobs.list`（R106 交付的发现面）在重启后列空——能发现的只有本次生命内铸的作业。
  3. 「部署事务可审计」只兑现了**状态可审计**（snapshot/revision），**过程不可审计**：
     一次失败部署的完整事件轨迹在重启后无法回看、无法打包进 support bundle 做事后归因。

`JobEvent` 有 5 个变体：`Stage { stage, pct }`、`Log { level, message }`、
`Warning { message }`、`Done { outcome }`、`Failed { error: ApiError }`。其中
`ApiError` 携带稳定公共码（`code`）+ category + retryable + summary，是可序列化的
稳定身份（`ERRORS.md` 的码表即其 wire 形状）。

约束：

- 存储已有显式耐久等级 D0–D3（`ADR-014`）；恢复正确性相关提交点至少 D3。
- `caly-storage` 用一组细粒度 trait（`ObjectStore` / `RevisionStore` / `SnapshotStore` /
  `JournalStore` / `ApplyJournalStore` / source index）表达不同记录族，`FsStore` 与
  `InMemoryStorage` 双后端实现同一契约（`object_contract.rs` 统一约束）。
- 只有 `caly-io-std` 可读宿主时钟；存储钟由 calyd 注入。
- 事件体已经过脱敏（`redact_job_event` 在进入引擎记录前应用），耐久化不引入新泄密面。
- GC 已管理 CAS/snapshot/revision 的生命周期；作业事件是**有界、可回收**的观测+审计数据。

---

## 2. Decision

Caly 为部署作业事件新增一等存储记录族 **Job Log**，并按以下决策持久化：

1. **记录族与耐久等级**：新增 `JobLogStore`（`caly-storage`），与既有 store trait 并列；
   一个作业一条 **job record**（身份 + 终态 + revision + 事件序列）。作业**终态提交点**
   （`Done`/`Failed`/`Cancelled`/`TimedOut`）按 **D3**（文件耐久 fsync+rename+dir fsync，
   与 snapshot/revision 提交同档）写入——终态作业是恢复与审计的事实，丢了就破坏「部署
   事务可审计」。**进行中**作业的增量事件按 **D1**（tmp+rename 的滚动段）周期落盘，崩溃
   可能丢最后一小段但不影响终态正确性；重启时进行中作业由既有恢复扫描收敛
   （`RFC-0005 §12`），其事件段best-effort 载入用于诊断。

2. **写时机**：引擎在作业**进入终态时**把完整 `JobRecord`（终态 + 全部已留存事件）经
   `JobLogStore` 落 D3；事件在内存里照常累积（热路径不为每条 log 付 fsync）。进行中事件
   的 D1 滚动段是可选的增量面，不阻塞终态 D3 路径。

3. **读/恢复**：daemon 启动恢复在恢复扫描后、对外服务前，把 store 里**仍在留存窗口内**
   的终态 job record 载入引擎 `state.jobs`（与 source index 恢复同形：durable 记录重建
   进程内镜像）。于是 `jobs.list` / `jobs.events` / `jobs.follow` 在重启后对历史作业
   照常工作；follow-stream 的 resume 游标（`JobEventsView` 的 retained/next index）以载入
   的留存窗口为准，窗口外仍按既有 `reset_required`/CURSOR_STALE(14) 语义处理。

4. **留存与 GC**：Job log 是**有界**的，复用既有 GC root 与宽限期机制（`RFC-0007 §13`）：
   保留最近 N 个终态作业（与 R106 的 `JOB_LIST_CAP` 同量级、可配置），超出的最旧作业事件
   随 GC 回收；仍被 snapshot/revision 引用为「last apply」的作业不被误删（与现有 GC root
   集一致）。回收是**事件行**的回收，不影响已提交 snapshot/revision。

5. **序列化**：job record 用与 wire 同源的稳定形状编码——事件枚举按 tag 存储，`Failed`
   的 `ApiError` 存其**稳定公共码 + category + retryable + 已脱敏 summary**（不存瞬态
   细节），保证落盘内容与 `jobs.events`/support bundle 里可见的一致、可重放为同构
   `JobEvent`。编码落在存储适配层（`caly-storage`），不把 serde 形状泄漏进引擎领域类型；
   不引入新外部 crate（沿用现有手写 records/JSON 方言，与 ADR-046 的依赖边界一致）。

6. **双后端契约**：`InMemoryStorage` 与 `FsStore` 实现同一 `JobLogStore`，语义差异由
   `object_contract.rs` 同族的存储契约测试统一约束（内存后端对「不支持持久」的问题如实
   报告，而非假装耐久——沿用既有「不可观测就说不可观测」纪律）。

一句话：**部署作业的终态事件是 D3 审计事实，落进一个有界、可 GC、与 snapshot 同档的
JobLogStore；启动时把留存窗口内的作业载入引擎，使 jobs.list/events/follow/resume 跨
daemon 重启闭环。**

---

## 3. Alternatives Considered

### 方案 A：作业事件仍纯内存，只持久化状态（现状）

- 优点：零存储复杂度；热路径无额外 IO。
- 缺点：flow 的 resume/发现/审计在 daemon 重启后全部失效（R105 实测）；「部署事务可审计」
  只兑现一半。
- 不采纳原因：这正是本 ADR 要消除的落差；与 RFC-0005「可证明恢复」、RFC-0002 的 job 模型
  相悖。

### 方案 B：每条事件实时 fsync（全 D3 流）

- 优点：崩溃零事件丢失。
- 缺点：一次部署 40+ 事件、含高频 log，逐条 fsync 放大写放大与延迟（ADR-014 明确反对
  「到处 fsync」）；低资源网关目标受损。
- 不采纳原因：终态提交点 D3 已保证审计事实不丢；进行中增量用 D1 best-effort 足够诊断，
  正确性由恢复扫描兜底。

### 方案 C：把作业事件塞进 ApplyJournal / CAS 复用现有记录族

- 优点：不新增 store trait。
- 缺点：ApplyJournal 服务于「未完成事务的恢复决策」，语义是 pending/unresolved 生命周期；
  作业事件是**终态后仍需留存、可分页、可 GC 的审计/观测流**，生命周期与查询形状（按
  job_id 分页事件、list 摘要）都不同；混进 journal 会让 GC root 与恢复判定耦合两类东西。
- 不采纳原因：记录族边界应反映恢复价值与生命周期（ADR-014 的精神）；独立 `JobLogStore`
  与既有细粒度 trait 风格一致。

### 方案 D：事件只进 support bundle（导出时才落盘）

- 优点：实现最轻。
- 缺点：bundle 是**按需导出**，崩溃/重启后根本没有可导出的内存事件；无法支持
  `jobs.list`/resume 的跨重启查询。
- 不采纳原因：把「可查询的历史」误当成「可导出的报告」；查询面需要常驻耐久记录。

---

## 4. Consequences

### Positive

- `jobs.list`（R106）/ `jobs.events` / `jobs.follow` / follow-stream resume 跨 daemon
  升级、崩溃、跨天回看闭环——flow 的价值不再被「重启即失」腰斩。
- 失败部署的完整事件轨迹可事后审计、可进 support bundle 归因，兑现「部署事务可审计」的
  过程面（与状态面 snapshot/revision 并列）。
- 留存有界、随 GC 回收，不无限增长；终态 D3 与既有 snapshot/revision 提交同档，恢复语义
  不被削弱。

### Negative / 成本

- 新增一个存储记录族（`JobLogStore` trait + Fs/Memory 双实现 + 契约测试 + 启动载入路径），
  是存储 schema 的一次扩展；需要在 `FsStore` 目录布局下新增 job log 命名空间与 schema 版本
  记账（接入既有 `schema_state`/migration/rollback-points 面）。
- 引擎在终态提交点多一次 D3 写（与 snapshot 提交同批时机，摊薄到既有提交路径）。
- 载入历史作业会增大启动后内存中的 `state.jobs`，靠留存窗口有界化。

### 边界 / 不做

- 不改变 wire 帧形状（`jobs.*` 操作与 R106 的 `jobs.list` 不变；只是数据在重启后仍在）。
- 不做进行中作业的「跨进程接管续跑」（那是 recovery/adoption 的另一层，RFC-0005 §12）；
  本 ADR 只保证**终态事件耐久 + 载入可查**，进行中作业仍由恢复扫描收敛为终态。
- 不引入新外部依赖；编码沿用现有方言。
- 终态作业事件的留存条数/天数默认值与 GC 宽限期对齐，具体常数在实现轮按 `JOB_LIST_CAP`
  与 GC 配置定，不写死在本 ADR。

---

## 5. 实施切片（供后续轮次）

1. `caly-storage`：`JobLogStore` trait（put terminal job record / get / list recent /
   GC 回收钩子）+ `FsStore`（D3 终态、job log 目录、schema 记账）+ `InMemoryStorage`
   （语义对照）+ 存储契约测试。
2. `caly-engine`：终态提交点写 job log；启动载入留存窗口内记录重建 `state.jobs`。
3. `caly-daemon`：恢复扫描后接入载入；GC root/宽限期纳入 job log；support bundle 可纳入
   历史作业轨迹。
4. 裁判：跨「写作业→杀 daemon→同 data-dir 重启→`jobs.list`/`jobs.events`/resume 命中」
   的真二进制 e2e（R105 实测的反例转成正例）；双后端契约；GC 回收不碰被引用作业。
