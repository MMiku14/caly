# ADR-055: 外部 init 系统（systemd）监督 `calyd`，`calyd` 继续监督 Core —— 两层监督边界

- Status: Accepted（第一百轮落地：`packaging/systemd/calyd.service` + 部署 runbook `DEPLOYMENT_SYSTEMD.md`，不改 Rust）
- Date: 2026-08-31
- Decision-Makers: Caly 接续开发方（维护者已把此类裁决交由此方自行决定，见 `ADR-035 §6bis`）
- Related-ADR: ADR-042（进程 spawn 网关——Platform/特权面与子进程生成分离）、ADR-043（Proc 最小监督面 try_wait/stop，TERM 显式推迟）、ADR-050（真实 effect runtime 显式组合根，默认 simulated）
- Related-RFC: RFC-0001（核心架构/Shell 与 supervisor 分层）、RFC-0005（部署/回滚/恢复：§3 参与者 Supervisor、§11 Core Supervisor 边界、§12 崩溃恢复）

---

## 1. Context

`calyd` 是控制面守护进程；它内部还有一个 **Core Supervisor** 管理代理核心
（mihomo/sing-box）**子进程**。随着「真核心跑在宿主机上」成为现实（ADR-044/046/050），
出现一个部署问题：**谁来监督 `calyd` 本身？**

现状（代码核实，非推断）：

- `calyd` 是一个**纯前台进程**：全仓 grep 不到任何 daemonize / double-fork /
  `setsid` / pidfile / 服务自安装逻辑（`crates/caly-daemon/src/bin/calyd.rs::main`
  直接 `TcpListener::bind` 后 accept 循环）。日志走 stdout/stderr（`eprintln!`），
  默认绑 `127.0.0.1:0`（临时端口），也支持 UDS（`--bind unix:/path`，`caly-ipc`
  `BindSpec`）。
- `calyd` 自身**没有 SIGTERM 优雅关停处理**——std 标准库面只有 SIGKILL，这正是
  `ADR-043 §2.5` 显式记录并推迟 TERM 面的理由。
- 但 `RFC-0005 §12.1` 规定：**Daemon 启动时 MUST 优先进入崩溃恢复检查，而不是立即
  启动新 Core**（检查未完成 Journal、清理孤儿 runtime、修复 system proxy/DNS/TUN、
  校验旧 Core 身份后决定接管/回滚/冷启动）。这套设计的前提就是「daemon 会死、会被
  外部重新拉起」。

因此「把守护进程交给 systemctl 托管」不是要改架构，而是把一个**本来就以前台、
可重启、崩溃即恢复为形状的进程**接到标准的进程监督器上。歧义点在于：systemd
和 `calyd` 内部的 Core Supervisor **各管哪一层**——边界不清会导致有人试图把
mihomo/sing-box 也做成独立 systemd unit，反而打断 apply 事务。

## 2. Decision

**监督分两层，各管各的，不得越界：**

```text
systemd (PID 1 / init)
   │  监督：calyd 进程的存活、开机自启、崩溃重启、stdout→journald
   │  手段：Type=simple + Restart=on-failure（外部生命周期）
   ▼
calyd（前台进程，不自我守护）
   │  监督：代理 Core 子进程（mihomo/sing-box）
   │  手段：Core Supervisor + Proc 端口 try_wait/stop（ADR-042/043）
   │  耦合：apply 事务、Health Probe、rollback/补偿、orphan 收割
   ▼
mihomo / sing-box（被 calyd spawn 的子进程，不是独立服务）
```

### 2.1 外部 init（systemd）监督 `calyd` 自身

- 交付 `packaging/systemd/calyd.service`（`Type=simple`、`Restart=on-failure`、
  `RuntimeDirectory` 承载 UDS、`--effect-runtime real` 显式开启、stdout/stderr 进
  journald）。部署、开机自启、崩溃后重启、日志聚合由 systemd 负责。
- **`calyd` 不实现自我守护**（不 fork、不写 pidfile、不自装服务）。12-factor 风格的
  前台进程 + 外部监督器是既定形状；本 ADR 只是把这个隐含前提显式化。
- systemd **不**使用 socket activation（calyd 不经 fd-passing 接受 listener，
  `BindSpec` 自己 bind）；也不依赖 systemd 的 Type=notify（calyd 不发 sd_notify），
  保持 `Type=simple` 的最小面。

### 2.2 `calyd` 继续监督 Core 子进程 —— 这一层不外包

- mihomo/sing-box 的生命周期**必须**留在 `calyd` 内的 Core Supervisor
  （`RFC-0005 §11`、`ADR-043`）：它耦合在**每一次 apply 部署事务**里——拉起后要
  Health Probe（spawn 成功 ≠ 配置合法，geo 缺失会自 fatal）、apply 补偿路径要 stop
  刚拉起的坏核心、rollback 要换核心、还要 reap 僵尸。
- **禁止**把 mihomo/sing-box 做成独立 systemd unit / launchd job 由 init 直接监督：
  init 看不到 apply 事务边界，只知道「进程活着」，无法理解「这个核心是这次失败
  部署要被回滚换掉的那一个」。
- Coordinator（何时部署/回滚）与 Supervisor（二进制生命周期）的职责分离
  （`RFC-0005 §11.2`「二者职责 MUST 分离」）不受本 ADR 影响。

### 2.3 关停与重启语义

- systemd 停 `calyd` 时发 SIGTERM；calyd 当前不拦截（std 无 TERM 面，ADR-043
  推迟）。这是**可接受的**：Core 的优雅 stop 是 `effect_std::shutdown` 的职责，
  而 calyd 异常退出后，**下一次启动的崩溃恢复**（RFC-0005 §12）会接管/清理孤儿
  Core、修复 proxy/DNS、收敛到 Last-Known-Good 或干净 Failed。崩溃重启路径本就
  被假定会发生，systemd 只是触发它的监督器。
- 未来若要让 calyd 在 SIGTERM 上主动优雅 shutdown Core，属于 ADR-043 预告的
  「带信号面的端口生长」，需另立 ADR，不在本轮。

## 3. Alternatives Considered

- **方案 A：calyd 自我守护（double-fork / pidfile / 内置 `calyd install`）**
  - 优点：一个二进制搞定，不依赖外部 init。
  - 缺点：重复造 init 已解决的轮子（监督、自启、日志、资源限制）；自我 daemonize
    在容器/systemd 下是反模式（fork 后 systemd 认为主进程退出；PID 追踪混乱）；
    把特权、pidfile 竞争、僵尸收割都拉进控制面。
  - 不采纳原因：与「前台进程 + 外部监督器」的现代服务形状冲突，且这些能力 systemd
    免费提供。
- **方案 B：把 mihomo/sing-box 也做成独立 systemd unit**
  - 优点：两个代理都能用 systemd 各自重启。
  - 缺点：**切断 apply 事务**——Health Probe、补偿 stop、rollback 换核、orphan
    判定全部失效或要跨进程重做；init 不懂「这个核心属于失败的那次部署」。
  - 不采纳原因：违反 `RFC-0005 §11.2` 职责边界与 ADR-042/043 的子进程监督契约。
- **方案 C：用 supervisord / 容器编排（docker/k8s）而非 systemd**
  - 优点：跨发行版、跨平台一致。
  - 缺点：本机/单机路由器/网关形态（本项目的目标环境，见 ADR-023 support-levels）
    最普遍的 init 就是 systemd；容器是另一条部署形态，不冲突但不在本轮。
  - 处理：本 ADR 的结论是「**外部 init 监督 calyd**」这一分层原则；systemd 是 Linux
    的实例化。非 Linux 平台（macOS launchd、Windows SCM、容器）是同一原则的不同
    监督器，留作后续工件，不与本轮的 systemd unit 冲突。

## 4. Consequences

### Positive

- `calyd` 保持纯前台、无自守护代码——监督/自启/日志/重启策略全部 declarative 落在
  unit 文件，不进二进制。
- 崩溃恢复（RFC-0005 §12）获得明确的外部触发器：`Restart=on-failure` 保证 calyd 死后
  被拉起，进而执行恢复检查。
- UDS + `RuntimeDirectory` 让本地 CLI 经 `--addr unix:/run/calyd/calyd.sock` 连接，
  无 TCP 端口暴露、靠文件系统权限做访问控制。

### Negative / Trade-offs

- 本轮只交付 Linux/systemd 工件；macOS（launchd）、Windows（SCM）、容器编排暂无
  对应单元（原则相同，工件缺失）。
- calyd 无 SIGTERM 优雅关停：systemd 停止时走「kill → 下次启动崩溃恢复」而非
  主动优雅 shutdown Core（语义正确但多一次恢复周期；优雅 TERM 面留待后续 ADR）。
- unit 固定用 `--effect-runtime real`：这是显式 opt-in（符合 ADR-050 默认 simulated
  的 fail-safe——flag 写在 unit 里，不是藏在代码默认里）；本地/CI 用 simulated
  变体（见 runbook）。

### Follow-up Work

- macOS launchd plist / Windows 服务描述 / 容器镜像（Dockerfile + 健康检查）——同一
  分层原则的其它监督器实例化。
- 打包成可安装形态（Debian `.deb`：装二进制、assets、`caly` 用户、enable unit）；
  本轮只给 unit + runbook，`make install`/打包脚本另立。
- calyd 的 SIGTERM 优雅关停面（ADR-043 预告的信号端口生长）：让 systemctl stop 先
  优雅 shutdown Core 再退，缩短恢复周期。

## 5. Compatibility and Migration

- **不破坏兼容、不改 wire、不改 Rust**：纯部署工件 + 文档。`calyd` 前台进程形状、
  `BindSpec`（TCP/UDS）、崩溃恢复逻辑全部原样复用。
- 无需版本 bump：unit/runbook 是新增交付物，不改变任何既有行为或协议。
- 现有测试里手动 spawn calyd 的方式不受影响（systemd 只是生产部署的监督器，
  测试照旧前台拉起）。

## 6. Notes

- 工件与文档：
  - 服务单元：`packaging/systemd/calyd.service`
  - 部署 runbook（安装/启用/日志/排障/simulated 变体/非 Linux 说明）：
    `docs/DEPLOYMENT_SYSTEMD.md`
- 部署后 CLI 连接：`caly status --addr unix:/run/calyd/calyd.sock`
  （R87 已支持 UDS）。
- 权限：real 模式改 system proxy/DNS/TUN 需要特权；本 unit 默认以 root 运行并在
  runbook 中说明收紧方向（RFC-0005 §13 Privilege Helper 是更长期的降权路径，
  本轮不实现 helper，避免越界）。
