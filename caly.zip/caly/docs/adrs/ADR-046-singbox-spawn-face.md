# ADR-046: sing-box spawn 面——第二核心真跑起来；复活随身份分派

- Status: Accepted（第五十八轮落地：schema-honest 渲染＋真 tar.gz 解包 spawn＋JSON 信封结构合并＋
  跨核复活裁判；`serde_json` 入 caly-daemon 由此 ADR 授权）
- Date: 2026-08-29
- Decision-Makers: Caly 接续开发方（维护者已把此类裁决交由此方自行决定，见 `ADR-035 §6bis`）
- Related-ADR: ADR-045（§4 的范围决定在本轮兑现——"资产已钉、缺 spawn 面"的"缺"不复存在；
  §3.2 的 mihomo-only 复活限制解除）、ADR-044（deployment 记忆语义不变）、ADR-043（Proc 端口）
- Supersedes: ADR-045 §4 中"缺 spawn 面"的当前状态描述（决定本身不变——当时诚实，现已兑现）

---

## 1. Context

R57 把 sing-box 1.13.20 的资产钉死（sha256、裁判、计划携带真摘要），拒绝语诚实地点名
"缺的是 spawn 面"。本轮把 spawn 面补上——并先付了一笔没预料到的学费：**渲染器与真实
schema 的距离**。对着钉死的二进制逐块烟测（`/tmp/sbtest`，decode+boot 双证据）钉死的事实：

| 渲染形状 | 1.13.20 的回答 |
|---|---|
| 顶层 `"tun"` 键（任意值） | `decode: unknown field "tun"` — FATAL |
| legacy dns server（`address` 字段） | FATAL，须 `ENABLE_DEPRECATED_LEGACY_DNS_SERVERS=true` |
| `rule_set` 字符串规则 | `start service: rule-set not found` — FATAL |
| WireGuard **outbound**（server/server_port） | `unknown field "server"` — 不 decode |
| WireGuard **endpoint**（address/private_key/peers） | ✓，但 peer 域名**启动时急切解析** |
| 域名地址的 dns server / 出站 | 须 `domain_resolver`＋`route.default_domain_resolver` |
| 无条件规则 `{"outbound":G}` | ✓（MATCH 的忠实翻译） |
| clash-api `external_controller` | ✓，`/version` 200 |

## 2. Decision

**渲染器只发二进制真收的形状；信封是结构合并，不是字符串拼接。**

1. **schema-honest 渲染**（`caly-singbox/src/adapter.rs`）：
   - dns server 全部 typed（local/udp/https），一个名为 caly-local 的 local server 恒在
     首位，域名地址挂 domain_resolver；route 带 default_domain_resolver。
   - WireGuard 渲染为 **endpoint**（1.11+ 模型）；IR 无凭据，结构键用**确定性惰性常量**
     （零字节 base64），真 `passthrough` 到场则覆盖——与 merge 的 `structural_params`
     同一教义：键载重、值惰性。
   - 协议键翻译：mihomo 形 `cipher` → sing-box 形 `method`（ss）/`security`（vmess）。
   - `MATCH` → 无条件规则；**不可译 matcher 省略并计数**（annotation
     `route.rules.elided`）——发一条引用不存在 rule-set 的规则是整config FATAL，
     省略＋注记才是诚实。
   - fakeip 是 TUN 侧特性：无 tun inbound 则省略（`dns.fakeip.elided` 注记说明）。
2. **spawn 面**（`caly-daemon/src/effect_std.rs`）：`SpawnCore(SingBox)` 分支——
   tar.gz 逐字节 sha256 核对（与 mihomo 同一供应链教义）、`tar -xzf --strip-components=1`
   解包（tar 默认覆盖——R57 gunzip 教训的前向支付）、`exec ./sing-box run -D . -c
   caly-run.json`。**信封合并**用 `serde_json`：mixed 入站口 listen_port 与 clash-api
   controller 是**部署事实**，归 runtime 所有（R55 的 mixed-port 规则），写进 adapter 的
   JSON 对象里——字符串拼接无法诚实地做这件事，此依赖是本 ADR 授权的唯一新 crate 边。
   ApiReady＝clash-api `/version`；ConfigIdentity＝spawn 时交给核的摘要——与 mihomo
   同一机制、同一真相源。
3. **实例槽**：后端仍只有一个实例槽。两个 adapter 各自的实例名
   （`mihomo-core-instance`/`singbox-core-instance`）都指向这个槽——名字说明计划
   指哪个核，槽说明能活几个（一；对活核再 spawn 按名拒绝）。
4. **demo 解绑**：sing-box demo 不再强制 tun（`wants_tun` 回到按名选择）——强制 tun
   使每个 sing-box apply 都死在 NetApply 拒绝上，spawn 面永远测不到。TUN 拒绝路径
   由 TUN 裁判继续持有。
5. **复活随身份分派**（`worker.rs`）：`revival_core_shape(core_identity)` 从快照记录的
   身份派生 CoreKind＋entrypoint（`mihomo@…`→yaml、`sing-box@…`→json）。ADR-045 §3.2
   的 mihomo-only 限制解除；其他身份仍是诚实跳过。**坑已付**：`CoreKind::as_str()` 是
   `sing-box`（连字符），不是 digest 前缀的 `singbox`——第一次跨核裁判红在跳过路径上，
   这是两个命名空间（wire 前缀 vs 身份前缀）不同字的实证。

## 3. 记录在案的缺口

1. **fakeip 的完整新 schema 未落地**：tun 启用时 fakeip server＋dns rule 会渲染，但
   domain-resolver 链未配平（c9/c10 烟测红）——tun 计划本就死在 NetApply，到达不了
   spawn；NetApply 落地的那一轮必须连带付清。
2. **merge 的 wg demo 地址用 TEST-NET-3**（`203.0.113.x`）：endpoint 启动时急切解析
   peer 域名，example.net 解析空即 FATAL。真源到场后走 `passthrough` 覆盖。
3. **libcronet.so 只是随包解包**，未核对它随核加载——无裁判、无断言，将来出问题先看这里。

## 4. Consequences

- 真核裁判升到 7（`real_apply.rs`）：sing-box 端到端（含宿主真相：解包出的
  `sing-box`＋`libcronet.so` 在实例目录、envelope 里无 7890、controller 答 /version）
  ＋跨核复活（mihomo 挡道→rollback→sing-box 复活→identity 探针判 `singbox:` 摘要→
  再 apply 判 Noop 且 pid 不动）。
- 渲染裁判 4（`render_shape.rs`）：只发二进制收的形状（烟测表就是断言表）、
  省略计数、fakeip 作用域、确定性。
- `unsupported-core` 拒绝语退役：CoreKind 两员皆有 spawn 面，match 穷尽——
  诚实的拒绝从不撒谎说"永远"，它说"现在还没有"，而现在到了。
