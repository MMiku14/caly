# ADR-062: 记录目录分片（sharded record directories）

- Status: Accepted（2026-09-02；第一百三十六轮落地）
- Date: 2026-09-02
- Decision-Makers: Caly 接续开发方（维护者已把此类裁决交由此方自行决定，见 `ADR-035 §6bis`）
- Related-ADR: ADR-035（目录即真相/索引层删除）、ADR-041（名字即主张）、ADR-054 §2.3（批量讨年）、ADR-057 §5（job-log 持久化——永不被 GC 回收）、ADR-061 §2.4（布局层走 schema 迁移链的分工）
- Related-RFC: RFC-0007 §12（Schema Version 与迁移原则）、§12.2.3（迁移失败=原样保留+拒启）
- Evidence: `STORAGE_SIZING_BASELINE.md`（第一百三十五轮量选：F1 拒启悬崖）

---

## 1. Context

量选（R135）量化了一个结构性悬崖：每个记录目录是**平的**，单目录 `MAX_ENTRIES_PER_DIRECTORY=4096`，
而 `Fs::list` 超 cap 是硬错（绝不静默截短——这是对的）。写路径不看目录（`put` 单 `stat` 讨年），
所以**写入永远能走过 4096**；悬崖咬在下次 `open`——daemon 不能跳过 open。更糟：GC 的候选集恰需同一次
list，**越崖后产品内无任何收容量**（唯一恢复=带外 rm）。可达性：满配 64 source（R134 配额上限）×
每小时一次内容有变的拉取 ≈ 1536 新对象/天，**约 2.7 天触崖**；`records/job-log` 更是**按设计永不被
GC 回收**（ADR-057 §5）——同一悬崖、更慢的引信、必然到达。

对照：content **字节**树自 R54 起就是两级分片（`objects/sha256/<xx>/<yy>/…`，256×256 桶）——只有
**记录**目录是平的。

## 2. Decision

### 2.1 六个记录目录统一分片：`<dir>/<xx>/<stem>.<obj|rec>`，xx = 记录文件名的哈希前两位

- 分片键 = **转义后的文件名主干**（`escape_component(key)` 的输出），桶 = `sha256(stem)` 的前两个
  小写 hex。不解码记录、不假设 digest 语法（digest 命名空间是调用方给的，生产是 `sha256:<hex>` 但
  规则不依赖它）；`escape_component` 单射（ADR-041）⇒ 键分布即主干分布。「名字即主张」延伸为
  **「路径即主张」**：整个相对路径由名字推导，包括桶。
- 一级 256 桶。单目录 cap 不变（4096）⇒ 每记录族上限 ≈ 256×4096 ≈ **105 万条**。第二级（content 树
  同形）是**登记在案的下一步**，某族逼近百万条时以同型迁移再加，不预建。
- 六族统一（`meta/objects` + `records/{revision,snapshot,os-journal,apply-journal,source-index,job-log}`）
  ——不只为 objects：job-log 按设计无界，是同一悬崖的必然实例；统一分片删掉**这一类** cliffs，不是
  两个实例。

### 2.2 布局变更走 schema 迁移链：`STORAGE_SCHEMA_VERSION` 1→2

ADR-061 §2.4 的分工在此兑现：目录搬家走 `caly-storage::schema` 的链与回退点。

- 迁移钩子 `ShardRecordDirectories`（v1→v2）：对每族，列平铺记录，逐个 `rename` 进其桶
  （桶由文件名推导，**无需解码**；源缺失=跳过 ⇒ 天然幂等，中断重跑即续迁）。
- **越崖的 v1 目录迁不动**：平铺目录本身超 4096 时，迁移的 list 即 CapacityExceeded ⇒ 迁移失败、
  原样保留、拒启（§12.2.3）。恢复次序如实入 runbook：**先带外删减再升级**（带外删记录是合法态，
  ADR-035 §6bis-ter）。
- 回退点（rollback point）升级为**桶感知**：枚举顶层记录文件（v1 形状）与桶内记录（v2 形状）都收；
  `records/job-log` 补进 `ROLLBACK_DIRECTORIES`（ADR-057 加族时漏登的保真欠账）。
- `caly-storage::migrations::production_migration_chain()` 成为唯一装配点；calyd bootstrap 以
  `open_with_migrations` 传入（此前生产链为空是「无待迁移布局」的正确状态——现在有了）。

### 2.3 名字主张升到桶级；顶层形状收窄

- 重开时（load）的 name claim：记录必须住在**它的名字哈希出的那个桶**——错桶=按名拒绝（ADR-041
  的越狱检查延长一层）。
- 顶层只允许桶名（恰好 2 小写 hex）；平铺记录文件出现在 v2 顶层=未迁移/损坏，按名拒绝。桶内只允许
  记录名与写残渣（残渣照旧 reap）。
- 每 cap 硬拒的教义不变：桶超 4096 = 具名拒启（点名条目数/cap/桶路径）——上限从「全族 4096」变为
  「单桶 4096」，悬崖抬高三个数量级且**不再 guaranteed 到达**，但没有变成静默截短。

### 2.4 连带政策：GC 排干率与 reopen 重哈希都不动

- **GC 每 cycle 至多 256 删**不动：它是对「一个 bug 一次抹掉整个 store」的爆炸半径边界，不是吞吐
  旋钮；分片后日常路径不再依赖「快速排干」。
- **reopen 全量重读+重哈希**（verify-everything）不动：基线实测 105-205 MiB/s、v0 现实上界
  ≈256 MiB ⇒ 每次重启 1.3-2.4 s——这是安全属性不是开销（`ADR-035 §6bis` 明确保留）；出现**实测**
  痛点再议（锚点信任/尺寸门/抽样验证），已登记，不做投机实现。

## 3. Alternatives considered

- **Fs 端口加分页/游标枚举**：否决——无状态端口加游标是契约级变更（两实现+契约测试全动）；分片
  复用 content 树先例，端口零变更。
- **两级分片（256×256）**：此刻否决——遍历成本≈桶数（一级：N 条记录 ≈ min(256,N) 次 list；
  两级：≈N 次），v0 量级下一级余量三个数量级；登记为下一步。
- **只分片 `meta/objects`**：否决——job-log 按设计无界，是同一悬崖的必然实例；删类不删实例。
- **抬高 `MAX_ENTRIES_PER_DIRECTORY`**：否决——推后悬崖不消除「写侧无界+读侧硬拒」的不对称；
  单目录 listing 的 open 成本也随条目数线性涨。
- **读时迁移（ADR-061 形状）**：否决——§2.4 已把目录搬家划给迁移链；平铺/分片混居树每次 open 都要
  双形状遍历，是永久分叉；一次性 move+回退点才是文档化形状。

## 4. Consequences

- open 的 list 次数从「每族 1 次」变为「1+非空桶数」（N 条记录 ≈ min(256,N)+1）——线性、量级小
  （4096 条 ≈ 227 次 list，量选工装复测入基线）；`stat_many` 批讨年不变（ADR-054 §2.3）。
- 记录路径变深一层：手工引用记录路径的测试/工装改用 `caly_storage::record_shard` 推导。
- R135 的悬崖裁判（4097 拒启）**退役**，由其反转（4097 正常重开）+单桶上限裁判接棒；量选工装的
  cliff rung 同步改写。
- 越崖 v1 目录的升级次序（先带外删减再迁移）入部署 runbook；带外删减可整桶删或逐条删。
