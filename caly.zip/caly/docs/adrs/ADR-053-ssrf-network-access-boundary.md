# ADR-053: SSRF 网络访问边界（RFC-0010 §11.1 的实现决策）

- Status: Accepted
- Date: 2026-08-30
- Decision-Makers: Caly Architecture
- Related-RFCs: RFC-0010 §11, RFC-0006
- Supersedes: None（本 ADR 是 RFC-0010 §11.1 四条最低要求在 `StdHttp` 上的**落地决策**；
  RFC 是规范，本 ADR 决定实现语义与豁免面。此前 `RFC_ADR_CRATE_INDEX.md` 登记
  「§11（SSRF）仍无对应实现」——本 ADR 收口。）

---

## 1. Context

RFC-0010 §11.1 要求下载路径不得被用作访问敏感本地/内网目标的探针：

- 连接后地址校验；
- loopback 限制（除显式允许的 active core 管理地址）；
- link-local / metadata 地址限制；
- 私有网段访问策略可配置，但默认保守。

2026-08-30 实测：`StdHttp` 的 `Direct` 路由对**任意**目标直连（`TcpStream::connect_timeout`），
无任何地址面校验；`FetchReq` 无策略字段。生产调用面仅 4 处：`effect_std` 3 处
（真 core controller 探针 ×2 + `fetch_via_active_core` ×1）与 `source_worker` 1 处
（用户配置的 source locator）。

## 2. Decision

1. **校验时机 = 连接后**：`connect_timeout` 成功后取 `stream.peer_addr()` 分类，不合格即
   关闭并拒绝（`TcpStream::connect_timeout(&SocketAddr)` 只在 resolve 后 connect 一次，
   不再发起第二次 DNS，因此 `peer_addr` 就是这条连接的对端——连接后校验即等价于
   「校验实际连接目标」，DNS 重绑定也逃不过同一个规则）。
2. **策略字段**：`FetchReq.scope: FetchScope { Default, AnyPeer }`。
   `Default` 保守：只允许 `Public` 类；`AnyPeer` 显式放行全部（调用方明确选择）。
   无隐式猜测——要访问私有目标必须说。
3. **分类**（`caly_io_std::classify_peer_address`）：Loopback（127.0.0.0/8、::1）、
   LinkLocalOrMetadata（169.254.0.0/16 含云 metadata 地址、fe80::/10）、Private
   （RFC-1918 IPv4、CGNAT 100.64/10、IPv6 ULA fc00::/7）、Public（其余）。
4. **豁免面**：
   - `FetchRoute::ActiveCore` — RFC 明文的「active core 管理地址」豁免（ADR-047 §2 的
     calyd 自 spawn core 混合入站），不进入校验；
   - `FetchRoute::SystemProxy` — 代理地址是调用方显式配置的信任项，而真实目标在代理
     之后不可见：既不校验代理地址也不声称校验目标，**明确记录该模式不适用 SSRF 门**；
   - calyd 的 core controller 探针（`effect_std`/`real_core` 的
     `http://127.0.0.1:{port}/...`）用 `Direct + AnyPeer`——它们是 RFC 豁免的
     「显式允许的管理地址」。
5. **拒绝分类**：`IoFaultKind::PermissionDenied`，summary 指名地址类别与
   「RFC-0010 §11.1 SSRF boundary」——不是 socket 错误，策略拒绝可被调用方识别。
   拒绝时**未写入任何字节**（校验在写请求之前），对端只看到连接关闭。
6. **模拟器不实现**：SSRF 是真实 socket 边界；`SimHttp` 无真实网络副作用，其契约测试
   用 `example.test` 假域名。`FetchScope` 字段在 sim 侧仅记录（契约两端字形一致），
   共享契约套件不含 SSRF 用例（SSRF 裁判在 `http_contract.rs`，std-only）。
7. **生产默认**：`source_worker` 的用户 locator 用 `Default`——内网/本机/元数据源的
   默认行为从「被访问」变为「按名拒绝」（安全优先的行为变更，见 Consequences）。

## 3. Verification

- `http_contract::the_default_scope_refuses_a_loopback_peer_by_name`：真 127.0.0.1 服务器 +
  `Default` scope → `PermissionDenied` + summary 含 `loopback`/`RFC-0010 §11.1`；服务器
  确认连接上收到 **0 字节**（连接后、写请求前拒绝）。
- `http_contract::an_explicit_any_peer_scope_allows_a_loopback_peer`：同目标 + `AnyPeer`
  → 请求真的到达服务器（>0 字节），拒绝不是 `PermissionDenied`。
- `http_contract::peer_address_classification_covers_the_rfc_partition`：15 个地址
  （各 IPv4/IPv6 家族边界）钉住分类。
- `scripts/falsify_round73.py`：M1 摘除连接后校验 → loopback 拒绝测试红（请求到达服务器）；
  M2 分类把 `127.0.0.1` 判为 `Public` → 同测试红。

## 4. Consequences

- **行为变更（有意）**：指向 loopback/link-local/私有网段的 source locator 在默认配置下
  被拒绝——这正是「默认保守」的代价；放行需要显式 `AnyPeer`（当前无配置面，拒绝信息
  指名 RFC 条款与类别，让操作者知道去哪里找答案）。安全面按 RFC 先行，放行面随配置
  功能落地。
- `FetchReq` 增加必填字段 `scope`：所有构造点（4 生产 + 5 测试）显式表态，
  未来新增 fetch 路径不会「忘掉」策略。
- 新 blocking 端口实现（UDS transport 等）无 IP 地址语义，不适用本边界；
  若未来引入 `https`，TLS 层不改变本校验（校验在 TLS 握手前已完成）。
