# ADR-048: SystemProxy 真实现；Direct 模式即路由决定；wg 凭据覆盖路径兑现

- Status: Accepted（第六十轮落地：`StdHttp` 三档路由收齐、sing-box Direct 模式渲染＋
  ActiveCore 真骑乘、wg passthrough 覆盖；`ADR-047 §5.1` 与 `ADR-046 §3.2` 两缺口关闭）
- Date: 2026-08-29
- Decision-Makers: Caly 接续开发方（维护者已把此类裁决交由此方自行决定，见 `ADR-035 §6bis`）
- Related-ADR: ADR-047（路由三档——本轮收齐第三档；§5.1 骑乘缺口由本轮 §3 关闭）、
  ADR-046（§3.2 的"真源到场后走 passthrough 覆盖"承诺由本轮 §4 兑现）
- Supersedes: 无

---

## 1. Context

R59 留下三档路由的最后一块诚实拒绝（SystemProxy）、一个记档缺口（sing-box 的
ActiveCore 骑乘——demo 默认选择是死 wg 隧道）、一个未兑现的承诺（wg 凭据的
passthrough 覆盖路径，ADR-046 §3.2 写了"到场后覆盖"但路径不存在）。

## 2. SystemProxy：环境解析一次，骑乘机制复用

- **绝对形式机制复用**（`ADR-047 §2` 的 ActiveCore 机制）：`SystemProxy` 向组合时注入的
  代理地址发绝对形式请求。无代理组合＝按名拒绝（"no system proxy is configured…
  refusing by name rather than silently going direct"）。
- **环境在组合根解析一次**：`system_proxy_from_env()`（`http_proxy` → `all_proxy`，小写
  键）只在 `StdEffectRuntime::new` 调用——fetch 中途重读环境会让同一次 apply 的路由
  取决于碰巧运行的时刻。纯解析半件 `parse_proxy_value(&str)` 单独可判：scheme 前缀
  容忍、`host:port` 为形、**待解析的名字与无端口的值都返回 None**（猜端口与静默直连
  是同一个谎的两个方向）。

## 3. Direct 模式即路由决定（关 `ADR-047 §5.1`）

sing-box 渲染此前无视 routing_mode：Direct 模式仍渲染 MATCH→group 规则，把全部流量送进
demo 选择器（默认 WireGuard endpoint，peer 是 TEST-NET 死对端）——**一个 Direct 模式的核
取不回任何东西**。修：Rule 模式保规则；**Direct 模式一条规则都不发**，`final: direct`
本身就是路由决定。裁判 9 的 sing-box 段随即从"门开着"升格为**真骑乘**：
`nightshift-sing-direct` apply → 经 mixed 入站真实取回 example.com 200。

## 4. wg 凭据覆盖路径（兑现 `ADR-046 §3.2`）

`render_wg_endpoint`：`passthrough` 的 `private_key`/`peer_public_key` 逐字、
`local_address`/`peer_allowed_ips` 逗号列表；缺键回落确定性惰性常量。**真值永远赢**，
惰性只在真空缺时兜底——裁判双向持有（真键在场→逐字出现；真空缺→惰性常量）。

## 5. 记录在案的缺口

1. `https_proxy`/大小写键未读（`HTTP_PROXY` 大写按惯例仅 CLI 场景；等真调用方带需求）。
2. socks5 系统代理未支持（`parse_proxy_value` 只收 `host:port` 的 HTTP 代理形）。
3. mihomo 侧 Direct 模式早已由核自身语义覆盖（`mode: direct`），无渲染改动需要。

## 6. Consequences

- `FetchRoute` 三档全真：Direct／ActiveCore（R59）／SystemProxy（本轮）——
  `unsupported` 拒绝语从路由面退役。
- 裁判新增 3（system-proxy 骑乘／无代理拒名／纯解析）＋渲染 2（Direct 模式／wg 覆盖），
  裁判 9 sing-box 段升格真骑乘。census 88 文件/680 断言、floor 680、
  `falsify_round60.py` 五变异。
