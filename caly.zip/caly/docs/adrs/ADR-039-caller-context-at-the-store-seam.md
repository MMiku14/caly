# ADR-039: 把调用方的 Context 送进 store 接缝（对 RFC-0007 冻结签名的修订）

- Status: Accepted（**四步全部落地**（第三十三～三十六轮）：23 个方法签名全链、伪造 ctx
  删除、`Cancelled` 门、归属真实化；累计字节预算（`ByteMeter` + 三助手、双后端同门）；store 接缝的
  等待时限（ctx 期限 × 注入时钟 × 驱动器三分答案）；门面穿透（查询路径 `caller_ctx` 三规则、引擎
  幽灵 ctx 移除、端到端裁判）。落地记录 §6/§7/§8/§9）
- Date: 2026-08-29
- Decision-Makers: Caly 接续开发方（维护者已把此类裁决交由此方自行决定，见 `ADR-035 §6bis`）
- Related-RFCs: RFC-0002, RFC-0006, RFC-0007
- Supersedes: None（本 ADR 是对 RFC-0007 已冻结 `StorageBackend` 签名的**修订记录**；RFC 原文作为
  历史文件不改写，修订以本 ADR 为准——与 `ADR-035` 对其 §2.4 字面保守化偏离的处置方式相同）

---

## 1. Context

`ROADMAP §1bis.1` 判明三件事卡在同一道门后：**打断一次已经开始的 store 调用**（第二十三轮"到不了的
那一半"）、**按调用方累计 store 预算**（第二十四/二十九轮"字节的那一半"）、**给 store 接缝一个真正的
等待时限**（第二十八轮"在 `Deadline` 内"的那一半）。它们互相同源：`RFC-0007` 冻结的 store 签名不带
调用方上下文。

本轮实测又找到这道门的第四个症状，也是最直观的一个：`FsStore::open` 在打开时**捏造**了一个
`IoContext`（`TraceId::new("storage")` + `Actor::System`）存进 `StoreInner.ctx`，此后每一次端口调用
都归属于它。调用方的身份死在引擎边界上——store 对所有调用者都以同一个幽灵应答。归属、预算、取消、
时限，四件事共用这一条断路。

而 `RequestContext`（= 端口层 `IoContext`）早已带齐了所需的一切：`cancel: CancelToken`
（`ADR-036 §2.2` 的协作取消）、`io_budget`、`deadline_ms` 与 `deadline_mono_ms`。缺的不是类型，
是接缝。

## 2. Decision

1. **六个 store trait（`ObjectStore` / `RevisionStore` / `SnapshotStore` / `JournalStore` /
   `ApplyJournalStore` / 聚合的 `StorageBackend`）的全部方法，尾参增加 `ctx: &IoContext`。**
   借用是调用作用域的：后端不得把它留存到调用之后（端口层对 `IoContext` 的既有规则原样适用于
   store 层）。选 `IoContext` 这个名字而不是新造 `StoreCtx`：store 接缝说的就是端口词汇，
   `ONBOARDING_NOTES` 处置表已拒绝过"把门面概念塞进端口类型"的反方向（`role` 那一条）。
2. **`FsStore` 的伪造 ctx 字段删除。** 端口调用携带交给 store 方法的那个 ctx：归属真实化——
   端口看见谁的 trace，就真的是谁的。store 从此不再发明自己的调用者。
3. **取消在接缝上有意义**：新增 `StorageErrorKind::Cancelled`；已取消的 ctx 拒绝**新的**工作单元，
   已在飞行中的单元完成（与 `ADR-036 §2.2` 执行器同一纪律：取消是协作的，不是撕毁的）。
   第 1 步把这门落在内容半（两个后端 `list_content` / `delete_content` 的先导检查 + fs 走查的
   级间检查）；其余方法随第 2–4 步各自获得预算/时限时补齐同一扇门。
4. **引擎自发的工作（idle GC、启动恢复）携带引擎自造的 ctx**（`Actor::System` + 引擎自己的
   trace 标签），绝不借用碰巧在场的调用者的：归属诚实优先于归属精确。门面把**调用方**的
   ctx 端到端送达是第 4 步，不靠提前挪用凑数。

## 3. 被否决的备选

- **`WithContext(store)` 装饰器，不动 trait。** 调用方仍然没有入口提供 ctx：三件事依旧卡死，
  且装饰器把"必须提供 ctx"降级成"可以忘掉提供"——可选的门等于没有门（未变红的门禁 ≈ 未使用的
  规则，同一形状）。
- **`set_ctx()` / 任务本地存储。** 跨 `await` 的隐式状态是伪造的另一种形状：派生值放在无来源的
  地方、必须记得刷新（`§4.81` 对 active-snapshot 镜像的教训，原样适用）。
- **等 RFC 先改。** `ROADMAP §1bis.1` 已判明正确下一步就是一份 ADR；RFC > ADR 的权威序不变，
  本 ADR 即修订记录本身。

## 4. 三件解锁事的分阶段

| 步 | 内容 | 前提 |
|---|---|---|
| 1（本轮） | 签名全链；`FsStore` 伪造 ctx 删除、端口归属真实化；`Cancelled` 门落在内容半 | 无 |
| 2（第三十四轮已落地，§7） | 字节预算：`ctx.byte_meter` 累计计费 + `admit_bytes`/`admit_unit`/`charge` 共享助手，双后端同门，收口第二十四/二十九轮的"字节那一半"（`ADR-036 §6bis-decies` 的偏离前提消除） | 第 1 步 |
| 3（第三十五轮已落地，§8） | `deadline_mono_ms` 由驱动处判定：store **开箱注入** `Clock`（`with_clock`，组合根拥有选择权），`drive_port` 把 ctx 的期限与取消一并递给 `Drive`；无时钟 ⇒ 期限被忽略而非被猜（`§4.86`） | 名义前提"有界池"实证为不必要——驱动处判限不需要等待事件，见 §8 |
| 4（第三十六轮已落地，§9） | 门面穿透：daemon/app 的 `RequestContext` 经 `EngineHandle` 到达 storage——每调用方的归属、取消、预算端到端；引擎三方法（digest/payload/metadata）的 `store_ctx` 幽灵移除；命令路径的期限换算**记录不做**（判期限属于执行侧驱动器，映射层不借存储钟，见 §9） | 第 1 步 |

## 5. Consequences

- **签名牵动全链**（engine/gc/tests/stubs 一次付清）；之后任何新能力不再为 ctx 重开接缝。
- `StorageErrorKind` 新增 `Cancelled`：调用方须把"被取消"与"失败"分开上报。第 1 步里 gc 的
  per-target 报告把被拒目标记为 failed 并带取消说明文本——诚实的中间态，第 4 步把它升为
  一等结果。
- **行为不漂移是验收线**：不取消、无预算、无时限的 ctx（`Default` 语义）之下，本轮之前 534 条
  断言全部逐字保持——第 1 步只加门，不改既有答案。

## 6. 第 1 步落地记录（第三十三轮）

**签名全链**：六个 store trait 的全部 23 个异步方法尾参加 `ctx: &IoContext`；`FsStore` 的
`StoreInner.ctx` 字段删除（打开时的 schema gate 改用局部、自标的 `storage-open` 上下文；同步
introspection 方法同理自标 `storage-introspection`）；`audit_backend` 增 `ctx` 参数（调用方归属）。
引擎侧 `EngineHandle::store_ctx()`（`engine-storage` 标签）供引擎自发工作使用——idle GC、启动
恢复、bundle、daemon 的 storage audit 各自在调用点传入。

**取消门（第 1 步落在内容半）**：`StorageErrorKind::Cancelled` 新增；fs 走查的 `spend` 闸门
（预算与取消同一道闸，第一次 spend 即先导检查，其后每次下级之前再查）；两后端的
`delete_content` 各有先导检查；InMemory 的 `list_content` 同门。`sweep_objects` /
`sweep_orphan_content` / `run_object_gc` 把 ctx 透传给 store——被取消的目标在 per-target 报告里
以取消说明文本出现（§5 记录的中间态，第 4 步升一等）。

**裁判**：`content_sweep.rs` 增 2（`the_port_sees_the_callers_trace_not_a_fabricated_ghost`——
ProbeFs 记录端口所见 trace，走查期间必须全是调用方的；`a_cancellation_that_arrives_mid_walk_
stops_the_next_level`——第一次端口调用时才取消，先导检查已过，级间门拦截）；`object_contract.rs`
增 1（`a_cancelled_caller_is_refused_the_same_way_on_both_backends`——两后端 walk 与 delete 同答
`Cancelled`）。契约总数 534 → **537**。

**证伪**：`scripts/archive/falsify_round33.py`，6 条变异全咬（fs 走查闸门失忆 / InMemory walk 门失忆 /
两后端 delete 门各一条 / 走查重递伪造身份 / Cancelled 误报 Busy）。

**验收线兑现**：签名变更不加门不改既有答案——改造完成的当次全仓运行即 **537 passed / 0 failed**
（534 条既有断言逐字保持），clippy 基线 32 不变，0 warning。

## 7. 第 2 步落地记录（第三十四轮）：累计字节预算

**前提**：`ADR-036 §6bis-decies` 当年把 `max_bytes` 降格为"单次调用上限、端口执行"的唯一理由是
store 签名不带 `Ctx`——没有调用方作用域，挂在 store 上的计数器会跨进程累计（"读起来像预算、
行为像停机"）。第 1 步消除了这个前提；本步把缺的另一半补上。

**形状**：`caly_common::ByteMeter`（`Arc<AtomicU64>`，克隆共享——同一上下文递归传递即同一命令的
作用域；相等性按身份，与 `CancelToken` 同理同形）。挂在 `RequestContext.byte_meter`，默认新 ctx
新域。规则只写一次：`caly_io::budget` 的 `admit_bytes`（写先导准入——写的大小事前已知，拒在
任何字节落盘之前）/ `admit_unit`（读准入——读要移动字节才知道大小，故门是"还有没有剩"，在飞
单元完成并如实计费、下一单元拒，与取消门同一在飞纪律）/ `charge`（事后记账）。fs-store 在
`write_bytes`/`read_bytes` 漏斗接线（内容、记录、验证读全部计费）；InMemory 的 `put`/`read_object`
调用同一助手——**规则一处写、两后端调**（第二十六轮的规矩）。

**语义边界**（有意为之，测试钉住）：未声明 `max_bytes` 的 ctx（默认与引擎自标 `engine-storage`）
零门零拒——`RequestContext::new` 的形状不被静默拦截；计费粒度后端自决（fs 连记录与验证读一起
计，memory 只计 payload），**门是契约、字数不是**——契约测试断言同 kind 同措辞，不断言同字数。

**裁判**：`crates/caly-storage/tests/store_byte_budget.rs` 9 条（含两条本轮关键）：
`a_write_charges_the_bytes_it_wrote_not_just_the_verification_read`——fs 的 put 是"写+读回验证+记录"，
读回同样计费，若写计费丢失 meter 仍会走动（证伪 M2 第一版不咬的原因）；floor=2×payload 钉住
每条路径各自的贡献。`clones_share_one_meter_so_a_command_pays_once_for_its_whole_scope`——克隆
共享正是 RFC 当初要的"执行器持有计数器"，挂在 ctx 上让旧担忧（跨进程停机）不成立。

**证伪**：`scripts/archive/falsify_round34.py` 8 条全咬（fs 写准入/写计费/读准入/读计费、memory 写准入/
读准入/读计费、共享措辞丢 "cumulative"）。契约 537 → **546**。

## 8. 第 3 步落地记录（第三十五轮）：store 接缝的等待时限

**收口的是第 28 轮"故意没做"的那一半**：当时 `port_drive.rs` 有了轮询预算（挂起端口 ⇒
`Busy` 而非 `Internal`），但"在 `Deadline` 内"缺席，理由写在 ADR-036——判期限要有时钟，
而那一层没有。第 1 步把 ctx 送进了接缝，期限的**载体**就位；本步补上**判定者**。

**形状**：`FsStore::with_clock(Arc<dyn Clock>)`（构造期 builder；组合根拥有时钟选择——
`StdClock` 真机 / `SimClock` 确定性门，与 `ADR-038 §3` 文件日期同一教义）。`drive_port` 现在
把 ctx 的两样东西递给端口层的 `Drive`：`cancel`（每次驱动都搭载——第 33 轮的取消门是方法内
先导检查，这是覆盖**挂起中端口**的另一半）与 `deadline_mono_ms`（仅当 store 持有时钟才判——
**期限与钟缺一即忽略、绝不猜测**，`§4.86`）。`from_iofault` 补 `Cancelled → Cancelled` 映射，
`Timeout` 原有映射保留：驱动器的三种答案（取消/超时/预算）在 store 侧仍是三种。

**前提复核**：阶段表原写"前提 `ADR-013` 有界池"——实证为**不必要**：有界池是"等一个完成
事件"（真阻塞调用）的前提；而判期限只需要在轮询之间读钟，`Drive` 已有该语义（`drive_pinned`
每轮 poll 前查取消→期限→预算）。第 4 步若引入真阻塞端口，池与期限的关系再议。

**裁判**：`crates/caly-storage/tests/store_port_deadline.rs` 5 条（过期期限+钟 ⇒ `Timeout` 非
`Busy`；未来期限 ⇒ 预算照旧 `Busy`——两侧边界；无钟 ⇒ 期限忽略不猜；取消调用方在挂起端口上
被答 `Cancelled`；同一调用方同一期限、钟前进后 `Busy` 变 `Timeout`——**判时限的是钟，不是
调用方的话**）。契约 546 → **551**。

**证伪**：`scripts/archive/falsify_round35.py` 5 条全咬（期限不递 / 取消不递 / `Cancelled` 压平为
`Internal` / `Timeout` 压平为 `Busy` / `with_clock` 收下钟又丢弃）。M1 第一版用 `&& false`
let-chain——本仓 edition 不支持、不编译，不作证（`§4.112`），换成可编译的 `(None, clock)`
形状后咬住。

---

## 9. 第 4 步落地记录（第三十六轮）：门面穿透

**收口的是第 1 步留在引擎里的三处幽灵**：`latest_support_bundle_digest` / `object_payload` /
`object_metadata` 当时以 `Self::store_ctx()` 自标签——签名已带 ctx，身份却是引擎的而非调用方的。
本步把 `ctx: &caly_io::IoContext` 提到参数上，daemon 侧由 `caller_ctx(app, actor, envelope)` 构造，
三条规则：**身份转发不造**（trace 用调用方的，绝不 `TraceId::new("daemon")`）、**预算缺省用
`IoBudget::default_command`**（`unlimited` 不可达——缺省不是无限制）、**相对期限仅当组合根注入了
钟才换算**（`with_deadline_from(now, relative)`；无钟则 unset 被端口忽略、绝不猜一个绝对值）。

**穿透范围按诚实划线**：查询路径只有 diagnostics 家族今天真读存储，`handle_query` 收 ctx、
`ReadSupportBundle` 一臂穿到引擎；其余十个纯内存应答家族**不收**这个参数——未用参数是另一种
漂移（query.rs 注释讲明了这条线与"长大后必须补穿"的编译期强制）。命令路径的 ctx 随
`Command.context` 早已入引擎，其 `deadline_mono_ms` 保持 unset：判期限属于执行侧驱动器
（`§4.86`），request_map 是纯映射、无 app 手柄，不借存储钟——**记录不做**而非漏做。

**本步自己的失误**：`caller_ctx` 初版把 `envelope.deadline_ms.unwrap_or(0)` 送进了换算——
"未声明期限"被静默变成"立即过期"，正是本 ADR 反对的借在场值凑数。无漂移裁判首跑即抓住
（`deadline_ms.or(Some(0))` 形状，已入证伪 harness 作回归变异 M6）。

**裁判**：`crates/caly-daemon/tests/facade_store_ctx.rs` 4 条端到端（16 字节预算 ⇒ 拒词点名
`io_budget.max_bytes`；拨到 700 的注入钟 × `deadline_ms: 0` ⇒ 拒词点名 `deadline at mono 700`
——幽灵 ctx 无期限、别的钟读不出 700；`ProbeFs` 读取期全部 trace == 调用方 trace；不声明
预算与期限 ⇒ 照旧读回）。daemon 测试不引 `caly-io-sim`（架构边），夹具用 `StdFs` + 手摇
`TestClock`。契约 551 → **555**。

**证伪**：`scripts/archive/falsify_round36.py` 6 条全咬（引擎换回幽灵 / daemon 丢预算 / 丢期限换算 /
伪造 trace / app 方法无视 ctx / `or(Some(0))` 回归）。
