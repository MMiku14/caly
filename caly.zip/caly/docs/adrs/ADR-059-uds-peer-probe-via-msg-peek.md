# ADR-059: UDS 对端探测经 MSG_PEEK（隔离 FFI crate，caly-ipc 保持 forbid(unsafe_code)）

- 状态：Accepted（第一百二十三轮）
- 关联：`ADR-043 §2.5`（不引外部 crate）、`ADR-056`（手写最小 FFI 先例）、`TRANSPORT_RUNTIME_MODEL §5`、`ROADMAP §13#3`

## 1. Context

`WireIo::probe_peer` 是流泵的死对端检查（R53 引入、R87 走 `WireIo`、R122 收进
`TimeoutScheduler::probe_peer`）：TCP 用 std 的 `TcpStream::peek`（0 字节=Closed），
UDS **恒 `Indeterminate`**——std 没有 `UnixStream::peek`，0 字节 read 会消费数据，
would-block write 也不证明对端已走。诚实的代价：UDS 上一条中途消失的流客户端会让
泵空转到 tick 预算耗尽（`a_stream_client_that_leaves_mid_wait_is_reaped_within_one_wait_tick`
因此只在 TCP 上断言）。

kernel 一直有答案：`recv(fd, buf, 1, MSG_PEEK | MSG_DONTWAIT)`——非破坏性看一眼，
0=对端有序关闭，>0=有数据，EAGAIN=开着没数据。但它是 syscall，需要 `unsafe`，而
`caly-ipc` 是 `#![forbid(unsafe_code)]`——`forbid` 不能被局部 `allow` 覆盖，这是
刻意的防线（wire codec 不该长出指针运算）。

## 2. Decision

1. 新增 workspace crate **`caly-uds-peek`**：手写 `extern "C" { recv, __errno_location }`
   四行声明 + 三个常量（`MSG_PEEK`/`MSG_DONTWAIT`/errno），**零依赖**（沿 `ADR-043 §2.5`
   不引 libc/nix；`ADR-056` 的手写 FFI 先例）。`unsafe` 集中在这一个文件，审查面独立。
2. 语义镜像 TCP 探测：recv 0 / ECONNRESET→`Closed`；>0 / EAGAIN→`Alive`；EINTR 重试；
   其它 errno→`Unknown`。**不发明关闭**：`Unknown` 映射 `PeerProbe::Indeterminate`，
   恰是 ADR 前的诚实答案——探测不到只丢 reap，绝不误收割活会话。
3. **平台范围如实**：Linux（glibc/musl 的 errno 事实）为支持目标（systemd unit、部署
   故事）；其它 unix 编译为 `Unknown` 而非猜 ABI（errno 访问器与值各不相同）；非 unix
   为 no-op。不支持平台只是回到 ADR 前的行为。
4. `caly-ipc` 依赖 `caly-uds-peek`（workspace 内部路径依赖，非外部 crate）；endpoint 的
   `UnixStream::probe_peer` 改走 `peek_stream`；`caly-ipc` 自身保持 forbid。
5. 不做：abstract sockets/named pipes；UDS 权限模型（RFC-0010 §14 整条仍开）；
   `WireIo` 形状不变（`PeerProbe` 三值不动）。

## 3. Alternatives Considered

- **引 `libc` crate**：一个依赖换 `recv` 与 errno 常量。违反 `ADR-043 §2.5`（外部
  crate 须 ADR，且现有唯一直接依赖是 ADR-046 的 serde_json）；为四行声明引一个 crate
  不成比例。
- **在 caly-ipc 内 `allow(unsafe_code)`**：不可行——crate 级 `forbid` 不能被局部覆盖；
  即便可行也是拆防线。
- **0 字节 read 探测**：消费数据（hello 帧会被吃掉），非等价。
- **保持 Indeterminate**：诚实但把 UDS 部署（systemd unit 的默认传输）置于次等地位——
  R55 的 unit 就用 UDS。

## 4. Consequences

- UDS 流泵获得与 TCP 同级的死对端 reap：新裁判
  `a_uds_stream_client_that_leaves_mid_wait_is_reaped_too`（同一对话、unix socket、
  一个 wait tick 内出现 reap 行、daemon 不 wedge）。旧钉翻转：
  `unix_probe_stays_indeterminate_after_the_peer_drops` →
  `unix_probe_reports_closed_after_the_peer_drops`；`unix_connect_and_hello_round_trip`
  的探活断言 Indeterminate→Alive。
- `caly-uds-peek` 自带单测三钉（静默 Alive / 数据待读 Alive 且 PEEK 不消费 / 对端
  drop→Closed），Linux-gated。
- 审计面：`unsafe` 只存在于 `caly-uds-peek`（`unsafe_op_in_unsafe_fn` deny），
  `grep -rn unsafe crates/` 的结果保持可一眼审。
- `TRANSPORT_RUNTIME_MODEL §5` 的实现表与 §10 主张 4 相应更新（UDS：`Indeterminate`
  →按平台 `Closed`/`Alive`/`Unknown→Indeterminate`）。
