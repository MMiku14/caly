# ADR-061: durable source index 的 cache tag 演进与读时前向迁移

- Status: Accepted（2026-09-02；第一百二十六轮落地）
- Date: 2026-09-02
- Decision-Makers: Caly 接续开发方（维护者已把此类裁决交由此方自行决定，见 `ADR-035 §6bis`）
- Related-ADR: ADR-049（有界 body、显式 endpoint、条件请求、source-index durable schema）、ADR-050（真实 runtime
  组合根）、ADR-057（作业事件持久化的记录/信封分层先例）
- Related-RFC: RFC-0003（pipeline/provenance）、RFC-0007 §12（Schema Version 与迁移原则、§12.3 向后兼容）

---

## 1. Context

`ROADMAP §12` 里程碑 2 点名「维护 durable source index 的 schema 演进与 migration 语义，保持已有原子提交、
CAS root 和 locator 失效」。深读现状后，这题分三层，两层已有、一层是真缺口：

- **布局层**（目录/文件布局的版本门禁）：`caly-storage::schema` 已实现 RFC-0007 §12 的 marker、classify、
  逐步前向迁移链与回退点，且有裁判（`schema.rs` tests）。`STORAGE_SCHEMA_VERSION=1` 至今未动，生产链为空
  是「无待迁移布局」的正确状态，不是缺口。
- **信封层**（记录字段演进）：`record.rs` 的键值信封对加性可选字段事实上兼容（`failure_code` 即先例：
  旧记录缺键 → `None`），未知新键按名拒绝（`reject_unknown_fields`）。
- **opaque cache 层**（`normalized:v1` / `provenance:v1` / `diagnostics:v1`）——**真缺口**：
  1. tag 是严格相等检查，任何演进（哪怕只是换个 tag 串）都会让旧目录里的全部记录在下次启动**砖死**；
  2. 拒绝语是一句泛化的「unsupported version or shape」，既不说找到的 tag 也不说支持的 tag（R75 已把
     「按名诊断」教义施加于 digest 格式，tag 是漏网之鱼）；
  3. 最要紧的：cache 只被**内容摘要锚**绑定，不携带**生产者身份**——pipeline 语义变化（normalize/
     provenance/diagnostics 的产出规则变了）之后，旧 cache 字节不变、锚全对，却已是旧管线的产物，且
     **不可检测**。`StageContext::pipeline_epoch` 存在但从未落盘，三处硬编码 `1`。

## 2. Decision

### 2.1 v2 tag 携带生产它的 pipeline epoch，且在锚覆盖之内

三个 cache 的 tag 从 `normalized:v1` 演进为 `normalized:v2:<epoch>`（provenance/diagnostics 同形）。
epoch 放在**锚覆盖的文本内部**而不是信封新字段：一个谎报的 epoch 必须是**可篡改检测的**——放信封里
则「把旧 cache 标成新 epoch」不触动任何摘要，正好把陈旧洗成新鲜。

`caly_pipeline::stage::PIPELINE_EPOCH` 成为唯一比较点（原三处硬编码 `1` 收敛到它）。本 build 写
`v2:<PIPELINE_EPOCH>`。

### 2.2 读时前向迁移：v1 ⇒ epoch 1，不重写

读取是**前向迁移**的：

- `v1` tag 解码为 **epoch 1**。这不是默认值方便，是历史事实：v1 tag 只被 epoch-1 的 build 写过，
  所以「v1 ≡ epoch 1」是演绎，不是猜测。迁移**纯内存**：摘要锚继续校验**盘上的 v1 字节**（锚先算、
  迁移后行——顺序写进代码），下次 update 在同一原子提交里以当前 tag 重写并重算锚。启动不做全量重写
  （没有写放大，也没有「迁移到一半」的中间态）。
- 未知 tag（`v3`、坏形状、别的家族）**按名拒绝启动**：拒绝语同时含找到的 tag 与支持列表
  （RFC-0007 §12.3：新代码不得静默把未知旧 schema 当当前 schema 用；旧代码遇到新 schema 同理）。

### 2.3 三 cache 的 epoch 必须一致；陈旧是降级不是砖死

一条记录是一次原子提交、一次 pipeline 运行——三个 cache 声称三个不同 epoch 不是任何 build 写过的形状，
**拒绝**（指名三个值），不猜该信谁。

epoch ≠ 当前（`CacheRecency::Stale`）**不是损坏**：endpoint 注册与 raw CAS 事实照常恢复（locator 失效、
CAS root、原子提交都保持），但旧 epoch 的 normalization **不进** `restored_sources()`（引擎不得把旧管线
产物当当前输入）。代价如实话写明：该源的下次 update 是全量重取（条件请求验证子 riding 在被跳过的
cache 上——在 304 上复用陈旧 normalization 正是本 ADR 要堵的洞）。陈旧的 cache 想再变当前，靠下一次
update 以当前 epoch 重写，不靠启动时的批量改写。`sources.inspect` 是**记录的投影**（带时间戳的事实），
不咨询 recency——消费闸门在引擎侧。

### 2.4 与布局层的分工

布局变化（目录搬家、文件格式换代）继续走 `caly-storage::schema` 的迁移链与回退点（§12.2 的备份义务
属于整目录改写）；本 ADR 只管**记录内 opaque cache 的语义版本**——它不需要备份，因为迁移不落盘。
两层各自演进，不共享版本号（RFC-0007 §12.1 的版本分离原则）。

## 3. Alternatives considered

- **启动时批量改写 v1 记录为 v2**：否决——写放大、引入「迁移到一半」的崩溃窗口，而读时迁移零风险
  （锚仍护着盘上字节）；下次 update 的原子提交本来就是自然的重写点。
- **epoch 放信封可选字段**：否决——不在锚覆盖内，谎报不可检测（见 §2.1）。
- **陈旧 cache 直接拒启**：否决——把「演进」当「损坏」处理会砖掉每个升级过的数据目录；损坏（锚不对、
  身份不符、epoch 互斥）才拒启。
- **陈旧 cache 静默继续用**：否决——这正是缺口本身：锚全对但语义已旧。
- **为未来可能的字段先建通用迁移框架**：否决——本 ADR 只实现今天有真实消费者的机制（epoch 身份），
  tag 文法（`v2:<n>`）已给下一个语义版本留了位置，届时加一个解码分支即可，不需要框架。

## 4. Consequences

- 裁判：e2e 三胎（`source_durable.rs`：v1 反砖+恢复为当前 / epoch-9 陈旧不进引擎且 worker 照常起 /
  未知 tag 按名拒启含支持列表）+ 单元三胎（v1≡v2:1 值保真 / 未知 tag 四形状按名 / 混合 epoch 拒绝且
  一致陈旧降级）+ 既有损坏参数化裁判全保绿（锚校验路径未动）。
- 证伪四变异：M1 v1 读作当前 epoch（反砖 e2e 的 epoch 断言红——但需配合 epoch≠1 才可判，故形状为
  「迁移填 0」由值保真单测红）、M2 未知 tag 当 v1（按名 e2e 红）、M3 陈旧照常消费（陈旧 e2e 红）、
  M4 锚改在迁移后的重编码上算（v1 反砖 e2e 红）。
- 残余（登记）：`sources.inspect` 不暴露 recency（用户面「你的 cache 是旧管线产物」提示属 wire 面
  扩展，另轮）；陈旧源的「从 CAS 复用 raw 重规范化而不重取」的优化未做（全量重取是诚实代价）；
  job-log 记录未带记录级版本（其信封加性演进已有 `failure_code` 先例，届时按需）。
