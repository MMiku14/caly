# ADR-040: `ByteStream` 的 label 是调用方自己的名字（宿主路径不出沙箱）

- Status: Accepted（第三十七轮落地：std 宿主路径泄漏封死、fs label 两后端同语义且由共享契约判、
  fetch label 钉形；"真读取器"显式推迟——无消费者即无能力，见 §3）
- Date: 2026-08-29
- Decision-Makers: Caly 接续开发方（维护者已把此类裁决交由此方自行决定，见 `ADR-035 §6bis`）
- Related-RFCs: RFC-0006（`§15` 双后端同套契约；VPath 沙箱的教义见 `docs/ONBOARDING_NOTES.md`
  处置表与 `caly_io::VPath` 的文档，不以编号引用不存在的 RFC）
- Supersedes: None（`ByteStream { label }` 自三十一轮起以"形状待决"结转，本 ADR 是那次结转的裁决）

---

## 1. Context

`caly_io::ByteStream { label: String }` 是 Fs `open_stream` 与 Http `fetch` 的返回载体。三十一轮
审查它时记下"形状 ADR 待做"，结转至今。本轮实测使用面后发现三个事实：

1. **`open_stream` 零生产调用方**——只有共享契约碰它（判在册文件开流成功、缺失文件 `NotFound`）；
   没有任何代码从 `ByteStream` 里读过数据，因为它根本不是读取器：没有 chunk、没有 poll、没有
   关闭语义，只有一个字符串。
2. **std 把宿主绝对路径递回了端口外**：`caly-io-std` 的 `open_stream` 返回
   `ByteStream { label: <resolve 后的宿主路径> }`。VPath 沙箱存在的唯一理由就是把宿主路径关在
   端口层之内（`resolve` 的职责），这一行把它整个 undone。sim 返回的是 vpath 相对键——同一调用，
   两后端两种语义，共享契约对此**沉默**（只判 Ok/Err，不看返回值）。
3. **fetch 的 label 取自脚本条目**（`response.url`）而非请求（`req.url`）。因 sim 按
   `response.url == req.url` 匹配脚本，两者行为不可分——但归属方向是错的：label 说的是"谁回答
   了"，而调用方需要的是"我要的是什么"。

## 2. Decision

**label 是调用方自己给资源的名字，绝不是宿主或后端 internals 的名字。**

- Fs `open_stream`：label == 请求路径的 `as_relative_path()` 渲染，**两后端同一规则**；宿主
  路径留在 `resolve` 所在的沙箱内（拒绝消息与 `resource` 字段仍可用它——那是留在端口内的
  诊断，不是返回值）。
- Http `fetch`：label == `"http:{req.url}"`（前缀说明这是哪一种名字；sim 是唯一实现，形状钉死，
  将来第二个后端必须同形，否则端口类型是谎言）。
- `ByteStream` 保持**句柄标签**的诚实形状：它不是读取器，类型文档照实说。**真读取器（分块、
  poll、关闭语义）显式推迟**，直到存在真实消费者；届时它是新决策，且必须随调用方的预算与期限
  走（`ADR-039` 的教义：能力与裁判同生，`§4.86` 一族：绝不借在场值凑数）。

## 3. 被否决的备选

- **现在就把 `ByteStream` 改成真 poll 读取器**（`Drive` 形状）：零消费者。无消费者的能力无法
  裁判，先造形状正是本仓反复记档的病灶（`§4.86`/`§4.134`）。
- **删掉 `open_stream`**：端口签名由 RFC-0006 冻结，且存在性探针本身有契约重量（缺失文件必须
   `NotFound`——这正是本轮泄漏得以被发现的原因：契约在用它）。删除是更大的手术，收益是负的。
- **label 改为 `Option<String>` 或删字段**：字段是句柄身份的最小载体；把"含义错了"修成
  "没有含义"不是修复。

## 4. 落地记录（第三十七轮）

- `crates/caly-io/src/port.rs`：类型文档钉规则（调用方的名字 / 不是读取器 / 真读取器=新 ADR
  且带 ctx 预算与期限）。
- `crates/caly-io-std/src/lib.rs`：`open_stream` label 改 `path.as_relative_path()`，注释写明
  宿主路径为何必须留在沙箱内。
- `crates/caly-io-sim/src/port_impl.rs`：fetch label 改 `req.url`（归属方向反转）。
- 裁判三处：共享契约 `fs_contract_violations` 现在**判返回值**（label == 请求路径渲染——
  这同时咬"两后端都空"的形状：parity 相等不是充分条件，相等**于正确值**才是）；std 侧
  `open_stream_label_carries_no_host_path`（宿主根不出现在任何端口值——只有 std 测试知道宿主根，
  裁判放它那里）；sim 侧 `fetch_body_label_names_the_request_in_a_pinned_shape`（钉 `"http:"`
  前缀形）。契约 555 → **557**。
- 证伪：`scripts/falsify_round37.py` 4 条全咬（宿主路径回归 / 两后端同空——parity 豁免不了的
  形状 / sim 单侧漂移 / fetch 失形）。
- **第四十二轮补记**：`StdHttp` 落地为 `Http` 的**第二个后端**（真 socket、纯 HTTP/1.1、
  `https` 以教义点名拒），共享 fetch 契约（`caly_io::contract::http_fetch_contract_violations`）
  两后端同跑——§5 的"第二个后端必须同形，否则端口类型是谎言"自此有牙齿：label 前缀
  `http:`（端口名，非 scheme）在两侧同判。

## 5. Consequences

- 端口值类型从此有一条可判的语义：**名字归属**。任何把宿主、脚本、后端 internals 塞进返回
  值的改动会被契约咬住，而不是靠 review。
- 真读取器落地之日（例如 core 下载需要分块），此 ADR 的"推迟"条款即为前置引用：新形状必须
  带 `IoContext` 的预算与期限，且先有消费者与裁判。
