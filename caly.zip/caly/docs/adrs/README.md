# Caly ADR Index

本目录用于记录 Caly 的架构决策记录（ADR）。

RFC 负责定义“系统必须是什么”，ADR 负责说明“为什么定成这样”。两者互补，但权威性不同：

```text
RFC > ADR > implementation note
```

---

## 1. 当前状态

当前已完成核心 ADR 的抽取，基本覆盖 Caly v1 架构骨架中的关键决策。

建议策略：

- RFC 先冻结边界
- ADR 再解释关键设计取舍
- 后续若 RFC 发生重大变更，应同步检查对应 ADR 是否需要更新或废弃

---

## 2. 已抽取 ADR

| ADR | 标题 | 关联 RFC | 状态 |
|---|---|---|---|
| ADR-011 | 纯内核 / 效果描述 / 单一 IO 网关 | RFC-0001 / RFC-0003 / RFC-0005 / RFC-0006 | Accepted |
| ADR-012 | EffectPlan 为一等对象；dry-run 与 explain 复用同一计划 | RFC-0005 | Accepted |
| ADR-013 | IO 按 C1–C6 分类，各自独立有界执行域 | RFC-0001 / RFC-0006 / RFC-0008 | Accepted |
| ADR-014 | 持久化分 D0–D3，按对象显式声明耐久语义 | RFC-0005 / RFC-0006 / RFC-0007 | Accepted |
| ADR-015 | 管线为 DAG + digest 记忆化；缓存仅加速，不改变语义 | RFC-0001 / RFC-0003 / RFC-0004 | Accepted |
| ADR-016 | VerifyGate 属于 IO 阶段，并按二进制摘要缓存结果 | RFC-0003 / RFC-0006 | Accepted |
| ADR-017 | CalyApi 为唯一门面，LocalApi/RemoteApi 共享 DTO 语义 | RFC-0001 / RFC-0002 | Accepted |
| ADR-018 | 写操作一律 Job 化；同步体验由前端组合而成 | RFC-0002 / RFC-0005 | Accepted |
| ADR-019 | 流具有显式投递策略，Reset 是一等协议语义 | RFC-0002 / RFC-0008 | Accepted |
| ADR-020 | 错误在门面边界归一化，并在该处完成脱敏 | RFC-0002 / RFC-0006 / RFC-0010 | Accepted |
| ADR-021 | Ctx 携带 deadline/cancel/budget，并贯穿到每个 Port 调用 | RFC-0002 / RFC-0006 / RFC-0010 | Accepted |
| ADR-022 | 确定性仿真是 PR 级门禁，而不是可选附加测试 | RFC-0001 / RFC-0005 / RFC-0006 / RFC-0007 | Accepted |
| ADR-023 | 功能支持分为 CalyManaged / NativeManaged / OpaquePreserved | RFC-0001 / RFC-0004 / RFC-0009 | Accepted |
| ADR-024 | Capability Registry 是功能支持事实的唯一来源，并必须绑定证据 | RFC-0004 / RFC-0008 | Accepted |
| ADR-025 | 顶层门面按 Facet 拆分，禁止演化为 God Interface | RFC-0002 | Accepted |
| ADR-026 | Facet 统一映射到 Operation Envelope，Local/Remote 共享协议语义 | RFC-0002 | Accepted |
| ADR-027 | Query / Command / Stream 是唯一三类对外交互语义 | RFC-0002 | Accepted |
| ADR-028 | Event 只用于通知；显式 Coordinator 负责编排 | RFC-0001 / RFC-0002 / RFC-0005 | Accepted |
| ADR-029 | 外部 Core / 平台 / 订阅格式必须经 Anti-Corruption Layer 隔离 | RFC-0001 / RFC-0003 / RFC-0004 / RFC-0008 | Accepted |
| ADR-030 | 结构化 Profile Patch 是唯一合法配置修改入口 | RFC-0001 / RFC-0009 | Accepted |
| ADR-031 | 自动化采用受限声明式 DSL，而不是任意脚本引擎 | RFC-0001 | Accepted |
| ADR-032 | 不加载动态 Rust 插件；未来扩展优先采用隔离 Provider Process | RFC-0001 / RFC-0010 | Accepted |
| ADR-033 | API / IR / Storage / Core Compatibility / Pipeline Epoch 必须独立演进 | RFC-0001 / RFC-0002 / RFC-0003 / RFC-0007 | Accepted |
| ADR-034 | 本地 IPC 采用 framed JSON over UDS / Named Pipe；gRPC 与 HTTP 作为未来桥接层 | RFC-0002 | Accepted |
| ADR-035 | `Fs` Port 增加目录列举与 mtime，并冻结 `runtime_path` 的基准 | RFC-0006 / RFC-0007 | **Accepted**（第 1、2、3 步已全部落地：`list` / 共享契约 / 清单层已删 / 年龄取端口 mtime） |
| ADR-036 | 端口调用需要有界执行器；`Ctx` 的 deadline / cancel / budget 必须被真正执行 | RFC-0001 / RFC-0006 / RFC-0007 / RFC-0008 | **Accepted**（含两处事实修正；第 0 步已落地——typed 驱动器 + 可挂起的仿真端口 + `io_budget` 上线；第 1 步已落地——`BoundedExecutor` 有界准入 + 公平推进 + 注入时钟，尚无生产调用者；第 2 步已落地——命令的 `Ctx` 抵达 apply 的 store 接缝；第 3 步已落地——`IoBudget.max_requests` 由引擎计费、默认值收窄并写进 `IMPLEMENTATION_STATUS §6bis`；`§2.5` 的探针时限第二十六轮落地（判定在执行器、0 预算在计划校验处拒，见 `§6bis-septies`）；第 2 步剩下的逐步游标第二十七轮落地（`§6bis-octies`：cutover 窗口先记账后动手、一条命令一个预算计数器、`OVERLOAD_AND_RETRY_MODEL §6.2` 三条要求各有裁判）；`§1` 表里最后一行 `io_budget.max_bytes` 已于第二十九轮由端口执行（`§6bis-decies`，形状是单次上限而非累计，偏离写在同一节）；`§6bis-quinque` 挂着的「查询侧是否接限制」已于第三十轮判完并落地（诊断查询有响应上界且报告截断，落点 `caly-daemon/src/paging.rs`；「按调用方接预算」被论证为不需要）；第 4 步的阻塞池与 `Proc` 仍未开始） |
| ADR-037 | Command 的幂等、CAS 与角色上下文由谁提供 | RFC-0002 / RFC-0005 / RFC-0010 | **Accepted**（已落地；三处偏离见其 §2bis） |
| ADR-038 | 存储回收的计划先于删除落地，并把 `required_role` 变成读侧也生效的门禁 | RFC-0002 / RFC-0007 / RFC-0010 | **Accepted**（第 1、2 步与第 3 步的时钟侧已落地：`list_revisions` / `system.gc-plan` / `system.gc-collect` / `sweep_objects` / root 集全有或全无 / 读侧角色门禁；`§13.2` 的 idle 自动触发第二十五轮落地——默认关闭、由 role-gated `AutomationPatch(gc.idle)` 打开，四步全部落地，策略见其 §9） |

对应文件：

- `ADR-011-pure-core-effect-plan-io-gateway.md`
- `ADR-012-effect-plan-as-first-class.md`
- `ADR-013-io-classification-and-bounded-execution-domains.md`
- `ADR-014-explicit-durability-tiers-d0-d3.md`
- `ADR-015-pipeline-dag-and-digest-memoization.md`
- `ADR-016-verifygate-is-io-stage-and-cached-by-binary-digest.md`
- `ADR-017-single-facade-local-remote-shared-dto.md`
- `ADR-018-write-operations-are-jobs-sync-is-frontend-composed.md`
- `ADR-019-streams-have-explicit-delivery-policies-and-reset-is-first-class.md`
- `ADR-020-errors-are-normalized-and-redacted-at-facade-boundary.md`
- `ADR-021-ctx-carries-deadline-cancel-budget-through-all-ports.md`
- `ADR-022-deterministic-simulation-is-a-pr-gate.md`
- `ADR-023-support-levels-managed-native-opaque.md`
- `ADR-024-capability-registry-as-single-source-of-truth.md`
- `ADR-025-facade-is-decomposed-into-facets-not-god-interface.md`
- `ADR-026-facets-map-to-operation-envelope-shared-across-local-and-remote.md`
- `ADR-027-query-command-stream-are-the-only-external-interaction-modes.md`
- `ADR-028-events-not-choreography-coordinator-orchestrates.md`
- `ADR-029-anti-corruption-layer-for-core-platform-and-subscription-worlds.md`
- `ADR-030-structured-profile-patch-is-the-only-config-mutation-entry.md`
- `ADR-031-automation-uses-restricted-declarative-dsl.md`
- `ADR-032-no-dynamic-rust-plugins-use-isolated-provider-processes.md`
- `ADR-033-version-lines-evolve-independently.md`
- `ADR-034-local-ipc-uses-framed-json-grpc-http-are-bridges.md`
- `ADR-035-fs-port-listing-and-path-bases.md`（Accepted；三步全已落地——`list` / `mtime` / 共享契约、清单层已删、回退点抄记录、对象年龄改取端口 mtime；遗留是 `stat_many` 与 GC 尚无生产调用者）
- `ADR-036-bounded-port-executor-and-enforced-ctx-limits.md`（Accepted；第 0 步已落地：`drive` / `CancelToken` / `hang` 注入 / envelope 的 `io_budget`；第 1 步已落地：`BoundedExecutor`（有界准入、公平推进、时钟注入、**不制造进展也不重试**）；第 2 步已落地：`RunLimits` + `run_ready_in` 让 apply 的第一次 store 写入 obey 命令的 `Ctx`，并且定下"记录已发生之事不可被拒"；第 3 步已落地：`default_command()` + `run_ready_in` 计费 + `BudgetExhausted`（`max_bytes` 仍不生效，理由写在 `§6bis-sexies`）；第 2 步剩下的逐步游标已落地：`EffectCursor` 把 cutover 窗口的意图记录放在那一步之前，写不下去就 refuse 那一步（`§6bis-octies`）；阻塞池与 `Http`/`Proc` 仍未做）
- `ADR-038-storage-gc-plan-and-role-gate-on-reads.md`（Accepted；第 1、2 步已落地——`list_revisions`、
  `system.gc-plan`（只报告）、`system.gc-collect`（真删，且只删它刚报告的那份清单）、`StorageBusy` 的第一个
  生产者；第 3 步的时钟注入落在引擎侧；`§13.2` 的 idle 自动触发也已落地（默认关闭 + 单调检查计数 + `triggered_by` 归属，见其 §9）；
  `system.gc-plan`、root 集全有或全无、读与流执行 `required_role`；删除任务与时钟注入未做）
- `ADR-037-command-idempotency-cas-and-role-context.md`（Accepted，第十四轮已落地）

---

## 3. 下一步建议

虽然核心 ADR 已补齐，但文档体系仍可继续增强：

1. 为每份 RFC 增加 `Related ADRs` 小节
2. 增加 `docs/ERRORS.md` 与 `docs/EXIT_CODES.md`
3. 增加 `docs/IMPLEMENTATION_STATUS.md`
4. 为 RFC 与 ADR 建立交叉引用索引表
5. 将 Accepted ADR 提炼成一页“架构原则总表”

---

## 4. ADR 编写要求

每份 ADR 至少回答：

1. 背景是什么？
2. 决策是什么？
3. 为什么不是其他方案？
4. 会带来什么后果？
5. 对哪些 RFC 有影响？

模板见：

- `docs/adrs/ADR-TEMPLATE.md`

---

## 5. 一句话原则

> RFC 冻结边界，ADR 解释边界。没有 ADR，边界会失去来由；没有 RFC，边界会失去约束。