# Caly ADR Index

本目录用于记录 Caly 的架构决策记录（ADR）。

RFC 负责定义“系统必须是什么”，ADR 负责说明“为什么定成这样”。两者互补，但权威性不同：

```text
RFC > ADR > implementation note
```

---

## 1. 当前状态

当前已完成核心 ADR 的抽取，基本覆盖 Caly v1 架构骨架中的关键决策。

建议策略：

- RFC 先冻结边界
- ADR 再解释关键设计取舍
- 后续若 RFC 发生重大变更，应同步检查对应 ADR 是否需要更新或废弃

---

## 2. 已抽取 ADR

| ADR | 标题 | 关联 RFC | 状态 |
|---|---|---|---|
| ADR-011 | 纯内核 / 效果描述 / 单一 IO 网关 | RFC-0001 / RFC-0003 / RFC-0005 / RFC-0006 | Accepted |
| ADR-012 | EffectPlan 为一等对象；dry-run 与 explain 复用同一计划 | RFC-0005 | Accepted |
| ADR-013 | IO 按 C1–C6 分类，各自独立有界执行域 | RFC-0001 / RFC-0006 / RFC-0008 | Accepted |
| ADR-014 | 持久化分 D0–D3，按对象显式声明耐久语义 | RFC-0005 / RFC-0006 / RFC-0007 | Accepted |
| ADR-015 | 管线为 DAG + digest 记忆化；缓存仅加速，不改变语义 | RFC-0001 / RFC-0003 / RFC-0004 | Accepted |
| ADR-016 | VerifyGate 属于 IO 阶段，并按二进制摘要缓存结果 | RFC-0003 / RFC-0006 | Accepted |
| ADR-017 | CalyApi 为唯一门面，LocalApi/RemoteApi 共享 DTO 语义 | RFC-0001 / RFC-0002 | Accepted |
| ADR-018 | 写操作一律 Job 化；同步体验由前端组合而成 | RFC-0002 / RFC-0005 | Accepted |
| ADR-019 | 流具有显式投递策略，Reset 是一等协议语义 | RFC-0002 / RFC-0008 | Accepted |
| ADR-020 | 错误在门面边界归一化，并在该处完成脱敏 | RFC-0002 / RFC-0006 / RFC-0010 | Accepted |
| ADR-021 | Ctx 携带 deadline/cancel/budget，并贯穿到每个 Port 调用 | RFC-0002 / RFC-0006 / RFC-0010 | Accepted |
| ADR-022 | 确定性仿真是 PR 级门禁，而不是可选附加测试 | RFC-0001 / RFC-0005 / RFC-0006 / RFC-0007 | Accepted |
| ADR-023 | 功能支持分为 CalyManaged / NativeManaged / OpaquePreserved | RFC-0001 / RFC-0004 / RFC-0009 | Accepted |
| ADR-024 | Capability Registry 是功能支持事实的唯一来源，并必须绑定证据 | RFC-0004 / RFC-0008 | Accepted |
| ADR-025 | 顶层门面按 Facet 拆分，禁止演化为 God Interface | RFC-0002 | Accepted |
| ADR-026 | Facet 统一映射到 Operation Envelope，Local/Remote 共享协议语义 | RFC-0002 | Accepted |
| ADR-027 | Query / Command / Stream 是唯一三类对外交互语义 | RFC-0002 | Accepted |
| ADR-028 | Event 只用于通知；显式 Coordinator 负责编排 | RFC-0001 / RFC-0002 / RFC-0005 | Accepted |
| ADR-029 | 外部 Core / 平台 / 订阅格式必须经 Anti-Corruption Layer 隔离 | RFC-0001 / RFC-0003 / RFC-0004 / RFC-0008 | Accepted |
| ADR-030 | 结构化 Profile Patch 是唯一合法配置修改入口 | RFC-0001 / RFC-0009 | Accepted |
| ADR-031 | 自动化采用受限声明式 DSL，而不是任意脚本引擎 | RFC-0001 | Accepted |
| ADR-032 | 不加载动态 Rust 插件；未来扩展优先采用隔离 Provider Process | RFC-0001 / RFC-0010 | Accepted |
| ADR-033 | API / IR / Storage / Core Compatibility / Pipeline Epoch 必须独立演进 | RFC-0001 / RFC-0002 / RFC-0003 / RFC-0007 | Accepted |
| ADR-034 | 本地 IPC 采用 framed JSON over UDS / Named Pipe；gRPC 与 HTTP 作为未来桥接层 | RFC-0002 | Accepted |
| ADR-035 | `Fs` Port 增加目录列举与 mtime，并冻结 `runtime_path` 的基准 | RFC-0006 / RFC-0007 | **Accepted**（第 1、2、3 步已全部落地：`list` / 共享契约 / 清单层已删 / 年龄取端口 mtime） |
| ADR-036 | 端口调用需要有界执行器；`Ctx` 的 deadline / cancel / budget 必须被真正执行 | RFC-0001 / RFC-0006 / RFC-0007 / RFC-0008 | **Accepted**（含两处事实修正；第 0 步已落地——typed 驱动器 + 可挂起的仿真端口 + `io_budget` 上线；第 1 步已落地——`BoundedExecutor` 有界准入 + 公平推进 + 注入时钟，尚无生产调用者；第 2 步已落地——命令的 `Ctx` 抵达 apply 的 store 接缝；第 3 步已落地——`IoBudget.max_requests` 由引擎计费、默认值收窄并写进 `IMPLEMENTATION_STATUS §6bis`；`§2.5` 的探针时限第二十六轮落地（判定在执行器、0 预算在计划校验处拒，见 `§6bis-septies`）；第 2 步剩下的逐步游标第二十七轮落地（`§6bis-octies`：cutover 窗口先记账后动手、一条命令一个预算计数器、`OVERLOAD_AND_RETRY_MODEL §6.2` 三条要求各有裁判）；`§1` 表里最后一行 `io_budget.max_bytes` 已于第二十九轮由端口执行（`§6bis-decies`，形状是单次上限而非累计，偏离写在同一节）；`§6bis-quinque` 挂着的「查询侧是否接限制」已于第三十轮判完并落地（诊断查询有响应上界且报告截断，落点 `caly-daemon/src/paging.rs`；「按调用方接预算」被论证为不需要）；第 4 步的通用阻塞池/transport runtime 仍未开始；`StdProc` 已有独立 spawn/try_wait/stop slice；第六十三轮 source slice 又接入 Std/Sim Http 共享 caller phase-boundary control） |
| ADR-037 | Command 的幂等、CAS 与角色上下文由谁提供 | RFC-0002 / RFC-0005 / RFC-0010 | **Accepted**（已落地；三处偏离见其 §2bis） |
| ADR-038 | 存储回收的计划先于删除落地，并把 `required_role` 变成读侧也生效的门禁 | RFC-0002 / RFC-0007 / RFC-0010 | **Accepted**（第 1、2 步与第 3 步的时钟侧已落地：`list_revisions` / `system.gc-plan` / `system.gc-collect` / `sweep_objects` / root 集全有或全无 / 读侧角色门禁；`§13.2` 的 idle 自动触发第二十五轮落地——默认关闭、由 role-gated `AutomationPatch(gc.idle)` 打开，四步全部落地，策略见其 §9） |
| ADR-039 | 把调用方的 Context 送进 store 接缝（对 RFC-0007 冻结签名的修订） | RFC-0002 / RFC-0006 / RFC-0007 | **Accepted**（第 1 步第三十三轮：23 个方法带 `ctx`、伪造 ctx 删除、`Cancelled` 门与归属真实化有裁判；第 2 步预算、第 3 步时限第三十四/三十五轮——第 3 步实证推翻"ADR-013 有界池"前提；第 4 步门面穿透第三十六轮，引擎幽灵 ctx 移除、端到端裁判 `facade_store_ctx.rs`；四步全落地） |
| ADR-040 | `ByteStream` 的 label 是调用方自己的名字——宿主路径不出沙箱，真读取器显式推迟 | RFC-0006 | **Accepted**（第三十七轮落地：std `open_stream` 宿主路径泄漏封死、fs label 两后端同语义且共享契约判返回值、fetch label 钉 `http:{req.url}` 形；裁判 3 处，证伪 4/4） |
| ADR-041 | 存储记录文件名的单射转义——两个名字不许共用一个文件 | RFC-0007 / ADR-035 / ADR-038 | **Accepted**（第三十九轮落地：`sanitize` 压平→`escape_component` 百分转义六处统一、boot 校验文件名==digest 会占据的名字、别名 get/delete 与静默互覆与两后端分歧全封死；裁判 3 处、证伪 4/4；第四十二轮 `StdHttp` 落地为第二后端、共享 fetch 契约两后端同判 label 形） |
| ADR-042 | 进程生成经 `Proc` 网关（`StdProc`），`Platform` 特权面不落 std | RFC-0006 / ADR-011 / ADR-022 / ADR-035 | **Accepted**（第五十三轮落地：`Command::new` 禁令按 `caly-io-std/clippy.toml` 先例定点豁免、shell-free + cwd 网关根 + stdio null + ENOENT 预查归因、`SimProc` 对齐空程序名拒绝、共享 spawn 契约两后端同判——契约表第 4 条补齐载体；`Platform` 是决策性缺席不是欠账；裁判 5 处） |
| ADR-043 | `Proc` 最小 supervision 面（`try_wait`/`stop`），TERM 决策显式推迟 | RFC-0006 / ADR-013 / ADR-022 / ADR-042 | **Accepted**（第五十四轮落地：`ChildExit{code,signaled}` 不压平、退出单调回放、宽限=自然退出窗口期满 SIGKILL（std 唯一信号，`/bin/kill` 间接触发被否决存档）、端口负责 reap、仿真侧可编排自然退出；真内核+geo 资产入工作区并由 digest 钉死；裁判 7 处） |
| ADR-044 | 真 effect backend 第一条纵向切片（资产校验、物化、spawn、probe、stop） | RFC-0005 / RFC-0006 / RFC-0007 / ADR-011 / ADR-022 | **Accepted**（第五十五/五十六轮落地；真实 mihomo/geo 资产、CAS/物化/进程生命周期经同一 executor 与端口判定） |
| ADR-045 | Rollback 必须复活目标 deployment，而非只撤销当前 deployment | RFC-0005 / RFC-0007 / ADR-044 | **Accepted**（第五十七轮落地；按 snapshot 记录的 core identity 复活，且同 profile 重试判 Noop） |
| ADR-046 | sing-box 第二核心 spawn face 与结构化 JSON envelope | RFC-0005 / RFC-0006 / ADR-044 | **Accepted**（第五十八轮落地；tar.gz digest、结构合并、clash-api、wg passthrough 约束） |
| ADR-047 | Http 路由诚实化：ActiveCore 真实经 mixed inbound | RFC-0006 / ADR-040 / ADR-046 | **Accepted**（第五十九轮落地；三档路由、活核 route source、InboundListening 探针、凭据边界） |
| ADR-048 | SystemProxy 真实现、Direct 模式路由、wg passthrough 覆盖 | RFC-0006 / ADR-047 / ADR-046 | **Accepted**（第六十轮落地；三档路由收齐、sing-box direct 真骑乘、真凭据覆盖） |
| ADR-049 | Http 以有界拥有字节承载响应体，不提前伪造读取器 | RFC-0003 / RFC-0006 / RFC-0007 | **Accepted**（第六十一轮决策、第六十二轮落地 durable source index；第六十三轮接入 Std/Sim 共享 caller deadline anchoring、source phase-boundary cancellation/deadline 与 durable inspection projection/redaction；`StdHttp` 单个 blocking syscall 的即时中断仍是明确边界） |
| ADR-050 | `calyd` 真实 effect runtime 的显式组合根配置 | RFC-0001 / RFC-0005 / RFC-0006 / RFC-0007 / RFC-0010 | **Accepted**（第六十四轮落地：real-only CLI 选择、显式 runtime/assets roots、可读/可写 preflight、startup/apply 失败语义；默认仍 simulated） |
| ADR-051 | Capability Registry JSON 工件是导出物，不是运行时输入物 | RFC-0004 / ADR-024 | **Accepted**（第六十八轮收口：工件由代码生成并由 drift 门禁钉住；生产代码不得从工件读取） |
| ADR-052 | Blocking syscall 的中断/回收语义（诚实边界 + 有界回收） | RFC-0006 / ADR-013 | **Accepted**（第七十二轮收口：语义定义先行，不依赖具体 transport；对端挂起有界回收 + 不可中断诚实性裁判） |
| ADR-053 | SSRF 网络访问边界（RFC-0010 §11.1 的实现决策） | RFC-0010 / RFC-0006 | **Accepted**（第七十三轮收口：连接后 peer 校验、FetchScope 保守默认/显式放行、ActiveCore 豁免） |
| ADR-054 | `Fs::stat_many` 批量 stat 面（ADR-035 登记的下一步） | RFC-0006 / RFC-0007 / ADR-035 | **Accepted**（第七十四轮收口：批量面 + `object_records` 单次批量定年，契约等价 + 计数裁判） |
| ADR-055 | 外部 init 系统（systemd）监督 `calyd`，`calyd` 继续监督 Core —— 两层监督边界 | RFC-0005 / ADR-044 | **Accepted**（第一百轮落地：systemd unit 工件 + 部署 runbook + 结构门禁；核心不得做成独立 unit） |
| ADR-056 | `calyd` 的信号面（SIGTERM/SIGINT 优雅关停） | RFC-0005 / ADR-055 | **Accepted**（第一百零二轮落地：pthread_sigmask + sigwait、StdEffectRuntime::shutdown(10s)、exit 0） |
| ADR-057 | 部署作业事件的持久化（Job Log Durability） | RFC-0002 / RFC-0005 / RFC-0007 | **Accepted**（切片 1/2/4 已落地：存储 primitive、引擎终态写入+启动恢复、真二进制 kill-9 重启 e2e 与 GC 不碰历史裁判；切片 3 剩 support bundle 收录作业轨迹） |
| ADR-058 | 流式 END 帧携带作业的公共失败码（failure_code） | RFC-0002 / RFC-0005 | **Accepted**（第一百一十六轮落地：failed 终局可选 `failure_code`、只属 failed、缺失→1/未识别→13/已识别→该码号；三条路径同一退出码；纯字段可加、无版本与 journal 迁移） |
| ADR-059 | UDS 对端探测经 MSG_PEEK（隔离 FFI crate） | ADR-043 / ADR-056 / TRANSPORT_RUNTIME_MODEL | **Accepted**（第一百二十三轮落地：`caly-uds-peek` 手写四行 FFI 零依赖、caly-ipc 保持 forbid(unsafe_code)；UDS 死对端探测与 TCP 同级；Unknown/非 Linux 如实 Indeterminate 不发明关闭） |
| ADR-060 | 崩溃恢复的跨进程 core adoption（凭据 + 身份三要素 + 可停的接管） | RFC-0005 §12 / ADR-043 / ADR-050 / ADR-056 | **Accepted**（第一百二十五轮落地：durable core receipt + pid/start_time 身份 + 接管/按名拒绝/冷收敛 + bin 内 pidfd foreign stop；绝不向身份不匹配的进程发信号） |
| ADR-061 | durable source index 的 cache tag 演进与读时前向迁移 | RFC-0003 / RFC-0007 §12 / ADR-049 | **Accepted**（第一百二十六轮落地：v2 tag 携带 pipeline epoch 且在锚覆盖内、v1≡epoch 1 纯内存迁移、未知 tag 按名拒启、陈旧降级不砖死） |

对应文件：

- `ADR-011-pure-core-effect-plan-io-gateway.md`
- `ADR-012-effect-plan-as-first-class.md`
- `ADR-013-io-classification-and-bounded-execution-domains.md`
- `ADR-014-explicit-durability-tiers-d0-d3.md`
- `ADR-015-pipeline-dag-and-digest-memoization.md`
- `ADR-016-verifygate-is-io-stage-and-cached-by-binary-digest.md`
- `ADR-017-single-facade-local-remote-shared-dto.md`
- `ADR-018-write-operations-are-jobs-sync-is-frontend-composed.md`
- `ADR-019-streams-have-explicit-delivery-policies-and-reset-is-first-class.md`
- `ADR-020-errors-are-normalized-and-redacted-at-facade-boundary.md`
- `ADR-021-ctx-carries-deadline-cancel-budget-through-all-ports.md`
- `ADR-022-deterministic-simulation-is-a-pr-gate.md`
- `ADR-023-support-levels-managed-native-opaque.md`
- `ADR-024-capability-registry-as-single-source-of-truth.md`
- `ADR-025-facade-is-decomposed-into-facets-not-god-interface.md`
- `ADR-026-facets-map-to-operation-envelope-shared-across-local-and-remote.md`
- `ADR-027-query-command-stream-are-the-only-external-interaction-modes.md`
- `ADR-028-events-not-choreography-coordinator-orchestrates.md`
- `ADR-029-anti-corruption-layer-for-core-platform-and-subscription-worlds.md`
- `ADR-030-structured-profile-patch-is-the-only-config-mutation-entry.md`
- `ADR-031-automation-uses-restricted-declarative-dsl.md`
- `ADR-032-no-dynamic-rust-plugins-use-isolated-provider-processes.md`
- `ADR-033-version-lines-evolve-independently.md`
- `ADR-034-local-ipc-uses-framed-json-grpc-http-are-bridges.md`
- `ADR-035-fs-port-listing-and-path-bases.md`（Accepted；三步全已落地——`list` / `mtime` / 共享契约、清单层已删、回退点抄记录、对象年龄改取端口 mtime；遗留是 `stat_many` 与 GC 尚无生产调用者）
- `ADR-036-bounded-port-executor-and-enforced-ctx-limits.md`（Accepted；第 0 步已落地：`drive` / `CancelToken` / `hang` 注入 / envelope 的 `io_budget`；第 1 步已落地：`BoundedExecutor`（有界准入、公平推进、时钟注入、**不制造进展也不重试**）；第 2 步已落地：`RunLimits` + `run_ready_in` 让 apply 的第一次 store 写入 obey 命令的 `Ctx`，并且定下"记录已发生之事不可被拒"；第 3 步已落地：`default_command()` + `run_ready_in` 计费 + `BudgetExhausted`，`max_bytes` 由端口按单次上限执行；第 2 步剩下的逐步游标已落地：`EffectCursor` 把 cutover 窗口的意图记录放在那一步之前，写不下去就 refuse 那一步（`§6bis-octies`）；`StdProc` 与 `StdHttp` 已有独立 slice，source 另有 Std/Sim 共享 caller phase-boundary control；通用阻塞池/transport runtime 仍未做）
- `ADR-038-storage-gc-plan-and-role-gate-on-reads.md`（Accepted；第 1、2 步已落地——`list_revisions`、
  `system.gc-plan`（只报告）、`system.gc-collect`（真删，且只删它刚报告的那份清单）、`StorageBusy` 的第一个
  生产者；第 3 步的时钟注入落在引擎侧；`§13.2` 的 idle 自动触发也已落地（默认关闭 + 单调检查计数 + `triggered_by` 归属，见其 §9）；
  `system.gc-plan`、root 集全有或全无、读与流执行 `required_role`；删除任务与时钟注入未做）
- `ADR-037-command-idempotency-cas-and-role-context.md`（Accepted，第十四轮已落地）
- `ADR-039-caller-context-at-the-store-seam.md`（Accepted；四步全落地——第 1 步第三十三轮 store 签名
  全链带 ctx、伪造 ctx 删除、`Cancelled` 门与归属真实化；第 2/3 步第三十四/三十五轮（预算计费、
  期限由持时钟方判，且实证推翻"ADR-013 有界池"前提）；第 4 步第三十六轮门面穿透：查询路径
  `caller_ctx`、引擎幽灵 ctx 移除、端到端裁判 `facade_store_ctx.rs`）
- `ADR-040-bytestream-label-is-the-callers-own-name.md`（Accepted；第三十七轮落地——std 的宿主
  路径泄漏封死、fs label 两后端同语义（共享契约判返回值：相等于正确值，不只是 parity）、fetch
  label 钉形；真读取器显式推迟至有消费者）
- `ADR-041-injective-record-name-escaping.md`（Accepted；第三十九轮落地——压平命名（两个合法名
  一个文件：静默互覆/别名命中/两后端分歧/重启不定）换单射百分转义，boot 名↔记录校验拒旧式与
  伪造命名；测试手写的三份压平副本收敛到唯一真源）
- `ADR-042-process-spawn-gateway.md`（Accepted；第五十三轮落地——spawn 与特权面拆开：
  `StdProc` 落 std（shell-free、cwd 网关根、stdio null、缺 cwd 点名 cwd 不赖程序），
  `Platform` 明确不落 std（伪造的能力承诺比缺席更糟）；契约第 4 条有载体的同时
  `RFC-0006 §15` 七条全齐）
- `ADR-043-proc-supervision-minimal-surface.md`（Accepted；第五十四轮落地——`ADR-042`
  预告的「端口生长决策」到来：poll 与带界停止两个方法、退出单调、宽限期属子进程；
  TERM 与 `/bin/kill` 路线的否决理由存档；真 mihomo 与 geo 资产成为工作区钉死物）
- `ADR-044-real-effect-backend-first-slice.md`（Accepted；第五十五/五十六轮真 effect 后端）
- `ADR-045-rollback-revives-target-deployment.md`（Accepted；第五十七轮 rollback 复活目标 deployment）
- `ADR-046-singbox-spawn-face.md`（Accepted；第五十八轮 sing-box spawn 与 JSON envelope）
- `ADR-047-http-route-honesty.md`（Accepted；第五十九轮 ActiveCore 路由）
- `ADR-048-system-proxy-and-direct-mode.md`（Accepted；第六十轮 SystemProxy 与 direct 模式）
- `ADR-049-bounded-http-body-carrier.md`（Accepted；第六十一轮有界 Http body carrier）
- `ADR-050-calyd-real-effect-runtime-composition.md`（Accepted；第六十四轮 `calyd` 真实 effect runtime 显式组合根）
- `ADR-051-capability-registry-artifacts-are-exports.md`（Accepted；第六十八轮工件方向收口）
- `ADR-052-blocking-syscall-interrupt-reclaim.md`（Accepted；第七十二轮阻塞中断/回收语义）
- `ADR-053-ssrf-network-access-boundary.md`（Accepted；第七十三轮 SSRF 边界）
- `ADR-054-fs-stat-many-batch.md`（Accepted；第七十四轮批量 stat 面）
- `ADR-055-external-init-supervises-calyd-two-layer-supervision.md`（Accepted；第一百轮两层监督）
- `ADR-056-graceful-shutdown-signal-surface.md`（Accepted；第一百零二轮信号面）
- `ADR-057-job-event-durability.md`（Accepted；第一百零八/一百零九轮作业事件持久化；2026-09-01 切片 4 裁判落地）
- `ADR-058-stream-end-frame-carries-failure-code.md`（Accepted；第一百一十六轮流式 END failure_code；2026-09-01 落地）
- `ADR-059-uds-peer-probe-via-msg-peek.md`（Accepted；第一百二十三轮 UDS peek；2026-09-02 落地）
- `ADR-060-crash-recovery-core-adoption.md`（Accepted；第一百二十五轮跨进程 core adoption；2026-09-02 落地）
- `ADR-061-cache-tag-evolution-and-read-time-migration.md`（Accepted；第一百二十六轮 cache tag 演进与读时迁移；2026-09-02 落地）

---

## 3. 下一步建议

虽然核心 ADR 已补齐，但文档体系仍可继续增强：

1. 为每份 RFC 增加 `Related ADRs` 小节（未做）
2. ~~增加 `docs/guides/ERRORS.md` 与 `docs/guides/EXIT_CODES.md`~~ **已完成**（二者皆在，且与代码互相裁判）
3. ~~增加 `docs/status/IMPLEMENTATION_STATUS.md`~~ **已完成**（census 由 `scripts/regenerate_test_census.py` 生成）
4. ~~为 RFC 与 ADR 建立交叉引用索引表~~ **已完成**（`docs/engineering/RFC_ADR_CRATE_INDEX.md`）
5. 将 Accepted ADR 提炼成一页「架构原则总表」（未做）

---

## 4. ADR 编写要求

每份 ADR 至少回答：

1. 背景是什么？
2. 决策是什么？
3. 为什么不是其他方案？
4. 会带来什么后果？
5. 对哪些 RFC 有影响？

模板见：

- `docs/adrs/ADR-TEMPLATE.md`

---

## 5. 一句话原则

> RFC 冻结边界，ADR 解释边界。没有 ADR，边界会失去来由；没有 RFC，边界会失去约束。