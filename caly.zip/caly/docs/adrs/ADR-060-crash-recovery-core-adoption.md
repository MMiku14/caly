# ADR-060: 崩溃恢复的跨进程 core adoption（凭据 + 三要素身份 + 可停的接管）

- Status: Accepted（2026-09-02；第一百二十五轮落地）
- Date: 2026-09-02
- Decision-Makers: Caly 接续开发方（维护者已把此类裁决交由此方自行决定，见 `ADR-035 §6bis`）
- Related-ADR: ADR-042（生成与特权分离）、ADR-043（进程 supervision）、ADR-044（真实 effect backend）、
  ADR-050（真实 runtime 组合根，§2.5 显式留下本缺口）、ADR-055（双层监督）、ADR-056（TERM 优雅停机）、
  ADR-057（作业事件持久化）
- Related-RFC: RFC-0005 §12（崩溃恢复规范：§12.2 步骤 5/6、§12.3 孤儿身份、§12.4 收敛性）

---

## 1. Context

ADR-056/第一百二十四轮之后，`calyd` 的**受监督**关停是干净的：SIGTERM → 排空 → 优雅停核 → exit 0。
但监督故事的另一半一直缺着：**daemon 崩溃**（`kill -9`、断电、panic）时优雅路径从未运行，真实核
作为孤儿存活（reparent 给 init），继续占着 controller/mixed 端口。下一个 `calyd` 对此**全盲**：

- `StdEffectRuntime` 的 `LiveInstance` 是进程内存态，没有任何落盘凭据；
- 重启的 daemon 不知道孤儿存在：无 live instance、无 `ActiveCore` 路由、日志无一字；
- 下一次 apply 的 `instance-already-running` 守卫在空状态上不触发——会在孤儿旁再 spawn 第二个核。

这正是 `RFC-0005 §12` 规定而未实现的部分：§12.2 步骤 5/6（旧核存活且身份匹配 → 接管/回滚/冷启动）、
§12.3（pid + start_time + instance_nonce 三者都匹配才可视为同一实例）、§12.4（恢复后必须收敛，不得
停留在「未知但看起来还能用」）。`ADR-050 §2.5` 当时显式登记：「不能用读取 snapshot 或重新 spawn
代替」接管，需要独立的 process identity、attach/recovery 方案和对应裁判。

约束（全部沿用既有裁决）：`caly-io-std` 与 `caly-daemon` lib 均 `forbid(unsafe_code)`；std 的
`Child::kill` 只能杀子进程，**非子进程没有 std 信号面**；ADR-043 §2.5 否决了「生产端口经
`/bin/kill` 触发 TERM」；FFI 先例只存在于 `calyd` bin（`support/signal.rs`，ADR-056）。

## 2. Decision

### 2.1 落盘 core receipt：接管的事实来源

真实 spawn 成功时，runtime 在 `<runtime-root>/core-receipt` 写一行一记录（records 文本，运维可
`grep`）的凭据，成功停核（含补偿与 shutdown）后删除：

```text
version=1
kind=mihomo|sing-box
nonce=spawn-<seq>-pid-<pid>
pid=<核心进程 pid>
start_time=</proc/<pid>/stat 第 22 字段的原始 tick 串>
controller_port=<u16>
mixed_port=<u16>
config_digest=<spawn 时钉住的配置摘要>
binary_digest=<spawn 时复核过的资产摘要>
spawned_at_unix_ms=<u64>
```

snapshot/journal 仍是**配置与部署记录**（ADR-050 的边界不变）；receipt 只回答一个新问题：
「上一个 daemon 认为哪个**进程**是它的核」。凭据损坏/不可解析 = 永远不可接管（按名拒绝 + 清除），
不是降级猜一个。

### 2.2 身份三要素：pid、/proc start_time、nonce——comm 不是

- **pid + start_time**（`/proc/<pid>/stat` 第 22 字段，原始 tick 串直接比较，不做单位换算）钉住
  「receipt 说的进程」与「现在活着的进程」是同一个。start_time 跨 `exec` 稳定——spawn 链是
  `/bin/sh -c "gunzip … && exec ./core …"`，**comm 会从 `sh` 变成 `core`**，所以 comm 只记录
  观察、不参与身份判定；pid 复用必然改变 start_time，这就是 §12.3 第二要素的意义。
- **nonce** 把 receipt 钉到一次具体 spawn（`StdProc` 的 spawn 序号 + pid）。进程自身无法证明 nonce；
  它的作用是凭据自洽与日志可对账，不冒充进程侧证据——ADR 如实记这一层。
- 读 `/proc/<pid>/stat` 是**固定路径的宿主事实读取**（pid 为数值，无调用方可控路径段），与资产
  读取同类；`Fs` 网关根仍是 profile 可控路径的边界，本 ADR 不扩大它。

### 2.3 adoption 在组合根、real 模式专属、listener 之前

`calyd --effect-runtime real` 启动时（bootstrap 之后、bind 之前）调 `adopt_on_start()`，结果按名
上日志（systemd 下进 journald）：

| 结果 | 判定 | receipt | 动作 |
|---|---|---|---|
| `NoReceipt` | 无凭据 | — | 冷启动，一字不假 |
| `Adopted` | pid 活、start_time 等、controller 应答 `/version` | 保留 | 重建 `LiveInstance(foreign)` + 重开 `ActiveCore` 路由 + 日志带 pid/nonce/端口 |
| `CoreGone` | `/proc/<pid>` 不存在 | **清除** | 核已死；OS 干净，记录层由既有 engine recovery 收敛 |
| `IdentityMismatch` | pid 活但 start_time 不同（pid 被复用） | **清除** | 那不是我们的进程；**绝不向不匹配的进程发信号**；原核必已死（pid 复用前提） |
| `Refused` | 身份匹配但 controller 不应答（核假死/端口被占） | **保留** | 不接管、不开路由；每次启动如实报，绝不「看起来还能用」 |

收敛性（§12.4）：已提交的 Active snapshot + 被接管的活核 = 「旧 Snapshot Active」成立；核死 +
凭据清除 = 干净冷态；拒绝接管 + 理由上日志 = 显式非悬空。把 Active snapshot 记录在核死后回滚为
Failed 属记录层策略，**显式不在本轮**（engine recovery 的既有语义不动，残余登记于 §4）。

### 2.4 可停的接管：ForeignStopper 注入 + pidfd FFI（bin 内）

接管必须完整——只会「看着」的接管在下次停机时又造孤儿。但非子进程没有 std 信号面，端口 crate 又
`forbid(unsafe_code)`。方案：lib 定义 `ForeignStopper`（`Fn(pid, start_time) -> Result<
ForeignStopOutcome, String>`，`StoppedWithinGrace | KilledAfterGrace | AlreadyGone`），
`StdEffectRuntime::with_foreign_stopper` 由**组合根注入**；未注入时对 foreign 核的停止按名失败
（`foreign-stop-unavailable`），不静默降级。

`calyd` bin 的新 FFI 模块（与 `support/signal.rs` 同一教义：符号极小、unsafe 圈禁在 bin 内、
不引 libc crate）实现生产 stopper：

1. `pidfd_open(pid)`——**先**钉住进程（fd 绑定的是「这个进程」而非「这个 pid」）；
2. 再读 `/proc/<pid>/stat` 复核 start_time——不匹配即拒（pidfd 之后的 stat 读的是被钉进程或
   其复用者：复用者必不匹配，原进程已死则信号落在死 fd 上无害——该次序消除 bare-kill 的
   TOCTOU pid 复用竞态）；
3. `pidfd_send_signal(SIGTERM)` → 有界等待（grace）→ `pidfd_send_signal(SIGKILL)` → 等消失。

非子进程的退出状态归 init，我们拿不到也不编造：停止证据记 `foreign` + 结果档
（`stopped-within-grace` / `killed-after-grace` / `already-gone`），不伪造退出码。内核无
pidfd（<5.3）时按名拒绝——不回退 bare kill。

### 2.5 simulated 模式不参与

adoption 是真实进程层的事实；`SimulatedRuntime` 无进程可接管，路径完全不经过。默认 simulated
的事实不变（ADR-050）。

## 3. Alternatives considered

- **读 snapshot 代替凭据**：否决（ADR-050 §2.5 已否）——snapshot 是配置记录，不含进程身份，
  「看起来部署过」不等于「进程还在」。
- **发现孤儿一律杀掉再重 spawn**：否决——中断在途代理（违背 §12.2 「接管」的本意）、且非子进程
  根本没有 std 杀面；「杀不掉就留着但不说」正是 §12.4 禁止的悬空态。
- **`Proc` 端口长出信号面**：否决（本轮）——`caly-io-std` 全 crate `forbid(unsafe_code)`，
  为一个 Unix-only 需求打开整个 crate 的 unsafe 面不值；进程生命周期控制是组合根职责
  （ADR-011/056 同判）。若未来引擎层需要可移植的「等进程消失」，再立 ADR。
- **生产 `/bin/kill` 子进程代杀**：否决（ADR-043 §2.5 原判）——shell 面回到生产路径。
- **bare `kill(pid)` FFI 接受 pid 复用竞态**：否决——竞态窗口小但杀错进程的代价不对称，而
  pidfd 恰好就是为了这个而存在；「窗口小」不是工程理由。

## 4. Consequences

- 裁判：库层 `real_apply.rs` 四胎（接管重建 + 停止链清凭据 / 核死清除凭据 / start_time 不匹配
  拒绝且**不动那个进程** / controller 哑拒绝且不开路由）+ 旗舰 e2e `caly_cli_e2e.rs`
  （双二进制：kill -9 → 同 pid 接管 → SIGTERM 随第二 daemon 停核、exit 0、凭据清除）+
  证伪四变异（跳过 start_time 校验 / 只记日志不建实例 / foreign 停止空转 / 核死不清凭据）。
- 残余（登记，不静默）：①核死后把 Active snapshot 记录收敛为 Failed 的记录层策略；②多 live
  label（当前 runtime 单实例语义）；③Windows 的 SCM/进程面（FEATURES §1.3 既有残余）；④adoption
  只验证 controller 应答，不钉资产版本——资产升级不应使接管失效（有意为之）。
- `docs/status/*`、`docs/guides/FEATURES.md`、CHANGELOG 同轮收口；census/floor 随裁判数上调。
