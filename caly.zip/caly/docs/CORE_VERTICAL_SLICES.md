# Caly Core Vertical Slice Strategy

本文件说明 `MockCoreAdapter`、`caly-mihomo` 与 `caly-singbox` 在当前阶段的真实落点，以及为什么 vertical slice 仍然应该围绕中心主链推进。

> **📌 阅读提示（2026-08-31 更新）**：双内核已从 mock slice 推进到**真实内核资产 spawn/probe/stop/rollback 切片**（sha256 钉死）；完整 artifact golden 与 runtime API 仍缺。最新状态见 `FEATURES.md §2.5`、`IMPLEMENTATION_STATUS.md`。本文保留 slice 策略与取舍价值。


---

## 1. vertical slice 的真正目标

vertical slice 的目标不是立刻完成所有 native 配置字段，而是尽快验证以下主链：

```text
Profile / Sources / Overrides
  -> Pipeline
  -> ResolvedProfile
  -> Capability Validation
  -> CoreAdapter
  -> CompiledArtifact
  -> NativeValidationReport
  -> ApplyPlanningResult
  -> EffectPlan
```

也就是说，vertical slice 的价值在于：

- 验证 centerline 是否能闭合
- 验证不同 core 的 capability / compile / apply 差异是否有承载位
- 验证 `CompiledArtifact` 不是空名义对象

---

## 2. 当前已经具备的基础

当前已形成：

- `caly-ir`
- `caly-domain`
- `caly-core::CoreAdapter`
- `caly-core::MockCoreAdapter`
- `caly-pipeline::run_pipeline_for_adapter(...)`
- `caly-engine::plan_apply_request(...)`
- `caly-engine::deployment_plan_view(...)`
- `caly-engine::explain_pipeline(...)`
- `caly-mihomo::MihomoAdapter`
- `caly-singbox::SingBoxAdapter`

这意味着 core vertical slice 已经不只是“将来要做”，而是开始成为 daemon/query/facade 可消费的中间层。

---

## 3. 当前 `CompiledArtifact` 的语义已经升级

`CompiledArtifact` 当前已不再只是：

- digest
- file hint

而开始承载：

- native config format
- entrypoint
- media type
- stable bytes
- annotations

这很关键，因为它使得后续以下工作有了真正挂载点：

- native validation
- CAS/object write intent
- materialization path
- config identity comparison
- selection-only diff / semantic diff

---

## 4. Mihomo slice 的当前状态

### 已有能力

- 产出 YAML-shaped native artifact bytes
- 暴露 `dns.fake_ip` / `routing.rules` / `network.tun` / `runtime.group.select` 能力位
- 根据当前/下一 artifact 差异区分：
  - `Noop`
  - `ApiPatch`
  - `HotReload`
  - `Restart`
- 生成对应的 `EffectPlan`
- vertical slice helper 能返回：
  - artifact hint
  - artifact bytes
  - native accepted
  - apply plan kind
  - effect step count

### 当前设计含义

这代表 Mihomo slice 已经开始表达：

- 运行时组选择可通过 API patch 承载
- 配置变更在不涉及 TUN 网络副作用时可偏向 hot reload
- 涉及 TUN 时会升级到 network-aware 路径

---

## 5. sing-box slice 的当前状态

### 已有能力

- 产出 JSON-shaped native artifact bytes
- 暴露 `dns.fake_ip` / `routing.rules` / `network.tun` / `outbound.wireguard` 能力位
- 根据 capability 与 artifact 差异区分：
  - `Noop`
  - `Restart`
  - `RebuildAndRestart`
- 生成对应的 `EffectPlan`
- vertical slice helper 能返回：
  - artifact hint
  - artifact bytes
  - native accepted
  - apply plan kind
  - effect step count

### 当前设计含义

这代表 sing-box slice 已经开始表达：

- WireGuard/outbound native-only 差异
- 配置更新更保守地偏向 restart/rebuild 路线
- TUN 与 native-only 特性会推动部署事务升级

---

## 6. Mock slice 的当前角色

`MockCoreAdapter` 现在仍然有价值，但角色已经变化：

- 它不再只是“占坑”
- 它更像 centerline contract 的最小实现
- 它用于验证：
  - semantic digest / selection digest
  - native bytes 存在性
  - apply plan/effect plan 投影格式

因此，Mock slice 的定位应是：

> 保持最小可验证 contract，而不是继续成为真实能力扩展的主战场。

---

## 7. 当前仍缺什么

vertical slice 仍未完成，主要差距在：

1. source 已有真实 fixture→parse/normalize→CAS/cache→apply 消费、durable index、caller phase-boundary control 与 inspection projection；剩余是更广 source scheme/feature coverage，以及 blocking syscall 的中断式 runtime 语义
2. capability validation 还没有完全由 registry/coverage 驱动的外部工件加载
3. native validation 仍以结构与已登记 core fixture 为主，完整生产平台部署面未闭合
4. effect plan 已进入 executor / storage / rollback 闭环，但 `calyd` 默认仍为 simulated runtime
5. runtime driver 还没接完整真实 HTTP/IPC transport 与 telemetry API

---

## 8. 下一阶段的正确推进方式

正确顺序应是：

1. 继续让 pipeline 产出更真实的 resolved profile
2. 让 capability check 绑定 registry / coverage matrix
3. 让 adapter compile/validate 更贴近真实 native shape
4. 让 engine/daemon 真执行 effect plan
5. 再去扩更多 native feature 字段

不要反过来先堆大量 core 特有字段，否则只会重新滑回“大一统配置假象”。

---

## 9. 一句话结论

> 现在 vertical slice 已经从“空 adapter 骨架”推进到“能产出 native bytes、validation、apply plan 和 effect plan 的 partial centerline slice”，下一步应继续压实执行闭环。