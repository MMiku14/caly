# Caly 开发日志 — 2026-08-31（第九十四轮：CLI 校验回包 request_id 与发出请求关联）

R71 已在握手修掉「v0 只信帧类型、不读内容」（协议主版本/编码不符即拒）。本轮在**请求/应答**
路径上闭合它的同形残留：CLI 一次性动词发出 `request_id`，却只按帧 kind 接受 RESPONSE/REFUSAL，
从不读回包里的关联 id。一个 foreign id（错帧/串帧/困惑的对端）或缺 id 的回包会被当成本次动词的
答案打印。无 wire 形状变更、无新依赖、无新 ADR。

---

## 1. 靶子（量选与判据）

### 1.1 现象

`crates/caly-cli/src/bin/caly.rs` 的 `ask()`：

```rust
session.send(WIRE_KIND_REQUEST, &request_payload(1, operation, extra, json))?;
let (kind, payload) = session.recv()? ...;
match kind {
    WIRE_KIND_RESPONSE => Ok(Answer::Records(records)),   // 不读 request_id
    WIRE_KIND_REFUSAL => Ok(Answer::Refused { .. }),       // 同样不读
    ...
}
```

v0 是「一连接一在途请求」（`request_head_from_records` 把缺失 id 默认为 0），daemon 在**每个**
response/refusal 上回显请求 id（`status_records` 等与 `refusal()` 都写 `request_id=`）。但 CLI
从不校验它。于是：

- 回包 `request_id=999`（本连接刚发的是 1）→ 仍被当作 status 答案打印；
- 回包根本没有 `request_id` 记录 → 也被接受。

### 1.2 为什么既有测试没抓到

真 daemon 总回显正确 id，全部真 daemon e2e 天然绿；既有假 daemon 测试也没人故意回 foreign id。
同族教训（R89/R92）：**正常对端不触发的错，要由假对端故意构造暴露**。

### 1.3 判据（可证伪）

> 一个 RESPONSE/REFUSAL 帧只有在 `request_id == 本次发出值` 时才是本次答案；foreign id 或缺 id
> 即协议不符（exit 13，点名两侧 id），且错帧事实不得打印。正确 id 的回包必须照常接受（不是凡回包
> 全拒）。

## 2. 实现

- 加命名常量 `const REQUEST_ID: u64 = 1`。v0 一连接一在途、每次动词都新鲜握手，所以恒为 1；命名
  是为了「发出值」与「校验值」是**同一个符号**，不各写字面量（见证伪 M2）。
- `ask()`：`request_payload(REQUEST_ID, ..)` 发出；解析回包 `request_id`（records/json 两面都经
  `wire_field`/`json_to_records`），`answer_id != Some(REQUEST_ID)` 即返回错误（exit 13），文案
  "the daemon answered request id X, but this verb sent 1 — PROTO_MISMATCH"。缺失/不可解析 id 得
  `None != Some(1)` 同样拒绝。
- follow 流不涉及：流 DATA/END 与 ack 确认不按请求 id 关联（那条链路用 stream_id/游标），不改。

## 3. 裁判

### 3.1 假 daemon wire e2e（`caly_cli_e2e.rs`，3 胎）

- `a_response_with_a_foreign_request_id_is_refused_not_printed_as_the_answer`：假 daemon 握手后回
  `request_id=999` 的 response。断言 exit 13、stderr 含 "request id" 与 "999"、stdout **不**打印
  `core_running: true`（错帧事实不上纸）。删关联检查的变异下 exit 0 且打印错帧 → 红。
- `a_response_with_no_request_id_is_refused_not_printed_as_the_answer`：回包**无** `request_id` 记录。
  exit 13、事实不打印。钉「缺失也拒」——把缺失默认成匹配（`.or(Some(REQUEST_ID))`）的变异即红。
- `a_response_with_the_sent_request_id_is_accepted`：回 `request_id=1` → exit 0 且打印。反空转：
  防「凡回包全拒」让前两条变 vacuous。

### 3.2 结构门禁

`the_cli_correlates_each_answer_with_its_request_id`（生产 caly bin）：存在 `const REQUEST_ID: u64`；
`ask` 体内经 `request_payload(REQUEST_ID` 发出；且含**真实比较表达式** `answer_id != Some(REQUEST_ID)`。
最后一条刻意不写成「出现 answer_id 符号」——M1 变异把逻辑删成 `let _answer_id = ();` 时，符号还在但
比较没了，第一版门禁因子串匹配漏判；改钉比较表达式才咬住。

### 3.3 证伪 `scripts/falsify_round94.py`（3 变异全 BIT，均编译绿、判据红）

- **M1**（删比较：parse+if 换成 `let _answer_id = ();`）：foreign 与 missing e2e 都红 + 门禁红。
- **M2**（比较改成 `!= Some(999)` 外国常量）：sent happy 裁判（id 1 被错误拒绝）红——证明校验值必须
  等于发出值，不是任意数字。
- **M3**（`.or(Some(REQUEST_ID))` 把缺失 id 默认成匹配）：missing e2e 红，而 foreign（999 在场仍错）
  与 sent（1 正确）裁判仍正确——证明「缺失 ≠ 匹配」这半边独立成立，不是把缺失和 foreign 混为一谈。

## 4. 收口数字

- `cargo test --workspace`：829 → **833**（+4：CLI e2e 3、arch 门禁 1）；`check.sh TEST_FLOOR=833`。
- clippy 唯一源码位置：**31**（= 基线，未抬、无 `#[allow]`）。
- rustfmt：只对碰过的文件（`caly.rs`、`caly_cli_e2e.rs`、`dependency_direction.rs`）。
- 普查重新生成（files=105 total=833 rows=105），描述列手写补 R94。

## 5. 本轮踩到的点（留档 `ONBOARDING_NOTES §4.168`）

1. **关联字段要在客户端校验，不能只信帧类型**：握手校验了协议/编码（R71）与角色（R92/R93），
   请求/应答也必须校验回包属于本次请求。
2. **发出值与校验值用同一命名符号**——M2 就是两者漂移成不同数字的变异，分开写常量/字面量会漏。
3. **裁判三胎**（foreign 拒 / 缺失拒 / 正确收），缺一就被「全拒」或「全收」蒙混。
4. **结构门禁钉真实比较表达式，不钉符号出现**：`_unused` 绑定也含子串，会让删逻辑的变异漏网（M1
   第一版门禁正是这样没咬住，改成 `answer_id != Some(REQUEST_ID)` 后才咬）。
5. **证伪脚本的「咬住」判据不要加过严的输出子串**：M1 门禁失败文案是 "...compare it to
   REQUEST_ID"，脚本一度要求含 "answer_id" 而误报 MISS；判「门禁红」应看 test result，而非某个
   具体词。

## 6. 明确没做

多请求复用/递增 request_id（v0 一连接一在途，CLI 每次动词新鲜握手；request_id 的多态化、client 侧
`send_request_frame` 复用属 §13#3 的「typed send_request_frame / 共享 timeout scheduler」主体）；
不改 follow 流关联与 daemon 回包形状；无 wire 形状变更、无新依赖。
