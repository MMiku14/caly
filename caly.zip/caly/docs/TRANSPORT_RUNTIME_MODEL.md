# Caly Transport Runtime Model

本文件说明生产 IPC 的层次：`BindSpec` / `WireIo` / `FramePump` / `HandshakeDrive`
是 **calyd 与 caly 共用的一层**；`SessionRegistry` / `DaemonRuntime` / `ServerLoop`
仍是 harness 层。把后者写成生产 runtime，会让人去接一份从未上线的循环。

交叉引用：`IPC_IMPLEMENTATION_PLAN.md`、`ROADMAP §13#3`、`IMPLEMENTATION_STATUS §8.22`。

---

## 1. 背景：为什么 TCP-only 生产是缺口而不是风格

v0 wire 早已冻结：`[kind u8][len u32 BE][payload]`，payload 是 UTF-8 `key=value`
记录（`--json` 会话在 hello 之后改 JSON 对象，握手帧本身仍是 records）。codec
在 `caly_ipc::wire`；方言在 `caly_ipc::dialect`；请求形状在 `caly_ipc::wire_ops`。

缺的不是帧格式。第八十六轮之前，生产两侧各自握着一份 **TCP-only** 接缝：

- `calyd`：`TcpListener::bind` + `listener.incoming()` + `TcpStream` 上的
  `serve_connection`；`--port-file` 写裸 `u16`。
- `caly`：`TcpStream::connect` + 手写 `Session`；`--addr` 只懂 `host:port`。

一份 UDS 实现如果再抄一遍 `read_frame` / `write_frame` / hello 循环，就是
**第二个协议穿着第二个 transport 的衣服**。`RFC-0002` 要求 framed JSON over
UDS / Named Pipe；Named Pipe 是 Windows，v0 宿主不是。UDS 必须是同一套
bind/connect/pump，而不是 `--unix` 开关另起炉灶。

因此第八十七轮的切片是：

> 一个 `BindSpec`、一个 `WireIo`、一个 `FramePump`、一个 handshake-only
> `ClientLoop` 驱动。TCP 与 UDS 是这个表面的两个实现，不是两份循环。

---

## 2. 推荐层次（生产 vs harness）

```text
生产（calyd / caly 真 binary 走这里）

  BindSpec            --bind / --addr 的语法，不打开 socket
  BoundAddr           实际绑定结果；port-file 的权威字符串
  WireListener        TCP 或 UDS 监听；chmod 0o600；stale unlink
  WireStream          TCP 或 UDS 已连接流
  WireIo              Read+Write + 读超时 + 对端探测
  FramePump           在 WireIo 上跑共享 codec
  HandshakeDrive      ClientLoop 只走 hello：New → HelloSent → Active
  dialect + wire_ops  hello 之后的请求形状（字符串 op + extras）

harness（测试与 loopback 走这里，生产 binary 不调用）

  SessionMachine      单会话状态约束
  DaemonSession       单会话 server-side glue
  DaemonTransport     单会话 transport boundary（calyd 仍用它处理 hello/request）
  SessionRegistry     多会话索引与调度（skeleton）
  DaemonRuntime       runtime-level app + registry assembly
  ServerLoop          client/server protocol loopback harness
```

`DaemonTransport` 仍在 `serve_connection` 里处理 hello 与 request 的 **typed**
一侧（`on_hello` / `on_client_frame`）。它不是 socket 层。socket 层是 `WireIo`。

`ClientLoop::send_request_frame` 收 typed `caly_api::Operation`。v0 wire 是
字符串 op + 各 op 专属 extra（`§8.11` / R76）。把 typed 层接到生产 CLI 是
**新 API 增长**，不是复用。HandshakeDrive 因此只驱动 hello。

---

## 3. BindSpec：解析不打开 socket

`BindSpec::parse` 的输入是 `--bind` / `--addr` 的原文字符串。它不做 DNS、
不 `stat`、不 `bind`。一个尚不存在的 unix 路径仍是合法 spec；一个没有端口的
hostname 仍是 usage。

| 输入 | 结果 |
|---|---|
| `127.0.0.1:0` / `127.0.0.1:9090` / `localhost:8080` | `Tcp { host, port }` |
| `[::1]:9090` / `[::]:0` | `Tcp`，display 带方括号 |
| `unix:/tmp/caly.sock` / `unix:///tmp/caly.sock` | `Unix { path }`（剥一层或两层前缀） |
| `/tmp/caly.sock` / `./caly.sock` / `../caly.sock` | `Unix`（绝对或相对路径，无需前缀） |
| `npipe:` / `\\.\pipe\` / `//./pipe/` | Unsupported，点名 named pipes |
| `@caly.sock` / `unix:@caly.sock` | Unsupported，点名 abstract（`unlink` 清不掉） |
| 空 / 空白 | Usage，点名 empty |
| `unix:` / `unix://` | Usage，点名 missing a path |
| 含 NUL | Usage，点名 NUL（`sockaddr_un` 是 C 字符串） |
| 路径 > `UNIX_PATH_MAX`（104） | Usage，点名 `sun_path` |
| `localhost` / `127.0.0.1` / `[::1]` 无端口 | Usage，点名 host:port |
| 端口不是 u16 | Usage，点名 u16 |

`UNIX_PATH_MAX = 104`：Linux `sun_path` 108 含 NUL，107 可用。拒绝点放在 104，
让垫到 105 的测试仍低于内核硬顶，拒绝是我们的，不是 `EINVAL`。

Windows Named Pipe 与 Linux abstract socket 都按名拒绝。v0 宿主是 Unix 文件
socket + TCP loopback。把它们做成“以后再接”的静默忽略，等于生产路径上有一条
谁也测不到的分支。

---

## 4. BoundAddr 与 port-file 契约

`WireListener::bind` 返回 `(listener, BoundAddr)`。`BoundAddr` 是 **实际**
绑定，不是 spec：

- TCP `host:0`：内核选端口；`tcp_port()` 是那个非零 u16。
- UDS：path 在 stale unlink 与 `chmod 0o600` 之后仍是 spec 里的那条路径。

`--port-file` 写的是 `BoundAddr::port_file_text()`，**不是** `display()`：

| 传输 | `port_file_text()` | 既有 e2e 怎么读 |
|---|---|---|
| TCP | 裸十进制 `u16`（例如 `43123`） | `calyd_wire` / `caly_cli_e2e` 解析一个数字 |
| UDS | `unix:<path>` | 同一文件，不同字符串；**绝不是**一个假装成端口的数字 |

TCP 保持裸 u16 是兼容既有裁判，不是“UDS 也该是数字”。一个 UDS 监听器若把
path 写进 port-file 而不带 `unix:` 前缀，TCP 解析器会把它当 u16 失败或——更糟
——碰巧解析成某个端口。裁判
`unix_port_file_text_is_the_unix_prefix` 与
`a_unix_port_file_is_not_a_bare_u16` 钉住这个前缀。

`display()` 给人看（stderr `listening on …`）；port-file 给脚本看。两套字符串
可以碰巧相同（UDS），TCP 上故意不同（display 带 host，port-file 只有端口）。

---

## 5. WireIo 与探测诚实性

`WireIo: Read + Write` 额外要两件事：读/写超时，以及对端探测。

```text
enum PeerProbe { Alive, Closed, Indeterminate }
```

| 实现 | `probe_peer` | 理由 |
|---|---|---|
| `TcpStream` | `peek` 0 字节 → `Closed`；有数据或 WouldBlock/TimedOut → `Alive` | std 有 peek |
| `UnixStream` | 恒 `Indeterminate` | std 无 peek；0 字节 read 会消费；would-block write 不证明对端已走 |
| `MemoryIo` | 由夹具决定 | 单元测试 |

把 UDS 的 would-block write 发明成 `Closed`，会在 live session 上误收割。
`libc`/`nix` 的 `MSG_PEEK` 是新依赖，需要 ADR，本轮不做。流泵对
`Indeterminate` 的态度是 **继续等**，直到一次真正的 write 失败或 tick 预算耗尽。

`calyd` 的 job 流泵（round 53，round 87 改走 `WireIo`）在 `PumpStep::Wait`
里调 `probe_peer`：TCP 上 `Closed` 打一行 stderr 并停泵；UDS 上
`Indeterminate` 继续等。裁判 `a_stream_client_that_leaves` 仍只在 TCP 上断言
reap 行——UDS 没有 peek，不能用同一条裁判假装收割。

超时：`HELLO_TIMEOUT`（5s，陌生人）与 `--session-idle-ms`（默认 30s，已握手）
仍是两条策略（round 46）。它们设在 `WireIo::set_read_timeout`，不是一个全局
scheduler 对象。共享 timeout scheduler 仍是后续项。

---

## 6. FramePump

`FramePump<S: WireIo>` 是 codec 的拥有者：

- `send(kind, payload)` → `wire_write_frame`（出站 cap 在编码处拒绝）。
- `recv()` → `wire_read_frame`（入站 cap 在读 payload 之前拒绝；`timed_out`
  留给 speaker 映射 exit 11）。
- 构造时可选读超时。
- `probe()` 委托 `WireIo::probe_peer`。

`Closed` 探测 **不得** 再读：对端已走，再 `read` 是把 EOF 说成一帧。
`Indeterminate` **必须** 落到 `read`：否则 UDS 永远收不到 hello。
这两条是 `duplex.rs` 的单元裁判，不是注释。

`MemoryIo` 是内存双端队列，`transport_kind() == "memory"`。它让 handshake
与 pump 的单测不碰 socket。生产路径不构造它。

---

## 7. HandshakeDrive：hello-only ClientLoop

生产 `caly` 过去发送 dialect hello 字节并校验 ack，从不碰 `ClientLoop`。
typed 循环存在、未引用。`send_request_frame` 收 typed `Operation`，v0 是
字符串 op + extras——接上去是第二张请求表。

`drive_client_hello` 只做 hello：

1. `ClientLoop::open_handshake`：New → HelloSent，产出 `OutboundHello`。
   **字节仍是 `client_hello_payload`**，不是 typed `ClientHello` 编码。
2. 读一帧。kind 必须是 `hello_ack`，否则按名拒绝。
3. dialect 解析 → `client_validate_hello_ack`（协议 major、encoding 与会话
   一致）。**先于** `observe_hello_ack`。跳过这一步就回到 R71 的“只看 kind”。
4. dialect view 映射到 typed `ServerHelloAck`：`records` 与 `json` 都变成
   `Encoding::Json`（typed 枚举没有 Records）。`msgpack` → `MsgPack`。
   其它 encoding 按名拒绝。
5. `observe_hello_ack` → Active。hello **不**消耗 `next_request_id`（仍是 1）。

CLI 角色是 `Admin`。`ClientSessionConfig::default` 是 `Operator`
（`ADR-037 §2.2`）。生产 CLI 一直以 Admin 自报；daemon 的宽松解析把未知
role 映成 Admin。把 Operator 放到线上是静默降权，穿成“用默认”。

`HandshakeDrive` 不实现 `Debug`。单测用 `match` / `unwrap_err`，不
`expect_err`——`expect_err` 要求 Ok 类型 Debug。

---

## 8. 生产接线

### 8.1 calyd

```text
BindSpec::parse(--bind)
  → WireListener::bind
  → BoundAddr::port_file_text() 写入 --port-file（若有）
  → loop { listener.accept() → spawn { serve_connection(&mut impl WireIo) } }
```

`serve_connection` 签名从 `TcpStream` 改为 `&mut impl WireIo`。帧读写仍走
共享 codec；hello/request 仍走 `DaemonTransport` + dialect + `decode_request`。
worker 线程、流表、idle 期限不变。

默认 `--bind` 仍是 `127.0.0.1:0`（TCP 临时端口）。UDS 是
`--bind unix:/path` 或 `--bind /absolute/path`。

UDS bind 额外行为：

- 已存在的 **socket** inode：unlink 后 bind（重启可重绑）。
- 已存在的 **普通文件**：按名拒绝，不 unlink（那是操作员的数据）。
- 已存在的 **目录**：按名拒绝。
- bind 成功后 `chmod 0o600`。世界可读 socket 就是 `RFC-0010 §14` UDS 权限
  在生产上的失败形态。0o600 是 v0 默认，直到 helper/platform ADR 另说。
  **这不是 §14 整条收口**——没有 helper、没有目录 umask 策略、没有 named
  pipe ACL。

### 8.2 caly

```text
BindSpec::parse(--addr)
  → WireStream::connect(spec, 3s)
  → FramePump
  → drive_client_hello
  → 既有 ask / follow_stream（字符串 op + extras）
```

`--addr unix:/path` 与 `--addr 127.0.0.1:PORT` 走同一 `Session::open`。
CLI 的 `recv` 仍委托 `wire_read_frame`（R85 入站 cap）。handshake 的
connected 行仍去 stderr。

---

## 9. 明确仍是 skeleton 的层

下列类型继续存在，**生产 binary 不把它们当 socket 循环**：

- `SessionRegistry` / `SessionRegistryConfig` / `SessionRegistrySnapshot`
- `DaemonRuntime`（harness 装配，不是 `calyd` 的 listener）
- `ServerLoop`（loopback）
- `ClientLoop::send_request_frame` / `observe_stream` / `apply_ack`

把“SessionRegistry 已有 open/hello/frame”写成“transport runtime 已完成”，
是用 harness 覆盖率冒充生产接线。第八十七轮不删除这些类型，也不把它们
接到 `calyd` 的 accept 循环上。

---

## 10. 可证伪主张（本轮钉住的）

1. UDS port-file 以 `unix:` 开头，不是裸 u16。
2. TCP port-file 仍是裸 u16，字符全是 ASCII 数字。
3. 编码谎言（ack `encoding=msgpack` 对 records 会话）在 `observe_hello_ack`
   **之前**被拒绝，客户端不得变成 Active。
4. UDS 对端 drop 之后 `probe_peer` 仍是 `Indeterminate`，不得发明 `Closed`。
5. TCP 对端 drop 之后 `peek` 0 → `Closed`。
6. 新鲜 UDS 的 mode 是 `0o600`。
7. 生产 CLI 的 handshake 角色是 Admin，不是 Operator 默认。
8. hello 不推进 `next_request_id`。

对应证伪脚本：`scripts/falsify_round87.py`（M1 摘 `unix:` 前缀 / M2 跳过
`client_validate_hello_ack`）。

---

## 11. 明确未做

- `ClientLoop::send_request_frame` 接入生产 CLI（双表接线，R76 已排除）。
- 共享 timeout scheduler 对象（仍是每连接 `set_read_timeout`）。
- UDS peek（libc/nix，需 ADR）。
- Named pipes / abstract sockets。
- `SessionRegistry` 生产化。
- RFC-0010 §14 的完整 UDS 权限模型（helper、目录 umask、ACL）——本轮只有
  bind 后 `chmod 0o600`。
- close reason / reconnect 规则下沉到 `WireIo`（reconnect 仍在 daemon 流表）。

---

## 12. 一句话结论

> 如果 `SessionMachine` 解决的是“单连接是否合法”，那么 `BindSpec`/`WireIo`
> 解决的是“这条连接在哪种 socket 上、两端是否共用一个泵”；`HandshakeDrive`
> 把 typed `ClientLoop` 接到 dialect 字节上，且只接到 hello。
> `SessionRegistry` 仍然回答 harness 里“当前有哪些打开的 session”，不是
> `calyd` 的 accept 循环。
