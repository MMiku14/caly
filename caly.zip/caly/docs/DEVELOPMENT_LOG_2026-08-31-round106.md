# 开发日志 · 第一百零六轮（2026-08-31）：`jobs.list` 部署作业发现面

## 缘起

上一轮（R105，`JOB_FLOW_SCENARIO_REVIEW.md`）用真二进制端到端实测一个「网关部署日」场景，
据此重估 Job/Flow 功能必要性，暴露两个 P0：

1. **作业事件不跨重启**（内存态，`kill -9` 后 `caly job 1` → `no such job`）。
2. **没有 `jobs.list`**——必须已知 job_id 才能查，丢了 shell 历史就无从发现有哪些部署作业。

本轮做 **第 2 项的发现面**：新增只读操作 `jobs.list` 与 `caly jobs`（无 id）列表。第 1 项
（持久化）是存储 schema 变更、按纪律须先有 ADR，且一轮只做一件事，留独立一轮。

> 注意：`AutomationOp::ListJobs` 是**定时自动化作业**的列表，与部署作业无关；部署作业在
> `DiagnosticsOp`（FollowJob / ReadJobEvents / FollowJobStream），此前三者都要 job_id。

## 靶子（可证伪判据）

> 「`caly jobs`（不带 id）必须返回当前 daemon 持有的部署作业摘要，按 job_id **新→旧**、有界；
> `caly jobs <id>` 行为不变（仍分页该作业事件）。列表每行与该作业 `jobs.follow` 摘要同源。」

## 改动（一个只读 query 贯通四层）

| 层 | 文件 | 内容 |
|---|---|---|
| caly-engine | `service.rs` | `EngineHandle::list_job_views(limit)`：BTreeMap `.iter().rev()`（新→旧）`.take(limit)`，复用 `summarize_job_record` 造 `JobFollowView`（与 `project_job_follow` 同源，不漂移；无 window，计数表 retained 窗口） |
| caly-api | `ops.rs` / `result.rs` | `DiagnosticsOp::ListJobs`（query / Viewer / CostClass::Small）；`OperationResult::JobList(Vec<JobFollowView>)`，行复用 `JobFollowView` |
| caly-daemon | `app.rs` / `query/diagnostics.rs` / `bin/calyd.rs` | `app.job_list()` 设 `JOB_LIST_CAP=64`（local/remote 唯一 seam 一致）；query 加 `ListJobs` 臂；bin 加 `job_list_records`（`job_count` + `job_<i>_id/state/pct/event_count/last_stage/failure_code`，index 0 最新）+ `OperationResult::JobList` 渲染臂 |
| caly-ipc | `wire_ops.rs` | `"jobs.list"` 加入 `WIRE_OPERATION_NAMES`（13→14）；encode/decode 双臂（decode 无字段）；roundtrip 测试加 ListJobs |
| caly-cli | `bin/caly.rs` | `caly jobs`（无 id / 旗标占位）→ `jobs.list`；`caly jobs <id>` → `jobs.events`（不变）；新 `print_job_list`（id 为首字段、新→旧）；typed `DiagnosticsOp::ListJobs` 臂 |

## 裁判

- **engine 单测 2**：`list_job_views_is_newest_first_and_capped`（ids `[3,2,1]` 新→旧；cap=2 保最新两个 `[3,2]`）、`list_job_views_empty_is_ok`（空引擎→空列表 Ok）。
- **wire roundtrip**：`every_encoded_operation_decodes_back_to_itself` 加 ListJobs；白名单 14 项 decode 全识别。
- **真二进制 e2e**：`caly_jobs_without_an_id_lists_recent_jobs_newest_first`——apply 两个作业（id 1、2）后 `caly jobs` 头部 `jobs: 2`、行首字段序列 `["2","1"]`，并对**独立 oracle** 的 `jobs.list` wire 对话核 `job_count=2 / job_0_id=2 / job_1_id=1 / job_0_state=completed`。
- **结构门禁**：`the_jobs_discovery_verb_is_wired_end_to_end_under_a_daemon_cap`（dependency_direction 25→26）——钉 CLI 无 id→`jobs.list`+`DiagnosticsOp::ListJobs`+`print_job_list`、wire 双侧命名、engine `list_job_views`、daemon `job_list`+`JOB_LIST_CAP`、bin `OperationResult::JobList`+`job_list_records`。

## 证伪（`scripts/falsify_round106.py`，全 BIT）

| 变异 | 改动 | 被咬的裁判 |
|---|---|---|
| M1 | 引擎去掉 `.rev()`（改旧→新） | engine 单测 newest-first + 真二进制 e2e（期望 `[2,1]`）红 |
| M2 | CLI 无 id 不再选 `jobs.list`（旗标重排臂置 None） | 真二进制 e2e 红 |
| M3 | daemon 去掉 `JOB_LIST_CAP`（改 usize::MAX） | 结构门禁红 |
| M4 | wire 删掉 `jobs.list` decode 臂 | roundtrip 测试红 |

均保绑定/类型/arity（编译绿、判据红），`shutil.move` 还原 + `os.utime` + sha256 校验，收尾无 `.r106bak` 残留。

## 踩到的坑（测试设计）

1. **M2 变异点选错臂**：`caly jobs --addr HOST` 在 `jobs` verb 后下一个 token 是 `--addr` 旗标，走的是我写的「旗标重排队」臂，不是裸 `None` 臂（后者只有 `caly jobs` 裸命令命中）。第一版 M2 改 `None` 臂，e2e 不咬。**变异要打在真实测试路径经过的分支上**。
2. **列表渲染首字段不得有前导填充**：`print_job_list` 第一版用 `{id:>4}` 右对齐填充，e2e 用 `split_whitespace().next()` 取「id」实际取到的是状态列，顺序断言**假绿**（M1 下输出已是旧序、测试却过）。把 id 改为无前导填充、对齐挪到状态列后，M1 e2e 正确报 `left ["1","2"] vs right ["2","1"]`。教训：**约定「脚本取首字段」的列不能有前导空白**；变异不咬时先手动 `cargo build` 看真实输出，定位是实现没坏还是断言取错。

## 收尾

- census **862→866**、floor 866（+4：engine lib 2、caly_cli_e2e 47→48、dependency_direction 25→26；wire roundtrip 是既有测试加条目，非新 `#[test]`）。
- clippy baseline 31 不动；仅 `rustfmt --edition 2021` 碰过的文件；无新外部依赖、无新帧、无新 ADR（只读发现操作，无契约偏离）。
- 文档：本日志 + `IMPLEMENTATION_STATUS §8.38` + `ONBOARDING_NOTES §4.180`/处置表 6.132 + README 索引 + `FEATURES.md`/`JOB_FLOW_SCENARIO_REVIEW` 状态更新；CENTERLINE 866。

## 明确没做（下一轮方向）

- **作业事件持久化跨重启**（R105 P0 主体）：需终态/进行中 Job 事件落 FsStore + 启动恢复载入，属存储 schema 变更，**先 ADR**；本轮 `list_job_views` 只列本次 daemon 生命内作业。
- list 的分页 / retention 窗口（现为 daemon 固定 cap 64）。
- CLI `--role`（R105 P1）；v0 JSON 值全字符串（记录方言）。
