# Job / Flow 成本收益评估报告：便利性、代码量与维护难度

> 本文回答一个问题：**Job（异步作业 + 事件流）与 Flow（follow 流式跟随 / 断点续传 / 事件分页）带来的用户便利，与它们带来的代码量和维护难度相比，是否仍然必要？**
>
> 方法：以**用户身份**（只使用官方 CLI `caly`，不碰 wire 协议、不读测试）把部署日的完整操作链真实跑一遍，逐条记录输出与退出码；再按模块核算代码量、测试份额、决策文档与轮次投入，评估维护难度；最后给出分级判定与后续开发建议。
>
> 日期：2026-09-01。基线：886 tests / floor 886（干净重建全绿）。运行环境：`--effect-runtime simulated`（默认，零宿主副作用；真实内核下的时间维度差异在文中标注）。姊妹篇：`JOB_FLOW_SCENARIO_REVIEW.md`（R105 的实测重估，当时暴露的 P0 缺口——作业历史跨重启丢失——已在 R109/R110 闭环，本报告第 2.8 节实测证实）。

---

## 1. 结论先行（给赶时间的人）

1. **必要性成立，不砍。** Job/Flow 不是装饰：实测中它是「一次部署 → 一条可分页、可审计、带进度与失败身份的事件流」的唯一载体，是 caly 相对「改配置重启内核」的根本差异（RFC-0001 的事务不变量）。砍掉它 = 退回同步 RPC + 日志文件 grep。
2. **便利是真实的，且刚补上最后一块**：`kill -9` 后同 data-dir 重启，5 条历史作业（含各自 44/25/5/3/16 个事件）全部可列、可翻页、可 follow 重放——R105 实测时的最高落差已闭环。
3. **成本是成比例的，不是失控的**：直接服务 Job/Flow 的生产代码约 3.5–4.5k 行、测试约 110–130 条（占 886 的 ~13–15%）、决策文档 7 份 ADR，投入约 25 轮（110 轮的 ~1/4）。多数成本已沉淀为**裁判资产**（每行行为有红绿裁判钉住），边际维护成本是「不改坏」而非「继续长」。
4. **建议：主体冻结，只补三个小缺口，轮次转向。** 不再为 Job/Flow 加新机制；剩余投入仅限 (a) ~~CLI `--role` 可达性~~ **（同日 R112 已落地）**、(b) 流式 END 帧携带 failure_code、(c) `apply` 同步组合面的文档化/旗标。之后把轮次转给 P2（真核长部署 e2e）与 ROADMAP §13#3（协议生产化尾巴，TUI 前置）。

---

## 2. 用户视角实测（全部真实执行，原始输出摘录）

> 剧本与 `JOB_FLOW_SCENARIO_REVIEW.md §1` 同源（网关「部署日」），但**只在用户面操作**：起 daemon、敲 CLI、看退出码。daemon 后台起于临时目录，`--effect-runtime simulated`。

### 2.1 写操作即 Job：acceptance 秒回，不占 SSH 会话

```
$ caly apply demo-tun-profile --idempotency-key k1
job_id: 1            state_revision: 1     estimated_impact: Restart
exit=0                                    ← 立即返回，作业在后台 drain

$ caly apply demo-tun-profile            （忘了 key）
caly: profiles.apply needs --idempotency-key <k>; reuse the same key to retry, mint a fresh one per distinct write
exit=2                                    ← 缺 key 被点名拒绝，脚本错误早暴露
```

**便利**：长部署（真实内核下 spawn 内核 + 5 组 probe 可达数十秒）不阻塞终端；幂等键让 CI 重试安全（实测同 key 重放 → 同一个 `job_id: 1`、`state_revision: 1` 原样回；新 key → 新 job 2）。

### 2.2 发现面：不记 job_id 也能找回作业

```
$ caly jobs
jobs: 5
  5  completed  100%  events=16
  4  completed    0%  events=3
  3  completed  100%  events=5
  2  completed  100%  events=25
  1  completed  100%  events=44
exit=0                                    ← 新→旧，摘要一行一条
```

**便利**：丢了 shell 历史、或作业由别人（另一台机器、CI）发起，也能先列 id 再查。

### 2.3 一次性摘要：成败身份化

```
$ caly job 1
job_id: 1   state: completed   lifecycle: idle
next_event_index: 44   event_count: 44
last_stage: snapshot.committed snapshot:rev:a22ede834cd24915 revision=rev:a22ede834cd24915
last_stage_pct: 100   warning_count: 8   log_count: 25
failure_code: （空）  failure_summary: （空）
exit=0
```

**便利**：14 个字段一个动词；失败时 `failure_code` 按公共码映射退出号（R99），`caly job <id>` 在 CI 里可直接当判据。

### 2.4 事件分页：44 个事件的游标翻页

```
$ caly jobs 1 --from 0 --max 4
job_id: 1   state: completed   events: 4
  - [stage 10%] pipeline.resolve profile=demo-tun-profile
  - [stage 25%] capability.validate required=8 warn=1 blocked=0
  - [log:info] capability routing.rules=Allow/SupportedExact/CalyManaged
  - [log:info] capability dns.fake_ip=Allow/SupportedExact/CalyManaged
next_from_event_index: 4                 ← 游标 exclusive，逐页拼接不丢不重

$ caly jobs 1 --from 40 --max 4
events: 3
  - [log:info] Finalize 11: commit-revision 1
  - [stage 100%] snapshot.committed snapshot:rev:a22e... revision=rev:a22e...
  - [done] Succeeded
next_from_event_index: （空）             ← 到末尾了
```

**便利**：大事件集按页取；`next_from` 空=到头，语义干净。

### 2.5 follow：等待 + 实时进度 + 判决退出码

```
$ caly apply demo-tun-profile --idempotency-key w2   （慢 worker：--worker-tick-ms 400）
job_id: 2 ...
$ time caly follow 2                       ← 提交后立刻 attach
  - [stage 0%] running
  - [stage 10%] pipeline.resolve ...
  ...
  - [stage 100%] snapshot.committed ...
  - [done] Succeeded
real 0m0.180s                              ← 阻塞到终态，流式打印，exit 0
```

**便利**：这是「看起来同步」的组合面——`apply`（铸 job）+ `follow <id>`（等终态、按判决给退出码）两行命令等于一次同步部署。中间态也真实可抓：apply 后立刻 `caly jobs` 显示 `1 accepted - events=0`，0.9s 后 `completed 100% events=44`——**后台执行 + 中途 attach 的窗口真实存在**（真实内核下这个窗口是数十秒，正是流 idle 30s 加宽的理由）。

### 2.6 resume：断点续传零重印

```
$ caly follow --resume 1
caly: stream 1 (resumed=true)
（stdout 0 行）                             ← 已消费的事件零重印
exit=0
```

**便利**：同一 daemon 生命内断线重连不重放。**但注意**（见 §4.3）：跨 daemon 重启后旧 stream id 已无意义，resume 只能用于同生命内重连。

### 2.7 事务纪律族：rollback / gc / doctor / bundle 全部 Job 化

```
$ caly rollback --snapshot rev:a22ede834cd24915 --idempotency-key rk1
job_id: 3   state_revision: 5   estimated_impact: Restart
$ caly gc-plan          （只读：grace/objects/snapshots/revisions/unfinished_journals/would_run…）
$ caly gc --idempotency-key gk1
job_id: 4   estimated_impact: ReadOnly
$ caly support-bundle --idempotency-key bk1
job_id: 5
$ caly bundle          （读回：digest==content_sha256、78 行脱敏、truncated: false）
```

**便利**：破坏性操作先计划后执行；诊断包可查、可校验。这些动词共用同一套 Job 形状——用户学一个心智模型（「写操作 → job_id → jobs/follow」）就能操作全部命令，这是 Job 化最大的隐性便利：**认知成本一次付清**。

### 2.8 崩溃恢复：R105 的 P0 缺口已闭环（本报告最重要的实测）

```
$ pkill -9 calyd；同 data-dir 重启
$ caly status        → active_profile: demo-tun-profile；active_snapshot: rev:a22e…；recovery scan clean
$ caly jobs
jobs: 5                                    ← R105 时这里是「no such job」；现在 5 条全在
  5  completed  100%  events=16
  4  completed    0%  events=3
  3  completed  100%  events=5
  2  completed  100%  events=25
  1  completed  100%  events=44
$ caly jobs 1 --from 40 --max 4            ← 翻页照常
$ caly follow 1                            ← 重放照常（44 行）
$ caly apply … --idempotency-key k3        → job_id: 6（新 id 不撞恢复的 1–5）
```

**便利**：daemon 升级/崩溃重启/跨天回看——Flow 最该发光的场景——现在真的发光了。过程审计从「本次 daemon 生命」升级为「与部署状态同寿命」。

### 2.9 错误面与机器面

```
$ caly job 99    → caly: refused (CONFLICT): no such job: 99        exit=4
$ caly follow 99 → caly: refused (NOT_FOUND): job 99 does not exist; a stream cannot open on a job that was never accepted   exit=13
$ caly job 1 --json → 全字符串值 JSON（v0 记录方言），键集与 records 同体
```

**便利**：不存在的作业是**点名拒绝 + 稳定退出码**，不是编造的空页（脚本可直接分流）。

### 2.10 用户面小结

一条链六个动词（apply/jobs/job/follow/resume + rollback/gc/bundle 同形状）覆盖「铸作业 → 发现 → 摘要 → 分页 → 实时跟 → 断线续 → 崩溃后回看」。**每个动词都有实测输出与退出码佐证，无一空转**。当前用户面仍有三个刺（非 Job/Flow 核心，见 §4.3）：~~CLI 无 `--role`~~（**同日 R112 已落地**）、`apply` 无 `--wait`（同步组合要两行命令）、流式失败只有笼统 exit 1（END 帧无 failure_code）。

---

## 3. 代码量与结构成本（按模块实测）

### 3.1 生产代码

| 层 | 模块（行数） | 其中 Job/Flow 的职责 |
|---|---|---|
| 引擎 | `worker.rs`（1760）、`job_persistence.rs`（476）、`state.rs`（223）、`event.rs`（145）、`service.rs` 的 job 方法群（`mark_finished`/`restore_job_logs`/`prune_job_logs_locked`/`append_job_event`/`follow_job`/`project_job_follow`/`list_job_views`/`events_since`/`summarize_job_record`/`redact_job_event`，约 350 行） | 队列/状态机、drain、终态 D3 落盘、启动恢复、留存回收、投影与分页、脱敏 |
| 存储 | `job_log.rs`（61）+ `record.rs` job-log codec 段（encode/decode + known_fields 12 键） | 终态记录原语与坏记录拒绝 |
| IPC | `wire_ops.rs`（923）、`wire.rs`（281，8 帧 kind）、`dialect.rs`（561）、`client.rs`（312，typed 流表状态机）、`session.rs`（146）、`stream.rs`（97）、`policy.rs`（69） | jobs 三动词编解码、stream 开/resume 双形状、帧关联、流表、期限 |
| daemon | `app.rs`（1566，job 视图/列表/drain/投影）、`calyd.rs`（1829，帧循环+流泵+worker 线程+reap+期限安装） | 服务面：每连接一帧循环、每 tick 一 drain、流泵 |
| CLI | `caly.rs`（1257）、`follow.rs`（83）、`follow_loop.rs`（129） | 六个动词、同步组合、resume 状态机、退出码映射 |

粗算：**直接服务 Job/Flow 的生产代码 ≈ 3.5–4.5k 行**（按模块职责折算；worker/calyd 等大文件整行数中约一半为其服务）。对照：全仓 20 个 crate、生产代码总量约 2 万行级别，Job/Flow 约占 1/5。

### 3.2 测试

- 真二进制 e2e：`calyd_wire.rs` 45 条（测试名含 job/stream/follow/event/apply/bundle/gc 的 19 条，但整文件 2/3 以上内容为 job/stream 面——jobs 页、follow、流、apply、gc、bundle 全是 job 铸成）；`caly_cli_e2e.rs` 48 条（同名口径 28 条）。
- 耐久与契约：`job_log_durability.rs` 5、`job_log_contract.rs` 3、`job_persistence.rs` 单测 5。
- 引擎/IPC/存储内以 job/follow/stream/event/resume 命名的函数 109 个（含测试）。
- 合计：**直接以作业/事件/流为对象的测试 ≈ 110–130 条，占 886 的 ~13–15%**；连同 wire 层普遍带 job 形状的 e2e，约 20% 的测试面为 Job/Flow 服务。

### 3.3 决策与文档

- ADR 7 份（约 1000 行）：`ADR-018`（写操作即 Job）、`ADR-019`（流交付策略与 Reset）、`ADR-020`（错误归一）、`ADR-027`（查询/命令/流三模式）、`ADR-038`（GC 与读门）、`ADR-040`（字节流标签）、`ADR-057`（作业事件耐久）。
- 工程文档：`IPC_STREAM_POLICY.md`（106）、`IPC_JOB_FOLLOW_MODEL.md`（137）、`JOB_FLOW_SCENARIO_REVIEW.md`（151）+ 本报告；`RFC-0002` 的 jobs/streams 章节、`FEATURES.md §3`、`EXIT_CODES.md` 的 14/15 号码。

### 3.4 轮次投入

R44–R53（job/event/follow/resume 上 wire）→ R66（流帧逐字 parity）→ R71/R76–77（方言/请求单源）→ R89–R103（客户端泵/期限/帧关联校验族，约 15 轮）→ R105（实测重估）→ R106（jobs.list）→ R107–R110（ADR-057 四切片）。**约 25+ 轮 ≈ 110 轮的 1/4 投入在 Job/Flow。**

---

## 4. 维护难度评估

### 4.1 结构性成本一：同一事实四处呈现，四处有逐字裁判

一个作业事件在 `jobs.events` 页、follow DATA 帧、support bundle 行、job-log 持久化记录**四处**呈现；工程上刻意用同一渲染源（`bundle::render_job_event`，R66/R109）保证一致，并用逐字 parity 裁判钉住。**代价**：改一次事件行格式 = 四组裁判一起动。这是刻意选择（一致性 > 局部自由），维护成本是常量而非随功能增长。

### 4.2 结构性成本二：帧关联校验族——每接一个新帧就长一条门禁

R94–R97 系列证明：wire 单会话多路复用下「信帧 kind 不信帧内容」的每一个残留都是一个真洞（别流事件打印成本流、别流 END 定退出码）。于是流路径每一帧（opened/DATA/END/ack）都有 id 关联裁判 + 结构门禁。**代价**：想动流协议 = 先读 4 条裁判判据；想加新帧 = 默认也要带关联校验。这是复杂度税，但付在了该付的地方。

### 4.3 结构性成本三：跨进程耐久把「简单功能」升级成了「带边界的子系统」

R107–R110 把作业历史从内存态变成 D3 落盘 + 启动恢复 + 留存回收 + GC 边界裁判。**代价**：新增「坏记录启动拒绝」「GC 不碰 job-log」「kill-9 后三查询面全命中」等边界必须长期持有；上轮 falsify 的 mtime 事故（变异二进制被 cargo 当最新、门禁跑污染产物）说明测试基建本身的复杂度是 Job/Flow 复杂度的直接投影。

### 4.4 结构性成本四：计数棘轮与文档寄存器

每加一条测试，要同步 census 表、TEST_FLOOR、CENTERLINE 断言数、ROADMAP 快照、FEATURES、IMPLEMENTATION_STATUS、ONBOARDING_NOTES、CHANGELOG 至少 8 处，`check.sh` 带两个生成器 `--check`。**代价**：Job/Flow 相关测试占 13–15%，是棘轮最大的单一贡献者。但这是全项目统一纪律，不是 Job/Flow 独有。

### 4.5 维护难度总评

**高在深度、低在广度**：Job/Flow 的每一行行为都有裁判，改动的风险是可预判的（改哪、谁红、为什么红，文档里都有判据）；真正危险的维护事故（falsify 污染产物、mtime 还原）出在**测试基建**而非 Job/Flow 本身。若把 Job/Flow 比作一笔投资：前期资本支出高（25 轮），但现在进入的是一段**维护期**——收益（用户面便利）持续、边际维护成本主要花在「别改坏」。

---

## 5. 必要性判定（分级）

| 功能 | 判定 | 依据（实测/成本） |
|---|---|---|
| 写操作即 Job + acceptance 秒回 | **不可删** | RFC-0001 事务不变量；同步 RPC 无法表达长部署（§2.1/2.5） |
| 事件流 + 进度/警告/失败身份 | **不可删** | 44 事件、8 警告、probe 可见；失败码映射退出码（§2.3） |
| jobs.list 发现面 | **刚需（已补）** | §2.2；不记 id 可找回，CI/多客户端场景 |
| jobs.events 分页 | **必要（保留）** | §2.4；脚本/UI 分页底座。与 follow 共用投影，增量成本近零 |
| follow 流（同步组合面） | **刚需** | §2.5；0.18s 阻塞到终态 + 实时进度，两行命令=同步部署 |
| resume/ack 状态机 | **冻结** | §2.6；同生命重连有价值，跨重启后旧 stream id 无意义（fresh follow 即可）。**不再投功能，不删** |
| 跨重启持久化（D3+恢复+GC 边界） | **刚需（已闭环）** | §2.8；R105 P0 → 实测 kill-9 后全在 |
| 幂等键 | **不可删** | §2.1；CI 重试安全的基石 |
| rollback/gc/doctor/bundle 的 job 化 | **必要（设计正确）** | §2.7；共用一套心智模型，认知成本一次付清 |

**未闭环的缺口不在 Job/Flow 核心，而在周边可达性**：
- ~~CLI `--role`（分权机制 wire 层有效、用户面够不到——P1）~~ **同日 R112 已落地**（默认 admin 保持兼容；「默认 viewer」翻转留待认证配套）；
- 流式 END 帧携带 failure_code（流式失败只有笼统 exit 1，须 wire 形状 ADR——小改）；
- `apply` 无 `--wait`（同步组合要两行命令；文档化 compose 模式即可，不必改协议）。

---

## 6. 结论与后续开发建议

1. **保留 Job/Flow，判定为「必要且已到维护期」**。用户便利（§2 全节实测）与代码/维护成本（§3/§4）成比例；成本大头已沉淀为裁判资产，边际维护成本可预期。
2. **主体冻结**：不再为 Job/Flow 新增机制。明确不做：进行中作业 D1 增量持久化（ADR-057 已列为可选增量面）、第三查询动词、resume 跨重启语义扩展、多流并发 UI 之外的协议扩展。
3. **剩余投入只在这三个小缺口（按序）**：(a) ~~CLI `--role viewer|operator|admin`~~ **同日 R112 已落地**（实现取舍：默认 admin 而非本文建议的默认 viewer——翻转默认会破坏既有脚本与全部 e2e，属破坏性变更，留待认证配套时另议）；(b) END 帧 failure_code（wire 形状小扩展，先 ADR）；(c) `apply` 同步组合面文档化（`apply`+`follow` 两行范式写进 FEATURES/runbook）。
4. **轮次转向**：Job/Flow 收口后，把开发重心转到 P2（`--effect-runtime real` + 钉死资产的真核长部署 e2e——验证 resume 在真实时间维度的价值）与 ROADMAP §13#3（typed `send_request_frame`、共享 timeout scheduler——TUI 与批量脚本的前置）。这两项分别是「让已建机制在真实内核下可证」与「让多请求/多流并发成为可能」，而不是给 Job/Flow 再加肥。

---

## 7. 复现方式

```bash
cargo build --bin calyd --bin caly
D=$(mktemp -d); mkdir -p "$D/data"
calyd --data-dir "$D/data" --bind 127.0.0.1:0 --port-file "$D/port" &
A="127.0.0.1:$(cat "$D/port")"
caly apply demo-tun-profile --idempotency-key k1 --addr "$A"   # §2.1
caly jobs --addr "$A"                                          # §2.2
caly job 1 --addr "$A"                                         # §2.3
caly jobs 1 --from 0 --max 4 --addr "$A"                       # §2.4
caly follow 1 --addr "$A"                                      # §2.5
caly follow --resume 1 --addr "$A"                             # §2.6
# §2.8 崩溃恢复：kill -9 后同 data-dir 重启，jobs/job 1/jobs 1 照常
```

（慢 worker attach 窗口用 `--worker-tick-ms 400` 起 daemon 后重复 §2.5。）
