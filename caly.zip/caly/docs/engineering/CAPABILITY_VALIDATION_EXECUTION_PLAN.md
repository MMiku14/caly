# Caly Capability Validation Execution Plan

> 
> **📌 阅读提示（2026-08-31 更新）**：下方「本版状态」停留在 **2026-08-27**，仅作历史记录。
> 最新功能面与状态请以 `docs/guides/FEATURES.md`（功能说明书）与 `docs/status/IMPLEMENTATION_STATUS.md`（逐轮收口）、`docs/status/CENTERLINE_PROGRESS.md`（主链进度）为准；量化基线为 **862 测试 / floor 862**。本文保留其设计与实施基线价值。


> **本版状态（2026-08-27）**：`§6` 的 `RequiredCapability` / `RequiredCapabilitySet` /
> `CapabilityDecision` / `CapabilityEvaluationReport` 与 `§5.1~5.3` 的分层已由
> `caly-cap/src/eval.rs` + `caly-pipeline` 的 `CapabilityValidationReport` 承载，
> 求值结果已进入 apply gate（`worker.rs` 在 blocked>0 时拒绝入队后执行）。
> `§5.4` 的 explain/doctor 出口已可用；`§8` 的 fallback 影响 apply 升级仍是部分实现。
> 另注：`capability-registry.json` 现在会被 `caly-cap/src/json.rs` 解析并有漂移门禁，
> 但执行路径仍读 `default_registry_document()`，见 `docs/history/ONBOARDING_NOTES.md §3.5`。

本文件专门说明 Caly 如何把 RFC-0004 中定义的 Capability / Coverage 体系，从“注册表与状态模型”推进为**真正参与中心主链决策的执行层**。

它关注的不是能力目录本身，而是：

```text
ResolvedProfile
  -> Feature Extraction
  -> Capability Requirement Set
  -> Registry / Coverage Evaluation
  -> Validation Report
  -> Lower / Emit / ApplyPlan Gate
```

---

## 1. 为什么现在必须单独推进这条线

当前代码已经有：

- `caly-cap` registry schema / loader / validator
- `caly-core::CapabilitySet`
- `caly-pipeline::validate_capabilities(...)`
- mihomo / sing-box / mock adapter 的 capability descriptors

但当前仍然存在一个关键差距：
> capability validation 还没有完全由 registry / coverage matrix 驱动，而仍部分依赖 vertical slice 内的局部规则。

这会带来三个问题：

1. 文档说“Registry 是唯一事实来源”，代码却还没有完全做到
2. 同一特性在不同 adapter / pipeline 分支里可能逐渐分叉
3. strict mode 的阻断条件还没有被系统化表达

因此，这条线现在必须单独拉出来推进。

---

## 2. 本文关注的目标链

```text
Profile / Source / Override
  -> Merge / Resolve
  -> ResolvedProfile
  -> Extract Required Features
  -> Match Capability Keys
  -> Evaluate support state + support level + fallback
  -> Produce validation diagnostics/issues
  -> Gate compile / apply planning / runtime exposure
```

---

## 3. 当前已具备的工程基础

### 3.1 数据模型基础

当前已有：

- `CapabilityKey`
- `CapabilityDomain`
- `SupportLevel`
- `CapabilityState`
- `Constraint`
- `FallbackPolicy`
- `EvidenceRef`
- `CapabilityDescriptor`

### 3.2 代码基础

当前已有：

- `capability-registry.json`
- `coverage-matrix.json`
- `validate_registry_document(...)`
- `validate_coverage_matrix(...)`
- adapter `capability_set(...)`
- `validate_capabilities(...)`

### 3.3 当前已显式出现的能力样例

- `dns.fake_ip`
- `routing.rules`
- `network.tun`
- `runtime.group.select`
- `outbound.wireguard`

这些样例已经足够作为 capability execution path 的第一批真实落点。

---

## 4. 当前真正缺的部分

当前最主要缺口不是“再添加更多 key”，而是以下四件事：

### 4.1 缺 Feature Extraction 层

当前 `ResolvedProfile` 还没有系统地投影成“需要哪些 capability key”的稳定中间结果。

### 4.2 缺 Registry-Driven Evaluation 层

当前验证还不是统一从 registry / coverage matrix 求值，而更多像：

- profile 某字段存在
- then 手工判断某 key 是否在 adapter capability set 中

这还不够。

### 4.3 缺 fallback 执行边界

文档已经定义了：

- `PreserveOpaqueSameCore`
- `RequireDropFlag`
- `UseNativeOnlyMode`
- `EscalateToRestart`
- `DisableRuntimeFeature`

但这些 fallback 现在还没有真正进入 pipeline / apply planning 的决策闭环。

### 4.4 缺 capability -> explain / doctor / CLI 统一出口

当前 capability 还没有形成一个稳定的对外解释对象，导致：

- doctor 只能给抽象文字
- explain pipeline 还不能充分解释“为什么此能力被允许/阻断”
- CLI/TUI 后续难以共享同一判定结果

---

## 5. 推荐的执行分层

### 5.1 Layer A — Feature Extraction

输入：`ResolvedProfile`

输出：`RequiredCapabilitySet`

建议至少提取：

- routing mode requirement
- DNS mode requirement
- TUN requirement
- selected runtime mutation requirement
- node protocol requirements
- outbound kind requirements
- inbound kind requirements
- native-only passthrough requirements

建议结构：

```text
RequiredCapability {
  key,
  reason,
  strictness,
  source_path,
}
```

其中：

- `key`：稳定 capability key
- `reason`：为什么需要该能力
- `strictness`：Hard / Soft / Informational
- `source_path`：可选，用于 explain/doctor

### 5.2 Layer B — Registry Evaluation

输入：

- `RequiredCapabilitySet`
- target core identity
- adapter version
- platform facts
- registry / coverage matrix

输出：`CapabilityDecisionSet`

建议每个决策至少包含：

- capability key
- state
- support level
- matched evidence
- fallback policy
- blocked reason
- remediation

### 5.3 Layer C — Pipeline Gate

输入：`CapabilityDecisionSet`

输出：

- diagnostics
- core issues
- whether compile may continue
- whether apply planning must escalate

关键要求：

- `Unsupported` MUST 阻断
- `Unknown` 在 strict 下 MUST 阻断
- `Experimental` SHOULD 默认警告或阻断，取决于策略
- `SupportedNativeOnly` 允许继续，但必须可解释
- `PreservedOpaque` 只允许在目标一致且策略允许时继续

### 5.4 Layer D — Downstream Consumers

求值结果必须继续被下游消费：

- `Lower / Emit`
- `ApplyPlan` 选择
- `ExplainPipeline`
- `Doctor`
- `core capabilities` 查询
- future TUI capability UI

---

## 6. 推荐的最小类型集合

为了把这条线从文档推到代码，建议引入以下对象：

### 6.1 `RequiredCapability`

至少包含：

- `key: CapabilityKey`
- `reason: String`
- `strict: bool`
- `origin: Option<IrPath>`

### 6.2 `RequiredCapabilitySet`

职责：

- 收集去重后的 required keys
- 保留每个 key 的来源理由
- 支持 explain/doctor 输出

### 6.3 `CapabilityDecision`

至少包含：

- `key`
- `state`
- `support_level`
- `fallback`
- `reason`
- `remediation`
- `evidence_summary`

### 6.4 `CapabilityEvaluationReport`

至少包含：

- `required[]`
- `decisions[]`
- `blocked_count`
- `warning_count`
- `informational_count`
- `may_compile`
- `must_escalate_apply`

---

## 7. 与当前 centerline 的接线点

### 7.1 在 `resolve_ir(...)` 之后

因为只有 `ResolvedProfile` 形成后，才能稳定分析：

- 真实 routing mode
- 真实 group selection
- 真实 outbound/inbound/protocol
- 真实 tun/dns 状态

所以 feature extraction 应在 `resolve` 之后，而不是更早。

### 7.2 在 adapter compile 之前

因为 capability validation 的职责之一是决定：

- 是否允许继续 compile
- 是否必须转向 native-only mode
- 是否必须拒绝跨-core 或 strict deployment

所以它必须位于 compile 之前或与 compile orchestration 紧密耦合。

### 7.3 在 apply planning 之前继续保留结果

因为 fallback 与 state 可能影响：

- `ApiPatch`
- `HotReload`
- `Restart`
- `RebuildAndRestart`

例如：

- `network.tun` -> 可能要求升级到 restart / network-aware path
- `outbound.wireguard` native-only -> 可能要求 native-only deployment mode
- runtime mutation unsupported -> 禁止 `ApiPatch`

---

## 8. fallback 不应只停留在文案层

当前必须明确：fallback 不是文字备注，而是决策输入。

### 8.1 `UseNativeOnlyMode`

含义：

- 继续部署，但要求保留 native extension/passthrough 形态
- 对 explain/doctor/CLI 必须明确显示

### 8.2 `EscalateToRestart`

含义：

- capability 本身可能支持，但其使用禁止热路径
- apply planning 必须升级为更保守路径

### 8.3 `DisableRuntimeFeature`

含义：

- runtime facade / watch / control plane 某能力对用户不可用
- 但静态部署本身仍可允许

### 8.4 `PreserveOpaqueSameCore`

含义：

- 同 core 回写可继续
- 跨 core 迁移必须阻断

---

## 9. explain / doctor / CLI 的统一输出要求

一旦 capability execution path 建立，对外最少要能给出：

- `required capability`
- `actual state`
- `support level`
- `why required`
- `why blocked`
- `fallback chosen`
- `recommended remediation`

示例语义：

```text
capability=dns.fake_ip
required_by=resolved dns mode fake-ip
state=SupportedExact
support_level=CalyManaged
result=allow
```

```text
capability=outbound.wireguard
required_by=node protocol wireguard
state=SupportedNativeOnly
support_level=NativeManaged
fallback=UseNativeOnlyMode
result=allow-with-warning
```

```text
capability=runtime.group.select
required_by=persisted group selection
state=Unsupported
result=block
remediation=remove runtime selection dependence or switch target core
```

---

## 10. 推荐的三阶段实施顺序

### Stage 1 — Required Feature Projection

交付物：

- `ResolvedProfile -> RequiredCapabilitySet`
- 第一批 capability extractor：
  - dns
  - tun
  - routing.rules
  - runtime.group.select
  - outbound.wireguard

完成定义：

- capability validation 不再手工散落判断 profile 字段，而是先生成 requirement set

### Stage 2 — Registry-Driven Evaluation

交付物：

- capability evaluator
- decision report
- strict mode gate
- fallback projection

完成定义：

- `validate_capabilities(...)` 可以统一从 evaluator 生成 diagnostics/issues

### Stage 3 — Downstream Integration

交付物：

- explain pipeline capability section
- doctor capability diagnostics
- apply planning escalation hook
- core capability query report

完成定义：

- capability 不只决定“能不能过”，还能解释“为什么这么过”

---

## 11. 当前阶段的完成定义

只有满足以下条件，才能说 capability validation 真正进入执行阶段：

1. `ResolvedProfile` 可稳定投影为 required capability set
2. registry / coverage matrix 真参与求值
3. strict mode gate 不再依赖局部 if/else
4. fallback 会影响 compile / apply / runtime exposure
5. explain / doctor / CLI 可共享同一 capability decision output

---

## 12. 一句话结论

> Caly 的 capability system 下一步不该继续停留在“有 key、有状态”，而要推进成 `ResolvedProfile -> Requirement -> Registry Evaluation -> Decision -> Apply Gate` 的真正执行链。