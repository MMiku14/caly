# 使用场景报告：网关运维的一天（全产品用户面实测）

> 本文是**用户视角**的全产品场景实测报告：以官方 CLI `caly` + 守护进程 `calyd` 两个真二进制，把「管理一台无头网关上的 caly」这件事按五个运维日场景完整走一遍，逐条记录命令、原始输出与退出码。与前两篇的边界：`JOB_FLOW_SCENARIO_REVIEW.md` 专注 Job/Flow 的机制重估，`JOB_FLOW_COST_BENEFIT_REPORT.md` 专注成本收益判定，**本篇专注「一个运维从早到晚实际会怎么用、每一步看到什么、哪里顺畅、哪里撞墙」**。
>
> 日期：2026-09-01。基线：886 tests / floor 886。环境：`--effect-runtime simulated`（默认，零宿主副作用）；真实内核下的行为差异在文中标注。所有输出均为真实执行结果。

---

## 1. 场景总览

| 场景 | 一句话 | 用到的动词 |
|---|---|---|
| A. 新网关首次上线 | 从裸机到第一版配置生效并确认快照 | `calyd`、`status`、`profiles`、`profile`、`apply`、`jobs`、`job`、`follow` |
| B. 订阅接入日 | 给 daemon 喂订阅源，看用户面能看到什么 | `calyd --source-endpoint`、`status`、`doctor`、`profiles` |
| C. 变更与回滚日 | 改配置、幂等重试、不满意回滚、日常体检 | `apply`、`rollback`、`gc-plan`、`gc`、`doctor`、`support-bundle`、`bundle` |
| D. 故障演练日 | kill -9 崩溃恢复 + 历史审计 + 慢作业实时观察 | `kill -9`、`status`、`jobs`、`job`、`follow` |
| E. 脚本化运维日 | CI/脚本怎么用退出码、JSON、分页、同步等待 | 全部 + `--json`、`--from/--max` |

---

## 2. 场景 A：新网关首次上线

**目标**：起服务、看清运行时状态、应用第一版配置、确认部署过程与最终快照。

```
$ calyd --data-dir /tmp/a/data --bind 127.0.0.1:0 --port-file /tmp/a/port
calyd: listening on 127.0.0.1:40601 (data: /tmp/a/data, effect-runtime: simulated)

$ caly status
core_running: false            active_profile:（空）
active_core:（空）             active_snapshot:（空）
pending_recovery_decisions: 0  last_recovery_summary: recovery scan clean
```

九字段全上屏，空值也显式呈现（能区分「没有」和「忘了」）。首版配置：

```
$ caly apply demo-tun-profile --idempotency-key k1
job_id: 1    state_revision: 1    estimated_impact: Restart        exit=0
```

acceptance 秒回（真实内核下这一步之后是数十秒的后台部署，不占终端）。观察部署：

```
$ caly jobs
jobs: 1
  1  completed  100%  events=44                                   exit=0

$ caly job 1
state: completed  next_event_index: 44  event_count: 44
last_stage: snapshot.committed snapshot:rev:a22ede834cd24915 revision=rev:a22ede834cd24915
last_stage_pct: 100  warning_count: 8  log_count: 25

$ caly jobs 1 --from 0 --max 4
  - [stage 10%] pipeline.resolve profile=demo-tun-profile
  - [stage 25%] capability.validate required=8 warn=1 blocked=0
  - [log:info] capability routing.rules=Allow/SupportedExact/CalyManaged
  - [log:info] capability dns.fake_ip=Allow/SupportedExact/CalyManaged
next_from_event_index: 4
```

**体验**：44 个事件把「解析 → 能力校验（8 必填、1 警告、0 阻塞）→ 部署计划 → 效果执行 → 探针 → 快照提交」整条链摊开给用户看，进度百分比与快照号都在——一次部署变成一份可读的审计记录。

**观察到的怪癖（记录在案，见 §7）**：`caly profiles` 只列 `default-profile`，但 `caly profile demo-tun-profile` 可查、`apply` 可用——列表与查询面不一致；`caly profile nonexistent` 不报错，回显所问 id 并配默认视图，exit 0。
**（2026-09-01 更新，R113 已修）**：`profiles.get` 契约收窄——注册表（`default-profile` ∪ active）之外的 id 现在按名拒绝（`CONFLICT`/`no such profile: <id>`，exit 4），列表与查询面同源一致；`demo-tun-profile` 在 apply 注册后即可查、可列。见 `ONBOARDING_NOTES §4.187`。

---

## 3. 场景 B：订阅接入日

**目标**：把订阅源（airport 订阅）交给 daemon，看导入结果在用户面长什么样。

```
$ calyd --data-dir /tmp/b/data --bind 127.0.0.1:0 --port-file /tmp/b/port \
        --source-endpoint "airport=http://127.0.0.1:8123/subscription-20260803.txt"
calyd: listening on 127.0.0.1:46063 (data: /tmp/b/data, effect-runtime: simulated)
```

端点注册本身不报错。然后逐个查询面找它的影子：

```
$ caly status   → 无任何 source 字段
$ caly doctor   → storage/recovery/idempotency/gc 四个面，无 source 面
$ caly profiles → 仍只有 default-profile；无新 profile 出现
```

落盘侧同样安静：data-dir 里只有 schema 记录，没有拉取/解析产物；daemon 日志无 source 活动行。

**体验**：**订阅管道在 daemon 侧存在（`--source-endpoint` 可注册、engine 有 source worker 与 durable source index、有 SSRF 边界裁判），但用户面没有任何动词能看到它**——拉没拉到、解析过没过、节点数多少、什么时候刷新的，全都不可见。运维的「订阅接入日」当前是个黑盒步骤。这是全产品最显眼的用户面缺口（与 §7-3 同条）。

**（2026-09-01 更新，R114 已修）**：`caly sources` / `caly source <id>`（wire `sources.list`/`sources.inspect`）已上线。同一形态的 daemon（`--source-endpoint airport=<订阅URL>`）上实测：

```
$ caly sources
sources: 3
  airport  Source airport  (subscription)
  default-profile-src-primary  Primary Source RuleSet  (subscription)
  default-profile-src-fallback  Fallback Source RuleSet  (subscription)

$ caly source airport
source_id: airport
label: Source airport
kind: subscription
locator: http://example.test/subscription-20260803.txt
route: direct
etag: never
raw_stored_at_unix_ms: never        ← 未拉取就是「never」，不是空白
normalized_node_count: 0
warning_count: 0

$ caly source nightshift            ← 注册表外的 id
caly: refused (CONFLICT): no such source: nightshift   exit=4
```

注册表 = worker 端点（`--source-endpoint` 注册 ∪ durable index 恢复）∪ profile workflow 引用的 source；列表与查询同源一致（R113 对 profiles 的同一契约搬到 sources）。「接入日」从黑盒变成：注册 → `caly sources` 见到名字 → `caly source <id>` 看到拉取事实。`source update`（触发拉取）的用户面动词仍未上线（拉取走 job 命令，SSRF 边界对 loopback 保守拒绝，需要 scope 配置面后才有意义）。

---

## 4. 场景 C：变更与回滚日

**目标**：再改一次配置、验证幂等重试、回滚、日常体检。

```
$ caly apply demo-tun-profile --idempotency-key k1        ← 同 key 重放
job_id: 1    state_revision: 1                             ← 同一个作业原样回，exit=0
$ caly apply demo-tun-profile --idempotency-key k2        ← 新 key
job_id: 2    state_revision: 3                             ← 新作业（25 事件）
$ caly apply demo-tun-profile --idempotency-key ...       ← 忘了 key
caly: profiles.apply needs --idempotency-key <k>; ...      exit=2
```

**体验**：幂等键语义干净——CI 重试不会重复部署；忘 key 立刻被点名（exit 2），不浪费一次往返。回滚：

```
$ caly rollback --snapshot rev:a22ede834cd24915 --idempotency-key rk1
job_id: 3    state_revision: 5    estimated_impact: Restart
```

体检与清理：

```
$ caly gc-plan     → grace_period_ms: 900000  max_deletions: 256  objects_total: 1 ...
$ caly gc --idempotency-key gk1            → job_id: 4  estimated_impact: ReadOnly
$ caly doctor      → storage audit / recovery / idempotency / gc 四个面，warnings: 0 errors: 0
$ caly support-bundle --idempotency-key bk1 → job_id: 5
$ caly bundle      → digest==content_sha256、78 行脱敏、truncated: false
```

**体验**：破坏性操作一律「先计划（gc-plan 只读）后执行（gc 铸 job）」；体检四层一眼扫完；诊断包读回自带完整性校验——运维最怕的「清理错东西」「导出的包被动过」在这里被协议层按住。

**观察**：同一 profile 的第二次 apply 只有 25 个事件（首版 44 个）——增量语义在事件流里可见（第二次没有重新解析/能力判定的全部步骤），这是合理优化而非缺陷，但对「对比两次部署」的脚本要注意事件数不恒定。

---

## 5. 场景 D：故障演练日（kill -9 崩溃恢复）

**目标**：模拟最坏情况——daemon 被 SIGKILL——然后验证「状态在、历史在、审计在」。

```
$ kill -9 <calyd pid>
$ calyd --data-dir /tmp/a/data --bind 127.0.0.1:0 --port-file /tmp/a/port2    ← 同 data-dir 重启

$ caly status
active_profile: demo-tun-profile
active_snapshot: snapshot:rev:a22ede834cd24915
last_recovery_summary: recovery scan clean

$ caly jobs
jobs: 5
  5  completed  100%  events=16
  4  completed    0%  events=3
  3  completed  100%  events=5
  2  completed  100%  events=25
  1  completed  100%  events=44

$ caly jobs 1 --from 40 --max 4        ← 重启后翻页照常
$ caly follow 1                        ← 重启后重放照常（44 行）
$ caly apply demo-tun-profile --idempotency-key k3
job_id: 6                              ← 新作业 id 不与恢复的 1–5 撞号
```

**体验**：部署状态（active profile/snapshot）与**过程历史（5 条作业、各自事件流）**在 SIGKILL 后全部原样可查。R105 实测时这里的答案是 `refused (CONFLICT): no such job: 1`——那个最高优先级缺口已闭环（ADR-057，R109/R110）。**「升级/崩溃/跨天回看」这三个 flow 最该发光的场景，现在真的发光。**

错误面（脚本分流友好）：

```
$ caly job 99    → caly: refused (CONFLICT): no such job: 99            exit=4
$ caly follow 99 → caly: refused (NOT_FOUND): job 99 does not exist; ... exit=13
```

慢作业的实时窗口（`--worker-tick-ms 400` 起 daemon 模拟真实内核节奏）：

```
$ caly apply ... ; caly jobs            → 1  accepted  -  events=0    ← 后台跑着
（0.9s 后）$ caly jobs                   → 1  completed  100%  events=44
```

**体验**：部署「在后台跑、可中途 attach」的窗口真实存在——真实内核下这是数十秒，运维可以提交后立刻开另一台终端跟进度。

---

## 6. 场景 E：脚本化运维日

**目标**：验证 CI/脚本最关心的三件事——退出码可信、JSON 可解析、能同步等待结果。

退出码实测表（本场景全部实拍）：

| 情形 | 命令 | 退出码 | 含义 |
|---|---|---|---|
| 成功 acceptance | `caly apply ... --idempotency-key k` | 0 | 已受理 |
| 成功跟到终态 | `caly follow <id>` | 0 | 作业终态 Succeeded |
| 缺幂等键 | `caly apply demo-tun-profile` | 2 | usage，stderr 点名缺什么 |
| 查不存在的作业 | `caly job 99` | 4 | CONFLICT |
| 跟不存在的作业 | `caly follow 99` | 13 | NOT_FOUND |

机器面：

```
$ caly job 1 --json
{"request_id":"1","job_id":"1","state":"completed",...,"event_count":"44",...}
（v0 记录方言：JSON 值全为字符串，消费方需自行转型——已知简化，文档化行为）
```

同步等待的推荐姿势（两行组合）：

```
job=$(caly apply demo-tun-profile --idempotency-key "$KEY" | sed -n 's/^job_id: //p')
caly follow "$job"          # 阻塞到终态，按判决给退出码（实测 0.18s 内完成）
```

**（2026-09-01 更新，R115 已修）**：`caly apply <id> --idempotency-key <k> --wait` 把这两行合成一条命令——acceptance 三字段先上纸，随后同一会话开 follow 流把事件照打、按流判决退出码（Succeeded 0 / Failed 1 / Cancelled 15 / TimedOut 11 / 状态缺口 14），`--wait --json` 同样逐行原文。协议不动：仍是同一连接上的两个请求。`--wait` 只属于 apply，别的动词上它是 usage（exit 2）。实测：

```
$ caly apply demo-tun-profile --idempotency-key w1 --wait
job_id: 1
state_revision: 1
estimated_impact: Restart
  - [stage 0%] running
  - [stage 10%] pipeline.resolve profile=demo-tun-profile
  ...
  - [done] Succeeded            ← exit 0
```

分页拼接：`--from` exclusive + `next_from_event_index` 透传即可逐页拼完 44 个事件，到末尾 `next_from` 为空。

**体验**：脚本化运维的主链齐了，最后一个小刺也已收（见 §7 #6）：流式失败从 R116 起按 END 帧的 `failure_code` 落精确退出码——`caly follow 1`、`apply --wait` 与一次性 `caly job 1` 对同一失败作业给同一数字（ADR-058）。脚本能依赖与不能假设的清单沉淀在 `docs/guides/SCRIPTING.md`（R117，发现 #7 的文档指引）。

---

## 7. 用户面发现清单（本报告的实测结论）

| # | 发现 | 性质 | 影响 |
|---|---|---|---|
| 1 | `caly profile <不存在>` 回显所问 id + 默认视图、exit 0，不报错 | ~~行为缺陷~~ **R113 已修** | 脚本查错 profile 名会拿假成功——本报告发现的最尖锐一条；现已按 `no such profile: <id>`（CONFLICT，exit 4）拒绝 |
| 2 | `profiles` 列表只含 `default-profile`，`demo-tun-profile` 可查可 apply 却不在列表 | ~~列表/查询面不一致~~ **R113 已澄清并修** | 列表才是真注册表（default ∪ active）；get 之前对未注册 id 也答合成视图——修法不是往列表加行，而是 get 对表外 id 拒绝，两面对齐 |
| 3 | 订阅导入（`--source-endpoint`）在用户面完全不可见（§3） | ~~用户面缺口~~ **R114 已修** | 「订阅接入日」曾是黑盒；现有 `caly sources`（注册表列表，未拉取即见）与 `caly source <id>`（单源视图，未拉取=显式 never + 0），注册表外 id 按名拒绝（CONFLICT，exit 4）。`source update` 的用户面动词仍缺（SSRF scope 配置面先决，见 §3 更新注） |
| 4 | CLI 无 `--role`，三角色分权用户够不到 | 用户面缺口 | 监控机只读/运维机可写无法落地。**本报告成文时缺失；同日已开发 `caly --role`（见 `ONBOARDING_NOTES §6.138`）** |
| 5 | `apply` 无 `--wait` 旗标，同步等待靠「apply+follow」两行组合 | ~~便利性缺口~~ **R115 已修** | `caly apply --idempotency-key <k> --wait`：acceptance 照打、同一会话跟流到终态、按流判决退出码（Succeeded 0/Failed 1/Cancelled 15/TimedOut 11/缺口 14）；纯 CLI 组合，不改协议；`--wait` 只属 apply（别处 usage exit 2） |
| 6 | 流式 END 帧无 failure_code，流式失败只 exit 1 | ~~缺口~~ **R116 已修（ADR-058）** | 无目标 rollback 失败作业：`caly job 1` exit 4、`caly follow 1` exit **4 非 1**、`--json` END 行含 `failure_code`；三条路径同一退出码 |
| 7 | 同 profile 二次 apply 事件数（25）少于首版（44） | ~~观察（非缺陷）~~ **R117 已收（文档指引）** | 事件数是部署工作量的投影——`docs/guides/SCRIPTING.md §3` 钉成脚本合同：不许假设恒定事件数/固定 stage 序列，只依赖 `[done]` 终局行、退出码与 END 帧字段 |

---

## 8. 一句话总结

**五个场景里，A（上线）、C（变更回滚）、D（故障演练）、E（脚本化）的主链全部真实可跑且体验连贯——一次部署从「敲命令」变成「一条可审计、可回滚、崩溃后仍在的事件流」；七个发现在 R112–R117 全部收口：六个代码收口（#4 `--role`、#1 profile 假成功、#3 订阅用户面、#5 `apply --wait`、#6 END failure_code（ADR-058，三条路径同一退出码），以及澄清的 #2），#7 事件数可变按文档指引收（`docs/guides/SCRIPTING.md §3` 钉成脚本合同）。**

---

## 9. 复现方式

```bash
cargo build --bin calyd --bin caly
D=$(mktemp -d); mkdir -p "$D/data"
calyd --data-dir "$D/data" --bind 127.0.0.1:0 --port-file "$D/port" &
A="127.0.0.1:$(cat "$D/port")"
caly status --addr "$A"                                   # §2
caly profiles --addr "$A"; caly profile demo-tun-profile --addr "$A"
caly apply demo-tun-profile --idempotency-key k1 --addr "$A"   # §2/§4
caly apply demo-tun-profile --idempotency-key k2 --wait --addr "$A"  # §6 R115
caly jobs --addr "$A"; caly job 1 --addr "$A"; caly jobs 1 --from 0 --max 4 --addr "$A"
caly rollback --snapshot <snap> --idempotency-key rk1 --addr "$A"  # §4
caly rollback --idempotency-key rbad --addr "$A"; caly follow 1 --addr "$A"  # §6 R116 无目标失败 -> exit 4 (CONFLICT)
caly gc-plan --addr "$A"; caly gc --idempotency-key gk1 --addr "$A"
caly support-bundle --idempotency-key bk1 --addr "$A"; caly bundle --addr "$A"
kill -9 <pid>; calyd --data-dir "$D/data" ...             # §5 同 data-dir 重启后 jobs/job 1 照常
# §3 订阅：先 cd fixtures && python3 -m http.server 8123，再加
#   --source-endpoint "airport=http://127.0.0.1:8123/subscription-20260803.txt"
caly sources --addr "$A"; caly source airport --addr "$A"     # R114 用户面
```
