# Caly IPC Stream Policy Model

本文件补充说明 Caly IPC 中最容易被低估的一层：**每种 stream 不只是 payload 不同，可靠性、ACK、Reset 和 replay 语义也不同。**

---

## 1. 为什么 stream policy 必须显式化

如果所有流都只抽象成“服务端不断发消息”，会很快出现问题：

- 有的流其实需要无损续传
- 有的流只需要最新值
- 有的流在 gap 后应 Reset
- 有的流根本不值得逐条 ACK

因此，`StreamKind` 之外还必须有 `StreamPolicy`。

---

## 2. 当前建议模型

当前代码骨架中，`StreamPolicy` 至少表达：

- `DeliveryGuarantee`
- `AckPolicy`
- `reset_on_gap`

这三者共同决定：

- 客户端是否要持久维护 seq/cursor
- 服务端是否需要保留 replay window
- slow client 时是 drop / reset / resumable 哪一种

---

## 3. 推荐默认策略

| StreamKind | Delivery | ACK | Gap | 实现 |
|---|---|---|---|---|
| Job | LosslessResumable | Required | Resume/Retry | 已落地（`job_stream.rs` 泵：Data/Gap/End/Wait，R120/R121 收口游标与 resume_from） |
| Deployment | LosslessResumable | Required | Resume/Retry | StreamKind 存在、无开启操作（无生产者，登记于 IMPLEMENTATION_STATUS §8.41） |
| Dashboard | SnapshotThenPatch | Optional | Reset | **已落地（R127）**：首拉恰一帧 `SnapshotJson`（= `runtime.status` 同一事实单源重述，seq 钉活边），后续 typed 补丁；落后保留窗点名 Reset |
| Traffic | LatestValue | None | Drop middle values | 未落地（无真实流量数据源；今天只享事件桥） |
| Logs | LossyRing | None | Drop old values | 未落地（无日志环数据源；今天只享事件桥，且每拉受 64 帧上界） |
| Connections | SnapshotThenPatch | Optional | Reset | **已落地（R127）**：首拉恰一帧 `SnapshotJson`（= `runtime.connections` 页同一事实），后续同 Dashboard |

---

## 4. 与 watch bridge 的关系

watch bridge 不应只做 payload 翻译，还应该知道：

- 当前 stream kind 的 policy
- 当前 seq / retained window
- 是否需要 reset
- 是否允许 ack

否则协议行为会散落到：

- session
- handler
- engine event layer
- UI client

多处条件分支里。

---

## 5. 与 session cursor 的关系

对支持 replay 的流，session 层通常还需要维护：

- `last_emitted_seq`
- `acked_upto`
- reopen / reconnect 时的 preferred resume position

这说明 `StreamPolicy` 不只是“静态说明”，还会影响 session runtime 行为。

### 5.1 游标极性：请求游标是排他的（第一百二十轮钉死）

`slice_job_events` 的 `from_event_index` 语义是**排他请求游标**：「我已经拥有到 N」——回答从 N+1 开始。
所有回读这个字段的路径必须喂「已交付/已确认到的最后索引」，而不是「我下一个想要的索引」；两者恰好差一，
而差一就是静默丢一行。第一百二十轮的真核 e2e 就这样丢过：泵把「活边沿（下一个未交付）」当游标喂回去，
活窗边读边长时恰好跳过落在边沿后的第一条事件；空首页把 retained 边沿当游标，首事件到达即被跳过。
修复后的统一约定（`job_stream.rs` 是唯一事实源）：

- 泵的 `cursor()` 与 DATA 帧 `next_event_index` 记录一律是「已交付到的最后索引」；
- 截断页 `next_from_event_index` 本就是「最后返回的索引」，直接透传；
- 空页不设游标（「什么都没交付」回读开流位置，而不是种子一个边沿）；
- ACK 的 `acked_upto` 因此也是「已交付到的最后索引」，resume 把它原样喂回 `from_event_index` 即得
  「从第一条未确认事件起重放」——at-least-once 的重放窗口与 ack 边界精确对接，无丢无重。

state-gap 的 `resume_from` 同样是排他游标（第一百二十一轮收口，曾是最老保留行的**索引**——直接喂给
`--from` 会跳过该行本身）：泵现在交付「下一次读恰好落在最老保留行上」的游标值（retained 边沿减一；gap 只在
已裁掉 ≥2 条时触发，故不会下溢），CLI 提示把它原样交给操作员。裁判：
`job_stream::a_gap_hands_back_a_cursor_that_lands_on_the_oldest_retained_line`（真 slice+真泵+回喂组合）、
`caly_cli_e2e::a_state_gap_end_names_the_cursor_to_resume_with`（提示逐字透传）。

---

## 6. 当前 skeleton 已有基础

当前骨架已开始具备：

- `StreamKind`
- `StreamPolicy`
- `AckPolicy`
- `DaemonSession::opened_streams`
- `StreamCursorState`
- `watch_bridge`

这说明 stream 已经不再是“单向打印消息”，而开始接近正式协议对象。

---

## 7. 仍需补齐的关键点（2026-09-02 更新）

1. ~~ACK 的推进窗口与 resend 语义~~ 已有实现：`StreamCursorState`（apply_ack 单调推进、preferred_resume_from 按 policy 折叠 acked/emitted/explicit 三源）+ v0 隐式 ack（有序连接）；显式 ack 帧走 `StreamAck`
2. ~~job stream retained/reset 细则~~ 已收口（R120/R121：`JobStreamPump` 的 Gap/End/Wait 与 resume_from 落点裁判）
3. ~~dashboard/connections 的 snapshot first frame 约定~~ 已收口（R127：首拉恰一帧 `SnapshotJson`，同一查询单源，seq 钉活边，历史折入不重发）
4. ~~slow client 触发 reset 的正式策略~~ 已收口（R127：引擎 256 事件保留窗 + 每拉 64 帧上界 + 落后保留窗点名 `Reset{StateGapTooLarge}`，裁判可达）

5. ~~Deployment 流的生产者~~ 已收口（R130：`RuntimeSubscription::Deployment` 经真请求路径开流；watch bridge 的逐帧生产语义=按 kind 过滤——只在该流的主题事件（`DeploymentChanged`）发生时铸帧，seq/恢复/Reset 沿共享事件窗；裁判 `crates/caly-daemon/tests/deployment_stream.rs` 4 胎，`overload` 两类生产者同轮落地：窗滚动=engine 记 `EventBacklog`、Reset 铸造处=bridge 记 `StreamBackpressure`，`OVERLOAD_AND_RETRY_MODEL §3.2/§3.3` 首次有真实生产者）

剩余：Traffic/Logs 的专有生产语义（待真实数据源——mihomo/sing-box 的流量与日志 API 面尚未设计接入，接入轮一并定义 LatestValue coalesce 与 LossyRing 语义）。

---

## 8. 一句话结论

> Caly 的 stream 不是一个统一广播管道，而是一组带有不同可靠性契约的协议面。