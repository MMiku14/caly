# Caly App Client Layer

本文件说明为什么在 `caly-api` 之外，还需要一个更面向调用路径的 **app client layer**。

> **📌 阅读提示（2026-08-31 更新）**：app client layer 已随 LocalApi/RemoteApi/CLI 接线推进；最新落地与边界见 `docs/guides/FEATURES.md §2/§3`、`docs/engineering/REMOTE_FACADE_PARITY.md`、`docs/status/IMPLEMENTATION_STATUS.md`。


---

## 1. 背景

`caly-api` 负责：

- Facet
- DTO
- Operation
- Error boundary

但它本身不应承担：

- daemon transport glue
- client session state
- hello / stream / ack runtime 行为
- loopback integration glue

因此，需要一个上层 client layer 来组织：

- `LocalAppClient`
- `RemoteSessionClient`
- `RemoteFacade`
- `LoopbackRemoteTransport`
- contract / follow glue

---

## 2. 推荐分层

```text
caly-api       只定义接口与 DTO
caly-ipc       定义核心协议与 client/server session primitive
caly-daemon    定义 server-side app / transport / session glue
caly-app       定义 local/remote client assembly
```

这层次可以避免：

- 把 remote glue 塞进 `caly-api`
- 把 CLI/TUI 直接耦合到 daemon transport
- 把 loopback harness 逻辑分散在各 crate

---

## 3. 当前 skeleton 已具备的能力

当前已开始具备：

- `LocalAppClient`
- `RemoteSessionClient<T>`
- `RemoteFacade<T>`
- `LoopbackRemoteTransport`
- `LoopbackHarness`
- `run_basic_parity_check(...)`
- `run_system_contract(...)`
- `run_job_follow_contract(...)`

这说明 app client layer 已经开始形成。

---

## 4. 一句话结论

> `caly-api` 负责定义契约，`caly-app` 负责把契约装配成真正可调用的 local/remote client。