# Caly TUI 规划（Phase 9 / `caly-tui`）

> 状态：**Planned，未实现**（`ROADMAP §10` / `IMPLEMENTATION_STATUS` CLI 行）。本文件是规划，不是
> 实现许可：`ROADMAP §12` 把 TUI 排在里程碑 **7（最后）**，硬约束是「在 Phase 5/6/8 进一步闭环前，
> 不让 TUI 反向驱动架构偏航」。本规划的唯一目的，是让**真到要做 TUI 的那一轮**能直接照此切片、照此
> 证伪，而不临时发明架构。

---

## 1. 一句话定位

`caly-tui` 是 `calyd` 的**又一个 wire 客户端**，与 `caly`（CLI）平级——不是 daemon 的内嵌界面，也
不读 storage/engine 内部。它消费的**每一个事实**都必须是 `caly` 今天已经能在 stdout 上打印、或
`calyd` 已经在 wire 上回答的东西。如果 TUI 需要一个 CLI/wire 还没有的事实，正确动作是**先在
daemon/wire 上开口子（独立一轮、带自己的证伪）**，而不是让 TUI 伸手进内部。

## 2. 非目标（明确不做）

- **不**让 TUI 成为新的事实来源：不直接开 `caly-storage`、不直连 effect runtime、不绕过
  `FramePump`/握手/角色闸（R87–R92 建立的边界 TUI 一律继承）。
- **不**为 TUI 发明新的授权/角色路径：TUI 握手声明的角色与 `caly` 一样走 hello `role=`，
  Admin-only 动作（apply/rollback/gc/shutdown）在 `Operator` 角色下必须被 daemon 以 `PERMISSION`
  拒绝并在界面上如实呈现（R92 已让线端角色闸生效）。
- **不**在 Phase 9 之前提前实现；本文件不产生 `[[bin]]`、不产生 crate。
- **不**引入外部 crate 而无 ADR（见 §6）。

## 3. 架构与依赖边界（硬约束）

- 新成员 `caly-tui`，依赖**只能**落在 arch-test 的 `ALLOWED_*` 表内。预期形态：
  - `caly-tui` → `caly-ipc`（`BindSpec`/`WireStream`/`FramePump`/dialect/`--json` 记录）、
    `caly-api`（`Operation`/角色/退出码类型）、`caly-common`。
  - **禁止** `caly-tui` → `caly-daemon` / `caly-storage` / `caly-engine`（TUI 是远端客户端，不是
    库消费者；LoopbackHarness 是 daemon 测试设施，不是 UI 的数据源）。
  - 依赖边新增前先在 `crates/caly-arch-test/src/lib.rs` 的允许表登记，否则
    `dependency_direction.rs` 会红。
- 两种接线方式，**规划阶段不定死，落地第一轮用 ADR 裁决**（见 §6 ADR-TUI-1）：
  1. **子进程方式**：TUI  spawn `caly --json <verb>`，解析 stdout 的一行 JSON。零新内部耦合、
     天然继承 CLI 的全部退出码/超时/角色语义；代价是进程粒度刷新、follow 流要靠子进程生命周期。
  2. **wire 客户端方式**：TUI 直接用 `caly-ipc::FramePump` 连 calyd（与 `caly` 同一套握手/泵/
     期限/探活），自己发 `runtime.status` 等 op、自己开 `jobs.follow-stream`。更流畅、能复用
     R91 的流静默期限；代价是 TUI 要自己实现 CLI 已有的 dial/握手/记录解析（可抽 `caly-cli`
     里的纯函数为共享库，但那是独立一轮的重构）。
  - 规划**倾向方式 2 的「共享客户端核心」终态**，但**第一步建议方式 1**（子进程）以最小耦合验证
    界面与信息架构，再按需要演进——演进时不改变屏上事实，只换数据通路。

## 4. 屏与数据源（每一屏都映射到已有 op / 退出码）

| 屏 | 数据来源（已存在） | 交互 | 备注 |
|---|---|---|---|
| 连接/握手 | `caly status`（`runtime.status`）；连不上=exit 12、握手不符=13、超时=11 | 选 `--addr`（TCP/`unix:`） | 失败态必须可读，不是白屏 |
| Dashboard | `runtime.status` 九字段（core_running/active_profile/active_core/active_snapshot/last_apply_plan_summary/pending_recovery_decisions/last_recovery_summary/last_failure）+ `diagnostics.doctor` 三层计数 | 周期刷新（轮询，非订阅） | 只读；`--json` 逐键 |
| Profiles | `profiles.list`（计数 + `profile_{i}_*`）、`profiles.get <id>` 全字段 | 浏览/选择；高亮 active | 列表计数以 wire 为准，不客户端猜 |
| Job / Follow | `jobs.events`（分页 `--from/--max`）、`jobs.follow-stream`（lossless-resumable 流，DATA/END/ack） | 选中 job → 实时事件流；断线用 stream_id `--resume` | **直接继承 R91**：流静默期限 30s、Wait 不发帧属正常，界面不得把静默当卡死 |
| 动作 | `profiles.apply` / `profiles.rollback`（命令，带 idempotency key）、`system.gc-plan`→`system.gc` | 确认后执行；展示 acceptance/job 流 | Admin-only；`Operator` 下动作入口应禁用或显示 PERMISSION；命令必须由 TUI 铸或透传 idempotency key（CLI 不代铸，TUI 同规） |
| 诊断/支持包 | `diagnostics.doctor`、`diagnostics.support-bundle` / `bundle [digest]` | 生成/查看 bundle | 脱敏边界（R-redaction）已在 daemon 侧，TUI 不再做二次脱敏 |

- 退出码呈现：TUI 是长进程，不退出，但**每个后台动作的结局**映射 `docs/guides/EXIT_CODES.md`（0 成功 / 1 失败
  / 11 超时 / 12 不可达 / 13 协议不符 / 14 CURSOR_STALE / 8 PERMISSION…），在状态栏/弹层如实显示。

## 5. 分阶段里程碑（每阶段独立、可证伪、不反向驱动架构）

- **T0（实现前，本轮规划产物）**：本文档 + README 索引；不产生代码。
- **T1（第一刀，只读 dashboard）**：建 `caly-tui` 成员、接依赖表、一个静态渲染循环显示
  `runtime.status` 九字段（方式 1 子进程 `caly status --json` 起步）。裁判：TUI 进程输出包含与
  `caly status --json` **逐键一致**的事实（两客户端一致才是证据，同 CLI e2e 的 oracle 原则）；
  calyd 不可达时显示明确错误而非挂起（继承 exit 12 语义）。
- **T2（profiles 浏览 + 选择）**：`profiles.list/get`，列表/详情两视图。
- **T3（job 列表 + follow 实时流）**：`jobs.events` 分页 + `jobs.follow-stream`；含断线
  `--resume`（acked 游标零重印）与「静默≠卡死」的 30s 流期限 UX。
- **T4（动作：apply/rollback/gc，带确认与 idempotency key、角色感知）**：Admin 动作在 Operator
  角色下被拒并如实呈现（R92 语义在 UI 上可见）。
- **T5（doctor/bundle、可访问性、键位、最小主题）**。
- 每一阶段：先确认所需事实**已在 wire 上**；若不在，**退回开一个 daemon/wire 轮次**，不在 TUI 里凑。

## 6. 实现前必须先有的 ADR / 决策

- **ADR-TUI-1 渲染与输入栈**：终端 raw-mode/事件循环几乎必然需要外部 crate（`crossterm`/
  `ratatui` 一类）。按项目铁律（外部 crate 须先 ADR；目前仅 `serde_json` 经 ADR-046 授权给
  caly-daemon），**第一步先写 ADR** 裁决：(a) 手写最小 ANSI + 行缓冲（零新依赖，能力有限），还是
  (b) 引入 `crossterm`(+`ratatui`)（能力全、依赖增）。ADR 须写明依赖边、供应/审计姿态、为何 TUI
  的依赖不渗入核心 crate（TUI 是叶子成员）。
- **ADR-TUI-2 数据通路**：§3 的子进程 vs 直连 wire；倾向「先子进程验证 IA、终态共享客户端核心」，
  但以 ADR 定。
- **不**为 TUI 改 `require_role`/wire 形状/idempotency 规则；如确需新事实，走独立 daemon 轮次。

## 7. 与现有纪律的对齐

- 一轮只做一件事：T1–T5 各是一轮；「为 TUI 在 daemon 开口子」若需要，也单独成轮。
- 每条新断言可证伪：TUI 裁判优先「TUI 呈现 == `caly --json`/oracle 逐键一致」与「失败态不挂起」，
  不做像素快照类脆测试。
- 数字纪律：TUI 加入后 `regenerate_test_census.py` / floor / 依赖表 / 成员数（20→21）随那一轮更新。
- 墙钟/纯核心纪律：TUI 是叶子二进制（同 CLI/daemon bin），其渲染/事件代码的时钟与 `Command`
  使用落在 TUI crate 自身，不进 `caly-ipc`/核心。
