# 平台面设计计划（PLATFORM_FACE_PLAN）

> 对应 `ROADMAP §12#6`：Platform/TUN/helper、keyring、UDS 权限（随 transport runtime 落地）、
> 导入限额与 storage schema/performance。本文是**设计前置文档**（engineering 档，非决策）：
> 盘点现状、给选项与取舍、标出哪些子项需要 ADR、画裁判草案。决策落地时逐项另立 ADR。
> 基线：`583d154`（R130）；关联审查发现：`CODE_REVIEW_R131_FINDINGS.md`（F7 结构债、F9 unit 注释）。

---

## 1. 现状盘点（先量后设计）

已经落地的平台面事实：

| 面 | 现状 | 依据 |
|---|---|---|
| 真实 effect runtime | `calyd --effect-runtime real` 显式配对 `--runtime-root`/`--assets-dir`，启动前置写探针+资产校验，默认仍 simulated | ADR-050；e2e `real_effect_runtime_preflight_*` |
| 跨进程 core adoption | durable core receipt、pid+start_time 三要素、接管/按名拒绝/冷收敛、pidfd foreign stop | ADR-060（R125） |
| 监督分层 | systemd 监督 calyd 进程；calyd 自己监督 core 子进程（生命周期耦合 apply 事务，init 看不见） | ADR-055；`packaging/systemd/calyd.service` |
| UDS 权限（一半） | socket 文件 chmod 0o600 | R89（`ROADMAP §13#3` 记「本轮只有 chmod 0o600」） |
| SSRF 边界 | 连接后 peer 校验 + `FetchScope` 保守默认/显式放行 + ActiveCore 豁免 | ADR-053（R73） |
| 资产完整性 | 真核+geo 四文件 sha256 钉死，`fetch_assets.sh` 按哈希恢复 | R54/R67 |
| 优雅停机 | SIGTERM 掩码 main() 首句 + sigwait waiter + 有界排空 exit 0 | ADR-056 + §8（R124/R129） |
| 导入限额（一半） | pipeline 解析边界有输入限额错误位；本地导入「仍受输入限额约束」是 RFC 要求，**执行面未见** | RFC-0003 §L335、RFC-0010 §L292 |

未落地的：TUN 设备面、特权 helper、system proxy/DNS 的真实落地方、keyring、UDS 目录级权限、
导入限额执行面、storage schema/performance。

## 2. 子项设计框架

### 2.1 TUN 与特权模型（最大子项，最先要 ADR）

- **缺口**：real runtime 目前管理 core 进程（spawn/probe/stop），但 TUN 设备的创建/配置
  （`/dev/net/tun`、addr/route/MTU）与 system proxy/DNS 的落地面没有 effect 端口抽象——
  这些都是平台特权操作，形状与「起一个用户态进程」不同。
- **选项**：
  - A. **root 服务直操**（现状延长线）：calyd 以 root 跑，TUN/proxy/DNS 由 daemon 直接做。
    代价：everything-or-nothing 特权，与 RFC-0005 §13 的最小特权目标相悖。
  - B. **Privilege Helper**（RFC-0005 §13 的既定方向）：一个小而可审计的 helper 二进制
    （root/能力位），暴露**窄命令面**（up/down TUN、set/unset system proxy、DNS 恢复），
    calyd 以普通用户+特定能力运行，helper 每命令校验参数并落审计日志。
    代价：新 IPC 面（建议复用 UDS+既有帧方言）、helper 自身的分发/版本配套。
  - C. **纯 core 自理**：mihomo/sing-box 自带 TUN/auto-route，calyd 只给配置与监督。
    代价：回滚/补偿语义（RFC-0005 的 apply 事务）部分落在 core 自己手里，
    「apply 失败即世界不变」的可证伪面被稀释。
- **倾向**（待 ADR 定案）：B 为主体（最小特权+审计面），C 作为 core 能力覆盖时的快路径
  （配置声明 TUN，helper 只做所有权确认与兜底恢复）——两者不互斥，但**回滚补偿的权威
  必须在 calyd**（ADR-055 的分层理由同源）。
- **裁判草案**：helper 命令面=effect port（sim/std 双实现，对齐 ADR-022/050 的同计划双验证）；
  TUN up→core 起→probe 失败→**补偿路径可证**（helper down 幂等+审计行）；
  helper 拒绝越权参数（坏 if 名/超界 MTU）按名拒绝；无 helper 时 real+TUN profile
  在 preflight 即拒（不是运行中崩）。
- **需要的 ADR**：`Privilege Helper 命令面与审计语义`（含与 ADR-055 分层的关系）。

### 2.2 keyring / 机密面（RFC-0010 的未兑现部分）

- **缺口**：RFC-0010 §L63-96 已定三类机密（订阅 URL token、core 控制 token、本地加密 store
  解锁材料）与「OS keyring 优先、无 keyring 平台降级 MUST 最小权限」——执行面为零：
  订阅 URL 目前以明文进 durable source 记录（redaction 只盖展示/projection 面）。
- **设计问题**（一个 ADR 的量）：
  1. **存储边界**：机密值迁出 durable 记录 → OS keyring（Linux: `org.freedesktop.secrets`/
     libsecret；无桌面场景降级为 0600 root-only 文件 + 显式「降级模式」自报）。
     引用形状：记录里只留 keyring 引用 id（`keyring://<id>`），durable 记录可随快照分发
     而不带机密。
  2. **取用路径**：source worker 拉取前经 port 解引用（新增 `SecretStore` port——
     io 网关教义下它是又一个 std/sim 双实现端口）；`doctor` 报 keyring 可用性与降级状态。
  3. **support bundle/inspection**：redaction 边界已有（ADR-020/R41 面），补
     「keyring 引用不得解析进 bundle」的裁判。
- **裁判草案**：解引用只在 port 内（arch-test 禁 src 直读 keyring 文件）；无 keyring 平台
  降级自报+最小权限断言（文件 mode）；快照/导出不含机密值（既有脱敏裁判扩展一条）。
- **需要的 ADR**：`SecretStore port 与 keyring 降级语义`。

### 2.3 UDS 权限收尾（小）——**已收口（第一百三十四轮）**

- **缺口**：socket 0600 已有；目录级（`/run/calyd` 0755 由 systemd `RuntimeDirectory` 给出）
  与「同组只读面」（Operator/Viewer 角色）没有设计——现在 0600 = owner-only，
  非 root CLI 无法连接（`caly status --addr unix:...` 需要 root 或 sudo）。
- **定案与落地（R134）**：选 A——socket 默认仍 `0600`，组共享是**显式 opt-in**：
  `calyd --socket-mode 0660`（八进制解析；拒绝 any other 位=RFC-0010 §14.4 具名拒绝、
  拒绝丢 owner rw）＋systemd `Group=caly` 工作流（见 `DEPLOYMENT_SYSTEMD.md §8`）。
  实现：`caly_ipc::WireListener::bind_with_unix_mode`（校验+chmod 单点）。
- **裁判**：endpoint 两胎（0660 真落盘 / 0666、0604、001、0o060 全具名拒且不留 socket
  文件）+ calyd_wire 二进制一胎（旗标→socket 文件 mode 实测 0660）；falsify 四变异全
  BIT（含「calyd 丢旗标」）。

### 2.4 导入限额（小-中）——**量选后部分收口（第一百三十四轮）**

- **缺口**：RFC-0010 §L292「本地导入仍受输入限额约束」与 RFC-0003 的限额错误位——
  执行面未见（profile/source 导入无数量/大小 cap 的按名拒绝路径）。
- **量选结论（R134 实测）**：①单订阅响应字节——**已有**（每 endpoint 注册即带
  `SOURCE_BODY_CAP=4MiB` + IoBudget 次数/字节边界，`OVERLOAD §2ter` 已记）；②sources 数
  ——**本轮收口**：`MAX_SOURCE_ENDPOINTS=64`（engine worker 注册表增长点按名拒绝
  「import quota: sources」，重注册同 id=更新不拒；calyd 启动 65 个即拒、无 port 文件）；
  ③profiles 数/单 profile 字节——**无导入面**（profile 集合为固定内置+apply，无用户导入
  API）→ 限额随 RFC-0009 profile patch/导入轮落地，不为不存在的调用方发明语义
  （ADR-051 方案 A 同理由）。类别归属微决策：限额=调用方配置错（usage/config refusal），
  非 overload——已按此实现（calyd exit 2/1 启动拒绝）。
- **裁判**：worker 单测（64 绿/65 具名拒/重注册绿）+ calyd_wire 二进制一胎（有界等待——
  变异下 daemon 化的 calyd 是失败不是挂死）；falsify M1 双裁判齐咬。

### 2.5 storage schema/performance（量选先行）——**已收口（第一百三十五轮，量选结论=需要演进）**

- **缺口**：无已知性能问题记录（先量再做的教义下不该臆测）。真缺口是**量选工装**：
  durable 大对象（snapshot/raw source）在万级 profile/source 下的启动恢复与 GC 全扫的
  计时基线。R128 的计数制性能回归框架正好是挂载点（计数不计时 → 这里需要的是
  **计时但沙箱内确定性可比**：固定 fixture+`Instant` 由 port 注入）。
- **建议**：平台面前置一轮做 storage 量选（fixture 生成器+报告），数字说话后再决定
  schema 演进是否真需要（可能结论是「不需要」，那就只留量选工装——负结果也是收口）。
- **定案与落地（R135）**：量选完成，结论是**需要**——但为结构不为性能。工装=
  `crates/caly-storage/examples/sizing_bench.rs`（计数进门禁、计时进报告的 R128 教义；
  真盘 StdFs+确定性 fixture+两条阶梯）；行为钉=perf_regression 两裁判（4096 悬崖具名拒启、
  96→1536 十六倍计数线性）；数字与发现入 `STORAGE_SIZING_BASELINE.md`：reopen/list/plan
  全线性（105-205 MiB/s、7.0 port calls/obj、plan 可忽略），但 `meta/objects/` 平面目录
  4096 条目上限是**拒启悬崖**（写路径不看目录→必可走过；GC 候选集恰需同一次 list→越崖即
  产品内无收容量；满配 source ≈2.7 天可达）。下一轮立 ADR：记录目录分片（content 树
  `xx/yy` 前例）或分页枚举+GC 排干率+带外恢复 runbook。

## 3. 排序与依赖

1. **R132（建议）**：修复轮第一批（`CODE_REVIEW_R131_FINDINGS` F3/F9/F5——小而独立，
   清掉语义债再开新面）。
2. ~~**R134**：UDS 权限收尾 + 导入限额~~ **已收口（本轮）**：UDS=--socket-mode opt-in
   组共享+RFC-0010 §14.4 边界校验；限额=sources 注册配额（64）+「无导入面不造语义」
   量选结论（HTTP body cap 已有、profiles 随 RFC-0009 轮）。
3. ~~**R134**：storage 量选轮~~ **已收口（R135）**：工装+行为钉+`STORAGE_SIZING_BASELINE.md`；
   结论=schema/layout 演进需要（F1 拒启悬崖，触发条件已量化）。~~下一轮立 ADR~~ **已立并落地
   （R136，ADR-062）**：记录目录分片+生产迁移链 v1→v2，悬崖退役；GC 排干率与 reopen 重哈希
   政策经裁决均不动。
4. **R135 起**：Privilege Helper ADR + 首切片（命令面 port + sim 实现 + 审计日志形状），
   TUN up/down 作为第一个真实命令；system proxy/DNS 落地随 helper 第二切片。
5. **keyring**：与 helper 并行或紧随（SecretStore port 独立于 helper；但它改 durable
   source 记录形状=一次 schema 演进，须与 §2.5 的量选结论对表）。

## 4. 一句话结论

> 平台面不是一个功能，是一组各自有 ADR 的边界决策；顺序上先用两个小项（UDS 收尾、
> 导入限额）与一次量选把地基钉住，再开 helper 这个大头——特权永远最后放大。
