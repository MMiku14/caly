# Caly Scenario Suite Strategy

本文件说明为什么在 Caly 当前阶段，需要一个围绕 loopback harness、remote client、facade parity 和 centerline plan/explain 组织起来的 scenario suite。

---

## 1. 目标

scenario suite 的目标不是替代真实 integration tests，而是：

- 在骨架阶段提前验证跨层时序
- 把协议和 facade 行为做成可回归的组合场景
- 尽早发现 local/remote 语义漂移
- 尽早发现 centerline 输出在 query / remote / contract 层的裂缝

---

## 2. 当前建议覆盖面

当前至少应覆盖：

1. handshake
2. runtime watch open（R127 起：dashboard 首拉=快照帧，structured 事件为补丁语义）
3. runtime watch ack path
4. job follow query
5. job follow stream
6. hello timeout
7. wire probe
8. local/remote parity
9. contract bundle
10. plan/explain 相关 parity

---

## 3. 当前代码入口

当前已具备的 scenario / suite 入口包括：

- `run_handshake_scenario()`
- `run_runtime_watch_scenario()`
- `run_job_follow_query_stream_scenario()`
- `run_wire_probe_scenario()`
- `run_timeout_scenario()`
- `run_parity_scenarios()`
- `run_job_follow_contract_scenario()`（共用一个 daemon，自己产生 job；两条 façade 跟同一个 job）
- `run_smoke_bundle()`

这意味着 scenario suite 已不再只是文档建议，而是已经有真实代码入口。

两条入口的签名在本轮收窄过：`run_job_follow_query_stream_scenario()` 与
`run_job_follow_contract_scenario()` 都不再接受 `JobId`。前者的参数从未被读（它自己造 job），
后者拿着硬编码的 `JobId(1)` 去跟一个不存在的 job —— 而 scenario 现在跑在**同一条** daemon 上，
job 必须由场景自己产生，否则「两条路径比同一个 job」这句前提不成立（`docs/history/ONBOARDING_NOTES.md §4.55`）。

**并且它不再只是「可编译」**：`crates/caly-app/tests/contract_gate.rs` 的
`every_scenario_suite_row_passes` 跑 `run_smoke_bundle()`，要求**每一行都是 `Passed`**，
并对行数设下限（100）——只聚了几行必过项的「套件」不能靠体积小蒙过去。在这条门禁出现之前，
本文件描述的场景束只有五行被判定（`scenario::run_loopback_scenarios`），其中三行的状态还是
硬编码的 `true`；那五行连同同 crate 里并存的第二个 `ScenarioSuite` 类型一起被删除
（`docs/history/ONBOARDING_NOTES.md §4.56`）。判定者补上的第一次运行就抓出三个真缺陷，见同一节。

---

## 4. 当前 scenario suite 的角色

在当前阶段，scenario suite 的主要职责是三层：

### Layer A — IPC / Session 行为回归

关注：

- hello
- timeout
- open stream
- ack path
- reset / resume 入口

### Layer B — Facade / Contract 行为回归

关注：

- local facade 与 remote facade 是否仍然共享同一语义结果
- request/response 组合在 loopback 路径上是否断裂

### Layer C — Centerline 输出回归

关注：

- `profile.plan`
- `diagnostics.explain_pipeline`
- `job follow`

也就是说，scenario suite 现在已经开始承担“外围协议层 + 中心主链查询层”的双重回归作用。

---

## 4bis. 本版已加入的场景组（第十一轮）

| 场景 | 断言的东西 |
|---|---|
| `job-events.content` | 事件的**行**能读到，且含 `snapshot.committed`（不是只有计数） |
| `job-events.counters` | `next_event_index` 与行数、`retained_from` 一致；新 job 不该已经丢行 |
| `job-events.at-end-is-empty-not-broken` | 游标停在末尾 = "没有新的"，不是 reset、不是错误 |
| `parity.write.*` | 写侧四条 case 的**内容**（`write.{case}.events`）与同一条 job 的两侧一致 |
| `support-bundle.readback` | 导出可读回（见 `docs/engineering/REDACTION_AND_SUPPORT_BUNDLE.md §4.2`） |

反-vacuity 规则写进了断言本身：事件比对在任一侧为空时判**失配**，因为"两边都空"满足一切相等性断言。

## 4ter. 本版加入的分页行与判定者（第十二轮）

| 行 | 断言的东西 |
|---|---|
| `job-events.bounded-page-roundtrip` | 按 3 行一页走到结束，逐页拼回必须等于整窗读；`pages > 1`（实测 11 页）——单页就把全部塞回来不算通过 |
| `job-events.zero-bound-refused` | `max_lines: 0` 必须被**拒绝**，且拒绝文本同时含稳定码 `CONFIG_INVALID` 与字段名 —— 这两样只有 harness 不丢弃 `ErrorCode` 时才可能被断言 |

判定者是 `crates/caly-app/tests/contract_gate.rs` 里的 `every_scenario_suite_row_passes`（见 `§3` 末段）：
它跑 `run_smoke_bundle()` 的**全部** 128 行（第十二轮结束时是 123 行，本轮 `overload.*` 加了 5 行），
所以每一行都与其余 127 行同生共死；本轮之前这个束
没有任何判定者，补上之后第一次运行就红了三处（`docs/history/ONBOARDING_NOTES.md §4.55`）。

## 4quater. 过载场景组（第十三轮）

| 行 | 断言的东西 |
|---|---|
| `overload.queue-is-exactly-full` | 灌进去的命令数量恰等于容量：不然"满了"是编出来的 |
| `overload.refused-on-both-paths-identically` | 同一条 daemon 上，本地 façade 与 loopback 远端收到的拒绝**逐字段相同**（code / category / retryable / summary / detail / remediation） |
| `overload.refusal-says-what-to-do` | 拒绝里必须有 `error=queue_full`、`retry_hint=RetryLater`、`queue_cap=` 与一句可执行 remediation |
| `overload.refusal-produced-no-side-effect` | 拒绝前后 `state_revision` 与队列深度都不动（`OVERLOAD_AND_RETRY_MODEL §3.1`） |
| `overload.visible-in-doctor-over-the-transport` | 拒绝经 transport 之后仍在 `doctor` 的 warnings 里，一条按类别汇总，且不冒充 errors |

这一束跑在**同一个** `DaemonApp` 上（两条 façade 只是两个入口），否则"两侧一致"比的是两份数据。
`detail` 里带 `at_generation`，两侧必须相同——这同时反证了拒绝没有推进 revision。

## 5. 当前仍未覆盖的关键场景

这份清单本身已经过期了一半，本轮按实测逐条核对（`grep` 命中即算覆盖，标注落在哪个文件）：

1. 已覆盖（第十三轮）：queue full / overload —— 场景束 `overload.*` 五行（见 `§4quater`）之外，还有
   `crates/caly-daemon/tests/overload.rs`（4 条）与 `crates/caly-engine/src/processor.rs` 的 3 条单元测试；
   **仍未覆盖**的是另外三类过载（`EventBacklog` / `StreamBackpressure` / `StorageBusy`）——它们连生产者都没有
2. 已覆盖（单元 + 场景各一条）：`crates/caly-engine/src/job_follow.rs` 的 reset 分支与"末尾游标不是
   reset"，场景行 `job-events.at-end-is-empty-not-broken`；第十二轮另加了"分页不许伪造续读游标"
3. 已覆盖：`crates/caly-ipc/tests/session_and_frames.rs`（`ProtoMismatch` 协商失败）
4. 已覆盖：同一文件的 `validate_frame_header` 超限用例（含"恰好等于上限通过 / 超一字节失败"两个边界）
5. 部分覆盖：`crates/caly-cap/tests/registry_drift.rs` 与 `crates/caly-engine/tests/apply_execution_gate.rs`
   的 capability 门禁；`strict` 组合仍只在 apply 侧
6. 已覆盖：`crates/caly-daemon/tests/apply_command_path.rs`
7. 已覆盖：`crates/caly-engine/tests/apply_execution_gate.rs`（effect plan、崩溃矩阵、回滚）与
   `crates/caly-daemon/tests/cas_and_impact.rs`（影响分类）

---

## 6. 下一阶段推进顺序

建议按以下顺序扩：

1. 先补 centerline 相关场景
2. 再补 overload / reset / protocol mismatch
3. 再补 command/apply/snapshot/journal 场景
4. 最后接真实 transport runtime 下的 integration tests

---

## 7. 一句话结论

> 在 Caly 当前阶段，scenario suite 是把 IPC、facade parity 与 centerline plan/explain 从“静态骨架”推进到“可组合验证骨架”的关键桥梁。