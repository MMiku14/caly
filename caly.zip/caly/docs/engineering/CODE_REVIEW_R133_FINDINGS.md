# R133 二轮代码审查发现账本（CODE_REVIEW_R133_FINDINGS）——质量/性能/简洁透镜

> 性质：**留档不修**（延续 R131 账本的处置方式；用户指令 2026-09-02「修完之后继续审查」）。
> 透镜：与 R131（正确性/资源边界）不同，本轮问的是「这段写法有没有更高级、更具性能、
> 更简洁高效的形状」——每条都给出证据（file:line + 机理）与建议形状，宁缺毋滥：
> v0 wire 的 `Vec<(String,String)>` records 方言、String 错误管道等**架构级既定决策不
> 计入发现**（改它们=换方言/换架构，不是写法升级）。
> 基线：R133 修复批之后的树。状态列在修复轮更新（open → fixed(R13x)）。

---

## 1. 总体判断

热路径上没有算法级问题（无 O(n²)、无泄漏、无锁嵌套）；可改进项集中在**「为取一个小
事实而克隆/锁一大块状态」**的形状上——四处，全部有实证。另有一条微优化与一条结构性
可选项。无 P0/P1 级性能风险（保留窗 256、拉取 64、作业 64 的既有界把它们全部封顶）。

## 2. 发现清单

| 编号 | 级别 | 位置 | 状态 |
|---|---|---|---|
| R133-Q1 | P2（性能+一致性） | `crates/caly-daemon/src/watch_bridge.rs` `stream_payload_from_event` | open |
| R133-Q2 | P2（性能） | `crates/caly-engine/src/event.rs` `replay_from` | open |
| R133-Q3 | P2（性能） | `crates/caly-daemon/src/session.rs:157`（活边沿经整窗克隆） | open |
| R133-Q4 | P3（微） | `crates/caly-daemon/src/watch_bridge.rs:41,99`（Vec 容量预算） | open |
| R133-Q5 | P3（微） | `crates/caly-daemon/src/stream.rs` `subscription_kind_name` 包装层 | open |
| R133-Q6 | 信息（结构可选项） | daemon 内部 `Result<_, String>` 错误管道 | n/a |

### R133-Q1（P2）桥接循环每事件一次「锁+克隆整个 runtime 状态」

- **证据**：`stream_payload_from_event(app, …)` 的第一句是 `app.runtime_snapshot()?`——
  锁 `DaemonApp.runtime` 并 **clone 整个 `DaemonRuntimeState`**；它在
  `bridge_engine_events` 的 per-event 循环里被逐事件调用。一次 64 帧的拉取=64 次锁+64 次
  全状态克隆，而循环里只有 `RuntimeChanged` 一族 payload 真正用到 runtime。
- **附帯一致性角度**：同一拉取内的各帧各自取快照——中途状态变化会让一次拉取内的帧
  携带不同的 runtime 视图（今天单线程会话路径下难触发，但形状在邀请不一致）。
- **建议形状**：拉取开始时取**一次** `runtime_snapshot` 传入映射函数
  （`stream_payload_from_event(&runtime, kind, payload)`）；一次拉取一个视图，锁与克隆
  从 O(事件数) 降到 O(1)。修轮顺手把 F6 之后的循环体保持不变，裁判=既有 watch 裁判族
  全绿+可加一条「一次拉取内 RuntimeState 帧同视图」的单测。

### R133-Q2（P2）`replay_from` 无界克隆整个保留窗（engine 侧克隆先于 daemon 侧截断）

- **证据**：`EventLog::replay_from` 两个分支都 `.clone()`/`.cloned().collect()` **全部**
  保留事件（上限 256）后才返回；R133-F6 只把**铸帧**上界移进了 bridge——engine 仍先克隆
  整窗、daemon 再用 ≤64。滞后积压场景下每次拉取克隆 256 个事件结构（每个含 String
  summary）用掉 1/4。
- **建议形状**：`replay_from_limit(from_exclusive, limit)`（或 `EventWindow` 加
  `limit: Option<usize>` 参数）——游标/reset 语义完全不变（reset 判定在克隆之前），
  只是克隆也按需截断；`events_since` 透传。与 Q1 同轮修=一次拉取的完整「锁/克隆预算」。

### R133-Q3（P2）快照活边沿=克隆整个保留窗只为读一个计数器

- **证据**：`session.rs:157` `let live_edge = app.event_window(None)?.next_seq
  .saturating_sub(1);`——而 `event_window(None)` 走 `replay_from(None)`，其 None 分支是
  `self.events.clone()`（整环克隆）。读一个 u64，付 256 事件克隆。
- **建议形状**：engine 加只读访问器 `next_event_seq(&self) -> EventSeq`（锁内读
  `next_seq` 即返，零克隆）；session 快照路径改用它。与 Q2 同文件同轮。

### R133-Q4（P3·微）桥接循环无容量预算

- **证据**：`watch_bridge.rs:41/99` `let mut frames = Vec::new()` 后逐帧 push——F6 之前
  上界是 truncate（建满再砍），F6 之后循环早停但 Vec 仍从 0 再分配。
- **建议形状**：`Vec::with_capacity(max_frames.min(followed.events.len()))`（Q2 落地后
  events 已带上界，容量恰好）。纯分配面，零语义差。

### R133-Q5（P3·微）`subscription_kind_name` 的 String 包装层

- **证据**：daemon `stream.rs` 的该 fn 现在是 `caly_ipc::subscription_kind_name(x)
  .to_owned()`——每次开流一次堆分配，仅为了维持旧的 String API。ipc 侧已是 `&'static str`。
- **建议形状**：调用方（`OpenedStream.subscription_kind`）改持 `&'static str` 或调用点
  `.to_owned()`——包装层可删。微；随 watch 上 wire 轮（P1）顺手。

### R133-Q6（信息·结构可选项，非缺陷）

daemon 内部错误管道是 `Result<_, String>`（summary 文本即错误）。升级形状=分类型错误
enum（`#[non_exhaustive]`），语义更精确、可编程分支；但这是横切重构（数百个签名），
且仓库现状把「错误=给操作员看的句子」当作设计（EXIT_CODES/ERRORS 文档均以文本为锚），
收益/成本比不成立——**记录为「若未来需要机器可分支的错误分类时再议」**，不设修复轮。

## 3. 修复建议形状

Q1+Q2+Q3+Q4 一轮（同两条数据路径，一次把「一次拉取的锁/克隆预算」从 O(窗) 降到
O(上界)，裁判=既有 watch/deployment 裁判族+活边沿单测+falsify 去 limit 变异）；Q5 随
watch wire 轮；Q6 不修。
