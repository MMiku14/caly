# Storage 量选基线（STORAGE_SIZING_BASELINE）

> `PLATFORM_FACE_PLAN §2.5` 的收口工件：先量后设计——数字说话，再决定 schema 演进是否真需要。
> 基线轮：第一百三十五轮（R135）；工具：`crates/caly-storage/examples/sizing_bench.rs`；
> 行为钉：`crates/caly-storage/tests/perf_regression.rs`（R128 框架挂载点，计数进门禁、计时进本报告）。
> 本文数字为**本沙箱**（2 CPU、warm page cache、release 构建）一次运行的墙钟，配对**机器无关**的
> port-call 计数；跨机器比较以计数为准，墙钟只给量级。

---

## 1. 方法

- **工具**：`cargo run -p caly-storage --example sizing_bench --release`。
  为什么是 example 不是 `#[test]`：R128 教义「计数进门禁、计时进报告」——共享沙箱里墙钟是 flaky 的，
  门禁钉的是 port-call 计数缩放（任意时钟速度下二次扫都是二次的）；墙钟数字按需产出入档，永不进断言。
- **fixture**：确定性（xorshift 流，seed=对象序号）——每次运行字节全同，run 间差异只属于 store 不属于
  fixture；每 rung 独立全新临时目录；`FsStore` over `StdFs`（真盘）+ `StdClock`，写入走生产路径
  （`put`：D2 写 content + 读回验证 + 哈希 + 写 `.obj` 记录 + 单 `stat` 讨年）。
- **测四件事**：build（写路径）、reopen（`FsStore::open`＝崩溃恢复扫：**重读并重哈希每个 content 锚点**，
  即每次启动 O(全部 durable 字节)）、list（`list_objects`：一次 `list` + 一次 `stat_many` 批，
  ADR-054 §2.3）、plan（`plan_object_gc` 全量扫，纯计算）。
- **两条阶梯分离两个候选瓶颈**：计数阶梯（4 KiB 定长，N→4096 上限）与字节阶梯（N=128 定数，
  payload 4 KiB→256 KiB）。
- 工具自带结构断言（reopen 必须 Ok、list 必须返回 N、全扫 plan 必须收 N、4097 必须拒）——行为漂移时
  工具自己先红。

## 2. 数字（2026-09-02，本沙箱）

计数阶梯（4 KiB/对象，向 4096 单目录条目上限走）：

| rung | 对象×字节 | 总量 | build | **reopen** | 吞吐 | list | plan | sim port calls |
|---|---|---|---|---|---|---|---|---|
| n64 | 64×4 KiB | 256 KiB | 5.6 ms | 2.3 ms | 107.1 MiB/s | 0.8 ms | 0.0 ms | 484（7.6/obj） |
| n512 | 512×4 KiB | 2 MiB | 42.2 ms | 18.7 ms | 106.8 MiB/s | 4.8 ms | 0.1 ms | 3620（7.1/obj） |
| n2048 | 2048×4 KiB | 8 MiB | 169.6 ms | 75.5 ms | 106.0 MiB/s | 19.0 ms | 0.0 ms | 14372（7.0/obj） |
| n4096 | 4096×4 KiB | 16 MiB | 338.4 ms | **151.7 ms** | 105.5 MiB/s | 39.7 ms | 0.3 ms | 28708（**7.0/obj**） |

字节阶梯（128 对象定数，payload 增长）：

| rung | 对象×字节 | 总量 | build | **reopen** | 吞吐 | list | plan | sim port calls |
|---|---|---|---|---|---|---|---|---|
| b4k | 128×4 KiB | 512 KiB | 10.9 ms | 4.8 ms | 105.2 MiB/s | 1.1 ms | 0.0 ms | 932（7.3/obj） |
| b64k | 128×64 KiB | 8 MiB | 86.3 ms | 40.6 ms | 196.8 MiB/s | 1.2 ms | 0.0 ms | 932（7.3/obj） |
| b256k | 128×256 KiB | 32 MiB | 327.1 ms | 156.0 ms | 205.1 MiB/s | 1.3 ms | 0.0 ms | 932（7.3/obj） |

悬崖 rung：4097 个对象 → reopen **拒绝**：
`directory var/caly/meta/objects holds 4097 entries, cap was 4096`（已由裁判
`an_object_directory_past_the_entry_cap_refuses_the_next_reopen_naming_the_bound` 钉为行为）。

## 3. 发现

- **F1（结构悬崖，量选的真答案）**：content **字节**树已两级分片（`objects/sha256/xx/yy/…`，
  256×256 桶），但对象**记录**目录 `meta/objects/` 是平的，单目录上限
  `MAX_ENTRIES_PER_DIRECTORY=4096`（list 超 cap=CapacityExceeded 硬错，绝不静默截短——这是对的；
  代价是超限即拒启）。写路径不看目录（`put` 单 `stat` 讨年），所以**写入永远能走过 4096**，悬崖咬在
  下一次 `open`——而 daemon 不能跳过 open。可达性算术：64 个 source（R134 注册配额上限）× 每小时
  一次内容有变的拉取 = 1536 个新对象/天，**约 2.7 天无 GC 即触崖**；触崖后 GC 自己也进不去（候选集
  恰需同一次 list），产品内无收容量，唯一恢复路径是带外 `rm meta/objects/*.obj`（缺失记录是合法态，
  ADR-035 §6bis-ter；另 GC 每 cycle 至多删 256，排干 4096+ 需 16 个 cycle——排干率也入 ADR 讨论）。
- **F2（每次启动 O(全部 durable 字节)）**：reopen 把每个带锚点的对象**重读+重哈希**（load 的
  verify-everything 纪律）。本沙箱 105-205 MiB/s（对象越大摊薄越快）；v0 现实上界 64 source ×
  4 MiB `SOURCE_BODY_CAP` ≈ 256 MiB → **每次重启 ~1.3-2.4 s** 且随历史增长。16 MiB（4096 小对象）
  才 152 ms——开销不在条目数在字节数；这不是当前痛点，是**分片后必然回到台面的政策问题**（锚点
  信任/抽样验证/尺寸门），属 ADR 级决策，本轮不动。
- **F3（健康面，钉住别退）**：list/讨年批路径无病灶——1 次 `stat_many`、0 次 `stat`（R128 裁判在
  N=2048/4096 量级仍应成立）；plan 纯计算可忽略（4096 对象 0.3 ms）；port calls 恒定 **7.0/obj**
  （机器无关的线性证据，与 R128 计数裁判互补：那两个裁判本轮扩到 96→1536 的 16× 线性钉）。
- **F4（修面很小）**：只有 `meta/objects/` 一个目录是平的；content 树先例（锚点前两级 hex 分片）就
  在同一个文件里（`content_suffix_for`）。分片记录目录或分页枚举是**局部**演进，不是 schema 重做。

## 4. 结论（量选回答了 §2.5 的问题）

> schema/layout 演进**需要**——但不是为性能（reopen/list/plan 全线性、吞吐百 MiB 级），而是为
> **F1 的结构性拒启悬崖**。触发条件已量化（≈2.7 天@满配 source 无 GC；GC 越崖即失效）。
> 下一轮立 ADR：对象记录目录分片（对齐 content 树先例）或分页枚举；连带议题：GC 排干率
> （256/cycle）、越崖恢复 runbook（带外 rm 的合法性已由 ADR-035 §6bis-ter 背书）。reopen 全量
> 重哈希的政策（F2）随分片轮一并入 ADR 讨论，不单独开。

本轮**不做**：布局改动、ADR、reopen 验证政策——只落三件：量选工装（example）、行为钉（两裁判）、
本基线报告。这正是 §2.5 写的「负结果也是收口」的正面版本：结论是「需要」，且带数字与修面。

---

## 5. 补记（第一百三十六轮，ADR-062 落地后复测）

分片落地后的同工装复测（同沙箱、同 fixture）：F1 悬崖**退役**——cliff rung 改写为
「4097 对象重开 OK」；分片遍历开销可见且随 N 摊薄：port calls 7.0/obj → 9.3/obj（N=64，
桶近乎单例时）→ **7.1/obj**（N=4096，256 桶摊薄）；reopen 墙钟同量级（n4096：151.7→180.1 ms，
含桶遍历）。单桶 cap 4096 仍在（具名拒启裁判接棒），每族上限 ≈256×4096≈**105 万条**。
裁决与迁移语义见 `ADR-062`；v1 数据目录升级（含越崖目录「先带外删减再迁移」次序）见其 §2.2/§4。
