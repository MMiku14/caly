# R131 深度代码审查发现账本（CODE_REVIEW_R131_FINDINGS）

> 性质：**留档不修**——本轮只审查与记录，发现项统一在后续修复轮处理（用户指令，2026-09-02）。
> 方法：风险模式全仓扫描（unwrap/expect 分布、错误吞咽、无界容器、切片安全、todo/exit、
> lib 内 exit）+ 热点文件深读（session/stream/handler/remote/bridge/engine state/cli bin），
> 每条发现附证据位置与建议修法。审查基线：`583d154`（R130 收口后）。
> 状态表：每条发现将在修复轮更新状态（`open` → `fixed`，附轮号）。

---

## 1. 总体判断

生产代码的纪律面整体健康：`todo!`/`unimplemented!` 全仓为零；lib 层无 `std::process::exit`；
ipc 编解码无未检查切片；时钟纪律/单一 IO 网关由 clippy 钉死；错误路径几乎全部走 `Result<String>`
显式映射。下列发现按严重度排序，**无 P0**（没有会让数据损坏或安全边界穿透的问题）；两条 P1
都是「边界条件下的诚实性/资源面」问题，其余为语义精度与结构债。

## 2. 发现清单

| 编号 | 严重度 | 位置 | 状态 |
|---|---|---|---|
| R131-F1 | P1 | `crates/caly-daemon/src/session.rs:21` | fixed(R133) |
| R131-F2 | P1 | `crates/caly-io-std/src/resolve.rs:64` | fixed(R133) |
| R131-F3 | P2 | `crates/caly-daemon/src/handler.rs:78` + `stream.rs:124` | fixed(R133) |
| R131-F4 | P2 | `crates/caly-daemon/src/stream.rs` / `harness.rs` / `crates/caly-app/src/remote.rs` | fixed(R133) |
| R131-F5 | P2 | `crates/caly-cli/src/bin/caly.rs:313` | fixed(R133) |
| R131-F6 | P3 | `crates/caly-daemon/src/session.rs:152` | fixed(R133) |
| R131-F7 | P3（结构） | `crates/caly-daemon/src/bin/calyd.rs`（2088 行）等 | open |
| R131-F8 | 信息（已文档化） | `crates/caly-daemon/src/watch_bridge.rs` | n/a |
| R131-F9 | P2（文档/运维漂移） | `packaging/systemd/calyd.service:57` + `DEPLOYMENT_SYSTEMD.md §7` | fixed(R133) |

### R131-F1（P1）watch 家族的会话流表无界

- **证据**：`DaemonSession.opened_streams: BTreeMap<u64, StreamCursorState>`——全仓无 cap、
  无 `remove`。对照面：calyd wire 侧 job-follow 的 `StreamTable`（`calyd.rs:160`，
  `MAX_STREAM_TABLE=64`，超限按名拒绝）是有界的；FEATURES §3.3 的「流表有界（超 cap 拒绝）」
  说的是它。
- **后果**：今天该表只经 harness/测试路径触达（watch 家族不在 v0 wire），风险潜伏；一旦
  watch 家族接 wire（TUI 前置，见 `TUI_READINESS_PLAN.md`），长连接反复开流不关即无界增长。
- **建议修法**：与 `StreamTable` 同规——`MAX_OPENED_WATCH_STREAMS`（对齐 64）超 cap 按名拒绝
  （`Unsupported` 语汇），并补「流结束后从表移除或复用槽位」的生命周期语义；修轮须带裁判
  （开 65 条流第 65 条按名拒）+ falsify。
- **归属**：watch wire 接入轮的前置项（`TUI_READINESS_PLAN.md §2` 已列入清单）。

### R131-F2（P1）解析线程 spawn 失败 = panic

- **证据**：`resolve.rs:64` `.expect("spawn the bounded resolver thread")`——惰性单例首次使用时
  `thread::Builder::spawn` 失败（线程/fd 上限下的 `EAGAIN`）直接 panic，穿透到无辜调用者。
- **后果**：io 层的教义是「边界条件按名拒绝」（ADR-052/R129 的全部设计），这是该面上唯一的
  panic 出口；资源受限时一个 DNS 查询可以带崩整个 daemon。
- **建议修法**：spawn 失败映射为按名 `IoFault`（`Unavailable`，summary 指明 resolver 未启动），
  `get_or_init` 改为可失败初始化（如 `OnceLock` + 结果缓存，失败可重试语义要显式写明）。
  裁判：注入「spawn 必败」的缝 + falsify。

### R131-F3（P2）Stream 臂内部错误被吞成「不支持的操作」

- **证据**：`stream.rs` `handle_stream` 对 `allocate_stream(...).ok()?`——`Err`（目前唯一来源：
  runtime 锁毒化）变成 `None`；`handler.rs:78` 把 `None` 走 `unsupported_request_response`。
- **后果**：内部锁毒化会被报成 UNSUPPORTED 类 refusal——错误类别失真（`OVERLOAD_AND_RETRY_MODEL`
  对「不支持」与「内部故障」的 remediation 语义不同），排障方向被指错。
- **建议修法**：`handle_stream` 返回 `Result<Option<OperationResult>, String>`（对齐 Query 臂的
  `Ok(None)=unsupported / Err=error_response` 三分），`allocate_stream` 的 Err 走 `error_response`。

### R131-F4（P2）subscription→StreamKind 映射四份拷贝

- **证据**：同一映射存在于 `caly-daemon/src/stream.rs` 两处（`subscription_kind_name` 内联 +
  `stream_kind_for_operation`）、`caly-daemon/src/harness.rs:385`、`caly-app/src/remote.rs` 两处
  （checked 与 unchecked 路径各一份）。R130 加 `Deployment` 时被迫改了四个文件、五处 match——
  下一个 variant 会再来一遍，漏一处即编译错（现在是穷举 match，编译器兜底）但**值配对**错
  （如 Deployment→Dashboard）编译器不兜底。
- **建议修法**：收敛为 `caly_ipc` 单函数（它同时看得见 `caly_api::RuntimeSubscription` 与
  `StreamKind`）：`pub fn stream_kind_for_subscription(...) -> StreamKind` 与
  `pub const fn subscription_kind_name(...)`；五处调用点改为引用。修轮带结构门禁防回归拷贝。

### R131-F5（P2）follow 路径畸形 JSON 静默成空记录

- **证据**：`caly.rs:313` follow 的 parse 闭包 `json_to_records(&text).unwrap_or_default()`——
  坏 JSON 变空 records，后续按「缺字段/畸形」报协议错（exit 13 方向对，fail-closed 成立），
  但 summary 会指向「opened 帧缺 stream_id」而不是「JSON 解析失败」——排障语义指错方向。
- **建议修法**：解析失败单独成错（保留 exit 13，summary 指明 `json decode of <kind> frame
  failed: <error>`）；与 R94 的「信内容不信 kind」同族，补一条畸形 JSON 帧的 e2e。

### R131-F6（P3）watch 拉取先建全量帧再截断

- **证据**：`session.rs` watch 臂先 `bridge_engine_events` 构造整窗帧、返回后
  `frames.truncate(MAX_WATCH_FRAMES_PER_PULL)`。有界性达成（对外契约不变），但回压积压时
  每次拉取分配整个保留窗（256×帧大小）再丢掉 3/4。
- **建议修法**：把 cap 传进 bridge（`events_since` 后先截事件迭代再铸帧），或
  `Vec::with_capacity`+提前 break。纯性能/分配面，修轮可与 F1 同文件顺手（但分开提交）。

### R131-F7（P3·结构债）巨型文件

- **证据**：`calyd.rs` 2088 行（解码适配+渲染表+accept 循环+job 流泵+adopt+信号+生命周期混排）、
  `effect_std.rs` 1862、`service.rs` 1833、`caly.rs` 1470。功能正确但审查/改动定位成本线性上涨，
  且 `calyd.rs` 的渲染表与流泵已被两轮以上改动反复穿越。
- **建议修法**：不急拆、随平台面轮顺势分区（`calyd.rs` 至少把「渲染表」「job 流泵」「adopt」
  各自成 `bin/support/` 模块——信号面已有先例 `bin/support/signal.rs`）。拆分轮必须纯移动
  （零行为 diff，门禁全绿即证）。

### R131-F8（信息·交叉引用，非新发现）

非 Deployment kind（Dashboard/Connections/Traffic/Logs）的 watch 流仍携带共享事件窗的全部事件
（含 `DeploymentEvent` 帧）——这是 R130 记录在案的顺延项（Traffic/Logs 待真实数据源、
SnapshotThenPatch 只盖首帧），见 `IMPLEMENTATION_STATUS §8.44`「明确没做」。列出仅为与 F1
修复轮对齐口径：watch 家族接线时一并决定非 Deployment kind 的窗口事件白名单。

### R131-F9（P2·文档/运维漂移）unit 文件的 SIGTERM 注释与 ADR-056 现实相反

- **证据**：`packaging/systemd/calyd.service` 注释写「calyd does not catch SIGTERM (std exposes
  no TERM surface, ADR-043 §2.5). On stop it is killed; the NEXT start's recovery reaps…」。
  现实：R124（ADR-056）起 calyd **正是**捕获 SIGTERM 优雅排空（stop accepting → bounded drain →
  core stop → exit 0），R129 还修了掩码顺序（ADR-056 §8）；`TimeoutStopSec=15s`+`KillSignal=SIGTERM`
  的组合现在是「15s 预算内优雅、超时才 SIGKILL」。
- **后果**：运维读者会以为 stop 必杀、必须等下次启动 recovery 收尸——与真实排空行为相反，
  影响 stop 预算调优判断与故障预期（journal 里其实能看到「received termination signal」）。
- **建议修法**：改写该注释为 ADR-056 语义（优雅排空+15s 有界预算+超时 SIGKILL 兜底+下次启动
  recovery 仍是最后防线）；顺手核对 `DEPLOYMENT_SYSTEMD.md` 的 stop 一节是否同病。

## 3. 修复批结果（第一百三十三轮，2026-09-02）

F1/F2/F3/F4/F5/F6/F9 七项收口（falsify_round133 四变异全 BIT；F3 的 Err 路径今日仅锁毒化可达、不配行为裁判，类型形状由 F1 的拒绝走同一 `error_response` 门佐证；F6 为纯等值重构、语义由既有流裁判族钉住；F9 为文案）。F7（巨型文件拆分）按本表原计划**显式顺延**至平台面轮顺势做；F8 为已文档化顺延项（n/a）。裁判与位置：F1=`watch_snapshot_stream::a_session_stream_table_is_bounded_and_refuses_by_name_when_full`（+会话拒后仍活）、F2=`resolver_spawn_failure.rs`（专用二进制，seam=`resolver_spawn_is_broken_for_tests` pub 重导出）、F4=`dependency_direction::subscription_to_stream_kind_has_one_home`（单一家+反空转）、F5=`caly_cli_e2e::caly_names_an_undecodable_json_frame_as_a_protocol_disagreement`（假 daemon json 帧垃圾→13+具名）。

## 4. 统一修复轮的建议形状（历史建议，已被 §3 执行）

1. 一条提交一个发现（F4/F6 可各自独立；F1 单独带裁判+falsify；F2 需要注入缝，量最大）。
2. 顺序建议：F3/F9（最小、纯语义/纯文案）→ F5 → F4 → F6 → F1（与 watch wire 前置对齐）→ F2 → F7（顺势）。
3. 每条修复更新本表状态列（`open → fixed(R13x)`）；全部收口后本文件降级为历史记录，
   或并入 `IMPLEMENTATION_STATUS §6` 的负债记账。
