# Caly Local/Remote Facade Parity Notes

本文件用于说明 `LocalFacade`、`RemoteFacade` 与 `LoopbackHarness` 在当前阶段的关系，以及 parity 已经推进到哪里。

> **📌 阅读提示（2026-08-31 更新）**：parity 已随 wire 生产接线（v0 TCP+UDS、帧关联、角色授权、退出码映射）大幅推进，CLI 前端在真 daemon wire 上闭环。最新状态见 `docs/guides/FEATURES.md §4`、`docs/engineering/IPC_TRANSPORT_DECISION.md`、`docs/status/IMPLEMENTATION_STATUS.md`。


---

## 1. 为什么这份文档仍然重要

Caly 的一个核心目标是：

- LocalApi / RemoteApi 语义一致
- CLI/TUI 不因为 transport 不同而拥有不同业务逻辑
- facade 只是 transport 差异的边界，不是业务逻辑分叉点

因此，parity 不是锦上添花，而是控制平面架构的核心质量约束。

---

## 2. 当前已经具备的基础

当前已形成：

- `LocalFacade`
- `RemoteSessionClient<T>`
- `RemoteFacade<T>`
- `LoopbackRemoteTransport`
- `LoopbackHarness`
- `run_basic_parity_check(...)`
- `run_system_contract(...)`
- `run_job_follow_contract(...)`
- `run_loopback_remote_contract(...)`

这意味着：

- 本地调用路径已经不是 ad-hoc helper，而是 facade 入口
- 远程调用路径已经不是纯 DTO 结构，而是 session + transport + client glue
- local/remote 之间已经有最小 contract 验证层

---

## 3. 与之前相比的实际推进

当前 parity 面已经从：

- `system.status`
- `system.info`
- `system.gc-collect` / `system.gc-collect-keyed`（`ADR-038 §2`：一条会删数据的命令。两条用例一起进
  `ENVELOPE_PARITY_CASES`：带 key 的那条检查第二个门面**重放**第一个的 job 而不是再删一轮，不带 key
  的那条检查两侧收到同一句 `CONFIG_INVALID`。`parity_of` 把数字归一化，所以比对的是形状与语义，
  不是巧合相同的 job id）
- `system.gc-plan`（`ADR-038 §1`：一份把 store 事实搬进视图的读。逐字段必须相同，否则"哪条门面把回收
  范围算错了"无法归因；它同时进 `ENVELOPE_PARITY_CASES`，所以两侧构造的 envelope 本身也在比对范围内）
- `runtime.status`
- `diagnostics.follow_job`

继续扩展到：

- `profile.plan`
- `diagnostics.explain_pipeline`

这很重要，因为这两个接口已经直接贴近中心主链：

- `profile.plan` 能暴露 apply planning 结果
- `diagnostics.explain_pipeline` 能暴露 pipeline / compile / effect projection

也就是说，parity 开始不再只是外围系统状态，而是在比较 centerline 的输出。

---

## 4. 当前 parity 的真实边界

当前已经成立的结论：

1. local facade 可通过 daemon query path 获取 centerline plan/explain 结果
2. remote facade 可通过 IPC operation 获取相同语义结果
3. parity / contract / loopback scenario 已有代码入口并可编译验证

但当前**尚未**宣称：

- 所有 Facet 都已 parity
- stream runtime 行为已完全一致
- reconnect / retry / reset 策略已完全固定
- apply command 执行路径已 local/remote 同步闭环

---

## 5. 当前仍然不是完全 parity 的地方

仍有明显差距：

1. `operation.rs` 仍偏大，DTO 迁移未完成
2. local/remote 两侧仍有若干 skeleton 值直接返回
3. command path 的真实 apply 执行尚未接好
4. stream runtime 的更丰富行为还未完全对齐
5. overload/public error 仍未在所有 operation 路径完全一致地体现

---

## 6. 为什么 loopback harness 仍然关键

Loopback harness 的价值在于：

- 能让 remote path 在无真实 UDS/Named Pipe runtime 的阶段先跑起来
- 能把 hello/request/stream/ack/follow 串起来
- 能作为 local/remote parity 的低成本回归底座

也就是说：

> loopback harness 不是过渡玩具，而是 parity 收敛的前置基础设施。

---

## 7. 下一阶段该怎么推进 parity

正确顺序应是：

1. 完成 `caly-api` DTO 收敛
2. 让更多 Facet 的 query/command 统一走 operation 驱动
3. 继续把 `plan` / `explain` / `follow` / `watch` 纳入 contract
4. 在 daemon command path 接上真实 apply 后，再比较 local/remote 的 job lifecycle 输出

---

## 8. 一句话结论

> Local/Remote parity 已经从“外围状态对照”推进到“中心主链结果对照”，下一步要做的是把这种对照扩展到真实 apply 执行闭环。
---

## 3bis. 写侧 parity 与错误身份（2026-08-27 第九轮加入）

上面两张表全部是**查询**。查询一致而写入不一致是可能的，而且当时就是如此（`ONBOARDING_NOTES §4.37`）。
现在多了一组比较写入的入口，都在 `caly-app`：

| 入口 | 比什么 |
|---|---|
| `run_write_parity(daemon, profile)` | 同一个 daemon 上，两条路径各跑 `WRITE_PARITY_CASES = [fresh-a, fresh-b, dedup-a, dedup-b]`，逐 case 比对 `WriteTrace` |
| `capture_write_cases(facade, daemon, profile, key)` | 采集：`Accepted` 的影响分类、这次写消耗了多少 `state_revision`、job 的终态与最后一段、日志/告警条数、失败码、之后的 active profile/快照、待决 journal 数、doctor 错误数 |
| `capture_cas_answers(facade, daemon, profile)` | 故意用**过期**的 `expected_revision` 与**当前**的各提交一次：两条路径必须同样拒绝/同样接受，且错误码、类别、trace_id 逐字相同 |
| `run_envelope_parity(daemon)` | 同一请求分别按两条 façade 会构造的 envelope 送进 `handle_request`，比对 `parity_of()`：`trace_id` + `result`（数字归一化） |
| `parity_of(envelope)` | 上一条用的投影。**`request_id` 被排除**并注明理由：它由"谁来组帧"决定，进程内调用没有帧可编号 —— 比它等于比管道而不是比 daemon 的决定 |

比对用的数字归一化（`normalize_counters`）只作用于 job id 与 revision 这类必然递增的量；
受影响的是**形状**：返回哪个变体、是不是错误、错误码/类别/remediation 文本、影响分类、trace、事件条数。

### 3bis.1 错误身份是这一节的前提

`RFC-0002 §4.1` 要求两条路径共享 `ErrorCode`。修之前远端 façade 把 daemon 的错误压成 String 再包成
`UNAVAILABLE / Internal / retryable=true`，于是「被有意拒绝」在远端读起来像「可以重试」。
现在 façade 走 `send_operation_checked` + `with_client_api`；曾经"仅剩的两个有损点"是两个 stream 打开处，
第十一轮把它们也接上了类型化路径，于是 `with_client` **不再存在于** `remote_facade.rs`。判定也随之从
"计数棘轮（恰好 2 处）"改成绝对断言：`no_facade_path_flattens_a_daemon_error` 读 façade 源码，要求
`with_client(&client` 出现 0 次、包装函数本身不得回归，并点名现在必须存在的三条类型化路径
（`send_operation_checked` / `open_runtime_stream_checked` / `open_job_follow_stream_checked`）。
把棘轮改成 0 值断言的理由写在 `docs/history/ONBOARDING_NOTES.md §4.51`：一个"允许两处"的计数只能阻止变多，
不能阻止其中一处被复制成第三种拼法。

### 3bis.2 导出闭环也在比对之内

`write.events_paged_identical`（第十二轮）：两条路径各自按 3 行翻页走到结束，行数与内容都必须一致
（任一侧为空即失配）。上限由 daemon 出口施加、两条路径共用，所以这条比对的真正用途是**防止将来有人
在某一侧的 façade 里再动一次页大小** —— 那会伪装成"远端少了几行日志"。

`write.bundle_readback` 与 `write.bundle_readback_missing` 两条：同一份 bundle 从两条路径读回必须**逐字节
一致**（比对的是返回文本的 `sha256`，不是长度），而不存在的那个 digest 必须两边给出**同一个拒绝**。
反-vacuity 断言写在 `caly-app/tests/write_parity.rs` 里：先让本地路径真的产出一个 bundle，再要求
`write.bundle_readback` 的证据以 `read digest=sha256:` 开头 —— 否则"两边都拒绝"也能把这条比对喂绿。

### 3bis.2b 身份这一层：`ADR-037` 落地之后才可比

`role` 与 `idempotency_key` 以前在两条路径上都是**常量**（本地 façade 自赋 `Admin`、session 默认也是
`Admin`），于是「两条路径的权限语义一致」这句话没有可比较的对象。第十四轮之后有两处真断言：

- `the_same_role_refusal_comes_back_over_both_access_paths`（`crates/caly-daemon/tests/`）：同一角色走
  进程内 façade 与走 loopback transport，`PERMISSION: …required role Admin` 必须逐字节相同；
- `a_keyless_required_write_is_refused_identically_on_both_paths`（`crates/caly-app/tests/error_identity.rs`）：
  无 key 的 `profile.apply` 在两条路径上给出同一条 `CONFIG_INVALID` 拒绝，并且**什么都没发生**
  （`state_revision` 仍为 0、没有 job、没有部署）。

顺序也是契约的一部分，并且被写成断言：角色 → 请求形状（key）→ 状态（CAS / 生命周期）。理由是调用者
只能处理自己控制得了的那一件事；`a_keyless_request_with_a_stale_revision_is_refused_for_the_key` 钉住
「key 先于 CAS」，`the_local_path_is_operator_by_default_and_says_so_in_the_refusal` 钉住「角色先于一切」。

### 3bis.3 还没有覆盖的部分（诚实列出）

- ~~`role`：两条路径都不看调用方，所以 `required_role` 永不失败~~ —— 第十四轮由 `ADR-037` 关掉：两条
  路径都从调用者取角色（本地 `DaemonApp::local_role`，远端握手时的 `ClientSessionConfig.role`），默认
  `Operator`，并且上面 §3bis.2b 那两条断言开始有意义。仍**没有**的是 principal 层（角色之外「是谁」）与
  `--as-role` 的退出码映射。
- `deadline_ms` 的执行：现在两条路径都把它写进 envelope，但没人据此取消 —— 与 `ADR-036` 的执行器问题重叠。
- stream 侧的写后**逐帧**比对：`follow_job_stream` 的两个有损包装点已在第十一轮去掉（`with_client`
  在 façade 文件里为 0 处，`error_identity.rs` 断言这件事），但 `pull_stream` 拿到的帧仍然只检查
  "非空 + 行数"，没有逐 payload 字段比对。事件的**内容**跨路径一致性因此走的是 Query 一侧：
  `write.{case}.events`（数字归一）与 `write.events_paged_identical`（各按 3 行翻页走到结束，
  行数与内容都必须一致；任一侧为空即失配）。
- 错误码在**报告文本**里的拼写：`contract.rs::read_through` 与 `LoopbackHarness` 现在都用
  `docs/guides/ERRORS.md` 的稳定码（`refused CONFLICT …`、`CONFIG_INVALID: …`），并由 `write_parity.rs`
  与 scenario 行钉住；`contract.rs::describe` 同样改用稳定码，但那条路径只在出错时才有输出，
  **没有任何测试能观察它**（本轮的失败注入证实了这一点，见 `DEVELOPMENT_LOG` AC6 末段）。
