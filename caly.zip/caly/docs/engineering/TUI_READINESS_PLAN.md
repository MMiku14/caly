# TUI 就绪计划与 artifact golden 加强（TUI_READINESS_PLAN）

> 对应 `ROADMAP §12#7` 尾段：「余 artifact golden 加强，最后再推进 TUI」。本文是设计前置
> 文档（engineering 档）：把「TUI 需要什么」拆成可逐轮收口的前置清单，并设计 golden 的
> 加强面。基线：`583d154`（R130）；关联：`PLATFORM_FACE_PLAN.md`（平台面先行排序）、
> `CODE_REVIEW_R131_FINDINGS.md`（F1=watch 流表 cap 是本文前置项）。

---

## 1. 现状盘点：TUI 的数据面已到哪一步

| 面 | 现状 | 缺口 |
|---|---|---|
| Job 流 | wire 全通（opened→DATA→END/ACK、resume、failure_code、exit 码） | 无 |
| Dashboard/Connections 流 | 生产者就绪（R127 SnapshotThenPatch：首帧快照+有界分拉+慢客户 Reset） | **不在 v0 wire**（`WIRE_OPERATION_NAMES` 无 watch 家族） |
| Deployment 流 | 生产者就绪（R130：开流+逐帧过滤+恢复+Reset） | 同上；且会话机流表无 cap（R131-F1） |
| Traffic/Logs 流 | policy 在表、专有生产语义待真实数据源 | 数据源接入（mihomo/sing-box API 面） |
| 会话内多请求 | 已支持（R123：递增 request_id、双请求复用同一会话） | **并发交错多流**（一连接一泵串行复用；RFC-0002 多路复用形状=v1） |
| CLI 渲染 | records 人类渲染+`--json` 双形态、follow_loop 逐帧渲染 | 无交互面（TUI 是新 surface，不是 CLI 改造） |

结论：TUI 的**协议对象**（六种 StreamKind 的 policy/生产语义）基本齐了，缺的是
**传输接线**（watch 家族上 wire）、**并发形状**（多路复用 v1）与**终端面本身**。

## 2. 前置清单（按轮拆）

### P1 watch 家族上 wire（`runtime.watch`）

- 形状：`WIRE_OPERATION_NAMES` 16→17（`runtime.watch`+extras `subscription`），encode/decode
  双臂；calyd 渲染臂（WatchOpened→records）；opened 帧带 `subscription_kind` 回显。
- **前置修复 R131-F1**：`DaemonSession.opened_streams` 加 cap（对齐 wire 侧 `Stream_TABLE=64`
  形状，超限按名拒）+ 流结束移除语义——wire 接通后它就是生产资源面。
- 裁判草案：calyd_wire 胎（开流回显 kind/流 id；坏 subscription 按名拒 USAGE；65 条超限
  按名拒）+ e2e（`caly watch dashboard --once` 拉一帧快照对独立 oracle）；falsify：
  去 cap/错 kind 回显/缺 decode 臂。
- 消费者：CLI `caly watch <kind>` 动词（`--once` 脚本面 + 缺省持续拉）——TUI 之前，
  脚本先吃到流面。

### P2 并发交错多流（RFC-0002 多路复用 v1）

- 现状约束：`FramePump` 一连接串行（请求-应答与流帧按到达序处理，follow 期间 ask 复用
  同一泵已支持，但**两条流同时开**没有关联分派形状——stream_id 分派在 session 两侧都有，
  缺的是客户端事件循环的「帧→所属流」订阅分发的正式语义）。
- 设计问题（一个 ADR 的量）：客户端订阅模型（每流一个 channel？单一 poll 事件口？）；
  daemon 侧无改动（帧本来就带 stream_id，`opened_streams` 已按 id 键）；背压交互
  （慢流不得饿死快流—— pump 串行即天然公平，**保持串行泵**、只加客户端分派是最小形状）。
- 裁判草案：进程内双流交错注入（MemoryIo 形状先例）+ e2e：一条连接上 dashboard 持续拉
  与 job follow 并发，两流各帧各序完整、无串流（stream_id 关联裁判已有先例可扩）。

### P3 Traffic/Logs 数据源接入

- mihomo（REST `traffic` WS/轮询、`logs` 流）与 sing-box 对应面：port 形状（poll 优先于 WS
  ——与「std 无 WS」现状一致）、LatestValue coalesce 与 LossyRing 丢帧语义随轮定义
  （`IPC_STREAM_POLICY §7` 已留位）。此轮也补齐 R130 顺延的两个 kind 生产语义。

### P4 artifact golden 加强（ROADMAP §13#5 的原话：「加强与内核 runtime API 同轮」）

- 现状：R67 golden=产物**字节**级（gz/tgz/二进制/geo 库 sha256+独立 oracle 重建合并配置）。
  缺口：**行为面**——内核 runtime API 的版本漂移不可见（mihomo Clash API 字段/sing-box
  experiment API 变化只会表现为运行期解析失败或静默字段缺失）。
- 设计：`assets/manifest` 增 `runtime_api` 探测记录（mihomo `/version`、sing-box
  `boxlife/version` 端点形状随 P3 一起定）；golden 测试从「字节全等」扩一条
  「API 面钉死」：对钉死版本内核实测一组**代表性响应 fixture**（traffic/status/logs 各一）
  入库，效果面解析器对这些 fixture 的输出 golden 化——内核升级轮换资产时，fixture diff
  就是 API 漂移的显式审阅面。
- 裁判草案：fixture→解析器输出的逐字段 golden（漂移=红+diff 指明哪个字段）；falsify：
  改 fixture 一字段不红即门禁空转。

### P5 TUI 本体（最后）

- **依赖决策是第一道门**：终端库（ratatui/crossterm 形状）=新外部依赖，须 ADR
  （现行依赖清单只授权 serde_json+uds-peek FFI；「无新依赖」是历轮明确没做的常量项）。
  备选：先做**无依赖的最小行式 TUI**（ANSI 转义+原始模式经 termios——io 网关教义下
  terminal 也是 port），量出真实需求再决定要不要引库——教义顺序与平台面一致。
- 数据面：P1/P2/P3 之后，TUI=「Dashboard 流快照+patch 增量渲染、Deployment 流时间线、
  Job 流详情页、Traffic 实时行」的纯消费者；连接面复用 `FramePump`+hello 角色
  （TUI 自报 ClientKind::Tui 已在 hello 形状里）。
- 裁判草案：渲染确定性（喂录制帧序列→期望屏幕行快照）；慢终端（可注入时钟的刷新节流）；
  断流重连（resume 语义复用）。

## 3. 排序（与平台面的相对位置）

1. 修复轮第一批（R131 F3/F9/F5）→ 第二批（F4/F6）——语义债先清。
2. **P1 watch 上 wire（含 F1）**——TUI 与脚本面共同前置，性价比最高。
3. **P4 golden 加强**——可与 P1 并行（不同 crate 面）；内核 API fixture 依赖 P3 的端点
   定义，先做 mihomo 面。
4. P2 多路复用 v1 → P3 Traffic/Logs 数据源 →（平台面 R133-R135 穿插，见
   `PLATFORM_FACE_PLAN §3`）→ P5 TUI 本体。
5. TUI 依赖 ADR 在 P5 开轮时立（量出需求再立，不提前）。

## 4. 一句话结论

> TUI 不是「写一个界面」，是把已就绪的流面接到 wire、给并发一个正式形状、给内核 API
> 一份 golden——做完这三件，TUI 只是它们上面最薄的一层消费者。
