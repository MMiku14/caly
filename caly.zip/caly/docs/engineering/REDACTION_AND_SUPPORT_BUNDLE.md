# Redaction 与 Support Bundle

> 本文记录 `RFC-0010 §6/§7/§12` 与 `ADR-020 §3` 在代码里的落点：**脱敏发生在哪些边界、support
> bundle 里到底有什么、以及这些结论如何用命令复现**。
>
> 本轮动手之前实测：`grep -rn 'redact\|Redact\|Secret' crates --include='*.rs' | wc -l` → **0**，
> 也就是说 `RFC-0010 §6/§7` 与 `ADR-020 §3` 各自用 MUST 要求的机制此前并不存在（不是"不完善"，是没有）。
> 今天再跑同一条命令命中的是本轮新增的实现，命令本身留在这里作为"当时为空"的可复现对照。

---

## 1. 一句话结论

```
Redactor 只有一份，装在引擎里；三条出口（job 日志、ApiError、support bundle）各过它一次，
bundle 额外把策略升到 Strict。
```

---

## 2. `caly-common::redact`

`crates/caly-common/src/redact.rs`（870 行，20 个单元测试；`cargo test -p caly-common` 跑 25 个，含 `digest.rs` 的 5 个）。纯逻辑，无时钟、无文件系统、无 trait
——这是 `ADR-011` 允许它被任何层调用的前提。

### 2.1 规则顺序（`RFC-0010 §6.2` 的逐条落地）

| 顺序 | 规则 | 覆盖的 §6.2 目标 | 形态 |
|---|---|---|---|
| 1 | 已登记的字面量 | 调用方知道的任意 secret | 整段替换为 `***REDACTED***` |
| 2 | PEM 块 | 私钥材料（含未闭合的 `-----BEGIN`） | 整块 → 单个 marker |
| 3 | URL 结构 | 订阅 URL token、`user:pass@`、嵌套 `url=` | query/fragment 值级掩码 |
| 4 | `key: value` / `key=value` / `"key": "value"` | 密码、api key、cookie、UUID | 值级掩码；`Authorization` 类整行 |
| 5 | Strict 追加项 | `§4.1` 准 secret：UUID、内网 IPv4、home 路径用户名 | 值级掩码 |

`REDACTED` 是常量而不是各处自造的字符串，因为 `§6.3` 真正要求的是「同一路径输出行为一致」。

### 2.2 两条刻意保留的边界

1. **不猜。** `https://host/<opaque-token>`（无 `?`、无 key 名）没有文本信号，任何 pattern 规则都只能靠
   启发式，而启发式一旦误伤 `sha256:<64hex>` 这类对象地址，诊断就不可读了。因此这类 secret 必须由
   持有 URL 的一方 `register_secret()` 登记——这正好是 `§3.3`「脱敏在对象构造或边界转换时完成」的含义。
2. **不删。** 规则只替换值，不吞字段，所以 `redact(redact(x)) == redact(x)`（幂等），`line_count`
   不变。测试 `line_structure_survives_redaction` / `benign_text_is_returned_unchanged` 钉住这两点。

### 2.3 一处需要 maintainer 确认的解读

`§4` 把「节点 … UUID」列进 Secret，`§4.1` 又把「某些可识别个人或设备身份的信息（按上下文）」列为
准 secret。本文把 **UUID 归到准 secret**（只有 Strict 才掩），理由：`system.info`/快照/日志里
UUID 形状的关联 id 是排障主线索，而默认策略下仍掩掉 `uuid = "…"` 这种**带 key 名**的写法。
若 maintainer 认定 UUID 应无条件掩，只需把 `scrub_uuids` 从 Strict 分支移到公共链，测试
`strict_mode_also_converges_quasi_secrets` 里那句「default 不动 §4.1 项」需同时反转。

---

## 3. 三条出口

| 出口 | 落点 | 为什么是这里 |
|---|---|---|
| job 日志 / stage / warning / `JobEvent::Failed` | `EngineHandle::append_job_event`（`caly-engine/src/service.rs`） | 引擎内**唯一**写 job 事件的地方；follow、stream、bundle 都只读它 |
| 对外 `ApiError` | `handler::handle_request` → `DaemonApp::redact_error` | `ADR-020` 说「跨门面后必须统一」；`ApiError::new` 的构造点散布在十几个 crate 且多数在插值自己不拥有的文本 |
| support bundle | `BundleDraft::finish(&Redactor)` | `§3.3`：导出物只有一个合法形态，即「已经掩过」的 `SupportBundle` |

第四处边界（`§6.1` 的"对外 DTO 映射时"）**本轮没有加掩码点**，理由是实测它当前没有可泄漏的字段：

```bash
$ grep -rn 'pub url\|pub password\|pub token\|pub secret' crates/caly-api/src/dto/*.rs | wc -l
0
```

（`SourceSummary` 只有 `id`/`label`/`kind`；订阅 URL 只出现在 `caly-io::FetchReq.url`，而 `Http` 还没接进
任何生产路径。）这是一个**会随实现过期的结论**：一旦 DTO 出现 URL/凭据字段，必须在上表第三行之后
再过一次 redactor —— 记在这里，是为了让它有一个明确的落点，而不是等下次泄漏了再找。

两条实现约束值得记下：

- `DaemonApp::redact_error` 在引擎锁中毒时**退化为 Strict redactor**，而不是跳过脱敏；错误路径不该
  因为第二个错误而失败，也不该因此变成明文出口。
- 双层是刻意的：本轮把 `append_job_event` 里的脱敏整行注释掉之后，只有
  `job_events_are_masked_where_they_are_appended` / `a_job_log_line_is_masked_before_any_reader_sees_it`
  两条失败，**bundle 与 ApiError 两条出口仍然掩着**（各自实测 7 passed / 1 failed，5 passed / 1 failed）。
  即：任一条边界失手，不会同时失去脱敏。

---

## 4. Support Bundle

### 4.1 内容

`crates/caly-engine/src/bundle.rs` 的 `BUNDLE_SECTIONS` 是显式清单（第十二轮 10 段；第十三轮加
`overload` 段为 11 段；`ADR-038 §2` 的回收记录使 `storage-gc` 成为第 12 段；`ADR-057` §5 切片 3
的耐久作业轨迹使 `job-history` 成为第 13 段），渲染顺序即声明顺序：

```text
header · architecture · capability · apply-journals · snapshots · recovery ·
effect-plan · runtime-log · job-history · resources · overload · storage-audit · storage-gc
```

| 段 | 来源 | 对应条目 |
|---|---|---|
| `header` | `BundleIdentity`（daemon bootstrap 注入）+ `env!("CARGO_PKG_VERSION")` + `cfg!(debug_assertions)` | `§12.2` 版本信息 |
| `architecture` | `EngineState`（lifecycle / generation / queue / 作业状态计数） | `§12.2` 架构状态摘要 |
| `capability` | `caly_cap::default_registry_document()` 计数 + 最近一次 apply 的 verdict | `§12.2` capability 摘要、`ADR-024` |
| `apply-journals` | `ApplyJournalStore::list_apply_journals`（**本轮新增**） | `STORAGE_RECOVERY §9.3` 第 1 项 |
| `snapshots` | `list_snapshots` + `latest_last_known_good` | `§9.3` 第 2、3 项 |
| `recovery` | `scan_recovery_state()`（含 `RecoveryFailed`） | `§9.3` 第 4 项 |
| `effect-plan` | `last_effect_plan()` 逐步 `step_kind_name` | `§12.2` 脱敏后的 apply 报告 |
| `runtime-log` | 最近 4 个作业 × 12 行 | `§12.2` 脱敏后的日志 |
| `job-history` | `JobLogStore::list_job_logs`（耐久终态作业记录，最新在前；8 作业 × 12 行有界；**存储投影而非内存投影**——不依赖本进程 `restore_job_logs`） | `ADR-057` §5 切片 3 |
| `resources` | 对象数/字节数/按 kind 计数、事件窗、待决 OS journal 数 | `§12.2` 资源统计 |
| `overload` | `EngineState` 的拒绝记录（按类别汇总，总数取自完整计数器而不是有界窗口）+ 队列 `depth/capacity` | `OVERLOAD_AND_RETRY_MODEL §7.2` 的内部出口、`§10 Stage 3` |
| `storage-audit` | `caly_storage::audit_backend`（与 `doctor` 同一个函数） | `§9.2` |
| `storage-gc` | `EngineState::last_gc_run`（ refusal / deleted / failed 逐条） | `ADR-038 §2` |

`header` 里 `instance identity unavailable: engine lock poisoned` 这类行不是装饰：一个「读不到」必须
比一个看起来正常的默认值诚实（同 `§9.2` 的 `Observation` 原则）。

### 4.2 出口、读回与生命周期

bundle 的字节走 `ObjectStore::put`（`ObjectKind::SupportBundle`），对象 key 就是内容的 `sha256:` 摘要；
作业上留给操作员的是这条 `Log`（含摘要）与一个 `Stage{ "bundle.committed", 100 }`。

**读回**（`DiagnosticsOp::ReadSupportBundle`，一个 Query）：

```rust
SupportBundleReadRequest { digest: Option<String>, max_bytes: Option<u64> }
//  None  = store 里最新的那个 bundle（客户端只点了"导出"，没有理由要求它会解析摘要）
```

三条约束都是被实测逼出来的，不是审美：

1. **只读 `ObjectKind::SupportBundle`**，且在碰到任何字节**之前**判定。CAS 里同时存着
   `CompiledArtifact` / `RawSource` —— 那是 core 要跑的配置，按设计**不脱敏**。一个"给摘要就返回内容"
   的查询会立刻把脱敏导出变成 secret reader，所以拒绝消息只说"它是 `CompiledArtifact`"，不回显内容
   （`ONBOARDING_NOTES §4.48`）。
2. **`max_bytes` 截断响应，不截断校验**。daemon 先按自身上限读全并让 store 校验锚点，再按需前缀化；
   否则"我只要前 120 字节"就是绕过 `RFC-0007 §6.3` 完整性检查的开关。截断视图里的
   `content_sha256` 仍是**整包**的锚点，`truncated: true` 明说这是片段。
3. **读时校验**在两个后端语义一致（`caly-storage/tests/object_contract.rs` 同一组断言跑两遍）；
   超限错误在 store 层措辞统一，不把 `var/caly/objects/…` 这种内部路径泄进客户端可读的文本
   （`§4.47`：`RFC-0010 §4.1` 把路径列为需谨慎展示）。

仍然**没做**的一件事：把包写到调用方指定的路径。那需要平台/导出位置决策（`ADR-011` 下 `caly-daemon`
没有平台层），本轮把"读回内容"补齐后，这一步只剩"落到用户要的位置"，不再是"能不能拿到"。

因为没有任何 snapshot 引用 bundle 对象，`RFC-0007 §13` 的 GC 在宽限期后可以回收它 —— 这是诊断导出
应有的生命周期，不是遗漏；需要长期留存的使用者应按摘要取出后自行另存。

### 4.3 「不包含明文 secret」是可证的

`§14.3` 的断言用的是 `Redactor::exposes_sensitive_text`（＝「再过一遍规则不再改变任何字节」），
而不是「测试里那几个 token 串没出现」——前者不依赖测试作者想到所有形态。配套两条：

- `the_draft_shows_what_the_bundle_would_have_leaked`：同一个 `BundleDraft` 未掩前**确实**含明文，
  否则「bundle 里没有」可能只是因为「bundle 里什么都没有」。
- `the_bundle_bytes_on_disk_hide_what_the_operator_pasted`（daemon 侧）：走真实 `StdFs`，把导出文件
  从盘上读回来检查，输入是客户端可控的 `ProxyTestDelay.node_ids`，并同时覆盖 named-value 与
  已登记字面量两种泄漏形态。

---

## 4.4 `docs/history/ONBOARDING_NOTES.md` 引用与本文编号

`crates/caly-arch-test::docs` 会扫 `docs/**` 检查表格列数、列表连号、小节号唯一、以及反引号里引用的
`crates/…`/`docs/…` 路径是否存在。本文引用的每一条路径都过这个门禁；若将来把 `redact.rs` 改名，
本文会先编译期失败（`cargo test -p caly-arch-test`），而不是悄悄留下断链。

---

## 5. 复现

```bash
export PATH="$HOME/.cargo/bin:$PATH"
cargo test -p caly-common                         # 25：规则本体（含幂等、无误伤）+ digest 向量
cargo test -p caly-storage --test apply_journal_listing   # 4：枚举原语 + 损坏记录必须炸
cargo test -p caly-engine --test support_bundle   # 8：内容、CAS 一致性、导出脱敏
cargo test -p caly-daemon --test redaction_boundary       # 6：三条出口 + doctor/bundle 一致
cargo test -p caly-storage --test object_contract   # 8：内容读回 + 两个后端同一组断言
cargo test -p caly-daemon --test support_bundle_readback  # 5：读回、类别收窄、截断语义
cargo test -p caly-app --test write_parity  # 7：写侧 parity（含 bundle 读回一致性）
cargo test -p caly-daemon --test job_events        # 4：事件窗口读回，行本身也是掩过的
./scripts/check.sh                                # all gates passed
```

撤掉某一层脱敏/检查后，对应断言立刻变红（各跑一次后还原）：把 `service.rs` 里 `redact_job_event`
那一行注释掉 → 日志边界两条失败（而 bundle 与 `ApiError` 两条仍绿，证明三条边界互不依赖）；
把 `read_support_bundle` 的 kind 检查去掉 → 收窄那条失败；把读时锚点校验去掉 → 篡改那条失败；
把 `max_bytes` 直接当成 store 的上限 → 截断那条失败（说明"截断不跳校验"不是口头约定）；把
`worker.rs` 的 `DiagnosticsBundle` 分支换回旧的 skeleton，`caly-app` 的
`remote.diagnostics.support_bundle.committed` 立刻失败（本轮各实测过一次，均已还原）。
