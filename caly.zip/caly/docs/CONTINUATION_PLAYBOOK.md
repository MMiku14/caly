# Caly 接续开发手册：工作流程与经验

> 这份文件不是规范，也不新增义务。它是**方法**：从第十八轮到第六十二轮（2026-08-27 → 2026-08-30）在
> 这个仓库里连续推进后，把"怎么做才不出事"和"哪些做法被证明会出事"写在一起，让下一个接续者
> 不必重犯同样形状的错。当前状态以 `IMPLEMENTATION_STATUS.md` / `CENTERLINE_PROGRESS.md` 的快照为准，
> 本手册中的轮次数字和例子若标明历史，只用于说明方法。
>
> 权威顺序不变（`docs/README.md §5`）：**RFC > ADR > 工程文档 > 代码**。这份手册排在"工程文档"一档，
> 且只补充*操作方法*；它与任何 RFC/ADR 冲突时，以那两份为准。
>
> 三条索引，先看它们再看本文：
>
> - 具体缺陷与逐轮判断：`docs/ONBOARDING_NOTES.md §4`（本文每条规矩后面的 `§4.NNN` 都指向那里）
> - 现在还剩什么没做：`docs/IMPLEMENTATION_STATUS.md` 的未覆盖清单
> - 待办与阻塞点：`docs/ROADMAP.md §1bis`（按阶段量的完成度）

---

## 1. 每一轮的标准流程（八步，按顺序，别乱）

| 步 | 做什么 | 命令 / 判据 |
|---|---|---|
| 1 | **先量，再决定这轮做什么**。不接受"文档说没做"或"我记得上一轮…"作为依据：用 grep / 一次跑测 / 一次临时打印把现状钉住 | 例：第三十轮的响应上界，起点是 `grep -n "MAX_FRAME_SIZE_BYTES" crates/caly-ipc/src/*.rs` 加上读 `encode_raw_json` 发现它不检查尺寸 |
| 2 | **写下靶子的判据**：本轮要成立的性质，用一句可以被证伪的中文说清楚 | 例：第二十九轮「载荷超过 `Ctx::io_budget.max_bytes` 时，端口必须在**任何字节落地之前**拒绝，并且文案点名是哪条上限」 |
| 3 | 改代码。**只做这一件事**：顺手重构是下一轮的靶子，不是本轮的便利 | `cargo check --workspace --all-targets` 必须 0 warning（这是门禁，不是建议） |
| 4 | **格式化只跑自己碰过的文件，并且是每个文件的最后一次写** | `rustfmt --edition 2021 <files>`；禁止 `cargo fmt --all`（7.7k 行噪声会淹没改动，`§4.116`） |
| 5 | 重新生成测试普查表，并**手写**新行的描述（脚本不许替你编理由） | `python3 scripts/regenerate_test_census.py`；`--check` 只报不改；新增文件必须给描述，脚本会打印 `describe these new rows: [...]` |
| 6 | 文档一遍：ADR（若有决策/偏离）→ 工程文档 → `IMPLEMENTATION_STATUS` → `CENTERLINE_PROGRESS` → 开发日志 → 本手册（若流程本身变了） | 每处改完 `grep` 一遍**旧值**，命中数 0 才算完（`§4.119`） |
| 7 | **证伪**：本轮每条新断言、每个新门禁，都要有一个"让它失效"的变异 | `python3 /tmp/falsifyNN.py`（模板见 `scripts/`，规程见本文 §5） |
| 8 | 收尾复核：`bash scripts/check.sh` **连跑两次 diff 为空**；下限先撕开再还原；无备份残留 | 见本文 §11 的清单 |

**为什么顺序是硬的**：第 6 步在第 7 步之前，是因为证伪会改文件；第 5 步在第 6 步之前，是因为文档里的数字要引用普查结果。第三十轮我就把第 4 步漏在第 3 步的一次追加编辑之后，欠账从 1,685 跳到 1,761（`§4.116`）。

---

## 2. 不可协商的边界

| 边界 | 内容 | 为什么 |
|---|---|---|
| 依赖边界 | 直接外部 crate 必须先有 ADR 授权；当前唯一例外是 `caly-daemon` 的 `serde_json`，由 `ADR-046` 授权，其他直接依赖保持 workspace path | 可复现仿真与可审计边界（`ADR-022`）；不能再把当前 workspace 写成“零外部依赖” |
| 依赖方向 | 只允许 `crates/caly-arch-test/src/lib.rs` 的 `ALLOWED_DEPENDENCY_EDGES` / `ALLOWED_DEV_DEPENDENCY_EDGES` 里声明过的边；`caly-io-sim` 永不进生产边 | 门禁 `no_undeclared_production_dependency_edges`；这就是 `caly-daemon` 不依赖 `caly-io` 而引擎要 re-export `caly_io::Clock` 的原因 |
| 时钟 | 只有 `caly-io-std` 能读宿主时钟（`crates/caly-io-std/clippy.toml`）；其余地方**没有时钟就没有期限判断**，"不可判"要如实报告 | `§4.86` 的三腿：不判、不猜、要说出来。这条决定了第三十轮"poll 预算不是 Deadline"的选择 |
| clippy 基线 | 不抬 `CLIPPY_BASELINE`，不加 `#[allow]` 来消音；改代码 | 新 lint 会打在**新代码**上（`§4.44` 补记）；本轮 `assertions_on_constants` 就是它替我们把"两个常数的关系"写成 `const _: () = assert!(…)` |
| 基线存档 | 绝不覆盖 `/home/user/caly.zip`（原始交付物） | 它是唯一能证明"本轮改了哪些"的对照物（本工作区不是 git 仓库） |
| 权威顺序 | 与冻结签名冲突时（如 `RFC-0007` 的 `StorageBackend`、`RFC-0002 §14.4` 的码表），**写清落差**而不是绕过 | 例：端口层 `CapacityExceeded` 与 API 层 `CONFIG_INVALID` 之间的有意落差，写在 `ERRORS §5.1` / `OVERLOAD §3.7` / `ADR-036 §6bis-decies` 三处同口径 |

---

## 3. 数字纪律（我犯得最多的一类，11 次）

1. **只抄裁判自报的数**：`scripts/check.sh` 的那几行、`regenerate_test_census.py` 的
   `files=N total=M rows=N`、`cargo test --workspace` 的 `test result:`。**不做加法**。
   我算错合计的次数：`§4.87`、`§4.105`、`§4.117`（三次：446/447/450、472、502）。
2. **重抄要放在最后一次改动之后**，包括"为文档补的那条测试"这种小改动。第三十轮我为一条断言补了
   `docs.rs` 的单元测试，总数从 499 变 501，文档里全是旧数——而且**没有门禁管 CENTERLINE 那句数字**，
   所以第三十轮加了 `the_centerline_assertion_count_matches_the_tree`，它上线当轮就抓到作者。
3. **一个数必须带口径**。`cargo fmt --all -- --check` 的"1,685 行"是**输出行数**；
   `grep '^Diff in' | wc -l` 是 **hunk 数**（同一状态 122）。混用会写出"欠账 122 行"这种谁都无法复现的话（`§4.118`）。
4. **常数之间的关系写进编译期**：`const _: () = assert!(A >= B, "为什么")`。测试里 `assert!(CONST_A > CONST_B)`
   是"永远不会失败的断言"（clippy 会喊，且它说得对）。
5. **测不到的数字就别写**。例：scenario 套件那一百多行里只有"≥100 且逐行 Passed"可判，
   所以文档里从来只写这一句，不写具体行数。

---

## 4. 断言与门禁的纪律

| 规矩 | 反例（真实发生过） |
|---|---|
| **一条断言必须能被证伪**：写之前先想"什么改动会让它变红"，想不出就改成别的形状或写进文档当已知缺口 | 第三十轮的 `&& !truncated` 守卫：M9 删掉它全仓不红，因为 audit 把 info 行聚合，"空层 + 被截断"在 daemon 层不可达 → 规则被命名成 `may_claim_clean` 单独测四组合（`§4.125`） |
| **上限要从两侧推** | 只有"超过会拒"的断言，等于允许把界改成 1 而没人发现（`§4.114`；第二十九轮的 M1 就是把预算改成 2） |
| **组合规则（取更严的一条）要测"宽松那条不得放大"** | `§4.122`，第二十九轮 M5 |
| **覆盖面要逐个实现失效地测** | 共享 helper + 两个后端：只有把**每个后端**的调用删一次都变红，"两边都调"才是事实（`§4.121`；第二十九轮 M1–M4） |
| **别把实现细节写进断言** | 我写 `assert_eq!(len, DIAGNOSTIC_MAX_LINES)`，实际 127（那个夹具里先咬的是字节预算）；改成守恒律 `carried + omitted == total`（`§4.126`） |
| **交互顺序要断整条序列** | 只断子集会同时看不见"多做了一次"和"顺序错了"（`§4.110`） |
| **加界/加截断时，必须有一条"不设界就会越界"的对照** | 否则断言在"数据本来很小"的世界里全绿（`§4.127`：`without_the_bound_this_answer_would_have_exceeded_the_frame_cap`） |
| **门禁自己要有反空转断言** | "扫到的文件数 ≥ 8"、"至少要找到 2 个后端"、"docs 树 ≥ 30 篇"——目录一改，扫描变空是静默通过的经典方式（第三十、三十一轮各一条） |
| **报告"没编译"和"没咬住"要分开** | 变异写成 `if cond && false` 会删掉 `if let` 的绑定 → `E0425` → 它证明的是 rustc，不是断言（`§4.112`） |

---

## 5. 证伪 harness 的操作规程

模板：`/tmp/falsifyNN.py`（历轮同族，`§4.60 / §4.64 / §4.66 / §4.71 / §4.84 / §4.87 / §4.93 / §4.98 /
§4.112 / §4.121` 是它自己的规矩来源）。硬要求：

1. **一次一个变异，一个变异只改一个文件**（两个文件同时改，红了不知道是谁）。
2. 变异必须**保住绑定、类型、调用 arity**——目标是"性质不成立"，不是"程序坏掉"。
3. 备份-还原按**内容与 mtime 双双还原**：`shutil.move(backup, path)` 然后 `os.utime(path, None)`，
   并用 `sha256` 断言还原后与动手前一致。（第三十轮我一度用 `cp` 还原，`mtime` 保留旧值导致门禁跑的是缓存。）
4. 启动时清扫上一轮残留的 `*.rNNbak`；收尾时 `find` 必须为空。
5. **先重生成普查再跑**，这样"还原后全仓绿"才有意义。
6. 每个变异列出**期望变红的测试名**，命中才算咬住；`build_failed = "error[" in out or "could not compile" in out`，
   并把 `cargo` 自己的 `error: test failed` 与"没编译"**区分开**。
7. 一个变异**不咬**时，先改变异、别急着改测试：多半是断言还没长在分支上（`§4.125` 就是这个流程的产物）。

---

## 6. 文档手术规程（跨轮踩坑总结）

这个仓库的门禁里，有四条是**文档形状**的（表格、编号、路径、处置表），因为它们历史上出过五次事：

1. **表格行不许换行**：一行表行写多行 = 渲染器把续行当段落，且列数检查看不见（`§4.89`：一次批量补丁
   把表格行粘进段落，**所有门禁全绿**）。
2. **表行之间不许空行**：markdown 里空行**结束表格**，之后的行变成段落。`check_disposition_ledger`
   因此带相邻性检查——它第二十八轮加，第三十轮立刻咬住我新行前的一个空行。
3. **围栏内的例子一律跳过**：自动化曾因把散文里的代码片段当成表行而误伤（`§4.89`）。
4. **脚本写法**：把补丁写成 python 文件（不是 heredoc 里的正则），`assert t.count(old) == 1` 之后
   **一次性写文件**；多行锚点先让程序证明它存在，别从终端输出肉眼复制（`§4.123`：我栽在漏 `**`、
   漏缩进、Python 里 `\`+换行被吃掉）。
5. **一行只归一条规则**：两条规则命中同一行 → 重复插入而不是替换失败（`§4.129`，门禁抓不到，
   因为数字对、句子不通）。改完必须**把那几行读一遍**。
6. **脚本报错就是没写**：`assert` 中途失败 → 后面的文件一个都没改。**重跑同一个脚本**，
   已应用的 hunk 会报 `hits=0`，据此判断哪些还没落盘——第三十轮我发现上一轮有两处文档改动就这么静默丢了，
   而门禁全绿。
7. **历史不改写，只追加**：旧段落里被后来事实推翻的句子（例如"`max_bytes` 仍然不生效"）保留原文 +
   一条 `（第N轮更新：…）` 注。这些文档同时是决策日志，抹掉就丢了"当初为什么这样以为"。

---

## 7. 现有门禁清单（新增前先查这张表，避免造重复轮子）

| 门禁 | 判什么 | 它的失效形状（怎么知道它在工作） |
|---|---|---|
| `check.sh`：build 无警告 / `TEST_FLOOR` / clippy 位置棘轮 / fmt 提示 | 编译干净、测试数不下限、告警不增、格式化欠账可见 | 把 floor +1（`FAIL test count fell below the floor…`） |
| `regenerate_test_census.py --check` + `status_table_test_counts_match_the_tree` | `IMPLEMENTATION_STATUS §3.3` 每行的测试数与树一致、不许有未登记文件 | 加一个 `#[test]` 不改表 |
| `every_documented_path_reference_resolves` | 文档里 `crates/…`/`docs/…`/`scripts/…` 引用必须存在 | 删掉一个被引用的文件（**注意**：它不查节号，`§4.107`） |
| `doc_tables_and_lists_are_well_formed` | 表格列数、分隔行、列表编号、重复节号、表行被粘进段落 | 删掉某表的分隔行 |
| `check_disposition_ledger` | 处置表行号连续、收尾标题 = 末行 +1、**行与行相邻** | 在两个行之间插一个空行 |
| `the_document_index_lists_every_top_level_document` | `docs/README.md §1` 的目录树 ↔ `docs/*.md` **双向**一致：新文档不进索引 = 没人会读它；索引留着已删的文件 = 空头承诺 | 加一篇文档但不改 README（第三十一轮当天就咬了加它的人，`§4.130`） |
| `check_disposition_ledger` 的两条 | 行号连续 + 行与行相邻 + **每行以 `|` 收尾**（第三十一轮加：上一轮我自己把处置表写成多行，渲染时那一段变成散文） | 在两个行之间插一个空行；把一行的中段换行 |
| `the_centerline_assertion_count_matches_the_tree` | CENTERLINE 那句「这 N 个断言是否依然成立」= 树里的实际数（含"句子消失"与"出现两次"） | 把那个数改错 |
| `the_document_index_lists_every_top_level_document` | `docs/README.md §1` 的目录树 ↔ `docs/*.md` 双向一致（第三十一轮加） | 新加一个文档却不写进索引 |
| `production_code_drives_effect_plans_through_the_cursor_entry_point` | 生产 `src/` 不许调用无游标的 `execute_effect_plan(` | 加一个行为不变的第二接缝（M13，测试全绿、只有门禁红） |
| `the_durable_store_drives_ports_through_the_shared_budget` | `caly-storage/src/**` 不许 `block_on_ready(`（`audit.rs` 豁免并写明理由） | 让某个文件自己驱动端口 |
| `every_backend_that_runs_the_fs_suite_runs_the_byte_budget_check_too` | 跑了 fs 套件的后端必须也跑字节预算检查 | 某个后端悄悄停掉这一项（M10） |
| `dependency_direction.rs` 其余四条 + `pure_core_crates…` | 依赖边、陈旧豁免边、纯核心不碰 IO/墙钟、成员覆盖 | 往 `ALLOWED_*` 里塞一条没用的边 |

**新增门禁的三条要求**：① 有单元测试说明它判什么；② 有一个"让它变红"的变异；③ 带一条反空转断言
（扫到的对象数 ≥ 下限），否则目录一改它就静默变成扫 0 个。

---

## 8. 环境与工具

- **每个 bash 调用都要** `export PATH="$HOME/.cargo/bin:$PATH"`。工具链在会话中消失过**三次**
  （`~/.cargo/bin` 只剩 `rustup` shim）；恢复：
  ```text
  export RUSTUP_HOME=$HOME/.rustup CARGO_HOME=$HOME/.cargo
  chmod +x $HOME/.cargo/bin/rustup
  $HOME/.cargo/bin/rustup toolchain install stable --profile minimal --no-update
  $HOME/.cargo/bin/rustup component add rustfmt clippy
  ```
  （注意 `--no-update`，不是 `--no-modify-path`。`§4.124`。）
- `check.sh` 的第一步会**报错并附恢复命令**，而不是静默绿——环境类前置条件就该做成会喊的 gate。
- 空输出 ≠ 通过：`cargo … | grep …` 什么都不印，很可能是 cargo 根本没跑（它的 `command not found`
  写在自己的 stderr 里，被管道吞了）（`§4.100`）。
- 需要 cargo 重印 target 清单时得 `find crates -name '*.rs' -exec touch {} +`，**但**这会毁掉
  "本轮改了哪些文件"的时间戳信号（`§4.113`）：要拍照就先存一份 `find -newermt` 的输出。
- 沙箱里没有 `bc`，没有 CI，工作区不是 git 仓库：所以"改了什么"只能靠 sha256 与门禁，不能靠 `git diff`。

---

## 9. 怎么挑下一件事

优先级的正确排法不是"哪个功能缺"，而是**哪个阻塞点被解开后能同时解锁多件事**。截至第六十二轮的经验：

1. 先查三处 backlog：`docs/ROADMAP.md §1bis`（按阶段量的完成度与阻塞）、
   `docs/IMPLEMENTATION_STATUS.md` 的未覆盖清单、各 ADR 的"还没有的"小节。三处不一致时，**以能跑出证据的那处为准**，并把另一处改对。
2. 分类每个候选：**"需要写代码"** vs **"需要决策"**。后者的标志是它撞上冻结层
   （`RFC-0007` 的 `StorageBackend` 签名、`RFC-0002 §14.4` 的码表、`clippy.toml` 禁用 `Command::new`、
   Platform 权限、真实 effect runtime 的生产默认）。要引入外部 crate 必须先有 ADR（当前 `serde_json` 是
   `ADR-046` 已授权的例外）；需要决策的候选**要么写 ADR 提案要么先不动**，不要在代码层偷偷绕。
3. 一件好靶子的形状：**现状可以量出来是错的**（或至少是"没人读"），修法在冻结边界之内，性质可以被一条
   会红的断言钉住。第十九到三十一轮挑的题都符合这个形状：时钟注入、GC 触发、探针时限、逐步游标、
   挂起的类型、字节上限、响应上界。
4. 如果本轮只是补文档/门禁（第三十一轮就是这样），那也**必须**留一条能证伪它的东西，否则它就是散文。

---

## 10. 缺口的三个登记处，别只写一个

| 登记处 | 记什么 | 读者 |
|---|---|---|
| `docs/ONBOARDING_NOTES.md §4` | 每一个"发现/自我修正"一条，含现象、为什么、处置、可复用 | 下一个接手的人（学的是形状） |
| `docs/ONBOARDING_NOTES.md §6` 处置表 | 一行一轮：这轮做了什么、判据是什么、牵连哪些 `§4.NNN` | 想快速知道"这仓库被怎样推进过"的人 |
| `docs/IMPLEMENTATION_STATUS.md` 未覆盖清单 | **现在**还缺什么，以及"为什么不是遗漏而是缺口" | 想判断能不能交付的人 |
| 各 ADR 的"还没有的"小节 | 该决策的落地**边界**（哪些一半故意没做、为什么） | 下一轮要挑靶子的人 |

规矩：**结构性限制必须写进文档，不许藏在提交信息或口头汇报里**；文档里也不许用"下一步"含糊过去——
要么写"没做，理由 X"，要么写"不需要，理由 Y"（第三十轮对"查询侧接不接调用方预算"的答复就是后者）。

---

## 11. 一轮收尾清单（照抄即可）

```text
[ ] cargo check --workspace --all-targets           0 warning
[ ] bash scripts/check.sh                             all gates passed
[ ] bash scripts/check.sh（第二次）→ 与第一次 diff 为空
[ ] 文档收口后直接运行 `./scripts/check.sh`；若模式位未保留，再用 `bash scripts/check.sh`，不要混写结论
[ ] python3 scripts/regenerate_test_census.py --check   退出码 0（当前 `files=94 total=710 rows=94`）
[ ] 新加断言/门禁全部有对应证伪变异，且 harness 报 "all mutations bit: True"
[ ] 每个变异的"没编译"与"没咬住"分开看过
[ ] 下限先撕开（floor +1）看到 FAIL 原文，还原后 sha256sum -c → OK
[ ] find . -name '*.bak' -o -name '*.orig' -o -name '*.rNNbak'          空
[ ] cargo fmt --all -- --check 的清单里没有本轮碰过的文件；欠账数与上轮一致
[ ] 本轮所有数字重抄完后，grep 旧值 → 命中 0（跨 docs/ 与 crates/）
[ ] 本轮改过的**每一行文档都读一遍**（片段替换会把那行变成重复片段，`§4.131`）
[ ] 新增文档 → `docs/README.md §1` 已收录（有门禁，别靠记性）
[ ] 开发日志的引用段与门禁输出逐字节相同（只剥 ANSI，不许顺手剥缩进——那样会造出假 DIFFER）
[ ] docs/README.md §1 收录了本轮新增的文档（门禁会替你查）
```

---

## 12. 这份手册自己的可证伪性

- 它被 `docs/README.md §1` 的目录树收录，由 `the_document_index_lists_every_top_level_document` 检查
  （第三十一轮加）。也就是说：**如果下一个接手者加了文档却不更新索引，或者删了这份文件却留着索引，
  `cargo test` 会红**。
- 文中引用的每条 `§4.NNN` 都指向 `ONBOARDING_NOTES.md` 里真实存在的条目；引用命令的行为可以在
  `crates/caly-arch-test/tests/doc_consistency.rs` 与 `scripts/` 里核对。
- 它不复述任何"当前有几个测试"这种每轮都变的数字——那类数的家在 `IMPLEMENTATION_STATUS §3.1/§3.3`，
  由 `regenerate_test_census.py` 与门禁维护（本文因此不需要跟着每轮改，这就是它存在的理由之一）。
