# Caly 开发日志 — 2026-08-31（第一百零八轮：Job Log Durability 切片 1 —— 存储 primitive）

R107 立了 `ADR-057`（部署作业事件持久化 / Job Log Durability，Accepted）。本轮按
`ADR-057 §5` 的四切片实施序做**切片 1：存储 primitive**，只碰 `caly-storage`，**不接
引擎/daemon、不做启动载入、不挂 GC、不做进行中作业 D1 滚动段**（那是切片 2/3 与可选
增量面）。无新外部 crate、无 wire 帧形状变更、无依赖边变化。

---

## 1. 本轮靶子

### 1.1 范围（ADR-057 §5 切片 1）

`caly-storage` 新增一等记录族 `job-log`，与 object / revision / snapshot / journal /
apply-journal / source-index 并列：

- 存储自有**纯类型**（不依赖 `caly-api` / 引擎领域类型，照 `SourceIndexRecord` 的纯
  信封模式）：`JobEventRecord{kind, line}` 与 `JobLogRecord{job_id, state, revision,
  outcome, failure_code, failure_summary, last_stage, last_stage_pct, warning_count,
  log_count, events, committed_at_unix_ms}`，字段全 `String/u64/u8/usize/i64/Option`。
- `JobLogStore` trait：`put_job_log` / `get_job_log` / `list_job_logs`，三法都带
  `StorageErrorKind::Unsupported` 默认臂；并作为 supertrait 挂进 `StorageBackend`
  约束列表（与 Object/Revision/.../ApplyJournal 同列）。
- record codec：`encode_job_log` / `decode_job_log`，事件用**重复 `event` key**、值
  打包 `kind<TAB>line`（tab 不在 tag 内，line 经 record codec 转义可含多行）；
  `known_fields` 加 `job-log` 12 键表，未知 key 由 `decode_and_check` 拒。
- 双后端同契约：`FsStore`（终态 **D3**：`write_text(..., Durability::D3)`，落
  `records/job-log/<escape(job_id)>.rec`；open scan 经 `RECORD_KINDS` 5→6 自动覆盖 +
  `name_claim` 校验；`load_job_logs` 读目录按 job_id **降序**，能 parse u64 则数字降、
  否则字符串降）与 `InMemoryStorage`（同序）。

### 1.2 可证伪判据

> 一条写进 store 的终态作业记录，必须在**同一个 store** 和（FsStore）**同一个 root 上
> 新开的 store 实例**里按字节读回；`list_job_logs` 必须是 newest-first；任何带「本版本
> 不认识的字段」或「坏事件形状」的记录必须被**点名拒绝**，而不是静默部分解码。

---

## 2. 遇到的问题与处置（留档 `ONBOARDING_NOTES §4.182`）

1. **`JobLogStore` 三法误置于 `impl StorageBackend`**：`JobLogStore` 是与 `ObjectStore`
   并列的**独立 trait**（不像 source-index 四法是直接挂在 `StorageBackend` 上的关联
   fn），三法必须放在独立的 `impl JobLogStore for FsStore {}` /
   `impl JobLogStore for InMemoryStorage {}` 块。第一次编译报 E0407（method is not a
   member of trait `StorageBackend`）+ E0277（`FsStore/InMemoryStorage: JobLogStore is
   not satisfied`）。**规则**：加一个新 store 面时，先分清它是「StorageBackend 上的
   关联方法」（source-index 模式）还是「独立 trait + supertrait 约束」（object/
   journal/... 模式）；后者的实现写在独立 impl 块。
2. **把 `JobLogStore` 挂成 `StorageBackend` supertrait 后，workspace 里所有手写 fake
   backend 全部不满足约束**：`cargo test --workspace --no-run` 报 7 处 fake
   `impl StorageBackend for X {}`（daemon `UnreadableStore`/`InconsistentStore`，engine
   `NoContentWalk`/`JournalSpy`/`BrokenJournal`/`FlakyStorage`，及非空委托型
   `UnverifiedRawStorage`）。空块 fake 加空 `impl JobLogStore for X {}`（继承
   Unsupported 默认臂，与它们 StorageBackend 空块语义一致）；委托型
   `UnverifiedRawStorage` 加三法委托给 `self.inner`。**规则**：给 `StorageBackend`
   加 supertrait 是一次跨 crate 的契约扩张，`cargo test --workspace --no-run` 会列出
   每个手写 fake；空 fake 用空 impl（默认 Unsupported）、委托 fake 照搬委托块。
3. **open 启动扫描对坏记录的行为是「收集 problems → open 失败」而非「读时才拒」**：
   `records/job-log/` 在 open 时被 decode，带未知字段的记录让 `FsStore::open` 直接
   返回 `FsStoreError`（summary 点名集合 + 字段名）。契约测试据此断言「带未知字段的
   job-log 让 reopen 失败」，而不是 reopen 成功后 get 才拒。`get_job_log` 单点读仍有
   `IntegrityViolation` 臂（decode_and_check），两道防线。

---

## 3. 裁判（测试）

- `crates/caly-storage/tests/record_codec.rs` 加 5 条（19→24）：终态记录全字段 + 多行/
  转义事件逐字节 round-trip；可选字段缺席而非空串（空 failure_code 归一 `None`）；
  未知字段点名拒绝；缺 required（`state`）按名报告；**丢 tab 的事件（缺 kind 分隔符）
  拒绝**。
- 新建 `crates/caly-storage/tests/job_log_contract.rs`（2 条）：双后端同断言
  （写后按字节读回、未知 job 是 `None`、两条记录数字 id 降序）+ FsStore **同 root 新开
  实例重启读回一致**（kill-9 重启的存储侧骨架；in-memory 无盘，不参与此断言）；
  **重启扫描对带未知字段的伪造 job-log 点名集合+字段名拒绝**。
- 证伪（一次一变异，备份双还原 sha256 全等）：
  - M1：`decode_job_log` 事件 `split_once('\t')` 的 `ok_or(报错)` 改成
    `unwrap_or((packed, ""))`（吞掉缺 tab 事件）→ `job_log_rejects_an_event_that_lost_
    its_kind_separator` **变红**，4 条 round-trip 仍绿（特异性好）；还原 sha256
    `a4eac4…6fd5` 全等。
  - M2：`load_job_logs` 数字排序 `b.cmp(&a)`（降序）改成 `a.cmp(&b)`（升序）→
    `a_terminal_job_record_round_trips_on_every_backend` 的 fs-store newest-first 断言
    **变红**；还原 sha256 `77944d…e343` 全等。

---

## 4. 数字与门禁

- census：866 → **873**（+7：record_codec +5、job_log_contract +2）；floor 866 →
  **873**（`scripts/check.sh` TEST_FLOOR）。census 由 `regenerate_test_census.py`
  重建 §3.3 表。
- clippy baseline 持平 **31**，`caly-storage` 零 warning；无 `#[allow]`、无
  `cargo fmt --all`（只 `rustfmt --edition 2021` 碰过的文件）。
- 未碰：引擎、daemon、wire、IPC、CLI、依赖边、caly.zip 基线。

---

## 5. 明确没做（后续切片，仍挂起）

- 切片 2：引擎进终态时写 job log + 启动恢复把终态记录载入引擎 `state.jobs`
  （`JobState/JobOutcome/JobEvent` → 存储纯类型的映射在这一层做）。
- 切片 3：daemon 恢复接入 + GC root（被 snapshot/revision 引用为 last-apply 的作业
  不误删）+ support bundle。
- 切片 4：真二进制「写作业 → `kill -9` → 同 data-dir 重启 → `jobs.list`/
  `jobs.events`/resume 命中」e2e。
- 可选增量面：进行中作业 D1 滚动段（ADR-057 标为可选，本轮不做）。
- 其余既有 deferred：CLI `--role`+轻认证（P1）、真核长部署 resume e2e（P2）、
  ROADMAP §13#3 多流生产化（P3）、R104 流式 END 帧加 failure_code（须 ADR）。
