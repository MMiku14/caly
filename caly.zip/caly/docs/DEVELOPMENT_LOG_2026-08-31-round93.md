# Caly 开发日志 — 2026-08-31（第九十三轮：hello 角色在信任边界 fail-closed 解析）

R92 让请求信封的角色取自握手协商值（`peer_role`），把"线端角色被硬编码 Admin"的提权洞堵上了。
本轮顺着同一根线再查一步：那个协商值本身是怎么从 wire 解析的——发现 lenient 握手解析把**未知/缺失
角色**也映成最高权限 Admin，是 R92 的同族 fail-open。无 wire 形状变更、无新依赖、无新 ADR（落实
`RFC-0002 §7.2` / `ADR-037` 已确立的角色语义）。另本轮**产出 TUI 规划文档**（`docs/TUI_PLAN.md`），
不实现（ROADMAP 把 TUI 排在最后）。

---

## 1. 靶子（量选与判据）

### 1.1 现象（fail-open 身份）

`caly_ipc::dialect::server_hello_from_records` 是 pre-round-71 留下的 **lenient** 解析：

```rust
role: match wire_field(records, "role") {
    Some("Operator") => Role::Operator,
    Some("Viewer") => Role::Viewer,
    _ => Role::Admin,        // 未知值 AND 缺失，都给最高权限
},
```

calyd 握手用的正是它（`bin/calyd.rs` 的 `KIND_HELLO` 分支）。于是 R92 之后的链路是：
`role=Root`（或 `garbage`、大小写不符的 `admin`、或干脆不带 role）→ lenient 解析成 `Admin` →
`SessionMachine.info.role = Admin` → `peer_role() = Admin` → envelope `role: Admin` →
`require_role` 放行 Admin-only 命令。一个畸形/省略身份的对端被当成最高权限。

对照：同一握手里的 `encoding` 字段，未知值是 **fail-closed 按名拒绝**
（`server_hello_session_json`）。对"无法解析的输入"，编码拒绝、角色却提权——自相矛盾。

### 1.2 为什么既有测试没抓到

dialect 单测 `server_hello_from_records_maps_the_wire_roles_and_protocol` **明确断言**
`role=Root → Admin`、空记录 → `Admin`。这是**有意保留的 legacy 合约**（老客户端/旧调用者依赖
宽松默认）。问题不是 lenient 函数写错了，而是**信任边界（daemon）不该继承它**。

### 1.3 判据（可证伪）

> daemon 握手解析角色必须 fail-closed：合法的 `Admin/Operator/Viewer` 字面各自映射；**未知值按名
> 拒绝**（HANDSHAKE）；**缺失角色默认最小权限 Viewer**（不默认 Admin）。lenient 旧解析可为旧调用者
> 保留宽松默认，但授权路径不得用它。

## 2. 实现

- `caly-ipc/src/dialect.rs`：新增 `server_hello_role(&records) -> Result<Role, String>`。
  - `Some("Admin"/"Operator"/"Viewer")` → 对应 `Role`；
  - `Some(other)` → `Err("role {other:?} is not on the v0 wire; the roles are Viewer, Operator
    and Admin")`（与未知 encoding 同形状，按名拒绝）；
  - `None`（缺失）→ `Ok(Role::Viewer)`（最小权限默认；角色面的"无 encoding 即 records"）。
  - `PrivilegedBroker` 是进程内凭据族（`role_name` 本就不把它当 wire 角色），在 wire 上落 `Some`
    分支按未知拒绝。
  - lenient `server_hello_from_records` 与其"未知→Admin"默认**原样保留**（旧单测仍钉），只加注释
    说明信任边界改用 `server_hello_role`。
- `caly-daemon/src/bin/calyd.rs` 握手分支：先 `server_hello_role(&records)`，`Err` 即在接受 hello
  前 `refusal(stream, false, 0, "HANDSHAKE", &problem); return;`；成功则
  `let mut hello = server_hello_from_records(&records); hello.role = negotiated_role;`——用 fail-closed
  结果**覆盖** lenient 默认。

## 3. 裁判

### 3.1 dialect 进程内单测（`crates/caly-ipc/src/dialect.rs`，2 条）

- `server_hello_role_maps_the_wire_roles_and_defaults_missing_to_viewer`：三角色字面映射；空记录与
  只带 client_name 的记录都 → `Viewer`（缺失不提权）。
- `server_hello_role_refuses_an_unparseable_role_by_name`：枚举 `Root`/`Administrator`/`admin`
  /`garbage`/`PrivilegedBroker` 全 `Err`，且错误信息含该值与 "not on the v0 wire"。

### 3.2 真实 calyd wire e2e（`crates/caly-daemon/tests/calyd_wire.rs`，2 条）

- `a_hello_claiming_an_unknown_role_is_refused_not_promoted_to_admin`：`role=Root` 握手必须回
  KIND_REFUSAL（kind 5，不是 hello_ack kind 2）、`code=HANDSHAKE`、summary 点名 `Root`。
  fail-open 变异下回 hello_ack（kind 2 vs 5），裁判红。
- `a_hello_with_no_role_defaults_to_the_least_privileged_viewer`：完全不带 role 仍能握手（回 hello_ack），
  但发 Admin-only `system.gc`（带 idempotency key，排除 key 闸）必须 KIND_REFUSAL/`code=PERMISSION`
  ——证明缺失默认 Viewer（若是 Admin 会放行，见 R92 的 Admin twin）。

### 3.3 结构门禁

`dependency_direction.rs::the_wire_daemon_parses_a_hello_role_fail_closed_at_handshake`：dialect 暴露
`pub fn server_hello_role(`；calyd 握手 match 臂（锚定 `KIND_HELLO if !hello_seen`，不是 import 别名）
含 `server_hello_role(&records)`、`hello.role = negotiated_role` 覆盖、且窗口内有 `"HANDSHAKE"` 拒绝。

### 3.4 证伪 `scripts/falsify_round93.py`（3 变异全 BIT，均编译绿、判据红）

- **M1**（解析 fail-open：未知/缺失都 → Admin）：dialect 单测红 + 未知角色 e2e 收到 hello_ack 红。
- **M2**（daemon 跳过 fail-closed 解析、直接信任 lenient）：门禁无 `server_hello_role` 调用点红，
  且未知角色被接受、缺失角色被当 Admin（两 e2e 都红）。
- **M3**（缺失角色也改成报错，而非最小权限默认）：dialect "缺失→Viewer" 单测红 + 缺失角色 e2e
  握手被拒红。M3 钉死"缺失默认安全"半边——防"凡非字面角色全拒"的过度收紧（那会破坏"无声明即最低
  权限"的安全缺省）。

## 4. 收口数字

- `cargo test --workspace`：824 → **829**（+5：dialect 2、calyd_wire e2e 2、arch 门禁 1）；
  `check.sh TEST_FLOOR=829`。
- clippy 唯一源码位置：**31**（= 基线，未抬、无 `#[allow]`）。
- rustfmt：只对碰过的文件（dialect.rs、calyd.rs、calyd_wire.rs、dependency_direction.rs）。
- 普查重新生成（files=105 total=829 rows=105），描述列手写补 R93。

## 5. 本轮环境事件（留档）

- 接续沙箱的 Rust 工具链在会话中途被重置（`~/.cargo/bin` 只剩 rustup、无 toolchain）。按钉死版本
  重装：`rustup toolchain install 1.98.0 --profile minimal --component rustfmt --component clippy`
  （rustc 1.98.0 / 88d9e12ae，与基线一致），随后继续。clippy 基线 31 未随重装漂移。

## 6. TUI 规划（本轮另一份产物，非实现）

- 新建 `docs/TUI_PLAN.md`：定位（calyd 的又一个 wire 客户端，与 `caly` 平级，不读内部）、非目标
  （不反向驱动架构、角色/授权继承 R92/R93）、依赖边界（`caly-tui` 只能 → caly-ipc/caly-api/
  caly-common，禁止 → caly-storage/engine/daemon；新增依赖边先入 ALLOWED 表）、屏↔op 映射
  （dashboard/profiles/job&follow/动作/诊断，全部用已有 op 与退出码；follow 屏继承 R91 流静默期限、
  动作屏继承 R92/R93 角色闸）、T0–T5 里程碑（每阶段独立可证伪、缺事实先回 daemon 轮次开口子）、
  实现前必须先有的 ADR（渲染栈 crossterm/ratatui vs 手写 ANSI；数据通路子进程 vs 直连 wire）。
- 严守 ROADMAP：TUI 排最后（里程碑 7），本轮只规划，不建 crate、不产生 `[[bin]]`。

## 7. 明确没做

principal/凭据/认证（`ADR-037` v1 "谁在调用 = 一个角色，仅此而已"）；不改 `require_role`/
`role_satisfies` 判定与本地门面；lenient `server_hello_from_records` 的旧默认保留（兼容合约，只是
信任边界不再用）；无 wire 形状变更、无新依赖。§13#3 残余主体仍为：共享 timeout scheduler、typed
`send_request_frame` 生产化、UDS peek（须先 ADR）。
