# Caly IPC Implementation Plan

本文件把当前 IPC 相关的 RFC、ADR 与 **生产接线** 收敛成一份实现计划。
目标是减少后续实现时的来回摇摆——尤其是把 harness 循环误当成生产 runtime。

交叉引用：`TRANSPORT_RUNTIME_MODEL.md`、`ROADMAP §13#3`、`IMPLEMENTATION_STATUS §8.22`。

> **📌 阅读提示（2026-08-31 更新）**：本文为 IPC 实施计划基线。此后第 88–103 轮已落地 v0 wire、双路径有界期限、帧关联/角色 fail-closed、流式/一次性 follow 与退出码诚实性等；最新状态见 `FEATURES.md §3–§4`、`IPC_STREAM_POLICY.md`、`IMPLEMENTATION_STATUS §8.22 之后各节`。§13#3 的 timeout scheduler/typed send_request_frame 仍未做。

---

## 1. 目标

把目前的协议分析和代码骨架推进成：

- 可维护的本地 IPC 栈（**同一套** bind/connect/pump，TCP 与 UDS 两个实现）
- 可恢复的 Job follow / watch 体系
- 可严格校验的 session / frame / request 三层模型
- 可明确桥接的核心协议，而不是被 gRPC/HTTP 倒逼设计

第八十七轮把第一项的生产最小面接上了：`BindSpec` / `WireIo` / `FramePump` /
`drive_client_hello`。其余三项仍按既有骨架推进，不在本轮假装完成。

---

## 2. 已经具备的骨架与生产面

当前已具备（骨架，多数有单测）：

- `RequestEnvelope` / `ResponseEnvelope`
- `ClientHello` / `ServerHelloAck`
- `SessionMachine`
- `SessionLoopInput` / `SessionLoopOutput`
- `StreamFrame` / `Ack`
- `StreamPolicy`
- `DaemonSession`
- `watch_bridge`
- Job follow query + stream skeleton
- `idempotency_key` 的外部承载位
- `caly_ipc::dialect`（R71：hello/hello_ack/请求头单一词汇表）
- `caly_ipc::wire_ops`（R76/R77：13 op 编码表 + 解码镜像 + 流双形状）
- `caly_ipc::wire` 入站/出站帧帽（R85：生产 CLI 走同一 codec）

第八十七轮起，生产 binary 另外具备：

- `BindSpec::parse`：`--bind` / `--addr` 一张语法表（TCP host:port、unix 前缀、
  绝对/相对路径；named pipe 与 abstract socket 按名拒绝）
- `WireListener` / `WireStream` / `WireIo`：TCP 与 UDS 同一 trait
- `FramePump`：共享 codec + 探测诚实性（TCP peek Closed / UDS Indeterminate）
- `drive_client_hello`：ClientLoop 只走 hello，dialect 字节在线上，
  `client_validate_hello_ack` 先于 `observe_hello_ack`
- `calyd`：`WireListener::bind` + `serve_connection(&mut impl WireIo)` +
  port-file `bound.port_file_text()`（TCP 裸 u16，UDS `unix:<path>`）
- `caly`：`WireStream::connect` + `drive_client_hello`
- UDS bind：`chmod 0o600`、stale socket unlink、拒绝 unlink 普通文件/目录

这意味着 IPC **最难的结构层**已经齐了，并且 **socket 层不再是两份 TCP 副本**。
它仍不意味着 `send_request_frame` 或 `SessionRegistry` 已上生产。

---

## 3. 剩余关键工作按顺序排布

### Phase A — Session Runtime Completion

1. ~~接 transport read/write loop~~ **第八十七轮**：`FramePump` + `WireIo`
   覆盖 TCP 与 UDS；`calyd`/`caly` 生产路径不再各写一份 `TcpStream` 循环。
   残留：每连接 `set_read_timeout`，没有共享 scheduler 对象。
2. hello timeout 真正进入调度 —— 生产已有 `HELLO_TIMEOUT`（5s）与
   `--session-idle-ms`（默认 30s）两条策略（round 46），设在 socket 上。
   缺的是跨连接的统一调度器，不是“陌生人没有期限”。
3. close reason 与 reconnect 规则固定 —— reconnect 仍在 daemon 流表
   （acked cursor、有界 64）；`WireIo` 不携带 close reason。
4. frame kind / frame side 校验继续下沉 —— dialect 已校验 hello_ack 内容；
   未知 kind 在 `serve_connection` 按名拒绝。typed `ClientFrame` 侧的完整
   校验仍主要在 harness。

### Phase B — Stream Runtime Completion

1. ACK 与 resend/resume 语义 —— 生产已有 STREAM_ACK 对话与至少一次投递
   （round 52）；typed `AckPolicy` 的通用 runtime 仍未接。
2. stream open 后第一帧规则 —— 生产泵 `JobStreamPump` 已钉先行后终 / 不推空帧。
3. reset reason 固定 —— state-gap 报 `resume_from`；typed reset 仍是骨架。
4. dashboard / connections snapshot-first 策略 —— 未开始（TUI 未创建）。

### Phase C — Job Follow Completion

1. query + stream 行为完全对齐 —— e2e 已有逐行逐字（R66）与跨 op 计数。
2. `from_event_index` retained/reset 规则固定 —— 引擎单元已钉；生产 CLI 透传。
3. CLI follow UX 与 exit code 对齐 —— `caly follow` 已按 `EXIT_CODES.md` 映射。
4. Job event DTO 细化 —— 现有 `JobEventsView` / 流帧 records 足够 v0。

### Phase D — RemoteApi/CLI Integration

1. request/session glue —— CLI 握手走 `drive_client_hello`；请求仍走
   `wire_request` 字符串表，**不**走 `send_request_frame`（R76 排除）。
2. follow loop —— 生产 CLI 已有；typed stream 循环仍是骨架。
3. retry/idempotency path —— 命令路径已有；transport 层重连不是 CLI 自动重试。
4. JSON 输出与错误映射 —— `--json` 与 `EXIT_CODES` 对照裁判已有。

---

## 4. 决策约束

实现时必须继续遵守：

- 核心本地协议使用 framed records（或协商后的 JSON）over **同一套**
  `WireIo`：TCP 与 UDS。Named Pipe 仍按名拒绝，直到有 Windows 宿主 ADR。
- gRPC/HTTP 仅作为未来 bridge 候选。
- stream policy 不得散落在多处 ad-hoc 分支中。
- request -> command / event -> stream / job -> follow 三个边界必须保持独立。
- UDS 探测不得发明 `Closed`（无 std peek；libc/nix 需 ADR）。
- TCP `--port-file` 保持裸 u16；UDS 必须写 `unix:<path>`。
- 生产 CLI 角色是 Admin，不得静默继承 `ClientSessionConfig::default` 的 Operator。
- 不得把 `SessionRegistry` / `ServerLoop` 的测试覆盖率写成生产 transport 完成。

---

## 5. 一句话结论

> 现在 IPC 最重要的不是再扩 operation 数量，而是把 session、stream、job follow
> 和 ack/resume 这四条主线做严谨。socket 层已经不再是缺口的主体：TCP 与 UDS
> 共用 BindSpec/WireIo/FramePump，hello 共用 HandshakeDrive。下一步是
> `send_request_frame` 的 typed 接线（那是新 API，要单独量）、共享 timeout
> 调度，以及 close reason —— 而不是再抄一份 UnixStream 循环。
