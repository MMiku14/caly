# Caly 开发日志 — 2026-08-31（第一百零九轮：Job Log Durability 切片 2 —— 引擎终态写入 + 启动恢复）

R108（切片 1）把 `JobLogStore` 存储 primitive 落进 `caly-storage`（纯类型 + Fs/Memory
双实现 + 契约裁判）。本轮做 `ADR-057 §5` **切片 2**：引擎在作业进入终态时把留存事件
窗口写进 D3 存储，daemon 启动恢复时把终态记录读回引擎 `state.jobs`。不做 daemon
恢复编排的 GC root / support bundle（切片 3）与真二进制 kill-9 e2e（切片 4）。无新
外部 crate、无 wire 帧形状变更、无依赖边变化。

---

## 1. 本轮靶子

### 1.1 引擎↔存储类型映射（新增 `crates/caly-engine/src/job_persistence.rs`）

照 `source_persistence.rs` 的分层：`caly-storage` 拥有落盘信封但**不向上依赖引擎**，
引擎在适配层拥有领域类型 ↔ 稳定串的映射。

- `record_from_job(&JobRecord, now)`：把引擎 typed `JobEvent` 渲染成 `kind<TAB>line`
  稳定串（line 复用 `bundle::render_job_event`，与 `jobs.events`/support bundle 同源），
  并把汇总计数（warning/log、last_stage/pct、failure_code/summary）反范式化到记录上。
  只接受**终态**（Completed/Failed/Cancelled/TimedOut），非终态报错拒绝。
- `job_from_record(&JobLogRecord)`：重建 typed 事件；`failed` 事件用稳定公共码
  （`ErrorCode` 闭集逐串匹配）+ 已脱敏 summary 重建 `ApiError`（category/retryable 由
  code 派生，**不落盘**）；未知 state / 未知 failure_code / 未知 event kind / 坏行形状
  一律按名拒绝。
- state 名集中在 `job_state_name`（与 `JobFollowView.state` 的
  `format!("{:?}",state).to_lowercase()` 同拼法，含 `timedout`）。

### 1.2 终态写入（`EngineHandle::mark_finished`）

`mark_finished` 是每个作业的终态提交点（worker 循环结束时调用）。在内存态更新后，
若作业已进终态：取 `storage_now()`（注入存储时钟，否则 execution-policy 基准，与 apply
持久化同源）→ `record_from_job` → `storage.put_job_log(.., D3)`。**写失败不吞**：一个
重启后无法恢复的终态作业正是这条记录要堵的缺口，所以返回 `Err`（与 snapshot/apply
持久化失败同性质）。

### 1.3 启动恢复（`EngineHandle::restore_job_logs` + daemon `startup_recovery`）

- `restore_job_logs()`：`list_job_logs`（newest-first）→ 逐条 `job_from_record`（坏记录
  是启动错误）→ **最旧先插入**，并把 `next_job_id` 推到超过最高恢复 id（新作业不与
  durable id 撞号）。
- daemon `startup_recovery` 在 snapshot/apply 扫描**之前**先 `restore_job_logs()`；
  `try_bootstrap`（durable 后端）下读不回 = on-disk 状态不可信 = 启动错误，与既有
  snapshot 恢复拒绝规则一致。

---

## 2. 遇到的问题与处置（留档 `ONBOARDING_NOTES §4.183`）

1. **给 `StorageBackend` 加 supertrait（切片 1）的空 impl `JobLogStore for X {}` 在切片
   2 变成真缺口**：切片 1 为 7 个手写 fake backend 补的是空 impl（继承 `Unsupported`
   默认臂），只为满足 trait 约束。切片 2 让 `mark_finished` 在完成路径上调
   `put_job_log`，于是所有「包一层 `InMemoryStorage`、只 instrument/打断某一个面」的
   fake（FlakyStorage / JournalSpy / BrokenJournal / NoContentWalk /
   UnreadableStore / InconsistentStore）在作业完成时拿到 `Unsupported` → 完成路径
   报错 → cutover/swap/durable-boot 一批既有裁判变红。**正确修法**：这些 fake 对其它
   所有 store 面都是**委托 `self.inner`**，空 JobLogStore 只是当时满足约束的占位；按
   委托族惯例把三法委托给 inner（唯一已委托的 UnverifiedRawStorage 切片 1 就这么做）。
   **规则**：给包装型 fake 加新 store 面时，默认委托 inner，除非该 fake 的**定义语义**
   就是「这个面不可用」（如 NoContentWalk 是为 content-tree 不可走而存在——但它仍委托
   job-log，因为它打断的是 content 面不是 job 面）。
2. **伪造记录的拒绝点在 store 重开而非 `restore_job_logs`**：切片 1 已钉死 FsStore
   open 启动扫描会 decode 所有 RECORD_KINDS，坏记录让 `FsStore::open` 直接失败。所以
   切片 2 的篡改裁判断言的是 **`FsStore::open` 失败**（引擎根本走不到 restore），而不是
   restore 报错——两条防线（open 扫描 + get/list decode）都在，但启动场景先撞 open。
3. **stage 行解析器初版误把 `[stage 70%] name` 拆成 `[stage] 70%] name`**：先用
   `strip_prefix("[stage ").or_else(strip_prefix("[stage]"))` 的回退序错了（`[stage 70%]`
   也含前缀 `[stage` 但不含 `[stage]`，回退没触发，却被错误地按无 pct 分支解析）。重写为
   先判 `[stage ` （带空格，取 `<pct>%] <name>`）再判 `[stage]`（无 pct）。

---

## 3. 裁判（测试）

- `crates/caly-engine/src/job_persistence.rs` 单测 5 条：Failed 终态作业 round-trip
  （state/outcome/failure_code/计数/last_stage、每个重建事件渲染行逐字等于存储行）、
  Completed 不带 failure_code、非终态（Running）拒绝持久化、未知 state / 未知
  failure_code（`NOT_A_REAL_CODE`）/ 未知 event kind（`teleport`）各按名拒绝。
- 新建 `crates/caly-engine/tests/job_log_durability.rs`（4 条，真引擎跑仿真盘
  FsStore，非 mock）：①Completed 作业 mark_finished 写 D3 → **同 backend 新开
  EngineHandle + `restore_job_logs` 后 jobs.list/follow 命中**、事件窗口非空不 reset、
  新分配 job_id 越过恢复 id；②恢复作业保持**终态**（重启不重放、不报 in-flight）；
  ③Failed 作业恢复后 `failure_code=PERMISSION` + 已脱敏 summary；④伪造未知字段的
  job-log 让 store 重开失败（点名集合+字段名）。
- 证伪（一次一变异，备份双还原 sha256 全等）：
  - M1：`mark_finished` 里把 `put_job_log(record,…)` 改成跳过写 → **4 条全红**（完成
    后存储里没有记录）；还原 sha256 `bbd404…7d82` 全等。
  - M2：`restore_job_logs` 里跳过 `guard.jobs.insert(...)`（仍计数、仍推 next_job_id）
    → **3 条红**（jobs.list/follow 空），篡改条仍绿（它在 open 即拒，与 insert 无关
    ——特异性好）；还原同 sha256 全等。

---

## 4. 数字与门禁

- census：873 → **882**（+9：job_persistence 单元 5、job_log_durability 4）；floor
  873 → **882**；§3.3 表由 `regenerate_test_census.py` 重建、CENTERLINE 断言数同步。
- clippy baseline 持平 **31**，新代码零 warning；无 `#[allow]`、无 `cargo fmt --all`
  （只 rustfmt 碰过的文件）；无新帧/依赖/ADR。
- 未碰 wire/IPC/CLI；caly.zip 基线未动。

---

## 5. 明确没做（后续切片，仍挂起）

- 切片 3：daemon 恢复编排把 GC root 扩到 job-log（被 snapshot/revision 引用为
  last-apply 的作业不误删）+ support bundle 收录终态作业历史 + 留存窗口有界回收。
- 切片 4：真二进制「写作业 → `kill -9` → 同 data-dir 重启 → `jobs.list`/
  `jobs.events`/resume 命中」e2e。
- 可选增量面：进行中作业 D1 滚动段（ADR-057 标为可选，未开工）。
- 其余既有 deferred：CLI `--role`+轻认证（P1）、真核长部署 resume e2e（P2）、
  ROADMAP §13#3 多流生产化（P3）、R104 流式 END 帧加 failure_code（须 ADR）。
