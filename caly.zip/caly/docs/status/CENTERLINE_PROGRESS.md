# Caly Centerline Progress

本文件专门跟踪 Caly 最重要的一条中心主链：

```text
Profile / Source / Override
  -> Caly IR
  -> ResolvedProfile
  -> Capability Validation
  -> CoreAdapter
  -> NativeValidation
  -> ApplyPlanning
  -> EffectPlan
  -> Effect Executor          <-- 本版接上
  -> Snapshot / Journal / Revision
  -> Recovery / Rollback       <-- 本版接上
  -> Daemon Command Path / Local+Remote Facade
```

> 本版依据 2026-08-30 的实测结果重写。上一版把“journal 级接线已完成”记成“尚未实接”，
> 同时把“effect 执行缺失”说得过轻；第七十五轮把 source caller 边界与 durable inspection projection 接上，第七十六轮把 v0 wire 请求形状单源化（`caly-ipc::wire_request` 一张编码表 + CLI 消费 + 真 daemon 门扫描裁判）——准确粒度见 §3 与 §5。
> 本文第 4 节之后保留各轮的历史证据；其中旧轮次里的“当时未做”不等于当前状态，当前快照以 §2/§3/§5/§7 为准。
> 交叉引用：`docs/history/ONBOARDING_NOTES.md §2.2 / §2.3`。

---

## 1. 为什么要单独跟踪这条线

因为 Caly 最容易掉入的工程陷阱是：

- UI 和 daemon 看起来很忙
- IPC、watch、loopback、scenario 都很多
- 但真正的中心主链还没有接起来

所以需要一份专门文档回答：

> 中心主链到底接到哪一步了？

---

## 2. 当前已经接上的部分

- `caly-domain`
  - `Profile / Override / SelectionMemory`
  - group selection / tun builder helpers
- `caly-ir`
  - `CalyIr / ResolvedProfile / CompiledArtifact`（native format、entrypoint、media type、stable bytes、annotations）
- `caly-pipeline`
  - `parse_source(...)` 真实 decode/normalize UTF-8 URI 或 base64/base64url envelope，支持当前已登记的 source schemes，并产出 bounded diagnostics 与 parser provenance
  - `merge_profile(...)` 真实消费 attached sources / normalized source estimates / selections / override selectors，并物化图结构
  - `resolve_ir(...)` 执行 selection memory replay、default recovery、引用完整性、deterministic manifest / semantic digest / revision
  - `validate_semantic(...)` / `validate_capabilities(...)` 由 registry + coverage matrix 求值
- `caly-core` / `caly-mihomo` / `caly-singbox`
  - 产出真实 native artifact bytes
  - 产出 `ApplyPlan`（`Noop / ApiPatch / HotReload / Restart / RebuildAndRestart`）与 typed `EffectPlan`（steps + compensations）
  - `config.identity` 注解现在等于 spawn 时交给 core 的 config digest，使 identity 探针可判定
- `caly-engine`
  - `HttpSourceUpdateWorker` 通过显式 endpoint registry + `Http` Port 获取 source，限制 body，校验 raw CAS，并把 normalized source cache 接入 apply planning；304 只在 raw anchor 可验证时复用；source-index durable record 负责 endpoint/validators/raw/normalized/provenance/diagnostics 的 D3 发布与重启恢复；同一注入 clock 在 HTTP 前后、parse/CAS/D3 commit 前做 caller cancellation/deadline 边界检查，且 blocking adapter 返回后还有 post-call probe
  - `apply::plan_apply_*` 现在同时输出 typed `effect_plan` 与展示用字符串投影
  - **`executor::execute_effect_plan`**：按 typed `EffectStep` 分派，含阶段单调性、verify-before-commit、resume 边界、补偿回滚、崩溃注入、注入式时钟
  - `recovery::{begin_apply_persistence, advance_apply_phase, finalize_apply_persistence, mark_apply_reverted, mark_apply_recovery_failed, scan_recovery_state}`
  - `worker::execute_profile_apply` 走执行器；`execute_profile_rollback` 真执行补偿并结算 journal
  - `source_inspection` 从 durable record 投影 endpoint/validators/raw anchors/normalized counts/diagnostics/provenance；统一 `Redactor` 保护 locator、label、validator 与 provenance，daemon `handle_request` 已有真实 fixture 裁判
- `caly-storage`
  - `execution.rs`：`ApplyJournalRecord` / `SnapshotCandidate` / `RecoveryDecision` 投影
  - `memory.rs`：`InMemoryStorage` 实现五个 store trait，被上面真实读写
- `caly-daemon`
  - query：`ProfileOp::Plan`、`DiagnosticsOp::ExplainPipeline`
  - command：`ProfileOp::Apply / Rollback` → engine → 执行 → snapshot
  - 启动 `recovery_scan()` + `apply_recovery_snapshot()`
  - `calyd` 组合根注入 `FsStore`、`StdClock`、`StdHttp` 与显式 `--source-endpoint id=locator`；默认 effect runtime 仍为 simulated
  - `SourceOp::Inspect` 经 query/facade 读取 durable source inspection；当前 parser/source record 有明确大小上限，未来若改变上限再单列分页/stream 决策
- `caly-app`
  - local/remote facade 与 parity 覆盖 `profile.plan` / `profile.apply` / `diagnostics.explain_pipeline` / runtime 与 system 视图

---

## 3. “接上”的两个粒度，必须分开说

| 粒度 | 含义 | 状态 |
|---|---|---|
| Journal 级 | 事务游标、phase、LKG 标记、pending 扫描能落库 | 已具备（`caly-engine::recovery` + `caly-storage`） |
| Effect 执行级 | 逐步解释 `EffectStep`，按阶段门禁放行/阻断，失败后真补偿 | 已具备（`caly-engine::executor`）；默认目标是 `SimulatedRuntime`，`calyd --effect-runtime real` 可显式组合 `StdEffectRuntime` 并经过 mihomo/sing-box 真核裁判；跨进程 recovery/adoption 仍未宣称 |

第三级仍未完全闭合（下表的真实 effect slice 已存在，但跨进程 recovery/adoption 与 Platform 面未完成；`calyd` 的显式 real 选择和 preflight 已落地）：

| 粒度 | 含义 | 状态 |
|---|---|---|
| 真副作用级 | fs / proc / net / core runtime API 落地，崩溃后由下一次启动接管 | `Partial`：真实 core effect adapter 的显式注入、spawn/probe/stop/rollback slice 已有；`calyd` real 模式显式组合与 preflight 已有，但跨进程 recovery/adoption、Platform/TUN 与完整 OS 网络副作用未完成 |

因此现在的准确说法是：

> 中心主链已能在**确定性仿真后端**上端到端执行并恢复；真实 mihomo/sing-box effect slice 可在显式组合根注入下进行真核验证，但默认生产运行时、Platform/TUN 与完整 OS 网络副作用仍未完成。

---

## 4. 本轮新增的工程验证结论

```bash
./scripts/check.sh
# `./scripts/check.sh` 最终结果：866 tests / floor 866 / clippy baseline 31 / fmt 0 lines；all gates passed（第九十四轮回包 request_id 关联校验；第九十三轮 hello 角色 fail-closed 解析；第九十二轮线端请求角色取自 hello 协商；第九十一轮 follow 流静默期限 + recv 探活不借用读预算；第九十轮 daemon 服务端写半对称期限；第八十六轮生命周期拒收消费 §4 默认；第八十五轮生产 CLI 入站帧帽走共享 codec；第八十四轮 RetryPolicy 型 + §4↔默认双向裁判；第八十三轮 `ErrorCode::category()` 默认权威 + §4↔默认双向裁判；第八十二轮 §4↔§5.x 使用规则覆盖裁判；第八十一轮 EXIT_CODES §2 名字列 + 双胎名一致裁判；第八十轮 docs/guides/ERRORS.md §4/§4.1 名称闭包裁判；第七十九轮 EXIT_CODES 表↔代码对照裁判；第七十八轮 doctor runtime 投影可达化 + 其 wire 承载与开关；第七十七轮 wire 形状对称闭包 + 解码单源 + 流双形状收编；第七十六轮 v0 wire 请求形状单源 + 扫描裁判 + CLI 迁移；第七十五轮 source-index 锚格式校验缺口补面 + 门禁发现的 R72 cancel-judge 竞态修复 `§4.157` 后连跑两次一致）
python3 scripts/regenerate_test_census.py --check
# files=105 total=866 rows=105
```

### 第七十六轮（上一轮快照）：v0 wire 请求形状单源

这一轮的靶子是**形状漂移**：v0 的 wire 请求长什么样，此前同时写在 CLI 的手拼 JSON、daemon 门的字段表与文档里。falsify 先证明这是真缺口——两个各一行的变异：把 op 名写成 `"profiles.applyx"`（M1），把 apply 的 `"profile_id"` 写成 `"profile"`（M2），编译器与既有测试都不红；只有运行时真 daemon 门会以 UNSUPPORTED / USAGE 拒收。形状错误编译不出来，只能靠“真门”当裁判。

落点是 `crates/caly-ipc/src/wire_ops.rs`：一个 `WireRequest { name, extras }`、13 个 operation 码一张表、未知 op 按名拒绝（不是静默映射）、bool 以 `"true"`/`"false"` 承载。消费方 `crates/caly-cli/src/bin/caly.rs` 删掉自家 extras 拼装表：子命令先构 typed `Operation`，再 `wire_request` 编码，`idempotency_key` 只在 apply/rollback/gc 且非空时追加；ask/print 以 `wire.name` 分发；数字参数经 `wire_number`/`wire_required_number` 在客户端报 usage，而不是把旧 daemon 门校验换个位置。

裁判是扫门判官 `every_request_op_encoded_by_the_single_source_passes_the_daemons_door`：13 个 `wire_request` 输出逐一送进真 calyd 门（KIND_REQUEST + request_payload，先排干异步流帧），断言拒绝原因不是 USAGE/UNSUPPORTED 且 request_id 回声——“编码表与 daemon 门之间没有缝隙”从此成为可回归事实。calyd_wire 35 条、cli_e2e 22 条；`scripts/archive/falsify_round76.py` 双变异均被咬（`all mutations behaved as predicted: True`）。


### 第八十七轮：共享 BindSpec/WireIo + 生产 UDS + handshake-only ClientLoop（当前快照）

`calyd`/`caly` 此前各握一份 TCP-only 循环。UDS 若再抄一份就是第二个协议。
本轮把 bind/connect/pump 收成 `BindSpec` / `WireIo` / `FramePump`，hello 收成
`drive_client_hello`（dialect 字节、validate 先于 observe、records/json→Json、
CLI 角色 Admin）。TCP port-file 仍裸 u16；UDS 写 `unix:<path>`。UDS probe 恒
Indeterminate（无 std peek）。chmod 0o600 是 v0 默认，不是 RFC-0010 §14。

裁判：ipc endpoint/duplex/handshake_drive + 集成 endpoint；calyd_wire UDS
hello/status 与 UDS port-file；caly_cli_e2e UDS status。证伪：
`scripts/archive/falsify_round87.py` 2 变异（M1 摘 unix: 前缀 / M2 跳过 validate）。
明确没做：`cargo fmt --all`、改 502、`send_request_frame`、共享 timeout scheduler。

### 第八十六轮（上一轮快照）：生命周期拒收消费 §4 默认

`app.rs` 生命周期拒收此前是 CONFLICT + Platform + retryable=true，与 `docs/guides/ERRORS.md` §4/§5.2/§7.2
相左。本轮裁决：overlay 未决 recovery 是资源冲突，不是平台故障也不是 daemon 不可达；操作员
发另一条命令，不是重放。落点：`ApiError::for_code` 消费 `category()`/`retry_policy()`；生命周期
与 CAS-miss 走它。裁判：error_doc 14 码 + durable_boot Recovering/Failed 钉 Config 且不可重试。
证伪：`scripts/archive/falsify_round86.py` 2 变异全咬（0.4s / 1.7s）。

### 第八十五轮（上一轮快照）：生产 CLI 入站帧帽走共享 codec

生产 `caly` 的 `Session::recv` 此前手写 `read_exact` 头 + `vec![0; len]` 再读体，
注释声称共享 codec 做入站 cap 而生产路径从未调用 `wire_read_frame`（daemon 侧
`calyd` 已走 codec）。超 cap 声明会分配并卡在 3s 读超时，exit 11 把协议违规说成超时。

落点：`WireFrameError { summary, timed_out }` + `message()` / `from_io()`；CLI `recv`
委托 codec，`timed_out` 映射回 round-44 文案以保 `docs/guides/EXIT_CODES.md` 11；删死代码
`is_timeout`。裁判：wire 单元 timeout 命名 + e2e 假 daemon 只写 5 字节超 cap 头
（CLI <2s、exit 13、文案点名 inbound cap）。证伪：`scripts/archive/falsify_round85.py` 2 变异全咬
（M1 摘入站 cap 0.5s / M2 一切 wire 错→timeout 文案 1.4s）。

### 第八十四轮（上一轮快照）：RetryPolicy 型 + §4↔默认双向裁判

§8.18 残余①（Retryable 4 值 vs bool，需 RetryPolicy 型才可对照）本轮关账。`docs/guides/ERRORS.md §4`
的 Retryable 列（否/视场景/可能/是）是每码的**重试性质**，比 `ApiError::retryable` 的
bool 丰富——早先量选记过：bool 无法表达「可能/视场景」，所以该列一直无任何裁判。

落点：`caly-api` 加 `RetryPolicy`（Never/Maybe/Depends/Always 四值，= 文档四词
的一一映射；映射本身住在裁判里——词永远是文档的，不是代码的）+ `ErrorCode::
retry_policy()`（14 臂 = §4 默认；`Cancelled`/`Internal` 代码侧裁定 Never，注释注明）
+ 裁判 `error_doc.rs` +1（§4 (名→词) map == (名→`retry_policy()` 词) map，双向）。
零行为变更——`ApiError::retryable` 的 bool 保持实例级 wire 字段不动。

证伪：`scripts/archive/falsify_round84.py` 2 变异全咬——M1 文档 §4 `TIMEOUT` 是→否；
M2 代码 `retry_policy()` 的 Timeout 臂 Always→Never（各 0.1s/0.4s）。

### 第八十三轮（上一轮快照）：`ErrorCode::category()` 默认权威 + §4↔默认双向裁判

§8.15 残余①（`(code→category)` 逐点权威不存在、三处与 §4 相左未裁决）本轮裁决。量选
先读文档：`docs/guides/ERRORS.md §5.1` **自己钉了** `CONFIG_INVALID` + `User` 的实例用例
（io_budget）——分类在本文档语义里是**逐例**的，§4 的 Category 列是**每个码的规范
默认类**，不是强制归类。据此把全部 11 处 User/分类偏差点逐一核查：9 处是文档先例内的
caller-mistake 类（misrouted support-bundle、bad_page_request、no-such-job、
read_bundle_refusal、bad_gc_request、idempotency 拒收、handshake/session 拒绝……），
1 处恰好等于 §4 默认（CAS-miss = CONFLICT/Config，注释引用 §5.2），1 处真实待议：
`app.rs` 生命周期拒收 = CONFLICT + **Platform** + retryable（既非 §4 默认也非
caller-mistake，登记 §8.18 待议项、本轮不动）。

落点：`ErrorCode::category()`（14 臂，= §4 默认；Cancelled→User / Internal→Internal
为代码侧裁定并注明）+ `ErrorCategory::as_str()`（7 臂）+ 裁判 `error_doc.rs` +1
（§4 (名→类) map == (名→category().as_str()) map，双向）。零行为变更——已有的
偏差是有据的实例归类，不是 bug。

证伪：`scripts/archive/falsify_round83.py` 2 变异全咬——M1 文档 §4 `PERMISSION`
Platform→User；M2 代码 `category()` 的 Timeout 臂 Io→User（各 0.1s/0.4s）。

### 第八十二轮（上一轮快照）：§4↔§5.x 使用规则覆盖裁判

`docs/guides/ERRORS.md §4` 稳定码集合与 `§5.x` 使用规则小节此前无覆盖关系裁判：§4 里删掉一个码而
§5.x 还留着它的规则、给 §5.x 新开一个小节写保留码（`CANCELLED`）的使用规则、或
§5.x 标题把码名拼错——全部静默通过。而 §5 的规则正是实现被逐条引用的判据
（`error_identity` 引用 §5.2 的 CAS-miss 归类），规则集与码集脱钩 = 实现无从对照。

落点：`crates/caly-api/tests/error_doc.rs` +1 条（`the_usage_rules_cover_exactly_
the_stable_codes`）：§5 必有且仅有 10 个小节（5.1..=5.10 唯一）、每个 §5 标题只点名
§4 稳定码（保留码/未入档码不得有规则小节）、每个 §4 稳定码恰好出现在一个 §5
小节（不多不少）。

证伪：`scripts/archive/falsify_round82.py` 2 变异全咬——M1 §5.7 标题码名 `TIMEOUT`→
`TIMEOUTX`（TIMEOUT 无规则 + TIMEOUTX 非稳定码，0.0s）；M2 后门转正：新增
`### 5.11 CANCELLED` 规则小节（10 节断言 + CANCELLED 非 §4 码，0.1s）。

### 第八十一轮（上一轮快照）：EXIT_CODES §2 名字列 + 双胎名一致裁判

R79 的残余之一是 `docs/guides/EXIT_CODES.md §2` 表 1（0/1/2）「只做数字存在性对照（无名字列）」：
§2 只有数字与含义，没有可对照的码名，0=成功/1=一般失败/2=用法错误 的**名字**是枚举
里 `Success`/`GeneralFailure`/`Usage` 的事，文档对不上、代码改了名也没人知道。同时
新暴露一个跨 crate 风险：`ExitCode`（caly-cli）与 `ErrorCode`（caly-api）各有一套
名字，3..=16 的任务是同一字符串（`from_error_code`），但两套 `as_str` 各写各的，
没有裁判把它们钉在一起。

落点（R81）：
- `ExitCode::as_str()`（17 臂，`ExitCode` 侧权威名字；3..=16 与 `ErrorCode::as_str`
  逐字相同，由裁判钉住）；
- `docs/guides/EXIT_CODES.md §2` 表加「名称」列（`SUCCESS`/`GENERAL_FAILURE`/`USAGE`），文档
  与代码从此可对照；
- 裁判 `exit_code_table.rs` +1：① §2 (数字→名称) map == 枚举 (as_i32→as_str)；②
  双胎名一致：对全部 14 个 ErrorCode，`ExitCode::as_str(from_error_code(ec)) ==
  ec.as_str()`；
- R79 裁判的解析器**收窄到 §3 区段**（§2 原来是 2 格被自然跳过，加名字列后变 3 格
  会被旧解析器误收——区段化是 R81 的必要配套，R79 的 M1/M2 变异锚点不受影响，
  旧证伪脚本重跑仍双咬）。

证伪：`scripts/archive/falsify_round81.py` 3 变异全咬——M1 文档 §2 `SUCCESS`→`SUCCEED`；
M2 代码 `ExitCode::Usage`→`USAGE_`；M3 代码 `ErrorCode::Timeout`→`TIMEOUT_`
（R81 双胎断言红 + R80 闭包裁判红，跨轮双裁判协同）。0.1-2.3s，restore 干净。

### 第八十轮（上一轮快照）：docs/guides/ERRORS.md §4/§4.1 名称闭包裁判

`docs/guides/ERRORS.md §4` 声明 v1 公共稳定错误码最小集合（12 个码 × Category × Retryable），
`§4.1` 声明 6 个保留码位；`caly_api::ErrorCode`（14 个变体）是实现。但文档门禁只查
表格**形状**，没有任何检查对照两边**名称**：在 enum 里加一个未入档的码、在 §4 里把
`CONFIG_INVALID` 拼错、把 `RATE_LIMITED` 从保留位偷偷转正——所有既有门禁照常全绿。

落点：`crates/caly-api/tests/error_doc.rs`（纯文档读取裁判，不 spawn 进程）——闭包是
**方向性**的：① 已实现的码 ⊆ §4∪§4.1（enum 里不许有无名码）；② §4 稳定码 ⊆ 已实现
（文档里的码不许不存在）；③ 保留↔实现的「中点」被钉死：恰好 `CANCELLED`/`INTERNAL`
两个保留码已实现（其余四个保留位实现 = 必须先转正/改文），§4 与 §4.1 不许重叠；
④ §4 表行数 12、§4.1 六项；§4 每行 Category 必须落在 §3 的 7 分类表内、Retryable
必须落在 {否,视场景,可能,是} 内（文档内部自洽，防分类名/取值漂移）。

量选中顺带确认的边界（不发明权威，登记为残余）：代码侧**没有**按码的分类/可重试
权威——(category, retryable) 由每个 `ApiError::new` 构造点逐例裁定，且已发现至少三处
与 §4 相左（`map_handshake_error`/`map_session_loop_error` 把 `ConfigInvalid` 归
User、`error_identity` 钉住未知 job 的 follow=CONFLICT+User）。为此 Round 80 只做
「两边都已存在」的名称闭包，Category/Retryable 列留给引入权威的轮次（§8.15 残余）。

证伪：`scripts/archive/falsify_round80.py` 4 变异全咬——M1 文档侧把 §4 的 `CONFIG_INVALID`
拼成 `CONFIG_INVALIDX`；M2 给 §4 加 `RATE_LIMITED` 行（保留位未除名）；M3 §3 分类名
`Config`→`Configs`；M4 代码侧 `as_str` 把 `Timeout` 输出为 `TIMEOUT_`（R80 闭包与
R79 退出码裁判**双红**）。各 0.1-4.0s，restore 后内容级干净且 mtime 单调（R79.5.1
教训内建）。首版裁判全等写法被首跑当场纠正为方向性闭包（保留码按设计未实现）。

### 第七十九轮（上一轮快照）：EXIT_CODES 表↔代码对照裁判

`docs/guides/EXIT_CODES.md` 是 shell 脚本与 CI 依赖的契约，`caly_cli::ExitCode`（0-16）与
`caly_api::ErrorCode`（14 个变体，`as_str`）是其实现——但文档门禁只查表格**形状**
（列数/分隔行/编号），**没有任何检查核对表格的内容与代码**：把 `CURSOR_STALE` 改名、
把 `Timeout=11` 改成 21，所有既有门禁照常全绿。表↔代码的对齐此前只是「碰巧一致」，
而运维脚本是按文档写重试策略的——这正是「文档声称 X、验证 X 用命令」循环在退出码
上的缺口。

落点：`crates/caly-cli/tests/exit_code_table.rs`（纯文档读取裁判，不 spawn 进程）——
用该文件的**最小解析器**读 `docs/guides/EXIT_CODES.md` 的 ErrorCode 表（`| N | NAME | 说明 |`，
名字取第一个反引号 token，`CANCELLED` / interrupted 的后缀不算名字），两个断言：
① 文档 (名字→数字) map == 代码 `from_error_code` 的 (as_str→数字) map（双向双射）；
② `ExitCode` 枚举值集合 == 0..=16 且无重复无遗漏。任何一侧改名/改号/跳号都是测试失败。

证伪：`scripts/archive/falsify_round79.py` 双变异全咬——M1 文档侧把 `CURSOR_STALE` 拼成
`CURSOR_STALEX`（表↔枚举对照红）；M2 代码侧把 `Timeout = 11` 改成 `Timeout = 21`
（范围完整性与映射双红，`from_error_code` 的 21 对不上文档的 11）。两侧都只有一行
改动，都会被「两个实现同意」的裁判当场抓住。文档侧从此有了与代码同级的可核对性：
契约漂移不再是散文的事。

终跑（第九次全量，95.3s）：三连排雷后 **all gates passed**——① falsify
restore 的 `copy2` 保留原 mtime，M2 恢复后源码比含 `21` 的 rlib 旧，cargo 不重编、
`21` 泄漏进裁判（R78 的 stale-fingerprint 陷阱被 restore 重新引爆；修法：
`restore_one` 恢复后 `os.utime(path, None)`，现场 utime 排雷后 2/2 绿）；
② 新测试 `workspace_root()` 返回 `PathBuf` 触发 disallowed_types，clippy 31→32
（改 `&'static Path` + `display()` 回 31）；③ `real_apply` 502 网络瞬态一次
（§4.155 族，未改码重跑全绿）。详见 DEVLOG §23.5。

### 第七十八轮（上一轮快照）：doctor runtime 投影可达化

量选撞见一个「实现了但接口不可达」的形态：daemon 的 `query/diagnostics.rs` 早有
`if request.include_runtime` 分支（summary 追加 `runtime active_profile/active_snapshot/
engine_lifecycle` 三字段），五处 harness 测试（diagnostic_bounds、durable_boot、
gc_collect、idempotency_and_roles、redaction_boundary）都以 `include_runtime: true`
断言过它——但 v0 wire 的形状里**没有这个记录**：`wire_ops` 的 doctor 臂是 `plain`
（不编码）、解码器固定 `false`、CLI 的 `caly doctor` 硬编码 `false`（同 crate 的库
路径 `caly-cli/src/driver.rs` 却用 `true`）——「医生声称可以查看的运行时状态，从任何
wire 客户端都够不到」。

落点是 v0 wire 的加宽（与 bool 族同款语义）：`diagnostics.doctor` 增加可选记录
`include_runtime`（`"true"` 生效、缺席=false）；`wire_ops` 编码/解码同步（encode 恒写
`"true"`/`"false"`、decode 按名读取）、`caly doctor --runtime` 开关（默认形状不变，
向后兼容）、真 daemon 门裁判 `a_doctor_request_can_opt_into_the_runtime_projection`
（先发默认形状断言 summary **不**加宽，再发 opt-in 断言 summary 真的命名 runtime
快照——两个愿望一次断言）。

裁判与证伪：wire_ops 的 doctor opt-in round-trip（编码写出记录、解码读回同一 typed
请求）；`scripts/archive/falsify_round78.py` 双变异全咬——M1 解码臂丢掉记录→round-trip 红 +
**真 daemon 门红**（daemon 经 decode 解码，手写 opt-in payload 的 summary 不再加宽，
这一红同时证明「daemon 确实经单源解码」）；M2 编码臂退回 plain→opt-in round-trip 红。
「opt-in 从 CLI 到 daemon 的语义链」从此在两个方向上都被钉住。

---

### 第七十七轮（上一轮快照）：wire 形状对称闭包

第七十六轮只封了编码侧，量选立刻露出另一半：`calyd.rs` 的解码 match 表（213 行）仍是
手写的第二份字段知识；`jobs.follow-stream` 的 open/resume 两形状在 `caly.rs` 的
`follow_stream` 里仍在手拼（第七十六轮的「单源」没有覆盖它）；且 daemon 的
UNSUPPORTED 文案列举 12 个 op，**漏掉了自己支持的 `jobs.follow-stream`**。三处都实证过
才动手：编码器与解码器**互为镜像**是「单源」的完整主张，此前没有任何裁判能证明或证伪。

落点是 `crates/caly-ipc/src/wire_ops.rs`：`decode_request`（12 个无状态 op 的
records→typed `Operation`，镜像编码表）、`wire_stream_request`/`decode_stream_request`
（follow-stream 的 open/resume 双形状，此前 CLI 手拼、daemon 手读）、`WIRE_OPERATION_NAMES`
（13 名列表——daemon 的 UNSUPPORTED 文案改由它生成，顺带补回漏写的 follow-stream）。
`calyd.rs` 的 213 行手写解码表删除，调用 decode 后仅保留门内责任：会话状态
（`streams` 表查询）、错误→refusal 文案映射（逐字保持，35 条 e2e 钉子按 contains 钉住措辞）、
以及 NOT_FOUND/UNSUPPORTED/USAGE 的分类。`caly.rs` 的 follow_stream 手拼 extras 删除。

裁判是**对称性本身**：`wire_ops` 新增 5 条（每个编码 op 解码回自身、13 名无一被解码器
判为 Unknown、拒绝按名报字段、流两形状各自 round-trip、encode 名集合==文档名单集合）；
`calyd_wire` 35 条与 cli_e2e 22 条证明迁移后行为零变化（那条手写解码表本来就没有
「自己的语义」——它只有 wire 形状，搬进单源后钉子全绿）。`scripts/archive/falsify_round77.py`
双变异全咬：M1 把编码侧 resume 的记录名 typo（`stream_id`→`stream_id_x`）——round-trip
裁判红；M2 把解码侧 apply 的记录名 typo（`profile_id`→`profile`）——round-trip 红**且**
真 daemon 门红（daemon 现在经 decode 解码）。wire 形状自此只剩一张表 + 一个镜像裁判：
任何一侧的改名都是测试失败，而不是运行时才知道的漂移。

---

### 第七十五轮（上一轮快照）：effect 执行/恢复与 source 边界的验证证据

关键点是**断言内容**而不只是数量：

- `crates/caly-engine/tests/apply_execution_gate.rs`
  - 适配器的真实计划必须通过阶段门禁，且 `Probe` 必须早于 `MarkSnapshot`
  - **在每个 `EffectStep` 之后注入崩溃**，断言 last-known-good 不被替换、事务不留在 pending/success
  - prepare 段崩溃 ⇒ journal `Abandoned` 且不得声称 cutover；cutover 段崩溃 ⇒ 必须 `Reverted`/`RecoveryFailed`
  - 重复规划逐字段相等（typed plan、digest、capability 摘要）
- `crates/caly-daemon/tests/apply_command_path.rs`
  - envelope → command → job → 执行 → snapshot，且 daemon runtime 视图同步
  - Viewer 越权必须在入队前被拒
- `crates/caly-io-sim/tests/*`、`crates/caly-cap/tests/registry_drift.rs`、`crates/caly-arch-test/tests/*`

这些断言在编写过程中暴露了 3 个真实缺陷（identity 探针永不可通过、`crash_after_effect_step` label 不可达、
虚拟时钟可回退），均已修复并固化。详见 `docs/history/ONBOARDING_NOTES.md §4`。

### 历史轮次证据（以下数字与“当时未做”只描述当时，不覆盖当前快照）

第三十轮补充：`OVERLOAD_AND_RETRY_MODEL §5.1` 的 Query 那一格，以及 `ADR-036 §6bis-quinque` 里挂了七轮的
「查询侧不接限制」，本轮判完并落地。靶子是先量出来的：`caly-ipc` 的 `MAX_FRAME_SIZE_BYTES` 只检查**入站**帧
（`validate_frame_header`），而 `encode_raw_json` 对尺寸什么都肯造 —— 于是一次完全合法的
`diagnostics.recovery-status`，只要 store 里有几百条未决事务，就能造出一个对端拒绝接收的帧。运维在部署坏掉的
那一刻失去诊断，收到的还是传输错误而不是 API 错误。`RFC-0002 §11.4` 那句「large objects MUST NOT be returned
as an oversized inline IPC frame」在 daemon 这一侧一直没有承载体。

落点是 `caly-daemon/src/paging.rs`（它本来就是"一个回答能带多少"这件事的住处：一个事实一个家，`§4.81`）：
128 行 / 单行 4 KiB / 整层 512 KiB，其中 1 KiB 是留给截断说明自己的**预留** —— 一句"我截断了"如果自己就能把
预算顶爆，那个界就不叫界。三条规则各有一条断言：被截的那一层里必须有那句说明（不许塞进 notes 绕圈子）、
未截断的答案不许携带它（占位符会让标志变成噪音）、`decision_count` 与 summary 里的总数**不许随答案收缩**
（M8 就是让它收缩，红的是"总数"那条断言）。上界按**来源**施加而不是按组装好的答案施加，这样洪水挤不掉 daemon
自己要说的话（recovery 计数、idempotency 窗口、gc 计划与上一轮周期）—— 那三句才是运维打开 doctor 的原因。

两处自我修正值得留着。第一处：第一版断言写的是 `decisions.len() == 128`，实际是 127 —— 在这个夹具里先咬住的
是**字节**预算而不是行数预算；把"哪个界生效"写进断言等于把实现细节当性质，改成守恒律
`carried + omitted == total` 之后两个界都对（`§4.126`）。第二处：`&& !truncated` 那个守卫在 daemon 层
**造不出可达用例**（audit 会把 info 行聚合成几条），于是规则被命名成 `paging::may_claim_clean` 单独测四种
组合，而不是留在调用点当一个没有裁判的 `&&`（`§4.125`）。本轮没有新增门禁：文本门禁只能检查"某个名字出现过"，
而这一轮的性质是"答案真的装得下"，只能在量答案的地方测 —— 说不出一条会咬的门禁，就写下来，不造装饰。

`cargo test --workspace` 485 → 501；11 条证伪变异全咬住（M9 的第一版不咬，把规则命名之后才咬住）。

第二十九轮补充：`ADR-036 §1` 表里最后一行「`io_budget` 限制单次 IO —— 没人读」终于有了读者，而读者是端口
自己。`RFC-0006 §5.3` 的原文早就写明三件事：受限的是**单次操作**、清单里有**可读取总字节数**、用尽时
**Port MUST** 返回容量类 `IoFault` —— 主语一直是端口，不是引擎。于是 `caly_io::budget` 提供
`byte_ceiling(ctx, requested)`（读侧：取调用自带 cap 与预算里更紧的一条，并记住是哪条在管）与
`check_payload(ctx, resource, bytes)`（写侧：**任何字节落地之前**拒），`StdFs` 与 `SimFs` 调同一份实现，
`fs_byte_budget_violations` 在两个后端上跑同一组断言（含「被拒之后 `stat` 说没有这个文件」——
`RFC-0007 §6.2` 要的就是别留下半份东西）。`Http` 侧同样按 `byte_ceiling` 收窄 body 上限；当前 `StdHttp` 与 `SimHttp` 均有实现，并共享 caller deadline anchoring/check helper。

三个可以悄悄做错的岔口，各有一条断言：**精确等于上限是放行**（`<=`，差一格就变成"因为你正好用了我给的额度
而拒绝你"）；**宽松的那条不得放大**（预算比 cap 大时仍按 cap，否则设预算等于提额）；**未设预算什么都不拒**
（`None` 既不是 0，也不是"无限到不必检查"）。公开面沿用前两轮的形状：端口 `CapacityExceeded` ⇒ store 保住 kind ⇒
引擎认成 `RefusalKind::PayloadTooBig` ⇒ `CONFIG_INVALID` + `User` + `retryable=false`，与 `BudgetExhausted`
分开是因为**旋钮不同**；`remediation` 本轮也进了同一张表。`request_map.rs` 那条测试的断言仍然成立
（`max_bytes.is_none()`），但它的**解释**已经从真变假 —— 改的是措辞，`§4.120` 记的就是这类"没人喊的过期"。

诚实的边界：命令的 `max_bytes` **仍到不了端口** —— 它止于 `RunLimits`，端口看到的那份 `IoContext` 属于
`FsStore`、跨调用方共享，把它送进去卡在同一条 `RFC-0007` 冻结的签名上。本轮做的是「字段有人执行、执行处只有
一处、两个后端跑同一组断言」，不是「调用方的预算已贯通 durable 路径」。

第二十八轮补充：`ADR-036 §2.6` 那句"以免新后端一挂起就报内部错误"落地了 —— 而它的起点是一个 3 行函数：
`FsStore` 里的 `fn suspension(...) { StorageError::new(StorageErrorKind::Internal, message) }`。端口层明明交出了
`Busy` + `retryable` + "用了多少 poll"，到 store 这一层被改写成"存储坏了"。代价不在文案里而在**上一层**：
`StoreRefusal::from_storage_error`（第二十七轮加的）只认 `Busy`，于是"盘忙"与"记录损坏"在公开错误、重试建议、
`doctor` 的账本上全都被压成同一件事。

本轮把这一层的形状改成它本该有的样子：`caly-storage/src/port_drive.rs` 用 `caly_io::drive`（生产里唯一的 poll 循环）
有界轮询端口，超预算把驱动器的 `Busy` 经**同一张** `from_iofault` 表报上去；`fs_store.rs` 的 8 个驱动点与
`schema.rs` 的 4 个全走它，`suspension()` 删除。同时给仿真端口加了 `stall(label, polls)`：**只有"永不就绪"的
仿真器不足以验证一个预算** —— 那种情形下"驱动器放弃太早"和"端口卡死了"是同一个读数，把预算调成 1 也全绿；
有了可数的挂起，边界才能从两侧量（`budget-1` 通过、`budget` 拒绝）。

三件刻意没做的事：不在这一层判期限（没有时钟、也没有值得等的事件；等第 4 步的阻塞池给它一个可等的东西）；
不做 per-store 的可配预算（`open` 里的迁移路径够不着，够不着的旋钮就是下一处含混）；不新增 `Timeout` 之类的
新类型 —— 没有时钟说时间到过，就不能说时间到了（`§4.86`）。11 条证伪变异全咬住（主线 9 + 收尾补的相邻性检查 2），其中两条的裁判是新加的门禁
（`crates/caly-storage/src/**` 不许出现 `block_on_ready(`，豁免 `audit.rs` 并写明理由，另附一条"扫到文件数 ≥ 8"的
反空转断言）—— 有一条变异改的是 `schema.rs`，行为完全相同、测试全绿，**只有门禁能抓**，这就是它值得存在的理由。

第二十七轮补充：`APPLY_EXECUTION_CENTERLINE §6.1` Phase B 的 pending guard 接进了生产路径。本轮的起点不是
一个想法而是一次测量：给 `EngineHandle::put_apply_journal` 临时加一行打印、跑一次真实 apply，store 在执行期间
只收到**一条** journal 写，内容是 `phase=Finalize cursor=8 net=true cutover=true state=Committed` —— 也就是
"cutover 发生过"这件事在 cutover **结束之后**才落盘。进程死在中间，重启读到的是 `pending/prepare`，
`STORAGE_RECOVERY_EXECUTION_PLAN §7.3` 第 3 步据此判"世界没被动过"并把事务丢掉。**文档写了三条要求、代码满足两条，
第三条（"crash recovery 识别执行到哪一步"）四轮来没人能证伪**，因为当时的接缝只在计划结束后写一次。

落地的形状是"执行器问，注入的 sink 答"：`EffectCursor::record_intent(phase, index)` 在每个 `Cutover` 步骤之前被调用，
sink（`worker.rs::JournalIntentCursor`）走既有的 `EngineHandle::advance_apply_phase`；**写不下去就 refuse 那一步**，
于是 guard 不是日志而是不变量。两条分工值得单独记：① 窗口的**第一条**记录仍然不可被拒也不计费（`advance_records_touched_world`
本来就是干这个的，游标链住自己那份 journal 之后该谓词自然转假），其余各条可被拒 —— 同一规则细到步级；
② 没有"步完成"回调，因为下一条意图记录必然涵盖上一条的完成，窗口末位由计划结束时的 fold 负责，于是
"每步恰好一条"成了可断言的数字（多写一条就红）。`needs_intent_record` 带编译期锚点，覆盖面等于 `phase_of` 的分类正确性。

同轮顺带修掉两处自己不实的陈述与一处收紧：`ADR-036 §6bis-quinque` 那句「`advance_apply_phase` 由 `worker.rs` 填」
（grep 复现：worker 从没调过它，见 `§4.108`）；满仓抄来抄去的「`ADR-038 §6.2`」（ADR-038 没有 §6.2，锚点是
`OVERLOAD_AND_RETRY_MODEL §6.2`，见 `§4.107`）；以及 `run_apply` 里"一份命令一个预算计数器"—— 此前每个接缝各建一份
`RunLimits`，而 `for_command` 每次新建 `billed`，于是"64 次访问"实际是"每接缝 64 次"（`§4.109`）。
新增 13 条断言（`cutover_intent_guard.rs` 11、`run_limits.rs` 1、`dependency_direction.rs` 门禁 1：450 → 463，
门禁自报 `463 tests passed (floor 463)`），13 条证伪变异全咬住 —— 其中一条**第一版不编译**而作废重跑
（变异要保住绑定与 arity，否则测的是 rustc，`§4.112`），还有一条是专门给门禁自己准备的：它加一个行为不变的
第二接缝，测试全绿、只有门禁红。

第二十六轮补充：`ADR-036 §2.5` 的探针时限接上了 —— 立项表格里五个「没人读」的字段只剩字节预算一项。
形状是**分工**而不是加个 if：`StepEvidence` 多一个 `elapsed_ms`（运行时**报告**），执行器**判定**是否超出
`deadline_ms`；判定写进每个适配器，就等于每个适配器都有一次忘记它的机会，而那个字段当初正是这么变成交代的。
超限不新增状态：它是一次**验证失败**，`probe_passed` 保持假，于是快照不标、修订不提交（`ADR-016` 那道门本来就在这）。
边界取「用完刚好等于预算」为放行，`<=` 差一格就变成「因为你花了我给你的时间而拒绝你」。`deadline_ms == 0`
既不当「无限制」也不当「零时间」，而是在**碰任何运行时之前**拒 —— 与 `ADR-038 §2` 拒 `max_deletions: Some(0)`
同形：越界的上限是策略问题，缺失的上限是计划缺陷。
同一轮把 `caly_api::GcRunView` 接上生产者（`system.gc-plan` 带 `last_run`）：第二十五轮那条「两个渲染器必须
同一句话」因此从预防性变成真的在守一条路径，`None`（本进程没跑过）与 `Some(deleted = 0)`（跑过、无事可做）
在客户端侧也分开了。新增 13 条断言（执行器单元 4、探针门禁 6、daemon 侧映射 3），9 条证伪变异全咬住。
本轮也留下一条自我修正（`ONBOARDING_NOTES §4.105`）：我把自己算的合计 446 写进了文档，而门禁与生成器都给 447 ——
「不写自己算出来的总数」从建议升级成硬规定。补一句 sequel：同一轮后来给处置表编号加了新门禁（+3 条），于是
刚抄下来的 447 也过期了，最终两个裁判都给 450 —— **抄来的数也要在交付前重抄一次**，这就是为什么本轮最后
所有数字都是重跑之后写的。同一轮还多了一条 `§4.106`：给 DTO 加字段把两个没碰过的 `caly-ipc` 枚举顶过 clippy
阈值，处置是 `Option<Box<…>>`，基线没抬。

第二十五轮补充：`ADR-038 §13.2` 落地，这个 ADR 四步全部完成 —— 自动收集**默认关闭**，
打开它的唯一方式是一条 role-gated 命令。cadence 用 **idle 检查次数**而不是毫秒（本引擎没有可轮询的宿主时钟，
而崩溃矩阵要可复现），检查点唯一在 `consume_one_skeleton` 说"队列空了"的那一刻，所以自动化永不插到调用方之前；
计数器只在启用时前进，且**单调、永不重置** —— 自动周期的幂等 key 由它派生，重置会让第二次周期拿到与第一次
相同的 key 而被 dedup 吞成重放：收集器安静停摆，`last_gc_run` 看着仍然正常（两头各一条断言）。
`tick` 只排队、`cycle` 才删除，两侧共用同一个 `would_run` 判定，不重算"idle"。
`GcRunRecord::triggered_by`（`caller` / `automation:gc.idle`）进了 `summary_line`，`doctor` 与 bundle 因此看到
同一句；顺带处理了它的双胞胎 DTO `caly_api::GcRunView` —— 它有同一个渲染函数却**从来没有生产者**，
所以可以长期与引擎那份悄悄分叉而没人报错（`ONBOARDING_NOTES §4.102`，"有类型有渲染无生产者"是第四次出现）。
本轮也修了三句过期话（`§4.101` 的"改状态前先数住处"当轮命中三次）：`Ctx.deadline_ms` 仍能拒未开始的访问、
`caly-app::remote` 的预算转发断言已在第二十四轮补上、GC 生产接线在 ROADMAP 里还写着"剩余"。

第二十四轮补充：`ADR-036` 第 3 步 —— 预算从"字段"变成"有人读它"，而默认值不再是"无限制"。
`IoBudget::default_command()`（64 次**计入的** store 访问；不设字节上限）现在由三处共用同一个常量：
`RequestContext::new`、`caly_api::default_ctx`、`request_map` 的缺省回落 —— 两处各写一个数字就是下一次漂移。
`RunLimits` 多了一个计费器（`Arc<AtomicU64>` 语义：克隆共享，上限属于这一次命令执行），
`run_ready_in` 在**驱动 future 之前**扣一次，所以"预算耗尽"意味着 store 一次也没被问 —— 这条不是读代码看出来的，
是 `CountsPolls` 那个会自报 poll 次数的 fixture 断出来的（`§4.98`：一个"什么都没做"的守卫，没有计数者就没有证人）。
两条规则一并定下：**只给可以被拒的访问计费**（记真相那几条既不拒也不计，否则调用方的上限变成对引擎簿记的上限）、
"已计费 = 已尝试"（被预算拒掉的那次要退回去，不然重试循环会被自己的拒绝反复抽税）。
新拒绝种类 `BudgetExhausted` → 公开码 `CONFIG_INVALID` + `retryable=false` + job 结算 `Failed`；
`max_bytes` **仍然不生效**并写进 release note（`IMPLEMENTATION_STATUS §6bis`）：引擎看不见全部字节，
在那一处统计只会造出"数字在涨但没数全"的假保险。（**第二十九轮更新**：字节上限已由端口执行，见下面第二十九轮补充；这一句记录的是当时的判断，
而那个判断当时是对的——「引擎看不见全部字节」到今天仍然成立，只是不再等于「没人执行」。）第二十一轮欠的那条端到端断言补上了
（`crates/caly-app/tests/budget_parity.rs`：预算花光的 apply 在两条门面逐字段相同；remote 若不再转发，
远端会把默认预算花掉并跑成功，比较当场停止匹配）。新增 6 条断言，14 条证伪变异全咬住
（M9 第一次没咬住，就是 `§4.98` 那条缺口）。

第二十三轮补充：`ADR-036` 第 2 步 —— 命令的 `Ctx` 真的抵达了 store 接缝，而它到不了的那一半被写明。
`recovery::run_ready_in(future, &RunLimits)` 让 apply 的第一次 store 写入 obey 调用方：已取消或期限已过的命令
**在 store 被问之前**就被答复（测试用 `scan_recovery_state` + LKG 证明什么都没写）。拒绝原因是数据不是文案 ——
`StoreRefusal.kind` 决定 job 怎么结算，`JobOutcome::Cancelled` / `TimedOut` 这两个此前只有映射代码、没有生产者的
变体第一次有了。另一条规则是本轮自己长出来的：**拒绝只能阻止"开始下一步"，不能阻止"记下已经发生了什么"** ——
`finalize` / `mark_apply_reverted` / `mark_apply_recovery_failed` 连 `limits` 参数都没有，
`advance_apply_phase` 只在 `advance_records_touched_world` 为假时才 obey，而那个判据与写记录用的是同一个
`phase_starts_world_effects`（两处各写一遍 = 迟早各说各话）。到不了的那一半写进 `ADR-036 §6bis-quinque`：
所有后端在引擎这一层首次 poll 即就绪（挂起在 `FsStore` 内部就被 `block_on_ready` 摊平成 `StorageError`），
要让限制进到端口里得先让 `StorageBackend` 的签名带上 `Ctx`，而那动的是 `RFC-0007` 冻结过的形状。
新增 15 条断言（`run_limits.rs` 单元 6、`recovery.rs` 单元 3、apply 集成 6；401 + 15 = 416 由门禁与 census
各报一次），14 条证伪变异全咬住 —— 其中两条是证伪跑出来后补的断言缺口（`§4.94` 一个谁也关不掉的合取项、
`§4.95` cycle 结果与 job 记录的两答案分裂）。

第二十二轮补充：`ADR-036` 第 1 步 —— 有界执行器，而且它**不制造进展**。`caly_io::BoundedExecutor`
把三件事变成可断言的事实：准入（`max_tasks` 满了就是 `Busy`，文本同时给出在队数与容量，并且**不消耗
`TaskId`** —— 按 id 关联结果的调用方不该看到洞）、公平（一轮里每个任务只拿 `polls_per_task` 次轮询，
提交序即完成序；贪心驱动在第一轮就只答一个任务，这条断言当场抓住它）、时间（`Advance::StepMillis` 唯一
允许的动作是调用**注入的** `Clock::sleep_until`；`caly-io` 依旧零 clippy 豁免、零宿主时钟，`§6bis.1`
表过态的那一点就此落地）。两条 ADR 没写死的语义本轮定死并各有一条断言：端口自己的故障 `Ok(Err(fault))`
**原样交出、交一次、不重试**（重试纪律在调用方，`OVERLOAD_AND_RETRY_MODEL §4`），只有驱动器的 `Busy` 回队；
`ExecutorMetrics` 把 completed / port_faults / timeouts / cancellations / busy_stops 分开数，且
`submitted` 必须等于四类出路之和。为此 `runtime::drive` 的循环抽成 `drive_pinned`（问题在所有权不在措辞：
`drive` 按值取 future，一轮没就绪就把调用方正等的东西销毁了），生产路径里的 poll 循环仍只有一份。
13 条单元 + 4 条 `SimFs` 集成断言（后者要求被 `hang` 的读在注入时钟上判成 `Timeout`、不许动时间时判成
`Busy`、端口故障逐字段等于不经执行器的那一份）。执行器今天**没有生产调用者**：第 2 步把它接进
`run_ready` 之前，`max_tasks` 这个界只会被测试触到 —— 这条与 `run_object_gc` 同类，`ONBOARDING_NOTES §4.85`
已说清那是分工而不是遗漏。

第二十一轮补充（含收尾）：把 `ADR-036` 从"永远等一个执行器"里救出第一步。此前 `Timeout` / `Cancelled` 只能由后端
**自己声称**（`FaultKind::{Timeout, Cancelled}` 是造出来的答案），于是"驱动器能否区分二者"这个问句根本无法
提出。现在有了 `caly_io::runtime::drive`：每次轮询前先看取消、再看期限，两者都没说话而预算耗尽时答 `Busy`
—— **没有时钟就不判期限**，编造一个"期限已过"等于给调用方一个他无法核对的理由。`caly-io-sim` 配了一次性
`hang("fs.read")` 注入，让这条契约第一次跑在真后端上（仿真契约套件 13 条）。顺带三件：
`block_on_ready` 与 `caly-engine::recovery::run_ready` 收敛成同一个实现的两个包装（后者曾自带手写 `Wake`，
这就是"三份 poll 循环各自措辞"的来历）；`caly_common::CancelToken` 落地但**不过线**（句柄不是数据，远端拿到
惰性 token；跨进程取消=会话断开，那是第 2/4 步）；`RequestEnvelope.io_budget` 补上，于是
`Ctx.io_budget` 第一次有抵达 daemon 的路径 —— 这修的是 `ADR-036 §6bis.2` 记在它自己文中的事实错误。
`Ctx` **不**存绝对 deadline（`§4.86`：派生值必须住在有源的层，而 daemon 没有单调时钟）。两条关于我手法的账：
`§4.87`（sweep 自报"改了 21 处"却完全不认得字段简写，是编译器逐条抓出来的；以及我把脚本输出 `tail` 掉而没发现它中途
失败）。第 2–4 步（引擎侧接线、预算记账与默认值收窄、阻塞池与 `Http`/`Proc`）原样待办。

第二十轮补充：**回收真的能跑了**。`ADR-038` 的第 2 步落地 —— `SystemOp::CollectGarbage`（命令、
`Idempotency::Required`、`Role::Admin`、`mutates_revision: true`，**没有** `dry_run`，因为
`system.gc-plan` 就是 dry run）→ `CommandKind::StorageGc` → 一个任务。四条不可省的性质：
① 周期执行的必须正是它刚报告的那份清单（`GcPlanSummary` 同时带 `collect`（给人看）与 `sweep`（给 store
删），同一次计算产出；删除走从 `run_object_gc` 拆出来的 `sweep_objects`）；② root 不全或引擎忙时
**什么都不删**，并且报告与可执行清单被同一行清空（少一类保护 = 可以删掉正在用的东西，这是全套设计里唯一
不可逆的方向）；③ 周期不得把自己算作在飞工作，于是有了 `work_in_flight_except(state, excluding_job)`
—— 而**入队前那道门不继承这个豁免**（`§4.82`）；④ 忙时拒绝走 `§3.1` 的入队前位置，`StorageBusy` 因此有了
第一个生产者，同时 `generation` 一步不推进（`§4.58` 的教训）。顺带纠正一处我自己写错的事实：
"daemon 拥有当前快照"不成立，两处赋值都是从 store 推的，于是 `active_snapshot_id` 移进 `EngineState`、
由提交那一刻写入（`§4.81`）。支持包多了第 12 段 `storage-gc`。新增 10 条断言、9 条证伪变异全部咬住（其中三条一开始没红，原因在证伪工具自己，见 `§4.84`）；
三条关于我手法本身的账（`§4.81` / `§4.82` / `§4.83`）。

第十九轮补充：把**时钟接进比较**。第十八轮之后，`§4.74` 记的那处"两条时间线"还开着：对象的年龄来自
端口（真盘 = 文件 mtime），而计划的 `now` 来自 `ExecutionPolicy::clock_start_unix_ms`（默认 0）—— 两者
从未被任何代码关联。本轮落 `ADR-038 §3` 的引擎侧：`set_storage_clock` / `storage_now()`，计划优先用注入
的端口时钟，并把**用的是哪一个**写进 `now_source`（`doctor` 的那行 note 因此长这样：
`now=1700000000000@execution-policy-base`）。三件事值得单独说：① journal 的时间戳**不换** —— 它必须与
`audit` 的 `now` 同源，统一成宿主时钟会让确定性回放门禁把每个 journal 都说成陈旧（`ADR-038 §7` 有对照表）；
② 检出器是**单向**的（只抓"年龄来自未来"），反方向不可判定，所以"第 3 步先于第 2 步"不是排序偏好而是
安全前提（`§4.80`）；③ 本仓库没有 `[[bin]]`，所以真机部署暂时没人填这个参数 —— 接缝 + 报告 + 两侧测试
都到位，缺的是入口，这点写在 ADR 里而不是含糊成"已完成"。新增 4 条断言、6 条证伪变异全部咬住；
另外补了一条渲染自检（`assert!(!detail.contains("  "))`），因为本轮又一次踩到"补丁把 Rust 字符串的续行
折成一行"（`§4.79`，与 `§4.68` / `§4.78` 同族）。

第十八轮补充：把 `§4.73` 记的那笔账**开始偿还**。`caly_storage::gc` 的策略自第五轮起就有测试、没有生产者，
于是"磁盘只增不减"在所有观测面上都表现为健康。本轮按 `ADR-038` 只做第 1 步 —— **先让计划可读，再让删除可行**：
`RevisionStore::list_revisions` 补上 `RFC-0007 §13.1` 六类 root 里唯一没有来源的那一类（默认答 `Unsupported`
而不是空集：空集在 GC 语境里等于"这些对象没人要"）；`caly-engine::gc_plan` 把计划算成一份**全有或全无**的报告
（任一 root 读不到 → `collect` 清空 + 指名道姓的缺口，而不是给出一份少了那一类的删除列表）；
`SystemOp::GcPlan` 把同一份视图同时交给本地与 session 门面；`doctor` 增一条 note 承载计划与拒绝原因。

接线时查出两件更基础的事，都已留档：`required_role` 当时只在命令路径执行，读与流的声明是空头承诺
（`ProfileOp::Plan` 的 `Operator` 从未生效，`§4.75`）—— 本轮把门禁提到 `handle_request`，两条路共用一个
`require_role`；以及上一轮把对象年龄换成端口 mtime 之后，年龄与 `now` 落在两条时间线上（真盘 mtime vs
注入的策略时钟），在真实目录上"所有对象都在未来"（`§4.74`）—— 计划现在检出并拒绝，根因（组装根注入
`Clock`）留在 `ADR-038 §3`。另两条自查同样值得记住：给"健康/不健康"判定加信号前先问它对健康系统是否恒真
（`§4.76`），以及补丁把表格行粘进段落时**所有门禁全绿**（`§4.78`，已补 `check_stray_table_rows`）。
新增 20 条断言（引擎单元 8 + 存储 4 + 门面 8）、11 条证伪变异全部咬住。

第十七轮补充：`ADR-035` **收尾**（第 3 步）。对象的年龄过去是调用方填的一个整数，
`FsStore::put` 原样写进记录、原样报告；而 `§13.1` 的 grace period 保护的恰恰是"刚写完、还没有任何
root 引用它"的那个�口 —— 于是一个 `stored_at_unix_ms: 0` 就能让新对象在 G一给记录定年的地方，`put` / `get` / `list_objects` / 启动填缓存四条路都过它，
规则是 `max(端口 mtime, 记录声明)`：两个来源会朝不同方向说谎（声明可填旧、mtime 会因备份恢复或时钟
回跳而偏旧），而这个字段唯一会丢数据的错法是"看起来更旧"。端口答 `None` 时**不伪造**——这既是不 invent
纪律，也是 `object_contract.rs` 跨后端同答能守住的原因。这条比 `ADR-035 §2.4` 的字面更保守，偏离与理由
写在 `§6bis-quater`，并且有一条测试钉住方向（把实现改回"端口直接覆盖"会红）。

同一轮里查出两件没解决的事，都记下来了而不是留成"第 3 步完成"：`GcPolicy::now_unix_ms` 仍是调用方给的
（`caly-storage` 不持有 `Clock`，年龄的另一半没有端口来源）；以及 **`gc.rs` 整条链没有生产调用者**
——`run_object_gc` 只被自己的测试调用，磁盘因此事实上只增不减，而"未覆盖"清单当时只在细节上诚实
（写着"grace period 依赖注入时间"），在结构上漏项（没写"入口不存在"，`§4.73`）。

第十六轮补充：把地基缺口**接线**。第十五轮只加能力，本轮删掉绕行的那一层：`caly-storage` 不再维护
`manifest/*.idx`，`list_objects` / `list_snapshots` / `list_*_apply` / 启动校验全部走 `Fs::list`，
端口根与 store 根之间的换算收进唯一一处（`fs_store::list_directory`）。`open()` 的语义因此从
"清单必须与实体一致"变成"实体必须自洽"：记录解不开、内容对不上锚点仍然拒启，**新增**的是
"目录里出现布局解释不了的名字"也拒启（清单时代看不见它），**放弃**的是"某个记录被带外删除"（没有
第二份名单可以说这里本该有一个）—— 这一得一失写进 `ADR-035 §6bis-ter`，不含混过去。三处顺带的收获：
崩溃留下的改名残留必须在启动时回收（否则 `ListCap` 预算会被非记录文件吃掉，store 起不来），
回退点从"抄清单"改成"抄记录"（`create_rollback_point` 现在枚举目录），而
`schema::has_any`——"这个目录到底是不是空的"——也第一次能用真列举回答，且列举失败按"有数据"处理。
另外把四类枚举查询从进程内缓存上摘下来：`list_pending_apply`（决定要不要拒绝启动）与
`list_apply_journals`（导出给人看）此前一个读缓存一个读盘，是一个 store 两个答案；现在每个集合只有
一个 loader，同一集合的多个查询在结构上不可能再给出不同的集合。
新增 5 条断言、9 条证伪变异全部咬住（harness 自己也被证伪一轮：`mv` 恢复保留旧 mtime，导致门禁跑的是
带着变异的下游二进制，见 `§4.71`），其中一条**一开始不咬**：我原本用"重启后看得见"证明"来自枚举"，
但 `load()` 也是用枚举填缓存的，两种实现在重启点必然同值 —— 改成对运行中的 store 断言才成立（`§4.69`）。

第十五轮补充：中心线的**地基缺口**。`Fs` 端口没有目录列举，`caly-storage` 因此自己维护
`manifest/*.idx` 当作"有什么"的第二份真相，并用启动时全量校验兜住不一致（`§4.15`）；`Meta` 没有 mtime，
`RFC-0007 §13.1` 要的 grace period 只能靠调用方注入时间，未知年龄一律不删（`§4.20`）。`ADR-035` 第 1 步
把能力补上：`Fs::list(dir, ListCap, ctx)` 有序 / 可预算（超限是 `CapacityExceeded` 而不是截断）/ 只一层 /
"空目录"与"不存在"可区分；`Meta.modified_at_unix_ms` 是 `Option`，仿真的时间只来自注入的虚拟时钟。
两个后端跑同一套共享契约（新增 `fs_listing_violations` / `fs_mtime_violations`）；落地时才看清两条必须
写死的边界：**恰好等于上限必须成功**（否则"给我全部"的调用在满目录上必挂），以及**对文件 `list` 是
`InvalidInput` 而非 `NotFound`**（真盘拿到 `ENOTDIR`、仿真盘拿到"没这个目录"，两者的直觉实现正好分岔，
而 `NotFound` 会让调用方以为整棵子树可以放弃）。仿真端为此必须记录被创建过的目录
（`MemFs::dirs`）—— 这不是风格选择，是"区分空与不存在"在扁平模型下的唯一实现方式。
`RFC-0006` 补了 `§8.4`（含错误映射表）与 `§15` 第 8 条，并把"冻结的是语义不是 trait 签名"写回 `§16`
（`ADR-035` 原本把这条约束写重了，见 `§4.67`）；`RFC-0007 §6.4` 冻结了 `runtime_path` 的路径基准。
当时**第 2、3 步未落地**：清单层还在、GC 仍吃注入时间，所以 `list` / mtime 是"有契约、有测试、
无生产调用者"，这句话写进了未覆盖清单而不是装作完成。
（第十七轮记：第 2、3 步已分别于第十六、十七轮落地，"无生产调用者"这句因此不再适用于 `list` 与
`mtime` —— 保留原文是为了留下"补了能力 ≠ 接完线"这条判断；今天的对应缺口换成了 GC 的接线与
`stat_many`，见上面第十七轮补充与 `ONBOARDING_NOTES §4.73`。）
另外：本轮我自己删掉 4 个契约测试而所有判定者都没反应（表格是从树里重算的，它如实报了"少 4 个"），
于是给门禁加了 `TEST_FLOOR`（`§4.66`）。

第十四轮补充：中心线的**入口身份**。`ADR-035 / 036 / 037` 三份 Proposed 由维护者授权定稿，037 落地：
`required_role` 第一次真的会拒绝（本地与 session 默认都降到 `Operator`，更高权限由组装根声明）；
`Idempotency::Required` 从「4 个操作声明、0 处读取」变成有执行点的契约（缺 key → `CONFIG_INVALID`，空白 key
对任何命令都拒 —— 它是一个共享桶，不是 key）；`RequestMapError` 带 kind，两类拒绝不再混报 `PERMISSION`；
去重窗口只淘汰已完成条目并按 `evictions` 自报；本地 `request_id` 改为单调分配，`Command.id` 不再全是
`req-0`（`§4.61`）。定稿过程中我自己的「宽松变体」（缺 key 时派生 `req:<request_id>`）被 `run_write_parity`
当场否证：两条路径的 id 各自计数、窗口按 actor 全局，于是本地与远端的 `fresh-a` 派生出同一个 `req:1`
而互相吞掉（`§4.62`）—— 这条记录留在 ADR-037 §2bis，因为它说明「拒绝」不是保守而是唯一自洽的读法。
035 / 036 同时定稿但**实现未开始**，各自写下偏离与分阶段顺序（036 还顺手改了两处与代码不符的说法：
`RequestEnvelope` 根本没有 `io_budget` 字段）。留档 `§4.61-§4.63`。

第十三轮补充：中心线的**拒绝出口**。`processor::submit_command` 原先先分配 job id、先 `bump_generation()`，
再在 `enqueue` 里发现队列满了 —— 于是"被拒的那一次"照样推进了 revision，而 revision 正是 `expected_revision`
比的那个数（`RFC-0002 §6.2`）：一次容量拒绝会让**别的**客户端合法的 CAS 前提变成 `CONFLICT`
（`OVERLOAD_AND_RETRY_MODEL §3.1` 的"不产生 apply side effect"是硬要求，不是措辞）。同时 `OverloadReport`
有两个映射器，接在 daemon 线上的是只留 code/category/retryable/summary 的那一个，正是同一份文档 `§8`
禁止的形状，而带 `retry_hint` 的那一个无人调用。本轮：判断容量前置于一切改写；映射合成一个（`detail` 带
`error=<class> retry_hint=… queue_len=… queue_cap=… at_generation=…`，`diagnostics[]` 带机器可读类别，
`StorageBusy` 归 `Io`）；拒绝记入有界日志并按类别汇总成**同一份文本**，`doctor` 与 bundle 的 `overload` 段
共用（`§7.2` 的内部出口）。判定：引擎单元 3 条、`caly-daemon/tests/overload.rs` 4 条（含两条 daemon 的差分
对照：只拒 vs 不拒，之后接受的 revision 与 job id 必须逐项相等）、bundle 1 条、scenario `overload.*` 5 行。
留档 `§4.58-§4.60`（`§4.60` 记的是我自己的注入脚本把红名单搞假了这件事）。

第十二轮补充：把"读得到"补成"读得完"。`ReadJobEvents` 当时一次返回整个保留窗口，而"切片从哪一行开始"
这件事在 `watch_bridge` 里被**重算**了一遍；现在 `JobEventWindow.first_index` 是唯一出处，流帧 `seq` 与
分页游标读的是同一个数。响应上界由 `caly-daemon::paging` 施加（默认 64 行 / 64 KiB，上限 512 行 / 1 MiB，
0 值拒绝），请求 DTO 因此与 `JobFollowRequest` 分家 —— 否则 follow 一侧要背两个它从不读的字段。
补这条的同时发现 **scenario 套件的一半从来没有判定者**：门禁信任的是五行 `run_loopback_scenarios`
（其中三行状态硬编码 `true`），而 123 行的 `run_smoke_bundle` 只被一个没有 `[[bin]]` 的 crate 引用。
加上 `every_scenario_suite_row_passes` 之后第一次运行就红了三处：跟不存在的 job、永不发出的
runtime-state patch、以及把 `ErrorCode` 丢掉的 harness —— 三处都已修，假绿套件与它那份并行的
`ScenarioSuite` 类型一起删除。留档 `§4.54-§4.57`。

第十一轮补充：把 job 的**事件内容**接进可比对的范围。`JobFollowView` 只有计数，而 `JobFollowProjection.window`
里一直有全部 `JobEvent` 却没交给调用方；本地 façade 的 `follow_job_stream` 只回一个 `WatchOpened` 句柄，
进程内根本没有泵可开 —— 也就是说"看事件行"这件事**只在有 transport 的那一侧存在**。现在 `DiagnosticsOp::ReadJobEvents`
是一条 Query，两条 façade 都有，渲染复用引擎唯一的那个 `render_job_event`；`run_write_parity` 因此能比"行"而不止比"数"，
并带反-vacuity（任一侧为空即失配）。顺带清掉了最后两个有损包装点（`with_client` 从 façade 文件消失），
`slice_job_events` 的 reset/续读算术补了单元测试并当场抓到一次 off-by-one。留档 `§4.50-§4.53`。

第十轮补充：导出**闭环**。上一轮 bundle 只是写进 CAS 并印了个摘要，谁都拿不回来（`ObjectStore` 没有
内容读路径）；本轮补 `read_object`（默认 `Unsupported`，读时先按锚点校验）+ `DiagnosticsOp::ReadSupportBundle`
（Query，`digest: None` = 最新一个；**只允许 `ObjectKind::SupportBundle`**，因为 CAS 里的编译工件不脱敏）。
顺带用一组跨后端断言（`caly-storage/tests/object_contract.rs`）抓出两处"内存后端与落盘后端各说各话"：
metadata-only 的 `materialize` 一个报错一个 `Ok(())`；`put` 声明假锚点一个拒绝一个静默覆盖。
留档见 `docs/history/ONBOARDING_NOTES.md §4.45-§4.48`。

第九轮补充：中心线的**写入出口**接上。`RemoteFacade` 此前给每类写操作伪造一个常量 idempotency key
（引擎按 `(actor,key)` 去重且**不比载荷**）⇒ 同一 daemon 上第二次远端 apply 直接返回第一次的 job 并
"完成"，而本地路径两次都跑；`Accepted.estimated_impact` 被 daemon 重建为 `ReadOnly`（引擎早已分类好）；
`ctx.expected_revision` 传到引擎后无人读；远端还把 `trace_id` 换成每方法字面量、把 `ApiError` 压成
String 再包成"可重试"。四条都已修，并新增 `run_write_parity`（四 case + 两条 CAS 探针 + 五条信封比对）、
`caly-daemon/tests/cas_and_impact.rs`、`caly-app/tests/error_identity.rs`。
留档 `docs/history/ONBOARDING_NOTES.md §4.37-§4.43`，契约面 `docs/engineering/REMOTE_FACADE_PARITY.md §3bis`，
未决语义 `ADR-037`（Proposed）。

第八轮补充：中心线的**最后一段对外表面**接上：`DiagnosticsOp::SupportBundle` 从一条 skeleton 日志变成
10 段导出（`caly-engine::bundle`），字节进 CAS、作业上报内容摘要；`RFC-0010` 的脱敏从"文档里有 MUST、
代码里 0 命中"变为三条边界（`append_job_event` / `handle_request` / `BundleDraft::finish`）。
为此补了 `ApplyJournalStore::list_apply_journals`（"最近 apply 摘要"此前在接口上做不到）并把
`doctor` 与 bundle 的审计装配收敛成同一个 `caly_storage::audit_backend`。
规则与门禁↔测试映射见 `docs/engineering/REDACTION_AND_SUPPORT_BUNDLE.md`；留档见 `docs/history/ONBOARDING_NOTES.md §4.28-§4.34`。

第六轮补充：`RFC-0007 §12` 的 schema 门禁落地 —— 版本号写进目录（`schema/storage.rec`）、
启动时先分类再放行（`Absent/Current/Older/Newer/Corrupt`），迁移必须**分步连续**、迁移前**先建回退点**、
失败即拒绝启动（`§15.5`）。`§12.3`"不得把未知旧 schema 当作当前 schema"是按字面实现的：
版本更高的目录一律拒开，不做任何"试着读读看"。
另为两个结构性阻塞点提交了 ADR 草案（`ADR-035` `Fs::list`/mtime/路径基准、
`ADR-036` 有界端口执行器与 `Ctx` 限额），状态 **Proposed**，等维护者确认。

第五轮补充：恢复状态现在会**闸门**命令 —— `Recovering` 拒绝新的 `profile.apply`（但保留
rollback 这条出路，也保留全部查询），后端自相矛盾时进 `Failed` 并拒绝一切命令。此前"报告状态"与
"接受写入"是两件事：客户端忽略 status 字段就能在未解决的事务之上再部署一次。
留档见 `docs/history/ONBOARDING_NOTES.md §4.21-§4.22`。

第五轮（同日）补：`STORAGE_RECOVERY §8` / `RFC-0007 §13` 的 GC 落实为 `caly-storage::gc`（此前
`ObjectStore` 既不能枚举也不能删除，GC 在接口层面就无法实现）；daemon 现在能把状态恢复**从盘上**做完
（`try_bootstrap` + 注入后端），并修掉了"重启后 `active_profile` 为空但快照存在"的状态视图不一致。
留档见 `docs/history/ONBOARDING_NOTES.md §4.18-§4.20`。

第四轮（同日）补：中心主链第一次**跨进程**闭合。`caly-storage::FsStore` 经 `caly-io::Fs` 落盘，
`caly-engine/tests/durable_centerline.rs` 用"换一个新 engine、重新 open 同一个盘"验证：已提交快照可恢复、
被打断的 cutover 会以 `RollbackToLastKnownGood` / `RevertOsEffectsOnly` 决策重新出现、
被篡改的 CAS 内容让 `open()` 直接失败。为此 `CasWriteIntent` 补上了载荷（此前 CAS 只是 digest 索引）。
留档见 `docs/history/ONBOARDING_NOTES.md §4.14-§4.16`。

第三轮（同日）补：`caly-io-std`（生产 IO 网关：`StdFs` 全量 + `StdClock`）建立，并与 `caly-io-sim`
共用 `caly_io::contract` 契约套件（`RFC-0006 §15` 第 1/2/5/7 条 + 锁语义）；`SimFs::lock_exclusive`
原本永不竞争，已改为与生产端同构的锁文件模型。留档见 `docs/history/ONBOARDING_NOTES.md §4.9-§4.13`。

第二轮（同日）补充：`storage_backend_swap.rs` 用第二个后端跑通同一套断言并覆盖 `Busy` 路径；
恢复扫描改为覆盖 `Pending | RecoveryFailed`（此前“补偿也失败”的事务会从扫描里消失）；
`executor.rs` 拆成解释器 + `sim_runtime.rs`，`execute_profile_apply` 从 383 行拆成 6 个相位函数。
留档见 `docs/history/ONBOARDING_NOTES.md §4bis`。

---

## 5. 当前仍然缺的关键部分

1. **Source blocking 边界的剩余硬化**：HTTP→parser→CAS→D3 的同步阶段已有统一注入 clock 的 cancellation/deadline 检查与真实 fixture 裁判；`StdHttp` 单个 OS blocking syscall 不能被 CancelToken 从中途强行打断，未来可挂起 runtime/transport 的中断与回收语义仍未定；
2. **Source inspection 的规模扩展**：当前 durable provenance/diagnostics 已完成 bounded API projection 与统一 redaction；若未来放宽 parser/source record 上限，再补分页/stream 契约，当前不把没有分页写成缺陷；
3. **真实 effect runtime 的跨进程/平台边界**：`calyd` 已可用显式 `--effect-runtime real --runtime-root … --assets-dir …` 组合 `StdEffectRuntime`，并在 listener 前做 preflight；默认仍为 `SimulatedRuntime`，跨进程 recovery/adoption、Platform/TUN/helper 与完整 OS 网络副作用未落地；
4. **RuntimeDriver 统一语义**：`config_identity()`、完整 runtime API/telemetry 与当前最小 `EffectRuntime` 接口尚未统一；
5. **通用 IPC transport runtime**：`caly-ipc` 的 UDS/双工读写泵、timeout scheduler 与完整 production transport 仍未完成；
6. **Capability 来源切换**：执行仍从代码内建 default 读取，JSON 工件目前只用于漂移门禁；
7. storage schema migration / `stat_many` 性能面、security/secret/platform 余项、stream 逐帧 payload 与 engine→具体 adapter 的已登记架构债仍待处理。

---

## 6. 本阶段的关键结论

- merge 不再返回空图，resolve 不再拼占位 digest
- artifact 不只是文件名 hint，adapter 不只返回 “accepted”
- **apply 不再只是 plan 的字符串投影**：typed step 被解释，门禁被强制，补偿被执行
- daemon command path 与 job follow 已能观察执行与恢复阶段
- source ingest 现在有显式 locator、真实 parse/normalize、raw CAS 校验与 normalized cache 消费；durable source index 以 D3 record、重启恢复、304 复用与 locator 变更删除接入中心线
- 中心线的每一步现在都有断言约束，而不只是编译约束

---

## 7. 一句话结论

> Caly 的真正进度，不取决于页面或命令数量，而取决于
> `Profile -> IR -> Capability -> Native -> EffectPlan -> Execution -> Snapshot -> Recovery`
> 这条链是否持续闭合：当前已经能在仿真后端执行并恢复，且 source ingest 的显式 locator、条件请求、raw CAS 复用、parser provenance、durable source index、caller phase-boundary checks 与 inspection projection 已接入；
> 下一步的判据是 blocking syscall 边界的诚实扩展、真实 runtime 的跨进程/平台安全面，以及共享 timeout scheduler / typed send_request_frame 与 security 面（BindSpec/WireIo 已由第八十七轮接入）；生产组合根的显式 real 选择与 preflight 已由 `ADR-050` 固化。
> 当前门禁为 902 tests / floor 902 / clippy baseline 31；fmt 0 行（硬门禁）。本轮完整 workspace 回归由 `./scripts/check.sh` 实测。
> 判据是“这 902 个断言是否依然成立”：门禁会拒绝任何让测试数掉下下限的改动 —— 少一个测试就是一次回归。
