# Caly Roadmap

本文件给出 Caly 从文档冻结走向可运行系统的建议实施路线。

路线的核心原则是：

> **先建立边界与契约，再做最小纵向切片，最后扩展功能面。**

并且在当前阶段还要再补上一条更硬的执行原则：

> **优先持续闭合中心主链，而不是反复扩外围协议壳。**

也就是说，Roadmap 的阶段不是“先界面后底层”，而是：

1. 先让契约可编译
2. 再让 centerline 可解释、可验证、可计划
3. 再让 daemon / IPC / CLI 围绕 centerline 形成真正执行闭环

---

## 1. 路线概览

> 当前快照：2026-09-02（R117–R123 见前；R124 calyd 优雅排空（ADR-056 增补）；R125 跨进程 core adoption（ADR-060）；R126 durable source index 的 cache tag 演进与读时迁移（ADR-061）；R127 SnapshotThenPatch watch 流（快照首帧+有界分拉+慢客户 Reset，IPC_STREAM_POLICY §3/§7 落地）；R128 确定性 fuzz 四面+计数制性能回归入常规门禁（里程碑 7 硬化收口）；R129 有界 DNS 解析（ADR-052 增补 §7，§12#1 收口；同轮收口补丁修复 R125 起潜伏的 SIGTERM 掩码顺序缺陷，ADR-056 增补 §8）；R130 §12#4/#5 收口（Deployment 流生产者+EventBacklog/StreamBackpressure 生产者；capability registry=导出物早已由 ADR-051 定案）；R131 深度审查+后续设计文档轮（9 项发现留档于 `docs/engineering/CODE_REVIEW_R131_FINDINGS.md` 待统一修复；平台面与 TUI/golden 设计计划已立）；R132 构建后 CLI 功能测试轮（全动词矩阵实测，follow 用法缺陷修复）；R133 R131 账本修复批（7/9 项收口）+二轮质量审查；R134 平台面第一轮（UDS socket-mode 组共享+sources 注册配额，PLATFORM_FACE_PLAN §2.3/§2.4 收口）；R135 storage 量选（工装+基线+悬崖行为钉，§2.5 收口）；R136 ADR-062 记录目录分片+生产迁移链 v1→v2（量选悬崖拆除）；**982 个测试** / floor 982）。过程证据保留在各轮 `docs/history/logs/DEVELOPMENT_LOG_*.md`（最新 `DEVELOPMENT_LOG_2026-08-31-round109.md`）与 `docs/history/ONBOARDING_NOTES.md §4/§6`；本表只描述当前状态。**功能面速查（为什么/面向什么/状态）见 `docs/guides/FEATURES.md`。**

| 阶段 | 目标 | 核心产物 | 当前状态 |
|---|---|---|---|
| Phase 0 | 文档冻结 | RFC-0001 ~ RFC-0010，ADR-011 ~ ADR-061 | `Done`（10 份 RFC、51 份编号 ADR，均为 `Accepted`；ADR-055 systemd 分层、ADR-056 SIGTERM、ADR-058/059 wire/transport、ADR-060 跨进程 adoption 为冻结后增补——实现切片见各自 §5/§4） |
| Phase 1 | 工程边界落地 | workspace、crate 骨架、clippy/arch guardrails | `Done`（20 个成员；直接外部依赖只有 ADR-046 授权的 `serde_json`） |
| Phase 2 | 源码级契约落地 | Operation、ApiError、Facet、IoFault、Stage、ApplyPlan、EffectStep、IPC skeleton、registry schema | `Partial` |
| Phase 2.5 | 编译打通与契约收敛 | toolchain、workspace check、依赖修复、命名收敛 | `Done` |
| Phase 3 | 基础设施与 IO | IO Port、Storage、CAS、Pipeline、sim world | `Partial`（`StdFs`/`StdClock`/`StdHttp`/`StdProc` 与 `FsStore` 已有生产 slice；Platform、schema migration 与性能面仍缺） |
| Phase 4 | 控制链与 daemon | Command、Job、Coordinator、queue、event、daemon bootstrap | `Partial`（daemon command/apply/recovery 与真实 binary 入口已接入） |
| Phase 5 | 核心主链纵向切片 | Profile/Source/Override -> IR -> ResolvedProfile -> Native -> ApplyPlan -> EffectPlan | `Partial`（真实 source parse/normalize、CAS/cache 消费、durable source index/provenance 恢复、caller phase-boundary checks 与 inspection projection 已接入；blocking syscall 的即时中断及更广的 runtime/platform 仍缺） |
| Phase 5.5 | Effect 执行与恢复闭环 | Effect executor、journal/snapshot 提交、补偿回滚、启动恢复扫描 | `Partial`（内存/落盘后端闭合；`calyd` 已支持显式 real runtime 组合与 preflight，默认仍 simulated；跨进程 adoption 已由 ADR-060 收口：kill -9 后的孤儿核按凭据+pid/start_time 身份接管、拒绝按名、pidfd 可停） |
| Phase 6 | Daemon / IPC / CLI 连接 | LocalApi、RemoteApi、Job、watch、CLI 可用 | `In Progress`（`calyd`/`caly` binary 与 v0 TCP+UDS slice 已有；BindSpec/WireIo/FramePump/共享 timeout scheduler/UDS peek（ADR-059）已接入；typed 双表接线已重估定案为显式不做（R123），§13#3 传输项全收口） |
| Phase 7 | 双 Core 纵向切片 | Mihomo / sing-box 两个 core 的第一版 vertical slice | `Partial`（资产、spawn/probe/stop/rollback 真核 slice 已有；artifact golden 与完整 runtime API 仍缺） |
| Phase 8 | Platform / Recovery | TUN、system proxy、helper、journal、rollback、recovery | `Partial`（recovery、Direct/ActiveCore/SystemProxy 的已有 slice；Platform/TUN/helper 未完成） |
| Phase 9 | TUI / Runtime UX | dashboard、connections、traffic、logs、select/probe UX | `Planned` |
| Phase 10 | 硬化与发布门禁 | fuzz、真核 CI、性能回归、doctor、support bundle | `Partial`（doctor/support-bundle/redaction 与真核裁判已有；CI 已上线（2026-09-01，与本地同一套）；fuzz 与计数制性能回归已入常规门禁（第一百二十八轮）；余 artifact golden 加强与平台面） |

---

## 1bis. 按阶段量的完成度（2026-08-30 当前快照）

这一节只写能由当前树复算的事实；旧轮次的数字不在这里重写。

| 阶段 | 量的东西（命令） | 实测 | 由此可下的结论 |
|---|---|---|---|
| 0 文档 | `ls docs/rfcs/*.md`、`ls docs/adrs/ADR-*.md`、`grep -m1 -o "Status: [A-Za-z]*"` | RFC 10、编号 ADR 47、Accepted 47 / Proposed 0（另有 ADR-TEMPLATE.md 模板文件，自身标 Proposed——非编号 ADR） | 冻结层无待确认 ADR；ADR-057 已 Accepted，其实现切片按 §5 推进——切片 1/2（存储 primitive、引擎终态写入+启动恢复，R108/R109）与切片 4 的裁判（真二进制 kill-9 重启 e2e + GC 不碰历史，2026-09-01）已落地，切片 3 剩 support bundle 收录作业轨迹 |
| 1 工程边界 | `cargo metadata --no-deps`、扫描 workspace manifests | 成员 20；`caly-daemon` 的直接外部 crate 为 `serde_json`，由 ADR-046 授权 | 依赖边界仍由 arch test 守护；当前不是零外部依赖 |
| 2 源码级契约 | `cargo test --workspace`、`caly-arch-test` 文档/依赖门禁 | 890 个行首 `#[test]`，108 个文件；契约、parity、scenario、durable source index、source inspection、calyd runtime preflight、source-index 损坏形态证伪（含第七十五轮补齐的 `raw_object_digest` 锚格式与三个 cache digest 锚格式按名诊断）、docs/guides/ERRORS.md §4/§4.1 名称闭包（第八十轮：文档码名↔枚举方向性双射 + 保留/实现中点钉死 + §3/§4 文档内部词汇自洽，falsify 4 变异全咬含跨轮 R80/R79 双红）、EXIT_CODES §2 名字列 + 双胎名一致（第八十一轮：`ExitCode::as_str`≠`ErrorCode::as_str` 漂移=跨 crate 双裁判红）、§4↔§5.x 使用规则覆盖（第八十二轮：§5 规则小节与 §4 稳定码一一覆盖、保留码不得有规则小节）、`ErrorCode::category()` 默认权威与 §4 双向裁判（第八十三轮：默认类 ↔ §4 Category 列；逐例偏差经审计登记）、RetryPolicy 型与 §4 双向裁判（第八十四轮：文档四词 ↔ `retry_policy()` 四值，bool 保持实例级）、生产 CLI 入站帧帽走共享 codec（第八十五轮：超 cap 头即拒 + `timed_out` 命名，falsify 2 变异）、生命周期拒收消费 §4 默认（第八十六轮：`ApiError::for_code`，CONFLICT→Config/不可重试，falsify 2 变异）、共享 BindSpec/WireIo 生产 UDS 与 handshake-only ClientLoop（第八十七轮：TCP port-file 仍裸 u16、UDS 写 unix: 前缀、编码谎言在 observe 前拒绝，falsify 2 变异）、v0 wire 请求形状单源与对称闭包（第七十六轮：`caly_ipc::wire_request` 编码表 + CLI 迁移消费 + 真 daemon 门扫描裁判 + 无线名按名拒绝；第七十七轮：`decode_request`/`wire_stream_request` 解码镜像 + follow-stream 双形状收编 + round-trip 对称裁判 + 14 名单覆盖（R106 `jobs.list`））、stream 逐帧 payload 断言、spawn 产物字节 golden、registry 工件方向（导出物非运行时输入）、真核心身份/遥测（`CoreIdentity` + `TelemetryTraffic`）、内置文档单次构建（`OnceLock` 记忆化判等）、v0 wire 记录方言统一与 hello_ack 内容校验（`caly_ipc::dialect` + 假 daemon 矛盾应答裁判）、blocking syscall 中断/回收语义（`ADR-052` + 对端挂起有界回收/不可中断诚实性裁判）、SSRF 网络访问边界（`ADR-053` + 连接后 peer 校验/默认保守拒绝/显式放行裁判）、Fs 批量 stat 面（`ADR-054` + `stat_many` 契约等价/单次调用计数裁判）均有判定者 | `Partial`：类型与主要语义有断言，完整 transport/security 面仍缺 |
| 3 IO / Storage | 检查 `caly-io-std` 的 `Std*` 实现、`FsStore` 与 `caly-io-sim` 契约 | `StdFs`/`StdClock`/`StdHttp`/`StdProc` 已有；`Platform` 仍无实现；落盘 store 已有 | 单一 IO 网关与有界 body/进程面成立；Platform 仍是决策性缺席 |
| 4 控制链 / daemon | `find crates -name '*.rs'`、`caly-daemon`/`caly-engine` 测试与 binary targets | source update、apply/recovery、GC、真实 `calyd`/`caly` 入口已接入 | library + binary 的中心 command path 已可复验 |
| 5 / 5.5 主链与恢复 | 检查 `parse_source`、source worker、executor、journal/recovery 与 apply tests | source decode/normalize→CAS/cache→apply 消费、durable source index 跨重启恢复、HTTP→parser→CAS→D3 的同步 phase-boundary deadline/cancellation 与 durable inspection projection 已闭合；blocking syscall 即时中断仍未 | “会规划→会执行→会记账→会恢复”成立，source endpoint/validators/raw CAS/normalized/provenance/diagnostics 可跨重启复用 |
| 6 Daemon / IPC / CLI | `grep -rn "TcpStream\|UnixStream" crates/`、扫描 `[[bin]]`、运行 calyd E2E | `calyd` 与 `caly` binary 存在；v0 TCP+UDS record/JSON payload slice、worker/reconnect/ack 已有；BindSpec/WireIo/FramePump 已接入生产 | 共享 timeout scheduler 第一百二十二轮、UDS peek（ADR-059）与会话递增 request_id/连接复用第一百二十三轮接入；typed `send_request_frame` 双表接线 R123 重估定案为显式不做（单一 typed 编码表 `wire_ops` 即生产路径，门禁钉死）——§13#3 传输运行时项全收口 |
| 7 双 Core | `crates/caly-daemon/tests/real_apply.rs`、资产/adapter tests | mihomo/sing-box 资产、spawn/probe/stop/rollback 真核裁判已存在 | 真实 core effect slice 是 `Partial`，不等于完整 Platform 部署 |
| 8 Platform / Recovery | `grep` Platform impl 与 daemon composition root | recovery 已落盘；Platform/TUN/helper 仍缺；StdClock 已由 calyd 注入 | 不再把 clock-timeline 或无 bin 当当前阻塞 |
| 9 TUI / Runtime UX | `ls crates` | `caly-tui` 不存在 | 未开始 |
| 10 硬化与发布门禁 | `./scripts/check.sh`、`regenerate_test_census.py --check`、`regenerate_doc_index.py --check`、fmt/clippy 输出 | 958 tests / floor 958；clippy 31；fmt 0 行（硬门禁）；CI 已上线（`.github/workflows/ci.yml`，与本地同一套） | 本地与 CI 门禁一致（2026-09-01 起）；~~fuzz/perf regression 仍缺~~ **第一百二十八轮已收口**（确定性结构感知 fuzz 四面+计数制性能回归两裁判，全部入常规门禁） |

### 1bis.1 阻塞点（三件事卡在同一道门上）

~~`RFC-0007` 冻结的 `StorageBackend` 签名不带 `Ctx`，于是这三件都动不了~~ **已决策并落地第 1 步**：
`ADR-039`（第三十三轮）把调用方 Context 送进 store 接缝——23 个方法签名全链带 `ctx`、
`FsStore` 的伪造身份删除、`StorageErrorKind::Cancelled` 取消门落在内容半、端口归属真实化有裁判。
剩下的按其 §4 阶段表走，**四步已全部落地**：

1. 打断一次已经开始的 store 调用 → 第 1 步已给接缝（取消门先落内容半；第三十四轮把取消随
   drive 恒挂、`Cancelled→Cancelled` 映射有裁判）；
2. 按调用方累计 store 预算 → 第 2 步（`ctx.io_budget` 在 fs-store/memory 计费，第三十四轮）；
3. 给 store 接缝一个真正的等待时限 → 第 3 步（第三十五轮：期限由持时钟方判、轮询间读钟即可，
   `ADR-013` 有界池这个继承来的前提经实证**不必要**，见 ADR-039 §8）；
4. daemon 门面把调用方 ctx 送到端口 → 第 4 步（第三十六轮：查询路径 `caller_ctx` 三规则、
   引擎三方法的幽灵 ctx 移除、端到端裁判在 `facade_store_ctx.rs`）。

### 1bis.3 需要决策而非代码的缺口（第三十八轮登记；本节是登记处，已决项标注去向）

- ~~**Capability registry 的来源方向**（`IMPLEMENTATION_STATUS §8.3`：从文件加载 vs 文件仅由代码生成）~~
  **已决策**：`ADR-051`（第六十八轮）收口为后者——JSON 工件是导出物（生成器重写 + drift 门禁
  保证 == Rust 文档），生产 `src/` 不得从工件读取（arch-test 裁判），「文件加载失败/离线语义」
  无运行时面；未来引入运行时加载须按 `ADR-051 §2.4` 另立 ADR。
- ~~**`FsStore::sanitize` 非单射，对象名可撞文件**~~ **已决策并落地**：`ADR-041`（第三十九轮）
  选单射百分转义 + boot 名↔记录校验（被否决：put 拒撞名——修不了别名读；入口拒特殊字符——
  `mihomo:*` 命名惯例是更大契约）。测量细节与四个后果（静默互覆/别名命中/两后端分歧/重启
  不定）见其 §1。anchor 读侧校验（第三十八轮）不涉此题：content anchor 由 store 自算自校，
  对象 digest 才是调用方名字。

### 1bis.2 一句话完成度

> 中心主链（Phase 2–5.5 + 10 的门禁面）已经可交付给下一个实现者：契约有类型、执行有门禁、崩溃现场可读、诊断有界，source ingest 也已完成显式 endpoint→HTTP→parse→RawSource CAS→normalized cache 的真实 slice。
> durable source index/provenance 已把 locator、条件请求、raw CAS、normalized cache、parser provenance 与 diagnostics 接到跨重启事实；caller phase-boundary deadline/cancellation 与 redacted source inspection projection 也已接入。当前最高优先转为 blocking/runtime 边界、真实 effect runtime 跨进程/平台安全面与 typed send_request_frame 的取舍重估（共享 timeout scheduler 已于第一百二十二轮收口）。BindSpec/WireIo 已由第八十七轮接入。外围仍包括 Platform/TUN、TUI 与 CI/fuzz/performance（capability 文件加载已由 `ADR-051` 决策为导出物方向，运行时加载不再是目标）。

---

## 2. 已完成的阶段修正

### 2.1 Phase 1 — 工程边界落地

已完成：

- workspace 与 crate 结构建立
- 基本 arch guardrails / clippy 约束建立
- 代码组织已达到可持续迭代的基本形态

因此，Phase 1 不再应视为 `Partial`。

### 2.2 Phase 2.5 — 编译打通与契约收敛

这一阶段现在已经真实完成：

- Rust toolchain 已安装
- `cargo check --workspace` 已跑通
- 多个 crate 间的依赖/导出/类型裂缝已被修补
- 后续推进已可建立在真实编译反馈之上

这一步虽然不是“产品功能”，但它非常关键，因为它把 Caly 从“静态骨架堆积”推进到了“动态可检验骨架”。

---

## 3. Phase 2 — 源码级契约落地

### 当前进展

已完成：

- `caly-common`
- `caly-api` 基础 DTO / Error / Facet / Operation
- `caly-plan` 中 `ApplyPlan` / `EffectPlan`
- `caly-io` 基础 Port / Fault / VPath
- `caly-cap` registry / loader 骨架
- `caly-ipc` frame / handshake / stream / dispatch / codec / client / session primitive
- `caly-cli` exit code / follow / driver / contract_driver 基础骨架

仍需补齐：

- DTO 真正迁移出 `operation.rs`
- DTO 分面之间重复 re-export 与旧定义并存问题
- `caly-api` 对外导出面继续收敛
- 更严格的 schema / validation 层

---

## 4. Phase 3 — 基础设施骨架

### 当前进展

已完成：

- `caly-storage` 基本数据类型、store trait 与 in-memory backend 骨架
- `caly-io-sim` 的世界模型、fault injector、首批 Port impl 与 scenario builder
- workspace 编译已覆盖这些 crate

仍需补齐：

- source blocking syscall 中断/资源回收语义的明确决策与新 transport 下的验证；当前 phase-boundary caller deadline/cancellation、inspection read model 与坏记录参数化证伪已接入；
- ~~storage schema migration~~（记录级 tag 演进+读时迁移已由 ADR-061 收口；布局层门禁与迁移链早已具备）、~~`stat_many`~~（R74）与孤儿内容（已收口）已划走，余性能收口；
- 更丰富的 step-aware scenario 与故障回放；
- Platform/TUN/helper 与安全边界（SSRF、keyring、UDS 权限、导入限额）。

已不再列为缺口：`FsStore`、`Fs::list`/mtime、GC production path、`StdHttp` 与 `StdProc`；这些均有实现与对应断言。

---

## 5. Phase 4 — 控制链与 daemon 骨架

### 当前进展

已完成：

- `caly-engine` 的 Command / Queue / Job / Idempotency / Event / Worker 基本骨架
- `caly-daemon` 的 lifecycle / session / transport / registry / runtime / harness 基本骨架
- `caly-app` 的 local/remote/parity/contract/scenario 基本装配

仍需补齐：

- typed send_request_frame 与完整 production session（读写泵第八十七轮接入；共享 timeout scheduler 第一百二十二轮收口）；
- overload/backpressure 的剩余生产者与安全/平台错误面。

apply command path、engine/storage durable wiring、worker consume 与 recovery 已有生产接线，不再重复施工。

---

## 6. Phase 5 — 核心主链纵向切片

### 当前进展

这是当前最应该继续投入的主线。

已完成或已有真实 slice：

- `caly-domain` 可表达 `Profile / Override / SelectionMemory`；
- `caly-pipeline::parse_source` 已 decode/normalize 支持的 source envelope，并产出有界 diagnostics/provenance；
- endpoint registry、`StdHttp`/`SimHttp`、有界 body、RawSource CAS、normalized cache 与 apply planning 已接线；
- merge/resolve/semantic/capability validation、native artifacts、`ApplyPlan`/typed `EffectPlan` 已进入中心主链。

### 当前阶段完成定义

原始四条的实测状态：

1. 真实 source parse / normalize —— **已达成 partial slice**（URI/base64 envelope、RawSource CAS、normalized cache、parser provenance）；durable source index 的 locator/validators/raw CAS/normalized/provenance/diagnostics 跨重启恢复已达成；
2. registry 驱动的 capability validation —— **已达成**（JSON 工件漂移已有门禁；执行来源 = 代码文档，`ADR-051` 已把「从 JSON 加载」钉为非方向）；
3. apply executor 与 snapshot/journal 的连接 —— **已达成**；
4. daemon command path 触发真实 apply workflow —— **已达成**，并已有 `calyd`/`caly` binary E2E。

因此 Phase 5 继续记 `Partial`：中心线已能执行并验证，source durable facts、phase-boundary caller control 与 inspection projection 已闭合，但 blocking runtime、完整真实 runtime/platform 仍缺。

---

## 7. Phase 6 — Daemon / IPC / CLI 连接

### 当前进展

与之前相比，这一阶段已经不应继续标成 `Planned`。

已完成或已有真实 slice：

- `LocalFacade` / `RemoteFacade`、loopback、parity/contract/scenario 已被测试判定；
- request → command → apply workflow、job lifecycle、follow/rollback/gc/support-bundle 与 `calyd` wire 已接入；
- `calyd`/`caly` binary、v0 TCP record/JSON payload、worker thread、reconnect/ack 与 CLI 核心动词已有 E2E。

### 仍需补齐

- `caly-ipc` typed send_request_frame 与 SessionRegistry 生产化（BindSpec/WireIo/FramePump 第八十七轮、共享 timeout scheduler 第一百二十二轮收口；第八十九轮 CLI 整段会话——请求/ack/流帧——都经同一泵收发，read+write 均有界，生产路径不再裸调 codec）；
- ~~stream payload 的逐帧生产语义与更完整的 backpressure producer~~ **第一百二十七轮已收口**（SnapshotThenPatch：dashboard/connections 快照首帧=同一查询重述、事件桥每拉 64 帧有界、慢客户落后保留窗点名 Reset；Traffic/Logs 专有语义待真实数据源，登记）；
- CLI/TUI 的发布级 UX，而不是中心 command path 本身。

---

## 8. Phase 7 — 双 Core 纵向切片

### 当前进展

已从 `Planned` 提升到 `Partial`。

当前已有：

- `caly-mihomo`
  - YAML-shaped native artifact
  - native validation
  - apply planning
  - vertical slice helper
- `caly-singbox`
  - JSON-shaped native artifact
  - native validation
  - apply planning
  - vertical slice helper

### 仍需补齐

- 更真实的 capability matrix 差异与 JSON registry 的**导出物**语义（`ADR-051`）：矩阵差异本身仍可做，但「文件加载」已不是待办；
- 原生 artifact byte golden、版本覆盖与完整 runtime API/telemetry；
- multi-core 生产默认、资产升级/回滚策略与 Platform 权限边界。

mihomo/sing-box 的 binary inspection、spawn/probe/stop/rollback 真核 slice 已有，不再写成“未做”。

---

## 9. Phase 8 — Platform / Recovery

### 目标

把平台副作用正式纳入部署事务。

### 当前进展与剩余范围

`EffectPlan` 已被 executor 解释，`FsStore`/journal/snapshot/recovery 已有落盘闭环；真实 mihomo/sing-box effect adapter、Direct/ActiveCore/SystemProxy 的已有 slice 也可由组合根显式注入。

仍未完成：`Platform`/TUN/helper、完整 OS 网络副作用、keyring/SSRF/UDS 权限等安全平台面，以及把真实 effect runtime 作为 `calyd` 的明确默认配置。
---

## 10. Phase 9 — TUI / Runtime UX

### 目标

提供真正可交互的管理体验，但不破坏控制面边界。

### 约束

在 Phase 5 / 6 / 8 未进一步闭环前，不应让 TUI 反向驱动架构偏航。

---

## 11. Phase 10 — 硬化与发布门禁

### 目标

把“能编译、能演示”提升为“可发布、可维护、可回归”。

### 关键门禁

- 真 core fixture 与 native validation fixture：mihomo/sing-box 资产、spawn、controller probe、stop/rollback 已有真核裁判；
- contract/regression suite、overload/backpressure coverage；
- support bundle / doctor / secret redaction：`RFC-0010 §14` 第 1/2/3 条已有断言；第 4–8 条（UDS 权限、helper 输入、SSRF、下载校验、导入限额）仍待平台层决策；
- ~~fuzz、CI、性能回归~~已收口（CI 2026-09-01 上线；fuzz/性能回归第一百二十八轮入常规门禁）；artifact golden 加强（R67 已有产物字节 golden，「完整内核 runtime API」连带项属平台轮）。

---

## 12. 推荐最小里程碑（当前顺序）

1. ~~source blocking syscall 的中断/回收边界~~ **已收口**（ADR-052（R72）边界化 connect/read/write；第一百二十九轮补上最后一个无界调用 getaddrinfo——单例有界解析线程、队头阻塞如实、死预算零进入、同线程回收，ADR-052 增补 §7）；坏记录/跨重启参数化证伪扩展为逐轮惯例；
2. ~~维护 durable source index 的 schema 演进与 migration 语义~~ **第一百二十六轮已收口**（ADR-061：v2 tag 携带 pipeline epoch（锚覆盖内）、v1≡epoch 1 读时迁移不重写、未知 tag 按名拒启、陈旧降级不砖死——原子提交/CAS root/locator 失效全保持）；
3. ~~补跨进程 core adoption/ownership~~ **第一百二十五轮已收口**（ADR-060：durable core receipt、pid+start_time 身份三要素、接管/按名拒绝/冷收敛、bin 内 pidfd foreign stop；默认 simulated 不变）；其上再做 Platform/TUN/helper 与多 live label；
4. ~~typed send_request_frame 取舍重估、stream payload 逐帧生产语义与剩余 backpressure producer~~ **第一百三十轮已收口**——typed `send_request_frame` 重估定案为**显式不做**（R123：单一 typed 编码表 `wire_ops::wire_request` 已是生产路径，接 typed 循环是第二条对话路径，门禁 `the_cli_speaks_the_one_typed_request_table` 钉单一表）；逐帧生产语义=Deployment 流生产者落地（`RuntimeSubscription::Deployment` 开流走真请求路径、watch bridge 按 kind 只铸 DeploymentChanged 帧、seq/恢复/Reset 沿共享事件窗）、Traffic/Logs 仍待真实数据源（已声明顺延）；backpressure producer=`EventBacklog`（engine 在 `events_since` 观察到窗滚动即记账）与 `StreamBackpressure`（watch/job bridge 铸 Reset 处记账）双双有生产者，doctor/support bundle 经 `overload_lines` 可见；
5. ~~capability registry 从 JSON 文件加载或正式声明 JSON 仅为导出物，并补加载失败/离线语义~~ **第六十八轮已决策（ADR-051）**：JSON 工件是导出物（生成器重写+`registry_drift.rs` 门禁保证==Rust 文档），生产 `src/` 禁止从工件读取（arch-test `the_registry_artifacts_are_exports_not_runtime_inputs`）；「加载失败/离线」无运行时面（无生产加载器即无该失败面），未来引入须按 ADR-051 §2.4 另立 ADR；
6. Platform/TUN/helper、keyring/SSRF/UDS 权限/导入限额与 storage schema/performance（设计前置文档已立：`docs/engineering/PLATFORM_FACE_PLAN.md`，R131——含子项排序与所需 ADR 清单）；
7. ~~CI、fuzz、性能回归~~（CI 2026-09-01；fuzz/性能回归第一百二十八轮）已收口，余 artifact golden 加强，最后再推进 TUI（设计前置文档已立：`docs/engineering/TUI_READINESS_PLAN.md`，R131——P1 watch 上 wire→P4 golden→P2 多路复用→P3 数据源→P5 TUI 本体）。

---

## 13. 当前最优动作

基于 `docs/status/IMPLEMENTATION_STATUS.md §7` 与 2026-08-30 实测，下一轮应按以下顺序行动：

1. **source 边界与 inspection 的剩余硬化**：保持 HTTP→parser→CAS→D3 的统一 phase-boundary caller control；~~若引入可挂起 transport，先定义 blocking syscall 的中断/回收语义~~ **第七十二轮已收口**：`ADR-052` 提前定义了该语义（不依赖具体 transport），裁判为 `http_contract` 两个对端挂起测试（有界回收 + 不可中断诚实性），`falsify_round72.py` 2 变异全咬——引入 UDS/双工 transport 时直接沿用 §2 语义；沿现有 durable projection 扩展各损坏形态的参数化拒启证伪（记录层第六十五轮收口、**第七十五轮补面**：`raw_object_digest` 锚格式校验缺口（原来只查非空，而该字段是寻址锚）+ 三个 cache digest 的畸形值按名诊断（原来经内容锚比较间接拒绝、误报 mismatch），`IMPLEMENTATION_STATUS §8.4` 首条；残余为随新字段扩展的维护动作）；
2. **真实 runtime 的生产组合根**：~~在不改变默认 simulated 事实的前提下，决定真实 effect runtime 的显式配置和权限~~ **已实现**：`calyd --effect-runtime real` + `--runtime-root`/`--assets-dir` 显式配对（其余组合为命名拒绝），启动前置写探针 + 资产可读校验；默认仍 simulated；二元级 E2E `calyd_wire::real_effect_runtime_preflight_refuses_missing_assets_before_listening`；
3. **通用 transport runtime**：补 `caly-ipc` UDS/双工调度、timeout/reconnect 的统一生产实现与 stream 逐帧裁判；**第七十一轮已量选并收口其前置**——量选确认生产缺口确为传输运行时（`calyd.rs` 手写 TCP 帧循环、`caly-cli` 手写 Session/hello/ask/follow_stream 均未用 ClientLoop），本轮先把 v0 wire 记录方言收敛到 `caly_ipc::dialect` 并让 CLI 校验 hello_ack 内容（字节不变；详见 `IMPLEMENTATION_STATUS §8.7`）；**第八十五轮收口生产 CLI 入站**：`Session::recv` 改走共享 `wire_read_frame`（入站 cap 在读 payload 之前拒绝；`timed_out` 映射保 exit 11），**第八十七轮收口 BindSpec/WireIo/FramePump/HandshakeDrive**：生产 calyd/caly 共用同一套 bind/connect/pump，UDS 接入（port-file 写 unix: 前缀，TCP 仍裸 u16），drive_client_hello 只走 hello（validate 先于 observe，不接 send_request_frame）。**第八十九轮收口 CLI 全会话走泵**：`Session` 持 `FramePump<WireStream>`，请求/ack/流帧与握手共用同一有界 read+write transport（关闭 R44 挂死面的写半：此前会话帧只设 read 超时、无 write 超时），门禁 `the_cli_drives_every_frame_through_the_shared_pump` 禁生产 caly-cli 裸调 codec（falsify 2 变异全咬）；**第九十轮收口 daemon 服务端对位**：`set_transport_deadlines` 同点设 read+write（accept 用 HELLO_TIMEOUT、hello 后提升 session_idle），不读对端不再无限挂住写线程，进程内 `UnixStream::pair` 确定性机制裁判 + 结构门禁（falsify 3 变异全咬）；**第九十一轮收口客户端 follow 流期限**：follow 的 Job 流是 lossless-resumable 流而非请求-应答（daemon 流泵 `Wait` 不发帧、真核 spawn/probe 可数十秒无声），opened 帧后经 `FramePump::set_idle(STREAM_IDLE_TIMEOUT=30s)` 双向加宽（hello/请求阶段仍 3s，静默 daemon 仍 exit 11）；同时修一处更深根因——`FramePump::recv` 的 TCP `peek` 曾用调用方整段读期限、超时被映成 Alive 吞掉，使静默对端在 peek 与 read_exact 各等一遍（有效静默预算翻倍、加宽对短间隙失效），现探活收窄到 50ms 短窗口后恢复调用方读期限（对齐 daemon 流泵），裁判=4s 静默间隙 e2e + MemoryIo 期限调用序列单测 + 结构门禁（falsify 3 变异全咬）。残余（2026-09-02 重估）：~~共享 timeout scheduler~~（R122 收口）、~~typed send_request_frame~~（R123 重估定案显式不做）、~~UDS peek~~（R123 收口，ADR-059）、SessionRegistry 生产化（已否决，仅 harness 用是设计）、RFC-0010 §14 整条；留 v1：一条连接上并发交错多流（现为一连接一泵串行复用，RFC-0002 多路复用形状）；
4. **能力来源与安全平台**：JSON registry 的输入/导出身份已由 `ADR-051` 收口；~~SSRF~~ **第七十三轮已收口**（`ADR-053`：连接后 peer 校验 + `FetchScope` 保守默认/显式放行 + ActiveCore 豁免，裁判 3 条 + falsify 2 变异全咬，`IMPLEMENTATION_STATUS §8.8`）；剩余 Platform/TUN/helper、keyring、UDS 权限（随 transport runtime 落地）与导入限额；
5. **schema/performance/release**：storage migration（第一百二十六轮收口）、~~`stat_many`~~（第七十四轮收口）、artifact golden（R67 产物字节 golden 已有，加强与内核 runtime API 同轮）、~~CI/fuzz/performance~~（CI 2026-09-01 上线；fuzz/计数制性能回归第一百二十八轮入常规门禁）。

已不再是下一步事项：真实 source parse/decode/normalize、durable source index 的基础记录/恢复/304/GC root、source inspection bounded projection/redaction、HTTP caller phase-boundary control、FsStore/GC production wiring、StdHttp/StdProc、effect executor/apply/recovery 闭环、CLI/calyd binary target、以及 role/idempotency/CAS/读侧有界性。

---

## 14. 一句话原则

> Caly 的路线图不应再围绕外围接口数量扩张，而应围绕中心主链是否继续闭合来排序。