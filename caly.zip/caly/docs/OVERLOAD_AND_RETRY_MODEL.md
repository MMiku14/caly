# Caly Overload and Retry Model

本文件说明当 Caly 遇到：

- queue full
- event backlog
- stream backpressure
- frame too large
- storage busy
- temporary transport pressure
- apply execution resource contention

时，应如何把这些问题表达为**统一可解释的系统状态、协议语义与用户错误**。

---

## 1. 为什么 overload 不能只当内部异常

如果 overload/backpressure 只作为内部日志存在，会出现问题：

- CLI 不知道该不该重试
- Remote client 不知道是配置错了还是系统忙
- session/stream 层会出现模糊失败
- apply job 可能在资源压力下表现为“像配置坏了”

因此，队列满、短时不可用、回放窗口失效、存储繁忙，必须进入公开错误语义和/或事件语义。

---

## 2. 当前代码里已经存在的基础

当前代码已开始出现：

- `QueuePolicy { max_len }`
- bounded event log
- `SubmitRejected`
- `OverloadClass`
  - `QueueFull`
  - `EventBacklog`
  - `StreamBackpressure`
  - `StorageBusy`
- `RetryHint`
  - `RetryImmediately`
  - `RetryLater`
  - `ReopenSession`
  - `ManualIntervention`
- `OverloadReport::to_api_error(...)`
- daemon `submit_request_as_command(...)` 中的 overload -> `ApiError` 映射

这说明 overload 已开始被当作一等系统行为，而不再只是偶发异常。

> **本节的两处断言在第十三轮被核对过**（`docs/ONBOARDING_NOTES.md §4.59`）。原文把上面两条并列成"已经存在
> 的基础"，实际情况是：`to_api_error` **没有任何调用者**，线上走的是 daemon 自己那份更薄的映射，它只保留
> code / category / retryable / summary —— 也就是下面 `§8` 明确禁止的形状。现在两者合成一个：daemon 的
> `error_map::map_overload_report` 直接转发 `OverloadReport::to_api_error`，`retry_hint` 的文案由
> `RetryHint::remediation()` 单点提供。

---

## 2bis. 历史状态（2026-08-27，第十三轮；保留作演进证据）

> 本节记录第十三轮当时的状态。后续轮次已接入 `StdHttp`/`StdProc`、真实 v0 TCP slice、worker/reconnect/ack、bounded response 与 source ingest；不要把本节的旧“无 bin”结论当作当前状态。

| 本文件的要求 | 落点 | 判定 |
|---|---|---|
| `§3.1` `QueueFull`（以及第二十轮的 `§3.4` `StorageBusy`，走同一个入队前位置）：尚未进入执行态、返回 retryable + `RetryLater`、不产生 apply side effect | `caly-engine::processor::submit_command` 在任何改写**之前**判容量；拒绝经 `rejected_for_full_queue` 统一记录 | `processor::tests::a_refusal_for_a_full_queue_advances_nothing…`、`crates/caly-daemon/tests/overload.rs`（4 条，含"拒绝不得把合法 `expected_revision` 变成 `CONFLICT`"与两条 daemon 的差分对照） |
| `§5.2` Command 路径的表达应是 `ApiError` + `retryable` + `retry hint`，不得伪装成 `Accepted` | 唯一的 `to_api_error`：`UNAVAILABLE` + 按类别定的 category + `detail` 内 `error=<class>` / `retry_hint=<Hint>` / `queue_len` / `queue_cap` / `at_generation` | `the_public_error_names_the_class_the_hint_and_the_numbers`、`scenario_suite` 的 `overload.refusal-says-what-to-do` |
| `§7.1` public error 出口 | 同上 | 同上 |
| `§7.2` internal event 出口（backlog 长度、queue cap、发生位置） | `EngineState::overloads`（有界 8 条）+ `overload_totals`（完整计数）→ `overload_lines()` 一份文本，`doctor` 与 bundle 的 `overload` 段共用 | `ten_refusals_are_ten_occurrences_even_though_the_log_keeps_eight`（十次拒绝必须报十次）、`refusals_are_reported_in_the_bundle_and_their_absence_is_stated_too`、`doctor_reports_the_pressure_the_caller_was_already_told_about`、`overload.visible-in-doctor-over-the-transport` |
| `§8` 禁止"只返回一条 `Unavailable`，不给任何细分线索" | 由 `detail` + `diagnostics[code]` 满足 | 上面三条错误身份断言 |
| `§9` CLI/TUI 最低要求 | 数据已在 `ApiError` 里；`caly-cli` 已有 `caly` binary，CLI/wire 能表达公开拒绝；TUI 仍未创建 | CLI 基础表达已覆盖，TUI 与发布级 UX 仍未覆盖 |

`§3.2` `EventBacklog` 与 `§3.3` `StreamBackpressure`：**分类与映射齐备，生产者仍缺失**。
本轮刻意不给它们造触发点——没有真实争用模型而硬编一个"看起来像过载"的错误，会把 `§8` 要求的区分重新
糊在一起。这两类连同 `§6.1` / `§6.3` 的剩余部分留在 `docs/IMPLEMENTATION_STATUS.md §3.3` 的未覆盖清单里；
**`§6.2` 已于第二十七轮落地**（见下面那一节的落地记录）。

> **第二十轮更新 —— `§3.4` `StorageBusy` 有了第一个生产者，但要看清它是哪一个。**
> `system.gc-collect` 在引擎尚有在飞工作时于**入队之前**被拒：`UNAVAILABLE` + `retryable=true` +
> `detail` 内 `error=storage_busy retry_hint=RetryLater at_generation=…`，同时进入 `§7.2` 的两个出口
> （有界日志与按类别计数）。选它作第一个生产者，是因为这份争用**不需要编**：「有别的命令在跑」由引擎自己的
> 状态回答，而被拒的一方什么也没失去（重试即可）。
> 它**不是** `§6.2` 那个争用（cutover 期间对同一份存储的写争用 + recovery-sensitive 升级）。那一句仍然没有
> 落地，写在这里是为了不让人因为类别同名而把 `§6` 读成已完成。
> 判定：`crates/caly-daemon/tests/gc_collect.rs::a_busy_engine_refuses_the_cycle_and_changes_nothing`
> （含"拒绝不得推进 `state_revision`"）与
> `crates/caly-engine/tests/gc_plan_and_clock.rs::an_ineligible_store_state_refuses_the_cycle_at_both_ends`。


## 2ter. 当前实现状态（2026-08-30）

- `QueueFull` 与入队前的 `StorageBusy` 有生产者；cutover journal intent refusal、store port `Busy` 与 apply/recovery 映射也已有生产路径。
- `EventBacklog` / `StreamBackpressure` 的分类与流协议表达已存在，但完整的生产触发、合并/丢帧策略与通用 transport runtime 仍未闭合；不能因为 `StreamPayload::Reset` 存在就声称背压生产者完成。
- 出站 frame 上界、diagnostics 查询的有界响应、`IoBudget` 的次数/单次字节边界均已有执行与断言；`PayloadTooBig` / `BudgetExhausted` 不是 overload 类。
- `caly-cli` 与 `calyd` binary 已存在，CLI/wire 已能表达公开拒绝；source caller deadline/cancellation 现在已覆盖带注入 clock 的同步 HTTP→parser→CAS→D3 phase boundaries，剩余重点是通用 IPC transport、blocking syscall 的中断语义与流侧真实压力模型。

## 3. overload 的公开分类

推荐至少固定以下公开语义：

### 3.1 `QueueFull`

表示：

- daemon/engine 当前命令队列已达到上限
- 请求尚未进入执行态

典型处理：

- 返回 retryable error
- 给出 `RetryLater`
- 不产生 apply side effect

### 3.2 `EventBacklog`

表示：

- 事件窗口已滚动
- 查询/跟随者请求的游标已落在保留区之外

典型处理：

- query 返回 stale / reset-required 语义
- stream 返回 `Reset`
- 用户需重新打开或重新同步

### 3.3 `StreamBackpressure`

表示：

- 客户端消费速度不足
- 无法继续维持预期投递语义

典型处理：

- 对 latest-value stream 可 coalesce
- 对 replayable stream 可 reset
- 对严格有序流可断开并要求 reopen

### 3.4 `StorageBusy`

表示：

- snapshot/journal/object write 所依赖的底层存储当前不可快速获取

典型处理：

- 返回 retryable error
- 禁止把它伪装成配置错误
- 若已进入 cutover 阶段，必须升级为 recovery-sensitive 失败路径

> **第二十八轮：这一类现在有了第二个生产者，而且是"底层真的忙"那一个。**
> 以前 `StorageBusy` 只有两种来源：入队前的准入拒绝（第二十轮），与 cutover 窗口里游标写不下去（第二十七轮）。
> 现在 `caly-storage` 的驱动层也会给出它 —— 一个端口在 `STORE_PORT_POLL_BUDGET` 次 poll 内没有就绪，
> 就按 `StorageErrorKind::Busy` 报上来（第二十八轮之前是 `Internal`，也就是**这一类本该有、却被上一层抹掉**的状态）。
> 关键差别不是文案而是类型：`StoreRefusal::from_storage_error` 认 `Busy` 并升级成 `RefusalKind::StorageBusy`，
> 于是 `§7.2` 的运维账本看得见的这一次是真的一次"存储忙"。裁判：
> `crates/caly-engine/tests/store_suspension_is_contention.rs`（2 条：慢盘必须跑完整条 apply、卡盘必须以 contention 报出）
> 与 `crates/caly-storage/tests/store_port_budget.rs`（6 条，含"不得报 `Internal`"那条反向断言）。
> 本节第二条（"禁止伪装成配置错误"）在本轮之后仍然只在**入队前**那一支被机械检查；盘忙走的是 `STORAGE` + `Io`，
> 与 `CONFIG_INVALID` 分得开，见 `ADR-036 §6bis-octies` 的那张共用表。

### 3.5 `FrameTooLarge`

表示：

- 请求或响应超过协议允许大小

典型处理：

- 立即拒绝
- 指向协议/客户端行为问题，而非系统忙
- 通常不建议自动重试相同输入

### 3.6 `ProtocolPressure`

表示：

- hello/session/frame 校验失败或 transport runtime 资源受限

典型处理：

- 区分：协议不匹配、会话失效、暂时拥塞
- 只有暂时拥塞可提示重试；协议不匹配应直接失败

### 3.7 `IoBudget` 耗尽**不是** overload 类（第二十四轮的判断）

`ADR-036 §2.4` 落地之后，一个命令的 `Ctx::io_budget.max_requests` 花光会真的拒掉下一步 store 访问。
它**不**进上面任何一类：

- `§3.1`–`§3.6` 说的是**系统侧**压力（队列、事件窗口、流背压、存储忙），提示重试的前提是"换个时机就好"
- 预算耗尽是**调用方自己划的界限**：同一个请求换时机再来一次，仍然会花光同一个数
- 所以公开面是 `CONFIG_INVALID` / `ErrorCategory::User` / `retryable=false`（`docs/ERRORS.md §5.1`），
  remediation 指向那个字段本身；`OverloadClass` 不新增变体，`RetryHint` 也不为它发明一档

公开码表里没有 `CAPACITY_EXCEEDED` 是同一件事的另一半：`RFC-0002 §14.4` 冻结了稳定码表，加码是 RFC 级
决定。端口层的 `IoFaultKind::CapacityExceeded`（`RFC-0006 §5.3` 要求的回答形状）与 API 层之间因此有**有意
的落差**，两边各自可解释，比强行造一个共享的假对称好。

> **第二十九轮补一行**：那个落差现在有了第二个入口，处理方式一致。端口按 `§5.3` 拒掉的载荷会上到存储层成
> `StorageErrorKind::CapacityExceeded`，引擎把它认成 `RefusalKind::PayloadTooBig` —— 仍然 `CONFIG_INVALID` +
> `ErrorCategory::User` + `retryable=false`，仍然不进 `OverloadClass`（"你自己设的界限"不是系统压力）。
> 它与 `BudgetExhausted` 是两个 kind 而不是一个，因为**旋钮不同**：一个数这次命令里的访问次数，一个数单次
> 载荷的字节；把它们合成一格，remediation 就会对一半的调用方说错话（"拆成更小的操作"对超限的单次写没用）。
> 裁判：`run_limits::tests::a_capacity_refusal_is_the_callers_and_a_busy_store_is_the_operators`。

---

## 4. RetryHint 的真正语义

`RetryHint` 不应只是 UI 文案，而应是行为建议。

### 4.1 `RetryImmediately`

仅适用于：

- 明确尚未产生副作用
- 且失败高度可能是瞬时争用

不适用于：

- 已触发 apply cutover
- 已触发 stream reset
- 已知协议不兼容

### 4.2 `RetryLater`

适用于：

- queue full
- 短时 storage busy
- daemon 正在 drain backlog

### 4.3 `ReopenSession`

适用于：

- stream cursor 已失效
- session 被服务端关闭
- hello 生命周期需要重新协商

### 4.4 `ManualIntervention`

适用于：

- recovery failed
- 持续 storage integrity 问题
- capability/blocking policy 冲突
- repeated overload 但无法自动收敛

---

## 5. Query / Command / Stream 三类路径中的 overload 表达

### 5.1 Query

Query 路径中的 overload 典型包括：

- stale cursor
- snapshot not retained
- temporary storage busy

表达方式应偏向：

- 结构化错误
- reset-required view field
- 明确 remediation

> **第三十轮落地记录 —— 落的是"答案有界"，不是"查询会拒绝"**。上面三条要求的是：查询在压力下仍然给出
> 结构化、可行动的回答。本轮补的是最容易失控的一条：`diagnostics.doctor` 与 `diagnostics.recovery-status`
> 的列表由 **store 的规模**决定（每条 finding 一行、每个未决事务一条决策），既不分页也不流式，而
> `caly-ipc` 只在**入站**方向检查 `MAX_FRAME_SIZE_BYTES`，`encode_raw_json` 什么尺寸都肯造 ——
> 于是一次合法查询可以造出一个对端拒绝接收的帧：运维在部署坏掉的那一刻失去诊断，收到的还是传输错误而不是
> API 错误。现在两条查询各带上界（`caly-daemon/src/paging.rs::DiagnosticBudget`），并且**截断写进答案本身**
> （`truncated` + `omitted_*` + 落在被截那一层里的说明行；未截断的答案不许携带那句话）。
> 上面"典型"里的另两条（stale cursor、snapshot not retained）仍是视图字段层面的事，本轮没动，也没划掉。
>
> **第四十轮关账 —— 两条均已落地并补上裁判**：stale cursor 的 `reset_required` 视图字段在
> `caly-engine/src/job_follow.rs` 的单测里有正反两面的裁判（过期游标 ⇒ 空窗口 + 从
> `retained_from_index` 重开，而不是"假装空列表"；窗口内游标照常续读）；snapshot not retained
> 的表达在 `crates/caly-daemon/tests/facade_store_ctx.rs`：失 digest 的 bundle 读回结构化拒绝
> （`Conflict`/`User`/不可重试），remediation 点名两条出路（job 自己的日志行、重新提交
> `DiagnosticsOp::SupportBundle`）与诚实的消失原因（unreferenced、gc may collect）——此前这段
> 文本没有任何测试读过它。§5.1 至此没有未落项。

### 5.2 Command

Command 路径中的 overload 典型包括：

- queue full
- executor busy
- storage busy before prepare begins

表达方式应偏向：

- `ApiError`
- `retryable=true/false`
- `retry hint`
- 不应伪装成 Accepted Job


> **第四十一轮关账 —— 表达要求已全部有裁判**：queue full 的拒绝带 `retryable=true`、
> `retry_hint=RetryLater`、类别（`error=queue_full`）与背后的数字，且不把合法
> `expected_revision` 变成 `CONFLICT`、拒完队列不多不少、`doctor` 一行按类别汇总
> （`crates/caly-daemon/tests/overload.rs`）；"storage busy before prepare" 的形状是 store
> 暂停 ⇒ `Busy` 类型而非 `Internal`（`store_suspension_is_contention.rs`），且入队前的
> CAS 拒绝不留下 job。同轮补上出站那一半：`encode_raw_json_bounded` 让超
> `MAX_FRAME_SIZE_BYTES` 的**响应**在成为帧之前被拒（此前只有入站检查——一个超界答案是
> 服务器 bug，交给对端拒收是把传输错误冒充 API 答案），裁判在
> `caly-ipc/tests/session_and_frames.rs` 与 `caly-daemon/tests/outbound_frame_bound.rs`。

### 5.3 Stream

Stream 路径中的 overload 典型包括：

- replay gap
- backpressure
- session drift

表达方式应偏向：

- `Reset`
- server close reason
- reopen requirement

---


> **历史注记（第四十一轮；当前部分已被后续轮次覆盖）**：§5.3 的三件事（replay gap / backpressure / session
> drift）里，传输层的表达已就绪。后续已接入 `jobs.follow-stream`、worker、reconnect/resume 与 ack；但完整通用 transport runtime、真实背压生产者和逐帧生产语义仍未闭合，见 §2ter。

## 6. apply execution 与 overload 的交叉约束

一旦 apply executor 落地，overload 必须更细化地进入事务模型。

### 6.1 Prepare 前 overload

例如：

- queue full
- storage busy before journal pending

要求：

- 可以安全重试
- 不得污染 active runtime

### 6.2 Cutover 中 overload

例如：

- storage busy while updating journal cursor
- runtime control plane timeout
- privileged helper busy

要求：

- 不得简单提示“稍后再试”就结束
- 必须进入 recovery-aware 失败路径
- job follow 需要看到是 execution failure，不是 validation failure

**第二十七轮落地记录**（判据与断言名同时写在这里，免得这句话再过四轮变成另一句"已落地"的口头说法）。

上面三条要求的**第一条**在今天有了唯一可能的形状：不是"给一个更凶的错误码"，而是**让被拒的那一步不发生**。
`crates/caly-engine/src/executor.rs` 在执行任何 `Cutover` 相步骤之前调用注入的 `EffectCursor::record_intent`，
拒绝即把该步记成 `StepSkip::Gate { reason: "journal-intent-refused" }` 并终止计划 —— 于是"更新游标时存储忙"
这一格从"错误发生在事后"变成"错误发生在事前，且世界没动"。三条要求各自的裁判：

| 要求 | 落地 | 裁判 |
|---|---|---|
| 不得只说"稍后再试" | 存储自己说 `Busy` 时 hint 是 `ManualIntervention`，并同时写进 `doctor` / bundle 读的过载计数（`OverloadReport::journal_pressure`） | `crates/caly-engine/tests/cutover_intent_guard.rs::the_refused_record_shows_up_as_storage_pressure_for_the_operator` |
| recovery-aware 失败路径 | `ApplyFailure::recovery` 逐字引用这条进程**真的写成功**的 journal 记录（phase / cursor / 两个 flag），而 `journal_after_execution` 的 fold 与 `put_apply_journal` 不受拒绝影响（拒绝永远不能阻止记录） | 同文件 `a_journal_that_refuses_the_record_costs_the_world_nothing` |
| 是执行失败，不是验证失败 | code/category 与持久化接缝共用一张表（`STORAGE` + `Io`；仅 `CONFIG_INVALID` 留给调用方自己的预算），job 结算仍区分 `Failed` / `Cancelled` / `TimedOut` | 同文件 `an_expired_deadline_stops_the_window_and_the_job_says_so`、`only_a_busy_journal_counts_as_pressure_on_the_operator` |

剩下的 `privileged helper busy` **没有**落地，也没有被假装落地：本仓库仍没有 Platform/helper 能力。
`runtime control plane timeout` 已有真实 effect adapter 的 probe/deadline 最小面，但不是完整通用 transport/runtime 语义；这两类边界继续保留在当前缺口中。
### 6.3 Verify 后 overload

例如：

- snapshot commit busy
- revision commit contention

要求：

- 若 runtime 已成功切换，则必须优先保证真相提交收敛
- 不允许留下“新 runtime 成功，但 snapshot 未知”的悬空状态

---

> **第四十二轮复核 —— §6 的每一条点名其裁判**：queue full（`overload.rs`：类别/hint/数字，
> 且不把合法 `expected_revision` 变 `CONFLICT`）；storage busy before journal pending 与
> "不得污染 active runtime"（`cutover_intent_guard.rs`：store 拒绝 ⇒ 世界一分未动、被拒步骤
> 不到达 runtime）；storage busy while updating journal cursor（同文件：预算 1 ⇒ 两条接缝共用
> 一个计数器；`store_suspension_is_contention.rs`：`Busy` 是类型不是 `Internal`）；runtime
> control plane timeout（`cutover_intent_guard.rs`：注入时钟让期限落在窗口第二格 ⇒ `TimedOut`
> 且 detail 引用读数）；"可以安全重试"（`overload.rs`：`retryable=true` 只在队列满这一类）；
> "job follow 看到 execution failure 而非 validation failure"（`job_events.rs` 的
> `last_stage`/阶段行判据）。**不划的两条**：privileged helper busy——Platform 属 Phase 8、
> 未开始，无从裁判；"必须进入 recovery-aware 失败路径"——`durable_boot.rs` 已判
> `Recovering` 拒 apply 且 doctor 报告，但完整的 recovery-aware 重试语义还没有独立裁判，
> 留待 Phase 6 传输运行时一并。

## 7. public error 与 internal event 的分层

同一次 overload 可能需要两个出口：

### 7.1 public error

面向：

- CLI
- Remote client
- automation caller

关注：

- 能否重试
- 需要何种动作
- 是否是用户错误

### 7.2 internal event

面向：

- diagnostics
- support bundle
- operator trace

关注：

- backlog 长度
- queue cap
- retained window 起点
- journal cursor 所在阶段

两者都需要，但不能混为一谈。

---

## 8. 推荐的错误映射纪律

### 必须区分

- 配置错误 vs overload
- capability blocked vs temporary busy
- protocol mismatch vs reopen-session
- validation failed vs execution failed vs recovery failed

### 禁止出现

- 只返回一条 `Unavailable`，不给任何细分线索
- 把 queue full 伪装成内部错误
- 把 stream reset 伪装成空结果
- 把 recovery failed 当作普通 apply failed

---

## 9. 对 CLI / TUI 的最低要求

CLI/TUI 至少应能表达：

- 这是不是 overload
- 是否建议重试
- 是立刻重试、稍后重试还是重开 session
- 是否需要人工处理
- 是否可能涉及 apply/recovery 风险

示例语义：

```text
error=queue_full
retryable=true
retry_hint=RetryLater
remediation=wait for current jobs to drain or reduce submit rate
```

```text
error=stream_backpressure
retryable=true
retry_hint=ReopenSession
remediation=reopen watch stream from latest cursor
```

```text
error=recovery_failed
retryable=false
retry_hint=ManualIntervention
remediation=inspect support bundle and last-known-good snapshot state
```

---

## 10. 推荐的下一阶段落地点

1. 为 `EventBacklog` / `StreamBackpressure` 建立真实可复现的生产模型：明确哪些流可合并、哪些必须 gap/reset、哪些必须断开，并让 worker/transport 的压力进入公开事件与错误。
2. 完成 `caly-ipc` 通用 transport runtime（UDS/双工读写泵、timeout scheduler、reconnect）及 stream payload 逐帧生产语义。
3. 维护 source ingest caller deadline/cancellation 的 phase-boundary 断言；若引入可挂起 transport，再为 blocking syscall 中断、资源回收与 HTTP→parser→CAS→D3 竞态补独立裁判。
4. 保持 queue/storage/cutover 的既有 taxonomy，不把调用方 `IoBudget` 耗尽或 `PayloadTooBig` 误归入 overload；同步更新 doctor/support bundle 的压力摘要。

## 11. 一句话结论

> overload 不是神秘失败，而必须被表达成：可分类、可提示、可恢复、可与 apply/recovery 风险区分的公开系统语义。