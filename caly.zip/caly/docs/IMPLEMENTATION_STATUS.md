# Caly Implementation Status

本文件用于跟踪 Caly 从“架构冻结”走向“可编译、可验证、可演进控制平面”的当前实现状态。

**重要说明**：

> 本状态表反映当前 workspace 内可见的真实工程推进情况。它不是发布说明，而是工程盘点、差距列表与下一阶段排序表。
>
> 本版已按 2026-08-27 的**实测结果**重写。重写原因见 `docs/ONBOARDING_NOTES.md §2`：
> 上一版把“已经存在的接线”标成未做（`§2.2`），同时把“已经不存在的告警”列成待清（`§2.1`）。
> 现在每一项都附带可复现命令，结论只在命令支持时才写。

---

## 1. 状态标签

| 状态 | 含义 |
|---|---|
| `Documented` | 规范已写出，但尚未进入代码骨架 |
| `Planned` | 已列入实施顺序，但未开始 |
| `Skeleton` | 目录/接口骨架已建立，但实质逻辑很弱 |
| `In Progress` | 已开始实现，且正在替换 placeholder |
| `Partial` | 已具备部分可验证行为或 partial slice |
| `Done` | 已达到当前阶段的完成定义 |
| `Blocked` | 因上游契约、平台或外部依赖受阻 |

`Done` 的判定自本版起**必须有测试支撑**：只有 `cargo check` 通过最多记 `Partial`。

---

## 2. 当前总体快照

| 维度 | 当前状态 | 说明 |
|---|---|---|
| 架构总纲 RFC | `Done` | RFC-0001 已形成 |
| 子系统 RFC | `Done` | RFC-0002 ~ RFC-0010 已形成第一版 |
| 核心 ADR | `Done` | ADR-011 ~ ADR-034 已落地；ADR-035 / 036 / 037 原为 Proposed，2026-08-28 由维护者授权接续开发方定稿：**037 Accepted 并已落地**，**035 / 036 Accepted 但实现未开始**（各自的定稿偏离见其 §6bis / §2bis） |
| 端口契约 | `Done`（且已被生产代码调用；`system.gc-plan` 的视图带 `now_source`，两侧逐字段相同）；第二十一轮起 `caly_io::runtime::drive` 是能区分 `Timeout` / `Cancelled` / `Busy` 的**唯一**驱动路径，`block_on_ready` 与 `caly-engine::recovery::run_ready` 都是它的包装 | `caly-io::contract` 是**唯一**一份契约实现，两个后端各自跑它：列举有序、`ListCap` 拒绝而非截断、恰好等于上限不算超、"空目录"与"不存在"可区分、对文件 `list` 是 `InvalidInput`、mtime 要么一致已知要么一致未知且不回退 |
| 存储契约 | `Partial` | `caly-storage/tests/object_contract.rs`：同一组断言跑 `InMemoryStorage` 与 `FsStore`，已抓出两处后端各说各话（`ONBOARDING_NOTES §4.46/§4.47`） |
| 术语/风格文档 | `Done` | `GLOSSARY.md` / `STYLEGUIDE.md` 已形成；`CONTINUATION_PLAYBOOK.md`（第三十一轮）记录接续开发的工作流程与门禁清单 |
| 接手审计 | `Done` | `ONBOARDING_NOTES.md`：131 条留档（文档/代码偏差、结构性坑、已修缺陷与自查），且新增一条**自我维护**的门禁：`caly-arch-test::docs` 每次 `cargo test` 扫 `docs/**` 检查表格/编号/引用路径 |
| Facade 契约 | `Partial` | `docs/REMOTE_FACADE_PARITY.md §3bis`：读侧、写侧、错误身份三层都有门禁；`role` 与 `deadline` 的执行待 `ADR-037` |
| Cargo workspace | `Partial` | 20 成员（`cargo metadata` 实测；第三轮加入 `caly-io-std` 后本行一直是旧的 19，本轮修）、**零外部依赖**，`cargo check --workspace --all-targets` 0 warning |
| 源码级契约 | `Partial` | `caly-api` / `caly-plan` / `caly-ipc` / `caly-io` 接口层可编译 |
| 可验证性 | `Partial` | 504 个测试（接手时为 0；数字来自 `cargo test --workspace`，门禁 `TEST_FLOOR=504` 是同一条自报口径，第三十一轮实测）：中心主链、门禁、恢复、回滚审计、IPC 框架层、跨后端 Port 契约、落盘与重启恢复、**contract/parity 判定**、**脱敏边界与导出内容**、**128 行 scenario 套件的判定者**（其中 overload 五行、分页读两行） |
| 过载与拒绝 | `Partial` | `QueueFull` 与 `StorageBusy` 两条完整闭环（后者第二十轮由回收门产生）：拒绝在改状态**之前**判定（不推进 revision、不消耗 job id）、公开错误带 `error=queue_full` + `retry_hint` + 队列数字、同一事件按类别汇总进 `doctor` 与 bundle 的 `overload` 段；`EventBacklog` / `StreamBackpressure` / `StorageBusy` 三类仍**没有生产者**（只有分类与映射），见 `OVERLOAD_AND_RETRY_MODEL §10` |
| 权限与幂等 | `Done` | `ADR-037`（第十四轮定稿并落地）：`required_role` 在两条路径上都可失败（本地与 session 默认都是 `Operator`，更高权限要组装根用 `DaemonApp::set_local_role` 显式声明）；`Idempotency::Required` 缺 key 被拒、空白 key 对任何命令都被拒（它是一个共享桶，不是 key）；`RequestMapError` 带 kind，`PERMISSION` 与 `CONFIG_INVALID` 不再混报；去重窗口只淘汰已完成条目并报告`evictions`；本地 `request_id` 单调分配，`Command.id` 不再是 `req-0` |
| 读侧有界性 | `Done` | `RFC-0002 §9` / `§11.4`：两条大读都有响应上界，且**截断必须被报告**（`SupportBundleView::truncated` / `JobEventsView::next_from_event_index`）。事件窗口读的默认页与上限在 `caly-daemon::paging`，`max_lines: 0` 被 `CONFIG_INVALID` 拒绝而不是被猜成「那就用默认」；导出读的 `max_bytes: 0` 则**照做**（空文本 + `truncated = true`）—— 两者语义不同：「给我 0 行」是自相矛盾的请求，「我只要头部」是可诚实满足的请求 |
| 存储诊断 | `Partial` | `caly-storage::audit` 实现 `STORAGE_RECOVERY §9.2` 四项发现；`doctor` 不再输出占位 warning |
| IO 网关实现 | `Partial` | `caly-io-std` 已建立（`StdFs` 全 9 个方法，含第十五轮补的 `list` + `Meta.mtime`，以及 `StdClock`）；`list` 自第十六轮起有生产调用者（`caly-storage` 的枚举与回退点），`mtime` 仍没有；`Http` / `Proc` / `Platform` 仍缺 |
| IO 仿真层 | `Partial` | `caly-io-sim` 已接为 engine dev-dependency 并有语义测试；`SimFs` 与 `StdFs` 跑同一套共享契约（含新的列举 / mtime 两条），mtime 只来自注入的虚拟时钟；**仍未接生产 Port 路径** |
| 共享上下文模型 | `Partial` | `TraceId` / `Actor` / `RequestContext` / `IoBudget` 跨 crate 贯通 |
| 通信协议分析 | `Done` | framed JSON over UDS / Named Pipe 已文档冻结并下沉代码 |
| App client layer | `Partial` | local/remote facade、loopback、contract/parity/scenario 可编译**且被判定**；parity 改为共享同一个 daemon（此前比的是两个进程） |
| Domain / IR / Core | `Partial` | 已从类型骨架推进到可执行 vertical slice |
| Pipeline / Apply 主链 | `In Progress` | merge/resolve/validate/compile/apply + **effect 执行**已闭合到内存后端 |
| Effect 执行 | `Partial` | `caly-engine::executor` 解释 typed `EffectStep`，含三阶段与 verify 门禁；真后端未接 |
| Storage / Journal / Snapshot | `Partial` | 后端可替换（`Arc<dyn StorageBackend>`），第二后端 `FsStore` 经 `caly-io` Port 落盘、内容寻址、写入即校验；**schema 版本已成为盘上事实**，不匹配/更新版本/损坏一律拒绝启动 |
| CAS 内容 | `Partial` | `CasWriteIntent` 携带载荷，`materialize` 前重算 sha256；`§6.3`"不得静默容忍损坏"可被测试触发 |
| GC（`§13`） | `Partial` | root 集（active/LKG/retained snapshot/revision/未完成 journal/running/grace）+ 计划 + 上限 + 资格门禁；store 侧只提供 `list_objects`/`delete`，不含策略 |
| Recovery | `Partial` | 启动扫描 + 决策 + 回滚补偿可运行；扫描现在同时覆盖 `Pending` 与 `RecoveryFailed`；真接管未接 |
| Capability 校验 | `Partial` | registry/coverage 驱动求值已进流水线；JSON 工件与代码的漂移已有门禁，但执行仍读内建 default |
| RuntimeDriver | `Skeleton` | trait 与 mock 在；真 runtime API 未接 |
| CLI | `Partial` | 逻辑可编译，但**无 `[[bin]]`**，不可 `cargo run` |
| 真实部署与回滚 | `Skeleton` | effect 计划/补偿已执行，journal·snapshot·revision 已能落盘且重启可恢复；GC 策略已落实；spawn core 与 OS 网络副作用仍只到仿真 |

---

## 3. 编译与检查状态

### 3.1 当前结果

```bash
cargo check --workspace --all-targets     # 通过，0 warning
cargo test --workspace                    # 504 passed / 0 failed（门禁另有 TEST_FLOOR=504 下限）
cargo clippy --workspace --all-targets     # 32 处不同位置告警（棘轮基线；接手时为 33）
cargo fmt --all -- --check                 # 1,685 行输出（未门禁，见 §8.6；接手时 7,723）
cargo test --workspace --no-run            # 64 个 test 可执行 + 20 个 doc-test 目标 = 84 个 target
                                           # （口径：数 `Executable unittests` 与 `Executable tests/` 两类行，
                                           #  第三十轮实测 20 + 44 = 64 个可执行；缓存为热的时候 cargo 不重印这些行，要先 touch 一遍 \n                                           #  —— 但 touch 会毁掉「本轮改了哪些文件」的时间戳信号，见 ONBOARDING §4.113）
./scripts/check.sh                         # all gates passed
python3 scripts/regenerate_test_census.py --check   # §3.3 的表是否与树一致（不改文件）
# 门禁各步的原始日志留在 target/gate-logs/（解析失败时靠它复盘，见 ONBOARDING §4.65）
```

规模（`find`/`wc -l` 实测，排除 `target/`）：**219** 个 `.rs` / **62,374** 行 Rust / **504** 个行首 `#[test]`（65 个文件）/ **84** 个 test target（64 个可执行 + 20 个 doc-test；产出它们的命令在上面那个代码块里） / **74** 篇 Markdown，
成员 crate 由 19 增至 **20**（新增 `caly-io-std`）。
`grep -rn "std::fs\|std::process" crates/` 在 `caly-io-std` 之外**没有任何生产代码命中**，
"单一 IO 网关"因此是可检查的事实而不是一句声明。
`executor.rs`（1,386 行，纯解释器）与 `sim_runtime.rs`（689 行，确定性世界模型）已拆分；
`execute_profile_apply` 从 383 行拆成 7 个相位函数（第二十七轮加 `cursor_guard_failure`），其中最大者
83 行（`commit_snapshot`，本轮未动）。口径 = 花括号配对数出的函数长度（含签名行），第二十七轮实测：
`gate_capability` 39 / `report_planning` 17 / `persist_projection` 38 / `execute_effects` 52 /
`commit_snapshot` 83 / `cursor_guard_failure` 54 / `execution_failure` 53。
（`consume_one_skeleton` 仍是那个既有的命令分派大函数：227 行，本轮未改其形状——只在它调用的
`execute_effects` 里加了 guard。）第二十八轮另加一个文件：`crates/caly-storage/src/port_drive.rs`（86 行，
store 驱动端口的预算与那张唯一的 fault→kind 表）；`fs_store.rs` 1,266 行、`schema.rs` 499 行、
`caly-io-sim` 的 `fault.rs` 216 行 / `port_impl.rs` 747 行。

### 3.2 关于 warning 的更正

上一版在此处列举了“DTO 重复 re-export、unused import”等告警。**当前不存在任何编译告警**。

复现时务必先强制全量重编，否则 cargo 会用缓存而不重放告警，容易得出相反结论：

```bash
find . -name '*.rs' -exec touch {} +
cargo check --workspace --all-targets 2>&1 | grep -cE '^(warning|error)'   # 0
```

因此 `API_DTO_MIGRATION_PLAN.md` 中“清 warning”这一动因已消失；该文档剩下的价值是
**收敛 `operation.rs` 的职责边界**，不是消除诊断信息。

### 3.3 测试覆盖的真实分布

按文件实测（**65** 个文件、合计 **504**）。计数口径与被检的断言一致：只数**行首**的 `#[test]`
（`caly_arch_test::docs::count_test_attributes`）—— 讲「测试计数」的测试必须在散文里写出这个记号，
子串匹配会把说明文字一起数进去。复现：

```bash
for f in $(grep -rl '#\[test\]' crates --include='*.rs' | sort); do
  printf '%3d  %s\n' "$(grep -c '^[[:space:]]*#\[test\]' "$f")" "$f"
done                                  # 合计与逐行之和由门禁复算
```

本表由 `scripts/regenerate_test_census.py` 生成（`--check` 只报不改），描述列保留人工内容、只重算数量。
复算裁判是门禁 `crates/caly-arch-test/tests/doc_consistency.rs`，每次 `cargo test` 都跑：
任何一行改了数量而代码没跟着改（或反之、或新增了测试文件忘了加行）都会失败。

| 测试位置 | 数量 | 覆盖的断言 |
|---|---|---|
| `crates/caly-app/tests/budget_parity.rs` | 2 | 补上第二十一轮欠下的那条端到端断言：**预算花光的 `profile.apply` 在两条门面上得到逐字段相同的答案**（state / failure_code / summary / event_count 全等，读的是各自 façade 的 `JobFollowView`，没有任何私有字段被打开）；以及"不写预算"与"明写 64"不可区分 —— 如果 `remote.rs` 那一行不再转发，远端会花掉 daemon 的默认预算、把 apply 跑成成功，这条比较当场停止匹配 |
| `crates/caly-app/tests/contract_gate.rs` | 6 | contract / parity / scenario 三套报告必须**全绿**且非空；parity 在真实部署之后比对同一个 daemon 的两条路径；`run_smoke_bundle` 的 128 行逐行判定（行数下限 100，防止「只聚几行必过项」冒充套件） |
| `crates/caly-app/tests/error_identity.rs` | 6 | 错误身份跨路径一致：daemon 的拒绝保持 `CONFLICT`/类别/不可重试/remediation，传输失败仍是 `UNAVAILABLE`，调用方 trace_id 不被 façade 改写，façade 源码里有损 wrapper 必须为 **0** 处（计数棘轮已在第十一轮改成绝对断言） |
| `crates/caly-app/tests/write_parity.rs` | 10 | 写侧 parity：四条 case 两条路径逐条比对、无 key 的写必须每次都跑、同 key 必须复用原 job 且答案逐字节相同、部署必须报出引擎分类的影响、读回内容两条路径一致（含反-vacuity：必须真的读到 bytes 且摘要三者相等）、**按 3 行翻页走到末尾之后两侧仍逐行相同** |
| `crates/caly-arch-test/src/docs.rs`（单元） | 24 | 文档形状规则本身可证伪（第二十八轮起包括处置表的**相邻性**：行与行之间隔一个空行就等于表格到此为止，编号检查看不出、渲染出来是一段话）：列数失配、缺分隔行、行内代码与转义竖线不算列、列表连号（空行后重新起算合法）、小节号唯一（`3.` 与 `3` 同号）、通配符不当作断链、注入式存在性判定、实测数字与合计自洽；第三十一轮两条：文档索引双向核对、处置表行必须以 ` |
| `crates/caly-arch-test/tests/dependency_direction.rs` | 10 | 依赖方向、陈旧允许边、纯核心符号、债务棘轮、成员覆盖；第二十七轮加：`production_code_drives_effect_plans_through_the_cursor_entry_point` —— 生产代码（`crates/*/src/**`）不许调用无游标的 `execute_effect_plan(`，注释行除外，`caly-engine/src/executor.rs` 自己豁免（它就是那句委托）。它的裁判方式被写进测试名里：**行为不变的违规**（多一个不接游标的接缝）只有这条门禁会红；第二十八轮加：`the_durable_store_drives_ports_through_the_shared_budget` —— `crates/caly-storage/src/**` 不许出现 `block_on_ready(`（唯一豁免 `audit.rs`，它驱动的是已经带类型的 `dyn StorageBackend`，并附一条「扫到的文件数 ≥ 8」的反空转断言，免得门禁自己悄悄变成零）；第二十九轮加：`every_backend_that_runs_the_fs_suite_runs_the_byte_budget_check_too` —— 任何跑了 `fs_contract_violations` 的后端套件必须也跑 `fs_byte_budget_violations`，否则新加的契约检查会悄悄变成仿真器独有（`ADR-022` 最怕的形状）；门禁自己带一条"应当恰好找到 2 个后端"的断言，免得它退化成扫 0 个文件 |
| `crates/caly-arch-test/tests/doc_consistency.rs` | 7 | **扫遍 `docs/**`**：引用路径必须存在、表格/列表/编号形状、crate 名合法、`§3.3` 的实测数字与树一致；含一条反-vacuity 断言（文件数 / 引用数 / 行数下限）；第三十一轮加第 7 条：`the_document_index_lists_every_top_level_document` —— `docs/README.md §1` 的目录树 ↔ `docs/*.md` **双向**一致（新文档不写进索引 = 没人会读它；索引留着已删的文件 = 一句空头承诺） |
| `crates/caly-cap/tests/registry_drift.rs` | 7 | registry / coverage JSON 与内建 default 双向一致、解析器健壮性 |
| `crates/caly-common/src/digest.rs`（单元） | 5 | SHA-256 NIST 向量、分块与填充边界、`sha256_matches` 的严格语义 |
| `crates/caly-common/src/lib.rs`（单元） | 4 | `Ctx` 默认不带去重句柄、`with_idempotency_key` 只加不改其它字段（`ADR-021` 末尾的向后兼容扩展规则） |
| `crates/caly-common/src/redact.rs`（单元） | 20 | `RFC-0010 §6.2` 每条规则各有正反例：幂等、无误伤（digest / 公共地址 / 端口不被掩）、Strict 才动的 `§4.1` 准 secret、字面量登记 |
| `crates/caly-daemon/src/local_facade.rs`（单元） | 2 | 本地门面把 `Ctx.io_budget` 原样写进 envelope；没有预算时也**明说**当时生效的那个默认（第二十四轮起是有界的 `default_command`，不再是 unlimited）而不是留 `None` 让 daemon 猜 —— 同一条请求在两条门面上必须有同一个答案 |
| `crates/caly-daemon/src/paging.rs`（单元） | 13 | 事件页的四条规则各一条（默认不是上限、超上限被夹、0 被拒而不是被猜、wild 值仍然离帧上限很远），外加第二十九、三十轮的诊断上界那一组：预算内什么都不说（反占位符）、行数越界**仍在计数**、单行超长是**就地缩短**且把省略量写进文本、字节预算可以先于行数预算咬下来、首行永远被带出（与 `caly-engine::job_follow` 同一条规则，一个 crate 不许有两种答案）、说明行必须装得下它自己的预留、`may_claim_clean` 的四种组合 |
| `crates/caly-daemon/src/request_map.rs`（单元） | 4 | 入站 `io_budget` 原样抵达 `Command.context`；缺失才用 daemon 默认，且那个默认与门面侧写的默认**是同一个值**（`default_command`，64 次计入的 store 访问；两处各写一遍就是下一次漂移的来源）；相对 `deadline_ms` 被转发但**不被伪造**成绝对期限（daemon 无单调时钟）；远端路径安装惰性 token 而非假装的转发 |
| `crates/caly-daemon/tests/apply_command_path.rs` | 5 | envelope→command→job→执行→snapshot、越权拒绝、启动恢复、回滚保留快照 |
| `crates/caly-daemon/tests/cas_and_impact.rs` | 5 | `expected_revision` CAS 在入队前拒绝（不留下 job）、匹配的 revision 接受且旧的再不能用、重放不受 CAS 阻挡、三类命令各自报出 Restart/ReadOnly/Reload、查询完全不看该字段 |
| `crates/caly-daemon/tests/diagnostic_bounds.rs` | 6 | 两条批量诊断查询的响应上界（`RFC-0002 §9`/`§11.4` + `§4.54`）。**第一条是整份文件的非空性对照**：`without_the_bound_this_answer_would_have_exceeded_the_frame_cap` 量出同一份数据不设界就超过 `MAX_FRAME_SIZE_BYTES`，否则其余五条在"数据本来很小"的世界里全都会绿。其余：守恒律 `carried + omitted == decision_count`（计数不缩到答案大小）、每行不超单行上限且带省略标记、整层连说明行一起不超公开上限、洪水不挤掉 daemon 自己的三句话（recovery/idempotency/gc 计划）、安静时不许出现截断说明、以及"只有行数咬住"的那个组合（`shortened == 0`） |
| `crates/caly-daemon/tests/durable_boot.rs` | 10 | 重启后从盘恢复 `active_profile/active_core/snapshot`；崩溃事务跨多次重启仍报 `Recovering`；盘损坏**拒绝启动**；`Recovering` 拒 apply 但放行 status 与 rollback；后端自相矛盾进 `Failed`；doctor 三项真实发现；未知 job 是类型化错误 |
| `crates/caly-daemon/tests/gc_collect.rs` | 6 | 回收周期经完整命令门面：删的就是给操作看过的清单、忙时拒绝且**什么都不改**（含 `state_revision` 不动）、缺 key 的拒绝点名 `system.gc-collect`、越界在入队前就是 `CONFIG_INVALID`、陈旧 `expected_revision` 是 `CONFLICT`、`Viewer` 不能启动删除 |
| `crates/caly-daemon/tests/gc_plan.rs` | 9 | GC 计划经完整门面：孤儿被点名而每个 root 引用的对象都不在表上（且理由写明是哪个 root）、真盘与注入时钟不同源时**拒绝**而不是给出空表、快照记录被带外删除 → 两个可行动的 gap、越界参数是 `CONFIG_INVALID` 而非 store 故障、非 idle 引擎拒答自己的计划、`Viewer` 读不到删除计划 |
| `crates/caly-daemon/tests/gc_run_view.rs` | 3 | `system.gc-plan` 的答案终于带上上一轮回收周期干了什么：没跑过就是 `None`（而不是"跑过、什么也没删"），跑过则**逐字段**等于引擎里那份记录（含 `triggered_by` —— 映射时最容易悄悄丢的就是这种没人会去读的字段），并且客户端那行与 `doctor` 那行**必须是同一句话**（两个渲染器、一个事实；这条断言的存在理由见 `ONBOARDING_NOTES §4.102`） |
| `crates/caly-daemon/tests/idempotency_and_roles.rs` | 7 | `ADR-037` 落地的判定：无 key 的 `Required` 命令在入引擎之前被 `CONFIG_INVALID` 拒绝（且不留下 job、不推进 revision）、空白 key 对**任何**命令都拒绝（它是共享桶）、三道门禁的顺序（角色 → 请求形状 → 状态）、本地默认角色是 `Operator` 且 `Admin` 授权后同一命令可执行、同角色在两条路径上的拒绝文本逐字节相同、本地调用的 request id 不再恒为 0（`Command.id` 可区分）、拒绝次数在 doctor 里可读 |
| `crates/caly-daemon/tests/job_events.rs` | 9 | 事件窗口内容：行的顺序与关键标记（`apply.plan` / `snapshot.committed` / `[done] Succeeded`）、计数与行数自洽、`from_event_index` 为**排他**游标、末尾游标是空窗口而非 reset、未知 job 与摘要查询给出**同一句**拒绝、读回的**行本身仍是掩过的**、**3 行一页走回整窗**、无视上限的请求仍然 `≤` 公布的两个界、`0` 界被 `CONFIG_INVALID` 拒绝且点名是哪个字段 |
| `crates/caly-daemon/tests/overload.rs` | 4 | 灌到真实上限（256）之后：拒绝带类别 / hint / 数字而不是裸 `UNAVAILABLE`、拒绝不得把合法的 `expected_revision` 变成 `CONFLICT`、拒完队列不多不少、`doctor` 一条按类别汇总的行（不是每次拒绝一条，也不是错误级） |
| `crates/caly-daemon/tests/redaction_boundary.rs` | 6 | `§14.1/§14.2/§14.3` 三条门禁：错误在门面边界被掩、job 日志在写入处被掩、bundle 落盘字节无明文；bundle 与 doctor 同一行 summary；升级单向；查询侧类型化拒绝 |
| `crates/caly-daemon/tests/support_bundle_readback.rs` | 5 | 导出可达：读回的字节与 store 里的完全一致且仍脱敏（命名值与登记字面量都不出现）、省略 digest 取最新一个、**非 bundle 的 digest 在碰字节之前被拒**且错误文本不回显 payload、缺对象是类型化拒绝而非空导出、截断只截响应不跳校验 |
| `crates/caly-engine/src/bundle.rs`（单元） | 8 | `enumeration` 三分法（不支持 / 读不到 / 有内容）、段清单、Strict 升级、「草稿确实含明文」的可证伪断言、身份读不到时不填假值 |
| `crates/caly-engine/src/executor.rs`（单元） | 12 | 阶段分类与单调性、verify-before-commit 门禁、顺序拒绝、崩溃矩阵、journal 状态映射、跳过原因可区分；第二十六轮加：探针时限的边界、时限只作用于探针、`deadline_ms=0` 与策略开关无关、合并证据取**最慢**一段 |
| `crates/caly-engine/src/gc_plan.rs`（单元） | 14 | 计划的纯逻辑：六类 root 各自生效且理由可核对、缺任一类即清空删除列表、retained 采样有界且自报截断、容量推迟不计为保留、边界默认/收窄/拒绝三分、年龄晚于 now 视为时钟不同源、actionable 与结构性缺口的分层、idle 取自引擎自身状态 |
| `crates/caly-engine/src/idempotency.rs`（单元） | 7 | 去重窗口的边界语义：只有**已完成**记录会被淘汰且按 job id 从旧到新、运行中的记录永不被淘汰（淘汰它就是让重试触发第二次部署）、窗口外的那条必须被计数说出去、`(actor, key)` 是键而不是 key 本身、重放读回的是原 `Accepted` 逐字 |
| `crates/caly-engine/src/job_follow.rs`（单元） | 8 | 窗口与分页算术（含端到端碰不到的 reset 分支）：游标比保留起点还旧 → `reset_required` 且不返回半截列表；窗口内 → 从 `from+1` 续上；末尾 → 空但不是 reset；`first_index` 必须就是本切片真正的第一行；页必须能走回整窗、单行超预算仍然返回、reset 不许伪装成一个可用的续读游标 |
| `crates/caly-engine/src/processor.rs`（单元） | 3 | 拒绝不改任何状态（revision / job id / 队列内容）、十次拒绝=十次记录（有界窗口必须自报窗口）、公开错误的每一段（类别、hint、数字、诊断码）都来自同一个映射 |
| `crates/caly-engine/src/recovery.rs`（单元） | 9 | `block_on_ready` 契约、`StorageBackend` 可作 trait object |
| `crates/caly-engine/src/run_limits.rs`（单元） | 8 | 一份 `Ctx` 换算成"能被判的执行限制"的每条规则：`immediate()` 真的什么都不得罪（且不谎报 limits）；相对期限只在有时钟时锚定，没时钟时记为 **unjudged** 而不是"没有期限"；边界已经锚好的绝对期限**不许二次锚定**（off-by-one 也测）；本文件与 `RequestContext::with_deadline_from` 必须算出同一个数；limits 克隆共享取消位；`polls=0` 当 1 处理；`StoreRefusal` 的 kind 与 retry 位来自给答案的那一方，不来自分类；第二十七轮加：store 自己说 `Busy` 才升级成 `StorageBusy`，其余九种 `StorageErrorKind` 一律留作 `Backend`（三种都各有一条断言，且 store 原文必须逐字带出）；第二十九轮加：端口的 `CapacityExceeded` ⇒ `RefusalKind::PayloadTooBig`（`retryable=false` 是推理：重发不会让载荷变小），store 的 `Busy` ⇒ `StorageBusy`（可重试）—— 两个"容量形状"的答案不许塌成一个 |
| `crates/caly-engine/src/service.rs`（单元） | 1 | 回收归属的匹配规则单独钉住：没有 claim 时任何周期都是 `caller`；claim 属于另一个 job 时既拿不到标签也**不会**把它消费掉；只有被调度的那条 job 能取走 `automation:gc.idle`，且只能取一次。写在 seam 上而不是写成端到端用例，是因为今天那条端到端路径**构造不出来** （tick 只在队列为空时跑，而排队中的自动周期会让计划判定 non-idle，人工周期只会被拒而不是插队）——留着这条断言是为了队列一旦有优先级顺序，标签仍然不会串 |
| `crates/caly-engine/src/sim_runtime.rs`（单元） | 9 | 确定性世界模型：identity 采纳与陈旧拒绝、net 事务、DB 事务、物化前置条件、探针一次性、锁前提、派生 id |
| `crates/caly-engine/src/worker.rs`（单元） | 1 | `worker.rs` 第一次有自己的单元测试，为的是把两张"一个事实一个答案"的表钉住：`BudgetExhausted` 与 `PayloadTooBig` 共用 code/category（`RFC-0002 §14.4` 没有容量码）却**必须**给出不同的 remediation（一个是次数、一个是单次字节，指错等于给半个调用方发错建议）；而 `StorageBusy` 那条**不许**提到 `io_budget` —— 把存储自己的忙说成调用方的错，是编造理由 |
| `crates/caly-engine/tests/apply_execution_gate.rs` | 7 | 中心线端到端、**每个 EffectStep 崩溃后 LKG 不被污染**、恢复决策仅凭 journal、确定性、回滚 |
| `crates/caly-engine/tests/ctx_limits_in_apply.rs` | 6 | `ADR-036` 第 2 步落在调用方看得见的那一侧：已取消的命令**在 store 被问之前**就被答复（`list_unresolved_apply` 与 LKG 证明 store 没被动过）；job 记录与 cycle 结果必须说同一件事（`JobState::Cancelled` / `TimedOut`，这两个 `JobOutcome` 变体此前没有生产者）；期限由注入时钟判出来、错误文本必须引用那次读数；**没有时钟就不许把不可判的期限变成拒绝**；限制在场但未被违反时答案与完全不设限制逐字节相同；以及"第一次记下世界已被改动的写不可拒绝，之后的游标移动可以"这半边免疫 |
| `crates/caly-engine/tests/cutover_intent_guard.rs` | 11 | `APPLY_EXECUTION_CENTERLINE §6.1` Phase B 的 pending guard（`OVERLOAD_AND_RETRY_MODEL §6.2` 的那三条要求在代码里的落点）。执行器层 5 条：整条 trace 相等（**顺序**是性质本身，子集断言看不见它）、guard 只覆盖 Cutover 窗口、意图写被拒 ⇒ 那一步不到达 runtime（含 `RolledBack` + 补偿恰好一次）、窗口第一格被拒 ⇒ `FailedBeforeCutover` 且**不得**跑补偿、`NoCursor` 与旧的 `execute_effect_plan` 逐字段相等（证明是「加了一层」而不是「改了一层」）。worker 层 6 条：一次真 apply 在 store 里的写序（pending → 每条 cutover 一步一条 → fold，且 `updated_at` 不倒退）、store 拒绝 ⇒ 世界一分未动且记录这么说、拒绝同时进 `doctor` 的过载行与调用方 `detail`（同一份 `detail()` 拼写）、`IntegrityViolation` 不算拥塞、预算 1 ⇒ 两条接缝共用一个计数器（旧写法会让 apply 跑完）、注入步进时钟让期限正好落在窗口第二格 ⇒ job 结算 `TimedOut` 且 `deadline at mono 2 expired` 出现在 detail |
| `crates/caly-engine/tests/durable_centerline.rs` | 7 | 真流水线跑在落盘后端；**换新 engine + 重开同盘**后快照可恢复、被打断的 cutover 变回决策、第二次 apply 不删旧快照 |
| `crates/caly-engine/tests/gc_plan_and_clock.rs` | 6 | 计划与周期共用一个钟：共享时钟下 grace 边界成为事实（推进虚拟时间即从不可删变为可删）、不注入时钟时拒绝并写明用的基准、周期只删它刚报告的那份清单、被拒也必须留下记录、root 全好但引擎忙这一单独状态也要停、被拒/空跑/删了东西三种结局在记录里互不相同 |
| `crates/caly-engine/tests/idle_gc_automation.rs` | 6 | `ADR-038 §13.2` 的自动收集：没有那张 patch 时跑 24 轮也**一个对象都不动、计数器也不前进**（未授权期间的计数不算数，否则第一次启用会落在无关等待的中段）；启用后在到期的那次检查上真的删掉无主对象，并把 `triggered_by=automation:gc.idle` 写进记录行；**tick 只排队、cycle 才动手**（tick 之后 store 未变、`last_gc_run` 仍空、claim 指向某个具体 job）；空仓库的到期检查**不产生 job 行**；第二次自动周期不复用第一次的幂等 key（否则 dedup 把它吞成重放，收集器安静停摆而记录看着仍然正常）；自动化永不插到调用方命令之前 |
| `crates/caly-engine/tests/probe_deadline_gate.rs` | 6 | `ADR-036 §2.5`：探针超时是**验证失败**而不是新状态。预算刚好用完必须放行（`<=` 的边界）；超一点就停在那一步 —— `probe_passed` 仍为假、快照不标、修订不提交，证据里保留 `took=…ms` 以便审计；脚本化的慢速是**一次性**的（否则第二个探针被连坐，而真实计划总是连着发两个探针）；`deadline_ms == 0` 在**碰任何运行时之前**拒掉，且不受 `enforce_phase_order` 影响 |
| `crates/caly-engine/tests/simulated_clock_execution.rs` | 5 | 注入时钟、port 级与 executor 级注入一致、陈旧 identity 阻断 |
| `crates/caly-engine/tests/storage_backend_swap.rs` | 3 | 换后端跑同一套断言、`Busy` 不造假状态、快照提交失败留下恢复痕迹 |
| `crates/caly-engine/tests/store_suspension_is_contention.rs` | 2 | 同一件事在**上一层**的样子：store 说 `Busy` ⇒ `StoreRefusal::from_storage_error` 必须给出 `RefusalKind::StorageBusy` + `retryable=true` + 驱动器原文（`Internal` 会把它降级成 `Backend`，于是运维那本账少一笔）；反过来，一个只是慢的落盘后端必须把整条 apply 跑成功并交出 last-known-good（旧写法在这里报内部错误） |
| `crates/caly-engine/tests/support_bundle.rs` | 9 | `§9.3` 四项来自真实 store、12 段齐备且有序、CAS 摘要=内容摘要、导出无明文、作业上报句柄、「读不到」不等于「正常」、**拒绝记录进 `overload` 段且空日志必须明说** |
| `crates/caly-io-sim/tests/contract.rs` | 16 | `RFC-0006 §15` 端口契约跑在仿真盘：VPath 逃逸、`D0–D3` 耐久分层、锁竞争；第十五轮起还包括列举有序且受 `ListCap` 约束、空目录与不存在可区分（`dirs` 只记录被写入创建出来的目录）、mtime 只来自注入的虚拟时钟且**只在写时**盖章、没有时钟时诚实地报 `None`；第二十八轮加：注入的 **stall**（计数挂起）在 1 次 poll 下仍不就绪、在 2 次 poll 下答对、且一次性 —— 与 `hang`（永不就绪）分成两种形状，因为「慢」与「卡死」若在测试里是同一个读数，任何 poll 预算都能自称安全；第二十九轮起包括同一组 `fs_byte_budget_violations`，另有 `Http` 一侧的"body 上限与调用方预算取更紧的一条" （`SimHttp` 是唯一存在的 `Http`，所以这条不写成跨后端一致） |
| `crates/caly-io-sim/tests/executor.rs` | 4 | 执行器跑在**真的会挂起的端口**上，而不只是跑在夹具上：一批 `SimFs` 读按提交序返回且字节完整；被 `hang` 的读在注入时钟上判成 `Timeout`（消息必须引用它判的那条期限、时钟必须确实走了 3×20ms、用完的 hang 不再卡住下一次读）；不许动时间时是 `Busy` 并点名卡住的 label （`advance=none, clock=yes`），且时钟一格没走；端口自己的故障**逐字段等于**不经执行器时的那一份（kind、文本、重试位都不许被改写），并且不被重试 |
| `crates/caly-io-sim/tests/simulation_primitives.rs` | 10 | 虚拟时钟推进不回拨、故障注入按 label 命中、场景确定性 |
| `crates/caly-io-std/tests/contract.rs` | 12 | 同一套契约跑在**真文件系统**：VPath、`D0–D3` 分层、无临时残留、root 沙箱、锁互斥；加上共享的列举与 mtime 两条，其中"恰好等于上限必须成功"与"对文件调用 `list` 是 `InvalidInput`"由本文件独有的两条断言各自复核一遍，外加端口故障文本不得泄漏宿主绝对路径；第二十九轮起包括共享的 `fs_byte_budget_violations`：真盘上超限写在**落盘之前**被拒、被拒之后 `stat` 必须说没有这个文件、精确等于预算放行、未设预算不拒 —— 与仿真盘跑的是同一组断言 |
| `crates/caly-io/src/budget.rs`（单元） | 4 | （本轮新增，见 `docs/DEVELOPMENT_LOG_2026-08-27.md` 对应小节）；`RFC-0006 §5.3` 的上限只剩四条可数的事实，各一条断言：更紧的一条赢（**宽松的那条不得放大调用自带的 cap**）、精确等于上限算在内、被拒文案点名的是 `io_budget.max_bytes` 还是 `512 byte cap`、`resource` 字段不许在半路丢掉；外加"未设预算什么都不拒"（`None` 既不是 0，也不是无限到不必检查） |
| `crates/caly-io/src/executor.rs`（单元） | 13 | 有界执行器的每条规则各有一条断言钉住：满队是 `Busy` 且文本同时含在队数与容量、拒绝不消耗 id 也不惊动已排队的任务；capacity 0 与「没有时钟却要求 sleep」在**构造期**就拒；一轮里每个任务只拿同样多的 poll、完成序等于提交序（贪心驱动会在第一轮就只答一个，这条断言当场抓住它）；`Advance::StepMillis` 让等时间的任务真的完成，且推进次数与 tick 数分别可数；永不就绪以 `Busy` 收尾、任务仍在队里、completed 与 port_faults 都不许动；期限到期是 `Timeout` 并且**挂起的 future 被丢弃**（poll 次数证明到期那一轮没有再 poll 一次）；没有时钟时期限**不会**被说成超时；父令牌取消发生在下一个 poll 之前（被取消的任务一次都不跑）；sleep 端口的故障不被改写成 `Busy`；四类出路各自计数且相加等于 submitted |
| `crates/caly-io/src/runtime.rs`（单元） | 6 | 驱动器的四条出路：立即就绪只 poll 一次（既有调用点行为不变）、被驱动到就绪的挂起端口算数完成、没有时钟也没有取消时是 `Busy`（可重试、瞬态）且文本写明哪些限制在场、取消优先于超时且两者是**不同 kind**、有期限但没时钟时**不猜**、`block_on_ready` 与 `drive` 的文案不许各说各话 |
| `crates/caly-ipc/tests/session_and_frames.rs` | 18 | 帧编解码与长度校验、协商策略、会话状态机、流交付策略 |
| `crates/caly-storage/tests/apply_journal_listing.rs` | 4 | 默认 `Unsupported` ≠ 空、内存与落盘都含 `Committed`、**记录损坏让导出失败**而不是跳过 |
| `crates/caly-storage/tests/fs_store.rs` | 17 | 内容寻址、篡改拒绝、元数据-only 不可物化、重启复原（仿真盘）；第十七轮起还包括：对象年龄取端口 mtime 而非调用方声明（谎报不能提前进 GC）、无时钟时不伪造、两个来源冲突取较新的一侧；第十六轮起还包括：带外写入的记录同样被枚举（运行中与重启后都要）、崩溃残留与「布局解释不了的名字」分别处置、超限是拒绝而非短列表、store 不写任何索引（按文件总数计）、pending 扫描答自目录而非内存 |
| `crates/caly-storage/tests/fs_store_on_real_disk.rs` | 5 | 同一组重启断言跑在 `StdFs` 真盘上（曾据此抓出 `runtime_path` 双前缀）；第十七轮起还包括真盘 mtime 落在写入窗口内（时钟也只经 `StdClock` 端口读） |
| `crates/caly-storage/tests/gc.rs` | 10 | `§13/§15.6`：六类 root 各自生效且理由正确；未引用且过 grace 才回收；未知年龄不回收；单轮上限；忙时拒绝；共享内容不误删；宽限期边界为排他 |
| `crates/caly-storage/tests/object_contract.rs` | 8 | **同一组断言跑 `InMemoryStorage` 与 `FsStore`**：写后按字节读回、未知 digest 是 `None` 而非错误、声明假锚点被拒、metadata-only 既不能物化也不能读回、超限是 `CapacityExceeded`（消息含两个数字且不漏内部路径）、删除后内容不残留、不支持的后端答 `Unsupported`、**篡改后读回被拒** |
| `crates/caly-storage/tests/record_codec.rs` | 10 | 记录 round-trip；拒绝未知版本、未知字段、坏枚举、悬空转义 |
| `crates/caly-storage/tests/revision_listing.rs` | 4 | 登记修订的枚举：未实现的后端答 `Unsupported` 而不是空集（空集会授权删除）、两个后端同行同序且带 digest、目录即真相（重启后一致，文件被删就少一条）、记录损坏使整次枚举失败而非跳过 |
| `crates/caly-storage/tests/schema.rs` | 13 | `§12` 四规则 + `§12.3`：五分类判定、迁移必须连续分步、迁移前建回退点、失败即拒启、标记只在缺失时写入 |
| `crates/caly-storage/tests/store_port_budget.rs` | 7 | 落盘 store 怎么驱动它底下的端口（`ADR-036 §2.6`）：预算之内的挂起**仍然是成功**（读、写各一条，写那条复核"字节真的落了盘"）；永远不就绪报 `Busy` 且**明写不得报 `Internal`**、文本必须带驱动器自己用的 poll 数；边界从两侧量（`budget-1` 通过、`budget` 拒绝），所以把常数改成 1 会当场红；stall 是一次性的、不连坐后续调用；`port_drive.rs` 里不许出现第二个 poll 循环（`Waker::noop` 命中数必须为 0，且只准调共享驱动器一次）；第二十九轮加：`the_store_invents_no_byte_ceiling_of_its_own` —— 4 MiB 载荷经 store 写入必须成功，因为 `FsStore` 那份共享 `IoContext` **不设**预算；这是"别把好意写成停机"的那条防线 |

未覆盖（诚实列出）：**`ADR-036` 落在第 0、1、2、3 步**（类型、有界驱动、可挂起的仿真端口、envelope 的 `io_budget` 透传与**生效**（`max_requests` 由引擎计费并在耗尽时拒掉下一次计入的访问）、`BoundedExecutor` 本体、以及"命令的 `Ctx` 抵达 store 接缝"都在；但 (a) `BoundedExecutor` 仍**没有生产调用者**——第 2 步接的是 `drive`/`RunLimits` 这条最小接缝，队列上限 `max_tasks` 今天只被测试触到，与 `run_object_gc` 同类（`ONBOARDING_NOTES §4.85` 说清那是分工不是遗漏）；
  同一条理由也适用于第二十七轮的游标接缝：`RunLimits` 现在被**两个**接缝共用（`begin_apply_persistence` 与 `JournalIntentCursor`），
  所以"一份命令一个预算计数器"从这一刻起才真的可证（`crates/caly-engine/tests/cutover_intent_guard.rs` 的预算那条就是它的裁判，见 `ONBOARDING_NOTES §4.109`）；(b) **期限只能阻止一次还没开始的 store 访问，不能打断已经开始的**——本仓所有后端在引擎这一层都是"首次 poll 即就绪"；第二十八轮起 `FsStore` 内部不再是"一次 poll 否则内部错误"，而是有界轮询（`port_drive::STORE_PORT_POLL_BUDGET`）且超预算如实报 `Busy`（于是它能被 `StoreRefusal::from_storage_error` 认成 contention），但**仍在 poll 之间判定，不能中断已经在做的那一次**，要让限制走到端口里去，得先给 `StorageBackend` 的签名带上 `Ctx`（`RFC-0007` 冻结过它，见 `ADR-036 §6bis-quinque`）；(c) 查询侧仍**不按调用方**接限制（query 路径手上是 envelope 而不是 `Ctx`），但"答案有没有上界"这一半已在第三十轮判完并落地：两条批量诊断查询有响应上界且如实报告截断，其余读回路径（bundle 的 `max_bytes`、事件页的 `EventPagePolicy`、gc 计划的 `GC_PLAN_SAMPLE_LIMIT` / `MAX_GC_MAX_DELETIONS`）此前就有界；仍然没有的是"调用方自选更大页"——理由写在 `ADR-036 §6bis-quinque` 的那条更新里；`caly-io-std` 阻塞池与 `Proc` 仍未做；`Http` / `Proc` 那半边的**字节**那一格已于第二十九轮落地（上限由端口执行、两个后端跑同一组契约断言），但**按调用方累计**仍没有做到 —— 命令的 `Ctx` 止于 `RunLimits`，端口看到的那份 `IoContext` 属于 `FsStore`、跨调用方共享），`Ctx.deadline_ms` 能拒掉**尚未开始**的访问、打断不了已经开始的（`ADR-036 §6bis-quinque`）；`caly-app::remote` 那行预算转发的端到端断言已在第二十四轮补上（`crates/caly-app/tests/budget_parity.rs`），`§4.86` 记的那笔挂账结清；**自动收集默认关闭**（`ADR-038 §13.2` 已于第二十五轮落地成 role-gated 的 `AutomationPatch(gc.idle)`：没提交过那条命令的部署不会自己动手 —— 这是策略选择，不是缺口，见 `ADR-038 §9`）；**真实部署目前仍会带着 `clock-timeline` 缺口而拒绝**（接缝已在第十九轮建好：`EngineHandle::set_storage_clock` + `storage_now()`，计划优先用注入的端口时钟并报告 `now_source`；但 `caly-daemon` 没有 `[[bin]]`，还没有会去填它的组装根。测试钉住两侧：不注入 → 拒绝并说明用的哪个基准；注入 → 同一份 store 状态立刻成为可用计划，见 `§4.74` 与 `ADR-038 §7` 的两个 `now` 对照表）；**孤儿内容无人清扫**（先删元数据再删内容，中间崩溃留下的内容文件今天没有任何东西会发现：内容在三层目录下而端口只保证一层列举）、
`EventBacklog` / `StreamBackpressure` 两类过载**仍没有生产者**（分类与映射都在，触发点不在：
它们缺的是流侧的合并/丢帧策略）。`StorageBusy` 于第二十轮**第一次有了生产者** —— 回收周期在引擎忙时被
入队前拒绝；而 `OVERLOAD_AND_RETRY_MODEL §6.2` 设想的那个争用（cutover 期间对同一份存储的写争用 +
recovery-sensitive 升级）已于**第二十七轮**落地：逐步意图记录 + 写不下去就 refuse 那一步 + 三条要求各有裁判
（`APPLY_EXECUTION_CENTERLINE §6.1` Phase B 的 pending guard，见 `ADR-036 §6bis-octies`）；`§6.1` / `§6.3` 的其余部分（prepare 前的
其它过载来源、verify 之后的提交收敛）仍按各自文档的口径检查。
把 bundle 写到调用方指定的路径（需要平台/导出位置决策，读回内容本身已经可用）、
`RFC-0010 §5`（keyring / 加密存储优先级）与 `§11`（SSRF/重定向剥离）、`§13` 的 principal 层（角色边界仍只有
`role_satisfies` 一处实现，第十四轮起它在两条路径上都真的会拒绝，但「谁在调用」今天只等于一个角色）、`§14` 门禁的第 4–8 条（UDS 权限、helper 输入、SSRF、下载校验、导入限额）——
`§14` 的 1/2/3 条已落为断言；
`caly-ipc` 的**传输运行时**（读写泵、reconnect、timeout 调度——现在测的是框架与
状态机，不是 socket）、`caly-mihomo` / `caly-singbox` 的原生字节内容 golden、
`caly-pipeline` 的缓存/记忆化、stream 侧的写后**逐帧 payload** 比对（有损包装已在第十一轮清零，
`pull_stream` 的帧仍只检查"非空与行数"）、
`Ctx` 的 `deadline_ms` 执行者与 `IoBudget` 记账（`ADR-036` 已定稿、实现未开始：`block_on_ready` 仍只 poll 一次，
`RequestEnvelope` 连 `io_budget` 字段都还没有）、`Fs::list` / `Meta.mtime` 与清单层删除（`ADR-035` 已定稿、实现未开始）、
`caly-io-std` 的 `Http` / `Proc`（尚未实现，契约 §15 的 3、4 条因此空着，见 §7.10）。

---

## 4. RFC 实施状态矩阵

| RFC | 标题 | 状态 | 当前落地情况 |
|---|---|---|---|
| RFC-0001 | Core Architecture | `Partial` | workspace、依赖方向（**已有门禁**）、engine/daemon/app 主骨架成型；`engine -> 具体 adapter` 仍是已登记债务 |
| RFC-0002 | API / Facade / IPC | `Partial` | Facet/DTO/Operation、local/remote facade、loopback contract；**写侧、事件内容与错误身份 parity 已建立**（`run_write_parity`：四条写 case + 每条的事件行内容比对 + 同一 job 两侧逐字节一致 + 两条 CAS 探针 + 五条信封比对；`with_client` 有损包装已从 façade 移除），`expected_revision` CAS 与 `ctx.trace_id` 透传已实现；`required_role` / `Idempotency::Required` 仍无执行者（`ADR-037` Proposed）；`§9` / `§11.4` 的**读侧有界性**已实现：导出读与事件窗口读都是「有界且自报截断」的查询（默认页与上限在 `caly-daemon::paging`） |
| RFC-0003 | Pipeline / Provenance | `In Progress` | merge/resolve/validate/compile/flow 产出可执行计划；缓存/记忆化仍无测试 |
| RFC-0004 | Capability / Coverage | `Partial` | registry/coverage 参与求值；JSON 工件漂移已有门禁，但执行仍来自内建 default |
| RFC-0005 | Deployment / Recovery | `In Progress` | **effect 执行 + journal + snapshot + 回滚补偿 + 恢复扫描已闭合到内存后端**；真 OS 副作用未接 |
| RFC-0006 | IO Port / IoFault | `Partial` | 两个后端 + 共享契约套件已落地（§15 的 1/2/5/7 条）；`Http` / `Proc` / `Platform` 适配器仍缺 |
| RFC-0007 | Storage / CAS / Snapshot | `Partial` | 五个 store trait + 内存后端 + **`FsStore` 落盘后端**；`§6.1-6.4`（含**读时锚点校验**与 `read_object`）与 `§13/§15.6`（GC root 集）均可测；两个后端跑同一组契约断言；`§7.3` schema 迁移未做 |
| RFC-0008 | RuntimeDriver / Telemetry | `Skeleton` | trait/mock 在；`config_identity()` 与 plan 侧仍未连接（见 `ONBOARDING_NOTES.md §4.1` 残留项） |
| RFC-0009 | Profile Patch / Override | `In Progress` | selector、selection memory replay、merge/resolve 消费已成形 |
| RFC-0010 | Security / Secret / Redaction | `Partial` | `caly-common::redact` 落地 `§6.2` 全部目标 + `§4.1` 准 secret；三条出口（job 日志 / `ApiError` / support bundle）各自接线，`§14` 门禁 1/2/3 有断言；`§5`/`§11`/`§13` 未成码 |

---

## 5. 按 crate 分组的真实推进状态

### 5.1 基础层

| 模块 | 状态 | 当前情况 |
|---|---|---|
| `caly-arch-test` | `Partial` | 已从“有函数无调用”变为真实门禁：manifest 解析 + 方向/陈旧/纯核心/债务棘轮 |
| `caly-common` | `Partial` | 共享上下文模型被多个 crate 实际使用 |
| `caly-io` | `Partial` | Port / Fault / VPath 契约稳定；`contract.rs`（RFC-0006 §15 的跨后端契约套件）；`runtime.rs`（`drive` / `drive_pinned`：一次一个 future 的有界驱动，三种互不相同的出路）；`executor.rs`（`BoundedExecutor`：有界准入 + 公平推进 + 注入时钟，**不制造时间也不重试**）；re-export `Actor/TraceId/RequestContext/IoBudget/CancelToken` |
| `caly-io-std` | `Partial` | 新建。`StdFs`（root 沙箱、D0–D3 耐久、临时文件 + 原子 rename + fsync、锁文件）与 `StdClock`；与 `caly-io-sim` 跑同一套契约测试 |
| `caly-io-sim` | `Partial` | 世界模型/fault/scenario 可编译且**已测**；时钟回退、label 不可达、`lock_exclusive` 永不竞争三处缺陷已修 |
| `caly-ir` | `In Progress` | `CompiledArtifact` 承载 native bytes / media type / annotations |
| `caly-domain` | `In Progress` | `Profile` / `OverrideRule` / `SelectionMemory` 与 builder 服务 pipeline |

### 5.2 控制平面核心

| 模块 | 状态 | 当前情况 |
|---|---|---|
| `caly-pipeline` | `In Progress` | 六个阶段形成可执行 slice；`CapabilityValidationReport` / `ApplyWorkflowProjection` 被 engine 消费 |
| `caly-cap` | `Partial` | 新增零依赖 JSON 读写器 + 漂移门禁；strict 判定已进 pipeline |
| `caly-plan` | `Partial` | `ApplyPlan` / `EffectPlan` 被 adapter 与 engine::apply 真实投影 |
| `caly-storage` | `Partial` | `execution.rs` 投影；`store.rs` 的 `StorageBackend` + `list_unresolved_apply` + `list_objects`/`delete`；`record.rs` 行式编解码（拒绝未知版本/未知字段）；`fs_store.rs` 经 `caly-io::Fs` 落盘、集合枚举走 `Fs::list`（无自造索引层）、对象年龄取端口 mtime；`gc.rs` 回收策略 + `RevisionStore::list_revisions` 补齐 `§13.1` 缺的那类 root（默认 `Unsupported`），消费方在 `caly-engine::gc_plan`；`gc.rs` 的 `sweep_objects` 与计划分离（使「周期只执行它刚报告的那份清单」是结构而非约定）；计划与周期的消费都在 `caly-engine::gc_plan` |
| `caly-engine` | `In Progress` | queue/job/idempotency/event + `executor.rs`（解释与门禁）+ `sim_runtime.rs`（确定性世界）+ `recovery.rs`（持久化编排，面向 `dyn StorageBackend`）+ `gc_plan.rs`（回收计划与周期：root 集全有或全无、`now` 取注入的端口时钟并报告来源、有界采样、周期不得把自己算作在飞工作、执行的就是它报告的那份清单）；`run_limits.rs`（把命令的 `Ctx` 换算成 store 访问的限制：deadline / cancel / `IoBudget.max_requests` 计费；拒绝原因作为数据带出去，job 才有 `Cancelled` / `TimedOut` 两种结算）；`gc_plan.rs` 的 idle 触发（`decide_idle_gc` + 单调检查计数 + `triggered_by`，`ADR-038 §13.2 / §9`）|
| `caly-daemon` | `In Progress` | query/command/stream/session/runtime/local facade + 从盘启动恢复 + 生命周期闸门（`Recovering` 拒 apply 放行 rollback/查询；`Failed` 拒命令）+ `required_role` 对 query/stream/command 三条路径统一执行（`ADR-038 §2.5`），均有测试 |

### 5.3 Core 适配层

| 模块 | 状态 | 当前情况 |
|---|---|---|
| `caly-core` | `In Progress` | `CoreAdapter` / mock / native helper；`config.identity` 已改为与 spawn 时交给 core 的 config 一致 |
| `caly-mihomo` | `Partial` | YAML artifact、native validation、apply planning、EffectPlan 全链 |
| `caly-singbox` | `Partial` | JSON artifact、native validation、apply planning、EffectPlan 全链 |

### 5.4 对外接口层

| 模块 | 状态 | 当前情况 |
|---|---|---|
| `caly-api` | `Partial` | Facet/DTO/Operation 可编译；第二十轮起 `SystemOp::CollectGarbage` + `GcRunView`（`gc-plan` 是它的 dry run）；第十八轮起 `SystemOp::GcPlan` + `GcPlanView`（18 字段，逐项都是「能不能删」的一部分，折任一项都会让剩下的被误读）；0 warning，`operation.rs` 仍偏大 |
| `caly-ipc` | `Partial` | frame/session/stream/client primitive 可编译且有 18 个测试；真实 transport runtime 未完成 |
| `caly-app` | `Partial` | local/remote facade、loopback、parity/contract/scenario 编译打通 |
| `caly-cli` | `Partial` | driver/follow/contract_driver 可编译；**无 bin target** |
| `caly-tui`（未创建） | `Planned` | workspace 无此成员，仅有规划条目 |

---

## 6. 当前中心主链的真实进度

```text
Profile / Source / Override
  -> Caly IR -> ResolvedProfile
  -> Capability Validation
  -> CoreAdapter -> NativeValidation
  -> ApplyPlan -> EffectPlan
  -> Effect Executor            <-- 本版新增
  -> Journal / Snapshot / Revision
  -> Recovery Scan / Rollback   <-- 本版闭合
  -> Daemon Command Path / Facade
```

### 6.1 本版新增的能力

- `caly-engine::executor` 把 `EffectPlan` **解释执行**，而不是渲染成字符串：
  - `phase_of` / `phase_rank` 固化 Prepare / Cutover / Finalize 分类；
  - 阶段单调性门禁（prepare 不得出现在 cutover 之后）；
  - verify-before-commit 门禁（无成功 `Probe` 不得 `MarkSnapshot` / `CommitRevision`）；
  - resume 边界：已记录 cutover 的事务不得回放到 prepare；
  - 失败后按逆序执行 `compensations`，补偿再失败则升级为 `RollbackFailed`；
  - `ExecutionStatus` 区分 `Rejected` / `FailedBeforeCutover` / `RolledBack` / `RollbackFailed`；
  - `ExecutionPolicy::fail_after_step` 提供“任意步骤后崩溃”注入点；
  - 时钟、故障、世界状态全部注入，模块内无 fs / process / 墙钟。
- `SimulatedRuntime`：确定性内存运行时（对象、物化、DB、core、net），
  会因“未写入即物化”“identity 不符”等**计划与世界不一致**而失败。
- `worker.rs`：apply 走执行器，rollback 真执行补偿并结算 journal；
  移除 “not connected to recovery executor yet”。
- job follow 现在报 `effects.prepare.started` / `effects.cutover.started` /
  `effects.verify.started` / `snapshot.committed` / `recovery.started` / `recovery.succeeded`。
- `ApplyWorkflowResult.effect_plan`：typed 计划进入 engine 结果，字符串投影降级为展示用途。

### 6.2 仍未完成的部分

- 真实 source parse / decode / normalize（仍是 estimate 级）
- 真实 effect 后端（fs / proc / net / core runtime API）——当前执行目标是 `SimulatedRuntime`；
  它需要 `caly-io` Port，而 Port 是 `async`，因此被上面第 2 条（executor 归属）阻塞
- 落盘 `StorageBackend` 实现（trait 缝隙已开，缺一个真的后端）
- `RuntimeDriver::config_identity()` 与 plan 侧 identity 的真正连通
- storage 落盘后端与 `dyn StorageBackend` 解绑
- `caly-ipc` transport runtime（读写泵、reconnect、timeout 调度）
- security / secret / redaction 系统化落地

---

## 6bis. 行为变更（release note，第二十四 / 二十六 / 二十七轮）

**`Ctx::io_budget` 与 `RequestEnvelope.io_budget` 从今天起有后果，而 daemon 的默认值不再是「无限制」。**

- `IoBudget::default_command()` 是一个命令执行所获得的默认：**至多 64 次「计入的」store 访问**
  （`IoBudget::DEFAULT_COMMAND_STORE_REQUESTS`），字节数不设上限。
  `RequestContext::new` 与 `caly_api::default_ctx` 都直接写这个值，`request_map` 在 envelope 缺字段时
  也回落到同一个常量 —— 两个门面、一条策略（`ADR-017`）。
- 「计入的」= **引擎可以拒绝的那些访问**：`recovery::run_ready_in` 经手的 store 调用（apply 的 phase A、
  以及不改变世界标记的游标推进）。记账/落真相的那几条（`put_apply_journal`、`finalize_*`、
  `mark_apply_reverted` / `mark_apply_recovery_failed`）**既不被告绝也不被计费**：一个不可能被拒的动作
  被计入预算，等于让调用方的上限去管引擎自己的簿记（`ADR-036 §6bis-sexies`）。
- 耗尽时：公开错误 `CONFIG_INVALID` / `ErrorCategory::User` / `retryable=false`，
  文案带两个数字（`allows N accounted store access(es); M already made`），job 结算 `Failed`
  （不是 `Cancelled`/`TimedOut`：那是调用方自己划的界限，不是它放弃了）。
- **对既有调用方的影响**：以前 `io_budget` 是"传下去但没人读"的字段，所以没人会被它挡；现在默认 64。
  本轮实测：整个 workspace 测试（含完整 apply 与场景包）在默认值下 422 条全绿，一次真实 apply 只花掉
  个位数次访问；显式写 `max_requests: Some(0)` 是唯一"必然被拒"的用法（用于试探边界）。**如果你的调用
  本来就想不受限，请显式写 `IoBudget::unlimited()`** —— 现在那是一个会被尊重的值，而不是唯一的值。
- **同轮新增的第二项自动化，默认关闭**：`ADR-038 §13.2` 的 idle 收集器。打开它的方式是提交
`AutomationPatch { job_id: "gc.idle", enabled: true }`（一条 `Role::Admin` 命令），不是配置里的隐式开关 ——
「允许系统自己动数据」必须留下一条可归责的命令。到期检查只做两件事：读一遍计划、在计划说得出「有东西可收」时
排一个**正常**命令；删除仍由那条命令走与人工完全相同的路径，记录里写 `triggered_by=automation:gc.idle`。
- **探针时限已在第二十六轮生效**（`ADR-036 §2.5`）：运行时**报告**耗时，执行器**判定**是否超出 `deadline_ms`，超出即"验证失败"走既有分支。为什么判定放在执行器：写在每个适配器里，就等于每个适配器都有一次忘记它的机会。`deadline_ms == 0` 不当成"无限制"也不当成"零时间"，而是在计划校验阶段直接拒（与 `ADR-038 §2` 对 `max_deletions: Some(0)` 的处理同形）。**这会改变行为**：过去能通过的"探针没写预算"的计划，现在会在触碰任何运行时之前被拒 —— 但本仓三个适配器给的都一直是正数（3_000），所以没有既有调用方受影响。
- **仍然没有的部分（别把上面读成"预算全链路生效"）**：`max_bytes` 在本层**不生效**，因为引擎看不见
  字节总量的全部（只有一条路径知道自己在读多大一个 payload）。留一个数字反而会造出"看着像保险"的
  假统计，所以宁可写成"未生效"并在此处与 ADR 中并列说明。（后半句已被第二十九轮超过：字节上限由**端口**执行，见本节末尾那一节；这一条留下的"引擎这一层不累计字节"到今天仍然成立。）
  `describe()` 会把预算显示成 `budget=<已用>/<上限>` 或 `budget=5/uncapped`，未生效与不计数是两件事。

**第二十七轮追加：cutover 窗口现在先记账、后动手，而崩溃现场因此换了分类。**

- 一次 apply 在 `Cutover` 相的**每一步之前**都会往 apply journal 写一条意图记录（`current_phase=Cutover`、
  `current_step_index=那一步的下标`、`net_effect_started` / `core_cutover_started` 已置真）。
  实测规模：默认 profile 的计划有 2 个 cutover 步 ⇒ 每次 apply 多 2 条 journal 写
  （`crates/caly-engine/tests/cutover_intent_guard.rs::a_real_apply_writes_the_cutover_window_into_the_store_as_it_goes`
  数的就是这个数字，多写一条就会红）。对 `FsStore` 那是真的 D3 落盘写——这是 `§6.1` Phase B 明说的代价。
- **对运维的分类会变**：同一个"进程在 cutover 中途被 kill"的现场，以前 journal 停在 prepare，
  启动扫描按「世界没被动过」丢弃 pending；现在它读到 `cutover_started=true` 与游标下标，于是走
  `STORAGE_RECOVERY_EXECUTION_PLAN §7.3` 的第 4 步（优先回到 last-known-good，回不去标 `RecoveryFailed`）。
  这不是回归，是那条规则第一次真的能运行——但请把它当成一次**行为变更**读。
- **意图记录写不下去时，那一步不执行**（`journal-intent-refused`）：公开错误 `STORAGE` + `Io`，
  job 结算按原因分为 `Failed` / `Cancelled` / `TimedOut`，`doctor` 的过载行只在 store 自己说 `Busy` 时出现
  （`error=storage_busy retry_hint=ManualIntervention`）。调用方的期限/取消/预算耗尽都算"调用方放弃"，
  不进那个计数（`OVERLOAD_AND_RETRY_MODEL §3.7`）。
- **一处收紧**：一条命令的 `io_budget.max_requests` 现在跨接缝共享（以前每个有界接缝各自从头数）。
  默认 64 不受影响（本轮实测：463 条测试全绿，含完整 apply 与场景包），但**显式设成个位数的调用方**
  会比过去更早被拒——那才是这个字段一开始的意思。

**第二十八轮追加：落盘 store 不再把"端口还没好"说成"存储坏了"。**

- `FsStore` / `schema.rs` 驱动 `dyn Fs` 的方式从"一次 poll，否则 `StorageErrorKind::Internal`"改成
  "有界轮询（`STORE_PORT_POLL_BUDGET = 64` 次），超预算报 `StorageErrorKind::Busy`，并带上驱动器自己那句
  `still pending after N poll(s)`"。**如果你曾按 `Internal` 匹配过 store 的错误**（今天没有任何测试或生产代码这么做），
  这一类情形现在是 `Busy`：`retryable=true`、`§3.4` 的 `storage_busy` 类，以及 `doctor` 的一条过载记录。
- 反过来，一个"慢但会答"的端口从错误变成成功：整条 apply 在慢盘上应当跑完并提交 last-known-good，而不是失败。
  这条有端到端断言（`crates/caly-engine/tests/store_suspension_is_contention.rs`）。
- 端口层多了一个可注入形状：`caly-io-sim::stall(label, polls)`（一次性、可数的挂起），与 `hang`（永不就绪）
  分开。任何自称"有上限"的数字都需要两侧都能推，这就是那一侧。

**仍未生效的部分**：`Cutover` 之外的步骤不受 guard（`needs_intent_record` 只管这个相，且有编译期锚点）；
guard 的覆盖面等于 `phase_of` 的分类正确性——一个新步骤种类若被归成 `Prepare`，它就绕开了 guard，
所以那条分类本身有断言钉着（`executor.rs::phase_classification_matches_centerline_document`）。

**第二十九轮追加：`Ctx::io_budget.max_bytes` 从今天起有人执行，执行者是端口自己。**

- `caly_io::budget::byte_ceiling` / `check_payload` 是唯一的实现处，`StdFs` 与 `SimFs` 调同一份代码，
  `caly_io::contract::fs_byte_budget_violations` 在**两个后端**上跑同一组断言：载荷超过 `max_bytes` 时在
  **任何字节落地之前**被拒（被拒之后 `stat` 必须说没有这个文件）、精确等于上限**放行**、读侧上限取调用自带 cap
  与预算里更紧的一条（**宽松的预算不得放大 cap**）、未设预算**什么都不拒**。`Http` 侧同样按 `byte_ceiling`
  收窄 body 上限（只有一侧有实现，故不宣称跨后端一致）。
- 公开面：端口的 `CapacityExceeded` 到引擎变成新的 `RefusalKind::PayloadTooBig` —— `CONFIG_INVALID` +
  `ErrorCategory::User` + `retryable=false`，remediation 指向 `Ctx::io_budget.max_bytes`。它与
  `BudgetExhausted` 是两个 kind：一个数次数、一个数单次载荷字节，合成一格就会对一半调用方说错话。
  `remediation` 本轮也并进那张共用表（同一件事的第三面）。码表里仍无 `CAPACITY_EXCEEDED`
  （`RFC-0002 §14.4` 冻结），落差是有意的，见 `OVERLOAD_AND_RETRY_MODEL §3.7`。
- **形状与 `ADR-036 §2.4` 的设想不同**：`max_bytes` 是**单次调用的上限**，不是跨调用累计量。累计需要一个比一次
  调用活得久的作用域，而能把 `Ctx` 送到端口的那道签名（`RFC-0007` 冻结的 `StorageBackend`）今天不带它；挂到
  store 的共享 `IoContext` 上就变成"第 N 次大写入之后所有人一起被拒"——那不是预算，是停机。偏离与理由记在
  `ADR-036 §6bis-decies`。
- **对既有调用方无可观察影响**：默认 `max_bytes: None`（什么都不拒），且没有一处生产代码今天设过它。

**第三十轮追加：两条诊断查询的答案从此有上界，而截断是被说出来的。**

- `diagnostics.recovery-status` 的 `decisions` 与 `diagnostics.doctor` 的三层列表受
  `caly-daemon/src/paging.rs` 的 `DIAGNOSTIC_MAX_LINES = 128` / `DIAGNOSTIC_MAX_LINE_BYTES = 4 KiB` /
  `DIAGNOSTIC_MAX_BYTES = 512 KiB`（其中 1 KiB 是留给说明行自己的预留）约束。
  两个视图各多带三个字段：`truncated`、`omitted_*`、`shortened_*`；`decision_count` / `pending_apply_count`
  与 summary 里的 `decisions=N` **保持真实总数**，不随答案收缩。
- **这是行为变更**：一个有几百条未决事务的部署，过去会返回一份大到对端拒收的帧（表现为传输层错误、诊断丢失），
  现在返回一份有界的、并且写清楚了"还差多少、去哪儿看全文"的答案。要全文就生成 support bundle ——
  `storage-audit` 段带的是未截断的 finding 列表，它本来就是存储对象而不是一帧。
- 加字段的方式与 `GcPlanView::last_run`（第二十六轮）同类：响应 DTO 的**新增可选读取**，不动请求、不动码表、
  不动 `ProtocolVersion`；两条门面都经同一个 handler，所以 `caly-app::contract.rs` 的整值比较自动把新字段
  纳入 parity 判定。
  会改变的只有"显式设了 `max_bytes` 的调用方"——过去那个字段是装饰，现在它是一份真的上限。

## 7. 关键阻塞项（更新版）

1. `EngineHandle` 绑死 `InMemoryStorage`，storage trait 的“可替换后端”拿不到（最高优先）
2. `run_ready()` 的同步 poll 一次模型，任何会挂起的 future 都会变成运行时报错
3. pipeline 仍未接真实 source parse / normalize
4. `engine -> caly-mihomo / caly-singbox` 的具体依赖（已登记 `KNOWN_ARCH_DEBT`）
5. capability 执行路径仍读内建 default，而非 JSON 工件（漂移已可测，来源未切）
6. `caly-ipc` 缺真实双工 transport runtime
7. `caly-mihomo` / `caly-singbox` 未接真实 binary / runtime API
8. security / secret / redaction 未进入实现层
9. 无 CI：`scripts/check.sh` 只是本地入口，门禁未被强制执行
10. ~~`Fs` Port 没有目录列举~~：第十五轮加了 `list` / `ListCap` / `Meta.mtime`，第十六轮删掉了
    落盘后端自建的 `manifest/*.idx` 索引（`ADR-035 §6bis-ter`，`ONBOARDING_NOTES.md §4.15`）。
    仍开着的两条：**grace period 还是只吃调用方注入的 `stored_at_unix_ms`**（端口 mtime 有值但无人读，
    未知年龄一律保守不删），以及**孤儿内容没有清扫者**（先删元数据再删内容，中间崩溃留下的内容文件
    没有任何东西会发现：内容在三层目录下，而端口只保证一层列举）
11. `caly-io-std` 只有 `Fs` + `Clock`：`Http` / `Proc` / `Platform` 适配器缺失，因此 `RFC-0006 §15`
    契约第 3、4 条无法覆盖；且任何真实等待（下载订阅、spawn core）都仍被 §7.2 的执行模型缺口挡住

已不再是阻塞项：`operation.rs` 无重复导出告警（§3.2）；storage/recovery/daemon 接线（§2.2 已更正）。

---

## 8. 建议的下一实现阶段

### 8.1 落盘后端（阻塞项 1 的剩余部分）

- 缝隙已开好：`caly_storage::StorageBackend` + `EngineHandle::with_backend(..)`；
  参考实现见 `crates/caly-engine/tests/storage_backend_swap.rs` 里的 `FlakyStorage`
- 需要落盘实现 + 崩溃语义（写入顺序、fsync 边界）；这两点应由 ADR 冻结
- executor 归属仍待定：要么引入最小 `block_on`，要么把 storage trait 改回同步（需要 ADR）

### 8.2 真实 effect 后端

- 用 `caly-io` 的 `Fs` / `Proc` / `Platform` Port 实现 `EffectRuntime`
- 让 `SimulatedRuntime` 与真后端在同一组断言下跑（ADR-022 的对偶要求）

### 8.3 Capability 来源切换

- 决策：registry 从文件加载（含失败/离线语义），或明确“文件仅由代码生成”
- 若保持后者，则把 `REGISTRY_PATH` 改为“导出物”而非“输入物”，并更新 ADR-024 措辞

### 8.4 测试补面

- `caly-ipc` codec/session/handshake 单测
- mihomo / sing-box 产物字节 golden 测试
- facade parity 断言化
- 纯核心确定性/记忆化测试（RFC-0003）

### 8.5 CI

- 把 `scripts/check.sh` 放进 `.github/workflows`，并把 clippy 基线改为“新增即红”

### 8.6 格式收口

- 一次独立 `cargo fmt --all` 提交，然后把脚本里的 fmt 从 note 升级为 fail

---

## 9. 维护规则

- 只有文档落地 -> `Documented`
- 只有目录和空文件 -> `Skeleton`
- 有可编译的部分逻辑或 partial slice -> `Partial`
- 有持续替换 placeholder 的中心逻辑 -> `In Progress`
- 满足当前阶段完成定义**且有测试支撑** -> `Done`
- 任何“已通过验证”的表述必须附带可复现命令，否则不得写入本表

不要把“代码变多了”误标为 `Done`，也不要把“已经存在但粒度不够”误标为“未开始”
——`ONBOARDING_NOTES.md §2.2` 就是后者造成本轮重复核对的实例。

---

## 10. 一句话原则

> Caly 的中心主链现在能被**执行**而不只是被**规划**；
> 下一步的判据不再是“又多了一个 façade”，而是“落盘后端与真 IO 适配器接进来之后，那 95 个断言是否依然全绿”。
