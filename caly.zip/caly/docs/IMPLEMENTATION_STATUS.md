# Caly Implementation Status

本文件用于跟踪 Caly 从“架构冻结”走向“可编译、可验证、可演进控制平面”的当前实现状态。

**重要说明**：

> 本状态表反映当前 workspace 内可见的真实工程推进情况。它不是发布说明，而是工程盘点、差距列表与下一阶段排序表。
>
> 本版按 2026-08-30 的**实测结果**收口。重写原因见 `docs/ONBOARDING_NOTES.md §2`；source slice、durable source index、caller 边界与 inspection 投影的偏差、修复和接续教训见 `§4.140`–`§4.151`：
> 上一版把“已经存在的接线”标成未做（`§2.2`），同时把“已经不存在的告警”列成待清（`§2.1`）。
> 现在每一项都附带可复现命令；当前门禁结果以本版 §3 的最后一次实测为准。

---

## 1. 状态标签

| 状态 | 含义 |
|---|---|
| `Documented` | 规范已写出，但尚未进入代码骨架 |
| `Planned` | 已列入实施顺序，但未开始 |
| `Skeleton` | 目录/接口骨架已建立，但实质逻辑很弱 |
| `In Progress` | 已开始实现，且正在替换 placeholder |
| `Partial` | 已具备部分可验证行为或 partial slice |
| `Done` | 已达到当前阶段的完成定义 |
| `Blocked` | 因上游契约、平台或外部依赖受阻 |

`Done` 的判定自本版起**必须有测试支撑**：只有 `cargo check` 通过最多记 `Partial`。

---

## 2. 当前总体快照

| 维度 | 当前状态 | 说明 |
|---|---|---|
| 架构总纲 RFC | `Done` | RFC-0001 已形成 |
| 子系统 RFC | `Done` | RFC-0002 ~ RFC-0010 已形成第一版 |
| 核心 ADR | `Done` | ADR-011 ~ ADR-054 均已定稿；当前 44 份 ADR 为 `Accepted`、0 份为 `Proposed`（另有 ADR-TEMPLATE.md 模板文件自身标 Proposed，非编号 ADR）。`ADR-049` 记录有界 HTTP body、显式 source endpoint、条件请求复用、source-index durable schema；`ADR-050` 冻结 `calyd` 真实 effect runtime 的显式 CLI 组合、资产/运行目录 preflight 与失败语义；`ADR-051` 收口 capability registry JSON 工件的方向（导出物、非运行时输入）；caller deadline/cancellation 的 phase-boundary 实现与 inspection 投影已落地，真正打断 blocking syscall 的运行时仍未宣称。 |
| 端口契约 | `Done`（且已被生产代码调用；`system.gc-plan` 的视图带 `now_source`，两侧逐字段相同）；第二十一轮起 `caly_io::runtime::drive` 是能区分 `Timeout` / `Cancelled` / `Busy` 的**唯一**驱动路径，`block_on_ready` 与 `caly-engine::recovery::run_ready` 都是它的包装 | `caly-io::contract` 是**唯一**一份契约实现，两个后端各自跑它：列举有序、`ListCap` 拒绝而非截断、恰好等于上限不算超、"空目录"与"不存在"可区分、对文件 `list` 是 `InvalidInput`、mtime 要么一致已知要么一致未知且不回退 |
| 存储契约 | `Partial` | `caly-storage/tests/object_contract.rs`：同一组断言跑 `InMemoryStorage` 与 `FsStore`，已抓出两处后端各说各话（`ONBOARDING_NOTES §4.46/§4.47`） |
| 术语/风格文档 | `Done` | `GLOSSARY.md` / `STYLEGUIDE.md` 已形成；`CONTINUATION_PLAYBOOK.md`（第三十一轮）记录接续开发的工作流程与门禁清单 |
| 接手审计 | `Done` | `ONBOARDING_NOTES.md`：155 条留档（文档/代码偏差、结构性坑、已修缺陷与自查），且新增一条**自我维护**的门禁：`caly-arch-test::docs` 每次 `cargo test` 扫 `docs/**` 检查表格/编号/引用路径 |
| Facade 契约 | `Partial` | `docs/REMOTE_FACADE_PARITY.md §3bis`：读侧、写侧、错误身份、角色、CAS、幂等与事件内容 parity 均有门禁；通用 IPC runtime 仍未完全接入生产 transport |
| Cargo workspace | `Partial` | 20 成员（`cargo metadata` 实测）；直接外部依赖只有 `caly-daemon` 的 `serde_json`，由 `ADR-046` 授权用于 sing-box JSON 信封结构合并，其余直接依赖为 workspace path；`cargo check --workspace --all-targets` 0 warning |
| 源码级契约 | `Partial` | `caly-api` / `caly-plan` / `caly-ipc` / `caly-io` 接口层可编译 |
| 可验证性 | `Partial` | 813 个行首 `#[test]` 断言（105 个文件；数字来自 `python3 scripts/regenerate_test_census.py`，`cargo test --workspace` 门禁 floor 同步为 813）：中心主链、source ingest、durable source index、**source-index 记录各损坏形态的参数化拒启证伪（opaque cache 锚点、raw SHA-256 格式、未知字段/版本、缺字段、空 identity/locator、零上限、坏时间戳、worker 恢复的 raw CAS metadata 不一致、304 复用丢失/未校验字节）**、门禁、恢复、回滚审计、IPC 框架层、跨后端 Port 契约、落盘与重启恢复、**contract/parity 判定**、**脱敏边界与导出内容**、**128 行 scenario 套件的判定者** |
| 过载与拒绝 | `Partial` | `QueueFull` 与 `StorageBusy` 已有完整生产路径（入队前拒绝、cutover journal intent refusal、store port `Busy`）；拒绝在改状态**之前**判定，公开错误与 doctor/bundle 按类别汇总；`EventBacklog` / `StreamBackpressure` 仍缺完整生产模型与合并/丢帧策略，见 `OVERLOAD_AND_RETRY_MODEL §2ter / §10` |
| 权限与幂等 | `Done` | `ADR-037`（第十四轮定稿并落地）：`required_role` 在两条路径上都可失败（本地与 session 默认都是 `Operator`，更高权限要组装根用 `DaemonApp::set_local_role` 显式声明）；`Idempotency::Required` 缺 key 被拒、空白 key 对任何命令都被拒（它是一个共享桶，不是 key）；`RequestMapError` 带 kind，`PERMISSION` 与 `CONFIG_INVALID` 不再混报；去重窗口只淘汰已完成条目并报告`evictions`；本地 `request_id` 单调分配，`Command.id` 不再是 `req-0` |
| 读侧有界性 | `Done` | `RFC-0002 §9` / `§11.4`：两条大读都有响应上界，且**截断必须被报告**（`SupportBundleView::truncated` / `JobEventsView::next_from_event_index`）。事件窗口读的默认页与上限在 `caly-daemon::paging`，`max_lines: 0` 被 `CONFIG_INVALID` 拒绝而不是被猜成「那就用默认」；导出读的 `max_bytes: 0` 则**照做**（空文本 + `truncated = true`）—— 两者语义不同：「给我 0 行」是自相矛盾的请求，「我只要头部」是可诚实满足的请求 |
| 存储诊断 | `Partial` | `caly-storage::audit` 实现 `STORAGE_RECOVERY §9.2` 四项发现；`doctor` 不再输出占位 warning |
| IO 网关实现 | `Partial` | `caly-io-std` 已实现 `StdFs`、`StdClock`、`StdHttp`（HTTP/1.1、`http://`、有界 body、条件请求、注入 clock 的 caller cancellation/deadline 边界；`https://` 按名 `Unsupported`）与 `StdProc`（shell-free spawn、try_wait、stop）；`StdFs` 的 list/mtime 已被 `FsStore` 的枚举与对象定年实际消费。`Platform` 仍是**决策性缺席**，不是伪造的能力承诺（`ADR-042 §2.2`）；单个 OS blocking syscall 的中途中断不虚构。 |
| IO 仿真层 | `Partial` | `caly-io-sim` 提供 `SimFs` / `SimHttp` / `SimProc` 等确定性替身与共享契约测试；`SimHttp` 与 `StdHttp` 共享 caller deadline anchoring/check 语义并有取消/过期裁判；它只进入测试/开发路径，**不进入生产依赖**是边界而不是缺口。 |
| 共享上下文模型 | `Partial` | `TraceId` / `Actor` / `RequestContext` / `IoBudget` 跨 crate 贯通 |
| 通信协议分析 | `Done` | framed JSON over UDS / Named Pipe 已文档冻结并下沉代码 |
| App client layer | `Partial` | local/remote facade、loopback、contract/parity/scenario 可编译**且被判定**；parity 改为共享同一个 daemon（此前比的是两个进程） |
| Domain / IR / Core | `Partial` | 已从类型骨架推进到可执行 vertical slice |
| Pipeline / Apply 主链 | `In Progress` | merge/resolve/validate/compile/apply + **effect 执行**已闭合到内存后端 |
| Effect 执行 | `Partial` | `caly-engine::executor` 解释 typed `EffectStep`，含三阶段与 verify 门禁；`StdEffectRuntime` 已能由 `DaemonApp::set_effect_runtime` 显式注入并经 mihomo/sing-box 真核测试；`calyd --effect-runtime real` 已在 listener 前完成 runtime/assets preflight 并在 recovery 前构造选定 runtime，默认 `EngineHandle` 与 `calyd` 仍使用 `SimulatedRuntime` |
| Storage / Journal / Snapshot | `Partial` | 后端可替换（`Arc<dyn StorageBackend>`），第二后端 `FsStore` 经 `caly-io` Port 落盘、内容寻址、写入即校验；**schema 版本已成为盘上事实**，不匹配/更新版本/损坏一律拒绝启动 |
| Durable source index / provenance | `Done`（当前 source 阶段） | `StorageBackend` 的 source-index put/get/list/delete、`FsStore` D3 record、`InMemoryStorage`、typed opaque cache codec、启动恢复、raw CAS 内容/metadata/size/sha256 校验、200/304 发布与 locator 变更失效均已接入；真实 fixture 的 FsStore/SimFs 跨重启裁判通过。Source update 已在 HTTP 前后、parse 前后、CAS 后及 D3 commit 前按同一注入 clock 做取消/deadline 边界检查；daemon source inspection 从 durable record 投影 provenance/diagnostics 并统一脱敏。StdHttp 的单个 blocking syscall 仍只能由 socket timeout + post-call probe 约束，不能宣称即时中断。 |
| CAS 内容 | `Partial` | `CasWriteIntent` 携带载荷，`materialize` 前重算 sha256；`§6.3`"不得静默容忍损坏"可被测试触发 |
| GC（`§13`） | `Partial` | root 集（active/LKG/retained snapshot/revision/未完成 journal/running/grace）+ 对象/内容计划 + 上限 + 资格门禁已接入 engine service；`system.gc-plan`、`system.gc` 与默认关闭的 `gc.idle` automation 都有生产路径；schema 迁移与更高效的批量定年仍未做 |
| Recovery | `Partial` | 启动扫描 + 决策 + 回滚补偿可运行；扫描现在同时覆盖 `Pending` 与 `RecoveryFailed`；真接管未接 |
| Capability 校验 | `Partial` | registry/coverage 驱动求值已进流水线；JSON 工件与代码的漂移已有门禁，但执行仍读内建 default |
| RuntimeDriver | `Skeleton` | trait 与 mock 在；真 runtime API 未接 |
| CLI | `Partial` | `caly-cli` 已有 `caly` binary target；status、profiles、apply、rollback、jobs/follow、gc 与 support-bundle 均有真实 calyd E2E，TUI 仍未创建 |
| 真实部署与回滚 | `Partial` | `FsStore` 已能落盘并重启恢复；`StdEffectRuntime` 已对 mihomo/sing-box 做真实 spawn、controller probe、stop 与 rollback 测试；`calyd` 组合根支持显式 `--effect-runtime real --runtime-root … --assets-dir …` 及启动前 preflight，默认仍是 `SimulatedRuntime`；跨进程 core adoption、Platform/TUN 与完整 OS 网络副作用不覆盖 |

---

## 3. 编译与检查状态

### 3.1 当前结果

```bash
cargo check --workspace --all-targets     # 通过，0 warning
cargo test --workspace                    # 813 passed / 0 failed（门禁 TEST_FLOOR=813）
cargo clippy --workspace --all-targets     # 31 个 distinct locations，未超过 CLIPPY_BASELINE=31
cargo fmt --all -- --check                 # 0 行（第八十七轮 rustfmt 了本轮 touched 的 ipc/calyd/caly 文件，这些文件上的既有漂移一并消除；第七十四轮口径 331 是当时 touched 文件收口后的 advisory）
cargo test --workspace --no-run            # 92 个 executable targets：22 个 unittests + 70 个 integration tests
                                           # 口径：`grep -E 'Executable (unittests|tests/)'` 数输出行；不要再拆成旧的 doc-test 目标
./scripts/check.sh                         # 本轮完整门禁通过（813 / 31 / 0）
python3 scripts/regenerate_test_census.py --check   # §3.3 的表是否与树一致（不改文件）
# 门禁各步的原始日志留在 target/gate-logs/（解析失败时靠它复盘，见 ONBOARDING §4.65）
```

规模（`find`/`wc -l` 实测，排除 `target/`）：**262** 个 `.rs` / **92,582** 行 Rust / **813** 个行首 `#[test]`（105 个文件）/ **92** 个 executable test targets（22 个 unittests + 70 个 integration tests，`contract.rs`/`selfcheck.rs` 各有两个 crate 的同名文件各算一个；产出它们的命令在上面那个代码块里） / **93** 篇 Markdown（`find . -name "*.md"` 排除 `target/`：docs/ 91 + 根 2）；成员 **20**。
直接外部依赖只有 `serde_json`（由 `ADR-046` 授权），不能再把当前 workspace 写成零外部依赖。
`grep -rn "std::fs\|std::process" crates/` 在 `caly-io-std` 之外**没有任何生产代码命中**，
"单一 IO 网关"因此是可检查的事实而不是一句声明。
`executor.rs`（1,386 行，纯解释器）与 `sim_runtime.rs`（689 行，确定性世界模型）已拆分；
`execute_profile_apply` 从 383 行拆成 7 个相位函数（第二十七轮加 `cursor_guard_failure`），其中最大者
83 行（`commit_snapshot`，本轮未动）。口径 = 花括号配对数出的函数长度（含签名行），第二十七轮实测：
`gate_capability` 39 / `report_planning` 17 / `persist_projection` 38 / `execute_effects` 52 /
`commit_snapshot` 83 / `cursor_guard_failure` 54 / `execution_failure` 53。
（`consume_one_skeleton` 仍是那个既有的命令分派大函数：227 行，本轮未改其形状——只在它调用的
`execute_effects` 里加了 guard。）第二十八轮另加一个文件：`crates/caly-storage/src/port_drive.rs`（86 行，
store 驱动端口的预算与那张唯一的 fault→kind 表）；`fs_store.rs` 1,266 行、`schema.rs` 499 行、
`caly-io-sim` 的 `fault.rs` 216 行 / `port_impl.rs` 747 行。

### 3.2 关于 warning 的更正

上一版在此处列举了“DTO 重复 re-export、unused import”等告警。**当前不存在任何编译告警**；独立的 clippy 门禁仍报告并棘轮 31 个既有 distinct locations。

复现时务必先强制全量重编，否则 cargo 会用缓存而不重放告警，容易得出相反结论：

```bash
find . -name '*.rs' -exec touch {} +
cargo check --workspace --all-targets 2>&1 | grep -cE '^(warning|error)'   # 0
```

因此 `API_DTO_MIGRATION_PLAN.md` 中“清 warning”这一动因已消失；该文档剩下的价值是
**收敛 `operation.rs` 的职责边界**，不是消除诊断信息。

### 3.3 测试覆盖的真实分布

按文件实测（**105** 个文件、合计 **813**）。计数口径与被检的断言一致：只数**行首**的 `#[test]`
（`caly_arch_test::docs::count_test_attributes`）—— 讲「测试计数」的测试必须在散文里写出这个记号，
子串匹配会把说明文字一起数进去。复现：

```bash
for f in $(grep -rl '#\[test\]' crates --include='*.rs' | sort); do
  printf '%3d  %s\n' "$(grep -c '^[[:space:]]*#\[test\]' "$f")" "$f"
done                                  # 合计与逐行之和由门禁复算
```

本表由 `scripts/regenerate_test_census.py` 生成（`--check` 只报不改），描述列保留人工内容、只重算数量。
复算裁判是门禁 `crates/caly-arch-test/tests/doc_consistency.rs`，每次 `cargo test` 都跑：
任何一行改了数量而代码没跟着改（或反之、或新增了测试文件忘了加行）都会失败。

| 测试位置 | 数量 | 覆盖的断言 |
|---|---|---|
| `crates/caly-api/tests/error_doc.rs` | 6 | ERRORS.md §4/§4.1 名称闭包 + §4↔`category()`/`retry_policy()` 双向 + `ApiError::for_code` 消费默认权威（第八十六轮：Always→true，其余→false） |
| `crates/caly-app/tests/budget_parity.rs` | 2 | 补上第二十一轮欠下的那条端到端断言：**预算花光的 `profile.apply` 在两条门面上得到逐字段相同的答案**（state / failure_code / summary / event_count 全等，读的是各自 façade 的 `JobFollowView`，没有任何私有字段被打开）；以及"不写预算"与"明写 64"不可区分 —— 如果 `remote.rs` 那一行不再转发，远端会花掉 daemon 的默认预算、把 apply 跑成成功，这条比较当场停止匹配 |
| `crates/caly-app/tests/contract_gate.rs` | 6 | contract / parity / scenario 三套报告必须**全绿**且非空；parity 在真实部署之后比对同一个 daemon 的两条路径；`run_smoke_bundle` 的 128 行逐行判定（行数下限 100，防止「只聚几行必过项」冒充套件） |
| `crates/caly-app/tests/error_identity.rs` | 6 | 错误身份跨路径一致：daemon 的拒绝保持 `CONFLICT`/类别/不可重试/remediation，传输失败仍是 `UNAVAILABLE`，调用方 trace_id 不被 façade 改写，façade 源码里有损 wrapper 必须为 **0** 处（计数棘轮已在第十一轮改成绝对断言） |
| `crates/caly-app/tests/write_parity.rs` | 10 | 写侧 parity：四条 case 两条路径逐条比对、无 key 的写必须每次都跑、同 key 必须复用原 job 且答案逐字节相同、部署必须报出引擎分类的影响、读回内容两条路径一致（含反-vacuity：必须真的读到 bytes 且摘要三者相等）、**按 3 行翻页走到末尾之后两侧仍逐行相同** |
| `crates/caly-arch-test/src/docs.rs`（单元） | 24 | 文档形状规则本身可证伪（第二十八轮起包括处置表的**相邻性**：行与行之间隔一个空行就等于表格到此为止，编号检查看不出、渲染出来是一段话）：列数失配、缺分隔行、行内代码与转义竖线不算列、列表连号（空行后重新起算合法）、小节号唯一（`3.` 与 `3` 同号）、通配符不当作断链、注入式存在性判定、实测数字与合计自洽；第三十一轮两条：文档索引双向核对、处置表行必须以 ` |
| `crates/caly-arch-test/tests/dependency_direction.rs` | 11 | 依赖方向、陈旧允许边、纯核心符号、债务棘轮、成员覆盖；第二十七轮加：`production_code_drives_effect_plans_through_the_cursor_entry_point` —— 生产代码（`crates/*/src/**`）不许调用无游标的 `execute_effect_plan(`，注释行除外，`caly-engine/src/executor.rs` 自己豁免（它就是那句委托）。它的裁判方式被写进测试名里：**行为不变的违规**（多一个不接游标的接缝）只有这条门禁会红；第二十八轮加：`the_durable_store_drives_ports_through_the_shared_budget` —— `crates/caly-storage/src/**` 不许出现 `block_on_ready(`（唯一豁免 `audit.rs`，它驱动的是已经带类型的 `dyn StorageBackend`，并附一条「扫到的文件数 ≥ 8」的反空转断言，免得门禁自己悄悄变成零）；第二十九轮加：`every_backend_that_runs_the_fs_suite_runs_the_byte_budget_check_too` —— 任何跑了 `fs_contract_violations` 的后端套件必须也跑 `fs_byte_budget_violations`，否则新加的契约检查会悄悄变成仿真器独有（`ADR-022` 最怕的形状）；门禁自己带一条"应当恰好找到 2 个后端"的断言，免得它退化成扫 0 个文件；第六十八轮加：`the_registry_artifacts_are_exports_not_runtime_inputs` —— 生产 `crates/*/src/**` 不许出现「工件 token 与取数调用同行」（`read_to_string`/`fs::read`/`File::open`/`include_str!`/`include_bytes!`）；仅命名常量不算（命名≠读取）；它是 `ADR-051`「工件=导出物」的机器裁判 |
| `crates/caly-arch-test/tests/doc_consistency.rs` | 7 | **扫遍 `docs/**`**：引用路径必须存在、表格/列表/编号形状、crate 名合法、`§3.3` 的实测数字与树一致；含一条反-vacuity 断言（文件数 / 引用数 / 行数下限）；第三十一轮加第 7 条：`the_document_index_lists_every_top_level_document` —— `docs/README.md §1` 的目录树 ↔ `docs/*.md` **双向**一致（新文档不写进索引 = 没人会读它；索引留着已删的文件 = 一句空头承诺） |
| `crates/caly-cap/tests/registry_drift.rs` | 8 | registry / coverage JSON 与内建 default 双向一致、解析器健壮性 |
| `crates/caly-cli/tests/caly_cli_e2e.rs` | 25 | **第二个可执行程序**（第四十四轮，`caly` CLI）：对真 `calyd`（双 binary 互通）——`caly status` 打印九字段且与**独立 oracle 读者**（测试自带最小 wire 实现，非共享 codec——两实现一致才是证据）逐值对齐；daemon 不可达 = exit 12 点名地址；缺 `--addr` = exit 2 不碰网络；哑服务端（accept 后一言不发）= **exit 11 超时**而非挂死（读超时 3s，变异 M1 死锁暴露的产物缺陷）；第四十五轮起 `caly doctor`（三层行与计数经独立 oracle 对齐、gc 行的活时钟段按稳定前缀判）、第四十六轮起 `caly profiles`/`caly profile <id>`（清单计数与逐行、视图全字段对独立 oracle parity）、第四十七轮起 `caly apply`/`caly jobs`（acceptance 三字段上纸、job 已跑完才读得到、事件行与计数对独立 oracle 全串 parity——终态 job 事件不可变，无稳定前缀豁免；缺 `--idempotency-key` = exit 2 点名旗标——CLI 不代铸 key）、第四十八轮起 `caly job`（follow 摘要全字段 parity）、`caly rollback --snapshot`（点名快照进 job 事件行、缺 key exit 2）、`caly jobs --from/--max`（**分页平铺裁判**：截断页游标非空、续读页到头、两页拼接==整窗——一行不丢一行不重）、第四十九轮起 `caly gc-plan`/`caly gc`/`caly support-bundle`/`caly bundle [<digest>]`（plan 对独立 oracle 标量 parity、gc 缺 key exit 2+重放同 job+下一张 plan 能看见 last_run、bundle 无参=最新、`--max-bytes` 截断如实报、text 原样上纸）、第五十轮起全动词 `--json`（输出=daemon 的 JSON 原文一行；事实与 records 面**逐键等同**——测试自带独立扁平 JSON oracle 对 records oracle 比对）、第五十一轮起 `caly follow <id> [--from N]`（流式打印、退出码=判决：Succeeded 0/Failed 1/Cancelled 15/TimedOut 11、state-gap=14 CURSOR_STALE 带 resume 提示；行与 `caly jobs` 逐行 parity——两个动词一个投影）、第五十二轮起 `caly follow --resume <stream-id>`（打印过的即 ack——确认是对话最后一帧，读到它重连才确定性；stderr 报 stream id 供恢复用；acked resume **零重印**）、第八十五轮起 **入站超 cap 头即拒**（假 daemon 只写 5 字节超 cap 头、永不写声明长度：CLI <2s 以 exit 13 点名 inbound cap——手写 vec-len 路径会卡满 3s 读超时变 exit 11）；第八十七轮：caly status 走 unix 域套接字（同一 BindSpec/WireStream） |
| `crates/caly-cli/tests/exit_code_table.rs` | 3 | （本轮新增，见 `docs/DEVELOPMENT_LOG_2026-08-27.md` 对应小节） |
| `crates/caly-common/src/digest.rs`（单元） | 5 | SHA-256 NIST 向量、分块与填充边界、`sha256_matches` 的严格语义 |
| `crates/caly-common/src/lib.rs`（单元） | 4 | `Ctx` 默认不带去重句柄、`with_idempotency_key` 只加不改其它字段（`ADR-021` 末尾的向后兼容扩展规则） |
| `crates/caly-common/src/redact.rs`（单元） | 20 | `RFC-0010 §6.2` 每条规则各有正反例：幂等、无误伤（digest / 公共地址 / 端口不被掩）、Strict 才动的 `§4.1` 准 secret、字面量登记 |
| `crates/caly-daemon/src/bin/calyd.rs`（单元） | 2 | `EffectRuntimeSelection` 的默认 simulated/real-only 参数拒绝、real 模式必须同时提供非空 runtime/assets roots；详见 `ADR-050` 与本轮开发日志 |
| `crates/caly-daemon/src/effect_std.rs`（单元） | 2 | 供应链围栏的正面裁判：计划钉的 binary digest 与后端**将部署的字节**的 sha256 不符 → `binary-digest-mismatch` 点名拒绝（两个摘要都在拒绝语里），且拒绝发生在任何字节落盘之前（runtime 目录不得出现）。摘配的快乐路径由 `real_apply.rs` 端到端判 |
| `crates/caly-daemon/src/job_stream.rs`（单元） | 6 | **第一个流泵**（第五十一轮，`IPC_STREAM_POLICY` 首段真实现——Job 流=LosslessResumable/Ack Required/gap 不 reset）：纯状态机，喂**从 cursor 起读的页**，每步一答——Data（新行+游标）/Gap（`reset_required`→报 resume 位置，**无损流绝不跳**）/End（终态且行已冲净——先行后终，End 早到=对完整性撒谎）/Wait（无新闻不推空帧）；非终态不猜判决（waiting_input 是状态不是判决）；`timedout`（`{:?}`-lowered 无下划线）→TimedOut |
| `crates/caly-daemon/src/local_facade.rs`（单元） | 2 | 本地门面把 `Ctx.io_budget` 原样写进 envelope；没有预算时也**明说**当时生效的那个默认（第二十四轮起是有界的 `default_command`，不再是 unlimited）而不是留 `None` 让 daemon 猜 —— 同一条请求在两条门面上必须有同一个答案 |
| `crates/caly-daemon/src/paging.rs`（单元） | 13 | 事件页的四条规则各一条（默认不是上限、超上限被夹、0 被拒而不是被猜、wild 值仍然离帧上限很远），外加第二十九、三十轮的诊断上界那一组：预算内什么都不说（反占位符）、行数越界**仍在计数**、单行超长是**就地缩短**且把省略量写进文本、字节预算可以先于行数预算咬下来、首行永远被带出（与 `caly-engine::job_follow` 同一条规则，一个 crate 不许有两种答案）、说明行必须装得下它自己的预留、`may_claim_clean` 的四种组合 |
| `crates/caly-daemon/src/request_map.rs`（单元） | 4 | 入站 `io_budget` 原样抵达 `Command.context`；缺失才用 daemon 默认，且那个默认与门面侧写的默认**是同一个值**（`default_command`，64 次计入的 store 访问；两处各写一遍就是下一次漂移的来源）；相对 `deadline_ms` 被转发但**不被伪造**成绝对期限（daemon 无单调时钟）；远端路径安装惰性 token 而非假装的转发 |
| `crates/caly-daemon/tests/apply_command_path.rs` | 5 | envelope→command→job→执行→snapshot、越权拒绝、启动恢复、回滚保留快照 |
| `crates/caly-daemon/tests/calyd_wire.rs` | 38 | **第一个可执行程序**（第四十三轮，`ROADMAP §1bis.2` 的 0→1）：spawn 真 `calyd` 二进制、真 TCP、v0 记录帧——hello→ack（点名 daemon 与 instance）；`runtime.status` 端到端应答且**九字段全上 wire**（空值也在：客户端能分"没有"与"忘了"）；白名单外 op 按名拒（`UNSUPPORTED` 点名所问与唯一在册者）；hello 前请求拒（`HELLO_REQUIRED`）；超 `MAX_FRAME_SIZE_BYTES` 的帧**连接终结**（拒帧=先吞后答，恰是被禁的形状）；第四十五轮：**并发裁判**（哑客户端占一连接时第二个客户端照常被服务——单连接循环下构造性失败，线程化后哑连接只花自己的超时）与 **doctor 裁判**（在册 op、三层计数==随行索引行数——计数撒谎即红）；第四十六轮：profiles 裁判（计数==`profile_{i}_id` 行、id 唯一、至多一个 active、计数外无行）、**第一个带参 op** 裁判（缺 `profile_id` → 点名 USAGE 拒绝、拒绝后**会话照活**、视图回显所问 id——答 default 的视图算答错）、会话空闲裁判（`--session-idle-ms 1200` 下 1.2s 收割——若回落到 socket 上残留的 5s hello 期限即红；一个常量管两种策略时此题不可证伪）；第四十七轮：**第一个 command 上 wire**（`profiles.apply` + 内联 drain——读到 acceptance 时 job 已终态、`runtime.status` 能从查询面看到 active_profile 变化、同 idempotency key 重放同 job id/新 key 新 job、缺 key 是 daemon 自己的点名拒绝）、`jobs.events` 裁判（state==completed、计数==行、计数外无行）；第四十八轮：follow 裁判（**跨 op 一致性**——follow 的 event_count 必须等于 events 分页的计数、未知 job 是点名拒绝不是编造的 summary）、rollback 裁判（**点名快照反猜**——两个不同 profile 两个快照，点名回滚的 job 事件行记 `target=<所点名>`；吞参变异恒用 LKG 即红；缺 key 拒绝+同 key 重放同 job）；第四十九轮：gc-plan 裁判（**查询问两遍除活钟外必须全同**、`now_source`==storage-clock——`ADR-038 §3` 钟自报家门、collect/orphan 计数==行）、gc 裁判（**门口 bounds 拒绝**——`max_deletions=0` 是 CONFIG_INVALID 点名且**不产生 job**、缺 key 拒绝、同 key 重放、跑过=plan 的 `last_run` 是 Some——与"从没跑过"不同答）、bundle 裁判（无 key 也收——`Idempotency::Optional`：重导出不是第二次破坏性写；digest 在 job 事件行 `object=sha256:…`；读回 digest 回显+content_sha256==digest+`truncated` 只在 `max_bytes` 真截时为真；**伪 digest 是拒绝不是读**——RFC-0010 §12.3 不可绕）；第五十轮：**JSON 会话裁判**（同一 daemon 双会话问同一 op——键值集除 request_id 外必须全同：**编码改变事实的写法、绝不改变有哪些事实**；索引行 doctrine 在 JSON 里同样成立）、坏 JSON 裁判（USAGE 拒绝**本身也是 JSON**——一个会话一个编码；会话照活）、未知编码裁判（HANDSHAKE 点名拒——值不可解析就不许猜含义）；第五十一轮：**第一个流裁判**（opened→DATA→END 三帧契约、DATA 计数==events 分页计数——跨 op 一致性延伸到流、END 带 verdict、JSON 会话里流帧也是 JSON）、游标裁判（from=N **exclusive**——与 next_from_event_index 同一契约、平铺==整窗）、幽灵 job 裁判（**opened 帧之前先查存在**——为不存在的 job 开流=为先撒一个流再补一个意外）；第五十二轮：**reconnect 裁判**（acked 流 resume=**空 delta**——确认帧 acked_upto 是屏障，读到即确定 daemon 已记账；未 ack 流 resume=**全量重放**——emitted≠acked，resume 游标取调用方确认过的、绝不取服务端碰巧发出的）、未知流 resume/ack 点名拒、**流表有界**（第 65 个流是点名容量拒绝——无界流表是穿着功能外衣的泄漏）；第五十三轮：**worker 线程裁判**（acceptance=已排队——慢 tick 下第二连接立刻查到 `state=accepted`/0 事件，R47 的"读到 acceptance 已跑完"形状退役；活流裁判——opened 帧之后 300ms 静默窗内不得有 DATA（有=又内联了），worker 的 tick 到点化作 DATA、END 带判决）、**断线收割裁判**（5s tick 下客户端 opened 后即弃线——泵的一个 wait tick 内（2.5s 期限）stderr 必须出现 reap 行：没有零字节探活就得等下一次写失败=≥5s）、**零 tick 旗标拒绝**（exit 2 点名旗标——自旋不是调度）、**非数值参数点名拒绝**（`max_deletions=abc` 是 USAGE 且不吞 key 不产 job；`from_event_index=soon` 拒绝——垃圾游标静默变全量重放是最糟的一个；grace/max_lines/max_bytes 同规）；第六十六轮：**流帧逐字裁判**（`the_stream_data_payload_matches_the_events_page_line_for_line`——DATA 帧的 `event_{i}` 与 events 页的 `event_{i}` 逐行逐字一致（unescape 语义面、顺序、帧拼接==整窗页）+ **计数==行的帧内版**（帧内 `event_count` 必须等于该帧 `event_<digit>` 行数）；行序翻转/行截断/count 少报/多发一行的 4 变异全咬，count-vs-count 裁判对此全盲，见 `IMPLEMENTATION_STATUS §8.4`；第八十七轮：UnixDaemon + UDS hello/status 与 UDS port-file 不是裸 u16（TCP 仍是裸端口号） |
| `crates/caly-daemon/tests/cas_and_impact.rs` | 5 | `expected_revision` CAS 在入队前拒绝（不留下 job）、匹配的 revision 接受且旧的再不能用、重放不受 CAS 阻挡、三类命令各自报出 Restart/ReadOnly/Reload、查询完全不看该字段 |
| `crates/caly-daemon/tests/diagnostic_bounds.rs` | 6 | 两条批量诊断查询的响应上界（`RFC-0002 §9`/`§11.4` + `§4.54`）。**第一条是整份文件的非空性对照**：`without_the_bound_this_answer_would_have_exceeded_the_frame_cap` 量出同一份数据不设界就超过 `MAX_FRAME_SIZE_BYTES`，否则其余五条在"数据本来很小"的世界里全都会绿。其余：守恒律 `carried + omitted == decision_count`（计数不缩到答案大小）、每行不超单行上限且带省略标记、整层连说明行一起不超公开上限、洪水不挤掉 daemon 自己的三句话（recovery/idempotency/gc 计划）、安静时不许出现截断说明、以及"只有行数咬住"的那个组合（`shortened == 0`） |
| `crates/caly-daemon/tests/durable_boot.rs` | 10 | 重启后从盘恢复 `active_profile/active_core/snapshot`；崩溃事务跨多次重启仍报 `Recovering`；盘损坏**拒绝启动**；`Recovering` 拒 apply 但放行 status 与 rollback；后端自相矛盾进 `Failed`；doctor 三项真实发现；未知 job 是类型化错误 |
| `crates/caly-daemon/tests/facade_store_ctx.rs` | 5 | ADR-039 §2 第 4 步的端到端裁判：调用方声明的 16 字节预算被拒词点名 `io_budget.max_bytes`、`deadline_ms: 0` 在注入钟下被拒词点名 `deadline at mono`、读取期端口收到的一切 trace 都是调用方的（不是引擎幽灵）、不声明预算与期限的调用照旧读回（无漂移；这条裁判在首跑就抓住了 `unwrap_or(0)` 把"无期限"变成"立即过期"的静默策略） |
| `crates/caly-daemon/tests/gc_collect.rs` | 6 | 回收周期经完整命令门面：删的就是给操作看过的清单、忙时拒绝且**什么都不改**（含 `state_revision` 不动）、缺 key 的拒绝点名 `system.gc-collect`、越界在入队前就是 `CONFIG_INVALID`、陈旧 `expected_revision` 是 `CONFLICT`、`Viewer` 不能启动删除 |
| `crates/caly-daemon/tests/gc_plan.rs` | 10 | GC 计划经完整门面：孤儿被点名而每个 root 引用的对象都不在表上（且理由写明是哪个 root）、真盘与注入时钟不同源时**拒绝**而不是给出空表、快照记录被带外删除 → 两个可行动的 gap、越界参数是 `CONFIG_INVALID` 而非 store 故障、非 idle 引擎拒答自己的计划、`Viewer` 读不到删除计划 |
| `crates/caly-daemon/tests/gc_run_view.rs` | 3 | `system.gc-plan` 的答案终于带上上一轮回收周期干了什么：没跑过就是 `None`（而不是"跑过、什么也没删"），跑过则**逐字段**等于引擎里那份记录（含 `triggered_by` —— 映射时最容易悄悄丢的就是这种没人会去读的字段），并且客户端那行与 `doctor` 那行**必须是同一句话**（两个渲染器、一个事实；这条断言的存在理由见 `ONBOARDING_NOTES §4.102`） |
| `crates/caly-daemon/tests/idempotency_and_roles.rs` | 7 | `ADR-037` 落地的判定：无 key 的 `Required` 命令在入引擎之前被 `CONFIG_INVALID` 拒绝（且不留下 job、不推进 revision）、空白 key 对**任何**命令都拒绝（它是共享桶）、三道门禁的顺序（角色 → 请求形状 → 状态）、本地默认角色是 `Operator` 且 `Admin` 授权后同一命令可执行、同角色在两条路径上的拒绝文本逐字节相同、本地调用的 request id 不再恒为 0（`Command.id` 可区分）、拒绝次数在 doctor 里可读 |
| `crates/caly-daemon/tests/job_events.rs` | 9 | 事件窗口内容：行的顺序与关键标记（`apply.plan` / `snapshot.committed` / `[done] Succeeded`）、计数与行数自洽、`from_event_index` 为**排他**游标、末尾游标是空窗口而非 reset、未知 job 与摘要查询给出**同一句**拒绝、读回的**行本身仍是掩过的**、**3 行一页走回整窗**、无视上限的请求仍然 `≤` 公布的两个界、`0` 界被 `CONFIG_INVALID` 拒绝且点名是哪个字段 |
| `crates/caly-daemon/tests/outbound_frame_bound.rs` | 1 | `OVERLOAD §5.2` 的出站那一半：服务器循环经 `encode_raw_json_bounded` 编码，超 `MAX_FRAME_SIZE_BYTES` 的载荷**在成为帧之前**被拒（错误点名规则）——一个超界答案是服务器 bug，交给对端拒收是把传输错误冒充 API 答案；小载荷照旧往返（上界不是对诚实答案的新税） |
| `crates/caly-daemon/tests/overload.rs` | 4 | 灌到真实上限（256）之后：拒绝带类别 / hint / 数字而不是裸 `UNAVAILABLE`、拒绝不得把合法的 `expected_revision` 变成 `CONFLICT`、拒完队列不多不少、`doctor` 一条按类别汇总的行（不是每次拒绝一条，也不是错误级） |
| `crates/caly-daemon/tests/real_apply.rs` | 10 | 第五十五轮**真后端三裁判**＋第五十六轮**两裁判**（`effect_std::StdEffectRuntime`＋assets 里钉死 sha256 的真 mihomo/geo，经 `DaemonApp::set_effect_runtime` 注入同一命令路径）。R55：①nightshift 全链——计划真跑到 `snapshot.committed`，真核真活（pid 在 `/proc`、controller 答真 `/version`），测试收尾 `shutdown` 真停（杀后必 sleep 再核验）；②rollback 真停核＋撤文件——spawn 型计划的补偿集扩为 stop-core → un-materialize → net-revert（此前 rollback 对真核补偿**零**步、核照跑），裁判对着进程表断言；③demo-tun 诚实拒绝——`unsupported-net-apply` 的拒绝语（ADR-042 §2.2 deliberate absence）随失败 detail 上 job 事件、无核无 envelope 残留、不激活 profile。R55 写裁判顺带咬出四处"渲染从未被真核读过"的真相并修掉（规则目标指渲染组标签、`dns.enhanced-mode` 只认 fake-ip/redir-host/normal、协议必填参数经 `passthrough` 逐键透传、组内假 `interface-name` 删除）。R56（current 真相，ADR-044 §7）：④restart 赎回——apply 对着引擎最后提交的 artifact 规划，换 profile 判 Restart，旧核被计划的 StopCore **真停**（对着进程表断言，不再是 runtime 层兜底拒绝）；⑤同 profile 再 apply 判 Noop——无步骤无 spawn，核原 pid 不动、controller 照答，`last_apply_plan_summary` 读到 "Noop"。R57（ADR-045）：②改判**复活**——rollback 补偿后由同一 executor 用同一 runtime 把 target snapshot 的 deployment 真部署回去（WriteObject→Materialize→Spawn→ApiReady→**ConfigIdentity 判 target 摘要**），对着进程表断言新核死、旧配置活、B 的文件清、A 的文件回，且复活后再 apply 同 profile 判 Noop（deployment 记忆由复活喂给引擎）。R58（ADR-046）：⑥第二核心端到端——sing-box 真核 spawn（tar.gz 逐字节核对、信封结构合并、clash-api 答 /version），宿主真相＝解包出的 sing-box＋libcronet.so 在实例目录、envelope 无 7890；⑦跨核复活——mihomo 挡道后 rollback，revival 随 core_identity 分派（`sing-box@`→JSON 路径），identity 探针判 `singbox:` 摘要，复活后再 apply 判 Noop。R59（ADR-047）：⑧经核取回——ActiveCore 路由真走活核 mixed 入站（mihomo direct 模式真实取回 example.com 200；无核/停核后按名拒绝），sing-box 段由 apply 内 InboundListening 探针持门开（demo 默认选择是死 wg 隧道，骑乘暂缺，ADR-047 §5.1）；⑨凭据边界——demo 口令只在 artifact 字节里，事件流一字不漏 |
| `crates/caly-daemon/tests/redaction_boundary.rs` | 6 | `§14.1/§14.2/§14.3` 三条门禁：错误在门面边界被掩、job 日志在写入处被掩、bundle 落盘字节无明文；bundle 与 doctor 同一行 summary；升级单向；查询侧类型化拒绝 |
| `crates/caly-daemon/tests/source_inspection.rs` | 1 | 真实 `fixtures/subscription-20260803.txt` 经 daemon `handle_request` 查询 durable source inspection；断言 30 节点、route/validators/provenance 与 locator/label 的统一 redaction，且 facade 返回与 direct query 一致 |
| `crates/caly-daemon/tests/spawn_artifacts.rs` | 2 | **产物字节 golden**（第六十七轮，`§8.4`「mihomo / sing-box 产物字节 golden」）：真 apply 后 runtime root 持有**钉死资产的精确字节**——gz/tgz 拷贝、gunzip/tar 解压出的二进制、两个 geo 库逐字节 golden（测试内独立 gunzip/tar oracle），合并配置由独立 oracle 重建（mihomo=artifact 字节+文档化 envelope 模板**全等** / sing-box=独立 merge 后 `serde_json::Value` **全等**）；目录白名单断言无意外产物（`cache.db` 为核心运行时自产、明确排除在 golden 外）；`falsify_round67.py` 5 变异全咬（geo 交叉写 / envelope 漏 geox / merge 漏 clash_api / strip-components 丢失 / log-level 漂移——只校验资产的裁判对此全盲） |
| `crates/caly-daemon/tests/support_bundle_readback.rs` | 5 | 导出可达：读回的字节与 store 里的完全一致且仍脱敏（命名值与登记字面量都不出现）、省略 digest 取最新一个、**非 bundle 的 digest 在碰字节之前被拒**且错误文本不回显 payload、缺对象是类型化拒绝而非空导出、截断只截响应不跳校验 |
| `crates/caly-engine/src/bundle.rs`（单元） | 8 | `enumeration` 三分法（不支持 / 读不到 / 有内容）、段清单、Strict 升级、「草稿确实含明文」的可证伪断言、身份读不到时不填假值 |
| `crates/caly-engine/src/executor.rs`（单元） | 12 | 阶段分类与单调性、verify-before-commit 门禁、顺序拒绝、崩溃矩阵、journal 状态映射、跳过原因可区分；第二十六轮加：探针时限的边界、时限只作用于探针、`deadline_ms=0` 与策略开关无关、合并证据取**最慢**一段 |
| `crates/caly-engine/src/gc_plan.rs`（单元） | 14 | 计划的纯逻辑：六类 root 各自生效且理由可核对、缺任一类即清空删除列表、retained 采样有界且自报截断、容量推迟不计为保留、边界默认/收窄/拒绝三分、年龄晚于 now 视为时钟不同源、actionable 与结构性缺口的分层、idle 取自引擎自身状态 |
| `crates/caly-engine/src/idempotency.rs`（单元） | 7 | 去重窗口的边界语义：只有**已完成**记录会被淘汰且按 job id 从旧到新、运行中的记录永不被淘汰（淘汰它就是让重试触发第二次部署）、窗口外的那条必须被计数说出去、`(actor, key)` 是键而不是 key 本身、重放读回的是原 `Accepted` 逐字 |
| `crates/caly-engine/src/job_follow.rs`（单元） | 8 | 窗口与分页算术（含端到端碰不到的 reset 分支）：游标比保留起点还旧 → `reset_required` 且不返回半截列表；窗口内 → 从 `from+1` 续上；末尾 → 空但不是 reset；`first_index` 必须就是本切片真正的第一行；页必须能走回整窗、单行超预算仍然返回、reset 不许伪装成一个可用的续读游标 |
| `crates/caly-engine/src/processor.rs`（单元） | 3 | 拒绝不改任何状态（revision / job id / 队列内容）、十次拒绝=十次记录（有界窗口必须自报窗口）、公开错误的每一段（类别、hint、数字、诊断码）都来自同一个映射 |
| `crates/caly-engine/src/recovery.rs`（单元） | 9 | `block_on_ready` 契约、`StorageBackend` 可作 trait object |
| `crates/caly-engine/src/run_limits.rs`（单元） | 8 | 一份 `Ctx` 换算成"能被判的执行限制"的每条规则：`immediate()` 真的什么都不得罪（且不谎报 limits）；相对期限只在有时钟时锚定，没时钟时记为 **unjudged** 而不是"没有期限"；边界已经锚好的绝对期限**不许二次锚定**（off-by-one 也测）；本文件与 `RequestContext::with_deadline_from` 必须算出同一个数；limits 克隆共享取消位；`polls=0` 当 1 处理；`StoreRefusal` 的 kind 与 retry 位来自给答案的那一方，不来自分类；第二十七轮加：store 自己说 `Busy` 才升级成 `StorageBusy`，其余九种 `StorageErrorKind` 一律留作 `Backend`（三种都各有一条断言，且 store 原文必须逐字带出）；第二十九轮加：端口的 `CapacityExceeded` ⇒ `RefusalKind::PayloadTooBig`（`retryable=false` 是推理：重发不会让载荷变小），store 的 `Busy` ⇒ `StorageBusy`（可重试）—— 两个"容量形状"的答案不许塌成一个 |
| `crates/caly-engine/src/service.rs`（单元） | 1 | 回收归属的匹配规则单独钉住：没有 claim 时任何周期都是 `caller`；claim 属于另一个 job 时既拿不到标签也**不会**把它消费掉；只有被调度的那条 job 能取走 `automation:gc.idle`，且只能取一次。写在 seam 上而不是写成端到端用例，是因为今天那条端到端路径**构造不出来** （tick 只在队列为空时跑，而排队中的自动周期会让计划判定 non-idle，人工周期只会被拒而不是插队）——留着这条断言是为了队列一旦有优先级顺序，标签仍然不会串 |
| `crates/caly-engine/src/sim_runtime.rs`（单元） | 9 | 确定性世界模型：identity 采纳与陈旧拒绝、net 事务、DB 事务、物化前置条件、探针一次性、锁前提、派生 id |
| `crates/caly-engine/src/source_persistence.rs`（单元） | 2 | normalized/provenance/diagnostics typed codec round-trip；optional nested provenance and diagnostics fields survive deterministic persistence encoding |
| `crates/caly-engine/src/source_worker.rs`（单元） | 4 | source update 的显式 locator 约束、Http/Sim 取 body→parser→RawSource CAS 的完整路径、304/ETag 条件请求的已校验 raw-body 复用、durable source-index 恢复/发布、locator 变更失效，以及 SourceUpdate job 分支和过程缓存的真实成功路径；含“缺 locator 不猜 URL”拒绝 |
| `crates/caly-engine/src/worker.rs`（单元） | 1 | `worker.rs` 第一次有自己的单元测试，为的是把两张"一个事实一个答案"的表钉住：`BudgetExhausted` 与 `PayloadTooBig` 共用 code/category（`RFC-0002 §14.4` 没有容量码）却**必须**给出不同的 remediation（一个是次数、一个是单次字节，指错等于给半个调用方发错建议）；而 `StorageBusy` 那条**不许**提到 `io_budget` —— 把存储自己的忙说成调用方的错，是编造理由 |
| `crates/caly-engine/tests/apply_execution_gate.rs` | 7 | 中心线端到端、**每个 EffectStep 崩溃后 LKG 不被污染**、恢复决策仅凭 journal、确定性、回滚 |
| `crates/caly-engine/tests/content_orphan_cycle.rs` | 6 | 孤儿内容周期在引擎层的四个事实：走查答案**到达计划**（同一读取半区）、周期执行自己刚计划的孤儿清单（`deleted=0 content_deleted=1` 是磁盘只涨不减的形状）、时间线取存储时钟（同一文件新鲜与过期两个答案）、对象与内容**共享**一个删除预算；另两条：走不了内容树的后端 = gap ⇒ 周期拒绝且一字节不删（`NoContentWalk` 包装后端 withhold 的正是这个能力）、内容树损伤是**报告的 gap** 而非死查询 |
| `crates/caly-engine/tests/ctx_limits_in_apply.rs` | 6 | `ADR-036` 第 2 步落在调用方看得见的那一侧：已取消的命令**在 store 被问之前**就被答复（`list_unresolved_apply` 与 LKG 证明 store 没被动过）；job 记录与 cycle 结果必须说同一件事（`JobState::Cancelled` / `TimedOut`，这两个 `JobOutcome` 变体此前没有生产者）；期限由注入时钟判出来、错误文本必须引用那次读数；**没有时钟就不许把不可判的期限变成拒绝**；限制在场但未被违反时答案与完全不设限制逐字节相同；以及"第一次记下世界已被改动的写不可拒绝，之后的游标移动可以"这半边免疫 |
| `crates/caly-engine/tests/cutover_intent_guard.rs` | 11 | `APPLY_EXECUTION_CENTERLINE §6.1` Phase B 的 pending guard（`OVERLOAD_AND_RETRY_MODEL §6.2` 的那三条要求在代码里的落点）。执行器层 5 条：整条 trace 相等（**顺序**是性质本身，子集断言看不见它）、guard 只覆盖 Cutover 窗口、意图写被拒 ⇒ 那一步不到达 runtime（含 `RolledBack` + 补偿恰好一次）、窗口第一格被拒 ⇒ `FailedBeforeCutover` 且**不得**跑补偿、`NoCursor` 与旧的 `execute_effect_plan` 逐字段相等（证明是「加了一层」而不是「改了一层」）。worker 层 6 条：一次真 apply 在 store 里的写序（pending → 每条 cutover 一步一条 → fold，且 `updated_at` 不倒退）、store 拒绝 ⇒ 世界一分未动且记录这么说、拒绝同时进 `doctor` 的过载行与调用方 `detail`（同一份 `detail()` 拼写）、`IntegrityViolation` 不算拥塞、预算 1 ⇒ 两条接缝共用一个计数器（旧写法会让 apply 跑完）、注入步进时钟让期限正好落在窗口第二格 ⇒ job 结算 `TimedOut` 且 `deadline at mono 2 expired` 出现在 detail |
| `crates/caly-engine/tests/durable_centerline.rs` | 7 | 真流水线跑在落盘后端；**换新 engine + 重开同盘**后快照可恢复、被打断的 cutover 变回决策、第二次 apply 不删旧快照 |
| `crates/caly-engine/tests/effect_runtime_swap.rs` | 1 | 第五十五轮解绑裁判：`CountingRuntime` 包住模拟世界注入 `with_effect_runtime`——注入面每步真被调（计数 >0）、世界真落地（running_core/net_txn 与 sim 直跑一致）、`clone_with_effect_runtime` 后 trait accessor 拿到的是注入者。防"解绑之后没人再调注入面"的静默回归 |
| `crates/caly-engine/tests/gc_plan_and_clock.rs` | 6 | 计划与周期共用一个钟：共享时钟下 grace 边界成为事实（推进虚拟时间即从不可删变为可删）、不注入时钟时拒绝并写明用的基准、周期只删它刚报告的那份清单、被拒也必须留下记录、root 全好但引擎忙这一单独状态也要停、被拒/空跑/删了东西三种结局在记录里互不相同 |
| `crates/caly-engine/tests/idle_gc_automation.rs` | 6 | `ADR-038 §13.2` 的自动收集：没有那张 patch 时跑 24 轮也**一个对象都不动、计数器也不前进**（未授权期间的计数不算数，否则第一次启用会落在无关等待的中段）；启用后在到期的那次检查上真的删掉无主对象，并把 `triggered_by=automation:gc.idle` 写进记录行；**tick 只排队、cycle 才动手**（tick 之后 store 未变、`last_gc_run` 仍空、claim 指向某个具体 job）；空仓库的到期检查**不产生 job 行**；第二次自动周期不复用第一次的幂等 key（否则 dedup 把它吞成重放，收集器安静停摆而记录看着仍然正常）；自动化永不插到调用方命令之前 |
| `crates/caly-engine/tests/latest_bundle_digest.rs` | 3 | "最新 bundle"的选择规则第一次有裁判：最新 `stored_at_unix_ms` 胜、同刻 tie-break 按 digest 确定且**两次同问同答**、更新的非 bundle 对象不因其日期取胜、无任何 bundle 时是 `None` 而不是"最新的任何东西"、无时间戳记录（带外可造）输给任何有日期的 |
| `crates/caly-engine/tests/probe_deadline_gate.rs` | 6 | `ADR-036 §2.5`：探针超时是**验证失败**而不是新状态。预算刚好用完必须放行（`<=` 的边界）；超一点就停在那一步 —— `probe_passed` 仍为假、快照不标、修订不提交，证据里保留 `took=…ms` 以便审计；脚本化的慢速是**一次性**的（否则第二个探针被连坐，而真实计划总是连着发两个探针）；`deadline_ms == 0` 在**碰任何运行时之前**拒掉，且不受 `enforce_phase_order` 影响 |
| `crates/caly-engine/tests/simulated_clock_execution.rs` | 5 | 注入时钟、port 级与 executor 级注入一致、陈旧 identity 阻断 |
| `crates/caly-engine/tests/source_durable.rs` | 13 | 真实 `fixtures/subscription-20260803.txt` 的 30 节点输入：FsStore + SimFs 首次 200 后重启恢复 endpoint/validators/raw CAS/normalized/provenance/diagnostics，第二次条件请求带 ETag 与 Last-Modified 并收到 304；坏 source-index record 拒绝启动；locator 变化删除 durable index；**损坏形态证伪**：raw 对象 metadata 的 size 声明与 record 不一致时 worker 恢复点名拒绝、restore 后 raw body 被改写时 304 复用被 store 读校验拒绝（不静默复用）、`UnverifiedRawStorage` 双端（返回 `Ok(None)` / 返回未校验字节）证明 worker 自己的"cached raw body is missing"与"digest anchor on 304 reuse"守卫可达而非死代码 |
| `crates/caly-engine/tests/storage_backend_swap.rs` | 3 | 换后端跑同一套断言、`Busy` 不造假状态、快照提交失败留下恢复痕迹 |
| `crates/caly-engine/tests/store_suspension_is_contention.rs` | 2 | 同一件事在**上一层**的样子：store 说 `Busy` ⇒ `StoreRefusal::from_storage_error` 必须给出 `RefusalKind::StorageBusy` + `retryable=true` + 驱动器原文（`Internal` 会把它降级成 `Backend`，于是运维那本账少一笔）；反过来，一个只是慢的落盘后端必须把整条 apply 跑成功并交出 last-known-good（旧写法在这里报内部错误） |
| `crates/caly-engine/tests/support_bundle.rs` | 9 | `§9.3` 四项来自真实 store、12 段齐备且有序、CAS 摘要=内容摘要、导出无明文、作业上报句柄、「读不到」不等于「正常」、**拒绝记录进 `overload` 段且空日志必须明说** |
| `crates/caly-io-sim/tests/contract.rs` | 22 | `RFC-0006 §15` 端口契约跑在仿真盘：VPath 逃逸、`D0–D3` 耐久分层、锁竞争；第十五轮起还包括列举有序且受 `ListCap` 约束、空目录与不存在可区分（`dirs` 只记录被写入创建出来的目录）、mtime 只来自注入的虚拟时钟且**只在写时**盖章、没有时钟时诚实地报 `None`；第二十八轮加：注入的 **stall**（计数挂起）在 1 次 poll 下仍不就绪、在 2 次 poll 下答对、且一次性 —— 与 `hang`（永不就绪）分成两种形状，因为「慢」与「卡死」若在测试里是同一个读数，任何 poll 预算都能自称安全；第二十九轮起包括同一组 `fs_byte_budget_violations`，另有 `Http` 一侧的"body 上限与调用方预算取更紧的一条" （`SimHttp` 是唯一存在的 `Http`，所以这条不写成跨后端一致） |
| `crates/caly-io-sim/tests/executor.rs` | 4 | 执行器跑在**真的会挂起的端口**上，而不只是跑在夹具上：一批 `SimFs` 读按提交序返回且字节完整；被 `hang` 的读在注入时钟上判成 `Timeout`（消息必须引用它判的那条期限、时钟必须确实走了 3×20ms、用完的 hang 不再卡住下一次读）；不许动时间时是 `Busy` 并点名卡住的 label （`advance=none, clock=yes`），且时钟一格没走；端口自己的故障**逐字段等于**不经执行器时的那一份（kind、文本、重试位都不许被改写），并且不被重试 |
| `crates/caly-io-sim/tests/simulation_primitives.rs` | 10 | 虚拟时钟推进不回拨、故障注入按 label 命中、场景确定性 |
| `crates/caly-io-std/tests/contract.rs` | 13 | 同一套契约跑在**真文件系统**：VPath、`D0–D3` 分层、无临时残留、root 沙箱、锁互斥；加上共享的列举与 mtime 两条，其中"恰好等于上限必须成功"与"对文件调用 `list` 是 `InvalidInput`"由本文件独有的两条断言各自复核一遍，外加端口故障文本不得泄漏宿主绝对路径；第二十九轮起包括共享的 `fs_byte_budget_violations`：真盘上超限写在**落盘之前**被拒、被拒之后 `stat` 必须说没有这个文件、精确等于预算放行、未设预算不拒 —— 与仿真盘跑的是同一组断言 |
| `crates/caly-io-std/tests/http_contract.rs` | 11 | `StdHttp`（第四十二轮，`Http` 端口的第二个后端）：共享 fetch 契约在**真 socket** 上跑（本地脚本服务器——同一场景两侧同判，`RFC-0006 §15` 对 Http 生效）；条件请求（首取带 ETag、再取以 ETag 相问 ⇒ `304` 原样作答——"没变"是答案不是错误）；`https` 以 `Unsupported` 拒且点明无外部 crate 教义（不冒充连接失败）；拒连以 `Unavailable` 点名地址。传输上界=预算与请求界的较紧者，超界不多读一字节 |
| `crates/caly-io-std/tests/http_route.rs` | 6 | 第五十九轮路由裁判（ADR-047 §2）：ActiveCore 发**绝对形式**代理请求到路由源地址（stub mixed 入站记下请求行；不可解析主机名保证直连必败）、无活核按名拒绝、无路由源点名接线、SystemProxy 按名拒绝不静默直连。R60（ADR-048）：SystemProxy 真骑乘（组合时代理地址＋绝对形式，stub 记请求行）、无代理按名拒绝、`parse_proxy_value` 纯解析（待解析名字/无端口→None） |
| `crates/caly-io-std/tests/proc_std.rs` | 5 | `StdProc`（第五十三轮，`Proc` 端口的 std 后端，`ADR-042`）：共享 spawn 契约在真二进制上跑（空程序名拒绝点名、手柄 pid≥1 且 nonce 非空）；**真子进程 cwd/env 落盘证明**（`/bin/sh` 是调用方自选的程序不是端口包的 shell——shell-free 由结构保证、由行为作证）；缺程序 `NotFound` 点名程序；**缺 cwd 点名 cwd 不赖程序**——OS 层缺程序与缺 cwd 同为 ENOENT，fork 前显式分诊（`§4.138`），映射后才敢说 NotFound 是程序；第五十四轮：**supervision 契约在真活体上**（`/bin/sleep` 新鲜子未退出、stop 宽限期满击杀、退出单调回放、幽灵 handle 双路径点名）＋`/bin/true` 自然退出是它自己的退出（code 0 非信号——宽限窗口的含义） |
| `crates/caly-io-std/tests/real_core.rs` | 3 | **真内核真跑**（第五十四轮，`ADR-043` 的消费者面）：mihomo v1.19.30 与 geoip.metadb/geosite.dat 作为工作区资产**由 sha256 钉死**（`RFC-0010 §14` 第 5 条「下载校验」成为门禁——漂移即红且点名文件与两个 digest）；全生命周期经端口——spawn→`try_wait`=还在跑→核心自己的控制器 `/version` 经 `Http` 端口答 200→`stop` 宽限期满击杀（signaled——数字是信号选的不是核心选的）→退出单调回放→mixed/controller 两端口归还；**geo 承重裁判**：`-t` 层点名 GeoSite 缺失、端口层观察 fatal 自退（geox-url 指向不可达地址——沙箱有网，「顺手下载」必须结构上不可行而非不便） |
| `crates/caly-io/src/budget.rs`（单元） | 4 | （本轮新增，见 `docs/DEVELOPMENT_LOG_2026-08-27.md` 对应小节）；`RFC-0006 §5.3` 的上限只剩四条可数的事实，各一条断言：更紧的一条赢（**宽松的那条不得放大调用自带的 cap**）、精确等于上限算在内、被拒文案点名的是 `io_budget.max_bytes` 还是 `512 byte cap`、`resource` 字段不许在半路丢掉；外加"未设预算什么都不拒"（`None` 既不是 0，也不是无限到不必检查） |
| `crates/caly-io/src/executor.rs`（单元） | 13 | 有界执行器的每条规则各有一条断言钉住：满队是 `Busy` 且文本同时含在队数与容量、拒绝不消耗 id 也不惊动已排队的任务；capacity 0 与「没有时钟却要求 sleep」在**构造期**就拒；一轮里每个任务只拿同样多的 poll、完成序等于提交序（贪心驱动会在第一轮就只答一个，这条断言当场抓住它）；`Advance::StepMillis` 让等时间的任务真的完成，且推进次数与 tick 数分别可数；永不就绪以 `Busy` 收尾、任务仍在队里、completed 与 port_faults 都不许动；期限到期是 `Timeout` 并且**挂起的 future 被丢弃**（poll 次数证明到期那一轮没有再 poll 一次）；没有时钟时期限**不会**被说成超时；父令牌取消发生在下一个 poll 之前（被取消的任务一次都不跑）；sleep 端口的故障不被改写成 `Busy`；四类出路各自计数且相加等于 submitted |
| `crates/caly-io/src/runtime.rs`（单元） | 6 | 驱动器的四条出路：立即就绪只 poll 一次（既有调用点行为不变）、被驱动到就绪的挂起端口算数完成、没有时钟也没有取消时是 `Busy`（可重试、瞬态）且文本写明哪些限制在场、取消优先于超时且两者是**不同 kind**、有期限但没时钟时**不猜**、`block_on_ready` 与 `drive` 的文案不许各说各话 |
| `crates/caly-ipc/src/dialect.rs`（单元） | 13 | （本轮新增，见 `docs/DEVELOPMENT_LOG_2026-08-27.md` 对应小节） |
| `crates/caly-ipc/src/duplex.rs`（单元） | 4 | 第八十七轮 FramePump：共享 codec 泵；TCP peek 0 字节→Closed、UDS 无 peek 恒 Indeterminate；send 失败把通道标死；MemoryIo 内存双工 |
| `crates/caly-ipc/src/endpoint.rs`（单元） | 10 | 第八十七轮 BindSpec 语法表（TCP host:port、unix 前缀、路径）；TCP port-file 裸 u16、UDS 写 unix: 前缀；chmod 0o600；UNIX_PATH_MAX=104；stale unlink 拒普通文件 |
| `crates/caly-ipc/src/handshake_drive.rs`（单元） | 9 | 第八十七轮 drive_client_hello：dialect 字节、validate 先于 observe、records/json 映射 Encoding::Json、CLI 角色 Admin 不继承 Operator、hello 不推进 request_id |
| `crates/caly-ipc/src/json.rs`（单元） | 5 | 协商载荷编码（第五十轮，`ADR-034` 第一刀）：扁平字符串值 JSON 对象——**record 键即 JSON 键**，编码改变写法不改变事实集合；转义双向往返（两面的分隔符 `=`/`%`/换行 与引号反斜杠都要活着）、**畸形拒绝不修补**（尾随垃圾/数字值/裸词/自造转义/悬逗号全点名）、空对象与空值往返、重复键如实保留（与 records 面同构） |
| `crates/caly-ipc/src/wire.rs`（单元） | 4 | v0 wire 编解码（第四十四轮提取共享——calyd/CLI/未来客户端同用一个 codec，但 E2E oracle 故意自持最小实现作对照）：转义往返保序且字面 `%3D` 不能伪装成 `=`、记录解析与查键、**帧帽双向**（出站超界不触碰流、入站超界只读 5 字节头即拒）、**读超时被命名**（第八十五轮：`WireFrameError.timed_out`，自定义 Read TimedOut ⇒ 真；codec 不把文案写成 CLI 的 timed-out-after——exit-11 措辞归 speaker） |
| `crates/caly-ipc/src/wire_ops.rs`（单元） | 11 | （本轮新增，见 `docs/DEVELOPMENT_LOG_2026-08-27.md` 对应小节） |
| `crates/caly-ipc/tests/endpoint.rs` | 10 | 第八十七轮集成：parse/bind、UDS chmod、stale 普通文件拒绝、TCP Closed vs UDS Indeterminate、ClientLoop unix 对打 hello |
| `crates/caly-ipc/tests/session_and_frames.rs` | 19 | 帧编解码与长度校验、协商策略、会话状态机、流交付策略；第四十一轮起含**出站**帧上界（恰在界内是帧、超一字节拒且点名字节数与上限、legacy 无界编码器为握手保留原形） |
| `crates/caly-mihomo/tests/selfcheck.rs` | 2 | 第五十九轮自检裁判（ADR-047 §4）：渲染产物过 mihomo 自己的 `-t`（钉死资产解包执行，schema 漂移在 spawn 前被核报警）；demo 口令只在 artifact 字节、manifest 与 annotations 一字不带（边界是位置性的） |
| `crates/caly-pipeline/src/flow.rs`（单元） | 2 | 真实 pipeline/apply projection 的 provenance 聚合与显式 source_inputs 解析分支；断言真实路径携带 parser provenance，而 legacy estimate 路径保持空 |
| `crates/caly-pipeline/src/source.rs`（单元） | 6 | source URI/base64 解码、显式 locator/source_ref_at 语义、raw SHA-256 与 provenance，以及 4 MiB source cap、128 条 diagnostics 上限和异常 padding 拒绝 |
| `crates/caly-singbox/tests/pinned_asset.rs` | 1 | 第二核心的资产钉（第五十七轮，ADR-045 §4）：`assets/cores/sing-box-1.13.20-linux-amd64.tar.gz` 存在且 sha256 == `SINGBOX_BINARY_SHA256`（计划携带的摘要）。真后端还起不了 sing-box 核（按名拒绝、拒绝语点名『资产已钉、缺 spawn 面』）——钉死使该拒绝成为有日期的范围决定而非永久耸肩。哈希用系统 `sha256sum`（caly-singbox 无 caly-common 依赖，无 ADR 不引 crate） |
| `crates/caly-singbox/tests/render_shape.rs` | 6 | 第五十八轮渲染裁判（ADR-046 §1）：断言表＝烟测表——只发 1.13.20 真 decode/boot 收的形状（wg=endpoint、dns typed＋local 解析器、MATCH→无条件规则、cipher→method 翻译、显式 direct、无顶层 tun／无 rule_set／无 legacy address）；不可译 matcher 省略并计数（annotation）；fakeip 无 tun 省略、有 tun 渲染；两次编译同 identity（确定性）。R60（ADR-048）：Direct 模式一条规则不发（final 即路由决定，Direct 核必须能取回）；wg passthrough 真键逐字覆盖惰性常量（local_address/peer_allowed_ips 逗号列表），真空缺时惰性常量仍在（双向持有） |
| `crates/caly-singbox/tests/selfcheck.rs` | 1 | 第五十九轮自检裁判（ADR-047 §4）：渲染产物过 sing-box 自己的 `check`；真 passthrough 口令逐字进 artifact、annotations 不带 |
| `crates/caly-storage/tests/apply_journal_listing.rs` | 4 | 默认 `Unsupported` ≠ 空、内存与落盘都含 `Committed`、**记录损坏让导出失败**而不是跳过 |
| `crates/caly-storage/tests/content_sweep.rs` | 23 | 孤儿内容清扫的存储层全部性质：走查看见无元数据命名的内容（否则以下全空转）、日期取端口证据 / 无时钟如实报 None / 无人伪造、写残渣被发现为独立种类、布局解释不了的文件**拒绝整次走查**（四种形状）、目录预算两侧可量（4 恰好 / 3 拒绝）、纯计划器四条（被引用永不孤儿科龄无关、grace 边界两侧、未知年龄永留、预算是**余数**不是第二份）、删除侧三条（删后复查一致、残渣删除、store 层仍被引用拒绝 + 坏 target 造不出路径）、InMemory 同一扇门三个答案、默认 Unsupported 不装空树、叶子字母表恰为 60 位 hex（错长叶子/半长 stem 残渣是损伤不是 anchor，走查与删除门各拒一次） |
| `crates/caly-storage/tests/fs_store.rs` | 17 | 内容寻址、篡改拒绝、元数据-only 不可物化、重启复原（仿真盘）；第十七轮起还包括：对象年龄取端口 mtime 而非调用方声明（谎报不能提前进 GC）、无时钟时不伪造、两个来源冲突取较新的一侧；第十六轮起还包括：带外写入的记录同样被枚举（运行中与重启后都要）、崩溃残留与「布局解释不了的名字」分别处置、超限是拒绝而非短列表、store 不写任何索引（按文件总数计）、pending 扫描答自目录而非内存 |
| `crates/caly-storage/tests/fs_store_on_real_disk.rs` | 11 | 同一组重启断言跑在 `StdFs` 真盘上（曾据此抓出 `runtime_path` 双前缀）；第十七轮起还包括真盘 mtime 落在写入窗口内（时钟也只经 `StdClock` 端口读）；第三十八轮起两条 anchor 裁判：记录里的 `content_sha256` 被（带外）改成非 anchor 形状后，boot 拒绝且**点名 anchor 与病灶**（`malformed content anchor` / `not a sha256 reference` / `not a full 64-hex`），而不是误诊成"引用了缺失内容"的幽灵路径或路径层 `Internal` |
| `crates/caly-storage/tests/gc.rs` | 11 | `§13/§15.6`：六类 root 各自生效且理由正确；未引用且过 grace 才回收；未知年龄不回收；单轮上限；忙时拒绝；共享内容不误删；宽限期边界为排他 |
| `crates/caly-storage/tests/object_contract.rs` | 12 | **同一组断言跑 `InMemoryStorage` 与 `FsStore`**：写后按字节读回、未知 digest 是 `None` 而非错误、声明假锚点被拒、metadata-only 既不能物化也不能读回、超限是 `CapacityExceeded`（消息含两个数字且不漏内部路径）、删除后内容不残留、不支持的后端答 `Unsupported`、**篡改后读回被拒** |
| `crates/caly-storage/tests/record_codec.rs` | 19 | 记录 round-trip（含 source-index validator/cache envelope 与 raw stored-at）；拒绝未知版本、未知字段、坏枚举、悬空转义；**source-index 参数化证伪**：三个 opaque cache 字段与各自 SHA-256 锚脱钩时按字段名拒绝、raw_content_sha256 非 `sha256:`+64hex 格式拒绝、未知字段点名拒绝、缺 required 字段按名报告、空 source_id/locator 与 `max_body_bytes=0` 各按名拒绝、`updated_at`/`raw_stored_at` 非整数与 `strict_mode` 非布尔按名拒绝 |
| `crates/caly-storage/tests/revision_listing.rs` | 4 | 登记修订的枚举：未实现的后端答 `Unsupported` 而不是空集（空集会授权删除）、两个后端同行同序且带 digest、目录即真相（重启后一致，文件被删就少一条）、记录损坏使整次枚举失败而非跳过 |
| `crates/caly-storage/tests/schema.rs` | 13 | `§12` 四规则 + `§12.3`：五分类判定、迁移必须连续分步、迁移前建回退点、失败即拒启、标记只在缺失时写入 |
| `crates/caly-storage/tests/stat_many.rs` | 2 | （本轮新增，见 `docs/DEVELOPMENT_LOG_2026-08-27.md` 对应小节） |
| `crates/caly-storage/tests/store_byte_budget.rs` | 9 | 累计字节预算在 store 接缝的全部性质（`ADR-039 §2` 第 2 步）：写先导准入（拒后盘面不动、此前写入完好、大 payload 不留孤儿内容）、读"在飞单元完成后下一单元拒"（cap=65 两读成第三拒）、克隆共享同一 meter（子上下文花同一份预算）、未声明预算⇒无门（默认与引擎自标 ctx 不被静默拦截）、双后端同门同词（单 payload 超限同 kind 同 "cumulative" 措辞、重复写在有限次内双双被拒——粒度差异写明）、memory 读计费后拒新单元、meter 本体（累计/克隆同域/新 ctx 新域/相等即同一）、写计费独立于验证读（floor=2×payload，防读回兜底掩盖写门失效） |
| `crates/caly-storage/tests/store_port_budget.rs` | 7 | 落盘 store 怎么驱动它底下的端口（`ADR-036 §2.6`）：预算之内的挂起**仍然是成功**（读、写各一条，写那条复核"字节真的落了盘"）；永远不就绪报 `Busy` 且**明写不得报 `Internal`**、文本必须带驱动器自己用的 poll 数；边界从两侧量（`budget-1` 通过、`budget` 拒绝），所以把常数改成 1 会当场红；stall 是一次性的、不连坐后续调用；`port_drive.rs` 里不许出现第二个 poll 循环（`Waker::noop` 命中数必须为 0，且只准调共享驱动器一次）；第二十九轮加：`the_store_invents_no_byte_ceiling_of_its_own` —— 4 MiB 载荷经 store 写入必须成功，因为 `FsStore` 那份共享 `IoContext` **不设**预算；这是"别把好意写成停机"的那条防线 |
| `crates/caly-storage/tests/store_port_deadline.rs` | 5 | store 接缝等待时限的全部性质（`ADR-039 §2` 第 3 步，收口第 28 轮"故意没做"的那一半）：过期期限 + 注入时钟 ⇒ `Timeout`（非 `Busy`，消息带 mono 时刻）、未来期限 ⇒ 预算照旧答 `Busy`（两侧边界）、**无时钟 ⇒ 期限被忽略而非被猜**（端口层自己的规矩在接缝处成立）、已取消调用方在挂起端口上被答 `Cancelled`（第 33 轮先导门的"在飞那一半"）、同一调用方同一期限在时钟前进后从 `Busy` 变 `Timeout`（判时限的是钟不是调用方的话） |

未覆盖（诚实列出）：

- **Source caller deadline / cancellation 的剩余边界**：HTTP→parser→CAS→D3 已由同一注入 clock 在各同步阶段边界约束，并有 Std/Sim 与真实 fixture 裁判；`StdHttp` 的 OS blocking syscall 不能被 CancelToken 从中途强行打断，未来若引入可挂起 runtime/transport，必须另定其中断与资源回收语义。
- **Source inspection 的读模型**：durable source-index 已保存 endpoint/validators/raw/normalized/provenance/diagnostics，且启动时恢复 worker 与 engine normalized cache；`SourceOp::Inspect` 已经从 durable record 形成 bounded API projection，按统一 `Redactor` 脱敏 locator/label/validator/provenance，同时保留 digest/size/count 等完整性锚点。未来若放宽 parser 的 bounded 记录上限，再另行设计分页；当前不把没有分页写成已缺失的功能。
- **真实 effect runtime 的跨进程/平台边界**：`StdEffectRuntime` 与 mihomo/sing-box 真核裁判已经存在，`calyd` 已有显式 `--effect-runtime real` 组合入口、资产/运行目录 preflight 与失败语义；默认仍是 `SimulatedRuntime`。跨进程 core adoption、Platform/TUN/helper、完整 OS 网络副作用与权限安全面仍未完成。
- **`RuntimeDriver` 全语义**：`config_identity()` 与完整 runtime API/telemetry trait 仍未接入 effect adapter 的统一接口；当前真后端走 `EffectRuntime` 的最小面。
- **通用 IPC transport runtime**：`calyd`/`caly` 已用同一套 `BindSpec`/`WireIo`/`FramePump` 接 TCP 与 UDS（第八十七轮）；hello 走 `drive_client_hello`。残余是共享 timeout scheduler、typed `send_request_frame` 与 `SessionRegistry` 生产化，不是再抄一份 UnixStream 循环。
- **Platform / security 的剩余面**：TUN、helper、keyring/加密存储、redirect policy（SSRF 已收口，见 `§8.8`）、RFC-0010 §14 整条（第八十七轮 UDS bind 只做了 chmod 0o600 这一条 v0 默认）与导入限额仍未落地；`Platform` 的决策性缺席必须保持，不得用假能力填空。
- **Capability 来源切换**：JSON 工件漂移已有门禁，但执行仍从代码内建 `default_*_document()` 读取；文件加载失败/离线首启动语义未决。
- **Storage schema / 性能**：`§7.3` schema migration 未做；~~`stat_many` 尚未提供~~ **第七十四轮已提供**（`ADR-054`：`Fs::stat_many` 批量 stat 面，`object_records` 单次批量 dated，`§8.9`），内容/对象年龄在批量枚举面不再按逐项 stat；GC/content sweep 已有 engine service 生产调用者，不能再写成无人消费。
- **架构债与发布基础设施**：`engine -> caly-mihomo/singbox` 具体依赖仍登记为 `KNOWN_ARCH_DEBT`；无 CI、无 fuzz、无性能回归；stream payload 的逐帧语义与原生 artifact golden 仍可加强。

---

## 4. RFC 实施状态矩阵

| RFC | 标题 | 状态 | 当前落地情况 |
|---|---|---|---|
| RFC-0001 | Core Architecture | `Partial` | workspace、依赖方向（**已有门禁**）、engine/daemon/app 主骨架成型；`engine -> 具体 adapter` 仍是已登记债务 |
| RFC-0002 | API / Facade / IPC | `Partial` | Facet/DTO/Operation、local/remote facade、loopback contract；写侧、事件内容、错误身份、role、CAS、idempotency 与读侧有界性均已有断言；`calyd`/`caly` 已提供 v0 TCP+UDS 客户端面（BindSpec/WireIo/FramePump + handshake-only ClientLoop）；共享 timeout scheduler 与 typed send_request_frame 仍未 |
| RFC-0003 | Pipeline / Provenance | `In Progress` | `parse_source` 已真实 decode/normalize 并产出 parser provenance，`flow`/apply 消费显式 source inputs 与 source cache；durable provenance、normalized cache 恢复与 inspection projection 已完成当前 bounded source 阶段，pipeline 更广泛的输入/记忆化语义仍在推进 |
| RFC-0004 | Capability / Coverage | `Partial` | registry/coverage 参与求值；JSON 工件漂移已有门禁，但执行仍来自内建 default |
| RFC-0005 | Deployment / Recovery | `In Progress` | effect executor、journal/snapshot、回滚补偿与恢复扫描已在内存/落盘后端闭合；真实 mihomo/sing-box effect adapter 有显式注入与真核测试，`calyd` 的 real 模式已显式组合并 preflight，跨进程 adoption、生产平台权限与 Platform/TUN 仍未完成 |
| RFC-0006 | IO Port / IoFault | `Partial` | `StdFs`/`StdClock`/`StdHttp`/`StdProc` 与 `Sim*` 已有共享或对应契约；Std/Sim Http 共享 caller deadline anchoring 与 cancellation/expiry 判定，`https://` 与 `Platform` 仍按名拒绝，真正可中断的 blocking runtime 与共享 timeout scheduler 仍待补；BindSpec/WireIo 已接入 |
| RFC-0007 | Storage / CAS / Snapshot | `Partial` | 五个 store trait + 内存后端 + **`FsStore` 落盘后端**；`§6.1-6.4`（含**读时锚点校验**与 `read_object`）与 `§13/§15.6`（GC root 集）均可测；两个后端跑同一组契约断言；`§7.3` schema 迁移未做 |
| RFC-0008 | RuntimeDriver / Telemetry | `Skeleton` | trait/mock 在；`EffectRuntime` 已有真实 core identity/probe 最小面，但统一 `RuntimeDriver::config_identity()` 与完整 telemetry API 仍未连接 |
| RFC-0009 | Profile Patch / Override | `In Progress` | selector、selection memory replay、merge/resolve 消费已成形 |
| RFC-0010 | Security / Secret / Redaction | `Partial` | `caly-common::redact` 落地 `§6.2` 全部目标 + `§4.1` 准 secret；三条出口（job 日志 / `ApiError` / support bundle）各自接线，`§14` 门禁 1/2/3 有断言；`§5`/`§11`/`§13` 未成码 |

---

## 5. 按 crate 分组的真实推进状态

### 5.1 基础层

| 模块 | 状态 | 当前情况 |
|---|---|---|
| `caly-arch-test` | `Partial` | 已从“有函数无调用”变为真实门禁：manifest 解析 + 方向/陈旧/纯核心/债务棘轮 |
| `caly-common` | `Partial` | 共享上下文模型被多个 crate 实际使用 |
| `caly-io` | `Partial` | Port / Fault / VPath 契约稳定；`contract.rs`（RFC-0006 §15 的跨后端契约套件）；`runtime.rs`（`drive` / `drive_pinned`：一次一个 future 的有界驱动，三种互不相同的出路）；`executor.rs`（`BoundedExecutor`：有界准入 + 公平推进 + 注入时钟，**不制造时间也不重试**）；re-export `Actor/TraceId/RequestContext/IoBudget/CancelToken` |
| `caly-io-std` | `Partial` | `StdFs`（root 沙箱、D0–D3 耐久、临时文件 + 原子 rename + fsync、锁文件）、`StdClock`、`StdHttp`（HTTP/1.1、`http://`、有界 body/条件请求、注入 clock 的 caller cancellation/deadline 边界）与 `StdProc`（shell-free spawn、try_wait、stop）；与仿真后端共享相应契约，`https://`/Platform 按名拒绝；单个 OS blocking syscall 的中途中断仍不虚构 |
| `caly-io-sim` | `Partial` | 世界模型/fault/scenario 可编译且**已测**；时钟回退、label 不可达、`lock_exclusive` 永不竞争三处缺陷已修；`SimHttp` 与 `StdHttp` 共享 caller deadline anchoring/check 语义并有取消/过期裁判 |
| `caly-ir` | `In Progress` | `CompiledArtifact` 承载 native bytes / media type / annotations |
| `caly-domain` | `In Progress` | `Profile` / `OverrideRule` / `SelectionMemory` 与 builder 服务 pipeline |

### 5.2 控制平面核心

| 模块 | 状态 | 当前情况 |
|---|---|---|
| `caly-pipeline` | `In Progress` | 六个阶段形成可执行 slice；`CapabilityValidationReport` / `ApplyWorkflowProjection` 被 engine 消费 |
| `caly-cap` | `Partial` | 新增零依赖 JSON 读写器 + 漂移门禁；strict 判定已进 pipeline |
| `caly-plan` | `Partial` | `ApplyPlan` / `EffectPlan` 被 adapter 与 engine::apply 真实投影 |
| `caly-storage` | `Partial` | `execution.rs` 投影；`store.rs` 的 `StorageBackend` + `list_unresolved_apply` + `list_objects`/`delete`；`record.rs` 行式编解码（拒绝未知版本/未知字段）；`fs_store.rs` 经 `caly-io::Fs` 落盘、集合枚举走 `Fs::list`（无自造索引层）、对象年龄取端口 mtime；`gc.rs` 回收策略 + `RevisionStore::list_revisions` 补齐 `§13.1` 缺的那类 root（默认 `Unsupported`），消费方在 `caly-engine::gc_plan`；`gc.rs` 的 `sweep_objects` 与计划分离（使「周期只执行它刚报告的那份清单」是结构而非约定）；计划与周期的消费都在 `caly-engine::gc_plan` |
| `caly-engine` | `In Progress` | queue/job/idempotency/event + `executor.rs`（解释与门禁）+ `sim_runtime.rs`（确定性世界）+ `recovery.rs`（持久化编排，面向 `dyn StorageBackend`）+ `gc_plan.rs`（回收计划与周期：root 集全有或全无、`now` 取注入的端口时钟并报告来源、有界采样、周期不得把自己算作在飞工作、执行的就是它报告的那份清单）；`run_limits.rs`（把命令的 `Ctx` 换算成 store 访问的限制：deadline / cancel / `IoBudget.max_requests` 计费；拒绝原因作为数据带出去，job 才有 `Cancelled` / `TimedOut` 两种结算）；`gc_plan.rs` 的 idle 触发（`decide_idle_gc` + 单调检查计数 + `triggered_by`，`ADR-038 §13.2 / §9`）|
| `caly-daemon` | `In Progress` | query/command/stream/session/runtime/local facade + 从盘启动恢复 + 生命周期闸门 + role/CAS/idempotency；`calyd` 组合根注入 `StdHttp` source worker、`FsStore` 与 `StdClock`，并以 `--effect-runtime real` 显式组合 `StdEffectRuntime`（默认 simulated；recovery/adoption 边界见 `ADR-050`） |

### 5.3 Core 适配层

| 模块 | 状态 | 当前情况 |
|---|---|---|
| `caly-core` | `In Progress` | `CoreAdapter` / mock / native helper；`config.identity` 已改为与 spawn 时交给 core 的 config 一致 |
| `caly-mihomo` | `Partial` | YAML artifact、native validation、apply planning、EffectPlan 全链 |
| `caly-singbox` | `Partial` | JSON artifact、native validation、apply planning、EffectPlan 全链 |

### 5.4 对外接口层

| 模块 | 状态 | 当前情况 |
|---|---|---|
| `caly-api` | `Partial` | Facet/DTO/Operation 可编译；第二十轮起 `SystemOp::CollectGarbage` + `GcRunView`（`gc-plan` 是它的 dry run）；第十八轮起 `SystemOp::GcPlan` + `GcPlanView`（18 字段，逐项都是「能不能删」的一部分，折任一项都会让剩下的被误读）；0 warning，`operation.rs` 仍偏大 |
| `caly-ipc` | `Partial` | frame/session/stream/client primitive 可编译；生产 BindSpec/WireIo/FramePump 与 handshake-only ClientLoop 已接入 calyd/caly（TCP+UDS）；timeout scheduler 与 typed send_request_frame 仍未接入 |
| `caly-app` | `Partial` | local/remote facade、loopback、parity/contract/scenario 编译打通 |
| `caly-cli` | `Partial` | `caly` binary target 已存在；driver/follow/contract_driver 与 calyd E2E 覆盖已接入 |
| `caly-tui`（未创建） | `Planned` | workspace 无此成员，仅有规划条目 |

---

## 6. 当前中心主链的真实进度

```text
Profile / Source / Override
  -> Caly IR -> ResolvedProfile
  -> Capability Validation
  -> CoreAdapter -> NativeValidation
  -> ApplyPlan -> EffectPlan
  -> Effect Executor            <-- 本版新增
  -> Journal / Snapshot / Revision
  -> Recovery Scan / Rollback   <-- 本版闭合
  -> Daemon Command Path / Facade
```

### 6.1 当前中心主链能力（截至 2026-08-30）

- `HttpSourceUpdateWorker` 把显式 endpoint registry、`StdHttp`/`SimHttp`、有界 body、`parse_source`、RawSource CAS、normalized cache 与 SourceUpdate job 接成真实 source slice；304 复用先读 CAS raw body 并验证双锚点，locator 变化清条件 cache。
- `caly-engine::executor` 把 `EffectPlan` **解释执行**，而不是渲染成字符串：
  - `phase_of` / `phase_rank` 固化 Prepare / Cutover / Finalize 分类；
  - 阶段单调性门禁（prepare 不得出现在 cutover 之后）；
  - verify-before-commit 门禁（无成功 `Probe` 不得 `MarkSnapshot` / `CommitRevision`）；
  - resume 边界：已记录 cutover 的事务不得回放到 prepare；
  - 失败后按逆序执行 `compensations`，补偿再失败则升级为 `RollbackFailed`；
  - `ExecutionStatus` 区分 `Rejected` / `FailedBeforeCutover` / `RolledBack` / `RollbackFailed`；
  - `ExecutionPolicy::fail_after_step` 提供“任意步骤后崩溃”注入点；
  - 时钟、故障、世界状态全部注入，模块内无 fs / process / 墙钟。
- `SimulatedRuntime`：确定性内存运行时（对象、物化、DB、core、net），
  会因“未写入即物化”“identity 不符”等**计划与世界不一致**而失败。
- `worker.rs`：apply 走执行器，rollback 真执行补偿并结算 journal；
  移除 “not connected to recovery executor yet”。
- job follow 现在报 `effects.prepare.started` / `effects.cutover.started` /
  `effects.verify.started` / `snapshot.committed` / `recovery.started` / `recovery.succeeded`。
- `ApplyWorkflowResult.effect_plan`：typed 计划进入 engine 结果，字符串投影降级为展示用途。

### 6.2 仍未完成的部分

- source ingest 的 caller deadline / cancellation 已覆盖 HTTP→parser→CAS→D3 的同步 phase boundaries；剩余限制是 `StdHttp` 单个 OS blocking syscall 只能在返回后由 worker post-call probe 观察，不能即时打断；
- source inspection 已把 durable provenance/diagnostics 投影到 API 并经统一 redaction；当前 source record 受 parser 的节点/diagnostic 上限约束，若未来扩大记录规模再补分页/stream 设计；
- `StdEffectRuntime` 已由 `calyd` 的显式 real 模式接入生产组合根，但默认仍是 simulated；资产/运行目录 preflight 已接入，跨进程 core adoption、Platform/TUN/helper 与完整 OS 网络副作用仍未完成；
- `RuntimeDriver` 的统一 identity / telemetry API、Platform/TUN/helper 与完整 OS 网络副作用；
- BindSpec/WireIo/FramePump 与 handshake-only ClientLoop 已接入生产 TCP+UDS（第八十七轮）；stream payload 的逐帧 e2e 断言已在第六十六轮覆盖。残余：共享 timeout scheduler、typed send_request_frame、UDS peek（无 std peek）、SessionRegistry 生产化；
- capability 执行读代码内建 registry/coverage default（**已决策**，`ADR-051`：代码文档=单一事实源，JSON 工件=导出物、由 `registry_drift.rs` 门禁保证一致；运行时从文件加载是新 ADR 才可引入的能力——原「而不是从 JSON 工件加载」的表述是文档与事实的漂移，已收口）；
- storage schema migration / `stat_many` 性能面，以及 engine→具体 adapter 的已登记架构债。

---

## 6bis. 历史行为变更记录（第二十四 / 二十六 / 二十七轮）

> 本节保存当时的 release note 与行为证据；其中轮次测试总数、旧基线和“从今天起”等措辞不代表当前快照。当前数字与剩余缺口以 §2、§3、§6.2、§7 为准。

**`Ctx::io_budget` 与 `RequestEnvelope.io_budget` 从该轮起有后果，而 daemon 的默认值不再是「无限制」。**

- `IoBudget::default_command()` 是一个命令执行所获得的默认：**至多 64 次「计入的」store 访问**
  （`IoBudget::DEFAULT_COMMAND_STORE_REQUESTS`），字节数不设上限。
  `RequestContext::new` 与 `caly_api::default_ctx` 都直接写这个值，`request_map` 在 envelope 缺字段时
  也回落到同一个常量 —— 两个门面、一条策略（`ADR-017`）。
- 「计入的」= **引擎可以拒绝的那些访问**：`recovery::run_ready_in` 经手的 store 调用（apply 的 phase A、
  以及不改变世界标记的游标推进）。记账/落真相的那几条（`put_apply_journal`、`finalize_*`、
  `mark_apply_reverted` / `mark_apply_recovery_failed`）**既不被告绝也不被计费**：一个不可能被拒的动作
  被计入预算，等于让调用方的上限去管引擎自己的簿记（`ADR-036 §6bis-sexies`）。
- 耗尽时：公开错误 `CONFIG_INVALID` / `ErrorCategory::User` / `retryable=false`，
  文案带两个数字（`allows N accounted store access(es); M already made`），job 结算 `Failed`
  （不是 `Cancelled`/`TimedOut`：那是调用方自己划的界限，不是它放弃了）。
- **对既有调用方的影响**：以前 `io_budget` 是"传下去但没人读"的字段，所以没人会被它挡；现在默认 64。
  本轮实测：整个 workspace 测试（含完整 apply 与场景包）在默认值下 422 条全绿，一次真实 apply 只花掉
  个位数次访问；显式写 `max_requests: Some(0)` 是唯一"必然被拒"的用法（用于试探边界）。**如果你的调用
  本来就想不受限，请显式写 `IoBudget::unlimited()`** —— 现在那是一个会被尊重的值，而不是唯一的值。
- **同轮新增的第二项自动化，默认关闭**：`ADR-038 §13.2` 的 idle 收集器。打开它的方式是提交
`AutomationPatch { job_id: "gc.idle", enabled: true }`（一条 `Role::Admin` 命令），不是配置里的隐式开关 ——
「允许系统自己动数据」必须留下一条可归责的命令。到期检查只做两件事：读一遍计划、在计划说得出「有东西可收」时
排一个**正常**命令；删除仍由那条命令走与人工完全相同的路径，记录里写 `triggered_by=automation:gc.idle`。
- **探针时限已在第二十六轮生效**（`ADR-036 §2.5`）：运行时**报告**耗时，执行器**判定**是否超出 `deadline_ms`，超出即"验证失败"走既有分支。为什么判定放在执行器：写在每个适配器里，就等于每个适配器都有一次忘记它的机会。`deadline_ms == 0` 不当成"无限制"也不当成"零时间"，而是在计划校验阶段直接拒（与 `ADR-038 §2` 对 `max_deletions: Some(0)` 的处理同形）。**这会改变行为**：过去能通过的"探针没写预算"的计划，现在会在触碰任何运行时之前被拒 —— 但本仓三个适配器给的都一直是正数（3_000），所以没有既有调用方受影响。
- **仍然没有的部分（别把上面读成"预算全链路生效"）**：`max_bytes` 在本层**不生效**，因为引擎看不见
  字节总量的全部（只有一条路径知道自己在读多大一个 payload）。留一个数字反而会造出"看着像保险"的
  假统计，所以宁可写成"未生效"并在此处与 ADR 中并列说明。（后半句已被第二十九轮超过：字节上限由**端口**执行，见本节末尾那一节；这一条留下的"引擎这一层不累计字节"到今天仍然成立。）
  `describe()` 会把预算显示成 `budget=<已用>/<上限>` 或 `budget=5/uncapped`，未生效与不计数是两件事。

**第二十七轮追加：cutover 窗口现在先记账、后动手，而崩溃现场因此换了分类。**

- 一次 apply 在 `Cutover` 相的**每一步之前**都会往 apply journal 写一条意图记录（`current_phase=Cutover`、
  `current_step_index=那一步的下标`、`net_effect_started` / `core_cutover_started` 已置真）。
  实测规模：默认 profile 的计划有 2 个 cutover 步 ⇒ 每次 apply 多 2 条 journal 写
  （`crates/caly-engine/tests/cutover_intent_guard.rs::a_real_apply_writes_the_cutover_window_into_the_store_as_it_goes`
  数的就是这个数字，多写一条就会红）。对 `FsStore` 那是真的 D3 落盘写——这是 `§6.1` Phase B 明说的代价。
- **对运维的分类会变**：同一个"进程在 cutover 中途被 kill"的现场，以前 journal 停在 prepare，
  启动扫描按「世界没被动过」丢弃 pending；现在它读到 `cutover_started=true` 与游标下标，于是走
  `STORAGE_RECOVERY_EXECUTION_PLAN §7.3` 的第 4 步（优先回到 last-known-good，回不去标 `RecoveryFailed`）。
  这不是回归，是那条规则第一次真的能运行——但请把它当成一次**行为变更**读。
- **意图记录写不下去时，那一步不执行**（`journal-intent-refused`）：公开错误 `STORAGE` + `Io`，
  job 结算按原因分为 `Failed` / `Cancelled` / `TimedOut`，`doctor` 的过载行只在 store 自己说 `Busy` 时出现
  （`error=storage_busy retry_hint=ManualIntervention`）。调用方的期限/取消/预算耗尽都算"调用方放弃"，
  不进那个计数（`OVERLOAD_AND_RETRY_MODEL §3.7`）。
- **一处收紧**：一条命令的 `io_budget.max_requests` 现在跨接缝共享（以前每个有界接缝各自从头数）。
  默认 64 不受影响（本轮实测：463 条测试全绿，含完整 apply 与场景包），但**显式设成个位数的调用方**
  会比过去更早被拒——那才是这个字段一开始的意思。

**第二十八轮追加：落盘 store 不再把"端口还没好"说成"存储坏了"。**

- `FsStore` / `schema.rs` 驱动 `dyn Fs` 的方式从"一次 poll，否则 `StorageErrorKind::Internal`"改成
  "有界轮询（`STORE_PORT_POLL_BUDGET = 64` 次），超预算报 `StorageErrorKind::Busy`，并带上驱动器自己那句
  `still pending after N poll(s)`"。**如果你曾按 `Internal` 匹配过 store 的错误**（今天没有任何测试或生产代码这么做），
  这一类情形现在是 `Busy`：`retryable=true`、`§3.4` 的 `storage_busy` 类，以及 `doctor` 的一条过载记录。
- 反过来，一个"慢但会答"的端口从错误变成成功：整条 apply 在慢盘上应当跑完并提交 last-known-good，而不是失败。
  这条有端到端断言（`crates/caly-engine/tests/store_suspension_is_contention.rs`）。
- 端口层多了一个可注入形状：`caly-io-sim::stall(label, polls)`（一次性、可数的挂起），与 `hang`（永不就绪）
  分开。任何自称"有上限"的数字都需要两侧都能推，这就是那一侧。

**仍未生效的部分**：`Cutover` 之外的步骤不受 guard（`needs_intent_record` 只管这个相，且有编译期锚点）；
guard 的覆盖面等于 `phase_of` 的分类正确性——一个新步骤种类若被归成 `Prepare`，它就绕开了 guard，
所以那条分类本身有断言钉着（`executor.rs::phase_classification_matches_centerline_document`）。

**第二十九轮追加：`Ctx::io_budget.max_bytes` 从今天起有人执行，执行者是端口自己。**

- `caly_io::budget::byte_ceiling` / `check_payload` 是唯一的实现处，`StdFs` 与 `SimFs` 调同一份代码，
  `caly_io::contract::fs_byte_budget_violations` 在**两个后端**上跑同一组断言：载荷超过 `max_bytes` 时在
  **任何字节落地之前**被拒（被拒之后 `stat` 必须说没有这个文件）、精确等于上限**放行**、读侧上限取调用自带 cap
  与预算里更紧的一条（**宽松的预算不得放大 cap**）、未设预算**什么都不拒**。`Http` 侧同样按 `byte_ceiling`
  收窄 body 上限；当前 `StdHttp` 与 `SimHttp` 均有实现，且共享 caller deadline anchoring/check helper 与对应 parity tests。
- 公开面：端口的 `CapacityExceeded` 到引擎变成新的 `RefusalKind::PayloadTooBig` —— `CONFIG_INVALID` +
  `ErrorCategory::User` + `retryable=false`，remediation 指向 `Ctx::io_budget.max_bytes`。它与
  `BudgetExhausted` 是两个 kind：一个数次数、一个数单次载荷字节，合成一格就会对一半调用方说错话。
  `remediation` 本轮也并进那张共用表（同一件事的第三面）。码表里仍无 `CAPACITY_EXCEEDED`
  （`RFC-0002 §14.4` 冻结），落差是有意的，见 `OVERLOAD_AND_RETRY_MODEL §3.7`。
- **形状与 `ADR-036 §2.4` 的设想不同**：`max_bytes` 是**单次调用的上限**，不是跨调用累计量。累计需要一个比一次
  调用活得久的作用域，而能把 `Ctx` 送到端口的那道签名（`RFC-0007` 冻结的 `StorageBackend`）今天不带它；挂到
  store 的共享 `IoContext` 上就变成"第 N 次大写入之后所有人一起被拒"——那不是预算，是停机。偏离与理由记在
  `ADR-036 §6bis-decies`。
- **对既有调用方无可观察影响**：默认 `max_bytes: None`（什么都不拒），且没有一处生产代码今天设过它。

**第三十轮追加：两条诊断查询的答案从此有上界，而截断是被说出来的。**

- `diagnostics.recovery-status` 的 `decisions` 与 `diagnostics.doctor` 的三层列表受
  `caly-daemon/src/paging.rs` 的 `DIAGNOSTIC_MAX_LINES = 128` / `DIAGNOSTIC_MAX_LINE_BYTES = 4 KiB` /
  `DIAGNOSTIC_MAX_BYTES = 512 KiB`（其中 1 KiB 是留给说明行自己的预留）约束。
  两个视图各多带三个字段：`truncated`、`omitted_*`、`shortened_*`；`decision_count` / `pending_apply_count`
  与 summary 里的 `decisions=N` **保持真实总数**，不随答案收缩。
- **这是行为变更**：一个有几百条未决事务的部署，过去会返回一份大到对端拒收的帧（表现为传输层错误、诊断丢失），
  现在返回一份有界的、并且写清楚了"还差多少、去哪儿看全文"的答案。要全文就生成 support bundle ——
  `storage-audit` 段带的是未截断的 finding 列表，它本来就是存储对象而不是一帧。
- 加字段的方式与 `GcPlanView::last_run`（第二十六轮）同类：响应 DTO 的**新增可选读取**，不动请求、不动码表、
  不动 `ProtocolVersion`；两条门面都经同一个 handler，所以 `caly-app::contract.rs` 的整值比较自动把新字段
  纳入 parity 判定。
  会改变的只有"显式设了 `max_bytes` 的调用方"——过去那个字段是装饰，现在它是一份真的上限。

## 7. 关键阻塞项（更新版）

1. **真实 effect runtime 的跨进程/平台权限边界**：`calyd` 已可用 `--effect-runtime real` 显式选择 `StdEffectRuntime`，并在 listener 前校验 runtime/assets；默认仍是模拟运行时，跨进程 core adoption、TUN/helper/完整 OS 网络副作用尚未落地；
2. **Source 边界的剩余硬化**：HTTP→parser→CAS→D3 的同步阶段已由同一注入 clock 做 caller deadline/cancellation 边界检查，inspection 也已从 durable record 完成 bounded provenance/diagnostics projection 与 redaction；损坏形态拒启已由第六十五轮收口、**第七十五轮补面**（`raw_object_digest` 锚格式 + 三个 cache digest 按名诊断，`§8.10`）；剩余是 blocking syscall 的不可即时中断、未来扩大记录规模时的分页/stream 设计，以及随新字段扩展覆盖（维护动作）；
3. **通用 IPC transport runtime**：BindSpec/WireIo/FramePump 与 handshake-only ClientLoop 已接入生产 TCP+UDS（第八十七轮）；共享 timeout scheduler、typed send_request_frame 与 SessionRegistry 生产化仍缺；
4. **Capability 来源切换**：执行仍来自代码内建 default，JSON 仅作漂移工件/门禁；
5. **RuntimeDriver 与安全平台面**：统一 identity/telemetry、TUN、helper、keyring、~~SSRF~~ **第七十三轮已收口**（连接后 peer 校验 + `FetchScope` 保守默认/显式放行 + ActiveCore 豁免，`ADR-053` / `§8.8`；redirect：当前实现不跟随重定向，RFC-0010 §11.2 的 SHOULD 因无自动跟随而不适用，见 §8.8）、UDS 权限与导入限额；
6. **Storage schema / 性能与架构债**：schema migration ~~与 `stat_many`~~ ——`stat_many` **第七十四轮已收口**（`ADR-054`：`Fs::stat_many` 批量 stat 面 + `object_records` 单次批量 dated，契约等价 + 1 次调用计数裁判，`§8.9`）——余 engine→具体 adapter 的已登记债务；
7. 无 CI：`scripts/check.sh` 仍是本地入口，门禁未被远程强制执行。

已不再是阻塞项：storage backend 可替换性、落盘 `FsStore`、真实 source parse/decode/normalize、durable source index 的 locator/validators/raw CAS/normalized/provenance/diagnostics 恢复、`StdHttp`/`StdProc`、GC/content sweep 生产接线、CLI/calyd binary target、effect executor/apply/recovery 闭环、以及 role/idempotency/CAS/读侧有界性。

---

## 8. 建议的下一实现阶段

### 8.1 Source 边界硬化与 inspection 维护

- 维护 HTTP→parser→CAS→D3 的 phase-boundary caller deadline/cancellation；~~若引入可挂起的生产 transport，再单列 ADR 定义 blocking syscall 的中断/回收语义~~ **第七十二轮已收口**：blocking syscall 的中断/回收语义已由 `ADR-052` 提前定义为决策（该语义不依赖具体 transport 才成立——不是「因为还没引入就悬着」，而是「任何会阻塞的端口实现都要遵守」）：①进行中 syscall 不可中断（诚实边界，取消只在阶段边界生效）②有界回收 `min(caller deadline 剩余, peer 上限)`，deadline 优先 ③上限触发 → `IoFaultKind::Timeout` ④fault 后连接关闭（对端见 EOF，无跨请求复用）⑤阶段内只用注入 clock。裁判 `http_contract::a_stalled_peer_is_reclaimed_by_the_caller_deadline`（真 TCP 对端 accept 后挂住；600ms deadline 必须在 5s 内回收为 Timeout 且对端见 EOF——若实现无视 deadline 只用自己的 10s 上限则此测试红）与 `a_cancel_during_a_blocked_read_does_not_claim_interruption`（fetch 线程 + 服务器确认请求已到后置位 cancel：认证「read 阻塞中取消 ≠ 立即中断」，诚实答案是 ~deadline 后的 Timeout 回收）。`falsify_round72.py` 2 变异（M1 摘除 read timeout → 挂死被 30s 杀；M2 超时误映射 Unavailable → 1.1s 红）全咬。不在 worker 里读取宿主时钟（ADR-052 §2.5）；
- 维护现有 source inspection 的 durable projection、统一 redaction 与 parser bounds；只有放宽记录上限后才引入分页/stream 读侧契约；
- 保持现有 source-index D3 原子提交、重启坏记录拒绝、CAS 内容与 metadata 双锚点校验、304 复用和 locator 变更删除，不把已完成的 durable slice 退回 process-local。

### 8.2 真实 effect runtime 的生产组合根

- `calyd` 已以 `--effect-runtime real` 显式选择 `StdEffectRuntime`，要求 `--runtime-root` 与 `--assets-dir`，并在 listener 前完成 root 写入探针及固定资产布局可读性 preflight；simulated 模式拒绝携带这些 real-only 参数，默认不会产生宿主机副作用；
- 保持 `SimulatedRuntime` 与真实 runtime 使用同一 typed `EffectPlan`/executor 裁判（`ADR-022`）；真实模式当前不宣称跨进程 core adoption、Platform/TUN/helper 或完整 OS 网络部署，见 `ADR-050`。

### 8.3 Capability 来源切换

- ~~决策：registry 从文件加载（含失败/离线语义），或明确“文件仅由代码生成”；若保持后者，则把 `REGISTRY_PATH` 改为“导出物”而非“输入物”，并更新 ADR-024 措辞~~ **第六十八轮已决策**：`ADR-051` 收口为后者——JSON 工件是导出物（生成器重写 + `registry_drift.rs` 门禁保证 == Rust 文档），生产 `src/` 不得从工件读取（arch-test `the_registry_artifacts_are_exports_not_runtime_inputs`）；「文件加载失败/离线语义」无运行时面（无生产加载器），未来引入须按 `ADR-051 §2.4` 另立 ADR。`ADR-024` 的单一事实源与 SupportedExact⇒证据两条决定不变。

### 8.4 测试补面

- ~~source-index 记录各损坏形态（typed cache anchor、raw CAS metadata/body、未知字段/版本）的参数化拒启证伪~~ **第六十五轮已覆盖**：codec 层三个 opaque anchor/raw 锚格式/未知字段/缺字段/空 identity/零上限/坏时间戳（`record_codec.rs` 6 条），worker/store 层 raw metadata 不一致与 304 复用三形态（`source_durable.rs` 4 条，含不校验读取的后端双端裁判）；**第七十五轮补面**：量选发现「随新字段扩展」之外的两类**旧字段覆盖空白**（当时误记为全覆盖）——`raw_object_digest` 只查非空不查锚格式（该字段是 worker 后来 `storage.get(record.raw_object_digest)` 的寻址锚；缺口实锤是 fixture 自己都带着 `sha256:raw-object` 这种非锚值）→ 现与 `raw_content_sha256` 同规则按名拒绝；三个 cache digest（`normalized_digest`/`provenance_digest`/`diagnostics_digest`）畸形值此前只被内容锚比较间接拒绝、诊断误报为「does not match its content anchor」（说「你改了值」，不是「这不是锚」）→ 现先按名报「is not a sha256 anchor」（`record_codec.rs` +2，`falsify_round75.py` 2 变异全咬）；残余仍为「随新字段扩展覆盖」这一维护动作；
- ~~逐帧 stream payload 断言~~ **第六十六轮已覆盖**；~~生产 BindSpec/WireIo/FramePump 与 handshake-only ClientLoop~~ **第八十七轮已覆盖**（TCP+UDS 同一套泵）。残余：共享 timeout scheduler、typed send_request_frame、UDS peek。逐帧 stream payload 断言（整窗逐行、帧内计数==行、unescape 语义面）在 `calyd_wire::the_stream_data_payload_matches_the_events_page_line_for_line`，判定 `jobs.follow-stream` 的 DATA 帧与 `jobs.events` 页逐行一致（行序翻转/行截断/count 少报/多发一行 4 变异全咬，count-vs-count 裁判对此全盲）；残余是共享 timeout scheduler、typed send_request_frame 与 UDS peek，不是再抄一份 UnixStream 循环；
- ~~mihomo / sing-box 产物字节 golden~~ **第六十七轮已覆盖**：真 apply 后 runtime root 持有钉死资产的精确字节（gz/tgz 拷贝、gunzip/tar 解压出的二进制、两个 geo 库）+ 合并配置由独立 oracle 重建（mihomo=artifact+文档化 envelope 模板全等、sing-box=独立 merge 后 `serde_json::Value` 全等），`spawn_artifacts.rs` 2 条、5 变异全咬。
- ~~RuntimeDriver identity/telemetry~~ **第六十九轮已覆盖**：apply 计划尾随 `CoreIdentity` + `TelemetryTraffic` 两个探针（mihomo/singbox 两个 adapter、`worker.rs` 复活计划、sim 计划镜像同步）——身份证据是 `GET /version` 响应体的 `version` 字段（`probe.core-identity kind=… version=…`，200 但读不出 body = 拒绝，不是骨架通过）；遥测证据是 `GET /connections` 的 `uploadTotal`/`downloadTotal`（`probe.telemetry-traffic upload_total=… download_total=…`；选 /connections 而不是 /traffic：sing-box 的 /traffic 只有速率、mihomo 的才有总量，connections 是两端唯一同形的累计面）；sim 侧同语义（模拟器无计数器，如实声明 0）；`worker.rs report_execution` 让探针观测值进 job 日志（仅 probe 步——此前探针证据从不落日志，探针证明不了任何事）；`real_apply` 新裁判跑两个真核心：证据携带钉住版本（v1.19.30 / sing-box 1.13.20）、经 core 取一次真实 URL 后核心自己的计数器严格增长、公共读面（`controller_identity`/`controller_traffic_totals`）与探针同解析路径；4 变异全咬（身份硬编码 / 计数器硬编码 (0,0) / mihomo 删身份步 / singbox 删遥测步）。
- ~~capability 文件加载失败语义~~ **第六十八轮已决策收口**（`ADR-051`）：无生产加载器 ⇒ 无「文件加载失败」运行时面；`registry_from_json`/`coverage_matrix_from_json` 的解析失败语义（畸形/未知枚举/缺字段按名拒绝）已被 `registry_drift.rs` 钉住。
- ~~纯核心缓存/记忆化（性能面）~~ **第七十轮已收口**：内置 registry 与 coverage 文档改为进程内**单次构建**（`caly-cap::catalog` 的 `OnceLock` 记忆化，`default_registry_document`/`default_coverage_matrix_document` 返回 `&'static`）——apply/validate/bundle 每次 merge 的 base 不再整份重建（~18 个 descriptor + 字符串），`ADR-051` 的「编译期 Rust 值」事实不变（记忆化的是常量，不是从文件加载）；裁判 `registry_drift::the_builtin_documents_are_constructed_once_per_process`（两次调用指针判等），`falsify_round70.py` 2 变异（registry/coverage 各一，改回每次新建后 Box::leak）全咬。**至此 §8.4 全部测试补面项已收口。**

### 8.5 CI

- 把 `scripts/check.sh` 放进 `.github/workflows`，并把 clippy 基线改为“新增即红”

### 8.6 格式收口

- 一次独立 `cargo fmt --all` 提交，然后把脚本里的 fmt 从 note 升级为 fail

### 8.7 v0 wire 记录方言（第七十一轮已收口）

- **一个问题，两处解析**：v0 wire 的 hello / hello_ack / 请求头记录，`calyd` 的手写连接循环与 `caly` CLI 各写了一份（calyd.rs 自解析 records + match kind；caly.rs 手写 `hello()`/`op_request()`），键名、默认值与校验规则在一侧改了另一侧不会知道。
- **更深的洞**：CLI 从不读 hello_ack 的内容——只认帧 kind，所以「一个自称协议 2.x 或选了另一编码的 daemon」也会被接受。这是 v0 里协议兼容性唯一能被客户端检查的点，却从未被检查。
- **收口**：`caly_ipc::dialect`（新，14 个 pub mod；crate 1,813 → 2,306 行）成为该词汇表的**单一实现**——`client_hello_records/payload`、`server_hello_session_json`、`server_hello_from_records`、`server_hello_ack_records`、`server_hello_ack_from_records`、`client_validate_hello_ack`、`request_payload`、`request_head_from_records`。连接两侧都改用它：calyd 的 hello 解析/hello_ack 构造/请求头提取，caly 的 hello 发送/ack 解析与校验/请求构造。字节形状不变（hello 与请求记录的键序、缺省值逐字节相同——dialect 单测用字节断言钉住）。
- **一个刻意的加宽**：hello_ack 现在在旧 3 键（daemon_name/daemon_version/instance_id）之后回显 `major`/`minor`/`encoding`/`compression`——这是 CLI 校验所依赖的内容；旧 ack 只有 3 键时客户端无物可查。客户端解析是严格的（缺任一键=按名拒绝「不是 v0 方言」），因为猜不动的对端不值得猜。
- **裁判**：`caly_cli_e2e::caly_refuses_a_hello_ack_that_contradicts_the_session`（假 daemon 回 `encoding=msgpack`/`major=2`，CLI 必须 exit 13 且指名双方；若被变回 v0 的「只看 kind」则 CLI 继续到 exit 0——判据直接盯着行为，不是内部结构）+ `dialect` 13 个单测（字节级 golden + 缺键/未知值/协商缺省）。`falsify_round71.py` 2 变异（M1 CLI 跳过校验、M2 ack 丢回显键）各 0.5s 全咬。

### 8.8 SSRF 网络访问边界（第七十三轮已收口，`ADR-053`）

- **此前状态**：`RFC-0010 §11.1` 的 SSRF 最低要求（连接后地址校验、loopback/link-local-metadata 限制、私有网段默认保守）无任何实现——`StdHttp` 的 `Direct` 路由对任意目标直连，`RFC_ADR_CRATE_INDEX.md` 登记「§11（SSRF）仍无对应实现」。
- **实现**：`FetchReq.scope: FetchScope { Default, AnyPeer }`（Default=保守，仅允许 Public 类；AnyPeer=显式放行全部）；`StdHttp` 连接成功**后**取 `peer_addr()` 分类（Loopback 127.0.0.0/8+::1 / LinkLocalOrMetadata 169.254.0.0/16+fe80::/10 / Private RFC-1918+CGNAT+ULA / Public），不达标即关闭并 `PermissionDenied`（指名类别与「RFC-0010 §11.1 SSRF boundary」），**拒绝发生在写任何字节之前**（服务器收到 0 字节）。豁免：`ActiveCore` 路由（RFC 明文的管理地址豁免）；`SystemProxy`（代理地址=显式信任配置，真实目标不可见，明确记录不适用）；calyd 的 core controller 探针（`effect_std`/`real_core` 的 `127.0.0.1:{port}`）用 `Direct + AnyPeer`（显式管理地址）。
- **生产默认**：`source_worker` 的用户 locator 用 `Default`——内网/本机/元数据源默认按名拒绝（安全优先的行为变更；放行面随配置功能落地，拒绝信息指名条款与类别）。
- **裁判**：`http_contract::the_default_scope_refuses_a_loopback_peer_by_name`（PermissionDenied + 服务器 0 字节）、`an_explicit_any_peer_scope_allows_a_loopback_peer`（显式放行通过边界且非 PermissionDenied）、`peer_address_classification_covers_the_rfc_partition`（15 地址钉住分类）。`falsify_round73.py` 2 变异（M1 摘连接后校验、M2 127.0.0.0/8 判 Public）各 0.6s 全咬。
- **redirect（§11.2）**：`StdHttp` 不跟随重定向（3xx 原样返回调用方），因此不存在「自动跨 origin 请求」的认证头泄漏面；SHOULD 条款因实现语义不适用，此处如实记录，不声称已实现。

### 8.9 Fs 批量 stat 面（第七十四轮已收口，`ADR-054`）

- **登记债务**：`ADR-035 §3`（拒绝富 `list` 条目时写上「批量 stat 属于后续 `stat_many` 的优化」）与 `§6bis-quater`（第十七轮 `dated` 落地时），`FsStore::object_records` 对 N 条对象记录每条一次 `Fs::stat` 端口调用。
- **实现**：`Fs::stat_many(&[VPath]) -> Vec<Option<Meta>>` ——同长同序、每项 == 逐条 `stat` 答案、`Err`=整批失败、空输入=空输出、**一次逻辑端口调用**（fault 注入世界单点 `maybe_fail`）；`SimFs` 的 `stat`/`stat_many` 共用同一 `sim_meta` 判定（「每项等于逐条」是同一答案不是巧合），`StdFs` 底层循环但抽象为一次调用；存储层 `object_records` 改为 list → 逐条 read+decode → 一次 `stat_many` → 逐条 `date_object`（合并规则不变的 whichever-is-newer，纯函数抽出供单/批共用）。单对象路径（get/put/open）保持单次 `dated`。
- **裁判**：契约套件 `fs_contract_violations` 新增 `stat_many` 项（两端跑：等价/None/顺序/空输入）；`caly-storage/tests/stat_many.rs`（新文件，`CountingFs` 包装计数）2 条——`object_records_dates_its_whole_directory_with_one_stat_many`（stat_many==1、stat==0、年龄正确）与 `object_records_batch_matches_individual_reads`（批量与单条 get 的 stored_at 逐条相等）。`falsify_round74.py` 2 变异（M1 调用点退化逐条 stat、M2 SimFs::stat_many 长度错）各 1.4s/0.6s 全咬。
### 8.10 source-index 锚格式校验缺口补面（第七十五轮，`§8.4` 首条残余）

- **登记债务**：`§8.4` 首条（source-index 损坏形态）在第六十五轮后记为「残余仅为随新字段扩展覆盖」——第七十五轮量选发现该表述不全：两类**旧字段**覆盖空白（① `raw_object_digest` 只查非空不查锚格式，而它是 worker `storage.get(record.raw_object_digest)` 的寻址锚；② 三个 cache digest 畸形值只被内容锚比较间接拒绝，诊断误报「does not match its content anchor」而非「不是锚」）。
- **实现**：`crates/caly-storage/src/record.rs::decode_source_index`——`raw_object_digest` 与 `raw_content_sha256` 同规则 `source_anchor` 按名校验；`normalized_digest`/`provenance_digest`/`diagnostics_digest` 在 verify 前按名格式检查（错误统一「source index {field} is not a sha256 anchor」，符合 ADR-035 的 restart 不猜哪部分坏）；生产写入恒为 `sha256:` 前缀，启动打开遇旧非法记录按名拒绝（不新增放宽）。
- **裁判**：`record_codec.rs` +2（`source_index_rejects_a_raw_object_digest_that_is_not_a_sha256_anchor` / `source_index_rejects_malformed_cache_digests_by_name`，各 3 变体）；fixture `raw_object_digest` 从非法值 `sha256:raw-object` 改正为合法锚——**fixture 自带非法值且全部测试通过，正是校验空白的实锤**。
- **证伪**：`scripts/falsify_round75.py` 2 变异全咬（M1 删 `raw_object_digest` 检查 / M2 删 cache digest 检查环，保编译、按预期红）；无新 ADR（闭合既有原则，非新架构决策）。
- **门禁发现（非本轮靶）**：完整门禁第 d 遍红在 R72 的 `a_cancel_during_a_blocked_read_does_not_claim_interruption`——既有 judge 竞态（「服务器已收请求」≠「客户端已阻塞在 read」，2 核/宿主争用下 27% 命中）；实现语义正确，judge 改为诚实边界答案重试（≤10）+ 其余立即红 + 5s 有界等待，两遍全绿日志一致；详见 `DEVLOG §19.6` / `ONBOARDING §4.157`（测试数 752 不变）。
- **残余仍为**「随新字段扩展覆盖」这一维护动作（本条同时修正了「仅此而已」的过时表述）。

### 8.11 v0 wire 请求形状单源（第七十六轮，`§13#3` 先行切片）

- **登记债务**：`§13#3` 主体（transport / ClientLoop 接入）仍最大；本条只取「wire 请求
  形状单源」这一可证伪切片——此前 CLI 手拼 extras、daemon 门字段表、文档三处各持一份形状
  知识，漂移编译不出来（量选排除 `send_request_frame` 接 typed 层：v0 wire 是字符串 op +
  各 op 专属 extra，双表接线是 API 增长而非复用）。
- **实现**：`crates/caly-ipc/src/wire_ops.rs`——`WireRequest{name,extras}` + 13 op 编码表 +
  按名拒绝（无 wire 名的 op 报 `no_wire_name`）；CLI `caly.rs` 子命令表是唯一手写表，
  typed `Operation`→`wire_request`，`idempotency_key` 仅 keyed ops（apply/rollback/gc）
  且非空时追加，ask/print 以 `wire.name` 分发；`wire_number`/`wire_required_number` 把
  旧 daemon 门校验移到客户端 usage 错误。
- **裁判**：`wire_ops` 单测 5 条（每 op 名+记录契约、按名拒绝、bool `"true"`/`"false"`、
  optional iff `Some`）；`calyd_wire` 新增扫门判官
  `every_request_op_encoded_by_the_single_source_passes_the_daemons_door`（13 op 逐一过
  真 calyd 门，排干流帧，断言非 USAGE/UNSUPPORTED 且 request_id 回声）；cli_e2e 22 条
  （真二进制链路）。
- **证伪**：`scripts/falsify_round76.py` 2 变异全咬（M1 `"profiles.apply"`→
  `"profiles.applyx"`→daemon UNSUPPORTED；M2 apply 记录名 `profile_id`→`profile`→daemon
  USAGE；均经真门判官，各 ~1.3-1.7s）。
- **门禁发现（非本轮靶）**：falsify 首版 restore 漏洞（`backup_taken` 标志在 M1 restore
  删除备份后失效）让 M2 变异残留进工作树，`check.sh` tests 门揪出；修复脚本后复跑干净。
  详见 `ONBOARDING_NOTES §4.159`。
- **残余**：`§13#3` transport 主体；除 CLI 外的第三个消费方仍应走同一个 `wire_request`
  （本轮只迁移了既有 CLI，未新增消费方）。

### 8.12 wire 形状对称闭包（第七十七轮，`§13#3` 第二切片）

- **登记债务**：第七十六轮只封了编码侧（`wire_request` 一张表）；daemon 的解码表仍手写
  在 `calyd.rs`（213 行 match），`jobs.follow-stream` 的 open/resume 两形状在 CLI 仍手拼，
  且 daemon 的 UNSUPPORTED 文案漏列 `jobs.follow-stream`——「单源」的对称性与流形状
  都没有裁判。三处先实证再定靶。
- **实现**：`crates/caly-ipc/src/wire_ops.rs`——`decode_request`（12 个无状态 op 的
  records→typed `Operation`，镜像编码表）、`wire_stream_request`/`decode_stream_request`
  （follow-stream open/resume 双形状）、`WIRE_OPERATION_NAMES`（13 名列表；daemon 的
  UNSUPPORTED 文案改由它生成，补回漏写的 follow-stream）；`DecodedRequest`/
  `WireDecodeError`（按名报字段）。`calyd.rs` 删除 213 行手写解码表，调用 decode 后仅保留
  门内责任（会话状态/文案映射/错误分类）；`caly.rs` 删除 follow_stream 手拼 extras。
- **裁判**：`wire_ops` +5（每 op round-trip 回自身、13 名无一 Unknown、拒绝按名报字段、
  流两形状各自 round-trip、encode 名集合==名单集合）；`calyd_wire` 35 条 + 扫门判官
  （行为零变化，文案逐字保持）；cli_e2e 22 条（follow/resume 真二进制链路）。
- **证伪**：`scripts/falsify_round77.py` 2 变异全咬（M1 编码侧 resume 记录名 typo→
  round-trip 红；M2 解码侧 apply 记录名 typo→round-trip 红 + 真 daemon 门红；
  各 ~0.3s，restore 后内容级核对干净）。
- **残余**：`§13#3` transport 主体（UDS/双工调度、timeout/reconnect）——多次量选确认
  为最大未动项；wire 形状的两张表现在同处，transport 落地只需接 typed 层。

### 8.13 doctor runtime 投影可达化（第七十八轮）

- **登记债务**：`diagnostics.doctor` 的 `include_runtime` 在 daemon 有实现分支、五处
  harness 测试断言过，但 v0 wire 形状从未携带它（编码器 `plain`、解码器固定 `false`、
  CLI 硬编码 `false`，而同 crate 库路径 `driver.rs` 用 `true`）——「实现了但接口
  不可达」：医生声称可查看的 runtime 状态，从任何 wire 客户端都够不到。
- **实现**：v0 wire 加宽——`diagnostics.doctor` 增加可选记录 `include_runtime`
  （`"true"` 生效，bool 族同款语义，缺席=false）；`wire_ops` 编码/解码同步（encode
  恒写 `"true"`/`"false"`，decode 按名读）；`caly doctor --runtime` 开关（默认形状
  不变，向后兼容）。
- **裁判**：wire_ops 的 doctor opt-in round-trip（编码写出记录、解码读回同一 typed
  请求）；`calyd_wire` 新门裁判 `a_doctor_request_can_opt_into_the_runtime_projection`
  （默认形状 summary **不**加宽 + opt-in 形状 summary 命名 runtime 快照，一次断言两个
  愿望，真 daemon 门）；cli_e2e 新用例
  `caly_doctor_runtime_flag_names_the_runtime_projection`（真二进制链路）。
- **证伪**：`scripts/falsify_round78.py` 2 变异全咬（M1 解码臂丢掉记录→round-trip 红
  **且**真 daemon 门红——证明 daemon 确实经 decode 解码；M2 编码臂退回 plain→opt-in
  round-trip 红；各 ~0.4s，restore 后内容级核对干净）。
- **残余**：doctor 的 runtime 投影只含三字段（active_profile/active_snapshot/
  engine_lifecycle），不接 `RuntimeDriver`——其 mihomo/singbox 实现仍是硬编码
  skeleton stub 且全库无消费者（接入需先立消费点）。

### 8.14 EXIT_CODES 表↔代码对照裁判（第七十九轮）

- **登记债务**：`docs/EXIT_CODES.md` 是 shell/CI 依赖的契约，但文档门禁只查表格形状；
  表内容与 `caly_cli::ExitCode`/`caly_api::ErrorCode` 无任何对照裁判——「表↔代码
  对齐」在此前只是碰巧一致，任何一侧改名/改号/跳号都静默通过。
- **实现**：`crates/caly-cli/tests/exit_code_table.rs`（纯文档读取裁判，不 spawn 进程）：
  ① 文档 ErrorCode 表（`| N | NAME | 说明 |`，名字取首个反引号 token）的
  (名字→数字) map == 代码 `from_error_code` 的 (as_str→数字) map（双向双射）；
  ② `ExitCode` 枚举值集合 == 0..=16、无重复无遗漏。一行数 14 == ErrorCode 变体数。
- **裁判**：`cargo test -p caly-cli --test exit_code_table`（2 条，~0.0s，无进程）。
- **证伪**：`scripts/falsify_round79.py` 2 变异全咬（M1 文档侧 `CURSOR_STALE`→
  `CURSOR_STALEX`；M2 代码侧 `Timeout=11`→`Timeout=21`，范围+映射双红；
  各 ~0.1-0.9s，restore 后内容级核对干净——**初版 restore 保留原 mtime，导致
  stale fingerprint 时间炸弹**（rlib 比源码新，cargo 不重编，`21` 泄漏进终跑，
  见 DEVLOG §23.5.1）；已修：`restore_one` 恢复后 `os.utime(path, None)`。
- **终跑**：`check.sh` all gates passed（768/768、clippy 31、fmt 331 advisory）。
  途中三次排雷：① stale-21 时间炸弹（utime 排雷+修脚本）；② 新测试用
  `PathBuf` 触发 disallowed_types 使 clippy 31→32（改 `&Path`+`display()` 回基线）；
  ③ `real_apply` 502 网络瞬态一次（§4.155 族，未改码重跑全绿）。
- **残余**：`errors.rs`/`ERRORS.md` 的 ApiError 表（错误对象↔ErrorCode 映射）尚无
  同类对照裁判；`EXIT_CODES.md §2` 表 1（0/1/2）只做数字存在性对照（无名字列）。

### 8.15 ERRORS.md §4/§4.1 名称闭包裁判（第八十轮）

- **登记债务**：`docs/ERRORS.md §4`（v1 稳定码最小集合：12 码 × Category × Retryable）
  与 `§4.1`（6 个保留码位）是脚本/自动化可依赖的码名契约，但文档门禁只查表格形状；
  enum 加未入档码、§4 拼错码名、保留码偷偷转正——全部静默通过。与 §8.14 同族，
  但多了个量选发现的边界：**代码侧没有按码的分类/可重试权威**——(category,
  retryable) 由每个 `ApiError::new` 构造点逐例裁定，且已发现至少三处与 §4 相左
  （`map_handshake_error`/`map_session_loop_error` 把 `ConfigInvalid` 归 User；
  `error_identity` 钉住未知 job 的 follow = CONFLICT+User）。
- **实现**：`crates/caly-api/tests/error_doc.rs`（纯文档读取裁判，不 spawn 进程）——
  方向性闭包：已实现 ⊆ §4∪§4.1（无无名码）；§4 稳定码 ⊆ 已实现（无不存在的码）；
  保留↔实现中点钉死为恰好 `CANCELLED`+`INTERNAL`（其余四个保留位实现前必须转正）；
  §4/§4.1 不相交、行数 12/6；§4 的 Category ∈ §3 七分类、Retryable ∈
  {否,视场景,可能,是}（文档内部自洽）；`ALL_CODES` 配穷举 `match` 见证（新变体
  编译失败，列表不会悄然过时）。
- **裁判**：`cargo test -p caly-api --test error_doc`（2 条，~0.0s，无进程）。
- **证伪**：`scripts/falsify_round80.py` 4 变异全咬（M1 §4 码名拼错 / M2 保留码
  转正不除名 / M3 §3 分类名漂移 / M4 代码侧 `as_str` 漂移——R80+R79 双裁判红），
  各 0.1-4.0s；restore 内建 mtime 单调（R79.5.1 教训直接固化进脚本）。
- **残余**：① (code→category) 逐点权威不存在，构造点与 §4 的三处相左未裁决
  （候选轮：引入 `ErrorCode::category()` 权威或修订 §4 措辞，涉及行为面，需单列）；
  ② (code→retryable) 文档为 4 值（否/视场景/可能/是）、代码只有 bool——需
  RetryPolicy 型才可对照，§4 该列至今无任何裁判；③ §4.1 措辞与代码现状张力：
  `CANCELLED`/`INTERNAL` 已在代码投入使用（EXIT_CODES 15/16、`ApiError::internal`）
  而文档仍写作「保留码位」——语义灰色区，待文档修订或 RFC 追认。

---

### 8.16 EXIT_CODES §2 名字列 + 双胎名一致裁判（第八十一轮）

- **关账**：§8.14 的残余之一（`EXIT_CODES §2` 表 1 无名字列）本轮收口。原缺口：
  §2 只有 `0/1/2` 数字与含义，无码名可对照——`Success`/`GeneralFailure`/`Usage`
  是枚举的事，文档侧数字对不上、代码改名全静默；且 `ExitCode`（caly-cli）与
  `ErrorCode`（caly-api）各有一套名字（3..=16 经 `from_error_code` 指同一字符串），
  双胎 `as_str` 无裁判钉住。
- **实现**：① `ExitCode::as_str()`（17 臂，补 0/1/2 名字 + 与 `ErrorCode::as_str`
  逐字相同的 3..=16）；② `EXIT_CODES.md §2` 表加「名称」列（`SUCCESS`/
  `GENERAL_FAILURE`/`USAGE`）；③ 裁判 `exit_code_table.rs` +1 条：§2 (数字→名称)
  map == 枚举 (as_i32→as_str) map，以及 14 个共享码的 `ExitCode::as_str∘
  from_error_code == ErrorCode::as_str` 双胎一致；④ R79 裁判解析器收窄到 §3
  区段（§2 加列后变 3 格会误收——必要配套，R79 旧证伪重跑仍双咬）。
- **裁判**：`cargo test -p caly-cli --test exit_code_table`（3 条，~0.0s，无进程）。
- **证伪**：`scripts/falsify_round81.py` 3 变异全咬（M1 §2 名 `SUCCESS`→`SUCCEED` /
  M2 `ExitCode::Usage`→`USAGE_` / M3 `ErrorCode::Timeout`→`TIMEOUT_`=R81+R80
  双裁判红），0.1-2.3s；restore 内建 mtime 单调。

---

### 8.17 §4↔§5.x 使用规则覆盖裁判（第八十二轮）

- **登记债务**：`ERRORS.md §4` 稳定码集合与 `§5.x` 使用规则小节无覆盖关系裁判——§4
  删码但 §5 留规则、§5 给保留码开后门（如 §5.11 `CANCELLED`）、§5 标题拼错码名，
  全静默。而 §5 规则是实现的逐条判据（`error_identity` 引用 §5.2 的 CAS-miss
  归类），规则集与码集脱钩 = 实现无从对照。
- **实现**：`error_doc.rs` +1 条（`the_usage_rules_cover_exactly_the_stable_codes`）：
  §5 小节恰 10 个（5.1..=5.10 编号唯一）、每个 §5 标题只点名 §4 稳定码（保留码/
  未入档码不得有规则小节）、每个 §4 稳定码恰好出现在一个 §5 小节（不多不少）。
- **裁判**：`cargo test -p caly-api --test error_doc`（3 条，~0.0s，无进程）。
- **证伪**：`scripts/falsify_round82.py` 2 变异全咬（M1 §5.7 标题码名改名 / M2 新增
  §5.11 给保留码 CANCELLED 立规则），0.0-0.1s；restore 内建 mtime 单调。

---

### 8.18 `ErrorCode::category()` 默认权威 + §4↔默认双向裁判（第八十三轮）

- **裁决（§8.15 残余①关账）**：量选先读文档——`ERRORS.md §5.1` 自己钉了
  `CONFIG_INVALID` + `User` 的实例用例（io_budget 超限），故分类在本文档语义里是
  **逐例**的，§4 的 Category 列是每个码的**规范默认类**，不是强制归类。
  全部 11 处 User/分类偏差点逐一核查：9 处为文档先例内的 caller-mistake 类
  （misrouted support-bundle、bad_page_request、no-such-job、read_bundle_refusal、
  bad_gc_request、idempotency 拒收、handshake/session 拒绝、routed-but-no-handler），
  1 处恰好等于 §4 默认（CAS-miss = CONFLICT+Config，注释已引用 §5.2），唯一待议项：
  `app.rs` 生命周期拒收 = CONFLICT + **Platform** + retryable=true（既非 §4 默认也
  非 caller-mistake 类；是「状态冲突」还是「暂不可用」需产品语义裁决，本轮不动）。
- **实现**：`ErrorCode::category()`（14 臂 = §4 默认；`Cancelled`→User /
  `Internal`→Internal 为代码侧裁定并在注释注明）+ `ErrorCategory::as_str()`（7 臂）
  + 裁判 `error_doc.rs` +1：§4 (名→类) map == (名→`category().as_str()`) map，双向。
  零行为变更。
- **裁判**：`cargo test -p caly-api --test error_doc`（4 条，~0.0s，无进程）。
- **证伪**：`scripts/falsify_round83.py` 2 变异全咬（M1 §4 `PERMISSION` Platform→User /
  M2 `category()` Timeout 臂 Io→User），0.1s/0.4s。
- **残余**：① Retryable 4 值 vs bool（§8.15 残余②不变，需 RetryPolicy 型）；
  ② `app.rs` 生命周期拒收的 (CONFLICT,Platform) 待议；③ 构造点仍未统一消费
  `category()`（迁移属后续收口；现有偏差逐例有注释）；④ `real_apply` 真核 E2E 的
  example.com 502 瞬态今日两发（log 家族三发）——环境噪声治理候选：测试内单次
  重试或前置连通性探针（需权衡「放松裁判」与「环境噪声」，另行议）。


---

### 8.19 RetryPolicy 型 + §4↔默认双向裁判（第八十四轮）

- **关账（§8.18 残余①）**：`ERRORS.md §4` 的 Retryable 列（否/视场景/可能/是）是每码的
  **重试性质**，比 `ApiError::retryable` 的 bool 丰富——「可能/视场景」无法扁平化为
  bool，因此该列此前无任何裁判（R80 起列为残余）。本轮把「词」侧做成代码侧权威。
- **实现**：`RetryPolicy`（Never/Maybe/Depends/Always 四值，`pub use error::*` 自动
  导出）+ `ErrorCode::retry_policy()`（14 臂 = §4 默认；`Cancelled`/`Internal` 代码侧
  裁定 Never，注释注明）+ 裁判 `error_doc.rs` +1：§4 (名→词) map ==
  (名→`retry_policy()` 词) map，双向。**词→变体映射住在裁判里**——文档的词永远是
  文档的，代码只输出变体。零行为变更（`ApiError.retryable` 的 bool 保持实例级
  wire 字段）。
- **裁判**：`cargo test -p caly-api --test error_doc`（5 条，~0.0s，无进程）。
- **证伪**：`scripts/falsify_round84.py` 2 变异全咬（M1 §4 `TIMEOUT` 是→否 /
  M2 `retry_policy()` Timeout 臂 Always→Never），0.1s/0.4s。
- **残余收敛**：§4 的 Category/Retryable 两列至此都有双向裁判（§8.18/§8.19）；
  剩余：app.rs 生命周期拒收 (CONFLICT,Platform) 待议、构造点迁移 category()/
  retry_policy()、real_apply 502 瞬态治理、§8.6 fmt 收口、§8.5 CI。


### 8.20 生产 CLI 入站帧帽走共享 codec（第八十五轮）

- **关账**：生产 `caly` 的 `Session::recv` 此前手写 `read_exact` 头 + `vec![0; len]` 再读体，
  注释声称共享 codec 做入站 cap 而生产路径从未调用 `wire_read_frame`（daemon 侧 `calyd`
  已走 codec）。对超 cap 声明会分配并卡在 3s 读超时，exit 11 把协议违规说成超时。
- **实现**：`WireFrameError { summary, timed_out }` + `message()` / `from_io()`；
  encode/decode 用它们；CLI `recv` 委托 codec，`timed_out` 映射回 round-44 文案
  `timed out after {READ_TIMEOUT}ms waiting for the daemon to speak`（`EXIT_CODES.md` 11
  仍匹配 `starts_with("timed out")`）；删死代码 `is_timeout`。
- **裁判**：`wire.rs` 单元 `a_read_timeout_is_named_so_speakers_can_map_exit_11` +
  `caly_cli_e2e.rs` `an_over_cap_inbound_frame_is_refused_before_the_payload_is_read`
  （假 daemon 只写 5 字节超 cap 头：CLI <2s、exit 13、文案点名 inbound cap）。
- **证伪**：`scripts/falsify_round85.py` 2 变异（M1 摘 `wire_read_frame` 入站 cap /
  M2 CLI 把一切 wire 错映射成 timeout 文案）。ROOT=`/home/user/caly`。
- **残余**：ClientLoop / UDS 双工泵仍未接入；构造点未统一消费 `category()`/`retry_policy()`；
  app.rs 生命周期 (CONFLICT,Platform) 待议。


### 8.21 生命周期拒收消费 §4 默认（第八十六轮）

- **裁决（§8.18 残余②关账）**：`app.rs` 生命周期拒收此前是 CONFLICT + **Platform** +
  retryable=true。对照 `ERRORS.md`：§4 CONFLICT 默认 Config / 否；§5.2 是资源冲突不是 OS
  平台面；§5.8 UNAVAILABLE 是 daemon 不可达（此处 daemon 在答）；§7.2 CONFLICT 不可重试。
  overlay 新 apply 到未决 recovery 是资源冲突，操作员发的是**另一条**命令（rollback / 清
  Failed），不是重放同一条 apply。
- **实现**：`ApiError::for_code`（`category()` + Always→true / 其余→false）；生命周期拒收
  与 CAS-miss 改走它；`ApiError::internal` 委托 `for_code(Internal, …)`。`new` 仍留给
  逐例偏差（caller-mistake User、overload Internal、Maybe/Depends 实例级 true）。
- **裁判**：`error_doc.rs` `for_code_consumes_the_section_4_defaults`（14 码）+
  `durable_boot` Recovering/Failed 钉 Config 且 `retryable=false`。
- **证伪**：`scripts/falsify_round86.py` 2 变异全咬（M1 `for_code` 改写 User 0.4s /
  M2 生命周期退回 Platform+true 1.7s）。ROOT=`/home/user/caly`。
- **明确没做（文档禁止或不是一刀）**：`cargo fmt --all`（playbook / §8.6 独立提交）；
  改 502 裁判（§4.155：不降级、不改裁判掩盖波动）；ClientLoop / UDS 泵（§13#3 主体，
  第七十六轮已排除 naive `send_request_frame` 接线）；其余 `ApiError::new` 偏差点仍手写。

### 8.22 共享 BindSpec/WireIo + 生产 UDS + handshake-only ClientLoop（第八十七轮，`§13#3`）

- **关账**：`§13#3` 主体此前是 calyd/caly 各握一份 TCP-only 循环。UDS 若再抄一份
  read/write/hello 就是第二个协议。量选排除 naive `send_request_frame`（v0 是
  字符串 op + extras，双表是 API 增长不是复用）。
- **实现**：`caly_ipc::endpoint`（BindSpec / BoundAddr / WireListener /
  WireStream / WireIo；UNIX_PATH_MAX=104；chmod 0o600；TCP port-file 裸 u16；
  UDS `unix:<path>`；UDS probe 恒 Indeterminate）；`duplex::FramePump`；
  `handshake_drive::drive_client_hello`（dialect 字节、validate 先于 observe、
  records/json→Encoding::Json、CLI 角色 Admin）。`calyd`：`WireListener` +
  `serve_connection(&mut impl WireIo)`；`caly`：`WireStream` +
  `drive_client_hello`。
- **裁判**：ipc 单测 endpoint 10 / duplex 4 / handshake_drive 9 + 集成
  endpoint 10；`calyd_wire` UDS hello/status + UDS port-file 不是裸 u16；
  `caly_cli_e2e::caly_status_over_a_unix_domain_socket`。
- **证伪**：`scripts/falsify_round87.py` 2 变异全咬（M1 摘 unix: 前缀 /
  M2 跳过 `client_validate_hello_ack`）。ROOT=`/home/user/caly`。
- **明确没做**：`cargo fmt --all`（playbook / §8.6 独立提交）；改 502 裁判
  （§4.155）；`send_request_frame` 接入生产；共享 timeout scheduler；UDS peek
  （libc/nix 需 ADR）；RFC-0010 §14 整条（本轮只有 chmod 0o600）；其余
  `ApiError::new` 偏差点。


## 9. 维护规则

- 只有文档落地 -> `Documented`
- 只有目录和空文件 -> `Skeleton`
- 有可编译的部分逻辑或 partial slice -> `Partial`
- 有持续替换 placeholder 的中心逻辑 -> `In Progress`
- 满足当前阶段完成定义**且有测试支撑** -> `Done`
- 任何“已通过验证”的表述必须附带可复现命令，否则不得写入本表

不要把“代码变多了”误标为 `Done`，也不要把“已经存在但粒度不够”误标为“未开始”
——`ONBOARDING_NOTES.md §2.2` 就是后者造成本轮重复核对的实例。

---

## 10. 一句话原则

> Caly 的中心主链现在能被**执行**而不只是被**规划**；
> durable source index 已让 locator/条件请求/raw CAS/normalized/provenance/diagnostics 跨重启保持同一事实，
> 下一步的判据转为 source blocking boundary 的诚实扩展、真实 effect runtime 的跨进程/平台安全面，以及共享 timeout scheduler / typed send_request_frame 与 security 面（BindSpec/WireIo 已由第八十七轮接入），
> 而不是把 simulated 默认偷偷说成真实部署。当前门禁为 813 tests / floor 813 / clippy 基线 31；格式漂移 0 行。