# Caly 开发日志 — 2026-08-27（effect 执行闭环 + 可验证性门禁）

本轮任务：**读文档 → 掌握项目 → 接续开发**，并把掌握过程中遇到的问题留档
（留档正文见 `docs/ONBOARDING_NOTES.md`）。本文件记录“这一轮实际改了什么、如何验证、什么没做”。

---

## 1. 接手时的基线（实测，非文档转述）

| 项 | 实测值 | 与文档的差异 |
|---|---|---|
| 结构 | 19 crates / 154 `.rs` / 20,677 行 | — |
| 外部依赖 | 0（`Cargo.lock` 只有 path 成员） | 文档未强调，但它决定了很多条目能否落地 |
| `cargo check --workspace --all-targets` | 通过，**0 warning** | 文档 §3.2 声称“仍存在若干 warning”（已过期） |
| `#[test]` 数量 | **0**（连 `assert` 都是 0） | 文档称 contract/parity/scenario “可编译运行”，实际无任何断言 |
| `caly-cli` bin target | 无（19 个成员全是 `[lib]`） | 文档把 CLI 记为 `Partial`，但没有任何可执行入口 |
| `caly-io-sim` | **孤儿 crate**：无人依赖 | 文档记 `Partial` + “fault injection 已可用”，实际零接线 |
| `caly-arch-test` | 检查函数在，**无调用者** | 文档记 “allow-list 已扩展，自动依赖检查仍待深化”；实测喂入真实 manifest 即有 10 条越界 |
| `capability-registry.json` | 无任何代码解析它 | 文档/ADR-024 把它当“唯一事实来源”叙述；实为文档 |
| `caly-storage` / recovery / daemon | 已接线（journal 级） | 文档记为 `Skeleton` 且列入阻塞项（**偏保守**） |
| `cargo fmt --check` | 7,723 行 diff | 文档未提 |
| `cargo clippy` | 33 处不同位置告警 | 文档未提 |

一条方法论结论：**文档写得比代码好，但比代码旧**。照 `ROADMAP.md §13` 直接开工，
会重做已经存在的 storage/executor 接线，或去清早就不存在的 warning。

---

## 2. 本轮的接续开发内容

### 2.1 Effect 执行器（中心主链缺的那半截）

新增 `crates/caly-engine/src/executor.rs`（约 560 行含测试）。此前 `EffectPlan` 只被
`render_effect_step()` 渲染成 `Vec<String>` 塞进 job log，`APPLY_EXECUTION_CENTERLINE.md §6.1`
的三段模型在代码里没有承载体。现在：

| 能力 | 实现 | 依据 |
|---|---|---|
| typed 分派 | `phase_of` / `step_label` 按 `caly_plan::EffectStep` 变体求值 | `§3`“缺的是执行闭环” |
| 阶段单调性门禁 | `validate_effect_plan`：prepare 不得出现在 cutover 之后 | `§6.1` Phase A 不得改 active runtime |
| verify-before-commit | 无成功 `Probe` 时拒绝 `MarkSnapshot` / `CommitRevision` | `§5.1` `RuntimeVerified -> SnapshotCommitted` |
| resume 边界 | `validate_resume_boundary`：已记 cutover 的事务不得回放 prepare | `STORAGE_RECOVERY §6.2` B/C |
| 补偿与失败分级 | `ExecutionStatus::{Rejected, FailedBeforeCutover, RolledBack, RollbackFailed}`，逆序执行 compensations | `§5.1` 失败分支 + `§10`“RecoveryFailed 高于 apply failed” |
| 崩溃注入 | `ExecutionPolicy::fail_after_step` | `ADR-022`“任意 EffectStep 后崩溃” |
| 时钟注入 | `clock_start_unix_ms` / `clock_step_ms` | `clippy.toml` 禁墙钟；`ADR-011` |
| journal 折叠 | `journal_after_execution` → Committed / Abandoned / Reverted / RecoveryFailed | `STORAGE_RECOVERY §5` |
| 确定性后端 | `SimulatedRuntime`（对象 / 物化 / DB / core / net / identity） | `ADR-013` 有界执行域 |

**刻意保持纯同步**：不新增 `run_ready` 调用面（见 §4.2）。

### 2.2 worker / rollback 接线

- `apply.rs`：`ApplyWorkflowResult` 新增 typed `effect_plan: Option<EffectPlan>`，
  字符串投影保留但降级为展示用途。
- `worker.rs::execute_profile_apply`：改为“begin persistence → 执行 executor → 折叠 journal →
  成功才 finalize(snapshot/revision)”，并按 `§9` 发
  `effects.prepare.started` / `effects.cutover.started` / `effects.verify.started` /
  `snapshot.committed`；失败区分 `ConfigInvalid`(plan 被拒) / `CoreFailed`(不可自动恢复) /
  `Unavailable`(已回滚，可重试)。
- `worker.rs`：新增 `execute_profile_rollback`，替换
  `"... is not connected to recovery executor yet"`：真执行 compensations、结算 pending journal、
  无 LKG 时明确拒绝而不是“假成功”。
- `state.rs` / `service.rs`：`last_effect_plan` 记录 + `effect_runtime()` /
  `execution_policy()` / `set_execution_policy()` / `put_apply_journal()` 暴露给装配层与测试。

### 2.3 可验证性

新增 **47 个测试**（此前 0）：executor 单元 7、apply 门禁 7、仿真时钟 4、daemon command path 5、
架构门禁 7、仿真原语 10、registry 漂移 7。要点：

- **穷举崩溃矩阵**：对真实 mihomo 计划的每个步骤下标注入崩溃，断言
  「LKG 不被替换」「事务不得留在 pending/成功」「journal 记录的 phase 与实际已应用步骤一致」。
- **恢复可判定**：仅凭 pending journal（不含任何内存态）就能得出
  `CleanupAbandonedRuntime` / `RollbackToLastKnownGood` / `RevertOsEffectsOnly` 决策。
- **确定性**：同输入两次规划，typed plan、digest、capability 摘要、步骤文本全等。
- **门禁自证**：架构测试自己解析 `crates/*/Cargo.toml`，因此“新增越界依赖”“删除成员未更新表”
  “allow-list 写了一条不存在的边”都会红。

### 2.4 把孤儿仿真层接进来

- `caly-io-sim` 成为 `caly-engine` 的 dev-dependency（arch 门禁为此新增 `ALLOWED_DEV_DEPENDENCY_EDGES`）。
- `simulated_clock_execution.rs` 证明「port 级注入点」与「executor 记录的中止游标」是同一个语义。

### 2.5 让 registry 工件成为真数据

- 新增 `crates/caly-cap/src/json.rs`：零依赖 JSON 读写器 + 各枚举的稳定文本形式。
- `crates/caly-cap/tests/registry_drift.rs`：`parse(文件) == 内建 default` 且 `emit == 文件`（双向），
  另含解析器健壮性与“coverage 行必须引用已注册 key”的断言。
- 按此重新生成了 `capability-registry.json`（3 → 15 项）与 `coverage-matrix.json`（3 → 25 行）。
- 维护入口：`CALY_REGENERATE_CAPABILITY_ARTIFACTS=1 cargo test -p caly-cap`。

### 2.6 门禁与工具链

- `scripts/check.sh`：工具链存在性 → 0-warning 构建 → 测试数 > 0 → clippy 位置棘轮（33）→ fmt 报告。
  **每条检查在“没跑起来”时都必须 fail**：写第一版时我在无 `PATH` 的 shell 里跑，
  结果 cargo 不存在却打印了 “check is clean”——这种 fail-open 比没门禁更危险，已重写。
- `rust-toolchain.toml`：固定 `stable` + `rustfmt` + `clippy`，消除 §1.3 那类“作者机器状态”问题。

---

## 3. 本轮修复的 3 个真实缺陷

都是**已存在代码**里的缺陷，文档、评审、`cargo check` 都没发现，是写断言时撞出来的。

| # | 缺陷 | 后果 | 修法 |
|---|---|---|---|
| 1 | `config.identity` 注解取 **semantic digest** 校验和，而 `SpawnCore.spec.config_digest` 是 **artifact digest** | 任何按 typed plan 执行的 apply 都会被自己的 `Probe(ConfigIdentity)` 打死；“验证后才提交”整条门禁在生产计划上必然失败 | `caly-mihomo` / `caly-singbox` / `caly-core::mock` 三处统一以 artifact digest 作为 identity；并只在热路径（reload/patch）断言“陈旧 identity 必须阻断” |
| 2 | `SimWorld::crash_after_effect_step(N)` 用 label `crash-after-step-N` 注册，而 `FaultInjector` 按 label 全等匹配，调用方只查 port 名 | 该注入 API **永远不可能触发**：`ADR-022` 的核心设施在 API 层不可达 | 新增共享常量 `EFFECT_STEP_LABEL`，`world.rs` / `scenario.rs` 均用它注册 |
| 3 | `VirtualClock::advance_ms` 里 `millis as i64` 在 `millis > i64::MAX` 时变负 | 虚拟墙上时钟可**倒退**，所有 deadline/timeout 仿真会产生系统性假通过/假失败 | `i64::try_from(...).unwrap_or(i64::MAX)` 饱和化，并用测试固化“不得倒退” |

另记录一个**未改**的语义陷阱：`SharedFaults::maybe_fail` 先 `advance_step` 再匹配，
所以 `trigger_after_step: Some(N)` 实为“第 N 次调用触发”，不是“N 步之后触发”（差一）。
改匹配顺序会影响所有 fault kind，收益不抵风险，故以注释 + 断言钉住（`simulation_primitives.rs`）。

---

## 4. 未尽事项（按建议顺序）

1. `EngineHandle` 与 `InMemoryStorage` 解绑（`Arc<dyn StorageBackend>`）——否则“可替换后端”只是 trait 装饰。
2. `run_ready()` 的同步 poll-once 模型与 async storage trait 的矛盾需要决策：引入最小 executor，
   或把 trait 收回同步。**两者都需要一条 ADR**，不宜夹在功能改动里。
3. 用 `caly-io` Port 写真实 `EffectRuntime`，让本轮 47 个断言在真后端上重跑。
4. 真实 source parse / normalize（仍是 estimate 级）。
5. capability 来源切换：读文件 or 明确“文件是导出物”，并同步 `ADR-024` 措辞。
6. `RuntimeDriver::config_identity()` 与 plan 侧 identity 真连通（`RFC-0008` §6）。
7. `caly-ipc` transport runtime + reconnect/timeout；facade parity 断言化。
8. CI：把 `scripts/check.sh` 放进 workflow，clippy 从“棘轮 33”改成“新增即红”。
9. 一次独立 `cargo fmt --all` 收口，然后把脚本中的 fmt 从 note 升级为 fail。
10. 消除 `caly-engine -> caly-mihomo / caly-singbox`（`KNOWN_ARCH_DEBT` 已钉住，删除债务时会立刻变红提醒）。

---

## 5. 本版结果

```text
$ ./scripts/check.sh
== toolchain
cargo 1.98.0 (797e8a9bc 2026-08-05)
rustc 1.98.0 (88d9e12ae 2026-08-18)
== build (must be free of warnings)
  ok    cargo check --workspace --all-targets is clean
== tests
  ok    47 tests passed
== clippy (ratchet on distinct source locations)
  ok    clippy locations at baseline (33)
== formatting (advisory until the repo-wide rustfmt commit lands)
  note  ~7.4k formatting diff lines remain (tracked, not gating)
== result
  all gates passed
```

规模变化：`154 → 162` 个 `.rs`，`20,677 → 25,233` 行 Rust，`0 → 47` 个测试。

---

## 6. 一句话

> 本轮把中心主链从“会规划”推进到“会在确定性后端上执行并恢复”，
> 同时把项目自称已有、实际不存在的三道门禁（测试、依赖方向、registry 单一来源）变成真会红的检查；
> 过程中撞出的 3 个缺陷已修并留档，接手者请先读 `ONBOARDING_NOTES.md`。

---

# 第二轮（同日）：自我返工 + 后端可替换性 + IPC 框架层验证

第一轮交付后自评：我批评了别人的结构与验证问题，但**我自己那一轮的代码也有该返工的地方**。
本轮先还这笔债，再继续 `§4 未尽事项` 的第 1、7 两条。

## R1. 返工（quality）

| 项目 | 返工前 | 返工后 |
|---|---|---|
| `caly-engine/src/executor.rs` | 1,398 行：解释器 + 确定性世界模型混在一起 | 1,004 行只留解释器；世界模型移入 `sim_runtime.rs`（671 行）并补 9 个自身测试 |
| `worker.rs::execute_profile_apply` | 383 行单函数（相位、事件、错误翻译交织） | 6 个相位函数（`gate_capability` / `report_planning` / `persist_projection` / `execute_effects` / `commit_snapshot` + `report_execution`），最大 72 行；事件与 `mark_finished` 只在 `ApplyRun` 一处 |
| `ApplyFailure` 大小 | 内含未装箱 `ApiError`，把 clippy `result_large_err` 从 23 顶到 34 | `Box<ApiError>` + `with_recovery/with_deployment/with_warning` builder；**棘轮回到 33，没有抬高基线** |
| `StepOutcome::Rejected` | 同时表示“门禁拒绝”与“崩溃注入” | `Skipped { skip: StepSkip::Gate{..} \| CrashInjected }`，新增 `injected_crash_and_gate_block_are_distinguishable` 断言二者可区分 |
| `EffectExecution::next_clock_tick` | 需要在成功/失败两条路径手工同步 | 派生方法 `clock_ticks()`，删掉两处赋值 |
| `EffectStep` → 文本 | `apply.rs::render_effect_step` 与 `executor::step_label` 各一份 11 臂 match | `render_effect_step` 委托 `step_label`（`DeploymentPlanView.steps` 展示文本随之变化，字段与类型不变） |
| 重构第一稿 | 我把 `run.stage(..)?` 写成 `let _ = run.stage(..)`（吞错误） | 定稿前全部恢复 `?`，并补 `impl From<String> for ApplyFailure`：记录进度失败成为显式内部故障 |

留档一条方法论结论（已写进 `ONBOARDING_NOTES.md §4.8`）：**重构时最容易从 `?` 退化成 `let _ =`**，
因为签名变了以后编译器会诱导人“先让它过”。
| `run_compensations` 返回 `Result<usize, StepFailure>` | 回滚只报一个数字、失败即无声中断，比 apply 更不可审计 | 改为返回 `CompensationRun { steps, failure }`：回滚逐步发 `compensate NN:` 日志；失败时停在第一步并带原因上报（2 条测试，其中一条断言"优先撤销最新步骤"） |

## R2. 未尽事项第 1 条：storage 后端真的可替换

- `caly-storage` 新增 `StorageBackend`（对象安全的五 store 超 trait + blanket impl）。
- `EngineHandle` 由 `Arc<InMemoryStorage>` 改为 `Arc<dyn StorageBackend>`，新增 `with_backend(..)`；
  `with_storage(..)` 保留为便捷入口。`recovery.rs` 的 6 个函数从泛型 `<S: ObjectStore + ...>`
  改为接收 `&dyn StorageBackend`。
- **删除** `caly-engine::coordinator::CoordinatorStorage`：同一份 supertrait 列表的第二份副本，
  且全仓库无人使用（`grep -rn CoordinatorStorage` 只命中定义处）。
- 新增 `crates/caly-engine/tests/storage_backend_swap.rs`（3 个测试）：
  1. 换后端跑同一套中心线断言 → 证明可替换性不是纸面的；
  2. 注入 `ObjectStore::put = Busy` → 作业失败、不写 journal、不产生 snapshot、错误为 `Storage` 且 `retryable`；
  3. 注入 `put_snapshot = Busy`（effect 已跑完才失败）→ 必须留下可被扫描发现的恢复痕迹。

## R3. 写 R2.3 时撞出的真缺陷（已修）

`scan_recovery_state` 只调 `list_pending_apply()`（过滤 `state == Pending`），
而“finalization 失败”会把 journal 标成 `RecoveryFailed` —— **不再是 Pending，于是从启动扫描里消失**。
即 `STORAGE_RECOVERY_EXECUTION_PLAN.md §6.2` 情况 B（最需要人工介入的一种）在扫描中完全不可见。

修法：
- `ApplyJournalStore::list_unresolved_apply()`（`Pending | RecoveryFailed`），扫描改用它；
- `build_recovery_scan_report` 对 `RecoveryFailed` 产出 `RecoveryDecision::EnterFailedState`
  （不自动重放回滚，只持续报警）；
- 报告字段更名 `unresolved_apply_journals`；**daemon 公开 DTO 的 `pending_apply_count` 名称保持不变**
  （`STYLEGUIDE.md`：进入公开 DTO 的命名优先稳定）。

## R4. 未尽事项第 7 条的一部分：`caly-ipc` 框架层测试

`caly-ipc` 此前 0 测试。新增 `tests/session_and_frames.rs`（18 个）覆盖：

- 帧编解码：round-trip、声明长度与载荷不符 → `InvalidLength`、非 UTF-8 → `Truncated`；
- `make_header` 的 `usize as u32` **截断缺陷**（>4 GiB 长度回绕，绕过 `FrameTooLarge`）
  → 改为饱和化，并有专门断言；
- 控制帧 vs 流帧分类；控制帧默认禁止压缩；帧大小边界为**包含**上界；
- 协商：JSON 直通；MsgPack/Zstd 仅在 policy 打开时接受；空 client name 拒绝；
  **major 不符拒绝但 minor 不符放行**（`ADR-033` 版本线独立演进）；ack 回显 feature 与 revision；
- 会话状态机：hello 前请求被拒、hello 后放行、二次 hello 拒绝（而非重置）、close 后惰性、
  会话内 major 绑定请求；
- 流策略表与 `§Reset 是一等公民`（`ADR-019`）。

**未做**：transport 运行时（socket 读写泵、reconnect、timeout 调度）——它需要 `std::net`/`UnixStream`
线程与超时调度，属于独立的执行模型决策，与 `run_ready` 那条同源，应一起由 ADR 收口。

## R5. 本轮结果

```text
$ ./scripts/check.sh
  ok    cargo check --workspace --all-targets is clean
  ok    81 tests passed
  ok    clippy locations at baseline (33)
  note  formatting diff lines remain (tracked, not gating)   # 本轮把新触到的文件也格式化了，噪声下降
  all gates passed
```

规模：**165** 个 `.rs` / **26,713** 行 / **81** 个 `#[test]`（第一轮结束为 47）。
本轮新增 5 个源文件级改动模块：`sim_runtime.rs`（新）、`storage_backend_swap.rs`（新）、
`session_and_frames.rs`（新）、`caly-storage/src/store.rs` + `memory.rs` + `execution.rs`、`caly-ipc/src/codec.rs`。

## R6. 下一轮建议（替换上一轮 §4 的排序）

1. **落盘 `StorageBackend`**（缝隙已开，参考 `FlakyStorage` 的形状）：需要 ADR 冻结写入顺序与 fsync/rename 边界。
2. **`run_ready` 与 async Port 的统一决策**：这同时解锁“真 effect 后端（`caly-io` Port 实现 `EffectRuntime`）”
   与“IPC transport 运行时”两项——它们卡在同一处。
3. 真实 source parse / normalize。
4. capability 来源切换（读 JSON 或明确“文件是导出物”）。
5. `caly-mihomo` / `caly-singbox` 产物字节的 golden 测试 + facade parity 断言化。
6. CI：把 `scripts/check.sh` 放进 workflow，并把 clippy 从“棘轮”改成“新增即红”、fmt 从 note 改成 fail。

---

# 第三轮（同日）：补上缺失的生产 IO 网关，并把 RFC 的契约测试变成能跑的东西

## T0. 为什么选这一件事

前两轮结束后，`IMPLEMENTATION_STATUS.md §7` 的第一条是"后端可替换"（已做），第二条是
`run_ready` 的执行模型矛盾。但在挑下一件事时，我发现有一条**被 RFC 明确要求、却完全没有承载体**的项：

- `RFC-0006 §15`：`caly-io-std` 与 `caly-io-sim` **SHOULD 通过同一套契约测试**（并列出 7 条最低项）；
- `RFC-0001 §204 / §1461`：`caly-io-std` 是 workspace 规划成员；
- `ROADMAP.md §4`："仍需补齐：`caly-io-std`"。

而 **`caly-io-std` 这个 crate 根本不存在**（`ls crates/` 只有 `caly-io`、`caly-io-sim`）。
于是"单一 IO 网关"（`ADR-011`）只有一个仿真实现：网关的形状有了，生产的那一半没有。
补它，同时把 §15 的契约做成两侧共用的测试，是这一轮的中心。

## T1. 落地的东西

1. **新 crate `caly-io-std`**（成员 19 → 20）
   - `StdFs`：`Fs` 全部 8 个方法。root 目录沙箱（`resolve` 二次校验，`VPath` 与 Fs 两层互不依赖地拒绝逃逸）；
     `write_atomic` 按 `ADR-014` 分层：`D0` 直写、`D1` 临时文件 + rename、`D2/D3` 再加 `fsync(file)` + `fsync(parent)`；
     `link_or_copy` 先试 `hard_link` 失败退 `copy`；锁用 `create_new` 的 `.lock` 文件建模。
   - `StdClock`：`mono()` 以进程起点为基准（不受墙钟跳变影响），`now()` 取 `UNIX_EPOCH` 偏移，
     `sleep_until` 分片睡眠以便 `advance_ms` 生效，过期目标立即返回。
   - `Http` / `Proc` / `Platform` **不做**：它们依赖仍未决策的执行模型；不假装实现。
2. **`caly-io/src/contract.rs`：共享契约套件**（与 trait 同处，返回违规列表而非 panic）
   `vpath_escape_violations` / `fs_contract_violations` / `fs_lock_violations` /
   `clock_contract_violations` / `fault_kind_vocabulary_is_distinguishable`，并附一张
   "§15 七条 → 覆盖状态"表；两个后端各自 `tests/contract.rs` 调用同一批函数（std 8 个测试、sim 6 个）。
3. **`FsLocking` trait**（`lock` / `release` / `release_path`）：补上 `Fs::lock_exclusive` 缺失的释放半边。
4. **`caly-io` re-export `Actor / TraceId / RequestContext / IoBudget`**：后端不必再顺带依赖 `caly-common`
   （`caly-io-std` 因此只依赖 `caly-io` 一条边，已在 arch allow-list 中登记并注释理由）。

## T2. 顺手修掉的两处（都是这一轮撞出来的）

| 缺陷 | 后果 | 处置 |
|---|---|---|
| `SimFs::lock_exclusive` **永远返回成功** | 仿真里测不出锁竞争，而崩溃恢复正依赖"锁还在"；另外 `FileLock` 无 guard、无 `Drop`，trait 层面根本没有 release | 锁改为在 `MemFs` 里放/删锁文件记录，与 `StdFs` 同构；`FsLocking` 提供 release；契约测试同时约束两侧 |
| 根 `clippy.toml` 无差别禁 `std::fs::File` / `SystemTime::now` / `Instant::now` | **把唯一被授权碰世界的网关也封死了**：`ADR-014` 的 fsync 与 §15.5 的单调时钟都写不出来 | 新增 `crates/caly-io-std/clippy.toml`（clippy 会向上查找配置）只在该 crate 放开这三个符号，**保留** `Command` 与 `PathBuf` 禁令；豁免位置受限且自带理由，而不是散落 `#[allow]` |

另外：`Waker::noop()` 现已稳定，替掉两处手写 no-op waker（`clippy` 棘轮由 33 → **32**，基线随之调低）。

## T3. 门禁本身的缺陷（自我证伪后发现）

写完后我把门禁**故意弄坏**来验证：加一行 `let unused_binding = 1u8;` →
`FAIL cargo check produced warnings/errors` + `FAIL clippy locations grew: 33 > baseline 32`，退出码 1 ✓；撤销后恢复绿 ✓。

但在此之前我发现同一份代码连跑两次，clippy 计数在 34 / 33 / 32 之间跳——
因为 **cargo 按 crate 缓存 lint 结果**，只有被重编的 crate 会重放告警。
一个数字随缓存漂移的门禁等于没有门禁（而且它长得像绿灯）。
处置：lint 阶段改在一次性 `CARGO_TARGET_DIR`（`mktemp -d`）里跑，每次全量；测试阶段仍用常规目录。
这条与 `§2.5`（arch 守卫无人调用）、`§3.1`（0 测试也报 ok）是同一个错误的三个实例，
已作为 `ONBOARDING_NOTES.md §4.12` 留档。

还有一条操作性教训（`§4.13`）：我用单行锚点给 `ALLOWED_DEPENDENCY_EDGES` 加新边，
而该常量早被 rustfmt 重排成多行，替换**静默未命中**，`caly-io-std -> caly-io` 漏登记——
抓到它的正是上一轮加的棘轮测试。此后脚本化改动一律 `assert old in s`，并且以门禁输出为准而不是相信编辑成功。

## T4. 本轮结果

```text
$ ./scripts/check.sh
  ok    cargo check --workspace --all-targets is clean
  ok    95 tests passed
  ok    clippy locations at baseline (32)
  note  formatting diff lines remain (tracked, not gating)
  all gates passed
```

规模：**169** 个 `.rs` / **28,149** 行 / **95** 个 `#[test]` / **20** 个成员 crate。
本轮测试数变化：81 → 95，即 `+8`（`caly-io-std/tests/contract.rs`）`+6`（`caly-io-sim/tests/contract.rs`）；
新增 4 个 `.rs` 文件（两个 contract 测试、`caly-io/src/contract.rs`、`caly-io-std/src/lib.rs`），与 165 → 169 一致。

## T5. 下一轮（更新排序）

1. `caly-storage` 的 `StdFs` 落盘后端（现在缝隙与网关都齐了）：journal / snapshot 走 `Fs`，
   `ADR-014` D3 的"与 DB 提交协同"落在 storage 层。
2. 执行模型决策（`block_on` vs 收回同步 trait）→ 同时解锁 `Http` / `Proc` 适配器与 IPC transport 运行时。
3. `run_ready` 若保留，应改为对 `caly_io::contract::block_on_ready` 复用，避免两份手写 waker 语义。
4. 真实 source parse / normalize；capability 来源切换；facade parity 断言；CI 接入。

---

# 第四轮（同日）：让中心主链第一次跨进程闭合（落盘存储）

## U0. 选这一件事的理由

上一轮结束时 `IMPLEMENTATION_STATUS §7` 的第一条已经变成"没有落盘实现"。开工前先确认存储层到底
能不能落盘，结果发现一个接口级的空洞：

```bash
grep -n "pub struct CasWriteIntent" -A 4 crates/caly-storage/src/cas.rs
#   pub object: CasObjectRef,
#   pub source_label: String,        ← 没有载荷
```

`ObjectStore::put` 只收元数据。也就是说**所谓"内容寻址存储"里从来没有内容**：
`memory.rs::materialize` 的实现是 `if contains_key(digest) { Ok(()) }`。
`RFC-0007 §6.4` 要求物化"得到可供目标消费者使用的工件副本"，在这个接口上任何后端都做不到 ——
这解释了"可落盘"为什么长期停在 `Skeleton`：不是执行器没写完，是存储接口没有内容通道。

## U1. 补载荷 + 真摘要

- `CasWriteIntent` 增加 `payload: Vec<u8>`，并提供 `metadata()` / `with_payload()`；
  纯索引场景（只登记外部 blob）仍然合法，但**不能物化**（明确报 `IntegrityViolation`）。
- `ApplyStorageProjectionInput` 增加 `artifact_bytes`，由 `caly-engine::apply` 从
  `compile.artifact.bytes` 填入 —— 编译产物第一次真正进入存储。
- `CasObjectRef` 增加 `content_sha256`，由**存储**在写入时计算（不信任调用方声明；声明不符直接拒写）。
- `caly-common::digest`：纯 std 的 SHA-256。**为什么不直接改 `artifact_digest`**：现有
  `artifact_digest` 是 `"{core}:{:016x}"` 的 64 位 FNV 型校验和（`caly-core::native`），
  它同时是 revision/snapshot 标识的来源，换掉会牵动一整层既有断言；而且 64 位非密码学校验和
  本来就**不能**用来发现截断/篡改。所以职责分开：pipeline 标识照旧，完整性交给 sha256。
  实现用 NIST 向量（空串 / "abc" / 56 字节边界）证伪，不是自洽即可。

## U2. 新后端 `caly-storage::FsStore`

经 `caly_io::Fs` 落盘，**本 crate 内没有任何 `std::fs`**（`ADR-011` 的"单一 IO 网关"因此可检查：
`grep -rn "std::fs\|std::process" crates/` 在 `caly-io-std` 之外只命中测试与文档注释）。

- 布局按 `RFC-0007 §6.1`：`objects/sha256/<aa>/<bb>/<rest>`、`meta/objects/*.obj`、
  `records/<kind>/*.rec`、`pointers/last-known-good`
- 写入顺序按 `§6.2`：先内容、回读校验、再让元数据/清单指向它 —— 崩溃不会留下"清单有记录但文件不存在"
- 耐久按 `ADR-014`：对象 D2、快照/OS-journal/apply-journal/清单 D3（journal 必须领先于不可逆副作用）
- 物化按 `MaterializationMode`：`Copy` 走读+写（CAS 原件保持不可变），`Hardlink/Reflink` 走 `link_or_copy`
- 读路径全部重算摘要比对，不匹配 → `IntegrityViolation`（`§6.3`"不得静默容忍"）

两个被迫的取舍，都写进了留档：
1. `Fs` Port **没有 `readdir`** → 只能维护 `manifest/<kind>.idx` 当可枚举集合；副作用是"清单 vs 实体"
   成为新失效模式，故 `open()` 加载阶段逐条校验、宁可拒绝启动也不跳过坏记录。给 `Fs` 加 list 需 ADR。
2. 记录编码自己写（`record.rs`，行式 `key=value`）：无 serde 可用。选行式而非手写 JSON 的理由是
   support bundle 里可 grep、可拒绝未知字段（v2 文件不会被当 v1 半读）、加字段不会靠位置错位静默串位。
   `open` 对未知 tag / 未知字段 / 类型不符一律报错，各有测试。

## U3. 顺手的收敛

`block_on_ready`（"poll 一次且要求已就绪"）此前有**三份**：`caly-io::contract` 一份、
`caly-engine::recovery::run_ready` 一份（还自带手写 `Wake`）、storage 又要一份。
统一到 `caly_io::runtime::block_on_ready`，其余两处改为再导出/委托 —— 限制本身不变，
但从"三处可能各自漂移"变成"一处写明并测试"。

## U4. 测试（+29，累计 129）

| 文件 | 数 | 断言的东西 |
|---|---|---|
| `caly-common` digest 单测 | 5 | NIST 向量、分块/填充边界、单比特变化、匹配器的严格前缀语义 |
| `caly-storage/tests/record_codec.rs` | 10 | 每种记录 round-trip；含 `=`/换行/反斜杠；未知版本拒绝；未知字段拒绝；缺字段按名报错；坏枚举/坏整数/悬空转义；空文件 |
| `caly-storage/tests/fs_store.rs` | 8 | 内容回读一致；物化落地字节精确；**篡改内容 → 拒绝物化**；篡改后 `open()` 失败而非跳过；元数据-only 不可物化；**重启后**快照/LKG 指针/未完成 journal 全部复现；`RecoveryFailed` 重启后仍被上报 |
| `caly-storage/tests/fs_store_on_real_disk.rs` | 4 | 内容真的落成文件并按 digest 定位；**重启后**只靠目录复原（快照 + 未完成 journal + 指针文件）；越带篡改双重拦截；D0–D3 都产出正确字节且不留临时文件 |
| `caly-engine/tests/durable_centerline.rs` | 7 | 真流水线跑在 `FsStore` 上；产物按自身 digest 存在盘上且与编译结果逐字节相同；**换一个新 engine + 重新 open 同一块盘** → 已提交快照可恢复、扫描干净；被打断的 cutover 重新出现为 `RollbackToLastKnownGood`；无 LKG 时升级为 `RevertOsEffectsOnly`；第二次 apply 移动标记但**不删除**上一份快照记录（`§7.2`） |

其中"重启"这一类此前根本无法写：`InMemoryStorage` 的生命周期就是进程的生命周期。

## U5. 门禁与结果

```text
$ ./scripts/check.sh
  ok    cargo check --workspace --all-targets is clean
  ok    129 tests passed
  ok    clippy locations at baseline (32)
  note  formatting diff lines remain (tracked, not gating)
  all gates passed
```

本轮 clippy 一度涨到 34：两处是我新写的 SHA-256 循环（`chunks_exact(64)` → `as_chunks::<64>()`、
`for i in 0..16 { w[i] = .. }` → `iter_mut().enumerate()`）。**改代码而不是调基线**，改完回到 32，
向量测试仍全绿（说明重写没改语义）。

规模：177 个 `.rs` / 31,085 行 / 129 测试 / 20 个成员 crate。

**真盘那一半不是可选的。**`crates/caly-storage/tests/fs_store_on_real_disk.rs`（4 条）第一次跑就红了：
我按仿真的习惯给 `runtime_path` 传了带前缀的路径，`StdFs` 于是写出 `<root>/store/store/runtime/...`。
仿真后端没有自己的根，**双层前缀这种错误只有在真文件系统上才看得见**。
顺带暴露一个规范空洞：`RFC-0007 §6.4` 从没说 `runtime_path` 相对谁。已在 `fs_store.rs` 模块文档与测试注释
两处写明"相对 store 根、前缀由 `FsStore` 负责"，并把"写进 RFC"列入下一轮建议（`ONBOARDING_NOTES.md §4.17`）。

## U6. 下一轮

1. **`Fs::list` + mtime（需 ADR）**：去掉 `manifest/*.idx` 这层自造索引，消除"清单与实体不一致"这一类失效；
   有 mtime 后 grace period 不再依赖调用方注入 `stored_at_unix_ms`；
   同时把 `MaterializationRequest::runtime_path` 的基准（相对 store 根）写进 `RFC-0007 §6.4`。
2. **执行模型 ADR**：`block_on` vs trait 收回同步。它同时解锁 `Http`/`Proc` 适配器、IPC transport 运行时，
   以及"真 effect 后端 = 用 Port 实现 `EffectRuntime`"。
3. `caly-daemon` 启动时真的从 `FsStore` 恢复（现在 engine 侧能力齐了，daemon 还只在内存上演示 seed/scan）。
4. `§8` GC root 集：pending journal / active snapshot / LKG 引用对象不得被回收。
5. 真实 source parse/normalize、capability 来源切换、facade parity 断言、CI 接入。

---

# 第五轮（同日）：GC 落实 + daemon 真的从盘上恢复

## V0. 选这两件事的理由

上一轮留下的两项里，`Fs::list` 与执行模型都需要 ADR（要改冻结的 trait）；能立刻做的只有
`§8` GC root 集与"daemon 启动真的读盘"。动手前照例先确认接口能不能承载，结果两处都不行：

- `ObjectStore` 只有 `put / get / materialize` —— **不能枚举、不能删除**。
  于是 `RFC-0007 §13`（GC）与 `STORAGE_RECOVERY §8`（root 集）在任何后端上都**无法实现**，
  不是"实现得弱"。`grep -rn "gc\|garbage" crates/` 动手前零命中。
- `DaemonApp` 的后端一直是 `InMemoryStorage`：所谓"启动恢复"只在一个进程内成立。

## V1. GC：策略与存储分离

- `ObjectStore` 增 `list_objects()` 与 `delete(digest) -> bool`，**store 保持无策略**：
  它不知道什么是 root，所以"随手 delete"不会被误当成 GC 安全动作。
- 新增 `caly-storage/src/gc.rs`：
  - `collect_gc_roots` 覆盖 `§13.1` 六类 root（active snapshot / LKG / retained snapshots /
    已登记 revision / 未完成 journal（Pending **与** RecoveryFailed）/ running job / 手动 pin）
    + grace period；`GcRootReason` 让"为什么没删"可解释，doctor 能直接引用。
  - `plan_object_gc` 纯函数（不碰 store），单轮 `max_deletions` 上限：**一个 bug 不能一轮清空整个库**。
  - `run_object_gc` 按 `§13.2` 先标记后清扫；删除失败不中断整轮但计入 `GcReport.failed`。
  - 资格门禁 `GcEligibility{idle, pending_deployments}`：`§13.2` 的 SHOULD 被写成**类型化的拒绝**
    （`Busy` + "gc refused by policy"），让"在 apply 中间跑 GC"不再是看起来合理的操作。
- grace period 与时间：本 crate 无时钟、`Fs::stat` 的 `Meta` 又没有 mtime，所以
  `CasObjectRef.stored_at_unix_ms` 由**写入方注入**（apply 路径复用 journal 那条注入时钟）。
  取舍写在模块头：**年龄未知 = 永久在 grace 内**。多留一轮可逆，误删不可逆。

## V2. daemon 从盘恢复

`DaemonApp::try_bootstrap(config, backend: Arc<dyn StorageBackend>)`。后端**注入**而非在 daemon 内
构造：选哪种存储是 composition root 的事，`ADR-011` 把宿主接触留在端口层，所以 `caly-daemon`
仍然没有任何文件系统依赖（只有测试才引 `caly-io-std`，已在 arch 的 dev 边里登记并注明"不得转成生产边"）。

顺带修掉两个真问题（`ONBOARDING_NOTES §4.19`）：
1. 恢复只回填 `active_snapshot`，不回填 `active_profile / active_core / last_apply_plan_summary`
   → **重启后 `system.status` 报"没有活动 profile"，而同一个 daemon 又能继续在其上 apply**：
   同一个问题两个答案，取决于进程是否重启过。现在按 id 读回完整 snapshot 记录回填三项；
   若 marker 指向读不回的记录，daemon 直接 `Failed` + `last_error`，不假装"空但健康"。
2. `let _ = app.recovery_scan().and_then(...)` 是又一处 fail-open。
   `try_bootstrap` 现在对扫描失败**拒绝启动**（`store_unusable = true`）；
   保留的 `bootstrap()` 因为签名不能失败，改为把原因记进 `last_error` + `Failed`。

## V3. 测试（+13，累计 142）

| 文件 | 数 | 关键点 |
|---|---|---|
| `caly-storage/tests/gc.rs` | 9 | 六类 root 各自生效且理由正确；未引用**且**过 grace 才回收；未知年龄不回收；grace 到期后同一对象可回收；单轮上限且超额项被报为 blocked；忙/非 idle/未枚举三种拒绝；删除后二次运行幂等；**共享内容不被误删**、survivor 仍能物化、清单同步收缩、重启后只剩一个对象 |
| `caly-daemon/tests/durable_boot.rs` | 4 | 重启后 `active_profile/active_core/snapshot/plan` 全部从盘复原；崩溃事务跨**两次**重启仍报 `Recovering` 且计数为 1；盘被撕裂时 store 拒开且 daemon 拒启；内存入口保持不失败且不谎报错误 |

`§15.6` 的验收条款（"GC 不删除被 Active/Snapshot/Journal 引用对象"）现在是真的可跑的测试，
而不是文档里的一句话。注意 `gc.rs` 里有一组断言是**反向**的（未引用者必须被删）：只测"不删"的话，
一个什么都不删的 GC 也能全绿。

## V4. 门禁

```text
$ ./scripts/check.sh
  ok    cargo check --workspace --all-targets is clean
  ok    142 tests passed
  ok    clippy locations at baseline (32)
  all gates passed
```

本轮棘轮又抓到 4 条属于我的 lint（两处 `let _ = ...?` 的无值绑定 + 一处因此变成死代码的
`remove_from_manifest`）：改代码、删掉那行**本来就没意义的**"先写空再删"（对象内容不需要第二个
清单，那是我起草时的残留），基线仍是 32。
另外格式化又顺带削掉几百行历史 diff（6582 → 5915）。

规模：180 个 `.rs` / 32,724 行 / 142 测试 / 20 成员。

## V5. 下一轮

1. `Fs::list` + `Meta.mtime`（需 ADR）：去掉 `manifest/*.idx`，GC 的 grace period 不再依赖注入时间。
2. 执行模型 ADR：解锁 `Http` / `Proc` 适配器、IPC transport 运行时、用 Port 实现的 `EffectRuntime`。
3. `daemon` 侧：`Recovering` 状态下**拒绝**新的 apply（现在只是报告状态，未设闸门）；`Failed` 同理。
4. `§7.3` schema 迁移：`STORAGE_SCHEMA_VERSION` 当时只是常量，无人校验 → 已在第六轮落地（见下文 W1）。

## V6. 追加：恢复状态开始真正闸门命令

写完 V2 后自检发现一处不一致：`apply_recovery_snapshot` **报告**了 `Recovering` / `Failed`，
但没人据此拒绝写入 —— 客户端只要不读 status，就能在一个未解决的崩溃事务之上再部署一次。
这正是我在 `try_bootstrap` 里选择"扫描失败就拒绝启动"时想避免的那类事，却只修了一半。

规则（刻意不对称）：

| lifecycle | 被拒 | 仍可用 | 理由 |
|---|---|---|---|
| `Recovering` | `ProfileApply` | rollback、全部查询、其余命令 | **rollback 是走出 recovery 的路**，把它一起堵死等于锁死逃生口 |
| `Failed` | 一切命令 | 全部查询 | `status` / `doctor` / `explain_pipeline` 正是诊断失败所必需 |

拒绝点是 `submit_request_as_command`（request→command 的唯一边界），不是各个 façade ——
否则闸门会变成"每加一个入口就要记得加一遍"的东西。错误用 `Conflict` + `Platform` + `retryable`，
并把"先解决未决事务（回滚到 LKG 或确认身份后接管）"写进 `remediation`。

### 写这段时又抓到两处（都记进了留档）

1. **`apply_recovery_snapshot` 末尾无条件 `runtime.lifecycle = ...`**，把前面分支刚设好的 `Failed`
   覆盖掉。不是读出来的，是新断言跑红才发现（`left: Starting, right: Failed`）——
   换句话说，这个函数当时**根本没有办法**表达"恢复没成功"。现在改成单一出口：
   先算 `unresolvable: Option<String>`，最后一次性决定 `Failed > Recovering > Starting`，
   并把原因同时落到 `last_error` 与 `last_recovery_summary`，让 status 与 doctor 讲同一个故事。
2. **我自己的"假校验"**：为了让读不回快照时更宽容，第一版加了 `get_snapshot_by_id` 失败就退回
   `latest_last_known_good_snapshot()` 的 fallback。而 `report.latest_last_known_good` 本来就是
   从那条路径算出来的 —— **用同一个说法印证它自己**，后端自相矛盾时它照样"一致"，
   `Failed` 分支永远不触发，测试也就永远测不到我想测的东西。已删除并写明"故意不做回退"。
   教训：**校验必须来自第二条独立路径，否则它是装饰。**

### 结果

```text
$ ./scripts/check.sh
  ok    cargo check --workspace --all-targets is clean
  ok    144 tests passed
  ok    clippy locations at baseline (32)
  all gates passed
```

本轮 clippy 一度 +1：`refusal_for_lifecycle(...) -> Result<(), ApiError>` 撞上
`result_large_err`（`ApiError` ≥128 字节）。改成返回 `Option<ApiError>`（语义本来就是"要么拒要么不拒"，
没有第三种失败），既不刷基线也少一层 `Result` 嵌套。同时顺手把"锁中毒"从 `Option` 返回值里剥出来，
交给调用方用 `?` 变成真正的错误 —— 状态读不到时**不放行写入**，也不假装成功。

规模：180 个 `.rs` / 33,084 行 / 144 测试 / 20 成员。

---

# 第六轮（同日）：schema 门禁落地 + 给两个结构性阻塞点开 ADR 草案

## W0. 分流原则

前五轮反复撞到的两类事，处理方式必须分开：

- **接口缺操作**（没有 `delete`、没有 `list`）→ 可以直接补，属于实现；
- **改动已冻结的边界**（`Fs` trait 形状、`Ctx` 语义、执行模型）→ 按 `docs/README.md §5` 的权威顺序
  （`RFC > ADR > 工程文档 > 代码注释`），**必须先有决策**，代码不能替架构做决定。

所以本轮 = 一条实现（`§7.3` schema，`RFC-0007 §12` 本来就冻结了规则，只是没人落地）
＋ 两份**Proposed** ADR（`§12` 之外的两件事），后者不偷偷开工。

## W1. schema 门禁（`caly-storage/src/schema.rs`）

实测起点：`STORAGE_SCHEMA_VERSION = 1` 是一个**没人读也没人写**的常量 —— 于是
`§12.2.1`（启动 MUST 兼容性检查）与 `§15.5`（迁移失败 MUST 拒绝启动）没有承载体：
v0 目录会被直接当 v1 打开。

按 `§12.2` 四条逐条实现：

| `§12.2` | 实现 | 测试 |
|---|---|---|
| MUST 先做兼容性检查 | `read_marker` + `classify` → `Absent / Current / Older{v} / Newer{v} / Corrupt{reason}`，且**在读取任何记录之前** | `a_fresh_store_is_initialised_once_and_never_rewritten_on_read` 等 |
| MUST 迁移前建可回退点 | `create_rollback_point`：把 schema marker + 全部清单 `link_or_copy` 到 `backups/v<from>/`；无物可拷时**报错而不是继续** | `a_rollback_point_over_nothing_is_refused` |
| MUST 迁移失败拒绝启动 | hook 返回 `Err` → 保留旧 marker、附 `failed_migration` + `rollback_point` 后拒绝 | `a_failing_hook_leaves_the_store_on_the_old_version_and_refuses_startup` |
| SHOULD 迁移后一致性检查 | 门禁通过才进 `load()`，而 `load()` 会逐条重算摘要 | `fs_store_writes_the_marker_on_first_open_and_reopens_against_it` |

`§12.3` 按字面实现，不做"善意推断"：

- 版本**更高**的目录一律拒开（不 try-read）；
- **有数据但没有 marker** 的目录拒开，除非调用方显式声明"这是空目录"；
- marker 存在但读不出的，**不降级为"当作没有"** —— 那样一个损坏目录会被初始化成全新的，
  里面所有记录变成静默孤儿。这是 `read_marker` 返回 `Option<Result<..>>` 三态而不是 `Option<u32>` 的原因。

迁移链要求**分步连续**：`plan(from,to)` 只接受 `v{n} -> v{n+1}` 的 hook，缺步即拒；
`from >= to` 也拒（"迁移"不允许倒退）。理由：允许 `v1 -> v3` 一步跳，等于允许跳过 v2 引入的不变量。
另外 marker **只在缺失时写**：`open()` 是读操作，每次都重写会把 `migrations_applied` 归零，
正好抹掉"这个目录是怎么变成现在这样的"这条唯一线索 —— 这点我在写完第一版才发现，
断言是 `a_fresh_store_is_initialised_once_and_never_rewritten_on_read`（故意改一个字段再开一次，看它是否被覆盖）。

## W2. 两份 ADR 草案（状态 Proposed，未开工）

- **`ADR-035`：`Fs::list` + `Meta.mtime` + `runtime_path` 基准冻结。**
  把 `manifest/*.idx` 这层自造索引换成端口能力；顺带把第五轮踩到的双重前缀问题写成规范条文。
  否决了"storage 自己用 `std::fs::read_dir`"（违反 `ADR-011`，且仿真无法注入列举故障）。
- **`ADR-036`：有界端口执行器 + `Ctx` 限额真正生效。**
  写之前先把现状钉死（可复现，不是感觉）：

  | 要求 | 实测 |
  |---|---|
  | `deadline_ms` 限制调用 | 一路传到 `Command.timeout_ms`，**没有任何地方据此超时** |
  | `cancel_token` | `RequestContext` 里**根本没这个字段**；全仓 `grep cancel` 只命中 CLI 的字符串映射 |
  | `io_budget` 限流 | `IoBudget::unlimited()` 是唯一构造方式，`request_map.rs:99` 还把入站预算**写死** unlimited |
  | `Probe { deadline_ms }` | 出现在计划与日志里，仿真 runtime 只把它打印出来 |

  结论：这不是"没写到那么细"，而是**只能 poll 一次的执行模型在结构上无法表达"等到期限为止"**。
  它同时阻塞 `Http`/`Proc` 适配器、IPC transport、真 `EffectRuntime` 三项 ——
  所以 ADR 里给出四个备选（维持现状 / 上 tokio / 端口改同步 / 执行器放引擎）并逐条写为什么不采纳，
  其中"上 tokio"被拒的实质理由是**破坏 `ADR-022` 的确定性可复现**，不是"多一个依赖"。

  唯一需要维护者明确表态的点已写在 §6：执行器若要自己数时间，`caly-io` 目前被根 `clippy.toml`
  禁止读时钟（只有 `caly-io-std` 有豁免）——要么时钟继续作为端口注入，要么给 `caly-io` 同样的豁免。

## W3. 结果

```text
$ ./scripts/check.sh
  ok    cargo check --workspace --all-targets is clean
  ok    157 tests passed
  ok    clippy locations at baseline (32)
  all gates passed
```

棘轮本轮抓到 2 条我自己的：`from_version/to_version` 触发 `wrong_self_convention`
（`from_*` 按惯例应无 `self`）→ 改名 `source_version/target_version`；测试里一处多余 `format!`。
仍然是改代码，不动基线。

规模：182 个 `.rs` / 34,139 行 / 157 测试 / 20 成员；本轮新增 13 个测试（schema 门禁）。

## W4. 下一轮（需要决策先行）

1. **等 `ADR-035` / `ADR-036` 被确认或改写**；在此之前，`Fs`/`Ctx` 的形状视为冻结，不再绕过。
2. 可并行推进（不碰冻结边界）：`caly-daemon` 的 `doctor` 输出接入 schema marker 与回退点信息；
   GC 的 grace period 在 `ADR-035` 落地前先用注入时钟做**穷举边界测试**（0 / 恰好等于 / 恰好超过）。
3. `§7.3` 迁移后的"必要一致性检查"目前复用 `load()` 的摘要校验；若要更严（记录数 vs 清单数、
   孤儿对象检测），值得单列一节而不是塞进 `open()`。

---

# 第七轮（同日）：让 parity / contract / doctor 从"能跑"变成"会红"

## X0. 切入点

第六轮把 schema 门禁做完后，`§9.2`（doctor 该报什么）仍是清单。动手前先照惯例 grep，
结果这一轮四个发现里有三个属于同一类：**机制存在，判定缺失**。

## X1. 三套报告机制没有判定者（→ 已补）

`ContractReport::all_passed` / `ParityReport::all_match` / `ScenarioSuite::all_passed` 都定义了，
`grep -rn "all_passed\|all_match" crates/` 显示**只有定义处、零调用处**：bundle 生成报告，报告被丢弃。
新增 `caly-app/tests/contract_gate.rs`（6 条）后，第一件事就是让整套 parity 暴露真相（见 X2）。
测试还要求"报告非空"：空报告 = 什么都没比较 ≠ 通过。

## X2. parity 一直比的是**两个不同的 daemon**（→ 已修）

`build_loopback_remote_client()` 内部自己 `DaemonApp::bootstrap("loopback-daemon")`，
而 local 侧是调用方另造的 `"parity-daemon"`。两侧从来不是同一份状态。

后果不是"少测了一点"，而是**方向反了**：`system.info.instance_id` 永远 Mismatch（稳定噪声），
而 ADR-017 真正要保的东西 —— 同一份状态经 local 与 remote 两条路径必须给出同一答案 ——
被埋在那堆噪声里，永远测不出来。

修法：`LoopbackRemoteTransport::with_app(daemon)` + `build_loopback_remote_client_with(daemon)`，
parity 入口改成收**一个 daemon**、两侧都从它构造（`run_parity_scenarios` 同样）。
现在 `loopback_parity_matches_after_a_real_deployment` 会先真跑一次 apply
（留下 active snapshot、连接列表、profile 列表、恢复状态），再要求 4+ 个字段全部 Match。

## X3. "查到了但没有这个对象"被当成"这个操作没人实现"（→ 已修）

`handle_request` 对三条路径的 `Ok(None)` 一律回 `"operation routed to X but no daemon handler is connected yet"`。
`FollowJob` 在 job 不存在时正好返回 `Ok(None)`。连带发现：
`run_remote_follow_scenarios` follow 的是硬编码 `JobId(1)`，**从来没提交过 job** ——
所以这条 scenario 只要真被断言就必然报错（X1 之前没人断言，于是它一直"静默失败"）。

两个方向都被误导：调用方看到"未实现"会绕开一个正常 API；实现者看到"未实现"会以为还有活没干。
改法：`FollowJob` 的 None 变成 `"no such job: 4242"`（`Conflict` + `job history is not durable` 提示），
`unsupported_request_response` 只留给真正没有 handler 的操作；scenario 改为先 apply、拿真实 job id、
确认 job 被处理，再 follow。

## X4. doctor 的占位 warning 让"没有告警"失去信息量（→ 已修）

`handle_diagnostics::Doctor` 起手塞一条固定
`"diagnostics pipeline is still partial; verify against real core runtime later"`。
于是每次 `doctor` 都非空，真实发现与占位符不可区分，而且 contract 里
`!doctor.warnings.is_empty()` 这类断言**恒真**（我把它改严之后立刻变假）。

落地内容：
- `caly-storage/src/audit.rs`：纯函数计算 `§9.2` 四类发现（dangling pending journal /
  abandoned runtime / no valid last-known-good / snapshot-object mismatch），外加
  `dangling-last-known-good`、`last-known-good-unreadable`、`missing-rollback-point`、`older-schema`。
  **`§9.2` 四条现在全部可实现且有断言。**
- 关键设计：**"读不到" ≠ "没有"**。`Observation<T>::Unavailable` 与 `Known(false)` 分开；
  `last_known_good_error` 与 `last_known_good: None` 分开。诊断工具最常见的谎话就是把
  "我查不了"输出成"一切正常"。内存后端因此老实回答"不可观测"，而不是编一个健康结论。
- `materialize` 现在留一个 durable marker（`materialized/<digest>.ok`），"runtime 目录被清空"
  才从事实缺失变成可判定；marker 写在成功之后、失败只吞不报（丢它只损失诊断，不损失部署）。
- `DoctorReport` 增加 `notes`（第三档）。信息性内容以前无处可去，只能塞进 warnings ——
  那正是占位符能活下来的原因。

## X5. 两处trait 设计的硬事实（值得单独记）

1. **blanket impl 与"可覆盖默认实现"互斥。** 我想给 `StorageBackend` 加自省 hook：默认答
   "不知道"，真后端覆写成"知道"。但 `impl<T: 五trait> StorageBackend for T {}` 已经覆盖所有类型，
   `impl StorageBackend for FsStore { … }` 立刻 `E0119 conflicting implementations`（Rust 无 specialization）。
   取舍：撤掉 blanket，改显式 opt-in。代价**当场可见** —— 三个测试替身因为少写
   `impl StorageBackend for X {}` 而编不过。换来的是那一行成为"本类型是完整可替换后端"的声明。
2. **`StorageErrorKind` 缺 `Unsupported`，而 `SchemaMismatch` / `MigrationFailed` 零使用。**
   "后端不支持"只能挤进 `Internal`。已加 `Unsupported` 并用于可选能力的默认回答；
   两个死变体保留（它们属于还没实现的 `§7.3` 迁移路径，不是遗漏）。

## X6. 结果

```text
$ ./scripts/check.sh
  ok    cargo check --workspace --all-targets is clean
  ok    168 tests passed
  ok    clippy locations at baseline (32)
  all gates passed
```

棘轮本轮抓到 1 条：我在 scenario 里对 `Copy` 类型 `JobId` 写了 `.clone()` → 去掉。
（前几轮它抓到过 11 条、3 条、2 条：同一个机制在不同人手上重复起作用，才叫门禁。）

规模：184 个 `.rs` / 35,591 行 / 168 测试 / 20 成员。本轮 +11 测试。

## X7. 下一轮

1. `SupportBundle` 仍是 `Ok(None)`（"真未实现"）：`§9.3` 要它导出 apply journal 摘要、
   active/LKG 元数据、恢复事件汇总 —— 现在 `storage_audit` 已经把原料备齐，只欠组装与脱敏（`RFC-0010`）。
2. parity 补**写侧**：同一 daemon 上 local 提交 apply、remote 提交 apply，两条路径的 job 事件流与
   `RecoveryStatus` 必须一致（目前 parity 只覆盖读侧）。
3. ADR-035 / ADR-036 的确认（`Fs::list`、`mtime`、执行模型）。
4. `doctor` 的输出接进 CLI（仍无 `[[bin]]`，见 `§3.2`）—— 需要先决定 bin 的边界。

---

# 第八轮：脱敏边界与 support bundle（X7 清单第 1 项）

## Y0. 切入点

`X7` 说 bundle「只欠组装与脱敏」。按惯例先验证而不是先相信：

```bash
$ grep -rn 'redact\|Redact\|Secret' crates --include='*.rs' | wc -l      # 本轮之前
0
$ grep -rn 'DiagnosticsBundle' crates/caly-engine/src/worker.rs
crates/caly-engine/src/worker.rs:62:        crate::command::CommandKind::DiagnosticsBundle => {
```

第一条说明「脱敏」不是不完善而是**不存在**（`RFC-0010 §3.3`/`§6.1` 与 `ADR-020 §3` 各写了 MUST，
`ADR-020 §4` 还把 redactor 列在 Follow-up Work）；第二条印证上一轮的判断：bundle 是一条 skeleton 日志。
所以本轮顺序反过来：先造 redactor（bundle 的正确性依赖它），再补 bundle 缺的原语，最后接三条出口。

## Y1. `caly-common::redact`：870 行，20 个测试（→ 已建）

规则顺序照 `§6.2` 逐条映射（见 `docs/REDACTION_AND_SUPPORT_BUNDLE.md §2.1` 的表）。三条设计决定：

1. **`REDACTED` 是常量**。`§6.3` 的重点不是标记长什么样，而是「不因前端不同而一处脱敏、一处泄漏」。
2. **幂等 + 不删**。`redact(redact(x)) == redact(x)`、行数不变、`line_count` 不变，才敢在多个边界重复应用。
3. **不猜**。`https://host/<opaque-token>` 无 key 名，任何 pattern 规则都只能启发式；启发式会误伤
   `sha256:<64hex>` 这类对象地址。于是这类值必须 `register_secret()` —— 这恰好是 `§3.3`
   「在对象构造或边界转换时完成」的字面含义：知道 secret 的人负责登记。

`Default` 与 `Strict` 两档对应 `§4`（Secret）与 `§4.1`（准 secret）。**这里有一次需要 maintainer 确认
的解读**：`§4` 把 UUID 列为 Secret、`§4.1` 又把身份信息列为准 Secret，本轮取「带 key 名的
`uuid = "…"` 默认就掩、裸 UUID 只在 Strict 掩」，并让 `looks_like_uuid` 显式拒绝更长的 hex 串。

## Y2. 三条出口各过 redactor 一次（→ 已接）

| 出口 | 落点 | 为什么不是别处 |
|---|---|---|
| job 日志 / stage / warning / `Failed` | `EngineHandle::append_job_event` | 引擎内唯一写 job 事件处；follow、stream、bundle 都只是读者 |
| `ApiError` | `handler::handle_request` → `DaemonApp::redact_error` | `ApiError::new` 散布十几个 crate 且多处插值自己不拥有的文本；门面响应是唯一必经点 |
| bundle | `BundleDraft::finish(&Redactor)` | 让「未脱敏的导出物」在类型上不存在 |

实测的失败注入（本轮跑过一次即还原）：把 `redact_job_event` 那一行注释掉后，
`cargo test -p caly-engine --test support_bundle` → `7 passed; 1 failed`、
`-p caly-daemon --test redaction_boundary` → `5 passed; 1 failed`。
也就是说 bundle 与 `ApiError` 两条边界**不依赖**日志边界：三条出口独立成立，这是刻意的冗余而非巧合。

## Y3. `§9.3` 第 1 项在接口上做不到：journal 无法枚举已提交事务（→ 已补）

`ApplyJournalStore` 只有 `list_pending_apply` / `list_unresolved_apply`。"最近若干次 apply 的摘要"
需要的 `Committed` 恰好被两者排除 —— 与 `ONBOARDING_NOTES §4.18`（`ObjectStore` 不能枚举 → GC 无处下手）
同一类缺口。新增 `list_apply_journals`，默认 `Unsupported`（不是空列表）：

- `InMemoryStorage` 回答内存表；
- `FsStore` **重新经 manifest 读盘**，因此记录损坏时导出报 `IntegrityViolation`，而不是把缺的那条
  静默省略（`tests/apply_journal_listing.rs::a_torn_record_aborts_the_list_instead_of_being_skipped`）。

`bundle::enumeration` 把「不支持 / 读不到 / 有内容」三分开：不支持 → 段里写 `not enumerable`；
其他错误 → 整个导出失败。诊断工具把一个读不出的 store 渲染成"一切正常"，比没有工具更糟。

## Y4. `doctor` 与 bundle 曾需要两份审计装配（→ 抽公共函数）

`DaemonApp::storage_audit()` 有 ~60 行「读后端自省 + 组装 `AuditInput`」。bundle 要同样的结论；
照抄就是两份会各自漂移的实现。下沉为 `caly_storage::audit_backend(backend, now)`，并给
`StorageAudit` 补 `finding_lines()`（按发生顺序的全量视图 —— doctor 的三档分层是给人 triage 用的，
导出物把三份列表重排会把 info 读成 error）。新增 `doctor_and_the_bundle_report_the_same_finding`
断言两者不仅 finding 相同、**同一行 summary 字符串**也相同。

## Y5. bundle 的形状（→ 已实现）

10 个固定段（`BUNDLE_SECTIONS`，渲染顺序即声明顺序）：`header · architecture · capability ·
apply-journals · snapshots · recovery · effect-plan · runtime-log · resources · storage-audit`，
覆盖 `§9.3` 四项 + `§12.2` 六项。字节走 `ObjectStore::put`（`ObjectKind::SupportBundle`），
对象 key 即内容 `sha256:`，作业上报摘要 + `Stage{"bundle.committed", 100}`。

明确**不做**两件：写到用户指定路径（`ADR-011` 下 daemon 无平台层）；给 bundle 开 GC 根
（`§13` grace period 之后回收，正是导出物应有的生命周期）。两条都写进文档，不留成"读者自行推测"。

## Y6. 本轮抓到的自己的问题与一处文档缺陷

1. `collect_header` 初稿 `handle.bundle_identity().unwrap_or_default()` —— 又是 `§4.19` 刚修过的
   `let _ =` fail-open 家族。改为显式分支并在 `header` 段写明「instance identity unavailable」。
2. `ApiError::redacted` 初稿顺手 `.filter(|value| value.is_empty())`：脱敏不是丢弃数据的许可。删掉。
3. `clippy.toml` 的 `PathBuf` 禁令**同样命中测试目标**（`--all-targets`）：daemon 测试因此改用 `String`。
   棘轮本轮抓到 3 条自造 lint（`manual_contains` ×2、`needless_range_loop` ×2、`filter_map`→`map`），
   全部改代码，基线仍是 32。
4. `ONBOARDING_NOTES.md §6` 有两个 `6.10`（表格行与表格后的小节标题撞号）。一份记录「文档与代码不符」
   的文件自己编号重复，也得算缺陷 —— 已把小节挪到 `6.28`（`§4.34`）。

## Y7. 把这轮的"人肉复核"变成门禁（→ 新增）

上面三条文档缺陷（两处编号重复、一处成员数过期）都是靠人读出来的，而人读不准。于是本轮把可机检的部分
写成 `caly-arch-test::docs`，由 `tests/doc_consistency.rs`（13 条单元 + 5 条 gate）每次 `cargo test` 扫全部 `docs/**`（现 72 篇 Markdown）：

| 规则 | 为什么值得一个门禁 |
|---|---|
| 表格每行列数一致、且表头后必须有 `|---|` | 渲染器直接不认为它是表格；反引号内与 `\|` 转义的竖线**不**算列分隔符（本仓文档大量在单元格里贴 grep 命令） |
| 有序列表连号 | `docs/README.md §2.5` 两个 `3.` 存在了不知多久 |
| 同文件内小节号唯一 | `ONBOARDING_NOTES §6` 的表行 `6.10` 与小节标题 `6.10` 撞号；`3.` 与 `3` 归一化后视为同号 |
| 反引号里的 `crates/…`/`docs/…`/`scripts/…` 路径必须存在 | **这一条最值**：本轮实测 198 处此类反引号片段，其中 154 处是可直接判定的引用（15 处通配、29 处只到目录），0 处失配；改名/删文件会立刻炸，而不是等下一个人踩 |
| 文中 `caly-*` 必须是 workspace 成员，或写进 `DOCUMENTED_NON_MEMBER_CRATES` | `RFC-0001` 里的 `caly-tui` 是"计划中"，允许，但必须留理由（`ONBOARDING §5.3`） |

三条纪律：① 检查函数全是 `fn(text) -> Vec<DocIssue>` 的纯函数，文件系统访问留在测试侧，所以每条规则
都能在单元测试里被**证伪**（先让它失败，再修文档）；② 有一条反-vacuity 断言（文件数 ≥60 / 引用数 ≥100 /
行数 ≥8000），否则"扫到 0 个问题"可以只是"什么都没扫"；③ 通配符引用（`crates/*/Cargo.toml`）不算断链 ——
第一版把它判成违规，是门禁自己先犯了"把模式当引用"的错，改了规则而不是放宽断言。
实测一：给 `SCENARIO_SUITE.md` 追加一行少一列的表格行 + 一个重复的小节号 + 一条指向不存在文件的引用，
门禁立刻报出三处并 `FAILED`，随后还原。
实测二：把 `§3.3` 表里 `redact.rs` 的数量从 20 改成 24 并删掉 `schema.rs` 那一行，门禁立刻报
`stale-count`（数量失配）、`stale-count`（合计 231 vs 行和 222）、`broken-path-reference`（缺行）三条。（写这段的时候，那句"指向不存在的文件"的例子本身用了反引号包住的
假路径，于是新门禁**先把开发日志判为违规** —— 规则生效得比预期还快，例子已改为不带路径的写法。）

## Y8. 结果

```text
$ ./scripts/check.sh
  ok    cargo check --workspace --all-targets is clean
  ok    251 tests passed
  ok    clippy locations at baseline (32)
  note  2785 formatting diff lines remain (tracked, not gating)
  all gates passed
```

规模：191 个 `.rs` / 39,764 行 / 231 测试 / 62 个 test target / 20 成员 / 71 篇 Markdown。本轮 +63 测试（168 → 231）。
格式化欠账 5,476 → 5,300（只格式化本轮触碰的文件）。

## Y9. 下一轮

1. **parity 写侧**（`X7` 第 2 项，仍未做）：同一 daemon 上 local 与 remote 各提交一次 apply，
   比较两条路径的 job 事件流与 `RecoveryStatus`。目前 parity 只覆盖读侧，而本轮暴露的
   「同一 store 两份装配」正是写侧最容易出分歧的地方。
2. **`SupportBundle` 的取回**：CAS 里有字节，客户端只能拿到摘要。要么给 `caly-api` 增加
   按摘要读取导出物的查询（`DiagnosticsOp` 新变体），要么等平台/导出位置决策 —— 需要选一条。
3. `SupportBundle` 的 `§12.2` 还缺"资源统计"里的真实进程/IO 计量（现在只有计数）：
   需要 `ADR-036` 的执行器决策才能引入 IO 计量而不破 `Ctx` 的冻结形态。
4. ADR-035 / ADR-036 的确认（第 6 轮起就挂着）。
5. `doctor` 接进 CLI（仍无 `[[bin]]`，见 `§3.2`）—— 先决定 bin 的边界。

---

# 第九轮：写侧 parity（`X7`/`Y9` 清单第 1 项）

## Z0. 切入点与开局的环境退化

两件开局就得记下的事：

1. `./scripts/check.sh` 报 `Permission denied`，随后 `cargo not found on PATH`。实测：跨会话快照留下了
   `~/.cargo/bin/rustup`（20 MB 真文件），却没留 `~/.rustup`，于是 `cargo`/`rustc` 那些软链全部失效；
   模式位也没保住。按 `§1.3` 重装后继续，教训写进 `ONBOARDING §4.43`（新开局先 `bash scripts/check.sh`）。
2. `Y9` 说 parity 只覆盖读侧。按惯例先验证"只覆盖读侧"这件事本身：`grep` 过 `run_basic_parity_check`
   的 12 次比较，**全是查询**。于是这一轮的目标定为：把写入放进同一套比较里，并且让它有机会失败。

## Z1. 常量 idempotency key：第二次远端写操作被静默吞掉（→ 已修，`§4.37`）

`remote_facade.rs` 五处写操作各自传了 `"profile-apply"` 这类**按操作类型固定的常量**当 key，而
`LocalFacade` 传 `None`。引擎侧 `submit_checked` 只看 `(actor, key)`，**不比载荷**，所以
`("Cli","profile-apply")` 是整个 daemon 的一个槽位：同一 daemon 上第二次远端 apply（任何 profile、
任何调用方）返回第一次的 job 并原地"完成"。这是 `RFC-0002 §4.1` 明文 MUST 共享的语义。

为什么长期没人发现：contract 那条 `remote.profile.apply.accepted` 断言 `job_id > 0`，被去重的旧 job
当然 > 0。**断言"有个号"和断言"发生了这次写"是两件事** —— 后者需要比 delta、比事件、比形状。

修法：key 只能来自 `Ctx`（`idempotency_key: Option<String>`，`ADR-021 §5` 允许这种向后兼容扩展），
两条路径读同一个字段；并把原因钉成行为测试 `a_constant_key_would_swallow_the_second_deployment`。

## Z2. `Accepted.estimated_impact` 与重放答案都是被重建的（→ 已修，`§4.38`）

引擎已经分类过（`dispatch::classify_command`：apply→`Restart`、select→`Reload`、repair→
`PrivilegedNetworkChange`），但 `submit_engine_command` 只留 `job_id`，`handler.rs` 再拼一个
`Accepted{ estimated_impact: ReadOnly, … }`。于是"这次会不会重启 core"对任何命令都是"什么都不会变"。
幂等重放路径同样重建一份（用当前 generation + ReadOnly）—— 同一请求第一次与第二次答案不同，直接违反
`§8.3`「返回原 JobId 或等价 outcome」。

修法：`SubmitCommandResponse` 携带 `caly_api::Accepted` 并原样转发；`IdempotencyRecord` 记住**原始那份**
并在重放时逐字返回。断言 `each_command_kind_reports_the_impact_the_engine_classified` 与
`a_repeated_key_replays_the_original_answer_on_both_paths`（后者连 impact 一起比）。

## Z3. 远端把 `ApiError` 压成 String，再包成"可重试"（→ 已修，`§4.39`）

`send_operation` 一路 `Result<_, String>`，façade 再统一 `remote_unavailable` →
`UNAVAILABLE / Internal / retryable=true`。也就是说 `CONFLICT`（本轮的 CAS 拒绝、第七轮修的 "no such
job"）在远端读起来像"不确定，可重试"，会诱导对**被有意拒绝**的操作自动重试。

修法：`send_operation_checked` + `with_client_api` 走全部 37 处 façade 调用，daemon 的
code/category/retryable/remediation/diagnostics 原样到达；真正的调用失败（未握手、无响应帧、锁中毒）
才合成 `Unavailable`。有损的 `with_client` 只留在两个 stream 打开处，并加了一条**计数**测试，多一处即失败。

这里有一段**我自己差点写错的结论**，原样留下：改完之后门禁报 `locations shrank: 23 < baseline 32`，
我据此认定"9 处 `result_large_err` 被消掉了"，并准备按规则把基线降到 23。同一棵树**再跑一遍是 32**。
`cargo clippy` 按 crate 重放缓存里的 lint，所以那个 23 是漏计：本轮新代码既没消掉旧的一处，
也没新增一处（23 处 `result_large_err` 全在既有代码里 —— `query/*.rs`、两个 façade、`driver.rs`、
`contract.rs` 的三个既有函数）。于是基线**仍是 32**，本轮在门禁上做的是修测量：
`scripts/check.sh` 现在在同一份一次性 target 目录里跑两遍 clippy 取**最大值**，缓存只能把数字推高、
不能让它变小。教训与棘轮的初衷同源：**工具的读数也是待验证的文档**。

## Z4. `Ctx` 三个字段被丢弃或改写（→ 修三留一，`§4.40`）

| 字段 | 修前（远端） | 处置 |
|---|---|---|
| `deadline_ms` | 硬编码 `Some(30_000)` | `ctx.deadline_ms.unwrap_or(DEFAULT)` |
| `expected_revision` | 恒为 `None`；且**引擎也没人读** | 透传 + `submit_checked` 真正实现 CAS，映射 `CONFLICT/Config/不可重试` + remediation |
| `trace_id` | 被每方法字面量顶掉 | 用 `ctx.trace_id`，删掉 37 个 tag；`§6.3` 从此可断言 |
| `role` | 两侧各自 `Admin` | **未改**：`Ctx` 无处安放角色，`ADR-037`（Proposed）给了 envelope 侧 `AuthContext` 的方案 |

CAS 有个顺序决定必须写下来：**先查幂等重放、后查 CAS**。带 key 的重试必然携带第一次读到的 revision，
反过来做会让每次重试都变成冲突，幂等窗口自己成为失败来源（`a_replayed_command_is_not_blocked_by_the_cas_check`）。

## Z5. 写侧 parity 的形状（→ 已建）

`caly-app`：`run_write_parity` = 四条 case（`fresh-a/fresh-b/dedup-a/dedup-b`）× 两条路径逐条比对
+ 两条 CAS 探针 + 五条**信封**比对（`run_envelope_parity`/`parity_of`）。三条设计判断：

1. `request_id` **排除**在比对之外并注明理由：它由"谁来组帧"决定，进程内没有帧可编号 —— 比它等于比管道。
2. 数字归一化只用于必然递增的量（job id、revision），形状与文本保持原样；否则"两条路径"永远比不出东西。
3. 每条 case 额外断言**路径无关**的行为（没要 key 就必须真的跑、只有 `dedup-b` 允许复用），
   因为两条路径同时犯同一个错时，任何"比对"都是绿的。
   这一点是被自己咬出来的：第一版让两条路径共用一个 dedup key，远端 `dedup-a` 命中的是本地刚写进
   窗口的 job，`delta=0` 看起来像 parity 失败，其实是我的比较不公平（`§4.42`）。跨路径共享 key
   是 `§8.3` 要求的**行为**，于是它变成一条独立断言 `write.dedup_spans_access_paths`，而不是被消掉。

`run_parity_scenarios` 现在先跑写侧再跑读侧，`every_loopback_scenario_passes` 因此也会判定它。

## Z6. 顺手让文档的门禁管住了我自己两次

- `status_table_test_counts_match_the_tree` 先在 `caly-common/src/lib.rs` 加了 2 个测试而没加表行时报错，
  又在给 `docs.rs` 补第 13 个测试时**再次**报错。两次都是它替人记账，本轮不再手抄数字。
- 门禁自己也补了一条规则：表行里 `` `path`（单元）`` 的括号说明被当成了路径的一部分（于是 6 行"文件不存在"）。
  修成"取开头的路径字符段"，并加测试 `a_row_annotation_does_not_become_part_of_the_path`。
  ——**门禁的规则也要有反例测试**，否则它会用假阳性教会大家无视它。

## Z7. 结果

```text
$ ./scripts/check.sh
  ok    cargo check --workspace --all-targets is clean
  ok    251 tests passed
  ok    clippy locations at baseline (32)
  note  2785 formatting diff lines remain (tracked, not gating)
  all gates passed
```

五次失败注入（各跑一次后还原，实测输出见下）：
① 撤 handler 的 `Accepted` 转发 → `write.{local,remote}.impact_is_classified` 与
`a_deployment_reports_the_impact_the_engine_classified` 失败；
② 把常量 key 放回 `RemoteFacade::apply` → `every_write_case_matches_across_the_two_paths` 失败；
③ 撤掉引擎里的 CAS 检查 → `a_stale_expected_revision_is_refused_before_anything_is_queued` 与
`a_matching_revision_is_accepted_and_a_second_one_is_not` 失败；
④ 让远端 façade 重新写死 `expected_revision=None`/无 key → `a_cas_refusal_arrives_identically…` 失败；
⑤ 把 trace 换回每方法字面量 → `the_callers_trace_id_survives_both_paths`（`left: "remote-facade-call"`）。
另有两次**由门禁反向抓我**：文档计数表因为我给 `docs.rs` 加了第 13 个测试而变红；
`clippy` 读数因缓存漏计报出 23（实际 32）—— 前者我补了表行，后者我改了门禁本身（`§4.44`）。

规模：194 个 `.rs` / 42,302 行 / **251** 测试 / 64 个 test target / 20 成员 / 72 篇 Markdown。本轮 +20 测试（231 → 251）。

## Z8. 下一轮

1. `ADR-037` 采纳与否决定 `role`/`Idempotency::Required` 的最终语义；在那之前 `required_role` 仍是文档性的。
2. **`SupportBundle` 的取回**（`Y9` 第 2 项，仍未做）：字节在 CAS 里，客户端只有摘要。
3. stream 侧的写后逐条比对（现在只有 contract 的一条单边断言）+ 那两个有损 stream 调用点。
4. `deadline_ms` 的执行者（与 `ADR-036` 重叠）。
5. ADR-035 / ADR-036 / ADR-037 三份 Proposed 的确认；`caly-cli` 的 `[[bin]]` 边界。

---

# 第十轮：把导出接回客户端（`Z8` 第 2 项 + 存储层缺口）

## AA0. 切入点：上一轮留了一个"写得到、读不回"的洞

`X7 → Y9 → Z8` 三轮都记着同一件事：`SupportBundle` 的取回没做。本轮动手前先把上一轮我自己写的理由
翻出来核对 —— `docs/REDACTION_AND_SUPPORT_BUNDLE.md §4.2` 写的是"导出位置需要平台决策"。
这条**只对了一半**：需要平台决策的是"写到用户指定的路径"，而"把已经进 CAS 的字节读回给客户端"
根本不需要平台层。查 `ObjectStore` 才看清真相：

```text
put / get(元数据) / materialize(写到一个 runtime 路径) / list_objects / delete
```

**没有一条能把内容读出来。** 于是第八轮的导出是一个只有回执的写操作：摘要印在作业上，谁都拿不到东西。
我上一轮把这个缺口用一个"需要决策"的理由包装过去了 —— 记在 `§4.45`，也记在这里，因为它和
`§2.2`（文档比代码保守）是同一类错误，只不过这次是我自己写的文档。

## AA1. `read_object`：默认 `Unsupported`，读时校验锚点（→ 已补）

```rust
fn read_object(&self, digest: &str, max_bytes: u64)
    -> Result<Option<Vec<u8>>, StorageError>   // 默认：Err(Unsupported)
```

三点纪律都沿用仓库既有做法：**不支持 ≠ 空**（否则"这个后端读不了"会读成"对象不存在"，与 `§4.18`
的 GC 缺口同构）；`None` 只表示"没有这个 digest"，与 `get` 一致；返回前必须按记录锚点校验
（`RFC-0007 §6.3` 的完整性不能只管写、不管读）。`max_bytes` 是硬上限，超限报 `CapacityExceeded`
而不是悄悄给一半 —— `§6.5` 说的是"不许无界地把大对象吸进内存"。

## AA2. 把两个后端放在同一组断言下，立刻抓到两处各说各话（→ 已修）

新增 `crates/caly-storage/tests/object_contract.rs`：8 条测试，**同一组断言分别跑 `InMemoryStorage` 与
`FsStore`**。它第一天就抓到两处（都不是本轮新代码引入的，是"各测各的"漏了很久）：

| 场景 | 修前 memory | 修前 FsStore | 采纳 |
|---|---|---|---|
| `materialize` 一个 metadata-only 记录 | `Ok(())` | `Err(IntegrityViolation)` | 拒绝 |
| `put` 声明的锚点与载荷不符 | 静默用实际值覆盖 | 拒绝 | 拒绝 |

以及一处泄漏：超限读把端口的原文 `file exceeds byte cap: var/caly/objects/sha256/15/93/…` 冒泡出去
—— 内部路径进了客户端可读文本（`RFC-0010 §4.1` 把路径列为准 secret），且两后端措辞不可比对。
改成 store 层先 `stat_size` 再给统一消息（`object X is N bytes and the caller allowed M`）。

**结论值得单独记**：`storage_backend_swap.rs` 只证明了"中心线换个后端还能跑通"，
它不约束后端的**错误语义**。跨后端契约测试补的正是这一层（`§4.46/§4.47`）。

## AA3. `ReadSupportBundle`：一个必须先过类别检查的查询（→ 已建）

`DiagnosticsOp::ReadSupportBundle { request }` 是 Query（`ADR-027` 三类之一），
`request.digest: Option<String>`，`None` 语义是"store 里最新的那个"。理由很实际：点了"导出诊断"的
客户端没有理由去解析作业日志里的摘要 —— 但这条便利不能变成猜测，所以"最新"是从 store 枚举里
按 `(stored_at, digest)` 确定性取的，不是记在内存里的 last-id。

安全收窄是本轮最要紧的一条（`§4.48`）：CAS 里除了 bundle 还存着 `CompiledArtifact` 与 `RawSource`，
**那是 core 真正要跑的配置，按设计不脱敏**。"给摘要就返回内容"的查询等于开了一个 secret reader，
把 `RFC-0010 §12.2` 的脱敏导出从后门拆掉。所以 `kind` 检查发生在**碰任何字节之前**，
拒绝消息只说"它是 `CompiledArtifact`"、绝不回显内容。

另一条同样重要：`max_bytes` **只截断响应，不截断校验**。若把它直接当 store 的上限传下去，
"我只要前 120 字节"就成了绕过完整性检查的开关。

## AA4. 反向接线：harness / contract / scenario / parity 都能读回

`LoopbackHarness::read_support_bundle`、`run_loopback_remote_contract` 的
`remote.diagnostics.support_bundle.readback`、`run_support_bundle_scenario` 的
`support-bundle.readback` 与 `support-bundle.readback-missing-is-refused`，
以及 `run_write_parity` 里两条 `write.bundle_readback*`。

写这几条时踩到自己一个"假绿"：如果 daemon 侧根本没产出 bundle，两条路径都会返回**同样的拒绝**，
比对全绿而什么都没测。于是补了反-vacuity 断言 —— 先让本地路径真的产出一个 bundle，再要求
`write.bundle_readback` 的 detail 必须以 `read digest=sha256:` 开头、含 `text_sha256=`，
并要求"对象 key == 校验锚点 == 返回文本的摘要"三者相等（内容寻址必须活过一次往返）。

## AA5. 三次失败注入（各跑一次后还原）

本轮还顺手修了门禁自己的两处计量错误（`§4.44` 的 clippy 读数漏计在第九轮、
`§4.49` 的表格列数少算一列在本轮）—— 两次都是"工具冤枉别人"的形态，所以都补了针对计量函数本身的测试。

| 撤掉什么 | 变红的断言 |
|---|---|
| `read_support_bundle` 的 kind 检查 | `a_digest_that_is_not_a_bundle_is_refused_before_any_bytes_are_read` |
| `FsStore::read_object` 的锚点校验 | `tampered_content_is_refused_on_read_rather_than_handed_back` |
| 把 `max_bytes` 直接当成 store 上限 | `a_truncated_read_says_so_and_stays_a_prefix` |

三条都是"设计点"而不是"实现点"：它们红的原因是**语义**被换掉了，不是代码写错了。

## AA6. 结果

```text
$ ./scripts/check.sh
  ok    cargo check --workspace --all-targets is clean
  ok    265 tests passed
  ok    clippy locations at baseline (32)
  note  2168 formatting diff lines remain (tracked, not gating)
  all gates passed
```

规模：196 个 `.rs` / 43,826 行 / 265 测试 / 67 个 test target / 20 成员 / 72 篇 Markdown。本轮 +14 测试（251 → 265）。

## AA7. 下一轮

1. parity 里 `role` 与 `Idempotency::Required` 的语义仍待 `ADR-037`；本轮读回查询特意**不**碰 `role`
   （两条路径都硬编码 `Admin`，比它等于比一个恒真式）。
2. stream 侧写后逐条比对 + 那两个仍走有损包装的 stream 打开处（`Z8` 遗留）。
3. `deadline_ms` 的执行者（`ADR-036`）。
4. 把 bundle 写到调用方指定路径（需要平台层决策）；`caly-cli` 的 `[[bin]]` 边界。
5. ADR-035 / 036 / 037 三份 Proposed 的确认。

---

# 第十一轮：事件内容接进比对（`AA7` 第 2 项）

## AB0. 切入点：计数相同 ≠ 行为相同

上一轮给 parity 加了三条 case 比对，但比的是 `log_count` / `warning_count` / `last_stage`。
本轮先质疑这套断言的强度：两条路径各自"14 条日志、8 条告警"时，一条把 `snapshot.committed`
写成 `snapshot.commit`，比对仍然全绿。查 `JobFollowView` 与 `JobFollowProjection` 又发现更基本的一件事：
**窗口里的 `JobEvent` 一直都在，只是没有任何 façade 方法把它交给调用方**；而本地路径连流都没有
（`follow_job_stream` 只回一个 `WatchOpened{stream_id}`，进程内没有泵可开）。于是本轮做读事件内容，
顺手把 `AA7` 的另一项（那两个有损 stream 打开处）一起清掉。

## AB1. `DiagnosticsOp::ReadJobEvents`：Query，而不是"给本地也造一条流"（→ 已建）

```text
request  = JobFollowRequest { job_id, from_event_index? }      // 复用既有请求 DTO
response = JobEventsView { state, events, next_event_index,
                           retained_from_event_index, reset_required }
```

两个决定：
1. **它是 Query**（`ADR-027`：Query/Command/Stream 是仅有的三种交互）。要回答的问题是
   "这个 job 已经产生了哪些行"，那是快照读取；流是"接下来还会产生什么"。把本地也塞一条流，
   是在给一个读需求配一套订阅机制。
2. **渲染只有一处**。引擎的 `bundle::render_job_event`（原是 `pub(crate)`）改为公开并复用，
   于是 follow、stream、support bundle、这个新查询是同一份文本。三份写法必然漂移，这仓库已经
   为此付过学费（`§4.30` 的 stage 命名）。

## AB2. 有损包装从"限 2 处"变成"必须 0 处"（→ 已清）

`open_runtime_stream` / `open_job_follow_stream` 加上 typed 变体后，`remote_facade.rs` 里
`with_client` 连函数本身都不需要存在了。对应测试从"数到 2 就放行"改成断言 **0** 并点名三个路径必须用
typed 包装 —— 计数的棘轮会安静接受它自己的上限，而这里的上限本该是 0（`§4.51`）。

## AB3. reset 分支不可达，于是单元测试补在语义层（→ 已补 3 条）

`slice_job_events` 的 `reset_required` 需要"游标比窗口起点还旧"，默认窗口 128 条，而真实 apply job
约 33 行 —— **端到端测试永远碰不到它**（`ADR-019` 把 reset 列为 first-class，它却只活在代码里）。
补在 `job_follow.rs`：过旧游标→reset 且空列表、窗口内游标→从 `from+1` 续上、末尾游标→空但**不是** reset。
这三条当天就抓到一次 off-by-one（把 `from_event_index` 当包含语义），两条同时变红。

## AB4. 反-vacuity：两条新断言都不允许"两边都空"过关

`run_write_parity` 新增 `write.{case}.events`（数字归一化后逐行比）与 `write.events_same_job_identical`
（同一条 job 从两侧读，必须逐字节相同）。两处都加了"任一侧为空即失配"的判定 —— 否则
"什么都没返回"会满足任何相等性断言。这正是本轮 F2 注掉 `events` 之后能立刻变红的原因。

## AB5. 失败注入（3 次，各跑一次后还原）

| 撤掉什么 | 变红 |
|---|---|
| `from_event_index` 改成包含语义 | `a_cursor_resumes_where_it_says…`（daemon）+ 引擎 2 条单元测试 |
| façade 读到窗口却把行丢空（模拟旧的"只有计数"） | `event_content_is_compared_not_merely_counted`、`the_compared_lines_are_the_ones_the_operator_would_read`、`every_write_case_matches_across_the_two_paths` |
| （顺带）`with_client` 已不存在，计数测试改为 0 | `no_facade_path_flattens_a_daemon_error` 通过；把任一 stream 打开改回有损包装即失败 |

## AB6. 一次流程错误，记在这里（`§4.53`）

给 `job_follow` 加测试时我漏了 `JobState` 的 import，测试二进制**没编译起来**；而我用的
`grep -E 'test result|FAILED'` 对编译错误一行都不匹配，输出为空被我读成了"跑过了"。
连着几步我都以为引擎单元测试是通过的，直到 `tail` 原文才看见 `error: could not compile`。
教训：**验证命令的过滤器必须让失败可见**。本轮之后一律看原文尾部或退出码。
（这条和整个项目的母题是同一句话的两种说法："文档说做过" ≠ "做过"，"我看了输出" ≠ "输出说了那件事"。）

## AB7. 结果与规模

```text
$ ./scripts/check.sh
  ok    cargo check --workspace --all-targets is clean
  ok    274 tests passed
  ok    clippy locations at baseline (32)
  ok    clippy locations at baseline (32)
  note  2089 formatting diff lines remain (tracked, not gating)
  all gates passed
```

规模：197 个 `.rs` / 44,650 行 / **274** 测试 / 68 个 test target / 20 成员 / 72 篇 Markdown。本轮 +9 测试（265 → 274）。

本轮新增：`ReadJobEvents`（Query）+ 两条 façade 方法 + harness 方法 + contract 两条 case +
scenario 三条 + `crates/caly-daemon/tests/job_events.rs`（4 条）+ `job_follow.rs` 单元测试（3 条）+
`write_parity.rs` 2 条；移除 `with_client`（含其唯一用途的两处）。

## AB8. 下一轮

1. `role` / `Idempotency::Required` 仍等 `ADR-037`；本轮的 `ReadJobEvents` 是 `Viewer` 级查询，
   但两条路径都硬编码 `Admin`，所以 `required_role` 依旧无法被真正比对（比它等于比恒真式）。
2. `deadline_ms` 的执行者（`ADR-036`）：现在两条路径都会把它写进 envelope，`Command.timeout_ms`
   也已经带下去，仍然没有人在超时处动作。
3. bundle 写到调用方指定路径（需要平台层）。
4. 事件窗口的**分页上限**：`ReadJobEvents` 目前一次性返回整个窗口，`SCENARIO_SUITE`/`LOOPBACK_CONTRACTS`
   都没有为它定义"多少行算多"，需要定一个有界策略（与 `max_events` 保留窗口是两件事）。
5. ADR-035 / 036 / 037 确认；`caly-cli` 的 `[[bin]]` 边界。

---

# 第十二轮：把"读得到"补成"读得完"（`AB8` 第 4 项），以及一个没人判定的套件

## AC0. 切入点：上一轮自己造出来的缺口

`AB8` 第 4 条写的是"`ReadJobEvents` 目前一次性返回整个窗口"。本轮先复核这句话（前几轮每轮都推翻过
自己的记录，这次它**成立**）：

```bash
grep -n "max_lines\|max_bytes" crates/caly-api/src/dto/diagnostics.rs   # 只有 SupportBundleReadRequest 有
grep -n "render_job_events" crates/caly-daemon/src/app.rs               # 整个窗口一次渲染、一次返回
```

同时 `grep -n "retained_from_index" crates/caly-daemon/src/watch_bridge.rs` 露出第二件事：为了知道
"返回的第一行是第几行"，流侧**重算**了一遍引擎在 `slice_job_events` 里已经算过的
`max(from + 1, retained_from)`。也就是说，这一轮不是"加个 limit 参数"，而是把分页读与流读共用的那条
算术收成一个出处。

## AC1. 有界读：`JobEventsRequest`，而不是给 `JobFollowRequest` 加两个字段

`RFC-0002 §9` 把日志列入**必须**分页或流式的大集合，`§11.4` 又规定大对象 MUST NOT 以内嵌超大 IPC 帧
返回（帧上限 `caly_ipc::MAX_FRAME_SIZE_BYTES` = 4 MiB）。保留策略只约束条数（128 条），单行长度没人管，
所以"响应有界"当时只是巧合成立。

```text
JobEventsRequest { job_id, from_event_index?, max_lines?, max_bytes? }
JobEventsView    { …, byte_len, next_from_event_index? }
```

三个决定：

1. **不复用 `JobFollowRequest`**。给一个两条路径共用的请求 DTO 加 `max_lines`，follow 一侧就永远背着
   两个它从不读的字段（`§4.38` 的"字段没人读"）。分家之后，`FollowJob` 保持无界摘要、`ReadJobEvents`
   是有界内容，各自的文档才各自成立。
2. **游标语义 = 本项最后返回的索引**，字段名因此是 `next_from_event_index`（不是
   `resume_from_event_index`）：请求侧 `from_event_index` 是**排他的**（第十一轮为这条补过单元测试），
   把回复字段命名为"要填回 `from_event_index` 的值"，客户端就不必自己算 `+1 / -1` —— 命名承担了算术。
3. **不新设 `truncated` 布尔**：它就是 `next_from_event_index.is_some()`，由 `is_truncated()` 派生。
   两个"还有更多"的表述迟早互相矛盾（`§4.21` 的 lifecycle 覆盖是同族教训）。

## AC2. `first_index`：切片起点只有一个出处

`JobEventWindow` 新增 `first_index`，`slice_job_events` 两条分支都填它（reset 分支填保留起点）。消费端：

- `watch_bridge::bridge_job_follow` 的 `base` 从"重算 max"改为读字段；
- `page_job_events` 用它算 `next_from_event_index = first_index + taken - 1`。

新单元测试 `first_index_names_the_line_the_slice_actually_starts_with` 钉三件事：无游标时由保留策略决定、
游标在窗口内时由游标决定、`events[0]` 确实是那一行。**这条测试立刻抓到我自己的一个错**：我原本在里面
写"游标 0（远早于窗口）→ 由保留决定"，但那其实是 reset 分支（返回空列表），断言失败；改成"reset 也报告
`first_index` = 保留起点"才是事实。测试比作者可信，这是第 N 次。

## AC3. 谁拥有默认页与上限：daemon，不是 engine

`crates/caly-daemon/src/paging.rs`：默认 64 行 / 64 KiB，上限 512 行 / 1 MiB（`≤` 帧上限的 1/3，由
`the_caps_leave_room_for_the_frame_limit` 断言），并且：

- `max_lines: Some(0)` / `max_bytes: Some(0)` → **拒绝**：`CONFIG_INVALID`（`docs/ERRORS.md §5.1`）
  + "省略即为默认页"的 remediation。读成"用默认"会送出一整页客户端没要求过的内容；读成"返回空"则是
  一个永不前进的游标。
- 超过上限 → **收窄到上限**而不是报错：`next_from_event_index` 会告诉客户端这一页没读完，它自己就能继续。
- 单行超过字节预算 → **仍然返回该行**（引擎规则 1）：空页 + 游标不动 = 活锁。

`JobEventPagePolicy` **刻意没有 `Default`**："常用尺寸"只能有一个出处，而回答查询的是 daemon。
上限（512 行）经公共路径**观察不到** —— 保留窗口只有 128 条，任何真实 job 都填不满它，所以该 clamp 由
单元测试钉住；状态文档没有把它写成"端到端验证过"（`§4.54` 末注）。

## AC4. 顺手挖出的更大一件事：scenario 套件的一半没有判定者（`§4.55` / `§4.56`）

加 `every_scenario_suite_row_passes`（跑 `run_smoke_bundle()` 的 123 行，行数下限设 100，防止"聚三行
必过项"冒充套件）之前，被门禁信任的是 `scenario::run_loopback_scenarios` —— 五行，其中三行状态**硬编码
`true`**。第一次运行就红了三处：

| 症状 | 根因 |
|---|---|
| `bundle returned an error: no such job: 1` | `run_job_follow_contract_scenario(JobId(1))` 跟一个不存在的 job（第十轮起未知 job 是拒绝），且它两条 façade 各自起了**不同**的 daemon |
| `runtime.watch.structured-runtime-state` = `Failed` | 部署路径从不发出 runtime-state patch，而 `§10.3` 规定 Dashboard 流是 snapshot + patch |
| `job-events.zero-bound-refused` = `Failed` | `LoopbackHarness` 把 `ApiError` 折成 `summary`，scenario 层根本读不到错误码 |

三处都修了：scenario 共用一个 daemon 并自建 job；`worker.rs` 在快照提交后推 `RuntimeChanged`
（`watch_bridge` 渲染成 `StreamPayload::RuntimeState`）；harness 与 `contract.rs` 的两处报告文本统一用
`docs/ERRORS.md` 的**稳定码**（`as_str()`），并由 `write_parity.rs` 的 `refused CONFLICT ` 前缀断言钉住。
遗留的五行假绿套件连同 `ScenarioCase` / `scenario::ScenarioSuite` 一起删除 —— 同一个 crate 里两个
`ScenarioSuite` 形状、由两个测试分别判定，本身就是漂移机器。`run_job_follow_query_stream_scenario(_job_id)`
那个"收了但不读"的参数也一并去掉：调用方以为自己在选 job，实际选的是场景自造的 job。

## AC5. 反-vacuity 与可达性

- daemon `a_small_page_walks_the_window_and_the_last_page_tells_it_to_stop`：逐页**拼回**整窗，且
  `next_from_event_index` 恰等于"最后返回的索引"；`is_truncated()` 与游标存在性逐页比对。
- `a_window_smaller_than_its_own_page_is_not_reported_as_truncated`：游标在末尾必须是"空 + 不截断 +
  无游标"，否则客户端会在一个已完成的 job 上无限翻页。
- `a_request_that_ignores_the_caps_still_gets_a_bounded_reply`：`u32::MAX` / `u64::MAX` 的请求仍然
  `≤` 公布的两个上限，且 `byte_len == events.join("\n").len()`（报告的行数不能自说自话）。
- parity `write.events_paged_identical` + `walking_the_window_in_pages_agrees_across_the_two_paths`：
  两侧各自按 3 行走到结束，行数与内容都比；detail 里的行数必须 ≥ 8，两边同时返空不算通过。
- contract `…job_events.bounded` / `…job_events.walk`（走查必须等于整窗读）；场景
  `job-events.bounded-page-roundtrip` 要求 `pages > 1`（实测 11 页）。

## AC6. 失败注入（9 次，各跑一次后还原）

每次改一处 → `cargo test -p caly-engine -p caly-daemon -p caly-app --no-fail-fast` → 记下红名单 → 还原。
红名单写全名，不写"若干条失败"。

| 撤掉什么 | 变红 |
|---|---|
| `resolve` 里的 `min(MAX_…)`（不再收窄） | `paging::tests::a_page_larger_than_the_cap_is_clamped_rather_than_served` + `the_caps_leave_room_for_the_frame_limit`（改完测试之后这条注入会多红一条） |
| `Some(0)` 的拒绝分支（0 当默认） | `a_zero_bound_is_refused_and_names_the_field`、`a_bad_bound_on_an_unknown_job_still_refuses_on_the_bound` |
| 引擎"首行必须返回"的规则 | `job_follow::tests::one_line_beyond_the_byte_cap_is_still_returned_and_says_so` |
| `next_from_event_index` 永远 `None` | `a_page_hands_back_the_cursor_that_continues_it_exactly`、`one_line_beyond_the_byte_cap…`、`a_small_page_walks_the_window_and_the_last_page_tells_it_to_stop`、`walking_the_window_in_pages_agrees_across_the_two_paths`、`the_loopback_remote_contract_bundle_passes_every_case`、`every_scenario_suite_row_passes` |
| `first_index` 忽略调用方游标 | 引擎 4 条：`a_cursor_inside_the_window_resumes_and_reports_no_reset`、`a_page_hands_back_the_cursor…`、`first_index_names_the_line_the_slice_actually_starts_with`、`one_line_beyond_the_byte_cap…` |
| 部署后不推 `RuntimeChanged` | `every_scenario_suite_row_passes`（`runtime.watch.structured-runtime-state`） |
| harness 只留 `summary`（丢错误码） | `every_scenario_suite_row_passes`（`job-events.zero-bound-refused`） |
| `read_through` 退回 Debug 拼写 | `every_write_case_matches_across_the_two_paths` |
| 只在 remote façade 分页（本地不分） | `event_content_is_compared_not_merely_counted`、`every_write_case_matches_across_the_two_paths`、`walking_the_window_in_pages_agrees_across_the_two_paths`、`every_scenario_suite_row_passes` |

另外记一次"抓不住"的注入：把 `contract.rs::describe` 退回 Debug 拼写，**没有任何测试变红** —— 它只在
`run_write_parity` 出错时才被调用，绿色运行下那段输出根本不存在，所以稳定码在那条路径上没有断言可依。
我没有为它编一条测试，也没有把 `read_through` 的成果算到它头上；这一条写在这里，免得下一轮当成"已验证"。

第一次做"只在 remote 分页"时我用的是 `cargo test --test write_parity --test contract_gate`（没有
`--no-fail-fast`），只看见 `contract_gate` 的红，几乎得出"分页差异没人管"的错误结论 —— `cargo test` 是
fail-fast 的，`write_parity` 根本没跑。与 `§4.53` 同一课：**验证用的管道必须让失败可见**（`§4.57`）。

## AC6bis. 本轮自己造的两条 lint（修代码，不动基线）

写 `paging.rs` 时我把常量之间的关系写成了运行时断言：

```text
warning: this assertion has a constant value (×2)
   --> crates/caly-daemon/src/paging.rs:145  assert!(DEFAULT_JOB_EVENT_PAGE_BYTES <= MAX_JOB_EVENT_PAGE_BYTES)
   --> crates/caly-daemon/src/paging.rs:146  assert!(DEFAULT_JOB_EVENT_PAGE_LINES <= MAX_JOB_EVENT_PAGE_LINES)
```

门禁立刻从 `32` 涨到 `34`。按规矩**改代码而不是抬基线**：这两条关系是编译期事实，于是搬进
`const _: () = assert!(..)` —— 违反它现在是**构建失败**，比一条永真的测试强；测试
`the_caps_leave_room_for_the_frame_limit` 则改为断言**经 `resolve` 之后**的值（那才是"客户端要很多，
仍然只拿到上限"这件事），基线回到 32。这与本轮删掉三行硬编码 `true` 的 scenario（`§4.56`）是同一条
判据的两面：能恒真的断言不是断言。

## AC7. 结果与规模

```text
$ ./scripts/check.sh
  ok    cargo check --workspace --all-targets is clean
  ok    290 tests passed
  ok    clippy locations at baseline (32)
  note  1847 formatting diff lines remain (tracked, not gating)
  all gates passed
```

规模：198 个 `.rs` / 45,860 行 Rust / **290** 个行首 `#[test]`（38 个文件）/ 68 个 test target /
20 个成员 / 72 篇 Markdown。本轮 +16 测试（274 → 290）：引擎 `job_follow` +5 条（3 → 8）、
`caly-daemon/src/paging.rs` 5 条（新文件）、`crates/caly-daemon/tests/job_events.rs` 4 → 9、
`write_parity.rs` 9 → 10、`contract_gate.rs` 6 → 6（一加一删：新增整束判定者，删掉判定假绿套件的那条）。
格式化欠账 2,089 → **1,847** 行（口径是 `cargo fmt --all -- --check` 的输出行数，与门禁一致；本轮触碰的
文件恰好是欠账最集中的几个，仍然只格式化触碰文件、不动全库）。

## AC8. 下一轮

1. `role` / `Idempotency::Required` 仍等 `ADR-037`：`ReadJobEvents` 是 `Viewer` 级查询，但两条路径都
   硬编码 `Admin`，`required_role` 依旧无法被真正比对（比它等于比恒真式）。
2. `deadline_ms` 的执行者（`ADR-036`）。
3. 流侧**逐帧**内容比对：`runtime.watch` 现在多了一帧 runtime-state（场景行断言它的存在），但
   `contract.rs` 对 `pull_stream` 帧仍只检查"非空 + 行数"；把逐帧 payload 对齐，能同时补掉
   `runtime.watch` 剩下的那点不对称。
4. `caly-cli` 的 `[[bin]]` 边界 → `doctor` / `--json` / 退出码映射可以吃现在这套 typed `ApiError.code`
   （`driver.rs` 仍把错误折成字符串）。
5. ADR-035 / 036 / 037 三份 Proposed 的确认；`Fs::list` / `Meta.mtime` 缺口（`ADR-035`）不变。

---

# 第十三轮：中心线的拒绝出口 —— 过载不再伪装成进展

## AD0. 切入点：`SCENARIO_SUITE §5` 剩下的那条"未覆盖"

上一轮核对场景清单时写下一句：「**未覆盖**：queue full / overload —— `caly-engine::overload` 与
`caly-daemon::error_map` 有实现，但 `grep -rn "overload" crates/*/tests/*.rs` 一条断言都没有」。
本轮从这条开始，先复核它是否仍然成立（成立）以及"有实现"到底是真的还是叙述（一半真）：

```bash
grep -rn "queue_full\|OverloadReport" crates --include='*.rs' | grep -v "overload.rs\|error_map.rs"
#  processor.rs:46  OverloadReport::queue_full(max_len)            ← 生产者，确实在
#  service.rs:350   submit_command(...) 的拒绝分支                  ← 确实接到 submit_checked
#  app.rs:204       SubmitFailure::Overload(report) => map_overload_report(...)
grep -rn "to_api_error" crates --include='*.rs'
#  crates/caly-engine/src/overload.rs:37 定义                        ← 唯一一处：没有调用者
```

也就是说：链路上有人产出、有人映射，但**信息在映射处被丢掉**，而且**没有任何断言**。两条一起处理。

## AD1. 第一个真缺陷：被拒的命令推进了 revision

`submit_command` 的顺序是「分配 job id → `bump_generation()` → `enqueue`（在里面才发现满了）」。
`generation` 不是内部记账：它是 `expected_revision` 比对的基准（`RFC-0002 §6.2`），也是 daemon 对外发布的
`state_revision`。后果是**跨客户端**的：A 的请求因为引擎忙被拒，B 手里的 revision（在拒绝发生之前读的）
从此变成 `CONFLICT`——一个什么都没改的操作改坏了别人的前置条件。附带一条：job id 也被消耗，
两条本应同构的 daemon 的 id 序列会分叉。

`OVERLOAD_AND_RETRY_MODEL §3.1` 写的"不产生 apply side effect"因此是可判定的命题，不是风格要求。
处置：把容量判断提到任何改写之前（`CommandQueue::has_capacity()`），拒绝走独立的
`rejected_for_full_queue`；`enqueue` 的 `RejectedFull` 分支留着，但明确写成"同一 `&mut` 借用下不可能到达，
到达即内部错误"——既不 panic 也不静默重试。

差分测试比"看一个计数器"更硬：两台 daemon 同样灌满，A 拒两次、B 不拒，然后各 drain 一条再提交，
**接受的 `state_revision` 与 `job_id` 必须逐项相等**（`refusals_are_invisible_in_the_revision_history_of_the_work_that_did_run`）。

## AD2. 第二个真缺陷：两个映射器，线上那个是丢信息的

daemon 的 `map_overload_report` 自己重建 `ApiError`，只留 code / category / retryable / summary；
`OverloadReport::to_api_error` 带 `remediation` 却无人调用。文档 `§8` 明令禁止"只返回一条 `Unavailable`，
不给任何细分线索"（原文拼写如此），`§9` 还给了期望形状。合成一个：

```text
detail = "error=queue_full retry_hint=RetryLater queue_len=256 queue_cap=256 at_generation=256"
diagnostics[] = { code: "queue_full", message: <summary> }
category = StorageBusy -> Io, 其余 -> Internal
remediation = RetryHint::remediation()          ← 文案与 hint 放在一起，daemon 不再抄一份
```

`RetryHint::as_str()` 用稳定的大写拼写（`RetryLater`），因为它现在会出现在客户端可读文本里；
`category`/`code` 的口径与 `docs/ERRORS.md §5.8` 一致。

## AD3. 第三个缺口：拒绝只活在那一次响应里

`§7.2` 要求同一次过载有两个出口：给调用者的 `ApiError`，和给诊断的记录（backlog 长度、queue cap、
发生位置）。后者原先完全没有——被拒的命令没有 job，所以不在 `runtime-log` 里；事件日志又被 cap 滚掉。

处置：`EngineState.overloads`（有界 8 条）+ `overload_totals`（**完整计数**）。两者是分开的，因为
"最近 8 条"不等于"发生过 8 次"：`overload_lines()` 输出
`overload queue_full: 10 occurrence(s), 8 of them retained — … (hint RetryLater, generation 256)`，
`doctor` 的 warning 与 bundle 的新 `overload` 段共用这一个函数（两个出口、一份文本，杜绝各写一份）。
空日志写一句"没有记录"，不省略段——`BUNDLE_SECTIONS` 因此从 10 段变 11 段（三处文档里的段数同步改了）。

## AD4. 反-vacuity

- 灌队列的 `fill_queue` 断言"接受数恰等于容量"且 `queue_stats() == (256, 256)`：否则"满了"是编的。
- 场景 `overload.refused-on-both-paths-identically` 比的是完整身份串（含 `detail`）；`detail` 里有
  `at_generation`，所以"两侧相同"同时反证了"拒绝没推进 revision"。
- doctor 断言**恰好一行**按类别汇总，且次数精确：daemon 侧灌满后再拒 3 次必须是 `3 occurrence(s)`，
  场景侧本地+远端各一次必须是 `2 occurrence(s)`，并且过滤计数 `== 1` —— 挡住"每次拒绝印一行"与
  "整段没有"两种糊法；同时断言这行落在 `warnings` 而不是 `errors`（引擎成功保护自己，不该被报成故障）。
- 引擎那条十次拒绝的单元测试断言 `10 occurrence(s)` 且带 `8 of them retained`：有界窗口不能冒充总数。
  `doctor` 与 bundle 共用 `EngineState::overload_lines()` 这一个函数（所以两处不可能各写一份文案），
  bundle 侧由 `refusals_are_reported_in_the_bundle…` 复核同一形状。
- 空日志场景：拒绝发生**之前**取一次 doctor，断言没有 overload 行。

## AD5. 失败注入（6 次，每次一个文件，还原后复跑确认全绿）

| 撤掉什么 | 变红 |
|---|---|
| 把容量判断挪回 `next_job_id()` / `bump_generation()` 之后 | `processor::tests::a_refusal_for_a_full_queue_advances_nothing…`、`a_refusal_does_not_turn_a_valid_cas_expectation_into_a_conflict`、`refusals_are_invisible_in_the_revision_history…` |
| daemon 恢复自建薄错误 | `a_full_queue_is_refused_with_a_class_a_hint_and_a_retry_not_a_bare_unavailable` |
| 拒绝不记账 | `ten_refusals_are_ten_occurrences…`、`doctor_reports_the_pressure…`、`refusals_are_reported_in_the_bundle…` |
| 计数取自有界窗口 | `ten_refusals_are_ten_occurrences…`、`refusals_are_reported_in_the_bundle…` |
| 容量判断差一（`len <= cap`） | 7 条：daemon 4（含差分对照那条）+ 引擎 2 + bundle 1 |
| bundle 不写空日志那句 | `refusals_are_reported_in_the_bundle…` |

第一轮批量注入时我的脚本自己错了：同一文件的多处编辑把"文件名→原文"的快照覆盖成半改状态，于是还原没还回去，
后三个 mutation 跑在同一棵坏树上、红名单一模一样。发现它是因为我照例看了原始输出尾部，那里有一条
`warning: function rejected_for_full_queue is never used`——在修好的代码里不可能出现。脚本随后改成
"一次一个 mutation、一个 mutation 只碰一个文件、还原后再跑一遍确认全绿"。留档 `§4.60`。

## AD6. 两处我自己的写法错误（都被工具抓住）

1. clippy 涨到 34：`assert!(state.jobs.get(&2).is_none())` → `unnecessary_get_then_check`；
   以及 `doc_lazy_continuation` —— 后者指向一个**真**错误：我用「在 `pub async fn` 之前插入」的锚点
   插新场景函数，结果插进了上一个函数**文档注释与它的条目之间**，把别人的文档切断了。改代码 +
   把文档块移回它的条目旁边，基线回到 32。锚点不能只认签名行。
2. 一次 `cargo test --test A --test B` 忘了 `--no-fail-fast`，红名单只出现一半；与 `§4.53`、`§4.57`
   同一课。本轮之后注入脚本固定带 `--no-fail-fast` 并检查还原后的全绿。

## AD7. 结果与规模

```text
$ ./scripts/check.sh
  ok    cargo check --workspace --all-targets is clean
  ok    298 tests passed
  ok    clippy locations at baseline (32)
  note  1847 formatting diff lines remain (tracked, not gating)
  all gates passed
```

规模：199 个 `.rs` / 46,802 行 Rust / **298** 个行首 `#[test]`（40 个文件）/ 69 个 test target /
20 个成员 / 72 篇 Markdown。本轮 +8 测试（290 → 298）：引擎 `processor.rs` 单元测试 3 条、
`crates/caly-daemon/tests/overload.rs` 4 条（新文件）、`support_bundle.rs` 8 → 9；scenario 束从 123 行
增到 128 行（新增 `overload.*` 5 行，仍由 `every_scenario_suite_row_passes` 逐行判定）。
格式化欠账 1,847 行不变（本轮触碰的文件在上一轮已经整过）。

## AD8. 下一轮

1. `EventBacklog` / `StreamBackpressure` / `StorageBusy` 仍**没有生产者**：分类与映射都在，触发点不在。
   `StorageBusy` 需要 cutover 期的 storage 争用模型（`§6.2` 要求它升级为 recovery-sensitive 路径，
   不能只提示"稍后再试"）；另两类需要流侧的合并/丢帧策略。刻意不造触发点。
2. `role` / `Idempotency::Required`（`ADR-037`）与 `deadline_ms`（`ADR-036`）仍等决策。
3. 流侧逐帧 payload 跨路径比对（`pull_stream` 的帧现在只检查非空与行数）。
4. `caly-cli` 的 `[[bin]]` 边界：`§9` 要求 CLI 能表达"是不是过载 / 怎么重试"，数据现在已经在
   `ApiError.detail` 与 `diagnostics[]` 里，缺的是那个二进制。
5. ADR-035（`Fs::list` / `Meta.mtime`）不变。

---

# 第十四轮：三份 Proposed 定稿，`ADR-037` 一次落到底

## AE0. 这一轮的输入不是"再挑一件事"，而是"这三件你替我定"

上一轮 `AD8` 把三份 ADR 列为阻塞项（`role` / `deadline` / `Fs::list`）。本轮指令是「353637 你自行决策，
继续」：决策权下放。开工前把每份 ADR 的**事实断言**重新核一遍 —— 包括我自己写的那些：

```bash
grep -rn "Idempotency::Required" crates --include='*.rs' | grep -v test   # 仍是 0 处生产读取
grep -rn "io_budget" crates --include='*.rs'                              # 只有两处赋值，无人读
grep -n "io_budget" crates/caly-api/src/envelope.rs                       # ADR-036 说的透传链不存在
```

第三条是本轮第一个发现：**`ADR-036` 对现状的描述是错的**。它写"从 `RequestEnvelope.io_budget` 透传"，
而 envelope 没有这个字段（字段只有 protocol / request_id / trace_id / deadline_ms / expected_revision /
idempotency_key / role / operation）。`Ctx.io_budget` 到不了 daemon，`request_map` 只能自己写死
`unlimited()`。一份"等人裁决"的 ADR 里连现状都要复核，何况是我自己写的。

## AE1. 三份的定稿

| ADR | 决定 | 落地 |
|---|---|---|
| 037 | §2 四条照原文采纳，但记下**三处偏离**：不引入 `AuthContext`（`role` 已在 envelope 上，并存就是两个真相）；角色落点从 `LocalFacade::with_role` 改到组装根（本地 façade 是 11 个 facet 各自重建 envelope，逐个传参只会各写各的默认值）；窗口只按条数限界，不按注入时钟（引擎在 036 落地前没有时钟，接一个就破坏 `ADR-022` 的确定性复现） | **本轮落地** |
| 035 | 照原文采纳，但**否掉**它自己的过渡期设计（"`list` 返回 `Unsupported` 就回退读清单"等于把要消灭的第二真相永久留在代码里）；分三步，删清单层与改取时来源各算一步 | 未开始 |
| 036 | 采纳，并回答它唯一留白的技术点：**时钟由端口注入，不给 `caly-io` 开 clippy 豁免**；同时改掉两处与代码不符的说法，并在四步之前插一步"先有可挂起的被测对象" | 未开始 |

`Status` 三行、`docs/adrs/README.md`、`RFC_ADR_CRATE_INDEX` 的段落同步，并且明写"已定稿 ≠ 已实现"，
否则下一轮读者会以为 `Fs::list` 已经存在。

## AE2. `ADR-037` 落地清单

1. **角色**：`DaemonRuntimeState::local_role` 默认 `Operator`；`ClientSessionConfig::default().role` 也从
   `Admin` 降下来（两条路径必须同一个默认值，否则"共享权限语义"又是空话）。`required_role` 从此真会拒绝。
2. **`Required` 缺 key → 拒绝**（`CONFIG_INVALID` + remediation）。同时**空白 key 对任何命令都拒**：
   `Some("")` / `Some("   ")` 是一个共享桶，和第九轮那个"每类操作一个常量 key"同形，只是穿了合法值的衣服。
3. **`RequestMapError` 带 `kind`**：`app.rs` 以前把 `request_map` 的一切失败都报成 `PERMISSION`（当时只有
   角色检查会失败，所以无害）。kind 与第二个拒绝理由是**同一次**改动加上的 —— "只有一种情况"的隐含假设
   要在破口出现之前就显式化。
4. **去重窗口**：只淘汰已完成条目（按 job id 从旧到新），运行中的永不淘汰；`evictions` /
   `finished_window` 由同一个 accessor 供 `doctor` note 与 bundle 的 `architecture` 段使用；上限 512 大于
   队列上限 256，并由 `the_window_is_never_the_reason_a_submission_fails` 钉住（窗口不能成为第二个拒理由）。
5. **本地 `request_id`**：façade 原来恒为 `RequestId(0)`，而 `Command.id = req-<request_id>` ⇒ 所有本地命令
   同名，"这条事件属于哪个命令"无法回答（`§4.61`）。改为运行时状态上的单调分配。
6. **三道门禁的顺序**（角色 → 请求形状 → 状态）各有一断言钉住：调用者只能处理自己控制得了的那件事。

## AE3. 我的"宽松版"被 parity 门禁当场否掉（`§4.62`）

我不愿把"没带 key 的高危写"变成非法输入，先实现成：缺 key 时派生 `req:<request_id>`。跑全量，
`run_write_parity` 立刻红：

```text
Mismatch write.fresh-a :: local=(… revision_delta: 2 …) remote=(… revision_delta: 0 …)
Mismatch write.local.cas_current :: … advanced=false
```

机制：request id 是**每条访问路径各自计数**的（本地一个计数器、session 一个，都从 1 起），去重窗口按
`(actor, key)` 是**全局**的 ⇒ 本地与远端的 `fresh-a` 都派生出 `req:1`，远端那次静默复用了本地的 job。
派生 key 的两种形状都不成立：跨路径碰撞（不安全），或每次唯一（等价于没有 key，`Required` 退回装饰）。
所以"拒绝"不是保守选择，是唯一自洽的读法。这段写进 `ADR-037 §2bis`，因为过程比结论有用。

## AE4. 一次注入跑出一个活锁（`§4.64`）

为验证"运行中的记录不能被淘汰"，我把受害者过滤放宽到包含运行中的记录。预期两条红，实际**套件挂死**：
循环的退出条件 `over == 0` 只数已完成条数，而放宽后的受害者集合删一条并不会让 `over` 变小。代码今天是对的
（两个集合由同一个过滤定义），但没有任何东西守着这层一致性。

处置分两块：淘汰循环改为按条目数限界（坏情况从挂死降级为 `len()` 断言失配）；顺手删掉 `put_running` 里的
第二次 `evict` 调用 —— 插入的新记录必是 `Running`，永远不可能让"已完成超限"成立，那是一句不会执行的规则，
留着只会让人日后只改一处。补两条测试把这两点变成断言：
`the_oldest_record_being_running_does_not_make_it_the_victim`（故意让最旧那条是运行中的，否则两种实现
在任何 fixture 里都分不开——我第一版就是这么漏的）与 `a_window_of_only_running_records_never_evicts`。

同一轮里我自己的工具也出了事：第一版注入脚本被超时打断，`restore` 没跑，坏改动留在树里，症状是"一个我没碰
过的断言变红 + 一条测试挂死"。注入装置从此三条：一次只改一个文件、`try/finally` 还原、启动时先扫遗留备份。
**能被中断的验证工具等于没有验证** —— 这条教训第四次出现（`§4.53` / `§4.57` / `§4.60` / `§4.64`）。

## AE5. 反-vacuity 与被改写的旧断言

- keyless 拒绝的测试都额外断言"什么都没发生"：无 job、`state_revision` 仍为 0、没有部署 —— 否则"拒绝"可能
  只是报错前已经做完了一半。
- 角色与 key 的拒绝在两条路径上**逐字节**比对（`the_same_role_refusal_comes_back_over_both_access_paths`
  与 `a_keyless_required_write_is_refused_identically_on_both_paths`）；本轮之前这两句话没有可比较的对象。
- 语义一变，旧断言就必须改写而不是悄悄删：`an_unkeyed_write_always_runs` → `a_keyed_write_always_runs`
  （"带不同 key 的写各自都跑"），并新增 keyless 被拒的断言；`write_parity` 的四个 case 从此统一
  **按路径命名空间**发 key（共享命名空间会让远端 `fresh-a` 复用本地那次）。
- `scripts/regenerate_test_census.py` 进仓库（`--check` 只报不改）。上一轮那些"我实测过"的规模数字是用
  `/tmp` 里的一次性脚本算的，本轮开头 `/tmp` 与工具链一起消失（快照不保存 `~/.rustup`），先重装 rustup 才跑
  得起来 —— 计数刷新这种机械步骤只要靠手抄就一定会漂，`§4.36` 的病根在此。

## AE5b. 顺手把自己的门禁修了一遍（`§4.65`）

改 ADR 的时候门禁连续给出两次**错判**（`no test results parsed` / `clippy did not run`，而 cargo 退出码
都是 0），顺着去看 `scripts/check.sh`，发现两处自己的问题：

- 注释说 clippy 在一次性空目录里跑，代码里测试段 `unset CARGO_TARGET_DIR` 之后就没人设回去 ——
  第十轮那个"跑两遍取最大值"是在给一个本不该存在的现象打补丁；
- 三段判定都是 `out="$(cargo … 2>&1)"` 之后 `printf '%s\n' "$out" | grep -q PAT` —— 脚本开着
  `set -o pipefail`，`grep -q` 命中即退出、`printf` 被 `SIGPIPE` 打死、141 被 `pipefail` 提成管道状态，
  于是 `if !` 把一次**成功**的运行读成失败。这就是那两次误判的成因（日志 737 行、70 条 `test result:`、
  cargo 退出码 0，三件事同时成立只有这一种解释）。修法不是 `|| true` 糊过去，而是判定一律 `grep -q PAT 文件`，
  摘录用的管道才允许失败。

现在：每步显式指定 target dir（clippy 第二遍复用第一遍的目录 —— 要的是冷/热对照，不是再付一次全量编译）、
输出写文件、记录退出码、解析不到就重试一次并说出来、日志留在 `target/gate-logs/`（放临时目录里会被
`trap` 删掉，"请看日志"就成了空话）、判定只 `grep -q 文件`。改完连跑 5 次结果完全一致
（313 / 32 / 1,774），冷/热两遍的读数也各存了盘（`target/gate-logs/loc1.txt` 32 行、`loc2.txt` 32 行）：口径变严之后
基线没有"涨"，说明之前那个数字是真的，只是当时无法证明它每次都是真的。

并且**拿门禁自己做了次注入**：把 `local_role` 默认改成 `Viewer`，门禁必须红 —— 红了，
并点名 `every_scenario_suite_row_passes`；改回即绿。会变的门禁比没有门禁更糟，这一条与
`§4.23`（判定者缺席）是同一枚硬币的另一面：判定者自己也要被判定。

## AE6. 结果与规模

```text
$ ./scripts/check.sh
  ok    cargo check --workspace --all-targets is clean
  ok    313 tests passed
  ok    clippy locations at baseline (32)
  note  1774 formatting diff lines remain (tracked, not gating)
  all gates passed
```

规模：200 个 `.rs` / 47,647 行 Rust / **313** 个行首 `#[test]`（42 个文件）/ 70 个 test target /
20 个成员 / 72 篇 Markdown。本轮 +15 测试（298 → 313）：引擎 `idempotency.rs` 7 条、
`crates/caly-daemon/tests/idempotency_and_roles.rs` 7 条、`error_identity.rs` +1 条。
clippy 本轮一度 33（我新加的 `local_request` 返回 `ApiResult<RequestEnvelope>`，多一处
`result_large_err`）—— 把两次可失败读取并回 `dispatch` 后回到 32，基线没动。格式化欠账 1,847 → 1,774 行。

## AE7. 下一轮

1. `ADR-035` 第 1 步：`Fs::list` + `ListCap` + `Meta.modified_at_unix_ms`，两个后端同时实现，契约套件加三条
   （有序 / `ListCap` 生效 / "空目录"与"不存在"可区分）。只加能力，删清单层留给第 2 步。
2. `ADR-036` 第 0 步：先给 `RequestEnvelope` 加 `io_budget`（现在连字段都没有）+ 一个故意挂起的端口，让
   `Timeout` / `Cancelled` 第一次在契约测试里可达，再谈执行器本体。
3. 三类过载（`EventBacklog` / `StreamBackpressure` / `StorageBusy`）仍无生产者；流侧逐帧 payload 跨路径比对。
4. `caly-cli` 的 `[[bin]]`：`ADR-037` 需要的 `--as-role` 与"权限不足"的退出码、以及 `driver.rs` 仍把错误折成
   字符串那处，都要等它。

---

# 第十五轮：把端口能力补上 —— `Fs::list`、mtime，以及"删了测试没人发现"

## AF0. 选这一件的判据

上一轮三份 ADR 定稿后，唯一"已 Accepted 且可以马上动手"的是 `ADR-035` 的第 1 步。选它还有一个理由：
它是三份里唯一**只加不改**的改动（加端口能力，不动语义、不动存储布局、不动数据），
所以每一步都可回退，而且它把 `caly-storage` 那两处"靠自己兜住"的补丁（清单索引、注入时间）
从"必须存在"变成"可以拆掉"。

## AF1. 端口的形状

```text
Meta { len, is_file, is_dir, modified_at_unix_ms: Option<i64> }
Fs::list(&VPath, ListCap, &IoContext) -> BoxFuture<Result<Vec<VPath>, IoFault>>
```

四条语义（`RFC-0006 §8.4`，本轮写进 RFC）：有序 / 可预算 / 只一层 / 空与不存在可区分。
其中两条是落地时才发现必须写死的：

- **"恰好等于上限必须成功"**。写成 `len >= cap` 的两个后端都会让每一次"给我全部"的调用在满目录上
  失败，而这种 off-by-one 只有把 cap 边界写成断言才看得见；
- **对文件调用 `list` 是 `InvalidInput`，不是 `NotFound`**。两个后端各自的"直觉实现"在这里正好分岔
  （真盘拿到 `ENOTDIR`，仿真盘拿到"我没这个目录"），而 `NotFound` 会让调用方以为整棵子树可以放弃。
  这条只有共享契约能抓住 —— 也正好说明为什么这套测试必须只有一份。

`Option<i64>` 的 mtime 是刻意的：仿真世界可以诚实地回答"我不知道"。所以本轮加了一条
`a_world_without_a_clock_reports_no_mtime_at_all`，以及一条把"时钟只在写入时读"钉住的
`sim_mtime_comes_from_the_virtual_clock_and_is_stamped_per_write`（推进 5 秒后老文件的 mtime 必须
**不变**，新写入的必须是 6000）。共享契约本身反而不能要求 `Some`：它得容许一个没时钟的后端。

## AF2. 仿真端被迫多出来的那个集合

`MemFs` 原来是纯扁平文件表，于是"空目录"和"不存在的目录"在模型里不可区分。`ADR-035` 的语义要求逼出
一个 `dirs: BTreeSet<String>`，由 `write_atomic` / `rename` / `link_or_copy` / 锁获取登记祖先路径 ——
和 `StdFs::ensure_parent` 是同一件事的两面（在这里，目录只能因为一次写入而存在）。
`Stat` 对目录返回 `is_dir: true, len: 0`，并在文档里写明"目录的 `len` 无语义、不得跨后端比较"。

## AF3. 我没按 ADR 的过渡期写，而且它自己也写重了一条

- ADR 的 §5 原本要"若 `list` 返回 `Unsupported` 就回退读清单"。定稿时已否掉，本轮再确认一次理由：
  两个后端都由本仓库实现，`Unsupported` 分支永远不会走到，而"保留一条读清单的路"就是把要消灭的
  第二真相留在代码里。
- ADR 说本改动"修改了 `RFC-0006` 冻结过的端口形状"。复核 §16，原文是"本文暂不冻结具体 trait 代码签名"
  —— 冻结的是能力边界与语义，`§8.1` 还是"至少应支持"的写法。也就是说这个改动从来不需要等 RFC 放行，
  它需要的是 ADR（决定"加什么、语义是什么"）。这句澄清已写回 `§16`，因为它决定的其实是"以后同类改动走哪条路"。

## AF4. 本轮最该留档的一条：我删掉了 4 个测试，没有一个判定者响（`§4.66`）

插入新测试时我用了按索引切片的写法（`s[:start] + new + s[end:]`，而 `start`/`end` 是从别的字符串算出来的），
结果 `caly-io-std/tests/contract.rs` 里 4 个既有测试整段消失。之后：`cargo test` 全绿、clippy 全绿、
`§3.3` 实测表也全绿 —— 因为那张表是从树里**重算**出来的，它如实报告了"少 4 个"。

所有判定者都只会检查"文档与树一致"，没有一个检查"测试数没有下降"。

处置：`scripts/check.sh` 加 `TEST_FLOOR=321`（低于下限即红，注释里写明"下调必须同批给理由"），
并用"把下限临时抬到 400 → 门禁红、改回 → 全绿"验证这条守卫真的会响。
四个测试按终端里回读过的原文恢复（不是凭记忆重写）。教训：**生成式的表只保证"与树一致"，不保证
"树没变差"**；一切数量型断言都要配下限或上限，否则它只是快照。

顺带两条同族的小账：clippy 这轮从 32 涨到 37（`unused_variable` / 3 处 `doc_overindented_list_items` /
`needless_borrow`），全在我自己新写的代码里，逐条改代码回到 32；`Meta` 新增字段后 `caly-storage` 的
`stat` 调用点全部要复核一遍有没有把 `len` 当大小用（结果：没有，目录的 `len` 无人读，已在文档里写明）。

## AF5. 还没做的事（本轮刻意不做）

1. **第 2 步：删掉 `manifest/*.idx`**，把 `list_objects` / 各类 pending 枚举改成 `list` + 逐条解码。
   这一步会改变 `open()` 的校验语义（从"清单必须与实体一致"变成"实体必须自洽"），要独立回归。
2. **第 3 步：GC 的 grace period 改用 `Meta.modified_at_unix_ms`**，注入值退为兜底。
3. 因此 `list` / mtime 今天是**有契约、有测试、无生产调用者**。这句已经写进
   `docs/IMPLEMENTATION_STATUS.md` 的未覆盖清单；如果第 2、3 步长期不落地，正确做法是撤掉字段，
   而不是让它挂着"看起来做了"的样子。

## AF6. 结果与规模

```text
$ ./scripts/check.sh
  ok    cargo check --workspace --all-targets is clean
  ok    321 tests passed (floor 321)
  ok    clippy locations at baseline (32)
  note  1774 formatting diff lines remain (tracked, not gating)
  all gates passed
```

规模：200 个 `.rs` / 48,361 行 Rust / **321** 个行首 `#[test]`（42 个文件）/ 70 个 test target /
20 个成员 / 72 篇 Markdown。本轮 +8 测试（313 → 321）：仿真侧 +5（列举契约、mtime 契约、无时钟诚实
`None`、时钟只在写时盖章、目录只由写入产生）、真盘侧 +3（列举契约、mtime 契约 + 已知、对文件列举）。


---

# 第十六轮（2026-08-28）：`ADR-035` 第 2 步 —— 删掉 `caly-storage` 的清单层

## AG0. 本轮选什么、为什么

第十五轮结束时，`Fs::list` 与 `Meta.modified_at_unix_ms` 是「有契约、有测试、**无生产调用者**」，
而 `IMPLEMENTATION_STATUS` 的未覆盖清单明确写着：第 2、3 步不落地就必须把字段撤掉。也就是说
下一轮的候选只有一个 —— 不是"还能做什么"，而是"哪一条欠账到期限了"。本轮做第 2 步（删清单层）。
第 3 步（grace period 取 mtime）留下一轮，理由与第十五轮相同：一步一提交，各自可独立回退。

## AG1. 删掉的东西，和它换来的东西

- `manifest/<kind>.idx` 的读写、`load_manifest` / `save_manifest` / `manifest_add` 全部删除；
  `put_snapshot` / `put_apply_journal` 从 2 次写变成 1 次（少一次 D3 写，也就少一个"清单与实体不一致"
  的时间窗）。文件总数由 `the_store_writes_no_index_of_anything_it_wrote` 钉住 = 6。
- 集合枚举改走 `Fs::list`，端口根 ↔ store 根的换算只在 `fs_store::list_directory` 一处发生
  （`ADR-035 §2.5` 冻结的路径基准，从此是一段代码而不是若干处字符串拼接）。
- 预算换轨：`MAX_RECORD_BYTES`（清单文件的字节上限，隐式限制集合大小）→
  `MAX_ENTRIES_PER_DIRECTORY = 4096`（显式条目上限，超限是 `CapacityExceeded` 而不是短列表）。
- `open()` 的语义从"清单必须与实体一致"变成"实体必须自洽"：**新增**能发现目录里出现布局解释不了的
  文件（`unexpected file in records/snapshot: README.txt` → 拒启）；**放弃**"某记录被带外删除"的检测
  （没有第二份名单可以说这里本该有一个）。LKG 指针与内容锚点的校验保留，所以"损坏"仍抓得住。

## AG2. 落地时才看清的三件事

1. **崩溃残留必须先回收。** `StdFs::write_atomic` 会留下 `<target>.tmp-<n>`；清单看不见它，`list` 看得见。
   若把它当损坏拒启，一次崩溃就能让 store 永远起不来；若只忽略不删，它会占住枚举预算，攒够 4096 个
   之后 `open` 因为"目录太大"而失败在一个并非记录的数字上。所以 `reap_residue` 是 `ListCap` 成立的
   前提，不是锦上添花。
2. **回退点必须改抄记录。** `create_rollback_point` 原来抄的是 5 个清单文件；清单被删掉之后回退点会
   退化成"只有一个 schema 标记"。现在它枚举 `meta/objects` 与四个记录目录逐个 `link_or_copy`，
   仍不抄对象内容（不可变、内容寻址）。这属于 `ADR-035 §4 Follow-up` 里"保留/迁移 `backups/` 语义"的
   迁移分支，落地前没人在文档里想过它。
3. **`has_any` 顺便变强了。** "这个未版本化的目录到底是不是空的"原先只能探测五个已知清单名，
   一个只含记录文件的目录会被当成空的然后被初始化掉。改为真列举，并且**列举失败按"有数据"处理**：
   猜"是空的"正是丢数据的那条路。

## AG3. 把缓存从枚举上摘下来（本轮第二个语义变化）

`list_pending_apply` / `list_unresolved_apply` / `list_snapshots` 的兜底分支原先读进程内缓存，而
`list_apply_journals` 读盘 —— 一个 store、两个答案，而**拒绝启动**用的是那个可能变陈旧的答案。现在
四类查询共用同一次枚举。缓存只留给 `get_*` 与删除时的共享内容判定（后者保留缓存是性能决定：GC 每删
一条都要问"还有谁引用这块内容"，改读盘是 O(n²)，在仿真盘上每次读还要线性扫文件表；这个不对称写进了
`list_objects_inline` 的文档）。

## AG4. 自查：三条变异一开始不咬（`§4.69`）、一次吃掉 fixture 的补丁（`§4.68`）、一个污染构建图的 harness（`§4.71`）

9 条证伪变异里 3 条报 `NO EFFECT`：一条打偏（改了不相关的第一个目录项）、一条根本没编译
（把参数改名成 `_name` 却仍在函数体用 `name`，而"harness 没看到 FAILED 行"被误判成"断言无效"），
一条是**断言太弱** —— 我用"重启后看得见"证明"枚举来自目录"，可 `load()` 本身就是用 `list` 填缓存的，
两种实现在重启点必然同值；改成对**运行中的 store** 断言，M8 立刻变红。教训："重启后正确"不等于
"来自枚举"，凡是宣称"不再依赖缓存"的断言都必须制造一个运行中的分岔窗口。

还有一条更贵的（`§4.71`）：harness 用 `shutil.move` 恢复文件，rename 保留了备份的旧 mtime，而那个 mtime
比变异版本的 rlib 更旧 —— cargo 因此不重编 `caly-storage`，转头把**带着变异**的 rlib 链进了之后重建的每个
下游测试二进制。门禁于是红在一条本轮新写的断言上，而磁盘上根本没有那个文件。源码字节是校验过的、
内容从头到尾没错；错的是我只验证了源码、没验证构建图。修法：恢复后 `os.utime(path, None)`，
并且恢复后跑 `cargo test --workspace`（只跑被改的包看不见下游污染）。教训：**改一个库的源码去证伪，
收尾要恢复的是"构建"，不是"文件"**；源码不变而门禁变红时，先查 `target/` 的 mtime，再读代码。

另一条是自己的工具：一次锚点覆盖范围大于替换文本范围的补丁，把 `schema.rs` 里一行 fixture 的
`write(...)` 删掉了，而所有 `assert old in s` 都通过。锚点只证明"打中了"，不证明"没少写"。
处置与两条新规（缩小锚点、打完立刻跑受影响的 target）见 `§4.68`。

## AG5. 结果与规模

```text
$ ./scripts/check.sh
  ok    cargo check --workspace --all-targets is clean
  ok    326 tests passed (floor 326)
  ok    clippy locations at baseline (32)
  note  1774 formatting diff lines remain (tracked, not gating)
  all gates passed
```

规模：200 个 `.rs` / 48,825 行 Rust / **326** 个行首 `#[test]`（42 个文件）/ 70 个 test target /
20 个成员 / 72 篇 Markdown。本轮 +5 测试（321 → 326），全部在 `crates/caly-storage/tests/fs_store.rs`：
带外写入的记录运行中与重启后都必须可见、残留与损坏分别处置、超限是拒绝而非短列表（含 `has_any`
的保守方向）、store 不写任何索引、pending 扫描答自目录而非内存。clippy 一度 33（`redundant_closure`，
我自己写的闭包），改代码回到 32。格式化欠账本轮新增部分已当场 `rustfmt` 掉（1,853 → 1,774）。

## AG6. 下一步（按优先级）

1. **`ADR-035` 第 3 步**：GC 的 grace period 优先取 `Meta.modified_at_unix_ms`，注入的
   `stored_at_unix_ms` 退为兜底 —— 这是"有能力、无调用者"名单上仅剩的一条。
2. **孤儿内容清扫**：删除元数据与删除内容之间崩溃留下的内容文件，今天没有任何东西会发现它
   （内容在三层目录下，端口只保证一层列举）。要么给端口加递归列举 / `stat_many`（需 ADR），
   要么把内容目录拍平；本轮把它写进 `ADR-035 §6bis-ter` 的"未一并解决"而不是假装完成。
3. `ADR-036` 第 0 步：给 `RequestEnvelope` 加 `io_budget` + 一个故意悬挂的端口，让
   `Timeout` / `Cancelled` 先变得可测。
4. 然后：`StorageBusy` 的生产者（cutover 期的 storage 争用模型）、流侧逐帧载荷比对、
   `caly-cli` 的 `[[bin]]` 与 `--as-role`（`ADR-037` 已经造出了这个需求）。


---

# 第十七轮（2026-08-28）：`ADR-035` 第 3 步 —— 对象的年龄改由端口证据决定

## AH0. 本轮选什么、为什么

上一轮结束时 `ADR-035` 只剩第 3 步，而 `IMPLEMENTATION_STATUS` 的未覆盖清单挂着
「`Meta.modified_at_unix_ms` 仍没有生产调用者 …… 不做就该撤掉该字段」。也就是说候选还是只有一个：
要么补完它，要么按自己写的规则撤掉。补完。

动手前先复核本轮要改的那处事实（不信任任何文档，包括上一轮的我自己）：
`grep -rn 'modified_at_unix_ms' crates/ | grep -v crates/caly-io` 在第十七轮开始时**零命中**，
所以"无调用者"当时确实成立；`grep -rn 'fs.list(' crates/caly-storage/src/` 命中 1 处，
所以第 2 步接的线还在。两条都成立才动手。

## AH1. 落点只有一处，四条路共用它

`FsStore::dated(object, suffix)`：`Fs::stat` 拿到 mtime，与记录里的声明**取较新的一侧**。
`put` 的返回值、`get`、`list_objects` 的枚举、`open()` 填缓存 —— 四条路都过它，因为"同一个对象的年龄
取决于哪次调用问的"就是两个真相换了一件类型的外衣。真盘那条也有测试：`StdClock` 取窗口两端，
断言对象年龄落在其中（测试自己不许读时钟，`ADR-011` + `clippy.toml`）。

一处**有意偏离**已写进 `ADR-035 §6bis-quater`：§2.4 的字面是"端口优先、`None` 才退回注入值"，
落地是 `max(端口, 声明)`。理由是两个来源会说谎的方向不同 —— 声明能被填成 1970，mtime 会因为备份恢复
或时钟回跳而偏旧 —— 而这个字段唯一会造成数据损失的错法是"看起来比实际更旧"（多留一轮是可逆的）。
证伪 M2 就是"改回字面版"，它让 `a_claim_newer_than_the_port_is_kept_and_a_missing_one_is_filled_in`
变红，所以偏离是被断言着的，不是嘴上说说。

## AH2. 代价，与本轮没解决的三件事

- 代价：每条对象记录多一次 `Fs::stat`。`ADR-035 §3` 明确拒绝过"让 `list` 返回富条目"并把
  批量 stat 留给 `stat_many`，所以本步不趁势改端口形状；`object_records` 本来就逐条 read + decode，
  复杂度类别不变（仿真盘上两者都是对文件表的线性扫）。`stat_many` 从此是**记下来的优化**，不是遗漏。
- 没解决 1：`GcPolicy::now_unix_ms` 仍由调用方提供。年龄有了一半端口来源，"现在几点"没有。
- 没解决 2：**GC 整条链没有生产调用者**（`run_object_gc` 只被 `crates/caly-storage/tests/gc.rs` 调用）。
  磁盘事实上只增不减。按 `ADR-018`「写操作即任务」，GC 该是 job（要进度、可取消、计入 overload 出口），
  那是独立一轮的决策，不该塞进"换个时间来源"里。
- 没解决 3：孤儿内容清扫（上一轮记的那条）不变。

## AH3. 自查：本轮两条新留档都是关于我自己的判断方式

- `§4.72`：这条缺陷不是读代码读出来的，是我为了测兜底路径**随手填了 `stored_at_unix_ms: 0`** 去构造
  反例时照出来的。教训可以复用：写"闸门类"字段（决定要不要删、要不要放行）的测试时，
  **先构造"调用方说谎"的那一侧**——反例造得出来，就说明这个字段本不该信调用方。
  同族的正面先例是 `content_sha256`：允许声明，但存储层自己重算，不符就拒 —— 同一个模式本该在
2026-08-27 那一轮就想清楚。
- `§4.73`：未覆盖清单"在细节上诚实、在结构上漏项"。它写了"grace period 依赖注入时间"，
  没写"没有人调用 GC"。此后检查自己写的"未覆盖"清单时，除了逐条核对，还要反问一句
  **"这一整块能力有谁按下去？"** —— 没有生产者时，最该出现在清单第一条的不是它的细节缺口。

6 条证伪变异全部咬住（M1 关掉定年、M2 改回端口覆盖、M3 取 `min`、M4 写路径不定年、
M5 启动不填年龄、M6 没有证据时伪造一个）。harness 直接复用上一轮收进 `scripts/falsify_round16.py`
的模板（含"恢复要碰 mtime、收尾要跑全工作区"两条本轮新增的规则，见 `§4.71`）。

## AH4. 结果与规模

```text
$ ./scripts/check.sh
  ok    cargo check --workspace --all-targets is clean
  ok    331 tests passed (floor 331)
  ok    clippy locations at baseline (32)
  note  1774 formatting diff lines remain (tracked, not gating)
  all gates passed
```

规模：200 个 `.rs` / 49,103 行 Rust / **331** 个行首 `#[test]`（42 个文件）/ 70 个 test target /
20 个成员 / 72 篇 Markdown。本轮 +5 测试（326 → 331）：仿真侧 4 条（端口定年、GC 反事实、
无时钟不伪造、`max` 的方向）、真盘 1 条（mtime 落在写入窗口内）。clippy 与格式化欠账都没新增
（本轮新代码一次通过 0 处新 lint，`rustfmt` 只跑 3 个文件后 `cargo fmt --all -- --check` 仍是 1,774）。
`ADR-035` 至此三步全部落地，`§6bis-quater` 末尾留着两个已知遗留。

## AH5. 下一步（按优先级）

1. **GC 的生产接线**：`GcJob`（按 `ADR-018` 写操作即任务：进度事件、可取消、过 `§13.2` 的
   idle 门禁、拒绝走第十三轮那条 overload 出口），`now` 从执行策略的时钟取，`doctor` 报告本轮结果。
   这一步同时消掉 `§4.73` 与 AH2 的两条没解决项。
2. **`stat_many`（或递归列举）**：把第 3 步的每记录一次 `stat` 收掉，并让**孤儿内容清扫**成为可能
   ——两者是同一个端口能力缺口，值得合在一条 ADR 里决策。
3. `ADR-036` 第 0 步：`RequestEnvelope.io_budget` + 一个故意悬挂的端口，让 `Timeout` / `Cancelled`
   先变得可测。
4. 然后：`StorageBusy` 的生产者、流侧逐帧载荷比对、`caly-cli` 的 `[[bin]]` 与 `--as-role`。


---

# 第十八轮（2026-08-28）：`ADR-038` —— 回收计划先落地，顺带把 `required_role` 变成真的门禁

## AJ0. 本轮选什么、为什么

上一轮结尾我写下"GC 整条链没有生产调用者"这条留档（`§4.73`），并把它排在本轮第一位。开工前照例先复核：
`grep -rn 'run_object_gc' --include='*.rs' crates/` → `1 src/gc.rs`（定义）+ `7 tests/gc.rs`，
"只有测试调用"成立。`grep -n 'fn list_revisions' crates/caly-storage/src/store.rs` → 无命中，
`§13.1` 的六类 root 里"已登记 Revision"这一类**当时根本没有查询可用**。

于是本轮的定位不是"把 GC 接上"，而是**把 GC 接上的第一个可核对切片**：`ADR-038` 分三步，
本轮落第 1 步（计划可读），删除留给第 2 步。理由写进 ADR 的方案 A：删除是唯一不可逆的那一半，
在没有"计划可读"之前上线它，等于让第一次评审在已经删完之后进行 —— 本仓库对不可逆操作的一致做法
是先给报告（`profile.apply` 有 `dry_run`，`storage-audit` 段先于任何删除存在）。

## AJ1. 三处结构性约束，而不是三个函数

- `RevisionStore::list_revisions()`，默认实现返回 `Unsupported` 而不是空集合。空集在这条链上不是
  "没数据"而是"这些对象没人引用，可以删"。两个内置后端各自实现（`FsStore` 复用 `ADR-035` 的目录枚举 ——
  上一轮接的线在这里第一次被别人用上）。
- `build_gc_plan` 是**纯函数**：root 集不全 → `collect` 被清空 + 每条缺口指名道姓。这不是保守，是唯一
  自洽的选择：一份"少了两类 root 算出来的删除列表"比"没有列表"更危险，因为它看起来可执行。
- `required_role` 提到 `handle_request`，对 `Query` / `Stream` 生效；命令路径**保留**自己那一次
  （`submit_request_as_command` 是公开入口）。三处共用一个 `require_role` 与一个 `api_error_for`，
  于是"同一个拒绝在两条路长得不一样"被结构排除，而不是靠纪律。

## AJ2. 本轮最该留档的四条，全是关于我自己的判断方式

- `§4.74` **两条时间线从未对齐**：上一轮把对象年龄换成端口 mtime，而 `now` 仍是注入的策略时钟。真盘上
  `now=0` < 年龄 ⇒ 一切"在未来" ⇒ grace 保护一切，计划永远"无事可做"；反向（注入时钟超前）会让真实对象
  全部看起来过期 —— 那个方向今天不可达，但一步之遥。第十六/十七轮的 6 条证伪都抓不到它，因为仿真盘
  的 mtime 与策略时钟同源；**只有写消费者才会走到真盘那条路径**。已加 `clock-timeline` 缺口：检出即拒绝，
  根因（组装根注入 `Clock`）留在 `ADR-038 §3`。
- `§4.75` `required_role` 对读不生效 —— `ProfileOp::Plan` 的 `Operator` 声明在本仓库历史上从未被执行。
  缺陷不是我读出来的，是"Viewer 应该被拒"这条新断言第一次跑就红出来的。
- `§4.76` 我第一版把"GC 不能运行"升级成 `doctor` 的 warning，最有价值的那条断言
  （"健康的落盘 store 不产生 warning"）立刻变红。追下去发现更结构性的事实：凡是能让计划拒绝的 store
  状态，`storage_audit` 会先把整个 doctor 请求打成 `UNAVAILABLE` —— 我的 warning 要么重复审计、要么永不触发。
  处置不是放宽那条断言，而是删掉 `has_actionable_gap()` 方法（不留永不触发的分支），保留 `actionable`
  作为**数据**，并把理由写进 `ADR-038 §4` 的 Negative。
- `§4.78` **连续两轮**我把处置表的行粘进了上一段（锚点吃掉了分隔空行、替换文本没把它吐回来），
  所有门禁全绿：`check_markdown_tables` 只认以 `|` 开头的行。修法除拆回粘住的行，是给 `caly-arch-test`
  加 `check_stray_table_rows`（≥3 个 ` | ` 分隔、以 `|` 结尾、不以 `|` 开头 ⇒ 粘住的表行；围栏内不判），
  并证伪过：粘一行进去 → `stray-table-row: docs/ONBOARDING_NOTES.md:1499`，还原 → 全绿。

另有 `§4.77`：`Redactor` 会把 `remediation` 里的 `pass idempotency_key: Some(..)` 当成敏感键值掩掉
（实测 `***REDACTED***)`）。本轮把文案提成 `concat!` 常量（一处改，六处不必各改一遍），**没有**动掩码边界 ——
豁免哪个字段属 `ADR-020` 的决策，且需要逐字段证明"这一列永远不含调用方数据"。

## AJ3. 顺带修掉的构建图陷阱

`KEY_REMEDIATION` 第一次提取成常量时，我的补丁把多行 `\` 续行折叠成一行、留下六个连续空格，测试
`a_required_command_without_a_key_is_refused_before_the_engine_sees_it` 立刻变红（它断言的是
"mint a fresh value per distinct write"这段单空格文本）。教训：**把字符串提成常量必须核对渲染后的字节**，
不是核对源码看起来差不多。改用 `concat!` 之后没有转义与续行的余地。

## AJ4. 结果与规模

```text
$ ./scripts/check.sh
  ok    cargo check --workspace --all-targets is clean
  ok    353 tests passed (floor 353)
  ok    clippy locations at baseline (32)
  note  1760 formatting diff lines remain (tracked, not gating)
  all gates passed
```

新增 22 条断言（331 → **353**：`crates/caly-engine/src/gc_plan.rs`
单元 8、`crates/caly-daemon/tests/gc_plan.rs` 8、`crates/caly-storage/tests/revision_listing.rs` 4、
`caly-arch-test::docs` 2）。证伪 11 条变异全部咬住（M1 从图里摘掉 revisions 一类、M2 缺口不再清空列表、
M3 时间线判反、M4 采样不设限、M5 接受 `max_deletions: 0`、M6 `doctor` 不再报计划、M7 读侧不设角色门、
M8 命令路径不设角色门、M9 `list_revisions` 默认答空集、M10 解析失败改成整条查询失败、M11 视图丢掉
`actionable`），收尾工作区全绿、7 个文件按 sha256 校验恢复。clippy 本轮 0 新增（32 处基线未动）；
格式化欠账 1,774 → **1,760**（顺手把上一轮漏排的 `caly-engine/src/lib.rs` 与 `local_facade.rs` 也格式化掉了）。

## AJ5. 下一步（按优先级）

1. **`ADR-038` 第 2 步**：`SystemOp::CollectGarbage` 作为任务（`ADR-018`「写操作即任务」）：进度事件、
   可取消、执行的是**它刚取到的那份计划**且仅当 `would_run == true`，拒绝走第十三轮的 overload 出口；
   结果与计划一起进支持包新段 `storage-gc`。
2. **`ADR-038` 第 3 步**：组装根注入 `Clock`，让 `now` 与端口 mtime 同源 —— 这一步做完之前，真实部署上的
   计划会一直带着 `clock-timeline` 拒绝（`§4.74`）。它可以和第 2 步同轮，但必须各自可回退。
3. `ADR-036` 第 0 步（`RequestEnvelope.io_budget` + 一个故意悬挂的端口）；`stat_many` + 孤儿内容清扫；
   `caly-cli` 的 `[[bin]]` 与 `--as-role`（`ADR-037/038` 都需要它）。


---

# 第十九轮（2026-08-28）：`ADR-038` 第 3 步 —— 让比较的两端来自同一个钟

## AL0. 本轮选什么、为什么

上一轮结束时 `ADR-038` 有两件未完成：第 2 步（把删除变成任务）与第 3 步（注入 `Clock` 使 `now` 与
mtime 同源）。按 `AJ5` 的顺序第 2 步在前。本轮**故意换序**，理由就是上一轮自己写下的那条留档：
`§4.74` —— 真实目录上 `now=0` 而对象年龄是文件 mtime，一切"在未来"，grace 保护所有对象；于是先落地
删除只会得到一个"看起来能用、实际永远不删"的动词。**先让比较成立，再让删除发生**。换序的理由写进
`ADR-038 §7` 的「检出规则的方向」。

## AL1. 落地的形状

- `EngineHandle::set_storage_clock(Option<Arc<dyn Clock>>)` 与 `storage_now() -> (i64, &'static str)`：
  注入了就用端口时钟（`storage-clock`），没注入就退回策略基准（`execution-policy-base`），
  **来源随值一起返回** —— `now=0` 看起来像关于世界的事实，其实只是"没人给过我这个数"。
- `GcPlanSummary.now_source` / `GcPlanView.now_source` / `summary_line` / `doctor` 的 note 全部带上它：
  `now=1700000000000@execution-policy-base`。
- `caly-daemon::set_storage_clock` 只做转发，参数类型写成 `caly_engine::Clock`（引擎对端口 trait 的
  re-export）。**没有**给 `caly-daemon` 新增指向 `caly-io` 的依赖边 —— 那条边受
  `ALLOWED_DEPENDENCY_EDGES` 管辖，为少写一行 import 去动架构门禁是本末倒置。
- journal 的时间戳一行未动：它必须与 `audit` 的 `now` 同源，统一成宿主时钟会破坏 `ADR-022` 的可重放
  性，并把每个 journal 都判成陈旧。这张对照表写在 `ADR-038 §7`。

## AL2. 测试必须钉住两侧

`crates/caly-engine/tests/gc_plan_and_clock.rs`：
① 注入与 `SimFs` 共享的 `SimClock` → `now_source=storage-clock`、无 `clock-timeline`、刚写的对象在 grace
内不可删 → 推进虚拟时钟越过 grace → **同一个对象成为唯一可回收项**（grace 边界成了事实而不是巧合）；
② 什么都不注入、且**先推进时钟再写对象** → `age > now` → 拒绝并写明基准；随后注入 → 同一份 store 状态
立刻成为可用计划。真盘版本在 `crates/caly-daemon/tests/gc_plan.rs`：注入 `StdClock` 后 `system.gc-plan`
把孤儿列为可回收，而 active 快照引用的对象**即使 grace=0 也仍被 root 挡住**。

## AL3. 自查两条，都是关于我自己的

- `§4.79` 补丁脚本又一次把 Rust 字符串的 `\` 续行折成一行（留下 6 个连续空格）。第十八轮同族缺陷是
  被测试抓住的；**这次测试没抓**，是我读文件时看见的。于是补了一条渲染自检
  `assert!(!detail.contains("  "))` 并定规则：生成 Rust 字面量不用行内续行，长文本用 `concat!`。
  与 `§4.68`（锚点吃行）、`§4.78`（表格行粘段）同族 —— 补丁的失败模式是"打上了但形状错了"。
- `§4.80` 我第一版测试是"先写对象再推进时钟"，断言没红：推进时钟不改动已盖好的日期，`age == now`
  不满足 `age > now`，于是得到的是"仍在 grace 内"而不是"检出跨时间线"。两种状态在 `collect` 上完全
  同形（都空），差别只在 `gaps` / `skipped_for_grace`。教训：**写检测器的测试必须构造它唯一的触发
  条件，并断言与它相邻的那个"看着像"的状态**，否则测试会在两种情况下都绿。

## AL4. 结果与规模

```text
$ ./scripts/check.sh
  ok    cargo check --workspace --all-targets is clean
  ok    357 tests passed (floor 357)
  ok    clippy locations at baseline (32)
  note  1760 formatting diff lines remain (tracked, not gating)
  all gates passed
```

规模：204 个 `.rs` / 51,567 行 Rust / **357** 个行首 `#[test]`（46 个文件）/ 73 个 test target /
20 个成员 / 73 篇 Markdown。本轮 +4 断言，6 条证伪变异全部咬住；clippy 与格式化欠账均无新增
（1,760 未变）。`ONBOARDING_NOTES` §4 条数 78 → **80**；处置表补 `| 6.45 |`，"明确不做"小节让位 `6.46`；
`ADR-035 §6bis-quater` 的两条"本步没解决"同步改成已落地/仍开着的准确状态。

## AL5. 下一步（按优先级）

1. **`ADR-038` 第 2 步**：`SystemOp::CollectGarbage` 作为任务 —— 进度事件、可取消、只执行它刚取到的那份
   计划且仅当 `would_run`、拒绝走第十三轮那条 overload 出口，结果进支持包新段 `storage-gc`。
   第 3 步的先决条件已在引擎侧就位，这一步现在才谈得上安全。
2. `ADR-036` 第 0 步：`RequestEnvelope.io_budget` + 一个故意悬挂的端口，让 `Timeout` / `Cancelled` 可测。
3. `stat_many` / 孤儿内容清扫；`caly-cli` 的 `[[bin]]`（`ADR-037`、`ADR-038` 第 3 步的生产侧填参都等它）。


---

# 第二十轮（2026-08-28）：`ADR-038` 第 2 步 —— 回收从"报告"变成"任务"

## AM0. 本轮选什么、为什么

`AL5` 的第一项就是它。第 3 步（时钟同源）上一轮已在引擎侧就位，于是"把删除接上"的先决条件满足了 ——
这个顺序不是偏好：`§4.74` 说清了反过来的后果（真盘上 `now` 是策略基准、年龄是文件 mtime，任何比较都无意义），
所以**先让比较成立，再让删除发生**；这样失败的方向永远是"什么都不做"，而不是"做错"。

开工前照例复核自己的记录：`grep -c 'SystemOp::CollectGarbage' crates/caly-api/src/ops.rs` → 0（确实没接）；
`grep -n 'fn sweep_objects' crates/caly-storage/src/gc.rs` → 0（拆分还没做）；
`grep -n 'active_snapshot' crates/caly-daemon/src/app.rs` → 只有两处赋值，两处都来自 store
（这条复核直接产出 `§4.81`，见下）。

## AM1. 形状

- `SystemOp::CollectGarbage { request }`：`Idempotency::Required`（重试不能删两轮，而且与 apply 不同，
  这里没有可推导的天然 key —— 两次调用之间 store 已经变了）、`Role::Admin`、`mutates_revision: true`、
  `CostClass::Large`、**没有 `dry_run`**。
- `CommandKind::StorageGc { grace_period_ms, max_deletions }` → 任务；`dispatch` 归 `Mutating` +
  `EstimatedImpact::ReadOnly`（改的是存储，不动运行中的 core，与 `DnsFlushCache` 同一个分法）；
  `coordinator` 声明 `Config` + `Core` 两把锁（"删的是配置与 core 工件"这件事必须写在唯一说它的地方，
  即使今天引擎串行执行、声明是冗余的）。
- `caly_storage::gc` 拆出 `sweep_objects(store, digests, retained)`：`run_object_gc` 仍是"自己算自己删"
  （它的语义就是跑一轮），引擎这条路径必须"算一次、报告、执行同一份"，因为引擎多了一条
  **root 不全就清空**的规则（`§2.3`），那是 `§13.1` 的要求而不是 `§13.2` 的。
- 结果进 `EngineState::last_gc_run` → `doctor` 的一行 note → 支持包第 12 段 `storage-gc`。
  "没跑过"与"跑了、删了 0 个"与"被拒"是三种不同的话，都必须能被读出来。

## AM2. 三条我本轮查出来的东西（都是关于我自己的判断）

- **`§4.81`「daemon 拥有当前快照」是我上一轮写错的**，而且同时写进了 ADR 与方法文档。grep 显示 daemon 的
  两处赋值都来自 `latest_last_known_good`：它不拥有这件事，它只是镜像。危害不在措辞，在于那份镜像是
  **一份必须有人记得更新的副本** —— 新的提交路径只要忘了同步，root 集就安静地少一类保护，而少一类保护
  等于可以删掉正在用的对象。于是 `active_snapshot_id` 移进 `EngineState`，由 `finalize_apply_persistence`
  成功之后写入。可复用：**每次用"某层拥有这个事实"为参数传递辩护，去 grep 那个所有者有几分是自己算的。**
- **`§4.82` 检查跑进了被检查的东西里面。** `StorageGc` 成为任务后，第一个端到端测试直接红：
  `has_work_in_flight` 把正在执行收集的那个 job 数了进去，于是每个周期都拒绝自己。修成
  `work_in_flight_except(state, excluding_job)`，且**入队前那道门不继承豁免**（否则两个排队的收集互相放行）。
  可复用：把守卫从外部移进被守卫的流程内部时，重问一遍"这个谓词数的是谁"。
- **`§4.83` 复用拒绝类别 = 复用它的说明文字和计数器。** 最省事的写法是把越界也塞进
  `InvalidRequest`，`match` 立刻补全、测试也只看"被拒了"。停下来读调用方会看到什么，才发现两处会撒谎：
  remediation 会说"请带 idempotency_key"（照做后仍被同一理由拒），`idempotency_key_refusals`
  会因为有人多问了几次"能不能多删点"而上涨。于是新增 `InvalidBounds`，remediation 与计数各归其位。
  可复用：新增拒绝理由时，把旧 kind 的**所有消费者**列一遍，而不是把 `match` 补到能编译。

另外 `§4.79`（补丁脚本破坏字符串形状）本轮又复现两次，规则补进该条：脚本里的字符串一律三引号，
生成的 Rust 字面量一律单行或 `concat!`，写完立刻 `ast.parse` + 编译各跑一次。

## AM3. `StorageBusy` 终于有了生产者 —— 以及为什么它不等于 `§6.2` 完成

`OVERLOAD_AND_RETRY_MODEL §3.4` 这个类别从第十三轮起有分类、有映射、没有生产者。本轮给它接上第一个：
收集周期在引擎忙时于**入队之前**被拒。它不需要编造测量（"有别的命令在跑"由引擎状态回答），而被拒的一方
什么都没失去（重试即可）。但它**不是** `§6.2` 设想的 cutover 期存储写争用 + recovery-sensitive 升级 ——
那一句仍未落地，我把它在 `OVERLOAD_AND_RETRY_MODEL` 与未覆盖清单里都分行写明，免得类别同名被读成已完成。

## AM4. 结果与规模

```text
$ ./scripts/check.sh
  ok    cargo check --workspace --all-targets is clean
  ok    367 tests passed (floor 367)
  ok    clippy locations at baseline (32)
  note  1760 formatting diff lines remain (tracked, not gating)
  all gates passed
```

新增 10 条断言（`tests/gc_plan_and_clock.rs` 4 条 + `caly-daemon/tests/gc_collect.rs` 6 条）——其中三条是证伪跑出来之后补的，见 `§4.84`；
`ENVELOPE_PARITY_CASES` 从 6 到 8（含一条带 key 的重放与一条缺 key 的拒绝），支持包 11 → 12 段
（`storage-gc`；`BUNDLE_SECTIONS` 是声明表，段数变了三处文档同步）。规模：205 个 `.rs` / 52,920 行 /
**367** 个 `#[test]`（47 文件）/ 74 个 test target。`ONBOARDING_NOTES` §4 由 80 → **83**。

## AM5. 下一步（按优先级）

1. `ADR-038 §8` 末：`§13.2` 的 **idle 自动触发**——机制齐备，缺的是"谁在什么时候允许系统自己动数据"的
   策略决定（需要一次独立讨论，不该塞进实现轮）。
2. `ADR-036` 第 0 步：`RequestEnvelope.io_budget` + 一个故意悬挂的端口，让 `Timeout` / `Cancelled` 可测。
3. `§6.2` 的 cutover 存储争用模型、`stat_many` / 孤儿内容清扫、`caly-cli` 的 `[[bin]]`
   （`ADR-037` / `ADR-038 §3` 的生产侧填参都等它）。


---

# 第二十一轮（2026-08-28）：`ADR-036` 第 0 步 —— 让 `Timeout` 与 `Cancelled` 成为可以被问的问题

## AN0. 本轮选什么、为什么

`AM5` 的第二项是它，而且它是唯一一个"已 Accepted 但实现未开始"的 ADR。更重要的是它卡着一串别人：
`Http` / `Proc` 适配器、IPC transport、真 `EffectRuntime`、`Probe` 超时接进验证门禁 —— 全都因为
"端口不能挂起、`block_on_ready` 只 poll 一次"而写不出来（`ADR-036 §1` 那张表就是本轮复核过的实测表）。

`ADR-036 §6bis.3` 把第 0 步定义成**只加不改**：类型 + `Option<IoBudget>` 字段 + 让 `Timeout`/`Cancelled`
在契约测试里可达（需要一个故意挂起的端口），端口行为仍全部立即 ready。本轮就按这条边界做，不越到
`BoundedExecutor`（第 1 步）去。

## AN1. 有了什么

- `caly_io::runtime::drive(fut, Drive)`：有界轮询，每次轮询前依次看取消、期限。三种出路互不相同：
  `Cancelled`（不可重试）、`Timeout`（可重试）、`Busy`（可重试 + 瞬态，且文本写明哪些限制在场）。
  **没给时钟就不判期限** —— 编造一个"期限已过"是给调用方一个无法核对的理由。
- `block_on_ready` 变成 `drive(fut, Drive::immediate())` 的包装；`caly-engine::recovery::run_ready` 也不再
  自己写 poll 循环（它曾经连 `Wake` 都自己实现过）。三份"poll 一次并抱怨"的合成一份，措辞从此不可能分叉。
- `caly_common::CancelToken`：两个 `Arc<AtomicBool>`（自身 + 父），`child()` 只在父取消时取消。
  相等性写成语义同一（`Arc::ptr_eq`）而不是标志相等 —— 否则两个未取消的 token 会"相等"。
  `Ctx` 多了它（默认不取消）与 `deadline_mono_ms`。
- `caly-io-sim`：`hang("fs.read")` 一次性、按 label 注入"永远不就绪"。这是本轮真正的买家：
  没有可挂起的被测对象，"驱动器能不能区分超时与取消"就只是个修辞问题。
- `RequestEnvelope.io_budget: Option<IoBudget>` → `request_map` 透传：`ADR-036 §6bis.2` 记在它自己文中的
  事实错误（"从 envelope 透传"其实无从透传）到此成立。

## AN2. 一处偏离与一条明知未测的线，都写下来

- **偏离**：`§2.2` 要 `Ctx` 存绝对 `Deadline`。daemon 没有单调时钟（`clippy.toml` 只豁免 `caly-io-std`），
  所以换算留在持有 `Clock` 的驱动者一侧，`Ctx` 只带 `deadline_mono_ms: Option<u64>`、daemon 边界明确写
  `None`。这是 `§4.81` 那一课的第二次应用：**派生值必须住在有源的层**。零点错位的两个方向都错（0 会取消
  一切，很大则从不取消），所以"算一个大概的"不是次优解而是错误解。记 `§4.86`。
- **未测**：`caly-app::remote` 里那一行 `Some(ctx.io_budget.clone())` 没有端到端断言 —— 预算在记账（第 3 步）
  之前没有任何可观察后果，要断言就得暴露内部值或为测试造公开 API。两个边界处的单元测试已经钉住
  "同一请求在两条门面上答案相同"这一半；剩下那一半连同理由写进未覆盖清单，第 3 步必须一起补。

## AN3. 自查：`§4.87` —— 我信了自己的"成功计数"两次

① sweep 加 `io_budget: None,` 时正则找 `role:`，凡是写成字段初始化简写 `role,` 的构造点它都不认得，脚本却
报告"改了 21 处"；剩下的是编译器逐条（`E0063`）交给我的，我按报错迭代到零才算完 —— 所以"漏了几处"这个数字
我只引用编译器，不自记（`§4.87`）；② 我把某个补丁脚本的输出 `tail -12` 截断后继续干活，而那个脚本
在中途断言失败退出、后半批补丁一条都没打上（症状是"我以为加好的两个测试不在文件里"）。两条同一族：
**自动改写的验收标准必须来自独立判定者（编译器/断言），不能来自工具自己的统计**；与 `§4.53`
（过滤 grep 掩盖编译失败）、`§4.84`（证伪工具自己误报）是同一件事的第三次记。

## AN4. 结果与规模

```text
$ ./scripts/check.sh
  ok    cargo check --workspace --all-targets is clean
  ok    384 tests passed (floor 384)
  ok    clippy locations at baseline (32)
  note  1685 formatting diff lines remain (tracked, not gating)
  all gates passed
```

新增 17 条断言：`caly-io/src/runtime.rs` 单元 6（含"立即就绪只 poll 一次"这条**不变性**测试——它保证本轮
对所有既有调用点零行为变化）、`caly-io-sim/tests/contract.rs` 2、`request_map` 单元 4、`local_facade` 单元 2、
`caly-common/src/lib.rs` 2、`caly-arch-test/src/docs.rs` 1（`AN6`）。合计由 `scripts/regenerate_test_census.py`
报出（`files=50 total=384 rows=50`），本文件只负责不复述一个自己数出来的值。
`ONBOARDING_NOTES` §4 由 85 → **90**；处置表补 `| 6.49 |`–`| 6.52 |`，`### 6.52 明确不做` 让位 `### 6.53`。
规模：205 个 `.rs` / 53,801 行 / **384** 个 `#[test]`（50 文件）/ 74 个 test target / 73 篇 Markdown。
clippy 无新增（32）；格式化欠账 1,760 → **1,685**（本轮触碰过的文件跑了 `rustfmt --edition 2021`）。

## AN5. 下一步（按优先级）

1. `ADR-036` 第 1、2 步：`BoundedExecutor`（有界队列、满了 `Busy`）+ 把命令的 `Ctx` deadline / token 接进
   `run_ready`，让 `deadline_ms` 第一次真的能中止一次挂起的 store 访问；`Probe { deadline_ms }` 接进验证门禁分支。
2. `ADR-036` 第 3 步：`IoBudget` 记账 + 默认值从 unlimited 收窄（需要 release note，`§4.86` 那条未测断言一并补）。
3. `ADR-038 §8` 末的 idle 自动触发；`§6.2` 的 cutover 存储争用模型；`stat_many` / 孤儿内容清扫；
   `caly-cli` 的 `[[bin]]`（`ADR-037` / `038` 的生产侧填参都等它）。


## AN6. 收尾：为这个失效专门写的门禁，仍然没看见失效（`§4.90`）

写 AN4 那串数字之前我照例复核，用 `grep -c '^| 6\.5'` 数处置表：只数到 6.50。`| 6.51 |` 那一行**被接在
`§6` 末尾一条 `>` 引用的尾巴上**（`…的理由。| 6.51 | … | 4.89 |`），而 `check_stray_table_rows` —— `§4.78`
为了"表行被粘进上一段"这个失效专门加的门禁 —— 全绿。原因在度量口径：它数的是 ` | ` 分隔的个数，
被粘的行第一个 `|` 紧贴中文句号（没空格）、最后一个 cell 闭合在行尾（也没空格），三个 cell 只数出两个
分隔。规则的形状（不以 `|` 开头 + 以 `|` 结尾 + 三个 cell）没错，错在**用什么去数**。

处置是两步，顺序很重要：

1. **先按真实形状写一条测试**（`> prose。| 6.51 | x | y |`），跑，**红**（`assertion left == right failed:
   []`，`left: 0, right: 1`）—— 这一步证明缺口是真实的，而不是我给门禁编一个假想敌。上一轮的测试用的
   是 `prose | 6.42 | x | y |`（有空格），所以它一直在通过：为失效写的门禁被"我想象中的整齐形状"喂熟了。
2. 再把判据改成「不在行内代码段里的 `|` 个数 ≥3」（新增 `pipes_outside_code_spans`，反引号按开关处理，
   与 `table_cells` 同口径 —— `§4.89` 那句引文里的 `| 6.99 |` 因此不会被误伤）。改完跑全语料：**只报一行**，
   正是 `docs/ONBOARDING_NOTES.md:1826`。门禁变宽与损坏被看见是同一次运行里的两个读数，而不是我先修
   文档再补测试。

然后才是把那一行搬回表里、把 `AN4` 里三处我自己数错的数字（`request_map` 6→4、§4 条数 87→90、
测试数与行数）改成实测值。**"我上一轮说过已经手工补回"**在这一轮被 `grep` 证伪了两次，这正是
`§4.87` 的同一课：文本变长不是证据，形状生效才是。

顺带一条：还原 `TEST_FLOOR` 时我用 `cp /tmp/check.sh.bak … 2>/dev/null`，而那个备份从未创建；是
`sha256sum -c` 报 `FAILED` 才拦住我（`§4.90` 末）。**"调用过还原命令"不是证据，内容一致才是。**

---

# 第二十二轮（2026-08-28）：`ADR-036` 第 1 步 —— 有界执行器，以及一个拒绝制造进展的调度器

## AN0. 本轮选什么、为什么

上一轮把第 0 步（类型 + 有界驱动 + 可挂起的仿真端口）落地，并在 `AN5` 里把第 1、2 步排在最前。
本轮做**第 1 步**：`BoundedExecutor`。选它的理由不是"顺序如此"，而是它把三件一直在文档里当口号的东西
变成可以问、可以答的问题：

| 之前只是一句话 | 现在有一条断言 |
|---|---|
| "有界执行域"（`ADR-013`） | 队列满了是 `Busy` + 文本同时给出在队数与容量，且**不消耗 `TaskId`** |
| "公平推进"（`ADR-036 §2.1`） | 一轮里每个任务只拿 `polls_per_task` 次；提交序即完成序 |
| "`deadline` / `cancel` 必须被执行" | 期限由**注入的**时钟判定；没有时钟就不判，结果 `Busy` 而不是 `Timeout` |

`ADR-036 §5` 的四步里，第 2 步（引擎接线）必须排在执行器存在之后 —— 本轮不动 `run_ready`，
所以下面 `AN2` 说清"有了但没人用"这一条怎么记账。

## AN1. 有了什么

- `crates/caly-io/src/executor.rs`：`BoundedExecutor<'a, T>`（`submit` / `tick` / `run_until_idle`）、
  `ExecutorLimits { max_tasks = 64, polls_per_task = 4, advance }`、`TaskLimits { deadline, cancel }`、
  `Completion<T>`、`RunReport<T> { completions, ticks, stop, stuck }`、`ExecutorMetrics`（十个计数器）。
- `Advance::{None, StepMillis(ms)}`：唯一能让"世界走一步"的入口，且它调的是注入的 `Clock::sleep_until`。
  **`caly-io` 没有新增任何 `clippy.toml` 豁免，也没有读宿主时钟** —— `§6bis.1` 表过态的那一点就此落地。
- `runtime::drive_pinned(Pin<&mut F>, Drive)`：`drive` 的循环被抽出来复用。动机是所有权，不是措辞：
  `drive` 按值取 future，一轮没就绪就把调用方正等的东西销毁了，而执行器需要"还没就绪，还你"。
  生产路径里 `Waker::noop` 的命中数仍是 **1**。
- 两条 ADR 没写死、本轮定死的语义：① **端口自己的故障原样交出、交一次、不重试**（只有驱动器的 `Busy` 回队）；
  ② **执行器不制造进展** —— `Advance::None` 时时间一格不走，跑完预算就是 `Busy` 并点名卡住的 label。
- `docs/adrs/ADR-036` 多了 `§6bis-quater`（落地记录，含"第 1 步故意没做的四件事"）。

## AN2. 有界但没人碰得到：这条账怎么记

`max_tasks` 今天只会被测试触到 —— 执行器**没有生产调用者**，第 2 步把它接进
`caly-engine::recovery::run_ready` 之后，"第 65 个并发端口调用被拒"才是运维能观察到的事。
我没有为了"看起来已接线"去硬造一个调用点（那会把 `run_ready` 的语义悄悄改掉）。处理方式与
`run_object_gc` 一致：`IMPLEMENTATION_STATUS` 的未覆盖清单第一句写明"执行器今天没有生产调用者"，
`ONBOARDING_NOTES §4.85` 那条"分工不是遗漏"的说法在这里同样成立。

## AN3. 自查三条（都关于我自己的手法）

- `§4.91`：我断言 `Unavailable` 是 `retryable` —— 那是我对生产者的猜测，红了。真相是
  `FaultSpec::into_io_fault` 一个位都不设。改法不是把断言反着写，而是**比较两条路径的产物**：
  同一个故障走一次直接读拿 `direct`，再走执行器拿一份，`assert_eq!(executed, &direct)`。
  顺带抓到"故障只被消费一次 ⇒ 第三次读必须成功"（= 执行器没重试）。
- `§4.92`：`dead_code` 报 `struct SleepFaults is never constructed` —— 我写了夹具、计划了断言，
  忘了把断言写下来。补出来的那条测试第一次就断言了 `ticks == 1` 与 `busy_stops == 0`。
  **零依赖工作区里的 `unused` 警告是免费的覆盖率检查器**：修法是补断言，不是压警告。
- `§4.93`：一个五处替换的补丁脚本在第三处 assert 失败，因为上一轮跑过 `rustfmt` 把那行折成了三行。
  整个脚本一个字节都没写盘 —— 这次这正是我要的行为：**一个脚本 = 一次写盘**，`AssertionError` 一律当作
  "什么都没发生"重跑。与 `§4.87`（半途 abort 而后半批没打上）的差别不在会不会 abort，而在半改状态是否存在。

## AN4. 结果与规模

```text
$ ./scripts/check.sh
  ok    cargo check --workspace --all-targets is clean
  ok    401 tests passed (floor 401)
  ok    clippy locations at baseline (32)
  note  1685 formatting diff lines remain (tracked, not gating)
  all gates passed
```

新增 17 条断言：`caly-io/src/executor.rs` 单元 13、`caly-io-sim/tests/executor.rs` 4。合计由
`scripts/regenerate_test_census.py` 自报 `files=52 total=401 rows=52`，门禁报 `401 tests passed (floor 401)`
—— 两个来源一致才写进文档（`§4.87`）。规模：`find crates -name '*.rs' | wc -l` = 207，`.rs` 合计 55,176 行，
test target 75（55 个可执行 + 20 个 doc-test），成员 20，`docs/**` Markdown 73 篇。
clippy 本轮 4 条告警全部改代码修掉（`redundant_pattern_matching` 1、`explicit_auto_deref` 2、`dead_code` 1，
条数取自 `cargo clippy -p caly-io -p caly-io-sim --all-targets` 的原始输出，不是我数的），基线仍 32，
`#[allow]` 加了 0 处；格式化欠账 1,685 未新增（本轮触碰的 4 个文件单独跑过 `rustfmt --edition 2021`）。

**证伪：10 条变异全咬住**（一条一个文件、`try/finally` 按内容 + mtime 还原、`sha256` 复核、还原后整仓再跑一遍）：

```text
M1 admission bound is off by one                     bit
M2 a refusal consumes a TaskId                       bit
M3 a round drives greedily instead of fairly         bit
M4 a port fault is 'not ready yet' and gets requeued bit
M5 the driver's Busy ends the task instead of keeping it bit
M6 a fault from the sleep port is relabelled Busy    bit
M7 busy_stops counts every stop, port faults included bit
M8 sleeping without a clock silently downgrades      bit
M9 a timed-out task is also counted as completed     bit
M10 the executor keeps its clock instead of handing it to the driver bit
post-restore workspace: green / digest ok: executor True, runtime True
```

十条一次全红，是 `§4.88` 那条规矩的回款：**写断言时就把"被改的那条分支"指出来**（本轮每条断言都对应
一个具体的判断句：`depth` 还是不是 2、id 有没有洞、时钟有没有被交出去、`busy_stops` 是不是 0）。

## AN5. 下一步（按优先级）

1. `ADR-036` 第 2 步：把命令的 `Ctx` 接进 `run_ready`（deadline + token + 走 `BoundedExecutor`），
   `deadline_ms` 第一次真的能中止一次挂起的 store 访问；`Probe { deadline_ms }` 接进既有验证失败分支。
2. 第 3 步：`IoBudget` 记账 + 默认值从 unlimited 收窄（需要 release note），并补 `§4.86` 那条
   仍未测的 `caly-app::remote` 预算转发断言。
3. 第 4 步：`caly-io-std` 的有界阻塞池 + `Http` / `Proc`（`§2.6`、`ADR-013` Follow-up）。
4. `ADR-038 §13.2` 的 idle 自动触发；`stat_many` / 孤儿内容清扫；`caly-cli` 的 `[[bin]]`。

---

# 第二十三轮（2026-08-28）：`ADR-036` 第 2 步 —— 命令的 `Ctx` 抵达 store 接缝，并划清它到不了的那条线

## AN0. 本轮选什么、为什么

上一轮留下第 2 步：执行器有了，但没有任何生产调用者读命令的 `Ctx`。开工前先复核"这一步到底能让什么变成可
观察"，结论决定了整轮的形状：

| 接缝 | 谁在这里驱动 future | 挂起能被观察到吗 |
|---|---|---|
| S1 引擎 → `StorageBackend` | `recovery::run_ready`（本轮新增 `run_ready_in`） | 后端全部首次 poll 即就绪 ⇒ **只能观察"开始前就拒"** |
| S2 `FsStore` → 端口 | `crates/caly-storage/src/fs_store.rs` 里的 `block_on_ready` | 挂起在这一层被摊平成 `StorageError`，S1 看不见 |

所以"把限制接到 S1"能兑现的是**取消与超期阻止一次尚未开始的 store 访问**（真实、可断言、运维可观察），
而"打断已经开始的调用"必须先把 `Ctx` 送进 `StorageBackend` 的签名 —— 那是 `RFC-0007` 冻结过的形状。
本轮因此做了两件同等重要的事：把 S1 接上，并把"到不了"写进 ADR 与状态文档，**不让 `enforced` 一个词替
两个承诺背书**（`§4.96`）。

## AN1. 有了什么

- `crates/caly-engine/src/run_limits.rs`：`RunLimits`（`immediate()` / `for_command(&Ctx, Option<Arc<dyn Clock>>)` /
  `drive()` / `describe()`）与 `StoreRefusal { kind, message, limits, retryable }`。相对期限在这里锚定成绝对
  `Deadline`；**没有时钟就记 `unjudged` 并如实上报**，既不当成"没期限"也不当成"期限已过"。
  `DEFAULT_STORE_POLL_BUDGET = 64` 带 `const _: () = assert!(> 0)`。
- `recovery::run_ready_in(future, &RunLimits)`：`drive` + 类型化拒绝。`run_ready` 一字未动，仍逐字等于
  `block_on_ready` 的文案（那条"两份措辞不许分家"的旧断言继续守着）。
- 生产接线：`EngineHandle::begin_apply_persistence(projection, &RunLimits)` 与
  `advance_apply_phase(..., &RunLimits)`，由 `worker.rs` 的 `run.store_limits()` =
  `for_command(&queued.command.context, handle.storage_clock())` 填。**没有新增任何依赖边**
  （`Clock` 走引擎自己的 re-export）。
- `JobOutcome::Cancelled` / `TimedOut` 第一次有生产者：`ApplyFailure.settle` + `fail()` 用它结算。
  `watch_bridge` 与 `processor` 里那两条"映射但没有来源"的分支从此有对应输入。
- **本轮自己长出来的规则**：拒绝只能阻止"开始下一步"，永远不能阻止"记下已经发生了什么"。
  `finalize_apply_persistence` / `mark_apply_reverted` / `mark_apply_recovery_failed` **连 `limits`
  参数都没有**（签名让错的事无法表达）；`advance_apply_phase` 只在
  `recovery::advance_records_touched_world(journal, phase)` 为假时才 obey —— 判据与写记录共用同一个
  `phase_starts_world_effects`，两处不可能各说各话。

## AN2. 一处措辞上的取舍

`describe()` 输出 `deadline=mono 50, cancel=armed, polls=64` / `deadline=unjudged(no clock)`，进
`StoreRefusal.limits`，再进 job 的 `ApiError.detail`。之所以单独设 `unjudged`：把"没有期限"和"有期限但
这里判不了"合并成一个答案，运维就失去了唯一能区分"配置没给时钟"与"调用方没设期限"的线索。这与 `§4.86`
（`Ctx` 不存绝对 deadline）、`§4.74`（`now_source`）是同一条纪律的第三次应用：**派生值的来源必须可见**。

## AN3. 自查三条

- `§4.94`：`is_immediate()` 里我多写了 `&& !self.unjudged`。证伪把这一项删掉，**没有一个测试变红** ——
  因为 `for_command` 永远装一个 token，`cancel.is_none()` 早已是 false，那一项在每个可达状态上都是冗余。
  处置是删掉并在定义处写明为什么只有三条，而不是为了"让它有用"去造一个没有生产者的状态。
- `§4.95`：M14 把 `mark_finished(..., failure.settle)` 改成硬写 `Failed`（cycle 结果仍报 `Cancelled`），
  14 条测试全绿。真相是我的断言只读了 `result.outcome`，没读 job 记录 —— 而 `watch_bridge` / bundle /
  `job follow` 读的是后者。补 `assert_settled_state(...)` 后 M14 立刻变红。**这条变异是我原本打算做又
  嫌"太像"而跳过的那一条**：跳过的那条往往正是没被断言的那条。
- `§4.96`：见 `AN0` 的表。可复用：**给"强制执行 X"写验收标准时，先问"不加夹具，有没有一条测试能让 X
  真的触发"**；没有就写清楚它目前只在接缝语义上成立。同族还有一条本轮顺手做的：
  `limits_that_are_present_and_not_violated_answer_exactly_like_having_none` —— 一个在没违规时会改变
  答案的检查本身就是 bug，10 行断言挡住它。
- `§4.97`：上一轮我往 `caly-io/src/runtime.rs` 的模块文档里写了「23 files, measured」；同一条命令今天读 26
  （把 `runtime.rs` 自己算进去是 27）。没有任何门禁抱怨过 —— 那是注释里的一个数。而我第一版还替它编了
  原因，查下去只对一半（两个新增测试文件确有命中，其余差额没查、也不必查）：**没写口径的计数连「为什么
  变了」都答不出来**。处置是把数字换成带过滤条件的完整命令并自陈会过期。**注释里的数字只有两种安全形态**：
  裁判会核对的（census / 断言 / 门禁输出），或者旁边放着可复制的命令。

## AN4. 结果与规模

```text
$ ./scripts/check.sh
  ok    cargo check --workspace --all-targets is clean
  ok    416 tests passed (floor 416)
  ok    clippy locations at baseline (32)
  note  1685 formatting diff lines remain (tracked, not gating)
  all gates passed
```

新增 15 条断言：`run_limits.rs` 单元 6、`recovery.rs` 单元 3、`tests/ctx_limits_in_apply.rs` 6
（401 + 15 = 416，`regenerate_test_census.py` 自报 `files=54 total=416 rows=54`，门禁自报 `416 tests
passed (floor 416)` —— 两个来源一致才写进来）。规模：209 个 `.rs` / 56,168 行 Rust / 76 个 test target
（56 可执行 + 20 doc-test）/ 20 个成员 / 73 篇 Markdown。clippy 中途漂到 33 一次（测试里一处
`map_err(|text| text)`），改代码回到 32；`CLIPPY_BASELINE` 与 `#[allow]` 都没动。格式化欠账 1,685 未新增。

`TEST_FLOOR` 抬到 416 前照例撕开一次：`FAIL test count fell below the floor: 416 < floor 417`（临时值），
还原后 `sha256sum -c` → `OK`。

**证伪：14 条变异全咬住**（一条一文件、内容 + mtime 还原、sha256 复核、还原后整仓再跑）：

```text
M1 is_immediate always true, so refusals lose their limits line       bit
M2 an absolute deadline is shifted by a second anchoring              bit
M3 no clock becomes a deadline at zero                                bit
M4 a zero poll budget stays zero                                      bit
M5 a timeout is reported as plain congestion                          bit
M6 a backend error borrows the caller's blame                         bit
M7 the retry bit is invented instead of copied                        bit
M8 run_ready_in ignores the limits it is given                        bit
M9 Prepare also counts as touching the world                          bit
M10 the immunity predicate ignores which flags are already set        bit
M11 the handle drops the immunity and always obeys                    bit
M12 phase A stops obeying the caller                                  bit
M13 a cancellation settles as a broken deployment                     bit
M14 fail() ignores the settlement it was handed                        bit
post-restore workspace: green / digest ok: run_limits, recovery, service, worker 均 True
all mutations bit: True
```

这张表是**第三次**跑出来的，前两次的读数才是本轮真正的账：第一次 M1 `NO EFFECT`（`is_immediate` 里那个
合取项在每个可达状态上都是空的，见 `§4.94`）、M2 `MUTATION DID NOT BUILD`（我把元组当迭代器写——变异不
成立等于没跑）、M12 的锚点被上一轮 `rustfmt` 折行吃掉，整只脚本按 assert 停下；第二次 M1 换成真能观察到
的写法后咬住，M14 仍然 `NO EFFECT`，补上 `assert_settled_state`（`§4.95`）才跑成现在这张表。**M6 是唯一一条被既有测试抓住
的**：我把 `retryable` 从"照抄 store 的答案"改成"照我的分类算"，`a_busy_object_store_fails_the_job_without_inventing_state`
当场变红 —— 新字段不是免费adding，它会顶掉别人原本给的答案。

## AN5. 下一步（按优先级）

1. `ADR-036` 第 3 步：`IoBudget` 真记账（`TaskLimits` 今天只有 deadline/cancel 两项），默认值从 unlimited
   收窄（要 release note），并补 `§4.86` 那条仍未测的 `caly-app::remote` 预算转发断言。
2. 第 4 步：`caly-io-std` 有界阻塞池 + `Http` / `Proc`；`BoundedExecutor` 在这一轮才有资格被真正用上
   （它今天仍只被测试触到）。
3. 让 `Ctx` 进到 `StorageBackend` 的签名（`RFC-0007` 层）—— 这是"能打断已开始的调用"唯一的路，需要一份
   新 ADR 或在 `ADR-036` 之后追加决策。
4. `ADR-038 §13.2` idle 自动触发；查询侧是否接限制（策略问题）；`stat_many` / 孤儿内容清扫；
   `caly-cli` 的 `[[bin]]`。

---

# 第二十四轮（2026-08-27/28）：`ADR-036` 第 3 步 —— 预算有了读者，默认值不再是"没有限制"

## AN0. 本轮选什么、为什么，以及为什么先量化"能被观察到什么"

上一轮把命令的 `Ctx` 接到 store 接缝，并在 `AN5` 里把第 3 步排在最前：`IoBudget` 记账 + 默认值从 unlimited
收窄 + 补回第二十一轮欠下的那条 `caly-app::remote` 端到端断言。开工第一件事是把"预算生效"这句话拆开，
因为 `IoBudget` 的两个字段可见性完全不同：

| 维度 | 谁看得见 | 本轮 |
|---|---|---|
| `max_requests`（访问次数） | 引擎：每一次经 `run_ready_in` 的 store 访问都在它手里 | **生效**：在驱动 future 之前扣一次 |
| `max_bytes`（字节数） | 只有 `FsStore` 里面知道，而那一层的签名不带 `Ctx` | **不生效**，写进 ADR/release note，不假装 |

"先数清哪些读数存在"这步决定了整轮的形状：如果我按 `§2.4` 的字面去端口层记账，就得改 `StorageBackend`
签名（`RFC-0007` 冻结过），那是另一次决策。所以本轮的预算落在**能被拒的那一层**，并把落不到的地方写在
同一段话里。

## AN1. 有了什么

- `caly_common::IoBudget`：`default_command()`（`max_requests = Some(64)`、`max_bytes = None`）、
  `DEFAULT_COMMAND_STORE_REQUESTS`、`is_unlimited()`。`RequestContext::new`、`caly_api::default_ctx`、
  `request_map` 的缺省回落**共用这个常量** —— 上一版这三处各写一遍 `unlimited()`，那不是一个默认值，
  是三个巧合。
- `RunLimits` 多一个计费器（`budget` + `billed: Arc<AtomicU32>`，克隆共享：上限属于这次命令执行，不属于
  某个副本）；`recovery::run_ready_in` 在驱动**之前**`charge()`，所以"预算耗尽"的可观察含义是
  **store 一次也没被问**。
- 新拒绝种类 `RefusalKind::BudgetExhausted` → 公开面 `CONFIG_INVALID` + `ErrorCategory::User` +
  `retryable=false`，job 结算 `Failed`（不是 `Cancelled`/`TimedOut`：那是它放弃了，这是它划错了线）。
- 三条 `§2.4` 没写的规则，本轮定下来并各有一条断言：
  ① **只给可以被拒的访问计费**（簿记那几条既不拒也不计）；② **"已计费"= 已尝试**，被预算拒掉的那次要
  把乐观加的 1 减回去，否则重试循环会被自己的拒绝反复抽税；③ **预算门先于取消/期限**（它问的是过去，
  那两个问的是现在），两真取其一的选择必须写下来。
- `describe()` 的预算半句统一成 `<已用>/<上限>`，没设上限也照数（`budget=5/uncapped`）：**"没设上限"与
  "没在数"是两件事**。
- `crates/caly-app/tests/budget_parity.rs`：第二十一轮那条"当时无法诚实断言"的挂账还掉了。
- `docs/IMPLEMENTATION_STATUS.md §6bis` 是本轮的 release note（含"如果你的调用本来想不受限，请显式写
  `IoBudget::unlimited()`"）；`docs/OVERLOAD_AND_RETRY_MODEL.md §3.7` 记了为什么这**不是**一个 overload 类。

## AN2. 一处"没有新码"的取舍

API 层没有 `CAPACITY_EXCEEDED`：`RFC-0002 §14.4` 冻结了稳定码表，加一个码是 RFC 级决定，不由 ADR 代行。
于是端口层 `IoFaultKind::CapacityExceeded`（`RFC-0006 §5.3` 要求的回答形状）与 API 层 `CONFIG_INVALID`
之间有落差。我没有抹平它，而是在 `docs/ERRORS.md §5.1` 的适用例、`OVERLOAD §3.7` 与
`ADR-036 §6bis-sexies` 三处各写一句为什么 —— 一个解释得清的落差比一个凭制造的对称便宜。

## AN3. 自查四条（又是关于我自己的手法）

- `§4.98`：**M9 第一次没咬住。**把 `charge()` 挪到 `drive()` 之后（= store 被问了才说预算不够），14 条测试
  全绿 —— 因为我用的是 `async { 6u8 }`，"跑一次"与"跳过"在我所有读数上一模一样。补了一个会自报 poll
  次数的 fixture（`CountsPolls`）断"被拒的那次一次都没 poll"，M9 立刻变红。**任何以"不做某事"为内容的
  守卫，测试里必须有一个能记录"那件事有没有发生"的观察者。**
- `§4.99`：我用两条 `re.sub` 去折叠两处字符串续行，吃掉了一个 `.expect(...)`；`cargo test` 全绿，是下一句
  `cargo check --all-targets | grep -cE "^warning|^error"` 读出 1 条 `unused_must_use` 才把我拉回来。
  **跨行改写字符串/表达式的正则不允许**；自动改写之后测试还全绿，先怀疑改写吃了内容。
- `§4.100`：本轮中途工具链消失（`~/.rustup/toolchains` 没了），而我连着两条
  `cargo test --workspace 2>&1 | grep -E …` 都返回**空** —— bash 把 `cargo: command not found` 写在自己的
  stderr 上，管道里没有东西 —— 我据此一度认为"没破坏任何东西"。**空输出不是通过，是没有运行**；
  绕过 `scripts/check.sh` 自己拼命令时，它第一行的 `== toolchain` 护栏也不在了。
- `§4.101`：上一轮我把 ADR-036 状态推进到"第 2 步已落地"，改了 `docs/adrs/README.md` 的条目行，却漏了
  同文件表格里那一行（仍写"第 2–4 步未开始"），门禁全绿。**改任何状态前先 `grep -rn "ADR-036" docs/`
  数清住处**：一个事实有几处，编辑就有几处。

## AN4. 结果与规模

```text
$ ./scripts/check.sh
  ok    cargo check --workspace --all-targets is clean
  ok    422 tests passed (floor 422)
  ok    clippy locations at baseline (32)
  note  1685 formatting diff lines remain (tracked, not gating)
  all gates passed
```

新增 6 条断言：`recovery.rs` 单元 4（预算耗尽拒两次都不 poll、未设上限也照数、门先于取消、可不可拒=可不可
计费）、`budget_parity.rs` 2。合计 `422` 由两个来源各报一次：生成器 `files=55 total=422 rows=55`、门禁
`422 tests passed (floor 422)`；`cargo test --workspace --no-run` 报 57 个可执行 + 20 个 doc-test = **77**
个 target。规模：210 个 `.rs` / 56,717 行 Rust / 20 个成员 / 73 篇 Markdown。默认值收窄之后**整个套件仍然
全绿**，这本身就是"64 次够用"的实测读数（我没有另外手写一个"它够用"的断言去替代它）。本轮唯一一次我自己
造出的红是一条 `unused_must_use`（`§4.99`：`cargo check --all-targets` 的 0-warning 口径抓到我只折叠了半个
表达式）；clippy 位置数全程 32，`CLIPPY_BASELINE` 与 `#[allow]` 都没动。格式化欠账 1,685
未新增（本轮 8 个触碰文件都单独跑过 `rustfmt --edition 2021`）。

`TEST_FLOOR` 抬到 422 前照例撕开：`FAIL test count fell below the floor: 422 < floor 423 (a test was
lost; if the removal is deliberate, lower the floor and say why)`，还原后 `sha256sum -c` → `OK`。

**证伪：14 条变异全咬住**（一条一文件、内容 + mtime 还原、sha256 复核、还原后整仓再跑）：

```text
M1 the default stops being bounded                       bit
M2 the client-side default ctx disagrees                 bit
M3 the daemon invents its own fallback again              bit
M4 a command's budget is dropped on the way to the engine bit
M5 the cap is off by one                                 bit
M6 a refusal still eats budget                           bit
M7 the count is hidden when nothing is capped             bit
M8 the refusal stops naming the numbers                   bit
M9 the store is asked before the budget is checked        bit
M10 a spent budget is reported as a storage fault         bit
M11 a spent budget settles like a cancellation            bit
M12 the remote façade drops the budget again              bit
M13 is_unlimited says yes to everything                   bit
M14 the default number is tightened to zero                bit
post-restore workspace: green / digest ok: 7 个文件全 True
all mutations bit: True
```

**M12 是本轮最有价值的一条**：把 `remote.rs` 的 `Some(ctx.io_budget.clone())` 改回 `None`，
`a_spent_budget_refuses_the_apply_the_same_way_over_either_path` 变红 —— "这行看着没人依赖"这个怀疑第一次
有了能跑的答案；第二十一轮记在 §4.86 的那笔挂账到此结清（还的时候连变异一起还，否则"补了断言"
只是话）。M14 则说明：默认值那个数字**只有在被某条断言按字面值使用时**才是政策 —— 悄悄把它改成 0 时，
抓到它的只有那条"默认值必须像明写的 64 一样能跑完 apply"的对比；`request_map` 与门面各自比的是常量
（`Some(DEFAULT_COMMAND_STORE_REQUESTS)`），常量自己变了它们照旧相等。**一个只对常量成立的断言，管不住
常量的值。**

## AN5. 下一步（按优先级）

1. `ADR-036` 第 4 步：`caly-io-std` 有界阻塞池 + `Http` / `Proc` —— 到那里预算才需要进端口层
   （`TaskLimits` 已留位），`max_bytes` 也才有全可见的统计点。
2. `BoundedExecutor` 与 `RunLimits` 的合流：今天计费在引擎的 drive 接缝、执行器仍只被测试触到。第 4 步之后
   要么把引擎切到执行器上，要么在 ADR 里写死"两处各管一层"的理由 —— 现状是可解释的，不许长期含混。
3. 让 `Ctx` 进 `StorageBackend` 签名（`RFC-0007` 层）：这是"能打断已开始的调用"和"字节预算真生效"共用的
   那道门，需要新 ADR 或 `ADR-036` 之后的追加决策。
4. `ADR-038 §13.2` idle 自动触发；查询侧是否接限制；`stat_many` / 孤儿内容清扫；`caly-cli` 的 `[[bin]]`。

---

# 第二十五轮（2026-08-28）：`ADR-038 §13.2` —— 回收器学会自己起身，而起身要先有人在册

## AN0. 本轮选什么、为什么

上一轮把 `ADR-036` 推到第 3 步之后，`ADR-038` 只剩一件事：`§13.2` 的 idle 自动触发。它第 8 节末尾写着
"缺的是策略而非新契约……需要 `Roadmap` 级别的一次讨论，不该塞进一个实现轮次" —— 所以本轮第一件事是**把那次
讨论写下来**（`ADR-038 §9`），第二件事才是实现。授权来源与第十七轮相同（维护者把此类裁决交由此方自行决定）。

先量的还是"这一步能把什么变成可观察"：`RFC-0007 §13.2` 是 **SHOULD**，`would_run` 已经算了 idle 与
pending deployment，删除路径、记录、拒绝理由全都就位 —— 缺的只是"谁在什么时候允许系统自己动数据"。这句话
决定了本轮全部形状：**不新增开关，改用已有的 role-gated 自动化面**。

## AN1. 有了什么

- **打开方式**：`AutomationPatch { job_id: "gc.idle", enabled: true }`，一条 `Role::Admin` 命令。它进
  idempotency、进事件流、进 bundle，所以"允许 daemon 自己动数据"留下一条可归责的记录，而不是配置里一个
  隐身开关。**默认关闭**：没提交过那条命令的部署，行为与本轮之前逐字节相同。
- **cadence 用 idle 检查次数**（`IDLE_GC_INTERVAL_CHECKS = 4`），不是毫秒：本引擎没有可轮询的宿主时钟
  （根 `clippy.toml` 只豁免 `caly-io-std`），而按真实时间调度会让崩溃矩阵失去可复现性。检查点唯一：
  `consume_one_skeleton` 在 `poll_next()` 说"没活了"的那一刻。
- **两个计数器规矩**：① 只在**启用时**前进（未授权期间的计数会把第一次启用变成"立刻就跑"）；② **单调、
  永不重置**，到期判据 `checks % interval == 0`。②不是风格：自动周期的幂等 key 由 `checks` 派生，一个会
  归零的计数器让第二次触发拿到与第一次相同的 key，被 dedup 吞成**重放** —— 收集器从此安静停摆，而
  `last_gc_run` 看着仍然正常。
- **tick 与 cycle 分家**：`idle_gc_tick()` 只 `submit_checked` 一条正常的 `StorageGc` 命令；删除走人工用的
  同一条路径、同一个 `would_run` 门、同一份 sweep 清单。自动化没有自己的删除实现 —— 有一份就有一份会漂移。
- **归属**：`GcRunRecord::triggered_by`（`caller` / `automation:gc.idle`）写进 `summary_line`，`doctor` 的
  note 与 bundle 的 `storage-gc` 段因此同一句。claim 用 **job id 匹配**消费，不是"触发时清标志位"。
- `ROADMAP` 里那句"剩余：GC 的生产接线"改了；`RFC-0007 §13.2` 加了修订注（SHOULD 按"机制存在且可启用"满足）。

## AN2. 一处 DTO 的旧债，和它为什么值得本轮顺手修

`caly_api::GcRunView` 是这份记录的双胞胎 DTO：它有**同一个 `summary_line`**，却**从来没有生产者**
（`grep -rn "GcRunView" crates/` 只有定义与一行 re-export）。也就是说引擎那份加不加 `triggered_by`，DTO 那份
都不会响 —— 哪天有人把它接到 `system.gc-collect` 的答案上，客户端就看到一句没有归属的回收记录，而"谁允许
它删的"正是本轮加这个字段的全部理由。处置：DTO 补同一字段 + 一条把两句话钉死的断言
（`the_record_line_and_the_dto_line_are_one_sentence`）。**"有类型、有渲染、无生产者"在这个仓库是第四次出现**
（`required_role` 第十八轮、`StorageBusy` 第二十轮、`JobOutcome::Cancelled/TimedOut` 第二十三轮，
`§4.102`）—— 没有生产者的代码不会被测到，只会被读到。

## AN3. 自查三条

- `§4.103`：自动收集的第一版测试全红，我读成"gate 没接上"。真相是 fixture 不满足判定条件两次：没
  `set_storage_clock` ⇒ 计划因两条时间线**主动拒绝**；补上时钟后对象年龄=0 ⇒ 还在默认 15 分钟 grace 内。
  把我拉出来的是同一批测试里那条**人工对照**（同 fixture、人工提交收集，它成功删了东西）—— 有它才能把
  "世界不具备条件"与"自动化没接上"分开。
- `§4.104`：一条 `fired_at % INTERVAL == 0` 红了，报 9。代码没错，是我把读数取在循环结束之后。同族还有一次：
  我按"5 次 drain = 5 次检查"算了个不存在的余量。**关于"何时"的断言要在"何时"读**，或者干脆把驱动写成
  不变式循环（`while checks % INTERVAL != 0 { … }`）。
- `§4.104` 的补记（同一族第三次，最贵的一次）：**M6 连跑两次都没咬**。我先后加了"记录必须更新""必须多一个
  job 行"，两次都被溜过 —— 因为计数器一重置，**触发点自己也跟着移动**，固定长度的 drain 循环恰好让两次触发
  落在不同的检查号上，key 自然不撞。第三次把两次触发钉死（`interval - 1` 与 `interval` 次 drain）才立刻变红。
  **"证明两个东西不一样"的测试，必须自己控制这两个东西的位置**；把位置交给循环次数，等于让被变异的对象决定
  证人站在哪里。

## AN4. 结果与规模

```text
$ ./scripts/check.sh
  ok    cargo check --workspace --all-targets is clean
  ok    434 tests passed (floor 434)
  ok    clippy locations at baseline (32)
  note  1685 formatting diff lines remain (tracked, not gating)
  all gates passed
```

新增 12 条断言：`gc_plan.rs` 单元 5（due 判据、四种拒绝理由各占一位、顺序本身、key 全程序唯一、两句话相同）、
`service.rs` 单元 1（claim 按 job id 匹配的两个方向）、`tests/idle_gc_automation.rs` 6。合计由两个来源各报一次：
`regenerate_test_census.py` 自报 `files=57 total=434 rows=57`，门禁自报 `434 tests passed (floor 434)`。
规模：211 个 `.rs` / 57,602 行 Rust / 78 个 test target（58 可执行 + 20 doc-test）/ 20 个成员 / 73 篇 Markdown。
clippy 中途漂到 35 再落到 33，两处都改代码修掉：三条 `manual_is_multiple_of`（`checks % N == 0` 现在该写
`checks.is_multiple_of(N)`）与一条 `explicit_auto_deref`（`&*clock`）。**新 lint 不会因为"基线里别人也这样写"
而豁免你 —— 基线只保护存量，所以每次都要让门禁跑在自己改的代码上。**`CLIPPY_BASELINE` 与 `#[allow]` 都没动；
另有一条 `assertions_on_constants` 风险被我直接删掉了那条测试：对一个常量 `assert` 不产生任何信息，
`const _: () = assert!(…)` 才是它的正确位置。格式化欠账 1,685
未新增。`TEST_FLOOR` 抬到 434 前照例撕开一次，还原后 `sha256sum -c` → `OK`。

**证伪：11 条变异全咬住**（一条一文件、内容 + mtime 还原、sha256 复核、还原后整仓再跑）：

```text
M1 due-ness is off by one check                      bit
M2 enablement stops mattering to the decision         bit
M3 an empty store still earns a cycle                bit
M4 the reason order is chosen for brevity             bit
M5 idle checks are counted while unauthorised         bit
M6 the cadence counter resets on fire                 bit
M7 the schedule forgets which job it belongs to       bit
M8 the label is a flag to clear, not an id to match   bit
M10 the engine's refused line drops the attribution    bit
M11 the DTO's refused line drifts from the record's   bit
M12 the two trigger strings are swapped                bit
post-restore workspace: green / digest ok: gc_plan, service, worker, dto 均 True
all mutations bit: True
```

**有一条性质本轮决定不写测试，并把它记下来**：`M9`（把 tick 从"队列为空"那一支挪走）跑出来不改变任何可观察
行为 —— 因为计划自己会因 `work_in_flight != 0` 判 non-idle 而拒绝排队。**两道独立防线让单点变异不可测**，
这不是断言缺口；写在这里是为了不让下一个读者以为漏了什么（`ADR-038 §9` 的证伪小节同句）。编号跳过 M9 也是
同一件事的记法。

## AN5. 下一步（按优先级）

1. `ADR-036` 第 4 步：`caly-io-std` 有界阻塞池 + `Http` / `Proc`；预算的字节维度与 `BoundedExecutor` 的生产
   调用点都在那一步（`max_bytes` 今天不生效，是**写明**的不生效）。
2. `BoundedExecutor` 与 `RunLimits` 的合流：idle 收集走的仍是 `run_ready`（既不被告绝也不计费）。要么把引擎
   切到执行器上，要么在 ADR 里写死两处各管一层。
3. 把 `Ctx` 送进 `StorageBackend` 签名（`RFC-0007` 层）：这是"打断已开始的调用"与"字节预算真生效"共用的门。
4. 查询侧是否接限制；`stat_many` / 孤儿内容清扫；`caly-cli` 的 `[[bin]]`（`caly-daemon` 也没有 bin，真机
   组装根仍缺 —— `clock-timeline` 那条缺口因此还在）；`caly_api::GcRunView` 要么接上生产者要么删除。

---

# 第二十六轮（2026-08-28）：`ADR-036 §2.5` —— 探针的时限终于有人读，以及一句重复的话终于有两条路可走

## AN0. 本轮选什么、为什么

`ADR-036 §1` 那张"传下去但没人读"的表是这份 ADR 的立项依据，五个字段里第 0–3 步已经收掉四个，最后一个是
`Probe { deadline_ms }`："值存在于计划里、出现在日志里，`SimulatedRuntime` 只把它打印出来"。第 4 步
（`caly-io-std` 阻塞池 + `Http`/`Proc`）是另一量级的事，而这一行是**同一句话的最后一格**，所以先把它做掉：
`§1` 的表格如果留着一行"没人读"，这份 ADR 的说法就还是修辞。

同一轮把第二十五轮自己点名的另一件事办了：`caly_api::GcRunView` "要么接上生产者要么删" —— 接上了，
于是那句"两个渲染器必须同一句话"从预防性变成真的在守一条路径。

## AN1. 有了什么

- `StepEvidence` 多一个 `elapsed_ms`，`merge` 时取 **max**。**运行时报告耗时，执行器判定是否超限** ——
  这个分工是本轮的全部要点：判定写进每个适配器，就等于每个适配器都有一次忘记它的机会（`caly-core` 的 mock、
  `mihomo`、`singbox` 各有各的探针路径），而这个字段当初正是这么退成交代的。
- 超限 = **验证失败**，走 `ADR-016` 既有的"没有通过的探针就不许提交"分支：`probe_passed` 保持假，快照不标、
  修订不提交；不新增 `ExecutionStatus` 变体（`§2.5` 明确这么要求）。
- 边界是 `elapsed <= deadline` 放行：用了刚好等于预算的时间不算超时。差一格就变成"因为你花了我给你的时间而拒绝你"。
- `deadline_ms == 0` 在 `validate_effect_plan` 阶段拒（`validate_probe_deadlines`，**不受
  `enforce_phase_order` 影响**）。两种省事读法都不行：当"无限制"= 让缺省值关掉门禁；当"零时间"= 让每个这种
  计划必然失败。与 `ADR-038 §2` 拒 `max_deletions: Some(0)` 同形 —— 越界的上限是策略问题，缺失的上限是计划缺陷。
- `SimulatedRuntime::make_next_probe_slow(ms)`：**一次性**的世界模型（与 `fail_next_probe` 同理）。真实适配器
  该用注入的 `Clock` 量出来；执行器自己没有时钟，也不该有（`§6bis.1`、`§4.86`）。
- `system.gc-plan` 的答案带 `last_run: Option<GcRunView>`：`None`（本进程没跑过）与 `Some(deleted = 0)`
  （跑过、无事可做）在**客户端侧**也分开了；`gc_run_view` 逐字段映射，`GcPlanView::summary_line()` 直接**引用**
  DTO 那句渲染而不是另写一遍。

## AN2. 一处"这会改变行为"的说明

过去"探针没写预算"的计划能通过校验（0 没人读）；现在它在碰任何运行时之前被拒。本仓三个适配器给的都一直是
正数（`deadline_ms: 3_000`），所以没有既有调用方受影响 —— 但这是一次真实的收紧，已写进
`IMPLEMENTATION_STATUS §6bis` 的行为变更段（release note 那一节），不是"内部重构"。

## AN3. 自查：`§4.105`（同一族第五次、第六次）

- **说了没做**：我准备在总结里写"两处补记已应用"，落笔前按 `§4.101` 的习惯 grep 了一下要引的句子 ——
  **两处都是 0 次命中**。那两个 edit 我只写了脚本、没有跑（当时执行的是另一份修复脚本）。没有编译错误、
  没有门禁失败，因为"少了一段散文"不会让任何东西变红。
- **自数的合计**：我在文档里写了 `446` 与"新增 12 条"，而两个裁判早就各自给出 `447`/`+13`。我算的是
  434 + 4 + 6 + 3 = 447，写下来是 446 —— 因为先按"探针文件 5 条"算过一版，后来加了第 6 条测试，
  **改了代码没回头改脑中的算式**。
- 落地成硬规定：① 文档里每一句"已改 X"，落笔前先 grep X 那句话，命中数不是 1 就是没做；② **不写自己算
  出来的合计**，总数只抄门禁与生成器的读数，不一致就停手；③ 写完再跑一次 `check.sh`（这次它把
  `TEST_FLOOR=446` 和实测 447 并排摆着）。

## AN4. 结果与规模

```text
$ ./scripts/check.sh
  ok    cargo check --workspace --all-targets is clean
  ok    450 tests passed (floor 450)
  ok    clippy locations at baseline (32)
  note  1685 formatting diff lines remain (tracked, not gating)
  all gates passed
```

新增 16 条断言：`executor.rs` 单元 4、`tests/probe_deadline_gate.rs` 6、`caly-daemon/tests/gc_run_view.rs` 3、
`caly-arch-test/src/docs.rs` 单元 3（`AN7` 那个新门禁自带）。两个来源各报一次：生成器
`files=59 total=450 rows=59`、门禁 `450 tests passed (floor 450)`。规模：213 个 `.rs` / 58,467 行 Rust /
80 个 test target（60 可执行 + 20 doc-test）/ 20 个成员 / 73 篇 Markdown。
`TEST_FLOOR` 抬到 450 前照例撕开：`FAIL test count fell below the floor: 450 < floor 451 (a test was lost;
if the removal is deliberate, lower the floor and say why)`，还原后 `sha256sum -c` → `OK`。clippy 与
格式化欠账都没动（32 / 1,685；本轮 8 个触碰文件单独跑过 `rustfmt --edition 2021` —— 其中
`caly-arch-test/src/docs.rs` 是写完新门禁后才格式化，一度把欠账顶到 1,709，又拉回来）。

**证伪：9 条变异全咬住**（一条一文件、内容 + mtime 还原、sha256 复核、还原后整仓再跑）：

```text
M1 the boundary is strict, so a full budget fails      bit
M2 the deadline is printed but not enforced             bit
M3 the plan check follows the phase-order flag          bit
M4 merged evidence keeps the last duration             bit
M5 the scripted delay stays armed for every probe       bit
M6 the probe reports no duration at all                bit
M7 the mapper drops the attribution field              bit
M8 the plan answer never carries the last run          bit
M9 the client's line paraphrases instead of quoting     bit
post-restore workspace: green / digest ok: executor, sim, api, daemon 均 True
all mutations bit: True
```

写变异清单时先遇到一次自我修正：M5 的第一版断言（"第一个探针超时，执行停在它那里"）**测不出一性**，因为
执行在第一步就返回，"第二个探针是否也被延迟连坐"根本没机会被观察。改成"第一个探针慢但在预算内、第二个预算紧"
之后，延迟泄漏会立刻让第二个探针超时 ⇒ 红。这与 `§4.98`（守卫必须有计数者）、`§4.104`（把触发点钉死）
是同一条：**先问"这条变异若成立，哪个读数会变"**，答不出就是断言还没长在分支上。

## AN5. 下一步（按优先级）

1. `ADR-036` 第 4 步：`caly-io-std` 有界阻塞池 + `Http` / `Proc` —— 字节预算（`max_bytes`）到那里才有
   全可见的统计点，`BoundedExecutor` 也才有生产调用者。
2. `BoundedExecutor` 与 `RunLimits` 的合流（两处各管一层，还是把引擎切到执行器上）—— 现状可解释，不许长期含混。
3. 把 `Ctx` 送进 `StorageBackend` 签名（`RFC-0007` 层）："能打断已开始的调用"与"字节预算真生效"共用这道门。
4. `ADR-038 §6.2` 的 cutover 存储争用模型；查询侧是否接限制；`stat_many` / 孤儿内容清扫；
   `caly-daemon` / `caly-cli` 的 `[[bin]]`（真机组装根仍缺，`clock-timeline` 缺口因此还在）。
   （第二十七轮注：这一格里 `§6.2` 的文件名写错了 —— ADR-038 没有 §6.2，锚点是
   `docs/OVERLOAD_AND_RETRY_MODEL.md §6.2`（`ONBOARDING_NOTES §4.107`）；同一轮它已经落地，见下面第二十七轮。）

## AN6. 收尾：一个 DTO 字段把两个没碰过的文件顶过了 clippy 阈值（`§4.106`）

加完 `GcPlanView.last_run` 之后编译干净、447 条测试全绿，而 `check.sh` 报 `clippy locations grew: 34 > baseline 32` ——
两条新告警在 `caly-ipc/src/frame.rs` 与 `client_loop.rs`：`ServerFrame::Response(ResponseEnvelope)` 被顶到
424 字节，越过 `large_size_difference_between_variants`。原因是尺寸链
`ResponseEnvelope → OperationResult → GcPlanView → GcRunView`：在最外层加 150 字节，物理上发生在传输层枚举里。

处置按仓库既有先例（`ApplyFailure.error: Box<ApiError>`）：字段改成 `Option<Box<GcRunView>>`（+8 而非 +150），
使用方几乎无感（`Box` 自动 deref，`expect`/`clone`/逐字段比较都不用动），clippy 回到 32。**没有抬基线、没有加
`#[allow]`**，并把这个"为什么是 Box"写进 DTO 的字段注释，免得下一个人当成随手装箱把它拆回去。

值得留的那句：**编译通过也不是证据**。尺寸、变体比例这类后果不在类型检查的射程里，只在门禁的射程里 ——
所以 `check.sh` 要跑在改动之后，而不是"我记得我只动了一个 DTO"之后。

## AN7. 收尾之二：把这个毛病本身做成门禁（`check_disposition_ledger`）

写 `§4.106` 之前我核对处置表编号，发现自己在上一小节把标题从 `### 6.59` 抬到了 `### 6.60`，而表里最后一行仍是
`6.58` —— 因为本轮我把两条留档**并进了同一行**（一行对一轮），却顺手把标题的号也推了一格。两处都是合法
markdown：`check_heading_numbers` 只管"同一个号出现两次"，`check_stray_table_rows` 只管"行被粘进段落"，
**没有一条门禁管"处置表与它的收尾标题编号是否接得上"**，而这恰恰是这个文件历史上第五次出问题的地方
（`§4.78` / `§4.89` / `§4.90` / 第二十一轮的两处 / 本轮）。

所以本轮最后加了 `caly_arch_test::docs::check_disposition_ledger`：行号必须从 1 连续无重复，`明确**不做**`
那个标题必须正好是最后一行 +1，围栏内的例子一律不看（`§4.89` 的教训：自动化曾把散文里的一个代码片段当成表行）。
它自带 3 条单元测试，并且**立刻咬住两处变异**（把连续性检查的区间写空 → `a_gap_in_the_disposition_ledger_is_reported`
变红；把"必须等于 max+1"改成"只要存在" → `the_not_doing_heading_has_to_be_the_next_number` 变红）。

值得记的是顺序：我先犯了那个错，再把它变成门禁 —— 这个仓库的门禁几乎全都是这个形状来的。**能靠人记住的
约定，最后都会变成一次红；早一点让它变成断言，下一个读者就不用重演我这一轮。**
# 第二十七轮（2026-08-28）：`APPLY_EXECUTION_CENTERLINE §6.1` Phase B —— cutover 窗口先记账，后动手

## AN0. 本轮选什么、为什么

`ADR-036 §5` 的四步里，第 4 步（`caly-io-std` 阻塞池 + `Http` / `Proc`）是另一量级的事，而它前面还留着一句
没做完的话：`§2.6` 说「在没有该线程池之前，`StdFs` 允许继续同步且立即 ready，但 `block_on_ready` 的
"只 poll 一次"必须升级为"在 `Deadline` 内轮询到 ready"」。第 23 轮把后半（`run_ready_in`）做了，前半留到
本轮 —— 但本轮真正的靶子不是它，而是它背后那条被写了三遍、从来没人能证伪的要求：

> `APPLY_EXECUTION_CENTERLINE.md §6.1` Phase B：必须有 journal pending guard / 必须定义明确顺序 /
> **必须允许 crash recovery 识别执行到哪一步**

开工前先量一次现状（不是推测）：给 `EngineHandle::put_apply_journal` 临时加一行 `eprintln!`，跑
`cargo test -p caly-engine --test storage_backend_swap -- --nocapture`，真实 apply 在执行期间只打出**一条**：

```text
PROBE27 put_apply_journal phase=Finalize cursor=8 net=true cutover=true state=Committed
```

也就是说 8 步计划（实测 phases = `[Prepare, Prepare, Cutover, Cutover, Finalize ×4]`）里，"cutover 发生过"
这件事是在 cutover **结束之后**才落盘的。于是第三句要求今天不成立：进程死在第 3 步与活到第 8 步之后被 kill，
在 store 里长得一模一样，都是 `pending/prepare`。`STORAGE_RECOVERY_EXECUTION_PLAN §7.3` 的第 3 步据此丢弃事务、
"保留现状" —— 而现状可能已经被换了核心。这一格是本轮的靶子。

`OVERLOAD_AND_RETRY_MODEL §6.2` 的三条要求（"不得简单提示稍后再试"/"必须进入 recovery-aware 失败路径"/
"job follow 要看到是执行失败不是验证失败"）从第十三轮起挂在未覆盖清单里，缺的正是同一个承载体：
先有"游标在执行中被写"这件事，才谈得上"游标写不下去时怎么办"。

## AN1. 有了什么

- `caly_engine::executor::EffectCursor`：一条方法 `record_intent(phase, step_index) -> Result<(), CursorRefusal>`。
  `execute_effect_plan_with_cursor` 在执行**任何** `Cutover` 相步骤之前问一次；被拒 ⇒ 那一步记成
  `StepSkip::Gate { reason: "journal-intent-refused" }`、走 `finish_with_failure`（于是窗口已开就是 `RolledBack`，
  窗口没开就是 `FailedBeforeCutover`，两者不同）。`execute_effect_plan` 保留旧签名，委托给
  `&mut NoCursor` —— 有一条断言逐字段比较两者相等，用来证明本轮是**加了一层**而不是改了一层。
- `needs_intent_record(phase)`：只管 `Cutover`。为什么 `Prepare` 不要（可安全重做）、`Finalize` 不要
  （那些步骤本身就是持久化动作，失败早有 `mark_apply_recovery_failed` 这条升级路）写在谓词的文档里，
  并且配一个 `const _: () = assert!(..)`：顺手把谓词扩大一点，编译期就要先回答"为什么"。
- **没有** step-done 回调：下一条意图记录必然涵盖上一条的完成，窗口末位归计划结束时的 fold。这条"少写一半"
  的选择不是省事的说法，它让"每步恰好一条"变成可断言的数字（`a_real_apply_writes_the_cutover_window_into_the_store_as_it_goes`
  数的正是它，多写一条就红）。
- `worker.rs::JournalIntentCursor`：sink 走既有的 `EngineHandle::advance_apply_phase`，并**链住自己那份 journal
  副本** —— 于是 `advance_records_touched_world` 在第一条之后自然转假：窗口第一条记录既不可被拒也不计费，
  其余各条可被拒（也就计费）。同一规则细到步级，没有引入第二个开关。
- `CursorRefusal { kind, message, retryable, caller_side }`：由 `StoreRefusal` 转换。`caller_side` 是从
  `is_caller_side()` 抄的，因为转换会消耗掉原对象 —— 这是本轮唯一一次"为了不发明值而多带一个字段"。
- `StoreRefusal::from_storage_error`：store 自己说 `StorageErrorKind::Busy` 才升级成新的
  `RefusalKind::StorageBusy`，其余九种一律留作 `Backend`（一条断言钉住"只升一种"，一条钉住"store 原文逐字带出"）。
  这不是美化分类：`doctor` 的过载计数只认这个类别，而 `Ctx` 进不了 `StorageBackend` 签名（`RFC-0007` 冻着），
  store 自己的 `Busy` 是这一层唯一还能拿到的诚实信号。
- `EngineHandle::record_storage_contention` + `OverloadReport::journal_pressure`：mid-apply 的存储争用因此进了
  `doctor` / bundle 共用的过载计数，hint 是 `ManualIntervention`；`OverloadReport::detail()` 是从 `to_api_error`
  里**抽出来**的一份拼写，调用方的 `detail` 与运维的那行共用它 —— `§4.59` 那个教训的第二次偿还。
- `worker.rs` 的两张共享表：`settle_for_refusal`（kind → `Failed` / `Cancelled` / `TimedOut`）与
  `public_shape_for_refusal`（kind → `STORAGE` + `Io`，仅 `CONFIG_INVALID` 留给调用方自己的预算）。
  持久化接缝与 guard 接缝此前各写一份；两份就是下一次分歧。

## AN2. 一处"这会改变行为"的说明

1. **成本**：cutover 相每一步多一条 journal 写（默认 profile 实测 2 条）。`FsStore` 的 journal 写是 D3，
   所以这是真实的 fsync 次数。`§6.1` 把 pending guard 写在要求里，本仓库选择不逃这笔账；将来要收，
   得由一条新 ADR 明确改成"整窗一条"并说清丢了逐步精度。
2. **运维分类会变**：同一个"cutover 中途被 kill"的现场，以前扫描判"没动过 ⇒ 丢弃 pending"，现在判
   `cutover_started=true` ⇒ 走 `§7.3` 第 4 步（优先回 last-known-good，回不去标 `RecoveryFailed`）。
   这条已经写进 `IMPLEMENTATION_STATUS §6bis` 的第二十七轮追加段，因为它对读文档的人是行为变更而不是好消息。
3. **收紧**：`run_apply` 现在一次构造 `RunLimits` 交给两个有界接缝。此前每接缝各调一次 `run.store_limits()`，
   而 `for_command` 每次都新建 `billed: Arc::new(0)` —— "一条命令 64 次访问"实际是"每接缝 64 次"。默认值下
   没人撞上，所以它活了四轮。显式把 `max_requests` 设成个位数的调用方会比过去更早被拒。
4. **安全停点的语义**：调用方的期限/取消在窗口内被拒 ⇒ 停在步与步之间并**走补偿**，即"取消一次 apply 得到
   一次回滚"，不会得到半套部署；`finalize` / `mark_apply_reverted` / `mark_apply_recovery_failed` 仍然没有
   `limits` 参数（签名让"拒绝记录"无法表达，第 23 轮那条规则原样管用）。

## AN3. 自查：本轮抓到我自己三句不实的话

- **一句错引在满仓抄**（`§4.107`）：第二十六轮我写「`ADR-038 §6.2` 的 cutover 存储争用模型」，而 ADR-038
  根本没有 §6.2 —— 锚点是 `docs/OVERLOAD_AND_RETRY_MODEL.md §6.2`。grep 一下节号就露馅，可没有门禁管节号：
  `every_documented_path_reference_resolves` 只查文件存在。已统一改成带文件名的引用，并在 ADR-038 `§8`
  那节标题里补上文件名（歧义的源头）。
- **一句「已接线」活了四轮**（`§4.108`）：`ADR-036 §6bis-quinque` 写着「`advance_apply_phase` 由 `worker.rs` 用
  `run.store_limits()` 填」。`grep -rn "advance_apply_phase" --include=*.rs crates/` 的答复是：只有
  `caly-daemon/src/app.rs:647`（`seed_recovery_fixture`，一个模拟崩溃现场的夹具）与四个测试文件，worker 一次都没有。
  那句话描述的是"接缝备好了"，读起来却是"生产已经在用"——**不能被一条 grep 复现的"已接线"就是叙事**。
  本轮把它变成真的；原句保留，并在那一段下面追加更正，因为"当初为什么会这样以为"本身是要留的东西。
- **一处共享只在第二个使用者出现时才成为性质**（`§4.109`）：`RunLimits` 的注释一直写着"上限属于这次命令执行，
  而不是某个副本"，可第 23 轮只有一个有界接缝，没有第二个使用者去检验它。给游标接缝加限制是**唯一**能让这句话
  变成可证伪的机会，本轮它当场抓出"每接缝各数一遍"。教训写进 `§4.109`：共享状态要在第二个使用者出现的那一轮
  补一条跨使用者断言。
- 还有三条工具层的：手工夹具必须先过自己声明的门禁（`§4.110`，本轮两条断言第一遍就红，两次都是夹具）；
  在同一列上追加写之后"这一列仍然单调"要重新证明（`§4.111`，`updated_at` 的次序本轮从推导改成断言）。
- 最后一条是收尾时自己栽的（`§4.113`）：为了数 test target 而照文档配方 `touch` 了全仓 `.rs`，于是本来打算用来复核「本轮只改了这些文件」的 `find -newermt` 一下变成了 210 多个文件。清单最后是靠编辑记录与两处 sha256 复核对上的 —— 取证之前先给信号拍照。

## AN4. 结果与规模

```text
$ ./scripts/check.sh
  ok    cargo check --workspace --all-targets is clean
== tests
  ok    463 tests passed (floor 463)
== clippy (ratchet on distinct source locations)
  ok    clippy locations at baseline (32)
== formatting (advisory until the repo-wide rustfmt commit lands)
  note  1685 formatting diff lines remain (tracked, not gating)
== result
  all gates passed
```

新增 13 条断言：`crates/caly-engine/tests/cutover_intent_guard.rs` 11（执行器层 5 + worker 层 6）、
`crates/caly-engine/src/run_limits.rs` 单元 1、`crates/caly-arch-test/tests/dependency_direction.rs` 门禁 1。
两个来源各报一次：生成器 `files=60 total=463 rows=60`、门禁 `463 tests passed (floor 463)`（450 → 463）。
规模：214 个 `.rs` / 60,064 行 Rust / 81 个 test target（61 可执行 + 20 doc-test，实测口径：
`cargo test --workspace --no-run` 自报 `Executable unittests` 20 行 + `Executable tests/` 41 行）/
20 个成员 / 73 篇 Markdown（本轮没有新增文档文件）。`executor.rs` 1,386 行、`worker.rs` 1,265 行、
`run_limits.rs` 563 行。
`TEST_FLOOR` 抬到 463 前照例撕开：`FAIL test count fell below the floor: 463 < floor 464 (a test was lost;
if the removal is deliberate, lower the floor and say why)`，还原后 `sha256sum -c` → `scripts/check.sh: OK`。
clippy 与格式化欠账都没动（32 / 1,685；本轮 7 个触碰文件全部单独跑过 `rustfmt --edition 2021`）。
`check.sh` 连跑两次输出逐字节相同，`regenerate_test_census.py --check` 退出码 0，工作树里没有 `.bak` 残留。

## AN5. 下一步（按优先级）

1. `ADR-036` 第 4 步：`caly-io-std` 有界阻塞池 + `Http` / `Proc` —— 字节预算（`max_bytes`）到那里才有全可见的
   统计点，`BoundedExecutor` 也才有生产调用者。（`Proc` 那一半还另有一道闸：`crates/caly-io-std/clippy.toml`
   明写 spawn 属 Platform、`std::process::Command::new` 在本仓**所有** crate 里都是禁用符号，本轮复核过。）
2. `BoundedExecutor` 与 `RunLimits` 的合流：本轮之后引擎有**两个**有界接缝共用一份 limits，而执行器仍然
   只在测试里被调用 —— 现状可解释，不许长期含混。
3. 把 `Ctx` 送进 `StorageBackend` 签名（`RFC-0007` 层）："能打断已开始的调用"与"字节预算真生效"共用这道门。
   本轮的 guard 让"步与步之间"成为安全停点，但一步**之内**依旧不可打断。
4. 查询侧是否接限制；`stat_many` / 孤儿内容清扫；`caly-daemon` / `caly-cli` 的 `[[bin]]`（真机组装根仍缺，
   `clock-timeline` 缺口因此还在）。

## AN6. 证伪：13 条变异，其中一条因不编译而作废重跑（`§4.112`）

```text
M1  the guard is compiled out                                  bit
M2  the guard also fires for finalize steps                    bit
M3  the record names the step before the one starting          bit
M4  the cursor does not chain its journal                      bit
M5  the cutover seam rebuilds its own limits                   bit
M6  a caller-side refusal settles as Failed anyway             bit
M7  the guard's refusal folded into the generic failure        bit（第一版不编译，作废重跑后才算）
M8  the public detail stops quoting the operator's report      bit
M9  the store's own Busy answer is never promoted              bit
M10 every refusal inflates the operator's pressure tally       bit
M11 the mid-cutover hint is downgraded to "retry later"        bit
M12 the detail() extraction loses the generation               bit
M13 a second apply seam skips the cursor (gate-only witness)   bit
post-restore workspace: green / digest ok: executor, worker, run_limits, service, overload 均 True
all mutations bit: True
```

M7 的第一版把 `if let Some(refusal) = cursor.refusal.clone() {` 改成 `if cursor.refusal.is_some() && false {`：
条件恒假了，但 `if let` 的绑定也没了 ⇒ `E0425` ⇒ harness 记成 `MUTATION DID NOT BUILD`，那一格**什么都不能证明**。
换成保住绑定与类型的等价式 `cursor.refusal.clone().filter(|_| false)` 重跑：三条预期断言全红，另外还红了
`the_callers_budget_bounds_the_cutover_window_too`（说明这个分支同时是两条性质的裁判）。
"harness 把『没编译』与『没咬住』分开报"是第七轮立的规矩，本轮是它第一次真的救我 —— 否则这条会被我记成通过。

## AN7. 收尾：一条只有门禁看得见的变异

M13 是这样设计的：在 `worker.rs` 里加一个**行为完全不变**的多余调用 ——
`let _spare = crate::executor::execute_effect_plan(plan, ..., &policy);`（无游标的那一个）。
整仓 463 条测试全绿，因为多跑一次纯函数不改任何后果；唯一红的是新加的门禁
`production_code_drives_effect_plans_through_the_cursor_entry_point`（扫 `crates/*/src/**`，禁 `execute_effect_plan(`
调用，注释行与 `caly-engine/src/executor.rs` 自己豁免）。

这条变异是本轮最想说的一件事：**guard 的价值不在它今天生效，而在下一个接缝不能悄悄不接它**。一个"多一条接缝"
的改动，测试是抓不住的 —— 它没有让任何现有断言变假。能被测出来的性质才算性质，所以这一族的规矩（本轮第二次用）
是：每次把某件事变成不变量，就顺手回答"什么改动会让它失效而测试全绿"，答出来就把它做成门禁，答不出来就写进文档
当作已知缺口（`ADR-036 §6bis-octies` 的"还没有的"那节就是答不出时写的）。

# 第二十八轮（2026-08-28）：`ADR-036 §2.6` 前半 —— 落盘 store 不再把"端口还没好"说成"存储坏了"

## AN0. 本轮选什么、为什么

上一轮收尾时我把第 4 步（`caly-io-std` 阻塞池 + `Http` / `Proc`）列为下一件事。开工前先读那一层的现状，
撞见一个 3 行函数：

```rust
fn suspension(message: String) -> StorageError {
    StorageError::new(StorageErrorKind::Internal, message)
}
```

它是 `§2.6` 那句"以免新后端一挂起就报内部错误"所**防**的事的实现：`FsStore` 用 `caly_io::block_on_ready`
驱动端口（一次 poll），任何 `Pending` 从这里出来都被贴上 `Internal`。而 `caly_io::drive` 给出的其实是
`IoFaultKind::Busy` + `retryable=true` + `transient=true` + 一句写着用了多少 poll 的文本 —— 也就是说
**类型信息在端口层是存在的，被 store 这一层抹掉了**。

抹掉的代价不在文案里，在上一层：第二十七轮加的 `StoreRefusal::from_storage_error` 只认 `Busy`，
把它升级成 `RefusalKind::StorageBusy`，而 `doctor` 的过载账本、`OVERLOAD_AND_RETRY_MODEL §3.4` 的类别、
"重试一下还是去修盘"的判断全挂在这个位上。喂 `Internal`，它只能报 `Backend`：于是"盘忙"与"记录坏了"
在公开错误、remediation 和运维账本上是同一件事，而**没有任何测试会红**。

第 4 步本身因此是被这一格挡着的（阻塞池的 future 天生会挂起；真 `Http` 也一样）。所以本轮做这一格，
并且只做得起的那一半。

## AN1. 有了什么

- `crates/caly-storage/src/port_drive.rs`（86 行，新）：`STORE_PORT_POLL_BUDGET = 64`，两条编译期锚点 ——
  `> 0`（零预算是把每次访问都拒掉，那不是限制是停机）与 **`>= 2`**（"一次 poll 的预算"就是旧行为披个名字，
  锚点让这条路走不通）；`drive_port(future)` 调 `caly_io::drive`（生产里唯一的 poll 循环，`Waker::noop`
  命中数仍是 1），把**驱动器自己的**拒绝走 `from_iofault` 这张表。
- `from_iofault` 从 `fs_store.rs` **移**过来而不是复制：它现在有两个使用者，而"一个事实两处拼写"是
  `§4.81` 记过的形状。
- `fs_store.rs` 的 8 个驱动点 + `schema.rs` 的 4 个全改走 `drive_port`；`suspension()` 删除。顺带消灭了
  `exists()` 里那处自己手写的 `Internal` 映射 —— 同一个事实第三种拼写。
- 端口层多了一种**形状**：`caly-io-sim` 原来只有 `hang`（永不就绪）。本轮加 `stall(label, polls)`
  （一次性、可数的挂起），并且 `SimFs::write_atomic` 从此也认 `hang` / `stall`（以前只有 `read` 认）——
  写路径才是真 fsync 住的地方。
- 门禁 `the_durable_store_drives_ports_through_the_shared_budget`：`crates/caly-storage/src/**` 不许出现
  `block_on_ready(`，注释行除外；唯一豁免 `audit.rs`，豁免理由写在门禁里（它驱动 `dyn StorageBackend`
  的 future，那里已经是类型化 `StorageError`，没有端口层的类型可丢）；另附一条"扫到的文件数 ≥ 8"的
  反空转断言，免得目录一改，门禁悄悄变成扫 0 个文件。

## AN2. 三条 `§2.6` 没写死的判断

1. **预算数 poll，不数毫秒。** 判期限要有时钟，而这一层没有也不该有（`clippy.toml` 禁宿主时钟，`§4.86`
   说只有拿时钟的那一层能判时间）；更根本的是**今天没有任何东西值得等**：所有真实端口在第一次 poll 里就
   把活干完了。把 `BoundedExecutor` 那套 `Advance::StepMillis` 搬下来，等于在没有事件可等的时候烧 CPU
   装作在等。等一个真正的完成事件，是第 4 步阻塞池的事 —— 那时这个预算才长出期限，且期限来自注入的
   `Clock`。所以 `§2.6` 那句"在 `Deadline` 内轮询到 ready"本轮只落了前半，后半**写在 ADR 里而不是糊过去**。
2. **超预算报 `Busy`，不报 `Timeout`。** 没有时钟说时间到过，就不能说时间到了；驱动器原文
   （`still pending after 64 poll(s)`）逐字带出，因为它同时是"用了多少"和"上限是多少"两个数。
3. **不做 per-store 可配的预算。** 一开始想加 `FsStore::with_port_drive(...)`，自己否了：`open` 里的迁移
   路径（`schema.rs`）够不着那个旋钮，而够不着的旋钮就是下一处"看起来可配、其实写死"的含混。
   一个常数 + 两侧边界断言已经足够；真要按调用方收紧，那属于把 `Ctx` 送进 `StorageBackend` 签名的决策。

## AN3. 一次"上限"要怎么测，才不是一句修辞

只有 `hang` 的时候，我能写的断言只有一类："端口永不就绪 ⇒ 被拒"。问题是**把预算改成 1 也全绿**：
"驱动器放弃太早"和"端口卡死了"在那个世界里是同一个读数。所以我先给仿真器加了 `stall(label, polls)`，
然后边界从两侧量：

- `polls = 预算 - 1` ⇒ 必须成功（`a_port_that_stalls_inside_the_budget_still_answers_through_the_store`
  以及写路径那条；后者还顺手复核"字节真的落了盘"，免得"成功"只是没人写）；
- `polls = 预算` ⇒ 必须被拒（`the_budget_is_measured_from_both_sides` 用一个循环把两侧写在一起，
  常数和断言不可能各说各话）；
- stall 是一次性的（`the_stall_is_charged_to_one_call_and_not_to_the_store` +
  `caly-io-sim/tests/contract.rs` 里那条端口层断言），否则"慢"会连坐后续调用，正面测试会因错误的理由通过。

同族的还有 `§4.98`（守卫必须有计数者）。这两条合起来是本仓对"有界"二字的最小要求：
**能被跨过的界，才叫界**。

## AN4. 结果与规模

```text
$ ./scripts/check.sh
  ok    cargo check --workspace --all-targets is clean
== tests
  ok    474 tests passed (floor 474)
== clippy (ratchet on distinct source locations)
  ok    clippy locations at baseline (32)
== formatting (advisory until the repo-wide rustfmt commit lands)
  note  1685 formatting diff lines remain (tracked, not gating)
== result
  all gates passed
```

新增 11 条断言：`crates/caly-storage/tests/store_port_budget.rs` 6、
`crates/caly-engine/tests/store_suspension_is_contention.rs` 2、`caly-io-sim/tests/contract.rs` +1、
`caly-arch-test/tests/dependency_direction.rs` 门禁 +1、`caly-arch-test/src/docs.rs` +1（本轮补的相邻性检查自带，
见 `AN6`）。两个来源各报一次：生成器 `files=62 total=474 rows=62`、门禁 `474 tests passed (floor 474)`。
规模：217 个 `.rs` / 60,686 行 Rust / 83 个 test target（63 可执行 + 20 doc-test）/ 20 个成员 / 73 篇 Markdown。
`TEST_FLOOR` 从 463 抬到 474，抬之前照例撕开：`FAIL test count fell below the floor: 474 < floor 475
(a test was lost; if the removal is deliberate, lower the floor and say why)`，还原后 `sha256sum -c` →
`scripts/check.sh: OK`。clippy 仍在基线 32，格式化欠账 1,685（本轮一度 1,696，见 `§4.116`）。

## AN5. 行为变更与它的读者

- **错误类别变了一格**：一个挂起的端口过去在 store 层报 `StorageErrorKind::Internal`，现在报 `Busy`；
  在引擎层过去是 `RefusalKind::Backend`，现在是 `RefusalKind::StorageBusy`（于是 `doctor` 多一条过载记录，
  `retry_hint=RetryLater` 那套 `§3.4` 的语义第一次能从盘这里长出来）。今天没有任何生产代码或测试按
  `Internal` 匹配过 store 的挂起，所以这个变更不破坏调用方 —— 但它是**公开可见的**，写进
  `IMPLEMENTATION_STATUS §6bis`。
- **一个慢盘不再让 apply 失败**：`a_slow_durable_backend_runs_the_apply_to_completion` 是端到端的
  （真 `FsStore` + 注入的 2 次挂起 ⇒ job `Succeeded` 且 last-known-good 交出）。
- **仍未覆盖**：`fs_store_on_real_disk` 那类真盘测试没有注入挂起的手段（`StdFs` 第一次 poll 就做完），
  所以"慢盘"目前只在仿真后端上被证明 —— 与 `ADR-022`（仿真即发布门禁）一致，但也仅此而已：
  真后端如果将来改成会挂起，这一层的正确性靠的是同一份 `drive_port`，不需要新证据。
- 下一步如果做第 4 步的阻塞池，`suspension` 这一格的**收益**会立刻显形：池子提交任务的 future 一定挂起，
  届时 store 层唯一的失败路径就是"预算内答完/超预算报 Busy"。这也是本轮把预算做成常数的原因之一。

## AN6. 收尾：本轮的数字被重抄了三次，而每次都是裁判赢

1. 我先把 `TEST_FLOOR` 写成 472（463 + 10 的心算），census 自报 473 —— 差的那条是我算进"存储层 6 条"里的
   `contract.rs` 断言（`§4.117`）。
2. 改完之后我又给 `docs.rs` 加了一条单元测试，裁判变成 474，于是全部数字再抄一遍。
3. 抄的时候我漏着两处：`ONBOARDING_NOTES` 的规模段与"门禁结果"段还留着上一轮的 462，而同一个文件的处置表
   那行写着 463（`§4.119`）。**同一文件自相矛盾而所有门禁全绿** —— 因为没有任何门禁查"旧值是否还有残留"。
   现在我把这条写成可执行的顺序：`grep -rn '<旧值>' docs/ crates/` 列住处 → 逐条改 → **再 grep 一次，命中 0 才算完**。

顺带把 `§4.119` 暴露的门禁空隙补了：那个空行是我上一轮 splice 留下的，它把处置表从中间截断（markdown 里
空行结束表格），而 `check_disposition_ledger` 只按顺序数行号、`check_tables` 只看表形，**单行脱离时谁都看不见**。
本轮给它加了相邻性检查（行与行之间不许隔空行）+ 一条单元测试，形状与第二十六轮那条一样：我先犯了它，再把它
变成断言。它也挨了两次证伪：判据改成永不成立 ⇒ 自带的那条单元测试红；改成永远成立 ⇒ 单元测试与
`doc_tables_and_lists_are_well_formed`（跑在真实文件上）一起红。本轮合计 **11 条变异全咬住**（主线 9 + 这两条）。

---

## AN7. 下一步（按优先级）

1. `ADR-036` 第 4 步：`caly-io-std` 有界阻塞池（`Http` 的仿真那一半比想象的近：`caly-io-sim` 已有
   `SimHttp`，而且它的 `fetch` **已经**读 `FetchReq::max_body_bytes`（`crates/caly-io-sim/src/port_impl.rs`）—— 于是
   `RFC-0006 §15.3` 的 body 上限契约可以先在共享契约套件里落地，`IoBudget::max_bytes` 的记账也有了一个
   看得见字节的地方；真 socket 那半边仍属"需要决策"，不是"需要写代码"）。
2. `BoundedExecutor` 与 `RunLimits` 的合流：现在 store 层有了第二个有界驱动点（`drive_port`），
   "谁持有预算"这件事更该有一个答案了。
3. 把 `Ctx` 送进 `StorageBackend` 签名（`RFC-0007` 层）："能打断已开始的调用"与"按命令收紧 store 预算"
   共用这道门。
4. 查询侧是否接限制；`stat_many` / 孤儿内容清扫；`caly-daemon` / `caly-cli` 的 `[[bin]]`。
# 第二十九轮（2026-08-28）：`RFC-0006 §5.3` 的主语是端口 —— `io_budget.max_bytes` 最后一次"没人读"结束

## AN0. 本轮选什么、为什么

`ADR-036 §1` 那张表从立项起就剩最后一行没被划掉：「`io_budget` 限制单次 IO —— `IoBudget::unlimited()` 是唯一
构造方式，且 `request_map` 把入站预算写死为 unlimited」。第二十一到二十四轮做掉了构造方式与 `max_requests`，
`max_bytes` 则被反复记作"引擎看不见全部字节，所以不生效"。开工前把 RFC 原文读了一遍，发现**这句话的主语一直是
端口**：

> `RFC-0006 §5.3` 「`io_budget` 用于限制**单次操作**的资源消耗，例如：可读取总字节数 / 可发起请求数 / 可解压后
> 总字节数。Budget 用尽时，**Port MUST** 返回容量/预算类 `IoFault`。」

受限的是单次操作、看得见尺寸的是端口、被要求返回那个 `IoFault` 的也是端口。于是"字节预算要等第 4 步"这个说法
只有一半对：需要等的是**真 `Http` / `Proc` 的实现**，而不是"由谁执行 `§5.3`"。本轮因此做执行处本身，并且顺手
把上一轮已经具备的东西接上——`caly-io-sim::SimHttp` 的 `fetch` **早就**在读 `FetchReq::max_body_bytes`，
只是没人把调用方的预算放到同一条判断里。

## AN1. 有了什么

| 位置 | 内容 |
|---|---|
| `caly-io/src/budget.rs`（新，207 行） | `byte_ceiling(ctx, requested)`：读侧上限取"调用自带 cap"与"`io_budget.max_bytes`"里**更紧**的一条，并记住是哪条在管；`check_payload(ctx, resource, bytes)`：写侧在任何字节落地**之前**拒；两者共用同一句文案规则（点名旋钮 + 带两个数） |
| `caly-io-std/src/lib.rs` | `StdFs::read` / `write_atomic` 从此**读** `ctx`（此前是 `_ctx`，字段被无视）；两行改动，接的是同一份 helper |
| `caly-io-sim/src/port_impl.rs` | `SimFs::read` / `write_atomic` 同一处调用；`SimHttp::fetch` 的 body 上限改成 `byte_ceiling(ctx, req.max_body_bytes)` |
| `caly-io/src/contract.rs` | `fs_byte_budget_violations`：六条断言（超限写在落盘前被拒、被拒后 `stat` 说没有该文件、精确等于上限放行、cap 更紧时文案点名 cap、预算更紧时文案点名 `io_budget.max_bytes`、未设预算什么都不拒），**两个后端各跑一遍** |
| `caly-engine` | `StorageErrorKind::CapacityExceeded` ⇒ 新的 `RefusalKind::PayloadTooBig`（`CONFIG_INVALID` + `User` + `retryable=false`）；`public_shape_for_refusal` 从两列变三列，`remediation` 进表 |
| `caly-arch-test` | 门禁 `every_backend_that_runs_the_fs_suite_runs_the_byte_budget_check_too`（附"应恰好找到 2 个后端"的反空转断言） |

## AN2. 三条判断，一条偏离

1. **精确等于上限是放行。** `<=` 而不是 `<`；差一格就变成"因为你正好用了我给的额度而拒绝你"。与 `ByteCap` /
   `ListCap` 同规则，本轮把它同时写进单元测试与两个后端的契约。
2. **宽松的那条不得放大另一条。** `max_bytes = 8 KiB` 配 `ByteCap(4 KiB)` 仍然按 4 KiB 拒 —— 写成"取 max"
   或写成 `budget > requested`，"预算更紧时按预算"那半边照绿，只有这条会红（证伪 M5 就是这么抓的）。
   `§4.122` 记的是这个形状：**组合规则要两个方向各一条断言**。
3. **未设预算 = 什么都不拒**，不是 0、也不是"无限到不必检查"。`M7`（把 `None` 读成 0）让三个测试当场红，
   包括 `the_store_invents_no_byte_ceiling_of_its_own` —— 那条断言守的是"`FsStore` 那份共享 `IoContext`
   不许设预算"：在那里放一个累计上限，等于"第 N 次大写入之后所有调用方一起被拒"。
4. **偏离 `§2.4`**：那条设想的是"执行器持有计数器、前后**累加**字节数"。本轮做的是**单次上限**。理由不是省事，
   是结构：累计需要比一次调用活得久的作用域，而能把 `Ctx` 送到端口的那道签名（`RFC-0007` 冻结的
   `StorageBackend`）今天不带它。偏离写在 ADR 原句下面，而不是让"累加"两个字悄悄活着。

## AN3. 一条断言一直为真，它旁边的解释却变成了假的

```rust
assert!(
    command.context.io_budget.max_bytes.is_none(),
    "bytes are deliberately uncapped at this layer; ..."
);
```

`request_map.rs` 里这条断言本轮之后**仍然成立**（默认确实不设上限），但那句解释曾经是"这一层没人执行"的同义
反复，现在成了假话：字节是可执行的，只是默认不开。修的是措辞，不是断言 —— 并把引用的 ADR 小节从
`§6bis-sexies` 换到 `§6bis-decies`。`§4.120` 记这条，可复用的部分是一句流程：改语义的那一轮，除了找"会失败的
断言"，还要 `grep` 字段名去读**围绕它的句子**；`assert!` 的第二个参数是给人读的契约，它过期时没有任何机器会喊。

同族还有一处本轮自查抓到的：`r29i.py` 里两条规则命中同一行，把那行写成
`` `wc -l` = `wc -l` = **61,269** 行； 行；`` —— 重复插入而非替换失败，门禁全绿（它核对数字，不核对句子通不通）。
**一行只归一条规则管**，改完要把受影响的行读一遍（`§4.123` 后半段）。

## AN4. 结果与规模

```text
$ ./scripts/check.sh
  ok    cargo check --workspace --all-targets is clean
== tests
  ok    485 tests passed (floor 485)
== clippy (ratchet on distinct source locations)
  ok    clippy locations at baseline (32)
== formatting (advisory until the repo-wide rustfmt commit lands)
  note  1685 formatting diff lines remain (tracked, not gating)
== result
  all gates passed
```

新增 11 条断言：`caly-io/src/budget.rs` 4（新文件）、`caly-io-std/tests/contract.rs` 1、
`caly-io-sim/tests/contract.rs` 2、`caly-storage/tests/store_port_budget.rs` 1、
`caly-engine/src/run_limits.rs` 1、`caly-engine/src/worker.rs` 1（这个文件第一次有自己的单元测试）、
`caly-arch-test/tests/dependency_direction.rs` 门禁 1。两个来源各报一次：生成器
`files=64 total=485 rows=64`、门禁 `485 tests passed (floor 485)`（474 → 485）。
规模：218 个 `.rs` / 61,269 行 Rust / 83 个 test target（63 可执行 + 20 doc-test）/ 20 个成员 / 73 篇 Markdown。
`TEST_FLOOR` 抬到 485 前照例撕开：`FAIL test count fell below the floor: 485 < floor 486 (a test was lost;
if the removal is deliberate, lower the floor and say why)`，还原后 `sha256sum -c` → `scripts/check.sh: OK`。
clippy 仍在基线 32；格式化欠账本轮一度 1,761 —— 还是 `§4.116` 那个毛病（格式化没排在最后一次写之后），
最后一次 `rustfmt` 后回到 **1,685**，我碰过的 8 个文件都不在 diff 清单里。
本轮开工第一件事是恢复工具链（第三次消失），`check.sh` 直接报 `FAIL cargo not found on PATH` 并附上安装命令
（`§4.124`）。

## AN5. 证伪：10 条，其中 4 条按后端分开

M1 真实盘读侧不看预算 / M2 真实盘写侧写完才测 / M3 仿真盘读侧不看预算 / M4 仿真盘写侧不测 ——
**这四条各自只红自己那一侧的套件**，这才是"两个后端都调了同一份 helper"这件事的证明；共享 helper 自己
跑通一次不等于两边都在用它（`§4.121`）。M5 把"取更紧的一条"写反、M6 边界翻成排他、M7 把"未设预算"读成 0、
M8 引擎不再升级 `CapacityExceeded`、M9 把两种预算拒绝的 remediation"去重"成同一个旋钮（红的是
`worker.rs` 那条新单元测试）、M10 让某个后端不再调用新检查但保留套件 —— 红的只有新门禁。

M9 值得单记：我在写它之前先补了那条单元测试，因为一开始 `PayloadTooBig` 的 remediation **没有任何断言读过**，
"两个 kind 共用一张表"这件事在只有 code/category 被断言时是测不出来的 —— 先问"这条变异若成立，哪个读数会变"，
答不出就说明断言还没长在分支上（`§4.98` / 第二十六轮 AN4 同一条）。

## AN6. 下一步（按优先级）

1. 让命令的 `Ctx` 真的抵达端口：`StorageBackend` 签名加 `Ctx`（`RFC-0007` 层）。本轮之后，
   `max_bytes` 已经"有人执行"，但 durable 路径上执行的是 `FsStore` 那份共享 `IoContext`（不设上限），
   所以"调用方设了预算却没让写变严"仍是真话 —— 这是同一个缺口的两面，`ADR-036 §6bis-decies` 的
   "还没有的"一节写得很明白。
2. `caly-io-std` 的 `Http`：`§15.3` 的跨后端断言现在只差一个实现（`byte_ceiling` 那一侧已就位，
   共享契约表里第 3 行按事实写明"只有一侧"）。`Proc` 另有一道闸：`std::process::Command::new` 在本仓
   所有 crate 都是禁用符号，spawn 属 Platform，需要决策而不是代码。
3. `caly-io-std` 有界阻塞池 —— 有了它，上一轮的 poll 预算才有一个值得等的东西，`§2.6` 的"在 `Deadline` 内"
   才会从"故意没做"变成"可以做"。
4. `BoundedExecutor` 与 `RunLimits` 的合流；查询侧是否接限制；`stat_many` / 孤儿内容清扫；
   `caly-daemon` / `caly-cli` 的 `[[bin]]`。
# 第三十轮（2026-08-28）：`RFC-0002 §11.4` 在 daemon 侧的承载体 —— 两条诊断查询有了响应上界

## AN0. 本轮选什么、为什么

`ADR-036 §6bis-quinque` 的第二条从第二十三轮起一直写着「查询侧不接限制……哪些查询值得被拒是策略问题」。
本轮先去量现状，量出来的不是"策略没定"，而是一个更具体的洞：

- `caly-ipc::MAX_FRAME_SIZE_BYTES = 4 MiB` 只在**入站**方向被 `validate_frame_header` 检查；
- daemon 出答的 `encode_raw_json` 对尺寸什么都肯造（`EncodedFrame { header: make_header(payload.len(), …) }`，
  没有任何上限判断）；
- 而 `diagnostics.recovery-status` 的 `decisions` 是「每个未决 apply journal 一行」，
  `diagnostics.doctor` 的三层列表是「每条 audit finding 一行 + 每条 recovery 决策一行」——
  两者的大小都由 **store** 决定，调用方无法预期，也都没有分页或流式（`RFC-0002 §9` 要求大集合必须二选一）。

三条放在一起的结论：一次**完全合法**的查询，只要 store 够大，就能造出一个对端拒收的帧。表现是运维在部署
坏掉的那一刻失去诊断，并且收到的不是 API 错误而是传输层错误 —— 而那恰好是唯一一条"界限由 store 决定"的
路径。`§11.4` 那句「large objects MUST NOT be returned as an oversized inline IPC frame」在 daemon 这一侧
从来没有承载体：`paging.rs` 给 `ReadJobEvents` 建过一次（`§4.54`），两条诊断查询是剩下的洞。

顺带把"要不要给查询接上*调用方的*预算"这个挂了七轮的问题判掉：**不接**，理由写在
`ADR-036 §6bis-quinque` 的更新里 —— 要"给我全部"已经有 support bundle（它把未截断的 audit 全文写进一个存储
对象，本来就不是一帧），而给 `DoctorRequest` 加 `max_lines` 要动线格式，换来的能力没人需要。
所以答案是"不需要"，不是"没做到"，并且这句话现在写在被引用的那一格旁边。

## AN1. 有了什么

| 位置 | 内容 |
|---|---|
| `caly-daemon/src/paging.rs` | `DIAGNOSTIC_MAX_LINES = 128` / `DIAGNOSTIC_MAX_LINE_BYTES = 4 KiB` / `DIAGNOSTIC_MAX_BYTES = 512 KiB`（其中 `DIAGNOSTIC_NOTE_RESERVE_BYTES = 1024` 是留给截断说明**自己**的预留），`DiagnosticBudget::for_bulk_tier()`、`bound_lines()`、`BoundedLines{lines,byte_len,omitted,shortened,total}`、`truncation_note(what, budget)`、`may_claim_clean()`；两条与帧上限的关系都是 `const _: () = assert!(…)` |
| `caly-api::DoctorReport` / `RecoveryStatusView` | 各加 `truncated` + `omitted_*` + `shortened_*`；`decision_count` / `pending_apply_count` / summary 里的 `decisions=N` **保持真实总数** |
| `caly-daemon/src/query/diagnostics.rs` | 上界按**来源**施加（audit 三层 + recovery 决策各一次），daemon 自己的句子在截断之后追加；截断说明落进**被截的那一层**；`no findings requiring action` 由 `may_claim_clean` 决定 |
| `caly-arch-test` | `check_round_claim` + 门禁 `the_centerline_assertion_count_matches_the_tree`（把 CENTERLINE 那句「这 N 个断言是否依然成立」与树里的实际数对表） |
| 测试 | `paging.rs` 8 条单元测试 + `caly-daemon/tests/diagnostic_bounds.rs` 6 条端到端 |

## AN2. 三条规则，两条继承，一条命名

1. **首行必带出**：与 `caly-engine::job_follow` 的 page 规则同一条，一个 crate 不许对"页满了长什么样"给出两种
   答案；空列表与"没有东西"不可区分，是诊断最不能犯的错。
2. **`omitted` 要数完，不是遇到就停**：`bound_lines` 里超限之后仍继续计数 —— 于是 `carried + omitted == total`
   成为一条可以在两个方向上验证的守恒律（M3 把 `continue` 改成 `break`，红的就是这条）。
3. **`shortened` 与 `omitted` 分开报**：「还有更多行」和「这一行被切了」的补救手段不同（前者去读 bundle，
   后者读了也没用），合成一个数就把两种情况都说错了。

另外两件形状上的事：
- **预留说明行的位子**。`for_bulk_tier()` 是 `标准预算 − NOTE_RESERVE`，因为"我截断了"那句如果自己就能把预算
  顶爆，那这个界就有例外；例外等于没有界。`the_truncation_note_fits_inside_its_reservation` 把所有计数器推到
  `usize::MAX` 去量说明行的长度，而不是估一个"大概几百字节"。
- **截断说明必须落在被截那一层**（不是塞进 notes 里"报告一下"）。M10 把三条说明都改道进 notes，红的是
  一条专门断言"warning 层里有自己的说明、notes 里没有 audit-warnings 那句"的测试 —— 那条断言是证伪跑之前
  补的，因为原来的写法只检查"文本里出现过"，而 `all` 是三层拼接，改道它照样绿。

## AN3. 两处本轮抓到自己

- **断言写死了"哪个界先咬"**：第一版 `assert_eq!(view.decisions.len(), DIAGNOSTIC_MAX_LINES)` 跑出 127 ——
  这个夹具里先咬住的是**字节**预算（每行缩到 ~4 KiB，127 行就顶到预留后的预算）。红的不是实现而是我的断言。
  改成守恒律 `carried + omitted == decision_count`，再单独造一个"只有行数会咬"的夹具去测
  `omitted == 72 && shortened == 0`（`§4.126`）。
- **一个不可达的守卫没有裁判**：`doctor` 那句 `&& !truncated` 加完之后，M9（把它删掉）**不咬** ——
  audit 会把 info 级 finding 聚合成几行，所以"三层全空 + 被截断"这个组合在 daemon 层根本造不出来，
  我那条断言通过的理由是 `warnings` 非空，跟守卫在不在没关系。做法是把规则命名成
  `paging::may_claim_clean(warnings_empty, errors_empty, truncated)` 并测四种组合，M9 立刻咬住（`§4.125`）。
  这条比结论本身更值得记：**留下一个"看起来有实现、实际没人判"的守卫，比不写更糟** —— 下一次有人"顺手简化"
  会把它当冗余删掉，而全仓不会红。

## AN4. 结果与规模

```text
$ ./scripts/check.sh
  ok    cargo check --workspace --all-targets is clean
== tests
  ok    501 tests passed (floor 501)
== clippy (ratchet on distinct source locations)
  ok    clippy locations at baseline (32)
== formatting (advisory until the repo-wide rustfmt commit lands)
  note  1685 formatting diff lines remain (tracked, not gating)
== result
  all gates passed
```

新增 16 条断言：`paging.rs` 8（含 `may_claim_clean` 的四组合）、`caly-daemon/tests/diagnostic_bounds.rs` 6、
`caly-arch-test/src/docs.rs` 1（新门禁自带的）、`doc_consistency.rs` 1（门禁接线）。两个来源各报一次：
生成器 `files=65 total=501 rows=65`、门禁 `501 tests passed (floor 501)`（485 → 501；本轮第一次把 floor
写成 502，又是自己的加法赢过一次 —— `§4.117` 第九次生效，裁判是 501）。
规模：219 个 `.rs` / 62,201 行 Rust / 84 个 test target（64 可执行 + 20 doc-test）/ 20 个成员 / 73 篇 Markdown；
`paging.rs` 529 行、`diagnostic_bounds.rs` 347 行、`docs.rs` 1,184 行。
`TEST_FLOOR` 抬到 501 前照例撕开：`FAIL test count fell below the floor: 501 < floor 502 (a test was lost;
if the removal is deliberate, lower the floor and say why)`，还原后 `sha256sum -c` → `scripts/check.sh: OK`。
clippy 仍 32、格式化欠账 1,685：本轮中途一度 **35 / 1,761** —— 新测试自己带了 2 条 `unused Result` 和 1 条
`assertions_on_constants`（`§4.128`：**新增测试要立刻跑门禁**，别攒到收尾；`assertions_on_constants` 在提醒
"两个常数之间的关系不是断言，是编译期事实"，本轮把它改成 `const _: () = assert!(…)`）。

**新加的门禁上线当轮就抓到作者**：它报"这 499 个断言"与树里的 501 不符；而第二十八轮加的相邻性检查也立刻
咬住本轮处置表新行前那个空行。**两轮前因为自己犯错加的门禁，本轮开始替自己值班** —— 这是这个仓库里门禁
唯一可靠的来源：先犯，再固化。

## AN5. 证伪：11 条全咬住

M1 预留消失 / M2 首行规则被删（于是一页可以是空的）/ M3 `continue` 改 `break`（不再数剩下的）/
M4 超长行被丢弃而不是就地缩短 / M5 说明行无条件出现（占位符复活）/ M6 缩短不算截断 /
M7 恢复状态不再被限界 / M8 **总数收缩到答案大小**（最该红的一种）/ M9 干净结论不看截断 /
M10 说明统一塞进 notes / M11 新门禁接受任何数字（把 stale 分支变成死分支）。

M8 值得单独看：它不改变"被截断"这一事实，只改变"总数"—— 也就是把一个诚实的有界回答变成一句谎话，
而红的那条断言是 `decision_count == JOURNALS`。如果当时我写的是 `assert_eq!(decisions.len(), 127)`
这类形状，M8 就不会咬 —— 所以"断什么"在这里比"断多少次"重要（`§4.126`）。

## AN6. 下一步（按优先级）

1. `RFC-0007` 层那个唯一的闸：把 `Ctx` 送进 `StorageBackend` 签名。它同时解锁三件被反复点名的东西 ——
   按调用方收紧 store 预算、打断已经开始的调用、以及把命令的 `max_bytes` 送到端口（第二十九轮的字段现在
   由 store 那份共享 context 决定，不设限）。这是**需要决策**而不是需要写代码，所以下一轮要么写 ADR 提案，
   要么继续挑不需要动冻结层的东西。
2. `caly-io-std` 的 `Http`：`§15.3` 的 body 上限现在两边都有实现处（`byte_ceiling` 已就位），只差
   `StdHttp`；`Proc` 另有一道闸（`std::process::Command::new` 全仓禁用，spawn 属 Platform）。
3. `caly-io-std` 有界阻塞池：有了它，第二十八轮的 poll 预算才有值得等的东西，`§2.6` 的"在 `Deadline` 内"
   才会从"故意没做"变成"可以做"。
4. `BoundedExecutor` 与 `RunLimits` 的合流；`stat_many` / 孤儿内容清扫；`caly-daemon` / `caly-cli` 的
   `[[bin]]`；`OVERLOAD §5.1` 剩下的两条（stale cursor、snapshot not retained）与 `§3.5` `FrameTooLarge`
   —— 本轮把"让帧超限"这条路堵住了，所以 `§3.5` 现在更接近"不需要生产者"而不是"缺生产者"，
   这句判断需要一次单独的复核再写死。
# 第三十一轮（2026-08-28）：把手法写成文档，把文档变成有裁判的 —— `CONTINUATION_PLAYBOOK.md` + 完成度复核

## AN0. 本轮选什么、为什么

用户提了两件事：把工作流程与经验总结进文档，以及汇报要有"项目大范围完成度"。这两件事各自都有陷阱，
所以本轮先把它们做成**可检查的东西**，而不是做成两段散文：

- "总结经验"的陷阱是它变成一份没人读、也没人维护的说明。对策：写完之后**给它一条门禁**
  （`the_document_index_lists_every_top_level_document`：`docs/README.md §1` 的目录树 ↔ `docs/*.md` 双向一致），
  否则新文档本身就是"没人读"的那一个。
- "汇报完成度"的陷阱是抄旧结论。本轮复核 `ROADMAP §1` 时就撞到一条过时的：它写着"另有 ADR-035 / 036 两份
  **Proposed** 草案待确认"，而实测 `grep -m1 -o "Status: [A-Za-z]*" docs/adrs/ADR-0*.md` 是 **28 个 Accepted、0 个 Proposed**。
  对策：新的 `ROADMAP §1bis` 每一行都必须附"量的东西（命令）+ 实测 + 由此可下的结论"，不写形容词。

## AN1. 有了什么

| 位置 | 内容 |
|---|---|
| `docs/CONTINUATION_PLAYBOOK.md`（新，223 行） | 12 节：每轮八步流程（带命令）、不可协商边界表、数字纪律（我犯过 11 次的形状）、断言/门禁纪律、证伪 harness 操作规程、文档手术规程、**现有门禁清单**（每条写明它判什么 + 它的失效形状）、环境与工具链恢复、"怎么挑下一件事"（阻塞点梯 + 需要决策 vs 需要写代码）、缺口三个登记处的分工、可勾选的收尾清单、这份文档自己的可证伪性 |
| `docs/ROADMAP.md` | `§1bis` 按阶段量的完成度（Phase 0→10 逐条：命令、实测数字、结论）＋`§1bis.1` 阻塞点（三件事卡在同一道 `RFC-0007` 签名上）＋`§1bis.2` 一句话完成度；Phase 0 那行过时结论就地更正 |
| `docs/README.md` | §1 目录树收录新文档；§2.5 阅读顺序把手册放第 1、并注明 `ROADMAP §1bis` 是量出来的完成度；§3 分工表加两行（类型都是 `Informative + Process`，不新增权威） |
| `caly-arch-test` | 新门禁 + `check_disposition_ledger` 加两条规则：**行必须以 `|` 收尾**（多行 = 渲染成散文）、相邻性报告在"原因已被更精确的那条说出"时闭嘴 |

## AN2. 三条从本轮实测里长出来的结论

1. **完成度的诚实形状是"每行有命令"**。`§1bis` 的关键数字都是量出来的：外部依赖 0（`grep` 清单里没有非
   `path` 依赖）、成员 20、`[[bin]]` **0**、socket 使用 **0**、CI/fuzz **无**、端口实现覆盖：生产适配器
   **2/7**（`Fs`、`Clock`）vs 仿真 **6/7**（`Platform` 两边都没有）、各 crate 测试数
   （engine 148 / daemon 94 / storage 78 / …，而 9 个 crate 是 0——它们的正确性经别处的测试间接判）。
   所以"能运行吗"的答案必须写成两句：**库与门禁可运行；可执行程序为 0**（`clock-timeline` 与 `[[bin]]`
   两个缺口都从这里长出来）。这不是退步，是把"未完成"从形容词变成坐标。
2. **门禁上线当天就咬住加它的人**：索引门禁写完后我才落 `CONTINUATION_PLAYBOOK.md`，中间那次 `cargo test`
   直接报「exists but `§1` does not list it」；第二十八轮加的相邻性检查也连咬两轮（本轮是处置表行**被写成多行**）。
   第二件事暴露了一个新形状：多行行既不满足"相邻"也不满足"列数"检查的可见条件，于是它**静默存在了两轮**。
   因此新增"行必须以 `|` 收尾"这条规则，并把它自己证伪了（关掉规则 → 测试红；把标志恒真 → 测试红）。
3. **删掉不可达的分支，而不是留着当心安**。我第一版给 split-row 规则写了 `lines.get(&n).map(…).unwrap_or(true)`；
   证伪跑（M5，把 fallback 翻个向）**不咬**——因为那个 `unwrap_or` 永不可达。按 `§4.94` 的老规矩，
   改成在扫描时就地算出 `ends_ok` 并随行携带，`unwrap_or` 消失，于是同一变异变成可咬的（重跑 M5：红）。
   顺带消掉一次 `rows.iter().find(...)` 的 O(n²) 回查。

## AN3. 本轮的两处自我修正（都记进了手册）

- **片段替换把一行变成重复片段**（`§4.131`）：我用"找到行 → 行内 `replace(old,new)`"改链尾数字，而 `old`
  是 `new` 的子串且该行本就有同样子串 ⇒ 出现 `450 → 463 → 434 → 447 → 450 → 463`。门禁全绿（数字对、
  形状对，只有句子读两遍）。规矩升级为：**改一行就重写那一行**；要保留子串替换，必须同时断言
  "`old` 在该行唯一"且"`old` 不是 `new` 的子串"（`docs/ROADMAP.md` 那行有 4 列，整行重写会吃掉最后一列，
  所以那里明确用了带 `count == 1` 断言的子串替换，并把理由写进注释）。
- **数字又被自己的加法骗了三次**（`§4.117` 第九、十次）：483→503→504 一路都是"census 自报"救回来的，
  最后一次连行数都要重量（我先写 62,368，实测 62,374）。手册第 3 节因此把规矩写成三句：只抄裁判的数、
  每次改动后再问一次、改完 grep 旧值到命中 0。

## AN4. 结果与规模

```text
$ ./scripts/check.sh
  ok    cargo check --workspace --all-targets is clean
== tests
  ok    504 tests passed (floor 504)
== clippy (ratchet on distinct source locations)
  ok    clippy locations at baseline (32)
== formatting (advisory until the repo-wide rustfmt commit lands)
  note  1685 formatting diff lines remain (tracked, not gating)
== result
  all gates passed
```

本轮净增 3 条断言（`docs.rs` 2 条：索引双向 + 多行行；`doc_consistency.rs` 1 条接线门禁），
`cargo test --workspace` 501 → 504（**注意**：这是裁判自报值，不是我算的；手册 §11 的清单要求最后一次
`regenerate_test_census.py` 之后才写数字）。普查自报 `files=65 total=504 rows=65`。
规模：219 个 `.rs` / 62,374 行 Rust / 84 个 test target / 20 个成员 / **74** 篇 Markdown（本轮 +1）。
`TEST_FLOOR` 抬到 504 前照例撕开：`FAIL test count fell below the floor: 504 < floor 505 (a test was lost;
if the removal is deliberate, lower the floor and say why)`，还原后 `sha256sum -c` → `scripts/check.sh: OK`。
clippy 仍 32、格式化欠账 1,685（本轮没碰任何 `.rs` 的格式策略：`docs.rs` 是唯一改动的源文件，单独 rustfmt）。

## AN5. 证伪：5 条，全咬住

| 变异 | 红的判据 |
|---|---|
| 索引门禁"没收录"方向关掉 | `the_document_index_is_checked_in_both_directions` |
| 索引门禁"索引留空位"方向关掉 | 同上（这条证明**两个方向各自有牙**，不是只测一边） |
| 多行行规则关掉（`if false`） | `a_disposition_row_split_across_lines_is_reported` |
| 相邻性不再让位给精确报告 | 同上（红的是"应只报 1 条"那条断言） |
| `ends_ok` 恒真（原来藏在不可达 fallback 里的形状） | 同上 |

第一次跑时第 5 条是 `NO EFFECT` —— 因为它打在**不可达的 fallback** 上；处理方式不是补断言而是**删掉那个分支**，
再跑就咬住了。这条已经在手册第 5 节写成一句：*"一个变异不咬时，先怀疑断言没长在分支上；如果分支本身不可达，
就删掉它——不可达的防御代码不是安全网，是没人能核对的承诺"*。

## AN6. 下一步（不变，但按 §1bis 的口径重排）

1. **需要决策的那道门**：把 `Ctx` 送进 `StorageBackend` 签名（`RFC-0007`）。`§1bis.1` 说清了它一次解锁三件事
   （打断已开始调用、按调用方累计 store 预算、store 接缝的真 `Deadline`）。下一轮该产出的是**一份 ADR 提案**，
   而不是绕过它的实现。
2. `caly-io-std::Http`（Phase 3 生产适配器从 2/7 往上走的最近一级；`byte_ceiling` 已就位，`§15.3` 的跨后端
   断言只差一个实现）。`Proc` 仍需要 Platform 决策（`Command::new` 全仓禁用是有意的）。
3. `caly-io-std` 有界阻塞池 —— `ADR-013` 的 follow-up，也是"在 `Deadline` 内轮询"从"故意没做"变"可以做"的前提。
4. `[[bin]]` 的边界决策（Phase 6/9 的两个缺口同源：`clock-timeline` 的注入者、`caly doctor --io` 的读者）。
5. `OVERLOAD §5.1` 剩下的两条（stale cursor、snapshot not retained）＋复核 `§3.5 FrameTooLarge`
   是否已从"缺生产者"变成"不需要生产者"——本轮把"让帧超限"这条路堵了一半，这句判断需要再量一次才能写死。

---

# 第三十二轮（2026-08-29）：GC 的另一半 —— 内容树孤儿清扫（`RFC-0007 §6.1` 收口）

## AN0. 本轮选什么、为什么

第 3 步（对象半边）落地后，plan 只看得见元数据：内容树里的孤儿 blob 与写残留对 GC 不可见，
`§13` 的 grace period 对它们不生效。这是 `RFC-0007 §6.1` 明写的另一半根，也是
`ADR-038 §9` 之后唯一没有裁判的 GC 面。选它而不是 `Ctx` 进端口签名，因为后者是决策轮
（`§1bis.1`，产出应是 ADR 提案），而这一件是**写代码就能收口**的事。

## AN1. 有了什么

- `ObjectStore::list_content / delete_content`（默认 `Unsupported`；engine 把 `Unsupported`
  记为 `GcRootGap("content-tree")` + `roots_complete=false`，缺口不冒充空树）。
- fs-store 走树：重复单级 `Fs::list` 三层下钻，目录预算 1024 含 level-0、超限 `CapacityExceeded`
  不部分遍历、损坏 `IntegrityViolation` 不跳过；短 anchor（hex<5）入口拒绝。
- InMemory 按 anchor 重键 + `keep_orphan_content` 测试后门；`delete_content` 引用检查与
  fs-store 同形（契约测试钉死，且当轮抓到真缺陷，`§4.132`）。
- 引擎全链携带内容半：plan（`plan_orphan_content`，引用/未知年龄永不入围）、周期
  （共享删除预算 `max_deletions − collect.len()`）、记录（`summary_line` 新增
  `content_deleted= content_failed=`，与 DTO 逐字同源）、daemon 视图四个新字段 + parity。
- 测试 504 → **534**（storage content_sweep 21 / object_contract 9 / engine
  content_orphan_cycle 6 / 真盘孤儿清扫 1 / daemon 内容半视图 1，及其余回归）。

## AN2. 三条从本轮实测里长出来的结论

1. **跨后端契约测试的增量在"同一非法输入"上**。单后端各自的测试全绿时，同一 `Anchor("sha256:00")`
   交给两个后端，fs-store 当场 panic（空路径段）——规格没写的输入，只有对比才暴露（`§4.132`）。
2. **共享预算必须测"花光的另一侧"**。`max_deletions=1` 时第二个孤儿内容 deferred，这条断言
   存在之前，"对象与内容共享预算"只是一句注释；存在之后它是可变红的性质。
3. **搬家后第一次构建红，先怀疑烘焙路径**；`--no-fail-fast` 之外，**汇总数远小于 census 总数
   本身就是失败信号**（fail-fast 假汇总 64/1 的教训，`§4.133`）。

## AN3. 本轮的两处自我修正

- 契约测试第一版拿短 anchor 当"不存在的内容"，修复后它变成**被拒绝的输入**——测试形状跟着
  实现语义走，语义变了测试的输入形状也要换（全长 digest 形状）。
- 仓库从 `/home/user/caly/caly` 移到 `/home/user/caly` 后，`error_identity` 因烘焙的旧绝对路径
  红了两次；全仓 `touch` + 重编是恢复手段（`§4.113` 的镜像），`falsify_round16.py` 的 `ROOT`
  从此与新家对上。

## AN4. 结果与规模

- `cargo test --workspace --no-fail-fast`：**534 passed / 0 failed**（census `--check` 同数）。
- 证伪：15 条变异全咬（见 `ADR-038 §10` 清单）；两处失败形态修在断言位置而非测试数量。
- 复核清单唯一遗留项（walk 叶名 64 位 hex 强制）本轮内收口：叶子字母表恰 60 位（64−4，
  `const _` 钉住），错长叶子/半长 stem 残渣是损伤不是 anchor，两条门禁各自变红过再入库。
- `check.sh`：TEST_FLOOR 534；clippy 基线 32 不变（0 warning）；`cargo fmt --check` 只碰本轮改动文件。

## AN5. 证伪：15 条，全咬住

| 变异 | 咬住它的裁判 |
|---|---|
| walk 不达叶级（`Vec::new()`） | `the_walk_sees_content_no_metadata_names` |
| 引用判失忆（`false &&`） | `referenced_content_is_never_orphaned_no_matter_how_old` |
| 未知年龄可删（`None => true`） | `an_orphan_of_unknown_age_survives_every_cycle` |
| grace 反转（`>=` → `<`） | `grace_boundaries_hold_from_both_sides` |
| fs-store 引用中内容可删 | `the_store_refuses_to_delete_content_metadata_still_names` |
| InMemory 引用中内容可删 | `the_content_tree_door_answers_the_same_way_on_both_backends` |
| 残留误分类（residue 分支关） | `write_residue_is_discovered_as_its_own_kind` |
| 非法 anchor 形状放行 | `a_target_the_layout_cannot_explain_is_refused` |
| 目录预算永不触发 | `the_directory_budget_is_measured_from_both_sides` |
| 能力缺口改类名 | `an_unwalkable_backend_is_a_gap_and_the_cycle_deletes_nothing` |
| 执行跳过内容清扫 | `a_cycle_deletes_the_orphan_it_planned_and_says_so` |
| 预算翻倍（不减 collect） | `objects_and_content_share_one_deletion_budget` |
| 记录句子丢内容半（数字清零） | `the_record_line_and_the_dto_line_are_one_sentence` |
| 叶子错长放行（`&& len == 60` 关掉） | `a_leaf_of_the_wrong_hex_length_is_damage_not_an_anchor` |
| 残渣半长 stem 放行（stem 长度关掉） | `a_residue_whose_stem_is_not_a_full_leaf_is_damage` |

M10 是类名改写而非删除 push（裸块不是合法 match 臂，删了就不编译——`§4.112`）：它证明
类名断言长在那一行上；"吞掉 Unsupported"是同一条断言的另一种红。M13 用数字清零而不是删
格式段（删段会连累 arity，又是编译错误伪装成性质）。M8 给了本轮第二条教训：长度门收紧后
它的旧输入（`NOT-HEX`，7 位）先被长度挡住，变异"不咬"暴露的是**输入没长在门上**——补一条
64 位非 hex 的输入后字母门重新有牙。一条门禁需要能被它自己的输入打红，否则它测的是另一条门。

## AN6. 下一步（不变的两道门，重排后不变）

1. `Ctx` 进 `StorageBackend` 签名的 **ADR 提案**（`§1bis.1`：打断/预算/真 Deadline 三合一）。
2. `caly-io-std::Http` 的 `ByteStream { label }`：三十一轮结转的结构性发现——无消费者，
   `RFC-0006 §9.2` MUST 未满足，需要形状 ADR（ADR-036 步骤 3、4 不可声明的根因同源）。
3. ~~walk 叶名 64 位 hex 的强制~~ 已在本轮收口（原为唯一遗留复核项）：叶子字母表恰 60 位
   hex，错长叶子与半长 stem 残渣都是损伤；M14/M15 两条变异咬住，M8 补输入后字母门重新有牙。
   剩下真正开着的口是"形状对但内容不承诺"（anchor 指向的文件字节是否真为其摘要），属读取侧
   完整性校验决策，与 `Ctx` 进端口签名同一张决策桌。

---

# 第三十三轮（2026-08-29）：自行决策的那道门 —— `ADR-039`，调用方 Context 进 store 接缝

## AN0. 本轮选什么、为什么

`ROADMAP §1bis.1` 把三件事（打断已开始的 store 调用 / 按调用方累计 store 预算 / store 接缝的真
时限）判为"卡在同一道门后，正确下一步是一份 ADR 提案"。维护者已把此类裁决交给接续开发方
（`ADR-035 §6bis`），本轮据此**自行决策并落地第 1 步**：写 `ADR-039`，改 `RFC-0007` 冻结的签名。

本轮实测还找到这道门的第四个症状，也是最直观的一个：`FsStore::open` 捏造一个 `IoContext` 存进
`StoreInner.ctx`，此后每一次端口调用都归属于这个幽灵——调用方身份死在引擎边界上。

## AN1. 有了什么

- 六个 store trait 全部 23 个异步方法尾参 `ctx: &IoContext`（`ObjectStore` 8 / `RevisionStore` 3 /
  `SnapshotStore` 4 / `JournalStore` 3 / `ApplyJournalStore` 5，含默认 `Unsupported` 的四个）。
- `StoreInner.ctx` 删除；open 的 schema gate 与同步 introspection 各自持局部、自标上下文
  （`storage-open` / `storage-introspection`）；`audit_backend` 增 ctx 参数由调用方归属。
- `StorageErrorKind::Cancelled`；取消门落在内容半：fs 走查的 `spend` 闸门（第一次 spend 即先导
  检查，其后每级之前再查——预算与取消同一道闸）、两后端 `list_content`/`delete_content` 同答。
- 引擎侧 `EngineHandle::store_ctx()`（`engine-storage`）供 idle GC、启动恢复、bundle、daemon
  audit 等引擎自发工作使用——自标归属，绝不借用碰巧在场的调用者。
- 裁判 3 条：端口归属真实化（ProbeFs 记录走查期间端口所见 trace 必须全是调用方的）、走查级间
  取消（第一次端口调用才取消，先导已过、级间拦截）、两后端取消同答（契约）。

## AN2. 三条从本轮实测里长出来的结论

1. **归属真实化是可断言的**，不是文档口号：ProbeFs 夹在 store 与端口之间记录每个调用的
   trace_id，"store 不再发明自己的调用者"从一句 ADR 原则变成一条会红的测试。
2. **预算与取消共用同一道闸**是设计而不是省事：走查以"级"为工作单元，预算在这一级花、取消在
   这一级查，两者的粒度天然一致，先导检查就是第一次 spend——不需要第二套检查代码。
3. **`"%s" % None` 的静默字符串化**把批量签名改造变成了 20 分钟的定位练习（`§4.134`）：
   Python 的字符串格式化从不报错、只会写错——转换器输出必须每文件 `cargo check` 才算改完。

## AN3. 本轮的两处自我修正

- `NoneBoxFuture`（见上）：三个测试文件的签名被静默损伤，靠"基线 zip + 全树定义为零"收窄到
  "该标识符从未存在"，机械还原；教训入 `§4.134`。
- 第一版把取消门写成"两后端各自决定"，契约测试逼着统一：fs 走查在 `spend` 查、InMemory 在入口
  查——**位置可以不同，答案必须相同**，这正是跨后端契约测试存在的理由（`§4.132` 的延续）。

## AN4. 结果与规模

- `cargo test --workspace --no-fail-fast`：**537 passed / 0 failed**（改造当次运行即全绿——
  签名变更不加门不改既有答案，是 `ADR-039 §5` 的验收线）；census `--check` 同数。
- 证伪：`scripts/falsify_round33.py` 6 条全咬（fs 闸门失忆 / InMemory walk 门失忆 / 两后端
  delete 门各一 / 伪造身份重现 / Cancelled 误报 Busy）。
- `check.sh`：TEST_FLOOR 537；clippy 基线 32 不变；fmt 只碰本轮改动文件。

## AN5. 证伪：6 条，全咬住

| 变异 | 咬住它的裁判 |
|---|---|
| fs 走查 spend 闸门取消检查失忆（`false &&`） | `a_cancellation_that_arrives_mid_walk_stops_the_next_level` |
| InMemory walk 取消门失忆 | `a_cancelled_caller_is_refused_the_same_way_on_both_backends` |
| fs `delete_content` 取消门失忆 | 同上（delete 半） |
| InMemory `delete_content` 取消门失忆 | 同上（delete 半） |
| 走查向端口递交伪造身份（`storage` 幽灵） | `the_port_sees_the_callers_trace_not_a_fabricated_ghost` |
| 走查把取消误报为 Busy | `a_cancellation_that_arrives_mid_walk_stops_the_next_level` |

## AN6. 下一步（`ADR-039 §4` 阶段表）

1. 第 2 步：字节预算——fs-store 读写按 `ctx.io_budget` 计费（`caly_io::budget` 既有助手），
   收口第二十四/二十九轮"字节的那一半"。
2. 第 3 步：`deadline_mono_ms` 由持 `Monotonic` 的驱动方判定（前提 `ADR-013` 有界池）。
3. 第 4 步：门面穿透——daemon/app 的 `RequestContext` 经 `EngineHandle` 端到端到达 storage。
4. `caly-io-std::Http` 的 `ByteStream { label }` 形状 ADR（三十一轮结转，未动）。

---

# 第三十四轮（2026-08-29）：`ADR-039` 第 2 步 —— 累计字节预算落在 store 接缝

## AN0. 本轮选什么、为什么

`ADR-036 §6bis-decies` 把 `max_bytes` 降格为"单次调用上限"的唯一理由是 store 签名不带 `Ctx`——
没有调用方作用域，挂 store 的计数器会跨进程累计。第 33 轮消除了这个前提；本轮补上缺的另一半，
`ADR-039 §4` 阶段表第 2 步。

## AN1. 有了什么

- `caly_common::ByteMeter`（`Arc<AtomicU64>`；克隆共享——上下文递归传递即同一命令的作用域；
  相等按身份，与 `CancelToken` 同理同形），挂 `RequestContext.byte_meter`，新 ctx 新域。
- 规则一处写、两后端调：`caly_io::budget` 增 `admit_bytes`（写先导准入——大小事前已知，
  拒在任何字节落盘之前）、`admit_unit`（读准入——"还有剩吗"，在飞单元完成并计费、下一单元拒，
  与取消门同一在飞纪律）、`charge`（事后记账）。
- fs-store 在 `write_bytes`/`read_bytes` 漏斗接线（内容、记录、验证读全计费）；InMemory 的
  `put`/`read_object` 同门同措辞。
- 语义边界：未声明预算 ⇒ 零门（`RequestContext::new` 与引擎自标 ctx 不被静默拦截）；
  计费粒度后端自决——**门是契约、字数不是**。

## AN2. 三条从本轮实测里长出来的结论

1. **两条计费路径互为兜底**（`§4.135`）：fs 的 put = 写 + 读回验证 + 记录，读回同样计费，
   拿掉写计费后 meter 仍在走、门"看起来活着"。裁判必须按路径钉贡献（floor=2×payload），
   总量断言测不出单路径失效。
2. **"不咬"先查门有没有备份，再怀疑变异**：M2 第一版不咬时，探针（打印真实拒绝消息里的
   `already moved`）一步定位到数据源，比读代码猜快十倍。
3. **meter 挂 ctx 是当年"停机"担忧的解**：作用域跟着调用方走，跨进程累计在结构上不可能——
   旧偏离记录补注即可，不需要新 ADR 推翻。

## AN3. 本轮的两处自我修正

- M2 第一版 judge 选错（见上），补路径级裁判后咬住；harness 同步改为 M2b。
- 盲目正则加 `byte_meter` 字段时误伤 `RunLimits`/`Drive` 的 struct 定义（第 33 轮 `§4.134` 的
  同族失误，本轮即犯即改）——批量改字段依旧必须每文件 `cargo check`。

## AN4. 结果与规模

- `cargo test --workspace --no-fail-fast`：**546 passed / 0 failed**（接线当次全绿——默认无预算
  ⇒ 既有 537 条逐字保持）；census `--check` 同数（files=68）。
- 证伪：`scripts/falsify_round34.py` 8 条全咬；clippy 基线 32；fmt 只碰本轮文件。

## AN5. 证伪：8 条，全咬住

| 变异 | 咬住它的裁判 |
|---|---|
| fs 写准入丢（`let _ = admit_bytes`） | `a_write_that_would_cross_the_callers_budget_is_refused_before_it_lands` |
| fs 写计费丢（读回仍计费） | `a_write_charges_the_bytes_it_wrote_not_just_the_verification_read` |
| fs 读准入丢 | `a_read_charges_what_it_moved_and_the_next_unit_refuses` |
| fs 读计费丢 | 同上 |
| memory 写准入丢 | `both_backends_answer_the_budget_door_the_same_way` |
| memory 读准入丢 | `a_memory_read_charges_and_then_refuses_new_units` |
| memory 读计费丢 | 同上 |
| 共享措辞丢 "cumulative" | 写门裁判（措辞断言） |

## AN6. 下一步（`ADR-039 §4` 阶段表）

1. 第 3 步：`deadline_mono_ms` 由持 `Monotonic` 的驱动方判定（前提 `ADR-013` 有界池）。
2. 第 4 步：门面穿透——daemon/app 的 `RequestContext` 端到端到达 storage（届时累计 meter 与
   取消门对真实调用方生效，而非只对测试构造的 ctx）。
3. `caly-io-std::Http` 的 `ByteStream { label }` 形状 ADR（三十一轮结转，未动）。

---

# 第三十五轮（2026-08-29）：`ADR-039` 第 3 步 —— store 接缝的等待时限

## AN0. 本轮选什么、为什么

第 28 轮给 store 的端口驱动器加了轮询预算（挂起端口 ⇒ `Busy` 而非 `Internal`），"在
`Deadline` 内"那一半当时记为**故意没做**：判期限要有时钟，而那一层没有。第 33 轮把 ctx
送进接缝后，期限的载体就位；本轮补上判定者——`ADR-039 §4` 第 3 步。

## AN1. 有了什么

- `FsStore::with_clock(Arc<dyn Clock>)`：构造期 builder，`None`（`open` 默认）= 期限忽略。
  组合根拥有时钟选择（`StdClock` 真机 / `SimClock` 确定性门），与 `ADR-038 §3` 文件日期
  同一教义。
- `drive_port(future, ctx, clock)`：把 ctx 的**取消**（每次驱动搭载——第 33 轮的取消门是
  方法内先导检查，这是覆盖挂起中端口的另一半）与 **`deadline_mono_ms`**（仅当 store 持有
  时钟）递给端口层 `Drive`。期限与钟缺一即忽略、绝不猜测（`§4.86`）。
- `from_iofault` 补 `Cancelled → Cancelled`；`Timeout` 原有映射保留——驱动器的三种答案
  （取消/超时/预算）在 store 侧仍是三种。
- 走查与目录助手（`walk_content_tree`/`list_directory`/`walk_stat`）穿时钟参数；schema
  gate 的开箱工作诚实持 `None`（store 尚不存在，无人声明期限）。

## AN2. 三条从本轮实测里长出来的结论

1. **"前提有界池"实证为不必要**：阶段表原写第 3 步前提是 `ADR-013` 有界池——判期限其实
   只需要在轮询之间读钟（`drive_pinned` 每轮 poll 前查取消→期限→预算），不必等完成事件；
   有界池是**真阻塞调用**的前提，与期限判定解耦。前提要复核，不要继承。
2. **判时限的是钟，不是调用方的话**：同一调用方、同一相对期限，钟前进后答案从 `Busy`
   变 `Timeout`——这条裁判把"期限的判定权在持钟方"从原则变成了可变红的行为。
3. **M1 变异再证 `§4.112`**：`&& false` let-chain 在本仓 edition 不编译、不作证；换成
   `(None, clock)` 的可编译形状后立刻咬住。变异保持形状，否则测的是 rustc。

## AN3. 本轮的两处自我修正

- 无时钟夹具第一版忘了先放对象：`read_object` 对无记录的 digest 答 `Ok(None)` 而**不碰
  端口**——夹具的意图（看驱动器对沉默端口说什么）被短路。先写对象再挂起。
- M1 形状（见上）。

## AN4. 结果与规模

- `cargo test --workspace --no-fail-fast`：**551 passed / 0 failed**（接线当次全绿——无钟
  ⇒ 期限忽略 ⇒ 既有 546 条逐字保持）；census `--check` 同数（files=69）。
- 证伪：`scripts/falsify_round35.py` 5 条全咬；clippy 基线 32；fmt 只碰本轮文件。

## AN5. 证伪：5 条，全咬住

| 变异 | 咬住它的裁判 |
|---|---|
| 期限不递给 Drive（`(None, clock)`） | `an_expired_deadline_times_the_port_out_instead_of_calling_it_busy` |
| 取消不递给 Drive | `a_cancelled_caller_is_answered_cancelled_even_mid_port` |
| `Cancelled` 压平为 `Internal` | 同上 |
| `Timeout` 压平为 `Busy` | 过期期限裁判 |
| `with_clock` 收下钟又丢弃 | 过期期限裁判 |

## AN6. 下一步（`ADR-039 §4`）

1. 第 4 步：门面穿透——daemon/app 的 `RequestContext`（含 `deadline_ms → deadline_mono_ms`
   换算、`io_budget`、取消）经 `EngineHandle` 端到端到达 storage；届时本轮的期限门与第 2
   步的 meter 对**真实调用方**生效，`StdClock` 的生产接线也归此步。
2. `caly-io-std::Http` 的 `ByteStream { label }` 形状 ADR（三十一轮结转，未动）。

---

## 第三十六轮（2026-08-29）：ADR-039 第 4 步——门面穿透，四步全落

**断点测量**：命令路径的 ctx 随 `Command.context` 早已入引擎，但其 `deadline_mono_ms` 为 `None`
（`request_map.rs` 注释"daemon owns no monotonic clock"在 `set_storage_clock` 先例之后**已过时**）；
查询路径在 `query/diagnostics.rs` 调 `app.read_support_bundle` 时把 ctx 丢在门外；引擎三方法
（`latest_support_bundle_digest`/`object_payload`/`object_metadata`）仍以 `Self::store_ctx()`
自标签幽灵（第 1 步留下的三处）。

**落地**：引擎三方法 `ctx` 上提为参数；daemon `caller_ctx(app, actor, envelope)` 三规则——身份
转发不造、预算缺省 `IoBudget::default_command`（`unlimited` 不可达）、相对期限仅当
`app.storage_clock_for_deadlines()` 有钟才 `with_deadline_from(now, relative)`；查询路径仅
diagnostics 家族穿 ctx（其余十家族纯内存应答、不收未用参数——query.rs 注释讲明这条线）；
`app.read_support_bundle(ctx, request)`。命令路径期限换算**记录不做**：判期限属于执行侧
驱动器（`§4.86`），request_map 是纯映射无 app 手柄，不借存储钟（ADR-039 §9）。

**裁判**：`crates/caly-daemon/tests/facade_store_ctx.rs` 4 条端到端。夹具不引 `caly-io-sim`
（daemon 架构边）：`StdFs` 临时目录 + 手摇 `TestClock`（`Arc<Mutex<u64>>`，`sleep_until` 即答）
+ `ProbeFs` 记录读取期 ctx.trace_id + `FsStore::with_clock` + `try_bootstrap` +
`set_storage_clock` 同源双钟。

**本步自己的失误（§4.136）**：`caller_ctx` 初版 `deadline_ms.unwrap_or(0)` 把"未声明期限"静默
变成"立即过期"——无漂移裁判**首跑即抓**（两条裁判红）。修为 `(Some(clock), Some(relative))`
双 Some 门，回归变异 M6 `or(Some(0))` 入 harness。另：deadline 裁判初版想用"拨到 500 × 100ms"
判过期——但 `deadline_ms` 是相对到达时刻的（500+100=600 未过期），改"拨到 700 × 0ms"，拒词必须
点名 `deadline at mono 700`（幽灵 ctx 无期限、别的钟读不出 700）。

- `cargo test --workspace --no-fail-fast`：**555 passed / 0 failed**；census 551/69 → **555/70**；
  `TEST_FLOOR` 551 → 555；clippy 唯一位置 31（新测试的 3 条 warning 修净：unused import /
  type_complexity（元组改 `Fixture` 结构体）/ result_large_err（按 `gc_collect.rs` 先例 Box），
  基线 32 未动）。
- 证伪：`scripts/falsify_round36.py` **6/6 全咬**（引擎幽灵回归 / daemon 丢预算 / 丢期限换算 /
  伪造 trace / app 无视 ctx / `or(Some(0))` 回归）。M3 锚点被 `cargo fmt` 换行改写后 harness
  断言拦下（`anchor x0`），按新形状重锚——锚点断言又一次证明必要。

## 下一步

1. `caly-io-std::Http` 的 `ByteStream { label }` 形状 ADR（三十一轮结转，未动）。
2. anchor 读侧校验、有界阻塞池、`OVERLOAD §5.1` 余项（见 ROADMAP）。

---

## 第三十七轮（2026-08-29）：ADR-040——ByteStream 的 label 是调用方自己的名字

**断点测量**（三十一轮结转的形状题）：`open_stream` 零生产调用方（只有共享契约在用）；
`ByteStream { label }` 不是读取器（无 chunk/poll/关闭）——这些是"诚实形状"。真正的缺陷两个：
① std 的 `open_stream` 把 resolve 后的**宿主绝对路径**塞进 label 递回端口外——VPath 沙箱存在
的唯一理由被一行 undone；② fs label 两后端两种语义（sim=vpath 键、std=宿主路径），共享契约只判
Ok/Err 不看返回值。附带：fetch label 取 `response.url`（脚本条目）而非 `req.url`——按
`response.url == req.url` 匹配所以行为不可分，但归属方向反了。

**决策（ADR-040）**：label = 调用方自己给资源的名字。fs：`as_relative_path()` 两后端同规；
fetch：钉 `http:{req.url}` 形；真读取器**显式推迟**（无消费者即无能力；届时新 ADR 且必须带
ctx 预算与期限——ADR-039 教义）。被否决：现在造 poll 读取器（零消费者、无法裁判）、删
`open_stream`（RFC-0006 冻结 + 存在性探针有契约重量）、label 改 Option/删字段（"含义错了"修成
"没有含义"不是修复）。

**裁判 3 处**：共享契约 `fs_contract_violations` 判**返回值**（label == 请求路径渲染——同时咬
"两后端同空"：parity 相等不是充分条件，相等于正确值才是）；std
`open_stream_label_carries_no_host_path`（宿主根不出现在任何端口值——只有 std 测试知道宿主根）；
sim `fetch_body_label_names_the_request_in_a_pinned_shape`。

**本课**：ADR 头一度写了"RFC-0011（若编号有出入以处置表为准）"——引用不存在的 RFC 还预留借口，
正是本仓记档的病灶形状；入档前自纠为只引 RFC-0006、VPath 教义指向真实载体。

- `cargo test --workspace --no-fail-fast`：**557 passed / 0 failed**；census 555/70 → **557/70**
  （两个新裁判落在既有文件，文件数不变）；`TEST_FLOOR` 555 → 557；clippy 32 不动。
- 证伪：`scripts/falsify_round37.py` **4/4 全咬**（宿主路径回归 / 两后端同空 / sim 单侧漂移 /
  fetch 失形）。

## 下一步

1. anchor 读侧校验（ROADMAP 缺口梯）。
2. 有界阻塞池、`OVERLOAD §5.1` 余项。

---

## 第三十八轮（2026-08-29）：anchor 读侧校验——boot 扫描与 GC 同一门

**断点测量**：GC 删除路径对 content anchor 有完整三连拒（非 sha256 引用 / 非小写 hex / 非
64-hex 全长，`content_sweep.rs` 六形裁判），但 `FsStore::load()`（boot 自洽校验，ADR-035 §6bis）
把记录里的 `content_sha256` **未经准入**直接喂 `content_suffix_for`——带外损坏的记录会把
`../../etc/passwd` 一类垃圾变成后缀：或撞上 VPath 拒绝报路径层 `Internal`，或落成
"references missing content" 的**幽灵路径误诊**。boot 拒绝是对的（行为不变），但拒词说谎。

**落地**：抽取 `admit_content_anchor`（三连拒原样搬家），`content_suffix_for_target`（GC 门）
与 `load()`（boot 门）走同一 admission——两门对"什么算可解释"不再各说各话；boot 对坏 anchor
报 `object {digest} records a malformed content anchor: <措辞>` 并拒绝启动。

**顺带登记的决策题（ROADMAP §1bis.3）**：测量时发现 `sanitize` **非单射**——对象 digest 是
调用方自铸名（`obj:orphan` 合法），`/\: .` 都压成 `_`，两个合法名可撞同一
`meta/objects/*.obj`（put 互覆、get/delete 别名命中、fs 与 memory 两后端对别名答案不一）。
修复形状动 `RFC-0007 §6.4` 冻结命名，**需 ADR**，不当轮擅改。

**裁判**：`fs_store_on_real_disk.rs` +2（带外改记录→重开：traversal 形状点名 anchor 与
`not a sha256 reference`、且**不**含"references missing content"；短 hex 形状点名
`not a full 64-hex sha256 name`）。夹具用 `caly_storage::encode_object` 重编码整记录（非字符串
替换，codec 全程合法）。

- `cargo test --workspace --no-fail-fast`：**559 passed / 0 failed**；census 557/70 → **559/70**；
  `TEST_FLOOR` 557 → 559；clippy 31（≤32 不动）。
- 证伪：`scripts/falsify_round38.py` **4/4 全咬**（boot 绕准入重建幽灵误诊 / 长度规则被删 /
  准入空洞化——`let _ =` 既不拒也不说，boot 会带着损伤走过去 / GC 门绕开共享准入，两门分叉）。

## 下一步

1. `OVERLOAD §5.1` 余项、有界阻塞池（ROADMAP）。
2. §1bis.3 sanitize 单射性 ADR（需决策：拒撞名 or 单射转义）。

---

## 第三十九轮（2026-08-29）：ADR-041——记录文件名单射转义（§1bis.3 决策题收口）

**决策**：`sanitize` 压平（`/\: .`→`_`）非单射的四个后果——两个合法名**静默互覆**一个
`meta/objects/*.obj`、别名 `get` 命中并返回 digest 不符的记录 / 别名 `delete` 删别人的文件、
fs 与 memory **两后端对别名答案分歧**、互覆后**重启前后答案不同**——选单射百分转义
`escape_component`（`%`→`%25` 先行，其余 `%2F/%5C/%3A/%20/%2E`；六处调用点统一：对象记录
四处 + `records/{kind}` + `materialized/`）+ boot"文件名 == digest 会占据的名字"校验
（legacy/伪造命名点名拒绝启动）。被否决：put 拒撞名（修不了别名读、要反向映射）、入口拒
特殊字符（`mihomo:*` 惯例是更大契约）、维持现状（违反两后端同门同词与重启不变两教义）。

**裁判 3 处**：`object_contract.rs` 两后端同问（别名 get→None、别名 delete→false、幸存者
完好）；durable 侧四个名字两对单射边界（`obj:orphan`/`obj_orphan`、字面 `probe%2Fpath`/
`probe/path`）重启后仍四条俱全；真盘旧式名（记录放到压平时代文件名）boot 点名拒。

**迁移即教训**：夹具迁移八处，其中三份**各自手写的压平规则副本**浮出——`gc_plan.rs` 两份
（一份还漏了 `\`）、`durable_centerline.rs` 一份（只换 `:`）。"两个渲染器一个事实"
（§4.102）在命名规则上的重演：副本必漂移。`escape_component` 因此公开，成为唯一真源。

- `cargo test --workspace --no-fail-fast`：**562 passed / 0 failed**；census 559/70 →
  **562/70**；`TEST_FLOOR` 559 → 562；clippy 31（≤32 不动）。
- 证伪：`scripts/falsify_round39.py` **4/4 全咬**（压平回归 / boot 校验解除 / `:` 半吊子
  转义——单射性悄悄丢失 / `%` 转义缺席——字面名可伪装转义名）。
- ADR-041 入档，adrs/README 索引两处；ROADMAP §1bis.3 该项标记已决并指明去向。
- **顺手修掉一个检查器缺陷**：`table_cells` 的反斜杠转义在**代码段内**也生效——引用反斜杠
  字符本身的代码段（`` `\` ``）会把闭合分隔符当转义吞掉、代码段永不闭合、其后所有竖线不被
  计数：三列的行被判两列。本轮处置行恰好引用了那个漏掉的反斜杠，当场触发。修复：转义只在
  代码段外生效（CommonMark），用例钉进既有单测。

## 下一步

1. `OVERLOAD §5.1` 余项、有界阻塞池（ROADMAP）。
2. `records/{kind}` 各族的大名单↔记录 boot 校验（ADR-041 §2 留的后续，需要时再做）。

---

## 第四十轮（2026-08-29）：一轮两题——boot 大名单校验推广 + OVERLOAD §5.1 关账

**① ADR-041 §2 留的后续**：`records/{kind}` 四族的 boot 名↔记录校验——`load()` 的
RECORD_KINDS 循环现在对每条 decoded 记录断言文件名 stem == `escape_component(id)`，措辞与
对象族同门（`legacy or forged naming` 点名文件与 id）。裁判 2 条真盘：压平时代旧名拒；
**未转义原名**（`snapshot:raw-name.rec`——`:` 在 Linux 是合法文件名字符，裸 id 落盘真实可达）
同拒。证伪 3 条：校验解除 / 拿裸 id 比对（恰好被裸名裁判咬住——它是为这个变异存在的）/
写侧丢转义（store 拒绝自己的记录，重启裁判红）。

**② OVERLOAD §5.1 关账**：stale cursor 的 `reset_required` 正反裁判早在 `job_follow.rs` 内嵌
单测（本轮曾误报"零裁判"——只搜了 tests/ 目录漏了 src 内嵌 mod tests，先验证再断言）；
snapshot not retained 的 remediation 文本（两条出路 + gc 诚实原因）此前无测试读过，补裁判
在 `facade_store_ctx.rs`（失 digest ⇒ 结构化 `Conflict`/`User`/不可重试 + remediation 三要素）。
§5.1 至此无未落项，文档注记关账。

- `cargo test --workspace --no-fail-fast`：**565 passed / 0 failed**；census 562/70 → **565/70**；
  `TEST_FLOOR` 562 → 565；clippy 31（≤32 不动）。
- 证伪：`scripts/falsify_round40.py` **3/3 全咬**。

## 下一步

1. 有界阻塞池（`ADR-039 §8` 留的真阻塞端口前提，需要设计）。
2. `OVERLOAD §5.2/§5.3` 的未落项复核（同 §5.1 的验证式关账法）。

---

## 第四十一轮（2026-08-29）：一轮四题

**① OVERLOAD §5.2 验证式关账**：queue full 的 `retryable=true`/`retry_hint=RetryLater`/类别/
数字、storage-busy 的 `Busy` 类型、入队前 CAS 拒绝不留 job——表达要求全部已有裁判，复核后
关账（我首轮侦察曾误判"retry hint 缺失"：grep 字面 `retryable: true` 不中，实际是 bool 字段
赋值——**先读测试再断言缺口**）。

**② 出站帧上界（第三十轮注记点名的另一半）**：`encode_raw_json_bounded`——超
`MAX_FRAME_SIZE_BYTES` 的响应在成为帧之前被拒，错误点名字节数与上限；`encode_raw_json`
保留原形给握手（协议自身封顶的小消息）。server_loop 三处调用点全部走 bound。裁判两处
（ipc：恰在界内是帧/超一字节拒/legacy 形状不变；daemon：server_loop 超界拒、小载荷照旧）。

**③ `latest_support_bundle_digest` 选择规则首次有裁判**：最新时刻胜、同刻 tie-break 按
digest 确定（两次同问同答）、更新的非 bundle 不因日期取胜、无 bundle 时 `None`、无时间戳
记录（带外造，文件名用 `escape_component`——R39 知识直接复用）输给任何有日期的。

**④ §5.3 诚实注记**：传输层 `StreamPayload::Reset`/`ClientStreamHealth` 就绪，daemon 的
`FollowJobStream` 仍是 stub（`Ok(None)`，§4.21 式混同）——流式 follow 属 Phase 6，不划项
不冒充。

- `cargo test --workspace --no-fail-fast`：**570 passed / 0 failed**；census 565/70 →
  **570/72**（两个新测试文件）；`TEST_FLOOR` 565 → 570；clippy 32 不动。
- 证伪：`scripts/falsify_round41.py` **4/4 全咬**（codec 解除 / server_loop 绕回无界 /
  tie-break 删除 / kind 过滤删除）。

## 下一步

1. 有界阻塞池设计（`ADR-039 §8` 留真阻塞端口前提）。
2. Phase 6 传输运行时（流式 follow 接线——§5.3 判据已就绪）。

---

## 第四十二轮（2026-08-29）：StdHttp——Http 端口的第二个后端 + 共享契约

**① `StdHttp`（真基建）**：纯 HTTP/1.1 over `std::net`、无外部 crate。`https` 以
`Unsupported` 拒并点明教义（RFC-0001 §1.4），不冒充连接失败——静默降级是那次 M4 变异
证伪的形状。传输上界 = `byte_ceiling(ctx, max_body_bytes)` 较紧者，流式计数、超界即停、
声明超界不读全量。条件请求（etag/if_modified_since）发出且 `304` 原样作答。label 按
ADR-040 钉形。**共享契约** `http_fetch_contract_violations` 新入 `caly_io::contract`：
sim（脚本）与 std（本地脚本服务器）以同一闭包场景跑同一裁判——`RFC-0006 §15` 对 Http
自此生效。首跑该契约就抓到两次 `http://` vs `http:` 前缀笔误（我犯在契约与 StdHttp 各
一处，sim/std 裁判各咬一次）。

**② 删 `EngineHandle::get_object`**：全仓零引用死 API + R36 漏网的 `store_ctx` 幽灵。
无消费者即无能力；其余 store_ctx 站点经逐点分类全部是引擎自发工作（bundle 生成、执行器
journal 写），ADR-039 §2.4 合规。

**③ OVERLOAD §6 逐条复核**：六条点名裁判（overload / cutover_intent_guard /
store_suspension / job_events），两条诚实不划（Platform Phase 8、recovery-aware 重试语义
待 Phase 6）。

- `cargo test --workspace --no-fail-fast`：**575 passed / 0 failed**；census 570/72 →
  **575/73**（新 `http_contract.rs`）；`TEST_FLOOR` 570 → 575；clippy 31（≤32 不动）。
- 证伪：`scripts/falsify_round42.py` **4/4 全咬**（label 失形 / 传输上界弃用 / 条件头
  不发 / https 静默降级为明文尝试）。

## 下一步

1. 有界阻塞池设计（`ADR-039 §8` 前提，需要设计先行）。
2. Phase 6 传输运行时（流式 follow 接线；`Proc`/`Platform` 端口的 std 侧）。

---

## 第四十三轮（2026-08-29）：里程碑——calyd，可执行程序 0 → 1

**bin（组合根）**：`crates/caly-daemon/src/bin/calyd.rs`——`FsStore`+`StdFs` 落盘、`StdClock`
注入（store `with_clock` + daemon `set_storage_clock` 同源，期限换算可用）；bin 是 workspace
里唯一组装真适配器的地方，`caly-io`/`caly-io-std` 因此提为 daemon 产依赖（注释 + arch 门
`ALLOWED_DEPENDENCY_EDGES` 带理由声明；lib 仍注入存储，ADR-011 不变）。

**v0 wire（诚实最小）**：`[kind u8][len u32 BE][键值记录]`——**不谎称 JSON**：全量 op 序列化
是 Phase 6 传输运行时的工作，v0 假装会说就是协议形状的 stub。帧帽双向：入站超
`MAX_FRAME_SIZE_BYTES` 拒读（连接终结），出站经同一常量。**一条白名单查询**
`runtime.status` 经完整 `DaemonTransport`（握手→ack 点名 daemon/instance、会话序、角色门
都是未来一切 op 的路径）；九字段全上 wire（空值也在）；白名单外 op 按名拒（点名所问与
唯一在册者）；hello 前请求拒。

**E2E 裁判（`calyd_wire.rs`，spawn 真 binary）**：port-file 机制免 sleep-and-hope。cap 裁判
首版把 write 期 RST 当 panic——**中途断连就是拒收**，judge 语义修正为"连接必须终结且不得
作答"（拒帧=先吞后答，恰是被禁形状）。clippy 禁用表按 `caly-io-std/clippy.toml` 先例以
文件级 `#![allow]`+理由豁免（spawn harness 本职）。

**顺带记录**：有界阻塞池按"无消费者即无能力"教义**继续推迟**（无并发事件循环的消费者，
建了就是无裁判的基建；ADR-039 §8 前提在 Phase 6 事件循环落地时一并满足）。

- `cargo test --workspace --no-fail-fast`：**579 passed / 0 failed**；census 575/73 →
  **579/74**；`TEST_FLOOR` 575 → 579；clippy 32 不动；ROADMAP §1bis.2 改写（0 → 1）。
- 证伪：`scripts/falsify_round43.py` **4/4 全咬**（hello 前请求被答 / 帧帽吞掉超界 /
  字段遗忘 / 白名单敞开）。

## 下一步

1. Phase 6 传输运行时：v0 wire 之上的 JSON 帧编码面、并发连接、流式 follow（§5.3 判据已备）。
2. `caly-cli` 可执行（`caly-io-std/clippy.toml` 的 `Command` 禁令留给 Platform 决策）。

---

## 第四十四轮（2026-08-29）：caly CLI——可执行 1 → 2，wire 单一真源，一个真缺陷

**① `caly_ipc::wire`**：v0 wire 编解码从 calyd 内联提取为共享模块（帧头/键值转义/双向帧帽，
3 条单测：转义单射、记录解析、超界不触碰流）。calyd 与 CLI 同一 codec；E2E oracle **故意**
自持最小实现作对照——两实现一致才是证据。

**② `caly` CLI**（`caly-cli` 新 bin target）：`caly status --addr host:port`——hello、
`runtime.status`、九字段打印（空值也在）。退出码按 `EXIT_CODES.md`：0 成功、2 用法错（不碰
网络）、11 超时、12 不可达（点名地址）、13 会话拒。E2E 3+1 条：与 oracle 逐值对齐、死端口
exit 12、缺 `--addr` exit 2、哑服务端 exit 11。

**③ 变异 M1 揭出真缺陷**：跳过 hello 的客户端与等待的 daemon **双方无读超时互等死锁**
（两次 harness "挂死"的真相）。挂死的变异不是坏变异，是对产物的发现：当轮双侧补界——CLI 读
超时 3s → exit 11；daemon 空闲连接 5s 终结（单连接 daemon 被哑客户端楔死的服务面问题一并封
掉，裁判 `a_silent_connection_is_ended_by_the_daemon_not_held_forever`）。修后 M1 才咬。

**④ 工具教训（§4.137）**：内联 falsify 脚本把备份写在循环外，M1 restore 即消费、M2 变异残留
源码——被测树被自己的工具污染。恢复后按规程（每变异独立备份）补跑 M3/M4。

- `cargo test --workspace --no-fail-fast`：**587 passed / 0 failed**；census 579/74 →
  **587/76**（`caly_cli_e2e.rs` + `wire.rs` 单元）；`TEST_FLOOR` 579 → 587；clippy 31
  （≤32；新增代码 0 warning：`strip_prefix` 重写转义链、doc 合并）。
- 证伪：4/4 全咬（跳 hello / 不可达 exit 0 / 字段丢弃 / 答案捏造——oracle 对照裁判）。

## 下一步

1. Phase 6 传输运行时：JSON 帧面（全 op 序列化）、并发连接、流式 follow。
2. CLI 子命令扩展（随传输运行时）；`Proc`/`Platform` std 侧。

---

## 第四十五轮（2026-08-29）：并发连接 + doctor 上 wire

**① calyd thread-per-connection**：R44 的空闲超时救了单个客户端，但单连接循环让哑客户端
**挡住所有人**（第二个客户端要等第一个的超时）。线程化后哑连接只花自己的超时；裁判：哑客户端
占位时第二个客户端 3s 内被完整服务（M1 退化回串行即红）。

**② wire 第二个在册 op `diagnostics.doctor`**：三层分离照 `DoctorReport` 教义（一个桶招占位
符模式）、每行索引（客户端能分"没有第三条"与"忘了"）、`truncated` 随行、计数==随行行数
（计数撒谎即红）。拒词改为点名**两个**在册 op。

**③ CLI `caly doctor`**：三层各归其位打印，与独立 oracle 逐行对齐。

**判据三修（同轮自纠，都是 oracle 设计课）**：oracle 没做值解转义（CLI 正确解了 `%3D` 反被
咬——oracle 必须独立实现**完整文档格式**）；计数行前缀撞名（`warning_count` 以 `warning_`
开头被数成行——按纯数字后缀过滤）；gc 行带活时钟读数（两次对话必不同——按稳定前缀判）。

- `cargo test --workspace --no-fail-fast`：**590 passed / 0 failed**；census 587/76 → **590/76**；
  `TEST_FLOOR` 587 → 590；clippy 32 不动（oracle 的 manual_strip 改 strip_prefix 链）。
- 证伪：`scripts/falsify_round45.py` **4/4 全咬**（退化回串行 / doctor 掉白名单 / 计数撒谎 /
  CLI 吞层）。

## 下一步

1. Phase 6 传输运行时主体：JSON 帧面（全 op 序列化决策）、流式 follow（FollowJobStream）。
2. `Proc`/`Platform` std 侧（Platform 决策先行）。

---

## 第四十六轮（2026-08-29）：真查询面第一组上 wire + 期限一分为二

**① `profiles.list` 上 wire**（第 3 个在册 op）：`profile_count` + `profile_{i}_id/label/active`
索引行。裁判钉四件事：计数==id 行、id 唯一、**至多一个 active**、计数之外无行（静默加行=未计数
的 profile）。默认 profile 恒在——"诚实的空清单"也是一行。

**② `profiles.get` 上 wire**（第 4 个、**第一个带请求参的 op**）：缺 `profile_id` 点名 USAGE
拒绝**不猜默认**（M3：`.unwrap_or("default")` 变异被咬）；拒绝是应答不是断连——同一连接下一个
良构请求照答；视图**回显所问 id**（M4：恒答 default 被咬——两个视图都合法，答非所问仍是错）。

**③ CLI `caly profiles` / `caly profile <id>`**：对独立 oracle parity（oracle 自持 wire 对话，
含转义）。取参**不得吞旗标**：`caly profile --addr x` 里落在 id 位的 `--addr` 算 id 缺席——
e2e 首跑咬住（CLI 把 `--addr` 当 id、地址值成了未知参数）。

**④ 期限一分为二**：R45 一个 `HELLO_IDLE_TIMEOUT` 管两侧——会话侧"自己的期限"**不可证伪**
（删掉它，socket 上残留的 hello 期限照样 5s 收割，裁判无从分辨）。拆成 `HELLO_TIMEOUT`（5s，
陌生者）+ `--session-idle-ms`（默认 30s，会话——操作员对"已登录者可以静多久"有分歧，所以是
旋钮）。裁判用 1.2s 旋钮 + 时钟断言钉死：做收割的是会话期限，不是残留的 hello 期限（M5）。

顺带修 R45 漏账：calyd 头注仍写 "answers exactly **one** query"（doctor 已是第二个 op）。

- `cargo test --workspace --no-fail-fast`：**595 passed / 0 failed**（calyd_wire 7→10、
  cli e2e 5→7）；census 590/76 → **595/76**；`TEST_FLOOR` 590 → 595；clippy 基线不动。
- 证伪：`scripts/falsify_round46.py` **6/6 全咬**（list 掉白名单 / 计数谎报 / 缺参猜默认 /
  回显恒 default / 会话期限移除回落 hello 期限 / CLI 吞 label）。

## 下一步

1. Phase 6 传输运行时主体：JSON 帧面（全 op 序列化决策）、流式 follow（FollowJobStream）、
   reconnect/timeout scheduler。
2. request → command → apply 真执行闭环（`profiles.apply` 上 wire 是第一候选）。
3. `Proc`/`Platform` std 侧（Platform 决策先行）；有界阻塞池（真阻塞端口出现时再议，
   ADR-039 §8 前提复核的结论仍然成立）。

---

## 第四十七轮（2026-08-29）：command 闭环上 wire

**① `profiles.apply` 上 wire**（第 5 个 op、**第一个 command**）：idempotency key 随请求记录
上 wire——`ADR-037` 的原文在裁判里：缺 key 的 apply 是 daemon 自己的点名拒绝（summary 含
`idempotency_key`），daemon 不代铸，**客户端也不代铸**（`caly apply` 缺 `--idempotency-key`
= exit 2——静默铸 key 把每次 shell 重试变成第二次写）。同 key 重放同 job id，新 key 新 job。

**② 内联 drain**：v0 无 worker 线程，接收连接在写 acceptance **之前**排空引擎（有界：永不
settle 的队列被拒不被旋）。客户端读到的 acceptance 已跑完——M2（跳过 drain）证明裁判有牙：
"只接收的队列是假装执行器的队列"。

**③ `jobs.events` 上 wire**（第 6 个 op）：state、`event_count`+索引行（计数==行、计数外无
行——doctor 轮教义的第三次应用）、全部游标字段（`next_from_event_index` 空 = 页到头）。

**④ CLI `caly apply` / `caly jobs`**：acceptance 三字段上纸；`jobs` 与独立 oracle 全串
parity——终态 job 的事件不可变，**无稳定前缀豁免**（与 doctor 的活时钟行相反的两面）。

**⑤ 组合裁判**：apply 之后 `runtime.status` 的 `active_profile` 变为所 apply 的 profile——
查询面必须看得见 command 面做过的事。

- `cargo test --workspace --no-fail-fast`：**601 passed / 0 failed**（calyd_wire 10→13、
  cli e2e 7→10）；census 595/76 → **601/76**；`TEST_FLOOR` 595 → 601；clippy 基线不动。
- 证伪：`scripts/falsify_round47.py` **6/6 全咬**（apply 掉白名单 / 跳过内联 drain /
  wire 吞 key / acceptance 谎报 job id / jobs.events 掉白名单 / CLI 吞事件行）。M2 第一版
  `Ok(0usize)` 推不出 E 不编译不作证（§4.112），改 `Ok::<usize, String>(0)` 后咬住。

## 下一步

1. 流式 follow（`FollowJobStream`）：第一个 stream op 上 wire——`WatchOpened`/订阅/取消，
   IPC_STREAM_POLICY 的第一段真实现。
2. JSON 帧面序列化决策（ADR-034 补记）：typed-frame 序列化归 transport runtime 的承诺兑现。
3. `Proc`/`Platform` std 侧（Platform 决策先行）。

---

## 第四十八轮（2026-08-29）：follow / rollback 上 wire + 分页闭环

**① `jobs.follow` 上 wire**（第 7 个 op）：摘要全字段（state/lifecycle/stage 进度/failure 身份/
窗口计数）。**跨 op 一致性裁判**：follow 的 `event_count` == events 分页的计数——两个 op 看同一
job 是同一投影的两个面，不是两份事实。未知 job = 点名拒绝，不是编造的 summary。

**② `profiles.rollback` 上 wire**（第 8 个 op、第二个 command）：**点名快照反猜**。前提是
实验先教的：同 profile 两次 apply 发布**同一个** revision id（id 是内容不是尝试），所以裁判用
两个不同 profile 造两个快照；点名回滚的 job 事件行记 `target=<所点名>`，吞参变异（恒用
LKG）即红。缺 key 拒绝、同 key 重放同 job（与 apply 同规）。

**③ CLI `caly job` / `caly rollback --snapshot` / `caly jobs --from/--max`**：分页平铺裁判——
截断页必报非空游标、续读到头、两页拼接==整窗（一行不丢、一行不重）。

**当轮自纠两处**：wire 裁判的事件行匹配先补了独立 unescape（`target%3D…`——值转义是文档格式的
一半，R45 的教训这次先行应用）；CLI 分派漏了 rollback 的 print arm（打印成了 status 字段），
e2e 首跑咬住。另记：实验进程曾被自己的 `pkill -f` 模式误杀（命令行含模式串即匹配）——清理
后台进程时模式要带不可误配的锚。

- `cargo test --workspace --no-fail-fast`：**607 passed / 0 failed**（calyd_wire 13→16、
  cli e2e 10→13）；census 601/76 → **607/76**；`TEST_FLOOR` 601 → 607；clippy 基线不动。
- 证伪：`scripts/falsify_round48.py` **6/6 全咬**（follow 掉白名单 / state 谎报 / 吞快照名 /
  CLI 吞 last_stage / CLI 忽略 --from / daemon 吞游标）。

## 下一步

1. 流式 follow（`FollowJobStream`）：第一个 stream op——订阅生命周期（WatchOpened/取消），
   `IPC_STREAM_POLICY` 首段真实现。
2. JSON 帧面序列化决策（ADR-034 补记）：record 键即 JSON 键。
3. `Proc`/`Platform` std 侧（Platform 决策先行）。

---

## 第四十九轮（2026-08-29）：维护对 + 导出对上 wire

**① `system.gc-plan`**（第 9 个 op、查询）：问两遍除活钟外必须全同（`now_unix_ms` 是钟不是
事实）；`now_source` 自报家门（`ADR-038 §3`）；collect/orphan 计数==索引行。

**② `system.gc`**（第 10 个 op、command、key Required）：**门口 bounds 拒绝**——
`max_deletions=0` 是 CONFIG_INVALID 点名且不产生 job（"被安全拒绝的回收不该看到绿行"的更早
一步：坏请求连 job 都不配）；同 key 重放同 sweep；跑过 = 下一张 plan 的 `last_run` 是 Some
（与"从没跑过"是两个答案）。

**③ `diagnostics.support-bundle`**（第 11 个 op、command、**Optional key——无 key 也收**：
重导出不是第二次破坏性写）；digest 在 job 事件行 `object=sha256:…`。

**④ `diagnostics.support-bundle-read`**（第 12 个 op）：digest 回显、content_sha256==digest、
`truncated` 只在真截时为真、**伪 digest 是拒绝不是读**（`RFC-0010 §12.3`）。

**⑤ CLI 四动词**（`gc-plan`/`gc`/`support-bundle`/`bundle [<digest>]`）。烟测先咬两个真 bug：
CLI 给 gc 恒附空 key 记录（空串是 "present but empty" 的另一种拒绝）；gc/support-bundle 落进了
status 的 print arm。参数循环改为 `Vec::IntoIter`（可选操作数要回填，`env::Args` 不能 peek）。

裁判自纠两处：`last_run` 值先 unescape（`deleted%3D0`）；digest 事件行是 `object=sha256:…` 形
（取 digest 不取标签）。再记一课：`pgrep -f` 的模式会匹配含**明文路径**的自家命令行——清理
与使用绝不能混在一条命令里。

- `cargo test --workspace --no-fail-fast`：**613 passed / 0 failed**（calyd_wire 16→19、
  cli e2e 13→16）；census 607/76 → **613/76**；`TEST_FLOOR` 607 → 613；clippy 基线不动。
- 证伪：`scripts/falsify_round49.py` **6/6 全咬**（gc-plan 掉白名单 / collect_count 谎报 /
  gc 吞 bounds 记录 / 恒报 truncated:false / 读吞 digest 记录 / CLI 吞 would_run）。

## 下一步

1. JSON 帧面决策与第一刀（ADR-034 补记：handshake 恒 records、op 载荷按协商编码；
   record 键即 JSON 键；`--json` 与默认输出逐字节同面——事实不随编码变）。
2. 流式 follow（`FollowJobStream`）：第一个 stream op，`IPC_STREAM_POLICY` 首段真实现。
3. `Proc`/`Platform` std 侧（Platform 决策先行）。

---

## 第五十轮（2026-08-29）：JSON 载荷编码第一刀（ADR-034 兑现）

**① `caly_ipc::json`**：扁平字符串值 JSON 对象——**record 键即 JSON 键**，值为同样的字符串。
转义双向往返（`=`/`%`/换行 与 `"`/`\`/`{` 两面的分隔符都要活着）；畸形点名拒绝不修补
（尾随垃圾/数字值/裸词/自造转义/悬逗号）。

**② 协商**：hello `encoding=json` → 会话所有 op 载荷（请求/响应/拒绝）为 JSON。三条边界：
握手帧恒 records（元语言不随载荷编码变）；未知编码 HANDSHAKE 点名拒；**一个会话一个编码**
（坏 JSON 的 USAGE 拒绝本身也是 JSON）。

**③ 编码不换事实裁判**：同一 daemon 双会话问同一 op，键值集除 `request_id` 外全同——
**编码改变事实的写法，绝不改变有哪些事实**。

**④ CLI 全动词 `--json`**：输出=daemon 的 JSON 原文一行；e2e 自带独立扁平 JSON oracle
对 records oracle 逐键比对。

**裁判当轮自纠三处**：json 会话的请求也必须是 JSON（裁判第一版送了 records 形状，被
daemon 正确拒绝——"一个会话一个编码"是双向的）；parity 必须排除 request_id（标识对话
不标识事实）；文档锚里"（伪 digest"实况是"；伪 digest"——**标点也是实况**。

- `cargo test --workspace --no-fail-fast`：**623 passed / 0 failed**（ipc 单测 3→8、
  calyd_wire 19→22、cli e2e 16→18）；census 76→**77** 文件、613→**623**；
  `TEST_FLOOR` 613 → 623；clippy 基线不动。
- 证伪：`scripts/falsify_round50.py` **6/6 全咬**（daemon 无视协商 / 转义丢弃 /
  尾随垃圾被宽恕 / 未知编码被吞 / CLI 不协商 / --json 打印人话渲染）。
- ADR-034 补"落地记录（第五十轮）"。

## 下一步

1. 流式 follow（`FollowJobStream`）：第一个 stream op——订阅生命周期（WatchOpened/取消），
   `IPC_STREAM_POLICY` 首段真实现。
2. `Proc`/`Platform` std 侧（Platform 决策先行）。
3. JSON 面第二刀（若真需要）：非字符串值的类型化——等第一个真的需要数字键值的调用方
   出现再议（收窄优先，ADR-034 补记原文）。

---

## 第五十一轮（2026-08-29）：第一个流

**① `job_stream.rs` 纯泵**（`IPC_STREAM_POLICY` 首段真实现）：Job 流=LosslessResumable、
Ack Required、gap 不 reset。喂"从 cursor 起读的页"，每步一答——Data（新行+游标）、Gap（报
resume 位置，**无损流绝不跳**）、End（终态且行已冲净——**先行后终**，End 早到=对完整性撒谎）、
Wait（无新闻不推空帧）。非终态不猜判决；`timedout`（`{:?}`-lowered）→TimedOut。

**② wire 帧类 6/7 + 第 13 个 op `jobs.follow-stream`**：opened→DATA→END 三帧契约；流帧走会话
载荷编码（JSON 会话里流帧也是 JSON——一个会话一个编码延伸到流）；DATA 计数==events 分页计数
（跨 op 一致性延伸到流）。v0 引擎内联 drain，job 在任何客户端能问之前已终态——泵重放窗口后
即 END，活增量随 worker 线程到来；ack 在 v0 由单连接有序帧隐式承载，显式 ack 属 reconnect 路。

**③ 幽灵流真 bug**：allocate 不查 job 存在——未知 job 先收 opened 帧再收拒绝。诚实形状是
**opened 之前先查**（探测页顺便喂泵第一步）。裁判咬住后修。

**④ `from_event_index` 是 exclusive 游标**（from=3→从 4 起）——与 `next_from_event_index`
同一契约；裁判第一版按 inclusive 写期望，自己红了。

**⑤ CLI `caly follow <id> [--from N]`**：流式打印；退出码=判决（0/1/15/11；state-gap=14
CURSOR_STALE 带 resume 提示）；`--json` 打印帧原文。

- `cargo test --workspace --no-fail-fast`：**634 passed / 0 failed**（daemon lib 19→25、
  calyd_wire 22→25、cli e2e 18→20）；census 77→**78** 文件、623→**634**；
  `TEST_FLOOR` 623 → 634；clippy 32 不动（泵的 Default 当轮补）。
- 证伪：`scripts/falsify_round51.py` **6/6 全咬**（泵吞 gap / 泵先行后终被破 / END 恒报
  Succeeded / DATA 掉首行 / CLI 忽略 DATA / CLI 失败判 0）——全部非挂起形状。

## 下一步

1. reconnect/resume 路：显式 ack 帧 + `last_emitted_seq`/`acked_upto` 的重连续传
   （`StreamCursorState` 已有，wire 侧未接）。
2. `Proc`/`Platform` std 侧（Platform 决策先行）。
3. worker 线程（让"活增量流"从裁判不可达变为可判）。

---

## 第五十二轮（2026-08-29）：reconnect / resume 路

**① 帧类 8（STREAM_ACK）**：**ack 是对话不是喊话**——daemon 答 `acked_upto` 确认帧；客户端读到
它才有"已记账"的确定性屏障（否则重连存在调度竞态）。泵先写后读，确认帧必是 END 之后的对话
最后一帧——CLI 因此改为"END→发 ack→读确认→退出"（一对话一 ack 取最终游标）。

**② 服务端流表**（有界 64，条目记 job/acked/last_emitted）：**满了点名拒**（STREAM_CAPACITY）；
静默逐出更糟——被逐流的 resume 会从没人记得的位置作答。

**③ 至少一次投递**：resume 游标取 **acked**（调用方确认过的），绝不取 last_emitted（服务端
碰巧发出的）——未 ack 断线重连=全量重放，acked=空 delta。resume 保留**逻辑流 id**。

**④ CLI `caly follow --resume <stream-id>`**：stderr 报流 id；打印过的即 ack；acked resume
零重印。

- `cargo test --workspace --no-fail-fast`：**639 passed / 0 failed**（calyd_wire 25→29、
  cli e2e 20→21）；census 634/78 → **639/78**；`TEST_FLOOR` 634 → 639；clippy 32 不动
  （三处新债当轮清：`mut extra`、`unused_assignments` allow、`_end`）。
- 证伪：`scripts/falsify_round52.py` **6/6 全咬**（resume 忽略 acked / ack 被丢 / 未知流
  被当新开 / emitted 替代 acked / 容量帽移除 / CLI 永不 ack）。M3 变异体自带 fallback
  助手以可编译（§4.112）。

## 下一步

1. `Proc`/`Platform` std 侧（Platform 决策先行）。
2. worker 线程（活增量流从裁判不可达变为可判；泵的 Wait 分支今天只有预算上限在行使）。
3. 断线检测/心跳（session 层 `force_hello_timeout` 既有，wire 侧未接）。

---

## 第五十三轮（2026-08-29）：worker 线程、断线收割、ADR-042、非数值门口

**① worker 线程（acceptance=已排队）**：接收连接不再内联 drain——R47 的"读到 acceptance 已跑完"
形状退役，唯一 drainer 是后台线程，按 `--worker-tick-ms`（默认 25，0 在旗标处拒绝——自旋不是调度）
每 tick ≤1 job。一个 tick 就是一个活窗口：慢 tick（800ms）下第二连接**立刻**查到 `state=accepted`/
0 事件——查询面第一次看得见"存在但尚未发生"的 job。e2e 迁移：所有"apply 后立即读终态"的裁判补
`wait_for_terminal`/`oracle_wait_terminal`（**daemon 自报的状态是唯一不说谎的钟**——墙钟 sleep 只是
把竞态重建一遍）；follow 类裁判天然自同步（泵自己等到 END）。

**② 活增量流从裁判不可达变为可判**：follow 在首 drain 前打开——opened 帧之后 300ms 静默窗内不得
有 DATA（有=又内联了：窗口远短于 800ms tick， margins 双侧安全）；worker 的 tick 到点化作 DATA、
END 带判决。泵的 Wait 分支从"只有预算上限在行使"变为真行使（探测页看见 accepted/0 事件 → Wait）。

**③ 断线收割**：泵 Wait 期零字节 peek 探活（50ms 读超时；`Ok(0)`=EOF、超时=活着沉默、字节留给
END 后的 ack 对话）。弃线客户端花费**一个 wait tick**（5s tick 裁判里 2.5s 期限内 stderr 必出
reap 行），而非整个 tick 预算、也不等下一次写失败（≥5s——两者可区分正是本题可证伪的关键）。
收割≠楔死：新连接照常被服务。被动探活而非心跳协议——心跳是双端协议，等"中间人吞空闲连接"的
真实部署证据再议（ONBOARDING §6.86 留档）。

**④ `ADR-042`（spawn 与特权面拆开）**：`StdProc` 落 std——shell-free（`program` 直 exec，argv 是
字面向量）、cwd 网关根（`StdFs::resolve` 同规 + **fork 前 `is_dir` 分诊**：OS 层缺程序与缺 cwd 同为
ENOENT，不预检就把两者都归因程序名是撒谎——§4.138，首测当轮咬住当轮修）、stdio 全 null（遗忘的
子进程不替 daemon 握客户端 socket）、`NotFound`/`PermissionDenied` 点名映射、nonce=序号+pid（宿主
回收 pid，单 pid 不区分实例）。`Command::new` 禁令按 `ADR-035`/`ADR-014` 先例在
`caly-io-std/clippy.toml` 定点豁免（其余 crate 一个不动）。`SimProc` 对齐空程序名拒绝；共享
`proc_spawn_contract_violations`（两闭包形状，同 fetch 契约先例）两后端同判——**契约表
`RFC-0006 §15` 七条全有载体**。`Platform` **决策性缺席**：恒报 false 的 `StdPlatform` 是没人核对
过的能力承诺，比缺席更糟；落地条件与 `SpawnCore`/`StopCore` 真接线同到。

**⑤ 非数值参数门口**：`numbered_bound`——数值记录"在场但不可解析=USAGE 点名拒绝"，废除
`.parse().ok()` 静默默认。`max_deletions=abc` 曾变"无界"（ADR-038 §2 要防的恰是这个）、
`from_event_index=abc` 曾变"从头全量重放"（垃圾游标静默重放是可证伪 Worst case）、grace_period_ms/
max_lines/max_bytes 同规；拒绝不吞 key 不产 job（同 key 诚实重试仍开 job）。

- `cargo test --workspace --no-fail-fast`：**647 passed / 0 failed**（calyd_wire 29→32、
  io-sim contract 18→19、proc_std 新文件 4）；census 78→**79** 文件、639→**647**；
  `TEST_FLOOR` 639 → 647；clippy 基线不动。
- 证伪：`scripts/falsify_round53.py` **6/6 全咬**（acceptance 恢复内联 drain / **worker-tick 旗标
  被忽略** / Wait 探活摘除 / spawn 失败吞成假手柄 / env 注入被丢 / 数值门口回退成 `.ok()` 吞噬）。
  M2 初版是「worker 永不排空」——目标裁判 10s 内红，但无关的流测试各爬满 10_000 tick 泵预算
  （预算≠秒级期限，64 流裁判=小时级），实为挂起形状；重设计为旗标忽略变异，harness 补 15 分钟
  硬超时、楔住=DID NOT BIT 点名（§4.139：变异的形状承诺由机器说了算）。竞态双跑被击杀后备份链
  传播过 M6 毒化基线（sha256 只对进程内基线负责）——按内容标志重建后全套重跑。

## 下一步

1. `SpawnCore`/`StopCore` 真接线（消费 `StdProc`，带来 wait/kill/收割的新决策——`ADR-042 §5` 划线
   届时按新 ADR 修订）。
2. `Http` 的 `FetchRoute::SystemProxy`/`ActiveCore`（有 `Proc` 之后路由两级才有意义）。
3. 候选池遗留：有界阻塞池（真阻塞端口出现时再议，ADR-039 §8）、gc/bundle 数值域门口
   （`grace_period_ms<0` 这类解析成功但值域非法的——本轮只关了"不可解析"这半）、
   JSON 面第二刀（等真调用方）。

---

## 第五十四轮（2026-08-29）：真内核第一刀——mihomo、geo、ADR-043

**① `ADR-043` Proc supervision 最小面**：`ChildExit{code,signaled}`（数字，以及数字是它自己选
的还是信号替它选的——压平成一个数会让"退出码 9"与"被信号 9 杀死"变成同一个答案）；
`try_wait` 非阻塞且**退出单调回放**（会忘退出的端口让"死了吗"在最要紧时不可回答）；
`stop(grace)` 宽限窗口属子进程（期内自然退出如实报告）、期满 SIGKILL（std 唯一信号）；
std 侧端口负责 **reap**。TERM 显式不做：`/bin/kill` 间接触发被否决存档（把发信号变成再
spawn 一个进程），诚实来源是未来信号面端口生长或核心自身 API 关停。

**② 真内核与 geo 入库**：mihomo v1.19.30（amd64 基线，gz 18.9MB）＋geoip.metadb（8.6MB）＋
geosite.dat（4.3MB）下载入 `assets/`，**sha256 钉死在裁判常量里**——`RFC-0010 §14` 第 5 条
"下载校验"从文档变门禁：漂移即红且点名文件与两个 digest；缺资产=按名红，绝不 skip。

**③ 全生命周期经端口**（`real_core.rs`）：spawn→`try_wait`=还在跑（不是猜）→核心自己的
控制器 `/version` 经 **Http 端口**答 200（健康判据=状态码——`ByteStream` 按 `ADR-040` 是标签，
拿不到 body 是诚实现状）→`stop` 宽限期满击杀（`signaled` 断言钉住归因）→退出单调回放→
mixed/controller 双端口归还（"还握着端口的停止不是停止"）。

**④ geo 承重**：GEOSITE/GEOIP 规则下缺 geo=**确定性 fatal**——`-t` 层点名 GeoSite 缺失、端口层
观察 fatal 自退。**geox-url 指向 127.0.0.1:1**：沙箱有网络，"缺文件就顺手下载"必须**结构上
不可行**，不是碰巧不便——这是"值不可解析就不许猜含义"的资源版教义。

**⑤ 同轮自纠**：VPath 不能表达"根自身"（`.` 不是段）——真内核 spawn 改 `-d` 绝对路径、cwd
网关特性仍由 `proc_std` 专测承载；`StdHttp` 是单元结构体（无 `new`）；契约闭包返回 `Result`
不解包。**⑥ ops 咬出的测试卫生缺陷**：real_core 每次运行解压两个 ~50MB 核心目录且从不清理——
证伪连跑五个变异套件后 `/tmp`（993M tmpfs）报 **no space left on device**（连进程都起不来）。
修法=`ScratchDir` Drop 守卫（测试结束自清，79M+67M/次归零）；教训：**重资产的测试夹具自带
生命周期债**，census 里看不见，直到把 tmpfs 填满。

- `cargo test --workspace --no-fail-fast`：**652 passed / 0 failed**（io-sim 契约 19→20、
  proc_std 4→5、real_core 新文件 ×3）；census 79→**80** 文件、647→**652**；
  `TEST_FLOOR` 647 → 652；clippy 基线不动。
- 证伪：`scripts/falsify_round54.py` **5/5 全咬**（try_wait 恒报在跑 / stop 伪造退出不击杀 /
  仿真 stop 用击杀覆盖自然退出 / spawn 不注册进监督表 / 信号位被压平）。

## 下一步

1. **`EngineHandle` 的 `EffectRuntime` 解绑**（ROADMAP"后端可替换性"effects 半边）：
   `Arc<dyn EffectRuntime>`＋daemon 组合根注入——本轮原语（spawn/probe/stop/geo 资产）已齐，
   `SpawnCore/StopCore/Probe` 的 std 后端是直通路。
2. `caly-singbox` 真内核（第二核心，验证 `CoreKind` 分派不是 mihomo 特判）。
3. 候选池遗留：`Http` 路由两级、有界阻塞池（ADR-039 §8）、gc/bundle 数值域门口、
   JSON 面第二刀（等真调用方）。

---

## 第五十五轮（2026-08-29）：真 effect 后端第一刀——同一 executor 跑真核，ADR-044

四题全交付，全绿（census 82 文件 / **656** 断言、TEST_FLOOR 656、clippy 32、证伪 5/5）。

1. **引擎解绑**（批次 1）：`EngineHandle` 的 `effects` 从具体 `SimulatedRuntime` 改为
   `Arc<dyn EffectRuntime>`；`with_effect_runtime` / `clone_with_effect_runtime` /
   trait accessor 三面；sim 世界归测试自持（`sim_handle()` 模式）。新裁判
   `effect_runtime_swap.rs`（CountingRuntime：注入面被调 >0 且两世界一致）。
2. **`StdEffectRuntime`**（批次 2，`caly-daemon/src/effect_std.rs`＋ADR-044）：WriteObject
   **核实**在库、Materialize 真字节真文件、SpawnCore 从钉死资产起真核（`/bin/sh -c
   "gunzip … && exec ./core …"`，pid 即核 pid）、ApiReady 真问 controller、StopCore 经
   `ADR-043` 端口真杀真收割；**拒绝面全部按名拒绝**（NetApply/NetRevert 点名 ADR-042
   §2.2、DbTxn、CoreApiCall 除 Status、Probe 除两种、双重 spawn＝`instance-already-running`
   不孤儿化）；信封模型＝artifact＋operational keys（geox 指向 127.0.0.1：geo 缺席＝响亮
   fatal 非静默下载）；`shutdown/live_pid/controller_ready` 操作面；`DaemonApp::
   set_effect_runtime`＋`engine_storage`（runtime 必须核 **同一个** store 实例）。
   engine re-export `caly-plan` 步骤类型（呈现层，不加依赖边）。
3. **渲染真相四处**（真核首跑咬出，全部对着真二进制验证后修）：规则目标必须指渲染组
   **标签**（指 id＝`proxy not found` fatal）；`dns.enhanced-mode` 只认
   fake-ip/redir-host/**normal**（mixed/system＝fatal `invalid mode`，IR 的 System/Mixed
   坍缩到 normal）；ss/vmess/vless/trojan 必填参数经 `ProxyNode.passthrough` 逐键透传
   （`merge.rs` 合成侧填结构性占位——值惰性键承重，IR 无凭据模型记缺口）；组内
   `interface-name` 是假选择，删（选择经组序到核）。另：失败 job 的 detail 带步骤自己的
   拒绝语（`worker.rs` 拼 status.summary），`unsupported-net-apply` 操作员终于读得到。
4. **补偿集扩充＋真核三裁判**（批次 3，`real_apply.rs`）：spawn 型计划的补偿从"零"扩为
   stop-core → un-materialize → net-revert（逆序执行），`compensate(StopCore)` 真停。
   裁判：nightshift 全链（pid 在 `/proc`、controller 真答 `/version`、收尾真停）；rollback
   真停核＋撤文件（对着进程表断言）；demo-tun 诚实拒绝（detail 点名 ADR-042、无核无文件
   不激活）。**顺带发现**：demo apply 规划恒 first-install（`current=None`），Restart 计划
   的 StopCore 分支不可达——restart 裁判因此改判 rollback 序列（真停核的可达真形状），
   缺口记入 ADR-044 §5.3。
5. **ADR-044**＋索引（RFC_ADR_CRATE_INDEX 增 042/043/044 组、daemon 行挂 effect_std）、
   `scripts/falsify_round55.py`（M1 spawn 换 /bin/true、M2 补偿停核伪造退出、M3 NetApply
   假装成功、M4 撤文件拆掉、M5 dns 退回 mixed——**5/5 全咬全恢复**，清扫
   `caly-run.yaml` 模式不匹配 harness 自身）、census/TEST_FLOOR 652→656、本日志。

### 教训（第五十五轮）

- **§7 首跑即雷**：模拟世界的"渲染已验证"只是"sim 没意见"；真核第一跑咬出四处
  fatal/假语义。新后端的第一条裁判永远是"拿真东西跑一遍"，不是"把类型对上"。
- **§8 猜 API 形状必错**：`BlockFuture` 的路径、`DnsMode::Mixed` 的字符串、`WriteObject`
  的字段穷尽——凭记忆写的第一版 13 个编译错。先 `grep` 真签名再写调用。
- **§9 孤儿核的两个来源**：计划层（补偿集为空）与 runtime 层（二次 spawn 覆写 handle）。
  修法各归各：计划补 StopCore 补偿；runtime 双重 spawn 拒绝。只修一层＝另一半还在漏。

## 下一步

1. **apply 规划喂 `current`**（ADR-044 §5.3）：把 active snapshot 的 artifact 作为当前
   真相交给规划——Restart 计划的 StopCore（旧核真停）从"不可达"变"可达"，restart 裁判
   回归本位。
2. `caly-singbox` 真内核（第二核心，验证 `CoreKind` 分派不是 mihomo 特判；
   `unsupported-core` 拒绝面已有）。
3. 候选池遗留：`Http` 路由两级、有界阻塞池（ADR-039 §8）、gc/bundle 数值域门口、
   JSON 面第二刀（等真调用方）、binary_digest 真摘要（计划带真包摘要即可裁判错配）。

---

## 第五十六轮（2026-08-29）：current 的真相——apply 对着最后部署规划，ADR-044 §5.1/§5.3 结清

四题全交付，全绿（census 83 文件 / **659** 断言、TEST_FLOOR 659、clippy 32、证伪 5/5、
真核五裁判、check ×2）。

1. **规划喂 `current`**（§5.3 结清，ADR-044 §7 增补）：`EngineState.last_compiled_artifact`
   ——apply 走到 `snapshot.committed` 才记（失败不改写记忆）、rollback 置 None（补偿之后
   "不知道什么在跑"就是真相，下一个 apply 诚实按 first install 规划）；worker 以
   `plan_apply_request_with_current` 接线；`ApplyWorkflowResult` 携带 `compiled_artifact`；
   `apply_workflow_from_handle` 那个被忽略的 `_handle` 参数终于用上了。
2. **计划形状语义修正**（adapter）：跨 profile 变更判 **Restart**（reload 只重读核心自己
   的配置路径，换 profile 换的是物化路径——判 HotReload 等于先设一个必失败的 identity
   探针）；同 artifact 再 apply 判 **Noop**——无步骤无 spawn，journal 以 `noop:<digest>`
   点名（与真计划 id `mihomo-effect-plan-…` 不可碰撞；`build_storage_projection` 的
   "must have plan"假设被 Noop 首次触达而咬红，如实修复）。
3. **binary_digest 真摘要**（§5.1 结清）：`caly_mihomo::MIHOMO_BINARY_SHA256`（资产
   sha256，钉死裁判在 real_core.rs）；`StdEffectRuntime::SpawnCore` 对**将部署的字节**
   算 sha256 核对（不是文件名、不是记来的常量），错配 `binary-digest-mismatch` 点名拒绝
   （两个摘要都在拒绝语里）＋单元裁判（拒绝发生在任何落盘之前）。读一次、哈希、比对、
   同字节落盘——不读第二遍。
4. **裁判与证伪**：`real_apply.rs` 五裁判（restart 赎回：旧核被计划的 StopCore 真停；
   Noop：同 pid 不动、summary "Noop"）；`falsify_round56.py` M1 跨 profile 卫兵拆掉 /
   M2 摘要差一字符 / M3 worker 回退 None / M4 检查压平 / M5 Noop 判定投毒——**5/5 全咬
   全恢复**。ripple 三处如实修：parity 类测试的前提升格为"相等初始状态"
   （`run_write_parity` remote 侧独立 daemon；dedup 跨路径与 bundle 回读这两个**以共享
   状态为定义**的断言走同一 daemon 的第二个 client）、budget_parity 同修。

### 教训（第五十六轮）

- **§10 "从未可达"的路径里藏着从未工作的代码**：`current` 恒 None 使 Noop 计划在 demo
  路径上不可达，`build_storage_projection` 的"必有 effect plan"假设从未被触达——接线第
  一跑即咬红。新路径的第一条裁判永远是"让它真的跑一遍"。
- **§11 身份是核自报的，不是我们写下去的**：曾把 sim 的 reload 建模成"自动采纳新物化
  身份"，`stale_live_identity` 裁判咬住——那正是 R55 §7 那种"模拟说绿"，只是这次模拟
  在说谎的方向当了帮凶。建模世界前先问：这个答案是谁的报告？
- **§12 parity 的前提是相等初始状态，不是共享状态**：部署记忆让"同一操作跑两遍"不再
  是同一操作（第二遍是 Noop）。以共享状态为定义的断言（dedup 跨路径）与以相等初始状
  态为前提的断言（逐案对等）要**分开声明、分开构造**，混在一起两头都是假对等。

## 第五十七轮（2026-08-29）：rollback 复活旧部署＋第二核心资产钉——ADR-045

- **复活**：`worker::redeploy_rollback_target`——补偿成功后用**同一 executor、同一
  runtime** 把 target snapshot 的部署装回去（WriteObject→Materialize→Spawn→ApiReady→
  **ConfigIdentity 判 target 摘要**，经 `execute_effect_plan_with_cursor(NoCursor)`）。
  identity 探针是复活的证据：不是"某个核起来了"，是"target 的配置在跑"。复活失败＝
  rollback 失败（补偿已拆、复活未立，红着可见）。记录缺失/非 mihomo/字节已失＝
  出声跳过。复活喂 deployment 记忆：之后再 apply 同 profile 判 Noop。
- **复活裁判咬出两个真缺陷**（都是产品缺陷，不是测试偏差）：
  1. `gunzip -k` 在复用实例目录上拒写已存在的 `core`——spawn 链静默死（stdin 关），
     核未起、探针超时，表象是误导性的"补偿失败"。链上必须 `-kf`。
  2. **快照真相**：apply 把每个提交都标 LKG 且无人降级，虚拟钟按步数计时——Noop
     (1 步) 永远排在被回滚部署 (8 步) 之前，操作员视图一直指着刚拆掉的东西。
     `promote_snapshot_to_last_known_good`：target 抬到最新之上、被替代者降级。
- **第二核心第一刀**：sing-box 1.13.20 资产钉死（`SINGBOX_BINARY_SHA256`，sha256sum
  裁判）；`unsupported-core` 拒绝语改诚实——"资产已钉、缺 spawn 面"，范围决定有日期。
- **M5 揭出第三个真缺陷（sim 保真）**：`ConfigIdentity` 探针在核未报身份时**采纳计划
  期望**（`identity adopted`）——spawn 忘了播种身份，探针替它圆谎，模拟说绿。修：
  未报身份＝失败（`identity-unreported`），探针不替核答题。
- 教义沉淀：ADR-045；census 83→84 文件、659→660 断言、TEST_FLOOR 660；
  `falsify_round57.py` 五变异全咬。
- 本轮失误（自己咬自己）：R57 重写 real_apply judge 2 区段时把夹在中间的 restart/noop
  两裁判一并删掉——"3 passed"不是 5；**替换区段前先数区间内还有谁**。文档行锚点用了
  行前缀，把换行插进了行中间——**锚点必须整行、且行数守恒**。

### 教训（第五十七轮）

- **§13 声明式视图的"最新"是谁的钟**：`latest LKG` 按快照 created_at 取，而 created_at
  是策略步数钟——它度量"这次跑了多少步"，不度量"谁最后被操作员确认"。任何"最新 X"
  视图都要问：排序键和人的直觉是同一个序吗？
- **§14 拆和装不是逆运算**：补偿（拆）没有"装回去"的对偶步骤；复活是一次**部署**，
  用部署的机器（计划、探针、journal 语义）而不是发明的"恢复模式"。重建的语义 = 复用
  的语义。
- **§15 资产钉死先于能力落地**：真后端起不了第二核之前先把字节钉死——拒绝语就能点名
  "缺的是什么"，范围决定变成有日期的承诺，而不是永久的耸肩。
- **§16 变异不咬＝还有谎没拆**：M5（sim 不播种身份）第一跑不咬，不是变异无效，是探针
  的 `identity adopted` 臂在替核圆谎——"没咬"本身常常就是发现。

## 第五十八轮（2026-08-29）：sing-box spawn 面——第二核心真跑，ADR-046

- **先付学费再写渲染**：对着钉死的 sing-box 1.13.20 逐块烟测（decode+boot 双证据，
  /tmp/sbtest c1–c20）钉死七个事实：顶层 `tun` 键 FATAL、legacy dns `address` FATAL、
  `rule_set` 字符串 FATAL、WireGuard 是 **endpoint** 不是 outbound（且 peer 域名启动时
  急切解析）、域名地址须 `domain_resolver`＋`route.default_domain_resolver`、无条件规则
  是 MATCH 的忠实翻译、clash-api `/version` 即控制器真相。渲染器照表重写：typed dns＋一个名为 caly-local 的 local server 恒在首位、wg=endpoint＋确定性惰性键（零字节 base64）、`cipher`→`method`/
  `security` 翻译、MATCH→无条件规则、**不可译 matcher 省略并计数**（annotation）、
  fakeip 无 tun 省略。渲染裁判的断言表就是烟测表。
- **spawn 面**（effect_std `spawn_singbox_core`）：tar.gz 逐字节 sha256 核对（与 mihomo
  同一供应链教义，新增第二核的单元拒绝裁判）；**信封是结构合并**——`serde_json` 把
  listen_port 与 clash-api controller 写进 adapter 的 JSON 对象（部署事实归 runtime，
  R55 的 mixed-port 规则；字符串拼接无法诚实地做这件事，此依赖由 ADR-046 授权）；
  `tar -xzf --strip-components=1`＋`exec ./sing-box run -D . -c caly-run.json`（tar 默认
  覆盖——R57 gunzip 教训前向支付）。StopCore/CoreApiCall 双实例名指向同一槽。
- **demo 解绑**：sing-box demo 不再强制 tun（否则每个 sing-box apply 都死在 NetApply，
  spawn 面永远测不到）；TUN 拒绝路径仍由 TUN 裁判持有。
- **复活随身份分派**（`revival_core_shape`）：快照 core_identity → (CoreKind,
  entrypoint)；ADR-045 §3.2 的 mihomo-only 限制解除。跨核裁判：sing-box 被 mihomo 挡道
  → rollback → sing-box 复活（identity 探针判 `singbox:` 摘要）→ 再 apply 判 Noop。
- **裁判**：real_apply 7（＋第二核端到端、跨核复活，宿主真相含解包出的 sing-box＋
  libcronet.so）；渲染裁判 4；第二核摘要拒绝单元 1。census 85 文件/667 断言、
  floor 667。`falsify_round58.py` 五变异。

### 教训（第五十八轮）

- **§17 渲染器的老师是真二进制，不是文档记忆**：三个"应该没问题"的形状（顶层 tun、
  legacy dns、rule_set 字符串）全是 FATAL；文档版本间的迁移（wireguard endpoint 化、
  dns resolver 链）只有 binary 的报错知道全貌。新核心渲染第一课：烟测表先于断言表，
  断言表就是烟测表。
- **§18 两个命名空间的同字不同义**：digest 前缀 `singbox:` 与身份前缀 `sing-box@`
  是同一核心的两个名字——`CoreKind::as_str()` 用连字符，artifact_digest 前缀不用。
  跨命名空间的分派（复活按身份、断言按 digest）第一次就踩空；裁判咬出跳过路径后
  才定谳。凡跨命名空间取字，先用裁判钉住两边拼写的实证。
- **§19 `a && b & kill` 杀的是子壳不是 b**：烟测的 `check && run … & p=$!; kill $p`
  把核留在宿主上占着 7890/17171——裁判因 free_port 设计无恙，但宿主卫生靠扫。
  长命子进程的烟测一律 `p=$!; kill $p` 直取，或用 exec 链。

## 第五十九轮（2026-08-29）：Http 路由诚实化——ActiveCore 真经核，ADR-047

- **三档路由**：`StdHttp` 此前只读 url、无视 route 列——ActiveCore 静默直连是一列被声明
  却不被遵守的谎言。现三档各有真语义：Direct 现状；**ActiveCore 向活核 mixed 入站发绝对
  形式代理请求**（地址来自 `CoreRouteSource` 共享单元：spawn 写入、stop/shutdown 清除，
  一份事实无双份簿记）；SystemProxy 按名拒绝（等第一个真调用方）。
- **端到端裁判咬出两个真缺陷（都修在产品侧）**：
  1. **apply 完成≠代理门开**：verify 只探 controller，mihomo mixed 入站晚若干毫秒绑好，
     紧跟 apply 的经核取回撞窗（表象是误导性的 connection refused，ss 显示核在监听）。
     修：真后端补 **InboundListening** 探针（原按名拒绝），两 adapter 计划＋复活计划都
     加这一步——apply 完成＝代理门真在接受连接。
  2. **崩核变砖**：核被带外停掉后，下一次 apply 的 Restart 死在 StopCore（no-running-core）。
     sim 从来都说 `already-gone`（幂等）——真后端是对等分歧。修：停没在跑的核＝已达成；
     停别的 id 仍拒。
- **核自检裁判**：渲染产物必须过核自己的校验器（mihomo `-t`／sing-box `check`，钉死资产
  解包执行）——schema 漂移在 spawn 之前就被二进制报警。断言表由烟测钉死（R58），本轮起
  核自动复验。
- **凭据边界（§5.2 第一刀）**：demo 口令与真 passthrough 口令只活在 artifact 字节里（核要
  真值才肯 parse），manifest、annotations、job 事件流一字不带。边界的诚实是**位置性的**。
- **sing-box 骑乘暂缺（ADR-047 §5.1）**：demo 默认选择是 WireGuard endpoint 且 peer 是
  TEST-NET 惰性地址——经核取回挂在死隧道上。mihomo 端到端＋stub 单元持机制，sing-box 段
  由 apply 内 InboundListening 持门。
- 教义沉淀：ADR-047；census 88 文件/676 断言、floor 676；`falsify_round59.py` 五变异。

### 教训（第五十九轮）

- **§20 声明而不遵守的列，是最安静的谎言**：route 字段在类型里、在请求里、被每一个人
  传递，唯独没有人读它——没有裁判的字段都会走到这一步。类型系统的穷尽匹配只管存在的
  变体，不管被声明的语义。
- **§21 竞态的表象会指认一个无辜的组件**：connect refused 指向"没监听"，ss 却显示在监听
  ——真相是探针证明的（controller）和裁判依赖的（mixed）不是同一扇门。**每个"就绪"断言
  都要问：就绪的是哪扇门？**
- **§22 幂等是世界语义，不是便利**：停没在跑的核＝已达成——sim 先说了真话，真后端的
  "严格"反而把崩溃变成了砖。对等分歧的方向要看哪边说的是世界。

## 第六十轮（2026-08-29）：SystemProxy 收齐三档；Direct 模式即路由决定——ADR-048

- **SystemProxy 真实现**：绝对形式机制复用（同 ActiveCore），代理地址**组合时注入一次**
  （`system_proxy_from_env`：http_proxy→all_proxy，`StdEffectRuntime::new` 调用——fetch
  中途重读环境会让路由取决于碰巧的时刻）。纯解析半件 `parse_proxy_value` 单独可判：
  scheme 前缀容忍、host:port 为形、**待解析名字与无端口值都 None**（猜端口与静默直连
  是同一个谎的两个方向）。无代理组合＝按名拒绝。裁判 3：stub 骑乘（绝对形式）／无代理
  拒名／纯解析。
- **Direct 模式即路由决定（关 ADR-047 §5.1）**：sing-box 渲染此前无视 routing_mode——
  Direct 模式仍发 MATCH→group 规则，把全部流量送进 demo 死隧道，**Direct 核取不回任何
  东西**。修：Direct 模式一条规则不发，`final: direct` 本身就是路由决定。裁判 9 的
  sing-box 段随即从"门开着"升格**真骑乘**（nightshift-sing-direct 经 mixed 真实取回
  200）——`FetchRoute` 三档全真，路由面的 unsupported 拒绝语退役。
- **wg 凭据覆盖路径（兑现 ADR-046 §3.2）**：`render_wg_endpoint` 读 passthrough——
  private_key/peer_public_key 逐字、local_address/peer_allowed_ips 逗号列表；缺键回落
  惰性常量。真值永远赢，裁判双向持有（真键在场逐字出现／真空缺惰性仍在）。
- 教义沉淀：ADR-048（§5 记 https_proxy/socks5 未支持）；census 88 文件/680 断言、
  floor 680；`falsify_round60.py` 五变异。

### 教训（第六十轮）

- **§23 模式是路由决定，不是装饰键**：routing_mode 在类型里走了一路，渲染器却没读——
  与 R59 的 route 列同病（§20），只是这次藏在"渲染只关心拓扑"的借口下。每个随 profile
  携带的模式字段都要问：谁消费它？没人消费的模式就是下一个谎言。
- **§24 环境读取属于组合根，不属于库调用**：fetch 里现读 env＝同一次操作的路由取决于
  时刻；解析一次、注入进来，库保持纯、可判、可组合。纯半件（parse）与效半件（env
  读取）分开写，裁判只咬纯半件——env 本身不可重复判。
- **§25 校验器的深度决定它能守什么**：sing-box `check` 只 decode（不解析 route.final
  引用），`run` 才在 start service 解析——删掉显式 direct 出站时 check 照过、核当场死。
  自检裁判守 schema，运行裁判守引用；"过了 check"永远不能被说成"能启动"。（M5 第一跑
  锚错裁判即此教训的自付版。）

## 第六十一轮（2026-08-29）：真实 source ingest 纵向切片——显式 locator、条件复用与 CAS 证据

这一轮先重新读了 `ROADMAP`、`IMPLEMENTATION_STATUS`、`CENTERLINE_PROGRESS`、`OVERLOAD_AND_RETRY_MODEL`、相关 ADR 与 source/apply 代码。结论不是“再做一个 parser stub”，而是 source 链已经有纯解析边界，缺的是把**显式外部 locator → 有界 HTTP → parser → RawSource CAS → normalized cache → apply planning** 接成一条可以拒绝错误证据的生产路径。

- **显式 endpoint registry**：新增 `SourceEndpoint`（`source_id`、kind、label、locator、route、body cap、media type、strict policy）。source id 或展示 label 永不推导 URL；未注册 locator、空 locator、零 cap、超过 parser cap 都在组合/注册时拒绝。`calyd` 通过 `--source-endpoint id=locator` 注册，保持 locator 是组合根提供的数据而不是库里猜出来的地址。
- **HTTP 与 parser 接线**：`HttpSourceUpdateWorker` 同时接受 `StdHttp` 与 `SimHttp`，请求带 `ETag` / `If-Modified-Since` 条件字段与有界 body；`parse_source` 负责 UTF-8 URI 或 base64/base64url envelope 的 decode/normalize，并产出 `RawSource`、`NormalizedSource`、有界 diagnostics 与 parser provenance。worker 只负责编排，不把 host/network 逻辑带进 pipeline。
- **CAS 事实边界**：200 响应先通过 parser，随后把原始 bytes 以 `ObjectKind::RawSource` 写入 CAS；写入载荷、对象 kind、`content_sha256` 与 parser raw digest 必须一致，任何错锚点都拒绝。成功报告才写入 engine 的 normalized source cache；cache 写失败会让 SourceUpdate job Failed，而不是留下绿色“已更新”。
- **304 不是空成功**：process-local report 保存 ETag / Last-Modified 与 raw object 引用。304 路径从同一个 `StorageBackend::read_object` 读回 raw bytes，校验 `RawSource.content_digest` 与 CAS `content_sha256` 两个锚点，再复用 normalized/provenance；无 prior report、对象缺失、或锚点不一致都拒绝。这样条件请求的复用有内容证据，而不是把“没有 body”送进 parser。
- **locator 变更失效**：同 source id 改成不同 locator 时删除条件 cache；同 locator 重注册保持 cache。否则新 endpoint 回 304 会把旧 endpoint 的 bytes 当成新资源，这是静默数据污染，不是性能问题。
- **SourceUpdate job / composition root**：worker 结果进入真实 SourceUpdate job，事件报告 fetch/normalize/CAS、节点数、raw digest 与 `raw_reused`；daemon/app 提供 worker、endpoint 注册与 source cache 接缝。`calyd` 组合 `FsStore`、`StdFs`、`StdClock`、`StdHttp` 与显式 endpoint；effect runtime 仍默认 simulated，不能把 source 的真实 HTTP 误写成整套真实部署已默认接管。
- **门禁与裁判**：source worker、flow、source parser 的测试纳入生成式 census；当前 `python3 scripts/regenerate_test_census.py --check` 自报 `files=91 total=691 rows=91`。304 校验复用、locator invalidation、source cache consumption 与明确 locator 拒绝各有断言。文档收口后直接执行 `./scripts/check.sh` 通过：691 tests / floor 691、clippy baseline 31、fmt 1,365 行 advisory；独立 `cargo test --workspace` 也通过。独立 `cargo fmt --all -- --check` 仍以非零退出，输出仍是这 1,365 行既有 workspace 格式漂移，符合当前 advisory 门禁策略。

### 本轮发现并留档的问题

1. 直接改 304 分支为成功会制造“空 body parser”或“相信 process-local memory”的假绿；已在 `ONBOARDING_NOTES.md §4.140` 记录并由 CAS anchor test 固化。
2. endpoint registry 初版会跨 locator 发送旧条件字段；已在 `§4.141` 记录并让 locator 变更清 cache。
3. source 代码绿后，文档门禁仍因测试 census 与中心线旧数字失败；已在 `§4.142` 记录，数字改为生成器/树共同作答，而不是手算。
4. 收口复查又发现 GC active snapshot 与 `daemon owns` 的旧注释、以及多份“无 bin/零外部依赖/真实 source 未做”当前表述；本轮没有改写历史证据，而是在状态/路线/接续文档中明确“历史记录 vs 当前快照”，并修正代码注释与当前缺口。

### 本轮明确未做

- durable source index：endpoint locator、条件字段、raw/normalized digest、parser provenance 的持久化 schema、原子提交与跨重启恢复；
- HTTP→parser→CAS 全链的 caller deadline/cancellation；
- 把 `StdEffectRuntime` 变成 `calyd` 默认 runtime，或补齐 Platform/TUN/helper；
- 通用 `caly-ipc` transport runtime、stream 逐帧生产语义、capability JSON 文件加载、schema migration/`stat_many`、CI/fuzz/performance。

## 下一步

1. **durable source index / provenance**：定义 source record、原子提交、重启扫描、坏记录拒启、304 复用与 locator 变更失效；
2. **source 全链限制**：为 HTTP→parser→CAS 设计 caller deadline/cancellation，并保持没有时钟就不猜期限；
3. **真实 runtime 生产组合根**：明确 `StdEffectRuntime` 的配置、权限、资产目录与失败语义；默认 simulated 的事实不悄悄改写；
4. **transport 与压力**：完成通用 `caly-ipc` transport runtime、stream payload 逐帧语义与 EventBacklog/StreamBackpressure 的真实生产模型；
5. **能力来源与发布**：决定 capability JSON 是输入还是导出物，补 schema/performance、artifact golden、CI/fuzz/performance。
