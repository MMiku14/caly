# RFC-0006: Caly IO Port / IoFault 规范

- Status: Draft
- Version: 1.0.0-draft
- Depends-On: RFC-0001, RFC-0002, RFC-0005
- Last-Updated: 2026-08-30

---

## 摘要

本文冻结 Caly 的 IO 边界。目标是把文件系统、网络、进程、时钟、随机数、密钥存储以及相关错误语义，从业务逻辑中彻底收口到一组稳定 Port 后面。

本 RFC 解决三个问题：

1. 哪些能力属于 IO，必须通过 Port 调用。
2. 所有 IO 调用必须共享哪些统一语义，例如 deadline、cancel、budget、路径约束。
3. IO 错误如何表达，才能让上层无需解析平台 errno 或第三方库细节。

本文与 RFC-0001 的“纯内核 + 单一 IO 网关”原则一致，并为后续 `caly-io`、`caly-io-std`、`caly-io-sim` 的代码接口提供规范基础。

---

## 1. 目标

本文冻结：

- IO Port 的职责边界
- 统一调用上下文在 IO 层的最低要求
- `IoFault` 分类模型
- `VPath` 路径安全语义
- Port 级 deadline / cancel / budget 传播规则
- 常见 Port 的最小职责集合
- IO 契约测试的最低门槛

---

## 2. 非目标

本文不冻结：

- 具体 Rust trait 的最终函数签名细节
- 平台特定 syscall 选型
- SQLite schema 细节
- RuntimeDriver 语义细节
- EffectPlan 的完整执行器实现

这些内容分别由其他 RFC 或实现文件补充。

---

## 3. 设计原则

1. 业务逻辑 **MUST NOT** 直接触碰真实 IO。
2. 所有外部世界交互 **MUST** 通过 Port 发生。
3. IO 失败语义 **MUST** 以 `IoFault` 表达，而非泄漏 errno/异常字符串。
4. 所有 IO 调用 **MUST** 接受统一上下文约束。
5. 路径与资源访问 **MUST** 默认受限，而不是默认开放。
6. 仿真实现与真实实现 **MUST** 共享同一组契约测试。

---

## 4. IO Port 总览

Caly 的 IO Port 至少包括以下类别：

| Port | 负责 |
|---|---|
| `Fs` | 文件、目录、原子写、重命名、锁、流式读取 |
| `Http` | 远程获取、流式下载、条件请求、重定向控制 |
| `Proc` | 子进程启动、终止、wait、stdio 管理 |
| `Clock` | 墙钟、单调时钟、sleep、计时器抽象 |
| `Rand` | 随机字节、UUID、nonce |
| `Keyring` | Secret 的系统存储与读取 |
| `Platform` | 系统代理、TUN、DNS、路由等系统副作用 |
| `Signal` / `ProcessWatch` | 进程退出/系统信号观察 |
| `PrivTransport` | 与 Privilege Helper 的本地受限通信 |

实现可以拆成更多子 trait，但对外规范不应少于上述能力面。

---

## 5. 统一调用上下文

所有 Port 调用 **MUST** 接受或隐式继承统一 `Ctx`。最低语义包括：

- `trace_id`
- `actor`
- `deadline`
- `cancel_token`
- `io_budget`
- `expected_revision`（若有意义）

### 5.1 Deadline 规则

- 子调用 MUST 使用不大于父调用的剩余 deadline。
- Port 实现 MUST 在超时后尽快终止或返回失败。
- 超时应表现为稳定 `IoFault`，而不是无限悬挂。

### 5.2 Cancel 规则

- Port 实现 SHOULD 支持 cooperative cancellation。
- 流式读取/写入 MUST 在 chunk 边界检查取消信号。
- 已取消调用返回的错误必须可与普通超时区分。
- 区分两者的责任在**驱动调用的那一层**，不在被调用的端口：端口只能报告自己发生了什么，而"没在期限内
  完成"与"caller 放弃了"是同一个未完成状态的两种原因。

> 修订（第二十四轮）：`§5.3` 的"Budget 用尽时返回容量/预算类 `IoFault`"从今天起在引擎这一层**有人执行**
> （`caly_engine::RunLimits` 计费 + `run_ready_in` 在驱动前拒绝）。两点如实记录：字节维度仍**不生效**
> （引擎看不见全部字节，`ADR-036 §6bis-sexies` 写明它属第 4 步），而公开 API 层因 `RFC-0002 §14.4` 冻结码表
> 仍答 `CONFIG_INVALID` 而不是新的容量码 —— 落差是有意的，见 `docs/OVERLOAD_AND_RETRY_MODEL.md §3.7`。

> 修订（第二十一轮，`ADR-036 §6bis-ter`）：上面这条今天才有实现处 —— `caly_io::runtime::drive` 在每次
> 轮询前先看 `CancelToken`（→ `Cancelled`，不可重试），再看 `Deadline`（→ `Timeout`，可重试），两者都没有
> 命中而轮询预算耗尽时给 `Busy`（可重试、瞬态）。**没有时钟可判定时限时它不返回 `Timeout`**：编造一个
> 期限已过，等于给调用方一个他无法核对的理由。`caly-io-sim` 另外提供一次性 `hang(label)` 注入，
> 使这条契约第一次可以在真后端上被测（此前 `Timeout` / `Cancelled` 只能由后端自己声称）。

### 5.3 Budget 规则

`io_budget` 用于限制单次操作的资源消耗，例如：

- 可读取总字节数
- 可发起请求数
- 可解压后总字节数

Budget 用尽时，Port MUST 返回容量/预算类 `IoFault`。

> 修订（第二十九轮，`ADR-036 §6bis-decies`）：这条 MUST 从今天起有执行处，而且执行者就是被要求的那一层 ——
> `caly_io::budget` 的 `byte_ceiling` / `check_payload`，`StdFs` 与 `SimFs` 调同一份实现，
> `caly_io::contract::fs_byte_budget_violations` 在两个后端上跑同一组断言（写侧超限必须在**落盘之前**拒、
> 精确等于上限必须放行、上限取更紧的一条、未设预算必须什么都不拒、被拒的文案必须点名 `io_budget.max_bytes`）。
> `max_bytes` 因此是"单次操作的上限"（本节的字面语义），不是跨调用的累计量 —— 累计的那一轴是
> `max_requests`，由 `caly-engine::RunLimits` 按一次命令执行记账（第二十四轮）。两轴语义不同是结构造成的，
> 不是疏忽：字节的可见性与命令作用域不在同一层。

> 修订（第六十三轮，`ADR-049 §2.4`）：`Http` trait 仍不携带 `Clock`，但具体 `StdHttp`/`SimHttp` 可由 composition root 注入同一 monotonic clock。两端通过 `caly_io::caller_deadline_mono_ms` / `check_caller_control` 共享 relative-to-absolute anchoring 与 `Cancelled`/`Timeout` 判定；`StdHttp` 另以剩余期限收紧 blocking socket timeout。`HttpSourceUpdateWorker` 在 HTTP、parse、CAS 与 D3 commit 之间执行 phase probes，故 source caller control 已覆盖当前同步 HTTP→parser→CAS→D3 slice。这里的"尽快终止"对 StdHttp 的诚实解释仍是 socket timeout + 返回后的 probe：单个 OS blocking syscall 不能被 token 从中途强行打断；没有 clock 时不得猜 deadline。

---

## 6. `IoFault` 规范

### 6.1 目标

`IoFault` 是所有 IO Port 的统一错误边界。上层逻辑不应依赖：

- `errno`
- 第三方 crate 原始错误类型
- 平台专属错误字符串

### 6.2 最小分类

`IoFault` 至少应表达以下类别：

- `NotFound`
- `AlreadyExists`
- `PermissionDenied`
- `Busy`
- `Timeout`
- `Cancelled`
- `CapacityExceeded`
- `Transient`
- `Unavailable`
- `IntegrityViolation`
- `InvalidInput`
- `Unsupported`
- `InternalIo`

### 6.3 必备属性

每个 `IoFault` 至少应携带：

- `kind`
- `summary`
- `retryable`
- `transient`
- `resource?`
- `source_hint?`
- `trace_id?`

### 6.4 语义要求

- `retryable=true` 不等于调用方必须自动重试。
- `Transient` 表示可能通过稍后重试成功，但是否重试由上层策略决定。
- `IntegrityViolation` 用于哈希不匹配、损坏、部分写等完整性问题。
- `CapacityExceeded` 用于磁盘满、内存预算耗尽、下载超限、解压超限等。
- `Unsupported` 用于平台或后端无此能力，而不是“开发者还没写”。

---

## 7. `VPath` 路径模型

### 7.1 目标

`VPath` 用于提供受根目录约束的路径表达，防止：

- `..` 逃逸
- 任意绝对路径访问
- 符号链接绕过
- 用户输入直接映射到宿主真实路径

### 7.2 约束

`VPath`：

- MUST 绑定一个预定义根
- MUST 拒绝绝对路径输入
- MUST 拒绝 `..`、空段、非法保留名
- SHOULD 在打开/重命名时抵御符号链接逃逸

### 7.3 使用规则

- 业务层与存储层 SHOULD 传递 `VPath`，而不是原始字符串路径。
- 任何来自订阅、导入配置或 UI 的路径，都 MUST 先规范化为 `VPath` 或被拒绝。

---

## 8. `Fs` Port 规范

### 8.1 最小职责

`Fs` 至少应支持：

- 小文件读取
- 流式读取
- 原子写
- rename
- remove
- stat
- lock
- link/reflink/copy 物化
- 目录列举（见 §8.4；由 `ADR-035` 补入）

### 8.2 原子写要求

`write_atomic` MUST 明确声明 durability 级别，并满足相应语义：

- `D0`：允许缓存丢失
- `D1`：tmp + rename
- `D2`：tmp + fsync(file) + rename + fsync(dir)
- `D3`：与 DB 持久提交协调

### 8.3 文件锁

若实现提供排他锁：

- 锁对象 MUST 明确所有权与生命周期
- 锁释放 MUST 可预测
- 锁冲突应映射为 `Busy`

### 8.4 目录列举

> 修订：本小节由 `ADR-035`（第十四轮定稿、第十五轮加能力、第十六轮接线）补入。理由不是"想加一个 API"，
> 而是缺少它会让每个持久化后端各自发明一份"有什么"的真相 —— `caly-storage` 曾为此维护
> `manifest/*.idx`，"清单与实体不一致"因此成为常态失效模式；该清单层已随 `ADR-035` 第 2 步删除。
> 本节因此不只是"允许实现提供列举"，而是**要求**它提供：持久层不再有任何自造索引的余地。

`list(dir, ListCap, ctx)` 返回该目录的**直接**子项，MUST 满足：

- **有序**：按相对路径字典序。恢复扫描与 GC 要在仿真盘与真实盘上得到同一个候选集；否则
  `ADR-022` 的发布门禁验证的是一个生产端口并不存在的顺序。
- **可预算**：条目数超过 `ListCap` MUST 返回 `CapacityExceeded`，MUST NOT 返回截断后的列表。
  理由与 `§5.3` 的字节预算相同：一个"看起来完整"的部分答案是静默漏做。
- **只一层**：子目录与文件都作为子项出现；类型由 `stat` 判断。列举不承担遍历策略。
- **空与不存在可区分**：目录存在但没有子项返回 `Ok(空)`；目录不存在返回 `NotFound`。
  `stat` 回答"它在不在"，所以"不在"是值；`list` 回答"里面有什么"，对不存在的东西给出空答案是谎。
  这一条要求纯内存的仿真实现**记录被创建过的目录**，否则两种情况无法区分。
- 对文件路径调用 `list` MUST 是 `InvalidInput`（该路径存在但没有子项），MUST NOT 是 `NotFound`
  （那会让调用方以为整棵子树可以放弃）。

错误映射：

| 情形 | `IoFaultKind` |
|---|---|
| 目录不存在 | `NotFound` |
| 目标是文件而非目录 | `InvalidInput` |
| 条目数超预算 | `CapacityExceeded` |
| 目录可读性被拒 | `PermissionDenied` |

`Meta` 同时带 `modified_at_unix_ms: Option<i64>`：语义是"最后一次成功 `write_atomic` 的时间"，由端口
自己记录。`None` 表示"这个实现不知道"，是合法答案；MUST NOT 用 0 或宿主时钟填充——一个假装是纪元
时间的值会让新对象看起来极其陈旧。

---

## 9. `Http` Port 规范

### 9.1 最小职责

`Http` 至少应支持：

- 流式响应体
- 条件请求（如 ETag / If-Modified-Since）
- body cap
- 重定向策略控制
- 连接/读取超时
- 目标路由选择

> 当前实现修订（第六十三轮，`ADR-049`）：生产与仿真 Http port 以有界、完整的 `FetchBody` snapshot 承载响应字节；不是超过上限后返回截断前缀。`StdHttp`/`SimHttp` 对 body cap、条件请求与 caller phase-boundary control 共同作答。真正可暂停/可中断的 chunk reader 仍不是现有 `Http` trait 的承诺，若有调用方必须另定 poll/close/drop、budget、deadline 与回收语义。

### 9.2 安全要求

- MUST 在连接建立后执行 SSRF 地址检查
- MUST 支持最大 body 限制
- MUST 支持最大解压后字节限制
- SHOULD 在跨 origin 重定向时剥离敏感头

### 9.3 错误映射

- DNS 失败不应泄漏底层库细节，需映射为统一 `IoFault`
- 4xx/5xx 可映射为 `Unavailable` 或更细分上层错误，但 Port 至少要保留 HTTP 状态摘要

---

## 10. `Proc` Port 规范

### 10.1 最小职责

`Proc` 至少应支持：

- 无 shell 启动子进程
- 传递 argv/env/cwd
- 管理 stdin/stdout/stderr
- wait / terminate / kill
- 进程身份信息观察

### 10.2 约束

- MUST NOT 通过 shell 拼接命令
- MUST 支持 stdout/stderr 持续读取
- MUST 支持优雅停止与强制停止两阶段
- SHOULD 提供平台稳定的“同一实例识别”能力，如 pid + start_time + nonce

### 10.3 错误映射

- 启动失败：`PermissionDenied` / `NotFound` / `InvalidInput` / `Unavailable`
- wait 超时：`Timeout`
- 被取消：`Cancelled`

---

## 11. `Clock` Port 规范

### 11.1 分离语义

`Clock` 至少包含两种时间：

- 墙钟：用于展示、日志、快照时间元数据
- 单调时钟：用于超时、重试间隔、健康检查时限

### 11.2 约束

- 超时与 sleep MUST 基于单调时钟
- 纯管线 MUST NOT 依赖 `Clock`
- 仿真环境 MUST 可替换为虚拟时钟

---

## 12. `Rand` Port 规范

### 12.1 用途

`Rand` 用于：

- token
- nonce
- UUID
- 临时名称随机后缀

### 12.2 约束

- 纯管线 MUST NOT 依赖 `Rand`
- 需要安全随机性的调用 MUST 使用适合安全用途的实现
- 仿真环境 SHOULD 支持种子化确定性实现

---

## 13. `Keyring` Port 规范

### 13.1 角色

`Keyring` 用于统一 Secret 的系统存储接口。业务层不应直接依赖某 OS keychain API。

### 13.2 要求

- MUST 区分“无能力支持”和“临时不可用”
- MUST 支持按稳定 key 存取 secret
- SHOULD 支持删除与更新
- 失败应映射为 `Unsupported`、`PermissionDenied` 或 `Unavailable`

---

## 14. `Platform` Port 规范

### 14.1 范围

Platform Port 覆盖：

- system proxy
- system DNS
- TUN
- route
- autostart
- process info
- notify

### 14.2 约束

- 平台能力不足 MUST 通过统一错误或 capability 呈现
- 平台副作用调用 SHOULD 可生成/返回可回滚事务句柄
- 任何需要提升权限的操作都不应隐式透传到 shell

---

## 15. 契约测试

`caly-io-std` 与 `caly-io-sim` SHOULD 通过同一套契约测试。最低测试包括：

1. `VPath` 拒绝逃逸路径
2. `Fs.write_atomic` 满足约定的持久化等级
3. `Http` 在 body 超限时终止并返回统一错误
4. `Proc` 不经过 shell，stdout/stderr 可读取
5. `Clock` 的单调时间不受墙钟跳变影响
6. `Rand` 的仿真实现可复现
7. `Keyring` 的“不支持”和“暂时不可用”可区分
8. `Fs.list` 有序、受预算约束、只一层，并能区分“空目录”与“不存在”；`Meta.modified_at_unix_ms`
   要么一致地已知、要么一致地未知，且对同一路径不回退（`ADR-035`）

---

## 16. 冻结范围

本文冻结：

- IO Port 的最小能力边界
- `IoFault` 分类思路与最低字段
- `VPath` 的安全语义
- `Ctx` 在 IO 层的传播要求
- Port 契约测试的必要性

本文暂不冻结具体 trait 代码签名与平台专属细节。

> 一句必要的澄清（`ADR-035` 落地时核对）：上面这句是真的 —— 冻结的是**能力边界与语义**，不是方法表。
> 因此"给 `Fs` 增加 `list`"这类**加能力**的改动，受 `ADR` 层约束（要写 ADR、要两个后端同时满足契约），
> 但不受本文约束；反过来，改变上表中任一语义（例如允许截断式列举）才是要重新修订本文的动作。

---

## 17. 一句话结论

Caly 的 IO 边界必须收敛为：

> 所有外部世界交互都经过 Port，所有失败都归一为 `IoFault`，所有路径都受 `VPath` 约束，所有时限都由统一 `Ctx` 贯穿。