//! Unified Caly client: CLI commands, TUI, operations engine, layout suite, and logging.

#![forbid(unsafe_code)]

pub mod cli;
pub mod ops;

pub use cli::*;
pub use ops::*;
pub use ops::layout;

pub use ops::layout::tui_kit;
