//! caly-ops — the shared operations layer behind the caly frontends.
//!
//! The daemon-client pipeline (`client/`), the output envelope renderer
//! (`output/`), the error-code families (`error/`), the layered `config.yaml`
//! loader (`config`), the subscription text helpers (`subscription`) and the
//! kernel version manager (`kernels`) live here so the CLI (`caly-cli`) and
//! the TUI (`caly tui`) execute the identical operations over the identical
//! projections. Frontends own grammar, key handling and screen rendering;
//! this crate owns everything beneath: UDS calls, offline file surgery,
//! receipts and tables.
//!
//! The thin-client rule still holds at this layer: talk to the daemon only
//! through the wire protocol (caly-protocol v2) and offline projections —
//! never reach into composition/application/backends/server.

#![forbid(unsafe_code)]
#![cfg_attr(test, allow(clippy::unwrap_used, clippy::expect_used, clippy::panic, clippy::todo, clippy::unimplemented, clippy::unreachable))] // #53: tests assert with unwrap/expect/panic (+todo/unreachable in fixtures); production lints stay deny

pub mod client;
/// Layered `config.yaml` read/parse surface (P8a: moved up from the
/// daemon host so offline commands share one loader with boot; now
/// shared with the TUI through this crate).
pub mod config;
/// Entry-tree renderer (cli-v3-design.md G1 / W3a): the shared 三区制
/// layout behind `sub parse` and `node list --offline --format=tree`.
pub mod entry_tree;
pub mod error;
pub mod kernels;
pub mod subscription;
#[cfg(test)]
mod subscription_tests;
/// Cross-crate test helpers (`temp_root`, `hermetic_paths`,
/// `unique_file`). Public (not `pub(crate)`) so the CLI and TUI test
/// suites share the one naming scheme — same shape as
/// `caly_platform::paths::test_helpers`. Production code must not
/// use this module.
pub mod test_helpers;
/// Frontend-agnostic option/spec types (moved out of the CLI grammar
/// so both frontends construct the same [`client::ClientCommand`]).
pub mod types;

pub mod layout;
