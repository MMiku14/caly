//! Offline proxy-group writer for the `set proxy-group …` leaves.
//!
//! The 5 CRUD leaves (`add` / `remove` / `enable` / `disable` /
//! `list`) round-trip `proxy_groups: Vec<ProxyGroupConfig>` in
//! `config.yaml`. Since the CLI-sinking round 2, the
//! write semantics live in ONE shared implementation,
//! `caly_profile::store::resource_mutations` (the same code the daemon's
//! config-mutation actor runs); this module is the CLI's thin
//! offline adapter: it maps the CLI grammar types (`PgTypeSpec` /
//! `PgMemberSpec`) onto the wire payloads and projects the shared
//! error enum onto the stable `PgWriteError` codes.

use caly_domain::{ProxyGroupMemberRef, ProxyGroupMutation};
use caly_platform::paths::AppPaths;
use caly_profile::schema::ProxyGroupTypeConfig;

use caly_profile::store::resource_mutations::ResourceMutationError;
use caly_profile::store::resource_writer::{ResourceError, ResourceWriteOutcome};

/// Proxy-group-specific error variants. The shared
/// [`ResourceError`] cases flow through the `Shared(_)` arm so
/// the dispatch has one `match` instead of two parallel enums.
#[derive(Debug)]
pub enum PgWriteError {
    /// The id is empty or not path-safe ASCII.
    InvalidName(String),
    /// `add` on a name that's already in `proxy_groups:`.
    AlreadyDeclared(String),
    /// `remove` / `enable` / `disable` on a name that's not in
    /// `proxy_groups:`.
    NotDeclared(String),
    /// A `url-test` / `fallback` / `load-balance` group was
    /// added without a `--url` flag.
    MissingUrl(String),
    /// A `select` / `relay` group was added with a `--url`
    /// flag.
    UnexpectedUrl(String),
    /// Any other failure the shared writer surfaces.
    Shared(ResourceError),
}

impl core::fmt::Display for PgWriteError {
    fn fmt(&self, formatter: &mut core::fmt::Formatter<'_>) -> core::fmt::Result {
        match self {
            Self::InvalidName(name) => {
                write!(
                    formatter,
                    "proxy group name `{name}` is not path-safe ASCII"
                )
            }
            Self::AlreadyDeclared(name) => {
                write!(formatter, "proxy group `{name}` is already declared")
            }
            Self::NotDeclared(name) => write!(formatter, "proxy group `{name}` is not declared"),
            Self::MissingUrl(name) => write!(
                formatter,
                "proxy group `{name}` requires --url (url-test / fallback / load-balance)"
            ),
            Self::UnexpectedUrl(name) => write!(
                formatter,
                "proxy group `{name}` is a select/relay; --url is ignored (drop the flag)"
            ),
            Self::Shared(shared) => write!(formatter, "{shared}"),
        }
    }
}

impl std::error::Error for PgWriteError {}

impl crate::layout::ErrorHint for PgWriteError {}

impl From<ResourceError> for PgWriteError {
    fn from(value: ResourceError) -> Self {
        match value {
            ResourceError::AlreadyDeclared(name) => Self::AlreadyDeclared(name),
            ResourceError::NotDeclared(name) => Self::NotDeclared(name),
            other => Self::Shared(other),
        }
    }
}

impl From<ResourceMutationError> for PgWriteError {
    fn from(value: ResourceMutationError) -> Self {
        match value {
            ResourceMutationError::InvalidName(name) => Self::InvalidName(name),
            ResourceMutationError::AlreadyDeclared(name) => Self::AlreadyDeclared(name),
            ResourceMutationError::NotDeclared(name) => Self::NotDeclared(name),
            ResourceMutationError::MissingUrl(name) => Self::MissingUrl(name),
            ResourceMutationError::UnexpectedUrl(name) => Self::UnexpectedUrl(name),
            ResourceMutationError::InvalidKind(kind) => {
                Self::Shared(ResourceError::Invalid(format!("unknown kind `{kind}`")))
            }
            ResourceMutationError::InvalidUrl(reason) => {
                Self::Shared(ResourceError::Invalid(reason))
            }
            ResourceMutationError::Shared(shared) => Self::Shared(shared),
        }
    }
}

/// Type-kind spec for the CLI writer. Mirrors
/// `cli::ProxyGroupTypeSpec` but stays a CLI-side enum.
#[derive(Debug, Clone, Copy, Eq, PartialEq)]
pub enum PgTypeSpec {
    Select,
    UrlTest,
    Fallback,
    LoadBalance,
    Relay,
}

impl PgTypeSpec {
    pub const fn to_schema(self) -> ProxyGroupTypeConfig {
        match self {
            Self::Select => ProxyGroupTypeConfig::Select,
            Self::UrlTest => ProxyGroupTypeConfig::UrlTest,
            Self::Fallback => ProxyGroupTypeConfig::Fallback,
            Self::LoadBalance => ProxyGroupTypeConfig::LoadBalance,
            Self::Relay => ProxyGroupTypeConfig::Relay,
        }
    }

    /// The wire `kind:` spelling (kebab-case), shared by the daemon RPC
    /// payload and the offline writer.
    pub const fn clash_label(self) -> &'static str {
        self.to_schema().clash_label()
    }
}

impl From<crate::types::ProxyGroupTypeSpec> for PgTypeSpec {
    fn from(value: crate::types::ProxyGroupTypeSpec) -> Self {
        match value {
            crate::types::ProxyGroupTypeSpec::Select => Self::Select,
            crate::types::ProxyGroupTypeSpec::UrlTest => Self::UrlTest,
            crate::types::ProxyGroupTypeSpec::Fallback => Self::Fallback,
            crate::types::ProxyGroupTypeSpec::LoadBalance => Self::LoadBalance,
            crate::types::ProxyGroupTypeSpec::Relay => Self::Relay,
        }
    }
}

/// Member spec for the CLI writer. Mirrors
/// `cli::ProxyGroupMemberSpec` but erases the CLI grammar.
#[derive(Debug, Clone, Eq, PartialEq)]
pub enum PgMemberSpec {
    Node { tag: String },
    Group { name: String },
    Direct,
    Reject,
}

impl PgMemberSpec {
    /// Maps to the wire `members:` ref.
    pub fn to_ref(&self) -> ProxyGroupMemberRef {
        match self {
            Self::Node { tag } => ProxyGroupMemberRef::Node(tag.clone()),
            Self::Group { name } => ProxyGroupMemberRef::Group(name.clone()),
            Self::Direct => ProxyGroupMemberRef::Direct,
            Self::Reject => ProxyGroupMemberRef::Reject,
        }
    }
}

/// What an `add` / `remove` / `enable` / `disable` call did.
pub type PgWriteOutcome = ResourceWriteOutcome;

/// `set proxy-group add <name> --type <kind> [--members …] [--url …]`.
pub fn add_group(
    paths: &AppPaths,
    name: &str,
    group_type: PgTypeSpec,
    members: &[PgMemberSpec],
    url: Option<&str>,
    interval_seconds: Option<u32>,
    tolerance_ms: Option<u32>,
    apply: bool,
) -> Result<PgWriteOutcome, PgWriteError> {
    let mutation = ProxyGroupMutation::Add {
        name: name.to_owned(),
        kind: group_type.clash_label().to_owned(),
        members: members.iter().map(PgMemberSpec::to_ref).collect(),
        url: url.map(str::to_owned),
        interval_seconds,
        tolerance_ms,
    };
    caly_profile::store::resource_mutations::mutate_proxy_group(paths, &mutation, apply)
        .map_err(PgWriteError::from)
}

/// `set proxy-group remove` — filters the `proxy_groups:` list by name.
pub fn remove_group(
    paths: &AppPaths,
    name: &str,
    apply: bool,
) -> Result<PgWriteOutcome, PgWriteError> {
    let mutation = ProxyGroupMutation::Remove {
        name: name.to_owned(),
    };
    caly_profile::store::resource_mutations::mutate_proxy_group(paths, &mutation, apply)
        .map_err(PgWriteError::from)
}

/// `set proxy-group enable|disable` — flips the `enabled` flag.
pub fn set_enabled(
    paths: &AppPaths,
    name: &str,
    enabled: bool,
    apply: bool,
) -> Result<PgWriteOutcome, PgWriteError> {
    let mutation = if enabled {
        ProxyGroupMutation::Enable {
            name: name.to_owned(),
        }
    } else {
        ProxyGroupMutation::Disable {
            name: name.to_owned(),
        }
    };
    caly_profile::store::resource_mutations::mutate_proxy_group(paths, &mutation, apply)
        .map_err(PgWriteError::from)
}

/// Reads the declared `proxy_groups:` list from the layered config.
pub fn probe_layered_config(paths: &AppPaths) -> Result<(), String> {
    super::load_layered_lenient(&paths.config, None).map(|_| ())
}

pub fn read_declared(paths: &AppPaths) -> Vec<(String, bool, String, usize, bool)> {
    match super::load_layered_lenient(&paths.config, None) {
        Ok(config) => config
            .proxy_groups
            .into_iter()
            .map(|g| {
                let kind = g.group_type.clash_label().to_owned();
                let member_count = g.members.len();
                let has_url_test = g.url_test.is_some();
                (g.name, g.enabled, kind, member_count, has_url_test)
            })
            .collect(),
        Err(_) => Vec::new(),
    }
}

#[cfg(test)]
mod tests;
