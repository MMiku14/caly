//! Capability-list presentation helpers for `caly status`.

use caly_ipc::protocol::protocol::v2::WirePresentationSnapshot;

pub(super) fn print_capabilities(snapshot: &WirePresentationSnapshot) {
    if snapshot.capabilities.is_empty() {
        println!("capabilities: none");
        return;
    }
    // The same adaptive engine as every other listing — minus the TSV
    // face (scripts read `status --json`): a titled mini-table.
    println!("capabilities:");
    let rows: Vec<Vec<String>> = snapshot
        .capabilities
        .iter()
        .map(|capability| {
            vec![
                capability_label(capability.capability).to_owned(),
                configured_label(capability.configured).to_owned(),
                runtime_label(capability.runtime).to_owned(),
                capability.caveat.as_deref().unwrap_or("").to_owned(),
            ]
        })
        .collect();
    crate::layout::print_table(
        crate::layout::TableMode::Table,
        &["CAPABILITY", "CONFIGURED", "RUNTIME", "CAVEAT"],
        &rows,
    );
}

pub fn capability_label(value: i32) -> &'static str {
    match value {
        1 => "tun-config",
        2 => "dns-config",
        3 => "mode-switch",
        4 => "proxy-groups",
        5 => "proxy-selection",
        6 => "url-test",
        7 => "connections",
        8 => "connection-close",
        9 => "traffic",
        10 => "logs",
        11 => "rules",
        _ => "unknown",
    }
}

pub fn configured_label(value: i32) -> &'static str {
    match value {
        1 => "unsupported",
        2 => "supported",
        3 => "partial",
        _ => "unknown",
    }
}

pub fn runtime_label(value: i32) -> &'static str {
    match value {
        1 => "not-required",
        2 => "available",
        3 => "unavailable",
        4 => "unknown",
        _ => "unknown",
    }
}
