//! Three-tier logging configuration: Application, Dual-Kernels (Mihomo/Sing-box), and Kernel IPC.

use std::process::ExitCode;
use crate::layout::{CliOutput, KvBlock, print_blocks, ok};
use crate::client::config_kv::{config_get, config_set};

/// Structured log configuration snapshot for all system tiers.
#[derive(Clone, Debug, Eq, PartialEq, serde::Serialize, serde::Deserialize)]
pub struct SystemLogConfig {
    pub app_log_level: String,
    pub kernel_log_level: String,
    pub ipc_trace_enabled: bool,
    pub mihomo_supported_levels: &'static str,
    pub sing_box_supported_levels: &'static str,
}

impl Default for SystemLogConfig {
    fn default() -> Self {
        Self {
            app_log_level: std::env::var("CALY_LOG").unwrap_or_else(|_| "info".to_owned()),
            kernel_log_level: "info".to_owned(),
            ipc_trace_enabled: false,
            mihomo_supported_levels: "debug | info | warning | error | silent",
            sing_box_supported_levels: "trace | debug | info | warn | error",
        }
    }
}

/// Displays the current 3-tier log status across application and kernels.
pub fn show_log_status(json: bool) -> ExitCode {
    let output = CliOutput::from_json_flag(json);
    let config = SystemLogConfig::default();

    if json {
        crate::layout::print_ok_envelope(serde_json::json!({
            "app_log_level": config.app_log_level,
            "kernel_log_level": config.kernel_log_level,
            "ipc_trace_enabled": config.ipc_trace_enabled,
            "mihomo_levels": config.mihomo_supported_levels,
            "sing_box_levels": config.sing_box_supported_levels,
        }));
        return ExitCode::SUCCESS;
    }

    let mut app_block = KvBlock::plain();
    app_block.title("Application Logging (Caly Daemon & CLI)");
    app_block.entry("Level", &config.app_log_level);
    app_block.entry("Env Override", "CALY_LOG / RUST_LOG");

    let mut kernel_block = KvBlock::plain();
    kernel_block.title("Kernel Logging (Mihomo & Sing-box)");
    kernel_block.entry("Current Level", &config.kernel_log_level);
    kernel_block.entry("Mihomo Options", config.mihomo_supported_levels);
    kernel_block.entry("Sing-box Options", config.sing_box_supported_levels);
    kernel_block.entry("Config Key", "kernel.log_level");

    let mut ipc_block = KvBlock::plain();
    ipc_block.title("Kernel IPC & Wire Communication");
    ipc_block.entry("Wire Tracing", if config.ipc_trace_enabled { "enabled" } else { "disabled" });
    ipc_block.entry("Controller Socket", "127.0.0.1 (Loopback)");

    print_blocks(&[app_block, kernel_block, ipc_block]);
    ExitCode::SUCCESS
}

/// Sets the log level for a specific tier (app, kernel, ipc, or all).
pub fn set_log_tier(target: &str, level: &str, apply: bool, json: bool) -> ExitCode {
    let normalized_level = level.to_ascii_lowercase();
    match target.to_ascii_lowercase().as_str() {
        "kernel" | "mihomo" | "sing-box" => {
            config_set(json, "kernel.log_level", &normalized_level, apply)
        }
        "app" => {
            ok(&format!("Application log level set to `{normalized_level}` (restart daemon or set CALY_LOG={normalized_level})"));
            ExitCode::SUCCESS
        }
        "ipc" => {
            let state = if matches!(normalized_level.as_str(), "true" | "1" | "on" | "debug" | "trace") { "true" } else { "false" };
            ok(&format!("Kernel IPC communication trace set to `{state}`"));
            ExitCode::SUCCESS
        }
        "all" => {
            let _ = config_set(json, "kernel.log_level", &normalized_level, apply);
            ok(&format!("All log tiers set to `{normalized_level}`"));
            ExitCode::SUCCESS
        }
        other => {
            crate::layout::error(&format!("unknown log target `{other}`, valid targets: app, kernel, ipc, all"));
            ExitCode::from(2)
        }
    }
}
