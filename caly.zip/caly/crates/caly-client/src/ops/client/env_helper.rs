//! Shell environment variable generator (`caly env`).
//!
//! Emits POSIX/Bash/Zsh/Fish shell commands for one-click proxy setup:
//! `eval $(caly env)` or `eval $(caly env --unset)`.

use std::process::ExitCode;

/// Emits export or unset commands for shell integration.
pub fn print_shell_env(unset: bool, fish: bool, mixed_port: u16) -> ExitCode {
    let port = if mixed_port == 0 { 7890 } else { mixed_port };
    if unset {
        if fish {
            println!("set -e http_proxy; set -e https_proxy; set -e all_proxy; set -e no_proxy;");
        } else {
            println!("unset http_proxy https_proxy all_proxy no_proxy");
        }
    } else {
        let http = format!("http://127.0.0.1:{port}");
        let socks = format!("socks5://127.0.0.1:{port}");
        let no_proxy = "localhost,127.0.0.1,local,*.local,10.0.0.0/8,172.16.0.0/12,192.168.0.0/16";
        if fish {
            println!("set -gx http_proxy {http};");
            println!("set -gx https_proxy {http};");
            println!("set -gx all_proxy {socks};");
            println!("set -gx no_proxy '{no_proxy}';");
        } else {
            println!("export http_proxy="{http}"");
            println!("export https_proxy="{http}"");
            println!("export all_proxy="{socks}"");
            println!("export no_proxy="{no_proxy}"");
        }
    }
    ExitCode::SUCCESS
}
