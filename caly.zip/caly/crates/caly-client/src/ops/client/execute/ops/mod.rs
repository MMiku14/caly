//! Lifecycle and mutation operations for the daemon execute path.
//!
//! Split out of `client/execute/mod.rs` (audit #70 file-length
//! budget): each helper assigns a fresh operation id, submits the
//! built [`WireCommand`], and either reports the immediate
//! terminal status or polls to a terminal state. Human output
//! reports a semantic summary; JSON output keeps the raw
//! operation record for scripts.

use std::process::ExitCode;

use caly_ipc::protocol::{
    client::{ClientContract, UdsClient},
    protocol::v2::{
        ExecuteRequest, ExecuteSyncRequest, GetOperationStatusRequest, RawOperationState,
        WireCommand, WireCoreAction, WireCoreKind, WireMode,
    },
};

use super::super::{operation_id, output};
mod select;

pub(super) use select::execute_select_proxy;
#[cfg(test)]
pub(crate) use select::parse_node_id;

/// Submits one operation, then reports the outcome. `immediate` callers
/// (stop daemon / reload config) run the Round-17 lifecycle path: the
/// server returns the final `WireOperationStatus` inside the
/// `ExecuteResponse`, so the client must NOT poll (the `StopDaemon` path
/// closes the UDS socket right after the response, and polling for a
/// stale id would surface a confusing `connect_failed` error). If the
/// response is somehow non-terminal (defensive), fall through to a
/// bounded poll. The mutation path (`immediate: false`) always polls to
/// a terminal state.
/// Server-owned synchronous execution for commands whose payload does not
/// embed the operation id. One RPC replaces the previous submit + poll loop.
pub(super) fn execute_sync_operation(
    client: &mut UdsClient,
    json: bool,
    summary: &str,
    build: impl FnOnce() -> WireCommand,
) -> ExitCode {
    match client.execute_sync(ExecuteSyncRequest {
        command: build(),
        timeout_ms: 20_000,
        poll_interval_ms: 100,
    }) {
        Ok(response) => {
            output::print_operation_status(&response.operation, json, summary);
            if response.operation.state.is_terminal() {
                terminal_exit_code(response.operation.state)
            } else {
                ExitCode::from(1) // server timeout while still running
            }
        }
        Err(error) => output::report_error(error, json),
    }
}

pub(super) fn execute_operation(
    client: &mut UdsClient,
    json: bool,
    summary: &str,
    immediate: bool,
    build: impl FnOnce([u8; 16]) -> WireCommand,
) -> ExitCode {
    let id = operation_id();
    match client.execute(ExecuteRequest {
        operation_id: id,
        command: build(id),
    }) {
        Ok(response) if immediate && response.operation.state.is_terminal() => {
            output::print_operation_status(&response.operation, json, summary);
            terminal_exit_code(response.operation.state)
        }
        Ok(_) => poll_operation(client, id, json, summary),
        Err(error) => output::report_error(error, json),
    }
}

/// Executes a `SetMode` operation against the daemon.
pub(super) fn execute_set_mode(client: &mut UdsClient, mode: &str, json: bool) -> ExitCode {
    let Some(mode_value) = WireMode::from_label(mode) else {
        return output::report_usage_error("mode must be rule, global, or direct", json);
    };
    execute_sync_operation(client, json, &format!("set mode to {mode}"), || {
        WireCommand::SetMode {
            mode: mode_value.wire(),
        }
    })
}

/// Switches the active core to `target` (stop previous kernel, start target).
pub(super) fn execute_switch_core(client: &mut UdsClient, target: &str, json: bool) -> ExitCode {
    let kind = match target {
        "sing-box" => WireCoreKind::SingBox,
        "mihomo" => WireCoreKind::Mihomo,
        other => {
            return output::report_usage_error(
                &format!("unknown core `{other}`; use mihomo or sing-box"),
                json,
            );
        }
    };
    execute_sync_operation(
        client,
        json,
        &format!("switch core to {}", kind.label()),
        || WireCommand::SwitchCore {
            core_kind: kind.wire(),
            action: WireCoreAction::Restart.wire(),
        },
    )
}

/// Executes a core lifecycle action (start/stop/restart) for the resolved core.
///
/// Without an explicit `--core`/`CALY_CORE`, the target follows the daemon's
/// runtime active core — so `caly core restart` restarts the kernel the user
/// actually switched to instead of silently switching to (or stopping it for)
/// a hardcoded mihomo.
pub(super) fn execute_core(
    client: &mut UdsClient,
    action: WireCoreAction,
    core: Option<&str>,
    json: bool,
) -> ExitCode {
    let effective = match core {
        Some(core) => Some(core.to_owned()),
        None => active_core_kind(client).map(|kind| kind.label().to_owned()),
    };
    let kind = match resolved_core_kind(effective.as_deref()) {
        Ok(kind) => kind,
        Err(message) => {
            let verb = match action {
                WireCoreAction::Start => "start",
                WireCoreAction::Stop => "stop",
                WireCoreAction::Restart => "restart",
            };
            return crate::layout::report_error_returning(
                crate::layout::CliOutput::from_json_flag(json),
                crate::layout::CliError::new(
                    crate::error::usage::INVALID,
                    message,
                    format!("core {verb}"),
                ),
            );
        }
    };
    let label = kind.label();
    let verb = match action {
        WireCoreAction::Start => "start",
        WireCoreAction::Stop => "stop",
        WireCoreAction::Restart => "restart",
    };
    execute_sync_operation(client, json, &format!("{verb} {label}"), || {
        WireCommand::SwitchCore {
            core_kind: kind.wire(),
            action: action.wire(),
        }
    })
}

/// Reads the daemon snapshot for the runtime active core kind.
pub(super) fn active_core_kind(client: &mut UdsClient) -> Option<WireCoreKind> {
    let snapshot = client.snapshot().ok()?;
    WireCoreKind::from_wire(snapshot.applied.core_kind?)
}

/// Resolves the target core: `--core` flag first, then `CALY_CORE`, default
/// mihomo. Unknown values fail loudly instead of silently falling back to
/// mihomo (a typo like `--core mihomoo` must not silently act on the wrong
/// kernel).
pub(super) fn resolved_core_kind(core: Option<&str>) -> Result<WireCoreKind, String> {
    let effective = core
        .map(str::to_owned)
        .or_else(|| std::env::var("CALY_CORE").ok());
    match effective.as_deref() {
        None | Some("mihomo") => Ok(WireCoreKind::Mihomo),
        Some("sing-box") => Ok(WireCoreKind::SingBox),
        Some("xray") => Ok(WireCoreKind::Xray),
        Some(other) => Err(format!(
            "unknown core target `{other}` (expected mihomo, sing-box or xray)"
        )),
    }
}

/// Polls an operation until it reaches a terminal state (or a bounded timeout).
/// `summary` describes the requested change for the human-readable result line.
fn poll_operation(client: &mut UdsClient, id: [u8; 16], json: bool, summary: &str) -> ExitCode {
    let deadline = std::time::Instant::now() + std::time::Duration::from_secs(20);
    loop {
        match client.operation_status(GetOperationStatusRequest { operation_id: id }) {
            Ok(status) => {
                if status.state.is_terminal() {
                    output::print_operation_status(&status, json, summary);
                    return terminal_exit_code(status.state);
                }
                if std::time::Instant::now() >= deadline {
                    output::print_operation_status(&status, json, summary);
                    return ExitCode::from(1); // TimedOutStillRunning (C-A: 1)
                }
            }
            Err(error) => return output::report_error(error, json),
        }
        std::thread::sleep(std::time::Duration::from_millis(200));
    }
}

/// Maps a terminal operation state to the CLI exit-code contract.
fn terminal_exit_code(state: RawOperationState) -> ExitCode {
    use caly_ipc::protocol::protocol::v2::WireOperationState;
    // C-A contract (cli-v3-design.md appendix B): 0 = success, 1 = any
    // execution failure (including operator cancellation); 3 is
    // reserved for doctor/dns probe failures. The v3.1 extension
    // codes 6/7 were never adopted (W3a review, BUG-3).
    match state.known() {
        Some(WireOperationState::Completed) => ExitCode::SUCCESS,
        Some(WireOperationState::Failed) | Some(WireOperationState::Cancelled) => ExitCode::from(1),
        _ => ExitCode::from(1), // still running / unknown
    }
}
