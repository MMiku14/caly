//! Offline subscription listing (`sub list` providers/sources table).

#[cfg(test)]
#[path = "list_render_tests.rs"]
mod list_render_tests;

// ── offline subscription inspection ───────────────

/// `caly sub list` (v1 `show sub providers`) — list the
/// configured subscription providers and their sources.
/// W2 (§5.1/§5.4): adaptive table/TSV human face.
pub fn list_providers(
    json: bool,
    format: Option<crate::types::OutputFormat>,
    socket: Option<&std::path::PathBuf>,
) -> std::process::ExitCode {
    // CLI sinking (2026-08-14, read path): online-first — the daemon
    // snapshot carries the declared source listing (computed by the
    // shared configstore pipeline, lenient cache counts). Offline
    // fallback re-computes from config + cache with the same
    // implementation.
    match try_online_sources(socket) {
        Ok(sources) if !sources.is_empty() => {
            return render_source_listing(json, format, sources);
        }
        _ => {}
    }
    let root = caly_platform::paths::AppPaths::from_env().config;
    let (declared, _providers) = match crate::config::load_from(root) {
        Ok(None) => (
            caly_profile::schema::SubscriptionConfig::default(),
            Vec::new(),
        ),
        Ok(Some(config)) => (config.subscriptions.clone(), config.resolved_providers()),
        Err(error) => {
            return crate::layout::report_error_returning(
                crate::layout::CliOutput::from_json_flag(json),
                crate::layout::CliError::new(
                    "sub.list_failed",
                    format!("subscription list failed: {error}"),
                    "sub list",
                ),
            );
        }
    };
    // The offline rows come from the shared configstore pipeline — the
    // same 1-based `SourceView`s the daemon publishes — projected into
    // the JSON row model, so online and offline agree on ids, names
    // and lenient cache counts (previously a private duplicate here
    // drifted: strict Clash counts and 0-based ids).
    let paths = caly_platform::paths::AppPaths::from_env();
    let sources: Vec<serde_json::Value> =
        caly_profile::store::source_listing::compute_source_views(&paths, &declared)
            .into_iter()
            .map(source_view_row)
            .collect();
    render_source_listing(json, format, sources)
}

/// Projects one shared [`caly_domain::SourceView`] into the JSON row
/// model — the same keys [`try_online_sources`] builds from the
/// snapshot, so the renderer and the JSON contract cannot tell online
/// from offline apart.
fn source_view_row(view: caly_domain::SourceView) -> serde_json::Value {
    serde_json::json!({
        "index": view.index,
        "name": view.name,
        "kind": view.kind,
        "url": view.url,
        "enabled": view.enabled,
        "nodes": view.nodes,
        "groups": view.groups.join(", "),
        "cached": view.cached,
        "last_refresh": view.last_refresh_unix,
        "next_refresh": view.next_refresh_unix,
    })
}

/// Shared renderer for the unified listing (online or offline rows).
fn render_source_listing(
    json: bool,
    format: Option<crate::types::OutputFormat>,
    sources: Vec<serde_json::Value>,
) -> std::process::ExitCode {
    use std::process::ExitCode;
    let root = caly_platform::paths::AppPaths::from_env().config;
    let (_, providers) = match crate::config::load_from(root) {
        Ok(Some(config)) => (config.subscriptions.clone(), config.resolved_providers()),
        _ => (
            caly_profile::schema::SubscriptionConfig::default(),
            Vec::new(),
        ),
    };
    if providers.is_empty() {
        return render_empty_providers(json, format, sources);
    }
    if json {
        let items: Vec<serde_json::Value> = providers
            .iter()
            .map(|p| provider_json_item(p, &sources))
            .collect();
        println!(
            "{}",
            serde_json::json!({
                "providers": items,
                "sources": sources,
                "count": providers.len(),
            })
        );
    } else {
        // W2 (cli-v3-design.md §5.1/§5.4, Q6): one adaptive
        // table — subscription sources and inline-provider
        // nodes share the NAME/TYPE/SOURCE columns; W3a adds the
        // offline-cache-derived NODES/GROUPS/LAST REFRESH/
        // NEXT REFRESH columns (never a live parse) and the ⚠
        // stale badge (enabled source with no cached body). The
        // v1 provider wrapper lines and the trailing `N provider(s)`
        // count are retired (JSON keeps `providers` and `count`).
        let mode = crate::layout::table_mode(format);
        let headers: &[&str] = match mode {
            crate::layout::TableMode::Tsv => &[
                "id",
                "name",
                "type",
                "source",
                "nodes",
                "groups",
                "last_refresh",
                "next_refresh",
                "status",
            ],
            crate::layout::TableMode::Table => &[
                "ID",
                "NAME",
                "TYPE",
                "SOURCE",
                "NODES",
                "GROUPS",
                "LAST REFRESH",
                "NEXT REFRESH",
                "STATUS",
            ],
        };
        let rows = provider_rows(mode, &sources, &providers);
        if rows.is_empty() && mode == crate::layout::TableMode::Table {
            crate::layout::empty(
                "subscription sources",
                Some("add one with `caly sub add <url-or-file> --apply`"),
            );
        } else {
            crate::layout::print_table(mode, headers, &rows);
        }
    }
    ExitCode::SUCCESS
}

/// Online-first source listing: reads the daemon snapshot's declared
/// sources. Returns `Err` when the daemon is unreachable (the offline
/// fallback takes over).
fn try_online_sources(
    socket: Option<&std::path::PathBuf>,
) -> Result<Vec<serde_json::Value>, caly_ipc::protocol::client::ClientError> {
    use caly_ipc::protocol::client::ClientContract;
    let socket = crate::client::resolve_client_socket(socket);
    let mut client = crate::client::UdsClient::connect(socket)?;
    let snapshot = client.snapshot()?;
    Ok(snapshot
        .sources
        .into_vec()
        .into_iter()
        .map(|source| {
            serde_json::json!({
                "index": source.index,
                "name": source.name.to_string(),
                "kind": source.kind.to_string(),
                "url": source.url.to_string(),
                "enabled": source.enabled,
                "nodes": source.nodes,
                "groups": source.groups.into_vec().into_iter().map(|g| g.to_string()).collect::<Vec<_>>().join(", "),
                "cached": source.cached,
                "last_refresh": source.last_refresh_unix,
                "next_refresh": source.next_refresh_unix,
            })
        })
        .collect())
}

/// Builds the W2/W3a unified listing rows: one row per subscription
/// source (`#<1-based index>` when unnamed), then one row per
/// inline-provider node. STATUS is the ●○⚠ badge on a TTY and the
/// `ok`/`disabled`/`stale` word in TSV; inline nodes carry no enable
/// state, hence `-`.
fn provider_rows(
    mode: crate::layout::TableMode,
    sources: &[serde_json::Value],
    providers: &[caly_profile::schema::ProviderConfig],
) -> Vec<Vec<String>> {
    let mut rows: Vec<Vec<String>> = Vec::new();
    let now = crate::layout::now_unix();
    for row in sources {
        let enabled = row["enabled"].as_bool() == Some(true);
        // ID column: the 1-based add-order id shared with
        // `resolve_source_ref` (`sub remove 2` / `sub refresh 3` …).
        // Both row producers (daemon snapshot, offline configstore
        // views) already carry 1-based `index`, so it renders as-is —
        // the old `+ 1` double-counted the online rows.
        let id = row["index"].as_u64().unwrap_or(0).to_string();
        let name = row["name"]
            .as_str()
            .map_or_else(|| format!("#{id}"), str::to_owned);
        let cached = row["cached"].as_bool() == Some(true);
        let nodes = row["nodes"].as_u64().unwrap_or(0);
        let groups = row["groups"]
            .as_str()
            .map_or_else(String::new, str::to_owned);
        let last_refresh = row["last_refresh"].as_u64();
        let next_refresh = row["next_refresh"].as_u64();
        let status = match mode {
            crate::layout::TableMode::Tsv => crate::layout::source_word(enabled, cached).to_owned(),
            // Paint is gated inside the badge (real terminal only —
            // an explicit `--format=table` into a pipe stays clean).
            crate::layout::TableMode::Table => crate::layout::source_badge(enabled, cached),
        };
        let (last_cell, next_cell) = match mode {
            crate::layout::TableMode::Tsv => (
                last_refresh.map_or_else(String::new, |ts| ts.to_string()),
                next_refresh.map_or_else(String::new, |ts| ts.to_string()),
            ),
            crate::layout::TableMode::Table => (
                crate::layout::relative_time(now, last_refresh),
                crate::layout::relative_time(now, next_refresh),
            ),
        };
        rows.push(vec![
            id,
            name,
            "subscription".to_owned(),
            row["url"].as_str().unwrap_or("").to_owned(),
            nodes.to_string(),
            groups.clone(),
            last_cell,
            next_cell,
            status,
        ]);
    }
    for p in providers {
        if let caly_profile::schema::ProviderKind::InlineNodes(nodes) = &p.kind {
            for node in nodes {
                rows.push(vec![
                    "-".to_owned(),
                    p.name.clone(),
                    "inline-node".to_owned(),
                    node.clone(),
                    "-".to_owned(),
                    "-".to_owned(),
                    "-".to_owned(),
                    "-".to_owned(),
                    "-".to_owned(),
                ]);
            }
        }
    }
    rows
}

/// The no-provider face (extracted for the 100-line budget): JSON keeps
/// the empty envelope, sources-only configs still list their rows on the
/// human face (CLI audit — "no provider" was misleading when
/// sources exist), a bare TSV prints the header contract, and an
/// absolutely empty config gets the actionable hint.
fn render_empty_providers(
    json: bool,
    format: Option<crate::types::OutputFormat>,
    sources: Vec<serde_json::Value>,
) -> std::process::ExitCode {
    use std::process::ExitCode;
    let mode = crate::layout::table_mode(format);
    let headers: &[&str] = match mode {
        crate::layout::TableMode::Tsv => &[
            "id",
            "name",
            "type",
            "source",
            "nodes",
            "groups",
            "last_refresh",
            "next_refresh",
            "status",
        ],
        crate::layout::TableMode::Table => &[
            "ID",
            "NAME",
            "TYPE",
            "SOURCE",
            "NODES",
            "GROUPS",
            "LAST REFRESH",
            "NEXT REFRESH",
            "STATUS",
        ],
    };
    if json {
        println!(
            "{}",
            serde_json::json!({ "providers": [], "sources": sources, "count": 0 })
        );
    } else if !sources.is_empty() {
        let rows = provider_rows(mode, &sources, &[]);
        crate::layout::print_table(mode, headers, &rows);
    } else if mode == crate::layout::TableMode::Tsv {
        crate::layout::print_table(mode, headers, &[]);
    } else {
        crate::layout::empty(
            "subscription providers",
            Some(
                "set `subscriptions.url` or `subscriptions.sources` in config.yaml to create the default provider",
            ),
        );
    }
    ExitCode::SUCCESS
}

/// Renders one provider as its JSON row. Kind-specific
/// payload lives under its own key so consumers never
/// see a subscription provider's source list mirrored
/// onto an inline provider.
fn provider_json_item(
    p: &caly_profile::schema::ProviderConfig,
    sources: &[serde_json::Value],
) -> serde_json::Value {
    use caly_profile::schema::ProviderKind;
    match &p.kind {
        ProviderKind::SubscriptionSources => serde_json::json!({
            "name": p.name,
            "kind": "subscription-sources",
            "source_urls": sources
                .iter()
                .filter(|row| row["enabled"].as_bool() == Some(true))
                .filter_map(|row| row["url"].as_str().map(str::to_owned))
                .collect::<Vec<_>>(),
        }),
        ProviderKind::InlineNodes(nodes) => serde_json::json!({
            "name": p.name,
            "kind": "inline-nodes",
            "nodes": nodes,
        }),
    }
}
