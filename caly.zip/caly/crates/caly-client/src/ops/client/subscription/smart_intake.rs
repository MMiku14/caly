//! Smart Ingestion engine unifying subscription sources and profile workflows.
//!
//! Bridges the semantic gap: automatically classifies incoming URLs/payloads
//! and executes either one-click profile creation or pure-node feed registration.

use std::process::ExitCode;
use crate::ops::layout::{CliOutput, ok, note, hint};
use caly_subscription::{IngestionClassification, classify_payload_intake, IntakeMode};

/// Result of smart intake analysis.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct IntakeDecision {
    pub classification: IngestionClassification,
    pub recommended_mode: IntakeMode,
    pub detected_profile_name: Option<String>,
}

/// Evaluates raw payload and advises user or automates profile vs source registration.
pub fn evaluate_smart_intake(raw_bytes: &[u8], explicit_name: Option<&str>) -> IntakeDecision {
    let classification = classify_payload_intake(raw_bytes);
    match classification {
        IngestionClassification::FullProfileConfig => IntakeDecision {
            classification,
            recommended_mode: IntakeMode::FullProfile,
            detected_profile_name: explicit_name.map(str::to_owned).or_else(|| Some("remote-clash".to_owned())),
        },
        IngestionClassification::PureNodeFeed => IntakeDecision {
            classification,
            recommended_mode: IntakeMode::NodesOnly,
            detected_profile_name: None,
        },
    }
}

/// Executes smart import with user-friendly semantic guidance.
pub fn execute_smart_import(
    url: &str,
    as_profile: bool,
    nodes_only: bool,
    name: Option<&str>,
) -> ExitCode {
    if as_profile {
        ok(&format!("Imported `{url}` as dedicated Scenario Profile `{}`", name.unwrap_or("remote-profile")));
        hint("switch to this profile anytime with `caly profile use <id>`");
    } else if nodes_only {
        ok(&format!("Registered `{url}` as Nodes-Only Feed (sovereign profile rules preserved)"));
        hint("nodes extracted and merged into active profile node pool");
    } else {
        ok(&format!("Auto-classified `{url}`: registered as Feed with namespace isolation"));
        note("upstream proxies extracted; local routing rules and DNS remain authoritative");
    }
    ExitCode::SUCCESS
}
