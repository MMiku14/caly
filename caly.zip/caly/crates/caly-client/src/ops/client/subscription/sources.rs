//! Subscription source writers (`set sub add/remove/enable/disable`).
//!
//! Thin offline adapter over
//! [`caly_profile::store::subscription_sources`] — the same
//! implementation the daemon's config-mutation actor runs. The
//! proxy-group / rule-provider adapters sank in the CLI-sinking
//! round; the subscription writer was left behind as a ~450-line
//! line-for-line fork and sank here. The adapter only:
//! - bootstraps a missing `config.yaml` (fresh install) before
//!   delegating — the daemon always has a config, the CLI may not;
//! - keeps the legacy-scalar `remove` refusal the shared writer
//!   does not know about;
//! - projects the shared error / preview types onto the stable
//!   CLI [`SubCmdError`] / [`SubWriteOutcome`] vocabulary.
//!
//! Behavioral proof: `client/subscription/tests.rs` runs unchanged
//! against the delegation.

use caly_profile::store::subscription_sources::{self as store, SourceWritePreview};
use caly_platform::paths::AppPaths;

use super::{SubCmdError, SubWriteOutcome, ensure_config, load_declared_with};

/// Projects the shared write preview onto the CLI outcome: an
/// untouched file is `NoChange` (even on the apply path — the
/// shared writer reports `applied: false` for idempotent calls), a
/// real write is `Applied`, and anything else is a dry-run preview.
fn map_preview(preview: SourceWritePreview) -> SubWriteOutcome {
    if preview.unchanged {
        SubWriteOutcome::NoChange
    } else if preview.applied {
        SubWriteOutcome::Applied
    } else {
        SubWriteOutcome::DryRun
    }
}

/// Resolves the `<name-or-url>` addressing token shared by `sub set`
/// / `sub refresh` / `sub remove` / `sub enable|disable` into the
/// source's stored URL.
pub fn resolve_source_ref(paths: &AppPaths, token: &str) -> Result<String, SubCmdError> {
    ensure_config(paths)?;
    store::resolve_source_ref(paths, token).map_err(SubCmdError::from)
}

/// `set sub add <url-or-file> [--name N] [--every M] [--apply]`.
pub fn add_source(
    paths: &AppPaths,
    token: &str,
    name: Option<&str>,
    refresh_every_minutes: Option<u64>,
    apply: bool,
) -> Result<SubWriteOutcome, SubCmdError> {
    ensure_config(paths)?;
    store::add_source(paths, token, name, refresh_every_minutes, apply)
        .map(map_preview)
        .map_err(SubCmdError::from)
}

/// `set sub set <name-or-url> [--url U] [--name N] [--every M]
/// [--apply]`: edits one declared source in place.
pub fn set_source(
    paths: &AppPaths,
    target: &str,
    new_url: Option<&str>,
    new_name: Option<&str>,
    refresh_every_minutes: Option<u64>,
    apply: bool,
) -> Result<SubWriteOutcome, SubCmdError> {
    ensure_config(paths)?;
    store::set_source(
        paths,
        target,
        new_url,
        new_name,
        refresh_every_minutes,
        apply,
    )
    .map(map_preview)
    .map_err(SubCmdError::from)
}

/// `set sub remove <name-or-url> [--purge] [--apply]`.
///
/// The legacy scalar `subscriptions.url` (id 1) is not part of the
/// `sources` list; `remove` cannot delete it, and purging its cache
/// would silently starve a still-declared source — hence the refusal
/// the shared writer does not know about.
pub fn remove_source(
    paths: &AppPaths,
    target: &str,
    purge: bool,
    apply: bool,
) -> Result<SubWriteOutcome, SubCmdError> {
    ensure_config(paths)?;
    let url = store::resolve_source_ref(paths, target).map_err(SubCmdError::from)?;
    let config = load_declared_with(paths)?;
    if config.subscriptions.url.as_deref() == Some(url.as_str()) {
        return Err(SubCmdError::InvalidUrl(
            "the legacy `subscriptions.url` cannot be removed via `sub`; edit config.yaml to drop it"
                .to_owned(),
        ));
    }
    store::remove_source(paths, &url, purge, apply)
        .map(map_preview)
        .map_err(SubCmdError::from)
}

/// `set sub enable <name-or-url> [--apply]`.
pub fn enable_source(
    paths: &AppPaths,
    target: &str,
    apply: bool,
) -> Result<SubWriteOutcome, SubCmdError> {
    ensure_config(paths)?;
    store::set_enabled(paths, target, true, apply)
        .map(map_preview)
        .map_err(SubCmdError::from)
}

/// `set sub disable <name-or-url> [--apply]`.
pub fn disable_source(
    paths: &AppPaths,
    target: &str,
    apply: bool,
) -> Result<SubWriteOutcome, SubCmdError> {
    ensure_config(paths)?;
    store::set_enabled(paths, target, false, apply)
        .map(map_preview)
        .map_err(SubCmdError::from)
}
