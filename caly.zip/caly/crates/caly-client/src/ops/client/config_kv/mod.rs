//! `config get` / `config set` — scalar key/value access over the
//! layered config.
//!
//! Reads resolve per layer (base → active profile → `config.d/*` in
//! loader order); the last layer declaring the path wins — exactly
//! `deep_merge`'s rule for scalar leaves, without reimplementing the
//! merge. Every answer carries its source file, so a shadowing
//! surprise is impossible to miss. Writes edit the winning file in
//! place through comment-preserving line surgery; a key no layer
//! declares is refused with the missing parent named — typos fail
//! loudly instead of scattering new keys. The merged tree is
//! re-validated after every write and the original bytes restored on
//! failure, so a bad value never reaches disk.
//!
//! Keys are dotted snake_case paths (`kernel.mixed_port`,
//! `dns.mode`); only scalars are gettable/settable as values —
//! sections and lists go through `config edit`.

use std::path::{Path, PathBuf};
use std::process::ExitCode;

use caly_platform::paths::{AppPaths, SafeName};
use serde_norway::Value;

mod get;
mod set;

pub use get::config_get;
pub use set::{ScalarFailure, ScalarOutcome, apply_scalar, config_set};

#[cfg(test)]
mod tests;

/// One parsed layer file.
pub(super) struct Layer {
    path: PathBuf,
    text: String,
    value: Value,
}

/// Resolves the active profile the way `crate::config::load_from`
/// does (`CALY_PROFILE` override, else the `profile use` context).
pub fn active_profile() -> Result<Option<SafeName>, String> {
    match std::env::var("CALY_PROFILE") {
        Ok(value) => SafeName::new(value)
            .map(Some)
            .map_err(|_| "invalid CALY_PROFILE (must be path-safe ASCII)".to_owned()),
        Err(_) => Ok(crate::client::context::active_profile()),
    }
}

/// Layer files in loader merge order: base, active profile overlay,
/// `config.d/*.yaml|*.yml` sorted. Missing files are skipped; an
/// unreadable or unparseable file is a hard error (the merged tree
/// would refuse to load anyway).
pub(super) fn load_layers(
    paths: &AppPaths,
    profile: Option<&SafeName>,
) -> Result<Vec<Layer>, String> {
    let mut files = vec![paths.config.join("config.yaml")];
    if let Some(name) = profile {
        files.push(
            paths
                .config
                .join("profiles")
                .join(format!("{}.yaml", name.as_str())),
        );
    }
    let fragments = paths.config.join("config.d");
    if fragments.is_dir() {
        let entries = std::fs::read_dir(&fragments)
            .map_err(|error| format!("cannot list {}: {error}", fragments.display()))?;
        let mut extra: Vec<PathBuf> = Vec::new();
        for entry in entries {
            let path = entry
                .map_err(|error| format!("cannot list {}: {error}", fragments.display()))?
                .path();
            if matches!(
                path.extension().and_then(|value| value.to_str()),
                Some("yaml" | "yml")
            ) {
                extra.push(path);
            }
        }
        extra.sort();
        files.extend(extra);
    }
    let mut layers = Vec::new();
    for path in files {
        if !path.is_file() {
            continue;
        }
        let text = std::fs::read_to_string(&path)
            .map_err(|error| format!("cannot read {}: {error}", path.display()))?;
        let value: Value = serde_norway::from_str(&text)
            .map_err(|error| format!("cannot parse {}: {error}", path.display()))?;
        layers.push(Layer { path, text, value });
    }
    Ok(layers)
}

/// Splits a dotted key (`a.b.c`) into segments. Empty keys and empty
/// segments are usage errors (exit 2); unknown-but-well-formed keys
/// are lookup failures (exit 1) reported by the caller.
pub(super) fn parse_key(key: &str) -> Result<Vec<&str>, String> {
    let segments: Vec<&str> = key.split('.').collect();
    if key.trim().is_empty() || segments.iter().any(|segment| segment.trim().is_empty()) {
        return Err(format!(
            "malformed config key `{key}` (dotted path, e.g. kernel.mixed_port)"
        ));
    }
    Ok(segments)
}

/// Walks one layer's value down `path`. `None` when any level is
/// missing or not a mapping.
pub(super) fn walk<'a>(value: &'a Value, path: &[&str]) -> Option<&'a Value> {
    let mut current = value;
    for segment in path {
        current = current.as_mapping()?.get(Value::from(*segment))?;
    }
    Some(current)
}

/// Whether `value` is a settable scalar (strings, numbers, booleans).
/// Null reads as `null` but is never written (`config set` refuses
/// empty values; clear a line with `config edit`).
pub(super) fn is_scalar(value: &Value) -> bool {
    matches!(value, Value::String(_) | Value::Number(_) | Value::Bool(_))
}

/// Human display of a scalar leaf. Strings print raw (no quotes);
/// numbers and booleans print canonically; anything else renders as
/// a YAML fragment.
pub(super) fn display_scalar(value: &Value) -> String {
    match value {
        Value::String(text) => text.clone(),
        Value::Number(number) => number.to_string(),
        Value::Bool(flag) => flag.to_string(),
        Value::Null => "null".to_owned(),
        other => serde_norway::to_string(other)
            .unwrap_or_default()
            .trim_end()
            .to_owned(),
    }
}

/// Converts a YAML value to JSON for the `--json` envelopes.
/// Non-string mapping keys (anchors, merge keys) are skipped.
pub(super) fn to_json(value: &Value) -> serde_json::Value {
    match value {
        Value::Null => serde_json::Value::Null,
        Value::Bool(flag) => serde_json::Value::Bool(*flag),
        Value::Number(number) => {
            if let Some(int) = number.as_i64() {
                serde_json::Value::from(int)
            } else if let Some(uint) = number.as_u64() {
                serde_json::Value::from(uint)
            } else if let Some(float) = number.as_f64() {
                serde_json::Value::from(float)
            } else {
                serde_json::Value::from(number.to_string())
            }
        }
        Value::String(text) => serde_json::Value::from(text.clone()),
        Value::Sequence(items) => serde_json::Value::Array(items.iter().map(to_json).collect()),
        Value::Mapping(entries) => {
            let mut object = serde_json::Map::new();
            for (key, item) in entries {
                if let Value::String(name) = key {
                    object.insert(name.clone(), to_json(item));
                }
            }
            serde_json::Value::Object(object)
        }
        Value::Tagged(tagged) => to_json(&tagged.value),
    }
}

/// Renders `path` relative to the config root for receipts.
pub(super) fn relative_to(root: &Path, path: &Path) -> String {
    path.strip_prefix(root).map_or_else(
        |_| path.display().to_string(),
        |relative| relative.display().to_string(),
    )
}

pub(super) fn report(
    code: &'static str,
    command: &'static str,
    message: String,
    hint: Option<&str>,
    json: bool,
) -> ExitCode {
    let mut error = crate::layout::CliError::new(code, message, command);
    if let Some(hint) = hint {
        error = error.with_hint(hint);
    }
    crate::layout::report_error_returning(crate::layout::CliOutput::from_json_flag(json), error)
}
