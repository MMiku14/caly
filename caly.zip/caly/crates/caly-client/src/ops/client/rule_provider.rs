//! Offline rule-provider writer for the `set rule-provider …` leaves.
//!
//! Since the CLI-sinking round 2, the write semantics live
//! in ONE shared implementation, `caly_profile::store::resource_mutations`
//! (the same code the daemon's config-mutation actor runs); this module
//! is the CLI's thin offline adapter: it maps the CLI grammar types
//! (`RpSourceSpec` / `RpBehavior`) onto the wire payloads and projects
//! the shared error enum onto the stable `RpWriteError` codes.

use std::path::PathBuf;

use caly_domain::{RuleProviderMutation, RuleProviderSourceRef};
use caly_platform::paths::AppPaths;

use caly_profile::store::resource_mutations::ResourceMutationError;
use caly_profile::store::resource_writer::{ResourceError, ResourceWriteOutcome};

/// Rule-provider-specific error variants. Some variants are only
/// constructed under `cfg(test)`; the allow keeps non-test builds quiet.
#[allow(dead_code)]
#[derive(Debug)]
pub enum RpWriteError {
    InvalidName(String),
    AlreadyDeclared(String),
    NotDeclared(String),
    InvalidBehavior(String),
    InvalidUrl(String),
    Shared(ResourceError),
}

impl core::fmt::Display for RpWriteError {
    fn fmt(&self, formatter: &mut core::fmt::Formatter<'_>) -> core::fmt::Result {
        match self {
            Self::InvalidName(name) => write!(
                formatter,
                "rule provider name `{name}` is not path-safe ASCII"
            ),
            Self::AlreadyDeclared(name) => {
                write!(formatter, "rule provider `{name}` is already declared")
            }
            Self::NotDeclared(name) => write!(formatter, "rule provider `{name}` is not declared"),
            Self::InvalidBehavior(reason) => {
                write!(formatter, "invalid rule provider behavior: {reason}")
            }
            Self::InvalidUrl(reason) => write!(formatter, "invalid rule provider URL: {reason}"),
            Self::Shared(shared) => write!(formatter, "{shared}"),
        }
    }
}

impl std::error::Error for RpWriteError {}

impl crate::layout::ErrorHint for RpWriteError {}

impl From<ResourceError> for RpWriteError {
    fn from(value: ResourceError) -> Self {
        match value {
            ResourceError::AlreadyDeclared(name) => Self::AlreadyDeclared(name),
            ResourceError::NotDeclared(name) => Self::NotDeclared(name),
            other => Self::Shared(other),
        }
    }
}

impl From<ResourceMutationError> for RpWriteError {
    fn from(value: ResourceMutationError) -> Self {
        match value {
            ResourceMutationError::InvalidName(name) => Self::InvalidName(name),
            ResourceMutationError::AlreadyDeclared(name) => Self::AlreadyDeclared(name),
            ResourceMutationError::NotDeclared(name) => Self::NotDeclared(name),
            ResourceMutationError::InvalidUrl(reason) => Self::InvalidUrl(reason),
            ResourceMutationError::InvalidKind(kind) => {
                Self::Shared(ResourceError::Invalid(format!("unknown kind `{kind}`")))
            }
            ResourceMutationError::MissingUrl(name) => Self::Shared(ResourceError::Invalid(
                format!("entry `{name}` requires --url"),
            )),
            ResourceMutationError::UnexpectedUrl(name) => Self::Shared(ResourceError::Invalid(
                format!("entry `{name}` is a select/relay; --url is ignored"),
            )),
            ResourceMutationError::Shared(shared) => Self::Shared(shared),
        }
    }
}

/// Source-kind spec for the CLI writer. Mirrors
/// `cli::RuleProviderSourceSpec` but erases the bounded text / path.
#[derive(Debug, Clone)]
pub enum RpSourceSpec {
    Http { url: String, interval_ms: u64 },
    File { path: PathBuf },
    Inline { payload: String },
}

impl RpSourceSpec {
    /// Maps to the wire source ref.
    pub fn to_ref(&self) -> RuleProviderSourceRef {
        match self {
            Self::Http { url, interval_ms } => RuleProviderSourceRef::Http {
                url: url.clone(),
                interval_ms: *interval_ms,
            },
            Self::File { path } => RuleProviderSourceRef::File {
                path: path.display().to_string(),
            },
            Self::Inline { payload } => RuleProviderSourceRef::Inline {
                payload: payload.clone(),
            },
        }
    }
}

/// The behavior the rule body contains. Non-default variants are
/// currently only constructed by tests; see above.
#[allow(dead_code)]
#[derive(Debug, Clone, Copy)]
pub enum RpBehavior {
    Domain,
    DomainSuffix,
    IpCidr,
    Classical,
}

impl RpBehavior {
    /// Default when the operator does not pass `--behavior` explicitly.
    pub const DEFAULT: Self = Self::Domain;

    /// The wire `--behavior` spelling (kebab-case).
    pub const fn cli_name(self) -> &'static str {
        match self {
            Self::Domain => "domain",
            Self::DomainSuffix => "domain-suffix",
            Self::IpCidr => "ip-cidr",
            Self::Classical => "classical",
        }
    }
}

/// Re-export of the unified `Outcome` shape.
pub type RpWriteOutcome = ResourceWriteOutcome;

/// `set rule-provider add-http|add-file|add-inline`.
pub fn add_provider(
    paths: &AppPaths,
    name: &str,
    source: &RpSourceSpec,
    behavior: RpBehavior,
    apply: bool,
) -> Result<RpWriteOutcome, RpWriteError> {
    let mutation = RuleProviderMutation::Add {
        name: name.to_owned(),
        source: source.to_ref(),
        behavior: Some(behavior.cli_name().to_owned()),
    };
    caly_profile::store::resource_mutations::mutate_rule_provider(paths, &mutation, apply)
        .map_err(RpWriteError::from)
}

/// `set rule-provider remove` — filters the `rule_providers:` list.
pub fn remove_provider(
    paths: &AppPaths,
    name: &str,
    apply: bool,
) -> Result<RpWriteOutcome, RpWriteError> {
    let mutation = RuleProviderMutation::Remove {
        name: name.to_owned(),
    };
    caly_profile::store::resource_mutations::mutate_rule_provider(paths, &mutation, apply)
        .map_err(RpWriteError::from)
}

/// `set rule-provider enable|disable` — flips the `enabled` flag.
pub fn set_enabled(
    paths: &AppPaths,
    name: &str,
    enabled: bool,
    apply: bool,
) -> Result<RpWriteOutcome, RpWriteError> {
    let mutation = if enabled {
        RuleProviderMutation::Enable {
            name: name.to_owned(),
        }
    } else {
        RuleProviderMutation::Disable {
            name: name.to_owned(),
        }
    };
    caly_profile::store::resource_mutations::mutate_rule_provider(paths, &mutation, apply)
        .map_err(RpWriteError::from)
}

#[cfg(test)]
mod tests;
