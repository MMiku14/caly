//! Mutating commands for the `caly profile` subcommand.
//!
//! Split out of `client/profile.rs` (audit #70 file-length budget).
//! Every writer here goes through the shared
//! `caly_profile::store::resource_writer::mutate_list_at` primitive (the
//! same pipeline the daemon's config-mutation actor runs): it picks
//! the fragment that declares `profiles:` when one exists (a
//! fragment-declared sequence REPLACES the base key on layered merge,
//! so a base write would be silently invisible), backs up, validates,
//! and atomically rewrites — comments and unknown keys elsewhere in
//! the target file survive.

use std::path::Path;

use caly_domain::is_path_safe_component;
use caly_platform::paths::AppPaths;
use caly_profile::{
    profile_store::ProfileStoreError,
    schema::{ProfileConfig, ProfileSourceConfig},
};

use super::{
    ProfileCmdError, ProfileSourceKind, ProfileWriteOutcome, find_declared, load_declared_profiles,
};
use caly_profile::store::resource_writer::current_unix_ms;

/// Appends a new `ProfileConfig` to the `profiles:` list (the
/// `config.d/` fragment declaring it when one exists, else the
/// base config — resolved by the shared primitive). The target is parsed, validated,
/// and re-emitted with the new entry; the layout is preserved
/// (the existing top-level order is kept). `Local` source kinds
/// must already point at a file the operator owns; this function
/// does not materialise the body.
///
/// `dry_run` builds the new `AppConfig` and runs every check
/// (uniqueness, path safety, validation) but does **not**
/// write to disk. The caller surfaces the result so the CLI
/// can print "would have added profile `x`" without touching
/// the operator's file.
pub fn add_profile(
    paths: &AppPaths,
    id: &str,
    source: ProfileSourceKind,
    dry_run: bool,
) -> Result<ProfileWriteOutcome, ProfileCmdError> {
    if !is_path_safe_component(id) {
        return Err(ProfileCmdError::InvalidId(id.to_owned()));
    }
    let (config, _store) = load_declared_profiles(paths)?;
    if find_declared(&config, id).is_some() {
        return Err(ProfileCmdError::AlreadyDeclared(id.to_owned()));
    }
    let entry = build_profile_config(id, source);
    if dry_run {
        return Ok(ProfileWriteOutcome::DryRun);
    }
    mutate_profiles_in_config(paths, |current| {
        let mut next = current.to_vec();
        next.push(entry);
        Ok(next)
    })?;
    Ok(ProfileWriteOutcome::Applied)
}

/// Removes a profile from the `profiles:` list and clears its cache.
/// When `dry_run` is set, the call validates and prints
/// "would have removed profile `x`" without touching the
/// file.
pub fn remove_profile(
    paths: &AppPaths,
    id: &str,
    dry_run: bool,
) -> Result<ProfileWriteOutcome, ProfileCmdError> {
    if !is_path_safe_component(id) {
        return Err(ProfileCmdError::InvalidId(id.to_owned()));
    }
    let (config, store) = load_declared_profiles(paths)?;
    if find_declared(&config, id).is_none() {
        return Err(ProfileCmdError::NotDeclared(id.to_owned()));
    }
    if dry_run {
        return Ok(ProfileWriteOutcome::DryRun);
    }
    store.remove(id)?;
    let target = id.to_owned();
    mutate_profiles_in_config(paths, |current| {
        Ok(current
            .iter()
            .filter(|entry| entry.id != target)
            .cloned()
            .collect())
    })?;
    Ok(ProfileWriteOutcome::Applied)
}

/// Flips the `enabled` flag on a declared profile. The
/// schema default is `enabled: true` (Round 15 added the
/// field), so `enable` is a no-op for a fresh entry and
/// `disable` is the meaningful state transition.
///
/// the `apply: bool` parameter was added so
/// the dry-run path lives in the writer (matching the
/// pre-Round-22 contract that all 5 profile writers
/// accept a dry-run flag). Pre-Round 30 the dispatch
/// inlined the dry-run validation: it duplicated the
/// path-safety check, the load, the existence scan, and
/// the `CliError::new(…)` construction — a 60-line
/// dry-run shape that mirrored the apply path but lived
/// in a separate code path. Folding the dry-run branch
/// into the writer removes the duplication: the
/// writer's single existence scan now drives both the
/// apply and the dry-run outcome, and the dispatch's
/// `set_enabled_dispatch` collapses to a 1-line
/// `run_writer` call.
pub fn set_profile_enabled(
    paths: &AppPaths,
    id: &str,
    enabled: bool,
    apply: bool,
) -> Result<ProfileWriteOutcome, ProfileCmdError> {
    if !is_path_safe_component(id) {
        return Err(ProfileCmdError::InvalidId(id.to_owned()));
    }
    let (config, _store) = load_declared_profiles(paths)?;
    if find_declared(&config, id).is_none() {
        return Err(ProfileCmdError::NotDeclared(id.to_owned()));
    }
    if !apply {
        return Ok(ProfileWriteOutcome::DryRun);
    }
    let target = id.to_owned();
    let outcome = mutate_profiles_in_config(paths, |current| {
        Ok(current
            .iter()
            .map(|entry| {
                let mut entry = entry.clone();
                if entry.id == target {
                    entry.enabled = enabled;
                }
                entry
            })
            .collect())
    })?;
    Ok(outcome.write_outcome())
}

/// spawn `$EDITOR` (or `vi` as a fallback) with
/// the current cached body as the starting content, then
/// write the result back to the cache. Returns
/// `ProfileCmdError::NotDeclared` if the profile has no
/// cached body yet (the operator must `set profile refresh`
/// first).
///
/// `apply: false` is a no-op (the dry-run path); the editor
/// is never spawned and the cache is never touched.
pub fn edit_profile(
    paths: &AppPaths,
    id: &str,
    apply: bool,
) -> Result<ProfileWriteOutcome, ProfileCmdError> {
    if !is_path_safe_component(id) {
        return Err(ProfileCmdError::InvalidId(id.to_owned()));
    }
    let (config, store) = load_declared_profiles(paths)?;
    if find_declared(&config, id).is_none() {
        return Err(ProfileCmdError::NotDeclared(id.to_owned()));
    }
    if !apply {
        return Ok(ProfileWriteOutcome::DryRun);
    }
    let body = store.read(id)?.ok_or_else(|| {
        ProfileCmdError::Store(ProfileStoreError::Io(std::io::Error::new(
            std::io::ErrorKind::NotFound,
            format!("profile `{id}` has no cached body; run `set profile refresh` first"),
        )))
    })?;
    let editor = std::env::var("EDITOR").unwrap_or_else(|_| "vi".to_owned());
    let tmp = std::env::temp_dir().join(format!("caly-profile-{id}-{}.yaml", std::process::id()));
    std::fs::write(&tmp, &body).map_err(|e| ProfileCmdError::Store(ProfileStoreError::Io(e)))?;
    let status = std::process::Command::new(&editor)
        .arg(&tmp)
        .status()
        .map_err(|error| {
            ProfileCmdError::Store(ProfileStoreError::Io(std::io::Error::other(format!(
                "cannot spawn editor `{editor}`: {error}"
            ))))
        })?;
    if !status.success() {
        let _ = std::fs::remove_file(&tmp);
        return Err(ProfileCmdError::Store(ProfileStoreError::Io(
            std::io::Error::other(format!("editor `{editor}` exited with {status}")),
        )));
    }
    let new_body =
        std::fs::read(&tmp).map_err(|e| ProfileCmdError::Store(ProfileStoreError::Io(e)))?;
    let _ = std::fs::remove_file(&tmp);
    let url = store.read_metadata(id)?.map(|m| m.url).unwrap_or_default();
    let now_ms = current_unix_ms();
    store.write(id, &new_body, &url, now_ms)?;
    Ok(ProfileWriteOutcome::Applied)
}

/// write the current cached body to `<out>`.
/// Returns `ProfileCmdError::NotDeclared` if the profile
/// has no cached body yet.
///
/// returns [`ProfileWriteOutcome`] so the
/// dispatch can route `export` through the same
/// `run_writer` envelope as the other verbs. `export`
/// has no dry-run path (the operation is either the
/// write or an error), so the writer always returns
/// `Applied` on success.
pub fn export_profile(
    paths: &AppPaths,
    id: &str,
    out: &Path,
) -> Result<ProfileWriteOutcome, ProfileCmdError> {
    if !is_path_safe_component(id) {
        return Err(ProfileCmdError::InvalidId(id.to_owned()));
    }
    let (_config, store) = load_declared_profiles(paths)?;
    let body = store.read(id)?.ok_or_else(|| {
        ProfileCmdError::Store(ProfileStoreError::Io(std::io::Error::new(
            std::io::ErrorKind::NotFound,
            format!("profile `{id}` has no cached body; run `set profile refresh` first"),
        )))
    })?;
    if let Some(parent) = out.parent() {
        std::fs::create_dir_all(parent)
            .map_err(|e| ProfileCmdError::Store(ProfileStoreError::Io(e)))?;
    }
    std::fs::write(out, &body).map_err(|e| ProfileCmdError::Store(ProfileStoreError::Io(e)))?;
    Ok(ProfileWriteOutcome::Applied)
}

fn build_profile_config(id: &str, source: ProfileSourceKind) -> ProfileConfig {
    let source_config = match source {
        ProfileSourceKind::Local { path } => ProfileSourceConfig::Local { path },
        ProfileSourceKind::Remote {
            url,
            interval_minutes,
        } => ProfileSourceConfig::Remote {
            url,
            interval_minutes,
        },
        ProfileSourceKind::Merge { parts } => ProfileSourceConfig::Merge { parts },
    };
    ProfileConfig {
        id: id.to_owned(),
        name: None,
        description: None,
        source: source_config,
        enabled: true,
    }
}

/// Mutates the `profiles:` list through the shared config-store
/// primitive — thin-client delegation, not a bespoke pipeline.
///
/// `mutator` is called with the current `Vec<ProfileConfig>` and returns
/// the desired next list. The shared primitive resolves the write target
/// (the `config.d/` fragment declaring `profiles:` when one exists, else
/// the base file), performs the comment-preserving line edit, validates,
/// backs up once, and atomically rewrites; an idempotent mutation
/// returns `NoChange` with no backup / write at all.
///
/// This replaces the bespoke `mutate_profiles_in_config` + `backup_config`
/// pair (Round 21): the bespoke writer hardcoded the base file, so its
/// writes were silently shadowed by the generated `98-profiles.yaml`
/// (`profiles: []` replaces the base key on layered merge) — `profile
/// add` reported success while `profile list` stayed empty.
fn mutate_profiles_in_config<F>(
    paths: &AppPaths,
    mutator: F,
) -> Result<caly_profile::store::resource_writer::ListEditOutcome, ProfileCmdError>
where
    F: FnOnce(&[ProfileConfig]) -> Result<Vec<ProfileConfig>, ProfileCmdError>,
{
    caly_profile::store::resource_writer::mutate_list_at::<ProfileConfig, ProfileCmdError, F>(
        paths,
        &["profiles"],
        mutator,
    )
}

impl From<caly_profile::store::yaml_surgery::SurgeryError> for ProfileCmdError {
    fn from(value: caly_profile::store::yaml_surgery::SurgeryError) -> Self {
        match value {
            caly_profile::store::yaml_surgery::SurgeryError::KeyNotFound(reason)
            | caly_profile::store::yaml_surgery::SurgeryError::TypeMismatch(reason)
            | caly_profile::store::yaml_surgery::SurgeryError::Parse(reason)
            | caly_profile::store::yaml_surgery::SurgeryError::Value(reason) => {
                Self::ParseConfig(reason)
            }
        }
    }
}
