//! Human and JSON rendering for the entry tree (split from
//! `entry_tree.rs` to keep the model and renderer within budget).

use super::{EntryTree, HashSet, TreeGroup, TreeMember, member_cycles};
use serde_json::json;

/// Badge lane + display sanitizer, owned by the layout suite and
/// re-exported here so tree/picker call sites keep one import root.
pub use crate::layout::{badge_lane, strip_controls};

// ── human rendering ─────────────────────────────────────────────

/// Renders the human tree. Layout: group zone (one block per group,
/// members indented with `├─`/`└─`), then 未入组节点 zone, then 规则区
/// (offline faces only). A document without groups degenerates to a
/// protocol-only listing.
pub fn render_human(tree: &EntryTree) -> String {
    let mut out = String::new();
    let cycles = member_cycles(&tree.groups);
    if tree.has_groups() {
        for (index, group) in tree.groups.iter().enumerate() {
            render_group_header(&mut out, group);
            render_members(&mut out, group, &cycles[index]);
        }
        out.push('\n');
    }
    if !tree.ungrouped.is_empty() {
        if tree.has_groups() {
            // Document with groups: the 未入组节点 zone (G-§3.2).
            out.push_str("ungrouped nodes\n");
            for (index, node) in tree.ungrouped.iter().enumerate() {
                let branch = if index + 1 == tree.ungrouped.len() {
                    "└─"
                } else {
                    "├─"
                };
                let _ = std::fmt::Write::write_fmt(
                    &mut out,
                    format_args!(
                        "  {branch} {}{}\n",
                        badge_lane(&node.kind),
                        strip_controls(&node.name)
                    ),
                );
            }
            out.push('\n');
        } else {
            // Group-less document (URI lines / base64): the degenerate
            // protocol-only listing (G-§3.2) — no zone title, no tree
            // glyphs.
            for node in &tree.ungrouped {
                let _ = std::fmt::Write::write_fmt(
                    &mut out,
                    format_args!("{}{}\n", badge_lane(&node.kind), strip_controls(&node.name)),
                );
            }
            out.push('\n');
        }
    }
    if !tree.rules.is_empty() {
        out.push_str("rules zone\n");
        for rule in &tree.rules {
            let kind = rule.target_kind.as_deref().unwrap_or("unknown");
            // The target column shares the 10-column badge lane with the
            // group/member zones, so rule targets align across badge
            // widths (`→ [direct]  DIRECT` / `→ [selector] Telegram`).
            let _ = std::fmt::Write::write_fmt(
                &mut out,
                format_args!(
                    "  {} → {}{}\n",
                    strip_controls(&rule.text),
                    badge_lane(kind),
                    strip_controls(&rule.target)
                ),
            );
        }
    }
    if out.is_empty() {
        out.push_str("(no entries)\n");
    }
    out
}

/// Renders one group's header line: `[badge] name` with the probe
/// annotation when the group probes (`url=… · interval=…s · tolerance=…ms`).
fn render_group_header(out: &mut String, group: &TreeGroup) {
    let _ = std::fmt::Write::write_fmt(
        out,
        format_args!(
            "{}{}{}\n",
            badge_lane(&group.kind),
            strip_controls(&group.name),
            probe_note(group)
        ),
    );
}

fn probe_note(group: &TreeGroup) -> String {
    let Some(url) = &group.url else {
        return String::new();
    };
    let mut note = format!("  url={}", strip_controls(url));
    if let Some(interval) = group.interval_seconds {
        let _ = std::fmt::Write::write_fmt(&mut note, format_args!(" · interval={interval}s"));
    }
    if let Some(tolerance) = group.tolerance_ms {
        let _ = std::fmt::Write::write_fmt(&mut note, format_args!(" · tolerance={tolerance}ms"));
    }
    note
}

fn render_members(out: &mut String, group: &TreeGroup, cycle_flags: &[bool]) {
    for (index, member) in group.members.iter().enumerate() {
        let branch = if index + 1 == group.members.len() {
            "└─"
        } else {
            "├─"
        };
        match member {
            TreeMember::Node { name, kind } | TreeMember::Builtin { name, kind } => {
                let _ = std::fmt::Write::write_fmt(
                    out,
                    format_args!("  {branch} {}{}\n", badge_lane(kind), strip_controls(name)),
                );
            }
            TreeMember::Group { name, kind } => {
                if cycle_flags.get(index).copied().unwrap_or(false) {
                    let _ = std::fmt::Write::write_fmt(
                        out,
                        format_args!(
                            "  {branch} {}{} → ⟲ cycle\n",
                            badge_lane(kind),
                            strip_controls(name)
                        ),
                    );
                } else {
                    let display = strip_controls(name);
                    let _ = std::fmt::Write::write_fmt(
                        out,
                        format_args!(
                            "  {branch} {}{} → 嵌套组(见 {display})\n",
                            badge_lane(kind),
                            display
                        ),
                    );
                }
            }
            TreeMember::Unknown { name } => {
                let _ = std::fmt::Write::write_fmt(
                    out,
                    format_args!(
                        "  {branch} {}{}\n",
                        badge_lane("unknown"),
                        strip_controls(name)
                    ),
                );
            }
        }
    }
}

// ── JSON rendering (§6.1 contract, frozen from the W3a exit) ────

/// Renders the §6.1 C-C JSON contract: flat `entries[]` + `members[]`
/// two-level shape. `entries[]` order: groups (declaration order), then
/// protocols (ungrouped first, then grouped, both in declaration order),
/// then the distinct builtins. Optional fields (`delay_ms`, `selected`,
/// `groups_in`) are omitted when absent (serde skip_none semantics);
/// W3b's online enrichment adds them without renaming or removing.
pub fn render_json(tree: &EntryTree) -> serde_json::Value {
    let mut entries: Vec<serde_json::Value> = Vec::new();

    for group in &tree.groups {
        let mut object = json!({
            "name": group.name,
            "kind": group.kind,
            "type": "group",
        });
        if let Some(url) = &group.url {
            object["url"] = json!(url);
        }
        if let Some(interval) = group.interval_seconds {
            object["interval_seconds"] = json!(interval);
        }
        if let Some(tolerance) = group.tolerance_ms {
            object["tolerance_ms"] = json!(tolerance);
        }
        let members: Vec<serde_json::Value> = group
            .members
            .iter()
            .map(|member| match member {
                TreeMember::Node { name, kind } | TreeMember::Builtin { name, kind } => {
                    json!({ "name": name, "kind": kind })
                }
                TreeMember::Group { name, kind } => {
                    json!({ "name": name, "kind": kind, "ref": true })
                }
                TreeMember::Unknown { name } => json!({ "name": name, "kind": "unknown" }),
            })
            .collect();
        object["members"] = serde_json::Value::Array(members);
        entries.push(object);
    }

    for node in &tree.ungrouped {
        entries.push(json!({
            "name": node.name,
            "kind": node.kind,
            "type": "protocol",
        }));
    }
    let mut seen: HashSet<&str> = tree.ungrouped.iter().map(|n| n.name.as_str()).collect();
    for group in &tree.groups {
        for member in &group.members {
            if let TreeMember::Node { name, kind } = member
                && seen.insert(name.as_str())
            {
                entries.push(json!({
                    "name": name,
                    "kind": kind,
                    "type": "protocol",
                    "groups_in": groups_in_for(name, &tree.groups),
                }));
            }
        }
    }

    for builtin in &tree.builtins {
        entries.push(json!({
            "name": builtin.name,
            "kind": builtin.kind,
            "type": "builtin",
        }));
    }

    let rules: Vec<serde_json::Value> = tree
        .rules
        .iter()
        .map(|rule| {
            let mut object = json!({ "text": rule.text, "target": rule.target });
            if let Some(kind) = &rule.target_kind {
                object["target_kind"] = json!(kind);
            }
            object
        })
        .collect();

    json!({
        "format": tree.format,
        "ok": true,
        "version": crate::layout::JSON_CONTRACT_VERSION,
        "counts": {
            "entries": tree.entry_count(),
            "protocols": tree.protocol_count(),
            "groups": tree.groups.len(),
            "builtins": tree.builtins.len(),
            "rules": tree.rules.len(),
        },
        "entries": entries,
        "rules": rules,
    })
}

/// Member groups of one protocol tag, in group declaration order.
fn groups_in_for(name: &str, groups: &[TreeGroup]) -> Vec<String> {
    let mut names = Vec::new();
    for group in groups {
        for member in &group.members {
            if let TreeMember::Node { name: tag, .. } = member
                && tag == name
            {
                names.push(group.name.clone());
                break;
            }
        }
    }
    names
}
