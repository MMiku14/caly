//! Catalog of stable error codes used across the CLI.
//!
//! Every error returned by caly's CLI surface has a
//! `code: &'static str` drawn from this module. Scripts can
//!
//! branch on the code (e.g. `case "$code" in
//! profile.not_declared) ... esac`) without parsing the
//! human message.
//!
//! # Code naming convention
//!
//! `<family>.<subkind>` — the family is the top-level command
//! (`profile`, `sub`, `core`, …) and the subkind describes the
//! failure mode. `usage.*` codes always exit 2; everything
//! else exits 1.
//!
//!
//! # Module layout 
//! Each shared family lives in its own sub-module; callers use
//! `crate::error::core::invalid_target(...)` and friends. Families
//! mapped per-leaf (`profile`, `sub`, `daemon`) keep their codes
//! next to the dispatching command.

pub use crate::layout::CliError;

pub mod config;
pub mod core;
pub mod usage;

// re-export the top-level usage functions so the
// Round 10/11/12 public API (`crate::error::json_not_valid(...)`)
// keeps working unchanged. The implementations live in
// `usage::*` now; the re-exports make the path stable.
pub use usage::{binary_override_outside_daemon, json_not_valid, json_with_completion};

/// The daemon could not be reached (not running, socket missing, …).
pub const DAEMON_UNREACHABLE: &str = "daemon.unreachable";

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn error_mod_exports_all_codes() {
        // Locks the public API: every family has at least one
        // `pub const` and at least one `pub fn` so the
        // `commands::*` call sites compile unchanged.
        let _ = core::INVALID_TARGET;
        let _: for<'a> fn(&'a str, &'a str) -> crate::layout::CliError = core::invalid_target;
        let _ = config::CHECK_FAILED;
        let _: for<'a> fn(&'a str, &'a str) -> crate::layout::CliError = config::check_failed;
        let _ = DAEMON_UNREACHABLE;
        let _ = usage::json_not_valid;
    }
}
