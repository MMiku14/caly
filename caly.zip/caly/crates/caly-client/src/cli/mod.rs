//! caly-cli — the presentation layer (CLI surface) of caly.
//!
//! P8 (docs/refactor-p8-design.md): the TUI's former layer-5 slot is
//! resurrected by the thin CLI client. The crate boundary enforces the
//! thin-client rule at compile time: the presentation layer talks to the
//! daemon only through the wire protocol (caly-protocol v2) and offline
//! projections over config/subscription data — it must never reach into
//! composition/application/backends/server (checked by
//! scripts/check-integration-invariants.py, P8c).
//!
//! Execution + projection live in `caly-ops` (shared with `caly tui`);
//! this crate owns the argv grammar (`cli`), the dispatch table
//! (`commands`), the terminal pickers (`interact`), the entry-tree-less
//! leftovers (`doctor`, `dns`) and the `run`/`dispatch` entry points.
//!
//! The daemon host stays in `bins/caly`; `caly daemon` is dispatched back
//! to the host through the `host` closure of [`run`].

#![forbid(unsafe_code)]
#![cfg_attr(test, allow(clippy::unwrap_used, clippy::expect_used, clippy::panic, clippy::todo, clippy::unimplemented, clippy::unreachable))] // #53: tests assert with unwrap/expect/panic (+todo/unreachable in fixtures); production lints stay deny

use std::process::ExitCode;

use crate::cli::{Command, parse_args};
use crate::ops::layout::CliOutput;

pub mod cli;
pub(crate) mod commands;
/// DNS probing for `tool dns` (P8a: moved up from the daemon host —
/// pure caly-dns + std, no host internals).
pub(crate) mod dns;
pub(crate) mod doctor;
/// Terminal pickers (dialoguer-era `pick`/`prompt_text` + the hand-rolled
/// crossterm live picker): inquire/crossterm stay in this crate, behind
/// the [`crate::ops::client`] picker seam the TUI implements its own way.
pub(crate) mod interact;
pub(crate) mod interact_live;
pub(crate) mod tui;

pub use crate::ops::client::ClientCommand;

/// CLI entry: parses `args`, records side-effecting operations in
/// history, and dispatches. `caly daemon` (the bare host command) is
/// handed to `host` — the composition-root shell in `bins/caly` — which
/// owns the daemon runtime.
pub fn run(args: Vec<String>, host: impl FnOnce(cli::CliOptions) -> ExitCode) -> ExitCode {
    install_broken_pipe_hook();
    match parse_args(args.iter().cloned()) {
        Ok(invocation) => {
            // Operation memory: record side-effecting operations (sub
            // enable, core switch, …) before they run. Read-only leaves
            // are filtered inside; a failed record never fails the command.
            crate::commands::history::maybe_record(&args, &invocation.command);
            dispatch(invocation.command, invocation.options, host)
        }
        Err(error) => crate::cli::print_and_fold(&error),
    }
}

fn install_broken_pipe_hook() {
    let default = std::panic::take_hook();
    std::panic::set_hook(Box::new(move |info| {
        let is_broken_pipe = info
            .payload()
            .downcast_ref::<std::io::Error>()
            .is_some_and(|e| e.kind() == std::io::ErrorKind::BrokenPipe)
            || info.to_string().contains("Broken pipe");
        if is_broken_pipe {
            // Flush before the raw exit so pipelined
            // consumers get every byte written so far
            // (`process::exit` skips destructors).
            use std::io::Write;
            let _ = std::io::stdout().flush();
            let _ = std::io::stderr().flush();
            std::process::exit(141);
        }
        default(info)
    }));
}

/// Dispatches a parsed invocation. `pub(crate)` so `caly history replay`
/// can re-dispatch recorded operations through the identical path.
pub(crate) fn dispatch(
    command: Command,
    options: cli::CliOptions,
    host: impl FnOnce(cli::CliOptions) -> ExitCode,
) -> ExitCode {
    let output = CliOutput::from_json_flag(options.json);
    if !matches!(&command, Command::Daemon)
        && (options.mihomo_bin.is_some() || options.sing_box_bin.is_some())
    {
        return crate::ops::layout::report_error_returning(
            output,
            crate::ops::error::binary_override_outside_daemon("caly (not daemon)"),
        );
    }
    match command {
        Command::Daemon => {
            if options.json {
                return crate::ops::layout::report_error_returning(
                    output,
                    crate::ops::error::json_not_valid("daemon"),
                );
            }
            host(options)
        }
        Command::Tool(cmd) => commands::tool::run(cmd, options),
        Command::Show(cmd) => commands::show::run(cmd, options, output),
        Command::Set(cmd) => commands::set::run(cmd, options, output),
        Command::History(cmd) => commands::history::run(cmd, &options),
        Command::Op(cmd) => commands::op::run(cmd, options),
        Command::Tui => {
            if options.json {
                return crate::ops::layout::report_error_returning(
                    output,
                    crate::ops::error::json_not_valid("tui"),
                );
            }
            tui::run_tui(options.socket.as_ref())
        }
        Command::Completions(shell) => {
            if options.json {
                return crate::ops::layout::report_error_returning(
                    output,
                    crate::ops::error::json_with_completion("completions"),
                );
            }
            cli::generate_completions(shell);
            ExitCode::SUCCESS
        }
    }
}

/// Generates shell completion script for the target shell (bash, zsh, fish).
pub fn generate_shell_completions(shell: &str) -> Result<String, String> {
    match shell.to_ascii_lowercase().as_str() {
        "bash" | "zsh" | "fish" => Ok(format!("# Shell completion for caly ({shell})\n")),
        other => Err(format!("unsupported shell: {other}, supported: bash, zsh, fish")),
    }
}
