//! Daemon action wrappers: receipts in, screen flashes out.
//!
//! Thin `impl Tui` layer over [`actions`](crate::ops::client::actions):
//! every wrapper flashes the receipt (or the failure sentence) and
//! re-snapshots on success so the frame shows the new state without
//! waiting for the next tick. Async submissions (refreshes) skip the
//! re-snapshot — the tick picks the fresh data up on its own.

use super::app::Tui;
use super::popup::{Popup, SettingsRow};

impl Tui {
    /// Flashes an action result and re-snapshots on success.
    fn finish_action(&mut self, result: Result<String, String>) {
        match result {
            Ok(receipt) => {
                self.flash(&receipt);
                self.refresh();
            }
            Err(reason) => self.flash(&reason),
        }
    }

    pub(super) fn action_select(&mut self, node_id: [u8; 16], label: &str) {
        let result = crate::ops::client::actions::select_node(self.socket.as_ref(), node_id, label);
        self.finish_action(result);
    }

    pub(super) fn action_pick(&mut self, group: &str, member: &str) {
        let result =
            crate::ops::client::actions::pick_group_member(self.socket.as_ref(), group, member);
        self.finish_action(result);
    }

    pub(super) fn action_set_mode(&mut self, label: &str) {
        let result = crate::ops::client::actions::set_mode(self.socket.as_ref(), label);
        self.finish_action(result);
    }

    /// Switches the running core, closing the popup on success (the
    /// radio would lie about the current core otherwise). Failures keep
    /// the popup open for a retry.
    pub(super) fn action_switch_core(&mut self, target: &str) {
        match crate::ops::client::actions::switch_core(self.socket.as_ref(), target) {
            Ok(receipt) => {
                self.popup = None;
                self.flash(&receipt);
                self.refresh();
            }
            Err(reason) => self.flash(&reason),
        }
    }

    /// Submits a one-source refresh; the popup stays open (the details
    /// are still valid — the tick delivers the fresh data).
    pub(super) fn action_refresh_source(&mut self, name: &str, url: &str) {
        match crate::ops::client::actions::refresh_source(self.socket.as_ref(), name, url) {
            Ok(receipt) => self.flash(&receipt),
            Err(reason) => self.flash(&reason),
        }
    }

    pub(super) fn action_set_tun(&mut self, on: bool) {
        let result = crate::ops::client::actions::set_tun(self.socket.as_ref(), on);
        self.finish_action(result);
    }

    pub(super) fn action_set_system_proxy(&mut self, on: bool) {
        let result = crate::ops::client::actions::set_system_proxy(self.socket.as_ref(), on);
        self.finish_action(result);
    }

    /// `Enter`/`Space` inside the settings window: toggles and the
    /// mode cycle apply in place (the window stays open so several
    /// settings change in one visit); the core row swaps in the core
    /// switcher instead.
    pub(super) fn activate_settings_row(&mut self) {
        let selected = match self.popup {
            Some(Popup::Settings { selected }) => selected,
            _ => return,
        };
        match SettingsRow::from_index(selected) {
            SettingsRow::Mode => self.cycle_mode(),
            SettingsRow::Tun => {
                let on = self.snapshot.as_ref().is_some_and(|snapshot| {
                    !snapshot.desired.tun_requested
                });
                self.action_set_tun(on);
            }
            SettingsRow::SysProxy => {
                let on = self.snapshot.as_ref().is_some_and(|snapshot| {
                    !snapshot.desired.system_proxy_requested
                });
                self.action_set_system_proxy(on);
            }
            SettingsRow::Core => self.open_cores_popup(),
            SettingsRow::RefreshAll => self.action_refresh_all(),
        }
    }

    pub(super) fn action_refresh_all(&mut self) {
        let result = crate::ops::client::actions::refresh_all(self.socket.as_ref(), false);
        // No re-snapshot: refresh is async server-side, the tick picks
        // up the fresh data on its own.
        match result {
            Ok(receipt) => self.flash(&receipt),
            Err(reason) => self.flash(&reason),
        }
    }
}
