//! TUI state, screen loop, and daemon actions.
//!
//! Key dispatch lives in [`super::keys`], frame assembly in
//! [`super::frame`]; this file owns the [`Tui`] struct, the raw-mode /
//! alternate-screen lifecycle, the 2 s re-snapshot tick, and the thin
//! wrappers that turn [`actions`](crate::ops::client::actions) results
//! into screen flashes. Every wrapper re-snapshots on success so the
//! frame shows the new state without waiting for the next tick.
//!
//! Connection discipline: one held [`UdsClient`] serves every tick and
//! every action-triggered refresh — connect + handshake happen once,
//! not per refresh. A failed snapshot drops the client and retries
//! once on a fresh connection (a daemon restart mid-session reads as
//! one quiet reconnect, not an error flash); only a second failure
//! surfaces, as the offline frame.

use std::cell::RefCell;
use std::collections::HashMap;
use std::io::Write as _;
use std::path::PathBuf;
use std::sync::mpsc;
use std::time::{Duration, Instant};

use caly_ipc::protocol::client::{ClientContract, UdsClient};
use crossterm::event::Event;

use super::{Snapshot, Tab};

/// Snapshot refresh cadence. Ticks reuse the held connection (one cheap
/// RPC), so only a dead daemon costs time — one connect-retry window
/// (~1s) before the offline frame appears.
const TICK: Duration = Duration::from_secs(2);

/// How long a receipt/error flash owns the footer.
const NOTICE_TTL: Duration = Duration::from_secs(4);

pub(super) struct Tui {
    pub(super) socket: Option<PathBuf>,
    /// Held daemon connection (see the module docs). `None` only before
    /// the first refresh or after a failure, both of which reconnect.
    client: Option<UdsClient>,
    pub(super) snapshot: Option<Snapshot>,
    pub(super) fetch_error: Option<String>,
    pub(super) tab: Tab,
    /// Cursor position per tab (Nodes: filtered position; Groups:
    /// flattened row; Status/Subs: unused, they scroll).
    pub(super) cursor: [usize; 6],
    /// First visible body line per tab.
    pub(super) scroll: [usize; 6],
    /// Node-name substring filter (Nodes tab only).
    pub(super) filter: String,
    /// Whether keystrokes are editing the filter.
    pub(super) filtering: bool,
    /// Open secondary window, if any (modal: keys route to it).
    pub(super) popup: Option<super::popup::Popup>,
    pub(super) notice: Option<(String, Instant)>,
    /// In-flight ping-all sweep: polled (never blocking) on every loop
    /// pass so the UI stays live while probes run.
    pub(super) sweep_rx: Option<mpsc::Receiver<super::sweep::SweepMsg>>,
    /// Latest sweep progress (done, total, dead) for the footer.
    pub(super) sweep_progress: Option<(usize, usize, usize)>,
    /// Fresh sweep medians by lowercase hex node id; wins over snapshot
    /// latencies until the next sweep replaces them.
    pub(super) sweep_overlay: HashMap<String, Option<u32>>,
    /// Bumped on every sweep fold; part of the body-cache key so fresh
    /// medians invalidate the memoized node list.
    pub(super) overlay_gen: u64,
    /// Memoized body render (see [`super::frame`]).
    pub(super) body_cache: RefCell<Option<super::body::BodyCache>>,
}

impl Tui {
    pub(super) fn new(socket: Option<PathBuf>) -> Self {
        Self {
            socket,
            client: None,
            snapshot: None,
            fetch_error: None,
            tab: Tab::Nodes,
            cursor: [0; 6],
            scroll: [0; 6],
            filter: String::new(),
            filtering: false,
            popup: None,
            notice: None,
            sweep_rx: None,
            sweep_progress: None,
            sweep_overlay: HashMap::new(),
            overlay_gen: 0,
            body_cache: RefCell::new(None),
        }
    }

    pub(super) fn run(&mut self) -> Result<(), String> {
        crossterm::terminal::enable_raw_mode().map_err(|error| format!("raw mode: {error}"))?;
        let mut out = std::io::stdout();
        let entered = crossterm::execute!(
            out,
            crossterm::terminal::EnterAlternateScreen,
            crossterm::cursor::Hide,
            crossterm::event::EnableMouseCapture
        );
        let outcome = entered
            .map_err(|error| format!("alternate screen: {error}"))
            .and_then(|()| self.event_loop(&mut out));
        let _ = crossterm::execute!(
            out,
            crossterm::event::DisableMouseCapture,
            crossterm::cursor::Show,
            crossterm::terminal::LeaveAlternateScreen
        );
        let _ = crossterm::terminal::disable_raw_mode();
        outcome
    }

    fn event_loop(&mut self, out: &mut std::io::Stdout) -> Result<(), String> {
        self.refresh();
        let mut last_tick = Instant::now();
        loop {
            self.render(out)?;
            if crossterm::event::poll(TICK).map_err(|error| format!("event poll: {error}"))? {
                match crossterm::event::read().map_err(|error| format!("event read: {error}"))? {
                    Event::Key(key) => {
                        if self.handle_key(key.code, key.modifiers) {
                            return Ok(());
                        }
                        self.poll_sweep();
                    }
                    Event::Mouse(mouse) => {
                        use crossterm::event::{MouseEventKind, MouseButton};
                        match mouse.kind {
                            MouseEventKind::ScrollDown => {
                                self.move_down();
                            }
                            MouseEventKind::Drag(_) => {}
                            MouseEventKind::ScrollUp => {
                                self.move_up();
                            }
                            MouseEventKind::Down(MouseButton::Left) => {
                                if mouse.row == 1 {
                                    let col = mouse.column as usize;
                                    if col < 12 {
                                        self.tab = Tab::Nodes;
                                    } else if col < 24 {
                                        self.tab = Tab::Groups;
                                    } else if col < 36 {
                                        self.tab = Tab::Status;
                                    } else {
                                        self.tab = Tab::Subs;
                                    }
                                } else if mouse.row >= 3 {
                                    let target_line = (mouse.row as usize).saturating_sub(3);
                                    let current_tab = self.tab.index();
                                    let target_cursor = self.scroll[current_tab].saturating_add(target_line);
                                    if self.cursor[current_tab] == target_cursor {
                                        self.activate();
                                    } else {
                                        self.cursor[current_tab] = target_cursor;
                                    }
                                }
                            }
                            _ => {}
                        }
                    }
                    Event::Resize(_, _) => {}
                    _ => {}
                }
                continue;
            }
            if last_tick.elapsed() >= TICK {
                last_tick = Instant::now();
                self.refresh();
                self.poll_sweep();
            }
        }
    }

    fn render(&mut self, out: &mut std::io::Stdout) -> Result<(), String> {
        // A zero dimension (pty default, broken terminfo) carries no layout
        // information — fall back to 80x24 rather than a one-line frame.
        let (width, height) = match crossterm::terminal::size() {
            Ok((width, height)) if width > 0 && height > 0 => (width as usize, height as usize),
            _ => (80, 24),
        };
        crossterm::execute!(
            out,
            crossterm::cursor::MoveTo(0, 0),
            crossterm::terminal::Clear(crossterm::terminal::ClearType::All)
        )
        .map_err(|error| format!("clear: {error}"))?;
        for line in super::frame::frame(self, width, height) {
            writeln!(out, "{line}\r").map_err(|error| format!("draw: {error}"))?;
        }
        out.flush().map_err(|error| format!("flush: {error}"))?;
        Ok(())
    }

    /// Re-snapshots over the held connection and clamps every cursor to
    /// the fresh data (a refresh can shrink any list out from under the
    /// cursor).
    pub(super) fn refresh(&mut self) {
        match self.snapshot_via_client() {
            Ok(snapshot) => {
                self.fetch_error = None;
                self.snapshot = Some(snapshot);
                self.clamp_cursors();
                self.validate_popup();
            }
            Err(reason) => {
                self.snapshot = None;
                self.fetch_error = Some(reason);
            }
        }
    }

    /// One snapshot RPC over the held client, connecting on demand and
    /// retrying once on a fresh connection when the held one fails. Any
    /// `Err` leaves `client` as `None` so the next refresh reconnects.
    fn snapshot_via_client(&mut self) -> Result<Snapshot, String> {
        if self.client.is_none() {
            self.client = Some(crate::ops::client::actions::connect(self.socket.as_ref())?);
        }
        if let Some(client) = self.client.as_mut() {
            match client.snapshot() {
                Ok(snapshot) => return Ok(snapshot),
                Err(_) => self.client = None,
            }
        }
        let mut client = crate::ops::client::actions::connect(self.socket.as_ref())?;
        match client.snapshot() {
            Ok(snapshot) => {
                self.client = Some(client);
                Ok(snapshot)
            }
            Err(error) => Err(crate::ops::client::actions::describe_error(&error)),
        }
    }

    fn clamp_cursors(&mut self) {
        let Some(snapshot) = self.snapshot.as_ref() else {
            return;
        };
        let nodes = super::nodes::filtered_indices(snapshot, &self.filter).len();
        self.cursor[Tab::Nodes.index()] =
            self.cursor[Tab::Nodes.index()].min(nodes.saturating_sub(1));
        self.cursor[Tab::Subs.index()] =
            self.cursor[Tab::Subs.index()].min(snapshot.sources.len().saturating_sub(1));
        let groups = super::groups::flatten(snapshot);
        let flat = self.cursor[Tab::Groups.index()].min(groups.len().saturating_sub(1));
        // A refresh can land the cursor on a header: snap to a member.
        self.cursor[Tab::Groups.index()] = super::groups::next_member(&groups, flat)
            .or_else(|| super::groups::prev_member(&groups, flat))
            .unwrap_or(0);
    }

    /// Closes a detail popup whose target left the snapshot (a
    /// refresh can drop nodes/sources out from under an open window).
    fn validate_popup(&mut self) {
        let stale = match (self.popup.as_ref(), self.snapshot.as_ref()) {
            (Some(super::popup::Popup::Node { node_id, .. }), Some(snapshot)) => {
                !snapshot.nodes.iter().any(|node| node.node_id == *node_id)
            }
            (Some(super::popup::Popup::Source { index, .. }), Some(snapshot)) => {
                !snapshot.sources.iter().any(|source| source.index == *index)
            }
            _ => false,
        };
        if stale {
            self.popup = None;
        }
    }

    pub(super) fn flash(&mut self, text: &str) {
        self.notice = Some((text.to_owned(), Instant::now()));
    }

    pub(super) fn notice_text(&self) -> Option<String> {
        self.notice.as_ref().and_then(|(text, at)| {
            if at.elapsed() < NOTICE_TTL {
                Some(text.clone())
            } else {
                None
            }
        })
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn failed_refresh_reports_and_holds_no_client() {
        let mut tui = Tui::new(Some(PathBuf::from("/nonexistent-caly.sock")));
        tui.refresh();
        assert!(tui.snapshot.is_none());
        assert!(tui.client.is_none());
        let error = tui.fetch_error.expect("fetch error is recorded");
        assert!(error.contains("daemon unreachable"), "{error}");
    }
}
