//! Popup content builders: one view per secondary window.
//!
//! Pure functions of (popup, snapshot, sweep overlay): node identity,
//! source records with both time faces, the core radio with its armed
//! confirm line, and the help text. Chrome (border, scroll, overlay)
//! lives in [`super::popup`].

use std::collections::HashMap;

use super::Snapshot;
use super::popup::{CORES, PopupView, SettingsRow};

pub(super) fn node_view(
    node: &caly_ipc::protocol::protocol::v2::WireDisplayNode,
    selected: bool,
    overlay: &HashMap<String, Option<u32>>,
) -> PopupView {
    let hex = caly_domain::to_hex(node.node_id);
    let latency = match overlay.get(&hex) {
        Some(Some(median)) => format!("{median} ms (sweep)"),
        Some(None) => "down (sweep)".to_owned(),
        None => node
            .latency_ms
            .map_or_else(|| "—".to_owned(), |latency| format!("{latency} ms")),
    };
    let raw_name = crate::ops::client::output::decode_display_name(&node.name);
    let flag = crate::ops::layout::text::TuiGlyphs::country_flag(&raw_name);
    let proto_icon = crate::ops::layout::text::TuiGlyphs::protocol_glyph(&node.protocol);

    // Derive node feature badges based on protocol metadata
    let mut badges_list = vec!["TLS 1.3"];
    let proto_lower = node.protocol.to_ascii_lowercase();
    if proto_lower.contains("vless") || raw_name.to_ascii_lowercase().contains("reality") {
        badges_list.push("Reality");
        badges_list.push("Vision");
    }
    if proto_lower.contains("vmess") || proto_lower.contains("ws") {
        badges_list.push("WS");
    } else if proto_lower.contains("grpc") {
        badges_list.push("gRPC");
    } else if proto_lower.contains("hy2") || proto_lower.contains("hysteria") {
        badges_list.push("QUIC");
        badges_list.push("BBR");
    }
    badges_list.push("UDP");
    badges_list.push("Chrome");

    let pills = crate::ops::layout::tui_kit::render_node_badge_pills(&badges_list);

    let mut lines = vec![
        format!("name:     {flag} {raw_name}"),
        format!("id:       {hex}"),
        format!("protocol: {proto_icon}"),
        format!("badges:   {pills}"),
        format!("latency:  {latency} {}", crate::ops::layout::theme::BtopMeter::render_latency_meter(overlay.get(&hex).and_then(|&x| x).or(node.latency_ms))),
        format!("kernel:   {}", if node.available { "yes" } else { "no" }),
    ];
    if selected {
        lines.push("● this is the active node".to_owned());
    }
    PopupView {
        title: "node".to_owned(),
        lines,
        hint: "Enter select · Esc close".to_owned(),
    }
}

pub(super) fn source_view(source: &caly_ipc::protocol::protocol::v2::WireSourceView) -> PopupView {
    let now = crate::ops::layout::now_unix();
    let groups = source
        .groups
        .iter()
        .map(caly_domain::BoundedText::as_str)
        .collect::<Vec<_>>()
        .join(", ");
    let lines = vec![
        format!("name:    {}", source.name.as_str()),
        format!("id:      {}", source.index),
        format!("type:    {}", source.kind.as_str()),
        format!("url:     {}", source.url.as_str()),
        format!(
            "status:   {} {}",
            crate::ops::layout::source_badge(source.enabled, source.cached),
            crate::ops::layout::source_word(source.enabled, source.cached)
        ),
        format!("nodes:    {}", source.nodes),
        format!(
            "groups:   {}",
            if groups.is_empty() { "—" } else { &groups }
        ),
        format!("updated:  {}", stamp(now, source.last_refresh_unix)),
        format!("next:     {}", stamp(now, source.next_refresh_unix)),
    ];
    PopupView {
        title: "source".to_owned(),
        lines,
        hint: "R refresh this source · Esc close".to_owned(),
    }
}

/// Relative time with the raw unix stamp alongside (a detail window can
/// afford both faces).
fn stamp(now: u64, then: Option<u64>) -> String {
    match then {
        Some(ts) => format!("{} ({ts})", crate::ops::layout::relative_time(now, Some(ts))),
        None => "—".to_owned(),
    }
}

pub(super) fn cores_view(snapshot: &Snapshot, selected: usize, armed: bool) -> PopupView {
    let current = snapshot
        .applied
        .core_kind
        .and_then(caly_ipc::protocol::protocol::v2::WireCoreKind::from_wire)
        .map(caly_ipc::protocol::protocol::v2::WireCoreKind::label);
    let mut lines: Vec<String> = CORES
        .iter()
        .enumerate()
        .map(|(index, name)| {
            let cursor = if index == selected % CORES.len() {
                ">"
            } else {
                " "
            };
            let marker = if current == Some(*name) { "*" } else { " " };
            let suffix = if current == Some(*name) {
                " (current)"
            } else {
                ""
            };
            format!("{cursor} {marker} {name}{suffix}")
        })
        .collect();
    if armed {
        lines.push(String::new());
        lines.push(format!(
            "switch to `{}`? the data plane restarts —",
            CORES[selected % CORES.len()]
        ));
        lines.push("Enter again to confirm.".to_owned());
    }
    PopupView {
        title: "switch core".to_owned(),
        lines,
        hint: "↑/↓ move · Enter switch · Esc close".to_owned(),
    }
}

pub(super) fn settings_view(snapshot: &Snapshot, selected: usize) -> PopupView {
    use caly_ipc::protocol::protocol::v2::WireMode;
    let mode = WireMode::from_wire(snapshot.desired.mode)
        .map(WireMode::label)
        .unwrap_or("unknown");
    let core = snapshot
        .applied
        .core_kind
        .and_then(caly_ipc::protocol::protocol::v2::WireCoreKind::from_wire)
        .map(caly_ipc::protocol::protocol::v2::WireCoreKind::label)
        .unwrap_or("unknown");
    let rows = [
        (SettingsRow::Mode, "mode", mode.to_owned()),
        (
            SettingsRow::Tun,
            "tun",
            toggle(snapshot.desired.tun_requested, snapshot.platform.tun_engaged),
        ),
        (
            SettingsRow::SysProxy,
            "system proxy",
            toggle(
                snapshot.desired.system_proxy_requested,
                snapshot.platform.proxy_engaged,
            ),
        ),
        (SettingsRow::Core, "core", format!("{core}  →")),
        (SettingsRow::RefreshAll, "refresh all", String::new()),
    ];
    let lines = rows
        .iter()
        .enumerate()
        .map(|(index, (_, label, value))| {
            let cursor = if index == selected % SettingsRow::COUNT {
                ">"
            } else {
                " "
            };
            format!("{cursor} {label:<12} {value}").trim_end().to_owned()
        })
        .collect();
    PopupView {
        title: "settings".to_owned(),
        lines,
        hint: "↑/↓ move · Enter/Space change · Esc close".to_owned(),
    }
}

/// Desired-vs-live toggle face: `on`/`off` plus a pending marker while
/// the daemon catches up with the last change.
fn toggle(want: bool, live: bool) -> String {
    let state = if want { "on" } else { "off" };
    if want == live {
        state.to_owned()
    } else {
        format!("{state} (pending)")
    }
}

pub(super) const HELP_LINES: [&str; 22] = [
    "caly tui — keys",
    "",
    "  Tab / Shift-Tab   switch tabs (or 1-4)",
    "  ↑/↓, j/k          move cursor / scroll",
    "  Home/End, g/G     first / last row",
    "  Enter             Nodes: select · Groups: pick · Subs: details",
    "  v                 node details (Nodes tab)",
    "  /                 filter the node list (Nodes tab)",
    "  t                 ping every node (background sweep)",
    "  R                 refresh all (this source in its details)",
    "  m                 cycle mode rule → global → direct",
    "  C                 switch core (with confirm)",
    "  S                 settings (mode, tun, proxy, core)",
    "  r                 refresh now (auto-refresh ticks anyway)",
    "  ?                 toggle this help",
    "  q / Esc           quit (Esc first closes windows, then the filter)",
    "",
    "The sweep overlays fresh medians on the node list; unreachable",
    "nodes read `down`. Flashes at the bottom are daemon receipts —",
    "the same sentences the one-shot CLI prints.",
    "",
    "Nothing here deletes anything; core switches restart the data plane.",
];

#[cfg(test)]
mod tests {
    use super::super::fixtures::tests::fixture_snapshot;
    use super::*;

    fn snapshot() -> Snapshot {
        fixture_snapshot(2)
    }

    #[test]
    fn settings_view_marks_the_cursor_and_live_values() {
        let view = settings_view(&snapshot(), 1);
        assert_eq!(view.lines.len(), SettingsRow::COUNT);
        assert!(view.lines[0].contains("mode"), "{}", view.lines[0]);
        assert!(view.lines[0].contains("rule"), "{}", view.lines[0]);
        assert!(view.lines[1].starts_with('>'), "{}", view.lines[1]);
        assert!(view.lines[1].contains("off"), "{}", view.lines[1]);
        assert!(view.lines[3].contains("→"), "{}", view.lines[3]);
    }

    #[test]
    fn settings_view_flags_a_toggle_the_daemon_has_not_applied() {
        let mut snapshot = snapshot();
        snapshot.desired.tun_requested = true;
        let view = settings_view(&snapshot, 0);
        assert!(view.lines[1].contains("on (pending)"), "{}", view.lines[1]);
    }

    #[test]
    fn node_view_shows_identity_and_sweep_latency() {
        let snapshot = snapshot();
        let node = snapshot
            .nodes
            .iter()
            .find(|node| node.node_id == [1u8; 16])
            .expect("fixture node-1");
        let mut overlay = HashMap::new();
        overlay.insert(caly_domain::to_hex([1u8; 16]), Some(42));
        let view = node_view(node, false, &overlay);
        assert_eq!(view.title, "node");
        let text = view.lines.join("\n");
        assert!(text.contains("node-1"), "{text}");
        assert!(text.contains(&caly_domain::to_hex([1u8; 16])), "{text}");
        assert!(text.contains("42 ms (sweep)"), "{text}");
    }

    #[test]
    fn source_view_carries_badge_and_stamps() {
        let snapshot = snapshot();
        let source = snapshot
            .sources
            .iter()
            .find(|source| source.index == 1)
            .expect("fixture source");
        let view = source_view(source);
        let text = view.lines.join("\n");
        assert!(text.contains("https://example.com/sub"), "{text}");
        assert!(text.contains("●"), "{text}");
        assert!(text.contains("(1700000000)"), "{text}");
    }

    #[test]
    fn cores_view_marks_current_and_arms_explicitly() {
        let mut snapshot = snapshot();
        snapshot.applied.core_kind = Some(1);
        let text = cores_view(&snapshot, 1, false).lines.join("\n");
        assert!(text.contains("* mihomo (current)"), "{text}");
        assert!(text.contains(">   sing-box"), "{text}");
        let text = cores_view(&snapshot, 1, true).lines.join("\n");
        assert!(text.contains("switch to `sing-box`?"), "{text}");
    }
}
