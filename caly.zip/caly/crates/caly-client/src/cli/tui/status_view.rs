//! The Status tab: the `caly status` facts as scrollable screen lines.
//!
//! Built from the exact block constructors the one-shot command uses
//! ([`desired_block`](crate::ops::client::output::desired_block) et al.),
//! rendered — not printed — into owned lines. The only deliberate
//! difference: no kernel-selection race. `status` probes the live kernel
//! for its display name with a wall-clock budget; the TUI repaints on a
//! 2 s tick, where a probe per frame would cost a round-trip per repaint
//! for a line the daemon record already covers.

use super::Snapshot;

/// Every Status line: daemon identity, the four state blocks, the node
/// count, and the capability mini-table.
pub(super) fn lines(snapshot: &Snapshot, width: usize) -> Vec<String> {
    let mut out = crate::ops::layout::KvBlock::plain()
        .indent(0)
        .row("daemon", caly_domain::to_hex(snapshot.daemon_instance_id))
        .row("revision", snapshot.revision)
        .row("sequence", snapshot.cursor.sequence)
        .render();
    out.push(String::new());
    out.extend(crate::ops::layout::render_blocks(&[
        crate::ops::client::output::desired_block(snapshot),
        crate::ops::client::output::applied_block(snapshot, None),
        crate::ops::client::output::observed_block(snapshot),
        crate::ops::client::output::platform_block(snapshot),
    ]));
    out.push(String::new());
    out.push(format!("nodes: {}", snapshot.nodes.len()));
    out.extend(capability_lines(snapshot, width));
    out
}

fn capability_lines(snapshot: &Snapshot, width: usize) -> Vec<String> {
    if snapshot.capabilities.is_empty() {
        return vec!["capabilities: none".to_owned()];
    }
    let mut out = vec!["capabilities:".to_owned()];
    let rows: Vec<Vec<String>> = snapshot
        .capabilities
        .iter()
        .map(|capability| {
            vec![
                crate::ops::client::output::capability_label(capability.capability).to_owned(),
                crate::ops::client::output::configured_label(capability.configured).to_owned(),
                crate::ops::client::output::runtime_label(capability.runtime).to_owned(),
                capability.caveat.as_deref().unwrap_or("").to_owned(),
            ]
        })
        .collect();
    out.extend(crate::ops::layout::render_table(
        crate::ops::layout::TableMode::Table,
        &["CAPABILITY", "CONFIGURED", "RUNTIME", "CAVEAT"],
        &rows,
        Some(width),
    ));
    out
}

#[cfg(test)]
mod tests {
    use super::super::fixtures::tests::fixture_snapshot;
    use super::*;

    #[test]
    fn status_lines_carry_identity_blocks_and_capabilities() {
        let text = lines(&fixture_snapshot(2), 100).join("\n");
        assert!(text.contains("daemon"), "{text}");
        assert!(text.contains("revision"), "{text}");
        assert!(text.contains("desired"), "{text}");
        assert!(text.contains("applied"), "{text}");
        assert!(text.contains("observed"), "{text}");
        assert!(text.contains("platform"), "{text}");
        assert!(text.contains("nodes: 2"), "{text}");
        assert!(text.contains("proxy-groups"), "{text}");
    }
}
