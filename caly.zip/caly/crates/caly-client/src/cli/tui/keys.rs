//! Key dispatch for the TUI: normal mode (key in, quit flag out),
//! unit-tested without a terminal. Filter editing and the `Esc`
//! ladder live here; popup-modal dispatch in [`super::popup_keys`],
//! cursor movement in [`super::cursor`].

use crossterm::event::{KeyCode, KeyModifiers};

use super::Tab;
use super::app::Tui;
use super::popup::{CORES, Popup};

impl Tui {
    /// Handles one keypress; true means quit (Ctrl-C quits from anywhere).
    pub(super) fn handle_key(&mut self, code: KeyCode, modifiers: KeyModifiers) -> bool {
        if modifiers.contains(KeyModifiers::CONTROL) && matches!(code, KeyCode::Char('c')) {
            return true;
        }
        if self.popup.is_some() {
            return self.handle_popup_key(code);
        }
        if self.filtering {
            return self.handle_filter_key(code);
        }
        match code {
            KeyCode::Esc => return self.handle_escape(),
            KeyCode::Char('q') => return true,
            KeyCode::Char('?') => { self.popup = Some(super::popup::Popup::WhichKey); },
            KeyCode::Tab => self.switch_tab(1),
            KeyCode::BackTab => self.switch_tab(Tab::ALL.len() - 1),
            KeyCode::Char(digit @ '1'..='6') => {
                self.tab = Tab::from_index((digit as usize) - ('1' as usize));
            }
            KeyCode::Up | KeyCode::Char('k') => self.move_up(),
            KeyCode::Down | KeyCode::Char('j') => self.move_down(),
            KeyCode::Home | KeyCode::Char('g') => self.move_first(),
            KeyCode::End | KeyCode::Char('G') => self.move_last(),
            KeyCode::Enter => self.activate(),
            KeyCode::Char('/') => self.start_filter(),
            KeyCode::Char('v') => self.open_node_popup(),
            KeyCode::Char('r') => self.refresh(),
            KeyCode::Char('t') => self.start_sweep(),
            KeyCode::Char('R') => self.action_refresh_all(),
            KeyCode::Char('m') => self.cycle_mode(),
            KeyCode::Char('C') => self.open_cores_popup(),
            KeyCode::Char('S') => self.open_settings(),
            KeyCode::Char('L') => { self.popup = Some(super::popup::Popup::LogTail { scroll: 0 }); },
            _ => {}
        }
        false
    }

    /// The `Esc` ladder: exit filter editing, else clear the filter,
    /// else quit. (Popups close in the modal branch above.)
    fn handle_escape(&mut self) -> bool {
        if self.filtering {
            self.filtering = false;
            self.filter.clear();
        } else if self.filter.is_empty() {
            return true;
        } else {
            self.filter.clear();
        }
        self.cursor[Tab::Nodes.index()] = 0;
        false
    }

    fn handle_filter_key(&mut self, code: KeyCode) -> bool {
        match code {
            KeyCode::Enter | KeyCode::Esc => {
                self.filtering = false;
                if matches!(code, KeyCode::Esc) {
                    self.filter.clear();
                }
            }
            KeyCode::Backspace => {
                self.filter.pop();
                self.cursor[Tab::Nodes.index()] = 0;
            }
            KeyCode::Char(char) => {
                self.filter.push(char);
                self.cursor[Tab::Nodes.index()] = 0;
            }
            _ => {}
        }
        false
    }

    fn switch_tab(&mut self, delta: usize) {
        self.tab = Tab::from_index(self.tab.index() + delta);
    }

    /// `Enter`: the tab's primary action (select / pick / details).
    fn activate(&mut self) {
        match self.tab {
            Tab::Nodes => self.activate_node(),
            Tab::Groups => self.activate_member(),
            Tab::Status => self.flash("status is read-only — actions live on Nodes/Groups"),
            Tab::Subs => self.open_source_popup(),
        }
    }

    fn activate_node(&mut self) {
        let pick = self.snapshot.as_ref().and_then(|snapshot| {
            let indices = super::nodes::filtered_indices(snapshot, &self.filter);
            indices.get(self.cursor[Tab::Nodes.index()]).map(|&index| {
                let node = &snapshot.nodes[index];
                (
                    node.node_id,
                    crate::ops::client::output::decode_display_name(&node.name),
                )
            })
        });
        match pick {
            Some((node_id, label)) => self.action_select(node_id, &label),
            None => self.flash("no node under the cursor"),
        }
    }

    fn activate_member(&mut self) {
        let pick = self.snapshot.as_ref().and_then(|snapshot| {
            let rows = super::groups::flatten(snapshot);
            match rows.get(self.cursor[Tab::Groups.index()]) {
                Some(super::groups::GroupRow::Member { group, name, .. }) => {
                    Some((group.clone(), name.clone()))
                }
                _ => None,
            }
        });
        match pick {
            Some((group, member)) => self.action_pick(&group, &member),
            None => self.flash("move to a member row to pick it"),
        }
    }

    pub(super) fn open_help(&mut self) {
        let open = !matches!(self.popup, Some(Popup::Help { .. }));
        self.popup = open.then_some(Popup::Help { scroll: 0 });
    }

    pub(super) fn open_node_popup(&mut self) {
        if self.tab != Tab::Nodes {
            self.flash("node details live on the Nodes tab");
            return;
        }
        let pick = self.snapshot.as_ref().and_then(|snapshot| {
            let indices = super::nodes::filtered_indices(snapshot, &self.filter);
            indices
                .get(self.cursor[Tab::Nodes.index()])
                .map(|&index| snapshot.nodes[index].node_id)
        });
        match pick {
            Some(node_id) => self.popup = Some(Popup::Node { node_id, scroll: 0 }),
            None => self.flash("no node under the cursor"),
        }
    }

    pub(super) fn open_source_popup(&mut self) {
        let pick = self.snapshot.as_ref().and_then(|snapshot| {
            snapshot
                .sources
                .get(self.cursor[Tab::Subs.index()])
                .map(|source| source.index)
        });
        match pick {
            Some(index) => self.popup = Some(Popup::Source { index, scroll: 0 }),
            None => self.flash("no source under the cursor"),
        }
    }

    pub(super) fn open_cores_popup(&mut self) {
        if self.snapshot.is_none() {
            self.flash("no daemon connection — press r to retry");
            return;
        }
        let selected = self
            .current_core()
            .and_then(|current| CORES.iter().position(|core| *core == current))
            .unwrap_or(0);
        self.popup = Some(Popup::Cores { selected, armed: false });
    }

    pub(super) fn open_settings(&mut self) {
        if self.snapshot.is_none() {
            self.flash("no daemon connection — press r to retry");
            return;
        }
        self.popup = Some(Popup::Settings { selected: 0 });
    }

    fn start_filter(&mut self) {
        if self.tab == Tab::Nodes {
            self.filtering = true;
        } else {
            self.flash("the filter is for the node list — switch to Nodes first");
        }
    }

    /// Cycles rule → global → direct from the daemon's live mode.
    pub(super) fn cycle_mode(&mut self) {
        use caly_ipc::protocol::protocol::v2::WireMode;
        let current = self
            .snapshot
            .as_ref()
            .and_then(|snapshot| WireMode::from_wire(snapshot.desired.mode));
        match current {
            Some(WireMode::Rule) => self.action_set_mode("global"),
            Some(WireMode::Global) => self.action_set_mode("direct"),
            Some(WireMode::Direct) => self.action_set_mode("rule"),
            None => self.flash("the daemon reports an unknown mode — cannot cycle"),
        }
    }
}

#[cfg(test)]
mod tests {
    use super::super::fixtures::tests::{fixture_snapshot, press};
    use super::*;
    use crossterm::event::KeyCode;

    fn online_tui() -> Tui {
        let mut tui = Tui::new(None);
        tui.snapshot = Some(fixture_snapshot(3));
        tui
    }

    #[test]
    fn tabs_cycle_and_jump() {
        let mut tui = online_tui();
        press(&mut tui, KeyCode::Tab);
        assert_eq!(tui.tab, Tab::Groups);
        press(&mut tui, KeyCode::BackTab);
        assert_eq!(tui.tab, Tab::Nodes);
        press(&mut tui, KeyCode::Char('4'));
        assert_eq!(tui.tab, Tab::Subs);
    }

    #[test]
    fn escape_ladder_clears_the_filter_then_quits() {
        let mut tui = online_tui();
        tui.filter = "hk".to_owned();
        assert!(!press(&mut tui, KeyCode::Esc));
        assert!(tui.filter.is_empty());
        assert!(press(&mut tui, KeyCode::Esc));
    }

    #[test]
    fn filter_editing_captures_printables_and_resets_the_cursor() {
        let mut tui = online_tui();
        tui.cursor[Tab::Nodes.index()] = 2;
        press(&mut tui, KeyCode::Char('/'));
        assert!(tui.filtering);
        assert!(!press(&mut tui, KeyCode::Char('q')));
        assert_eq!(tui.filter, "q");
        assert_eq!(tui.cursor[Tab::Nodes.index()], 0);
        press(&mut tui, KeyCode::Backspace);
        assert!(tui.filter.is_empty());
        press(&mut tui, KeyCode::Enter);
        assert!(!tui.filtering);
    }

    #[test]
    fn ctrl_c_quits_even_while_filtering() {
        let mut tui = online_tui();
        tui.filtering = true;
        assert!(tui.handle_key(KeyCode::Char('c'), crossterm::event::KeyModifiers::CONTROL));
    }

    #[test]
    fn subs_enter_opens_the_source_window() {
        let mut tui = online_tui();
        tui.tab = Tab::Subs;
        press(&mut tui, KeyCode::Enter);
        assert!(matches!(tui.popup, Some(Popup::Source { index: 1, .. })));
    }

    #[test]
    fn settings_key_opens_the_window_when_online() {
        let mut tui = online_tui();
        press(&mut tui, KeyCode::Char('S'));
        assert!(matches!(tui.popup, Some(Popup::Settings { selected: 0 })));
        tui.popup = None;
        tui.snapshot = None;
        press(&mut tui, KeyCode::Char('S'));
        assert!(tui.popup.is_none());
    }

    #[test]
    fn view_key_opens_the_node_window_on_nodes_only() {
        let mut tui = online_tui();
        press(&mut tui, KeyCode::Char('v'));
        assert!(matches!(tui.popup, Some(Popup::Node { node_id, .. }) if node_id == [0u8; 16]));
        tui.popup = None;
        tui.tab = Tab::Status;
        press(&mut tui, KeyCode::Char('v'));
        assert!(tui.popup.is_none());
    }
}
