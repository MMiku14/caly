//! Dispatch for `caly env`.

use std::process::ExitCode;

pub fn dispatch(unset: bool, fish: bool) -> ExitCode {
    crate::ops::client::env_helper::print_shell_env(unset, fish, 7890)
}
