//! `node inline` (alias: `set proxy list`) — the offline inline-entries list.
//!
//! The `set proxy add/edit/remove/import` leaves round-trip entries
//! under `<state>/inline-proxies/`, but no leaf ever displayed them
//! back (the W3a tree face merges them into the declared tree; the
//! plain table/JSON list was missing). This face closes that gap.
//!
//! Displayed URIs are credential-stripped (see [`split_display_uri`]):
//! a list leaf must never leak passwords, UUIDs or opaque config
//! blobs into terminals, logs or piped JSON.

use std::process::ExitCode;

use crate::ops::client::inline_proxy::{InlineProxy, list_entries, resolve_paths_pub};
use crate::ops::layout::CliOutput;

/// Lists the operator-declared inline entries (offline, sorted by id).
pub fn run(output: CliOutput, format: Option<crate::cli::OutputFormat>) -> ExitCode {
    let entries = list_entries(&resolve_paths_pub());
    if output.is_json() {
        render_inline_json(output, &entries);
    } else {
        render_inline_table(format, &entries);
    }
    ExitCode::SUCCESS
}

fn render_inline_json(output: CliOutput, entries: &[(String, InlineProxy)]) {
    let items: Vec<serde_json::Value> = entries
        .iter()
        .map(|(id, entry)| {
            let (scheme, host) = split_display_uri(&entry.uri);
            serde_json::json!({
                "id": id,
                "scheme": scheme,
                "host": host,
                "group": entry.group,
                "added_at_ms": entry.added_at_ms,
            })
        })
        .collect();
    output.success(
        &format!("listed {} inline {}", items.len(), plural(items.len())),
        serde_json::json!({
            "entries": items,
            "count": items.len(),
        }),
    );
}

fn plural(count: usize) -> &'static str {
    if count == 1 { "entry" } else { "entries" }
}

/// Human face: adaptive table/TSV mirroring the `proxy-group list` face.
fn render_inline_table(
    format: Option<crate::cli::OutputFormat>,
    entries: &[(String, InlineProxy)],
) {
    let mode = crate::ops::layout::table_mode(format);
    let rows: Vec<Vec<String>> = entries
        .iter()
        .map(|(id, entry)| {
            vec![
                id.clone(),
                sanitize_display_uri(&entry.uri),
                entry.group.clone().unwrap_or_default(),
            ]
        })
        .collect();
    let headers: &[&str] = match mode {
        crate::ops::layout::TableMode::Tsv => &["id", "uri", "group"],
        crate::ops::layout::TableMode::Table => &["ID", "URI", "GROUP"],
    };
    crate::ops::layout::print_table(mode, headers, &rows);
}

/// Renders a proxy URI for display (`ss://host:port`, `vmess://…`).
fn sanitize_display_uri(uri: &str) -> String {
    let (scheme, host) = split_display_uri(uri);
    if scheme.is_empty() {
        return "…".to_owned();
    }
    if host.is_empty() {
        return format!("{scheme}://…");
    }
    format!("{scheme}://{host}")
}

/// Splits a proxy URI into a display-safe `(scheme, host)` pair.
///
/// Credentials never reach the display: userinfo is stripped, the
/// query/fragment dropped, and opaque payloads (a bare base64 blob
/// with no authority, e.g. `vmess://…`) show no host at all. A
/// malformed URI yields `("", "")`.
fn split_display_uri(uri: &str) -> (String, String) {
    let Some((scheme, rest)) = uri.split_once("://") else {
        return (String::new(), String::new());
    };
    if scheme.is_empty() || !is_scheme(scheme) {
        return (String::new(), String::new());
    }
    let authority = rest.split(['/', '?', '#']).next().unwrap_or_default();
    let host = authority
        .rsplit_once('@')
        .map_or(authority, |(_, host)| host);
    if is_bare_host(host) {
        (scheme.to_owned(), host.to_owned())
    } else {
        (scheme.to_owned(), String::new())
    }
}

fn is_scheme(value: &str) -> bool {
    value
        .chars()
        .all(|c| c.is_ascii_alphanumeric() || matches!(c, '+' | '-' | '.'))
}

/// A printable bare host: non-empty, no whitespace/controls, and
/// shaped like a host (`example.com`, `1.2.3.4`, `[::1]:8080`) rather
/// than an opaque token. Single-label names without a port
/// (`localhost`) stay hidden — indistinguishable from blobs, and
/// safety wins over completeness here.
fn is_bare_host(value: &str) -> bool {
    !value.is_empty()
        && !value.chars().any(|c| c.is_whitespace() || c.is_control())
        && (value.contains('.') || value.contains(':'))
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn split_strips_userinfo_and_query() {
        assert_eq!(
            split_display_uri("ss://method:pass@example.com:8388/?plugin=x#frag"),
            ("ss".to_owned(), "example.com:8388".to_owned())
        );
        assert_eq!(
            split_display_uri("trojan://password@example.com:443"),
            ("trojan".to_owned(), "example.com:443".to_owned())
        );
    }

    #[test]
    fn split_hides_opaque_payloads() {
        // a bare base64 blob has no authority structure.
        assert_eq!(
            split_display_uri("vmess://eyJ2IjoiMn0"),
            ("vmess".to_owned(), String::new())
        );
        assert_eq!(
            split_display_uri("not a uri"),
            (String::new(), String::new())
        );
        assert_eq!(split_display_uri(""), (String::new(), String::new()));
    }

    #[test]
    fn split_accepts_bare_and_bracketed_hosts() {
        assert_eq!(
            split_display_uri("http://proxy.lan:8080/path"),
            ("http".to_owned(), "proxy.lan:8080".to_owned())
        );
        assert_eq!(
            split_display_uri("socks5://[::1]:1080"),
            ("socks5".to_owned(), "[::1]:1080".to_owned())
        );
    }

    #[test]
    fn sanitize_renders_display_shapes() {
        assert_eq!(
            sanitize_display_uri("ss://m:p@example.com:8388/"),
            "ss://example.com:8388"
        );
        assert_eq!(sanitize_display_uri("vmess://eyJ2IjoiMn0"), "vmess://…");
        assert_eq!(sanitize_display_uri("garbage"), "…");
    }
}
