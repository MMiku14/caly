//! Proxy Auto-Config (PAC) export and publication tool (`caly pac …`).

use std::path::PathBuf;
use std::process::ExitCode;
use crate::ops::layout::{ok, error, hint};

/// Exports PAC file to disk.
pub fn export_pac(output_path: Option<PathBuf>, socks_port: u16, http_port: u16) -> ExitCode {
    let out = output_path.unwrap_or_else(|| PathBuf::from("proxy.pac"));
    let socks = if socks_port == 0 { 7890 } else { socks_port };
    let http = if http_port == 0 { 7890 } else { http_port };
    
    let pac_content = caly_platform::pac::render_pac(&format!("127.0.0.1:{socks}"), &format!("127.0.0.1:{http}"));
    if let Err(e) = std::fs::write(&out, pac_content) {
        error(&format!("failed to write PAC file {}: {e}", out.display()));
        return ExitCode::from(1);
    }
    ok(&format!("PAC file successfully exported to {}", out.display()));
    hint("configure this file in macOS/Windows/iOS network proxy settings");
    ExitCode::SUCCESS
}
