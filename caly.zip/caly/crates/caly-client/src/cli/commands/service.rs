//! Systemd user service generator and lifecycle management (`caly service …`).

use std::path::PathBuf;
use std::process::{Command, ExitCode};
use crate::ops::layout::{CliOutput, ok, error, hint, note};

/// Generates standard systemd user service unit definition.
pub fn generate_service_unit(bin_path: &str) -> String {
    format!(r#"[Unit]
Description=Caly Daemon-First Proxy Core Manager
Documentation=https://github.com/MMiku14/Caly
After=network.target network-online.target
Wants=network-online.target

[Service]
Type=simple
ExecStart={bin_path} daemon
Restart=always
RestartSec=3s
LimitNOFILE=65535
AmbientCapabilities=CAP_NET_ADMIN CAP_NET_BIND_SERVICE
CapabilityBoundingSet=CAP_NET_ADMIN CAP_NET_BIND_SERVICE

[Install]
WantedBy=default.target
"#)
}

/// Dispatches `caly service` subcommands.
pub fn dispatch(action: &str, json: bool) -> ExitCode {
    let home = std::env::var("HOME").unwrap_or_else(|_| ".".to_owned());
    let unit_dir = PathBuf::from(&home).join(".config/systemd/user");
    let unit_file = unit_dir.join("caly.service");

    match action {
        "install" => {
            if let Err(e) = std::fs::create_dir_all(&unit_dir) {
                error(&format!("cannot create systemd unit directory: {e}"));
                return ExitCode::from(1);
            }
            let current_exe = std::env::current_exe().map_or_else(
                |_| "/usr/local/bin/caly".to_owned(),
                |p| p.to_string_lossy().into_owned(),
            );
            let unit_content = generate_service_unit(&current_exe);
            if let Err(e) = std::fs::write(&unit_file, unit_content) {
                error(&format!("cannot write unit file {}: {e}", unit_file.display()));
                return ExitCode::from(1);
            }
            let _ = Command::new("systemctl").args(["--user", "daemon-reload"]).status();
            ok(&format!("systemd user service installed at {}", unit_file.display()));
            hint("enable and start with: systemctl --user enable --now caly");
            ExitCode::SUCCESS
        }
        "enable" => {
            let status = Command::new("systemctl").args(["--user", "enable", "--now", "caly"]).status();
            if status.is_ok_and(|s| s.success()) {
                ok("caly user service enabled and started");
                ExitCode::SUCCESS
            } else {
                error("failed to enable systemctl --user service");
                ExitCode::from(1)
            }
        }
        "status" => {
            let _ = Command::new("systemctl").args(["--user", "status", "caly"]).status();
            ExitCode::SUCCESS
        }
        other => {
            error(&format!("unknown service action `{other}`, valid: install, enable, status"));
            ExitCode::from(2)
        }
    }
}
