//! `caly log` — inspect and configure 3-tier logging (App, Kernels, IPC).

use std::process::ExitCode;
use crate::ops::layout::CliOutput;

/// Dispatch for log configuration commands.
pub fn dispatch(
    subcommand: Option<&str>,
    target: Option<&str>,
    level: Option<&str>,
    apply: bool,
    json: bool,
) -> ExitCode {
    match subcommand {
        None | Some("status") | Some("show") | Some("get") => {
            crate::ops::client::log_config::show_log_status(json)
        }
        Some("set") => {
            if let (Some(tgt), Some(lvl)) = (target, level) {
                crate::ops::client::log_config::set_log_tier(tgt, lvl, apply, json)
            } else {
                crate::ops::layout::error("usage: caly log set <app|kernel|ipc|all> <level> [--apply]");
                ExitCode::from(2)
            }
        }
        Some(other) => {
            crate::ops::layout::error(&format!("unknown log command `{other}`, use `caly log` or `caly log set <target> <level>`"));
            ExitCode::from(2)
        }
    }
}
