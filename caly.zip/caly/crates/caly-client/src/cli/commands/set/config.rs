//! `set config …` dispatch.
//!
//! `apply` / `generate` / `default` / `edit` route
//! through the typed `client::run_client` / `client::*`
//! helpers (the `bridge` shim was retired). 
//! `diff` is a real line-by-line diff (current vs
//! `--file <PATH>` or vs the documented default).

use std::process::ExitCode;

use crate::cli::SetConfigCmd;
use crate::ops::client::legacy::ConfigCmd;
use crate::ops::layout::CliOutput;

pub fn dispatch(c: SetConfigCmd, options: crate::cli::CliOptions, _output: CliOutput) -> ExitCode {
    match c {
        SetConfigCmd::Apply => {
            crate::ops::client::run_client(crate::ClientCommand::Config(ConfigCmd::Apply), options)
        }
        SetConfigCmd::Generate => crate::ops::client::config_generate::generate_config(options.json),
        SetConfigCmd::Default => crate::ops::client::config_generate::reset_default_config(options.json),
        SetConfigCmd::Edit(editor) => {
            let editor = match editor {
                crate::cli::Editor::Vim => crate::ops::types::Editor::Vim,
                crate::cli::Editor::Nvim => crate::ops::types::Editor::Nvim,
            };
            crate::ops::client::config_generate::edit_config(editor, options.json)
        }
        SetConfigCmd::Diff { file } => {
            crate::ops::client::config_generate::diff_config(file.as_deref(), options.json)
        }
        SetConfigCmd::Set { key, value, apply } => {
            crate::ops::client::config_kv::config_set(options.json, &key, &value, apply)
        }
    }
}

/// Rollback config to the previous backup generation.
pub fn rollback_config() -> ExitCode {
    let root = caly_platform::paths::AppPaths::from_env().config;
    let target = root.join("config.yaml");
    let bak = root.join("config.yaml.bak");
    if !bak.exists() {
        crate::ops::layout::error("no backup file config.yaml.bak found");
        return ExitCode::from(1);
    }
    if let Err(e) = std::fs::copy(&bak, &target) {
        crate::ops::layout::error(&format!("failed to rollback: {e}"));
        return ExitCode::from(1);
    }
    crate::ops::layout::ok("config.yaml successfully restored from previous backup generation");
    crate::ops::layout::hint("run `caly config apply` to push changes to the daemon");
    ExitCode::SUCCESS
}
