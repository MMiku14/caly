//! `set proxy …` dispatch.
//!
//! `On` / `Off` route through the typed
//! `client::run_client` path. the four CRUD
//! leaves (`add` / `edit` / `remove` / `import`) write
//! `<state>/inline-proxies/<id>.json` via
//! `client::inline_proxy`.
//!
//! every CRUD leaf routes through the shared
//! `commands::set::common::run_writer` envelope (the
//! fifth resource on the envelope, joining `set sub` /
//! `set profile` / `set rule-provider` /
//! `set proxy-group`). The four per-leaf bodies that
//! each hand-rolled their own `Ok(_)` / `Err(_)`
//! envelope builders collapsed into one-line shims;
//! the writer's `InlineProxyOutcome { Applied, DryRun }`
//! carries the on-disk `id` and the `ImportOutcome
//! { Applied, DryRun, NoOp }` carries the count, both
//! projected into the JSON envelope via the
//! `extra_payload` closure.

use std::process::ExitCode;

use crate::cli::SetProxyCmd;
use crate::ops::client::inline_proxy::{ImportOutcome, InlineProxyError, InlineProxyOutcome};
use crate::ops::client::legacy::SysCmd;
use crate::commands::set::common::{
    OutcomeKind, ResourceVerb, Summaries, WriteEnvelope, run_writer,
};
use crate::ops::layout::CliOutput;

/// The singular resource name used by the
/// [`Summaries::standard`] constructor for the
/// `set proxy remove` CRUD leaf (`add` / `edit`
/// are bespoke because their `InlineProxyOutcome`
/// carries an on-disk `id` that the envelope
/// projects via `inline_proxy_payload`; `import`
/// is the 1-of-1 oddity whose `applied` /
/// `dry_run` strings differ from the "X added"
/// pattern).
const NOUN: &str = "inline proxy";

pub fn dispatch(c: SetProxyCmd, options: crate::cli::CliOptions, output: CliOutput) -> ExitCode {
    use crate::ops::client::inline_proxy as cmd;
    let paths = cmd::resolve_paths_pub();
    match c {
        SetProxyCmd::On => {
            crate::ops::client::run_client(crate::ClientCommand::Sys(SysCmd::Proxy(true)), options)
        }
        SetProxyCmd::Off => {
            crate::ops::client::run_client(crate::ClientCommand::Sys(SysCmd::Proxy(false)), options)
        }
        // W-PAC (2026-08-12): `sysproxy pac [url]` — without a URL the
        // CLI writes a generated PAC (local subnets direct, everything
        // else via the local proxy) into the state directory and points
        // the desktop at it; with a URL that URL is used verbatim. The
        // daemon only performs the desktop switch (auto mode +
        // autoconfig-url); the PAC authoring is fully offline.
        SetProxyCmd::Pac { url } => dispatch_pac(url, options, output),
        SetProxyCmd::Add {
            uri,
            group,
            apply,
            dry_run,
        } => dispatch_add(
            &paths,
            output,
            &uri,
            group.as_deref(),
            apply,
            dry_run,
            options,
        ),
        SetProxyCmd::Edit { id, apply, dry_run } => {
            dispatch_edit(&paths, output, &id, apply, dry_run, options)
        }
        SetProxyCmd::Remove { id, apply, dry_run } => {
            dispatch_remove(&paths, output, &id, apply, dry_run, options)
        }
        SetProxyCmd::Import {
            path,
            apply,
            dry_run,
        } => dispatch_import(&paths, output, &path, apply, dry_run, options),
    }
}

fn dispatch_add(
    paths: &caly_platform::paths::AppPaths,
    output: CliOutput,
    uri: &str,
    group: Option<&str>,
    apply: bool,
    dry_run: bool,
    options: crate::cli::CliOptions,
) -> ExitCode {
    use crate::ops::client::inline_proxy as cmd;
    let effective_apply = apply && !dry_run;
    let leaf = format!("set proxy add {uri}");
    let code = run_writer(
        output,
        Summaries::standard(NOUN, ResourceVerb::Add),
        &WriteEnvelope {
            name: uri,
            leaf: &leaf,
        },
        || cmd::add_proxy(paths, uri, group, effective_apply),
        classify_inline,
        code_for,
        inline_proxy_payload,
    );
    converge_inline(code, output, paths, effective_apply, options)
}

/// Best-effort full refresh after a successful applied CRUD write so
/// the daemon folds the changed inline files on this command — not on
/// some later refresh. Mirrors `sub.rs::crud_and_converge` (whose
/// Remove/Disable/Enable converge unconditionally, import-NoOp
/// included here for uniformity); the refresh result never overrides
/// the write's exit code — a down daemon must not fail a write that
/// already landed on disk.
fn converge_inline(
    code: ExitCode,
    output: CliOutput,
    paths: &caly_platform::paths::AppPaths,
    effective_apply: bool,
    options: crate::cli::CliOptions,
) -> ExitCode {
    if effective_apply && code == ExitCode::SUCCESS {
        let _ = super::sub::refresh_leaf_dispatch(output, paths, None, false, false, options);
    }
    code
}

fn dispatch_edit(
    paths: &caly_platform::paths::AppPaths,
    output: CliOutput,
    id: &str,
    apply: bool,
    dry_run: bool,
    options: crate::cli::CliOptions,
) -> ExitCode {
    use crate::ops::client::inline_proxy as cmd;
    let effective_apply = apply && !dry_run;
    let leaf = format!("set proxy edit {id}");
    let code = run_writer(
        output,
        Summaries::custom(
            "inline proxy edited",
            "inline proxy would be edited (dry-run)",
            "inline proxy already edited",
        ),
        &WriteEnvelope {
            name: id,
            leaf: &leaf,
        },
        || cmd::edit_proxy(paths, id, effective_apply),
        classify_inline,
        code_for,
        inline_proxy_payload,
    );
    converge_inline(code, output, paths, effective_apply, options)
}

fn dispatch_remove(
    paths: &caly_platform::paths::AppPaths,
    output: CliOutput,
    id: &str,
    apply: bool,
    dry_run: bool,
    options: crate::cli::CliOptions,
) -> ExitCode {
    use crate::ops::client::inline_proxy as cmd;
    let effective_apply = apply && !dry_run;
    let leaf = format!("set proxy remove {id}");
    let code = run_writer(
        output,
        Summaries::standard(NOUN, ResourceVerb::Remove),
        &WriteEnvelope {
            name: id,
            leaf: &leaf,
        },
        || cmd::remove_proxy(paths, id, effective_apply),
        classify_inline,
        code_for,
        inline_proxy_payload,
    );
    converge_inline(code, output, paths, effective_apply, options)
}

fn dispatch_import(
    paths: &caly_platform::paths::AppPaths,
    output: CliOutput,
    path: &std::path::Path,
    apply: bool,
    dry_run: bool,
    options: crate::cli::CliOptions,
) -> ExitCode {
    use crate::ops::client::inline_proxy as cmd;
    let effective_apply = apply && !dry_run;
    let path_str = path.display().to_string();
    let leaf = format!("set proxy import {path_str}");
    let code = run_writer(
        output,
        Summaries::custom(
            "imported inline proxies",
            "would import inline proxies (dry-run)",
            "no new inline proxies to import",
        ),
        &WriteEnvelope {
            name: &path_str,
            leaf: &leaf,
        },
        || cmd::import_proxy(paths, path, effective_apply),
        classify_import,
        code_for,
        import_payload,
    );
    converge_inline(code, output, paths, effective_apply, options)
}

/// Projects an `InlineProxyError` to the stable CLI
/// `code:` used in the JSON error envelope. The four
/// variants are 1-for-1 with the `set proxy <verb>`
/// failure modes; pre-Round-23 each leaf inlined this
/// match and the `code` strings drifted between call
/// sites. The shared `common::run_writer` envelope
/// surfaces the same `code` to every operator-facing
/// `jq` consumer.
fn code_for(error: &InlineProxyError) -> &'static str {
    match error {
        InlineProxyError::InvalidUri(_) => "proxy.invalid_uri",
        InlineProxyError::AlreadyDeclared(_) => "proxy.already_declared",
        InlineProxyError::NotDeclared(_) => "proxy.not_declared",
        InlineProxyError::Io(_) => "proxy.write_failed",
    }
}

/// the `classify` closure for
/// `InlineProxyOutcome`. The `set proxy add | edit |
/// remove` leaves use this; `import` has its own
/// `classify_import` because `ImportOutcome` is a
/// separate enum. Round 23 folded the per-call id
/// into the outcome variants (the `Applied` /
/// `DryRun` cases now carry `id: String`), so the
/// `match` arms destructure the enum but only
/// inspect the variant tag. The `InlineProxyOutcome`
/// enum does not surface a `NoChange` arm today
/// (the writer's `add_proxy` short-circuits on
/// duplicate URIs with `AlreadyDeclared`; `edit` /
/// `remove` short-circuit on unknown ids with
/// `NotDeclared`); the closure still matches
/// `NoChange` for the future caller that needs
/// idempotent success.
fn classify_inline(outcome: &InlineProxyOutcome) -> OutcomeKind {
    match outcome {
        InlineProxyOutcome::DryRun { .. } => OutcomeKind::DryRun,
        InlineProxyOutcome::Applied { .. } => OutcomeKind::Applied,
    }
}

/// the `classify` closure for
/// `ImportOutcome`. `NoOp` is the idempotent
/// success path — the operator passed `--apply`,
/// but every line of the import file was already
/// declared, so the writer did not change any
/// on-disk state. The dispatch surfaces this as
/// `dry_run: false` (the user did not opt in to a
/// preview) with a distinct human summary
/// (`"no new inline proxies to import"`) so the
/// operator can tell apart "I imported N
/// entries" from "I confirmed everything was
/// already there". Pre-Round 25 `NoOp` was
/// collapsed into `DryRun` (the writer returned
/// `DryRun` when `count == 0`), which lied to
/// the operator: `--apply` followed by a
/// `dry_run: true` envelope suggested the write
/// was held back when in fact it was held back by
/// the no-change check, not the dry-run policy.
fn classify_import(outcome: &ImportOutcome) -> OutcomeKind {
    match outcome {
        ImportOutcome::DryRun { .. } => OutcomeKind::DryRun,
        ImportOutcome::Applied { .. } => OutcomeKind::Applied,
        ImportOutcome::NoOp => OutcomeKind::NoChange,
    }
}

/// Extra-payload projection for `InlineProxyOutcome`.
/// The on-disk `id` is the only data the envelope needs
/// beyond the base `name` / `leaf` / `dry_run` triple.
/// The dispatch's `add` / `edit` / `remove` leaves
/// reuse this closure verbatim.
fn inline_proxy_payload(outcome: &InlineProxyOutcome) -> serde_json::Value {
    let id = match outcome {
        InlineProxyOutcome::Applied { id } | InlineProxyOutcome::DryRun { id } => id.clone(),
    };
    serde_json::json!({ "id": id })
}

/// Extra-payload projection for `ImportOutcome`. The
/// `count` is reported for every variant; `NoOp`
/// collapses to `count: 0`. The path lives in
/// `envelope.name` (the user-typed `path`), so we
/// only need to project the count here.
fn import_payload(outcome: &ImportOutcome) -> serde_json::Value {
    let count = match outcome {
        ImportOutcome::Applied { count } | ImportOutcome::DryRun { count } => *count,
        ImportOutcome::NoOp => 0,
    };
    serde_json::json!({ "count": count })
}

#[cfg(test)]
mod dry_run_envelope_tests;

/// `sysproxy pac [url]` dispatch (extracted for the 100-line budget):
/// without a URL the CLI writes a generated PAC into the state
/// directory and points the desktop at it; with a URL that URL is used
/// verbatim. The daemon only performs the desktop switch (auto mode +
/// autoconfig-url); the PAC authoring is fully offline.
fn dispatch_pac(
    url: Option<String>,
    options: crate::cli::CliOptions,
    output: CliOutput,
) -> ExitCode {
    let pac_url = match url {
        // Shared gate with the daemon boundary: fail fast here with
        // the CLI envelope instead of round-tripping a typo.
        Some(url) => {
            if let Err(error) = caly_platform::pac::validate_pac_url(&url) {
                return pac_write_error(output, &error.to_string());
            }
            url
        }
        None => match generate_pac_file(output) {
            Ok(url) => url,
            Err(code) => return code,
        },
    };
    crate::ops::client::run_client(
        crate::ClientCommand::Sys(SysCmd::ProxyPac(pac_url)),
        options,
    )
}

/// Writes the caly-generated PAC file into the state directory and
/// returns its `file://` URL for the desktop's autoconfig-url.
///
/// Thin dispatch: port resolution (offline config read) stays here —
/// the daemon takes its system-proxy endpoint from the same config
/// file with no CLI overrides, so no drift is possible — while PAC
/// rendering, atomic publish and URL validation live in
/// `caly-platform::pac`, shared with the daemon boundary.
fn generate_pac_file(output: CliOutput) -> Result<String, ExitCode> {
    let paths = caly_platform::paths::AppPaths::from_env();
    // The PAC must point at the port the daemon would actually listen on.
    // A missing config falls back to the daemon's 7890 default, but a
    // present-but-unreadable config must fail loudly — silently generating a
    // PAC against the wrong port black-holes everything through the proxy.
    let port: u16 = match crate::ops::config::load_from(paths.config.clone()) {
        Ok(Some(config)) => config.kernel.mixed_port,
        Ok(None) => 7890,
        Err(error) => {
            return Err(pac_write_error(output, &format!(
                "cannot read config.yaml for the proxy port: {error}"
            )));
        }
    };
    // `AppPaths::state` already includes the `caly` component.
    match caly_platform::pac::publish_pac(&paths.state, port) {
        Ok(pac_path) => Ok(format!("file://{}", pac_path.display())),
        Err(error) => Err(pac_write_error(output, &error.to_string())),
    }
}

/// Builds the structured error for a `sysproxy pac` file-operation failure
/// and prints it through the same envelope as other CLI errors.
fn pac_write_error(output: CliOutput, detail: &str) -> ExitCode {
    let cli = crate::ops::layout::CliError::new(
        "sysproxy.pac_write_failed",
        detail.to_owned(),
        "sysproxy pac",
    );
    crate::ops::layout::report_error_returning(output, cli)
}
