//! Live fallback for `node pick`.
//!
//! Kernel-side groups (a subscription's `select` groups such as AUTO,
//! builtins such as GLOBAL) never enter the declared entry tree, but a
//! pick executes kernel-side anyway — so a group the declared tree
//! misses is resolved from the live snapshot instead. This keeps `node
//! pick` consistent with the `node groups` listing (and with the TUI's
//! Groups-tab pick, which was always live-based).

use std::process::ExitCode;

use crate::ops::entry_tree::{TreeGroup, TreeMember};

/// Snapshot probe budget for the live-group lookup (same triage
/// posture as `caly status`: never hang on a wedged socket).
const PROBE_BUDGET: std::time::Duration = std::time::Duration::from_millis(500);

/// Resolves `group` against the live snapshot's proxy groups,
/// synthesizing the [`TreeGroup`] the declared-tree pick flow
/// validates against. `Err` is the unknown-group error (already
/// printed): neither declared nor live, or the daemon is down.
pub(super) fn live_selector_target(
    options: &crate::cli::CliOptions,
    group: &str,
    json: bool,
) -> Result<TreeGroup, ExitCode> {
    let socket = options.socket.clone().unwrap_or_else(|| {
        std::env::var_os("CALY_SOCKET").map_or_else(
            || caly_platform::paths::AppPaths::from_env().socket_path(),
            std::path::PathBuf::from,
        )
    });
    let snapshot =
        match crate::ops::client::execute::probe_snapshot_with_budget(&socket, PROBE_BUDGET) {
            Ok(snapshot) => snapshot,
            Err(_) => return Err(unknown_group_error(group, json)),
        };
    let found = snapshot
        .proxy_groups
        .iter()
        .find(|candidate| candidate.name == group)
        .or_else(|| {
            snapshot
                .proxy_groups
                .iter()
                .find(|candidate| candidate.name.eq_ignore_ascii_case(group))
        });
    match found {
        Some(found) => Ok(live_tree_group(&found.name, &found.kind, &found.members)),
        None => Err(unknown_group_error(group, json)),
    }
}

/// Builds the synthesized group: the wire kind lowercases onto the
/// declared badge vocabulary (`Selector` → `selector`, `URLTest` →
/// `urltest`), and `DIRECT`/`REJECT` members become builtins so the
/// shared canonicalization treats them like declared ones.
fn live_tree_group(name: &str, kind: &str, members: &[String]) -> TreeGroup {
    TreeGroup {
        name: name.to_owned(),
        kind: kind.to_lowercase(),
        url: None,
        interval_seconds: None,
        tolerance_ms: None,
        members: members
            .iter()
            .map(|member| {
                if member.eq_ignore_ascii_case("DIRECT") || member.eq_ignore_ascii_case("REJECT") {
                    TreeMember::Builtin {
                        name: member.clone(),
                        kind: "builtin".to_owned(),
                    }
                } else {
                    TreeMember::Node {
                        name: member.clone(),
                        kind: "node".to_owned(),
                    }
                }
            })
            .collect(),
    }
}

/// Unknown-group error with an actionable listing (the previous text
/// pointed at `node enable`, which only manages declared groups —
/// a circle back to the same miss).
fn unknown_group_error(group: &str, json: bool) -> ExitCode {
    crate::ops::client::output::report_failure(
        &format!(
            "group `{group}` is neither declared nor live; see `caly node groups` for the live groups, or declare it with `caly node add {group} --type select`"
        ),
        json,
    )
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn live_group_maps_kind_and_builtin_members() {
        let group = live_tree_group(
            "AUTO",
            "Selector",
            &["smoke-node".to_owned(), "DIRECT".to_owned()],
        );
        assert_eq!(group.name, "AUTO");
        assert_eq!(group.kind, "selector");
        assert!(matches!(
            group.members[0],
            TreeMember::Node { .. }
        ));
        assert!(matches!(
            group.members[1],
            TreeMember::Builtin { .. }
        ));
    }

    #[test]
    fn live_group_lowercases_auto_managed_kinds() {
        let group = live_tree_group("auto", "URLTest", &[]);
        assert_eq!(group.kind, "urltest");
    }
}
