//! The **Caly TUI**: a modern, LazyVim-inspired ratatui frontend.
#![forbid(unsafe_code)]
#![warn(missing_docs, rust_2018_idioms)]

pub mod browser;
pub mod settings;
pub mod theme;
pub mod widgets;

use std::time::{Duration, Instant};
use crossterm::event::{
    self, Event, KeyCode, KeyEvent, KeyEventKind, KeyModifiers, MouseButton, MouseEvent,
    MouseEventKind,
};
use crate::settings::Settings;
use crate::theme::{color, icon, style};
use crate::widgets::{
    draw_cover_image, draw_cover_placeholder, format_volume_bar, render_visualizer,
};

use ratatui::layout::{Alignment, Constraint, Direction, Layout, Rect};
use ratatui::style::{Color, Modifier, Style};
use ratatui::text::{Line, Span};
use ratatui::widgets::{
    Block, BorderType, Borders, Clear, Gauge, List, ListItem, ListState, Paragraph, Wrap,
};
use ratatui::Frame;

use caly_artwork::Artwork;
use caly_core::progress::format_time;
use caly_core::queue::RepeatMode;
use caly_engine::control::Control;
use caly_engine::{Engine, PlayState};

/// Refresh interval (100 ms).
pub const TICK: Duration = Duration::from_millis(100);

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
enum Mode {
    Queue,
    Input,
    Help,
    SignalFlow,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
enum Focus {
    Main,
    Browser,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
enum InputKind {
    AddPath,
    QueueFilter,
    BrowserFilter,
}

struct UiState {
    mode: Mode,
    focus: Focus,
    show_browser: bool,
    browser_width: u16,
    list: ListState,
    filter: String,
    input: String,
    input_label: String,
    input_kind: InputKind,
    telescope_sel: usize,
    browser: Option<browser::BrowserState>,
    browser_list: ListState,
    help_scroll: u16,
    status: String,
    last_render: Instant,
    frame: Option<FrameRects>,
    last_click: Option<(Instant, u16, u16)>,
    queue_row_map: Vec<usize>,
    cover: Option<Artwork>,
    cover_uri: String,
    cover_loading: Option<String>,
    cover_rx: Option<std::sync::mpsc::Receiver<Option<Artwork>>>,
    cache_dir: Option<std::path::PathBuf>,
    vol_target: Option<f32>,
}

#[derive(Debug, Clone, Copy, Default)]
struct FrameRects {
    main: Rect,
    queue_inner: Rect,
    queue_offset: usize,
    browser: Option<Rect>,
    browser_inner: Option<Rect>,
    browser_offset: usize,
}

/// The TUI application bound to an engine handle.
pub struct Tui {
    engine: Engine,
    ui: UiState,
    settings: Settings,
}

impl Tui {
    /// Creates the TUI for an engine with settings.
    pub fn new(engine: Engine, settings: Settings) -> Self {
        let artwork_ok = settings.artwork;
        let mut list = ListState::default();
        list.select(engine.snapshot().queue_cursor.or(Some(0)));
        Self {
            engine,
            settings,
            ui: UiState {
                mode: Mode::Queue,
                focus: Focus::Main,
                show_browser: false,
                browser_width: 38,
                list,
                filter: String::new(),
                input: String::new(),
                input_label: String::new(),
                input_kind: InputKind::AddPath,
                telescope_sel: 0,
                browser: None,
                browser_list: ListState::default(),
                help_scroll: 0,
                status: String::new(),
                last_render: Instant::now(),
                frame: None,
                last_click: None,
                queue_row_map: Vec::new(),
                cover: None,
                cover_uri: String::new(),
                cover_loading: None,
                cover_rx: None,
                cache_dir: artwork_cache_dir().filter(|_| artwork_ok),
                vol_target: None,
            },
        }
    }

    /// The key event loop; blocks until the user quits.
    pub fn run(&mut self) {
        let mut terminal = ratatui::init();
        if self.settings.mouse {
            let _ = crossterm::execute!(std::io::stdout(), crossterm::event::EnableMouseCapture);
        }
        let res = self.event_loop(&mut terminal);
        if self.settings.mouse {
            let _ = crossterm::execute!(std::io::stdout(), crossterm::event::DisableMouseCapture);
        }
        ratatui::restore();
        if let Err(e) = res {
            eprintln!("caly: TUI error: {e}");
        }
    }

    fn event_loop<B: ratatui::backend::Backend>(
        &mut self,
        terminal: &mut ratatui::Terminal<B>,
    ) -> std::io::Result<()> {
        loop {
            self.publish_if_due(terminal)?;
            let has_event = event::poll(TICK)?;
            if !has_event {
                continue;
            }
            match event::read()? {
                Event::Key(key) if key.kind == KeyEventKind::Press => {
                    if self.handle_key(key)? {
                        return Ok(());
                    }
                }
                Event::Mouse(m) if self.settings.mouse => {
                    if self.handle_mouse(m)? {
                        return Ok(());
                    }
                }
                Event::Resize(_, _) => {
                    self.ui.frame = None;
                }
                _ => {}
            }
        }
    }

    fn publish_if_due<B: ratatui::backend::Backend>(
        &mut self,
        terminal: &mut ratatui::Terminal<B>,
    ) -> std::io::Result<()> {
        let due = self.ui.last_render.elapsed() >= TICK;
        if due {
            self.sync_volume_intent();
            self.tick_artwork();
            terminal.draw(|f| draw(f, &mut self.ui, &self.engine))?;
            self.ui.last_render = Instant::now();
        }
        Ok(())
    }

    fn sync_volume_intent(&mut self) {
        if let Some(t) = self.ui.vol_target {
            if (self.engine.snapshot().volume - t).abs() < 1e-4 {
                self.ui.vol_target = None;
            }
        }
    }

    fn tick_artwork(&mut self) {
        let snap = self.engine.snapshot();
        let current = snap.current.as_ref().map(|c| c.uri.clone());
        let Some(uri) = current else {
            self.ui.cover = None;
            self.ui.cover_uri.clear();
            return;
        };
        if uri != self.ui.cover_uri {
            self.ui.cover = None;
            self.ui.cover_uri.clear();
        }
        if let Some(rx) = &self.ui.cover_rx {
            match rx.try_recv() {
                Ok(art) => {
                    self.ui.cover_rx = None;
                    self.ui.cover_loading = None;
                    if uri == self.ui.cover_uri {
                        self.ui.cover = art;
                    }
                }
                Err(std::sync::mpsc::TryRecvError::Empty) => {}
                Err(std::sync::mpsc::TryRecvError::Disconnected) => {
                    self.ui.cover_rx = None;
                    self.ui.cover_loading = None;
                }
            }
        }
        if self.ui.cover.is_none()
            && self.ui.cover_loading.as_deref() != Some(uri.as_str())
            && self.ui.cover_uri != uri
            && self.ui.cache_dir.is_some()
        {
            let cache = self.ui.cache_dir.clone().expect("checked above");
            let (tx, rx) = std::sync::mpsc::channel();
            self.ui.cover_rx = Some(rx);
            self.ui.cover_loading = Some(uri.clone());
            self.ui.cover_uri = uri.clone();
            std::thread::spawn(move || {
                let art = caly_artwork::load(&uri, &cache);
                let _ = tx.send(art);
            });
        }
    }

    fn handle_key(&mut self, key: KeyEvent) -> std::io::Result<bool> {
        if key.modifiers.contains(KeyModifiers::CONTROL) && key.code == KeyCode::Char('c') {
            return Ok(true);
        }
        let wants_focus_switch = key.code == KeyCode::Tab
            || (key.modifiers.contains(KeyModifiers::CONTROL) && key.code == KeyCode::Char('w'));
        if wants_focus_switch && self.ui.mode == Mode::Queue && self.ui.show_browser {
            self.ui.focus = match self.ui.focus {
                Focus::Main => Focus::Browser,
                Focus::Browser => Focus::Main,
            };
            return Ok(false);
        }
        match self.ui.mode {
            Mode::Input => self.handle_input_key(key),
            Mode::Help => self.handle_help_key(key),
            Mode::SignalFlow => self.handle_signal_flow_key(key),
            Mode::Queue if self.ui.focus == Focus::Browser => self.handle_browser_key(key),
            Mode::Queue => self.handle_queue_key(key),
        }
    }

    fn handle_signal_flow_key(&mut self, key: KeyEvent) -> std::io::Result<bool> {
        match key.code {
            KeyCode::Esc | KeyCode::Char('q') | KeyCode::Char('i') | KeyCode::Char('?') => {
                self.ui.mode = Mode::Queue;
            }
            KeyCode::Down | KeyCode::Char('j') => {
                self.ui.help_scroll = self.ui.help_scroll.saturating_add(2);
            }
            KeyCode::Up | KeyCode::Char('k') => {
                self.ui.help_scroll = self.ui.help_scroll.saturating_sub(2);
            }
            _ => {}
        }
        Ok(false)
    }

    fn handle_input_key(&mut self, key: KeyEvent) -> std::io::Result<bool> {
        let snap = self.engine.snapshot();
        let query = self.ui.input.to_lowercase();
        let matches_count = snap
            .queue_titles
            .iter()
            .filter(|t| query.is_empty() || t.to_lowercase().contains(&query))
            .count();

        match key.code {
            KeyCode::Esc => {
                self.ui.mode = Mode::Queue;
                self.ui.status.clear();
            }
            KeyCode::Down | KeyCode::Char('j')
                if key.modifiers.contains(KeyModifiers::CONTROL)
                    || self.ui.input_kind == InputKind::QueueFilter =>
            {
                if matches_count > 0 {
                    self.ui.telescope_sel = (self.ui.telescope_sel + 1).min(matches_count - 1);
                }
            }
            KeyCode::Up | KeyCode::Char('k')
                if key.modifiers.contains(KeyModifiers::CONTROL)
                    || self.ui.input_kind == InputKind::QueueFilter =>
            {
                self.ui.telescope_sel = self.ui.telescope_sel.saturating_sub(1);
            }
            KeyCode::Enter => {
                let value = self.ui.input.trim().to_string();
                match self.ui.input_kind {
                    InputKind::AddPath => {
                        if !value.is_empty() {
                            let tracks = vec![caly_core::queue::Track::from_uri(
                                caly_core::queue::TrackId(0),
                                value.clone(),
                            )];
                            self.engine.enqueue(tracks, true);
                            self.ui.status = format!("{} Enqueued: {value}", icon::PLAY);
                        }
                    }
                    InputKind::QueueFilter => {
                        let matched_indices: Vec<usize> = snap
                            .queue_titles
                            .iter()
                            .enumerate()
                            .filter(|(_, t)| query.is_empty() || t.to_lowercase().contains(&query))
                            .map(|(i, _)| i)
                            .collect();
                        if let Some(&target_idx) = matched_indices.get(self.ui.telescope_sel) {
                            self.ui.list.select(Some(target_idx));
                            self.engine.send(Control::PlayIndex(target_idx));
                            self.ui.status = format!("{} Jumped to track #{target_idx}", icon::PLAY);
                        }
                        self.ui.filter = value;
                    }
                    InputKind::BrowserFilter => {
                        if let Some(b) = &mut self.ui.browser {
                            b.set_filter(value.clone());
                            self.ui.status = format!("{} File filter: {value}", icon::SEARCH);
                        }
                    }
                }
                self.ui.input.clear();
                self.ui.mode = Mode::Queue;
                self.ui.last_render = Instant::now() - TICK;
            }
            KeyCode::Char(c) => {
                self.ui.input.push(c);
                self.ui.telescope_sel = 0;
            }
            KeyCode::Backspace => {
                self.ui.input.pop();
                self.ui.telescope_sel = 0;
            }
            _ => {}
        }
        Ok(false)
    }

    fn handle_browser_key(&mut self, key: KeyEvent) -> std::io::Result<bool> {
        let Some(browser) = &mut self.ui.browser else {
            self.ui.focus = Focus::Main;
            return Ok(false);
        };
        let engine = &self.engine;
        match key.code {
            KeyCode::Down | KeyCode::Char('j') => browser.move_sel(1),
            KeyCode::Up | KeyCode::Char('k') => browser.move_sel(-1),
            KeyCode::Char('g') => browser.jump(true),
            KeyCode::Char('G') => browser.jump(false),
            KeyCode::PageDown | KeyCode::Char('d') if key.modifiers.contains(KeyModifiers::CONTROL) => {
                browser.move_sel(10);
            }
            KeyCode::PageUp | KeyCode::Char('u') if key.modifiers.contains(KeyModifiers::CONTROL) => {
                browser.move_sel(-10);
            }
            KeyCode::Left | KeyCode::Char('h') | KeyCode::Backspace => {
                browser.go_up();
            }
            KeyCode::Enter | KeyCode::Char('l') | KeyCode::Right => {
                if browser.enter_selected() {
                } else if let Some(t) = browser.selected().filter(|e| !e.is_dir) {
                    let track = caly_core::queue::Track::from_uri(
                        caly_core::queue::TrackId(0),
                        t.path.to_string_lossy().into_owned(),
                    );
                    engine.enqueue(vec![track], true);
                    self.ui.status = format!("{} Playing {}", icon::PLAY, t.name);
                }
            }
            KeyCode::Char('a') => {
                let paths = browser.selected_paths();
                let n = paths.len();
                if n > 0 {
                    let tracks = paths
                        .into_iter()
                        .map(|p| {
                            caly_core::queue::Track::from_uri(
                                caly_core::queue::TrackId(0),
                                p.to_string_lossy().into_owned(),
                            )
                        })
                        .collect();
                    engine.enqueue(tracks, false);
                    self.ui.status = format!("Added {n} item(s) to queue");
                }
            }
            KeyCode::Char('.') => {
                browser.toggle_hidden();
                self.ui.status.clone_from(&if browser.show_hidden() {
                    "Hidden files visible".into()
                } else {
                    "Hidden files hidden".into()
                });
            }
            KeyCode::Char('/') => {
                self.ui.mode = Mode::Input;
                self.ui.input_kind = InputKind::BrowserFilter;
                self.ui.input_label = format!(" {} Search files > ", icon::SEARCH);
                self.ui.input.clear();
            }
            KeyCode::Char('r') => {
                browser.refresh();
                self.ui.status = "Refreshed explorer".into();
            }
            KeyCode::Char('+') | KeyCode::Char('=') => {
                self.ui.browser_width = (self.ui.browser_width + 4).min(60);
            }
            KeyCode::Char('-') => {
                self.ui.browser_width = self.ui.browser_width.saturating_sub(4).max(20);
            }
            KeyCode::Char('f') => {
                self.toggle_browser();
            }
            KeyCode::Esc | KeyCode::Char('q') => {
                self.ui.focus = Focus::Main;
            }
            _ => {}
        }
        Ok(false)
    }

    fn handle_help_key(&mut self, key: KeyEvent) -> std::io::Result<bool> {
        match key.code {
            KeyCode::Esc | KeyCode::Char('q') | KeyCode::Char('?') => {
                self.ui.mode = Mode::Queue;
            }
            KeyCode::Down | KeyCode::Char('j') => {
                self.ui.help_scroll = self.ui.help_scroll.saturating_add(3);
            }
            KeyCode::Up | KeyCode::Char('k') => {
                self.ui.help_scroll = self.ui.help_scroll.saturating_sub(3);
            }
            _ => {}
        }
        Ok(false)
    }

    fn handle_queue_key(&mut self, key: KeyEvent) -> std::io::Result<bool> {
        let snap = self.engine.snapshot();
        let len = snap.queue_len;
        let sel = self.ui.list.selected();
        match key.code {
            KeyCode::Char('q') => return Ok(true),
            KeyCode::Char('?') => {
                self.ui.mode = Mode::Help;
                self.ui.help_scroll = 0;
                return Ok(false);
            }
            KeyCode::Char('i') => {
                self.ui.mode = Mode::SignalFlow;
                self.ui.help_scroll = 0;
                return Ok(false);
            }
            KeyCode::Down | KeyCode::Char('j') => {
                let next = sel
                    .unwrap_or(0)
                    .saturating_add(1)
                    .min(len.saturating_sub(1));
                self.ui.list.select(Some(next));
            }
            KeyCode::Up | KeyCode::Char('k') => {
                let prev = sel.unwrap_or(0).saturating_sub(1);
                self.ui.list.select(Some(prev));
            }
            KeyCode::Char('g') => {
                self.ui.list.select(Some(0));
            }
            KeyCode::Char('G') => {
                if len > 0 {
                    self.ui.list.select(Some(len - 1));
                }
            }
            KeyCode::Char('d') if key.modifiers.contains(KeyModifiers::CONTROL) => {
                let next = sel.unwrap_or(0).saturating_add(8).min(len.saturating_sub(1));
                self.ui.list.select(Some(next));
            }
            KeyCode::Char('u') if key.modifiers.contains(KeyModifiers::CONTROL) => {
                let prev = sel.unwrap_or(0).saturating_sub(8);
                self.ui.list.select(Some(prev));
            }
            KeyCode::Char('J') => {
                if let Some(i) = sel {
                    if i + 1 < len {
                        self.engine.send(Control::Move(i, i + 1));
                        self.ui.list.select(Some(i + 1));
                    }
                }
            }
            KeyCode::Char('K') => {
                if let Some(i) = sel {
                    if i > 0 {
                        self.engine.send(Control::Move(i, i - 1));
                        self.ui.list.select(Some(i - 1));
                    }
                }
            }
            KeyCode::Enter => {
                if let Some(i) = sel {
                    if i < len {
                        self.engine.send(Control::PlayIndex(i));
                    }
                }
            }
            KeyCode::Char(' ') => self.engine.send(Control::TogglePause),
            KeyCode::Char('s') => self.engine.send(Control::Stop),
            KeyCode::Char('n') => self.engine.send(Control::Next),
            KeyCode::Char('p') => self.engine.send(Control::Prev),
            // Seeking forward / backward (5s / 30s)
            KeyCode::Left | KeyCode::Char('h') => {
                let cur = snap.position.position;
                let target = cur.saturating_sub(Duration::from_secs(5));
                self.engine.send(Control::Seek(target));
                self.ui.status = format!("󰒮 Seek -5s ({})", format_time(target));
            }
            KeyCode::Right | KeyCode::Char('l') => {
                let cur = snap.position.position;
                let target = cur + Duration::from_secs(5);
                self.engine.send(Control::Seek(target));
                self.ui.status = format!("󰒭 Seek +5s ({})", format_time(target));
            }
            KeyCode::Char('H') => {
                let cur = snap.position.position;
                let target = cur.saturating_sub(Duration::from_secs(30));
                self.engine.send(Control::Seek(target));
                self.ui.status = format!("󰒮 Seek -30s ({})", format_time(target));
            }
            KeyCode::Char('L') => {
                let cur = snap.position.position;
                let target = cur + Duration::from_secs(30);
                self.engine.send(Control::Seek(target));
                self.ui.status = format!("󰒭 Seek +30s ({})", format_time(target));
            }
            KeyCode::Char('+') | KeyCode::Char('=') => {
                self.bump_volume(snap.volume, 1.0);
            }
            KeyCode::Char('-') => {
                self.bump_volume(snap.volume, -1.0);
            }
            KeyCode::Char('r') => {
                let next = match snap.repeat {
                    RepeatMode::Off => RepeatMode::All,
                    RepeatMode::All => RepeatMode::One,
                    RepeatMode::One => RepeatMode::Off,
                };
                self.engine.send(Control::SetRepeat(next));
            }
            KeyCode::Char('x') => self.engine.send(Control::ToggleShuffle),
            KeyCode::Char('d') => {
                if let Some(i) = sel {
                    self.engine.send(Control::Remove(i));
                }
            }
            KeyCode::Char('a') => {
                self.ui.mode = Mode::Input;
                self.ui.input_kind = InputKind::AddPath;
                self.ui.input_label = format!(" {} Add Path/URL > ", icon::PLAY);
                self.ui.input.clear();
            }
            KeyCode::Char('/') => {
                self.ui.mode = Mode::Input;
                self.ui.input_kind = InputKind::QueueFilter;
                self.ui.input_label = format!(" {} Telescope Search > ", icon::SEARCH);
                self.ui.input.clear();
                self.ui.telescope_sel = 0;
            }
            KeyCode::Char('f') => {
                self.toggle_browser();
            }
            _ => {}
        }
        Ok(false)
    }

    fn handle_mouse(&mut self, m: MouseEvent) -> std::io::Result<bool> {
        if self.ui.mode == Mode::Help || self.ui.mode == Mode::SignalFlow {
            self.ui.mode = Mode::Queue;
            self.ui.last_render = Instant::now();
            return Ok(false);
        }
        if self.ui.mode != Mode::Queue {
            return Ok(false);
        }
        if matches!(
            m.kind,
            MouseEventKind::ScrollUp | MouseEventKind::ScrollDown
        ) {
            let d = if matches!(m.kind, MouseEventKind::ScrollUp) {
                -1isize
            } else {
                1isize
            };
            if self.ui.focus == Focus::Browser {
                if let Some(b) = &mut self.ui.browser {
                    b.move_sel(d);
                }
            } else {
                let len = self.engine.snapshot().queue_len;
                let sel = self.ui.list.selected().unwrap_or(0);
                let next = if d > 0 {
                    sel.saturating_add(1).min(len.saturating_sub(1))
                } else {
                    sel.saturating_sub(1)
                };
                self.ui.list.select(Some(next));
            }
            self.ui.last_render = Instant::now();
            return Ok(false);
        }
        if !matches!(m.kind, MouseEventKind::Down(MouseButton::Left)) {
            return Ok(false);
        }
        let Some(fr) = self.ui.frame else {
            return Ok(false);
        };
        let now = Instant::now();
        let dbl = self
            .ui
            .last_click
            .map(|(t, c, r)| now - t < Duration::from_millis(400) && c == m.column && r == m.row)
            .unwrap_or(false);
        self.ui.last_click = Some((now, m.column, m.row));
        let (x, y) = (m.column as i32, m.row as i32);
        let in_rect = |r: Rect| {
            x >= r.x as i32
                && x < (r.x + r.width) as i32
                && y >= r.y as i32
                && y < (r.y + r.height) as i32
        };
        if let Some(binner) = fr.browser_inner {
            if in_rect(binner) {
                self.ui.focus = Focus::Browser;
                let row = (y - binner.y as i32).max(0) as usize + fr.browser_offset;
                if let Some(b) = &mut self.ui.browser {
                    b.select_visible(row);
                }
                if dbl {
                    self.browser_activate();
                }
                self.ui.last_render = Instant::now();
                return Ok(false);
            }
        }
        if in_rect(fr.queue_inner) {
            self.ui.focus = Focus::Main;
            let row = (y - fr.queue_inner.y as i32).max(0) as usize + fr.queue_offset;
            if let Some(&real) = self.ui.queue_row_map.get(row) {
                self.ui.list.select(Some(real));
                if dbl {
                    self.engine.send(Control::PlayIndex(real));
                }
            }
            self.ui.last_render = Instant::now();
            return Ok(false);
        }
        if in_rect(fr.main) {
            self.ui.focus = Focus::Main;
            self.ui.last_render = Instant::now();
        }
        Ok(false)
    }

    fn browser_activate(&mut self) {
        let engine = &self.engine;
        let Some(browser) = &mut self.ui.browser else {
            return;
        };
        if browser.enter_selected() {
            return;
        }
        if let Some(t) = browser.selected().filter(|e| !e.is_dir) {
            let track = caly_core::queue::Track::from_uri(
                caly_core::queue::TrackId(0),
                t.path.to_string_lossy().into_owned(),
            );
            engine.enqueue(vec![track], true);
            self.ui.status = format!("{} Playing {}", icon::PLAY, t.name);
        }
    }

    fn bump_volume(&mut self, current: f32, dir: f32) {
        let base = self.ui.vol_target.unwrap_or(current);
        let target = volume_step(base, dir, self.settings.volume_percent);
        self.ui.vol_target = Some(target);
        self.engine.send(Control::SetVolume(target));
    }

    fn toggle_browser(&mut self) {
        if self.ui.show_browser {
            self.ui.show_browser = false;
            if self.ui.focus == Focus::Browser {
                self.ui.focus = Focus::Main;
            }
            return;
        }
        if self.ui.browser.is_none() {
            let exts = browser::DEFAULT_EXTS
                .iter()
                .map(|s| s.to_string())
                .collect::<Vec<_>>();
            self.ui.browser = Some(browser::BrowserState::new(
                browser::BrowserState::music_or_home(),
                &exts,
            ));
        }
        self.ui.browser_list = ListState::default();
        self.ui.show_browser = true;
        self.ui.focus = Focus::Browser;
        self.ui.status.clear();
    }
}

// ---------------------------------------------------------------------------
// Rendering Layer
// ---------------------------------------------------------------------------

fn draw(f: &mut Frame<'_>, ui: &mut UiState, engine: &Engine) {
    let snap = engine.snapshot();
    let area = f.area();
    ui.frame = Some(FrameRects::default());

    let main_area = if ui.show_browser && ui.browser.is_some() {
        let w = ui.browser_width.min(area.width.saturating_sub(34).max(24));
        let chunks = Layout::horizontal([Constraint::Length(w), Constraint::Min(0)]).split(area);
        if let Some(fr) = ui.frame.as_mut() {
            fr.browser = Some(chunks[0]);
        }
        draw_browser(f, chunks[0], ui);
        chunks[1]
    } else {
        area
    };

    if let Some(fr) = ui.frame.as_mut() {
        fr.main = main_area;
    }
    draw_main(f, main_area, ui, &snap);

    if ui.mode == Mode::Input && ui.input_kind == InputKind::QueueFilter {
        draw_telescope_modal(f, area, ui, &snap);
    } else if ui.mode == Mode::Input {
        draw_simple_input(f, area, ui);
    } else if ui.mode == Mode::Help {
        draw_which_key_modal(f, area, ui);
    } else if ui.mode == Mode::SignalFlow {
        draw_signal_flow_modal(f, area, ui, &snap);
    }
}

fn draw_main(f: &mut Frame<'_>, area: Rect, ui: &mut UiState, snap: &caly_engine::Snapshot) {
    let card_height = if area.height < 22 { 6 } else { 8 };
    let chunks = Layout::default()
        .direction(Direction::Vertical)
        .constraints([
            Constraint::Length(card_height),
            Constraint::Min(5),
            Constraint::Length(1),
        ])
        .split(area);

    draw_now_playing(f, chunks[0], ui, snap);
    draw_queue(f, chunks[1], ui, snap);
    draw_statusline(f, chunks[2], ui, snap);
}

fn draw_now_playing(f: &mut Frame<'_>, area: Rect, ui: &mut UiState, snap: &caly_engine::Snapshot) {
    let title = match &snap.current {
        Some(c) => match (&c.artist, &c.title) {
            (Some(a), t) => format!("{a} - {t}"),
            (None, t) => t.clone(),
        },
        None => "Caly - Ready to play".to_string(),
    };

    let (state_symbol, state_style) = match snap.state {
        PlayState::Playing => (format!("{} PLAYING", icon::PLAY), Style::new().fg(color::ACCENT_GREEN).add_modifier(Modifier::BOLD)),
        PlayState::Paused => (format!("{} PAUSED", icon::PAUSE), Style::new().fg(color::ACCENT_YELLOW).add_modifier(Modifier::BOLD)),
        PlayState::Stopped => (format!("{} STOPPED", icon::STOP), Style::new().fg(color::MUTED)),
    };

    let (hifi_badge, hifi_style) = if snap.is_bit_perfect {
        (format!("{} BIT-PERFECT", icon::BIT_PERFECT), Style::new().fg(color::ACCENT_GREEN).add_modifier(Modifier::BOLD))
    } else {
        (format!("{} HI-FI DSP", icon::FLOW), Style::new().fg(color::ACCENT_CYAN))
    };

    let border_color = if ui.focus == Focus::Main && snap.state == PlayState::Playing {
        color::ACCENT_CYAN
    } else {
        color::MUTED
    };

    let block = Block::default()
        .borders(Borders::ALL)
        .border_type(BorderType::Rounded)
        .border_style(Style::new().fg(border_color))
        .title(Line::from(vec![
            Span::styled(format!(" {} Now Playing ", icon::TRACK), Style::new().fg(color::ACCENT_CYAN).add_modifier(Modifier::BOLD)),
            Span::styled(format!(" [{state_symbol}] "), state_style),
            Span::styled(format!(" [{hifi_badge}] "), hifi_style),
        ]))
        .title_alignment(Alignment::Left);

    f.render_widget(block, area);

    let inner = Block::default().borders(Borders::ALL).inner(area);
    let content_area = {
        let areas = Layout::default()
            .direction(Direction::Vertical)
            .constraints([Constraint::Min(2), Constraint::Length(1)])
            .split(inner);
        areas[0]
    };

    let (cover_cw, has_art) = if content_area.width < 14 {
        (0, false)
    } else {
        match &ui.cover {
            Some(art) if art.width > 0 && art.height > 0 => {
                let cell_h = content_area.height as usize * 2;
                let fit_h = (art.height as usize).min(cell_h);
                let cw = (((fit_h as f64) * art.width as f64 / art.height as f64).round() as usize)
                    .clamp(6, 24)
                    .min(content_area.width as usize) as u16;
                (cw, true)
            }
            _ => (10, false),
        }
    };

    let text_area = Rect {
        x: content_area.x + cover_cw,
        y: content_area.y,
        width: content_area.width.saturating_sub(cover_cw).max(1),
        height: content_area.height,
    };

    let visualizer_line = render_visualizer(snap.state, snap.position.position.as_millis());

    let mut meta_lines = vec![
        Line::from(vec![
            Span::styled(format!("  {} ", icon::TRACK), Style::new().fg(color::ACCENT_PURPLE)),
            Span::styled(title, Style::new().fg(color::FG).add_modifier(Modifier::BOLD)),
            Span::raw("   "),
            visualizer_line.spans.into_iter().collect::<Vec<_>>().pop().unwrap_or_else(|| Span::raw("")),
        ]),
        Line::from(vec![
            Span::styled(format!("  {} ", icon::TIME), Style::new().fg(color::ACCENT_CYAN)),
            Span::styled(caly_core::progress::format_progress(&snap.position), Style::new().fg(color::FG)),
            Span::raw("   "),
            Span::styled(format!("{} ", icon::BIT_PERFECT), Style::new().fg(color::ACCENT_BLUE)),
            Span::styled(
                match (snap.backend, snap.source) {
                    (Some(b), Some(s)) => format!("{b} · {s}"),
                    (Some(b), None) => format!("{b}"),
                    _ => "idle".to_string(),
                },
                Style::new().fg(color::MUTED),
            ),
            Span::raw("   "),
            Span::styled(format!("{} ", icon::FLOW), Style::new().fg(color::ACCENT_GREEN)),
            Span::styled(snap.signal_flow.concise_path(), Style::new().fg(color::FG)),
            Span::raw("  "),
            Span::styled("[i: Flow Detail]", Style::new().fg(color::ACCENT_CYAN)),
        ]),
    ];

    if area.height >= 8 {
        let vol_line = format_volume_bar(snap.volume, 10);
        meta_lines.push(Line::from(vec![
            Span::raw("  "),
            vol_line.spans[0].clone(),
            vol_line.spans[1].clone(),
            vol_line.spans[2].clone(),
        ]));
    }

    f.render_widget(Paragraph::new(meta_lines), text_area);

    if cover_cw > 0 {
        if has_art {
            if let Some(art) = &ui.cover {
                draw_cover_image(
                    f.buffer_mut(),
                    art,
                    Rect {
                        x: content_area.x,
                        y: content_area.y,
                        width: cover_cw,
                        height: content_area.height,
                    },
                );
            }
        } else {
            draw_cover_placeholder(
                f,
                Rect {
                    x: content_area.x,
                    y: content_area.y,
                    width: cover_cw,
                    height: content_area.height,
                },
            );
        }
    }

    let ratio = snap.position.ratio();
    let bar_area = Rect {
        x: inner.x,
        y: inner.y + inner.height.saturating_sub(1),
        width: inner.width,
        height: 1,
    };

    f.render_widget(
        Gauge::default()
            .ratio(f64::from(ratio.clamp(0.0, 1.0)))
            .label(format!("{:.1}%", ratio * 100.0))
            .gauge_style(Style::new().fg(color::ACCENT_CYAN).bg(color::SURFACE)),
        bar_area,
    );
}

fn draw_queue(f: &mut Frame<'_>, area: Rect, ui: &mut UiState, snap: &caly_engine::Snapshot) {
    let dur_str = snap
        .queue_duration
        .map(|d| format!(" · {}", format_time(d)))
        .unwrap_or_default();
    let title = format!("  Queue ({} tracks{}) ", snap.queue_len, dur_str);

    let is_focused = ui.focus == Focus::Main;
    let block = Block::default()
        .borders(Borders::ALL)
        .border_type(BorderType::Rounded)
        .border_style(if is_focused {
            Style::new().fg(color::ACCENT_CYAN)
        } else {
            Style::new().fg(color::MUTED)
        })
        .title(title);

    ui.queue_row_map.clear();
    let items: Vec<ListItem<'static>> = queue_items(snap, &ui.filter, &mut ui.queue_row_map);
    let list = List::new(items)
        .block(block)
        .highlight_style(
            Style::new()
                .bg(color::ACTIVE_BG)
                .fg(color::ACCENT_CYAN)
                .add_modifier(Modifier::BOLD),
        )
        .highlight_symbol("▎ ");

    f.render_stateful_widget(list, area, &mut ui.list);
    if let Some(fr) = ui.frame.as_mut() {
        fr.queue_inner = Block::default().borders(Borders::ALL).inner(area);
        fr.queue_offset = ui.list.offset();
    }
}

fn queue_items(
    snap: &caly_engine::Snapshot,
    filter: &str,
    row_map: &mut Vec<usize>,
) -> Vec<ListItem<'static>> {
    let mut items = Vec::new();
    let (queue_len, cursor) = (snap.queue_len, snap.queue_cursor);
    let filter_l = filter.to_lowercase();
    let mut pos = 0usize;
    for (idx, title) in snap.queue_titles.iter().enumerate() {
        if idx >= queue_len {
            break;
        }
        let is_current = cursor == Some(idx);
        let mat = filter_l.is_empty() || title.to_lowercase().contains(&filter_l);
        pos += 1;
        if !mat {
            continue;
        }
        let (prefix, prefix_style) = if is_current {
            (format!("{} ", icon::PLAY), Style::new().fg(color::ACCENT_GREEN).add_modifier(Modifier::BOLD))
        } else {
            ("  ".into(), Style::new().fg(color::MUTED))
        };
        let style = if is_current {
            Style::new().fg(color::ACCENT_GREEN).add_modifier(Modifier::BOLD)
        } else {
            Style::new().fg(color::FG)
        };
        row_map.push(idx);
        items.push(ListItem::new(Line::from(vec![
            Span::styled(prefix, prefix_style),
            Span::styled(format!("{pos:>3}. "), Style::new().fg(color::MUTED)),
            Span::styled(title.clone(), style),
        ])));
    }
    if items.is_empty() {
        let hint = if filter_l.is_empty() {
            "  Queue is empty. Press 'a' to add a path or 'f' for explorer."
        } else {
            "  No matching tracks found."
        };
        items.push(ListItem::new(Line::from(Span::styled(
            hint,
            Style::new().fg(color::MUTED),
        ))));
    }
    items
}

fn draw_browser(f: &mut Frame<'_>, area: Rect, ui: &mut UiState) {
    let Some(browser) = &ui.browser else {
        return;
    };
    let mut title = format!(" {} Explorer: {} ", icon::FOLDER, browser.cwd().display());
    if browser.show_hidden() {
        title.push_str(" [hidden: on] ");
    }
    if !browser.filter().is_empty() {
        title.push_str(&format!(" [filter: {}] ", browser.filter()));
    }
    let focused = ui.focus == Focus::Browser;
    let block = Block::default()
        .borders(Borders::ALL)
        .border_type(BorderType::Rounded)
        .title(title)
        .border_style(if focused {
            Style::new().fg(color::ACCENT_PURPLE)
        } else {
            Style::new().fg(color::MUTED)
        });

    let vis = browser.visible_indices();
    let items: Vec<ListItem<'static>> = vis
        .iter()
        .map(|&i| {
            let e = &browser.entries()[i];
            let (ico, name, st) = if e.is_dir {
                (icon::FOLDER, e.display_name(), Style::new().fg(color::ACCENT_BLUE).add_modifier(Modifier::BOLD))
            } else if e.is_audio {
                (icon::TRACK, e.display_name(), Style::new().fg(color::ACCENT_CYAN))
            } else {
                (icon::FILE, e.name.clone(), Style::new().fg(color::MUTED))
            };
            let size = e.size_str();
            ListItem::new(Line::from(vec![
                Span::styled(format!("  {ico} "), st),
                Span::styled(name, st),
                Span::styled(
                    if size.is_empty() {
                        String::new()
                    } else {
                        format!("  {size}")
                    },
                    Style::new().fg(color::MUTED),
                ),
            ]))
        })
        .collect();

    let list = List::new(items)
        .block(block)
        .highlight_style(
            Style::new()
                .bg(color::ACTIVE_BG)
                .fg(color::ACCENT_PURPLE)
                .add_modifier(Modifier::BOLD),
        )
        .highlight_symbol("▎ ");

    ui.browser_list
        .select(Some(browser.selected_index_for_draw()));
    f.render_stateful_widget(list, area, &mut ui.browser_list);
    if let Some(fr) = ui.frame.as_mut() {
        fr.browser_inner = Some(Block::default().borders(Borders::ALL).inner(area));
        fr.browser_offset = ui.browser_list.offset();
    }
}

fn draw_statusline(f: &mut Frame<'_>, area: Rect, ui: &UiState, snap: &caly_engine::Snapshot) {
    let mode_str = match ui.mode {
        Mode::Queue if ui.focus == Focus::Browser => " FILES ",
        Mode::Queue => " NORMAL ",
        Mode::Input => " TELESCOPE ",
        Mode::Help => " WHICH-KEY ",
        Mode::SignalFlow => " SIGNAL-FLOW ",
    };

    let mode_color = match ui.mode {
        Mode::Queue if ui.focus == Focus::Browser => color::ACCENT_PURPLE,
        Mode::Queue => color::ACCENT_CYAN,
        Mode::Input => color::ACCENT_YELLOW,
        Mode::Help => color::ACCENT_GREEN,
        Mode::SignalFlow => color::ACCENT_CYAN,
    };

    let vol_pct = (snap.volume.clamp(0.0, 2.0) * 100.0).round() as u32;
    let repeat_str = match snap.repeat {
        RepeatMode::Off => "OFF",
        RepeatMode::All => "ALL",
        RepeatMode::One => "ONE",
    };
    let shuf_str = if snap.shuffle { "ON" } else { "OFF" };

    let line = Line::from(vec![
        Span::styled(
            mode_str,
            Style::new().bg(mode_color).fg(Color::Black).add_modifier(Modifier::BOLD),
        ),
        Span::raw(" "),
        Span::styled(
            if ui.show_browser { "Tab: Focus " } else { "f: Explorer " },
            Style::new().fg(color::MUTED),
        ),
        Span::styled("i: Flow ", Style::new().fg(color::ACCENT_CYAN)),
        Span::styled("?: Help ", Style::new().fg(color::MUTED)),
        if let Some(err) = &snap.last_error {
            Span::styled(format!(" 󰅚 {err} "), Style::new().fg(color::ACCENT_RED))
        } else if !ui.status.is_empty() {
            Span::styled(format!(" {} ", ui.status), Style::new().fg(color::ACCENT_YELLOW))
        } else {
            Span::raw("")
        },
        Span::styled("  |  ", Style::new().fg(color::MUTED)),
        Span::styled(format!("{} {repeat_str}  {} {shuf_str}", icon::REPEAT, icon::SHUFFLE), Style::new().fg(color::FG)),
        Span::styled("  |  ", Style::new().fg(color::MUTED)),
        Span::styled(format!("{} {vol_pct}%", icon::VOLUME), Style::new().fg(color::ACCENT_CYAN)),
        Span::styled("  |  ", Style::new().fg(color::MUTED)),
        Span::styled(
            if snap.is_bit_perfect { format!("{} Bit-Perfect", icon::BIT_PERFECT) } else { format!("{} Hi-Fi Flow", icon::FLOW) },
            if snap.is_bit_perfect {
                Style::new().bg(color::ACCENT_GREEN).fg(Color::Black).add_modifier(Modifier::BOLD)
            } else {
                Style::new().bg(color::SURFACE).fg(color::ACCENT_CYAN)
            },
        ),
        Span::raw(" "),
        Span::styled(
            format!("{} {}", icon::TIME, format_time(snap.position.position)),
            Style::new().fg(color::FG),
        ),
    ]);

    f.render_widget(Paragraph::new(line), area);
}

fn draw_signal_flow_modal(
    f: &mut Frame<'_>,
    area: Rect,
    ui: &mut UiState,
    snap: &caly_engine::Snapshot,
) {
    let modal_area = centered_rect(82, 80, area);
    f.render_widget(Clear, modal_area);

    let (border_color, banner_text, banner_style) = if snap.is_bit_perfect {
        (
            color::ACCENT_GREEN,
            format!(" {} 100% BIT-PERFECT DIRECT SIGNAL PATH (ZERO ALTERATION) ", icon::BIT_PERFECT),
            Style::new().bg(color::ACCENT_GREEN).fg(Color::Black).add_modifier(Modifier::BOLD),
        )
    } else {
        (
            color::ACCENT_CYAN,
            format!(" {} HIGH-FIDELITY DSP AUDIO FLOW (STUDIO SINC / BS.775) ", icon::FLOW),
            Style::new().bg(color::ACCENT_CYAN).fg(Color::Black).add_modifier(Modifier::BOLD),
        )
    };

    let block = Block::default()
        .borders(Borders::ALL)
        .border_type(BorderType::Rounded)
        .border_style(Style::new().fg(border_color))
        .title(format!(" {} Audio Processing Flow Pipeline (Press 'i' or 'Esc' to exit) ", icon::FLOW));

    let mut lines = Vec::new();
    lines.push(Line::raw(""));
    lines.push(Line::from(vec![Span::styled(banner_text, banner_style)]));
    lines.push(Line::raw(""));

    let steps = &snap.signal_flow.steps;
    if steps.is_empty() {
        lines.push(Line::from(Span::styled("  Idle - No active audio stream.", Style::new().fg(color::MUTED))));
    } else {
        for (idx, step) in steps.iter().enumerate() {
            let num = idx + 1;
            let (status_badge, status_style) = if step.is_passthrough {
                (" [Bit-Perfect] ", Style::new().fg(color::ACCENT_GREEN).add_modifier(Modifier::BOLD))
            } else {
                (" [DSP Active]  ", Style::new().fg(color::ACCENT_YELLOW).add_modifier(Modifier::BOLD))
            };

            lines.push(Line::from(vec![
                Span::styled(format!("  [{num}] "), Style::new().fg(color::ACCENT_CYAN).add_modifier(Modifier::BOLD)),
                Span::styled(format!("{:<15}", step.stage), Style::new().fg(color::FG).add_modifier(Modifier::BOLD)),
                Span::styled(format!("  {}  ", step.processor), Style::new().fg(color::ACCENT_PURPLE)),
                Span::styled(status_badge, status_style),
            ]));

            lines.push(Line::from(vec![
                Span::styled("      IN:  ", Style::new().fg(color::MUTED)),
                Span::styled(format!("{:<28}", step.input_spec), Style::new().fg(color::FG)),
                Span::styled(" OUT: ", Style::new().fg(color::MUTED)),
                Span::styled(&step.output_spec, Style::new().fg(color::FG)),
            ]));

            if !step.details.is_empty() {
                lines.push(Line::from(vec![
                    Span::styled("      NOTE: ", Style::new().fg(color::MUTED)),
                    Span::styled(&step.details, Style::new().fg(color::MUTED)),
                ]));
            }

            if idx + 1 < steps.len() {
                lines.push(Line::from(Span::styled("      │", Style::new().fg(color::MUTED))));
                lines.push(Line::from(Span::styled("      ▼", Style::new().fg(color::ACCENT_CYAN))));
            }
        }
    }

    f.render_widget(
        Paragraph::new(lines)
            .block(block)
            .scroll((ui.help_scroll, 0)),
        modal_area,
    );
}

fn draw_telescope_modal(
    f: &mut Frame<'_>,
    area: Rect,
    ui: &mut UiState,
    snap: &caly_engine::Snapshot,
) {
    let modal_area = centered_rect(65, 60, area);
    f.render_widget(Clear, modal_area);

    let query = ui.input.to_lowercase();
    let matches: Vec<(usize, &String)> = snap
        .queue_titles
        .iter()
        .enumerate()
        .filter(|(_, t)| query.is_empty() || t.to_lowercase().contains(&query))
        .collect();

    let chunks = Layout::default()
        .direction(Direction::Vertical)
        .constraints([Constraint::Length(3), Constraint::Min(3)])
        .split(modal_area);

    let prompt_block = Block::default()
        .borders(Borders::ALL)
        .border_type(BorderType::Rounded)
        .border_style(Style::new().fg(color::ACCENT_CYAN))
        .title(format!(
            " {} Telescope: Filter Queue (Matches: {}/{}) ",
            icon::SEARCH,
            matches.len(),
            snap.queue_len
        ));

    let prompt_text = format!(" {} > {}", icon::PROMPT, ui.input);
    f.render_widget(Paragraph::new(prompt_text).block(prompt_block), chunks[0]);

    let list_block = Block::default()
        .borders(Borders::ALL)
        .border_type(BorderType::Rounded)
        .border_style(Style::new().fg(color::MUTED))
        .title(" Results (<Enter>: Jump & Play, <C-j>/<C-k>: Select, <Esc>: Close) ");

    let items: Vec<ListItem<'static>> = matches
        .iter()
        .enumerate()
        .map(|(rank, (orig_idx, title))| {
            let is_sel = rank == ui.telescope_sel;
            let st = if is_sel {
                Style::new().fg(color::ACCENT_CYAN).add_modifier(Modifier::BOLD)
            } else {
                Style::new().fg(color::FG)
            };
            ListItem::new(Line::from(vec![
                Span::styled(format!("{:>3}. ", orig_idx + 1), Style::new().fg(color::MUTED)),
                Span::styled(title.to_string(), st),
            ]))
        })
        .collect();

    let mut state = ListState::default();
    if !matches.is_empty() {
        state.select(Some(ui.telescope_sel.min(matches.len() - 1)));
    }
    let list = List::new(items)
        .block(list_block)
        .highlight_style(Style::new().bg(color::ACTIVE_BG))
        .highlight_symbol("▎ ");

    f.render_stateful_widget(list, chunks[1], &mut state);
}

fn draw_simple_input(f: &mut Frame<'_>, area: Rect, ui: &mut UiState) {
    let modal_area = centered_rect(50, 20, area);
    f.render_widget(Clear, modal_area);

    let title = match ui.input_kind {
        InputKind::AddPath => format!(" {} Add Path / URL ", icon::PLAY),
        InputKind::QueueFilter => format!(" {} Filter Queue ", icon::SEARCH),
        InputKind::BrowserFilter => format!(" {} Filter Files ", icon::SEARCH),
    };

    let block = Block::default()
        .borders(Borders::ALL)
        .border_type(BorderType::Rounded)
        .title(title)
        .border_style(Style::new().fg(color::ACCENT_CYAN));

    let line = format!("{}{}", ui.input_label, ui.input);
    f.render_widget(
        Paragraph::new(line).block(block).wrap(Wrap { trim: false }),
        modal_area,
    );
}

fn draw_which_key_modal(f: &mut Frame<'_>, area: Rect, ui: &mut UiState) {
    let modal_area = centered_rect(76, 76, area);
    f.render_widget(Clear, modal_area);

    let block = Block::default()
        .borders(Borders::ALL)
        .border_type(BorderType::Rounded)
        .border_style(Style::new().fg(color::ACCENT_PURPLE))
        .title(" 󰌌 Which-Key: Caly Keybindings (Press Esc / q to close) ");

    let keybinds = vec![
        Line::from(Span::styled(format!("  {} Playback Controls", icon::PLAY), style::section_header())),
        Line::from(vec![
            Span::styled("    <Space>      ", style::key_tag()),
            Span::raw("Toggle Play / Pause        "),
            Span::styled("n / p        ", style::key_tag()),
            Span::raw("Next / Previous track"),
        ]),
        Line::from(vec![
            Span::styled("    s            ", style::key_tag()),
            Span::raw("Stop playback              "),
            Span::styled("+ / -        ", style::key_tag()),
            Span::raw("Volume Up / Down (1%/5%)"),
        ]),
        Line::from(vec![
            Span::styled("    r            ", style::key_tag()),
            Span::raw("Cycle Repeat (Off/All/One) "),
            Span::styled("x            ", style::key_tag()),
            Span::raw("Toggle Shuffle"),
        ]),
        Line::raw(""),
        Line::from(Span::styled(format!("  {} Navigation (Vim Motion)", icon::SHUFFLE), style::section_header())),
        Line::from(vec![
            Span::styled("    j / k        ", style::key_tag()),
            Span::raw("Move cursor down / up      "),
            Span::styled("g / G        ", style::key_tag()),
            Span::raw("Jump to Top / Bottom"),
        ]),
        Line::from(vec![
            Span::styled("    Ctrl-d / u   ", style::key_tag()),
            Span::raw("Scroll half page down / up "),
            Span::styled("<Enter>      ", style::key_tag()),
            Span::raw("Play selected track"),
        ]),
        Line::from(vec![
            Span::styled("    h / l (Left/Right) ", style::key_tag()),
            Span::raw("Seek -5s / +5s in track    "),
            Span::styled("H / L        ", style::key_tag()),
            Span::raw("Seek -30s / +30s"),
        ]),
        Line::raw(""),
        Line::from(Span::styled("   Queue Management (Vim Style)", style::section_header())),
        Line::from(vec![
            Span::styled("    J / K        ", style::key_tag()),
            Span::raw("Move track Down / Up       "),
            Span::styled("d            ", style::key_tag()),
            Span::raw("Delete / Remove track"),
        ]),
        Line::from(vec![
            Span::styled("    /            ", style::key_tag()),
            Span::raw("Telescope Fuzzy Filter     "),
            Span::styled("i            ", style::key_tag()),
            Span::raw("Signal Flow (Hi-Fi Path)"),
        ]),
        Line::from(vec![
            Span::styled("    a            ", style::key_tag()),
            Span::raw("Enqueue new Path or URL    "),
            Span::styled("q            ", style::key_tag()),
            Span::raw("Quit player"),
        ]),
        Line::raw(""),
        Line::from(Span::styled(format!("  {} File Explorer (Neo-Tree)", icon::FOLDER), style::section_header())),
        Line::from(vec![
            Span::styled("    f            ", style::key_tag()),
            Span::raw("Toggle Explorer sidebar    "),
            Span::styled("<Tab>/<C-w>  ", style::key_tag()),
            Span::raw("Switch Focus (Main <-> Tree)"),
        ]),
        Line::from(vec![
            Span::styled("    h / l        ", style::key_tag()),
            Span::raw("Parent dir / Open directory"),
            Span::styled("a            ", style::key_tag()),
            Span::raw("Add file/folder to queue"),
        ]),
        Line::from(vec![
            Span::styled("    .            ", style::key_tag()),
            Span::raw("Toggle hidden dotfiles     "),
            Span::styled("r            ", style::key_tag()),
            Span::raw("Refresh directory tree"),
        ]),
    ];

    f.render_widget(
        Paragraph::new(keybinds)
            .block(block)
            .scroll((ui.help_scroll, 0)),
        modal_area,
    );
}

fn centered_rect(percent_x: u16, percent_y: u16, r: Rect) -> Rect {
    let popup_layout = Layout::default()
        .direction(Direction::Vertical)
        .constraints([
            Constraint::Percentage((100 - percent_y) / 2),
            Constraint::Percentage(percent_y),
            Constraint::Percentage((100 - percent_y) / 2),
        ])
        .split(r);

    Layout::default()
        .direction(Direction::Horizontal)
        .constraints([
            Constraint::Percentage((100 - percent_x) / 2),
            Constraint::Percentage(percent_x),
            Constraint::Percentage((100 - percent_x) / 2),
        ])
        .split(popup_layout[1])[1]
}

fn artwork_cache_dir() -> Option<std::path::PathBuf> {
    if let Some(x) = std::env::var_os("XDG_CACHE_HOME").filter(|v| !v.is_empty()) {
        return Some(std::path::PathBuf::from(x).join("caly").join("artwork"));
    }
    std::env::var_os("HOME").filter(|v| !v.is_empty()).map(|h| {
        std::path::PathBuf::from(h)
            .join(".cache")
            .join("caly")
            .join("artwork")
    })
}

fn volume_step(current: f32, dir: f32, percent: bool) -> f32 {
    let (step, max) = if percent { (0.01, 1.0) } else { (0.05, 2.0) };
    (current + dir * step).clamp(0.0, max)
}

/// Convenience for headless mode.
pub fn headless_status(snap: &caly_engine::Snapshot) -> String {
    match (&snap.current, snap.state) {
        (Some(c), PlayState::Playing) => format!(
            "{} {}   {}   [{}]",
            icon::PLAY,
            c.title,
            caly_core::progress::format_progress(&snap.position),
            snap.output.clone().unwrap_or_default()
        ),
        (Some(c), PlayState::Paused) => format!("{} {}   {}", icon::PAUSE, c.title, snap.position),
        (None, _) => "caly: idle".to_string(),
        _ => String::new(),
    }
}
