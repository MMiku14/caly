//! Byte-stream reading abstraction.
use std::fmt;
use std::io::{self, Read, Seek, SeekFrom};
use std::path::{Path, PathBuf};

/// Result alias for transport operations.
pub type TransportResult<T> = std::result::Result<T, TransportError>;

/// Errors produced by [`Transport`] implementations.
#[derive(Debug, thiserror::Error)]
pub enum TransportError {
    /// I/O failure.
    #[error("I/O error: {0}")]
    Io(#[from] io::Error),
    /// Seeking is not supported.
    #[error("seek not supported")]
    Unsupported,
    /// Resource not found.
    #[error("not found: {0}")]
    NotFound(String),
    /// Generic failure with a message.
    #[error("transport error: {0}")]
    Other(String),
}

impl From<TransportError> for crate::CalyError {
    fn from(e: TransportError) -> Self {
        match e {
            TransportError::Io(i) => crate::CalyError::Io(i),
            other => crate::CalyError::Unavailable(other.to_string()),
        }
    }
}

/// What kind of source a transport represents.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash)]
pub enum TransportKind {
    /// A local filesystem file.
    File,
    /// An HTTP(S) URL.
    Http,
    /// An in-memory buffer.
    Memory,
    /// Anything else.
    Other,
}

impl fmt::Display for TransportKind {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        let s = match self {
            TransportKind::File => "file",
            TransportKind::Http => "http",
            TransportKind::Memory => "memory",
            TransportKind::Other => "other",
        };
        write!(f, "{s}")
    }
}

/// `true` when the URI looks like an HTTP(S) URL.
pub fn is_http_uri(uri: &str) -> bool {
    uri.starts_with("http://") || uri.starts_with("https://")
}

/// `true` when the URI looks like a local path or `file://` URL.
pub fn is_file_uri(uri: &str) -> bool {
    uri.starts_with("file://") || !is_http_uri(uri)
}

/// Strips a `file://` prefix if present.
pub fn file_uri_to_path(uri: &str) -> PathBuf {
    uri.strip_prefix("file://")
        .map(PathBuf::from)
        .unwrap_or_else(|| PathBuf::from(uri))
}

/// A seekable-byte-stream abstraction used by decoders.
pub trait Transport: Send {
    /// Reads up to `buf.len()` bytes.
    fn read(&mut self, buf: &mut [u8]) -> TransportResult<usize>;
    /// Seeks to `pos` bytes from the start.
    fn seek(&mut self, pos: u64) -> TransportResult<u64>;
    /// Total number of bytes if known.
    fn len(&self) -> Option<u64>;
    /// `true` when [`Transport::seek`] is supported.
    fn seekable(&self) -> bool {
        true
    }
    /// Human-readable origin.
    fn origin(&self) -> &str;
}

/// A [`Transport`] factory.
pub trait TransportFactory: Send + Sync {
    /// Kind of transport.
    fn kind(&self) -> TransportKind;
    /// `true` when this factory can open `uri`.
    fn can_open(&self, uri: &str) -> bool;
    /// Opens the URI.
    fn open(&self, uri: &str) -> TransportResult<Box<dyn Transport>>;
}

/// Local file transport.
pub struct FileTransport {
    file: io::BufReader<std::fs::File>,
    len: u64,
    path: PathBuf,
}

impl FileTransport {
    /// Opens a local file.
    pub fn open(uri: &str) -> TransportResult<Self> {
        let path = file_uri_to_path(uri);
        let file = std::fs::File::open(&path).map_err(|e| match e.kind() {
            io::ErrorKind::NotFound => TransportError::NotFound(uri.to_string()),
            _ => TransportError::Io(e),
        })?;
        let len = file.metadata().map(|m| m.len()).unwrap_or(0);
        Ok(Self {
            file: io::BufReader::new(file),
            len,
            path,
        })
    }

    /// Path served.
    pub fn path(&self) -> &Path {
        &self.path
    }
}

impl Transport for FileTransport {
    fn read(&mut self, buf: &mut [u8]) -> TransportResult<usize> {
        Ok(self.file.read(buf)?)
    }
    fn seek(&mut self, pos: u64) -> TransportResult<u64> {
        Ok(self.file.seek(SeekFrom::Start(pos))?)
    }
    fn len(&self) -> Option<u64> {
        Some(self.len)
    }
    fn seekable(&self) -> bool {
        true
    }
    fn origin(&self) -> &str {
        self.path.to_str().unwrap_or("<non-utf8 path>")
    }
}

/// In-memory transport.
pub struct CursorTransport {
    cursor: io::Cursor<Vec<u8>>,
    origin: String,
}

impl CursorTransport {
    /// Wraps buffer.
    pub fn new(data: Vec<u8>, origin: impl Into<String>) -> Self {
        Self {
            cursor: io::Cursor::new(data),
            origin: origin.into(),
        }
    }
}

impl Transport for CursorTransport {
    fn read(&mut self, buf: &mut [u8]) -> TransportResult<usize> {
        Ok(self.cursor.read(buf)?)
    }
    fn seek(&mut self, pos: u64) -> TransportResult<u64> {
        Ok(self.cursor.seek(SeekFrom::Start(pos))?)
    }
    fn len(&self) -> Option<u64> {
        Some(self.cursor.get_ref().len() as u64)
    }
    fn seekable(&self) -> bool {
        true
    }
    fn origin(&self) -> &str {
        &self.origin
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn cursor_roundtrip() {
        let mut t = CursorTransport::new(vec![1, 2, 3, 4, 5], "mem");
        let mut buf = [0u8; 3];
        assert_eq!(t.read(&mut buf).unwrap(), 3);
        assert_eq!(buf, [1, 2, 3]);
        assert_eq!(t.seek(1).unwrap(), 1);
    }
}
