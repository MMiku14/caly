//! Channel mixing: convert any canonical layout to mono/stereo output.
use crate::audio::AudioBuffer;
use crate::media::ChannelLayout;
use crate::CalyError;

const CENTER: f32 = std::f32::consts::FRAC_1_SQRT_2; // 0.70710677
const REAR: f32 = 0.5;

/// In-place channel mixer for whole buffers with SIMD-friendly fast-paths.
#[derive(Debug, Clone)]
pub struct Mixer {
    target: usize,
    scratch: Vec<f32>,
}

impl Mixer {
    /// Creates a mixer producing `target` channels per frame.
    pub fn new(target: usize) -> Self {
        debug_assert!(target == 1 || target == 2);
        Self {
            target,
            scratch: Vec::new(),
        }
    }

    /// Target channel count.
    pub fn target(&self) -> usize {
        self.target
    }

    /// Mixes an interleaved buffer into `dst`.
    pub fn mix(&mut self, input: &AudioBuffer, dst: &mut Vec<f32>) -> Result<usize, CalyError> {
        let src_ch = input.channels.get() as usize;
        if src_ch == self.target {
            dst.clear();
            dst.extend_from_slice(&input.samples);
            return Ok(input.frames());
        }
        self.mix_into(&input.samples, src_ch, &input.layout, dst)
    }

    /// Mixes raw interleaved samples into `dst` with optimized fast-paths.
    pub fn mix_into(
        &mut self,
        interleaved: &[f32],
        src_ch: usize,
        layout: &ChannelLayout,
        dst: &mut Vec<f32>,
    ) -> Result<usize, CalyError> {
        let dst_ch = self.target;
        if src_ch == 0 || dst_ch == 0 {
            return Err(CalyError::Config("channels must be non-zero".into()));
        }
        let frames = interleaved.len() / src_ch;
        dst.clear();
        dst.reserve(frames * dst_ch);

        // Fast-path 1: Direct passthrough
        if src_ch == dst_ch {
            dst.extend_from_slice(interleaved);
            return Ok(frames);
        }

        // Fast-path 2: Mono -> Stereo upmix
        if src_ch == 1 && dst_ch == 2 {
            for &s in interleaved {
                dst.push(s);
                dst.push(s);
            }
            return Ok(frames);
        }

        // Fast-path 3: Stereo -> Mono downmix
        if src_ch == 2 && dst_ch == 1 {
            for chunk in interleaved.chunks_exact(2) {
                dst.push((chunk[0] + chunk[1]) * 0.5);
            }
            return Ok(frames);
        }

        // Fast-path 4: Multichannel (e.g. 5.1 / 7.1) downmix
        // Pre-compute port indices ONCE for the entire buffer
        let fl_idx = layout.index_of(ChannelLayout::FRONT_LEFT);
        let fr_idx = layout.index_of(ChannelLayout::FRONT_RIGHT);
        let fc_idx = layout.index_of(ChannelLayout::FRONT_CENTER);
        let sl_idx = layout.index_of(ChannelLayout::SIDE_LEFT);
        let sr_idx = layout.index_of(ChannelLayout::SIDE_RIGHT);
        let bl_idx = layout.index_of(ChannelLayout::BACK_LEFT);
        let br_idx = layout.index_of(ChannelLayout::BACK_RIGHT);

        // Normalization scale factor for linear downmix to prevent clipping
        const NORM_FACTOR: f32 = 1.0 / (1.0 + CENTER + REAR);

        for chunk in interleaved.chunks_exact(src_ch) {
            let fl = fl_idx.and_then(|i| chunk.get(i)).copied().unwrap_or(0.0);
            let fr = fr_idx.and_then(|i| chunk.get(i)).copied().unwrap_or(0.0);
            let fc = fc_idx.and_then(|i| chunk.get(i)).copied().unwrap_or(0.0) * CENTER;
            let sl = sl_idx.and_then(|i| chunk.get(i)).copied().unwrap_or(0.0) * REAR;
            let sr = sr_idx.and_then(|i| chunk.get(i)).copied().unwrap_or(0.0) * REAR;
            let bl = bl_idx.and_then(|i| chunk.get(i)).copied().unwrap_or(0.0) * REAR;
            let br = br_idx.and_then(|i| chunk.get(i)).copied().unwrap_or(0.0) * REAR;

            let l = (fl + fc + sl + bl) * NORM_FACTOR;
            let r = (fr + fc + sr + br) * NORM_FACTOR;

            if dst_ch == 2 {
                dst.push(l);
                dst.push(r);
            } else {
                dst.push((l + r) * 0.5);
            }
        }

        Ok(frames)
    }
}

/// Converts one source frame to the target channel count.
pub fn mix_frame(
    src: &[f32],
    src_ch: usize,
    src_layout: &ChannelLayout,
    dst: &mut [f32],
    dst_ch: usize,
) -> Result<(), CalyError> {
    debug_assert_eq!(src.len() % src_ch, 0);
    debug_assert_eq!(dst.len() % dst_ch, 0);
    let mut mixer = Mixer::new(dst_ch);
    let mut out = Vec::with_capacity(dst_ch);
    mixer.mix_into(src, src_ch, src_layout, &mut out)?;
    dst.copy_from_slice(&out);
    Ok(())
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::media::{ChannelLayout, Channels};

    fn stereo(l: f32, r: f32) -> AudioBuffer {
        AudioBuffer {
            channels: Channels::STEREO,
            sample_rate: 48000,
            layout: ChannelLayout::STEREO,
            samples: vec![l, r],
        }
    }

    #[test]
    fn downmix_stereo_to_mono() {
        let mut m = Mixer::new(1);
        let mut out = Vec::new();
        let n = m.mix(&stereo(0.8, 0.2), &mut out).unwrap();
        assert_eq!(n, 1);
        assert_eq!(out, vec![0.5]);
    }

    #[test]
    fn upmix_mono_to_stereo() {
        let mono = AudioBuffer {
            channels: Channels::MONO,
            sample_rate: 48000,
            layout: ChannelLayout::MONO,
            samples: vec![0.7],
        };
        let mut m = Mixer::new(2);
        let mut out = Vec::new();
        m.mix(&mono, &mut out).unwrap();
        assert_eq!(out, vec![0.7, 0.7]);
    }

    #[test]
    fn surround_to_stereo_normalized_keeps_balance() {
        let src = AudioBuffer {
            channels: Channels::new(6).unwrap(),
            sample_rate: 48000,
            layout: ChannelLayout::FIVE_POINT_ONE,
            samples: vec![1.0, 1.0, 1.0, 0.0, 0.0, 0.0],
        };
        let mut m = Mixer::new(2);
        let mut out = Vec::new();
        m.mix(&src, &mut out).unwrap();
        assert!(out.iter().all(|s| s.abs() <= 1.0));
        assert!((out[0] - out[1]).abs() < 1e-6);
    }
}
