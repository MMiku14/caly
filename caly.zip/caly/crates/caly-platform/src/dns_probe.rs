//! Bounded DNS reachability probe.
//!
//! Sends a minimal DNS `A` query over UDP to a nameserver and classifies the
//! outcome. Used for diagnostics (per-nameserver health) without a full DNS
//! client library.

use std::{
    io,
    net::{IpAddr, SocketAddr, ToSocketAddrs, UdpSocket},
    time::Duration,
};

/// Default DNS service port when a nameserver has no explicit port.
pub const DNS_DEFAULT_PORT: u16 = 53;
/// Reasonable per-attempt read timeout.
pub const DNS_PROBE_TIMEOUT: Duration = Duration::from_secs(3);

/// Classified result of a single nameserver probe.
#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub enum DnsProbeOutcome {
    /// The resolver answered with a usable (no-error) response, optionally
    /// carrying the first A-record address from the answer section.
    Resolved(Option<IpAddr>),
    /// The resolver refused the query or returned an error rcode.
    Refused,
    /// No response arrived within the timeout.
    Timeout,
    /// The nameserver/domain input was invalid or the socket failed.
    Error,
}

/// Probes one nameserver for the given hostname.
pub fn probe_nameserver(nameserver: &str, domain: &str, timeout: Duration) -> DnsProbeOutcome {
    let Ok(address) = parse_nameserver(nameserver) else {
        return DnsProbeOutcome::Error;
    };
    let Ok(query) = build_query(domain) else {
        return DnsProbeOutcome::Error;
    };
    let Ok(socket) = UdpSocket::bind("0.0.0.0:0") else {
        return DnsProbeOutcome::Error;
    };
    if socket.set_read_timeout(Some(timeout)).is_err() || socket.connect(address).is_err() {
        return DnsProbeOutcome::Error;
    }
    if socket.send(&query).is_err() {
        return DnsProbeOutcome::Error;
    }
    let mut buffer = [0u8; 512];
    let Ok(read) = socket.recv(&mut buffer) else {
        return DnsProbeOutcome::Timeout;
    };
    classify_response(&query, &buffer[..read])
}

/// Parses `host` or `host:port` into a UDP socket address, defaulting to 53.
fn parse_nameserver(value: &str) -> io::Result<SocketAddr> {
    if let Ok(ip) = value.parse::<IpAddr>() {
        return Ok(SocketAddr::new(ip, DNS_DEFAULT_PORT));
    }
    value
        .to_socket_addrs()?
        .next()
        .ok_or_else(|| io::Error::new(io::ErrorKind::AddrNotAvailable, "no address"))
}

/// Interprets a response by matching the transaction id and reading the rcode.
fn classify_response(query: &[u8], response: &[u8]) -> DnsProbeOutcome {
    if response.len() < 12 || query.len() < 2 {
        return DnsProbeOutcome::Error;
    }
    if response[0] != query[0] || response[1] != query[1] {
        return DnsProbeOutcome::Error;
    }
    let rcode = response[3] & 0x0f;
    if rcode != 0 {
        return DnsProbeOutcome::Refused;
    }
    DnsProbeOutcome::Resolved(parse_first_a(response))
}

/// Extracts the first `A` record address from a DNS response answer section.
/// Returns `None` when there is no A answer or the encoding is unexpected.
fn parse_first_a(response: &[u8]) -> Option<IpAddr> {
    let ancount = u16::from_be_bytes([response[6], response[7]]);
    if ancount == 0 {
        return None;
    }
    // Skip the header (12) plus the question section.
    let mut offset = skip_question(response, 12)?;
    for _ in 0..ancount {
        offset = skip_name(response, offset)?;
        if offset + 10 > response.len() {
            return None;
        }
        let rtype = u16::from_be_bytes([response[offset], response[offset + 1]]);
        let rdlength = u16::from_be_bytes([response[offset + 8], response[offset + 9]]) as usize;
        let rdata = offset + 10;
        if rtype == 1 && rdlength == 4 && rdata + 4 <= response.len() {
            return Some(IpAddr::V4(std::net::Ipv4Addr::new(
                response[rdata],
                response[rdata + 1],
                response[rdata + 2],
                response[rdata + 3],
            )));
        }
        offset = rdata + rdlength;
    }
    None
}

/// Skips the DNS question section starting at `offset`.
fn skip_question(response: &[u8], offset: usize) -> Option<usize> {
    let after_name = skip_name(response, offset)?;
    // QTYPE (2) + QCLASS (2)
    after_name
        .checked_add(4)
        .filter(|end| *end <= response.len())
}

/// Skips a DNS name (labels or a compression pointer).
fn skip_name(response: &[u8], mut offset: usize) -> Option<usize> {
    loop {
        if offset >= response.len() {
            return None;
        }
        let length = response[offset];
        if length == 0 {
            return offset.checked_add(1);
        }
        if length & 0xc0 == 0xc0 {
            // Compression pointer: 2 bytes total, name ends.
            return offset.checked_add(2);
        }
        offset = offset.checked_add(1 + length as usize)?;
        if offset > response.len() {
            return None;
        }
    }
}

/// Builds a minimal DNS query (header + `A` question, IN class).
fn build_query(domain: &str) -> io::Result<Vec<u8>> {
    const TRANSACTION_ID: [u8; 2] = [0xAB, 0xCD];
    let mut query = Vec::with_capacity(64);
    query.extend_from_slice(&TRANSACTION_ID);
    query.extend_from_slice(&0x0100u16.to_be_bytes()); // recursion desired
    query.extend_from_slice(&1u16.to_be_bytes()); // QDCOUNT
    query.extend_from_slice(&[0, 0, 0, 0, 0, 0]); // AN/NS/AR counts
    for label in domain.split('.') {
        if label.is_empty() || label.len() > 63 {
            return Err(io::Error::new(io::ErrorKind::InvalidInput, "bad label"));
        }
        let length = u8::try_from(label.len())
            .map_err(|_| io::Error::new(io::ErrorKind::InvalidInput, "bad label"))?;
        query.push(length);
        query.extend_from_slice(label.as_bytes());
    }
    query.push(0);
    query.extend_from_slice(&1u16.to_be_bytes()); // QTYPE: A
    query.extend_from_slice(&1u16.to_be_bytes()); // QCLASS: IN
    Ok(query)
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn query_contains_question_for_domain() -> Result<(), std::io::Error> {
        let query = build_query("example.com")?;
        assert!(query.starts_with(&[0xAB, 0xCD]));
        assert_eq!(&query[12..25], b"\x07example\x03com\x00");
        Ok(())
    }

    #[test]
    fn bad_domain_label_is_rejected() {
        assert!(build_query("").is_err());
        assert!(build_query("a..b").is_err());
    }

    #[test]
    fn matching_transaction_classifies_resolved() -> Result<(), std::io::Error> {
        let query = build_query("example.com")?;
        let mut response = [0u8; 512];
        response[0] = query[0];
        response[1] = query[1];
        response[3] = 0x80; // QR + rcode 0
        assert_eq!(
            classify_response(&query, &response[..12]),
            DnsProbeOutcome::Resolved(None)
        );
        Ok(())
    }

    #[test]
    fn mismatched_transaction_is_an_error() -> Result<(), std::io::Error> {
        let query = build_query("example.com")?;
        let mut response = [0u8; 512];
        response[0] = 0x00;
        response[1] = 0x01;
        assert_eq!(
            classify_response(&query, &response[..12]),
            DnsProbeOutcome::Error
        );
        Ok(())
    }

    #[test]
    fn refused_rcode_is_classified() -> Result<(), std::io::Error> {
        let query = build_query("example.com")?;
        let mut response = [0u8; 512];
        response[0] = query[0];
        response[1] = query[1];
        response[3] = 0x85; // rcode 5 (REFUSED)
        assert_eq!(
            classify_response(&query, &response[..12]),
            DnsProbeOutcome::Refused
        );
        Ok(())
    }

    #[test]
    fn parses_first_a_record_address() -> Result<(), std::io::Error> {
        let query = build_query("example.com")?;
        // A minimal response: header + the echoed question + one A answer
        // (name pointer 0xc00c, type A, class IN, ttl 300, rdlength 4, 1.2.3.4).
        let mut response = vec![0u8; 512];
        response[..12].copy_from_slice(&query[..12]);
        response[2] = 0x80; // QR
        response[3] = 0; // rcode 0
        response[6] = 0;
        response[7] = 1; // ANCOUNT = 1
        // Copy the question section (echoed) so the answer lands after it.
        let qlen = 12 + query[12..].len();
        response[12..qlen].copy_from_slice(&query[12..]);
        response[qlen..qlen + 2].copy_from_slice(&[0xc0, 0x0c]); // NAME ptr
        response[qlen + 2..qlen + 4].copy_from_slice(&[0x00, 0x01]); // TYPE A
        response[qlen + 4..qlen + 6].copy_from_slice(&[0x00, 0x01]); // CLASS IN
        response[qlen + 6..qlen + 10].fill(0); // TTL
        response[qlen + 10..qlen + 12].copy_from_slice(&[0x00, 0x04]); // RDLENGTH
        response[qlen + 12..qlen + 16].copy_from_slice(&[1, 2, 3, 4]); // A data
        let classified = classify_response(&query, &response[..qlen + 16]);
        assert_eq!(
            classified,
            DnsProbeOutcome::Resolved(Some(IpAddr::V4(std::net::Ipv4Addr::new(1, 2, 3, 4))))
        );
        Ok(())
    }

    #[test]
    fn probe_reaches_a_local_resolver_over_udp() -> Result<(), std::io::Error> {
        let server = UdpSocket::bind("127.0.0.1:0")?;
        let address = server.local_addr()?;
        let handle = std::thread::spawn(move || {
            let mut buffer = [0u8; 512];
            if let Ok((_, peer)) = server.recv_from(&mut buffer) {
                let mut response = [0u8; 512];
                response[..12].copy_from_slice(&buffer[..12]); // echo header incl id
                response[2] = 0x80; // QR set, rcode 0
                response[3] = 0;
                let _ = server.send_to(&response[..12], peer);
            }
        });
        let outcome = probe_nameserver(&address.to_string(), "example.com", Duration::from_secs(2));
        let _ = handle.join();
        assert_eq!(outcome, DnsProbeOutcome::Resolved(None));
        Ok(())
    }
}
