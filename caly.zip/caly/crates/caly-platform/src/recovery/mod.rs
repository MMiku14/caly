//! Restore-first durable recovery state machine.
//!
//! A single generic, owner-only, atomic recovery store (`FileRecoveryStore<R>`)
//! serves the two concrete platform side effects — system proxy and TUN — via
//! typed records and typed restore-first startup gates. There is deliberately
//! no separate legacy recovery abstraction: both side effects share one store
//! implementation and one restore-first pattern.

mod store;
pub use store::{
    FileRecoveryStore, ProxyRecoveryRecord, ProxyRecoveryStore, RecoveryStore, RecoveryStoreError,
    TunRecoveryRecord, TunRecoveryStore,
};

use crate::PlatformFailure;

/// Durable recovery lifecycle.
#[derive(Clone, Copy, Debug, Eq, PartialEq, serde::Serialize, serde::Deserialize)]
pub enum RecoveryPhase {
    Prepared,
    Applied,
    Restoring,
}

/// Re-applies a durable proxy side effect to the desktop backend.
pub trait ProxyRecoveryAction {
    fn restore_proxy(&mut self, record: &ProxyRecoveryRecord) -> Result<(), PlatformFailure>;
}

/// Startup gate for the proxy side effect: re-apply a pending record before any
/// new core/platform mutation begins, then clear only the matching owner record.
pub fn proxy_restore_first(
    store: &dyn ProxyRecoveryStore,
    action: &mut impl ProxyRecoveryAction,
) -> Result<ProxyRecoveryOutcome, ProxyRecoveryFailure> {
    let Some(mut record) = store.load().map_err(ProxyRecoveryFailure::Load)? else {
        return Ok(ProxyRecoveryOutcome::NothingPending);
    };
    record.phase = RecoveryPhase::Restoring;
    store
        .persist(&record)
        .map_err(ProxyRecoveryFailure::MarkRestoring)?;
    action
        .restore_proxy(&record)
        .map_err(ProxyRecoveryFailure::Restore)?;
    store
        .clear_if_owner(record.owner_token)
        .map_err(ProxyRecoveryFailure::Clear)?;
    Ok(ProxyRecoveryOutcome::Restored)
}

/// Successful proxy recovery result.
#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub enum ProxyRecoveryOutcome {
    NothingPending,
    Restored,
}

/// Proxy recovery failure retaining the exact failed durability boundary.
#[derive(Clone, Debug, Eq, PartialEq)]
pub enum ProxyRecoveryFailure {
    Load(RecoveryStoreError),
    MarkRestoring(RecoveryStoreError),
    Restore(PlatformFailure),
    Clear(RecoveryStoreError),
}

/// Re-applies a durable TUN side effect to the platform backend.
pub trait TunRecoveryAction {
    fn restore_tun(&mut self, record: &TunRecoveryRecord) -> Result<(), PlatformFailure>;
}

/// Startup gate for the TUN side effect: re-engage a pending record before any
/// new mutation begins, then clear only the matching owner record.
pub fn tun_restore_first(
    store: &dyn TunRecoveryStore,
    action: &mut impl TunRecoveryAction,
) -> Result<ProxyRecoveryOutcome, TunRecoveryFailure> {
    let Some(mut record) = store.load().map_err(TunRecoveryFailure::Load)? else {
        return Ok(ProxyRecoveryOutcome::NothingPending);
    };
    record.phase = RecoveryPhase::Restoring;
    store
        .persist(&record)
        .map_err(TunRecoveryFailure::MarkRestoring)?;
    action
        .restore_tun(&record)
        .map_err(TunRecoveryFailure::Restore)?;
    store
        .clear_if_owner(record.owner_token)
        .map_err(TunRecoveryFailure::Clear)?;
    Ok(ProxyRecoveryOutcome::Restored)
}

/// TUN recovery failure retaining the exact failed durability boundary.
#[derive(Clone, Debug, Eq, PartialEq)]
pub enum TunRecoveryFailure {
    Load(RecoveryStoreError),
    MarkRestoring(RecoveryStoreError),
    Restore(PlatformFailure),
    Clear(RecoveryStoreError),
}

#[cfg(test)]
mod tests {
    use super::store::RecoveryStore as _;
    use super::*;
    use std::sync::Mutex;

    struct MemStore {
        record: Mutex<Option<ProxyRecoveryRecord>>,
    }

    impl MemStore {
        fn new(record: Option<ProxyRecoveryRecord>) -> Self {
            Self {
                record: Mutex::new(record),
            }
        }
    }

    impl super::store::RecoveryStore<ProxyRecoveryRecord> for MemStore {
        fn load(&self) -> Result<Option<ProxyRecoveryRecord>, RecoveryStoreError> {
            self.record
                .lock()
                .map_err(|_| RecoveryStoreError::Read("poisoned".into()))
                .map(|guard| guard.clone())
        }
        fn persist(&self, record: &ProxyRecoveryRecord) -> Result<(), RecoveryStoreError> {
            *self
                .record
                .lock()
                .map_err(|_| RecoveryStoreError::Write("poisoned".into()))? = Some(record.clone());
            Ok(())
        }
        fn clear_if_owner(&self, owner_token: [u8; 16]) -> Result<(), RecoveryStoreError> {
            let mut guard = self
                .record
                .lock()
                .map_err(|_| RecoveryStoreError::Remove("poisoned".into()))?;
            if guard.as_ref().is_some_and(|r| r.owner_token == owner_token) {
                *guard = None;
            }
            Ok(())
        }
        fn clear(&self) -> Result<(), RecoveryStoreError> {
            *self
                .record
                .lock()
                .map_err(|_| RecoveryStoreError::Remove("poisoned".into()))? = None;
            Ok(())
        }
    }
    impl ProxyRecoveryStore for MemStore {}

    struct ActionRecorder {
        restored: Mutex<bool>,
        fail_restore: bool,
    }

    impl ProxyRecoveryAction for ActionRecorder {
        fn restore_proxy(&mut self, _record: &ProxyRecoveryRecord) -> Result<(), PlatformFailure> {
            if self.fail_restore {
                return Err(PlatformFailure {
                    operation: bounded_pl("restore"),
                    resource: bounded_pl("proxy"),
                    message: bounded_pl("failed"),
                    suggested_action: bounded_pl("retry"),
                });
            }
            *self.restored.lock().map_err(|_| PlatformFailure {
                operation: bounded_pl("lock"),
                resource: bounded_pl("proxy"),
                message: bounded_pl("poisoned"),
                suggested_action: bounded_pl("retry"),
            })? = true;
            Ok(())
        }
    }

    fn bounded_pl<const MAX: usize>(value: &str) -> caly_domain::BoundedText<MAX> {
        caly_domain::BoundedText::new(value.to_owned()).unwrap()
    }

    fn pending_record(seed: u8) -> ProxyRecoveryRecord {
        ProxyRecoveryRecord {
            owner_token: [seed; 16],
            phase: RecoveryPhase::Applied,
            host: "127.0.0.1".to_owned(),
            port: 7890,
            enabled: true,
            original_mode: "manual".to_owned(),
            original_endpoint: String::new(),
        }
    }

    #[test]
    fn proxy_restore_first_with_nothing_pending() -> Result<(), ProxyRecoveryFailure> {
        let store = MemStore::new(None);
        let mut action = ActionRecorder {
            restored: Mutex::new(false),
            fail_restore: false,
        };
        assert_eq!(
            proxy_restore_first(&store, &mut action)?,
            ProxyRecoveryOutcome::NothingPending
        );
        Ok(())
    }

    #[test]
    fn proxy_restore_first_reapplies_and_clears() -> Result<(), ProxyRecoveryFailure> {
        let store = MemStore::new(Some(pending_record(1)));
        let mut action = ActionRecorder {
            restored: Mutex::new(false),
            fail_restore: false,
        };
        assert_eq!(
            proxy_restore_first(&store, &mut action)?,
            ProxyRecoveryOutcome::Restored
        );
        assert!(
            *action
                .restored
                .lock()
                .map_err(|_| ProxyRecoveryFailure::Clear(RecoveryStoreError::Read(
                    "poisoned".into()
                )))?
        );
        assert!(store.load().map_err(ProxyRecoveryFailure::Load)?.is_none());
        Ok(())
    }

    #[test]
    fn proxy_restore_first_failed_restore_keeps_record() {
        let store = MemStore::new(Some(pending_record(2)));
        let mut action = ActionRecorder {
            restored: Mutex::new(false),
            fail_restore: true,
        };
        assert!(matches!(
            proxy_restore_first(&store, &mut action),
            Err(ProxyRecoveryFailure::Restore(_))
        ));
        // The pending record must remain so a later startup can retry.
        assert!(store.load().is_ok());
    }
}
