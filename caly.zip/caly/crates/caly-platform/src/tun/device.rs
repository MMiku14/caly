//! Engage / restore pipeline for the Linux TUN backend.
//!
//! Round 31: the engage + restore orchestration
//! for the Linux TUN backend used to live in
//! `linux.rs` (an 871-line monolith that exceeded
//! the 400-line hard cap — S4.1 advisory). The
//! orchestration (and its `LinuxOwnedTun` handle)
//! extract into this file so the per-attempt /
//! per-batch runners (`escalate.rs`), the
//! shell-quoting helpers (`script.rs`), and the
//! failure shape (`capability.rs`) can all be
//! reused without dragging the 200-line
//! orchestration with them.

use std::path::Path;

use caly_domain::BoundedText;

use crate::command::LinuxCommandRunner;
use crate::PlatformFailure;

use super::escalate::{TunEscalation, run_ip, run_ip_sequence};
use super::script::tun_command;
use super::{OwnedTun, TunBackend, TunRequest};

type InterfaceName = BoundedText<64>;

/// Round 31: the `OwnedTun` handle for a Linux
/// TUN device. The pre-Round 31 inline struct
/// lived in `linux.rs` next to the engage
/// pipeline; the extraction keeps the handle
/// co-located with the engage / restore code
/// that owns it.
struct LinuxOwnedTun {
    interface: InterfaceName,
    runner: LinuxCommandRunner,
    escalation: TunEscalation,
}

/// Round 31: the Linux TUN backend entry point.
/// The pre-Round 31 impl block lived in
/// `linux.rs`; the extraction moves only the
/// engage pipeline (the platform-faithful
/// "adopt the held device" / "drop the stale
/// one" / "create fresh" state machine) to
/// this file.
pub struct LinuxTunBackend {
    runner: LinuxCommandRunner,
    escalation: TunEscalation,
}

impl Default for LinuxTunBackend {
    fn default() -> Self {
        Self {
            runner: LinuxCommandRunner,
            escalation: TunEscalation::default(),
        }
    }
}

impl LinuxTunBackend {
    /// Round 31: overrides the privilege-escalation
    /// policy for privileged `ip` commands. The
    /// pre-Round 31 inline `with_escalation`
    /// moved to this module unchanged.
    #[must_use]
    pub const fn with_escalation(mut self, escalation: TunEscalation) -> Self {
        self.escalation = escalation;
        self
    }
}

impl TunBackend for LinuxTunBackend {
    fn engage(&mut self, request: TunRequest) -> Result<Box<dyn OwnedTun>, PlatformFailure> {
        engage_with(&mut self.runner, self.escalation, request)
    }
}

impl OwnedTun for LinuxOwnedTun {
    fn interface(&self) -> &InterfaceName {
        &self.interface
    }

    fn restore(mut self: Box<Self>) -> Result<(), PlatformFailure> {
        restore_tun(&mut self.runner, self.escalation, self.interface.as_str())
    }
}

/// Round 31: the engage pipeline. The contract is
/// *ensure*, not *own*: the config apply that
/// precedes the platform engage already restarted
/// the core with a `tun` inbound, and the core
/// itself creates and configures the device. So an
/// interface that already exists is ADOPTED
/// (MTU/UP confirmed idempotently) rather than
/// deleted and recreated — deleting a device a live
/// process holds fails with EBUSY, and treating that
/// ready signal as an engage failure used to leave
/// the core hijacking traffic into a device the
/// platform layer did not track.
///
/// A *stale* interface (left behind by a crashed
/// daemon or an interrupted earlier engage) is still
/// dropped first: the delete succeeds when no
/// process holds the device, and the interface is
/// then created fresh.
///
/// Every `ip` command is tried directly first; when
/// the daemon lacks `CAP_NET_ADMIN` the remaining
/// sequence is retried as ONE escalated `sh -c`
/// batch (`pkexec`, then `sudo -n`), so the user is
/// prompted for the root password at most once per
/// engage instead of once per `ip` command.
pub(crate) fn engage_with(
    runner: &mut impl crate::command::CommandRunner,
    escalation: TunEscalation,
    request: TunRequest,
) -> Result<Box<dyn OwnedTun>, PlatformFailure> {
    let interface = request.interface.clone();
    let name = interface.as_str();
    let mtu = request.mtu;
    let ensure = || {
        vec![
            tun_command(vec!["link", "set", "dev", name, "mtu", &mtu.to_string()]),
            tun_command(vec!["link", "set", "dev", name, "up"]),
        ]
    };
    if interface_exists(name) {
        // Distinguish the two owners of an existing interface by probing the
        // delete DIRECTLY first (no escalation): EBUSY means a live process
        // (the core's tun inbound) holds the device — a ready signal that
        // must short-circuit before any pkexec/sudo attempt, so a held
        // device never triggers a pointless password prompt. Any other
        // direct failure is retried through the escalation chain; only when
        // the delete succeeds is the interface recreated fresh.
        let delete = vec!["tuntap", "del", "dev", name, "mode", "tun"];
        let arguments = super::script::build_arguments(&delete)?;
        let direct = super::escalate::attempt(runner, "ip", &[], &arguments, super::escalate::DIRECT_TIMEOUT);
        if direct.is_err()
            && !matches!(direct, Err(ref error) if is_busy_failure(error))
        {
            // Stale leftover that needs privileges (or a real failure): let
            // the escalation chain decide, keeping its clear error.
            run_ip(runner, escalation, delete)?;
        } else if direct.is_err() {
            // Held by the running core: adopt the device as-is. The idempotent
            // MTU/UP confirmation doubles as the readiness check — a held but
            // half-configured device fails here with a real error.
            run_ip_sequence(runner, escalation, &ensure())?;
            return Ok(Box::new(LinuxOwnedTun {
                interface,
                runner: LinuxCommandRunner,
                escalation,
            }));
        }
        // direct delete succeeded: stale interface removed, create fresh below.
    }
    let mut commands = vec![tun_command(vec![
        "tuntap",
        "add",
        "dev",
        name,
        "mode",
        "tun",
    ])];
    commands.extend(ensure());
    if let Err(error) = run_ip_sequence(runner, escalation, &commands) {
        // Best-effort cleanup of a partially applied engage. The cleanup MUST
        // use `TunEscalation::None` regardless of the original policy: a
        // failed engage that already prompted for the root password (or one
        // that failed to) must never prompt the user a second time for a
        // best-effort rollback. The previous implementation passed through the
        // caller's `escalation` argument, which contradicted the inline
        // "never another password prompt" comment and would have surfaced a
        // second polkit / sudo prompt on every failed engage.
        let _ = run_ip(
            runner,
            TunEscalation::None,
            vec!["tuntap", "del", "dev", name, "mode", "tun"],
        );
        return Err(error);
    }
    Ok(Box::new(LinuxOwnedTun {
        interface,
        runner: LinuxCommandRunner,
        escalation,
    }))
}

/// Round 31: deletes the TUN device, tolerating a
/// busy interface: when the core still holds the
/// device (restore raced the kernel restart) the
/// delete fails with EBUSY and the core itself
/// releases the interface on shutdown — that is a
/// successful restore, not an error. Every other
/// failure (permission, absent device) keeps its
/// original error.
pub(crate) fn restore_tun(
    runner: &mut impl crate::command::CommandRunner,
    escalation: TunEscalation,
    name: &str,
) -> Result<(), PlatformFailure> {
    match run_ip(
        runner,
        escalation,
        vec!["tuntap", "del", "dev", name, "mode", "tun"],
    ) {
        Err(error) if is_busy_failure(&error) => Ok(()),
        other => other,
    }
}

/// Round 31: whether a failed `ip` command signals
/// that the interface is held by a live process
/// ("Device or resource busy") rather than a
/// permission or environmental failure. A held
/// device is a ready signal during engage (the
/// core's tun inbound owns it) and a no-op during
/// restore (the core releases it on restart).
pub(crate) fn is_busy_failure(error: &PlatformFailure) -> bool {
    error.message.as_str().to_ascii_lowercase().contains("busy")
}

/// Round 31: whether a network interface with the
/// requested name already exists. `/sys/class/net`
/// reflects every interface the kernel knows about
/// (persist TUN devices included), so a leftover
/// `caly0` from a previous run is detected here
/// and removed before a fresh one is created.
pub(crate) fn interface_exists(name: &str) -> bool {
    Path::new("/sys/class/net").join(name).is_dir()
}

#[cfg(test)]
mod device_tests {
    //! Round 31: the engage / restore tests stay
    //! co-located with the orchestration so a
    //! future change to the "adopt / drop /
    //! create" state machine lands next to its
    //! tests. The escalation policy tests live
    //! in `escalate.rs`; the shell-quoting tests
    //! live in `script.rs`; the failure-shape
    //! tests live in `capability.rs`.

    use super::{engage_with, interface_exists, is_busy_failure, restore_tun};
    use crate::command::{CommandOutput, CommandResult, CommandRunner};
    use crate::PlatformFailure;
    use crate::tun::TunEscalation;
    use crate::tun::TunRequest;
    use caly_domain::BoundedText;
    use std::cell::RefCell;
    use std::rc::Rc;

    /// Records every command without executing
    /// anything, so stale-interface handling can
    /// be asserted safely (never touches a real
    /// device).
    #[derive(Clone, Default)]
    struct RecordingRunner {
        calls: Rc<RefCell<Vec<String>>>,
    }

    impl CommandRunner for RecordingRunner {
        fn run_bounded(
            &mut self,
            request: crate::command::CommandRequest,
        ) -> Result<CommandResult, PlatformFailure> {
            let mut line = request.executable.to_string_lossy().into_owned();
            for argument in &request.arguments {
                line.push(' ');
                line.push_str(argument.as_str());
            }
            self.calls.borrow_mut().push(line);
            Ok(CommandResult {
                exit_code: Some(0),
                stdout: CommandOutput::new(),
                stderr: CommandOutput::new(),
            })
        }
    }

    fn tun_request(name: &str) -> TunRequest {
        TunRequest {
            interface: BoundedText::new(name.to_owned()).unwrap_or_else(|_| std::process::abort()),
            mtu: 1400,
        }
    }

    #[test]
    fn interface_exists_detects_real_interfaces_only() {
        // `lo` always exists on Linux; a unique name never does.
        assert!(interface_exists("lo"));
        let unique = format!("caly-test-{}", std::process::id());
        assert!(!interface_exists(&unique));
    }

    #[test]
    fn engage_drops_stale_interface_before_creating_fresh() -> Result<(), String> {
        let mut runner = RecordingRunner::default();
        // `lo` exists, so engage must delete it first (recorded only; the mock
        // never executes anything) and then recreate + configure it.
        let _owned = engage_with(&mut runner, TunEscalation::None, tun_request("lo"))
            .map_err(|e| e.to_string())?;
        let calls = runner.calls.borrow();
        assert!(
            calls
                .first()
                .is_some_and(|line| line.contains("tuntap del dev lo")),
            "stale interface must be deleted first, got {calls:?}"
        );
        assert!(
            calls.iter().any(|line| line.contains("tuntap add dev lo")),
            "a fresh interface must then be created, got {calls:?}"
        );
        assert!(calls.len() >= 3, "add + mtu + up expected: {calls:?}");
        Ok(())
    }

    #[test]
    fn engage_without_stale_interface_goes_straight_to_add() -> Result<(), String> {
        let mut runner = RecordingRunner::default();
        let unique = format!("caly-test-{}", std::process::id());
        engage_with(&mut runner, TunEscalation::None, tun_request(&unique))
            .map_err(|e| e.to_string())?;
        let calls = runner.calls.borrow();
        assert!(
            calls
                .first()
                .is_some_and(|line| line.contains("tuntap add dev")),
            "no stale interface: the first command must be add, got {calls:?}"
        );
        Ok(())
    }

    /// A runner that fails every direct attempt
    /// (as a daemon without `CAP_NET_ADMIN`
    /// would) and records escalated calls.
    #[derive(Clone, Default)]
    struct EscalatingRunner {
        calls: Rc<RefCell<Vec<String>>>,
    }

    impl CommandRunner for EscalatingRunner {
        fn run_bounded(
            &mut self,
            request: crate::command::CommandRequest,
        ) -> Result<CommandResult, PlatformFailure> {
            let mut line = request.executable.to_string_lossy().into_owned();
            for argument in &request.arguments {
                line.push(' ');
                line.push_str(argument.as_str());
            }
            self.calls.borrow_mut().push(line);
            let escalated = request.executable.to_string_lossy() == "pkexec";
            Ok(CommandResult {
                exit_code: Some(i32::from(!escalated)),
                stdout: CommandOutput::new(),
                stderr: CommandOutput::new(),
            })
        }
    }

    #[test]
    fn engage_without_privileges_escalates_one_batch_not_per_command() -> Result<(), String> {
        let mut runner = EscalatingRunner::default();
        let unique = format!("caly-test-{}", std::process::id());
        engage_with(&mut runner, TunEscalation::Pkexec, tun_request(&unique))
            .map_err(|e| e.to_string())?;
        let calls = runner.calls.borrow();
        // Every direct `ip` attempt happened (and failed), then exactly ONE
        // escalated `sh -c` batch carries the whole sequence.
        let direct: Vec<&String> = calls
            .iter()
            .filter(|line| line.starts_with("ip "))
            .collect();
        let escalated: Vec<&String> = calls
            .iter()
            .filter(|line| line.starts_with("pkexec "))
            .collect();
        assert_eq!(
            escalated.len(),
            1,
            "one password prompt expected: {calls:?}"
        );
        assert!(
            escalated[0].contains("sh -c ip tuntap add dev ")
                && escalated[0].contains(" && ip link set dev "),
            "escalated batch must chain the remaining commands: {escalated:?}"
        );
        // The direct phase stops at the first failure (add), so exactly one
        // direct attempt precedes the single escalated batch.
        assert_eq!(
            direct.len(),
            1,
            "first direct attempt then one batch: {calls:?}"
        );
        Ok(())
    }

    #[test]
    fn engage_with_direct_privileges_never_escalates() -> Result<(), String> {
        let mut runner = RecordingRunner::default();
        let unique = format!("caly-test-{}", std::process::id());
        engage_with(&mut runner, TunEscalation::Pkexec, tun_request(&unique))
            .map_err(|e| e.to_string())?;
        let calls = runner.calls.borrow();
        assert!(
            calls.iter().all(|line| line.starts_with("ip ")),
            "no escalation when direct commands succeed: {calls:?}"
        );
        assert_eq!(calls.len(), 3);
        Ok(())
    }

    /// Every escalation attempt must FAIL so
    /// the engage itself reports an error and
    /// rolls back. The pre-Round 31 inline
    /// shape propagated the caller's
    /// `escalation` argument into the cleanup
    /// `run_ip` call, so a failed engage would
    /// have surfaced a SECOND password prompt
    /// for the best-effort rollback. The
    /// Round 31 cleanup is a direct `ip tuntap
    /// del` only, so the test pins the
    /// `pkexec` call count to exactly 1 (the
    /// failed engage batch) regardless of
    /// policy.
    #[derive(Clone, Default)]
    struct AlwaysFailRunner {
        calls: Rc<RefCell<Vec<String>>>,
    }

    impl CommandRunner for AlwaysFailRunner {
        fn run_bounded(
            &mut self,
            request: crate::command::CommandRequest,
        ) -> Result<CommandResult, PlatformFailure> {
            let mut line = request.executable.to_string_lossy().into_owned();
            for argument in &request.arguments {
                line.push(' ');
                line.push_str(argument.as_str());
            }
            self.calls.borrow_mut().push(line);
            Ok(CommandResult {
                exit_code: Some(1),
                stdout: CommandOutput::new(),
                stderr: CommandOutput::new(),
            })
        }
    }

    /// A runner whose `ip tuntap del` fails with
    /// EBUSY (stderr carries the kernel's "Device
    /// or resource busy") while every other
    /// command succeeds — the exact shape of a
    /// device held by the running core's tun
    /// inbound.
    #[derive(Clone, Default)]
    struct BusyDeleteRunner {
        calls: Rc<RefCell<Vec<String>>>,
    }

    impl CommandRunner for BusyDeleteRunner {
        fn run_bounded(
            &mut self,
            request: crate::command::CommandRequest,
        ) -> Result<CommandResult, PlatformFailure> {
            let mut line = request.executable.to_string_lossy().into_owned();
            for argument in &request.arguments {
                line.push(' ');
                line.push_str(argument.as_str());
            }
            let is_delete = line.contains("tuntap del dev");
            self.calls.borrow_mut().push(line);
            let busy = CommandOutput::try_from_vec(
                b"Cannot delete TUN device: Device or resource busy\n".to_vec(),
            )
            .unwrap_or_else(|_| CommandOutput::new());
            Ok(CommandResult {
                exit_code: Some(i32::from(is_delete)),
                stdout: CommandOutput::new(),
                stderr: if is_delete { busy } else { CommandOutput::new() },
            })
        }
    }

    /// The core's tun inbound created the
    /// device before the platform engage ran
    /// (config apply precedes SetTun). The
    /// engage must ADOPT the held device — no
    /// delete, no recreate, no escalation —
    /// and confirm MTU/UP idempotently instead
    /// of failing on the busy delete.
    #[test]
    fn engage_adopts_interface_held_by_core() -> Result<(), String> {
        let mut runner = BusyDeleteRunner::default();
        // `lo` always exists, so the engage probes the delete and sees EBUSY.
        let _owned = engage_with(&mut runner, TunEscalation::Pkexec, tun_request("lo"))
            .map_err(|e| e.to_string())?;
        let calls = runner.calls.borrow();
        assert!(
            !calls.iter().any(|line| line.contains("tuntap add dev lo")),
            "a held device must not be recreated: {calls:?}"
        );
        assert!(
            !calls.iter().any(|line| line.starts_with("pkexec ")),
            "EBUSY must short-circuit before any escalation prompt: {calls:?}"
        );
        assert!(
            calls.iter().any(|line| line.contains("link set dev lo mtu"))
                && calls.iter().any(|line| line.contains("link set dev lo up")),
            "adoption confirms MTU/UP idempotently: {calls:?}"
        );
        Ok(())
    }

    /// A stale interface (no holder) must still
    /// be dropped and recreated: the delete
    /// succeeds and the fresh-create path runs
    /// as before.
    #[test]
    fn restore_tolerates_busy_interface() -> Result<(), String> {
        let mut runner = BusyDeleteRunner::default();
        // `lo` is "held" from the runner's point of view; the core will
        // release it on restart, so a busy restore is a successful no-op.
        restore_tun(&mut runner, TunEscalation::None, "lo").map_err(|e| e.to_string())?;
        let calls = runner.calls.borrow();
        assert_eq!(calls.len(), 1, "one delete attempt: {calls:?}");
        assert!(calls[0].contains("tuntap del dev lo"));
        Ok(())
    }

    #[test]
    fn restore_propagates_non_busy_failures() {
        let mut runner = AlwaysFailRunner::default();
        let outcome = restore_tun(&mut runner, TunEscalation::None, "lo");
        assert!(outcome.is_err(), "a permission failure must not be swallowed");
        assert!(!matches!(outcome, Err(ref error) if is_busy_failure(error)));
    }

    /// Regression: a failed engage under any
    /// escalation policy must clean up with a
    /// direct `ip tuntap del` only — never a
    /// `pkexec` or `sudo -n` batch. The inline
    /// comment of the old implementation said
    /// "never another password prompt" but the
    /// call site passed the original
    /// `escalation` through, contradicting the
    /// comment.
    #[test]
    fn failed_engage_cleanup_never_escalates() -> Result<(), String> {
        let mut runner = AlwaysFailRunner::default();
        let unique = format!("caly-test-{}", std::process::id());
        // `Pkexec` is the most likely policy to
        // misbehave: every direct attempt
        // fails (no CAP_NET_ADMIN), then the
        // escalated batch also fails (mock
        // returns exit 1), so the engage
        // returns Err and the cleanup path
        // runs. The cleanup must not surface
        // another `pkexec`.
        let result = engage_with(&mut runner, TunEscalation::Pkexec, tun_request(&unique));
        if result.is_ok() {
            return Err("engage must fail when every attempt fails".to_owned());
        }
        let calls = runner.calls.borrow();
        let escalated: Vec<&String> = calls
            .iter()
            .filter(|line| line.starts_with("pkexec ") || line.starts_with("sudo "))
            .collect();
        if escalated.len() != 1 {
            return Err(format!(
                "exactly one escalated batch is allowed (the failed engage); \
                 the cleanup must not escalate again: {calls:?}"
            ));
        }
        // The cleanup command is the LAST one
        // in the call log and must start with
        // the bare `ip` executable.
        let cleanup = calls
            .iter()
            .rev()
            .find(|line| line.contains("tuntap del dev"));
        match cleanup {
            Some(line) if line.starts_with("ip ") => Ok(()),
            Some(line) => Err(format!(
                "cleanup must run direct `ip tuntap del`, got {line:?}"
            )),
            None => Err(format!(
                "cleanup `tuntap del` must be recorded: {calls:?}"
            )),
        }
    }
}
