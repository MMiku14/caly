//! Cross-platform infrastructure boundary.
//!
//! Concrete OS backends must live in this crate. Current modules define
//! truthful transaction and ownership contracts; unsupported operations must
//! return structured failure rather than empty success.

#![forbid(unsafe_code)]
#![cfg_attr(test, allow(clippy::unwrap_used, clippy::expect_used, clippy::panic, clippy::todo, clippy::unimplemented, clippy::unreachable))] // #53: tests assert with unwrap/expect/panic (+todo/unreachable in fixtures); production lints stay deny
pub mod command;
pub mod desktop;
pub mod entropy;
mod error;
pub mod fs;
pub mod instance_lock;
pub mod node_selection;
pub mod proxy_mode;
pub mod pac;
pub mod paths;
pub mod process;
pub mod recovery;
pub mod secrets;
pub mod tun;
pub mod uds;

pub use error::PlatformFailure;

/// Builds a bounded text value, falling back to a static label on overflow.
/// A fallback that itself overflows is a fixed-text invariant violation in
/// the caller; it is clamped (and logged) rather than panicking, so a
/// presentation bug can no longer take the control plane down (L1 audit:
/// the pre-fix `unreachable!` aborted the whole daemon for it). Shared
/// across platform backends to avoid per-file duplication.
pub(crate) fn bounded_text<const MAX: usize>(
    value: impl Into<String>,
    fallback: &'static str,
) -> caly_domain::BoundedText<MAX> {
    match caly_domain::BoundedText::new(value.into()) {
        Ok(value) => value,
        Err(_) => match caly_domain::BoundedText::new(fallback.to_owned()) {
            Ok(value) => value,
            Err(error) => {
                tracing::warn!(
                    "bounded_text fallback `{fallback}` exceeds capacity {MAX}: {error}; clamping"
                );
                caly_domain::BoundedText::from_nonempty_clamped(fallback.to_owned(), "_")
            }
        },
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn oversized_fallback_clamps_instead_of_panicking() {
        // L1 regression: a fallback that itself overflows used to hit
        // `unreachable!` and abort the daemon; it now clamps to the bound.
        let clamped = bounded_text::<4>("way-too-long".to_owned(), "also-way-too-long");
        assert!(clamped.as_str().len() <= 4);
        assert!(clamped.as_str().is_char_boundary(clamped.as_str().len()));
        assert_eq!(bounded_text::<4>("ok".to_owned(), "fb").as_str(), "ok");
        assert_eq!(bounded_text::<4>(String::new(), "fb").as_str(), "fb");
    }
}

pub mod dns;
pub use dns::*;
