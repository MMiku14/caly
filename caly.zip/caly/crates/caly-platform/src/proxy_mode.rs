//! Durable memory of the user's proxy routing mode.
//!
//! `proxy mode <rule|global|direct>` used to PATCH the kernel only:
//! a daemon restart re-seeded `rule`, every config re-render pushed the
//! hardcoded `mode: rule` back, and sing-box (whose config carries no
//! mode field until `default_mode`) forgot it on every restart. The
//! mode record is the single source of truth the renderers embed and
//! the boot seed reads, so the mode survives restarts, switches and
//! subscription refreshes (bug ⑪).
//!
//! Owner-only (`0600`) atomic JSON, mirroring the node-selection record.

use std::path::Path;

use serde::{Deserialize, Serialize};

use crate::fs::{AtomicWritePlan, LinuxAtomicFileBackend, atomic_write};
use crate::{PlatformFailure, bounded_text as bounded};

/// Maximum bytes accepted for the mode record payload.
pub const MAX_MODE_BYTES: usize = 1_024;

/// The persisted routing mode: `rule`, `global` or `direct`.
#[derive(Clone, Debug, Deserialize, Eq, PartialEq, Serialize)]
pub struct ProxyModeRecord {
    /// Kernel mode label, exactly as the Clash `/configs` API spells it.
    pub mode: String,
}

impl ProxyModeRecord {
    /// Builds a record for a validated label.
    pub fn new(mode: &str) -> Self {
        Self {
            mode: mode.to_owned(),
        }
    }
}

/// Persists the routing mode atomically, owner-only.
pub fn save_proxy_mode(path: &Path, record: &ProxyModeRecord) -> Result<(), PlatformFailure> {
    let parent = if let Some(parent) = path.parent().filter(|p| !p.as_os_str().is_empty()) {
        std::fs::create_dir_all(parent)
            .map_err(|error| failure(path, format!("cannot create state dir: {error}")))?;
        parent.to_path_buf()
    } else {
        return Err(failure(
            path,
            "mode path has no parent directory".to_owned(),
        ));
    };
    let contents = serde_json::to_vec(record)
        .map_err(|error| failure(path, format!("cannot encode mode: {error}")))?;
    if contents.len() > MAX_MODE_BYTES {
        return Err(failure(
            path,
            "mode record exceeds the size bound".to_owned(),
        ));
    }
    let file_stem = path.file_name().map_or_else(
        || "mode".to_owned(),
        |name| name.to_string_lossy().into_owned(),
    );
    let temporary = parent.join(format!("{file_stem}.tmp.{}", std::process::id()));
    let mut backend = LinuxAtomicFileBackend;
    let contents = crate::fs::AtomicFileContents::try_from_vec(contents)
        .map_err(|_| failure(path, "mode record exceeds the bounded file size".to_owned()))?;
    atomic_write(
        &mut backend,
        AtomicWritePlan {
            destination: path.to_path_buf(),
            temporary,
            contents,
        },
    )
    .map_err(|atomic| failure(path, atomic.primary.message.to_string()))
}

/// Loads the persisted routing mode label, if any.
///
/// Missing, corrupt, oversized or unlabelled records yield `None`:
/// restoring a mode is best-effort and must never fail lifecycle work.
pub fn load_proxy_mode(path: &Path) -> Option<String> {
    use std::io::Read;
    let mut contents = Vec::new();
    std::fs::File::open(path)
        .ok()?
        .take(MAX_MODE_BYTES as u64 + 1)
        .read_to_end(&mut contents)
        .ok()?;
    if contents.len() > MAX_MODE_BYTES {
        return None;
    }
    let record = serde_json::from_slice::<ProxyModeRecord>(&contents).ok()?;
    match record.mode.as_str() {
        "rule" | "global" | "direct" => Some(record.mode),
        _ => None,
    }
}

fn failure(path: &Path, message: String) -> PlatformFailure {
    PlatformFailure {
        operation: bounded("save-proxy-mode".to_owned(), "mode-operation"),
        resource: bounded(path.display().to_string(), "mode-path"),
        message: bounded(message, "proxy mode persistence failed"),
        suggested_action: bounded(
            "inspect the XDG state directory permissions".to_owned(),
            "state permissions",
        ),
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    fn scratch(name: &str) -> std::path::PathBuf {
        let dir = std::env::temp_dir().join(format!(
            "caly-mode-test-{}-{name}",
            std::process::id()
        ));
        let _ = std::fs::remove_dir_all(&dir);
        dir.join("proxy-mode.json")
    }

    #[test]
    fn round_trip_persists_the_label() {
        let path = scratch("round-trip");
        save_proxy_mode(&path, &ProxyModeRecord::new("global")).expect("save works");
        assert_eq!(load_proxy_mode(&path).as_deref(), Some("global"));
        let _ = std::fs::remove_dir_all(path.parent().expect("parent"));
    }

    #[test]
    fn missing_file_loads_none() {
        let path = scratch("missing");
        assert_eq!(load_proxy_mode(&path), None);
    }

    #[test]
    fn unknown_label_loads_none() {
        let path = scratch("unknown");
        std::fs::create_dir_all(path.parent().expect("parent")).expect("dir");
        std::fs::write(&path, r#"{"mode":"turbo"}"#).expect("write");
        assert_eq!(load_proxy_mode(&path), None);
        let _ = std::fs::remove_dir_all(path.parent().expect("parent"));
    }
}
