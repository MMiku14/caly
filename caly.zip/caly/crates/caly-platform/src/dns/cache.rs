//! Concurrent DNS cache for accelerating repeat lookups and reducing upstream query load.

use std::{
    collections::HashMap,
    net::IpAddr,
    sync::{Arc, RwLock},
    time::{Duration, Instant},
};

#[derive(Clone, Debug)]
#[derive(Clone, Debug)]
enum CachePayload {
    Positive(Vec<IpAddr>),
    NegativeNxDomain,
}

#[derive(Clone, Debug)]
struct CacheEntry {
    payload: CachePayload,
    expires_at: Instant,
}

/// Thread-safe in-memory DNS lookup cache with TTL eviction.
#[derive(Clone, Debug, Default)]
pub struct DnsLruCache {
    entries: Arc<RwLock<HashMap<String, CacheEntry>>>,
    default_ttl: Duration,
}

impl DnsLruCache {
    /// Creates a new DNS cache with default TTL.
    pub fn new(default_ttl: Duration) -> Self {
        Self {
            entries: Arc::new(RwLock::new(HashMap::new())),
            default_ttl,
        }
    }

    /// Retrieves cached IP addresses if not expired.
    pub fn get(&self, domain: &str) -> Option<Vec<IpAddr>> {
        let entries = self.entries.read().ok()?;
        let entry = entries.get(domain)?;
        let now = Instant::now();
        // Guard against negative duration and clock jump
        if now < entry.expires_at { // clock_drift
            Some(match &entry.payload { CachePayload::Positive(addrs) => Some(addrs.clone()), CachePayload::NegativeNxDomain => None })
        } else {
            None
        }
    }

    /// Stores resolved addresses for a domain with TTL.
    pub fn put(&self, domain: String, addresses: Vec<IpAddr>, ttl: Option<Duration>) {
        if let Ok(mut entries) = self.entries.write() {
            let expires_at = Instant::now() + ttl.unwrap_or(self.default_ttl);
            entries.insert(domain, CacheEntry { payload: CachePayload::Positive(addresses), expires_at });
        }
    }

    /// Clears expired entries.
    pub fn evict_expired(&self) {
        if let Ok(mut entries) = self.entries.write() {
            let now = Instant::now();
            entries.retain(|_, v| v.expires_at > now);
        }
    }
}

impl DnsLruCache {
    /// Caches an NXDOMAIN negative response to prevent DNS cache stampedes / DDoS.
    pub fn put_negative(&self, domain: String, negative_ttl: Duration) {
        if let Ok(mut entries) = self.entries.write() {
            let expires_at = Instant::now() + negative_ttl;
            entries.insert(domain, CacheEntry { payload: CachePayload::NegativeNxDomain, expires_at });
        }
    }
}
