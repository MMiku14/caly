//! Desktop session / system-proxy state read surface.
//!
//! P8b: moved up from `caly-backends` so the presentation layer can
//! inspect the desktop proxy state without reaching into adapters —
//! platform owns system touchpoints (M12), and the read side of the
//! gsettings / KDE / session-env backends is exactly that:
//! gsettings/kioslaverc/environment.d reads with no side effects.
//!
//! The WRITE side (apply/restore/engage) stays in the `PlatformCommandBackend`
//! implementations inside `caly-backends`, which delegate their read side
//! back to [`capture_proxy_state`] so both paths always agree.
//!
//! Desktop coverage: the `gsettings` backend serves GNOME plus every
//! desktop that kept the `org.gnome.system.proxy` schema (Unity,
//! Cinnamon, MATE, Pantheon, Budgie, … — MATE never forked the proxy
//! schema, its control-center capplet writes the GNOME one); KDE
//! Plasma is served via `kioslaverc`; desktops without a proxy
//! database (Wayland compositors, XFCE, LXQt/LXDE, bare window
//! managers) fall back to the user `environment.d` proxy file, which
//! takes effect at the next login.

use std::path::{Path, PathBuf};

use crate::command::{
    CommandArguments, CommandRequest, CommandResult, CommandRunner, LinuxCommandRunner,
};

/// Supported Linux desktop proxy backends.
#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub enum DesktopProxyMode {
    /// GNOME and GNOME-schema desktops (Unity, Cinnamon, MATE,
    /// Pantheon, Budgie, …) via `gsettings` on
    /// `org.gnome.system.proxy`.
    Gnome,
    /// KDE Plasma via `kwriteconfig5`/`kwriteconfig6` writing `kioslaverc`.
    Kde,
    /// Desktops without a proxy database (Wayland compositors such as
    /// niri/sway/Hyprland, XFCE, LXQt/LXDE, bare window managers) via
    /// user `environment.d` proxy variables. Takes effect at the next
    /// login — the session manager reads the file once at startup.
    SessionEnv,
    /// A desktop with no supported system-proxy mechanism.
    Unsupported,
}

impl DesktopProxyMode {
    /// Lowercase backend label (`gnome` / `kde` / `session-env` /
    /// `unsupported`) for diagnostics — explicit so a variant rename
    /// cannot silently change user-visible output.
    pub const fn label(self) -> &'static str {
        match self {
            Self::Gnome => "gnome",
            Self::Kde => "kde",
            Self::SessionEnv => "session-env",
            Self::Unsupported => "unsupported",
        }
    }
}

/// Reads the raw desktop/session identifier for diagnostics
/// (`XDG_CURRENT_DESKTOP`, falling back to `DESKTOP_SESSION`).
/// Single-line, bounded, never empty — safe to embed in messages
/// (failure constructors clamp again downstream).
pub fn desktop_session_id() -> String {
    let raw = std::env::var("XDG_CURRENT_DESKTOP")
        .or_else(|_| std::env::var("DESKTOP_SESSION"))
        .unwrap_or_default();
    let cleaned: String = raw.chars().filter(|c| !c.is_control()).take(48).collect();
    let cleaned = cleaned.trim();
    if cleaned.is_empty() {
        "unknown".to_owned()
    } else {
        cleaned.to_owned()
    }
}

/// Detects the current desktop proxy mode from the session environment.
pub fn detect_desktop_mode() -> DesktopProxyMode {
    classify_desktop(&desktop_session_id().to_lowercase())
}

/// Pure classification of a lowercased desktop/session identifier.
///
/// Substring matching because `XDG_CURRENT_DESKTOP` is often a
/// colon-separated list (`ubuntu:GNOME`, `Budgie:GNOME`) and session
/// names carry vendor prefixes. Order matters: the GNOME-schema
/// family first, then KDE, then the session-env fallback class.
fn classify_desktop(desktop: &str) -> DesktopProxyMode {
    // GNOME-schema family: Unity, Cinnamon, MATE, Pantheon and Budgie
    // all kept `org.gnome.system.proxy` (none forked the proxy schema),
    // so one gsettings backend serves them all. Phosh/Regolith are
    // GNOME-shell based and match on `gnome` already.
    if ["gnome", "unity", "cinnamon", "mate", "pantheon", "budgie"]
        .iter()
        .any(|token| desktop.contains(token))
    {
        DesktopProxyMode::Gnome
    } else if desktop.contains("kde") || desktop.contains("plasma") {
        DesktopProxyMode::Kde
    } else if [
        // Wayland compositors without a proxy database.
        "niri", "sway", "hyprland", "river", "labwc", "wayfire", "miriway", "cosmic",
        // Desktop environments without a proxy database.
        "xfce", "lxqt", "lxde",
        // Bare window managers: the session environment is the only
        // proxy channel applications honour.
        "i3", "qtile", "awesome", "bspwm", "dwm", "xmonad",
    ]
    .iter()
    .any(|token| desktop.contains(token))
    {
        DesktopProxyMode::SessionEnv
    } else {
        // Deepin (dconfig), UKUI, Enlightenment and anything unknown:
        // honest `Unsupported` beats writing an env file the session
        // would silently ignore.
        DesktopProxyMode::Unsupported
    }
}

/// Captures the current desktop proxy state as `(mode, endpoint)` through a
/// fresh runner, mirroring the daemon-side capture exactly (single source of
/// truth for the read side).
pub fn capture_proxy_state(mode: DesktopProxyMode) -> (String, String) {
    match mode {
        DesktopProxyMode::Gnome => capture_gnome(&mut LinuxCommandRunner),
        DesktopProxyMode::Kde => capture_kde(&mut LinuxCommandRunner),
        DesktopProxyMode::SessionEnv => capture_session_env(),
        DesktopProxyMode::Unsupported => ("none".to_owned(), String::new()),
    }
}

/// Runs one command and requires exit code zero (read-side tolerance: a
/// probe failure yields `None`, never a crash).
fn run_ok<R: CommandRunner>(
    runner: &mut R,
    executable: PathBuf,
    args: &[&str],
) -> Option<CommandResult> {
    let arguments = arguments(args)?;
    runner
        .run_bounded(CommandRequest {
            executable,
            arguments,
            timeout: std::time::Duration::from_secs(2),
        })
        .ok()
        .filter(|result| result.exit_code == Some(0))
}

/// Bounded argument list (read-side probe arguments are short; an over-long
/// one yields `None`).
fn arguments(values: &[&str]) -> Option<CommandArguments> {
    let mut out = CommandArguments::new();
    for value in values {
        let argument = caly_domain::BoundedText::new((*value).to_owned()).ok()?;
        out.try_push(argument).ok()?;
    }
    Some(out)
}

// ---------------------------------------------------------------------------
// GNOME (gsettings)
// ---------------------------------------------------------------------------

/// Captures the current GNOME proxy state as `(mode, endpoint)`.
///
/// One `list-recursively` carries mode + autoconfig-url + http
/// host/port in a single spawn (verified live against real gsettings:
/// children are included as `org.gnome.system.proxy.http …` lines) —
/// the per-key `get` path it replaces paid up to three spawns per
/// capture. The scan is order-independent (gsettings sorts keys
/// alphabetically, but nothing here relies on it).
///
/// `auto` reports the PAC URL; `manual` reports `host:port`; unreadable mode
/// degrades to `("unknown", "")` — a probe failure must never
/// masquerade as "no proxy", or the shutdown restore would write `none` over
/// the operator's genuine configuration.
fn capture_gnome<R: CommandRunner>(runner: &mut R) -> (String, String) {
    let Some(result) = run_ok(
        runner,
        gsettings(),
        &["list-recursively", "org.gnome.system.proxy"],
    ) else {
        return ("unknown".to_owned(), String::new());
    };
    let dump = GsettingsDump::scan(stdout_text(&result));
    let Some(mode) = dump.mode else {
        return ("unknown".to_owned(), String::new());
    };
    if mode == "auto" {
        return (mode, dump.autoconfig_url.unwrap_or_default());
    }
    if mode != "manual" {
        return (mode, String::new());
    }
    let host = dump.http_host.unwrap_or_default();
    if host.is_empty() {
        return (mode, String::new());
    }
    // Some tools (including earlier caly versions) store a combined
    // `host:port` in the host key; accept it directly when well-formed.
    if endpoint_port(&host).is_some() {
        return (mode, host);
    }
    let Some(port) = dump.http_port else {
        return (mode, String::new());
    };
    (mode, format!("{host}:{port}"))
}

/// The proxy keys scanned out of one `list-recursively` dump.
#[derive(Default)]
struct GsettingsDump {
    mode: Option<String>,
    autoconfig_url: Option<String>,
    http_host: Option<String>,
    http_port: Option<u16>,
}

impl GsettingsDump {
    /// Scans `schema key value` lines, ignoring anything outside the
    /// proxy schema (future keys, sibling schemas on odd outputs).
    fn scan(text: &str) -> Self {
        let mut dump = Self::default();
        for line in text.lines() {
            let Some(rest) = line.strip_prefix("org.gnome.system.proxy") else {
                continue;
            };
            if let Some(value) = rest.strip_prefix(" mode ") {
                dump.mode = parse_gsettings_value(value);
            } else if let Some(value) = rest.strip_prefix(" autoconfig-url ") {
                dump.autoconfig_url = parse_gsettings_value(value);
            } else if let Some(value) = rest.strip_prefix(".http host ") {
                dump.http_host = parse_gsettings_value(value);
            } else if let Some(value) = rest.strip_prefix(".http port ") {
                dump.http_port = parse_gsettings_u32(value);
            }
        }
        dump
    }
}

fn gsettings() -> PathBuf {
    PathBuf::from("gsettings")
}

fn stdout_text(result: &CommandResult) -> &str {
    std::str::from_utf8(result.stdout.as_slice()).unwrap_or_default()
}

/// Parses one `gsettings get` value, stripping the surrounding single quotes.
fn parse_gsettings_value(raw: &str) -> Option<String> {
    let trimmed = raw.trim();
    let unquoted = trimmed.strip_prefix('\'')?.strip_suffix('\'')?;
    Some(unquoted.to_owned())
}

/// Parses a `gsettings get` numeric value, tolerating the `uint32 ` prefix.
fn parse_gsettings_u32(raw: &str) -> Option<u16> {
    let trimmed = raw.trim();
    let digits = trimmed.strip_prefix("uint32 ").unwrap_or(trimmed);
    digits.parse::<u16>().ok()
}

/// The trailing port of a `host:port` endpoint, when well-formed.
///
/// bracket-aware — `[::1]:7890` yields `7890`; a bare IPv6
/// literal has no port separator semantics and yields `None` (the old
/// `rfind(':')` read `::1` as host `::` / port `1`).
fn endpoint_port(endpoint: &str) -> Option<u16> {
    let (_host, port) = split_endpoint_parts(endpoint);
    port?.parse::<u16>().ok()
}

/// Bracket-aware endpoint splitter, shared with the GNOME write side
/// (`caly-backends::platform::gnome`) so read and write parse endpoints
/// identically: `[v6]:port` / `host:port` → `(host, Some(port))`; a bare
/// IPv6 literal or port-less host → `(host, None)`.
pub fn split_endpoint_parts(endpoint: &str) -> (&str, Option<&str>) {
    if let Some(rest) = endpoint.strip_prefix('[')
        && let Some(close) = rest.find(']')
    {
        let host = &rest[..close];
        let tail = &rest[close + 1..];
        return (host, tail.strip_prefix(':'));
    }
    // More than one colon means a bare IPv6 literal without brackets.
    if endpoint.matches(':').count() > 1 {
        return (endpoint, None);
    }
    match endpoint.rfind(':') {
        Some(index) if index > 0 => ((&endpoint[..index]), Some(&endpoint[index + 1..])),
        _ => (endpoint, None),
    }
}

/// Renders an `http://` proxy URL from a host or a `host:port` endpoint,
/// shared by the KDE and session-env writers so URL shaping cannot
/// drift between desktops. An endpoint carrying its own port wins over
/// `default_port`; an IPv6 host gains brackets (`[::1]:7890`); callers
/// pass a non-empty host or endpoint.
pub fn http_proxy_url(host_or_endpoint: &str, default_port: u16) -> String {
    let (host, port) = split_endpoint_parts(host_or_endpoint.trim());
    let port = port
        .filter(|text| !text.is_empty())
        .map_or_else(|| default_port.to_string(), str::to_owned);
    if host.contains(':') {
        format!("http://[{host}]:{port}")
    } else {
        format!("http://{host}:{port}")
    }
}

/// Renders an `http://` proxy URL from a captured endpoint (the
/// restore path): an endpoint carrying its own port renders with it
/// (IPv6 bracketed); a port-less endpoint keeps the legacy
/// `http://host` shape instead of gaining a bogus `:0`.
pub fn http_proxy_url_from_endpoint(endpoint: &str) -> String {
    match split_endpoint_parts(endpoint.trim()) {
        (_, Some(_)) => http_proxy_url(endpoint, 0),
        (host, None) if host.contains(':') => format!("http://[{host}]"),
        (host, None) => format!("http://{host}"),
    }
}

// ---------------------------------------------------------------------------
// KDE Plasma (kioslaverc via kreadconfig)
// ---------------------------------------------------------------------------

const KDE_PROXY_GROUP: &str = "Proxy Settings";
const KDE_PAC_KEY: &str = "Proxy Config Script";

/// KDE `ProxyType` values: 0 = no proxy, 1 = manual, 2 = automatic (PAC).
fn kreadconfig_tool() -> PathBuf {
    if std::env::var("KDE_SESSION_VERSION").as_deref() == Ok("6") {
        PathBuf::from("kreadconfig6")
    } else {
        PathBuf::from("kreadconfig5")
    }
}

/// Captures the current KDE proxy state as `(mode, endpoint)`.
///
/// The endpoint is the `httpProxy` URL with its scheme stripped, and is only
/// meaningful for manual mode. Unreadable state degrades to `("unknown", "")`
/// (a probe failure must not masquerade as "no proxy", or the
/// shutdown restore would write `ProxyType=0` over the operator's genuine
/// manual configuration).
fn capture_kde<R: CommandRunner>(runner: &mut R) -> (String, String) {
    let tool = kreadconfig_tool();
    let Some(raw) = read_key(runner, &tool, "ProxyType") else {
        return ("unknown".to_owned(), String::new());
    };
    match raw.trim() {
        "1" => {
            // Audit #114 (endpoint arm): an unreadable `httpProxy` in a
            // confirmed manual config must not masquerade as an empty
            // endpoint — same unknown treatment as the `ProxyType` read.
            let Some(http_proxy) = read_key(runner, &tool, "httpProxy") else {
                return ("unknown".to_owned(), String::new());
            };
            ("manual".to_owned(), strip_http_scheme(http_proxy.trim()))
        }
        "2" => {
            // A PAC mode without a readable script URL is still `auto`;
            // restoration re-applies mode 2 and leaves the URL untouched
            // when the capture could not observe it.
            let pac_url = read_key(runner, &tool, KDE_PAC_KEY)
                .map(|value| value.trim().to_owned())
                .unwrap_or_default();
            ("auto".to_owned(), pac_url)
        }
        _ => ("none".to_owned(), String::new()),
    }
}

fn read_key<R: CommandRunner>(runner: &mut R, tool: &Path, key: &str) -> Option<String> {
    let result = run_ok(runner, tool.to_path_buf(), &[KDE_PROXY_GROUP, "--key", key])?;
    Some(
        std::str::from_utf8(result.stdout.as_slice())
            .unwrap_or_default()
            .trim()
            .to_owned(),
    )
}

/// Strips an `http://` or `https://` scheme prefix from a proxy URL.
fn strip_http_scheme(value: &str) -> String {
    let trimmed = value.trim();
    let stripped = trimmed
        .strip_prefix("http://")
        .or_else(|| trimmed.strip_prefix("https://"))
        .unwrap_or(trimmed);
    stripped.trim_end_matches('/').to_owned()
}

// ---------------------------------------------------------------------------
// session-env (environment.d fallback class)
// ---------------------------------------------------------------------------

/// Captures the current session-env proxy state as `(mode, endpoint)`.
///
/// The session file is caly-owned; its presence with a parseable export means
/// a manual proxy endpoint was active. Unreadable state degrades to `none`.
fn capture_session_env() -> (String, String) {
    let Some(path) = session_env_file_path() else {
        return ("none".to_owned(), String::new());
    };
    let Ok(contents) = std::fs::read_to_string(&path) else {
        return ("none".to_owned(), String::new());
    };
    match parse_session_env_endpoint(&contents) {
        Some(endpoint) => ("manual".to_owned(), endpoint),
        None => ("none".to_owned(), String::new()),
    }
}

/// The caly-owned user `environment.d` proxy file. Exported so the
/// read side (here) and the write side (`caly-backends`) resolve the
/// same path and can never drift apart.
pub fn session_env_file_path() -> Option<PathBuf> {
    let home = std::env::var_os("HOME")?;
    Some(PathBuf::from(home).join(".config/environment.d/caly-proxy.conf"))
}

fn parse_session_env_endpoint(contents: &str) -> Option<String> {
    for line in contents.lines() {
        let trimmed = line.trim();
        let Some(rest) = trimmed.strip_prefix("export http_proxy=") else {
            continue;
        };
        let unquoted = rest.trim().trim_matches('"');
        let stripped = unquoted.strip_prefix("http://").unwrap_or(unquoted);
        if !stripped.is_empty() {
            return Some(stripped.to_owned());
        }
    }
    None
}

#[cfg(test)]
mod tests {
    use super::*;

    /// Runner returning scripted stdout values in order (exit code zero).
    struct ScriptedRunner {
        outputs: std::collections::VecDeque<&'static str>,
    }

    impl CommandRunner for ScriptedRunner {
        fn run_bounded(
            &mut self,
            _request: CommandRequest,
        ) -> Result<CommandResult, crate::PlatformFailure> {
            // A scripted command with no output left simulates a probe
            // failure (nonzero exit): the read side must degrade to
            // `unknown`, never to an empty-but-ok read (Audit #114).
            let Some(stdout) = self.outputs.pop_front() else {
                return Ok(CommandResult {
                    exit_code: Some(1),
                    stdout: caly_domain::BoundedVec::new(),
                    stderr: caly_domain::BoundedVec::new(),
                });
            };
            Ok(CommandResult {
                exit_code: Some(0),
                stdout: caly_domain::BoundedVec::try_from_vec(stdout.as_bytes().to_vec())
                    .unwrap_or_default(),
                stderr: caly_domain::BoundedVec::new(),
            })
        }
    }

    #[test]
    fn parse_gsettings_value_strips_quotes() {
        assert_eq!(parse_gsettings_value("'manual'"), Some("manual".to_owned()));
        assert_eq!(parse_gsettings_value("'auto'"), Some("auto".to_owned()));
        assert_eq!(parse_gsettings_value("none"), None);
        assert_eq!(parse_gsettings_value("''"), Some(String::new()));
    }

    #[test]
    fn parse_gsettings_u32_tolerates_type_prefix() {
        assert_eq!(parse_gsettings_u32("uint32 7890"), Some(7890));
        assert_eq!(parse_gsettings_u32("7890"), Some(7890));
        assert_eq!(parse_gsettings_u32("not-a-number"), None);
    }

    #[test]
    fn capture_reads_split_host_and_port_keys() {
        let mut runner = ScriptedRunner {
            outputs: vec!["org.gnome.system.proxy mode 'manual'\n\
                org.gnome.system.proxy.http host '127.0.0.1'\n\
                org.gnome.system.proxy.http port uint32 7890\n"]
            .into(),
        };
        assert_eq!(
            capture_gnome(&mut runner),
            ("manual".to_owned(), "127.0.0.1:7890".to_owned())
        );
    }

    #[test]
    fn capture_accepts_combined_host_port_value() {
        let mut runner = ScriptedRunner {
            outputs: vec!["org.gnome.system.proxy mode 'manual'\n\
                org.gnome.system.proxy.http host '127.0.0.1:7890'\n"]
            .into(),
        };
        assert_eq!(
            capture_gnome(&mut runner),
            ("manual".to_owned(), "127.0.0.1:7890".to_owned())
        );
    }

    #[test]
    fn capture_none_mode_has_no_endpoint() {
        let mut runner = ScriptedRunner {
            outputs: vec!["org.gnome.system.proxy mode 'none'\n"].into(),
        };
        assert_eq!(
            capture_gnome(&mut runner),
            ("none".to_owned(), String::new())
        );
    }

    #[test]
    fn capture_gnome_auto_reads_pac_url() {
        let mut runner = ScriptedRunner {
            outputs: vec!["org.gnome.system.proxy autoconfig-url 'file:///x.pac'\n\
                org.gnome.system.proxy mode 'auto'\n"]
            .into(),
        };
        assert_eq!(
            capture_gnome(&mut runner),
            ("auto".to_owned(), "file:///x.pac".to_owned())
        );
    }

    #[test]
    fn capture_gnome_scan_is_order_independent() {
        // keys arrive alphabetically, but the scan must not rely on it.
        let mut runner = ScriptedRunner {
            outputs: vec!["org.gnome.system.proxy.http port 3128\n\
                org.gnome.system.proxy.http host '10.0.0.1'\n\
                org.gnome.system.proxy mode 'manual'\n"]
            .into(),
        };
        assert_eq!(
            capture_gnome(&mut runner),
            ("manual".to_owned(), "10.0.0.1:3128".to_owned())
        );
    }

    #[test]
    fn capture_gnome_dump_without_mode_is_unknown() {
        let mut runner = ScriptedRunner {
            outputs: vec!["org.gnome.system.proxy.http host '10.0.0.1'\n"].into(),
        };
        assert_eq!(
            capture_gnome(&mut runner),
            ("unknown".to_owned(), String::new())
        );
    }

    #[test]
    fn capture_unreadable_mode_is_unknown_not_none() {
        // a failed probe must not masquerade as "no proxy".
        let mut runner = ScriptedRunner {
            outputs: std::collections::VecDeque::new(),
        };
        assert_eq!(
            capture_gnome(&mut runner),
            ("unknown".to_owned(), String::new())
        );
    }

    #[test]
    fn capture_auto_reads_pac_script_url() {
        let mut runner = ScriptedRunner {
            outputs: vec!["2", "http://example.com/proxy.pac"].into(),
        };
        assert_eq!(
            capture_kde(&mut runner),
            ("auto".to_owned(), "http://example.com/proxy.pac".to_owned())
        );
    }

    #[test]
    fn capture_manual_strips_http_scheme() {
        let mut runner = ScriptedRunner {
            outputs: vec!["1", "http://127.0.0.1:7890/"].into(),
        };
        assert_eq!(
            capture_kde(&mut runner),
            ("manual".to_owned(), "127.0.0.1:7890".to_owned())
        );
    }

    #[test]
    fn capture_manual_with_unreadable_http_proxy_is_unknown() {
        // Audit #114 (endpoint arm): missing httpProxy in a manual config
        // is unknown, not an empty endpoint.
        let mut runner = ScriptedRunner {
            outputs: vec!["1"].into(),
        };
        assert_eq!(
            capture_kde(&mut runner),
            ("unknown".to_owned(), String::new())
        );
    }

    #[test]
    fn capture_auto_and_none_modes() {
        let mut runner = ScriptedRunner {
            outputs: vec!["2"].into(),
        };
        assert_eq!(capture_kde(&mut runner), ("auto".to_owned(), String::new()));
        let mut runner = ScriptedRunner {
            outputs: vec!["0"].into(),
        };
        assert_eq!(capture_kde(&mut runner), ("none".to_owned(), String::new()));
    }

    #[test]
    fn strip_http_scheme_handles_prefixes_and_slashes() {
        assert_eq!(strip_http_scheme("http://a:1/"), "a:1");
        assert_eq!(strip_http_scheme("https://b:2"), "b:2");
        assert_eq!(strip_http_scheme("plain:3"), "plain:3");
    }

    #[test]
    fn parse_session_env_endpoint_reads_exported_endpoint() {
        let contents = "export http_proxy=\"http://127.0.0.1:7890\"\n";
        assert_eq!(
            parse_session_env_endpoint(contents),
            Some("127.0.0.1:7890".to_owned())
        );
    }

    #[test]
    fn parse_session_env_endpoint_ignores_unset_files() {
        assert_eq!(parse_session_env_endpoint(""), None);
        assert_eq!(
            parse_session_env_endpoint("# comment\nexport HTTPS_PROXY=\"http://x\"\n"),
            None
        );
    }

    #[test]
    fn classify_desktop_covers_known_families() {
        use DesktopProxyMode::{Gnome, Kde, SessionEnv, Unsupported};
        // GNOME-schema family, incl. colon-separated lists.
        for id in [
            "gnome",
            "ubuntu:gnome",
            "unity",
            "cinnamon",
            "mate",
            "pantheon",
            "budgie:gnome",
        ] {
            assert_eq!(classify_desktop(id), Gnome, "{id}");
        }
        for id in ["kde", "plasma"] {
            assert_eq!(classify_desktop(id), Kde, "{id}");
        }
        // Session-env fallback class.
        for id in [
            "niri", "sway", "hyprland", "river", "labwc", "wayfire", "miriway", "cosmic",
            "xfce", "lxqt", "lxde", "i3", "qtile", "awesome", "bspwm", "dwm", "xmonad",
        ] {
            assert_eq!(classify_desktop(id), SessionEnv, "{id}");
        }
        // Unknown or schema-less-but-unhandled stays honest.
        for id in ["", "deepin", "enlightenment", "ukui", "windows"] {
            assert_eq!(classify_desktop(id), Unsupported, "{id}");
        }
    }

    #[test]
    fn http_proxy_url_brackets_ipv6_and_prefers_endpoint_port() {
        assert_eq!(
            http_proxy_url("127.0.0.1", 7890),
            "http://127.0.0.1:7890"
        );
        assert_eq!(http_proxy_url("[::1]", 7890), "http://[::1]:7890");
        assert_eq!(http_proxy_url("::1", 7890), "http://[::1]:7890");
        // An endpoint carrying its own port wins over the default.
        assert_eq!(
            http_proxy_url("10.0.0.1:8080", 7890),
            "http://10.0.0.1:8080"
        );
        assert_eq!(http_proxy_url("[::1]:8080", 7890), "http://[::1]:8080");
    }

    #[test]
    fn http_proxy_url_from_endpoint_keeps_portless_shape() {
        assert_eq!(
            http_proxy_url_from_endpoint("10.0.0.1:8080"),
            "http://10.0.0.1:8080"
        );
        assert_eq!(
            http_proxy_url_from_endpoint("[::1]:8080"),
            "http://[::1]:8080"
        );
        assert_eq!(
            http_proxy_url_from_endpoint("proxy.lan"),
            "http://proxy.lan"
        );
        assert_eq!(http_proxy_url_from_endpoint("::1"), "http://[::1]");
    }

    #[test]
    fn split_endpoint_parts_is_bracket_aware() {
        assert_eq!(split_endpoint_parts("[::1]:7890"), ("::1", Some("7890")));
        assert_eq!(
            split_endpoint_parts("127.0.0.1:7890"),
            ("127.0.0.1", Some("7890"))
        );
        assert_eq!(split_endpoint_parts("::1"), ("::1", None));
    }
}
