use std::collections::BTreeMap;

use caly_cap::{
    CapabilityDescriptor, CapabilityDomain, CapabilityKey, CapabilityState, Constraint, EvidenceRef,
    FallbackPolicy, SupportLevel,
};
use caly_core::{
    artifact_digest, stable_checksum_text, ApplyPlanningResult, CapabilitySet, CoreAdapter,
    CoreIdentity, CoreIssue, CoreKind, IssueLevel, NativeValidationReport, RuntimeDriver,
};
use caly_ir::{
    CompiledArtifact, NativeConfigFormat, ProxyProtocol, ResolvedProfile, RuleAction, StableBytes,
};
use caly_plan::{
    ApplyIssue, ApplyIssueLevel, ApplyPlan, ApplyPlanKind, BlobRef, CoreCall,
    CoreKind as PlanCoreKind, CoreSpec, DeployImpact, Durability, EffectPlan, EffectStep,
    FileMode, InstanceId, NetworkPlan, PlanId, PrivilegeSet, ProbeKind, ProbeSpec, SnapshotId,
};

use crate::runtime::MihomoRuntimeDriver;

#[derive(Default)]
pub struct MihomoAdapter;

impl CoreAdapter for MihomoAdapter {
    fn inspect_binary(&self) -> Result<CoreIdentity, String> {
        Ok(CoreIdentity {
            kind: CoreKind::Mihomo,
            version: "1.0.0-skeleton".to_owned(),
            build: Some("mihomo".to_owned()),
            binary_digest: "mihomo-skeleton-binary".to_owned(),
        })
    }

    fn capability_set(&self, _identity: &CoreIdentity) -> Result<CapabilitySet, String> {
        Ok(CapabilitySet {
            descriptors: vec![
                capability(
                    "dns.fake_ip",
                    "Mihomo Fake-IP",
                    CapabilityDomain::Dns,
                    SupportLevel::CalyManaged,
                    CapabilityState::SupportedExact,
                    vec![Constraint {
                        field: "mode".to_owned(),
                        expected: "fake-ip".to_owned(),
                    }],
                    None,
                    vec!["mihomo dns fake-ip is modeled directly".to_owned()],
                ),
                capability(
                    "runtime.group.select",
                    "Mihomo runtime group select",
                    CapabilityDomain::Runtime,
                    SupportLevel::CalyManaged,
                    CapabilityState::SupportedExact,
                    Vec::new(),
                    None,
                    vec!["mihomo supports controller-driven group selection".to_owned()],
                ),
                capability(
                    "routing.rules",
                    "Mihomo rule routing",
                    CapabilityDomain::Routing,
                    SupportLevel::CalyManaged,
                    CapabilityState::SupportedExact,
                    Vec::new(),
                    None,
                    vec!["mihomo supports rule routing in this slice".to_owned()],
                ),
                capability(
                    "network.tun",
                    "Mihomo TUN",
                    CapabilityDomain::Tun,
                    SupportLevel::CalyManaged,
                    CapabilityState::SupportedExact,
                    Vec::new(),
                    Some(FallbackPolicy::EscalateToRestart),
                    vec!["tun implies network side effects and restart".to_owned()],
                ),
            ],
        })
    }

    fn preflight(
        &self,
        profile: &ResolvedProfile,
        _capabilities: &CapabilitySet,
    ) -> Result<Vec<CoreIssue>, String> {
        let mut issues = vec![CoreIssue {
            level: if profile.nodes.is_empty() {
                IssueLevel::Warning
            } else {
                IssueLevel::Info
            },
            code: "MIHOMO_PREFLIGHT".to_owned(),
            summary: "mihomo adapter preflight executed".to_owned(),
        }];

        if profile.groups.is_empty() {
            issues.push(CoreIssue {
                level: IssueLevel::Warning,
                code: "MIHOMO_EMPTY_GROUPS".to_owned(),
                summary: "mihomo compile path prefers at least one proxy group".to_owned(),
            });
        }

        Ok(issues)
    }

    fn compile(
        &self,
        profile: &ResolvedProfile,
        _capabilities: &CapabilitySet,
    ) -> Result<CompiledArtifact, String> {
        let bytes = render_mihomo_yaml(profile);
        let mut annotations = common_annotations(profile);
        annotations.insert("core.kind".to_owned(), "mihomo".to_owned());
        // The identity a core is asked to confirm at apply time must be the artifact it
        // is actually handed (CoreSpec::config_digest), not a digest of the semantic
        // profile. Deriving it from the semantic digest made the ConfigIdentity probe
        // unanswerable: it could never match, for any plan.
        let artifact_digest = artifact_digest("mihomo", &bytes);
        annotations.insert("config.identity".to_owned(), artifact_digest.0.clone());

        Ok(CompiledArtifact {
            profile_id: profile.profile_id.clone(),
            target_core: CoreKind::Mihomo.target(),
            adapter_version: 1,
            artifact_digest,
            file_name_hint: format!("{}.mihomo.yaml", profile.profile_id.0),
            format: NativeConfigFormat::Yaml,
            entrypoint: "config.yaml".to_owned(),
            media_type: "application/x-yaml".to_owned(),
            bytes,
            annotations,
        })
    }

    fn validate_native(&self, artifact: &CompiledArtifact) -> Result<NativeValidationReport, String> {
        let body = String::from_utf8_lossy(&artifact.bytes.bytes);
        let accepted = body.contains("proxy-groups:") && body.contains("proxies:");
        let mut issues = vec![CoreIssue {
            level: IssueLevel::Info,
            code: "MIHOMO_NATIVE_VALIDATE".to_owned(),
            summary: format!("mihomo validated {}", artifact.file_name_hint),
        }];

        if !accepted {
            issues.push(CoreIssue {
                level: IssueLevel::Error,
                code: "MIHOMO_NATIVE_REJECTED".to_owned(),
                summary: "mihomo native validation expected proxies and proxy-groups sections".to_owned(),
            });
        }

        Ok(NativeValidationReport { accepted, issues })
    }

    fn plan_apply(
        &self,
        current: Option<&CompiledArtifact>,
        next: &CompiledArtifact,
    ) -> Result<ApplyPlanningResult, String> {
        let selection_only = current
            .map(|artifact| selection_only_change(artifact, next))
            .unwrap_or(false);
        let tun_enabled = annotation_bool(next, "tun.enabled");

        let kind = if current
            .map(|artifact| artifact.artifact_digest == next.artifact_digest)
            .unwrap_or(false)
        {
            ApplyPlanKind::Noop
        } else if selection_only {
            ApplyPlanKind::ApiPatch
        } else if current.is_some() && !tun_enabled {
            ApplyPlanKind::HotReload
        } else {
            ApplyPlanKind::Restart
        };

        let impact = match kind {
            ApplyPlanKind::Noop => DeployImpact::Noop,
            ApplyPlanKind::ApiPatch => DeployImpact::RuntimePatch,
            ApplyPlanKind::HotReload => DeployImpact::Reload,
            ApplyPlanKind::Restart => {
                if tun_enabled {
                    DeployImpact::NetworkChange
                } else {
                    DeployImpact::Restart
                }
            }
            ApplyPlanKind::RebuildAndRestart => DeployImpact::RebuildAndRestart,
        };
        let requires = PrivilegeSet {
            needs_admin: tun_enabled,
            needs_network_control: tun_enabled,
            needs_process_control: !matches!(kind, ApplyPlanKind::Noop | ApplyPlanKind::ApiPatch),
            needs_secret_access: false,
        };
        let reasons = plan_reasons(current, next, kind);
        let effect_plan = build_effect_plan(kind, current, next, impact, requires.clone());

        Ok(ApplyPlanningResult {
            apply_plan: ApplyPlan {
                kind,
                impact,
                requires,
                issues: vec![ApplyIssue {
                    level: ApplyIssueLevel::Info,
                    code: "MIHOMO_APPLY_PLAN".to_owned(),
                    summary: format!("mihomo selected {:?}", kind),
                }],
                reasons,
            },
            effect_plan,
        })
    }

    fn runtime(&self) -> Result<Box<dyn RuntimeDriver>, String> {
        Ok(Box::new(MihomoRuntimeDriver::default()))
    }
}

fn capability(
    key: &str,
    title: &str,
    domain: CapabilityDomain,
    support_level: SupportLevel,
    state: CapabilityState,
    constraints: Vec<Constraint>,
    fallback: Option<FallbackPolicy>,
    notes: Vec<String>,
) -> CapabilityDescriptor {
    CapabilityDescriptor {
        key: CapabilityKey(key.to_owned()),
        title: title.to_owned(),
        domain,
        support_level,
        state,
        constraints,
        fallback,
        evidence_ref: EvidenceRef {
            fixture_id: Some(format!("mihomo-{key}")),
            golden_test_id: None,
            native_validation_test_id: None,
            runtime_test_id: None,
        },
        notes,
    }
}

fn render_mihomo_yaml(profile: &ResolvedProfile) -> StableBytes {
    let mut lines = vec![
        format!("mode: {}", routing_mode_name(profile.routing_mode)),
        format!("profile-name: {}", profile.profile_id.0),
        "mixed-port: 7890".to_owned(),
        "allow-lan: false".to_owned(),
        "proxies:".to_owned(),
    ];

    for node in &profile.nodes {
        lines.push(format!("  - name: {}", node.label));
        lines.push(format!("    type: {}", proxy_protocol_name(node.protocol)));
        lines.push(format!("    server: {}", node.server));
        lines.push(format!("    port: {}", node.port));
    }

    lines.push("proxy-groups:".to_owned());
    for group in &profile.groups {
        lines.push(format!("  - name: {}", group.label));
        lines.push(format!("    type: {}", group_type_name(group.kind)));
        if let Some(selected) = &group.selected {
            lines.push(format!("    interface-name: {}", selected.0));
        }
        lines.push("    proxies:".to_owned());
        for member in &group.members {
            let label = profile
                .nodes
                .iter()
                .find(|node| node.id == *member)
                .map(|node| node.label.clone())
                .unwrap_or_else(|| member.0.clone());
            lines.push(format!("      - {}", label));
        }
    }

    lines.push("rules:".to_owned());
    for rule in &profile.rules {
        lines.push(format!(
            "  - {},{}",
            rule.matcher,
            rule.target_group
                .as_ref()
                .map(|group| group.0.clone())
                .unwrap_or_else(|| rule_action_name(rule.action).to_owned())
        ));
    }

    if let Some(dns) = &profile.dns {
        lines.push("dns:".to_owned());
        lines.push("  enable: true".to_owned());
        lines.push(format!("  enhanced-mode: {}", dns_mode_name(dns.mode)));
        lines.push("  nameserver:".to_owned());
        for server in &dns.servers {
            lines.push(format!("    - {}", server));
        }
    }

    if let Some(tun) = &profile.tun {
        lines.push("tun:".to_owned());
        lines.push(format!("  enable: {}", tun.enabled));
        lines.push(format!("  auto-route: {}", tun.auto_route));
        lines.push(format!("  strict-route: {}", tun.strict_route));
    }

    StableBytes::new(lines.join("\n").into_bytes())
}

fn common_annotations(profile: &ResolvedProfile) -> BTreeMap<String, String> {
    let mut annotations = BTreeMap::new();
    annotations.insert("semantic_digest".to_owned(), profile.semantic_digest.0.clone());
    annotations.insert("routing.mode".to_owned(), routing_mode_name(profile.routing_mode).to_owned());
    annotations.insert(
        "tun.enabled".to_owned(),
        profile
            .tun
            .as_ref()
            .map(|tun| tun.enabled)
            .unwrap_or(false)
            .to_string(),
    );
    annotations.insert("selection_digest".to_owned(), selection_digest(profile));
    annotations.insert("selections".to_owned(), selection_pairs(profile).join(","));
    annotations
}

fn selection_digest(profile: &ResolvedProfile) -> String {
    format!("sel:{:016x}", stable_checksum_text(&selection_pairs(profile).join("|")))
}

fn selection_pairs(profile: &ResolvedProfile) -> Vec<String> {
    profile
        .groups
        .iter()
        .map(|group| {
            format!(
                "{}={}",
                group.id.0,
                group
                    .selected
                    .as_ref()
                    .map(|node| node.0.clone())
                    .unwrap_or_else(|| "none".to_owned())
            )
        })
        .collect()
}

fn selection_only_change(current: &CompiledArtifact, next: &CompiledArtifact) -> bool {
    current.annotations.get("semantic_digest") == next.annotations.get("semantic_digest")
        && current.annotations.get("selection_digest") != next.annotations.get("selection_digest")
}

fn annotation_bool(artifact: &CompiledArtifact, key: &str) -> bool {
    artifact
        .annotations
        .get(key)
        .map(|value| value == "true")
        .unwrap_or(false)
}

fn plan_reasons(
    current: Option<&CompiledArtifact>,
    next: &CompiledArtifact,
    kind: ApplyPlanKind,
) -> Vec<String> {
    let mut reasons = vec![format!("target core={}", next.target_core_string())];
    match current {
        None => reasons.push("no active artifact exists; first deployment needs spawn".to_owned()),
        Some(previous) if previous.artifact_digest == next.artifact_digest => {
            reasons.push("artifact digest is unchanged".to_owned())
        }
        Some(previous) if selection_only_change(previous, next) => {
            reasons.push("only runtime group selections changed".to_owned())
        }
        Some(_) => reasons.push("native configuration content changed".to_owned()),
    }

    if annotation_bool(next, "tun.enabled") {
        reasons.push("tun is enabled; network state must be coordinated".to_owned());
    }

    reasons.push(format!("selected apply plan kind={kind:?}"));
    reasons
}

fn build_effect_plan(
    kind: ApplyPlanKind,
    current: Option<&CompiledArtifact>,
    next: &CompiledArtifact,
    impact: DeployImpact,
    requires: PrivilegeSet,
) -> Option<EffectPlan> {
    if matches!(kind, ApplyPlanKind::Noop) {
        return None;
    }

    let instance = InstanceId("mihomo-core-instance".to_owned());
    let snapshot = SnapshotId(format!("mihomo-snapshot-{}", next.profile_id.0));
    let core_spec = CoreSpec {
        kind: PlanCoreKind::Mihomo,
        binary_digest: "mihomo-skeleton-binary".to_owned(),
        config_digest: next.artifact_digest.0.clone(),
    };
    let blob = BlobRef {
        digest: next.artifact_digest.0.clone(),
        size_hint: Some(next.size_bytes() as u64),
    };

    let mut steps = vec![
        EffectStep::WriteObject {
            digest: next.artifact_digest.0.clone(),
            source: blob,
            durability: Durability::D2,
        },
        EffectStep::MaterializeArtifact {
            digest: next.artifact_digest.0.clone(),
            at: format!("runtime/{}/{}", next.profile_id.0, next.entrypoint),
            mode: FileMode::ReadOnlyArtifact,
        },
    ];

    if annotation_bool(next, "tun.enabled") {
        steps.push(EffectStep::NetApply {
            plan: NetworkPlan {
                summary: "configure TUN + route ownership for mihomo".to_owned(),
                requires_privilege: true,
            },
        });
    }

    match kind {
        ApplyPlanKind::ApiPatch => {
            for (group_id, node_id) in selection_delta(current, next) {
                steps.push(EffectStep::CoreApiCall {
                    instance: instance.clone(),
                    call: CoreCall::SelectProxy { group_id, node_id },
                });
            }
        }
        ApplyPlanKind::HotReload => {
            steps.push(EffectStep::CoreApiCall {
                instance: instance.clone(),
                call: CoreCall::Reload,
            });
        }
        ApplyPlanKind::Restart | ApplyPlanKind::RebuildAndRestart => {
            if current.is_some() {
                steps.push(EffectStep::StopCore {
                    instance: instance.clone(),
                    grace_ms: 2_500,
                });
            }
            steps.push(EffectStep::SpawnCore { spec: core_spec });
        }
        ApplyPlanKind::Noop => {}
    }

    steps.push(EffectStep::Probe {
        probe: ProbeSpec {
            kind: ProbeKind::ApiReady,
            target: None,
        },
        deadline_ms: 3_000,
    });
    steps.push(EffectStep::Probe {
        probe: ProbeSpec {
            kind: ProbeKind::ConfigIdentity,
            target: next.annotations.get("config.identity").cloned(),
        },
        deadline_ms: 3_000,
    });
    steps.push(EffectStep::MarkSnapshot { snapshot_id: snapshot });
    steps.push(EffectStep::CommitRevision { revision: 1 });

    let mut compensations = Vec::new();
    if annotation_bool(next, "tun.enabled") {
        compensations.push(EffectStep::NetRevert {
            txn_id: caly_plan::NetTxnId("mihomo-net-revert".to_owned()),
        });
    }
    if current.is_some() {
        compensations.push(EffectStep::CoreApiCall {
            instance,
            call: CoreCall::Reload,
        });
    }

    Some(EffectPlan {
        id: PlanId(format!("mihomo-effect-plan-{}", next.profile_id.0)),
        steps,
        compensations,
        requires,
        impact,
    })
}

fn selection_delta(current: Option<&CompiledArtifact>, next: &CompiledArtifact) -> Vec<(String, String)> {
    let current_pairs = current
        .and_then(|artifact| artifact.annotations.get("selections"))
        .map(|value| parse_selection_pairs(value))
        .unwrap_or_default();
    let next_pairs = next
        .annotations
        .get("selections")
        .map(|value| parse_selection_pairs(value))
        .unwrap_or_default();

    next_pairs
        .into_iter()
        .filter(|(group_id, node_id)| current_pairs.get(group_id) != Some(node_id))
        .collect()
}

fn parse_selection_pairs(value: &str) -> BTreeMap<String, String> {
    let mut pairs = BTreeMap::new();
    for entry in value.split(',') {
        if entry.is_empty() {
            continue;
        }
        let mut parts = entry.splitn(2, '=');
        let Some(group_id) = parts.next() else {
            continue;
        };
        let Some(node_id) = parts.next() else {
            continue;
        };
        pairs.insert(group_id.to_owned(), node_id.to_owned());
    }
    pairs
}

fn proxy_protocol_name(protocol: ProxyProtocol) -> &'static str {
    match protocol {
        ProxyProtocol::Shadowsocks => "ss",
        ProxyProtocol::Vmess => "vmess",
        ProxyProtocol::Vless => "vless",
        ProxyProtocol::Trojan => "trojan",
        ProxyProtocol::Hysteria2 => "hysteria2",
        ProxyProtocol::Tuic => "tuic",
        ProxyProtocol::WireGuard => "wireguard",
        ProxyProtocol::Unknown => "unknown",
    }
}

fn group_type_name(kind: caly_ir::GroupType) -> &'static str {
    match kind {
        caly_ir::GroupType::Select => "select",
        caly_ir::GroupType::UrlTest => "url-test",
        caly_ir::GroupType::Fallback => "fallback",
        caly_ir::GroupType::LoadBalance => "load-balance",
        caly_ir::GroupType::Relay => "relay",
    }
}

fn rule_action_name(action: RuleAction) -> &'static str {
    match action {
        RuleAction::UseGroup => "MATCH",
        RuleAction::Direct => "DIRECT",
        RuleAction::Reject => "REJECT",
        RuleAction::UseOutbound => "OUTBOUND",
    }
}

fn routing_mode_name(mode: caly_ir::RoutingMode) -> &'static str {
    match mode {
        caly_ir::RoutingMode::Rule => "rule",
        caly_ir::RoutingMode::Global => "global",
        caly_ir::RoutingMode::Direct => "direct",
    }
}

fn dns_mode_name(mode: caly_ir::DnsMode) -> &'static str {
    match mode {
        caly_ir::DnsMode::System => "system",
        caly_ir::DnsMode::FakeIp => "fake-ip",
        caly_ir::DnsMode::Redirect => "redir-host",
        caly_ir::DnsMode::Mixed => "mixed",
    }
}

trait ArtifactExt {
    fn target_core_string(&self) -> &'static str;
}

impl ArtifactExt for CompiledArtifact {
    fn target_core_string(&self) -> &'static str {
        match self.target_core {
            caly_ir::CoreTarget::Mihomo => "mihomo",
            caly_ir::CoreTarget::SingBox => "sing-box",
            caly_ir::CoreTarget::Auto => "auto",
        }
    }
}
