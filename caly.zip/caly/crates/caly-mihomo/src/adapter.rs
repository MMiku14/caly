use std::collections::BTreeMap;

use caly_cap::{
    CapabilityDescriptor, CapabilityDomain, CapabilityKey, CapabilityState, Constraint,
    EvidenceRef, FallbackPolicy, SupportLevel,
};
use caly_core::{
    artifact_digest, stable_checksum_text, ApplyPlanningResult, CapabilitySet, CoreAdapter,
    CoreIdentity, CoreIssue, CoreKind, IssueLevel, NativeValidationReport, RuntimeDriver,
};
use caly_ir::{
    CompiledArtifact, NativeConfigFormat, ProxyProtocol, ResolvedProfile, RuleAction, StableBytes,
};
use caly_plan::{
    ApplyIssue, ApplyIssueLevel, ApplyPlan, ApplyPlanKind, BlobRef, CoreCall,
    CoreKind as PlanCoreKind, CoreSpec, DeployImpact, Durability, EffectPlan, EffectStep, FileMode,
    InstanceId, NetworkPlan, PlanId, PrivilegeSet, ProbeKind, ProbeSpec, SnapshotId,
};

use crate::runtime::MihomoRuntimeDriver;

#[derive(Default)]
pub struct MihomoAdapter;

impl CoreAdapter for MihomoAdapter {
    fn inspect_binary(&self) -> Result<CoreIdentity, String> {
        Ok(CoreIdentity {
            kind: CoreKind::Mihomo,
            version: "1.0.0-skeleton".to_owned(),
            build: Some("mihomo".to_owned()),
            binary_digest: MIHOMO_BINARY_SHA256.to_owned(),
        })
    }

    fn capability_set(&self, _identity: &CoreIdentity) -> Result<CapabilitySet, String> {
        Ok(CapabilitySet {
            descriptors: vec![
                capability(
                    "dns.fake_ip",
                    "Mihomo Fake-IP",
                    CapabilityDomain::Dns,
                    SupportLevel::CalyManaged,
                    CapabilityState::SupportedExact,
                    vec![Constraint {
                        field: "mode".to_owned(),
                        expected: "fake-ip".to_owned(),
                    }],
                    None,
                    vec!["mihomo dns fake-ip is modeled directly".to_owned()],
                ),
                capability(
                    "runtime.group.select",
                    "Mihomo runtime group select",
                    CapabilityDomain::Runtime,
                    SupportLevel::CalyManaged,
                    CapabilityState::SupportedExact,
                    Vec::new(),
                    None,
                    vec!["mihomo supports controller-driven group selection".to_owned()],
                ),
                capability(
                    "routing.rules",
                    "Mihomo rule routing",
                    CapabilityDomain::Routing,
                    SupportLevel::CalyManaged,
                    CapabilityState::SupportedExact,
                    Vec::new(),
                    None,
                    vec!["mihomo supports rule routing in this slice".to_owned()],
                ),
                capability(
                    "network.tun",
                    "Mihomo TUN",
                    CapabilityDomain::Tun,
                    SupportLevel::CalyManaged,
                    CapabilityState::SupportedExact,
                    Vec::new(),
                    Some(FallbackPolicy::EscalateToRestart),
                    vec!["tun implies network side effects and restart".to_owned()],
                ),
            ],
        })
    }

    fn preflight(
        &self,
        profile: &ResolvedProfile,
        _capabilities: &CapabilitySet,
    ) -> Result<Vec<CoreIssue>, String> {
        let mut issues = vec![CoreIssue {
            level: if profile.nodes.is_empty() {
                IssueLevel::Warning
            } else {
                IssueLevel::Info
            },
            code: "MIHOMO_PREFLIGHT".to_owned(),
            summary: "mihomo adapter preflight executed".to_owned(),
        }];

        if profile.groups.is_empty() {
            issues.push(CoreIssue {
                level: IssueLevel::Warning,
                code: "MIHOMO_EMPTY_GROUPS".to_owned(),
                summary: "mihomo compile path prefers at least one proxy group".to_owned(),
            });
        }

        Ok(issues)
    }

    fn compile(
        &self,
        profile: &ResolvedProfile,
        _capabilities: &CapabilitySet,
    ) -> Result<CompiledArtifact, String> {
        let bytes = render_mihomo_yaml(profile);
        let mut annotations = common_annotations(profile);
        annotations.insert("core.kind".to_owned(), "mihomo".to_owned());
        // The identity a core is asked to confirm at apply time must be the artifact it
        // is actually handed (CoreSpec::config_digest), not a digest of the semantic
        // profile. Deriving it from the semantic digest made the ConfigIdentity probe
        // unanswerable: it could never match, for any plan.
        let artifact_digest = artifact_digest("mihomo", &bytes);
        annotations.insert("config.identity".to_owned(), artifact_digest.0.clone());

        Ok(CompiledArtifact {
            profile_id: profile.profile_id.clone(),
            target_core: CoreKind::Mihomo.target(),
            adapter_version: 1,
            artifact_digest,
            file_name_hint: format!("{}.mihomo.yaml", profile.profile_id.0),
            format: NativeConfigFormat::Yaml,
            entrypoint: "config.yaml".to_owned(),
            media_type: "application/x-yaml".to_owned(),
            bytes,
            annotations,
        })
    }

    fn validate_native(
        &self,
        artifact: &CompiledArtifact,
    ) -> Result<NativeValidationReport, String> {
        let body = String::from_utf8_lossy(&artifact.bytes.bytes);
        let accepted = body.contains("proxy-groups:") && body.contains("proxies:");
        let mut issues = vec![CoreIssue {
            level: IssueLevel::Info,
            code: "MIHOMO_NATIVE_VALIDATE".to_owned(),
            summary: format!("mihomo validated {}", artifact.file_name_hint),
        }];

        if !accepted {
            issues.push(CoreIssue {
                level: IssueLevel::Error,
                code: "MIHOMO_NATIVE_REJECTED".to_owned(),
                summary: "mihomo native validation expected proxies and proxy-groups sections"
                    .to_owned(),
            });
        }

        Ok(NativeValidationReport { accepted, issues })
    }

    fn plan_apply(
        &self,
        current: Option<&CompiledArtifact>,
        next: &CompiledArtifact,
    ) -> Result<ApplyPlanningResult, String> {
        let selection_only = current
            .map(|artifact| selection_only_change(artifact, next))
            .unwrap_or(false);
        let tun_enabled = annotation_bool(next, "tun.enabled");

        // A different profile materializes at a different path (`runtime/<profile>/…`),
        // and a reload re-reads the core's OWN config path — so a cross-profile change can
        // only be honest as a restart (round 56). Without this check a profile switch
        // planned `HotReload`, which would reload the OLD file and then fail the identity
        // probe: right answer, wrong place — the plan kind should not set up a probe to
        // fail when the restart shape was available.
        let cross_profile = current
            .map(|artifact| artifact.profile_id != next.profile_id)
            .unwrap_or(false);
        let kind = if current
            .map(|artifact| artifact.artifact_digest == next.artifact_digest)
            .unwrap_or(false)
        {
            ApplyPlanKind::Noop
        } else if selection_only {
            ApplyPlanKind::ApiPatch
        } else if current.is_some() && !tun_enabled && !cross_profile {
            ApplyPlanKind::HotReload
        } else {
            ApplyPlanKind::Restart
        };

        let impact = match kind {
            ApplyPlanKind::Noop => DeployImpact::Noop,
            ApplyPlanKind::ApiPatch => DeployImpact::RuntimePatch,
            ApplyPlanKind::HotReload => DeployImpact::Reload,
            ApplyPlanKind::Restart => {
                if tun_enabled {
                    DeployImpact::NetworkChange
                } else {
                    DeployImpact::Restart
                }
            }
            ApplyPlanKind::RebuildAndRestart => DeployImpact::RebuildAndRestart,
        };
        let requires = PrivilegeSet {
            needs_admin: tun_enabled,
            needs_network_control: tun_enabled,
            needs_process_control: !matches!(kind, ApplyPlanKind::Noop | ApplyPlanKind::ApiPatch),
            needs_secret_access: false,
        };
        let reasons = plan_reasons(current, next, kind);
        let effect_plan = build_effect_plan(kind, current, next, impact, requires.clone());

        Ok(ApplyPlanningResult {
            apply_plan: ApplyPlan {
                kind,
                impact,
                requires,
                issues: vec![ApplyIssue {
                    level: ApplyIssueLevel::Info,
                    code: "MIHOMO_APPLY_PLAN".to_owned(),
                    summary: format!("mihomo selected {:?}", kind),
                }],
                reasons,
            },
            effect_plan,
        })
    }

    fn runtime(&self) -> Result<Box<dyn RuntimeDriver>, String> {
        Ok(Box::new(MihomoRuntimeDriver::default()))
    }
}

fn capability(
    key: &str,
    title: &str,
    domain: CapabilityDomain,
    support_level: SupportLevel,
    state: CapabilityState,
    constraints: Vec<Constraint>,
    fallback: Option<FallbackPolicy>,
    notes: Vec<String>,
) -> CapabilityDescriptor {
    CapabilityDescriptor {
        key: CapabilityKey(key.to_owned()),
        title: title.to_owned(),
        domain,
        support_level,
        state,
        constraints,
        fallback,
        evidence_ref: EvidenceRef {
            fixture_id: Some(format!("mihomo-{key}")),
            golden_test_id: None,
            native_validation_test_id: None,
            runtime_test_id: None,
        },
        notes,
    }
}

/// The sha256 of the workspace's pinned mihomo asset
/// (`assets/cores/mihomo-linux-amd64-v1.19.30.gz`), pinned byte-for-byte by
/// `crates/caly-io-std/tests/real_core.rs`. Round 56 (`ADR-044 §5.1` closed): the plan
/// carries the real digest, so a backend holding a different binary refuses the mismatch
/// by name instead of running whatever it happens to have.
pub const MIHOMO_BINARY_SHA256: &str =
    "cf06ce2c7d1421bdbda14ee4a5b6046672dc35ebf8eecd8e77504ec3c0ed9a84";

fn render_mihomo_yaml(profile: &ResolvedProfile) -> StableBytes {
    let mut lines = vec![
        format!("mode: {}", routing_mode_name(profile.routing_mode)),
        format!("profile-name: {}", profile.profile_id.0),
        // No `mixed-port` here (round 55): the listen port is a deployment fact, so the
        // real effect runtime owns it in its envelope (`caly-daemon/src/effect_std.rs`) —
        // one owner per key, or the core refuses the merged config.
        "allow-lan: false".to_owned(),
        "proxies:".to_owned(),
    ];

    for node in &profile.nodes {
        lines.push(format!("  - name: {}", node.label));
        lines.push(format!("    type: {}", proxy_protocol_name(node.protocol)));
        lines.push(format!("    server: {}", node.server));
        lines.push(format!("    port: {}", node.port));
        // Protocol params ride in `passthrough` (round 55): the keys a real core demands
        // per protocol (ss cipher/password, vmess uuid/alterId, …) — emitted verbatim and
        // sorted, because a node without them is a config the core refuses to parse, and
        // inventing them here silently would be the same lie in the other direction.
        for (key, value) in &node.passthrough {
            lines.push(format!("    {key}: {value}"));
        }
    }

    lines.push("proxy-groups:".to_owned());
    for group in &profile.groups {
        lines.push(format!("  - name: {}", group.label));
        lines.push(format!("    type: {}", group_type_name(group.kind)));
        // A `selected` member is a *selection*, and mihomo has no group field for one —
        // `interface-name` names an outbound interface, which a NodeId is not (round 55
        // removed that line: it parsed, but it bound traffic to an interface that does not
        // exist). Selection reaches the core through group ordering (first = default).
        let _ = &group.selected;
        lines.push("    proxies:".to_owned());
        for member in &group.members {
            let label = profile
                .nodes
                .iter()
                .find(|node| node.id == *member)
                .map(|node| node.label.clone())
                .unwrap_or_else(|| member.0.clone());
            lines.push(format!("      - {}", label));
        }
    }

    lines.push("rules:".to_owned());
    for rule in &profile.rules {
        // A rule's target must name a proxy/group exactly as rendered above — the group's
        // LABEL, not its id (round 55: ids parsed fine on the simulator and were refused
        // by the real core with `proxy not found`). An id that matches no rendered group
        // passes through verbatim, which the core will refuse loudly rather than silently.
        let target = rule
            .target_group
            .as_ref()
            .map(|group_id| {
                profile
                    .groups
                    .iter()
                    .find(|group| &group.id == group_id)
                    .map(|group| group.label.clone())
                    .unwrap_or_else(|| group_id.0.clone())
            })
            .unwrap_or_else(|| rule_action_name(rule.action).to_owned());
        lines.push(format!("  - {},{}", rule.matcher, target));
    }

    if let Some(dns) = &profile.dns {
        lines.push("dns:".to_owned());
        lines.push("  enable: true".to_owned());
        lines.push(format!("  enhanced-mode: {}", dns_mode_name(dns.mode)));
        lines.push("  nameserver:".to_owned());
        for server in &dns.servers {
            lines.push(format!("    - {}", server));
        }
    }

    if let Some(tun) = &profile.tun {
        lines.push("tun:".to_owned());
        lines.push(format!("  enable: {}", tun.enabled));
        lines.push(format!("  auto-route: {}", tun.auto_route));
        lines.push(format!("  strict-route: {}", tun.strict_route));
    }

    StableBytes::new(lines.join("\n").into_bytes())
}

fn common_annotations(profile: &ResolvedProfile) -> BTreeMap<String, String> {
    let mut annotations = BTreeMap::new();
    annotations.insert(
        "semantic_digest".to_owned(),
        profile.semantic_digest.0.clone(),
    );
    annotations.insert(
        "routing.mode".to_owned(),
        routing_mode_name(profile.routing_mode).to_owned(),
    );
    annotations.insert(
        "tun.enabled".to_owned(),
        profile
            .tun
            .as_ref()
            .map(|tun| tun.enabled)
            .unwrap_or(false)
            .to_string(),
    );
    annotations.insert("selection_digest".to_owned(), selection_digest(profile));
    annotations.insert("selections".to_owned(), selection_pairs(profile).join(","));
    annotations
}

fn selection_digest(profile: &ResolvedProfile) -> String {
    format!(
        "sel:{:016x}",
        stable_checksum_text(&selection_pairs(profile).join("|"))
    )
}

fn selection_pairs(profile: &ResolvedProfile) -> Vec<String> {
    profile
        .groups
        .iter()
        .map(|group| {
            format!(
                "{}={}",
                group.id.0,
                group
                    .selected
                    .as_ref()
                    .map(|node| node.0.clone())
                    .unwrap_or_else(|| "none".to_owned())
            )
        })
        .collect()
}

fn selection_only_change(current: &CompiledArtifact, next: &CompiledArtifact) -> bool {
    current.annotations.get("semantic_digest") == next.annotations.get("semantic_digest")
        && current.annotations.get("selection_digest") != next.annotations.get("selection_digest")
}

fn annotation_bool(artifact: &CompiledArtifact, key: &str) -> bool {
    artifact
        .annotations
        .get(key)
        .map(|value| value == "true")
        .unwrap_or(false)
}

fn plan_reasons(
    current: Option<&CompiledArtifact>,
    next: &CompiledArtifact,
    kind: ApplyPlanKind,
) -> Vec<String> {
    let mut reasons = vec![format!("target core={}", next.target_core_string())];
    match current {
        None => reasons.push("no active artifact exists; first deployment needs spawn".to_owned()),
        Some(previous) if previous.artifact_digest == next.artifact_digest => {
            reasons.push("artifact digest is unchanged".to_owned())
        }
        Some(previous) if selection_only_change(previous, next) => {
            reasons.push("only runtime group selections changed".to_owned())
        }
        Some(_) => reasons.push("native configuration content changed".to_owned()),
    }

    if annotation_bool(next, "tun.enabled") {
        reasons.push("tun is enabled; network state must be coordinated".to_owned());
    }

    reasons.push(format!("selected apply plan kind={kind:?}"));
    reasons
}

fn build_effect_plan(
    kind: ApplyPlanKind,
    current: Option<&CompiledArtifact>,
    next: &CompiledArtifact,
    impact: DeployImpact,
    requires: PrivilegeSet,
) -> Option<EffectPlan> {
    if matches!(kind, ApplyPlanKind::Noop) {
        return None;
    }

    let instance = InstanceId("mihomo-core-instance".to_owned());
    let snapshot = SnapshotId(format!("mihomo-snapshot-{}", next.profile_id.0));
    let core_spec = CoreSpec {
        kind: PlanCoreKind::Mihomo,
        binary_digest: MIHOMO_BINARY_SHA256.to_owned(),
        config_digest: next.artifact_digest.0.clone(),
    };
    let blob = BlobRef {
        digest: next.artifact_digest.0.clone(),
        size_hint: Some(next.size_bytes() as u64),
    };

    let mut steps = vec![
        EffectStep::WriteObject {
            digest: next.artifact_digest.0.clone(),
            source: blob,
            durability: Durability::D2,
        },
        EffectStep::MaterializeArtifact {
            digest: next.artifact_digest.0.clone(),
            at: format!("runtime/{}/{}", next.profile_id.0, next.entrypoint),
            mode: FileMode::ReadOnlyArtifact,
        },
    ];

    if annotation_bool(next, "tun.enabled") {
        steps.push(EffectStep::NetApply {
            plan: NetworkPlan {
                summary: "configure TUN + route ownership for mihomo".to_owned(),
                requires_privilege: true,
            },
        });
    }

    match kind {
        ApplyPlanKind::ApiPatch => {
            for (group_id, node_id) in selection_delta(current, next) {
                steps.push(EffectStep::CoreApiCall {
                    instance: instance.clone(),
                    call: CoreCall::SelectProxy { group_id, node_id },
                });
            }
        }
        ApplyPlanKind::HotReload => {
            steps.push(EffectStep::CoreApiCall {
                instance: instance.clone(),
                call: CoreCall::Reload,
            });
        }
        ApplyPlanKind::Restart | ApplyPlanKind::RebuildAndRestart => {
            if current.is_some() {
                steps.push(EffectStep::StopCore {
                    instance: instance.clone(),
                    grace_ms: 2_500,
                });
            }
            steps.push(EffectStep::SpawnCore { spec: core_spec });
        }
        ApplyPlanKind::Noop => {}
    }

    steps.push(EffectStep::Probe {
        probe: ProbeSpec {
            kind: ProbeKind::ApiReady,
            target: None,
        },
        deadline_ms: 3_000,
    });
    // Round 59 (`ADR-047 §3`): the controller answering is not the proxy door being
    // open — the two come up milliseconds apart, and a completed apply must mean both.
    steps.push(EffectStep::Probe {
        probe: ProbeSpec {
            kind: ProbeKind::InboundListening,
            target: None,
        },
        deadline_ms: 3_000,
    });
    steps.push(EffectStep::Probe {
        probe: ProbeSpec {
            kind: ProbeKind::ConfigIdentity,
            target: next.annotations.get("config.identity").cloned(),
        },
        deadline_ms: 3_000,
    });
    steps.push(EffectStep::MarkSnapshot {
        snapshot_id: snapshot,
    });
    steps.push(EffectStep::CommitRevision { revision: 1 });

    let mut compensations = Vec::new();
    if annotation_bool(next, "tun.enabled") {
        compensations.push(EffectStep::NetRevert {
            txn_id: caly_plan::NetTxnId("mihomo-net-revert".to_owned()),
        });
    }
    if current.is_some() {
        compensations.push(EffectStep::CoreApiCall {
            instance: instance.clone(),
            call: CoreCall::Reload,
        });
    }
    // Round 55: a plan that spawns a core must be able to un-spawn it, and one that
    // materialized an artifact must be able to un-materialize it. Before this, rollback
    // of a spawned plan compensated *nothing* on a real host — the plan said "recovered"
    // and left the core running. The list is executed in reverse, so appending puts the
    // stop first: kill the new core, then remove the file it ran from.
    if matches!(
        kind,
        ApplyPlanKind::Restart | ApplyPlanKind::RebuildAndRestart
    ) {
        compensations.push(EffectStep::MaterializeArtifact {
            digest: next.artifact_digest.0.clone(),
            at: format!("runtime/{}/{}", next.profile_id.0, next.entrypoint),
            mode: FileMode::ReadOnlyArtifact,
        });
        compensations.push(EffectStep::StopCore {
            instance: instance.clone(),
            grace_ms: 2_500,
        });
    }

    Some(EffectPlan {
        id: PlanId(format!("mihomo-effect-plan-{}", next.profile_id.0)),
        steps,
        compensations,
        requires,
        impact,
    })
}

fn selection_delta(
    current: Option<&CompiledArtifact>,
    next: &CompiledArtifact,
) -> Vec<(String, String)> {
    let current_pairs = current
        .and_then(|artifact| artifact.annotations.get("selections"))
        .map(|value| parse_selection_pairs(value))
        .unwrap_or_default();
    let next_pairs = next
        .annotations
        .get("selections")
        .map(|value| parse_selection_pairs(value))
        .unwrap_or_default();

    next_pairs
        .into_iter()
        .filter(|(group_id, node_id)| current_pairs.get(group_id) != Some(node_id))
        .collect()
}

fn parse_selection_pairs(value: &str) -> BTreeMap<String, String> {
    let mut pairs = BTreeMap::new();
    for entry in value.split(',') {
        if entry.is_empty() {
            continue;
        }
        let mut parts = entry.splitn(2, '=');
        let Some(group_id) = parts.next() else {
            continue;
        };
        let Some(node_id) = parts.next() else {
            continue;
        };
        pairs.insert(group_id.to_owned(), node_id.to_owned());
    }
    pairs
}

fn proxy_protocol_name(protocol: ProxyProtocol) -> &'static str {
    match protocol {
        ProxyProtocol::Shadowsocks => "ss",
        ProxyProtocol::Vmess => "vmess",
        ProxyProtocol::Vless => "vless",
        ProxyProtocol::Trojan => "trojan",
        ProxyProtocol::Hysteria2 => "hysteria2",
        ProxyProtocol::Tuic => "tuic",
        ProxyProtocol::WireGuard => "wireguard",
        ProxyProtocol::Unknown => "unknown",
    }
}

fn group_type_name(kind: caly_ir::GroupType) -> &'static str {
    match kind {
        caly_ir::GroupType::Select => "select",
        caly_ir::GroupType::UrlTest => "url-test",
        caly_ir::GroupType::Fallback => "fallback",
        caly_ir::GroupType::LoadBalance => "load-balance",
        caly_ir::GroupType::Relay => "relay",
    }
}

fn rule_action_name(action: RuleAction) -> &'static str {
    match action {
        RuleAction::UseGroup => "MATCH",
        RuleAction::Direct => "DIRECT",
        RuleAction::Reject => "REJECT",
        RuleAction::UseOutbound => "OUTBOUND",
    }
}

fn routing_mode_name(mode: caly_ir::RoutingMode) -> &'static str {
    match mode {
        caly_ir::RoutingMode::Rule => "rule",
        caly_ir::RoutingMode::Global => "global",
        caly_ir::RoutingMode::Direct => "direct",
    }
}

fn dns_mode_name(mode: caly_ir::DnsMode) -> &'static str {
    match mode {
        // mihomo v1.19.30 accepts exactly `fake-ip`, `redir-host` and `normal` (verified
        // against the binary; `system` and `mixed` are refused as `invalid mode`). The IR's
        // enum is finer than the core's, so System and Mixed collapse onto `normal` — the
        // no-fake-ip default — rather than emitting a value the core rejects.
        caly_ir::DnsMode::System => "normal",
        caly_ir::DnsMode::FakeIp => "fake-ip",
        caly_ir::DnsMode::Redirect => "redir-host",
        caly_ir::DnsMode::Mixed => "normal",
    }
}

trait ArtifactExt {
    fn target_core_string(&self) -> &'static str;
}

impl ArtifactExt for CompiledArtifact {
    fn target_core_string(&self) -> &'static str {
        match self.target_core {
            caly_ir::CoreTarget::Mihomo => "mihomo",
            caly_ir::CoreTarget::SingBox => "sing-box",
            caly_ir::CoreTarget::Auto => "auto",
        }
    }
}
