use caly_domain::{
    attach_group_selection, attach_sources, replace_tun, skeleton_profile, source_ref,
};
use caly_ir::{normalized_source_stub, CoreTarget, RoutingMode};
use caly_pipeline::{run_pipeline_for_adapter, PipelineRequest, StageContext};

use crate::adapter::MihomoAdapter;

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct MihomoVerticalSlice {
    pub artifact_hint: String,
    pub artifact_bytes: usize,
    pub accepted: bool,
    pub apply_plan_kind: String,
    pub effect_step_count: usize,
    pub issue_count: usize,
    pub diagnostic_count: usize,
}

pub fn run_mihomo_vertical_slice(
    profile_label: impl Into<String>,
) -> Result<MihomoVerticalSlice, String> {
    let profile = attach_group_selection(
        attach_sources(
            replace_tun(
                skeleton_profile(
                    "mihomo-profile",
                    profile_label,
                    CoreTarget::Mihomo,
                    RoutingMode::Rule,
                ),
                true,
                true,
                false,
            ),
            vec![source_ref("source-01", "Primary Source")],
        ),
        "source-01-group-main",
        "Primary Source Shadowsocks 01",
    );

    let request = PipelineRequest {
        profile,
        source_inputs: Vec::new(),
        normalized_sources: vec![normalized_source_stub("source-01", "Primary Source")],
        overrides: Vec::new(),
        selection_memory: None,
        strict_mode: false,
    };

    let adapter = MihomoAdapter;
    let output = run_pipeline_for_adapter(
        request,
        StageContext {
            pipeline_epoch: 1,
            adapter_version: 1,
            strict_mode: false,
        },
        &adapter,
        None,
    )?;

    let compile = output
        .compile
        .ok_or_else(|| "mihomo slice produced no compile output".to_owned())?;
    let effect_step_count = compile
        .apply_planning
        .effect_plan
        .as_ref()
        .map(|plan| plan.steps.len())
        .unwrap_or(0);

    Ok(MihomoVerticalSlice {
        artifact_hint: compile.artifact.file_name_hint.clone(),
        artifact_bytes: compile.artifact.size_bytes(),
        accepted: compile.native_validation.accepted,
        apply_plan_kind: format!("{:?}", compile.apply_planning.apply_plan.kind),
        effect_step_count,
        issue_count: compile.preflight_issues.len() + compile.native_validation.issues.len(),
        diagnostic_count: output.diagnostics.len(),
    })
}
