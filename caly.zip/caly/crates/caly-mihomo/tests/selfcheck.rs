//! Round 59 (`ADR-047 §4`): the core's OWN validator judges the render, and the demo
//! credential stays inside the artifact.
//!
//! Two judges:
//!
//! * **selfcheck** — the artifact the adapter renders must pass `mihomo -t`: the binary's
//!   own config checker, not our own opinion of the shape. Schema drift in the render
//!   surfaces here as a refused test, before any spawn path reaches it.
//! * **credential boundary** — the demo password ("caly-demo") must live in the artifact
//!   bytes (the core needs real values to parse; `ADR-047 §4`) and NOWHERE else the
//!   pipeline produces: not the manifest, not the annotations. Words about a config are
//!   not the config.
//!
//! The binary invocations are the deliberate exceptions to the no-ad-hoc-process rule,
//! same doctrine as `pinned_asset.rs`: the whole point is asking the pinned core itself.

use caly_domain::{attach_group_selection, attach_sources, skeleton_profile, source_ref};
use caly_ir::{normalized_source_stub, CoreTarget, RoutingMode};
use caly_mihomo::MihomoAdapter;
use caly_pipeline::{run_pipeline_for_adapter, PipelineRequest, StageContext};

fn compiled_artifact() -> caly_ir::CompiledArtifact {
    let profile = attach_group_selection(
        attach_sources(
            skeleton_profile(
                "mihomo-selfcheck",
                "Selfcheck",
                CoreTarget::Mihomo,
                RoutingMode::Rule,
            ),
            vec![source_ref("source-01", "Primary Source")],
        ),
        "source-01-group-main",
        "Primary Source Shadowsocks 01",
    );
    let request = PipelineRequest {
        profile,
        source_inputs: Vec::new(),
        normalized_sources: vec![normalized_source_stub("source-01", "Primary Source")],
        overrides: Vec::new(),
        selection_memory: None,
        strict_mode: false,
    };
    let output = run_pipeline_for_adapter(
        request,
        StageContext {
            pipeline_epoch: 1,
            adapter_version: 1,
            strict_mode: false,
        },
        &MihomoAdapter,
        None,
    )
    .expect("the pipeline runs");
    output
        .compile
        .expect("the compile stage produces an artifact")
        .artifact
}

fn workspace_root() -> String {
    let manifest = env!("CARGO_MANIFEST_DIR");
    manifest[..manifest.len() - "crates/caly-mihomo".len()].to_owned()
}

/// The render must survive `mihomo -t` — the core's own verdict on the config we hand it.
#[expect(clippy::disallowed_methods)]
#[test]
fn the_rendered_artifact_passes_the_cores_own_config_test() {
    let artifact = compiled_artifact();
    let target_dir =
        std::env::var("CARGO_TARGET_TMPDIR").unwrap_or_else(|_| "target/tmp".to_owned());
    let root = format!("{target_dir}/mihomo-selfcheck-{}", std::process::id());
    let _ = std::fs::remove_dir_all(&root);
    std::fs::create_dir_all(&root).expect("scratch");

    std::fs::write(format!("{root}/config.yaml"), &artifact.bytes.bytes)
        .expect("write the artifact");
    let asset = format!(
        "{}assets/cores/mihomo-linux-amd64-v1.19.30.gz",
        workspace_root()
    );
    let extract = std::process::Command::new("/bin/sh")
        .arg("-c")
        .arg(format!(
            "gunzip -c {asset} > {root}/core && chmod +x {root}/core"
        ))
        .output()
        .expect("extract the pinned core");
    assert!(
        extract.status.success(),
        "extracting the pinned asset failed: {}",
        String::from_utf8_lossy(&extract.stderr)
    );

    let verdict = std::process::Command::new(format!("{root}/core"))
        .arg("-t")
        .arg("-f")
        .arg(format!("{root}/config.yaml"))
        .output()
        .expect("run the core's own config test");
    let spoken = format!(
        "{}{}",
        String::from_utf8_lossy(&verdict.stdout),
        String::from_utf8_lossy(&verdict.stderr)
    );
    assert!(
        verdict.status.success() && spoken.contains("successful"),
        "mihomo -t must accept the rendered artifact:\n{spoken}"
    );
    let _ = std::fs::remove_dir_all(&root);
}

/// The demo credential lives in the artifact bytes and nowhere else the pipeline emits.
#[test]
fn the_demo_credential_stays_inside_the_artifact() {
    let artifact = compiled_artifact();
    let body = String::from_utf8_lossy(&artifact.bytes.bytes);
    assert!(
        body.contains("caly-demo"),
        "the artifact must carry the structural password the core needs to parse"
    );
    for (key, value) in &artifact.annotations {
        assert!(
            !value.contains("caly-demo"),
            "an annotation ({key}) must not carry the credential: {value}"
        );
    }
    // The manifest is the words ABOUT the config; it must not be the config.
    let manifest = compiled_manifest();
    assert!(
        !manifest.contains("caly-demo"),
        "the manifest must not carry the credential:\n{manifest}"
    );
}

fn compiled_manifest() -> String {
    let profile = attach_sources(
        skeleton_profile(
            "mihomo-selfcheck",
            "Selfcheck",
            CoreTarget::Mihomo,
            RoutingMode::Rule,
        ),
        vec![source_ref("source-01", "Primary Source")],
    );
    let request = PipelineRequest {
        profile,
        source_inputs: Vec::new(),
        normalized_sources: vec![normalized_source_stub("source-01", "Primary Source")],
        overrides: Vec::new(),
        selection_memory: None,
        strict_mode: false,
    };
    let output = run_pipeline_for_adapter(
        request,
        StageContext {
            pipeline_epoch: 1,
            adapter_version: 1,
            strict_mode: false,
        },
        &MihomoAdapter,
        None,
    )
    .expect("the pipeline runs");
    String::from_utf8_lossy(
        &output
            .resolved_profile
            .generated_bytes
            .expect("resolve renders a manifest")
            .bytes,
    )
    .into_owned()
}
