use std::collections::BTreeMap;

use caly_api::JobId;

use crate::command::{Command, CommandId, IdempotencyKey};
use crate::event::EventLog;
use crate::idempotency::IdempotencyTable;
use crate::job::{JobRecord, JobState};
use crate::queue::{CommandQueue, QueuePolicy, QueuePushResult};

#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub enum EngineLifecycle {
    Idle,
    Busy,
    Recovering,
    Failed,
}

#[derive(Clone, Copy, Debug, Eq, PartialEq, Ord, PartialOrd, Hash)]
pub struct EngineGeneration(pub u64);

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct QueuedCommand {
    pub job_id: JobId,
    pub command: Command,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub enum EnqueueResult {
    Accepted,
    RejectedFull { max_len: usize },
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct EngineState {
    pub lifecycle: Option<EngineLifecycle>,
    pub generation: u64,
    pub next_job_id: u64,
    pub queue: CommandQueue,
    pub queued_commands: BTreeMap<u64, Command>,
    pub jobs: BTreeMap<u64, JobRecord>,
    pub automation_overrides: BTreeMap<String, bool>,
    pub idempotency: IdempotencyTable,
    pub events: EventLog,
    /// The last `EffectPlan` that was executed to completion, kept so that a rollback
    /// command can run its compensations instead of only reporting a skeleton outcome.
    pub last_effect_plan: Option<caly_plan::EffectPlan>,
    /// The artifact of the last **committed** apply (round 56, `ADR-044 §5.3`): the
    /// deployment truth the next plan is planned against. `None` until an apply commits —
    /// and again after a rollback, which lands the engine back at "nothing proven
    /// deployed" rather than at a guess.
    pub last_compiled_artifact: Option<caly_ir::CompiledArtifact>,
    /// Latest successful source normalizations, keyed by source id. A subsequent apply may
    /// consume these exact nodes; an empty cache never authorizes a guessed URL or node.
    pub source_cache: BTreeMap<String, caly_ir::NormalizedSource>,
    /// Which snapshot the deployment is on, as the engine learned it from the commit that made it
    /// active.
    ///
    /// `ADR-038 §1` had the *daemon* pass this to the GC plan; §8 moves it here, because both
    /// daemon-side assignments derive it from `latest_last_known_good` -- a copy a caller must remember
    /// to update is how a root set quietly stops protecting the running deployment (`docs/ONBOARDING_NOTES.md §4.81`).
    /// `None` means "nothing has committed in this process", which is honest, and the plan then relies
    /// on the last-known-good root and says so.
    pub active_snapshot_id: Option<String>,
    /// The outcome of the last storage collection cycle, if one ran (`ADR-038 §2`).
    pub last_gc_run: Option<crate::gc_plan::GcRunRecord>,
    /// How many times the worker has found the queue empty (`ADR-038 §13.2`'s cadence input).
    ///
    /// **Monotone, never reset** -- the collector is due when this is a multiple of
    /// `IDLE_GC_INTERVAL_CHECKS`, and the automatic cycle's idempotency key is derived from it. A
    /// counter that restarted on fire would hand the second cycle the first cycle's key, and dedup
    /// would swallow it: an idle collector that stops working after one pass and says nothing.
    pub idle_gc_checks: u64,
    /// Which job the last automatic cycle was scheduled for, if one is outstanding.
    ///
    /// A cycle compares this with its own job id to decide what to write into
    /// `GcRunRecord::triggered_by`, so the label cannot be stolen by a manual collection that happens
    /// to run next (a "clear the flag when it fires" design would put a second owner on this fact).
    pub idle_gc_claim: Option<caly_api::JobId>,
    /// The last capability verdict, so the support bundle can report what a deployment was
    /// actually allowed to do rather than only what the registry says is possible.
    pub last_capability_summary: Option<crate::apply::CapabilitySummary>,
    /// Which process this engine belongs to. Set by the composition root; the support bundle
    /// reports it because a bundle without a version and an instance is not actionable.
    pub bundle_identity: crate::bundle::BundleIdentity,
    /// Recent admission refusals, newest last, bounded so a flooding client cannot grow the
    /// diagnostics surface without limit. This is the `OVERLOAD_AND_RETRY_MODEL §7.2` outlet: the
    /// caller gets an `ApiError`, the operator gets to see how often and when.
    pub overloads: std::collections::VecDeque<crate::overload::OverloadReport>,
    /// Every refusal ever made, per class — the counter a bounded log cannot carry.
    pub overload_totals: BTreeMap<crate::overload::OverloadClass, usize>,
    /// The one redactor every operator-visible string in this engine passes through
    /// (`RFC-0010 §6.3`: the same path must mask the same way everywhere).
    pub redactor: caly_common::redact::Redactor,
}

impl Default for EngineState {
    fn default() -> Self {
        Self::new()
    }
}

impl EngineState {
    pub fn new() -> Self {
        Self {
            lifecycle: Some(EngineLifecycle::Idle),
            generation: 0,
            next_job_id: 1,
            queue: CommandQueue::with_policy(QueuePolicy::bounded(256)),
            queued_commands: BTreeMap::new(),
            jobs: BTreeMap::new(),
            automation_overrides: BTreeMap::new(),
            idempotency: IdempotencyTable::default(),
            events: EventLog::with_capacity(256),
            last_effect_plan: None,
            last_compiled_artifact: None,
            source_cache: BTreeMap::new(),
            active_snapshot_id: None,
            last_gc_run: None,
            idle_gc_checks: 0,
            idle_gc_claim: None,
            last_capability_summary: None,
            overloads: std::collections::VecDeque::new(),
            overload_totals: BTreeMap::new(),
            bundle_identity: crate::bundle::BundleIdentity::default(),
            redactor: caly_common::redact::Redactor::default(),
        }
    }

    pub fn next_job_id(&mut self) -> JobId {
        let next = self.next_job_id;
        self.next_job_id = self.next_job_id.saturating_add(1);
        JobId(next)
    }

    pub fn bump_generation(&mut self) -> EngineGeneration {
        self.generation = self.generation.saturating_add(1);
        EngineGeneration(self.generation)
    }

    pub fn insert_job(&mut self, record: JobRecord) {
        self.jobs.insert(record.id.0, record);
    }

    /// How many refusals the engine remembers. Bounded by `RECENT_OVERLOADS`.
    pub const RECENT_OVERLOADS: usize = 8;

    pub fn record_overload(&mut self, report: crate::overload::OverloadReport) {
        *self.overload_totals.entry(report.class).or_insert(0) += 1;
        if self.overloads.len() >= Self::RECENT_OVERLOADS {
            self.overloads.pop_front();
        }
        self.overloads.push_back(report);
    }

    /// The operator-facing summary of pressure, shared by `doctor` and the support bundle so the two
    /// surfaces cannot report different numbers for the same event.
    pub fn overload_lines(&self) -> Vec<String> {
        let recent: Vec<crate::overload::OverloadReport> = self.overloads.iter().cloned().collect();
        crate::overload::overload_lines(&recent, &self.overload_totals)
    }

    pub fn queue_capacity(&self) -> usize {
        self.queue.capacity()
    }

    pub fn enqueue(&mut self, job_id: JobId, command: Command) -> EnqueueResult {
        match self.queue.push(command.clone()) {
            QueuePushResult::Accepted => {
                self.queued_commands.insert(job_id.0, command);
                EnqueueResult::Accepted
            }
            QueuePushResult::RejectedFull { max_len } => EnqueueResult::RejectedFull { max_len },
        }
    }

    pub fn current_lifecycle(&self) -> EngineLifecycle {
        self.lifecycle.unwrap_or(EngineLifecycle::Idle)
    }

    pub fn set_lifecycle(&mut self, lifecycle: EngineLifecycle) {
        self.lifecycle = Some(lifecycle);
    }

    pub fn dequeue_next(&mut self) -> Option<QueuedCommand> {
        let entry = self.queue.pop()?;
        let command_id = entry.command.id.0.clone();
        let target_job_id = self.queued_commands.iter().find_map(|(job_id, command)| {
            if command.id.0 == command_id {
                Some(*job_id)
            } else {
                None
            }
        })?;
        let command = self.queued_commands.remove(&target_job_id)?;
        Some(QueuedCommand {
            job_id: JobId(target_job_id),
            command,
        })
    }

    pub fn get_job_mut(&mut self, job_id: JobId) -> Option<&mut JobRecord> {
        self.jobs.get_mut(&job_id.0)
    }

    pub fn mark_job_state(&mut self, job_id: JobId, state: JobState) {
        if let Some(record) = self.jobs.get_mut(&job_id.0) {
            record.state = state;
        }
    }

    pub fn has_command(&self, command_id: &CommandId) -> bool {
        self.queued_commands
            .values()
            .any(|command| &command.id == command_id)
    }

    pub fn has_idempotency_key(&self, key: &IdempotencyKey) -> bool {
        self.idempotency
            .get(caly_common::Actor::System, key)
            .is_some()
    }
}
