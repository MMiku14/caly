use caly_api::{ApiError, JobId};

#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub enum JobState {
    Accepted,
    Queued,
    Running,
    WaitingInput,
    Completed,
    Failed,
    Cancelled,
    TimedOut,
}

#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub enum JobOutcome {
    Succeeded,
    Failed,
    Cancelled,
    TimedOut,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub enum JobEvent {
    Stage { stage: String, pct: Option<u8> },
    Log { level: String, message: String },
    Warning { message: String },
    Done { outcome: JobOutcome },
    Failed { error: ApiError },
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct JobRecord {
    pub id: JobId,
    pub state: JobState,
    pub revision: u64,
    pub events: Vec<JobEvent>,
}
