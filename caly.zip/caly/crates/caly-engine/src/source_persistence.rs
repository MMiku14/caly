//! Typed persistence codec for the durable source index.
//!
//! `caly-storage` owns the atomic record envelope but deliberately does not depend upward on the
//! pipeline.  This module owns the versioned opaque values stored inside that envelope and refuses
//! any value it cannot reconstruct exactly.  The codec uses length-prefixed fields rather than a
//! separator, so labels, locators, diagnostics, and node parameters cannot change the meaning of a
//! record by containing a delimiter.
//!
//! Tag evolution (`ADR-061`): the v2 tags carry the **producing pipeline's epoch** inside the
//! anchored text (`normalized:v2:<epoch>`), so a cache written by an older pipeline is
//! detectable instead of staying byte-identical forever. Reading is forward-migrating: a
//! `v1` tag (the only tag any pre-v2 build wrote) decodes as **epoch 1** — the only epoch a
//! v1 writer ever ran, a historical fact rather than a guess — with no rewrite (the digest
//! anchors keep validating the stored bytes; the next update re-encodes at the current tag
//! inside the same atomic commit). A tag this build does not understand refuses **by name**,
//! found tag and supported list both in the message (`RFC-0007 §12.3`).

use std::collections::BTreeMap;

use caly_ir::{
    Digest, NodeId, NormalizedNode, NormalizedSource, ProxyProtocol, RawSource, SourceId,
    SourceKind,
};
use caly_pipeline::stage::{
    Diagnostic, DiagnosticSeverity, IrPath, Origin, Provenance, ProvenanceDelta, StageId,
};
use caly_storage::SourceIndexRecord;

use crate::source_worker::SourceUpdateReport;

const NORMALIZED_TAG_V1: &str = "normalized:v1";
const PROVENANCE_TAG_V1: &str = "provenance:v1";
const DIAGNOSTICS_TAG_V1: &str = "diagnostics:v1";
const NORMALIZED_TAG_V2: &str = "normalized:v2";
const PROVENANCE_TAG_V2: &str = "provenance:v2";
const DIAGNOSTICS_TAG_V2: &str = "diagnostics:v2";

/// The tag token a cache encoded by THIS build carries: `<family>:v2:<PIPELINE_EPOCH>`.
fn current_tag(v2: &str) -> String {
    format!("{v2}:{}", caly_pipeline::stage::PIPELINE_EPOCH)
}

/// Interpret one opaque cache's tag token: `v1` reads as epoch 1 (the only epoch any v1
/// writer ever ran — the migration's one historical fact, `ADR-061 §2.2`), `v2:<epoch>` as
/// its recorded epoch, anything else refuses BY NAME with the supported list.
fn decode_tag_epoch(found: &str, v1: &str, v2: &str) -> Result<u32, String> {
    if found == v1 {
        return Ok(1);
    }
    if let Some(rest) = found.strip_prefix(v2) {
        if let Some(digits) = rest.strip_prefix(':') {
            if let Ok(epoch) = digits.parse::<u32>() {
                return Ok(epoch);
            }
        }
    }
    Err(format!(
        "cache tag {found:?} is not understood by this build \
         (supported: {v1} and {v2}:<epoch>); a record this build never wrote"
    ))
}

/// Whether a restored record's caches were produced by the pipeline this build runs
/// (`ADR-061 §2.3`). A stale cache is not corruption: the record keeps its raw CAS and
/// locator facts, but its normalization must not flow into the engine as if it were current.
#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub(crate) enum CacheRecency {
    Current,
    Stale { recorded_epoch: u32 },
}

/// Encode a sequence without reserving a delimiter. Lengths are UTF-8 byte lengths, which makes
/// the parser unambiguous for both Unicode labels and arbitrary escaped text.
fn encode_sequence(values: &[String]) -> String {
    let mut output = String::new();
    for value in values {
        output.push_str(&value.len().to_string());
        output.push(':');
        output.push_str(value);
    }
    output
}

fn decode_sequence(text: &str, what: &str) -> Result<Vec<String>, String> {
    let mut values = Vec::new();
    let mut offset = 0usize;
    while offset < text.len() {
        let relative_colon = text[offset..]
            .find(':')
            .ok_or_else(|| format!("{what} has a length prefix without a colon"))?;
        let colon = offset + relative_colon;
        if colon == offset {
            return Err(format!("{what} has an empty length prefix"));
        }
        let length = text[offset..colon]
            .parse::<usize>()
            .map_err(|_| format!("{what} has a non-numeric length prefix"))?;
        let start = colon + 1;
        let end = start
            .checked_add(length)
            .ok_or_else(|| format!("{what} field length overflows"))?;
        let value = text
            .get(start..end)
            .ok_or_else(|| format!("{what} field ends in the middle of UTF-8 text"))?;
        values.push(value.to_owned());
        offset = end;
    }
    Ok(values)
}

fn require_fields<'a>(
    fields: &'a [String],
    expected: usize,
    what: &str,
) -> Result<&'a [String], String> {
    if fields.len() == expected {
        Ok(fields)
    } else {
        Err(format!(
            "{what} has {} fields; expected {expected}",
            fields.len()
        ))
    }
}

fn parse_usize(value: &str, field: &str) -> Result<usize, String> {
    value
        .parse::<usize>()
        .map_err(|_| format!("{field} is not a valid unsigned integer"))
}

fn parse_u16(value: &str, field: &str) -> Result<u16, String> {
    value
        .parse::<u16>()
        .map_err(|_| format!("{field} is not a valid port"))
}

fn source_kind_name(kind: SourceKind) -> &'static str {
    match kind {
        SourceKind::Subscription => "subscription",
        SourceKind::LocalFile => "local-file",
        SourceKind::Inline => "inline",
    }
}

fn source_kind(value: &str) -> Result<SourceKind, String> {
    match value {
        "subscription" => Ok(SourceKind::Subscription),
        "local-file" => Ok(SourceKind::LocalFile),
        "inline" => Ok(SourceKind::Inline),
        _ => Err("normalized source has an unknown source kind".to_owned()),
    }
}

fn protocol_name(protocol: ProxyProtocol) -> &'static str {
    match protocol {
        ProxyProtocol::Shadowsocks => "shadowsocks",
        ProxyProtocol::Vmess => "vmess",
        ProxyProtocol::Vless => "vless",
        ProxyProtocol::Trojan => "trojan",
        ProxyProtocol::Hysteria2 => "hysteria2",
        ProxyProtocol::Tuic => "tuic",
        ProxyProtocol::WireGuard => "wireguard",
        ProxyProtocol::Unknown => "unknown",
    }
}

fn protocol(value: &str) -> Result<ProxyProtocol, String> {
    match value {
        "shadowsocks" => Ok(ProxyProtocol::Shadowsocks),
        "vmess" => Ok(ProxyProtocol::Vmess),
        "vless" => Ok(ProxyProtocol::Vless),
        "trojan" => Ok(ProxyProtocol::Trojan),
        "hysteria2" => Ok(ProxyProtocol::Hysteria2),
        "tuic" => Ok(ProxyProtocol::Tuic),
        "wireguard" => Ok(ProxyProtocol::WireGuard),
        "unknown" => Ok(ProxyProtocol::Unknown),
        _ => Err("normalized node has an unknown protocol".to_owned()),
    }
}

pub(crate) fn encode_normalized(source: &NormalizedSource) -> String {
    let mut fields = vec![
        current_tag(NORMALIZED_TAG_V2),
        source.id.0.clone(),
        source.raw_digest.0.clone(),
        source_kind_name(source.source_kind).to_owned(),
        source.node_count_estimate.to_string(),
        source.group_count_estimate.to_string(),
        source.rule_count_estimate.to_string(),
        source.nodes.len().to_string(),
    ];
    for node in &source.nodes {
        let mut node_fields = vec![
            node.id.0.clone(),
            node.label.clone(),
            protocol_name(node.protocol).to_owned(),
            node.server.clone(),
            node.port.to_string(),
            node.passthrough.len().to_string(),
        ];
        for (key, value) in &node.passthrough {
            node_fields.push(key.clone());
            node_fields.push(value.clone());
        }
        fields.push(encode_sequence(&node_fields));
    }
    encode_sequence(&fields)
}

pub(crate) fn decode_normalized(encoded: &str) -> Result<(NormalizedSource, u32), String> {
    let fields = decode_sequence(encoded, "normalized cache")?;
    if fields.len() < 8 {
        return Err("normalized cache has an unsupported shape".to_owned());
    }
    let epoch = decode_tag_epoch(&fields[0], NORMALIZED_TAG_V1, NORMALIZED_TAG_V2)?;
    let node_count = parse_usize(&fields[7], "normalized node count")?;
    require_fields(&fields, 8 + node_count, "normalized cache")?;
    let mut nodes = Vec::with_capacity(node_count);
    for (index, encoded_node) in fields[8..].iter().enumerate() {
        let node_fields = decode_sequence(encoded_node, "normalized node")?;
        if node_fields.len() < 6 {
            return Err(format!("normalized node {index} is incomplete"));
        }
        let map_count = parse_usize(&node_fields[5], "normalized passthrough count")?;
        require_fields(&node_fields, 6 + map_count * 2, "normalized node")?;
        let mut passthrough = BTreeMap::new();
        for pair in node_fields[6..].chunks(2) {
            if passthrough
                .insert(pair[0].clone(), pair[1].clone())
                .is_some()
            {
                return Err(format!("normalized node {index} repeats a passthrough key"));
            }
        }
        let port = parse_u16(&node_fields[4], "normalized node port")?;
        if port == 0 {
            return Err(format!("normalized node {index} has port zero"));
        }
        nodes.push(NormalizedNode {
            id: NodeId::new(node_fields[0].clone()),
            label: node_fields[1].clone(),
            protocol: protocol(&node_fields[2])?,
            server: node_fields[3].clone(),
            port,
            passthrough,
        });
    }
    Ok((
        NormalizedSource {
            id: SourceId::new(fields[1].clone()),
            raw_digest: Digest(fields[2].clone()),
            source_kind: source_kind(&fields[3])?,
            node_count_estimate: parse_usize(&fields[4], "normalized node estimate")?,
            group_count_estimate: parse_usize(&fields[5], "normalized group estimate")?,
            rule_count_estimate: parse_usize(&fields[6], "normalized rule estimate")?,
            nodes,
        },
        epoch,
    ))
}

fn encode_option(value: Option<&str>) -> String {
    match value {
        Some(value) => encode_sequence(&["some".to_owned(), value.to_owned()]),
        None => encode_sequence(&["none".to_owned()]),
    }
}

fn decode_option(encoded: &str, what: &str) -> Result<Option<String>, String> {
    let fields = decode_sequence(encoded, what)?;
    match fields.as_slice() {
        [kind] if kind == "none" => Ok(None),
        [kind, value] if kind == "some" => Ok(Some(value.clone())),
        _ => Err(format!("{what} has an invalid optional value")),
    }
}

fn encode_path(path: &IrPath) -> String {
    let mut fields = vec![path.segments.len().to_string()];
    fields.extend(path.segments.iter().cloned());
    encode_sequence(&fields)
}

fn decode_path(encoded: &str, what: &str) -> Result<IrPath, String> {
    let fields = decode_sequence(encoded, what)?;
    if fields.is_empty() {
        return Err(format!("{what} has no segment count"));
    }
    let count = parse_usize(&fields[0], "provenance path segment count")?;
    require_fields(&fields, count + 1, what)?;
    Ok(IrPath {
        segments: fields[1..].to_vec(),
    })
}

fn encode_origin(origin: &Origin) -> String {
    match origin {
        Origin::Source { source_id, locator } => encode_sequence(&[
            "source".to_owned(),
            source_id.clone(),
            encode_option(locator.as_deref()),
        ]),
        Origin::Override { override_id } => {
            encode_sequence(&["override".to_owned(), override_id.clone()])
        }
        Origin::Default => encode_sequence(&["default".to_owned()]),
        Origin::Safety => encode_sequence(&["safety".to_owned()]),
    }
}

fn decode_origin(encoded: &str, what: &str) -> Result<Origin, String> {
    let fields = decode_sequence(encoded, what)?;
    let Some(kind) = fields.first() else {
        return Err(format!("{what} has no origin kind"));
    };
    match kind.as_str() {
        "source" => {
            require_fields(&fields, 3, what)?;
            Ok(Origin::Source {
                source_id: fields[1].clone(),
                locator: decode_option(&fields[2], "source locator")?,
            })
        }
        "override" => {
            require_fields(&fields, 2, what)?;
            Ok(Origin::Override {
                override_id: fields[1].clone(),
            })
        }
        "default" => {
            require_fields(&fields, 1, what)?;
            Ok(Origin::Default)
        }
        "safety" => {
            require_fields(&fields, 1, what)?;
            Ok(Origin::Safety)
        }
        _ => Err(format!("{what} has an unknown origin kind")),
    }
}

fn stage_name(stage: StageId) -> &'static str {
    stage.as_str()
}

fn stage(value: &str) -> Result<StageId, String> {
    match value {
        "INGEST" => Ok(StageId::Ingest),
        "DECODE" => Ok(StageId::Decode),
        "NORMALIZE" => Ok(StageId::Normalize),
        "IDENTIFY" => Ok(StageId::Identify),
        "MERGE" => Ok(StageId::Merge),
        "RESOLVE" => Ok(StageId::Resolve),
        "VALIDATE_SEMANTIC" => Ok(StageId::ValidateSemantic),
        "VALIDATE_CAPABILITY" => Ok(StageId::ValidateCapability),
        "LOWER" => Ok(StageId::Lower),
        "EMIT" => Ok(StageId::Emit),
        "VERIFY_NATIVE" => Ok(StageId::VerifyNative),
        _ => Err("provenance has an unknown stage".to_owned()),
    }
}

fn encode_stages(stages: &[StageId]) -> String {
    let mut fields = vec![stages.len().to_string()];
    fields.extend(stages.iter().map(|stage| stage_name(*stage).to_owned()));
    encode_sequence(&fields)
}

fn decode_stages(encoded: &str) -> Result<Vec<StageId>, String> {
    let fields = decode_sequence(encoded, "provenance transform")?;
    if fields.is_empty() {
        return Err("provenance transform has no stage count".to_owned());
    }
    let count = parse_usize(&fields[0], "provenance stage count")?;
    require_fields(&fields, count + 1, "provenance transform")?;
    fields[1..].iter().map(|value| stage(value)).collect()
}

fn encode_provenance_entry(entry: &Provenance) -> String {
    let superseded = entry
        .superseded
        .iter()
        .map(encode_origin)
        .collect::<Vec<_>>();
    encode_sequence(&[
        encode_path(&entry.field),
        encode_origin(&entry.origin),
        encode_stages(&entry.transform),
        encode_sequence(&superseded),
    ])
}

fn decode_provenance_entry(encoded: &str, index: usize) -> Result<Provenance, String> {
    let fields = decode_sequence(encoded, "provenance entry")?;
    require_fields(&fields, 4, "provenance entry")?;
    let superseded_fields = decode_sequence(&fields[3], "provenance superseded origins")?;
    Ok(Provenance {
        field: decode_path(&fields[0], "provenance field")?,
        origin: decode_origin(&fields[1], "provenance origin")?,
        transform: decode_stages(&fields[2])?,
        superseded: superseded_fields
            .iter()
            .enumerate()
            .map(|(origin_index, value)| {
                decode_origin(value, "provenance superseded origin").map_err(|error| {
                    format!("provenance entry {index} origin {origin_index}: {error}")
                })
            })
            .collect::<Result<Vec<_>, _>>()?,
    })
}

pub(crate) fn encode_provenance(delta: &ProvenanceDelta) -> String {
    let mut fields = vec![
        current_tag(PROVENANCE_TAG_V2),
        delta.entries.len().to_string(),
    ];
    fields.extend(delta.entries.iter().map(encode_provenance_entry));
    encode_sequence(&fields)
}

pub(crate) fn decode_provenance(encoded: &str) -> Result<(ProvenanceDelta, u32), String> {
    let fields = decode_sequence(encoded, "parser provenance")?;
    if fields.len() < 2 {
        return Err("parser provenance has an unsupported shape".to_owned());
    }
    let epoch = decode_tag_epoch(&fields[0], PROVENANCE_TAG_V1, PROVENANCE_TAG_V2)?;
    let count = parse_usize(&fields[1], "provenance entry count")?;
    require_fields(&fields, count + 2, "parser provenance")?;
    let entries = fields[2..]
        .iter()
        .enumerate()
        .map(|(index, value)| decode_provenance_entry(value, index))
        .collect::<Result<Vec<_>, _>>()?;
    Ok((ProvenanceDelta { entries }, epoch))
}

fn severity_name(severity: DiagnosticSeverity) -> &'static str {
    match severity {
        DiagnosticSeverity::Error => "error",
        DiagnosticSeverity::Warning => "warning",
        DiagnosticSeverity::Info => "info",
    }
}

fn severity(value: &str) -> Result<DiagnosticSeverity, String> {
    match value {
        "error" => Ok(DiagnosticSeverity::Error),
        "warning" => Ok(DiagnosticSeverity::Warning),
        "info" => Ok(DiagnosticSeverity::Info),
        _ => Err("diagnostics contain an unknown severity".to_owned()),
    }
}

fn encode_diagnostic_path(path: Option<&IrPath>) -> String {
    path.map(encode_path)
        .as_deref()
        .map_or_else(|| encode_option(None), |value| encode_option(Some(value)))
}

fn decode_diagnostic_path(encoded: &str) -> Result<Option<IrPath>, String> {
    decode_option(encoded, "diagnostic related path")?
        .map(|value| decode_path(&value, "diagnostic related path"))
        .transpose()
}

fn encode_diagnostic(diagnostic: &Diagnostic) -> String {
    encode_sequence(&[
        diagnostic.code.clone(),
        severity_name(diagnostic.severity).to_owned(),
        diagnostic.summary.clone(),
        encode_option(diagnostic.detail.as_deref()),
        encode_diagnostic_path(diagnostic.related_path.as_ref()),
        encode_option(diagnostic.remediation.as_deref()),
    ])
}

fn decode_diagnostic(encoded: &str, index: usize) -> Result<Diagnostic, String> {
    let result: Result<Diagnostic, String> = (|| {
        let fields = decode_sequence(encoded, "diagnostic")?;
        require_fields(&fields, 6, "diagnostic")?;
        Ok(Diagnostic {
            code: fields[0].clone(),
            severity: severity(&fields[1])?,
            summary: fields[2].clone(),
            detail: decode_option(&fields[3], "diagnostic detail")?,
            related_path: decode_diagnostic_path(&fields[4])?,
            remediation: decode_option(&fields[5], "diagnostic remediation")?,
        })
    })();
    result.map_err(|error| format!("diagnostic {index}: {error}"))
}

pub(crate) fn encode_diagnostics(diagnostics: &[Diagnostic]) -> String {
    let mut fields = vec![
        current_tag(DIAGNOSTICS_TAG_V2),
        diagnostics.len().to_string(),
    ];
    fields.extend(diagnostics.iter().map(encode_diagnostic));
    encode_sequence(&fields)
}

pub(crate) fn decode_diagnostics(encoded: &str) -> Result<(Vec<Diagnostic>, u32), String> {
    let fields = decode_sequence(encoded, "diagnostics")?;
    if fields.len() < 2 {
        return Err("diagnostics have an unsupported shape".to_owned());
    }
    let epoch = decode_tag_epoch(&fields[0], DIAGNOSTICS_TAG_V1, DIAGNOSTICS_TAG_V2)?;
    let count = parse_usize(&fields[1], "diagnostic count")?;
    require_fields(&fields, count + 2, "diagnostics")?;
    let diagnostics = fields[2..]
        .iter()
        .enumerate()
        .map(|(index, value)| decode_diagnostic(value, index))
        .collect::<Result<Vec<_>, _>>()?;
    Ok((diagnostics, epoch))
}

fn source_kind_from_record(value: &str) -> Result<SourceKind, String> {
    source_kind(value)
}

fn raw_source_from_record(record: &SourceIndexRecord) -> Result<RawSource, String> {
    let kind = source_kind_from_record(&record.source_kind)?;
    Ok(RawSource {
        id: SourceId::new(record.source_id.clone()),
        kind,
        origin_label: record.label.clone(),
        content_digest: Digest(record.raw_content_sha256.clone()),
        bytes_len: record.raw_bytes_len,
        media_type: record.media_type.clone(),
    })
}

/// Build the engine-facing report from one durable record. This is run during source-worker
/// construction, not lazily on the first update: malformed typed cache data refuses boot.
pub(crate) fn report_from_record(
    record: &SourceIndexRecord,
    current_epoch: u32,
) -> Result<(SourceUpdateReport, CacheRecency), String> {
    let normalized_anchor = caly_common::digest::sha256_digest(record.normalized_cache.as_bytes());
    let provenance_anchor = caly_common::digest::sha256_digest(record.parser_provenance.as_bytes());
    let diagnostics_anchor = caly_common::digest::sha256_digest(record.diagnostics.as_bytes());
    if record.normalized_digest != normalized_anchor
        || record.provenance_digest != provenance_anchor
        || record.diagnostics_digest != diagnostics_anchor
    {
        return Err("source index opaque cache content failed its digest anchors".to_owned());
    }
    if !record.raw_content_sha256.starts_with("sha256:")
        || record.raw_content_sha256.len() != "sha256:".len() + 64
        || !record.raw_content_sha256["sha256:".len()..]
            .bytes()
            .all(|byte| byte.is_ascii_hexdigit())
    {
        return Err("source index raw content anchor is not a sha256 digest".to_owned());
    }
    let (normalized, normalized_epoch) = decode_normalized(&record.normalized_cache)?;
    if normalized.id.0 != record.source_id
        || normalized.raw_digest.0 != record.raw_content_sha256
        || source_kind_name(normalized.source_kind) != record.source_kind
    {
        return Err(
            "source index normalized cache disagrees with its source identity or raw anchor"
                .to_owned(),
        );
    }
    let (provenance, provenance_epoch) = decode_provenance(&record.parser_provenance)?;
    let (diagnostics, diagnostics_epoch) = decode_diagnostics(&record.diagnostics)?;
    // One record is one atomic commit of one pipeline run; three caches claiming three
    // different epochs is not a shape any build ever wrote — refuse rather than guess which
    // cache to trust (ADR-061 §2.3).
    if normalized_epoch != provenance_epoch || normalized_epoch != diagnostics_epoch {
        return Err(format!(
            "source index opaque caches disagree about the pipeline epoch that produced \
             them (normalized={normalized_epoch}, provenance={provenance_epoch}, \
             diagnostics={diagnostics_epoch})"
        ));
    }
    let recency = if normalized_epoch == current_epoch {
        CacheRecency::Current
    } else {
        CacheRecency::Stale {
            recorded_epoch: normalized_epoch,
        }
    };
    let raw = raw_source_from_record(record)?;
    let raw_object = caly_storage::CasObjectRef {
        digest: caly_storage::ObjectDigest(record.raw_object_digest.clone()),
        kind: caly_storage::ObjectKind::RawSource,
        size_bytes: Some(record.raw_bytes_len),
        content_type: record.media_type.clone(),
        content_sha256: Some(record.raw_content_sha256.clone()),
        stored_at_unix_ms: record.raw_stored_at_unix_ms,
    };
    let report = SourceUpdateReport {
        source_id: SourceId::new(record.source_id.clone()),
        raw,
        normalized,
        raw_object,
        diagnostics,
        provenance,
        reused_raw_body: false,
        etag: record.etag.clone(),
        last_modified: record.last_modified.clone(),
    };
    Ok((report, recency))
}

/// Check that an index record still carries all of the report facts it claims to carry. The storage
/// codec verifies the opaque text hashes; this second layer verifies the typed identity and shape.
pub(crate) fn record_from_report(
    endpoint: &crate::source_worker::SourceEndpoint,
    report: &SourceUpdateReport,
    updated_at_unix_ms: i64,
) -> SourceIndexRecord {
    let normalized_cache = encode_normalized(&report.normalized);
    let parser_provenance = encode_provenance(&report.provenance);
    let diagnostics = encode_diagnostics(&report.diagnostics);
    SourceIndexRecord {
        source_id: endpoint.source_id.0.clone(),
        source_kind: source_kind_name(endpoint.kind).to_owned(),
        label: endpoint.label.clone(),
        locator: endpoint.locator.clone(),
        route: match endpoint.route {
            caly_io::FetchRoute::Direct => "direct",
            caly_io::FetchRoute::SystemProxy => "system-proxy",
            caly_io::FetchRoute::ActiveCore => "active-core",
        }
        .to_owned(),
        max_body_bytes: endpoint.max_body_bytes,
        media_type: endpoint.media_type.clone(),
        strict_mode: endpoint.strict_mode,
        etag: report.etag.clone(),
        last_modified: report.last_modified.clone(),
        raw_object_digest: report.raw_object.digest.0.clone(),
        raw_content_sha256: report
            .raw_object
            .content_sha256
            .clone()
            .unwrap_or_else(|| report.raw.content_digest.0.clone()),
        raw_bytes_len: report.raw.bytes_len,
        raw_stored_at_unix_ms: report.raw_object.stored_at_unix_ms,
        normalized_digest: caly_common::digest::sha256_digest(normalized_cache.as_bytes()),
        normalized_cache,
        provenance_digest: caly_common::digest::sha256_digest(parser_provenance.as_bytes()),
        parser_provenance,
        diagnostics_digest: caly_common::digest::sha256_digest(diagnostics.as_bytes()),
        diagnostics,
        updated_at_unix_ms,
    }
}

pub(crate) fn source_kind_from_text(value: &str) -> Result<SourceKind, String> {
    source_kind(value)
}

pub(crate) fn route_from_text(value: &str) -> Result<caly_io::FetchRoute, String> {
    match value {
        "direct" => Ok(caly_io::FetchRoute::Direct),
        "system-proxy" => Ok(caly_io::FetchRoute::SystemProxy),
        "active-core" => Ok(caly_io::FetchRoute::ActiveCore),
        _ => Err("source index has an unknown fetch route".to_owned()),
    }
}

#[cfg(test)]
mod tests {
    /// A well-formed sha256 anchor (`sha256:` + 64 hex) — the record gate refuses anything
    /// less, and this fixture wants to reach the EPOCH check, not the anchor check.
    fn sha64(seed: &str) -> String {
        format!("sha256:{}", seed.repeat(64))
    }

    /// Prefix-correct first-field surgery: the caches are length-prefixed sequences, so a
    /// tag swap must rewrite `<len>:` too (the e2e helper learned this the loud way).
    fn retag_first_field(text: &str, to: &str) -> String {
        let colon = text.find(':').expect("length prefix");
        let len: usize = text[..colon].parse().expect("numeric prefix");
        let rest = &text[colon + 1 + len..];
        format!("{}:{}{}", to.len(), to, rest)
    }

    /// Deterministic structure-aware fuzz for the durable cache decoders (round 128's
    /// hardening milestone): the length-prefixed codec faces tampered or foreign store
    /// bytes, and the `ADR-061` tag grammar is its newest surface. The invariants are the
    /// fuzz pair: **never a panic**, and every refusal **by name**. Local xorshift PRNG,
    /// fixed budget, no dependencies.
    #[test]
    fn mutated_caches_never_panic_and_refuse_by_name() {
        struct Rng(u64);
        impl Rng {
            fn next(&mut self) -> u64 {
                let mut x = self.0;
                x ^= x >> 12;
                x ^= x << 25;
                x ^= x >> 27;
                self.0 = x;
                x.wrapping_mul(0x2545_F491_4F6C_DD1D)
            }
            fn below(&mut self, n: usize) -> usize {
                (self.next() % n.max(1) as u64) as usize
            }
        }
        const DELIMITERS: &[u8] = b"|=&:\\\"\n\r\t \x00";
        fn mutate(rng: &mut Rng, corpus: &[u8]) -> Vec<u8> {
            if corpus.is_empty() {
                return vec![DELIMITERS[rng.below(DELIMITERS.len())]];
            }
            let mut bytes = corpus.to_vec();
            let len = bytes.len();
            match rng.below(6) {
                0 => bytes.truncate(rng.below(len + 1)),
                1 => {
                    let at = rng.below(len);
                    bytes[at] ^= 1 << rng.below(8);
                }
                2 => bytes.insert(rng.below(len + 1), DELIMITERS[rng.below(DELIMITERS.len())]),
                3 => {
                    let start = rng.below(len);
                    let end = start + rng.below(len - start + 1);
                    let chunk = bytes[start..end].to_vec();
                    bytes.extend_from_slice(&chunk);
                }
                4 => bytes.insert(rng.below(len + 1), b'0' + (rng.below(10) as u8)),
                5 => {
                    let start = rng.below(len);
                    let end = start + rng.below(len - start + 1);
                    bytes.drain(start..end);
                }
                _ => unreachable!(),
            }
            bytes
        }

        let source = NormalizedSource {
            id: SourceId::new("fuzz-source"),
            raw_digest: Digest("sha256:fuzz".to_owned()),
            source_kind: SourceKind::Subscription,
            nodes: vec![NormalizedNode {
                id: NodeId::new("node:1"),
                label: "label |= \\ \" \n 🛡".to_owned(),
                protocol: ProxyProtocol::Vless,
                server: "example.test".to_owned(),
                port: 443,
                passthrough: BTreeMap::from([("sni".to_owned(), "example.test|=:".to_owned())]),
            }],
            node_count_estimate: 1,
            group_count_estimate: 1,
            rule_count_estimate: 1,
        };
        let provenance = ProvenanceDelta::default();
        let diagnostics = vec![Diagnostic {
            code: "FUZZ".to_owned(),
            severity: DiagnosticSeverity::Warning,
            summary: "summary |= \\".to_owned(),
            detail: Some("detail".to_owned()),
            related_path: Some(IrPath::from_segments(["source", "line-1"])),
            remediation: None,
        }];
        let corpus = [
            encode_normalized(&source),
            encode_provenance(&provenance),
            encode_diagnostics(&diagnostics),
            // The empty first field (an absent tag) is the edge every tag grammar forgets.
            retag_first_field(&encode_normalized(&source), ""),
            String::new(),
        ];

        let mut rng = Rng(0xE91D_2A6F_0B55_8137);
        let mut accepted = 0;
        let mut refused = 0;
        for step in 0..3000 {
            let base = &corpus[rng.below(corpus.len())];
            let input = if step % 8 == 0 {
                base.clone()
            } else {
                String::from_utf8_lossy(&mutate(&mut rng, base.as_bytes())).into_owned()
            };
            type CacheDecoder = fn(&str) -> Result<u32, String>;
            let decoders: [(&str, CacheDecoder); 3] = [
                ("normalized", |raw| {
                    decode_normalized(raw).map(|(_, epoch)| epoch)
                }),
                ("provenance", |raw| {
                    decode_provenance(raw).map(|(_, epoch)| epoch)
                }),
                ("diagnostics", |raw| {
                    decode_diagnostics(raw).map(|(_, epoch)| epoch)
                }),
            ];
            let mut this_accepted = false;
            for (label, decode) in decoders {
                let outcome =
                    std::panic::catch_unwind(std::panic::AssertUnwindSafe(|| decode(&input)));
                let Ok(result) = outcome else {
                    panic!("{label} panicked on {input:?} (seeded step {step})");
                };
                match result {
                    Ok(_) => this_accepted = true,
                    Err(message) => assert!(
                        !message.trim().is_empty(),
                        "{label}: a refusal must say something by name"
                    ),
                }
            }
            if this_accepted {
                accepted += 1;
            } else {
                refused += 1;
            }
        }
        assert!(
            accepted > 0 && refused > 0,
            "the fuzz must exercise both sides (accepted={accepted}, refused={refused})"
        );
    }

    #[test]
    fn a_v1_tag_decodes_as_epoch_one_and_matches_the_v2_encoding_of_the_same_value() {
        // The migration's one historical fact (ADR-061 §2.2): every v1 writer ran epoch 1,
        // so a v1 tag decodes as exactly the value a v2:1 encoding carries — no guess, no
        // default-of-the-day.
        let source = NormalizedSource {
            id: SourceId::new("legacy-source"),
            raw_digest: Digest("sha256:legacy".to_owned()),
            source_kind: SourceKind::Subscription,
            nodes: vec![NormalizedNode {
                id: NodeId::new("node:1"),
                label: "legacy edge".to_owned(),
                protocol: ProxyProtocol::Vless,
                server: "example.test".to_owned(),
                port: 443,
                passthrough: BTreeMap::new(),
            }],
            node_count_estimate: 1,
            group_count_estimate: 1,
            rule_count_estimate: 1,
        };
        let v2 = encode_normalized(&source);
        let (v2_value, v2_epoch) = decode_normalized(&v2).expect("v2 decodes");
        assert_eq!(v2_epoch, caly_pipeline::stage::PIPELINE_EPOCH);

        // Byte surgery v2:1 -> v1 (same body, the only shape any pre-v2 build wrote).
        let v1 = retag_first_field(&v2, NORMALIZED_TAG_V1);
        assert_ne!(v1, v2, "the fixture must actually exercise the legacy tag");
        let (v1_value, v1_epoch) = decode_normalized(&v1).expect("v1 migrates forward");
        assert_eq!(v1_epoch, 1);
        assert_eq!(v1_value, v2_value, "migration is value-faithful");
    }

    #[test]
    fn an_unknown_tag_refuses_by_name_with_the_supported_list() {
        let encoded_base = encode_normalized(&NormalizedSource {
            id: SourceId::new("s"),
            raw_digest: Digest("sha256:x".to_owned()),
            source_kind: SourceKind::Subscription,
            nodes: vec![],
            node_count_estimate: 0,
            group_count_estimate: 0,
            rule_count_estimate: 0,
        });
        for foreign in ["normalized:v3", "normalized:", "normalized:v2:x", "bogus"] {
            let encoded = retag_first_field(&encoded_base, foreign);
            let error = decode_normalized(&encoded)
                .expect_err("a tag this build cannot understand is refused");
            assert!(
                error.contains(foreign),
                "{foreign:?}: the refusal names what it found: {error}"
            );
            assert!(
                error.contains(NORMALIZED_TAG_V1) && error.contains(NORMALIZED_TAG_V2),
                "{foreign:?}: the refusal names what is supported: {error}"
            );
        }
    }

    #[test]
    fn caches_claiming_different_epochs_are_refused_not_averaged() {
        // One record is one atomic commit of one pipeline run; mixed epochs never existed
        // on any disk (ADR-061 §2.3) — the refusal says so instead of guessing.
        let source = NormalizedSource {
            id: SourceId::new("s"),
            raw_digest: Digest(sha64("7")),
            source_kind: SourceKind::Subscription,
            nodes: vec![],
            node_count_estimate: 0,
            group_count_estimate: 0,
            rule_count_estimate: 0,
        };
        let normalized = encode_normalized(&source);
        let provenance = encode_provenance(&ProvenanceDelta::default());
        let diagnostics = encode_diagnostics(&[]);
        // `retag_first_field` needs the family from the CURRENT tag; both caches carry it.
        let epoch_of = |text: &str| -> String {
            let colon = text.find(':').expect("prefix");
            let len: usize = text[..colon].parse().expect("len");
            let tag = &text[colon + 1..colon + 1 + len];
            let family = tag.split(':').next().expect("family");
            retag_first_field(text, &format!("{family}:v2:7"))
        };
        let record = SourceIndexRecord {
            source_id: "s".to_owned(),
            source_kind: "subscription".to_owned(),
            label: "l".to_owned(),
            locator: "https://example.test/s".to_owned(),
            route: "direct".to_owned(),
            max_body_bytes: 1024,
            media_type: None,
            strict_mode: false,
            etag: None,
            last_modified: None,
            raw_object_digest: "objects:abc".to_owned(),
            raw_content_sha256: sha64("7"),
            raw_bytes_len: 1,
            raw_stored_at_unix_ms: None,
            normalized_cache: epoch_of(&normalized),
            normalized_digest: caly_common::digest::sha256_digest(epoch_of(&normalized).as_bytes()),
            provenance_digest: caly_common::digest::sha256_digest(provenance.as_bytes()),
            parser_provenance: provenance.clone(),
            diagnostics_digest: caly_common::digest::sha256_digest(diagnostics.as_bytes()),
            diagnostics: diagnostics.clone(),
            updated_at_unix_ms: 0,
        };
        let error = report_from_record(&record, caly_pipeline::stage::PIPELINE_EPOCH)
            .expect_err("mixed epochs are refused");
        assert!(
            error.contains("disagree about the pipeline epoch"),
            "{error}"
        );
        // The matching-epoch record with the SAME surgery on all three caches is fine:
        // staleness (all three at 7) is a degrade, not a refusal.
        let mut consistent = record.clone();
        consistent.parser_provenance = epoch_of(&provenance);
        consistent.provenance_digest =
            caly_common::digest::sha256_digest(consistent.parser_provenance.as_bytes());
        consistent.diagnostics = epoch_of(&diagnostics);
        consistent.diagnostics_digest =
            caly_common::digest::sha256_digest(consistent.diagnostics.as_bytes());
        let (_, recency) = report_from_record(&consistent, caly_pipeline::stage::PIPELINE_EPOCH)
            .expect("a consistent record with a foreign epoch degrades, not refuses");
        assert_eq!(recency, CacheRecency::Stale { recorded_epoch: 7 });
    }

    use super::*;
    use caly_ir::{NormalizedNode, ProxyProtocol};

    #[test]
    fn normalized_codec_preserves_unicode_and_map_order() {
        let source = NormalizedSource {
            id: SourceId::new("source/一"),
            raw_digest: Digest("sha256:raw".to_owned()),
            source_kind: SourceKind::Subscription,
            nodes: vec![NormalizedNode {
                id: NodeId::new("node:1"),
                label: "🇩🇪 edge".to_owned(),
                protocol: ProxyProtocol::Vless,
                server: "example.test".to_owned(),
                port: 443,
                passthrough: BTreeMap::from([
                    ("sni".to_owned(), "example.test".to_owned()),
                    ("token".to_owned(), "a=b\\c\n".to_owned()),
                ]),
            }],
            node_count_estimate: 1,
            group_count_estimate: 1,
            rule_count_estimate: 1,
        };
        let (decoded, epoch) = decode_normalized(&encode_normalized(&source)).expect("round trip");
        assert_eq!(decoded, source);
        assert_eq!(epoch, caly_pipeline::stage::PIPELINE_EPOCH);
    }

    #[test]
    fn provenance_and_diagnostics_codecs_preserve_optional_nested_fields() {
        let provenance = ProvenanceDelta {
            entries: vec![
                Provenance {
                    field: IrPath::from_segments(["source", "node"]),
                    origin: Origin::Source {
                        source_id: "source-1".to_owned(),
                        locator: None,
                    },
                    transform: vec![StageId::Ingest, StageId::Normalize],
                    superseded: vec![
                        Origin::Default,
                        Origin::Override {
                            override_id: "override-1".to_owned(),
                        },
                    ],
                },
                Provenance {
                    field: IrPath::from_segments(["runtime"]),
                    origin: Origin::Safety,
                    transform: Vec::new(),
                    superseded: vec![Origin::Source {
                        source_id: "source-2".to_owned(),
                        locator: Some("https://example.test/feed?token=hidden".to_owned()),
                    }],
                },
            ],
        };
        let (decoded_provenance, provenance_epoch) =
            decode_provenance(&encode_provenance(&provenance)).expect("provenance round trip");
        assert_eq!(decoded_provenance, provenance);
        assert_eq!(provenance_epoch, caly_pipeline::stage::PIPELINE_EPOCH);

        let diagnostics = vec![Diagnostic {
            code: "SOURCE_LINE_SKIPPED".to_owned(),
            severity: DiagnosticSeverity::Warning,
            summary: "line skipped".to_owned(),
            detail: Some("detail with = and \\ and newline\n".to_owned()),
            related_path: Some(IrPath::from_segments(["source", "line-1"])),
            remediation: Some("fix the line".to_owned()),
        }];
        let (decoded_diagnostics, diagnostics_epoch) =
            decode_diagnostics(&encode_diagnostics(&diagnostics)).expect("diagnostics round trip");
        assert_eq!(decoded_diagnostics, diagnostics);
        assert_eq!(diagnostics_epoch, caly_pipeline::stage::PIPELINE_EPOCH);
    }
}
