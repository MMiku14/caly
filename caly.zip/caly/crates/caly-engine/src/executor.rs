//! Effect execution engine.
//!
//! This module is the missing half of the apply centerline described in
//! `docs/APPLY_EXECUTION_CENTERLINE.md §3`: the workspace could already *project*
//! an `EffectPlan`, but nothing interpreted it. Steps were rendered into strings
//! (`render_effect_step`) and copied into job logs, so the three-phase execution
//! model of `APPLY_EXECUTION_CENTERLINE.md §6` had no carrier in code.
//!
//! Design rules (all traceable to a frozen doc, no new architecture here):
//!
//! 1. Steps are interpreted as typed `caly_plan::EffectStep` values, never as strings.
//! 2. `Prepare -> Cutover -> Finalize` must be **monotonic** across the forward plan
//!    (`APPLY_EXECUTION_CENTERLINE.md §6.1`): Prepare must not touch the active
//!    runtime, so a Prepare step may not appear after a Cutover step.
//! 3. A commit (`MarkSnapshot` / `CommitRevision`) may not run unless a `Probe` has
//!    already succeeded, i.e. `RuntimeVerified -> SnapshotCommitted`
//!    (`APPLY_EXECUTION_CENTERLINE.md §5.1`, `§6.1` Phase C).
//! 4. Failure after cutover triggers `compensations` in reverse order; if the
//!    compensation itself fails the result is `RollbackFailed`, which is a strictly
//!    higher-severity outcome than a plain apply failure
//!    (`APPLY_EXECUTION_CENTERLINE.md §10`).
//! 5. Everything is deterministic: no clock, no randomness, no I/O. Time is injected
//!    through `ExecutionPolicy`, and side effects go through the `EffectRuntime` port.
//!    This keeps the module inside the `clippy.toml` disallowed-symbol set
//!    (`ADR-011`, `ADR-013`) and makes it usable as the `ADR-022` simulation substrate.
//!    The `EffectCursor` added for `§6.1` Phase B does not weaken this: the executor never
//!    owns a store and never decides *what* the truth is, it asks an injected sink to record
//!    an intent and honours the answer -- so plan + policy + runtime + cursor together are
//!    still the whole input, and a run stays reproducible byte for byte.

use caly_plan::CoreCall;
use caly_plan::EffectPlan;
use caly_plan::EffectStep;
use caly_storage::advance_apply_journal_step;
use caly_storage::mark_apply_journal_state;
use caly_storage::ApplyJournalRecord;
use caly_storage::ApplyJournalState;
use caly_storage::ApplyPhase;

/// Deterministic phase classification of a single effect step.
///
/// Mirrors `docs/APPLY_EXECUTION_CENTERLINE.md §6.1` exactly:
/// `WriteObject` / `MaterializeArtifact` / `DbTxn` are prepare, the runtime and OS
/// mutations are cutover, and `Probe` / `MarkSnapshot` / `CommitRevision` finalize.
pub const fn phase_of(step: &EffectStep) -> ApplyPhase {
    match step {
        EffectStep::WriteObject { .. }
        | EffectStep::MaterializeArtifact { .. }
        | EffectStep::DbTxn { .. } => ApplyPhase::Prepare,
        EffectStep::SpawnCore { .. }
        | EffectStep::StopCore { .. }
        | EffectStep::CoreApiCall { .. }
        | EffectStep::NetApply { .. }
        | EffectStep::NetRevert { .. } => ApplyPhase::Cutover,
        EffectStep::Probe { .. }
        | EffectStep::MarkSnapshot { .. }
        | EffectStep::CommitRevision { .. } => ApplyPhase::Finalize,
    }
}

/// Ordering rank used for the monotonicity gate. Higher means "later, and less reversible".
pub const fn phase_rank(phase: ApplyPhase) -> u8 {
    match phase {
        ApplyPhase::Prepare => 0,
        ApplyPhase::Cutover => 1,
        ApplyPhase::Finalize => 2,
        ApplyPhase::Recovery => 3,
    }
}

/// A stable, human-readable label for a step, used in events and reports.
///
/// Unlike `render_effect_step` in `apply.rs` (which is a *presentation* projection),
/// this label is produced from the typed variant and is what the executor reports.
pub fn step_label(step: &EffectStep) -> String {
    match step {
        EffectStep::WriteObject { digest, .. } => format!("write-object {digest}"),
        EffectStep::MaterializeArtifact { digest, at, .. } => {
            format!("materialize {at} <- {digest}")
        }
        EffectStep::DbTxn { ops } => format!("db-txn ops={}", ops.len()),
        EffectStep::SpawnCore { spec } => {
            format!("spawn-core config={}", spec.config_digest)
        }
        EffectStep::StopCore { instance, grace_ms } => {
            format!("stop-core {} grace={grace_ms}ms", instance.0)
        }
        EffectStep::CoreApiCall { instance, call } => match call {
            CoreCall::Status => format!("core-api {} status", instance.0),
            CoreCall::Reload => format!("core-api {} reload", instance.0),
            CoreCall::SelectProxy { group_id, node_id } => {
                format!(
                    "core-api {} select group={group_id} node={node_id}",
                    instance.0
                )
            }
            CoreCall::CloseConnection { connection_id } => {
                format!("core-api {} close-connection {connection_id}", instance.0)
            }
        },
        EffectStep::NetApply { plan } => format!("net-apply {}", plan.summary),
        EffectStep::NetRevert { txn_id } => format!("net-revert {}", txn_id.0),
        EffectStep::Probe { probe, deadline_ms } => format!(
            "probe {:?} deadline={}ms target={}",
            probe.kind,
            deadline_ms,
            probe.target.clone().unwrap_or_else(|| "none".to_owned())
        ),
        EffectStep::MarkSnapshot { snapshot_id } => {
            format!("mark-snapshot {}", snapshot_id.0)
        }
        EffectStep::CommitRevision { revision } => format!("commit-revision {revision}"),
    }
}

/// What the runtime observed while executing one step.
#[derive(Clone, Debug, Default, Eq, PartialEq)]
pub struct StepEvidence {
    pub observations: Vec<String>,
    /// How long the step took, in the runtime's own time base (`ADR-036 §2.5`).
    ///
    /// The runtime *reports* it and the executor *judges* it. That split is the whole point: a deadline
    /// check inside each adapter is a deadline check each adapter can forget, and the field would go
    /// back to being decoration -- which is precisely what `ADR-036 §1` listed about `deadline_ms`.
    /// A real `Std*` runtime measures with its injected `Clock`; the simulated one is told.
    pub elapsed_ms: u64,
}

impl StepEvidence {
    pub fn one(observation: impl Into<String>) -> Self {
        Self {
            observations: vec![observation.into()],
            elapsed_ms: 0,
        }
    }

    /// Evidence for a step that took measurable time.
    pub fn took(observation: impl Into<String>, elapsed_ms: u64) -> Self {
        Self {
            observations: vec![observation.into()],
            elapsed_ms,
        }
    }

    pub fn merge(&mut self, other: StepEvidence) {
        self.observations.extend(other.observations);
        // The longest part wins: an elapsed figure that gets summed across merged evidence would let a
        // step that ran twice look slower than either run, and a *smaller* max would let it look faster
        // than the run that actually timed out.
        self.elapsed_ms = self.elapsed_ms.max(other.elapsed_ms);
    }
}

/// A typed failure surfaced by an [`EffectRuntime`].
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct StepFailure {
    pub code: String,
    pub summary: String,
    pub retryable: bool,
}

impl StepFailure {
    pub fn new(code: impl Into<String>, summary: impl Into<String>, retryable: bool) -> Self {
        Self {
            code: code.into(),
            summary: summary.into(),
            retryable,
        }
    }
}

/// The port an effect step is executed against.
///
/// Keeping this a trait is what makes the executor testable without a filesystem,
/// a process table, or a core binary, which is the `ADR-022` requirement that
/// deployment and recovery claims be falsifiable in simulation.
pub trait EffectRuntime: Send + Sync {
    /// Apply one forward step.
    fn execute(&self, phase: ApplyPhase, step: &EffectStep) -> Result<StepEvidence, StepFailure>;

    /// Undo one previously applied step during compensation.
    fn compensate(&self, phase: ApplyPhase, step: &EffectStep)
        -> Result<StepEvidence, StepFailure>;
}

/// Execution knobs. All of them are injected rather than read from the environment,
/// so a given plan plus policy plus runtime always yields byte-identical results.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct ExecutionPolicy {
    /// Crash injection (`ADR-022` "可在任意 `EffectStep` 后触发崩溃"): after this many
    /// forward steps have succeeded, the next step fails with `simulated-crash`.
    pub fail_after_step: Option<usize>,
    /// Base timestamp for journal cursors. `0` is a valid, reproducible value.
    pub clock_start_unix_ms: i64,
    /// Timestamp increment applied per journal advance.
    pub clock_step_ms: i64,
    /// Enforce `APPLY_EXECUTION_CENTERLINE.md §6.1` phase monotonicity before running.
    pub enforce_phase_order: bool,
    /// Enforce the verify-before-commit gate (`§6.1` Phase C).
    pub require_probe_before_commit: bool,
    /// Make `StopCore` / `CoreApiCall` / `Probe` require a live core in the simulated world.
    /// Off by default so a first deployment from an empty world still plans cleanly.
    pub enforce_runtime_presence: bool,
}

impl Default for ExecutionPolicy {
    fn default() -> Self {
        Self {
            fail_after_step: None,
            clock_start_unix_ms: 0,
            clock_step_ms: 1,
            enforce_phase_order: true,
            require_probe_before_commit: true,
            enforce_runtime_presence: false,
        }
    }
}

impl ExecutionPolicy {
    /// Deterministic timestamp for the `n`th journal advance.
    pub fn timestamp_at(&self, tick: usize) -> i64 {
        self.clock_start_unix_ms
            .saturating_add((tick as i64).saturating_mul(self.clock_step_ms))
    }

    pub fn crashing_after(mut self, step: usize) -> Self {
        self.fail_after_step = Some(step);
        self
    }
}

/// Why the executor refused to *attempt* a step, as opposed to the runtime failing it.
///
/// Kept distinct from `StepOutcome::Failed` because the two mean different things to an
/// operator: a skip is the executor protecting an invariant, a failure is the host refusing
/// to do the work.
#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub enum StepSkip {
    /// A gate blocked the step; nothing was attempted.
    Gate { reason: &'static str },
    /// Crash injection stopped the run before this step (`ADR-022`).
    CrashInjected,
}

/// Outcome of one step as recorded by the executor.
#[derive(Clone, Debug, Eq, PartialEq)]
pub enum StepOutcome {
    Applied,
    Failed { failure: StepFailure },
    Skipped { skip: StepSkip },
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct ExecutedStep {
    pub index: usize,
    pub phase: ApplyPhase,
    pub label: String,
    pub outcome: StepOutcome,
    pub observations: Vec<String>,
}

impl ExecutedStep {
    pub fn succeeded(&self) -> bool {
        matches!(self.outcome, StepOutcome::Applied)
    }

    pub fn skipped(&self) -> bool {
        matches!(self.outcome, StepOutcome::Skipped { .. })
    }
}

/// Terminal status of an execution.
///
/// `Plan`-time rejection and `Execute`-time failure are deliberately distinct
/// variants, and `RollbackFailed` is distinct from `RolledBack`, per
/// `APPLY_EXECUTION_CENTERLINE.md §10` ("`Plan` 失败 ≠ `Execute` 失败",
/// "`RecoveryFailed` 必须高于普通 apply failed").
#[derive(Clone, Debug, Eq, PartialEq)]
pub enum ExecutionStatus {
    /// Every forward step applied, commit allowed.
    Completed,
    /// The plan never ran because it is structurally unsafe to execute.
    Rejected { reason: String },
    /// A step failed while the active runtime was still untouched.
    FailedBeforeCutover {
        failed_at: usize,
        summary: String,
        retryable: bool,
    },
    /// A step failed after cutover and compensation restored the prior state.
    RolledBack {
        failed_at: usize,
        summary: String,
        compensations_run: usize,
    },
    /// A step failed after cutover and compensation also failed: manual recovery needed.
    RollbackFailed {
        failed_at: usize,
        summary: String,
        rollback_summary: String,
    },
}

impl ExecutionStatus {
    pub fn is_success(&self) -> bool {
        matches!(self, Self::Completed)
    }

    /// True when the active runtime may have been touched and is not known to be restored.
    pub fn needs_manual_recovery(&self) -> bool {
        matches!(self, Self::RollbackFailed { .. })
    }

    pub fn summary_code(&self) -> &'static str {
        match self {
            Self::Completed => "apply.completed",
            Self::Rejected { .. } => "apply.plan-rejected",
            Self::FailedBeforeCutover { .. } => "apply.failed-before-cutover",
            Self::RolledBack { .. } => "apply.recovered",
            Self::RollbackFailed { .. } => "apply.recovery-failed",
        }
    }
}

/// Full result of executing one `EffectPlan`.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct EffectExecution {
    pub plan_id: String,
    pub status: ExecutionStatus,
    pub steps: Vec<ExecutedStep>,
    pub compensations: Vec<ExecutedStep>,
    pub cutover_started: bool,
    pub net_effect_started: bool,
    pub probe_passed: bool,
    pub snapshot_marked: bool,
    pub committed_revision: Option<u64>,
}

impl EffectExecution {
    pub fn succeeded(&self) -> bool {
        self.status.is_success()
    }

    /// Number of forward steps that actually applied.
    pub fn applied_count(&self) -> usize {
        self.steps.iter().filter(|step| step.succeeded()).count()
    }

    /// Number of clock ticks this execution consumed.
    ///
    /// Derived rather than stored: keeping a second counter in sync across the success and
    /// failure paths was the kind of thing that silently drifts.
    pub fn clock_ticks(&self) -> usize {
        self.steps.len() + self.compensations.len()
    }

    /// The index the journal cursor should point at after this execution.
    pub fn cursor_step_index(&self) -> usize {
        match &self.status {
            ExecutionStatus::Rejected { .. } => 0,
            ExecutionStatus::Completed => self.steps.len(),
            ExecutionStatus::FailedBeforeCutover { failed_at, .. }
            | ExecutionStatus::RolledBack { failed_at, .. }
            | ExecutionStatus::RollbackFailed { failed_at, .. } => *failed_at,
        }
    }

    pub fn terminal_phase(&self) -> ApplyPhase {
        if self.cutover_started {
            if self.snapshot_marked {
                ApplyPhase::Finalize
            } else {
                ApplyPhase::Cutover
            }
        } else {
            ApplyPhase::Prepare
        }
    }
}

/// Reject an out-of-order plan without touching any runtime.
pub fn validate_effect_plan(plan: &EffectPlan, policy: &ExecutionPolicy) -> Result<(), String> {
    // Not gated on `enforce_phase_order`: the probe-deadline rule is about the plan being *executable*
    // at all, while the phase order is a policy about how strictly to read it.
    validate_probe_deadlines(plan)?;
    if !policy.enforce_phase_order {
        return Ok(());
    }
    let mut highest: Option<ApplyPhase> = None;
    for (index, step) in plan.steps.iter().enumerate() {
        let phase = phase_of(step);
        if let Some(previous) = highest {
            if phase_rank(phase) < phase_rank(previous) {
                return Err(format!(
                    "effect plan {} step {:02} is {:?} but follows a {:?} step; prepare work must precede cutover",
                    plan.id.0,
                    index + 1,
                    phase,
                    previous
                ));
            }
        }
        highest = Some(phase);
    }
    Ok(())
}

/// Refuse a plan whose `Probe` step has no time budget to enforce.
///
/// `deadline_ms == 0` is not "no limit" -- read literally it is "a probe that can never succeed", and
/// reading it as "unset" would let a missing value quietly disable the gate. So the plan is refused
/// up front, the way `ADR-038 §2` refuses `max_deletions: Some(0)`: an unset bound is a bug in the
/// plan, and the moment to say so is before any runtime is touched.
pub fn validate_probe_deadlines(plan: &EffectPlan) -> Result<(), String> {
    for (index, step) in plan.steps.iter().enumerate() {
        if let EffectStep::Probe { probe, deadline_ms } = step {
            if *deadline_ms == 0 {
                return Err(format!(
                    "effect plan {} step {:02}: {:?} probe carries deadline_ms=0; state a positive \
                     budget (0 means \"no time at all\", not \"no limit\")",
                    plan.id.0,
                    index + 1,
                    probe.kind
                ));
            }
        }
    }
    Ok(())
}

/// `ADR-036 §2.5`, the enforcement half: a probe that outlived its deadline is a **verify failure**,
/// routed through the existing "no commit without a passed probe" branch rather than a new status.
///
/// Why here and not in the runtime: the check has to hold for *every* adapter, and one of them will
/// eventually forget. Why retryable: the core may answer in time next attempt, and nothing was
/// committed -- the same reasoning that makes a busy store retryable (`OVERLOAD_AND_RETRY_MODEL §3.4`).
fn probe_deadline_failure(step: &EffectStep, evidence: &StepEvidence) -> Option<StepFailure> {
    let EffectStep::Probe { probe, deadline_ms } = step else {
        return None;
    };
    if evidence.elapsed_ms <= *deadline_ms {
        return None;
    }
    Some(StepFailure::new(
        "probe-deadline-exceeded",
        format!(
            "{:?} probe used {}ms of its {deadline_ms}ms budget; the deployment is not treated as \
             verified",
            probe.kind, evidence.elapsed_ms
        ),
        true,
    ))
}

/// Refuse to re-enter `Prepare` on a transaction whose cutover already started.
///
/// A resumed transaction (`STORAGE_RECOVERY_EXECUTION_PLAN.md §6.2` case B/C) must
/// continue from the recorded cursor, not replay reversible preparation work as if
/// the active runtime were still untouched.
pub fn validate_resume_boundary(
    journal: &ApplyJournalRecord,
    plan: &EffectPlan,
) -> Result<(), String> {
    if !journal.core_cutover_started {
        return Ok(());
    }
    match plan.steps.iter().find(|step| phase_rank(phase_of(step)) <= phase_rank(ApplyPhase::Prepare)) {
        Some(step) => Err(format!(
            "apply txn {} already recorded cutover; refusing to replay prepare step {:?} from cursor {}",
            journal.apply_txn_id.0,
            step_label(step),
            journal.current_step_index
        )),
        None => Ok(()),
    }
}

/// Why the apply journal refused to record an intent (`APPLY_EXECUTION_CENTERLINE.md §6.1`
/// Phase B, `OVERLOAD_AND_RETRY_MODEL.md §6.2`).
///
/// Kept as data rather than as a `String` for the same reason `StoreRefusal` is: "the store is
/// busy", "the caller gave up" and "the caller's budget is spent" decide different job outcomes,
/// different public errors, and whether `doctor` sees pressure at all. `retryable` is copied from
/// whichever answer produced this and never derived from the kind (`docs/ONBOARDING_NOTES.md
/// §4.91`).
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct CursorRefusal {
    pub kind: crate::run_limits::RefusalKind,
    pub message: String,
    pub retryable: bool,
    /// Copied from `StoreRefusal::is_caller_side`, because the worker needs it to settle the job as
    /// `Cancelled` / `TimedOut` rather than `Failed` -- and `StoreRefusal` itself is consumed by the
    /// conversion, so this is the only way the bit survives into the failure path.
    pub caller_side: bool,
}

impl From<crate::run_limits::StoreRefusal> for CursorRefusal {
    fn from(refusal: crate::run_limits::StoreRefusal) -> Self {
        let caller_side = refusal.is_caller_side();
        Self {
            kind: refusal.kind,
            message: refusal.to_string(),
            retryable: refusal.retryable,
            caller_side,
        }
    }
}

/// Which steps have to be announced to the journal before they run, and why the answer is
/// "the cutover window only".
///
/// * `Prepare` is defined as safe to redo (`§6.1` Phase A: "可以安全重试"), so a missing record there
///   costs a repeat, not a wrong read.
/// * `Finalize` *is* the persistence work -- its steps commit the snapshot and the revision, and a
///   failure there already has a recovery-aware path (`mark_apply_recovery_failed`). A record before
///   a record would be a write about a write.
/// * `Cutover` is the only window in which a step can change the running system while the journal
///   still says "nothing was touched". That is the state `§6.1` asks a pending guard to close.
pub const fn needs_intent_record(phase: ApplyPhase) -> bool {
    matches!(phase, ApplyPhase::Cutover)
}

const _: () = {
    assert!(
        needs_intent_record(ApplyPhase::Cutover),
        "the guard exists for the cutover window; if that stops being true, everything this file \
         says about crash visibility stops being true too"
    );
    assert!(
        !needs_intent_record(ApplyPhase::Prepare) && !needs_intent_record(ApplyPhase::Finalize),
        "a record per prepare or finalize step would double the journal's durable traffic for no \
         safety, and the file's own argument against that is this line"
    );
};

/// The store-side hook that makes `§6.1` Phase B's "必须允许 crash recovery 识别执行到哪一步" hold for
/// a process that dies, not only for a run that returns.
///
/// One method, called immediately before each cutover step. The sink writes the intent (cursor at the
/// step about to start, with the two world-touched flags set by `recovery::advance_apply_phase`), and
/// its refusal is what stops the step from running.
///
/// There is deliberately no "step finished" call: the *next* intent record says everything the
/// previous progress record would have ("steps before `k` are done, `k` may have started"), and the
/// end-of-plan fold owns the last position. A second write per step doubles the journal's durability
/// traffic for information the next write already carries -- and `crates/caly-engine/tests/
/// cutover_intent_guard.rs` asserts the one-write-per-step figure, so a redundant write is caught.
pub trait EffectCursor {
    /// Record that step `step_index` of `phase` is about to start.
    ///
    /// `Err(refusal)` means the journal could not be written, so the step must not run. The guard is
    /// the point: "record before you touch the world" is only an invariant if refusing to record
    /// refuses to touch.
    fn record_intent(&mut self, phase: ApplyPhase, step_index: usize) -> Result<(), CursorRefusal>;
}

/// Records nothing: the behaviour every call site had before the guard existed, and what
/// [`execute_effect_plan`] uses so the simulation harnesses keep their exact output.
#[derive(Clone, Copy, Debug, Default, Eq, PartialEq)]
pub struct NoCursor;

impl EffectCursor for NoCursor {
    fn record_intent(
        &mut self,
        _phase: ApplyPhase,
        _step_index: usize,
    ) -> Result<(), CursorRefusal> {
        Ok(())
    }
}

/// Execute the forward half of an `EffectPlan` against a runtime, with no journal cursor.
///
/// This function is pure with respect to storage: it produces the report and the
/// *next* journal record, and leaves persistence to the caller (`EngineHandle`), so
/// that execution can be driven from tests, the worker, or the daemon alike.
///
/// `NoCursor` means the cutover window is not announced before it opens, which is right for a
/// simulation and wrong for a deployment -- so the worker calls
/// [`execute_effect_plan_with_cursor`], and `crates/caly-arch-test` fails any production `src/`
/// file that calls this variant instead.
pub fn execute_effect_plan(
    plan: &EffectPlan,
    journal: &ApplyJournalRecord,
    runtime: &dyn EffectRuntime,
    policy: &ExecutionPolicy,
) -> EffectExecution {
    execute_effect_plan_with_cursor(plan, journal, runtime, policy, &mut NoCursor)
}

/// [`execute_effect_plan`] plus the `§6.1` Phase B pending guard.
pub fn execute_effect_plan_with_cursor(
    plan: &EffectPlan,
    journal: &ApplyJournalRecord,
    runtime: &dyn EffectRuntime,
    policy: &ExecutionPolicy,
    cursor: &mut dyn EffectCursor,
) -> EffectExecution {
    if let Err(reason) =
        validate_effect_plan(plan, policy).and_then(|()| validate_resume_boundary(journal, plan))
    {
        return EffectExecution {
            plan_id: plan.id.0.clone(),
            status: ExecutionStatus::Rejected { reason },
            steps: Vec::new(),
            compensations: Vec::new(),
            cutover_started: false,
            net_effect_started: false,
            probe_passed: false,
            snapshot_marked: false,
            committed_revision: None,
        };
    }

    let mut execution = EffectExecution {
        plan_id: plan.id.0.clone(),
        status: ExecutionStatus::Completed,
        steps: Vec::new(),
        compensations: Vec::new(),
        cutover_started: false,
        net_effect_started: false,
        probe_passed: false,
        snapshot_marked: false,
        committed_revision: None,
    };

    let mut applied_before_crash = 0usize;

    for (index, step) in plan.steps.iter().enumerate() {
        if policy.fail_after_step == Some(applied_before_crash) {
            let failure = StepFailure::new(
                "simulated-crash",
                format!(
                    "execution halted after {applied_before_crash} applied step(s); step {:02} never started",
                    index + 1
                ),
                true,
            );
            execution
                .steps
                .push(record_skipped(index, step, StepSkip::CrashInjected));
            finish_with_failure(plan, runtime, &mut execution, index, failure);
            return execution;
        }

        let phase = phase_of(step);
        if policy.require_probe_before_commit
            && matches!(
                step,
                EffectStep::MarkSnapshot { .. } | EffectStep::CommitRevision { .. }
            )
            && !execution.probe_passed
        {
            let failure = StepFailure::new(
                "unverified-commit",
                format!(
                    "refusing {:?} at step {:02}: no successful Probe in this execution",
                    step_kind_name(step),
                    index + 1
                ),
                false,
            );
            execution.steps.push(record_skipped(
                index,
                step,
                StepSkip::Gate {
                    reason: "unverified-commit",
                },
            ));
            finish_with_failure(plan, runtime, &mut execution, index, failure);
            return execution;
        }

        // `§6.1` Phase B's pending guard: announce the step, or do not run it. It sits after every
        // gate that can skip the step (crash injection, verify-before-commit), because a step that
        // will not run must not leave a record saying it was about to.
        if needs_intent_record(phase) {
            if let Err(refusal) = cursor.record_intent(phase, index) {
                let failure =
                    StepFailure::new("journal-intent-refused", refusal.message, refusal.retryable);
                execution.steps.push(record_skipped(
                    index,
                    step,
                    StepSkip::Gate {
                        reason: "journal-intent-refused",
                    },
                ));
                finish_with_failure(plan, runtime, &mut execution, index, failure);
                return execution;
            }
        }

        match runtime.execute(phase, step) {
            Ok(evidence) => {
                if let Some(failure) = probe_deadline_failure(step, &evidence) {
                    // The probe ran and told the truth about how long it took; that is the whole
                    // answer. `probe_passed` stays false, so the commit gate below also refuses to
                    // publish a snapshot for this execution.
                    execution.steps.push(ExecutedStep {
                        index,
                        phase,
                        label: step_label(step),
                        outcome: StepOutcome::Failed {
                            failure: failure.clone(),
                        },
                        observations: evidence.observations,
                    });
                    finish_with_failure(plan, runtime, &mut execution, index, failure);
                    return execution;
                }
                execution.steps.push(ExecutedStep {
                    index,
                    phase,
                    label: step_label(step),
                    outcome: StepOutcome::Applied,
                    observations: evidence.observations,
                });
                applied_before_crash += 1;
                if phase == ApplyPhase::Cutover {
                    execution.cutover_started = true;
                    if matches!(step, EffectStep::NetApply { .. }) {
                        execution.net_effect_started = true;
                    }
                }
                if matches!(step, EffectStep::Probe { .. }) {
                    execution.probe_passed = true;
                }
                if let EffectStep::MarkSnapshot { .. } = step {
                    execution.snapshot_marked = true;
                }
                if let EffectStep::CommitRevision { revision } = step {
                    execution.committed_revision = Some(*revision);
                }
            }
            Err(failure) => {
                execution.steps.push(ExecutedStep {
                    index,
                    phase,
                    label: step_label(step),
                    outcome: StepOutcome::Failed {
                        failure: failure.clone(),
                    },
                    observations: Vec::new(),
                });
                finish_with_failure(plan, runtime, &mut execution, index, failure);
                return execution;
            }
        }
    }

    execution
}

fn record_skipped(index: usize, step: &EffectStep, skip: StepSkip) -> ExecutedStep {
    ExecutedStep {
        index,
        phase: phase_of(step),
        label: step_label(step),
        outcome: StepOutcome::Skipped { skip },
        observations: Vec::new(),
    }
}

pub(crate) fn step_kind_name(step: &EffectStep) -> &'static str {
    match step {
        EffectStep::WriteObject { .. } => "write-object",
        EffectStep::MaterializeArtifact { .. } => "materialize",
        EffectStep::DbTxn { .. } => "db-txn",
        EffectStep::SpawnCore { .. } => "spawn-core",
        EffectStep::StopCore { .. } => "stop-core",
        EffectStep::CoreApiCall { .. } => "core-api",
        EffectStep::NetApply { .. } => "net-apply",
        EffectStep::NetRevert { .. } => "net-revert",
        EffectStep::Probe { .. } => "probe",
        EffectStep::MarkSnapshot { .. } => "mark-snapshot",
        EffectStep::CommitRevision { .. } => "commit-revision",
    }
}

/// Fan out a step failure into one of the three documented outcomes.
fn finish_with_failure(
    plan: &EffectPlan,
    runtime: &dyn EffectRuntime,
    base: &mut EffectExecution,
    failed_at: usize,
    failure: StepFailure,
) {
    if !base.cutover_started {
        base.status = ExecutionStatus::FailedBeforeCutover {
            failed_at,
            summary: failure.summary.clone(),
            retryable: failure.retryable,
        };
        return;
    }

    // Cutover already touched the active runtime: unwind in reverse order.
    let mut rollback_ok = true;
    let mut rollback_summary = String::new();
    let mut compensations = Vec::new();
    if plan.compensations.is_empty() {
        rollback_ok = false;
        rollback_summary = "plan declares no compensations; cannot unwind cutover".to_owned();
    } else {
        for (offset, step) in plan.compensations.iter().enumerate().rev() {
            let phase = phase_of(step);
            match runtime.compensate(phase, step) {
                Ok(evidence) => compensations.push(ExecutedStep {
                    index: offset,
                    phase,
                    label: step_label(step),
                    outcome: StepOutcome::Applied,
                    observations: evidence.observations,
                }),
                Err(rollback_failure) => {
                    rollback_ok = false;
                    rollback_summary = format!(
                        "compensation {:02} ({}) failed: {}",
                        offset + 1,
                        step_label(step),
                        rollback_failure.summary
                    );
                    compensations.push(ExecutedStep {
                        index: offset,
                        phase,
                        label: step_label(step),
                        outcome: StepOutcome::Failed {
                            failure: rollback_failure,
                        },
                        observations: Vec::new(),
                    });
                    break;
                }
            }
        }
    }

    base.compensations = compensations;
    base.status = if rollback_ok {
        ExecutionStatus::RolledBack {
            failed_at,
            summary: failure.summary.clone(),
            compensations_run: base.compensations.len(),
        }
    } else {
        ExecutionStatus::RollbackFailed {
            failed_at,
            summary: failure.summary.clone(),
            rollback_summary,
        }
    };
}

/// Fold an execution into the apply journal: advance the cursor, then move the
/// transaction to its terminal state.
///
/// `APPLY_EXECUTION_CENTERLINE.md §12` requires that the journal reflects execution
/// rather than merely existing, and `STORAGE_RECOVERY_EXECUTION_PLAN.md §5` requires
/// that a never-cut-over transaction is abandoned rather than left pending.
pub fn journal_after_execution(
    journal: &ApplyJournalRecord,
    execution: &EffectExecution,
    policy: &ExecutionPolicy,
) -> ApplyJournalRecord {
    // Every interpreted or skipped step consumes one clock tick, so the journal records a
    // monotonic sequence derived from the injected clock rather than a wall reading.
    let updated = policy.timestamp_at(execution.clock_ticks().max(1));

    let advanced = advance_apply_journal_step(
        journal,
        execution.terminal_phase(),
        execution.cursor_step_index(),
        journal.net_effect_started || execution.net_effect_started,
        journal.core_cutover_started || execution.cutover_started,
        updated,
    );

    let state = match &execution.status {
        ExecutionStatus::Completed => ApplyJournalState::Committed,
        ExecutionStatus::Rejected { .. } | ExecutionStatus::FailedBeforeCutover { .. } => {
            ApplyJournalState::Abandoned
        }
        ExecutionStatus::RolledBack { .. } => ApplyJournalState::Reverted,
        ExecutionStatus::RollbackFailed { .. } => ApplyJournalState::RecoveryFailed,
    };

    mark_apply_journal_state(&advanced, state, updated)
}

/// Result of unwinding a plan's compensations (`APPLY_EXECUTION_CENTERLINE.md §5.1`
/// `CompensationRunning -> Recovered | RecoveryFailed`).
#[derive(Clone, Debug, Default, Eq, PartialEq)]
pub struct CompensationRun {
    pub steps: Vec<ExecutedStep>,
    pub failure: Option<StepFailure>,
}

impl CompensationRun {
    pub fn succeeded(&self) -> bool {
        self.failure.is_none()
    }

    pub fn applied_count(&self) -> usize {
        self.steps.iter().filter(|step| step.succeeded()).count()
    }
}

/// Run only the compensation half of a plan, in reverse.
///
/// Returns a report rather than a bare count so the rollback path can log each step, exactly
/// like the apply path does; a rollback that "succeeded" without saying what it undid is not
/// auditable. A failed compensation stops the unwind and is reported, never swallowed.
pub fn run_compensations(plan: &EffectPlan, runtime: &dyn EffectRuntime) -> CompensationRun {
    let mut run = CompensationRun::default();
    for (offset, step) in plan.compensations.iter().enumerate().rev() {
        let phase = phase_of(step);
        match runtime.compensate(phase, step) {
            Ok(evidence) => run.steps.push(ExecutedStep {
                index: offset,
                phase,
                label: step_label(step),
                outcome: StepOutcome::Applied,
                observations: evidence.observations,
            }),
            Err(failure) => {
                run.steps.push(ExecutedStep {
                    index: offset,
                    phase,
                    label: step_label(step),
                    outcome: StepOutcome::Failed {
                        failure: failure.clone(),
                    },
                    observations: Vec::new(),
                });
                run.failure = Some(failure);
                break;
            }
        }
    }
    run
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::sim_runtime::SimulatedRuntime;
    use caly_plan::{
        BlobRef, CoreKind, CoreSpec, Durability, NetworkPlan, PlanId, PrivilegeSet, ProbeKind,
    };
    use caly_storage::build_apply_storage_projection;
    use caly_storage::ApplyStorageProjectionInput;
    use caly_storage::RevisionNumber;

    fn write_object(digest: &str) -> EffectStep {
        EffectStep::WriteObject {
            digest: digest.to_owned(),
            source: BlobRef {
                digest: digest.to_owned(),
                size_hint: Some(128),
            },
            durability: Durability::D2,
        }
    }

    fn plan(steps: Vec<EffectStep>, compensations: Vec<EffectStep>) -> EffectPlan {
        EffectPlan {
            id: PlanId("plan-test".to_owned()),
            steps,
            compensations,
            requires: PrivilegeSet::default(),
            impact: caly_plan::DeployImpact::Restart,
        }
    }

    /// The boundary is `<=`, not `<`: a probe that used exactly its budget is a probe that answered in
    /// time. Getting this off by one is how a deployment fails for taking the time it was granted.
    #[test]
    fn a_probe_that_used_exactly_its_budget_still_counts() {
        let step = EffectStep::Probe {
            probe: caly_plan::ProbeSpec {
                kind: caly_plan::ProbeKind::ApiReady,
                target: None,
            },
            deadline_ms: 1_000,
        };
        assert!(probe_deadline_failure(&step, &StepEvidence::took("ok", 1_000)).is_none());
        let failure = probe_deadline_failure(&step, &StepEvidence::took("ok", 1_001))
            .expect("one millisecond over is over");
        assert_eq!(failure.code, "probe-deadline-exceeded");
        assert!(
            failure.summary.contains("1001ms of its 1000ms budget"),
            "both numbers, always: {failure:?}"
        );
        assert!(
            failure.retryable,
            "a slow answer is a reason to retry, not to give up"
        );
    }

    /// Only probes carry a deadline, so the check must be a no-op for every other step -- a step whose
    /// runtime happens to report elapsed time is not a verification failure.
    #[test]
    fn the_deadline_rule_applies_to_probes_and_to_nothing_else() {
        let step = EffectStep::MarkSnapshot {
            snapshot_id: caly_plan::SnapshotId("snap-1".to_owned()),
        };
        assert!(probe_deadline_failure(&step, &StepEvidence::took("slow", 9_999)).is_none());
    }

    /// `deadline_ms == 0` is refused as a plan defect rather than read as "no limit" or as "no time
    /// allowed" -- both readings turn a missing value into a behaviour, and the second one makes every
    /// apply fail. The refusal must not depend on `enforce_phase_order`.
    #[test]
    fn an_unbudgeted_probe_is_refused_whatever_the_policy_says() {
        let plan = plan(
            vec![EffectStep::Probe {
                probe: caly_plan::ProbeSpec {
                    kind: caly_plan::ProbeKind::ApiReady,
                    target: None,
                },
                deadline_ms: 0,
            }],
            Vec::new(),
        );
        let reason = validate_effect_plan(
            &plan,
            &ExecutionPolicy {
                enforce_phase_order: false,
                ..ExecutionPolicy::default()
            },
        )
        .expect_err("an unset deadline is a plan bug");
        assert!(reason.contains("deadline_ms=0"), "{reason}");
        assert!(
            reason.contains("no limit"),
            "the message has to say which reading it rejected: {reason}"
        );
    }

    #[test]
    fn merged_evidence_reports_the_slowest_part() {
        let mut left = StepEvidence::took("a", 3);
        left.merge(StepEvidence::took("b", 7));
        assert_eq!(
            left.elapsed_ms, 7,
            "summing would invent time nobody waited"
        );
        left.merge(StepEvidence::took("c", 1));
        assert_eq!(
            left.elapsed_ms, 7,
            "and taking the last would hide the run that timed out"
        );
        assert_eq!(left.observations.len(), 3);
    }

    fn pending_journal() -> ApplyJournalRecord {
        build_apply_storage_projection(ApplyStorageProjectionInput {
            apply_txn_id: caly_storage::ApplyTxnId("txn-1".to_owned()),
            trace_id: "trace-1".to_owned(),
            job_id: None,
            profile_id: "profile-1".to_owned(),
            revision_id: caly_storage::RevisionId("rev-1".to_owned()),
            revision_number: RevisionNumber(1),
            semantic_digest: "sha:sem".to_owned(),
            compiled_artifact_digest: "sha:art".to_owned(),
            core_binary_digest: "sha:bin".to_owned(),
            core_identity: "mihomo@1.0".to_owned(),
            effect_plan_id: "plan-test".to_owned(),
            apply_plan_summary: "Restart".to_owned(),
            artifact_file_name: "config.yaml".to_owned(),
            artifact_size_bytes: 128,
            artifact_bytes: b"config: stub".to_vec(),
            content_type: "application/x-yaml".to_owned(),
            runtime_path: "runtime/profile-1/config.yaml".to_owned(),
            selection_memory_digest: None,
            validation_summary: String::new(),
            previous_snapshot_id: None,
            created_at_unix_ms: 0,
        })
        .apply_journal
    }

    #[test]
    fn phase_classification_matches_centerline_document() {
        assert_eq!(
            phase_of(&write_object("d")),
            ApplyPhase::Prepare,
            "write-object must stay in prepare"
        );
        assert_eq!(
            phase_of(&EffectStep::NetApply {
                plan: NetworkPlan {
                    summary: "tun".to_owned(),
                    requires_privilege: true,
                }
            }),
            ApplyPhase::Cutover
        );
        assert_eq!(
            phase_of(&EffectStep::CommitRevision { revision: 1 }),
            ApplyPhase::Finalize
        );
        assert!(phase_rank(ApplyPhase::Prepare) < phase_rank(ApplyPhase::Cutover));
        assert!(phase_rank(ApplyPhase::Cutover) < phase_rank(ApplyPhase::Finalize));
    }

    #[test]
    fn happy_path_commits_after_probe() {
        let runtime = SimulatedRuntime::new();
        let plan = plan(
            vec![
                write_object("sha:art"),
                EffectStep::MaterializeArtifact {
                    digest: "sha:art".to_owned(),
                    at: "runtime/p1/config.yaml".to_owned(),
                    mode: caly_plan::FileMode::ReadOnlyArtifact,
                },
                EffectStep::SpawnCore {
                    spec: CoreSpec {
                        kind: CoreKind::Mihomo,
                        binary_digest: "sha:bin".to_owned(),
                        config_digest: "sha:art".to_owned(),
                    },
                },
                EffectStep::Probe {
                    probe: caly_plan::ProbeSpec {
                        kind: ProbeKind::ApiReady,
                        target: None,
                    },
                    deadline_ms: 1_000,
                },
                EffectStep::MarkSnapshot {
                    snapshot_id: caly_plan::SnapshotId("snap-1".to_owned()),
                },
            ],
            vec![EffectStep::StopCore {
                instance: caly_plan::InstanceId("missing".to_owned()),
                grace_ms: 100,
            }],
        );

        let execution = execute_effect_plan(
            &plan,
            &pending_journal(),
            &runtime,
            &ExecutionPolicy::default(),
        );

        assert_eq!(execution.status, ExecutionStatus::Completed);
        assert!(execution.probe_passed);
        assert!(execution.snapshot_marked);
        assert_eq!(execution.applied_count(), 5);
        let state = runtime.snapshot();
        assert!(state.has_object("sha:art"));
        assert_eq!(state.materialized.len(), 1);
        assert!(state.running_core.is_some());
    }

    #[test]
    fn materialize_before_write_is_rejected_at_runtime() {
        let runtime = SimulatedRuntime::new();
        let plan = plan(
            vec![EffectStep::MaterializeArtifact {
                digest: "sha:ghost".to_owned(),
                at: "runtime/p1/config.yaml".to_owned(),
                mode: caly_plan::FileMode::ReadOnlyArtifact,
            }],
            Vec::new(),
        );
        let execution = execute_effect_plan(
            &plan,
            &pending_journal(),
            &runtime,
            &ExecutionPolicy::default(),
        );
        match &execution.status {
            ExecutionStatus::FailedBeforeCutover { summary, .. } => {
                assert!(summary.contains("never written"), "{summary}");
            }
            other => panic!("expected prepare-phase failure, got {other:?}"),
        }
        assert!(!execution.cutover_started);
    }

    #[test]
    fn commit_without_probe_is_gated() {
        let runtime = SimulatedRuntime::new();
        let plan = plan(
            vec![
                write_object("sha:art"),
                EffectStep::SpawnCore {
                    spec: CoreSpec {
                        kind: CoreKind::Mihomo,
                        binary_digest: "sha:bin".to_owned(),
                        config_digest: "sha:art".to_owned(),
                    },
                },
                EffectStep::MarkSnapshot {
                    snapshot_id: caly_plan::SnapshotId("snap-1".to_owned()),
                },
            ],
            Vec::new(),
        );
        let execution = execute_effect_plan(
            &plan,
            &pending_journal(),
            &runtime,
            &ExecutionPolicy::default(),
        );
        match &execution.status {
            ExecutionStatus::RolledBack { summary, .. }
            | ExecutionStatus::RollbackFailed { summary, .. } => {
                assert!(
                    summary.contains("unverified-commit") || summary.contains("Probe"),
                    "{summary}"
                );
            }
            other => panic!("expected gated failure, got {other:?}"),
        }
        assert!(!execution.snapshot_marked);
    }

    #[test]
    fn out_of_order_plan_is_rejected_without_touching_runtime() {
        let runtime = SimulatedRuntime::new();
        let plan = plan(
            vec![
                EffectStep::SpawnCore {
                    spec: CoreSpec {
                        kind: CoreKind::Mihomo,
                        binary_digest: "sha:bin".to_owned(),
                        config_digest: "sha:art".to_owned(),
                    },
                },
                write_object("sha:late"),
            ],
            Vec::new(),
        );
        let execution = execute_effect_plan(
            &plan,
            &pending_journal(),
            &runtime,
            &ExecutionPolicy::default(),
        );
        assert!(matches!(execution.status, ExecutionStatus::Rejected { .. }));
        assert!(execution.steps.is_empty());
        assert!(runtime.snapshot().log.is_empty());
    }

    #[test]
    fn crash_injection_after_each_step_is_deterministic() {
        let steps = vec![
            write_object("sha:art"),
            EffectStep::MaterializeArtifact {
                digest: "sha:art".to_owned(),
                at: "runtime/p1/config.yaml".to_owned(),
                mode: caly_plan::FileMode::ReadOnlyArtifact,
            },
            EffectStep::SpawnCore {
                spec: CoreSpec {
                    kind: CoreKind::Mihomo,
                    binary_digest: "sha:bin".to_owned(),
                    config_digest: "sha:art".to_owned(),
                },
            },
            EffectStep::Probe {
                probe: caly_plan::ProbeSpec {
                    kind: ProbeKind::ApiReady,
                    target: None,
                },
                deadline_ms: 1_000,
            },
        ];
        let plan = plan(
            steps,
            vec![EffectStep::NetRevert {
                txn_id: caly_plan::NetTxnId("net-1".to_owned()),
            }],
        );

        let mut statuses = Vec::new();
        for cut in 0..=plan.steps.len() {
            let runtime = SimulatedRuntime::new();
            let execution = execute_effect_plan(
                &plan,
                &pending_journal(),
                &runtime,
                &ExecutionPolicy::default().crashing_after(cut),
            );
            statuses.push(execution.status.summary_code().to_owned());
        }
        // Cutting after only Prepare steps must not be treated as a cutover failure:
        // APPLY_EXECUTION_CENTERLINE.md 6.1 Phase A says prepare failure cannot touch the
        // active runtime, so there is nothing to compensate. Cutting after SpawnCore
        // (a cutover step) must roll back, and cutting at the very end must succeed.
        assert_eq!(statuses[0], "apply.failed-before-cutover");
        assert_eq!(statuses[1], "apply.failed-before-cutover");
        assert_eq!(statuses[2], "apply.failed-before-cutover");
        assert_eq!(statuses[3], "apply.recovered");
        assert_eq!(statuses[4], "apply.completed");
    }

    #[test]
    fn compensation_run_reports_each_step_and_stops_at_the_first_failure() {
        let plan = plan(
            Vec::new(),
            vec![
                EffectStep::NetRevert {
                    txn_id: caly_plan::NetTxnId("net-1".to_owned()),
                },
                EffectStep::CoreApiCall {
                    instance: caly_plan::InstanceId("core-1".to_owned()),
                    call: caly_plan::CoreCall::Reload,
                },
            ],
        );

        // Lenient world: both compensations run, in reverse order.
        let ok = run_compensations(&plan, &SimulatedRuntime::new());
        assert!(ok.succeeded());
        assert_eq!(ok.applied_count(), 2);
        assert_eq!(ok.steps[0].index, 1, "the newest step must be undone first");
        assert!(
            ok.steps[0].label.contains("reload"),
            "{}",
            ok.steps[0].label
        );

        // Strict world with no live core: the reload compensation fails and the run stops.
        let strict = SimulatedRuntime::new();
        strict.set_enforce_preconditions(true);
        let failed = run_compensations(&plan, &strict);
        assert!(!failed.succeeded());
        let failure = failed
            .failure
            .expect("a failed compensation must be reported");
        assert_eq!(failure.code, "no-running-core");
        assert_eq!(failed.steps.len(), 1, "the unwind must stop, not continue");
        assert!(matches!(
            failed.steps[0].outcome,
            StepOutcome::Failed { .. }
        ));
    }

    #[test]
    fn journal_state_mapping_covers_every_status() {
        let base = pending_journal();
        let mut execution = EffectExecution {
            plan_id: "plan-test".to_owned(),
            status: ExecutionStatus::Completed,
            steps: Vec::new(),
            compensations: Vec::new(),
            cutover_started: true,
            net_effect_started: true,
            probe_passed: true,
            snapshot_marked: true,
            committed_revision: Some(1),
        };
        assert_eq!(
            journal_after_execution(&base, &execution, &ExecutionPolicy::default()).state,
            ApplyJournalState::Committed
        );

        assert_eq!(execution.clock_ticks(), 0);
        execution.status = ExecutionStatus::Rejected {
            reason: "bad".to_owned(),
        };
        execution.cutover_started = false;
        execution.net_effect_started = false;
        execution.snapshot_marked = false;
        assert_eq!(
            journal_after_execution(&base, &execution, &ExecutionPolicy::default()).state,
            ApplyJournalState::Abandoned
        );

        execution.status = ExecutionStatus::RollbackFailed {
            failed_at: 2,
            summary: "boom".to_owned(),
            rollback_summary: "cannot unwind".to_owned(),
        };
        execution.cutover_started = true;
        let failed = journal_after_execution(&base, &execution, &ExecutionPolicy::default());
        assert_eq!(failed.state, ApplyJournalState::RecoveryFailed);
        assert!(failed.core_cutover_started);
    }
}
