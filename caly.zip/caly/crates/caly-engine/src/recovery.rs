use std::future::Future;

use crate::run_limits::{RunLimits, StoreRefusal};

use caly_storage::{
    advance_apply_journal_step, build_recovery_scan_report, mark_apply_journal_state,
    snapshot_record_from_candidate, ApplyJournalRecord, ApplyJournalState, ApplyPhase,
    ApplyStorageProjection, JournalRecordId, StorageBackend, StorageError,
};

/// What `begin_apply_persistence` proved: the artifact is in the object store, the runtime
/// candidate is materialized, and the transaction is journaled as pending.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct PersistedApplyExecution {
    pub journal: ApplyJournalRecord,
    pub artifact_digest: String,
    pub runtime_path: String,
}

/// The committed truth: snapshot id plus revision id, after `finalize_apply_persistence`.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct FinalizedApplyExecution {
    pub journal: ApplyJournalRecord,
    pub snapshot_id: String,
    pub revision_id: String,
}

// The functions below take `&dyn StorageBackend` rather than a generic `S: ObjectStore + ...`.
// The generic form forced every caller to know which subset of stores a given operation needed,
// and made it impossible to hand the engine a swapped-in backend at all (the engine field was a
// concrete `InMemoryStorage`). One object-safe facade is both simpler and substitutable.

/// Phase A of `docs/engineering/APPLY_EXECUTION_CENTERLINE.md §6.1`: repeatable preparation only.
/// A failure here must leave the active runtime and the previous snapshot untouched.
pub async fn begin_apply_persistence(
    storage: &dyn StorageBackend,
    projection: ApplyStorageProjection,
    ctx: &caly_io::IoContext,
) -> Result<PersistedApplyExecution, StorageError> {
    let object = storage.put(projection.artifact_object.clone(), ctx).await?;
    storage
        .materialize(projection.materialization.clone(), ctx)
        .await?;
    storage
        .put_apply_journal(projection.apply_journal.clone(), ctx)
        .await?;
    Ok(PersistedApplyExecution {
        journal: projection.apply_journal,
        artifact_digest: object.digest.0,
        runtime_path: projection.materialization.runtime_path,
    })
}

/// Whether entering `phase` is what marks "the running system may already have been changed".
///
/// One home for the rule: the write below derives the two flags from it, and `service.rs` asks the
/// same question to decide whether a caller's deadline may refuse the write at all. Two copies of
/// that predicate is how a refusal ends up disagreeing with the record it was supposed to protect
/// (`docs/history/ONBOARDING_NOTES.md §4.81`).
pub const fn phase_starts_world_effects(phase: ApplyPhase) -> bool {
    matches!(phase, ApplyPhase::Cutover | ApplyPhase::Finalize)
}

/// Whether this particular advance is the write that **first** records a world change.
///
/// `true` means the engine must not refuse it on a caller's behalf: the flags are the scanner's only
/// evidence about a core that may already be new, and losing them turns "the caller gave up" into
/// "the next process misreads the crash site". A plain cursor move inside one phase is different --
/// dropping it costs a re-do, not a wrong read -- so that one may be refused.
pub fn advance_records_touched_world(journal: &ApplyJournalRecord, phase: ApplyPhase) -> bool {
    phase_starts_world_effects(phase)
        && (!journal.net_effect_started || !journal.core_cutover_started)
}

/// Move the journal cursor, and record the two flags a recovery scanner depends on.
pub async fn advance_apply_phase(
    storage: &dyn StorageBackend,
    journal: &ApplyJournalRecord,
    phase: ApplyPhase,
    step_index: usize,
    updated_at_unix_ms: i64,
    ctx: &caly_io::IoContext,
) -> Result<ApplyJournalRecord, StorageError> {
    let advanced = advance_apply_journal_step(
        journal,
        phase,
        step_index,
        journal.net_effect_started || phase_starts_world_effects(phase),
        journal.core_cutover_started || phase_starts_world_effects(phase),
        updated_at_unix_ms,
    );
    storage.put_apply_journal(advanced.clone(), ctx).await?;
    Ok(advanced)
}

/// Phase C: publish the new truth. Only ever called after runtime verification succeeded,
/// which is what keeps a failed apply from polluting last-known-good.
pub async fn finalize_apply_persistence(
    storage: &dyn StorageBackend,
    journal: &ApplyJournalRecord,
    snapshot_candidate: &caly_storage::SnapshotCandidate,
    created_at_unix_ms: i64,
    ctx: &caly_io::IoContext,
) -> Result<FinalizedApplyExecution, StorageError> {
    storage
        .put_revision(
            caly_storage::revision_record_from_candidate(snapshot_candidate, created_at_unix_ms),
            ctx,
        )
        .await?;
    storage
        .put_snapshot(
            snapshot_record_from_candidate(
                snapshot_candidate,
                Some(journal.journal_id.clone()),
                created_at_unix_ms,
                true,
            ),
            ctx,
        )
        .await?;
    let committed =
        mark_apply_journal_state(journal, ApplyJournalState::Committed, created_at_unix_ms);
    storage.put_apply_journal(committed.clone(), ctx).await?;
    Ok(FinalizedApplyExecution {
        journal: committed,
        snapshot_id: snapshot_candidate.snapshot_id.0.clone(),
        revision_id: snapshot_candidate.revision_id.0.clone(),
    })
}

pub async fn mark_apply_reverted(
    storage: &dyn StorageBackend,
    journal: &ApplyJournalRecord,
    updated_at_unix_ms: i64,
    ctx: &caly_io::IoContext,
) -> Result<ApplyJournalRecord, StorageError> {
    let reverted =
        mark_apply_journal_state(journal, ApplyJournalState::Reverted, updated_at_unix_ms);
    storage.put_apply_journal(reverted.clone(), ctx).await?;
    Ok(reverted)
}

/// The escalation case: compensation also failed, so recovery cannot be declared finished.
pub async fn mark_apply_recovery_failed(
    storage: &dyn StorageBackend,
    journal: &ApplyJournalRecord,
    updated_at_unix_ms: i64,
    ctx: &caly_io::IoContext,
) -> Result<ApplyJournalRecord, StorageError> {
    let failed = mark_apply_journal_state(
        journal,
        ApplyJournalState::RecoveryFailed,
        updated_at_unix_ms,
    );
    storage.put_apply_journal(failed.clone(), ctx).await?;
    Ok(failed)
}

/// Boot-time scan. The decision must be derivable from stored state alone: a crash leaves
/// nothing in memory behind.
pub async fn scan_recovery_state(
    storage: &dyn StorageBackend,
    ctx: &caly_io::IoContext,
) -> Result<caly_storage::RecoveryScanReport, StorageError> {
    let unresolved = storage.list_unresolved_apply(ctx).await?;
    let pending_os = storage
        .list_pending(ctx)
        .await?
        .into_iter()
        .map(|record| record.id)
        .collect::<Vec<JournalRecordId>>();
    let latest_last_known_good = storage
        .latest_last_known_good(ctx)
        .await?
        .map(|snapshot| snapshot.id);
    Ok(build_recovery_scan_report(
        unresolved,
        pending_os,
        latest_last_known_good,
    ))
}

/// Drive an already-complete future to a value without an executor.
///
/// # Invariant
///
/// Every storage operation in this workspace is synchronous underneath, so these futures are always
/// ready on first poll. This is a deliberate constraint, not an accident: the workspace has no executor
/// dependency (see `docs/history/ONBOARDING_NOTES.md §1.4` and `§3.3`). A backend that actually suspends gets
/// `caly_io::block_on_ready`'s `Busy` text rather than being silently scheduled, so the limitation
/// fails loudly at the seam instead of producing a hang.
///
/// This used to be a second hand-written poll loop (with its own `Wake` implementation), which is how
/// the two copies came to word the same failure differently; it now delegates. `ADR-036` step 0 added
/// the typed driver (`caly_io::runtime::drive`, which can also answer `Timeout` and `Cancelled`) and
/// deliberately left **this** seam on immediate semantics: honouring a caller's `Ctx` deadline here means
/// threading the command context into every store access the engine makes, and that is step 2 of the same
/// ADR. The types and the reachability exist now; the wiring is the next change, and saying so here keeps
/// the gap from being read as done.
pub fn run_ready<F>(future: F) -> Result<F::Output, String>
where
    F: Future,
{
    caly_io::block_on_ready(future)
}

/// [`run_ready`] under a caller's limits: the same one-poll-per-ready-port contract, plus the two
/// checks that can fire *before* the store is touched (`ADR-036 §2.3`).
///
/// The refusal is typed (`StoreRefusal`) rather than flattened, because the difference between
/// "the caller cancelled" and "the caller's time ran out" is exactly what decides how the job settles
/// -- and it must survive to that decision as data, not as a string someone pattern-matches
/// (`RFC-0006 §5.2`). With [`RunLimits::immediate`] the message is `block_on_ready`'s verbatim text and
/// no limits line is appended, so the unbounded path cannot drift from the one every other caller uses.
pub fn run_ready_in<F>(future: F, limits: &RunLimits) -> Result<F::Output, StoreRefusal>
where
    F: Future,
{
    // Charged before the future is polled at all, so a budget refusal never half-runs an access and
    // never leaves the store wondering where the call went.
    limits.charge()?;
    caly_io::drive(future, limits.drive()).map_err(|fault| StoreRefusal::from_fault(&fault, limits))
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::sync::Arc;

    use caly_storage::InMemoryStorage;

    /// The `run_ready` contract, asserted rather than commented: an immediately-ready future
    /// yields its value.
    fn test_ctx() -> caly_io::IoContext {
        caly_io::RequestContext::new(
            caly_io::TraceId::new("recovery-tests"),
            caly_io::Actor::System,
        )
    }

    #[test]
    fn run_ready_yields_ready_futures() {
        assert_eq!(run_ready(async { 7u8 }), Ok(7));
    }

    /// The seam that makes `ADR-036` step 2 non-decorative: with a budget, a store call that
    /// suspends is *driven* rather than refused on the spot; with `immediate()` it is refused.
    /// The fixture is a hand-written suspending future, because no backend in this repo suspends at
    /// this seam -- see `ADR-036 §6bis-quinque` for what that costs us.
    #[test]
    fn a_suspending_store_call_is_driven_to_readiness_within_the_budget() {
        let ready_after_three = Suspends { left: 2 };
        assert_eq!(
            run_ready_in(ready_after_three, &RunLimits::immediate().with_polls(4)),
            Ok(7),
            "four polls is enough for a future that needs three"
        );
        let refused = run_ready_in(Suspends { left: 2 }, &RunLimits::immediate())
            .expect_err("one poll is not three");
        assert_eq!(refused.kind, crate::run_limits::RefusalKind::NotReady);
        assert!(
            refused.limits.is_empty(),
            "no limits, no limits line: {refused:?}"
        );
        let flat = caly_io::block_on_ready(Suspends { left: 2 })
            .expect_err("the same future on the unbounded helper");
        assert_eq!(
            refused.to_string(),
            flat,
            "the wording of a refusal may not depend on which helper you happened to call"
        );
    }

    #[test]
    fn a_refusal_under_limits_names_the_limits_that_caused_it() {
        let token = caly_common::CancelToken::new();
        token.cancel();
        let mut context = caly_common::RequestContext::new(
            caly_common::TraceId::new("refusal-wording"),
            caly_common::Actor::System,
        );
        context.cancel = token;
        context.deadline_ms = Some(40);
        let limits = RunLimits::for_command(&context, None);
        let refused = run_ready_in(async { 1u8 }, &limits).expect_err("the caller already gave up");
        assert_eq!(
            refused.kind,
            crate::run_limits::RefusalKind::CallerCancelled,
            "a fired token must arrive as cancellation, not as congestion: {refused:?}"
        );
        assert!(
            refused.message.contains("call cancelled before poll 1"),
            "{refused}"
        );
        assert!(
            refused.limits.contains("deadline=unjudged(no clock)"),
            "the record has to say the deadline was requested but unjudgeable, not that there was \
             none: {refused:?}"
        );
        assert!(refused.is_caller_side());
        assert!(
            !refused.retryable,
            "a cancellation the caller asked for is not something to retry into existence: {refused:?}"
        );
    }

    /// The refusal decision and the record must come from one predicate, or a deadline can drop the
    /// write whose whole purpose is to say the world changed.
    #[test]
    fn the_immunity_of_a_flag_setting_advance_is_the_rule_the_write_uses() {
        let base = test_journal();
        assert!(
            !advance_records_touched_world(&base, ApplyPhase::Prepare),
            "a prepare-phase cursor move records nothing new, so it may be refused"
        );
        assert!(
            advance_records_touched_world(&base, ApplyPhase::Cutover),
            "the cutover advance is the first one that sets both flags"
        );
        let advanced = advance_apply_journal_step(
            &base,
            ApplyPhase::Cutover,
            4,
            base.net_effect_started || phase_starts_world_effects(ApplyPhase::Cutover),
            base.core_cutover_started || phase_starts_world_effects(ApplyPhase::Cutover),
            9,
        );
        assert!(
            advanced.net_effect_started && advanced.core_cutover_started,
            "the derived flags are what the predicate was talking about: {advanced:?}"
        );

        // Once both flags are up, a later cutover write records nothing new and is refusable again.
        let mut settled = base.clone();
        settled.net_effect_started = true;
        settled.core_cutover_started = true;
        assert!(!advance_records_touched_world(
            &settled,
            ApplyPhase::Cutover
        ));
    }

    /// A store call that needs `left + 1` polls before it answers: the only way to test that the
    /// engine *drives* rather than refuses, given no backend here suspends on its own.
    struct Suspends {
        left: u8,
    }

    impl std::future::Future for Suspends {
        type Output = u8;

        fn poll(
            mut self: std::pin::Pin<&mut Self>,
            _cx: &mut std::task::Context<'_>,
        ) -> std::task::Poll<u8> {
            if self.left == 0 {
                std::task::Poll::Ready(7)
            } else {
                self.left -= 1;
                std::task::Poll::Pending
            }
        }
    }

    /// Built from the real planner rather than written out field by field: a hand-made record would
    /// silently stop matching what the apply path actually stores.
    fn test_journal() -> caly_storage::ApplyJournalRecord {
        crate::plan_apply_request(caly_api::ApplyRequest {
            profile_id: caly_api::ProfileId("demo-tun-profile".to_owned()),
            dry_run: false,
            strict: false,
        })
        .expect("plan")
        .storage_projection
        .apply_journal
    }

    /// A store call that records whether it was *polled*. A gate whose entire job is "do not touch the
    /// store" is untestable without one: the refusal's value and message are identical whether or not
    /// the future ran, which is exactly how a `drive`-before-`charge` mutation survived the first
    /// falsification run (`docs/history/ONBOARDING_NOTES.md §4.98`).
    struct CountsPolls {
        polls: Arc<std::sync::atomic::AtomicUsize>,
        value: u8,
    }

    impl std::future::Future for CountsPolls {
        type Output = u8;

        fn poll(
            self: std::pin::Pin<&mut Self>,
            _cx: &mut std::task::Context<'_>,
        ) -> std::task::Poll<u8> {
            self.polls.fetch_add(1, std::sync::atomic::Ordering::SeqCst);
            std::task::Poll::Ready(self.value)
        }
    }

    /// The whole point of step 3: `IoBudget::max_requests` is read by someone, and the refusal says so
    /// with the two numbers an operator needs, before the store is asked.
    #[test]
    fn a_spent_request_budget_refuses_the_next_access_and_names_both_numbers() {
        let mut context = caly_common::RequestContext::new(
            caly_common::TraceId::new("budget-spent"),
            caly_common::Actor::Cli,
        );
        context.io_budget = caly_common::IoBudget {
            max_bytes: None,
            max_requests: Some(1),
        };
        let limits = RunLimits::for_command(&context, None);
        let polled = Arc::new(std::sync::atomic::AtomicUsize::new(0));
        assert_eq!(limits.billed(), 0);
        assert_eq!(
            run_ready_in(
                CountsPolls {
                    polls: Arc::clone(&polled),
                    value: 5,
                },
                &limits
            )
            .expect("the first access is within budget"),
            5
        );
        assert_eq!(
            limits.billed(),
            1,
            "the access was attempted, so it is billed"
        );
        assert_eq!(polled.load(std::sync::atomic::Ordering::SeqCst), 1);

        let refusal = run_ready_in(
            CountsPolls {
                polls: Arc::clone(&polled),
                value: 6,
            },
            &limits,
        )
        .expect_err("budget=1/1 is spent");
        assert_eq!(
            polled.load(std::sync::atomic::Ordering::SeqCst),
            1,
            "the refusal must not poll the store call at all -- that is the only observable meaning of \
             \"refused before the store was asked\""
        );
        assert_eq!(
            refusal.kind,
            crate::run_limits::RefusalKind::BudgetExhausted
        );
        assert!(
            refusal
                .message
                .contains("allows 1 accounted store access(es); 1 already made"),
            "{:?}",
            refusal.message
        );
        assert!(
            !refusal.retryable,
            "a spent budget is not congestion: {refusal:?}"
        );
        assert!(refusal.limits.contains("budget=1/1"), "{refusal:?}");
        assert_eq!(
            limits.billed(),
            1,
            "a refusal must not charge the command for an attempt that never happened -- otherwise a retry loop is billed for its own refusals"
        );
    }

    /// Uncapped is not uncounted: `billed` keeps one meaning so the number in `describe` can be read
    /// either way.
    #[test]
    fn an_uncapped_budget_is_still_counted() {
        let mut context = caly_common::RequestContext::new(
            caly_common::TraceId::new("budget-none"),
            caly_common::Actor::Cli,
        );
        context.io_budget = caly_common::IoBudget::unlimited();
        let limits = RunLimits::for_command(&context, None);
        for want in 1u8..=5 {
            assert_eq!(
                run_ready_in(async move { want }, &limits).expect("never capped"),
                want
            );
        }
        assert_eq!(limits.billed(), 5);
        assert!(
            limits.describe().contains("budget=5/uncapped"),
            "{limits:?}"
        );
    }

    /// Two true statements about one call, one order. The budget gate asks about the past (how many
    /// accesses were made), `drive` asks about the present (cancelled? time out?), so the budget wins
    /// -- and the attempted access is still billed, because "billed" means attempted.
    #[test]
    fn the_budget_gate_runs_first_and_a_cancelled_attempt_is_still_billed() {
        let mut context = caly_common::RequestContext::new(
            caly_common::TraceId::new("budget-vs-cancel"),
            caly_common::Actor::Cli,
        );
        context.io_budget = caly_common::IoBudget {
            max_bytes: None,
            max_requests: Some(1),
        };
        context.cancel = caly_common::CancelToken::pre_cancelled();
        let limits = RunLimits::for_command(&context, None);
        let refused =
            run_ready_in(async { 1u8 }, &limits).expect_err("cancelled before the first poll");
        assert_eq!(
            refused.kind,
            crate::run_limits::RefusalKind::CallerCancelled
        );
        assert_eq!(
            limits.billed(),
            1,
            "the access was attempted as far as the driver is concerned, so it counts"
        );
        let second =
            run_ready_in(async { 2u8 }, &limits).expect_err("and now the budget is gone too");
        assert_eq!(
            second.kind,
            crate::run_limits::RefusalKind::BudgetExhausted,
            "with both true, the record says which one the engine checked first"
        );
    }

    /// The recording paths take no limits, so they are neither refusable nor billable. Asserted, so the
    /// rule cannot quietly become "some bookkeeping writes are charged and some are not".
    #[test]
    fn unrefusable_writes_are_not_billed() {
        let storage: Arc<dyn StorageBackend> = Arc::new(InMemoryStorage::new());
        let mut context = caly_common::RequestContext::new(
            caly_common::TraceId::new("unbilled"),
            caly_common::Actor::Cli,
        );
        context.io_budget = caly_common::IoBudget {
            max_bytes: None,
            max_requests: Some(1),
        };
        let limits = RunLimits::for_command(&context, None);
        let journal = crate::plan_apply_request(caly_api::ApplyRequest {
            profile_id: caly_api::ProfileId("demo-tun-profile".to_owned()),
            dry_run: false,
            strict: false,
        })
        .expect("plan")
        .storage_projection
        .apply_journal;

        run_ready_in(
            storage.put_apply_journal(journal.clone(), &test_ctx()),
            &limits,
        )
        .expect("one access, in budget")
        .expect("the store accepts it");
        assert_eq!(limits.billed(), 1);
        for _ in 0..3 {
            run_ready(storage.put_apply_journal(journal.clone(), &test_ctx()))
                .expect("the recording path")
                .expect("the store accepts it");
        }
        assert_eq!(
            limits.billed(),
            1,
            "writes that cannot be refused must not consume the budget -- otherwise the cap silently becomes a cap on the engine's own bookkeeping"
        );
    }

    /// `StorageBackend` must be usable as a trait object, otherwise the engine's `Arc<dyn ...>`
    /// field cannot exist at all.
    #[test]
    fn in_memory_storage_satisfies_the_backend_facade() {
        let backend: Arc<dyn StorageBackend> = Arc::new(InMemoryStorage::new());
        let latest =
            run_ready(backend.latest_last_known_good(&test_ctx())).expect("immediate read");
        assert!(latest.expect("no storage error").is_none());
    }
}
