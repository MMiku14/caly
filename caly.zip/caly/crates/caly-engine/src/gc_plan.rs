//! The garbage-collection **plan**: what a cycle would remove, and whether that answer may be
//! trusted (`ADR-038` step 1).
//!
//! `RFC-0007 §13` fixes the root set and the behaviour rules, and `caly_storage::gc` has implemented
//! that policy since round 5 -- with tests, and with no producer and no consumer
//! (`docs/ONBOARDING_NOTES.md §4.73`). The consequence is not a missing feature but an invisible one:
//! a store that can only grow looks healthy from every existing surface. This module is the first half
//! of wiring it up: **compute the plan and report it, delete nothing**. Step 2 turns an unqualified
//! report into a job; a report nobody can read first would have made that step unverifiable.
//!
//! Two rules shape the design, and both are about not lying:
//!
//! * **The root set is all-or-nothing.** `§13.1` names six classes of root. A plan computed from a
//!   subset is worse than no plan, because it says "nothing references these" about objects whose only
//!   protector is the class nobody looked at. So every class must be *obtainable*: a backend that
//!   cannot answer becomes a [`GcRootGap`] that zeroes the collect list and explains itself, and the
//!   plan is reported as unsafe to run. `Unsupported` is a gap; a real fault is an error.
//! * **"Now" is not a caller argument.** `GcPolicy::now_unix_ms` comes from the engine's injected
//!   execution clock -- the same timeline the apply journal and the support bundle use -- so a request
//!   cannot choose the instant that makes objects look old. `ADR-035 §6bis-quater` records why this
//!   half was left open after step 3; this module closes it for the operator-facing path.
//!
//! The pure half ([`build_gc_plan`]) takes already-read inputs, so the composition of roots, bounds
//! and reporting limits can be unit-tested without a store; the reading half lives in
//! [`crate::service::EngineHandle::storage_gc_plan`].

use caly_storage::gc::{
    collect_gc_roots, plan_object_gc, GcEligibility, GcGraph, GcPolicy, GcRefusal,
};
use caly_storage::{ApplyJournalRecord, CasObjectRef, RevisionRecord, SnapshotRecord};

use crate::state::EngineState;

/// How much of the retained set a plan reports.
///
/// A plan is a response, and `RFC-0002 §9` allows no unbounded collection in one: `GcPlan::blocked`
/// carries an entry per retained object, so on a large store the *answer* would be bigger than the
/// thing it is describing. `retained_total` therefore counts everything and `retained_sample` is
/// capped -- with `is_truncated` saying so, because a truncated list that does not announce itself is
/// the failure `ADR-035 §2.1` refuses for directory listings too.
pub const GC_PLAN_SAMPLE_LIMIT: usize = 32;

/// Grace period applied when a caller does not ask for one: the same 15 minutes
/// `caly_storage::gc::GcPolicy::default()` uses, restated here deliberately -- the report and a real
/// cycle must not disagree about what "recently written" means just because two defaults were written
/// in two places.
pub const DEFAULT_GC_GRACE_PERIOD_MS: i64 = 15 * 60 * 1000;

/// The largest grace period a plan may be asked for (30 days).
pub const MAX_GC_GRACE_PERIOD_MS: i64 = 30 * 24 * 60 * 60 * 1000;

/// Objects a plan may list as collectable. This is also what a real cycle would remove per run, so
/// the report cannot promise more than the collector is allowed to do.
pub const DEFAULT_GC_MAX_DELETIONS: usize = 256;

/// Upper bound on that knob, so a request cannot ask for "everything in the store, in one report".
pub const MAX_GC_MAX_DELETIONS: usize = 4096;

const _: () = assert!(DEFAULT_GC_GRACE_PERIOD_MS <= MAX_GC_GRACE_PERIOD_MS);
const _: () = assert!(DEFAULT_GC_MAX_DELETIONS <= MAX_GC_MAX_DELETIONS);
const _: () = assert!(GC_PLAN_SAMPLE_LIMIT > 0);

/// A root class the plan could not assemble.
///
/// `actionable` separates the two kinds of "cannot" that a report has to tell apart. A missing or
/// unreadable record is damage an operator can put back; a backend that has no such query, or a store
/// whose dates and the engine's clock are on different timelines, needs a code or configuration change.
/// `doctor` warns only for the first kind -- and that is not a courtesy. Its contract
/// (`crates/caly-daemon/tests/durable_boot.rs`) is that a healthy store produces no warnings, and the
/// round that added this report briefly made every durable deployment warn forever
/// (`docs/ONBOARDING_NOTES.md §4.76`).
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct GcRootGap {
    /// Which class of `§13.1` is missing, stable and machine-readable.
    pub class: &'static str,
    /// What the backend said, and what it therefore cannot protect.
    pub detail: String,
    /// Whether an operator can clear this without shipping anything.
    pub actionable: bool,
}

impl GcRootGap {
    /// A gap that describes the deployment rather than something to fix in it.
    pub fn new(class: &'static str, detail: impl Into<String>) -> Self {
        Self {
            class,
            detail: detail.into(),
            actionable: false,
        }
    }

    /// A gap whose cause is damage: the thing named by the store cannot be read back.
    pub fn damage(class: &'static str, detail: impl Into<String>) -> Self {
        Self {
            class,
            detail: detail.into(),
            actionable: true,
        }
    }
}

/// One retained object and the roots holding it (`§13.1`'s "why not" answer).
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct GcRetainedEntry {
    pub digest: String,
    pub reasons: Vec<String>,
}

/// Requested bounds for a plan. `None` means "use the default", not "no bound".
#[derive(Clone, Copy, Debug, Default, Eq, PartialEq)]
pub struct GcPlanBounds {
    pub grace_period_ms: Option<i64>,
    pub max_deletions: Option<u32>,
}

/// Why a request's own bounds were refused. A plan is a read, but it is a read with knobs, and a knob
/// outside its declared range is the caller breaking the query's contract -- which `ERRORS.md §5.1`
/// files under `CONFIG_INVALID`, not under "the store is broken".
#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub enum GcBoundsRefusal {
    NegativeGracePeriod(i64),
    GracePeriodTooLarge {
        requested: i64,
        limit: i64,
    },
    MaxDeletionsTooLarge {
        requested: u32,
        limit: u32,
    },
    /// `max_deletions: 0` asks "show me a plan that could not act", which is not a question worth
    /// answering: `DEFAULT_GC_MAX_DELETIONS` already bounds a real cycle, and omitting the field says
    /// the same thing more clearly.
    ZeroMaxDeletions,
}

impl GcBoundsRefusal {
    pub fn message(&self) -> String {
        match self {
            Self::NegativeGracePeriod(requested) => format!(
                "grace_period_ms must not be negative: {requested} (a negative grace period would \
                 make every object look infinitely old)"
            ),
            Self::GracePeriodTooLarge { requested, limit } => format!(
                "grace_period_ms {requested} exceeds the supported limit {limit}; omit it for the \
                 default {DEFAULT_GC_GRACE_PERIOD_MS}"
            ),
            Self::MaxDeletionsTooLarge { requested, limit } => {
                format!("max_deletions {requested} exceeds the supported limit {limit}")
            }
            Self::ZeroMaxDeletions => format!(
                "max_deletions must be at least 1; omit it for the default \
                 {DEFAULT_GC_MAX_DELETIONS}"
            ),
        }
    }
}

/// Bounds after validation, with defaults applied.
#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub struct ResolvedGcBounds {
    pub grace_period_ms: i64,
    pub max_deletions: usize,
}

impl GcPlanBounds {
    /// Clamp-or-refuse, the same shape `caly_daemon::paging` uses for event pages: an out-of-range
    /// bound is refused rather than silently narrowed, and only a *large but legal* value is clamped.
    ///
    /// The ranges live here, next to the constants they bound, and a façade validates by calling this
    /// rather than repeating them: two copies of a bound is how a validator and the thing it
    /// validates start disagreeing about what a request may ask for.
    pub fn resolve(self) -> Result<ResolvedGcBounds, GcBoundsRefusal> {
        let grace_period_ms = match self.grace_period_ms {
            Some(value) if value < 0 => return Err(GcBoundsRefusal::NegativeGracePeriod(value)),
            Some(value) if value > MAX_GC_GRACE_PERIOD_MS => {
                return Err(GcBoundsRefusal::GracePeriodTooLarge {
                    requested: value,
                    limit: MAX_GC_GRACE_PERIOD_MS,
                })
            }
            Some(value) => value,
            None => DEFAULT_GC_GRACE_PERIOD_MS,
        };
        let max_deletions = match self.max_deletions {
            Some(0) => return Err(GcBoundsRefusal::ZeroMaxDeletions),
            Some(value) if value > MAX_GC_MAX_DELETIONS as u32 => {
                return Err(GcBoundsRefusal::MaxDeletionsTooLarge {
                    requested: value,
                    limit: MAX_GC_MAX_DELETIONS as u32,
                })
            }
            Some(value) => value as usize,
            None => DEFAULT_GC_MAX_DELETIONS,
        };
        Ok(ResolvedGcBounds {
            grace_period_ms,
            max_deletions,
        })
    }
}

/// Everything the pure half needs. Built by the handle so the reading and the deciding can be tested
/// apart; `gaps` is where the reader reports a class it could not obtain.
#[derive(Clone, Debug, Default)]
pub struct GcPlanInputs<'a> {
    pub objects: Vec<CasObjectRef>,
    pub retained_snapshots: Vec<SnapshotRecord>,
    pub revisions: Vec<RevisionRecord>,
    pub unfinished_journals: Vec<ApplyJournalRecord>,
    pub running_job_artifacts: Vec<String>,
    pub active_snapshot: Option<&'a SnapshotRecord>,
    pub last_known_good: Option<&'a SnapshotRecord>,
    pub now_unix_ms: i64,
    /// Which clock produced `now_unix_ms`; see [`GcPlanSummary::now_source`].
    pub now_source: &'static str,
    pub grace_period_ms: i64,
    pub max_deletions: usize,
    pub idle: bool,
    pub pending_deployments: usize,
    pub gaps: Vec<GcRootGap>,
}

/// The reported plan. Every number in it is about the store as the plan saw it, and nothing was
/// deleted to produce it.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct GcPlanSummary {
    pub now_unix_ms: i64,
    /// Which clock `now_unix_ms` came from: `"storage-clock"` when one was injected, else
    /// `"execution-policy-base"`. Reported rather than implied because the two are **not**
    /// interchangeable -- object ages may come from the store's file dates
    /// (`ADR-035 §2.4`) while journal cursors come from the deterministic policy base (`ADR-022`), and
    /// comparing across them is `docs/ONBOARDING_NOTES.md §4.74`. A reader has to be able to tell
    /// "nothing is collectable" from "I cannot judge freshness" without reading this crate.
    pub now_source: &'static str,
    pub grace_period_ms: i64,
    pub max_deletions: usize,
    pub sample_limit: usize,
    pub objects_total: usize,
    pub snapshots_total: usize,
    pub revisions_total: usize,
    pub unfinished_journals: usize,
    /// The digests a cycle removes. This is not a *description* of a plan: [`Self::sweep`] is the
    /// list a collection job deletes, in order, and the field here is its rendering. Empty whenever
    /// [`Self::roots_complete`] is false, because a partial root set cannot license a list.
    pub collect: Vec<String>,
    /// The same list in the store's own type, ready for `caly_storage::gc::sweep_objects`. Kept
    /// alongside rather than rebuilt at the delete site so the report and the deletion cannot drift
    /// apart (`ADR-038 §2`).
    pub sweep: Vec<caly_storage::ObjectDigest>,
    pub retained_total: usize,
    pub retained_sample: Vec<GcRetainedEntry>,
    /// Retained-by-capacity, not retained-by-root: objects that are unreferenced and would be
    /// collected by a later cycle. `GcPlan::blocked` mixes the two (entries with no reasons), so this
    /// counts them out rather than inflating `retained_total`.
    pub deferred_over_cap: usize,
    pub skipped_for_grace: usize,
    pub idle: bool,
    pub pending_deployments: usize,
    pub gaps: Vec<GcRootGap>,
}

impl GcPlanSummary {
    pub fn roots_complete(&self) -> bool {
        self.gaps.is_empty()
    }

    /// Whether a real cycle would be allowed to run right now: `§13.2`'s eligibility *and* a root set
    /// worth trusting. Derived rather than stored, so the report cannot say "would run" while naming
    /// a gap that makes running unsafe.
    pub fn would_run(&self) -> bool {
        self.roots_complete() && eligibility_of(self).check().is_ok()
    }

    pub fn is_truncated(&self) -> bool {
        self.retained_total > self.retained_sample.len()
    }

    /// Why a cycle would not run, in the operator's terms. `None` means "it would".
    pub fn refusal(&self) -> Option<String> {
        if !self.roots_complete() {
            let classes: Vec<&str> = self.gaps.iter().map(|gap| gap.class).collect();
            return Some(format!(
                "root set incomplete: {} (`RFC-0007 §13.1`); no object may be deleted on a partial \
                 root set",
                classes.join(", ")
            ));
        }
        match eligibility_of(self).check() {
            Ok(()) => None,
            Err(GcRefusal::NotIdle) => Some("engine is not idle".to_owned()),
            Err(GcRefusal::PendingDeployments(count)) => {
                Some(format!("{count} unfinished deployment transaction(s)"))
            }
            Err(GcRefusal::NothingToInspect) => Some("nothing to inspect".to_owned()),
        }
    }

    /// The one-line form `doctor` and the parity harness print. Derived from the same fields the view
    /// carries, so the two cannot tell different stories about one plan.
    pub fn summary_line(&self) -> String {
        format!(
            "gc plan objects={} collect={} retained={} deferred={} grace={}ms now={}@{} gaps={} actionable={} would_run={}{} sample_limit={}",
            self.objects_total,
            self.collect.len(),
            self.retained_total,
            self.deferred_over_cap,
            self.grace_period_ms,
            self.now_unix_ms,
            self.now_source,
            self.gaps.len(),
            self.gaps.iter().filter(|gap| gap.actionable).count(),
            self.would_run(),
            if self.is_truncated() {
                " truncated=true"
            } else {
                ""
            },
            self.sample_limit
        )
    }
}

/// Read one root class, and turn "this backend cannot answer" into a [`GcRootGap`].
///
/// The three outcomes are deliberately different. `Unsupported` is a *capability* answer, so the plan
/// still gets built and reports the hole; any other failure is damage, and a damaged store must not
/// be handed a deletion list at all; `Ok` is just data. Folding the first into the second would make a
/// minimal backend un diagnosable, and folding it into the third would make it look empty.
pub fn root_class<T>(
    gaps: &mut Vec<GcRootGap>,
    class: &'static str,
    why_it_matters: &str,
    read: Result<Result<Vec<T>, caly_storage::StorageError>, String>,
) -> Result<Vec<T>, String> {
    match read? {
        Ok(value) => Ok(value),
        Err(failure) if failure.kind == caly_storage::StorageErrorKind::Unsupported => {
            gaps.push(GcRootGap::new(
                class,
                format!("{why_it_matters}: {}", failure.summary),
            ));
            Ok(Vec::new())
        }
        Err(failure) => Err(failure.summary),
    }
}

/// Compose the root set, apply the policy, and bound the answer.
///
/// Pure on purpose: no store access, so a test can hand it exactly the inputs a backend produced --
/// including the case that matters most, a class that is missing.
pub fn build_gc_plan(inputs: &GcPlanInputs<'_>) -> GcPlanSummary {
    let mut gaps = inputs.gaps.clone();
    let source = inputs.now_source;
    // The grace period is a *comparison*, and a comparison needs both sides on one timeline. Object
    // ages may come from the port (a real filesystem's mtime, `ADR-035 §6bis-quater`) while `now` is
    // the engine's injected execution clock -- two clocks that no code relates. An object dated after
    // `now` proves the mismatch, and then "inside the grace period" is a fact about the clocks rather
    // than about the object. Refuse, and say which is ahead (`docs/ONBOARDING_NOTES.md §4.74`).
    if let Some(newest) = inputs
        .objects
        .iter()
        .filter_map(|object| object.stored_at_unix_ms)
        .max()
    {
        let now = inputs.now_unix_ms;
        if newest > now {
            gaps.push(GcRootGap::new(
                "clock-timeline",
                format!("the store dates an object at {newest}, after the plan's now={now} (source: {source}): the ages and the clock are not on one timeline, so grace cannot be judged; inject the clock the store reads its dates from (ADR-038 §3)"),
            ));
        }
    }

    let policy = GcPolicy {
        grace_period_ms: inputs.grace_period_ms,
        now_unix_ms: inputs.now_unix_ms,
        max_deletions: inputs.max_deletions,
    };
    let graph = GcGraph {
        active_snapshot: inputs.active_snapshot,
        last_known_good: inputs.last_known_good,
        retained_snapshots: &inputs.retained_snapshots,
        revisions: &inputs.revisions,
        unfinished_journals: &inputs.unfinished_journals,
        running_job_artifacts: &inputs.running_job_artifacts,
        pinned: &[],
    };

    let roots = collect_gc_roots(&graph, &policy, &inputs.objects);
    let plan = plan_object_gc(&inputs.objects, &roots, &policy);

    // `GcPlan::blocked` holds "protected by a root" and "unreferenced but over the per-cycle cap"
    // together; the second kind has no reasons. Counting them as retained would tell an operator the
    // data is rooted when the only reason is arithmetic.
    let deferred_over_cap = plan
        .blocked
        .iter()
        .filter(|blocked| blocked.reasons.is_empty())
        .count();
    let retained_sample = plan
        .blocked
        .iter()
        .filter(|blocked| !blocked.reasons.is_empty())
        .take(GC_PLAN_SAMPLE_LIMIT)
        .map(|blocked| GcRetainedEntry {
            digest: blocked.digest.clone(),
            reasons: blocked
                .reasons
                .iter()
                .map(|reason| reason.as_str().to_owned())
                .collect(),
        })
        .collect();

    let mut summary = GcPlanSummary {
        now_unix_ms: inputs.now_unix_ms,
        now_source: inputs.now_source,
        grace_period_ms: inputs.grace_period_ms,
        max_deletions: inputs.max_deletions,
        sample_limit: GC_PLAN_SAMPLE_LIMIT,
        objects_total: inputs.objects.len(),
        snapshots_total: inputs.retained_snapshots.len(),
        revisions_total: inputs.revisions.len(),
        unfinished_journals: inputs.unfinished_journals.len(),
        collect: plan.collect.iter().map(|digest| digest.0.clone()).collect(),
        sweep: plan.collect,
        retained_total: plan.retained,
        retained_sample,
        deferred_over_cap,
        skipped_for_grace: plan.skipped_for_grace,
        idle: inputs.idle,
        pending_deployments: inputs.pending_deployments,
        gaps,
    };

    if !summary.roots_complete() {
        // The one place a computed answer is thrown away on purpose. Listing deletions derived from a
        // partial root set would be the most actionable form of a wrong number -- and clearing the
        // sweep list here, in the same breath, is what stops the report from being merely advisory
        // while the delete path reads its own copy.
        summary.collect.clear();
        summary.sweep.clear();
    }
    summary
}

/// The rule the plan enforces that `§13.2` states for the collector: a cycle runs only when the
/// engine is idle and nothing is mid-deployment. Exposed so `ADR-038 §2`'s job can gate on the *same*
/// function rather than re-deciding eligibility where a plan already refused.
pub fn eligibility_of(summary: &GcPlanSummary) -> GcEligibility {
    GcEligibility {
        idle: summary.idle,
        pending_deployments: summary.pending_deployments,
    }
}

/// The automation job id that turns the idle collector on (`ADR-038 §13.2`).
///
/// It is an *automation job* on purpose: `CommandKind::AutomationPatch` is already the role-gated
/// surface for "may the daemon act on its own", so enabling this reuses the authorization that exists
/// instead of inventing a second switch a caller could flip without a role check.
pub const AUTOMATION_IDLE_GC_JOB_ID: &str = "gc.idle";

/// How many idle checks must pass between two automatic cycles.
///
/// A constant, not a knob: one more tunable number here is one more place for a cadence and a report to
/// disagree. Counted in **idle checks** rather than milliseconds because this engine owns no clock it
/// may poll for a schedule, and a cadence in cycles stays reproducible in a crash matrix (`ADR-022`) in
/// a way a wall-clock one never would be.
pub const IDLE_GC_INTERVAL_CHECKS: u64 = 4;

const _: () = assert!(
    IDLE_GC_INTERVAL_CHECKS > 0,
    "an interval of 0 would fire on every idle check, which is not a cadence but a spin"
);

/// Who asked for a collection cycle. Kept as a string because it is *reported*, not branched on: the
/// engine's record line and the support bundle both carry it, and the caller-visible view does not need
/// a field telling a caller something they already know.
pub const GC_TRIGGER_CALLER: &str = "caller";
pub const GC_TRIGGER_IDLE_AUTOMATION: &str = "automation:gc.idle";

/// Why the collector was or was not enqueued at this check. Exposed as data so a test (and later a
/// `doctor` line) can assert the *reason* instead of the mere absence of a job.
#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub enum IdleGcDecision {
    /// Enqueue a cycle now.
    Enqueue,
    Skip(IdleGcSkip),
}

#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub enum IdleGcSkip {
    /// Nobody enabled the automation job. The counter does not advance while disabled, so a freshly
    /// enabled collector waits a full interval instead of firing mid-unrelated-wait.
    AutomationOff,
    /// Enabled, but this is not a multiple of `IDLE_GC_INTERVAL_CHECKS`.
    NotDue,
    /// The plan refused: not idle, a deployment pending, or a root class it could not assemble.
    PlanRefused,
    /// The plan would run, but there is nothing it can collect. Skipping here is what keeps an idle
    /// daemon from appending a job row (and a dedup entry) every interval forever.
    NothingToCollect,
}

impl IdleGcDecision {
    pub const fn is_enqueue(&self) -> bool {
        matches!(self, Self::Enqueue)
    }

    /// The one-word label a log line or a `doctor` note can carry.
    pub const fn as_str(&self) -> &'static str {
        match self {
            Self::Enqueue => "enqueued",
            Self::Skip(IdleGcSkip::AutomationOff) => "automation-off",
            Self::Skip(IdleGcSkip::NotDue) => "not-due",
            Self::Skip(IdleGcSkip::PlanRefused) => "plan-refused",
            Self::Skip(IdleGcSkip::NothingToCollect) => "nothing-to-collect",
        }
    }
}

/// Is this the check on which the collector is due?
///
/// The counter is **monotone and never reset on fire**, and due-ness is "`interval` divides checks".
/// halves matter: a "checks since last fire" counter that resets would give the second automatic cycle
/// the same idempotency key as the first, and dedup would swallow it -- an idle collector that quietly
/// stops working after one pass, with nothing in the record to say so.
pub const fn idle_gc_check_is_due(checks: u64) -> bool {
    checks > 0 && checks.is_multiple_of(IDLE_GC_INTERVAL_CHECKS)
}

/// The whole decision. `plan_would_run` / `collect_len` come from the plan the caller just computed, so
/// the collector never re-derives eligibility here -- one judgment, two callers (`§4.81`'s shape).
#[must_use]
pub fn decide_idle_gc(
    checks: u64,
    enabled: bool,
    plan_would_run: bool,
    collect_len: usize,
) -> IdleGcDecision {
    if !enabled {
        return IdleGcDecision::Skip(IdleGcSkip::AutomationOff);
    }
    if !idle_gc_check_is_due(checks) {
        return IdleGcDecision::Skip(IdleGcSkip::NotDue);
    }
    if !plan_would_run {
        return IdleGcDecision::Skip(IdleGcSkip::PlanRefused);
    }
    if collect_len == 0 {
        return IdleGcDecision::Skip(IdleGcSkip::NothingToCollect);
    }
    IdleGcDecision::Enqueue
}

/// The idempotency key an automatic cycle carries, derived from the monotone check number: a fresh value
/// per distinct logical operation is exactly what `ADR-037` asks for.
pub fn idle_gc_idempotency_key(checks: u64) -> String {
    format!("automation-gc-idle-check-{checks}")
}

/// What both outlets say when no cycle has ever run.
///
/// One const, two consumers (`doctor`'s note and the bundle's `storage-gc` section): the sentence is
/// about one fact, and two spellings of it is how one outlet eventually starts sounding reassuring
/// while the other does not.
pub const NO_GC_RUN_YET: &str = "no collection cycle has run in this process";

/// What one collection cycle did (`ADR-038 §2`).
///
/// Stored on the engine state and echoed by `doctor` and the support bundle, because "40 objects
/// reclaimed" and "nothing to do" look identical from the outside otherwise -- and a cycle that
/// refused for safety must be distinguishable from a cycle that found nothing.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct GcRunRecord {
    pub at_generation: u64,
    pub now_unix_ms: i64,
    pub now_source: &'static str,
    pub grace_period_ms: i64,
    pub max_deletions: usize,
    /// Objects actually removed.
    pub collected: Vec<String>,
    /// Objects the store refused to remove, with what it said. Kept per object because a cycle that
    /// silently deleted less than it planned is indistinguishable from one that worked.
    pub failed: Vec<(String, String)>,
    pub retained_total: usize,
    pub skipped_for_grace: usize,
    /// The cycle did not run, and why. `Some` means nothing was deleted.
    pub refused: Option<String>,
    /// [`GC_TRIGGER_CALLER`] or [`GC_TRIGGER_IDLE_AUTOMATION`] (`ADR-038 §13.2`).
    ///
    /// Reported, not merely stored: "the daemon removed 40 objects by itself" and "an operator asked it
    /// to" must not read the same in a bundle. Deliberately absent from the caller-visible view -- the
    /// caller knows who they are, and a second copy of this sentence in a DTO is how two outlets
    /// eventually disagree about one fact.
    pub triggered_by: &'static str,
}

impl GcRunRecord {
    pub fn deleted_count(&self) -> usize {
        self.collected.len()
    }

    pub fn summary_line(&self) -> String {
        match &self.refused {
            Some(refusal) => format!(
                "gc cycle at revision={} refused: {refusal} triggered_by={}",
                self.at_generation, self.triggered_by
            ),
            None => format!(
                "gc cycle at revision={} deleted={} failed={} retained={} skipped_for_grace={} \
                 now={}@{} triggered_by={}",
                self.at_generation,
                self.collected.len(),
                self.failed.len(),
                self.retained_total,
                self.skipped_for_grace,
                self.now_unix_ms,
                self.now_source,
                self.triggered_by,
            ),
        }
    }
}

/// How much work is in flight: queued commands, plus jobs that have not reached a terminal state.
///
/// The count (not just a flag) exists because `OVERLOAD_AND_RETRY_MODEL §7` wants a refusal to carry
/// the numbers it was based on, and because a boolean cannot explain "why is 0 different from 1".
pub fn work_in_flight(state: &EngineState) -> usize {
    work_in_flight_except(state, None)
}

/// The same count, ignoring one job -- which is how a collection cycle avoids refusing itself.
///
/// `RFC-0007 §13.2` wants the collector to run when the engine is idle, and once the collector *is* a
/// job (this round), the job executing the cycle is by definition a non-terminal job. Counting it would
/// make every cycle refuse itself (`docs/ONBOARDING_NOTES.md §4.82`). The exclusion is a parameter
/// rather than a global "skip StorageGc jobs" rule for a reason: at admission the check must still see
/// *another* queued collection cycle, or two of them would each wave the other through.
pub fn work_in_flight_except(state: &EngineState, exclude: Option<caly_api::JobId>) -> usize {
    state.queue.len()
        + state
            .jobs
            .values()
            .filter(|job| {
                Some(job.id) != exclude
                    && matches!(
                        job.state,
                        crate::job::JobState::Accepted
                            | crate::job::JobState::Queued
                            | crate::job::JobState::Running
                            | crate::job::JobState::WaitingInput
                    )
            })
            .count()
}

/// Whether work is in flight: queued commands, or a job that has not reached a terminal state.
///
/// This is `§13.2`'s "idle" half. It is deliberately conservative about the *engine*'s own view --
/// a job waiting for input is not finished -- and it says nothing about other processes, which this
/// control plane does not model.
pub fn has_work_in_flight(state: &EngineState) -> bool {
    work_in_flight(state) > 0
}

#[cfg(test)]
mod tests {
    use super::*;
    use caly_storage::execution::{ApplyJournalRecord, ApplyJournalState, ApplyPhase, ApplyTxnId};
    use caly_storage::journal::JournalRecordId;
    use caly_storage::revision::{RevisionId, RevisionNumber};
    use caly_storage::snapshot::{SnapshotRecord, SnapshotRecordId};
    use caly_storage::{ObjectDigest, ObjectKind};

    // ---- the idle collector's policy (`ADR-038 §13.2`) ------------------------------

    /// Each condition gets its own turn at being false, and each has a distinct reason. A gate that
    /// only says "no" cannot be told apart from a gate that is not running at all -- and the whole
    /// argument for automating a destructive cycle is that a refusal stays explainable.
    #[test]
    fn idle_cadence_is_a_multiple_of_the_interval() {
        for checks in 1..=4 * IDLE_GC_INTERVAL_CHECKS {
            assert_eq!(
                idle_gc_check_is_due(checks),
                checks.is_multiple_of(IDLE_GC_INTERVAL_CHECKS),
                "check {checks} is due exactly when it is a multiple of the interval; a shift here is \
                 how an automatic cycle starts competing with caller work"
            );
        }
        assert!(
            !idle_gc_check_is_due(0),
            "check zero is \"nobody has looked yet\", not \"it is due immediately\""
        );
        assert!(
            idle_gc_check_is_due(IDLE_GC_INTERVAL_CHECKS),
            "the interval itself is due"
        );
    }

    #[test]
    fn every_reason_the_collector_stays_put_is_named() {
        assert_eq!(
            decide_idle_gc(IDLE_GC_INTERVAL_CHECKS, false, true, 4),
            IdleGcDecision::Skip(IdleGcSkip::AutomationOff),
            "disabled wins over everything: nobody authorised this work, so no plan is even read"
        );
        assert_eq!(
            decide_idle_gc(3, true, true, 4),
            IdleGcDecision::Skip(IdleGcSkip::NotDue)
        );
        assert_eq!(
            decide_idle_gc(IDLE_GC_INTERVAL_CHECKS, true, false, 4),
            IdleGcDecision::Skip(IdleGcSkip::PlanRefused),
            "the plan's own refusal outranks a to-do list: it is the only party that read the store"
        );
        assert_eq!(
            decide_idle_gc(IDLE_GC_INTERVAL_CHECKS, true, true, 0),
            IdleGcDecision::Skip(IdleGcSkip::NothingToCollect),
            "and a runnable plan with nothing in it must not earn a job row"
        );
        assert!(decide_idle_gc(IDLE_GC_INTERVAL_CHECKS, true, true, 1).is_enqueue());
        assert_eq!(
            decide_idle_gc(1, false, false, 0).as_str(),
            "automation-off",
            "the reported label has to name the reason that actually fired, in this order"
        );
        // The order is itself a decision, so it gets its own case: with both blocking conditions true,
        // the actionable sentence is the plan's ("the root set is incomplete"), not the count ("nothing
        // to collect") -- an operator reading the latter would clean nothing and be no closer to a run.
        assert_eq!(
            decide_idle_gc(IDLE_GC_INTERVAL_CHECKS, true, false, 0),
            IdleGcDecision::Skip(IdleGcSkip::PlanRefused),
            "the plan's refusal must outrank an empty to-do list, or the reason is chosen for brevity"
        );
    }

    /// The counter is monotone **on purpose**. Resetting it on fire is the shape that silently kills
    /// the collector, because the automatic cycle's idempotency key is derived from it.
    #[test]
    fn the_key_of_each_due_check_is_unique_for_the_whole_process() {
        let mut seen = std::collections::BTreeSet::new();
        let mut checks = 0u64;
        for _ in 0..64 {
            checks += 1;
            if idle_gc_check_is_due(checks) {
                assert!(
                    seen.insert(idle_gc_idempotency_key(checks)),
                    "two due checks would share an idempotency key at check {checks}: the second \
                     cycle would be deduped into the first and the collector would stop deleting"
                );
            }
        }
        assert_eq!(
            seen.len(),
            64 / IDLE_GC_INTERVAL_CHECKS as usize,
            "one key per due check, no more and no fewer"
        );
    }

    /// `caly_api::GcRunView` is the caller-visible twin of this record and, as of this round, has no
    /// producer at all -- which is precisely when a duplicated sentence starts to drift, because nothing
    /// fails. So the two renderings are pinned equal here rather than "sometime" when someone wires the
    /// DTO up (`docs/ONBOARDING_NOTES.md §4.102`).
    #[test]
    fn the_record_line_and_the_dto_line_are_one_sentence() {
        let record = GcRunRecord {
            at_generation: 9,
            now_unix_ms: 100,
            now_source: "storage-clock",
            grace_period_ms: 10,
            max_deletions: 8,
            collected: vec!["sha:a".to_owned()],
            failed: vec![("sha:b".to_owned(), "the store said busy".to_owned())],
            retained_total: 3,
            skipped_for_grace: 1,
            refused: None,
            triggered_by: GC_TRIGGER_IDLE_AUTOMATION,
        };
        let view = caly_api::GcRunView {
            at_generation: record.at_generation,
            now_unix_ms: record.now_unix_ms,
            now_source: record.now_source.to_owned(),
            grace_period_ms: record.grace_period_ms,
            max_deletions: record.max_deletions,
            collected: record.collected.clone(),
            failed: record
                .failed
                .iter()
                .map(|(digest, reason)| caly_api::GcFailureView {
                    digest: digest.clone(),
                    reason: reason.clone(),
                })
                .collect(),
            retained_total: record.retained_total,
            skipped_for_grace: record.skipped_for_grace,
            refused: record.refused.clone(),
            triggered_by: record.triggered_by.to_owned(),
        };
        assert_eq!(view.summary_line(), record.summary_line());

        let refused = GcRunRecord {
            refused: Some("an apply is in flight".to_owned()),
            ..record
        };
        let refused_view = caly_api::GcRunView {
            refused: refused.refused.clone(),
            ..view
        };
        assert_eq!(refused_view.summary_line(), refused.summary_line());
    }

    /// Both outlets print one sentence, so the trigger has to be inside it -- in both branches, since a
    /// refused automatic cycle is exactly the case an operator needs to attribute.
    #[test]
    fn the_label_is_part_of_the_sentence_both_outlets_print() {
        let base = GcRunRecord {
            at_generation: 7,
            now_unix_ms: 100,
            now_source: "storage-clock",
            grace_period_ms: 10,
            max_deletions: 8,
            collected: Vec::new(),
            failed: Vec::new(),
            retained_total: 0,
            skipped_for_grace: 0,
            refused: None,
            triggered_by: GC_TRIGGER_IDLE_AUTOMATION,
        };
        assert!(
            base.summary_line()
                .contains("triggered_by=automation:gc.idle"),
            "{}",
            base.summary_line()
        );
        let refused = GcRunRecord {
            refused: Some("an apply is in flight".to_owned()),
            triggered_by: GC_TRIGGER_CALLER,
            ..base
        };
        assert!(
            refused
                .summary_line()
                .contains("refused: an apply is in flight")
                && refused.summary_line().contains("triggered_by=caller"),
            "{}",
            refused.summary_line()
        );
    }

    fn object(digest: &str, age: Option<i64>) -> CasObjectRef {
        CasObjectRef {
            digest: ObjectDigest(digest.to_owned()),
            kind: ObjectKind::CompiledArtifact,
            size_bytes: Some(8),
            content_type: None,
            content_sha256: None,
            stored_at_unix_ms: age,
        }
    }

    fn snapshot(id: &str, artifact: &str, lkg: bool) -> SnapshotRecord {
        SnapshotRecord {
            id: SnapshotRecordId(id.to_owned()),
            revision_id: RevisionId("rev:01".to_owned()),
            revision_number: RevisionNumber(1),
            profile_id: "demo-profile".to_owned(),
            semantic_digest: format!("sem:{}", id.len()),
            compiled_artifact_digest: artifact.to_owned(),
            core_binary_digest: "bin:1".to_owned(),
            core_identity: "mihomo@0.1".to_owned(),
            apply_plan_summary: "Apply".to_owned(),
            journal_id: None,
            selection_memory_digest: None,
            validation_summary: "ok".to_owned(),
            created_at_unix_ms: 10,
            is_last_known_good: lkg,
        }
    }

    fn revision(id: &str, digest: &str) -> RevisionRecord {
        RevisionRecord {
            id: RevisionId(id.to_owned()),
            number: RevisionNumber(1),
            profile_id: "demo-profile".to_owned(),
            semantic_digest: digest.to_owned(),
            created_at_unix_ms: 1,
        }
    }

    fn journal(txn: &str, artifact: &str) -> ApplyJournalRecord {
        ApplyJournalRecord {
            journal_id: JournalRecordId(format!("journal:{txn}")),
            apply_txn_id: ApplyTxnId(txn.to_owned()),
            trace_id: "t".to_owned(),
            job_id: Some("1".to_owned()),
            profile_id: "demo-profile".to_owned(),
            revision_id: RevisionId("rev:01".to_owned()),
            semantic_digest: "sem:1".to_owned(),
            compiled_artifact_digest: artifact.to_owned(),
            core_identity: "mihomo@0.1".to_owned(),
            effect_plan_id: "plan:1".to_owned(),
            current_phase: ApplyPhase::Cutover,
            current_step_index: 2,
            net_effect_started: true,
            core_cutover_started: true,
            previous_snapshot_id: None,
            created_at_unix_ms: 1,
            updated_at_unix_ms: 2,
            state: ApplyJournalState::Pending,
        }
    }

    fn inputs(objects: Vec<CasObjectRef>) -> GcPlanInputs<'static> {
        GcPlanInputs {
            objects,
            now_unix_ms: 1_000_000,
            // The un-injected case, which is what the assertions about roots should be sitting on.
            now_source: "execution-policy-base",
            grace_period_ms: DEFAULT_GC_GRACE_PERIOD_MS,
            max_deletions: DEFAULT_GC_MAX_DELETIONS,
            idle: true,
            ..GcPlanInputs::default()
        }
    }

    #[test]
    fn bounds_default_clamp_and_refuse() {
        let resolved = GcPlanBounds::default().resolve().expect("defaults resolve");
        assert_eq!(resolved.grace_period_ms, DEFAULT_GC_GRACE_PERIOD_MS);
        assert_eq!(resolved.max_deletions, DEFAULT_GC_MAX_DELETIONS);

        // Legal but large is clamped; out of range is refused. Same split as the paging bounds, for
        // the same reason: a caller asking for more than the default is not breaking a rule.
        let clamped = GcPlanBounds {
            grace_period_ms: Some(DEFAULT_GC_GRACE_PERIOD_MS + 1),
            max_deletions: Some(300),
        }
        .resolve()
        .expect("within the limit");
        assert_eq!(clamped.max_deletions, 300);
        assert!(clamped.grace_period_ms > DEFAULT_GC_GRACE_PERIOD_MS);

        assert_eq!(
            GcPlanBounds {
                grace_period_ms: Some(-1),
                max_deletions: None,
            }
            .resolve()
            .expect_err("a negative grace period would make everything look ancient"),
            GcBoundsRefusal::NegativeGracePeriod(-1)
        );
        assert_eq!(
            GcPlanBounds {
                grace_period_ms: None,
                max_deletions: Some(0),
            }
            .resolve()
            .expect_err("`0` is not a plan, it is a way to ask nothing"),
            GcBoundsRefusal::ZeroMaxDeletions
        );
        assert!(GcPlanBounds {
            grace_period_ms: None,
            max_deletions: Some(MAX_GC_MAX_DELETIONS as u32 + 1),
        }
        .resolve()
        .is_err());
    }

    #[test]
    fn a_complete_root_set_protects_every_class_it_names() {
        let active = snapshot("snap:active", "obj:active", false);
        let lkg = snapshot("snap:lkg", "obj:lkg", true);
        let retained = snapshot("snap:old", "obj:old", false);
        let rev = revision("rev:01", "obj:rev");
        let open = journal("txn:1", "obj:txn");
        let summary = build_gc_plan(&GcPlanInputs {
            // Every age is deliberately past the grace period: an unknown age would protect all of
            // them with `grace-period` and the assertion below would pass without any root working.
            objects: vec![
                object("obj:active", Some(0)),
                object("obj:lkg", Some(0)),
                object("obj:old", Some(0)),
                object("obj:rev", Some(0)),
                object("obj:txn", Some(0)),
                object("obj:job", Some(0)),
                object("obj:free", Some(0)),
            ],
            retained_snapshots: vec![retained],
            revisions: vec![rev],
            unfinished_journals: vec![open],
            running_job_artifacts: vec!["obj:job".to_owned()],
            active_snapshot: Some(&active),
            last_known_good: Some(&lkg),
            ..inputs(vec![])
        });

        assert!(summary.roots_complete());
        assert_eq!(
            summary.collect,
            vec!["obj:free".to_owned()],
            "exactly the object no root names: {summary:?}"
        );
        assert!(
            summary.would_run(),
            "{}",
            summary.refusal().unwrap_or_default()
        );
        // Which root protected which object, stated exactly. This is what makes the wiring testable:
        // dropping any class from the graph shows up here as a missing reason rather than as a plan
        // that merely looks a bit smaller.
        let reasons: Vec<(String, String)> = summary
            .retained_sample
            .iter()
            .map(|entry| (entry.digest.clone(), entry.reasons.join("+")))
            .collect();
        assert_eq!(
            reasons,
            vec![
                ("obj:active".to_owned(), "active-snapshot".to_owned()),
                ("obj:job".to_owned(), "running-job".to_owned()),
                ("obj:lkg".to_owned(), "last-known-good".to_owned()),
                ("obj:old".to_owned(), "last-known-good".to_owned()),
                ("obj:rev".to_owned(), "registered-revision".to_owned()),
                ("obj:txn".to_owned(), "unfinished-journal".to_owned()),
            ],
            "{summary:?}"
        );
        assert_eq!(summary.retained_total, 6);
        assert_eq!(
            summary.skipped_for_grace, 0,
            "no object here is being saved by freshness alone"
        );
    }

    #[test]
    fn a_missing_root_class_empties_the_list_instead_of_licensing_it() {
        let mut base = inputs(vec![object("obj:free", Some(0))]);
        assert!(
            base.idle && base.gaps.is_empty(),
            "the harness starts from a complete root set, so a red below cannot be blamed on it"
        );
        let complete = build_gc_plan(&base);
        assert_eq!(
            complete.collect,
            vec!["obj:free".to_owned()],
            "sanity: with every root readable, an unreferenced old object is collectable"
        );

        base.gaps.push(GcRootGap::new(
            "registered-revisions",
            "the backend cannot enumerate registered revisions",
        ));
        let gapped = build_gc_plan(&base);
        assert!(
            gapped.collect.is_empty(),
            "a partial root set must not produce a deletion list"
        );
        assert!(
            gapped.sweep.is_empty(),
            "and the executable list must be emptied too: report and sweep are cleared by the same line, so neither one is the only thing between a gap and a delete"
        );
        assert!(!gapped.would_run());
        assert!(
            gapped
                .refusal()
                .unwrap_or_default()
                .contains("registered-revisions"),
            "the refusal must name the class the operator has to fix"
        );
        // The store facts it *can* state are still stated: an empty plan is not an empty store.
        assert_eq!(gapped.objects_total, 1);
    }

    #[test]
    fn an_object_dated_after_now_refuses_the_whole_grace_judgement() {
        // A real filesystem's mtime against an injected clock at zero: every object is "in the
        // future", so the grace comparison protects everything and the plan looks reassuringly empty.
        let inputs = GcPlanInputs {
            objects: vec![object("obj:new", Some(5_000))],
            now_unix_ms: 1_000,
            grace_period_ms: 0,
            max_deletions: DEFAULT_GC_MAX_DELETIONS,
            idle: true,
            ..GcPlanInputs::default()
        };
        let summary = build_gc_plan(&inputs);
        let classes: Vec<&str> = summary.gaps.iter().map(|gap| gap.class).collect();
        assert_eq!(classes, vec!["clock-timeline"], "{summary:?}");
        assert!(
            summary.collect.is_empty(),
            "a plan that cannot judge freshness must not list deletions: {summary:?}"
        );
        assert!(!summary.would_run());
        assert!(
            summary
                .refusal()
                .unwrap_or_default()
                .contains("clock-timeline"),
            "the refusal has to name the gap: {summary:?}"
        );
        // The store facts are still stated: a refusal is not an empty store.
        assert_eq!(summary.objects_total, 1);

        // And with both sides on one timeline, the same object is exactly what a cycle should collect.
        let agreed = GcPlanInputs {
            now_unix_ms: 6_000,
            ..inputs_for_age(vec![object("obj:new", Some(5_000))], 0)
        };
        let summary = build_gc_plan(&agreed);
        assert!(summary.gaps.is_empty(), "{summary:?}");
        assert_eq!(summary.collect, vec!["obj:new".to_owned()]);
    }

    fn inputs_for_age(objects: Vec<CasObjectRef>, grace_period_ms: i64) -> GcPlanInputs<'static> {
        GcPlanInputs {
            objects,
            grace_period_ms,
            max_deletions: DEFAULT_GC_MAX_DELETIONS,
            idle: true,
            ..GcPlanInputs::default()
        }
    }

    #[test]
    fn the_now_source_is_reported_and_the_refusal_names_the_fix() {
        let mut mismatch = inputs(vec![object("obj:new", Some(5_000))]);
        mismatch.now_unix_ms = 1_000;
        let refused = build_gc_plan(&mismatch);
        assert_eq!(refused.now_source, "execution-policy-base");
        assert!(
            refused
                .summary_line()
                .contains("now=1000@execution-policy-base"),
            "the line an operator reads must say which clock it used: {}",
            refused.summary_line()
        );
        let detail = refused
            .gaps
            .first()
            .map(|gap| gap.detail.clone())
            .unwrap_or_default();
        assert!(detail.contains("source: execution-policy-base"), "{detail}");
        assert!(
            detail.contains("ADR-038 §3"),
            "a refusal that does not point at the fix is a shrug: {detail}"
        );
        assert!(
            !detail.contains("  "),
            "a run of spaces means a folded literal lost its backslash: {detail}"
        );

        // Same object, same rule -- with the store's own clock injected there is no mismatch to
        // report, and the plan becomes a plan again.
        mismatch.now_unix_ms = 6_000;
        mismatch.now_source = "storage-clock";
        mismatch.grace_period_ms = 0;
        let agreed = build_gc_plan(&mismatch);
        assert!(agreed.gaps.is_empty(), "{agreed:?}");
        assert_eq!(agreed.now_source, "storage-clock");
        assert_eq!(agreed.collect, vec!["obj:new".to_owned()]);
    }

    #[test]
    fn only_damage_is_reported_as_actionable() {
        let mut inputs = inputs(vec![object("obj:free", Some(0))]);
        inputs.gaps.push(GcRootGap::new(
            "registered-revisions",
            "the backend has no such query",
        ));
        let structural = build_gc_plan(&inputs);
        assert!(
            structural.gaps.iter().all(|gap| !gap.actionable),
            "{structural:?}"
        );
        assert!(
            !structural.summary_line().contains("actionable=1"),
            "{}",
            structural.summary_line()
        );

        inputs.gaps.push(GcRootGap::damage(
            "active-snapshot",
            "the runtime names a record the store cannot produce",
        ));
        let damaged = build_gc_plan(&inputs);
        assert!(damaged.gaps.iter().any(|gap| gap.actionable), "{damaged:?}");
        assert!(
            damaged.summary_line().contains("actionable=1"),
            "{}",
            damaged.summary_line()
        );
    }

    #[test]
    fn the_retained_report_is_bounded_and_says_so() {
        let objects: Vec<CasObjectRef> = (0..(GC_PLAN_SAMPLE_LIMIT + 5))
            .map(|index| object(&format!("obj:{index:03}"), None))
            .collect();
        // Every object is protected by an unknown age, so `blocked` would carry one row each.
        let summary = build_gc_plan(&inputs(objects));
        assert_eq!(summary.retained_total, GC_PLAN_SAMPLE_LIMIT + 5);
        assert_eq!(
            summary.retained_sample.len(),
            GC_PLAN_SAMPLE_LIMIT,
            "the sample is a bound, not a suggestion"
        );
        assert!(summary.is_truncated());
        assert!(summary.summary_line().contains("truncated=true"));
    }

    #[test]
    fn deferred_by_capacity_is_not_reported_as_retained_by_a_root() {
        let objects: Vec<CasObjectRef> = (0..6)
            .map(|index| object(&format!("obj:{index}"), Some(0)))
            .collect();
        let summary = build_gc_plan(&GcPlanInputs {
            max_deletions: 2,
            ..inputs(objects)
        });
        assert_eq!(summary.collect.len(), 2, "the cycle bound holds");
        assert_eq!(
            summary.deferred_over_cap, 4,
            "the rest are deferred, and they must be counted as such: {summary:?}"
        );
        assert_eq!(summary.retained_total, 0, "nothing was protected by a root");
    }

    #[test]
    fn eligibility_comes_from_the_engines_own_state() {
        let mut state = EngineState::new();
        assert!(!has_work_in_flight(&state), "a fresh engine is idle");

        state.enqueue(
            caly_api::JobId(1),
            crate::command::Command {
                id: crate::command::CommandId("cmd-1".to_owned()),
                request_id: None,
                actor: caly_common::Actor::Cli,
                context: caly_common::RequestContext::new(
                    caly_common::TraceId::new("gc"),
                    caly_common::Actor::Cli,
                ),
                timeout_ms: None,
                idempotency_key: None,
                kind: crate::command::CommandKind::DiagnosticsBundle,
            },
        );
        assert!(
            has_work_in_flight(&state),
            "a queued command is work: its effect plan may name objects nobody has written down yet"
        );
    }
}
