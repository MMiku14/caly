use std::sync::{Arc, Mutex};

use caly_api::{Accepted, JobFollowView, JobId, PatchAutomationJob};
use caly_storage::{
    ApplyStorageProjection, InMemoryStorage, RecoveryScanReport, SnapshotRecord, StorageBackend,
};

use crate::command::{Command, IdempotencyKey};
use crate::event::{Event, EventSeq, ReplayWindow};
use crate::executor::{EffectRuntime, ExecutionPolicy};
use crate::idempotency::IdempotencyStatus;
use crate::job::{JobEvent, JobOutcome, JobRecord, JobState};
use crate::job_follow::{slice_job_events, JobEventRetentionPolicy, JobEventWindow};
use crate::overload::OverloadReport;
use crate::processor::{
    mark_finished, mark_running, poll_next_command, submit_command, ProcessedCommand,
    SubmitRejected,
};
use crate::recovery::{
    advance_apply_phase, begin_apply_persistence, finalize_apply_persistence,
    mark_apply_recovery_failed, mark_apply_reverted, run_ready, run_ready_in, scan_recovery_state,
    FinalizedApplyExecution, PersistedApplyExecution,
};
use crate::sim_runtime::SimulatedRuntime;
use crate::source_worker::{SourceUpdateWorker, UnconfiguredSourceUpdateWorker};
use crate::state::{EngineLifecycle, EngineState, QueuedCommand};
use crate::worker::{drain_with_policy, WorkerDrainReport, WorkerPolicy};

#[derive(Clone)]
pub struct EngineHandle {
    inner: Arc<Mutex<EngineState>>,
    storage: Arc<dyn StorageBackend>,
    /// The effect backend the apply executor drives. Concrete no more (round 55): the seam
    /// `ROADMAP §13` called "真 effect 后端" begins here — the engine defaults to the
    /// deterministic [`SimulatedRuntime`] (`ADR-022`) and the composition root may inject any
    /// [`EffectRuntime`], which is how the daemon runs real cores through the same executor.
    effects: Arc<dyn EffectRuntime>,
    /// The source update worker is injected at the composition root. Keeping the default explicit
    /// refusal prevents a queued `SourceUpdate` from becoming a fake success when no locator,
    /// HTTP port, or CAS backend is wired (`ADR-029`, `ADR-049`).
    source_updater: Arc<Mutex<Arc<dyn SourceUpdateWorker>>>,
    execution_policy: Arc<Mutex<ExecutionPolicy>>,
    /// The clock whose readings may be compared with the store's own file dates. `None` means
    /// "nothing was injected", and then the GC plan falls back to the execution-policy base and
    /// reports which it used (`ADR-038 §3`, `docs/history/ONBOARDING_NOTES.md §4.74`).
    storage_clock: Arc<Mutex<Option<Arc<dyn caly_io::Clock>>>>,
}

impl Default for EngineHandle {
    fn default() -> Self {
        Self::new(EngineState::new())
    }
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub enum SubmitFailure {
    Overload(OverloadReport),
    /// The caller's `expected_revision` CAS precondition (`RFC-0002 §6.2`) does not hold.
    ///
    /// Carried as data rather than a message so the boundary can map it to the right error code
    /// instead of pattern-matching on a string.
    StaleRevision {
        expected: u64,
        current: u64,
    },
    Internal(String),
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct SubmitResult {
    pub accepted: Accepted,
    pub reused_existing_job: bool,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct EventWindow {
    pub from_exclusive: Option<EventSeq>,
    pub next_seq: u64,
    pub retained_from: EventSeq,
    pub reset_required: bool,
    pub events: Vec<Event>,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct JobFollow {
    pub job: Option<JobRecord>,
    pub lifecycle: EngineLifecycle,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct JobFollowProjection {
    pub summary: JobFollowView,
    pub window: Option<JobEventWindow>,
}

impl EngineHandle {
    /// The context engine-originated store work carries (`ADR-039 §2.4`): the engine's own
    /// label, never a borrowed caller's. Façade threading (the ADR's step 4) replaces this at
    /// the seams where a real caller context exists; until then attribution says "the engine
    /// did this", which is the truth.
    pub fn store_ctx() -> caly_io::IoContext {
        caly_io::RequestContext::new(
            caly_io::TraceId::new("engine-storage"),
            caly_io::Actor::System,
        )
    }

    pub fn new(state: EngineState) -> Self {
        Self::with_storage(state, InMemoryStorage::new())
    }

    /// Build a handle over an arbitrary backend.
    ///
    /// This is the seam `docs/history/ONBOARDING_NOTES.md §3.4` asked for: the engine used to hold a
    /// concrete `InMemoryStorage`, which made the five store traits decorative. Tests and the
    /// daemon can now inject any `StorageBackend` (see `tests/storage_backend_swap.rs`).
    pub fn with_backend(state: EngineState, storage: Arc<dyn StorageBackend>) -> Self {
        Self::with_effect_runtime(state, storage, Arc::new(SimulatedRuntime::new()))
    }

    /// Build a handle over an arbitrary backend **and** an arbitrary effect runtime — the
    /// composition root's injection point (`ROADMAP §13`'s "真 effect 后端"). Everything the
    /// executor does with the world goes through this trait, so a daemon that hands in a real
    /// runtime gets real cores, real probes and real stops from the *same* plan the simulator
    /// validated (`ADR-022`'s dual requirement, closed at the seam rather than forked paths).
    pub fn with_effect_runtime(
        state: EngineState,
        storage: Arc<dyn StorageBackend>,
        effects: Arc<dyn EffectRuntime>,
    ) -> Self {
        Self {
            inner: Arc::new(Mutex::new(state)),
            storage,
            effects,
            source_updater: Arc::new(Mutex::new(Arc::new(UnconfiguredSourceUpdateWorker))),
            execution_policy: Arc::new(Mutex::new(ExecutionPolicy::default())),
            storage_clock: Arc::new(Mutex::new(None)),
        }
    }

    /// A copy of this handle whose effect runtime is `effects` — the daemon's setter seam, so
    /// `DaemonApp` can swap backends without re-bootstrapping the whole engine.
    pub fn clone_with_effect_runtime(&self, effects: Arc<dyn EffectRuntime>) -> Self {
        Self {
            inner: Arc::clone(&self.inner),
            storage: Arc::clone(&self.storage),
            effects,
            source_updater: Arc::clone(&self.source_updater),
            execution_policy: Arc::clone(&self.execution_policy),
            storage_clock: Arc::clone(&self.storage_clock),
        }
    }

    /// Convenience for the default in-memory backend.
    pub fn with_storage(state: EngineState, storage: InMemoryStorage) -> Self {
        Self::with_backend(state, Arc::new(storage))
    }

    /// The effect runtime the apply executor runs against.
    ///
    /// Defaults to the deterministic [`SimulatedRuntime`]; `ADR-022` requires that the
    /// deployment path be drivable and assertable without touching a real OS. Round 55 made
    /// the return type the trait: callers that need the simulator's world keep their own
    /// `Arc<SimulatedRuntime>` from construction instead of reaching back for it here.
    pub fn effect_runtime(&self) -> Arc<dyn EffectRuntime> {
        Arc::clone(&self.effects)
    }

    /// Replace the source worker at the composition root. The default is intentionally not a
    /// successful no-op: a source command without an explicit locator/HTTP/CAS path must fail
    /// rather than claim that the subscription was updated.
    pub fn set_source_update_worker(
        &self,
        worker: Arc<dyn SourceUpdateWorker>,
    ) -> Result<(), String> {
        let restored = worker.restored_sources()?;
        {
            let mut state = self
                .inner
                .lock()
                .map_err(|_| "engine state lock poisoned".to_owned())?;
            for source in restored {
                state.source_cache.insert(source.id.0.clone(), source);
            }
        }
        let mut guard = self
            .source_updater
            .lock()
            .map_err(|_| "source update worker lock poisoned".to_owned())?;
        *guard = worker;
        Ok(())
    }

    pub fn source_update(
        &self,
        source_id: &str,
        ctx: &caly_common::RequestContext,
    ) -> Result<crate::source_worker::SourceUpdateReport, String> {
        let worker = self
            .source_updater
            .lock()
            .map_err(|_| "source update worker lock poisoned".to_owned())?
            .clone();
        worker.update(source_id, ctx)
    }

    /// Read the source worker's durable inspection projection. The worker owns the verification
    /// because only it knows how to decode its typed provenance/diagnostics envelope; the engine
    /// merely keeps the façade-independent seam available to the daemon.
    pub fn source_inspection(
        &self,
        source_id: &str,
        ctx: &caly_common::RequestContext,
    ) -> Result<Option<crate::source_worker::SourceInspectionReport>, String> {
        let worker = self
            .source_updater
            .lock()
            .map_err(|_| "source update worker lock poisoned".to_owned())?
            .clone();
        worker.inspect(source_id, ctx)
    }

    /// Enumerate the source endpoint registry (round 114). This is the same registry that
    /// durable restoration and `--source-endpoint` registration populate, so the daemon's
    /// `sources.list`/`sources.inspect` surface can show a registered locator before any fetch
    /// and keep showing indexed entries after a restart.
    pub fn list_source_endpoints(
        &self,
    ) -> Result<Vec<crate::source_worker::SourceEndpoint>, String> {
        let worker = self
            .source_updater
            .lock()
            .map_err(|_| "source update worker lock poisoned".to_owned())?
            .clone();
        worker.list_endpoints()
    }

    /// Register a locator through the injected worker without exposing a concrete worker type to
    /// the daemon. Workers that do not own an endpoint registry refuse explicitly.
    pub fn register_source_endpoint(
        &self,
        endpoint: crate::source_worker::SourceEndpoint,
    ) -> Result<(), String> {
        let worker = self
            .source_updater
            .lock()
            .map_err(|_| "source update worker lock poisoned".to_owned())?
            .clone();
        worker.register_endpoint(endpoint)
    }

    /// Record only a source update that has already passed fetch, normalization, and CAS. The
    /// source worker publishes the durable source index before calling this process-local mirror;
    /// installing a durable worker also restores that mirror before apply planning can consume it.
    pub fn record_source_update(
        &self,
        report: &crate::source_worker::SourceUpdateReport,
    ) -> Result<(), String> {
        let mut guard = self
            .inner
            .lock()
            .map_err(|_| "engine state lock poisoned".to_owned())?;
        guard
            .source_cache
            .insert(report.source_id.0.clone(), report.normalized.clone());
        Ok(())
    }

    pub fn normalized_source_cache(&self) -> Result<Vec<caly_ir::NormalizedSource>, String> {
        let guard = self
            .inner
            .lock()
            .map_err(|_| "engine state lock poisoned".to_owned())?;
        Ok(guard.source_cache.values().cloned().collect())
    }

    pub fn cached_source(
        &self,
        source_id: &str,
    ) -> Result<Option<caly_ir::NormalizedSource>, String> {
        let guard = self
            .inner
            .lock()
            .map_err(|_| "engine state lock poisoned".to_owned())?;
        Ok(guard.source_cache.get(source_id).cloned())
    }

    pub fn execution_policy(&self) -> ExecutionPolicy {
        self.execution_policy
            .lock()
            .map(|guard| guard.clone())
            .unwrap_or_default()
    }

    /// Override the execution policy, e.g. to inject a crash after effect step N.
    /// Inject the clock that a *file date* is comparable with (`ADR-038 §3`).
    ///
    /// Two `now`s exist in this engine on purpose. Journal cursors are derived from
    /// `ExecutionPolicy::clock_start_unix_ms` because the release gate has to replay a run
    /// byte-for-byte (`ADR-022`), while object ages may come from the port's own file dates
    /// (`ADR-035 §2.4`). Comparing the second pair across the two timelines is precisely
    /// `docs/history/ONBOARDING_NOTES.md §4.74`; a deployment reading dates off a real filesystem injects
    /// `StdClock` here, a simulation injects the `SimClock` its `SimFs` already uses, and anything
    /// that injects nothing keeps the policy base and gets a refused plan rather than a guessed one.
    ///
    /// No production composition root calls this yet, because there is none: the daemon has no
    /// `[[bin]]` (`docs/status/IMPLEMENTATION_STATUS.md` 未覆盖). What exists is the seam, the refusal, and
    /// tests for both -- stated rather than papered over.
    pub fn set_storage_clock(&self, clock: Option<Arc<dyn caly_io::Clock>>) -> Result<(), String> {
        let mut guard = self
            .storage_clock
            .lock()
            .map_err(|_| "storage clock slot lock poisoned".to_owned())?;
        *guard = clock;
        Ok(())
    }

    /// The instant to compare stored file dates against, and where it came from.
    ///
    /// The source is returned with the value because "which clock is this?" is the difference between
    /// a usable plan and a nonsense one; a report that hides it would make `now=0` look like a fact
    /// about the world.
    pub fn storage_now(&self) -> (i64, &'static str) {
        let injected = self
            .storage_clock
            .lock()
            .ok()
            .and_then(|guard| guard.clone())
            .map(|clock| clock.now().unix_millis);
        match injected {
            Some(at) => (at, "storage-clock"),
            None => (
                self.execution_policy().clock_start_unix_ms.max(0),
                "execution-policy-base",
            ),
        }
    }

    pub fn set_execution_policy(&self, policy: ExecutionPolicy) -> Result<(), String> {
        let mut guard = self
            .execution_policy
            .lock()
            .map_err(|_| "execution policy lock poisoned".to_owned())?;
        *guard = policy;
        Ok(())
    }

    /// The clock whose readings may be compared with the store's own file dates, if any was
    /// injected. Reported as an `Option` rather than defaulted, because the absence *is* the answer
    /// the caller needs: no clock means no deadline may be judged here (`ADR-036 §6bis`, `§4.86`).
    pub fn storage_clock(&self) -> Option<Arc<dyn caly_io::Clock>> {
        self.storage_clock
            .lock()
            .ok()
            .and_then(|guard| guard.clone())
    }

    /// Persist an arbitrary apply journal record (used by the executor's journal fold).
    pub fn put_apply_journal(
        &self,
        record: caly_storage::ApplyJournalRecord,
    ) -> Result<(), String> {
        run_ready(self.storage.put_apply_journal(record, &Self::store_ctx()))?
            .map_err(|error| error.summary)
    }

    /// Remember which effect plan produced the current deployment, for rollback.
    pub fn record_effect_plan(&self, plan: Option<caly_plan::EffectPlan>) -> Result<(), String> {
        let mut guard = self
            .inner
            .lock()
            .map_err(|_| "engine state lock poisoned".to_owned())?;
        guard.last_effect_plan = plan;
        Ok(())
    }

    pub fn last_effect_plan(&self) -> Result<Option<caly_plan::EffectPlan>, String> {
        let guard = self
            .inner
            .lock()
            .map_err(|_| "engine state lock poisoned".to_owned())?;
        Ok(guard.last_effect_plan.clone())
    }

    /// Remember the artifact of the deployment that just committed (round 56). The next
    /// apply is planned against this — a second apply stops being a first install.
    pub fn record_compiled_artifact(
        &self,
        artifact: Option<caly_ir::CompiledArtifact>,
    ) -> Result<(), String> {
        let mut guard = self
            .inner
            .lock()
            .map_err(|_| "engine state lock poisoned".to_owned())?;
        guard.last_compiled_artifact = artifact;
        Ok(())
    }

    pub fn last_compiled_artifact(&self) -> Result<Option<caly_ir::CompiledArtifact>, String> {
        let guard = self
            .inner
            .lock()
            .map_err(|_| "engine state lock poisoned".to_owned())?;
        Ok(guard.last_compiled_artifact.clone())
    }

    pub fn storage(&self) -> Arc<dyn StorageBackend> {
        Arc::clone(&self.storage)
    }

    /// Store one object (CAS write: content first, then verification, then the index).
    ///
    /// Exposed for the one writer that is not part of an apply — the support bundle
    /// (`crate::bundle`) — which is a payload the engine itself produced.
    pub fn put_object(
        &self,
        intent: caly_storage::CasWriteIntent,
    ) -> Result<caly_storage::CasObjectRef, String> {
        run_ready(self.storage.put(intent, &Self::store_ctx()))?.map_err(|error| error.summary)
    }

    /// The newest bundle the store still holds, newest first by `(stored_at, digest)`.
    ///
    /// The tie-break on `digest` matters: several bundles written on one injected clock instant are
    /// otherwise ordered arbitrarily, and an arbitrarily-chosen "latest" is a bug that only shows up
    /// as a different answer next run.
    pub fn latest_support_bundle_digest(
        &self,
        ctx: &caly_io::IoContext,
    ) -> Result<Option<String>, String> {
        let mut candidates: Vec<(i64, String)> = run_ready(self.storage.list_objects(ctx))?
            .map_err(|error| error.summary)?
            .into_iter()
            .filter(|object| object.kind == caly_storage::ObjectKind::SupportBundle)
            .map(|object| {
                (
                    object.stored_at_unix_ms.unwrap_or(i64::MIN),
                    object.digest.0,
                )
            })
            .collect();
        candidates.sort_by(|left, right| right.0.cmp(&left.0).then_with(|| right.1.cmp(&left.1)));
        Ok(candidates.into_iter().next().map(|(_, digest)| digest))
    }

    /// The bytes behind a digest, verified by the store against its own anchor before they are
    /// handed back. `None` means the store has no such digest.
    ///
    /// This exists because the store interface could previously only `put`, look at metadata, and
    /// `materialize` a file for a core to read. An export meant for a *person* had no way out
    /// (`docs/history/ONBOARDING_NOTES.md §4.45`).
    pub fn object_payload(
        &self,
        digest: &str,
        max_bytes: u64,
        ctx: &caly_io::IoContext,
    ) -> Result<Option<Vec<u8>>, String> {
        run_ready(self.storage.read_object(digest, max_bytes, ctx))?.map_err(|error| error.summary)
    }

    /// Whether the store can hand out content at all, so a caller can tell `Unsupported` from
    /// "the object is absent". Reported rather than assumed.
    pub fn object_metadata(
        &self,
        digest: &str,
        ctx: &caly_io::IoContext,
    ) -> Result<Option<caly_storage::CasObjectRef>, String> {
        run_ready(self.storage.get(digest, ctx))?.map_err(|error| error.summary)
    }

    /// The redactor every operator-visible string in this engine passes through.
    pub fn redactor(&self) -> Result<caly_common::redact::Redactor, String> {
        let guard = self
            .inner
            .lock()
            .map_err(|_| "engine state lock poisoned".to_owned())?;
        Ok(guard.redactor.clone())
    }

    /// Replace the redactor — e.g. a daemon configured for `RFC-0010 §12.1` strict convergence.
    pub fn set_redactor(&self, redactor: caly_common::redact::Redactor) -> Result<(), String> {
        let mut guard = self
            .inner
            .lock()
            .map_err(|_| "engine state lock poisoned".to_owned())?;
        guard.redactor = redactor;
        Ok(())
    }

    /// Tell the engine that `value` is secret material, so it is masked wherever it appears.
    ///
    /// `RFC-0010 §3.3` puts this duty on whoever holds the secret at construction time: a
    /// subscription token in a bare path has no textual signal for a pattern rule to find.
    pub fn register_secret(&self, value: &str) -> Result<(), String> {
        let mut guard = self
            .inner
            .lock()
            .map_err(|_| "engine state lock poisoned".to_owned())?;
        guard.redactor.register_secret(value);
        Ok(())
    }

    /// The redactor an *export* must use: the process rules, escalated to the bundle's policy.
    pub fn bundle_redactor(&self) -> Result<caly_common::redact::Redactor, String> {
        Ok(self.redactor()?.escalate_to(crate::bundle::BUNDLE_POLICY))
    }

    pub fn bundle_identity(&self) -> Result<crate::bundle::BundleIdentity, String> {
        let guard = self
            .inner
            .lock()
            .map_err(|_| "engine state lock poisoned".to_owned())?;
        Ok(guard.bundle_identity.clone())
    }

    /// Which process this engine belongs to, for the support bundle header.
    pub fn set_bundle_identity(
        &self,
        identity: crate::bundle::BundleIdentity,
    ) -> Result<(), String> {
        let mut guard = self
            .inner
            .lock()
            .map_err(|_| "engine state lock poisoned".to_owned())?;
        guard.bundle_identity = identity;
        Ok(())
    }

    /// Keep the capability verdict of the plan being applied, for the support bundle.
    pub fn record_capability_summary(
        &self,
        summary: crate::apply::CapabilitySummary,
    ) -> Result<(), String> {
        let mut guard = self
            .inner
            .lock()
            .map_err(|_| "engine state lock poisoned".to_owned())?;
        guard.last_capability_summary = Some(summary);
        Ok(())
    }

    pub fn last_capability_summary(
        &self,
    ) -> Result<Option<crate::apply::CapabilitySummary>, String> {
        let guard = self
            .inner
            .lock()
            .map_err(|_| "engine state lock poisoned".to_owned())?;
        Ok(guard.last_capability_summary.clone())
    }

    pub fn snapshot(&self) -> Result<EngineState, String> {
        self.inner
            .lock()
            .map(|guard| guard.clone())
            .map_err(|_| "engine state lock poisoned".to_owned())
    }

    pub fn submit(&self, command: Command) -> Result<SubmitResult, String> {
        self.submit_checked(command)
            .map_err(|failure| match failure {
                SubmitFailure::Overload(report) => report.summary,
                SubmitFailure::StaleRevision { expected, current } => {
                    format!("expected revision {expected} is stale; the engine is at {current}")
                }
                SubmitFailure::Internal(message) => message,
            })
    }

    pub fn submit_checked(&self, command: Command) -> Result<SubmitResult, SubmitFailure> {
        let mut guard = self
            .inner
            .lock()
            .map_err(|_| SubmitFailure::Internal("engine state lock poisoned".to_owned()))?;

        if let Some(key) = &command.idempotency_key {
            if let Some(existing) = guard.idempotency.get(command.actor, key) {
                // A replay answers with the original response, byte for byte: rebuilding one here
                // handed back the *current* generation with a `ReadOnly` impact, so the same request
                // got a different answer the second time (`RFC-0002 §8.3` says it must not).
                return Ok(SubmitResult {
                    accepted: existing.accepted.clone(),
                    reused_existing_job: true,
                });
            }
        }

        // `RFC-0002 §6.2`: `expected_revision` is a compare-and-swap precondition. The value used to
        // be plumbed all the way from `Ctx` into `Command.context` and then read by nobody, so a
        // caller that asked "only run this if the state is still at revision N" got exactly the
        // answer it would have got without asking. It is checked *after* the replay lookup above on
        // purpose: a duplicate of an already accepted command must return the original job rather
        // than fail, or a retry after a dropped response becomes an error.
        if let Some(expected) = command.context.expected_revision {
            if expected != guard.generation {
                return Err(SubmitFailure::StaleRevision {
                    expected,
                    current: guard.generation,
                });
            }
        }

        let processed: ProcessedCommand = submit_command(&mut guard, command.clone()).map_err(
            |SubmitRejected { reason, overload }| match overload {
                Some(overload) => SubmitFailure::Overload(overload),
                None => SubmitFailure::Internal(reason),
            },
        )?;

        if let Some(key) = &command.idempotency_key {
            guard.idempotency.put_running(
                command.actor,
                key,
                command.id.clone(),
                &processed.accepted,
            );
        }

        Ok(SubmitResult {
            accepted: processed.accepted,
            reused_existing_job: false,
        })
    }

    pub fn poll_next(&self) -> Result<Option<QueuedCommand>, String> {
        let mut guard = self
            .inner
            .lock()
            .map_err(|_| "engine state lock poisoned".to_owned())?;
        Ok(poll_next_command(&mut guard))
    }

    pub fn mark_running(&self, queued: &QueuedCommand) -> Result<(), String> {
        let mut guard = self
            .inner
            .lock()
            .map_err(|_| "engine state lock poisoned".to_owned())?;
        mark_running(&mut guard, queued);
        Ok(())
    }

    pub fn mark_finished(&self, queued: &QueuedCommand, outcome: JobOutcome) -> Result<(), String> {
        let mut guard = self
            .inner
            .lock()
            .map_err(|_| "engine state lock poisoned".to_owned())?;

        let impact = if let Some(job) = guard.jobs.get(&queued.job_id.0) {
            if matches!(
                job.state,
                JobState::Running | JobState::Queued | JobState::Accepted
            ) {
                caly_api::EstimatedImpact::Restart
            } else {
                caly_api::EstimatedImpact::ReadOnly
            }
        } else {
            caly_api::EstimatedImpact::ReadOnly
        };

        mark_finished(&mut guard, queued, outcome, impact);

        if let Some(key) = &queued.command.idempotency_key {
            guard
                .idempotency
                .mark_finished(queued.command.actor, key, outcome);
        }

        // Terminal commit point for the durable job log (`ADR-057` §5 slice 2): the job has just
        // reached a terminal state, so snapshot its retained event window into the D3 store. The
        // in-memory state stays the hot path; this write is what makes `jobs.list`/`jobs.events`
        // answer after a restart. A persistence failure must not be swallowed — a terminal job the
        // operator cannot recover after a crash is exactly the gap the record exists to close.
        if let Some(job) = guard.jobs.get(&queued.job_id.0).cloned() {
            // The commit timestamp comes from the storage-injected clock if one was installed,
            // else the execution-policy base — the same `storage_now()` source apply persistence
            // uses. It only reads a separate mutex, so it is safe while the state lock is held.
            let (now, _source) = self.storage_now();
            let record = crate::job_persistence::record_from_job(&job, now)?;
            run_ready(self.storage.put_job_log(record, &Self::store_ctx()))?
                .map_err(|error| error.summary)?;
            // Bounded retention (`ADR-057` §4): the newest JOB_LOG_RETENTION terminal jobs stay
            // (the most recent last-apply job is therefore never aged out first); older records
            // are reclaimed. Reclaiming a job log never touches a committed snapshot/revision.
            self.prune_job_logs_locked()?;
        }

        Ok(())
    }

    /// Load every durable terminal job record back into engine state, newest set first so lower
    /// ids are inserted first and the in-memory `BTreeMap` order matches the on-disk order.
    ///
    /// Run at startup before the daemon serves traffic (`ADR-057` §5 slice 2), mirroring how the
    /// source worker restores its durable index. A record that does not decode back into a typed
    /// job is a start-up error, the same rule the snapshot/apply scan follows: a job history the
    /// engine cannot honestly reconstruct must not be answered with an empty list.
    pub fn restore_job_logs(&self) -> Result<usize, String> {
        let records = run_ready(self.storage.list_job_logs(&Self::store_ctx()))?
            .map_err(|error| error.summary)?;
        let mut jobs = Vec::with_capacity(records.len());
        for record in &records {
            jobs.push(crate::job_persistence::job_from_record(record)?);
        }
        let mut guard = self
            .inner
            .lock()
            .map_err(|_| "engine state lock poisoned".to_owned())?;
        let mut restored = 0usize;
        // `list_job_logs` is newest-first; insert oldest first so a fresh `next_job_id` is seeded
        // past the highest restored id and a future job never collides with a durable id.
        for job in jobs.into_iter().rev() {
            guard.next_job_id = guard.next_job_id.max(job.id.0.saturating_add(1));
            guard.jobs.insert(job.id.0, job);
            restored += 1;
        }
        Ok(restored)
    }

    /// Reclaim terminal job logs past the retention window (`ADR-057` §4).
    ///
    /// Called right after a terminal write so the on-disk job-log set stays bounded without a
    /// separate GC pass. `list_job_logs` is newest-first, so everything past `JOB_LOG_RETENTION`
    /// is older history: delete those. The newest records — including the just-written terminal
    /// job and therefore the most recent last-apply job — are always kept, which is the bounded
    /// form of "a job the retained set still names must not be reclaimed". Reclamation removes
    /// job-log records only; it never deletes a snapshot or revision.
    fn prune_job_logs_locked(&self) -> Result<(), String> {
        use crate::job_persistence::JOB_LOG_RETENTION;
        let records = run_ready(self.storage.list_job_logs(&Self::store_ctx()))?
            .map_err(|error| error.summary)?;
        if records.len() <= JOB_LOG_RETENTION {
            return Ok(());
        }
        for stale in &records[JOB_LOG_RETENTION..] {
            run_ready(
                self.storage
                    .delete_job_log(&stale.job_id, &Self::store_ctx()),
            )?
            .map_err(|error| error.summary)?;
        }
        Ok(())
    }

    pub fn append_job_event(&self, job_id: JobId, event: JobEvent) -> Result<(), String> {
        let mut guard = self
            .inner
            .lock()
            .map_err(|_| "engine state lock poisoned".to_owned())?;
        // `RFC-0010 §6.1` lists "when a log line is constructed" as a redaction boundary, and this
        // is the one place every job line passes: follow, stream and support bundle all read these
        // events, so masking here means no reader has to remember to mask. Redaction is idempotent,
        // so an already-clean line costs a comparison and nothing else.
        let event = redact_job_event(&guard.redactor, event);
        let job = guard
            .jobs
            .get_mut(&job_id.0)
            .ok_or_else(|| format!("unknown job id: {}", job_id.0))?;
        job.events.push(event);
        Ok(())
    }

    pub fn push_event(
        &self,
        kind: crate::event::EventKind,
        command_id: Option<String>,
        payload: crate::event::EventPayload,
    ) -> Result<Event, String> {
        let mut guard = self
            .inner
            .lock()
            .map_err(|_| "engine state lock poisoned".to_owned())?;
        Ok(guard.events.push(kind, command_id, payload))
    }

    /// Phase A of an apply: the one persistence step that happens *before* anything in the running
    /// system changes, so it is the one the engine drives under the caller's limits
    /// (`ADR-036 §2.3`, `crate::run_limits`). A refusal here means the store was never asked.
    pub fn begin_apply_persistence(
        &self,
        projection: ApplyStorageProjection,
        limits: &crate::run_limits::RunLimits,
    ) -> Result<PersistedApplyExecution, crate::run_limits::StoreRefusal> {
        match run_ready_in(
            begin_apply_persistence(self.storage.as_ref(), projection, &Self::store_ctx()),
            limits,
        ) {
            Ok(Ok(value)) => Ok(value),
            // The store did answer, and its answer was an error: that goes out as `Backend`, with no
            // limits line, because blaming the caller's deadline for it would be a fabricated reason.
            Ok(Err(error)) => Err(crate::run_limits::StoreRefusal::from_storage_error(&error)),
            Err(refusal) => Err(refusal),
        }
    }

    /// Record pressure the engine saw *while a job was executing* (`OVERLOAD_AND_RETRY_MODEL §7.2`).
    ///
    /// The public `ApiError` is transient -- the caller retries and forgets -- so the durable half of
    /// a refusal has to be written down somewhere an operator reads. This is that place, and it is
    /// deliberately narrow: only a refusal the *store* called busy counts as system pressure. A
    /// caller-side or budget refusal is reported as what it is and never inflates the tally, because
    /// `§3.7` says so and because a tally that rises for someone else's small budget is a tally
    /// nobody can act on.
    ///
    /// `at_generation` is read here, under the same lock as the record: a generation the caller
    /// grabbed a moment ago is a claim about a state that has already moved.
    pub fn record_storage_contention(
        &self,
        kind: crate::run_limits::RefusalKind,
        what: impl Into<String>,
        retryable: bool,
    ) -> Result<Option<crate::overload::OverloadReport>, String> {
        if kind != crate::run_limits::RefusalKind::StorageBusy {
            return Ok(None);
        }
        let mut guard = self
            .inner
            .lock()
            .map_err(|_| "engine state lock poisoned".to_owned())?;
        let report = crate::overload::OverloadReport::journal_pressure(
            what.into(),
            guard.generation,
            retryable,
        );
        guard.record_overload(report.clone());
        Ok(Some(report))
    }

    /// Move the journal cursor -- but refuse the write only when it records nothing new.
    ///
    /// `run_ready` (unbounded) is used on purpose whenever `advance_records_touched_world` says this
    /// advance is the first write that marks "the world may already have changed": a caller's expired
    /// deadline must not be able to erase the evidence a recovery scanner reads, because the
    /// consequences of that land on the *next* process, not on this caller.
    pub fn advance_apply_phase(
        &self,
        journal: &caly_storage::ApplyJournalRecord,
        phase: caly_storage::ApplyPhase,
        step_index: usize,
        updated_at_unix_ms: i64,
        limits: &crate::run_limits::RunLimits,
    ) -> Result<caly_storage::ApplyJournalRecord, crate::run_limits::StoreRefusal> {
        let immediate = crate::run_limits::RunLimits::immediate();
        let obeys = if crate::recovery::advance_records_touched_world(journal, phase) {
            &immediate
        } else {
            limits
        };
        match run_ready_in(
            advance_apply_phase(
                self.storage.as_ref(),
                journal,
                phase,
                step_index,
                updated_at_unix_ms,
                &Self::store_ctx(),
            ),
            obeys,
        ) {
            Ok(Ok(value)) => Ok(value),
            Ok(Err(error)) => Err(crate::run_limits::StoreRefusal::from_storage_error(&error)),
            Err(refusal) => Err(refusal),
        }
    }

    pub fn finalize_apply_persistence(
        &self,
        journal: &caly_storage::ApplyJournalRecord,
        snapshot_candidate: &caly_storage::SnapshotCandidate,
        created_at_unix_ms: i64,
    ) -> Result<FinalizedApplyExecution, String> {
        let finalized = run_ready(finalize_apply_persistence(
            self.storage.as_ref(),
            journal,
            snapshot_candidate,
            created_at_unix_ms,
            &Self::store_ctx(),
        ))?
        .map_err(|error| error.summary)?;
        // The commit that produces a snapshot is the moment it becomes active; recording it here is
        // what lets the collector treat it as a root without a caller having to remember to say so.
        let mut guard = self
            .inner
            .lock()
            .map_err(|_| "engine state lock poisoned".to_owned())?;
        guard.active_snapshot_id = Some(finalized.snapshot_id.clone());
        Ok(finalized)
    }

    pub fn mark_apply_reverted(
        &self,
        journal: &caly_storage::ApplyJournalRecord,
        updated_at_unix_ms: i64,
    ) -> Result<caly_storage::ApplyJournalRecord, String> {
        run_ready(mark_apply_reverted(
            self.storage.as_ref(),
            journal,
            updated_at_unix_ms,
            &Self::store_ctx(),
        ))?
        .map_err(|error| error.summary)
    }

    pub fn mark_apply_recovery_failed(
        &self,
        journal: &caly_storage::ApplyJournalRecord,
        updated_at_unix_ms: i64,
    ) -> Result<caly_storage::ApplyJournalRecord, String> {
        run_ready(mark_apply_recovery_failed(
            self.storage.as_ref(),
            journal,
            updated_at_unix_ms,
            &Self::store_ctx(),
        ))?
        .map_err(|error| error.summary)
    }

    pub fn scan_recovery_state(&self) -> Result<RecoveryScanReport, String> {
        run_ready(scan_recovery_state(
            self.storage.as_ref(),
            &Self::store_ctx(),
        ))?
        .map_err(|error| error.summary)
    }

    /// Read one snapshot by id, so a restored marker can be verified instead of trusted.
    pub fn get_snapshot_by_id(
        &self,
        snapshot_id: &caly_storage::SnapshotRecordId,
    ) -> Result<Option<SnapshotRecord>, String> {
        run_ready(self.storage.get_snapshot(snapshot_id, &Self::store_ctx()))?
            .map_err(|error| error.summary)
    }

    pub fn latest_last_known_good_snapshot(&self) -> Result<Option<SnapshotRecord>, String> {
        run_ready(self.storage.latest_last_known_good(&Self::store_ctx()))?
            .map_err(|error| error.summary)
    }

    /// Round 57: a rollback changes which snapshot is the known-good truth. The apply
    /// path marks every commit `last_known_good` and nothing ever demotes — so after a
    /// rollback the "latest LKG" could still be the deployment the operator just undid
    /// (found by `real_apply.rs`'s revive judge: the Noop re-commit's snapshot ordered
    /// *before* the rolled-back one on the policy's step-counting clock). This promotes
    /// the target — created_at above the current ceiling, so it orders last — and demotes
    /// the record it replaces. A target with no stored record is a no-op: the compensations
    /// already ran, and the pre-round-57 tolerance for ghost ids is not this function's
    /// fight.
    pub fn promote_snapshot_to_last_known_good(&self, target: &str) -> Result<(), String> {
        let Some(mut record) =
            self.get_snapshot_by_id(&caly_storage::SnapshotRecordId(target.to_owned()))?
        else {
            return Ok(());
        };
        let latest = self.latest_last_known_good_snapshot()?;
        let ceiling = latest
            .as_ref()
            .map(|current| current.created_at_unix_ms)
            .unwrap_or(i64::MIN)
            .max(record.created_at_unix_ms);
        if let Some(current) = latest {
            if current.id.0 != target && current.is_last_known_good {
                let demoted = caly_storage::SnapshotRecord {
                    is_last_known_good: false,
                    ..current.clone()
                };
                run_ready(self.storage.put_snapshot(demoted, &Self::store_ctx()))?
                    .map_err(|error| error.summary)?;
            }
        }
        if !record.is_last_known_good || record.created_at_unix_ms <= ceiling {
            record.is_last_known_good = true;
            record.created_at_unix_ms = ceiling + 1;
        }
        run_ready(self.storage.put_snapshot(record, &Self::store_ctx()))?
            .map_err(|error| error.summary)?;
        Ok(())
    }

    /// Compute what a storage GC cycle would collect, deleting nothing (`ADR-038 §1`).
    ///
    /// Two input choices are load-bearing rather than incidental:
    ///
    /// * The active snapshot is engine state, resolved from the same store used for GC. A caller
    ///   cannot pass `None` and silently drop a root; an unresolvable record becomes a gap that refuses
    ///   the plan -- the failure is reported instead of becoming a smaller answer.
    /// * `now_unix_ms` comes from the injected execution clock, the same base the apply journal and
    ///   the support bundle use. `GcPolicy::now_unix_ms` was previously only ever supplied by a test;
    ///   making it request-supplied would let a caller pick the instant that makes objects look old,
    ///   which is exactly the `ADR-035 §6bis-quater` problem in its other half.
    pub fn storage_gc_plan(
        &self,
        bounds: crate::gc_plan::ResolvedGcBounds,
    ) -> Result<crate::gc_plan::GcPlanSummary, String> {
        self.storage_gc_plan_except(bounds, None)
    }

    /// The plan, with one job excluded from the idle check (`ADR-038 §2`,
    /// `docs/history/ONBOARDING_NOTES.md §4.82`): a collection cycle running as a job must not refuse itself.
    pub fn storage_gc_plan_except(
        &self,
        bounds: crate::gc_plan::ResolvedGcBounds,
        excluding_job: Option<caly_api::JobId>,
    ) -> Result<crate::gc_plan::GcPlanSummary, String> {
        use caly_storage::StorageErrorKind;

        let state = self.snapshot()?;
        let (now, now_source) = self.storage_now();
        let mut gaps = Vec::new();

        // The candidate set is not a root class, so a backend that cannot enumerate objects has no
        // plan to report at all: that is an error, not a gap.
        let objects = match run_ready(self.storage.list_objects(&Self::store_ctx()))? {
            Ok(objects) => objects,
            Err(failure) if failure.kind == StorageErrorKind::Unsupported => return Err(
                "this backend cannot enumerate objects, so there is no candidate set to plan over"
                    .to_owned(),
            ),
            Err(failure) => return Err(failure.summary),
        };

        let retained_snapshots = crate::gc_plan::root_class(
            &mut gaps,
            "retained-snapshots",
            "`§13.1` protects what a rollback target still reads, so without the retained set those              objects look free",
            run_ready(self.storage.list_snapshots(&Self::store_ctx())),
        )?;
        let revisions = crate::gc_plan::root_class(
            &mut gaps,
            "registered-revisions",
            "`§13.1` lists 已登记 Revision as a root, so a revision's semantic digest cannot be              pinned without the set",
            run_ready(self.storage.list_revisions(&Self::store_ctx())),
        )?;
        let unfinished_journals = crate::gc_plan::root_class(
            &mut gaps,
            "unfinished-journals",
            "a transaction that started cutover still owns its artifact and semantic digests",
            run_ready(self.storage.list_unresolved_apply(&Self::store_ctx())),
        )?;
        let source_indexes = crate::gc_plan::root_class(
            &mut gaps,
            "source-index",
            "a durable source index owns its raw body so a later conditional 304 remains verifiable",
            run_ready(self.storage.list_source_indexes(&Self::store_ctx())),
        )?;
        let source_raw_objects = source_indexes
            .iter()
            .map(|record| record.raw_object_digest.clone())
            .collect();

        // The content tree is not a root class: it is the half of the store the metadata-keyed
        // candidate set above cannot see (`store.rs::list_content`). Both ways this can fail are
        // gaps rather than errors -- `Unsupported` is a capability answer, and damage *here* must
        // not hide every other line an operator needs (the same reasoning as the marker below);
        // but a plan with this gap licenses no deletion list, which `roots_complete` already
        // enforces for the whole summary.
        let content = match run_ready(self.storage.list_content(&Self::store_ctx()))? {
            Ok(entries) => entries,
            Err(failure) if failure.kind == StorageErrorKind::Unsupported => {
                gaps.push(crate::gc_plan::GcRootGap::new(
                    "content-tree",
                    format!(
                        "this backend cannot walk its content tree, so orphan content and write \
                         residue are invisible to the plan: {}",
                        failure.summary
                    ),
                ));
                Vec::new()
            }
            Err(failure) => {
                gaps.push(crate::gc_plan::GcRootGap::damage(
                    "content-tree",
                    format!(
                        "the content tree could not be walked: {} (`RFC-0007 §6.1` half; \
                         a refusal here is damage, not an empty tree)",
                        failure.summary
                    ),
                ));
                Vec::new()
            }
        };

        let last_known_good =
            match run_ready(self.storage.latest_last_known_good(&Self::store_ctx()))? {
                Ok(record) => record,
                Err(failure) => {
                    // Both an unanswerable marker and a pointer at a record the store cannot produce are
                    // gaps here, not errors. The distinction the plan keeps is between "I cannot describe
                    // the store" (the candidate set: that fails the call) and "I cannot rule out a root"
                    // (which must still report the store, and refuse). Failing here would also hide every
                    // other line an operator needs in exactly the case that produced the damage.
                    gaps.push(crate::gc_plan::GcRootGap::damage(
                        "last-known-good",
                        format!("the marker could not be resolved: {}", failure.summary),
                    ));
                    None
                }
            };

        let active_id = state.active_snapshot_id.clone();
        let active_snapshot = match active_id.as_deref() {
            None => None,
            Some(id) => {
                let record = self
                    .get_snapshot_by_id(&caly_storage::SnapshotRecordId(id.to_owned()))
                    .map_err(|error| {
                        format!("the active snapshot {id} could not be read: {error}")
                    })?;
                if record.is_none() {
                    gaps.push(crate::gc_plan::GcRootGap::damage(
                        "active-snapshot",
                        format!(
                            "the engine reports {id} as active and the store cannot produce it"
                        ),
                    ));
                }
                record
            }
        };

        // `§13.1`'s sixth class: what an in-flight transaction references. The engine keeps the
        // `EffectPlan` of the last completed apply, not the digests a running one is about to write,
        // so there is nothing honest to pin -- and "nothing to pin" is precisely the answer that must
        // not be reported as a fact about the store. `ADR-038 §3` closes it by recording digests on
        // the job; until then a non-idle engine gets a refused plan rather than a plausible one.
        let idle = crate::gc_plan::work_in_flight_except(&state, excluding_job) == 0;
        if !idle {
            gaps.push(crate::gc_plan::GcRootGap::new(
                "running-job-artifacts",
                "an in-flight command may reference objects no journal has recorded yet, and the                  engine keeps no per-job digest list to pin",
            ));
        }

        let pending_deployments = unfinished_journals.len();
        let inputs = crate::gc_plan::GcPlanInputs {
            objects,
            retained_snapshots,
            revisions,
            unfinished_journals,
            source_raw_objects,
            running_job_artifacts: Vec::new(),
            content,
            active_snapshot: active_snapshot.as_ref(),
            last_known_good: last_known_good.as_ref(),
            now_unix_ms: now,
            now_source,
            grace_period_ms: bounds.grace_period_ms,
            max_deletions: bounds.max_deletions,
            idle,
            pending_deployments,
            gaps,
        };
        Ok(crate::gc_plan::build_gc_plan(&inputs))
    }

    /// Run one storage collection cycle (`ADR-038 §2`).
    ///
    /// Three properties, all deliberate:
    ///
    /// * the cycle executes **the plan it just computed** -- `plan.sweep` is the list handed to the
    ///   store, so there is no second place where "what is safe to delete" gets decided;
    /// * an incomplete root set or an ineligible engine deletes nothing and records why (`§13.2`),
    ///   and the record is not a silent success;
    /// * the outcome is stored (`last_gc_run`) so `doctor` and a support bundle can see the difference
    ///   between "reclaimed 40 objects", "nothing to reclaim" and "refused".
    pub fn storage_gc_collect(
        &self,
        bounds: crate::gc_plan::ResolvedGcBounds,
        excluding_job: Option<caly_api::JobId>,
    ) -> Result<crate::gc_plan::GcRunRecord, String> {
        let plan = self.storage_gc_plan_except(bounds, excluding_job)?;
        let generation = self.snapshot()?.generation;
        // Who this cycle belongs to, decided by job id rather than by a flag that gets cleared: a
        // manual collection that happens to run while an automatic one is queued must not inherit its
        // label (`ADR-038 §13.2`).
        let source = self.take_idle_gc_claim(excluding_job);
        let record = |source: &'static str,
                      refused: Option<String>,
                      collected: Vec<String>,
                      failed: Vec<(String, String)>,
                      collected_content: Vec<String>,
                      failed_content: Vec<(String, String)>| {
            crate::gc_plan::GcRunRecord {
                at_generation: generation,
                now_unix_ms: plan.now_unix_ms,
                now_source: plan.now_source,
                grace_period_ms: plan.grace_period_ms,
                max_deletions: plan.max_deletions,
                collected,
                failed,
                retained_total: plan.retained_total,
                skipped_for_grace: plan.skipped_for_grace,
                collected_content,
                failed_content,
                refused,
                triggered_by: source,
            }
        };
        if !plan.would_run() {
            let refused = plan
                .refusal()
                .unwrap_or_else(|| "the plan refused without saying why".to_owned());
            let out = record(
                source,
                Some(refused),
                Vec::new(),
                Vec::new(),
                Vec::new(),
                Vec::new(),
            );
            self.remember_gc_run(&out)?;
            return Ok(out);
        }
        if plan.sweep.is_empty() && plan.orphan_sweep.is_empty() {
            let out = record(source, None, Vec::new(), Vec::new(), Vec::new(), Vec::new());
            self.remember_gc_run(&out)?;
            return Ok(out);
        }
        // Objects first, then content: both lists came from the same plan, under the same budget,
        // and the order keeps "metadata went before the bytes it named" true even inside one cycle.
        let mut collected = Vec::new();
        let mut failed = Vec::new();
        if !plan.sweep.is_empty() {
            let report = run_ready(caly_storage::gc::sweep_objects(
                self.storage.as_ref(),
                &plan.sweep,
                plan.retained_total,
                &Self::store_ctx(),
            ))?;
            collected = report
                .collected
                .iter()
                .map(|digest| digest.0.clone())
                .collect();
            failed = report
                .failed
                .into_iter()
                .map(|(digest, reason)| (digest.0, reason))
                .collect();
        }
        // The content sweep runs even when the object sweep found nothing -- that is the whole
        // point of a cycle over a store whose disk grew while `deleted=0` stayed true.
        let mut collected_content = Vec::new();
        let mut failed_content = Vec::new();
        if !plan.orphan_sweep.is_empty() {
            let report = run_ready(caly_storage::gc::sweep_orphan_content(
                self.storage.as_ref(),
                &plan.orphan_sweep,
                &Self::store_ctx(),
            ))?;
            collected_content = report.collected;
            failed_content = report.failed;
        }
        let out = record(
            source,
            None,
            collected,
            failed,
            collected_content,
            failed_content,
        );
        self.remember_gc_run(&out)?;
        Ok(out)
    }

    /// Register one idle check (`ADR-038 §13.2`).
    ///
    /// The counter is only advanced while the automation job is **enabled**: counting while it is off
    /// would make a freshly enabled collector fire in the middle of an unrelated wait, so the cadence
    /// would depend on when someone happened to leave it disabled.
    pub fn note_idle_gc_check(&self, enabled: bool) -> Result<u64, String> {
        let mut guard = self
            .inner
            .lock()
            .map_err(|_| "engine state lock poisoned".to_owned())?;
        if !enabled {
            return Ok(0);
        }
        guard.idle_gc_checks = guard.idle_gc_checks.saturating_add(1);
        Ok(guard.idle_gc_checks)
    }

    /// Whether the idle collector's automation job is on. An absent entry means off: the daemon never
    /// acts on stored data until somebody files the role-gated `AutomationPatch` that says so.
    pub fn idle_gc_enabled(&self) -> Result<bool, String> {
        let guard = self
            .inner
            .lock()
            .map_err(|_| "engine state lock poisoned".to_owned())?;
        Ok(guard
            .automation_overrides
            .get(crate::gc_plan::AUTOMATION_IDLE_GC_JOB_ID)
            .copied()
            .unwrap_or(false))
    }

    /// The queue is empty: decide whether the idle collector should be scheduled, and do it if so.
    ///
    /// Note what is **not** re-derived here: idleness, pending deployments and root completeness are the
    /// plan's own `would_run`, computed once and read by both the cycle and this gate
    /// (`docs/history/ONBOARDING_NOTES.md §4.81` again). And the returned `true` means "a job was queued", not
    /// "things were deleted" -- the cycle reports that itself, in `last_gc_run`.
    pub fn idle_gc_tick(&self) -> Result<bool, String> {
        let enabled = self.idle_gc_enabled()?;
        let checks = self.note_idle_gc_check(enabled)?;
        if !crate::gc_plan::idle_gc_check_is_due(checks) {
            // Cheap bail-out, before any store read: not due is decided by a counter.
            return Ok(false);
        }
        // The automatic pass uses the same default bounds a manual `GcCollectRequest::new()` gets, so
        // there is no second set of numbers to keep in sync. `resolve` cannot refuse those defaults; if
        // that ever stops being true, the tick says so out loud rather than inventing bounds.
        let bounds = crate::gc_plan::GcPlanBounds {
            grace_period_ms: None,
            max_deletions: None,
        }
        .resolve()
        .map_err(|refusal| format!("idle collector bounds refused: {}", refusal.message()))?;
        let plan = self.storage_gc_plan_except(bounds, None)?;
        let decision =
            crate::gc_plan::decide_idle_gc(checks, enabled, plan.would_run(), plan.collect.len());
        if !decision.is_enqueue() {
            return Ok(false);
        }
        let trace = format!("automation-gc-idle-check-{checks}");
        let command = crate::command::Command {
            id: crate::command::CommandId(trace.clone()),
            request_id: None,
            actor: caly_common::Actor::System,
            // The engine's own path has no caller, so it gets a fresh context rather than a borrowed
            // one: no deadline to blame a caller for, and the stated default budget (round 24).
            context: caly_common::RequestContext::new(
                caly_common::TraceId::new(trace),
                caly_common::Actor::System,
            ),
            timeout_ms: None,
            idempotency_key: Some(crate::command::IdempotencyKey(
                crate::gc_plan::idle_gc_idempotency_key(checks),
            )),
            kind: crate::command::CommandKind::StorageGc {
                grace_period_ms: None,
                max_deletions: None,
            },
        };
        let accepted = match self.submit_checked(command) {
            Ok(result) => result.accepted,
            Err(failure) => {
                // Only reachable if the queue or the lock says no. A background cycle that cannot be
                // scheduled is *skipped*, never retried eagerly: the counter already advanced, so the
                // next due check tries again.
                return Err(format!("idle collector could not be queued: {failure:?}"));
            }
        };
        let mut guard = self
            .inner
            .lock()
            .map_err(|_| "engine state lock poisoned".to_owned())?;
        guard.idle_gc_claim = Some(accepted.job_id);
        drop(guard);
        self.append_job_event(
            accepted.job_id,
            crate::job::JobEvent::Log {
                level: "info".to_owned(),
                message: format!(
                    "automation {} enqueued at check {checks} ({})",
                    crate::gc_plan::AUTOMATION_IDLE_GC_JOB_ID,
                    decision.as_str()
                ),
            },
        )?;
        Ok(true)
    }

    /// Which label the cycle about to run should carry, consuming the claim only when the job ids match.
    ///
    /// Matching rather than "clear a flag when it fires": see the unit test below for why the ordering
    /// guarantee (the tick only runs on an empty queue, and a queued automatic job makes the plan
    /// non-idle, so no manual cycle can cut in front of it) is *not* the only thing protecting this --
    /// if the queue ever grows a priority order, the label logic still attributes correctly.
    pub(crate) fn take_idle_gc_claim(&self, job: Option<caly_api::JobId>) -> &'static str {
        let Ok(mut guard) = self.inner.lock() else {
            return crate::gc_plan::GC_TRIGGER_CALLER;
        };
        let claimed = matches!(job, Some(id) if guard.idle_gc_claim == Some(id));
        if claimed {
            guard.idle_gc_claim = None;
            return crate::gc_plan::GC_TRIGGER_IDLE_AUTOMATION;
        }
        crate::gc_plan::GC_TRIGGER_CALLER
    }

    fn remember_gc_run(&self, record: &crate::gc_plan::GcRunRecord) -> Result<(), String> {
        let mut guard = self
            .inner
            .lock()
            .map_err(|_| "engine state lock poisoned".to_owned())?;
        guard.last_gc_run = Some(record.clone());
        Ok(())
    }

    /// The last collection cycle, as recorded. `None` means this process never ran one, which is a
    /// different answer from "ran and deleted nothing".
    pub fn last_gc_run(&self) -> Result<Option<crate::gc_plan::GcRunRecord>, String> {
        Ok(self.snapshot()?.last_gc_run.clone())
    }

    /// Record which snapshot the deployment is on. Called by the commit path and by the daemon after a
    /// recovery scan; the GC plan reads it as a root (`ADR-038 §8`).
    pub fn set_active_snapshot(&self, snapshot_id: Option<String>) -> Result<(), String> {
        let mut guard = self
            .inner
            .lock()
            .map_err(|_| "engine state lock poisoned".to_owned())?;
        guard.active_snapshot_id = snapshot_id;
        Ok(())
    }

    /// The refusals this engine remembers (bounded by `EngineState::RECENT_OVERLOADS`), newest last.
    ///
    /// Read-only on purpose: the only way to add to it is to actually be refused. `doctor` and the
    /// support bundle both render this, so "we were under load" survives the caller's error being
    /// closed and retried.
    pub fn recent_overloads(&self) -> Result<Vec<OverloadReport>, String> {
        let guard = self
            .inner
            .lock()
            .map_err(|_| "engine state lock poisoned".to_owned())?;
        Ok(guard.overloads.iter().cloned().collect())
    }

    /// `(entries, finished_window, evictions)` of the idempotency dedup window.
    ///
    /// Reported because `RFC-0002 §8.3`'s window is explicitly "最近窗口": whether a key is still
    /// dedupable is observable state, and a bounded window that does not say it is bounded is the
    /// truncated-response defect again (`docs/history/ONBOARDING_NOTES.md §4.54`).
    pub fn idempotency_stats(&self) -> Result<(usize, usize, usize), String> {
        let guard = self
            .inner
            .lock()
            .map_err(|_| "engine state lock poisoned".to_owned())?;
        Ok((
            guard.idempotency.len(),
            guard.idempotency.max_finished(),
            guard.idempotency.evictions(),
        ))
    }

    /// The refusals this engine made, already reduced to display lines (`doctor` and the support
    /// bundle share this one builder, so they cannot disagree about how many there were).
    pub fn overload_lines(&self) -> Result<Vec<String>, String> {
        let guard = self
            .inner
            .lock()
            .map_err(|_| "engine state lock poisoned".to_owned())?;
        Ok(guard.overload_lines())
    }

    /// `(depth, capacity)` of the command queue, for diagnostics surfaces.
    pub fn queue_stats(&self) -> Result<(usize, usize), String> {
        let guard = self
            .inner
            .lock()
            .map_err(|_| "engine state lock poisoned".to_owned())?;
        Ok((guard.queue.len(), guard.queue.capacity()))
    }

    pub fn drain_with_policy(&self, policy: WorkerPolicy) -> Result<WorkerDrainReport, String> {
        drain_with_policy(self, policy)
    }

    pub fn follow_job(&self, job_id: JobId) -> Result<JobFollow, String> {
        let guard = self
            .inner
            .lock()
            .map_err(|_| "engine state lock poisoned".to_owned())?;
        Ok(JobFollow {
            job: guard.jobs.get(&job_id.0).cloned(),
            lifecycle: guard.current_lifecycle(),
        })
    }

    pub fn project_job_follow(
        &self,
        job_id: JobId,
        from_event_index: Option<u64>,
    ) -> Result<Option<JobFollowProjection>, String> {
        let followed = self.follow_job(job_id)?;
        let Some(job) = followed.job else {
            return Ok(None);
        };
        let window = slice_job_events(&job, from_event_index, JobEventRetentionPolicy::default());
        let summary = summarize_job_record(&job);
        Ok(Some(JobFollowProjection {
            summary: JobFollowView {
                job_id,
                state: format!("{:?}", job.state).to_lowercase(),
                lifecycle: format!("{:?}", followed.lifecycle).to_lowercase(),
                next_event_index: window.next_index,
                retained_from_event_index: window.retained_from_index,
                reset_required: window.reset_required,
                event_count: window.events.len(),
                last_stage: summary.last_stage,
                last_stage_pct: summary.last_stage_pct,
                warning_count: summary.warning_count,
                log_count: summary.log_count,
                failure_code: summary.failure_code,
                failure_summary: summary.failure_summary,
            },
            window: Some(window),
        }))
    }

    /// A summary row per retained job, newest first, capped at `limit`.
    ///
    /// `jobs.events`/`jobs.follow` answer questions about a job you already know the id of; this is
    /// the discovery half — without it a client cannot find out which jobs exist after a restart of
    /// its own shell (`docs/engineering/JOB_FLOW_SCENARIO_REVIEW.md` measured that gap). It reuses the exact
    /// summary `project_job_follow` projects for one job, so the list row and that job's follow
    /// summary cannot drift. The window counters describe what is *retained* for the job (the list
    /// carries no page of lines). The cap is a ceiling the caller cannot raise past the engine's own.
    pub fn list_job_views(&self, limit: usize) -> Result<Vec<JobFollowView>, String> {
        let guard = self
            .inner
            .lock()
            .map_err(|_| "engine state lock poisoned".to_owned())?;
        let lifecycle = format!("{:?}", guard.current_lifecycle()).to_lowercase();
        // ids are a monotonically-minted BTreeMap, so reverse iteration is newest-first.
        // BTreeMap is ordered by id ascending; `.rev()` yields newest first and the take caps it.
        let rows: Vec<JobFollowView> = guard
            .jobs
            .iter()
            .rev()
            .take(limit.max(1))
            .map(|(id, job)| {
                let window = slice_job_events(job, None, JobEventRetentionPolicy::default());
                let summary = summarize_job_record(job);
                JobFollowView {
                    job_id: JobId(*id),
                    state: format!("{:?}", job.state).to_lowercase(),
                    lifecycle: lifecycle.clone(),
                    next_event_index: window.next_index,
                    retained_from_event_index: window.retained_from_index,
                    reset_required: window.reset_required,
                    event_count: window.events.len(),
                    last_stage: summary.last_stage,
                    last_stage_pct: summary.last_stage_pct,
                    warning_count: summary.warning_count,
                    log_count: summary.log_count,
                    failure_code: summary.failure_code,
                    failure_summary: summary.failure_summary,
                }
            })
            .collect();
        Ok(rows)
    }

    pub fn events_since(&self, from_exclusive: Option<EventSeq>) -> Result<EventWindow, String> {
        let guard = self
            .inner
            .lock()
            .map_err(|_| "engine state lock poisoned".to_owned())?;
        let replay = guard.events.replay_from(from_exclusive);
        let window = match replay {
            ReplayWindow::Events {
                next_seq,
                retained_from,
                events,
            } => EventWindow {
                from_exclusive,
                next_seq,
                retained_from,
                reset_required: false,
                events,
            },
            ReplayWindow::ResetRequired {
                next_seq,
                retained_from,
                ..
            } => EventWindow {
                from_exclusive,
                next_seq,
                retained_from,
                reset_required: true,
                events: Vec::new(),
            },
        };
        Ok(window)
    }

    pub fn automation_overrides(&self) -> Result<Vec<(String, bool)>, String> {
        let guard = self
            .inner
            .lock()
            .map_err(|_| "engine state lock poisoned".to_owned())?;
        Ok(guard
            .automation_overrides
            .iter()
            .map(|(job_id, enabled)| (job_id.clone(), *enabled))
            .collect())
    }

    pub fn set_automation_job(&self, request: &PatchAutomationJob) -> Result<(), String> {
        let mut guard = self
            .inner
            .lock()
            .map_err(|_| "engine state lock poisoned".to_owned())?;
        guard
            .automation_overrides
            .insert(request.job_id.clone(), request.enabled);
        Ok(())
    }

    pub fn idempotency_status(
        &self,
        actor: caly_common::Actor,
        key: &IdempotencyKey,
    ) -> Result<Option<IdempotencyStatus>, String> {
        let guard = self
            .inner
            .lock()
            .map_err(|_| "engine state lock poisoned".to_owned())?;
        Ok(guard
            .idempotency
            .get(actor, key)
            .map(|record| record.status.clone()))
    }
}

#[derive(Default)]
struct JobRecordSummary {
    last_stage: Option<String>,
    last_stage_pct: Option<u8>,
    warning_count: usize,
    log_count: usize,
    failure_code: Option<String>,
    failure_summary: Option<String>,
}

fn summarize_job_record(job: &JobRecord) -> JobRecordSummary {
    let mut summary = JobRecordSummary::default();
    for event in &job.events {
        match event {
            JobEvent::Stage { stage, pct } => {
                summary.last_stage = Some(stage.clone());
                summary.last_stage_pct = *pct;
            }
            JobEvent::Warning { .. } => {
                summary.warning_count = summary.warning_count.saturating_add(1);
            }
            JobEvent::Log { .. } => {
                summary.log_count = summary.log_count.saturating_add(1);
            }
            JobEvent::Failed { error } => {
                summary.failure_code = Some(error.code.as_str().to_owned());
                summary.failure_summary = Some(error.summary.clone());
            }
            JobEvent::Done { .. } => {}
        }
    }
    summary
}

/// Mask the text an operator would read off a job, leaving untouched events alone.
fn redact_job_event(redactor: &caly_common::redact::Redactor, event: JobEvent) -> JobEvent {
    use caly_common::redact::Redactor as R;
    fn hit(redactor: &R, text: &str) -> bool {
        redactor.exposes_sensitive_text(text)
    }
    match event {
        JobEvent::Log { level, message } if hit(redactor, &message) => JobEvent::Log {
            level: if hit(redactor, &level) {
                redactor.redact(&level)
            } else {
                level
            },
            message: redactor.redact(&message),
        },
        JobEvent::Stage { stage, pct } if hit(redactor, &stage) => JobEvent::Stage {
            stage: redactor.redact(&stage),
            pct,
        },
        JobEvent::Warning { message } if hit(redactor, &message) => JobEvent::Warning {
            message: redactor.redact(&message),
        },
        JobEvent::Failed { error } if error.exposes_sensitive_text(redactor) => JobEvent::Failed {
            error: error.redacted(redactor),
        },
        other => other,
    }
}

#[cfg(test)]
mod idle_gc_label_tests {
    use super::EngineHandle;
    use crate::gc_plan::{GC_TRIGGER_CALLER, GC_TRIGGER_IDLE_AUTOMATION};
    use caly_api::JobId;

    /// The claim matcher's two directions, pinned directly.
    ///
    /// The behavioural version of this case ("a manual cycle steals the automation label") is
    /// unreachable today: the tick only fires on an empty queue, and a queued automatic job makes the
    /// plan non-idle, so a manual cycle that runs before it is refused instead. That is exactly why the
    /// rule is asserted at the seam rather than left to an argument about ordering -- if the queue ever
    /// grows a priority order, matching by job id is what keeps a manual deletion from being reported as
    /// something the daemon decided on its own.
    #[test]
    fn only_the_job_that_was_scheduled_consumes_the_automation_label() {
        let handle = EngineHandle::default();
        assert_eq!(
            handle.take_idle_gc_claim(Some(JobId(7))),
            GC_TRIGGER_CALLER,
            "with no claim outstanding, every cycle is somebody's"
        );

        {
            let mut guard = handle.inner.lock().expect("lock");
            guard.idle_gc_claim = Some(JobId(9));
        }
        assert_eq!(
            handle.take_idle_gc_claim(Some(JobId(7))),
            GC_TRIGGER_CALLER,
            "a different job id must not pick up a label that belongs to another cycle"
        );
        assert_eq!(
            handle.inner.lock().expect("lock").idle_gc_claim,
            Some(JobId(9)),
            "and it must not consume it either -- the scheduled cycle still has a claim to match"
        );
        assert_eq!(
            handle.take_idle_gc_claim(Some(JobId(9))),
            GC_TRIGGER_IDLE_AUTOMATION,
            "the scheduled cycle is the one that gets it"
        );
        assert_eq!(handle.inner.lock().expect("lock").idle_gc_claim, None);
        assert_eq!(
            handle.take_idle_gc_claim(Some(JobId(9))),
            GC_TRIGGER_CALLER,
            "consumed once: a repeat of the same job cannot claim the label twice"
        );
    }
}

#[cfg(test)]
mod list_job_views_tests {
    use super::EngineHandle;
    use crate::job::{JobRecord, JobState};
    use caly_api::JobId;

    fn seed(handle: &EngineHandle, id: u64, state: JobState) {
        let mut guard = handle.inner.lock().expect("lock");
        guard.insert_job(JobRecord {
            id: JobId(id),
            state,
            revision: id,
            events: Vec::new(),
        });
    }

    /// The discovery list is newest-first: id 3 first, and the cap truncates from the oldest end.
    #[test]
    fn list_job_views_is_newest_first_and_capped() {
        let handle = EngineHandle::default();
        seed(&handle, 1, JobState::Completed);
        seed(&handle, 2, JobState::Completed);
        seed(&handle, 3, JobState::Failed);

        let all = handle.list_job_views(64).expect("list");
        let ids: Vec<u64> = all.iter().map(|row| row.job_id.0).collect();
        assert_eq!(ids, vec![3, 2, 1], "newest first, not insertion order");
        assert_eq!(all[0].state, "failed", "state is projected per row");

        let capped = handle.list_job_views(2).expect("capped list");
        let capped_ids: Vec<u64> = capped.iter().map(|row| row.job_id.0).collect();
        assert_eq!(
            capped_ids,
            vec![3, 2],
            "the cap keeps the NEWEST two, dropping the oldest"
        );
    }

    /// An empty engine answers an empty list — a legitimate directory, not an error.
    #[test]
    fn list_job_views_empty_is_ok() {
        let handle = EngineHandle::default();
        let rows = handle.list_job_views(64).expect("empty list is ok");
        assert!(rows.is_empty());
    }
}
