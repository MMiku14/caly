#![forbid(unsafe_code)]

// Re-exported so downstream crates can *implement* `executor::EffectRuntime` without taking
// a direct dependency on `caly-plan` (round 55): the daemon's real backend names these types
// in its method signatures, and a re-export is presentation — the dependency arrow stays
// engine -> plan, exactly as the arch allow-list froze it.
pub use caly_plan::{CoreCall, CoreKind, CoreSpec, EffectPlan, EffectStep, ProbeKind};

pub mod apply;
pub mod bundle;
pub mod command;
pub mod config;
pub mod coordinator;
pub mod dispatch;
pub mod event;
pub mod event_stream;
pub mod executor;
pub mod gc_plan;
pub mod idempotency;
pub mod job;
pub mod job_follow;
pub mod overload;
pub mod processor;
pub mod queue;
pub mod recovery;
pub mod run_limits;
pub mod service;
pub mod sim_runtime;
pub mod source_persistence;
pub mod source_worker;
pub mod state;
pub mod worker;

pub use apply::*;
pub use bundle::*;
pub use caly_io::Clock;
pub use command::*;
pub use config::*;
pub use coordinator::*;
pub use dispatch::*;
pub use event::*;
pub use event_stream::*;
pub use executor::*;
pub use gc_plan::*;
pub use idempotency::*;
pub use job::*;
pub use job_follow::*;
pub use overload::*;
pub use processor::*;
pub use queue::*;
pub use recovery::*;
pub use run_limits::*;
pub use service::*;
pub use sim_runtime::*;
pub use source_worker::*;
pub use state::*;
pub use worker::*;
