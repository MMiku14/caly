//! Deterministic in-memory effect runtime.
//!
//! This is the default [`EffectRuntime`](crate::executor::EffectRuntime) target for the apply
//! centerline. It lives in its own module (it used to be inlined into `executor.rs`, which made
//! that module both the *interpreter* and a *world emulator*) for two reasons:
//!
//! 1. The interpreter is the part whose correctness the RFCs care about; keeping it small and
//!    dependency-free makes the gates auditable.
//! 2. This file is the piece a real backend replaces. `caly-io-sim` cannot host it, because the
//!    workspace keeps simulation out of production edges, and `EngineHandle` needs a *default*
//!    runtime at run time, not only in tests.
//!
//! Every behavior here is derived from plan content plus explicit seeding: no filesystem, no
//! process table, no clock, no randomness (`clippy.toml` disallowed symbols; `ADR-011`).

use std::collections::BTreeMap;
use std::collections::BTreeSet;
use std::sync::{Arc, Mutex};

use caly_plan::CoreCall;
use caly_plan::DbOp;
use caly_plan::EffectStep;
use caly_plan::ProbeKind;
use caly_storage::ApplyPhase;

use crate::executor::{step_kind_name, EffectRuntime, StepEvidence, StepFailure};

/// A running core as tracked by [`SimulatedRuntime`].
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct SimulatedCore {
    pub instance: String,
    pub config_digest: String,
    pub binary_digest: String,
}

#[derive(Clone, Debug, Default, Eq, PartialEq)]
struct SimWorld {
    objects: BTreeSet<String>,
    materialized: BTreeMap<String, String>,
    db: BTreeMap<String, String>,
    running_core: Option<SimulatedCore>,
    /// Identity the live core claims to be running. A `Probe(ConfigIdentity)` compares the
    /// plan's expectation against this, which is how "the wrong config is live" is caught.
    /// The adapters carry the identity as an opaque label (not the artifact digest), so an
    /// unseeded world adopts whatever the first identity probe reports.
    core_identity: Option<String>,
    net_txn: Option<String>,
    log: Vec<String>,
    fail_next_probe: Option<String>,
    /// How long the *next* probe is allowed to appear to take (`ADR-036 §2.5`). The world
    /// models a slow core; the executor decides whether that is a failure -- see
    /// [`crate::executor::probe_deadline_failure`].
    slow_next_probe_ms: Option<u64>,
    enforce_preconditions: bool,
    sequence: u64,
}

/// A deterministic, inspectable [`EffectRuntime`] implementation.
///
/// It is not a filesystem or process simulator; it models exactly the state the
/// centerline needs to reason about (written objects, materialized paths, DB ops, a
/// running core, an applied net txn) so that plan/world inconsistencies become
/// observable failures instead of silently "succeeding" strings.
#[derive(Clone, Debug, Default)]
pub struct SimulatedRuntime {
    world: Arc<Mutex<SimWorld>>,
}

impl SimulatedRuntime {
    pub fn new() -> Self {
        Self::default()
    }

    /// Seed a previously deployed core, i.e. model a non-first apply.
    pub fn with_running_core(core: SimulatedCore) -> Self {
        let runtime = Self::new();
        if let Ok(mut guard) = runtime.world.lock() {
            // A core that is running reports the config it was handed (round 57): a
            // "running but silent" world is exactly the state the identity probe
            // refuses to paper over anymore.
            guard.core_identity = Some(core.config_digest.clone());
            guard.running_core = Some(core);
        }
        runtime
    }

    pub fn set_enforce_preconditions(&self, enabled: bool) {
        if let Ok(mut guard) = self.world.lock() {
            guard.enforce_preconditions = enabled;
        }
    }

    /// Seed the identity that the currently running core reports, i.e. model "a different
    /// config is live right now". Used to prove the identity probe can block an apply.
    pub fn seed_core_identity(&self, identity: impl Into<String>) {
        if let Ok(mut guard) = self.world.lock() {
            guard.core_identity = Some(identity.into());
        }
    }

    /// Model a core that answers, but late: the next `Probe` reports this much elapsed time.
    ///
    /// One-shot for the same reason `fail_next_probe` is: a world model that keeps being slow changes
    /// every later step, and a test would then be asserting an accumulation rather than one decision.
    pub fn make_next_probe_slow(&self, millis: u64) {
        if let Ok(mut guard) = self.world.lock() {
            guard.slow_next_probe_ms = Some(millis);
        }
    }

    /// Make the next `Probe` fail with `reason`, to exercise the verify gate.
    pub fn fail_next_probe(&self, reason: impl Into<String>) {
        if let Ok(mut guard) = self.world.lock() {
            guard.fail_next_probe = Some(reason.into());
        }
    }

    pub fn snapshot(&self) -> SimulatedRuntimeState {
        let guard = match self.world.lock() {
            Ok(guard) => guard,
            Err(_) => return SimulatedRuntimeState::default(),
        };
        SimulatedRuntimeState {
            objects: guard.objects.iter().cloned().collect(),
            materialized: guard
                .materialized
                .iter()
                .map(|(path, digest)| format!("{path}={digest}"))
                .collect(),
            db: guard
                .db
                .iter()
                .map(|(key, value)| format!("{key}={value}"))
                .collect(),
            running_core: guard.running_core.clone(),
            core_identity: guard.core_identity.clone(),
            net_txn: guard.net_txn.clone(),
            log: guard.log.clone(),
            sequence: guard.sequence,
        }
    }

    fn note(&self, observations: &[String]) {
        if let Ok(mut guard) = self.world.lock() {
            for observation in observations {
                guard.sequence = guard.sequence.saturating_add(1);
                guard.log.push(observation.clone());
            }
        }
    }
}

/// Read-only view of a [`SimulatedRuntime`], for assertions and diagnostics.
#[derive(Clone, Debug, Default, Eq, PartialEq)]
pub struct SimulatedRuntimeState {
    pub objects: Vec<String>,
    pub materialized: Vec<String>,
    pub db: Vec<String>,
    pub running_core: Option<SimulatedCore>,
    pub core_identity: Option<String>,
    pub net_txn: Option<String>,
    pub log: Vec<String>,
    pub sequence: u64,
}

impl SimulatedRuntimeState {
    pub fn has_object(&self, digest: &str) -> bool {
        self.objects.iter().any(|value| value == digest)
    }
}

impl EffectRuntime for SimulatedRuntime {
    fn execute(&self, phase: ApplyPhase, step: &EffectStep) -> Result<StepEvidence, StepFailure> {
        let outcome = self.apply_step(phase, step);
        if let Ok(evidence) = &outcome {
            self.note(&evidence.observations);
        }
        outcome
    }

    fn compensate(
        &self,
        phase: ApplyPhase,
        step: &EffectStep,
    ) -> Result<StepEvidence, StepFailure> {
        let outcome = self.undo_step(phase, step);
        if let Ok(evidence) = &outcome {
            self.note(&evidence.observations);
        }
        outcome
    }
}

impl SimulatedRuntime {
    fn apply_step(
        &self,
        phase: ApplyPhase,
        step: &EffectStep,
    ) -> Result<StepEvidence, StepFailure> {
        let mut guard = self.world.lock().map_err(|_| {
            StepFailure::new("runtime-poisoned", "simulated runtime lock poisoned", false)
        })?;

        let require_core = |world: &SimWorld| -> Result<(), StepFailure> {
            if world.running_core.is_none() && world.enforce_preconditions {
                return Err(StepFailure::new(
                    "no-running-core",
                    format!(
                        "{:?} step requires a live core but the runtime is empty",
                        phase
                    ),
                    true,
                ));
            }
            Ok(())
        };

        match step {
            EffectStep::WriteObject { digest, source, .. } => {
                let inserted = guard.objects.insert(digest.clone());
                Ok(StepEvidence::one(format!(
                    "cas.write {} {} size={}",
                    if inserted { "created" } else { "exists" },
                    source.digest,
                    source.size_hint.unwrap_or(0)
                )))
            }
            EffectStep::MaterializeArtifact { digest, at, mode } => {
                if !guard.objects.contains(digest) {
                    return Err(StepFailure::new(
                        "object-not-found",
                        format!("cannot materialize {at}: object {digest} was never written"),
                        true,
                    ));
                }
                guard.materialized.insert(at.clone(), digest.clone());
                Ok(StepEvidence::one(format!(
                    "fs.materialize {at} mode={:?}",
                    mode
                )))
            }
            EffectStep::DbTxn { ops } => {
                let mut evidence = StepEvidence::default();
                for op in ops {
                    match op {
                        DbOp::Put { table, key, value } => {
                            let store_key = format!("{table}/{key}");
                            guard.db.insert(store_key.clone(), value.clone());
                            evidence.observations.push(format!("db.put {store_key}"));
                        }
                        DbOp::Delete { table, key } => {
                            let store_key = format!("{table}/{key}");
                            let removed = guard.db.remove(&store_key).is_some();
                            evidence.observations.push(format!(
                                "db.delete {store_key} {}",
                                if removed { "removed" } else { "absent" }
                            ));
                        }
                    }
                }
                Ok(evidence)
            }
            EffectStep::SpawnCore { spec } => {
                let instance = format!("core-{:08x}", stable_hash(&spec.config_digest));
                guard.running_core = Some(SimulatedCore {
                    instance: instance.clone(),
                    config_digest: spec.config_digest.clone(),
                    binary_digest: spec.binary_digest.clone(),
                });
                // A freshly spawned core reports the config it was handed.
                guard.core_identity = Some(spec.config_digest.clone());
                Ok(StepEvidence::one(format!(
                    "proc.spawn {instance} config={} binary={}",
                    spec.config_digest, spec.binary_digest
                )))
            }
            EffectStep::StopCore { instance, grace_ms } => {
                require_core(&guard)?;
                let stopped = guard
                    .running_core
                    .as_ref()
                    .map(|core| core.instance.clone() == instance.0)
                    .unwrap_or(false);
                if stopped {
                    guard.running_core = None;
                    guard.core_identity = None;
                    Ok(StepEvidence::one(format!(
                        "proc.stop {} grace={grace_ms}ms",
                        instance.0
                    )))
                } else {
                    Ok(StepEvidence::one(format!(
                        "proc.stop {} already-gone",
                        instance.0
                    )))
                }
            }
            EffectStep::CoreApiCall { instance, call } => {
                require_core(&guard)?;
                // Round 56 tried modelling a reload as "the core now runs the last
                // materialized artifact" — and reverted it the same round: identity is
                // what the core REPORTS (`seed_core_identity`), never what we just wrote.
                // A reload that adopts the new identity by assumption is the simulator
                // answering green on the real question ("did the core actually reload?");
                // `stale_live_identity_blocks_a_reload_apply_before_commit` is the judge
                // that bit. A world that models a successful reload seeds the identity.
                let label = match call {
                    CoreCall::Status => "status".to_owned(),
                    CoreCall::Reload => "reload".to_owned(),
                    CoreCall::SelectProxy { group_id, node_id } => {
                        format!("select {group_id} -> {node_id}")
                    }
                    CoreCall::CloseConnection { connection_id } => {
                        format!("close-connection {connection_id}")
                    }
                };
                Ok(StepEvidence::one(format!(
                    "core.call {} {label}",
                    instance.0
                )))
            }
            EffectStep::NetApply { plan } => {
                let txn = format!("net-{:08x}", stable_hash(&plan.summary));
                guard.net_txn = Some(txn.clone());
                Ok(StepEvidence::one(format!(
                    "net.apply {txn} {}",
                    plan.summary
                )))
            }
            EffectStep::NetRevert { txn_id } => {
                guard.net_txn = None;
                Ok(StepEvidence::one(format!("net.revert {}", txn_id.0)))
            }
            EffectStep::Probe { probe, deadline_ms } => {
                if let Some(reason) = guard.fail_next_probe.take() {
                    return Err(StepFailure::new(
                        "probe-failed",
                        format!("{:?} probe failed: {reason}", probe.kind),
                        true,
                    ));
                }
                require_core(&guard)?;
                let detail = match probe.kind {
                    ProbeKind::ApiReady => match &guard.running_core {
                        Some(core) => format!("api.ready {}", core.instance),
                        None => "api.ready assumed".to_owned(),
                    },
                    ProbeKind::ConfigIdentity => match (&guard.core_identity, &probe.target) {
                        (Some(live), Some(expected)) if live != expected => {
                            return Err(StepFailure::new(
                                "identity-mismatch",
                                format!("live core reports {live} but the plan expects {expected}"),
                                false,
                            ))
                        }
                        (Some(live), Some(expected)) => {
                            format!("identity confirmed {expected} (live={live})")
                        }
                        (None, Some(target)) => {
                            // Round 57 (falsify M5): a probe that *adopts* the plan's
                            // expectation when the core reports nothing is the simulator
                            // grading its own homework — R55 §7 in a new spot. An honest
                            // core always reports; silence is a failure, not agreement.
                            let _ = target;
                            return Err(StepFailure::new(
                                "identity-unreported",
                                "the core reports no identity; the probe refuses to adopt                                  the plan's expectation",
                                false,
                            ));
                        }
                        (_, None) => "identity unasserted".to_owned(),
                    },
                    ProbeKind::InboundListening => match &guard.running_core {
                        Some(core) => format!("listen {}", core.instance),
                        None => "listen assumed".to_owned(),
                    },
                    ProbeKind::DirectConnectivity | ProbeKind::ProxyConnectivity => {
                        format!("connectivity {:?} ok", probe.kind)
                    }
                };
                let elapsed = guard.slow_next_probe_ms.take().unwrap_or(0);
                Ok(StepEvidence::took(
                    format!(
                        "probe.ok {:?} deadline={}ms took={elapsed}ms {detail}",
                        probe.kind, deadline_ms
                    ),
                    elapsed,
                ))
            }
            EffectStep::MarkSnapshot { snapshot_id } => Ok(StepEvidence::one(format!(
                "snapshot.mark {} phase={:?}",
                snapshot_id.0, phase
            ))),
            EffectStep::CommitRevision { revision } => Ok(StepEvidence::one(format!(
                "revision.commit {revision} phase={phase:?}"
            ))),
        }
    }

    fn undo_step(&self, phase: ApplyPhase, step: &EffectStep) -> Result<StepEvidence, StepFailure> {
        let mut guard = self.world.lock().map_err(|_| {
            StepFailure::new("runtime-poisoned", "simulated runtime lock poisoned", false)
        })?;

        match step {
            // Undo semantics that matter for the world model.
            EffectStep::NetRevert { txn_id } => {
                guard.net_txn = None;
                Ok(StepEvidence::one(format!("net.revert {}", txn_id.0)))
            }
            EffectStep::StopCore { instance, .. } => {
                if guard
                    .running_core
                    .as_ref()
                    .map(|core| core.instance == instance.0)
                    .unwrap_or(false)
                {
                    guard.running_core = None;
                    guard.core_identity = None;
                }
                Ok(StepEvidence::one(format!("compensate.stop {}", instance.0)))
            }
            EffectStep::SpawnCore { .. } => {
                guard.running_core = None;
                guard.core_identity = None;
                Ok(StepEvidence::one("compensate.kill-new-core".to_owned()))
            }
            EffectStep::CoreApiCall { instance, .. } => {
                if guard.running_core.is_none() && guard.enforce_preconditions {
                    return Err(StepFailure::new(
                        "no-running-core",
                        format!("cannot compensate onto {} with no live core", instance.0),
                        false,
                    ));
                }
                Ok(StepEvidence::one(format!(
                    "compensate.restore-previous-config {}",
                    instance.0
                )))
            }
            EffectStep::DbTxn { .. } => {
                Ok(StepEvidence::one("compensate.db-txn-skipped".to_owned()))
            }
            EffectStep::MaterializeArtifact { at, .. } => {
                guard.materialized.remove(at);
                Ok(StepEvidence::one(format!("compensate.unlink {at}")))
            }
            other => Ok(StepEvidence::one(format!(
                "compensate.{} phase={:?}",
                step_kind_name(other),
                phase
            ))),
        }
    }
}

/// Small deterministic string hash. Avoids `DefaultHasher` so results do not depend
/// on `std` hashing implementation details across releases.
pub(crate) fn stable_hash(value: &str) -> u32 {
    let mut hash: u32 = 0x811c_9dc5;
    for byte in value.as_bytes() {
        hash ^= u32::from(*byte);
        hash = hash.wrapping_mul(0x0100_0193);
    }
    hash
}

#[cfg(test)]
mod tests {
    use super::*;
    use caly_plan::{
        CoreKind, CoreSpec, DbOp, FileMode, InstanceId, NetTxnId, NetworkPlan, ProbeKind, ProbeSpec,
    };
    use caly_storage::ApplyPhase;

    fn spawn(digest: &str) -> EffectStep {
        EffectStep::SpawnCore {
            spec: CoreSpec {
                kind: CoreKind::Mihomo,
                binary_digest: "sha:bin".to_owned(),
                config_digest: digest.to_owned(),
            },
        }
    }

    fn probe(kind: ProbeKind, target: Option<String>) -> EffectStep {
        EffectStep::Probe {
            probe: ProbeSpec { kind, target },
            deadline_ms: 100,
        }
    }

    fn net(summary: &str) -> EffectStep {
        EffectStep::NetApply {
            plan: NetworkPlan {
                summary: summary.to_owned(),
                requires_privilege: true,
            },
        }
    }

    #[test]
    fn spawning_a_core_adopts_the_identity_of_the_config_it_was_handed() {
        let runtime = SimulatedRuntime::new();
        runtime
            .execute(ApplyPhase::Cutover, &spawn("sha:art"))
            .expect("spawn");
        let world = runtime.snapshot();
        assert!(world.running_core.is_some());
        assert_eq!(world.core_identity.as_deref(), Some("sha:art"));

        // An identity probe asking for the same config is therefore a confirmation, not a guess.
        runtime
            .execute(
                ApplyPhase::Finalize,
                &probe(ProbeKind::ConfigIdentity, Some("sha:art".to_owned())),
            )
            .expect("identity must match the spawned config");
    }

    #[test]
    fn a_stale_core_identity_fails_the_probe() {
        let runtime = SimulatedRuntime::new();
        runtime.seed_core_identity("sha:old".to_owned());
        let error = runtime
            .execute(
                ApplyPhase::Finalize,
                &probe(ProbeKind::ConfigIdentity, Some("sha:new".to_owned())),
            )
            .expect_err("a live core with a different config must be reported");
        assert_eq!(error.code, "identity-mismatch");
        assert!(error.summary.contains("sha:old"), "{}", error.summary);
    }

    #[test]
    fn net_effects_are_tracked_and_reverted() {
        let runtime = SimulatedRuntime::new();
        runtime
            .execute(ApplyPhase::Cutover, &net("configure TUN"))
            .expect("net apply");
        let after_apply = runtime.snapshot();
        assert!(after_apply.net_txn.is_some());

        // The same plan summary must derive the same txn id: the world is a function of inputs.
        let other = SimulatedRuntime::new();
        other
            .execute(ApplyPhase::Cutover, &net("configure TUN"))
            .expect("net apply");
        assert_eq!(other.snapshot().net_txn, after_apply.net_txn);

        runtime
            .execute(
                ApplyPhase::Cutover,
                &EffectStep::NetRevert {
                    txn_id: NetTxnId("net-1".to_owned()),
                },
            )
            .expect("net revert");
        assert!(runtime.snapshot().net_txn.is_none());
    }

    #[test]
    fn db_transactions_apply_puts_and_deletes() {
        let runtime = SimulatedRuntime::new();
        runtime
            .execute(
                ApplyPhase::Prepare,
                &EffectStep::DbTxn {
                    ops: vec![
                        DbOp::Put {
                            table: "profiles".to_owned(),
                            key: "p1".to_owned(),
                            value: "rev-1".to_owned(),
                        },
                        DbOp::Put {
                            table: "profiles".to_owned(),
                            key: "p2".to_owned(),
                            value: "rev-2".to_owned(),
                        },
                        DbOp::Delete {
                            table: "profiles".to_owned(),
                            key: "p1".to_owned(),
                        },
                    ],
                },
            )
            .expect("db txn");

        let world = runtime.snapshot();
        assert_eq!(world.db, vec!["profiles/p2=rev-2".to_owned()]);
        assert_eq!(world.log.len(), 3, "each op is one observable effect");
    }

    #[test]
    fn materialize_requires_the_object_to_exist_first() {
        let runtime = SimulatedRuntime::new();
        let error = runtime
            .execute(
                ApplyPhase::Prepare,
                &EffectStep::MaterializeArtifact {
                    digest: "sha:missing".to_owned(),
                    at: "runtime/p1/config.yaml".to_owned(),
                    mode: FileMode::ReadOnlyArtifact,
                },
            )
            .expect_err("materializing an unwritten object must fail");
        assert_eq!(error.code, "object-not-found");
        assert!(error.retryable, "the write may simply not have landed yet");
    }

    #[test]
    fn a_failed_probe_leaves_the_world_unchanged_and_is_consumed_once() {
        let runtime = SimulatedRuntime::new();
        runtime
            .execute(ApplyPhase::Cutover, &spawn("sha:art"))
            .expect("spawn");
        let before = runtime.snapshot();

        runtime.fail_next_probe("core did not come up");
        let error = runtime
            .execute(ApplyPhase::Finalize, &probe(ProbeKind::ApiReady, None))
            .expect_err("armed probe failure must fire");
        assert_eq!(error.code, "probe-failed");
        assert_eq!(
            runtime.snapshot().log,
            before.log,
            "a failed step records nothing"
        );

        runtime
            .execute(ApplyPhase::Finalize, &probe(ProbeKind::ApiReady, None))
            .expect("the injection is one-shot");
    }

    #[test]
    fn stopping_a_core_clears_both_runtime_markers() {
        let runtime = SimulatedRuntime::new();
        runtime
            .execute(ApplyPhase::Cutover, &spawn("sha:art"))
            .expect("spawn");
        let instance = runtime
            .snapshot()
            .running_core
            .expect("core")
            .instance
            .clone();
        runtime
            .execute(
                ApplyPhase::Cutover,
                &EffectStep::StopCore {
                    instance: InstanceId(instance),
                    grace_ms: 100,
                },
            )
            .expect("stop");
        let world = runtime.snapshot();
        assert!(world.running_core.is_none());
        assert!(
            world.core_identity.is_none(),
            "a stopped core reports no identity"
        );
    }

    #[test]
    fn precondition_enforcement_turns_an_empty_world_into_a_failure() {
        let lenient = SimulatedRuntime::new();
        assert!(lenient
            .execute(
                ApplyPhase::Cutover,
                &EffectStep::CoreApiCall {
                    instance: InstanceId("core-1".to_owned()),
                    call: caly_plan::CoreCall::Reload,
                },
            )
            .is_ok());

        let strict = SimulatedRuntime::new();
        strict.set_enforce_preconditions(true);
        let error = strict
            .execute(
                ApplyPhase::Cutover,
                &EffectStep::CoreApiCall {
                    instance: InstanceId("core-1".to_owned()),
                    call: caly_plan::CoreCall::Reload,
                },
            )
            .expect_err("a strict world must refuse to reload nothing");
        assert_eq!(error.code, "no-running-core");
    }

    #[test]
    fn instance_identifiers_are_derived_not_random() {
        let first = SimulatedRuntime::new();
        let second = SimulatedRuntime::new();
        for runtime in [&first, &second] {
            runtime
                .execute(
                    ApplyPhase::Cutover,
                    &net("configure TUN + route ownership for mihomo"),
                )
                .expect("net");
            runtime
                .execute(ApplyPhase::Cutover, &spawn("sha:same"))
                .expect("spawn");
        }
        assert_eq!(first.snapshot(), second.snapshot());
    }
}
