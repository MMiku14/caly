use caly_api::EstimatedImpact;

use crate::command::{Command, CommandKind};
use crate::coordinator::{default_lock_set_for_command, CoordinationPlan};

#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub enum DispatchClass {
    ReadOnlyLike,
    Mutating,
    Privileged,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct DispatchDecision {
    pub class: DispatchClass,
    pub estimated_impact: EstimatedImpact,
    pub plan: CoordinationPlan,
}

pub fn classify_command(command: &Command) -> DispatchDecision {
    let (class, estimated_impact) = match &command.kind {
        CommandKind::DiagnosticsBundle => (DispatchClass::ReadOnlyLike, EstimatedImpact::ReadOnly),
        // A cycle reclaims unreferenced bytes: it mutates the store, and it must not be classified as
        // read-only, because `estimated_impact` is what tells a caller that the submission changed
        // something. `ReadOnly` as the *impact* is still the truth for the runtime: no core is told to
        // reload or restart by a collection. Same split as `DnsFlushCache`, which also mutates and
        // leaves the running configuration alone.
        CommandKind::StorageGc { .. } => (DispatchClass::Mutating, EstimatedImpact::ReadOnly),
        CommandKind::DnsFlushCache => (DispatchClass::Mutating, EstimatedImpact::ReadOnly),
        CommandKind::RuntimeCloseConnection { .. } => {
            (DispatchClass::Mutating, EstimatedImpact::ReadOnly)
        }
        CommandKind::ProxyTestDelay { .. } => {
            (DispatchClass::ReadOnlyLike, EstimatedImpact::ReadOnly)
        }
        CommandKind::AutomationPatch(_) => (DispatchClass::Mutating, EstimatedImpact::ReadOnly),
        CommandKind::NetworkRepair => (
            DispatchClass::Privileged,
            EstimatedImpact::PrivilegedNetworkChange,
        ),
        CommandKind::SystemShutdown => (DispatchClass::Privileged, EstimatedImpact::Restart),
        CommandKind::ProfileApply(_) => (DispatchClass::Mutating, EstimatedImpact::Restart),
        CommandKind::ProfileRollback(_) => (DispatchClass::Mutating, EstimatedImpact::Restart),
        CommandKind::SourceUpdate { .. } => (DispatchClass::Mutating, EstimatedImpact::ReadOnly),
        CommandKind::ProxySelect { .. } => (DispatchClass::Mutating, EstimatedImpact::Reload),
    };

    DispatchDecision {
        class,
        estimated_impact,
        plan: CoordinationPlan {
            apply_plan: None,
            effect_plan: None,
            lock_set: default_lock_set_for_command(command),
        },
    }
}
