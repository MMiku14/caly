use crate::job::{JobEvent, JobRecord};

#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub struct JobEventRetentionPolicy {
    pub max_events: usize,
}

impl JobEventRetentionPolicy {
    pub const fn bounded(max_events: usize) -> Self {
        Self { max_events }
    }
}

impl Default for JobEventRetentionPolicy {
    fn default() -> Self {
        Self { max_events: 128 }
    }
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct JobEventWindow {
    pub next_index: u64,
    pub retained_from_index: u64,
    pub reset_required: bool,
    /// Index of `events[0]`, i.e. where this slice actually starts.
    ///
    /// It is not `retained_from_index` and it is not `from_event_index + 1`: the returned slice
    /// begins at the *later* of the two, so a reader that wants to number these events (a stream
    /// frame's `seq`, a paged reply's resume cursor) used to re-derive the maximum itself
    /// (`docs/ONBOARDING_NOTES.md §4.54`). Carrying it here makes the resume rule have exactly one
    /// home. `first_index == next_index` means the window is empty from this reader's point of view.
    pub first_index: u64,
    pub events: Vec<JobEvent>,
}

pub fn slice_job_events(
    record: &JobRecord,
    from_event_index: Option<u64>,
    policy: JobEventRetentionPolicy,
) -> JobEventWindow {
    let total = record.events.len();
    let retained_from_index = total.saturating_sub(policy.max_events) as u64;
    let next_index = total as u64;

    if let Some(from) = from_event_index {
        if from.saturating_add(1) < retained_from_index {
            return JobEventWindow {
                next_index,
                retained_from_index,
                reset_required: true,
                first_index: retained_from_index,
                events: Vec::new(),
            };
        }
    }

    let requested_start = from_event_index
        .map(|index| index.saturating_add(1) as usize)
        .unwrap_or(0);
    let retained_start = retained_from_index as usize;
    let start = requested_start.max(retained_start);

    JobEventWindow {
        next_index,
        retained_from_index,
        reset_required: false,
        first_index: start as u64,
        events: record.events.iter().skip(start).cloned().collect(),
    }
}

/// How much of a job's window one reply may carry.
///
/// Retention caps *how many* events a job keeps; it does not cap how long each of them is, and the two
/// are different questions: the window a job *has* is what a support bundle has to see, while the page
/// a caller *receives* is bounded so that a query never turns into an oversized inline IPC frame
/// (`RFC-0002 §9`, `§11.4`). The bound is therefore applied on the way out, not smuggled into the
/// retention policy.
///
/// There is deliberately no `Default`: the response bound belongs to whoever answers the query, and a
/// second copy of "the usual size" inside the engine is a number the daemon would have to remember to
/// agree with. `caly-daemon::paging` owns the defaults and the caps; the engine only enforces what it
/// is handed.
#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub struct JobEventPagePolicy {
    /// `0` means "no line limit"; the byte cap still applies. A caller asking for everything gets
    /// everything up to `max_bytes`, rather than a magic number to look up first.
    pub max_lines: usize,
    /// A single line larger than this is still returned — see `page_job_events`.
    pub max_bytes: u64,
}

impl JobEventPagePolicy {
    pub const fn bounded(max_lines: usize, max_bytes: u64) -> Self {
        Self {
            max_lines,
            max_bytes,
        }
    }
}

/// A bounded page of rendered job event lines.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct JobEventPage {
    pub lines: Vec<String>,
    /// Bytes of `lines` joined by newlines — what a caller actually pays for on the wire.
    pub byte_len: u64,
    /// Index `lines[0]` carries, i.e. the window's start for this caller.
    pub first_index: u64,
    /// Put this straight back into `from_event_index` to read what is left — it is the *last index
    /// this page returned*, because the request cursor is exclusive, and naming it after the field it
    /// fills is what stops a client from off-by-one-ing its way through the log.
    ///
    /// `None` means the page ran to `next_index`: nothing was left out. A caller that loops on
    /// `Some(..)` therefore terminates, and a caller that ignores the field entirely still sees the
    /// whole window. A `reset_required` window reports `None` too — the answer to a stale cursor is
    /// "re-take from the start" (`RFC-0002 §10.2`), not "continue from a position we cannot honour".
    /// Deliberately the only truncation signal here: two fields meaning "there is more" is two fields
    /// that can disagree.
    pub next_from_event_index: Option<u64>,
    /// The window's `next_index`, echoed so a caller can tell "nothing left" from "nothing retained".
    pub next_index: u64,
}

impl JobEventPage {
    pub fn is_truncated(&self) -> bool {
        self.next_from_event_index.is_some()
    }

    pub fn line_count(&self) -> usize {
        self.lines.len()
    }
}

/// Render and bound a window, oldest first, with a progress guarantee.
///
/// Two rules are load-bearing:
///
/// 1. The first line is emitted even when it alone exceeds `max_bytes`. A page that returns nothing
///    while lines remain is a cursor that can never advance, which is a livelock the caller cannot
///    recover from; one oversized line is a display problem instead.
/// 2. `next_from_event_index` is the last index returned, set only when the window actually has more.
///    A request for fewer lines than exist is truncation; a request that happens to cover everything
///    is not.
pub fn page_job_events(window: &JobEventWindow, policy: JobEventPagePolicy) -> JobEventPage {
    let mut lines = Vec::new();
    let mut byte_len = 0u64;
    let mut consumed = 0usize;

    for event in &window.events {
        if policy.max_lines != 0 && lines.len() >= policy.max_lines {
            break;
        }
        let text = crate::bundle::render_job_event(event);
        let cost = if lines.is_empty() {
            text.len() as u64
        } else {
            text.len() as u64 + 1 // the newline a caller sees between lines
        };
        if !lines.is_empty() && byte_len + cost > policy.max_bytes {
            break;
        }
        byte_len += cost;
        lines.push(text);
        consumed += 1;
    }

    let first_index = window.first_index;
    let taken_to = first_index.saturating_add(consumed as u64);
    let next_from_event_index = if consumed > 0 && taken_to < window.next_index {
        Some(first_index + consumed as u64 - 1)
    } else {
        None
    };

    JobEventPage {
        lines,
        byte_len,
        first_index,
        next_from_event_index,
        next_index: window.next_index,
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::job::JobState;
    use caly_api::JobId;

    fn job_with(events: usize) -> JobRecord {
        JobRecord {
            id: JobId(1),
            state: JobState::Running,
            revision: 0,
            events: (0..events)
                .map(|index| JobEvent::Stage {
                    stage: format!("step-{index}"),
                    pct: Some(50),
                })
                .collect(),
        }
    }

    /// The reset branch `slice_job_events` has a `ReadJobEvents`-reachable cursor but no fixture big
    /// enough to hit it through a real job, so the arithmetic is pinned directly.
    #[test]
    fn a_cursor_older_than_the_window_earns_a_reset_not_an_empty_list() {
        let record = job_with(200);
        let window = slice_job_events(&record, Some(10), JobEventRetentionPolicy::bounded(64));
        assert!(window.reset_required, "{window:?}");
        assert!(window.events.is_empty(), "a reset must not half-answer");
        assert_eq!(window.next_index, 200);
        assert_eq!(window.retained_from_index, 136, "200 total, 64 retained");
        // A reset answers "start over from here", and here is the oldest line that still exists.
        assert_eq!(window.first_index, 136, "{window:?}");
    }

    #[test]
    fn a_cursor_inside_the_window_resumes_and_reports_no_reset() {
        let record = job_with(200);
        let window = slice_job_events(&record, Some(150), JobEventRetentionPolicy::bounded(64));
        assert!(!window.reset_required, "{window:?}");
        assert_eq!(window.events.len(), 49, "151..=199");
        assert_eq!(
            window.first_index, 151,
            "the caller's cursor wins inside the window"
        );
        assert_eq!(
            window.events.last().map(|_| window.first_index + 49),
            Some(window.next_index),
            "first_index + len must land exactly on next_index"
        );
        assert_eq!(
            window.events.first(),
            Some(&JobEvent::Stage {
                stage: "step-151".to_owned(),
                pct: Some(50)
            }),
            "from_event_index is exclusive"
        );
    }

    /// `first_index` is what a paged reader resumes from, so it has to be *this slice's* start even
    /// when the retained window, not the caller, decided it.
    #[test]
    fn first_index_names_the_line_the_slice_actually_starts_with() {
        let record = job_with(200);
        // No cursor at all: retention decides where the slice starts, and `first_index` is the
        // line number a reader has to attach to what it gets back.
        let window = slice_job_events(&record, None, JobEventRetentionPolicy::bounded(64));
        assert_eq!(window.first_index, 136, "{window:?}");
        assert_eq!(
            window.events.first(),
            Some(&JobEvent::Stage {
                stage: "step-136".to_owned(),
                pct: Some(50)
            }),
            "`first_index` must be the index of *this* event, not of the one above it"
        );
        // A cursor older than the window is a reset, and a reset still names the oldest live line
        // so a reader that ignores the flag cannot silently number from zero.
        let window = slice_job_events(&record, Some(0), JobEventRetentionPolicy::bounded(64));
        assert!(window.reset_required, "{window:?}");
        assert_eq!(window.first_index, 136, "{window:?}");
        // Small job, nothing dropped: the caller's cursor decides.
        let small = job_with(6);
        let window = slice_job_events(&small, Some(4), JobEventRetentionPolicy::bounded(64));
        assert_eq!(
            (window.first_index, window.events.len()),
            (5, 1),
            "{window:?}"
        );
        // A job with no events at all starts and ends at zero.
        let empty = job_with(0);
        let window = slice_job_events(&empty, None, JobEventRetentionPolicy::bounded(64));
        assert_eq!((window.first_index, window.next_index), (0, 0));
    }

    #[test]
    fn a_cursor_at_the_end_is_empty_but_not_a_reset() {
        let record = job_with(8);
        let window = slice_job_events(&record, Some(7), JobEventRetentionPolicy::bounded(64));
        assert!(window.events.is_empty(), "{window:?}");
        assert!(!window.reset_required, "{window:?}");
        // No events at all: the window is trivially retained from zero.
        let empty = job_with(0);
        let window = slice_job_events(&empty, None, JobEventRetentionPolicy::bounded(64));
        assert_eq!((window.next_index, window.retained_from_index), (0, 0));
        assert_eq!(window.first_index, 0);
        assert!(window.events.is_empty() && !window.reset_required);
    }

    fn record_with(events: Vec<JobEvent>) -> JobRecord {
        JobRecord {
            id: JobId(2),
            state: JobState::Running,
            revision: 0,
            events,
        }
    }

    fn window_of(record: &JobRecord, from: Option<u64>, retained: usize) -> JobEventWindow {
        slice_job_events(record, from, JobEventRetentionPolicy::bounded(retained))
    }

    #[test]
    fn a_page_hands_back_the_cursor_that_continues_it_exactly() {
        let record = job_with(10);
        let policy = JobEventPagePolicy::bounded(4, 64 * 1024);
        let mut pages = Vec::new();
        let mut cursor = None;
        let mut seen = Vec::new();

        for _ in 0..10 {
            let window = window_of(&record, cursor, 128);
            let page = page_job_events(&window, policy);
            assert_eq!(
                page.byte_len,
                page.lines.join("\n").len() as u64,
                "{page:?}"
            );
            seen.extend(page.lines.iter().cloned());
            let stop = !page.is_truncated();
            pages.push(page.lines.len());
            if stop {
                break;
            }
            cursor = page.next_from_event_index;
        }

        assert_eq!(pages, vec![4, 4, 2], "{pages:?}");
        assert_eq!(
            seen,
            (0..10)
                .map(|index| format!("[stage 50%] step-{index}"))
                .collect::<Vec<_>>(),
            "paging must neither repeat nor skip a line"
        );
    }

    /// A page that returns nothing while lines remain is a cursor that cannot advance: the caller
    /// loops forever or gives up. One oversized line is merely ugly, so it wins.
    #[test]
    fn one_line_beyond_the_byte_cap_is_still_returned_and_says_so() {
        let huge = "x".repeat(1024);
        let record = record_with(vec![
            JobEvent::Log {
                level: "info".to_owned(),
                message: huge.clone(),
            },
            JobEvent::Log {
                level: "info".to_owned(),
                message: "after".to_owned(),
            },
        ]);
        let window = window_of(&record, None, 128);
        let page = page_job_events(&window, JobEventPagePolicy::bounded(64, 32));
        assert_eq!(page.lines.len(), 1, "{page:?}");
        assert!(page.lines[0].contains(&huge));
        assert_eq!(
            page.next_from_event_index,
            Some(0),
            "the caller resumed past the line it was given, not onto it"
        );
        // …and continuing from that cursor does reach the next line, so the loop makes progress.
        let rest = page_job_events(&window_of(&record, page.next_from_event_index, 128), {
            JobEventPagePolicy::bounded(64, 32)
        });
        assert_eq!(rest.lines, vec!["[log:info] after".to_owned()], "{rest:?}");
        assert!(!rest.is_truncated());
    }

    #[test]
    fn a_reset_window_pages_to_nothing_instead_of_to_a_position_it_cannot_honour() {
        let record = job_with(200);
        // Cursor 10 is long gone; retention starts at 136.
        let window = window_of(&record, Some(10), 64);
        assert!(window.reset_required, "{window:?}");
        let page = page_job_events(&window, JobEventPagePolicy::bounded(8, 64 * 1024));
        assert!(page.lines.is_empty(), "{page:?}");
        assert!(
            page.next_from_event_index.is_none(),
            "a stale cursor is answered by `reset_required`, not by a fake resume position: {page:?}"
        );
        assert_eq!((page.first_index, page.next_index), (136, 200));
    }

    #[test]
    fn a_page_big_enough_for_the_window_is_not_reported_as_truncated() {
        let record = job_with(10);
        let window = window_of(&record, None, 128);
        let page = page_job_events(&window, JobEventPagePolicy::bounded(512, 1024 * 1024));
        assert_eq!(page.lines.len(), 10);
        assert!(!page.is_truncated(), "{page:?}");
        // `max_lines == 0` is the documented "no line limit" convention, not "no lines".
        let unlimited = page_job_events(&window, JobEventPagePolicy::bounded(0, 1024 * 1024));
        assert_eq!(unlimited.lines.len(), 10, "{unlimited:?}");
        assert!(!unlimited.is_truncated());
        // An empty window is not truncation either — there is simply nothing there.
        let empty = record_with(Vec::new());
        let page = page_job_events(
            &window_of(&empty, None, 128),
            JobEventPagePolicy::bounded(4, 32),
        );
        assert!(page.lines.is_empty() && !page.is_truncated(), "{page:?}");
    }
}
