use caly_api::{ApiError, ErrorCategory, ErrorCode, EstimatedImpact};

use crate::apply::{plan_apply_request_with_sources, ApplyWorkflowResult};
use crate::executor::{
    CursorRefusal, EffectCursor, EffectExecution, ExecutionPolicy, ExecutionStatus,
};
use crate::job::{JobEvent, JobOutcome};
use crate::recovery::PersistedApplyExecution;
use crate::run_limits::{RefusalKind, RunLimits};
use crate::service::EngineHandle;
use crate::state::QueuedCommand;
use caly_storage::{ApplyJournalRecord, ApplyPhase};

#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub struct WorkerPolicy {
    pub max_cycles_per_drain: usize,
}

impl WorkerPolicy {
    pub const fn bounded(max_cycles_per_drain: usize) -> Self {
        Self {
            max_cycles_per_drain,
        }
    }
}

impl Default for WorkerPolicy {
    fn default() -> Self {
        Self {
            max_cycles_per_drain: 64,
        }
    }
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct WorkerCycleResult {
    pub job_id: u64,
    pub outcome: JobOutcome,
    pub impact: EstimatedImpact,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct WorkerDrainReport {
    pub cycles: usize,
    pub exhausted_queue: bool,
    pub limit_hit: bool,
    pub results: Vec<WorkerCycleResult>,
}

pub fn consume_one_skeleton(handle: &EngineHandle) -> Result<Option<WorkerCycleResult>, String> {
    let mut queued = handle.poll_next()?;
    if queued.is_none() {
        // Nothing a caller queued is runnable, which is the same fact as "the engine is idle" here --
        // so this is the one place `ADR-038 §13.2`'s automatic collector is considered. It cannot
        // interleave with a caller's work, and it is off until an operator files the role-gated
        // automation patch that turns it on.
        if handle.idle_gc_tick()? {
            queued = handle.poll_next()?;
        }
    }
    let Some(queued) = queued else {
        return Ok(None);
    };

    handle.mark_running(&queued)?;

    let result = match &queued.command.kind {
        crate::command::CommandKind::ProfileApply(request) => {
            execute_profile_apply(handle, &queued, request.clone())?
        }
        crate::command::CommandKind::ProfileRollback(request) => {
            execute_profile_rollback(handle, &queued, request.clone())?
        }
        crate::command::CommandKind::DiagnosticsBundle => {
            // `docs/engineering/STORAGE_RECOVERY_EXECUTION_PLAN.md §9.3`. This used to append the single line
            // "support bundle skeleton generated" and call the job done: the accepted command, the
            // follow projection and the contract predicate all passed, while nothing was exported.
            crate::bundle::run_bundle_job(handle, &queued)?
        }
        crate::command::CommandKind::StorageGc {
            grace_period_ms,
            max_deletions,
        } => {
            // One cycle, from the plan to the sweep, with the record kept either way. A refusal is
            // reported as a failed job: an operator who asked to reclaim space and was refused for
            // safety must not see a green row, and `§13.2`'s gate is the whole point of it.
            let bounds = crate::gc_plan::GcPlanBounds {
                grace_period_ms: *grace_period_ms,
                max_deletions: *max_deletions,
            };
            match bounds
                .resolve()
                .map_err(|refusal| refusal.message())
                .and_then(|bounds| handle.storage_gc_collect(bounds, Some(queued.job_id)))
            {
                Ok(record) => {
                    let outcome = if record.refused.is_some() {
                        JobOutcome::Failed
                    } else {
                        JobOutcome::Succeeded
                    };
                    handle.append_job_event(
                        queued.job_id,
                        JobEvent::Log {
                            level: if outcome == JobOutcome::Failed {
                                "warn".to_owned()
                            } else {
                                "info".to_owned()
                            },
                            message: record.summary_line(),
                        },
                    )?;
                    if let Some(refusal) = record.refused.clone() {
                        handle.append_job_event(
                            queued.job_id,
                            JobEvent::Warning { message: refusal },
                        )?;
                    }
                    handle.mark_finished(&queued, outcome)?;
                    WorkerCycleResult {
                        job_id: queued.job_id.0,
                        outcome,
                        impact: EstimatedImpact::ReadOnly,
                    }
                }
                Err(problem) => {
                    handle.append_job_event(
                        queued.job_id,
                        JobEvent::Warning {
                            message: format!("storage gc could not run: {problem}"),
                        },
                    )?;
                    handle.mark_finished(&queued, JobOutcome::Failed)?;
                    WorkerCycleResult {
                        job_id: queued.job_id.0,
                        outcome: JobOutcome::Failed,
                        impact: EstimatedImpact::ReadOnly,
                    }
                }
            }
        }
        crate::command::CommandKind::ProxySelect { group_id, node_id } => {
            handle.append_job_event(
                queued.job_id,
                JobEvent::Stage {
                    stage: format!("runtime.select {} -> {}", group_id, node_id),
                    pct: Some(100),
                },
            )?;
            handle.mark_finished(&queued, JobOutcome::Succeeded)?;
            WorkerCycleResult {
                job_id: queued.job_id.0,
                outcome: JobOutcome::Succeeded,
                impact: EstimatedImpact::Reload,
            }
        }
        crate::command::CommandKind::ProxyTestDelay { node_ids } => {
            handle.append_job_event(
                queued.job_id,
                JobEvent::Log {
                    level: "info".to_owned(),
                    message: format!("delay test requested for nodes={:?}", node_ids),
                },
            )?;
            handle.mark_finished(&queued, JobOutcome::Succeeded)?;
            WorkerCycleResult {
                job_id: queued.job_id.0,
                outcome: JobOutcome::Succeeded,
                impact: EstimatedImpact::ReadOnly,
            }
        }
        crate::command::CommandKind::DnsFlushCache => {
            handle.append_job_event(
                queued.job_id,
                JobEvent::Stage {
                    stage: "dns.flush-cache".to_owned(),
                    pct: Some(100),
                },
            )?;
            handle.mark_finished(&queued, JobOutcome::Succeeded)?;
            WorkerCycleResult {
                job_id: queued.job_id.0,
                outcome: JobOutcome::Succeeded,
                impact: EstimatedImpact::ReadOnly,
            }
        }
        crate::command::CommandKind::AutomationPatch(request) => {
            handle.set_automation_job(request)?;
            handle.append_job_event(
                queued.job_id,
                JobEvent::Stage {
                    stage: format!("automation.patch {} -> {}", request.job_id, request.enabled),
                    pct: Some(100),
                },
            )?;
            handle.push_event(
                crate::event::EventKind::DeploymentChanged,
                Some(queued.command.id.0.clone()),
                crate::event::EventPayload::DeploymentChanged {
                    summary: format!(
                        "automation job {} patched to {}",
                        request.job_id, request.enabled
                    ),
                },
            )?;
            handle.mark_finished(&queued, JobOutcome::Succeeded)?;
            WorkerCycleResult {
                job_id: queued.job_id.0,
                outcome: JobOutcome::Succeeded,
                impact: EstimatedImpact::ReadOnly,
            }
        }
        crate::command::CommandKind::RuntimeCloseConnection { connection_id } => {
            handle.append_job_event(
                queued.job_id,
                JobEvent::Stage {
                    stage: format!("runtime.close-connection {}", connection_id),
                    pct: Some(100),
                },
            )?;
            handle.mark_finished(&queued, JobOutcome::Succeeded)?;
            WorkerCycleResult {
                job_id: queued.job_id.0,
                outcome: JobOutcome::Succeeded,
                impact: EstimatedImpact::ReadOnly,
            }
        }
        crate::command::CommandKind::SourceUpdate { source_id } => {
            // Source updates are real work now: explicit locator lookup, bounded fetch, pure
            // decode/normalize, then raw-body CAS. A missing composition-root worker or a failed
            // parse is a failed job, never the old green "scheduled" skeleton.
            match handle.source_update(source_id, &queued.command.context) {
                Ok(report) => {
                    if let Err(error) = handle.record_source_update(&report) {
                        handle.append_job_event(
                            queued.job_id,
                            JobEvent::Warning {
                                message: format!("source update cache failed: {error}"),
                            },
                        )?;
                        handle.mark_finished(&queued, JobOutcome::Failed)?;
                        return Ok(Some(WorkerCycleResult {
                            job_id: queued.job_id.0,
                            outcome: JobOutcome::Failed,
                            impact: EstimatedImpact::ReadOnly,
                        }));
                    }
                    handle.append_job_event(
                        queued.job_id,
                        JobEvent::Stage {
                            stage: format!("source.fetch {}", source_id),
                            pct: Some(33),
                        },
                    )?;
                    handle.append_job_event(
                        queued.job_id,
                        JobEvent::Stage {
                            stage: format!(
                                "source.normalize {} nodes",
                                report.normalized.nodes.len()
                            ),
                            pct: Some(66),
                        },
                    )?;
                    for diagnostic in report.diagnostics {
                        handle.append_job_event(
                            queued.job_id,
                            JobEvent::Warning {
                                message: diagnostic.summary,
                            },
                        )?;
                    }
                    handle.append_job_event(
                        queued.job_id,
                        JobEvent::Log {
                            level: "info".to_owned(),
                            message: format!(
                                "source {} updated: raw_digest={} bytes={} nodes={} raw_reused={}",
                                source_id,
                                report.raw.content_digest.0,
                                report.raw.bytes_len,
                                report.normalized.nodes.len(),
                                report.reused_raw_body
                            ),
                        },
                    )?;
                    handle.append_job_event(
                        queued.job_id,
                        JobEvent::Stage {
                            stage: format!("source.cas {}", report.raw_object.digest.0),
                            pct: Some(100),
                        },
                    )?;
                    handle.mark_finished(&queued, JobOutcome::Succeeded)?;
                    WorkerCycleResult {
                        job_id: queued.job_id.0,
                        outcome: JobOutcome::Succeeded,
                        impact: EstimatedImpact::ReadOnly,
                    }
                }
                Err(error) => {
                    handle.append_job_event(
                        queued.job_id,
                        JobEvent::Warning {
                            message: format!("source update failed: {error}"),
                        },
                    )?;
                    handle.mark_finished(&queued, JobOutcome::Failed)?;
                    WorkerCycleResult {
                        job_id: queued.job_id.0,
                        outcome: JobOutcome::Failed,
                        impact: EstimatedImpact::ReadOnly,
                    }
                }
            }
        }
        crate::command::CommandKind::SystemShutdown => {
            handle.push_event(
                crate::event::EventKind::RuntimeChanged,
                Some(queued.command.id.0.clone()),
                crate::event::EventPayload::RuntimeChanged {
                    summary: "system shutdown skeleton path executed".to_owned(),
                },
            )?;
            handle.mark_finished(&queued, JobOutcome::Succeeded)?;
            WorkerCycleResult {
                job_id: queued.job_id.0,
                outcome: JobOutcome::Succeeded,
                impact: EstimatedImpact::Restart,
            }
        }
        crate::command::CommandKind::NetworkRepair => {
            handle.append_job_event(
                queued.job_id,
                JobEvent::Log {
                    level: "info".to_owned(),
                    message: "network repair skeleton path executed".to_owned(),
                },
            )?;
            handle.mark_finished(&queued, JobOutcome::Succeeded)?;
            WorkerCycleResult {
                job_id: queued.job_id.0,
                outcome: JobOutcome::Succeeded,
                impact: EstimatedImpact::PrivilegedNetworkChange,
            }
        }
    };

    Ok(Some(result))
}

// ---- apply / rollback worker cycles ---------------------------------------------------
//
// Restructured on 2026-08-27. `execute_profile_apply` had grown to ~380 lines that interleaved
// three concerns: running the centerline phases, formatting job events, and translating
// failures into public errors. The phases are now separate functions returning
// `Result<_, ApplyFailure>`, and the event + `mark_finished` bookkeeping exists exactly once
// (in `ApplyRun`). The observable behaviour is intentionally unchanged: the same stage names and
// percentages are emitted, because `apply_execution_gate.rs` and the daemon tests assert them.

/// One apply/rollback cycle's reporting surface: the only place that writes job events.
struct ApplyRun<'a> {
    handle: &'a EngineHandle,
    queued: &'a QueuedCommand,
    profile_id: String,
}

impl ApplyRun<'_> {
    /// The store-access limits this command implies (`ADR-036 §2.3`).
    ///
    /// Built once per execution and anchored by whichever clock the engine was given: the deadline is
    /// an absolute instant from here on, not a budget each layer subtracts from on its way down.
    /// If no clock was injected the deadline stays unjudged and is *reported* as such by
    /// `RunLimits::describe` -- the engine never guesses at a caller's time budget
    /// (`docs/history/ONBOARDING_NOTES.md §4.86`).
    fn store_limits(&self) -> crate::run_limits::RunLimits {
        crate::run_limits::RunLimits::for_command(
            &self.queued.command.context,
            self.handle.storage_clock(),
        )
    }
}

/// Why a cycle stopped, plus what should be published about it.
///
/// `error` is boxed deliberately: `ApiError` carries a `Vec` plus several `String`s, and an
/// unboxed field pushed every `Result<_, ApplyFailure>` in this module over clippy's
/// `result_large_err` threshold (11 sites). Boxing keeps the error channel small without
/// touching any public DTO.
struct ApplyFailure {
    error: Box<ApiError>,
    settle: JobOutcome,
    /// How the job settles. `Failed` almost everywhere -- but a refusal that came from the
    /// *caller's* own limits settles as `Cancelled` / `TimedOut` instead, because those two
    /// `JobOutcome` variants exist precisely to say "this row is not a broken deployment"
    /// (`RFC-0006 §5.2`, `ADR-036 §6bis-quinque`: they had no producer before this).
    /// Narrative for `EventKind::RecoveryDecision`.
    recovery: Option<String>,
    /// Narrative for `EventKind::DeploymentChanged`.
    deployment: Option<String>,
    /// Non-fatal job warning, emitted ahead of the failure event.
    warning: Option<String>,
}

impl ApplyFailure {
    /// Override how the job settles. Only a caller-side refusal should ever need this.
    fn with_settlement(mut self, outcome: JobOutcome) -> Self {
        self.settle = outcome;
        self
    }

    fn error_only(error: ApiError) -> Self {
        Self {
            error: Box::new(error),
            settle: JobOutcome::Failed,
            recovery: None,
            deployment: None,
            warning: None,
        }
    }

    fn with_recovery(mut self, summary: impl Into<String>) -> Self {
        self.recovery = Some(summary.into());
        self
    }

    fn with_deployment(mut self, summary: impl Into<String>) -> Self {
        self.deployment = Some(summary.into());
        self
    }

    fn with_warning(mut self, message: impl Into<String>) -> Self {
        self.warning = Some(message.into());
        self
    }

    /// A job-event or bookkeeping write failed. That is an internal fault, not a user error,
    /// and it must not be reported as one.
    fn infrastructure(message: impl Into<String>) -> Self {
        Self::error_only(
            ApiError::new(
                ErrorCode::Internal,
                ErrorCategory::Internal,
                true,
                "apply worker could not record progress",
                caly_common::TraceId::new("unknown"),
            )
            .with_detail(message),
        )
    }
}

impl From<String> for ApplyFailure {
    fn from(message: String) -> Self {
        Self::infrastructure(message)
    }
}

/// Used by the two `Result<_, String>` entry points (`execute_profile_apply` and
/// `execute_profile_rollback`), whose caller `consume_one_skeleton` only understands a string.
/// Any structured reporting has nowhere to go at that point, so the summary is kept verbatim.
impl From<ApplyFailure> for String {
    fn from(failure: ApplyFailure) -> Self {
        match failure.error.detail {
            Some(detail) => format!("{}: {}", failure.error.summary, detail),
            None => failure.error.summary,
        }
    }
}

impl<'a> ApplyRun<'a> {
    fn new(
        handle: &'a EngineHandle,
        queued: &'a QueuedCommand,
        profile_id: impl Into<String>,
    ) -> Self {
        Self {
            handle,
            queued,
            profile_id: profile_id.into(),
        }
    }

    fn trace(&self) -> caly_common::TraceId {
        self.queued.command.context.trace_id.clone()
    }

    fn command_id(&self) -> String {
        self.queued.command.id.0.clone()
    }

    fn stage(&self, pct: u8, stage: impl Into<String>) -> Result<(), ApplyFailure> {
        self.handle
            .append_job_event(
                self.queued.job_id,
                JobEvent::Stage {
                    stage: stage.into(),
                    pct: Some(pct),
                },
            )
            .map_err(ApplyFailure::from)
    }

    /// A `JobEvent::Warning`, not a warn-level log line: `JobFollowView.warning_count` counts
    /// these, so the daemon's diagnostics surface depends on the variant.
    fn warn(&self, message: impl Into<String>) -> Result<(), ApplyFailure> {
        self.handle
            .append_job_event(
                self.queued.job_id,
                JobEvent::Warning {
                    message: message.into(),
                },
            )
            .map_err(ApplyFailure::from)
    }

    fn log(&self, level: &str, message: impl Into<String>) -> Result<(), ApplyFailure> {
        self.handle
            .append_job_event(
                self.queued.job_id,
                JobEvent::Log {
                    level: level.to_owned(),
                    message: message.into(),
                },
            )
            .map_err(ApplyFailure::from)
    }

    /// Publish the failure, close the job, and hand the caller the cycle result.
    fn fail(
        &self,
        failure: ApplyFailure,
        impact: EstimatedImpact,
    ) -> Result<WorkerCycleResult, String> {
        if let Some(message) = failure.warning {
            self.handle
                .append_job_event(self.queued.job_id, JobEvent::Warning { message })?;
        }
        self.handle.append_job_event(
            self.queued.job_id,
            JobEvent::Failed {
                error: *failure.error,
            },
        )?;
        if let Some(summary) = failure.recovery {
            self.handle.push_event(
                crate::event::EventKind::RecoveryDecision,
                Some(self.command_id()),
                crate::event::EventPayload::RecoveryDecision { summary },
            )?;
        }
        if let Some(summary) = failure.deployment {
            self.handle.push_event(
                crate::event::EventKind::DeploymentChanged,
                Some(self.command_id()),
                crate::event::EventPayload::DeploymentChanged { summary },
            )?;
        }
        self.handle.mark_finished(self.queued, failure.settle)?;
        Ok(WorkerCycleResult {
            job_id: self.queued.job_id.0,
            outcome: failure.settle,
            impact,
        })
    }

    fn succeed(
        &self,
        deployment: String,
        impact: EstimatedImpact,
    ) -> Result<WorkerCycleResult, String> {
        self.handle.push_event(
            crate::event::EventKind::DeploymentChanged,
            Some(self.command_id()),
            crate::event::EventPayload::DeploymentChanged {
                summary: deployment,
            },
        )?;
        self.handle
            .mark_finished(self.queued, JobOutcome::Succeeded)?;
        Ok(WorkerCycleResult {
            job_id: self.queued.job_id.0,
            outcome: JobOutcome::Succeeded,
            impact,
        })
    }
}

fn execute_profile_apply(
    handle: &EngineHandle,
    queued: &QueuedCommand,
    request: caly_api::ApplyRequest,
) -> Result<WorkerCycleResult, String> {
    let run = ApplyRun::new(handle, queued, request.profile_id.0.clone());
    run.stage(10, format!("pipeline.resolve profile={}", run.profile_id))?;

    // Round 56 (`ADR-044 §5.3`): plan against what is actually deployed. Until something
    // commits this is `None` — a first install — and after a rollback it is `None` again,
    // because "rolled back" means nothing is proven deployed, not "the previous artifact
    // is probably running".
    let current = match handle.last_compiled_artifact() {
        Ok(current) => current,
        Err(message) => {
            return run.fail(
                ApplyFailure::error_only(
                    ApiError::new(
                        ErrorCode::Internal,
                        ErrorCategory::Internal,
                        false,
                        "engine state unavailable for apply planning",
                        run.trace(),
                    )
                    .with_detail(message),
                ),
                EstimatedImpact::Restart,
            );
        }
    };
    let cached_sources = match handle.normalized_source_cache() {
        Ok(sources) => sources,
        Err(message) => {
            return run.fail(
                ApplyFailure::error_only(
                    ApiError::new(
                        ErrorCode::Internal,
                        ErrorCategory::Internal,
                        false,
                        "source cache unavailable for apply planning",
                        run.trace(),
                    )
                    .with_detail(message),
                ),
                EstimatedImpact::Restart,
            );
        }
    };
    let workflow = match plan_apply_request_with_sources(request, current.as_ref(), cached_sources)
    {
        Ok(workflow) => workflow,
        Err(message) => {
            let failure = ApplyFailure::error_only(
                ApiError::new(
                    ErrorCode::Internal,
                    ErrorCategory::Internal,
                    false,
                    "apply planning failed",
                    run.trace(),
                )
                .with_detail(message),
            )
            .with_deployment(format!(
                "apply planning failed for profile {}",
                run.profile_id
            ));
            return run.fail(failure, EstimatedImpact::Restart);
        }
    };

    // Keep the verdict the apply actually got, so a later bundle reports what was allowed rather
    // than only what the registry says is possible (`RFC-0010 §12.2`). Recorded before the gate so
    // a blocked apply is still explainable afterwards. A failure here is a diagnostics gap, not a
    // reason to abandon a deployment, so it is reported rather than swallowed.
    if let Err(message) = handle.record_capability_summary(workflow.capability.clone()) {
        run.warn(format!(
            "capability verdict not recorded for diagnostics: {message}"
        ))?;
    }

    let impact = impact_from_plan_kind(&workflow.apply_plan_kind);
    match run_apply(&run, handle, &workflow) {
        Ok(()) => run.succeed(
            format!(
                "persisted apply {} for profile {}",
                workflow.apply_plan_kind, run.profile_id
            ),
            impact,
        ),
        Err(failure) => run.fail(failure, impact),
    }
}

/// Phases 2..5 of `docs/engineering/APPLY_EXECUTION_CENTERLINE.md §5.1`, in order.
fn run_apply(
    run: &ApplyRun<'_>,
    handle: &EngineHandle,
    workflow: &ApplyWorkflowResult,
) -> Result<(), ApplyFailure> {
    // Built once for the whole execution and handed to every bounded seam. This used to be a
    // `run.store_limits()` call inside each seam, and `RunLimits::for_command` mints a fresh spent
    // counter each time -- so "the caller's command gets 64 store accesses" was quietly "each seam
    // gets 64". One call, one counter, and `crates/caly-engine/tests/cutover_intent_guard.rs` holds
    // the two seams to it.
    let limits = run.store_limits();
    gate_capability(run, workflow)?;
    report_planning(run, workflow)?;
    let persisted = persist_projection(run, handle, workflow, &limits)?;
    let journal = execute_effects(run, handle, workflow, &persisted, &limits)?;
    commit_snapshot(run, handle, workflow, &journal)
}

/// The capability gate runs before any side effect, and its refusal is a *config* problem, not a
/// runtime one (`docs/engineering/APPLY_EXECUTION_CENTERLINE.md §10`).
fn gate_capability(run: &ApplyRun<'_>, workflow: &ApplyWorkflowResult) -> Result<(), ApplyFailure> {
    run.stage(
        25,
        format!(
            "capability.validate required={} warn={} blocked={}",
            workflow.capability.required_count,
            workflow.capability.warning_count,
            workflow.capability.blocked_count,
        ),
    )?;
    for decision in workflow.capability.decisions.iter().take(8) {
        run.log("info", format!("capability {decision}"))?;
    }
    for diagnostic in workflow.diagnostics.iter().take(8) {
        run.warn(diagnostic.clone())?;
    }

    if workflow.capability.blocked_count == 0 {
        return Ok(());
    }
    Err(ApplyFailure::error_only(
        ApiError::new(
            ErrorCode::UnsupportedCapability,
            ErrorCategory::Capability,
            false,
            format!(
                "apply blocked by {} capability decision(s)",
                workflow.capability.blocked_count
            ),
            run.trace(),
        )
        .with_detail(workflow.capability.decisions.join(" | "))
        .with_remediation("switch target core, relax strict mode, or remove blocked features"),
    )
    .with_deployment(format!(
        "apply blocked before execution for profile {}",
        run.profile_id
    )))
}

fn report_planning(run: &ApplyRun<'_>, workflow: &ApplyWorkflowResult) -> Result<(), ApplyFailure> {
    run.stage(
        45,
        format!(
            "native.validate accepted={}",
            workflow.compilation.native_accepted
        ),
    )?;
    run.stage(60, format!("apply.plan {}", workflow.apply_plan_kind))?;
    run.stage(
        70,
        format!(
            "storage.project txn={} snapshot={}",
            workflow.storage.apply_txn_id, workflow.storage.snapshot_id
        ),
    )
}

fn persist_projection(
    run: &ApplyRun<'_>,
    handle: &EngineHandle,
    workflow: &ApplyWorkflowResult,
    limits: &RunLimits,
) -> Result<PersistedApplyExecution, ApplyFailure> {
    let persisted = handle
        .begin_apply_persistence(workflow.storage_projection.clone(), limits)
        .map_err(|refusal| {
            // The summary names the seam; the code, the category and the knob to turn come from one
            // table shared with the cutover guard, so the two cannot recommend different fields for one
            // refusal (`docs/history/ONBOARDING_NOTES.md §4.81`). A spent budget or an over-large payload is the
            // caller's own limit, so neither is reported as a storage fault.
            let summary = match refusal.kind {
                RefusalKind::BudgetExhausted => "apply refused by the caller's io budget",
                RefusalKind::PayloadTooBig => "apply refused by the caller's byte budget",
                _ => "apply persistence begin failed",
            };
            let (code, category, remediation) = public_shape_for_refusal(refusal.kind);
            ApplyFailure::error_only(
                ApiError::new(code, category, refusal.retryable, summary, run.trace())
                    .with_detail(refusal.to_string())
                    .with_remediation(remediation),
            )
            .with_settlement(settle_for_refusal(refusal.kind))
        })?;
    run.log(
        "info",
        format!(
            "journal.pending {} runtime={}",
            persisted.journal.journal_id.0, persisted.runtime_path
        ),
    )?;
    Ok(persisted)
}

/// Phase A + B of `§6.1`, then the journal fold. Returns the settled journal to commit from.
fn execute_effects(
    run: &ApplyRun<'_>,
    handle: &EngineHandle,
    workflow: &ApplyWorkflowResult,
    persisted: &PersistedApplyExecution,
    limits: &RunLimits,
) -> Result<ApplyJournalRecord, ApplyFailure> {
    let Some(plan) = workflow.effect_plan.as_ref() else {
        // A plan with no effects (e.g. Noop) still commits its projection; only the execution
        // stages are skipped. This keeps the pre-executor behaviour for no-op applies.
        return Ok(persisted.journal.clone());
    };

    let policy = handle.execution_policy();
    let mut cursor = JournalIntentCursor::new(handle, &policy, limits, &persisted.journal);
    let execution = crate::executor::execute_effect_plan_with_cursor(
        plan,
        &persisted.journal,
        handle.effect_runtime().as_ref(),
        &policy,
        &mut cursor,
    );
    let journal = crate::executor::journal_after_execution(&persisted.journal, &execution, &policy);
    handle
        .put_apply_journal(journal.clone())
        .map_err(|message| {
            ApplyFailure::error_only(
                ApiError::new(
                    ErrorCode::Storage,
                    ErrorCategory::Io,
                    true,
                    "apply journal settlement failed",
                    run.trace(),
                )
                .with_detail(message),
            )
        })?;

    report_execution(run, workflow, &execution)?;
    // The guard's own refusal outranks the generic execution failure. Both are true; only one of them
    // tells the operator that the *journal* is the thing to fix, and `OVERLOAD_AND_RETRY_MODEL §6.2`
    // is written about exactly this refusal.
    if let Some(refusal) = cursor.refusal.clone() {
        return Err(cursor_guard_failure(
            run, handle, &journal, &cursor, refusal,
        ));
    }
    if !execution.succeeded() {
        return Err(execution_failure(run, &execution, &journal));
    }
    Ok(journal)
}

/// The `docs/engineering/APPLY_EXECUTION_CENTERLINE.md §6.1` Phase B pending guard, as the worker implements it: every
/// cutover step is announced in the apply journal *before* the runtime is asked to change anything.
///
/// Two things it deliberately does not do:
///
/// * **It does not retry a refused record.** Retry policy belongs to the caller
///   (`OVERLOAD_AND_RETRY_MODEL §4`), and a guard that retries quietly is a guard that hides the
///   refusal it exists to report.
/// * **It does not decide which writes may be refused.** `EngineHandle::advance_apply_phase`
///   substitutes `RunLimits::immediate()` for the single record that first says "the world may have
///   changed" (`ADR-036 §6bis-quinque`), so a caller who gives up cannot delete the evidence; the
///   cursor chains its own copy of the journal, which is how that predicate sees the flag as already
///   set from the second record onwards.
///
/// The cursor it writes is the index of the step *about to start*, i.e. one past the last step known
/// done. That is the honest figure for a process that may die at any moment: after a hard kill the
/// scanner reads "everything below `k` finished, `k` may have begun", which is exactly what
/// `validate_resume_boundary` refuses to re-run.
struct JournalIntentCursor<'a> {
    handle: &'a EngineHandle,
    policy: &'a ExecutionPolicy,
    limits: &'a RunLimits,
    journal: ApplyJournalRecord,
    /// Step indices whose intent record landed, in order. Asserted against rather than merely
    /// logged: the count is the difference between "one record per cutover step" and a guess.
    recorded: Vec<usize>,
    refusal: Option<CursorRefusal>,
}

impl<'a> JournalIntentCursor<'a> {
    fn new(
        handle: &'a EngineHandle,
        policy: &'a ExecutionPolicy,
        limits: &'a RunLimits,
        journal: &'a ApplyJournalRecord,
    ) -> Self {
        Self {
            handle,
            policy,
            limits,
            journal: journal.clone(),
            recorded: Vec::new(),
            refusal: None,
        }
    }
}

impl EffectCursor for JournalIntentCursor<'_> {
    fn record_intent(&mut self, phase: ApplyPhase, step_index: usize) -> Result<(), CursorRefusal> {
        let advanced = self.handle.advance_apply_phase(
            &self.journal,
            phase,
            step_index,
            // The same tick sequence the end-of-plan fold uses, so the cursor's timestamps cannot run
            // backwards across the guard boundary: `index + 1 <= steps.len() <= clock_ticks`.
            self.policy.timestamp_at(step_index + 1),
            self.limits,
        );
        match advanced {
            Ok(journal) => {
                self.journal = journal;
                self.recorded.push(step_index);
                Ok(())
            }
            Err(refusal) => {
                let refusal = CursorRefusal::from(refusal);
                self.refusal = Some(refusal.clone());
                Err(refusal)
            }
        }
    }
}

/// How a job settles for a refusal of this kind -- at either bounded seam.
///
/// One table, because "the caller gave up" must not mean `Cancelled` on the persistence seam and
/// `Failed` on the cutover seam; two tables is the `docs/history/ONBOARDING_NOTES.md §4.81` shape (one fact,
/// two spellings, free to drift).
fn settle_for_refusal(kind: RefusalKind) -> JobOutcome {
    match kind {
        // The caller stopped wanting this, or ran out of time, *before the store was asked*: nothing
        // happened, so the job record must say that rather than "storage broke" -- and those two
        // `JobOutcome` variants exist precisely to say it (`RFC-0006 §5.2`).
        RefusalKind::CallerCancelled => JobOutcome::Cancelled,
        RefusalKind::DeadlineExpired => JobOutcome::TimedOut,
        _ => JobOutcome::Failed,
    }
}

/// The public code and category for a refusal, at either bounded seam.
///
/// `RFC-0002 §14.4` freezes the code list and has no capacity code, so both budget-shaped refusals point
/// back at the field the caller can change (`CONFIG_INVALID` + `User`) and every other refusal is
/// `STORAGE` ("the store said no") -- including the store's own `Busy`. Adding `CAPACITY_EXCEEDED` is an
/// RFC-level decision, recorded as deferred in `ADR-036 §6bis-sexies`; what distinguishes a busy store
/// from a corrupt record is the class in the detail line and the entry in `doctor`'s tally.
///
/// The remediation is in the table because it is the same fact as the code: one refusal answered with two
/// different knobs, depending on which seam happened to hit it, is the `§4.81` shape again.
fn public_shape_for_refusal(kind: RefusalKind) -> (ErrorCode, ErrorCategory, &'static str) {
    match kind {
        RefusalKind::BudgetExhausted => (
            ErrorCode::ConfigInvalid,
            ErrorCategory::User,
            "raise Ctx::io_budget.max_requests, or split the operation into smaller ones",
        ),
        RefusalKind::PayloadTooBig => (
            ErrorCode::ConfigInvalid,
            ErrorCategory::User,
            "raise Ctx::io_budget.max_bytes or send a smaller payload: the port refused before it \
             wrote, so nothing needs unwinding",
        ),
        _ => (
            ErrorCode::Storage,
            ErrorCategory::Io,
            "inspect object store and apply journal availability",
        ),
    }
}

/// `docs/engineering/OVERLOAD_AND_RETRY_MODEL.md §6.2` is a list of three requirements, and this function is where each
/// of them gets its outlet:
///
/// * **"不得简单提示稍后再试就结束"** -- when the store itself called the refusal busy, it is recorded as
///   engine pressure with a `ManualIntervention` hint (`EngineHandle::record_storage_contention`,
///   `§7.2`'s durable half), and the class and hint are quoted into `detail` so the caller sees the
///   same words the operator does.
/// * **recovery-aware** -- the narrative names the journal record this process *did* manage to write,
///   flags and cursor included, so the next boot's scan is not the first time anybody notices.
/// * **an execution failure, not a validation one** -- the code comes from `public_shape_for_refusal`,
///   the same table the persistence seam uses, never the `CONFIG_INVALID` a rejected plan gets. A
///   caller's own limit -- spent requests or an over-large payload -- is the one case where both seams
///   answer `CONFIG_INVALID` on purpose, and they name the field from the same row of the same table.
fn cursor_guard_failure(
    run: &ApplyRun<'_>,
    handle: &EngineHandle,
    journal: &ApplyJournalRecord,
    cursor: &JournalIntentCursor<'_>,
    refusal: CursorRefusal,
) -> ApplyFailure {
    let what = format!(
        "the cutover intent record ({} written before it)",
        cursor.recorded.len()
    );
    let mut detail = refusal.message.clone();
    match handle.record_storage_contention(refusal.kind, what, refusal.retryable) {
        Ok(Some(report)) => detail = format!("{detail} | {}", report.detail()),
        Ok(None) => {}
        Err(message) => {
            // A diagnostics gap is reported; it never replaces the refusal that stopped the apply.
            let _ = run.warn(format!("pressure not recorded for diagnostics: {message}"));
        }
    }
    let (code, category, budget_remediation) = public_shape_for_refusal(refusal.kind);
    let remediation = if refusal.caller_side {
        "the refused step never started, so nothing outside the store changed: retry the apply          with a longer Ctx::deadline_ms, or omit it"
    } else if matches!(
        refusal.kind,
        RefusalKind::BudgetExhausted | RefusalKind::PayloadTooBig
    ) {
        budget_remediation
    } else {
        "restore write access to the apply journal before retrying: the engine will not touch          the running system without the record that says it might have"
    };
    ApplyFailure::error_only(
        ApiError::new(
            code,
            category,
            refusal.retryable,
            "apply stopped before a cutover step: the apply journal refused the intent record",
            run.trace(),
        )
        .with_detail(detail)
        .with_remediation(remediation),
    )
    .with_settlement(settle_for_refusal(refusal.kind))
    .with_warning(format!(
        "cutover guard halted the apply after {} intent record(s)",
        cursor.recorded.len()
    ))
    .with_recovery(format!(
        "recovery.pending for apply txn {}: the journal records phase {:?} at cursor {} with \
         cutover_started={}, so the window this process left is readable without waiting for a \
         crash to discover it",
        journal.apply_txn_id.0,
        journal.current_phase,
        journal.current_step_index,
        journal.core_cutover_started,
    ))
}

/// Stage names follow `docs/engineering/APPLY_EXECUTION_CENTERLINE.md §9` so job follow, the stream path and the
/// query path describe one progression instead of three.
fn report_execution(
    run: &ApplyRun<'_>,
    workflow: &ApplyWorkflowResult,
    execution: &EffectExecution,
) -> Result<(), ApplyFailure> {
    run.stage(
        72,
        format!(
            "effects.prepare.started plan={} steps={}",
            execution.plan_id,
            workflow.effect_steps.len()
        ),
    )?;
    if execution.cutover_started {
        run.stage(
            80,
            format!(
                "effects.cutover.started step={} net_effect_started={}",
                execution.cursor_step_index(),
                execution.net_effect_started
            ),
        )?;
    }
    if execution.probe_passed {
        run.stage(86, "effects.verify.started")?;
    }
    for step in execution.steps.iter().take(12) {
        run.log(
            if step.succeeded() { "info" } else { "warn" },
            format!("{:?} {:02}: {}", step.phase, step.index + 1, step.label),
        )?;
        // Round 69: a probe's observations ARE its evidence (e.g. `probe.core-identity
        // kind=mihomo version=…`) — hiding them makes the probe prove nothing to the
        // operator who reads the job log. Other steps' observations stay out: their label
        // is the summary, and their evidence is not the point of the step.
        if step.label.starts_with("probe ") {
            for observation in &step.observations {
                run.log(
                    "info",
                    format!("{:?} {:02}: {observation}", step.phase, step.index + 1),
                )?;
            }
        }
    }
    for compensation in execution.compensations.iter().take(8) {
        run.log(
            "info",
            format!(
                "compensate {:02}: {}",
                compensation.index + 1,
                compensation.label
            ),
        )?;
    }
    Ok(())
}

/// `§10`: a gate rejection, a rolled-back apply, and an apply whose rollback also failed are
/// three different public outcomes with three different retry answers.
fn execution_failure(
    run: &ApplyRun<'_>,
    execution: &EffectExecution,
    journal: &ApplyJournalRecord,
) -> ApplyFailure {
    let code = execution.status.summary_code();
    let manual = execution.status.needs_manual_recovery();
    let rejected_reason = match &execution.status {
        ExecutionStatus::Rejected { reason } => Some(reason.clone()),
        _ => None,
    };
    let (error_code, category, retryable) = if rejected_reason.is_some() {
        (ErrorCode::ConfigInvalid, ErrorCategory::Config, false)
    } else if manual {
        (ErrorCode::CoreFailed, ErrorCategory::Core, false)
    } else {
        (ErrorCode::Unavailable, ErrorCategory::Core, true)
    };

    ApplyFailure::error_only(ApiError::new(
            error_code,
            category,
            retryable,
            format!("effect execution failed ({code})"),
            run.trace(),
        )
        .with_detail(rejected_reason.unwrap_or_else(|| {
            // The failing step's label AND its own words (round 55): a refusal like the
            // real backend's `unsupported-net-apply` names itself and its reason in the
            // summary — dropping that left operators with "a net step failed", which is
            // the anonymity this field exists to prevent.
            let label = execution
                .steps
                .iter()
                .rev()
                .find(|step| !step.succeeded())
                .map(|step| step.label.clone())
                .unwrap_or_else(|| "unknown step".to_owned());
            match &execution.status {
                ExecutionStatus::FailedBeforeCutover { summary, .. }
                | ExecutionStatus::RolledBack { summary, .. }
                | ExecutionStatus::RollbackFailed { summary, .. } => {
                    format!("{label}: {summary}")
                }
                _ => label,
            }
        }))
        .with_remediation(if manual {
            "run daemon recovery scan and restore the last-known-good snapshot before retrying"
        } else {
            "inspect the pending apply journal cursor, then retry apply once the runtime is reachable"
        }))
        .with_recovery(if manual {
            format!(
                "recovery.failed for apply txn {}: active runtime state is not proven restorable",
                journal.apply_txn_id.0
            )
        } else {
            format!(
                "recovery.succeeded for apply txn {} at step {}",
                journal.apply_txn_id.0,
                journal.current_step_index
            )
        })
}

/// Phase C: the new truth is published only after execution proved the runtime verified.
fn commit_snapshot(
    run: &ApplyRun<'_>,
    handle: &EngineHandle,
    workflow: &ApplyWorkflowResult,
    journal: &ApplyJournalRecord,
) -> Result<(), ApplyFailure> {
    let policy = handle.execution_policy();
    let ticks = if workflow.effect_plan.is_some() {
        journal.current_step_index + 1
    } else {
        1
    };

    let finalized = handle
        .finalize_apply_persistence(
            journal,
            &workflow.storage_projection.snapshot_candidate,
            policy.timestamp_at(ticks),
        )
        .map_err(|message| {
            let state = handle
                .mark_apply_recovery_failed(journal, policy.timestamp_at(ticks + 1))
                .map(|failed| format!("{:?}", failed.state))
                .unwrap_or_else(|_| "unrecorded".to_owned());
            ApplyFailure::error_only(
                ApiError::new(
                    ErrorCode::Storage,
                    ErrorCategory::Io,
                    true,
                    "apply finalization failed",
                    run.trace(),
                )
                .with_detail(message)
                .with_remediation("inspect snapshot/revision persistence before retrying apply"),
            )
            .with_recovery(format!(
                "apply finalization failed for profile {}; manual recovery may be required",
                run.profile_id
            ))
            .with_warning(format!(
                "recovery pending: journal={} state={}",
                journal.journal_id.0, state
            ))
        })?;

    handle
        .record_effect_plan(workflow.effect_plan.clone())
        .map_err(ApplyFailure::from)?;
    // The deployment truth of this commit (round 56): the next apply plans against this
    // artifact, so its plan kind — and its StopCore — stop being a first install's.
    handle
        .record_compiled_artifact(Some(workflow.compiled_artifact.clone()))
        .map_err(ApplyFailure::from)?;
    run.stage(
        100,
        format!(
            "snapshot.committed {} revision={}",
            finalized.snapshot_id, finalized.revision_id
        ),
    )?;
    run.handle
        .push_event(
            crate::event::EventKind::SnapshotCommitted,
            Some(run.command_id()),
            crate::event::EventPayload::SnapshotCommitted {
                snapshot_id: finalized.snapshot_id.clone(),
            },
        )
        .map_err(ApplyFailure::from)?;
    // The runtime state *did* just change — a different profile is live, a different snapshot backs
    // it — so the Dashboard stream has to say so. `RFC-0002 §10.3` describes that stream as
    // "snapshot + patch", and a client that re-renders its header from the patch would otherwise keep
    // showing the pre-apply profile until it happened to re-query. `watch_bridge` turns this into a
    // `StreamPayload::RuntimeState` frame carrying the daemon's post-commit snapshot.
    run.handle
        .push_event(
            crate::event::EventKind::RuntimeChanged,
            Some(run.command_id()),
            crate::event::EventPayload::RuntimeChanged {
                summary: format!(
                    "profile {} active, snapshot {} at revision {}",
                    run.profile_id, finalized.snapshot_id, finalized.revision_id
                ),
            },
        )
        .map_err(ApplyFailure::from)?;
    Ok(())
}

/// Roll back by *executing* the compensation half of the last applied effect plan and settling
/// the apply journals, instead of only describing what a rollback would do.
///
/// Closes the `rollback skeleton` gap in `docs/engineering/APPLY_EXECUTION_CENTERLINE.md §8` and makes
/// `recovery.started` / `recovery.succeeded` observable on the job.
fn execute_profile_rollback(
    handle: &EngineHandle,
    queued: &QueuedCommand,
    request: caly_api::RollbackRequest,
) -> Result<WorkerCycleResult, String> {
    let run = ApplyRun::new(handle, queued, String::new());
    run.stage(20, "recovery.started")?;

    let Some(target) = resolve_rollback_target(handle, request.snapshot_id.as_deref())? else {
        return run.fail(
            ApplyFailure::error_only(
                ApiError::new(
                    ErrorCode::Conflict,
                    ErrorCategory::User,
                    false,
                    "no rollback target is available",
                    run.trace(),
                )
                .with_detail("no last-known-good snapshot has been committed yet")
                .with_remediation("complete one successful apply before requesting a rollback"),
            ),
            EstimatedImpact::ReadOnly,
        );
    };

    let compensated = match run_rollback_compensations(handle, &target, &run) {
        Ok(summary) => summary,
        Err(failure) => return run.fail(failure, EstimatedImpact::Restart),
    };

    // Round 57: the target snapshot is the known-good truth from here on — the deployment
    // just compensated must not keep the "latest LKG" crown on a step-counting clock.
    handle
        .promote_snapshot_to_last_known_good(&target)
        .map_err(ApplyFailure::from)?;

    let settled = settle_pending_journals(handle)?;
    run.log(
        "info",
        format!("recovery.settled pending_journals={settled} {compensated}"),
    )?;
    handle.record_effect_plan(None)?;
    // Round 56: a rollback compensated the last deployment away; the engine no longer
    // knows an artifact that is proven running — until the revival below proves one.
    handle.record_compiled_artifact(None)?;

    // Round 57 (`ADR-044 §5.4` closed, `ADR-045`): the compensations took the new
    // deployment away; now put the target snapshot's deployment BACK. A rollback that
    // only kills the new core leaves the host dark, and "pointers restored, no traffic"
    // is not what the operator asked for.
    let redeployed = match redeploy_rollback_target(handle, &run, &target) {
        Ok(summary) => summary,
        Err(failure) => return run.fail(failure, EstimatedImpact::Restart),
    };

    run.stage(100, format!("recovery.succeeded target={target}"))?;
    run.succeed(
        format!("rolled back to snapshot {target}; {compensated}; {redeployed}"),
        EstimatedImpact::Restart,
    )
}

/// Round 57 (`ADR-045`): revive the rollback target's deployment through the same
/// executor and the same runtime an apply uses — no special "rollback mode" on the host,
/// because a second code path to the same core is how the two drift apart.
#[allow(clippy::too_many_lines)]
fn redeploy_rollback_target(
    handle: &EngineHandle,
    run: &ApplyRun<'_>,
    target: &str,
) -> Result<String, ApplyFailure> {
    let Some(record) = handle
        .get_snapshot_by_id(&caly_storage::SnapshotRecordId(target.to_owned()))
        .map_err(|message| redeploy_store_failure(run, target, message))?
    else {
        // A named target this engine has no record of keeps the pre-round-57 behaviour:
        // pointers rolled back, nothing redeployed, the skip said out loud.
        return Ok("no snapshot record for the target; nothing redeployed".to_owned());
    };
    // Round 58 (`ADR-046 §5`): both real cores have spawn faces now, so the revival
    // dispatches on the recorded identity — kind, config entrypoint, and materialization
    // path all follow the core the target actually ran. Anything else stays an honest
    // skip: this engine will not improvise a third envelope.
    let Some((kind, entrypoint)) = revival_core_shape(&record.core_identity) else {
        run.log(
            "warn",
            format!(
                "rollback redeploy has no spawn face for {}; left stopped (ADR-046 scope)",
                record.core_identity
            ),
        )?;
        return Ok("target core has no spawn face; nothing redeployed".to_owned());
    };
    let Some(bytes) = handle
        .object_payload(
            &record.compiled_artifact_digest,
            4 << 20,
            &EngineHandle::store_ctx(),
        )
        .map_err(|message| redeploy_store_failure(run, target, message))?
    else {
        run.log(
            "warn",
            format!(
                "artifact {} is gone from the store; nothing redeployed",
                record.compiled_artifact_digest
            ),
        )?;
        return Ok("artifact bytes unavailable; nothing redeployed".to_owned());
    };

    let digest = record.compiled_artifact_digest.clone();
    let at = format!("runtime/{}/{}", record.profile_id, entrypoint);
    let plan = caly_plan::EffectPlan {
        id: caly_plan::PlanId(format!("rollback-redeploy-{target}")),
        steps: vec![
            caly_plan::EffectStep::WriteObject {
                digest: digest.clone(),
                source: caly_plan::BlobRef {
                    digest: digest.clone(),
                    size_hint: Some(bytes.len() as u64),
                },
                durability: caly_plan::Durability::D2,
            },
            caly_plan::EffectStep::MaterializeArtifact {
                digest: digest.clone(),
                at: at.clone(),
                mode: caly_plan::FileMode::ReadOnlyArtifact,
            },
            caly_plan::EffectStep::SpawnCore {
                spec: caly_plan::CoreSpec {
                    kind,
                    binary_digest: record.core_binary_digest.clone(),
                    config_digest: digest.clone(),
                },
            },
            caly_plan::EffectStep::Probe {
                probe: caly_plan::ProbeSpec {
                    kind: caly_plan::ProbeKind::ApiReady,
                    target: None,
                },
                deadline_ms: 3_000,
            },
            // The proxy door too (`ADR-047 §3`): a revived deployment must be able to
            // carry traffic, not just answer its controller.
            caly_plan::EffectStep::Probe {
                probe: caly_plan::ProbeSpec {
                    kind: caly_plan::ProbeKind::InboundListening,
                    target: None,
                },
                deadline_ms: 3_000,
            },
            // The identity probe is the WHOLE point: it proves the revived core runs the
            // target's config, not "some config".
            caly_plan::EffectStep::Probe {
                probe: caly_plan::ProbeSpec {
                    kind: caly_plan::ProbeKind::ConfigIdentity,
                    target: Some(digest.clone()),
                },
                deadline_ms: 3_000,
            },
            // Round 69 (`IMPLEMENTATION_STATUS §8.4`): the revived core names itself too —
            // `GET /version`'s self-reported version beside the kind the plan spawned, and
            // the revived counters as the new baseline.
            caly_plan::EffectStep::Probe {
                probe: caly_plan::ProbeSpec {
                    kind: caly_plan::ProbeKind::CoreIdentity,
                    target: None,
                },
                deadline_ms: 3_000,
            },
            caly_plan::EffectStep::Probe {
                probe: caly_plan::ProbeSpec {
                    kind: caly_plan::ProbeKind::TelemetryTraffic,
                    target: None,
                },
                deadline_ms: 3_000,
            },
        ],
        compensations: vec![
            caly_plan::EffectStep::MaterializeArtifact {
                digest: digest.clone(),
                at: at.clone(),
                mode: caly_plan::FileMode::ReadOnlyArtifact,
            },
            caly_plan::EffectStep::StopCore {
                instance: caly_plan::InstanceId("mihomo-core-instance".to_owned()),
                grace_ms: 2_500,
            },
        ],
        requires: caly_plan::PrivilegeSet::default(),
        impact: caly_plan::DeployImpact::Restart,
    };
    // A synthetic, never-persisted journal: the revival's crash window is a recorded gap
    // (`ADR-045 §3`) — it runs after the real journals were settled, and inventing a
    // journal lifecycle for it here would be the pretense of recovery semantics.
    let journal =
        caly_storage::build_apply_storage_projection(caly_storage::ApplyStorageProjectionInput {
            apply_txn_id: caly_storage::ApplyTxnId(format!("txn:rollback:{target}")),
            trace_id: format!("trace:rollback:{target}"),
            job_id: None,
            profile_id: record.profile_id.clone(),
            revision_id: caly_storage::RevisionId(record.revision_id.0.clone()),
            revision_number: record.revision_number,
            semantic_digest: record.semantic_digest.clone(),
            compiled_artifact_digest: digest.clone(),
            core_binary_digest: record.core_binary_digest.clone(),
            core_identity: record.core_identity.clone(),
            effect_plan_id: plan.id.0.clone(),
            apply_plan_summary: "RollbackRedeploy".to_owned(),
            artifact_file_name: format!("{}.mihomo.yaml", record.profile_id),
            artifact_size_bytes: bytes.len() as u64,
            artifact_bytes: bytes.clone(),
            content_type: "application/yaml".to_owned(),
            runtime_path: at.clone(),
            selection_memory_digest: record.selection_memory_digest.clone(),
            validation_summary: record.validation_summary.clone(),
            previous_snapshot_id: None,
            created_at_unix_ms: 0,
        })
        .apply_journal;

    // The with-cursor entry point like every production apply path (`§6.1`); `NoCursor`
    // because the revival has no persisted journal whose cutover window could be
    // announced — the recorded-gap honesty of `ADR-045 §3`, now in the open at the call
    // site instead of hidden behind the plain wrapper.
    let mut no_cursor = crate::executor::NoCursor;
    let execution = crate::executor::execute_effect_plan_with_cursor(
        &plan,
        &journal,
        handle.effect_runtime().as_ref(),
        &handle.execution_policy(),
        &mut no_cursor,
    );
    run.stage(95, format!("rollback.redeploy.executed plan={}", plan.id.0))?;
    // The revival logs its steps the way an apply does (`report_execution` is bound to a
    // workflow's stage model; the revival has none, so its evidence is log lines).
    for step in execution.steps.iter().take(12) {
        run.log(
            if step.succeeded() { "info" } else { "warn" },
            format!("Redeploy {:02}: {}", step.index + 1, step.label),
        )?;
    }
    if !execution.succeeded() {
        let failing = execution
            .steps
            .iter()
            .rev()
            .find(|step| !step.succeeded())
            .map(|step| step.label.clone())
            .unwrap_or_else(|| "unknown step".to_owned());
        return Err(ApplyFailure::error_only(
            ApiError::new(
                ErrorCode::CoreFailed,
                ErrorCategory::Core,
                false,
                "rollback redeploy failed",
                run.trace(),
            )
            .with_detail(format!("{failing}: {:?}", execution.status))
            .with_remediation(
                "the compensations already undid the new deployment; inspect the target \
                 snapshot's artifact and re-run rollback",
            ),
        )
        .with_recovery(format!(
            "recovery.failed for rollback to {target}: the old deployment could not be revived"
        )));
    }

    // The revival IS a deployment: remember its plan (a later rollback can compensate it)
    // and its artifact (the next apply of the same profile is an honest Noop, and a
    // different profile an honest Restart — the memory R56 gave the engine, now fed by
    // the revival instead of only by fresh applies).
    handle
        .record_effect_plan(Some(plan))
        .map_err(ApplyFailure::from)?;
    handle
        .record_compiled_artifact(Some(caly_ir::CompiledArtifact {
            profile_id: caly_ir::ProfileId(record.profile_id.clone()),
            target_core: caly_ir::CoreTarget::Mihomo,
            adapter_version: 1,
            artifact_digest: caly_ir::ArtifactDigest(digest),
            file_name_hint: format!("{}.mihomo.yaml", record.profile_id),
            format: caly_ir::NativeConfigFormat::Yaml,
            entrypoint: entrypoint.to_owned(),
            media_type: "application/yaml".to_owned(),
            bytes: caly_ir::StableBytes::new(bytes),
            // The snapshot record carries the digest truth, not the compile annotations;
            // empty annotations make same-artifact re-apply a Noop and everything else a
            // Restart, which is exactly the honest shape for a revived deployment.
            annotations: std::collections::BTreeMap::new(),
        }))
        .map_err(ApplyFailure::from)?;
    Ok(format!(
        "revived deployment of snapshot {target} ({} steps)",
        execution.steps.len()
    ))
}

fn redeploy_store_failure(run: &ApplyRun<'_>, target: &str, message: String) -> ApplyFailure {
    ApplyFailure::error_only(
        ApiError::new(
            ErrorCode::Storage,
            ErrorCategory::Io,
            true,
            "rollback redeploy could not read the store",
            run.trace(),
        )
        .with_detail(message),
    )
    .with_recovery(format!(
        "recovery pending for rollback to {target}; the store was unreadable mid-revival"
    ))
}

fn resolve_rollback_target(
    handle: &EngineHandle,
    requested: Option<&str>,
) -> Result<Option<String>, String> {
    if let Some(snapshot_id) = requested {
        return Ok(Some(snapshot_id.to_owned()));
    }
    Ok(handle
        .latest_last_known_good_snapshot()?
        .map(|snapshot| snapshot.id.0))
}

/// The spawn shape a revival needs per recorded core identity: which CoreKind to spawn
/// and which entrypoint filename the deployment materialized. `None` = no spawn face.
fn revival_core_shape(core_identity: &str) -> Option<(caly_plan::CoreKind, &'static str)> {
    if core_identity.starts_with("mihomo@") {
        Some((caly_plan::CoreKind::Mihomo, "config.yaml"))
    } else if core_identity.starts_with("sing-box@") {
        Some((caly_plan::CoreKind::SingBox, "config.json"))
    } else {
        None
    }
}

fn run_rollback_compensations(
    handle: &EngineHandle,
    target: &str,
    run: &ApplyRun<'_>,
) -> Result<String, ApplyFailure> {
    let Some(plan) = handle.last_effect_plan().map_err(|message| {
        ApplyFailure::error_only(
            ApiError::new(
                ErrorCode::Storage,
                ErrorCategory::Io,
                true,
                "rollback could not read the last effect plan",
                run.trace(),
            )
            .with_detail(message),
        )
    })?
    else {
        return Ok("no prior effect plan recorded; nothing to compensate".to_owned());
    };

    let unwind = crate::executor::run_compensations(&plan, handle.effect_runtime().as_ref());
    for step in unwind.steps.iter() {
        run.log(
            if step.succeeded() { "info" } else { "warn" },
            format!("compensate {:02}: {}", step.index + 1, step.label),
        )?;
    }

    match unwind.failure {
        None => Ok(format!(
            "compensated {} step(s) of effect plan {}",
            unwind.applied_count(),
            plan.id.0
        )),
        Some(failure) => Err(ApplyFailure::error_only(
            ApiError::new(
                ErrorCode::CoreFailed,
                ErrorCategory::Core,
                false,
                "rollback compensation failed",
                run.trace(),
            )
            .with_detail(format!("{}: {}", failure.code, failure.summary))
            .with_remediation(
                "inspect the pending apply journal and restore the snapshot manually",
            ),
        )
        .with_recovery(format!(
            "recovery.failed for rollback to {target}: {}",
            failure.summary
        ))),
    }
}

fn settle_pending_journals(handle: &EngineHandle) -> Result<usize, String> {
    let report = handle.scan_recovery_state()?;
    let policy = handle.execution_policy();
    let mut settled = 0usize;
    for (index, journal) in report.unresolved_apply_journals.iter().enumerate() {
        let reverted = handle.mark_apply_reverted(journal, policy.timestamp_at(index + 1))?;
        if reverted.state != caly_storage::ApplyJournalState::Reverted {
            return Err("rollback failed to settle pending apply journal".to_owned());
        }
        settled += 1;
    }
    Ok(settled)
}

fn impact_from_plan_kind(plan_kind: &str) -> EstimatedImpact {
    match plan_kind {
        "Noop" => EstimatedImpact::Noop,
        "ApiPatch" => EstimatedImpact::Reload,
        "HotReload" => EstimatedImpact::Reload,
        "Restart" => EstimatedImpact::Restart,
        "RebuildAndRestart" => EstimatedImpact::RebuildAndRestart,
        _ => EstimatedImpact::ReadOnly,
    }
}

pub fn drain_skeleton(
    handle: &EngineHandle,
    max_cycles: usize,
) -> Result<Vec<WorkerCycleResult>, String> {
    let mut results = Vec::new();
    for _ in 0..max_cycles {
        match consume_one_skeleton(handle)? {
            Some(result) => results.push(result),
            None => break,
        }
    }
    Ok(results)
}

pub fn drain_with_policy(
    handle: &EngineHandle,
    policy: WorkerPolicy,
) -> Result<WorkerDrainReport, String> {
    let results = drain_skeleton(handle, policy.max_cycles_per_drain)?;
    let cycles = results.len();
    let limit_hit = cycles >= policy.max_cycles_per_drain;
    let exhausted_queue = !limit_hit;
    Ok(WorkerDrainReport {
        cycles,
        exhausted_queue,
        limit_hit,
        results,
    })
}

#[cfg(test)]
mod tests {
    use super::public_shape_for_refusal;
    use crate::run_limits::RefusalKind;
    use caly_api::{ErrorCategory, ErrorCode};

    /// The two budget-shaped refusals share a code and a category because `RFC-0002 §14.4` has no
    /// capacity code -- and they must still not share a **remediation**, because they point at different
    /// fields of the caller's own `Ctx`. That distinction is the whole reason `PayloadTooBig` exists as a
    /// kind rather than as a second message on `BudgetExhausted`; without an assertion it would collapse
    /// the first time someone "deduplicates" the two arms.
    #[test]
    fn the_two_budget_refusals_name_different_knobs_and_the_same_public_bucket() {
        let requests = public_shape_for_refusal(RefusalKind::BudgetExhausted);
        let bytes = public_shape_for_refusal(RefusalKind::PayloadTooBig);
        assert_eq!(
            (requests.0, requests.1),
            (bytes.0, bytes.1),
            "both are the caller's own limit, so both are {requests:?} / {bytes:?}"
        );
        assert_eq!(requests.0, ErrorCode::ConfigInvalid);
        assert_eq!(requests.1, ErrorCategory::User);
        assert!(
            requests.2.contains("max_requests") && !requests.2.contains("max_bytes"),
            "{}",
            requests.2
        );
        assert!(
            bytes.2.contains("max_bytes") && !bytes.2.contains("max_requests"),
            "{}",
            bytes.2
        );

        // And a store-caused refusal keeps the storage shape, with no budget advice at all.
        let storage = public_shape_for_refusal(RefusalKind::StorageBusy);
        assert_eq!(
            (storage.0, storage.1),
            (ErrorCode::Storage, ErrorCategory::Io),
            "{storage:?}"
        );
        assert!(
            !storage.2.contains("io_budget"),
            "blaming the caller's field for the store's own busy answer is a fabricated reason: {}",
            storage.2
        );
    }
}
