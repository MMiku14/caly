use std::collections::BTreeMap;

use caly_common::Actor;

use crate::command::{CommandId, IdempotencyKey};
use crate::job::JobOutcome;

#[derive(Clone, Debug, Eq, PartialEq, Ord, PartialOrd)]
pub struct ActorKey {
    pub actor: Actor,
    pub idempotency_key: String,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub enum IdempotencyStatus {
    Running,
    Finished(JobOutcome),
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct IdempotencyRecord {
    pub command_id: CommandId,
    pub job_id: u64,
    /// The exact `Accepted` the daemon handed out the first time.
    ///
    /// `RFC-0002 §8.3` requires a duplicate command to return 「原 JobId 或等价 outcome」. Rebuilding
    /// an `Accepted` on the replay path instead of reusing the recorded one was how a replayed
    /// apply came back with a different `state_revision` and a hardcoded `ReadOnly` impact — i.e.
    /// the same request answered two different ways depending on whether it was the first or the
    /// second of its kind. Idempotency has to cover the *response*, not only the job id.
    pub accepted: caly_api::Accepted,
    pub status: IdempotencyStatus,
}

/// The dedup window `RFC-0002 §8.3` requires: `(actor, key) -> job + state`.
///
/// `max_finished` bounds how many **completed** records are kept, and that is the whole policy: a
/// running record is never evicted (dropping one would let a retry start a second deployment, which is
/// exactly what `§8.3` forbids), while completed records are what a retry *after* the window will miss.
/// Bounding only the finished half also means insertion can never fail for capacity reasons — the
/// running set is already bounded by the queue cap, so the table cannot fill up with unevictable
/// entries. `ADR-037 §2.5` asked for a bounded window; this is the shape that stays deterministic
/// without inventing a second overload class (`docs/ONBOARDING_NOTES.md §4.62`).
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct IdempotencyTable {
    entries: BTreeMap<ActorKey, IdempotencyRecord>,
    max_finished: usize,
    evictions: usize,
}

impl Default for IdempotencyTable {
    fn default() -> Self {
        Self {
            entries: BTreeMap::new(),
            // Above the engine's queue capacity (256), so a submission is never refused because the
            // dedup window was full: capacity pressure is the queue's job, not the window's.
            max_finished: 512,
            evictions: 0,
        }
    }
}

impl IdempotencyTable {
    pub fn with_finished_window(max_finished: usize) -> Self {
        Self {
            max_finished,
            ..Self::default()
        }
    }

    pub fn len(&self) -> usize {
        self.entries.len()
    }

    pub fn is_empty(&self) -> bool {
        self.entries.is_empty()
    }

    pub fn max_finished(&self) -> usize {
        self.max_finished
    }

    /// How many completed records have fallen out of the window. A caller that retried a command and
    /// got a fresh deployment would see this number move, which is the only honest way to report
    /// "the window is not a promise of permanence".
    pub fn evictions(&self) -> usize {
        self.evictions
    }

    pub fn make_key(actor: Actor, key: &IdempotencyKey) -> ActorKey {
        ActorKey {
            actor,
            idempotency_key: key.0.clone(),
        }
    }

    pub fn put_running(
        &mut self,
        actor: Actor,
        key: &IdempotencyKey,
        command_id: CommandId,
        accepted: &caly_api::Accepted,
    ) {
        self.entries.insert(
            Self::make_key(actor, key),
            IdempotencyRecord {
                command_id,
                job_id: accepted.job_id.0,
                accepted: accepted.clone(),
                status: IdempotencyStatus::Running,
            },
        );
    }

    /// Drop the oldest **finished** records until the window fits again.
    ///
    /// Only `mark_finished` calls this. Inserting a record cannot push the finished count over the cap
    /// (a fresh record is always `Running`), and an eviction hook in `put_running` would therefore be a
    /// second copy of a rule that the other site already enforces — the shape that later makes someone
    /// "fix" one and not the other.
    ///
    /// "Oldest" is job id order, not insertion order: a replay of an existing key re-inserts it with a
    /// newer job id, and it must not become the victim while older completed work is still in there.
    fn evict_finished_over_window(&mut self) {
        // The loop is bounded by the entry count instead of running until `over == 0`. Same work in the
        // correct case, and one difference in the broken case: if the bound and the victim set ever
        // stop agreeing, that shows up as a wrong `len()` in a test rather than as a hung suite. This is
        // not a hypothetical — the round-14 mutation "let running records be victims too" turned the
        // loop into a livelock, because the finished-over-cap number stops decreasing while the victim
        // list keeps offering running records (`docs/ONBOARDING_NOTES.md §4.64`).
        let mut steps = self.entries.len();
        while steps > 0 {
            steps -= 1;
            let candidates: Vec<(u64, ActorKey)> = self
                .entries
                .iter()
                .filter(|(_, record)| matches!(record.status, IdempotencyStatus::Finished(_)))
                .map(|(key, record)| (record.job_id, key.clone()))
                .collect();
            let over = candidates.len().saturating_sub(self.max_finished);
            if over == 0 {
                return;
            }
            let mut oldest = candidates;
            oldest.sort();
            for (_, key) in oldest.iter().take(over) {
                self.entries.remove(key);
                self.evictions += 1;
            }
        }
    }

    pub fn mark_finished(&mut self, actor: Actor, key: &IdempotencyKey, outcome: JobOutcome) {
        if let Some(record) = self.entries.get_mut(&Self::make_key(actor, key)) {
            record.status = IdempotencyStatus::Finished(outcome);
        }
        // The finished count only changes here, so this is where the window has to be re-bounded —
        // bounding it on insert alone would let it grow by one for every command that ever completes.
        self.evict_finished_over_window();
    }

    pub fn get(&self, actor: Actor, key: &IdempotencyKey) -> Option<&IdempotencyRecord> {
        self.entries.get(&Self::make_key(actor, key))
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::state::EngineState;
    use caly_api::{Accepted, EstimatedImpact, JobId};

    fn accepted(job_id: u64, revision: u64) -> Accepted {
        Accepted {
            job_id: JobId(job_id),
            state_revision: revision,
            estimated_impact: EstimatedImpact::Restart,
        }
    }

    fn key(text: &str) -> IdempotencyKey {
        IdempotencyKey(text.to_owned())
    }

    /// `RFC-0002 §8.3` promises a **recent** window, and `ADR-037 §2.5` fixes how it is bounded:
    /// completed records fall out, running ones never do. Both halves matter — evicting a running
    /// record is how a retry starts a second deployment, which is the one thing that section forbids.
    #[test]
    fn completed_records_fall_out_of_the_window_and_the_counter_says_so() {
        let mut table = IdempotencyTable::with_finished_window(2);
        for job in 1..=3u64 {
            let id = CommandId(format!("cmd-{job}"));
            let key = key(&format!("key-{job}"));
            table.put_running(Actor::Cli, &key, id, &accepted(job, job));
            table.mark_finished(Actor::Cli, &key, JobOutcome::Succeeded);
        }
        assert_eq!(table.len(), 2, "{table:?}");
        assert_eq!(table.evictions(), 1, "one record left the window");
        assert!(
            table.get(Actor::Cli, &key("key-1")).is_none(),
            "the oldest completed record is the one that goes"
        );
        assert!(table.get(Actor::Cli, &key("key-3")).is_some());
    }

    #[test]
    fn a_running_record_is_never_the_eviction_victim() {
        let mut table = IdempotencyTable::with_finished_window(1);
        for job in 1..=3u64 {
            table.put_running(
                Actor::Cli,
                &key(&format!("key-{job}")),
                CommandId(format!("cmd-{job}")),
                &accepted(job, job),
            );
        }
        assert_eq!(
            table.len(),
            3,
            "nothing is finished yet, so nothing may be dropped"
        );
        assert_eq!(table.evictions(), 0);

        table.mark_finished(Actor::Cli, &key("key-1"), JobOutcome::Succeeded);
        assert_eq!(table.len(), 3, "one finished record still fits the window");
        table.mark_finished(Actor::Cli, &key("key-2"), JobOutcome::Succeeded);
        assert_eq!(table.len(), 2, "{table:?}");
        assert!(table.get(Actor::Cli, &key("key-1")).is_none());
        assert!(
            table.get(Actor::Cli, &key("key-3")).is_some(),
            "the still-running record survives even though it is the newest only by accident"
        );
    }

    /// The victim has to be chosen among finished records, and the fixture has to be able to tell that
    /// apart from "the oldest record": here the **oldest** entry is still running, so an implementation
    /// that picks the oldest overall would drop a running command and let its retry start a second
    /// deployment (`RFC-0002 §8.3`'s one forbidden outcome) while keeping a stale completed one.
    #[test]
    fn the_oldest_record_being_running_does_not_make_it_the_victim() {
        let mut table = IdempotencyTable::with_finished_window(1);
        let busy = key("busy");
        table.put_running(
            Actor::Cli,
            &busy,
            CommandId("cmd-1".to_owned()),
            &accepted(1, 1),
        );
        for job in 2..=3u64 {
            let done = key(&format!("done-{job}"));
            table.put_running(
                Actor::Cli,
                &done,
                CommandId(format!("cmd-{job}")),
                &accepted(job, job),
            );
            table.mark_finished(Actor::Cli, &done, JobOutcome::Succeeded);
        }
        assert!(
            table.get(Actor::Cli, &busy).is_some(),
            "the running command was evicted to make room for its own stale sibling"
        );
        assert!(
            table.get(Actor::Cli, &key("done-2")).is_none(),
            "the older *completed* record is the one that should fall out: {table:?}"
        );
        assert_eq!(table.evictions(), 1);
    }

    /// Only `mark_finished` re-bounds the window, and this pins that the omission is deliberate rather
    /// than a hole: a table that only ever sees running records must not evict anything, no matter how
    /// many arrive.
    #[test]
    fn a_window_of_only_running_records_never_evicts() {
        let mut table = IdempotencyTable::with_finished_window(1);
        for job in 1..=5u64 {
            table.put_running(
                Actor::Cli,
                &key(&format!("busy-{job}")),
                CommandId(format!("cmd-{job}")),
                &accepted(job, job),
            );
        }
        assert_eq!(
            table.len(),
            5,
            "running records are not the window's business"
        );
        assert_eq!(table.evictions(), 0);
    }

    /// `ADR-037 §2.5` as ratified: the window is bounded by **count**, and the count is deliberately
    /// larger than the queue capacity, so "the dedup window was full" can never be the reason a
    /// submission is refused. If either number moves, this has to be re-decided rather than discovered.
    #[test]
    fn the_window_is_never_the_reason_a_submission_fails() {
        assert!(
            IdempotencyTable::default().max_finished() >= EngineState::new().queue.capacity(),
            "a window smaller than the queue turns capacity pressure into a second, unmodelled refusal"
        );
    }

    /// The key is `(actor, key)`, not the key alone: two callers using the same string must not resolve
    /// to each other's job. `§8.3` names the actor in the tuple for exactly this reason.
    #[test]
    fn the_window_is_keyed_per_actor_as_well_as_per_key() {
        let mut table = IdempotencyTable::default();
        table.put_running(
            Actor::Cli,
            &key("shared"),
            CommandId("cmd-cli".to_owned()),
            &accepted(11, 1),
        );
        assert!(table.get(Actor::Cli, &key("shared")).is_some());
        assert!(
            table.get(Actor::Tui, &key("shared")).is_none(),
            "a different actor must not replay someone else's job"
        );
    }

    /// Replaying an existing key re-inserts it, and the record must keep the answer the first call got
    /// rather than a freshly built one (round 9 rebuilt `Accepted` and the replay diverged).
    #[test]
    fn a_replay_reads_back_the_original_answer_verbatim() {
        let mut table = IdempotencyTable::default();
        let original = accepted(7, 42);
        table.put_running(
            Actor::Cli,
            &key("k"),
            CommandId("cmd-7".to_owned()),
            &original,
        );
        let record = table.get(Actor::Cli, &key("k")).expect("record");
        assert_eq!(record.accepted, original);
        assert_eq!(record.job_id, 7);
        assert_eq!(record.status, IdempotencyStatus::Running);
    }
}
