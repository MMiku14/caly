use caly_api::{
    ApplyRequest, CapabilityQuery, CapabilityReport, DeploymentPlanView, PipelineExplain,
    PipelineExplainRequest,
};
use caly_cap::{
    default_coverage_matrix_document, default_registry_document, merged_coverage_matrix,
    merged_registry_document, CapabilityDecisionKind, CapabilityState,
};
use caly_core::{CoreAdapter, MockCoreAdapter};
use caly_domain::{
    attach_group_selection, attach_sources, group_selection, override_rule, replace_tun,
    selection_memory, skeleton_profile, source_ref, OverrideRule, OverrideScope, Profile,
    SelectionMemory,
};
use caly_ir::{CoreTarget, NormalizedSource, RoutingMode, SourceKind};
use caly_mihomo::MihomoAdapter;
use caly_pipeline::{
    project_apply_workflow, run_pipeline_for_adapter, PipelineRequest, StageContext,
};
use caly_singbox::SingBoxAdapter;
use caly_storage::{
    build_apply_storage_projection, ApplyStorageProjection, ApplyStorageProjectionInput,
    ApplyTxnId, RevisionNumber,
};

use crate::command::{Command, CommandKind};
use crate::service::EngineHandle;

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct ApplyWorkflowRequest {
    pub profile: Profile,
    pub normalized_sources: Vec<NormalizedSource>,
    pub overrides: Vec<OverrideRule>,
    pub selection_memory: Option<SelectionMemory>,
    pub strict_mode: bool,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct ResolvedProfileSummary {
    pub profile_id: String,
    pub revision_id: String,
    pub target_core: String,
    pub source_count: usize,
    pub node_count: usize,
    pub group_count: usize,
    pub rule_count: usize,
    pub selected_groups: Vec<String>,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct CompilationSummary {
    pub core_kind: String,
    pub core_version: String,
    pub binary_digest: String,
    pub artifact_digest: String,
    pub artifact_file_name: String,
    pub artifact_media_type: String,
    pub artifact_bytes: usize,
    pub native_accepted: bool,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct CapabilitySummary {
    pub required_count: usize,
    pub allowed_count: usize,
    pub warning_count: usize,
    pub blocked_count: usize,
    pub must_escalate_apply: bool,
    pub decisions: Vec<String>,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct StorageProjectionSummary {
    pub apply_txn_id: String,
    pub apply_journal_id: String,
    pub snapshot_id: String,
    pub revision_id: String,
    pub artifact_object_digest: String,
    pub runtime_path: String,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct ResolvedSourceSummary {
    pub id: String,
    pub label: String,
    pub kind: String,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct ResolvedNodeSummary {
    pub id: String,
    pub label: String,
    pub protocol: String,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct ResolvedGroupSummary {
    pub id: String,
    pub label: String,
    pub selected: Option<String>,
    pub members: Vec<String>,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct ResolvedRuleSummary {
    pub id: String,
    pub label: String,
    pub action: String,
    pub target: Option<String>,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct ResolvedNetworkSummary {
    pub dns_mode: Option<String>,
    pub dns_servers: Vec<String>,
    pub tun_enabled: bool,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct ApplyWorkflowResult {
    pub diagnostics: Vec<String>,
    pub apply_plan_kind: String,
    pub apply_plan_reasons: Vec<String>,
    pub apply_issue_summaries: Vec<String>,
    pub effect_plan_present: bool,
    /// Typed effect plan for execution. `effect_steps` above is only a *presentation*
    /// projection; the executor consumes this field so step semantics survive into
    /// execution (docs/APPLY_EXECUTION_CENTERLINE.md 12: "effect execution 不再只是字符串投影").
    pub effect_plan: Option<caly_plan::EffectPlan>,
    /// The compiled artifact this workflow would deploy (round 56): the engine remembers
    /// it on commit, and the next apply plans against it as `current`.
    pub compiled_artifact: caly_ir::CompiledArtifact,
    pub effect_steps: Vec<String>,
    pub compensation_steps: Vec<String>,
    pub resolved: ResolvedProfileSummary,
    pub resolved_sources: Vec<ResolvedSourceSummary>,
    pub resolved_nodes: Vec<ResolvedNodeSummary>,
    pub resolved_groups: Vec<ResolvedGroupSummary>,
    pub resolved_rules: Vec<ResolvedRuleSummary>,
    pub resolved_network: ResolvedNetworkSummary,
    pub compilation: CompilationSummary,
    pub capability: CapabilitySummary,
    pub storage: StorageProjectionSummary,
    pub storage_projection: ApplyStorageProjection,
}

pub fn plan_apply_with_adapter(
    adapter: &dyn CoreAdapter,
    request: ApplyWorkflowRequest,
    current: Option<&caly_ir::CompiledArtifact>,
) -> Result<ApplyWorkflowResult, String> {
    let strict_mode = request.strict_mode;
    let output = run_pipeline_for_adapter(
        PipelineRequest {
            profile: request.profile,
            normalized_sources: request.normalized_sources,
            overrides: request.overrides,
            selection_memory: request.selection_memory,
            strict_mode,
        },
        StageContext {
            pipeline_epoch: 1,
            adapter_version: 1,
            strict_mode,
        },
        adapter,
        // Round 56: the artifact the engine last deployed, when there is one. `None`
        // means "nothing deployed yet" — a first install — and the plan says so.
        current,
    )?;

    let resolved_summary = summarize_resolved_profile(&output.resolved_profile);
    let resolved_sources = summarize_sources(&output.resolved_profile);
    let resolved_nodes = summarize_nodes(&output.resolved_profile);
    let resolved_groups = summarize_groups(&output.resolved_profile);
    let resolved_rules = summarize_rules(&output.resolved_profile);
    let resolved_network = summarize_network(&output.resolved_profile);
    let capability_summary = summarize_capability_validation(output.capability_validation.as_ref());
    let compile = output
        .compile
        .clone()
        .ok_or_else(|| "pipeline produced no compile output".to_owned())?;
    let storage_projection = build_storage_projection(&compile, &output.resolved_profile)?;
    let workflow = project_apply_workflow(output)
        .ok_or_else(|| "pipeline produced no apply workflow".to_owned())?;

    Ok(ApplyWorkflowResult {
        // Round 56: the artifact this workflow compiled — the deploy truth the engine
        // remembers on commit, so the *next* plan is planned against what is actually
        // running (`ADR-044 §5.3`).
        compiled_artifact: compile.artifact.clone(),
        diagnostics: workflow
            .diagnostics
            .into_iter()
            .map(|diagnostic| diagnostic.summary)
            .collect(),
        apply_plan_kind: format!("{:?}", workflow.apply_plan.kind),
        apply_plan_reasons: workflow.apply_plan.reasons.clone(),
        apply_issue_summaries: workflow
            .apply_plan
            .issues
            .iter()
            .map(|issue| issue.summary.clone())
            .collect(),
        effect_plan_present: workflow.effect_plan.is_some(),
        effect_plan: workflow.effect_plan.clone(),
        effect_steps: workflow
            .effect_plan
            .as_ref()
            .map(|plan| {
                plan.steps
                    .iter()
                    .enumerate()
                    .map(|(index, step)| render_effect_step(index, step))
                    .collect::<Vec<_>>()
            })
            .unwrap_or_default(),
        compensation_steps: workflow
            .effect_plan
            .as_ref()
            .map(|plan| {
                plan.compensations
                    .iter()
                    .enumerate()
                    .map(|(index, step)| render_effect_step(index, step))
                    .collect::<Vec<_>>()
            })
            .unwrap_or_default(),
        resolved: resolved_summary,
        resolved_sources,
        resolved_nodes,
        resolved_groups,
        resolved_rules,
        resolved_network,
        compilation: CompilationSummary {
            core_kind: compile.identity.kind.as_str().to_owned(),
            core_version: compile.identity.version.clone(),
            binary_digest: compile.identity.binary_digest.clone(),
            artifact_digest: compile.artifact.artifact_digest.0.clone(),
            artifact_file_name: compile.artifact.file_name_hint.clone(),
            artifact_media_type: compile.artifact.media_type.clone(),
            artifact_bytes: compile.artifact.size_bytes(),
            native_accepted: compile.native_validation.accepted,
        },
        capability: capability_summary,
        storage: StorageProjectionSummary {
            apply_txn_id: storage_projection.apply_journal.apply_txn_id.0.clone(),
            apply_journal_id: storage_projection.apply_journal.journal_id.0.clone(),
            snapshot_id: storage_projection.snapshot_candidate.snapshot_id.0.clone(),
            revision_id: storage_projection.snapshot_candidate.revision_id.0.clone(),
            artifact_object_digest: storage_projection.artifact_object.object.digest.0.clone(),
            runtime_path: storage_projection.materialization.runtime_path.clone(),
        },
        storage_projection,
    })
}

pub fn plan_apply_for_target(
    target: CoreTarget,
    request: ApplyWorkflowRequest,
    current: Option<&caly_ir::CompiledArtifact>,
) -> Result<ApplyWorkflowResult, String> {
    let adapter = adapter_for_target(target);
    plan_apply_with_adapter(adapter.as_ref(), request, current)
}

pub fn plan_apply_with_mock(request: ApplyWorkflowRequest) -> Result<ApplyWorkflowResult, String> {
    let adapter = MockCoreAdapter;
    plan_apply_with_adapter(&adapter, request, None)
}

pub fn plan_apply_request(request: ApplyRequest) -> Result<ApplyWorkflowResult, String> {
    plan_apply_request_with_current(request, None)
}

/// Plan an apply against what is *actually deployed* (round 56, `ADR-044 §5.3`): the
/// caller hands the engine's last committed artifact, and the adapter's plan kind stops
/// being a first install the moment something runs. `plan_apply_request` stays the
/// first-install preview it always was.
pub fn plan_apply_request_with_current(
    request: ApplyRequest,
    current: Option<&caly_ir::CompiledArtifact>,
) -> Result<ApplyWorkflowResult, String> {
    let workflow_request = demo_apply_request_from_api(&request);
    let target =
        infer_target_from_profile_id(&request.profile_id.0, workflow_request.profile.core_target);
    plan_apply_for_target(target, workflow_request, current)
}

pub fn deployment_plan_view(request: ApplyRequest) -> Result<DeploymentPlanView, String> {
    let workflow = plan_apply_request(request)?;
    let mut warnings = workflow.diagnostics.clone();
    warnings.extend(workflow.apply_issue_summaries.clone());
    warnings.extend(workflow.capability.decisions.clone());
    Ok(DeploymentPlanView {
        plan_kind: workflow.apply_plan_kind,
        warnings,
        steps: workflow.effect_steps,
    })
}

pub fn explain_pipeline(request: PipelineExplainRequest) -> Result<PipelineExplain, String> {
    let workflow = plan_apply_request(ApplyRequest {
        profile_id: request.profile_id.clone(),
        dry_run: true,
        strict: false,
    })?;

    let mut stages = vec![
        format!("profile:{}", workflow.resolved.profile_id),
        format!("resolved.revision:{}", workflow.resolved.revision_id),
        format!("resolved.target:{}", workflow.resolved.target_core),
        format!(
            "resolved.graph:nodes={} groups={} rules={} sources={}",
            workflow.resolved.node_count,
            workflow.resolved.group_count,
            workflow.resolved.rule_count,
            workflow.resolved.source_count,
        ),
        format!(
            "compile.core:{}@{}",
            workflow.compilation.core_kind, workflow.compilation.core_version
        ),
        format!(
            "compile.artifact:{} {} {}B",
            workflow.compilation.artifact_file_name,
            workflow.compilation.artifact_media_type,
            workflow.compilation.artifact_bytes,
        ),
        format!(
            "validate.native:accepted={}",
            workflow.compilation.native_accepted
        ),
        format!(
            "validate.capabilities:required={} warn={} blocked={} escalate={}",
            workflow.capability.required_count,
            workflow.capability.warning_count,
            workflow.capability.blocked_count,
            workflow.capability.must_escalate_apply,
        ),
        format!("apply.plan:{}", workflow.apply_plan_kind),
        format!(
            "storage.projection:txn={} snapshot={} runtime={}",
            workflow.storage.apply_txn_id,
            workflow.storage.snapshot_id,
            workflow.storage.runtime_path,
        ),
    ];

    if !workflow.resolved.selected_groups.is_empty() {
        stages.push(format!(
            "resolve.selections:{}",
            workflow.resolved.selected_groups.join(", ")
        ));
    }
    stages.extend(
        workflow
            .capability
            .decisions
            .iter()
            .map(|line| format!("capability.{line}")),
    );
    stages.extend(
        workflow
            .effect_steps
            .iter()
            .map(|step| format!("effect.{step}")),
    );

    Ok(PipelineExplain {
        stages,
        diagnostics: workflow.diagnostics,
    })
}

pub fn capability_report_for_query(query: CapabilityQuery) -> Result<CapabilityReport, String> {
    let target = infer_target_from_query(&query.target)?;
    let adapter = adapter_for_target(target);
    let identity = adapter.inspect_binary()?;
    let capabilities = adapter.capability_set(&identity)?;
    let registry =
        merged_registry_document(&default_registry_document(), &capabilities.descriptors);
    let coverage = merged_coverage_matrix(
        &default_coverage_matrix_document(),
        &capabilities.descriptors,
        core_target_name(target),
    );

    let mut supported = Vec::new();
    let mut warnings = Vec::new();
    let mut blocked = Vec::new();

    for descriptor in &registry.capabilities {
        let state = coverage
            .matrix
            .iter()
            .find(|entry| {
                entry.capability_key == descriptor.key
                    && (entry.target_core == core_target_name(target) || entry.target_core == "*")
            })
            .map(|entry| entry.state)
            .unwrap_or(descriptor.state);
        let line = format!(
            "{}={:?}/{:?}",
            descriptor.key.0, state, descriptor.support_level
        );
        match state {
            CapabilityState::SupportedExact | CapabilityState::SupportedNativeOnly => {
                supported.push(line)
            }
            CapabilityState::Experimental | CapabilityState::PreservedOpaque => warnings.push(line),
            CapabilityState::Unsupported | CapabilityState::Unknown => blocked.push(line),
        }
    }

    supported.sort();
    warnings.sort();
    blocked.sort();

    Ok(CapabilityReport {
        target: query.target,
        supported,
        warnings,
        blocked,
    })
}

pub fn classify_apply_command(command: &Command) -> bool {
    matches!(
        command.kind,
        CommandKind::ProfileApply(_) | CommandKind::ProfileRollback(_)
    )
}

pub fn apply_workflow_from_handle(
    handle: &EngineHandle,
    request: ApplyWorkflowRequest,
) -> Result<ApplyWorkflowResult, String> {
    let target = infer_target_from_profile_id(&request.profile.id.0, request.profile.core_target);
    // The handle is the state owner: planning "what would happen now" against anything but
    // its own last deployment would be a first-install preview wearing a handle's clothes.
    let current = handle
        .last_compiled_artifact()
        .map_err(|message| format!("engine state unavailable: {message}"))?;
    plan_apply_for_target(target, request, current.as_ref())
}

fn summarize_capability_validation(
    report: Option<&caly_pipeline::CapabilityValidationReport>,
) -> CapabilitySummary {
    let Some(report) = report else {
        return CapabilitySummary {
            required_count: 0,
            allowed_count: 0,
            warning_count: 0,
            blocked_count: 0,
            must_escalate_apply: false,
            decisions: Vec::new(),
        };
    };

    let mut allowed_count = 0;
    let mut warning_count = 0;
    let mut blocked_count = 0;
    let mut decisions = Vec::new();

    for decision in &report.evaluation.decisions {
        match decision.kind {
            CapabilityDecisionKind::Allow => allowed_count += 1,
            CapabilityDecisionKind::AllowWithWarning => warning_count += 1,
            CapabilityDecisionKind::Block => blocked_count += 1,
        }
        decisions.push(format!(
            "{}={:?}/{:?}/{:?}",
            decision.key.0, decision.kind, decision.state, decision.support_level
        ));
    }

    CapabilitySummary {
        required_count: report.evaluation.required.len(),
        allowed_count,
        warning_count,
        blocked_count,
        must_escalate_apply: report.evaluation.must_escalate_apply,
        decisions,
    }
}

fn build_storage_projection(
    compile: &caly_pipeline::CompilationOutput,
    profile: &caly_ir::ResolvedProfile,
) -> Result<ApplyStorageProjection, String> {
    // Round 56: a Noop plan (the artifact is already deployed) has no plan to name. The
    // journal still records WHICH deployment made it a noop, so the id carries the
    // artifact digest: it cannot collide with a real plan id (`mihomo-effect-plan-…`) and
    // says exactly what ran — nothing, because this artifact is already live.
    let effect_plan_id = compile
        .apply_planning
        .effect_plan
        .as_ref()
        .map(|plan| plan.id.0.clone())
        .unwrap_or_else(|| format!("noop:{}", compile.artifact.artifact_digest.0));
    let validation_summary = compile
        .native_validation
        .issues
        .iter()
        .map(|issue| format!("{}:{}", issue.code, issue.summary))
        .collect::<Vec<_>>()
        .join(" | ");

    Ok(build_apply_storage_projection(
        ApplyStorageProjectionInput {
            apply_txn_id: ApplyTxnId(format!("txn:{}", profile.revision_id.0)),
            trace_id: format!("trace:{}", profile.profile_id.0),
            job_id: None,
            profile_id: profile.profile_id.0.clone(),
            revision_id: caly_storage::RevisionId(profile.revision_id.0.clone()),
            revision_number: RevisionNumber(1),
            semantic_digest: profile.semantic_digest.0.clone(),
            compiled_artifact_digest: compile.artifact.artifact_digest.0.clone(),
            core_binary_digest: compile.identity.binary_digest.clone(),
            core_identity: format!(
                "{}@{}",
                compile.identity.kind.as_str(),
                compile.identity.version
            ),
            effect_plan_id,
            apply_plan_summary: format!("{:?}", compile.apply_planning.apply_plan.kind),
            artifact_file_name: compile.artifact.file_name_hint.clone(),
            artifact_size_bytes: compile.artifact.size_bytes() as u64,
            // The store needs the bytes: content addressing without content is only an index.
            artifact_bytes: compile.artifact.bytes.bytes.clone(),
            content_type: compile.artifact.media_type.clone(),
            runtime_path: format!(
                "runtime/{}/{}",
                profile.profile_id.0, compile.artifact.entrypoint
            ),
            selection_memory_digest: Some(selection_memory_digest(profile)),
            validation_summary,
            previous_snapshot_id: None,
            created_at_unix_ms: 0,
        },
    ))
}

fn selection_memory_digest(profile: &caly_ir::ResolvedProfile) -> String {
    profile
        .groups
        .iter()
        .filter_map(|group| {
            group
                .selected
                .as_ref()
                .map(|selected| format!("{}={}", group.id.0, selected.0))
        })
        .collect::<Vec<_>>()
        .join("|")
}

fn summarize_sources(profile: &caly_ir::ResolvedProfile) -> Vec<ResolvedSourceSummary> {
    if profile.rulesets.is_empty() {
        return vec![ResolvedSourceSummary {
            id: format!("{}-source", profile.profile_id.0),
            label: "Derived Source".to_owned(),
            kind: "subscription".to_owned(),
        }];
    }

    profile
        .rulesets
        .iter()
        .map(|ruleset| ResolvedSourceSummary {
            id: ruleset
                .source
                .as_ref()
                .map(|source| source.0.clone())
                .unwrap_or_else(|| ruleset.id.0.clone()),
            label: ruleset.label.clone(),
            kind: "subscription".to_owned(),
        })
        .collect()
}

fn summarize_nodes(profile: &caly_ir::ResolvedProfile) -> Vec<ResolvedNodeSummary> {
    profile
        .nodes
        .iter()
        .map(|node| ResolvedNodeSummary {
            id: node.id.0.clone(),
            label: node.label.clone(),
            protocol: proxy_protocol_name(node.protocol).to_owned(),
        })
        .collect()
}

fn summarize_groups(profile: &caly_ir::ResolvedProfile) -> Vec<ResolvedGroupSummary> {
    profile
        .groups
        .iter()
        .map(|group| ResolvedGroupSummary {
            id: group.id.0.clone(),
            label: group.label.clone(),
            selected: group.selected.as_ref().map(|selected| selected.0.clone()),
            members: group
                .members
                .iter()
                .map(|member| member.0.clone())
                .collect(),
        })
        .collect()
}

fn summarize_rules(profile: &caly_ir::ResolvedProfile) -> Vec<ResolvedRuleSummary> {
    profile
        .rules
        .iter()
        .map(|rule| ResolvedRuleSummary {
            id: rule.id.0.clone(),
            label: rule.label.clone(),
            action: rule_action_name(rule.action).to_owned(),
            target: rule
                .target_group
                .as_ref()
                .map(|group| group.0.clone())
                .or_else(|| {
                    rule.target_outbound
                        .as_ref()
                        .map(|outbound| outbound.0.clone())
                }),
        })
        .collect()
}

fn summarize_network(profile: &caly_ir::ResolvedProfile) -> ResolvedNetworkSummary {
    ResolvedNetworkSummary {
        dns_mode: profile
            .dns
            .as_ref()
            .map(|dns| dns_mode_name(dns.mode).to_owned()),
        dns_servers: profile
            .dns
            .as_ref()
            .map(|dns| dns.servers.clone())
            .unwrap_or_default(),
        tun_enabled: profile.tun.as_ref().map(|tun| tun.enabled).unwrap_or(false),
    }
}

fn summarize_resolved_profile(profile: &caly_ir::ResolvedProfile) -> ResolvedProfileSummary {
    ResolvedProfileSummary {
        profile_id: profile.profile_id.0.clone(),
        revision_id: profile.revision_id.0.clone(),
        target_core: core_target_name(profile.core_target).to_owned(),
        source_count: profile.rulesets.len(),
        node_count: profile.nodes.len(),
        group_count: profile.groups.len(),
        rule_count: profile.rules.len(),
        selected_groups: profile
            .groups
            .iter()
            .filter_map(|group| {
                group
                    .selected
                    .as_ref()
                    .map(|selected| format!("{}={}", group.id.0, selected.0))
            })
            .collect(),
    }
}

/// Presentation projection of one effect step.
///
/// The step text itself now comes from `executor::step_label`, so there is exactly one
/// `EffectStep` -> text mapping in the crate. Previously `apply.rs` kept a second, slightly
/// different 11-arm match over the same enum, which is exactly how DTO text and execution
/// reporting drift apart.
fn render_effect_step(index: usize, step: &caly_plan::EffectStep) -> String {
    format!("{:02}: {}", index + 1, crate::executor::step_label(step))
}

fn adapter_for_target(target: CoreTarget) -> Box<dyn CoreAdapter> {
    match target {
        CoreTarget::Mihomo => Box::new(MihomoAdapter),
        CoreTarget::SingBox => Box::new(SingBoxAdapter),
        CoreTarget::Auto => Box::new(MihomoAdapter),
    }
}

fn demo_apply_request_from_api(request: &ApplyRequest) -> ApplyWorkflowRequest {
    let target = infer_target_from_profile_id(&request.profile_id.0, CoreTarget::Auto);
    let routing_mode = if request.profile_id.0.contains("global") {
        RoutingMode::Global
    } else if request.profile_id.0.contains("direct") {
        RoutingMode::Direct
    } else {
        RoutingMode::Rule
    };

    let mut profile = skeleton_profile(
        request.profile_id.0.clone(),
        format!("Profile {}", request.profile_id.0),
        target,
        routing_mode,
    );
    profile = attach_sources(
        profile,
        vec![
            source_ref(
                format!("{}-src-primary", request.profile_id.0),
                "Primary Source",
            ),
            source_ref(
                format!("{}-src-fallback", request.profile_id.0),
                "Fallback Source",
            ),
        ],
    );
    profile = attach_group_selection(
        profile,
        format!("{}-src-primary-group-main", request.profile_id.0),
        primary_selection_label(target),
    );

    // Round 58: the sing-box spawn face is real, so a sing-box demo no longer hides
    // behind a forced tun (which NetApply refuses); tun stays opt-in by name for every
    // target — the TUN refusal judge covers that path (`ADR-046 §3`).
    let wants_tun = request.profile_id.0.contains("tun");
    if wants_tun {
        profile = replace_tun(profile, true, true, request.profile_id.0.contains("strict"));
    }

    let normalized_sources = vec![
        normalized_source(
            format!("{}-src-primary", request.profile_id.0),
            SourceKind::Subscription,
            2,
            2,
            2,
        ),
        normalized_source(
            format!("{}-src-fallback", request.profile_id.0),
            if request.profile_id.0.contains("inline") {
                SourceKind::Inline
            } else {
                SourceKind::LocalFile
            },
            1,
            1,
            1,
        ),
    ];

    let mut overrides = vec![override_rule(
        "ensure-dns-mode",
        OverrideScope::Profile,
        "dns.mode",
        "set",
        Some(if wants_tun { "fake-ip" } else { "mixed" }.to_owned()),
    )];
    if request.profile_id.0.contains("global") {
        overrides.push(override_rule(
            "routing-global",
            OverrideScope::Profile,
            "routing.mode",
            "set",
            Some("global".to_owned()),
        ));
    }
    if request.profile_id.0.contains("sing") {
        overrides.push(override_rule(
            "pin-singbox",
            OverrideScope::Profile,
            "profile.core_target",
            "set",
            Some("sing-box".to_owned()),
        ));
    }

    let memory = selection_memory(
        &profile,
        vec![group_selection(
            format!("{}-src-fallback-group-main", request.profile_id.0),
            fallback_selection_label(target),
        )],
    );

    ApplyWorkflowRequest {
        profile,
        normalized_sources,
        overrides,
        selection_memory: Some(memory),
        strict_mode: request.strict,
    }
}

fn normalized_source(
    id: impl Into<String>,
    source_kind: SourceKind,
    node_count_estimate: usize,
    group_count_estimate: usize,
    rule_count_estimate: usize,
) -> NormalizedSource {
    let id = id.into();
    NormalizedSource {
        id: caly_ir::SourceId::new(id.clone()),
        raw_digest: caly_ir::Digest(format!("raw:{id}")),
        source_kind,
        node_count_estimate,
        group_count_estimate,
        rule_count_estimate,
    }
}

fn primary_selection_label(target: CoreTarget) -> &'static str {
    match target {
        CoreTarget::SingBox => "Primary Source WireGuard 01",
        _ => "Primary Source Shadowsocks 01",
    }
}

fn fallback_selection_label(_target: CoreTarget) -> &'static str {
    "Fallback Source VMess 01"
}

fn infer_target_from_profile_id(profile_id: &str, declared: CoreTarget) -> CoreTarget {
    match declared {
        CoreTarget::Mihomo | CoreTarget::SingBox => declared,
        CoreTarget::Auto => {
            let lowered = profile_id.to_ascii_lowercase();
            if lowered.contains("sing") || lowered.contains("sb") {
                CoreTarget::SingBox
            } else {
                CoreTarget::Mihomo
            }
        }
    }
}

fn infer_target_from_query(target: &str) -> Result<CoreTarget, String> {
    match target.trim().to_ascii_lowercase().as_str() {
        "mihomo" | "meta" => Ok(CoreTarget::Mihomo),
        "sing-box" | "singbox" | "sb" => Ok(CoreTarget::SingBox),
        "auto" => Ok(CoreTarget::Auto),
        other => Err(format!("unknown capability target: {other}")),
    }
}

fn proxy_protocol_name(protocol: caly_ir::ProxyProtocol) -> &'static str {
    match protocol {
        caly_ir::ProxyProtocol::Shadowsocks => "shadowsocks",
        caly_ir::ProxyProtocol::Vmess => "vmess",
        caly_ir::ProxyProtocol::Vless => "vless",
        caly_ir::ProxyProtocol::Trojan => "trojan",
        caly_ir::ProxyProtocol::Hysteria2 => "hysteria2",
        caly_ir::ProxyProtocol::Tuic => "tuic",
        caly_ir::ProxyProtocol::WireGuard => "wireguard",
        caly_ir::ProxyProtocol::Unknown => "unknown",
    }
}

fn rule_action_name(action: caly_ir::RuleAction) -> &'static str {
    match action {
        caly_ir::RuleAction::UseGroup => "use-group",
        caly_ir::RuleAction::Direct => "direct",
        caly_ir::RuleAction::Reject => "reject",
        caly_ir::RuleAction::UseOutbound => "use-outbound",
    }
}

fn dns_mode_name(mode: caly_ir::DnsMode) -> &'static str {
    match mode {
        caly_ir::DnsMode::System => "system",
        caly_ir::DnsMode::FakeIp => "fake-ip",
        caly_ir::DnsMode::Redirect => "redirect",
        caly_ir::DnsMode::Mixed => "mixed",
    }
}

fn core_target_name(target: CoreTarget) -> &'static str {
    match target {
        CoreTarget::Mihomo => "mihomo",
        CoreTarget::SingBox => "sing-box",
        CoreTarget::Auto => "auto",
    }
}
