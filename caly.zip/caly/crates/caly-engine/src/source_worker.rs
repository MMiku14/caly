//! Source update worker: locator lookup -> bounded HTTP body -> pure normalization -> CAS.
//!
//! This is the first real source vertical slice. The worker owns orchestration only; URI decoding
//! remains in `caly-pipeline::source`, and host/network/storage contact remains behind `Http` and
//! `StorageBackend` (`ADR-011`, `ADR-029`, `ADR-049`). A source id or display label is never
//! interpreted as a URL. An endpoint must be registered explicitly by the composition root.

use std::collections::BTreeMap;
use std::sync::{Arc, Mutex};

use caly_common::{Actor, RequestContext, TraceId};
use caly_io::{drive, Clock, FetchReq, FetchRoute, Http};
use caly_ir::{NormalizedSource, RawSource, SourceId, SourceKind};
use caly_pipeline::{parse_source, ParsedSource, SourceInput, MAX_SOURCE_BYTES};
use caly_storage::{
    CasObjectRef, CasWriteIntent, ObjectDigest, ObjectKind, SourceIndexRecord, StorageBackend,
};

use crate::recovery::{run_ready, run_ready_in};
use crate::run_limits::{RunLimits, StoreRefusal};
use crate::source_persistence::{
    record_from_report, report_from_record, route_from_text, source_kind_from_text,
};

/// The explicit metadata needed to fetch one source. A locator is data supplied by the caller,
/// never a value derived from `SourceId` or `SourceRef.label`.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct SourceEndpoint {
    pub source_id: SourceId,
    pub kind: SourceKind,
    pub label: String,
    pub locator: String,
    pub route: FetchRoute,
    pub max_body_bytes: u64,
    pub media_type: Option<String>,
    pub strict_mode: bool,
}

impl SourceEndpoint {
    pub fn subscription(
        source_id: SourceId,
        label: impl Into<String>,
        locator: impl Into<String>,
        max_body_bytes: u64,
    ) -> Self {
        Self {
            source_id,
            kind: SourceKind::Subscription,
            label: label.into(),
            locator: locator.into(),
            route: FetchRoute::Direct,
            max_body_bytes,
            media_type: Some("text/plain".to_owned()),
            strict_mode: false,
        }
    }

    /// Construct an endpoint from an external string id without making callers depend on the IR
    /// id wrapper. This is the composition-root convenience used by `calyd`.
    pub fn subscription_named(
        source_id: impl Into<String>,
        label: impl Into<String>,
        locator: impl Into<String>,
        max_body_bytes: u64,
    ) -> Self {
        Self::subscription(SourceId::new(source_id), label, locator, max_body_bytes)
    }

    /// Lift a domain source reference without inventing a locator. This is the only adapter from
    /// profile metadata to the fetch worker; a legacy `SourceRef` with `None` remains an explicit
    /// configuration error.
    pub fn locator(&self) -> &str {
        &self.locator
    }

    pub fn from_source_ref(
        reference: &caly_domain::SourceRef,
        max_body_bytes: u64,
    ) -> Result<Self, String> {
        let locator = reference.locator.clone().ok_or_else(|| {
            format!(
                "source {} has no explicit locator; refusing to derive one from its label",
                reference.id.0
            )
        })?;
        Ok(Self::subscription(
            reference.id.clone(),
            reference.label.clone(),
            locator,
            max_body_bytes,
        ))
    }
}

/// The durable/content result of one successful source update.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct SourceUpdateReport {
    pub source_id: SourceId,
    pub raw: RawSource,
    pub normalized: NormalizedSource,
    pub raw_object: CasObjectRef,
    pub diagnostics: Vec<caly_pipeline::Diagnostic>,
    pub provenance: caly_pipeline::ProvenanceDelta,
    /// True when the server answered `304 Not Modified` and the worker verified/reused the
    /// previously stored raw body instead of writing a second copy.
    pub reused_raw_body: bool,
    pub etag: Option<String>,
    pub last_modified: Option<String>,
}

/// The durable facts a source inspection query is allowed to project. It deliberately carries the
/// typed report rather than reading the process-local cache: an inspection must explain what the
/// source index can reconstruct after restart, not what happened to remain in one worker's heap.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct SourceInspectionReport {
    pub endpoint: SourceEndpoint,
    pub report: SourceUpdateReport,
    pub updated_at_unix_ms: i64,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct SourcePreviewReport {
    pub node_count: usize,
    pub group_count: usize,
    pub warnings: Vec<String>,
}

/// Parse an inline body through the same pure source boundary used by `SourceUpdate`. Queries do
/// not get a second "count non-empty text" implementation: preview and update must agree on what
/// a node is, while the query returns only diagnostic summaries.
pub fn preview_inline_source(source_id: &str, bytes: Vec<u8>) -> SourcePreviewReport {
    let input = SourceInput {
        id: SourceId::new(source_id),
        kind: SourceKind::Inline,
        origin_label: "inline preview".to_owned(),
        locator: None,
        bytes,
        media_type: Some("text/plain".to_owned()),
    };
    match parse_source(&input, false) {
        Ok(parsed) => SourcePreviewReport {
            node_count: parsed.normalized.nodes.len(),
            group_count: parsed.normalized.group_count_estimate,
            warnings: parsed
                .diagnostics
                .into_iter()
                .map(|diagnostic| diagnostic.summary)
                .collect(),
        },
        Err(error) => SourcePreviewReport {
            node_count: 0,
            group_count: 0,
            warnings: vec![error],
        },
    }
}

/// Worker seam owned by the engine. The default implementation refuses explicitly, rather than
/// reporting a green "scheduled" job when no locator/HTTP backend has been connected.
pub trait SourceUpdateWorker: Send + Sync + 'static {
    fn update(&self, source_id: &str, ctx: &RequestContext) -> Result<SourceUpdateReport, String>;

    /// Read the durable source-index projection used by inspection. Returning `None` means the
    /// worker has no durable record for this id; it must not be filled from a process-local cache by
    /// the default implementation, because that would make the query change meaning across restart.
    fn inspect(
        &self,
        _source_id: &str,
        _ctx: &RequestContext,
    ) -> Result<Option<SourceInspectionReport>, String> {
        Ok(None)
    }

    /// A durable worker may hand already-verified normalized sources to the engine state when it is
    /// installed. The default is an empty restore set for stateless/custom workers.
    fn restored_sources(&self) -> Result<Vec<NormalizedSource>, String> {
        Ok(Vec::new())
    }

    /// Composition roots may expose endpoint registration without downcasting the worker. The
    /// default refuses because not every worker has a mutable locator registry.
    fn register_endpoint(&self, _endpoint: SourceEndpoint) -> Result<(), String> {
        Err("this source worker does not expose an endpoint registry".to_owned())
    }
}

#[derive(Clone, Debug, Default)]
pub struct UnconfiguredSourceUpdateWorker;

impl SourceUpdateWorker for UnconfiguredSourceUpdateWorker {
    fn update(&self, source_id: &str, _ctx: &RequestContext) -> Result<SourceUpdateReport, String> {
        Err(format!(
            "source update {source_id} is unavailable: no explicit source locator/HTTP worker is configured"
        ))
    }
}

/// HTTP-backed source worker. It is usable with `StdHttp` and `SimHttp`; the latter is how the
/// source boundary gets deterministic contract coverage without making the pipeline know about a
/// simulator.
#[derive(Clone, Debug)]
struct CachedSource {
    report: SourceUpdateReport,
}

/// Keep the source pipeline's refusal vocabulary typed until the last public seam. The worker's
/// trait predates `StoreRefusal`, so its compatibility surface is still `String`; the string must
/// nevertheless say whether the caller cancelled, the injected clock expired, or a port/backend
/// answered. In particular, a pending HTTP call is not silently relabelled as a timeout.
fn source_limit_error(
    source_id: &str,
    phase: &str,
    fault: &caly_io::IoFault,
    limits: &RunLimits,
) -> String {
    let refusal = StoreRefusal::from_fault(fault, limits);
    format!(
        "source {source_id} {phase} refused ({:?}): {refusal}",
        refusal.kind
    )
}

fn source_store_refusal(source_id: &str, phase: &str, refusal: StoreRefusal) -> String {
    format!(
        "source {source_id} {phase} refused ({:?}): {refusal}",
        refusal.kind
    )
}

fn source_backend_error(
    source_id: &str,
    phase: &str,
    error: &caly_storage::StorageError,
) -> String {
    let refusal = StoreRefusal::from_storage_error(error);
    format!(
        "source {source_id} {phase} failed ({:?}): {refusal}",
        refusal.kind
    )
}

/// Probe the same `Drive` used for the actual port calls at a phase boundary. This is deliberately a
/// ready future: it does not bill an IO request or manufacture progress, it only asks the injected
/// cancellation/deadline judge whether the next synchronous phase may start.
fn check_source_limits(
    source_id: &str,
    phase: &str,
    limits: &RunLimits,
) -> Result<(), String> {
    drive(std::future::ready(()), limits.drive())
        .map(|_| ())
        .map_err(|fault| source_limit_error(source_id, phase, &fault, limits))
}

/// Anchor a relative caller deadline once at the source composition root and carry that absolute
/// instant into every port context. `RunLimits` owns the arithmetic; this copy only transports the
/// result to `FsStore`/`StdHttp`, which already know how to compare `deadline_mono_ms` with their
/// injected clock. No host clock is read here.
fn anchored_source_context(ctx: &RequestContext, limits: &RunLimits) -> RequestContext {
    let mut anchored = ctx.clone();
    if anchored.deadline_mono_ms.is_none() {
        anchored.deadline_mono_ms = limits.deadline().map(|deadline| deadline.0);
    }
    anchored
}

/// Convert the verified engine projection into the API's redacted source-inspection model. Keeping
/// this next to the typed durable decoder prevents the daemon façade from re-decoding opaque fields
/// or falling back to its active-profile estimate.
pub fn project_source_inspection(
    durable: SourceInspectionReport,
    redactor: &caly_common::redact::Redactor,
) -> caly_api::SourceInspection {
    let endpoint = durable.endpoint;
    let report = durable.report;
    let warning_count = report
        .diagnostics
        .iter()
        .filter(|diagnostic| {
            matches!(
                diagnostic.severity,
                caly_pipeline::DiagnosticSeverity::Warning
            )
        })
        .count() as u32;
    let diagnostics = report
        .diagnostics
        .iter()
        .map(|diagnostic| caly_api::SourceDiagnostic {
            code: redactor.redact(&diagnostic.code),
            severity: source_diagnostic_severity(diagnostic.severity).to_owned(),
            summary: redactor.redact(&diagnostic.summary),
            detail: diagnostic
                .detail
                .as_deref()
                .map(|detail| redactor.redact(detail)),
            related_path: diagnostic.related_path.as_ref().map(|path| {
                redactor.redact(
                    &path
                        .segments
                        .iter()
                        .map(String::as_str)
                        .collect::<Vec<_>>()
                        .join("."),
                )
            }),
            remediation: diagnostic
                .remediation
                .as_deref()
                .map(|remediation| redactor.redact(remediation)),
        })
        .collect();
    let provenance = report
        .provenance
        .entries
        .iter()
        .map(|entry| {
            let (origin, locator) = source_provenance_origin(&entry.origin, redactor);
            caly_api::SourceProvenance {
                field: redactor.redact(
                    &entry
                        .field
                        .segments
                        .iter()
                        .map(String::as_str)
                        .collect::<Vec<_>>()
                        .join("."),
                ),
                origin,
                locator,
                transform: entry
                    .transform
                    .iter()
                    .map(|stage| stage.as_str().to_owned())
                    .collect(),
                superseded: entry
                    .superseded
                    .iter()
                    .map(|origin| source_provenance_origin_text(origin, redactor))
                    .collect(),
            }
        })
        .collect();
    let route = match endpoint.route {
        FetchRoute::Direct => "direct",
        FetchRoute::SystemProxy => "system-proxy",
        FetchRoute::ActiveCore => "active-core",
    };
    caly_api::SourceInspection {
        summary: caly_api::SourceSummary {
            id: caly_api::SourceId(redactor.redact(&endpoint.source_id.0)),
            label: redactor.redact(&endpoint.label),
            kind: source_kind_text(endpoint.kind),
        },
        locator: Some(redactor.redact(&endpoint.locator)),
        route: Some(route.to_owned()),
        etag: report.etag.as_deref().map(|value| redactor.redact(value)),
        last_modified: report
            .last_modified
            .as_deref()
            .map(|value| redactor.redact(value)),
        latest_digest: Some(report.raw.content_digest.0.clone()),
        raw_object_digest: Some(report.raw_object.digest.0.clone()),
        raw_bytes_len: Some(report.raw.bytes_len),
        raw_stored_at_unix_ms: report.raw_object.stored_at_unix_ms,
        normalized_node_count: report.normalized.nodes.len(),
        normalized_group_count: report.normalized.group_count_estimate,
        diagnostics,
        provenance,
        updated_at_unix_ms: Some(durable.updated_at_unix_ms),
        warning_count,
    }
}

fn source_diagnostic_severity(
    severity: caly_pipeline::DiagnosticSeverity,
) -> &'static str {
    match severity {
        caly_pipeline::DiagnosticSeverity::Error => "error",
        caly_pipeline::DiagnosticSeverity::Warning => "warning",
        caly_pipeline::DiagnosticSeverity::Info => "info",
    }
}

fn source_kind_text(kind: SourceKind) -> String {
    match kind {
        SourceKind::Subscription => "subscription".to_owned(),
        SourceKind::LocalFile => "file".to_owned(),
        SourceKind::Inline => "inline".to_owned(),
    }
}

fn source_provenance_origin(
    origin: &caly_pipeline::Origin,
    redactor: &caly_common::redact::Redactor,
) -> (String, Option<String>) {
    match origin {
        caly_pipeline::Origin::Source {
            source_id,
            locator,
        } => (
            format!("source:{}", redactor.redact(source_id)),
            locator.as_deref().map(|value| redactor.redact(value)),
        ),
        _ => (source_provenance_origin_text(origin, redactor), None),
    }
}

fn source_provenance_origin_text(
    origin: &caly_pipeline::Origin,
    redactor: &caly_common::redact::Redactor,
) -> String {
    match origin {
        caly_pipeline::Origin::Source {
            source_id,
            locator,
        } => {
            let mut text = format!("source:{}", redactor.redact(source_id));
            if let Some(locator) = locator {
                text.push_str(" (");
                text.push_str(&redactor.redact(locator));
                text.push(')');
            }
            text
        }
        caly_pipeline::Origin::Override { override_id } => {
            format!("override:{}", redactor.redact(override_id))
        }
        caly_pipeline::Origin::Default => "default".to_owned(),
        caly_pipeline::Origin::Safety => "safety".to_owned(),
    }
}

pub struct HttpSourceUpdateWorker {
    http: Arc<dyn Http>,
    storage: Arc<dyn StorageBackend>,
    clock: Option<Arc<dyn Clock>>,
    endpoints: Arc<Mutex<BTreeMap<String, SourceEndpoint>>>,
    /// The fast in-process view of the durable source index. Construction restores it from the
    /// backend before the worker is exposed; every successful 200/304 then republishes the complete
    /// record atomically, so this map is never the only evidence for a conditional request.
    cache: Arc<Mutex<BTreeMap<String, CachedSource>>>,
}

impl HttpSourceUpdateWorker {
    /// Construct the worker and restore every durable source entry before it can serve an update.
    ///
    /// A malformed source record, a missing raw object, or a metadata/anchor mismatch is a startup
    /// refusal.  Lazy restoration would make the first `304` the place where corruption is
    /// discovered, after the daemon had already announced itself as healthy.
    pub fn new(
        http: Arc<dyn Http>,
        storage: Arc<dyn StorageBackend>,
    ) -> Result<Self, String> {
        let worker = Self {
            http,
            storage,
            clock: None,
            endpoints: Arc::new(Mutex::new(BTreeMap::new())),
            cache: Arc::new(Mutex::new(BTreeMap::new())),
        };
        worker.restore_durable_state()?;
        Ok(worker)
    }

    fn restore_durable_state(&self) -> Result<(), String> {
        let ctx = RequestContext::new(TraceId::new("source-index-open"), Actor::System);
        let limits = RunLimits::immediate();
        let records = run_ready(self.storage.list_source_indexes(&ctx))
            .map_err(|summary| format!("source index startup driver failed: {summary}"))?
            .map_err(|error| format!("source index startup read failed: {}", error.summary))?;
        for record in records {
            let source_id = record.source_id.clone();
            let (endpoint, report) = self.load_durable_record(&record, &ctx, &limits)?;
            self.endpoints
                .lock()
                .map_err(|_| "source endpoint registry lock poisoned".to_owned())?
                .insert(source_id.clone(), endpoint);
            self.cache
                .lock()
                .map_err(|_| "source cache lock poisoned".to_owned())?
                .insert(source_id, CachedSource { report });
        }
        Ok(())
    }

    /// Decode and verify one durable record before exposing it either to the worker cache or to the
    /// inspection read model. The same helper is used at startup and on demand so a query cannot
    /// accidentally become less strict than restart recovery.
    fn load_durable_record(
        &self,
        record: &SourceIndexRecord,
        ctx: &RequestContext,
        limits: &RunLimits,
    ) -> Result<(SourceEndpoint, SourceUpdateReport), String> {
        let source_id = record.source_id.as_str();
        let endpoint = Self::endpoint_from_record(record)?;
        if record.raw_bytes_len > endpoint.max_body_bytes {
            return Err(format!(
                "source index {source_id} raw body length {} exceeds endpoint cap {}",
                record.raw_bytes_len, endpoint.max_body_bytes
            ));
        }
        let report = report_from_record(record)
            .map_err(|summary| format!("source index {source_id} typed cache is invalid: {summary}"))?;
        let object = run_ready_in(self.storage.get(&record.raw_object_digest, ctx), limits)
            .map_err(|refusal| {
                source_store_refusal(&format!("source index {source_id}"), "object lookup", refusal)
            })?
            .map_err(|error| {
                source_backend_error(&format!("source index {source_id}"), "object lookup", &error)
            })?
            .ok_or_else(|| {
                format!(
                    "source index {source_id} references missing raw object {}",
                    record.raw_object_digest
                )
            })?;
        if object.digest.0 != record.raw_object_digest
            || object.kind != ObjectKind::RawSource
            || object.content_sha256.as_deref() != Some(record.raw_content_sha256.as_str())
            || object.size_bytes != Some(record.raw_bytes_len)
        {
            return Err(format!(
                "source index {source_id} raw object metadata disagrees with its durable anchors"
            ));
        }
        let raw_bytes = run_ready_in(
            self.storage
                .read_object(&record.raw_object_digest, endpoint.max_body_bytes, ctx),
            limits,
        )
        .map_err(|refusal| {
            source_store_refusal(&format!("source index {source_id}"), "raw CAS read", refusal)
        })?
        .map_err(|error| {
            source_backend_error(&format!("source index {source_id}"), "raw CAS read", &error)
        })?
        .ok_or_else(|| {
            format!(
                "source index {source_id} references missing raw CAS bytes {}",
                record.raw_object_digest
            )
        })?;
        if raw_bytes.len() as u64 != record.raw_bytes_len
            || caly_ir::sha256_digest(&raw_bytes) != record.raw_content_sha256
        {
            return Err(format!(
                "source index {source_id} raw CAS bytes disagree with their durable anchors"
            ));
        }
        Ok((endpoint, report))
    }

    fn endpoint_from_record(record: &SourceIndexRecord) -> Result<SourceEndpoint, String> {
        let endpoint = SourceEndpoint {
            source_id: SourceId::new(record.source_id.clone()),
            kind: source_kind_from_text(&record.source_kind)?,
            label: record.label.clone(),
            locator: record.locator.clone(),
            route: route_from_text(&record.route)?,
            max_body_bytes: record.max_body_bytes,
            media_type: record.media_type.clone(),
            strict_mode: record.strict_mode,
        };
        Self::validate_endpoint(&endpoint)?;
        Ok(endpoint)
    }

    fn persist_report(
        &self,
        endpoint: &SourceEndpoint,
        report: &SourceUpdateReport,
        ctx: &RequestContext,
        limits: &RunLimits,
    ) -> Result<(), String> {
        let record = record_from_report(endpoint, report, self.stored_at());
        run_ready_in(self.storage.put_source_index(record, ctx), limits)
            .map_err(|refusal| {
                source_store_refusal(&endpoint.source_id.0, "source-index commit", refusal)
            })?
            .map_err(|error| {
                source_backend_error(&endpoint.source_id.0, "source-index commit", &error)
            })
    }

    pub fn with_clock(mut self, clock: Arc<dyn Clock>) -> Self {
        self.clock = Some(clock);
        self
    }

    fn validate_endpoint(endpoint: &SourceEndpoint) -> Result<(), String> {
        if endpoint.source_id.0.trim().is_empty() {
            return Err("source endpoint id must not be empty".to_owned());
        }
        if endpoint.locator.trim().is_empty() {
            return Err(format!(
                "source {} has no locator; refusing to derive one",
                endpoint.source_id.0
            ));
        }
        if endpoint.max_body_bytes == 0 {
            return Err(format!(
                "source {} has a zero body cap",
                endpoint.source_id.0
            ));
        }
        if endpoint.max_body_bytes as usize > MAX_SOURCE_BYTES {
            return Err(format!(
                "source {} body cap exceeds the parser limit of {} bytes",
                endpoint.source_id.0, MAX_SOURCE_BYTES
            ));
        }
        Ok(())
    }

    pub fn register(&self, endpoint: SourceEndpoint) -> Result<(), String> {
        Self::validate_endpoint(&endpoint)?;
        let source_id = endpoint.source_id.0.clone();
        let previous = self
            .endpoints
            .lock()
            .map_err(|_| "source endpoint registry lock poisoned".to_owned())?
            .get(&source_id)
            .cloned();
        let changed = previous.as_ref().is_some_and(|value| value != &endpoint);
        if changed {
            // A process-local cache eviction is not enough: without deleting the durable index,
            // the old locator and validators would come back on the next worker construction.
            let invalidate_ctx = RequestContext::new(
                TraceId::new("source-index-invalidate"),
                Actor::System,
            );
            run_ready(self.storage.delete_source_index(&source_id, &invalidate_ctx))
                .map_err(|summary| {
                    format!(
                        "source {source_id} locator change invalidation driver failed: {summary}"
                    )
                })?
                .map_err(|error| {
                    format!(
                        "source {source_id} locator change invalidation failed: {}",
                        error.summary
                    )
                })?;
            self.cache
                .lock()
                .map_err(|_| "source cache lock poisoned".to_owned())?
                .remove(&source_id);
        }
        self.endpoints
            .lock()
            .map_err(|_| "source endpoint registry lock poisoned".to_owned())?
            .insert(source_id, endpoint);
        Ok(())
    }

    pub fn endpoint(&self, source_id: &str) -> Result<Option<SourceEndpoint>, String> {
        self.endpoints
            .lock()
            .map(|endpoints| endpoints.get(source_id).cloned())
            .map_err(|_| "source endpoint registry lock poisoned".to_owned())
    }

    pub fn cached_report(&self, source_id: &str) -> Result<Option<SourceUpdateReport>, String> {
        self.cache
            .lock()
            .map(|cache| cache.get(source_id).map(|entry| entry.report.clone()))
            .map_err(|_| "source cache lock poisoned".to_owned())
    }

    /// Read one source-index record through the same verification path used at worker startup.
    /// `None` is a durable absence, not a projection of the process-local cache.
    pub fn inspect_durable(
        &self,
        source_id: &str,
        ctx: &RequestContext,
    ) -> Result<Option<SourceInspectionReport>, String> {
        let limits = RunLimits::for_command(ctx, self.clock.clone());
        let source_ctx = anchored_source_context(ctx, &limits);
        check_source_limits(source_id, "inspection admission", &limits)?;
        let record = run_ready_in(
            self.storage.get_source_index(source_id, &source_ctx),
            &limits,
        )
        .map_err(|refusal| source_store_refusal(source_id, "inspection record read", refusal))?
        .map_err(|error| source_backend_error(source_id, "inspection record read", &error))?;
        let Some(record) = record else {
            return Ok(None);
        };
        let updated_at_unix_ms = record.updated_at_unix_ms;
        let (endpoint, report) = self.load_durable_record(&record, &source_ctx, &limits)?;
        Ok(Some(SourceInspectionReport {
            endpoint,
            report,
            updated_at_unix_ms,
        }))
    }

    fn stored_at(&self) -> i64 {
        self.clock
            .as_ref()
            .map(|clock| clock.now().unix_millis)
            .unwrap_or(0)
    }

    fn fetch(
        &self,
        endpoint: &SourceEndpoint,
        etag: Option<String>,
        last_modified: Option<String>,
        ctx: &RequestContext,
        limits: &RunLimits,
    ) -> Result<caly_io::FetchResp, String> {
        let request = FetchReq {
            url: endpoint.locator.clone(),
            route: endpoint.route,
            etag,
            if_modified_since: last_modified,
            max_body_bytes: endpoint.max_body_bytes,
        };
        drive(self.http.fetch(request, ctx), limits.drive())
            .map_err(|fault| {
                source_limit_error(&endpoint.source_id.0, "HTTP fetch", &fault, limits)
            })?
            .map_err(|fault| {
                // Do not copy an adapter summary into a job event: a URL query can carry a
                // caller token even though the parser itself never logs credentials. The fault
                // kind is enough for retry/diagnosis here; the boundary redactor remains a second
                // line of defence.
                format!(
                    "source {} fetch failed: io fault {:?}",
                    endpoint.source_id.0, fault.kind
                )
            })
    }

    fn parse_body(
        &self,
        endpoint: &SourceEndpoint,
        bytes: Vec<u8>,
    ) -> Result<(ParsedSource, CasObjectRef), String> {
        let parsed = parse_source(
            &SourceInput {
                id: endpoint.source_id.clone(),
                kind: endpoint.kind,
                origin_label: endpoint.label.clone(),
                locator: Some(endpoint.locator.clone()),
                bytes: bytes.clone(),
                media_type: endpoint.media_type.clone(),
            },
            endpoint.strict_mode,
        )
        .map_err(|summary| {
            format!(
                "source {} normalization failed: {summary}",
                endpoint.source_id.0
            )
        })?;
        let raw_digest = parsed.raw.content_digest.0.clone();
        let object = CasObjectRef {
            digest: ObjectDigest(raw_digest.clone()),
            kind: ObjectKind::RawSource,
            size_bytes: Some(bytes.len() as u64),
            content_type: endpoint.media_type.clone(),
            content_sha256: Some(raw_digest),
            stored_at_unix_ms: None,
        };
        Ok((parsed, object))
    }

    fn validate_response_label(
        &self,
        endpoint: &SourceEndpoint,
        response: &caly_io::FetchResp,
    ) -> Result<(), String> {
        // Keep the contract spelling in one comparison while avoiding a second URL/label source
        // of truth. The body label is the caller's URL-shaped name, never a resolved host path.
        let expected_label = format!("http:{}", endpoint.locator);
        if response.body.label != expected_label {
            return Err(format!(
                "source {} fetch returned an unexpected body label",
                endpoint.source_id.0
            ));
        }
        Ok(())
    }
}

impl SourceUpdateWorker for HttpSourceUpdateWorker {
    fn update(&self, source_id: &str, ctx: &RequestContext) -> Result<SourceUpdateReport, String> {
        // One limits object owns the deadline anchor, cancellation handle, and cumulative request
        // budget for the whole source transaction. Re-deriving it per phase would turn one caller
        // deadline into several relative timers and would let a cancelled fetch still start a CAS
        // write (`ADR-036 §2.2`, `ADR-049 §2.4`).
        let limits = RunLimits::for_command(ctx, self.clock.clone());
        let source_ctx = anchored_source_context(ctx, &limits);
        check_source_limits(source_id, "update admission", &limits)?;

        let endpoint = self
            .endpoint(source_id)?
            .ok_or_else(|| format!("source {source_id} has no registered locator"))?;
        if endpoint.source_id.0 != source_id {
            return Err(format!("source endpoint key mismatch for {source_id}"));
        }
        let previous = self.cached_report(source_id)?;
        let response = self.fetch(
            &endpoint,
            previous.as_ref().and_then(|report| report.etag.clone()),
            previous
                .as_ref()
                .and_then(|report| report.last_modified.clone()),
            &source_ctx,
            &limits,
        )?;
        // A blocking adapter may return after a caller cancelled or after its socket operation
        // crossed the deadline. The outer post-call probe is therefore required even though the
        // drive checked before every poll; it is the honest boundary for the current body-snapshot
        // carrier, which cannot interrupt a syscall already in progress.
        check_source_limits(source_id, "after HTTP fetch", &limits)?;
        let response_etag = response.etag.clone();
        let response_last_modified = response.last_modified.clone();

        if response.status == 304 {
            let Some(previous) = previous else {
                return Err(format!(
                    "source {} returned 304 but no prior raw body is attached to this worker",
                    endpoint.source_id.0
                ));
            };
            self.validate_response_label(&endpoint, &response)?;
            check_source_limits(source_id, "before cached raw-body read", &limits)?;
            let bytes = run_ready_in(
                self.storage.read_object(
                    &previous.raw_object.digest.0,
                    endpoint.max_body_bytes,
                    &source_ctx,
                ),
                &limits,
            )
            .map_err(|refusal| {
                source_store_refusal(&endpoint.source_id.0, "cached raw-body read", refusal)
            })?
            .map_err(|error| {
                source_backend_error(&endpoint.source_id.0, "cached raw-body read", &error)
            })?
            .ok_or_else(|| {
                format!(
                    "source {} returned 304 but its cached raw body is missing",
                    endpoint.source_id.0
                )
            })?;
            check_source_limits(source_id, "after cached raw-body read", &limits)?;
            let digest = caly_ir::sha256_digest(&bytes);
            if previous.raw.content_digest.0 != digest
                || previous.raw_object.content_sha256.as_deref() != Some(digest.as_str())
            {
                return Err(format!(
                    "source {} cached raw body failed its digest anchor on 304 reuse",
                    endpoint.source_id.0
                ));
            }
            let mut report = previous;
            report.reused_raw_body = true;
            report.etag = response_etag.or(report.etag);
            report.last_modified = response_last_modified.or(report.last_modified);
            check_source_limits(source_id, "before 304 source-index commit", &limits)?;
            self.persist_report(&endpoint, &report, &source_ctx, &limits)?;
            self.cache
                .lock()
                .map_err(|_| "source cache lock poisoned".to_owned())?
                .insert(
                    source_id.to_owned(),
                    CachedSource {
                        report: report.clone(),
                    },
                );
            return Ok(report);
        }

        if !(200..300).contains(&response.status) {
            return Err(format!(
                "source {} returned HTTP status {}",
                endpoint.source_id.0, response.status
            ));
        }
        self.validate_response_label(&endpoint, &response)?;
        check_source_limits(source_id, "before source parse", &limits)?;
        let bytes_for_store = response.body.bytes.clone();
        let (parsed, object) = self.parse_body(&endpoint, bytes_for_store.clone())?;
        check_source_limits(source_id, "after source parse", &limits)?;
        let intent = CasWriteIntent {
            object,
            source_label: format!("source:{}", endpoint.source_id.0),
            payload: bytes_for_store,
            stored_at_unix_ms: self.stored_at(),
        };
        let stored = run_ready_in(self.storage.put(intent, &source_ctx), &limits)
            .map_err(|refusal| {
                source_store_refusal(&endpoint.source_id.0, "CAS write", refusal)
            })?
            .map_err(|error| source_backend_error(&endpoint.source_id.0, "CAS write", &error))?;
        check_source_limits(source_id, "after CAS write", &limits)?;
        if stored.kind != ObjectKind::RawSource
            || stored.content_sha256.as_deref() != Some(parsed.raw.content_digest.0.as_str())
        {
            return Err(format!(
                "source {} CAS returned an integrity anchor different from the fetched body",
                endpoint.source_id.0
            ));
        }
        let report = SourceUpdateReport {
            source_id: endpoint.source_id.clone(),
            raw: parsed.raw,
            normalized: parsed.normalized,
            raw_object: stored,
            diagnostics: parsed.diagnostics,
            provenance: parsed.provenance,
            reused_raw_body: false,
            etag: response_etag,
            last_modified: response_last_modified,
        };
        check_source_limits(source_id, "before 200 source-index commit", &limits)?;
        self.persist_report(&endpoint, &report, &source_ctx, &limits)?;
        self.cache
            .lock()
            .map_err(|_| "source cache lock poisoned".to_owned())?
            .insert(
                source_id.to_owned(),
                CachedSource {
                    report: report.clone(),
                },
            );
        Ok(report)
    }

    fn inspect(
        &self,
        source_id: &str,
        ctx: &RequestContext,
    ) -> Result<Option<SourceInspectionReport>, String> {
        self.inspect_durable(source_id, ctx)
    }

    fn restored_sources(&self) -> Result<Vec<NormalizedSource>, String> {
        self.cache
            .lock()
            .map(|cache| {
                cache
                    .values()
                    .map(|entry| entry.report.normalized.clone())
                    .collect()
            })
            .map_err(|_| "source cache lock poisoned".to_owned())
    }

    fn register_endpoint(&self, endpoint: SourceEndpoint) -> Result<(), String> {
        self.register(endpoint)
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::{Command, CommandId, CommandKind, EngineState, WorkerPolicy};
    use caly_common::{Actor, RequestContext, TraceId};
    use caly_io_sim::{ScriptedHttp, ScriptedResponse, SharedFaults, SimHttp};
    use caly_storage::ObjectStore;

    fn ctx() -> RequestContext {
        RequestContext::new(TraceId::new("source-worker-test"), Actor::System)
    }

    #[test]
    fn explicit_locator_fetches_parses_and_stores_raw_bytes() {
        let url = "http://feed.test/sub";
        let mut scripted = ScriptedHttp::default();
        scripted.push(ScriptedResponse {
            url: url.to_owned(),
            status: 200,
            body: b"vless://uuid@example.test:443#edge\n".to_vec(),
        });
        let http = Arc::new(SimHttp::new(scripted, SharedFaults::default()));
        let storage = Arc::new(caly_storage::InMemoryStorage::new());
        let worker = HttpSourceUpdateWorker::new(http, storage.clone()).expect("worker startup");
        worker
            .register(SourceEndpoint::subscription(
                SourceId::new("source-1"),
                "Feed",
                url,
                1024,
            ))
            .expect("registered locator");

        let report = worker.update("source-1", &ctx()).expect("source update");
        assert_eq!(report.normalized.nodes.len(), 1);
        assert_eq!(
            report.raw.bytes_len,
            b"vless://uuid@example.test:443#edge\n".len() as u64
        );
        assert_eq!(report.raw_object.kind, ObjectKind::RawSource);
        assert_eq!(
            report.raw_object.content_sha256,
            Some(caly_ir::sha256_digest(
                b"vless://uuid@example.test:443#edge\n"
            ))
        );
        let metadata = caly_io::block_on_ready(storage.get(&report.raw_object.digest.0, &ctx()))
            .expect("storage future ready")
            .expect("metadata result")
            .expect("raw object exists");
        assert_eq!(metadata.digest, report.raw_object.digest);
    }

    #[test]
    fn source_update_command_runs_the_fetch_normalize_cas_worker() {
        let url = "http://feed.test/command";
        let mut scripted = ScriptedHttp::default();
        scripted.push(ScriptedResponse {
            url: url.to_owned(),
            status: 200,
            body: b"trojan://secret@example.test:443#edge\n".to_vec(),
        });
        let http = Arc::new(SimHttp::new(scripted, SharedFaults::default()));
        let storage = Arc::new(caly_storage::InMemoryStorage::new());
        let handle = crate::EngineHandle::with_backend(
            EngineState::new(),
            storage.clone() as Arc<dyn caly_storage::StorageBackend>,
        );
        let worker = Arc::new(
            HttpSourceUpdateWorker::new(
                http,
                storage.clone() as Arc<dyn caly_storage::StorageBackend>,
            )
            .expect("worker startup"),
        );
        worker
            .register(SourceEndpoint::subscription(
                SourceId::new("source-command"),
                "Feed",
                url,
                1024,
            ))
            .expect("registered locator");
        handle
            .set_source_update_worker(worker)
            .expect("worker slot");
        handle
            .submit(Command {
                id: CommandId("source-command-job".to_owned()),
                request_id: None,
                actor: Actor::System,
                context: ctx(),
                timeout_ms: None,
                idempotency_key: None,
                kind: CommandKind::SourceUpdate {
                    source_id: "source-command".to_owned(),
                },
            })
            .expect("queued source update");

        let drained = handle
            .drain_with_policy(WorkerPolicy::bounded(1))
            .expect("drained source update");
        assert_eq!(drained.results.len(), 1);
        assert_eq!(drained.results[0].outcome, crate::JobOutcome::Succeeded);
        let events = handle
            .follow_job(caly_api::JobId(drained.results[0].job_id))
            .expect("follow")
            .job
            .expect("job")
            .events;
        assert!(events
            .iter()
            .any(|event| { format!("{event:?}").contains("source source-command updated") }));
        assert_eq!(handle.normalized_source_cache().expect("cache").len(), 1);
    }

    #[derive(Clone, Default)]
    struct ConditionalHttp {
        requests: Arc<Mutex<Vec<caly_io::FetchReq>>>,
    }

    impl Http for ConditionalHttp {
        fn fetch<'a>(
            &'a self,
            request: caly_io::FetchReq,
            _ctx: &'a caly_io::IoContext,
        ) -> caly_io::BoxFuture<'a, Result<caly_io::FetchResp, caly_io::IoFault>> {
            let requests = Arc::clone(&self.requests);
            Box::pin(async move {
                let conditional = request.etag.is_some() || request.if_modified_since.is_some();
                requests
                    .lock()
                    .map_err(|_| {
                        caly_io::IoFault::new(
                            caly_io::IoFaultKind::InternalIo,
                            "request log poisoned",
                        )
                    })?
                    .push(request.clone());
                Ok(caly_io::FetchResp {
                    status: if conditional { 304 } else { 200 },
                    etag: Some("\"v1\"".to_owned()),
                    last_modified: Some("Wed, 01 Jan 2025 00:00:00 GMT".to_owned()),
                    body: caly_io::FetchBody {
                        label: format!("http:{}", request.url),
                        bytes: if conditional {
                            Vec::new()
                        } else {
                            b"vless://uuid@example.test:443#edge\n".to_vec()
                        },
                    },
                })
            })
        }
    }

    #[test]
    fn not_modified_reuses_verified_body_and_sends_cached_conditions() {
        let url = "http://feed.test/conditional";
        let http = Arc::new(ConditionalHttp::default());
        let storage = Arc::new(caly_storage::InMemoryStorage::new());
        let worker = HttpSourceUpdateWorker::new(http.clone(), storage).expect("worker startup");
        worker
            .register(SourceEndpoint::subscription(
                SourceId::new("source-conditional"),
                "Conditional feed",
                url,
                1024,
            ))
            .expect("registered locator");

        let first = worker
            .update("source-conditional", &ctx())
            .expect("first update");
        let second = worker
            .update("source-conditional", &ctx())
            .expect("304 update");
        assert!(!first.reused_raw_body);
        assert!(second.reused_raw_body);
        assert_eq!(second.raw, first.raw);
        assert_eq!(second.normalized, first.normalized);
        assert_eq!(second.raw_object, first.raw_object);
        assert_eq!(second.etag, Some("\"v1\"".to_owned()));
        let requests = http.requests.lock().expect("request log");
        assert_eq!(requests.len(), 2);
        assert_eq!(requests[1].etag, Some("\"v1\"".to_owned()));
        assert_eq!(
            requests[1].if_modified_since,
            Some("Wed, 01 Jan 2025 00:00:00 GMT".to_owned())
        );
        drop(requests);

        // Re-registering an id for a different locator invalidates the old conditional state;
        // otherwise a 304 from the new endpoint could incorrectly reuse bytes from the old one.
        let new_url = "http://feed.test/conditional-v2";
        worker
            .register(SourceEndpoint::subscription(
                SourceId::new("source-conditional"),
                "Conditional feed v2",
                new_url,
                1024,
            ))
            .expect("updated locator");
        let third = worker
            .update("source-conditional", &ctx())
            .expect("new endpoint update");
        assert!(!third.reused_raw_body);
        let requests = http.requests.lock().expect("request log");
        assert_eq!(requests.len(), 3);
        assert_eq!(requests[2].url, new_url);
        assert_eq!(requests[2].etag, None);
        assert_eq!(requests[2].if_modified_since, None);
    }

    #[test]
    fn missing_locator_is_a_refusal_not_a_derived_url() {
        let worker = UnconfiguredSourceUpdateWorker;
        let error = worker
            .update("label-that-is-not-a-url", &ctx())
            .expect_err("refused");
        assert!(error.contains("no explicit source locator"));
        assert!(!error.contains("http://label-that-is-not-a-url"));
    }
}
