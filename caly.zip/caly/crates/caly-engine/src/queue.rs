use std::collections::VecDeque;

use crate::command::Command;

#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub struct QueuePolicy {
    pub max_len: usize,
}

impl QueuePolicy {
    pub const fn bounded(max_len: usize) -> Self {
        Self { max_len }
    }
}

impl Default for QueuePolicy {
    fn default() -> Self {
        Self { max_len: 256 }
    }
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct QueueEntry {
    pub command: Command,
}

#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub enum QueuePushResult {
    Accepted,
    RejectedFull { max_len: usize },
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct CommandQueue {
    policy: QueuePolicy,
    inner: VecDeque<QueueEntry>,
}

impl Default for CommandQueue {
    fn default() -> Self {
        Self {
            policy: QueuePolicy::default(),
            inner: VecDeque::new(),
        }
    }
}

impl CommandQueue {
    pub fn with_policy(policy: QueuePolicy) -> Self {
        Self {
            policy,
            inner: VecDeque::new(),
        }
    }

    pub fn push(&mut self, command: Command) -> QueuePushResult {
        if self.inner.len() >= self.policy.max_len {
            return QueuePushResult::RejectedFull {
                max_len: self.policy.max_len,
            };
        }
        self.inner.push_back(QueueEntry { command });
        QueuePushResult::Accepted
    }

    pub fn pop(&mut self) -> Option<QueueEntry> {
        self.inner.pop_front()
    }

    pub fn len(&self) -> usize {
        self.inner.len()
    }

    /// Whether a `push` would be accepted right now.
    ///
    /// Admission has to be decided *before* anything is mutated: `submit_command` used to allocate a
    /// job id and bump the engine generation first, so a command that was refused for a full queue
    /// still moved the revision every other caller compares `expected_revision` against
    /// (`docs/history/ONBOARDING_NOTES.md §4.58`).
    pub fn has_capacity(&self) -> bool {
        self.inner.len() < self.policy.max_len
    }

    pub fn is_empty(&self) -> bool {
        self.inner.is_empty()
    }

    pub fn capacity(&self) -> usize {
        self.policy.max_len
    }
}
