use caly_api::{JobId, StreamId};

#[derive(Clone, Copy, Debug, Eq, PartialEq, Ord, PartialOrd, Hash)]
pub struct EventSeq(pub u64);

#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub enum EventKind {
    CommandAccepted,
    CommandRejected,
    JobUpdated,
    RuntimeChanged,
    DeploymentChanged,
    SnapshotCommitted,
    JournalRecovered,
    RecoveryDecision,
    StreamReset,
}

#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub enum ReplayResetReason {
    RetentionExceeded,
    GapTooLarge,
    ExplicitReset,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub enum EventPayload {
    CommandAccepted { job_id: JobId, revision: u64 },
    CommandRejected { reason: String },
    JobUpdated { job_id: JobId, state: String },
    RuntimeChanged { summary: String },
    DeploymentChanged { summary: String },
    SnapshotCommitted { snapshot_id: String },
    JournalRecovered { journal_id: String },
    RecoveryDecision { summary: String },
    StreamReset { stream_id: StreamId, reason: String },
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct Event {
    pub seq: EventSeq,
    pub kind: EventKind,
    pub command_id: Option<String>,
    pub payload: EventPayload,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub enum ReplayWindow {
    Events {
        next_seq: u64,
        retained_from: EventSeq,
        events: Vec<Event>,
    },
    ResetRequired {
        next_seq: u64,
        retained_from: EventSeq,
        reason: ReplayResetReason,
    },
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct EventLog {
    pub next_seq: u64,
    pub retained_from_seq: u64,
    pub max_events: usize,
    pub events: Vec<Event>,
}

impl Default for EventLog {
    fn default() -> Self {
        Self {
            next_seq: 0,
            retained_from_seq: 0,
            max_events: 256,
            events: Vec::new(),
        }
    }
}

impl EventLog {
    pub fn with_capacity(max_events: usize) -> Self {
        Self {
            max_events,
            ..Self::default()
        }
    }

    pub fn push(
        &mut self,
        kind: EventKind,
        command_id: Option<String>,
        payload: EventPayload,
    ) -> Event {
        let seq = EventSeq(self.next_seq);
        self.next_seq = self.next_seq.saturating_add(1);
        let event = Event {
            seq,
            kind,
            command_id,
            payload,
        };
        self.events.push(event.clone());

        while self.events.len() > self.max_events {
            if let Some(removed) = self.events.first() {
                self.retained_from_seq = removed.seq.0.saturating_add(1);
            }
            self.events.remove(0);
        }

        event
    }

    pub fn replay_from(&self, from_exclusive: Option<EventSeq>) -> ReplayWindow {
        let retained_from = EventSeq(self.retained_from_seq);

        if let Some(seq) = from_exclusive {
            if seq.0.saturating_add(1) < self.retained_from_seq {
                return ReplayWindow::ResetRequired {
                    next_seq: self.next_seq,
                    retained_from,
                    reason: ReplayResetReason::RetentionExceeded,
                };
            }

            let events = self
                .events
                .iter()
                .filter(|event| event.seq.0 > seq.0)
                .cloned()
                .collect();
            return ReplayWindow::Events {
                next_seq: self.next_seq,
                retained_from,
                events,
            };
        }

        ReplayWindow::Events {
            next_seq: self.next_seq,
            retained_from,
            events: self.events.clone(),
        }
    }
}
