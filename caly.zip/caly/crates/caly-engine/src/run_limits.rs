//! Whose deadline a store access obeys, and who is allowed to say it expired.
//!
//! `ADR-036 §2.3` says timeouts and cancellations are applied by the executor of the port call, not
//! by each port. In this workspace the engine's store accesses are driven in
//! [`crate::recovery::run_ready`], so that is where a command's `Ctx` has to arrive -- and it is the
//! whole of step 2 of that ADR: until these limits are threaded, `Ctx.deadline_ms` was copied through
//! four layers and read by nobody.
//!
//! # What obeying means at this seam, precisely
//!
//! Every backend here completes its future on the first poll (`caly-storage`'s durable backend drives
//! its own port calls and flattens a suspension into a `StorageError`), so the checks that can fire
//! here are the ones [`caly_io::drive`] makes *before* the first poll: "the caller has cancelled" and
//! "the caller's time was already out when we were about to touch the store". Both are worth having --
//! they mean a doomed command stops producing state instead of finishing it -- but neither is
//! mid-call interruption, and this file does not claim to be able to interrupt a store call that has
//! already started. Making that possible means the limits have to reach the ports *inside* the store,
//! which the frozen `StorageBackend` signatures do not carry; `ADR-036 §6bis-quinque` records that as
//! the open half of this step instead of letting it be inferred from the word "enforced".
//!
//! # The rule this file exists to make impossible to get wrong
//!
//! A refusal may stop the engine from **starting** the next step. It must never stop the engine from
//! **recording what already happened**: the writes that set `net_effect_started` /
//! `core_cutover_started`, that publish a snapshot, or that mark a journal `Reverted` /
//! `RecoveryFailed` are the scanner's only evidence about a world that has already been touched.
//! Refusing one of those turns "the caller gave up" into "the next process misreads the crash site",
//! which is the irreversible direction. That is why every entry point here takes limits explicitly:
//! the recording paths pass [`RunLimits::immediate`] and say why at the call site.

use std::sync::{
    atomic::{AtomicU32, Ordering},
    Arc,
};

use caly_common::{IoBudget, RequestContext};
use caly_io::{Clock, Deadline, Drive};

/// How many times one store access may be polled before the engine gives up on it.
///
/// Not a throughput knob. With backends that are ready on the first poll it is never reached; it exists
/// so that a future backend which does suspend has a bound, and a bound is what makes "we will get
/// back to you" a checkable statement rather than a hope.
pub const DEFAULT_STORE_POLL_BUDGET: u32 = 64;

const _: () = assert!(
    DEFAULT_STORE_POLL_BUDGET > 0,
    "a zero poll budget would refuse every store access, which is not a limit but an outage"
);

/// The limits one store access is driven under.
///
/// `Clone` shares the cancellation flag *and* the spent budget on purpose: the cap is per command
/// execution, so a clone of the limits must not start a fresh allowance (nor lose the caller's
/// cancellation). No `Default`: an all-zeros `RunLimits` would silently mean "no budget", which is the
/// ambiguity `ADR-036 §2.4` exists to remove -- pick `immediate()` or `for_command()` on purpose.
#[derive(Clone)]
pub struct RunLimits {
    cancel: Option<caly_common::CancelToken>,
    deadline: Option<Deadline>,
    clock: Option<Arc<dyn Clock>>,
    max_polls: u32,
    budget: IoBudget,
    billed: Arc<AtomicU32>,
    /// The caller asked for a deadline that this layer cannot judge, because judging it needs a clock
    /// and none was injected. Tracked separately from `deadline: None`: "no deadline" and "a deadline
    /// nobody could check" must not collapse into the same operator-visible answer
    /// (`docs/history/ONBOARDING_NOTES.md §4.86`).
    unjudged: bool,
}

impl RunLimits {
    /// One poll, nothing to cancel, nothing to judge -- today's semantics, and the right value for
    /// every path that is not running on a caller's behalf.
    pub fn immediate() -> Self {
        Self {
            cancel: None,
            deadline: None,
            clock: None,
            max_polls: 1,
            // Unbounded on purpose: this is the shape every non-caller path uses, and billing those
            // would turn "the engine records what happened" into something a caller can starve.
            budget: IoBudget::unlimited(),
            billed: Arc::new(AtomicU32::new(0)),
            unjudged: false,
        }
    }

    /// The limits a command's own `Ctx` implies, anchored by whichever clock the engine was given.
    ///
    /// The deadline is anchored **once**, when the command starts, and never re-derived per store call:
    /// "each layer subtracts what it used" is how a relative budget drifts into a different number by
    /// the time it reaches the port that has to obey it (`ADR-036 §2.2`).
    pub fn for_command(context: &RequestContext, clock: Option<Arc<dyn Clock>>) -> Self {
        let now_mono = clock.as_ref().map(|clock| clock.mono().ticks_millis);
        let (deadline, unjudged) = match (context.deadline_mono_ms, context.deadline_ms) {
            (Some(at), _) => (Some(Deadline(at)), false),
            (None, Some(millis)) => match now_mono {
                Some(now) => (Some(Deadline(now.saturating_add(millis))), false),
                None => (None, true),
            },
            (None, None) => (None, false),
        };
        Self {
            cancel: Some(context.cancel.clone()),
            deadline,
            clock,
            max_polls: DEFAULT_STORE_POLL_BUDGET,
            unjudged,
            budget: context.io_budget.clone(),
            billed: Arc::new(AtomicU32::new(0)),
        }
    }

    /// How many **accounted** store accesses this execution has made. Always counted, capped or not,
    /// so the number keeps one meaning: `describe()` reports `budget=<made>/<cap>`.
    pub fn billed(&self) -> u32 {
        self.billed.load(Ordering::Relaxed)
    }

    /// Charge this execution one store access, or refuse it before the access is attempted.
    ///
    /// Two rules worth stating because both were choices, not consequences:
    ///
    /// * **This gate runs before [`crate::recovery::run_ready_in`] drives anything**, because it asks
    ///   about the past ("how many have I already made") while `drive`'s checks ask about the present
    ///   (cancelled? time out?). A command that is both cancelled and out of budget is therefore
    ///   reported as out of budget, which is the more actionable of the two truths.
    /// * **An access that reaches this gate is billed even if the port then refuses it** -- billed means
    ///   "attempted", not "succeeded". A *refused* access (budget already gone) is not billed, since
    ///   nothing was attempted; that is what keeps a retry loop from being charged for its own
    ///   refusals.
    ///
    /// Only accesses that *could* have been refused are billed at all, which is why the recording paths
    /// (`put_apply_journal`, finalize, revert) never appear in this count: they take no limits, so
    /// they are neither refusable nor billable. One rule, no invisible ledger.
    pub(crate) fn charge(&self) -> Result<(), StoreRefusal> {
        let made = self.billed.fetch_add(1, Ordering::Relaxed);
        let cap = match self.budget.max_requests {
            None => return Ok(()),
            Some(cap) => cap,
        };
        if made >= cap {
            // The increment above was optimistic; put it back so a refusal does not eat budget.
            self.billed.fetch_sub(1, Ordering::Relaxed);
            return Err(StoreRefusal {
                kind: RefusalKind::BudgetExhausted,
                message: format!(
                    "this command's io budget allows {cap} accounted store access(es); {made} already \
                     made, so nothing further was started"
                ),
                retryable: false,
                limits: if self.is_immediate() {
                    String::new()
                } else {
                    self.describe()
                },
            });
        }
        Ok(())
    }

    /// Override the poll budget. `0` means `1`, matching [`Drive::bounded`]: "no polls at all" is not
    /// a tighter limit, it is a guarantee of failure that still looks like an attempt.
    #[must_use]
    pub fn with_polls(mut self, max_polls: u32) -> Self {
        self.max_polls = if max_polls == 0 { 1 } else { max_polls };
        self
    }

    /// Limits that could not have caused a refusal: nothing armed, nothing to judge.
    ///
    /// A conjunction of only what can *refuse* something. An earlier version also required
    /// `!self.unjudged`, and the falsification run showed that no test could turn that clause off
    /// without any assertion noticing -- a conjunct nobody can witness is decoration wearing the
    /// clothes of a safety property (`docs/history/ONBOARDING_NOTES.md §4.94`). `unjudged` stays in
    /// [`RunLimits::describe`], where a test does read it.
    pub const fn is_immediate(&self) -> bool {
        self.cancel.is_none() && self.deadline.is_none() && self.clock.is_none()
    }

    pub const fn deadline(&self) -> Option<Deadline> {
        self.deadline
    }

    /// Whether nothing in these limits can refuse an access on budget grounds. The recording paths
    /// (`put_apply_journal`, finalize, revert) depend on this being true of them -- they take no limits
    /// at all, which is the same fact stated at the signature.
    pub const fn budget_is_unlimited(&self) -> bool {
        self.budget.max_requests.is_none()
    }

    pub const fn max_polls(&self) -> u32 {
        self.max_polls
    }

    /// The `Drive` handed to [`caly_io::drive`]. Borrowed from `self`, because the driver holds `&dyn
    /// Clock` / `&CancelToken` and this is the only place that owns them for the length of a call.
    pub fn drive(&self) -> Drive<'_> {
        Drive {
            cancel: self.cancel.as_ref(),
            deadline: self.deadline,
            clock: self.clock.as_deref(),
            max_polls: self.max_polls,
        }
    }

    /// One line for an event or job summary: what a refusal here would be *blamed on*.
    ///
    /// Kept free of paths and digests because it lands in operator-visible strings.
    pub fn describe(&self) -> String {
        let deadline = match (self.deadline, self.unjudged) {
            (Some(at), _) => format!("deadline=mono {}", at.0),
            (None, true) => "deadline=unjudged(no clock)".to_owned(),
            (None, false) => "deadline=none".to_owned(),
        };
        // One format whether or not a cap exists: the count is the interesting half, and hiding it
        // when nothing is capped would give `describe` two shapes for no reason.
        let cap = match self.budget.max_requests {
            Some(cap) => cap.to_string(),
            None => "uncapped".to_owned(),
        };
        let budget = format!("{}/{}", self.billed(), cap);
        format!(
            "{deadline}, cancel={}, budget={budget}, polls={}",
            match &self.cancel {
                Some(token) if token.is_cancelled() => "fired",
                Some(_) => "armed",
                None => "none",
            },
            self.max_polls
        )
    }
}

/// Hand-written because `Arc<dyn Clock>` is not `Debug`: the useful part of a refusal's context is
/// exactly what [`RunLimits::describe`] already spells out, so this is that line with a name on it.
impl std::fmt::Debug for RunLimits {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        write!(f, "RunLimits({})", self.describe())
    }
}

/// Why a bounded store access did not happen.
///
/// Carried as data rather than as prose because `RFC-0006 §5.2` requires "the caller gave up" and
/// "the caller's time ran out" to stay distinguishable all the way out -- and in this engine that
/// distinction is what decides whether the *job* settles as `Cancelled`, `TimedOut` or `Failed`
/// (`ADR-036 §6bis-quinque`: those two `JobOutcome` variants existed with no producer).
#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub enum RefusalKind {
    /// The caller's token had already fired; the store was never asked.
    CallerCancelled,
    /// An injected clock said the caller's absolute deadline had passed; the store was never asked.
    DeadlineExpired,
    /// The port did not become ready inside the poll budget. Nothing was concluded about time --
    /// that is the whole reason this variant is not `DeadlineExpired`.
    NotReady,
    /// The store answered, and its answer was an error. The limits had nothing to do with it.
    Backend,
    /// The caller's own `IoBudget::max_requests` is spent. Not congestion and not a deadline: the
    /// request was legal and the budget said stop, which is why the public code is
    /// `CONFIG_INVALID` and the job settles as `Failed` (`ADR-036 §6bis-sexies`).
    BudgetExhausted,
    /// The payload this call wanted to move is over the caller's own `Ctx::io_budget.max_bytes`, and the
    /// **port** is the one that said so (`RFC-0006 §5.3`, `caly_io::budget`). Distinct from
    /// `BudgetExhausted`, which is this layer's own request counter running out: here the knob is bytes,
    /// the refusal came from inside the store, and `retryable` is false on the record rather than copied
    /// -- a payload cannot shrink because you asked again.
    PayloadTooBig,
    /// The **store itself** said it is busy (`StorageErrorKind::Busy`), which is the one storage
    /// answer `OVERLOAD_AND_RETRY_MODEL §3.4` has a class for. Split out of `Backend` because
    /// `§6.2` needs the mid-transaction case to reach `doctor`'s pressure tally, and "the backend
    /// returned an error" does not say that. Nothing else is promoted: a per-kind retry table for
    /// the other nine `StorageErrorKind`s is what `ADR-036 §6bis-quinque` declined to invent, and
    /// inventing one here would be the same mistake with a nicer name.
    StorageBusy,
}

/// A refusal, with the limits that caused it beside it.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct StoreRefusal {
    pub kind: RefusalKind,
    /// The store's or the driver's own text, unmodified.
    pub message: String,
    /// What [`RunLimits::describe`] said at the moment of the refusal. Empty for [`RefusalKind::Backend`],
    /// because blaming limits for a backend error would be a fabricated reason.
    pub limits: String,
    /// Whether trying again could plausibly work. This is copied from whichever answer was given --
    /// the port's own bit for a driver refusal -- and never derived from `kind`: "the caller
    /// cancelled" and "the store is busy" happen to agree far too often for a guess to be safe.
    pub retryable: bool,
}

impl StoreRefusal {
    /// From the typed fault [`caly_io::drive`] answers with. `drive` produces exactly `Cancelled`,
    /// `Timeout` and `Busy`; any other kind is reported as `NotReady` with the fault's own text,
    /// because inventing a fourth meaning for it would be worse than being unimpressed by it.
    pub(crate) fn from_fault(fault: &caly_io::IoFault, limits: &RunLimits) -> Self {
        let kind = match fault.kind {
            caly_io::IoFaultKind::Cancelled => RefusalKind::CallerCancelled,
            caly_io::IoFaultKind::Timeout => RefusalKind::DeadlineExpired,
            _ => RefusalKind::NotReady,
        };
        Self {
            kind,
            message: fault.summary.clone(),
            retryable: fault.retryable,
            limits: if limits.is_immediate() {
                String::new()
            } else {
                limits.describe()
            },
        }
    }

    /// A store error. `StorageError` carries a kind and a summary but no retry classification -- so
    /// this keeps the answer the worker has always given (`true`) instead of inventing a per-kind
    /// table here; `ADR-036 §6bis-quinque` records that the storage error model is where that bit
    /// ought to live.
    pub(crate) fn backend(message: impl Into<String>) -> Self {
        Self {
            kind: RefusalKind::Backend,
            message: message.into(),
            retryable: true,
            limits: String::new(),
        }
    }

    /// A store error, keeping the classifications the store already made.
    ///
    /// Two answers are promoted, and both exist because the *model* has a name for them: `Busy` →
    /// [`RefusalKind::StorageBusy`] (the `OVERLOAD_AND_RETRY_MODEL §3.4` class, and the one `§6.2` counts
    /// for the operator), and `CapacityExceeded` → [`RefusalKind::PayloadTooBig`] (the caller's own byte
    /// budget, refused by the port per `RFC-0006 §5.3`). Every other kind stays `Backend`: a per-kind
    /// retry table for the rest is what `ADR-036 §6bis-quinque` declined to invent, and inventing one
    /// here would be the same mistake with a nicer name. The store's own text is kept verbatim in
    /// `message`, which is what `crates/caly-engine/tests/cutover_intent_guard.rs` asserts.
    pub(crate) fn from_storage_error(error: &caly_storage::StorageError) -> Self {
        if error.kind == caly_storage::StorageErrorKind::CapacityExceeded {
            // `retryable: false` is reasoned, not copied: `StorageError` carries no retry bit (see
            // `backend`), and retrying a payload does not make it smaller.
            return Self {
                kind: RefusalKind::PayloadTooBig,
                message: error.summary.clone(),
                retryable: false,
                limits: String::new(),
            };
        }
        if error.kind == caly_storage::StorageErrorKind::Busy {
            return Self {
                kind: RefusalKind::StorageBusy,
                message: error.summary.clone(),
                // Copied from `backend`'s long-standing answer, not derived from the kind:
                // `§3.4` calls a busy store retryable, and this agrees with it rather than
                // re-deciding it here.
                retryable: true,
                limits: String::new(),
            };
        }
        Self::backend(error.summary.clone())
    }

    pub const fn is_caller_side(&self) -> bool {
        matches!(
            self.kind,
            RefusalKind::CallerCancelled | RefusalKind::DeadlineExpired
        )
    }
}

impl std::fmt::Display for StoreRefusal {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        if self.limits.is_empty() {
            write!(f, "{}", self.message)
        } else {
            write!(f, "{} (limits: {})", self.message, self.limits)
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::sync::atomic::{AtomicU64, Ordering};

    use caly_common::{Actor, CancelToken, TraceId};
    use caly_io::{BoxFuture, IoFault, Monotonic, Timestamp};

    /// A clock that steps on every read, i.e. the scripted version of "time passed". Real time would
    /// make the anchor below depend on the machine.
    struct SteppingClock {
        step: u64,
        ticks: AtomicU64,
    }

    impl SteppingClock {
        fn new(step: u64) -> Self {
            Self {
                step,
                ticks: AtomicU64::new(0),
            }
        }
    }

    impl Clock for SteppingClock {
        fn now(&self) -> Timestamp {
            Timestamp {
                unix_millis: self.ticks.load(Ordering::Relaxed) as i64,
            }
        }

        fn mono(&self) -> Monotonic {
            Monotonic {
                ticks_millis: self.ticks.fetch_add(self.step, Ordering::Relaxed),
            }
        }

        fn sleep_until<'a>(&'a self, _at: Monotonic) -> BoxFuture<'a, Result<(), IoFault>> {
            Box::pin(async { Ok(()) })
        }
    }

    fn context() -> RequestContext {
        RequestContext::new(TraceId::new("run-limits"), Actor::System)
    }

    #[test]
    fn immediate_limits_carry_nothing_to_obey() {
        let limits = RunLimits::immediate();
        assert!(limits.is_immediate());
        assert_eq!(limits.max_polls(), 1);
        let drive = limits.drive();
        assert!(drive.cancel.is_none() && drive.deadline.is_none() && drive.clock.is_none());
        assert_eq!(
            limits.describe(),
            "deadline=none, cancel=none, budget=0/uncapped, polls=1",
            "an unbounded path must say so, not look like a bounded one that happens to be open"
        );
        assert_eq!(limits.billed(), 0);
        assert!(
            limits.budget_is_unlimited(),
            "the unbounded shape is what every recording path uses, so it must not be billable"
        );
    }

    #[test]
    fn a_relative_deadline_is_anchored_by_the_injected_clock_only() {
        let clock = Arc::new(SteppingClock::new(10));
        let mut ctx = context();
        ctx.deadline_ms = Some(50);

        let anchored = RunLimits::for_command(&ctx, Some(Arc::clone(&clock) as Arc<dyn Clock>));
        assert_eq!(
            anchored.deadline(),
            Some(Deadline(50)),
            "this clock reads 0 on its first reading, so the absolute deadline is 0 + 50; the number \
             is checked, not remembered"
        );
        assert_eq!(
            anchored.describe(),
            "deadline=mono 50, cancel=armed, budget=0/64, polls=64",
            "the operator-visible line has to say the deadline is *judged*, and against what budget"
        );

        let without_clock = RunLimits::for_command(&ctx, None);
        assert_eq!(
            without_clock.deadline(),
            None,
            "no clock means nobody here may claim the time ran out"
        );
        assert!(
            without_clock.describe().contains("unjudged(no clock)"),
            "{}",
            without_clock.describe()
        );
        assert!(
            !without_clock.is_immediate(),
            "an unjudged deadline is not the same thing as no deadline"
        );
    }

    #[test]
    fn an_absolute_deadline_from_the_boundary_is_taken_as_it_arrives() {
        let mut ctx = context();
        // What `caly-daemon`'s boundary writes: relative value kept, absolute left unset (§4.86).
        ctx.deadline_ms = Some(25);
        ctx.deadline_mono_ms = Some(777);
        let clock = Arc::new(SteppingClock::new(10));
        let limits = RunLimits::for_command(&ctx, Some(clock as Arc<dyn Clock>));
        assert_eq!(
            limits.deadline(),
            Some(Deadline(777)),
            "a deadline already anchored upstream must not be re-anchored here -- that is the drift \
             ADR-036 §2.2 names"
        );
    }

    #[test]
    fn both_anchorings_agree_on_the_same_rule() {
        // `caly-daemon` turns a relative deadline into an absolute one at its boundary with
        // `RequestContext::with_deadline_from`; the engine would do it again here. Two rules for the
        // same quantity is how the two eventually disagree, so they are asserted to compute one number.
        let mut ctx = context();
        ctx.deadline_ms = Some(30);
        let at_boundary = ctx
            .clone()
            .with_deadline_from(Some(1_000), 30)
            .deadline_mono_ms
            .expect("the boundary had a clock reading, so it could anchor");

        let mut arrived = ctx.clone();
        arrived.deadline_mono_ms = Some(at_boundary);
        let limits = RunLimits::for_command(&arrived, None);
        assert_eq!(limits.deadline(), Some(Deadline(at_boundary)));

        // And the "no clock at either layer" case stays unset on both paths, rather than defaulting
        // to zero on one of them -- which would refuse everything while looking like a limit.
        let unanchored = RunLimits::for_command(&ctx, None);
        assert_eq!(unanchored.deadline(), None);
        assert_eq!(ctx.with_deadline_from(None, 30).deadline_mono_ms, None);
    }

    #[test]
    fn limits_share_the_callers_cancellation_instead_of_copying_it() {
        let token = CancelToken::new();
        let mut ctx = context();
        ctx.cancel = token.clone();
        let limits = RunLimits::for_command(&ctx, None);
        assert!(!limits.describe().contains("fired"));
        token.cancel();
        assert!(
            limits.describe().contains("fired"),
            "cloning the limits must not freeze the flag: {}",
            limits.describe()
        );
    }

    /// The promotions are exactly two, one per class the model already has a name for; everything else
    /// stays "the backend said no". Without the `Busy` half, a mid-cutover busy store is
    /// indistinguishable from a corrupt record and `doctor`'s tally cannot be trusted; without the
    /// capacity half, a caller who set `io_budget.max_bytes` is told the *store* failed.
    #[test]
    fn only_the_stores_own_busy_answer_becomes_storage_contention() {
        for (kind, expect) in [
            (
                caly_storage::StorageErrorKind::Busy,
                RefusalKind::StorageBusy,
            ),
            (
                caly_storage::StorageErrorKind::IntegrityViolation,
                RefusalKind::Backend,
            ),
            (
                caly_storage::StorageErrorKind::NotFound,
                RefusalKind::Backend,
            ),
            (
                caly_storage::StorageErrorKind::SchemaMismatch,
                RefusalKind::Backend,
            ),
        ] {
            let error = caly_storage::StorageError::new(kind, "store text");
            let refusal = StoreRefusal::from_storage_error(&error);
            assert_eq!(refusal.kind, expect, "{kind:?}");
            assert_eq!(
                refusal.message, "store text",
                "the store's own words, unmodified"
            );
            assert!(
                refusal.limits.is_empty(),
                "a store error must not be blamed on limits: {refusal:?}"
            );
        }
    }

    /// The two capacity-shaped store answers must not collapse into one another: a busy store is the
    /// operator's pressure, a payload over the caller's own budget is the caller's mistake. Different
    /// public code, different knob, opposite retryability -- all decided from the kind the store actually
    /// returned, never from prose (`ADR-036 §6bis-decies`).
    #[test]
    fn a_capacity_refusal_is_the_callers_and_a_busy_store_is_the_operators() {
        let over_budget = StoreRefusal::from_storage_error(&caly_storage::StorageError::new(
            caly_storage::StorageErrorKind::CapacityExceeded,
            "port says no",
        ));
        assert_eq!(over_budget.kind, RefusalKind::PayloadTooBig);
        assert!(
            !over_budget.retryable,
            "retrying a payload does not make it smaller: {over_budget:?}"
        );
        assert!(
            !over_budget.is_caller_side(),
            "the caller giving up and the caller asking for too much are different facts"
        );
        assert!(
            over_budget.limits.is_empty(),
            "a port's refusal must not be blamed on this layer's limits: {over_budget:?}"
        );

        let busy = StoreRefusal::from_storage_error(&caly_storage::StorageError::new(
            caly_storage::StorageErrorKind::Busy,
            "store is busy",
        ));
        assert_eq!(busy.kind, RefusalKind::StorageBusy);
        assert!(
            busy.retryable,
            "a busy store is a reason to try again: {busy:?}"
        );
    }

    #[test]
    fn a_zero_poll_budget_is_one_poll_not_a_guaranteed_refusal() {
        assert_eq!(RunLimits::immediate().with_polls(0).max_polls(), 1);
        assert_eq!(RunLimits::immediate().with_polls(3).max_polls(), 3);
    }
}
