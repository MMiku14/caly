use caly_api::{ApiError, DiagnosticSummary, ErrorCategory, ErrorCode, TraceId};

#[derive(Clone, Copy, Debug, Eq, PartialEq, PartialOrd, Ord)]
pub enum OverloadClass {
    QueueFull,
    EventBacklog,
    StreamBackpressure,
    StorageBusy,
}

#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub enum RetryHint {
    RetryImmediately,
    RetryLater,
    ReopenSession,
    ManualIntervention,
}

impl OverloadClass {
    /// The machine-readable name `docs/engineering/OVERLOAD_AND_RETRY_MODEL.md §9` asks the public error to carry
    /// (`error=queue_full`), so a caller can branch on the *class* instead of matching prose.
    pub const fn as_str(self) -> &'static str {
        match self {
            Self::QueueFull => "queue_full",
            Self::EventBacklog => "event_backlog",
            Self::StreamBackpressure => "stream_backpressure",
            Self::StorageBusy => "storage_busy",
        }
    }
}

impl RetryHint {
    pub const fn as_str(self) -> &'static str {
        match self {
            Self::RetryImmediately => "RetryImmediately",
            Self::RetryLater => "RetryLater",
            Self::ReopenSession => "ReopenSession",
            Self::ManualIntervention => "ManualIntervention",
        }
    }

    /// What the caller should actually do. `§4` of the overload model insists a hint is a behaviour,
    /// not UI copy — which is also why it lives next to the hint instead of inside the daemon's mapper,
    /// where a second copy would be free to disagree.
    pub const fn remediation(self) -> &'static str {
        match self {
            Self::RetryImmediately => "retry the request immediately",
            Self::RetryLater => "retry after current queued work drains",
            Self::ReopenSession => "reopen the session and retry",
            Self::ManualIntervention => "inspect daemon status and logs before retrying",
        }
    }
}

/// One pressure event, as the engine saw it.
///
/// The three context fields exist because the public error and the diagnostics exit need the same
/// numbers (`OVERLOAD_AND_RETRY_MODEL §7`: one event, two outlets, no divergence): `queue_len` /
/// `queue_cap` say how deep the backlog was, and `at_generation` says where in the state it happened —
/// which is what makes "a refusal changed nothing" checkable.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct OverloadReport {
    pub class: OverloadClass,
    pub summary: String,
    pub retry_hint: RetryHint,
    pub retryable: bool,
    pub queue_len: Option<usize>,
    pub queue_cap: Option<usize>,
    pub at_generation: u64,
}

impl OverloadReport {
    pub fn queue_full(queue_len: usize, max_len: usize, at_generation: u64) -> Self {
        Self {
            class: OverloadClass::QueueFull,
            summary: format!("command queue full (capacity={max_len})"),
            retry_hint: RetryHint::RetryLater,
            retryable: true,
            queue_len: Some(queue_len),
            queue_cap: Some(max_len),
            at_generation,
        }
    }

    /// The store is busy with something that must not be interrupted (`§6.2`).
    ///
    /// This class had a name, a mapper and no producer since `§3.4` was written -- the same shape of
    /// gap `docs/history/ONBOARDING_NOTES.md §4.73` recorded for the collector itself. The collector is what
    /// fills it: a cycle asked to run while commands are in flight is refused *before* it is queued,
    /// because deleting objects an in-flight deployment will reference is the one mistake here that
    /// cannot be undone.
    pub fn storage_busy(in_flight: usize, at_generation: u64) -> Self {
        Self {
            class: OverloadClass::StorageBusy,
            summary: format!(
                "storage is busy with {in_flight} in-flight command(s); the collector runs only when \
                 the engine is idle (RFC-0007 §13.2)"
            ),
            retry_hint: RetryHint::RetryLater,
            retryable: true,
            queue_len: Some(in_flight),
            queue_cap: None,
            at_generation,
        }
    }

    /// The store refused a write *while a transaction was open* (`§6.2`: "storage busy while
    /// updating journal cursor").
    ///
    /// A different event from [`OverloadReport::storage_busy`], which is an admission refusal issued
    /// before any work started. This one happened inside the transaction, so the hint is
    /// `ManualIntervention` and not `RetryLater`: `§6.2` forbids ending the answer at "try again
    /// later", because the write that was refused is the record the *next* process reads to decide
    /// whether the running system was already changed.
    pub fn journal_pressure(what: String, at_generation: u64, retryable: bool) -> Self {
        Self {
            class: OverloadClass::StorageBusy,
            summary: format!("the apply journal refused {what}"),
            retry_hint: RetryHint::ManualIntervention,
            retryable,
            // The queue depth says nothing about a mid-transaction refusal, so it stays unset rather
            // than borrowed from the apply's own position in the queue.
            queue_len: None,
            queue_cap: None,
            at_generation,
        }
    }

    /// The event window rolled past a follower's cursor (`§3.2`): the caller asked to resume
    /// from a seq the engine no longer retains, so the honest answer is reset-required, not a
    /// stale replay or a silent skip.
    ///
    /// This class had a name and no producer until round 130 — the same gap shape
    /// [`OverloadReport::storage_busy`] closed for `§3.4`. The producer is `events_since`
    /// itself: the engine is where the roll is *observed*, so every follower (query or
    /// stream) records it exactly once per lag incident, and `doctor` / the support bundle
    /// say what the caller was already told.
    pub fn follower_backlog(retained_from: u64, next_seq: u64, at_generation: u64) -> Self {
        Self {
            class: OverloadClass::EventBacklog,
            summary: format!(
                "event window rolled past a follower cursor (retained_from={retained_from} \
                 next_seq={next_seq}); re-sync from the live edge"
            ),
            retry_hint: RetryHint::ReopenSession,
            retryable: true,
            queue_len: None,
            queue_cap: None,
            at_generation,
        }
    }

    /// A stream could not keep its delivery contract (`§3.3`): the client consumed slower
    /// than the window rolled, so the lossless/resumable guarantee was abandoned and the
    /// stream was handed a named `Reset` instead. Recorded where the Reset frame is minted
    /// (the daemon's watch/job bridges) — the frame tells the client, the report tells
    /// `doctor`, one event, two outlets (`§7`).
    pub fn stream_backpressure(
        kind: &str,
        stream_id: u64,
        detail: &str,
        at_generation: u64,
    ) -> Self {
        Self {
            class: OverloadClass::StreamBackpressure,
            summary: format!(
                "{kind} stream {stream_id} could not keep its delivery contract: {detail}; \
                 re-open from the live edge"
            ),
            retry_hint: RetryHint::ReopenSession,
            retryable: true,
            queue_len: None,
            queue_cap: None,
            at_generation,
        }
    }

    /// The machine-readable half of the event: which class, which hint, where in the state.
    ///
    /// Extracted because two outlets need the *same* line -- the public error's `detail`, and the
    /// cursor-guard failure in the worker -- and a second spelling is how `doctor` and the caller
    /// start disagreeing about one event (`docs/history/ONBOARDING_NOTES.md §4.59`).
    pub fn detail(&self) -> String {
        let mut detail = format!(
            "error={} retry_hint={}",
            self.class.as_str(),
            self.retry_hint.as_str()
        );
        if let (Some(len), Some(cap)) = (self.queue_len, self.queue_cap) {
            detail.push_str(&format!(" queue_len={len} queue_cap={cap}"));
        }
        detail.push_str(&format!(" at_generation={}", self.at_generation));
        detail
    }

    /// The single mapping from "engine is under pressure" to a public error.
    ///
    /// The daemon used to own a second mapping (`caly_daemon::error_map::map_overload_report`) that
    /// dropped `retry_hint`, `class` and every number, keeping only `Unavailable` + a category —
    /// precisely the "一条 `Unavailable`，不给任何细分线索" that `§8` forbids, while this function,
    /// which did keep the hint, had no callers at all. Now there is one spelling and the daemon calls
    /// it (`docs/history/ONBOARDING_NOTES.md §4.59`).
    pub fn to_api_error(&self, trace_id: TraceId) -> ApiError {
        let category = match self.class {
            // Storage pressure is an I/O condition the caller cannot fix by re-reading config; the
            // other classes are the daemon's own admission decisions.
            OverloadClass::StorageBusy => ErrorCategory::Io,
            _ => ErrorCategory::Internal,
        };
        let detail = self.detail();
        ApiError::new(
            ErrorCode::Unavailable,
            category,
            self.retryable,
            self.summary.clone(),
            trace_id,
        )
        .with_detail(detail)
        .with_remediation(self.retry_hint.remediation())
        .with_diagnostic(DiagnosticSummary {
            code: self.class.as_str().to_owned(),
            message: self.summary.clone(),
            path: None,
        })
    }
}

/// One line per class of pressure that was ever seen, for `doctor` and the support bundle.
///
/// `totals` is the full history; `recent` is the bounded log (`EngineState::RECENT_OVERLOADS` entries).
/// Counting only the log would repeat the mistake of a truncated read that does not say it was
/// truncated: ten refusals with an eight-entry window would report eight. So the count comes from
/// `totals`, and the window is named whenever it is smaller than that.
pub fn overload_lines(
    recent: &[OverloadReport],
    totals: &std::collections::BTreeMap<OverloadClass, usize>,
) -> Vec<String> {
    let mut out = Vec::new();
    for (class, total) in totals {
        let last = recent.iter().rev().find(|report| report.class == *class);
        let retained = recent
            .iter()
            .filter(|report| report.class == *class)
            .count();
        let detail = match last {
            Some(report) => format!(
                " — {} (hint {}, generation {})",
                report.summary,
                report.retry_hint.as_str(),
                report.at_generation
            ),
            // A class leaves the window only when something else pushed it out, and then the last
            // known detail is genuinely gone: say so instead of printing a line that looks complete.
            None => " — the last refusal for this class has left the retained window".to_owned(),
        };
        let window = if retained < *total {
            format!(", {retained} of them retained")
        } else {
            String::new()
        };
        out.push(format!(
            "overload {}: {} occurrence(s){window}{detail}",
            class.as_str(),
            total
        ));
    }
    out
}
