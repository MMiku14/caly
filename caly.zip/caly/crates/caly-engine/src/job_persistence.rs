//! Typed mapping between the engine's in-memory `JobRecord`/`JobEvent` and the durable
//! `caly_storage::JobLogRecord` envelope (`ADR-057`).
//!
//! `caly-storage` owns the on-disk record shape but deliberately does not depend on the engine's
//! domain types. This module owns the mapping at the engine boundary, the same split
//! `source_persistence.rs` uses for the durable source index:
//!
//! - [`record_from_job`] renders the engine's typed events into the stable `kind<TAB>line` strings
//!   the store keeps, and denormalises the summary counters a restart needs to answer
//!   `jobs.list`/`jobs.follow` without re-parsing or re-running the job.
//! - [`job_from_record`] reconstructs the typed events so the follow stream and support bundle see
//!   the same lines after a restart.
//!
//! Two facts are stored that cannot be re-derived from the event window alone:
//!
//! - the **terminal state** (`completed`/`failed`/`cancelled`/`timed_out`) — a `done` event carries
//!   an outcome, but a record persisted from a job that died without one still has to say what
//!   state it was read back as; and
//! - the **stable failure code** (`PERMISSION`, `STORAGE`, …), so a post-restart `caly job <id>`
//!   maps to the same documented exit code without the full `ApiError` (only its public, already
//!   redacted identity is stored — category/retryable are derived from the code, never persisted).
//!
//! Only **terminal** jobs are mapped; the engine keeps live events in memory and persists once at
//! the terminal commit point (D3, `ADR-057` §5). A crash mid-job leaves no file, and recovery
//! converges that job the way `RFC-0005 §12` already does.

use caly_api::{ErrorCode, JobId};
use caly_storage::job_log::{JobEventRecord, JobLogRecord};

use crate::job::{JobEvent, JobOutcome, JobRecord, JobState};

/// How many terminal job logs the durable store keeps (`ADR-057` §4 "留存有界、随 GC 回收").
///
/// Aligned with the daemon's `JOB_LIST_CAP` (the newest jobs `jobs.list` can answer): retaining at
/// least that many means a fresh restart answers the full discovery window from the durable set
/// before the in-memory map holds anything newer. Reclamation is reclaiming **event history only**
/// — it never removes a committed snapshot or revision; the newest `JOB_LOG_RETENTION` terminal
/// jobs are always kept (the bounded analogue of "a job the retained set still names"), so the
/// most recent `last-apply` job is never the first thing a cycle ages out.
///
/// `pub` (not `pub(crate)`) so the integration test in
/// `crates/caly-engine/tests/job_log_durability.rs` can drive the engine across the window without
/// re-typing the number.
pub const JOB_LOG_RETENTION: usize = 64;

/// Stable wire-state name, the same spelling `JobFollowView.state` and the CLI table use
/// (`format!("{:?}", state).to_lowercase()`). Centralised here so the durable value and the live
/// projection cannot spell a terminal state two different ways.
pub(crate) fn job_state_name(state: JobState) -> &'static str {
    match state {
        JobState::Accepted => "accepted",
        JobState::Queued => "queued",
        JobState::Running => "running",
        JobState::WaitingInput => "waiting_input",
        JobState::Completed => "completed",
        JobState::Failed => "failed",
        JobState::Cancelled => "cancelled",
        // `{:?}` lowercases `TimedOut` to `timedout`; keep the durable spelling identical.
        JobState::TimedOut => "timedout",
    }
}

pub(crate) fn job_state_from_name(value: &str) -> Result<JobState, String> {
    match value {
        "accepted" => Ok(JobState::Accepted),
        "queued" => Ok(JobState::Queued),
        "running" => Ok(JobState::Running),
        "waiting_input" => Ok(JobState::WaitingInput),
        "completed" => Ok(JobState::Completed),
        "failed" => Ok(JobState::Failed),
        "cancelled" => Ok(JobState::Cancelled),
        "timedout" => Ok(JobState::TimedOut),
        other => Err(format!(
            "job log carries an unknown terminal state {other:?}"
        )),
    }
}

fn outcome_name(outcome: JobOutcome) -> &'static str {
    match outcome {
        JobOutcome::Succeeded => "succeeded",
        JobOutcome::Failed => "failed",
        JobOutcome::Cancelled => "cancelled",
        JobOutcome::TimedOut => "timed_out",
    }
}

fn outcome_from_name(value: &str) -> Result<JobOutcome, String> {
    match value {
        "succeeded" => Ok(JobOutcome::Succeeded),
        "failed" => Ok(JobOutcome::Failed),
        "cancelled" => Ok(JobOutcome::Cancelled),
        "timed_out" => Ok(JobOutcome::TimedOut),
        other => Err(format!("job log carries an unknown outcome {other:?}")),
    }
}

/// The event tag stored in the repeated `event` key — a small closed set, never the rendered line.
fn event_kind_name(event: &JobEvent) -> &'static str {
    match event {
        JobEvent::Stage { .. } => "stage",
        JobEvent::Log { .. } => "log",
        JobEvent::Warning { .. } => "warning",
        JobEvent::Done { .. } => "done",
        JobEvent::Failed { .. } => "failed",
    }
}

fn error_code_from_str(value: &str) -> Option<ErrorCode> {
    // The closed set of public codes, matched against their stable wire spelling. Keeping this list
    // in the engine (not deriving it from serde) means a code added to the API but never meant to
    // reach a durable record does not silently become one.
    const CODES: [ErrorCode; 14] = [
        ErrorCode::ConfigInvalid,
        ErrorCode::Conflict,
        ErrorCode::UnsupportedCapability,
        ErrorCode::CoreNotRunning,
        ErrorCode::CoreFailed,
        ErrorCode::Permission,
        ErrorCode::NetOs,
        ErrorCode::Storage,
        ErrorCode::Timeout,
        ErrorCode::Unavailable,
        ErrorCode::ProtoMismatch,
        ErrorCode::CursorStale,
        ErrorCode::Cancelled,
        ErrorCode::Internal,
    ];
    CODES.into_iter().find(|code| code.as_str() == value)
}

/// Render one typed event to the exact human-facing line `jobs.events` prints, so a restarted
/// daemon reproduces the same text the original would have streamed.
fn render_event_line(event: &JobEvent) -> String {
    crate::bundle::render_job_event(event)
}

/// Build the durable terminal record for one job. Only terminal states are persisted; a non-terminal
/// job has no record to write yet (the caller checks before persisting).
pub(crate) fn record_from_job(
    job: &JobRecord,
    committed_at_unix_ms: i64,
) -> Result<JobLogRecord, String> {
    if !is_terminal(job.state) {
        return Err(format!(
            "job {} is not in a terminal state ({:?}); only terminal jobs are persisted",
            job.id.0, job.state
        ));
    }

    let mut events = Vec::with_capacity(job.events.len());
    let mut outcome: Option<String> = None;
    let mut failure_code: Option<String> = None;
    let mut failure_summary: Option<String> = None;
    let mut last_stage: Option<String> = None;
    let mut last_stage_pct: Option<u8> = None;
    let mut warning_count = 0usize;
    let mut log_count = 0usize;

    for event in &job.events {
        match event {
            JobEvent::Stage { stage, pct } => {
                last_stage = Some(stage.clone());
                last_stage_pct = *pct;
            }
            JobEvent::Log { .. } => log_count += 1,
            JobEvent::Warning { .. } => warning_count += 1,
            JobEvent::Done { outcome: done } => {
                outcome = Some(outcome_name(*done).to_owned());
            }
            JobEvent::Failed { error } => {
                failure_code = Some(error.code.as_str().to_owned());
                failure_summary = Some(error.summary.clone());
            }
        }
        events.push(JobEventRecord {
            kind: event_kind_name(event).to_owned(),
            line: render_event_line(event),
        });
    }

    Ok(JobLogRecord {
        job_id: job.id.0.to_string(),
        state: job_state_name(job.state).to_owned(),
        revision: job.revision,
        outcome,
        failure_code,
        failure_summary,
        last_stage,
        last_stage_pct,
        warning_count,
        log_count,
        events,
        committed_at_unix_ms,
    })
}

/// Reconstruct a typed terminal job from its durable record. The reconstructed events are the
/// rendered lines a `failed`/`done`/`stage`/… event would carry; the `ApiError` is rebuilt from its
/// stable public code plus the stored, already-redacted summary (category/retryable come from the
/// code, so nothing else about the error has to be persisted).
pub(crate) fn job_from_record(record: &JobLogRecord) -> Result<JobRecord, String> {
    let job_id = record
        .job_id
        .parse::<u64>()
        .map_err(|_| format!("job log job_id {:?} is not a numeric job id", record.job_id))?;
    let state = job_state_from_name(&record.state)?;

    let mut events = Vec::with_capacity(record.events.len());
    for (index, event) in record.events.iter().enumerate() {
        events.push(decode_event(event, index, &record.outcome)?);
    }

    // A `failed` job must carry a usable stable code; a record that says failed but names a code this
    // build does not know is a schema we cannot honestly reproduce — refuse it by name.
    if state == JobState::Failed {
        let code_text = record
            .failure_code
            .as_deref()
            .ok_or_else(|| "a failed job log carries no failure_code".to_owned())?;
        if error_code_from_str(code_text).is_none() {
            return Err(format!(
                "job log for failed job {job_id} carries an unknown failure code {code_text:?}"
            ));
        }
    }

    Ok(JobRecord {
        id: JobId(job_id),
        state,
        revision: record.revision,
        events,
    })
}

fn decode_event(
    event: &JobEventRecord,
    index: usize,
    outcome: &Option<String>,
) -> Result<JobEvent, String> {
    let where_ = || format!("job log event {index} ({})", event.kind);
    let line = event.line.as_str();
    match event.kind.as_str() {
        "stage" => {
            // Shape: `[stage 70%] name` or `[stage] name`.
            if let Some(rest) = line.strip_prefix("[stage ") {
                // `[stage <pct>%] <name>` → rest is `<pct>%] <name>`.
                let close = rest
                    .find("] ")
                    .ok_or_else(|| format!("{} stage line is missing its separator", where_()))?;
                let pct_text = &rest[..close];
                let pct = pct_text
                    .strip_suffix('%')
                    .and_then(|digits| digits.parse::<u8>().ok())
                    .filter(|value| *value <= 100)
                    .ok_or_else(|| {
                        format!("{} stage percentage {pct_text:?} is not 0-100", where_())
                    })?;
                let name = rest[close + 2..].to_owned();
                Ok(JobEvent::Stage {
                    stage: name,
                    pct: Some(pct),
                })
            } else {
                // `[stage] <name>`.
                let name = line
                    .strip_prefix("[stage]")
                    .ok_or_else(|| format!("{} does not have the stage line shape", where_()))?
                    .trim_start()
                    .to_owned();
                Ok(JobEvent::Stage {
                    stage: name,
                    pct: None,
                })
            }
        }
        "log" => {
            // Shape: `[log:<level>] <message>`.
            let body = line
                .strip_prefix("[log:")
                .ok_or_else(|| format!("{} does not have the log line shape", where_()))?;
            let close = body
                .find("] ")
                .ok_or_else(|| format!("{} log line is missing its separator", where_()))?;
            let level = body[..close].to_owned();
            let message = body[close + 2..].to_owned();
            Ok(JobEvent::Log { level, message })
        }
        "warning" => {
            // Shape: `[warn] <message>`.
            let message = line
                .strip_prefix("[warn] ")
                .ok_or_else(|| format!("{} does not have the warning line shape", where_()))?
                .to_owned();
            Ok(JobEvent::Warning { message })
        }
        "done" => {
            // The outcome is the durable truth; the line is just `[done] <Outcome>`.
            let outcome_text = outcome.as_deref().ok_or_else(|| {
                format!("{} done event but the record carries no outcome", where_())
            })?;
            let done = outcome_from_name(outcome_text)?;
            Ok(JobEvent::Done { outcome: done })
        }
        "failed" => {
            let code_text = line
                .strip_prefix("[failed ")
                .and_then(|rest| rest.split(']').next())
                .ok_or_else(|| format!("{} does not have the failed line shape", where_()))?;
            let code = error_code_from_str(code_text).ok_or_else(|| {
                format!(
                    "{} names failure code {code_text:?} this build does not know",
                    where_()
                )
            })?;
            let summary = line
                .split_once("] ")
                .map(|(_, text)| text.to_owned())
                .unwrap_or_default();
            // The rebuilt error is used for its stable public code/summary on the follow stream, not
            // for tracing across the process boundary that ended — so a placeholder trace id is the
            // honest choice: category/retryable derive from the code, never from the record.
            let error = caly_api::ApiError::for_code(
                code,
                summary,
                caly_common::TraceId::new("recovered-job"),
            );
            Ok(JobEvent::Failed { error })
        }
        other => Err(format!(
            "job log event {index} carries an unknown event kind {other:?}"
        )),
    }
}

fn is_terminal(state: JobState) -> bool {
    matches!(
        state,
        JobState::Completed | JobState::Failed | JobState::Cancelled | JobState::TimedOut
    )
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::job::{JobEvent, JobRecord, JobState};
    use caly_api::{ErrorCode, JobId};

    fn failed_api_error() -> caly_api::ApiError {
        caly_api::ApiError::for_code(
            ErrorCode::Permission,
            "role Viewer does not satisfy required role Admin",
            caly_common::TraceId::new("trace-x"),
        )
    }

    fn terminal_failed_job() -> JobRecord {
        JobRecord {
            id: JobId(7),
            state: JobState::Failed,
            revision: 12,
            events: vec![
                JobEvent::Stage {
                    stage: "storage.project".to_owned(),
                    pct: Some(70),
                },
                JobEvent::Log {
                    level: "info".to_owned(),
                    message: "Prepare 01: write-object mihomo:abc".to_owned(),
                },
                JobEvent::Warning {
                    message: "a redacted warning\nwith two lines".to_owned(),
                },
                JobEvent::Failed {
                    error: failed_api_error(),
                },
                JobEvent::Done {
                    outcome: JobOutcome::Failed,
                },
            ],
        }
    }

    #[test]
    fn a_terminal_failed_job_round_trips_through_the_durable_record() {
        let job = terminal_failed_job();
        let record = record_from_job(&job, 1_700_000_000_000).expect("terminal job maps");
        assert_eq!(record.job_id, "7");
        assert_eq!(record.state, "failed");
        assert_eq!(record.revision, 12);
        assert_eq!(record.outcome.as_deref(), Some("failed"));
        assert_eq!(record.failure_code.as_deref(), Some("PERMISSION"));
        assert_eq!(record.warning_count, 1);
        assert_eq!(record.log_count, 1);
        assert_eq!(record.last_stage.as_deref(), Some("storage.project"));
        assert_eq!(record.last_stage_pct, Some(70));

        let back = job_from_record(&record).expect("record maps back");
        assert_eq!(back.id, JobId(7));
        assert_eq!(back.state, JobState::Failed);
        assert_eq!(back.revision, 12);
        // The failed event rebuilds the stable code and the redacted summary; the rendered line
        // matches what the live job would have streamed.
        match back
            .events
            .iter()
            .find(|event| matches!(event, JobEvent::Failed { .. }))
        {
            Some(JobEvent::Failed { error }) => {
                assert_eq!(error.code, ErrorCode::Permission);
                assert!(error.summary.contains("role Viewer"), "{}", error.summary);
            }
            other => panic!("expected a failed event, got {other:?}"),
        }
        // Every reconstructed event renders to the same line the record stored.
        for (typed, stored) in back.events.iter().zip(record.events.iter()) {
            assert_eq!(crate::bundle::render_job_event(typed), stored.line);
        }
    }

    #[test]
    fn a_succeeded_job_without_a_failure_carries_no_failure_code() {
        let job = JobRecord {
            id: JobId(3),
            state: JobState::Completed,
            revision: 1,
            events: vec![
                JobEvent::Stage {
                    stage: "done".to_owned(),
                    pct: Some(100),
                },
                JobEvent::Done {
                    outcome: JobOutcome::Succeeded,
                },
            ],
        };
        let record = record_from_job(&job, 100).expect("maps");
        assert_eq!(record.state, "completed");
        assert!(record.failure_code.is_none());
        assert_eq!(record.outcome.as_deref(), Some("succeeded"));
        let back = job_from_record(&record).expect("maps back");
        assert_eq!(back.state, JobState::Completed);
    }

    #[test]
    fn a_non_terminal_job_is_refused_rather_than_persisted() {
        let job = JobRecord {
            id: JobId(9),
            state: JobState::Running,
            revision: 2,
            events: Vec::new(),
        };
        let error = record_from_job(&job, 1).expect_err("a running job has no terminal record");
        assert!(error.contains("not in a terminal state"), "{error}");
    }

    #[test]
    fn a_record_with_an_unknown_state_or_failure_code_is_refused() {
        let mut record = record_from_job(&terminal_failed_job(), 1).expect("maps");
        record.state = "zombie".to_owned();
        assert!(job_from_record(&record).is_err(), "unknown state refused");

        let mut record = record_from_job(&terminal_failed_job(), 1).expect("maps");
        record.failure_code = Some("NOT_A_REAL_CODE".to_owned());
        let error = job_from_record(&record).expect_err("unknown code refused");
        assert!(error.contains("NOT_A_REAL_CODE"), "{error}");
    }

    #[test]
    fn a_record_with_an_unknown_event_kind_is_refused() {
        let mut record = record_from_job(&terminal_failed_job(), 1).expect("maps");
        record.events[0].kind = "teleport".to_owned();
        let error = job_from_record(&record).expect_err("unknown event kind refused");
        assert!(error.contains("teleport"), "{error}");
    }
}
