use caly_api::{Accepted, EstimatedImpact};

use crate::command::Command;
use crate::coordinator::accept_command;
use crate::dispatch::{classify_command, DispatchDecision};
use crate::event::{EventKind, EventPayload};
use crate::job::{JobEvent, JobOutcome, JobState};
use crate::overload::OverloadReport;
use crate::state::{EngineLifecycle, EngineState, EnqueueResult, QueuedCommand};

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct ProcessedCommand {
    pub accepted: Accepted,
    pub dispatch: DispatchDecision,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct SubmitRejected {
    pub reason: String,
    pub overload: Option<OverloadReport>,
}

pub fn submit_command(
    state: &mut EngineState,
    command: Command,
) -> Result<ProcessedCommand, SubmitRejected> {
    let dispatch = classify_command(&command);

    // Admission is decided before anything is mutated. This function used to allocate a job id and
    // `bump_generation()` first, so a command refused for a full queue still advanced the revision —
    // and `generation` is exactly what `expected_revision` is compared against (`RFC-0002 §6.2`) and
    // what the daemon publishes as `state_revision`. A refusal under load therefore poisoned other
    // callers' compare-and-swap preconditions while changing nothing: `OVERLOAD_AND_RETRY_MODEL §3.1`
    // says a `QueueFull` must "不产生 apply side effect", and a phantom revision bump is one
    // (`docs/history/ONBOARDING_NOTES.md §4.58`).
    if !state.queue.has_capacity() {
        return Err(rejected_for_full_queue(state, &command));
    }

    // A collection cycle is refused here, before a job id exists and before the generation moves, for
    // the same reason `§3.1` refuses a full queue at this point: a refusal that advances the revision
    // poisons every other caller's `expected_revision` while having changed nothing (`§4.58`, and the
    // `StorageBusy` class this fills had been waiting for a producer since `§6.2`).
    if matches!(command.kind, crate::command::CommandKind::StorageGc { .. })
        && crate::gc_plan::has_work_in_flight(state)
    {
        return Err(rejected_for_busy_storage(state, &command));
    }

    let job_id = state.next_job_id();
    let revision = state.bump_generation().0;
    let accepted = accept_command(job_id, revision, dispatch.estimated_impact);

    match state.enqueue(job_id, command.clone()) {
        EnqueueResult::Accepted => {
            state.insert_job(accepted.job.clone());
            state.events.push(
                EventKind::CommandAccepted,
                Some(command.id.0.clone()),
                EventPayload::CommandAccepted { job_id, revision },
            );
            Ok(ProcessedCommand {
                accepted: accepted.accepted,
                dispatch,
            })
        }
        EnqueueResult::RejectedFull { max_len } => {
            // Unreachable by construction: the capacity check above and this push happen under the
            // same `&mut EngineState` borrow, so nothing can grow the queue in between. Kept as an
            // explicit failure rather than a panic or a silent retry — reaching it would mean the
            // queue grew inside its own type, and that must not be answered with "no" or with "yes".
            let _ = max_len;
            Err(SubmitRejected {
                reason: "the queue refused a command that admission had just accepted".to_owned(),
                overload: None,
            })
        }
    }
}

/// Refuse one command because the queue is full, and leave that refusal visible in both outlets
/// `OVERLOAD_AND_RETRY_MODEL §7` asks for: the caller's `ApiError` (built by the caller's mapper from
/// the report below) and the diagnostics event.
fn rejected_for_full_queue(state: &mut EngineState, command: &Command) -> SubmitRejected {
    let overload =
        OverloadReport::queue_full(state.queue.len(), state.queue.capacity(), state.generation);
    state.record_overload(overload.clone());
    state.events.push(
        EventKind::CommandRejected,
        Some(command.id.0.clone()),
        EventPayload::CommandRejected {
            reason: overload.summary.clone(),
        },
    );
    SubmitRejected {
        reason: overload.summary.clone(),
        overload: Some(overload),
    }
}

/// Refuse a collection cycle because the store is busy, through the same two outlets as every other
/// admission refusal: the caller's `ApiError` and the diagnostics log `doctor` reads.
fn rejected_for_busy_storage(state: &mut EngineState, command: &Command) -> SubmitRejected {
    let overload =
        OverloadReport::storage_busy(crate::gc_plan::work_in_flight(state), state.generation);
    state.record_overload(overload.clone());
    state.events.push(
        EventKind::CommandRejected,
        Some(command.id.0.clone()),
        EventPayload::CommandRejected {
            reason: overload.summary.clone(),
        },
    );
    SubmitRejected {
        reason: overload.summary.clone(),
        overload: Some(overload),
    }
}

pub fn poll_next_command(state: &mut EngineState) -> Option<QueuedCommand> {
    let queued = state.dequeue_next()?;
    state.set_lifecycle(EngineLifecycle::Busy);
    state.mark_job_state(queued.job_id, JobState::Queued);
    Some(queued)
}

pub fn mark_running(state: &mut EngineState, queued: &QueuedCommand) {
    state.mark_job_state(queued.job_id, JobState::Running);
    if let Some(job) = state.get_job_mut(queued.job_id) {
        job.events.push(JobEvent::Stage {
            stage: "running".to_owned(),
            pct: Some(0),
        });
    }
    state.events.push(
        EventKind::JobUpdated,
        Some(queued.command.id.0.clone()),
        EventPayload::JobUpdated {
            job_id: queued.job_id,
            state: "running".to_owned(),
        },
    );
}

pub fn mark_finished(
    state: &mut EngineState,
    queued: &QueuedCommand,
    outcome: JobOutcome,
    impact: EstimatedImpact,
) {
    let next_state = match outcome {
        JobOutcome::Succeeded => JobState::Completed,
        JobOutcome::Failed => JobState::Failed,
        JobOutcome::Cancelled => JobState::Cancelled,
        JobOutcome::TimedOut => JobState::TimedOut,
    };

    let bumped_revision = match impact {
        EstimatedImpact::Noop | EstimatedImpact::ReadOnly => None,
        _ => Some(state.bump_generation().0),
    };

    state.mark_job_state(queued.job_id, next_state);
    if let Some(job) = state.get_job_mut(queued.job_id) {
        job.events.push(JobEvent::Done { outcome });
        if let Some(revision) = bumped_revision {
            job.revision = job.revision.max(revision);
        }
    }
    state.set_lifecycle(EngineLifecycle::Idle);
    state.events.push(
        EventKind::JobUpdated,
        Some(queued.command.id.0.clone()),
        EventPayload::JobUpdated {
            job_id: queued.job_id,
            state: format!("{:?}", next_state).to_lowercase(),
        },
    );
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::command::{CommandId, CommandKind};
    use crate::event::EventKind;
    use crate::overload::{OverloadClass, RetryHint};
    use crate::queue::{CommandQueue, QueuePolicy};
    use caly_api::{ApplyRequest, ErrorCode, JobId, ProfileId};
    use caly_common::{Actor, RequestContext, TraceId};

    fn apply_command(profile: &str, tag: &str) -> Command {
        Command {
            id: CommandId(format!("cmd-{tag}")),
            request_id: None,
            actor: Actor::Cli,
            context: RequestContext::new(TraceId::new(format!("trace-{tag}")), Actor::Cli),
            timeout_ms: None,
            idempotency_key: None,
            kind: CommandKind::ProfileApply(ApplyRequest {
                profile_id: ProfileId(profile.to_owned()),
                dry_run: false,
                strict: false,
            }),
        }
    }

    fn state_with_queue(capacity: usize) -> EngineState {
        let mut state = EngineState::new();
        state.queue = CommandQueue::with_policy(QueuePolicy::bounded(capacity));
        state
    }

    /// `OVERLOAD_AND_RETRY_MODEL §3.1`: a `QueueFull` refusal happens before the request enters the
    /// execution state and must not produce a side effect. Generation is the value every
    /// `expected_revision` is compared against, so bumping it while refusing is a side effect on
    /// *other* callers — which is what this pins (`docs/history/ONBOARDING_NOTES.md §4.58`).
    #[test]
    fn a_refusal_for_a_full_queue_advances_nothing_but_the_record_of_the_refusal() {
        let mut state = state_with_queue(1);
        let first = submit_command(&mut state, apply_command("p1", "a")).expect("first accepted");
        assert_eq!(first.accepted.state_revision, 1, "{:?}", first.accepted);
        assert_eq!(first.accepted.job_id, JobId(1));

        let rejected =
            submit_command(&mut state, apply_command("p2", "b")).expect_err("must refuse");
        let report = rejected.overload.expect("a refusal carries its class");
        assert_eq!(report.class, OverloadClass::QueueFull);
        assert_eq!(report.queue_len, Some(1));
        assert_eq!(report.queue_cap, Some(1));
        assert_eq!(report.at_generation, 1, "{report:?}");

        assert_eq!(state.generation, 1, "a refused command changed no state");
        assert_eq!(state.next_job_id, 2, "and consumed no job id");
        assert!(!state.jobs.contains_key(&2), "no phantom job record");
        assert_eq!(
            state.queue.len(),
            1,
            "the queue still holds only the accepted one"
        );

        // The next command that fits continues where the last accepted one stopped.
        poll_next_command(&mut state).expect("drain the accepted command");
        let third = submit_command(&mut state, apply_command("p3", "c")).expect("accepted again");
        assert_eq!(third.accepted.state_revision, 2, "{:?}", third.accepted);
        assert_eq!(third.accepted.job_id, JobId(2));
    }

    /// Two outlets, one truth (§7.2): the caller sees the error, the operator sees the record — and
    /// the record is bounded without becoming an undercount.
    #[test]
    fn ten_refusals_are_ten_occurrences_even_though_the_log_keeps_eight() {
        let mut state = state_with_queue(0);
        for index in 0..10 {
            let rejected = submit_command(&mut state, apply_command("p", &index.to_string()))
                .expect_err("a zero-capacity queue refuses everything");
            assert!(rejected.overload.is_some(), "{rejected:?}");
        }
        let rejected_events = state
            .events
            .events
            .iter()
            .filter(|event| matches!(event.kind, EventKind::CommandRejected))
            .count();
        assert_eq!(
            rejected_events, 10,
            "one event per refusal, none per phantom job"
        );
        assert_eq!(state.overloads.len(), EngineState::RECENT_OVERLOADS);
        assert_eq!(state.overload_totals[&OverloadClass::QueueFull], 10);

        let lines = state.overload_lines();
        assert_eq!(lines.len(), 1, "{lines:?}");
        assert!(lines[0].contains("10 occurrence(s)"), "{lines:?}");
        assert!(
            lines[0].contains(&format!(
                "{} of them retained",
                EngineState::RECENT_OVERLOADS
            )),
            "a bounded window must say it is bounded: {lines:?}"
        );
        assert!(lines[0].contains("hint RetryLater"), "{lines:?}");

        // Nothing to report stays empty rather than a reassuring line.
        let quiet = EngineState::new();
        assert!(
            quiet.overload_lines().is_empty(),
            "{:?}",
            quiet.overload_lines()
        );
    }

    /// The public error is where `retry_hint` becomes actionable text. The daemon used to rebuild its
    /// own, thinner, version of this error (`§4.59`), so the mapping is pinned here rather than left
    /// to "obviously someone reads the hint".
    #[test]
    fn the_public_error_names_the_class_the_hint_and_the_numbers() {
        let error = OverloadReport::queue_full(256, 256, 7).to_api_error(TraceId::new("trace-x"));
        assert_eq!(error.code, ErrorCode::Unavailable, "{error:?}");
        assert_eq!(
            error.category,
            caly_api::ErrorCategory::Internal,
            "{error:?}"
        );
        assert!(
            error.retryable,
            "queue full is transient by definition: {error:?}"
        );
        assert_eq!(
            error.remediation.as_deref(),
            Some(RetryHint::RetryLater.remediation()),
            "{error:?}"
        );
        let detail = error.detail.clone().unwrap_or_default();
        for token in [
            "error=queue_full",
            "retry_hint=RetryLater",
            "queue_len=256",
            "queue_cap=256",
            "at_generation=7",
        ] {
            assert!(detail.contains(token), "{token} missing from {detail}");
        }
        assert!(
            error
                .diagnostics
                .iter()
                .any(|diagnostic| diagnostic.code == "queue_full"),
            "{error:?}"
        );

        // Same event, different class: storage pressure is I/O, and the class still reaches the caller.
        let busy = OverloadReport {
            class: OverloadClass::StorageBusy,
            summary: "snapshot write is busy".to_owned(),
            retry_hint: RetryHint::RetryLater,
            retryable: true,
            queue_len: None,
            queue_cap: None,
            at_generation: 3,
        };
        let error = busy.to_api_error(TraceId::new("trace-y"));
        assert_eq!(error.category, caly_api::ErrorCategory::Io, "{error:?}");
        let detail = error.detail.clone().unwrap_or_default();
        assert!(detail.contains("error=storage_busy"), "{detail}");
        assert!(
            !detail.contains("queue_len"),
            "a report without queue context must not invent one: {detail}"
        );
    }
}
