//! Support bundle export — `docs/engineering/STORAGE_RECOVERY_EXECUTION_PLAN.md §9.3` and `RFC-0010 §12`.
//!
//! `§9.3` names four things the export must carry once storage and recovery are wired:
//!
//! ```text
//! - recent apply journal summaries
//! - active snapshot metadata
//! - last-known-good metadata
//! - recovery incident summary
//! ```
//!
//! `RFC-0010 §12.2` adds what a bundle must additionally contain (architecture state, version
//! information, capability summary, redacted logs, redacted apply report, resource statistics) and
//! `§12.3` what it must not (full subscription URLs, node passwords, API tokens, raw secret-store
//! content). `DiagnosticsOp::SupportBundle` used to answer with a single job log line saying
//! "support bundle skeleton generated"; that line is what this module replaces.
//!
//! # Where redaction happens
//!
//! `RFC-0010 §3.3` requires masking at *object construction*, not at render time, so the type a
//! caller can export is [`SupportBundle`] — which only exists already masked, produced by
//! [`BundleDraft::finish`]. The draft is the pre-masking view and is kept public for one reason:
//! a test has to be able to show that the unredacted text *did* contain the secret, otherwise
//! "the bundle leaks nothing" is unfalsifiable and could just mean "the bundle is empty".
//!
//! The bundle's own policy is [`RedactionPolicy::Strict`] (`§12.1`: the reader is someone else),
//! escalated from whatever the process redactor is, so registered literal secrets still apply.
//!
//! # Where the bytes go
//!
//! Into the CAS as an `ObjectKind::SupportBundle` object, so the object digest is the bundle's
//! identity and the export is verifiable (`RFC-0007 §6.2-6.3`). Nothing is written to a
//! caller-chosen path: choosing *where* a user's diagnostics land is a platform decision the
//! façade does not have yet (`docs/history/ONBOARDING_NOTES.md §4.29`), and the operator-facing handle is
//! the digest reported on the job. Because no snapshot references a bundle object, `§13`'s GC is
//! free to collect it after the grace period — which is the intended lifetime for a diagnostics
//! export, not an oversight.

use std::collections::BTreeMap;
use std::sync::Arc;

use caly_common::redact::{RedactionPolicy, Redactor};
use caly_storage::StorageBackend;

use crate::state::EngineState;

/// The section names, in the order they are rendered.
///
/// A const list rather than whatever the collectors happened to produce: the `§14.3` gate and the
/// contract assertions both need a fixed expectation to check, and an export that silently loses a
/// section is the failure mode a support engineer cannot debug from the inside.
pub const BUNDLE_SECTIONS: [&str; 12] = [
    "header",
    "architecture",
    "capability",
    "apply-journals",
    "snapshots",
    "recovery",
    "effect-plan",
    "runtime-log",
    "resources",
    "overload",
    "storage-audit",
    // What the last collection cycle did, or that none has run (`ADR-038 §2`). Its own section rather
    // than lines inside `storage-audit`: the audit answers "is the store consistent", this answers
    // "what did we reclaim, and did we dare" -- two questions an operator reads separately.
    "storage-gc",
];

/// Content type recorded on the CAS object.
pub const BUNDLE_CONTENT_TYPE: &str = "text/plain; charset=utf-8";

/// How the bundle is masked, whatever the daemon was configured with (`§12.1`).
pub const BUNDLE_POLICY: RedactionPolicy = RedactionPolicy::Strict;

/// How many recent jobs contribute log lines, and how many lines each contributes.
///
/// Bounded because the bundle is handed to third parties and is built on a machine that may be in
/// a bad state: an unbounded export is a second way to make things worse.
const LOG_TAIL_JOBS: usize = 4;
const LOG_TAIL_LINES_PER_JOB: usize = 12;
/// How many recent apply journals are summarised.
const RECENT_JOURNALS: usize = 8;

/// Which process this bundle describes.
///
/// The engine does not own these strings — the composition root does — so they are handed in at
/// bootstrap rather than guessed at here.
#[derive(Clone, Debug, Eq, PartialEq, Default)]
pub struct BundleIdentity {
    pub instance_id: String,
    pub daemon_name: String,
    pub daemon_version: String,
    pub protocol_version: String,
}

impl BundleIdentity {
    pub fn new(
        instance_id: impl Into<String>,
        daemon_name: impl Into<String>,
        daemon_version: impl Into<String>,
        protocol_version: impl Into<String>,
    ) -> Self {
        Self {
            instance_id: instance_id.into(),
            daemon_name: daemon_name.into(),
            daemon_version: daemon_version.into(),
            protocol_version: protocol_version.into(),
        }
    }

    /// Crate version of the control plane, from the workspace manifest.
    pub const fn caly_version() -> &'static str {
        env!("CARGO_PKG_VERSION")
    }

    pub const fn build_profile() -> &'static str {
        if cfg!(debug_assertions) {
            "debug"
        } else {
            "release"
        }
    }
}

/// One named block of lines.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct BundleSection {
    pub name: String,
    pub lines: Vec<String>,
}

impl BundleSection {
    pub fn new(name: &str) -> Self {
        Self {
            name: name.to_owned(),
            lines: Vec::new(),
        }
    }

    pub fn push(&mut self, line: impl Into<String>) {
        self.lines.push(line.into());
    }

    pub fn line_count(&self) -> usize {
        self.lines.len()
    }
}

/// The pre-masking view of a bundle. Never exported (`§3.3`).
#[derive(Clone, Debug, Eq, PartialEq, Default)]
pub struct BundleDraft {
    pub generated_at_unix_ms: i64,
    pub sections: Vec<BundleSection>,
}

impl BundleDraft {
    pub fn new(generated_at_unix_ms: i64) -> Self {
        Self {
            generated_at_unix_ms,
            sections: Vec::new(),
        }
    }

    /// Index of the named section, creating it (empty, at the end) on first use.
    fn ensure_section(&mut self, name: &str) -> usize {
        if let Some(index) = self
            .sections
            .iter()
            .position(|section| section.name == name)
        {
            return index;
        }
        self.sections.push(BundleSection::new(name));
        self.sections.len() - 1
    }

    /// Append one line to the named section. Sections appear in the order they are first written,
    /// which is why [`collect_bundle_draft`] calls the collectors in `BUNDLE_SECTIONS` order.
    pub fn push_line(&mut self, name: &str, line: impl Into<String>) {
        let text = line.into();
        let index = self.ensure_section(name);
        self.sections[index].push(text);
    }

    pub fn line_count(&self) -> usize {
        self.sections
            .iter()
            .map(|section| section.line_count())
            .sum()
    }

    /// Unredacted text. Test and inspection surface only: `run_bundle_job` writes
    /// [`SupportBundle`]'s bytes and nothing else, so this render never reaches storage or a
    /// client. See the module docs for why the draft is public at all.
    pub fn render(&self) -> String {
        render_sections(self.generated_at_unix_ms, BUNDLE_POLICY, &self.sections)
    }

    /// Mask every line and freeze the result into the only exportable form.
    pub fn finish(self, redactor: &Redactor) -> SupportBundle {
        let policy = redactor.policy();
        let sections = self
            .sections
            .into_iter()
            .map(|section| BundleSection {
                name: redactor.redact(&section.name),
                lines: section
                    .lines
                    .into_iter()
                    .map(|line| redactor.redact(&line))
                    .collect(),
            })
            .collect();
        SupportBundle {
            generated_at_unix_ms: self.generated_at_unix_ms,
            policy,
            sections,
        }
    }
}

/// A redacted, exportable bundle.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct SupportBundle {
    pub generated_at_unix_ms: i64,
    pub policy: RedactionPolicy,
    pub sections: Vec<BundleSection>,
}

impl SupportBundle {
    pub fn section(&self, name: &str) -> Option<&BundleSection> {
        self.sections.iter().find(|section| section.name == name)
    }

    pub fn lines_of(&self, name: &str) -> Vec<&str> {
        self.section(name)
            .map(|section| section.lines.iter().map(String::as_str).collect())
            .unwrap_or_default()
    }

    pub fn line_count(&self) -> usize {
        self.sections
            .iter()
            .map(|section| section.line_count())
            .sum()
    }

    pub fn has_section(&self, name: &str) -> bool {
        self.sections.iter().any(|section| section.name == name)
    }

    pub fn render(&self) -> String {
        render_sections(self.generated_at_unix_ms, self.policy, &self.sections)
    }

    pub fn bytes(&self) -> Vec<u8> {
        self.render().into_bytes()
    }

    /// `sha256:<hex>` over [`Self::bytes`], i.e. the CAS identity the object is stored under.
    pub fn content_digest(&self) -> String {
        caly_common::digest::sha256_digest(&self.bytes())
    }

    pub fn contains(&self, needle: &str) -> bool {
        self.render().contains(needle)
    }
}

fn render_sections(
    generated_at_unix_ms: i64,
    policy: RedactionPolicy,
    sections: &[BundleSection],
) -> String {
    let mut out = String::new();
    out.push_str("# caly support bundle\n");
    out.push_str(&format!("# generated_at_unix_ms={generated_at_unix_ms}\n"));
    out.push_str(&format!("# redaction={}\n", policy.as_str()));
    for section in sections {
        out.push_str(&format!("== section: {}\n", section.name));
        for line in &section.lines {
            for nested in line.split('\n') {
                out.push_str(nested);
                out.push('\n');
            }
        }
    }
    out
}

/// Collect everything the bundle reports, as a draft.
///
/// Every fact is read from the same injected backend the daemon runs on, so the bundle and
/// `doctor` cannot disagree about the store: both go through
/// [`caly_storage::audit_backend`].
pub fn collect_bundle_draft(handle: &crate::service::EngineHandle) -> Result<BundleDraft, String> {
    let state = handle.snapshot()?;
    let policy = handle.execution_policy();
    let now = policy.clock_start_unix_ms.max(0);
    let mut draft = BundleDraft::new(now);
    let backend = handle.storage();

    collect_header(handle, &mut draft);
    collect_architecture(&state, &mut draft);
    collect_capability(&state, &mut draft);
    collect_journals(&backend, &mut draft)?;
    collect_snapshots(&backend, &mut draft)?;
    collect_recovery(handle, &mut draft)?;
    collect_effect_plan(handle, &mut draft);
    collect_runtime_log(&state, &mut draft);
    collect_resources(&backend, &state, &mut draft)?;
    collect_overloads(&state, &mut draft);
    if let Ok(audit) = caly_storage::audit_backend(
        backend.as_ref(),
        now,
        &crate::service::EngineHandle::store_ctx(),
    ) {
        draft.push_line("storage-audit", audit.summary_line());
        for line in audit.finding_lines() {
            draft.push_line("storage-audit", line);
        }
    } else {
        draft.push_line(
            "storage-audit",
            "unavailable: the audit could not read the store",
        );
    }
    collect_gc_run(handle, &mut draft)?;
    Ok(draft)
}

/// The last collection cycle, as the engine recorded it.
///
/// An absent run is written out as "no cycle has run in this process" rather than omitted: a bundle
/// that is silent about a destructive operation cannot tell a support engineer whether it was refused,
/// never wired, or simply never asked -- the same reason `storage-audit` says `not enumerable` instead
/// of printing nothing.
fn collect_gc_run(
    handle: &crate::service::EngineHandle,
    draft: &mut BundleDraft,
) -> Result<(), String> {
    match handle.last_gc_run()? {
        Some(record) => {
            draft.push_line("storage-gc", record.summary_line());
            for (digest, reason) in &record.failed {
                draft.push_line("storage-gc", format!("failed {digest}: {reason}"));
            }
            for digest in &record.collected {
                draft.push_line("storage-gc", format!("removed {digest}"));
            }
        }
        None => draft.push_line("storage-gc", crate::gc_plan::NO_GC_RUN_YET),
    }
    Ok(())
}

/// Turn a store enumeration into "the records", "it cannot answer", or "abort".
///
/// `Unsupported` becomes `None` — the collector then writes an explicit *not enumerable* line,
/// because "no journals" would read as "nothing was ever applied", which is a different and much
/// more dangerous claim. Any other failure is returned as an error: a diagnostics export must not
/// turn an unreadable store into a confident empty report (the same discipline `§9.2` and
/// `docs/history/ONBOARDING_NOTES.md §4.19` are about).
fn enumeration<T>(
    outcome: Result<Vec<T>, caly_storage::StorageError>,
) -> Result<Option<Vec<T>>, String> {
    match outcome {
        Ok(records) => Ok(Some(records)),
        Err(failure) if matches!(failure.kind, caly_storage::StorageErrorKind::Unsupported) => {
            Ok(None)
        }
        Err(failure) => Err(failure.summary),
    }
}

/// Which identity the header can honestly state, plus the line that says it cannot.
///
/// An empty `instance=` would be an invented value dressed up as a field; when the identity is not
/// knowable the export says so and stops. Split out because that choice is the interesting part of
/// the header and a unit test should be able to reach it without a whole engine.
fn identity_lines(identity: &BundleIdentity, known: bool) -> Vec<String> {
    if !known {
        return vec!["instance identity unavailable: engine state lock was poisoned".to_owned()];
    }
    vec![format!("instance={}", identity.instance_id)]
}

fn collect_header(handle: &crate::service::EngineHandle, draft: &mut BundleDraft) {
    // A poisoned lock is not a reason to leave the header out, but it is a reason to say the
    // header is unknown rather than invent an instance.
    let (identity, identity_known) = match handle.bundle_identity() {
        Ok(identity) => (identity, true),
        Err(_) => (BundleIdentity::default(), false),
    };
    for line in identity_lines(&identity, identity_known) {
        draft.push_line("header", line);
    }
    draft.push_line(
        "header",
        format!(
            "daemon={} version={} protocol={}",
            identity.daemon_name, identity.daemon_version, identity.protocol_version
        ),
    );
    draft.push_line(
        "header",
        format!(
            "caly={} build={}",
            BundleIdentity::caly_version(),
            BundleIdentity::build_profile()
        ),
    );
    let schema = match backend_schema_state(handle) {
        Some(version) => format!("v{version}"),
        None => "unreadable".to_owned(),
    };
    draft.push_line(
        "header",
        format!(
            "storage_schema={} migrations_applied={}",
            schema,
            handle.storage().migrations_applied()
        ),
    );
}

fn backend_schema_state(handle: &crate::service::EngineHandle) -> Option<u32> {
    match handle.storage().schema_state() {
        caly_storage::Observation::Known(version) => Some(version),
        caly_storage::Observation::Unavailable(_) => None,
    }
}

fn collect_architecture(state: &EngineState, draft: &mut BundleDraft) {
    draft.push_line(
        "architecture",
        format!("engine_lifecycle={:?}", state.current_lifecycle()),
    );
    draft.push_line("architecture", format!("generation={}", state.generation));
    draft.push_line("architecture", format!("queue_depth={}", state.queue.len()));
    draft.push_line(
        "architecture",
        format!(
            "jobs_total={} queued={}",
            state.jobs.len(),
            state.queued_commands.len()
        ),
    );
    let mut by_state: BTreeMap<String, usize> = BTreeMap::new();
    for job in state.jobs.values() {
        *by_state
            .entry(format!("{:?}", job.state).to_lowercase())
            .or_default() += 1;
    }
    for (name, count) in by_state {
        draft.push_line("architecture", format!("jobs.{name}={count}"));
    }
    draft.push_line(
        "architecture",
        format!("automation_overrides={}", state.automation_overrides.len()),
    );
    draft.push_line(
        "architecture",
        format!(
            "idempotency entries={} finished_window={} evictions={}",
            state.idempotency.len(),
            state.idempotency.max_finished(),
            state.idempotency.evictions()
        ),
    );
}

/// What the engine had to refuse, and how deep the queue was when it did.
///
/// `OVERLOAD_AND_RETRY_MODEL §7.2` wants backlog length and queue cap on the diagnostics outlet, and
/// `§10 Stage 3` names the support bundle as one of its two consumers. An empty log is stated, not
/// omitted: "no refusals" is evidence, while a missing section reads as "the collector did not run".
fn collect_overloads(state: &EngineState, draft: &mut BundleDraft) {
    draft.push_line(
        "overload",
        format!(
            "queue {}/{} retained_refusals={}",
            state.queue.len(),
            state.queue.capacity(),
            state.overloads.len()
        ),
    );
    for line in state.overload_lines() {
        draft.push_line("overload", line);
    }
    if state.overloads.is_empty() {
        draft.push_line(
            "overload",
            "no overload refusal recorded in this generation (the log holds the last 8)",
        );
    }
}

fn collect_capability(state: &EngineState, draft: &mut BundleDraft) {
    let registry = caly_cap::default_registry_document();
    draft.push_line(
        "capability",
        format!(
            "registry_version={} entries={} (ADR-024: the registry is the source of truth)",
            registry.version,
            registry.capabilities.len()
        ),
    );
    let mut by_state: BTreeMap<String, usize> = BTreeMap::new();
    for entry in &registry.capabilities {
        *by_state.entry(format!("{:?}", entry.state)).or_default() += 1;
    }
    for (name, count) in by_state {
        draft.push_line("capability", format!("registry.{name}={count}"));
    }
    match &state.last_capability_summary {
        Some(summary) => {
            draft.push_line(
                "capability",
                format!(
                    "last-evaluated required={} allowed={} warnings={} blocked={} escalate={}",
                    summary.required_count,
                    summary.allowed_count,
                    summary.warning_count,
                    summary.blocked_count,
                    summary.must_escalate_apply
                ),
            );
            for decision in summary.decisions.iter().take(8) {
                draft.push_line("capability", format!("decision {decision}"));
            }
        }
        None => draft.push_line(
            "capability",
            "no apply has been evaluated in this engine generation",
        ),
    }
}

fn collect_journals(
    backend: &Arc<dyn StorageBackend>,
    draft: &mut BundleDraft,
) -> Result<(), String> {
    let records = enumeration(caly_io::block_on_ready(
        backend.list_apply_journals(&crate::service::EngineHandle::store_ctx()),
    )?)?;
    let Some(mut records) = records else {
        draft.push_line("apply-journals", "not enumerable on this backend");
        return Ok(());
    };
    records.sort_by(|left, right| left.apply_txn_id.0.cmp(&right.apply_txn_id.0));
    let total = records.len();
    for journal in records.into_iter().rev().take(RECENT_JOURNALS) {
        draft.push_line(
            "apply-journals",
            format!(
                "txn={} state={} phase={:?} step={} profile={} artifact={} snapshot_prev={} core={}",
                journal.apply_txn_id.0,
                journal_state_text(journal.state),
                journal.current_phase,
                journal.current_step_index,
                journal.profile_id,
                journal.compiled_artifact_digest,
                journal
                    .previous_snapshot_id
                    .as_ref()
                    .map(|id| id.0.clone())
                    .unwrap_or_else(|| "-".to_owned()),
                journal.core_identity
            ),
        );
        draft.push_line(
            "apply-journals",
            format!(
                "  flags cutover_started={} net_effect_started={} created={} updated={}",
                journal.core_cutover_started,
                journal.net_effect_started,
                journal.created_at_unix_ms,
                journal.updated_at_unix_ms
            ),
        );
    }
    draft.push_line(
        "apply-journals",
        format!("total={total} shown={}", total.min(RECENT_JOURNALS)),
    );
    Ok(())
}

fn journal_state_text(state: caly_storage::ApplyJournalState) -> &'static str {
    match state {
        caly_storage::ApplyJournalState::Pending => "pending",
        caly_storage::ApplyJournalState::Committed => "committed",
        caly_storage::ApplyJournalState::Reverted => "reverted",
        caly_storage::ApplyJournalState::Abandoned => "abandoned",
        caly_storage::ApplyJournalState::RecoveryFailed => "recovery-failed",
    }
}

fn collect_snapshots(
    backend: &Arc<dyn StorageBackend>,
    draft: &mut BundleDraft,
) -> Result<(), String> {
    let listed = enumeration(caly_io::block_on_ready(
        backend.list_snapshots(&crate::service::EngineHandle::store_ctx()),
    )?)?;
    if let Some(mut records) = listed {
        records.sort_by(|left, right| left.id.0.cmp(&right.id.0));
        for snapshot in records.into_iter().rev().take(RECENT_JOURNALS) {
            draft.push_line("snapshots", snapshot_line("snapshot", &snapshot));
        }
    } else {
        draft.push_line("snapshots", "not enumerable on this backend");
    }
    match caly_io::block_on_ready(
        backend.latest_last_known_good(&crate::service::EngineHandle::store_ctx()),
    )? {
        Ok(Some(snapshot)) => {
            draft.push_line("snapshots", snapshot_line("last-known-good", &snapshot))
        }
        Ok(None) => draft.push_line(
            "snapshots",
            "no last-known-good snapshot: nothing has been committed on this store",
        ),
        Err(failure) => draft.push_line(
            "snapshots",
            format!("last-known-good unreadable: {}", failure.summary),
        ),
    }
    Ok(())
}

fn snapshot_line(label: &str, snapshot: &caly_storage::SnapshotRecord) -> String {
    format!(
        "{label} id={} rev={}#{} profile={} artifact={} semantic={} core={} lkg={} created={} validation={}",
        snapshot.id.0,
        snapshot.revision_id.0,
        snapshot.revision_number.0,
        snapshot.profile_id,
        snapshot.compiled_artifact_digest,
        snapshot.semantic_digest,
        snapshot.core_identity,
        snapshot.is_last_known_good,
        snapshot.created_at_unix_ms,
        snapshot.validation_summary
    )
}

fn collect_recovery(
    handle: &crate::service::EngineHandle,
    draft: &mut BundleDraft,
) -> Result<(), String> {
    let report = handle.scan_recovery_state()?;
    draft.push_line(
        "recovery",
        format!(
            "unresolved_apply={} pending_os={} last_known_good={}",
            report.unresolved_apply_journals.len(),
            report.pending_os_journals.len(),
            report
                .latest_last_known_good
                .as_ref()
                .map(|id| id.0.clone())
                .unwrap_or_else(|| "-".to_owned())
        ),
    );
    if report.decisions.is_empty() {
        draft.push_line("recovery", "no recovery decisions outstanding");
    }
    for decision in &report.decisions {
        draft.push_line("recovery", format!("decision {decision:?}"));
    }
    for journal in &report.unresolved_apply_journals {
        draft.push_line(
            "recovery",
            format!(
                "unresolved txn={} state={} step={}",
                journal.apply_txn_id.0,
                journal_state_text(journal.state),
                journal.current_step_index
            ),
        );
    }
    Ok(())
}

/// The apply report, which `RFC-0010 §12.2` asks for in redacted form.
fn collect_effect_plan(handle: &crate::service::EngineHandle, draft: &mut BundleDraft) {
    let plan = match handle.last_effect_plan() {
        Ok(Some(plan)) => plan,
        Ok(None) => {
            draft.push_line(
                "effect-plan",
                "no effect plan has been executed in this generation",
            );
            return;
        }
        Err(message) => {
            draft.push_line("effect-plan", format!("unavailable: {message}"));
            return;
        }
    };
    draft.push_line(
        "effect-plan",
        format!(
            "id={} steps={} compensations={}",
            plan.id.0,
            plan.steps.len(),
            plan.compensations.len()
        ),
    );
    for (index, step) in plan.steps.iter().enumerate() {
        draft.push_line(
            "effect-plan",
            format!("step {index} {}", crate::executor::step_kind_name(step)),
        );
    }
    for (index, step) in plan.compensations.iter().enumerate() {
        draft.push_line(
            "effect-plan",
            format!(
                "compensation {index} {}",
                crate::executor::step_kind_name(step)
            ),
        );
    }
}

fn collect_runtime_log(state: &EngineState, draft: &mut BundleDraft) {
    let ids: Vec<u64> = state.jobs.keys().copied().collect();
    let start = ids.len().saturating_sub(LOG_TAIL_JOBS);
    for job_id in ids[start..].iter() {
        let Some(job) = state.jobs.get(job_id) else {
            continue;
        };
        let events: Vec<String> = job.events.iter().map(render_job_event).collect();
        let skip = events.len().saturating_sub(LOG_TAIL_LINES_PER_JOB);
        for line in &events[skip..] {
            draft.push_line("runtime-log", format!("job {job_id} {line}"));
        }
    }
    if draft
        .sections
        .iter()
        .all(|section| section.name != "runtime-log")
    {
        draft.push_line("runtime-log", "no job history in this generation");
    }
}

/// One job event as the text an operator reads.
///
/// Public because the follow **query** needs the same rendering the stream and the support bundle
/// already use: three spellings of the same event is how two views of one job start to disagree.
pub fn render_job_event(event: &crate::job::JobEvent) -> String {
    use crate::job::JobEvent;
    match event {
        JobEvent::Stage { stage, pct } => match pct {
            Some(pct) => format!("[stage {pct}%] {stage}"),
            None => format!("[stage] {stage}"),
        },
        JobEvent::Log { level, message } => format!("[log:{level}] {message}"),
        JobEvent::Warning { message } => format!("[warn] {message}"),
        JobEvent::Done { outcome } => format!("[done] {outcome:?}"),
        JobEvent::Failed { error } => format!("[failed {}] {}", error.code, error.summary),
    }
}

fn collect_resources(
    backend: &Arc<dyn StorageBackend>,
    state: &EngineState,
    draft: &mut BundleDraft,
) -> Result<(), String> {
    let objects = match caly_io::block_on_ready(
        backend.list_objects(&crate::service::EngineHandle::store_ctx()),
    )? {
        Ok(objects) => objects,
        Err(failure) => return Err(failure.summary),
    };
    let bytes: u64 = objects
        .iter()
        .map(|object| object.size_bytes.unwrap_or(0))
        .sum();
    let by_kind: BTreeMap<String, usize> =
        objects.iter().fold(BTreeMap::new(), |mut acc, object| {
            *acc.entry(format!("{:?}", object.kind)).or_default() += 1;
            acc
        });
    draft.push_line(
        "resources",
        format!("objects={} bytes={bytes}", objects.len()),
    );
    for (kind, count) in by_kind {
        draft.push_line("resources", format!("objects.{kind}={count}"));
    }
    draft.push_line(
        "resources",
        format!(
            "event_log retained={} next_seq={} capacity={}",
            state.events.events.len(),
            state.events.next_seq,
            state.events.max_events
        ),
    );
    let pending_os = match caly_io::block_on_ready(
        backend.list_pending(&crate::service::EngineHandle::store_ctx()),
    )? {
        Ok(records) => records.len(),
        Err(failure) => return Err(failure.summary),
    };
    draft.push_line("resources", format!("pending_os_journals={pending_os}"));
    Ok(())
}

/// Run the `DiagnosticsBundle` command: collect, mask once, store, and report the handle.
pub fn run_bundle_job(
    handle: &crate::service::EngineHandle,
    queued: &crate::state::QueuedCommand,
) -> Result<crate::worker::WorkerCycleResult, String> {
    let draft = collect_bundle_draft(handle)?;
    let redactor = handle.bundle_redactor()?;
    let bundle = draft.finish(&redactor);
    let bytes = bundle.bytes();
    let digest = caly_common::digest::sha256_digest(&bytes);
    let now = handle.execution_policy().clock_start_unix_ms.max(0);

    for section in &bundle.sections {
        handle.append_job_event(
            queued.job_id,
            crate::job::JobEvent::Stage {
                stage: format!(
                    "bundle.section {} lines={}",
                    section.name,
                    section.line_count()
                ),
                pct: None,
            },
        )?;
    }

    let intent = caly_storage::CasWriteIntent {
        object: caly_storage::CasObjectRef {
            digest: caly_storage::ObjectDigest(digest.clone()),
            kind: caly_storage::ObjectKind::SupportBundle,
            size_bytes: Some(bytes.len() as u64),
            content_type: Some(BUNDLE_CONTENT_TYPE.to_owned()),
            content_sha256: Some(digest.clone()),
            stored_at_unix_ms: Some(now),
        },
        source_label: format!("support-bundle:job-{}", queued.job_id.0),
        payload: bytes,
        stored_at_unix_ms: now,
    };
    let stored = handle.put_object(intent)?;

    handle.append_job_event(
        queued.job_id,
        crate::job::JobEvent::Log {
            level: "info".to_owned(),
            message: format!(
                "support bundle written: object={} lines={} bytes={} redaction={}",
                stored.digest.0,
                bundle.line_count(),
                stored.size_bytes.unwrap_or(0),
                bundle.policy.as_str()
            ),
        },
    )?;
    handle.append_job_event(
        queued.job_id,
        crate::job::JobEvent::Stage {
            stage: "bundle.committed".to_owned(),
            pct: Some(100),
        },
    )?;
    handle.mark_finished(queued, crate::job::JobOutcome::Succeeded)?;

    Ok(crate::worker::WorkerCycleResult {
        job_id: queued.job_id.0,
        outcome: crate::job::JobOutcome::Succeeded,
        impact: caly_api::EstimatedImpact::ReadOnly,
    })
}

/// Render a window of job events, oldest first.
pub fn render_job_events(events: &[crate::job::JobEvent]) -> Vec<String> {
    events.iter().map(render_job_event).collect()
}

#[cfg(test)]
mod tests {
    use super::*;
    use caly_common::redact::REDACTED;

    fn failure(kind: caly_storage::StorageErrorKind, summary: &str) -> caly_storage::StorageError {
        caly_storage::StorageError::new(kind, summary.to_owned())
    }

    #[test]
    fn an_unsupported_enumeration_becomes_a_note_not_an_error() {
        let outcome: Result<Vec<u8>, _> = Err(failure(
            caly_storage::StorageErrorKind::Unsupported,
            "this backend cannot enumerate apply journals",
        ));
        assert_eq!(
            enumeration(outcome).expect("unsupported is not an error"),
            None
        );
    }

    #[test]
    fn a_real_store_failure_aborts_the_export() {
        let outcome: Result<Vec<u8>, _> =
            Err(failure(caly_storage::StorageErrorKind::Busy, "disk busy"));
        assert_eq!(enumeration(outcome), Err("disk busy".to_owned()));
    }

    #[test]
    fn records_pass_through_including_an_empty_list() {
        assert_eq!(
            enumeration(Ok(Vec::<u8>::new())).expect("ok"),
            Some(Vec::new())
        );
        assert_eq!(enumeration(Ok(vec![1u8, 2])).expect("ok"), Some(vec![1, 2]));
    }

    /// The section list is the contract the tests and the docs both quote, so an exporter that
    /// quietly drops one has to be caught here rather than by a reader of the bundle.
    #[test]
    fn every_declared_section_is_rendered() {
        let mut draft = BundleDraft::new(10);
        for name in BUNDLE_SECTIONS {
            draft.push_line(name, "x");
        }
        let bundle = draft.finish(&Redactor::default());
        for name in BUNDLE_SECTIONS {
            assert!(bundle.has_section(name), "missing {name}");
            assert_eq!(bundle.lines_of(name), vec!["x"], "{name}");
        }
        assert_eq!(bundle.line_count(), BUNDLE_SECTIONS.len());
    }

    #[test]
    fn the_bundle_escalates_to_strict_even_when_the_process_did_not() {
        let input = "home /home/mika/caly node d1ae09f6-1e0e-4f77-9a51-7a3b1f0e2b6c";
        let process = Redactor::default();
        assert_eq!(
            process.redact(input),
            input,
            "the default policy leaves §4.1 items alone"
        );

        let mut draft = BundleDraft::new(1);
        draft.push_line("header", input);
        let bundle = draft.finish(&process.escalate_to(BUNDLE_POLICY));
        assert_eq!(bundle.policy, RedactionPolicy::Strict);
        assert!(!bundle.contains("/home/mika"), "{}", bundle.render());
        assert!(!bundle.contains("d1ae09f6"), "{}", bundle.render());
    }

    #[test]
    fn the_draft_shows_what_the_bundle_would_have_leaked() {
        // Falsification for `RFC-0010 §14.3`: without this, "the bundle contains no secret" could
        // pass simply because the collector produced nothing.
        let mut draft = BundleDraft::new(1);
        draft.push_line("runtime-log", "job 1 fetch token=SECRETVALUE123 ok");
        assert!(draft.render().contains("SECRETVALUE123"));

        let bundle = draft.finish(&Redactor::default());
        assert!(!bundle.contains("SECRETVALUE123"), "{}", bundle.render());
        assert!(bundle.contains(REDACTED), "{}", bundle.render());
        assert!(bundle.contains("job 1 fetch"), "{}", bundle.render());
    }

    /// The header must not dress an unreadable value up as a field: `instance=` with nothing after
    /// it reads exactly like "this process has no id", which is a claim, not a gap.
    #[test]
    fn an_unknown_identity_is_reported_as_a_gap_not_an_empty_field() {
        let known = identity_lines(
            &BundleIdentity::new("inst-1", "calyd", "0.1.0", "v1.0"),
            true,
        );
        assert_eq!(known, vec!["instance=inst-1".to_owned()]);

        let unknown = identity_lines(&BundleIdentity::default(), false);
        assert_eq!(
            unknown,
            vec!["instance identity unavailable: engine state lock was poisoned".to_owned()]
        );
        // No empty field, in either direction.
        assert!(unknown.iter().all(|line| !line.trim_end().ends_with('=')));
        assert!(known.iter().all(|line| !line.contains("unavailable")));
    }

    #[test]
    fn the_content_digest_is_the_stored_bytes_digest() {
        let mut draft = BundleDraft::new(7);
        draft.push_line("header", "instance=i1");
        let bundle = draft.finish(&Redactor::default());
        let digest = caly_common::digest::sha256_digest(&bundle.bytes());
        assert_eq!(bundle.content_digest(), digest);
        assert!(digest.starts_with("sha256:"));
        assert!(bundle.render().starts_with("# caly support bundle\n"));
    }
}
