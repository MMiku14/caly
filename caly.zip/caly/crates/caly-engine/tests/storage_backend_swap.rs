//! Storage backend substitutability.
//!
//! `docs/STORAGE_RECOVERY_EXECUTION_PLAN.md` calls storage the "transaction substrate", and
//! `caly-storage` defines five store traits to keep that substrate replaceable. Until
//! `EngineHandle` stopped holding a concrete `InMemoryStorage`, none of it was usable: there was
//! nowhere to put a different backend. These tests are the proof of the seam — a second backend
//! implementation, driving the *same* centerline assertions, plus the failure path a real
//! backend has and the in-memory one cannot (`Busy`).

use std::sync::atomic::{AtomicUsize, Ordering};
use std::sync::{Arc, Mutex};

use caly_api::{ApplyRequest, ErrorCode, JobId, ProfileId};
use caly_common::{Actor, RequestContext, TraceId};
use caly_engine::{
    command::{Command, CommandId, CommandKind},
    EngineHandle, JobOutcome, WorkerPolicy,
};
use caly_io::IoContext;
use caly_storage::{
    ApplyJournalRecord, ApplyJournalStore, ApplyTxnId, BoxFuture, CasObjectRef, CasWriteIntent,
    InMemoryStorage, JobLogStore, JournalRecord, JournalRecordId, JournalStore,
    MaterializationRequest, ObjectStore, RevisionId, RevisionRecord, RevisionStore, SnapshotRecord,
    SnapshotRecordId, SnapshotStore, StorageBackend, StorageError, StorageErrorKind,
};

/// A real backend wrapper that can refuse writes, the way a busy disk or a locked database does.
#[derive(Clone, Default)]
struct FlakyStorage {
    inner: InMemoryStorage,
    /// Number of remaining refusals applied to `ObjectStore::put`.
    put_refusals: Arc<AtomicUsize>,
    /// Number of remaining refusals applied to `SnapshotStore::put_snapshot`.
    snapshot_refusals: Arc<AtomicUsize>,
    observed: Arc<Mutex<Vec<String>>>,
}

impl FlakyStorage {
    fn new() -> Self {
        Self::default()
    }

    fn arm_put(&self, times: usize) {
        self.put_refusals.store(times, Ordering::SeqCst);
    }

    fn arm_snapshot(&self, times: usize) {
        self.snapshot_refusals.store(times, Ordering::SeqCst);
    }

    fn observed(&self) -> Vec<String> {
        self.observed
            .lock()
            .map(|guard| guard.clone())
            .unwrap_or_default()
    }

    fn note(&self, what: &str) {
        if let Ok(mut guard) = self.observed.lock() {
            guard.push(what.to_owned());
        }
    }

    fn take(refusals: &AtomicUsize) -> bool {
        refusals
            .fetch_update(Ordering::SeqCst, Ordering::SeqCst, |value| {
                if value == 0 {
                    None
                } else {
                    Some(value - 1)
                }
            })
            .is_ok()
    }
}

// Explicit, because `StorageBackend` must stay overridable per backend: a blanket impl would
// force every backend onto the "I know nothing" defaults, including the durable one.
impl StorageBackend for FlakyStorage {}

impl JobLogStore for FlakyStorage {
    fn put_job_log<'a>(
        &'a self,
        record: caly_storage::job_log::JobLogRecord,
        ctx: &'a IoContext,
    ) -> BoxFuture<'a, Result<(), StorageError>> {
        self.inner.put_job_log(record, ctx)
    }
    fn get_job_log<'a>(
        &'a self,
        job_id: &'a str,
        ctx: &'a IoContext,
    ) -> BoxFuture<'a, Result<Option<caly_storage::job_log::JobLogRecord>, StorageError>> {
        self.inner.get_job_log(job_id, ctx)
    }
    fn list_job_logs<'a>(
        &'a self,
        ctx: &'a IoContext,
    ) -> BoxFuture<'a, Result<Vec<caly_storage::job_log::JobLogRecord>, StorageError>> {
        self.inner.list_job_logs(ctx)
    }
}

impl ObjectStore for FlakyStorage {
    fn put<'a>(
        &'a self,
        intent: CasWriteIntent,
        ctx: &'a IoContext,
    ) -> BoxFuture<'a, Result<CasObjectRef, StorageError>> {
        self.note("put");
        if Self::take(&self.put_refusals) {
            Box::pin(async move {
                Err(StorageError::new(
                    StorageErrorKind::Busy,
                    "object store is busy (injected)",
                ))
            })
        } else {
            self.inner.put(intent, ctx)
        }
    }

    fn get<'a>(
        &'a self,
        digest: &'a str,
        ctx: &'a IoContext,
    ) -> BoxFuture<'a, Result<Option<CasObjectRef>, StorageError>> {
        self.inner.get(digest, ctx)
    }

    fn materialize<'a>(
        &'a self,
        request: MaterializationRequest,
        ctx: &'a IoContext,
    ) -> BoxFuture<'a, Result<(), StorageError>> {
        self.note("materialize");
        self.inner.materialize(request, ctx)
    }

    fn list_objects<'a>(
        &'a self,
        ctx: &'a IoContext,
    ) -> BoxFuture<'a, Result<Vec<CasObjectRef>, StorageError>> {
        self.note("list_objects");
        self.inner.list_objects(ctx)
    }

    fn delete<'a>(
        &'a self,
        digest: &'a str,
        ctx: &'a IoContext,
    ) -> BoxFuture<'a, Result<bool, StorageError>> {
        self.note("delete");
        self.inner.delete(digest, ctx)
    }
}

impl RevisionStore for FlakyStorage {
    fn put_revision<'a>(
        &'a self,
        record: RevisionRecord,
        ctx: &'a IoContext,
    ) -> BoxFuture<'a, Result<(), StorageError>> {
        self.note("put_revision");
        self.inner.put_revision(record, ctx)
    }

    fn get_revision<'a>(
        &'a self,
        revision_id: &'a RevisionId,
        ctx: &'a IoContext,
    ) -> BoxFuture<'a, Result<Option<RevisionRecord>, StorageError>> {
        self.inner.get_revision(revision_id, ctx)
    }
}

impl SnapshotStore for FlakyStorage {
    fn put_snapshot<'a>(
        &'a self,
        record: SnapshotRecord,
        ctx: &'a IoContext,
    ) -> BoxFuture<'a, Result<(), StorageError>> {
        self.note("put_snapshot");
        if Self::take(&self.snapshot_refusals) {
            Box::pin(async move {
                Err(StorageError::new(
                    StorageErrorKind::Busy,
                    "snapshot store is busy (injected)",
                ))
            })
        } else {
            self.inner.put_snapshot(record, ctx)
        }
    }

    fn get_snapshot<'a>(
        &'a self,
        snapshot_id: &'a SnapshotRecordId,
        ctx: &'a IoContext,
    ) -> BoxFuture<'a, Result<Option<SnapshotRecord>, StorageError>> {
        self.inner.get_snapshot(snapshot_id, ctx)
    }

    fn latest_last_known_good<'a>(
        &'a self,
        ctx: &'a IoContext,
    ) -> BoxFuture<'a, Result<Option<SnapshotRecord>, StorageError>> {
        self.inner.latest_last_known_good(ctx)
    }
}

impl JournalStore for FlakyStorage {
    fn put_journal<'a>(
        &'a self,
        record: JournalRecord,
        ctx: &'a IoContext,
    ) -> BoxFuture<'a, Result<(), StorageError>> {
        self.inner.put_journal(record, ctx)
    }

    fn get_journal<'a>(
        &'a self,
        journal_id: &'a JournalRecordId,
        ctx: &'a IoContext,
    ) -> BoxFuture<'a, Result<Option<JournalRecord>, StorageError>> {
        self.inner.get_journal(journal_id, ctx)
    }

    fn list_pending<'a>(
        &'a self,
        ctx: &'a IoContext,
    ) -> BoxFuture<'a, Result<Vec<JournalRecord>, StorageError>> {
        self.inner.list_pending(ctx)
    }
}

impl ApplyJournalStore for FlakyStorage {
    fn put_apply_journal<'a>(
        &'a self,
        record: ApplyJournalRecord,
        ctx: &'a IoContext,
    ) -> BoxFuture<'a, Result<(), StorageError>> {
        self.note("put_apply_journal");
        self.inner.put_apply_journal(record, ctx)
    }

    fn get_apply_journal<'a>(
        &'a self,
        apply_txn_id: &'a ApplyTxnId,
        ctx: &'a IoContext,
    ) -> BoxFuture<'a, Result<Option<ApplyJournalRecord>, StorageError>> {
        self.inner.get_apply_journal(apply_txn_id, ctx)
    }

    fn list_pending_apply<'a>(
        &'a self,
        ctx: &'a IoContext,
    ) -> BoxFuture<'a, Result<Vec<ApplyJournalRecord>, StorageError>> {
        self.inner.list_pending_apply(ctx)
    }

    fn list_unresolved_apply<'a>(
        &'a self,
        ctx: &'a IoContext,
    ) -> BoxFuture<'a, Result<Vec<ApplyJournalRecord>, StorageError>> {
        self.inner.list_unresolved_apply(ctx)
    }
}

fn ctx() -> caly_io::IoContext {
    caly_io::RequestContext::new(
        caly_io::TraceId::new("storage-backend-swap"),
        caly_io::Actor::System,
    )
}

fn apply_command(profile_id: &str) -> Command {
    Command {
        id: CommandId(format!("cmd-{profile_id}")),
        request_id: None,
        actor: Actor::Cli,
        context: RequestContext::new(TraceId::new("trace-swap"), Actor::Cli),
        timeout_ms: None,
        idempotency_key: None,
        kind: CommandKind::ProfileApply(ApplyRequest {
            profile_id: ProfileId(profile_id.to_owned()),
            dry_run: false,
            strict: false,
        }),
    }
}

fn drain(handle: &EngineHandle) -> caly_engine::WorkerCycleResult {
    handle
        .submit(apply_command("demo-tun-profile"))
        .expect("submit");
    handle
        .drain_with_policy(WorkerPolicy::bounded(1))
        .expect("drain")
        .results
        .into_iter()
        .next()
        .expect("one cycle")
}

/// The centerline must not be in-memory-specific: the same apply on a different backend yields
/// the same committed snapshot.
#[test]
fn a_swapped_backend_runs_the_same_apply_to_completion() {
    let backend = Arc::new(FlakyStorage::new());
    let handle = EngineHandle::with_backend(caly_engine::EngineState::new(), backend.clone());

    let result = drain(&handle);
    assert_eq!(result.outcome, JobOutcome::Succeeded);

    let lkg = handle
        .latest_last_known_good_snapshot()
        .expect("lkg read")
        .expect("the swapped backend must hold a committed snapshot");
    assert_eq!(lkg.profile_id, "demo-tun-profile");
    assert!(lkg.is_last_known_good);
    let report = handle.scan_recovery_state().expect("scan");
    assert!(
        report.unresolved_apply_journals.is_empty() && report.decisions.is_empty(),
        "a completed apply must leave nothing unresolved: {:?}",
        report.decisions
    );

    let observed = backend.observed();
    for expected in [
        "put",
        "materialize",
        "put_apply_journal",
        "put_revision",
        "put_snapshot",
    ] {
        assert!(
            observed.iter().any(|call| call == expected),
            "the engine must reach the injected backend for {expected}, saw {observed:?}"
        );
    }
}

/// `APPLY_EXECUTION_CENTERLINE.md §10` requires "storage busy" to be a distinct public failure.
#[test]
fn a_busy_object_store_fails_the_job_without_inventing_state() {
    let backend = Arc::new(FlakyStorage::new());
    backend.arm_put(1);
    let handle = EngineHandle::with_backend(caly_engine::EngineState::new(), backend.clone());

    let result = drain(&handle);
    assert_eq!(result.outcome, JobOutcome::Failed);

    let events = handle
        .follow_job(JobId(result.job_id))
        .expect("follow")
        .job
        .expect("job")
        .events;
    let failure = events
        .iter()
        .find_map(|event| match event {
            caly_engine::JobEvent::Failed { error } => Some(error.clone()),
            _ => None,
        })
        .expect("a failed apply must surface a public error");
    assert_eq!(failure.code, ErrorCode::Storage);
    assert!(failure.retryable, "a busy store is retryable");
    assert!(
        failure.summary.contains("persistence begin failed"),
        "{}",
        failure.summary
    );

    // Nothing may have been published: no snapshot, no pending journal, and no effect executed.
    assert!(handle
        .latest_last_known_good_snapshot()
        .expect("lkg read")
        .is_none());
    assert!(!backend.observed().iter().any(|call| call == "put_snapshot"));
    assert_eq!(
        backend
            .observed()
            .iter()
            .filter(|call| *call == "put_apply_journal")
            .count(),
        0,
        "the journal must not be written when the object store refused the artifact"
    );
}

/// The dangerous case: the effects already ran, then the snapshot commit failed. The engine must
/// record that recovery is unresolved instead of losing the transaction.
#[test]
fn a_busy_snapshot_store_leaves_a_recovery_trace_not_a_fake_success() {
    let backend = Arc::new(FlakyStorage::new());
    backend.arm_snapshot(1);
    let handle = EngineHandle::with_backend(caly_engine::EngineState::new(), backend.clone());

    let result = drain(&handle);
    assert_eq!(result.outcome, JobOutcome::Failed);

    let events = handle
        .follow_job(JobId(result.job_id))
        .expect("follow")
        .job
        .expect("job")
        .events;
    assert!(events
        .iter()
        .any(|event| matches!(event, caly_engine::JobEvent::Warning { message } if message.contains("recovery pending"))),
        "the job must report that recovery is pending: {events:?}"
    );

    // The journal must be readable and in a non-committed state, so a boot scan can act on it.
    let pending = caly_engine::recovery::run_ready(handle.storage().list_pending_apply(&ctx()))
        .expect("immediate read")
        .expect("no storage error");
    assert!(
        pending.is_empty(),
        "a recovery-failed txn is no longer merely pending: {pending:?}"
    );

    let unresolved =
        caly_engine::recovery::run_ready(handle.storage().list_unresolved_apply(&ctx()))
            .expect("immediate read")
            .expect("no storage error");
    assert_eq!(
        unresolved.len(),
        1,
        "an unsettled apply must remain visible to the recovery scanner"
    );
    assert_eq!(
        unresolved[0].state,
        caly_storage::ApplyJournalState::RecoveryFailed
    );

    // And the scan must keep reporting it instead of treating the run as clean.
    let report = handle.scan_recovery_state().expect("scan");
    assert_eq!(report.unresolved_apply_journals.len(), 1);
    assert!(
        matches!(
            report.decisions.as_slice(),
            [caly_storage::RecoveryDecision::EnterFailedState { .. }]
        ),
        "{:?}",
        report.decisions
    );
    assert!(handle
        .latest_last_known_good_snapshot()
        .expect("lkg read")
        .is_none());
}
