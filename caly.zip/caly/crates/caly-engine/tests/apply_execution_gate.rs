//! Centerline execution gate.
//!
//! These tests are the `ADR-022` "deterministic simulation is a PR gate" requirement
//! applied to the apply centerline: every effect step index is a crash point, and the
//! recovery/last-known-good invariants must hold at each one.
//!
//! Before this file the workspace had **zero** tests, so every "已验证" claim in
//! `docs/IMPLEMENTATION_STATUS.md` was backed only by `cargo check`.

use caly_api::{ApplyRequest, JobId, ProfileId, RollbackRequest};
use caly_common::{Actor, RequestContext, TraceId};
use caly_engine::{
    command::{Command, CommandId, CommandKind},
    executor::{phase_of, phase_rank, validate_effect_plan, ExecutionPolicy},
    plan_apply_request, EngineHandle, RunLimits, WorkerPolicy,
};
use caly_storage::ApplyJournalState;

fn apply_command(profile_id: &str, tag: &str) -> Command {
    Command {
        id: CommandId(format!("cmd-{tag}-{profile_id}")),
        request_id: None,
        actor: Actor::Cli,
        context: RequestContext::new(TraceId::new(format!("trace-{tag}")), Actor::Cli),
        timeout_ms: None,
        idempotency_key: None,
        kind: CommandKind::ProfileApply(ApplyRequest {
            profile_id: ProfileId(profile_id.to_owned()),
            dry_run: false,
            strict: false,
        }),
    }
}

fn rollback_command(snapshot_id: Option<String>) -> Command {
    Command {
        id: CommandId("cmd-rollback".to_owned()),
        request_id: None,
        actor: Actor::Cli,
        context: RequestContext::new(TraceId::new("trace-rollback"), Actor::Cli),
        timeout_ms: None,
        idempotency_key: None,
        kind: CommandKind::ProfileRollback(RollbackRequest { snapshot_id }),
    }
}

fn stage_events(handle: &EngineHandle, job_id: JobId) -> Vec<String> {
    handle
        .follow_job(job_id)
        .expect("job follow")
        .job
        .map(|job| {
            job.events
                .iter()
                .filter_map(|event| match event {
                    caly_engine::JobEvent::Stage { stage, .. } => Some(stage.clone()),
                    _ => None,
                })
                .collect()
        })
        .unwrap_or_default()
}

fn log_events(handle: &EngineHandle, job_id: JobId) -> Vec<String> {
    handle
        .follow_job(job_id)
        .expect("job follow")
        .job
        .map(|job| {
            job.events
                .iter()
                .filter_map(|event| match event {
                    caly_engine::JobEvent::Log { message, .. } => Some(message.clone()),
                    _ => None,
                })
                .collect()
        })
        .unwrap_or_default()
}

fn run_one(handle: &EngineHandle, command: Command) -> caly_engine::WorkerCycleResult {
    let accepted = handle.submit(command).expect("submit accepted");
    let report = handle
        .drain_with_policy(WorkerPolicy::bounded(1))
        .expect("worker drain");
    assert_eq!(report.cycles, 1, "exactly one cycle must run");
    let result = report.results.into_iter().next().expect("one cycle result");
    assert_eq!(result.job_id, accepted.accepted.job_id.0);
    result
}

/// The adapters' real plans must satisfy the documented phase ordering, otherwise the
/// executor would reject them and apply could never run.
#[test]
fn centerline_plans_satisfy_the_phase_ordering_gate() {
    for profile_id in [
        "demo-profile",
        "demo-global-profile",
        "demo-singbox-profile",
        "demo-tun-strict-profile",
    ] {
        let workflow = plan_apply_request(ApplyRequest {
            profile_id: ProfileId(profile_id.to_owned()),
            dry_run: true,
            strict: false,
        })
        .unwrap_or_else(|error| panic!("plan {profile_id}: {error}"));

        let plan = workflow
            .effect_plan
            .as_ref()
            .unwrap_or_else(|| panic!("{profile_id} must produce a typed effect plan"));

        validate_effect_plan(plan, &ExecutionPolicy::default())
            .unwrap_or_else(|reason| panic!("{profile_id} plan rejected: {reason}"));

        let ranks: Vec<u8> = plan
            .steps
            .iter()
            .map(|step| phase_rank(phase_of(step)))
            .collect();
        assert!(
            ranks.windows(2).all(|pair| pair[0] <= pair[1]),
            "{profile_id} phase ranks must be non-decreasing, got {ranks:?}"
        );
        // A plan that commits without ever probing would silently defeat the verify gate.
        let probe_at = plan
            .steps
            .iter()
            .position(|step| matches!(step, caly_plan::EffectStep::Probe { .. }));
        let commit_at = plan
            .steps
            .iter()
            .position(|step| matches!(step, caly_plan::EffectStep::MarkSnapshot { .. }));
        assert!(
            probe_at < commit_at,
            "{profile_id} must probe before marking a snapshot (probe={probe_at:?} commit={commit_at:?})"
        );
    }
}

#[test]
fn apply_command_runs_effect_execution_and_commits_a_snapshot() {
    let handle = EngineHandle::default();
    let result = run_one(&handle, apply_command("demo-tun-profile", "happy"));

    assert_eq!(
        result.outcome,
        caly_engine::JobOutcome::Succeeded,
        "happy path must succeed, stages: {:?}",
        stage_events(&handle, JobId(result.job_id))
    );

    let stages = stage_events(&handle, JobId(result.job_id));
    for expected in [
        "effects.prepare.started",
        "effects.cutover.started",
        "effects.verify.started",
        "snapshot.committed",
    ] {
        assert!(
            stages.iter().any(|stage| stage.starts_with(expected)),
            "job follow must report {expected}, got {stages:?}"
        );
    }
    assert!(
        stages
            .iter()
            .position(|stage| stage.starts_with("effects.prepare.started"))
            .expect("prepare stage")
            < stages
                .iter()
                .position(|stage| stage.starts_with("effects.cutover.started"))
                .expect("cutover stage"),
        "prepare must be reported before cutover: {stages:?}"
    );

    // Persistence side: the transaction is committed and no pending journal is left behind.
    let lkg = handle
        .latest_last_known_good_snapshot()
        .expect("lkg read")
        .expect("a last-known-good snapshot must exist after a successful apply");
    assert_eq!(lkg.profile_id, "demo-tun-profile");
    assert!(lkg.is_last_known_good);
    let report = handle.scan_recovery_state().expect("recovery scan");
    assert!(
        report.unresolved_apply_journals.is_empty(),
        "committed txn must not stay pending: {:?}",
        report.unresolved_apply_journals
    );
    assert!(report.decisions.is_empty());

    // Effect execution really touched the (simulated) runtime, not just the log strings.
    let world = handle.effect_runtime().snapshot();
    assert_eq!(world.materialized.len(), 1, "{world:?}");
    assert!(world.running_core.is_some(), "spawn-core must run a core");
    assert!(
        world.net_txn.is_some(),
        "tun profile must apply net effects"
    );
    assert!(
        world.log.iter().any(|line| line.starts_with("cas.write")),
        "{:?}",
        world.log
    );
    assert!(
        log_events(&handle, JobId(result.job_id))
            .iter()
            .any(|line| line.contains("net-apply")),
        "effect steps must be reported typed, not only counted"
    );
}

/// `ADR-022` item 3: "可在任意 `EffectStep` 后触发崩溃", and
/// `STORAGE_RECOVERY_EXECUTION_PLAN.md §7`: a failed deploy must never remove or
/// overwrite the previous last-known-good snapshot.
#[test]
fn crash_after_any_effect_step_never_pollutes_last_known_good() {
    let workflow = plan_apply_request(ApplyRequest {
        profile_id: ProfileId("demo-tun-profile".to_owned()),
        dry_run: true,
        strict: false,
    })
    .expect("baseline plan");
    let step_count = workflow
        .effect_plan
        .as_ref()
        .expect("effect plan")
        .steps
        .len();
    assert!(
        step_count >= 5,
        "expected a non-trivial plan to make the matrix meaningful, got {step_count}"
    );

    let handle = EngineHandle::default();
    let established = run_one(&handle, apply_command("demo-tun-profile", "establish"));
    assert_eq!(established.outcome, caly_engine::JobOutcome::Succeeded);
    let baseline_lkg = handle
        .latest_last_known_good_snapshot()
        .expect("lkg read")
        .expect("baseline lkg")
        .id
        .0
        .clone();

    for cut in 0..step_count {
        let crashed_profile = format!("demo-tun-crash-{cut}-profile");
        let crash_workflow = plan_apply_request(ApplyRequest {
            profile_id: ProfileId(crashed_profile.clone()),
            dry_run: true,
            strict: false,
        })
        .expect("crash profile plan");
        let crash_plan = crash_workflow
            .effect_plan
            .as_ref()
            .expect("crash effect plan");

        let handle_for_cut = EngineHandle::default();
        let seed = run_one(
            &handle_for_cut,
            apply_command("demo-tun-profile", "seed-before-crash"),
        );
        assert_eq!(seed.outcome, caly_engine::JobOutcome::Succeeded);
        let lkg_before = handle_for_cut
            .latest_last_known_good_snapshot()
            .expect("lkg read")
            .expect("lkg present")
            .id
            .0
            .clone();

        handle_for_cut
            .set_execution_policy(ExecutionPolicy {
                fail_after_step: Some(cut),
                ..ExecutionPolicy::default()
            })
            .expect("policy set");

        let crashed = run_one(&handle_for_cut, apply_command(&crashed_profile, "crash"));

        assert_eq!(
            crashed.outcome,
            caly_engine::JobOutcome::Failed,
            "crash at step {cut} must fail the job"
        );

        // Invariant 1: the previously good snapshot survives untouched.
        let lkg_after = handle_for_cut
            .latest_last_known_good_snapshot()
            .expect("lkg read")
            .expect("lkg survives")
            .id
            .0
            .clone();
        assert_eq!(
            lkg_after, lkg_before,
            "crash at step {cut} must not replace the last-known-good snapshot"
        );
        assert_eq!(lkg_after, baseline_lkg);

        // Invariant 2: the crashed transaction is settled, never left as a success.
        let journal: caly_storage::ApplyJournalRecord = {
            let store = handle_for_cut.storage();
            let txn_id = caly_storage::ApplyTxnId(crash_workflow.storage.apply_txn_id.clone());
            caly_engine::recovery::run_ready(store.get_apply_journal(&txn_id))
                .expect("immediate storage read")
                .map_err(|error| error.summary)
                .expect("journal lookup failed")
                .expect("journal must exist for a settled txn")
        };
        assert!(
            !matches!(
                journal.state,
                ApplyJournalState::Pending | ApplyJournalState::Committed
            ),
            "crash at step {cut} left journal in {:?}",
            journal.state
        );
        assert_eq!(
            journal.current_step_index, cut,
            "journal cursor must point at the failing step"
        );

        // Invariant 3: what the journal claims must match what actually *applied*.
        // A crash injected before any cutover step ran may never report a cutover, and
        // must be abandoned rather than rolled back (nothing to undo yet).
        let cutover_ran = crash_plan.steps.iter().take(cut).any(|step| {
            phase_rank(phase_of(step)) >= phase_rank(caly_storage::ApplyPhase::Cutover)
        });
        if cutover_ran {
            assert!(
                journal.core_cutover_started,
                "crash at {cut} happened after cutover steps but journal denies it"
            );
            assert!(
                matches!(
                    journal.state,
                    ApplyJournalState::Reverted | ApplyJournalState::RecoveryFailed
                ),
                "post-cutover crash at {cut} must roll back, got {:?}",
                journal.state
            );
        } else {
            assert_eq!(
                journal.state,
                ApplyJournalState::Abandoned,
                "prepare-only crash at {cut} must abandon the txn, got {:?}",
                journal.state
            );
            assert!(!journal.core_cutover_started);
            assert!(!journal.net_effect_started);
        }
    }
}

/// A crash that looks like process death (journal stays pending) must be decidable from
/// the journal alone -- that is the whole point of `STORAGE_RECOVERY_EXECUTION_PLAN.md §6`.
#[test]
fn recovery_scan_decides_from_the_pending_journal_alone() {
    // Prepare-only pending transaction: no cutover happened, so cleanup is enough.
    let handle = EngineHandle::default();
    let workflow = plan_apply_request(ApplyRequest {
        profile_id: ProfileId("demo-tun-profile".to_owned()),
        dry_run: false,
        strict: false,
    })
    .expect("plan");
    let persisted = handle
        .begin_apply_persistence(workflow.storage_projection.clone(), &RunLimits::immediate())
        .expect("begin persistence");
    let report = handle.scan_recovery_state().expect("scan");
    assert_eq!(report.unresolved_apply_journals.len(), 1);
    assert_eq!(
        report.decisions,
        vec![caly_storage::RecoveryDecision::CleanupAbandonedRuntime {
            profile_id: "demo-tun-profile".to_owned()
        }],
        "prepare-only pending txn must only be cleaned up"
    );
    assert!(report.latest_last_known_good.is_none());
    drop(persisted);

    // Cutover started and an LKG exists: prefer rollback to last-known-good.
    let handle = EngineHandle::default();
    run_one(&handle, apply_command("demo-tun-profile", "establish-lkg"));
    let workflow = plan_apply_request(ApplyRequest {
        profile_id: ProfileId("demo-global-profile".to_owned()),
        dry_run: false,
        strict: false,
    })
    .expect("plan");
    let persisted = handle
        .begin_apply_persistence(workflow.storage_projection.clone(), &RunLimits::immediate())
        .expect("begin persistence");
    handle
        .advance_apply_phase(
            &persisted.journal,
            caly_storage::ApplyPhase::Cutover,
            3,
            1,
            &RunLimits::immediate(),
        )
        .expect("advance cutover");
    let report = handle.scan_recovery_state().expect("scan");
    assert!(
        matches!(
            report.decisions.as_slice(),
            [caly_storage::RecoveryDecision::RollbackToLastKnownGood { .. }]
        ),
        "cut-over pending txn with an LKG must roll back, got {:?}",
        report.decisions
    );
}

#[test]
fn apply_is_deterministic_across_repeated_planning() {
    let first = plan_apply_request(ApplyRequest {
        profile_id: ProfileId("demo-tun-strict-profile".to_owned()),
        dry_run: false,
        strict: true,
    })
    .expect("first plan");
    let second = plan_apply_request(ApplyRequest {
        profile_id: ProfileId("demo-tun-strict-profile".to_owned()),
        dry_run: false,
        strict: true,
    })
    .expect("second plan");

    assert_eq!(
        first.effect_plan, second.effect_plan,
        "effect plan must be stable"
    );
    assert_eq!(
        first.storage.artifact_object_digest,
        second.storage.artifact_object_digest
    );
    assert_eq!(first.storage.snapshot_id, second.storage.snapshot_id);
    assert_eq!(
        first.compilation.artifact_bytes,
        second.compilation.artifact_bytes
    );
    assert_eq!(first.capability, second.capability);
    assert_eq!(first.effect_steps, second.effect_steps);
}

#[test]
fn rollback_command_executes_compensations() {
    let handle = EngineHandle::default();
    let applied = run_one(&handle, apply_command("demo-tun-profile", "then-rollback"));
    assert_eq!(applied.outcome, caly_engine::JobOutcome::Succeeded);
    let world_after_apply = handle.effect_runtime().snapshot();
    assert!(world_after_apply.net_txn.is_some());
    assert!(world_after_apply.running_core.is_some());

    let lkg = handle
        .latest_last_known_good_snapshot()
        .expect("lkg")
        .expect("lkg")
        .id
        .0
        .clone();

    let rolled_back = run_one(&handle, rollback_command(Some(lkg.clone())));
    assert_eq!(
        rolled_back.outcome,
        caly_engine::JobOutcome::Succeeded,
        "stages: {:?}",
        stage_events(&handle, JobId(rolled_back.job_id))
    );

    let stages = stage_events(&handle, JobId(rolled_back.job_id));
    assert!(stages
        .iter()
        .any(|stage| stage.starts_with("recovery.started")));
    assert!(stages
        .iter()
        .any(|stage| stage.starts_with("recovery.succeeded") && stage.contains(&lkg)));
    assert!(log_events(&handle, JobId(rolled_back.job_id))
        .iter()
        .any(|line| line.contains("compensated 1 step")));
    // A rollback must be as auditable as an apply: the individual compensation is logged,
    // not just a count.
    assert!(
        log_events(&handle, JobId(rolled_back.job_id))
            .iter()
            .any(|line| line.contains("compensate 01:") && line.contains("net-revert")),
        "{:?}",
        log_events(&handle, JobId(rolled_back.job_id))
    );

    // The compensation really ran against the runtime: the net transaction is gone.
    let world = handle.effect_runtime().snapshot();
    assert!(
        world.net_txn.is_none(),
        "net.revert must clear the applied net txn, got {:?}",
        world.net_txn
    );
    // Rollback must not invent a new snapshot.
    assert_eq!(
        handle
            .latest_last_known_good_snapshot()
            .expect("lkg")
            .expect("lkg")
            .id
            .0,
        lkg
    );
}

#[test]
fn rollback_without_any_committed_snapshot_is_rejected() {
    let handle = EngineHandle::default();
    let result = run_one(&handle, rollback_command(None));
    assert_eq!(result.outcome, caly_engine::JobOutcome::Failed);
    let events = handle
        .follow_job(JobId(result.job_id))
        .expect("follow")
        .job
        .expect("job")
        .events;
    let failure = events
        .iter()
        .find_map(|event| match event {
            caly_engine::JobEvent::Failed { error } => Some(error.clone()),
            _ => None,
        })
        .unwrap_or_else(|| panic!("expected a failed job event, got {events:?}"));
    assert_eq!(failure.code, caly_api::ErrorCode::Conflict);
    assert_eq!(failure.category, caly_api::ErrorCategory::User);
    assert!(
        !failure.retryable,
        "a missing rollback target is not retryable"
    );
    assert!(
        failure.summary.contains("no rollback target"),
        "{}",
        failure.summary
    );
}
