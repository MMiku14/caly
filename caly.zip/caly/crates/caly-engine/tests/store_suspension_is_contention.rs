//! What a suspended port looks like **one layer above** the store (`ADR-036 §2.6` →
//! `OVERLOAD_AND_RETRY_MODEL §3.4`/`§6.2`).
//!
//! `crates/caly-storage/tests/store_port_budget.rs` establishes that the durable store drives its
//! ports under a budget and keeps the driver's kind. That is only worth having because of what the
//! layer above does with the kind: `StoreRefusal::from_storage_error` promotes a store `Busy` into
//! `RefusalKind::StorageBusy`, which is the one refusal `doctor`'s pressure tally is about. Before this
//! round the store answered `Internal`, so the promotion could never fire on a stuck port and the
//! refusal was indistinguishable from a corrupt record -- correct-looking code sitting on a
//! type that had already thrown the fact away.
//!
//! These two tests are the chain, end to end: a slow durable backend must not break an apply, and a
//! stuck one must be reported as contention rather than as damage.

use std::sync::Arc;

use caly_api::{ApplyRequest, ProfileId};
use caly_common::{Actor, RequestContext, TraceId};
use caly_engine::{
    Command, CommandId, CommandKind, EngineHandle, EngineState, JobOutcome, RefusalKind, RunLimits,
};
use caly_io_sim::{hang, stall, FaultInjector, MemFs, SharedFaults, SimFs};
use caly_storage::{
    build_apply_storage_projection, ApplyStorageProjectionInput, ApplyTxnId, FsStore, RevisionId,
    RevisionNumber,
};

const ROOT: &str = "var/caly";

fn projection() -> caly_storage::ApplyStorageProjection {
    build_apply_storage_projection(ApplyStorageProjectionInput {
        apply_txn_id: ApplyTxnId("txn-contention".to_owned()),
        trace_id: "trace-contention".to_owned(),
        job_id: None,
        profile_id: "demo-tun-profile".to_owned(),
        revision_id: RevisionId("rev-1".to_owned()),
        revision_number: RevisionNumber(1),
        semantic_digest: "sha:sem".to_owned(),
        compiled_artifact_digest: "sha:art".to_owned(),
        core_binary_digest: "sha:bin".to_owned(),
        core_identity: "mihomo@1.0".to_owned(),
        effect_plan_id: "plan-1".to_owned(),
        apply_plan_summary: "Restart".to_owned(),
        artifact_file_name: "config.yaml".to_owned(),
        artifact_size_bytes: 128,
        artifact_bytes: b"config: stub".to_vec(),
        content_type: "application/x-yaml".to_owned(),
        runtime_path: "runtime/demo/config.yaml".to_owned(),
        selection_memory_digest: None,
        validation_summary: String::new(),
        previous_snapshot_id: None,
        created_at_unix_ms: 0,
    })
}

fn engine_over(faults: &SharedFaults) -> EngineHandle {
    let fs = SimFs::new(MemFs::default(), faults.clone());
    let store = FsStore::open(Box::new(fs), ROOT).expect("open");
    EngineHandle::with_backend(EngineState::new(), Arc::new(store))
}

/// The durable store said "busy", and the engine heard "busy" -- as data, with the driver's own text
/// and the retry bit the driver set. `handle.begin_apply_persistence` is the seam the apply starts at,
/// so this is the earliest place the chain can be observed, and the one `§6.1` calls "safe to retry".
#[test]
fn a_stuck_port_reaches_the_engine_as_storage_contention() {
    let faults = SharedFaults::new(FaultInjector::new(7));
    let handle = engine_over(&faults);
    faults
        .push(hang("fs.write_atomic"))
        .expect("arm a hang on the only port the write path uses");

    let refusal = handle
        .begin_apply_persistence(projection(), &RunLimits::immediate())
        .expect_err("the port never answers, so nothing may be reported as persisted");
    assert_eq!(refusal.kind, RefusalKind::StorageBusy, "{refusal:?}");
    assert!(
        refusal.retryable,
        "a busy store is a reason to try again, copied from the driver's own bit: {refusal:?}"
    );
    assert!(
        refusal.message.contains(&format!(
            "still pending after {} poll(s)",
            caly_storage::STORE_PORT_POLL_BUDGET
        )),
        "the store's text reaches the caller unmodified, with the budget the driver actually used: \
         {refusal:?}"
    );
}

/// The same port, one notch gentler: the write is slow and then succeeds. This must be an ordinary,
/// committed apply -- `run_ready` at the engine seam plus `drive_port` at the store seam are the whole
/// mechanism, and no call site in between had to learn anything.
#[test]
fn a_slow_durable_backend_runs_the_apply_to_completion() {
    let faults = SharedFaults::new(FaultInjector::new(9));
    let handle = engine_over(&faults);
    faults
        .push(stall("fs.write_atomic", 2))
        .expect("arm one slow write");

    handle
        .submit(Command {
            id: CommandId("cmd-slow-store".to_owned()),
            request_id: None,
            actor: Actor::Cli,
            context: RequestContext::new(TraceId::new("slow-store"), Actor::Cli),
            timeout_ms: None,
            idempotency_key: None,
            kind: CommandKind::ProfileApply(ApplyRequest {
                profile_id: ProfileId("demo-tun-profile".to_owned()),
                dry_run: false,
                strict: false,
            }),
        })
        .expect("submit");
    let report = handle
        .drain_with_policy(caly_engine::WorkerPolicy::bounded(1))
        .expect("drain");
    let cycle = report.results.into_iter().next().expect("one cycle");
    assert_eq!(
        cycle.outcome,
        JobOutcome::Succeeded,
        "a port that needed three polls is a slow disk, not a failure: {cycle:?}"
    );
    let lkg = handle
        .latest_last_known_good_snapshot()
        .expect("read")
        .expect("the snapshot survived the slow write");
    assert_eq!(
        lkg.profile_id, "demo-tun-profile",
        "and it is the same truth a fast store would have committed"
    );
}
