//! `latest_support_bundle_digest` is the answer behind "the newest bundle the store still
//! holds" — the default read a caller gets when it clicks *Export* without a digest. Its
//! selection rule was arithmetic in search of a judge: newest `stored_at_unix_ms` wins, a tie is
//! broken by digest (deterministic, if arbitrary — and that determinism is now pinned), an
//! object with no timestamp cannot win over one with a date, and a non-bundle object never
//! counts at all.

use std::sync::Arc;

use caly_engine::{EngineHandle, EngineState};
use caly_io::{block_on_ready, Durability, Fs, IoContext, VPath};
use caly_io_sim::{FaultInjector, MemFs, SharedFaults, SimFs};
use caly_storage::cas::{CasObjectRef, CasWriteIntent, ObjectDigest, ObjectKind};
use caly_storage::fs_store::FsStore;
use caly_storage::{ObjectStore, StorageBackend};

const ROOT: &str = "var/caly";

fn ctx() -> IoContext {
    IoContext::new(
        caly_io::TraceId::new("latest-bundle"),
        caly_io::Actor::System,
    )
}

fn engine_with(entries: &[(&str, i64, ObjectKind)]) -> EngineHandle {
    let fs = SimFs::new(MemFs::default(), SharedFaults::new(FaultInjector::new(1)));
    let store = FsStore::open(Box::new(fs.clone()) as Box<dyn Fs>, ROOT).expect("open");
    for (digest, stored_at, kind) in entries {
        block_on_ready(ObjectStore::put(
            &store,
            CasWriteIntent {
                object: CasObjectRef {
                    digest: ObjectDigest((*digest).to_owned()),
                    kind: *kind,
                    size_bytes: None,
                    content_type: None,
                    content_sha256: None,
                    stored_at_unix_ms: None,
                },
                source_label: "latest-bundle-probe".to_owned(),
                payload: format!("payload-{digest}").into_bytes(),
                stored_at_unix_ms: *stored_at,
            },
            &ctx(),
        ))
        .expect("ready")
        .expect("put");
    }
    EngineHandle::with_backend(
        EngineState::new(),
        Arc::new(store) as Arc<dyn StorageBackend>,
    )
}

fn latest(handle: &EngineHandle) -> Option<String> {
    handle
        .latest_support_bundle_digest(&ctx())
        .expect("the store answers")
}

#[test]
fn the_newest_bundle_wins_and_a_tie_is_broken_deterministically() {
    let handle = engine_with(&[
        ("bundle:older", 100, ObjectKind::SupportBundle),
        ("bundle:tie-a", 200, ObjectKind::SupportBundle),
        // Same instant as tie-a, lexicographically greater digest: the tie-break is arbitrary
        // but it must be *stable* — two callers asking the same question get the same bundle.
        ("bundle:tie-z", 200, ObjectKind::SupportBundle),
        // A newer object that is not a bundle must not win by its date alone.
        ("artifact:newer", 400, ObjectKind::CompiledArtifact),
    ]);
    assert_eq!(latest(&handle).as_deref(), Some("bundle:tie-z"));
    assert_eq!(
        latest(&handle).as_deref(),
        Some("bundle:tie-z"),
        "the tie-break is deterministic: the same question gets the same answer"
    );
}

#[test]
fn a_store_with_no_bundle_at_all_answers_none_even_if_it_holds_newer_objects() {
    let handle = engine_with(&[("artifact:only", 9_000, ObjectKind::CompiledArtifact)]);
    assert_eq!(
        latest(&handle),
        None,
        "\"the newest bundle\" is None when there is no bundle, not the newest anything"
    );
}

/// An undated bundle record is reachable in reality: a record written out of band (or by an
/// older writer) can carry `stored_at_unix_ms: None`, and the selection treats that as "no
/// claim", not as "newest". Placed out of band on purpose, under the `ADR-041` escaped name.
#[test]
fn an_undated_bundle_loses_to_any_dated_one() {
    let fs = SimFs::new(MemFs::default(), SharedFaults::new(FaultInjector::new(1)));
    let store = FsStore::open(Box::new(fs.clone()) as Box<dyn Fs>, ROOT).expect("open");
    block_on_ready(ObjectStore::put(
        &store,
        CasWriteIntent {
            object: CasObjectRef {
                digest: ObjectDigest("bundle:dated".to_owned()),
                kind: ObjectKind::SupportBundle,
                size_bytes: None,
                content_type: None,
                content_sha256: None,
                stored_at_unix_ms: None,
            },
            source_label: "dated".to_owned(),
            payload: b"dated".to_vec(),
            stored_at_unix_ms: 50,
        },
        &ctx(),
    ))
    .expect("ready")
    .expect("put");

    let undated = CasObjectRef {
        digest: ObjectDigest("bundle:undated".to_owned()),
        kind: ObjectKind::SupportBundle,
        size_bytes: None,
        content_type: None,
        content_sha256: None,
        stored_at_unix_ms: None,
    };
    let undated_stem = caly_storage::fs_store::escape_component("bundle:undated");
    let name = format!(
        "{ROOT}/meta/objects/{}/{}.obj",
        caly_storage::record_shard(&undated_stem),
        undated_stem
    );
    let path = VPath::try_from_str(&name).expect("static path");
    block_on_ready(fs.write_atomic(
        &path,
        caly_storage::encode_object(&undated).into_bytes(),
        Durability::D2,
        &ctx(),
    ))
    .expect("ready")
    .expect("place the undated record");

    let handle = EngineHandle::with_backend(
        EngineState::new(),
        Arc::new(store) as Arc<dyn StorageBackend>,
    );
    assert_eq!(
        latest(&handle).as_deref(),
        Some("bundle:dated"),
        "no timestamp is no claim: any dated bundle beats an undated one"
    );
}
