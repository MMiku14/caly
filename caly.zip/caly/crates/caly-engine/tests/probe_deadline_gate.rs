//! `ADR-036 §2.5`, the last row of that ADR's `§1` table: `Probe { deadline_ms }` used to be printed
//! and never enforced, which made "verify before commit" (`ADR-016`) a gate on *whether* a probe ran
//! rather than on *whether it answered in time*.
//!
//! The rule as implemented: the runtime reports how long the step took, the executor compares that with
//! the plan's budget, and an overrun is a **verify failure** -- the existing "no commit without a
//! passed probe" branch, not a new execution status. So a core that answers late does not get a second
//! kind of outcome; it simply has not been verified.

use caly_api::{ApplyRequest, ProfileId};
use caly_engine::executor::{execute_effect_plan, ExecutionPolicy};
use caly_engine::plan_apply_request;
use caly_engine::sim_runtime::{SimulatedCore, SimulatedRuntime};
use caly_plan::{DeployImpact, EffectPlan, EffectStep, PlanId, PrivilegeSet, ProbeKind, ProbeSpec};

fn journal() -> caly_storage::ApplyJournalRecord {
    plan_apply_request(ApplyRequest {
        profile_id: ProfileId("demo-tun-profile".to_owned()),
        dry_run: false,
        strict: false,
    })
    .expect("plan")
    .storage_projection
    .apply_journal
}

fn plan_with_deadline(deadline_ms: u64) -> EffectPlan {
    EffectPlan {
        id: PlanId("probe-gate".to_owned()),
        steps: vec![
            EffectStep::Probe {
                probe: ProbeSpec {
                    kind: ProbeKind::ApiReady,
                    target: None,
                },
                deadline_ms,
            },
            EffectStep::MarkSnapshot {
                snapshot_id: caly_plan::SnapshotId("snap-1".to_owned()),
            },
            EffectStep::CommitRevision { revision: 7 },
        ],
        compensations: Vec::new(),
        requires: PrivilegeSet::default(),
        impact: DeployImpact::Restart,
    }
}

#[test]
fn a_probe_that_answers_in_time_still_opens_the_commit_gate() {
    let runtime = SimulatedRuntime::with_running_core(SimulatedCore {
        instance: "core-1".to_owned(),
        config_digest: "sha:cfg".to_owned(),
        binary_digest: "sha:bin".to_owned(),
        kind: caly_plan::CoreKind::Mihomo,
    });
    let execution = execute_effect_plan(
        &plan_with_deadline(1_000),
        &journal(),
        &runtime,
        &ExecutionPolicy::default(),
    );
    assert!(execution.succeeded(), "{:?}", execution.status);
    assert!(
        execution.probe_passed,
        "a fast probe verifies the deployment"
    );
    assert_eq!(execution.committed_revision, Some(7));
}

#[test]
fn a_probe_that_overruns_its_budget_is_a_verify_failure_not_a_commit() {
    let runtime = SimulatedRuntime::with_running_core(SimulatedCore {
        instance: "core-1".to_owned(),
        config_digest: "sha:cfg".to_owned(),
        binary_digest: "sha:bin".to_owned(),
        kind: caly_plan::CoreKind::Mihomo,
    });
    // One millisecond over the 1_000ms budget: the boundary belongs to the plan, not to a tolerance.
    runtime.make_next_probe_slow(1_001);

    let execution = execute_effect_plan(
        &plan_with_deadline(1_000),
        &journal(),
        &runtime,
        &ExecutionPolicy::default(),
    );
    assert!(
        !execution.succeeded(),
        "a probe that did not answer in time is not a verification"
    );
    assert!(
        matches!(
            &execution.status,
            caly_engine::executor::ExecutionStatus::FailedBeforeCutover {
                retryable: true,
                ..
            }
        ),
        "{:?}",
        execution.status
    );
    assert!(!execution.probe_passed, "the gate stays shut");
    assert!(
        !execution.snapshot_marked && execution.committed_revision.is_none(),
        "and nothing was published: {:?} {:?}",
        execution.snapshot_marked,
        execution.committed_revision
    );
    let label = &execution.steps[0];
    assert!(
        label
            .observations
            .iter()
            .any(|line| line.contains("took=1001ms")),
        "the evidence keeps the measured time, or the refusal cannot be audited: {:?}",
        label.observations
    );
}

#[test]
fn a_probe_that_used_exactly_its_budget_is_not_overrunning_it() {
    let runtime = SimulatedRuntime::with_running_core(SimulatedCore {
        instance: "core-1".to_owned(),
        config_digest: "sha:cfg".to_owned(),
        binary_digest: "sha:bin".to_owned(),
        kind: caly_plan::CoreKind::Mihomo,
    });
    runtime.make_next_probe_slow(1_000);
    let execution = execute_effect_plan(
        &plan_with_deadline(1_000),
        &journal(),
        &runtime,
        &ExecutionPolicy::default(),
    );
    assert!(
        execution.succeeded(),
        "off-by-one here means a deployment fails for taking the time it was granted: {:?}",
        execution.status
    );
}

/// The whole plan is refused before any runtime is touched, so a missing budget cannot be mistaken for
/// a slow core: one is a plan defect, the other is a world event.
#[test]
fn an_unbudgeted_probe_rejects_the_plan_before_any_step_runs() {
    let runtime = SimulatedRuntime::new();
    let execution = execute_effect_plan(
        &plan_with_deadline(0),
        &journal(),
        &runtime,
        &ExecutionPolicy::default(),
    );
    match &execution.status {
        caly_engine::executor::ExecutionStatus::Rejected { reason } => {
            assert!(reason.contains("deadline_ms=0"), "{reason}");
        }
        other => panic!("expected a rejected plan, got {other:?}"),
    }
    assert!(
        execution.steps.is_empty(),
        "a rejected plan must not have touched the runtime at all"
    );
}

/// The world-model knob is one-shot, for the same reason `fail_next_probe` is: a delay that stays armed
/// would make *every* later probe slow, so a test would be asserting an accumulation instead of a
/// decision. It matters because a real plan runs several probes back to back (`mihomo` and `singbox`
/// both emit `ApiReady` then `ConfigIdentity`) with per-step budgets.
#[test]
fn a_delay_is_charged_to_one_probe_and_not_to_the_plan() {
    let runtime = SimulatedRuntime::with_running_core(SimulatedCore {
        instance: "core-1".to_owned(),
        config_digest: "sha:cfg".to_owned(),
        binary_digest: "sha:bin".to_owned(),
        kind: caly_plan::CoreKind::Mihomo,
    });
    runtime.make_next_probe_slow(5_000);
    let plan = EffectPlan {
        id: PlanId("two-probes".to_owned()),
        steps: vec![
            EffectStep::Probe {
                probe: ProbeSpec {
                    kind: ProbeKind::ApiReady,
                    target: None,
                },
                // Generous: the slow one is allowed to take its 5s.
                deadline_ms: 9_000,
            },
            EffectStep::Probe {
                probe: ProbeSpec {
                    kind: ProbeKind::ConfigIdentity,
                    target: Some("sha:cfg".to_owned()),
                },
                // Tight: if the delay leaked past the probe it was scripted on, this one is over.
                deadline_ms: 1_000,
            },
            EffectStep::MarkSnapshot {
                snapshot_id: caly_plan::SnapshotId("snap-1".to_owned()),
            },
        ],
        compensations: Vec::new(),
        requires: PrivilegeSet::default(),
        impact: DeployImpact::Restart,
    };

    let execution = execute_effect_plan(&plan, &journal(), &runtime, &ExecutionPolicy::default());
    assert!(
        execution.succeeded(),
        "one slow probe must not poison the whole plan: {:?}",
        execution.status
    );
    let slow = execution.steps[0]
        .observations
        .iter()
        .filter(|line| line.contains("took=5000ms"))
        .count();
    let clean = execution.steps[1]
        .observations
        .iter()
        .filter(|line| line.contains("took=0ms"))
        .count();
    assert_eq!(
        slow, 1,
        "the delay is recorded exactly once: {:?}",
        execution.steps
    );
    assert_eq!(
        clean, 1,
        "the second probe answered as if nothing had happened"
    );
}

/// A probe that blows its budget stops the execution *there*: the step is blamed, nothing after it
/// runs, and `probe_passed` stays false so the commit gate below also refuses to publish.
#[test]
fn the_execution_stops_at_the_probe_that_overspent() {
    let runtime = SimulatedRuntime::with_running_core(SimulatedCore {
        instance: "core-1".to_owned(),
        config_digest: "sha:cfg".to_owned(),
        binary_digest: "sha:bin".to_owned(),
        kind: caly_plan::CoreKind::Mihomo,
    });
    runtime.make_next_probe_slow(5_000);
    let plan = EffectPlan {
        id: PlanId("overspent-first".to_owned()),
        steps: vec![
            EffectStep::Probe {
                probe: ProbeSpec {
                    kind: ProbeKind::ApiReady,
                    target: None,
                },
                deadline_ms: 1_000,
            },
            EffectStep::MarkSnapshot {
                snapshot_id: caly_plan::SnapshotId("snap-1".to_owned()),
            },
        ],
        compensations: Vec::new(),
        requires: PrivilegeSet::default(),
        impact: DeployImpact::Restart,
    };
    let execution = execute_effect_plan(&plan, &journal(), &runtime, &ExecutionPolicy::default());
    assert!(!execution.succeeded());
    assert_eq!(
        execution.steps.len(),
        1,
        "nothing after the failed probe is even attempted: {:?}",
        execution.steps
    );
    assert!(!execution.snapshot_marked);
}
