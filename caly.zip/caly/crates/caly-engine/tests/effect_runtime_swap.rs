//! The effect-runtime seam is real, not decorative (round 55, `ROADMAP §13`'s "真 effect
//! 后端"): a handle built with [`EngineHandle::with_effect_runtime`] must run **every** effect
//! step through the injected runtime — the same plan, a different world. The judge wraps the
//! simulator in a counting delegator and asks two questions at once:
//!
//! * did the executor call the *injected* runtime at all (counter > 0), and
//! * did the calls genuinely land in the world underneath (a core really ran, in the sim
//!   that the delegator wraps)?
//!
//! A seam that ignored the injection, or a delegator that answered without touching its
//! inner runtime, fails exactly one of the two.

use std::sync::atomic::{AtomicUsize, Ordering};
use std::sync::Arc;

use caly_api::ApplyRequest;
use caly_common::{Actor, RequestContext, TraceId};
use caly_engine::command::{Command, CommandKind};
use caly_engine::executor::{EffectRuntime, StepEvidence, StepFailure};
use caly_engine::sim_runtime::SimulatedRuntime;
use caly_engine::state::EngineState;
use caly_engine::worker::WorkerPolicy;
use caly_engine::EngineHandle;
use caly_storage::{ApplyPhase, InMemoryStorage, StorageBackend};

/// Delegates every call to the wrapped runtime and counts them — the smallest runtime whose
/// *provenance* is observable from the outside.
struct CountingRuntime {
    inner: Arc<SimulatedRuntime>,
    calls: AtomicUsize,
}

impl EffectRuntime for CountingRuntime {
    fn execute(
        &self,
        phase: ApplyPhase,
        step: &caly_plan::EffectStep,
    ) -> Result<StepEvidence, StepFailure> {
        self.calls.fetch_add(1, Ordering::SeqCst);
        self.inner.execute(phase, step)
    }

    fn compensate(
        &self,
        phase: ApplyPhase,
        step: &caly_plan::EffectStep,
    ) -> Result<StepEvidence, StepFailure> {
        self.calls.fetch_add(1, Ordering::SeqCst);
        self.inner.compensate(phase, step)
    }
}

fn apply_command(profile_id: &str) -> Command {
    Command {
        id: caly_engine::command::CommandId(format!("cmd-swap-{profile_id}")),
        request_id: None,
        actor: Actor::Cli,
        context: RequestContext::new(TraceId::new("effect-runtime-swap"), Actor::Cli),
        timeout_ms: None,
        idempotency_key: None,
        kind: CommandKind::ProfileApply(ApplyRequest {
            profile_id: caly_api::ProfileId(profile_id.to_owned()),
            dry_run: false,
            strict: false,
        }),
    }
}

#[test]
fn an_injected_effect_runtime_really_runs_the_plan() {
    let sim = Arc::new(SimulatedRuntime::new());
    let counting = Arc::new(CountingRuntime {
        inner: Arc::clone(&sim),
        calls: AtomicUsize::new(0),
    });
    let storage: Arc<dyn StorageBackend> = Arc::new(InMemoryStorage::new());
    let handle = EngineHandle::with_effect_runtime(EngineState::new(), storage, counting.clone());

    let accepted = handle.submit(apply_command("demo-tun-profile")).expect("submit");
    let report = handle
        .drain_with_policy(WorkerPolicy::bounded(1))
        .expect("drain");
    let result = report.results.into_iter().next().expect("one result");
    assert_eq!(
        result.outcome,
        caly_engine::job::JobOutcome::Succeeded,
        "the injected runtime must carry the apply, not break it"
    );

    let calls = counting.calls.load(Ordering::SeqCst);
    assert!(
        calls > 0,
        "the executor must call the injected runtime, not a baked-in one"
    );
    let world = sim.snapshot();
    assert!(
        world.running_core.is_some(),
        "the delegator's calls must genuinely land in the world it wraps"
    );
    // And the plan that ran is the plan: a tun profile leaves its net transaction behind.
    assert!(world.net_txn.is_some(), "{world:?}");
    assert_eq!(result.job_id, accepted.accepted.job_id.0);
}
