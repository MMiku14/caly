//! The `APPLY_EXECUTION_CENTERLINE.md §6.1` Phase B pending guard, end to end.
//!
//! `§6.1` demands three things of the cutover window -- a pending guard, a defined order, and
//! "必须允许 crash recovery 识别执行到哪一步" -- and `OVERLOAD_AND_RETRY_MODEL.md §6.2` adds what
//! happens when the journal refuses to cooperate mid-transaction. Before this file, none of that was
//! reachable from a real apply: measured by instrumenting `EngineHandle::put_apply_journal` and
//! draining one apply, the store received exactly one journal write during execution
//! (`phase=Finalize cursor=8 net=true cutover=true state=Committed`), i.e. the cutover evidence was
//! written *after* the cutover had already happened. A process killed in between read as "nothing was
//! touched", which is the one answer a recovery scanner must never be given.
//!
//! What is asserted here, and why each one is the interesting direction:
//!
//! * the intent record for step `k` is in the store **before** the runtime sees step `k` -- ordering,
//!   not existence, is what makes it crash-visible;
//! * a refusal to write that record **stops the step**: "record before you touch" is a guard only if
//!   refusing to record refuses to touch;
//! * the refusal is reported to the operator as storage pressure with a `ManualIntervention` hint,
//!   not swallowed into "retry later" (`§6.2`'s first sentence);
//! * one command has one spent-budget counter across both bounded seams, because the alternative is
//!   a cap that silently means "per seam".

use std::sync::atomic::{AtomicUsize, Ordering};
use std::sync::{Arc, Mutex};

use caly_api::{ApiError, ApplyRequest, ErrorCode, JobId, ProfileId};
use caly_common::{Actor, IoBudget, RequestContext, TraceId};
use caly_engine::apply::plan_apply_request;
use caly_engine::executor::{
    execute_effect_plan, execute_effect_plan_with_cursor, needs_intent_record, CursorRefusal,
    EffectCursor, EffectRuntime, ExecutionPolicy, ExecutionStatus, NoCursor, StepEvidence,
    StepFailure, StepOutcome, StepSkip,
};
use caly_engine::{Command, CommandId, CommandKind, EngineHandle, EngineState, JobOutcome};
use caly_io::IoContext;
use caly_plan::{
    BlobRef, CoreKind, CoreSpec, DeployImpact, Durability, EffectPlan, EffectStep, PlanId,
    PrivilegeSet,
};
use caly_storage::{
    build_apply_storage_projection, ApplyJournalRecord, ApplyJournalState, ApplyJournalStore,
    ApplyStorageProjectionInput, ApplyTxnId, BoxFuture, CasObjectRef, CasWriteIntent,
    InMemoryStorage, JobLogStore, JournalRecord, JournalRecordId, JournalStore,
    MaterializationRequest, ObjectStore, RevisionId, RevisionNumber, RevisionRecord, RevisionStore,
    SnapshotRecord, SnapshotRecordId, SnapshotStore, StorageBackend, StorageError,
    StorageErrorKind,
};

// ---------------------------------------------------------------- fixtures

/// The plan's phases, measured rather than remembered: `[Prepare, Prepare, Cutover, Cutover,
/// Finalize x4]` for `demo-tun-profile`. The test that uses this re-derives the indices from the
/// plan it is given, so a plan change moves the assertion instead of silently voiding it.
fn cutover_indices(plan: &EffectPlan) -> Vec<usize> {
    plan.steps
        .iter()
        .enumerate()
        .filter(|(_, step)| {
            caly_engine::executor::phase_of(step) == caly_storage::ApplyPhase::Cutover
        })
        .map(|(index, _)| index)
        .collect()
}

fn pending_journal() -> ApplyJournalRecord {
    build_apply_storage_projection(ApplyStorageProjectionInput {
        apply_txn_id: ApplyTxnId("txn-guard".to_owned()),
        trace_id: "trace-guard".to_owned(),
        job_id: None,
        profile_id: "profile-1".to_owned(),
        revision_id: RevisionId("rev-1".to_owned()),
        revision_number: RevisionNumber(1),
        semantic_digest: "sha:sem".to_owned(),
        compiled_artifact_digest: "sha:art".to_owned(),
        core_binary_digest: "sha:bin".to_owned(),
        core_identity: "mihomo@1.0".to_owned(),
        effect_plan_id: "plan-guard".to_owned(),
        apply_plan_summary: "Restart".to_owned(),
        artifact_file_name: "config.yaml".to_owned(),
        artifact_size_bytes: 128,
        artifact_bytes: b"config: stub".to_vec(),
        content_type: "application/x-yaml".to_owned(),
        runtime_path: "runtime/profile-1/config.yaml".to_owned(),
        selection_memory_digest: None,
        validation_summary: String::new(),
        previous_snapshot_id: None,
        created_at_unix_ms: 0,
    })
    .apply_journal
}

fn write_object(digest: &str) -> EffectStep {
    EffectStep::WriteObject {
        digest: digest.to_owned(),
        source: BlobRef {
            digest: digest.to_owned(),
            size_hint: Some(128),
        },
        durability: Durability::D2,
    }
}

fn spawn_core() -> EffectStep {
    EffectStep::SpawnCore {
        spec: CoreSpec {
            kind: CoreKind::Mihomo,
            binary_digest: "sha:bin".to_owned(),
            config_digest: "sha:art".to_owned(),
        },
    }
}

fn probe() -> EffectStep {
    EffectStep::Probe {
        probe: caly_plan::ProbeSpec {
            kind: caly_plan::ProbeKind::ApiReady,
            target: None,
        },
        deadline_ms: 1_000,
    }
}

fn stop_core() -> EffectStep {
    EffectStep::StopCore {
        instance: caly_plan::InstanceId("core-1".to_owned()),
        grace_ms: 100,
    }
}

fn plan(steps: Vec<EffectStep>, compensations: Vec<EffectStep>) -> EffectPlan {
    EffectPlan {
        id: PlanId("plan-guard".to_owned()),
        steps,
        compensations,
        requires: PrivilegeSet::default(),
        impact: DeployImpact::Restart,
    }
}

/// A runtime that writes down what it was asked to do, in order. The interleaving between the cursor
/// and the runtime is the whole property, and only the runtime can say when it was reached.
#[derive(Clone, Default)]
struct TracedRuntime {
    trace: Arc<Mutex<Vec<String>>>,
}

impl TracedRuntime {
    fn trace(&self) -> Vec<String> {
        self.trace
            .lock()
            .unwrap_or_else(|poisoned| poisoned.into_inner())
            .clone()
    }
}

impl EffectRuntime for TracedRuntime {
    fn execute(
        &self,
        phase: caly_storage::ApplyPhase,
        _step: &EffectStep,
    ) -> Result<StepEvidence, StepFailure> {
        if let Ok(mut guard) = self.trace.lock() {
            guard.push(format!("exec {phase:?}"));
        }
        Ok(StepEvidence::one("traced"))
    }

    fn compensate(
        &self,
        phase: caly_storage::ApplyPhase,
        _step: &EffectStep,
    ) -> Result<StepEvidence, StepFailure> {
        if let Ok(mut guard) = self.trace.lock() {
            guard.push(format!("compensate {phase:?}"));
        }
        Ok(StepEvidence::one("undone"))
    }
}

/// A cursor that appends to the same trace, so "before" is a fact about one sequence rather than a
/// reading of two.
struct TracingCursor {
    trace: Arc<Mutex<Vec<String>>>,
    /// Refuse this many-th intent call (1-based). `None` records everything.
    refuse_at: Option<usize>,
    intents: usize,
}

impl TracingCursor {
    fn new(trace: Arc<Mutex<Vec<String>>>, refuse_at: Option<usize>) -> Self {
        Self {
            trace,
            refuse_at,
            intents: 0,
        }
    }
}

impl EffectCursor for TracingCursor {
    fn record_intent(
        &mut self,
        phase: caly_storage::ApplyPhase,
        step_index: usize,
    ) -> Result<(), CursorRefusal> {
        self.intents += 1;
        if let Ok(mut guard) = self.trace.lock() {
            guard.push(format!("intent {step_index} ({phase:?})"));
        }
        if self.refuse_at == Some(self.intents) {
            return Err(CursorRefusal {
                kind: caly_engine::RefusalKind::StorageBusy,
                message: "the journal is busy (injected)".to_owned(),
                retryable: true,
                caller_side: false,
            });
        }
        Ok(())
    }
}

// ---------------------------------------------------------------- the store spy

/// A backend that keeps every apply-journal record it was asked to write, and can refuse one of them
/// the way a locked disk does.
#[derive(Default)]
struct JournalSpy {
    inner: InMemoryStorage,
    writes: Arc<Mutex<Vec<ApplyJournalRecord>>>,
    seen: Arc<AtomicUsize>,
    /// The 1-based index of the write that must be refused; `usize::MAX` refuses nothing.
    refuse_at: Arc<AtomicUsize>,
}

impl JournalSpy {
    fn new() -> Self {
        Self::default()
    }

    fn arm(&self, write_number: usize) {
        self.refuse_at.store(write_number, Ordering::SeqCst);
    }

    fn writes(&self) -> Vec<ApplyJournalRecord> {
        self.writes
            .lock()
            .unwrap_or_else(|poisoned| poisoned.into_inner())
            .clone()
    }
}

impl StorageBackend for JournalSpy {}

impl JobLogStore for JournalSpy {
    fn put_job_log<'a>(
        &'a self,
        record: caly_storage::job_log::JobLogRecord,
        ctx: &'a IoContext,
    ) -> BoxFuture<'a, Result<(), StorageError>> {
        self.inner.put_job_log(record, ctx)
    }
    fn get_job_log<'a>(
        &'a self,
        job_id: &'a str,
        ctx: &'a IoContext,
    ) -> BoxFuture<'a, Result<Option<caly_storage::job_log::JobLogRecord>, StorageError>> {
        self.inner.get_job_log(job_id, ctx)
    }
    fn list_job_logs<'a>(
        &'a self,
        ctx: &'a IoContext,
    ) -> BoxFuture<'a, Result<Vec<caly_storage::job_log::JobLogRecord>, StorageError>> {
        self.inner.list_job_logs(ctx)
    }
}

impl ObjectStore for JournalSpy {
    fn put<'a>(
        &'a self,
        intent: CasWriteIntent,
        ctx: &'a IoContext,
    ) -> BoxFuture<'a, Result<CasObjectRef, StorageError>> {
        self.inner.put(intent, ctx)
    }

    fn get<'a>(
        &'a self,
        digest: &'a str,
        ctx: &'a IoContext,
    ) -> BoxFuture<'a, Result<Option<CasObjectRef>, StorageError>> {
        self.inner.get(digest, ctx)
    }

    fn materialize<'a>(
        &'a self,
        request: MaterializationRequest,
        ctx: &'a IoContext,
    ) -> BoxFuture<'a, Result<(), StorageError>> {
        self.inner.materialize(request, ctx)
    }

    fn list_objects<'a>(
        &'a self,
        ctx: &'a IoContext,
    ) -> BoxFuture<'a, Result<Vec<CasObjectRef>, StorageError>> {
        self.inner.list_objects(ctx)
    }

    fn delete<'a>(
        &'a self,
        digest: &'a str,
        ctx: &'a IoContext,
    ) -> BoxFuture<'a, Result<bool, StorageError>> {
        self.inner.delete(digest, ctx)
    }
}

impl RevisionStore for JournalSpy {
    fn put_revision<'a>(
        &'a self,
        record: RevisionRecord,
        ctx: &'a IoContext,
    ) -> BoxFuture<'a, Result<(), StorageError>> {
        self.inner.put_revision(record, ctx)
    }

    fn get_revision<'a>(
        &'a self,
        revision_id: &'a RevisionId,
        ctx: &'a IoContext,
    ) -> BoxFuture<'a, Result<Option<RevisionRecord>, StorageError>> {
        self.inner.get_revision(revision_id, ctx)
    }

    fn list_revisions<'a>(
        &'a self,
        ctx: &'a IoContext,
    ) -> BoxFuture<'a, Result<Vec<RevisionRecord>, StorageError>> {
        self.inner.list_revisions(ctx)
    }
}

impl SnapshotStore for JournalSpy {
    fn put_snapshot<'a>(
        &'a self,
        record: SnapshotRecord,
        ctx: &'a IoContext,
    ) -> BoxFuture<'a, Result<(), StorageError>> {
        self.inner.put_snapshot(record, ctx)
    }

    fn get_snapshot<'a>(
        &'a self,
        snapshot_id: &'a SnapshotRecordId,
        ctx: &'a IoContext,
    ) -> BoxFuture<'a, Result<Option<SnapshotRecord>, StorageError>> {
        self.inner.get_snapshot(snapshot_id, ctx)
    }

    fn latest_last_known_good<'a>(
        &'a self,
        ctx: &'a IoContext,
    ) -> BoxFuture<'a, Result<Option<SnapshotRecord>, StorageError>> {
        self.inner.latest_last_known_good(ctx)
    }

    fn list_snapshots<'a>(
        &'a self,
        ctx: &'a IoContext,
    ) -> BoxFuture<'a, Result<Vec<SnapshotRecord>, StorageError>> {
        self.inner.list_snapshots(ctx)
    }
}

impl JournalStore for JournalSpy {
    fn put_journal<'a>(
        &'a self,
        record: JournalRecord,
        ctx: &'a IoContext,
    ) -> BoxFuture<'a, Result<(), StorageError>> {
        self.inner.put_journal(record, ctx)
    }

    fn get_journal<'a>(
        &'a self,
        journal_id: &'a JournalRecordId,
        ctx: &'a IoContext,
    ) -> BoxFuture<'a, Result<Option<JournalRecord>, StorageError>> {
        self.inner.get_journal(journal_id, ctx)
    }

    fn list_pending<'a>(
        &'a self,
        ctx: &'a IoContext,
    ) -> BoxFuture<'a, Result<Vec<JournalRecord>, StorageError>> {
        self.inner.list_pending(ctx)
    }
}

impl ApplyJournalStore for JournalSpy {
    fn put_apply_journal<'a>(
        &'a self,
        record: ApplyJournalRecord,
        ctx: &'a IoContext,
    ) -> BoxFuture<'a, Result<(), StorageError>> {
        let which = self.seen.fetch_add(1, Ordering::SeqCst) + 1;
        if which == self.refuse_at.load(Ordering::SeqCst) {
            return Box::pin(async move {
                Err(StorageError::new(
                    StorageErrorKind::Busy,
                    "apply journal is busy (injected)",
                ))
            });
        }
        if let Ok(mut guard) = self.writes.lock() {
            guard.push(record.clone());
        }
        self.inner.put_apply_journal(record, ctx)
    }

    fn get_apply_journal<'a>(
        &'a self,
        apply_txn_id: &'a ApplyTxnId,
        ctx: &'a IoContext,
    ) -> BoxFuture<'a, Result<Option<ApplyJournalRecord>, StorageError>> {
        self.inner.get_apply_journal(apply_txn_id, ctx)
    }

    fn list_pending_apply<'a>(
        &'a self,
        ctx: &'a IoContext,
    ) -> BoxFuture<'a, Result<Vec<ApplyJournalRecord>, StorageError>> {
        self.inner.list_pending_apply(ctx)
    }

    fn list_unresolved_apply<'a>(
        &'a self,
        ctx: &'a IoContext,
    ) -> BoxFuture<'a, Result<Vec<ApplyJournalRecord>, StorageError>> {
        self.inner.list_unresolved_apply(ctx)
    }
}

fn apply_command(budget_requests: Option<u32>) -> Command {
    let mut context = RequestContext::new(TraceId::new("trace-guard"), Actor::Cli);
    if let Some(max_requests) = budget_requests {
        context.io_budget = IoBudget {
            max_bytes: None,
            max_requests: Some(max_requests),
        };
    }
    Command {
        id: CommandId("cmd-guard".to_owned()),
        request_id: None,
        actor: Actor::Cli,
        context,
        timeout_ms: None,
        idempotency_key: None,
        kind: CommandKind::ProfileApply(ApplyRequest {
            profile_id: ProfileId("demo-tun-profile".to_owned()),
            dry_run: false,
            strict: false,
        }),
    }
}

/// Run exactly one apply cycle through the worker, with the caller's `max_requests` if the test has
/// an opinion about it.
fn drain(handle: &EngineHandle) -> caly_engine::WorkerCycleResult {
    drain_with_budget(handle, None)
}

fn drain_with_budget(handle: &EngineHandle, budget: Option<u32>) -> caly_engine::WorkerCycleResult {
    handle.submit(apply_command(budget)).expect("submit");
    handle
        .drain_with_policy(caly_engine::WorkerPolicy::bounded(1))
        .expect("drain")
        .results
        .into_iter()
        .next()
        .expect("one cycle")
}

fn failure_of(handle: &EngineHandle, job_id: u64) -> ApiError {
    handle
        .follow_job(JobId(job_id))
        .expect("follow")
        .job
        .expect("job")
        .events
        .iter()
        .find_map(|event| match event {
            caly_engine::JobEvent::Failed { error } => Some(error.clone()),
            _ => None,
        })
        .expect("a failed apply must surface a public error")
}

// ---------------------------------------------------------------- executor level

/// The order is the property. A record written after the step is a receipt, and a receipt does not
/// survive a process that dies mid-step.
#[test]
fn every_cutover_step_is_announced_before_the_runtime_sees_it() {
    let runtime = TracedRuntime::default();
    let mut cursor = TracingCursor::new(Arc::clone(&runtime.trace), None);
    let plan = plan(
        vec![
            write_object("sha:art"),
            spawn_core(),
            stop_core(),
            probe(),
            EffectStep::MarkSnapshot {
                snapshot_id: caly_plan::SnapshotId("snap-1".to_owned()),
            },
        ],
        Vec::new(),
    );
    let indices = cutover_indices(&plan);
    assert_eq!(indices, vec![1, 2], "the fixture's cutover window");

    let execution = execute_effect_plan_with_cursor(
        &plan,
        &pending_journal(),
        &runtime,
        &ExecutionPolicy::default(),
        &mut cursor,
    );

    assert!(execution.succeeded(), "{execution:?}");
    assert_eq!(
        runtime.trace(),
        vec![
            "exec Prepare".to_owned(),
            "intent 1 (Cutover)".to_owned(),
            "exec Cutover".to_owned(),
            "intent 2 (Cutover)".to_owned(),
            "exec Cutover".to_owned(),
            "exec Finalize".to_owned(),
            "exec Finalize".to_owned(),
        ],
        "one intent immediately before each cutover step, and nothing around prepare or finalize"
    );
    assert_eq!(
        execution.steps.iter().filter(|step| step.skipped()).count(),
        0
    );
}

/// `Prepare` is safe to redo and `Finalize` *is* the persistence work, so an extra record for either
/// is not a safety gain -- it is a durable write per step. `needs_intent_record` is a `const fn` so
/// the relation also holds at compile time (`executor.rs` carries the `const _: () = ...` form).
#[test]
fn the_guard_covers_the_cutover_window_and_nothing_else() {
    assert!(!needs_intent_record(caly_storage::ApplyPhase::Prepare));
    assert!(needs_intent_record(caly_storage::ApplyPhase::Cutover));
    assert!(
        !needs_intent_record(caly_storage::ApplyPhase::Finalize),
        "a record before a commit step would be a write about a write"
    );
    let cutover_only = |phase| needs_intent_record(phase);
    assert!(
        cutover_only(caly_storage::ApplyPhase::Cutover)
            && !cutover_only(caly_storage::ApplyPhase::Prepare),
        "the predicate must not be the phase list's negation of something else"
    );
}

/// The refusal has to *stop* something, or the guard is a log line.
#[test]
fn a_refused_intent_stops_its_step_from_running() {
    let runtime = TracedRuntime::default();
    let mut cursor = TracingCursor::new(Arc::clone(&runtime.trace), Some(2));
    let plan = plan(
        vec![write_object("sha:art"), spawn_core(), stop_core()],
        vec![stop_core()],
    );

    let execution = execute_effect_plan_with_cursor(
        &plan,
        &pending_journal(),
        &runtime,
        &ExecutionPolicy::default(),
        &mut cursor,
    );

    assert_eq!(
        runtime.trace(),
        vec![
            "exec Prepare".to_owned(),
            "intent 1 (Cutover)".to_owned(),
            "exec Cutover".to_owned(),
            "intent 2 (Cutover)".to_owned(),
            "compensate Cutover".to_owned(),
        ],
        "the refused step must not reach the runtime -- nothing else makes this a guard"
    );
    assert_eq!(
        execution.applied_count(),
        2,
        "prepare and the announced step"
    );
    let skipped = execution
        .steps
        .iter()
        .find(|step| step.skipped())
        .expect("the halted step is recorded as a skip, not as a failure the host reported");
    assert_eq!(
        skipped.outcome,
        StepOutcome::Skipped {
            skip: StepSkip::Gate {
                reason: "journal-intent-refused"
            }
        },
        "{skipped:?}"
    );
    assert!(
        matches!(
            execution.status,
            ExecutionStatus::RolledBack { failed_at: 2, .. }
        ),
        "the window had already opened, so this is a rollback, not a clean pre-cutover halt: {:?}",
        execution.status
    );
    assert_eq!(
        execution.compensations.len(),
        1,
        "and the compensation path ran for the one step that had applied"
    );
}

/// The other side of the same rule: when the *first* record of the window is what the store refused,
/// nothing was touched, so the answer must be `FailedBeforeCutover` and no compensation may run.
#[test]
fn a_refused_first_intent_halts_before_the_window_opens() {
    let runtime = TracedRuntime::default();
    let mut cursor = TracingCursor::new(Arc::clone(&runtime.trace), Some(1));
    let plan = plan(
        vec![write_object("sha:art"), spawn_core(), stop_core()],
        vec![stop_core()],
    );

    let execution = execute_effect_plan_with_cursor(
        &plan,
        &pending_journal(),
        &runtime,
        &ExecutionPolicy::default(),
        &mut cursor,
    );

    assert_eq!(
        runtime.trace(),
        vec!["exec Prepare".to_owned(), "intent 1 (Cutover)".to_owned()],
        "the run stopped at the window's edge: prepare got as far as it is allowed to"
    );
    assert!(
        matches!(
            execution.status,
            ExecutionStatus::FailedBeforeCutover { failed_at: 1, .. }
        ),
        "{:?}",
        execution.status
    );
    assert!(!execution.cutover_started && !execution.net_effect_started);
    assert!(
        execution.compensations.is_empty(),
        "nothing to undo, and an unwind of a step that never ran would be a lie"
    );
}

/// `execute_effect_plan` keeps its exact pre-guard behaviour, which is what lets the simulation
/// harnesses stay untouched -- and the equivalence is what proves the guard is *added*, not woven in.
#[test]
fn a_run_with_no_cursor_is_the_run_there_was_before() {
    let plan = plan(vec![write_object("sha:art"), spawn_core()], Vec::new());
    let without = execute_effect_plan(
        &plan,
        &pending_journal(),
        &caly_engine::SimulatedRuntime::new(),
        &ExecutionPolicy::default(),
    );
    let with_nothing = execute_effect_plan_with_cursor(
        &plan,
        &pending_journal(),
        &caly_engine::SimulatedRuntime::new(),
        &ExecutionPolicy::default(),
        &mut NoCursor,
    );
    assert_eq!(without, with_nothing);
    assert_eq!(without.steps.len(), 2);
}

// ---------------------------------------------------------------- worker level

/// The point of the whole round: on a *successful* apply the store holds the cutover evidence while
/// the window is open, not only after it closes -- exactly one intent write per cutover step, and
/// each one ahead of the fold that finishes the record.
#[test]
fn a_real_apply_writes_the_cutover_window_into_the_store_as_it_goes() {
    let spy = Arc::new(JournalSpy::new());
    let handle = EngineHandle::with_backend(EngineState::new(), spy.clone());
    let result = drain(&handle);
    assert_eq!(result.outcome, JobOutcome::Succeeded, "{result:?}");

    let workflow = plan_apply_request(ApplyRequest {
        profile_id: ProfileId("demo-tun-profile".to_owned()),
        dry_run: false,
        strict: false,
    })
    .expect("plan");
    let plan = workflow.effect_plan.expect("an effect plan");
    let cutover = cutover_indices(&plan);
    assert_eq!(
        cutover.len(),
        2,
        "the fixture's window; see the file header"
    );

    let writes = spy.writes();
    let intents: Vec<&ApplyJournalRecord> = writes
        .iter()
        .filter(|record| {
            record.current_phase == caly_storage::ApplyPhase::Cutover
                && record.state == ApplyJournalState::Pending
        })
        .collect();
    assert_eq!(
        intents.len(),
        cutover.len(),
        "exactly one intent record per cutover step -- the next intent subsumes the previous \
         progress, so a second write per step is waste, not safety: {writes:?}"
    );
    let cursors: Vec<usize> = intents
        .iter()
        .map(|record| record.current_step_index)
        .collect();
    assert_eq!(
        cursors, cutover,
        "the cursor of an intent record is the step about to start"
    );
    for record in &intents {
        assert!(
            record.core_cutover_started && record.net_effect_started,
            "the record that opens the window must say the window is open: {record:?}"
        );
    }

    // Ordering, measured on the store's own sequence: the first intent is written *before* the fold.
    let first_intent = writes
        .iter()
        .position(|record| record.current_phase == caly_storage::ApplyPhase::Cutover)
        .expect("a cutover record");
    let last = writes.len() - 1;
    assert!(
        first_intent < last,
        "the intent must not be the last word about the window: {writes:?}"
    );
    assert_eq!(
        writes[first_intent - 1].state,
        ApplyJournalState::Pending,
        "the record before the window is the pending journal, which said nothing was touched"
    );
    assert!(!writes[first_intent - 1].core_cutover_started);
    assert_eq!(
        writes[last].state,
        ApplyJournalState::Committed,
        "and the run still ends where it used to"
    );
    assert!(
        writes[first_intent].updated_at_unix_ms <= writes[last].updated_at_unix_ms,
        "the cursor's timestamps must not run backwards across the guard boundary: {:?}",
        writes
            .iter()
            .map(|record| record.updated_at_unix_ms)
            .collect::<Vec<_>>()
    );
}

/// The dangerous seam, and the reason `§6.2` exists: the journal refused the record, so the step must
/// not run *and* the surviving record must tell the truth about it.
#[test]
fn a_journal_that_refuses_the_record_costs_the_world_nothing() {
    let spy = Arc::new(JournalSpy::new());
    spy.arm(2);
    let handle = EngineHandle::with_backend(EngineState::new(), spy.clone());
    let result = drain(&handle);
    assert_eq!(result.outcome, JobOutcome::Failed, "{result:?}");

    let failure = failure_of(&handle, result.job_id);
    assert_eq!(failure.code, ErrorCode::Storage, "{failure:?}");
    assert!(
        failure
            .summary
            .contains("the apply journal refused the intent record"),
        "{}",
        failure.summary
    );
    assert!(
        failure
            .detail
            .as_deref()
            .unwrap_or_default()
            .contains("apply journal is busy (injected)"),
        "the store's own words have to reach the caller: {:?}",
        failure.detail
    );
    assert!(
        failure
            .remediation
            .as_deref()
            .unwrap_or_default()
            .contains("restore write access to the apply journal"),
        "{:?}",
        failure.remediation
    );

    let writes = spy.writes();
    // 1 = the pending journal; the armed write (2) was the first intent, and the post-halt fold is
    // (3). The fold is allowed, because refusing to record what happened is the one thing a refusal
    // may never cause.
    assert_eq!(writes.len(), 2, "{writes:?}");
    let final_record = writes.last().expect("the fold landed");
    assert!(
        !final_record.core_cutover_started,
        "nothing outside the store changed, and the record says exactly that: {final_record:?}"
    );
    assert_eq!(final_record.state, ApplyJournalState::Abandoned);
    assert!(
        handle
            .latest_last_known_good_snapshot()
            .expect("lkg read")
            .is_none(),
        "a halted apply may not publish a snapshot"
    );
}

/// `OVERLOAD_AND_RETRY_MODEL §7.2`: the caller's error is transient, so the operator's half has to be
/// written down as well -- and `§6.2`'s first sentence ("不得简单提示稍后再试就结束") is discharged by
/// the hint, not by prose.
#[test]
fn the_refused_record_shows_up_as_storage_pressure_for_the_operator() {
    let spy = Arc::new(JournalSpy::new());
    spy.arm(2);
    let handle = EngineHandle::with_backend(EngineState::new(), spy);
    let result = drain(&handle);
    assert_eq!(result.outcome, JobOutcome::Failed);

    let lines = handle.overload_lines().expect("overload lines");
    assert_eq!(
        lines
            .iter()
            .filter(|line| line.starts_with("overload storage_busy:"))
            .count(),
        1,
        "one class, one line: {lines:?}"
    );
    let line = lines
        .iter()
        .find(|line| line.starts_with("overload storage_busy:"))
        .expect("the mid-apply refusal must be tallied");
    assert!(line.contains("1 occurrence(s)"), "{line}");
    assert!(line.contains("ManualIntervention"), "{line}");
    assert!(
        line.contains("the apply journal refused the cutover intent record"),
        "{line}"
    );
    // The public error carries the *same* class and hint, from the same formatter (`§4.59`'s one
    // spelling), so a caller and an operator cannot be told two different stories about one event.
    let failure = failure_of(&handle, result.job_id);
    let detail = failure.detail.unwrap_or_default();
    assert!(detail.contains("error=storage_busy"), "{detail}");
    assert!(detail.contains("retry_hint=ManualIntervention"), "{detail}");
    let events = handle
        .follow_job(JobId(result.job_id))
        .expect("follow")
        .job
        .expect("job")
        .events;
    assert!(
        events.iter().any(|event| matches!(
            event,
            caly_engine::JobEvent::Warning { message } if message.contains("cutover guard")
        )),
        "job follow has to see an execution-stage halt, not only a code: {events:?}"
    );
}

/// One command, one spent-budget counter -- across the persistence seam *and* the guard. The plan's
/// first intent is unbilled on purpose (it is the write that records the window opening), so with a
/// budget of 1 the artifact write spends it and the *second* intent is what gets refused. A fresh
/// `RunLimits` per seam would let both intents through and this assertion would be the one that says
/// so.
#[test]
fn the_callers_budget_bounds_the_cutover_window_too() {
    let spy = Arc::new(JournalSpy::new());
    let handle = EngineHandle::with_backend(EngineState::new(), spy.clone());
    let result = drain_with_budget(&handle, Some(1));
    assert_eq!(result.outcome, JobOutcome::Failed, "{result:?}");

    let failure = failure_of(&handle, result.job_id);
    assert_eq!(failure.code, ErrorCode::ConfigInvalid, "{failure:?}");
    assert!(
        failure
            .summary
            .contains("apply stopped before a cutover step"),
        "{}",
        failure.summary
    );
    let detail = failure.detail.unwrap_or_default();
    assert!(detail.contains("budget=1/1"), "{detail}");
    assert!(
        detail.contains("io budget allows 1 accounted store access"),
        "{detail}"
    );

    let intents = spy
        .writes()
        .iter()
        .filter(|record| {
            record.current_phase == caly_storage::ApplyPhase::Cutover
                && record.state == ApplyJournalState::Pending
        })
        .count();
    assert_eq!(
        intents, 1,
        "the first intent landed (it records the window, so it may not be refused); the second \
         was refused by the shared counter"
    );
    // A budget refusal is not system pressure, and must not inflate the tally (`§3.7`).
    let lines = handle.overload_lines().expect("overload lines");
    assert!(
        !lines
            .iter()
            .any(|line| line.starts_with("overload storage_busy:")),
        "{lines:?}"
    );
}

/// The store's `Busy` is the one answer that gets promoted, and the promotion is what the operator's
/// tally depends on: an integrity violation must not look like congestion.
#[test]
fn only_a_busy_journal_counts_as_pressure_on_the_operator() {
    // Same refusal shape as above, but the store's error kind is not `Busy`: `IntegrityViolation`
    // comes from a corrupt record, and `doctor` must not count it as capacity.
    #[derive(Default)]
    struct BrokenJournal {
        inner: InMemoryStorage,
    }
    impl StorageBackend for BrokenJournal {}
    impl JobLogStore for BrokenJournal {
        fn put_job_log<'a>(
            &'a self,
            record: caly_storage::job_log::JobLogRecord,
            ctx: &'a caly_io::IoContext,
        ) -> caly_storage::BoxFuture<'a, Result<(), caly_storage::StorageError>> {
            self.inner.put_job_log(record, ctx)
        }
        fn get_job_log<'a>(
            &'a self,
            job_id: &'a str,
            ctx: &'a caly_io::IoContext,
        ) -> caly_storage::BoxFuture<
            'a,
            Result<Option<caly_storage::job_log::JobLogRecord>, caly_storage::StorageError>,
        > {
            self.inner.get_job_log(job_id, ctx)
        }
        fn list_job_logs<'a>(
            &'a self,
            ctx: &'a caly_io::IoContext,
        ) -> caly_storage::BoxFuture<
            'a,
            Result<Vec<caly_storage::job_log::JobLogRecord>, caly_storage::StorageError>,
        > {
            self.inner.list_job_logs(ctx)
        }
    }

    impl ObjectStore for BrokenJournal {
        fn put<'a>(
            &'a self,
            intent: CasWriteIntent,
            ctx: &'a IoContext,
        ) -> BoxFuture<'a, Result<CasObjectRef, StorageError>> {
            self.inner.put(intent, ctx)
        }
        fn get<'a>(
            &'a self,
            digest: &'a str,
            ctx: &'a IoContext,
        ) -> BoxFuture<'a, Result<Option<CasObjectRef>, StorageError>> {
            self.inner.get(digest, ctx)
        }
        fn materialize<'a>(
            &'a self,
            request: MaterializationRequest,
            ctx: &'a IoContext,
        ) -> BoxFuture<'a, Result<(), StorageError>> {
            self.inner.materialize(request, ctx)
        }
        fn list_objects<'a>(
            &'a self,
            ctx: &'a IoContext,
        ) -> BoxFuture<'a, Result<Vec<CasObjectRef>, StorageError>> {
            self.inner.list_objects(ctx)
        }
        fn delete<'a>(
            &'a self,
            digest: &'a str,
            ctx: &'a IoContext,
        ) -> BoxFuture<'a, Result<bool, StorageError>> {
            self.inner.delete(digest, ctx)
        }
    }
    impl RevisionStore for BrokenJournal {
        fn put_revision<'a>(
            &'a self,
            record: RevisionRecord,
            ctx: &'a IoContext,
        ) -> BoxFuture<'a, Result<(), StorageError>> {
            self.inner.put_revision(record, ctx)
        }
        fn get_revision<'a>(
            &'a self,
            revision_id: &'a RevisionId,
            ctx: &'a IoContext,
        ) -> BoxFuture<'a, Result<Option<RevisionRecord>, StorageError>> {
            self.inner.get_revision(revision_id, ctx)
        }
    }
    impl SnapshotStore for BrokenJournal {
        fn put_snapshot<'a>(
            &'a self,
            record: SnapshotRecord,
            ctx: &'a IoContext,
        ) -> BoxFuture<'a, Result<(), StorageError>> {
            self.inner.put_snapshot(record, ctx)
        }
        fn get_snapshot<'a>(
            &'a self,
            snapshot_id: &'a SnapshotRecordId,
            ctx: &'a IoContext,
        ) -> BoxFuture<'a, Result<Option<SnapshotRecord>, StorageError>> {
            self.inner.get_snapshot(snapshot_id, ctx)
        }
        fn latest_last_known_good<'a>(
            &'a self,
            ctx: &'a IoContext,
        ) -> BoxFuture<'a, Result<Option<SnapshotRecord>, StorageError>> {
            self.inner.latest_last_known_good(ctx)
        }
    }
    impl JournalStore for BrokenJournal {
        fn put_journal<'a>(
            &'a self,
            record: JournalRecord,
            ctx: &'a IoContext,
        ) -> BoxFuture<'a, Result<(), StorageError>> {
            self.inner.put_journal(record, ctx)
        }
        fn get_journal<'a>(
            &'a self,
            journal_id: &'a JournalRecordId,
            ctx: &'a IoContext,
        ) -> BoxFuture<'a, Result<Option<JournalRecord>, StorageError>> {
            self.inner.get_journal(journal_id, ctx)
        }
        fn list_pending<'a>(
            &'a self,
            ctx: &'a IoContext,
        ) -> BoxFuture<'a, Result<Vec<JournalRecord>, StorageError>> {
            self.inner.list_pending(ctx)
        }
    }
    impl ApplyJournalStore for BrokenJournal {
        fn put_apply_journal<'a>(
            &'a self,
            record: ApplyJournalRecord,
            _ctx: &'a IoContext,
        ) -> BoxFuture<'a, Result<(), StorageError>> {
            // Refuse every journal write, the way a corrupt record does.
            let _ = record;
            Box::pin(async move {
                Err(StorageError::new(
                    StorageErrorKind::IntegrityViolation,
                    "apply journal record does not verify (injected)",
                ))
            })
        }
        fn get_apply_journal<'a>(
            &'a self,
            apply_txn_id: &'a ApplyTxnId,
            ctx: &'a IoContext,
        ) -> BoxFuture<'a, Result<Option<ApplyJournalRecord>, StorageError>> {
            self.inner.get_apply_journal(apply_txn_id, ctx)
        }
        fn list_pending_apply<'a>(
            &'a self,
            ctx: &'a IoContext,
        ) -> BoxFuture<'a, Result<Vec<ApplyJournalRecord>, StorageError>> {
            self.inner.list_pending_apply(ctx)
        }
        fn list_unresolved_apply<'a>(
            &'a self,
            ctx: &'a IoContext,
        ) -> BoxFuture<'a, Result<Vec<ApplyJournalRecord>, StorageError>> {
            self.inner.list_unresolved_apply(ctx)
        }
    }

    let handle = EngineHandle::with_backend(EngineState::new(), Arc::new(BrokenJournal::default()));
    let result = drain(&handle);
    assert_eq!(result.outcome, JobOutcome::Failed, "{result:?}");
    let lines = handle.overload_lines().expect("overload lines");
    assert!(
        lines
            .iter()
            .all(|line| !line.starts_with("overload storage_busy:")),
        "a corrupt record is not congestion: {lines:?}"
    );
    // ...and it is refused before the window opens, because it is `begin_apply_persistence` that
    // cannot write -- which is the same answer the guard gives when it is the store that says no.
    let failure = failure_of(&handle, result.job_id);
    assert_eq!(failure.code, ErrorCode::Storage, "{failure:?}");
    assert!(
        !failure.summary.contains("refused the intent record"),
        "{}",
        failure.summary
    );
}

/// A clock that steps on every reading, i.e. the scripted version of "time passed while the store was
/// being asked". A real clock would make this test depend on the machine, and `ADR-022` is exactly
/// about not doing that.
#[derive(Default)]
struct Stepping {
    ticks: std::sync::atomic::AtomicU64,
}

impl caly_engine::Clock for Stepping {
    fn now(&self) -> caly_io::Timestamp {
        caly_io::Timestamp {
            unix_millis: self.ticks.load(std::sync::atomic::Ordering::Relaxed) as i64,
        }
    }

    fn mono(&self) -> caly_io::Monotonic {
        caly_io::Monotonic {
            ticks_millis: self
                .ticks
                .fetch_add(1, std::sync::atomic::Ordering::Relaxed),
        }
    }

    fn sleep_until<'a>(
        &'a self,
        _at: caly_io::Monotonic,
    ) -> caly_io::BoxFuture<'a, Result<(), caly_io::IoFault>> {
        Box::pin(async { Ok(()) })
    }
}

/// The window must be stoppable, and stopping it must be reported as *the caller giving up*, not as a
/// broken deployment: `RFC-0006 §5.2`'s distinction has to survive all the way to the job record, and
/// a refusal that arrives mid-window is the first place where it could have been flattened.
///
/// The arithmetic is measured, not remembered: `RunLimits::for_command` reads the clock once to anchor
/// (0), `begin_apply_persistence`'s drive check reads it again (1), and the second intent's check reads
/// it a third time (2). A deadline of 2 therefore passes the artifact write and expires exactly at the
/// window's second step -- which is the step whose record is *refusable* (the first one is not: it is
/// the record that says the world may have changed, `ADR-036 §6bis-quinque`).
#[test]
fn an_expired_deadline_stops_the_window_and_the_job_says_so() {
    let spy = Arc::new(JournalSpy::new());
    let handle = EngineHandle::with_backend(EngineState::new(), spy.clone());
    handle
        .set_storage_clock(Some(Arc::new(Stepping::default())))
        .expect("clock injected");

    let mut command = apply_command(None);
    command.context.deadline_mono_ms = Some(2);
    handle.submit(command).expect("submit");
    let result = handle
        .drain_with_policy(caly_engine::WorkerPolicy::bounded(1))
        .expect("drain")
        .results
        .into_iter()
        .next()
        .expect("one cycle");
    assert_eq!(
        result.outcome,
        JobOutcome::TimedOut,
        "a caller whose time ran out must not be recorded as a broken deployment: {result:?}"
    );

    let failure = failure_of(&handle, result.job_id);
    assert!(
        failure
            .summary
            .contains("apply stopped before a cutover step"),
        "{}",
        failure.summary
    );
    assert!(
        failure
            .remediation
            .as_deref()
            .unwrap_or_default()
            .contains("longer Ctx::deadline_ms"),
        "{:?}",
        failure.remediation
    );
    assert!(
        failure
            .detail
            .as_deref()
            .unwrap_or_default()
            .contains("deadline at mono 2 expired"),
        "{:?}",
        failure.detail
    );

    let intents = spy
        .writes()
        .iter()
        .filter(|record| {
            record.current_phase == caly_storage::ApplyPhase::Cutover
                && record.state == ApplyJournalState::Pending
        })
        .count();
    assert_eq!(
        intents, 1,
        "the record that opens the window landed; only the next one was refused"
    );
    let lines = handle.overload_lines().expect("overload lines");
    assert!(
        !lines.iter().any(|line| line.starts_with("overload storage_busy:")),
        "the caller's own clock is not system pressure (`OVERLOAD_AND_RETRY_MODEL §3.7`): {lines:?}"
    );
}
