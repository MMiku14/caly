//! The support bundle: what it must contain, and what it must not.
//!
//! `docs/STORAGE_RECOVERY_EXECUTION_PLAN.md §9.3` promised an export carrying recent apply journal
//! summaries, active-snapshot metadata, last-known-good metadata and a recovery incident summary.
//! `RFC-0010 §12.2` adds version information, a capability summary, redacted logs, a redacted apply
//! report and resource statistics; `§12.3` forbids full subscription URLs, node passwords and API
//! tokens. `DiagnosticsOp::SupportBundle` used to answer all of that with one job log line reading
//! "support bundle skeleton generated".
//!
//! These tests run the real command path — submit, drain, then read the bytes out of the store the
//! job wrote to — because an export that only exists in the return value of a function nobody calls
//! is not an export.

use std::sync::Arc;

use caly_api::{ApplyRequest, JobId, ProfileId};
use caly_common::redact::{Redactor, REDACTED};
use caly_common::{Actor, RequestContext, TraceId};
use caly_engine::{
    command::{Command, CommandId, CommandKind},
    plan_apply_request, BundleIdentity, EngineHandle, EngineState, JobEvent, JobOutcome, RunLimits,
    WorkerPolicy, BUNDLE_SECTIONS,
};
use caly_storage::{InMemoryStorage, ObjectKind, StorageBackend};

fn command(kind: CommandKind, tag: &str) -> Command {
    Command {
        id: CommandId(format!("cmd-{tag}")),
        request_id: None,
        actor: Actor::Cli,
        context: RequestContext::new(TraceId::new(format!("trace-{tag}")), Actor::Cli),
        timeout_ms: None,
        idempotency_key: None,
        kind,
    }
}

fn drain(handle: &EngineHandle, command: Command) -> caly_engine::WorkerCycleResult {
    handle.submit(command).expect("submit accepted");
    handle
        .drain_with_policy(WorkerPolicy::bounded(1))
        .expect("drain")
        .results
        .into_iter()
        .next()
        .expect("one cycle")
}

/// `OVERLOAD_AND_RETRY_MODEL §7.2` wants backlog length and queue cap on the diagnostics outlet, and
/// `§10 Stage 3` names the support bundle as a consumer. An empty log must still be stated: a missing
/// section reads as "the collector did not run", which is the `§4.19` failure shape again.
#[test]
fn refusals_are_reported_in_the_bundle_and_their_absence_is_stated_too() {
    let (handle, _store) = engine();
    let draft = caly_engine::collect_bundle_draft(&handle).expect("draft");
    let text = draft.render();
    assert!(
        text.contains("queue 0/256 retained_refusals=0"),
        "the bundle must report the queue it saw:\n{text}"
    );
    assert!(
        text.contains("no overload refusal recorded"),
        "an empty refusal log has to say so:\n{text}"
    );

    // Fill the queue (capacity 256) so the next submit is refused, then re-collect.
    let mut refused = 0usize;
    for index in 0..300 {
        let command = command(
            CommandKind::ProxyTestDelay {
                node_ids: vec![format!("node-{index}")],
            },
            &format!("flood-{index}"),
        );
        if handle.submit(command).is_err() {
            refused += 1;
        }
    }
    assert!(refused > 0, "the flood must actually overflow the queue");
    let draft = caly_engine::collect_bundle_draft(&handle).expect("draft after refusals");
    let text = draft.render();
    assert!(
        text.contains(&format!(
            "retained_refusals={}",
            EngineState::RECENT_OVERLOADS
        )),
        "the section must bound its own window:\n{text}"
    );
    assert!(
        text.contains(&format!("overload queue_full: {refused} occurrence(s)")),
        "the count is the total, not the window:\n{text}"
    );
    assert!(
        text.contains("hint RetryLater"),
        "the hint belongs on the operator outlet too:\n{text}"
    );
    assert!(
        !text.contains("no overload refusal recorded"),
        "the empty-log line must disappear once there is something to report"
    );
}

fn bundle_command() -> Command {
    command(CommandKind::DiagnosticsBundle, "bundle")
}

fn apply_command(profile_id: &str) -> Command {
    command(
        CommandKind::ProfileApply(ApplyRequest {
            profile_id: ProfileId(profile_id.to_owned()),
            dry_run: false,
            strict: false,
        }),
        "apply",
    )
}

/// An engine plus the store it is attached to, so a test can read what was actually written.
fn engine() -> (EngineHandle, InMemoryStorage) {
    let store = InMemoryStorage::new();
    let handle = EngineHandle::with_backend(
        EngineState::new(),
        Arc::new(store.clone()) as Arc<dyn StorageBackend>,
    );
    handle
        .set_bundle_identity(BundleIdentity::new(
            "inst-test",
            "calyd",
            "0.1.0-dev",
            "v1.0",
        ))
        .expect("identity recorded");
    (handle, store)
}

/// The bundle a drained `DiagnosticsBundle` job wrote into the store.
fn written_bundle(store: &InMemoryStorage) -> (String, String) {
    let digest = store
        .object_digests()
        .into_iter()
        .find(|digest| {
            store
                .stored(digest)
                .map(|object| object.meta.kind == ObjectKind::SupportBundle)
                .unwrap_or(false)
        })
        .expect("a support bundle object must have been stored");
    let stored = store.stored(&digest).expect("the object must have content");
    (
        digest,
        String::from_utf8(stored.payload).expect("the bundle is text"),
    )
}

#[test]
fn the_bundle_carries_every_section_the_docs_require() {
    let (handle, store) = engine();
    assert_eq!(
        drain(&handle, apply_command("demo-tun-profile")).outcome,
        JobOutcome::Succeeded
    );
    let result = drain(&handle, bundle_command());
    assert_eq!(result.outcome, JobOutcome::Succeeded);

    let (_digest, text) = written_bundle(&store);
    let mut positions = Vec::new();
    for name in BUNDLE_SECTIONS {
        let marker = format!("== section: {name}\n");
        let at = text
            .find(&marker)
            .unwrap_or_else(|| panic!("section {name} missing from:\n{text}"));
        positions.push(at);
    }
    // Order matters for a human reading a terminal scrollback: the const list is the contract.
    assert!(
        positions.windows(2).all(|pair| pair[0] < pair[1]),
        "sections must render in declaration order: {positions:?}"
    );
    assert!(text.contains("# caly support bundle"), "{text}");
    assert!(text.contains("# redaction=strict"), "{text}");
}

#[test]
fn the_bundle_reports_the_deployment_the_store_remembers() {
    let (handle, store) = engine();
    drain(&handle, apply_command("demo-tun-profile"));
    drain(&handle, bundle_command());
    let (_digest, text) = written_bundle(&store);

    // §9.3 item 1: recent apply journal summaries. A committed transaction is exactly what
    // `list_pending_apply` cannot see, which is why that enumeration hook had to be added.
    assert!(text.contains("== section: apply-journals"), "{text}");
    assert!(text.contains("state=committed"), "{text}");
    assert!(text.contains("total=1 shown=1"), "{text}");

    // §9.3 items 2 and 3: active snapshot and last-known-good metadata.
    assert!(text.contains("last-known-good id="), "{text}");
    assert!(text.contains("lkg=true"), "{text}");

    // §9.3 item 4: the recovery incident summary.
    assert!(text.contains("unresolved_apply=0"), "{text}");
    assert!(text.contains("no recovery decisions outstanding"), "{text}");

    // §12.2: version information, capability summary, apply report, resource statistics.
    assert!(text.contains("caly="), "{text}");
    assert!(
        text.contains("daemon=calyd version=0.1.0-dev protocol=v1.0"),
        "{text}"
    );
    assert!(text.contains("last-evaluated required="), "{text}");
    assert!(text.contains("step 0 write-object"), "{text}");
    assert!(text.contains("objects="), "{text}");
    assert!(text.contains("storage audit: schema="), "{text}");
}

#[test]
fn the_bundle_is_stored_content_addressed_and_reported_on_the_job() {
    let (handle, store) = engine();
    drain(&handle, bundle_command());
    let (digest, text) = written_bundle(&store);

    // The digest in the object key must be the digest of the bytes, or "content addressed" is a
    // name only: `RFC-0007 §6.2-6.3` is what makes the export verifiable by someone else.
    let anchor = caly_common::digest::sha256_digest(text.as_bytes());
    assert_eq!(digest, anchor, "object key must be the content digest");
    let stored = store.stored(&digest).expect("stored bundle");
    assert_eq!(stored.meta.content_sha256.as_deref(), Some(anchor.as_str()));
    assert_eq!(stored.meta.size_bytes, Some(text.len() as u64));
    assert_eq!(
        stored.meta.content_type.as_deref(),
        Some(caly_engine::BUNDLE_CONTENT_TYPE)
    );

    // The operator-facing handle is the digest, reported on the job.
    let events = handle
        .follow_job(JobId(1))
        .expect("follow")
        .job
        .expect("job")
        .events;
    assert!(
        events.iter().any(
            |event| matches!(event, JobEvent::Log { message, .. } if message.contains(&digest))
        ),
        "the job must report where the bundle went: {events:?}"
    );
    // The commit marker closes the job, and it is what a follow projection surfaces as `last_stage`.
    let committed_before_log = events
        .iter()
        .map(|event| match event {
            JobEvent::Stage { stage, pct } => format!("{stage}@{:?}", pct.map(|pct| pct as usize)),
            JobEvent::Log { .. } => "<log>".to_owned(),
            other => format!("{other:?}"),
        })
        .collect::<Vec<_>>();
    let committed = committed_before_log
        .iter()
        .position(|line| line == "bundle.committed@Some(100)")
        .unwrap_or_else(|| panic!("no commit stage in {committed_before_log:?}"));
    let logged = committed_before_log
        .iter()
        .position(|line| line == "<log>")
        .unwrap_or_else(|| panic!("no log line in {committed_before_log:?}"));
    assert!(
        logged < committed,
        "the digest is reported before the job commits"
    );
}

#[test]
fn an_export_never_carries_a_plaintext_secret() {
    // `RFC-0010 §14.3`. The node id is user input that the worker echoes into a job log line, and
    // the bundle collects those lines — so this is the real path a credential takes, not a fixture
    // written to be caught.
    let (handle, store) = engine();
    handle
        .register_secret("OPAQUETOKEN42")
        .expect("secret registered");

    drain(
        &handle,
        command(
            CommandKind::ProxyTestDelay {
                node_ids: vec![
                    "hk?token=URLTOKENVALUE".to_owned(),
                    "https://host/OPAQUETOKEN42".to_owned(),
                ],
            },
            "echo",
        ),
    );
    drain(&handle, bundle_command());
    let (_digest, text) = written_bundle(&store);

    assert!(!text.contains("URLTOKENVALUE"), "pattern leak:\n{text}");
    assert!(!text.contains("OPAQUETOKEN42"), "literal leak:\n{text}");
    assert!(text.contains(REDACTED), "expected masking in:\n{text}");
    // The line itself must still be readable: masking is not deletion.
    assert!(text.contains("delay test requested for nodes="), "{text}");
    assert!(!Redactor::strict().exposes_sensitive_text(&text), "{text}");
}

#[test]
fn job_events_are_masked_where_they_are_appended() {
    // `RFC-0010 §6.1` puts a redaction boundary at log-line construction. The engine's only writer
    // of job events is `append_job_event`, so the guarantee has to hold there — every reader
    // (follow, stream, bundle) then inherits it instead of remembering to mask.
    let (handle, _store) = engine();
    let accepted = handle
        .submit(command(CommandKind::DnsFlushCache, "dns"))
        .expect("accepted")
        .accepted;
    handle
        .append_job_event(
            accepted.job_id,
            JobEvent::Log {
                level: "info".to_owned(),
                message: "pulling https://sub.example.com/y?token=TOPSECRET".to_owned(),
            },
        )
        .expect("event appended");

    let events = handle
        .follow_job(accepted.job_id)
        .expect("follow")
        .job
        .expect("job")
        .events;
    let message = events
        .iter()
        .find_map(|event| match event {
            JobEvent::Log { message, .. } => Some(message.clone()),
            _ => None,
        })
        .expect("log event");
    assert!(!message.contains("TOPSECRET"), "{message}");
    assert!(message.contains(REDACTED), "{message}");

    // And it is idempotent, so masking a second time at another boundary is free.
    let once = Redactor::default().redact(&message);
    assert_eq!(once, message);
}

#[test]
fn the_bundle_names_an_unresolved_transaction_loudly() {
    // A journal left `Pending` is the crash-recovery entry point. `doctor` reports it, and the
    // bundle must say the same thing about the same store.
    let (handle, store) = engine();
    let workflow = plan_apply_request(ApplyRequest {
        profile_id: ProfileId("demo-tun-profile".to_owned()),
        dry_run: false,
        strict: false,
    })
    .expect("planning");
    handle
        .begin_apply_persistence(workflow.storage_projection.clone(), &RunLimits::immediate())
        .expect("journal begun");

    drain(&handle, bundle_command());
    let (_digest, text) = written_bundle(&store);

    assert!(text.contains("unresolved_apply=1"), "{text}");
    assert!(text.contains("state=pending"), "{text}");
    assert!(
        text.contains("dangling-pending-journal"),
        "the audit section must report the finding:\n{text}"
    );
}

#[test]
fn a_backend_that_cannot_answer_is_reported_as_such() {
    // `InMemoryStorage` records no schema marker, no rollback points and no materialization
    // tracking. The bundle has to say "not observable" there: an export that rendered "v0" or
    // "everything is fine" would be inventing a health report out of an absence of data.
    let (handle, store) = engine();
    drain(&handle, bundle_command());
    let (_digest, text) = written_bundle(&store);

    assert!(
        text.contains(
            "not-observable [info] schema-marker: this backend does not record a storage schema"
        ),
        "{text}"
    );
    assert!(text.contains("schema=unreadable"), "{text}");
    assert!(
        text.contains("no last-known-good snapshot"),
        "an empty store has no LKG, and that is stated: {text}"
    );
    // Not observable is not the same as broken: the findings that would need the missing data
    // (runtime presence, snapshot/object mismatch) are simply absent, and the audit says so by
    // reporting the counts it could read.
    assert!(!text.contains("snapshot-object-mismatch"), "{text}");
    assert!(!text.contains("abandoned-runtime"), "{text}");
    assert!(text.contains("clean [info] store: 0 object"), "{text}");
}

#[test]
fn a_bundle_without_a_deployment_says_so_rather_than_inventing_one() {
    let (handle, store) = engine();
    drain(&handle, bundle_command());
    let (_digest, text) = written_bundle(&store);

    assert!(
        text.contains("no effect plan has been executed in this generation"),
        "{text}"
    );
    assert!(
        text.contains("no apply has been evaluated in this engine generation"),
        "{text}"
    );
    assert!(text.contains("total=0 shown=0"), "{text}");
    assert!(text.contains("instance=inst-test"), "{text}");
}
