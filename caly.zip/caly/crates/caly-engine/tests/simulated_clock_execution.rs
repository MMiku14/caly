//! Bridge between the injected clock / port-level fault simulation (`caly-io-sim`) and the
//! effect executor.
//!
//! `ADR-022` requires a controllable clock, controllable fault injection and repeatable seeds
//! for the deployment path. `caly-io-sim` provided those primitives but nothing consumed them,
//! so the requirement was nominal. These tests make the centerline actually drive them.

use caly_api::{ApplyRequest, ProfileId};
use caly_engine::executor::{execute_effect_plan, journal_after_execution, ExecutionPolicy};
use caly_engine::plan_apply_request;
use caly_engine::sim_runtime::SimulatedRuntime;
use caly_io_sim::{SimWorld, VirtualClock, EFFECT_STEP_LABEL};

fn mihomo_plan() -> caly_plan::EffectPlan {
    plan_apply_request(ApplyRequest {
        profile_id: ProfileId("demo-tun-profile".to_owned()),
        dry_run: false,
        strict: false,
    })
    .expect("plan")
    .effect_plan
    .expect("effect plan")
}

fn pending_journal() -> caly_storage::ApplyJournalRecord {
    plan_apply_request(ApplyRequest {
        profile_id: ProfileId("demo-tun-profile".to_owned()),
        dry_run: false,
        strict: false,
    })
    .expect("plan")
    .storage_projection
    .apply_journal
}

#[test]
fn journal_time_comes_from_the_injected_clock_not_the_host() {
    let mut clock = VirtualClock::new(1_700_000_000_000);
    clock.advance_ms(250);
    clock.advance_ms(500);
    let started_at = clock.now().unix_millis;

    let policy = ExecutionPolicy {
        clock_start_unix_ms: started_at,
        clock_step_ms: 30,
        ..ExecutionPolicy::default()
    };

    let runtime = SimulatedRuntime::new();
    let plan = mihomo_plan();
    let journal = pending_journal();
    let execution = execute_effect_plan(&plan, &journal, &runtime, &policy);
    assert!(execution.succeeded(), "{:?}", execution.status);

    let settled = journal_after_execution(&journal, &execution, &policy);
    assert_eq!(settled.created_at_unix_ms, journal.created_at_unix_ms);
    assert_eq!(
        execution.clock_ticks(),
        plan.steps.len(),
        "a fully applied plan consumes one tick per step"
    );
    assert_eq!(
        settled.updated_at_unix_ms,
        started_at + (plan.steps.len() as i64) * 30,
        "the journal must record the injected virtual clock, not a host reading"
    );
    assert_eq!(
        settled.updated_at_unix_ms,
        policy.timestamp_at(execution.clock_ticks())
    );
    assert!(
        settled.updated_at_unix_ms >= started_at,
        "settled time cannot precede the start of the transaction"
    );
}

/// The two crash-injection entry points must mean the same thing, or a fault injected through
/// the IO ports would not correspond to the step the executor reports.
///
/// `SharedFaults::maybe_fail` advances its counter before matching, so a fault configured with
/// `trigger_after_step == N + 1` fires on the call that *precedes* executor step index `N`.
/// A crash-injected step and a gate-blocked step must not look the same to an operator:
/// one means "the simulation stopped the run", the other means "the executor refused to run
/// an unsafe step".
#[test]
fn injected_crash_and_gate_block_are_distinguishable() {
    use caly_engine::executor::{StepOutcome, StepSkip};

    let plan = mihomo_plan();
    let crash = execute_effect_plan(
        &plan,
        &pending_journal(),
        &caly_engine::sim_runtime::SimulatedRuntime::new(),
        &ExecutionPolicy {
            fail_after_step: Some(0),
            ..ExecutionPolicy::default()
        },
    );
    assert!(matches!(
        crash.steps[0].outcome,
        StepOutcome::Skipped {
            skip: StepSkip::CrashInjected
        }
    ));

    // A commit without a probe is a gate block on a *later* step, not a crash.
    let blocked = caly_engine::executor::execute_effect_plan(
        &{
            let mut truncated = plan.clone();
            truncated
                .steps
                .retain(|step| !matches!(step, caly_plan::EffectStep::Probe { .. }));
            truncated
        },
        &pending_journal(),
        &caly_engine::sim_runtime::SimulatedRuntime::new(),
        &ExecutionPolicy::default(),
    );
    let skipped = blocked
        .steps
        .iter()
        .find(|step| step.skipped())
        .expect("the gate must record a skipped step");
    assert!(matches!(
        skipped.outcome,
        StepOutcome::Skipped {
            skip: StepSkip::Gate {
                reason: "unverified-commit"
            }
        }
    ));
    assert!(!blocked.snapshot_marked);
}

#[test]
fn port_level_and_executor_level_crash_injection_agree() {
    let plan = mihomo_plan();
    let journal = pending_journal();

    for halt_at in 0..plan.steps.len() {
        let mut world = SimWorld::new(halt_at as u64);
        world.crash_after_effect_step(halt_at as u64 + 1);
        let faults = world.shared_faults();

        // Walk the plan the way a port-driven harness would: query the fault gate first, then
        // execute the step if no fault fired.
        let mut injected_halt_at: Option<usize> = None;
        for (index, _step) in plan.steps.iter().enumerate() {
            if faults.maybe_fail(EFFECT_STEP_LABEL).is_err() {
                injected_halt_at = Some(index);
                break;
            }
        }
        assert_eq!(
            injected_halt_at,
            Some(halt_at),
            "the fault gate must stop the run at step {halt_at}"
        );

        let runtime = SimulatedRuntime::new();
        let execution = execute_effect_plan(
            &plan,
            &journal,
            &runtime,
            &ExecutionPolicy {
                fail_after_step: Some(halt_at),
                ..ExecutionPolicy::default()
            },
        );
        assert_eq!(
            execution.cursor_step_index(),
            halt_at,
            "the executor must record the same halt index as the injected fault"
        );
        assert!(!execution.succeeded());
    }
}

#[test]
fn repeated_execution_reports_identical_evidence() {
    let plan = mihomo_plan();
    let journal = pending_journal();

    let first = execute_effect_plan(
        &plan,
        &journal,
        &SimulatedRuntime::new(),
        &ExecutionPolicy::default(),
    );
    let second = execute_effect_plan(
        &plan,
        &journal,
        &SimulatedRuntime::new(),
        &ExecutionPolicy::default(),
    );

    assert_eq!(first, second, "the same plan must produce the same report");
    assert_eq!(
        first
            .steps
            .iter()
            .map(|step| step.label.clone())
            .collect::<Vec<_>>(),
        second
            .steps
            .iter()
            .map(|step| step.label.clone())
            .collect::<Vec<_>>()
    );
    assert_eq!(
        first
            .steps
            .iter()
            .flat_map(|step| step.observations.clone())
            .collect::<Vec<_>>(),
        second
            .steps
            .iter()
            .flat_map(|step| step.observations.clone())
            .collect::<Vec<_>>()
    );
}

/// An identity probe must be able to *fail* an apply, per `RFC-0008`:
/// "config identity probe 可区分通过/失败/未知".
///
/// This uses a reload-shaped plan on purpose: a `Restart` plan spawns a fresh core from the
/// new artifact, so the identity it reports is by construction the new one. Only the hot
/// paths (reload / api patch) can leave a stale config live, which is exactly what the probe
/// exists to catch.
#[test]
fn stale_live_identity_blocks_a_reload_apply_before_commit() {
    use caly_plan::{
        BlobRef, CoreCall, DeployImpact, Durability, EffectPlan, EffectStep, FileMode, InstanceId,
        PlanId, PrivilegeSet, ProbeKind, ProbeSpec,
    };

    let digest = "sha256:planned-artifact".to_owned();
    let plan = EffectPlan {
        id: PlanId("plan-reload".to_owned()),
        steps: vec![
            EffectStep::WriteObject {
                digest: digest.clone(),
                source: BlobRef {
                    digest: digest.clone(),
                    size_hint: Some(64),
                },
                durability: Durability::D2,
            },
            EffectStep::MaterializeArtifact {
                digest: digest.clone(),
                at: "runtime/demo/config.yaml".to_owned(),
                mode: FileMode::ReadOnlyArtifact,
            },
            EffectStep::CoreApiCall {
                instance: InstanceId("mihomo-core-instance".to_owned()),
                call: CoreCall::Reload,
            },
            EffectStep::Probe {
                probe: ProbeSpec {
                    kind: ProbeKind::ConfigIdentity,
                    target: Some(digest.clone()),
                },
                deadline_ms: 1_000,
            },
            EffectStep::MarkSnapshot {
                snapshot_id: caly_plan::SnapshotId("snap-1".to_owned()),
            },
        ],
        compensations: vec![EffectStep::CoreApiCall {
            instance: InstanceId("mihomo-core-instance".to_owned()),
            call: CoreCall::Reload,
        }],
        requires: PrivilegeSet::default(),
        impact: DeployImpact::Reload,
    };

    let runtime = SimulatedRuntime::new();
    runtime.seed_core_identity("sha256:a-different-config".to_owned());

    let execution = execute_effect_plan(
        &plan,
        &pending_journal(),
        &runtime,
        &ExecutionPolicy::default(),
    );

    assert!(
        !execution.succeeded(),
        "a live core reporting a foreign identity must block the apply: {:?}",
        execution.status
    );
    assert!(
        !execution.snapshot_marked,
        "no snapshot may be marked after a failed identity probe"
    );
    assert!(
        matches!(
            execution.status,
            caly_engine::executor::ExecutionStatus::RolledBack { .. }
        ),
        "a reload that fails after cutover must roll back, got {:?}",
        execution.status
    );
    assert_eq!(execution.compensations.len(), 1);
    assert!(
        !execution.probe_passed,
        "the probe must not be recorded as passed"
    );

    let settled =
        journal_after_execution(&pending_journal(), &execution, &ExecutionPolicy::default());
    assert_eq!(settled.state, caly_storage::ApplyJournalState::Reverted);
}
