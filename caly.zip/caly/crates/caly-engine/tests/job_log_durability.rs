//! Terminal job logs survive a restart (`ADR-057` §5 slice 2).
//!
//! Slice 1 proved the storage primitive round-trips and reloads on a fresh `FsStore`. Slice 2 is
//! the engine half: when a job reaches a terminal state the engine writes its retained event
//! window to the durable store (D3), and a brand-new engine opened on the same backend restores
//! those jobs before serving traffic — so `jobs.list` / `jobs.events` answer after a `kill -9`.
//!
//! These tests drive the real engine over a simulated filesystem (the same `durable_centerline`
//! harness), never a mock of the persistence call: the assertion is that the record the *write*
//! path leaves on disk is the one the *restore* path reads back through a second engine instance.

use std::sync::Arc;

use caly_api::{ApplyRequest, ErrorCode, ProfileId};
use caly_common::{Actor, RequestContext, TraceId};
use caly_engine::{
    command::{Command, CommandId, CommandKind},
    EngineHandle, EngineState, JobEvent, JobOutcome, JobState, WorkerPolicy,
};
use caly_io::{block_on_ready, ByteCap, Fs, IoContext, VPath};
use caly_io_sim::{FaultInjector, MemFs, SharedFaults, SimFs};
use caly_storage::{fs_store::FsStore, StorageBackend};

const ROOT: &str = "var/caly";

fn disk() -> SimFs {
    SimFs::new(MemFs::default(), SharedFaults::new(FaultInjector::new(1)))
}

fn open(fs: SimFs) -> Arc<dyn StorageBackend> {
    Arc::new(FsStore::open(Box::new(fs), ROOT).expect("a fresh store opens"))
}

fn ctx() -> IoContext {
    IoContext::new(TraceId::new("job-log-durability"), Actor::System)
}

fn apply_command(tag: &str) -> Command {
    Command {
        id: CommandId(format!("cmd-{tag}")),
        request_id: None,
        actor: Actor::Cli,
        context: RequestContext::new(TraceId::new(format!("trace-{tag}")), Actor::Cli),
        timeout_ms: None,
        idempotency_key: None,
        kind: CommandKind::ProfileApply(ApplyRequest {
            profile_id: ProfileId(format!("profile-{tag}")),
            dry_run: false,
            strict: false,
        }),
    }
}

/// Drive one apply to a terminal state on the simulated runtime and return its job id.
fn run_one_to_completion(handle: &EngineHandle, tag: &str) -> u64 {
    handle.submit(apply_command(tag)).expect("submit accepted");
    let result = handle
        .drain_with_policy(WorkerPolicy::bounded(8))
        .expect("drain")
        .results
        .into_iter()
        .next()
        .expect("one cycle ran");
    assert_eq!(
        result.outcome,
        JobOutcome::Succeeded,
        "the simulated apply completes"
    );
    result.job_id
}

#[test]
fn a_completed_job_is_persisted_and_restored_into_a_fresh_engine() {
    let fs = disk();
    let job_id = {
        let handle = EngineHandle::with_backend(EngineState::new(), open(fs.clone()));
        let id = run_one_to_completion(&handle, "a");

        // The terminal record exists in the store this engine wrote to.
        let backend = handle.storage();
        let stored = block_on_ready(backend.list_job_logs(&ctx()))
            .expect("ready")
            .expect("list ok");
        assert!(
            stored.iter().any(|record| record.job_id == id.to_string()),
            "the completed job {id} has a durable terminal record: {stored:?}"
        );
        id
    };

    // A brand-new engine over the *same* backend restores the job before traffic.
    let reopened: Arc<dyn StorageBackend> =
        Arc::new(FsStore::open(Box::new(fs.clone()) as Box<dyn Fs>, ROOT).expect("reopen store"));
    let restored = EngineHandle::with_backend(EngineState::new(), reopened);
    let count = restored.restore_job_logs().expect("restore reads the logs");
    assert_eq!(count, 1, "exactly one terminal job is restored");

    let views = restored.list_job_views(64).expect("list after restart");
    assert_eq!(views.len(), 1, "jobs.list answers after a restart");
    assert_eq!(views[0].job_id.0, job_id);
    assert_eq!(views[0].state, "completed");

    // The follow projection answers with the retained event window and no reset.
    let projection = restored
        .project_job_follow(caly_api::JobId(job_id), None)
        .expect("project")
        .expect("the restored job projects");
    assert_eq!(projection.summary.state, "completed");
    assert!(!projection.window.expect("a window").events.is_empty());

    // A newly minted job id never collides with the restored id.
    let next = restored
        .submit(apply_command("b"))
        .expect("submit after restore")
        .accepted
        .job_id;
    assert!(
        next.0 > job_id,
        "the next job id {} must pass the restored id {job_id}",
        next.0
    );
}

#[test]
fn restored_jobs_remain_terminal_so_a_restart_does_not_replay_them() {
    let fs = disk();
    {
        let handle = EngineHandle::with_backend(EngineState::new(), open(fs.clone()));
        run_one_to_completion(&handle, "x");
    }
    let reopened: Arc<dyn StorageBackend> =
        Arc::new(FsStore::open(Box::new(fs) as Box<dyn Fs>, ROOT).expect("reopen store"));
    let restored = EngineHandle::with_backend(EngineState::new(), reopened);
    restored.restore_job_logs().expect("restore");

    // The restored record must come back in a terminal state, not running/queued — a job the
    // daemon saw finish must not be re-executed or reported as in-flight after a restart.
    let follow = restored.follow_job(caly_api::JobId(1)).expect("follow");
    let job = follow.job.expect("the job exists");
    assert!(
        matches!(
            job.state,
            JobState::Completed | JobState::Failed | JobState::Cancelled | JobState::TimedOut
        ),
        "restored state is terminal: {:?}",
        job.state
    );
}

#[test]
fn a_failed_job_restores_its_stable_failure_code_and_redacted_summary() {
    let fs = disk();
    {
        let handle = EngineHandle::with_backend(EngineState::new(), open(fs.clone()));
        handle
            .submit(apply_command("fail"))
            .expect("submit accepted");
        let queued = handle
            .poll_next()
            .expect("a queued command")
            .expect("queued");
        handle.mark_running(&queued).expect("running");
        // A failed terminal job carrying a stable public code.
        handle
            .append_job_event(
                queued.job_id,
                JobEvent::Failed {
                    error: caly_api::ApiError::for_code(
                        ErrorCode::Permission,
                        "role Viewer does not satisfy required role Admin",
                        TraceId::new("trace-fail"),
                    ),
                },
            )
            .expect("failed event");
        handle
            .mark_finished(&queued, JobOutcome::Failed)
            .expect("finished");
    }

    let reopened: Arc<dyn StorageBackend> =
        Arc::new(FsStore::open(Box::new(fs) as Box<dyn Fs>, ROOT).expect("reopen store"));
    let restored = EngineHandle::with_backend(EngineState::new(), reopened);
    restored.restore_job_logs().expect("restore");

    let views = restored.list_job_views(64).expect("list");
    let row = &views[0];
    assert_eq!(row.state, "failed");
    assert_eq!(
        row.failure_code.as_deref(),
        Some("PERMISSION"),
        "the stable code survives a restart so exit-code mapping still works: {row:?}"
    );
    assert!(
        row.failure_summary
            .as_deref()
            .is_some_and(|summary| summary.contains("role Viewer")),
        "the redacted summary survives: {:?}",
        row.failure_summary
    );
}

#[test]
fn the_durable_job_log_set_is_bounded_by_retention_and_keeps_the_newest_jobs() {
    use caly_engine::job_persistence::JOB_LOG_RETENTION;

    let fs = disk();
    let backend: Arc<dyn StorageBackend> = {
        let handle = EngineHandle::with_backend(EngineState::new(), open(fs.clone()));
        // Drive strictly more than the retention window of jobs to termination. Each terminal
        // write prunes, so the on-disk set never grows past JOB_LOG_RETENTION.
        let total = (JOB_LOG_RETENTION as u64) + 5;
        for index in 1..=total {
            handle
                .submit(apply_command(&format!("r{index}")))
                .expect("submit accepted");
            let queued = handle.poll_next().expect("queued").expect("a command");
            handle.mark_running(&queued).expect("running");
            // The job id minted for this submission is sequential and equals index.
            assert_eq!(
                queued.job_id.0, index,
                "sequential job ids drive the window"
            );
            handle
                .mark_finished(&queued, caly_engine::JobOutcome::Succeeded)
                .expect("finished + pruned");

            let stored = block_on_ready(backend_list(&handle.storage(), &ctx()))
                .expect("ready")
                .expect("list");
            assert!(
                stored.len() <= JOB_LOG_RETENTION,
                "after {index} jobs the durable set is bounded at {JOB_LOG_RETENTION}, got {}",
                stored.len()
            );
        }
        handle.storage()
    };

    // Reopen: exactly the newest JOB_LOG_RETENTION jobs survived; the oldest were reclaimed.
    let stored = block_on_ready(backend_list(&backend, &ctx()))
        .expect("ready")
        .expect("list");
    assert_eq!(
        stored.len(),
        JOB_LOG_RETENTION,
        "the set holds exactly the newest window"
    );
    // Newest first: the highest ids (last-written) are retained, job 1 is gone.
    let ids: Vec<u64> = stored
        .iter()
        .map(|record| record.job_id.parse::<u64>().expect("numeric id"))
        .collect();
    let newest = *ids.iter().max().expect("nonempty");
    assert_eq!(
        newest,
        (JOB_LOG_RETENTION as u64) + 5,
        "the last job survives"
    );
    assert!(
        !ids.contains(&1),
        "the oldest job was reclaimed past the window: {ids:?}"
    );
}

fn backend_list<'a>(
    backend: &'a Arc<dyn StorageBackend>,
    ctx: &'a IoContext,
) -> caly_storage::BoxFuture<
    'a,
    Result<Vec<caly_storage::job_log::JobLogRecord>, caly_storage::StorageError>,
> {
    backend.list_job_logs(ctx)
}

#[test]
fn a_corrupt_job_log_record_makes_restore_fail_like_any_other_untrusted_state() {
    let fs = disk();
    {
        let handle = EngineHandle::with_backend(EngineState::new(), open(fs.clone()));
        run_one_to_completion(&handle, "c");
    }
    // Forge an unknown field into the durable record, then reopen: restore must refuse rather than
    // silently load a record the build only partially understands.
    let path = format!("{ROOT}/records/job-log/1.rec");
    let vpath = VPath::try_from_str(&path).expect("relative path");
    let bytes = block_on_ready(fs.read(&vpath, ByteCap(1 << 20), &ctx()))
        .expect("ready")
        .expect("record exists");
    let text = String::from_utf8(bytes.to_vec()).expect("utf-8");
    block_on_ready(fs.write_atomic(
        &vpath,
        format!("{text}forged_field=true").into_bytes(),
        caly_io::Durability::D1,
        &ctx(),
    ))
    .expect("ready")
    .expect("tamper written");

    // The durable backend's startup scan decodes every job-log record before serving, so a record
    // carrying a field this build does not understand makes the *reopen itself* fail — the engine
    // never gets far enough to call `restore_job_logs`. Pin that refusal, naming the field.
    let open_error = FsStore::open(Box::new(fs) as Box<dyn Fs>, ROOT)
        .expect_err("a forged job record refuses the store reopen");
    assert!(
        open_error.summary.contains("forged_field") && open_error.summary.contains("job-log"),
        "the refusal names both the collection and the unknown field: {}",
        open_error.summary
    );
}
