//! `ADR-038 §13.2`, the last open step: the collector may run **itself**, when the engine is idle.
//!
//! Everything needed for that already existed: the plan's `would_run` (idle + no pending deployment + a
//! root set worth trusting), the cycle that executes exactly what it reported, and the record that makes
//! the outcome visible. What was missing was the policy answer to "who is allowed to let the system touch
//! data on its own" -- and that answer is what this file pins down:
//!
//! * **off until somebody files the role-gated automation patch.** No automatic cycle exists before it.
//! * **the cadence is counted in idle checks**, not milliseconds: this engine owns no clock it may poll
//!   for a schedule, and a cadence in cycles is reproducible where a wall-clock one is not (`ADR-022`).
//! * **a tick schedules; only a cycle deletes.**
//! * **the idempotency key comes from a monotone counter,** because a counter that resets would make the
//!   second cycle a *replay* of the first -- a collector that quietly stops working after one pass looks
//!   exactly like a disk with nothing left to reclaim.
//!
//! Objects are aged with the *same* injected clock that dates them (`ADR-035 §2.4`, `§4.74`): without one
//! timeline the plan refuses, and an idle collector that refuses for that reason is the honest answer --
//! which is why the fixture injects a clock rather than leaving the automatic pass broken.

use std::sync::Arc;

use caly_api::PatchAutomationJob;
use caly_common::{Actor, RequestContext, TraceId};
use caly_engine::{Command, CommandId, CommandKind, EngineHandle, EngineState, WorkerPolicy};
use caly_io::{block_on_ready, Clock, Fs, IoContext};
use caly_io_sim::{FaultInjector, MemFs, SharedFaults, SimClock, SimFs, VirtualClock};
use caly_storage::cas::{CasWriteIntent, ObjectDigest, ObjectKind};
use caly_storage::fs_store::FsStore;
use caly_storage::{ObjectStore, StorageBackend};

fn ctx() -> IoContext {
    IoContext::new(
        caly_io::TraceId::new("idle-gc-automation"),
        caly_io::Actor::System,
    )
}

const ROOT: &str = "var/caly";
const START: i64 = 1_700_000_000_000;
const GRACE: i64 = caly_engine::gc_plan::DEFAULT_GC_GRACE_PERIOD_MS;

struct World {
    handle: EngineHandle,
    store: Arc<FsStore>,
    clock: Arc<SimClock>,
}

impl World {
    fn new() -> Self {
        let clock = Arc::new(SimClock::new(
            VirtualClock::new(START),
            SharedFaults::new(FaultInjector::new(1)),
        ));
        let fs = SimFs::new(MemFs::default(), SharedFaults::new(FaultInjector::new(1)))
            .with_clock(&clock);
        let store = Arc::new(FsStore::open(Box::new(fs) as Box<dyn Fs>, ROOT).expect("open"));
        let handle = EngineHandle::with_backend(
            EngineState::new(),
            Arc::clone(&store) as Arc<dyn StorageBackend>,
        );
        handle
            .set_storage_clock(Some(Arc::clone(&clock) as Arc<dyn Clock>))
            .expect("one timeline for dates and for now");
        Self {
            handle,
            store,
            clock,
        }
    }

    /// An object nothing references, written now and then aged past the grace period -- so the plan can
    /// honestly call it collectable instead of refusing a comparison across two clocks.
    fn put_aged(&self, digest: &str) {
        block_on_ready(self.store.put(
            CasWriteIntent {
                object: caly_storage::CasObjectRef {
                    digest: ObjectDigest(digest.to_owned()),
                    kind: ObjectKind::RawSource,
                    size_bytes: None,
                    content_type: None,
                    content_sha256: None,
                    stored_at_unix_ms: None,
                },
                source_label: format!("{digest}.txt"),
                payload: b"bytes-nobody-references".to_vec(),
                stored_at_unix_ms: 0,
            },
            &ctx(),
        ))
        .expect("no suspension")
        .expect("write");
        self.clock
            .advance_ms(u64::try_from(GRACE + 1).expect("grace is a positive span"))
            .expect("the injected clock can move");
    }

    fn objects(&self) -> usize {
        block_on_ready(self.store.list_objects(&ctx()))
            .expect("ready")
            .expect("enumerable")
            .len()
    }

    fn drain_one(&self) {
        self.handle
            .drain_with_policy(WorkerPolicy::bounded(1))
            .expect("drain");
    }

    fn checks(&self) -> u64 {
        self.handle.snapshot().expect("snapshot").idle_gc_checks
    }

    fn enable(&self) {
        self.handle
            .submit(Command {
                id: CommandId("enable-gc-idle".to_owned()),
                request_id: None,
                actor: Actor::Cli,
                context: RequestContext::new(TraceId::new("enable-gc-idle"), Actor::Cli),
                timeout_ms: None,
                idempotency_key: None,
                kind: CommandKind::AutomationPatch(PatchAutomationJob {
                    job_id: caly_engine::gc_plan::AUTOMATION_IDLE_GC_JOB_ID.to_owned(),
                    enabled: true,
                }),
            })
            .expect("the patch is accepted");
        self.handle
            .drain_with_policy(WorkerPolicy::bounded(4))
            .expect("the patch runs");
    }
}

#[test]
fn an_idle_daemon_does_nothing_on_its_own_until_the_patch_arrives() {
    let world = World::new();
    world.put_aged("sha:never-touched");

    for _ in 0..24 {
        world.drain_one();
    }

    let state = world.handle.snapshot().expect("snapshot");
    assert_eq!(
        world.objects(),
        1,
        "the object is still there: no automation, no deletion"
    );
    assert!(
        state.last_gc_run.is_none(),
        "and no cycle was even recorded"
    );
    assert_eq!(
        state.idle_gc_checks, 0,
        "the counter does not advance while the job is disabled -- a cadence measured during a period \
         nobody authorised would make the first enable fire in the middle of an unrelated wait"
    );
}

#[test]
fn the_enabled_collector_fires_on_a_due_check_and_labels_its_record() {
    let world = World::new();
    world.put_aged("sha:collect-me");
    world.enable();

    for _ in 0..8 {
        world.drain_one();
    }

    assert_eq!(
        world.objects(),
        0,
        "the unrooted object is gone -- the collector ran without anyone filing a collection command"
    );
    let state = world.handle.snapshot().expect("snapshot");
    let record = state.last_gc_run.expect("a cycle ran and said so");
    assert_eq!(record.deleted_count(), 1);
    assert_eq!(
        record.triggered_by,
        caly_engine::gc_plan::GC_TRIGGER_IDLE_AUTOMATION,
        "an operator reading this must be able to tell the daemon did it alone"
    );
    assert!(
        record
            .summary_line()
            .contains("triggered_by=automation:gc.idle"),
        "{}",
        record.summary_line()
    );
}

/// The tick *schedules*; the cycle deletes. Two facts, two observable states.
#[test]
fn a_tick_schedules_a_cycle_and_does_not_delete_anything_itself() {
    let world = World::new();
    world.put_aged("sha:queued-only");
    world.enable();
    // The patch's own cycle consumed a check; walk the counter deliberately so the due check is the
    // thing under test rather than a side effect of how many drains the setup needed.
    for _ in 0..2 {
        assert!(
            !world.handle.idle_gc_tick().expect("tick"),
            "the next two checks are not multiples of the interval"
        );
    }
    assert!(
        world.handle.idle_gc_tick().expect("tick"),
        "this check is due, so a cycle is scheduled"
    );
    assert_eq!(world.objects(), 1, "and scheduling it deleted nothing");

    let state = world.handle.snapshot().expect("snapshot");
    assert!(
        state.idle_gc_claim.is_some(),
        "the schedule is attributed to a specific job, not to a flag"
    );
    assert!(state.last_gc_run.is_none(), "no cycle has run yet");

    world
        .handle
        .drain_with_policy(WorkerPolicy::bounded(2))
        .expect("run what was scheduled");
    let after = world.handle.snapshot().expect("snapshot");
    assert_eq!(world.objects(), 0);
    assert!(
        after.idle_gc_claim.is_none(),
        "the cycle consumed the claim by matching its own job id"
    );
    assert_eq!(
        after.last_gc_run.expect("record").triggered_by,
        caly_engine::gc_plan::GC_TRIGGER_IDLE_AUTOMATION
    );
}

/// Cadence, and the reason a due check is not enough on its own.
#[test]
fn the_next_due_check_with_an_empty_store_earns_no_cycle() {
    let world = World::new();
    world.put_aged("sha:one-shot");
    world.enable();
    // The patch's own cycle consumed check 1, so seven more walks the counter to 4 -- the due check,
    // read at the moment it happened rather than after the loop ran past it.
    while !world
        .checks()
        .is_multiple_of(caly_engine::gc_plan::IDLE_GC_INTERVAL_CHECKS)
    {
        world.drain_one();
    }
    let fired_at = world.checks();
    assert!(
        fired_at.is_multiple_of(caly_engine::gc_plan::IDLE_GC_INTERVAL_CHECKS),
        "it fired on a due check: {fired_at}"
    );
    let first_record = world
        .handle
        .snapshot()
        .expect("snapshot")
        .last_gc_run
        .clone()
        .expect("the first cycle recorded itself");

    // The store is clean now. A later due check must not run a cycle just to report "nothing to do":
    // an idle daemon appending an empty cycle every interval is how a bounded history drowns in it.
    // Two intervals, so a due check certainly happened while the store had nothing to offer.
    for _ in 0..(2 * caly_engine::gc_plan::IDLE_GC_INTERVAL_CHECKS) {
        world.drain_one();
    }
    let after = world.handle.snapshot().expect("snapshot");
    assert!(
        after.idle_gc_checks >= fired_at + caly_engine::gc_plan::IDLE_GC_INTERVAL_CHECKS,
        "at least one more due check went by: {} vs {}",
        after.idle_gc_checks,
        fired_at
    );
    assert_eq!(
        after.last_gc_run.as_ref(),
        Some(&first_record),
        "and no second cycle ran, so the record is still the one that deleted something"
    );
}

/// A second automatic cycle must be a *new* operation, not a replay of the first.
/// A second automatic cycle must be a *new* operation, not a replay of the first.
///
/// Both phases drain exactly as many times as the cadence requires, so the two fires are pinned to
/// specific check numbers: a cadence counter that resets on fire lands the second cycle on the *first*
/// cycle's idempotency key, dedup answers with the old job, and nothing is reclaimed -- while
/// `last_gc_run` still shows a healthy recent cycle. That is the failure mode the monotone counter in
/// `ADR-038 §9` exists to prevent, and this is its only witness.
#[test]
fn a_second_cycle_is_not_a_replay_of_the_first() {
    let interval = caly_engine::gc_plan::IDLE_GC_INTERVAL_CHECKS;
    let world = World::new();
    world.put_aged("sha:first-round-object");
    world.enable(); // the patch's own cycle consumed check 1

    // Checks 2, 3 and 4: the third drain is the due one, so cycle one runs and deletes here.
    for _ in 0..(interval - 1) {
        world.drain_one();
    }
    assert_eq!(
        world.checks(),
        interval,
        "the first fire is pinned to check {interval}"
    );
    assert_eq!(world.objects(), 0, "cycle one deleted");
    let first = world
        .handle
        .snapshot()
        .expect("snapshot")
        .last_gc_run
        .clone()
        .expect("cycle one recorded itself");
    let jobs_before = world.handle.snapshot().expect("snapshot").jobs.len();

    world.put_aged("sha:second-round-object");
    for _ in 0..interval {
        world.drain_one();
    }

    assert_eq!(
        world.objects(),
        0,
        "cycle two must actually run -- if it reused cycle one's idempotency key, dedup would answer \
         with the old job, the new object would sit there forever, and `last_gc_run` would still look \
         reassuring"
    );
    let after = world.handle.snapshot().expect("snapshot");
    let second = after.last_gc_run.clone().expect("a record exists");
    assert!(
        second.at_generation > first.at_generation,
        "the record must be a new one, not the leftover: {first:?} vs {second:?}"
    );
    assert!(
        after.jobs.len() > jobs_before,
        "and it must be a new job: this is the observable meaning of \"the cadence counter is monotone\""
    );
    assert_eq!(second.deleted_count(), 1);
    assert_eq!(
        second.triggered_by,
        caly_engine::gc_plan::GC_TRIGGER_IDLE_AUTOMATION
    );
}

/// Automation is low priority: it may not cut in front of a caller's work.
#[test]
fn an_automation_cycle_never_precedes_a_callers_command() {
    let world = World::new();
    world.put_aged("sha:caller-first");
    world.enable();
    world
        .handle
        .submit(Command {
            id: CommandId("manual-gc".to_owned()),
            request_id: None,
            actor: Actor::Cli,
            context: RequestContext::new(TraceId::new("manual-gc"), Actor::Cli),
            timeout_ms: None,
            idempotency_key: Some(caly_engine::IdempotencyKey("manual-gc-1".to_owned())),
            kind: CommandKind::StorageGc {
                grace_period_ms: Some(0),
                max_deletions: Some(8),
            },
        })
        .expect("a manual collection is queued");

    let report = world
        .handle
        .drain_with_policy(WorkerPolicy::bounded(4))
        .expect("drain with a caller ahead of the automation");
    assert!(
        !report.results.is_empty(),
        "the caller's command ran in this drain"
    );
    let state = world.handle.snapshot().expect("snapshot");
    let record = state.last_gc_run.expect("the manual cycle recorded itself");
    assert_eq!(
        record.triggered_by,
        caly_engine::gc_plan::GC_TRIGGER_CALLER,
        "and it is labelled as the caller's, whatever the automation did around it"
    );
    assert_eq!(world.objects(), 0, "the caller's cycle is what deleted it");
    assert!(
        state.idle_gc_claim.is_none(),
        "no automatic cycle was scheduled while a caller's work was in the queue"
    );
}
