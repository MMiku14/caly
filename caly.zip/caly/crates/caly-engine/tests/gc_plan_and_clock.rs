//! The GC plan's timeline rule, driven by a clock both sides share (`ADR-038 §3`).
//!
//! `docs/history/ONBOARDING_NOTES.md §4.74` recorded the defect this closes: after `ADR-035 §2.4` made object
//! ages come from the port's file dates, the plan still compared them against
//! `ExecutionPolicy::clock_start_unix_ms` -- two injected clocks that nothing relates. The fix is not to
//! pick a winner but to make the comparison use one timeline: whoever owns the dates owns the clock.
//!
//! The simulator is where this can be asserted at all, because virtual time can be advanced: the same
//! object is inside the grace period and then outside it, with nobody waiting and no wall clock read
//! (`clippy.toml` bans that outside the gateway, and `ADR-022` needs the gate reproducible).

use std::sync::Arc;

use caly_engine::{EngineHandle, EngineState, ExecutionPolicy, GcPlanBounds, GcPlanSummary};
use caly_io::{block_on_ready, Clock, Fs};
use caly_io_sim::{FaultInjector, MemFs, SharedFaults, SimClock, SimFs, VirtualClock};
use caly_storage::cas::{CasObjectRef, CasWriteIntent, ObjectDigest, ObjectKind};
use caly_storage::fs_store::FsStore;
use caly_storage::{ApplyJournalStore, ObjectStore, SnapshotStore, StorageBackend};

fn ctx() -> caly_io::IoContext {
    caly_io::RequestContext::new(
        caly_io::TraceId::new("gc-plan-and-clock"),
        caly_io::Actor::System,
    )
}

const ROOT: &str = "var/caly";
const START: i64 = 1_700_000_000_000;
const GRACE_MS: i64 = 15 * 60 * 1000;

fn object(digest: &str) -> CasObjectRef {
    CasObjectRef {
        digest: ObjectDigest(digest.to_owned()),
        kind: ObjectKind::RawSource,
        size_bytes: None,
        content_type: None,
        content_sha256: None,
        stored_at_unix_ms: None,
    }
}

fn put(store: &Arc<FsStore>, digest: &str) {
    let written = block_on_ready(store.put(
        CasWriteIntent {
            object: object(digest),
            source_label: format!("{digest}.txt"),
            payload: b"bytes-nobody-references".to_vec(),
            // A caller claiming 1970: the port's date is what the plan must use (`ADR-035 §2.4`), and these
            // tests are about the clock the plan compares that date *against*.
            stored_at_unix_ms: 0,
        },
        &ctx(),
    ))
    .expect("no suspension")
    .expect("write");
    assert_eq!(
        written.stored_at_unix_ms,
        Some(START),
        "the write must answer with the store's clock"
    );
}

/// A `FsStore` dated by `clock`, mounted on an engine, plus the plan entry point.
fn mount(clock: &Arc<SimClock>) -> (EngineHandle, Arc<FsStore>) {
    let fs =
        SimFs::new(MemFs::default(), SharedFaults::new(FaultInjector::new(1))).with_clock(clock);
    let store = Arc::new(FsStore::open(Box::new(fs) as Box<dyn Fs>, ROOT).expect("open"));
    let handle = EngineHandle::with_backend(
        EngineState::new(),
        Arc::clone(&store) as Arc<dyn StorageBackend>,
    );
    // The fallback base, pinned inside the grace window so "no clock injected" and "a clock from another
    // timeline" stay distinguishable outcomes rather than the same refusal.
    handle
        .set_execution_policy(ExecutionPolicy {
            clock_start_unix_ms: START,
            ..ExecutionPolicy::default()
        })
        .expect("policy");
    (handle, store)
}

fn plan(handle: &EngineHandle) -> GcPlanSummary {
    let bounds = GcPlanBounds::default().resolve().expect("defaults resolve");
    handle
        .storage_gc_plan(bounds)
        .expect("the plan query must answer")
}

#[test]
fn a_shared_clock_makes_the_grace_boundary_a_fact_rather_than_a_coincidence() {
    let clock = Arc::new(SimClock::new(
        VirtualClock::new(START),
        SharedFaults::new(FaultInjector::new(1)),
    ));
    let (handle, store) = mount(&clock);
    handle
        .set_storage_clock(Some(Arc::clone(&clock) as Arc<dyn Clock>))
        .expect("inject the clock the store dates by");
    put(&store, "obj:fresh");

    let inside = plan(&handle);
    assert_eq!(
        inside.now_source, "storage-clock",
        "the report has to say where `now` came from: {inside:?}"
    );
    assert_eq!(inside.now_unix_ms, START, "{inside:?}");
    assert!(
        inside.gaps.is_empty(),
        "one timeline, so nothing to refuse on: {:?}",
        inside.gaps
    );
    assert!(
        inside.collect.is_empty(),
        "an object written this instant is inside its grace period: {inside:?}"
    );
    assert_eq!(inside.skipped_for_grace, 1, "{inside:?}");

    // Same object, same plan, more virtual time: the grace period expires because the clock moved, not
    // because somebody re-wrote a claim.
    clock
        .advance_ms((GRACE_MS + 1) as u64)
        .expect("advance past the grace period");
    let outside = plan(&handle);
    assert_eq!(outside.now_unix_ms, START + GRACE_MS + 1, "{outside:?}");
    assert_eq!(
        outside.collect,
        vec!["obj:fresh".to_owned()],
        "unreferenced and out of grace: the one thing a cycle may take"
    );
    assert!(outside.would_run(), "{outside:?}");
    assert_eq!(
        outside.retained_total, 0,
        "and nothing here is held by a root: {outside:?}"
    );
}

#[test]
fn with_nothing_injected_the_plan_refuses_and_says_which_base_it_used() {
    let clock = Arc::new(SimClock::new(
        VirtualClock::new(START),
        SharedFaults::new(FaultInjector::new(1)),
    ));
    let (handle, store) = mount(&clock);
    // Move the store's clock first, then write: the object is stamped on a date the plan cannot
    // reconstruct from the policy base, which is the shape a real deployment has (files dated by the
    // host, `clock_start_unix_ms` left at its default 0).
    clock
        .advance_ms((GRACE_MS * 4) as u64)
        .expect("push the store's dates past the policy base");
    // Deliberately no `set_storage_clock` yet.
    let written = block_on_ready(store.put(
        CasWriteIntent {
            object: object("obj:late"),
            source_label: "dated-by-the-store".to_owned(),
            payload: b"bytes-nobody-references".to_vec(),
            stored_at_unix_ms: 0,
        },
        &ctx(),
    ))
    .expect("no suspension")
    .expect("write");
    assert_eq!(written.stored_at_unix_ms, Some(START + GRACE_MS * 4));

    let refused = plan(&handle);
    assert_eq!(refused.now_source, "execution-policy-base");
    let classes: Vec<&str> = refused.gaps.iter().map(|gap| gap.class).collect();
    assert_eq!(classes, vec!["clock-timeline"], "{refused:?}");
    assert!(
        refused.collect.is_empty(),
        "a plan across two timelines lists nothing: {refused:?}"
    );
    assert!(!refused.would_run());
    assert!(
        refused
            .summary_line()
            .contains("now=1700000000000@execution-policy-base"),
        "{}",
        refused.summary_line()
    );

    // Inject the clock and the mismatch is gone from the *same* store state -- which is what makes the
    // refusal evidence about the wiring rather than about the data. Freshness still protects the object
    // for one grace period, and then it becomes collectable on the elapsed time alone.
    handle
        .set_storage_clock(Some(Arc::clone(&clock) as Arc<dyn Clock>))
        .expect("inject");
    let fresh = plan(&handle);
    assert!(fresh.gaps.is_empty(), "{fresh:?}");
    assert_eq!(fresh.now_unix_ms, START + GRACE_MS * 4, "{fresh:?}");
    assert!(
        fresh.collect.is_empty() && fresh.skipped_for_grace == 1,
        "just written on this timeline, so still held: {fresh:?}"
    );

    clock.advance_ms((GRACE_MS + 1) as u64).expect("elapsed");
    let aged = plan(&handle);
    assert_eq!(aged.collect, vec!["obj:late".to_owned()], "{aged:?}");
    assert!(aged.would_run(), "{aged:?}");
}

// ---------------------------------------------------------------------------------------------
// The cycle itself: what it deletes, and what stops it.
// ---------------------------------------------------------------------------------------------

fn store_ok<T: std::fmt::Debug>(
    future: caly_io::BoxFuture<'_, Result<T, caly_storage::StorageError>>,
) -> T {
    block_on_ready(future)
        .expect("no suspension")
        .expect("storage call must succeed")
}

fn snapshot(id: &str, artifact: &str) -> caly_storage::SnapshotRecord {
    caly_storage::SnapshotRecord {
        id: caly_storage::SnapshotRecordId(id.to_owned()),
        revision_id: caly_storage::RevisionId("rev:01".to_owned()),
        revision_number: caly_storage::RevisionNumber(1),
        profile_id: "demo-profile".to_owned(),
        semantic_digest: "sem:1".to_owned(),
        compiled_artifact_digest: artifact.to_owned(),
        core_binary_digest: "bin:1".to_owned(),
        core_identity: "mihomo@0.1".to_owned(),
        apply_plan_summary: "Restart".to_owned(),
        journal_id: None,
        selection_memory_digest: None,
        validation_summary: "ok".to_owned(),
        created_at_unix_ms: START,
        is_last_known_good: true,
    }
}

fn command(id: &str, kind: caly_engine::CommandKind) -> caly_engine::Command {
    caly_engine::Command {
        id: caly_engine::CommandId(id.to_owned()),
        request_id: None,
        actor: caly_common::Actor::Cli,
        context: caly_common::RequestContext::new(
            caly_common::TraceId::new("gc-cycle"),
            caly_common::Actor::Cli,
        ),
        timeout_ms: None,
        idempotency_key: None,
        kind,
    }
}

fn digests(store: &Arc<FsStore>) -> Vec<String> {
    store_ok(store.list_objects(&ctx()))
        .into_iter()
        .map(|object| object.digest.0)
        .collect()
}

/// The cycle deletes exactly the list the plan reported -- not a list re-derived at the delete site --
/// and an object that is merely *old* but rooted survives.
#[test]
fn a_cycle_deletes_exactly_what_the_plan_named_and_keeps_what_a_root_holds() {
    let clock = Arc::new(SimClock::new(
        VirtualClock::new(START),
        SharedFaults::new(FaultInjector::new(1)),
    ));
    let (handle, store) = mount(&clock);
    handle
        .set_storage_clock(Some(Arc::clone(&clock) as Arc<dyn Clock>))
        .expect("inject");
    put(&store, "obj:orphan");
    put(&store, "obj:rooted");
    store_ok(store.put_snapshot(snapshot("snapshot:one", "obj:rooted"), &ctx()));

    // Past the grace period for both, so nothing below is saved by freshness: `grace_period_ms: 0`
    // below makes the root set the only difference between the two objects.
    clock
        .advance_ms((GRACE_MS + 1) as u64)
        .expect("advance past grace");
    let bounds = caly_engine::GcPlanBounds {
        grace_period_ms: Some(0),
        max_deletions: None,
    }
    .resolve()
    .expect("bounds");

    let before = handle.storage_gc_plan(bounds).expect("plan");
    assert_eq!(
        before.collect,
        vec!["obj:orphan".to_owned()],
        "the plan names one object and spares the rooted one: {before:?}"
    );

    let record = handle.storage_gc_collect(bounds, None).expect("collect");
    assert_eq!(
        record.collected, before.collect,
        "the cycle must execute the plan it just reported, not a second opinion"
    );
    assert!(
        record.failed.is_empty() && record.refused.is_none(),
        "{record:?}"
    );
    assert_eq!(record.retained_total, before.retained_total);
    assert_eq!(
        record.now_source, "storage-clock",
        "the record keeps saying which clock it judged by: {record:?}"
    );

    assert_eq!(
        digests(&store),
        vec!["obj:rooted".to_owned()],
        "the store is left holding exactly the rooted object"
    );
    assert_eq!(
        handle
            .last_gc_run()
            .expect("read")
            .expect("a run is recorded")
            .deleted_count(),
        1,
        "and the record of what it did survives the call"
    );

    // A second cycle over the same store finds nothing and says so plainly, rather than pretending to
    // have reclaimed something again.
    let again = handle
        .storage_gc_collect(bounds, None)
        .expect("second collect");
    assert!(again.collected.is_empty(), "{again:?}");
    assert!(again.refused.is_none(), "{again:?}");
    assert_eq!(again.retained_total, 1, "{again:?}");
}

/// Refusal has two distinct places, and each has to be visible without deleting anything.
#[test]
fn an_ineligible_store_state_refuses_the_cycle_at_both_ends() {
    let clock = Arc::new(SimClock::new(
        VirtualClock::new(START),
        SharedFaults::new(FaultInjector::new(1)),
    ));
    let (handle, store) = mount(&clock);
    handle
        .set_storage_clock(Some(Arc::clone(&clock) as Arc<dyn Clock>))
        .expect("inject");
    put(&store, "obj:orphan");
    clock
        .advance_ms((GRACE_MS + 1) as u64)
        .expect("advance past grace");
    let bounds = caly_engine::GcPlanBounds {
        grace_period_ms: Some(0),
        max_deletions: None,
    }
    .resolve()
    .expect("bounds");

    // (a) Admission: a queue with anything in it refuses a collection cycle *before* a job exists. The
    // revision must not move -- a refusal that bumps it poisons every other caller's
    // `expected_revision` while having changed nothing (`docs/history/ONBOARDING_NOTES.md §4.58`).
    handle
        .submit(command(
            "cmd-blocker",
            caly_engine::CommandKind::DiagnosticsBundle,
        ))
        .expect("the blocker is accepted");
    let generation_before = handle.snapshot().expect("state").generation;
    let refusal = handle
        .submit(command(
            "cmd-gc",
            caly_engine::CommandKind::StorageGc {
                grace_period_ms: Some(0),
                max_deletions: None,
            },
        ))
        .expect_err("a busy engine must refuse the cycle at admission");
    assert!(
        refusal.contains("idle"),
        "the refusal has to say what it is waiting for: {refusal}"
    );
    let after = handle.snapshot().expect("state");
    assert_eq!(
        after.generation, generation_before,
        "a refusal may not advance the revision other callers compare against"
    );
    assert!(
        after
            .overloads
            .iter()
            .any(|report| report.class == caly_engine::OverloadClass::StorageBusy),
        "and it has to reach the diagnostics outlet, not just this caller: {:?}",
        after.overloads
    );

    // (b) Execution: with work in flight the cycle also refuses when called directly, and deletes
    // nothing. Both ends are pinned because the admission check is an optimisation of this one, never
    // a replacement for it.
    let record = handle
        .storage_gc_collect(bounds, None)
        .expect("collect refuses cleanly");
    assert!(
        record.refused.is_some(),
        "an in-flight deployment is exactly what the collector must not race: {record:?}"
    );
    assert!(
        handle
            .last_gc_run()
            .expect("read")
            .map(|run| run.refused.is_some())
            .unwrap_or(false),
        "a refusal has to be recorded, not only returned: whoever did not submit the request reads \
         the record (`ADR-038 §2`)"
    );
    assert!(record.collected.is_empty(), "{record:?}");
    assert_eq!(
        digests(&store),
        vec!["obj:orphan".to_owned()],
        "a refusal must leave the store byte-for-byte as it was"
    );

    // Once the queue drains, the same cycle on the same store does the work.
    handle
        .drain_with_policy(caly_engine::WorkerPolicy::bounded(4))
        .expect("drain");
    // The drained job was a support-bundle export, which wrote a new CAS object on the way past --
    // so the assertion is "the orphan is gone", not an exact list. That is the better property anyway:
    // the cycle plans against the store as it finds it, not as an earlier caller predicted.
    let cleared = handle
        .storage_gc_collect(bounds, None)
        .expect("collect after drain");
    assert!(cleared.refused.is_none(), "{cleared:?}");
    assert!(
        cleared.collected.contains(&"obj:orphan".to_owned()),
        "the queued work is gone, so the same cycle now runs: {cleared:?}"
    );
    assert!(
        !digests(&store).contains(&"obj:orphan".to_owned()),
        "and it is actually removed: {:?}",
        digests(&store)
    );
}

#[test]
fn the_report_distinguishes_refused_from_nothing_to_do() {
    let clock = Arc::new(SimClock::new(
        VirtualClock::new(START),
        SharedFaults::new(FaultInjector::new(1)),
    ));
    let (handle, _store) = mount(&clock);
    let bounds = caly_engine::GcPlanBounds::default()
        .resolve()
        .expect("bounds");

    // An empty store: nothing to reclaim, and the cycle is allowed to run.
    let idle = handle.storage_gc_collect(bounds, None).expect("collect");
    assert!(idle.refused.is_none(), "{idle:?}");
    assert!(idle.collected.is_empty(), "{idle:?}");
    assert!(
        !idle.summary_line().contains("refused"),
        "{}",
        idle.summary_line()
    );
    assert!(
        idle.summary_line().contains("deleted=0"),
        "and it still states the number: {}",
        idle.summary_line()
    );
}

/// The other half of `would_run`, isolated on purpose: an unfinished transaction does not make the root
/// set unknowable (`§13.1` is complete -- the journal's own digests are inside it), it only makes the
/// moment wrong. A build that checks roots and forgets eligibility passes every root-completeness test,
/// so this case has to exist on its own.
#[test]
fn a_pending_transaction_stops_the_cycle_with_nothing_wrong_about_the_roots() {
    let clock = Arc::new(SimClock::new(
        VirtualClock::new(START),
        SharedFaults::new(FaultInjector::new(1)),
    ));
    let (handle, store) = mount(&clock);
    handle
        .set_storage_clock(Some(Arc::clone(&clock) as Arc<dyn Clock>))
        .expect("inject");
    put(&store, "obj:between");
    store_ok(store.put_apply_journal(journal("txn:open", "obj:other"), &ctx()));
    clock
        .advance_ms((GRACE_MS + 1) as u64)
        .expect("past grace, so only the gate can stop this");

    let bounds = caly_engine::GcPlanBounds {
        grace_period_ms: Some(0),
        max_deletions: None,
    }
    .resolve()
    .expect("bounds");
    let plan = handle.storage_gc_plan(bounds).expect("plan");
    assert!(
        plan.gaps.is_empty(),
        "every root is readable here -- that is the point of this test: {:?}",
        plan.gaps
    );
    assert_eq!(plan.pending_deployments, 1, "{plan:?}");
    assert_eq!(
        plan.collect,
        vec!["obj:between".to_owned()],
        "a plan may still be reported while a cycle is ineligible: {plan:?}"
    );
    assert!(!plan.would_run(), "{plan:?}");

    let record = handle.storage_gc_collect(bounds, None).expect("collect");
    assert!(
        record.refused.is_some(),
        "the cycle itself must honour `§13.2`: {record:?}"
    );
    assert!(record.collected.is_empty(), "{record:?}");
    assert_eq!(
        digests(&store),
        vec!["obj:between".to_owned()],
        "and the store must be untouched"
    );
}

fn journal(txn: &str, artifact: &str) -> caly_storage::ApplyJournalRecord {
    caly_storage::ApplyJournalRecord {
        journal_id: caly_storage::JournalRecordId(format!("journal:{txn}")),
        apply_txn_id: caly_storage::ApplyTxnId(txn.to_owned()),
        trace_id: "gc-cycle".to_owned(),
        job_id: None,
        profile_id: "demo-profile".to_owned(),
        revision_id: caly_storage::RevisionId(format!("rev:{txn}")),
        semantic_digest: "sem:1".to_owned(),
        compiled_artifact_digest: artifact.to_owned(),
        core_identity: "mihomo@0.1".to_owned(),
        effect_plan_id: "plan:1".to_owned(),
        current_phase: caly_storage::ApplyPhase::Cutover,
        current_step_index: 1,
        net_effect_started: true,
        core_cutover_started: true,
        previous_snapshot_id: None,
        created_at_unix_ms: START,
        updated_at_unix_ms: START,
        state: caly_storage::ApplyJournalState::Pending,
    }
}
