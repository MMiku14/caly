//! `ADR-036` step 2, at the seam a caller can actually see.
//!
//! The claim being tested is narrow and mechanical: a command's own `Ctx` now reaches the one engine
//! path that *starts* store work (`begin_apply_persistence`), so
//!
//! * a caller who cancelled, or whose deadline had already passed, is answered **without the store
//!   being asked at all** -- not "the store was told and ignored it";
//! * the job settles as `JobOutcome::Cancelled` / `TimedOut`, the two variants that had no producer
//!   before this round (`ADR-036 §6bis-quinque`);
//! * a deadline nobody can judge (no clock injected) is *not* turned into a refusal, and is reported
//!   as unjudged rather than as absent (`docs/ONBOARDING_NOTES.md §4.86`);
//! * and the writes that record that the world was already touched cannot be refused at all.
//!
//! The last two are the halves a wiring-only change usually forgets, which is why they are asserted
//! here rather than in a comment.

use std::sync::Arc;

use caly_api::{ApplyRequest, JobId, ProfileId};
use caly_common::{Actor, CancelToken, RequestContext, TraceId};
use caly_engine::{
    plan_apply_request, Command, CommandId, CommandKind, EngineHandle, EngineState, JobEvent,
    JobOutcome, RunLimits, WorkerPolicy,
};
use caly_io::block_on_ready;
use caly_io_sim::{FaultInjector, SharedFaults, SimClock, VirtualClock};
use caly_storage::{ApplyPhase, InMemoryStorage};

fn ctx() -> caly_io::IoContext {
    caly_io::RequestContext::new(
        caly_io::TraceId::new("ctx-limits-in-apply"),
        caly_io::Actor::System,
    )
}

fn projection() -> caly_storage::ApplyStorageProjection {
    plan_apply_request(ApplyRequest {
        profile_id: ProfileId("demo-tun-profile".to_owned()),
        dry_run: false,
        strict: false,
    })
    .expect("plan")
    .storage_projection
}

fn command_with(context: RequestContext) -> Command {
    Command {
        id: CommandId("cmd-ctx-limits".to_owned()),
        request_id: None,
        actor: Actor::Cli,
        context,
        timeout_ms: None,
        idempotency_key: None,
        kind: CommandKind::ProfileApply(ApplyRequest {
            profile_id: ProfileId("demo-tun-profile".to_owned()),
            dry_run: false,
            strict: false,
        }),
    }
}

fn handle() -> EngineHandle {
    EngineHandle::with_storage(EngineState::new(), InMemoryStorage::new())
}

fn drain(handle: &EngineHandle, command: Command) -> caly_engine::WorkerCycleResult {
    handle.submit(command).expect("submit accepted");
    handle
        .drain_with_policy(WorkerPolicy::bounded(1))
        .expect("drain")
        .results
        .into_iter()
        .next()
        .expect("one cycle")
}

fn failure_event(handle: &EngineHandle, job: u64) -> caly_api::ApiError {
    handle
        .follow_job(JobId(job))
        .expect("follow")
        .job
        .expect("job")
        .events
        .iter()
        .find_map(|event| match event {
            JobEvent::Failed { error } => Some(error.clone()),
            _ => None,
        })
        .expect("a refused apply must surface a public error")
}

/// The two places a settlement shows up must not disagree: the cycle result the caller was handed, and
/// the job record every other reader consults (watch bridge, support bundle, `job follow`).
///
/// This assertion exists because a falsification run asked for it: mutating `fail()` to write
/// `Failed` into the job record while still reporting `Cancelled` in the cycle result changed no test
/// at all until this was in place -- which is what a two-answer split looks like from the outside
/// (`docs/ONBOARDING_NOTES.md §4.95`).
fn assert_settled_state(handle: &EngineHandle, job: u64, want: caly_engine::JobState) {
    let record = handle
        .follow_job(JobId(job))
        .expect("follow")
        .job
        .expect("job");
    assert_eq!(
        record.state, want,
        "the settled row must say the same thing the caller was told"
    );
}

/// Nothing unresolved, no snapshot: the store was never asked.
fn assert_store_untouched(handle: &EngineHandle) {
    let report = handle.scan_recovery_state().expect("scan");
    assert!(
        report.unresolved_apply_journals.is_empty(),
        "a refusal must not leave a journal behind: {:?}",
        report.unresolved_apply_journals
    );
    assert!(
        block_on_ready(handle.storage().latest_last_known_good(&ctx()))
            .expect("ready")
            .expect("store answers")
            .is_none(),
        "and certainly no snapshot"
    );
}

#[test]
fn a_cancelled_command_is_answered_before_the_store_is_asked() {
    let handle = handle();
    let token = CancelToken::new();
    token.cancel();
    let mut context = RequestContext::new(TraceId::new("ctx-cancelled"), Actor::Cli);
    context.cancel = token;
    let limits = RunLimits::for_command(&context, handle.storage_clock());
    assert!(!limits.is_immediate(), "a fired token is a limit");

    let refusal = handle
        .begin_apply_persistence(projection(), &limits)
        .expect_err("the caller already gave up");
    assert_eq!(refusal.kind, caly_engine::RefusalKind::CallerCancelled);
    assert!(
        refusal.message.contains("call cancelled before poll 1"),
        "{refusal:?}"
    );
    assert!(
        !refusal.retryable,
        "a cancellation is not congestion: {refusal:?}"
    );
    assert!(
        refusal.limits.contains("cancel=fired"),
        "the record names what refused it: {refusal:?}"
    );
    assert_store_untouched(&handle);
}

#[test]
fn a_cancelled_apply_settles_as_cancelled_not_as_a_broken_deployment() {
    let handle = handle();
    let mut context = RequestContext::new(TraceId::new("ctx-cancelled-job"), Actor::Cli);
    context.cancel = CancelToken::pre_cancelled();
    let result = drain(&handle, command_with(context));

    assert_eq!(
        result.outcome,
        JobOutcome::Cancelled,
        "`JobOutcome::Cancelled` had no producer before `ADR-036` step 2; a row that says `Failed` \
         here would read as a broken deployment"
    );
    let failure = failure_event(&handle, result.job_id);
    assert_eq!(failure.code, caly_api::ErrorCode::Storage);
    assert!(
        failure
            .detail
            .as_deref()
            .unwrap_or_default()
            .contains("cancel=fired"),
        "{:?}",
        failure.detail
    );
    assert_settled_state(&handle, result.job_id, caly_engine::JobState::Cancelled);
    assert_store_untouched(&handle);
}

#[test]
fn an_expired_deadline_settles_as_timed_out_because_a_clock_said_so() {
    let handle = handle();
    let clock = SimClock::new(
        VirtualClock::new(0),
        SharedFaults::new(FaultInjector::new(1)),
    );
    handle
        .set_storage_clock(Some(Arc::new(clock) as Arc<dyn caly_io::Clock>))
        .expect("inject the clock the apply path anchors against");

    let mut context = RequestContext::new(TraceId::new("ctx-expired"), Actor::Cli);
    // What `caly-daemon` writes at its boundary: the absolute instant, judged by the engine's clock.
    context.deadline_ms = Some(0);
    context.deadline_mono_ms = Some(0);
    let result = drain(&handle, command_with(context));

    assert_eq!(result.outcome, JobOutcome::TimedOut);
    let failure = failure_event(&handle, result.job_id);
    let detail = failure.detail.clone().unwrap_or_default();
    assert!(
        detail.contains("deadline at mono 0 expired"),
        "the timeout must cite the reading that judged it, not just say \"too late\": {detail}"
    );
    assert!(failure.retryable, "a deadline is a reason to try again");
    assert_settled_state(&handle, result.job_id, caly_engine::JobState::TimedOut);
    assert_store_untouched(&handle);
}

#[test]
fn a_deadline_nobody_can_judge_is_not_turned_into_a_refusal() {
    let handle = handle();
    let mut context = RequestContext::new(TraceId::new("ctx-unjudged"), Actor::Cli);
    context.deadline_ms = Some(5);
    // No clock injected on this handle: the deadline stays *unjudged*, which must not mean "expired".
    let limits = RunLimits::for_command(&context, handle.storage_clock());
    assert!(!limits.is_immediate());
    assert!(
        limits.describe().contains("unjudged(no clock)"),
        "{limits:?}"
    );

    let persisted = handle
        .begin_apply_persistence(projection(), &limits)
        .expect("an unjudgeable deadline may not refuse work");
    assert_eq!(
        persisted.journal.current_phase,
        caly_storage::ApplyPhase::Prepare,
        "and it is the real projection, not a placeholder: {persisted:?}"
    );
    let report = handle.scan_recovery_state().expect("scan");
    assert_eq!(
        report.unresolved_apply_journals.len(),
        1,
        "the store WAS asked, because nothing said not to"
    );
}

#[test]
fn limits_that_are_present_and_not_violated_answer_exactly_like_having_none() {
    let handle = handle();
    let mut context = RequestContext::new(TraceId::new("ctx-far"), Actor::Cli);
    context.deadline_mono_ms = Some(10_000);
    let relaxed = RunLimits::for_command(&context, None);
    let plain = RunLimits::immediate();

    let with_limits = handle
        .begin_apply_persistence(projection(), &relaxed)
        .expect("the deadline is far away");
    let without = handle
        .begin_apply_persistence(projection(), &plain)
        .expect("no limits at all");
    assert_eq!(
        with_limits, without,
        "adding an enforceable check must not change the answer when nothing is violated -- \
         otherwise the enforcement itself is a side effect"
    );
}

#[test]
fn the_write_that_first_records_a_touched_world_cannot_be_refused() {
    let handle = handle();
    let persisted = handle
        .begin_apply_persistence(projection(), &RunLimits::immediate())
        .expect("phase A");
    assert!(
        !persisted.journal.net_effect_started && !persisted.journal.core_cutover_started,
        "phase A must not claim the world changed: {:?}",
        persisted.journal
    );

    let token = CancelToken::new();
    token.cancel();
    let mut context = RequestContext::new(TraceId::new("ctx-immunity"), Actor::Cli);
    context.cancel = token;
    let refused_if_it_could = RunLimits::for_command(&context, None);

    let cutover = handle
        .advance_apply_phase(
            &persisted.journal,
            ApplyPhase::Cutover,
            2,
            1,
            &refused_if_it_could,
        )
        .expect("this write is the evidence a recovery scanner reads; a deadline may not erase it");
    assert!(
        cutover.net_effect_started && cutover.core_cutover_started,
        "{cutover:?}"
    );

    // The *same* limits, now on a write that records nothing new, do refuse -- which is what makes the
    // immunity above a decision rather than an accident of the limits never being obeyed.
    let refusal = handle
        .advance_apply_phase(&cutover, ApplyPhase::Cutover, 7, 2, &refused_if_it_could)
        .expect_err("a cursor move inside a settled phase is refusable");
    assert_eq!(refusal.kind, caly_engine::RefusalKind::CallerCancelled);

    let report = handle.scan_recovery_state().expect("scan");
    let stored = &report.unresolved_apply_journals[0];
    assert_eq!(
        stored.current_step_index, 2,
        "the refusal left the cursor where the accepted write put it, so recovery re-does a step \
         instead of mis-reading the crash site: {stored:?}"
    );
    assert!(
        stored.net_effect_started && stored.core_cutover_started,
        "{stored:?}"
    );
}
