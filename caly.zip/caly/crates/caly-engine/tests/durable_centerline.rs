//! The centerline against a durable backend, across a restart.
//!
//! Everything before this file exercised apply against `InMemoryStorage`, where "recovery"
//! could only mean *within one process*. The promise in `docs/APPLY_EXECUTION_CENTERLINE.md §12`
//! and `STORAGE_RECOVERY_EXECUTION_PLAN.md §11` is stronger than that: a transaction must be
//! reconstructible from disk after the process is gone.
//!
//! These tests run the real pipeline (`plan_apply_request`) against `FsStore` over the simulator's
//! `Fs`, then build a **fresh engine over a freshly opened store on the same disk** — the only
//! thing carried across is the bytes.

use std::sync::Arc;

use caly_api::{ApplyRequest, ProfileId};
use caly_common::{Actor, RequestContext, TraceId};
use caly_engine::{
    command::{Command, CommandId, CommandKind},
    EngineHandle, EngineState, JobOutcome, RunLimits, WorkerPolicy,
};
use caly_io::{block_on_ready, ByteCap, Fs, ListCap, VPath};
use caly_io_sim::{FaultInjector, MemFs, SharedFaults, SimFs};
use caly_storage::fs_store::FsStore;
use caly_storage::SnapshotStore;

const ROOT: &str = "var/caly";

fn disk() -> SimFs {
    SimFs::new(MemFs::default(), SharedFaults::new(FaultInjector::new(1)))
}

fn open(fs: SimFs) -> Arc<dyn caly_storage::StorageBackend> {
    Arc::new(
        FsStore::open(Box::new(fs), ROOT)
            .expect("a fresh store must open over an empty or existing root"),
    )
}

fn apply_command(profile_id: &str) -> Command {
    Command {
        id: CommandId(format!("cmd-{profile_id}")),
        request_id: None,
        actor: Actor::Cli,
        context: RequestContext::new(TraceId::new("trace-durable"), Actor::Cli),
        timeout_ms: None,
        idempotency_key: None,
        kind: CommandKind::ProfileApply(ApplyRequest {
            profile_id: ProfileId(profile_id.to_owned()),
            dry_run: false,
            strict: false,
        }),
    }
}

fn drain(handle: &EngineHandle, command: Command) -> caly_engine::WorkerCycleResult {
    handle.submit(command).expect("submit accepted");
    handle
        .drain_with_policy(WorkerPolicy::bounded(1))
        .expect("drain")
        .results
        .into_iter()
        .next()
        .expect("one cycle")
}

/// The full relative paths in one store directory, exactly as the port enumerates them.
///
/// Deliberately obtained through `Fs::list` rather than by rebuilding the layout here: what these
/// assertions are about is what a *restart* can find, and the only honest definition of that is the
/// call the store itself makes (`ADR-035 §2.3`).
fn listed(fs: &SimFs, dir: &str) -> Vec<String> {
    let path = VPath::try_from_str(dir).expect("relative dir");
    block_on_ready(fs.list(&path, ListCap(256), &ctx()))
        .expect("ready")
        .expect("a store directory must be enumerable")
        .into_iter()
        .map(|entry| entry.as_relative_path())
        .collect()
}

fn read_file(fs: &SimFs, relative: &str) -> Option<String> {
    let path = VPath::try_from_str(relative).expect("relative path");
    block_on_ready(fs.read(&path, ByteCap(1 << 20), &ctx()))
        .ok()?
        .ok()
        .map(|bytes| String::from_utf8_lossy(&bytes).into_owned())
}

fn ctx() -> caly_io::IoContext {
    caly_io::RequestContext::new(TraceId::new("durable-read"), Actor::System)
}

/// A successful apply must leave real files behind, not just an updated map.
#[test]
fn a_committed_apply_leaves_readable_artifacts_on_disk() {
    let fs = disk();
    let handle = EngineHandle::with_backend(EngineState::new(), open(fs.clone()));

    let result = drain(&handle, apply_command("demo-tun-profile"));
    assert_eq!(result.outcome, JobOutcome::Succeeded);

    // Every collection has to be found by *listing the directory it lives in*. The index files these
    // assertions used to read are gone (`ADR-035 §2.3`), which is the point: an apply that only
    // updated a list would now be visible as an empty directory rather than hidden behind it.
    let objects = listed(&fs, &format!("{ROOT}/meta/objects"));
    assert!(
        objects.iter().any(|path| path.ends_with(".obj")),
        "object metadata must be a file in the enumerated directory: {objects:?}"
    );

    let records = listed(&fs, &format!("{ROOT}/records/snapshot"));
    assert!(
        records.iter().any(|path| path.ends_with(".rec")),
        "a committed snapshot must be a record file: {records:?}"
    );

    let journals = listed(&fs, &format!("{ROOT}/records/apply-journal"));
    assert!(
        !journals.is_empty(),
        "the apply journal must be a record file: {journals:?}"
    );

    let pointer = read_file(&fs, &format!("{ROOT}/pointers/last-known-good"))
        .expect("the last-known-good marker must be a file");
    assert!(
        !pointer.trim().is_empty(),
        "the pointer must name a snapshot"
    );

    // And nothing in the tree may be a list of something else.
    let all: Vec<String> = fs
        .snapshot()
        .expect("disk")
        .files
        .into_iter()
        .map(|file| file.path)
        .collect();
    assert!(
        all.iter().all(|path| !path.contains("manifest/")),
        "a durable apply must not maintain an index: {all:?}"
    );
}

/// The artifact bytes themselves must be content-addressed and readable back.
#[test]
fn the_compiled_bytes_are_stored_under_their_own_digest() {
    let fs = disk();
    let handle = EngineHandle::with_backend(EngineState::new(), open(fs.clone()));
    drain(&handle, apply_command("demo-tun-profile"));

    let workflow = caly_engine::plan_apply_request(ApplyRequest {
        profile_id: ProfileId("demo-tun-profile".to_owned()),
        dry_run: true,
        strict: false,
    })
    .expect("plan");
    let anchor = workflow
        .storage_projection
        .artifact_object
        .object
        .content_sha256
        .clone()
        .expect("the projection must record the integrity anchor");
    let suffix = caly_storage::fs_store::content_suffix_for(&anchor);
    let stored = read_file(&fs, &format!("{ROOT}/{suffix}")).expect("content file must exist");

    // The stored bytes are the compiled artifact, byte for byte.
    let expected =
        String::from_utf8_lossy(&workflow.storage_projection.artifact_object.payload).into_owned();
    assert_eq!(
        stored, expected,
        "content addressing must be exact, not approximate"
    );
    assert!(
        anchor.starts_with("sha256:"),
        "the anchor is a real digest: {anchor}"
    );
    assert!(caly_common::digest::sha256_matches(
        &anchor,
        expected.as_bytes()
    ));
}

/// The restart case: nothing from the old process is visible, yet the committed truth is.
#[test]
fn a_restarted_engine_recovers_the_committed_snapshot_from_disk() {
    let fs = disk();
    {
        let handle = EngineHandle::with_backend(EngineState::new(), open(fs.clone()));
        let result = drain(&handle, apply_command("demo-tun-profile"));
        assert_eq!(result.outcome, JobOutcome::Succeeded);
        let snapshot_id = handle
            .latest_last_known_good_snapshot()
            .expect("lkg read")
            .expect("lkg after apply")
            .id
            .0
            .clone();
        assert!(snapshot_id.starts_with("snapshot:rev:"));
    }

    // New engine, new store instance, same disk. The only shared state is the files.
    let reopened = FsStore::open(Box::new(fs.clone()) as Box<dyn Fs>, ROOT).expect("reopen");
    let handle = EngineHandle::with_backend(EngineState::new(), Arc::new(reopened));

    let lkg = handle
        .latest_last_known_good_snapshot()
        .expect("lkg read")
        .expect("a committed snapshot must survive the process");
    assert_eq!(lkg.profile_id, "demo-tun-profile");
    assert!(lkg.is_last_known_good);
    assert_eq!(lkg.apply_plan_summary, "Restart");
    assert!(!lkg.compiled_artifact_digest.is_empty());

    let report = handle.scan_recovery_state().expect("scan after restart");
    assert!(
        report.unresolved_apply_journals.is_empty(),
        "a committed transaction must not be resurrected as work: {:?}",
        report.unresolved_apply_journals
    );
    assert!(report.decisions.is_empty());
}

/// A deployment interrupted mid-cutover must come back as a *decision*, not as silence.
#[test]
fn an_interrupted_cutover_comes_back_as_a_rollback_decision() {
    let fs = disk();
    {
        let handle = EngineHandle::with_backend(EngineState::new(), open(fs.clone()));
        // First apply commits, so there is something to roll back to.
        drain(&handle, apply_command("demo-tun-profile"));

        // Then start a second transaction, journal the cutover, and "die" before finalization:
        // nothing settles the journal, which is exactly what a crash looks like from disk.
        let workflow = caly_engine::plan_apply_request(ApplyRequest {
            profile_id: ProfileId("demo-singbox-profile".to_owned()),
            dry_run: false,
            strict: false,
        })
        .expect("plan");
        let persisted = handle
            .begin_apply_persistence(workflow.storage_projection.clone(), &RunLimits::immediate())
            .expect("begin persistence");
        handle
            .advance_apply_phase(
                &persisted.journal,
                caly_storage::ApplyPhase::Cutover,
                2,
                1,
                &RunLimits::immediate(),
            )
            .expect("advance cutover");
    }

    let handle = EngineHandle::with_backend(EngineState::new(), open(fs));
    let report = handle.scan_recovery_state().expect("scan after restart");
    assert_eq!(
        report.unresolved_apply_journals.len(),
        1,
        "the unfinished transaction must reappear from disk"
    );
    assert_eq!(
        report.unresolved_apply_journals[0].profile_id,
        "demo-singbox-profile"
    );
    assert!(report.unresolved_apply_journals[0].core_cutover_started);
    assert_eq!(report.unresolved_apply_journals[0].current_step_index, 2);

    assert!(
        matches!(
            report.decisions.as_slice(),
            [caly_storage::RecoveryDecision::RollbackToLastKnownGood { .. }]
        ),
        "cutover started + a last-known-good exists must mean rollback, got {:?}",
        report.decisions
    );
    let lkg = handle
        .latest_last_known_good_snapshot()
        .expect("lkg read")
        .expect("the previous good snapshot is still the truth");
    assert_eq!(lkg.profile_id, "demo-tun-profile");
}

/// With no last-known-good to fall back to, the same crash must escalate, not be reported as
/// recoverable.
#[test]
fn an_interrupted_first_apply_on_an_empty_store_escalates() {
    let fs = disk();
    {
        let handle = EngineHandle::with_backend(EngineState::new(), open(fs.clone()));
        let workflow = caly_engine::plan_apply_request(ApplyRequest {
            profile_id: ProfileId("demo-tun-profile".to_owned()),
            dry_run: false,
            strict: false,
        })
        .expect("plan");
        let persisted = handle
            .begin_apply_persistence(workflow.storage_projection.clone(), &RunLimits::immediate())
            .expect("begin persistence");
        handle
            .advance_apply_phase(
                &persisted.journal,
                caly_storage::ApplyPhase::Cutover,
                1,
                1,
                &RunLimits::immediate(),
            )
            .expect("advance");
    }

    let handle = EngineHandle::with_backend(EngineState::new(), open(fs));
    let report = handle.scan_recovery_state().expect("scan");
    assert_eq!(report.unresolved_apply_journals.len(), 1);
    assert!(handle
        .latest_last_known_good_snapshot()
        .expect("lkg read")
        .is_none());
    assert!(
        matches!(
            report.decisions.as_slice(),
            [caly_storage::RecoveryDecision::RevertOsEffectsOnly { .. }]
        ),
        "net effects were recorded with nothing to roll back to: {:?}",
        report.decisions
    );
}

/// `STORAGE_RECOVERY_EXECUTION_PLAN.md §7`: a new deployment replaces the last-known-good
/// *marker*, but must not remove the previous snapshot it points at, because that record is what
/// an operator needs to reason about the incident.
#[test]
fn a_second_apply_moves_the_marker_without_erasing_the_previous_snapshot() {
    let fs = disk();
    let handle = EngineHandle::with_backend(EngineState::new(), open(fs.clone()));

    drain(&handle, apply_command("demo-tun-profile"));
    let first = handle
        .latest_last_known_good_snapshot()
        .expect("lkg")
        .expect("first lkg");
    let first_rel = format!(
        "{ROOT}/records/snapshot/{}.rec",
        first.id.0.replace(':', "_")
    );
    assert!(
        read_file(&fs, &first_rel).is_some(),
        "the first snapshot record must exist at {first_rel}"
    );

    drain(&handle, apply_command("demo-singbox-profile"));
    let second = handle
        .latest_last_known_good_snapshot()
        .expect("lkg")
        .expect("second lkg");
    assert_ne!(second.id, first.id, "the marker must move forward");
    assert_eq!(second.profile_id, "demo-singbox-profile");

    // The superseded snapshot stays readable, both through the store and on disk.
    let still_there = read_file(&fs, &first_rel).expect("previous snapshot must not be erased");
    assert!(
        still_there.contains(&first.semantic_digest),
        "{still_there}"
    );
    let reopened = FsStore::open(Box::new(fs) as Box<dyn Fs>, ROOT).expect("reopen");
    let fetched = block_on_ready(reopened.get_snapshot(&first.id))
        .expect("ready")
        .expect("read")
        .expect("the previous snapshot must still resolve by id");
    assert_eq!(fetched.id, first.id);
}

/// A torn write must be surfaced at open time by the engine's own view of the store.
#[test]
fn a_replaced_content_file_makes_the_store_refuse_to_open() {
    let fs = disk();
    {
        let handle = EngineHandle::with_backend(EngineState::new(), open(fs.clone()));
        drain(&handle, apply_command("demo-tun-profile"));
    }

    // Damage the CAS content, leaving the metadata record intact beside it. The anchor is read back
    // out of the on-disk metadata rather than passed in, and the file is *found by listing*, so this
    // proves the layout as well as the check.
    let meta_path = listed(&fs, &format!("{ROOT}/meta/objects"))
        .into_iter()
        .next()
        .expect("at least one object record");
    let anchor = read_file(&fs, &meta_path)
        .expect("object metadata")
        .lines()
        .find_map(|line| line.strip_prefix("content_sha256="))
        .expect("metadata carries the integrity anchor")
        .to_owned();
    let suffix = caly_storage::fs_store::content_suffix_for(&anchor);
    let path = VPath::try_from_str(&format!("{ROOT}/{suffix}")).expect("path");
    block_on_ready(fs.write_atomic(
        &path,
        b"corrupted-by-out-of-band-write".to_vec(),
        caly_io::Durability::D2,
        &ctx(),
    ))
    .expect("ready")
    .expect("tamper");

    let error = match FsStore::open(Box::new(fs) as Box<dyn Fs>, ROOT) {
        Ok(_) => panic!("a corrupted object must not open cleanly"),
        Err(error) => error,
    };
    assert!(
        error.summary.contains("no longer matches"),
        "the failure must name the integrity problem: {}",
        error.summary
    );
    // An engine cannot be built on a store that refuses to open, so there is no chance of it
    // reporting a healthy-looking empty state instead of the damage.
    assert!(
        FsStore::open(Box::new(disk()) as Box<dyn Fs>, ROOT).is_ok(),
        "control: a healthy root still opens"
    );
}
