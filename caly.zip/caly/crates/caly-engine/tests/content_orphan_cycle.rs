//! The orphan content cycle through the engine: the plan sees it, the job deletes it, and the
//! gates that refuse are the same gates every other deletion answers to.
//!
//! The storage layer (`crates/caly-storage/tests/content_sweep.rs`) pins the walk, the pure plan
//! and the store-side refusals. What only the engine can prove:
//!
//! * the walk's answer **reaches the plan** through the same reading half as every root class;
//! * a cycle **executes the orphan list it just planned**, under the `§13.2` eligibility and the
//!   root-completeness rule -- a plan with a content gap licenses no deletion at all;
//! * the **timeline** is the storage clock's, so "fresh" and "aged out" are the same fact here as
//!   they are on the disk;
//! * objects and content share **one** deletion budget, not two allowances.

use std::sync::Arc;

use caly_engine::{EngineHandle, EngineState, ExecutionPolicy, GcPlanBounds, GcPlanSummary};
use caly_io::{block_on_ready, Durability, Fs, IoContext, VPath};
use caly_io_sim::{FaultInjector, MemFs, SharedFaults, SimClock, SimFs, VirtualClock};
use caly_storage::cas::{CasObjectRef, CasWriteIntent, ObjectDigest, ObjectKind};
use caly_storage::execution::{ApplyJournalRecord, ApplyTxnId};
use caly_storage::fs_store::{content_suffix_for, FsStore};
use caly_storage::gc::ContentTarget;
use caly_storage::journal::JournalRecordId;
use caly_storage::revision::{RevisionId, RevisionRecord};
use caly_storage::snapshot::{SnapshotRecord, SnapshotRecordId};
use caly_storage::{
    ApplyJournalStore, JournalStore, ObjectStore, RevisionStore, SnapshotStore, StorageBackend,
    StorageError,
};

const ROOT: &str = "var/caly";
const START: i64 = 1_700_000_000_000;
const GRACE_MS: i64 = 15 * 60 * 1000;

fn ctx() -> IoContext {
    IoContext::new(
        caly_io::TraceId::new("content-cycle"),
        caly_io::Actor::System,
    )
}

fn object(digest: &str) -> CasObjectRef {
    CasObjectRef {
        digest: ObjectDigest(digest.to_owned()),
        kind: ObjectKind::RawSource,
        size_bytes: None,
        content_type: None,
        content_sha256: None,
        stored_at_unix_ms: None,
    }
}

/// A dated durable store on the simulator, mounted on an engine with the same clock -- the one
/// timeline the grace comparison needs (`ADR-038 §3`).
fn mount() -> (EngineHandle, Arc<FsStore>, Arc<SimClock>, SimFs) {
    let clock = Arc::new(SimClock::new(
        VirtualClock::new(START),
        SharedFaults::new(FaultInjector::new(1)),
    ));
    let fs =
        SimFs::new(MemFs::default(), SharedFaults::new(FaultInjector::new(1))).with_clock(&clock);
    let store = Arc::new(FsStore::open(Box::new(fs.clone()) as Box<dyn Fs>, ROOT).expect("open"));
    let handle = EngineHandle::with_backend(
        EngineState::new(),
        Arc::clone(&store) as Arc<dyn StorageBackend>,
    );
    handle
        .set_storage_clock(Some(Arc::clone(&clock) as Arc<dyn caly_engine::Clock>))
        .expect("storage clock");
    handle
        .set_execution_policy(ExecutionPolicy {
            clock_start_unix_ms: START,
            ..ExecutionPolicy::default()
        })
        .expect("policy");
    (handle, store, clock, fs)
}

fn plan(handle: &EngineHandle, grace: Option<i64>, cap: Option<u32>) -> GcPlanSummary {
    handle
        .storage_gc_plan(
            GcPlanBounds {
                grace_period_ms: grace,
                max_deletions: cap,
            }
            .resolve()
            .expect("bounds resolve"),
        )
        .expect("the plan query must answer")
}

fn orphan_on_disk(fs: &SimFs, payload: &[u8]) -> String {
    let anchor = caly_common::digest::sha256_digest(payload);
    let path = VPath::try_from_str(&format!("{ROOT}/{}", content_suffix_for(&anchor)))
        .expect("relative path");
    block_on_ready(fs.write_atomic(&path, payload.to_vec(), Durability::D2, &ctx()))
        .expect("no suspension")
        .expect("place the orphan a crashed writer leaves");
    anchor
}

/// The plan's content half answers with the same clock the store's dates came from: at the moment
/// of the write the orphan is fresh, one grace later it is not, and nobody advanced anything but
/// the injected timeline.
#[test]
fn an_orphan_ages_out_on_the_storage_clocks_timeline() {
    let (handle, _store, clock, fs) = mount();
    let anchor = orphan_on_disk(&fs, b"left behind by a crashed delete");

    let fresh = plan(&handle, None, None);
    assert_eq!(fresh.content_total, 1, "{fresh:?}");
    assert_eq!(fresh.orphan_sweep, Vec::new(), "fresh is kept: {fresh:?}");
    assert_eq!(fresh.orphan_skipped_for_grace, 1, "{fresh:?}");

    clock
        .advance_ms(GRACE_MS.try_into().expect("fits in u64"))
        .expect("advance the injected timeline");
    let aged = plan(&handle, None, None);
    assert_eq!(
        aged.orphan_sweep,
        vec![ContentTarget::Anchor(anchor)],
        "aged out on the same timeline: {aged:?}"
    );
    assert_eq!(aged.orphan_skipped_for_grace, 0, "{aged:?}");
    assert!(
        aged.summary_line()
            .contains("content_orphans=1 content_collect=1"),
        "the one sentence carries the content half: {}",
        aged.summary_line()
    );
}

/// The job executes the orphan list the plan carried: the file leaves the disk, the run record
/// names it, and a re-plan answers empty. `deleted=0 content_deleted=1` is exactly the shape a
/// store whose disk grew while nothing else changed produces.
#[test]
fn a_cycle_deletes_the_orphan_it_planned_and_says_so() {
    let (handle, store, clock, fs) = mount();
    let anchor = orphan_on_disk(&fs, b"the crash leftover a cycle must take");
    clock
        .advance_ms(GRACE_MS.try_into().expect("fits in u64"))
        .expect("age the orphan out");

    let record = handle
        .storage_gc_collect(GcPlanBounds::default().resolve().expect("bounds"), None)
        .expect("the cycle runs");
    assert!(record.collected.is_empty(), "no objects went: {record:?}");
    assert_eq!(
        record.collected_content,
        vec![anchor.clone()],
        "the orphan did: {record:?}"
    );
    assert!(
        record.summary_line().contains("deleted=0")
            && record.summary_line().contains("content_deleted=1"),
        "the record's one sentence separates the two lists: {}",
        record.summary_line()
    );

    let after = plan(&handle, None, None);
    assert_eq!(after.content_total, 0, "the disk answered: {after:?}");
    assert!(
        block_on_ready(store.list_content(&ctx()))
            .expect("no suspension")
            .expect("walk")
            .is_empty(),
        "the re-walk agrees the tree is empty"
    );
}

/// Referenced content is invisible to the sweep *through the engine too*: the plan may see the
/// file, but no list it produces names it, and no cycle takes it.
#[test]
fn content_somebody_owns_never_reaches_a_deletion_list() {
    let (handle, _store, _clock, _fs) = mount();
    let written = handle
        .put_object(CasWriteIntent {
            object: object("obj:owned"),
            source_label: "owned.txt".to_owned(),
            payload: b"bytes a live object owns".to_vec(),
            stored_at_unix_ms: 0,
        })
        .expect("write");
    let anchor = written.content_sha256.expect("anchor");

    let summary = plan(&handle, Some(0), None);
    assert_eq!(summary.content_total, 1, "the file is visible: {summary:?}");
    assert!(
        summary.orphan_sweep.is_empty(),
        "but no deletion list names it: {summary:?}"
    );
    assert_eq!(summary.orphan_skipped_for_grace, 0, "{summary:?}");
    drop(anchor);
}

/// Objects and content draw on **one** budget: with room for two deletions, an old object and two
/// old orphans become one object, one orphan, and one deferral -- not three deletions.
#[test]
fn objects_and_content_share_one_deletion_budget() {
    let (handle, _store, clock, fs) = mount();
    handle
        .put_object(CasWriteIntent {
            object: object("obj:unreferenced"),
            source_label: "unreferenced.txt".to_owned(),
            payload: b"an old object nobody references".to_vec(),
            stored_at_unix_ms: 0,
        })
        .expect("write");
    orphan_on_disk(&fs, b"orphan one");
    orphan_on_disk(&fs, b"orphan two");
    clock
        .advance_ms(GRACE_MS.try_into().expect("fits in u64"))
        .expect("age everything out");

    let summary = plan(&handle, Some(0), Some(2));
    assert_eq!(
        summary.collect.len() + summary.orphan_sweep.len(),
        2,
        "one bound, both populations: {summary:?}"
    );
    assert_eq!(
        summary.deferred_over_cap + summary.orphan_deferred_over_cap,
        1,
        "the third deletion defers visibly: {summary:?}"
    );
}

/// A backend that cannot walk its tree is a **gap**, and a plan with this gap licenses no
/// deletion: `roots_complete` goes false, `would_run` goes false, and a cycle records a refusal
/// while the store keeps every byte. This is the wiring `Unsupported` has to hit -- treating it as
/// "no content" instead would turn a blind backend into a silently-clean one.
#[test]
fn an_unwalkable_backend_is_a_gap_and_the_cycle_deletes_nothing() {
    let inner = Arc::new(caly_storage::InMemoryStorage::new());
    inner.keep_orphan_content("sha256:ee", b"content the wrapper cannot see");
    let handle = EngineHandle::with_backend(
        EngineState::new(),
        Arc::new(NoContentWalk {
            inner: Arc::clone(&inner) as Arc<dyn StorageBackend>,
        }) as Arc<dyn StorageBackend>,
    );

    let summary = plan(&handle, None, None);
    assert!(
        summary.gaps.iter().any(|gap| gap.class == "content-tree"),
        "the capability answer is a gap, not silence: {:?}",
        summary.gaps
    );
    assert!(
        !summary.roots_complete() && !summary.would_run(),
        "{summary:?}"
    );
    assert!(
        summary.orphan_sweep.is_empty(),
        "a blind plan licenses no deletion list: {summary:?}"
    );

    let record = handle
        .storage_gc_collect(GcPlanBounds::default().resolve().expect("bounds"), None)
        .expect("the refusal is a record, not an error");
    assert!(
        record.refused.is_some(),
        "the cycle must say why it did not run: {record:?}"
    );
    assert!(
        record.collected.is_empty() && record.collected_content.is_empty(),
        "and must have deleted nothing: {record:?}"
    );
    let still_there = block_on_ready(inner.list_content(&ctx()))
        .expect("no suspension")
        .expect("walk the inner store directly");
    assert_eq!(
        still_there.len(),
        1,
        "the orphan the wrapper could not see is still there: {still_there:?}"
    );
}

/// Damage in the tree is a gap the plan *reports* rather than a query that dies: every other line
/// an operator needs is still in the answer, and the deletion lists are empty because a refusal
/// over half a view is the wrong shape for a deletion list.
#[test]
fn damage_in_the_tree_is_a_reported_gap_not_a_dead_query() {
    let (handle, _store, _clock, fs) = mount();
    orphan_on_disk(&fs, b"a legitimate orphan");
    let stray = VPath::try_from_str(&format!("{ROOT}/objects/sha256/zz")).expect("path");
    block_on_ready(fs.write_atomic(
        &stray,
        b"a file where a directory belongs".to_vec(),
        Durability::D1,
        &ctx(),
    ))
    .expect("no suspension")
    .expect("place the damage");

    let summary = plan(&handle, None, None);
    assert!(
        summary
            .gaps
            .iter()
            .any(|gap| gap.class == "content-tree" && gap.detail.contains("walk")),
        "the damage is named: {:?}",
        summary.gaps
    );
    assert!(!summary.roots_complete(), "{summary:?}");
    assert!(
        summary.orphan_sweep.is_empty(),
        "no deletion list over a damaged view: {summary:?}"
    );
    assert_eq!(
        summary.objects_total, 0,
        "the rest of the answer is still there: {summary:?}"
    );
}

// ---------------------------------------------------------------------------
// the wrapper backend: everything delegates, the content walk does not exist
// ---------------------------------------------------------------------------

struct NoContentWalk {
    inner: Arc<dyn StorageBackend>,
}

impl ObjectStore for NoContentWalk {
    fn put<'a>(
        &'a self,
        intent: CasWriteIntent,
        ctx: &'a IoContext,
    ) -> caly_storage::BoxFuture<'a, Result<CasObjectRef, StorageError>> {
        self.inner.put(intent, ctx)
    }
    fn get<'a>(
        &'a self,
        digest: &'a str,
        ctx: &'a IoContext,
    ) -> caly_storage::BoxFuture<'a, Result<Option<CasObjectRef>, StorageError>> {
        self.inner.get(digest, ctx)
    }
    fn materialize<'a>(
        &'a self,
        request: caly_storage::cas::MaterializationRequest,
        ctx: &'a IoContext,
    ) -> caly_storage::BoxFuture<'a, Result<(), StorageError>> {
        self.inner.materialize(request, ctx)
    }
    fn list_objects<'a>(
        &'a self,
        ctx: &'a IoContext,
    ) -> caly_storage::BoxFuture<'a, Result<Vec<CasObjectRef>, StorageError>> {
        self.inner.list_objects(ctx)
    }
    fn delete<'a>(
        &'a self,
        digest: &'a str,
        ctx: &'a IoContext,
    ) -> caly_storage::BoxFuture<'a, Result<bool, StorageError>> {
        self.inner.delete(digest, ctx)
    }
    // `list_content` / `delete_content` / `read_object` stay at their `Unsupported` defaults --
    // that is the capability this wrapper exists to withhold.
}

impl RevisionStore for NoContentWalk {
    fn put_revision<'a>(
        &'a self,
        record: RevisionRecord,
        ctx: &'a IoContext,
    ) -> caly_storage::BoxFuture<'a, Result<(), StorageError>> {
        self.inner.put_revision(record, ctx)
    }
    fn get_revision<'a>(
        &'a self,
        revision_id: &'a RevisionId,
        ctx: &'a IoContext,
    ) -> caly_storage::BoxFuture<'a, Result<Option<RevisionRecord>, StorageError>> {
        self.inner.get_revision(revision_id, ctx)
    }
}

impl SnapshotStore for NoContentWalk {
    fn put_snapshot<'a>(
        &'a self,
        record: SnapshotRecord,
        ctx: &'a IoContext,
    ) -> caly_storage::BoxFuture<'a, Result<(), StorageError>> {
        self.inner.put_snapshot(record, ctx)
    }
    fn get_snapshot<'a>(
        &'a self,
        snapshot_id: &'a SnapshotRecordId,
        ctx: &'a IoContext,
    ) -> caly_storage::BoxFuture<'a, Result<Option<SnapshotRecord>, StorageError>> {
        self.inner.get_snapshot(snapshot_id, ctx)
    }
    fn latest_last_known_good<'a>(
        &'a self,
        ctx: &'a IoContext,
    ) -> caly_storage::BoxFuture<'a, Result<Option<SnapshotRecord>, StorageError>> {
        self.inner.latest_last_known_good(ctx)
    }
}

impl JournalStore for NoContentWalk {
    fn put_journal<'a>(
        &'a self,
        record: caly_storage::journal::JournalRecord,
        ctx: &'a IoContext,
    ) -> caly_storage::BoxFuture<'a, Result<(), StorageError>> {
        self.inner.put_journal(record, ctx)
    }
    fn get_journal<'a>(
        &'a self,
        journal_id: &'a JournalRecordId,
        ctx: &'a IoContext,
    ) -> caly_storage::BoxFuture<
        'a,
        Result<Option<caly_storage::journal::JournalRecord>, StorageError>,
    > {
        self.inner.get_journal(journal_id, ctx)
    }
    fn list_pending<'a>(
        &'a self,
        ctx: &'a IoContext,
    ) -> caly_storage::BoxFuture<'a, Result<Vec<caly_storage::journal::JournalRecord>, StorageError>>
    {
        self.inner.list_pending(ctx)
    }
}

impl ApplyJournalStore for NoContentWalk {
    fn put_apply_journal<'a>(
        &'a self,
        record: ApplyJournalRecord,
        ctx: &'a IoContext,
    ) -> caly_storage::BoxFuture<'a, Result<(), StorageError>> {
        self.inner.put_apply_journal(record, ctx)
    }
    fn get_apply_journal<'a>(
        &'a self,
        apply_txn_id: &'a ApplyTxnId,
        ctx: &'a IoContext,
    ) -> caly_storage::BoxFuture<'a, Result<Option<ApplyJournalRecord>, StorageError>> {
        self.inner.get_apply_journal(apply_txn_id, ctx)
    }
    fn list_pending_apply<'a>(
        &'a self,
        ctx: &'a IoContext,
    ) -> caly_storage::BoxFuture<'a, Result<Vec<ApplyJournalRecord>, StorageError>> {
        self.inner.list_pending_apply(ctx)
    }
    fn list_unresolved_apply<'a>(
        &'a self,
        ctx: &'a IoContext,
    ) -> caly_storage::BoxFuture<'a, Result<Vec<ApplyJournalRecord>, StorageError>> {
        self.inner.list_unresolved_apply(ctx)
    }
}

impl StorageBackend for NoContentWalk {}
