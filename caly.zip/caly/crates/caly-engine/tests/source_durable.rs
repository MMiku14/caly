//! Durable source-index coverage using the real subscription fixture.
//!
//! The source worker must not treat process memory as the source of truth: a second worker over a
//! reopened `FsStore` has to recover the endpoint, validators, raw CAS reference, normalized nodes,
//! diagnostics, and parser provenance before it can accept a `304`.

use std::sync::{Arc, Mutex};

use caly_common::redact::{Redactor, REDACTED};
use caly_common::{Actor, CancelToken, RequestContext, TraceId};
use caly_engine::{
    EngineHandle, EngineState, HttpSourceUpdateWorker, SourceEndpoint, SourceUpdateWorker,
};
use caly_io::{
    block_on_ready, ByteCap, Clock, Durability, FetchBody, FetchReq, FetchResp, Fs, Http,
    IoContext, IoFault, IoFaultKind,
};
use caly_io_sim::{FaultInjector, MemFs, SharedFaults, SimClock, SimFs, VirtualClock};
use caly_ir::SourceId;
use caly_storage::fs_store::{content_suffix_for, escape_component, FsStore};
use caly_storage::{
    ApplyJournalRecord, ApplyJournalStore, ApplyTxnId, BoxFuture, CasObjectRef, CasWriteIntent,
    InMemoryStorage, JournalRecord, JournalRecordId, JournalStore, MaterializationRequest,
    ObjectStore, RevisionId, RevisionRecord, RevisionStore, SnapshotRecord, SnapshotRecordId,
    SnapshotStore, StorageBackend, StorageError,
};

const ROOT: &str = "var/caly";
const SOURCE_ID: &str = "fixture-source";
const LOCATOR: &str = "https://fixture.invalid/subscription";

fn ctx() -> RequestContext {
    RequestContext::new(TraceId::new("source-durable-test"), Actor::System)
}

fn fixture() -> Vec<u8> {
    std::fs::read(concat!(
        env!("CARGO_MANIFEST_DIR"),
        "/../../fixtures/subscription-20260803.txt"
    ))
    .expect("real subscription fixture")
}

fn ready<T>(future: caly_io::BoxFuture<'_, Result<T, StorageError>>) -> Result<T, StorageError> {
    block_on_ready(future).expect("storage future must be ready")
}

fn seeded_durable_fixture() -> (SimFs, caly_storage::SourceIndexRecord) {
    let disk = SimFs::new(MemFs::default(), SharedFaults::default());
    let store = FsStore::open(Box::new(disk.clone()), ROOT).expect("fresh store");
    let backend: Arc<dyn StorageBackend> = Arc::new(store);
    let http = Arc::new(ConditionalFixtureHttp::new(fixture()));
    let worker = HttpSourceUpdateWorker::new(http, backend.clone()).expect("worker startup");
    worker.register(endpoint()).expect("explicit endpoint");
    worker.update(SOURCE_ID, &ctx()).expect("fixture update");
    let record = ready(backend.get_source_index(SOURCE_ID, &ctx()))
        .expect("source index read")
        .expect("durable source index");
    drop(worker);
    drop(backend);
    (disk, record)
}

#[derive(Clone)]
struct ConditionalFixtureHttp {
    body: Arc<Vec<u8>>,
    requests: Arc<Mutex<Vec<FetchReq>>>,
}

impl ConditionalFixtureHttp {
    fn new(body: Vec<u8>) -> Self {
        Self {
            body: Arc::new(body),
            requests: Arc::new(Mutex::new(Vec::new())),
        }
    }
}

impl Http for ConditionalFixtureHttp {
    fn fetch<'a>(
        &'a self,
        request: FetchReq,
        _ctx: &'a IoContext,
    ) -> caly_io::BoxFuture<'a, Result<FetchResp, IoFault>> {
        let body = Arc::clone(&self.body);
        let requests = Arc::clone(&self.requests);
        Box::pin(async move {
            requests
                .lock()
                .map_err(|_| IoFault::new(IoFaultKind::InternalIo, "request log poisoned"))?
                .push(request.clone());
            let conditional = request.etag.is_some() || request.if_modified_since.is_some();
            Ok(FetchResp {
                status: if conditional { 304 } else { 200 },
                etag: Some("\"fixture-v1\"".to_owned()),
                last_modified: Some("Sat, 03 Aug 2026 00:00:00 GMT".to_owned()),
                body: FetchBody {
                    label: format!("http:{}", request.url),
                    bytes: if conditional {
                        Vec::new()
                    } else {
                        (*body).clone()
                    },
                },
            })
        })
    }
}

/// A fixture-backed port that cancels after returning a complete HTTP response. The worker's
/// post-fetch boundary must observe this and refuse before parser/CAS work starts.
#[derive(Clone)]
struct CancelAfterFixtureHttp {
    body: Arc<Vec<u8>>,
    requests: Arc<Mutex<Vec<FetchReq>>>,
}

impl CancelAfterFixtureHttp {
    fn new(body: Vec<u8>) -> Self {
        Self {
            body: Arc::new(body),
            requests: Arc::new(Mutex::new(Vec::new())),
        }
    }
}

impl Http for CancelAfterFixtureHttp {
    fn fetch<'a>(
        &'a self,
        request: FetchReq,
        ctx: &'a IoContext,
    ) -> caly_io::BoxFuture<'a, Result<FetchResp, IoFault>> {
        let body = Arc::clone(&self.body);
        let requests = Arc::clone(&self.requests);
        Box::pin(async move {
            requests
                .lock()
                .map_err(|_| IoFault::new(IoFaultKind::InternalIo, "request log poisoned"))?
                .push(request.clone());
            ctx.cancel.cancel();
            Ok(FetchResp {
                status: 200,
                etag: None,
                last_modified: None,
                body: FetchBody {
                    label: format!("http:{}", request.url),
                    bytes: (*body).clone(),
                },
            })
        })
    }
}

/// The same fixture, but the simulated monotonic clock advances while the HTTP future completes.
/// This makes the post-fetch deadline probe deterministic without using a host clock.
#[derive(Clone)]
struct AdvanceClockAfterFixtureHttp {
    body: Arc<Vec<u8>>,
    clock: Arc<SimClock>,
}

impl Http for AdvanceClockAfterFixtureHttp {
    fn fetch<'a>(
        &'a self,
        request: FetchReq,
        _ctx: &'a IoContext,
    ) -> caly_io::BoxFuture<'a, Result<FetchResp, IoFault>> {
        let body = Arc::clone(&self.body);
        let clock = Arc::clone(&self.clock);
        Box::pin(async move {
            clock.advance_ms(10)?;
            Ok(FetchResp {
                status: 200,
                etag: None,
                last_modified: None,
                body: FetchBody {
                    label: format!("http:{}", request.url),
                    bytes: (*body).clone(),
                },
            })
        })
    }
}

fn endpoint() -> SourceEndpoint {
    SourceEndpoint::subscription_named(SOURCE_ID, "Fixture subscription", LOCATOR, 4 * 1024 * 1024)
}

#[test]
fn a_reopened_worker_reuses_the_fixture_on_304_with_all_provenance_intact() {
    let disk = SimFs::new(MemFs::default(), SharedFaults::new(FaultInjector::new(1)));
    let http = Arc::new(ConditionalFixtureHttp::new(fixture()));

    let first = {
        let store = FsStore::open(Box::new(disk.clone()), ROOT).expect("fresh store");
        let backend: Arc<dyn StorageBackend> = Arc::new(store);
        let worker = HttpSourceUpdateWorker::new(http.clone(), backend).expect("worker startup");
        worker.register(endpoint()).expect("explicit endpoint");
        worker
            .update(SOURCE_ID, &ctx())
            .expect("initial fixture update")
    };
    assert_eq!(first.normalized.nodes.len(), 30);
    assert_eq!(first.provenance.entries.len(), 1);

    let reopened_store = FsStore::open(Box::new(disk.clone()), ROOT).expect("reopen store");
    let reopened_backend: Arc<dyn StorageBackend> = Arc::new(reopened_store);
    let reopened_worker = HttpSourceUpdateWorker::new(http.clone(), reopened_backend.clone())
        .expect("restore worker");
    assert_eq!(
        reopened_worker
            .endpoint(SOURCE_ID)
            .expect("endpoint lookup")
            .expect("endpoint restored")
            .locator(),
        LOCATOR
    );
    let inspected = reopened_worker
        .inspect_durable(SOURCE_ID, &ctx())
        .expect("durable inspection")
        .expect("durable source record");
    let inspected_api = caly_engine::project_source_inspection(
        inspected,
        &caly_common::redact::Redactor::default(),
    );
    assert_eq!(inspected_api.summary.id.0, SOURCE_ID);
    assert_eq!(inspected_api.locator.as_deref(), Some(LOCATOR));
    assert_eq!(
        inspected_api.latest_digest,
        Some(first.raw.content_digest.0.clone())
    );
    assert_eq!(
        inspected_api.raw_object_digest,
        Some(first.raw_object.digest.0.clone())
    );
    assert_eq!(inspected_api.raw_bytes_len, Some(first.raw.bytes_len));
    assert_eq!(inspected_api.normalized_node_count, 30);
    assert_eq!(inspected_api.provenance.len(), 1);
    assert_eq!(inspected_api.diagnostics, Vec::new());
    let handle = EngineHandle::with_backend(EngineState::new(), reopened_backend.clone());
    handle
        .set_source_update_worker(Arc::new(reopened_worker))
        .expect("install restored worker");
    assert_eq!(
        handle
            .cached_source(SOURCE_ID)
            .expect("engine cache lookup")
            .expect("normalized cache restored")
            .nodes
            .len(),
        30
    );

    let second = handle
        .source_update(SOURCE_ID, &ctx())
        .expect("304 fixture reuse");
    assert!(second.reused_raw_body);
    assert_eq!(second.raw, first.raw);
    assert_eq!(second.normalized, first.normalized);
    assert_eq!(second.provenance, first.provenance);
    assert_eq!(second.diagnostics, first.diagnostics);
    assert_eq!(second.raw_object, first.raw_object);

    let requests = http.requests.lock().expect("request log");
    assert_eq!(requests.len(), 2);
    assert_eq!(requests[1].url, LOCATOR);
    assert_eq!(requests[1].etag, Some("\"fixture-v1\"".to_owned()));
    assert_eq!(
        requests[1].if_modified_since,
        Some("Sat, 03 Aug 2026 00:00:00 GMT".to_owned())
    );
    drop(requests);

    let records =
        ready(reopened_backend.list_source_indexes(&ctx())).expect("source index listing");
    assert_eq!(records.len(), 1);
    assert_eq!(records[0].source_id, SOURCE_ID);
    assert_eq!(records[0].raw_object_digest, second.raw_object.digest.0);

    let changed = SourceEndpoint::subscription_named(
        SOURCE_ID,
        "Fixture subscription moved",
        "https://fixture.invalid/subscription-v2",
        4 * 1024 * 1024,
    );
    handle
        .register_source_endpoint(changed)
        .expect("durable locator invalidation");
    assert!(ready(reopened_backend.list_source_indexes(&ctx()))
        .expect("source index listing after invalidation")
        .is_empty());
    let restarted_after_change = HttpSourceUpdateWorker::new(http, reopened_backend)
        .expect("worker startup after locator invalidation");
    assert!(restarted_after_change
        .endpoint(SOURCE_ID)
        .expect("endpoint lookup after invalidation")
        .is_none());
}

#[test]
fn inspection_projection_redacts_fixture_locator_label_validator_and_provenance() {
    let secret = "fixture-secret-token";
    let endpoint = SourceEndpoint::subscription(
        SourceId::new(SOURCE_ID),
        format!("fixture label {secret}"),
        format!("https://fixture.invalid/subscription?token={secret}"),
        4 * 1024 * 1024,
    );
    let http = Arc::new(ConditionalFixtureHttp::new(fixture()));
    let backend: Arc<dyn StorageBackend> = Arc::new(caly_storage::InMemoryStorage::new());
    let worker = HttpSourceUpdateWorker::new(http, backend).expect("worker startup");
    worker
        .register(endpoint.clone())
        .expect("explicit secret-bearing endpoint");
    let mut report = worker.update(SOURCE_ID, &ctx()).expect("fixture update");
    // Validators are durable operator-visible text too; make the assertion cover that field rather
    // than only relying on URL query redaction.
    report.etag = Some(secret.to_owned());
    let durable = caly_engine::SourceInspectionReport {
        endpoint,
        report,
        updated_at_unix_ms: 1_750_000_000_000,
    };
    let mut redactor = Redactor::default();
    redactor.register_secret(secret);
    let api = caly_engine::project_source_inspection(durable, &redactor);
    let rendered = format!("{api:?}");
    assert!(
        !rendered.contains(secret),
        "projection leaked registered secret: {rendered}"
    );
    assert!(
        rendered.contains(REDACTED),
        "projection did not leave a redaction marker: {rendered}"
    );
    assert_eq!(api.summary.label, format!("fixture label {REDACTED}"));
    assert_eq!(api.etag.as_deref(), Some(REDACTED));
    assert!(api
        .latest_digest
        .as_ref()
        .is_some_and(|digest| !digest.is_empty()));
    assert!(api
        .raw_object_digest
        .as_ref()
        .is_some_and(|digest| !digest.is_empty()));
    assert_eq!(api.raw_bytes_len, Some(fixture().len() as u64));
    assert_eq!(api.provenance.len(), 1);
    let expected_locator = format!("https://fixture.invalid/subscription?token={REDACTED}");
    assert_eq!(
        api.provenance[0].locator.as_deref(),
        Some(expected_locator.as_str())
    );
}

#[test]
fn a_cancelled_source_update_never_starts_http_or_cas() {
    let http = Arc::new(ConditionalFixtureHttp::new(fixture()));
    let backend: Arc<dyn StorageBackend> = Arc::new(caly_storage::InMemoryStorage::new());
    let worker =
        HttpSourceUpdateWorker::new(http.clone(), backend.clone()).expect("worker startup");
    worker.register(endpoint()).expect("explicit endpoint");

    let token = CancelToken::new();
    token.cancel();
    let mut caller = ctx();
    caller.cancel = token;
    let error = worker
        .update(SOURCE_ID, &caller)
        .expect_err("cancelled source update");
    assert!(error.contains("CallerCancelled"), "{error}");
    assert!(
        http.requests.lock().expect("request log").is_empty(),
        "a pre-cancelled call must not reach the HTTP port"
    );
    assert!(ready(backend.list_source_indexes(&ctx()))
        .expect("source index listing")
        .is_empty());
}

#[test]
fn an_expired_source_deadline_refuses_before_http_with_the_injected_clock() {
    let clock = Arc::new(SimClock::new(
        VirtualClock::new(1_750_000_000_000),
        SharedFaults::default(),
    ));
    let http = Arc::new(ConditionalFixtureHttp::new(fixture()));
    let backend: Arc<dyn StorageBackend> = Arc::new(caly_storage::InMemoryStorage::new());
    let worker = HttpSourceUpdateWorker::new(http.clone(), backend)
        .expect("worker startup")
        .with_clock(Arc::clone(&clock) as Arc<dyn Clock>);
    worker.register(endpoint()).expect("explicit endpoint");

    let mut caller = ctx();
    caller.deadline_mono_ms = Some(0);
    let error = worker
        .update(SOURCE_ID, &caller)
        .expect_err("expired source deadline");
    assert!(error.contains("DeadlineExpired"), "{error}");
    assert!(http.requests.lock().expect("request log").is_empty());
}

#[test]
fn cancellation_after_http_is_observed_before_source_parse_and_cas() {
    let http = Arc::new(CancelAfterFixtureHttp::new(fixture()));
    let backend: Arc<dyn StorageBackend> = Arc::new(caly_storage::InMemoryStorage::new());
    let worker =
        HttpSourceUpdateWorker::new(http.clone(), backend.clone()).expect("worker startup");
    worker.register(endpoint()).expect("explicit endpoint");

    let error = worker
        .update(SOURCE_ID, &ctx())
        .expect_err("post-fetch cancellation");
    assert!(error.contains("CallerCancelled"), "{error}");
    assert_eq!(http.requests.lock().expect("request log").len(), 1);
    assert!(ready(backend.list_source_indexes(&ctx()))
        .expect("source index listing")
        .is_empty());
}

#[test]
fn a_deadline_crossed_by_http_is_observed_before_cas() {
    let clock = Arc::new(SimClock::new(
        VirtualClock::new(1_750_000_000_000),
        SharedFaults::default(),
    ));
    let http = Arc::new(AdvanceClockAfterFixtureHttp {
        body: Arc::new(fixture()),
        clock: Arc::clone(&clock),
    });
    let backend: Arc<dyn StorageBackend> = Arc::new(caly_storage::InMemoryStorage::new());
    let worker = HttpSourceUpdateWorker::new(http, backend.clone())
        .expect("worker startup")
        .with_clock(Arc::clone(&clock) as Arc<dyn Clock>);
    worker.register(endpoint()).expect("explicit endpoint");

    let mut caller = ctx();
    caller.deadline_mono_ms = Some(5);
    let error = worker
        .update(SOURCE_ID, &caller)
        .expect_err("deadline crossed during HTTP");
    assert!(error.contains("DeadlineExpired"), "{error}");
    assert!(ready(backend.list_source_indexes(&ctx()))
        .expect("source index listing")
        .is_empty());
}

#[test]
fn a_missing_raw_object_refuses_durable_worker_restore() {
    let (disk, record) = seeded_durable_fixture();
    let metadata_path = caly_io::VPath::try_from_str(&format!(
        "{ROOT}/meta/objects/{}.obj",
        escape_component(&record.raw_object_digest)
    ))
    .expect("raw metadata path");
    block_on_ready(disk.remove(&metadata_path, &ctx()))
        .expect("fs future must be ready")
        .expect("remove raw metadata");

    let store = FsStore::open(Box::new(disk), ROOT).expect("store can open before worker restore");
    let error = match HttpSourceUpdateWorker::new(
        Arc::new(ConditionalFixtureHttp::new(fixture())),
        Arc::new(store),
    ) {
        Ok(_) => panic!("a source index pointing at a missing object must refuse restore"),
        Err(error) => error,
    };
    assert!(error.contains("references missing raw object"), "{error}");
}

#[test]
fn corrupt_raw_bytes_refuse_durable_worker_restore_even_when_metadata_survives() {
    let (disk, record) = seeded_durable_fixture();
    let content_path = caly_io::VPath::try_from_str(&format!(
        "{ROOT}/{}",
        content_suffix_for(&record.raw_content_sha256)
    ))
    .expect("raw content path");
    block_on_ready(disk.write_atomic(
        &content_path,
        b"corrupted fixture bytes".to_vec(),
        Durability::D2,
        &ctx(),
    ))
    .expect("fs future must be ready")
    .expect("overwrite raw content for corruption drill");

    let error = match FsStore::open(Box::new(disk), ROOT) {
        Ok(store) => match HttpSourceUpdateWorker::new(
            Arc::new(ConditionalFixtureHttp::new(fixture())),
            Arc::new(store),
        ) {
            Ok(_) => panic!("corrupt raw bytes must refuse restore"),
            Err(error) => error,
        },
        Err(error) => error.summary,
    };
    assert!(
        error.contains("content no longer matches")
            || error.contains("raw CAS bytes disagree with their durable anchors")
            || error.contains("failed integrity verification"),
        "{error}"
    );
}

#[test]
fn a_corrupt_source_record_refuses_the_next_store_open() {
    let disk = SimFs::new(MemFs::default(), SharedFaults::new(FaultInjector::new(1)));
    let http = Arc::new(ConditionalFixtureHttp::new(fixture()));
    {
        let store = FsStore::open(Box::new(disk.clone()), ROOT).expect("fresh store");
        let backend: Arc<dyn StorageBackend> = Arc::new(store);
        let worker = HttpSourceUpdateWorker::new(http, backend).expect("worker startup");
        worker.register(endpoint()).expect("explicit endpoint");
        worker.update(SOURCE_ID, &ctx()).expect("fixture update");
    }

    let record_path = caly_io::VPath::try_from_str(&format!(
        "{ROOT}/records/source-index/{}.rec",
        escape_component(SOURCE_ID)
    ))
    .expect("source record path");
    block_on_ready(disk.write_atomic(
        &record_path,
        b"record:v2\n".to_vec(),
        caly_io::Durability::D3,
        &ctx(),
    ))
    .expect("fs future must be ready")
    .expect("corruption write");

    let error =
        FsStore::open(Box::new(disk), ROOT).expect_err("bad source record must refuse boot");
    assert!(error.summary.contains("source-index"), "{}", error.summary);
    assert!(
        error.summary.contains("unsupported record tag"),
        "{}",
        error.summary
    );
}

/// A backend that hands back raw CAS bytes **without verifying them** — or says they are gone.
///
/// `FsStore` and `InMemoryStorage` both verify content on read, so on the shipping backends the
/// worker's own 304-time guards (`cached raw body is missing`, `failed its digest anchor on 304
/// reuse`) can never fire: the store refuses first. Those guards exist because `StorageBackend`
/// is a seam — a future remote or less-strict backend may not verify — and an unverifiable claim
/// is what `docs/ONBOARDING_NOTES.md §4.121` calls a guard without a reachable judge. This double
/// is the judge: it delegates everything to `InMemoryStorage` and only lies about `read_object`,
/// exactly the shape a backend that skips read verification would have.
/// The `read_object` lie: `(digest, replacement bytes)` answers for the digest instead of the payload.
type TamperedRead = Arc<Mutex<Option<(String, Vec<u8>)>>>;

#[derive(Clone, Default)]
struct UnverifiedRawStorage {
    inner: InMemoryStorage,
    /// When set to a digest, `read_object` answers `Ok(None)` for it instead of delegating.
    missing_digest: Arc<Mutex<Option<String>>>,
    /// When set to `(digest, bytes)`, `read_object` returns those bytes instead of the payload.
    tampered_read: TamperedRead,
}

impl UnverifiedRawStorage {
    fn new() -> Self {
        Self::default()
    }

    fn make_missing(&self, digest: &str) {
        *self.missing_digest.lock().expect("missing mode lock") = Some(digest.to_owned());
    }

    fn make_tampered(&self, digest: &str, bytes: Vec<u8>) {
        *self.tampered_read.lock().expect("tamper mode lock") = Some((digest.to_owned(), bytes));
    }
}

impl ObjectStore for UnverifiedRawStorage {
    fn put<'a>(
        &'a self,
        intent: CasWriteIntent,
        ctx: &'a IoContext,
    ) -> BoxFuture<'a, Result<CasObjectRef, StorageError>> {
        self.inner.put(intent, ctx)
    }

    fn get<'a>(
        &'a self,
        digest: &'a str,
        ctx: &'a IoContext,
    ) -> BoxFuture<'a, Result<Option<CasObjectRef>, StorageError>> {
        self.inner.get(digest, ctx)
    }

    fn materialize<'a>(
        &'a self,
        request: MaterializationRequest,
        ctx: &'a IoContext,
    ) -> BoxFuture<'a, Result<(), StorageError>> {
        self.inner.materialize(request, ctx)
    }

    fn list_objects<'a>(
        &'a self,
        ctx: &'a IoContext,
    ) -> BoxFuture<'a, Result<Vec<CasObjectRef>, StorageError>> {
        self.inner.list_objects(ctx)
    }

    fn read_object<'a>(
        &'a self,
        digest: &'a str,
        max_bytes: u64,
        ctx: &'a IoContext,
    ) -> BoxFuture<'a, Result<Option<Vec<u8>>, StorageError>> {
        let disposed = self
            .missing_digest
            .lock()
            .expect("missing mode lock")
            .as_deref()
            .map(|armed| armed == digest)
            .unwrap_or(false);
        if disposed {
            return Box::pin(async move { Ok(None) });
        }
        let tampered = self
            .tampered_read
            .lock()
            .expect("tamper mode lock")
            .clone()
            .filter(|(armed, _)| armed == digest)
            .map(|(_, bytes)| bytes);
        if let Some(bytes) = tampered {
            return Box::pin(async move { Ok(Some(bytes)) });
        }
        self.inner.read_object(digest, max_bytes, ctx)
    }

    fn delete<'a>(
        &'a self,
        digest: &'a str,
        ctx: &'a IoContext,
    ) -> BoxFuture<'a, Result<bool, StorageError>> {
        self.inner.delete(digest, ctx)
    }
}

impl RevisionStore for UnverifiedRawStorage {
    fn put_revision<'a>(
        &'a self,
        record: RevisionRecord,
        ctx: &'a IoContext,
    ) -> BoxFuture<'a, Result<(), StorageError>> {
        self.inner.put_revision(record, ctx)
    }

    fn get_revision<'a>(
        &'a self,
        revision_id: &'a RevisionId,
        ctx: &'a IoContext,
    ) -> BoxFuture<'a, Result<Option<RevisionRecord>, StorageError>> {
        self.inner.get_revision(revision_id, ctx)
    }
}

impl SnapshotStore for UnverifiedRawStorage {
    fn put_snapshot<'a>(
        &'a self,
        record: SnapshotRecord,
        ctx: &'a IoContext,
    ) -> BoxFuture<'a, Result<(), StorageError>> {
        self.inner.put_snapshot(record, ctx)
    }

    fn get_snapshot<'a>(
        &'a self,
        snapshot_id: &'a SnapshotRecordId,
        ctx: &'a IoContext,
    ) -> BoxFuture<'a, Result<Option<SnapshotRecord>, StorageError>> {
        self.inner.get_snapshot(snapshot_id, ctx)
    }

    fn latest_last_known_good<'a>(
        &'a self,
        ctx: &'a IoContext,
    ) -> BoxFuture<'a, Result<Option<SnapshotRecord>, StorageError>> {
        self.inner.latest_last_known_good(ctx)
    }
}

impl JournalStore for UnverifiedRawStorage {
    fn put_journal<'a>(
        &'a self,
        record: JournalRecord,
        ctx: &'a IoContext,
    ) -> BoxFuture<'a, Result<(), StorageError>> {
        self.inner.put_journal(record, ctx)
    }

    fn get_journal<'a>(
        &'a self,
        journal_id: &'a JournalRecordId,
        ctx: &'a IoContext,
    ) -> BoxFuture<'a, Result<Option<JournalRecord>, StorageError>> {
        self.inner.get_journal(journal_id, ctx)
    }

    fn list_pending<'a>(
        &'a self,
        ctx: &'a IoContext,
    ) -> BoxFuture<'a, Result<Vec<JournalRecord>, StorageError>> {
        self.inner.list_pending(ctx)
    }
}

impl ApplyJournalStore for UnverifiedRawStorage {
    fn put_apply_journal<'a>(
        &'a self,
        record: ApplyJournalRecord,
        ctx: &'a IoContext,
    ) -> BoxFuture<'a, Result<(), StorageError>> {
        self.inner.put_apply_journal(record, ctx)
    }

    fn get_apply_journal<'a>(
        &'a self,
        apply_txn_id: &'a ApplyTxnId,
        ctx: &'a IoContext,
    ) -> BoxFuture<'a, Result<Option<ApplyJournalRecord>, StorageError>> {
        self.inner.get_apply_journal(apply_txn_id, ctx)
    }

    fn list_pending_apply<'a>(
        &'a self,
        ctx: &'a IoContext,
    ) -> BoxFuture<'a, Result<Vec<ApplyJournalRecord>, StorageError>> {
        self.inner.list_pending_apply(ctx)
    }

    fn list_unresolved_apply<'a>(
        &'a self,
        ctx: &'a IoContext,
    ) -> BoxFuture<'a, Result<Vec<ApplyJournalRecord>, StorageError>> {
        self.inner.list_unresolved_apply(ctx)
    }
}

impl StorageBackend for UnverifiedRawStorage {
    fn put_source_index<'a>(
        &'a self,
        record: caly_storage::SourceIndexRecord,
        ctx: &'a IoContext,
    ) -> BoxFuture<'a, Result<(), StorageError>> {
        self.inner.put_source_index(record, ctx)
    }

    fn get_source_index<'a>(
        &'a self,
        source_id: &'a str,
        ctx: &'a IoContext,
    ) -> BoxFuture<'a, Result<Option<caly_storage::SourceIndexRecord>, StorageError>> {
        self.inner.get_source_index(source_id, ctx)
    }

    fn list_source_indexes<'a>(
        &'a self,
        ctx: &'a IoContext,
    ) -> BoxFuture<'a, Result<Vec<caly_storage::SourceIndexRecord>, StorageError>> {
        self.inner.list_source_indexes(ctx)
    }

    fn delete_source_index<'a>(
        &'a self,
        source_id: &'a str,
        ctx: &'a IoContext,
    ) -> BoxFuture<'a, Result<bool, StorageError>> {
        self.inner.delete_source_index(source_id, ctx)
    }
}

// `JobLogStore` is a supertrait of `StorageBackend`; this fake exists to pin raw-object
// verification, so it simply delegates the job-log surface to the in-memory backend it wraps.
impl caly_storage::JobLogStore for UnverifiedRawStorage {
    fn put_job_log<'a>(
        &'a self,
        record: caly_storage::job_log::JobLogRecord,
        ctx: &'a IoContext,
    ) -> BoxFuture<'a, Result<(), StorageError>> {
        self.inner.put_job_log(record, ctx)
    }

    fn get_job_log<'a>(
        &'a self,
        job_id: &'a str,
        ctx: &'a IoContext,
    ) -> BoxFuture<'a, Result<Option<caly_storage::job_log::JobLogRecord>, StorageError>> {
        self.inner.get_job_log(job_id, ctx)
    }

    fn list_job_logs<'a>(
        &'a self,
        ctx: &'a IoContext,
    ) -> BoxFuture<'a, Result<Vec<caly_storage::job_log::JobLogRecord>, StorageError>> {
        self.inner.list_job_logs(ctx)
    }
}

/// The worker recovery path refuses a record whose raw object metadata stopped agreeing with the
/// durable anchors — even when the content bytes themselves are still intact. Confusing "the
/// index disagrees with the object" with "the object is missing" would let a rewritten size
/// silently pass as the same raw body.
#[test]
fn disagreeing_raw_object_metadata_refuses_durable_worker_restore() {
    let (disk, record) = seeded_durable_fixture();
    let metadata_path = caly_io::VPath::try_from_str(&format!(
        "{ROOT}/meta/objects/{}.obj",
        escape_component(&record.raw_object_digest)
    ))
    .expect("raw metadata path");
    let bytes = block_on_ready(disk.read(&metadata_path, ByteCap(4 * 1024), &ctx()))
        .expect("fs future must be ready")
        .expect("raw metadata readable");
    let text = String::from_utf8(bytes.to_vec()).expect("object record is utf-8 text");
    let size_line = text
        .lines()
        .find(|line| line.starts_with("size="))
        .expect("object record carries a size claim");
    let edited = text.replacen(size_line, &format!("size={}", record.raw_bytes_len + 1), 1);
    block_on_ready(disk.write_atomic(
        &metadata_path,
        edited.into_bytes(),
        caly_io::Durability::D3,
        &ctx(),
    ))
    .expect("fs future must be ready")
    .expect("tampered metadata written");

    // The store itself still opens: its open scan compares content bytes against the content
    // anchor, not the size claim. The worker is the layer that must notice the disagreement.
    let store = FsStore::open(Box::new(disk), ROOT).expect("store can open before worker restore");
    let error = match HttpSourceUpdateWorker::new(
        Arc::new(ConditionalFixtureHttp::new(fixture())),
        Arc::new(store),
    ) {
        Ok(_) => panic!("a size claim that disagrees with the record must refuse restore"),
        Err(error) => error,
    };
    assert!(
        error.contains("raw object metadata disagrees with its durable anchors"),
        "{error}"
    );
}

/// Raw bytes corrupted *after* a worker has been restored must not be silently reused on a `304`:
/// the store's own read verification refuses, and the worker never reports a reuse. The
/// `write_atomic` overwrite keeps the metadata in place, so this is the "body only" corruption
/// shape at the reuse boundary, distinct from the restore-time corruption covered above.
#[test]
fn corrupt_raw_bytes_between_restore_and_304_refuse_reuse_on_the_durable_store() {
    let disk = SimFs::new(MemFs::default(), SharedFaults::new(FaultInjector::new(1)));
    let http = Arc::new(ConditionalFixtureHttp::new(fixture()));
    let raw_anchor = {
        let store = FsStore::open(Box::new(disk.clone()), ROOT).expect("fresh store");
        let backend: Arc<dyn StorageBackend> = Arc::new(store);
        let worker = HttpSourceUpdateWorker::new(http.clone(), backend).expect("worker");
        worker.register(endpoint()).expect("explicit endpoint");
        let first = worker.update(SOURCE_ID, &ctx()).expect("fixture update");
        first
            .raw_object
            .content_sha256
            .clone()
            .expect("raw body anchor")
    };
    let reopened_backend: Arc<dyn StorageBackend> =
        Arc::new(FsStore::open(Box::new(disk.clone()), ROOT).expect("reopen store"));
    let reopened_worker = HttpSourceUpdateWorker::new(http, reopened_backend).expect("restore");

    let content_path =
        caly_io::VPath::try_from_str(&format!("{ROOT}/{}", content_suffix_for(&raw_anchor)))
            .expect("raw content path");
    block_on_ready(disk.write_atomic(
        &content_path,
        b"corrupted fixture bytes".to_vec(),
        caly_io::Durability::D3,
        &ctx(),
    ))
    .expect("fs future must be ready")
    .expect("overwrite raw content for reuse-boundary corruption drill");

    let error = match reopened_worker.update(SOURCE_ID, &ctx()) {
        Ok(report) => panic!(
            "a 304 must not reuse bytes that no longer match their anchor, got {:?}",
            report.reused_raw_body
        ),
        Err(error) => error,
    };
    assert!(
        error.contains("cached raw-body read failed"),
        "the refusal must name the read phase: {error}"
    );
    assert!(
        error.contains("failed integrity verification on read"),
        "{error}"
    );
}

/// A `304` whose raw body was disposed of before reuse must be refused **by name**, never
/// satisfied from the worker's in-memory report. The durable backend cannot answer `Ok(None)`
/// for a digest it still indexes after reopen — its object map is loaded at open — so this
/// branch only has a judge against a backend that does not verify, or a deletion that happens
/// out-of-band.
#[test]
fn a_304_reuse_with_a_lost_raw_body_is_refused_by_name() {
    let http = Arc::new(ConditionalFixtureHttp::new(fixture()));
    let storage = Arc::new(UnverifiedRawStorage::new());
    let worker = HttpSourceUpdateWorker::new(http, storage.clone()).expect("worker startup");
    worker.register(endpoint()).expect("explicit endpoint");
    let first = worker.update(SOURCE_ID, &ctx()).expect("fixture update");
    storage.make_missing(&first.raw_object.digest.0);
    let error = worker
        .update(SOURCE_ID, &ctx())
        .expect_err("a missing raw body must refuse 304 reuse");
    assert!(error.contains("cached raw body is missing"), "{error}");
}

/// The same refusal when the backend hands back bytes **without verifying them**: the worker's
/// own digest anchor — not the store's read path — is what stands between a `304` and a silently
/// replaced raw body. On the shipping backends the store refuses first, so this judge proves
/// the worker-side guard is reachable behaviour rather than dead text for the next backend.
#[test]
fn a_304_reuse_with_unverified_bytes_is_refused_by_the_worker_anchor() {
    let http = Arc::new(ConditionalFixtureHttp::new(fixture()));
    let storage = Arc::new(UnverifiedRawStorage::new());
    let worker = HttpSourceUpdateWorker::new(http, storage.clone()).expect("worker startup");
    worker.register(endpoint()).expect("explicit endpoint");
    let first = worker.update(SOURCE_ID, &ctx()).expect("fixture update");
    storage.make_tampered(&first.raw_object.digest.0, b"tampered raw body".to_vec());
    let error = worker
        .update(SOURCE_ID, &ctx())
        .expect_err("unverified bytes must fail the worker's own anchor");
    assert!(
        error.contains("cached raw body failed its digest anchor on 304 reuse"),
        "{error}"
    );
}
