//! Durable source-index coverage using the real subscription fixture.
//!
//! The source worker must not treat process memory as the source of truth: a second worker over a
//! reopened `FsStore` has to recover the endpoint, validators, raw CAS reference, normalized nodes,
//! diagnostics, and parser provenance before it can accept a `304`.

use std::sync::{Arc, Mutex};

use caly_common::redact::{Redactor, REDACTED};
use caly_common::{Actor, CancelToken, RequestContext, TraceId};
use caly_engine::{
    EngineHandle, EngineState, HttpSourceUpdateWorker, SourceEndpoint, SourceUpdateWorker,
};
use caly_io::{
    block_on_ready, Clock, Durability, FetchBody, FetchReq, FetchResp, Fs, Http, IoContext,
    IoFault, IoFaultKind,
};
use caly_io_sim::{FaultInjector, MemFs, SharedFaults, SimClock, SimFs, VirtualClock};
use caly_ir::SourceId;
use caly_storage::fs_store::{content_suffix_for, escape_component, FsStore};
use caly_storage::{StorageBackend, StorageError};

const ROOT: &str = "var/caly";
const SOURCE_ID: &str = "fixture-source";
const LOCATOR: &str = "https://fixture.invalid/subscription";

fn ctx() -> RequestContext {
    RequestContext::new(TraceId::new("source-durable-test"), Actor::System)
}

fn fixture() -> Vec<u8> {
    std::fs::read(concat!(
        env!("CARGO_MANIFEST_DIR"),
        "/../../fixtures/subscription-20260803.txt"
    ))
    .expect("real subscription fixture")
}

fn ready<T>(future: caly_io::BoxFuture<'_, Result<T, StorageError>>) -> Result<T, StorageError> {
    block_on_ready(future).expect("storage future must be ready")
}

fn seeded_durable_fixture() -> (SimFs, caly_storage::SourceIndexRecord) {
    let disk = SimFs::new(MemFs::default(), SharedFaults::default());
    let store = FsStore::open(Box::new(disk.clone()), ROOT).expect("fresh store");
    let backend: Arc<dyn StorageBackend> = Arc::new(store);
    let http = Arc::new(ConditionalFixtureHttp::new(fixture()));
    let worker = HttpSourceUpdateWorker::new(http, backend.clone()).expect("worker startup");
    worker.register(endpoint()).expect("explicit endpoint");
    worker.update(SOURCE_ID, &ctx()).expect("fixture update");
    let record = ready(backend.get_source_index(SOURCE_ID, &ctx()))
        .expect("source index read")
        .expect("durable source index");
    drop(worker);
    drop(backend);
    (disk, record)
}

#[derive(Clone)]
struct ConditionalFixtureHttp {
    body: Arc<Vec<u8>>,
    requests: Arc<Mutex<Vec<FetchReq>>>,
}

impl ConditionalFixtureHttp {
    fn new(body: Vec<u8>) -> Self {
        Self {
            body: Arc::new(body),
            requests: Arc::new(Mutex::new(Vec::new())),
        }
    }
}

impl Http for ConditionalFixtureHttp {
    fn fetch<'a>(
        &'a self,
        request: FetchReq,
        _ctx: &'a IoContext,
    ) -> caly_io::BoxFuture<'a, Result<FetchResp, IoFault>> {
        let body = Arc::clone(&self.body);
        let requests = Arc::clone(&self.requests);
        Box::pin(async move {
            requests
                .lock()
                .map_err(|_| IoFault::new(IoFaultKind::InternalIo, "request log poisoned"))?
                .push(request.clone());
            let conditional = request.etag.is_some() || request.if_modified_since.is_some();
            Ok(FetchResp {
                status: if conditional { 304 } else { 200 },
                etag: Some("\"fixture-v1\"".to_owned()),
                last_modified: Some("Sat, 03 Aug 2026 00:00:00 GMT".to_owned()),
                body: FetchBody {
                    label: format!("http:{}", request.url),
                    bytes: if conditional {
                        Vec::new()
                    } else {
                        (*body).clone()
                    },
                },
            })
        })
    }
}

/// A fixture-backed port that cancels after returning a complete HTTP response. The worker's
/// post-fetch boundary must observe this and refuse before parser/CAS work starts.
#[derive(Clone)]
struct CancelAfterFixtureHttp {
    body: Arc<Vec<u8>>,
    requests: Arc<Mutex<Vec<FetchReq>>>,
}

impl CancelAfterFixtureHttp {
    fn new(body: Vec<u8>) -> Self {
        Self {
            body: Arc::new(body),
            requests: Arc::new(Mutex::new(Vec::new())),
        }
    }
}

impl Http for CancelAfterFixtureHttp {
    fn fetch<'a>(
        &'a self,
        request: FetchReq,
        ctx: &'a IoContext,
    ) -> caly_io::BoxFuture<'a, Result<FetchResp, IoFault>> {
        let body = Arc::clone(&self.body);
        let requests = Arc::clone(&self.requests);
        Box::pin(async move {
            requests
                .lock()
                .map_err(|_| IoFault::new(IoFaultKind::InternalIo, "request log poisoned"))?
                .push(request.clone());
            ctx.cancel.cancel();
            Ok(FetchResp {
                status: 200,
                etag: None,
                last_modified: None,
                body: FetchBody {
                    label: format!("http:{}", request.url),
                    bytes: (*body).clone(),
                },
            })
        })
    }
}

/// The same fixture, but the simulated monotonic clock advances while the HTTP future completes.
/// This makes the post-fetch deadline probe deterministic without using a host clock.
#[derive(Clone)]
struct AdvanceClockAfterFixtureHttp {
    body: Arc<Vec<u8>>,
    clock: Arc<SimClock>,
}

impl Http for AdvanceClockAfterFixtureHttp {
    fn fetch<'a>(
        &'a self,
        request: FetchReq,
        _ctx: &'a IoContext,
    ) -> caly_io::BoxFuture<'a, Result<FetchResp, IoFault>> {
        let body = Arc::clone(&self.body);
        let clock = Arc::clone(&self.clock);
        Box::pin(async move {
            clock.advance_ms(10)?;
            Ok(FetchResp {
                status: 200,
                etag: None,
                last_modified: None,
                body: FetchBody {
                    label: format!("http:{}", request.url),
                    bytes: (*body).clone(),
                },
            })
        })
    }
}

fn endpoint() -> SourceEndpoint {
    SourceEndpoint::subscription_named(SOURCE_ID, "Fixture subscription", LOCATOR, 4 * 1024 * 1024)
}

#[test]
fn a_reopened_worker_reuses_the_fixture_on_304_with_all_provenance_intact() {
    let disk = SimFs::new(MemFs::default(), SharedFaults::new(FaultInjector::new(1)));
    let http = Arc::new(ConditionalFixtureHttp::new(fixture()));

    let first = {
        let store = FsStore::open(Box::new(disk.clone()), ROOT).expect("fresh store");
        let backend: Arc<dyn StorageBackend> = Arc::new(store);
        let worker = HttpSourceUpdateWorker::new(http.clone(), backend).expect("worker startup");
        worker.register(endpoint()).expect("explicit endpoint");
        worker
            .update(SOURCE_ID, &ctx())
            .expect("initial fixture update")
    };
    assert_eq!(first.normalized.nodes.len(), 30);
    assert_eq!(first.provenance.entries.len(), 1);

    let reopened_store = FsStore::open(Box::new(disk.clone()), ROOT).expect("reopen store");
    let reopened_backend: Arc<dyn StorageBackend> = Arc::new(reopened_store);
    let reopened_worker = HttpSourceUpdateWorker::new(http.clone(), reopened_backend.clone())
        .expect("restore worker");
    assert_eq!(
        reopened_worker
            .endpoint(SOURCE_ID)
            .expect("endpoint lookup")
            .expect("endpoint restored")
            .locator(),
        LOCATOR
    );
    let inspected = reopened_worker
        .inspect_durable(SOURCE_ID, &ctx())
        .expect("durable inspection")
        .expect("durable source record");
    let inspected_api = caly_engine::project_source_inspection(
        inspected,
        &caly_common::redact::Redactor::default(),
    );
    assert_eq!(inspected_api.summary.id.0, SOURCE_ID);
    assert_eq!(inspected_api.locator.as_deref(), Some(LOCATOR));
    assert_eq!(
        inspected_api.latest_digest,
        Some(first.raw.content_digest.0.clone())
    );
    assert_eq!(
        inspected_api.raw_object_digest,
        Some(first.raw_object.digest.0.clone())
    );
    assert_eq!(inspected_api.raw_bytes_len, Some(first.raw.bytes_len));
    assert_eq!(inspected_api.normalized_node_count, 30);
    assert_eq!(inspected_api.provenance.len(), 1);
    assert_eq!(inspected_api.diagnostics, Vec::new());
    let handle = EngineHandle::with_backend(EngineState::new(), reopened_backend.clone());
    handle
        .set_source_update_worker(Arc::new(reopened_worker))
        .expect("install restored worker");
    assert_eq!(
        handle
            .cached_source(SOURCE_ID)
            .expect("engine cache lookup")
            .expect("normalized cache restored")
            .nodes
            .len(),
        30
    );

    let second = handle
        .source_update(SOURCE_ID, &ctx())
        .expect("304 fixture reuse");
    assert!(second.reused_raw_body);
    assert_eq!(second.raw, first.raw);
    assert_eq!(second.normalized, first.normalized);
    assert_eq!(second.provenance, first.provenance);
    assert_eq!(second.diagnostics, first.diagnostics);
    assert_eq!(second.raw_object, first.raw_object);

    let requests = http.requests.lock().expect("request log");
    assert_eq!(requests.len(), 2);
    assert_eq!(requests[1].url, LOCATOR);
    assert_eq!(requests[1].etag, Some("\"fixture-v1\"".to_owned()));
    assert_eq!(
        requests[1].if_modified_since,
        Some("Sat, 03 Aug 2026 00:00:00 GMT".to_owned())
    );
    drop(requests);

    let records =
        ready(reopened_backend.list_source_indexes(&ctx())).expect("source index listing");
    assert_eq!(records.len(), 1);
    assert_eq!(records[0].source_id, SOURCE_ID);
    assert_eq!(records[0].raw_object_digest, second.raw_object.digest.0);

    let changed = SourceEndpoint::subscription_named(
        SOURCE_ID,
        "Fixture subscription moved",
        "https://fixture.invalid/subscription-v2",
        4 * 1024 * 1024,
    );
    handle
        .register_source_endpoint(changed)
        .expect("durable locator invalidation");
    assert!(ready(reopened_backend.list_source_indexes(&ctx()))
        .expect("source index listing after invalidation")
        .is_empty());
    let restarted_after_change = HttpSourceUpdateWorker::new(http, reopened_backend)
        .expect("worker startup after locator invalidation");
    assert!(restarted_after_change
        .endpoint(SOURCE_ID)
        .expect("endpoint lookup after invalidation")
        .is_none());
}

#[test]
fn inspection_projection_redacts_fixture_locator_label_validator_and_provenance() {
    let secret = "fixture-secret-token";
    let endpoint = SourceEndpoint::subscription(
        SourceId::new(SOURCE_ID),
        format!("fixture label {secret}"),
        format!("https://fixture.invalid/subscription?token={secret}"),
        4 * 1024 * 1024,
    );
    let http = Arc::new(ConditionalFixtureHttp::new(fixture()));
    let backend: Arc<dyn StorageBackend> = Arc::new(caly_storage::InMemoryStorage::new());
    let worker = HttpSourceUpdateWorker::new(http, backend).expect("worker startup");
    worker
        .register(endpoint.clone())
        .expect("explicit secret-bearing endpoint");
    let mut report = worker.update(SOURCE_ID, &ctx()).expect("fixture update");
    // Validators are durable operator-visible text too; make the assertion cover that field rather
    // than only relying on URL query redaction.
    report.etag = Some(secret.to_owned());
    let durable = caly_engine::SourceInspectionReport {
        endpoint,
        report,
        updated_at_unix_ms: 1_750_000_000_000,
    };
    let mut redactor = Redactor::default();
    redactor.register_secret(secret);
    let api = caly_engine::project_source_inspection(durable, &redactor);
    let rendered = format!("{api:?}");
    assert!(
        !rendered.contains(secret),
        "projection leaked registered secret: {rendered}"
    );
    assert!(
        rendered.contains(REDACTED),
        "projection did not leave a redaction marker: {rendered}"
    );
    assert_eq!(api.summary.label, format!("fixture label {REDACTED}"));
    assert_eq!(api.etag.as_deref(), Some(REDACTED));
    assert!(api
        .latest_digest
        .as_ref()
        .is_some_and(|digest| !digest.is_empty()));
    assert!(api
        .raw_object_digest
        .as_ref()
        .is_some_and(|digest| !digest.is_empty()));
    assert_eq!(api.raw_bytes_len, Some(fixture().len() as u64));
    assert_eq!(api.provenance.len(), 1);
    let expected_locator = format!("https://fixture.invalid/subscription?token={REDACTED}");
    assert_eq!(
        api.provenance[0].locator.as_deref(),
        Some(expected_locator.as_str())
    );
}

#[test]
fn a_cancelled_source_update_never_starts_http_or_cas() {
    let http = Arc::new(ConditionalFixtureHttp::new(fixture()));
    let backend: Arc<dyn StorageBackend> = Arc::new(caly_storage::InMemoryStorage::new());
    let worker =
        HttpSourceUpdateWorker::new(http.clone(), backend.clone()).expect("worker startup");
    worker.register(endpoint()).expect("explicit endpoint");

    let token = CancelToken::new();
    token.cancel();
    let mut caller = ctx();
    caller.cancel = token;
    let error = worker
        .update(SOURCE_ID, &caller)
        .expect_err("cancelled source update");
    assert!(error.contains("CallerCancelled"), "{error}");
    assert!(
        http.requests.lock().expect("request log").is_empty(),
        "a pre-cancelled call must not reach the HTTP port"
    );
    assert!(ready(backend.list_source_indexes(&ctx()))
        .expect("source index listing")
        .is_empty());
}

#[test]
fn an_expired_source_deadline_refuses_before_http_with_the_injected_clock() {
    let clock = Arc::new(SimClock::new(
        VirtualClock::new(1_750_000_000_000),
        SharedFaults::default(),
    ));
    let http = Arc::new(ConditionalFixtureHttp::new(fixture()));
    let backend: Arc<dyn StorageBackend> = Arc::new(caly_storage::InMemoryStorage::new());
    let worker = HttpSourceUpdateWorker::new(http.clone(), backend)
        .expect("worker startup")
        .with_clock(Arc::clone(&clock) as Arc<dyn Clock>);
    worker.register(endpoint()).expect("explicit endpoint");

    let mut caller = ctx();
    caller.deadline_mono_ms = Some(0);
    let error = worker
        .update(SOURCE_ID, &caller)
        .expect_err("expired source deadline");
    assert!(error.contains("DeadlineExpired"), "{error}");
    assert!(http.requests.lock().expect("request log").is_empty());
}

#[test]
fn cancellation_after_http_is_observed_before_source_parse_and_cas() {
    let http = Arc::new(CancelAfterFixtureHttp::new(fixture()));
    let backend: Arc<dyn StorageBackend> = Arc::new(caly_storage::InMemoryStorage::new());
    let worker =
        HttpSourceUpdateWorker::new(http.clone(), backend.clone()).expect("worker startup");
    worker.register(endpoint()).expect("explicit endpoint");

    let error = worker
        .update(SOURCE_ID, &ctx())
        .expect_err("post-fetch cancellation");
    assert!(error.contains("CallerCancelled"), "{error}");
    assert_eq!(http.requests.lock().expect("request log").len(), 1);
    assert!(ready(backend.list_source_indexes(&ctx()))
        .expect("source index listing")
        .is_empty());
}

#[test]
fn a_deadline_crossed_by_http_is_observed_before_cas() {
    let clock = Arc::new(SimClock::new(
        VirtualClock::new(1_750_000_000_000),
        SharedFaults::default(),
    ));
    let http = Arc::new(AdvanceClockAfterFixtureHttp {
        body: Arc::new(fixture()),
        clock: Arc::clone(&clock),
    });
    let backend: Arc<dyn StorageBackend> = Arc::new(caly_storage::InMemoryStorage::new());
    let worker = HttpSourceUpdateWorker::new(http, backend.clone())
        .expect("worker startup")
        .with_clock(Arc::clone(&clock) as Arc<dyn Clock>);
    worker.register(endpoint()).expect("explicit endpoint");

    let mut caller = ctx();
    caller.deadline_mono_ms = Some(5);
    let error = worker
        .update(SOURCE_ID, &caller)
        .expect_err("deadline crossed during HTTP");
    assert!(error.contains("DeadlineExpired"), "{error}");
    assert!(ready(backend.list_source_indexes(&ctx()))
        .expect("source index listing")
        .is_empty());
}

#[test]
fn a_missing_raw_object_refuses_durable_worker_restore() {
    let (disk, record) = seeded_durable_fixture();
    let metadata_path = caly_io::VPath::try_from_str(&format!(
        "{ROOT}/meta/objects/{}.obj",
        escape_component(&record.raw_object_digest)
    ))
    .expect("raw metadata path");
    block_on_ready(disk.remove(&metadata_path, &ctx()))
        .expect("fs future must be ready")
        .expect("remove raw metadata");

    let store = FsStore::open(Box::new(disk), ROOT).expect("store can open before worker restore");
    let error = match HttpSourceUpdateWorker::new(
        Arc::new(ConditionalFixtureHttp::new(fixture())),
        Arc::new(store),
    ) {
        Ok(_) => panic!("a source index pointing at a missing object must refuse restore"),
        Err(error) => error,
    };
    assert!(error.contains("references missing raw object"), "{error}");
}

#[test]
fn corrupt_raw_bytes_refuse_durable_worker_restore_even_when_metadata_survives() {
    let (disk, record) = seeded_durable_fixture();
    let content_path = caly_io::VPath::try_from_str(&format!(
        "{ROOT}/{}",
        content_suffix_for(&record.raw_content_sha256)
    ))
    .expect("raw content path");
    block_on_ready(disk.write_atomic(
        &content_path,
        b"corrupted fixture bytes".to_vec(),
        Durability::D2,
        &ctx(),
    ))
    .expect("fs future must be ready")
    .expect("overwrite raw content for corruption drill");

    let error = match FsStore::open(Box::new(disk), ROOT) {
        Ok(store) => match HttpSourceUpdateWorker::new(
            Arc::new(ConditionalFixtureHttp::new(fixture())),
            Arc::new(store),
        ) {
            Ok(_) => panic!("corrupt raw bytes must refuse restore"),
            Err(error) => error,
        },
        Err(error) => error.summary,
    };
    assert!(
        error.contains("content no longer matches")
            || error.contains("raw CAS bytes disagree with their durable anchors")
            || error.contains("failed integrity verification"),
        "{error}"
    );
}

#[test]
fn a_corrupt_source_record_refuses_the_next_store_open() {
    let disk = SimFs::new(MemFs::default(), SharedFaults::new(FaultInjector::new(1)));
    let http = Arc::new(ConditionalFixtureHttp::new(fixture()));
    {
        let store = FsStore::open(Box::new(disk.clone()), ROOT).expect("fresh store");
        let backend: Arc<dyn StorageBackend> = Arc::new(store);
        let worker = HttpSourceUpdateWorker::new(http, backend).expect("worker startup");
        worker.register(endpoint()).expect("explicit endpoint");
        worker.update(SOURCE_ID, &ctx()).expect("fixture update");
    }

    let record_path = caly_io::VPath::try_from_str(&format!(
        "{ROOT}/records/source-index/{}.rec",
        escape_component(SOURCE_ID)
    ))
    .expect("source record path");
    block_on_ready(disk.write_atomic(
        &record_path,
        b"record:v2\n".to_vec(),
        caly_io::Durability::D3,
        &ctx(),
    ))
    .expect("fs future must be ready")
    .expect("corruption write");

    let error =
        FsStore::open(Box::new(disk), ROOT).expect_err("bad source record must refuse boot");
    assert!(error.summary.contains("source-index"), "{}", error.summary);
    assert!(
        error.summary.contains("unsupported record tag"),
        "{}",
        error.summary
    );
}
