use std::collections::BTreeSet;

use caly_cap::{
    default_coverage_matrix_document, default_registry_document, evaluate_required_capabilities,
    merged_coverage_matrix, merged_registry_document, CapabilityDecisionKind,
    CapabilityEvaluationReport, CapabilityKey, CapabilityState, RequiredCapability,
    RequiredCapabilitySet, RequirementStrength, SupportLevel,
};
use caly_core::{CapabilitySet, CoreIssue, IssueLevel};
use caly_ir::{ProxyProtocol, ResolvedProfile, RuleAction};

use crate::stage::{Diagnostic, DiagnosticSeverity, StageContext};

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct SemanticValidationReport {
    pub diagnostics: Vec<Diagnostic>,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct CapabilityValidationReport {
    pub diagnostics: Vec<Diagnostic>,
    pub issues: Vec<CoreIssue>,
    pub evaluation: CapabilityEvaluationReport,
}

pub fn validate_semantic(
    profile: &ResolvedProfile,
    _cx: &StageContext,
) -> SemanticValidationReport {
    let mut diagnostics = Vec::new();

    if profile.nodes.is_empty() && profile.groups.is_empty() {
        diagnostics.push(Diagnostic {
            code: "EMPTY_PROXY_GRAPH".to_owned(),
            severity: DiagnosticSeverity::Warning,
            summary: "resolved profile has no proxy nodes or groups".to_owned(),
            detail: None,
            related_path: None,
            remediation: Some("attach sources or overrides that materialize nodes".to_owned()),
        });
    }

    validate_unique_ids_and_labels(profile, &mut diagnostics);
    validate_group_integrity(profile, &mut diagnostics);
    validate_rule_integrity(profile, &mut diagnostics);
    validate_outbound_integrity(profile, &mut diagnostics);
    validate_network_integrity(profile, &mut diagnostics);

    SemanticValidationReport { diagnostics }
}

pub fn validate_capabilities(
    profile: &ResolvedProfile,
    capabilities: &CapabilitySet,
    strict_mode: bool,
) -> CapabilityValidationReport {
    let registry = merged_registry_document(default_registry_document(), &capabilities.descriptors);
    let coverage = merged_coverage_matrix(
        default_coverage_matrix_document(),
        &capabilities.descriptors,
        core_target_name(profile.core_target),
    );
    let required = required_capabilities_for_profile(profile);
    let evaluation = evaluate_required_capabilities(
        required,
        &capabilities.descriptors,
        caly_cap::EvaluationContext {
            target_core: core_target_name(profile.core_target),
            strict_mode,
            registry: Some(&registry),
            coverage: Some(&coverage),
        },
    );

    let mut diagnostics = Vec::new();
    let mut issues = Vec::new();

    for descriptor in &capabilities.descriptors {
        if strict_mode && matches!(descriptor.state, CapabilityState::Unknown) {
            diagnostics.push(Diagnostic {
                code: "STRICT_UNKNOWN_CAPABILITY".to_owned(),
                severity: DiagnosticSeverity::Error,
                summary: format!("strict mode blocks unknown capability {}", descriptor.key.0),
                detail: None,
                related_path: None,
                remediation: Some("pin a supported core/version or disable strict mode".to_owned()),
            });
            issues.push(CoreIssue {
                level: IssueLevel::Error,
                code: "STRICT_UNKNOWN_CAPABILITY".to_owned(),
                summary: format!("unknown capability in strict mode: {}", descriptor.key.0),
            });
        }

        if matches!(descriptor.support_level, SupportLevel::OpaquePreserved)
            && matches!(descriptor.state, CapabilityState::PreservedOpaque)
        {
            diagnostics.push(Diagnostic {
                code: "OPAQUE_CAPABILITY_PRESENT".to_owned(),
                severity: DiagnosticSeverity::Info,
                summary: format!(
                    "capability {} is preserved opaquely and should not be edited cross-core",
                    descriptor.key.0
                ),
                detail: None,
                related_path: None,
                remediation: Some("keep target core stable or add explicit mapping".to_owned()),
            });
        }
    }

    diagnostics.extend(capability_diagnostics(&evaluation));
    issues.extend(capability_issues(&evaluation));

    CapabilityValidationReport {
        diagnostics,
        issues,
        evaluation,
    }
}

pub fn required_capabilities_for_profile(profile: &ResolvedProfile) -> RequiredCapabilitySet {
    let mut required = RequiredCapabilitySet::default();

    if profile.routing_mode == caly_ir::RoutingMode::Rule && !profile.rules.is_empty() {
        required.push(required_capability(
            "routing.rules",
            "resolved profile uses rule-based routing",
            RequirementStrength::Hard,
            Some("routing.mode"),
        ));
    }

    if let Some(dns) = &profile.dns {
        if matches!(dns.mode, caly_ir::DnsMode::FakeIp | caly_ir::DnsMode::Mixed) {
            required.push(required_capability(
                "dns.fake_ip",
                format!("resolved dns mode is {}", dns_mode_name(dns.mode)),
                RequirementStrength::Hard,
                Some("dns.mode"),
            ));
        }
    }

    if let Some(tun) = &profile.tun {
        if tun.enabled {
            required.push(required_capability(
                "network.tun",
                "resolved profile enables tun".to_owned(),
                RequirementStrength::Hard,
                Some("tun.enabled"),
            ));
        }
        if tun.auto_route {
            required.push(required_capability(
                "tun.auto_route",
                "resolved profile requires auto-route behavior".to_owned(),
                RequirementStrength::Soft,
                Some("tun.auto_route"),
            ));
        }
        if tun.strict_route {
            required.push(required_capability(
                "tun.strict_route",
                "resolved profile requires strict-route behavior".to_owned(),
                RequirementStrength::Hard,
                Some("tun.strict_route"),
            ));
        }
    }

    if profile.groups.iter().any(|group| group.selected.is_some()) {
        required.push(required_capability(
            "runtime.group.select",
            "resolved profile carries persisted group selections",
            RequirementStrength::Soft,
            Some("groups[*].selected"),
        ));
    }

    if profile
        .nodes
        .iter()
        .any(|node| matches!(node.protocol, ProxyProtocol::WireGuard))
    {
        required.push(required_capability(
            "outbound.wireguard",
            "resolved profile contains wireguard-shaped nodes",
            RequirementStrength::Hard,
            Some("nodes[*].protocol"),
        ));
    }

    for node in &profile.nodes {
        let key = match node.protocol {
            ProxyProtocol::Shadowsocks => Some("proxy.shadowsocks"),
            ProxyProtocol::Vmess => Some("proxy.vmess"),
            ProxyProtocol::Vless => Some("proxy.vless"),
            ProxyProtocol::Trojan => Some("proxy.trojan"),
            ProxyProtocol::Hysteria2 => Some("proxy.hysteria2"),
            ProxyProtocol::Tuic => Some("proxy.tuic"),
            ProxyProtocol::WireGuard => Some("proxy.wireguard"),
            ProxyProtocol::Unknown => None,
        };
        if let Some(key) = key {
            required.push(required_capability(
                key,
                format!(
                    "resolved node {} uses protocol {:?}",
                    node.id.0, node.protocol
                ),
                RequirementStrength::Soft,
                Some("nodes[*].protocol"),
            ));
        }
    }

    required.dedup()
}

fn required_capability(
    key: impl Into<String>,
    reason: impl Into<String>,
    strength: RequirementStrength,
    origin_path: Option<&str>,
) -> RequiredCapability {
    RequiredCapability {
        key: CapabilityKey(key.into()),
        reason: reason.into(),
        strength,
        origin_path: origin_path.map(str::to_owned),
    }
}

fn capability_diagnostics(evaluation: &CapabilityEvaluationReport) -> Vec<Diagnostic> {
    evaluation
        .decisions
        .iter()
        .map(|decision| Diagnostic {
            code: format!("CAPABILITY_{:?}_{}", decision.kind, decision.key.0).to_uppercase(),
            severity: match decision.kind {
                CapabilityDecisionKind::Allow => DiagnosticSeverity::Info,
                CapabilityDecisionKind::AllowWithWarning => DiagnosticSeverity::Warning,
                CapabilityDecisionKind::Block => DiagnosticSeverity::Error,
            },
            summary: format!(
                "capability {} -> {:?} ({:?}/{:?})",
                decision.key.0, decision.kind, decision.state, decision.support_level
            ),
            detail: Some(decision.reason.clone()),
            related_path: decision
                .origin_path
                .as_ref()
                .map(|path| crate::stage::IrPath::from_segments([path.clone()])),
            remediation: decision.remediation.clone(),
        })
        .collect()
}

fn capability_issues(evaluation: &CapabilityEvaluationReport) -> Vec<CoreIssue> {
    evaluation
        .decisions
        .iter()
        .filter_map(|decision| match decision.kind {
            CapabilityDecisionKind::Allow => None,
            CapabilityDecisionKind::AllowWithWarning => Some(CoreIssue {
                level: IssueLevel::Warning,
                code: format!("CAPABILITY_{}_WARN", decision.key.0),
                summary: format!("{}: {}", decision.key.0, decision.reason),
            }),
            CapabilityDecisionKind::Block => Some(CoreIssue {
                level: IssueLevel::Error,
                code: format!("CAPABILITY_{}_BLOCKED", decision.key.0),
                summary: format!("{}: {}", decision.key.0, decision.reason),
            }),
        })
        .collect()
}

fn validate_unique_ids_and_labels(profile: &ResolvedProfile, diagnostics: &mut Vec<Diagnostic>) {
    let mut node_ids = BTreeSet::new();
    let mut node_labels = BTreeSet::new();
    for node in &profile.nodes {
        if !node_ids.insert(node.id.clone()) {
            diagnostics.push(Diagnostic {
                code: "DUPLICATE_NODE_ID".to_owned(),
                severity: DiagnosticSeverity::Error,
                summary: format!("duplicate node id {} in resolved profile", node.id.0),
                detail: Some(node.label.clone()),
                related_path: None,
                remediation: Some("deduplicate nodes during source normalization".to_owned()),
            });
        }
        if !node_labels.insert(node.label.clone()) {
            diagnostics.push(Diagnostic {
                code: "DUPLICATE_NODE_LABEL".to_owned(),
                severity: DiagnosticSeverity::Warning,
                summary: format!("duplicate node label {} in resolved profile", node.label),
                detail: Some(node.id.0.clone()),
                related_path: None,
                remediation: Some(
                    "stabilize node labels to keep selection memory deterministic".to_owned(),
                ),
            });
        }
    }

    let mut group_ids = BTreeSet::new();
    for group in &profile.groups {
        if !group_ids.insert(group.id.clone()) {
            diagnostics.push(Diagnostic {
                code: "DUPLICATE_GROUP_ID".to_owned(),
                severity: DiagnosticSeverity::Error,
                summary: format!("duplicate group id {} in resolved profile", group.id.0),
                detail: Some(group.label.clone()),
                related_path: None,
                remediation: Some("deduplicate groups during merge".to_owned()),
            });
        }
    }
}

fn validate_group_integrity(profile: &ResolvedProfile, diagnostics: &mut Vec<Diagnostic>) {
    let node_ids = profile
        .nodes
        .iter()
        .map(|node| node.id.clone())
        .collect::<BTreeSet<_>>();
    for group in &profile.groups {
        if group.members.is_empty() {
            diagnostics.push(Diagnostic {
                code: "EMPTY_GROUP".to_owned(),
                severity: DiagnosticSeverity::Warning,
                summary: format!("group {} has no members", group.id.0),
                detail: Some(group.label.clone()),
                related_path: None,
                remediation: Some("drop the empty group or repopulate it from sources".to_owned()),
            });
        }

        for member in &group.members {
            if !node_ids.contains(member) {
                diagnostics.push(Diagnostic {
                    code: "GROUP_MEMBER_MISSING_NODE".to_owned(),
                    severity: DiagnosticSeverity::Error,
                    summary: format!("group {} references missing node {}", group.id.0, member.0),
                    detail: None,
                    related_path: None,
                    remediation: Some(
                        "rebuild group membership after node normalization".to_owned(),
                    ),
                });
            }
        }

        if let Some(selected) = &group.selected {
            if !group.members.iter().any(|member| member == selected) {
                diagnostics.push(Diagnostic {
                    code: "GROUP_SELECTED_NOT_MEMBER".to_owned(),
                    severity: DiagnosticSeverity::Error,
                    summary: format!(
                        "group {} selected node {} is not a member",
                        group.id.0, selected.0
                    ),
                    detail: None,
                    related_path: None,
                    remediation: Some("repair selection memory or group membership".to_owned()),
                });
            }
        }
    }
}

fn validate_rule_integrity(profile: &ResolvedProfile, diagnostics: &mut Vec<Diagnostic>) {
    if profile.routing_mode == caly_ir::RoutingMode::Rule && profile.rules.is_empty() {
        diagnostics.push(Diagnostic {
            code: "RULE_MODE_WITHOUT_RULES".to_owned(),
            severity: DiagnosticSeverity::Warning,
            summary: "routing mode is rule but no rules are present".to_owned(),
            detail: None,
            related_path: None,
            remediation: Some("add rules or switch routing mode".to_owned()),
        });
    }

    let group_ids = profile
        .groups
        .iter()
        .map(|group| group.id.clone())
        .collect::<BTreeSet<_>>();
    let outbound_ids = profile
        .outbounds
        .iter()
        .map(|outbound| outbound.id.clone())
        .collect::<BTreeSet<_>>();
    let mut rule_ids = BTreeSet::new();

    for rule in &profile.rules {
        if !rule_ids.insert(rule.id.clone()) {
            diagnostics.push(Diagnostic {
                code: "DUPLICATE_RULE_ID".to_owned(),
                severity: DiagnosticSeverity::Error,
                summary: format!("duplicate rule id {} in resolved profile", rule.id.0),
                detail: Some(rule.label.clone()),
                related_path: None,
                remediation: Some("deduplicate rules during merge".to_owned()),
            });
        }

        match rule.action {
            RuleAction::UseGroup if rule.target_group.is_none() => diagnostics.push(Diagnostic {
                code: "RULE_ACTION_GROUP_TARGET_MISSING".to_owned(),
                severity: DiagnosticSeverity::Error,
                summary: format!("rule {} uses group action without target group", rule.id.0),
                detail: Some(rule.label.clone()),
                related_path: None,
                remediation: Some("retarget rule to a concrete proxy group".to_owned()),
            }),
            RuleAction::UseOutbound if rule.target_outbound.is_none() => {
                diagnostics.push(Diagnostic {
                    code: "RULE_ACTION_OUTBOUND_TARGET_MISSING".to_owned(),
                    severity: DiagnosticSeverity::Error,
                    summary: format!(
                        "rule {} uses outbound action without outbound target",
                        rule.id.0
                    ),
                    detail: Some(rule.label.clone()),
                    related_path: None,
                    remediation: Some("retarget rule to a concrete outbound".to_owned()),
                })
            }
            _ => {}
        }

        if let Some(group_id) = &rule.target_group {
            if !group_ids.contains(group_id) {
                diagnostics.push(Diagnostic {
                    code: "RULE_TARGET_GROUP_MISSING".to_owned(),
                    severity: DiagnosticSeverity::Error,
                    summary: format!("rule {} targets missing group {}", rule.id.0, group_id.0),
                    detail: Some(rule.label.clone()),
                    related_path: None,
                    remediation: Some("rebuild group ids after merge".to_owned()),
                });
            }
        }

        if let Some(outbound_id) = &rule.target_outbound {
            if !outbound_ids.contains(outbound_id) {
                diagnostics.push(Diagnostic {
                    code: "RULE_TARGET_OUTBOUND_MISSING".to_owned(),
                    severity: DiagnosticSeverity::Error,
                    summary: format!(
                        "rule {} targets missing outbound {}",
                        rule.id.0, outbound_id.0
                    ),
                    detail: Some(rule.label.clone()),
                    related_path: None,
                    remediation: Some("rebuild outbound ids after merge".to_owned()),
                });
            }
        }
    }
}

fn validate_outbound_integrity(profile: &ResolvedProfile, diagnostics: &mut Vec<Diagnostic>) {
    let group_ids = profile
        .groups
        .iter()
        .map(|group| group.id.clone())
        .collect::<BTreeSet<_>>();
    for outbound in &profile.outbounds {
        if let Some(group_id) = &outbound.proxy_group {
            if !group_ids.contains(group_id) {
                diagnostics.push(Diagnostic {
                    code: "OUTBOUND_PROXY_GROUP_MISSING".to_owned(),
                    severity: DiagnosticSeverity::Error,
                    summary: format!(
                        "outbound {} references missing group {}",
                        outbound.id.0, group_id.0
                    ),
                    detail: Some(outbound.label.clone()),
                    related_path: None,
                    remediation: Some("repair outbound->group mapping before compile".to_owned()),
                });
            }
        }
    }
}

fn validate_network_integrity(profile: &ResolvedProfile, diagnostics: &mut Vec<Diagnostic>) {
    if let Some(tun) = &profile.tun {
        if tun.strict_route && !tun.enabled {
            diagnostics.push(Diagnostic {
                code: "STRICT_ROUTE_WITHOUT_TUN".to_owned(),
                severity: DiagnosticSeverity::Error,
                summary: "strict-route requires tun.enabled=true".to_owned(),
                detail: None,
                related_path: None,
                remediation: Some("enable tun or disable strict-route".to_owned()),
            });
        }
    }

    if let Some(dns) = &profile.dns {
        if matches!(dns.mode, caly_ir::DnsMode::FakeIp | caly_ir::DnsMode::Mixed)
            && dns.servers.is_empty()
        {
            diagnostics.push(Diagnostic {
                code: "FAKEIP_WITHOUT_DNS_SERVER".to_owned(),
                severity: DiagnosticSeverity::Warning,
                summary: "fake-ip style DNS mode has no upstream servers".to_owned(),
                detail: None,
                related_path: None,
                remediation: Some("configure at least one upstream DNS server".to_owned()),
            });
        }
    }
}

fn core_target_name(target: caly_ir::CoreTarget) -> &'static str {
    match target {
        caly_ir::CoreTarget::Mihomo => "mihomo",
        caly_ir::CoreTarget::SingBox => "sing-box",
        caly_ir::CoreTarget::Auto => "auto",
    }
}

fn dns_mode_name(mode: caly_ir::DnsMode) -> &'static str {
    match mode {
        caly_ir::DnsMode::System => "system",
        caly_ir::DnsMode::FakeIp => "fake-ip",
        caly_ir::DnsMode::Redirect => "redirect",
        caly_ir::DnsMode::Mixed => "mixed",
    }
}
