#[derive(Clone, Debug, Eq, PartialEq, Ord, PartialOrd, Hash)]
pub struct Digest(pub String);

pub trait Digestible {
    fn stable_digest(&self) -> Digest;
}

impl Digestible for String {
    fn stable_digest(&self) -> Digest {
        Digest(self.clone())
    }
}

impl Digestible for str {
    fn stable_digest(&self) -> Digest {
        Digest(self.to_owned())
    }
}

#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub enum StageId {
    Ingest,
    Decode,
    Normalize,
    Identify,
    Merge,
    Resolve,
    ValidateSemantic,
    ValidateCapability,
    Lower,
    Emit,
    VerifyNative,
}

impl StageId {
    pub const fn as_str(self) -> &'static str {
        match self {
            Self::Ingest => "INGEST",
            Self::Decode => "DECODE",
            Self::Normalize => "NORMALIZE",
            Self::Identify => "IDENTIFY",
            Self::Merge => "MERGE",
            Self::Resolve => "RESOLVE",
            Self::ValidateSemantic => "VALIDATE_SEMANTIC",
            Self::ValidateCapability => "VALIDATE_CAPABILITY",
            Self::Lower => "LOWER",
            Self::Emit => "EMIT",
            Self::VerifyNative => "VERIFY_NATIVE",
        }
    }
}

#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub enum DiagnosticSeverity {
    Error,
    Warning,
    Info,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct IrPath {
    pub segments: Vec<String>,
}

impl IrPath {
    pub fn from_segments(segments: impl IntoIterator<Item = impl Into<String>>) -> Self {
        Self {
            segments: segments.into_iter().map(Into::into).collect(),
        }
    }
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub enum Origin {
    Source {
        source_id: String,
        locator: Option<String>,
    },
    Override {
        override_id: String,
    },
    Default,
    Safety,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct Provenance {
    pub field: IrPath,
    pub origin: Origin,
    pub transform: Vec<StageId>,
    pub superseded: Vec<Origin>,
}

#[derive(Clone, Debug, Default, Eq, PartialEq)]
pub struct ProvenanceDelta {
    pub entries: Vec<Provenance>,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct Diagnostic {
    pub code: String,
    pub severity: DiagnosticSeverity,
    pub summary: String,
    pub detail: Option<String>,
    pub related_path: Option<IrPath>,
    pub remediation: Option<String>,
}

/// The source pipeline's epoch: bumped when normalization/provenance/diagnostics semantics
/// change such that a cache produced by an older epoch must not be consumed as current
/// (`ADR-061`). Durable caches record the epoch that produced them; the comparison point is
/// this constant, in exactly one place.
pub const PIPELINE_EPOCH: u32 = 1;

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct StageContext {
    pub pipeline_epoch: u32,
    pub adapter_version: u32,
    pub strict_mode: bool,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct StageResult<T> {
    pub out: Option<T>,
    pub diagnostics: Vec<Diagnostic>,
    pub provenance: ProvenanceDelta,
}

impl<T> StageResult<T> {
    pub fn success(out: T) -> Self {
        Self {
            out: Some(out),
            diagnostics: Vec::new(),
            provenance: ProvenanceDelta::default(),
        }
    }
}

pub trait Stage {
    const ID: StageId;
    type Input: Digestible;
    type Output: Digestible;

    fn run(input: &Self::Input, cx: &StageContext) -> StageResult<Self::Output>;
}

pub fn stage_cache_key(
    stage_id: StageId,
    pipeline_epoch: u32,
    adapter_version: u32,
    input_digest: &Digest,
) -> String {
    format!(
        "{}:{}:{}:{}",
        stage_id.as_str(),
        pipeline_epoch,
        adapter_version,
        input_digest.0
    )
}
