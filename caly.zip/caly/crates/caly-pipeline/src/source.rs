//! Source decode and normalization for URI-style subscription bodies.
//!
//! This module is deliberately pure: it accepts bytes already obtained by an IO port and does
//! not know how they were fetched or stored. That keeps the anti-corruption boundary from
//! leaking `Http`, `Fs`, or `StorageBackend` into the pipeline (`RFC-0001 §7.2`, `ADR-029`).
//!
//! The first real source slice supports the line-oriented forms commonly returned by proxy
//! subscription endpoints: Shadowsocks, VMess, VLESS, Trojan, Hysteria2, and TUIC. A body may be
//! plain UTF-8 lines or a base64/base64url envelope containing those lines. Unsupported lines are
//! diagnostics in lenient mode, never guessed into a protocol; malformed recognized lines are
//! never turned into synthetic nodes.

use std::collections::{BTreeMap, BTreeSet};

use caly_ir::{
    Digest, NodeId, NormalizedNode, NormalizedSource, ProxyProtocol, RawSource, SourceId,
    SourceKind,
};

use crate::stage::{
    Diagnostic, DiagnosticSeverity, IrPath, Origin, Provenance, ProvenanceDelta, StageId,
};

/// Hard upper bound on normalized nodes from one source body. It is a parser bound, not a
/// merge-time truncation rule: exceeding it is an error so a source cannot silently lose nodes.
pub const MAX_SOURCE_NODES: usize = 1_024;
/// Upper bound for direct parser callers. HTTP callers normally enforce a tighter request cap,
/// but the pure stage must remain safe when fed inline bytes from another boundary.
pub const MAX_SOURCE_BYTES: usize = 4 * 1024 * 1024;
const MAX_SOURCE_DIAGNOSTICS: usize = 128;

type ParsedUriParts = (
    ProxyProtocol,
    Option<String>,
    String,
    u16,
    BTreeMap<String, String>,
);

/// A source body handed to the pure decode/normalize stage by its caller.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct SourceInput {
    pub id: SourceId,
    pub kind: SourceKind,
    pub origin_label: String,
    /// Explicit locator metadata, if the caller has one. The parser never derives it from the
    /// display label; provenance may carry it without making the parser responsible for fetching.
    pub locator: Option<String>,
    pub bytes: Vec<u8>,
    pub media_type: Option<String>,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct ParsedSource {
    pub raw: RawSource,
    pub normalized: NormalizedSource,
    pub diagnostics: Vec<Diagnostic>,
    pub provenance: ProvenanceDelta,
}

/// Decode and normalize one source body.
///
/// `strict = true` makes any unsupported or malformed non-empty line fatal. In lenient mode,
/// unsupported lines are retained as bounded diagnostics, while at least one valid node is still
/// required for success. Errors intentionally name a line number and protocol shape, not the raw
/// line: subscription lines can contain passwords, UUIDs, or tokens (`RFC-0010`).
pub fn parse_source(input: &SourceInput, strict: bool) -> Result<ParsedSource, String> {
    if input.bytes.len() > MAX_SOURCE_BYTES {
        return Err(format!(
            "source {} exceeds the {} byte parser limit",
            input.id.0, MAX_SOURCE_BYTES
        ));
    }
    let digest = Digest(caly_ir::sha256_digest(&input.bytes));
    let raw = RawSource {
        id: input.id.clone(),
        kind: input.kind,
        origin_label: input.origin_label.clone(),
        content_digest: digest.clone(),
        bytes_len: input.bytes.len() as u64,
        media_type: input.media_type.clone(),
    };

    let text = std::str::from_utf8(&input.bytes).map_err(|_| {
        format!(
            "source {} is neither UTF-8 URI text nor a decodable base64 envelope",
            input.id.0
        )
    })?;

    let direct = parse_lines(text, input, strict);
    let parsed = if !direct.nodes.is_empty() {
        direct
    } else if let Some(decoded) =
        decode_base64(text).and_then(|bytes| String::from_utf8(bytes).ok())
    {
        let encoded = parse_lines(&decoded, input, strict);
        if encoded.nodes.is_empty() {
            direct
        } else {
            encoded
        }
    } else {
        direct
    };

    if parsed.fatal || parsed.nodes.is_empty() {
        return Err(parsed
            .first_error
            .unwrap_or_else(|| format!("source {} contains no supported proxy URI", input.id.0)));
    }

    let normalized = NormalizedSource {
        id: input.id.clone(),
        raw_digest: digest,
        source_kind: input.kind,
        nodes: parsed.nodes,
        node_count_estimate: parsed.node_count,
        group_count_estimate: 1,
        rule_count_estimate: 1,
    };
    let provenance = ProvenanceDelta {
        entries: vec![Provenance {
            field: IrPath::from_segments(["source", input.id.0.as_str()]),
            origin: Origin::Source {
                source_id: input.id.0.clone(),
                locator: input.locator.clone(),
            },
            transform: vec![StageId::Ingest, StageId::Decode, StageId::Normalize],
            superseded: Vec::new(),
        }],
    };

    Ok(ParsedSource {
        raw,
        normalized,
        diagnostics: parsed.diagnostics,
        provenance,
    })
}

struct LineParse {
    nodes: Vec<NormalizedNode>,
    diagnostics: Vec<Diagnostic>,
    first_error: Option<String>,
    node_count: usize,
    fatal: bool,
}

fn parse_lines(text: &str, input: &SourceInput, strict: bool) -> LineParse {
    let mut result = LineParse {
        nodes: Vec::new(),
        diagnostics: Vec::new(),
        first_error: None,
        node_count: 0,
        fatal: false,
    };
    let mut ids = BTreeSet::new();

    for (line_index, raw_line) in text.lines().enumerate() {
        let line_number = line_index + 1;
        let line = raw_line.trim().trim_start_matches('\u{feff}').trim();
        if line.is_empty() || line.starts_with('#') || line.starts_with(';') {
            continue;
        }
        if line.len() > 16 * 1024 {
            record_line_error(
                &mut result,
                strict,
                line_number,
                "line exceeds the 16 KiB source-line limit",
                None,
                input,
            );
            continue;
        }

        let scheme = line
            .split_once("://")
            .map(|(scheme, _)| scheme.to_ascii_lowercase());
        let Some(scheme) = scheme else {
            record_line_error(
                &mut result,
                strict,
                line_number,
                "line is not a supported proxy URI",
                None,
                input,
            );
            continue;
        };
        if !is_supported_scheme(&scheme) {
            record_line_error(
                &mut result,
                strict,
                line_number,
                "protocol is not supported by this source slice",
                Some(scheme.as_str()),
                input,
            );
            continue;
        }

        match parse_uri(line, &scheme, input, &mut ids) {
            Ok(node) => {
                if result.nodes.len() >= MAX_SOURCE_NODES {
                    record_line_error(
                        &mut result,
                        true,
                        line_number,
                        "source exceeds the 1024-node limit",
                        Some(scheme.as_str()),
                        input,
                    );
                    break;
                }
                result.nodes.push(node);
                result.node_count += 1;
            }
            Err(detail) => record_line_error(
                &mut result,
                strict,
                line_number,
                &detail,
                Some(scheme.as_str()),
                input,
            ),
        }
    }
    result
}

fn record_line_error(
    result: &mut LineParse,
    strict: bool,
    line_number: usize,
    detail: &str,
    scheme: Option<&str>,
    input: &SourceInput,
) {
    let code = if strict {
        "SOURCE_PARSE_ERROR"
    } else {
        "SOURCE_LINE_SKIPPED"
    };
    let severity = if strict {
        DiagnosticSeverity::Error
    } else {
        DiagnosticSeverity::Warning
    };
    let protocol = scheme.unwrap_or("unknown");
    let summary = format!(
        "source {} line {} ({protocol}) was not normalized",
        input.id.0, line_number
    );
    let diagnostic = Diagnostic {
        code: code.to_owned(),
        severity,
        summary: summary.clone(),
        detail: Some(detail.to_owned()),
        related_path: Some(IrPath::from_segments([
            "source",
            input.id.0.as_str(),
            "line",
            &line_number.to_string(),
        ])),
        remediation: Some(
            "fix or remove the source line; do not rely on display labels as locators".to_owned(),
        ),
    };
    if result.diagnostics.len() < MAX_SOURCE_DIAGNOSTICS {
        result.diagnostics.push(diagnostic);
    }
    if result.first_error.is_none() {
        result.first_error = Some(format!("{summary}: {detail}"));
    }
    if strict {
        // Keep scanning for a deterministic diagnostic set, but remember that a valid node plus
        // a strict error is still a failed source. It must not be accepted merely because one
        // unrelated line happened to parse.
        result.fatal = true;
    }
}

fn is_supported_scheme(scheme: &str) -> bool {
    matches!(
        scheme,
        "ss" | "vmess" | "vless" | "trojan" | "hysteria2" | "hy2" | "tuic"
    )
}

fn parse_uri(
    line: &str,
    scheme: &str,
    input: &SourceInput,
    ids: &mut BTreeSet<String>,
) -> Result<NormalizedNode, String> {
    let rest = line
        .split_once("://")
        .map(|(_, rest)| rest)
        .ok_or_else(|| "URI is missing ://".to_owned())?;
    let (without_fragment, fragment) = rest
        .split_once('#')
        .map_or((rest, None), |(body, name)| (body, Some(name)));

    let (protocol, label, server, port, passthrough) = match scheme {
        "ss" => parse_shadowsocks(without_fragment, fragment)?,
        "vmess" => parse_vmess(without_fragment, fragment)?,
        "vless" => parse_userinfo_uri(without_fragment, fragment, ProxyProtocol::Vless)?,
        "trojan" => parse_userinfo_uri(without_fragment, fragment, ProxyProtocol::Trojan)?,
        "hysteria2" | "hy2" => {
            parse_userinfo_uri(without_fragment, fragment, ProxyProtocol::Hysteria2)?
        }
        "tuic" => parse_userinfo_uri(without_fragment, fragment, ProxyProtocol::Tuic)?,
        _ => return Err("protocol is not supported by this source slice".to_owned()),
    };

    let digest = caly_ir::sha256_hex(line.as_bytes());
    let prefix = format!("{}-{}", input.id.0, &digest[..16]);
    let mut id = prefix.clone();
    let mut duplicate = 2usize;
    while !ids.insert(id.clone()) {
        id = format!("{prefix}-{duplicate}");
        duplicate += 1;
    }

    Ok(NormalizedNode {
        id: NodeId::new(id),
        label: label.unwrap_or_else(|| format!("{server}:{port}")),
        protocol,
        server,
        port,
        passthrough,
    })
}

fn parse_shadowsocks(body: &str, fragment: Option<&str>) -> Result<ParsedUriParts, String> {
    let (without_query, query) = body
        .split_once('?')
        .map_or((body, None), |(base, query)| (base, Some(query)));
    let (encoded_user, encoded_authority) = without_query
        .rsplit_once('@')
        .map_or((None, without_query), |(user, authority)| {
            (Some(user), authority)
        });

    let (credentials, authority) = if let Some(user) = encoded_user {
        let decoded = percent_decode(user)?;
        if decoded.contains(':') {
            (decoded, encoded_authority.to_owned())
        } else {
            let decoded = decode_base64(user)
                .and_then(|bytes| String::from_utf8(bytes).ok())
                .ok_or_else(|| "ss userinfo is not method:password or base64".to_owned())?;
            (decoded, encoded_authority.to_owned())
        }
    } else {
        let decoded = decode_base64(without_query)
            .and_then(|bytes| String::from_utf8(bytes).ok())
            .ok_or_else(|| {
                "ss URI has no decodable method:password@host:port payload".to_owned()
            })?;
        let (credentials, authority) = decoded
            .rsplit_once('@')
            .ok_or_else(|| "ss payload is missing host and port".to_owned())?;
        (credentials.to_owned(), authority.to_owned())
    };
    let (method, password) = credentials
        .split_once(':')
        .ok_or_else(|| "ss credentials are missing method or password".to_owned())?;
    if method.is_empty() || password.is_empty() {
        return Err("ss method and password must not be empty".to_owned());
    }
    let (server, port) = parse_authority(&authority)?;
    let mut passthrough = BTreeMap::new();
    passthrough.insert("method".to_owned(), method.to_owned());
    passthrough.insert("password".to_owned(), password.to_owned());
    append_query(&mut passthrough, query)?;
    Ok((
        ProxyProtocol::Shadowsocks,
        decode_fragment(fragment)?,
        server,
        port,
        passthrough,
    ))
}

fn parse_userinfo_uri(
    body: &str,
    fragment: Option<&str>,
    protocol: ProxyProtocol,
) -> Result<ParsedUriParts, String> {
    let (without_query, query) = body
        .split_once('?')
        .map_or((body, None), |(base, query)| (base, Some(query)));
    let (userinfo, authority) = without_query
        .rsplit_once('@')
        .ok_or_else(|| "URI is missing userinfo and host".to_owned())?;
    let userinfo = percent_decode(userinfo)?;
    let (server, port) = parse_authority(authority)?;
    let mut passthrough = BTreeMap::new();
    match protocol {
        ProxyProtocol::Vless => {
            if userinfo.is_empty() {
                return Err("vless UUID must not be empty".to_owned());
            }
            passthrough.insert("uuid".to_owned(), userinfo);
        }
        ProxyProtocol::Tuic => {
            let (uuid, password) = userinfo
                .split_once(':')
                .ok_or_else(|| "tuic userinfo must be uuid:password".to_owned())?;
            if uuid.is_empty() || password.is_empty() {
                return Err("tuic uuid and password must not be empty".to_owned());
            }
            passthrough.insert("uuid".to_owned(), uuid.to_owned());
            passthrough.insert("password".to_owned(), password.to_owned());
        }
        ProxyProtocol::Trojan | ProxyProtocol::Hysteria2 => {
            if userinfo.is_empty() {
                return Err("proxy password must not be empty".to_owned());
            }
            passthrough.insert("password".to_owned(), userinfo);
        }
        _ => return Err("userinfo form is not supported for this protocol".to_owned()),
    }
    append_query(&mut passthrough, query)?;
    Ok((
        protocol,
        decode_fragment(fragment)?,
        server,
        port,
        passthrough,
    ))
}

fn parse_vmess(body: &str, fragment: Option<&str>) -> Result<ParsedUriParts, String> {
    let decoded = decode_base64(body)
        .and_then(|bytes| String::from_utf8(bytes).ok())
        .ok_or_else(|| "vmess URI is not a decodable base64 JSON object".to_owned())?;
    let server =
        json_string(&decoded, "add").ok_or_else(|| "vmess JSON is missing add".to_owned())?;
    let port = json_scalar(&decoded, "port")
        .and_then(|value| value.parse::<u16>().ok())
        .filter(|port| *port != 0)
        .ok_or_else(|| "vmess JSON has an invalid port".to_owned())?;
    let uuid = json_string(&decoded, "id").ok_or_else(|| "vmess JSON is missing id".to_owned())?;
    let label = decode_fragment(fragment)?.or_else(|| json_string(&decoded, "ps"));
    let mut passthrough = BTreeMap::new();
    passthrough.insert("uuid".to_owned(), uuid);
    for key in ["aid", "net", "type", "host", "path", "tls", "scy", "sni"] {
        if let Some(value) = json_scalar(&decoded, key) {
            passthrough.insert(key.to_owned(), value);
        }
    }
    Ok((ProxyProtocol::Vmess, label, server, port, passthrough))
}

fn parse_authority(authority: &str) -> Result<(String, u16), String> {
    if authority.is_empty() || authority.contains('/') || authority.contains('@') {
        return Err("URI authority is malformed".to_owned());
    }
    if let Some(rest) = authority.strip_prefix('[') {
        let (host, port) = rest
            .split_once(']')
            .ok_or_else(|| "IPv6 authority is missing ]".to_owned())?;
        let port = port
            .strip_prefix(':')
            .ok_or_else(|| "IPv6 authority is missing a port".to_owned())?;
        return parse_host_port(host, port);
    }
    let (host, port) = authority
        .rsplit_once(':')
        .ok_or_else(|| "URI authority is missing a port".to_owned())?;
    if host.contains(':') {
        return Err("IPv6 hosts must use bracket notation".to_owned());
    }
    parse_host_port(host, port)
}

fn parse_host_port(host: &str, port: &str) -> Result<(String, u16), String> {
    if host.is_empty() || host.chars().any(char::is_whitespace) {
        return Err("URI host is empty or contains whitespace".to_owned());
    }
    let port = port
        .parse::<u16>()
        .map_err(|_| "URI port is not a number".to_owned())?;
    if port == 0 {
        return Err("URI port must be between 1 and 65535".to_owned());
    }
    Ok((host.to_owned(), port))
}

fn append_query(target: &mut BTreeMap<String, String>, query: Option<&str>) -> Result<(), String> {
    let Some(query) = query else {
        return Ok(());
    };
    for pair in query.split('&').filter(|pair| !pair.is_empty()) {
        let (key, value) = pair
            .split_once('=')
            .map_or((pair, ""), |(key, value)| (key, value));
        let key = percent_decode(key)?;
        let value = percent_decode(value)?;
        if key.is_empty() {
            return Err("URI query contains an empty key".to_owned());
        }
        if target.insert(key.clone(), value).is_some() {
            return Err(format!("URI query repeats key {key:?}"));
        }
    }
    Ok(())
}

fn decode_fragment(fragment: Option<&str>) -> Result<Option<String>, String> {
    fragment
        .map(percent_decode)
        .transpose()
        .map(|value| value.filter(|text| !text.is_empty()))
}

fn json_scalar(text: &str, key: &str) -> Option<String> {
    let value = json_value(text, key)?;
    Some(value)
}

fn json_string(text: &str, key: &str) -> Option<String> {
    json_value(text, key)
}

/// Minimal JSON member extraction for VMess' small, known fields. This is not a general JSON
/// parser: it accepts a value only when the key is a member token, decodes quoted escapes, and
/// leaves unknown members untouched. Full object preservation belongs to a future JSON source
/// decoder rather than a hand-written permissive parser.
fn json_value(text: &str, key: &str) -> Option<String> {
    let needle = format!("\"{key}\"");
    let mut from = 0usize;
    while let Some(found) = text[from..].find(&needle) {
        let start = from + found;
        let before = text[..start]
            .chars()
            .rev()
            .find(|ch| !ch.is_ascii_whitespace());
        if before != Some('{') && before != Some(',') {
            from = start + needle.len();
            continue;
        }
        let mut index = start + needle.len();
        while text
            .as_bytes()
            .get(index)
            .is_some_and(u8::is_ascii_whitespace)
        {
            index += 1;
        }
        if text.as_bytes().get(index) != Some(&b':') {
            from = start + needle.len();
            continue;
        }
        index += 1;
        while text
            .as_bytes()
            .get(index)
            .is_some_and(u8::is_ascii_whitespace)
        {
            index += 1;
        }
        if text.as_bytes().get(index) == Some(&b'\"') {
            return parse_json_string(text, index);
        }
        let end = text[index..]
            .char_indices()
            .find(|(_, ch)| *ch == ',' || *ch == '}' || ch.is_ascii_whitespace())
            .map_or(text.len(), |(offset, _)| index + offset);
        return (end > index).then(|| text[index..end].to_owned());
    }
    None
}

fn parse_json_string(text: &str, quote: usize) -> Option<String> {
    let mut output = String::new();
    let mut index = quote + 1;
    while index < text.len() {
        let ch = text[index..].chars().next()?;
        index += ch.len_utf8();
        match ch {
            '"' => return Some(output),
            '\\' => {
                let escaped = text[index..].chars().next()?;
                index += escaped.len_utf8();
                match escaped {
                    '"' => output.push('"'),
                    '\\' => output.push('\\'),
                    '/' => output.push('/'),
                    'b' => output.push('\u{0008}'),
                    'f' => output.push('\u{000c}'),
                    'n' => output.push('\n'),
                    'r' => output.push('\r'),
                    't' => output.push('\t'),
                    'u' => {
                        let hex = text.get(index..index + 4)?;
                        let value = u32::from_str_radix(hex, 16).ok()?;
                        output.push(char::from_u32(value)?);
                        index += 4;
                    }
                    _ => return None,
                }
            }
            other => output.push(other),
        }
    }
    None
}

fn percent_decode(value: &str) -> Result<String, String> {
    let mut bytes = Vec::with_capacity(value.len());
    let raw = value.as_bytes();
    let mut index = 0usize;
    while index < raw.len() {
        if raw[index] != b'%' {
            bytes.push(raw[index]);
            index += 1;
            continue;
        }
        let high = raw.get(index + 1).and_then(|byte| hex_value(*byte));
        let low = raw.get(index + 2).and_then(|byte| hex_value(*byte));
        let (Some(high), Some(low)) = (high, low) else {
            return Err("URI contains an invalid percent escape".to_owned());
        };
        bytes.push((high << 4) | low);
        index += 3;
    }
    String::from_utf8(bytes).map_err(|_| "URI percent escape is not UTF-8".to_owned())
}

fn hex_value(byte: u8) -> Option<u8> {
    match byte {
        b'0'..=b'9' => Some(byte - b'0'),
        b'a'..=b'f' => Some(byte - b'a' + 10),
        b'A'..=b'F' => Some(byte - b'A' + 10),
        _ => None,
    }
}

fn decode_base64(input: &str) -> Option<Vec<u8>> {
    let mut compact: Vec<u8> = input
        .bytes()
        .filter(|byte| !byte.is_ascii_whitespace())
        .collect();
    if compact.is_empty() || compact.len() % 4 == 1 {
        return None;
    }
    while !compact.len().is_multiple_of(4) {
        compact.push(b'=');
    }
    if let Some(first_padding) = compact.iter().position(|byte| *byte == b'=') {
        if first_padding < compact.len().saturating_sub(2)
            || compact[first_padding..].iter().any(|byte| *byte != b'=')
        {
            return None;
        }
    }

    let mut output = Vec::with_capacity(compact.len() * 3 / 4);
    for chunk in compact.chunks(4) {
        let [first_byte, second_byte, third_byte, fourth_byte] = chunk else {
            return None;
        };
        let first = base64_value(*first_byte)?;
        let second = base64_value(*second_byte)?;
        let third = if *third_byte == b'=' {
            None
        } else {
            Some(base64_value(*third_byte)?)
        };
        let fourth = if *fourth_byte == b'=' {
            None
        } else {
            Some(base64_value(*fourth_byte)?)
        };
        if third.is_none() && fourth.is_some() {
            return None;
        }
        output.push((first << 2) | (second >> 4));
        if let Some(third) = third {
            output.push((second << 4) | (third >> 2));
            if let Some(fourth) = fourth {
                output.push((third << 6) | fourth);
            }
        }
    }
    Some(output)
}

fn base64_value(byte: u8) -> Option<u8> {
    match byte {
        b'A'..=b'Z' => Some(byte - b'A'),
        b'a'..=b'z' => Some(byte - b'a' + 26),
        b'0'..=b'9' => Some(byte - b'0' + 52),
        b'+' | b'-' => Some(62),
        b'/' | b'_' => Some(63),
        _ => None,
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    fn input(body: &str) -> SourceInput {
        SourceInput {
            id: SourceId::new("source-test"),
            kind: SourceKind::Subscription,
            origin_label: "test source".to_owned(),
            locator: Some("http://subscription.test/feed".to_owned()),
            bytes: body.as_bytes().to_vec(),
            media_type: Some("text/plain".to_owned()),
        }
    }

    #[test]
    fn parses_uri_lines_into_real_nodes_and_sha256_identity() {
        let parsed = parse_source(
            &input(
                "vless://uuid-1@example.test:443?security=tls&sni=edge.test#Edge\n\
                 trojan://secret@example.org:8443#Backup\n",
            ),
            true,
        )
        .expect("two valid URI lines");
        assert_eq!(parsed.normalized.nodes.len(), 2);
        assert_eq!(parsed.normalized.nodes[0].protocol, ProxyProtocol::Vless);
        assert_eq!(parsed.normalized.nodes[0].server, "example.test");
        assert_eq!(parsed.normalized.nodes[0].port, 443);
        assert_eq!(parsed.normalized.nodes[0].label, "Edge");
        assert_eq!(
            parsed.normalized.nodes[0].passthrough.get("uuid"),
            Some(&"uuid-1".to_owned())
        );
        assert_eq!(
            parsed.raw.content_digest.0,
            caly_ir::sha256_digest(
                input(
                    "vless://uuid-1@example.test:443?security=tls&sni=edge.test#Edge\n\
                 trojan://secret@example.org:8443#Backup\n",
                )
                .bytes
                .as_slice()
            )
        );
        assert_eq!(parsed.provenance.entries.len(), 1);
        assert!(parsed.provenance.entries[0]
            .transform
            .contains(&StageId::Normalize));
    }

    #[test]
    fn decodes_the_real_subscription_fixture_into_all_expected_nodes() {
        let bytes = std::fs::read(concat!(
            env!("CARGO_MANIFEST_DIR"),
            "/../../fixtures/subscription-20260803.txt"
        ))
        .expect("real subscription fixture");
        let source = SourceInput {
            id: SourceId::new("fixture-subscription"),
            kind: SourceKind::Subscription,
            origin_label: "2026-08-03 fixture".to_owned(),
            locator: Some("https://fixture.invalid/subscription".to_owned()),
            bytes: bytes.clone(),
            media_type: Some("text/plain".to_owned()),
        };
        let parsed = parse_source(&source, true).expect("the real fixture is a valid envelope");
        assert_eq!(parsed.normalized.nodes.len(), 30);
        assert_eq!(parsed.normalized.node_count_estimate, 30);
        assert_eq!(
            parsed.raw.content_digest.0,
            caly_ir::sha256_digest(bytes.as_slice())
        );
        assert!(parsed.normalized.nodes.iter().any(|node| {
            node.protocol == ProxyProtocol::Vless && node.server == "rezerv23.yunus.guru"
        }));
        assert!(parsed.normalized.nodes.iter().any(|node| {
            node.protocol == ProxyProtocol::Vmess && node.server == "47.86.167.194"
        }));
        assert_eq!(parsed.provenance.entries.len(), 1);
        assert_eq!(
            parsed.provenance.entries[0].origin,
            Origin::Source {
                source_id: "fixture-subscription".to_owned(),
                locator: Some("https://fixture.invalid/subscription".to_owned()),
            }
        );
        assert!(parsed.diagnostics.is_empty());
    }

    #[test]
    fn decodes_a_base64_subscription_without_leaking_credentials_to_diagnostics() {
        let plain = "ss://YWVzLTI1Ni1nY206c2VjcmV0@example.test:8388#Office\n";
        let encoded = base64_for_test(plain.as_bytes());
        let parsed = parse_source(&input(&encoded), true).expect("base64 URI list");
        assert_eq!(parsed.normalized.nodes.len(), 1);
        assert_eq!(
            parsed.normalized.nodes[0].protocol,
            ProxyProtocol::Shadowsocks
        );
        assert_eq!(parsed.normalized.nodes[0].label, "Office");
        assert!(parsed.diagnostics.iter().all(|diagnostic| {
            !diagnostic.summary.contains("secret")
                && !diagnostic
                    .detail
                    .as_deref()
                    .unwrap_or_default()
                    .contains("secret")
        }));
    }

    #[test]
    fn lenient_mode_skips_unknown_lines_but_strict_mode_rejects_them() {
        let body = "not-a-proxy-line\nvless://uuid@example.test:443#ok\n";
        let lenient = parse_source(&input(body), false).expect("one valid line remains");
        assert_eq!(lenient.normalized.nodes.len(), 1);
        assert_eq!(lenient.diagnostics.len(), 1);
        assert_eq!(lenient.diagnostics[0].code, "SOURCE_LINE_SKIPPED");
        assert!(parse_source(&input(body), true).is_err());
    }

    #[test]
    fn malformed_uri_never_becomes_a_synthetic_node() {
        let error = parse_source(&input("vless://missing-port@example.test#bad\n"), false)
            .expect_err("a recognized malformed URI must not be guessed");
        assert!(error.contains("line 1"));
        assert!(!error.contains("missing-port@example.test"));
    }

    #[test]
    fn base64_and_percent_decoders_obey_external_vectors() {
        assert_eq!(decode_base64("SGVsbG8="), Some(b"Hello".to_vec()));
        assert_eq!(decode_base64("SGVsbG8"), Some(b"Hello".to_vec()));
        assert_eq!(decode_base64("SGVsbG8tXw"), Some(b"Hello-_".to_vec()));
        assert_eq!(percent_decode("edge%20node"), Ok("edge node".to_owned()));
        assert!(percent_decode("bad%2").is_err());
    }

    fn base64_for_test(bytes: &[u8]) -> String {
        const ALPHABET: &[u8; 64] =
            b"ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
        let mut output = String::new();
        for chunk in bytes.chunks(3) {
            let a = chunk[0];
            let b = chunk.get(1).copied().unwrap_or(0);
            let c = chunk.get(2).copied().unwrap_or(0);
            output.push(ALPHABET[(a >> 2) as usize] as char);
            output.push(ALPHABET[((a << 4 | b >> 4) & 0x3f) as usize] as char);
            output.push(if chunk.len() > 1 {
                ALPHABET[((b << 2 | c >> 6) & 0x3f) as usize] as char
            } else {
                '='
            });
            output.push(if chunk.len() > 2 {
                ALPHABET[(c & 0x3f) as usize] as char
            } else {
                '='
            });
        }
        output
    }
}
