use caly_domain::{OverrideRule, Profile, SelectionMemory};
use caly_ir::NormalizedSource;

use crate::source::SourceInput;

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct PipelineRequest {
    pub profile: Profile,
    /// Explicit source bytes for the real decode/normalize path. Empty retains the legacy
    /// estimate-only fixtures until their caller supplies a fetched body.
    pub source_inputs: Vec<SourceInput>,
    pub normalized_sources: Vec<NormalizedSource>,
    pub overrides: Vec<OverrideRule>,
    pub selection_memory: Option<SelectionMemory>,
    pub strict_mode: bool,
}
