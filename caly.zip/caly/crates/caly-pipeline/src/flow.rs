use caly_core::CoreAdapter;
use caly_domain::{MergeReport, Profile};
use caly_ir::{NormalizedSource, ResolvedProfile};
use caly_plan::{ApplyPlan, EffectPlan};

use crate::compile::{compile_for_adapter, CompilationOutput};
use crate::input::PipelineRequest;
use crate::merge::{merge_profile, MergeInput};
use crate::resolve::{resolve_ir, ResolveInput};
use crate::source::parse_source;
use crate::stage::{Diagnostic, ProvenanceDelta, StageContext};
use crate::validate::{validate_capabilities, validate_semantic, CapabilityValidationReport};

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct PipelineFlowOutput {
    pub merge_report: MergeReport,
    pub diagnostics: Vec<Diagnostic>,
    /// Field-level source provenance from the real ingest/decode/normalize path. Legacy estimate
    /// fixtures have an empty delta rather than fabricated source locations.
    pub provenance: ProvenanceDelta,
    pub resolved_profile: ResolvedProfile,
    pub capability_validation: Option<CapabilityValidationReport>,
    pub compile: Option<CompilationOutput>,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct ApplyWorkflowProjection {
    pub resolved_profile: ResolvedProfile,
    pub capability_validation: Option<CapabilityValidationReport>,
    pub provenance: ProvenanceDelta,
    pub apply_plan: ApplyPlan,
    pub effect_plan: Option<EffectPlan>,
    pub diagnostics: Vec<Diagnostic>,
}

pub fn run_pipeline(request: PipelineRequest, cx: StageContext) -> PipelineFlowOutput {
    let (normalized_sources, source_diagnostics, provenance) = if request.source_inputs.is_empty() {
        (
            collect_sources(&request.profile, &request.normalized_sources),
            Vec::new(),
            ProvenanceDelta::default(),
        )
    } else {
        parse_source_inputs(&request.source_inputs, request.strict_mode)
    };
    let merge = merge_profile(
        MergeInput {
            profile: request.profile,
            normalized_sources,
            overrides: request.overrides,
        },
        &cx,
    );

    let resolve = resolve_ir(
        ResolveInput {
            ir: merge.ir,
            selection_memory: request.selection_memory,
        },
        &cx,
    );

    let semantic = validate_semantic(&resolve.profile, &cx);

    let mut diagnostics = source_diagnostics;
    diagnostics.extend(merge.diagnostics.clone());
    diagnostics.extend(resolve.diagnostics.clone());
    diagnostics.extend(semantic.diagnostics);

    PipelineFlowOutput {
        merge_report: merge.report,
        diagnostics,
        provenance,
        resolved_profile: resolve.profile,
        capability_validation: None,
        compile: None,
    }
}

pub fn run_pipeline_for_adapter(
    request: PipelineRequest,
    cx: StageContext,
    adapter: &dyn CoreAdapter,
    current: Option<&caly_ir::CompiledArtifact>,
) -> Result<PipelineFlowOutput, String> {
    let mut output = run_pipeline(request, cx.clone());
    let compiled = compile_for_adapter(adapter, &output.resolved_profile, current, cx.strict_mode)?;
    let capability_validation = validate_capabilities(
        &output.resolved_profile,
        &compiled.capabilities,
        cx.strict_mode,
    );
    output.diagnostics.extend(compiled.diagnostics.clone());
    output
        .diagnostics
        .extend(capability_validation.diagnostics.clone());
    output.capability_validation = Some(capability_validation);
    output.compile = Some(compiled);
    Ok(output)
}

pub fn project_apply_workflow(output: PipelineFlowOutput) -> Option<ApplyWorkflowProjection> {
    let compiled = output.compile?;
    Some(ApplyWorkflowProjection {
        resolved_profile: output.resolved_profile,
        capability_validation: output.capability_validation,
        provenance: output.provenance,
        apply_plan: compiled.apply_planning.apply_plan,
        effect_plan: compiled.apply_planning.effect_plan,
        diagnostics: output.diagnostics,
    })
}

fn parse_source_inputs(
    inputs: &[crate::source::SourceInput],
    strict_mode: bool,
) -> (Vec<NormalizedSource>, Vec<Diagnostic>, ProvenanceDelta) {
    let mut normalized = Vec::with_capacity(inputs.len());
    let mut diagnostics = Vec::new();
    let mut provenance = ProvenanceDelta::default();
    for input in inputs {
        match parse_source(input, strict_mode) {
            Ok(parsed) => {
                normalized.push(parsed.normalized);
                diagnostics.extend(parsed.diagnostics);
                provenance.entries.extend(parsed.provenance.entries);
            }
            Err(summary) => {
                diagnostics.push(Diagnostic {
                    code: "SOURCE_PARSE_FAILED".to_owned(),
                    severity: crate::stage::DiagnosticSeverity::Error,
                    summary: summary.clone(),
                    detail: None,
                    related_path: Some(crate::stage::IrPath::from_segments([
                        "source",
                        input.id.0.as_str(),
                    ])),
                    remediation: Some(
                        "provide a supported URI subscription body or fix the source payload"
                            .to_owned(),
                    ),
                });
                // Keep the source attached without manufacturing a node. Merge sees the zero
                // estimate and leaves the failed source out of the graph rather than silently
                // replacing it with a synthetic endpoint.
                normalized.push(NormalizedSource {
                    id: input.id.clone(),
                    raw_digest: caly_ir::Digest(format!("invalid:{}", input.id.0)),
                    source_kind: input.kind,
                    nodes: Vec::new(),
                    node_count_estimate: 0,
                    group_count_estimate: 0,
                    rule_count_estimate: 0,
                });
            }
        }
    }
    (normalized, diagnostics, provenance)
}

fn collect_sources(
    profile: &Profile,
    normalized_sources: &[NormalizedSource],
) -> Vec<NormalizedSource> {
    if !normalized_sources.is_empty() {
        return normalized_sources.to_vec();
    }

    profile
        .source_refs
        .iter()
        .map(|source| NormalizedSource {
            id: source.id.clone(),
            raw_digest: caly_ir::Digest(format!("raw:{}", source.id.0)),
            source_kind: caly_ir::SourceKind::Subscription,
            nodes: Vec::new(),
            node_count_estimate: 1,
            group_count_estimate: 1,
            rule_count_estimate: 1,
        })
        .collect()
}

#[cfg(test)]
mod tests {
    use super::*;
    use caly_domain::{attach_sources, skeleton_profile, source_ref};
    use caly_ir::{CoreTarget, RoutingMode, SourceId, SourceKind};

    fn context() -> StageContext {
        StageContext {
            pipeline_epoch: crate::stage::PIPELINE_EPOCH,
            adapter_version: 1,
            strict_mode: false,
        }
    }

    fn request(body: &str) -> PipelineRequest {
        let profile = attach_sources(
            skeleton_profile("profile", "Profile", CoreTarget::Mihomo, RoutingMode::Rule),
            vec![source_ref("feed", "Feed")],
        );
        PipelineRequest {
            profile,
            source_inputs: vec![crate::source::SourceInput {
                id: SourceId::new("feed"),
                kind: SourceKind::Subscription,
                origin_label: "Feed".to_owned(),
                locator: Some("http://feed.test/sub".to_owned()),
                bytes: body.as_bytes().to_vec(),
                media_type: Some("text/plain".to_owned()),
            }],
            normalized_sources: Vec::new(),
            overrides: Vec::new(),
            selection_memory: None,
            strict_mode: false,
        }
    }

    #[test]
    fn flow_materializes_parser_nodes_instead_of_estimates() {
        let output = run_pipeline(request("vless://uuid@example.test:443#Edge\n"), context());
        assert_eq!(output.resolved_profile.nodes.len(), 1);
        assert_eq!(output.resolved_profile.nodes[0].label, "Edge");
        assert_eq!(output.resolved_profile.nodes[0].server, "example.test");
        assert_eq!(output.resolved_profile.nodes[0].port, 443);
        assert_eq!(output.provenance.entries.len(), 1);
        assert!(output.provenance.entries[0]
            .transform
            .contains(&crate::stage::StageId::Decode));
    }

    #[test]
    fn failed_explicit_parse_does_not_fall_back_to_a_synthetic_node() {
        let output = run_pipeline(
            request("vless://missing-port@example.test#broken\n"),
            context(),
        );
        assert!(output.resolved_profile.nodes.is_empty());
        assert!(output
            .diagnostics
            .iter()
            .any(|diagnostic| diagnostic.code == "SOURCE_PARSE_FAILED"));
    }
}
