//! Re-export facade: caly-configstore has been consolidated into caly-profile::store.
//! All configuration writers, YAML surgery, and resource mutation tools are re-exported here.

#![forbid(unsafe_code)]
#![cfg_attr(test, allow(clippy::unwrap_used, clippy::expect_used, clippy::panic, clippy::todo, clippy::unimplemented, clippy::unreachable))]

pub use caly_profile::store::*;
