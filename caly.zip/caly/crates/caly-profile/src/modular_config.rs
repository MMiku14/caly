//! Four-tier modular configuration architecture.
//!
//! Separates concerns into distinct, safely-scoped configuration domains:
//! - `daemon.toml`: Host daemon runtime (UDS socket, log level, privilege policy)
//! - `core.yaml`: Proxy kernel baseline (ports, allow-lan, TUN, Fake-IP DNS)
//! - `routing.yaml`: Proxy groups, rule providers, and routing matchers
//! - `subscriptions.yaml`: Remote subscription feeds and refresh cadence

use std::path::{Path, PathBuf};

/// Paths defining the four-layer configuration layout.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct ModularConfigLayout {
    pub daemon_config: PathBuf,
    pub core_config: PathBuf,
    pub routing_config: PathBuf,
    pub subscriptions_config: PathBuf,
}

impl ModularConfigLayout {
    /// Discovers standard configuration paths under `root`.
    pub fn new(root: &Path) -> Self {
        Self {
            daemon_config: root.join("daemon.toml"),
            core_config: root.join("core.yaml"),
            routing_config: root.join("routing.yaml"),
            subscriptions_config: root.join("subscriptions.yaml"),
        }
    }
}
