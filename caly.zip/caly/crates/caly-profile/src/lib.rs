//! Configuration infrastructure for caly.
//!
//! Schema parsing, validation and generation caches live here. Subscription
//! intake/fetch moved to `caly-subscription` (P6, with the `reqwest` WAN
//! boundary); process-based template rendering moved to `caly-template` (P2);
//! application coordinators own publication.

#![forbid(unsafe_code)]
#![cfg_attr(test, allow(clippy::unwrap_used, clippy::expect_used, clippy::panic, clippy::todo, clippy::unimplemented, clippy::unreachable))] // #53: tests assert with unwrap/expect/panic (+todo/unreachable in fixtures); production lints stay deny
pub mod loader;
pub mod profile_fetch;
pub mod profile_store;
pub mod rule_match;
pub mod schema;

pub mod store;
pub use store::*;

pub mod modular_config;
pub use modular_config::ModularConfigLayout;

pub mod migration;
pub use migration::{migrate_config_tree, MigrationOutcome};
