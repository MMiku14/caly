//! Proxy-content `providers:` validation (name shape, inline-node URIs).
//!
//! Split out of `validate.rs` (audit #70 file-length budget); every check
//! here is reached from `super::validate` and turns a
//! parseable-but-unusable configuration into an explicit boot failure.

use super::{AppConfig, ConfigError};

/// Maximum `providers:` entries in one configuration (proxy-content
/// providers; mirrors the rule-provider budget).
const MAX_PROXY_PROVIDERS: usize = 64;
/// Maximum inline node URIs one `InlineNodes` provider may carry.
const MAX_INLINE_PROVIDER_NODES: usize = 1_024;

/// Validates every `providers:` entry. Names must be non-empty and
/// unique (a provider is the user-visible container selected by name);
/// `InlineNodes` bodies must be parseable proxy URIs — the same parser
/// `sub import` runs — so a typo fails at `config validate`, not at
/// render time.
pub(super) fn validate_providers(config: &AppConfig) -> Result<(), ConfigError> {
    use super::super::settings::ProviderKind;
    if config.providers.len() > MAX_PROXY_PROVIDERS {
        return Err(ConfigError::InvalidProvider {
            name: String::new(),
            reason: format!("more than {MAX_PROXY_PROVIDERS} providers"),
        });
    }
    let mut seen_names: std::collections::HashSet<&str> = std::collections::HashSet::new();
    for provider in &config.providers {
        if provider.name.trim().is_empty() {
            return Err(ConfigError::InvalidProvider {
                name: String::new(),
                reason: "provider name must not be empty".to_owned(),
            });
        }
        if !seen_names.insert(provider.name.as_str()) {
            return Err(ConfigError::InvalidProvider {
                name: provider.name.clone(),
                reason: "provider name must be unique".to_owned(),
            });
        }
        if let ProviderKind::InlineNodes(uris) = &provider.kind {
            if uris.len() > MAX_INLINE_PROVIDER_NODES {
                return Err(ConfigError::InvalidProvider {
                    name: provider.name.clone(),
                    reason: format!("more than {MAX_INLINE_PROVIDER_NODES} inline nodes"),
                });
            }
            // Validation-only parse: the subscription id is part of the
            // node identity, not of the URI's syntactic validity, so a
            // zeroed placeholder is fine here.
            let placeholder = caly_domain::SubscriptionId::from_bytes([0u8; 16]);
            for uri in uris {
                caly_subscription::parse_any_proxy_uri(uri, placeholder).map_err(|error| {
                    ConfigError::InvalidProvider {
                        name: provider.name.clone(),
                        reason: format!("inline node `{uri}` is invalid: {error:?}"),
                    }
                })?;
            }
        }
    }
    Ok(())
}
