//! Generated `config.d/90-routing.yaml` and `config.d/95-rule-providers.yaml`
//! fragment text.
//!
//!
//! The routing fragment seeds `rules:` with geo-based defaults:
//! private/reserved addresses and mainland-China domains/IPs go
//! DIRECT through `GEOIP` / `GEOSITE` matchers, and everything else
//! falls through to the renderer's `MATCH` catch-all. Geo data is
//! kernel-native on both sides (Mihomo auto-downloads its geodata;
//! sing-box gets auto-emitted SagerNet `.srs` remote rule-sets), so a
//! fresh install has working defaults with no shipped rule bodies,
//! no network fetch at generate time, and no external file dependency.
//! The rule-providers fragment ships commented Loyalsoldier
//! `v2ray-rules-dat` examples covering all three source kinds (`http`
//! / `file` / `inline`) and the three `behavior:` values the renderer
//! understands.

use std::path::PathBuf;

/// The default routing rules shipped by `config generate` and used by the
/// runtime when no `config.yaml` exists. Geo-only: private/reserved
/// addresses plus mainland-China domains/IPs go DIRECT; the pair needs
/// no `rule_providers:` backing (geo data is kernel-native), so the
/// defaults always validate and render on both Mihomo and sing-box.
pub fn default_rule_lines() -> Vec<String> {
    [
        "GEOIP,private,DIRECT",
        "GEOSITE,cn,DIRECT",
        "GEOIP,cn,DIRECT",
    ]
    .into_iter()
    .map(str::to_owned)
    .collect()
}

/// Renders the active `rules:` block used by the generated fragment.
fn render_default_rules_block() -> String {
    let mut block = String::from("rules:\n");
    for line in default_rule_lines() {
        block.push_str("  - ");
        block.push_str(&line);
        block.push('\n');
    }
    block
}

/// The `config.d/90-routing.yaml` fragment. The default keeps
/// private/reserved addresses and mainland-China domains/IPs DIRECT
/// through geo matchers; the renderer still appends the
/// `MATCH,<group>` catch-all when the list does not end one.
pub(super) fn routing_fragment() -> (PathBuf, String) {
    let body = format!(
        "# Routing rules. First match wins. The `MATCH,<group>` catch-all is\n\
         # appended by the renderer when this list does not already end one.\n\
         # The geo-only defaults below keep private/reserved addresses and\n\
         # mainland-China domains/IPs DIRECT; unmatched traffic falls\n\
         # through to the catch-all. Geo data is kernel-native: Mihomo\n\
         # downloads its geodata automatically, sing-box gets auto-emitted\n\
         # SagerNet `.srs` remote rule-sets — no `rule_providers:` entries\n\
         # are needed for the defaults.\n\
         #\n\
         # Available matchers:\n\
         #   - DOMAIN,<host>           exact host match\n\
         #   - DOMAIN-SUFFIX,<suffix>  host ends with the suffix\n\
         #   - DOMAIN-KEYWORD,<key>    host contains the keyword\n\
         #   - GEOIP,<cc>              GeoIP database lookup (Mihomo / sing-box)\n\
         #   - IP-CIDR,<cidr>          source/destination IP CIDR\n\
         #   - SRC-IP-CIDR,<cidr>      source-only IP CIDR (sing-box 1.12+)\n\
         #   - PROCESS-NAME,<glob>     process executable name (mihomo only)\n\
         #   - RULE-SET,<name>,<out>   user-declared provider from\n\
         #                             `rule_providers:` (Mihomo / sing-box)\n\
         #   - GEOSITE,<category>,<out>  SagerNet geosite category; caly\n\
         #                                auto-emits the rule set on the\n\
         #                                sing-box side, mihomo uses the\n\
         #                                built-in `geosite`.\n\
         #   - MATCH,<out>             catch-all\n\
         {default_rules}\n\
         # Example routing (uncomment the lines you want, then list the\n\
         # referenced providers in 95-rule-providers.yaml below):\n\
         # rules:\n\
         #   - DOMAIN-SUFFIX,example.com,DIRECT\n\
         #   - GEOIP,CN,DIRECT\n\
         #   - GEOSITE,private,DIRECT\n\
         #   - SRC-IP-CIDR,192.168.0.0/16,DIRECT\n\
         #   - RULE-SET,my-google,DIRECT\n\
         #   - PROCESS-NAME,docker,DIRECT\n\
         #   - MATCH,PROXY\n",
        default_rules = render_default_rules_block(),
    );
    (PathBuf::from("config.d/90-routing.yaml"), body)
}

/// The `config.d/95-rule-providers.yaml` fragment. The geo-only default
/// routing rules need no providers, so the only active line is an
/// explicit empty `rule_providers: []` (a comment-only document would
/// parse to null and break the layered merge); every snippet stays
/// commented and uncommenting one produces a self-validating config
/// (validated at load time).
pub(super) fn rule_providers_fragment() -> (PathBuf, String) {
    let body = String::from(
        "# User-declared rule providers. Each entry must have a unique\n\
         # `name`; a `RULE-SET,<name>,<out>` rule in 90-routing.yaml\n\
         # refers to that name. The default routing rules are geo-only\n\
         # and need no providers, so everything below is commented:\n\
         # uncomment a snippet to opt in.\n\
         #\n\
         # Available source kinds (`type:`):\n\
         #   type: http    url + interval_ms (>= 60000) ; the core\n\
         #                 fetches the body on its own polling cadence.\n\
         #   type: file    path on disk; the core reads the body once\n\
         #                 at start.\n\
         #   type: inline  payload: the rule body inline; caly-specific\n\
         #                 extension to the upstream spec, see CHANGELOG\n\
         #                 `Round 6`.\n\
         #\n\
         # Available behaviors (`behavior:`):\n\
         #   domain         exact host matchers (DOMAIN,...)\n\
         #   domain_suffix  suffix matchers; use `+.suffix` body lines\n\
         #                  for Mihomo (sing-box treats every line as a\n\
         #                  suffix after stripping the `+.` marker)\n\
         #   ip_cidr        CIDR matchers (IP-CIDR,...)\n\
         #   classical      full Mihomo rule lines (TYPE,arg,out)\n\
         #\n\
         # Available formats (`format:`):\n\
         #   source         text body (default)\n\
         #   binary         compiled rule set (Mihomo `.mrs` / sing-box\n\
         #                  `.srs`), only valid with `type: http` or\n\
         #                  `type: file`.\n\
         #\n\
         # Example providers (Loyalsoldier v2ray-rules-dat; uncomment to use):\n\
         #\n\
         # The geo-only defaults need no providers; the explicit empty\n\
         # list keeps this fragment a mergeable mapping.\n\
         rule_providers: []\n\
         # rule_providers:\n\
         #   - name: private\n\
         #     type: http\n\
         #     behavior: domain_suffix\n\
         #     format: source\n\
         #     url: https://raw.githubusercontent.com/Loyalsoldier/v2ray-rules-dat/release/private-domain-list.txt\n\
         #     interval_ms: 86400000\n\
         #   - name: gfw\n\
         #     type: http\n\
         #     behavior: domain_suffix\n\
         #     format: source\n\
         #     url: https://raw.githubusercontent.com/Loyalsoldier/v2ray-rules-dat/release/gfw.txt\n\
         #     interval_ms: 86400000\n\
         #   - name: cncidr\n\
         #     type: http\n\
         #     behavior: ip_cidr\n\
         #     format: source\n\
         #     url: https://raw.githubusercontent.com/Loyalsoldier/v2ray-rules-dat/release/cn-cidr.txt\n\
         #     interval_ms: 86400000\n\
         #   - name: local-extra\n\
         #     type: file\n\
         #     behavior: domain_suffix\n\
         #     format: source\n\
         #     path: /etc/caly/extra-rules.yaml\n\
         #   - name: inline-blocklist\n\
         #     type: inline\n\
         #     behavior: domain\n\
         #     format: source\n\
         #     payload: |\n\
         #       ads.example.com\n\
         #       track.example.org\n\
         #       metrics.example.io\n",
    );
    (PathBuf::from("config.d/95-rule-providers.yaml"), body)
}
