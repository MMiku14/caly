//! Schema validation tests, split by section so each fixture group stays
//! within the file-length budget.

use super::*;

mod core;
mod profiles_groups;
mod rule_providers;
