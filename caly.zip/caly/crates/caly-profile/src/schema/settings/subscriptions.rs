//! Subscription sources and proxy-content provider settings.
//!
//! Split out of `settings.rs` (audit #70 file-length budget).

use serde::{Deserialize, Serialize};

/// Subscription refresh source and fetch-policy inputs wired to the daemon.
#[derive(Clone, Debug, Deserialize, Eq, PartialEq, Serialize)]
#[serde(default, deny_unknown_fields)]
pub struct SubscriptionConfig {
    /// Public HTTP(S) subscription URL. Omitted means the legacy single-source
    /// path is unavailable; prefer `sources` for multi-source refresh.
    pub url: Option<String>,
    /// Multiple explicit subscription sources; each is refreshed when
    /// `caly sub refresh` runs. `enabled` toggles an individual source.
    #[serde(default)]
    pub sources: Vec<SubscriptionSource>,
    /// TCP connect timeout for one fetch attempt in milliseconds (>= 100).
    pub connect_timeout_ms: u64,
    /// Overall request timeout for one fetch attempt in milliseconds (>= 1000).
    pub request_timeout_ms: u64,
    /// Maximum accepted response body in mebibytes (1..=256).
    pub max_body_mb: u64,
    /// Follow HTTP redirects (disabled by default for SSRF containment).
    /// Even when enabled, redirects are pinned to the original host: a
    /// cross-host Location hop stops the fetch rather than bypassing the
    /// DNS pinning (audit #111).
    pub follow_redirects: bool,
    /// Route the fetch through the environment proxy variables.
    pub use_environment_proxy: bool,
    /// Daemon-side periodic refresh cadence in minutes. `0`
    /// (default) disables the background timer entirely — the
    /// operator opts in so an unattended daemon never surprises
    /// them with outbound fetches (#59). Anything from `1`
    /// upwards spawns the timer.
    pub refresh_interval_minutes: u64,
}

/// One explicit subscription source in `subscriptions.sources`.
#[derive(Clone, Debug, Deserialize, Eq, PartialEq, Serialize)]
#[serde(default, deny_unknown_fields)]
pub struct SubscriptionSource {
    /// Public HTTP(S) subscription URL.
    pub url: String,
    /// Refresh this source on `caly sub refresh` (default true).
    pub enabled: bool,
    /// Optional human-friendly display name (`set sub add --name`).
    /// Absent for sources declared before the flag landed; never
    /// serialised when `None` so existing configs round-trip
    /// byte-for-byte.
    #[serde(skip_serializing_if = "Option::is_none")]
    pub name: Option<String>,
}

impl Default for SubscriptionSource {
    fn default() -> Self {
        Self {
            url: String::new(),
            enabled: true,
            name: None,
        }
    }
}

/// A named provider grouping subscription sources or inline node URIs.
///
/// A provider is the user-visible container for proxy content: a
/// `SubscriptionSources` provider aggregates every enabled subscription source
/// (enumeration type), while an `InlineNodes` provider holds bare proxy-node URIs
/// (`vmess://`, `ss://`, …) that carry no upstream subscription URL. When
/// `providers:` is unset, a `default` provider is derived automatically from
/// `subscriptions.*` — the exact set `caly sub list` reads.
#[derive(Clone, Debug, Deserialize, Eq, PartialEq, Serialize)]
#[serde(default, deny_unknown_fields)]
pub struct ProviderConfig {
    /// Provider tag; `default` is the auto-derived one.
    pub name: String,
    /// What the provider contains.
    pub kind: ProviderKind,
}

impl Default for ProviderConfig {
    fn default() -> Self {
        Self {
            name: "default".to_owned(),
            kind: ProviderKind::SubscriptionSources,
        }
    }
}

/// Provider content kind (enumeration type).
#[derive(Clone, Debug, Deserialize, Eq, PartialEq, Serialize)]
#[serde(rename_all = "kebab-case")]
pub enum ProviderKind {
    /// Aggregates every enabled subscription source URL
    /// (`subscriptions.url` plus enabled `subscriptions.sources` entries).
    SubscriptionSources,
    /// Bare proxy-node URIs (`vmess://` …) without an upstream URL.
    InlineNodes(Vec<String>),
}

impl SubscriptionConfig {
    /// Returns every enabled source URL: the legacy `url` (always enabled when
    /// set) followed by the enabled entries of `sources`. This is the full set
    /// `caly sub refresh` fetches and merges.
    pub fn enabled_source_urls(&self) -> Vec<String> {
        let mut out = Vec::new();
        if let Some(url) = &self.url {
            out.push(url.clone());
        }
        out.extend(
            self.sources
                .iter()
                .filter(|source| source.enabled)
                .map(|source| source.url.clone()),
        );
        out
    }

    /// The auto-created enumeration default provider: contains every enabled
    /// subscription source URL — exactly the set `caly sub list` reads.
    /// Returns `None` when no source is configured, so a node-only config
    /// (inline `vmess://`-style content) never fabricates an empty provider.
    pub fn default_provider(&self) -> Option<ProviderConfig> {
        if self.enabled_source_urls().is_empty() {
            return None;
        }
        Some(ProviderConfig {
            name: "default".to_owned(),
            kind: ProviderKind::SubscriptionSources,
        })
    }
}

/// One user-defined rule provider. Mirrors `ProviderConfig` (a named source
/// of proxy content): `RuleProvider` is a named source of rule content,
impl Default for SubscriptionConfig {
    fn default() -> Self {
        Self {
            url: None,
            sources: Vec::new(),
            connect_timeout_ms: 5_000,
            request_timeout_ms: 30_000,
            max_body_mb: 32,
            follow_redirects: false,
            use_environment_proxy: false,
            refresh_interval_minutes: 0,
        }
    }
}
