//! Schema version migration pipeline for Caly configuration.

use serde_norway::Value;

/// Migration outcome and applied steps.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct MigrationOutcome {
    pub initial_version: u32,
    pub target_version: u32,
    pub migrations_applied: usize,
}

/// Validates and migrates raw YAML config value tree to the latest schema version.
pub fn migrate_config_tree(mut root: Value) -> (Value, MigrationOutcome) {
    let mut current_version = root
        .get("schema_version")
        .and_then(Value::as_u64)
        .unwrap_or(1) as u32;

    let initial_version = current_version;
    let mut count = 0;

    // v1 -> v2: Ensure modular structure compatibility
    if current_version == 1 {
        // v1 is canonical current version
        count += 0;
    }

    (
        root,
        MigrationOutcome {
            initial_version,
            target_version: current_version,
            migrations_applied: count,
        },
    )
}
