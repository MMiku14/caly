#![forbid(unsafe_code)]

pub mod catalog;
pub mod eval;
pub mod json;
pub mod loader;
pub mod registry;

pub use catalog::*;
pub use eval::*;
pub use json::*;
pub use loader::*;
pub use registry::*;

pub const REGISTRY_PATH: &str = "capability-registry.json";
pub const COVERAGE_MATRIX_PATH: &str = "coverage-matrix.json";
