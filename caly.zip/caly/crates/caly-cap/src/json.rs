//! A minimal JSON reader/writer for the capability registry artifacts.
//!
//! `ADR-024` makes the capability registry the single source of truth, and `caly-cap` shipped
//! `REGISTRY_PATH` / `COVERAGE_MATRIX_PATH` constants plus `validate_registry_document`. But
//! nothing ever *read* those files: `default_registry_document()` is built in Rust, so the
//! `.json` artifacts were documentation pretending to be data, and could drift silently.
//!
//! This module closes that loop with the workspace's zero-dependency constraint in mind
//! (`docs/history/ONBOARDING_NOTES.md §1.4`): a small recursive-descent JSON reader and a writer that
//! emits exactly the pretty-printed shape the checked-in files use. Together they let a test
//! assert `parse(file) == default_registry_document()`, which makes drift a build failure
//! instead of a review problem.

use crate::loader::{CoverageEntry, CoverageMatrixDocument, RegistryDocument};
use crate::registry::{
    CapabilityDescriptor, CapabilityDomain, CapabilityKey, CapabilityState, Constraint,
    EvidenceRef, FallbackPolicy, SupportLevel,
};

#[derive(Clone, Debug, Eq, PartialEq)]
pub enum JsonValue {
    Null,
    Bool(bool),
    /// Integers only: the registry artifacts carry a `version` number and nothing else.
    /// Keeping this integral is what lets `JsonValue` stay `Eq`, which the round-trip test
    /// needs; a float variant would have to be compared approximately instead.
    Number(u64),
    String(String),
    Array(Vec<JsonValue>),
    Object(Vec<(String, JsonValue)>),
}

impl JsonValue {
    pub fn as_str(&self) -> Option<&str> {
        match self {
            Self::String(value) => Some(value),
            _ => None,
        }
    }

    pub fn as_object(&self) -> Option<&[(String, JsonValue)]> {
        match self {
            Self::Object(entries) => Some(entries),
            _ => None,
        }
    }

    pub fn as_array(&self) -> Option<&[JsonValue]> {
        match self {
            Self::Array(values) => Some(values),
            _ => None,
        }
    }

    pub fn field(&self, name: &str) -> Option<&JsonValue> {
        self.as_object()?
            .iter()
            .find(|(key, _)| key == name)
            .map(|(_, value)| value)
    }

    pub fn string_field(&self, name: &str) -> Option<String> {
        self.field(name)?.as_str().map(|value| value.to_owned())
    }

    pub fn optional_string_field(&self, name: &str) -> Option<String> {
        match self.field(name)? {
            JsonValue::Null => None,
            JsonValue::String(value) => Some(value.clone()),
            _ => None,
        }
    }

    pub fn number_field(&self, name: &str) -> Option<u32> {
        match self.field(name)? {
            JsonValue::Number(value) => u32::try_from(*value).ok(),
            _ => None,
        }
    }

    pub fn array_field(&self, name: &str) -> Vec<JsonValue> {
        self.field(name)
            .and_then(|value| value.as_array())
            .map(|values| values.to_vec())
            .unwrap_or_default()
    }
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct JsonError {
    pub message: String,
    pub offset: usize,
}

impl JsonError {
    fn new(message: impl Into<String>, offset: usize) -> Self {
        Self {
            message: message.into(),
            offset,
        }
    }
}

/// Parse a JSON document. Supports the subset the registry artifacts use: objects, arrays,
/// strings (with basic escapes), numbers, `true` / `false` / `null`.
pub fn parse_json(raw: &str) -> Result<JsonValue, JsonError> {
    let bytes = raw.as_bytes();
    let mut pos = 0usize;

    fn skip_ws(bytes: &[u8], pos: &mut usize) {
        while *pos < bytes.len() && matches!(bytes[*pos], b' ' | b'\t' | b'\n' | b'\r') {
            *pos += 1;
        }
    }

    fn parse_value(bytes: &[u8], pos: &mut usize) -> Result<JsonValue, JsonError> {
        skip_ws(bytes, pos);
        let Some(&first) = bytes.get(*pos) else {
            return Err(JsonError::new("unexpected end of input", *pos));
        };
        match first {
            b'{' => {
                *pos += 1;
                let mut entries = Vec::new();
                loop {
                    skip_ws(bytes, pos);
                    if bytes.get(*pos) == Some(&b'}') {
                        *pos += 1;
                        break;
                    }
                    if !entries.is_empty() {
                        if bytes.get(*pos) != Some(&b',') {
                            return Err(JsonError::new("expected ',' or '}' in object", *pos));
                        }
                        *pos += 1;
                        skip_ws(bytes, pos);
                    }
                    let key = parse_string(bytes, pos)?;
                    skip_ws(bytes, pos);
                    if bytes.get(*pos) != Some(&b':') {
                        return Err(JsonError::new("expected ':' after object key", *pos));
                    }
                    *pos += 1;
                    let value = parse_value(bytes, pos)?;
                    entries.push((key, value));
                }
                Ok(JsonValue::Object(entries))
            }
            b'[' => {
                *pos += 1;
                let mut values = Vec::new();
                loop {
                    skip_ws(bytes, pos);
                    if bytes.get(*pos) == Some(&b']') {
                        *pos += 1;
                        break;
                    }
                    if !values.is_empty() {
                        if bytes.get(*pos) == Some(&b',') {
                            *pos += 1;
                            skip_ws(bytes, pos);
                        } else {
                            return Err(JsonError::new("expected ',' or ']' in array", *pos));
                        }
                    }
                    values.push(parse_value(bytes, pos)?);
                }
                Ok(JsonValue::Array(values))
            }
            b'"' => Ok(JsonValue::String(parse_string(bytes, pos)?)),
            b't' | b'f' | b'n' => {
                for (literal, value) in [
                    ("true", JsonValue::Bool(true)),
                    ("false", JsonValue::Bool(false)),
                    ("null", JsonValue::Null),
                ] {
                    if bytes[*pos..].starts_with(literal.as_bytes()) {
                        *pos += literal.len();
                        return Ok(value);
                    }
                }
                Err(JsonError::new("invalid literal", *pos))
            }
            _ if first.is_ascii_digit() => {
                let start = *pos;
                while *pos < bytes.len()
                    && matches!(bytes[*pos], b'0'..=b'9' | b'-' | b'+' | b'.' | b'e' | b'E')
                {
                    *pos += 1;
                }
                let text = std::str::from_utf8(&bytes[start..*pos])
                    .map_err(|_| JsonError::new("invalid number", start))?;
                text.parse::<u64>().map(JsonValue::Number).map_err(|_| {
                    JsonError::new(
                        format!("only non-negative integers are supported, got {text}"),
                        start,
                    )
                })
            }
            other => Err(JsonError::new(
                format!("unexpected byte {:?}", char::from(other)),
                *pos,
            )),
        }
    }

    fn parse_string(bytes: &[u8], pos: &mut usize) -> Result<String, JsonError> {
        if bytes.get(*pos) != Some(&b'"') {
            return Err(JsonError::new("expected a string", *pos));
        }
        *pos += 1;
        let mut out = String::new();
        let mut chunk = *pos;

        while *pos < bytes.len() {
            match bytes[*pos] {
                b'"' => {
                    copy_chunk(bytes, &mut out, chunk, *pos)?;
                    *pos += 1;
                    return Ok(out);
                }
                b'\\' => {
                    copy_chunk(bytes, &mut out, chunk, *pos)?;
                    *pos += 1;
                    let Some(&escaped) = bytes.get(*pos) else {
                        return Err(JsonError::new("unterminated escape", *pos));
                    };
                    out.push(match escaped {
                        b'n' => '\n',
                        b't' => '\t',
                        b'r' => '\r',
                        b'"' => '"',
                        b'\\' => '\\',
                        b'/' => '/',
                        other => {
                            return Err(JsonError::new(
                                format!("unsupported escape \\{}", char::from(other)),
                                *pos,
                            ))
                        }
                    });
                    *pos += 1;
                    chunk = *pos;
                }
                _ => *pos += 1,
            }
        }
        Err(JsonError::new("unterminated string", chunk))
    }

    fn copy_chunk(bytes: &[u8], out: &mut String, from: usize, to: usize) -> Result<(), JsonError> {
        let text = std::str::from_utf8(&bytes[from..to])
            .map_err(|_| JsonError::new("string bytes are not valid utf-8", from))?;
        out.push_str(text);
        Ok(())
    }

    let value = parse_value(bytes, &mut pos)?;
    skip_ws(bytes, &mut pos);
    if pos != bytes.len() {
        return Err(JsonError::new("trailing content after JSON value", pos));
    }
    Ok(value)
}

// ---------------------------------------------------------------------------
// enum <-> text mappings (the text form is the variant name, as in the checked-in files)
// ---------------------------------------------------------------------------

pub fn domain_to_str(domain: CapabilityDomain) -> &'static str {
    match domain {
        CapabilityDomain::Proxies => "Proxies",
        CapabilityDomain::ProxyGroups => "ProxyGroups",
        CapabilityDomain::Routing => "Routing",
        CapabilityDomain::RuleSets => "RuleSets",
        CapabilityDomain::Dns => "Dns",
        CapabilityDomain::Inbounds => "Inbounds",
        CapabilityDomain::Outbounds => "Outbounds",
        CapabilityDomain::Tun => "Tun",
        CapabilityDomain::SystemProxy => "SystemProxy",
        CapabilityDomain::SystemDns => "SystemDns",
        CapabilityDomain::Runtime => "Runtime",
        CapabilityDomain::Security => "Security",
    }
}

pub fn domain_from_str(value: &str) -> Result<CapabilityDomain, String> {
    Ok(match value {
        "Proxies" => CapabilityDomain::Proxies,
        "ProxyGroups" => CapabilityDomain::ProxyGroups,
        "Routing" => CapabilityDomain::Routing,
        "RuleSets" => CapabilityDomain::RuleSets,
        "Dns" => CapabilityDomain::Dns,
        "Inbounds" => CapabilityDomain::Inbounds,
        "Outbounds" => CapabilityDomain::Outbounds,
        "Tun" => CapabilityDomain::Tun,
        "SystemProxy" => CapabilityDomain::SystemProxy,
        "SystemDns" => CapabilityDomain::SystemDns,
        "Runtime" => CapabilityDomain::Runtime,
        "Security" => CapabilityDomain::Security,
        other => return Err(format!("unknown capability domain {other:?}")),
    })
}

pub fn support_level_to_str(level: SupportLevel) -> &'static str {
    match level {
        SupportLevel::CalyManaged => "CalyManaged",
        SupportLevel::NativeManaged => "NativeManaged",
        SupportLevel::OpaquePreserved => "OpaquePreserved",
    }
}

pub fn support_level_from_str(value: &str) -> Result<SupportLevel, String> {
    Ok(match value {
        "CalyManaged" => SupportLevel::CalyManaged,
        "NativeManaged" => SupportLevel::NativeManaged,
        "OpaquePreserved" => SupportLevel::OpaquePreserved,
        other => return Err(format!("unknown support level {other:?}")),
    })
}

pub fn state_to_str(state: CapabilityState) -> &'static str {
    match state {
        CapabilityState::SupportedExact => "SupportedExact",
        CapabilityState::SupportedNativeOnly => "SupportedNativeOnly",
        CapabilityState::PreservedOpaque => "PreservedOpaque",
        CapabilityState::Experimental => "Experimental",
        CapabilityState::Unsupported => "Unsupported",
        CapabilityState::Unknown => "Unknown",
    }
}

pub fn state_from_str(value: &str) -> Result<CapabilityState, String> {
    Ok(match value {
        "SupportedExact" => CapabilityState::SupportedExact,
        "SupportedNativeOnly" => CapabilityState::SupportedNativeOnly,
        "PreservedOpaque" => CapabilityState::PreservedOpaque,
        "Experimental" => CapabilityState::Experimental,
        "Unsupported" => CapabilityState::Unsupported,
        "Unknown" => CapabilityState::Unknown,
        other => return Err(format!("unknown capability state {other:?}")),
    })
}

pub fn fallback_to_str(policy: FallbackPolicy) -> &'static str {
    match policy {
        FallbackPolicy::PreserveOpaqueSameCore => "PreserveOpaqueSameCore",
        FallbackPolicy::RequireDropFlag => "RequireDropFlag",
        FallbackPolicy::UseNativeOnlyMode => "UseNativeOnlyMode",
        FallbackPolicy::EscalateToRestart => "EscalateToRestart",
        FallbackPolicy::DisableRuntimeFeature => "DisableRuntimeFeature",
    }
}

pub fn fallback_from_str(value: &str) -> Result<FallbackPolicy, String> {
    Ok(match value {
        "PreserveOpaqueSameCore" => FallbackPolicy::PreserveOpaqueSameCore,
        "RequireDropFlag" => FallbackPolicy::RequireDropFlag,
        "UseNativeOnlyMode" => FallbackPolicy::UseNativeOnlyMode,
        "EscalateToRestart" => FallbackPolicy::EscalateToRestart,
        "DisableRuntimeFeature" => FallbackPolicy::DisableRuntimeFeature,
        other => return Err(format!("unknown fallback policy {other:?}")),
    })
}

// ---------------------------------------------------------------------------
// documents
// ---------------------------------------------------------------------------

pub fn registry_from_json(raw: &str) -> Result<RegistryDocument, String> {
    let root =
        parse_json(raw).map_err(|error| format!("{} at offset {}", error.message, error.offset))?;
    let version = root.number_field("version").unwrap_or(0);
    let capabilities = root
        .array_field("capabilities")
        .into_iter()
        .map(descriptor_from_json)
        .collect::<Result<Vec<_>, _>>()?;
    Ok(RegistryDocument {
        version,
        capabilities,
    })
}

fn descriptor_from_json(value: JsonValue) -> Result<CapabilityDescriptor, String> {
    let key = value
        .string_field("key")
        .ok_or_else(|| "capability entry is missing \"key\"".to_owned())?;
    let title = value
        .string_field("title")
        .ok_or_else(|| format!("{key} is missing \"title\""))?;
    let domain = value
        .string_field("domain")
        .ok_or_else(|| format!("{key} is missing \"domain\""))
        .and_then(|raw| domain_from_str(&raw).map_err(|error| format!("{key}: {error}")))?;
    let support_level = value
        .string_field("support_level")
        .ok_or_else(|| format!("{key} is missing \"support_level\""))
        .and_then(|raw| support_level_from_str(&raw).map_err(|error| format!("{key}: {error}")))?;
    let state = value
        .string_field("state")
        .ok_or_else(|| format!("{key} is missing \"state\""))
        .and_then(|raw| state_from_str(&raw).map_err(|error| format!("{key}: {error}")))?;

    let constraints = value
        .array_field("constraints")
        .into_iter()
        .map(|entry| {
            Ok(Constraint {
                field: entry
                    .string_field("field")
                    .ok_or_else(|| format!("{key} constraint is missing \"field\""))?,
                expected: entry
                    .string_field("expected")
                    .ok_or_else(|| format!("{key} constraint is missing \"expected\""))?,
            })
        })
        .collect::<Result<Vec<_>, String>>()?;

    let fallback = match value.field("fallback") {
        None | Some(JsonValue::Null) => None,
        Some(JsonValue::String(raw)) => {
            Some(fallback_from_str(raw).map_err(|error| format!("{key}: {error}"))?)
        }
        Some(_) => return Err(format!("{key} has a non-string fallback")),
    };

    let evidence = value.field("evidence_ref");
    let evidence_ref = EvidenceRef {
        fixture_id: evidence.and_then(|it| it.optional_string_field("fixture_id")),
        golden_test_id: evidence.and_then(|it| it.optional_string_field("golden_test_id")),
        native_validation_test_id: evidence
            .and_then(|it| it.optional_string_field("native_validation_test_id")),
        runtime_test_id: evidence.and_then(|it| it.optional_string_field("runtime_test_id")),
    };

    let notes = value
        .array_field("notes")
        .into_iter()
        .filter_map(|entry| entry.as_str().map(|value| value.to_owned()))
        .collect();

    Ok(CapabilityDescriptor {
        key: CapabilityKey(key),
        title,
        domain,
        support_level,
        state,
        constraints,
        fallback,
        evidence_ref,
        notes,
    })
}

pub fn coverage_matrix_from_json(raw: &str) -> Result<CoverageMatrixDocument, String> {
    let root =
        parse_json(raw).map_err(|error| format!("{} at offset {}", error.message, error.offset))?;
    let version = root.number_field("version").unwrap_or(0);
    let matrix = root
        .array_field("matrix")
        .into_iter()
        .map(entry_from_json)
        .collect::<Result<Vec<_>, _>>()?;
    Ok(CoverageMatrixDocument { version, matrix })
}

fn entry_from_json(value: JsonValue) -> Result<CoverageEntry, String> {
    let key = value
        .string_field("capability_key")
        .ok_or_else(|| "coverage entry is missing \"capability_key\"".to_owned())?;
    Ok(CoverageEntry {
        capability_key: CapabilityKey(key.clone()),
        target_core: value
            .string_field("target_core")
            .ok_or_else(|| format!("{key} is missing \"target_core\""))?,
        version_range: value
            .string_field("version_range")
            .ok_or_else(|| format!("{key} is missing \"version_range\""))?,
        support_level: value
            .string_field("support_level")
            .ok_or_else(|| format!("{key} is missing \"support_level\""))
            .and_then(|raw| {
                support_level_from_str(&raw).map_err(|error| format!("{key}: {error}"))
            })?,
        state: value
            .string_field("state")
            .ok_or_else(|| format!("{key} is missing \"state\""))
            .and_then(|raw| state_from_str(&raw).map_err(|error| format!("{key}: {error}")))?,
        platforms: value
            .array_field("platforms")
            .into_iter()
            .filter_map(|entry| entry.as_str().map(|value| value.to_owned()))
            .collect(),
        evidence: value
            .array_field("evidence")
            .into_iter()
            .filter_map(|entry| entry.as_str().map(|value| value.to_owned()))
            .collect(),
    })
}

/// Emit the registry document as the checked-in pretty-printed JSON shape.
pub fn registry_to_json(document: &RegistryDocument) -> String {
    let mut out = String::new();
    out.push_str("{\n  \"version\": ");
    out.push_str(&document.version.to_string());
    out.push_str(",\n  \"capabilities\": [\n");
    for (index, descriptor) in document.capabilities.iter().enumerate() {
        out.push_str("    {\n");
        push_str_field(&mut out, "key", &descriptor.key.0);
        push_str_field(&mut out, "title", &descriptor.title);
        push_str_field(&mut out, "domain", domain_to_str(descriptor.domain));
        push_str_field(
            &mut out,
            "support_level",
            support_level_to_str(descriptor.support_level),
        );
        push_str_field(&mut out, "state", state_to_str(descriptor.state));
        out.push_str("      \"constraints\": [");
        for (offset, constraint) in descriptor.constraints.iter().enumerate() {
            if offset > 0 {
                out.push(',');
            }
            out.push_str(&format!(
                "{{ \"field\": {}, \"expected\": {} }}",
                quote(&constraint.field),
                quote(&constraint.expected)
            ));
        }
        out.push_str("],\n");
        match descriptor.fallback {
            Some(policy) => push_str_field(&mut out, "fallback", fallback_to_str(policy)),
            None => out.push_str("      \"fallback\": null,\n"),
        }
        out.push_str("      \"evidence_ref\": {\n");
        let mut fields: Vec<(&str, Option<&str>)> = vec![
            ("fixture_id", descriptor.evidence_ref.fixture_id.as_deref()),
            (
                "golden_test_id",
                descriptor.evidence_ref.golden_test_id.as_deref(),
            ),
            (
                "native_validation_test_id",
                descriptor.evidence_ref.native_validation_test_id.as_deref(),
            ),
            (
                "runtime_test_id",
                descriptor.evidence_ref.runtime_test_id.as_deref(),
            ),
        ];
        fields.retain(|(_name, value)| value.is_some());
        for (offset, (name, value)) in fields.iter().enumerate() {
            if offset > 0 {
                out.push_str(",\n");
            }
            out.push_str(&format!(
                "        \"{name}\": {}",
                quote(value.unwrap_or_default())
            ));
        }
        if !fields.is_empty() {
            out.push('\n');
        }
        out.push_str("      },\n");
        out.push_str("      \"notes\": [");
        for (offset, note) in descriptor.notes.iter().enumerate() {
            if offset > 0 {
                out.push(',');
            }
            out.push_str(&format!(" {}", quote(note)));
        }
        out.push_str("]\n");
        out.push_str(if index + 1 == document.capabilities.len() {
            "    }\n"
        } else {
            "    },\n"
        });
    }
    out.push_str("  ]\n}\n");
    out
}

pub fn coverage_matrix_to_json(document: &CoverageMatrixDocument) -> String {
    let mut out = String::new();
    out.push_str("{\n  \"version\": ");
    out.push_str(&document.version.to_string());
    out.push_str(",\n  \"matrix\": [\n");
    for (index, entry) in document.matrix.iter().enumerate() {
        out.push_str("    {\n");
        push_str_field(&mut out, "capability_key", &entry.capability_key.0);
        push_str_field(&mut out, "target_core", &entry.target_core);
        push_str_field(&mut out, "version_range", &entry.version_range);
        push_str_field(
            &mut out,
            "support_level",
            support_level_to_str(entry.support_level),
        );
        push_str_field(&mut out, "state", state_to_str(entry.state));
        out.push_str("      \"platforms\": [");
        push_string_list(&mut out, &entry.platforms);
        out.push_str("],\n");
        out.push_str("      \"evidence\": [");
        push_string_list(&mut out, &entry.evidence);
        out.push_str("]\n");
        out.push_str(if index + 1 == document.matrix.len() {
            "    }\n"
        } else {
            "    },\n"
        });
    }
    out.push_str("  ]\n}\n");
    out
}

fn push_string_list(out: &mut String, values: &[String]) {
    for (offset, value) in values.iter().enumerate() {
        if offset > 0 {
            out.push(',');
        }
        out.push_str(&format!(" {}", quote(value)));
    }
}

fn push_str_field(out: &mut String, name: &str, value: &str) {
    out.push_str(&format!("      \"{name}\": {},\n", quote(value)));
}

fn escape_json(value: &str) -> String {
    let mut out = String::with_capacity(value.len());
    for ch in value.chars() {
        match ch {
            '"' => out.push_str("\\\""),
            '\\' => out.push_str("\\\\"),
            '\n' => out.push_str("\\n"),
            '\t' => out.push_str("\\t"),
            '\r' => out.push_str("\\r"),
            other => out.push(other),
        }
    }
    out
}

fn quote(value: &str) -> String {
    format!("\"{}\"", escape_json(value))
}
