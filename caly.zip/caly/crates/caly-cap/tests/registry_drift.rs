//! Capability registry drift gate (`ADR-024`).
//!
//! `ADR-024` names the capability registry the single source of truth, and `caly-cap` shipped
//! `REGISTRY_PATH` / `COVERAGE_MATRIX_PATH` plus a `validate_registry_document` helper. But no
//! code ever read those files, so `capability-registry.json` and `coverage-matrix.json` could
//! say anything at all without a single test noticing. These assertions make the checked-in
//! artifacts real data: the JSON must parse to exactly the document the pipeline evaluates.
//!
//! To re-sync the files after changing `catalog.rs`:
//!
//! ```text
//! CALY_REGENERATE_CAPABILITY_ARTIFACTS=1 cargo test -p caly-cap
//! ```

use std::path::Path;

use caly_cap::{
    coverage_matrix_from_json, coverage_matrix_to_json, default_coverage_matrix_document,
    default_registry_document, parse_json, registry_from_json, registry_to_json, JsonValue,
    COVERAGE_MATRIX_PATH, REGISTRY_PATH,
};

fn artifact_path(name: &str) -> String {
    Path::new(env!("CARGO_MANIFEST_DIR"))
        .join(name)
        .to_string_lossy()
        .into_owned()
}

fn read(name: &str) -> String {
    let path = artifact_path(name);
    std::fs::read_to_string(&path).unwrap_or_else(|error| panic!("cannot read {path}: {error}"))
}

#[test]
fn checked_in_registry_json_is_exactly_the_built_in_document() {
    let from_file = registry_from_json(&read(REGISTRY_PATH)).expect("registry json must parse");
    let built_in = default_registry_document();

    assert_eq!(
        from_file.version, built_in.version,
        "registry version drifted"
    );
    let file_keys: Vec<String> = from_file
        .capabilities
        .iter()
        .map(|descriptor| descriptor.key.0.clone())
        .collect();
    let code_keys: Vec<String> = built_in
        .capabilities
        .iter()
        .map(|descriptor| descriptor.key.0.clone())
        .collect();
    assert_eq!(
        file_keys, code_keys,
        "the registry file and catalog.rs advertise different capability keys"
    );
    assert_eq!(
        from_file, *built_in,
        "regenerate with CALY_REGENERATE_CAPABILITY_ARTIFACTS=1"
    );
}

#[test]
fn checked_in_coverage_matrix_json_is_exactly_the_built_in_document() {
    let from_file =
        coverage_matrix_from_json(&read(COVERAGE_MATRIX_PATH)).expect("coverage json must parse");
    let built_in = default_coverage_matrix_document();
    assert_eq!(
        from_file, *built_in,
        "coverage matrix drifted from catalog.rs"
    );
}

#[test]
fn writer_and_reader_round_trip_the_documents() {
    let registry = default_registry_document();
    let emitted = registry_to_json(registry);
    assert_eq!(
        registry_from_json(&emitted).expect("emitted registry must parse"),
        *registry,
        "the writer emitted something the reader cannot reproduce"
    );

    let coverage = default_coverage_matrix_document();
    let emitted_coverage = coverage_matrix_to_json(coverage);
    assert_eq!(
        coverage_matrix_from_json(&emitted_coverage).expect("emitted coverage must parse"),
        *coverage
    );

    // The checked-in files are in canonical writer form, so `git diff` on them stays reviewable.
    assert_eq!(
        emitted,
        read(REGISTRY_PATH),
        "capability-registry.json is not in canonical form; regenerate it"
    );
    assert_eq!(
        emitted_coverage,
        read(COVERAGE_MATRIX_PATH),
        "coverage-matrix.json is not in canonical form; regenerate it"
    );
}

#[test]
fn every_coverage_row_references_a_registered_capability() {
    let registry = default_registry_document();
    let coverage = default_coverage_matrix_document();
    let missing: Vec<String> = coverage
        .matrix
        .iter()
        .filter(|entry| {
            !registry
                .capabilities
                .iter()
                .any(|descriptor| descriptor.key == entry.capability_key)
        })
        .map(|entry| format!("{} -> {}", entry.capability_key.0, entry.target_core))
        .collect();
    assert!(
        missing.is_empty(),
        "coverage rows must point at registered keys, or strict-mode evaluation has no \
         definition to consult: {missing:?}"
    );
}

#[test]
fn parser_rejects_malformed_and_unknown_content() {
    assert!(
        parse_json("{\"version\": }").is_err(),
        "missing value must fail"
    );
    assert!(
        parse_json("{\"a\": \"unterminated").is_err(),
        "unterminated string must fail"
    );
    assert!(
        parse_json("{} extra").is_err(),
        "trailing content must fail"
    );
    assert!(
        parse_json("{\"a\": [1,2}").is_err(),
        "bad array separator must fail"
    );
    assert!(
        parse_json("{\"a\": 1.5").is_err(),
        "non-integer numbers are out of scope"
    );
    assert!(
        registry_from_json("{ \"version\": 1, \"capabilities\": [] }")
            .map(|document| document.capabilities.is_empty())
            .unwrap_or(false),
        "an empty capability list must still parse"
    );

    let unknown_enum = "{ \"version\": 1, \"capabilities\": [ { \"key\": \"x\", \"title\": \"t\", \
                         \"domain\": \"Nope\", \"support_level\": \"CalyManaged\", \
                         \"state\": \"SupportedExact\", \"constraints\": [], \"fallback\": null } ] }";
    let error = registry_from_json(unknown_enum).expect_err("unknown domain must be rejected");
    assert!(error.contains("unknown capability domain"), "{error}");

    let missing_key = "{ \"version\": 1, \"capabilities\": [ { \"title\": \"t\" } ] }";
    let error = registry_from_json(missing_key).expect_err("missing key must be rejected");
    assert!(
        error.contains("missing") && error.contains("key"),
        "{error}"
    );
}

#[test]
fn parser_handles_the_field_subset_a_reader_needs() {
    let value = parse_json(
        r#"{
             "version": 3,
             "flag": true,
             "off": false,
             "nothing": null,
             "list": ["a", "b\"c", "d\ne"],
             "nested": { "inner": { "deep": "yes" } }
           }"#,
    )
    .expect("document must parse");

    assert_eq!(value.number_field("version"), Some(3));
    assert_eq!(
        value.field("flag"),
        Some(&JsonValue::Bool(true)),
        "booleans must be preserved"
    );
    assert_eq!(value.field("nothing"), Some(&JsonValue::Null));
    assert_eq!(value.array_field("list").len(), 3);
    assert_eq!(
        value
            .array_field("list")
            .get(1)
            .and_then(|it| it.as_str())
            .map(str::to_owned),
        Some("b\"c".to_owned()),
        "escapes must be decoded"
    );
    assert_eq!(
        value
            .field("nested")
            .and_then(|it| it.field("inner"))
            .and_then(|it| it.string_field("deep")),
        Some("yes".to_owned())
    );
}

/// Maintenance entry point: rewrites the two artifacts from `catalog.rs`.
///
/// Off by default. A test that mutates the source tree on every run would make the suite
/// non-repeatable, so the write only happens when a maintainer asks for it.
#[test]
fn regenerate_artifacts_on_request() {
    if std::env::var("CALY_REGENERATE_CAPABILITY_ARTIFACTS").is_err() {
        return;
    }
    std::fs::write(
        artifact_path(REGISTRY_PATH),
        registry_to_json(default_registry_document()),
    )
    .expect("registry artifact must be writable");
    std::fs::write(
        artifact_path(COVERAGE_MATRIX_PATH),
        coverage_matrix_to_json(default_coverage_matrix_document()),
    )
    .expect("coverage artifact must be writable");
}

/// Round 70 (`IMPLEMENTATION_STATUS §8.4` "纯核心缓存/记忆化"): the built-in documents
/// are constants, so they are constructed once per process. Pointer equality between two
/// calls is the judge: a regression to per-call construction breaks it; the drift tests
/// above keep comparing against the same value either way, so this is the only test that
/// notices the difference.
#[test]
fn the_builtin_documents_are_constructed_once_per_process() {
    let first = default_registry_document();
    let second = default_registry_document();
    assert!(
        std::ptr::eq(first, second),
        "the registry document was constructed more than once per process"
    );
    let first_coverage = default_coverage_matrix_document();
    let second_coverage = default_coverage_matrix_document();
    assert!(
        std::ptr::eq(first_coverage, second_coverage),
        "the coverage document was constructed more than once per process"
    );
}
