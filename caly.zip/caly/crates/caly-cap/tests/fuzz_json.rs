//! Deterministic structure-aware fuzz for the capability registry's hand-rolled JSON
//! reader (`caly-cap::json::parse_json`) — the parser that faces FOREIGN bytes: the
//! checked-in registry artifacts today, and any file a future loader is pointed at.
//!
//! A hand-rolled recursive-descent parser is exactly the layer where a "cannot happen"
//! slice index or an unterminated-escape loop hides from example-based tests. This judge
//! feeds it a seeded, reproducible stream of mutations over a VALID corpus (truncation,
//! bit flips, delimiter injection, splices, digit inflation, range deletion — and the
//! empty string, the input every guard forgets) and demands exactly two things:
//!
//! * **never a panic** — every input is answered, `catch_unwind` is the referee;
//! * **every refusal is by name** — an `Err` carries a non-empty message an operator
//!   could act on (`JsonError { message, offset }`), never a bare or empty rejection.
//!
//! No dependency, no nightly, no corpus on disk: the PRNG is a local xorshift, the seed
//! is a constant, and the budget is fixed so the normal gate stays fast. Raise the
//! constant for a longer session; determinism is what makes a fuzz finding reproducible.

use caly_cap::json::{parse_json, JsonValue};

struct Rng(u64);

impl Rng {
    fn next(&mut self) -> u64 {
        let mut x = self.0;
        x ^= x >> 12;
        x ^= x << 25;
        x ^= x >> 27;
        self.0 = x;
        x.wrapping_mul(0x2545_F491_4F6C_DD1D)
    }

    fn below(&mut self, n: usize) -> usize {
        (self.next() % n.max(1) as u64) as usize
    }
}

const SEED: u64 = 0xC0FF_EE12_8F7A_5E11;

const DELIMITERS: &[u8] = b"|=&\":\\\n\r\t \x7f\x00";

/// One deterministic mutation of a corpus entry. Every operator is byte-level: the caller
/// decides how to re-enter the `&str` world (lossy for the strict-text parsers, so the
/// parser still sees hostile-but-valid-UTF-8 input).
fn mutate(rng: &mut Rng, corpus: &[u8]) -> Vec<u8> {
    let mut bytes = corpus.to_vec();
    let len = bytes.len();
    if len == 0 {
        // The empty corpus entry can only grow: one byte of hostility is the whole
        // space it has.
        return vec![DELIMITERS[rng.below(DELIMITERS.len())]];
    }
    match rng.below(7) {
        0 => bytes.truncate(rng.below(len + 1)),
        1 => {
            let at = rng.below(len);
            bytes[at] ^= 1 << rng.below(8);
        }
        2 => {
            let at = rng.below(len + 1);
            bytes.insert(at, DELIMITERS[rng.below(DELIMITERS.len())]);
        }
        3 => {
            let a = rng.below(len);
            let b = rng.below(len);
            bytes.swap(a, b);
        }
        4 => {
            // duplicate a slice back-to-back (repetition stresses "did the parser advance")
            let start = rng.below(len);
            let end = start + rng.below(len - start + 1);
            let chunk = bytes[start..end].to_vec();
            bytes.extend_from_slice(&chunk);
        }
        5 => {
            // digit inflation: a random ASCII digit lands somewhere (length fields, numbers)
            let at = rng.below(len + 1);
            bytes.insert(at, b'0' + (rng.below(10) as u8));
        }
        6 => {
            // delete a range
            let start = rng.below(len);
            let end = start + rng.below(len - start + 1);
            bytes.drain(start..end);
        }
        _ => unreachable!(),
    }
    bytes
}

/// The valid corpus: every shape the registry artifacts use, plus the edges a mutation
/// deserves to start from (unicode labels, escapes, nesting, empty containers).
fn corpus() -> Vec<String> {
    vec![
        String::new(),
        "{\"version\":1}".to_owned(),
        "{\"a\":true,\"b\":false,\"c\":null}".to_owned(),
        "[1,2,3]".to_owned(),
        "{\"nested\":{\"deep\":[{\"k\":\"v\\\"\\\\\\n\"}]}}".to_owned(),
        "{\"label\":\"节点 🛡 一\",\"note\":\"\"}".to_owned(),
        "{}".to_owned(),
        "[]".to_owned(),
        "{\"n\":18446744073709551615}".to_owned(),
        "   {\"spaced\"\t:\r\n[  ] }  ".to_owned(),
        "\"just a string\"".to_owned(),
        "42".to_owned(),
    ]
}

/// Refuse-by-name helper: an `Err` without a message is a refusal an operator cannot act
/// on — the project's by-name doctrine applied to the fuzz oracle.
fn named(message: &str) {
    assert!(
        !message.trim().is_empty(),
        "a refusal must say something by name"
    );
}

#[test]
fn the_valid_corpus_parses_and_the_values_survive() {
    // The green side of the fuzz: the corpus itself must parse (and a few facts must hold),
    // so the fuzz below cannot vacuously pass on an always-refusing parser.
    let value = parse_json(&corpus()[1]).expect("version document parses");
    assert_eq!(
        value.field("version"),
        Some(&JsonValue::Number(1)),
        "the registry's own version shape"
    );
    let nested = parse_json(&corpus()[4]).expect("nested document parses");
    assert!(nested.field("nested").is_some(), "nesting is real");
    assert!(
        parse_json("").is_err(),
        "empty input is a named refusal, not a panic or a value"
    );
}

#[test]
fn mutated_documents_never_panic_and_refuse_by_name() {
    let corpus = corpus();
    let mut rng = Rng(SEED);
    let budget = 4000;
    let mut accepted = 0usize;
    let mut refused = 0usize;
    for step in 0..budget {
        let base = &corpus[rng.below(corpus.len())];
        let mutated_bytes = if step % 8 == 0 {
            base.as_bytes().to_vec()
        } else {
            mutate(&mut rng, base.as_bytes())
        };
        // The parser's contract is `&str`: byte mutations that broke UTF-8 come back as
        // lossy text — still hostile, still valid to hand over.
        let input = String::from_utf8_lossy(&mutated_bytes).into_owned();
        let outcome = std::panic::catch_unwind(std::panic::AssertUnwindSafe(|| parse_json(&input)));
        let Ok(result) = outcome else {
            panic!("parse_json panicked on input {input:?} (seeded step {step})");
        };
        match result {
            Ok(_) => accepted += 1,
            Err(error) => {
                refused += 1;
                named(&error.message);
                assert!(
                    error.offset <= input.len(),
                    "the error's offset points inside the input it is complaining about"
                );
            }
        }
    }
    assert!(
        accepted > 0 && refused > 0,
        "the fuzz must exercise both sides, not one (accepted={accepted}, refused={refused})"
    );
}
