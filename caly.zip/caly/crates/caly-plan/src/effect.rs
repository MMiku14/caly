#[derive(Clone, Debug, Eq, PartialEq, Ord, PartialOrd, Hash)]
pub struct PlanId(pub String);

#[derive(Clone, Debug, Eq, PartialEq, Ord, PartialOrd, Hash)]
pub struct InstanceId(pub String);

#[derive(Clone, Debug, Eq, PartialEq, Ord, PartialOrd, Hash)]
pub struct NetTxnId(pub String);

#[derive(Clone, Debug, Eq, PartialEq, Ord, PartialOrd, Hash)]
pub struct SnapshotId(pub String);

#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub enum Durability {
    D0,
    D1,
    D2,
    D3,
}

#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub enum FileMode {
    ReadOnlyArtifact,
    MutableCopy,
    Executable,
}

#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub enum DeployImpact {
    Noop,
    RuntimePatch,
    Reload,
    Restart,
    RebuildAndRestart,
    NetworkChange,
}

#[derive(Clone, Debug, Default, Eq, PartialEq)]
pub struct PrivilegeSet {
    pub needs_admin: bool,
    pub needs_network_control: bool,
    pub needs_process_control: bool,
    pub needs_secret_access: bool,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct BlobRef {
    pub digest: String,
    pub size_hint: Option<u64>,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub enum DbOp {
    Put {
        table: String,
        key: String,
        value: String,
    },
    Delete {
        table: String,
        key: String,
    },
}

#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub enum CoreKind {
    Mihomo,
    SingBox,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct CoreSpec {
    pub kind: CoreKind,
    pub binary_digest: String,
    pub config_digest: String,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub enum CoreCall {
    Status,
    Reload,
    SelectProxy { group_id: String, node_id: String },
    CloseConnection { connection_id: String },
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct NetworkPlan {
    pub summary: String,
    pub requires_privilege: bool,
}

#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub enum ProbeKind {
    ApiReady,
    ConfigIdentity,
    InboundListening,
    DirectConnectivity,
    ProxyConnectivity,
    /// Round 69 (`IMPLEMENTATION_STATUS §8.4` "RuntimeDriver identity/telemetry"): the
    /// controller answers 200 — but the plan should also know **what** answered. The real
    /// backend reads `GET /version` and its evidence carries the core's self-reported
    /// version next to the kind the plan spawned (`probe.core-identity kind=… version=…`).
    /// A body that cannot be read as a version is a failure, not a silent skeleton.
    CoreIdentity,
    /// Round 69: the runtime's own counters, one-shot. `GET /connections` on both cores
    /// carries cumulative `uploadTotal`/`downloadTotal` (mihomo's `/traffic` also does, but
    /// sing-box's does not — `/connections` is the one surface both cores agree on). The
    /// evidence is `probe.telemetry-traffic upload_total=… download_total=…`. A sample that
    /// cannot be parsed is a failure; the counters are the core's, not the daemon's.
    TelemetryTraffic,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct ProbeSpec {
    pub kind: ProbeKind,
    pub target: Option<String>,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub enum EffectStep {
    WriteObject {
        digest: String,
        source: BlobRef,
        durability: Durability,
    },
    MaterializeArtifact {
        digest: String,
        at: String,
        mode: FileMode,
    },
    DbTxn {
        ops: Vec<DbOp>,
    },
    SpawnCore {
        spec: CoreSpec,
    },
    StopCore {
        instance: InstanceId,
        grace_ms: u64,
    },
    CoreApiCall {
        instance: InstanceId,
        call: CoreCall,
    },
    NetApply {
        plan: NetworkPlan,
    },
    NetRevert {
        txn_id: NetTxnId,
    },
    Probe {
        probe: ProbeSpec,
        deadline_ms: u64,
    },
    MarkSnapshot {
        snapshot_id: SnapshotId,
    },
    CommitRevision {
        revision: u64,
    },
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct EffectPlan {
    pub id: PlanId,
    pub steps: Vec<EffectStep>,
    pub compensations: Vec<EffectStep>,
    pub requires: PrivilegeSet,
    pub impact: DeployImpact,
}
