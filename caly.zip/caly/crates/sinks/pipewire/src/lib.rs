//! **PipeWire** output backend - the primary audio backend of Caly.
#![warn(unsafe_code)]
#![warn(missing_docs, rust_2018_idioms)]

use std::sync::{Arc, Condvar, Mutex};
use std::time::{Duration, Instant};
use pipewire as pw;
use pipewire::properties::properties;
use pipewire::spa;
use pipewire::spa::pod::Pod;
use caly_core::backend::{
    AudioBackend, BackendError, BackendFactory, BackendInfo, BackendResult, OutputConfig,
    SinkReader, StreamParams, StreamState,
};

const INFO: BackendInfo = BackendInfo {
    id: "pipewire",
    name: "PipeWire",
    description: "Modern Linux audio server (default on most distros)",
    priority: 100,
    resource: "PipeWire",
};

const SPA_POSITIONS: [u32; 32] = [
    1, 2, 3, 4, 9, 10, 7, 8, 11, 5, 6,
    12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32,
];

const SPA_CHANNEL_MONO: u32 = 100;
const CONNECT_TIMEOUT: Duration = Duration::from_secs(4);

/// Factory for [`PipewireSink`].
pub struct PipewireFactory;

impl BackendFactory for PipewireFactory {
    fn info(&self) -> &BackendInfo {
        &INFO
    }
    fn create(&self, config: &OutputConfig) -> Result<Box<dyn AudioBackend>, BackendError> {
        Ok(Box::new(PipewireSink {
            device: config.device.clone(),
            session: None,
            stream: None,
        }))
    }
}

#[derive(Default, Clone)]
enum Conn {
    #[default]
    Unknown,
    Ready,
    Failed(String),
}

#[derive(Default)]
struct ConnState {
    flag: Mutex<Conn>,
    cv: Condvar,
}

impl ConnState {
    fn set(&self, c: Conn) {
        *self.flag.lock().unwrap() = c;
        self.cv.notify_all();
    }
    fn get(&self) -> Conn {
        self.flag.lock().unwrap().clone()
    }
}

struct UData {
    reader: SinkReader,
    channels: usize,
    conn: Arc<ConnState>,
}

struct PwSession {
    thread_loop: Option<pw::thread_loop::ThreadLoop>,
    context: Option<pw::context::Context>,
    core: Option<pw::core::Core>,
}

impl PwSession {
    fn teardown(&mut self) {
        let Some(thread_loop) = self.thread_loop.take() else {
            return;
        };
        {
            let _guard = thread_loop.lock();
            drop(self.core.take());
            drop(self.context.take());
            drop(_guard);
        }
        thread_loop.stop();
        drop(thread_loop);
    }
}

impl Drop for PwSession {
    fn drop(&mut self) {
        self.teardown();
    }
}

struct PwStream {
    stream: pw::stream::Stream,
    listener: pw::stream::StreamListener<UData>,
}

/// The PipeWire output backend instance.
pub struct PipewireSink {
    device: Option<String>,
    session: Option<PwSession>,
    stream: Option<PwStream>,
}

impl PipewireSink {
    #[allow(unsafe_code)]
    fn ensure_session(&mut self, params: &StreamParams) -> Result<(), BackendError> {
        if self.session.is_some() {
            return Ok(());
        }
        let thread_loop = unsafe { pw::thread_loop::ThreadLoop::new(Some("caly-pw"), None) }
            .map_err(|e| BackendError::Connect(format!("thread loop: {e}")))?;
        let (context, core) = {
            let _guard = thread_loop.lock();
            let context = pw::context::Context::new(&thread_loop)
                .map_err(|e| BackendError::Connect(format!("context: {e}")))?;
            let core = context
                .connect(None)
                .map_err(|e| BackendError::Connect(format!("core: {e}")))?;
            (context, core)
        };
        thread_loop.start();
        log::debug!(
            "pipewire: session ready ({} Hz / {} ch)",
            params.sample_rate,
            params.channels.get()
        );
        self.session = Some(PwSession {
            thread_loop: Some(thread_loop),
            context: Some(context),
            core: Some(core),
        });
        Ok(())
    }

    fn open_stream(
        &self,
        params: &StreamParams,
        reader: SinkReader,
        conn: &Arc<ConnState>,
    ) -> Result<PwStream, BackendError> {
        let session = self.session.as_ref().expect("session ensured");
        let _guard = session.thread_loop.as_ref().unwrap().lock();
        let mut props = properties! {
            *pw::keys::MEDIA_TYPE => "Audio",
            *pw::keys::MEDIA_CATEGORY => "Playback",
            *pw::keys::MEDIA_ROLE => "Music",
            *pw::keys::APP_NAME => "Caly",
            *pw::keys::NODE_NAME => "caly-output",
        };
        if let Some(dev) = &self.device {
            props.insert(*pw::keys::TARGET_OBJECT, dev.as_str());
        }
        let stream = pw::stream::Stream::new(session.core.as_ref().unwrap(), "caly", props)
            .map_err(|e| BackendError::Connect(format!("stream: {e}")))?;
        let udata = UData {
            reader,
            channels: params.channels.get() as usize,
            conn: conn.clone(),
        };
        let listener = stream
            .add_local_listener_with_user_data(udata)
            .state_changed(|_, udata, _old, new| match new {
                pw::stream::StreamState::Paused | pw::stream::StreamState::Streaming => {
                    udata.conn.set(Conn::Ready);
                }
                pw::stream::StreamState::Error(msg) => {
                    udata.conn.set(Conn::Failed(msg.clone()));
                }
                _ => {}
            })
            .process(process_audio)
            .register()
            .map_err(|e| BackendError::Connect(format!("listener: {e}")))?;

        let mut info = spa::param::audio::AudioInfoRaw::new();
        info.set_format(spa::param::audio::AudioFormat::F32LE);
        info.set_rate(params.sample_rate);
        info.set_channels(params.channels.get() as u32);
        let mut pos = [0u32; 64];
        if params.channels.get() == 1 {
            pos[0] = SPA_CHANNEL_MONO;
        } else {
            let ch_count = params.channels.get() as usize;
            for (i, p) in pos[..ch_count].iter_mut().enumerate() {
                *p = SPA_POSITIONS.get(i).copied().unwrap_or(0);
            }
        }
        info.set_position(pos);
        let values: Vec<u8> = spa::pod::serialize::PodSerializer::serialize(
            std::io::Cursor::new(Vec::new()),
            &spa::pod::Value::Object(spa::pod::Object {
                type_: spa_sys::SPA_TYPE_OBJECT_Format,
                id: spa_sys::SPA_PARAM_EnumFormat,
                properties: info.into(),
            }),
        )
        .map_err(|e| BackendError::Stream(format!("serialize: {e}")))?
        .0
        .into_inner();
        let pod = Pod::from_bytes(&values)
            .ok_or_else(|| BackendError::Stream("pod parse failed".into()))?;
        let mut params_refs = [pod];
        stream
            .connect(
                spa::utils::Direction::Output,
                None,
                pw::stream::StreamFlags::AUTOCONNECT
                    | pw::stream::StreamFlags::MAP_BUFFERS
                    | pw::stream::StreamFlags::RT_PROCESS,
                &mut params_refs,
            )
            .map_err(|e| BackendError::Connect(format!("connect: {e}")))?;
        Ok(PwStream { stream, listener })
    }

    fn destroy_stream(&mut self) {
        let Some(session) = self.session.as_ref() else {
            self.stream = None;
            return;
        };
        let Some(st) = self.stream.take() else {
            return;
        };
        let _guard = session.thread_loop.as_ref().unwrap().lock();
        let _ = st.stream.disconnect();
        drop(st.listener);
        drop(st.stream);
        drop(_guard);
    }
}

impl AudioBackend for PipewireSink {
    fn info(&self) -> &BackendInfo {
        &INFO
    }
    fn start(&mut self, params: &StreamParams, reader: SinkReader) -> BackendResult<()> {
        self.destroy_stream();
        self.ensure_session(params)?;
        let conn = Arc::new(ConnState::default());
        let stream = self.open_stream(params, reader, &conn)?;
        let deadline = Instant::now() + CONNECT_TIMEOUT;
        loop {
            match conn.get() {
                Conn::Ready => break,
                Conn::Failed(e) => {
                    self.destroy_stream();
                    return Err(BackendError::Connect(e));
                }
                Conn::Unknown => {}
            }
            if Instant::now() >= deadline {
                self.destroy_stream();
                return Err(BackendError::Connect(
                    "timeout waiting for stream negotiation".into(),
                ));
            }
            std::thread::sleep(Duration::from_millis(5));
        }
        self.stream = Some(stream);
        log::debug!("pipewire: stream active");
        Ok(())
    }
    fn pause(&mut self) -> BackendResult<()> {
        Ok(())
    }
    fn resume(&mut self) -> BackendResult<()> {
        Ok(())
    }
    fn stop(&mut self) -> BackendResult<()> {
        self.destroy_stream();
        Ok(())
    }
}

impl Drop for PipewireSink {
    fn drop(&mut self) {
        self.destroy_stream();
        self.session = None;
    }
}

fn process_audio(stream: &pw::stream::StreamRef, udata: &mut UData) {
    let state = udata.reader.shared().state();
    let Some(mut buffer) = stream.dequeue_buffer() else {
        return;
    };
    let Some(data) = buffer.datas_mut().first_mut() else {
        return;
    };
    let Some(bytes) = data.data() else {
        return;
    };
    let ch = udata.channels;
    let stride = ch * 4;
    if stride == 0 || bytes.len() < stride {
        return;
    }
    let buffer_len = bytes.len();
    match bytemuck::try_cast_slice_mut::<u8, f32>(bytes) {
        Ok(f32s) => {
            match state {
                StreamState::Playing | StreamState::Draining => {
                    let frames = udata.reader.read(f32s);
                    if frames > 0 {
                        udata.reader.note_reported(frames as u64);
                    } else if state == StreamState::Draining {
                        udata.reader.note_finished();
                    } else {
                        udata.reader.note_underrun();
                    }
                    f32s[frames * ch..].fill(0.0);
                }
                _ => {
                    f32s.fill(0.0);
                }
            }
        }
        Err(_) => {}
    }
    let chunk = data.chunk_mut();
    *chunk.offset_mut() = 0;
    *chunk.stride_mut() = stride as i32;
    *chunk.size_mut() = (buffer_len / stride * stride) as u32;
}
