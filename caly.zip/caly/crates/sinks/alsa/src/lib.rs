//! **ALSA** output backend.
#![forbid(unsafe_code)]
#![warn(missing_docs, rust_2018_idioms)]

use std::sync::atomic::{AtomicBool, Ordering};
use std::sync::Arc;
use std::thread;
use alsa::pcm::{Access, Format, Frames, HwParams, PCM};
use alsa::{Direction, ValueOr};
use caly_core::backend::{
    AudioBackend, BackendError, BackendFactory, BackendInfo, BackendResult, OutputConfig,
    SinkReader, StreamParams, StreamState,
};

const INFO: BackendInfo = BackendInfo {
    id: "alsa",
    name: "ALSA",
    description: "Direct ALSA access (fallback when no sound server runs)",
    priority: 40,
    resource: "ALSA (default or hw:)",
};

/// Factory for [`AlsaSink`].
pub struct AlsaFactory;

impl BackendFactory for AlsaFactory {
    fn info(&self) -> &BackendInfo {
        &INFO
    }
    fn create(&self, config: &OutputConfig) -> Result<Box<dyn AudioBackend>, BackendError> {
        Ok(Box::new(AlsaSink {
            device: config
                .device
                .clone()
                .unwrap_or_else(|| "default".to_string()),
            thread: None,
            stop_flag: None,
        }))
    }
}

/// A single ALSA output session.
pub struct AlsaSink {
    device: String,
    thread: Option<thread::JoinHandle<()>>,
    stop_flag: Option<Arc<AtomicBool>>,
}

impl AlsaSink {
    fn spawn(
        &mut self,
        params: &StreamParams,
        mut reader: SinkReader,
        pcm: PCM,
    ) -> BackendResult<()> {
        let stop = Arc::new(AtomicBool::new(false));
        let stop2 = stop.clone();
        let ch = params.channels.get() as usize;
        let quantum = 1024usize;
        let handle = thread::Builder::new()
            .name("caly-sink-alsa".into())
            .spawn(move || {
                let io = pcm.io_f32();
                let silence = vec![0.0f32; quantum * ch];
                let mut scratch = vec![0.0f32; quantum * ch];
                let mut device_paused = false;
                while !stop2.load(Ordering::Acquire) {
                    match reader.shared().state() {
                        StreamState::Stopped | StreamState::Stopping => break,
                        StreamState::Playing | StreamState::Draining => {
                            if device_paused {
                                let _ = pcm.pause(false);
                                device_paused = false;
                            }
                            let n = reader.read(&mut scratch);
                            if n > 0 {
                                reader.note_reported(n as u64);
                            } else if reader.shared().state() == StreamState::Draining {
                                reader.note_finished();
                            } else {
                                reader.note_underrun();
                            }
                            let data = if n > 0 {
                                &scratch[..n * ch]
                            } else {
                                &silence[..]
                            };
                            match io.writei(data) {
                                Ok(_f) => {}
                                Err(_) => {
                                    log::debug!("alsa: xrun, recovering");
                                    let _ = pcm.prepare();
                                }
                            }
                        }
                        StreamState::Paused => {
                            if !device_paused {
                                let _ = pcm.pause(true);
                                device_paused = true;
                            }
                            thread::sleep(std::time::Duration::from_millis(50));
                        }
                    }
                }
                let _ = pcm.pause(false);
                let _ = pcm.drain();
            })
            .map_err(|e| BackendError::State(format!("spawn: {e}")))?;
        self.thread = Some(handle);
        self.stop_flag = Some(stop);
        Ok(())
    }
}

fn configure_pcm(device: &str, rate: u32, ch: u8, quantum: Frames) -> BackendResult<PCM> {
    let pcm = PCM::new(device, Direction::Playback, false)
        .map_err(|e| BackendError::Connect(format!("open {device}: {e}")))?;
    let hw = HwParams::any(&pcm).map_err(|e| BackendError::Stream(format!("hw params: {e}")))?;
    hw.set_access(Access::RWInterleaved)
        .map_err(|e| BackendError::Stream(format!("access: {e}")))?;
    hw.set_format(Format::FloatLE)
        .map_err(|e| BackendError::Stream(format!("format: {e}")))?;
    hw.set_rate(rate, ValueOr::Nearest)
        .map_err(|e| BackendError::Stream(format!("rate: {e}")))?;
    hw.set_channels(ch as u32)
        .map_err(|e| BackendError::Stream(format!("channels: {e}")))?;
    hw.set_buffer_size_near(quantum * 4)
        .map_err(|e| BackendError::Stream(format!("buffer: {e}")))?;
    hw.set_period_size_near(quantum, ValueOr::Nearest)
        .map_err(|e| BackendError::Stream(format!("period: {e}")))?;
    pcm.hw_params(&hw)
        .map_err(|e| BackendError::Stream(format!("apply: {e}")))?;
    let got_rate = hw
        .get_rate()
        .map_err(|e| BackendError::Stream(format!("get_rate: {e}")))?;
    let got_ch = hw
        .get_channels()
        .map_err(|e| BackendError::Stream(format!("get_channels: {e}")))?;
    if got_rate != rate {
        return Err(BackendError::Stream(format!(
            "device realised {got_rate} Hz, engine feeds {rate} Hz (pitch shift)"
        )));
    }
    if got_ch != ch as u32 {
        return Err(BackendError::Stream(format!(
            "device realised {got_ch} ch, engine feeds {ch} ch"
        )));
    }
    drop(hw);
    pcm.prepare()
        .map_err(|e| BackendError::Stream(format!("prepare: {e}")))?;
    pcm.start()
        .map_err(|e| BackendError::Stream(format!("start: {e}")))?;
    Ok(pcm)
}

impl AudioBackend for AlsaSink {
    fn info(&self) -> &BackendInfo {
        &INFO
    }
    fn start(&mut self, params: &StreamParams, reader: SinkReader) -> BackendResult<()> {
        self.stop()?;
        let device = self.device.clone();
        let quantum = (params.buffer_frames / 4).max(256) as Frames;
        let pcm = configure_pcm(&device, params.sample_rate, params.channels.get(), quantum)?;
        self.spawn(params, reader, pcm)
    }
    fn pause(&mut self) -> BackendResult<()> {
        Ok(())
    }
    fn resume(&mut self) -> BackendResult<()> {
        Ok(())
    }
    fn stop(&mut self) -> BackendResult<()> {
        if let Some(s) = &self.stop_flag {
            s.store(true, Ordering::Release);
        }
        if let Some(h) = self.thread.take() {
            let _ = h.join();
        }
        self.stop_flag = None;
        Ok(())
    }
}

impl Drop for AlsaSink {
    fn drop(&mut self) {
        let _ = self.stop();
    }
}
