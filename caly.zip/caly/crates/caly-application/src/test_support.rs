//! Shared unit-test fixtures: deterministic clock and blank snapshot.

use caly_domain::{
    AppliedState, BoundedVec, CapabilitySet, DaemonInstanceId, DesiredState, EventCursor,
    EventSequence, ObservedState, PlatformEffectView, PresentationSnapshot, ProxyMode,
    SnapshotRevision, UnixMillis,
};

use crate::operations::TimeSource;

/// Deterministic test clock: every read advances one millisecond.
pub(crate) struct Clock(pub(crate) u64);

impl TimeSource for Clock {
    fn now(&mut self) -> UnixMillis {
        self.0 = self.0.saturating_add(1);
        UnixMillis::new(self.0)
    }
}

/// Blank presentation snapshot shared by projection/service tests.
pub(crate) fn snapshot_fixture() -> Result<PresentationSnapshot, Box<dyn std::error::Error>> {
    let daemon = DaemonInstanceId::from_bytes([1; 16]);
    let cursor = EventCursor::new(daemon, EventSequence::ZERO);
    let capabilities = CapabilitySet::new(BoundedVec::new())?;
    Ok(PresentationSnapshot::new(
        daemon,
        SnapshotRevision::new(0),
        cursor,
        DesiredState::new(ProxyMode::Rule, None, None, false, false),
        AppliedState::stopped(),
        ObservedState::default(),
        PlatformEffectView::none(),
        capabilities,
        BoundedVec::new(),
    ))
}
