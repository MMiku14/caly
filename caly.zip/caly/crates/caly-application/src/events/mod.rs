//! Application events ordered by the sole EventSequencer.

mod sequencer;

pub use caly_domain::PresentationDelta as ApplicationEvent;
pub use sequencer::{EventSequencer, SequencedEvent, SequencerError};
