//! Daemon event bus: process-wide domain facts for the pipeline layer.
//!
//! Distinct from the projection event stream (`ApplicationEvent` +
//! `EventSequencer`, which carries ordered presentation deltas for snapshot
//! sync). This bus carries pipeline-stage facts (刀 2, pipeline
//! design): a producer publishes a fact (`SubscriptionRefreshed { changed
//! }`), zero or more consumers subscribe and react — e.g. the config
//! reconciler re-renders the kernel config only when a refresh actually
//! changed nodes. Publishing never blocks: a slow subscriber misses events
//! rather than stalling the pipeline. A bounded recent-history ring keeps
//! the last events for observability.

use std::collections::VecDeque;
use std::sync::{Arc, Mutex, RwLock};
use std::time::Instant;

/// Domain facts published by pipeline stages.
#[derive(Clone, Debug)]
pub enum DaemonEvent {
    /// A subscription refresh completed. `changed == true` means at least
    /// one source delivered updated content, so the kernel config should
    /// be re-rendered (the config reconciler's trigger).
    SubscriptionRefreshed { changed: bool },
    /// CLI sinking (2026-08-14): a config.yaml mutation completed (the
    /// source-listing publisher recomputes `sub list`).
    ConfigMutated,
    /// Config rendering/apply failed and was rolled back.
    ConfigApplyFailed { reason: String },
    /// Config rendering/apply succeeded at the given generation.
    ConfigApplied { generation: u64 },
}

/// Bounded recent-event history entry for observability.
#[derive(Clone, Debug)]
pub struct RecordedEvent {
    /// Monotonic wall-clock instant when the event was published.
    pub at: Instant,
    /// The event itself.
    pub event: DaemonEvent,
}

/// Maximum number of events retained in the recent-history ring.
pub const EVENT_HISTORY_CAP: usize = 64;
/// Per-subscriber queue capacity: a consumer slower than this misses
/// events (try_send fails full) instead of blocking the publisher.
pub const EVENT_CHANNEL_CAP: usize = 256;

/// Lightweight multi-subscriber event bus.
///
/// Clone is cheap (shared state); hand a clone to every producer and
/// consumer. Subscribers use [`EventBus::subscribe`] and receive every
/// event published after subscription — there is no replay, by design:
/// reconcilers converge from current state, history is for humans.
#[derive(Clone, Default)]
pub struct EventBus {
    subscribers: Arc<Mutex<Vec<crossbeam_channel::Sender<DaemonEvent>>>>,
    history: Arc<RwLock<VecDeque<RecordedEvent>>>,
}

impl EventBus {
    /// Creates an empty bus.
    pub fn new() -> Self {
        Self::default()
    }

    /// Subscribes a new consumer. Events published after this call are
    /// delivered; a dropped receiver is pruned on the next publish.
    pub fn subscribe(&self) -> crossbeam_channel::Receiver<DaemonEvent> {
        let (sender, receiver) = crossbeam_channel::bounded(EVENT_CHANNEL_CAP);
        if let Ok(mut subscribers) = self.subscribers.lock() {
            subscribers.push(sender);
        }
        receiver
    }

    /// Publishes an event to every subscriber and records it in the ring.
    /// Never blocks and never fails the caller: a dead subscriber is
    /// silently dropped, a full history ring drops the oldest entry.
    pub fn publish(&self, event: DaemonEvent) {
        tracing::debug!(?event, "daemon event");
        if let Ok(mut history) = self.history.write() {
            history.push_back(RecordedEvent {
                at: Instant::now(),
                event: event.clone(),
            });
            while history.len() > EVENT_HISTORY_CAP {
                history.pop_front();
            }
        }
        // DS-1: one mutex serializes publishers end to end. A read guard +
        // deferred prune used to race here: two publishers collecting the
        // same dead index would `swap_remove` twice, the second removal
        // silently unsubscribing the live sender swapped into the hole —
        // and a pruned channel reads as Disconnected, which
        // `run_reconciler` treats as daemon shutdown. Publish is
        // control-plane-cheap; the serialization cost is negligible.
        let Ok(mut subscribers) = self.subscribers.lock() else {
            return;
        };
        // Full → the consumer is slow; drop the event for it but keep the
        // subscription. Dropping is a deliberate back-pressure choice, but
        // it must be visible: a reconciler that misses `changed: true` lets
        // the kernel config go stale (agent audit).
        let mut dropped = 0u32;
        let mut disconnected = Vec::new();
        for (index, sender) in subscribers.iter().enumerate() {
            match sender.try_send(event.clone()) {
                Ok(()) => {}
                Err(crossbeam_channel::TrySendError::Full(_)) => {
                    dropped += 1;
                }
                Err(crossbeam_channel::TrySendError::Disconnected(_)) => {
                    disconnected.push(index);
                }
            }
        }
        if dropped > 0 {
            tracing::warn!(
                dropped,
                "daemon event dropped for a slow subscriber (queue full)"
            );
        }
        // Prune under the same hold that collected the indices: no other
        // publisher can shift the Vec between collect and remove.
        for index in disconnected.into_iter().rev() {
            if index < subscribers.len() {
                subscribers.swap_remove(index);
            }
        }
    }

    /// Returns the recent-history ring (oldest first) for observability.
    pub fn recent(&self) -> Vec<RecordedEvent> {
        self.history
            .read()
            .map(|history| history.iter().cloned().collect())
            .unwrap_or_default()
    }
}

/// Runs a reconciler loop on a bus subscription: blocks on `recv_timeout`,
/// invoking `on_changed` for a changed-refresh fact, and ends only when the
/// bus is dropped (daemon shutdown). `Timeout` wakes are normal idle
/// intervals, not a reason to stop (an earlier `while let Ok` version
/// exited on the first idle second and never saw refresh events).
pub fn run_reconciler(
    events: &crossbeam_channel::Receiver<DaemonEvent>,
    interval: std::time::Duration,
    mut on_changed: impl FnMut(),
) {
    loop {
        match events.recv_timeout(interval) {
            Ok(DaemonEvent::SubscriptionRefreshed { changed: true }) => on_changed(),
            Ok(_) => {}
            Err(crossbeam_channel::RecvTimeoutError::Timeout) => {}
            Err(crossbeam_channel::RecvTimeoutError::Disconnected) => break,
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::time::Duration;

    #[test]
    fn publish_reaches_subscribers_in_order() {
        let bus = EventBus::new();
        let receiver = bus.subscribe();
        bus.publish(DaemonEvent::SubscriptionRefreshed { changed: true });
        bus.publish(DaemonEvent::ConfigApplied { generation: 3 });
        let first = receiver
            .recv_timeout(Duration::from_millis(10))
            .expect("first event");
        let second = receiver
            .recv_timeout(Duration::from_millis(10))
            .expect("second event");
        assert!(matches!(
            first,
            DaemonEvent::SubscriptionRefreshed { changed: true }
        ));
        assert!(matches!(
            second,
            DaemonEvent::ConfigApplied { generation: 3 }
        ));
    }

    #[test]
    fn history_keeps_recent_events_bounded() {
        let bus = EventBus::new();
        for index in 0..(EVENT_HISTORY_CAP + 10) {
            bus.publish(DaemonEvent::ConfigApplied {
                generation: index as u64,
            });
        }
        let recent = bus.recent();
        assert_eq!(recent.len(), EVENT_HISTORY_CAP);
        assert!(matches!(
            recent.first().expect("oldest recorded").event,
            DaemonEvent::ConfigApplied { generation: 10 }
        ));
        assert!(matches!(
            recent.last().expect("newest recorded").event,
            DaemonEvent::ConfigApplied { generation: 73 }
        ));
    }

    #[test]
    fn dead_subscriber_does_not_block_publish() {
        let bus = EventBus::new();
        {
            // Receiver dropped immediately: the sender must be pruned on
            // the next publish instead of erroring the caller.
            let _receiver = bus.subscribe();
        }
        bus.publish(DaemonEvent::SubscriptionRefreshed { changed: false });
        let receiver = bus.subscribe();
        bus.publish(DaemonEvent::ConfigApplied { generation: 1 });
        assert!(
            receiver.recv_timeout(Duration::from_millis(10)).is_ok(),
            "live subscriber must still receive after a dead one"
        );
    }

    #[test]
    fn concurrent_publish_with_dead_subscriber_never_unsubscribes_live() {
        // DS-1 regression: concurrent publishers used to `swap_remove` the
        // same dead index twice, silently unsubscribing a live channel
        // (which then reads Disconnected and kills its reconciler).
        let bus = EventBus::new();
        let live = bus.subscribe();
        // Several dead subscribers: every publish observes disconnects
        // and takes the prune path, maximizing the interleaving window.
        for _ in 0..4 {
            let _dead = bus.subscribe();
        }
        std::thread::scope(|scope| {
            for _ in 0..8 {
                let bus = bus.clone();
                scope.spawn(move || {
                    for _ in 0..200 {
                        bus.publish(DaemonEvent::ConfigApplied { generation: 1 });
                    }
                });
            }
        });
        // The live channel must be full, never disconnected: a prune race
        // would drop its only sender.
        let mut received = 0u32;
        loop {
            match live.try_recv() {
                Ok(_) => received += 1,
                Err(crossbeam_channel::TryRecvError::Empty) => break,
                Err(crossbeam_channel::TryRecvError::Disconnected) => {
                    panic!("live subscriber was pruned by concurrent publish");
                }
            }
        }
        assert_eq!(received as usize, EVENT_CHANNEL_CAP);
    }
}
