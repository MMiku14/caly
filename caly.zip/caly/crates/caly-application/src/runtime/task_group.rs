//! Explicit task ownership and shutdown contracts.

use caly_domain::{BoundedText, BoundedVec};

use super::CancellationToken;

/// Maximum long-lived tasks owned by one daemon runtime.
pub const MAX_OWNED_TASKS: usize = 64;
/// Owned task name.
pub type TaskName = BoundedText<64>;

/// Runtime-neutral join handle supplied by a concrete executor boundary.
pub trait OwnedTask: Send {
    fn name(&self) -> &TaskName;
    fn request_cancel(&self);
    fn join(self: Box<Self>) -> Result<(), TaskJoinError>;
}

/// Join failure that must be reported during shutdown.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct TaskJoinError {
    pub task: TaskName,
    pub reason: BoundedText<512>,
}

/// Group owning all long-lived task handles.
pub struct TaskGroup {
    root: CancellationToken,
    tasks: BoundedVec<Box<dyn OwnedTask>, MAX_OWNED_TASKS>,
}

impl TaskGroup {
    /// Creates an empty owned task group.
    pub fn new() -> Self {
        Self {
            root: CancellationToken::new(),
            tasks: BoundedVec::new(),
        }
    }

    /// Registers ownership or returns the task to the caller when full.
    pub fn register(&mut self, task: Box<dyn OwnedTask>) -> Result<(), Box<dyn OwnedTask>> {
        self.tasks
            .try_push(task)
            .map_err(caly_domain::BoundedPushError::into_value)
    }

    /// Requests cancellation from root to every task.
    pub fn cancel_all(&self) {
        self.root.cancel();
        for task in &self.tasks {
            task.request_cancel();
        }
    }

    /// Consumes every handle and reports all join failures.
    pub fn join_all(
        self,
    ) -> Result<BoundedVec<TaskJoinError, MAX_OWNED_TASKS>, caly_domain::CapacityError> {
        let mut failures = Vec::new();
        for task in self.tasks.into_vec() {
            if let Err(error) = task.join() {
                failures.push(error);
            }
        }
        BoundedVec::try_from_vec(failures)
    }

    /// Returns a child observation of root cancellation.
    pub fn cancellation(&self) -> CancellationToken {
        self.root.clone()
    }
}

impl Default for TaskGroup {
    fn default() -> Self {
        Self::new()
    }
}
