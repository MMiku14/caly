//! Source-listing publisher (CLI sinking, 2026-08-14, read path).
//!
//! Recomputes the declared subscription-source view and publishes it into
//! the projection whenever a subscription refresh completes or a config
//! mutation is applied — so `sub list` (and future TUI/WebUI clients)
//! renders from the snapshot instead of reading config.yaml + cache files
//! directly. Event-driven: the bus is an mpsc, so the thread blocks
//! between events and publishes nothing on idle ticks.

use std::{
    sync::{Arc, Mutex},
    time::Duration,
};

use caly_application::{
    events::{DaemonEvent, EventBus},
    projection::ProjectionRuntime,
    service::WallClock,
};
use caly_domain::PresentationDelta;

use super::RuntimeService;

/// Poll interval; only used to notice bus disconnection (daemon shutdown).
const POLL_INTERVAL: Duration = Duration::from_secs(1);

/// Spawns the publisher on the shared event bus and projection service.
pub fn spawn(
    event_bus: EventBus,
    service: Arc<Mutex<RuntimeService<WallClock, ProjectionRuntime>>>,
) {
    let events = event_bus.subscribe();
    let body = move || {
        // Seed the daemon's initial snapshot: a fresh daemon has no
        // refresh/mutation event to react to, but `sub list` must still
        // see the sources already declared in config.yaml.
        publish_sources(&service);
        loop {
            match events.recv_timeout(POLL_INTERVAL) {
                Ok(DaemonEvent::SubscriptionRefreshed { changed: true })
                | Ok(DaemonEvent::ConfigMutated) => {
                    publish_sources(&service);
                }
                Ok(_) => {}
                Err(crossbeam_channel::RecvTimeoutError::Timeout) => {}
                Err(crossbeam_channel::RecvTimeoutError::Disconnected) => break,
            }
        }
    };
    super::support::spawn_reconciler_task(body);
}

/// Recomputes and publishes the declared source listing into the
/// projection (best-effort: a poisoned lock or a publish failure never
/// takes down the daemon).
fn publish_sources(service: &Arc<Mutex<RuntimeService<WallClock, ProjectionRuntime>>>) {
    let paths = caly_platform::paths::AppPaths::from_env();
    let sources = caly_profile::store::source_listing::compute(&paths);
    tracing::debug!(
        state = %paths.state.display(),
        rows = sources.len(),
        first_nodes = sources.first().map(|s| s.nodes),
        "published source listing"
    );
    if let Ok(mut service) = service.lock() {
        let _ = service
            .projection_mut()
            .publish(PresentationDelta::SourcesReplaced(sources));
    }
}
