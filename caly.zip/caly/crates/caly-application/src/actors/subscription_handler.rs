//! SubscriptionActor refresh handler.

use caly_domain::PresentationDelta;

use crate::{
    actor_result::ActorResultClient,
    command_bus::Command,
    routing::{CommandTarget, RoutedCommand},
    runtime::{ActorDirective, ActorHandler},
};

use super::{
    SubscriptionCommandBackend,
    reporting::{HandlerReportError, report_outcome},
};

/// Nonblocking backend owning fetch/parse/cache generation work.
pub struct SubscriptionCommandHandler<B> {
    backend: B,
    results: ActorResultClient,
}

impl<B> SubscriptionCommandHandler<B> {
    pub const fn new(backend: B, results: ActorResultClient) -> Self {
        Self { backend, results }
    }
}

#[derive(Debug)]
pub enum SubscriptionHandlerError {
    WrongTarget,
    WrongCommand,
    Report(HandlerReportError),
}

impl<B: SubscriptionCommandBackend> ActorHandler<RoutedCommand> for SubscriptionCommandHandler<B> {
    type Error = SubscriptionHandlerError;

    fn handle(&mut self, routed: RoutedCommand) -> Result<ActorDirective, Self::Error> {
        if routed.target != CommandTarget::SubscriptionActor {
            return Err(SubscriptionHandlerError::WrongTarget);
        }
        if routed.cancellation.is_cancel_requested() {
            return Ok(ActorDirective::Continue);
        }
        let operation_id = routed.envelope.operation_id;
        let Command::RefreshSubscription { subscription_id } = routed.envelope.command else {
            return Err(SubscriptionHandlerError::WrongCommand);
        };
        let outcome = self
            .backend
            .refresh(subscription_id)
            .map(|nodes| vec![PresentationDelta::NodesReplaced(nodes)]);
        report_outcome(&self.results, operation_id, outcome)
            .map_err(SubscriptionHandlerError::Report)?;
        Ok(ActorDirective::Continue)
    }
}
