//! ConfigMutationActor: the daemon's single writer for `config.yaml`
//! subscription mutations (CLI sinking, 2026-08-14).
//!
//! `set sub add/remove/enable/disable` previously wrote the operator's
//! `config.yaml` directly from the CLI process — a second writer racing
//! the daemon's reads. This actor owns the write path: it receives the
//! `MutateConfig` command, executes the mutation through the shared
//! `caly-configstore` pipeline (read → parse → mutate → schema-validate →
//! backup → atomic write), and reports the dry-run preview or applied
//! outcome through the standard actor-result channel.

use caly_domain::PresentationDelta;
use caly_ports::ConfigMutationBackend;

use crate::events::{DaemonEvent, EventBus};

use crate::{
    actor_result::ActorResultClient,
    command_bus::Command,
    routing::{CommandTarget, RoutedCommand},
    runtime::{ActorDirective, ActorHandler},
};

use super::reporting::{HandlerReportError, finish_report};

/// Owns config.yaml subscription mutations over the shared write pipeline.
pub struct ConfigMutationHandler<B> {
    backend: B,
    results: ActorResultClient,
    events: EventBus,
}

impl<B> ConfigMutationHandler<B> {
    /// Creates a handler owning the mutation backend and result channel.
    pub fn new(backend: B, results: ActorResultClient) -> Self {
        Self {
            backend,
            results,
            events: EventBus::new(),
        }
    }

    /// Wires the handler to the shared event bus so the source-listing
    /// publisher (composition) observes config mutations.
    #[must_use]
    pub fn with_event_bus(mut self, events: EventBus) -> Self {
        self.events = events;
        self
    }
}

/// Config-mutation handler error; nothing here should kill the actor.
#[derive(Debug)]
pub enum ConfigMutationHandlerError {
    WrongTarget,
    WrongCommand,
    Report(HandlerReportError),
}

impl<B: ConfigMutationBackend> ActorHandler<RoutedCommand> for ConfigMutationHandler<B> {
    type Error = ConfigMutationHandlerError;

    fn handle(&mut self, routed: RoutedCommand) -> Result<ActorDirective, Self::Error> {
        if routed.target != CommandTarget::ConfigMutation {
            return Err(ConfigMutationHandlerError::WrongTarget);
        }
        if routed.cancellation.is_cancel_requested() {
            return Ok(ActorDirective::Continue);
        }
        let operation_id = routed.envelope.operation_id;
        let Command::MutateConfig { mutation, apply } = routed.envelope.command else {
            return Err(ConfigMutationHandlerError::WrongCommand);
        };
        let outcome = self.backend.mutate(mutation, apply).map(|outcome| {
            // A dry-run or idempotent no-op does not change config.yaml, so
            // there is nothing for the source-listing publisher to recompute
            // (and an identical SourcesReplaced delta would only churn the
            // projector revision). The outcome delta itself still reaches
            // the caller for preview rendering.
            if outcome.applied && !outcome.unchanged {
                self.events.publish(DaemonEvent::ConfigMutated);
            }
            vec![PresentationDelta::ConfigMutated(outcome)]
        });
        finish_report(&self.results, operation_id, outcome)
            .map_err(ConfigMutationHandlerError::Report)
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::actor_result::{ActorReport, actor_result_mailbox};

    /// Deterministic backend double.
    struct FakeMutation {
        outcome: Result<caly_domain::MutationOutcome, caly_ports::ActorFailure>,
    }

    impl ConfigMutationBackend for FakeMutation {
        fn mutate(
            &mut self,
            _mutation: caly_domain::ConfigMutation,
            _apply: bool,
        ) -> Result<caly_domain::MutationOutcome, caly_ports::ActorFailure> {
            self.outcome.clone()
        }
    }

    #[test]
    fn only_an_applied_mutation_publishes_the_config_fact() {
        use std::time::Duration;
        let (ingress, receiver) = actor_result_mailbox(8).unwrap();
        let client = ActorResultClient::new(ingress);
        let bus = crate::events::EventBus::new();
        let bus_events = bus.subscribe();
        let mut handler = ConfigMutationHandler::new(
            FakeMutation {
                outcome: Ok(caly_domain::MutationOutcome {
                    resource: caly_domain::ConfigResource::Subscription,
                    count: 2,
                    url: Some("https://example.com/sub".to_owned()),
                    applied: false,
                    unchanged: false,
                }),
            },
            client,
        )
        .with_event_bus(bus);
        let dry_run = routed_command();
        assert!(matches!(
            handler.handle(dry_run).expect("dry-run accepted"),
            ActorDirective::Continue
        ));
        assert!(matches!(
            bus_events.try_recv(),
            Err(crossbeam_channel::TryRecvError::Empty)
        ));
        // Drain the actor-result channel so the second command has capacity.
        receiver
            .receive_timeout(Duration::from_millis(10))
            .expect("dry-run report queued");
    }

    fn routed_command() -> RoutedCommand {
        RoutedCommand {
            target: CommandTarget::ConfigMutation,
            envelope: crate::command_bus::CommandEnvelope {
                operation_id: caly_domain::OperationId::from_bytes([7; 16]),
                command: Command::MutateConfig {
                    mutation: caly_domain::ConfigMutation::Subscription(
                        caly_domain::SubscriptionMutation::Enable {
                            target: "cray".to_owned(),
                        },
                    ),
                    apply: false,
                },
            },
            cancellation: crate::operations::OperationCancellationToken::new(),
        }
    }

    #[test]
    fn mutation_reports_outcome() {
        use std::time::Duration;
        let (ingress, receiver) = actor_result_mailbox(8).unwrap();
        let client = ActorResultClient::new(ingress);
        let outcome = caly_domain::MutationOutcome {
            resource: caly_domain::ConfigResource::Subscription,
            count: 3,
            url: Some("https://example.com/sub".to_owned()),
            applied: true,
            unchanged: false,
        };
        let mut handler = ConfigMutationHandler::new(
            FakeMutation {
                outcome: Ok(outcome.clone()),
            },
            client,
        );
        let routed = RoutedCommand {
            target: CommandTarget::ConfigMutation,
            envelope: crate::command_bus::CommandEnvelope {
                operation_id: caly_domain::OperationId::from_bytes([7; 16]),
                command: Command::MutateConfig {
                    mutation: caly_domain::ConfigMutation::Subscription(
                        caly_domain::SubscriptionMutation::Enable {
                            target: "cray".to_owned(),
                        },
                    ),
                    apply: true,
                },
            },
            cancellation: crate::operations::OperationCancellationToken::new(),
        };
        let directive = handler.handle(routed).expect("handler accepts");
        assert!(matches!(directive, ActorDirective::Continue));
        let report = receiver
            .receive_timeout(Duration::from_millis(10))
            .expect("report queued");
        match report {
            ActorReport::Completed { deltas, .. } => {
                assert_eq!(
                    deltas.into_vec(),
                    vec![PresentationDelta::ConfigMutated(outcome)]
                );
            }
            other => panic!("unexpected report: {other:?}"),
        }
    }
}
