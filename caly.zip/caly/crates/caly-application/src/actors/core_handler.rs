//! CoreActor command handler with truthful terminal reporting.

use caly_domain::PresentationDelta;

use crate::{
    actor_result::ActorResultClient,
    command_bus::Command,
    routing::{CommandTarget, RoutedCommand},
    runtime::{ActorDirective, ActorHandler},
};

use super::{
    CoreCommandBackend,
    reporting::{HandlerReportError, report_outcome},
};

/// Nonblocking CoreActor backend; process/API I/O belongs to its owned worker.
pub struct CoreCommandHandler<B> {
    backend: B,
    results: ActorResultClient,
    desired: caly_ports::SharedDesiredState,
}

impl<B> CoreCommandHandler<B> {
    /// Creates a handler owning `backend`, the result client, and the shared
    /// desired-state cell used to build Desired/Applied deltas.
    pub const fn new(
        backend: B,
        results: ActorResultClient,
        desired: caly_ports::SharedDesiredState,
    ) -> Self {
        Self {
            backend,
            results,
            desired,
        }
    }
}

#[derive(Debug)]
pub enum CoreHandlerError {
    WrongTarget,
    WrongCommand,
    Report(HandlerReportError),
}

impl<B: CoreCommandBackend> ActorHandler<RoutedCommand> for CoreCommandHandler<B> {
    type Error = CoreHandlerError;

    fn handle(&mut self, routed: RoutedCommand) -> Result<ActorDirective, Self::Error> {
        if routed.target != CommandTarget::CoreActor {
            return Err(CoreHandlerError::WrongTarget);
        }
        if routed.cancellation.is_cancel_requested() {
            return Ok(ActorDirective::Continue);
        }
        let operation_id = routed.envelope.operation_id;
        let outcome = match routed.envelope.command {
            Command::SelectProxy { node_id } => self
                .backend
                .select_proxy(node_id)
                .map(|state| vec![PresentationDelta::AppliedReplaced(state)]),
            Command::CloseAllConnections => self
                .backend
                .close_all_connections()
                .map(|state| vec![PresentationDelta::ObservedReplaced(state)]),
            Command::SetMode { mode } => {
                // Publish both the user-intent (Desired) and the acknowledged
                // (Applied) slice so the projection reflects a coherent mode.
                let current = self.desired.value();
                let new_desired = self.desired.replace(current.with_mode(mode));
                self.backend.set_mode(mode).map(|state| {
                    vec![
                        PresentationDelta::DesiredReplaced(new_desired),
                        PresentationDelta::AppliedReplaced(state),
                    ]
                })
            }
            _ => return Err(CoreHandlerError::WrongCommand),
        };
        report_outcome(&self.results, operation_id, outcome).map_err(CoreHandlerError::Report)?;
        Ok(ActorDirective::Continue)
    }
}
