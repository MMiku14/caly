//! Actor/coordinator result messages applied by the operation owner.

use caly_domain::{OperationFailure, OperationId, OperationStatus};

use super::{AdmissionController, AdmissionError, TimeSource};

/// Lifecycle update emitted by an actor or coordinator.
pub enum OperationUpdate {
    Started {
        operation_id: OperationId,
    },
    CommitReached {
        operation_id: OperationId,
    },
    Completed {
        operation_id: OperationId,
    },
    Failed {
        operation_id: OperationId,
        failure: OperationFailure,
    },
}

impl OperationUpdate {
    pub const fn operation_id(&self) -> OperationId {
        match self {
            Self::Started { operation_id }
            | Self::CommitReached { operation_id }
            | Self::Completed { operation_id }
            | Self::Failed { operation_id, .. } => *operation_id,
        }
    }
}

/// Result after the single owner applies an actor update.
pub enum OperationUpdateResult {
    Status(OperationStatus),
    CommitRecorded(OperationStatus),
}

impl<T: TimeSource> AdmissionController<T> {
    /// Applies one actor/coordinator update through the sole operation owner.
    pub fn apply_update(
        &mut self,
        update: OperationUpdate,
    ) -> Result<OperationUpdateResult, AdmissionError> {
        match update {
            OperationUpdate::Started { operation_id } => {
                self.start(operation_id).map(OperationUpdateResult::Status)
            }
            OperationUpdate::CommitReached { operation_id } => {
                self.mark_committed(operation_id)?;
                self.status(operation_id)
                    .map(OperationUpdateResult::CommitRecorded)
            }
            OperationUpdate::Completed { operation_id } => self
                .complete(operation_id)
                .map(OperationUpdateResult::Status),
            OperationUpdate::Failed {
                operation_id,
                failure,
            } => self
                .fail(operation_id, failure)
                .map(OperationUpdateResult::Status),
        }
    }
}
