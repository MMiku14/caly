//! Internal operation record and legal transitions.

use caly_domain::{
    BoundedText, OperationFailure, OperationId, OperationState, OperationStatus,
    OperationStatusError, UnixMillis,
};

use crate::command_bus::Command;

use super::{CommitSignal, OperationCancellationToken};

/// Internal operation record owned only by OperationStore.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct OperationRecord {
    id: OperationId,
    command: Command,
    kind: BoundedText<64>,
    created_at: UnixMillis,
    updated_at: UnixMillis,
    state: OperationState,
    failure: Option<OperationFailure>,
    commit_reached: bool,
    cancellation: OperationCancellationToken,
}

impl OperationRecord {
    /// Creates a pending operation.
    pub fn pending(
        id: OperationId,
        command: Command,
        kind: BoundedText<64>,
        now: UnixMillis,
    ) -> Self {
        Self {
            id,
            command,
            kind,
            created_at: now,
            updated_at: now,
            state: OperationState::Pending,
            failure: None,
            commit_reached: false,
            cancellation: OperationCancellationToken::new(),
        }
    }

    /// Applies a checked state transition.
    pub fn transition(
        &mut self,
        target: OperationState,
        now: UnixMillis,
        failure: Option<OperationFailure>,
    ) -> Result<(), TransitionError> {
        if now < self.updated_at {
            return Err(TransitionError::TimeMovedBackwards);
        }
        if !legal_transition(self.state, target) {
            return Err(TransitionError::Illegal {
                from: self.state,
                to: target,
            });
        }
        validate_failure(target, failure.as_ref())?;
        if target == OperationState::Cancelled {
            match self.cancellation.request_cancel() {
                super::CancellationSignal::Requested
                | super::CancellationSignal::AlreadyRequested => {}
                super::CancellationSignal::TooLate => {
                    return Err(TransitionError::CancellationAfterCommit);
                }
            }
        }
        self.state = target;
        self.updated_at = now;
        self.failure = failure;
        Ok(())
    }

    /// Marks the point after which cancellation cannot compensate safely.
    pub fn mark_committed(&mut self) -> Result<(), TransitionError> {
        if self.state != OperationState::Running {
            return Err(TransitionError::CommitOutsideRunning);
        }
        match self.cancellation.mark_committed() {
            CommitSignal::Committed | CommitSignal::AlreadyCommitted => {
                self.commit_reached = true;
                Ok(())
            }
            CommitSignal::CancellationWon => Err(TransitionError::CommitAfterCancellation),
        }
    }

    /// Returns whether explicit cancellation remains legal.
    ///
    /// Pending work is always cancellable. Running work is cancellable only
    /// for commands whose owner contract supports cooperative cancellation and
    /// only before the explicit commit point.
    pub const fn can_cancel(&self) -> bool {
        !self.commit_reached
            && (matches!(self.state, OperationState::Pending)
                || (matches!(self.state, OperationState::Running)
                    && self.command.supports_running_cancellation()))
    }

    pub fn cancellation_token(&self) -> OperationCancellationToken {
        self.cancellation.clone()
    }

    /// Creates the immutable Domain status projection.
    pub fn status(&self) -> Result<OperationStatus, OperationStatusError> {
        OperationStatus::new(
            self.id,
            self.kind.clone(),
            self.created_at,
            self.updated_at,
            self.state,
            self.failure.clone(),
        )
    }

    pub const fn id(&self) -> OperationId {
        self.id
    }
    pub const fn command(&self) -> &Command {
        &self.command
    }
    pub const fn state(&self) -> OperationState {
        self.state
    }
}

/// Illegal lifecycle transition.
#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub enum TransitionError {
    TimeMovedBackwards,
    Illegal {
        from: OperationState,
        to: OperationState,
    },
    MissingFailure,
    UnexpectedFailure,
    CommitOutsideRunning,
    CommitAfterCancellation,
    CancellationAfterCommit,
}

impl core::fmt::Display for TransitionError {
    fn fmt(&self, formatter: &mut core::fmt::Formatter<'_>) -> core::fmt::Result {
        match self {
            Self::TimeMovedBackwards => {
                formatter.write_str("operation clock moved backwards")
            }
            Self::Illegal { from, to } => write!(
                formatter,
                "illegal operation transition from {} to {}",
                from.label(),
                to.label()
            ),
            Self::MissingFailure => {
                formatter.write_str("failure transition carries no failure detail")
            }
            Self::UnexpectedFailure => {
                formatter.write_str("success transition carries a failure detail")
            }
            Self::CommitOutsideRunning => {
                formatter.write_str("commit outside the running state")
            }
            Self::CommitAfterCancellation => {
                formatter.write_str("commit after cancellation")
            }
            Self::CancellationAfterCommit => {
                formatter.write_str("cancellation after commit")
            }
        }
    }
}

impl std::error::Error for TransitionError {}

const fn legal_transition(from: OperationState, to: OperationState) -> bool {
    matches!(
        (from, to),
        (OperationState::Pending, OperationState::Running)
            | (OperationState::Pending, OperationState::Cancelled)
            | (OperationState::Running, OperationState::Completed)
            | (OperationState::Running, OperationState::Failed)
            | (OperationState::Running, OperationState::Cancelled)
    )
}

fn validate_failure(
    state: OperationState,
    failure: Option<&OperationFailure>,
) -> Result<(), TransitionError> {
    match (state, failure) {
        (OperationState::Failed, None) => Err(TransitionError::MissingFailure),
        (OperationState::Failed, Some(_)) | (_, None) => Ok(()),
        (_, Some(_)) => Err(TransitionError::UnexpectedFailure),
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use caly_domain::OperationFailureCode;

    fn record(command: Command) -> Result<OperationRecord, Box<dyn std::error::Error>> {
        Ok(OperationRecord::pending(
            OperationId::from_bytes([9; 16]),
            command,
            BoundedText::new("tun.set")?,
            UnixMillis::new(100),
        ))
    }

    fn failure() -> Result<OperationFailure, Box<dyn std::error::Error>> {
        Ok(OperationFailure::new(
            OperationFailureCode::Conflict,
            BoundedText::new("conflict")?,
            BoundedText::new("retry")?,
        ))
    }

    #[test]
    fn happy_path_projects_status() -> Result<(), Box<dyn std::error::Error>> {
        let mut record = record(Command::SetTun { enabled: true })?;
        assert_eq!(record.state(), OperationState::Pending);
        record.transition(OperationState::Running, UnixMillis::new(101), None)?;
        record.transition(OperationState::Completed, UnixMillis::new(102), None)?;
        let status = record.status()?;
        assert_eq!(status.id(), OperationId::from_bytes([9; 16]));
        assert_eq!(status.state(), OperationState::Completed);
        Ok(())
    }

    #[test]
    fn illegal_transitions_rejected() -> Result<(), Box<dyn std::error::Error>> {
        let mut record = record(Command::SetTun { enabled: true })?;
        assert_eq!(
            record.transition(OperationState::Completed, UnixMillis::new(101), None),
            Err(TransitionError::Illegal {
                from: OperationState::Pending,
                to: OperationState::Completed,
            })
        );
        assert_eq!(
            record.transition(OperationState::Running, UnixMillis::new(99), None),
            Err(TransitionError::TimeMovedBackwards)
        );
        Ok(())
    }

    #[test]
    fn failure_details_validated() -> Result<(), Box<dyn std::error::Error>> {
        let mut record = record(Command::SetTun { enabled: true })?;
        record.transition(OperationState::Running, UnixMillis::new(101), None)?;
        assert_eq!(
            record.transition(OperationState::Failed, UnixMillis::new(102), None),
            Err(TransitionError::MissingFailure)
        );
        assert_eq!(
            record.transition(
                OperationState::Completed,
                UnixMillis::new(102),
                Some(failure()?)
            ),
            Err(TransitionError::UnexpectedFailure)
        );
        record.transition(
            OperationState::Failed,
            UnixMillis::new(102),
            Some(failure()?),
        )?;
        assert_eq!(record.status()?.state(), OperationState::Failed);
        Ok(())
    }

    #[test]
    fn commit_gate_and_cancel_after_commit() -> Result<(), Box<dyn std::error::Error>> {
        let mut record = record(Command::SetTun { enabled: true })?;
        assert_eq!(
            record.mark_committed(),
            Err(TransitionError::CommitOutsideRunning)
        );
        record.transition(OperationState::Running, UnixMillis::new(101), None)?;
        record.mark_committed()?;
        assert_eq!(
            record.transition(OperationState::Cancelled, UnixMillis::new(102), None),
            Err(TransitionError::CancellationAfterCommit)
        );
        Ok(())
    }

    #[test]
    fn can_cancel_matrix() -> Result<(), Box<dyn std::error::Error>> {
        let pending = record(Command::CloseAllConnections)?;
        assert!(pending.can_cancel());
        let mut running_cancel = record(Command::SetTun { enabled: true })?;
        running_cancel.transition(OperationState::Running, UnixMillis::new(101), None)?;
        assert!(running_cancel.can_cancel());
        running_cancel.mark_committed()?;
        assert!(!running_cancel.can_cancel());
        let mut running_plain = record(Command::CloseAllConnections)?;
        running_plain.transition(OperationState::Running, UnixMillis::new(101), None)?;
        assert!(!running_plain.can_cancel());
        Ok(())
    }
}
