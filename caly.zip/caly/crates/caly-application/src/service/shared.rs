//! Shared transport facade for the daemon composition root.

use std::sync::{Arc, Mutex};

use caly_domain::{EventCursor, OperationId, OperationStatus, PresentationSnapshot};

use crate::projection::ProjectionRuntime;
use crate::{
    command_bus::CommandEnvelope,
    composition::WallClock,
    events::SequencedEvent,
    service::runtime_service::RuntimeService,
    service::{
        ApplicationServiceError, ApplicationServicePort, ApplicationWatch, CancellationResult,
    },
};

impl ApplicationServicePort for Arc<Mutex<RuntimeService<WallClock, ProjectionRuntime>>> {
    fn submit(
        &mut self,
        envelope: CommandEnvelope,
    ) -> Result<OperationStatus, ApplicationServiceError> {
        self.lock()
            .map_err(|_| ApplicationServiceError::InternalInvariant)?
            .submit(envelope)
    }
    fn cancel(&mut self, id: OperationId) -> Result<CancellationResult, ApplicationServiceError> {
        self.lock()
            .map_err(|_| ApplicationServiceError::InternalInvariant)?
            .cancel(id)
    }
    fn operation_status(
        &self,
        id: OperationId,
    ) -> Result<OperationStatus, ApplicationServiceError> {
        self.lock()
            .map_err(|_| ApplicationServiceError::InternalInvariant)?
            .operation_status(id)
    }
    fn snapshot(&self) -> Result<PresentationSnapshot, ApplicationServiceError> {
        self.lock()
            .map_err(|_| ApplicationServiceError::InternalInvariant)?
            .snapshot()
    }
    fn watch_after(
        &self,
        cursor: Option<EventCursor>,
    ) -> Result<ApplicationWatch, ApplicationServiceError> {
        self.lock()
            .map_err(|_| ApplicationServiceError::InternalInvariant)?
            .watch_after(cursor)
    }
    fn subscribe_live(&self) -> tokio::sync::broadcast::Receiver<SequencedEvent> {
        let Ok(guard) = self.lock() else {
            // Poisoned service cannot publish; return a channel that yields no
            // events by creating a detached receiver.
            let (tx, rx) = tokio::sync::broadcast::channel(1);
            drop(tx);
            return rx;
        };
        guard.subscribe_live()
    }
}
