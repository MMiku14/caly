//! Concrete single-owner Application service facade.


use caly_domain::{
    EventCursor, OperationFailure, OperationFailureCode, OperationId, OperationState,
    OperationStatus, PresentationSnapshot,
};

use crate::{
    command_bus::CommandEnvelope,
    events::SequencedEvent,
    operations::{AdmissionController, AdmissionError, StoreError, TimeSource},
    routing::{CommandSink, RouteDispatchError, route},
    service::{
        ApplicationServiceError, ApplicationServicePort, ApplicationWatch, CancellationResult,
        CommandSupportPolicy, SharedLiveConnectionQuery,
    },
};

/// Projection/replay reader owned by the runtime thread.
pub trait ProjectionService {
    fn snapshot(&self) -> Result<PresentationSnapshot, ApplicationServiceError>;
    fn watch_after(
        &self,
        cursor: Option<EventCursor>,
    ) -> Result<ApplicationWatch, ApplicationServiceError>;
    /// Subscribes to live projection events after the current position.
    fn subscribe_live(&self) -> tokio::sync::broadcast::Receiver<SequencedEvent>;
}

/// Serial facade joining atomic mutation admission with read projection.
pub struct RuntimeService<T, P> {
    admission: AdmissionController<T>,
    projection: P,
    command_support: CommandSupportPolicy,
    live_connections: Option<SharedLiveConnectionQuery>,
}

impl<T, P> RuntimeService<T, P> {
    /// Creates a service with all commands enabled. This constructor is kept
    /// for isolated tests/embedders that supply every owner; daemon composition
    /// must use `new_with_policy`.
    pub const fn new(admission: AdmissionController<T>, projection: P) -> Self {
        Self::new_with_policy(admission, projection, CommandSupportPolicy::All)
    }

    /// Creates a service with an explicit admission-time command surface.
    pub const fn new_with_policy(
        admission: AdmissionController<T>,
        projection: P,
        command_support: CommandSupportPolicy,
    ) -> Self {
        Self {
            admission,
            projection,
            command_support,
            live_connections: None,
        }
    }

    /// Executor/actor owner uses this path for legal operation transitions.
    pub const fn admission_mut(&mut self) -> &mut AdmissionController<T> {
        &mut self.admission
    }

    pub const fn projection_mut(&mut self) -> &mut P {
        &mut self.projection
    }

    /// Installs the shared live kernel query owner. The composition root
    /// calls this after controller construction; until then live connection
    /// reads fail as [`ApplicationServiceError::Unavailable`].
    pub fn set_live_connection_query(&mut self, query: SharedLiveConnectionQuery) {
        self.live_connections = Some(query);
    }
}

/// One bounded command-dispatch cycle result.
pub enum DispatchOutcome {
    Idle,
    IngressClosed,
    /// The operation was cancelled while Pending; its queued envelope was
    /// consumed without reaching an owner actor.
    CancelledBeforeDispatch(OperationStatus),
    Dispatched(OperationStatus),
    Rejected {
        status: OperationStatus,
        reason: DispatchRejectReason,
    },
}

#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub enum DispatchRejectReason {
    ResourceExhausted,
    TargetClosed,
}

#[derive(Debug)]
pub enum RuntimeDispatchError {
    InvalidTimeout,
    Admission(AdmissionError),
}

impl core::fmt::Display for RuntimeDispatchError {
    fn fmt(&self, formatter: &mut core::fmt::Formatter<'_>) -> core::fmt::Result {
        match self {
            Self::InvalidTimeout => formatter.write_str("runtime dispatch timeout is invalid"),
            Self::Admission(error) => write!(formatter, "runtime dispatch failed: {error}"),
        }
    }
}

impl std::error::Error for RuntimeDispatchError {}

impl<T: TimeSource, P> RuntimeService<T, P> {
    /// Starts an admitted operation, then routes it to one bounded owner mailbox.
    /// Dispatches one already-received envelope to its owner actor.
    ///
    /// Lock discipline: the caller receives the envelope WITHOUT the
    /// service lock ([`crate::command_bus::CommandReceiver::receive_timeout`])
    /// and locks only for this call, which never blocks. Receiving
    /// under the lock used to gate every transport read (snapshot,
    /// status, …) behind the 100 ms poll budget — and behind every
    /// other waiter ahead of it — so idle RPCs took seconds.
    /// The dispatch loop is the sole mailbox consumer, so no envelope
    /// is lost or double-dispatched between the two steps.
    pub fn dispatch_envelope(
        &mut self,
        envelope: CommandEnvelope,
        sink: &mut impl CommandSink,
    ) -> Result<DispatchOutcome, RuntimeDispatchError> {
        let current = self
            .admission
            .status(envelope.operation_id)
            .map_err(RuntimeDispatchError::Admission)?;
        if current.state() == OperationState::Cancelled {
            // Cancellation won the single-owner race while this envelope was
            // still queued. Consume it without starting or dispatching work.
            return Ok(DispatchOutcome::CancelledBeforeDispatch(current));
        }
        let operation_cancellation = self
            .admission
            .cancellation_token(envelope.operation_id)
            .map_err(RuntimeDispatchError::Admission)?;
        let running = self
            .admission
            .start(envelope.operation_id)
            .map_err(RuntimeDispatchError::Admission)?;
        let operation_id = envelope.operation_id;
        match sink.try_dispatch(route(envelope, operation_cancellation)) {
            Ok(()) => Ok(DispatchOutcome::Dispatched(running)),
            Err(error) => self.reject_dispatch(operation_id, error),
        }
    }

    fn reject_dispatch(
        &mut self,
        operation_id: OperationId,
        error: RouteDispatchError,
    ) -> Result<DispatchOutcome, RuntimeDispatchError> {
        let (reason, failure) = match error {
            RouteDispatchError::ResourceExhausted(_) => (
                DispatchRejectReason::ResourceExhausted,
                dispatch_failure(
                    OperationFailureCode::ResourceExhausted,
                    "target mailbox is full",
                    "query this operation, then retry later with a new operation id",
                ),
            ),
            RouteDispatchError::TargetClosed(_) => (
                DispatchRejectReason::TargetClosed,
                dispatch_failure(
                    OperationFailureCode::Infrastructure,
                    "target actor is closed",
                    "restart or reconnect to the daemon",
                ),
            ),
        };
        let status = self
            .admission
            .fail(operation_id, failure)
            .map_err(RuntimeDispatchError::Admission)?;
        Ok(DispatchOutcome::Rejected { status, reason })
    }
}

fn dispatch_failure(
    code: OperationFailureCode,
    message: &'static str,
    action: &'static str,
) -> OperationFailure {
    // Static literals, well within the bounded capacities; the infallible
    // `clamped` constructor replaces the old `BoundedText::new(...)?`
    // daemon-fatal early return (an unapplied dispatch would leave the
    // operation Started-not-Failed until the next cancel).
    OperationFailure::clamped(code, message, action)
}

impl<T, P> ApplicationServicePort for RuntimeService<T, P>
where
    T: TimeSource,
    P: ProjectionService,
{
    fn submit(
        &mut self,
        envelope: CommandEnvelope,
    ) -> Result<caly_domain::OperationStatus, ApplicationServiceError> {
        // Reject contract-only commands before reserving an Operation or
        // enqueueing work. A rejected command therefore cannot become a
        // permanently Running operation or reach an incompatible actor.
        self.command_support.validate(envelope.command.clone())?;
        self.admission.submit(envelope).map_err(map_admission)
    }

    fn cancel(
        &mut self,
        operation_id: OperationId,
    ) -> Result<CancellationResult, ApplicationServiceError> {
        let (decision, status) = self.admission.cancel(operation_id).map_err(map_admission)?;
        Ok(CancellationResult { decision, status })
    }

    fn operation_status(
        &self,
        operation_id: OperationId,
    ) -> Result<caly_domain::OperationStatus, ApplicationServiceError> {
        self.admission.status(operation_id).map_err(map_admission)
    }

    fn list_operations(&self) -> Result<caly_domain::OperationList, ApplicationServiceError> {
        Ok(self
            .admission
            .recent_operations(caly_domain::MAX_OPERATION_LIST))
    }

    fn live_connections(
        &self,
    ) -> Result<Vec<caly_domain::LiveConnection>, ApplicationServiceError> {
        let Some(query) = &self.live_connections else {
            return Err(ApplicationServiceError::Unavailable);
        };
        query
            .lock()
            .map_err(|_| ApplicationServiceError::InternalInvariant)?
            .connection_details(std::time::Duration::from_secs(2))
            .map_err(|_| ApplicationServiceError::InternalInvariant)
    }

    fn snapshot(&self) -> Result<PresentationSnapshot, ApplicationServiceError> {
        self.projection.snapshot()
    }

    fn watch_after(
        &self,
        cursor: Option<EventCursor>,
    ) -> Result<ApplicationWatch, ApplicationServiceError> {
        self.projection.watch_after(cursor)
    }

    fn subscribe_live(&self) -> tokio::sync::broadcast::Receiver<SequencedEvent> {
        self.projection.subscribe_live()
    }
}

fn map_admission(error: AdmissionError) -> ApplicationServiceError {
    match error {
        AdmissionError::Store(StoreError::ResourceExhausted) | AdmissionError::Queue(_) => {
            ApplicationServiceError::ResourceExhausted
        }
        AdmissionError::Store(StoreError::NotFound) => ApplicationServiceError::OperationNotFound,
        AdmissionError::Store(StoreError::IdempotencyConflict) => {
            ApplicationServiceError::IdempotencyConflict
        }
        AdmissionError::QueueRollback { .. }
        | AdmissionError::Store(_)
        | AdmissionError::InvalidKind(_)
        | AdmissionError::Status(_) => ApplicationServiceError::InternalInvariant,
    }
}

#[cfg(test)]
mod runtime_service_tests;
