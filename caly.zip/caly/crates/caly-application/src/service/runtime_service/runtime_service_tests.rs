use super::*;
use std::time::Duration;
use crate::{
    command_bus::{Command, CommandReceiveError, command_bus},
    events::SequencedEvent,
    operations::{CancelDecision, OperationStore},
    routing::{CommandSink, RouteDispatchError, RoutedCommand},
};
use caly_domain::{LiveConnection, OperationId, OperationState};
use crate::test_support::Clock;
use caly_ports::{ActorFailure, LiveConnectionQuery};

struct FullSink;
impl CommandSink for FullSink {
    fn try_dispatch(&mut self, command: RoutedCommand) -> Result<(), RouteDispatchError> {
        Err(RouteDispatchError::ResourceExhausted(command))
    }
}

#[derive(Default)]
struct CaptureSink(Option<RoutedCommand>);
impl CommandSink for CaptureSink {
    fn try_dispatch(&mut self, command: RoutedCommand) -> Result<(), RouteDispatchError> {
        self.0 = Some(command);
        Ok(())
    }
}

struct TestProjection;
impl ProjectionService for TestProjection {
    fn snapshot(&self) -> Result<PresentationSnapshot, ApplicationServiceError> {
        Err(ApplicationServiceError::Unavailable)
    }

    fn watch_after(
        &self,
        _cursor: Option<EventCursor>,
    ) -> Result<ApplicationWatch, ApplicationServiceError> {
        Err(ApplicationServiceError::Unavailable)
    }

    fn subscribe_live(&self) -> tokio::sync::broadcast::Receiver<SequencedEvent> {
        let (tx, rx) = tokio::sync::broadcast::channel(1);
        drop(tx);
        rx
    }
}

#[test]
fn list_operations_returns_recent_first_within_domain_bound()
-> Result<(), Box<dyn std::error::Error>> {
    let (ingress, _receiver) = command_bus(4)?;
    let admission = AdmissionController::new(OperationStore::new(8, 4)?, ingress, Clock(0));
    let mut service = RuntimeService::new(admission, TestProjection);
    let first = OperationId::from_bytes([1; 16]);
    let second = OperationId::from_bytes([2; 16]);
    service.submit(CommandEnvelope {
        operation_id: first,
        command: Command::SetTun { enabled: true },
    })?;
    service.submit(CommandEnvelope {
        operation_id: second,
        command: Command::SetMode {
            mode: caly_domain::ProxyMode::Rule,
        },
    })?;
    let operations = service.list_operations()?;
    assert_eq!(operations.len(), 2);
    assert_eq!(operations[0].id(), second);
    assert_eq!(operations[1].id(), first);
    Ok(())
}

#[test]
fn unsupported_command_is_rejected_before_operation_reservation()
-> Result<(), Box<dyn std::error::Error>> {
    let (ingress, receiver) = command_bus(2)?;
    let admission = AdmissionController::new(OperationStore::new(4, 2)?, ingress, Clock(0));
    let mut service = RuntimeService::new_with_policy(
        admission,
        TestProjection,
        CommandSupportPolicy::lifecycle_only(caly_domain::CoreKind::Mihomo),
    );
    let id = OperationId::from_bytes([9; 16]);
    let result = service.submit(CommandEnvelope {
        operation_id: id,
        command: Command::SetTun { enabled: true },
    });
    assert!(matches!(
        result,
        Err(ApplicationServiceError::InvalidCommand(_))
    ));
    assert!(matches!(
        service.operation_status(id),
        Err(ApplicationServiceError::OperationNotFound)
    ));
    assert_eq!(
        receiver.receive_timeout(Duration::from_millis(1)),
        Err(CommandReceiveError::TimedOut)
    );
    Ok(())
}

#[test]
fn dispatcher_token_observes_running_cancellation() -> Result<(), Box<dyn std::error::Error>> {
    let (ingress, receiver) = command_bus(2)?;
    let admission = AdmissionController::new(OperationStore::new(4, 2)?, ingress, Clock(0));
    let mut service = RuntimeService::new(admission, TestProjection);
    let id = OperationId::from_bytes([6; 16]);
    service.submit(CommandEnvelope {
        operation_id: id,
        command: Command::SetTun { enabled: true },
    })?;
    let expected = service.admission_mut().cancellation_token(id)?;
    let mut sink = CaptureSink::default();
    let envelope = receiver
        .receive_timeout(Duration::from_millis(1))
        .map_err(|_| "receive failed")?;
    let outcome = service.dispatch_envelope(envelope, &mut sink)?;
    assert!(matches!(outcome, DispatchOutcome::Dispatched(_)));
    let routed = sink.0.ok_or("routed command missing")?;
    assert_eq!(routed.cancellation, expected);
    assert!(!routed.cancellation.is_cancel_requested());
    let cancelled = service.cancel(id)?;
    assert_eq!(cancelled.decision, CancelDecision::Cancelled);
    assert_eq!(cancelled.status.state(), OperationState::Cancelled);
    assert!(routed.cancellation.is_cancel_requested());
    Ok(())
}

#[test]
fn pending_cancel_consumes_envelope_without_dispatch() -> Result<(), Box<dyn std::error::Error>> {
    let (ingress, receiver) = command_bus(2)?;
    let admission = AdmissionController::new(OperationStore::new(4, 2)?, ingress, Clock(0));
    let mut service = RuntimeService::new(admission, TestProjection);
    let id = OperationId::from_bytes([8; 16]);
    service.submit(CommandEnvelope {
        operation_id: id,
        command: Command::SetTun { enabled: true },
    })?;
    let cancelled = service.cancel(id)?;
    assert_eq!(cancelled.decision, CancelDecision::Cancelled);
    assert_eq!(cancelled.status.state(), OperationState::Cancelled);

    let envelope = receiver
        .receive_timeout(Duration::from_millis(1))
        .map_err(|_| "receive failed")?;
    let outcome = service.dispatch_envelope(envelope, &mut FullSink)?;
    assert!(matches!(
        outcome,
        DispatchOutcome::CancelledBeforeDispatch(ref status)
            if status.state() == OperationState::Cancelled
    ));
    assert_eq!(
        service.operation_status(id)?.state(),
        OperationState::Cancelled
    );
    Ok(())
}

#[test]
fn target_backpressure_finishes_operation_as_failed() -> Result<(), Box<dyn std::error::Error>> {
    let (ingress, receiver) = command_bus(2)?;
    let admission = AdmissionController::new(OperationStore::new(4, 2)?, ingress, Clock(0));
    let mut service = RuntimeService::new(admission, ());
    let id = OperationId::from_bytes([1; 16]);
    service.admission_mut().submit(CommandEnvelope {
        operation_id: id,
        command: Command::SetTun { enabled: true },
    })?;
    let envelope = receiver
        .receive_timeout(Duration::from_millis(1))
        .map_err(|_| "receive failed")?;
    let outcome = service.dispatch_envelope(envelope, &mut FullSink)?;
    assert!(matches!(outcome, DispatchOutcome::Rejected {
            ref status,
            reason: DispatchRejectReason::ResourceExhausted,
        } if status.state() == OperationState::Failed));
    Ok(())
}

struct StubConnectionQuery(Vec<LiveConnection>);
impl LiveConnectionQuery for StubConnectionQuery {
    fn connection_details(
        &mut self,
        _timeout: std::time::Duration,
    ) -> Result<Vec<LiveConnection>, ActorFailure> {
        Ok(self.0.clone())
    }
}

fn canned_connection() -> LiveConnection {
    LiveConnection {
        id: "conn-1".to_owned(),
        host: "example.com".to_owned(),
        destination_port: 443,
        network: "tcp".to_owned(),
        protocol_type: "tls".to_owned(),
        inbound_name: "mixed".to_owned(),
        process_path: String::new(),
        rule: "MATCH".to_owned(),
        rule_payload: String::new(),
        outbound: "proxy".to_owned(),
        chain: vec!["PROXY".to_owned()],
        upload_bytes: 7,
        download_bytes: 11,
    }
}

#[test]
fn live_connections_without_installed_query_fails_unavailable()
-> Result<(), Box<dyn std::error::Error>> {
    let (ingress, _receiver) = command_bus(4)?;
    let admission = AdmissionController::new(OperationStore::new(8, 4)?, ingress, Clock(0));
    let service = RuntimeService::new(admission, TestProjection);
    assert!(matches!(
        service.live_connections(),
        Err(ApplicationServiceError::Unavailable)
    ));
    Ok(())
}

#[test]
fn installed_live_connection_query_serves_kernel_details()
-> Result<(), Box<dyn std::error::Error>> {
    let (ingress, _receiver) = command_bus(4)?;
    let admission = AdmissionController::new(OperationStore::new(8, 4)?, ingress, Clock(0));
    let mut service = RuntimeService::new(admission, TestProjection);
    let query: SharedLiveConnectionQuery =
        std::sync::Arc::new(std::sync::Mutex::new(StubConnectionQuery(vec![
            canned_connection(),
        ])));
    service.set_live_connection_query(query);
    let connections = service.live_connections()?;
    assert_eq!(connections.len(), 1);
    assert_eq!(connections[0].id, "conn-1");
    assert_eq!(connections[0].download_bytes, 11);
    Ok(())
}
