//! Transport-facing Application service port.

use caly_domain::{
    BoundedText, BoundedVec, EventCursor, LiveConnection, OperationId, OperationList,
    OperationStatus, PresentationSnapshot,
};

use crate::{command_bus::CommandEnvelope, events::SequencedEvent, operations::CancelDecision};

/// Maximum replay events returned in one bounded service batch.
pub const MAX_REPLAY_BATCH: usize = 1_024;
pub type ReplayBatch = BoundedVec<SequencedEvent, MAX_REPLAY_BATCH>;
/// Shared live-kernel query owner handed to [`RuntimeService`] by the
/// composition root. The mutex keeps the synchronous controller query out of
/// the Tokio worker while the service facade remains lock-free for readers.
pub type SharedLiveConnectionQuery =
    std::sync::Arc<std::sync::Mutex<dyn caly_ports::LiveConnectionQuery + Send>>;

/// Watch recovery result selected by the Application owner.
pub enum ApplicationWatch {
    Replay(ReplayBatch),
    FullSnapshot(Box<PresentationSnapshot>),
}

/// Cancellation result with authoritative current status.
pub struct CancellationResult {
    pub decision: CancelDecision,
    pub status: OperationStatus,
}

/// Safe service error mapped by Transport in one place.
#[derive(Clone, Debug, Eq, PartialEq)]
pub enum ApplicationServiceError {
    ResourceExhausted,
    OperationNotFound,
    IdempotencyConflict,
    InvalidCommand(BoundedText<512>),
    Unavailable,
    InternalInvariant,
}

impl core::fmt::Display for ApplicationServiceError {
    fn fmt(&self, formatter: &mut core::fmt::Formatter<'_>) -> core::fmt::Result {
        match self {
            Self::ResourceExhausted => {
                formatter.write_str("admission queue is full; retry shortly")
            }
            Self::OperationNotFound => formatter.write_str("operation not found"),
            Self::IdempotencyConflict => {
                formatter.write_str("duplicate operation id with a different command")
            }
            Self::InvalidCommand(detail) => write!(formatter, "invalid command: {detail}"),
            Self::Unavailable => formatter.write_str("application service unavailable"),
            Self::InternalInvariant => formatter.write_str("internal invariant violated"),
        }
    }
}

impl std::error::Error for ApplicationServiceError {}

/// All transport calls enter Application through this interface.
pub trait ApplicationServicePort {
    fn submit(
        &mut self,
        envelope: CommandEnvelope,
    ) -> Result<OperationStatus, ApplicationServiceError>;
    fn cancel(
        &mut self,
        operation_id: OperationId,
    ) -> Result<CancellationResult, ApplicationServiceError>;
    fn operation_status(
        &self,
        operation_id: OperationId,
    ) -> Result<OperationStatus, ApplicationServiceError>;
    /// Returns a bounded, recently-updated operation list for TUI/WebUI
    /// dashboards and future CLI `op list`. Every service implementation
    /// must provide a real bounded view; an unavailable fallback belongs in
    /// the concrete implementation, not in the port contract.
    fn list_operations(&self) -> Result<OperationList, ApplicationServiceError>;
    /// Returns the current live kernel connection-detail slice, mediated by
    /// the daemon. The slice is a point-in-time read, not a subscription;
    /// continuous updates go through the watch stream.
    fn live_connections(&self) -> Result<Vec<LiveConnection>, ApplicationServiceError>;
    fn snapshot(&self) -> Result<PresentationSnapshot, ApplicationServiceError>;
    fn watch_after(
        &self,
        cursor: Option<EventCursor>,
    ) -> Result<ApplicationWatch, ApplicationServiceError>;
    /// Subscribes to live projection events for a continuous watch stream.
    fn subscribe_live(&self) -> tokio::sync::broadcast::Receiver<SequencedEvent>;
}

mod command_support;
pub(crate) mod results;
pub(crate) mod runtime_service;
pub(crate) mod shared;

pub use command_support::CommandSupportPolicy;
// P7:WallClock 受 orphan 规则锚定在本 crate(shared.rs 接缝注记),
// 经服务根对 caly-composition 公开。
pub use results::{ActorResultError, ActorResultOutcome};
pub use runtime_service::{
    DispatchOutcome, DispatchRejectReason, ProjectionService, RuntimeDispatchError, RuntimeService,
};
pub use shared::WallClock;
