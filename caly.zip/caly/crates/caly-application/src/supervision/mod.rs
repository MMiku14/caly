//! Runtime topology and stale-generation supervision rules.

mod topology;

pub use topology::{Component, DependencyEdge, TopologyError, default_topology, validate_topology};
