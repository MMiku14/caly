use std::collections::BTreeMap;

use caly_cap::{
    CapabilityDescriptor, CapabilityDomain, CapabilityKey, CapabilityState, Constraint,
    EvidenceRef, FallbackPolicy, SupportLevel,
};
use caly_ir::{CompiledArtifact, NativeConfigFormat, ResolvedProfile, StableBytes};
use caly_plan::{
    ApplyIssue, ApplyIssueLevel, ApplyPlan, ApplyPlanKind, BlobRef, CoreCall,
    CoreKind as PlanCoreKind, CoreSpec, DeployImpact, Durability, EffectPlan, EffectStep, FileMode,
    InstanceId, PlanId, PrivilegeSet, ProbeKind, ProbeSpec, SnapshotId,
};

use crate::adapter::{
    ApplyPlanningResult, CapabilitySet, CoreAdapter, CoreIdentity, CoreIssue, CoreKind, IssueLevel,
    NativeValidationReport,
};
use crate::native::{artifact_digest, stable_checksum_text};
use crate::runtime::{
    ControlPlane, CoreResourceSample, GroupRuntimeState, ProbePlane, RuntimeConnection,
    RuntimeDriver, RuntimeLogLine, RuntimeStatusView, TelemetryPlane, TrafficSample,
};

#[derive(Default)]
pub struct MockCoreAdapter;

impl CoreAdapter for MockCoreAdapter {
    fn inspect_binary(&self) -> Result<CoreIdentity, String> {
        Ok(CoreIdentity {
            kind: CoreKind::Mihomo,
            version: "0.0.0-mock".to_owned(),
            build: Some("skeleton".to_owned()),
            binary_digest: "mock-binary-digest".to_owned(),
        })
    }

    fn capability_set(&self, _identity: &CoreIdentity) -> Result<CapabilitySet, String> {
        Ok(CapabilitySet {
            descriptors: vec![
                capability(
                    "runtime.group.select",
                    "Mock runtime group select",
                    CapabilityDomain::Runtime,
                    SupportLevel::CalyManaged,
                    CapabilityState::SupportedExact,
                    vec![Constraint {
                        field: "transport".to_owned(),
                        expected: "ipc".to_owned(),
                    }],
                    Some(FallbackPolicy::UseNativeOnlyMode),
                    vec!["mock runtime selection capability".to_owned()],
                ),
                capability(
                    "dns.fake_ip",
                    "Mock Fake-IP",
                    CapabilityDomain::Dns,
                    SupportLevel::CalyManaged,
                    CapabilityState::SupportedExact,
                    vec![Constraint {
                        field: "mode".to_owned(),
                        expected: "fake-ip".to_owned(),
                    }],
                    None,
                    vec!["mock fake-ip capability".to_owned()],
                ),
                capability(
                    "network.tun",
                    "Mock TUN support",
                    CapabilityDomain::Tun,
                    SupportLevel::CalyManaged,
                    CapabilityState::SupportedExact,
                    Vec::new(),
                    None,
                    vec!["mock tun capability".to_owned()],
                ),
                capability(
                    "routing.rules",
                    "Mock rule routing",
                    CapabilityDomain::Routing,
                    SupportLevel::CalyManaged,
                    CapabilityState::SupportedExact,
                    Vec::new(),
                    None,
                    vec!["mock rule routing capability".to_owned()],
                ),
            ],
        })
    }

    fn preflight(
        &self,
        profile: &ResolvedProfile,
        capabilities: &CapabilitySet,
    ) -> Result<Vec<CoreIssue>, String> {
        let mut issues = vec![CoreIssue {
            level: if profile.nodes.is_empty() {
                IssueLevel::Warning
            } else {
                IssueLevel::Info
            },
            code: "MOCK_PREFLIGHT".to_owned(),
            summary: "mock adapter preflight executed".to_owned(),
        }];

        if profile.tun.as_ref().map(|tun| tun.enabled).unwrap_or(false)
            && !capabilities.supports_exact(&CapabilityKey("network.tun".to_owned()))
        {
            issues.push(CoreIssue {
                level: IssueLevel::Error,
                code: "MOCK_TUN_UNSUPPORTED".to_owned(),
                summary: "mock adapter cannot accept tun-enabled profile without network.tun"
                    .to_owned(),
            });
        }

        Ok(issues)
    }

    fn compile(
        &self,
        profile: &ResolvedProfile,
        _capabilities: &CapabilitySet,
    ) -> Result<CompiledArtifact, String> {
        let bytes = render_mock_config(profile);
        let mut annotations = build_common_annotations(profile);
        annotations.insert("core.kind".to_owned(), "mock".to_owned());
        // The identity a core is asked to confirm at apply time must be the artifact it
        // is actually handed (CoreSpec::config_digest), not a digest of the semantic
        // profile. Deriving it from the semantic digest made the ConfigIdentity probe
        // unanswerable: it could never match, for any plan.
        let artifact_digest = artifact_digest("mock", &bytes);
        annotations.insert("config.identity".to_owned(), artifact_digest.0.clone());

        Ok(CompiledArtifact {
            profile_id: profile.profile_id.clone(),
            target_core: CoreKind::Mihomo.target(),
            adapter_version: 1,
            artifact_digest,
            file_name_hint: format!("{}.mock.yaml", profile.profile_id.0),
            format: NativeConfigFormat::Yaml,
            entrypoint: "config.yaml".to_owned(),
            media_type: "application/x-yaml".to_owned(),
            bytes,
            annotations,
        })
    }

    fn validate_native(
        &self,
        artifact: &CompiledArtifact,
    ) -> Result<NativeValidationReport, String> {
        let body = String::from_utf8_lossy(&artifact.bytes.bytes);
        let accepted = !artifact.bytes.is_empty() && body.contains("profile:");
        let mut issues = vec![CoreIssue {
            level: IssueLevel::Info,
            code: "MOCK_VALIDATE_NATIVE".to_owned(),
            summary: format!("native validation inspected {}", artifact.file_name_hint),
        }];

        if !accepted {
            issues.push(CoreIssue {
                level: IssueLevel::Error,
                code: "MOCK_NATIVE_REJECTED".to_owned(),
                summary: "mock native validation rejected empty or malformed config".to_owned(),
            });
        }

        Ok(NativeValidationReport { accepted, issues })
    }

    fn plan_apply(
        &self,
        current: Option<&CompiledArtifact>,
        next: &CompiledArtifact,
    ) -> Result<ApplyPlanningResult, String> {
        let selection_only = current
            .map(|artifact| selection_only_change(artifact, next))
            .unwrap_or(false);
        let tun_enabled = annotation_bool(next, "tun.enabled");

        let kind = if current
            .map(|artifact| artifact.artifact_digest == next.artifact_digest)
            .unwrap_or(false)
        {
            ApplyPlanKind::Noop
        } else if selection_only {
            ApplyPlanKind::ApiPatch
        } else if current.is_some() && !tun_enabled {
            ApplyPlanKind::HotReload
        } else {
            ApplyPlanKind::Restart
        };

        let impact = match kind {
            ApplyPlanKind::Noop => DeployImpact::Noop,
            ApplyPlanKind::ApiPatch => DeployImpact::RuntimePatch,
            ApplyPlanKind::HotReload => DeployImpact::Reload,
            ApplyPlanKind::Restart => DeployImpact::Restart,
            ApplyPlanKind::RebuildAndRestart => DeployImpact::RebuildAndRestart,
        };
        let requires = required_privileges(tun_enabled, !matches!(kind, ApplyPlanKind::Noop));

        let reasons = plan_reasons(current, next, kind);
        let issues = vec![ApplyIssue {
            level: ApplyIssueLevel::Info,
            code: "MOCK_APPLY_PLAN".to_owned(),
            summary: format!("mock adapter selected {:?}", kind),
        }];

        let effect_plan = build_effect_plan("mock", kind, current, next, impact, requires.clone());

        Ok(ApplyPlanningResult {
            apply_plan: ApplyPlan {
                kind,
                impact,
                requires,
                issues,
                reasons,
            },
            effect_plan,
        })
    }

    fn runtime(&self) -> Result<Box<dyn RuntimeDriver>, String> {
        Ok(Box::new(MockRuntimeDriver::default()))
    }
}

fn capability(
    key: &str,
    title: &str,
    domain: CapabilityDomain,
    support_level: SupportLevel,
    state: CapabilityState,
    constraints: Vec<Constraint>,
    fallback: Option<FallbackPolicy>,
    notes: Vec<String>,
) -> CapabilityDescriptor {
    CapabilityDescriptor {
        key: CapabilityKey(key.to_owned()),
        title: title.to_owned(),
        domain,
        support_level,
        state,
        constraints,
        fallback,
        evidence_ref: EvidenceRef {
            fixture_id: Some(format!("capability-{key}")),
            golden_test_id: None,
            native_validation_test_id: None,
            runtime_test_id: None,
        },
        notes,
    }
}

fn render_mock_config(profile: &ResolvedProfile) -> StableBytes {
    let mut lines = vec![
        format!("profile: {}", profile.profile_id.0),
        format!("revision: {}", profile.revision_id.0),
        format!("target: {}", core_target_name(profile.core_target)),
        format!("routing_mode: {}", routing_mode_name(profile.routing_mode)),
        format!("semantic_digest: {}", profile.semantic_digest.0),
        format!("nodes: {}", profile.nodes.len()),
        format!("groups: {}", profile.groups.len()),
        format!("rules: {}", profile.rules.len()),
    ];

    if let Some(tun) = &profile.tun {
        lines.push(format!("tun.enabled: {}", tun.enabled));
        lines.push(format!("tun.auto_route: {}", tun.auto_route));
        lines.push(format!("tun.strict_route: {}", tun.strict_route));
    }

    for group in &profile.groups {
        let selected = group
            .selected
            .as_ref()
            .map(|node| node.0.clone())
            .unwrap_or_else(|| "none".to_owned());
        lines.push(format!("group.{}.selected: {}", group.id.0, selected));
    }

    StableBytes::new(lines.join("\n").into_bytes())
}

fn build_common_annotations(profile: &ResolvedProfile) -> BTreeMap<String, String> {
    let mut annotations = BTreeMap::new();
    annotations.insert(
        "semantic_digest".to_owned(),
        profile.semantic_digest.0.clone(),
    );
    annotations.insert(
        "routing.mode".to_owned(),
        routing_mode_name(profile.routing_mode).to_owned(),
    );
    annotations.insert(
        "tun.enabled".to_owned(),
        profile
            .tun
            .as_ref()
            .map(|tun| tun.enabled)
            .unwrap_or(false)
            .to_string(),
    );
    annotations.insert("node.count".to_owned(), profile.nodes.len().to_string());
    annotations.insert("group.count".to_owned(), profile.groups.len().to_string());
    annotations.insert("rule.count".to_owned(), profile.rules.len().to_string());
    annotations.insert("selection_digest".to_owned(), selection_digest(profile));
    annotations.insert("selections".to_owned(), selection_pairs(profile).join(","));
    annotations
}

fn selection_digest(profile: &ResolvedProfile) -> String {
    format!(
        "sel:{:016x}",
        stable_checksum_text(&selection_pairs(profile).join("|"))
    )
}

fn selection_pairs(profile: &ResolvedProfile) -> Vec<String> {
    profile
        .groups
        .iter()
        .map(|group| {
            format!(
                "{}={}",
                group.id.0,
                group
                    .selected
                    .as_ref()
                    .map(|node| node.0.clone())
                    .unwrap_or_else(|| "none".to_owned())
            )
        })
        .collect()
}

fn selection_only_change(current: &CompiledArtifact, next: &CompiledArtifact) -> bool {
    current.annotations.get("semantic_digest") == next.annotations.get("semantic_digest")
        && current.annotations.get("selection_digest") != next.annotations.get("selection_digest")
}

fn annotation_bool(artifact: &CompiledArtifact, key: &str) -> bool {
    artifact
        .annotations
        .get(key)
        .map(|value| value == "true")
        .unwrap_or(false)
}

fn required_privileges(tun_enabled: bool, process_control: bool) -> PrivilegeSet {
    PrivilegeSet {
        needs_admin: tun_enabled,
        needs_network_control: tun_enabled,
        needs_process_control: process_control,
        needs_secret_access: false,
    }
}

fn plan_reasons(
    current: Option<&CompiledArtifact>,
    next: &CompiledArtifact,
    kind: ApplyPlanKind,
) -> Vec<String> {
    let mut reasons = vec![format!(
        "target core={}",
        core_target_name(next.target_core)
    )];
    match current {
        None => reasons.push("no active compiled artifact exists yet".to_owned()),
        Some(previous) if previous.artifact_digest == next.artifact_digest => {
            reasons.push("compiled artifact digest is unchanged".to_owned())
        }
        Some(previous) if selection_only_change(previous, next) => {
            reasons.push("only runtime group selections changed".to_owned())
        }
        Some(_) => reasons.push("compiled artifact content changed".to_owned()),
    }

    if annotation_bool(next, "tun.enabled") {
        reasons.push("tun is enabled and implies network side effects".to_owned());
    }

    reasons.push(format!("selected apply plan kind={kind:?}"));
    reasons
}

fn build_effect_plan(
    prefix: &str,
    kind: ApplyPlanKind,
    current: Option<&CompiledArtifact>,
    next: &CompiledArtifact,
    impact: DeployImpact,
    requires: PrivilegeSet,
) -> Option<EffectPlan> {
    if matches!(kind, ApplyPlanKind::Noop) {
        return None;
    }

    let instance = InstanceId(format!("{prefix}-core-instance"));
    let snapshot = SnapshotId(format!("{prefix}-snapshot-{}", next.profile_id.0));
    let core_spec = CoreSpec {
        kind: PlanCoreKind::Mihomo,
        binary_digest: format!("{prefix}-binary"),
        config_digest: next.artifact_digest.0.clone(),
    };
    let blob = BlobRef {
        digest: next.artifact_digest.0.clone(),
        size_hint: Some(next.size_bytes() as u64),
    };

    let mut steps = vec![
        EffectStep::WriteObject {
            digest: next.artifact_digest.0.clone(),
            source: blob.clone(),
            durability: Durability::D2,
        },
        EffectStep::MaterializeArtifact {
            digest: next.artifact_digest.0.clone(),
            at: format!("runtime/{}/{}", next.profile_id.0, next.entrypoint),
            mode: FileMode::ReadOnlyArtifact,
        },
    ];

    match kind {
        ApplyPlanKind::ApiPatch => {
            for (group_id, node_id) in selection_delta(current, next) {
                steps.push(EffectStep::CoreApiCall {
                    instance: instance.clone(),
                    call: CoreCall::SelectProxy { group_id, node_id },
                });
            }
            steps.push(EffectStep::Probe {
                probe: ProbeSpec {
                    kind: ProbeKind::ConfigIdentity,
                    target: next.annotations.get("config.identity").cloned(),
                },
                deadline_ms: 1_500,
            });
            // Round 69: mirror of the adapters' identity/telemetry tail — the sim answers
            // with its own deterministic identity and (absent) counters.
            steps.push(EffectStep::Probe {
                probe: ProbeSpec {
                    kind: ProbeKind::CoreIdentity,
                    target: None,
                },
                deadline_ms: 1_500,
            });
            steps.push(EffectStep::Probe {
                probe: ProbeSpec {
                    kind: ProbeKind::TelemetryTraffic,
                    target: None,
                },
                deadline_ms: 1_500,
            });
        }
        ApplyPlanKind::HotReload => {
            steps.push(EffectStep::CoreApiCall {
                instance: instance.clone(),
                call: CoreCall::Reload,
            });
            steps.push(EffectStep::Probe {
                probe: ProbeSpec {
                    kind: ProbeKind::ApiReady,
                    target: None,
                },
                deadline_ms: 2_000,
            });
        }
        ApplyPlanKind::Restart | ApplyPlanKind::RebuildAndRestart => {
            if current.is_some() {
                steps.push(EffectStep::StopCore {
                    instance: instance.clone(),
                    grace_ms: 2_000,
                });
            }
            steps.push(EffectStep::SpawnCore {
                spec: core_spec.clone(),
            });
            steps.push(EffectStep::Probe {
                probe: ProbeSpec {
                    kind: ProbeKind::ApiReady,
                    target: None,
                },
                deadline_ms: 3_000,
            });
            steps.push(EffectStep::Probe {
                probe: ProbeSpec {
                    kind: ProbeKind::InboundListening,
                    target: None,
                },
                deadline_ms: 3_000,
            });
            // Round 69: mirror of the adapters' identity/telemetry tail (see the ApiPatch
            // arm above for the comment).
            steps.push(EffectStep::Probe {
                probe: ProbeSpec {
                    kind: ProbeKind::CoreIdentity,
                    target: None,
                },
                deadline_ms: 3_000,
            });
            steps.push(EffectStep::Probe {
                probe: ProbeSpec {
                    kind: ProbeKind::TelemetryTraffic,
                    target: None,
                },
                deadline_ms: 3_000,
            });
        }
        ApplyPlanKind::Noop => {}
    }

    steps.push(EffectStep::MarkSnapshot {
        snapshot_id: snapshot,
    });
    steps.push(EffectStep::CommitRevision { revision: 1 });

    let compensations = if current.is_some() {
        vec![EffectStep::CoreApiCall {
            instance,
            call: CoreCall::Reload,
        }]
    } else {
        Vec::new()
    };

    Some(EffectPlan {
        id: PlanId(format!("{prefix}-effect-plan-{}", next.profile_id.0)),
        steps,
        compensations,
        requires,
        impact,
    })
}

fn selection_delta(
    current: Option<&CompiledArtifact>,
    next: &CompiledArtifact,
) -> Vec<(String, String)> {
    let current_pairs = current
        .and_then(|artifact| artifact.annotations.get("selections"))
        .map(|value| parse_selection_pairs(value))
        .unwrap_or_default();
    let next_pairs = next
        .annotations
        .get("selections")
        .map(|value| parse_selection_pairs(value))
        .unwrap_or_default();

    next_pairs
        .into_iter()
        .filter(|(group_id, node_id)| current_pairs.get(group_id) != Some(node_id))
        .collect()
}

fn parse_selection_pairs(value: &str) -> BTreeMap<String, String> {
    let mut pairs = BTreeMap::new();
    for entry in value.split(',') {
        if entry.is_empty() {
            continue;
        }
        let mut parts = entry.splitn(2, '=');
        let Some(group_id) = parts.next() else {
            continue;
        };
        let Some(node_id) = parts.next() else {
            continue;
        };
        pairs.insert(group_id.to_owned(), node_id.to_owned());
    }
    pairs
}

fn core_target_name(target: caly_ir::CoreTarget) -> &'static str {
    match target {
        caly_ir::CoreTarget::Mihomo => "mihomo",
        caly_ir::CoreTarget::SingBox => "sing-box",
        caly_ir::CoreTarget::Auto => "auto",
    }
}

fn routing_mode_name(mode: caly_ir::RoutingMode) -> &'static str {
    match mode {
        caly_ir::RoutingMode::Rule => "rule",
        caly_ir::RoutingMode::Global => "global",
        caly_ir::RoutingMode::Direct => "direct",
    }
}

#[derive(Default)]
pub struct MockRuntimeDriver {
    control: MockControlPlane,
    telemetry: MockTelemetryPlane,
    probe: MockProbePlane,
}

impl RuntimeDriver for MockRuntimeDriver {
    fn control(&self) -> &dyn ControlPlane {
        &self.control
    }

    fn telemetry(&self) -> &dyn TelemetryPlane {
        &self.telemetry
    }

    fn probe(&self) -> &dyn ProbePlane {
        &self.probe
    }
}

#[derive(Default)]
pub struct MockControlPlane;

impl ControlPlane for MockControlPlane {
    fn status(&self) -> Result<RuntimeStatusView, String> {
        Ok(RuntimeStatusView {
            running: true,
            healthy: true,
            config_identity: Some("mock-config".to_owned()),
            summary: "mock runtime status".to_owned(),
        })
    }

    fn reload(&self) -> Result<(), String> {
        Ok(())
    }

    fn select_proxy(&self, _group_label: &str, _node_label: &str) -> Result<(), String> {
        Ok(())
    }

    fn close_connection(&self, _connection_id: &str) -> Result<(), String> {
        Ok(())
    }
}

#[derive(Default)]
pub struct MockTelemetryPlane;

impl TelemetryPlane for MockTelemetryPlane {
    fn traffic(&self) -> Result<Vec<TrafficSample>, String> {
        Ok(vec![TrafficSample {
            upload_bytes_per_sec: 0,
            download_bytes_per_sec: 0,
            uploaded_total: 0,
            downloaded_total: 0,
            timestamp_ms: 0,
        }])
    }

    fn connections(&self) -> Result<Vec<RuntimeConnection>, String> {
        Ok(Vec::new())
    }

    fn groups(&self) -> Result<Vec<GroupRuntimeState>, String> {
        Ok(Vec::new())
    }

    fn logs(&self) -> Result<Vec<RuntimeLogLine>, String> {
        Ok(Vec::new())
    }

    fn resource(&self) -> Result<Vec<CoreResourceSample>, String> {
        Ok(Vec::new())
    }
}

#[derive(Default)]
pub struct MockProbePlane;

impl ProbePlane for MockProbePlane {
    fn api_ready(&self) -> Result<bool, String> {
        Ok(true)
    }

    fn config_identity(&self) -> Result<Option<String>, String> {
        Ok(Some("mock-config".to_owned()))
    }

    fn inbound_listening(&self) -> Result<bool, String> {
        Ok(true)
    }
}
