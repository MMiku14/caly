//! Shared golden-snapshot harness for the renderer test binaries.
//!
//! Convergence: `render_golden.rs` (sing-box) and `mihomo_golden.rs` ran
//! byte-identical bless/compare loops; one copy removes the drift risk where
//! a harness fix lands in one binary and silently misses the other. Each
//! binary keeps only its case builders plus `cases()`.

use std::path::PathBuf;

pub fn golden_dir() -> PathBuf {
    PathBuf::from(env!("CARGO_MANIFEST_DIR")).join("tests/golden")
}

pub fn push(out: &mut Vec<(String, Vec<u8>)>, name: &str, bytes: impl Into<Vec<u8>>) {
    out.push((name.to_owned(), bytes.into()));
}

/// Blesses (`CALY_GOLDEN_BLESS=1`) or byte-compares every rendered case
/// against `tests/golden/<case>.snap`, failing with the full case list.
pub fn run_cases(cases: &[(String, Vec<u8>)]) {
    let bless = std::env::var_os("CALY_GOLDEN_BLESS").is_some();
    let dir = golden_dir();
    if bless {
        std::fs::create_dir_all(&dir).unwrap();
    }
    let mut failures: Vec<String> = Vec::new();
    for (name, actual) in cases {
        let path = dir.join(format!("{name}.snap"));
        if bless {
            std::fs::write(&path, actual).unwrap();
            continue;
        }
        match std::fs::read(&path) {
            Ok(expected) if expected == *actual => {}
            Ok(expected) => failures.push(format!(
                "{name}: golden {} bytes != rendered {} bytes",
                expected.len(),
                actual.len()
            )),
            Err(_) => failures.push(format!("{name}: no snapshot (run with CALY_GOLDEN_BLESS=1)")),
        }
    }
    assert!(
        failures.is_empty(),
        "golden mismatch ({} case(s)):\n{}",
        failures.len(),
        failures.join("\n")
    );
}
