//! Golden byte snapshots for the Mihomo YAML renderers in `caly-coreconf`.
//!
//! P3: mirrors `render_golden.rs` (which only pinned sing-box). The Mihomo
//! emitter is hand-rolled strings, so byte-pinning matters more here, not
//! less — the P1 uuid-injection fix is pinned by `mnode-hostile-uuid`.
//!
//! Each case renders through the public API and compares the exact output
//! bytes against `tests/golden/<case>.snap`. Regenerate after an intentional
//! renderer change with `CALY_GOLDEN_BLESS=1 cargo test -p caly-coreconf
//! --test mihomo_golden`, then review the fixture diff.

#![allow(clippy::unwrap_used, clippy::expect_used, clippy::panic)] // #53: golden harness asserts on render success

mod common;

use common::{push, run_cases};

use caly_coreconf::mihomo::proxy_sections::{
    MihomoProxyTag, render_proxy_sections_from,
    render_proxy_sections_with_rules_and_providers,
};
use caly_coreconf::mihomo::render::proxy_to_entry;
use caly_coreconf::mihomo::{MihomoConfigRenderer, MihomoConfigSettings};
use caly_domain::SubscriptionId;
use caly_subscription::parse_any_proxy_uri;

/// Renders every case (name, exact bytes). Error variants are folded into
/// text so unsupported-input cases still snapshot deterministically.
fn cases() -> Vec<(String, Vec<u8>)> {
    let mut out: Vec<(String, Vec<u8>)> = Vec::new();
    mnode_cases(&mut out);
    section_cases(&mut out);
    document_cases(&mut out);
    out
}

// ---------------------------------------------------------------- nodes

fn mnode(out: &mut Vec<(String, Vec<u8>)>, name: &str, tag: &str, uri: &str) {
    let parsed = parse_any_proxy_uri(uri, SubscriptionId::from_bytes([9; 16]));
    let bytes = match parsed {
        Ok(node) => {
            let rendered = MihomoProxyTag::new(tag.to_owned())
                .map_err(|error| format!("{error:?}"))
                .and_then(|tag| proxy_to_entry(&node, tag).map_err(|error| format!("{error:?}")));
            match rendered {
                Ok(entry) => entry.yaml.as_str().as_bytes().to_vec(),
                Err(error) => format!("ERR {error}").into_bytes(),
            }
        }
        Err(error) => format!("PARSE-ERR {error:?}").into_bytes(),
    };
    push(out, &format!("mnode-{name}"), bytes);
}

fn mnode_cases(out: &mut Vec<(String, Vec<u8>)>) {
    mnode(
        out,
        "vless-reality-ws",
        "reality-ws",
        "vless://a5ea9247-79f3-4655-aece-3fb51e1e669e@example.com:443?security=reality&flow=xtls-rprx-vision&sni=example.com&fp=chrome&pbk=zT7a-PnmIWP4c-G1EDUT3KZ7URi1kc8EppAWPr3h5lk&sid=afeed89ae23b36ed&type=ws&path=%2Fstream&host=example.com#reality-ws",
    );
    mnode(
        out,
        "vless-tls",
        "vless-tls",
        "vless://a5ea9247-79f3-4655-aece-3fb51e1e669e@example.com:443?security=tls#vless-tls",
    );
    mnode(
        out,
        "vmess-ws",
        "vmess-node",
        "vmess://eyJhZGQiOiJleGFtcGxlLmNvbSIsInBvcnQiOjQ0MywiaWQiOiI2YTg5YTIxNS0yMmJmLTRiZDctOTY0Mi1iOTViMmUwOTU4M2EiLCJhaWQiOjAsIm5ldCI6IndzIiwicGF0aCI6Ii9zIiwiaG9zdCI6ImV4YW1wbGUuY29tIiwidGxzIjoidGxzIiwicHMiOiJ2bWVzLW5vZGUifQ==",
    );
    mnode(
        out,
        "trojan-ws",
        "trojan-ws",
        "trojan://secret-pass@example.com:443?security=tls&sni=example.com&type=ws&path=%2Fstream#trojan-ws",
    );
    mnode(
        out,
        "ss-chacha20",
        "ss-node",
        "ss://Y2hhY2hhMjAtaWV0Zi1wb2x5MTMwNTpzZWNyZXRwYXNz@example.com:8443#ss-node",
    );
    mnode(
        out,
        "ss-plugin",
        "ss-plug",
        "ss://bm9uZTpwYXNz@1.2.3.4:443?plugin=v2ray-plugin%3Bmode%3Dwebsocket#ss-plug",
    );
    mnode(
        out,
        "hysteria2-obfs",
        "hy2",
        "hysteria2://secret@example.com:443?security=tls&sni=example.com&obfs=salamander&obfs-password=obfspass&upmbps=50&downmbps=100#hy2",
    );
    mnode(
        out,
        "tuic-bbr",
        "tuic",
        "tuic://2DD61D93-75D8-4DA4-AC0E-6AECE7EAC365:hello@example.com:443?congestion_control=bbr#tuic",
    );
    mnode(
        out,
        "vless-grpc",
        "grpc",
        "vless://a5ea9247-79f3-4655-aece-3fb51e1e669e@example.com:443?security=tls&sni=example.com&type=grpc&serviceName=grpc-svc#grpc",
    );
    mnode(
        out,
        "http",
        "http-node",
        "http://user:pass@example.com:8080#http-node",
    );
    mnode(
        out,
        "socks5",
        "socks-node",
        "socks5://user:pass@example.com:1080#socks-node",
    );
    // No Mihomo representation: pins the P2 skip-reason behavior at the
    // renderer boundary (the compose layer turns this into a skip + warn).
    mnode(
        out,
        "wireguard-unsupported",
        "wg",
        "wireguard://abcdef0123456789abcdef0123456789@example.com:51820?private-key=BBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBB=&public-key=AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA=#wg",
    );
    // P1 byte-pin: the smuggled newline must stay escaped inside the
    // double-quoted scalar, never become a second YAML line.
    mnode(
        out,
        "hostile-uuid",
        "evil",
        "vless://aaa%0Ainjected: true@example.com:443#evil",
    );
}

// ---------------------------------------------------------------- sections

fn section_entries() -> Vec<(String, String)> {
    let id = SubscriptionId::from_bytes([5; 16]);
    [
        ("trojan-ws", "trojan://secret-pass@example.com:443?security=tls&sni=example.com&type=ws&path=%2Fstream#trojan-ws"),
        ("ss-aes", "ss://YWVzLTEyOC1nY206cGFzc3dvcmQ=@example.com:8388#ss-aes"),
    ]
    .into_iter()
    .map(|(tag, uri)| {
        let node = parse_any_proxy_uri(uri, id).unwrap();
        let entry = proxy_to_entry(&node, MihomoProxyTag::new(tag.to_owned()).unwrap()).unwrap();
        (tag.to_owned(), entry.yaml.as_str().to_owned())
    })
    .collect()
}

fn section_cases(out: &mut Vec<(String, Vec<u8>)>) {
    let entries = section_entries();
    let pairs: Vec<(&str, &str)> = entries
        .iter()
        .map(|(tag, yaml)| (tag.as_str(), yaml.as_str()))
        .collect();
    push(
        out,
        "msec-two-nodes",
        render_proxy_sections_from("AUTO", &pairs).into_bytes(),
    );

    let rules = [
        caly_domain::RoutingRule::from_clash_line("DOMAIN-SUFFIX,google.com,PROXY").unwrap(),
        caly_domain::RoutingRule::from_clash_line("GEOIP,CN,DIRECT").unwrap(),
        caly_domain::RoutingRule::from_clash_line("MATCH,AUTO").unwrap(),
    ];
    let providers = [caly_domain::RuleProvider {
        name: caly_domain::RuleProviderName::new("my-google".to_owned()).unwrap(),
        source: caly_domain::RuleProviderSource::Http {
            url: caly_domain::RuleText::new("https://example.com/g.yaml".to_owned()).unwrap(),
            interval_ms: 86_400_000,
        },
        behavior: caly_domain::RuleProviderBehavior::Domain,
        format: caly_domain::RuleProviderFormat::Source,
    }];
    push(
        out,
        "msec-rules-providers",
        render_proxy_sections_with_rules_and_providers("AUTO", &pairs, &rules, &providers)
            .into_bytes(),
    );
}

// ---------------------------------------------------------------- documents

fn mdoc(out: &mut Vec<(String, Vec<u8>)>, name: &str, settings: &MihomoConfigSettings) {
    let bytes = match MihomoConfigRenderer.render(settings) {
        Ok(bytes) => bytes.as_slice().to_vec(),
        Err(error) => format!("ERR {error}").into_bytes(),
    };
    push(out, &format!("mdoc-{name}"), bytes);
}

fn document_cases(out: &mut Vec<(String, Vec<u8>)>) {
    mdoc(out, "base", &MihomoConfigSettings::default());
    let entries = section_entries();
    let pairs: Vec<(&str, &str)> = entries
        .iter()
        .map(|(tag, yaml)| (tag.as_str(), yaml.as_str()))
        .collect();
    let section = render_proxy_sections_from("AUTO", &pairs);
    let dns = caly_dns::DnsSettingsBuilder::new()
        .enabled(true)
        .push_nameserver("8.8.8.8")
        .unwrap()
        .build()
        .unwrap()
        .unwrap();
    mdoc(
        out,
        "full",
        &MihomoConfigSettings {
            mixed_port: 7890,
            external_controller_port: 9090,
            allow_lan: true,
            bind_address: "*".to_owned(),
            log_level: "warning".to_owned(),
            dns: Some(dns),
            secret: Some("topsecret".to_owned()),
            proxies: Some(caly_domain::BoundedText::new(section).unwrap()),
            tun: Some(
                caly_domain::TunConfig::new(caly_domain::TunStack::System, true, true, 1_400)
                    .unwrap(),
            ),
            transparent_port: 7892,
            transparent_tproxy: true,
            sniffer: None,
            mode: caly_domain::ProxyMode::Rule,
        },
    );
}

// ---------------------------------------------------------------- harness

#[test]
fn rendered_bytes_match_the_golden_snapshots() {
    run_cases(&cases());
}
