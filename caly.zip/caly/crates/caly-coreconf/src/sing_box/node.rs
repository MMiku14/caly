//! sing-box node outbound rendering: protocol fields, TLS, reality, transport.
//! Typed-model form (P3b): each protocol outbound is a serde struct; field
//! declaration order is alphabetical, matching the byte order the pre-typed
//! `serde_json::Value` (BTreeMap) assembly produced, so re-serialization is
//! byte-identical for every representable node.
//!
//! Kept separate from `document.rs` (document assembly) so each file stays
//! within the project's line limits.

use caly_domain::{DialableNode, Protocol};
use serde::Serialize;
use serde_json::Value;

use super::SingBoxOutboundError;

pub fn node_to_json(node: &DialableNode) -> Result<Value, SingBoxOutboundError> {
    let outbound = node_outbound(node)?;
    serde_json::to_value(&outbound).map_err(|_| SingBoxOutboundError::Serialization)
}

/// Renders one node as a compact JSON object string (tag `proxy-<id>`), the
/// per-node form stored by the shared registry so config backends can rebuild
/// the outbounds array without re-parsing the subscription body.
pub fn node_to_json_string(node: &DialableNode) -> Result<String, SingBoxOutboundError> {
    serde_json::to_string(&node_outbound(node)?).map_err(|_| SingBoxOutboundError::Serialization)
}

/// Builds the typed outbound for one dialable node.
fn node_outbound(node: &DialableNode) -> Result<NodeOutbound, SingBoxOutboundError> {
    let base = NodeBase::new(node);
    match node.protocol() {
        Protocol::Vless { user_id, flow } => {
            Ok(node_outbound_vless(node, base, user_id, flow.as_ref()))
        }
        Protocol::Trojan { password } => Ok(node_outbound_trojan(node, base, password)),
        Protocol::Vmess {
            user_id,
            alter_id,
            security,
        } => Ok(node_outbound_vmess(
            node, base, user_id, *alter_id, *security,
        )),
        Protocol::Shadowsocks {
            password,
            method,
            plugin,
        } => node_outbound_ss(base, *method, password, plugin.as_ref()),
        Protocol::Hysteria2 {
            password,
            up_mbps,
            down_mbps,
            obfuscation,
        } => Ok(node_outbound_hysteria2(
            node,
            base,
            password,
            obfuscation.as_ref(),
            *up_mbps,
            *down_mbps,
        )),
        Protocol::Tuic {
            user_id,
            password,
            congestion,
        } => Ok(node_outbound_tuic(
            node,
            base,
            user_id,
            password,
            *congestion,
        )),
        // Plain HTTP / socks5 proxies are first-class sing-box outbounds.
        Protocol::Http { username, password } => Ok(node_outbound_http(
            node,
            base,
            "http",
            username.as_ref(),
            password.as_ref(),
        )),
        Protocol::Socks5 { username, password } => Ok(node_outbound_http(
            node,
            base,
            "socks",
            username.as_ref(),
            password.as_ref(),
        )),
        Protocol::ShadowTls {
            password,
            version,
            sni,
        } => Ok(node_outbound_shadow_tls(
            node,
            base,
            password,
            *version,
            sni.as_ref(),
        )),
        Protocol::AnyTls { password, sni } => {
            Ok(node_outbound_any_tls(node, base, password, sni.as_ref()))
        }
        // sing-box 1.13 removed the legacy WireGuard outbound; the endpoint
        // form requires an address assignment that the node URI does not
        // carry. Fail closed instead of emitting a config sing-box rejects.
        Protocol::WireGuard { .. } => Err(SingBoxOutboundError::UnsupportedNode),
    }
}

/// Common identity fields shared by every outbound shape.
struct NodeBase {
    tag: String,
    server: String,
    server_port: u16,
}

impl NodeBase {
    fn new(node: &DialableNode) -> Self {
        Self {
            tag: format!("proxy-{}", caly_domain::to_hex(node.id().into_bytes())),
            server: node.endpoint().host().as_str().to_owned(),
            server_port: node.endpoint().port().get(),
        }
    }
}

fn node_outbound_vless(
    node: &DialableNode,
    base: NodeBase,
    user_id: &caly_domain::Credential,
    flow: Option<&caly_domain::ProtocolText>,
) -> NodeOutbound {
    NodeOutbound::Vless(Box::new(VlessOutbound {
        flow: flow.map(|flow| flow.as_str().to_owned()),
        server: base.server,
        server_port: base.server_port,
        tag: base.tag,
        tls: tls_json(node),
        transport: transport_json(node),
        kind: "vless",
        uuid: user_id.with_exposed(str::to_owned),
    }))
}

fn node_outbound_trojan(
    node: &DialableNode,
    base: NodeBase,
    password: &caly_domain::Credential,
) -> NodeOutbound {
    NodeOutbound::Trojan(TrojanOutbound {
        password: password.with_exposed(str::to_owned),
        server: base.server,
        server_port: base.server_port,
        tag: base.tag,
        tls: tls_json(node),
        transport: transport_json(node),
        kind: "trojan",
    })
}

fn node_outbound_vmess(
    node: &DialableNode,
    base: NodeBase,
    user_id: &caly_domain::Credential,
    alter_id: u16,
    security: caly_domain::VmessCipher,
) -> NodeOutbound {
    NodeOutbound::Vmess(Box::new(VmessOutbound {
        alter_id,
        security: crate::labels::vmess_cipher(security),
        server: base.server,
        server_port: base.server_port,
        tag: base.tag,
        tls: tls_json(node),
        transport: transport_json(node),
        kind: "vmess",
        uuid: user_id.with_exposed(str::to_owned),
    }))
}

fn node_outbound_hysteria2(
    node: &DialableNode,
    base: NodeBase,
    password: &caly_domain::Credential,
    obfuscation: Option<&caly_domain::Credential>,
    up_mbps: Option<u32>,
    down_mbps: Option<u32>,
) -> NodeOutbound {
    NodeOutbound::Hysteria2(Box::new(Hysteria2Outbound {
        down_mbps,
        obfs: obfuscation.map(|obfs| ObfsJson {
            password: obfs.with_exposed(str::to_owned),
            kind: "salamander",
        }),
        password: password.with_exposed(str::to_owned),
        server: base.server,
        server_port: base.server_port,
        tag: base.tag,
        // hysteria2 is TLS-only; sing-box rejects an outbound without a
        // `tls` block even when the URI carries no explicit SNI.
        tls: tls_or_host_fallback(node),
        kind: "hysteria2",
        up_mbps,
    }))
}

fn node_outbound_tuic(
    node: &DialableNode,
    base: NodeBase,
    user_id: &caly_domain::Credential,
    password: &caly_domain::Credential,
    congestion: caly_domain::CongestionControl,
) -> NodeOutbound {
    NodeOutbound::Tuic(Box::new(TuicOutbound {
        congestion_control: crate::labels::congestion_label(congestion),
        password: password.with_exposed(str::to_owned),
        server: base.server,
        server_port: base.server_port,
        tag: base.tag,
        // tuic is TLS-only for the same reason as hysteria2.
        tls: tls_or_host_fallback(node),
        kind: "tuic",
        uuid: user_id.with_exposed(str::to_owned),
    }))
}

/// http / socks branch of [`node_outbound`] (extracted for the
/// 100-line budget): plain proxy outbounds with optional credentials.
fn node_outbound_http(
    node: &DialableNode,
    base: NodeBase,
    kind: &'static str,
    username: Option<&caly_domain::Credential>,
    password: Option<&caly_domain::Credential>,
) -> NodeOutbound {
    // O5: reuse the base every other arm shares — the pre-convergence shape
    // recomputed tag/server/port here AND dropped the already-built base.
    let username = username.map(|cred| cred.with_exposed(str::to_owned));
    let password = password.map(|cred| cred.with_exposed(str::to_owned));
    // `https://` proxies carry a TLS config in the node; dropping it
    // would silently downgrade them to plaintext (agent audit 2026-08-12).
    let tls = tls_json(node);
    if kind == "http" {
        NodeOutbound::Http(HttpOutbound {
            password,
            server: base.server,
            server_port: base.server_port,
            tag: base.tag,
            tls,
            username,
            kind,
        })
    } else {
        NodeOutbound::Socks(SocksOutbound {
            password,
            server: base.server,
            server_port: base.server_port,
            tag: base.tag,
            tls,
            udp_over_tcp: true,
            username,
            kind,
        })
    }
}

/// Shadowsocks branch of [`node_outbound`] (extracted for the
/// 100-line budget): sing-box has no ss plugin (obfs-local /
/// v2ray-plugin) support, so a plugin node is rejected explicitly —
/// rendering a plain ss outbound would emit a dead proxy that looks
/// healthy.
fn node_outbound_ss(
    base: NodeBase,
    method: caly_domain::ShadowsocksCipher,
    password: &caly_domain::Credential,
    plugin: Option<&caly_domain::ShadowsocksPlugin>,
) -> Result<NodeOutbound, SingBoxOutboundError> {
    if plugin.is_some() {
        return Err(SingBoxOutboundError::UnsupportedNode);
    }
    let Some(label) =
        crate::labels::ss_cipher_supported(method).then(|| crate::labels::ss_cipher_label(method))
    else {
        return Err(SingBoxOutboundError::UnsupportedNode);
    };
    // O5: reuse the shared base (see node_outbound_http).
    Ok(NodeOutbound::Shadowsocks(ShadowsocksOutbound {
        method: label,
        password: password.with_exposed(str::to_owned),
        server: base.server,
        server_port: base.server_port,
        tag: base.tag,
        kind: "shadowsocks",
    }))
}

/// One sing-box outbound (per-protocol shapes; `type` discriminates).
#[derive(Clone, Debug, Serialize)]
#[serde(untagged)]
pub(crate) enum NodeOutbound {
    Vless(Box<VlessOutbound>),
    Trojan(TrojanOutbound),
    Vmess(Box<VmessOutbound>),
    Shadowsocks(ShadowsocksOutbound),
    Hysteria2(Box<Hysteria2Outbound>),
    Tuic(Box<TuicOutbound>),
    ShadowTls(Box<ShadowTlsOutbound>),
    AnyTls(Box<AnyTlsOutbound>),
    Http(HttpOutbound),
    Socks(SocksOutbound),
}

/// `vless` outbound (uuid, optional XTLS flow, TLS, transport).
#[derive(Clone, Debug, Serialize)]
pub(crate) struct VlessOutbound {
    #[serde(skip_serializing_if = "Option::is_none")]
    flow: Option<String>,
    server: String,
    server_port: u16,
    tag: String,
    #[serde(skip_serializing_if = "Option::is_none")]
    tls: Option<TlsJson>,
    #[serde(skip_serializing_if = "Option::is_none")]
    transport: Option<TransportJson>,
    #[serde(rename = "type")]
    kind: &'static str,
    uuid: String,
}

/// `trojan` outbound (password, TLS, transport).
#[derive(Clone, Debug, Serialize)]
pub(crate) struct TrojanOutbound {
    password: String,
    server: String,
    server_port: u16,
    tag: String,
    #[serde(skip_serializing_if = "Option::is_none")]
    tls: Option<TlsJson>,
    #[serde(skip_serializing_if = "Option::is_none")]
    transport: Option<TransportJson>,
    #[serde(rename = "type")]
    kind: &'static str,
}

/// `vmess` outbound (uuid, alterId, security, TLS, transport).
#[derive(Clone, Debug, Serialize)]
pub(crate) struct VmessOutbound {
    alter_id: u16,
    security: &'static str,
    server: String,
    server_port: u16,
    tag: String,
    #[serde(skip_serializing_if = "Option::is_none")]
    tls: Option<TlsJson>,
    #[serde(skip_serializing_if = "Option::is_none")]
    transport: Option<TransportJson>,
    #[serde(rename = "type")]
    kind: &'static str,
    uuid: String,
}

/// `shadowsocks` outbound (method label, password).
#[derive(Clone, Debug, Serialize)]
pub(crate) struct ShadowsocksOutbound {
    method: &'static str,
    password: String,
    server: String,
    server_port: u16,
    tag: String,
    #[serde(rename = "type")]
    kind: &'static str,
}

/// `http` outbound (optional credentials, optional TLS for `https://`).
///
/// UDP cannot be carried by the `http` outbound at all: sing-box has no
/// UDP path for plain HTTP proxies (no `udp_over_tcp` field — that option
/// exists only on `socks`), so a route selecting it for UDP traffic fails
/// with "UDP is not supported by outbound". The renderer must keep http
/// nodes out of UDP routes instead (see the route-layer UDP fallback).
#[derive(Clone, Debug, Serialize)]
pub(crate) struct HttpOutbound {
    #[serde(skip_serializing_if = "Option::is_none")]
    password: Option<String>,
    server: String,
    server_port: u16,
    tag: String,
    #[serde(skip_serializing_if = "Option::is_none")]
    tls: Option<TlsJson>,
    #[serde(skip_serializing_if = "Option::is_none")]
    username: Option<String>,
    #[serde(rename = "type")]
    kind: &'static str,
}

/// `socks` outbound (optional credentials, optional TLS).
///
/// `udp_over_tcp` is always true: sing-box's socks outbound carries UDP
/// either over the service's UDP associate or over a TCP tunnel, and the
/// tunnel is the broadly supported fallback — without it, a route sending
/// UDP to a socks node whose server lacks UDP associate fails with "UDP is
/// not supported by outbound" (fallback audit). Note the http
/// outbound has NO such option; only socks gets the UDP path.
#[derive(Clone, Debug, Serialize)]
pub(crate) struct SocksOutbound {
    #[serde(skip_serializing_if = "Option::is_none")]
    password: Option<String>,
    server: String,
    server_port: u16,
    tag: String,
    #[serde(skip_serializing_if = "Option::is_none")]
    tls: Option<TlsJson>,
    udp_over_tcp: bool,
    #[serde(skip_serializing_if = "Option::is_none")]
    username: Option<String>,
    #[serde(rename = "type")]
    kind: &'static str,
}

/// `hysteria2` outbound (password, optional up/down and salamander
/// obfuscation; TLS is mandatory at the sing-box schema level).
#[derive(Clone, Debug, Serialize)]
pub(crate) struct Hysteria2Outbound {
    #[serde(skip_serializing_if = "Option::is_none")]
    down_mbps: Option<u32>,
    #[serde(skip_serializing_if = "Option::is_none")]
    obfs: Option<ObfsJson>,
    password: String,
    server: String,
    server_port: u16,
    tag: String,
    tls: TlsJson,
    #[serde(rename = "type")]
    kind: &'static str,
    #[serde(skip_serializing_if = "Option::is_none")]
    up_mbps: Option<u32>,
}

/// `tuic` outbound (uuid, password, congestion control; TLS mandatory).
/// `shadowtls` outbound (validated against sing-box 1.13.14).
#[derive(Clone, Debug, Serialize)]
pub(crate) struct ShadowTlsOutbound {
    password: String,
    server: String,
    server_port: u16,
    tag: String,
    tls: TlsJson,
    #[serde(rename = "type")]
    kind: &'static str,
    version: u8,
}

/// `anytls` outbound (validated against sing-box 1.13.14).
#[derive(Clone, Debug, Serialize)]
pub(crate) struct AnyTlsOutbound {
    password: String,
    server: String,
    server_port: u16,
    tag: String,
    tls: TlsJson,
    #[serde(rename = "type")]
    kind: &'static str,
}

#[derive(Clone, Debug, Serialize)]
pub(crate) struct TuicOutbound {
    congestion_control: &'static str,
    password: String,
    server: String,
    server_port: u16,
    tag: String,
    tls: TlsJson,
    #[serde(rename = "type")]
    kind: &'static str,
    uuid: String,
}

/// Salamander obfuscation block (hysteria2).
#[derive(Clone, Debug, Serialize)]
pub(crate) struct ObfsJson {
    password: String,
    #[serde(rename = "type")]
    kind: &'static str,
}

/// Emits sing-box `tls`/`reality` settings when the node carries TLS, or
/// `None` when it does not.
///
/// `enabled: true` is mandatory: without it this sing-box line constructs a
/// nil TLS config and every outbound TLS handshake panics with a nil pointer
/// dereference in `ClientHandshake` — the reason the same subscription works
/// in v2rayN (Xray) but every TLS node died in caly.
fn node_outbound_shadow_tls(
    node: &DialableNode,
    base: NodeBase,
    password: &caly_domain::Credential,
    version: u8,
    sni: Option<&caly_domain::ProtocolText>,
) -> NodeOutbound {
    NodeOutbound::ShadowTls(Box::new(ShadowTlsOutbound {
        password: password.with_exposed(str::to_owned),
        server: base.server,
        server_port: base.server_port,
        tag: base.tag,
        tls: tls_with_explicit_sni(node, sni),
        kind: "shadowtls",
        version,
    }))
}

fn node_outbound_any_tls(
    node: &DialableNode,
    base: NodeBase,
    password: &caly_domain::Credential,
    sni: Option<&caly_domain::ProtocolText>,
) -> NodeOutbound {
    NodeOutbound::AnyTls(Box::new(AnyTlsOutbound {
        password: password.with_exposed(str::to_owned),
        server: base.server,
        server_port: base.server_port,
        tag: base.tag,
        tls: tls_with_explicit_sni(node, sni),
        kind: "anytls",
    }))
}

/// ShadowTLS / AnyTLS are TLS-only and carry their own protocol-level SNI
/// parameter; that SNI wins over the generic TLS block when both exist.
fn tls_with_explicit_sni(
    node: &DialableNode,
    explicit_sni: Option<&caly_domain::ProtocolText>,
) -> TlsJson {
    let mut tls = tls_or_host_fallback(node);
    if let Some(sni) = explicit_sni {
        tls.server_name = Some(sni.as_str().to_owned());
    }
    tls
}

fn tls_json(node: &DialableNode) -> Option<TlsJson> {
    node.tls().map(tls_json_from)
}

/// The hysteria2/tuic fallback: emit a TLS block keyed by the URI SNI when
/// present, otherwise by the server host, so the outbound is never TLS-less.
fn tls_or_host_fallback(node: &DialableNode) -> TlsJson {
    tls_json(node).unwrap_or_else(|| TlsJson {
        enabled: true,
        insecure: None,
        reality: None,
        server_name: Some(node.endpoint().host().as_str().to_owned()),
        utls: None,
    })
}

/// sing-box `tls` block (`enabled`, optional SNI / insecure / uTLS / reality).
#[derive(Clone, Debug, Serialize)]
pub(crate) struct TlsJson {
    enabled: bool,
    #[serde(skip_serializing_if = "Option::is_none")]
    insecure: Option<bool>,
    #[serde(skip_serializing_if = "Option::is_none")]
    reality: Option<RealityJson>,
    #[serde(skip_serializing_if = "Option::is_none")]
    server_name: Option<String>,
    #[serde(skip_serializing_if = "Option::is_none")]
    utls: Option<UtlsJson>,
}

/// Reality handshake identity (public key, optional short id).
#[derive(Clone, Debug, Serialize)]
pub(crate) struct RealityJson {
    public_key: String,
    #[serde(skip_serializing_if = "Option::is_none")]
    short_id: Option<String>,
}

/// uTLS fingerprint block.
#[derive(Clone, Debug, Serialize)]
pub(crate) struct UtlsJson {
    enabled: bool,
    fingerprint: &'static str,
}

fn tls_json_from(tls: &caly_domain::TlsConfig) -> TlsJson {
    TlsJson {
        enabled: true,
        insecure: tls.allow_insecure().then_some(true),
        // Reality handshake identity must be preserved, otherwise the outbound
        // cannot complete the handshake even though TLS is enabled.
        reality: tls.reality().map(|reality| RealityJson {
            public_key: reality.public_key().with_exposed(str::to_owned),
            short_id: reality
                .short_id()
                .map(|sid| sid.with_exposed(str::to_owned)),
        }),
        server_name: tls.sni().map(|sni| sni.as_str().to_owned()),
        // Reality (and browser-mimicking TLS) handshakes need a uTLS fingerprint:
        // without it sing-box dials with the Go standard-library fingerprint,
        // which Reality servers reject (and this sing-box release panics on the
        // nil uTLS config). The `fp` URI parameter is preserved end-to-end;
        // unknown labels fall back to `random` so a weird subscription value
        // can never produce an invalid outbound.
        utls: tls.fingerprint().map(|fingerprint| UtlsJson {
            enabled: true,
            fingerprint: sing_box_fingerprint(fingerprint.as_str()),
        }),
    }
}

/// Emits sing-box `transport` settings when the node uses a pluggable framing.
fn transport_json(node: &DialableNode) -> Option<TransportJson> {
    match node.transport()? {
        caly_domain::Transport::Tcp => None,
        caly_domain::Transport::WebSocket {
            path,
            host,
            early_data,
        } => Some(TransportJson::WebSocket(WebSocketTransport {
            early_data_header_name: early_data
                .as_ref()
                .map(|early| early.header_name().as_str().to_owned()),
            headers: host.as_ref().map(|host| WsHeadersJson {
                host: host.as_str().to_owned(),
            }),
            // sing-box understands Xray early data natively; dropping it here
            // would silently break the 0-RTT handshake the subscription
            // advertised (audit #64).
            max_early_data: early_data
                .as_ref()
                .map(caly_domain::WebSocketEarlyData::max_bytes),
            path: path.as_str().to_owned(),
            kind: "ws",
        })),
        caly_domain::Transport::Grpc { service_name } => Some(TransportJson::Grpc(GrpcTransport {
            service_name: service_name.as_str().to_owned(),
            kind: "grpc",
        })),
        caly_domain::Transport::Http2 { path, hosts } => {
            Some(TransportJson::HttpUpgrade(HttpUpgradeTransport {
                host: hosts.iter().next().map(|host| host.as_str().to_owned()),
                path: path.as_str().to_owned(),
                kind: "httpupgrade",
            }))
        }
        caly_domain::Transport::Quic => Some(TransportJson::Quic(QuicTransport { kind: "quic" })),
    }
}

/// sing-box transport block (ws/grpc/httpupgrade/quic shapes).
#[derive(Clone, Debug, Serialize)]
#[serde(untagged)]
pub(crate) enum TransportJson {
    WebSocket(WebSocketTransport),
    Grpc(GrpcTransport),
    HttpUpgrade(HttpUpgradeTransport),
    Quic(QuicTransport),
}

/// `ws` transport (path, optional Host header, optional Xray early data).
#[derive(Clone, Debug, Serialize)]
pub(crate) struct WebSocketTransport {
    #[serde(skip_serializing_if = "Option::is_none")]
    early_data_header_name: Option<String>,
    #[serde(skip_serializing_if = "Option::is_none")]
    headers: Option<WsHeadersJson>,
    #[serde(skip_serializing_if = "Option::is_none")]
    max_early_data: Option<u32>,
    path: String,
    #[serde(rename = "type")]
    kind: &'static str,
}

/// WebSocket `headers` block (only `Host` is rendered).
#[derive(Clone, Debug, Serialize)]
pub(crate) struct WsHeadersJson {
    #[serde(rename = "Host")]
    host: String,
}

/// `grpc` transport.
#[derive(Clone, Debug, Serialize)]
pub(crate) struct GrpcTransport {
    service_name: String,
    #[serde(rename = "type")]
    kind: &'static str,
}

/// `httpupgrade` transport (sing-box's name for HTTP/2 framing).
#[derive(Clone, Debug, Serialize)]
pub(crate) struct HttpUpgradeTransport {
    #[serde(skip_serializing_if = "Option::is_none")]
    host: Option<String>,
    path: String,
    #[serde(rename = "type")]
    kind: &'static str,
}

/// `quic` transport (marker block).
#[derive(Clone, Debug, Serialize)]
pub(crate) struct QuicTransport {
    #[serde(rename = "type")]
    kind: &'static str,
}

/// Maps a subscription fingerprint label onto the sing-box uTLS enum.
/// Known labels pass through; anything unknown falls back to `random` so an
/// exotic subscription value can never yield an invalid outbound.
fn sing_box_fingerprint(label: &str) -> &'static str {
    match label {
        "chrome" => "chrome",
        "firefox" => "firefox",
        "safari" => "safari",
        "ios" => "ios",
        "edge" => "edge",
        "random" => "random",
        "randomized" => "randomized",
        _ => "random",
    }
}

#[cfg(test)]
mod tests;

#[cfg(test)]
mod tls_enabled_tests;
