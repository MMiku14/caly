//! Rich Mihomo Clash-compatible API adapters (proxy groups, connections,
//! traffic). Kept separate from the minimal HTTP transport in `http.rs` so
//! each file stays within the project's line limits.

use std::{io::Read, time::Duration};

use crate::ports::{ConnectionSummary, KernelFailure, ProxyGroup};

use super::http::MihomoHttpControl;

impl MihomoHttpControl {
    /// Lists proxy groups and their current selection from `GET /proxies`.
    pub fn list_proxy_groups(&self, timeout: Duration) -> Result<Vec<ProxyGroup>, KernelFailure> {
        let body = self.request("/proxies", timeout)?;
        let json = super::http::response_json(&body)?;
        let Some(proxies) = json.get("proxies").and_then(serde_json::Value::as_object) else {
            return Ok(Vec::new());
        };
        let mut groups = Vec::new();
        for (name, value) in proxies {
            let is_group = matches!(
                value.get("type").and_then(serde_json::Value::as_str),
                Some("Selector" | "URLTest" | "Fallback" | "LoadBalance")
            );
            if !is_group {
                continue;
            }
            let selected = value
                .get("now")
                .and_then(serde_json::Value::as_str)
                .map(str::to_owned);
            groups.push(ProxyGroup {
                name: name.clone(),
                selected,
            });
        }
        Ok(groups)
    }

    /// Summarizes active connections from `GET /connections`.
    pub fn connection_summary(
        &self,
        timeout: Duration,
    ) -> Result<ConnectionSummary, KernelFailure> {
        let body = self.request("/connections", timeout)?;
        let json = super::http::response_json(&body)?;
        let Some(connections) = json
            .get("connections")
            .and_then(serde_json::Value::as_array)
        else {
            return Ok(ConnectionSummary {
                active: 0,
                download_bytes: 0,
                upload_bytes: 0,
            });
        };
        let mut active = 0_u32;
        let mut download = 0_u64;
        let mut upload = 0_u64;
        for connection in connections {
            let uploaded = numeric(connection, "upload");
            let downloaded = numeric(connection, "download");
            upload = upload.saturating_add(uploaded);
            download = download.saturating_add(downloaded);
            if downloaded > 0 {
                active = active.saturating_add(1);
            }
        }
        Ok(ConnectionSummary {
            active,
            download_bytes: download,
            upload_bytes: upload,
        })
    }

    /// Returns cumulative (download, upload) bytes from `GET /traffic`.
    ///
    /// Mihomo's `/traffic` endpoint is an SSE stream, so we read only the first
    /// frame (a JSON snapshot) and close the connection instead of draining to
    /// EOF (which would block forever).
    pub fn traffic_bytes(&self, timeout: Duration) -> Result<(u64, u64), KernelFailure> {
        let address = self.resolve_address()?;
        let mut stream = MihomoHttpControl::connect(address, timeout)?;
        self.write_request(&mut stream, "GET", "/traffic", "")?;
        let mut buffer = [0_u8; 4 * 1_024];
        let read = stream.read(&mut buffer).map_err(|error| {
            crate::common::failure_with_kind(
                crate::ports::KernelFailureKind::ApiUnavailable,
                &format!("cannot read Mihomo traffic snapshot: {error}"),
                "inspect Mihomo controller health",
            )
        })?;
        let text = core::str::from_utf8(&buffer[..read]).unwrap_or("");
        parse_traffic_frame(text)
    }

    /// Tests the latency of a named proxy via `GET /proxies/{name}/delay`.
    ///
    /// The endpoint probes a fixed `generate_204` URL and returns `{"delay":n}`
    /// on success; a non-2xx status (e.g. the target host is unreachable) is a
    /// valid HTTP outcome and maps to `Ok(None)` rather than a transport error.
    pub fn probe_delay(
        &self,
        name: &str,
        url: &str,
        timeout: Duration,
    ) -> Result<Option<u32>, KernelFailure> {
        // The kernel-side probe timeout follows the caller's budget (bounded)
        // so slow-but-reachable nodes are not missed by a hardcoded 3s probe.
        let delay_timeout_ms = u64::from(timeout.as_millis().clamp(100, 15_000) as u16);
        let encoded =
            percent_encoding::utf8_percent_encode(name, percent_encoding::NON_ALPHANUMERIC);
        // The probe URL must be percent-encoded: sing-box's Clash API rejects a
        // raw `://` in the query ("Body invalid") while the encoded form works.
        let encoded_url =
            percent_encoding::utf8_percent_encode(url, percent_encoding::NON_ALPHANUMERIC);
        let path = format!("/proxies/{encoded}/delay?url={encoded_url}&timeout={delay_timeout_ms}");
        let address = self.resolve_address()?;
        // Keep the socket timeout comfortably above the probe timeout so a slow
        // target yields a 503 response (mapped to Ok(None)) rather than a socket
        // read timeout (mapped to Err).
        let socket_timeout = timeout.saturating_add(Duration::from_secs(2));
        let mut stream = MihomoHttpControl::connect(address, socket_timeout)?;
        self.write_request(&mut stream, "GET", &path, "")?;
        let mut buffer = Vec::new();
        stream.read_to_end(&mut buffer).map_err(|error| {
            // A read timeout while awaiting the probe result means the kernel
            // did not answer within the probe budget (sing-box can hang past
            // its own `timeout` param when the dial stalls); a reset/EOF at
            // this stage likewise means the probe did not complete. Both are
            // classified as DeadlineExceeded so callers can treat them like an
            // unreachable node instead of a controller transport failure
            // (connect-phase failures stay ApiUnavailable/loud).
            let kind = if matches!(
                error.kind(),
                std::io::ErrorKind::WouldBlock
                    | std::io::ErrorKind::TimedOut
                    | std::io::ErrorKind::ConnectionReset
                    | std::io::ErrorKind::ConnectionAborted
                    | std::io::ErrorKind::UnexpectedEof
                    | std::io::ErrorKind::BrokenPipe
            ) {
                crate::ports::KernelFailureKind::DeadlineExceeded
            } else {
                crate::ports::KernelFailureKind::ApiUnavailable
            };
            crate::common::failure_with_kind(
                kind,
                &format!("cannot read Mihomo delay response: {error}"),
                "inspect Mihomo controller health",
            )
        })?;
        let text = core::str::from_utf8(&buffer).unwrap_or("");
        let Some(status) = http_status_code(text) else {
            // No HTTP status line: the kernel closed the probe without
            // answering (sing-box drops the connection for outbounds whose
            // dial fails instantly). The probe did not complete — deadline,
            // not a decode/transport failure.
            return Err(crate::common::failure_with_kind(
                crate::ports::KernelFailureKind::DeadlineExceeded,
                "kernel closed the delay probe without an HTTP response",
                "inspect the kernel controller state",
            ));
        };
        if !(200..300).contains(&status) {
            // A 404 means the name is not configured in the running kernel
            // (a naming/apply mismatch on our side), which must be loud — never
            // silently reported as an "unreachable" node.
            if status == 404 {
                return Err(crate::common::failure_with_kind(
                    crate::ports::KernelFailureKind::ApiUnavailable,
                    &format!("proxy `{name}` is not configured in the running kernel config"),
                    "run `caly config apply` to publish subscription nodes, then retry",
                ));
            }
            // 5xx: the kernel ran the probe and the target did not answer
            // (e.g. 503/504 after the kernel-side timeout) — a genuine
            // unreachable outcome, not a transport failure.
            if (500..600).contains(&status) {
                return Ok(None);
            }
            return Err(crate::common::failure_with_kind(
                crate::ports::KernelFailureKind::ApiUnavailable,
                &format!("kernel delay endpoint returned HTTP {status} for proxy `{name}`"),
                "inspect the kernel controller state",
            ));
        }
        let json_text = match text.split_once("\r\n\r\n") {
            Some((_, body)) => body,
            None => text,
        };
        let json = serde_json::from_str::<serde_json::Value>(json_text).map_err(|_| {
            crate::common::failure_with_kind(
                crate::ports::KernelFailureKind::DecodeRejected,
                "Mihomo delay response is invalid JSON",
                "inspect controller output",
            )
        })?;
        Ok(json
            .get("delay")
            .and_then(numeric_value)
            .and_then(|value| u32::try_from(value).ok()))
    }

    /// Lists the names of real (dialable) proxies from `GET /proxies`,
    /// excluding selector groups and built-in special types — the input set
    /// for a full latency sweep (`delay --all`).
    /// Lists the names of real (dialable) proxies from `GET /proxies` — the
    /// input set for a full latency sweep (`delay --all`).
    ///
    /// Mihomo lists every proxy as a top-level entry; sing-box only exposes
    /// selectors plus special entries and keeps the nodes inside each
    /// selector's `all` list, so both shapes are collected and de-duplicated.
    pub fn list_proxy_names(&self, timeout: Duration) -> Result<Vec<String>, KernelFailure> {
        let body = self.request("/proxies", timeout)?;
        let json = super::http::response_json(&body)?;
        let Some(proxies) = json.get("proxies").and_then(serde_json::Value::as_object) else {
            return Ok(Vec::new());
        };
        let is_special = |proxy_type: &str| {
            matches!(
                proxy_type,
                "Selector"
                    | "URLTest"
                    | "Fallback"
                    | "LoadBalance"
                    | "Direct"
                    | "Reject"
                    | "Compatible"
                    | "Pass"
            )
        };
        let mut names = std::collections::BTreeSet::new();
        for (name, value) in proxies {
            let proxy_type = value
                .get("type")
                .and_then(serde_json::Value::as_str)
                .unwrap_or("");
            if matches!(
                proxy_type,
                "Selector" | "URLTest" | "Fallback" | "LoadBalance"
            ) {
                // sing-box exposes its nodes only as selector members.
                if let Some(all) = value.get("all").and_then(serde_json::Value::as_array) {
                    for member in all {
                        if let Some(tag) = member.as_str()
                            && !tag.is_empty()
                            && tag != "direct"
                        {
                            names.insert(tag.to_owned());
                        }
                    }
                }
            } else if !is_special(proxy_type) {
                names.insert(name.clone());
            }
        }
        // Deterministic output for the sweep table.
        Ok(names.into_iter().collect())
    }
}

/// Extracts the three-digit HTTP status code from a raw response head
/// (e.g. `HTTP/1.1 404 Not Found` -> `Some(404)`).
fn http_status_code(text: &str) -> Option<u16> {
    let head = text.split_once("\r\n").map_or(text, |(head, _)| head);
    let mut parts = head.split_whitespace();
    let _version = parts.next()?;
    parts.next()?.parse().ok()
}

/// Reads a traffic byte count from the first matching field name.
/// Parses a `/traffic` response frame into cumulative (download, upload) bytes.
///
/// `/traffic` differs between kernels: Mihomo emits `{"up":N,"down":N,
/// "upTotal":N,"downTotal":N}` and sing-box emits `{"up":N,"down":N}`, both as
/// (optionally `data: `-prefixed) JSON frames. Any field naming a kernel has
/// used is accepted.
fn parse_traffic_frame(text: &str) -> Result<(u64, u64), KernelFailure> {
    let json_text = text
        .lines()
        .map(str::trim)
        .filter_map(|line| line.strip_prefix("data: ").or(Some(line)))
        .find(|line| line.starts_with('{'))
        .unwrap_or("");
    let json = serde_json::from_str::<serde_json::Value>(json_text).map_err(|_| {
        crate::common::failure_with_kind(
            crate::ports::KernelFailureKind::DecodeRejected,
            "core traffic snapshot is invalid JSON",
            "inspect controller output",
        )
    })?;
    let download = traffic_field(&json, &["downloadTotal", "downTotal", "down"]).unwrap_or(0);
    let upload = traffic_field(&json, &["uploadTotal", "upTotal", "up"]).unwrap_or(0);
    Ok((download, upload))
}

/// Reads a traffic byte count from the first matching field name.
fn traffic_field(node: &serde_json::Value, keys: &[&str]) -> Option<u64> {
    keys.iter()
        .find_map(|key| node.get(*key).and_then(numeric_value))
}

/// Reads a non-negative numeric field as `u64`.
fn numeric(node: &serde_json::Value, key: &str) -> u64 {
    node.get(key).and_then(numeric_value).unwrap_or(0)
}

/// Extracts a `u64` from a JSON number (handles both signed and unsigned).
fn numeric_value(value: &serde_json::Value) -> Option<u64> {
    value
        .as_u64()
        .or_else(|| value.as_i64().and_then(|v| u64::try_from(v).ok()))
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn traffic_field_accepts_all_naming_conventions() {
        // Mihomo: downTotal/upTotal; sing-box: down/up; classic Clash: downloadTotal/uploadTotal.
        let mihomo = serde_json::json!({ "up": 0, "down": 0, "upTotal": 500, "downTotal": 700 });
        assert_eq!(
            traffic_field(&mihomo, &["downloadTotal", "downTotal", "down"]),
            Some(700)
        );
        assert_eq!(
            traffic_field(&mihomo, &["uploadTotal", "upTotal", "up"]),
            Some(500)
        );
        let sing = serde_json::json!({ "up": 11, "down": 22 });
        assert_eq!(
            traffic_field(&sing, &["downloadTotal", "downTotal", "down"]),
            Some(22)
        );
        assert_eq!(
            traffic_field(&sing, &["uploadTotal", "upTotal", "up"]),
            Some(11)
        );
        let classic = serde_json::json!({ "downloadTotal": 9, "uploadTotal": 4 });
        assert_eq!(
            traffic_field(&classic, &["downloadTotal", "downTotal", "down"]),
            Some(9)
        );
        // Missing fields fall back to None -> caller uses 0.
        assert_eq!(
            traffic_field(
                &serde_json::json!({}),
                &["downloadTotal", "downTotal", "down"]
            ),
            None
        );
    }
}

#[cfg(test)]
mod probe_status_tests {
    use super::*;

    #[test]
    fn status_code_parses_http_versions_and_reason_phrases() {
        assert_eq!(http_status_code("HTTP/1.1 200 OK\r\n\r\n"), Some(200));
        assert_eq!(
            http_status_code("HTTP/1.0 503 Service Unavailable\r\nContent-Length: 0\r\n"),
            Some(503)
        );
        assert_eq!(http_status_code("HTTP/1.1 404 Not Found\r\n"), Some(404));
        // A body without a status head yields no status.
        assert_eq!(http_status_code("{\"delay\":42}"), None);
        assert_eq!(http_status_code(""), None);
    }
}

#[cfg(test)]
mod proxy_names_tests {

    fn parse(body: &str) -> Vec<String> {
        // Mirror the parser in list_proxy_names without hitting a controller.
        let json: serde_json::Value =
            serde_json::from_str(body).unwrap_or_else(|_| std::process::abort());
        let Some(proxies) = json.get("proxies").and_then(serde_json::Value::as_object) else {
            return Vec::new();
        };
        let is_special = |proxy_type: &str| {
            matches!(
                proxy_type,
                "Selector"
                    | "URLTest"
                    | "Fallback"
                    | "LoadBalance"
                    | "Direct"
                    | "Reject"
                    | "Compatible"
                    | "Pass"
            )
        };
        let mut names = std::collections::BTreeSet::new();
        for (name, value) in proxies {
            let proxy_type = value
                .get("type")
                .and_then(serde_json::Value::as_str)
                .unwrap_or("");
            if matches!(
                proxy_type,
                "Selector" | "URLTest" | "Fallback" | "LoadBalance"
            ) {
                if let Some(all) = value.get("all").and_then(serde_json::Value::as_array) {
                    for member in all {
                        if let Some(tag) = member.as_str()
                            && !tag.is_empty()
                            && tag != "direct"
                        {
                            names.insert(tag.to_owned());
                        }
                    }
                }
            } else if !is_special(proxy_type) {
                names.insert(name.clone());
            }
        }
        names.into_iter().collect()
    }

    #[test]
    fn mihomo_shape_lists_top_level_nodes_and_deduplicates_selector_members() {
        let body = r#"{"proxies":{
            "PROXY":{"type":"Selector","all":["n1","n2","direct"]},
            "GLOBAL":{"type":"Selector","all":["n1","n2"]},
            "n1":{"type":"Shadowsocks"},
            "n2":{"type":"Vless"},
            "direct":{"type":"Direct"},
            "REJECT":{"type":"Reject"}
        }}"#;
        let names = parse(body);
        assert_eq!(names, vec!["n1", "n2"], "deduplicated node names only");
    }

    #[test]
    fn sing_box_shape_collects_nodes_from_selector_members() {
        let body = r#"{"proxies":{
            "PROXY":{"type":"Selector","all":["proxy-a","proxy-b","direct"]},
            "GLOBAL":{"type":"Selector","all":["proxy-a","proxy-b"]},
            "direct":{"type":"Direct"}
        }}"#;
        let names = parse(body);
        assert_eq!(names, vec!["proxy-a", "proxy-b"]);
    }
}
