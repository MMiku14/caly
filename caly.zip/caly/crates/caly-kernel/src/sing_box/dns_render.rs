//! sing-box DNS block rendering (1.12+ server format).
//!
//! Every DNS server carries a `type`; fake-ip is expressed as a `fakeip`
//! server type referenced by a rule. When a server references a domain-hosted
//! resolver, the caller must also wire `route.default_domain_resolver` to the
//! first IP-literal server, which `RenderedDns::domain_resolver` reports.

use caly_domain::{DnsMode, DnsSettings};

/// A rendered `dns` object plus the resolver the caller must wire into `route`
/// when the configuration references a domain-hosted DNS server.
pub(crate) struct RenderedDns {
    pub(crate) json: String,
    pub(crate) domain_resolver: Option<String>,
}

/// Renders a bounded DNS configuration as a sing-box `dns` JSON object.
pub(crate) fn render_dns_object(dns: &DnsSettings) -> RenderedDns {
    let entries = collect_entries(dns);
    let resolver_tag = find_resolver(&entries);
    let mut servers = Vec::new();
    let mut rules = Vec::new();
    let mut final_tag = None;
    for (group, index, value) in entries {
        let server = render_server(&group, index, &value, resolver_tag.as_deref());
        servers.push(server.json);
        if group == "nameserver" && final_tag.is_none() {
            final_tag = Some(format!("{group}-{index}"));
        }
    }
    if dns.mode() == DnsMode::FakeIp
        && let Some(range) = dns.fake_ip_range()
    {
        servers.push(format!(
            "{{\"type\":\"fakeip\",\"tag\":\"fakeip\",\"inet4_range\":\"{}\"}}",
            range.as_str()
        ));
        rules.push("{\"query_type\":[\"A\",\"AAAA\"],\"server\":\"fakeip\"}".to_owned());
    }
    let servers = servers.join(",");
    let rules_json = if rules.is_empty() {
        String::new()
    } else {
        format!(",\"rules\":[{}]", rules.join(","))
    };
    let final_tag = final_tag
        .map(|tag| format!(",\"final\":\"{tag}\""))
        .unwrap_or_default();
    let json = format!("{{\"servers\":[{servers}]{rules_json}{final_tag}}}");
    RenderedDns {
        json,
        domain_resolver: resolver_tag,
    }
}

/// Collects (group, index, value) entries in a stable render order.
fn collect_entries(dns: &DnsSettings) -> Vec<(String, usize, String)> {
    let mut entries = Vec::new();
    for (index, server) in dns.nameservers().iter().enumerate() {
        entries.push(("nameserver".to_owned(), index, server.as_str().to_owned()));
    }
    for (index, server) in dns.fallback().iter().enumerate() {
        entries.push(("fallback".to_owned(), index, server.as_str().to_owned()));
    }
    for (index, server) in dns.direct().iter().enumerate() {
        entries.push(("direct".to_owned(), index, server.as_str().to_owned()));
    }
    for (index, server) in dns.default().iter().enumerate() {
        entries.push(("default".to_owned(), index, server.as_str().to_owned()));
    }
    entries
}

/// Returns the first IP-literal server tag usable as a domain resolver.
fn find_resolver(entries: &[(String, usize, String)]) -> Option<String> {
    entries.iter().find_map(|(group, index, value)| {
        let (ty, host) = sing_box_server(value);
        if ty != "local" && host_is_ip(&host) {
            Some(format!("{group}-{index}"))
        } else {
            None
        }
    })
}

/// A rendered single-server JSON object.
struct RenderedServer {
    json: String,
}

/// Builds one typed sing-box DNS server object from a nameserver string.
fn render_server(
    group: &str,
    index: usize,
    value: &str,
    resolver_tag: Option<&str>,
) -> RenderedServer {
    let (ty, host) = sing_box_server(value);
    let mut field_vec = vec![
        format!("\"type\":\"{ty}\""),
        format!("\"tag\":\"{group}-{index}\""),
    ];
    if ty != "local" {
        field_vec.push(format!("\"server\":\"{host}\""));
        if !host_is_ip(&host)
            && let Some(tag) = resolver_tag
        {
            field_vec.push(format!("\"domain_resolver\":\"{tag}\""));
        }
    }
    RenderedServer {
        json: format!("{{{}}}", field_vec.join(",")),
    }
}

/// Maps a nameserver string to its sing-box server type and host.
fn sing_box_server(value: &str) -> (String, String) {
    if value == "local" {
        return ("local".to_owned(), String::new());
    }
    for (prefix, ty) in [
        ("tls://", "tls"),
        ("https://", "https"),
        ("tcp://", "tcp"),
        ("quic://", "quic"),
        ("udp://", "udp"),
    ] {
        if let Some(rest) = value.strip_prefix(prefix) {
            return (ty.to_owned(), strip_dns_path(rest).to_owned());
        }
    }
    ("udp".to_owned(), value.to_owned())
}

/// Removes a trailing `/path` so only the host remains in `server`.
fn strip_dns_path(value: &str) -> &str {
    value.split('/').next().unwrap_or(value)
}

/// Returns whether the host is an IP literal (so no resolver is needed).
fn host_is_ip(host: &str) -> bool {
    host.parse::<std::net::IpAddr>().is_ok()
}

#[cfg(test)]
mod tests {
    use super::*;
    use caly_domain::DnsSettingsBuilder;

    #[test]
    fn renders_typed_servers_and_fakeip_rule() -> Result<(), Box<dyn std::error::Error>> {
        let dns = DnsSettingsBuilder::new()
            .enabled(true)
            .mode(DnsMode::FakeIp)
            .push_nameserver("8.8.8.8")?
            .push_nameserver("1.1.1.1")?
            .push_fallback("tls://dns.google")?
            .push_direct("223.5.5.5")?
            .fake_ip_range("198.18.0.1/16")?
            .build()?
            .ok_or("dns settings disabled")?;
        let rendered = render_dns_object(&dns);
        let json = rendered.json;
        assert!(json.contains("\"type\":\"udp\",\"tag\":\"nameserver-0\""));
        assert!(json.contains("\"type\":\"fakeip\""));
        assert!(json.contains("\"inet4_range\":\"198.18.0.1/16\""));
        assert!(json.contains("\"final\":\"nameserver-0\""));
        assert!(json.contains("{\"query_type\":[\"A\",\"AAAA\"],\"server\":\"fakeip\"}"));
        assert_eq!(rendered.domain_resolver.as_deref(), Some("nameserver-0"));
        Ok(())
    }
}
