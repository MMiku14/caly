//! Renders a sample running snapshot to an ANSI frame and prints it with
//! escape sequences stripped, so the layout can be inspected as plain text.
//!
//! Run with:
//!   cargo run -p caly-tui --example dump

use caly_domain::{
    AppliedState, BoundedVec, Capability, CapabilitySet, CapabilityStatus, ConfiguredSupport,
    CoreKind, CoreRunState, DaemonInstanceId, DesiredState, DisplayNode, EventCursor,
    EventSequence, NodeDisplayName, NodeId, NodeProtocolLabel, ObservedState, PlatformEffectView,
    PresentationSnapshot, ProxyMode, RuntimeAvailability, SnapshotNodes, SnapshotRevision,
};
use caly_tui::render::{HotZone, Renderer, style::Theme};

fn main() -> Result<(), Box<dyn std::error::Error>> {
    let snapshot = running_snapshot()?;
    let renderer = Renderer::new(Theme::default());
    let frame = renderer.frame(&snapshot, 90, 26);
    print!("{}", strip_ansi(frame.ansi()));

    let arrow = caly_tui::render::input::parse_key(b"\x1b[B");
    let action = arrow.and_then(caly_tui::render::action::action_from_key);
    println!("key \\x1b[B -> {action:?}");

    let click = Renderer::resolve_click(&frame, 88, 0).map(HotZone::action);
    println!("click(+ button) -> {click:?}");
    Ok(())
}

fn running_snapshot() -> Result<PresentationSnapshot, Box<dyn std::error::Error>> {
    let daemon = DaemonInstanceId::from_bytes([7; 16]);
    let mut nodes: SnapshotNodes = BoundedVec::new();
    push_node(&mut nodes, 1, "hk-edge-01", "vmess", true, Some(28))?;
    push_node(&mut nodes, 2, "sg-backbone", "shadowsocks", true, Some(41))?;
    push_node(&mut nodes, 3, "us-relay-a", "trojan", false, None)?;

    let dns_status = CapabilityStatus::new(
        Capability::DnsConfiguration,
        ConfiguredSupport::Supported,
        RuntimeAvailability::NotRequired,
        None,
    );
    let mut capabilities = BoundedVec::new();
    capabilities.try_push(dns_status).map_err(|_| "cap push")?;

    Ok(PresentationSnapshot::new(
        daemon,
        SnapshotRevision::new(4),
        EventCursor::new(daemon, EventSequence::new(4)),
        DesiredState::new(ProxyMode::Rule, None, None, true, false),
        AppliedState::new(
            Some(CoreKind::Mihomo),
            CoreRunState::Running,
            Some(NodeId::from_bytes([1; 16])),
            Some(7),
        )
        .map_err(|_| "invalid applied")?,
        ObservedState::new(1_048_576, 2_097_152, 42, 0),
        PlatformEffectView::new(true, true, false, None),
        CapabilitySet::new(capabilities).map_err(|_| "capability set")?,
        nodes,
    ))
}

fn push_node(
    nodes: &mut SnapshotNodes,
    id: u8,
    name: &str,
    protocol: &str,
    available: bool,
    latency_ms: Option<u32>,
) -> Result<(), &'static str> {
    let node = DisplayNode::new(
        NodeId::from_bytes([id; 16]),
        NodeDisplayName::new(name.to_owned()).map_err(|_| "name")?,
        NodeProtocolLabel::new(protocol.to_owned()).map_err(|_| "protocol")?,
        available,
        latency_ms,
    );
    nodes.try_push(node).map_err(|_| "node push")
}

/// Removes ANSI CSI sequences for a plain-text read of the frame.
fn strip_ansi(input: &str) -> String {
    let mut out = String::new();
    let mut chars = input.chars();
    while let Some(ch) = chars.next() {
        if ch == '\x1b' {
            for next in chars.by_ref() {
                if matches!(next, 'm' | 'H' | 'J') {
                    break;
                }
            }
        } else {
            out.push(ch);
        }
    }
    out
}
