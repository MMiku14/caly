//! Node tree view: nodes grouped by protocol family.
//!
//! A presentation-only tree whose top-level "branches" are protocol families
//! (vmess, shadowsocks, trojan, …). Each branch lists its member nodes, giving
//! a hierarchical overview without requiring a dialer-parent relationship on
//! the snapshot's redacted display nodes.

use caly_domain::{DisplayNode, NodeId, SnapshotNodes};

use super::Viewport;

/// A node-tree branch: one protocol family and its ordered member ids.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct NodeBranch {
    protocol: String,
    member_ids: Vec<NodeId>,
}

impl NodeBranch {
    /// The branch's protocol-family label.
    pub fn protocol(&self) -> &str {
        &self.protocol
    }
    /// Member node ids in this branch.
    pub fn member_ids(&self) -> &[NodeId] {
        &self.member_ids
    }
}

/// Tree-shaped node view ordered by protocol family.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct NodeTree {
    branches: Vec<NodeBranch>,
    viewport: Viewport,
}

impl NodeTree {
    /// Rebuilds the protocol-grouped tree from a snapshot's nodes.
    pub fn rebuild(&mut self, nodes: &SnapshotNodes, filter: &str, visible_rows: usize) {
        let mut branches: Vec<(String, Vec<DisplayNode>)> = Vec::new();
        for node in nodes.as_slice() {
            if !matches(node, filter) {
                continue;
            }
            let protocol = node.protocol().as_str().to_owned();
            match branches.iter_mut().find(|(name, _)| *name == protocol) {
                Some((_, members)) => members.push(node.clone()),
                None => branches.push((protocol, vec![node.clone()])),
            }
        }
        // Stable sort branches by protocol, members by name.
        branches.sort_by(|left, right| left.0.cmp(&right.0));
        for (_, members) in &mut branches {
            members.sort_by(|left, right| left.name().as_str().cmp(right.name().as_str()));
        }
        self.branches = branches
            .into_iter()
            .map(|(protocol, members)| NodeBranch {
                protocol,
                member_ids: members.iter().map(DisplayNode::id).collect(),
            })
            .collect();
        self.viewport.update_extent(visible_rows, self.row_count());
    }

    /// Total display rows (one per branch + one per member).
    pub fn row_count(&self) -> usize {
        self.branches
            .iter()
            .map(|branch| 1 + branch.member_ids.len())
            .sum()
    }

    /// Borrows the ordered branches.
    pub fn branches(&self) -> &[NodeBranch] {
        &self.branches
    }

    /// Number of protocol families.
    pub fn branch_count(&self) -> usize {
        self.branches.len()
    }

    /// Flattened member ids in tree order (branch by branch).
    pub fn ordered_ids(&self) -> Vec<NodeId> {
        let mut ids = Vec::new();
        for branch in &self.branches {
            ids.extend(branch.member_ids.iter().copied());
        }
        ids
    }
}

impl Default for NodeTree {
    fn default() -> Self {
        Self {
            branches: Vec::new(),
            viewport: Viewport::new(1, 0),
        }
    }
}

/// Whether a node matches the pre-lowercased keyword filter.
fn matches(node: &DisplayNode, needle: &str) -> bool {
    if needle.is_empty() {
        return true;
    }
    node.name().as_str().to_lowercase().contains(needle)
        || node.protocol().as_str().to_lowercase().contains(needle)
}

#[cfg(test)]
mod tests {
    use super::*;
    use caly_domain::{NodeDisplayName, NodeProtocolLabel};

    fn node(id: u8, name: &str, protocol: &str) -> Result<DisplayNode, &'static str> {
        Ok(DisplayNode::new(
            NodeId::from_bytes([id; 16]),
            NodeDisplayName::new(name.to_owned()).map_err(|_| "name")?,
            NodeProtocolLabel::new(protocol.to_owned()).map_err(|_| "proto")?,
            true,
            None,
        ))
    }

    fn nodes() -> Result<SnapshotNodes, &'static str> {
        let mut values = SnapshotNodes::new();
        for (id, name, proto) in [
            (1u8, "hk-01", "vmess"),
            (2, "sg-01", "shadowsocks"),
            (3, "us-01", "vmess"),
            (4, "jp-01", "trojan"),
        ] {
            values
                .try_push(node(id, name, proto)?)
                .map_err(|_| "push")?;
        }
        Ok(values)
    }

    #[test]
    fn groups_nodes_by_protocol() -> Result<(), &'static str> {
        let mut tree = NodeTree::default();
        tree.rebuild(&nodes()?, "", 100);
        assert_eq!(tree.branch_count(), 3);
        let vmess = tree
            .branches()
            .iter()
            .find(|b| b.protocol() == "vmess")
            .ok_or("vmess")?;
        assert_eq!(vmess.member_ids().len(), 2);
        // members sorted by name: hk-01 then us-01
        assert_eq!(vmess.member_ids()[0], NodeId::from_bytes([1; 16]));
        assert_eq!(vmess.member_ids()[1], NodeId::from_bytes([3; 16]));
        Ok(())
    }

    #[test]
    fn filter_prunes_members() -> Result<(), &'static str> {
        let mut tree = NodeTree::default();
        tree.rebuild(&nodes()?, "hk", 100);
        assert_eq!(tree.row_count(), 2); // one branch + one member
        Ok(())
    }

    #[test]
    fn row_count_sums_branches_and_members() -> Result<(), &'static str> {
        let mut tree = NodeTree::default();
        tree.rebuild(&nodes()?, "", 100);
        // 3 branches + 4 members = 7 rows
        assert_eq!(tree.row_count(), 7);
        Ok(())
    }
}
