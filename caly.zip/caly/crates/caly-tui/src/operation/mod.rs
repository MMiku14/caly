//! Mutation operation presentation state.

mod tracker;

pub use tracker::{OperationOutcome, OperationTrackError, OperationTracker, OperationView};

use caly_domain::{NodeId, ProxyMode};

/// A daemon-bound mutation the interactive loop wants to execute.
///
/// Pure and transport-agnostic: the binary translates each variant into a
/// daemon operation through its client. This keeps the presentation crate free
/// of any network or daemon dependency.
#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub enum ControlAction {
    /// Select the highlighted node (execute the selection).
    SelectNode(NodeId),
    /// Request the next routing mode (rule → global → direct).
    SetMode(ProxyMode),
    /// Restart the running proxy core.
    RestartCore,
    /// Close all live connections.
    CloseConnections,
}
