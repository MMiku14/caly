//! Queryable operation UX without optimistic completion.

use caly_domain::{BoundedVec, OperationId, OperationState, OperationStatus};

/// Maximum operations shown in one client session.
pub const MAX_TRACKED_OPERATIONS: usize = 128;

/// Presentation-only wait state around authoritative daemon status.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct OperationView {
    status: OperationStatus,
    wait_timed_out: bool,
}

impl OperationView {
    pub const fn status(&self) -> &OperationStatus {
        &self.status
    }
    pub const fn wait_timed_out(&self) -> bool {
        self.wait_timed_out
    }
    pub const fn requires_status_query(&self) -> bool {
        self.wait_timed_out && !self.status.state().is_terminal()
    }
}

/// Bounded session operation tracker.
pub struct OperationTracker(BoundedVec<OperationView, MAX_TRACKED_OPERATIONS>);

impl OperationTracker {
    pub const fn new() -> Self {
        Self(BoundedVec::new())
    }

    /// Inserts or replaces authoritative status by OperationId.
    pub fn update(&mut self, status: OperationStatus) -> Result<(), OperationTrackError> {
        if let Some(existing) = self
            .0
            .iter_mut()
            .find(|view| view.status.id() == status.id())
        {
            existing.wait_timed_out = false;
            existing.status = status;
            return Ok(());
        }
        self.0
            .try_push(OperationView {
                status,
                wait_timed_out: false,
            })
            .map_err(|_| OperationTrackError::CapacityReached)
    }

    /// Marks only the client wait as timed out; daemon status is unchanged.
    pub fn mark_wait_timeout(&mut self, id: OperationId) -> Result<(), OperationTrackError> {
        let view = self
            .0
            .iter_mut()
            .find(|view| view.status.id() == id)
            .ok_or(OperationTrackError::NotFound)?;
        if !view.status.state().is_terminal() {
            view.wait_timed_out = true;
        }
        Ok(())
    }

    /// Returns truthful presentation classification.
    pub fn outcome(&self, id: OperationId) -> Result<OperationOutcome, OperationTrackError> {
        let view = self
            .0
            .iter()
            .find(|view| view.status.id() == id)
            .ok_or(OperationTrackError::NotFound)?;
        if view.requires_status_query() {
            return Ok(OperationOutcome::WaitTimedOutQueryStatus);
        }
        Ok(match view.status.state() {
            OperationState::Pending | OperationState::Running => OperationOutcome::InProgress,
            OperationState::Completed => OperationOutcome::Succeeded,
            OperationState::Failed => OperationOutcome::Failed,
            OperationState::Cancelled => OperationOutcome::Cancelled,
        })
    }
}

impl Default for OperationTracker {
    fn default() -> Self {
        Self::new()
    }
}

#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub enum OperationTrackError {
    CapacityReached,
    NotFound,
}

#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub enum OperationOutcome {
    InProgress,
    WaitTimedOutQueryStatus,
    Succeeded,
    Failed,
    Cancelled,
}
