//! Snapshot-driven interactive loop over a `Terminal` port.
//!
//! `TuiApp` owns presentation-local state (refresh cadence, pause, quit,
//! node scroll) and runs a tick that renders a frame from the latest snapshot
//! and drains input events into `Action`s. It is transport-agnostic and fully
//! testable against a mock `Terminal`.

use std::time::Duration;

use caly_domain::PresentationSnapshot;

use crate::render::input::Key;
use crate::render::{Frame, Renderer, action};
use crate::terminal::{Event, Terminal, TerminalError};
use crate::widgets::{NodeList, NodeSortKey, NodeTree, SortOrder};

use action::Action;

/// Minimum refresh interval in milliseconds.
pub const MIN_REFRESH_MS: u64 = 100;
/// Maximum refresh interval in milliseconds.
pub const MAX_REFRESH_MS: u64 = 5_000;
/// Default refresh interval in milliseconds.
pub const DEFAULT_REFRESH_MS: u64 = 1_000;
/// Maximum length of the interactive node filter, in chars (audit #108):
/// keys past the cap are deliberately swallowed — the cap bounds per-tick
/// `nodes × filter` matching work; the shrinking node list is the feedback.
pub const FILTER_MAX_CHARS: usize = 64;

/// Presentation-local interactive state.
#[derive(Clone, Debug)]
pub struct TuiApp {
    renderer: Renderer,
    refresh: Duration,
    flags: Flags,
    scroll: usize,
    last: Option<PresentationSnapshot>,
    node_list: NodeList,
    node_tree: NodeTree,
    filter: String,
    control: Vec<crate::operation::ControlAction>,
}

/// Compact presentation-local flags backed by one byte (avoids a 4-bool struct
/// triggering `clippy::struct_excessive_bools`).
#[derive(Clone, Copy, Debug, Default, Eq, PartialEq)]
struct Flags(u8);

impl Flags {
    const PAUSED: u8 = 0b0001;
    const QUIT: u8 = 0b0010;
    const TREE_VIEW: u8 = 0b0100;
    const FILTERING: u8 = 0b1000;
    const READONLY: u8 = 0b1_0000;

    const fn paused(self) -> bool {
        self.0 & Self::PAUSED != 0
    }
    const fn quit(self) -> bool {
        self.0 & Self::QUIT != 0
    }
    const fn tree_view(self) -> bool {
        self.0 & Self::TREE_VIEW != 0
    }
    const fn filtering(self) -> bool {
        self.0 & Self::FILTERING != 0
    }
    const fn readonly(self) -> bool {
        self.0 & Self::READONLY != 0
    }

    fn set(&mut self, bit: u8, on: bool) {
        if on {
            self.0 |= bit;
        } else {
            self.0 &= !bit;
        }
    }
    fn set_quit(&mut self, on: bool) {
        self.set(Self::QUIT, on);
    }
    fn toggle_paused(&mut self) {
        self.0 ^= Self::PAUSED;
    }
    fn set_filtering(&mut self, on: bool) {
        self.set(Self::FILTERING, on);
    }
    fn toggle_tree_view(&mut self) {
        self.0 ^= Self::TREE_VIEW;
    }
}

impl TuiApp {
    /// Constructs an app with the default refresh cadence.
    pub fn new(renderer: Renderer) -> Self {
        Self {
            renderer,
            refresh: Duration::from_millis(DEFAULT_REFRESH_MS),
            flags: Flags::default(),
            scroll: 0,
            last: None,
            node_list: NodeList::new(SortOrder::name(), 1),
            node_tree: NodeTree::default(),
            filter: String::new(),
            control: Vec::new(),
        }
    }

    /// Arms read-only mode (`caly tui --readonly`): every daemon-
    /// mutating control action (node select, mode cycle, core
    /// restart, connection close) is swallowed at the source, so
    /// a monitoring session can never change live state. View
    /// actions (scroll / filter / sort / pause / quit) keep
    /// working.
    pub fn set_readonly(&mut self, readonly: bool) {
        self.flags.set(Flags::READONLY, readonly);
    }

    /// Whether read-only mode is armed.
    pub const fn is_readonly(&self) -> bool {
        self.flags.readonly()
    }

    /// Runs the interactive loop until a quit action is applied, forwarding any
    /// daemon-bound control actions to `on_control` after each rendered tick.
    pub fn run<T: Terminal>(
        &mut self,
        terminal: &mut T,
        source: &mut dyn FnMut() -> Option<PresentationSnapshot>,
        on_control: &mut dyn FnMut(Vec<crate::operation::ControlAction>),
    ) -> Result<(), TerminalError> {
        terminal.enter()?;
        let result = self.run_loop(terminal, source, on_control);
        terminal.leave();
        result
    }

    fn run_loop<T: Terminal>(
        &mut self,
        terminal: &mut T,
        source: &mut dyn FnMut() -> Option<PresentationSnapshot>,
        on_control: &mut dyn FnMut(Vec<crate::operation::ControlAction>),
    ) -> Result<(), TerminalError> {
        while !self.flags.quit() {
            self.tick(terminal, source)?;
            let drained = self.drain_control();
            if !drained.is_empty() {
                on_control(drained);
            }
            std::thread::sleep(self.refresh);
        }
        Ok(())
    }

    /// Renders one frame and drains pending input events.
    pub fn tick<T: Terminal>(
        &mut self,
        terminal: &mut T,
        source: &mut dyn FnMut() -> Option<PresentationSnapshot>,
    ) -> Result<(), TerminalError> {
        if !self.flags.paused()
            && let Some(snapshot) = source()
        {
            self.last = Some(snapshot);
        }
        let mut frame = None;
        if let Some(snapshot) = &self.last {
            let (cols, rows) = terminal.size();
            self.node_list
                .rebuild(snapshot.nodes(), &self.filter, visible_rows(rows));
            self.node_tree
                .rebuild(snapshot.nodes(), &self.filter, visible_rows(rows));
            if self.flags.tree_view() {
                let order = self.node_tree.ordered_ids();
                frame = Some(self.renderer.frame_with_order(snapshot, cols, rows, &order));
            } else {
                frame = Some(
                    self.renderer
                        .frame_sorted(snapshot, cols, rows, &self.node_list),
                );
            }
            if let Some(frame) = &frame {
                terminal.write(frame.ansi())?;
            }
        }
        // Always drain events so quit works even before a snapshot arrives.
        while let Some(event) = terminal.read_event() {
            self.handle_event(frame.as_ref(), event);
        }
        Ok(())
    }

    fn handle_event(&mut self, frame: Option<&Frame>, event: Event) {
        match event {
            Event::Key(key) => {
                if self.flags.filtering() {
                    // While typing a filter, every printable key edits the
                    // filter buffer instead of triggering an action.
                    self.handle_filter_key(key);
                } else if let Some(action) = action::action_from_key(key) {
                    self.apply(action);
                }
            }
            Event::Click { col, row } => {
                if let Some(frame) = frame
                    && let Some(zone) = Renderer::resolve_click(frame, col, row)
                {
                    self.apply(zone.action());
                }
            }
            Event::Resize { .. } => {}
        }
    }

    /// Edits the node filter buffer while in filter mode. Esc/Enter leave the
    /// mode (Esc keeps the filter, so it doubles as a quick dismiss); Backspace
    /// deletes the last char; printable chars append (bounded to
    /// [`FILTER_MAX_CHARS`]; excess keys are deliberately swallowed — see the
    /// constant's doc for the feedback rationale).
    fn handle_filter_key(&mut self, key: Key) {
        match key {
            Key::Esc | Key::Enter => self.flags.set_filtering(false),
            Key::Backspace => {
                self.filter.pop();
            }
            Key::Char(ch) if self.filter.chars().count() < FILTER_MAX_CHARS => {
                self.filter.push(ch);
            }
            _ => {}
        }
    }

    fn apply(&mut self, action: Action) {
        match action {
            Action::Quit => self.flags.set_quit(true),
            Action::TogglePause => self.flags.toggle_paused(),
            Action::AdjustRefresh(delta) => self.adjust_refresh(delta),
            Action::ScrollNodes(delta) => {
                let current = i64::try_from(self.scroll).unwrap_or(0);
                let next = (current + i64::try_from(delta).unwrap_or(0)).max(0);
                self.scroll = usize::try_from(next).unwrap_or(usize::MAX);
                self.node_list.scroll(delta);
                self.node_list.select(delta);
            }
            Action::SelectNextNode => {
                self.node_list.select(1);
            }
            Action::SelectPrevNode => {
                self.node_list.select(-1);
            }
            Action::SelectNode => {
                if self.flags.readonly() {
                    return;
                }
                if let Some(node) = self.node_list.selected() {
                    self.control
                        .push(crate::operation::ControlAction::SelectNode(node));
                }
            }
            Action::CycleMode => {
                if self.flags.readonly() {
                    return;
                }
                let mode = self.next_mode();
                self.control
                    .push(crate::operation::ControlAction::SetMode(mode));
            }
            Action::RestartCore => {
                if self.flags.readonly() {
                    return;
                }
                self.control
                    .push(crate::operation::ControlAction::RestartCore);
            }
            Action::CloseConnections => {
                if self.flags.readonly() {
                    return;
                }
                self.control
                    .push(crate::operation::ControlAction::CloseConnections);
            }
            Action::BeginFilter => self.flags.set_filtering(true),
            Action::CycleSort => self.cycle_sort(),
            Action::ToggleTreeView => self.toggle_tree_view(),
            Action::OpenMenu | Action::NextPreset | Action::PrevPreset => {}
        }
    }

    /// Cycles the active node sort key Name → Protocol → Latency → Name,
    /// resetting the direction to ascending on each switch.
    fn cycle_sort(&mut self) {
        let next = match self.node_list.sort().key() {
            NodeSortKey::Name => NodeSortKey::Protocol,
            NodeSortKey::Protocol => NodeSortKey::Latency,
            NodeSortKey::Latency => NodeSortKey::Name,
        };
        self.toggle_sort(next);
    }

    /// Drains the pending daemon-bound control actions for the outer loop.
    pub fn drain_control(&mut self) -> Vec<crate::operation::ControlAction> {
        std::mem::take(&mut self.control)
    }

    /// Returns the next routing mode in the rule → global → direct cycle, based
    /// on the latest snapshot's desired state.
    fn next_mode(&self) -> caly_domain::ProxyMode {
        let current = self
            .last
            .as_ref()
            .map_or(caly_domain::ProxyMode::Rule, |snapshot| {
                snapshot.desired().mode()
            });
        match current {
            caly_domain::ProxyMode::Rule => caly_domain::ProxyMode::Global,
            caly_domain::ProxyMode::Global => caly_domain::ProxyMode::Direct,
            caly_domain::ProxyMode::Direct => caly_domain::ProxyMode::Rule,
        }
    }

    fn adjust_refresh(&mut self, delta_ms: isize) {
        let base = i64::try_from(self.refresh.as_millis()).unwrap_or(0);
        let delta = i64::try_from(delta_ms).unwrap_or(0);
        let min = i64::try_from(MIN_REFRESH_MS).unwrap_or(0);
        let max = i64::try_from(MAX_REFRESH_MS).unwrap_or(i64::MAX);
        let clamped = (base + delta).clamp(min, max);
        let millis = u64::try_from(clamped).unwrap_or(0);
        self.refresh = Duration::from_millis(millis);
    }

    /// Sets the node filter keyword (bounded to [`FILTER_MAX_CHARS`] chars;
    /// longer input is truncated, matching the interactive typing cap).
    pub fn set_filter(&mut self, filter: &str) {
        self.filter = filter.chars().take(FILTER_MAX_CHARS).collect();
    }

    /// Borrows the current node filter keyword.
    pub fn filter(&self) -> &str {
        &self.filter
    }

    /// Returns whether the app is in filter-typing mode.
    pub fn filtering(&self) -> bool {
        self.flags.filtering()
    }

    /// Toggles the node sort key (direction flips when already active).
    pub fn toggle_sort(&mut self, key: NodeSortKey) {
        let mut order = self.node_list.sort();
        order.toggle(key);
        self.node_list.set_sort(order);
    }

    /// Borrows the current node list.
    pub fn node_list(&self) -> &NodeList {
        &self.node_list
    }

    /// Toggles between flat list and tree view.
    pub fn toggle_tree_view(&mut self) {
        self.flags.toggle_tree_view();
    }

    /// Returns whether tree view is active.
    pub fn tree_view(&self) -> bool {
        self.flags.tree_view()
    }

    /// Borrows the current node tree (tree view data).
    pub fn node_tree(&self) -> &NodeTree {
        &self.node_tree
    }

    /// Returns whether a quit action has been applied.
    pub fn should_quit(&self) -> bool {
        self.flags.quit()
    }
    /// Returns the current refresh interval.
    pub fn refresh(&self) -> Duration {
        self.refresh
    }
    /// Returns whether refresh is paused.
    pub fn paused(&self) -> bool {
        self.flags.paused()
    }
    /// Returns the current node-scroll offset.
    pub fn scroll(&self) -> usize {
        self.scroll
    }
}

/// Node rows visible in the NODES panel for a terminal height.
fn visible_rows(rows: usize) -> usize {
    rows.saturating_sub(2).saturating_mul(3) / 4
}

#[cfg(test)]
mod runner_tests;
