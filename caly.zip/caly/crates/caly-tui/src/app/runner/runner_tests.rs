use super::*;
use crate::render::{Renderer, input};
use crate::terminal::mock::MockTerminal;
use caly_domain::{
    AppliedState, BoundedVec, CapabilitySet, CoreKind, CoreRunState, DaemonInstanceId,
    DesiredState, DisplayNode, EventCursor, EventSequence, NodeDisplayName, NodeId,
    NodeProtocolLabel, ObservedState, PlatformEffectView, PresentationSnapshot, ProxyMode,
    SnapshotNodes, SnapshotRevision,
};

fn snapshot() -> Result<PresentationSnapshot, Box<dyn std::error::Error>> {
    let daemon = DaemonInstanceId::from_bytes([3; 16]);
    let applied = AppliedState::new(Some(CoreKind::Mihomo), CoreRunState::Running, None, Some(1))?;
    let capabilities = CapabilitySet::new(BoundedVec::new())?;
    Ok(PresentationSnapshot::new(
        daemon,
        SnapshotRevision::new(1),
        EventCursor::new(daemon, EventSequence::new(1)),
        DesiredState::new(ProxyMode::Rule, None, None, false, false),
        applied,
        ObservedState::new(0, 0, 0, 0),
        PlatformEffectView::none(),
        capabilities,
        BoundedVec::new(),
    ))
}

#[test]
fn tick_renders_and_drains_key_events() -> Result<(), TerminalError> {
    let mut terminal = MockTerminal::new(80, 24);
    terminal.queue(Event::Key(input::Key::Down));
    let mut source = || snapshot().ok();
    let mut app = TuiApp::new(Renderer::default());
    app.tick(&mut terminal, &mut source)?;
    assert_eq!(terminal.frame_count(), 1);
    assert_eq!(app.scroll(), 1);
    Ok(())
}

#[test]
fn pause_freezes_last_frame() -> Result<(), TerminalError> {
    let mut terminal = MockTerminal::new(80, 24);
    let mut source = || snapshot().ok();
    let mut app = TuiApp::new(Renderer::default());
    app.tick(&mut terminal, &mut source)?;
    let count_before = terminal.frame_count();
    terminal.queue(Event::Key(input::Key::Char('p')));
    let mut empty = || None::<PresentationSnapshot>;
    app.tick(&mut terminal, &mut empty)?;
    assert!(app.paused());
    assert_eq!(terminal.frame_count(), count_before + 1);
    Ok(())
}

#[test]
fn click_on_plus_adjusts_refresh() -> Result<(), TerminalError> {
    let mut terminal = MockTerminal::new(80, 24);
    let mut source = || snapshot().ok();
    let mut app = TuiApp::new(Renderer::default());
    app.tick(&mut terminal, &mut source)?;
    let base = app.refresh();
    terminal.queue(Event::Click { col: 78, row: 0 });
    let mut empty = || None::<PresentationSnapshot>;
    app.tick(&mut terminal, &mut empty)?;
    assert_eq!(
        app.refresh(),
        base.saturating_add(Duration::from_millis(100))
    );
    Ok(())
}

#[test]
fn quit_sets_flag() {
    let mut app = TuiApp::new(Renderer::default());
    app.apply(Action::Quit);
    assert!(app.should_quit());
}

#[test]
fn begin_filter_enters_typing_mode_and_edits_the_buffer() {
    let mut app = TuiApp::new(Renderer::default());
    app.apply(Action::BeginFilter);
    assert!(app.filtering());
    app.handle_event(None, Event::Key(input::Key::Char('h')));
    app.handle_event(None, Event::Key(input::Key::Char('k')));
    assert_eq!(app.filter(), "hk");
    // Backspace removes the last character.
    app.handle_event(None, Event::Key(input::Key::Backspace));
    assert_eq!(app.filter(), "h");
    // Enter commits and leaves the mode.
    app.handle_event(None, Event::Key(input::Key::Enter));
    assert!(!app.filtering());
    assert_eq!(app.filter(), "h");
}

#[test]
fn filter_mode_swallows_action_keys() {
    let mut app = TuiApp::new(Renderer::default());
    app.apply(Action::BeginFilter);
    // 'q' types into the filter rather than quitting.
    app.handle_event(None, Event::Key(input::Key::Char('q')));
    assert_eq!(app.filter(), "q");
    assert!(!app.should_quit());
    // Esc cancels the mode (dismissing the filter) without committing more.
    app.handle_event(None, Event::Key(input::Key::Esc));
    assert!(!app.filtering());
}

#[test]
fn cycle_sort_advances_through_all_keys() {
    let mut app = TuiApp::new(Renderer::default());
    assert_eq!(
        app.node_list().sort().key(),
        crate::widgets::NodeSortKey::Name
    );
    app.apply(Action::CycleSort);
    assert_eq!(
        app.node_list().sort().key(),
        crate::widgets::NodeSortKey::Protocol
    );
    app.apply(Action::CycleSort);
    assert_eq!(
        app.node_list().sort().key(),
        crate::widgets::NodeSortKey::Latency
    );
    app.apply(Action::CycleSort);
    assert_eq!(
        app.node_list().sort().key(),
        crate::widgets::NodeSortKey::Name
    );
}

#[test]
fn toggle_tree_view_action_flips_view() {
    let mut app = TuiApp::new(Renderer::default());
    assert!(!app.tree_view());
    app.apply(Action::ToggleTreeView);
    assert!(app.tree_view());
    app.apply(Action::ToggleTreeView);
    assert!(!app.tree_view());
}

#[test]
fn filter_and_sort_shape_the_node_list() -> Result<(), Box<dyn std::error::Error>> {
    let mut nodes: SnapshotNodes = BoundedVec::new();
    for (id, name, latency) in [(1u8, "hk-01", 30u32), (2, "sg-02", 20)] {
        nodes.try_push(DisplayNode::new(
            NodeId::from_bytes([id; 16]),
            NodeDisplayName::new(name.to_owned())?,
            NodeProtocolLabel::new("vmess".to_owned())?,
            true,
            Some(latency),
        ))?;
    }
    let daemon = DaemonInstanceId::from_bytes([4; 16]);
    let snapshot = PresentationSnapshot::new(
        daemon,
        SnapshotRevision::new(1),
        EventCursor::new(daemon, EventSequence::new(1)),
        DesiredState::new(ProxyMode::Rule, None, None, false, false),
        AppliedState::new(Some(CoreKind::Mihomo), CoreRunState::Running, None, Some(1))?,
        ObservedState::new(0, 0, 0, 0),
        PlatformEffectView::none(),
        CapabilitySet::new(BoundedVec::new())?,
        nodes,
    );
    let mut terminal = MockTerminal::new(80, 24);
    let mut source = || Some(snapshot.clone());
    let mut app = TuiApp::new(Renderer::default());
    app.tick(&mut terminal, &mut source).map_err(|_| "tick")?;
    app.toggle_sort(crate::widgets::NodeSortKey::Latency);
    app.tick(&mut terminal, &mut source).map_err(|_| "tick")?;
    assert_eq!(
        app.node_list().ordered_ids()[0],
        NodeId::from_bytes([2; 16])
    );
    app.set_filter("hk");
    app.tick(&mut terminal, &mut source).map_err(|_| "tick")?;
    assert_eq!(app.node_list().ordered_ids().len(), 1);
    assert_eq!(
        app.node_list().ordered_ids()[0],
        NodeId::from_bytes([1; 16])
    );
    Ok(())
}

#[test]
fn quit_works_before_first_snapshot() -> Result<(), TerminalError> {
    let mut terminal = MockTerminal::new(80, 24);
    terminal.queue(Event::Key(input::Key::Char('q')));
    let mut source = || None::<PresentationSnapshot>;
    let mut app = TuiApp::new(Renderer::default());
    app.tick(&mut terminal, &mut source)?;
    assert!(app.should_quit(), "q must quit even with no snapshot");
    Ok(())
}

#[test]
fn tree_view_groups_nodes_by_protocol() -> Result<(), &'static str> {
    let mut nodes: SnapshotNodes = BoundedVec::new();
    for (id, name, proto) in [
        (1u8, "hk-01", "vmess"),
        (2, "sg-01", "shadowsocks"),
        (3, "us-01", "vmess"),
    ] {
        nodes
            .try_push(DisplayNode::new(
                NodeId::from_bytes([id; 16]),
                NodeDisplayName::new(name.to_owned()).map_err(|_| "name")?,
                NodeProtocolLabel::new(proto.to_owned()).map_err(|_| "proto")?,
                true,
                None,
            ))
            .map_err(|_| "push")?;
    }
    let daemon = DaemonInstanceId::from_bytes([6; 16]);
    let snapshot = PresentationSnapshot::new(
        daemon,
        SnapshotRevision::new(1),
        EventCursor::new(daemon, EventSequence::new(1)),
        DesiredState::new(ProxyMode::Rule, None, None, false, false),
        AppliedState::new(Some(CoreKind::Mihomo), CoreRunState::Running, None, Some(1))
            .map_err(|_| "applied")?,
        ObservedState::new(0, 0, 0, 0),
        PlatformEffectView::none(),
        CapabilitySet::new(BoundedVec::new()).map_err(|_| "cap")?,
        nodes,
    );
    let mut terminal = MockTerminal::new(80, 24);
    let mut source = || Some(snapshot.clone());
    let mut app = TuiApp::new(Renderer::default());
    app.tick(&mut terminal, &mut source).map_err(|_| "tick")?;
    assert!(!app.tree_view());
    app.toggle_tree_view();
    assert!(app.tree_view());
    assert_eq!(app.node_tree().branch_count(), 2);
    // Tree order: shadowsocks branch first, then vmess (alphabetical).
    let ids = app.node_tree().ordered_ids();
    assert_eq!(ids[0], NodeId::from_bytes([2; 16])); // sg-01 (shadowsocks)
    app.tick(&mut terminal, &mut source).map_err(|_| "tick")?;
    Ok(())
}

#[test]
fn control_actions_emit_daemon_bound_actions() -> Result<(), Box<dyn std::error::Error>> {
    let mut nodes: SnapshotNodes = BoundedVec::new();
    nodes.try_push(DisplayNode::new(
        NodeId::from_bytes([1; 16]),
        NodeDisplayName::new("hk-01".to_owned())?,
        NodeProtocolLabel::new("vmess".to_owned())?,
        true,
        None,
    ))?;
    nodes.try_push(DisplayNode::new(
        NodeId::from_bytes([2; 16]),
        NodeDisplayName::new("sg-02".to_owned())?,
        NodeProtocolLabel::new("ss".to_owned())?,
        true,
        None,
    ))?;
    let daemon = DaemonInstanceId::from_bytes([9; 16]);
    let snapshot = PresentationSnapshot::new(
        daemon,
        SnapshotRevision::new(1),
        EventCursor::new(daemon, EventSequence::new(1)),
        DesiredState::new(ProxyMode::Rule, None, None, false, false),
        AppliedState::new(Some(CoreKind::Mihomo), CoreRunState::Running, None, Some(1))?,
        ObservedState::new(0, 0, 0, 0),
        PlatformEffectView::none(),
        CapabilitySet::new(BoundedVec::new())?,
        nodes,
    );
    let mut terminal = MockTerminal::new(80, 24);
    let mut source = || Some(snapshot.clone());
    let mut app = TuiApp::new(Renderer::default());
    app.tick(&mut terminal, &mut source).map_err(|_| "tick")?;

    // Select a node, then execute the selection.
    app.apply(action::Action::SelectNextNode);
    app.apply(action::Action::SelectNode);
    assert_eq!(
        app.drain_control(),
        vec![crate::operation::ControlAction::SelectNode(
            NodeId::from_bytes([2; 16])
        )]
    );

    // Cycle mode from Rule -> Global.
    app.apply(action::Action::CycleMode);
    assert_eq!(
        app.drain_control(),
        vec![crate::operation::ControlAction::SetMode(ProxyMode::Global)]
    );

    // Restart core and close connections.
    app.apply(action::Action::RestartCore);
    app.apply(action::Action::CloseConnections);
    assert_eq!(
        app.drain_control(),
        vec![
            crate::operation::ControlAction::RestartCore,
            crate::operation::ControlAction::CloseConnections,
        ]
    );
    assert!(app.drain_control().is_empty(), "outbox clears after drain");
    Ok(())
}

#[test]
fn select_node_with_no_selection_is_ignored() {
    let mut app = TuiApp::new(Renderer::default());
    app.apply(action::Action::SelectNode);
    assert!(app.drain_control().is_empty());
}
