//! Terminal presentation client for caly.
//!
//! The TUI consumes immutable presentation snapshots through caly-protocol.
//! Selection, viewport, reconnect and operation wait state remain client-local.

#![forbid(unsafe_code)]
#![cfg_attr(test, allow(clippy::unwrap_used, clippy::expect_used, clippy::panic))] // #53: tests assert with unwrap/expect/panic; production lint stays deny
pub mod app;
pub mod client;
pub mod editor;
pub mod model;
pub mod operation;
pub mod render;
pub mod terminal;
pub mod widgets;
