//! Reconnect, handshake, snapshot and watch state machine.

use caly_domain::{BoundedText, CursorDisposition, EventCursor, UnixMillis, classify_cursor};

/// Connection lifecycle with no optimistic connected state.
#[derive(Clone, Debug, Eq, PartialEq)]
pub enum ConnectionState {
    Disconnected,
    Connecting,
    Handshaking,
    FetchingSnapshot,
    Watching {
        cursor: EventCursor,
    },
    ApplyingEvent {
        current: EventCursor,
        incoming: EventCursor,
    },
    Backoff {
        attempt: u32,
        retry_at: UnixMillis,
        reason: BoundedText<512>,
    },
    Stopped,
}

/// External result fed into the deterministic supervisor.
#[derive(Clone, Debug, Eq, PartialEq)]
pub enum ConnectionEvent {
    ConnectStarted,
    TransportConnected,
    HandshakeAccepted,
    SnapshotReceived {
        cursor: EventCursor,
    },
    EventReceived {
        cursor: EventCursor,
    },
    EventApplied,
    EventDecodeFailed,
    Failed {
        retry_at: UnixMillis,
        reason: BoundedText<512>,
    },
    RetryDue {
        now: UnixMillis,
    },
    Stop,
}

/// Action the executor must perform next.
#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub enum ConnectionAction {
    None,
    OpenTransport,
    SendHandshake,
    FetchSnapshot,
    DecodeAndApplyEvent,
    CloseTransport,
}

/// Illegal transition indicates executor/state disagreement.
#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub struct ConnectionTransitionError;

/// Single-owner client connection state.
pub struct ConnectionSupervisor {
    state: ConnectionState,
    failures: u32,
}

impl ConnectionSupervisor {
    pub const fn new() -> Self {
        Self {
            state: ConnectionState::Disconnected,
            failures: 0,
        }
    }
    pub const fn state(&self) -> &ConnectionState {
        &self.state
    }

    /// Applies one event and returns an explicit executor action.
    pub fn transition(
        &mut self,
        event: ConnectionEvent,
    ) -> Result<ConnectionAction, ConnectionTransitionError> {
        if let Some(result) = self.handle_global(&event) {
            return result;
        }
        match (self.state.clone(), event) {
            (ConnectionState::Disconnected, ConnectionEvent::ConnectStarted) => {
                self.state = ConnectionState::Connecting;
                Ok(ConnectionAction::OpenTransport)
            }
            (ConnectionState::Backoff { retry_at, .. }, ConnectionEvent::RetryDue { now })
                if now >= retry_at =>
            {
                self.state = ConnectionState::Connecting;
                Ok(ConnectionAction::OpenTransport)
            }
            (ConnectionState::Connecting, ConnectionEvent::TransportConnected) => {
                self.state = ConnectionState::Handshaking;
                Ok(ConnectionAction::SendHandshake)
            }
            (ConnectionState::Handshaking, ConnectionEvent::HandshakeAccepted) => {
                self.state = ConnectionState::FetchingSnapshot;
                Ok(ConnectionAction::FetchSnapshot)
            }
            (ConnectionState::FetchingSnapshot, ConnectionEvent::SnapshotReceived { cursor })
            | (ConnectionState::Watching { .. }, ConnectionEvent::SnapshotReceived { cursor })
            | (
                ConnectionState::ApplyingEvent { .. },
                ConnectionEvent::SnapshotReceived { cursor },
            ) => Ok(self.accept_snapshot(cursor)),
            (
                ConnectionState::Watching { cursor },
                ConnectionEvent::EventReceived { cursor: incoming },
            ) => Ok(self.handle_event_cursor(cursor, incoming)),
            (ConnectionState::ApplyingEvent { incoming, .. }, ConnectionEvent::EventApplied) => {
                self.state = ConnectionState::Watching { cursor: incoming };
                Ok(ConnectionAction::None)
            }
            (ConnectionState::ApplyingEvent { .. }, ConnectionEvent::EventDecodeFailed) => {
                self.state = ConnectionState::FetchingSnapshot;
                Ok(ConnectionAction::FetchSnapshot)
            }
            _ => Err(ConnectionTransitionError),
        }
    }

    fn handle_global(
        &mut self,
        event: &ConnectionEvent,
    ) -> Option<Result<ConnectionAction, ConnectionTransitionError>> {
        match event {
            ConnectionEvent::Stop if matches!(self.state, ConnectionState::Stopped) => {
                Some(Ok(ConnectionAction::None))
            }
            ConnectionEvent::Stop => {
                self.state = ConnectionState::Stopped;
                Some(Ok(ConnectionAction::CloseTransport))
            }
            ConnectionEvent::Failed { .. } if matches!(self.state, ConnectionState::Stopped) => {
                Some(Err(ConnectionTransitionError))
            }
            ConnectionEvent::Failed { retry_at, reason } => {
                self.failures = self.failures.saturating_add(1);
                self.state = ConnectionState::Backoff {
                    attempt: self.failures,
                    retry_at: *retry_at,
                    reason: reason.clone(),
                };
                Some(Ok(ConnectionAction::CloseTransport))
            }
            _ => None,
        }
    }

    fn accept_snapshot(&mut self, cursor: EventCursor) -> ConnectionAction {
        self.failures = 0;
        self.state = ConnectionState::Watching { cursor };
        ConnectionAction::None
    }

    fn handle_event_cursor(
        &mut self,
        current: EventCursor,
        incoming: EventCursor,
    ) -> ConnectionAction {
        match classify_cursor(current, incoming) {
            CursorDisposition::Apply => {
                self.state = ConnectionState::ApplyingEvent { current, incoming };
                ConnectionAction::DecodeAndApplyEvent
            }
            CursorDisposition::Stale => ConnectionAction::None,
            CursorDisposition::FullSnapshotRequired => {
                self.state = ConnectionState::FetchingSnapshot;
                ConnectionAction::FetchSnapshot
            }
        }
    }
}

impl Default for ConnectionSupervisor {
    fn default() -> Self {
        Self::new()
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use caly_domain::{DaemonInstanceId, EventSequence};

    fn cursor(epoch: u8, sequence: u64) -> EventCursor {
        EventCursor::new(
            DaemonInstanceId::from_bytes([epoch; 16]),
            EventSequence::new(sequence),
        )
    }

    fn watching() -> Result<ConnectionSupervisor, ConnectionTransitionError> {
        let mut supervisor = ConnectionSupervisor::new();
        supervisor.transition(ConnectionEvent::ConnectStarted)?;
        supervisor.transition(ConnectionEvent::TransportConnected)?;
        supervisor.transition(ConnectionEvent::HandshakeAccepted)?;
        supervisor.transition(ConnectionEvent::SnapshotReceived {
            cursor: cursor(1, 7),
        })?;
        Ok(supervisor)
    }

    #[test]
    fn cursor_commits_only_after_event_apply() -> Result<(), ConnectionTransitionError> {
        let mut supervisor = watching()?;
        let action = supervisor.transition(ConnectionEvent::EventReceived {
            cursor: cursor(1, 8),
        })?;
        assert_eq!(action, ConnectionAction::DecodeAndApplyEvent);
        assert_eq!(
            supervisor.state(),
            &ConnectionState::ApplyingEvent {
                current: cursor(1, 7),
                incoming: cursor(1, 8),
            }
        );
        supervisor.transition(ConnectionEvent::EventApplied)?;
        assert_eq!(
            supervisor.state(),
            &ConnectionState::Watching {
                cursor: cursor(1, 8)
            }
        );
        Ok(())
    }

    #[test]
    fn gap_or_decode_failure_requests_snapshot() -> Result<(), ConnectionTransitionError> {
        let mut gap = watching()?;
        assert_eq!(
            gap.transition(ConnectionEvent::EventReceived {
                cursor: cursor(1, 9)
            })?,
            ConnectionAction::FetchSnapshot,
        );
        let mut decode = watching()?;
        decode.transition(ConnectionEvent::EventReceived {
            cursor: cursor(1, 8),
        })?;
        assert_eq!(
            decode.transition(ConnectionEvent::EventDecodeFailed)?,
            ConnectionAction::FetchSnapshot
        );
        Ok(())
    }
}
