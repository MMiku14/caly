//! Daemon connection supervision.

mod live_source;
mod supervisor;
mod watch_driver;

pub use live_source::{LiveWatchSource, ReplayWatchTransport, WatchTransport};
pub use supervisor::{
    ConnectionAction, ConnectionEvent, ConnectionState, ConnectionSupervisor,
    ConnectionTransitionError,
};
pub use watch_driver::{WatchDriver, WatchDriverError, WatchOutcome, WatchRecoveryCause};
