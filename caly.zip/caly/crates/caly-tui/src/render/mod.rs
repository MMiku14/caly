//! TUI renderer skeleton: layout → canvas → ANSI frame.
//!
//! The renderer is snapshot-driven and pure: it consumes an immutable
//! `PresentationSnapshot` and produces a full-screen 24-bit ANSI frame,
//! independent of any terminal input or daemon transport. Higher layers
//! supply the snapshot stream and refresh cadence.

pub mod action;
pub mod canvas;
mod format;
pub mod hotzone;
pub mod input;
pub mod layout;
pub mod panels;
pub mod style;

use caly_domain::{NodeId, PresentationSnapshot};

use self::canvas::Canvas;
pub use self::hotzone::{HotZone, HotZoneRegistry};
use self::layout::Layout;
use self::style::Theme;
use crate::widgets::NodeList;

/// One rendered frame: the ANSI text plus its registered hot zones.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct Frame {
    ansi: String,
    hotzones: HotZoneRegistry,
}

impl Frame {
    /// The full-screen ANSI text.
    pub fn ansi(&self) -> &str {
        &self.ansi
    }
    /// Hot zones registered while drawing this frame.
    pub fn hotzones(&self) -> &HotZoneRegistry {
        &self.hotzones
    }
}

/// Owns a theme and produces ANSI frames from snapshots.
#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub struct Renderer {
    theme: Theme,
}

impl Renderer {
    /// Constructs a renderer with a palette.
    pub const fn new(theme: Theme) -> Self {
        Self { theme }
    }

    /// Returns the active palette.
    pub const fn theme(self) -> Theme {
        self.theme
    }

    /// Renders a snapshot into a full-screen frame with hot zones.
    pub fn frame(&self, snapshot: &PresentationSnapshot, cols: usize, rows: usize) -> Frame {
        let mut canvas = Canvas::new(rows, cols, self.theme.background);
        let mut hotzones = HotZoneRegistry::default();
        let layout = Layout::compute(cols, rows);
        panels::draw_all(
            &mut canvas,
            &layout,
            snapshot,
            &self.theme,
            &mut hotzones,
            None,
        );
        Frame {
            ansi: canvas.to_ansi(),
            hotzones,
        }
    }

    /// Renders a frame drawing nodes in the `NodeList`'s ordered view.
    pub fn frame_sorted(
        &self,
        snapshot: &PresentationSnapshot,
        cols: usize,
        rows: usize,
        node_list: &NodeList,
    ) -> Frame {
        self.frame_with_order(snapshot, cols, rows, node_list.ordered_ids())
    }

    /// Renders a frame drawing nodes in a caller-provided order.
    pub fn frame_with_order(
        &self,
        snapshot: &PresentationSnapshot,
        cols: usize,
        rows: usize,
        order: &[NodeId],
    ) -> Frame {
        let mut canvas = Canvas::new(rows, cols, self.theme.background);
        let mut hotzones = HotZoneRegistry::default();
        let layout = Layout::compute(cols, rows);
        panels::draw_all(
            &mut canvas,
            &layout,
            snapshot,
            &self.theme,
            &mut hotzones,
            Some(order),
        );
        Frame {
            ansi: canvas.to_ansi(),
            hotzones,
        }
    }

    /// Renders a snapshot into a full-screen ANSI frame (text only).
    ///
    /// The frame begins with clear/home so consecutive frames are stable.
    pub fn render_frame(
        &self,
        snapshot: &PresentationSnapshot,
        cols: usize,
        rows: usize,
    ) -> String {
        self.frame(snapshot, cols, rows).ansi
    }

    /// Resolves a mouse click against a frame's hot zones.
    pub fn resolve_click(frame: &Frame, col: usize, row: usize) -> Option<HotZone> {
        frame.hotzones.resolve(col, row)
    }
}

impl Default for Renderer {
    fn default() -> Self {
        Self::new(Theme::default())
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use caly_domain::{
        AppliedState, BoundedVec, CapabilitySet, CoreKind, CoreRunState, DaemonInstanceId,
        DesiredState, EventCursor, EventSequence, ObservedState, PlatformEffectView,
        PresentationSnapshot, ProxyMode, SnapshotRevision,
    };

    fn snapshot() -> Result<PresentationSnapshot, Box<dyn std::error::Error>> {
        let daemon = DaemonInstanceId::from_bytes([9; 16]);
        let applied =
            AppliedState::new(Some(CoreKind::Mihomo), CoreRunState::Running, None, Some(1))?;
        let capabilities = CapabilitySet::new(BoundedVec::new())?;
        Ok(PresentationSnapshot::new(
            daemon,
            SnapshotRevision::new(3),
            EventCursor::new(daemon, EventSequence::new(3)),
            DesiredState::new(ProxyMode::Rule, None, None, false, false),
            applied,
            ObservedState::new(1024, 2048, 5, 0),
            PlatformEffectView::none(),
            capabilities,
            BoundedVec::new(),
        ))
    }

    #[test]
    fn frame_is_nonempty_and_contains_panel_titles() -> Result<(), Box<dyn std::error::Error>> {
        let renderer = Renderer::default();
        let frame = renderer.render_frame(&snapshot()?, 80, 24);
        assert!(frame.starts_with("\x1b[2J\x1b[H"));
        assert!(frame.contains("caly"));
        assert!(frame.contains("CORE"));
        assert!(frame.contains("TRAFFIC"));
        assert!(frame.contains("NODES"));
        assert!(frame.contains("running"));
        Ok(())
    }

    #[test]
    fn frame_flushes_for_tiny_terminal() -> Result<(), Box<dyn std::error::Error>> {
        let renderer = Renderer::new(Theme::tty());
        let frame = renderer.render_frame(&snapshot()?, 5, 3);
        assert!(frame.ends_with("\x1b[0m"));
        Ok(())
    }

    #[test]
    fn header_registers_refresh_hotzones() -> Result<(), Box<dyn std::error::Error>> {
        let renderer = Renderer::default();
        let frame = renderer.frame(&snapshot()?, 80, 24);
        assert!(!frame.hotzones().is_empty());
        // The "+" button sits two columns from the right edge of the header.
        let plus = Renderer::resolve_click(&frame, 78, 0);
        assert_eq!(
            plus.map(HotZone::action),
            Some(super::action::Action::AdjustRefresh(100))
        );
        let minus = Renderer::resolve_click(&frame, 76, 0);
        assert_eq!(
            minus.map(HotZone::action),
            Some(super::action::Action::AdjustRefresh(-100))
        );
        Ok(())
    }
}
