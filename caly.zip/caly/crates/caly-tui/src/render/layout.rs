//! Overflow-safe rectangle geometry and panel layout.

/// Height of the full-width header row.
pub const HEADER_ROWS: usize = 1;

/// A non-overflowing rectangle in terminal cell coordinates.
#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub struct Rect {
    col: usize,
    row: usize,
    width: usize,
    height: usize,
}

impl Rect {
    /// Constructs a rectangle clipped to non-negative cell bounds.
    pub const fn new(col: usize, row: usize, width: usize, height: usize) -> Self {
        Self {
            col,
            row,
            width,
            height,
        }
    }

    /// Left column.
    pub const fn col(self) -> usize {
        self.col
    }
    /// Top row.
    pub const fn row(self) -> usize {
        self.row
    }
    /// Width in columns.
    pub const fn width(self) -> usize {
        self.width
    }
    /// Height in rows.
    pub const fn height(self) -> usize {
        self.height
    }
    /// One-past-the-last column.
    pub const fn right(self) -> usize {
        self.col.saturating_add(self.width)
    }
    /// One-past-the-last row.
    pub const fn bottom(self) -> usize {
        self.row.saturating_add(self.height)
    }
}

/// A named screen region for one panel.
#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub enum PanelArea {
    Header,
    Core,
    Traffic,
    Platform,
    Nodes,
    Capabilities,
}

/// Computed layout for a terminal size.
#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub struct Layout {
    header: Rect,
    core: Rect,
    traffic: Rect,
    platform: Rect,
    nodes: Rect,
    capabilities: Rect,
}

impl Layout {
    /// Computes a deterministic two-column layout from a terminal size.
    pub fn compute(cols: usize, rows: usize) -> Self {
        let header = Rect::new(0, 0, cols, HEADER_ROWS);
        let body_rows = rows.saturating_sub(HEADER_ROWS);
        let body_top = HEADER_ROWS;
        let left_w = cols.saturating_mul(2) / 5;
        let right_col = left_w;
        let right_w = cols.saturating_sub(right_col);

        let core_h = body_rows / 3;
        let traffic_h = body_rows / 3;
        let platform_h = body_rows.saturating_sub(core_h).saturating_sub(traffic_h);
        let nodes_h = body_rows.saturating_mul(3) / 4;
        let cap_h = body_rows.saturating_sub(nodes_h);

        Self {
            header,
            core: Rect::new(0, body_top, left_w, core_h),
            traffic: Rect::new(0, body_top.saturating_add(core_h), left_w, traffic_h),
            platform: Rect::new(
                0,
                body_top.saturating_add(core_h).saturating_add(traffic_h),
                left_w,
                platform_h,
            ),
            nodes: Rect::new(right_col, body_top, right_w, nodes_h),
            capabilities: Rect::new(right_col, body_top.saturating_add(nodes_h), right_w, cap_h),
        }
    }

    /// Returns the rectangle for a panel area.
    pub const fn rect(&self, area: PanelArea) -> Rect {
        match area {
            PanelArea::Header => self.header,
            PanelArea::Core => self.core,
            PanelArea::Traffic => self.traffic,
            PanelArea::Platform => self.platform,
            PanelArea::Nodes => self.nodes,
            PanelArea::Capabilities => self.capabilities,
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn rect_bounds_never_overflow() {
        let rect = Rect::new(5, 3, usize::MAX, usize::MAX);
        assert_eq!(rect.right(), usize::MAX);
        assert_eq!(rect.bottom(), usize::MAX);
    }

    #[test]
    fn layout_covers_full_height_without_gaps() {
        let layout = Layout::compute(100, 25);
        let body_top = HEADER_ROWS;
        assert_eq!(layout.header.row(), 0);
        assert_eq!(layout.header.height(), 1);
        assert_eq!(layout.header.width(), 100);
        assert_eq!(layout.core.row(), body_top);
        assert_eq!(layout.platform.bottom(), 25);
        assert_eq!(layout.nodes.right(), 100);
        assert_eq!(layout.capabilities.bottom(), 25);
    }

    #[test]
    fn narrow_terminal_stays_in_bounds() {
        let layout = Layout::compute(10, 3);
        assert_eq!(layout.header.right(), 10);
        assert!(layout.nodes.right() <= 10);
        assert!(layout.platform.bottom() <= 3);
    }
}
