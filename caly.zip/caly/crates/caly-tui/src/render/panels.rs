//! Snapshot-to-canvas drawing for each panel area.

use caly_domain::{NodeId, PresentationSnapshot};

use super::action::Action;
use super::canvas::Canvas;
use super::format::{
    bool_label, capability_label, clip, format_bps, hex, kv, ordered_nodes, state_label,
    state_style,
};
use super::hotzone::{HotZone, HotZoneRegistry};
use super::layout::{Layout, PanelArea, Rect};
use super::style::{Style, Theme};

/// Draws every panel onto the canvas for a snapshot.
pub fn draw_all(
    canvas: &mut Canvas,
    layout: &Layout,
    snapshot: &PresentationSnapshot,
    theme: &Theme,
    hotzones: &mut HotZoneRegistry,
    node_order: Option<&[NodeId]>,
) {
    for area in [
        PanelArea::Header,
        PanelArea::Core,
        PanelArea::Traffic,
        PanelArea::Platform,
        PanelArea::Nodes,
        PanelArea::Capabilities,
    ] {
        draw_area(
            canvas,
            layout.rect(area),
            area,
            snapshot,
            theme,
            hotzones,
            node_order,
        );
    }
}

fn draw_area(
    canvas: &mut Canvas,
    rect: Rect,
    area: PanelArea,
    snapshot: &PresentationSnapshot,
    theme: &Theme,
    hotzones: &mut HotZoneRegistry,
    node_order: Option<&[NodeId]>,
) {
    match area {
        PanelArea::Header => draw_header(canvas, rect, snapshot, theme, hotzones),
        PanelArea::Core => draw_core(canvas, rect, snapshot, theme),
        PanelArea::Traffic => draw_traffic(canvas, rect, snapshot, theme),
        PanelArea::Platform => draw_platform(canvas, rect, snapshot, theme),
        PanelArea::Nodes => draw_nodes(canvas, rect, snapshot, theme, node_order),
        PanelArea::Capabilities => draw_capabilities(canvas, rect, snapshot, theme),
    }
}

fn draw_header(
    canvas: &mut Canvas,
    rect: Rect,
    snapshot: &PresentationSnapshot,
    theme: &Theme,
    hotzones: &mut HotZoneRegistry,
) {
    let bar = Style::plain(theme.background).on(theme.accent);
    canvas.fill_rect(rect, ' ', bar);
    let text = format!(
        "caly  daemon {}  rev:{}  {:?}",
        hex(snapshot.daemon_instance().into_bytes()),
        snapshot.revision().value(),
        snapshot.applied().run_state()
    );
    canvas.text(rect.row(), rect.col(), &text, Style::bold(theme.background));
    if rect.width() >= 4 {
        let minus_col = rect.right().saturating_sub(4);
        let plus_col = rect.right().saturating_sub(2);
        canvas.text(rect.row(), minus_col, "-", Style::bold(theme.background));
        canvas.text(rect.row(), plus_col, "+", Style::bold(theme.background));
        hotzones.register(HotZone::new(
            Rect::new(minus_col, rect.row(), 1, rect.height()),
            Action::AdjustRefresh(-100),
        ));
        hotzones.register(HotZone::new(
            Rect::new(plus_col, rect.row(), 1, rect.height()),
            Action::AdjustRefresh(100),
        ));
    }
}

fn draw_core(canvas: &mut Canvas, rect: Rect, snapshot: &PresentationSnapshot, theme: &Theme) {
    canvas.panel(rect, "CORE", theme);
    let applied = snapshot.applied();
    let state = applied.run_state();
    let mut row = rect.row().saturating_add(1);
    kv(
        canvas,
        rect,
        row,
        "run:",
        state_label(state),
        state_style(state, theme),
    );
    row = row.saturating_add(1);
    let core = applied
        .core()
        .map_or_else(|| "-".to_owned(), |core| format!("{core:?}"));
    kv(
        canvas,
        rect,
        row,
        "core:",
        &core,
        Style::plain(theme.foreground),
    );
    row = row.saturating_add(1);
    let generation = applied
        .config_generation()
        .map_or_else(|| "-".to_owned(), |value| value.to_string());
    kv(
        canvas,
        rect,
        row,
        "gen:",
        &generation,
        Style::plain(theme.foreground),
    );
    row = row.saturating_add(1);
    let mode = format!("{:?}", snapshot.desired().mode());
    kv(
        canvas,
        rect,
        row,
        "mode:",
        &mode,
        Style::plain(theme.foreground),
    );
}

fn draw_traffic(canvas: &mut Canvas, rect: Rect, snapshot: &PresentationSnapshot, theme: &Theme) {
    canvas.panel(rect, "TRAFFIC", theme);
    let observed = snapshot.observed();
    let mut row = rect.row().saturating_add(1);
    kv(
        canvas,
        rect,
        row,
        "up:",
        &format_bps(observed.upload_bytes_per_second()),
        Style::plain(theme.ok),
    );
    row = row.saturating_add(1);
    kv(
        canvas,
        rect,
        row,
        "down:",
        &format_bps(observed.download_bytes_per_second()),
        Style::plain(theme.accent),
    );
    row = row.saturating_add(1);
    kv(
        canvas,
        rect,
        row,
        "conn:",
        &observed.active_connections().to_string(),
        Style::plain(theme.foreground),
    );
    row = row.saturating_add(1);
    kv(
        canvas,
        rect,
        row,
        "dropped:",
        &observed.telemetry_dropped().to_string(),
        Style::plain(theme.muted),
    );
}

fn draw_platform(canvas: &mut Canvas, rect: Rect, snapshot: &PresentationSnapshot, theme: &Theme) {
    canvas.panel(rect, "PLATFORM", theme);
    let platform = snapshot.platform();
    let mut row = rect.row().saturating_add(1);
    kv(
        canvas,
        rect,
        row,
        "proxy:",
        &bool_label(platform.proxy_engaged()),
        Style::plain(theme.foreground),
    );
    row = row.saturating_add(1);
    kv(
        canvas,
        rect,
        row,
        "tun:",
        &bool_label(platform.tun_engaged()),
        Style::plain(theme.foreground),
    );
    row = row.saturating_add(1);
    kv(
        canvas,
        rect,
        row,
        "recovery:",
        &bool_label(platform.recovery_pending()),
        Style::plain(theme.foreground),
    );
    if let Some(reason) = platform.degraded_reason() {
        let row = row.saturating_add(1);
        canvas.text(
            row,
            rect.col().saturating_add(2),
            reason.as_str(),
            Style::plain(theme.warn),
        );
    }
}

fn draw_nodes(
    canvas: &mut Canvas,
    rect: Rect,
    snapshot: &PresentationSnapshot,
    theme: &Theme,
    node_order: Option<&[NodeId]>,
) {
    canvas.panel(rect, "NODES", theme);
    let mut row = rect.row().saturating_add(1);
    let mut col = rect.col().saturating_add(2);
    canvas.text(row, col, "name", Style::bold(theme.accent));
    col = col.saturating_add(24);
    canvas.text(row, col, "proto", Style::bold(theme.accent));
    col = col.saturating_add(10);
    canvas.text(row, col, "lat", Style::bold(theme.accent));
    row = row.saturating_add(1);
    for node in ordered_nodes(snapshot, node_order).take(rect.height().saturating_sub(2)) {
        let mut col = rect.col().saturating_add(2);
        canvas.text(
            row,
            col,
            clip(node.name().as_str(), 24),
            Style::plain(theme.foreground),
        );
        col = col.saturating_add(24);
        canvas.text(
            row,
            col,
            node.protocol().as_str(),
            Style::plain(theme.muted),
        );
        col = col.saturating_add(10);
        let latency = node
            .latency_ms()
            .map_or_else(|| "-".to_owned(), |value| value.to_string());
        canvas.text(row, col, &latency, Style::plain(theme.muted));
        row = row.saturating_add(1);
    }
}

fn draw_capabilities(
    canvas: &mut Canvas,
    rect: Rect,
    snapshot: &PresentationSnapshot,
    theme: &Theme,
) {
    canvas.panel(rect, "CAPABILITIES", theme);
    let mut row = rect.row().saturating_add(1);
    for status in snapshot
        .capabilities()
        .iter()
        .take(rect.height().saturating_sub(1))
    {
        let label = capability_label(status.capability());
        let usable = status.is_usable();
        let color = if usable { theme.ok } else { theme.warn };
        canvas.text(
            row,
            rect.col().saturating_add(2),
            &format!("{label:<12} {}", if usable { "usable" } else { "unusable" }),
            Style::plain(color),
        );
        row = row.saturating_add(1);
    }
}
