//! Colors, text styles and themes for the TUI renderer.
//!
//! The renderer emits 24-bit ANSI RGB escape sequences. A `Theme` maps named
//! UI roles to concrete RGB triples so the draw code stays theme-agnostic.

/// A 24-bit RGB color.
#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub struct Rgb {
    r: u8,
    g: u8,
    b: u8,
}

impl Rgb {
    /// Constructs an RGB color.
    pub const fn new(r: u8, g: u8, b: u8) -> Self {
        Self { r, g, b }
    }

    /// Parses a `0xRRGGBB` value.
    pub const fn from_hex(value: u32) -> Self {
        Self {
            r: ((value >> 16) & 0xff) as u8,
            g: ((value >> 8) & 0xff) as u8,
            b: (value & 0xff) as u8,
        }
    }

    /// Red channel.
    pub const fn r(self) -> u8 {
        self.r
    }
    /// Green channel.
    pub const fn g(self) -> u8 {
        self.g
    }
    /// Blue channel.
    pub const fn b(self) -> u8 {
        self.b
    }
}

/// Text style applied to a cell or run.
#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub struct Style {
    fg: Rgb,
    bg: Option<Rgb>,
    bold: bool,
}

impl Style {
    /// Plain foreground text.
    pub const fn plain(fg: Rgb) -> Self {
        Self {
            fg,
            bg: None,
            bold: false,
        }
    }

    /// Bold foreground text.
    pub const fn bold(fg: Rgb) -> Self {
        Self {
            fg,
            bg: None,
            bold: true,
        }
    }

    /// Adds a background color.
    #[must_use]
    pub const fn on(mut self, bg: Rgb) -> Self {
        self.bg = Some(bg);
        self
    }

    /// Returns the foreground color.
    pub const fn fg(self) -> Rgb {
        self.fg
    }
    /// Returns the background color, if any.
    pub const fn bg(self) -> Option<Rgb> {
        self.bg
    }
    /// Returns whether the text is bold.
    pub const fn is_bold(self) -> bool {
        self.bold
    }
}

/// Named palette used across all panels.
#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub struct Theme {
    pub background: Rgb,
    pub foreground: Rgb,
    pub accent: Rgb,
    pub muted: Rgb,
    pub border: Rgb,
    pub ok: Rgb,
    pub warn: Rgb,
    pub error: Rgb,
}

impl Default for Theme {
    fn default() -> Self {
        Self {
            background: Rgb::from_hex(0x1b_1f_27),
            foreground: Rgb::from_hex(0xd5_d8_de),
            accent: Rgb::from_hex(0x61_af_ef),
            muted: Rgb::from_hex(0x6a_73_82),
            border: Rgb::from_hex(0x3a_42_50),
            ok: Rgb::from_hex(0x98_c3_79),
            warn: Rgb::from_hex(0xd1_9a_66),
            error: Rgb::from_hex(0xe0_6c_75),
        }
    }
}

impl Theme {
    /// A high-contrast palette for legacy 16-color terminals.
    pub const fn tty() -> Self {
        Self {
            background: Rgb::from_hex(0x00_00_00),
            foreground: Rgb::from_hex(0xc0_c0_c0),
            accent: Rgb::from_hex(0xff_ff_ff),
            muted: Rgb::from_hex(0x80_80_80),
            border: Rgb::from_hex(0x60_60_60),
            ok: Rgb::from_hex(0x00_ff_00),
            warn: Rgb::from_hex(0xff_ff_00),
            error: Rgb::from_hex(0xff_00_00),
        }
    }
}

/// ANSI 24-bit foreground escape.
pub fn ansi_fg(color: Rgb) -> String {
    format!("\x1b[38;2;{};{};{}m", color.r(), color.g(), color.b())
}

/// ANSI 24-bit background escape.
pub fn ansi_bg(color: Rgb) -> String {
    format!("\x1b[48;2;{};{};{}m", color.r(), color.g(), color.b())
}

/// ANSI bold escape.
pub fn ansi_bold() -> &'static str {
    "\x1b[1m"
}

/// ANSI reset escape.
pub fn ansi_reset() -> &'static str {
    "\x1b[0m"
}

/// ANSI cursor position escape for `(row, col)` in 1-based terminal coords.
pub fn ansi_move(row: usize, col: usize) -> String {
    format!("\x1b[{};{}H", row.saturating_add(1), col.saturating_add(1))
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn hex_parsing_extracts_channels() {
        let color = Rgb::from_hex(0x98_c3_79);
        assert_eq!((color.r(), color.g(), color.b()), (0x98, 0xc3, 0x79));
    }

    #[test]
    fn style_marks_bold_and_background() {
        let style = Style::plain(Rgb::new(1, 2, 3)).on(Rgb::new(4, 5, 6));
        assert!(!style.is_bold());
        assert_eq!(style.bg(), Some(Rgb::new(4, 5, 6)));
        assert!(Style::bold(Rgb::new(1, 1, 1)).is_bold());
    }

    #[test]
    fn ansi_escapes_are_well_formed() {
        assert_eq!(ansi_fg(Rgb::new(1, 2, 3)), "\x1b[38;2;1;2;3m");
        assert_eq!(ansi_bg(Rgb::new(4, 5, 6)), "\x1b[48;2;4;5;6m");
        assert_eq!(ansi_move(0, 0), "\x1b[1;1H");
        assert_eq!(ansi_move(2, 3), "\x1b[3;4H");
    }
}
