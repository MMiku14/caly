//! Clickable hot zones registered during drawing.
//!
//! Mirrors btop's `mouse_mappings`: every drawn interactive element records
//! its on-screen rectangle and the action it triggers. A later mouse click is
//! resolved against the registry by coordinates.

use super::action::Action;
use super::layout::Rect;

/// A clickable screen region bound to an action.
#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub struct HotZone {
    rect: Rect,
    action: Action,
}

impl HotZone {
    /// Constructs a clickable region.
    pub const fn new(rect: Rect, action: Action) -> Self {
        Self { rect, action }
    }

    /// The clickable rectangle.
    pub const fn rect(self) -> Rect {
        self.rect
    }
    /// The action triggered by a click.
    pub const fn action(self) -> Action {
        self.action
    }
}

/// Ordered registry of hot zones for one rendered frame.
#[derive(Clone, Debug, Default, Eq, PartialEq)]
pub struct HotZoneRegistry {
    zones: Vec<HotZone>,
}

impl HotZoneRegistry {
    /// Begins a new frame, discarding stale zones.
    pub fn clear(&mut self) {
        self.zones.clear();
    }

    /// Registers a clickable region; later registrations take priority.
    pub fn register(&mut self, zone: HotZone) {
        self.zones.push(zone);
    }

    /// Returns the last-registered zone containing `(col, row)`.
    pub fn resolve(&self, col: usize, row: usize) -> Option<HotZone> {
        self.zones
            .iter()
            .rev()
            .find(|zone| {
                let rect = zone.rect();
                col >= rect.col() && col < rect.right() && row >= rect.row() && row < rect.bottom()
            })
            .copied()
    }

    /// Number of registered zones.
    pub fn len(&self) -> usize {
        self.zones.len()
    }

    /// Whether no zones are registered.
    pub fn is_empty(&self) -> bool {
        self.zones.is_empty()
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    fn zone(col: usize, row: usize, w: usize, h: usize, action: Action) -> HotZone {
        HotZone::new(Rect::new(col, row, w, h), action)
    }

    #[test]
    fn resolve_finds_containing_zone() {
        let mut registry = HotZoneRegistry::default();
        registry.register(zone(5, 5, 4, 3, Action::AdjustRefresh(100)));
        assert_eq!(
            registry.resolve(6, 6).map(HotZone::action),
            Some(Action::AdjustRefresh(100))
        );
        assert_eq!(registry.resolve(4, 6).map(HotZone::action), None);
        assert_eq!(registry.resolve(9, 6).map(HotZone::action), None);
        assert_eq!(registry.resolve(6, 8).map(HotZone::action), None);
    }

    #[test]
    fn last_registered_wins_on_overlap() {
        let mut registry = HotZoneRegistry::default();
        registry.register(zone(0, 0, 10, 10, Action::NextPreset));
        registry.register(zone(2, 2, 3, 3, Action::PrevPreset));
        assert_eq!(
            registry.resolve(3, 3).map(HotZone::action),
            Some(Action::PrevPreset)
        );
        assert_eq!(
            registry.resolve(1, 1).map(HotZone::action),
            Some(Action::NextPreset)
        );
    }

    #[test]
    fn clear_drops_zones() {
        let mut registry = HotZoneRegistry::default();
        registry.register(zone(0, 0, 2, 2, Action::Quit));
        registry.clear();
        assert!(registry.is_empty());
        assert_eq!(registry.resolve(0, 0).map(HotZone::action), None);
    }
}
