//! Incremental bounded editor state.

mod history;

pub use history::{EditBytes, EditHistory, HistoryError, TextEdit};
