//! Thin-client presentation model.

mod session;

pub use session::{DeltaApplyError, SelectionError, SelectionOutcome, SessionModel};
