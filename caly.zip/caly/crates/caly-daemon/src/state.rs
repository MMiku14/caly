use caly_api::{ProfileId, ProtocolVersion, Role};
use caly_engine::EngineLifecycle;

/// The daemon's self-reported name. Also the first line of a support bundle, so it is a constant
/// rather than a literal repeated in two files.
pub const DAEMON_NAME: &str = "calyd";
/// The daemon's self-reported version (`RFC-0010 §12.2`: a bundle carries version information).
pub const DAEMON_VERSION: &str = "0.1.0-dev";

#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub enum DaemonLifecycle {
    Stopped,
    Starting,
    Running,
    Recovering,
    Failed,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct DaemonRuntimeState {
    pub lifecycle: DaemonLifecycle,
    pub instance_id: String,
    pub daemon_name: String,
    pub daemon_version: String,
    pub protocol_version: ProtocolVersion,
    pub engine_lifecycle: EngineLifecycle,
    pub state_revision: u64,
    pub next_stream_id: u64,
    pub active_profile: Option<ProfileId>,
    pub active_core: Option<String>,
    pub active_snapshot: Option<String>,
    pub last_apply_plan_summary: Option<String>,
    pub pending_recovery_decisions: usize,
    pub last_recovery_summary: Option<String>,
    pub last_error: Option<String>,
    /// The role an **in-process** caller is treated as (`ADR-037 §2.2`). Deliberately not `Admin`:
    /// `RFC-0002 §7.2` makes `required_role` a real gate, so the local path may not hand out the
    /// highest privilege by default the way it used to (both façades hardcoded `Admin`, which made the
    /// check unfailable).
    pub local_role: Role,
    /// Monotonic per-request identity for local calls. The remote path gets this from
    /// `ClientSession::next_request_id`; the local façade used to put `RequestId(0)` on **every**
    /// request, and since `Command.id` is derived from it, every local command shared the id `req-0`
    /// (`docs/history/ONBOARDING_NOTES.md §4.61`).
    pub next_request_id: u64,
    /// How many `Idempotency::Required` submissions were refused for carrying no usable key.
    /// A counter rather than only an error: a caller that keeps retrying without a key looks like a
    /// daemon bug from the outside, and `doctor` is where that gets settled.
    pub idempotency_key_refusals: u64,
}

impl DaemonRuntimeState {
    pub fn new(instance_id: impl Into<String>, protocol_version: ProtocolVersion) -> Self {
        Self {
            lifecycle: DaemonLifecycle::Stopped,
            instance_id: instance_id.into(),
            daemon_name: DAEMON_NAME.to_owned(),
            daemon_version: DAEMON_VERSION.to_owned(),
            protocol_version,
            engine_lifecycle: EngineLifecycle::Idle,
            state_revision: 0,
            next_stream_id: 1,
            active_profile: None,
            active_core: None,
            active_snapshot: None,
            last_apply_plan_summary: None,
            pending_recovery_decisions: 0,
            last_recovery_summary: None,
            last_error: None,
            local_role: Role::Operator,
            next_request_id: 1,
            idempotency_key_refusals: 0,
        }
    }

    pub fn allocate_request_id(&mut self) -> u64 {
        let next = self.next_request_id;
        self.next_request_id = self.next_request_id.saturating_add(1);
        next
    }

    pub fn allocate_stream_id(&mut self) -> u64 {
        let next = self.next_stream_id;
        self.next_stream_id = self.next_stream_id.saturating_add(1);
        next
    }
}
