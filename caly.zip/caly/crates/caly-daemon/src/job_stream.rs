//! The job-stream pump: the first real `IPC_STREAM_POLICY` implementation.
//!
//! A Job stream is `LosslessResumable` with `AckPolicy::Required` and no reset-on-gap: the
//! pump may neither drop a line nor silently skip over one. Fed the **same paged reads**
//! `jobs.events` serves (`JobEventsView` from the caller's cursor), it decides one step at a
//! time what the stream owes the client next:
//!
//! * `Data` — new contiguous lines plus the resume cursor they end at;
//! * `Gap` — the asked position is no longer retained (`reset_required`); a lossless stream
//!   must say so and hand back a resume position, never jump;
//! * `End` — the job is terminal **and** every line has been flushed (an `End` before the
//!   lines is a lie about completeness);
//! * `Wait` — nothing new and not terminal; an empty `Data` push would claim work happened.
//!
//! The v0 wire carries acks implicitly (one connection, ordered frames); explicit ack frames
//! belong to the reconnect/resume path (`IPC_STREAM_POLICY §5`) and are deliberately not
//! invented here.

use caly_api::JobEventsView;
use caly_ipc::JobOutcome;

#[derive(Clone, Debug, Eq, PartialEq)]
pub enum PumpStep {
    Data {
        seq: u64,
        lines: Vec<String>,
        next_event_index: u64,
    },
    Gap {
        resume_from: u64,
    },
    End {
        seq: u64,
        outcome: JobOutcome,
        state: String,
    },
    Wait,
}

/// Terminal states map to outcomes; anything else is not terminal, and the pump does not
/// guess ("waiting_input" is a state, not a verdict).
fn outcome_for(state: &str) -> Option<JobOutcome> {
    match state {
        "completed" => Some(JobOutcome::Succeeded),
        "failed" => Some(JobOutcome::Failed),
        "cancelled" => Some(JobOutcome::Cancelled),
        // Engine state strings are `{:?}`-lowered: `TimedOut` → `timedout`, no underscore.
        "timedout" => Some(JobOutcome::TimedOut),
        _ => None,
    }
}

#[derive(Default)]
pub struct JobStreamPump {
    cursor: Option<u64>,
    seq: u64,
}

impl JobStreamPump {
    pub fn new() -> Self {
        Self::default()
    }

    /// The exclusive request cursor: the last event index this pump has already delivered
    /// (`None` = nothing delivered yet — read from the open position). Feeding it straight
    /// back into `from_event_index` resumes at the first UNDELIVERED event, because the
    /// slice's request cursor is exclusive ("I already have through N"). This pump used to
    /// keep "the next index I need" here instead, which made a page that ended exactly on
    /// the live edge (or an empty first page) skip one event on the next read — the loss the
    /// round-120 first-event judge pins.
    pub fn cursor(&self) -> Option<u64> {
        self.cursor
    }

    pub fn step(&mut self, page: &JobEventsView) -> PumpStep {
        if page.reset_required {
            // The asked position is no longer covered. A lossless stream cannot skip: name
            // the EXCLUSIVE CURSOR whose next read lands exactly on the oldest retained
            // line — `IPC_STREAM_POLICY §5.1`: every feedable value on this stream is an
            // exclusive request cursor ("I have through N"), and this field goes verbatim
            // into the state-gap END frame and the CLI's `--from` hint. A gap only fires
            // once at least two events were trimmed, so the subtraction cannot underflow
            // for a real window; `saturating_sub` is belt-braces for synthetic pages.
            return PumpStep::Gap {
                resume_from: page.retained_from_event_index.saturating_sub(1),
            };
        }
        // An empty page sets NO cursor: nothing has been delivered, so the next read starts
        // from the open position again (a fresh open's start; a resume's acked position).
        // Seeding the window's retained edge here would make the next exclusive read skip
        // that very event once it exists — the exact loss this round closed.
        if !page.events.is_empty() {
            self.seq += 1;
            // Both page cursor forms mean "the last index returned" — the exclusive request
            // cursor. A page that ran to the live edge must translate: `next_event_index`
            // is the first index NOT yet delivered, so the last delivered is one below.
            // (Saturating: a non-empty page always has next_event_index >= 1.)
            let next = page
                .next_from_event_index
                .unwrap_or(page.next_event_index.saturating_sub(1));
            self.cursor = Some(next);
            return PumpStep::Data {
                seq: self.seq,
                lines: page.events.clone(),
                next_event_index: next,
            };
        }
        match outcome_for(&page.state) {
            Some(outcome) => PumpStep::End {
                seq: self.seq,
                outcome,
                state: page.state.clone(),
            },
            None => PumpStep::Wait,
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use caly_api::JobId;

    fn page(state: &str, events: &[&str], next: u64, retained_from: u64) -> JobEventsView {
        JobEventsView {
            job_id: JobId(1),
            state: state.to_owned(),
            events: events.iter().map(|line| line.to_string()).collect(),
            next_event_index: next,
            retained_from_event_index: retained_from,
            reset_required: false,
            byte_len: 0,
            next_from_event_index: None,
        }
    }

    /// A terminal job replays its whole window and then ends — and the `End` only comes
    /// after the flush: the data frame carries every line, the end frame carries the
    /// verdict. An `End` before the lines would be a lie about completeness.
    #[test]
    fn a_terminal_job_flushes_then_ends() {
        let mut pump = JobStreamPump::new();
        let first = pump.step(&page("completed", &["a", "b", "c"], 3, 0));
        assert_eq!(
            first,
            PumpStep::Data {
                seq: 1,
                lines: vec!["a".to_owned(), "b".to_owned(), "c".to_owned()],
                // the LAST delivered index (2), not the live edge (3): the cursor is the
                // exclusive request cursor, so the next read starts at the first undelivered
                next_event_index: 2,
            }
        );
        assert_eq!(pump.cursor(), Some(2));
        let second = pump.step(&page("completed", &[], 3, 0));
        assert_eq!(
            second,
            PumpStep::End {
                seq: 1,
                outcome: JobOutcome::Succeeded,
                state: "completed".to_owned(),
            }
        );
    }

    /// A growing job is served as contiguous deltas: each `Data` push's lines are exactly the
    /// window range `[next - len, next)`, so no line is repeated, none is skipped, and the
    /// seq advances once per push — never for an empty one.
    #[test]
    fn a_growing_job_is_served_as_contiguous_deltas() {
        let mut pump = JobStreamPump::new();
        // The pump's contract: every page fed in is the read **from the pump's cursor** —
        // the caller re-reads at `cursor()` each tick, so a page's lines are always the new
        // ones. (page, what the step must be)
        let steps: Vec<(JobEventsView, &str)> = vec![
            (page("running", &["l0"], 1, 0), "data"),
            (page("running", &[], 1, 0), "wait"), // no news → Wait, not an empty Data
            (page("running", &["l1", "l2"], 3, 0), "data"),
            (page("completed", &["l3"], 4, 0), "data"),
            (page("completed", &[], 4, 0), "end"),
        ];
        let mut pushes = 0u64;
        for (current, expected) in steps {
            match pump.step(&current) {
                PumpStep::Data {
                    seq,
                    lines,
                    next_event_index,
                } => {
                    assert_eq!(expected, "data");
                    pushes += 1;
                    assert_eq!(seq, pushes, "one seq per data push");
                    let len = lines.len() as u64;
                    for (offset, line) in lines.iter().enumerate() {
                        // next_event_index is the LAST delivered index, so line offset 0
                        // sits at next - len + 1
                        let index = next_event_index + 1 - len + offset as u64;
                        assert_eq!(
                            line,
                            &format!("l{index}"),
                            "each pushed line is exactly the window line at its index"
                        );
                    }
                }
                PumpStep::Wait => assert_eq!(expected, "wait"),
                PumpStep::End { outcome, .. } => {
                    assert_eq!(expected, "end");
                    assert_eq!(outcome, JobOutcome::Succeeded);
                }
                PumpStep::Gap { .. } => panic!("no gap in this scenario"),
            }
        }
        assert_eq!(pushes, 3, "three data pushes, no empty ones");
    }

    /// A gap is named, never skipped: `reset_required` hands back the exclusive cursor whose
    /// next read lands ON the oldest retained line, on the first page (asked older than
    /// retained) and on a later one alike.
    #[test]
    fn a_gap_is_named_with_a_resume_position_never_skipped() {
        let mut pump = JobStreamPump::new();
        let mut old_ask = page("running", &["l2", "l3"], 4, 2);
        old_ask.reset_required = true; // asked from 0, window starts at 2
        assert_eq!(
            pump.step(&old_ask),
            PumpStep::Gap { resume_from: 1 },
            "the first page can already be a gap; the cursor lands on line 2"
        );

        let mut pump = JobStreamPump::new();
        assert_eq!(
            pump.step(&page("running", &["l0"], 1, 0)),
            PumpStep::Data {
                seq: 1,
                lines: vec!["l0".to_owned()],
                next_event_index: 0,
            }
        );
        let mut evicted = page("running", &["l5", "l6"], 7, 5);
        evicted.reset_required = true; // the window moved past our cursor
        assert_eq!(
            pump.step(&evicted),
            PumpStep::Gap { resume_from: 4 },
            "a lossless stream hands back a cursor that lands on line 5, it does not jump"
        );
    }

    /// `from: None` means "start of what is still retained" — the first page's
    /// `retained_from_event_index`, even when the history has already been trimmed.
    #[test]
    fn an_absent_from_starts_at_the_retained_edge() {
        let mut pump = JobStreamPump::new();
        let step = pump.step(&page("running", &["l7", "l8"], 9, 7));
        assert_eq!(
            step,
            PumpStep::Data {
                seq: 1,
                lines: vec!["l7".to_owned(), "l8".to_owned()],
                next_event_index: 8,
            }
        );
    }

    /// A failed job still flushes its lines first; the verdict rides the `End`.
    #[test]
    fn a_failed_job_flushes_then_ends_failed() {
        let mut pump = JobStreamPump::new();
        assert!(matches!(
            pump.step(&page("failed", &["w0"], 1, 0)),
            PumpStep::Data { .. }
        ));
        assert_eq!(
            pump.step(&page("failed", &[], 1, 0)),
            PumpStep::End {
                seq: 1,
                outcome: JobOutcome::Failed,
                state: "failed".to_owned(),
            }
        );
    }

    /// An empty page sets no cursor: nothing has been delivered, so the next read must
    /// start from the open position again. Seeding the retained edge here is the exact shape
    /// of the round-120 loss — the first event to arrive after an empty first page was
    /// skipped, because the next exclusive read started one past it.
    #[test]
    fn an_empty_page_leaves_the_cursor_alone() {
        let mut pump = JobStreamPump::new();
        assert_eq!(pump.step(&page("running", &[], 0, 0)), PumpStep::Wait);
        assert_eq!(pump.cursor(), None, "nothing delivered means no cursor");
        // Even when the window already retains events, an empty (fully read) page for THIS
        // pump must not seed one: the pump asked past the edge, the answer was empty.
        let mut pump = JobStreamPump::new();
        assert_eq!(
            pump.step(&page("running", &[], 5, 0)),
            PumpStep::Wait,
            "a caller that already read everything gets a Wait, not a reseeded cursor"
        );
        assert_eq!(pump.cursor(), None);
    }

    /// A page that ran to the live edge reports the LAST delivered index as its cursor (and
    /// on the wire), never the live edge itself: the request cursor is exclusive, so feeding
    /// the live edge back would skip the first event that lands after the page.
    #[test]
    fn a_live_edge_page_cursors_at_the_last_delivered_index() {
        let mut pump = JobStreamPump::new();
        assert_eq!(
            pump.step(&page("running", &["l0", "l1", "l2"], 3, 0)),
            PumpStep::Data {
                seq: 1,
                lines: vec!["l0".to_owned(), "l1".to_owned(), "l2".to_owned()],
                next_event_index: 2,
            }
        );
        assert_eq!(pump.cursor(), Some(2));
        // The window grows by one; the next page is read FROM the cursor exclusively, so it
        // must start at l3 — the event a live-edge cursor would have skipped.
        assert_eq!(
            pump.step(&page("running", &["l3"], 4, 0)),
            PumpStep::Data {
                seq: 2,
                lines: vec!["l3".to_owned()],
                next_event_index: 3,
            }
        );
    }

    /// Round 121: the gap's `resume_from` is the EXCLUSIVE CURSOR whose next read lands
    /// exactly on the oldest retained line — the value the state-gap END frame puts on the
    /// wire and the CLI tells the operator to feed back to `--from`. Composed from the REAL
    /// slice and the REAL pump (only the record is synthetic: the engine's own note says no
    /// real fixture is big enough to trip retention, `job_follow.rs` tests), the judge does
    /// what the operator does: take the hinted value, put it straight into `from_event_index`,
    /// and demand the oldest retained line comes back first — nothing skipped, nothing
    /// re-delivered.
    #[test]
    fn a_gap_hands_back_a_cursor_that_lands_on_the_oldest_retained_line() {
        use caly_engine::job::{JobEvent, JobRecord, JobState};
        use caly_engine::job_follow::{slice_job_events, JobEventRetentionPolicy};

        let record = JobRecord {
            id: JobId(1),
            state: JobState::Running,
            revision: 0,
            events: (0..130)
                .map(|index| JobEvent::Stage {
                    stage: format!("step-{index}"),
                    pct: Some(50),
                })
                .collect(),
        };

        // Ask from a position retention no longer covers: 128 of 130 are retained.
        let stale = slice_job_events(&record, Some(0), JobEventRetentionPolicy::default());
        assert!(
            stale.reset_required,
            "asking from 0 past a trimmed window is a gap"
        );
        assert_eq!(stale.retained_from_index, 2, "130 events, 128 retained");

        // The pump turns that page into the state-gap the wire carries.
        let gap_page = JobEventsView {
            job_id: JobId(1),
            state: "running".to_owned(),
            events: Vec::new(),
            next_event_index: stale.next_index,
            retained_from_event_index: stale.retained_from_index,
            reset_required: stale.reset_required,
            byte_len: 0,
            next_from_event_index: None,
        };
        let PumpStep::Gap { resume_from } = JobStreamPump::new().step(&gap_page) else {
            panic!("a reset page must gap, not guess");
        };

        // The operator's move: feed the hinted value straight back as `--from`.
        let resumed = slice_job_events(
            &record,
            Some(resume_from),
            JobEventRetentionPolicy::default(),
        );
        assert!(
            !resumed.reset_required,
            "the hinted cursor must be readable: {resume_from}"
        );
        assert_eq!(
            resumed.first_index, 2,
            "the hinted cursor lands on the OLDEST retained line, not one past it"
        );
        assert_eq!(
            resumed.events.len(),
            128,
            "the whole retained window comes back"
        );
        assert!(matches!(&resumed.events[0], JobEvent::Stage { stage, .. } if stage == "step-2"));
    }

    /// Not every non-success state is a verdict: `waiting_input` is a state, not an outcome,
    /// and the pump must not turn it into one.
    #[test]
    fn a_non_terminal_state_waits_rather_than_guessing_a_verdict() {
        let mut pump = JobStreamPump::new();
        assert_eq!(
            pump.step(&page("waiting_input", &[], 0, 0)),
            PumpStep::Wait,
            "no verdict is invented for a state that is not terminal"
        );
        // The engine's `TimedOut` is spelled `timedout` on the wire (`{:?}`-lowered).
        assert_eq!(
            pump.step(&page("timedout", &[], 0, 0)),
            PumpStep::End {
                seq: 0,
                outcome: JobOutcome::TimedOut,
                state: "timedout".to_owned(),
            }
        );
    }
}
