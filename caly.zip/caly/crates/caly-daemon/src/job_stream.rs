//! The job-stream pump: the first real `IPC_STREAM_POLICY` implementation.
//!
//! A Job stream is `LosslessResumable` with `AckPolicy::Required` and no reset-on-gap: the
//! pump may neither drop a line nor silently skip over one. Fed the **same paged reads**
//! `jobs.events` serves (`JobEventsView` from the caller's cursor), it decides one step at a
//! time what the stream owes the client next:
//!
//! * `Data` — new contiguous lines plus the resume cursor they end at;
//! * `Gap` — the asked position is no longer retained (`reset_required`); a lossless stream
//!   must say so and hand back a resume position, never jump;
//! * `End` — the job is terminal **and** every line has been flushed (an `End` before the
//!   lines is a lie about completeness);
//! * `Wait` — nothing new and not terminal; an empty `Data` push would claim work happened.
//!
//! The v0 wire carries acks implicitly (one connection, ordered frames); explicit ack frames
//! belong to the reconnect/resume path (`IPC_STREAM_POLICY §5`) and are deliberately not
//! invented here.

use caly_api::JobEventsView;
use caly_ipc::JobOutcome;

#[derive(Clone, Debug, Eq, PartialEq)]
pub enum PumpStep {
    Data {
        seq: u64,
        lines: Vec<String>,
        next_event_index: u64,
    },
    Gap {
        resume_from: u64,
    },
    End {
        seq: u64,
        outcome: JobOutcome,
        state: String,
    },
    Wait,
}

/// Terminal states map to outcomes; anything else is not terminal, and the pump does not
/// guess ("waiting_input" is a state, not a verdict).
fn outcome_for(state: &str) -> Option<JobOutcome> {
    match state {
        "completed" => Some(JobOutcome::Succeeded),
        "failed" => Some(JobOutcome::Failed),
        "cancelled" => Some(JobOutcome::Cancelled),
        // Engine state strings are `{:?}`-lowered: `TimedOut` → `timedout`, no underscore.
        "timedout" => Some(JobOutcome::TimedOut),
        _ => None,
    }
}

#[derive(Default)]
pub struct JobStreamPump {
    cursor: Option<u64>,
    seq: u64,
}

impl JobStreamPump {
    pub fn new() -> Self {
        Self::default()
    }

    /// The cursor to read the next page from (`None` = "start of what is retained", the
    /// page's own `retained_from_event_index`).
    pub fn cursor(&self) -> Option<u64> {
        self.cursor
    }

    pub fn step(&mut self, page: &JobEventsView) -> PumpStep {
        if page.reset_required {
            // The asked position is no longer covered. A lossless stream cannot skip: the
            // honest answer names the oldest position still readable.
            return PumpStep::Gap {
                resume_from: page.retained_from_event_index,
            };
        }
        // An absent `from` means "start of what is still retained": the page's own edge.
        if self.cursor.is_none() {
            self.cursor = Some(page.retained_from_event_index);
        }
        if !page.events.is_empty() {
            self.seq += 1;
            // `next_from_event_index` is the exclusive resume cursor of this page; absent
            // means the page reached `next_event_index` (the window's live edge).
            let next = page.next_from_event_index.unwrap_or(page.next_event_index);
            self.cursor = Some(next);
            return PumpStep::Data {
                seq: self.seq,
                lines: page.events.clone(),
                next_event_index: next,
            };
        }
        match outcome_for(&page.state) {
            Some(outcome) => PumpStep::End {
                seq: self.seq,
                outcome,
                state: page.state.clone(),
            },
            None => PumpStep::Wait,
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use caly_api::JobId;

    fn page(state: &str, events: &[&str], next: u64, retained_from: u64) -> JobEventsView {
        JobEventsView {
            job_id: JobId(1),
            state: state.to_owned(),
            events: events.iter().map(|line| line.to_string()).collect(),
            next_event_index: next,
            retained_from_event_index: retained_from,
            reset_required: false,
            byte_len: 0,
            next_from_event_index: None,
        }
    }

    /// A terminal job replays its whole window and then ends — and the `End` only comes
    /// after the flush: the data frame carries every line, the end frame carries the
    /// verdict. An `End` before the lines would be a lie about completeness.
    #[test]
    fn a_terminal_job_flushes_then_ends() {
        let mut pump = JobStreamPump::new();
        let first = pump.step(&page("completed", &["a", "b", "c"], 3, 0));
        assert_eq!(
            first,
            PumpStep::Data {
                seq: 1,
                lines: vec!["a".to_owned(), "b".to_owned(), "c".to_owned()],
                next_event_index: 3,
            }
        );
        assert_eq!(pump.cursor(), Some(3));
        let second = pump.step(&page("completed", &[], 3, 0));
        assert_eq!(
            second,
            PumpStep::End {
                seq: 1,
                outcome: JobOutcome::Succeeded,
                state: "completed".to_owned(),
            }
        );
    }

    /// A growing job is served as contiguous deltas: each `Data` push's lines are exactly the
    /// window range `[next - len, next)`, so no line is repeated, none is skipped, and the
    /// seq advances once per push — never for an empty one.
    #[test]
    fn a_growing_job_is_served_as_contiguous_deltas() {
        let mut pump = JobStreamPump::new();
        // The pump's contract: every page fed in is the read **from the pump's cursor** —
        // the caller re-reads at `cursor()` each tick, so a page's lines are always the new
        // ones. (page, what the step must be)
        let steps: Vec<(JobEventsView, &str)> = vec![
            (page("running", &["l0"], 1, 0), "data"),
            (page("running", &[], 1, 0), "wait"), // no news → Wait, not an empty Data
            (page("running", &["l1", "l2"], 3, 0), "data"),
            (page("completed", &["l3"], 4, 0), "data"),
            (page("completed", &[], 4, 0), "end"),
        ];
        let mut pushes = 0u64;
        for (current, expected) in steps {
            match pump.step(&current) {
                PumpStep::Data {
                    seq,
                    lines,
                    next_event_index,
                } => {
                    assert_eq!(expected, "data");
                    pushes += 1;
                    assert_eq!(seq, pushes, "one seq per data push");
                    let len = lines.len() as u64;
                    for (offset, line) in lines.iter().enumerate() {
                        let index = next_event_index - len + offset as u64;
                        assert_eq!(
                            line,
                            &format!("l{index}"),
                            "each pushed line is exactly the window line at its index"
                        );
                    }
                }
                PumpStep::Wait => assert_eq!(expected, "wait"),
                PumpStep::End { outcome, .. } => {
                    assert_eq!(expected, "end");
                    assert_eq!(outcome, JobOutcome::Succeeded);
                }
                PumpStep::Gap { .. } => panic!("no gap in this scenario"),
            }
        }
        assert_eq!(pushes, 3, "three data pushes, no empty ones");
    }

    /// A gap is named, never skipped: `reset_required` hands back the oldest position still
    /// readable, on the first page (asked older than retained) and on a later one alike.
    #[test]
    fn a_gap_is_named_with_a_resume_position_never_skipped() {
        let mut pump = JobStreamPump::new();
        let mut old_ask = page("running", &["l2", "l3"], 4, 2);
        old_ask.reset_required = true; // asked from 0, window starts at 2
        assert_eq!(
            pump.step(&old_ask),
            PumpStep::Gap { resume_from: 2 },
            "the first page can already be a gap"
        );

        let mut pump = JobStreamPump::new();
        assert_eq!(
            pump.step(&page("running", &["l0"], 1, 0)),
            PumpStep::Data {
                seq: 1,
                lines: vec!["l0".to_owned()],
                next_event_index: 1,
            }
        );
        let mut evicted = page("running", &["l5", "l6"], 7, 5);
        evicted.reset_required = true; // the window moved past our cursor
        assert_eq!(
            pump.step(&evicted),
            PumpStep::Gap { resume_from: 5 },
            "a lossless stream says where it can resume, it does not jump"
        );
    }

    /// `from: None` means "start of what is still retained" — the first page's
    /// `retained_from_event_index`, even when the history has already been trimmed.
    #[test]
    fn an_absent_from_starts_at_the_retained_edge() {
        let mut pump = JobStreamPump::new();
        let step = pump.step(&page("running", &["l7", "l8"], 9, 7));
        assert_eq!(
            step,
            PumpStep::Data {
                seq: 1,
                lines: vec!["l7".to_owned(), "l8".to_owned()],
                next_event_index: 9,
            }
        );
    }

    /// A failed job still flushes its lines first; the verdict rides the `End`.
    #[test]
    fn a_failed_job_flushes_then_ends_failed() {
        let mut pump = JobStreamPump::new();
        assert!(matches!(
            pump.step(&page("failed", &["w0"], 1, 0)),
            PumpStep::Data { .. }
        ));
        assert_eq!(
            pump.step(&page("failed", &[], 1, 0)),
            PumpStep::End {
                seq: 1,
                outcome: JobOutcome::Failed,
                state: "failed".to_owned(),
            }
        );
    }

    /// Not every non-success state is a verdict: `waiting_input` is a state, not an outcome,
    /// and the pump must not turn it into one.
    #[test]
    fn a_non_terminal_state_waits_rather_than_guessing_a_verdict() {
        let mut pump = JobStreamPump::new();
        assert_eq!(
            pump.step(&page("waiting_input", &[], 0, 0)),
            PumpStep::Wait,
            "no verdict is invented for a state that is not terminal"
        );
        // The engine's `TimedOut` is spelled `timedout` on the wire (`{:?}`-lowered).
        assert_eq!(
            pump.step(&page("timedout", &[], 0, 0)),
            PumpStep::End {
                seq: 0,
                outcome: JobOutcome::TimedOut,
                state: "timedout".to_owned(),
            }
        );
    }
}
