//! How much of a job's event window one query reply may carry.
//!
//! Two documented rules make this a daemon concern rather than an engine one:
//!
//! - `RFC-0002 §9`: big collections — 节点、规则、连接、**日志** — **MUST** support paging or streaming
//!   semantics. `ReadJobEvents` is neither incremental nor streamed, so it needs a page.
//! - `RFC-0002 §11.4`: large objects **MUST NOT** be returned as an oversized inline IPC frame; the
//!   frame cap is `caly_ipc::MAX_FRAME_SIZE_BYTES` (4 MiB), and the *response* encoder will happily
//!   build a frame right up to it.
//!
//! Retention already caps the number of events a job keeps (`JobEventRetentionPolicy`), so the count is
//! not actually unbounded — what is unbounded is the *size of one line*, which no retention policy
//! touches. A client that passes 4 000 `JobEvent::Log` lines of a megabyte each still has a response
//! that must be answerable, and the reply must say how much of the window it left out. That is what
//! these numbers do, and why they are clamped: a bound a caller can raise without limit is a suggestion.
//!
//! `docs/history/ONBOARDING_NOTES.md §4.54` records what this file replaced (an unbounded reply plus
//! per-consumer truncation that reported nothing).
//!
//! # The second thing this file bounds
//!
//! `diagnostics.doctor` and `diagnostics.recovery-status` are queries too, and their collections are
//! sized by the **store**, not by the caller: one audit line per finding, one recovery decision per
//! unresolved apply journal. Same two RFC rules apply, so the policy lives here rather than in the
//! query handler that happens to need it today -- `§4.81`'s shape (one fact, one home) applied to a bound.
//!
//! There is deliberately **no request field** for these. `RecoveryStatus` has no request at all, and
//! giving `DoctorRequest` a `max_lines` would change a wire shape to buy something the caller can already
//! get: the support bundle carries the *full* audit finding list (`caly-engine/src/bundle.rs` pushes
//! `audit.finding_lines()` into its `storage-audit` section), it is a stored object rather than a frame,
//! and it is read back with its own `max_bytes`. So the inline answer stays bounded and says so, and the
//! uncut pile is one `ReadSupportBundle` away.

use caly_api::JobEventsRequest;
use caly_engine::JobEventPagePolicy;

/// Lines a caller gets when it asks for none in particular.
///
/// Below the default retention window (128 events) on purpose: a default read should be cheap enough
/// to be a progress display, and a caller that wants the whole window asks for it by size.
pub const DEFAULT_JOB_EVENT_PAGE_LINES: usize = 64;
/// The largest page this daemon will hand out, however much was asked for.
///
/// `≥` the retention window, so "everything you still have" is expressible in one request and is not a
/// magic number a caller has to discover by trial and error.
pub const MAX_JOB_EVENT_PAGE_LINES: usize = 512;

pub const DEFAULT_JOB_EVENT_PAGE_BYTES: u64 = 64 * 1024;
/// `≤ MAX_FRAME_SIZE_BYTES / 3`, so a bounded page plus envelope overhead stays a long way from the
/// frame cap that `caly-ipc` enforces.
pub const MAX_JOB_EVENT_PAGE_BYTES: u64 = 1024 * 1024;

// The relations between the four numbers above are compile-time facts, so they are checked at compile
// time. `the_caps_leave_room_for_the_frame_limit` below keeps the part that is only true *after*
// `resolve` has run — comparing two constants inside `assert!` would be a test that cannot fail, which
// is the same shape of defect this round deleted in `crates/caly-app/src/scenario.rs`.
const _: () = assert!(DEFAULT_JOB_EVENT_PAGE_LINES <= MAX_JOB_EVENT_PAGE_LINES);
const _: () = assert!(DEFAULT_JOB_EVENT_PAGE_BYTES <= MAX_JOB_EVENT_PAGE_BYTES);
const _: () = assert!(MAX_JOB_EVENT_PAGE_BYTES * 3 <= caly_ipc::MAX_FRAME_SIZE_BYTES as u64);

/// How many lines a bulk diagnostic may carry, and how big those lines may be.
///
/// Three numbers because three different things can go wrong. Too many *lines* is a frame problem; one
/// absurdly long line (a `profile_id` or a reason string that grew) is a different problem, and dropping
/// it would delete the very finding that made the list long; and a *byte* budget is what makes the first
/// two sufficient -- a line count alone can still be megabytes.
///
/// The byte cap is deliberately below the transport's own limit even though `caly_ipc` only enforces
/// `MAX_FRAME_SIZE_BYTES` on inbound frames: `encode_raw_json` will build a frame of any size, so nothing
/// in the stack stops a *legal* query from producing a payload that the peer's header validation refuses.
/// That is the failure this file exists to prevent -- an operator losing the diagnostic exactly when the
/// deployment made it necessary, with a transport error instead of an API error.
pub const DIAGNOSTIC_MAX_LINES: usize = 128;
/// Per line. Longer than this and the line is shortened **in place**, with the elision written into the
/// text -- not dropped, and not silently clipped.
pub const DIAGNOSTIC_MAX_LINE_BYTES: usize = 4 * 1024;
/// Across the carried lines of one tier.
pub const DIAGNOSTIC_MAX_BYTES: u64 = 512 * 1024;
/// Room kept back inside that budget for the truncation note itself.
///
/// Without a reservation the note is the one line in the reply that is allowed to break the bound, and a
/// bound with an exception in it is not a bound. The longest note this file can produce is a few hundred
/// bytes; `a_truncation_note_fits_inside_its_reservation` measures it rather than trusting that estimate.
pub const DIAGNOSTIC_NOTE_RESERVE_BYTES: u64 = 1024;

const _: () = assert!(
    DIAGNOSTIC_NOTE_RESERVE_BYTES < DIAGNOSTIC_MAX_BYTES,
    "a reservation larger than the budget would leave nothing to carry"
);

const _: () = assert!(DIAGNOSTIC_MAX_LINES > 0);
const _: () = assert!(
    DIAGNOSTIC_MAX_LINE_BYTES <= DIAGNOSTIC_MAX_BYTES as usize,
    "a per-line cap above the total budget would let one line consume the whole answer"
);
// The same three-way relation `MAX_JOB_EVENT_PAGE_BYTES` keeps: a bounded answer plus envelope overhead
// stays a long way from the frame cap.
const _: () = assert!(DIAGNOSTIC_MAX_BYTES * 3 <= caly_ipc::MAX_FRAME_SIZE_BYTES as u64);

/// The bound applied to a bulk diagnostic list.
///
/// Not configurable by callers on purpose (see this file's header): the support bundle is the escape hatch
/// for "give me everything", and it is a stored object rather than a frame.
#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub struct DiagnosticBudget {
    pub max_lines: usize,
    pub max_line_bytes: usize,
    pub max_bytes: u64,
}

impl DiagnosticBudget {
    /// The budget as this daemon applies it to a bulk tier.
    pub const fn standard() -> Self {
        Self {
            max_lines: DIAGNOSTIC_MAX_LINES,
            max_line_bytes: DIAGNOSTIC_MAX_LINE_BYTES,
            max_bytes: DIAGNOSTIC_MAX_BYTES,
        }
    }

    /// The budget for a tier that will be *appended to* after the cut -- with room already taken for the
    /// note, so the note cannot be the line that breaks the bound.
    pub const fn for_bulk_tier() -> Self {
        Self {
            max_lines: DIAGNOSTIC_MAX_LINES,
            max_line_bytes: DIAGNOSTIC_MAX_LINE_BYTES,
            max_bytes: DIAGNOSTIC_MAX_BYTES - DIAGNOSTIC_NOTE_RESERVE_BYTES,
        }
    }
}

/// A bounded view of a bulk list, carrying the facts a reader needs to judge it.
///
/// `omitted` counts whole lines that were not carried, `shortened` counts lines that were carried but
/// elided. Both are reported separately from `truncated` because they have different repairs: "there were
/// more findings" is answered by the bundle, "this finding's text is cut" is not -- so an operator who sees
/// `truncated` alone cannot tell whether they are missing a fact or the tail of one they can already read.
#[derive(Clone, Debug, Default, Eq, PartialEq)]
pub struct BoundedLines {
    pub lines: Vec<String>,
    /// Bytes the carried lines take, counted the same way `JobEventsView::byte_len` counts them.
    pub byte_len: u64,
    pub omitted: usize,
    pub shortened: usize,
    pub total: usize,
}

impl BoundedLines {
    pub const fn truncated(&self) -> bool {
        self.omitted != 0 || self.shortened != 0
    }

    /// One line, for the tier this list belongs to: says what was cut, which budget cut it, and where the
    /// whole thing is. The budget is an argument rather than a constant read inside, because a note that
    /// quotes `DIAGNOSTIC_MAX_BYTES` under a *tier* budget (which is smaller, by the note's own
    /// reservation) would print a number no reader can reproduce.
    /// `None` when nothing was cut -- an answer that always contains "this may be incomplete" is how a
    /// warning stops being information (`docs/history/ONBOARDING_NOTES.md §4.54`, and the same reason
    /// `diagnostics.rs` deleted its fixed placeholder line).
    pub fn truncation_note(&self, what: &str, budget: DiagnosticBudget) -> Option<String> {
        if !self.truncated() {
            return None;
        }
        Some(format!(
            "{what} truncated for this reply: carried {} of {} line(s), omitted {}, shortened {} \
             (byte_len {} of a {} byte budget); the uncut list is in a support bundle's `storage-audit` \
             section",
            self.lines.len(),
            self.total,
            self.omitted,
            self.shortened,
            self.byte_len,
            budget.max_bytes,
        ))
    }
}

/// Whether `doctor` may append its "no findings requiring action" line.
///
/// Two inputs, and the second one is the whole point: an answer whose tiers are empty *and* whose lists
/// were cut is not a clean bill of health -- it is a report that did not look. As a bare `&&` inside the
/// query arm this rule was unfalsifiable, because the daemon cannot currently produce the combination
/// (the audit aggregates its informational findings into a handful of lines, so an empty `warnings`
/// tier never coexists with a cut). Naming the rule here is what gives it a judge: the four combinations
/// are unit-tested below, and `doctor` calls this instead of re-deciding.
pub fn may_claim_clean(warnings_empty: bool, errors_empty: bool, truncated: bool) -> bool {
    warnings_empty && errors_empty && !truncated
}

/// Apply a [`DiagnosticBudget`] to a list the daemon did not size.
///
/// Two rules are inherited from `caly_engine::job_follow`'s page, on purpose, so that one crate does not
/// grow two answers to "what happens when the first line is already too big":
///
/// 1. **the first line is carried even if it alone exceeds the byte budget** -- an empty list is
///    indistinguishable from "there was nothing", which is the one thing a diagnostic may never be;
/// 2. **`shortened` and `omitted` are counted, not guessed**: the loop stops carrying but keeps counting,
///    so the total the view reports is the real total.
pub fn bound_lines(input: Vec<String>, budget: DiagnosticBudget) -> BoundedLines {
    let mut out = BoundedLines {
        total: input.len(),
        ..BoundedLines::default()
    };
    for line in input {
        if out.lines.len() >= budget.max_lines {
            out.omitted += 1;
            continue;
        }
        let mut line = line;
        if line.len() > budget.max_line_bytes {
            // Cut on a char boundary, and say by how much: `floor_char_boundary` is unstable, so the
            // loop is the portable spelling of "do not panic on utf-8". The marker's own ~20 bytes are
            // not counted against `max_line_bytes` -- that number bounds how much *source* text is
            // carried, and the byte budget below is what bounds the reply.
            let mut keep = budget.max_line_bytes;
            while keep > 0 && !line.is_char_boundary(keep) {
                keep -= 1;
            }
            let elided = line.len() - keep;
            line.truncate(keep);
            line.push_str(&format!("…[{elided} bytes elided]"));
            out.shortened += 1;
        }
        let cost = line.len() as u64 + 1;
        if !out.lines.is_empty() && out.byte_len + cost > budget.max_bytes {
            // Everything from here on is omitted -- including this line. The loop keeps going so that
            // `omitted` counts them all rather than stopping at the first one.
            out.omitted += 1;
            continue;
        }
        out.byte_len += cost;
        out.lines.push(line);
    }
    out
}

/// A resolved page bound: no `Option`, no zero, nothing above the cap.
#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub struct EventPagePolicy {
    pub max_lines: usize,
    pub max_bytes: u64,
}

impl EventPagePolicy {
    /// Turn a client's request into a bound the engine will enforce.
    ///
    /// A zero is refused rather than reinterpreted. "0 lines" is what the caller wrote, and silently
    /// answering it with either the default or the whole window is how a diagnostic tool ends up
    /// reporting that a client saw the log: the reply would carry `next_from_event_index`, so the
    /// only way to notice the substitution is to diff the request against the page size.
    /// `CONFIG_INVALID` is also the code `docs/guides/ERRORS.md §5.1` gives a malformed request.
    pub fn resolve(request: &JobEventsRequest) -> Result<Self, String> {
        let max_lines = match request.max_lines {
            None => DEFAULT_JOB_EVENT_PAGE_LINES,
            Some(0) => return Err(
                "max_lines must be at least 1; omit the field to take the daemon's default page"
                    .to_owned(),
            ),
            Some(lines) => lines as usize,
        };
        let max_bytes = match request.max_bytes {
            None => DEFAULT_JOB_EVENT_PAGE_BYTES,
            Some(0) => return Err(
                "max_bytes must be at least 1; omit the field to take the daemon's default page"
                    .to_owned(),
            ),
            Some(bytes) => bytes,
        };
        Ok(Self {
            max_lines: max_lines.min(MAX_JOB_EVENT_PAGE_LINES),
            max_bytes: max_bytes.min(MAX_JOB_EVENT_PAGE_BYTES),
        })
    }

    pub const fn as_engine_policy(self) -> JobEventPagePolicy {
        JobEventPagePolicy::bounded(self.max_lines, self.max_bytes)
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use caly_api::JobId;

    fn request() -> JobEventsRequest {
        JobEventsRequest::new(JobId(7))
    }

    #[test]
    fn an_unspecified_page_takes_the_default_and_not_the_cap() {
        let policy = EventPagePolicy::resolve(&request()).expect("default policy");
        assert_eq!(
            (policy.max_lines, policy.max_bytes),
            (DEFAULT_JOB_EVENT_PAGE_LINES, DEFAULT_JOB_EVENT_PAGE_BYTES)
        );
        assert!(
            policy.max_lines < 128,
            "the default must be a page, not the retention window it happens to sit inside: {policy:?}"
        );
    }

    /// The cap is the point of the bound, so it has to bite on a request that ignores it — and a unit
    /// test is the only place that is observable, because retention means no real window is bigger
    /// than the page cap.
    #[test]
    fn a_page_larger_than_the_cap_is_clamped_rather_than_served() {
        let policy =
            EventPagePolicy::resolve(&request().with_max_lines(u32::MAX)).expect("clamped");
        assert_eq!(policy.max_lines, MAX_JOB_EVENT_PAGE_LINES);
        let policy =
            EventPagePolicy::resolve(&request().with_max_bytes(u64::MAX)).expect("clamped");
        assert_eq!(policy.max_bytes, MAX_JOB_EVENT_PAGE_BYTES);
    }

    #[test]
    fn a_smaller_page_is_honoured_exactly() {
        let policy = EventPagePolicy::resolve(&request().with_max_lines(3)).expect("policy");
        assert_eq!(policy.max_lines, 3);
        let policy = EventPagePolicy::resolve(&request().with_max_bytes(128)).expect("policy");
        assert_eq!(policy.max_bytes, 128);
    }

    /// A zero is a caller bug, and the two failure modes of "helpfully" accepting it are both worse:
    /// an empty page whose cursor never advances, or a full page the caller did not ask for.
    #[test]
    fn a_zero_bound_is_refused_rather_than_reinterpreted() {
        for (label, request) in [
            ("max_lines", request().with_max_lines(0)),
            ("max_bytes", request().with_max_bytes(0)),
        ] {
            let error = EventPagePolicy::resolve(&request)
                .err()
                .unwrap_or_else(|| panic!("{label} = 0 must be refused"));
            assert!(error.contains(label), "{error}");
            assert!(error.contains("at least 1"), "{error}");
        }
    }

    #[test]
    fn the_caps_leave_room_for_the_frame_limit() {
        // `caly-ipc` rejects a frame over its own cap, so a *resolved* page must not be able to reach
        // it even when the caller asked for `u64::MAX`. The constant-vs-constant half of this lives in
        // `const _` blocks above, where a violation is a build failure instead of a green test.
        let wild =
            EventPagePolicy::resolve(&request().with_max_bytes(u64::MAX).with_max_lines(u32::MAX))
                .expect("clamped");
        assert!(
            wild.max_bytes * 3 <= caly_ipc::MAX_FRAME_SIZE_BYTES as u64,
            "{wild:?}"
        );
        let plain = EventPagePolicy::resolve(&request()).expect("default");
        assert!(
            plain.max_lines <= wild.max_lines && plain.max_bytes <= wild.max_bytes,
            "the default must be inside the cap it is clamped to: {plain:?} vs {wild:?}"
        );
        assert_eq!(wild.max_lines, MAX_JOB_EVENT_PAGE_LINES);
        assert_eq!(wild.max_bytes, MAX_JOB_EVENT_PAGE_BYTES);
    }

    // ---- the diagnostic bound (this file's second job) -------------------------------------------
    //
    // Written against a hand-made budget rather than the public constants wherever a cap is being
    // crossed: the caps are 128 lines / 512 KiB, and a test that wants to see the 129th line omitted
    // must not need 129 lines of production-shaped text to say so. The *public* numbers are exercised
    // once each, below, where a wrong constant is what is being tested.

    fn budget(lines: usize, line_bytes: usize, bytes: u64) -> DiagnosticBudget {
        DiagnosticBudget {
            max_lines: lines,
            max_line_bytes: line_bytes,
            max_bytes: bytes,
        }
    }

    fn lines_of(count: usize, size: usize) -> Vec<String> {
        (0..count)
            .map(|i| format!("{i:04}{}", ".".repeat(size)))
            .collect()
    }

    /// Nothing cut, nothing said. The anti-placeholder rule `diagnostics.rs` learned the hard way
    /// (a fixed "still partial" line made every call non-empty) applied to a truncation notice: a
    /// `truncated` flag that is always true, or a note that is always present, teaches the reader to
    /// ignore both.
    #[test]
    fn a_list_inside_every_cap_is_carried_whole_and_says_nothing_more() {
        let input = vec!["one".to_owned(), "two".to_owned(), "three".to_owned()];
        let bounded = bound_lines(input.clone(), budget(4, 64, 1_000));
        assert_eq!(bounded.lines, input);
        assert_eq!(
            (bounded.omitted, bounded.shortened, bounded.total),
            (0, 0, 3)
        );
        assert!(!bounded.truncated());
        assert_eq!(
            bounded.truncation_note("audit warnings", budget(4, 64, 1_000)),
            None
        );
    }

    /// Past the line count the tail is omitted -- and still counted. `total` is what makes the report
    /// honest: a caller that sees "4 lines" and "omitted 6" can tell the source held 10.
    #[test]
    fn crossing_the_line_count_omits_the_tail_but_still_counts_it() {
        let bounded = bound_lines(lines_of(10, 4), budget(4, 64, 100_000));
        assert_eq!(bounded.lines.len(), 4);
        assert_eq!((bounded.omitted, bounded.total), (6, 10));
        assert_eq!(
            bounded.shortened, 0,
            "no line was near the per-line cap here"
        );
        assert!(bounded.truncated());
        let note = bounded
            .truncation_note("audit warnings", budget(4, 64, 100_000))
            .expect("a note");
        assert!(note.contains("carried 4 of 10 line(s)"), "{note}");
        assert!(note.contains("omitted 6"), "{note}");
        assert!(
            note.contains("storage-audit"),
            "the note has to say where the rest is, or it is an apology and not a pointer: {note}"
        );
    }

    /// One finding longer than the per-line cap is **shortened in place**, with the elision written into
    /// the text. Dropping it would delete the very finding that made the list long, and clipping it
    /// silently would leave the reader holding a truncated string with no way to know.
    #[test]
    fn one_giant_line_is_shortened_not_dropped_and_says_by_how_much() {
        let giant = "x".repeat(5_000);
        let bounded = bound_lines(vec![giant.clone()], budget(4, 64, 100_000));
        assert_eq!(bounded.lines.len(), 1, "the finding is still here");
        assert_eq!((bounded.shortened, bounded.omitted), (1, 0));
        let carried = &bounded.lines[0];
        assert!(carried.starts_with(&"x".repeat(64)), "{carried}");
        assert!(
            carried.ends_with("[4936 bytes elided]"),
            "the marker must state the gap exactly: {carried}"
        );
        assert!(carried.len() < giant.len());
        assert!(
            bounded.truncated(),
            "a shortened answer is not the whole answer, even when every line was carried"
        );
    }

    /// The byte budget has to be able to bite *before* the line count, or a list of 128 medium lines is
    /// "bounded" only in a sense nobody could enforce at the transport.
    #[test]
    fn the_byte_budget_bites_before_the_line_budget() {
        let bounded = bound_lines(lines_of(50, 200), budget(100, 1_024, 1_000));
        assert!(
            bounded.lines.len() < 10,
            "each line is ~205 bytes, so a 1 KiB budget cannot carry 50: {}",
            bounded.lines.len()
        );
        assert!(bounded.byte_len <= 1_000, "{:?}", bounded.byte_len);
        assert_eq!(bounded.total, 50);
        assert_eq!(bounded.omitted, 50 - bounded.lines.len());
    }

    /// Rule inherited from `caly-engine::job_follow`: the first line is emitted even when it alone
    /// exceeds the budget. Two views in one crate must not give different answers to "what does an
    /// over-full page look like", and "nothing" is the answer that looks like "there was nothing".
    #[test]
    fn the_first_line_is_carried_even_when_it_alone_exceeds_the_budget() {
        let bounded = bound_lines(vec!["y".repeat(500)], budget(10, 4_096, 10));
        assert_eq!(
            bounded.lines.len(),
            1,
            "an empty list would read as no findings"
        );
        assert_eq!(bounded.omitted, 0);
        assert!(
            bounded.byte_len > 10,
            "and the excess is reported, not hidden"
        );
    }

    /// The reservation is only real if the worst-case note fits inside it. Measured, not estimated:
    /// every counter at its maximum, which is the longest text this function can produce.
    #[test]
    fn the_truncation_note_fits_inside_its_reservation() {
        let worst = BoundedLines {
            lines: vec!["x".to_owned(); DIAGNOSTIC_MAX_LINES],
            byte_len: u64::MAX,
            omitted: usize::MAX,
            shortened: usize::MAX,
            total: usize::MAX,
        };
        let note = worst
            .truncation_note("audit warnings", DiagnosticBudget::for_bulk_tier())
            .expect("a note");
        assert!(
            note.len() < DIAGNOSTIC_NOTE_RESERVE_BYTES as usize,
            "a note that outgrows its reservation breaks the bound it announces: {} bytes",
            note.len()
        );
    }

    /// A public-capacity check with the constants themselves: the tier budget plus the reserved note
    /// must land exactly on the published cap, and that cap must still leave the transport room.
    #[test]
    fn the_bulk_tier_budget_and_its_note_fit_the_public_cap_exactly() {
        let tier = DiagnosticBudget::for_bulk_tier();
        assert_eq!(
            tier.max_bytes + DIAGNOSTIC_NOTE_RESERVE_BYTES,
            DIAGNOSTIC_MAX_BYTES
        );
        assert_eq!(tier.max_lines, DIAGNOSTIC_MAX_LINES);
        assert_eq!(tier.max_line_bytes, DIAGNOSTIC_MAX_LINE_BYTES);
        assert!(
            DIAGNOSTIC_MAX_BYTES * 3 <= caly_ipc::MAX_FRAME_SIZE_BYTES as u64,
            "the whole point of the number"
        );
    }

    /// The four reachable combinations, so the rule has a judge even where the daemon cannot yet build
    /// the fixture that would exercise it end to end.
    #[test]
    fn a_clean_bill_is_only_claimed_when_nothing_was_cut() {
        assert!(may_claim_clean(true, true, false));
        assert!(
            !may_claim_clean(true, true, true),
            "empty tiers plus a cut is the case that must stay silent"
        );
        assert!(!may_claim_clean(false, true, false));
        assert!(!may_claim_clean(true, false, false));
    }
}
