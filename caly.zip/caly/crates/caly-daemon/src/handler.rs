use caly_api::{ApiError, OperationMode, OperationResult, RequestEnvelope, ResponseEnvelope};
use caly_common::Actor;

use crate::app::{unsupported_request_response, DaemonApp};
use crate::query::handle_query;
use crate::stream::handle_stream;

pub fn handle_request(
    app: &DaemonApp,
    actor: Actor,
    envelope: &RequestEnvelope,
) -> ResponseEnvelope {
    // Queries and streams are gated here because they reach the store directly; the command path is
    // gated where the idempotency rule lives (`map_request_to_command`), so that a caller entering
    // through `submit_request_as_command` -- a test, a future CLI verb -- cannot skip it. Same
    // `require_role`, same `api_error_for`, so the three modes cannot drift apart.
    if !matches!(envelope.operation.meta().mode, OperationMode::Command) {
        if let Err(error) = crate::request_map::require_role(envelope) {
            return error_response(
                app,
                envelope,
                crate::request_map::api_error_for(envelope, error),
            );
        }
    }
    match envelope.operation.meta().mode {
        OperationMode::Command => match app.submit_request_as_command(actor, envelope) {
            // Forwarded as the engine produced it: the job id, the revision it was accepted at, and
            // the impact the dispatch classification derived from the command kind.
            Ok(Some(submitted)) => ok_response(
                envelope,
                caly_api::OperationResult::Accepted(submitted.accepted),
            ),
            Ok(None) => unsupported_request_response(app, envelope),
            Err(error) => error_response(app, envelope, error),
        },
        OperationMode::Query => match handle_query(app, envelope) {
            Ok(Some(result)) => ok_response(envelope, result),
            Ok(None) => unsupported_request_response(app, envelope),
            Err(error) => error_response(app, envelope, error),
        },
        OperationMode::Stream => match handle_stream(app, envelope) {
            Some(result) => ok_response(envelope, result),
            None => unsupported_request_response(app, envelope),
        },
    }
}

/// Every response leaves through these two functions.
///
/// That is the reason masking belongs here and not at each `ApiError::new` call site: the strings an
/// error carries are composed all over the tree — a profile id from the request, a core's own
/// failure text, a path — and `ADR-020 §3`/`RFC-0010 §7.2` need a guarantee that holds for all of
/// them, at the one boundary both façades share. `LocalApi` and `RemoteApi` call this same
/// function, so a client cannot get a masked error over one transport and a raw one over the other.
fn ok_response(envelope: &RequestEnvelope, result: OperationResult) -> ResponseEnvelope {
    ResponseEnvelope {
        request_id: envelope.request_id,
        trace_id: envelope.trace_id.clone(),
        result: Ok(result),
    }
}

fn error_response(
    app: &DaemonApp,
    envelope: &RequestEnvelope,
    error: ApiError,
) -> ResponseEnvelope {
    ResponseEnvelope {
        request_id: envelope.request_id,
        trace_id: envelope.trace_id.clone(),
        result: Err(app.redact_error(error)),
    }
}
