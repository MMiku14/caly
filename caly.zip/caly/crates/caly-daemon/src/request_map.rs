use caly_api::{ApiError, Operation, RequestEnvelope, Role};
use caly_common::{Actor, RequestContext};
use caly_engine::{Command, CommandId, CommandKind};

/// Why a request was refused before it ever reached the engine.
///
/// The kind exists **before** there was a second reason: `submit_request_as_command` used to map every
/// `request_map` failure to `PERMISSION` regardless of cause, which was harmless while the role check
/// was the only one and silently wrong the moment a second refusal appeared (`docs/guides/ERRORS.md` gives
/// `PERMISSION` and `CONFIG_INVALID` different categories, retryability and exit codes).
#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub enum RequestMapErrorKind {
    /// `required_role` was not met (`RFC-0002 §7.2`).
    Permission,
    /// The request itself is malformed for this operation's contract (`§5.2`, `§8.3`).
    InvalidRequest,
    /// The request's own bounds violate what the operation declares. Same `CONFIG_INVALID`, different
    /// kind, because the advice and the counter differ: `doctor`'s key-refusal tally must not rise
    /// because somebody asked for too many deletions (`ADR-038 §2`).
    InvalidBounds,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct RequestMapError {
    pub kind: RequestMapErrorKind,
    pub summary: String,
}

impl RequestMapError {
    pub fn permission(summary: impl Into<String>) -> Self {
        Self {
            kind: RequestMapErrorKind::Permission,
            summary: summary.into(),
        }
    }

    pub fn invalid_request(summary: impl Into<String>) -> Self {
        Self {
            kind: RequestMapErrorKind::InvalidRequest,
            summary: summary.into(),
        }
    }

    pub fn invalid_bounds(summary: impl Into<String>) -> Self {
        Self {
            kind: RequestMapErrorKind::InvalidBounds,
            summary: summary.into(),
        }
    }
}

/// The role gate, shared by every mode that `handle_request` dispatches.
///
/// `RFC-0002 §7.2` makes `required_role` part of what an operation *is*, and a contract is only real
/// where a boundary enforces it. Until `ADR-038 §1` this ran on the command path only: queries and
/// streams went straight to `handle_query` / `handle_stream`, so `OperationMeta::query(Role::Operator,
/// ..)` was decoration -- `profile.plan` has declared `Operator` for the whole history of this repo
/// and nothing ever read it (`docs/history/ONBOARDING_NOTES.md §4.75`). Enforcing it at the boundary, from the
/// same function, is what makes the declaration on a *new* read mean something.
pub(crate) fn require_role(envelope: &RequestEnvelope) -> Result<(), RequestMapError> {
    let meta = envelope.operation.meta();
    if role_satisfies(envelope.role, meta.required_role) {
        return Ok(());
    }
    Err(RequestMapError::permission(format!(
        "request role {:?} does not satisfy required role {:?}",
        envelope.role, meta.required_role
    )))
}

/// The `ApiError` a refusal at that gate turns into.
///
/// One constructor on purpose: a read refused for its role and a write refused for its role must not
/// grow different codes, categories or remediation text, and the two paths enter through different
/// functions.
pub(crate) fn api_error_for(envelope: &RequestEnvelope, error: RequestMapError) -> ApiError {
    let kind = error.kind;
    let code = match kind {
        // `PERMISSION` for an identity that cannot do the thing, `CONFIG_INVALID` for a request that is
        // malformed for the operation's contract. The categories, retryability and exit codes differ
        // (`docs/guides/ERRORS.md §5.1`, `§5.6`), so mapping both to `PERMISSION` would tell a caller to go
        // ask for rights it already has.
        RequestMapErrorKind::Permission => caly_api::ErrorCode::Permission,
        RequestMapErrorKind::InvalidRequest | RequestMapErrorKind::InvalidBounds => {
            caly_api::ErrorCode::ConfigInvalid
        }
    };
    let refusal = ApiError::new(
        code,
        caly_api::ErrorCategory::User,
        false,
        error.summary,
        envelope.trace_id.clone(),
    );
    // One remediation per kind. A caller told to "pass an idempotency key" after asking for
    // `max_deletions: 0` would go add a key, submit again, and be refused for the same reason.
    match kind {
        RequestMapErrorKind::InvalidRequest => refusal.with_remediation(KEY_REMEDIATION),
        RequestMapErrorKind::InvalidBounds => refusal.with_remediation(BOUNDS_REMEDIATION),
        RequestMapErrorKind::Permission => refusal,
    }
}

/// What to do about a bounds refusal. Shared with the plan query's mapper, so the two operations
/// cannot advertise different rules for the same two numbers.
pub(crate) const BOUNDS_REMEDIATION: &str =
    "omit grace_period_ms / max_deletions for the daemon's defaults, or pass values within the \
     published caps";

/// The text the caller needs to fix a key refusal. Named so the query path can point at the same words
/// without copying them.
pub(crate) const KEY_REMEDIATION: &str = concat!(
    "pass idempotency_key: Some(..) with a value that identifies this logical operation, ",
    "and reuse that same value when retrying it; mint a fresh value per distinct write. ",
    "The daemon will not derive one for you: request ids are counted per access path, ",
    "so a derived key would collide across paths"
);

pub fn role_satisfies(actual: Role, required: Role) -> bool {
    fn rank(role: Role) -> u8 {
        match role {
            Role::Viewer => 0,
            Role::Operator => 1,
            Role::Admin => 2,
            Role::PrivilegedBroker => 3,
        }
    }

    rank(actual) >= rank(required)
}

pub fn map_request_to_command(
    actor: Actor,
    envelope: &RequestEnvelope,
) -> Result<Option<Command>, RequestMapError> {
    require_role(envelope)?;
    let meta = envelope.operation.meta();
    let idempotency = resolve_idempotency_key(&meta, envelope)?;

    let kind = match &envelope.operation {
        Operation::System(op) => match op {
            caly_api::SystemOp::Shutdown => Some(CommandKind::SystemShutdown),
            caly_api::SystemOp::CollectGarbage { request } => {
                // Checked here, at the same boundary as the role and the key, so a cycle that could not
                // run is refused as a bad request instead of being queued and failing as a job. The
                // ranges are the engine's, not a second copy: `GcPlanBounds::resolve` is the only
                // spelling of them, which is what keeps the plan query and the collection cycle
                // promising the same limits (`ADR-038 §2`).
                caly_engine::gc_plan::GcPlanBounds {
                    grace_period_ms: request.grace_period_ms,
                    max_deletions: request.max_deletions,
                }
                .resolve()
                .map_err(|refusal| RequestMapError::invalid_bounds(refusal.message()))?;
                Some(CommandKind::StorageGc {
                    grace_period_ms: request.grace_period_ms,
                    max_deletions: request.max_deletions,
                })
            }
            _ => None,
        },
        Operation::Profile(op) => match op {
            caly_api::ProfileOp::Apply { request } => {
                Some(CommandKind::ProfileApply(request.clone()))
            }
            caly_api::ProfileOp::Rollback { request } => {
                Some(CommandKind::ProfileRollback(request.clone()))
            }
            _ => None,
        },
        Operation::Source(op) => match op {
            caly_api::SourceOp::Update { source_id } => Some(CommandKind::SourceUpdate {
                source_id: source_id.0.clone(),
            }),
            _ => None,
        },
        Operation::Proxy(op) => match op {
            caly_api::ProxyOp::Select { request } => Some(CommandKind::ProxySelect {
                group_id: request.group_id.0.clone(),
                node_id: request.node_id.0.clone(),
            }),
            caly_api::ProxyOp::TestDelay { request } => Some(CommandKind::ProxyTestDelay {
                node_ids: request
                    .node_ids
                    .iter()
                    .map(|node_id| node_id.0.clone())
                    .collect(),
            }),
            _ => None,
        },
        Operation::Dns(op) => match op {
            caly_api::DnsOp::FlushCache => Some(CommandKind::DnsFlushCache),
            _ => None,
        },
        Operation::Network(op) => match op {
            caly_api::NetworkOp::Repair => Some(CommandKind::NetworkRepair),
            _ => None,
        },
        Operation::Runtime(op) => match op {
            caly_api::RuntimeOp::CloseConnection { connection_id } => {
                Some(CommandKind::RuntimeCloseConnection {
                    connection_id: connection_id.0.clone(),
                })
            }
            _ => None,
        },
        Operation::Routing(_) => None,
        Operation::Core(_) => None,
        Operation::Diagnostics(op) => match op {
            caly_api::DiagnosticsOp::SupportBundle => Some(CommandKind::DiagnosticsBundle),
            _ => None,
        },
        Operation::Automation(op) => match op {
            caly_api::AutomationOp::PatchJob { request } => {
                Some(CommandKind::AutomationPatch(request.clone()))
            }
            _ => None,
        },
    };

    Ok(kind.map(|kind| Command {
        id: CommandId(format!("req-{}", envelope.request_id.0)),
        request_id: Some(envelope.request_id),
        actor,
        context: RequestContext {
            trace_id: envelope.trace_id.clone(),
            actor,
            deadline_ms: envelope.deadline_ms,
            expected_revision: envelope.expected_revision,
            // Forwarded, not fabricated; and where the caller stated nothing, the *stated* default --
            // the same value `caly_api::default_ctx` hands the local façade, so one request cannot get
            // two different budgets depending on which transport it arrived on. `IoBudget::unlimited`
            // is no longer reachable as a fallback: an unset field used to mean "no bound", which was
            // a silent policy (`ADR-036 §2.4`, step 3).
            io_budget: envelope
                .io_budget
                .clone()
                .unwrap_or_else(caly_common::IoBudget::default_command),
            idempotency_key: idempotency.clone(),
            // A token cannot cross the wire (a handle, not data), so session-scoped cancellation is a
            // closed session -- that mapping is `ADR-036`'s later step. The remote path therefore gets a
            // fresh, inert token rather than a pretend-forwarded one, and `deadline_mono_ms` stays unset
            // here: making `deadline_ms` absolute is the executing driver's judgment, not the
            // mapping's (`docs/history/ONBOARDING_NOTES.md §4.86`; even where a storage clock is injected
            // the command path does not borrow it for this -- see `ADR-039 §8`, round 36).
            cancel: caly_common::CancelToken::default(),
            byte_meter: caly_common::ByteMeter::default(),
            deadline_mono_ms: None,
        },
        timeout_ms: envelope.deadline_ms,
        idempotency_key: idempotency.map(caly_engine::IdempotencyKey),
        kind,
    }))
}

/// What key this command dedups under — the point where `RFC-0002 §7.2`'s
/// `idempotency: Required | Optional | NotApplicable` finally stops being decorative.
///
/// Rules, in order, and each one is why the enum exists:
///
/// - `Some("")` is refused for **any** command. An empty key is a constant key wearing a hat: every
///   caller that "supplied" one collapses into a single dedup bucket, which is precisely the round-9
///   defect (`§4.37`) where a fabricated constant made the second remote apply silently replay the
///   first. `CONFIG_INVALID`, because the caller's input is what is wrong.
/// - `Required` with no key: **refused**. This was not the plan of the moment — the first version of
///   this function derived `req:<request_id>` instead, and the write-parity harness caught what that
///   means: request ids are counted **per access path** (the daemon's counter for local calls, the
///   client session's for remote ones) while the dedup window is keyed per actor, so two unrelated
///   writes arriving on different paths derived the same key and one silently replayed the other. A
///   derived key is therefore either colliding (unsafe) or unique-per-call (pointless, because a
///   unique key is exactly "no dedup"). `ADR-037 §2.3` says refuse, and the harness says it is the
///   only sound reading (`docs/history/ONBOARDING_NOTES.md §4.62`).
/// - `Optional` / `NotApplicable` with no key: no dedup, unchanged.
fn resolve_idempotency_key(
    meta: &caly_api::OperationMeta,
    envelope: &RequestEnvelope,
) -> Result<Option<String>, RequestMapError> {
    let explicit = envelope
        .idempotency_key
        .as_deref()
        .map(str::trim)
        .filter(|key| !key.is_empty());
    if explicit.is_none() && envelope.idempotency_key.is_some() {
        return Err(RequestMapError::invalid_request(
            "idempotency_key was supplied empty; either give a key that identifies this operation, \
             or omit the field",
        ));
    }
    match (explicit, meta.idempotency) {
        (Some(key), _) => Ok(Some(key.to_string())),
        // Only the "carried none" case can reach here: a present-but-blank key was refused above.
        (None, caly_api::Idempotency::Required) => Err(RequestMapError::invalid_request(format!(
            "{} requires an idempotency_key (idempotency: Required) and this request carried none",
            operation_name(envelope)
        ))),
        (None, _) => Ok(None),
    }
}

/// The operation named the way a caller would recognise it, because a refusal that says only
/// "idempotency_key required" is a puzzle when a request carries ten fields. Kept to the operations
/// that declare `Required`, which is the whole set today (`profile.apply`, `profile.rollback`,
/// `system.shutdown`, `network.repair`).
fn operation_name(envelope: &RequestEnvelope) -> &'static str {
    use caly_api::Operation as Op;
    match &envelope.operation {
        Op::Profile(caly_api::ProfileOp::Apply { .. }) => "profile.apply",
        Op::Profile(caly_api::ProfileOp::Rollback { .. }) => "profile.rollback",
        Op::System(caly_api::SystemOp::Shutdown) => "system.shutdown",
        Op::System(caly_api::SystemOp::CollectGarbage { .. }) => "system.gc-collect",
        Op::Network(caly_api::NetworkOp::Repair) => "network.repair",
        _ => "this command",
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use caly_api::{Operation, ProtocolVersion, RequestId, SystemOp, TraceId};

    fn envelope_with(budget: Option<caly_common::IoBudget>) -> RequestEnvelope {
        RequestEnvelope {
            protocol: ProtocolVersion { major: 1, minor: 0 },
            request_id: RequestId(7),
            trace_id: TraceId::new("budget-plumbing"),
            deadline_ms: Some(250),
            expected_revision: None,
            idempotency_key: Some("k-7".to_owned()),
            role: Role::Admin,
            operation: Operation::System(SystemOp::CollectGarbage {
                request: caly_api::GcCollectRequest::new(),
            }),
            io_budget: budget,
        }
    }

    fn mapped(budget: Option<caly_common::IoBudget>) -> caly_engine::Command {
        map_request_to_command(Actor::Cli, &envelope_with(budget))
            .expect("mapped")
            .expect("a collection request maps to a command")
    }

    /// The whole point of adding the envelope field: `Ctx::io_budget` used to be dropped on this floor,
    /// which made every claim about budgets unfalsifiable from the caller's side
    /// (`ADR-036 §6bis.2`).
    #[test]
    fn an_inbound_budget_arrives_at_the_command_context() {
        let budget = caly_common::IoBudget {
            max_bytes: Some(4096),
            max_requests: Some(3),
        };
        assert_eq!(mapped(Some(budget.clone())).context.io_budget, budget);
    }

    /// `None` on the wire no longer means "no bound" -- and the fallback here has to be the *same
    /// value* the local façade writes onto the envelope, or one request gets two budgets depending on
    /// which transport it arrived on (`ADR-017`'s "one façade, shared DTOs", this time about a policy).
    #[test]
    fn no_budget_means_the_stated_default_and_the_one_the_local_path_sends() {
        let command = mapped(None);
        assert_eq!(
            command.context.io_budget,
            caly_common::IoBudget::default_command(),
            "`None` is the daemon's default, and that default is bounded and written down (step 3)"
        );
        assert_eq!(
            command.context.io_budget,
            caly_api::default_ctx("same-default", caly_common::Actor::Cli).io_budget,
            "the two places that had to agree on a default now agree by construction, and this is what\
             catches the day one of them is edited alone"
        );
        assert_eq!(
            command.context.io_budget.max_requests,
            Some(caly_common::IoBudget::DEFAULT_COMMAND_STORE_REQUESTS)
        );
        assert!(
            command.context.io_budget.max_bytes.is_none(),
            "the default states no per-call byte ceiling -- bytes are enforceable (by the ports, since \
             round 29) but unbounded unless the caller asks; `ADR-036 §6bis-decies`"
        );
    }

    #[test]
    fn the_relative_deadline_travels_and_is_not_fabricated_into_an_absolute_one() {
        let command = mapped(None);
        assert_eq!(
            command.timeout_ms,
            Some(250),
            "the inbound value is forwarded"
        );
        assert_eq!(
            command.context.deadline_mono_ms, None,
            "and it is not turned absolute here: the executing driver is the only party that can\
             say whether a deadline has passed (ADR-039 §8, round 36)"
        );
    }

    #[test]
    fn a_fresh_cancel_token_accompanies_every_mapped_command() {
        let command = mapped(None);
        assert!(
            !command.context.cancel.is_cancelled(),
            "a handle cannot cross the wire, so the remote path installs an inert token -- a cancelled\
             default would abort every inbound command before it began"
        );
    }
}
