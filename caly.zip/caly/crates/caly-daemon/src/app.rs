use std::sync::{Arc, Mutex};

use caly_api::{
    ApiError, ApplyRequest, AutomationJobView, ConnectionPage, ConnectionQuery, ConnectionView,
    CoreInspection, CoreInstallId, CoreInstallView, DnsExplainRequest, DnsExplainResult, DnsStatus,
    GroupView, JobFollowRequest, JobId, NetworkPlanView, NodePage, NodeQuery, NodeView,
    PatchAutomationJob, ProfileId, ProfileSummary, ProfileView, RequestEnvelope, ResponseEnvelope,
    RouteExplainRequest, RouteExplainResult, RoutingValidation, RulePage, RuleQuery, RuleView,
    RuntimeSubscription, SourceId, SourceInspection, SourcePreview, SourcePreviewRequest,
    SourceSummary,
};
use caly_common::{Actor, TraceId};
use caly_engine::{
    plan_apply_request, Command, CommandId, EngineHandle, EventWindow, JobFollowProjection,
    JobOutcome, SubmitFailure, WorkerPolicy,
};
use caly_ipc::DispatchTarget;
use caly_storage::{ApplyPhase, RecoveryScanReport, SnapshotRecord};

use crate::bootstrap::{bootstrap, DaemonBootstrapConfig};
use crate::error_map::map_overload_report;
use crate::request_map::map_request_to_command;
use crate::state::{DaemonLifecycle, DaemonRuntimeState};
use crate::stream::{subscription_kind_name, OpenedStream};

const DEFAULT_PROFILE_ID: &str = "default-profile";
const DEFAULT_PROFILE_LABEL: &str = "Default Profile";
const DEFAULT_CORE_KIND: &str = "mihomo";
const DEFAULT_CORE_VERSION: &str = "0.1.0-dev";
const DEFAULT_BINARY_DIGEST: &str = "mock-core-binary";

/// How much of a bundle object the daemon is willing to read back at all.
///
/// A bundle is bounded by construction (its collectors cap what they emit), so this is a guard
/// against an unexpectedly large object reaching a client rather than a paging mechanism. Exceeding
/// it is an error; `SupportBundleReadRequest::max_bytes` only shortens the response.
const SUPPORT_BUNDLE_READ_LIMIT: u64 = 4 * 1024 * 1024;

#[derive(Clone)]
pub struct DaemonApp {
    runtime: Arc<Mutex<DaemonRuntimeState>>,
    engine: EngineHandle,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct SubmitCommandResponse {
    /// The engine's answer, forwarded unchanged.
    ///
    /// It used to be reduced to `job_id` here while `handler` rebuilt an `Accepted` with
    /// `estimated_impact: ReadOnly` for **every** command. `caly-engine::dispatch` already classifies
    /// each kind (`ProfileApply` → `Restart`, `ProxySelect` → `Reload`,
    /// `NetworkRepair` → `PrivilegedNetworkChange`), so the field a caller reads to decide whether
    /// to warn the user before following a job was a constant — and a constant that said "nothing
    /// will change" for the operations that change the most.
    pub accepted: caly_api::Accepted,
    pub reused_existing_job: bool,
}

impl SubmitCommandResponse {
    pub fn job_id(&self) -> u64 {
        self.accepted.job_id.0
    }
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct EventFollowResponse {
    pub next_seq: u64,
    pub retained_from: u64,
    pub reset_required: bool,
    pub event_count: usize,
}

/// Why a daemon refused to start.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct DaemonStartError {
    pub summary: String,
    /// True when the durable store itself could not be opened. A store that will not open means
    /// the on-disk state cannot be trusted at all, which is strictly worse than a scan that
    /// simply found work to do.
    pub store_unusable: bool,
}

impl DaemonApp {
    /// Start with the default in-memory backend.
    ///
    /// A failed startup recovery scan used to be discarded with `let _ = ...`, so a daemon that
    /// could not reconstruct its state came up looking healthy. It now comes up `Failed` with the
    /// reason recorded in `last_error`.
    pub fn bootstrap(config: DaemonBootstrapConfig) -> Self {
        let backend: Arc<dyn caly_storage::StorageBackend> =
            Arc::new(caly_storage::InMemoryStorage::new());
        let recover = config.recover_on_start;
        let boot = bootstrap(config);
        let app = Self {
            runtime: Arc::new(Mutex::new(boot.runtime)),
            engine: EngineHandle::with_backend(boot.engine, backend),
        };
        if recover {
            if let Err(summary) = app.startup_recovery() {
                let _ = app.record_recovery_failure(summary);
            }
        }
        app
    }

    /// Start against an injected storage backend, recovering from whatever it already holds.
    ///
    /// The backend is injected rather than constructed here on purpose: choosing *which* storage
    /// exists is a composition-root decision, and `ADR-011` keeps host contact inside the port
    /// layer, so `caly-daemon` still has no filesystem dependency of its own.
    ///
    /// Unlike [`Self::bootstrap`], a recovery scan that fails is a start-up **error**: with a
    /// durable backend, "could not read the state" means the on-disk state cannot be trusted
    /// (a torn CAS object, a record that no longer decodes), and a daemon that starts anyway would
    /// happily apply on top of it.
    pub fn try_bootstrap(
        config: DaemonBootstrapConfig,
        backend: Arc<dyn caly_storage::StorageBackend>,
    ) -> Result<Self, DaemonStartError> {
        let recover = config.recover_on_start;
        let boot = bootstrap(config);
        let app = Self {
            runtime: Arc::new(Mutex::new(boot.runtime)),
            engine: EngineHandle::with_backend(boot.engine, backend),
        };
        if recover {
            app.startup_recovery().map_err(|summary| DaemonStartError {
                summary: format!("startup recovery failed: {summary}"),
                store_unusable: true,
            })?;
        }
        Ok(app)
    }

    /// Scan and apply, returning the reason if the scan itself could not run.
    fn startup_recovery(&self) -> Result<(), String> {
        let report = self.recovery_scan()?;
        self.apply_recovery_snapshot(&report)
    }

    fn record_recovery_failure(&self, summary: String) -> Result<(), String> {
        let mut guard = self
            .runtime
            .lock()
            .map_err(|_| "daemon runtime lock poisoned".to_owned())?;
        guard.lifecycle = DaemonLifecycle::Failed;
        guard.last_error = Some(summary);
        guard.last_recovery_summary = Some("startup recovery failed".to_owned());
        Ok(())
    }

    /// The daemon's view of what the store still owes the recovery scan.
    pub fn durable_scan(&self) -> Result<RecoveryScanReport, String> {
        self.engine.scan_recovery_state()
    }

    pub fn runtime_snapshot(&self) -> Result<DaemonRuntimeState, String> {
        self.runtime
            .lock()
            .map(|guard| guard.clone())
            .map_err(|_| "daemon runtime lock poisoned".to_owned())
    }

    pub fn set_running(&self) -> Result<(), String> {
        let mut guard = self
            .runtime
            .lock()
            .map_err(|_| "daemon runtime lock poisoned".to_owned())?;
        guard.lifecycle = DaemonLifecycle::Running;
        Ok(())
    }

    fn sync_runtime_from_engine(&self) -> Result<(), String> {
        let snapshot = self.engine.snapshot()?;
        let mut runtime = self
            .runtime
            .lock()
            .map_err(|_| "daemon runtime lock poisoned".to_owned())?;
        runtime.engine_lifecycle = snapshot.current_lifecycle();
        runtime.state_revision = snapshot.generation;
        let latest_snapshot = self.engine.latest_last_known_good_snapshot().ok().flatten();
        runtime.active_profile = latest_snapshot
            .as_ref()
            .map(|snapshot| caly_api::ProfileId(snapshot.profile_id.clone()));
        runtime.active_core = latest_snapshot
            .as_ref()
            .map(|snapshot| snapshot.core_identity.clone());
        runtime.last_apply_plan_summary = latest_snapshot
            .as_ref()
            .map(|snapshot| snapshot.apply_plan_summary.clone());
        let active_id = latest_snapshot
            .as_ref()
            .map(|snapshot| snapshot.id.0.clone());
        runtime.active_snapshot = latest_snapshot.map(|snapshot| snapshot.id.0);
        // The collector reads the active snapshot out of engine state, not out of this mirror: the
        // mirror is what `system.status` shows, and a root set that depends on a caller remembering to
        // update a second copy is how a running deployment stops being protected (`ADR-038 §8`).
        self.engine.set_active_snapshot(active_id)?;
        Ok(())
    }

    pub fn submit_engine_command(
        &self,
        command: Command,
    ) -> Result<SubmitCommandResponse, ApiError> {
        let trace_id = command.context.trace_id.clone();
        let result = self
            .engine
            .submit_checked(command)
            .map_err(|failure| match failure {
                SubmitFailure::Overload(report) => map_overload_report(trace_id, report),
                // `docs/ERRORS.md §5.2`: a compare-and-swap miss is a genuine multi-party conflict,
                // and it is not retryable as-is — the caller has to re-read the revision first.
                SubmitFailure::StaleRevision { expected, current } => ApiError::new(
                    caly_api::ErrorCode::Conflict,
                    caly_api::ErrorCategory::Config,
                    false,
                    format!("expected revision {expected} is stale; the daemon is at {current}"),
                    trace_id,
                )
                .with_detail(
                    "the submission carried ctx.expected_revision, and the state has moved since it                      was read",
                )
                .with_remediation(
                    "re-read system.status.state_revision, re-check what changed, then resubmit",
                ),
                SubmitFailure::Internal(message) => ApiError::new(
                    caly_api::ErrorCode::Unavailable,
                    caly_api::ErrorCategory::Internal,
                    true,
                    message,
                    trace_id,
                ),
            })?;
        self.sync_runtime_from_engine().map_err(|message| {
            ApiError::new(
                caly_api::ErrorCode::Unavailable,
                caly_api::ErrorCategory::Internal,
                true,
                message,
                TraceId::new("daemon-sync-runtime"),
            )
        })?;
        Ok(SubmitCommandResponse {
            accepted: result.accepted,
            reused_existing_job: result.reused_existing_job,
        })
    }

    pub fn submit_request_as_command(
        &self,
        actor: Actor,
        envelope: &RequestEnvelope,
    ) -> Result<Option<SubmitCommandResponse>, ApiError> {
        let command = match map_request_to_command(actor, envelope) {
            Ok(command) => command,
            Err(error) => {
                // The tally is decided from the kind, before the error is built: it counts *key*
                // refusals, and a bounds refusal on the same code must not inflate it
                // (`ADR-038 §2`).
                let counted = matches!(
                    error.kind,
                    crate::request_map::RequestMapErrorKind::InvalidRequest
                );
                let refusal = crate::request_map::api_error_for(envelope, error);
                if counted {
                    // Counted, because "the caller keeps getting refused" is invisible from the daemon
                    // side otherwise: the error goes back to that caller and is dropped, while `doctor`
                    // is where an operator settling "the daemon is stuck" reads the tally.
                    if let Ok(mut runtime) = self.runtime.lock() {
                        runtime.idempotency_key_refusals =
                            runtime.idempotency_key_refusals.saturating_add(1);
                    }
                }
                return Err(refusal);
            }
        };

        let Some(command) = command else {
            return Ok(None);
        };

        // A poisoned lock is not a reason to let a deployment through, so the state is read
        // before the decision and the failure path is an error, not a silent pass.
        let lifecycle = self
            .runtime_snapshot()
            .map_err(|message| {
                ApiError::new(
                    caly_api::ErrorCode::Internal,
                    caly_api::ErrorCategory::Internal,
                    true,
                    message,
                    envelope.trace_id.clone(),
                )
            })?
            .lifecycle;
        if let Some(refusal) = Self::refusal_for_lifecycle(lifecycle, &command, &envelope.trace_id)
        {
            return Err(refusal);
        }
        self.submit_engine_command(command).map(Some)
    }

    /// Refuse a command the daemon must not accept in its current lifecycle state.
    ///
    /// `apply_recovery_snapshot` already *reports* `Recovering` / `Failed`, but reporting is not
    /// gating: a client that ignored the status field could still deploy a new config on top of a
    /// transaction whose recovery nobody had resolved. That is precisely the state where an apply
    /// is most likely to make things worse, so the refusal belongs here at the single
    /// request-to-command boundary rather than in each façade.
    ///
    /// The rules are deliberately asymmetric:
    ///
    /// * `Recovering` blocks `ProfileApply` only. A rollback is how an operator gets *out* of
    ///   recovery, so blocking it would deadlock the escape hatch.
    /// * `Failed` blocks every command. Queries keep working: `status`, `doctor` and
    ///   `explain_pipeline` are how the failure gets diagnosed.
    fn refusal_for_lifecycle(
        lifecycle: DaemonLifecycle,
        command: &caly_engine::Command,
        trace_id: &caly_common::TraceId,
    ) -> Option<ApiError> {
        let blocked = match lifecycle {
            DaemonLifecycle::Recovering => {
                matches!(command.kind, caly_engine::CommandKind::ProfileApply(_))
            }
            DaemonLifecycle::Failed => true,
            DaemonLifecycle::Starting | DaemonLifecycle::Running | DaemonLifecycle::Stopped => {
                false
            }
        };
        if !blocked {
            return None;
        }

        let remediation = match lifecycle {
            DaemonLifecycle::Recovering =>
                "resolve the pending transaction first: roll back to the last-known-good snapshot,                  or take over the running instance after confirming its identity",
            _ => "clear the recorded startup failure (recovery or storage fault) before deploying again",
        };
        Some(
            ApiError::new(
                caly_api::ErrorCode::Conflict,
                caly_api::ErrorCategory::Platform,
                true,
                format!("daemon is {lifecycle:?} and will not accept this command yet"),
                trace_id.clone(),
            )
            .with_detail(format!(
                "command {} is refused while the daemon is {lifecycle:?}",
                command_line(&command.kind)
            ))
            .with_remediation(remediation),
        )
    }

    pub fn drain_engine_once(&self) -> Result<usize, String> {
        let report = self.engine.drain_with_policy(WorkerPolicy::bounded(1))?;
        self.sync_runtime_from_engine()?;
        Ok(report.cycles)
    }

    /// Read back a support bundle the store was asked to keep, by object digest.
    ///
    /// Three rules, all of them load-bearing:
    ///
    /// 1. **The digest must name a support bundle.** The object store also holds the compiled
    ///    artifact and raw source payloads, and those are *not* redacted — they are the config a core
    ///    runs with, credentials included. A query that read "whatever digest you gave me" would turn
    ///    `RFC-0010 §12.2`'s export into a generic secret reader, so the kind is checked
    ///    **before** any bytes are touched.
    /// 2. **Integrity first.** The store verifies the bytes against its own anchor on read; this
    ///    method never sees unverified content, so `truncated` below is a display decision, not a
    ///    partially-verified one.
    /// 3. **`max_bytes` bounds the response, not the read.** The whole object is read (up to
    ///    `SUPPORT_BUNDLE_READ_LIMIT`) and then prefixed, so a caller asking for less cannot make the
    ///    daemon skip verification.
    pub fn read_support_bundle(
        &self,
        request: caly_api::SupportBundleReadRequest,
    ) -> Result<caly_api::SupportBundleView, String> {
        let resolved;
        let digest = match request.digest.as_deref() {
            Some(digest) if !digest.trim().is_empty() => digest.trim(),
            // "the newest bundle the store still holds" — the caller only clicked *Export*, it has
            // no reason to have parsed a digest out of a job event.
            _ => {
                resolved = self.engine.latest_support_bundle_digest()?;
                resolved.as_deref().ok_or_else(|| {
                    "this store holds no support bundle yet; submit DiagnosticsOp::SupportBundle first"
                        .to_owned()
                })?
            }
        };
        let meta = self
            .engine
            .object_metadata(digest)?
            .ok_or_else(|| format!("no such object: {digest}"))?;
        if meta.kind != caly_storage::ObjectKind::SupportBundle {
            return Err(format!(
                "object {digest} is a {:?}, not a support bundle",
                meta.kind
            ));
        }
        let payload = self
            .engine
            .object_payload(digest, SUPPORT_BUNDLE_READ_LIMIT)?
            .ok_or_else(|| format!("object {digest} has no content to read back"))?;
        let text = String::from_utf8_lossy(&payload).into_owned();
        let (text, truncated) = match request.max_bytes {
            Some(limit) if (limit as usize) < text.len() => {
                // Cut on a char boundary, so a truncated bundle is still valid utf-8 for the caller.
                let mut end = limit as usize;
                while end > 0 && !text.is_char_boundary(end) {
                    end -= 1;
                }
                (text[..end].to_owned(), true)
            }
            _ => (text, false),
        };
        // Counted from what is actually returned: a truncated read reports the lines it delivered, so
        // `line_count` and `text` cannot disagree about what the caller is holding.
        Ok(caly_api::SupportBundleView {
            digest: digest.to_owned(),
            content_sha256: meta.content_sha256.clone().unwrap_or_default(),
            stored_at_unix_ms: meta.stored_at_unix_ms,
            byte_len: text.len() as u64,
            line_count: text.lines().count(),
            truncated,
            text,
        })
    }

    /// Audit the storage layer the way `docs/STORAGE_RECOVERY_EXECUTION_PLAN.md §9.2` asks
    /// `doctor` to: dangling journals, an abandoned runtime candidate, no valid last-known-good,
    /// and snapshot/object mismatch.
    ///
    /// The wiring lives in `caly-storage` so that this view and the support bundle's view of the
    /// same store are computed by one function. Until now each caller assembled its own
    /// `AuditInput`, which is how two diagnostics can disagree about facts neither of them invented.
    pub fn storage_audit(&self) -> Result<caly_storage::StorageAudit, String> {
        let policy = self.engine.execution_policy();
        let now = policy.clock_start_unix_ms.max(0);
        caly_storage::audit_backend(self.engine.storage().as_ref(), now)
    }

    /// Mask an outgoing error with the process redactor: `ADR-020 §3` and `RFC-0010 §7.2` both
    /// demand that `ApiError.summary/detail` be redacted, and this is the boundary every error
    /// crosses on its way to a client.
    pub fn redact_error(&self, error: caly_api::ApiError) -> caly_api::ApiError {
        match self.engine.redactor() {
            Ok(redactor) => error.redacted(&redactor),
            // A poisoned engine lock must not turn a refusal into a second failure, and it must
            // not quietly skip the masking either: fall back to the strictest redactor available.
            Err(_) => error.redacted(&caly_common::redact::Redactor::strict()),
        }
    }

    /// The redaction policy this daemon applies to outgoing errors and job log lines.
    pub fn redaction_policy(&self) -> Result<caly_common::redact::RedactionPolicy, String> {
        Ok(self.engine.redactor()?.policy())
    }

    /// Escalate redaction for this daemon (quasi-secrets included).
    ///
    /// Only escalation is exposed: the support bundle already runs at `Strict`, and a façade that
    /// could *relax* the process policy is a way to turn a safe default off by accident.
    pub fn escalate_redaction(
        &self,
        policy: caly_common::redact::RedactionPolicy,
    ) -> Result<(), String> {
        let current = self.engine.redactor()?;
        self.engine.set_redactor(current.escalate_to(policy))
    }

    /// Tell the daemon that `value` is secret material, so every later log line, error and bundle
    /// masks it wherever it appears. `RFC-0010 §3.3` puts this duty on whoever holds the secret:
    /// a token in a bare URL path carries no text a pattern rule could find.
    pub fn register_secret(&self, value: &str) -> Result<(), String> {
        self.engine.register_secret(value)
    }

    /// The role an in-process caller is treated as, and the accessor that changes it.
    ///
    /// `ADR-037 §2.2` as amended: the composition root declares the privilege it needs instead of the
    /// local façade assuming `Admin`. A setter rather than a bootstrap field because the role is a
    /// property of *who is calling now* (an embedded host may serve several callers over one daemon),
    /// and a `DaemonApp` clone shares it — which is the point: two façades over one daemon must not
    /// disagree about who they are.
    pub fn local_role(&self) -> Result<caly_api::Role, String> {
        Ok(self
            .runtime
            .lock()
            .map_err(|_| "daemon runtime state lock poisoned".to_owned())?
            .local_role)
    }

    pub fn set_local_role(&self, role: caly_api::Role) -> Result<(), String> {
        self.runtime
            .lock()
            .map_err(|_| "daemon runtime state lock poisoned".to_owned())?
            .local_role = role;
        Ok(())
    }

    /// A fresh per-request identity for a local call, matching what the remote path gets from its
    /// session. Deterministic (a counter), no clock, no randomness.
    pub fn next_request_id(&self) -> Result<u64, String> {
        Ok(self
            .runtime
            .lock()
            .map_err(|_| "daemon runtime state lock poisoned".to_owned())?
            .allocate_request_id())
    }

    /// The dedup window, plus how many submissions this daemon refused for carrying no usable key.
    /// `doctor` and the support bundle read the same accessor so they cannot report two numbers for one
    /// event (`RFC-0010 §6.3`: same path, same output).
    pub fn idempotency_stats(&self) -> Result<(usize, usize, usize, u64), String> {
        let refusals = self
            .runtime
            .lock()
            .map_err(|_| "daemon runtime state lock poisoned".to_owned())?
            .idempotency_key_refusals;
        let (entries, window, evictions) = self.engine.idempotency_stats()?;
        Ok((entries, window, evictions, refusals))
    }

    /// A page of a job's event lines, rendered exactly as the stream and the support bundle render
    /// them, and bounded by `paging` before it leaves the process.
    ///
    /// `None` means the daemon has no such job — a miss, not an empty window; a caller that cannot
    /// tell those apart reads "this job produced nothing" out of "this job does not exist".
    ///
    /// The bound is applied here, in the one place both façades reach, so Local and Remote cannot
    /// disagree about how much a reply carries (`RFC-0002 §4.1`). A daemon that paged on one path and
    /// not the other would show up as a *different log* per access method, which is the failure this
    /// query exists to prevent.
    pub fn job_events_view(
        &self,
        request: &caly_api::JobEventsRequest,
    ) -> Result<Option<caly_api::JobEventsView>, String> {
        let policy = crate::paging::EventPagePolicy::resolve(request)?;
        let Some(projection) =
            self.follow_job_projection(request.job_id, request.from_event_index)?
        else {
            return Ok(None);
        };
        let Some(window) = projection.window.as_ref() else {
            // Unreachable through `follow_job_projection` (it always fills the window it just
            // sliced). Reaching it would mean the projection and the window disagree, and answering
            // "no events" in that case is how a broken invariant becomes a silent wrong answer.
            return Err("job follow projection lost its event window".to_owned());
        };
        let page = caly_engine::page_job_events(window, policy.as_engine_policy());
        Ok(Some(caly_api::JobEventsView {
            job_id: request.job_id,
            state: projection.summary.state,
            events: page.lines,
            next_event_index: projection.summary.next_event_index,
            retained_from_event_index: projection.summary.retained_from_event_index,
            reset_required: projection.summary.reset_required,
            byte_len: page.byte_len,
            next_from_event_index: page.next_from_event_index,
        }))
    }

    /// The events of one job, as an operator sees them (already redacted).
    pub fn job_events(
        &self,
        job_id: caly_api::JobId,
    ) -> Result<Option<Vec<caly_engine::JobEvent>>, String> {
        Ok(self.engine.follow_job(job_id)?.job.map(|job| job.events))
    }

    /// One actionable line per class of refusal this engine had to make, newest state first.
    ///
    /// The caller's `ApiError` is transient — it is retried and forgotten. An operator asking "why is
    /// my apply not running" needs the durable half (`OVERLOAD_AND_RETRY_MODEL §7.2`: backlog length,
    /// queue cap, when it happened), which is why `doctor` and the support bundle both render this.
    pub fn overload_lines(&self) -> Result<Vec<String>, String> {
        self.engine.overload_lines()
    }

    /// `(depth, capacity)` of the engine's command queue, for `doctor` notes.
    pub fn queue_stats(&self) -> Result<(usize, usize), String> {
        self.engine.queue_stats()
    }

    pub fn recovery_scan(&self) -> Result<RecoveryScanReport, String> {
        self.engine.scan_recovery_state()
    }

    /// Say which clock the storage's file dates are comparable with (`ADR-038 §3`).
    ///
    /// The composition root owns that choice, not the daemon: `caly-io-std::StdClock` on a real host,
    /// `caly-io-sim::SimClock` inside the deterministic gate, `None` to keep the policy base. Leaving it
    /// unset is a legitimate answer and the GC plan reports it as one -- with a refusal rather than a
    /// guess (`docs/ONBOARDING_NOTES.md §4.74`).
    ///
    /// `caly_engine::Clock` is the port trait re-exported by the engine, which keeps `caly-daemon` off
    /// the `caly-io` dependency edge: this crate stays free of any host contact, and the seam is typed
    /// by the component that will actually use it.
    pub fn set_storage_clock(
        &self,
        clock: Option<Arc<dyn caly_engine::Clock>>,
    ) -> Result<(), String> {
        self.engine.set_storage_clock(clock)
    }

    /// What a storage GC cycle would do, computed without deleting anything (`ADR-038 §1`).
    ///
    /// The daemon passes the active snapshot id because it owns that fact, and the engine resolves the
    /// record from the store instead of trusting the id -- so a marker that no longer matches the store
    /// becomes a reported gap that refuses the plan, not a root that silently vanished.
    pub fn storage_gc_plan(
        &self,
        bounds: caly_engine::gc_plan::ResolvedGcBounds,
    ) -> Result<caly_engine::gc_plan::GcPlanSummary, String> {
        self.engine.storage_gc_plan(bounds)
    }

    /// What the last collection cycle did, if this process ran one (`ADR-038 §2`).
    pub fn last_gc_run(&self) -> Result<Option<caly_engine::gc_plan::GcRunRecord>, String> {
        self.engine.last_gc_run()
    }

    pub fn seed_recovery_fixture(
        &self,
        profile_id: impl Into<String>,
    ) -> Result<RecoveryScanReport, String> {
        let profile_id = profile_id.into();
        let workflow = plan_apply_request(ApplyRequest {
            profile_id: ProfileId(profile_id.clone()),
            dry_run: false,
            strict: false,
        })?;
        // `immediate()` on purpose: this is a fixture that *models a crash site*, not a command
        // executing on someone's behalf, so it has no caller whose deadline it could obey.
        let fixture_limits = caly_engine::RunLimits::immediate();
        let persisted = self
            .engine
            .begin_apply_persistence(workflow.storage_projection.clone(), &fixture_limits)
            .map_err(|refusal| refusal.to_string())?;
        let cutover = self
            .engine
            .advance_apply_phase(
                &persisted.journal,
                ApplyPhase::Cutover,
                workflow.effect_steps.len().max(1),
                1,
                &fixture_limits,
            )
            .map_err(|refusal| refusal.to_string())?;
        let _ = cutover;
        let report = self.engine.scan_recovery_state()?;
        self.apply_recovery_snapshot(&report)?;
        Ok(report)
    }

    pub fn latest_last_known_good_snapshot(&self) -> Result<Option<SnapshotRecord>, String> {
        self.engine.latest_last_known_good_snapshot()
    }

    pub fn latest_last_known_good_snapshot_id(&self) -> Result<Option<String>, String> {
        Ok(self
            .latest_last_known_good_snapshot()?
            .map(|snapshot| snapshot.id.0))
    }

    /// Fold a recovery scan into the daemon's runtime view.
    ///
    /// Three outcomes, and they must stay distinguishable:
    ///
    /// * nothing to do and a readable snapshot -> `Starting`, view restored from the record
    /// * unresolved transactions -> `Recovering` (which gates new applies, not rollback)
    /// * a last-known-good marker the store cannot return -> `Failed`, because the daemon cannot
    ///   claim a state it just failed to read
    pub fn apply_recovery_snapshot(&self, report: &RecoveryScanReport) -> Result<(), String> {
        for decision in &report.decisions {
            self.engine.push_event(
                caly_engine::EventKind::RecoveryDecision,
                None,
                caly_engine::EventPayload::RecoveryDecision {
                    summary: format!("{decision:?}"),
                },
            )?;
        }
        if let Some(snapshot_id) = &report.latest_last_known_good {
            self.engine.push_event(
                caly_engine::EventKind::JournalRecovered,
                None,
                caly_engine::EventPayload::JournalRecovered {
                    journal_id: format!("lkg:{}", snapshot_id.0),
                },
            )?;
        }

        // Read the marker back by id *before* taking the runtime lock. There is deliberately no
        // fallback to `latest_last_known_good_snapshot`: that is the same path the scan already
        // used, so it cannot be independent evidence that the record exists - it would turn "the
        // store disagrees with itself" into "recovered fine".
        let restored = report.latest_last_known_good.as_ref().map(|id| {
            (
                id.clone(),
                self.engine.get_snapshot_by_id(id).ok().flatten(),
            )
        });

        let mut runtime = self
            .runtime
            .lock()
            .map_err(|_| "daemon runtime lock poisoned".to_owned())?;
        runtime.active_snapshot = report
            .latest_last_known_good
            .as_ref()
            .map(|value| value.0.clone());

        let mut unresolvable: Option<String> = None;
        match restored {
            // Restore the whole view from the durable record. This used to assign
            // `active_snapshot` only, so a daemon that recovered successfully still reported
            // "no active profile" through `system.status` while happily serving applies on top of
            // the restored state - two answers to one question, depending on whether the process
            // had restarted.
            Some((_, Some(snapshot))) => {
                runtime.active_profile = Some(caly_api::ProfileId(snapshot.profile_id.clone()));
                runtime.active_core = Some(snapshot.core_identity.clone());
                runtime.last_apply_plan_summary = Some(snapshot.apply_plan_summary.clone());
            }
            Some((snapshot_id, None)) => {
                runtime.active_profile = None;
                runtime.active_core = None;
                runtime.last_apply_plan_summary = None;
                unresolvable = Some(format!(
                    "last-known-good snapshot {} is not readable",
                    snapshot_id.0
                ));
            }
            None => {
                runtime.active_profile = None;
                runtime.active_core = None;
                runtime.last_apply_plan_summary = None;
            }
        }

        runtime.pending_recovery_decisions = report.decisions.len();
        runtime.last_recovery_summary = Some(match (&unresolvable, report.decisions.len()) {
            (Some(reason), 0) => format!("recovery incomplete: {reason}"),
            (Some(reason), count) => format!("recovery decisions={count}: {reason}"),
            (None, 0) => "recovery scan clean".to_owned(),
            (None, count) => format!("recovery decisions={count}"),
        });
        runtime.lifecycle = if unresolvable.is_some() {
            DaemonLifecycle::Failed
        } else if report.decisions.is_empty() {
            DaemonLifecycle::Starting
        } else {
            DaemonLifecycle::Recovering
        };
        if let Some(reason) = unresolvable {
            runtime.last_error = Some(reason);
        }
        Ok(())
    }

    pub fn poll_and_complete_one_for_demo(&self) -> Result<Option<u64>, String> {
        let queued = match self.engine.poll_next()? {
            Some(value) => value,
            None => return Ok(None),
        };
        self.engine.mark_running(&queued)?;
        self.engine.mark_finished(&queued, JobOutcome::Succeeded)?;
        self.sync_runtime_from_engine()?;
        Ok(Some(queued.job_id.0))
    }

    pub fn process_next_job(&self) -> Result<bool, String> {
        let cycles = self.drain_engine_once()?;
        Ok(cycles > 0)
    }

    pub fn event_window(&self, from_exclusive: Option<u64>) -> Result<EventWindow, String> {
        let window = self
            .engine
            .events_since(from_exclusive.map(caly_engine::EventSeq))?;
        self.sync_runtime_from_engine()?;
        Ok(window)
    }

    pub fn follow_events(
        &self,
        from_exclusive: Option<u64>,
    ) -> Result<EventFollowResponse, String> {
        let window = self.event_window(from_exclusive)?;
        Ok(EventFollowResponse {
            next_seq: window.next_seq,
            retained_from: window.retained_from.0,
            reset_required: window.reset_required,
            event_count: window.events.len(),
        })
    }

    pub fn follow_job_projection(
        &self,
        job_id: JobId,
        from_event_index: Option<u64>,
    ) -> Result<Option<JobFollowProjection>, String> {
        let projection = self.engine.project_job_follow(job_id, from_event_index)?;
        self.sync_runtime_from_engine()?;
        Ok(projection)
    }

    pub fn route_request(&self, envelope: &RequestEnvelope) -> DispatchTarget {
        caly_ipc::route_operation(&envelope.operation)
    }

    pub fn allocate_stream(
        &self,
        subscription: RuntimeSubscription,
    ) -> Result<OpenedStream, String> {
        let mut guard = self
            .runtime
            .lock()
            .map_err(|_| "daemon runtime lock poisoned".to_owned())?;
        let stream_id = guard.allocate_stream_id();
        Ok(OpenedStream {
            stream_id,
            subscription_kind: subscription_kind_name(subscription),
        })
    }

    pub fn allocate_job_stream(&self, request: JobFollowRequest) -> Result<OpenedStream, String> {
        let mut guard = self
            .runtime
            .lock()
            .map_err(|_| "daemon runtime lock poisoned".to_owned())?;
        let stream_id = guard.allocate_stream_id();
        Ok(OpenedStream {
            stream_id,
            subscription_kind: format!("job-follow:{}", request.job_id.0),
        })
    }

    pub fn profile_summaries(&self) -> Result<Vec<ProfileSummary>, String> {
        let runtime = self.runtime_snapshot()?;
        let mut items = vec![ProfileSummary {
            id: ProfileId(DEFAULT_PROFILE_ID.to_owned()),
            label: DEFAULT_PROFILE_LABEL.to_owned(),
            active: runtime
                .active_profile
                .as_ref()
                .map(|value| value.0.as_str())
                == Some(DEFAULT_PROFILE_ID),
        }];
        if let Some(active_profile) = runtime.active_profile {
            if active_profile.0 != DEFAULT_PROFILE_ID {
                items.push(ProfileSummary {
                    id: active_profile.clone(),
                    label: format!("Active Profile {}", active_profile.0),
                    active: true,
                });
            }
        }
        Ok(items)
    }

    pub fn profile_view(&self, profile_id: ProfileId) -> Result<ProfileView, String> {
        let runtime = self.runtime_snapshot()?;
        let active = runtime.active_profile.as_ref() == Some(&profile_id);
        Ok(ProfileView {
            summary: ProfileSummary {
                id: profile_id,
                label: if active {
                    "Active Profile".to_owned()
                } else {
                    DEFAULT_PROFILE_LABEL.to_owned()
                },
                active,
            },
            source_count: usize::from(active) + 1,
            core_target: runtime.active_core.unwrap_or_else(|| "auto".to_owned()),
        })
    }

    pub fn core_install_views(&self) -> Result<Vec<CoreInstallView>, String> {
        let runtime = self.runtime_snapshot()?;
        let active_kind = runtime
            .active_core
            .as_deref()
            .and_then(core_kind_from_identity)
            .unwrap_or(DEFAULT_CORE_KIND);
        let active_version = runtime
            .active_core
            .as_deref()
            .and_then(core_version_from_identity)
            .unwrap_or(DEFAULT_CORE_VERSION);
        Ok(vec![CoreInstallView {
            id: CoreInstallId(format!("{}-install", active_kind)),
            kind: active_kind.to_owned(),
            version: active_version.to_owned(),
            active: runtime.active_core.is_some(),
        }])
    }

    pub fn core_inspection(
        &self,
        core_install_id: CoreInstallId,
    ) -> Result<CoreInspection, String> {
        let snapshot = self.latest_last_known_good_snapshot()?;
        let runtime = self.runtime_snapshot()?;
        let install = if let Some(snapshot) = &snapshot {
            CoreInstallView {
                id: core_install_id,
                kind: core_kind_from_identity(&snapshot.core_identity)
                    .unwrap_or(DEFAULT_CORE_KIND)
                    .to_owned(),
                version: core_version_from_identity(&snapshot.core_identity)
                    .unwrap_or(DEFAULT_CORE_VERSION)
                    .to_owned(),
                active: true,
            }
        } else {
            CoreInstallView {
                id: core_install_id,
                kind: runtime
                    .active_core
                    .as_deref()
                    .and_then(core_kind_from_identity)
                    .unwrap_or(DEFAULT_CORE_KIND)
                    .to_owned(),
                version: runtime
                    .active_core
                    .as_deref()
                    .and_then(core_version_from_identity)
                    .unwrap_or(DEFAULT_CORE_VERSION)
                    .to_owned(),
                active: runtime.active_core.is_some(),
            }
        };

        Ok(CoreInspection {
            install,
            binary_digest: snapshot
                .map(|value| value.core_binary_digest)
                .unwrap_or_else(|| DEFAULT_BINARY_DIGEST.to_owned()),
        })
    }

    pub fn source_summaries(&self) -> Result<Vec<SourceSummary>, String> {
        let workflow = self.workflow_for_active_or_default_profile()?;
        Ok(workflow
            .resolved_sources
            .into_iter()
            .map(|source| SourceSummary {
                id: SourceId(source.id),
                label: source.label,
                kind: source.kind,
            })
            .collect())
    }

    pub fn source_inspection(&self, source_id: SourceId) -> Result<SourceInspection, String> {
        let workflow = self.workflow_for_active_or_default_profile()?;
        let source = workflow
            .resolved_sources
            .iter()
            .find(|source| source.id == source_id.0)
            .cloned()
            .unwrap_or(caly_engine::ResolvedSourceSummary {
                id: source_id.0.clone(),
                label: format!("Source {}", source_id.0),
                kind: "subscription".to_owned(),
            });
        Ok(SourceInspection {
            summary: SourceSummary {
                id: SourceId(source.id.clone()),
                label: source.label,
                kind: source.kind,
            },
            latest_digest: Some(format!("digest:{}", source.id)),
            warning_count: workflow.diagnostics.len() as u32,
        })
    }

    pub fn source_preview(&self, request: SourcePreviewRequest) -> Result<SourcePreview, String> {
        if let Some(inline_source) = request.inline_source {
            return Ok(SourcePreview {
                node_count: usize::from(!inline_source.trim().is_empty()),
                group_count: usize::from(!inline_source.trim().is_empty()),
                warnings: Vec::new(),
            });
        }

        let workflow = self.workflow_for_active_or_default_profile()?;
        let requested = request.source_id.map(|source_id| source_id.0);
        let included = workflow
            .resolved_sources
            .iter()
            .filter(|source| {
                requested
                    .as_ref()
                    .map(|value| value == &source.id)
                    .unwrap_or(true)
            })
            .count();
        Ok(SourcePreview {
            node_count: workflow.resolved_nodes.len().min(included.max(1) * 2),
            group_count: workflow.resolved_groups.len().min(included.max(1) * 2),
            warnings: workflow.diagnostics.into_iter().take(4).collect(),
        })
    }

    pub fn node_page(&self, query: NodeQuery) -> Result<NodePage, String> {
        let workflow = self.workflow_for_active_or_default_profile()?;
        let filtered = workflow
            .resolved_nodes
            .into_iter()
            .filter(|node| {
                query
                    .group
                    .as_ref()
                    .map(|group_id| {
                        workflow.resolved_groups.iter().any(|group| {
                            group.id == group_id.0
                                && group.members.iter().any(|member| member == &node.id)
                        })
                    })
                    .unwrap_or(true)
            })
            .filter(|node| {
                query
                    .search
                    .as_ref()
                    .map(|search| {
                        node.label
                            .to_ascii_lowercase()
                            .contains(&search.to_ascii_lowercase())
                    })
                    .unwrap_or(true)
            })
            .map(|node| NodeView {
                id: caly_api::NodeId(node.id),
                label: node.label,
                protocol: node.protocol,
            })
            .collect::<Vec<_>>();
        paged_node_view(
            filtered,
            query.page,
            self.runtime_snapshot()?.state_revision,
        )
    }

    pub fn group_views(&self) -> Result<Vec<GroupView>, String> {
        let workflow = self.workflow_for_active_or_default_profile()?;
        Ok(workflow
            .resolved_groups
            .into_iter()
            .map(|group| GroupView {
                id: caly_api::GroupId(group.id),
                label: group.label,
                selected: group.selected.map(caly_api::NodeId),
            })
            .collect())
    }

    pub fn rule_page(&self, query: RuleQuery) -> Result<RulePage, String> {
        let workflow = self.workflow_for_active_or_default_profile()?;
        let items = workflow
            .resolved_rules
            .into_iter()
            .map(|rule| RuleView {
                id: rule.id,
                label: format!("{} [{}]", rule.label, rule.action),
            })
            .collect::<Vec<_>>();
        paged_rule_view(items, query.page, self.runtime_snapshot()?.state_revision)
    }

    pub fn route_explain(
        &self,
        request: RouteExplainRequest,
    ) -> Result<RouteExplainResult, String> {
        let workflow = self.workflow_for_active_or_default_profile()?;
        let matched = workflow
            .resolved_rules
            .iter()
            .find(|rule| {
                rule.label
                    .to_ascii_lowercase()
                    .contains(&request.target.to_ascii_lowercase())
                    || rule
                        .target
                        .as_ref()
                        .map(|target| {
                            target
                                .to_ascii_lowercase()
                                .contains(&request.target.to_ascii_lowercase())
                        })
                        .unwrap_or(false)
            })
            .or_else(|| workflow.resolved_rules.first());

        Ok(RouteExplainResult {
            matched_rule: matched.map(|rule| rule.label.clone()),
            action: matched
                .map(|rule| rule.action.clone())
                .unwrap_or_else(|| "direct".to_owned()),
        })
    }

    pub fn routing_validation(&self, profile_id: ProfileId) -> Result<RoutingValidation, String> {
        let workflow = self.workflow_for_profile(profile_id)?;
        let warning_count = workflow
            .diagnostics
            .iter()
            .filter(|line| {
                line.to_ascii_lowercase().contains("routing")
                    || line.to_ascii_lowercase().contains("rule")
            })
            .count() as u32;
        Ok(RoutingValidation {
            warning_count,
            error_count: workflow.capability.blocked_count as u32,
        })
    }

    pub fn dns_status(&self) -> Result<DnsStatus, String> {
        let workflow = self.workflow_for_active_or_default_profile()?;
        Ok(DnsStatus {
            fake_ip_enabled: workflow
                .resolved_network
                .dns_mode
                .as_deref()
                .map(|value| matches!(value, "fake-ip" | "mixed"))
                .unwrap_or(false),
            cache_entries: 0,
        })
    }

    pub fn dns_explain(&self, request: DnsExplainRequest) -> Result<DnsExplainResult, String> {
        let workflow = self.workflow_for_active_or_default_profile()?;
        let resolved_via = workflow
            .resolved_network
            .dns_servers
            .first()
            .cloned()
            .or(workflow.resolved_network.dns_mode.clone())
            .unwrap_or_else(|| "system".to_owned());
        Ok(DnsExplainResult {
            resolved_via: format!("{} via {}", request.domain_or_ip, resolved_via),
            outbound: workflow
                .resolved_groups
                .first()
                .map(|group| group.label.clone()),
        })
    }

    pub fn network_plan_view(&self, profile_id: ProfileId) -> Result<NetworkPlanView, String> {
        let workflow = self.workflow_for_profile(profile_id)?;
        Ok(NetworkPlanView {
            summary: format!(
                "apply={} steps={} warnings={}",
                workflow.apply_plan_kind,
                workflow.effect_steps.len(),
                workflow.diagnostics.len()
            ),
            requires_privilege: workflow
                .effect_steps
                .iter()
                .any(|step| step.contains("net-apply")),
        })
    }

    pub fn connection_page(&self, query: ConnectionQuery) -> Result<ConnectionPage, String> {
        let workflow = self.workflow_for_active_or_default_profile()?;
        let items = workflow
            .resolved_nodes
            .into_iter()
            .map(|node| ConnectionView {
                id: caly_api::ConnectionId(format!("conn-{}", node.id)),
                destination: format!("{}://{}", node.protocol, node.label),
                process: Some(workflow.resolved.profile_id.clone()),
            })
            .collect::<Vec<_>>();
        paged_connection_view(items, query.page, self.runtime_snapshot()?.state_revision)
    }

    pub fn automation_job_views(&self) -> Result<Vec<AutomationJobView>, String> {
        let runtime = self.runtime_snapshot()?;
        let profile_id = runtime
            .active_profile
            .clone()
            .unwrap_or_else(|| ProfileId(DEFAULT_PROFILE_ID.to_owned()));
        let overrides = self.engine.automation_overrides()?;
        let override_map = overrides
            .into_iter()
            .collect::<std::collections::BTreeMap<_, _>>();

        let defaults = vec![
            AutomationJobView {
                id: format!("automation.apply:{}", profile_id.0),
                label: format!("Auto apply {}", profile_id.0),
                enabled: true,
            },
            AutomationJobView {
                id: format!("automation.sources:{}", profile_id.0),
                label: format!("Refresh sources for {}", profile_id.0),
                enabled: true,
            },
            AutomationJobView {
                id: "automation.recovery.guard".to_owned(),
                label: "Recovery guard".to_owned(),
                enabled: runtime.pending_recovery_decisions == 0,
            },
        ];

        Ok(defaults
            .into_iter()
            .map(|job| AutomationJobView {
                enabled: override_map.get(&job.id).copied().unwrap_or(job.enabled),
                ..job
            })
            .collect())
    }

    pub fn patch_automation_job(&self, request: PatchAutomationJob) -> Result<(), String> {
        self.engine.set_automation_job(&request)
    }

    pub fn make_demo_command(
        &self,
        trace: impl Into<String>,
        kind: caly_engine::CommandKind,
    ) -> Command {
        let trace_id = TraceId::new(trace);
        Command {
            id: CommandId(format!("cmd-{}", trace_id.0)),
            request_id: None,
            actor: Actor::Cli,
            context: caly_common::RequestContext::new(trace_id, Actor::Cli),
            timeout_ms: Some(30_000),
            idempotency_key: None,
            kind,
        }
    }
}

impl DaemonApp {
    fn workflow_for_active_or_default_profile(
        &self,
    ) -> Result<caly_engine::ApplyWorkflowResult, String> {
        let runtime = self.runtime_snapshot()?;
        let profile_id = runtime
            .active_profile
            .unwrap_or_else(|| ProfileId(DEFAULT_PROFILE_ID.to_owned()));
        self.workflow_for_profile(profile_id)
    }

    fn workflow_for_profile(
        &self,
        profile_id: ProfileId,
    ) -> Result<caly_engine::ApplyWorkflowResult, String> {
        plan_apply_request(ApplyRequest {
            profile_id,
            dry_run: true,
            strict: false,
        })
    }
}

fn paged_node_view(
    items: Vec<NodeView>,
    page: caly_api::PageRequest,
    revision: u64,
) -> Result<NodePage, String> {
    let start = page
        .cursor
        .as_deref()
        .unwrap_or("0")
        .parse::<usize>()
        .unwrap_or(0);
    let limit = page.limit.max(1) as usize;
    let next_index = start.saturating_add(limit);
    let page_items = items
        .into_iter()
        .skip(start)
        .take(limit)
        .collect::<Vec<_>>();
    let next = if page_items.len() == limit {
        Some(next_index.to_string())
    } else {
        None
    };
    Ok(NodePage {
        items: page_items,
        next,
        revision,
    })
}

fn paged_rule_view(
    items: Vec<RuleView>,
    page: caly_api::PageRequest,
    revision: u64,
) -> Result<RulePage, String> {
    let start = page
        .cursor
        .as_deref()
        .unwrap_or("0")
        .parse::<usize>()
        .unwrap_or(0);
    let limit = page.limit.max(1) as usize;
    let next_index = start.saturating_add(limit);
    let page_items = items
        .into_iter()
        .skip(start)
        .take(limit)
        .collect::<Vec<_>>();
    let next = if page_items.len() == limit {
        Some(next_index.to_string())
    } else {
        None
    };
    Ok(RulePage {
        items: page_items,
        next,
        revision,
    })
}

fn paged_connection_view(
    items: Vec<ConnectionView>,
    page: caly_api::PageRequest,
    revision: u64,
) -> Result<ConnectionPage, String> {
    let start = page
        .cursor
        .as_deref()
        .unwrap_or("0")
        .parse::<usize>()
        .unwrap_or(0);
    let limit = page.limit.max(1) as usize;
    let next_index = start.saturating_add(limit);
    let page_items = items
        .into_iter()
        .skip(start)
        .take(limit)
        .collect::<Vec<_>>();
    let next = if page_items.len() == limit {
        Some(next_index.to_string())
    } else {
        None
    };
    Ok(ConnectionPage {
        items: page_items,
        next,
        revision,
    })
}

fn core_kind_from_identity(identity: &str) -> Option<&str> {
    identity.split_once('@').map(|(kind, _)| kind)
}

fn core_version_from_identity(identity: &str) -> Option<&str> {
    identity.split_once('@').map(|(_, version)| version)
}

pub fn unsupported_request_response(
    app: &DaemonApp,
    envelope: &RequestEnvelope,
) -> ResponseEnvelope {
    ResponseEnvelope {
        request_id: envelope.request_id,
        trace_id: envelope.trace_id.clone(),
        result: Err(app.redact_error(ApiError::new(
            caly_api::ErrorCode::Unavailable,
            caly_api::ErrorCategory::User,
            false,
            format!(
                "operation routed to {:?} but no daemon handler is connected yet",
                caly_ipc::route_operation(&envelope.operation)
            ),
            envelope.trace_id.clone(),
        ))),
    }
}

/// Short, stable description of a command kind for error text.
fn command_line(kind: &caly_engine::CommandKind) -> String {
    match kind {
        caly_engine::CommandKind::ProfileApply(request) => {
            format!("profile.apply {}", request.profile_id.0)
        }
        caly_engine::CommandKind::ProfileRollback(_) => "profile.rollback".to_owned(),
        caly_engine::CommandKind::SourceUpdate { source_id } => {
            format!("source.update {source_id}")
        }
        caly_engine::CommandKind::ProxySelect { group_id, node_id } => {
            format!("proxy.select {group_id} -> {node_id}")
        }
        caly_engine::CommandKind::ProxyTestDelay { node_ids } => {
            format!("proxy.test-delay {} node(s)", node_ids.len())
        }
        caly_engine::CommandKind::DnsFlushCache => "dns.flush-cache".to_owned(),
        caly_engine::CommandKind::RuntimeCloseConnection { connection_id } => {
            format!("runtime.close-connection {connection_id}")
        }
        caly_engine::CommandKind::NetworkRepair => "network.repair".to_owned(),
        caly_engine::CommandKind::DiagnosticsBundle => "diagnostics.bundle".to_owned(),
        caly_engine::CommandKind::AutomationPatch(job) => {
            format!("automation.patch {}", job.job_id)
        }
        caly_engine::CommandKind::SystemShutdown => "system.shutdown".to_owned(),
        // The bounds are echoed because a refusal that says only "the collection was refused" cannot
        // be told apart from one refused at *these* numbers.
        caly_engine::CommandKind::StorageGc {
            grace_period_ms,
            max_deletions,
        } => format!("system.gc-collect grace={grace_period_ms:?} max_deletions={max_deletions:?}"),
    }
}
