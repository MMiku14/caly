use caly_api::{
    ConnectionQuery, JobFollowRequest, Operation, OperationResult, PageRequest, RequestEnvelope,
    RuntimeStatus, RuntimeSubscription, WatchOpened,
};
use caly_ipc::{
    json_from_records, stream_policy, AckPolicy, StreamFrame, StreamKind, StreamPayload,
};

use crate::app::DaemonApp;

/// How many frames ONE pull of an event-bridged watch stream may carry
/// (`IPC_STREAM_POLICY §7`): a pull is a bounded unit of work, the engine's retained event
/// window (256 events) holds the rest, and the stream's own cursor picks up on the next
/// pull. An unbounded batch would make the slowest client's pull the biggest write the
/// daemon ever does.
pub const MAX_WATCH_FRAMES_PER_PULL: usize = 64;

/// The session's opened-stream table is bounded (round 133, `R131-F1`): the same admission
/// rule the wire door's job-follow table has had since round 96 (`MAX_STREAM_TABLE`), applied
/// to the watch family's session-side table. Streams in the session machine do not END
/// (there is no eviction yet — that lands with the wire watch round), so the cap is what
/// keeps a long-lived client from growing the table without bound.
pub const MAX_OPENED_SESSION_STREAMS: usize = 64;

/// The flat-record rendering of the `runtime.status` facts — the same eight keys the
/// records/JSON wire face carries (`calyd`'s response renderer prepends `request_id` and
/// reuses exactly these records; the dashboard snapshot carries them verbatim). One
/// rendering, two faces: a key that appears on one and not the other is a drift this
/// module's judges are built to bite.
pub fn runtime_status_field_records(status: &RuntimeStatus) -> Vec<(String, String)> {
    let none = String::new;
    vec![
        ("core_running".to_owned(), status.core_running.to_string()),
        (
            "active_profile".to_owned(),
            status
                .active_profile
                .as_ref()
                .map(|id| id.0.clone())
                .unwrap_or_else(none),
        ),
        (
            "active_core".to_owned(),
            status.active_core.clone().unwrap_or_else(none),
        ),
        (
            "active_snapshot".to_owned(),
            status.active_snapshot.clone().unwrap_or_else(none),
        ),
        (
            "last_apply_plan_summary".to_owned(),
            status.last_apply_plan_summary.clone().unwrap_or_else(none),
        ),
        (
            "pending_recovery_decisions".to_owned(),
            status.pending_recovery_decisions.to_string(),
        ),
        (
            "last_recovery_summary".to_owned(),
            status.last_recovery_summary.clone().unwrap_or_else(none),
        ),
        (
            "last_failure".to_owned(),
            status.last_failure.clone().unwrap_or_else(none),
        ),
    ]
}

/// Whether a kind has SnapshotThenPatch semantics (`IPC_STREAM_POLICY §3`): the first pull
/// is a snapshot of the CURRENT state, later pulls are patches. Dashboard and Connections
/// restate their one-shot queries; the event kinds (Traffic/Logs) and the Job stream have
/// their own policies and their own producers.
pub fn is_snapshot_then_patch(kind: StreamKind) -> bool {
    matches!(kind, StreamKind::Dashboard | StreamKind::Connections)
}

/// Build the FIRST frame of a SnapshotThenPatch stream: the kind's own one-shot query,
/// restated as one `SnapshotJson` frame seq'd at the given position. The snapshot comes
/// from the same projections the queries serve — a second dashboard renderer is how the
/// query and the stream would drift apart.
pub fn snapshot_frame(
    app: &DaemonApp,
    kind: StreamKind,
    stream_id: caly_api::StreamId,
    seq: u64,
) -> Result<StreamFrame, String> {
    let payload = match kind {
        StreamKind::Dashboard => {
            let status = app.runtime_status()?;
            StreamPayload::SnapshotJson(json_from_records(&runtime_status_field_records(&status)))
        }
        StreamKind::Connections => {
            let page = app.connection_page(ConnectionQuery {
                page: PageRequest {
                    cursor: None,
                    limit: 50,
                },
            })?;
            let mut records = Vec::new();
            for (index, item) in page.items.iter().enumerate() {
                records.push((format!("item.{index}.id"), item.id.0.clone()));
                records.push((
                    format!("item.{index}.destination"),
                    item.destination.clone(),
                ));
                records.push((
                    format!("item.{index}.process"),
                    item.process.clone().unwrap_or_default(),
                ));
            }
            records.push(("next".to_owned(), page.next.clone().unwrap_or_default()));
            records.push(("revision".to_owned(), page.revision.to_string()));
            StreamPayload::SnapshotJson(json_from_records(&records))
        }
        other => {
            return Err(format!(
                "stream kind {other:?} has no snapshot semantics; the snapshot path is for \
                 Dashboard/Connections (IPC_STREAM_POLICY §3)"
            ))
        }
    };
    Ok(StreamFrame {
        stream_id,
        seq,
        kind,
        payload,
    })
}

/// Three-way, like the Query door (round 133, `R131-F3`): `Ok(None)` really is "this door
/// does not speak the operation" (→ UNSUPPORTED); an allocation FAILURE is an internal error
/// and must answer as one — `.ok()?` used to relabel a poisoned runtime lock as "unsupported",
/// pointing the operator's triage in the wrong direction.
pub fn handle_stream(
    app: &DaemonApp,
    envelope: &RequestEnvelope,
) -> Result<Option<OperationResult>, Box<caly_api::ApiError>> {
    match &envelope.operation {
        Operation::Runtime(caly_api::RuntimeOp::Watch { subscription }) => {
            let runtime = app
                .allocate_stream(subscription.clone())
                .map_err(|summary| {
                    Box::new(caly_api::ApiError::internal(
                        summary,
                        envelope.trace_id.clone(),
                    ))
                })?;
            Ok(Some(OperationResult::WatchOpened(WatchOpened {
                stream_id: caly_api::StreamId(runtime.stream_id),
                subscription_kind: runtime.subscription_kind,
            })))
        }
        Operation::Diagnostics(caly_api::DiagnosticsOp::FollowJobStream { request }) => {
            let runtime = app
                .allocate_job_stream(request.clone())
                .map_err(|summary| {
                    Box::new(caly_api::ApiError::internal(
                        summary,
                        envelope.trace_id.clone(),
                    ))
                })?;
            Ok(Some(OperationResult::WatchOpened(WatchOpened {
                stream_id: caly_api::StreamId(runtime.stream_id),
                subscription_kind: runtime.subscription_kind,
            })))
        }
        _ => Ok(None),
    }
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct OpenedStream {
    pub stream_id: u64,
    pub subscription_kind: String,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub enum StreamSource {
    RuntimeSubscription(RuntimeSubscription),
    JobFollow(JobFollowRequest),
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct OpenedStreamState {
    pub stream_id: caly_api::StreamId,
    pub kind: StreamKind,
    pub source: StreamSource,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct StreamCursorState {
    pub opened: OpenedStreamState,
    pub last_emitted_seq: Option<u64>,
    pub acked_upto: Option<u64>,
}

impl StreamCursorState {
    pub fn new(opened: OpenedStreamState) -> Self {
        Self {
            opened,
            last_emitted_seq: None,
            acked_upto: None,
        }
    }

    pub fn note_emitted_frames(&mut self, frames: &[StreamFrame]) {
        if let Some(last) = frames.last() {
            self.last_emitted_seq = Some(last.seq);
        }
    }

    pub fn apply_ack(&mut self, upto_seq: u64) {
        self.acked_upto = Some(
            self.acked_upto
                .map(|current| current.max(upto_seq))
                .unwrap_or(upto_seq),
        );
    }

    pub fn preferred_resume_from(&self, explicit: Option<u64>) -> Option<u64> {
        if explicit.is_some() {
            return explicit;
        }

        match stream_policy(self.opened.kind).ack {
            AckPolicy::Required | AckPolicy::Optional => self.acked_upto.or(self.last_emitted_seq),
            AckPolicy::None => self.last_emitted_seq,
        }
    }
}

pub fn subscription_kind_name(subscription: RuntimeSubscription) -> String {
    caly_ipc::subscription_kind_name(subscription).to_owned()
}

pub fn stream_kind_for_operation(operation: &Operation) -> Option<StreamKind> {
    match operation {
        Operation::Runtime(caly_api::RuntimeOp::Watch { subscription }) => {
            Some(caly_ipc::stream_kind_for_subscription(subscription.clone()))
        }
        Operation::Diagnostics(caly_api::DiagnosticsOp::FollowJobStream { .. }) => {
            Some(StreamKind::Job)
        }
        _ => None,
    }
}

pub fn opened_stream_state_for_operation(
    operation: &Operation,
    opened: &WatchOpened,
) -> Option<OpenedStreamState> {
    let kind = stream_kind_for_operation(operation)?;
    let source = match operation {
        Operation::Runtime(caly_api::RuntimeOp::Watch { subscription }) => {
            StreamSource::RuntimeSubscription(subscription.clone())
        }
        Operation::Diagnostics(caly_api::DiagnosticsOp::FollowJobStream { request }) => {
            StreamSource::JobFollow(request.clone())
        }
        _ => return None,
    };

    Some(OpenedStreamState {
        stream_id: opened.stream_id,
        kind,
        source,
    })
}
