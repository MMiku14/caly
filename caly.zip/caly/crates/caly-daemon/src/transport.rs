use caly_common::Actor;
use caly_ipc::{
    ClientFrame, ClientHello, FrameHeader, NegotiationPolicy, ServerFrame, SessionLoopInput,
    SessionLoopOutput,
};

use crate::app::DaemonApp;
use crate::session::DaemonSession;
use crate::session_loop::{
    handle_session_input, inspect_session, SessionRuntimeConfig, SessionStepReport,
};

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct DaemonTransportConfig {
    pub actor: Actor,
    pub session_id: String,
    pub hello_timeout_ms: u64,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub enum TransportStepOutput {
    HelloAck(caly_ipc::ServerHelloAck),
    ResponseFrames(Vec<ServerFrame>),
    StreamFrames(Vec<ServerFrame>),
    Closed(caly_ipc::SessionCloseReason),
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct TransportInspection {
    pub session: SessionStepReport,
    pub open_stream_count: usize,
}

pub struct DaemonTransport {
    session: DaemonSession,
    config: SessionRuntimeConfig,
}

impl DaemonTransport {
    pub fn new(policy: NegotiationPolicy, config: DaemonTransportConfig) -> Self {
        Self {
            session: DaemonSession::new(config.actor, policy),
            config: SessionRuntimeConfig {
                session_id: config.session_id,
                hello_timeout_ms: config.hello_timeout_ms,
            },
        }
    }

    pub fn on_hello(
        &mut self,
        app: &DaemonApp,
        header: FrameHeader,
        hello: ClientHello,
    ) -> Result<TransportStepOutput, String> {
        let output = handle_session_input(
            &mut self.session,
            app,
            &self.config,
            SessionLoopInput::Hello { header, hello },
        )
        .map_err(|error| error.summary)?;
        Ok(map_session_output(output))
    }

    pub fn on_client_frame(
        &mut self,
        app: &DaemonApp,
        header: FrameHeader,
        frame: ClientFrame,
        is_control_message: bool,
    ) -> Result<TransportStepOutput, String> {
        let output = handle_session_input(
            &mut self.session,
            app,
            &self.config,
            SessionLoopInput::ClientFrame {
                header,
                frame,
                is_control_message,
            },
        )
        .map_err(|error| error.summary)?;
        Ok(map_session_output(output))
    }

    pub fn on_hello_timeout(&mut self, app: &DaemonApp) -> Result<TransportStepOutput, String> {
        let output = handle_session_input(
            &mut self.session,
            app,
            &self.config,
            SessionLoopInput::HelloTimeoutExpired,
        )
        .map_err(|error| error.summary)?;
        Ok(map_session_output(output))
    }

    pub fn close(
        &mut self,
        app: &DaemonApp,
        reason: caly_ipc::SessionCloseReason,
    ) -> Result<TransportStepOutput, String> {
        let output = handle_session_input(
            &mut self.session,
            app,
            &self.config,
            SessionLoopInput::Close { reason },
        )
        .map_err(|error| error.summary)?;
        Ok(map_session_output(output))
    }

    pub fn pull_stream(
        &mut self,
        app: &DaemonApp,
        stream_id: caly_api::StreamId,
        from_seq_exclusive: Option<u64>,
    ) -> Result<TransportStepOutput, String> {
        let frames = self
            .session
            .follow_opened_stream(app, stream_id, from_seq_exclusive)?;
        Ok(TransportStepOutput::StreamFrames(frames))
    }

    pub fn inspect(&self) -> TransportInspection {
        TransportInspection {
            session: inspect_session(&self.session),
            open_stream_count: self.session.opened_streams.len(),
        }
    }

    /// The role the peer **declared in its hello**, as the negotiated session records it.
    ///
    /// `ADR-037` puts the caller's role on the cross-façade envelope and makes `required_role`
    /// a real gate (`RFC-0002 §7.2`). The local façade takes its role from the composition root;
    /// a *wire* peer's role is the one it negotiated at hello — there is no other honest source.
    /// The request frame therefore carries THIS role into `require_role`, not a hard-coded
    /// `Admin`: otherwise every remote caller (including one that declared `Operator`) would
    /// pass an `Admin`-only operation, a silent privilege escalation that makes the wire-side
    /// permission gate unfailable. Returns `None` before hello is accepted (the frame loop
    /// only builds envelopes after `hello_seen`, so this is `Some` there).
    pub fn peer_role(&self) -> Option<caly_api::Role> {
        self.session.machine.info.as_ref().map(|info| info.role)
    }
}

fn map_session_output(output: SessionLoopOutput) -> TransportStepOutput {
    match output {
        SessionLoopOutput::HelloAck(ack) => TransportStepOutput::HelloAck(ack),
        SessionLoopOutput::Frames(frames) => TransportStepOutput::ResponseFrames(frames),
        SessionLoopOutput::Closed { reason } => TransportStepOutput::Closed(reason),
    }
}
