use caly_api::{ApiError, ErrorCategory, ErrorCode, TraceId};
use caly_engine::OverloadReport;
use caly_ipc::{FrameValidationError, HandshakeError, SessionLoopError};

pub fn map_handshake_error(trace_id: TraceId, error: HandshakeError) -> ApiError {
    let code = match error.code {
        caly_ipc::HandshakeErrorCode::ProtoMismatch => ErrorCode::ProtoMismatch,
        caly_ipc::HandshakeErrorCode::InvalidClientName => ErrorCode::ConfigInvalid,
        caly_ipc::HandshakeErrorCode::UnsupportedEncoding => ErrorCode::ProtoMismatch,
        caly_ipc::HandshakeErrorCode::UnsupportedCompression => ErrorCode::ProtoMismatch,
    };

    ApiError::new(code, ErrorCategory::User, false, error.summary, trace_id)
}

pub fn map_frame_validation_error(trace_id: TraceId, error: FrameValidationError) -> ApiError {
    let retryable = matches!(
        error.code,
        caly_ipc::FrameValidationErrorCode::FrameTooLarge
    );
    ApiError::new(
        ErrorCode::Unavailable,
        ErrorCategory::Io,
        retryable,
        error.summary,
        trace_id,
    )
}

pub fn map_session_loop_error(trace_id: TraceId, error: SessionLoopError) -> ApiError {
    let code = match error.code {
        caly_ipc::SessionLoopErrorCode::HelloRequired => ErrorCode::ProtoMismatch,
        caly_ipc::SessionLoopErrorCode::HelloInActiveSession => ErrorCode::ProtoMismatch,
        caly_ipc::SessionLoopErrorCode::FrameInvalid => ErrorCode::Unavailable,
        caly_ipc::SessionLoopErrorCode::RequestInvalid => ErrorCode::ConfigInvalid,
        caly_ipc::SessionLoopErrorCode::SessionClosed => ErrorCode::Unavailable,
    };
    ApiError::new(code, ErrorCategory::User, false, error.summary, trace_id)
}

/// The daemon's boundary for a refusal caused by pressure.
///
/// It delegates, and that is the whole point. This function used to build its own `ApiError` from the
/// report, keeping only `code` / `category` / `retryable` / `summary` — so a client that was told
/// "UNAVAILABLE, maybe retry" could not learn *what* was full or *what to do*, which is exactly what
/// `docs/engineering/OVERLOAD_AND_RETRY_MODEL.md §8` forbids ("只返回一条 `Unavailable`，不给任何细分线索").
/// Meanwhile `OverloadReport::to_api_error`, which did carry the hint, had no callers. Two mappers,
/// one of them better and unused, is how a boundary quietly becomes the lossy one
/// (`docs/history/ONBOARDING_NOTES.md §4.59`).
pub fn map_overload_report(trace_id: TraceId, report: OverloadReport) -> ApiError {
    report.to_api_error(trace_id)
}
