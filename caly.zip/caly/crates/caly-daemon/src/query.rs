mod automation;
mod common;
mod core;
mod diagnostics;
mod dns;
mod network;
mod profile;
mod proxy;
mod routing;
mod runtime;
mod source;
mod system;

use caly_api::{Operation, OperationResult, RequestEnvelope};

use crate::app::DaemonApp;

pub fn handle_query(
    app: &DaemonApp,
    ctx: &caly_common::RequestContext,
    envelope: &RequestEnvelope,
) -> Result<Option<OperationResult>, caly_api::ApiError> {
    // `ctx` is the caller the daemon is answering right now (`ADR-039 §2`, step 4). It threads to
    // the store through the one query family that reads storage today (diagnostics, for the
    // support-bundle objects); the families that answer from memory alone do not take it — an
    // unused parameter would be its own kind of drift. A family that grows a storage read adds
    // the parameter, and this match arm's `ctx` in scope is what makes forgetting it a compile
    // error rather than a silent ghost context.
    match &envelope.operation {
        Operation::System(op) => system::handle_system(app, envelope, op),
        Operation::Profile(op) => profile::handle_profile(app, envelope, op),
        Operation::Source(op) => source::handle_source(app, envelope, op),
        Operation::Proxy(op) => proxy::handle_proxy(app, envelope, op),
        Operation::Routing(op) => routing::handle_routing(app, envelope, op),
        Operation::Dns(op) => dns::handle_dns(app, envelope, op),
        Operation::Network(op) => network::handle_network(app, envelope, op),
        Operation::Core(op) => core::handle_core(app, envelope, op),
        Operation::Runtime(op) => runtime::handle_runtime(app, envelope, op),
        Operation::Diagnostics(op) => diagnostics::handle_diagnostics(app, ctx, envelope, op),
        Operation::Automation(op) => automation::handle_automation(app, envelope, op),
    }
}
