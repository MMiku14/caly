//! The real effect backend — the daemon side of `ROADMAP §13`'s "同一 executor 跑真核" (round 55).
//!
//! The engine's executor drives [`EffectRuntime`] (round 55 unbound it from the simulator);
//! this module is the daemon-side implementation that makes the *same* plan touch a real
//! host: a `WriteObject` claim is verified against the real store, `MaterializeArtifact`
//! writes a real file under the runtime root, `SpawnCore` runs a real mihomo **or a real
//! sing-box** from the workspace's pinned assets (round 58, `ADR-046`), `Probe` asks the
//! core's own controller through the `Http` port, and `StopCore` stops through the `Proc`
//! port's supervision surface (`ADR-043`).
//!
//! Where this backend does not yet tell the truth it **refuses by name** instead of
//! pretending: `NetApply`/`NetRevert` (the privileged `Platform` face is a deliberate
//! absence, `ADR-042 §2.2`), `DbTxn`, and every `CoreApiCall` except `Status`. A green apply
//! on this backend therefore means what it says.
//!
//! Two recorded gaps, kept visible rather than papered over:
//!
//! * ~~the plan's `binary_digest` was the adapter's placeholder~~ — closed in round 56:
//!   the plan now carries the pinned asset's real sha256 (`caly_mihomo::
//!   MIHOMO_BINARY_SHA256`), and `SpawnCore` **hashes the exact bytes it is about to
//!   deploy** and refuses a mismatch by name (`binary-digest-mismatch`, both digests in
//!   the message). "Run whatever is on disk" is how a supply chain becomes a hope;
//! * the run config is an **envelope**: artifact content (profile truth) plus operational
//!   keys the runtime owns (ports, controller, geo fallbacks deliberately pointed at
//!   `127.0.0.1:1` so a missing geo file stays a *loud* failure, never a silent download).
//!   The adapter renders none of those keys, so the concatenation is a config the core can
//!   actually parse — a duplicated key would be a config mihomo refuses to load.
//!
//! Bookkeeping note: each adapter names its own instance label
//! (`"mihomo-core-instance"` / `"singbox-core-instance"`) across
//! `SpawnCore`/`StopCore`/`CoreApiCall`; this backend has exactly ONE instance slot, so
//! both labels address it — the label says which core the plan means, the slot says how
//! many may live at once (one; a spawn over a live core is refused by name).

use std::collections::BTreeMap;
use std::net::TcpListener;
use std::sync::{Arc, Mutex};
use std::time::Duration;

use caly_engine::executor::{StepEvidence, StepFailure};
use caly_engine::recovery::run_ready;
use caly_engine::{CoreCall, CoreKind, EffectRuntime, EffectStep, EngineHandle, ProbeKind};
use caly_io::{
    block_on_ready, ByteCap, Bytes, Clock, Durability, FetchReq, FetchRoute, FetchScope, Fs, Http,
    IoContext, Proc, SpawnSpec, VPath,
};
use caly_io_std::{CoreRouteSource, StdClock, StdFs, StdHttp, StdProc};
use caly_storage::{ApplyPhase, StorageBackend};

/// The plan's single instance label (`caly-mihomo` adapter). Named here once so the backend
/// and the plan cannot drift apart silently.
const INSTANCE: &str = "mihomo-core-instance";
const SINGBOX_INSTANCE: &str = "singbox-core-instance";

/// The workspace's pinned core assets. Paths, not digests: the sha256 pinning already has
/// its own judge (`real_core.rs`); this struct is the composition root saying "run *these*
/// files".
#[derive(Clone, Debug)]
pub struct CoreAssets {
    pub mihomo_gz: String,
    pub singbox_tgz: String,
    pub geoip: String,
    pub geosite: String,
}

impl CoreAssets {
    /// `<workspace>/assets/…`, resolved at compile time from this crate's manifest dir.
    pub fn workspace_default() -> Self {
        let manifest = env!("CARGO_MANIFEST_DIR");
        let cut = manifest.len() - "crates/caly-daemon".len();
        let root = &manifest[..cut];
        Self::from_directory(format!("{root}/assets"))
    }

    /// Build the pinned asset layout used by the real runtime from an operator-owned directory.
    ///
    /// The filenames are part of the supply-chain contract: the spawn path still hashes the exact
    /// bytes before use, while this constructor keeps the composition root from accepting a vague
    /// "assets somewhere" setting that could silently select a different file.
    pub fn from_directory(directory: impl AsRef<std::path::Path>) -> Self {
        let directory = directory.as_ref();
        Self {
            mihomo_gz: directory
                .join("cores/mihomo-linux-amd64-v1.19.30.gz")
                .to_string_lossy()
                .into_owned(),
            singbox_tgz: directory
                .join("cores/sing-box-1.13.20-linux-amd64.tar.gz")
                .to_string_lossy()
                .into_owned(),
            geoip: directory
                .join("geo/geoip.metadb")
                .to_string_lossy()
                .into_owned(),
            geosite: directory
                .join("geo/geosite.dat")
                .to_string_lossy()
                .into_owned(),
        }
    }

    /// Validate the files that a real runtime may later read, before the daemon starts listening.
    ///
    /// This is intentionally a read/shape check, not a digest check: each selected core is hashed
    /// against the plan at spawn time, and an asset that is readable but not the pinned bytes must
    /// fail there by name. Preflight only turns a missing or unreadable operator configuration into
    /// a startup refusal instead of a delayed first-apply failure.
    pub fn validate_readable(&self) -> Result<(), String> {
        for (name, path) in [
            ("mihomo core asset", &self.mihomo_gz),
            ("sing-box core asset", &self.singbox_tgz),
            ("geoip asset", &self.geoip),
            ("geosite asset", &self.geosite),
        ] {
            let metadata = std::fs::metadata(path)
                .map_err(|error| format!("{name} {path:?} cannot be inspected: {error}"))?;
            if !metadata.is_file() {
                return Err(format!("{name} {path:?} is not a regular file"));
            }
            std::fs::OpenOptions::new()
                .read(true)
                .open(path)
                .map_err(|error| format!("{name} {path:?} is not readable: {error}"))?;
        }
        Ok(())
    }
}

struct LiveInstance {
    handle: caly_io::ChildHandle,
    controller_port: u16,
    /// The mixed inbound's port — the proxy door the `ActiveCore` route uses (`ADR-047 §2`).
    mixed_port: u16,
    config_digest: String,
    /// Round 69: which spawn path ran. The CoreIdentity probe names this next to the
    /// core's self-reported version — the plan spawned a *kind*, the probe reports the
    /// pairing, and nothing is assumed from the controller's answer alone.
    core_kind: CoreKind,
}

#[derive(Default)]
struct RuntimeState {
    /// digest → where it was materialized (`SpawnCore` finds its config here: the plan names
    /// digests, not paths).
    materialized: BTreeMap<String, String>,
    /// The one live instance, under the plan's label.
    instance: Option<LiveInstance>,
}

/// The real effect backend. Everything that touches the host goes through the IO gateway
/// (`StdFs`/`StdProc`/`StdHttp`/`StdClock`), with one deliberate exception: reading the
/// pinned assets from the workspace, which lives *outside* the runtime root by design — the
/// gateway's root sandbox is for runtime state, not for the immutable asset store.
pub struct StdEffectRuntime {
    store: Arc<dyn StorageBackend>,
    fs: StdFs,
    proc: StdProc,
    http: StdHttp,
    /// The live core's mixed inbound, shared with `StdHttp` (`ADR-047 §2`): spawn writes it,
    /// stop clears it, and every `ActiveCore` fetch resolves through this one cell — no
    /// second bookkeeping to drift against the instance slot.
    core_route: CoreRouteSource,
    clock: StdClock,
    assets: CoreAssets,
    state: Mutex<RuntimeState>,
}

impl StdEffectRuntime {
    pub fn new(
        root: impl Into<String>,
        store: Arc<dyn StorageBackend>,
        assets: CoreAssets,
    ) -> Self {
        let root = root.into();
        let core_route: CoreRouteSource = std::sync::Arc::new(Mutex::new(None));
        // The system proxy is resolved from the environment ONCE, here at the composition
        // root (`ADR-048 §2`); a fetch re-reading env mid-flight would make one apply's
        // routes depend on when it happened to run.
        let mut http = StdHttp::with_core_route(std::sync::Arc::clone(&core_route));
        if let Some(proxy) = StdHttp::system_proxy_from_env() {
            http = http.with_system_proxy(proxy);
        }
        Self {
            store,
            fs: StdFs::new(root.clone()),
            proc: StdProc::new(root),
            http,
            core_route,
            clock: StdClock::new(),
            assets,
            state: Mutex::new(RuntimeState::default()),
        }
    }

    fn ctx(&self) -> IoContext {
        EngineHandle::store_ctx()
    }

    fn poisoned() -> StepFailure {
        StepFailure::new("internal", "real runtime state lock poisoned", false)
    }

    /// Pick a free loopback port the way the composition root owns it: bind(0), read, drop.
    fn free_port() -> Result<u16, StepFailure> {
        TcpListener::bind("127.0.0.1:0")
            .and_then(|listener| listener.local_addr())
            .map(|address| address.port())
            .map_err(|error| {
                StepFailure::new(
                    "port-allocation",
                    format!("pick a free port: {error}"),
                    true,
                )
            })
    }

    /// Drive one boxed port future to completion (`run_ready` is the engine's own driver —
    /// the backend and the engine share a single, bounded definition of "run").
    fn port<R>(
        &self,
        future: caly_io::BoxFuture<'_, Result<R, caly_io::IoFault>>,
        code: &'static str,
    ) -> Result<R, StepFailure> {
        block_on_ready(future)
            .map_err(|summary| StepFailure::new(code, summary, true))?
            .map_err(|fault| StepFailure::new(code, fault.summary, true))
    }

    /// Drive one boxed store future (same driver, storage's error type).
    fn stored<R>(
        &self,
        future: caly_io::BoxFuture<'_, Result<R, caly_storage::StorageError>>,
        code: &'static str,
    ) -> Result<R, StepFailure> {
        run_ready(future)
            .map_err(|summary| StepFailure::new(code, summary, true))?
            .map_err(|error| StepFailure::new(code, error.summary, true))
    }

    /// Read a file under the runtime root through the `Fs` port.
    fn read_root(&self, path: &str, cap: u64, code: &'static str) -> Result<Bytes, StepFailure> {
        let vpath = VPath::try_from_str(path).map_err(|error| {
            StepFailure::new("invalid-path", format!("{path:?}: {error:?}"), false)
        })?;
        self.port(self.fs.read(&vpath, ByteCap(cap), &self.ctx()), code)
    }

    /// Write a file under the runtime root through the `Fs` port.
    fn write_root(&self, path: &str, data: Bytes, code: &'static str) -> Result<(), StepFailure> {
        let vpath = VPath::try_from_str(path).map_err(|error| {
            StepFailure::new("invalid-path", format!("{path:?}: {error:?}"), false)
        })?;
        self.port(
            self.fs
                .write_atomic(&vpath, data, Durability::D1, &self.ctx()),
            code,
        )
    }

    /// Ask the live core's controller `/version`. `false` means "not answering", whatever
    /// the reason — the callers (probe poll, status call) turn that into their own failures.
    fn controller_answers(&self, port: u16) -> bool {
        let request = FetchReq {
            url: format!("http://127.0.0.1:{port}/version"),
            route: FetchRoute::Direct,
            // RFC-0010 §11.1's explicit exemption: this is calyd's own spawned core
            // management address, not an untrusted target.
            scope: FetchScope::AnyPeer,
            etag: None,
            if_modified_since: None,
            max_body_bytes: 65_536,
        };
        matches!(
            self.port(self.http.fetch(request, &self.ctx()), "controller-fetch"),
            Ok(resp) if resp.status == 200
        )
    }

    /// `GET /version`'s self-reported `version` field — the core naming itself. A 200 whose
    /// body is not that JSON is a refusal: answering and identifying are different facts.
    fn controller_version(&self, port: u16) -> Result<String, String> {
        let body = self.fetch_controller_json(port, "version")?;
        body.get("version")
            .and_then(|value| value.as_str())
            .map(str::to_owned)
            .ok_or_else(|| "the /version body has no usable `version` field".to_owned())
    }

    /// The live core's own cumulative counters (`uploadTotal` / `downloadTotal` from
    /// `GET /connections`). Both cores serve these under the clash-API field names and both
    /// are monotonic per process, so a later fetch through the core must move them. mihomo's
    /// `/traffic` also carries totals but sing-box's `/traffic` is rates only — `/connections`
    /// is the one surface the two agree on.
    fn controller_totals(&self, port: u16) -> Result<(u64, u64), String> {
        let body = self.fetch_controller_json(port, "connections")?;
        let upload = body
            .get("uploadTotal")
            .and_then(|value| value.as_u64())
            .ok_or_else(|| "no u64 `uploadTotal`".to_owned())?;
        let download = body
            .get("downloadTotal")
            .and_then(|value| value.as_u64())
            .ok_or_else(|| "no u64 `downloadTotal`".to_owned())?;
        Ok((upload, download))
    }

    fn fetch_controller_json(&self, port: u16, path: &str) -> Result<serde_json::Value, String> {
        let request = FetchReq {
            url: format!("http://127.0.0.1:{port}/{path}"),
            route: FetchRoute::Direct,
            // Same exemption as `controller_answers`: the address is the daemon's own
            // spawned core controller (RFC-0010 §11.1).
            scope: FetchScope::AnyPeer,
            etag: None,
            if_modified_since: None,
            max_body_bytes: 65_536,
        };
        let resp = self
            .port(self.http.fetch(request, &self.ctx()), "controller-fetch")
            .map_err(|error| format!("controller fetch failed: {}", error.summary))?;
        if resp.status != 200 {
            return Err(format!("controller answered HTTP {}", resp.status));
        }
        serde_json::from_slice(&resp.body.bytes)
            .map_err(|error| format!("the /{path} body is not JSON: {error}"))
    }

    /// The mihomo spawn path: gzip asset, YAML envelope with operational keys appended,
    /// geo files the envelope's rules make load-bearing, one supervised process.
    fn spawn_mihomo_core(
        &self,
        binary_digest: &str,
        config_digest: &str,
    ) -> Result<StepEvidence, StepFailure> {
        // Round 56 (`ADR-044 §5.1` closed): the plan pins the binary it expects
        // (`caly_mihomo::MIHOMO_BINARY_SHA256`), and the check hashes the exact
        // bytes about to be deployed — not a filename, not a remembered constant.
        // It runs before anything else: a supply-chain refusal is not made better
        // by first proving the config was materialized.
        let core_gz = std::fs::read(&self.assets.mihomo_gz).map_err(|error| {
            StepFailure::new(
                "asset-read",
                format!("{}: {error}", self.assets.mihomo_gz),
                false,
            )
        })?;
        let core_sha256 = caly_common::digest::sha256_hex(&core_gz);
        if binary_digest != core_sha256 {
            return Err(StepFailure::new(
                "binary-digest-mismatch",
                format!(
                    "the plan pins core binary {binary_digest}; this backend's asset \
                             {} hashes to {core_sha256} — refusing to run a binary the plan \
                             did not name",
                    self.assets.mihomo_gz
                ),
                false,
            ));
        }
        let at = self
            .state
            .lock()
            .map_err(|_| Self::poisoned())?
            .materialized
            .get(config_digest)
            .cloned()
            .ok_or_else(|| {
                StepFailure::new(
                    "object-not-found",
                    format!(
                        "cannot spawn a core whose config {config_digest} was never \
                                 materialized on this backend"
                    ),
                    false,
                )
            })?;
        let dir = at
            .rsplit_once('/')
            .map(|(head, _)| head.to_owned())
            .unwrap_or_default();

        // The envelope: artifact content + operational keys (see module docs).
        let artifact =
            String::from_utf8_lossy(&self.read_root(&at, 4 << 20, "fs-read")?).into_owned();
        let mixed_port = Self::free_port()?;
        let controller_port = Self::free_port()?;
        let envelope = format!(
                    "{artifact}\n# caly runtime envelope — operational keys, not profile content\n\
                     mixed-port: {mixed_port}\n\
                     external-controller: 127.0.0.1:{controller_port}\n\
                     log-level: info\n\
                     geox-url:\n  geoip: \"http://127.0.0.1:1/geoip.metadb\"\n  geosite: \"http://127.0.0.1:1/geosite.dat\"\n  mmdb: \"http://127.0.0.1:1/country.mmdb\"\n  asn: \"http://127.0.0.1:1/GeoLite2-ASN.mmdb\"\n"
                );
        self.write_root(
            &format!("{dir}/caly-run.yaml"),
            envelope.into_bytes(),
            "fs-write",
        )?;

        // The assets the envelope's geo rules make load-bearing: copied from the
        // pinned workspace store into the instance dir through the same write path
        // as everything else under the root.
        let geoip = std::fs::read(&self.assets.geoip).map_err(|error| {
            StepFailure::new(
                "asset-read",
                format!("{}: {error}", self.assets.geoip),
                false,
            )
        })?;
        let geosite = std::fs::read(&self.assets.geosite).map_err(|error| {
            StepFailure::new(
                "asset-read",
                format!("{}: {error}", self.assets.geosite),
                false,
            )
        })?;
        self.write_root(&format!("{dir}/geoip.metadb"), geoip, "asset-copy")?;
        self.write_root(&format!("{dir}/geosite.dat"), geosite, "asset-copy")?;
        self.write_root(&format!("{dir}/core.gz"), core_gz, "asset-copy")?;

        let cwd = VPath::try_from_str(&dir).map_err(|error| {
            StepFailure::new("invalid-path", format!("{dir:?}: {error:?}"), false)
        })?;
        // One live instance per label — the plan's own shape. A second spawn
        // without a stop would orphan the first core (no handle left to stop it
        // with), and orphaning is exactly what refusing loudly exists to prevent.
        {
            let state = self.state.lock().map_err(|_| Self::poisoned())?;
            if state.instance.is_some() {
                return Err(StepFailure::new(
                    "instance-already-running",
                    format!(
                        "cannot spawn over {INSTANCE}: stop it first — the plan \
                                 spawns twice without a stop, which would orphan the live core"
                    ),
                    false,
                ));
            }
        }
        let handle = self.port(
            self.proc.spawn(
                SpawnSpec {
                    // The one shell use, and it is ours: fixed filenames only, no
                    // profile content, and `exec` so the handle's pid *is* the
                    // core's pid after the chain. `-f` matters: a revived
                    // deployment reuses the instance dir, where `core` already
                    // exists — plain gunzip would refuse to overwrite and the
                    // chain would die before the core ever started (round 57
                    // found this exactly there).
                    program: "/bin/sh".to_owned(),
                    argv: vec![
                        "-c".to_owned(),
                        "gunzip -kf core.gz && chmod +x core && exec ./core -d . -f caly-run.yaml"
                            .to_owned(),
                    ],
                    cwd: Some(cwd),
                    env: Vec::new(),
                },
                &self.ctx(),
            ),
            "spawn",
        )?;

        let evidence = StepEvidence::one(format!(
            "proc.spawn {INSTANCE} config={config_digest} plan_binary={binary_digest} \
                     asset=mihomo-linux-amd64-v1.19.30 controller=127.0.0.1:{controller_port} \
                     pid={}",
            handle.pid
        ));
        self.state
            .lock()
            .map_err(|_| Self::poisoned())?
            .instance
            .replace(LiveInstance {
                handle,
                controller_port,
                mixed_port,
                config_digest: config_digest.to_owned(),
                core_kind: CoreKind::Mihomo,
            });
        // The core answers proxy requests on its mixed inbound from now on.
        self.set_core_route(Some(mixed_port));
        Ok(evidence)
    }

    /// The sing-box spawn path (round 58, `ADR-046 §2`): tar.gz asset, JSON envelope
    /// whose deployment facts are MERGED into the adapter's object (never string-
    /// concatenated), no geo files (the render references none), one supervised process.
    /// The `ConfigIdentity` truth is the same as mihomo's: the digest handed to the core
    /// at spawn, recorded here and compared by the probe.
    fn spawn_singbox_core(
        &self,
        binary_digest: &str,
        config_digest: &str,
    ) -> Result<StepEvidence, StepFailure> {
        // Supply-chain check first, identical doctrine to mihomo: hash the exact bytes
        // about to be deployed, refuse a mismatch by name (`caly_singbox::
        // SINGBOX_BINARY_SHA256` is what the plan pins).
        let core_tgz = std::fs::read(&self.assets.singbox_tgz).map_err(|error| {
            StepFailure::new(
                "asset-read",
                format!("{}: {error}", self.assets.singbox_tgz),
                false,
            )
        })?;
        let core_sha256 = caly_common::digest::sha256_hex(&core_tgz);
        if binary_digest != core_sha256 {
            return Err(StepFailure::new(
                "binary-digest-mismatch",
                format!(
                    "the plan pins core binary {binary_digest}; this backend's asset \
                     {} hashes to {core_sha256} — refusing to run a binary the plan \
                     did not name",
                    self.assets.singbox_tgz
                ),
                false,
            ));
        }
        let at = self
            .state
            .lock()
            .map_err(|_| Self::poisoned())?
            .materialized
            .get(config_digest)
            .cloned()
            .ok_or_else(|| {
                StepFailure::new(
                    "object-not-found",
                    format!(
                        "cannot spawn a core whose config {config_digest} was never \
                         materialized on this backend"
                    ),
                    false,
                )
            })?;
        let dir = at
            .rsplit_once('/')
            .map(|(head, _)| head.to_owned())
            .unwrap_or_default();

        // The envelope: the adapter's JSON object with the deployment facts this runtime
        // owns written INTO it — the mixed inbound's listen port (a deployment fact, the
        // same round-55 rule as mihomo's `mixed-port`) and the clash-api controller the
        // ApiReady probe polls. String concatenation cannot do this honestly; the merge
        // is structural (`ADR-046 §2`).
        let artifact_bytes = self.read_root(&at, 4 << 20, "fs-read")?;
        let mut config: serde_json::Value =
            serde_json::from_slice(&artifact_bytes).map_err(|error| {
                StepFailure::new(
                    "envelope-decode",
                    format!("the sing-box artifact is not a JSON object: {error}"),
                    false,
                )
            })?;
        let mixed_port = Self::free_port()?;
        let controller_port = Self::free_port()?;
        if let Some(inbounds) = config.get_mut("inbounds").and_then(|v| v.as_array_mut()) {
            for inbound in inbounds.iter_mut() {
                if inbound.get("type").and_then(serde_json::Value::as_str) == Some("mixed") {
                    inbound["listen_port"] = serde_json::Value::from(mixed_port);
                    break;
                }
            }
        }
        if let Some(experimental) = config
            .get_mut("experimental")
            .and_then(|v| v.as_object_mut())
        {
            experimental.insert(
                "clash_api".to_owned(),
                serde_json::json!({
                    "external_controller": format!("127.0.0.1:{controller_port}")
                }),
            );
        }
        let envelope = serde_json::to_vec_pretty(&config).map_err(|error| {
            StepFailure::new(
                "envelope-encode",
                format!("the merged sing-box envelope cannot re-serialize: {error}"),
                false,
            )
        })?;
        self.write_root(&format!("{dir}/caly-run.json"), envelope, "fs-write")?;
        self.write_root(&format!("{dir}/core.tar.gz"), core_tgz, "asset-copy")?;

        let cwd = VPath::try_from_str(&dir).map_err(|error| {
            StepFailure::new("invalid-path", format!("{dir:?}: {error:?}"), false)
        })?;
        // One live instance per backend — the same slot, the same rule, the same refusal.
        {
            let state = self.state.lock().map_err(|_| Self::poisoned())?;
            if state.instance.is_some() {
                return Err(StepFailure::new(
                    "instance-already-running",
                    format!(
                        "cannot spawn over {SINGBOX_INSTANCE}: stop it first — the plan \
                         spawns twice without a stop, which would orphan the live core"
                    ),
                    false,
                ));
            }
        }
        let handle = self.port(
            self.proc.spawn(
                SpawnSpec {
                    // The one shell use, and it is ours: fixed filenames only, no
                    // profile content, and `exec` so the handle's pid *is* the core's
                    // pid after the chain. tar overwrites by default, so a revived
                    // deployment reusing the instance dir re-extracts cleanly (the
                    // gunzip lesson of round 57, paid forward).
                    program: "/bin/sh".to_owned(),
                    argv: vec![
                        "-c".to_owned(),
                        "tar -xzf core.tar.gz --strip-components=1 && chmod +x sing-box \
                         && exec ./sing-box run -D . -c caly-run.json"
                            .to_owned(),
                    ],
                    cwd: Some(cwd),
                    env: Vec::new(),
                },
                &self.ctx(),
            ),
            "spawn",
        )?;

        let evidence = StepEvidence::one(format!(
            "proc.spawn {SINGBOX_INSTANCE} config={config_digest} plan_binary={binary_digest} \
             asset=sing-box-1.13.20-linux-amd64 controller=127.0.0.1:{controller_port} \
             pid={}",
            handle.pid
        ));
        self.state
            .lock()
            .map_err(|_| Self::poisoned())?
            .instance
            .replace(LiveInstance {
                handle,
                controller_port,
                mixed_port,
                config_digest: config_digest.to_owned(),
                core_kind: CoreKind::SingBox,
            });
        // The core answers proxy requests on its mixed inbound from now on.
        self.set_core_route(Some(mixed_port));
        Ok(evidence)
    }

    /// Stop a live instance through the `Proc` port and report how it left.
    fn stop_instance(
        &self,
        live: LiveInstance,
        grace_ms: u64,
    ) -> Result<StepEvidence, StepFailure> {
        let exit = self.port(self.proc.stop(&live.handle, grace_ms), "stop")?;
        // No live core, no core route: an ActiveCore fetch after this must fail by name,
        // not by dialing a port the kernel may hand to someone else (`ADR-047 §2`). The
        // evidence names the proxy door that just closed.
        self.set_core_route(None);
        Ok(StepEvidence::one(format!(
            "proc.stop {INSTANCE} exit code={} signaled={} grace={grace_ms}ms \
             mixed_port={} (core route closed)",
            exit.code, exit.signaled, live.mixed_port
        )))
    }

    /// Publish (or clear) the live core's proxy door in the shared route source. A poisoned
    /// source cannot be updated; fetches then fail honestly on their own lookup.
    fn set_core_route(&self, port: Option<u16>) {
        let mut guarded = if let Ok(guard) = self.core_route.lock() {
            guard
        } else {
            return;
        };
        *guarded = port.map(|port| std::net::SocketAddr::from(([127, 0, 0, 1], port)));
    }

    /// Direct access to the http port for diagnostics: the same adapter the effects use,
    /// no second client with its own quirks.
    pub fn http_probe_fetch(
        &self,
        request: caly_io::FetchReq,
    ) -> caly_io::BoxFuture<'static, Result<caly_io::FetchResp, caly_io::IoFault>> {
        let http = self.http.clone();
        let ctx = self.ctx();
        Box::pin(async move { http.fetch(request, &ctx).await })
    }

    /// Fetch a URL through the ACTIVE core's mixed inbound (`ADR-047 §2`) — the operator's
    /// question ("does the proxy path work?") answered by the proxy path itself. Returns
    /// the HTTP status, or the port family's own words for why not.
    pub fn fetch_via_active_core(&self, url: &str, max_body_bytes: u64) -> Result<u16, String> {
        let request = caly_io::FetchReq {
            url: url.to_owned(),
            route: caly_io::FetchRoute::ActiveCore,
            // The ActiveCore route is exempt from the SSRF gate (RFC-0010 §11.1: the
            // active core management address is explicitly allowed); the scope field says
            // the conservative default because no exemption is being requested here.
            scope: caly_io::FetchScope::Default,
            etag: None,
            if_modified_since: None,
            max_body_bytes,
        };
        let ctx = self.ctx();
        match caly_io::block_on_ready(self.http.fetch(request, &ctx)) {
            Ok(Ok(resp)) => Ok(resp.status),
            Ok(Err(fault)) => Err(fault.summary),
            Err(not_ready) => Err(not_ready),
        }
    }

    /// Round 69: the live core's identity — `(kind, version)` — read through the same path
    /// the CoreIdentity probe uses, so a judge asserts on the production parsing, not on a
    /// second client.
    pub fn controller_identity(&self) -> Result<(String, String), String> {
        let (port, kind) = {
            let state = self.state.lock().map_err(|_| "state poisoned".to_owned())?;
            let live = state
                .instance
                .as_ref()
                .ok_or_else(|| "no live core".to_owned())?;
            (live.controller_port, live.core_kind)
        };
        Ok((
            core_kind_name(kind).to_owned(),
            self.controller_version(port)?,
        ))
    }

    /// Round 69: the live core's own cumulative counters, through the same parse the
    /// TelemetryTraffic probe uses.
    pub fn controller_traffic_totals(&self) -> Result<(u64, u64), String> {
        let port = {
            let state = self.state.lock().map_err(|_| "state poisoned".to_owned())?;
            let live = state
                .instance
                .as_ref()
                .ok_or_else(|| "no live core".to_owned())?;
            live.controller_port
        };
        self.controller_totals(port)
    }

    /// Orderly shutdown of whatever this runtime still runs: the surface daemon teardown —
    /// and every judge that spawned a real core — owes the host. A runtime that can start
    /// processes but cannot be told to stop them would be a leak with a type name.
    pub fn shutdown(&self, grace_ms: u64) -> Option<caly_io::ChildExit> {
        let live = self.state.lock().ok()?.instance.take()?;
        // The route closes with the core (`ADR-047 §2`): shutdown bypasses the plan path,
        // but the honesty rule is the same — no live core, no route to a freed port.
        self.set_core_route(None);
        caly_io::block_on_ready(self.proc.stop(&live.handle, grace_ms))
            .ok()?
            .ok()
    }

    /// The live core's pid, if one runs — an operator's question, answered from the same
    /// bookkeeping the effects use (never a second source of truth).
    pub fn live_pid(&self) -> Option<u32> {
        self.state
            .lock()
            .ok()?
            .instance
            .as_ref()
            .map(|live| live.handle.pid)
    }

    /// Whether the live core's controller answers — the same probe the `ApiReady` step
    /// runs, exposed so an operator (and a judge) can ask the core itself.
    pub fn controller_ready(&self) -> bool {
        let port = self
            .state
            .lock()
            .ok()
            .and_then(|guard| guard.instance.as_ref().map(|live| live.controller_port));
        port.map(|port| self.controller_answers(port))
            .unwrap_or(false)
    }
}

impl EffectRuntime for StdEffectRuntime {
    fn execute(&self, _phase: ApplyPhase, step: &EffectStep) -> Result<StepEvidence, StepFailure> {
        match step {
            // The claim is "the object is in the store". Phase A already put the artifact
            // bytes into CAS (`begin_apply_persistence`); a real backend *checks* that
            // claim instead of simulating it.
            EffectStep::WriteObject { digest, source, .. } => {
                let found = self.stored(self.store.get(digest, &self.ctx()), "store-read")?;
                if found.is_none() {
                    return Err(StepFailure::new(
                        "object-not-found",
                        format!(
                            "the plan writes object {digest} but the store does not hold it; \
                             Phase A persistence should have put it before effects ran"
                        ),
                        false,
                    ));
                }
                Ok(StepEvidence::one(format!(
                    "cas.write exists {digest} size={} (verified in the store)",
                    source.size_hint.unwrap_or(0)
                )))
            }
            EffectStep::MaterializeArtifact { digest, at, mode } => {
                let bytes = self
                    .stored(
                        self.store.read_object(digest, 4 << 20, &self.ctx()),
                        "store-read",
                    )?
                    .ok_or_else(|| {
                        StepFailure::new(
                            "object-not-found",
                            format!("cannot materialize {at}: object {digest} is not in the store"),
                            false,
                        )
                    })?;
                self.write_root(at, bytes, "fs-write")?;
                self.state
                    .lock()
                    .map_err(|_| Self::poisoned())?
                    .materialized
                    .insert(digest.clone(), at.clone());
                Ok(StepEvidence::one(format!(
                    "fs.materialize {at} mode={mode:?} (real file under the runtime root)"
                )))
            }
            EffectStep::SpawnCore { spec } => {
                // Both real cores have spawn faces now (round 58, `ADR-046 §2`): the
                // pinned-asset digest check, the envelope, and the probe surface are
                // per-core; the instance slot and the honesty rules are shared.
                match spec.kind {
                    CoreKind::Mihomo => {
                        self.spawn_mihomo_core(&spec.binary_digest, &spec.config_digest)
                    }
                    CoreKind::SingBox => {
                        self.spawn_singbox_core(&spec.binary_digest, &spec.config_digest)
                    }
                }
            }
            EffectStep::StopCore { instance, grace_ms } => {
                let live = self
                    .state
                    .lock()
                    .map_err(|_| Self::poisoned())?
                    .instance
                    .take();
                match live {
                    // Both adapters' labels address the one slot (`ADR-046 §4`): the
                    // label says which core the plan means, not a second instance.
                    Some(live) if instance.0 == INSTANCE || instance.0 == SINGBOX_INSTANCE => {
                        self.stop_instance(live, *grace_ms)
                    }
                    Some(live) => {
                        // A plan stopping an id this backend never spawned: put it back and
                        // refuse — losing the handle would make a later real stop impossible.
                        self.state.lock().map_err(|_| Self::poisoned())?.instance = Some(live);
                        Err(StepFailure::new(
                            "unknown-instance",
                            format!(
                                "cannot stop {}: this backend's live instance is {INSTANCE}",
                                instance.0
                            ),
                            false,
                        ))
                    }
                    // Round 59 (`ADR-047 §3`): stopping what is not running is
                    // already-done — the simulator has always said `already-gone`, and a
                    // core that crashed (or was stopped out-of-band) must not brick every
                    // later apply at its Restart plan's StopCore step.
                    None => Ok(StepEvidence::one(format!(
                        "proc.stop {} already-gone (nothing running on this backend)",
                        instance.0
                    ))),
                }
            }
            EffectStep::Probe { probe, deadline_ms } => match probe.kind {
                ProbeKind::ApiReady => {
                    let port = self
                        .state
                        .lock()
                        .map_err(|_| Self::poisoned())?
                        .instance
                        .as_ref()
                        .map(|live| live.controller_port)
                        .ok_or_else(|| {
                            StepFailure::new(
                                "no-running-core",
                                "cannot probe ApiReady: no live instance on this backend",
                                false,
                            )
                        })?;
                    let started = self.clock.mono().ticks_millis;
                    loop {
                        if self.controller_answers(port) {
                            return Ok(StepEvidence::took(
                                format!("probe.api-ready controller=127.0.0.1:{port} answered 200"),
                                self.clock.mono().ticks_millis.saturating_sub(started),
                            ));
                        }
                        if self.clock.mono().ticks_millis.saturating_sub(started) >= *deadline_ms {
                            return Err(StepFailure::new(
                                "probe-timeout",
                                format!(
                                    "the core's controller never answered within {deadline_ms}ms"
                                ),
                                true,
                            ));
                        }
                        std::thread::sleep(Duration::from_millis(100));
                    }
                }
                ProbeKind::ConfigIdentity => {
                    // The identity a core runs is what it was handed — this backend knows
                    // the digest it wrapped into the envelope.
                    let live_digest = self
                        .state
                        .lock()
                        .map_err(|_| Self::poisoned())?
                        .instance
                        .as_ref()
                        .map(|live| live.config_digest.clone())
                        .ok_or_else(|| {
                            StepFailure::new(
                                "no-running-core",
                                "cannot probe ConfigIdentity: no live instance",
                                false,
                            )
                        })?;
                    match &probe.target {
                        Some(target) if target == &live_digest => Ok(StepEvidence::one(format!(
                            "probe.config-identity {target} matches the live core"
                        ))),
                        Some(target) => Err(StepFailure::new(
                            "config-identity-mismatch",
                            format!("the plan expects config {target}; the live core runs {live_digest}"),
                            false,
                        )),
                        None => Ok(StepEvidence::one(
                            "probe.config-identity (no expectation to compare)".to_owned(),
                        )),
                    }
                }
                ProbeKind::CoreIdentity => {
                    // Round 69 (`IMPLEMENTATION_STATUS §8.4`): `ApiReady` proved the
                    // controller answers; this probe reads WHAT answers. A 200 whose body
                    // is not `{"version": "…"}` is a refusal, not an identity — a skeleton
                    // that hardcodes its version would pass the 200 check and fail here.
                    let (port, kind) = {
                        let state = self.state.lock().map_err(|_| Self::poisoned())?;
                        let live = state.instance.as_ref().ok_or_else(|| {
                            StepFailure::new(
                                "no-running-core",
                                "cannot probe CoreIdentity: no live instance",
                                false,
                            )
                        })?;
                        (live.controller_port, live.core_kind)
                    };
                    let started = self.clock.mono().ticks_millis;
                    let version = self.controller_version(port).map_err(|reason| {
                        StepFailure::new(
                            "core-identity-unreadable",
                            format!(
                                "the controller on 127.0.0.1:{port} answered but its identity \
                                 could not be read: {reason}"
                            ),
                            false,
                        )
                    })?;
                    Ok(StepEvidence::took(
                        format!(
                            "probe.core-identity kind={} version={version} \
                             controller=127.0.0.1:{port}",
                            core_kind_name(kind)
                        ),
                        self.clock.mono().ticks_millis.saturating_sub(started),
                    ))
                }
                ProbeKind::TelemetryTraffic => {
                    // Round 69: the core's own counters, one-shot. `GET /connections` on
                    // both cores carries cumulative `uploadTotal`/`downloadTotal` (mihomo's
                    // `/traffic` has them too, but sing-box's `/traffic` is rates only —
                    // connections is the surface both cores agree on). The value recorded
                    // here is the apply-time baseline; a later fetch through the core must
                    // move it.
                    let port = {
                        let state = self.state.lock().map_err(|_| Self::poisoned())?;
                        let live = state.instance.as_ref().ok_or_else(|| {
                            StepFailure::new(
                                "no-running-core",
                                "cannot probe TelemetryTraffic: no live instance",
                                false,
                            )
                        })?;
                        live.controller_port
                    };
                    let started = self.clock.mono().ticks_millis;
                    let (upload, download) = self.controller_totals(port).map_err(|reason| {
                        StepFailure::new(
                            "telemetry-unreadable",
                            format!(
                                "the controller on 127.0.0.1:{port} answered but its traffic \
                                 counters could not be read: {reason}"
                            ),
                            false,
                        )
                    })?;
                    Ok(StepEvidence::took(
                        format!(
                            "probe.telemetry-traffic upload_total={upload} \
                             download_total={download} controller=127.0.0.1:{port}"
                        ),
                        self.clock.mono().ticks_millis.saturating_sub(started),
                    ))
                }
                ProbeKind::InboundListening => {
                    // Round 59 (`ADR-047 §3`): the proxy door itself. ApiReady proves the
                    // controller answers; this proves the mixed inbound ACCEPTS — the two
                    // come up a few milliseconds apart, and "apply completed" must mean
                    // both (a judge found the gap by fetching through a freshly applied
                    // core and racing the bind).
                    let (port, digest) = {
                        let state = self.state.lock().map_err(|_| Self::poisoned())?;
                        state
                            .instance
                            .as_ref()
                            .map(|live| (live.mixed_port, live.config_digest.clone()))
                            .ok_or_else(|| {
                                StepFailure::new(
                                    "no-running-core",
                                    "cannot probe InboundListening: no live instance",
                                    false,
                                )
                            })?
                    };
                    let _ = digest;
                    let started = self.clock.mono().ticks_millis;
                    loop {
                        if std::net::TcpStream::connect_timeout(
                            &std::net::SocketAddr::from(([127, 0, 0, 1], port)),
                            Duration::from_millis(300),
                        )
                        .is_ok()
                        {
                            return Ok(StepEvidence::took(
                                format!(
                                    "probe.inbound-listening mixed=127.0.0.1:{port} accepts \
                                     connections (the proxy door is open)"
                                ),
                                self.clock.mono().ticks_millis.saturating_sub(started),
                            ));
                        }
                        if self.clock.mono().ticks_millis.saturating_sub(started) >= *deadline_ms {
                            return Err(StepFailure::new(
                                "inbound-not-listening",
                                format!(
                                    "the core's mixed inbound 127.0.0.1:{port} never accepted \
                                     within {deadline_ms}ms — the proxy door is not open"
                                ),
                                true,
                            ));
                        }
                        std::thread::sleep(Duration::from_millis(50));
                    }
                }
                other => Err(StepFailure::new(
                    "unsupported-probe",
                    format!(
                        "the real backend implements ApiReady, ConfigIdentity and \
                         InboundListening; {other:?} has no honest implementation yet — \
                         refusing rather than pretending"
                    ),
                    false,
                )),
            },
            EffectStep::CoreApiCall { instance, call } => {
                let port = self
                    .state
                    .lock()
                    .map_err(|_| Self::poisoned())?
                    .instance
                    .as_ref()
                    .filter(|_| instance.0 == INSTANCE || instance.0 == SINGBOX_INSTANCE)
                    .map(|live| live.controller_port)
                    .ok_or_else(|| {
                        StepFailure::new(
                            "no-running-core",
                            format!("cannot call the core: {} is not live", instance.0),
                            false,
                        )
                    })?;
                match call {
                    CoreCall::Status => {
                        if self.controller_answers(port) {
                            Ok(StepEvidence::one(format!(
                                "core.call {} status (controller answered 200)",
                                instance.0
                            )))
                        } else {
                            Err(StepFailure::new(
                                "core-status",
                                format!("{} did not answer its controller", instance.0),
                                true,
                            ))
                        }
                    }
                    other => Err(StepFailure::new(
                        "unsupported-core-call",
                        format!(
                            "the real backend implements Status only; {other:?} has no honest \
                             implementation yet — refusing rather than pretending"
                        ),
                        false,
                    )),
                }
            }
            EffectStep::NetApply { plan } => Err(StepFailure::new(
                "unsupported-net-apply",
                format!(
                    "the privileged Platform face is a deliberate absence (ADR-042 §2.2); \
                     \"{}\" cannot be applied on the real backend yet",
                    plan.summary
                ),
                false,
            )),
            EffectStep::NetRevert { txn_id } => Err(StepFailure::new(
                "unsupported-net-revert",
                format!(
                    "the privileged Platform face is a deliberate absence (ADR-042 §2.2); \
                     net transaction {} cannot be reverted on the real backend",
                    txn_id.0
                ),
                false,
            )),
            EffectStep::DbTxn { .. } => Err(StepFailure::new(
                "unsupported-db",
                "this backend has no database yet; a DbTxn step has no honest implementation"
                    .to_owned(),
                false,
            )),
            // The store-side truth of these two lives in the journal/snapshot machinery the
            // executor drives (the same split as the simulator); the runtime's part is the
            // evidence that the phase ran.
            EffectStep::MarkSnapshot { snapshot_id } => Ok(StepEvidence::one(format!(
                "snapshot.mark {}",
                snapshot_id.0
            ))),
            EffectStep::CommitRevision { revision } => {
                Ok(StepEvidence::one(format!("revision.commit {revision}")))
            }
        }
    }

    fn compensate(
        &self,
        _phase: ApplyPhase,
        step: &EffectStep,
    ) -> Result<StepEvidence, StepFailure> {
        match step {
            // Kill the new core through the port, grace 0: compensation is the "take it
            // back" path, and a core that just failed its probe gets no flushing window.
            EffectStep::SpawnCore { .. } => {
                let live = self
                    .state
                    .lock()
                    .map_err(|_| Self::poisoned())?
                    .instance
                    .take();
                match live {
                    Some(live) => {
                        let exit = self.port(self.proc.stop(&live.handle, 0), "stop")?;
                        Ok(StepEvidence::one(format!(
                            "compensate.kill-new-core exit code={} signaled={}",
                            exit.code, exit.signaled
                        )))
                    }
                    None => Ok(StepEvidence::one(
                        "compensate.kill-new-core (nothing live)".to_owned(),
                    )),
                }
            }
            EffectStep::MaterializeArtifact { at, .. } => {
                let path = VPath::try_from_str(at).map_err(|error| {
                    StepFailure::new("invalid-path", format!("{at:?}: {error:?}"), false)
                })?;
                let _ = self.port(self.fs.remove(&path, &self.ctx()), "fs-remove");
                self.state
                    .lock()
                    .map_err(|_| Self::poisoned())?
                    .materialized
                    .remove(at);
                Ok(StepEvidence::one(format!("compensate.unmaterialize {at}")))
            }
            // Compensating a stop = the rollback of a plan that stopped a core. For a
            // spawn-bearing restart plan the honest reach of round 55 is "the new core is
            // dead and its file gone"; *restarting the old core* has no step to express it
            // yet, and pretending otherwise is the silence this module refuses.
            EffectStep::StopCore { instance, .. } => {
                let live = self
                    .state
                    .lock()
                    .map_err(|_| Self::poisoned())?
                    .instance
                    .take();
                match live {
                    Some(live) if instance.0 == INSTANCE => {
                        let exit = self.port(self.proc.stop(&live.handle, 0), "stop")?;
                        Ok(StepEvidence::one(format!(
                            "compensate.stop {INSTANCE} exit code={} signaled={}",
                            exit.code, exit.signaled
                        )))
                    }
                    Some(live) => {
                        self.state.lock().map_err(|_| Self::poisoned())?.instance = Some(live);
                        Ok(StepEvidence::one(format!(
                            "compensate.stop {} (not this backend's instance; left alone)",
                            instance.0
                        )))
                    }
                    None => Ok(StepEvidence::one(format!(
                        "compensate.stop {} (nothing live)",
                        instance.0
                    ))),
                }
            }
            // Everything else either never ran on this backend (probe, call) or its truth
            // lives in the journal machinery — same benign arms the simulator keeps.
            other => Ok(StepEvidence::one(format!(
                "compensate.{} (nothing to undo on this backend)",
                step_name(other)
            ))),
        }
    }
}

/// One word per step kind, for compensation evidence. `EffectStep` has no kind method of its
/// own; the sim spells its arms out longhand and this backend keeps the same information in
/// one place.
fn step_name(step: &EffectStep) -> &'static str {
    match step {
        EffectStep::WriteObject { .. } => "write-object",
        EffectStep::MaterializeArtifact { .. } => "materialize-artifact",
        EffectStep::DbTxn { .. } => "db-txn",
        EffectStep::SpawnCore { .. } => "spawn-core",
        EffectStep::StopCore { .. } => "stop-core",
        EffectStep::CoreApiCall { .. } => "core-api-call",
        EffectStep::NetApply { .. } => "net-apply",
        EffectStep::NetRevert { .. } => "net-revert",
        EffectStep::Probe { .. } => "probe",
        EffectStep::MarkSnapshot { .. } => "mark-snapshot",
        EffectStep::CommitRevision { .. } => "commit-revision",
    }
}

/// The plan-level kind tag the identity evidence carries next to the core's own version
/// string (round 69): the pairing is the fact, so the kind is spelled out, not debug-printed.
fn core_kind_name(kind: CoreKind) -> &'static str {
    match kind {
        CoreKind::Mihomo => "mihomo",
        CoreKind::SingBox => "singbox",
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use caly_engine::CoreSpec;

    /// A plan that pins a binary this backend does not hold is refused **by name**, before
    /// any byte is written: the mismatch refusal is the supply-chain check, and this test
    /// is what makes removing it loud. (The matching-digest path is judged end to end by
    /// `tests/real_apply.rs`, which spawns the real core.)
    #[test]
    fn spawn_refuses_a_binary_the_plan_did_not_name() {
        let target_dir =
            std::env::var("CARGO_TARGET_TMPDIR").unwrap_or_else(|_| "target/tmp".to_owned());
        let root = format!("{target_dir}/effect-std-unit-{}", std::process::id());
        let _ = std::fs::remove_dir_all(&root);
        std::fs::create_dir_all(&root).expect("scratch");
        let runtime = StdEffectRuntime::new(
            &root,
            std::sync::Arc::new(caly_storage::InMemoryStorage::new()),
            CoreAssets::workspace_default(),
        );
        let failure = runtime
            .execute(
                caly_storage::ApplyPhase::Cutover,
                &EffectStep::SpawnCore {
                    spec: CoreSpec {
                        kind: CoreKind::Mihomo,
                        binary_digest: "sha256:not-the-pinned-asset".to_owned(),
                        config_digest: "mihomo:irrelevant".to_owned(),
                    },
                },
            )
            .expect_err("a mismatched binary digest must be refused");
        assert_eq!(failure.code, "binary-digest-mismatch");
        assert!(
            failure.summary.contains("sha256:not-the-pinned-asset")
                && failure.summary.contains("cf06ce2c"),
            "the refusal must name both digests: {}",
            failure.summary
        );
        // Refused before writing: the instance dir must not even exist.
        assert!(
            !std::path::Path::new(&root).join("runtime").exists(),
            "a refused spawn must leave no files behind"
        );
        let _ = std::fs::remove_dir_all(&root);
    }

    /// The second core pays the same toll (round 58, `ADR-046 §2`): a sing-box plan that
    /// pins a binary this backend does not hold is refused by name before any byte is
    /// written — the tar.gz is hashed exactly like mihomo's gzip, with the same refusal.
    #[test]
    fn singbox_spawn_refuses_a_binary_the_plan_did_not_name() {
        let target_dir =
            std::env::var("CARGO_TARGET_TMPDIR").unwrap_or_else(|_| "target/tmp".to_owned());
        let root = format!("{target_dir}/effect-std-unit-sb-{}", std::process::id());
        let _ = std::fs::remove_dir_all(&root);
        std::fs::create_dir_all(&root).expect("scratch");
        let runtime = StdEffectRuntime::new(
            &root,
            std::sync::Arc::new(caly_storage::InMemoryStorage::new()),
            CoreAssets::workspace_default(),
        );
        let failure = runtime
            .execute(
                caly_storage::ApplyPhase::Cutover,
                &EffectStep::SpawnCore {
                    spec: CoreSpec {
                        kind: CoreKind::SingBox,
                        binary_digest: "sha256:not-the-pinned-singbox".to_owned(),
                        config_digest: "singbox:irrelevant".to_owned(),
                    },
                },
            )
            .expect_err("a mismatched sing-box digest must be refused");
        assert_eq!(failure.code, "binary-digest-mismatch");
        assert!(
            failure.summary.contains("sha256:not-the-pinned-singbox")
                && failure.summary.contains("646bc01b"),
            "the refusal must name both digests: {}",
            failure.summary
        );
        assert!(
            !std::path::Path::new(&root).join("runtime").exists(),
            "a refused sing-box spawn must leave no files behind"
        );
        let _ = std::fs::remove_dir_all(&root);
    }
}
