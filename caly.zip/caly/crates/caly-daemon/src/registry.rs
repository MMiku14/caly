use std::collections::BTreeMap;

use caly_common::Actor;
use caly_ipc::{ClientFrame, ClientHello, FrameHeader, NegotiationPolicy, SessionCloseReason};

use crate::app::DaemonApp;
use crate::transport::{
    DaemonTransport, DaemonTransportConfig, TransportInspection, TransportStepOutput,
};

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct SessionRegistryConfig {
    pub negotiation: NegotiationPolicy,
    pub hello_timeout_ms: u64,
}

impl Default for SessionRegistryConfig {
    fn default() -> Self {
        Self {
            negotiation: NegotiationPolicy::default(),
            hello_timeout_ms: 5_000,
        }
    }
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct SessionRegistrySnapshot {
    pub session_count: usize,
    pub session_ids: Vec<String>,
}

pub struct SessionRegistry {
    config: SessionRegistryConfig,
    sessions: BTreeMap<String, DaemonTransport>,
}

impl SessionRegistry {
    pub fn new(config: SessionRegistryConfig) -> Self {
        Self {
            config,
            sessions: BTreeMap::new(),
        }
    }

    pub fn open_session(&mut self, actor: Actor, session_id: impl Into<String>) -> String {
        let session_id = session_id.into();
        let transport = DaemonTransport::new(
            self.config.negotiation.clone(),
            DaemonTransportConfig {
                actor,
                session_id: session_id.clone(),
                hello_timeout_ms: self.config.hello_timeout_ms,
            },
        );
        self.sessions.insert(session_id.clone(), transport);
        session_id
    }

    pub fn handle_hello(
        &mut self,
        app: &DaemonApp,
        session_id: &str,
        header: FrameHeader,
        hello: ClientHello,
    ) -> Result<TransportStepOutput, String> {
        let transport = self
            .sessions
            .get_mut(session_id)
            .ok_or_else(|| format!("unknown session id: {session_id}"))?;
        transport.on_hello(app, header, hello)
    }

    pub fn handle_frame(
        &mut self,
        app: &DaemonApp,
        session_id: &str,
        header: FrameHeader,
        frame: ClientFrame,
        is_control_message: bool,
    ) -> Result<TransportStepOutput, String> {
        let transport = self
            .sessions
            .get_mut(session_id)
            .ok_or_else(|| format!("unknown session id: {session_id}"))?;
        transport.on_client_frame(app, header, frame, is_control_message)
    }

    pub fn pull_stream(
        &mut self,
        app: &DaemonApp,
        session_id: &str,
        stream_id: caly_api::StreamId,
        from_seq_exclusive: Option<u64>,
    ) -> Result<TransportStepOutput, String> {
        let transport = self
            .sessions
            .get_mut(session_id)
            .ok_or_else(|| format!("unknown session id: {session_id}"))?;
        transport.pull_stream(app, stream_id, from_seq_exclusive)
    }

    pub fn force_hello_timeout(
        &mut self,
        app: &DaemonApp,
        session_id: &str,
    ) -> Result<TransportStepOutput, String> {
        let transport = self
            .sessions
            .get_mut(session_id)
            .ok_or_else(|| format!("unknown session id: {session_id}"))?;
        transport.on_hello_timeout(app)
    }

    pub fn close_session(
        &mut self,
        app: &DaemonApp,
        session_id: &str,
        reason: SessionCloseReason,
    ) -> Result<TransportStepOutput, String> {
        let mut transport = self
            .sessions
            .remove(session_id)
            .ok_or_else(|| format!("unknown session id: {session_id}"))?;
        transport.close(app, reason)
    }

    pub fn inspect_session(&self, session_id: &str) -> Result<TransportInspection, String> {
        let transport = self
            .sessions
            .get(session_id)
            .ok_or_else(|| format!("unknown session id: {session_id}"))?;
        Ok(transport.inspect())
    }

    pub fn snapshot(&self) -> SessionRegistrySnapshot {
        SessionRegistrySnapshot {
            session_count: self.sessions.len(),
            session_ids: self.sessions.keys().cloned().collect(),
        }
    }
}
