use std::sync::Arc;

use caly_api::{
    Accepted, ApiError, ApiResult, ApplyRequest, AutomationFacet, AutomationJobView, AutomationOp,
    BoxFuture, CalyFacade, CapabilityQuery, CapabilityReport, ConnectionId, ConnectionPage,
    ConnectionQuery, CoreFacet, CoreInspection, CoreInstallId, CoreInstallView, CoreOp, Ctx,
    DelayTestRequest, DiagnosticsFacet, DiagnosticsOp, DnsExplainRequest, DnsExplainResult,
    DnsFacet, DnsOp, DnsStatus, DoctorReport, DoctorRequest, ErrorCategory, ErrorCode,
    GcCollectRequest, GcPlanRequest, GcPlanView, GroupView, JobEventsRequest, JobEventsView,
    JobFollowRequest, JobFollowView, NetworkFacet, NetworkOp, NetworkPlanView, NetworkStatus,
    NodePage, NodeQuery, Operation, OperationResult, PatchAutomationJob, PipelineExplain,
    PipelineExplainRequest, ProfileFacet, ProfileId, ProfileOp, ProfileSummary, ProfileView,
    ProxyFacet, ProxyOp, RecoveryStatusView, RequestEnvelope, RequestId, Role, RollbackRequest,
    RouteExplainRequest, RouteExplainResult, RoutingFacet, RoutingOp, RoutingValidation, RulePage,
    RuleQuery, RuntimeFacet, RuntimeOp, RuntimeStatus, RuntimeSubscription, SelectNode, ServerInfo,
    SourceFacet, SourceId, SourceInspection, SourceOp, SourcePreview, SourcePreviewRequest,
    SourceSummary, SupportBundleReadRequest, SupportBundleView, SystemFacet, SystemOp,
    SystemStatus, WatchOpened,
};

use crate::app::DaemonApp;
use crate::handler::handle_request;

#[derive(Clone)]
pub struct LocalFacade {
    app: Arc<DaemonApp>,
}

impl LocalFacade {
    pub fn new(app: DaemonApp) -> Self {
        Self { app: Arc::new(app) }
    }

    pub fn app(&self) -> Arc<DaemonApp> {
        Arc::clone(&self.app)
    }
}

impl CalyFacade for LocalFacade {
    fn system(&self) -> Arc<dyn SystemFacet> {
        Arc::new(LocalSystemFacet { app: self.app() })
    }

    fn profile(&self) -> Arc<dyn ProfileFacet> {
        Arc::new(LocalProfileFacet { app: self.app() })
    }

    fn source(&self) -> Arc<dyn SourceFacet> {
        Arc::new(LocalSourceFacet { app: self.app() })
    }

    fn proxy(&self) -> Arc<dyn ProxyFacet> {
        Arc::new(LocalProxyFacet { app: self.app() })
    }

    fn routing(&self) -> Arc<dyn RoutingFacet> {
        Arc::new(LocalRoutingFacet { app: self.app() })
    }

    fn dns(&self) -> Arc<dyn DnsFacet> {
        Arc::new(LocalDnsFacet { app: self.app() })
    }

    fn network(&self) -> Arc<dyn NetworkFacet> {
        Arc::new(LocalNetworkFacet { app: self.app() })
    }

    fn core(&self) -> Arc<dyn CoreFacet> {
        Arc::new(LocalCoreFacet { app: self.app() })
    }

    fn runtime(&self) -> Arc<dyn RuntimeFacet> {
        Arc::new(LocalRuntimeFacet { app: self.app() })
    }

    fn diagnostics(&self) -> Arc<dyn DiagnosticsFacet> {
        Arc::new(LocalDiagnosticsFacet { app: self.app() })
    }

    fn automation(&self) -> Arc<dyn AutomationFacet> {
        Arc::new(LocalAutomationFacet { app: self.app() })
    }
}

/// Build the envelope a local call sends to the shared boundary.
///
/// Two fields used to be constants, and both were lies: `role` was `Role::Admin` for every local call
/// (so `required_role` could never fail — `docs/ONBOARDING_NOTES.md §4.41`), and `request_id` was
/// `RequestId(0)` for every local call. The second one is worse than cosmetic, because `Command.id` is
/// derived from it: every local command was `req-0`, so the event log and any audit of "which command
/// produced this" could not distinguish two of them (`§4.61`).
fn local_request(ctx: &Ctx, operation: Operation, role: Role, request_id: u64) -> RequestEnvelope {
    RequestEnvelope {
        protocol: caly_api::ProtocolVersion { major: 1, minor: 0 },
        request_id: RequestId(request_id),
        trace_id: ctx.trace_id.clone(),
        deadline_ms: ctx.deadline_ms,
        expected_revision: ctx.expected_revision,
        // `RFC-0002 §4.1` again: the local path forwards the caller's key exactly as `RemoteFacade`
        // does. Hardcoding `None` here while the remote path invented one of its own is what made
        // the two paths disagree about whether a repeated write runs again.
        idempotency_key: ctx.idempotency_key.clone(),
        role,
        operation,
        // Forwarded for the same reason the key is: if one path could express a budget and the other
        // could not, the daemon would answer the same caller differently depending on the transport.
        io_budget: Some(ctx.io_budget.clone()),
    }
}

fn dispatch(app: &DaemonApp, ctx: &Ctx, operation: Operation) -> ApiResult<OperationResult> {
    // The two reads that can fail here fail only on a poisoned lock. They are handled at the boundary
    // that already returns an `ApiError` — rather than by a second fallible helper, which would add a
    // `Result<_, ApiError>` signature (and a `result_large_err` location) for no extra honesty.
    let role = app
        .local_role()
        .map_err(|message| unavailable(ctx, message))?;
    let request_id = app
        .next_request_id()
        .map_err(|message| unavailable(ctx, message))?;
    let envelope = local_request(ctx, operation, role, request_id);
    handle_request(app, ctx.actor, &envelope).result
}

fn unavailable(ctx: &Ctx, summary: impl Into<String>) -> ApiError {
    ApiError::new(
        ErrorCode::Unavailable,
        ErrorCategory::Internal,
        false,
        summary,
        ctx.trace_id.clone(),
    )
}

#[derive(Clone)]
struct LocalSystemFacet {
    app: Arc<DaemonApp>,
}

impl SystemFacet for LocalSystemFacet {
    fn status<'a>(&'a self, ctx: Ctx) -> BoxFuture<'a, ApiResult<SystemStatus>> {
        let app = Arc::clone(&self.app);
        Box::pin(async move {
            match dispatch(&app, &ctx, Operation::System(SystemOp::Status))? {
                OperationResult::SystemStatus(value) => Ok(value),
                other => Err(unavailable(
                    &ctx,
                    format!("unexpected result for system.status: {:?}", other),
                )),
            }
        })
    }

    fn info<'a>(&'a self, ctx: Ctx) -> BoxFuture<'a, ApiResult<ServerInfo>> {
        let app = Arc::clone(&self.app);
        Box::pin(async move {
            match dispatch(&app, &ctx, Operation::System(SystemOp::Info))? {
                OperationResult::ServerInfo(value) => Ok(value),
                other => Err(unavailable(
                    &ctx,
                    format!("unexpected result for system.info: {:?}", other),
                )),
            }
        })
    }

    fn plan_gc<'a>(
        &'a self,
        ctx: Ctx,
        request: GcPlanRequest,
    ) -> BoxFuture<'a, ApiResult<GcPlanView>> {
        let app = Arc::clone(&self.app);
        Box::pin(async move {
            let operation = Operation::System(SystemOp::GcPlan { request });
            match dispatch(&app, &ctx, operation)? {
                OperationResult::GcPlan(value) => Ok(value),
                other => Err(unavailable(
                    &ctx,
                    format!("unexpected result for system.gc-plan: {:?}", other),
                )),
            }
        })
    }

    fn collect_garbage<'a>(
        &'a self,
        ctx: Ctx,
        request: GcCollectRequest,
    ) -> BoxFuture<'a, ApiResult<Accepted>> {
        let app = Arc::clone(&self.app);
        Box::pin(async move {
            let operation = Operation::System(SystemOp::CollectGarbage { request });
            match dispatch(&app, &ctx, operation)? {
                OperationResult::Accepted(value) => Ok(value),
                other => Err(unavailable(
                    &ctx,
                    format!("unexpected result for system.gc-collect: {:?}", other),
                )),
            }
        })
    }

    fn shutdown<'a>(&'a self, ctx: Ctx) -> BoxFuture<'a, ApiResult<Accepted>> {
        let app = Arc::clone(&self.app);
        Box::pin(async move {
            match dispatch(&app, &ctx, Operation::System(SystemOp::Shutdown))? {
                OperationResult::Accepted(value) => Ok(value),
                other => Err(unavailable(
                    &ctx,
                    format!("unexpected result for system.shutdown: {:?}", other),
                )),
            }
        })
    }
}

#[derive(Clone)]
struct LocalProfileFacet {
    app: Arc<DaemonApp>,
}

impl ProfileFacet for LocalProfileFacet {
    fn list<'a>(&'a self, ctx: Ctx) -> BoxFuture<'a, ApiResult<Vec<ProfileSummary>>> {
        let app = Arc::clone(&self.app);
        Box::pin(async move {
            match dispatch(&app, &ctx, Operation::Profile(ProfileOp::List))? {
                OperationResult::ProfileList(value) => Ok(value),
                other => Err(unavailable(
                    &ctx,
                    format!("unexpected result for profile.list: {:?}", other),
                )),
            }
        })
    }

    fn get<'a>(&'a self, ctx: Ctx, profile_id: ProfileId) -> BoxFuture<'a, ApiResult<ProfileView>> {
        let app = Arc::clone(&self.app);
        Box::pin(async move {
            match dispatch(
                &app,
                &ctx,
                Operation::Profile(ProfileOp::Get { profile_id }),
            )? {
                OperationResult::ProfileView(value) => Ok(value),
                other => Err(unavailable(
                    &ctx,
                    format!("unexpected result for profile.get: {:?}", other),
                )),
            }
        })
    }

    fn plan<'a>(
        &'a self,
        ctx: Ctx,
        request: ApplyRequest,
    ) -> BoxFuture<'a, ApiResult<caly_api::DeploymentPlanView>> {
        let app = Arc::clone(&self.app);
        Box::pin(async move {
            match dispatch(&app, &ctx, Operation::Profile(ProfileOp::Plan { request }))? {
                OperationResult::DeploymentPlan(value) => Ok(value),
                other => Err(unavailable(
                    &ctx,
                    format!("unexpected result for profile.plan: {:?}", other),
                )),
            }
        })
    }

    fn apply<'a>(&'a self, ctx: Ctx, request: ApplyRequest) -> BoxFuture<'a, ApiResult<Accepted>> {
        let app = Arc::clone(&self.app);
        Box::pin(async move {
            match dispatch(&app, &ctx, Operation::Profile(ProfileOp::Apply { request }))? {
                OperationResult::Accepted(value) => Ok(value),
                other => Err(unavailable(
                    &ctx,
                    format!("unexpected result for profile.apply: {:?}", other),
                )),
            }
        })
    }

    fn rollback<'a>(
        &'a self,
        ctx: Ctx,
        request: RollbackRequest,
    ) -> BoxFuture<'a, ApiResult<Accepted>> {
        let app = Arc::clone(&self.app);
        Box::pin(async move {
            match dispatch(
                &app,
                &ctx,
                Operation::Profile(ProfileOp::Rollback { request }),
            )? {
                OperationResult::Accepted(value) => Ok(value),
                other => Err(unavailable(
                    &ctx,
                    format!("unexpected result for profile.rollback: {:?}", other),
                )),
            }
        })
    }
}

#[derive(Clone)]
struct LocalSourceFacet {
    app: Arc<DaemonApp>,
}

impl SourceFacet for LocalSourceFacet {
    fn list<'a>(&'a self, ctx: Ctx) -> BoxFuture<'a, ApiResult<Vec<SourceSummary>>> {
        let app = Arc::clone(&self.app);
        Box::pin(async move {
            match dispatch(&app, &ctx, Operation::Source(SourceOp::List))? {
                OperationResult::SourceList(value) => Ok(value),
                other => Err(unavailable(
                    &ctx,
                    format!("unexpected result for source.list: {:?}", other),
                )),
            }
        })
    }

    fn inspect<'a>(
        &'a self,
        ctx: Ctx,
        source_id: SourceId,
    ) -> BoxFuture<'a, ApiResult<SourceInspection>> {
        let app = Arc::clone(&self.app);
        Box::pin(async move {
            match dispatch(
                &app,
                &ctx,
                Operation::Source(SourceOp::Inspect { source_id }),
            )? {
                OperationResult::SourceInspection(value) => Ok(value),
                other => Err(unavailable(
                    &ctx,
                    format!("unexpected result for source.inspect: {:?}", other),
                )),
            }
        })
    }

    fn update<'a>(&'a self, ctx: Ctx, source_id: SourceId) -> BoxFuture<'a, ApiResult<Accepted>> {
        let app = Arc::clone(&self.app);
        Box::pin(async move {
            match dispatch(
                &app,
                &ctx,
                Operation::Source(SourceOp::Update { source_id }),
            )? {
                OperationResult::Accepted(value) => Ok(value),
                other => Err(unavailable(
                    &ctx,
                    format!("unexpected result for source.update: {:?}", other),
                )),
            }
        })
    }

    fn preview<'a>(
        &'a self,
        ctx: Ctx,
        request: SourcePreviewRequest,
    ) -> BoxFuture<'a, ApiResult<SourcePreview>> {
        let app = Arc::clone(&self.app);
        Box::pin(async move {
            match dispatch(&app, &ctx, Operation::Source(SourceOp::Preview { request }))? {
                OperationResult::SourcePreview(value) => Ok(value),
                other => Err(unavailable(
                    &ctx,
                    format!("unexpected result for source.preview: {:?}", other),
                )),
            }
        })
    }
}

#[derive(Clone)]
struct LocalProxyFacet {
    app: Arc<DaemonApp>,
}

impl ProxyFacet for LocalProxyFacet {
    fn nodes<'a>(&'a self, ctx: Ctx, query: NodeQuery) -> BoxFuture<'a, ApiResult<NodePage>> {
        let app = Arc::clone(&self.app);
        Box::pin(async move {
            match dispatch(&app, &ctx, Operation::Proxy(ProxyOp::Nodes { query }))? {
                OperationResult::NodePage(value) => Ok(value),
                other => Err(unavailable(
                    &ctx,
                    format!("unexpected result for proxy.nodes: {:?}", other),
                )),
            }
        })
    }

    fn groups<'a>(&'a self, ctx: Ctx) -> BoxFuture<'a, ApiResult<Vec<GroupView>>> {
        let app = Arc::clone(&self.app);
        Box::pin(async move {
            match dispatch(&app, &ctx, Operation::Proxy(ProxyOp::Groups))? {
                OperationResult::GroupList(value) => Ok(value),
                other => Err(unavailable(
                    &ctx,
                    format!("unexpected result for proxy.groups: {:?}", other),
                )),
            }
        })
    }

    fn select<'a>(&'a self, ctx: Ctx, request: SelectNode) -> BoxFuture<'a, ApiResult<Accepted>> {
        let app = Arc::clone(&self.app);
        Box::pin(async move {
            match dispatch(&app, &ctx, Operation::Proxy(ProxyOp::Select { request }))? {
                OperationResult::Accepted(value) => Ok(value),
                other => Err(unavailable(
                    &ctx,
                    format!("unexpected result for proxy.select: {:?}", other),
                )),
            }
        })
    }

    fn test_delay<'a>(
        &'a self,
        ctx: Ctx,
        request: DelayTestRequest,
    ) -> BoxFuture<'a, ApiResult<Accepted>> {
        let app = Arc::clone(&self.app);
        Box::pin(async move {
            match dispatch(&app, &ctx, Operation::Proxy(ProxyOp::TestDelay { request }))? {
                OperationResult::Accepted(value) => Ok(value),
                other => Err(unavailable(
                    &ctx,
                    format!("unexpected result for proxy.test_delay: {:?}", other),
                )),
            }
        })
    }
}

#[derive(Clone)]
struct LocalRoutingFacet {
    app: Arc<DaemonApp>,
}

impl RoutingFacet for LocalRoutingFacet {
    fn rules<'a>(&'a self, ctx: Ctx, query: RuleQuery) -> BoxFuture<'a, ApiResult<RulePage>> {
        let app = Arc::clone(&self.app);
        Box::pin(async move {
            match dispatch(&app, &ctx, Operation::Routing(RoutingOp::Rules { query }))? {
                OperationResult::RulePage(value) => Ok(value),
                other => Err(unavailable(
                    &ctx,
                    format!("unexpected result for routing.rules: {:?}", other),
                )),
            }
        })
    }

    fn explain<'a>(
        &'a self,
        ctx: Ctx,
        request: RouteExplainRequest,
    ) -> BoxFuture<'a, ApiResult<RouteExplainResult>> {
        let app = Arc::clone(&self.app);
        Box::pin(async move {
            match dispatch(
                &app,
                &ctx,
                Operation::Routing(RoutingOp::Explain { request }),
            )? {
                OperationResult::RouteExplain(value) => Ok(value),
                other => Err(unavailable(
                    &ctx,
                    format!("unexpected result for routing.explain: {:?}", other),
                )),
            }
        })
    }

    fn validate<'a>(
        &'a self,
        ctx: Ctx,
        profile_id: ProfileId,
    ) -> BoxFuture<'a, ApiResult<RoutingValidation>> {
        let app = Arc::clone(&self.app);
        Box::pin(async move {
            match dispatch(
                &app,
                &ctx,
                Operation::Routing(RoutingOp::Validate { profile_id }),
            )? {
                OperationResult::RoutingValidation(value) => Ok(value),
                other => Err(unavailable(
                    &ctx,
                    format!("unexpected result for routing.validate: {:?}", other),
                )),
            }
        })
    }
}

#[derive(Clone)]
struct LocalDnsFacet {
    app: Arc<DaemonApp>,
}

impl DnsFacet for LocalDnsFacet {
    fn status<'a>(&'a self, ctx: Ctx) -> BoxFuture<'a, ApiResult<DnsStatus>> {
        let app = Arc::clone(&self.app);
        Box::pin(async move {
            match dispatch(&app, &ctx, Operation::Dns(DnsOp::Status))? {
                OperationResult::DnsStatus(value) => Ok(value),
                other => Err(unavailable(
                    &ctx,
                    format!("unexpected result for dns.status: {:?}", other),
                )),
            }
        })
    }

    fn explain<'a>(
        &'a self,
        ctx: Ctx,
        request: DnsExplainRequest,
    ) -> BoxFuture<'a, ApiResult<DnsExplainResult>> {
        let app = Arc::clone(&self.app);
        Box::pin(async move {
            match dispatch(&app, &ctx, Operation::Dns(DnsOp::Explain { request }))? {
                OperationResult::DnsExplain(value) => Ok(value),
                other => Err(unavailable(
                    &ctx,
                    format!("unexpected result for dns.explain: {:?}", other),
                )),
            }
        })
    }

    fn flush_cache<'a>(&'a self, ctx: Ctx) -> BoxFuture<'a, ApiResult<Accepted>> {
        let app = Arc::clone(&self.app);
        Box::pin(async move {
            match dispatch(&app, &ctx, Operation::Dns(DnsOp::FlushCache))? {
                OperationResult::Accepted(value) => Ok(value),
                other => Err(unavailable(
                    &ctx,
                    format!("unexpected result for dns.flush_cache: {:?}", other),
                )),
            }
        })
    }
}

#[derive(Clone)]
struct LocalNetworkFacet {
    app: Arc<DaemonApp>,
}

impl NetworkFacet for LocalNetworkFacet {
    fn status<'a>(&'a self, ctx: Ctx) -> BoxFuture<'a, ApiResult<NetworkStatus>> {
        let app = Arc::clone(&self.app);
        Box::pin(async move {
            match dispatch(&app, &ctx, Operation::Network(NetworkOp::Status))? {
                OperationResult::NetworkStatus(value) => Ok(value),
                other => Err(unavailable(
                    &ctx,
                    format!("unexpected result for network.status: {:?}", other),
                )),
            }
        })
    }

    fn inspect_plan<'a>(
        &'a self,
        ctx: Ctx,
        profile_id: ProfileId,
    ) -> BoxFuture<'a, ApiResult<NetworkPlanView>> {
        let app = Arc::clone(&self.app);
        Box::pin(async move {
            match dispatch(
                &app,
                &ctx,
                Operation::Network(NetworkOp::InspectPlan { profile_id }),
            )? {
                OperationResult::NetworkPlan(value) => Ok(value),
                other => Err(unavailable(
                    &ctx,
                    format!("unexpected result for network.inspect_plan: {:?}", other),
                )),
            }
        })
    }

    fn repair<'a>(&'a self, ctx: Ctx) -> BoxFuture<'a, ApiResult<Accepted>> {
        let app = Arc::clone(&self.app);
        Box::pin(async move {
            match dispatch(&app, &ctx, Operation::Network(NetworkOp::Repair))? {
                OperationResult::Accepted(value) => Ok(value),
                other => Err(unavailable(
                    &ctx,
                    format!("unexpected result for network.repair: {:?}", other),
                )),
            }
        })
    }
}

#[derive(Clone)]
struct LocalCoreFacet {
    app: Arc<DaemonApp>,
}

impl CoreFacet for LocalCoreFacet {
    fn list_installs<'a>(&'a self, ctx: Ctx) -> BoxFuture<'a, ApiResult<Vec<CoreInstallView>>> {
        let app = Arc::clone(&self.app);
        Box::pin(async move {
            match dispatch(&app, &ctx, Operation::Core(CoreOp::ListInstalls))? {
                OperationResult::CoreInstallList(value) => Ok(value),
                other => Err(unavailable(
                    &ctx,
                    format!("unexpected result for core.list_installs: {:?}", other),
                )),
            }
        })
    }

    fn inspect<'a>(
        &'a self,
        ctx: Ctx,
        core_install_id: CoreInstallId,
    ) -> BoxFuture<'a, ApiResult<CoreInspection>> {
        let app = Arc::clone(&self.app);
        Box::pin(async move {
            match dispatch(
                &app,
                &ctx,
                Operation::Core(CoreOp::Inspect { core_install_id }),
            )? {
                OperationResult::CoreInspection(value) => Ok(value),
                other => Err(unavailable(
                    &ctx,
                    format!("unexpected result for core.inspect: {:?}", other),
                )),
            }
        })
    }

    fn capabilities<'a>(
        &'a self,
        ctx: Ctx,
        query: CapabilityQuery,
    ) -> BoxFuture<'a, ApiResult<CapabilityReport>> {
        let app = Arc::clone(&self.app);
        Box::pin(async move {
            match dispatch(&app, &ctx, Operation::Core(CoreOp::Capabilities { query }))? {
                OperationResult::CapabilityReport(value) => Ok(value),
                other => Err(unavailable(
                    &ctx,
                    format!("unexpected result for core.capabilities: {:?}", other),
                )),
            }
        })
    }
}

#[derive(Clone)]
struct LocalRuntimeFacet {
    app: Arc<DaemonApp>,
}

impl RuntimeFacet for LocalRuntimeFacet {
    fn status<'a>(&'a self, ctx: Ctx) -> BoxFuture<'a, ApiResult<RuntimeStatus>> {
        let app = Arc::clone(&self.app);
        Box::pin(async move {
            match dispatch(&app, &ctx, Operation::Runtime(RuntimeOp::Status))? {
                OperationResult::RuntimeStatus(value) => Ok(value),
                other => Err(unavailable(
                    &ctx,
                    format!("unexpected result for runtime.status: {:?}", other),
                )),
            }
        })
    }

    fn connections<'a>(
        &'a self,
        ctx: Ctx,
        query: ConnectionQuery,
    ) -> BoxFuture<'a, ApiResult<ConnectionPage>> {
        let app = Arc::clone(&self.app);
        Box::pin(async move {
            match dispatch(
                &app,
                &ctx,
                Operation::Runtime(RuntimeOp::Connections { query }),
            )? {
                OperationResult::ConnectionPage(value) => Ok(value),
                other => Err(unavailable(
                    &ctx,
                    format!("unexpected result for runtime.connections: {:?}", other),
                )),
            }
        })
    }

    fn close_connection<'a>(
        &'a self,
        ctx: Ctx,
        connection_id: ConnectionId,
    ) -> BoxFuture<'a, ApiResult<Accepted>> {
        let app = Arc::clone(&self.app);
        Box::pin(async move {
            match dispatch(
                &app,
                &ctx,
                Operation::Runtime(RuntimeOp::CloseConnection { connection_id }),
            )? {
                OperationResult::Accepted(value) => Ok(value),
                other => Err(unavailable(
                    &ctx,
                    format!(
                        "unexpected result for runtime.close_connection: {:?}",
                        other
                    ),
                )),
            }
        })
    }

    fn watch<'a>(
        &'a self,
        ctx: Ctx,
        subscription: RuntimeSubscription,
    ) -> BoxFuture<'a, ApiResult<WatchOpened>> {
        let app = Arc::clone(&self.app);
        Box::pin(async move {
            match dispatch(
                &app,
                &ctx,
                Operation::Runtime(RuntimeOp::Watch { subscription }),
            )? {
                OperationResult::WatchOpened(value) => Ok(value),
                other => Err(unavailable(
                    &ctx,
                    format!("unexpected result for runtime.watch: {:?}", other),
                )),
            }
        })
    }
}

#[derive(Clone)]
struct LocalDiagnosticsFacet {
    app: Arc<DaemonApp>,
}

impl DiagnosticsFacet for LocalDiagnosticsFacet {
    fn doctor<'a>(
        &'a self,
        ctx: Ctx,
        request: DoctorRequest,
    ) -> BoxFuture<'a, ApiResult<DoctorReport>> {
        let app = Arc::clone(&self.app);
        Box::pin(async move {
            match dispatch(
                &app,
                &ctx,
                Operation::Diagnostics(DiagnosticsOp::Doctor { request }),
            )? {
                OperationResult::DoctorReport(value) => Ok(value),
                other => Err(unavailable(
                    &ctx,
                    format!("unexpected result for diagnostics.doctor: {:?}", other),
                )),
            }
        })
    }

    fn explain_pipeline<'a>(
        &'a self,
        ctx: Ctx,
        request: PipelineExplainRequest,
    ) -> BoxFuture<'a, ApiResult<PipelineExplain>> {
        let app = Arc::clone(&self.app);
        Box::pin(async move {
            match dispatch(
                &app,
                &ctx,
                Operation::Diagnostics(DiagnosticsOp::ExplainPipeline { request }),
            )? {
                OperationResult::PipelineExplain(value) => Ok(value),
                other => Err(unavailable(
                    &ctx,
                    format!(
                        "unexpected result for diagnostics.explain_pipeline: {:?}",
                        other
                    ),
                )),
            }
        })
    }

    fn recovery_status<'a>(&'a self, ctx: Ctx) -> BoxFuture<'a, ApiResult<RecoveryStatusView>> {
        let app = Arc::clone(&self.app);
        Box::pin(async move {
            match dispatch(
                &app,
                &ctx,
                Operation::Diagnostics(DiagnosticsOp::RecoveryStatus),
            )? {
                OperationResult::RecoveryStatus(value) => Ok(value),
                other => Err(unavailable(
                    &ctx,
                    format!(
                        "unexpected result for diagnostics.recovery_status: {:?}",
                        other
                    ),
                )),
            }
        })
    }

    fn follow_job<'a>(
        &'a self,
        ctx: Ctx,
        request: JobFollowRequest,
    ) -> BoxFuture<'a, ApiResult<JobFollowView>> {
        let app = Arc::clone(&self.app);
        Box::pin(async move {
            match dispatch(
                &app,
                &ctx,
                Operation::Diagnostics(DiagnosticsOp::FollowJob { request }),
            )? {
                OperationResult::JobFollow(value) => Ok(value),
                other => Err(unavailable(
                    &ctx,
                    format!("unexpected result for diagnostics.follow_job: {:?}", other),
                )),
            }
        })
    }

    fn follow_job_stream<'a>(
        &'a self,
        ctx: Ctx,
        request: JobFollowRequest,
    ) -> BoxFuture<'a, ApiResult<WatchOpened>> {
        let app = Arc::clone(&self.app);
        Box::pin(async move {
            match dispatch(
                &app,
                &ctx,
                Operation::Diagnostics(DiagnosticsOp::FollowJobStream { request }),
            )? {
                OperationResult::WatchOpened(value) => Ok(value),
                other => Err(unavailable(
                    &ctx,
                    format!(
                        "unexpected result for diagnostics.follow_job_stream: {:?}",
                        other
                    ),
                )),
            }
        })
    }

    fn read_job_events<'a>(
        &'a self,
        ctx: Ctx,
        request: JobEventsRequest,
    ) -> BoxFuture<'a, ApiResult<JobEventsView>> {
        let app = Arc::clone(&self.app);
        Box::pin(async move {
            match dispatch(
                &app,
                &ctx,
                Operation::Diagnostics(DiagnosticsOp::ReadJobEvents { request }),
            )? {
                OperationResult::JobEvents(value) => Ok(value),
                other => Err(unavailable(
                    &ctx,
                    format!(
                        "unexpected result for diagnostics.read_job_events: {:?}",
                        other
                    ),
                )),
            }
        })
    }

    fn read_support_bundle<'a>(
        &'a self,
        ctx: Ctx,
        request: SupportBundleReadRequest,
    ) -> BoxFuture<'a, ApiResult<SupportBundleView>> {
        let app = Arc::clone(&self.app);
        Box::pin(async move {
            match dispatch(
                &app,
                &ctx,
                Operation::Diagnostics(DiagnosticsOp::ReadSupportBundle { request }),
            )? {
                OperationResult::SupportBundle(value) => Ok(value),
                other => Err(unavailable(
                    &ctx,
                    format!(
                        "unexpected result for diagnostics.read_support_bundle: {:?}",
                        other
                    ),
                )),
            }
        })
    }

    fn support_bundle<'a>(&'a self, ctx: Ctx) -> BoxFuture<'a, ApiResult<Accepted>> {
        let app = Arc::clone(&self.app);
        Box::pin(async move {
            match dispatch(
                &app,
                &ctx,
                Operation::Diagnostics(DiagnosticsOp::SupportBundle),
            )? {
                OperationResult::Accepted(value) => Ok(value),
                other => Err(unavailable(
                    &ctx,
                    format!(
                        "unexpected result for diagnostics.support_bundle: {:?}",
                        other
                    ),
                )),
            }
        })
    }
}

#[derive(Clone)]
struct LocalAutomationFacet {
    app: Arc<DaemonApp>,
}

impl AutomationFacet for LocalAutomationFacet {
    fn list_jobs<'a>(&'a self, ctx: Ctx) -> BoxFuture<'a, ApiResult<Vec<AutomationJobView>>> {
        let app = Arc::clone(&self.app);
        Box::pin(async move {
            match dispatch(&app, &ctx, Operation::Automation(AutomationOp::ListJobs))? {
                OperationResult::AutomationJobs(value) => Ok(value),
                other => Err(unavailable(
                    &ctx,
                    format!("unexpected result for automation.list_jobs: {:?}", other),
                )),
            }
        })
    }

    fn patch_job<'a>(
        &'a self,
        ctx: Ctx,
        request: PatchAutomationJob,
    ) -> BoxFuture<'a, ApiResult<Accepted>> {
        let app = Arc::clone(&self.app);
        Box::pin(async move {
            match dispatch(
                &app,
                &ctx,
                Operation::Automation(AutomationOp::PatchJob { request }),
            )? {
                OperationResult::Accepted(value) => Ok(value),
                other => Err(unavailable(
                    &ctx,
                    format!("unexpected result for automation.patch_job: {:?}", other),
                )),
            }
        })
    }
}

#[cfg(test)]
mod budget_forwarding_tests {
    use super::*;
    use caly_api::{IoBudget, Operation, SystemOp};

    /// Parity of *expressibility*: whatever the session path can put on an envelope, the local path has
    /// to be able to put on the same envelope. If only one façade could state a budget, `ADR-017`'s
    /// "one façade, shared DTOs" would be true of the types and false of the behaviour.
    #[test]
    fn the_local_path_forwards_the_callers_budget() {
        let budget = IoBudget {
            max_bytes: Some(1024),
            max_requests: Some(1),
        };
        let mut ctx = caly_api::default_ctx("budget-local", caly_common::Actor::Cli);
        ctx.io_budget = budget.clone();
        let envelope = local_request(&ctx, Operation::System(SystemOp::Status), Role::Admin, 3);
        assert_eq!(
            envelope.io_budget,
            Some(budget),
            "forwarded, not replaced with the daemon's own default"
        );
    }

    #[test]
    fn an_ordinary_local_call_states_the_bounded_default_rather_than_silence() {
        let ctx = caly_api::default_ctx("budget-absent", caly_common::Actor::Cli);
        let envelope = local_request(&ctx, Operation::System(SystemOp::Status), Role::Admin, 4);
        assert_eq!(
            envelope.io_budget,
            Some(caly_api::IoBudget::default_command()),
            "the local façade always knows the caller's `Ctx`, so it reports the effective budget\
             instead of leaving the daemon to invent one -- `None` would be a second, different answer\
             for the same request over the other transport"
        );
        assert!(
            !envelope.io_budget.expect("stated").is_unlimited(),
            "and what it states is no longer `unlimited`"
        );
    }
}
