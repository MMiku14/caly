use caly_api::ProtocolVersion;
use caly_engine::{EngineLifecycle, EngineState};

use crate::state::{DaemonLifecycle, DaemonRuntimeState};

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct DaemonBootstrapConfig {
    pub instance_id: String,
    pub protocol_version: ProtocolVersion,
    pub recover_on_start: bool,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct DaemonBootstrapResult {
    pub runtime: DaemonRuntimeState,
    pub engine: EngineState,
}

pub fn bootstrap(config: DaemonBootstrapConfig) -> DaemonBootstrapResult {
    let mut runtime = DaemonRuntimeState::new(config.instance_id, config.protocol_version);
    runtime.lifecycle = if config.recover_on_start {
        DaemonLifecycle::Recovering
    } else {
        DaemonLifecycle::Starting
    };

    let mut engine = EngineState::new();
    // The support bundle has to say which process it came from. The engine cannot know that, so the
    // composition root hands it over here rather than the export guessing (`RFC-0010 §12.2`).
    engine.bundle_identity = caly_engine::BundleIdentity::new(
        runtime.instance_id.clone(),
        crate::state::DAEMON_NAME,
        crate::state::DAEMON_VERSION,
        format!(
            "v{}.{}",
            runtime.protocol_version.major, runtime.protocol_version.minor
        ),
    );
    engine.set_lifecycle(if config.recover_on_start {
        EngineLifecycle::Recovering
    } else {
        EngineLifecycle::Idle
    });

    DaemonBootstrapResult { runtime, engine }
}
