use caly_api::{
    Accepted, ApplyRequest, AutomationJobView, ConnectionId, ConnectionPage, ConnectionQuery,
    CoreInspection, CoreInstallView, DiagnosticsOp, DoctorReport, JobFollowRequest, JobFollowView,
    Operation, OperationResult, PatchAutomationJob, ProfileSummary, ProfileView,
    RecoveryStatusView, RuntimeOp, RuntimeStatus, RuntimeSubscription, WatchOpened,
};
use caly_common::Actor;
use caly_ipc::{
    encode_raw_json, make_header, ClientSession, ClientSessionConfig, ClientSessionState,
    Compression, Encoding, NegotiationPolicy, ServerFrame, StreamFrame, StreamKind,
};

use crate::app::DaemonApp;
use crate::bootstrap::DaemonBootstrapConfig;
use crate::transport::{
    DaemonTransport, DaemonTransportConfig, TransportInspection, TransportStepOutput,
};

/// A daemon refusal, as a scenario sees it.
///
/// The harness used to hand back `error.summary` alone. Every scenario that wanted to check *which*
/// refusal arrived therefore either asserted on prose (which the daemon is free to reword) or could not
/// check at all — and a scenario suite that cannot see `ErrorCode` cannot demonstrate the
/// `RFC-0002 §4.1` requirement it exists to test. The code is prefixed rather than replacing the
/// summary so the ~20 existing `contains(...)` assertions keep working and a failing scenario still
/// quotes what the daemon said.
fn describe_refusal(error: caly_api::ApiError) -> String {
    format!("{}: {}", error.code.as_str(), error.summary)
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct LoopbackHarnessConfig {
    pub client: ClientSessionConfig,
    pub transport: DaemonTransportConfig,
    pub daemon: DaemonBootstrapConfig,
    pub negotiation: NegotiationPolicy,
}

impl Default for LoopbackHarnessConfig {
    fn default() -> Self {
        Self {
            client: ClientSessionConfig::default(),
            transport: DaemonTransportConfig {
                actor: Actor::Cli,
                session_id: "loopback-session".to_owned(),
                hello_timeout_ms: 5_000,
            },
            daemon: DaemonBootstrapConfig {
                instance_id: "loopback-daemon".to_owned(),
                protocol_version: caly_api::ProtocolVersion { major: 1, minor: 0 },
                recover_on_start: false,
            },
            negotiation: NegotiationPolicy::default(),
        }
    }
}

pub struct LoopbackHarness {
    pub app: DaemonApp,
    pub transport: DaemonTransport,
    pub client: ClientSession,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct HarnessSnapshot {
    pub client_state: ClientSessionState,
    pub daemon_state: String,
    pub open_stream_count: usize,
}

impl LoopbackHarness {
    pub fn new(config: LoopbackHarnessConfig) -> Self {
        let app = DaemonApp::bootstrap(config.daemon);
        let transport = DaemonTransport::new(config.negotiation, config.transport);
        let client = ClientSession::new(config.client);
        Self {
            app,
            transport,
            client,
        }
    }

    pub fn handshake(&mut self) -> Result<(), String> {
        let hello = self.client.build_hello();
        let header = make_header(0, Encoding::Json, Compression::None);
        match self.transport.on_hello(&self.app, header, hello)? {
            TransportStepOutput::HelloAck(ack) => {
                self.client.apply_hello_ack(&ack).map_err(|e| e.summary)
            }
            other => Err(format!(
                "unexpected transport output during handshake: {:?}",
                other
            )),
        }
    }

    pub fn send_operation(
        &mut self,
        trace: impl Into<String>,
        operation: Operation,
        idempotency_key: Option<String>,
    ) -> Result<OperationResult, String> {
        let frame = self
            .client
            .make_request(
                trace,
                operation,
                Some(30_000),
                None,
                idempotency_key,
                // The harness drives the daemon directly; the budget it does not pass is deliberately
                // the daemon's default rather than a value invented here.
                None,
            )
            .map_err(|e| e.summary)?;
        let header = make_header(0, Encoding::Json, Compression::None);
        let output = self
            .transport
            .on_client_frame(&self.app, header, frame, true)?;
        match output {
            TransportStepOutput::ResponseFrames(frames) => self.consume_response_frames(frames),
            other => Err(format!(
                "unexpected transport output for request: {:?}",
                other
            )),
        }
    }

    pub fn submit_apply(
        &mut self,
        request: ApplyRequest,
        idempotency_key: Option<String>,
    ) -> Result<Accepted, String> {
        let result = self.send_operation(
            "loopback-profile-apply",
            Operation::Profile(caly_api::ProfileOp::Apply { request }),
            idempotency_key,
        )?;
        match result {
            OperationResult::Accepted(value) => Ok(value),
            other => Err(format!("unexpected apply result: {:?}", other)),
        }
    }

    pub fn process_next_job(&self) -> Result<bool, String> {
        self.app.process_next_job()
    }

    pub fn seed_recovery_fixture(&self, profile_id: impl Into<String>) -> Result<usize, String> {
        let report = self.app.seed_recovery_fixture(profile_id.into())?;
        Ok(report.decisions.len())
    }

    pub fn profile_list(&mut self) -> Result<Vec<ProfileSummary>, String> {
        let result = self.send_operation(
            "loopback-profile-list",
            Operation::Profile(caly_api::ProfileOp::List),
            None,
        )?;
        match result {
            OperationResult::ProfileList(value) => Ok(value),
            other => Err(format!("unexpected profile list result: {:?}", other)),
        }
    }

    pub fn profile_get(&mut self, profile_id: caly_api::ProfileId) -> Result<ProfileView, String> {
        let result = self.send_operation(
            "loopback-profile-get",
            Operation::Profile(caly_api::ProfileOp::Get { profile_id }),
            None,
        )?;
        match result {
            OperationResult::ProfileView(value) => Ok(value),
            other => Err(format!("unexpected profile get result: {:?}", other)),
        }
    }

    pub fn core_list_installs(&mut self) -> Result<Vec<CoreInstallView>, String> {
        let result = self.send_operation(
            "loopback-core-list-installs",
            Operation::Core(caly_api::CoreOp::ListInstalls),
            None,
        )?;
        match result {
            OperationResult::CoreInstallList(value) => Ok(value),
            other => Err(format!("unexpected core install list result: {:?}", other)),
        }
    }

    pub fn core_inspect(
        &mut self,
        core_install_id: caly_api::CoreInstallId,
    ) -> Result<CoreInspection, String> {
        let result = self.send_operation(
            "loopback-core-inspect",
            Operation::Core(caly_api::CoreOp::Inspect { core_install_id }),
            None,
        )?;
        match result {
            OperationResult::CoreInspection(value) => Ok(value),
            other => Err(format!("unexpected core inspect result: {:?}", other)),
        }
    }

    pub fn runtime_status(&mut self) -> Result<RuntimeStatus, String> {
        let result = self.send_operation(
            "loopback-runtime-status",
            Operation::Runtime(RuntimeOp::Status),
            None,
        )?;
        match result {
            OperationResult::RuntimeStatus(value) => Ok(value),
            other => Err(format!("unexpected runtime status result: {:?}", other)),
        }
    }

    pub fn runtime_connections(
        &mut self,
        query: ConnectionQuery,
    ) -> Result<ConnectionPage, String> {
        let result = self.send_operation(
            "loopback-runtime-connections",
            Operation::Runtime(RuntimeOp::Connections { query }),
            None,
        )?;
        match result {
            OperationResult::ConnectionPage(value) => Ok(value),
            other => Err(format!(
                "unexpected runtime connections result: {:?}",
                other
            )),
        }
    }

    pub fn close_connection(&mut self, connection_id: ConnectionId) -> Result<Accepted, String> {
        let result = self.send_operation(
            "loopback-runtime-close-connection",
            Operation::Runtime(RuntimeOp::CloseConnection { connection_id }),
            None,
        )?;
        match result {
            OperationResult::Accepted(value) => Ok(value),
            other => Err(format!(
                "unexpected runtime close-connection result: {:?}",
                other
            )),
        }
    }

    pub fn recovery_status(&mut self) -> Result<RecoveryStatusView, String> {
        let result = self.send_operation(
            "loopback-recovery-status",
            Operation::Diagnostics(DiagnosticsOp::RecoveryStatus),
            None,
        )?;
        match result {
            OperationResult::RecoveryStatus(value) => Ok(value),
            other => Err(format!("unexpected recovery status result: {:?}", other)),
        }
    }

    pub fn doctor(&mut self, include_runtime: bool) -> Result<DoctorReport, String> {
        let result = self.send_operation(
            "loopback-doctor",
            Operation::Diagnostics(DiagnosticsOp::Doctor {
                request: caly_api::DoctorRequest { include_runtime },
            }),
            None,
        )?;
        match result {
            OperationResult::DoctorReport(value) => Ok(value),
            other => Err(format!("unexpected doctor result: {:?}", other)),
        }
    }

    pub fn support_bundle(&mut self) -> Result<Accepted, String> {
        let result = self.send_operation(
            "loopback-support-bundle",
            Operation::Diagnostics(DiagnosticsOp::SupportBundle),
            None,
        )?;
        match result {
            OperationResult::Accepted(value) => Ok(value),
            other => Err(format!("unexpected support bundle result: {:?}", other)),
        }
    }

    /// Read back the newest bundle this daemon's store holds.
    ///
    /// The harness goes through the same framed request a remote client makes, so a scenario that
    /// passes here has exercised the read path end to end — not just the daemon method.
    pub fn read_support_bundle(
        &mut self,
        request: caly_api::SupportBundleReadRequest,
    ) -> Result<caly_api::SupportBundleView, String> {
        let result = self.send_operation(
            "loopback-read-support-bundle",
            Operation::Diagnostics(DiagnosticsOp::ReadSupportBundle { request }),
            None,
        )?;
        match result {
            OperationResult::SupportBundle(value) => Ok(value),
            other => Err(format!("unexpected bundle read result: {:?}", other)),
        }
    }

    /// A page of a job's retained event lines, as the stream would have shown them.
    pub fn read_job_events(
        &mut self,
        request: caly_api::JobEventsRequest,
    ) -> Result<caly_api::JobEventsView, String> {
        let result = self.send_operation(
            "loopback-read-job-events",
            Operation::Diagnostics(DiagnosticsOp::ReadJobEvents { request }),
            None,
        )?;
        match result {
            OperationResult::JobEvents(value) => Ok(value),
            other => Err(format!("unexpected job events result: {:?}", other)),
        }
    }

    pub fn automation_list_jobs(&mut self) -> Result<Vec<AutomationJobView>, String> {
        let result = self.send_operation(
            "loopback-automation-list",
            Operation::Automation(caly_api::AutomationOp::ListJobs),
            None,
        )?;
        match result {
            OperationResult::AutomationJobs(value) => Ok(value),
            other => Err(format!("unexpected automation list result: {:?}", other)),
        }
    }

    pub fn automation_patch_job(
        &mut self,
        request: PatchAutomationJob,
    ) -> Result<Accepted, String> {
        let result = self.send_operation(
            "loopback-automation-patch",
            Operation::Automation(caly_api::AutomationOp::PatchJob { request }),
            None,
        )?;
        match result {
            OperationResult::Accepted(value) => Ok(value),
            other => Err(format!("unexpected automation patch result: {:?}", other)),
        }
    }

    pub fn follow_job_query(
        &mut self,
        job_id: caly_api::JobId,
        from_event_index: Option<u64>,
    ) -> Result<JobFollowView, String> {
        let result = self.send_operation(
            "loopback-follow-job",
            Operation::Diagnostics(DiagnosticsOp::FollowJob {
                request: JobFollowRequest {
                    job_id,
                    from_event_index,
                },
            }),
            None,
        )?;
        match result {
            OperationResult::JobFollow(value) => Ok(value),
            other => Err(format!("unexpected follow job result: {:?}", other)),
        }
    }

    pub fn open_runtime_stream(
        &mut self,
        subscription: RuntimeSubscription,
    ) -> Result<WatchOpened, String> {
        let result = self.send_operation(
            "open-runtime-stream",
            Operation::Runtime(RuntimeOp::Watch {
                subscription: subscription.clone(),
            }),
            None,
        )?;
        match result {
            OperationResult::WatchOpened(opened) => {
                let kind = match subscription {
                    RuntimeSubscription::Dashboard => StreamKind::Dashboard,
                    RuntimeSubscription::Traffic => StreamKind::Traffic,
                    RuntimeSubscription::Logs => StreamKind::Logs,
                    RuntimeSubscription::Connections => StreamKind::Connections,
                };
                self.client.register_stream(opened.stream_id, kind);
                Ok(opened)
            }
            other => Err(format!(
                "unexpected result when opening runtime stream: {:?}",
                other
            )),
        }
    }

    pub fn open_job_follow_stream(
        &mut self,
        request: JobFollowRequest,
    ) -> Result<WatchOpened, String> {
        let result = self.send_operation(
            "open-job-follow-stream",
            Operation::Diagnostics(DiagnosticsOp::FollowJobStream {
                request: request.clone(),
            }),
            None,
        )?;
        match result {
            OperationResult::WatchOpened(opened) => {
                self.client
                    .register_stream(opened.stream_id, StreamKind::Job);
                Ok(opened)
            }
            other => Err(format!(
                "unexpected result when opening job follow stream: {:?}",
                other
            )),
        }
    }

    pub fn follow_stream(
        &mut self,
        stream_id: caly_api::StreamId,
        from_seq: Option<u64>,
    ) -> Result<Vec<StreamFrame>, String> {
        match self.transport.pull_stream(&self.app, stream_id, from_seq)? {
            TransportStepOutput::StreamFrames(frames) => self.consume_stream_frames(frames),
            other => Err(format!("unexpected stream pull output: {:?}", other)),
        }
    }

    pub fn ack_stream(
        &mut self,
        stream_id: caly_api::StreamId,
        upto_seq: u64,
    ) -> Result<(), String> {
        let frame = self
            .client
            .make_stream_ack(stream_id, upto_seq)
            .map_err(|e| e.summary)?;
        let header = make_header(0, Encoding::Json, Compression::None);
        let output = self
            .transport
            .on_client_frame(&self.app, header, frame, true)?;
        match output {
            TransportStepOutput::ResponseFrames(frames) if frames.is_empty() => Ok(()),
            TransportStepOutput::ResponseFrames(_) => Ok(()),
            other => Err(format!("unexpected output for stream ack: {:?}", other)),
        }
    }

    pub fn force_hello_timeout(&mut self) -> Result<(), String> {
        match self.transport.on_hello_timeout(&self.app)? {
            TransportStepOutput::Closed(_) => {
                self.client.close();
                Ok(())
            }
            other => Err(format!("unexpected output for hello timeout: {:?}", other)),
        }
    }

    pub fn inspect(&self) -> TransportInspection {
        self.transport.inspect()
    }

    pub fn snapshot(&self) -> HarnessSnapshot {
        let daemon = self.app.runtime_snapshot().ok();
        let inspection = self.transport.inspect();
        HarnessSnapshot {
            client_state: self.client.state,
            daemon_state: daemon
                .map(|state| format!("{:?}", state.lifecycle))
                .unwrap_or_else(|| "unknown".to_owned()),
            open_stream_count: inspection.open_stream_count,
        }
    }

    pub fn encode_probe_json(&self, payload: &str) -> usize {
        let frame = encode_raw_json(payload, Encoding::Json, Compression::None);
        frame.payload.len()
    }

    fn consume_response_frames(
        &mut self,
        frames: Vec<ServerFrame>,
    ) -> Result<OperationResult, String> {
        let mut last = None;
        for frame in frames {
            self.client
                .observe_server_frame(&frame)
                .map_err(|e| e.summary)?;
            if let ServerFrame::Response(response) = frame {
                last = Some(response.result.map_err(describe_refusal)?);
            }
        }
        last.ok_or_else(|| "response frame set did not contain a response".to_owned())
    }

    fn consume_stream_frames(
        &mut self,
        frames: Vec<ServerFrame>,
    ) -> Result<Vec<StreamFrame>, String> {
        let mut out = Vec::new();
        for frame in frames {
            self.client
                .observe_server_frame(&frame)
                .map_err(|e| e.summary)?;
            if let ServerFrame::Stream(stream) = frame {
                out.push(stream);
            }
        }
        Ok(out)
    }
}
