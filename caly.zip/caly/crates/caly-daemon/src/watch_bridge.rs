use caly_api::{JobId, StreamId};
use caly_engine::{EventKind, EventPayload, JobEvent, JobOutcome as EngineJobOutcome};
use caly_ipc::{JobOutcome, ResetReason, StreamFrame, StreamKind, StreamPayload};

use crate::app::DaemonApp;

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct WatchBridgeRequest {
    pub stream_id: StreamId,
    pub kind: StreamKind,
    pub from_seq_exclusive: Option<u64>,
}

pub fn bridge_engine_events(
    app: &DaemonApp,
    request: WatchBridgeRequest,
) -> Result<Vec<StreamFrame>, String> {
    let followed = app.event_window(request.from_seq_exclusive)?;

    if followed.reset_required {
        return Ok(vec![StreamFrame {
            stream_id: request.stream_id,
            seq: followed.next_seq,
            kind: request.kind,
            payload: StreamPayload::Reset {
                reason: ResetReason::StateGapTooLarge,
            },
        }]);
    }

    let mut frames = Vec::new();
    for event in followed.events {
        frames.push(StreamFrame {
            stream_id: request.stream_id,
            seq: event.seq.0,
            kind: request.kind,
            payload: stream_payload_from_event(app, event.kind, event.payload)?,
        });
    }

    Ok(frames)
}

pub fn bridge_job_follow(
    app: &DaemonApp,
    stream_id: StreamId,
    job_id: JobId,
    from_event_index: Option<u64>,
) -> Result<Vec<StreamFrame>, String> {
    let followed = match app.follow_job_projection(job_id, from_event_index)? {
        Some(value) => value,
        None => return Ok(Vec::new()),
    };

    if followed.summary.reset_required {
        return Ok(vec![StreamFrame {
            stream_id,
            seq: followed.summary.next_event_index,
            kind: StreamKind::Job,
            payload: StreamPayload::Reset {
                reason: ResetReason::StateGapTooLarge,
            },
        }]);
    }

    let mut frames = Vec::new();
    if let Some(window) = followed.window {
        // One source for "where this slice starts": `slice_job_events` already took the later of the
        // caller's cursor and the retention floor, and re-doing that max here is how the two readers
        // would drift apart (`docs/history/ONBOARDING_NOTES.md §4.54`).
        let base = window.first_index;
        for (offset, event) in window.events.into_iter().enumerate() {
            frames.push(StreamFrame {
                stream_id,
                seq: base.saturating_add(offset as u64),
                kind: StreamKind::Job,
                payload: stream_payload_from_job_event(job_id, event),
            });
        }
    }
    Ok(frames)
}

fn stream_payload_from_event(
    app: &DaemonApp,
    _kind: EventKind,
    payload: EventPayload,
) -> Result<StreamPayload, String> {
    let runtime = app.runtime_snapshot()?;
    Ok(match payload {
        EventPayload::CommandAccepted { job_id, revision } => {
            StreamPayload::CommandAccepted { job_id, revision }
        }
        EventPayload::CommandRejected { reason } => StreamPayload::CommandRejected { reason },
        EventPayload::JobUpdated { job_id, state } => StreamPayload::JobStage {
            job_id,
            stage: state,
            pct: None,
        },
        EventPayload::RuntimeChanged { summary } => StreamPayload::RuntimeState {
            active_profile: runtime.active_profile.map(|value| value.0),
            active_core: runtime.active_core,
            active_snapshot: runtime.active_snapshot,
            state_revision: runtime.state_revision,
            summary,
        },
        EventPayload::DeploymentChanged { summary } => StreamPayload::DeploymentEvent { summary },
        EventPayload::SnapshotCommitted { snapshot_id } => {
            StreamPayload::SnapshotCommitted { snapshot_id }
        }
        EventPayload::JournalRecovered { journal_id } => StreamPayload::RecoveryEvent {
            summary: format!("journal recovered: {journal_id}"),
        },
        EventPayload::RecoveryDecision { summary } => StreamPayload::RecoveryEvent { summary },
        EventPayload::StreamReset { reason, .. } => StreamPayload::Reset {
            reason: parse_reset_reason(&reason),
        },
    })
}

fn parse_reset_reason(reason: &str) -> ResetReason {
    match reason.to_ascii_lowercase().as_str() {
        "overflow" => ResetReason::Overflow,
        "daemonrestarted" | "daemon_restarted" | "daemon restarted" => ResetReason::DaemonRestarted,
        "subscriptionreplaced" | "subscription_replaced" | "subscription replaced" => {
            ResetReason::SubscriptionReplaced
        }
        _ => ResetReason::StateGapTooLarge,
    }
}

fn stream_payload_from_job_event(job_id: JobId, event: JobEvent) -> StreamPayload {
    match event {
        JobEvent::Stage { stage, pct } => StreamPayload::JobStage { job_id, stage, pct },
        JobEvent::Warning { message } => StreamPayload::JobWarning { job_id, message },
        JobEvent::Done { outcome } => StreamPayload::JobDone {
            job_id,
            outcome: match outcome {
                EngineJobOutcome::Succeeded => JobOutcome::Succeeded,
                EngineJobOutcome::Failed => JobOutcome::Failed,
                EngineJobOutcome::Cancelled => JobOutcome::Cancelled,
                EngineJobOutcome::TimedOut => JobOutcome::TimedOut,
            },
        },
        JobEvent::Log { level, message } => StreamPayload::JobLog {
            job_id,
            level,
            message,
        },
        JobEvent::Failed { error } => StreamPayload::JobFailed {
            job_id,
            code: error.code.as_str().to_owned(),
            summary: error.summary,
            remediation: error.remediation,
        },
    }
}
