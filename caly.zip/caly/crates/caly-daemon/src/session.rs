use std::collections::BTreeMap;

use caly_common::Actor;
use caly_ipc::{
    stream_policy, AckPolicy, ClientFrame, ClientHello, FrameHeader, NegotiationPolicy,
    ServerFrame, SessionMachine, SessionValidationError,
};

use crate::app::DaemonApp;
use crate::handler::handle_request;
use crate::stream::{
    is_snapshot_then_patch, opened_stream_state_for_operation, snapshot_frame, StreamCursorState,
    StreamSource, MAX_WATCH_FRAMES_PER_PULL,
};
use crate::watch_bridge::{bridge_engine_events, bridge_job_follow, WatchBridgeRequest};

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct DaemonSession {
    pub actor: Actor,
    pub machine: SessionMachine,
    pub opened_streams: BTreeMap<u64, StreamCursorState>,
}

impl DaemonSession {
    pub fn new(actor: Actor, policy: NegotiationPolicy) -> Self {
        Self {
            actor,
            machine: SessionMachine::new(policy),
            opened_streams: BTreeMap::new(),
        }
    }

    pub fn accept_hello(
        &mut self,
        app: &DaemonApp,
        hello: &ClientHello,
        session_id: impl Into<String>,
    ) -> Result<caly_ipc::ServerHelloAck, caly_ipc::HandshakeError> {
        let runtime = app
            .runtime_snapshot()
            .map_err(|message| caly_ipc::HandshakeError {
                code: caly_ipc::HandshakeErrorCode::ProtoMismatch,
                summary: message,
            })?;

        self.machine.accept_hello(
            hello,
            session_id,
            runtime.daemon_name,
            runtime.daemon_version,
            runtime.instance_id,
            runtime.state_revision,
        )
    }

    pub fn validate_frame(
        &self,
        header: &FrameHeader,
        is_control_message: bool,
    ) -> Result<(), caly_ipc::FrameValidationError> {
        self.machine.validate_frame(header, is_control_message)
    }

    pub fn handle_request(
        &mut self,
        app: &DaemonApp,
        envelope: &caly_api::RequestEnvelope,
    ) -> Result<caly_api::ResponseEnvelope, SessionValidationError> {
        self.machine.validate_request(envelope)?;
        // The session's stream table is bounded (round 133, `R131-F1`): a stream-opening
        // request past `MAX_OPENED_SESSION_STREAMS` is refused by name BEFORE anything is
        // allocated, through the same redacting error door every other refusal uses — the
        // wire-side job-follow table has had this shape since round 96; this is its twin.
        if crate::stream::stream_kind_for_operation(&envelope.operation).is_some()
            && self.opened_streams.len() >= crate::stream::MAX_OPENED_SESSION_STREAMS
        {
            let error = caly_api::ApiError::new(
                caly_api::ErrorCode::Unavailable,
                caly_api::ErrorCategory::Internal,
                true,
                format!(
                    "the session stream table is full ({}); streams must end before new \
                     ones open",
                    crate::stream::MAX_OPENED_SESSION_STREAMS
                ),
                envelope.trace_id.clone(),
            )
            .with_remediation(
                "let existing streams end, or drop the session, before opening new ones",
            );
            return Ok(crate::handler::error_response(app, envelope, error));
        }
        let response = handle_request(app, self.actor, envelope);
        if let Ok(caly_api::OperationResult::WatchOpened(opened)) = &response.result {
            if let Some(state) = opened_stream_state_for_operation(&envelope.operation, opened) {
                self.opened_streams
                    .insert(opened.stream_id.0, StreamCursorState::new(state));
            }
        }
        Ok(response)
    }

    pub fn handle_client_frame(
        &mut self,
        app: &DaemonApp,
        frame: &ClientFrame,
    ) -> Result<Vec<ServerFrame>, String> {
        match frame {
            ClientFrame::Request(envelope) => self
                .handle_request(app, envelope)
                .map(|response| vec![ServerFrame::Response(response)])
                .map_err(|error| error.summary),
            ClientFrame::StreamAck(ack) => {
                let opened = self
                    .opened_streams
                    .get_mut(&ack.stream_id.0)
                    .ok_or_else(|| format!("unknown stream id: {}", ack.stream_id.0))?;
                let policy = stream_policy(opened.opened.kind);
                if matches!(policy.ack, AckPolicy::None) {
                    return Err(format!(
                        "ack not allowed for stream kind: {:?}",
                        opened.opened.kind
                    ));
                }
                opened.apply_ack(ack.upto_seq);
                Ok(Vec::new())
            }
        }
    }

    pub fn follow_opened_stream(
        &mut self,
        app: &DaemonApp,
        stream_id: caly_api::StreamId,
        from_seq_exclusive: Option<u64>,
    ) -> Result<Vec<ServerFrame>, String> {
        let opened = self
            .opened_streams
            .get_mut(&stream_id.0)
            .ok_or_else(|| format!("unknown stream id: {}", stream_id.0))?;

        let effective_from = opened.preferred_resume_from(from_seq_exclusive);

        // SnapshotThenPatch (IPC_STREAM_POLICY §3): a Dashboard/Connections stream's FIRST
        // pull is one snapshot of the CURRENT state — the kind's own one-shot query,
        // restated — seq'd at the live edge, so the patch stream continues at +1 and the
        // pre-snapshot history (already folded into the snapshot) is never re-delivered.
        // "First" needs no extra cursor checks: `preferred_resume_from` already folds the
        // acked and emitted cursors (and any explicit resume position) into
        // `effective_from`, so `None` here means exactly "no cursor of any kind" — a
        // reconnecting client resumes as patches, by design.
        let snapshot_due = matches!(&opened.opened.source, StreamSource::RuntimeSubscription(_))
            && is_snapshot_then_patch(opened.opened.kind)
            && effective_from.is_none();

        let frames = if snapshot_due {
            let live_edge = app.event_window(None)?.next_seq.saturating_sub(1);
            vec![snapshot_frame(
                app,
                opened.opened.kind,
                stream_id,
                live_edge,
            )?]
        } else {
            match &opened.opened.source {
                StreamSource::RuntimeSubscription(_) => {
                    // A pull is bounded (IPC_STREAM_POLICY §7), and since round 133 (`R131-F6`)
                    // the bound is applied where frames are MINTED: the bridge stops at
                    // `MAX_WATCH_FRAMES_PER_PULL` instead of building the whole retained
                    // window and truncating three quarters of it away. The retained window
                    // still holds what this pull leaves behind; the stream's cursor (advanced
                    // by note_emitted_frames below) resumes exactly after the last frame kept.
                    bridge_engine_events(
                        app,
                        WatchBridgeRequest {
                            stream_id,
                            kind: opened.opened.kind,
                            from_seq_exclusive: effective_from,
                        },
                        MAX_WATCH_FRAMES_PER_PULL,
                    )?
                }
                StreamSource::JobFollow(request) => {
                    bridge_job_follow(app, stream_id, request.job_id, effective_from)?
                }
            }
        };

        opened.note_emitted_frames(&frames);
        Ok(frames.into_iter().map(ServerFrame::Stream).collect())
    }
}
