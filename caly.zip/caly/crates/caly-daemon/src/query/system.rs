use caly_api::{OperationResult, RequestEnvelope, ServerInfo, SystemStatus};

use crate::app::DaemonApp;

use super::common::internal_query_error;

pub fn handle_system(
    app: &DaemonApp,
    envelope: &RequestEnvelope,
    op: &caly_api::SystemOp,
) -> Result<Option<OperationResult>, caly_api::ApiError> {
    match op {
        caly_api::SystemOp::Status => {
            let runtime = app
                .runtime_snapshot()
                .map_err(|message| internal_query_error(envelope, message))?;
            Ok(Some(OperationResult::SystemStatus(SystemStatus {
                daemon_state: format!("{:?}", runtime.lifecycle).to_lowercase(),
                active_profile: runtime.active_profile,
                active_core: runtime.active_core,
                state_revision: runtime.state_revision,
            })))
        }
        caly_api::SystemOp::Info => {
            let runtime = app
                .runtime_snapshot()
                .map_err(|message| internal_query_error(envelope, message))?;
            Ok(Some(OperationResult::ServerInfo(ServerInfo {
                daemon_name: runtime.daemon_name,
                daemon_version: runtime.daemon_version,
                protocol_version: runtime.protocol_version,
                instance_id: runtime.instance_id,
            })))
        }
        caly_api::SystemOp::GcPlan { request } => {
            // Validated here, in the crate that turns refusals into status codes, but resolved by the
            // engine's own `resolve` -- the ranges live next to the constants they bound.
            let bounds = caly_engine::gc_plan::GcPlanBounds {
                grace_period_ms: request.grace_period_ms,
                max_deletions: request.max_deletions,
            }
            .resolve()
            .map_err(|refusal| bad_gc_request(envelope, refusal.message()))?;
            let plan = app
                .storage_gc_plan(bounds)
                .map_err(|message| internal_query_error(envelope, message))?;
            // The last cycle travels with the plan on purpose: `would_run` says what *would* happen,
            // and the only thing that tells an operator what already did is the record. Keeping them
            // in one answer is also what gives `GcRunView` a producer (`§4.102`).
            let last_run = app
                .last_gc_run()
                .map_err(|message| internal_query_error(envelope, message))?;
            Ok(Some(OperationResult::GcPlan(gc_view(
                &plan,
                last_run.as_ref(),
            ))))
        }
        caly_api::SystemOp::CollectGarbage { .. } => Ok(None),
        caly_api::SystemOp::Shutdown => Ok(None),
    }
}

/// The store's plan, in the shape that crosses a wire.
///
/// A field-for-field map rather than a `From` impl: both types are foreign to this crate, so an impl
/// here is a coherence argument waiting to happen, and moving the DTO into `caly-engine` would make
/// the engine the owner of a client-facing shape.
/// One collection record, in the shape that crosses a wire.
///
/// Field-for-field, and pinned by a test against the engine's own rendering: a mapper that drops a
/// field is invisible until somebody downstream needs it, and `triggered_by` is exactly the field
/// nobody would notice missing -- it is the difference between "the daemon deleted these" and "an
/// operator asked for these to be deleted" (`ADR-038 §9`).
fn gc_run_view(record: &caly_engine::gc_plan::GcRunRecord) -> caly_api::GcRunView {
    caly_api::GcRunView {
        at_generation: record.at_generation,
        now_unix_ms: record.now_unix_ms,
        now_source: record.now_source.to_owned(),
        grace_period_ms: record.grace_period_ms,
        max_deletions: record.max_deletions,
        collected: record.collected.clone(),
        failed: record
            .failed
            .iter()
            .map(|(digest, reason)| caly_api::GcFailureView {
                digest: digest.clone(),
                reason: reason.clone(),
            })
            .collect(),
        retained_total: record.retained_total,
        skipped_for_grace: record.skipped_for_grace,
        collected_content: record.collected_content.clone(),
        failed_content: record
            .failed_content
            .iter()
            .map(|(target, reason)| caly_api::GcFailureView {
                digest: target.clone(),
                reason: reason.clone(),
            })
            .collect(),
        refused: record.refused.clone(),
        triggered_by: record.triggered_by.to_owned(),
    }
}

fn gc_view(
    plan: &caly_engine::gc_plan::GcPlanSummary,
    last_run: Option<&caly_engine::gc_plan::GcRunRecord>,
) -> caly_api::GcPlanView {
    caly_api::GcPlanView {
        now_unix_ms: plan.now_unix_ms,
        now_source: plan.now_source.to_owned(),
        grace_period_ms: plan.grace_period_ms,
        max_deletions: plan.max_deletions,
        sample_limit: plan.sample_limit,
        objects_total: plan.objects_total,
        snapshots_total: plan.snapshots_total,
        revisions_total: plan.revisions_total,
        unfinished_journals: plan.unfinished_journals,
        collect: plan.collect.clone(),
        retained_total: plan.retained_total,
        retained_sample: plan
            .retained_sample
            .iter()
            .map(|entry| caly_api::GcRetainedView {
                digest: entry.digest.clone(),
                reasons: entry.reasons.clone(),
            })
            .collect(),
        deferred_over_cap: plan.deferred_over_cap,
        skipped_for_grace: plan.skipped_for_grace,
        content_total: plan.content_total,
        orphan_collect: plan.orphan_collect.clone(),
        orphan_skipped_for_grace: plan.orphan_skipped_for_grace,
        orphan_deferred_over_cap: plan.orphan_deferred_over_cap,
        idle: plan.idle,
        pending_deployments: plan.pending_deployments,
        gaps: plan
            .gaps
            .iter()
            .map(|gap| caly_api::GcRootGapView {
                class: gap.class.to_owned(),
                detail: gap.detail.clone(),
                actionable: gap.actionable,
            })
            .collect(),
        would_run: plan.would_run(),
        refusal: plan.refusal(),
        last_run: last_run.map(|record| Box::new(gc_run_view(record))),
    }
}

fn bad_gc_request(envelope: &RequestEnvelope, message: String) -> caly_api::ApiError {
    caly_api::ApiError::new(
        caly_api::ErrorCode::ConfigInvalid,
        caly_api::ErrorCategory::User,
        false,
        message,
        envelope.trace_id.clone(),
    )
    // The same words the command path uses, from one const: two operations, one contract.
    .with_remediation(crate::request_map::BOUNDS_REMEDIATION)
}
