use caly_api::{DoctorReport, OperationResult, RecoveryStatusView, RequestEnvelope};

use crate::app::DaemonApp;
use crate::state::DaemonLifecycle;

use super::common::internal_query_error;

pub fn handle_diagnostics(
    app: &DaemonApp,
    envelope: &RequestEnvelope,
    op: &caly_api::DiagnosticsOp,
) -> Result<Option<OperationResult>, caly_api::ApiError> {
    match op {
        caly_api::DiagnosticsOp::Doctor { request } => {
            let runtime = app
                .runtime_snapshot()
                .map_err(|message| internal_query_error(envelope, message))?;
            let recovery = app
                .recovery_scan()
                .map_err(|message| internal_query_error(envelope, message))?;
            let audit = app
                .storage_audit()
                .map_err(|message| internal_query_error(envelope, message))?;

            // Tiers are kept apart on purpose. This arm used to begin with a fixed
            // "diagnostics pipeline is still partial" warning, which made every `doctor` call
            // non-empty: a real finding and a placeholder were indistinguishable, and "no
            // warnings" stopped being information. Status echoes are counts, so they belong in
            // the summary/notes; only something an operator may need to act on is a warning.
            // Each bulk source is bounded *as it arrives*, and the daemon's own lines are appended after
            // the cut. That order is the point: a store with ten thousand findings must not be able to
            // push out the one sentence about a failed recovery or a full queue, which is the line the
            // operator came for. `RFC-0002 §9`/`§11.4` are satisfied by the bound, `§4.54` by the note.
            let budget = crate::paging::DiagnosticBudget::for_bulk_tier();
            let audit_warnings = crate::paging::bound_lines(audit.warning_lines(), budget);
            let audit_errors = crate::paging::bound_lines(audit.error_lines(), budget);
            let audit_notes = crate::paging::bound_lines(audit.info_lines(), budget);
            let decision_lines = crate::paging::bound_lines(
                recovery
                    .decisions
                    .iter()
                    .map(|decision| format!("recovery decision: {decision:?}"))
                    .collect(),
                budget,
            );
            let mut warnings = audit_warnings.lines.clone();
            let mut errors = audit_errors.lines.clone();
            let mut notes = audit_notes.lines.clone();
            // The daemon's own lines join before the notes, so a truncated tier reads
            // "findings…, then the sentence saying how many were dropped" rather than the note buried in
            // the middle of the list.
            warnings.extend(decision_lines.lines.clone());
            for (what, bounded) in [
                ("audit warnings", &audit_warnings),
                ("audit errors", &audit_errors),
                ("audit notes", &audit_notes),
                ("recovery decisions", &decision_lines),
            ] {
                if let Some(note) = bounded.truncation_note(what, budget) {
                    // The note joins the tier it describes, so reading `errors` alone still tells an
                    // operator that `errors` was cut.
                    if what.ends_with("errors") {
                        errors.push(note);
                    } else if what.ends_with("notes") {
                        notes.push(note);
                    } else {
                        warnings.push(note);
                    }
                }
            }
            let omitted_lines = audit_warnings.omitted
                + audit_errors.omitted
                + audit_notes.omitted
                + decision_lines.omitted;
            let shortened_lines = audit_warnings.shortened
                + audit_errors.shortened
                + audit_notes.shortened
                + decision_lines.shortened;
            let truncated = omitted_lines != 0 || shortened_lines != 0;

            // Refusals caused by pressure are operator-actionable by definition: something was full.
            // They are warnings rather than notes, and they are *not* errors, because the engine already
            // protected itself — the thing to act on is the submit rate, not the daemon's health.
            let overloads = app
                .overload_lines()
                .map_err(|message| internal_query_error(envelope, message))?;
            warnings.extend(overloads);
            if matches!(runtime.lifecycle, DaemonLifecycle::Failed)
                || recovery.decisions.iter().any(|decision| {
                    matches!(
                        decision,
                        caly_storage::RecoveryDecision::EnterFailedState { .. }
                    )
                })
            {
                errors.push("daemon recovery requires operator attention".to_owned());
            }

            // The dedup window is bounded by policy, so the size of the window and the number of
            // records that fell out of it are stated rather than assumed (`ADR-037 §2.5`): a caller
            // that retries after a long pause and gets a second deployment needs to be able to see
            // that the window had already moved on.
            let (entries, window, evictions, refusals) = app
                .idempotency_stats()
                .map_err(|message| internal_query_error(envelope, message))?;
            let mut summary = audit.summary_line();
            notes.push(format!(
                "recovery pending_apply={} pending_os={} decisions={}",
                recovery.unresolved_apply_journals.len(),
                recovery.pending_os_journals.len(),
                recovery.decisions.len(),
            ));
            // The role is reported because "callers keep being refused" has two very different causes —
            // an under-privileged local caller and a client that never sends a key — and the note is
            // where an operator tells them apart. A poisoned lock is therefore an error here, not a
            // `unwrap_or` that prints a plausible role: a diagnostic has no third option between
            // "accurate" and "withdrawn".
            let local_role = app
                .local_role()
                .map_err(|message| internal_query_error(envelope, message))?;
            notes.push(format!(
                "idempotency entries={entries} finished_window={window} evictions={evictions} \
                 keyless_refusals={refusals} (local role {local_role:?})"
            ));
            // The collector's plan belongs in `doctor` for one reason: until it is reported, a store
            // that can only grow is indistinguishable from a healthy one. It is a *note*, and not
            // because the refusals are unimportant: every state that makes the plan refuse (a record
            // the store cannot produce, a marker that cannot be resolved) also makes the audit above
            // fail the whole report first, so a warning here would either duplicate that or never
            // fire. The refusal is therefore carried inside the note's own text, and the per-gap
            // `actionable` flag travels in the view for a caller that wants to tier it -- which is
            // what keeps `would_run` from being the only signal a client gets.
            let plan = caly_engine::gc_plan::GcPlanBounds::default()
                .resolve()
                .map_err(|refusal| refusal.message())
                .and_then(|bounds| app.storage_gc_plan(bounds));
            match plan {
                Ok(plan) => notes.push(match plan.refusal() {
                    Some(refusal) => format!("{} refused: {refusal}", plan.summary_line()),
                    None => plan.summary_line(),
                }),
                Err(problem) => {
                    warnings.push(format!("storage gc plan unavailable: {problem}"));
                }
            }
            // The collector's last cycle, when there was one. A cycle that refused is reported in the
            // same breath as one that deleted nothing, because the difference is the whole point of
            // running it (`ADR-038 §2`): "I did not dare" and "there was nothing to do" must not look
            // alike to whoever is told the disk is fine.
            let last_run = app
                .last_gc_run()
                .map_err(|message| internal_query_error(envelope, message))?;
            notes.push(match &last_run {
                Some(record) => record.summary_line(),
                None => caly_engine::gc_plan::NO_GC_RUN_YET.to_owned(),
            });
            if request.include_runtime {
                summary = format!(
                    "{summary}; runtime active_profile={:?} active_snapshot={:?} engine_lifecycle={:?}",
                    runtime.active_profile, runtime.active_snapshot, runtime.engine_lifecycle
                );
            }
            // The rule itself lives in `paging::may_claim_clean`, where the combination can be unit-tested
            // (the daemon cannot build it end to end today: the audit aggregates its informational findings
            // into a handful of lines, so an empty `warnings` tier never coexists with a cut).
            if crate::paging::may_claim_clean(warnings.is_empty(), errors.is_empty(), truncated) {
                notes.push("no findings requiring action".to_owned());
            }

            Ok(Some(OperationResult::DoctorReport(DoctorReport {
                summary,
                warnings,
                errors,
                notes,
                truncated,
                omitted_lines,
                shortened_lines,
            })))
        }
        caly_api::DiagnosticsOp::ExplainPipeline { request } => {
            Ok(Some(OperationResult::PipelineExplain(
                caly_engine::explain_pipeline(request.clone())
                    .map_err(|message| internal_query_error(envelope, message))?,
            )))
        }
        caly_api::DiagnosticsOp::RecoveryStatus => {
            let runtime = app
                .runtime_snapshot()
                .map_err(|message| internal_query_error(envelope, message))?;
            let recovery = app
                .recovery_scan()
                .map_err(|message| internal_query_error(envelope, message))?;
            let bounded_decisions = crate::paging::bound_lines(
                recovery
                    .decisions
                    .iter()
                    .map(|decision| format!("{decision:?}"))
                    .collect(),
                crate::paging::DiagnosticBudget::for_bulk_tier(),
            );
            Ok(Some(OperationResult::RecoveryStatus(RecoveryStatusView {
                daemon_lifecycle: format!("{:?}", runtime.lifecycle).to_lowercase(),
                active_profile: runtime.active_profile,
                active_core: runtime.active_core,
                active_snapshot: runtime.active_snapshot,
                last_apply_plan_summary: runtime.last_apply_plan_summary,
                pending_apply_count: recovery.unresolved_apply_journals.len(),
                pending_os_count: recovery.pending_os_journals.len(),
                decision_count: recovery.decisions.len(),
                // Same bound as `doctor`, same reason: one decision per unresolved journal is a
                // collection sized by the store, not by the caller. `decision_count` above deliberately
                // keeps the true total -- a total that shrank to fit the reply would be the most
                // convincing kind of lie, and it is the only number in this view a caller acts on.
                decisions: bounded_decisions.lines.clone(),
                last_recovery_summary: runtime.last_recovery_summary,
                truncated: bounded_decisions.truncated(),
                omitted_decisions: bounded_decisions.omitted,
                shortened_decisions: bounded_decisions.shortened,
            })))
        }
        caly_api::DiagnosticsOp::FollowJob { request } => {
            let projection = app
                .follow_job_projection(request.job_id, request.from_event_index)
                .map_err(|message| internal_query_error(envelope, message))?;
            match projection {
                Some(projection) => Ok(Some(OperationResult::JobFollow(projection.summary))),
                // `Ok(None)` means "this facet has no handler" and the router turns it into
                // "no daemon handler is connected yet". An unknown job id is *not* that: the
                // handler ran and found nothing. Conflating them made a legitimate empty result
                // indistinguishable from an unimplemented operation - in both directions.
                None => Err(no_such_job(envelope, request.job_id.0)),
            }
        }
        caly_api::DiagnosticsOp::ReadJobEvents { request } => {
            let view = app
                .job_events_view(request)
                .map_err(|message| bad_page_request(envelope, message))?
                .ok_or_else(|| no_such_job(envelope, request.job_id.0))?;
            Ok(Some(OperationResult::JobEvents(view)))
        }
        caly_api::DiagnosticsOp::ReadSupportBundle { request } => {
            let view = app
                .read_support_bundle(request.clone())
                .map_err(|message| read_bundle_refusal(envelope, message))?;
            Ok(Some(OperationResult::SupportBundle(view)))
        }
        caly_api::DiagnosticsOp::SupportBundle => Err(caly_api::ApiError::new(
            // The router maps this operation to `CommandKind::DiagnosticsBundle`, so a request that
            // arrives on the *query* path was mis-routed. Answering `Ok(None)` here would produce
            // "no daemon handler is connected yet" — the same reply a genuinely unimplemented
            // operation gets, which is the conflation `docs/ONBOARDING_NOTES.md §4.21` is about.
            caly_api::ErrorCode::Conflict,
            caly_api::ErrorCategory::User,
            false,
            "support bundle is a command, not a query",
            envelope.trace_id.clone(),
        )
        .with_remediation(
            "submit DiagnosticsOp::SupportBundle as a command and follow the accepted job; the \
             bundle is stored content-addressed and its digest is reported on that job",
        )),
        caly_api::DiagnosticsOp::FollowJobStream { .. } => Ok(None),
    }
}

/// Why a bundle read failed, in the caller's terms.
///
/// "No such object" and "that object is not a bundle" are different answers with different fixes, and
/// the second is a refusal rather than a miss: the store also keeps compiled artifacts and raw
/// sources, which are **not** redacted, so they must not be reachable through a diagnostics query
/// (`RFC-0010 §12.3`). Both are `CONFLICT` — the request is well-formed, the state it names is what
/// does not work — and the distinction is carried in the remediation.
fn read_bundle_refusal(envelope: &RequestEnvelope, message: String) -> caly_api::ApiError {
    let is_kind = message.contains("not a support bundle");
    let error = caly_api::ApiError::new(
        caly_api::ErrorCode::Conflict,
        caly_api::ErrorCategory::User,
        false,
        message,
        envelope.trace_id.clone(),
    );
    if is_kind {
        error.with_remediation(
            "this query reads only ObjectKind::SupportBundle objects: the store also keeps compiled \
             artifacts and raw sources, and those are not redacted, so they stay unreachable here",
        )
    } else {
        error.with_remediation(
            "read the digest off the bundle job's own log line, or submit DiagnosticsOp::SupportBundle \
             and follow that job; bundle objects are unreferenced and gc may collect them",
        )
    }
}

/// A page bound the daemon will not honour, kept apart from an internal failure on purpose: the
/// caller can fix this one by editing its own request, and telling it "internal error, retry" would
/// send a client into a retry loop over its own typo.
fn bad_page_request(envelope: &RequestEnvelope, message: String) -> caly_api::ApiError {
    caly_api::ApiError::new(
        caly_api::ErrorCode::ConfigInvalid,
        caly_api::ErrorCategory::User,
        false,
        message,
        envelope.trace_id.clone(),
    )
    .with_remediation(
        "omit max_lines / max_bytes for the daemon's default page, or pass a value within the \
         published caps",
    )
}

/// The one answer to "that job does not exist", shared by the summary and the event-content query.
///
/// Two operations, two copies of this text, is how one of them eventually starts saying something
/// else — and `Ok(None)` is not an option here, because the router would turn it into "no daemon
/// handler is connected yet" (`docs/ONBOARDING_NOTES.md §4.25`).
fn no_such_job(envelope: &RequestEnvelope, job_id: u64) -> caly_api::ApiError {
    caly_api::ApiError::new(
        caly_api::ErrorCode::Conflict,
        caly_api::ErrorCategory::User,
        false,
        format!("no such job: {job_id}"),
        envelope.trace_id.clone(),
    )
    .with_remediation("follow a job this daemon accepted; job history is not durable")
}
