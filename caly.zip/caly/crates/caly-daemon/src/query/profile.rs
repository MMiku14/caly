use caly_api::{ApiError, ErrorCategory, ErrorCode, OperationResult, RequestEnvelope};
use caly_engine::deployment_plan_view;

use crate::app::{DaemonApp, ProfileViewError};

use super::common::internal_query_error;

/// The one answer to "that profile does not exist", the profile-side twin of
/// `diagnostics::no_such_job`: a `Conflict` refusal that names the id, not an empty view and
/// not a fabricated one. Before round 113 the get answered any id with a default-labelled
/// projection — a typo'd profile name was a silent success (`§4.187`).
fn no_such_profile(envelope: &RequestEnvelope, profile_id: &caly_api::ProfileId) -> ApiError {
    ApiError::new(
        ErrorCode::Conflict,
        ErrorCategory::User,
        false,
        format!("no such profile: {}", profile_id.0),
        envelope.trace_id.clone(),
    )
    .with_remediation(
        "profile.get answers the default profile and the active one; apply a profile to \
         register it",
    )
}

pub fn handle_profile(
    app: &DaemonApp,
    envelope: &RequestEnvelope,
    op: &caly_api::ProfileOp,
) -> Result<Option<OperationResult>, caly_api::ApiError> {
    match op {
        caly_api::ProfileOp::List => Ok(Some(OperationResult::ProfileList(
            app.profile_summaries()
                .map_err(|message| internal_query_error(envelope, message))?,
        ))),
        caly_api::ProfileOp::Get { profile_id } => match app.profile_view(profile_id.clone()) {
            Ok(view) => Ok(Some(OperationResult::ProfileView(view))),
            Err(ProfileViewError::UnknownProfile(asked)) => Err(no_such_profile(envelope, &asked)),
            Err(ProfileViewError::Internal(message)) => {
                Err(internal_query_error(envelope, message))
            }
        },
        caly_api::ProfileOp::Plan { request } => Ok(Some(OperationResult::DeploymentPlan(
            deployment_plan_view(request.clone())
                .map_err(|message| internal_query_error(envelope, message))?,
        ))),
        caly_api::ProfileOp::Apply { .. } | caly_api::ProfileOp::Rollback { .. } => Ok(None),
    }
}
