use caly_api::{OperationResult, RequestEnvelope};

use crate::app::DaemonApp;

use super::common::internal_query_error;

pub fn handle_runtime(
    app: &DaemonApp,
    envelope: &RequestEnvelope,
    op: &caly_api::RuntimeOp,
) -> Result<Option<OperationResult>, caly_api::ApiError> {
    match op {
        caly_api::RuntimeOp::Status => Ok(Some(OperationResult::RuntimeStatus(
            app.runtime_status()
                .map_err(|message| internal_query_error(envelope, message))?,
        ))),
        caly_api::RuntimeOp::Connections { query } => Ok(Some(OperationResult::ConnectionPage(
            app.connection_page(query.clone())
                .map_err(|message| internal_query_error(envelope, message))?,
        ))),
        caly_api::RuntimeOp::CloseConnection { .. } => Ok(None),
        caly_api::RuntimeOp::Watch { .. } => Ok(None),
    }
}
