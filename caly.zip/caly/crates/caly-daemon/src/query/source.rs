use caly_api::{ApiError, ErrorCategory, ErrorCode, OperationResult, RequestEnvelope};

use crate::app::{DaemonApp, SourceViewError};

use super::common::internal_query_error;

/// The one answer to "that source does not exist", the source-side twin of
/// `profile::no_such_profile`: a `Conflict` refusal that names the id, not an empty view and
/// not a fabricated one. Before round 114 the get answered any id with a default-labelled
/// projection — a typo'd source id was a silent success (§4.188).
fn no_such_source(envelope: &RequestEnvelope, source_id: &caly_api::SourceId) -> ApiError {
    ApiError::new(
        ErrorCode::Conflict,
        ErrorCategory::User,
        false,
        format!("no such source: {}", source_id.0),
        envelope.trace_id.clone(),
    )
    .with_remediation(
        "sources.inspect answers registered endpoint ids and the profile workflow's resolved \
         sources; register one with --source-endpoint id=locator or let an apply resolve it",
    )
}

pub fn handle_source(
    app: &DaemonApp,
    ctx: &caly_common::RequestContext,
    envelope: &RequestEnvelope,
    op: &caly_api::SourceOp,
) -> Result<Option<OperationResult>, Box<caly_api::ApiError>> {
    match op {
        caly_api::SourceOp::List => Ok(Some(OperationResult::SourceList(
            app.source_summaries()
                .map_err(|message| Box::new(internal_query_error(envelope, message)))?,
        ))),
        caly_api::SourceOp::Inspect { source_id } => {
            match app.source_inspection(source_id.clone(), ctx) {
                Ok(inspection) => Ok(Some(OperationResult::SourceInspection(inspection))),
                Err(SourceViewError::UnknownSource(asked)) => {
                    Err(Box::new(no_such_source(envelope, &asked)))
                }
                Err(SourceViewError::Internal(message)) => {
                    Err(Box::new(internal_query_error(envelope, message)))
                }
            }
        }
        caly_api::SourceOp::Preview { request } => Ok(Some(OperationResult::SourcePreview(
            app.source_preview(request.clone())
                .map_err(|message| Box::new(internal_query_error(envelope, message)))?,
        ))),
        caly_api::SourceOp::Update { .. } => Ok(None),
    }
}
