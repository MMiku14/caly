use caly_api::{NetworkStatus, OperationResult, RequestEnvelope};

use crate::app::DaemonApp;

use super::common::internal_query_error;

pub fn handle_network(
    app: &DaemonApp,
    envelope: &RequestEnvelope,
    op: &caly_api::NetworkOp,
) -> Result<Option<OperationResult>, caly_api::ApiError> {
    match op {
        caly_api::NetworkOp::Status => {
            let runtime = app
                .runtime_snapshot()
                .map_err(|message| internal_query_error(envelope, message))?;
            Ok(Some(OperationResult::NetworkStatus(NetworkStatus {
                tun_enabled: runtime
                    .last_apply_plan_summary
                    .as_deref()
                    .map(|_| true)
                    .unwrap_or(false),
                system_proxy_enabled: runtime.active_snapshot.is_some(),
                system_dns_overridden: runtime.active_snapshot.is_some(),
            })))
        }
        caly_api::NetworkOp::InspectPlan { profile_id } => Ok(Some(OperationResult::NetworkPlan(
            app.network_plan_view(profile_id.clone())
                .map_err(|message| internal_query_error(envelope, message))?,
        ))),
        caly_api::NetworkOp::Repair => Ok(None),
    }
}
