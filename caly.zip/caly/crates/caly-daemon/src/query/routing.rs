use caly_api::{OperationResult, RequestEnvelope};

use crate::app::DaemonApp;

use super::common::internal_query_error;

pub fn handle_routing(
    app: &DaemonApp,
    envelope: &RequestEnvelope,
    op: &caly_api::RoutingOp,
) -> Result<Option<OperationResult>, caly_api::ApiError> {
    match op {
        caly_api::RoutingOp::Rules { query } => Ok(Some(OperationResult::RulePage(
            app.rule_page(query.clone())
                .map_err(|message| internal_query_error(envelope, message))?,
        ))),
        caly_api::RoutingOp::Explain { request } => Ok(Some(OperationResult::RouteExplain(
            app.route_explain(request.clone())
                .map_err(|message| internal_query_error(envelope, message))?,
        ))),
        caly_api::RoutingOp::Validate { profile_id } => {
            Ok(Some(OperationResult::RoutingValidation(
                app.routing_validation(profile_id.clone())
                    .map_err(|message| internal_query_error(envelope, message))?,
            )))
        }
    }
}
