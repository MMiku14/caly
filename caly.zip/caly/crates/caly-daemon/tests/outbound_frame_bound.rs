//! `OVERLOAD_AND_RETRY_MODEL` round-41: the frame cap is enforced on the way **out** too.
//!
//! Round 30 bounded the answers a query assembles (`DiagnosticBudget`) and checked
//! `MAX_FRAME_SIZE_BYTES` on inbound frames, but `encode_raw_json` would still build any size —
//! so a server-side bug could hand the peer a transport refusal where the caller was owed an
//! answer. The server loop now encodes through the bound, and a payload that cannot be a frame
//! is refused before it exists, with the numbers named.

use caly_daemon::{ServerLoop, ServerLoopConfig};

#[test]
fn the_server_loop_refuses_to_build_a_frame_the_peer_must_refuse() {
    let loop_service = ServerLoop::new(ServerLoopConfig::default());
    // Small payloads round-trip as before — the bound is not a new tax on honest answers.
    assert_eq!(
        loop_service
            .probe_json_roundtrip("{\"probe\":true}")
            .as_deref(),
        Ok("{\"probe\":true}")
    );
    let cap = caly_ipc::policy::MAX_FRAME_SIZE_BYTES as usize;
    let over = "x".repeat(cap + 1);
    let error = loop_service
        .probe_json_roundtrip(&over)
        .expect_err("a payload over the negotiated cap must not become a frame");
    assert!(
        error.contains("exceeds MAX_FRAME_SIZE_BYTES"),
        "the refusal must name the rule: {error}"
    );
}
