//! The event **lines** of one job, as a caller reads them — and the bounds on how many of them a
//! single reply may carry.
//!
//! `DiagnosticsOp::FollowJob` returns counts: `log_count: 14`, `warning_count: 8`, a `last_stage`.
//! That is enough to watch progress and not enough to compare two access paths, review an incident,
//! or check that what was masked stayed masked — a run can rename a stage, lose the commit marker, or
//! reorder a warning and leave every count intact (`docs/history/ONBOARDING_NOTES.md §4.50`).
//!
//! `ReadJobEvents` is the query that returns the lines themselves. It renders them with the engine's
//! own renderer, the same one the stream and the support bundle use, so there is one spelling of an
//! event in this codebase rather than three. And it is a *paged* query: `RFC-0002 §9` requires paging
//! or streaming for collections as unbounded as a job log, and `§11.4` forbids answering a query with
//! an oversized inline IPC frame (`docs/history/ONBOARDING_NOTES.md §4.54`).

use caly_api::{
    ApplyRequest, DelayTestRequest, DiagnosticsOp, JobEventsRequest, JobFollowRequest, JobId,
    NodeId, Operation, ProfileId, ProfileOp, ProtocolVersion, ProxyOp, RequestEnvelope, RequestId,
    ResponseEnvelope, Role, TraceId,
};
use caly_common::redact::REDACTED;
use caly_common::Actor;
use caly_daemon::{handle_request, DaemonApp, DaemonBootstrapConfig};

fn daemon(tag: &str) -> DaemonApp {
    DaemonApp::bootstrap(DaemonBootstrapConfig {
        instance_id: tag.to_owned(),
        protocol_version: ProtocolVersion { major: 1, minor: 0 },
        recover_on_start: false,
    })
}

fn envelope(operation: Operation, id: u64) -> RequestEnvelope {
    RequestEnvelope {
        protocol: ProtocolVersion { major: 1, minor: 0 },
        request_id: RequestId(id),
        trace_id: TraceId::new(format!("events-{id}")),
        deadline_ms: None,
        expected_revision: None,
        // `Idempotency::Required` commands are refused without a key (`ADR-037 §2.3`), so the
        // helper mints one per request id: unique per submission, which is exactly what "a
        // different write" means to the dedup window.
        idempotency_key: Some(format!("events-{id}")),
        role: Role::Admin,
        io_budget: None,
        operation,
    }
}

/// One page of one job's window. Everything is explicit here so a test can name the bound it is
/// checking instead of inheriting one it did not choose.
fn page(
    job_id: u64,
    from_event_index: Option<u64>,
    max_lines: Option<u32>,
    max_bytes: Option<u64>,
) -> JobEventsRequest {
    JobEventsRequest {
        job_id: JobId(job_id),
        from_event_index,
        max_lines,
        max_bytes,
    }
}

fn events_request(daemon: &DaemonApp, request: JobEventsRequest) -> ResponseEnvelope {
    let from = request.from_event_index.unwrap_or(0);
    handle_request(
        daemon,
        Actor::Cli,
        &envelope(
            Operation::Diagnostics(DiagnosticsOp::ReadJobEvents { request }),
            10 + from,
        ),
    )
}

fn events_of(daemon: &DaemonApp, job_id: u64, from: Option<u64>) -> ResponseEnvelope {
    events_request(daemon, page(job_id, from, None, None))
}

/// Run one apply, then read its window.
fn applied(tag: &str) -> (DaemonApp, u64) {
    let daemon = daemon(tag);
    let accepted = handle_request(
        &daemon,
        Actor::Cli,
        &envelope(
            Operation::Profile(ProfileOp::Apply {
                request: ApplyRequest {
                    profile_id: ProfileId("demo-tun-profile".to_owned()),
                    dry_run: false,
                    strict: false,
                },
            }),
            1,
        ),
    );
    let job_id = match accepted.result {
        Ok(caly_api::OperationResult::Accepted(accepted)) => accepted.job_id.0,
        other => panic!("expected an accepted apply, got {other:?}"),
    };
    assert_eq!(daemon.drain_engine_once().expect("drain"), 1);
    (daemon, job_id)
}

fn view(response: ResponseEnvelope) -> caly_api::JobEventsView {
    match response.result {
        Ok(caly_api::OperationResult::JobEvents(view)) => view,
        other => panic!("expected a job events view, got {other:?}"),
    }
}

#[test]
fn the_window_lists_the_lines_and_the_counters_agree_with_them() {
    let (daemon, job_id) = applied("events-window");
    let got = view(events_of(&daemon, job_id, None));
    assert_eq!(got.job_id, JobId(job_id));
    assert_eq!(got.state, "completed", "{got:?}");
    assert!(got.events.len() >= 8, "{got:?}");
    // The progression a reviewer looks for, in order.
    let text = got.events.join("\n");
    for marker in [
        "pipeline.resolve profile=demo-tun-profile",
        "capability.validate",
        "effects.prepare.started",
        "apply.plan ",
        "snapshot.committed",
        "[done] Succeeded",
    ] {
        assert!(text.contains(marker), "missing {marker} in:\n{text}");
    }
    assert!(
        text.find("pipeline.resolve").unwrap() < text.find("snapshot.committed").unwrap(),
        "the lines must be oldest first:\n{text}"
    );
    // A full window: nothing dropped, nothing to reset, nothing left out of the page.
    assert_eq!(got.retained_from_event_index, 0, "{got:?}");
    assert!(!got.reset_required, "{got:?}");
    assert_eq!(got.next_event_index, got.events.len() as u64, "{got:?}");
    assert_eq!(got.dropped_event_count(), 0);
    assert_eq!(got.byte_len, text.len() as u64, "{got:?}");
    assert!(!got.is_truncated(), "{got:?}");
    assert!(!got.is_empty());
}

#[test]
fn a_cursor_resumes_where_it_says_instead_of_returning_a_mystery_slice() {
    let (daemon, job_id) = applied("events-cursor");
    let full = view(events_of(&daemon, job_id, None));
    let resumed = view(events_of(&daemon, job_id, Some(3)));
    assert_eq!(
        resumed.events,
        full.events[4..],
        "from_event_index is exclusive, so the caller continues where it stopped"
    );
    assert_eq!(resumed.next_event_index, full.next_event_index);
    assert_eq!(resumed.retained_from_event_index, 0);
    assert!(!resumed.reset_required);

    // A cursor at the end is "nothing new", not "you lost the stream".
    let at_end = view(events_of(&daemon, job_id, Some(full.next_event_index)));
    assert!(at_end.events.is_empty(), "{at_end:?}");
    assert!(!at_end.reset_required, "{at_end:?}");
}

#[test]
fn an_unknown_job_is_the_same_refusal_the_summary_gives() {
    let (daemon, _job_id) = applied("events-missing");
    let response = events_of(&daemon, 4_242, None);
    let ResponseEnvelope {
        result: Err(error), ..
    } = &response
    else {
        panic!("a missing job must be refused, got {:?}", response.result);
    };
    assert_eq!(error.code, caly_api::ErrorCode::Conflict, "{error:?}");
    assert_eq!(error.summary, "no such job: 4242", "{error:?}");
    // Identical wording to `FollowJob`: one answer to one question, from either operation.
    let summary = handle_request(
        &daemon,
        Actor::Cli,
        &envelope(
            Operation::Diagnostics(DiagnosticsOp::FollowJob {
                request: JobFollowRequest {
                    job_id: JobId(4_242),
                    from_event_index: None,
                },
            }),
            11,
        ),
    );
    match summary.result {
        Err(other) => assert_eq!(other.summary, error.summary, "{other:?}"),
        ok => panic!("expected the summary to refuse too, got {ok:?}"),
    }
}

#[test]
fn the_lines_are_masked_because_masking_happened_on_write() {
    // `RFC-0010 §6.1` puts redaction at line construction; this query must not become a second,
    // unmasked exit for the same events. The input here is client-supplied text the worker echoes.
    let daemon = daemon("events-masked");
    let accepted = handle_request(
        &daemon,
        Actor::Cli,
        &envelope(
            Operation::Proxy(ProxyOp::TestDelay {
                request: DelayTestRequest {
                    node_ids: vec![NodeId(
                        "hk?password=hunter2&token=PLAINSECRET99&label=home".to_owned(),
                    )],
                },
            }),
            1,
        ),
    );
    let job_id = match accepted.result {
        Ok(caly_api::OperationResult::Accepted(accepted)) => accepted.job_id.0,
        other => panic!("{other:?}"),
    };
    assert_eq!(daemon.drain_engine_once().expect("drain"), 1);

    let got = view(events_of(&daemon, job_id, None));
    let text = got.events.join("\n");
    assert!(
        !text.contains("hunter2"),
        "leaked through the event view:\n{text}"
    );
    assert!(!text.contains("PLAINSECRET99"), "leaked: {text}");
    assert!(text.contains(REDACTED), "{text}");
    assert!(text.contains("label=home"), "masking deleted data:\n{text}");
}

/// `RFC-0002 §9` makes paging mandatory for a log rather than merely allowed, so a page has to be
/// walkable: a cursor that skipped a line or repeated one leaves a client with a log that reads as
/// complete and is not.
#[test]
fn a_small_page_walks_the_window_and_the_last_page_tells_it_to_stop() {
    let (daemon, job_id) = applied("events-paged");
    let full = view(events_of(&daemon, job_id, None));
    assert!(
        full.events.len() > 4,
        "the fixture must be big enough to page: {:?}",
        full.events.len()
    );

    let mut cursor = None;
    let mut pages = Vec::new();
    let mut seen: Vec<String> = Vec::new();
    loop {
        let reply = view(events_request(&daemon, page(job_id, cursor, Some(2), None)));
        assert!(!reply.reset_required, "{reply:?}");
        assert!(reply.events.len() <= 2, "{reply:?}");
        // The window's own counters describe the window, not the page: they must not move as the
        // caller walks it, or a client cannot tell "end of log" from "end of page".
        assert_eq!(reply.next_event_index, full.next_event_index, "{reply:?}");
        assert_eq!(
            reply.retained_from_event_index, full.retained_from_event_index,
            "{reply:?}"
        );
        // `is_truncated()` is derived from the cursor and the walk below trusts the cursor, so both
        // are read before the reply's lines are moved out of it.
        let next = reply.next_from_event_index;
        assert_eq!(next.is_some(), reply.is_truncated(), "{reply:?}");
        let consumed = seen.len() + reply.events.len();
        assert_eq!(
            next,
            (next.is_some() && consumed > 0).then_some(consumed as u64 - 1),
            "the cursor is the last index this page returned, since the request cursor is exclusive"
        );
        pages.push(reply.events.len());
        seen.extend(reply.events);
        match next {
            Some(next) => cursor = Some(next),
            None => break,
        }
        assert!(pages.len() < 64, "the walk must terminate, got {pages:?}");
    }

    assert_eq!(seen, full.events, "the pages must reassemble the window");
    assert_eq!(pages.iter().sum::<usize>(), full.events.len());
    assert!(pages.iter().all(|count| *count == 2 || *count == 1));
    assert!(*pages.last().unwrap() <= 2);
}

/// The cap is what makes the bound real: a caller that ignores it still cannot get an unbounded
/// reply, and the daemon's published numbers are the ones it honours.
#[test]
fn a_request_that_ignores_the_caps_still_gets_a_bounded_reply() {
    let (daemon, job_id) = applied("events-capped");
    let view_of = |request: JobEventsRequest| view(events_request(&daemon, request));
    let wild = view_of(page(job_id, None, Some(u32::MAX), Some(u64::MAX)));
    assert!(
        wild.events.len() <= caly_daemon::MAX_JOB_EVENT_PAGE_LINES,
        "{wild:?}"
    );
    assert!(
        wild.byte_len <= caly_daemon::MAX_JOB_EVENT_PAGE_BYTES,
        "{wild:?}"
    );
    assert_eq!(wild.byte_len, wild.events.join("\n").len() as u64);
    assert!(
        !wild.is_truncated(),
        "the window is smaller than the cap, so this is not truncation: {wild:?}"
    );

    // A default read is a page, and that page is what the published default says it is.
    let plain = view_of(page(job_id, None, None, None));
    assert!(
        plain.events.len() <= caly_daemon::DEFAULT_JOB_EVENT_PAGE_LINES
            && plain.byte_len <= caly_daemon::DEFAULT_JOB_EVENT_PAGE_BYTES,
        "{plain:?}"
    );
    assert_eq!(
        plain.events, wild.events,
        "both cover the window, so they agree"
    );
    assert_eq!(
        plain.next_from_event_index, wild.next_from_event_index,
        "same window, same verdict on whether more remains"
    );
}

/// A `0` bound is a caller bug. Answering it with the default page would look like a full read to the
/// client, and answering it with an empty page would be a cursor that never advances, so the only
/// honest answer is a refusal that names the field.
#[test]
fn a_zero_bound_is_refused_and_names_the_field() {
    let (daemon, job_id) = applied("events-zero");
    for (field, request) in [
        ("max_lines", page(job_id, None, Some(0), None)),
        ("max_bytes", page(job_id, None, None, Some(0))),
    ] {
        let response = events_request(&daemon, request);
        let ResponseEnvelope {
            result: Err(error), ..
        } = &response
        else {
            panic!("a {field} of 0 must be refused, got {:?}", response.result);
        };
        assert_eq!(error.code, caly_api::ErrorCode::ConfigInvalid, "{error:?}");
        assert_eq!(error.category, caly_api::ErrorCategory::User, "{error:?}");
        assert!(!error.retryable, "retrying a typo is a loop: {error:?}");
        assert!(error.summary.contains(field), "{error:?}");
        // `Ok(None)` used to be how an unhandled operation leaked out; a refusal must not look like it.
        assert!(
            !error.summary.contains("no daemon handler"),
            "a bad request must not be answered as an unimplemented one: {error:?}"
        );
        assert!(
            error
                .remediation
                .as_deref()
                .unwrap_or_default()
                .contains("default page"),
            "{error:?}"
        );
    }
}

/// A refusal keeps its shape whatever the page bound says — the two questions must not be conflated,
/// and the ordering is deliberate: a caller with both a bad bound and a stale job id hears about the
/// bound, because that is the one it can fix without asking for a different job.
#[test]
fn a_bad_bound_on_an_unknown_job_still_refuses_on_the_bound() {
    let (daemon, _job_id) = applied("events-order");
    let response = events_request(&daemon, page(8_811, None, Some(0), None));
    match &response.result {
        Err(error) => {
            assert!(error.summary.contains("max_lines"), "{error:?}");
            assert_eq!(error.code, caly_api::ErrorCode::ConfigInvalid, "{error:?}");
        }
        ok => panic!("expected a refusal, got {ok:?}"),
    }
}

/// A stale cursor is a reset, and a page must not turn it into a fake resume position.
#[test]
fn a_window_smaller_than_its_own_page_is_not_reported_as_truncated() {
    // `from_event_index` past the end: nothing left, nothing to reset, and crucially no cursor to
    // follow, or a client loop would spin on an empty reply forever.
    let (daemon, job_id) = applied("events-end");
    let full = view(events_of(&daemon, job_id, None));
    let at_end = view(events_request(
        &daemon,
        page(job_id, Some(full.next_event_index), Some(4), None),
    ));
    assert!(at_end.events.is_empty(), "{at_end:?}");
    assert!(!at_end.is_truncated(), "{at_end:?}");
    assert_eq!(at_end.next_from_event_index, None, "{at_end:?}");
    assert_eq!(at_end.byte_len, 0, "{at_end:?}");
    assert_eq!(at_end.next_event_index, full.next_event_index);
}
