//! The `calyd` executable, end to end over a real socket (`ROADMAP §1bis.2`: executable 0 → 1).
//!
//! These judges spawn the built binary, read its chosen port from the file it writes, and speak
//! the v0 wire to it: hello → hello_ack, `runtime.status` → a response whose every field is
//! present, an unknown op → a refusal that names it, a request before hello → a refusal, and an
//! over-cap frame → the connection refusing it. The daemon underneath is the real one — durable
//! store, injected clock, session machinery — so what these judges prove is the composition,
//! not a mock of it.

// This file is a process-spawning integration harness: judging the `calyd` binary *is*
// spawning it (`Command::new`), waiting for its port (`Instant::now`), and naming scratch
// paths (`PathBuf`). The workspace bans those symbols to keep the core pure (`ADR-011`);
// the ban's rationale does not reach an E2E harness, and the lift is scoped to this file
// alone — the daemon's own sources keep every ban.
#![allow(clippy::disallowed_methods, clippy::disallowed_types)]

use std::io::{Read, Write};
use std::net::TcpStream;
#[cfg(unix)]
use std::os::unix::net::UnixStream;
use std::path::PathBuf;
use std::process::{Child, Command, Stdio};
use std::time::{Duration, Instant};

const KIND_HELLO: u8 = 1;
const KIND_HELLO_ACK: u8 = 2;
const KIND_REQUEST: u8 = 3;
const KIND_RESPONSE: u8 = 4;
const KIND_REFUSAL: u8 = 5;

struct Daemon {
    child: Child,
    port: u16,
    data_dir: PathBuf,
}

impl Drop for Daemon {
    fn drop(&mut self) {
        let _ = self.child.kill();
        let _ = self.child.wait();
        let _ = std::fs::remove_dir_all(&self.data_dir);
    }
}

fn spawn_daemon(tag: &str) -> Daemon {
    spawn_daemon_with(tag, &[])
}

fn spawn_daemon_with(tag: &str, extra_args: &[&str]) -> Daemon {
    let data_dir = std::env::temp_dir().join(format!(
        "calyd-e2e-{}-{}-{tag}",
        std::process::id(),
        std::time::SystemTime::now()
            .duration_since(std::time::UNIX_EPOCH)
            .expect("clock")
            .as_millis()
    ));
    let port_file = data_dir.with_extension("port");
    std::fs::create_dir_all(&data_dir).expect("scratch dir");
    let child = Command::new(env!("CARGO_BIN_EXE_calyd"))
        .arg("--data-dir")
        .arg(&data_dir)
        .arg("--bind")
        .arg("127.0.0.1:0")
        .arg("--port-file")
        .arg(&port_file)
        .args(extra_args)
        .stdout(Stdio::null())
        .spawn()
        .expect("the calyd binary must be built with the test run");
    // The binary writes the port file as its last startup act, so waiting for it is waiting
    // for "listening" — no sleep-and-hope.
    let deadline = Instant::now() + Duration::from_secs(10);
    let port = loop {
        if let Ok(text) = std::fs::read_to_string(&port_file) {
            break text.trim().parse::<u16>().expect("a port number");
        }
        assert!(
            Instant::now() < deadline,
            "calyd did not report a listening port within 10s"
        );
        std::thread::sleep(Duration::from_millis(25));
    };
    Daemon {
        child,
        port,
        data_dir,
    }
}

fn connect(daemon: &Daemon) -> TcpStream {
    TcpStream::connect(("127.0.0.1", daemon.port)).expect("the daemon is listening")
}

/// Parallel UDS spawn. TCP `--port-file` stays a bare u16 so the existing
/// judges keep parsing; this helper reads `unix:<path>` and never feeds that
/// string to `parse::<u16>`.
#[cfg(unix)]
struct UnixDaemon {
    child: Child,
    path: String,
    data_dir: PathBuf,
}

#[cfg(unix)]
impl Drop for UnixDaemon {
    fn drop(&mut self) {
        let _ = self.child.kill();
        let _ = self.child.wait();
        let _ = std::fs::remove_file(&self.path);
        let _ = std::fs::remove_dir_all(&self.data_dir);
    }
}

#[cfg(unix)]
fn spawn_daemon_unix(tag: &str) -> UnixDaemon {
    let data_dir = std::env::temp_dir().join(format!(
        "calyd-uds-{}-{}-{tag}",
        std::process::id(),
        std::time::SystemTime::now()
            .duration_since(std::time::UNIX_EPOCH)
            .expect("clock")
            .as_millis()
    ));
    let port_file = data_dir.with_extension("port");
    let sock = data_dir.with_extension("sock");
    std::fs::create_dir_all(&data_dir).expect("scratch dir");
    let child = Command::new(env!("CARGO_BIN_EXE_calyd"))
        .arg("--data-dir")
        .arg(&data_dir)
        .arg("--bind")
        .arg(format!("unix:{}", sock.display()))
        .arg("--port-file")
        .arg(&port_file)
        .stdout(Stdio::null())
        .spawn()
        .expect("the calyd binary must be built with the test run");
    let deadline = Instant::now() + Duration::from_secs(10);
    let path = loop {
        if let Ok(text) = std::fs::read_to_string(&port_file) {
            let text = text.trim();
            let rest = text
                .strip_prefix("unix:")
                .unwrap_or_else(|| panic!("UDS port-file must be unix:<path>, got {text:?}"));
            break rest.to_owned();
        }
        assert!(
            Instant::now() < deadline,
            "calyd did not report a unix path within 10s"
        );
        std::thread::sleep(Duration::from_millis(25));
    };
    UnixDaemon {
        child,
        path,
        data_dir,
    }
}

#[cfg(unix)]
fn connect_unix(daemon: &UnixDaemon) -> UnixStream {
    UnixStream::connect(&daemon.path).expect("the daemon is listening on the unix socket")
}

/// Same daemon, but stderr lands in a file the judge can read — the daemon's own connection
/// lifecycle lines are the honest observable for "what did the server do when the client left".
fn spawn_daemon_logged(tag: &str, extra_args: &[&str]) -> (Daemon, PathBuf) {
    let data_dir = std::env::temp_dir().join(format!(
        "calyd-e2e-{}-{}-{tag}",
        std::process::id(),
        std::time::SystemTime::now()
            .duration_since(std::time::UNIX_EPOCH)
            .expect("clock")
            .as_millis()
    ));
    let port_file = data_dir.with_extension("port");
    let stderr_file = data_dir.with_extension("stderr");
    std::fs::create_dir_all(&data_dir).expect("scratch dir");
    let stderr = std::fs::File::create(&stderr_file).expect("stderr file");
    let child = Command::new(env!("CARGO_BIN_EXE_calyd"))
        .arg("--data-dir")
        .arg(&data_dir)
        .arg("--bind")
        .arg("127.0.0.1:0")
        .arg("--port-file")
        .arg(&port_file)
        .args(extra_args)
        .stdout(Stdio::null())
        .stderr(Stdio::from(stderr))
        .spawn()
        .expect("the calyd binary must be built with the test run");
    let deadline = Instant::now() + Duration::from_secs(10);
    let port = loop {
        if let Ok(text) = std::fs::read_to_string(&port_file) {
            break text.trim().parse::<u16>().expect("a port number");
        }
        assert!(
            Instant::now() < deadline,
            "calyd did not report a listening port within 10s"
        );
        std::thread::sleep(Duration::from_millis(25));
    };
    (
        Daemon {
            child,
            port,
            data_dir,
        },
        stderr_file,
    )
}

/// Round 53 made acceptance mean **queued**: the worker thread runs the job on its own tick,
/// so a judge that needs a terminal job waits for the daemon to say so. The daemon's state is
/// the only clock that never lies here — wall-clock sleeps would only re-create the race this
/// helper exists to remove.
fn wait_for_terminal(stream: &mut TcpStream, job_id: u64) -> String {
    let deadline = Instant::now() + Duration::from_secs(10);
    let mut seq = 900u32;
    loop {
        seq += 1;
        send(
            stream,
            KIND_REQUEST,
            &format!("request_id={seq}\ntrace_id=e2e-wait\noperation=jobs.events\njob_id={job_id}"),
        );
        let (kind, body) = recv(stream);
        assert_eq!(
            kind, KIND_RESPONSE,
            "the wait poll is a normal request: {body}"
        );
        let state = field(&body, "state").unwrap_or_default();
        if matches!(
            state.as_str(),
            "completed" | "failed" | "cancelled" | "timedout"
        ) {
            return state;
        }
        assert!(
            Instant::now() < deadline,
            "job {job_id} never reached a terminal state (last state: {state})"
        );
        std::thread::sleep(Duration::from_millis(25));
    }
}

fn escape(value: &str) -> String {
    value
        .replace('%', "%25")
        .replace('=', "%3D")
        .replace('\n', "%0A")
}

/// The record-value escapes (`%`/`=`/newline → `%25`/`%3D`/`%0A`, `%` first so a literal
/// `probe%3Dx` can never masquerade as an escaped `probe=x`; documented in
/// `caly-ipc/src/wire.rs`). This oracle decodes exactly those three and leaves anything
/// else literal — an independent implementation, so a wire that stops escaping (or
/// double-escapes) cannot agree with it by construction.
fn unescape(value: &str) -> String {
    let mut out = String::with_capacity(value.len());
    let mut rest = value;
    while let Some(at) = rest.find('%') {
        out.push_str(&rest[..at]);
        let tail = &rest[at + 1..];
        let (decoded, consumed) = if tail.starts_with("25") {
            ('%', 3)
        } else if tail.starts_with("3D") {
            ('=', 3)
        } else if tail.starts_with("0A") {
            ('\n', 3)
        } else {
            ('%', 1)
        };
        out.push(decoded);
        rest = &tail[consumed - 1..];
    }
    out.push_str(rest);
    out
}

fn send(stream: &mut impl Write, kind: u8, payload: &str) {
    let bytes = payload.as_bytes();
    let mut frame = Vec::with_capacity(5 + bytes.len());
    frame.push(kind);
    frame.extend_from_slice(&(bytes.len() as u32).to_be_bytes());
    frame.extend_from_slice(bytes);
    stream.write_all(&frame).expect("write frame");
    stream.flush().expect("flush frame");
}

fn recv(stream: &mut impl Read) -> (u8, String) {
    let mut head = [0u8; 5];
    stream.read_exact(&mut head).expect("read a frame head");
    let len = u32::from_be_bytes([head[1], head[2], head[3], head[4]]) as usize;
    let mut payload = vec![0u8; len];
    stream
        .read_exact(&mut payload)
        .expect("read a frame payload");
    (head[0], String::from_utf8_lossy(&payload).into_owned())
}

fn records(payload: &str) -> Vec<(String, String)> {
    payload
        .lines()
        .filter_map(|line| {
            line.split_once('=')
                .map(|(k, v)| (k.to_owned(), v.to_owned()))
        })
        .collect()
}

fn field(payload: &str, key: &str) -> Option<String> {
    records(payload)
        .into_iter()
        .find(|(k, _)| k == key)
        .map(|(_, v)| v)
}

fn hello_payload() -> String {
    format!(
        "client_name=e2e\nrole={}\nmajor=1\nminor=0",
        escape("Admin")
    )
}

#[test]
fn hello_then_runtime_status_answers_every_field_over_the_wire() {
    let daemon = spawn_daemon("status");
    let mut stream = connect(&daemon);

    send(&mut stream, KIND_HELLO, &hello_payload());
    let (kind, ack) = recv(&mut stream);
    assert_eq!(kind, KIND_HELLO_ACK, "hello is answered by a hello_ack");
    assert_eq!(field(&ack, "daemon_name").as_deref(), Some("calyd"));
    assert!(
        !field(&ack, "instance_id").unwrap_or_default().is_empty(),
        "the ack names the instance: {ack}"
    );

    send(
        &mut stream,
        KIND_REQUEST,
        "request_id=7\ntrace_id=e2e-status\noperation=runtime.status",
    );
    let (kind, response) = recv(&mut stream);
    assert_eq!(kind, KIND_RESPONSE, "a status query gets a response frame");
    assert_eq!(field(&response, "request_id").as_deref(), Some("7"));
    // Every field present — a client must be able to tell "no active profile" from "the server
    // forgot that field exists". Nine fields, nine lines of assertion intent, one loop.
    for key in [
        "core_running",
        "active_profile",
        "active_core",
        "active_snapshot",
        "last_apply_plan_summary",
        "pending_recovery_decisions",
        "last_recovery_summary",
        "last_failure",
    ] {
        assert!(
            field(&response, key).is_some(),
            "field {key} must be on the wire: {response}"
        );
    }
    assert_eq!(field(&response, "core_running").as_deref(), Some("false"));
    assert_eq!(
        field(&response, "pending_recovery_decisions").as_deref(),
        Some("0")
    );
    assert_eq!(field(&response, "active_profile").as_deref(), Some(""));
}

#[test]
fn an_operation_off_the_v0_wire_is_refused_by_name_not_guessed() {
    let daemon = spawn_daemon("refuse-op");
    let mut stream = connect(&daemon);
    send(&mut stream, KIND_HELLO, &hello_payload());
    let _ = recv(&mut stream);

    send(
        &mut stream,
        KIND_REQUEST,
        "request_id=8\ntrace_id=e2e-refuse\noperation=profile.list",
    );
    let (kind, refusal) = recv(&mut stream);
    assert_eq!(kind, KIND_REFUSAL);
    assert_eq!(field(&refusal, "request_id").as_deref(), Some("8"));
    assert_eq!(field(&refusal, "code").as_deref(), Some("UNSUPPORTED"));
    assert!(
        field(&refusal, "summary")
            .unwrap_or_default()
            .contains("profile.list")
            && field(&refusal, "summary")
                .unwrap_or_default()
                .contains("runtime.status"),
        "the refusal names the op asked for and the one op that exists: {refusal}"
    );
}

#[test]
fn a_request_before_hello_is_refused_not_answered() {
    let daemon = spawn_daemon("refuse-early");
    let mut stream = connect(&daemon);
    send(
        &mut stream,
        KIND_REQUEST,
        "request_id=9\ntrace_id=e2e-early\noperation=runtime.status",
    );
    let (kind, refusal) = recv(&mut stream);
    assert_eq!(kind, KIND_REFUSAL);
    assert_eq!(field(&refusal, "code").as_deref(), Some("HELLO_REQUIRED"));
}

#[test]
fn a_frame_over_the_wire_cap_is_refused_by_the_connection() {
    let daemon = spawn_daemon("cap");
    let mut stream = connect(&daemon);
    send(&mut stream, KIND_HELLO, &hello_payload());
    let _ = recv(&mut stream);

    let cap = caly_ipc::MAX_FRAME_SIZE_BYTES as usize;
    let over = "x".repeat(cap + 1);
    let mut frame = Vec::with_capacity(5 + over.len());
    frame.push(KIND_REQUEST);
    frame.extend_from_slice(&((cap + 1) as u32).to_be_bytes());
    frame.extend_from_slice(over.as_bytes());
    // The honest answer is the **connection ending**: `read_frame` refuses the length before a
    // single payload byte is read, and the error closes the connection. A refusal *frame* here
    // would mean the daemon read a payload it had declared illegal — over-cap bytes swallowed
    // and then answered is the shape this judge exists to forbid.
    let _ = stream.write_all(&frame);
    let mut head = [0u8; 5];
    assert!(
        stream.read_exact(&mut head).is_err(),
        "the connection must end without answering; got kind {}",
        head[0]
    );
}

/// A client that connects and says nothing holds the daemon's only connection slot (v0 serves
/// one at a time), so silence must cost the connection, not the daemon: the read deadline ends
/// it. Found by round 44's falsification, which deadlocked both sides before either had one.
#[test]
fn a_silent_connection_is_ended_by_the_daemon_not_held_forever() {
    let daemon = spawn_daemon("idle");
    let mut stream = connect(&daemon);
    let started = Instant::now();
    let mut head = [0u8; 5];
    let outcome = stream.read_exact(&mut head);
    assert!(
        started.elapsed() < Duration::from_secs(15),
        "the daemon must end an idle connection by itself"
    );
    assert!(outcome.is_err(), "the connection must end, not answer");
}

/// Round 45's capacity judge: a silent client holds one connection and says nothing — a second
/// client must still be served, promptly. Under the one-connection-at-a-time loop this failed
/// by construction (the second client waited out the first's idle timeout); threads make the
/// wedge shape someone else's problem, which is what "never another client's turn" means.
#[test]
fn a_silent_client_never_costs_another_client_its_turn() {
    let daemon = spawn_daemon("concurrent");
    let silent = connect(&daemon);
    let _ = silent; // connects and says nothing, on purpose

    let started = Instant::now();
    let mut stream = connect(&daemon);
    send(&mut stream, KIND_HELLO, &hello_payload());
    let (kind, _ack) = recv(&mut stream);
    assert_eq!(kind, KIND_HELLO_ACK);
    send(
        &mut stream,
        KIND_REQUEST,
        "request_id=21
trace_id=e2e-concurrent
operation=runtime.status",
    );
    let (kind, response) = recv(&mut stream);
    assert_eq!(
        kind, KIND_RESPONSE,
        "served while a silent client holds its own connection"
    );
    assert!(
        field(&response, "request_id").as_deref() == Some("21"),
        "{response}"
    );
    assert!(
        started.elapsed() < Duration::from_secs(3),
        "the second client's answer must not wait out the first client's idle timeout"
    );
}

/// The second wired op: `diagnostics.doctor`, tier lines indexed on the wire. The counts must
/// be the truth about the lines that rode along — a count that disagrees with its own payload
/// is a lying summary, whatever produced it.
#[test]
fn doctor_answers_with_tiers_whose_counts_match_their_lines() {
    let daemon = spawn_daemon("doctor");
    let mut stream = connect(&daemon);
    send(&mut stream, KIND_HELLO, &hello_payload());
    let _ = recv(&mut stream);
    send(
        &mut stream,
        KIND_REQUEST,
        "request_id=22
trace_id=e2e-doctor
operation=diagnostics.doctor",
    );
    let (kind, response) = recv(&mut stream);
    assert_eq!(kind, KIND_RESPONSE, "doctor is on the v0 wire");
    assert_eq!(field(&response, "request_id").as_deref(), Some("22"));
    for key in [
        "summary",
        "truncated",
        "warning_count",
        "error_count",
        "note_count",
    ] {
        assert!(
            field(&response, key).is_some(),
            "{key} must ride: {response}"
        );
    }
    let lines = |prefix: &str| -> usize {
        let count_key = format!("{prefix}_count");
        // `{prefix}_count` is the tier's count, not one of its lines: only indexed keys count.
        records(&response)
            .into_iter()
            .filter(|(k, _)| {
                let indexed = format!("{prefix}_");
                k.starts_with(&indexed)
                    && k[indexed.len()..].chars().all(|ch| ch.is_ascii_digit())
                    && k.as_str() != count_key
            })
            .count()
    };
    for (prefix, count_key) in [
        ("warning", "warning_count"),
        ("error", "error_count"),
        ("note", "note_count"),
    ] {
        let declared: usize = field(&response, count_key)
            .and_then(|v| v.parse().ok())
            .unwrap_or(999);
        assert_eq!(
            lines(prefix),
            declared,
            "{count_key} must equal the {prefix}_* lines on the wire: {response}"
        );
    }
}

/// The third wired op: `profiles.list`. The count must be the truth about the indexed lines
/// (the same doctrine as doctor's tiers), the default profile means the list is never
/// silently empty, and at most one profile claims to be active.
#[test]
fn profiles_list_counts_its_lines_and_never_invents_a_second_active() {
    let daemon = spawn_daemon("profiles");
    let mut stream = connect(&daemon);
    send(&mut stream, KIND_HELLO, &hello_payload());
    let _ = recv(&mut stream);
    send(
        &mut stream,
        KIND_REQUEST,
        "request_id=31\ntrace_id=e2e-profiles\noperation=profiles.list",
    );
    let (kind, response) = recv(&mut stream);
    assert_eq!(kind, KIND_RESPONSE, "profiles.list is on the v0 wire");
    assert_eq!(field(&response, "request_id").as_deref(), Some("31"));
    let declared: usize = field(&response, "profile_count")
        .and_then(|v| v.parse().ok())
        .unwrap_or(999);
    assert!(
        declared >= 1,
        "the default profile means an honestly empty list is still one line: {response}"
    );
    // The count is a claim about the `profile_{i}_id` lines that rode along — and only those
    // (`profile_count` is not a line, and `profile_{i}_label` shares the prefix).
    let ids: Vec<String> = (0..declared)
        .map(|index| field(&response, &format!("profile_{index}_id")).unwrap_or_default())
        .collect();
    assert!(
        ids.iter().all(|id| !id.is_empty()),
        "every counted profile must carry an id: {response}"
    );
    let mut unique = ids.clone();
    unique.sort();
    unique.dedup();
    assert_eq!(
        unique.len(),
        ids.len(),
        "profile ids must be unique: {ids:?}"
    );
    let active: Vec<bool> = (0..declared)
        .map(|index| {
            field(&response, &format!("profile_{index}_active")).as_deref() == Some("true")
        })
        .collect();
    assert!(
        active.iter().filter(|flag| **flag).count() <= 1,
        "at most one profile may claim to be active: {active:?} ({response})"
    );
    for index in 0..declared {
        assert!(
            field(&response, &format!("profile_{index}_label"))
                .map(|label| !label.is_empty())
                .unwrap_or(false),
            "profile_{index}_label must ride along and be non-empty: {response}"
        );
    }
    // And the count is not quietly padded: no line exists past the declared count.
    assert!(
        field(&response, &format!("profile_{declared}_id")).is_none(),
        "a line past profile_count would be an uncounted profile: {response}"
    );
}

/// Doctor's runtime projection is an opt-in record on the wire (round 78): `include_runtime=true`
/// widens the summary to name the runtime snapshot the doctor is looking at; the absent record
/// keeps the door's older shape. The daemon's branch long existed — this is the first test that
/// can reach it over the wire at all.
#[test]
fn a_doctor_request_can_opt_into_the_runtime_projection() {
    let daemon = spawn_daemon("doctor-runtime");
    let mut stream = connect(&daemon);
    send(&mut stream, KIND_HELLO, &hello_payload());
    let _ = recv(&mut stream);
    // Default shape: no record, no projection (the summary stays honest about its scope).
    send(
        &mut stream,
        KIND_REQUEST,
        "request_id=23\ntrace_id=e2e-doctor-plain\noperation=diagnostics.doctor",
    );
    let (kind, response) = recv(&mut stream);
    assert_eq!(kind, KIND_RESPONSE, "doctor is on the v0 wire");
    let plain = field(&response, "summary").unwrap_or_default().to_owned();
    // The oracle's minimal reader does not unescape values (deliberately), so the
    // projection is asserted on escape-free tokens.
    assert!(
        !plain.contains("runtime active_profile"),
        "the default shape must not widen the summary: {plain}"
    );
    // Opt-in shape: the projection rides and names the runtime the doctor saw.
    send(
        &mut stream,
        KIND_REQUEST,
        "request_id=24\ntrace_id=e2e-doctor-rt\noperation=diagnostics.doctor\ninclude_runtime=true",
    );
    let (kind, response) = recv(&mut stream);
    assert_eq!(kind, KIND_RESPONSE, "the opt-in doctor is on the v0 wire");
    assert_eq!(
        field(&response, "request_id").as_deref(),
        Some("24"),
        "each request answered for itself: {response}"
    );
    let summary = field(&response, "summary").unwrap_or_default().to_owned();
    assert!(
        summary.contains("runtime active_profile") && summary.contains("engine_lifecycle"),
        "the opt-in must name the runtime snapshot: {summary}"
    );
}

/// The fourth wired op — the first one that takes a request field. A missing `profile_id` is a
/// refusal that names the field (never a guessed default), a refusal is an answer (the session
/// survives it), and the view that comes back echoes the id it was asked for — the anti-guess
/// judge: answering "default"'s view to a question about "nightshift" is a wrong answer even
/// though both are valid views.
#[test]
fn profiles_get_refuses_a_missing_id_and_echoes_the_one_it_was_asked() {
    let daemon = spawn_daemon("profile-get");
    let mut stream = connect(&daemon);
    send(&mut stream, KIND_HELLO, &hello_payload());
    let _ = recv(&mut stream);
    send(
        &mut stream,
        KIND_REQUEST,
        "request_id=32\ntrace_id=e2e-profile-get\noperation=profiles.get",
    );
    let (kind, refusal_body) = recv(&mut stream);
    assert_eq!(
        kind, KIND_REFUSAL,
        "no profile_id means refusal, not a guess"
    );
    assert_eq!(
        field(&refusal_body, "code").as_deref(),
        Some("USAGE"),
        "{refusal_body}"
    );
    assert!(
        refusal_body.contains("profile_id"),
        "the refusal must name the missing field: {refusal_body}"
    );

    // The session survives a refusal: the same connection answers the next, well-formed ask.
    send(
        &mut stream,
        KIND_REQUEST,
        "request_id=33\ntrace_id=e2e-profile-get\noperation=profiles.get\nprofile_id=nightshift",
    );
    let (kind, response) = recv(&mut stream);
    assert_eq!(
        kind, KIND_RESPONSE,
        "a refusal is an answer, not a disconnect"
    );
    assert_eq!(field(&response, "request_id").as_deref(), Some("33"));
    assert_eq!(
        field(&response, "profile_id").as_deref(),
        Some("nightshift"),
        "the view must echo the id it was asked for, not a default: {response}"
    );
    assert_eq!(
        field(&response, "active").as_deref(),
        Some("false"),
        "nothing was applied, so no profile may claim active: {response}"
    );
    let source_count = field(&response, "source_count")
        .and_then(|v| v.parse::<usize>().ok())
        .unwrap_or(0);
    assert!(
        source_count >= 1,
        "source_count must ride along: {response}"
    );
    assert!(
        field(&response, "core_target")
            .map(|t| !t.is_empty())
            .unwrap_or(false),
        "core_target must ride along (auto when no core is active): {response}"
    );
}

/// Round 44 gave pre-hello silence a deadline; round 45 made connections concurrent; this is
/// the session-active side, with teeth: the session idle deadline is its **own** policy
/// (`--session-idle-ms`, 1.2s here) — if the reap falls back to the 5s hello deadline the
/// socket carried in with it, this judge fails on the clock, which is exactly the mutation a
/// shared constant could never expose (round 45 used one constant for both sides).
#[test]
fn a_quiet_session_is_reaped_at_its_own_deadline_not_the_hello_one() {
    let daemon = spawn_daemon_with("idle-session", &["--session-idle-ms", "1200"]);
    let mut stream = connect(&daemon);
    send(&mut stream, KIND_HELLO, &hello_payload());
    let _ = recv(&mut stream);
    let started = Instant::now();
    stream
        .set_read_timeout(Some(Duration::from_secs(15)))
        .expect("client-side deadline");
    let mut head = [0u8; 5];
    let outcome = stream.read_exact(&mut head);
    assert!(
        outcome.is_err(),
        "the daemon must end a quiet session by itself, not answer it"
    );
    let elapsed = started.elapsed();
    assert!(
        elapsed < Duration::from_millis(2500),
        "the 1.2s session deadline must do the reaping, not the 5s hello deadline: {elapsed:?}"
    );
    assert!(
        elapsed >= Duration::from_millis(1000),
        "a reap this fast is an error close, not the idle deadline: {elapsed:?}"
    );
}

/// The first wired **command**. v0 has no worker thread, so the accepting connection drains the
/// engine inline before the acceptance is written — by the time this judge reads the acceptance,
/// the job must already be terminal, the query surface must reflect it (`runtime.status` names
/// the active profile), and the event count must be the truth about the lines that rode along.
#[test]
fn an_acceptance_means_queued_and_a_stream_watches_the_worker_finish() {
    let daemon = spawn_daemon_with("apply-worker", &["--worker-tick-ms", "800"]);
    let mut stream = connect(&daemon);
    send(&mut stream, KIND_HELLO, &hello_payload());
    let _ = recv(&mut stream);
    send(
        &mut stream,
        KIND_REQUEST,
        "request_id=41\ntrace_id=e2e-apply\noperation=profiles.apply\nprofile_id=demo-tun-profile\nidempotency_key=e2e-apply-1",
    );
    let (kind, accepted) = recv(&mut stream);
    assert_eq!(
        kind, KIND_RESPONSE,
        "profiles.apply is on the v0 wire: {accepted}"
    );
    let job_id: u64 = field(&accepted, "job_id")
        .and_then(|v| v.parse().ok())
        .expect("a numeric job_id on the acceptance");
    assert!(job_id >= 1, "job ids start at 1: {accepted}");
    assert!(
        field(&accepted, "state_revision")
            .and_then(|v| v.parse::<u64>().ok())
            .unwrap_or(0)
            >= 1,
        "the acceptance carries the revision it was accepted at: {accepted}"
    );
    assert!(
        field(&accepted, "estimated_impact")
            .map(|impact| !impact.is_empty())
            .unwrap_or(false),
        "the acceptance carries the estimated impact: {accepted}"
    );

    // Round 53: the worker thread owns the run, and with an 800ms tick the acceptance has not
    // run anything yet. A second connection must catch the job mid-flight: state `accepted`,
    // zero events — the query surface seeing a job that exists but has not happened yet is
    // the new fact this judge exists to hold.
    let mut probe = connect(&daemon);
    send(&mut probe, KIND_HELLO, &hello_payload());
    let _ = recv(&mut probe);
    send(
        &mut probe,
        KIND_REQUEST,
        &format!("request_id=42\ntrace_id=e2e-apply\noperation=jobs.events\njob_id={job_id}"),
    );
    let (kind, events) = recv(&mut probe);
    assert_eq!(
        kind, KIND_RESPONSE,
        "jobs.events is on the v0 wire: {events}"
    );
    assert_eq!(
        field(&events, "state").as_deref(),
        Some("accepted"),
        "right after the acceptance the job is queued, not finished: {events}"
    );
    assert_eq!(
        field(&events, "event_count").as_deref(),
        Some("0"),
        "an unrun job has no events to show: {events}"
    );

    // And the live stream: opened on the unrun job, it must not hand back the events in the
    // same breath — a data frame inside a window far shorter than the tick would mean the
    // daemon drained inline again. Then the worker's tick turns into data, and the end frame
    // carries the verdict.
    send(
        &mut probe,
        KIND_REQUEST,
        &format!(
            "request_id=43\ntrace_id=e2e-apply\noperation=jobs.follow-stream\njob_id={job_id}"
        ),
    );
    let (kind, opened) = recv(&mut probe);
    assert_eq!(
        kind, KIND_RESPONSE,
        "the stream opens on a queued job: {opened}"
    );
    assert_eq!(field(&opened, "resumed").as_deref(), Some("false"));
    probe
        .set_read_timeout(Some(Duration::from_millis(300)))
        .expect("quiet window timeout");
    match probe.read(&mut [0u8; 1]) {
        Ok(0) => panic!("the stream closed before any data frame"),
        Ok(_) => panic!(
            "a frame arrived inside the 300ms quiet window of an 800ms tick: \
             the worker does not own the run"
        ),
        Err(ref error)
            if error.kind() == std::io::ErrorKind::WouldBlock
                || error.kind() == std::io::ErrorKind::TimedOut => {}
        Err(error) => panic!("unexpected error in the quiet window: {error}"),
    }
    probe
        .set_read_timeout(Some(Duration::from_secs(10)))
        .expect("stream timeout");
    let (kind, data) = recv(&mut probe);
    assert_eq!(
        kind, KIND_STREAM_DATA,
        "the worker's tick arrives as data: {data}"
    );
    assert!(
        field(&data, "event_count")
            .and_then(|v| v.parse::<usize>().ok())
            .unwrap_or(0)
            >= 1,
        "the live delta carries the events that did not exist at open: {data}"
    );
    let (kind, end) = recv(&mut probe);
    assert_eq!(kind, KIND_STREAM_END, "the stream ends: {end}");
    assert_eq!(
        field(&end, "outcome").as_deref(),
        Some("Succeeded"),
        "{end}"
    );

    // And once the worker has finished it, the query surface reflects the command.
    send(
        &mut stream,
        KIND_REQUEST,
        "request_id=44\ntrace_id=e2e-apply\noperation=runtime.status",
    );
    let (kind, status) = recv(&mut stream);
    assert_eq!(kind, KIND_RESPONSE);
    assert_eq!(
        field(&status, "active_profile").as_deref(),
        Some("demo-tun-profile"),
        "the command path must be visible from the query path: {status}"
    );
}

/// `ADR-037` at the wire: no idempotency key, no write — and the refusal must name the key,
/// because "the daemon will not derive one for you" is the sentence a retrying caller needs.
#[test]
fn an_apply_without_an_idempotency_key_is_refused_by_name() {
    let daemon = spawn_daemon("apply-nokey");
    let mut stream = connect(&daemon);
    send(&mut stream, KIND_HELLO, &hello_payload());
    let _ = recv(&mut stream);
    send(
        &mut stream,
        KIND_REQUEST,
        "request_id=44\ntrace_id=e2e-apply-nokey\noperation=profiles.apply\nprofile_id=demo-tun-profile",
    );
    let (kind, refusal) = recv(&mut stream);
    assert_eq!(
        kind, KIND_REFUSAL,
        "no key means refusal, not a derived key"
    );
    assert!(
        refusal.contains("idempotency_key"),
        "the refusal must name the idempotency key: {refusal}"
    );
}

/// Same key, same job — not a second write. The replay must answer with the **same** job id
/// (`ADR-037`), and a fresh key must be a fresh job; anything else turns every retry into a
/// second deployment.
#[test]
fn the_same_idempotency_key_replays_the_same_job_not_a_new_one() {
    let daemon = spawn_daemon("apply-replay");
    let mut stream = connect(&daemon);
    send(&mut stream, KIND_HELLO, &hello_payload());
    let _ = recv(&mut stream);
    let ask = |stream: &mut TcpStream, request_id: u8, key: &str| {
        send(
            stream,
            KIND_REQUEST,
            &format!(
                "request_id={request_id}\ntrace_id=e2e-replay\noperation=profiles.apply\nprofile_id=demo-tun-profile\nidempotency_key={key}"
            ),
        );
        let (kind, body) = recv(stream);
        assert_eq!(kind, KIND_RESPONSE, "{body}");
        field(&body, "job_id").unwrap_or_default()
    };
    let first = ask(&mut stream, 45, "e2e-replay-key");
    let replay = ask(&mut stream, 46, "e2e-replay-key");
    let fresh = ask(&mut stream, 47, "e2e-replay-other");
    assert_eq!(
        first, replay,
        "the same idempotency key must replay the same job id"
    );
    assert_ne!(
        first, fresh,
        "a fresh key is a fresh logical write, so a fresh job"
    );
}

/// Two ops looking at the same job must agree with each other: `jobs.follow`'s summary and
/// `jobs.events`'s page are different facets of one projection, so the summary's `event_count`
/// must equal the unpaged events count, the state must be terminal once the worker has run the
/// job, and the stage must be the snapshot commit. An unknown job is a refusal that says so —
/// never a made-up summary.
#[test]
fn the_follow_summary_agrees_with_the_events_page() {
    let daemon = spawn_daemon("follow");
    let mut stream = connect(&daemon);
    send(&mut stream, KIND_HELLO, &hello_payload());
    let _ = recv(&mut stream);
    send(
        &mut stream,
        KIND_REQUEST,
        "request_id=51\ntrace_id=e2e-follow\noperation=profiles.apply\nprofile_id=demo-tun-profile\nidempotency_key=e2e-follow-1",
    );
    let (kind, accepted) = recv(&mut stream);
    assert_eq!(kind, KIND_RESPONSE, "{accepted}");
    let job_id: u64 = field(&accepted, "job_id")
        .and_then(|v| v.parse().ok())
        .expect("job id");
    wait_for_terminal(&mut stream, job_id);

    send(
        &mut stream,
        KIND_REQUEST,
        &format!("request_id=52\ntrace_id=e2e-follow\noperation=jobs.follow\njob_id={job_id}"),
    );
    let (kind, summary) = recv(&mut stream);
    assert_eq!(
        kind, KIND_RESPONSE,
        "jobs.follow is on the v0 wire: {summary}"
    );
    assert_eq!(
        field(&summary, "state").as_deref(),
        Some("completed"),
        "{summary}"
    );
    assert!(
        field(&summary, "last_stage")
            .map(|stage| stage.starts_with("snapshot.committed"))
            .unwrap_or(false),
        "last_stage must be the snapshot commit: {summary}"
    );
    assert_eq!(
        field(&summary, "failure_code").as_deref(),
        Some(""),
        "{summary}"
    );
    assert_eq!(
        field(&summary, "failure_summary").as_deref(),
        Some(""),
        "{summary}"
    );
    assert_eq!(
        field(&summary, "reset_required").as_deref(),
        Some("false"),
        "{summary}"
    );

    send(
        &mut stream,
        KIND_REQUEST,
        &format!("request_id=53\ntrace_id=e2e-follow\noperation=jobs.events\njob_id={job_id}"),
    );
    let (kind, events) = recv(&mut stream);
    assert_eq!(kind, KIND_RESPONSE);
    assert_eq!(
        field(&summary, "event_count"),
        field(&events, "event_count"),
        "follow's event_count and the events page's count are one fact, not two"
    );

    send(
        &mut stream,
        KIND_REQUEST,
        "request_id=54\ntrace_id=e2e-follow\noperation=jobs.follow\njob_id=999999",
    );
    let (kind, refusal) = recv(&mut stream);
    assert_eq!(
        kind, KIND_REFUSAL,
        "an unknown job is a refusal that says so, not a made-up summary: {refusal}"
    );
    assert!(
        refusal.contains("999999") || refusal.to_lowercase().contains("job"),
        "the refusal must name what was not found: {refusal}"
    );
}

/// A rollback that names a snapshot rolls back to **that** snapshot — the engine records
/// `target=<id>` in the job's own event lines. Swallowing the record (always the last-known-
/// good) is the guessed-default mutation this judge exists to bite.
#[test]
fn rollback_points_at_the_named_snapshot_not_the_last_known_good() {
    let daemon = spawn_daemon("rollback");
    let mut stream = connect(&daemon);
    send(&mut stream, KIND_HELLO, &hello_payload());
    let _ = recv(&mut stream);
    let apply = |stream: &mut TcpStream, request_id: u8, profile: &str, key: &str| {
        send(
            stream,
            KIND_REQUEST,
            &format!(
                "request_id={request_id}\ntrace_id=e2e-rollback\noperation=profiles.apply\nprofile_id={profile}\nidempotency_key={key}"
            ),
        );
        let (kind, body) = recv(stream);
        assert_eq!(kind, KIND_RESPONSE, "{body}");
        let job_id: u64 = field(&body, "job_id")
            .and_then(|v| v.parse().ok())
            .expect("job id");
        // The snapshot this apply publishes is what the next line reads back; the worker
        // owns the run, so the read waits for the job to finish — not for luck.
        wait_for_terminal(stream, job_id);
    };
    let active_snapshot = |stream: &mut TcpStream, request_id: u8| {
        send(
            stream,
            KIND_REQUEST,
            &format!("request_id={request_id}\ntrace_id=e2e-rollback\noperation=runtime.status"),
        );
        let (kind, status) = recv(stream);
        assert_eq!(kind, KIND_RESPONSE);
        field(&status, "active_snapshot").unwrap_or_default()
    };
    // Two different profiles publish two different snapshots (the same profile twice would
    // publish the same revision id twice — the id is the content, not the attempt).
    apply(&mut stream, 61, "demo-tun-profile", "e2e-rb-1");
    let first = active_snapshot(&mut stream, 62);
    apply(&mut stream, 63, "nightshift", "e2e-rb-2");
    let second = active_snapshot(&mut stream, 64);
    assert!(!first.is_empty() && !second.is_empty());
    assert_ne!(first, second, "two profiles publish two snapshots");

    send(
        &mut stream,
        KIND_REQUEST,
        &format!(
            "request_id=65\ntrace_id=e2e-rollback\noperation=profiles.rollback\nsnapshot_id={first}\nidempotency_key=e2e-rb-3"
        ),
    );
    let (kind, accepted) = recv(&mut stream);
    assert_eq!(
        kind, KIND_RESPONSE,
        "profiles.rollback is on the wire: {accepted}"
    );
    let job_id: u64 = field(&accepted, "job_id")
        .and_then(|v| v.parse().ok())
        .expect("rollback job id");
    wait_for_terminal(&mut stream, job_id);

    send(
        &mut stream,
        KIND_REQUEST,
        &format!("request_id=66\ntrace_id=e2e-rollback\noperation=jobs.events\njob_id={job_id}"),
    );
    let (kind, events) = recv(&mut stream);
    assert_eq!(kind, KIND_RESPONSE);
    let count: usize = field(&events, "event_count")
        .and_then(|v| v.parse().ok())
        .unwrap_or(0);
    // Event lines ride the wire value-escaped (`=`→`%3D`), so the judge unescapes them with its
    // own reader before matching — an oracle must implement the documented format, not skip the
    // half it finds inconvenient (round 45's lesson, applied from the start this time).
    let unescape = |value: &str| -> String {
        let mut out = String::new();
        let mut rest = value;
        while let Some(at) = rest.find('%') {
            out.push_str(&rest[..at]);
            let tail = &rest[at + 1..];
            if let Some(next) = tail.strip_prefix("25") {
                out.push('%');
                rest = next;
            } else if let Some(next) = tail.strip_prefix("3D") {
                out.push('=');
                rest = next;
            } else if let Some(next) = tail.strip_prefix("0A") {
                out.push('\n');
                rest = next;
            } else {
                out.push('%');
                rest = tail;
            }
        }
        out.push_str(rest);
        out
    };
    let lines: Vec<String> = (0..count)
        .map(|index| unescape(&field(&events, &format!("event_{index}")).unwrap_or_default()))
        .collect();
    assert!(
        lines
            .iter()
            .any(|line| line.contains(&format!("target={first}"))),
        "the rollback job must record the snapshot it actually used: {lines:?}"
    );
    assert!(
        !lines
            .iter()
            .any(|line| line.contains(&format!("target={second}"))),
        "a named rollback must not quietly use the last-known-good instead: {lines:?}"
    );
}

/// The second wired command inherits the first one's rules: no key, no write — and the same
/// key replays the same job id (`ADR-037`).
#[test]
fn rollback_without_a_key_is_refused_and_a_replay_reuses_the_job() {
    let daemon = spawn_daemon("rollback-key");
    let mut stream = connect(&daemon);
    send(&mut stream, KIND_HELLO, &hello_payload());
    let _ = recv(&mut stream);
    send(
        &mut stream,
        KIND_REQUEST,
        "request_id=67\ntrace_id=e2e-rb-key\noperation=profiles.rollback",
    );
    let (kind, refusal) = recv(&mut stream);
    assert_eq!(
        kind, KIND_REFUSAL,
        "no key means refusal, not a derived key"
    );
    assert!(
        refusal.contains("idempotency_key"),
        "the refusal must name the key: {refusal}"
    );

    send(
        &mut stream,
        KIND_REQUEST,
        "request_id=68\ntrace_id=e2e-rb-key\noperation=profiles.apply\nprofile_id=demo-tun-profile\nidempotency_key=e2e-rb-key-apply",
    );
    let _ = recv(&mut stream);
    let rollback = |stream: &mut TcpStream, request_id: u8, key: &str| {
        send(
            stream,
            KIND_REQUEST,
            &format!(
                "request_id={request_id}\ntrace_id=e2e-rb-key\noperation=profiles.rollback\nidempotency_key={key}"
            ),
        );
        let (kind, body) = recv(stream);
        assert_eq!(kind, KIND_RESPONSE, "{body}");
        field(&body, "job_id").unwrap_or_default()
    };
    let first = rollback(&mut stream, 69, "e2e-rb-key-r");
    let replay = rollback(&mut stream, 70, "e2e-rb-key-r");
    assert_eq!(first, replay, "the same key replays the same rollback job");
    assert!(!first.is_empty());
}

/// A plan is a query: asking twice must change nothing. Everything except the live clock
/// reading (`now_unix_ms`, and the `now=` inside `last_run`) must be identical across two
/// answers — and the clock must say which clock it is (`ADR-038 §3`: the source is part of
/// the answer, because file dates and a deterministic stand-in cannot be compared). The
/// collect counts are checkable claims about their indexed lines, as everywhere else.
#[test]
fn a_gc_plan_asked_twice_changes_nothing_but_the_clock() {
    let daemon = spawn_daemon("gc-plan");
    let mut stream = connect(&daemon);
    send(&mut stream, KIND_HELLO, &hello_payload());
    let _ = recv(&mut stream);
    send(
        &mut stream,
        KIND_REQUEST,
        "request_id=81\ntrace_id=e2e-gc\noperation=profiles.apply\nprofile_id=demo-tun-profile\nidempotency_key=e2e-gc-setup",
    );
    let _ = recv(&mut stream);
    let ask = |stream: &mut TcpStream, request_id: u8| {
        send(
            stream,
            KIND_REQUEST,
            &format!("request_id={request_id}\ntrace_id=e2e-gc\noperation=system.gc-plan"),
        );
        let (kind, body) = recv(stream);
        assert_eq!(kind, KIND_RESPONSE, "{body}");
        body
    };
    let first = ask(&mut stream, 82);
    let second = ask(&mut stream, 83);

    assert_eq!(
        field(&first, "now_source"),
        field(&second, "now_source"),
        "the clock source is part of the answer"
    );
    assert_eq!(
        field(&first, "now_source").as_deref(),
        Some("storage-clock"),
        "the plan must say which clock it used (ADR-038 §3): {first}"
    );
    for key in [
        "grace_period_ms",
        "max_deletions",
        "objects_total",
        "snapshots_total",
        "revisions_total",
        "unfinished_journals",
        "collect_count",
        "retained_total",
        "content_total",
        "gap_count",
        "would_run",
        "last_run",
    ] {
        assert_eq!(
            field(&first, key),
            field(&second, key),
            "a query asked twice must answer twice the same: {key}"
        );
    }
    for prefix in ["collect", "orphan_collect"] {
        let count_key = format!("{prefix}_count");
        let declared: usize = field(&first, &count_key)
            .and_then(|v| v.parse().ok())
            .unwrap_or(999);
        let lines = records(&first)
            .into_iter()
            .filter(|(k, _)| {
                let indexed = format!("{prefix}_");
                k.starts_with(&indexed) && k[indexed.len()..].chars().all(|ch| ch.is_ascii_digit())
            })
            .count();
        assert_eq!(
            lines, declared,
            "{count_key} must equal the {prefix}_* lines: {first}"
        );
    }
}

/// The maintenance command inherits every command rule: keyed (`Required` — a retried cycle
/// must not sweep twice), replayed by key, and **bounded before a job exists** — a
/// `max_deletions=0` refusal happens at the door, leaves no job behind, and changes nothing a
/// plan can see. The refused-for-safety path inside the worker reports a failed job, never a
/// green row; the door refusal here is the same honesty one step earlier.
#[test]
fn a_gc_command_is_keyed_bounded_at_the_door_and_replays() {
    let daemon = spawn_daemon("gc");
    let mut stream = connect(&daemon);
    send(&mut stream, KIND_HELLO, &hello_payload());
    let _ = recv(&mut stream);
    send(
        &mut stream,
        KIND_REQUEST,
        "request_id=84\ntrace_id=e2e-gc2\noperation=profiles.apply\nprofile_id=demo-tun-profile\nidempotency_key=e2e-gc2-setup",
    );
    let _ = recv(&mut stream);

    send(
        &mut stream,
        KIND_REQUEST,
        "request_id=85\ntrace_id=e2e-gc2\noperation=system.gc",
    );
    let (kind, refusal) = recv(&mut stream);
    assert_eq!(kind, KIND_REFUSAL, "no key, no sweep: {refusal}");
    assert!(refusal.contains("idempotency_key"), "{refusal}");

    send(
        &mut stream,
        KIND_REQUEST,
        "request_id=86\ntrace_id=e2e-gc2\noperation=system.gc\nidempotency_key=e2e-gc-run\nmax_deletions=0",
    );
    let (kind, refusal) = recv(&mut stream);
    assert_eq!(
        kind, KIND_REFUSAL,
        "max_deletions=0 is a bounds refusal, not a job: {refusal}"
    );
    assert!(
        refusal.contains("max_deletions")
            && field(&refusal, "code").as_deref() == Some("CONFIG_INVALID"),
        "the refusal names the bound and the code: {refusal}"
    );

    let run = |stream: &mut TcpStream, request_id: u8| {
        send(
            stream,
            KIND_REQUEST,
            &format!(
                "request_id={request_id}\ntrace_id=e2e-gc2\noperation=system.gc\nidempotency_key=e2e-gc-run"
            ),
        );
        let (kind, body) = recv(stream);
        assert_eq!(kind, KIND_RESPONSE, "{body}");
        field(&body, "job_id").unwrap_or_default()
    };
    let first = run(&mut stream, 87);
    let replay = run(&mut stream, 88);
    assert_eq!(first, replay, "the same key replays the same sweep");
    wait_for_terminal(&mut stream, first.parse::<u64>().expect("numeric job id"));

    // The cycle left its record where the next plan will show it.
    send(
        &mut stream,
        KIND_REQUEST,
        "request_id=89\ntrace_id=e2e-gc2\noperation=system.gc-plan",
    );
    let (kind, plan) = recv(&mut stream);
    assert_eq!(kind, KIND_RESPONSE);
    // `last_run`'s value rides escaped (`deleted%3D0`), like every record value.
    let last_run = field(&plan, "last_run").unwrap_or_default();
    let last_run = {
        let mut out = String::new();
        let mut rest = last_run.as_str();
        while let Some(at) = rest.find('%') {
            out.push_str(&rest[..at]);
            let tail = &rest[at + 1..];
            if let Some(next) = tail.strip_prefix("25") {
                out.push('%');
                rest = next;
            } else if let Some(next) = tail.strip_prefix("3D") {
                out.push('=');
                rest = next;
            } else if let Some(next) = tail.strip_prefix("0A") {
                out.push('\n');
                rest = next;
            } else {
                out.push('%');
                rest = tail;
            }
        }
        out.push_str(rest);
        out
    };
    assert!(
        last_run.contains("gc cycle") && last_run.contains("deleted="),
        "a run cycle is Some(...) — different from never having run: {plan}"
    );
}

/// The bundle pair: an export whose key is optional (`Idempotency::Optional` — re-exporting is
/// never a second destructive write), a digest reported on the job's own event lines, and a
/// read that echoes the digest, verifies it (content anchor == digest), reports its own
/// bounds (`truncated` only when `max_bytes` cut it), and refuses a digest that is not a
/// bundle rather than reading "whatever digest you passed".
#[test]
fn a_bundle_export_reports_its_digest_and_reads_back_honestly() {
    let daemon = spawn_daemon("bundle");
    let mut stream = connect(&daemon);
    send(&mut stream, KIND_HELLO, &hello_payload());
    let _ = recv(&mut stream);
    send(
        &mut stream,
        KIND_REQUEST,
        "request_id=91\ntrace_id=e2e-bundle\noperation=diagnostics.support-bundle",
    );
    let (kind, accepted) = recv(&mut stream);
    assert_eq!(
        kind, KIND_RESPONSE,
        "a bundle needs no key (Idempotency::Optional): {accepted}"
    );
    let job_id: u64 = field(&accepted, "job_id")
        .and_then(|v| v.parse().ok())
        .expect("bundle job id");
    wait_for_terminal(&mut stream, job_id);

    send(
        &mut stream,
        KIND_REQUEST,
        &format!("request_id=92\ntrace_id=e2e-bundle\noperation=jobs.events\njob_id={job_id}"),
    );
    let (kind, events) = recv(&mut stream);
    assert_eq!(kind, KIND_RESPONSE);
    let count: usize = field(&events, "event_count")
        .and_then(|v| v.parse().ok())
        .unwrap_or(0);
    let unescape = |value: &str| -> String {
        let mut out = String::new();
        let mut rest = value;
        while let Some(at) = rest.find('%') {
            out.push_str(&rest[..at]);
            let tail = &rest[at + 1..];
            if let Some(next) = tail.strip_prefix("25") {
                out.push('%');
                rest = next;
            } else if let Some(next) = tail.strip_prefix("3D") {
                out.push('=');
                rest = next;
            } else if let Some(next) = tail.strip_prefix("0A") {
                out.push('\n');
                rest = next;
            } else {
                out.push('%');
                rest = tail;
            }
        }
        out.push_str(rest);
        out
    };
    let digest = (0..count)
        .filter_map(|index| {
            let line = unescape(&field(&events, &format!("event_{index}")).unwrap_or_default());
            // The event line spells it `object=sha256:...`; take the digest, not the label.
            line.split_whitespace()
                .find(|token| token.contains("sha256:"))
                .map(|token| {
                    token
                        .split_once('=')
                        .map(|(_, digest)| digest)
                        .unwrap_or(token)
                        .to_owned()
                })
        })
        .next()
        .expect("the bundle job reports its digest on the event lines");

    send(
        &mut stream,
        KIND_REQUEST,
        &format!(
            "request_id=93\ntrace_id=e2e-bundle\noperation=diagnostics.support-bundle-read\ndigest={digest}"
        ),
    );
    let (kind, bundle) = recv(&mut stream);
    assert_eq!(kind, KIND_RESPONSE, "{bundle}");
    assert_eq!(field(&bundle, "digest").as_deref(), Some(digest.as_str()));
    assert_eq!(
        field(&bundle, "content_sha256"),
        Some(digest.clone()),
        "a bundle is addressed by the digest of its own content"
    );
    assert_eq!(field(&bundle, "truncated").as_deref(), Some("false"));
    assert!(
        field(&bundle, "byte_len")
            .and_then(|v| v.parse::<u64>().ok())
            .unwrap_or(0)
            > 0,
        "a bundle carries bytes: {bundle}"
    );

    send(
        &mut stream,
        KIND_REQUEST,
        &format!(
            "request_id=94\ntrace_id=e2e-bundle\noperation=diagnostics.support-bundle-read\ndigest={digest}\nmax_bytes=100"
        ),
    );
    let (kind, capped) = recv(&mut stream);
    assert_eq!(kind, KIND_RESPONSE);
    assert_eq!(field(&capped, "truncated").as_deref(), Some("true"));
    assert_eq!(field(&capped, "byte_len").as_deref(), Some("100"));

    send(
        &mut stream,
        KIND_REQUEST,
        "request_id=95\ntrace_id=e2e-bundle\noperation=diagnostics.support-bundle-read\ndigest=sha256:0000000000000000000000000000000000000000000000000000000000000000",
    );
    let (kind, refusal) = recv(&mut stream);
    assert_eq!(
        kind, KIND_REFUSAL,
        "a digest that is not a bundle is a refusal, not a read: {refusal}"
    );
}

// ---- The negotiated JSON payload encoding (round 50, `ADR-034`) ----
//
// This harness keeps its own tiny JSON reader as an independent oracle — the same discipline
// as the records readers above: two implementations agreeing is evidence, one implementation
// round-tripping itself is not. It parses exactly what the daemon is allowed to emit: one flat
// object with string values.
fn oracle_json_object(payload: &str) -> Vec<(String, String)> {
    let chars: Vec<char> = payload.chars().collect();
    let mut at = 0usize;
    let mut out = Vec::new();
    let skip = |at: &mut usize| {
        while *at < chars.len() && chars[*at].is_ascii_whitespace() {
            *at += 1;
        }
    };
    let string = |at: &mut usize| -> String {
        assert_eq!(
            chars[*at], '"',
            "oracle: expected a string at {at}: {payload}"
        );
        *at += 1;
        let mut value = String::new();
        while chars[*at] != '"' {
            if chars[*at] == '\\' {
                *at += 1;
                match chars[*at] {
                    'n' => value.push('\n'),
                    'r' => value.push('\r'),
                    't' => value.push('\t'),
                    '"' => value.push('"'),
                    '\\' => value.push('\\'),
                    other => panic!("oracle: unhandled escape \\{other}"),
                }
            } else {
                value.push(chars[*at]);
            }
            *at += 1;
        }
        *at += 1;
        value
    };
    skip(&mut at);
    assert_eq!(chars[at], '{', "oracle: expected '{{': {payload}");
    at += 1;
    loop {
        skip(&mut at);
        if chars[at] == '}' {
            break;
        }
        if !out.is_empty() {
            assert_eq!(chars[at], ',', "oracle: expected ',': {payload}");
            at += 1;
            skip(&mut at);
        }
        let key = string(&mut at);
        skip(&mut at);
        assert_eq!(chars[at], ':', "oracle: expected ':': {payload}");
        at += 1;
        skip(&mut at);
        let value = string(&mut at);
        out.push((key, value));
    }
    out
}

/// **The encoding changes how a fact is written, never which facts exist.** Two sessions — one
/// records, one negotiated JSON — ask the same op; the key→value maps must be equal. The JSON
/// session's handshake frames are still records: the meta-language does not change with the
/// payload encoding.
#[test]
fn a_json_session_answers_the_same_facts_as_a_records_session() {
    let daemon = spawn_daemon("json-parity");
    let mut json_stream = connect(&daemon);
    send(
        &mut json_stream,
        KIND_HELLO,
        "client_name=e2e\nrole=Admin\nmajor=1\nminor=0\nencoding=json",
    );
    let (ack_kind, ack_body) = recv(&mut json_stream);
    assert_eq!(ack_kind, KIND_HELLO_ACK);
    assert!(
        ack_body.contains("daemon_name="),
        "the handshake stays records in every encoding: {ack_body}"
    );

    // One session, one encoding: the request rides as JSON too — the client negotiated it.
    send(
        &mut json_stream,
        KIND_REQUEST,
        "{\"request_id\":\"101\",\"trace_id\":\"e2e-json\",\"operation\":\"profiles.list\"}",
    );
    let (kind, json_payload) = recv(&mut json_stream);
    assert_eq!(kind, KIND_RESPONSE);
    assert!(
        json_payload.starts_with('{'),
        "a JSON session answers JSON: {json_payload}"
    );
    let json_facts = oracle_json_object(&json_payload);

    let mut records_stream = connect(&daemon);
    send(&mut records_stream, KIND_HELLO, &hello_payload());
    let _ = recv(&mut records_stream);
    send(
        &mut records_stream,
        KIND_REQUEST,
        "request_id=102\ntrace_id=e2e-json\noperation=profiles.list",
    );
    let (kind, records_payload) = recv(&mut records_stream);
    assert_eq!(kind, KIND_RESPONSE);
    let records_facts = records(&records_payload);

    // `request_id` names the conversation, not the fact: each session asked with its own.
    let as_map = |facts: Vec<(String, String)>| -> Vec<(String, String)> {
        let mut map: Vec<(String, String)> = Vec::new();
        for (key, value) in facts {
            if key != "request_id" && !map.iter().any(|(k, _)| *k == key) {
                map.push((key, value));
            }
        }
        map.sort();
        map
    };
    assert_eq!(
        as_map(json_facts.clone()),
        as_map(records_facts),
        "the facts must not change with the encoding:\njson:    {json_payload}\nrecords: {records_payload}"
    );
    // And the indexed-line doctrine survives the encoding: the count is a claim about lines.
    let find = |facts: &[(String, String)], key: &str| {
        facts
            .iter()
            .find(|(k, _)| k == key)
            .map(|(_, v)| v.clone())
            .unwrap_or_default()
    };
    let declared: usize = find(&json_facts, "profile_count").parse().unwrap_or(999);
    for index in 0..declared {
        assert!(
            find(&json_facts, &format!("profile_{index}_id")) != String::new(),
            "the indexed lines ride the JSON object like they ride the records"
        );
    }
}

/// A payload that is not a JSON object is refused by name — never repaired into a nearby
/// guess — and the refusal itself rides in JSON, because one session has one encoding. The
/// session survives the refusal.
#[test]
fn a_malformed_json_payload_is_refused_in_json_and_the_session_survives() {
    let daemon = spawn_daemon("json-malformed");
    let mut stream = connect(&daemon);
    send(
        &mut stream,
        KIND_HELLO,
        "client_name=e2e\nrole=Admin\nmajor=1\nminor=0\nencoding=json",
    );
    let _ = recv(&mut stream);
    send(&mut stream, KIND_REQUEST, "definitely not json");
    let (kind, refusal) = recv(&mut stream);
    assert_eq!(kind, KIND_REFUSAL, "{refusal}");
    assert!(
        refusal.starts_with('{'),
        "the refusal rides in JSON too: {refusal}"
    );
    let facts = oracle_json_object(&refusal);
    let code = facts
        .iter()
        .find(|(k, _)| k == "code")
        .map(|(_, v)| v.clone())
        .unwrap_or_default();
    assert_eq!(code, "USAGE", "{refusal}");
    assert!(
        refusal.contains("JSON"),
        "the refusal must name the problem: {refusal}"
    );

    send(
        &mut stream,
        KIND_REQUEST,
        "{\"request_id\":\"103\",\"trace_id\":\"e2e\",\"operation\":\"runtime.status\"}",
    );
    let (kind, response) = recv(&mut stream);
    assert_eq!(
        kind, KIND_RESPONSE,
        "a refusal is an answer; the session survives it: {response}"
    );
    assert!(response.contains("\"core_running\""), "{response}");
}

/// An encoding the daemon does not know is a handshake refusal that names it — the one frame
/// that still rides as records, because a value the daemon cannot parse is not a value it may
/// guess the meaning of.
#[test]
fn an_unknown_encoding_is_refused_by_name_at_the_handshake() {
    let daemon = spawn_daemon("json-unknown");
    let mut stream = connect(&daemon);
    send(
        &mut stream,
        KIND_HELLO,
        "client_name=e2e\nrole=Admin\nmajor=1\nminor=0\nencoding=cbor",
    );
    let (kind, refusal) = recv(&mut stream);
    assert_eq!(kind, KIND_REFUSAL, "{refusal}");
    assert!(
        refusal.contains("cbor"),
        "the refusal names the value: {refusal}"
    );
    assert!(refusal.contains("encoding"), "{refusal}");
}

// ---- The first stream on the wire (round 51): `jobs.follow-stream` ----

const KIND_STREAM_DATA: u8 = 6;
const KIND_STREAM_END: u8 = 7;

/// The stream contract end to end on a completed job: the opened frame names the stream, the
/// data frame pushes the whole window (its count is the same fact `jobs.events` reports — two
/// ops, one projection), and the end frame carries the verdict. In a JSON session the stream
/// frames ride JSON too — one session, one encoding, stream frames included.
#[test]
fn a_follow_stream_replays_the_window_and_ends_with_the_verdict() {
    let daemon = spawn_daemon("stream");
    let mut stream = connect(&daemon);
    send(&mut stream, KIND_HELLO, &hello_payload());
    let _ = recv(&mut stream);
    send(
        &mut stream,
        KIND_REQUEST,
        "request_id=111\ntrace_id=e2e-stream\noperation=profiles.apply\nprofile_id=demo-tun-profile\nidempotency_key=e2e-stream-1",
    );
    let (kind, accepted) = recv(&mut stream);
    assert_eq!(kind, KIND_RESPONSE, "{accepted}");
    let job_id: u64 = field(&accepted, "job_id")
        .and_then(|v| v.parse().ok())
        .expect("job id");

    send(
        &mut stream,
        KIND_REQUEST,
        &format!(
            "request_id=112\ntrace_id=e2e-stream\noperation=jobs.follow-stream\njob_id={job_id}"
        ),
    );
    let (kind, opened) = recv(&mut stream);
    assert_eq!(
        kind, KIND_RESPONSE,
        "the opened frame answers first: {opened}"
    );
    let stream_id = field(&opened, "stream_id").unwrap_or_default();
    assert!(!stream_id.is_empty(), "the stream is named: {opened}");

    let (kind, data) = recv(&mut stream);
    assert_eq!(kind, KIND_STREAM_DATA, "then data: {data}");
    assert_eq!(
        field(&data, "stream_id").as_deref(),
        Some(stream_id.as_str())
    );
    assert_eq!(
        field(&data, "seq").as_deref(),
        Some("1"),
        "seq starts at 1: {data}"
    );
    let declared: usize = field(&data, "event_count")
        .and_then(|v| v.parse().ok())
        .unwrap_or(999);
    assert!(declared >= 1, "an executed job has lines: {data}");

    let (kind, end) = recv(&mut stream);
    assert_eq!(kind, KIND_STREAM_END, "the stream ends: {end}");
    assert_eq!(field(&end, "state").as_deref(), Some("completed"), "{end}");
    assert_eq!(
        field(&end, "outcome").as_deref(),
        Some("Succeeded"),
        "{end}"
    );

    // Cross-op consistency: the stream's count is the events op's count — one fact.
    send(
        &mut stream,
        KIND_REQUEST,
        &format!("request_id=113\ntrace_id=e2e-stream\noperation=jobs.events\njob_id={job_id}"),
    );
    let (kind, events) = recv(&mut stream);
    assert_eq!(kind, KIND_RESPONSE);
    assert_eq!(
        field(&data, "event_count"),
        field(&events, "event_count"),
        "the stream pushed exactly what the events op pages: {data} vs {events}"
    );

    // And in a JSON session the stream frames ride JSON (one session, one encoding).
    let mut json_stream = connect(&daemon);
    send(
        &mut json_stream,
        KIND_HELLO,
        "client_name=e2e\nrole=Admin\nmajor=1\nminor=0\nencoding=json",
    );
    let _ = recv(&mut json_stream);
    send(
        &mut json_stream,
        KIND_REQUEST,
        &format!(
            "{{\"request_id\":\"114\",\"trace_id\":\"e2e\",\"operation\":\"jobs.follow-stream\",\"job_id\":\"{job_id}\"}}"
        ),
    );
    let (kind, _opened) = recv(&mut json_stream);
    assert_eq!(kind, KIND_RESPONSE);
    let (kind, json_data) = recv(&mut json_stream);
    assert_eq!(kind, KIND_STREAM_DATA);
    assert!(
        json_data.starts_with('{'),
        "stream frames follow the session encoding: {json_data}"
    );
    let (kind, json_end) = recv(&mut json_stream);
    assert_eq!(kind, KIND_STREAM_END);
    assert!(json_end.starts_with('{'), "{json_end}");
}

/// The resume cursor is the stream's contract too: opening at `from_event_index=N` replays
/// exactly the events from N (the events op's own tiling, judged across the two ops).
#[test]
fn a_stream_opened_mid_window_replays_from_the_cursor() {
    let daemon = spawn_daemon("stream-from");
    let mut stream = connect(&daemon);
    send(&mut stream, KIND_HELLO, &hello_payload());
    let _ = recv(&mut stream);
    send(
        &mut stream,
        KIND_REQUEST,
        "request_id=115\ntrace_id=e2e-stream-from\noperation=profiles.apply\nprofile_id=demo-tun-profile\nidempotency_key=e2e-stream-from-1",
    );
    let (kind, accepted) = recv(&mut stream);
    assert_eq!(kind, KIND_RESPONSE);
    let job_id: u64 = field(&accepted, "job_id")
        .and_then(|v| v.parse().ok())
        .expect("job id");

    // Ground truth: the whole window, from the events op.
    send(
        &mut stream,
        KIND_REQUEST,
        &format!(
            "request_id=116\ntrace_id=e2e-stream-from\noperation=jobs.events\njob_id={job_id}"
        ),
    );
    let (kind, events) = recv(&mut stream);
    assert_eq!(kind, KIND_RESPONSE);
    let whole: Vec<String> = (0..field(&events, "event_count")
        .and_then(|v| v.parse().ok())
        .unwrap_or(0))
        .map(|index| field(&events, &format!("event_{index}")).unwrap_or_default())
        .collect();
    assert!(whole.len() >= 6);

    // The resume cursor is exclusive (`from_event_index=N` replays after N — the same
    // contract `next_from_event_index` serves), so `from=3` is the window from 4.
    let split = 3;
    send(
        &mut stream,
        KIND_REQUEST,
        &format!(
            "request_id=117\ntrace_id=e2e-stream-from\noperation=jobs.follow-stream\njob_id={job_id}\nfrom_event_index={split}"
        ),
    );
    let _ = recv(&mut stream); // opened
    let (kind, data) = recv(&mut stream);
    assert_eq!(kind, KIND_STREAM_DATA, "{data}");
    let pushed: Vec<String> = (0..field(&data, "event_count")
        .and_then(|v| v.parse().ok())
        .unwrap_or(0))
        .map(|index| field(&data, &format!("event_{index}")).unwrap_or_default())
        .collect();
    let expected: Vec<String> = whole[split + 1..].to_vec();
    assert_eq!(
        pushed, expected,
        "the stream from {split} is exactly the window from {split} — no more, no less"
    );
    let (kind, end) = recv(&mut stream);
    assert_eq!(kind, KIND_STREAM_END, "{end}");
}

/// A stream on a job that never existed is a refusal that names it — never an opened frame
/// for a ghost stream pushing made-up lines.
#[test]
fn a_stream_on_an_unknown_job_is_refused_not_improvised() {
    let daemon = spawn_daemon("stream-ghost");
    let mut stream = connect(&daemon);
    send(&mut stream, KIND_HELLO, &hello_payload());
    let _ = recv(&mut stream);
    send(
        &mut stream,
        KIND_REQUEST,
        "request_id=118\ntrace_id=e2e-ghost\noperation=jobs.follow-stream\njob_id=424242",
    );
    let (kind, refusal) = recv(&mut stream);
    assert_eq!(kind, KIND_REFUSAL, "{refusal}");
    assert!(
        refusal.contains("424242"),
        "the refusal names the job that does not exist: {refusal}"
    );
}

// ---- The reconnect path (round 52): ack frames + resume ----

const KIND_STREAM_ACK: u8 = 8;

/// The at-least-once contract, acked side: a client that acked everything and reconnects
/// gets the **empty delta** — the resume opens, the stream is already at its end, and not one
/// line is repeated. The ack is a conversation: the confirmation (`acked_upto`) is the
/// barrier that makes the subsequent resume deterministic.
#[test]
fn an_acked_stream_resumes_with_an_empty_delta() {
    let daemon = spawn_daemon("resume-acked");
    let mut stream = connect(&daemon);
    send(&mut stream, KIND_HELLO, &hello_payload());
    let _ = recv(&mut stream);
    send(
        &mut stream,
        KIND_REQUEST,
        "request_id=121\ntrace_id=e2e-resume\noperation=profiles.apply\nprofile_id=demo-tun-profile\nidempotency_key=e2e-resume-1",
    );
    let (kind, accepted) = recv(&mut stream);
    assert_eq!(kind, KIND_RESPONSE);
    let job_id: u64 = field(&accepted, "job_id")
        .and_then(|v| v.parse().ok())
        .expect("job id");

    send(
        &mut stream,
        KIND_REQUEST,
        &format!(
            "request_id=122\ntrace_id=e2e-resume\noperation=jobs.follow-stream\njob_id={job_id}"
        ),
    );
    let (kind, opened) = recv(&mut stream);
    assert_eq!(kind, KIND_RESPONSE);
    let stream_id = field(&opened, "stream_id").unwrap_or_default();
    let (kind, data) = recv(&mut stream);
    assert_eq!(kind, KIND_STREAM_DATA);
    let upto = field(&data, "next_event_index").unwrap_or_default();
    let (kind, end) = recv(&mut stream);
    assert_eq!(kind, KIND_STREAM_END);
    assert!(field(&end, "outcome").as_deref() == Some("Succeeded"));

    // The ack and its confirmation — the barrier before any reconnect.
    send(
        &mut stream,
        KIND_STREAM_ACK,
        &format!("stream_id={stream_id}\nnext_event_index={upto}"),
    );
    let (kind, confirmed) = recv(&mut stream);
    assert_eq!(kind, KIND_RESPONSE, "an ack is answered: {confirmed}");
    assert_eq!(
        field(&confirmed, "acked_upto").as_deref(),
        Some(upto.as_str()),
        "the confirmation echoes the cursor the daemon actually recorded"
    );

    // A new connection resumes the logical stream: nothing repeats.
    let mut resumed = connect(&daemon);
    send(&mut resumed, KIND_HELLO, &hello_payload());
    let _ = recv(&mut resumed);
    send(
        &mut resumed,
        KIND_REQUEST,
        &format!(
            "request_id=123\ntrace_id=e2e-resume\noperation=jobs.follow-stream\nresume=true\nstream_id={stream_id}"
        ),
    );
    let (kind, reopened) = recv(&mut resumed);
    assert_eq!(kind, KIND_RESPONSE, "{reopened}");
    assert_eq!(
        field(&reopened, "stream_id").as_deref(),
        Some(stream_id.as_str()),
        "a resume keeps the logical stream id the client knows"
    );
    assert_eq!(
        field(&reopened, "resumed").as_deref(),
        Some("true"),
        "{reopened}"
    );
    let (kind, next) = recv(&mut resumed);
    assert_eq!(
        kind, KIND_STREAM_END,
        "an acked-complete stream resumes straight to its end — the delta is empty: {next}"
    );
    assert_eq!(
        field(&next, "outcome").as_deref(),
        Some("Succeeded"),
        "{next}"
    );
}

/// The at-least-once contract, unacked side: a client that read everything but never acked,
/// then reconnects, gets the **full replay**. Emitted-but-unacked is not delivered-and-forgotten
/// — the resume cursor is what the client confirmed, never what the server happened to send.
#[test]
fn an_unacked_stream_replays_everything_on_resume() {
    let daemon = spawn_daemon("resume-unacked");
    let mut stream = connect(&daemon);
    send(&mut stream, KIND_HELLO, &hello_payload());
    let _ = recv(&mut stream);
    send(
        &mut stream,
        KIND_REQUEST,
        "request_id=124\ntrace_id=e2e-unacked\noperation=profiles.apply\nprofile_id=demo-tun-profile\nidempotency_key=e2e-unacked-1",
    );
    let (kind, accepted) = recv(&mut stream);
    assert_eq!(kind, KIND_RESPONSE);
    let job_id: u64 = field(&accepted, "job_id")
        .and_then(|v| v.parse().ok())
        .expect("job id");

    send(
        &mut stream,
        KIND_REQUEST,
        &format!(
            "request_id=125\ntrace_id=e2e-unacked\noperation=jobs.follow-stream\njob_id={job_id}"
        ),
    );
    let (kind, opened) = recv(&mut stream);
    assert_eq!(kind, KIND_RESPONSE);
    let stream_id = field(&opened, "stream_id").unwrap_or_default();
    let (kind, data) = recv(&mut stream);
    assert_eq!(kind, KIND_STREAM_DATA);
    let first_count = field(&data, "event_count").unwrap_or_default();
    let (kind, _end) = recv(&mut stream);
    assert_eq!(kind, KIND_STREAM_END);
    // No ack. The client vanishes with its unconfirmed cursor.

    let mut resumed = connect(&daemon);
    send(&mut resumed, KIND_HELLO, &hello_payload());
    let _ = recv(&mut resumed);
    send(
        &mut resumed,
        KIND_REQUEST,
        &format!(
            "request_id=126\ntrace_id=e2e-unacked\noperation=jobs.follow-stream\nresume=true\nstream_id={stream_id}"
        ),
    );
    let _ = recv(&mut resumed);
    let (kind, replay) = recv(&mut resumed);
    assert_eq!(
        kind, KIND_STREAM_DATA,
        "nothing was acked, so everything replays: {replay}"
    );
    assert_eq!(
        field(&replay, "event_count"),
        Some(first_count.clone()),
        "the replay is the whole window, exactly once more"
    );
    let (kind, end) = recv(&mut resumed);
    assert_eq!(kind, KIND_STREAM_END, "{end}");
}

/// A resume names a stream the daemon does not know (never opened, evicted by the bounded
/// table, or a restarted daemon): that is a refusal naming the stream — never a fresh open
/// dressed as a resume, which would silently answer a different question.
#[test]
fn a_resume_of_an_unknown_stream_is_refused_by_name() {
    let daemon = spawn_daemon("resume-unknown");
    let mut stream = connect(&daemon);
    send(&mut stream, KIND_HELLO, &hello_payload());
    let _ = recv(&mut stream);
    send(
        &mut stream,
        KIND_REQUEST,
        "request_id=127\ntrace_id=e2e-runknown\noperation=jobs.follow-stream\nresume=true\nstream_id=424242",
    );
    let (kind, refusal) = recv(&mut stream);
    assert_eq!(kind, KIND_REFUSAL, "{refusal}");
    assert!(
        refusal.contains("424242"),
        "the refusal names the stream that is not open: {refusal}"
    );
    // An ack for an unknown stream is the same honesty, one frame later.
    send(
        &mut stream,
        KIND_STREAM_ACK,
        "stream_id=424243\nnext_event_index=5",
    );
    let (kind, refusal) = recv(&mut stream);
    assert_eq!(kind, KIND_REFUSAL, "{refusal}");
    assert!(
        refusal.contains("424243"),
        "an ack must name an open stream: {refusal}"
    );
}

/// The stream table is bounded and refuses loudly: the 65th concurrent stream is a named
/// capacity refusal, in line with every other bounded queue this daemon owns — an unbounded
/// table is a leak wearing a feature's clothes.
#[test]
fn the_stream_table_is_bounded_and_refuses_loudly() {
    let daemon = spawn_daemon("stream-cap");
    let mut stream = connect(&daemon);
    send(&mut stream, KIND_HELLO, &hello_payload());
    let _ = recv(&mut stream);
    send(
        &mut stream,
        KIND_REQUEST,
        "request_id=128\ntrace_id=e2e-cap\noperation=profiles.apply\nprofile_id=demo-tun-profile\nidempotency_key=e2e-cap-1",
    );
    let (kind, accepted) = recv(&mut stream);
    assert_eq!(kind, KIND_RESPONSE);
    let job_id: u64 = field(&accepted, "job_id")
        .and_then(|v| v.parse().ok())
        .expect("job id");

    for index in 0..64 {
        send(
            &mut stream,
            KIND_REQUEST,
            &format!(
                "request_id=13{index}\ntrace_id=e2e-cap\noperation=jobs.follow-stream\njob_id={job_id}"
            ),
        );
        let (kind, opened) = recv(&mut stream);
        assert_eq!(kind, KIND_RESPONSE, "stream {index} opens: {opened}");
        let _ = recv(&mut stream); // data
        let _ = recv(&mut stream); // end
    }
    send(
        &mut stream,
        KIND_REQUEST,
        &format!(
            "request_id=1399\ntrace_id=e2e-cap\noperation=jobs.follow-stream\njob_id={job_id}"
        ),
    );
    let (kind, refusal) = recv(&mut stream);
    assert_eq!(kind, KIND_REFUSAL, "the 65th stream is refused: {refusal}");
    assert!(
        refusal.contains("full"),
        "the refusal names the capacity, not a generic error: {refusal}"
    );
}

/// A zero worker tick is a busy loop pretending to be a schedule, and the flag refuses it at
/// parse time — clamping silently would be a policy hiding inside a name (the same reason
/// round 46 split the hello and idle deadlines).
#[test]
fn a_zero_worker_tick_is_refused_at_the_flag_not_clamped() {
    let data_dir = std::env::temp_dir().join(format!("calyd-e2e-{}-zerotick", std::process::id()));
    let output = Command::new(env!("CARGO_BIN_EXE_calyd"))
        .arg("--data-dir")
        .arg(&data_dir)
        .arg("--worker-tick-ms")
        .arg("0")
        .output()
        .expect("the calyd binary must be built with the test run");
    assert_eq!(
        output.status.code(),
        Some(2),
        "a zero tick must be a usage exit, not a clamp"
    );
    let stderr = String::from_utf8_lossy(&output.stderr);
    assert!(
        stderr.contains("--worker-tick-ms") && stderr.contains("busy"),
        "the refusal names the flag and the reason: {stderr}"
    );
}

/// Round 53's disconnect half: a stream client that walks away mid-wait must cost the pump one
/// wait tick, not the whole tick budget. The daemon's tick here is 5s, so if the pump only
/// learned of the departure when the *next* write failed (the pre-round shape), the reap line
/// would appear no earlier than the worker's tick; the zero-byte peer probe must catch it in
/// the first wait. And "reaped" must not mean "wedged": the daemon still serves the next
/// client.
#[test]
fn a_stream_client_that_leaves_mid_wait_is_reaped_within_one_wait_tick() {
    let (daemon, stderr_file) = spawn_daemon_logged("worker-reap", &["--worker-tick-ms", "5000"]);
    let mut stream = connect(&daemon);
    send(&mut stream, KIND_HELLO, &hello_payload());
    let _ = recv(&mut stream);
    send(
        &mut stream,
        KIND_REQUEST,
        "request_id=140\ntrace_id=e2e-reap\noperation=profiles.apply\nprofile_id=demo-tun-profile\nidempotency_key=e2e-reap-1",
    );
    let (kind, accepted) = recv(&mut stream);
    assert_eq!(kind, KIND_RESPONSE, "{accepted}");
    let job_id: u64 = field(&accepted, "job_id")
        .and_then(|v| v.parse().ok())
        .expect("job id");

    // The stream opens on the queued job (the worker will not run it for 5s), the client
    // reads the opened frame, and then leaves.
    send(
        &mut stream,
        KIND_REQUEST,
        &format!(
            "request_id=141\ntrace_id=e2e-reap\noperation=jobs.follow-stream\njob_id={job_id}"
        ),
    );
    let (kind, opened) = recv(&mut stream);
    assert_eq!(kind, KIND_RESPONSE, "the stream opens: {opened}");
    drop(stream);

    let deadline = Instant::now() + Duration::from_millis(2_500);
    let mut saw_reap = false;
    while Instant::now() < deadline {
        if let Ok(text) = std::fs::read_to_string(&stderr_file) {
            if text.contains("client went away mid-stream") {
                saw_reap = true;
                break;
            }
        }
        std::thread::sleep(Duration::from_millis(25));
    }
    assert!(
        saw_reap,
        "the pump must notice the departed client within one wait tick (2.5s), \
         well before the 5s worker tick could hand it anything to write"
    );

    // Reaped is not wedged: a fresh client is served.
    let mut fresh = connect(&daemon);
    send(&mut fresh, KIND_HELLO, &hello_payload());
    let (kind, _) = recv(&mut fresh);
    assert_eq!(kind, KIND_HELLO_ACK, "the daemon still answers hellos");
}

/// A numeric record the daemon cannot parse is a refusal naming the field — the same rule the
/// wire already applied to ids. The `.and_then(|v| v.parse().ok())` shape this judge holds
/// down silently turned `max_deletions=abc` into "no bound" and `from_event_index=abc` into
/// "from the beginning": both are the daemon guessing a default the caller never sent, and a
/// garbage cursor that silently replays a whole stream is the worse of the two.
#[test]
fn a_number_field_that_wont_parse_is_a_named_refusal_not_a_default() {
    let daemon = spawn_daemon("num-gates");
    let mut stream = connect(&daemon);
    send(&mut stream, KIND_HELLO, &hello_payload());
    let _ = recv(&mut stream);

    // A keyed command first: the refusal must not consume the key either — a caller whose
    // request was refused for an unparseable bound retries the *same* write, and the same key
    // must still open its job.
    send(
        &mut stream,
        KIND_REQUEST,
        "request_id=150\ntrace_id=e2e-num\noperation=system.gc\nidempotency_key=e2e-num-1\nmax_deletions=abc",
    );
    let (kind, refusal) = recv(&mut stream);
    assert_eq!(
        kind, KIND_REFUSAL,
        "garbage is refused, not defaulted: {refusal}"
    );
    assert!(
        refusal.contains("max_deletions")
            && refusal.contains("refusing rather than defaulting")
            && field(&refusal, "code").as_deref() == Some("USAGE"),
        "the refusal names the field, the rule and the code: {refusal}"
    );
    send(
        &mut stream,
        KIND_REQUEST,
        "request_id=151\ntrace_id=e2e-num\noperation=system.gc\nidempotency_key=e2e-num-1",
    );
    let (kind, accepted) = recv(&mut stream);
    assert_eq!(
        kind, KIND_RESPONSE,
        "the refused request consumed no key and created no job: {accepted}"
    );
    let job_id: u64 = field(&accepted, "job_id")
        .and_then(|v| v.parse().ok())
        .expect("the honest retry opens its job");

    // The same rule on the queries and the stream cursor.
    send(
        &mut stream,
        KIND_REQUEST,
        "request_id=152\ntrace_id=e2e-num\noperation=system.gc-plan\ngrace_period_ms=soon",
    );
    let (kind, refusal) = recv(&mut stream);
    assert_eq!(kind, KIND_REFUSAL, "{refusal}");
    assert!(
        refusal.contains("grace_period_ms") && field(&refusal, "code").as_deref() == Some("USAGE"),
        "{refusal}"
    );
    send(
        &mut stream,
        KIND_REQUEST,
        &format!(
            "request_id=153\ntrace_id=e2e-num\noperation=jobs.follow-stream\njob_id={job_id}\nfrom_event_index=soon"
        ),
    );
    let (kind, refusal) = recv(&mut stream);
    assert_eq!(
        kind, KIND_REFUSAL,
        "a garbage cursor must not become a full silent replay: {refusal}"
    );
    assert!(refusal.contains("from_event_index"), "{refusal}");
    send(
        &mut stream,
        KIND_REQUEST,
        &format!(
            "request_id=154\ntrace_id=e2e-num\noperation=jobs.events\njob_id={job_id}\nmax_lines=lots"
        ),
    );
    let (kind, refusal) = recv(&mut stream);
    assert_eq!(kind, KIND_REFUSAL, "{refusal}");
    assert!(refusal.contains("max_lines"), "{refusal}");
    send(
        &mut stream,
        KIND_REQUEST,
        "request_id=155\ntrace_id=e2e-num\noperation=diagnostics.support-bundle-read\ndigest=sha256:0000\nmax_bytes=lots",
    );
    let (kind, refusal) = recv(&mut stream);
    assert_eq!(kind, KIND_REFUSAL, "{refusal}");
    assert!(refusal.contains("max_bytes"), "{refusal}");
}

/// Real host effects are an explicit composition choice. Missing one of the two operator-owned
/// paths is a usage refusal before the daemon opens a listener; the default path remains covered
/// by the socket judges above.
#[test]
fn real_effect_runtime_preflight_refuses_missing_assets_before_listening() {
    let base = std::env::temp_dir().join(format!("calyd-e2e-{}-real-config", std::process::id()));
    let data_dir = base.join("data");
    let runtime_root = base.join("runtime");
    let _ = std::fs::remove_dir_all(&base);
    let assets_dir = base.join("missing-assets");
    let output = Command::new(env!("CARGO_BIN_EXE_calyd"))
        .arg("--data-dir")
        .arg(&data_dir)
        .arg("--effect-runtime")
        .arg("real")
        .arg("--runtime-root")
        .arg(&runtime_root)
        .arg("--assets-dir")
        .arg(&assets_dir)
        .output()
        .expect("the calyd binary must be built with the test run");
    assert_eq!(
        output.status.code(),
        Some(1),
        "a missing real-runtime asset is a startup refusal, not a listener: {:?}",
        output.status
    );
    let stderr = String::from_utf8_lossy(&output.stderr);
    assert!(
        stderr.contains("real effect runtime assets") && stderr.contains("mihomo"),
        "the refusal names the preflight domain and asset: {stderr}"
    );
    assert!(
        !data_dir.join("var/caly").exists(),
        "asset preflight must happen before the durable store is created"
    );
    assert!(
        !base.join("data.port").exists(),
        "a refused configuration must not publish a port"
    );
    let _ = std::fs::remove_dir_all(base);
}

/// The stream's DATA payload is the events op's window line for line — both ops project one
/// fact (the job's event log), so a stream that re-orders, truncates, pads, or drops lines
/// still passes a count-vs-count judge (round 66, `IMPLEMENTATION_STATUS §8.4` step 2,
/// "per-frame payload"). The lines are compared unescaped, so `=` or a newline inside an
/// event line cannot hide structure, and each frame's `event_count` is judged against its
/// own `event_i` rows — the count-is-lines doctrine on the stream frame.
#[test]
fn the_stream_data_payload_matches_the_events_page_line_for_line() {
    let daemon = spawn_daemon("stream-lines");
    let mut stream = connect(&daemon);
    send(&mut stream, KIND_HELLO, &hello_payload());
    let _ = recv(&mut stream);
    send(
        &mut stream,
        KIND_REQUEST,
        "request_id=121\ntrace_id=e2e-stream-lines\noperation=profiles.apply\nprofile_id=demo-tun-profile\nidempotency_key=e2e-stream-lines-1",
    );
    let (kind, accepted) = recv(&mut stream);
    assert_eq!(kind, KIND_RESPONSE, "{accepted}");
    let job_id: u64 = field(&accepted, "job_id")
        .and_then(|v| v.parse().ok())
        .expect("a job id");
    let _ = wait_for_terminal(&mut stream, job_id);

    // Ground truth: the whole window from the events op.
    send(
        &mut stream,
        KIND_REQUEST,
        &format!(
            "request_id=122\ntrace_id=e2e-stream-lines\noperation=jobs.events\njob_id={job_id}"
        ),
    );
    let (kind, events) = recv(&mut stream);
    assert_eq!(kind, KIND_RESPONSE, "{events}");
    let page_count: usize = field(&events, "event_count")
        .and_then(|v| v.parse().ok())
        .unwrap_or(0);
    let page_lines: Vec<String> = (0..page_count)
        .map(|index| unescape(&field(&events, &format!("event_{index}")).unwrap_or_default()))
        .collect();
    assert!(
        page_lines.iter().all(|line| !line.is_empty()),
        "a demo apply's window has populated lines: {:?}",
        page_lines
    );
    assert!(page_lines.len() >= 6, "the demo window is non-trivial");

    // The stream: whole window, no from_event_index.
    send(
        &mut stream,
        KIND_REQUEST,
        &format!(
            "request_id=123\ntrace_id=e2e-stream-lines\noperation=jobs.follow-stream\njob_id={job_id}"
        ),
    );
    let (kind, opened) = recv(&mut stream);
    assert_eq!(kind, KIND_RESPONSE, "the stream opens: {opened}");
    let mut pushed: Vec<String> = Vec::new();
    let mut data_frames = 0usize;
    loop {
        let (kind, payload) = recv(&mut stream);
        match kind {
            KIND_STREAM_DATA => {
                data_frames += 1;
                let count: usize = field(&payload, "event_count")
                    .and_then(|v| v.parse().ok())
                    .unwrap_or(0);
                let frame_lines: Vec<String> = (0..count)
                    .map(|index| {
                        unescape(&field(&payload, &format!("event_{index}")).unwrap_or_default())
                    })
                    .collect();
                // The frame's own rows: every `event_<digits>` key (the count-is-lines
                // doctrine on stream frames, judged from the frame's record list).
                let frame_rows = records(&payload)
                    .iter()
                    .filter(|(key, _)| {
                        key.strip_prefix("event_")
                            .map(|suffix| {
                                !suffix.is_empty() && suffix.chars().all(|c| c.is_ascii_digit())
                            })
                            .unwrap_or(false)
                    })
                    .count();
                assert_eq!(
                    frame_rows, count,
                    "a frame's event_count is its event_i line count: {payload}"
                );
                assert!(
                    frame_lines.iter().all(|line| !line.is_empty()),
                    "an event line is not an empty string: {payload}"
                );
                pushed.extend(frame_lines);
            }
            KIND_STREAM_END => break,
            other => panic!("unexpected frame kind {other} while streaming: {payload}"),
        }
    }
    assert!(
        data_frames >= 1,
        "the stream must carry at least one data frame"
    );
    assert_eq!(
        pushed, page_lines,
        "the stream's lines are the events page's lines, verbatim and in order"
    );
    assert_eq!(
        pushed.len(),
        page_count,
        "the stream pushed exactly the page's line count"
    );
}

// --------------------------------------------------------------------------------------------
// round 76 — the single source encoder against the daemon's door
//
// `caly_ipc::wire_request` is the one encode table; `calyd.rs` is the decode table. They can
// drift (a renamed record, a renamed op) and every existing test would still pass, because
// each side's tests feed it by hand. This judge is the honest meeting point: every request op
// the encoder ships is sent over the real wire, and the daemon must answer with something
// other than a door refusal — `USAGE` (missing/malformed record) and `UNSUPPORTED` (an op the
// daemon does not dispatch) are the two ways a hand-built table can be wrong. Domain refusals
// (no such profile, no such job) are the daemon answering the question asked, not a door
// failure, and are judged by their own tests.

#[test]
fn every_request_op_encoded_by_the_single_source_passes_the_daemons_door() {
    use caly_api::{
        ApplyRequest, DoctorRequest, GcCollectRequest, GcPlanRequest, JobEventsRequest,
        JobFollowRequest, JobId, ProfileId, RollbackRequest, SupportBundleReadRequest,
    };
    use caly_api::{DiagnosticsOp, Operation, ProfileOp, RuntimeOp, SystemOp};

    let daemon = spawn_daemon("wire-op-sweep");
    let mut stream = connect(&daemon);
    send(&mut stream, KIND_HELLO, &hello_payload());
    let (kind, _ack) = recv(&mut stream);
    assert_eq!(kind, KIND_HELLO_ACK, "hello is answered by a hello_ack");

    let ops: Vec<Operation> = vec![
        Operation::Runtime(RuntimeOp::Status),
        Operation::Diagnostics(DiagnosticsOp::Doctor {
            request: DoctorRequest {
                include_runtime: false,
            },
        }),
        Operation::Diagnostics(DiagnosticsOp::SupportBundle),
        Operation::Profile(ProfileOp::List),
        Operation::Profile(ProfileOp::Get {
            profile_id: ProfileId("door-sweep".into()),
        }),
        Operation::Profile(ProfileOp::Apply {
            request: ApplyRequest {
                profile_id: ProfileId("door-sweep".into()),
                dry_run: true,
                strict: false,
            },
        }),
        Operation::Profile(ProfileOp::Rollback {
            request: RollbackRequest {
                snapshot_id: Some("door-sweep".into()),
            },
        }),
        Operation::Diagnostics(DiagnosticsOp::ReadJobEvents {
            request: JobEventsRequest {
                job_id: JobId(1),
                from_event_index: None,
                max_lines: None,
                max_bytes: None,
            },
        }),
        Operation::Diagnostics(DiagnosticsOp::FollowJob {
            request: JobFollowRequest {
                job_id: JobId(1),
                from_event_index: None,
            },
        }),
        Operation::Diagnostics(DiagnosticsOp::FollowJobStream {
            request: JobFollowRequest {
                job_id: JobId(1),
                from_event_index: None,
            },
        }),
        Operation::System(SystemOp::GcPlan {
            request: GcPlanRequest {
                grace_period_ms: Some(60_000),
                max_deletions: None,
            },
        }),
        Operation::System(SystemOp::CollectGarbage {
            request: GcCollectRequest {
                grace_period_ms: Some(60_000),
                max_deletions: Some(1),
            },
        }),
        Operation::Diagnostics(DiagnosticsOp::ReadSupportBundle {
            request: SupportBundleReadRequest {
                digest: None,
                max_bytes: Some(100),
            },
        }),
    ];

    for (index, operation) in ops.iter().enumerate() {
        let wire = caly_ipc::wire_request(operation)
            .expect("every op in the sweep has a v0 wire representation");
        let request_id = index as u64 + 1;
        // The session-level records a client actually sends: head fields then the extras.
        // Keyed writes carry the ADR-037 key; this client mints a sweep key so the door
        // check is the one under test, not the key rule (judged by its own tests).
        let mut extras: Vec<(&str, String)> = wire.extras.clone();
        if matches!(
            wire.name,
            "profiles.apply" | "profiles.rollback" | "system.gc"
        ) {
            extras.push(("idempotency_key", format!("r76-sweep-{request_id}")));
        }
        let payload = caly_ipc::dialect::request_payload(request_id, wire.name, &extras, false);
        let payload = std::str::from_utf8(&payload).expect("records payload is utf-8");
        send(&mut stream, KIND_REQUEST, payload);
        // Jobs this session launched (e.g. support-bundle) push stream frames out of band;
        // drain those until the answer to *this* request — a response or a refusal — lands.
        let (kind, answer) = loop {
            let (kind, frame) = recv(&mut stream);
            if !matches!(kind, KIND_STREAM_DATA | KIND_STREAM_END) {
                break (kind, frame);
            }
        };
        let code = field(&answer, "code").unwrap_or_default().to_owned();
        assert!(
            !(kind == KIND_REFUSAL && (code == "USAGE" || code == "UNSUPPORTED")),
            "{} was refused at the daemon's door ({code}): {answer}",
            wire.name
        );
        assert_eq!(
            field(&answer, "request_id").as_deref(),
            Some(&request_id.to_string()[..]),
            "{} must be answered for the request it was asked, not a neighbor's: {answer}",
            wire.name
        );
    }
}

/// Round 87: the same hello → runtime.status conversation over a Unix-domain
/// socket. TCP `--port-file` stays a bare u16; this judge reads `unix:<path>`
/// and never feeds that string to `parse::<u16>`. The facts on the wire must
/// not change with the transport.
#[cfg(unix)]
#[test]
fn hello_then_runtime_status_over_a_unix_domain_socket() {
    let daemon = spawn_daemon_unix("status");
    let mut stream = connect_unix(&daemon);

    send(&mut stream, KIND_HELLO, &hello_payload());
    let (kind, ack) = recv(&mut stream);
    assert_eq!(kind, KIND_HELLO_ACK, "hello is answered by a hello_ack");
    assert_eq!(field(&ack, "daemon_name").as_deref(), Some("calyd"));
    assert!(
        !field(&ack, "instance_id").unwrap_or_default().is_empty(),
        "the ack names the instance: {ack}"
    );

    send(
        &mut stream,
        KIND_REQUEST,
        "request_id=7\ntrace_id=e2e-uds-status\noperation=runtime.status",
    );
    let (kind, response) = recv(&mut stream);
    assert_eq!(kind, KIND_RESPONSE, "a status query gets a response frame");
    assert_eq!(field(&response, "request_id").as_deref(), Some("7"));
    assert_eq!(field(&response, "core_running").as_deref(), Some("false"));
    assert_eq!(
        field(&response, "pending_recovery_decisions").as_deref(),
        Some("0")
    );
}

/// A UDS port-file that a TCP parser would swallow as a number is the lie this
/// helper exists to refuse: the advertise string starts with `unix:`.
#[cfg(unix)]
#[test]
fn a_unix_port_file_is_not_a_bare_u16() {
    let daemon = spawn_daemon_unix("portfile");
    assert!(
        daemon.path.starts_with('/'),
        "the helper already stripped the unix: prefix: {}",
        daemon.path
    );
    assert!(
        daemon.path.parse::<u16>().is_err(),
        "a socket path must not look like a TCP port: {}",
        daemon.path
    );
}

/// Round 92: the role a peer negotiates at hello is the role its requests carry into the
/// permission gate (`ADR-037` / `RFC-0002 §7.2`). The production frame loop used to rebuild
/// every request envelope with `role: Role::Admin`, so a wire peer that declared `Operator`
/// still passed an Admin-only command — a silent privilege escalation that made the wire-side
/// `require_role` unfailable (the local façade's matching hole was closed in ADR-037 §2.2; the
/// typed `DaemonTransport`/loopback path already keeps the role, which is why the loopback
/// parity test could not see this one). This drives the REAL daemon over TCP with an
/// `Operator` hello and an Admin-only `system.gc`; it must come back as a `PERMISSION`
/// refusal, not run. An `Admin` peer on the same command must still be accepted (the gate is
/// not a blanket refusal).
#[test]
fn a_wire_peer_declaring_operator_is_refused_an_admin_command() {
    let daemon = spawn_daemon("wire-role-operator");
    let mut stream = connect(&daemon);

    // An Operator hello (the dialect maps the literal "Operator" to Role::Operator).
    let hello = "client_name=e2e\nrole=Operator\nmajor=1\nminor=0";
    send(&mut stream, KIND_HELLO, hello);
    let (kind, ack) = recv(&mut stream);
    assert_eq!(
        kind, KIND_HELLO_ACK,
        "hello is answered by a hello_ack: {ack}"
    );

    // An Admin-only command with its idempotency key present (so the refusal cannot be the
    // idempotency gate — role is checked first in `map_request_to_command`).
    send(
        &mut stream,
        KIND_REQUEST,
        "request_id=3\ntrace_id=e2e-gc-op\noperation=system.gc\nidempotency_key=e2e-gc-operator\ngrace_period_ms=0\nmax_deletions=1",
    );
    let (kind, body) = recv(&mut stream);
    assert_eq!(
        kind, KIND_REFUSAL,
        "an under-privileged command is a refusal, not a response: {body}"
    );
    assert_eq!(
        field(&body, "request_id").as_deref(),
        Some("3"),
        "the refusal names the request it refused: {body}"
    );
    assert_eq!(
        field(&body, "code").as_deref(),
        Some("PERMISSION"),
        "an Operator peer refused an Admin op must be PERMISSION, not another refusal: {body}"
    );
    assert!(
        field(&body, "summary")
            .unwrap_or_default()
            .contains("Admin"),
        "the refusal must name the required role so the caller knows the remedy: {body}"
    );
}

/// The other half of round 92: a peer that actually negotiated `Admin` is NOT refused by the
/// role gate for an Admin-only command. Without this, the fix could be "refuse every gc" and
/// the Operator test above would still pass vacuously. The command is well-formed, so the gate
/// admits it; it may succeed or fail as a job, but it must not come back `PERMISSION`.
#[test]
fn a_wire_peer_declaring_admin_is_not_refused_by_the_role_gate() {
    let daemon = spawn_daemon("wire-role-admin");
    let mut stream = connect(&daemon);

    send(&mut stream, KIND_HELLO, &hello_payload());
    let (kind, ack) = recv(&mut stream);
    assert_eq!(
        kind, KIND_HELLO_ACK,
        "hello is answered by a hello_ack: {ack}"
    );

    send(
        &mut stream,
        KIND_REQUEST,
        "request_id=4\ntrace_id=e2e-gc-admin\noperation=system.gc\nidempotency_key=e2e-gc-admin\ngrace_period_ms=0\nmax_deletions=1",
    );
    let (kind, body) = recv(&mut stream);
    // An Admin peer passes the role gate. The reply is a response (accepted/running) — never a
    // PERMISSION refusal. We do not assert the job's outcome, only that privilege was not the
    // thing that stopped it.
    assert_ne!(
        field(&body, "code").as_deref(),
        Some("PERMISSION"),
        "an Admin peer must not be refused on privilege for an Admin op: kind={kind} {body}"
    );
}

/// Round 93: the role a peer claims at hello is a security boundary and must be parsed
/// fail-closed (companion to round 92, which made the envelope carry the negotiated role).
/// The lenient dialect parser keeps its legacy "unknown role => Admin" default, but the daemon
/// is the trust boundary: an unparseable role claim is an identity it cannot grant, so it is
/// refused by name at handshake (the same fail-closed shape an unknown `encoding` gets) rather
/// than promoted to the highest role. A peer that asserts `role=Root` (or any non-wire label)
/// must not get a hello_ack at all.
#[test]
fn a_hello_claiming_an_unknown_role_is_refused_not_promoted_to_admin() {
    let daemon = spawn_daemon("wire-role-bogus");
    let mut stream = connect(&daemon);

    let hello = "client_name=e2e\nrole=Root\nmajor=1\nminor=0";
    send(&mut stream, KIND_HELLO, hello);
    let (kind, body) = recv(&mut stream);
    assert_eq!(
        kind, KIND_REFUSAL,
        "an unparseable role is a handshake refusal, not a hello_ck/admin grant: {body}"
    );
    assert_eq!(
        field(&body, "code").as_deref(),
        Some("HANDSHAKE"),
        "the refusal is a handshake rejection: {body}"
    );
    assert!(
        field(&body, "summary").unwrap_or_default().contains("Root"),
        "the refusal must name the bogus role so the caller knows the claim it cannot grant: {body}"
    );
}

/// Round 93: a hello that names NO role is not silently promoted to Admin — it defaults to the
/// least-privilege role (`Viewer`), the role counterpart of "no `encoding` means records".
/// Proven through behavior: a role-less peer requesting an Admin-only `system.gc` is refused
/// with PERMISSION. (An Admin peer on the same command is not, by
/// `a_wire_peer_declaring_admin_is_not_refused_by_the_role_gate`.)
#[test]
fn a_hello_with_no_role_defaults_to_the_least_privileged_viewer() {
    let daemon = spawn_daemon("wire-role-missing");
    let mut stream = connect(&daemon);

    // Deliberately no `role=` record at all.
    let hello = "client_name=e2e\nmajor=1\nminor=0";
    send(&mut stream, KIND_HELLO, hello);
    let (kind, ack) = recv(&mut stream);
    assert_eq!(
        kind, KIND_HELLO_ACK,
        "a missing role still handshakes: {ack}"
    );

    // An Admin-only command must now be refused on privilege — proof the default was Viewer,
    // not Admin (Admin would run it, as the round-92 Admin twin demonstrates).
    send(
        &mut stream,
        KIND_REQUEST,
        "request_id=5\ntrace_id=e2e-gc-norole\noperation=system.gc\nidempotency_key=e2e-gc-norole\ngrace_period_ms=0\nmax_deletions=1",
    );
    let (kind, body) = recv(&mut stream);
    assert_eq!(
        kind, KIND_REFUSAL,
        "a role-less (least-privilege) peer cannot run an Admin command: {body}"
    );
    assert_eq!(
        field(&body, "code").as_deref(),
        Some("PERMISSION"),
        "the refusal must be the privilege gate, not another failure: {body}"
    );
}

/// Round 102 / ADR-056: SIGTERM must trigger a GRACEFUL shutdown (exit code 0), not the default
/// signal action (death by signal 15). `systemctl stop/restart calyd` sends SIGTERM; before the
/// signal surface calyd installed no handler, so the operating system killed it immediately and
/// the live core was left for next-start crash recovery. This judge spawns the real binary, waits
/// until it is listening (its last startup act), sends a real SIGTERM, and asserts the process
/// exits 0 cleanly rather than being terminated by signal 15.
///
/// The harness itself delivering the signal via `/bin/kill` is test infrastructure (the workspace
/// bans process spawning/signalling from production sources, lifted here by the file-level
/// `disallowed_methods` allow); production code receives via `sigwait` — see ADR-056 §6.
#[cfg(unix)]
#[test]
fn sigterm_shuts_calyd_down_gracefully_with_exit_zero() {
    let mut daemon = spawn_daemon("sigterm");
    // The daemon is listening (port file written); its SIGTERM waiter thread inherited the
    // blocked mask before any accept/worker thread spawned.
    let pid = daemon.child.id();
    let kill = Command::new("/bin/kill")
        .arg("-TERM")
        .arg(pid.to_string())
        .status()
        .expect("the test host must provide /bin/kill to deliver SIGTERM");
    assert!(kill.success(), "/bin/kill -TERM {pid} failed: {kill:?}");

    // Bounded wait: a graceful stop is prompt; if the signal were ignored this times out rather
    // than hanging the suite.
    let deadline = Instant::now() + Duration::from_secs(15);
    let status = loop {
        match daemon.child.try_wait() {
            Ok(Some(status)) => break status,
            Ok(None) => {
                assert!(
                    Instant::now() < deadline,
                    "calyd did not exit after SIGTERM within 15s"
                );
                std::thread::sleep(Duration::from_millis(25));
            }
            Err(error) => panic!("waiting for calyd after SIGTERM: {error}"),
        }
    };
    use std::os::unix::process::ExitStatusExt;
    assert!(
        status.code() == Some(0),
        "SIGTERM must produce a graceful exit code 0 (clean systemd stop), got signal={:?} code={:?}",
        status.signal(),
        status.code()
    );
    // Daemon's Drop calls kill+wait on an already-exited, reaped child: both return Err and are
    // ignored there; it still cleans the scratch data dir. No manual reaping needed.
}
