//! Reading an export back — and what that read must refuse.
//!
//! Round 8 made `DiagnosticsOp::SupportBundle` write a real, redacted bundle into the CAS and report
//! its digest on the job, and explicitly recorded that the bytes could not be obtained by anyone:
//! the store could `put`, inspect metadata, and `materialize` a file for a core, but there was no read
//! path (`docs/ONBOARDING_NOTES.md §4.45`). This file covers the read that closes it, through the
//! daemon's own query boundary so the assertions are about what a client receives.
//!
//! The scoping rule matters as much as the read itself: the store also holds **compiled artifacts and
//! raw sources**, and those are the core's config — credentials included, unredacted by design. A
//! query that read "whatever digest you passed" would turn a diagnostics export into a general secret
//! reader, so the kind is checked before any bytes are touched (`RFC-0010 §12.3`).

use std::sync::Arc;

use caly_api::{
    ApplyRequest, DiagnosticsOp, Operation, ProfileId, ProfileOp, ProtocolVersion, RequestEnvelope,
    RequestId, ResponseEnvelope, Role, SupportBundleReadRequest, TraceId,
};
use caly_common::redact::REDACTED;
use caly_common::Actor;
use caly_daemon::{handle_request, DaemonApp, DaemonBootstrapConfig};
use caly_storage::cas::{CasObjectRef, CasWriteIntent, ObjectDigest, ObjectKind};
use caly_storage::{InMemoryStorage, ObjectStore, StorageBackend};

fn ctx() -> caly_io::IoContext {
    caly_io::RequestContext::new(
        caly_io::TraceId::new("support-bundle-readback"),
        caly_io::Actor::System,
    )
}

fn config(tag: &str) -> DaemonBootstrapConfig {
    DaemonBootstrapConfig {
        instance_id: tag.to_owned(),
        protocol_version: ProtocolVersion { major: 1, minor: 0 },
        recover_on_start: false,
    }
}

fn envelope(operation: Operation, id: u64) -> RequestEnvelope {
    RequestEnvelope {
        protocol: ProtocolVersion { major: 1, minor: 0 },
        request_id: RequestId(id),
        trace_id: TraceId::new(format!("readback-{id}")),
        deadline_ms: None,
        expected_revision: None,
        // `Idempotency::Required` commands are refused without a key (`ADR-037 §2.3`), so the
        // helper mints one per request id: unique per submission, which is exactly what "a
        // different write" means to the dedup window.
        idempotency_key: Some(format!("bundle-{id}")),
        role: Role::Admin,
        io_budget: None,
        operation,
    }
}

/// Ask for a bundle, run the job, and hand back the digest the job reported.
fn write_bundle(daemon: &DaemonApp) -> String {
    let accepted = match handle_request(
        daemon,
        Actor::Cli,
        &envelope(Operation::Diagnostics(DiagnosticsOp::SupportBundle), 1),
    )
    .result
    {
        Ok(caly_api::OperationResult::Accepted(accepted)) => accepted,
        other => panic!("expected an accepted bundle job, got {other:?}"),
    };
    assert_eq!(daemon.drain_engine_once().expect("drain"), 1);
    let events = daemon
        .job_events(caly_api::JobId(accepted.job_id.0))
        .expect("events")
        .expect("job");
    let line = events
        .iter()
        .filter_map(|event| match event {
            caly_engine::JobEvent::Log { message, .. } => Some(message.clone()),
            _ => None,
        })
        .find(|message| message.contains("support bundle written"))
        .expect("the job reports where the bundle went");
    digest_in(&line)
}

fn digest_in(text: &str) -> String {
    let start = text
        .find("object=sha256:")
        .expect("the log line names the object");
    text[start + "object=".len()..]
        .split(' ')
        .next()
        .expect("a digest")
        .to_owned()
}

fn read(daemon: &DaemonApp, request: SupportBundleReadRequest, id: u64) -> ResponseEnvelope {
    handle_request(
        daemon,
        Actor::Cli,
        &envelope(
            Operation::Diagnostics(DiagnosticsOp::ReadSupportBundle { request }),
            id,
        ),
    )
}

fn view(response: ResponseEnvelope) -> caly_api::SupportBundleView {
    match response.result {
        Ok(caly_api::OperationResult::SupportBundle(view)) => view,
        other => panic!("expected a bundle view, got {other:?}"),
    }
}

#[test]
fn a_written_bundle_is_read_back_byte_for_byte_and_still_masked() {
    let store = InMemoryStorage::new();
    let daemon = DaemonApp::try_bootstrap(
        config("readback-ok"),
        Arc::new(store.clone()) as Arc<dyn StorageBackend>,
    )
    .expect("boot");
    // A secret the composition root knows, carried by user input into a job log line the bundle tails.
    daemon.register_secret("OPAQUETOKEN42").expect("registered");
    daemon
        .escalate_redaction(caly_common::redact::RedactionPolicy::Strict)
        .expect("escalated");
    daemon
        .submit_request_as_command(
            Actor::Cli,
            &envelope(
                Operation::Profile(ProfileOp::Apply {
                    request: ApplyRequest {
                        profile_id: ProfileId("demo-tun-profile".to_owned()),
                        dry_run: false,
                        strict: false,
                    },
                }),
                2,
            ),
        )
        .expect("apply accepted");
    assert_eq!(daemon.drain_engine_once().expect("drain"), 1);
    // A secret-bearing line the bundle will tail: `ProxyTestDelay` echoes client-supplied node ids
    // straight into a job log line, which is the real path a credential takes into an export.
    daemon
        .submit_request_as_command(
            Actor::Cli,
            &envelope(
                Operation::Proxy(caly_api::ProxyOp::TestDelay {
                    request: caly_api::DelayTestRequest {
                        node_ids: vec![caly_api::NodeId(
                            "https://host/OPAQUETOKEN42?token=PLAINSECRET99&label=home".to_owned(),
                        )],
                    },
                }),
                90,
            ),
        )
        .expect("delay accepted");
    assert_eq!(daemon.drain_engine_once().expect("drain"), 1);

    let digest = write_bundle(&daemon);

    let got = view(read(
        &daemon,
        SupportBundleReadRequest {
            digest: Some(digest.clone()),
            max_bytes: None,
        },
        3,
    ));
    assert_eq!(got.digest, digest);
    assert!(!got.truncated);
    assert_eq!(got.line_count, got.text.lines().count());
    assert_eq!(got.byte_len as usize, got.text.len());
    assert_eq!(
        got.content_sha256,
        caly_common::digest::sha256_digest(got.text.as_bytes()),
        "the anchor the store verified against must be the digest of what the client received"
    );

    let stored = store
        .stored(&digest)
        .expect("the bundle object is in the store");
    assert_eq!(
        got.text.as_bytes(),
        stored.payload.as_slice(),
        "the read is the stored bytes, not a re-rendering"
    );

    // `§14.3`, now at the client boundary rather than at the store: what a caller can read back
    // carries neither the named nor the registered secret, and it still carries the useful half.
    assert!(!got.text.contains("OPAQUETOKEN42"), "{}", got.text);
    assert!(got.text.contains("== section: header"), "{}", got.text);
    assert!(got.text.contains("# redaction=strict"), "{}", got.text);
    assert!(!got.text.contains("PLAINSECRET99"), "{}", got.text);
    assert!(got.text.contains(REDACTED), "{}", got.text);
    // Masking is not deletion: the line is still there, readable, with its harmless field intact.
    assert!(
        got.text.contains("label=home"),
        "the bundle lost more than secrets:\n{}",
        got.text
    );
}

#[test]
fn omitting_the_digest_reads_the_newest_bundle() {
    let daemon = DaemonApp::bootstrap(config("readback-latest"));
    let digest = write_bundle(&daemon);
    let got = view(read(
        &daemon,
        SupportBundleReadRequest {
            digest: None,
            max_bytes: None,
        },
        4,
    ));
    assert_eq!(
        got.digest, digest,
        "\"the newest one\" is what a client means"
    );
    assert!(got.first_section().is_some(), "{}", got.text);
}

/// The scoping rule. A `CompiledArtifact` object is the core's own config; reading it through a
/// diagnostics query would be the leak, not the feature.
#[test]
fn a_digest_that_is_not_a_bundle_is_refused_before_any_bytes_are_read() {
    let store = InMemoryStorage::new();
    let artifact = "sha256:99aa";
    let payload = b"proxies:\n  - name: hk\n    password: hunter2\n".to_vec();
    caly_io::block_on_ready(store.put(
        CasWriteIntent {
            object: CasObjectRef {
                digest: ObjectDigest(artifact.to_owned()),
                kind: ObjectKind::CompiledArtifact,
                size_bytes: Some(payload.len() as u64),
                content_type: Some("text/yaml".to_owned()),
                content_sha256: None,
                stored_at_unix_ms: Some(1),
            },
            source_label: "artifact.yaml".to_owned(),
            payload,
            stored_at_unix_ms: 1,
        },
        &ctx(),
    ))
    .expect("no suspension")
    .expect("the artifact object is written");

    let daemon = DaemonApp::try_bootstrap(
        config("readback-scope"),
        Arc::new(store) as Arc<dyn StorageBackend>,
    )
    .expect("boot");
    let response = read(
        &daemon,
        SupportBundleReadRequest {
            digest: Some(artifact.to_owned()),
            max_bytes: None,
        },
        5,
    );
    let ResponseEnvelope {
        result: Err(error), ..
    } = &response
    else {
        panic!(
            "a compiled artifact must not be readable through the bundle query, got {:?}",
            response.result
        );
    };
    assert_eq!(error.code, caly_api::ErrorCode::Conflict, "{error:?}");
    assert!(
        error.summary.contains("CompiledArtifact"),
        "the refusal must name what the digest actually is: {}",
        error.summary
    );
    assert!(
        error
            .remediation
            .as_deref()
            .unwrap_or_default()
            .contains("not redacted"),
        "{:?}",
        error.remediation
    );
    // The payload must not leak through the error text either.
    assert!(!error.summary.contains("hunter2"), "{}", error.summary);
}

#[test]
fn a_missing_bundle_is_a_typed_refusal_not_an_empty_export() {
    let daemon = DaemonApp::bootstrap(config("readback-missing"));
    let response = read(
        &daemon,
        SupportBundleReadRequest {
            digest: None,
            max_bytes: None,
        },
        6,
    );
    let ResponseEnvelope {
        result: Err(error), ..
    } = &response
    else {
        panic!("an empty store must not look like an empty bundle");
    };
    assert_eq!(error.code, caly_api::ErrorCode::Conflict, "{error:?}");
    assert!(error.summary.contains("no support bundle yet"), "{error:?}");
    assert!(
        error
            .remediation
            .as_deref()
            .unwrap_or_default()
            .contains("DiagnosticsOp::SupportBundle"),
        "{:?}",
        error.remediation
    );

    // And an unknown digest reads as a miss, not as a zero-length bundle.
    let ResponseEnvelope {
        result: Err(other), ..
    } = read(
        &daemon,
        SupportBundleReadRequest {
            digest: Some("sha256:not-there".to_owned()),
            max_bytes: None,
        },
        7,
    )
    else {
        panic!("expected a refusal");
    };
    assert!(other.summary.contains("no such object"), "{other:?}");
}

#[test]
fn a_truncated_read_says_so_and_stays_a_prefix() {
    let daemon = DaemonApp::bootstrap(config("readback-truncate"));
    let digest = write_bundle(&daemon);
    let full = view(read(
        &daemon,
        SupportBundleReadRequest {
            digest: Some(digest.clone()),
            max_bytes: None,
        },
        8,
    ));
    let cut = view(read(
        &daemon,
        SupportBundleReadRequest {
            digest: Some(digest),
            max_bytes: Some(120),
        },
        9,
    ));
    assert!(cut.truncated, "a partial read must announce itself");
    assert_eq!(cut.byte_len as usize, cut.text.len());
    assert!(cut.byte_len <= 120, "{}", cut.byte_len);
    assert!(
        full.text.starts_with(&cut.text),
        "the prefix must be the prefix"
    );
    assert_eq!(cut.line_count, cut.text.lines().count());
    // The whole object is still verified before being cut, so the anchor is the full bundle's.
    assert_eq!(
        cut.content_sha256, full.content_sha256,
        "a truncated read must not report a digest of the truncated bytes"
    );
}
