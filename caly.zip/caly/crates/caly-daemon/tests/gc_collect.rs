//! One storage collection cycle, reached through the public command surface (`ADR-038 §2`).
//!
//! This is the destructive half: it removes bytes. Everything here is therefore about the two
//! properties that make destroying something acceptable in a control plane -- **it deletes exactly the
//! list the operator was shown**, and **when it must not run, it changes nothing at all** (not the
//! store, not the revision every other caller's `expected_revision` compares against).
//!
//! The fixture uses `InMemoryStorage` on purpose. On a real directory the ages come from file mtimes
//! while the engine's clock is the injected policy base, and `docs/ONBOARDING_NOTES.md §4.74` explains
//! why that combination is refused rather than interpreted; those two sides are pinned in
//! `crates/caly-engine/tests/gc_plan_and_clock.rs`. Here the point is the *command*: its gate, its
//! refusal codes, its record, and its visibility from `doctor`.

use std::sync::Arc;

use caly_api::{
    ApplyRequest, GcCollectRequest, GcPlanRequest, Operation, OperationResult, ProfileId,
    ProfileOp, ProtocolVersion, RequestEnvelope, RequestId, Role, SystemOp, TraceId,
};
use caly_api::{DiagnosticsOp, DoctorRequest};
use caly_common::Actor;
use caly_daemon::{DaemonApp, DaemonBootstrapConfig};
use caly_io::block_on_ready;
use caly_storage::{
    CasObjectRef, CasWriteIntent, InMemoryStorage, ObjectDigest, ObjectKind, ObjectStore,
    StorageBackend,
};

fn ctx() -> caly_io::IoContext {
    caly_io::RequestContext::new(caly_io::TraceId::new("gc-collect"), caly_io::Actor::System)
}

fn booted(tag: &str) -> (DaemonApp, Arc<InMemoryStorage>) {
    let store = Arc::new(InMemoryStorage::new());
    let daemon = DaemonApp::try_bootstrap(
        DaemonBootstrapConfig {
            instance_id: tag.to_owned(),
            protocol_version: ProtocolVersion { major: 1, minor: 0 },
            recover_on_start: false,
        },
        Arc::clone(&store) as Arc<dyn StorageBackend>,
    )
    .expect("boot");
    daemon.set_running().expect("running");
    (daemon, store)
}

fn envelope(
    actor_role: Role,
    operation: Operation,
    key: Option<&str>,
    expected_revision: Option<u64>,
) -> RequestEnvelope {
    RequestEnvelope {
        protocol: ProtocolVersion { major: 1, minor: 0 },
        request_id: RequestId(1),
        trace_id: TraceId::new("gc-collect"),
        deadline_ms: None,
        expected_revision,
        idempotency_key: key.map(str::to_owned),
        role: actor_role,
        io_budget: None,
        operation,
    }
}

fn collect(request: GcCollectRequest) -> Operation {
    Operation::System(SystemOp::CollectGarbage { request })
}

fn plan_op() -> Operation {
    Operation::System(SystemOp::GcPlan {
        request: GcPlanRequest::new().with_grace_period_ms(0),
    })
}

fn apply_op(profile: &str) -> Operation {
    Operation::Profile(ProfileOp::Apply {
        request: ApplyRequest {
            profile_id: ProfileId(profile.to_owned()),
            dry_run: false,
            strict: false,
        },
    })
}

fn run(
    daemon: &DaemonApp,
    operation: Operation,
) -> Result<OperationResult, Box<caly_api::ApiError>> {
    // Boxed on purpose: `ApiError` is wide enough that a bare `Result` here trips the workspace
    // `result_large_err` ratchet, and that ratchet is only worth having if new code bends to it
    // instead of the baseline being raised.
    caly_daemon::handle_request(
        daemon,
        Actor::Cli,
        &envelope(Role::Admin, operation, Some("gc-collect-once"), None),
    )
    .result
    .map_err(Box::new)
}

fn seed_orphan(store: &Arc<InMemoryStorage>, digest: &str) {
    block_on_ready(store.put(
        CasWriteIntent {
            object: CasObjectRef {
                digest: ObjectDigest(digest.to_owned()),
                kind: ObjectKind::RawSource,
                size_bytes: None,
                content_type: None,
                content_sha256: None,
                stored_at_unix_ms: None,
            },
            source_label: "unreferenced".to_owned(),
            payload: b"bytes-nothing-points-at".to_vec(),
            // Dated at the epoch, which is also where the deterministic clock base sits: with
            // `grace_period_ms: 0` the plan is then decided by the root set alone, which is what these
            // tests are about.
            stored_at_unix_ms: 0,
        },
        &ctx(),
    ))
    .expect("no suspension")
    .expect("write");
}

fn plan_of(daemon: &DaemonApp) -> caly_api::GcPlanView {
    match run(daemon, plan_op()).expect("the plan query answers") {
        OperationResult::GcPlan(view) => view,
        other => panic!("expected a gc plan, got {other:?}"),
    }
}

fn doctor_notes(daemon: &DaemonApp) -> Vec<String> {
    match caly_daemon::handle_request(
        daemon,
        Actor::Cli,
        &envelope(
            Role::Admin,
            Operation::Diagnostics(DiagnosticsOp::Doctor {
                request: DoctorRequest {
                    include_runtime: true,
                },
            }),
            None,
            None,
        ),
    )
    .result
    {
        Ok(OperationResult::DoctorReport(report)) => {
            let mut lines = report.notes;
            lines.extend(report.warnings);
            lines
        }
        other => panic!("expected a doctor report, got {other:?}"),
    }
}

/// The happy path, asserted at the two ends that matter: what was deleted, and what the report says.
#[test]
fn a_collected_cycle_removes_the_orphan_and_reports_it() {
    let (daemon, store) = booted("collect-happy");
    seed_orphan(&store, "obj:orphan");
    let rooted = daemon
        .latest_last_known_good_snapshot()
        .expect("no snapshot yet")
        .is_none();
    assert!(rooted, "a fresh daemon has nothing rooted, by construction");

    // Before anything has run, both outlets say the same sentence about it -- not "healthy", not an
    // empty section. One const behind both, so they cannot drift.
    let notes = doctor_notes(&daemon);
    assert!(
        notes
            .iter()
            .any(|line| line.contains("no collection cycle has run in this process")),
        "the absence of a cycle has to be stated, not omitted: {notes:?}"
    );

    let before = plan_of(&daemon);
    assert_eq!(
        before.collect,
        vec!["obj:orphan".to_owned()],
        "the operator is shown the list first: {before:?}"
    );
    assert!(before.would_run, "{before:?}");

    let accepted = match run(
        &daemon,
        collect(GcCollectRequest::new().with_grace_period_ms(0)),
    )
    .expect("an admin with a key may collect")
    {
        OperationResult::Accepted(accepted) => accepted,
        other => panic!("expected an accepted job, got {other:?}"),
    };
    assert_eq!(
        accepted.estimated_impact,
        caly_api::EstimatedImpact::ReadOnly,
        "a collection reclaims bytes; it does not tell the core to reload: {accepted:?}"
    );
    assert_eq!(daemon.drain_engine_once().expect("drain"), 1);

    // Asserted as "this object is gone and the plan no longer names it", not as a store total: the
    // apply above wrote its own artifact, which a collection cycle must not touch.
    let after = plan_of(&daemon);
    assert!(
        !after.collect.contains(&"obj:orphan".to_owned()),
        "the orphan must no longer be offered for deletion: {after:?}"
    );
    assert_eq!(
        after.retained_total, 0,
        "and it must not have been quietly re-rooted by something: {after:?}"
    );
    assert!(
        !block_on_ready(store.list_objects(&ctx()))
            .expect("no suspension")
            .expect("enumerate")
            .iter()
            .any(|object| object.digest.0 == "obj:orphan"),
        "the metadata record must be gone from the store, not merely from the plan"
    );
    assert!(
        block_on_ready(store.get("obj:orphan", &ctx()))
            .expect("no suspension")
            .expect("read")
            .is_none(),
        "the object must be unreadable, not merely unlisted"
    );

    let notes = doctor_notes(&daemon);
    assert!(
        notes
            .iter()
            .any(|line| line.contains("gc cycle at revision=") && line.contains("deleted=1")),
        "the cycle must be visible to an operator who did not submit it: {notes:?}"
    );
}

/// A refusal is reported as a refused cycle, and the store is untouched. Both halves are asserted
/// together because "the call failed" and "the call did nothing" are different claims.
#[test]
fn a_busy_engine_refuses_the_cycle_and_changes_nothing() {
    let (daemon, store) = booted("collect-busy");
    seed_orphan(&store, "obj:orphan");
    // Something in flight: an apply that has been accepted but not drained.
    caly_daemon::handle_request(
        &daemon,
        Actor::Cli,
        &envelope(
            Role::Admin,
            apply_op("demo-tun-profile"),
            Some("busy-blocker"),
            None,
        ),
    )
    .result
    .expect("the apply is accepted");

    let revision_before = daemon.runtime_snapshot().expect("runtime").state_revision;
    let error = run(
        &daemon,
        collect(GcCollectRequest::new().with_grace_period_ms(0)),
    )
    .expect_err("a collection may not race an in-flight deployment");
    assert_eq!(error.code.as_str(), "UNAVAILABLE", "{error:?}");
    assert!(
        error.retryable,
        "the very reason for the refusal is temporary: {error:?}"
    );
    let detail = error.detail.clone().unwrap_or_default();
    assert!(
        detail.contains("error=storage_busy") && detail.contains("retry_hint=RetryLater"),
        "the machine-readable part of the refusal: {detail}"
    );
    assert_eq!(
        daemon.runtime_snapshot().expect("runtime").state_revision,
        revision_before,
        "a refusal must not advance the revision other callers compare against"
    );
    assert_eq!(
        plan_of(&daemon).objects_total,
        1,
        "and the store must still hold the object it held"
    );
    let notes = doctor_notes(&daemon);
    assert!(
        notes
            .iter()
            .any(|line| line.contains("storage_busy") || line.contains("storage is busy")),
        "the refusal belongs to the operator's view, not only to the caller: {notes:?}"
    );
}

/// `Idempotency::Required` on a destructive command, enforced with the operation named.
#[test]
fn a_keyless_retry_of_a_destructive_command_is_refused_by_name() {
    let (daemon, _store) = booted("collect-keyless");
    let error = caly_daemon::handle_request(
        &daemon,
        Actor::Cli,
        &envelope(Role::Admin, collect(GcCollectRequest::new()), None, None),
    )
    .result
    .expect_err("a cycle with no key could be a second cycle");
    assert_eq!(error.code.as_str(), "CONFIG_INVALID", "{error:?}");
    assert!(
        error.summary.contains("system.gc-collect"),
        "the refusal has to say which operation demanded the key: {}",
        error.summary
    );
}

/// Bounds are the caller's contract: the same `CONFIG_INVALID` the plan query gives, and the store is
/// not consulted at all.
#[test]
fn an_out_of_range_bound_is_refused_before_any_delete_can_happen() {
    let (daemon, _store) = booted("collect-bounds");
    let error = run(
        &daemon,
        collect(GcCollectRequest::new().with_max_deletions(0)),
    )
    .expect_err("`max_deletions: 0` is not a cycle");
    assert_eq!(error.code.as_str(), "CONFIG_INVALID", "{error:?}");
    assert!(
        error.summary.contains("max_deletions must be at least 1"),
        "{}",
        error.summary
    );
    assert!(
        error
            .remediation
            .as_deref()
            .unwrap_or_default()
            .contains("published caps"),
        "a bounds refusal must not be told to go add an idempotency key: {:?}",
        error.remediation
    );
    // ...and it must not be *counted* as one either. `doctor`'s tally is what an operator reads to
    // decide whether callers keep forgetting keys, so folding a new refusal kind into the same code
    // would make that number lie (`docs/ONBOARDING_NOTES.md §4.83`).
    let notes = doctor_notes(&daemon);
    assert!(
        notes
            .iter()
            .any(|line| line.contains("idempotency") && line.contains("keyless_refusals=0")),
        "the counter must stay a fact about keys: {notes:?}"
    );
}

/// A stale `expected_revision` is refused on this command too, because the metadata says
/// `mutates_revision: true`. A cycle that deleted objects after the caller's view had moved would be
/// acting on a plan nobody is looking at any more.
#[test]
fn a_stale_precondition_conflicts_before_the_cycle_runs() {
    let (daemon, _store) = booted("collect-cas");
    daemon
        .submit_request_as_command(
            Actor::Cli,
            &envelope(
                Role::Admin,
                apply_op("demo-tun-profile"),
                Some("cas-apply"),
                None,
            ),
        )
        .expect("accepted");
    daemon.drain_engine_once().expect("drain");

    let error = caly_daemon::handle_request(
        &daemon,
        Actor::Cli,
        &envelope(
            Role::Admin,
            collect(GcCollectRequest::new().with_grace_period_ms(0)),
            Some("cas-collect"),
            Some(u64::MAX - 1),
        ),
    )
    .result
    .expect_err("a stale precondition must not be honoured");
    assert_eq!(error.code.as_str(), "CONFLICT", "{error:?}");
}

/// The role on the operation is the gate, not a label: `Viewer` may not delete, and the refusal is the
/// permission one.
#[test]
fn a_viewer_cannot_start_a_collection_cycle() {
    let (daemon, _store) = booted("collect-role");
    let error = caly_daemon::handle_request(
        &daemon,
        Actor::Cli,
        &envelope(
            Role::Viewer,
            collect(GcCollectRequest::new()),
            Some("collect-role"),
            None,
        ),
    )
    .result
    .expect_err("`Admin` is required, not suggested");
    assert_eq!(error.code.as_str(), "PERMISSION", "{error:?}");
}
