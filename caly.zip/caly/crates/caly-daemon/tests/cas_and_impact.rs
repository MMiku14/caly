//! The two things a `Command` answer has to get right, at the daemon boundary.
//!
//! 1. **CAS** — `RFC-0002 §6.2` makes `ctx.expected_revision` a compare-and-swap precondition. It
//!    was plumbed from `Ctx` into `RequestEnvelope` into `Command.context` and read by nobody, so
//!    "only run this if the state is still at revision N" was decoration.
//! 2. **The reported impact** — `caly-engine::dispatch::classify_command` derives an
//!    `EstimatedImpact` per command kind, and `Accepted` is the only place a caller sees it before
//!    following the job. The daemon used to rebuild the DTO with a hardcoded `ReadOnly`, i.e. every
//!    deployment announced that nothing would change.
//!
//! Both are asserted through `handle_request`, the boundary both façades share, so the check covers
//! what a client actually receives rather than what an internal struct happens to hold.

use caly_api::{
    ApplyRequest, DelayTestRequest, DiagnosticsOp, JobFollowRequest, JobId, Operation, ProfileOp,
    ProtocolVersion, ProxyOp, RequestEnvelope, RequestId, ResponseEnvelope, Role, SelectNode,
    TraceId,
};
use caly_common::Actor;
use caly_daemon::{handle_request, DaemonApp, DaemonBootstrapConfig};

fn daemon(tag: &str) -> DaemonApp {
    DaemonApp::bootstrap(DaemonBootstrapConfig {
        instance_id: tag.to_owned(),
        protocol_version: ProtocolVersion { major: 1, minor: 0 },
        recover_on_start: false,
    })
}

fn envelope(operation: Operation, id: u64, expected_revision: Option<u64>) -> RequestEnvelope {
    RequestEnvelope {
        protocol: ProtocolVersion { major: 1, minor: 0 },
        request_id: RequestId(id),
        trace_id: TraceId::new(format!("cas-{id}")),
        deadline_ms: None,
        expected_revision,
        // `Idempotency::Required` commands are refused without a key (`ADR-037 §2.3`), so the
        // helper mints one per request id: unique per submission, which is exactly what "a
        // different write" means to the dedup window.
        idempotency_key: Some(format!("cas-{id}")),
        role: Role::Admin,
        io_budget: None,
        operation,
    }
}

fn apply_operation(profile_id: &str) -> Operation {
    Operation::Profile(ProfileOp::Apply {
        request: ApplyRequest {
            profile_id: caly_api::ProfileId(profile_id.to_owned()),
            dry_run: false,
            strict: false,
        },
    })
}

fn revision(app: &DaemonApp) -> u64 {
    app.runtime_snapshot().expect("runtime").state_revision
}

#[test]
fn a_stale_expected_revision_is_refused_before_anything_is_queued() {
    let app = daemon("cas-stale");
    let current = revision(&app);
    let response = handle_request(
        &app,
        Actor::Cli,
        &envelope(apply_operation("demo-tun-profile"), 1, Some(current + 4)),
    );
    let ResponseEnvelope {
        result: Err(error), ..
    } = &response
    else {
        panic!(
            "a stale revision must be refused, got {:?}",
            response.result
        );
    };
    assert_eq!(error.code, caly_api::ErrorCode::Conflict, "{error:?}");
    assert_eq!(error.category, caly_api::ErrorCategory::Config, "{error:?}");
    assert!(
        !error.retryable,
        "retrying the same expectation cannot succeed"
    );
    assert!(
        error
            .summary
            .contains(&format!("is stale; the daemon is at {current}")),
        "the message has to say both numbers: {}",
        error.summary
    );
    assert!(
        error
            .remediation
            .as_deref()
            .unwrap_or_default()
            .contains("state_revision"),
        "{:?}",
        error.remediation
    );
    // Refused means nothing was queued: no job exists at all.
    let follow = app.follow_job_projection(JobId(1), None).expect("follow");
    assert!(
        follow.is_none(),
        "a refused command must not leave a job behind"
    );
}

#[test]
fn a_matching_revision_is_accepted_and_a_second_one_is_not() {
    let app = daemon("cas-current");
    let current = revision(&app);
    let accepted = match handle_request(
        &app,
        Actor::Cli,
        &envelope(apply_operation("demo-tun-profile"), 1, Some(current)),
    )
    .result
    {
        Ok(caly_api::OperationResult::Accepted(accepted)) => accepted,
        other => panic!("expected acceptance, got {other:?}"),
    };
    assert_eq!(
        accepted.estimated_impact,
        caly_api::EstimatedImpact::Restart
    );
    assert_eq!(app.drain_engine_once().expect("drain"), 1);

    // The same expectation again is now stale: accepting it would make CAS meaningless.
    let second = handle_request(
        &app,
        Actor::Cli,
        &envelope(apply_operation("demo-tun-profile"), 2, Some(current)),
    );
    assert!(
        matches!(&second.result, Err(error) if error.code == caly_api::ErrorCode::Conflict),
        "the daemon advanced, so the old expectation must be refused: {:?}",
        second.result
    );
}

#[test]
fn a_replayed_command_is_not_blocked_by_the_cas_check() {
    // Ordering matters: the point of an idempotency key is that a *retry* — which necessarily carries
    // the revision the caller read before the first attempt landed — returns the original job rather
    // than a conflict. Checking CAS first would turn every retried write into a failure.
    let app = daemon("cas-replay");
    let current = revision(&app);

    let first = app
        .submit_request_as_command(
            Actor::Cli,
            &envelope_with(apply_operation("demo-tun-profile"), 1, current, "retry-me"),
        )
        .expect("accepted")
        .expect("maps to a command");
    assert!(!first.reused_existing_job);
    assert_eq!(app.drain_engine_once().expect("drain"), 1);
    assert!(
        revision(&app) != current,
        "the deployment has to have moved the daemon, or the replay is not exercising a stale expectation"
    );

    let replayed = app
        .submit_request_as_command(
            Actor::Cli,
            &envelope_with(apply_operation("demo-tun-profile"), 2, current, "retry-me"),
        )
        .expect("a replay must not be refused by CAS")
        .expect("maps to a command");

    assert!(
        replayed.reused_existing_job,
        "the second call should have resolved to the recorded job"
    );
    assert_eq!(
        replayed.accepted, first.accepted,
        "a replay answers with the original response, impact and revision included"
    );
}

fn envelope_with(
    operation: Operation,
    id: u64,
    expected_revision: u64,
    key: &str,
) -> RequestEnvelope {
    RequestEnvelope {
        expected_revision: Some(expected_revision),
        idempotency_key: Some(key.to_owned()),
        ..envelope(operation, id, None)
    }
}

#[test]
fn each_command_kind_reports_the_impact_the_engine_derived() {
    let app = daemon("impact");
    let cases: [(Operation, &str, caly_api::EstimatedImpact); 3] = [
        (
            apply_operation("demo-tun-profile"),
            "apply",
            caly_api::EstimatedImpact::Restart,
        ),
        (
            Operation::Proxy(ProxyOp::TestDelay {
                request: DelayTestRequest {
                    node_ids: vec![caly_api::NodeId("n1".to_owned())],
                },
            }),
            "test-delay",
            caly_api::EstimatedImpact::ReadOnly,
        ),
        (
            Operation::Proxy(ProxyOp::Select {
                request: SelectNode {
                    group_id: caly_api::GroupId("g1".to_owned()),
                    node_id: caly_api::NodeId("n1".to_owned()),
                },
            }),
            "select",
            caly_api::EstimatedImpact::Reload,
        ),
    ];
    for (index, (operation, label, expected)) in cases.into_iter().enumerate() {
        let response = handle_request(
            &app,
            Actor::Cli,
            &envelope(operation, index as u64 + 1, None),
        );
        let accepted = match response.result {
            Ok(caly_api::OperationResult::Accepted(accepted)) => accepted,
            other => panic!("{label}: expected acceptance, got {other:?}"),
        };
        assert_eq!(
            accepted.estimated_impact, expected,
            "{label}: the dispatch classification never reached the caller"
        );
        assert_eq!(app.drain_engine_once().expect("drain"), 1, "{label}");
    }
}

/// The `FollowJob` query is unaffected by any of this: it is a query and carries no CAS meaning.
#[test]
fn queries_ignore_the_cas_field_entirely() {
    let app = daemon("cas-query");
    let response = handle_request(
        &app,
        Actor::Cli,
        &envelope(
            Operation::Diagnostics(DiagnosticsOp::FollowJob {
                request: JobFollowRequest {
                    job_id: JobId(7),
                    from_event_index: None,
                },
            }),
            1,
            Some(u64::MAX),
        ),
    );
    match response.result {
        // Both this and a CAS miss are `CONFLICT`, so the *message* is what proves the query path
        // never looked at `expected_revision`.
        Err(error) => {
            assert_eq!(error.code, caly_api::ErrorCode::Conflict, "{error:?}");
            assert!(
                error.summary.contains("no such job: 7"),
                "the refusal must be about the missing job, not the revision: {}",
                error.summary
            );
        }
        other => panic!("expected the typed unknown-job refusal, got {other:?}"),
    }
}
