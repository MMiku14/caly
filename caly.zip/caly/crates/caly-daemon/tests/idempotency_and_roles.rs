//! Who a local caller is, and what a high-risk write has to bring with it.
//!
//! `RFC-0002 §7.2` makes `required_role` and `idempotency` part of an operation's metadata, and
//! `ADR-037` (ratified this round) settles who supplies each:
//!
//! * the **role** is the caller's identity, and neither path may assume the highest one. Both façades
//!   used to hardcode `Role::Admin`, which made the permission check unfailable — a gate that cannot
//!   refuse is decoration;
//! * the **idempotency key** is the caller's, and a `Required` command without one is refused rather
//!   than guessed at. Guessing was tried first and the write-parity harness refuted it
//!   (`docs/ONBOARDING_NOTES.md §4.63`).
//!
//! These tests run through `handle_request`, i.e. the same boundary both façades forward to, so a rule
//! that only one path enforces has nowhere to hide.

use std::future::Future;
use std::pin::pin;
use std::task::{Context, Poll, Waker};

use caly_api::{
    ApplyRequest, CalyFacade, DelayTestRequest, DiagnosticsOp, DoctorRequest, ErrorCategory,
    ErrorCode, NetworkOp, Operation, ProfileOp, ProtocolVersion, ProxyOp, RequestEnvelope,
    ResponseEnvelope, Role, TraceId,
};
use caly_common::Actor;
use caly_daemon::{handle_request, DaemonApp, DaemonBootstrapConfig, LocalFacade};

/// The local façade's methods resolve on first poll; a suspension here would mean someone made the
/// in-process path await real I/O, which is worth failing on rather than hanging on.
fn ready<T, E: std::fmt::Debug>(future: impl Future<Output = Result<T, E>>) -> Result<T, E> {
    let mut cx = Context::from_waker(Waker::noop());
    let mut future = pin!(future);
    match future.as_mut().poll(&mut cx) {
        Poll::Ready(value) => value,
        Poll::Pending => panic!("a loopback façade call suspended"),
    }
}

fn daemon(tag: &str) -> DaemonApp {
    DaemonApp::bootstrap(DaemonBootstrapConfig {
        instance_id: tag.to_owned(),
        protocol_version: ProtocolVersion { major: 1, minor: 0 },
        recover_on_start: false,
    })
}

fn envelope(operation: Operation, id: u64, key: Option<&str>) -> RequestEnvelope {
    RequestEnvelope {
        protocol: ProtocolVersion { major: 1, minor: 0 },
        request_id: caly_api::RequestId(id),
        trace_id: TraceId::new(format!("idem-{id}")),
        deadline_ms: None,
        expected_revision: None,
        idempotency_key: key.map(str::to_owned),
        role: Role::Operator,
        io_budget: None,
        operation,
    }
}

fn apply(id: u64, key: Option<&str>) -> RequestEnvelope {
    envelope(
        Operation::Profile(ProfileOp::Apply {
            request: ApplyRequest {
                profile_id: caly_api::ProfileId("demo-tun-profile".to_owned()),
                dry_run: false,
                strict: false,
            },
        }),
        id,
        key,
    )
}

fn refusal(response: &ResponseEnvelope) -> &caly_api::ApiError {
    match &response.result {
        Err(error) => error,
        ok => panic!("expected a refusal, got {ok:?}"),
    }
}

#[test]
fn a_required_command_without_a_key_is_refused_before_the_engine_sees_it() {
    let app = daemon("keyless-refusal");
    let response = handle_request(&app, Actor::Cli, &apply(1, None));
    let error = refusal(&response);
    assert_eq!(error.code, ErrorCode::ConfigInvalid, "{error:?}");
    assert_eq!(error.category, ErrorCategory::User, "{error:?}");
    assert!(
        !error.retryable,
        "the same request cannot succeed: {error:?}"
    );
    assert!(error.summary.contains("profile.apply"), "{error:?}");
    assert!(error.summary.contains("idempotency_key"), "{error:?}");
    assert!(
        error
            .remediation
            .as_deref()
            .unwrap_or_default()
            .contains("mint a fresh value per distinct write"),
        "the refusal has to say what to do instead: {error:?}"
    );
    assert!(
        !error.summary.contains("no daemon handler"),
        "a refusal must not be reported as an unimplemented operation: {error:?}"
    );

    // Nothing reached the engine: no job exists, and the revision did not move.
    assert!(
        app.follow_job_projection(caly_api::JobId(1), None)
            .expect("follow")
            .is_none(),
        "a refused submission still created a job"
    );
    assert_eq!(app.runtime_snapshot().expect("runtime").state_revision, 0);
    let (_, _, _, refusals) = app.idempotency_stats().expect("stats");
    assert_eq!(
        refusals, 1,
        "the daemon must be able to say how often this happened"
    );
}

/// A blank key is worse than no key: it is a *shared* bucket. Every caller that "supplied" one lands in
/// the same dedup slot, which is how a fabricated constant key silently swallowed repeat deployments in
/// round 9 (`docs/ONBOARDING_NOTES.md §4.37`) — so the shape is refused on sight, for every operation,
/// not only the `Required` ones.
#[test]
fn a_blank_key_is_refused_for_any_command_because_it_is_a_shared_bucket() {
    let app = daemon("blank-key");
    for key in ["", "   "] {
        let response = handle_request(&app, Actor::Cli, &apply(2, Some(key)));
        let error = refusal(&response);
        assert_eq!(error.code, ErrorCode::ConfigInvalid, "{key:?}: {error:?}");
        assert!(
            error.summary.contains("supplied empty"),
            "{key:?}: {error:?}"
        );
    }
    // An `Optional` command is refused for the same reason even though it does not need a key.
    let delay = handle_request(
        &app,
        Actor::Cli,
        &envelope(
            Operation::Proxy(ProxyOp::TestDelay {
                request: DelayTestRequest {
                    node_ids: vec![caly_api::NodeId("hk".to_owned())],
                },
            }),
            3,
            Some(""),
        ),
    );
    assert_eq!(
        refusal(&delay).code,
        ErrorCode::ConfigInvalid,
        "an empty key on an Optional command is still a shared bucket: {:?}",
        refusal(&delay)
    );
    // …while omitting it entirely is fine for that command (`§5.2` supports, `§8.3` requires).
    let keyed_fine = handle_request(
        &app,
        Actor::Cli,
        &envelope(
            Operation::Proxy(ProxyOp::TestDelay {
                request: DelayTestRequest {
                    node_ids: vec![caly_api::NodeId("hk".to_owned())],
                },
            }),
            4,
            None,
        ),
    );
    assert!(
        matches!(
            keyed_fine.result,
            Ok(caly_api::OperationResult::Accepted(_))
        ),
        "an Optional command must still run keyless: {:?}",
        keyed_fine.result
    );
}

/// Which refusal wins when a request is wrong in two ways at once.
///
/// `CONFIG_INVALID` on purpose, and deliberately asserted so the order cannot flip unnoticed: the key
/// rule is about the request, the CAS is about the daemon's state, and a caller can only act on the
/// thing it controls. It is also the same reasoning `§4.54` used for a bad page bound on a missing job.
#[test]
fn a_keyless_request_with_a_stale_revision_is_refused_for_the_key() {
    let app = daemon("precedence");
    let mut request = apply(5, None);
    request.expected_revision = Some(u64::MAX - 1);
    let response = handle_request(&app, Actor::Cli, &request);
    let error = refusal(&response);
    assert_eq!(error.code, ErrorCode::ConfigInvalid, "{error:?}");
    assert_ne!(error.code, ErrorCode::Conflict, "{error:?}");

    // …and the identity gate comes before both, because "you may not do this at all" makes the rest of
    // the request moot: an under-privileged *and* keyless submission reports `PERMISSION`.
    let under_privileged = handle_request(
        &app,
        Actor::Cli,
        &envelope(Operation::Network(NetworkOp::Repair), 12, None),
    );
    assert_eq!(
        refusal(&under_privileged).code,
        ErrorCode::Permission,
        "{:?}",
        refusal(&under_privileged)
    );
}

#[test]
fn the_local_path_is_operator_by_default_and_says_so_in_the_refusal() {
    let app = daemon("local-role");
    assert_eq!(
        app.local_role().expect("role"),
        Role::Operator,
        "the local path used to hand out Admin to every call (`ADR-037 §2.2`)"
    );

    let local = LocalFacade::new(app.clone());
    let error = ready(local.network().repair(caly_api::Ctx::new(
        TraceId::new("repair-default-role"),
        Actor::Cli,
    )))
    .expect_err("an Operator may not repair the network");
    assert_eq!(error.code, ErrorCode::Permission, "{error:?}");
    assert!(
        error.summary.contains("Admin"),
        "the refusal must name the role that is missing: {error:?}"
    );
    assert!(!error.retryable, "{error:?}");

    // Granting the role is the composition root's decision, and it is the *façade* that reads it: an
    // envelope built by hand still carries whatever role its author chose, which is exactly why the
    // façade is the place this has to be settled.
    app.set_local_role(Role::Admin).expect("role set");
    let granted = ready(
        local.network().repair(
            caly_api::Ctx::new(TraceId::new("repair-granted"), Actor::Cli)
                // Keyed, because `network.repair` is `Required` too; this half is about the role gate.
                .with_idempotency_key("repair-granted"),
        ),
    );
    assert!(
        granted.is_ok(),
        "an Admin-authorized repair must be accepted: {:?}",
        granted.err()
    );
}

/// The parity half: an embedded caller and a session client with the same role must be refused with the
/// same words. `required_role` was unfailable on both paths before, so this comparison could not exist.
#[test]
fn the_same_role_refusal_comes_back_over_both_access_paths() {
    let app = daemon("role-parity");
    let mut client =
        caly_daemon::LoopbackHarness::new(caly_daemon::LoopbackHarnessConfig::default());
    client.handshake().expect("loopback handshake");

    // The harness formats refusals as `CODE: summary` (round 13), so that is the shape compared — the
    // point is that the *same* text comes back whichever path carried the request.
    let describe =
        |error: &caly_api::ApiError| format!("{}: {}", error.code.as_str(), error.summary);

    // In-process, through the façade the embedded caller uses.
    let local = LocalFacade::new(app.clone());
    let local_error = ready(
        local
            .network()
            .repair(caly_api::Ctx::new(TraceId::new("repair-local"), Actor::Cli)),
    )
    .expect_err("an Operator may not repair the network");
    // Over the loopback transport, whose session negotiated `Operator` as well.
    let remote_error = client
        .send_operation(
            "repair-remote",
            Operation::Network(NetworkOp::Repair),
            Some("repair-remote".to_owned()),
        )
        .expect_err("the same command must be refused over the transport too");

    let local = describe(&local_error);
    assert!(
        local.contains("PERMISSION") && local.contains("Admin"),
        "the local refusal is not the permission gate: {local_error:?}"
    );
    assert!(
        remote_error.contains("PERMISSION") && remote_error.contains("Admin"),
        "the transport path lost the refusal's code or wording: {remote_error}"
    );
    // Same words, not just the same code: the reason is what a caller acts on.
    assert_eq!(
        remote_error, local,
        "the same role got a different refusal per path"
    );
}

/// `RequestId` used to be `0` on every local call, and `Command.id` is derived from it — so every local
/// command was `req-0`, which is not an identity an audit trail can use.
#[test]
fn local_calls_get_their_own_request_identity() {
    let app = daemon("request-ids");
    let local = LocalFacade::new(app.clone());
    let mut accepted = Vec::new();
    for profile in ["profile-one", "profile-two", "profile-three"] {
        let ctx = caly_api::Ctx::new(TraceId::new(profile), Actor::Cli)
            .with_idempotency_key(format!("ids-{profile}"));
        accepted.push(
            ready(local.profile().apply(
                ctx,
                ApplyRequest {
                    profile_id: caly_api::ProfileId(profile.to_owned()),
                    dry_run: false,
                    strict: true,
                },
            ))
            .expect("accepted")
            .job_id,
        );
    }
    let distinct: Vec<_> = {
        let mut ids = accepted.clone();
        ids.sort_unstable();
        ids.dedup();
        ids
    };
    assert_eq!(
        distinct.len(),
        3,
        "three local writes produced the same job: {accepted:?}"
    );

    // The command ids in the event log are derived from the request id, and they are what an audit
    // trail has to work with. They used to all read `req-0`.
    let window = app.event_window(None).expect("event window");
    let command_ids: Vec<String> = window
        .events
        .iter()
        .filter_map(|event| event.command_id.clone())
        .collect();
    let unique: Vec<&String> = {
        let mut seen: Vec<&String> = Vec::new();
        for id in &command_ids {
            if !seen.contains(&id) {
                seen.push(id);
            }
        }
        seen
    };
    assert!(
        command_ids.len() >= 3,
        "no command ids were recorded at all: {command_ids:?}"
    );
    assert_eq!(
        unique.len(),
        command_ids.len(),
        "local commands share a command id, so the audit trail cannot separate them: {command_ids:?}"
    );
    for id in &unique {
        assert!(id.starts_with("req-"), "unexpected id shape: {id}");
        assert_ne!(id.as_str(), "req-0", "the constant request id is back");
    }
}

/// The durable half of the same rule: the operator needs to be able to see that callers keep getting
/// refused, because each refusal otherwise disappears into the caller's own error handling.
#[test]
fn refusals_are_counted_where_an_operator_will_look() {
    let app = daemon("refusal-tally");
    for index in 1..=3 {
        assert!(
            refusal(&handle_request(&app, Actor::Cli, &apply(index, None)))
                .summary
                .contains("idempotency_key")
        );
    }
    let doctor = handle_request(
        &app,
        Actor::Cli,
        &envelope(
            Operation::Diagnostics(DiagnosticsOp::Doctor {
                request: DoctorRequest {
                    include_runtime: true,
                },
            }),
            40,
            None,
        ),
    );
    let report = match doctor.result.expect("doctor") {
        caly_api::OperationResult::DoctorReport(report) => report,
        other => panic!("{other:?}"),
    };
    let note = report
        .notes
        .iter()
        .find(|line| line.contains("idempotency entries="))
        .expect("the doctor must report the dedup window it is enforcing");
    assert!(note.contains("keyless_refusals=3"), "{note}");
    assert!(note.contains("finished_window="), "{note}");
    assert!(note.contains("local role Operator"), "{note}");
    // Counted once per refusal, not once per retry of the same refusal.
    let (_, _, _, refusals) = app.idempotency_stats().expect("stats");
    assert_eq!(refusals, 3);
}
