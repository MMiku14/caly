//! The Deployment stream's producer (`IPC_STREAM_POLICY §7`, round 130 — `ROADMAP §12#4`).
//!
//! `StreamKind::Deployment` had a policy (`LosslessResumable`, ack `Required`) and a payload
//! mapping in the watch bridge, but no way to be opened and no production semantics: the
//! bridge admitted every engine event to every kind, so "a deployment stream" was
//! indistinguishable from a dashboard stream. These judges pin the producer that round 130
//! gave it:
//!
//! * the open goes through the real request path (`RuntimeOp::Watch { subscription: Deployment }`);
//! * per-frame production is the kind's own semantics — deployment events ONLY, minted
//!   exactly when a deployment-mutating event occurs, never for the unrelated events sharing
//!   the window (seqs stay the shared window's, so resume/reset are the window's too);
//! * lossless resume from a cursor;
//! * the slow-client policy: fall behind retention → a named `Reset`, and — new this round —
//!   the pressure is RECORDED (`OVERLOAD_AND_RETRY_MODEL §3.2/§3.3` finally have producers):
//!   `EventBacklog` where the engine observes the roll, `StreamBackpressure` where the Reset
//!   is minted, both visible to `doctor` via `overload_lines`.

use caly_api::{
    ApplyRequest, Operation, ProfileId, ProfileOp, ProtocolVersion, RequestEnvelope, RequestId,
    Role, RuntimeOp, RuntimeSubscription, StreamId, TraceId,
};
use caly_common::Actor;
use caly_daemon::{
    handle_request, DaemonApp, DaemonBootstrapConfig, DaemonSession, MAX_WATCH_FRAMES_PER_PULL,
};
use caly_engine::EventKind;
use caly_ipc::{
    ClientHello, ClientKind, Compression, Encoding, NegotiationPolicy, ResetReason, StreamFrame,
    StreamKind, StreamPayload,
};

fn daemon(tag: &str) -> DaemonApp {
    DaemonApp::bootstrap(DaemonBootstrapConfig {
        instance_id: tag.to_owned(),
        protocol_version: ProtocolVersion { major: 1, minor: 0 },
        recover_on_start: false,
    })
}

fn envelope(operation: Operation, id: u64) -> RequestEnvelope {
    RequestEnvelope {
        protocol: ProtocolVersion { major: 1, minor: 0 },
        request_id: RequestId(id),
        trace_id: TraceId::new(format!("deployment-stream-{id}")),
        deadline_ms: None,
        expected_revision: None,
        idempotency_key: Some(format!("deployment-stream-{id}")),
        role: Role::Admin,
        io_budget: None,
        operation,
    }
}

/// One real apply of the demo profile, drained to completion — each apply ends in exactly one
/// `DeploymentChanged` event (the worker's `succeed` narrative) among the several events it
/// puts on the shared log. That mix is what the per-kind filter is judged against.
fn apply_once(daemon: &DaemonApp, id: u64) {
    let accepted = handle_request(
        daemon,
        Actor::Cli,
        &envelope(
            Operation::Profile(ProfileOp::Apply {
                request: ApplyRequest {
                    profile_id: ProfileId("demo-tun-profile".to_owned()),
                    dry_run: false,
                    strict: false,
                },
            }),
            id,
        ),
    );
    assert!(
        matches!(accepted.result, Ok(caly_api::OperationResult::Accepted(_))),
        "the demo apply must be accepted: {:?}",
        accepted.result
    );
    assert_eq!(daemon.drain_engine_once().expect("drain"), 1);
}

fn handshake(daemon: &DaemonApp) -> DaemonSession {
    let mut session = DaemonSession::new(Actor::System, NegotiationPolicy::default());
    session
        .accept_hello(
            daemon,
            &ClientHello {
                protocol: ProtocolVersion { major: 1, minor: 0 },
                client_kind: ClientKind::Tui,
                client_name: "deployment-stream-judge".to_owned(),
                requested_encoding: Encoding::Json,
                requested_compression: Compression::None,
                supported_features: Vec::new(),
                role: Role::Admin,
            },
            "deployment-stream-session",
        )
        .expect("hello");
    session
}

fn open_deployment_watch(
    daemon: &DaemonApp,
    session: &mut DaemonSession,
    request_id: u64,
) -> StreamId {
    let opened = session
        .handle_request(
            daemon,
            &envelope(
                Operation::Runtime(RuntimeOp::Watch {
                    subscription: RuntimeSubscription::Deployment,
                }),
                request_id,
            ),
        )
        .expect("watch request");
    let Ok(caly_api::OperationResult::WatchOpened(opened)) = opened.result else {
        panic!("a deployment watch must open, not {opened:?}");
    };
    assert_eq!(opened.subscription_kind, "deployment");
    opened.stream_id
}

fn pull(daemon: &DaemonApp, session: &mut DaemonSession, stream: StreamId) -> Vec<StreamFrame> {
    session
        .follow_opened_stream(daemon, stream, None)
        .expect("pull")
        .into_iter()
        .map(|frame| match frame {
            caly_ipc::ServerFrame::Stream(frame) => frame,
            other => panic!("a stream pull yields stream frames, not {other:?}"),
        })
        .collect()
}

fn deployment_frames(frames: &[StreamFrame]) -> Vec<&StreamFrame> {
    frames
        .iter()
        .filter(|frame| matches!(frame.payload, StreamPayload::DeploymentEvent { .. }))
        .collect()
}

/// Every seq on the shared log that a deployment event was minted at, for asserting the
/// stream's frames against the log itself (the log is the oracle, the stream is the subject).
fn deployment_seqs(daemon: &DaemonApp) -> Vec<u64> {
    daemon
        .event_window(None)
        .expect("window")
        .events
        .iter()
        .filter(|event| event.kind == EventKind::DeploymentChanged)
        .map(|event| event.seq.0)
        .collect()
}

/// The whole point of the kind: a deployment watch replays the retained window's DEPLOYMENT
/// events and nothing else. The shared log carries command/job/runtime events too (more of
/// them than deployment events — that asymmetry is asserted, not assumed), and none of them
/// may surface as a frame on this stream.
#[test]
fn a_deployment_watch_replays_only_deployment_events_from_the_retained_window() {
    let daemon = daemon("deployment-replay");
    for id in 1..=3 {
        apply_once(&daemon, id);
    }
    let total = daemon.event_window(None).expect("window");
    let expected = deployment_seqs(&daemon);
    assert_eq!(
        expected.len(),
        3,
        "three applies mint three deployment events"
    );
    assert!(
        total.events.len() > expected.len(),
        "the fixture must put non-deployment events on the shared log ({} total, {} deployment)",
        total.events.len(),
        expected.len()
    );

    let mut session = handshake(&daemon);
    let stream = open_deployment_watch(&daemon, &mut session, 4);
    let frames = pull(&daemon, &mut session, stream);

    assert!(
        frames
            .iter()
            .all(|frame| frame.kind == StreamKind::Deployment),
        "every frame carries the stream's own kind: {frames:?}"
    );
    let got: Vec<u64> = frames.iter().map(|frame| frame.seq).collect();
    assert_eq!(
        got, expected,
        "the replay is the deployment events, in log order, at their own seqs"
    );
    for frame in &frames {
        assert!(
            matches!(frame.payload, StreamPayload::DeploymentEvent { .. }),
            "a deployment stream carries deployment events only, not {:?}",
            frame.payload
        );
    }
}

/// After the replay, new applies surface as exactly their deployment events — the
/// command/job/runtime events of the same apply never mint frames here.
#[test]
fn a_deployment_watch_delivers_only_the_new_deployment_events_after_a_pull() {
    let daemon = daemon("deployment-live");
    apply_once(&daemon, 1);
    let mut session = handshake(&daemon);
    let stream = open_deployment_watch(&daemon, &mut session, 2);
    let replay = pull(&daemon, &mut session, stream);
    assert_eq!(deployment_frames(&replay).len(), 1);

    apply_once(&daemon, 3);
    let before = daemon.event_window(None).expect("window").next_seq;
    let frames = pull(&daemon, &mut session, stream);
    let next = daemon.event_window(None).expect("window").next_seq;
    assert_eq!(before, next, "a pull must not advance the log");

    let expected: Vec<u64> = deployment_seqs(&daemon)
        .into_iter()
        .filter(|seq| *seq > replay[replay.len() - 1].seq)
        .collect();
    let got: Vec<u64> = frames.iter().map(|frame| frame.seq).collect();
    assert_eq!(
        got, expected,
        "exactly the new deployment events, at their seqs"
    );
    assert!(
        frames
            .iter()
            .all(|frame| matches!(frame.payload, StreamPayload::DeploymentEvent { .. })),
        "no interleaved non-deployment event may mint a frame: {frames:?}"
    );
    assert!(
        frames.len() <= MAX_WATCH_FRAMES_PER_PULL,
        "a pull stays bounded: {}",
        frames.len()
    );
}

/// The lossless half of the policy: an explicit cursor resumes after it — the deployment
/// events before the cursor are NOT re-delivered, the ones after it all are.
#[test]
fn a_deployment_watch_resumes_from_an_explicit_cursor() {
    let daemon = daemon("deployment-resume");
    for id in 1..=3 {
        apply_once(&daemon, id);
    }
    let seqs = deployment_seqs(&daemon);
    assert_eq!(seqs.len(), 3);
    let cursor = seqs[0];

    let mut session = handshake(&daemon);
    let stream = open_deployment_watch(&daemon, &mut session, 4);
    let frames = session
        .follow_opened_stream(&daemon, stream, Some(cursor))
        .expect("resume pull")
        .into_iter()
        .map(|frame| match frame {
            caly_ipc::ServerFrame::Stream(frame) => frame,
            other => panic!("a stream pull yields stream frames, not {other:?}"),
        })
        .collect::<Vec<_>>();

    let got: Vec<u64> = frames.iter().map(|frame| frame.seq).collect();
    assert_eq!(
        got,
        seqs[1..],
        "resume is exclusive of the cursor and lossless after it"
    );
}

/// The slow-client policy, now with its recorded half: a watcher parked while the window
/// rolls past it gets the named `Reset` (the frame — the client is told), AND the pressure
/// lands in `overload_lines` (the report — `doctor` is told): `StreamBackpressure` minted
/// where the Reset is, `EventBacklog` recorded where the engine observed the roll.
#[test]
fn a_deployment_watch_that_falls_behind_gets_a_reset_and_the_pressure_is_recorded() {
    let daemon = daemon("deployment-laggard");
    apply_once(&daemon, 1);
    let mut session = handshake(&daemon);
    let stream = open_deployment_watch(&daemon, &mut session, 2);
    let replay = pull(&daemon, &mut session, stream);
    assert_eq!(deployment_frames(&replay).len(), 1);
    let parked_at = replay[replay.len() - 1].seq;

    for id in 3..=70 {
        apply_once(&daemon, id);
    }
    let window = daemon.event_window(None).expect("window");
    assert!(
        window.retained_from.0 > parked_at + 1,
        "the fixture must actually age the cursor out (retained from {}, parked at {parked_at})",
        window.retained_from.0
    );
    assert!(
        daemon.overload_lines().expect("lines").is_empty(),
        "a healthy daemon reports no pressure"
    );

    let frames = pull(&daemon, &mut session, stream);
    assert!(
        !frames.is_empty(),
        "the daemon must answer the stalled pull"
    );
    assert!(
        frames.iter().any(|frame| matches!(
            frame.payload,
            StreamPayload::Reset {
                reason: ResetReason::StateGapTooLarge
            }
        )),
        "a stalled deployment watcher is told to re-open by name: {frames:?}"
    );

    let lines = daemon.overload_lines().expect("lines");
    let backlog = lines
        .iter()
        .find(|line| line.starts_with("overload event_backlog:"))
        .expect("the engine recorded the window roll");
    assert!(
        backlog.contains("hint ReopenSession"),
        "the EventBacklog line carries its hint: {backlog}"
    );
    let pressure = lines
        .iter()
        .find(|line| line.starts_with("overload stream_backpressure:"))
        .expect("the bridge recorded the abandoned contract");
    assert!(
        pressure.contains("Deployment") && pressure.contains(&format!("stream {}", stream.0)),
        "the StreamBackpressure line names the kind and the stream: {pressure}"
    );
}
