//! The caller's context, end to end: façade → daemon query → engine → store (`ADR-039 §2`, step 4).
//!
//! Rounds 33–35 built the three doors at the store seam -- attribution (`ctx` on every method,
//! the port sees the caller's trace), the cumulative byte meter, and the deadline -- but the
//! engine answered every synchronous request with its **self-labelled** context
//! (`engine-storage`), so no real caller had ever passed through them. This file pins the first
//! vertical where one does: the support-bundle read-back (`RFC-0010 §12.2`, the path
//! `§4.45` opened), from `handle_request` down to the port.
//!
//! * **Budget**: an envelope that states `io_budget.max_bytes` has the *caller's* meter refuse
//!   the read -- round 34's door, live for a real caller through the façade.
//! * **Deadline**: an envelope that states `deadline_ms` gets it converted against the injected
//!   storage clock and refused as `Timeout` -- round 35's door, ditto.
//! * **Attribution**: during the read, the port answers to the caller's trace -- never to the
//!   engine's ghost -- round 33's door, ditto.
//! * **No drift**: the same request without a stated budget or deadline reads the bundle back
//!   exactly as before.

use std::sync::{Arc, Mutex};

use caly_api::{
    DiagnosticsOp, Operation, ProtocolVersion, RequestEnvelope, RequestId, Role,
    SupportBundleReadRequest,
};
use caly_common::{Actor, TraceId};
use caly_daemon::{DaemonApp, DaemonBootstrapConfig};
use caly_io::{block_on_ready, ByteCap, Durability, Fs, IoContext, ListCap, VPath};
use caly_io_std::StdFs;
use caly_storage::cas::{CasObjectRef, CasWriteIntent, ObjectDigest, ObjectKind};
use caly_storage::fs_store::FsStore;
use caly_storage::{ObjectStore, StorageBackend};

const ROOT: &str = "var/caly";
static SCRITH_SEQ: std::sync::atomic::AtomicUsize = std::sync::atomic::AtomicUsize::new(0);
const SEED_TRACE: &str = "seed-write";

/// A port that records whose trace it was asked to work for.
struct ProbeFs {
    inner: Box<dyn Fs>,
    seen: Arc<Mutex<Vec<String>>>,
}

impl Fs for ProbeFs {
    fn read<'a>(
        &'a self,
        path: &'a VPath,
        cap: ByteCap,
        ctx: &'a IoContext,
    ) -> caly_io::BoxFuture<'a, Result<caly_io::Bytes, caly_io::IoFault>> {
        self.seen
            .lock()
            .expect("probe lock")
            .push(ctx.trace_id.0.clone());
        self.inner.read(path, cap, ctx)
    }
    fn open_stream<'a>(
        &'a self,
        path: &'a VPath,
        ctx: &'a IoContext,
    ) -> caly_io::BoxFuture<'a, Result<caly_io::ByteStream, caly_io::IoFault>> {
        self.inner.open_stream(path, ctx)
    }
    fn write_atomic<'a>(
        &'a self,
        path: &'a VPath,
        data: caly_io::Bytes,
        durability: Durability,
        ctx: &'a IoContext,
    ) -> caly_io::BoxFuture<'a, Result<(), caly_io::IoFault>> {
        self.inner.write_atomic(path, data, durability, ctx)
    }
    fn rename<'a>(
        &'a self,
        from: &'a VPath,
        to: &'a VPath,
        durability: Durability,
        ctx: &'a IoContext,
    ) -> caly_io::BoxFuture<'a, Result<(), caly_io::IoFault>> {
        self.inner.rename(from, to, durability, ctx)
    }
    fn remove<'a>(
        &'a self,
        path: &'a VPath,
        ctx: &'a IoContext,
    ) -> caly_io::BoxFuture<'a, Result<(), caly_io::IoFault>> {
        self.inner.remove(path, ctx)
    }
    fn stat<'a>(
        &'a self,
        path: &'a VPath,
        ctx: &'a IoContext,
    ) -> caly_io::BoxFuture<'a, Result<Option<caly_io::Meta>, caly_io::IoFault>> {
        self.inner.stat(path, ctx)
    }
    fn link_or_copy<'a>(
        &'a self,
        from: &'a VPath,
        to: &'a VPath,
        ctx: &'a IoContext,
    ) -> caly_io::BoxFuture<'a, Result<caly_io::LinkKind, caly_io::IoFault>> {
        self.inner.link_or_copy(from, to, ctx)
    }
    fn lock_exclusive<'a>(
        &'a self,
        path: &'a VPath,
        ctx: &'a IoContext,
    ) -> caly_io::BoxFuture<'a, Result<caly_io::FileLock, caly_io::IoFault>> {
        self.inner.lock_exclusive(path, ctx)
    }
    fn list<'a>(
        &'a self,
        dir: &'a VPath,
        cap: ListCap,
        ctx: &'a IoContext,
    ) -> caly_io::BoxFuture<'a, Result<Vec<VPath>, caly_io::IoFault>> {
        self.inner.list(dir, cap, ctx)
    }
}

/// A daemon over a durable store whose port answers through the probe, with a clock injected
/// both on the store (deadline judgements) and in the engine slot (the daemon's deadline
/// arithmetic reads the same one). Seeded with one support bundle.
/// A monotonic clock a test can move: the daemon keeps `caly-io-sim` off its edge, so the
/// deadline arithmetic is exercised with a hand-rolled clock instead of the simulator's.
struct TestClock {
    mono: Arc<Mutex<u64>>,
}

impl caly_io::Clock for TestClock {
    fn now(&self) -> caly_io::Timestamp {
        caly_io::Timestamp {
            unix_millis: 1_700_000_000_000 + *self.mono.lock().expect("clock lock") as i64,
        }
    }
    fn mono(&self) -> caly_io::Monotonic {
        caly_io::Monotonic {
            ticks_millis: *self.mono.lock().expect("clock lock"),
        }
    }
    fn sleep_until<'a>(
        &'a self,
        _deadline: caly_io::Monotonic,
    ) -> caly_io::BoxFuture<'a, Result<(), caly_io::IoFault>> {
        // Nothing in this suite sleeps: the clock exists so deadlines can be *judged*.
        Box::pin(async { Ok(()) })
    }
}

/// The assembled daemon plus the two handles the judges read: what the port saw, and the hand
/// the clock is on. A struct rather than a tuple -- the tuple shape trips `type_complexity`,
/// and the field names carry the fixture's contract.
struct Fixture {
    app: DaemonApp,
    seen: Arc<Mutex<Vec<String>>>,
    mono: Arc<Mutex<u64>>,
}

fn daemon_with_bundle() -> Fixture {
    let scratch = std::env::temp_dir().join(format!(
        "caly-facade-ctx-{}-{}",
        std::process::id(),
        SCRITH_SEQ.fetch_add(1, std::sync::atomic::Ordering::SeqCst),
    ));
    std::fs::create_dir_all(&scratch).expect("scratch dir");
    let fs = StdFs::new(scratch.join(ROOT).to_string_lossy().into_owned());
    let mono = Arc::new(Mutex::new(0u64));
    let clock = TestClock {
        mono: Arc::clone(&mono),
    };
    let seen = Arc::new(Mutex::new(Vec::new()));
    let store = FsStore::open(
        Box::new(ProbeFs {
            inner: Box::new(fs),
            seen: Arc::clone(&seen),
        }),
        "store",
    )
    .expect("open the store")
    .with_clock(Arc::new(clock) as Arc<dyn caly_io::Clock>);

    let seed_ctx = IoContext::new(TraceId::new(SEED_TRACE), Actor::System);
    block_on_ready(store.put(
        CasWriteIntent {
            object: CasObjectRef {
                digest: ObjectDigest("sha256:bundle-seed".to_owned()),
                kind: ObjectKind::SupportBundle,
                size_bytes: None,
                content_type: None,
                content_sha256: None,
                stored_at_unix_ms: Some(1_700_000_000_000),
            },
            source_label: "bundle.txt".to_owned(),
            payload: b"# support bundle\nthe bytes a caller reads back\n".to_vec(),
            stored_at_unix_ms: 1_700_000_000_000,
        },
        &seed_ctx,
    ))
    .expect("no suspension")
    .expect("seed the bundle");

    let app = DaemonApp::try_bootstrap(
        DaemonBootstrapConfig {
            instance_id: "facade-store-ctx".to_owned(),
            protocol_version: ProtocolVersion { major: 1, minor: 0 },
            recover_on_start: false,
        },
        Arc::new(store) as Arc<dyn StorageBackend>,
    )
    .expect("boot the daemon");
    app.set_storage_clock(Some(Arc::new(TestClock {
        mono: Arc::clone(&mono),
    }) as Arc<dyn caly_engine::Clock>))
        .expect("inject the clock the deadline arithmetic shares with the store");
    Fixture { app, seen, mono }
}

fn envelope(
    trace: &str,
    io_budget: Option<caly_common::IoBudget>,
    deadline_ms: Option<u64>,
) -> RequestEnvelope {
    RequestEnvelope {
        protocol: ProtocolVersion { major: 1, minor: 0 },
        request_id: RequestId(1),
        trace_id: TraceId::new(trace),
        deadline_ms,
        expected_revision: None,
        idempotency_key: None,
        role: Role::Admin,
        io_budget,
        operation: Operation::Diagnostics(DiagnosticsOp::ReadSupportBundle {
            request: SupportBundleReadRequest {
                digest: Some("sha256:bundle-seed".to_owned()),
                max_bytes: None,
            },
        }),
    }
}

fn read_out(
    app: &DaemonApp,
    envelope: &RequestEnvelope,
) -> Result<caly_api::SupportBundleView, Box<caly_api::ApiError>> {
    // Boxed on purpose: `ApiError` is wide enough that a bare `Result` here trips the workspace
    // `result_large_err` ratchet, and that ratchet is only worth having if new code bends to it
    // instead of the baseline being raised (same shape as `gc_collect.rs`).
    caly_daemon::handle_request(app, Actor::Cli, envelope)
        .result
        .map_err(Box::new)
        .map(|result| match result {
            caly_api::OperationResult::SupportBundle(view) => view,
            other => panic!("unexpected result for a bundle read: {other:?}"),
        })
}

#[test]
fn a_caller_who_states_a_byte_budget_has_it_enforced_at_the_store() {
    let fixture = daemon_with_bundle();
    let app = &fixture.app;
    // The bundle's bytes are far over 16; the metadata read alone will spend the budget.
    let error = read_out(
        app,
        &envelope(
            "budgeted-caller",
            Some(caly_common::IoBudget {
                max_bytes: Some(16),
                max_requests: None,
            }),
            None,
        ),
    )
    .expect_err("a stated 16-byte budget cannot carry a bundle read");
    assert!(
        format!("{} {:?}", error.summary, error.detail).contains("io_budget.max_bytes"),
        "the refusal must name the caller's own meter: {} {:?}",
        error.summary,
        error.detail
    );
}

#[test]
fn a_caller_who_states_a_deadline_has_it_judged_by_the_injected_clock() {
    let fixture = daemon_with_bundle();
    let app = &fixture.app;
    // `deadline_ms` is relative to arrival, so the strongest synchronous judge is a *zero*
    // deadline against a moved hand: the conversion anchors on the injected clock's reading
    // (700), expiry is judged at `<=`, and the refusal has to name that reading. An engine
    // ghost context carries no deadline at all (the read would succeed); a different clock
    // could not print 700.
    *fixture.mono.lock().expect("clock lock") = 700;
    let error = read_out(app, &envelope("deadline-caller", None, Some(0)))
        .expect_err("a zero deadline is expired at the clock's own reading");
    let text = format!("{} {:?}", error.summary, error.detail);
    assert!(
        text.contains("deadline at mono 700"),
        "the refusal must name the deadline the injected clock computed: {}",
        text
    );
}

#[test]
fn during_the_read_the_port_answers_to_the_caller_not_to_the_engine() {
    let fixture = daemon_with_bundle();
    let (app, seen) = (&fixture.app, &fixture.seen);
    seen.lock().expect("probe lock").clear();
    let view = read_out(app, &envelope("the-callers-own-trace", None, None))
        .expect("an unstated budget and deadline change nothing");
    assert!(view.text.contains("the bytes a caller reads back"));
    let traces = seen.lock().expect("probe lock");
    assert!(
        !traces.is_empty(),
        "the read must have asked the port something"
    );
    assert!(
        traces.iter().all(|trace| trace == "the-callers-own-trace"),
        "every port call during the read carries the caller's trace, got {traces:?}"
    );
}

#[test]
fn a_caller_who_states_neither_budget_nor_deadline_reads_exactly_as_before() {
    // The no-drift line: the default context (`IoBudget::default_command`, no deadline) is what
    // every existing caller and every earlier test sends, and the read still works.
    let fixture = daemon_with_bundle();
    let app = &fixture.app;
    let view = read_out(app, &envelope("plain-caller", None, None)).expect("the read works");
    assert_eq!(view.digest, "sha256:bundle-seed");
    assert!(!view.truncated);
}

/// `OVERLOAD_AND_RETRY_MODEL §5.1`'s "snapshot not retained", with its judge at last: a digest
/// the store no longer holds (or never held) must come back as a **structured** refusal — code,
/// category, retryability, and a remediation that names both actionable paths and the honest
/// reason the object can vanish. Until now this text had no test reading it.
#[test]
fn a_digest_the_store_no_longer_holds_is_a_structured_refusal_with_both_exits() {
    let fixture = daemon_with_bundle();
    let app = &fixture.app;
    let mut ask = envelope("gone-caller", None, None);
    let Operation::Diagnostics(DiagnosticsOp::ReadSupportBundle { request }) = &mut ask.operation
    else {
        panic!("the envelope is a bundle read");
    };
    request.digest = Some(format!("sha256:{}", "ab".repeat(32)));
    let error = read_out(app, &ask).expect_err("a digest the store never held cannot be read back");
    assert_eq!(
        (error.code, error.category, error.retryable),
        (
            caly_api::ErrorCode::Conflict,
            caly_api::ErrorCategory::User,
            false
        ),
        "structured, caller-fixable, and not worth a retry: {:?}",
        error
    );
    assert!(
        error.summary.contains("no such object"),
        "the summary must say what is missing: {}",
        error.summary
    );
    let remediation = error.remediation.as_deref().unwrap_or_default();
    assert!(
        remediation.contains("job's own log line")
            && remediation.contains("DiagnosticsOp::SupportBundle")
            && remediation.contains("gc may collect"),
        "both exits and the honest reason must be named: {remediation}"
    );
}
