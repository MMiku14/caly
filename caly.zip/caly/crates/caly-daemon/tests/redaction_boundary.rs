//! The boundary every operator-visible string crosses on its way out of the daemon.
//!
//! `RFC-0010 §14` sets three minimum gates for this area:
//!
//! ```text
//! 1. 日志输出默认脱敏
//! 2. `ApiError` 默认脱敏
//! 3. support bundle 不包含明文 secret
//! ```
//!
//! None of them existed in code before: there was no redactor anywhere in the tree, while
//! `ADR-020 §3` had already decided that masking happens at the façade boundary. These tests are
//! the wiring of that decision, driven through `handle_request` — the one function both façades
//! call — and, for the bundle, verified against the bytes actually written to a real filesystem.
//!
//! Every input here is text a client supplied. That is deliberate: a redactor tested against a
//! fixture written to be caught proves nothing about the strings production composes.

use std::sync::atomic::{AtomicU64, Ordering};
use std::sync::Arc;

use caly_api::{
    ApplyRequest, DelayTestRequest, DiagnosticsOp, DoctorRequest, NodeId, Operation, ProfileId,
    ProfileOp, ProtocolVersion, ProxyOp, RequestEnvelope, RequestId, ResponseEnvelope, Role,
    TraceId,
};
use caly_common::redact::{RedactionPolicy, REDACTED};
use caly_common::Actor;
use caly_daemon::{handle_request, query, DaemonApp, DaemonBootstrapConfig, DaemonLifecycle};
use caly_engine::JobEvent;
use caly_io_std::StdFs;
use caly_storage::fs_store::{content_suffix_for, FsStore};
use caly_storage::{ObjectKind, ObjectStore, StorageBackend};

static SEQ: AtomicU64 = AtomicU64::new(0);

/// A scratch directory on the real filesystem, for the tests that read exported bytes back.
///
/// Plain `String` rather than a path type: the workspace bans `std::path::PathBuf` outside the IO
/// gateway (`clippy.toml`), and these tests deliberately go through `StdFs` for everything that
/// touches the disk.
fn scratch(tag: &str) -> (String, String) {
    let nth = SEQ.fetch_add(1, Ordering::SeqCst);
    let name = format!("caly-redaction-{tag}-{nth}-{}", std::process::id());
    let dir = std::env::temp_dir()
        .join(&name)
        .to_string_lossy()
        .into_owned();
    std::fs::create_dir_all(&dir).expect("scratch dir must be creatable");
    (dir, name)
}

fn durable(root: &str) -> Arc<FsStore> {
    Arc::new(
        FsStore::open(Box::new(StdFs::new(root.to_owned())), "var/caly")
            .expect("a fresh store root must open"),
    )
}

fn config(instance: &str, recover: bool) -> DaemonBootstrapConfig {
    DaemonBootstrapConfig {
        instance_id: instance.to_owned(),
        protocol_version: ProtocolVersion { major: 1, minor: 0 },
        recover_on_start: recover,
    }
}

fn envelope(operation: Operation, id: u64) -> RequestEnvelope {
    RequestEnvelope {
        protocol: ProtocolVersion { major: 1, minor: 0 },
        request_id: RequestId(id),
        trace_id: TraceId::new(format!("redaction-{id}")),
        deadline_ms: None,
        expected_revision: None,
        // `Idempotency::Required` commands are refused without a key (`ADR-037 §2.3`), so the
        // helper mints one per request id: unique per submission, which is exactly what "a
        // different write" means to the dedup window.
        idempotency_key: Some(format!("redact-{id}")),
        role: Role::Admin,
        io_budget: None,
        operation,
    }
}

fn apply_envelope(profile_id: &str, id: u64) -> RequestEnvelope {
    envelope(
        Operation::Profile(ProfileOp::Apply {
            request: ApplyRequest {
                profile_id: ProfileId(profile_id.to_owned()),
                dry_run: false,
                strict: false,
            },
        }),
        id,
    )
}

fn delay_envelope(node_id: &str, id: u64) -> RequestEnvelope {
    envelope(
        Operation::Proxy(ProxyOp::TestDelay {
            request: DelayTestRequest {
                node_ids: vec![NodeId(node_id.to_owned())],
            },
        }),
        id,
    )
}

/// The bytes a `DiagnosticsBundle` job wrote into the store, read back off the real filesystem.
///
/// Reading the file rather than an in-memory copy is the point: the artifact a support engineer is
/// handed is the one on disk, and `RFC-0010 §14.3` is about that file.
fn bundle_on_disk(store: &Arc<FsStore>, root: &str) -> String {
    let objects = caly_io::block_on_ready(store.list_objects())
        .expect("no suspension")
        .expect("listing must succeed");
    let bundle = objects
        .into_iter()
        .find(|object| object.kind == ObjectKind::SupportBundle)
        .expect("the job must have stored a bundle object");
    let anchor = bundle
        .content_sha256
        .clone()
        .expect("a payload write records its own anchor");
    let path = format!("{root}/var/caly/{}", content_suffix_for(&anchor));
    std::fs::read_to_string(&path)
        .unwrap_or_else(|error| panic!("{path} must be readable: {error}"))
}

/// `RFC-0010 §14.2` / `ADR-020 §3`: an error that quotes request input must not carry it out.
#[test]
fn an_error_that_quotes_request_input_is_masked_at_the_response_boundary() {
    let (root, tag) = scratch("error");
    let daemon = DaemonApp::try_bootstrap(
        config(&tag, false),
        durable(&root) as Arc<dyn StorageBackend>,
    )
    .expect("boot");
    daemon
        .seed_recovery_fixture("demo-crash-profile")
        .expect("a pending transaction to gate on");
    assert_eq!(
        daemon.runtime_snapshot().expect("runtime").lifecycle,
        DaemonLifecycle::Recovering
    );

    // The refusal detail embeds `command_line(...)`, which is the profile id the client sent.
    let response = handle_request(
        &daemon,
        Actor::Cli,
        &apply_envelope("demo?token=LEAKEDTOKENVALUE", 1),
    );
    let ResponseEnvelope {
        result: Err(error), ..
    } = &response
    else {
        panic!(
            "an apply must be refused while recovering, got {:?}",
            response.result
        );
    };

    let detail = error.detail.clone().unwrap_or_default();
    assert!(
        detail.contains("profile.apply demo?token=***"),
        "the refusal must still name the command: {detail}"
    );
    assert!(!detail.contains("LEAKEDTOKENVALUE"), "leaked: {detail}");
    assert!(
        error.summary.contains("Recovering"),
        "the useful half of the message must survive: {}",
        error.summary
    );
    assert_eq!(error.code, caly_api::ErrorCode::Conflict);
    std::fs::remove_dir_all(&root).ok();
}

/// `RFC-0010 §14.1`: the log line is masked where it is built, so every reader inherits it.
#[test]
fn a_job_log_line_is_masked_before_any_reader_sees_it() {
    let (root, tag) = scratch("log");
    let daemon = DaemonApp::try_bootstrap(
        config(&tag, false),
        durable(&root) as Arc<dyn StorageBackend>,
    )
    .expect("boot");
    daemon.set_running().expect("running");

    // `ProxyTestDelay` echoes `node_ids` into a job log line — a real path from client text to an
    // operator-visible string, not a test-only writer.
    let accepted = match handle_request(
        &daemon,
        Actor::Cli,
        &delay_envelope("hk?password=hunter2andmore", 2),
    )
    .result
    {
        Ok(caly_api::OperationResult::Accepted(accepted)) => accepted,
        other => panic!("expected an accepted job, got {other:?}"),
    };
    assert_eq!(daemon.drain_engine_once().expect("drain"), 1);

    let events = daemon
        .job_events(accepted.job_id)
        .expect("job events")
        .expect("the job exists");
    let message = events
        .iter()
        .find_map(|event| match event {
            JobEvent::Log { message, .. } => Some(message.clone()),
            _ => None,
        })
        .expect("the worker logs the delay request");
    assert!(!message.contains("hunter2andmore"), "leaked: {message}");
    assert!(message.contains(REDACTED), "{message}");
    assert!(message.contains("delay test requested"), "{message}");

    // The follow projection a client polls reports the same line, so there is no second,
    // unmasked view of the same job.
    let follow = daemon
        .follow_job_projection(accepted.job_id, None)
        .expect("projection")
        .expect("projection for a known job");
    assert_eq!(follow.summary.log_count, 1, "{:?}", follow.summary);
    std::fs::remove_dir_all(&root).ok();
}

/// The export itself: what lands on disk must be the masked text (`§14.3`).
#[test]
fn the_bundle_bytes_on_disk_hide_what_the_operator_pasted() {
    let (root, tag) = scratch("bundle");
    let store = durable(&root);
    let daemon = DaemonApp::try_bootstrap(
        config(&tag, false),
        Arc::clone(&store) as Arc<dyn StorageBackend>,
    )
    .expect("boot");
    daemon.set_running().expect("running");

    // Two kinds of secret in one line: a named query value, and an opaque token that only a
    // registered literal can catch. The daemon is told about the latter the way a composition root
    // would be — by holding the subscription URL.
    daemon
        .register_secret("OPAQUETOKEN42")
        .expect("secret registered");
    daemon
        .escalate_redaction(RedactionPolicy::Strict)
        .expect("escalated");

    let accepted = match handle_request(
        &daemon,
        Actor::Cli,
        &delay_envelope(
            "https://host/OPAQUETOKEN42?token=PLAINSECRET99&label=home",
            3,
        ),
    )
    .result
    {
        Ok(caly_api::OperationResult::Accepted(accepted)) => accepted,
        other => panic!("expected acceptance, got {other:?}"),
    };
    assert_eq!(daemon.drain_engine_once().expect("drain"), 1);
    assert!(daemon
        .job_events(accepted.job_id)
        .expect("events")
        .expect("job")
        .iter()
        .any(|event| !format!("{event:?}").contains("PLAINSECRET99")));

    // Ask for a bundle through the command path, exactly as a client does.
    let bundle_job = match handle_request(
        &daemon,
        Actor::Cli,
        &envelope(Operation::Diagnostics(DiagnosticsOp::SupportBundle), 4),
    )
    .result
    {
        Ok(caly_api::OperationResult::Accepted(accepted)) => accepted,
        other => panic!("expected an accepted bundle job, got {other:?}"),
    };
    assert_eq!(daemon.drain_engine_once().expect("drain"), 1);
    let follow = daemon
        .follow_job_projection(bundle_job.job_id, None)
        .expect("projection")
        .expect("job");
    assert_eq!(
        follow.summary.last_stage.as_deref(),
        Some("bundle.committed"),
        "{:?}",
        follow.summary
    );

    let text = bundle_on_disk(&store, &root);
    assert!(text.contains("== section: runtime-log"), "{text}");
    assert!(
        text.contains("label=home"),
        "masking must not delete:\n{text}"
    );
    assert!(!text.contains("PLAINSECRET99"), "pattern leak:\n{text}");
    assert!(!text.contains("OPAQUETOKEN42"), "literal leak:\n{text}");
    assert!(text.contains(REDACTED), "expected masking:\n{text}");
    // The export runs at strict convergence whatever the daemon was configured with (§12.1).
    assert!(text.contains("# redaction=strict"), "{text}");
    std::fs::remove_dir_all(&root).ok();
}

/// A `§4.1` quasi-secret: escalation is one-way, so it cannot be used to turn masking down.
#[test]
fn escalation_only_ever_adds_convergence() {
    let (root, tag) = scratch("policy");
    let daemon = DaemonApp::try_bootstrap(
        config(&tag, false),
        durable(&root) as Arc<dyn StorageBackend>,
    )
    .expect("boot");
    assert_eq!(
        daemon.redaction_policy().expect("policy"),
        RedactionPolicy::Default,
        "the default must stay the documented minimum, not strict-by-surprise"
    );
    daemon
        .escalate_redaction(RedactionPolicy::Strict)
        .expect("escalate");
    assert_eq!(
        daemon.redaction_policy().expect("policy"),
        RedactionPolicy::Strict
    );
    daemon
        .escalate_redaction(RedactionPolicy::Default)
        .expect("de-escalation is a no-op");
    assert_eq!(
        daemon.redaction_policy().expect("policy"),
        RedactionPolicy::Strict,
        "`escalate_redaction` must not be a way to relax masking"
    );
    std::fs::remove_dir_all(&root).ok();
}

/// `docs/ONBOARDING_NOTES.md §4.21`: an unimplemented operation and a handled-but-empty one must
/// not share a reply. `SupportBundle` is a command, so the query arm has to say that.
#[test]
fn the_query_path_refuses_a_bundle_request_with_a_typed_error() {
    let (root, tag) = scratch("query");
    let daemon = DaemonApp::try_bootstrap(
        config(&tag, false),
        durable(&root) as Arc<dyn StorageBackend>,
    )
    .expect("boot");
    let error = query::handle_query(
        &daemon,
        &envelope(Operation::Diagnostics(DiagnosticsOp::SupportBundle), 5),
    )
    .expect_err("the query path must not answer for a command");
    assert_eq!(error.code, caly_api::ErrorCode::Conflict);
    assert_eq!(error.category, caly_api::ErrorCategory::User);
    assert_eq!(error.summary, "support bundle is a command, not a query");
    assert!(
        !error.summary.contains("no daemon handler is connected yet"),
        "the router's placeholder text must not be reused here: {}",
        error.summary
    );
    assert!(
        error
            .remediation
            .as_deref()
            .unwrap_or_default()
            .contains("content-addressed"),
        "{:?}",
        error.remediation
    );
    std::fs::remove_dir_all(&root).ok();
}

/// `doctor` and the bundle are two views of one store; they must not disagree.
#[test]
fn doctor_and_the_bundle_report_the_same_finding() {
    let (root, tag) = scratch("agree");
    let store = durable(&root);
    let daemon = DaemonApp::try_bootstrap(
        config(&tag, false),
        Arc::clone(&store) as Arc<dyn StorageBackend>,
    )
    .expect("boot");
    daemon
        .seed_recovery_fixture("demo-crash-profile")
        .expect("seed a mid-cutover transaction");

    let doctor = match query::handle_query(
        &daemon,
        &envelope(
            Operation::Diagnostics(DiagnosticsOp::Doctor {
                request: DoctorRequest {
                    include_runtime: true,
                },
            }),
            6,
        ),
    )
    .expect("doctor is answerable")
    .expect("doctor has a handler")
    {
        caly_api::OperationResult::DoctorReport(report) => report,
        other => panic!("unexpected doctor result: {other:?}"),
    };
    // The tier is the audit's call, not the test's: an open journal is an *error* here, and the
    // point of the pair is that both views of the store report the same finding and the same line.
    let reported: Vec<&String> = doctor
        .errors
        .iter()
        .chain(doctor.warnings.iter())
        .filter(|line| line.contains("dangling-pending-journal"))
        .collect();
    assert!(!reported.is_empty(), "doctor found nothing: {doctor:?}");

    handle_request(
        &daemon,
        Actor::Cli,
        &envelope(Operation::Diagnostics(DiagnosticsOp::SupportBundle), 7),
    );
    assert_eq!(daemon.drain_engine_once().expect("drain"), 1);
    let text = bundle_on_disk(&store, &root);
    assert!(
        text.contains("dangling-pending-journal"),
        "the bundle must report what doctor reported:\n{text}"
    );
    assert!(text.contains("state=pending"), "{text}");
    // One summary line, computed once. If these two strings ever drift, the `audit_backend` call
    // has been duplicated somewhere and one of the two views is going stale.
    let audit_line = doctor
        .summary
        .split(';')
        .next()
        .unwrap_or_default()
        .trim()
        .to_owned();
    assert!(
        text.contains(&audit_line),
        "bundle must carry doctor's own audit summary ({audit_line}):\n{text}"
    );
    std::fs::remove_dir_all(&root).ok();
}
