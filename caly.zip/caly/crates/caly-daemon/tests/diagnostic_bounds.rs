//! The bulk diagnostic queries carry a bound, and say what the bound left out.
//!
//! Two rules from `RFC-0002` meet here and neither of them is optional:
//!
//! - `§9`: big collections (nodes, rules, connections, logs) MUST support paging or streaming.
//!   `diagnostics.doctor` and `diagnostics.recovery-status` return lists whose size is decided by the
//!   **store** -- one audit line per finding, one recovery decision per unresolved apply journal -- and
//!   neither is streamed, so they need a bound like any other.
//! - `§11.4`: large objects MUST NOT come back as an oversized inline IPC frame. `caly-ipc` enforces
//!   `MAX_FRAME_SIZE_BYTES` on *inbound* frames only, and `encode_raw_json` builds a frame of any size,
//!   so nothing else in the stack kept a legal query from producing a payload the peer refuses. That is
//!   the failure this file exists to prevent: the operator loses the diagnostic at the moment a broken
//!   deployment made it necessary, and gets a transport error instead of an API error.
//!
//! And the rule `docs/history/ONBOARDING_NOTES.md §4.54` recorded, which is the half that is easy to skip:
//! truncation that is not reported is worse than no truncation, because it looks like an empty store.
//! So every assertion below pairs a bound with the number that proves the bound was honest -- and one
//! test (`without_the_bound_this_answer_would_have_exceeded_the_frame_cap`) proves the fixture would
//! actually have broken the transport, so none of the rest can pass by being vacuous.

use std::sync::Arc;

use caly_api::{
    DoctorReport, Operation, OperationResult, ProtocolVersion, RecoveryStatusView, RequestEnvelope,
    RequestId, Role, TraceId,
};
use caly_common::Actor;
use caly_daemon::paging::{DIAGNOSTIC_MAX_BYTES, DIAGNOSTIC_MAX_LINES, DIAGNOSTIC_MAX_LINE_BYTES};
use caly_daemon::{DaemonApp, DaemonBootstrapConfig};
use caly_io::block_on_ready;
use caly_storage::{
    ApplyJournalRecord, ApplyJournalState, ApplyJournalStore, ApplyPhase, ApplyTxnId,
    InMemoryStorage, JournalRecordId, RevisionId, StorageBackend,
};

/// How many unresolved apply journals the fixture plants. Chosen so that the unbounded answer is
/// *bigger than the frame cap*: `§11.4` is the rule under test, so the fixture has to be able to break
/// it. `a_store_big_enough_to_matter` asserts that it does.
fn ctx() -> caly_io::IoContext {
    caly_io::RequestContext::new(
        caly_io::TraceId::new("diagnostic-bounds"),
        caly_io::Actor::System,
    )
}

const JOURNALS: usize = 900;
/// The size of the field each recovery decision quotes. One decision line therefore runs past the
/// per-line cap, which is the case a line count alone cannot handle.
const PROFILE_PAD: usize = 6 * 1024;

fn booted(tag: &str) -> (DaemonApp, Arc<InMemoryStorage>) {
    let store = Arc::new(InMemoryStorage::new());
    let daemon = DaemonApp::try_bootstrap(
        DaemonBootstrapConfig {
            instance_id: tag.to_owned(),
            protocol_version: ProtocolVersion { major: 1, minor: 0 },
            recover_on_start: false,
        },
        Arc::clone(&store) as Arc<dyn StorageBackend>,
    )
    .expect("boot");
    daemon.set_running().expect("running");
    (daemon, store)
}

fn journal(index: usize) -> ApplyJournalRecord {
    ApplyJournalRecord {
        journal_id: JournalRecordId(format!("journal:txn-{index}")),
        apply_txn_id: ApplyTxnId(format!("txn-{index}")),
        trace_id: format!("trace-{index}"),
        job_id: Some(format!("job-{index}")),
        profile_id: format!("p{index}-{}", "p".repeat(PROFILE_PAD)),
        revision_id: RevisionId(format!("rev-{index}")),
        semantic_digest: format!("sha:sem-{index}"),
        compiled_artifact_digest: format!("sha:art-{index}"),
        core_identity: "mihomo@1.0".to_owned(),
        effect_plan_id: format!("plan-{index}"),
        current_phase: ApplyPhase::Prepare,
        current_step_index: 0,
        net_effect_started: false,
        core_cutover_started: false,
        previous_snapshot_id: None,
        created_at_unix_ms: 0,
        updated_at_unix_ms: 0,
        // `Pending`, not `RecoveryFailed`: this is the state a process leaves behind when it dies
        // before the cursor can be settled, which is exactly when someone runs `doctor`.
        state: ApplyJournalState::Pending,
    }
}

fn bulge(store: &Arc<InMemoryStorage>) {
    for index in 0..JOURNALS {
        block_on_ready(store.put_apply_journal(journal(index), &ctx()))
            .expect("the store future is ready")
            .expect("the store takes the record");
    }
}

fn envelope(operation: Operation) -> RequestEnvelope {
    RequestEnvelope {
        protocol: ProtocolVersion { major: 1, minor: 0 },
        request_id: RequestId(1),
        trace_id: TraceId::new("diagnostic-bounds"),
        deadline_ms: None,
        expected_revision: None,
        idempotency_key: None,
        role: Role::Admin,
        io_budget: None,
        operation,
    }
}

fn ask(daemon: &DaemonApp, operation: Operation) -> OperationResult {
    match caly_daemon::handle_request(daemon, Actor::Cli, &envelope(operation)).result {
        Ok(result) => result,
        Err(error) => panic!("the daemon refused the call: {}", error.summary),
    }
}

fn recovery_view(daemon: &DaemonApp) -> RecoveryStatusView {
    match ask(
        daemon,
        Operation::Diagnostics(caly_api::DiagnosticsOp::RecoveryStatus),
    ) {
        OperationResult::RecoveryStatus(view) => view,
        other => panic!("unexpected result: {other:?}"),
    }
}

fn doctor_view(daemon: &DaemonApp) -> DoctorReport {
    match ask(
        daemon,
        Operation::Diagnostics(caly_api::DiagnosticsOp::Doctor {
            request: caly_api::DoctorRequest {
                include_runtime: true,
            },
        }),
    ) {
        OperationResult::DoctorReport(report) => report,
        other => panic!("unexpected result: {other:?}"),
    }
}

/// The fixture is only worth having if it can break the rule it is bounded against. `§11.4`'s limit is
/// the transport's, so the claim under test is "the unbounded answer would have crossed it" -- measured
/// from the sizes of the data the view prints, not from an estimate. Without this assertion every bound
/// below could be passing because the fixture was always going to fit.
#[test]
fn without_the_bound_this_answer_would_have_exceeded_the_frame_cap() {
    // One `CleanupAbandonedRuntime { profile_id }` decision per unresolved journal, and each
    // `profile_id` is `PROFILE_PAD` bytes long, so the answer's decision list alone is that many lines.
    let per_line = PROFILE_PAD + "CleanupAbandonedRuntime { profile_id: \"\" }".len();
    let unbounded = JOURNALS * (per_line + 1);
    assert!(
        unbounded > caly_ipc::MAX_FRAME_SIZE_BYTES as usize,
        "the fixture has to be able to overflow the frame cap, or the bound is decoration: \
         {JOURNALS} lines of {per_line} bytes = {unbounded}"
    );
    // A relation between two constants is a compile-time fact, so it is checked at compile time -- a
    // runtime `assert!` here would be an assertion that can never fail for any reason other than this
    // file being edited, which is the shape clippy calls out and this repo has agreed to honour.
    const _: () = assert!(
        JOURNALS > DIAGNOSTIC_MAX_LINES,
        "the fixture has to overflow the line budget, not only the byte one"
    );
    // The journal record this is derived from really does carry that field -- otherwise the arithmetic
    // above is about a string the store never produced.
    assert!(journal(0).profile_id.len() >= PROFILE_PAD);
}

#[test]
fn a_bulging_store_is_answered_within_the_bound_and_the_totals_stay_true() {
    let (daemon, store) = booted("bounded-recovery");
    bulge(&store);

    let view = recovery_view(&daemon);
    assert_eq!(
        view.decision_count, JOURNALS,
        "the total the caller acts on is the real one, not the post-cut length"
    );
    // The conservation law, which is the property the two caps must not be able to break: whatever the
    // answer drops -- by line count or by bytes -- is accounted for. Asserting an exact carried length
    // here would instead encode *which* cap happens to bind (at 6 KiB per line it is the byte one, at
    // ~20 bytes it is the line one, and that difference is an implementation detail of this fixture).
    assert!(
        !view.decisions.is_empty(),
        "a bounded answer that carries nothing would be indistinguishable from a clean store"
    );
    assert!(view.decisions.len() <= DIAGNOSTIC_MAX_LINES);
    assert_eq!(
        view.decisions.len() + view.omitted_decisions,
        view.decision_count,
        "carried + omitted must equal the source, or lines vanished without being reported"
    );
    assert!(view.omitted_decisions > 0);
    assert_eq!(view.pending_apply_count, JOURNALS);
    assert!(view.truncated);
    assert!(
        view.shortened_decisions > 0,
        "every source line here is {}+ bytes, so all of them came in shortened",
        PROFILE_PAD
    );
}

#[test]
fn every_carried_line_fits_and_the_tier_fits_with_its_note() {
    let (daemon, store) = booted("bounded-sizes");
    bulge(&store);

    let view = recovery_view(&daemon);
    for line in &view.decisions {
        assert!(
            line.len() <= DIAGNOSTIC_MAX_LINE_BYTES + 64,
            "the per-line cap plus the elision marker, nothing more: {} bytes",
            line.len()
        );
        assert!(
            line.contains("bytes elided]"),
            "the shortening has to be visible in the text, not only in a flag: {line}"
        );
    }
    let bytes: usize = view.decisions.iter().map(|line| line.len() + 1).sum();
    assert!(
        bytes <= DIAGNOSTIC_MAX_BYTES as usize,
        "the whole list, note included, stays inside the public cap: {bytes}"
    );
}

/// The other half of the design, and the reason the bound is applied to each *source* rather than to the
/// assembled answer: a store that produces thousands of lines must not be able to push out the
/// daemon's own sentences, because those are what the operator came for.
#[test]
fn the_daemons_own_lines_survive_a_flood_of_findings() {
    let (daemon, store) = booted("bounded-doctor");
    bulge(&store);

    let report = doctor_view(&daemon);
    assert!(report.truncated, "{:?}", report.summary);
    assert!(
        report.omitted_lines > 0,
        "the recovery-decision list is {} long and the answer cannot carry it all",
        JOURNALS
    );

    let all: String = report
        .warnings
        .iter()
        .chain(report.errors.iter())
        .chain(report.notes.iter())
        .cloned()
        .collect::<Vec<_>>()
        .join("\n");
    assert!(
        all.contains("audit") && all.contains("truncated for this reply"),
        "the cut has to be stated inside the tiers: {all}"
    );
    // …and specifically in the tier that was cut. A notice parked in `notes` would be missed by anyone
    // reading only `warnings` -- which is the tier that a truncation is about, and the one a caller
    // greps when something looks alarming.
    assert!(
        report
            .warnings
            .iter()
            .any(|line| line.contains("truncated for this reply")),
        "the warning tier has to carry its own truncation notice: {:?}",
        report.warnings.last()
    );
    assert!(
        !report
            .notes
            .iter()
            .any(|line| line.contains("audit warnings truncated")),
        "the audit-warnings notice belongs with the warnings, not in the informational tier: {:?}",
        report.notes
    );
    // The true total survives in a note even where the per-item lines were cut.
    assert!(
        all.contains(&format!("decisions={JOURNALS}")),
        "the `recovery pending_apply=… decisions=…` note is the whole-truth channel: {all}"
    );
    // …and the daemon's own context is still there: idempotency window, gc plan, last run.
    for needle in [
        "idempotency entries=",
        "gc plan objects=",
        "no collection cycle has run in this process",
    ] {
        assert!(
            all.contains(needle),
            "a flood must not evict the lines the operator asked for: missing {needle:?}"
        );
    }
    // The clean-bill placeholder may not appear next to a cut answer.
    assert!(
        !all.contains("no findings requiring action"),
        "that sentence means \"nothing was dropped\", which is false here"
    );
}

/// The anti-placeholder rule, on the other side: an answer that lost nothing must not carry a
/// truncation notice, and must not set the flag. A `truncated` that is always true is read as noise
/// within a week, and then a real cut is indistinguishable from the default.
#[test]
fn a_quiet_store_reports_no_truncation_and_no_note() {
    let (daemon, _store) = booted("quiet-store");

    let view = recovery_view(&daemon);
    assert_eq!(view.decision_count, 0);
    assert!(!view.truncated);
    assert_eq!(view.omitted_decisions, 0);
    assert_eq!(view.shortened_decisions, 0);

    let report = doctor_view(&daemon);
    assert!(!report.truncated);
    assert_eq!(report.omitted_lines, 0);
    assert_eq!(report.shortened_lines, 0);
    let all: String = report
        .warnings
        .iter()
        .chain(report.errors.iter())
        .chain(report.notes.iter())
        .cloned()
        .collect::<Vec<_>>()
        .join("\n");
    assert!(!all.contains("truncated for this reply"), "{all}");
    assert!(
        all.contains("no findings requiring action"),
        "on a quiet store that sentence is information, and it is the only place it belongs: {all}"
    );
}

/// A store that has something to warn about must still be able to say so *and* say that the list is
/// short: the bound and the finding are two different claims, and one test pair proves they are not
/// being conflated. 200 unresolved journals is over the line cap but under the byte cap for a *short*
/// profile id, which is the shape where `omitted` does the work and `shortened` stays at zero.
#[test]
fn a_cut_that_only_counts_lines_reports_only_omission() {
    let (daemon, store) = booted("many-small-journals");
    for index in 0..(DIAGNOSTIC_MAX_LINES + 72) {
        let mut record = journal(index);
        record.profile_id = format!("small-{index}");
        block_on_ready(store.put_apply_journal(record, &ctx()))
            .expect("ready")
            .expect("stored");
    }

    let view = recovery_view(&daemon);
    assert_eq!(view.decisions.len(), DIAGNOSTIC_MAX_LINES);
    assert_eq!(view.omitted_decisions, 72);
    assert_eq!(
        view.shortened_decisions, 0,
        "none of these lines is anywhere near the per-line cap"
    );
    assert!(view.truncated);
}
