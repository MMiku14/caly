//! Daemon command path: request envelope -> command -> job -> real effect execution ->
//! snapshot, observed through the daemon's own facades.
//!
//! `docs/engineering/APPLY_EXECUTION_CENTERLINE.md §12` lists "daemon command path 能触发真实 apply
//! workflow" and "job follow 能观察执行与恢复阶段" as the definition of done for the apply
//! centerline. These two tests are that definition, expressed as assertions.

use caly_api::{
    ApplyRequest, Idempotency, JobId, Operation, OperationMode, ProfileId, ProfileOp,
    ProtocolVersion, RequestEnvelope, RequestId, Role, TraceId,
};
use caly_common::Actor;
use caly_daemon::{DaemonApp, DaemonBootstrapConfig, DaemonLifecycle};

fn envelope(operation: ProfileOp, role: Role, request_id: u64) -> RequestEnvelope {
    RequestEnvelope {
        protocol: ProtocolVersion { major: 1, minor: 0 },
        request_id: RequestId(request_id),
        trace_id: TraceId::new(format!("trace-apply-{request_id}")),
        deadline_ms: Some(30_000),
        expected_revision: None,
        // `Idempotency::Required` commands are refused without a key (`ADR-037 §2.3`), so the
        // helper mints one per request id: unique per submission, which is exactly what "a
        // different write" means to the dedup window.
        idempotency_key: Some(format!("cmdpath-{request_id}")),
        role,
        io_budget: None,
        operation: Operation::Profile(operation),
    }
}

fn app() -> DaemonApp {
    DaemonApp::bootstrap(DaemonBootstrapConfig {
        instance_id: "test-instance".to_owned(),
        protocol_version: ProtocolVersion { major: 1, minor: 0 },
        recover_on_start: true,
    })
}

#[test]
fn apply_is_a_command_and_becomes_a_job() {
    // ADR-018: writes are jobs, never synchronous queries. If this metadata drifts, the whole
    // command path below is unreachable by construction.
    let meta = ProfileOp::Apply {
        request: ApplyRequest {
            profile_id: ProfileId("demo-tun-profile".to_owned()),
            dry_run: false,
            strict: false,
        },
    }
    .meta();
    assert_eq!(meta.mode, OperationMode::Command);
    assert!(meta.mutates_revision);
    assert_eq!(meta.idempotency, Idempotency::Required);
}

#[test]
fn command_path_drives_effect_execution_and_publishes_a_snapshot() {
    let app = app();
    let envelope = envelope(
        ProfileOp::Apply {
            request: ApplyRequest {
                profile_id: ProfileId("demo-tun-profile".to_owned()),
                dry_run: false,
                strict: false,
            },
        },
        Role::Admin,
        11,
    );

    assert!(app.latest_last_known_good_snapshot_id().unwrap().is_none());

    let submitted = app
        .submit_request_as_command(Actor::Cli, &envelope)
        .expect("admin may submit apply")
        .expect("apply maps to a command");
    assert!(!submitted.reused_existing_job);

    let cycles = app.drain_engine_once().expect("worker drain");
    assert_eq!(cycles, 1);

    // Job follow must expose the execution stages, not only a terminal state.
    let projection = app
        .follow_job_projection(JobId(submitted.job_id()), None)
        .expect("projection")
        .expect("job exists");
    assert_eq!(
        projection.summary.state, "completed",
        "{:?}",
        projection.summary
    );
    assert!(
        projection
            .summary
            .last_stage
            .as_deref()
            .unwrap_or_default()
            .starts_with("snapshot.committed"),
        "last stage must be the snapshot commit, got {:?}",
        projection.summary.last_stage
    );
    assert_eq!(projection.summary.failure_code, None);
    assert!(
        projection.summary.log_count >= 6,
        "effect steps must be logged"
    );

    // The daemon is the state owner: its runtime view must reflect the committed snapshot.
    let runtime = app.runtime_snapshot().expect("runtime snapshot");
    assert_eq!(
        runtime.active_profile,
        Some(ProfileId("demo-tun-profile".to_owned()))
    );
    assert!(runtime.active_snapshot.is_some(), "{runtime:?}");
    assert_eq!(runtime.last_apply_plan_summary.as_deref(), Some("Restart"));
    assert!(
        runtime
            .active_core
            .as_deref()
            .unwrap_or_default()
            .starts_with("mihomo"),
        "{:?}",
        runtime.active_core
    );

    let lkg = app
        .latest_last_known_good_snapshot()
        .expect("lkg read")
        .expect("a successful apply must publish a last-known-good snapshot");
    assert_eq!(Some(lkg.id.0.clone()), runtime.active_snapshot);
    assert!(lkg.is_last_known_good);
    assert!(!lkg.semantic_digest.is_empty() && !lkg.compiled_artifact_digest.is_empty());
    assert!(
        lkg.journal_id.is_some(),
        "a committed snapshot must record which apply journal produced it: {lkg:?}"
    );

    // A committed transaction must leave nothing pending for the recovery scanner.
    let report = app.recovery_scan().expect("recovery scan");
    assert!(report.unresolved_apply_journals.is_empty());
    assert!(report.decisions.is_empty());
}

#[test]
fn command_path_rolls_back_and_keeps_the_snapshot() {
    let app = app();
    let apply = envelope(
        ProfileOp::Apply {
            request: ApplyRequest {
                profile_id: ProfileId("demo-tun-profile".to_owned()),
                dry_run: false,
                strict: false,
            },
        },
        Role::Admin,
        21,
    );
    app.submit_request_as_command(Actor::Cli, &apply)
        .expect("apply submitted")
        .expect("apply maps to a command");
    app.drain_engine_once().expect("apply drained");
    let snapshot_id = app
        .latest_last_known_good_snapshot_id()
        .expect("lkg")
        .expect("lkg after apply");

    let rollback = envelope(
        ProfileOp::Rollback {
            request: caly_api::RollbackRequest {
                snapshot_id: Some(snapshot_id.clone()),
            },
        },
        Role::Admin,
        22,
    );
    let rolled_back = app
        .submit_request_as_command(Actor::Cli, &rollback)
        .expect("rollback submitted")
        .expect("rollback maps to a command");
    assert_eq!(app.drain_engine_once().expect("rollback drained"), 1);

    let projection = app
        .follow_job_projection(JobId(rolled_back.job_id()), None)
        .expect("projection")
        .expect("job exists");
    assert_eq!(projection.summary.state, "completed");
    assert!(projection
        .summary
        .last_stage
        .as_deref()
        .unwrap_or_default()
        .starts_with("recovery.succeeded"));

    // Rollback must not destroy the snapshot it points at.
    assert_eq!(
        app.latest_last_known_good_snapshot_id()
            .expect("lkg")
            .as_deref(),
        Some(snapshot_id.as_str())
    );
    assert!(app.recovery_scan().expect("scan").decisions.is_empty());
}

#[test]
fn an_unauthorised_role_cannot_enqueue_an_apply() {
    let app = app();
    let envelope = envelope(
        ProfileOp::Apply {
            request: ApplyRequest {
                profile_id: ProfileId("demo-tun-profile".to_owned()),
                dry_run: false,
                strict: false,
            },
        },
        Role::Viewer,
        31,
    );

    let error = app
        .submit_request_as_command(Actor::Cli, &envelope)
        .expect_err("a viewer must not be able to apply");
    assert_eq!(error.code, caly_api::ErrorCode::Permission);
    assert_eq!(error.category, caly_api::ErrorCategory::User);
    assert!(!error.retryable);
    assert!(error.summary.contains("required role"), "{}", error.summary);

    // Nothing may have been queued, and no snapshot may appear.
    assert_eq!(app.drain_engine_once().expect("drain"), 0);
    assert!(app
        .latest_last_known_good_snapshot_id()
        .expect("lkg")
        .is_none());
}

#[test]
fn boot_recovery_scan_is_part_of_the_daemon_lifecycle() {
    let app = app();
    app.set_running().expect("set running");
    let before = app.runtime_snapshot().expect("runtime");
    assert_eq!(before.lifecycle, DaemonLifecycle::Running);
    assert_eq!(before.pending_recovery_decisions, 0);

    // The existing fixture leaves a cutover-mid-flight transaction behind, which the boot
    // recovery scan must turn into an explicit decision instead of silently accepting it.
    let report = app
        .seed_recovery_fixture("demo-tun-profile")
        .expect("seed pending journal");
    assert_eq!(report.unresolved_apply_journals.len(), 1);
    assert_eq!(report.decisions.len(), 1);
    assert!(report.latest_last_known_good.is_none());
    // The fixture advances the journal into Cutover, and this daemon instance has no
    // last-known-good snapshot to roll back to, so the only safe decision is to revert the OS
    // side effects recorded in the journal (docs/engineering/STORAGE_RECOVERY_EXECUTION_PLAN.md 6.2 case B).
    assert!(
        matches!(
            report.decisions[0],
            caly_storage::RecoveryDecision::RevertOsEffectsOnly { .. }
        ),
        "{:?}",
        report.decisions
    );

    let after = app.runtime_snapshot().expect("runtime");
    assert_eq!(after.pending_recovery_decisions, 1);
    assert_eq!(after.lifecycle, DaemonLifecycle::Recovering);
    assert!(after
        .last_recovery_summary
        .as_deref()
        .unwrap_or_default()
        .contains("recovery decisions=1"));
}
