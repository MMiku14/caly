//! `GcRunView` gets a producer (`docs/ONBOARDING_NOTES.md §4.102`).
//!
//! The type existed with a renderer and no caller: `system.gc-plan` answered with a plan but never with
//! what the last cycle *did*, so the only places that sentence appeared were `doctor` and a support
//! bundle -- both rendered by **a different implementation** (the engine's `GcRunRecord`). A client and
//! an operator reading two wordings of one cycle is how one of them eventually stops being true.
//!
//! So: the plan answer carries the last run, the DTO's own renderer renders it, and these tests pin
//! both halves -- that every field arrives (a dropped field is invisible until someone needs it, and
//! `triggered_by` is the field nobody would notice missing), and that the two renderings agree.

use std::sync::Arc;

use caly_api::{
    DiagnosticsOp, DoctorRequest, GcCollectRequest, GcPlanRequest, Operation, OperationResult,
    ProtocolVersion, RequestEnvelope, RequestId, Role, SystemOp, TraceId,
};
use caly_common::Actor;
use caly_daemon::{DaemonApp, DaemonBootstrapConfig};
use caly_io::block_on_ready;
use caly_storage::{
    CasObjectRef, CasWriteIntent, InMemoryStorage, ObjectDigest, ObjectKind, ObjectStore,
    StorageBackend,
};

fn ctx() -> caly_io::IoContext {
    caly_io::RequestContext::new(caly_io::TraceId::new("gc-run-view"), caly_io::Actor::System)
}

fn booted(tag: &str) -> (DaemonApp, Arc<InMemoryStorage>) {
    let store = Arc::new(InMemoryStorage::new());
    let daemon = DaemonApp::try_bootstrap(
        DaemonBootstrapConfig {
            instance_id: tag.to_owned(),
            protocol_version: ProtocolVersion { major: 1, minor: 0 },
            recover_on_start: false,
        },
        Arc::clone(&store) as Arc<dyn StorageBackend>,
    )
    .expect("boot");
    daemon.set_running().expect("running");
    (daemon, store)
}

fn envelope(operation: Operation, key: Option<&str>) -> RequestEnvelope {
    RequestEnvelope {
        protocol: ProtocolVersion { major: 1, minor: 0 },
        request_id: RequestId(1),
        trace_id: TraceId::new("gc-run-view"),
        deadline_ms: None,
        expected_revision: None,
        idempotency_key: key.map(str::to_owned),
        role: Role::Admin,
        io_budget: None,
        operation,
    }
}

fn run(daemon: &DaemonApp, operation: Operation) -> OperationResult {
    match caly_daemon::handle_request(
        daemon,
        Actor::Cli,
        &envelope(operation, Some("gc-run-view-key")),
    )
    .result
    {
        Ok(result) => result,
        Err(error) => panic!("the daemon refused the call: {}", error.summary),
    }
}

fn plan_of(daemon: &DaemonApp) -> caly_api::GcPlanView {
    match run(
        daemon,
        Operation::System(SystemOp::GcPlan {
            request: GcPlanRequest::new(),
        }),
    ) {
        OperationResult::GcPlan(view) => view,
        other => panic!("expected a gc plan, got {other:?}"),
    }
}

fn doctor_line_about_the_run(daemon: &DaemonApp) -> String {
    match run(
        daemon,
        Operation::Diagnostics(DiagnosticsOp::Doctor {
            request: DoctorRequest {
                include_runtime: false,
            },
        }),
    ) {
        OperationResult::DoctorReport(report) => report
            .notes
            .into_iter()
            .find(|line| line.contains("gc cycle at revision="))
            .unwrap_or_default(),
        other => panic!("expected a doctor report, got {other:?}"),
    }
}

fn collect(daemon: &DaemonApp) {
    let _ = run(
        daemon,
        Operation::System(SystemOp::CollectGarbage {
            request: GcCollectRequest::new().with_grace_period_ms(0),
        }),
    );
    daemon.drain_engine_once().expect("the cycle runs");
}

fn seed_orphan(store: &Arc<InMemoryStorage>, digest: &str) {
    block_on_ready(store.put(
        CasWriteIntent {
            object: CasObjectRef {
                digest: ObjectDigest(digest.to_owned()),
                kind: ObjectKind::RawSource,
                size_bytes: None,
                content_type: None,
                content_sha256: None,
                stored_at_unix_ms: None,
            },
            source_label: "unreferenced".to_owned(),
            payload: b"bytes-nothing-points-at".to_vec(),
            stored_at_unix_ms: 0,
        },
        &ctx(),
    ))
    .expect("no suspension")
    .expect("write");
}

/// `None` and `Some(deleted = 0)` are different answers and both have to survive the trip.
#[test]
fn an_untouched_process_reports_no_last_run_at_all() {
    let (daemon, _store) = booted("run-view-none");
    let view = plan_of(&daemon);
    assert!(
        view.last_run.is_none(),
        "no cycle has run: the field must be absent, not an empty record"
    );
    assert!(
        !view.summary_line().contains("last_run="),
        "and the client-facing line must not claim one: {}",
        view.summary_line()
    );
}

#[test]
fn a_collected_cycle_arrives_in_the_plan_answer_field_for_field() {
    let (daemon, store) = booted("run-view-full");
    seed_orphan(&store, "obj:a");
    seed_orphan(&store, "obj:b");
    collect(&daemon);

    let view = plan_of(&daemon);
    let run = view.last_run.clone().expect("a cycle ran");
    let record = daemon
        .last_gc_run()
        .expect("engine readable")
        .expect("the record exists");

    assert_eq!(run.deleted_count(), 2, "both orphans, nothing invented");
    assert_eq!(run.collected, record.collected, "same digests, same order");
    assert_eq!(run.at_generation, record.at_generation);
    assert_eq!(run.now_unix_ms, record.now_unix_ms);
    assert_eq!(run.now_source, record.now_source);
    assert_eq!(run.grace_period_ms, record.grace_period_ms);
    assert_eq!(run.max_deletions, record.max_deletions);
    assert_eq!(run.retained_total, record.retained_total);
    assert_eq!(run.skipped_for_grace, record.skipped_for_grace);
    assert_eq!(run.refused, record.refused);
    assert_eq!(
        run.failed.len(),
        record.failed.len(),
        "a per-object failure the client never hears about is the drift this test exists to catch"
    );
    // The attribution field is the one nobody would notice losing.
    assert_eq!(
        run.triggered_by, record.triggered_by,
        "`triggered_by` is how a client learns the operator asked; a mapper that drops it turns an \\
         authorized deletion into silence"
    );
}

#[test]
fn the_two_outlets_render_the_same_sentence_from_the_same_cycle() {
    let (daemon, store) = booted("run-view-sentence");
    seed_orphan(&store, "obj:c");
    collect(&daemon);

    let record_line = daemon
        .last_gc_run()
        .expect("engine readable")
        .expect("record")
        .summary_line();
    let view_line = plan_of(&daemon)
        .last_run
        .expect("the field is there")
        .summary_line();
    assert_eq!(
        view_line, record_line,
        "the client's renderer and the operator's renderer must say one thing"
    );
    // and the plan answer embeds it rather than paraphrasing it.
    let line = plan_of(&daemon).summary_line();
    assert!(line.contains(&format!("last_run={record_line}")), "{line}");
    assert!(
        doctor_line_about_the_run(&daemon).contains("gc cycle at revision="),
        "the note keeps its own copy of the same sentence"
    );
}
