//! The storage GC plan, reached through the public query surface (`ADR-038 §1`).
//!
//! `caly_storage::gc` has held the collector's policy since round 5 with nothing calling it, so a
//! store that could only grow looked healthy from every surface this daemon exposes
//! (`docs/history/ONBOARDING_NOTES.md §4.73`). These tests are about the *report*, and specifically about the
//! one property that makes a report safe to act on: **an incomplete root set must shrink the answer,
//! never the question.** A plan that quietly computed a deletion list from five of six root classes
//! would be worse than no plan, because it looks actionable.
//!
//! Two backends appear here on purpose. The in-memory one is the clean case: it has no file dates, so
//! the plan's clock and the ages are the same timeline, and what is under test is the root set. The
//! durable one is the case that matters on a real host, where ages come from `Fs::stat`
//! (`ADR-035 §6bis-quater`) and the plan's `now` comes from the injected execution clock -- which is
//! why a real-disk plan *refuses* rather than reporting, and why that refusal has its own test below
//! (`docs/history/ONBOARDING_NOTES.md §4.74`).

use std::path::Path;
use std::sync::atomic::{AtomicU64, Ordering};
use std::sync::Arc;

use caly_api::{
    ApplyRequest, GcPlanRequest, GcPlanView, Operation, OperationResult, ProfileId, ProfileOp,
    ProtocolVersion, RequestEnvelope, RequestId, Role, SystemOp, TraceId,
};
use caly_common::Actor;
use caly_daemon::{DaemonApp, DaemonBootstrapConfig};
use caly_io::{block_on_ready, Clock, Fs};
use caly_io_std::{StdClock, StdFs};
use caly_storage::fs_store::FsStore;
use caly_storage::{
    CasObjectRef, CasWriteIntent, InMemoryStorage, ObjectDigest, ObjectKind, ObjectStore,
    StorageBackend,
};

static SEQ: AtomicU64 = AtomicU64::new(0);

fn ctx() -> caly_io::IoContext {
    caly_io::RequestContext::new(caly_io::TraceId::new("gc-plan"), caly_io::Actor::System)
}

fn scratch(tag: &str) -> (String, String) {
    let nth = SEQ.fetch_add(1, Ordering::SeqCst);
    let name = format!("caly-gc-plan-{tag}-{nth}-{}", std::process::id());
    let dir = std::env::temp_dir().join(&name);
    std::fs::create_dir_all(&dir).expect("scratch dir must be creatable");
    (
        dir.to_string_lossy().into_owned(),
        format!("caly-gc-plan-{tag}-{nth}"),
    )
}

fn config(instance: &str) -> DaemonBootstrapConfig {
    DaemonBootstrapConfig {
        instance_id: instance.to_owned(),
        protocol_version: ProtocolVersion { major: 1, minor: 0 },
        recover_on_start: true,
    }
}

fn durable(root: &str) -> Arc<FsStore> {
    Arc::new(
        FsStore::open(
            Box::new(StdFs::new(root.to_owned())) as Box<dyn Fs>,
            "var/caly",
        )
        .expect("a fresh store root must open"),
    )
}

fn apply_envelope(profile_id: &str) -> RequestEnvelope {
    RequestEnvelope {
        protocol: ProtocolVersion { major: 1, minor: 0 },
        request_id: RequestId(1),
        trace_id: TraceId::new("gc-plan-apply"),
        deadline_ms: None,
        expected_revision: None,
        // `profile.apply` declares `Idempotency::Required` (`ADR-037 §2.3`), so this fixture brings a
        // key instead of having the submission refused.
        idempotency_key: Some(format!("gc-plan-apply-{profile_id}")),
        role: Role::Admin,
        io_budget: None,
        operation: Operation::Profile(ProfileOp::Apply {
            request: ApplyRequest {
                profile_id: ProfileId(profile_id.to_owned()),
                dry_run: false,
                strict: false,
            },
        }),
    }
}

fn gc_envelope(request: GcPlanRequest) -> RequestEnvelope {
    RequestEnvelope {
        protocol: ProtocolVersion { major: 1, minor: 0 },
        request_id: RequestId(2),
        trace_id: TraceId::new("gc-plan-query"),
        deadline_ms: None,
        expected_revision: None,
        // A query needs no key: there is nothing to dedup, and minting one to satisfy a rule that does
        // not apply to reads is how a permission check ends up aimed at the wrong thing.
        idempotency_key: None,
        role: Role::Operator,
        io_budget: None,
        operation: Operation::System(SystemOp::GcPlan { request }),
    }
}

fn plan(daemon: &DaemonApp, request: GcPlanRequest) -> GcPlanView {
    match caly_daemon::handle_request(daemon, Actor::Cli, &gc_envelope(request)).result {
        Ok(OperationResult::GcPlan(view)) => view,
        Ok(other) => panic!("expected a gc plan, got {other:?}"),
        Err(error) => panic!("the plan query refused: {}", error.summary),
    }
}

fn classes(view: &GcPlanView) -> Vec<String> {
    let mut names: Vec<String> = view.gaps.iter().map(|gap| gap.class.to_owned()).collect();
    names.sort();
    names
}

fn gap_detail(view: &GcPlanView, class: &str) -> String {
    view.gaps
        .iter()
        .find(|gap| gap.class == class)
        .map(|gap| gap.detail.clone())
        .unwrap_or_default()
}

/// Deploy into an in-memory store, then hand back the daemon and the same backend for fixture writes.
/// Deploy into a durable store on a real directory, for the tests that need file dates to exist.
fn booted_durable(tag: &str) -> (String, DaemonApp, Arc<FsStore>) {
    let (root, name) = scratch(tag);
    let store = durable(&root);
    let daemon =
        DaemonApp::try_bootstrap(config(&name), Arc::clone(&store) as Arc<dyn StorageBackend>)
            .expect("boot");
    daemon.set_running().expect("running");
    daemon
        .submit_request_as_command(Actor::Cli, &apply_envelope("demo-tun-profile"))
        .expect("accepted");
    assert_eq!(daemon.drain_engine_once().expect("drain"), 1);
    (root, daemon, store)
}

fn booted_in_memory(tag: &str) -> (DaemonApp, Arc<InMemoryStorage>) {
    let store = Arc::new(InMemoryStorage::new());
    let daemon =
        DaemonApp::try_bootstrap(config(tag), Arc::clone(&store) as Arc<dyn StorageBackend>)
            .expect("boot");
    daemon.set_running().expect("running");
    daemon
        .submit_request_as_command(Actor::Cli, &apply_envelope("demo-tun-profile"))
        .expect("accepted");
    assert_eq!(daemon.drain_engine_once().expect("drain"), 1);
    (daemon, store)
}

/// The plan names exactly what no root reaches, and keeps its hands off what the store can show is
/// referenced.
#[test]
fn a_queried_plan_names_the_orphan_and_protects_everything_rooted() {
    let (daemon, store) = booted_in_memory("plan-in-memory");
    let snapshot = daemon
        .latest_last_known_good_snapshot()
        .expect("lkg read")
        .expect("a committed apply leaves a last-known-good snapshot");
    let rooted = snapshot.compiled_artifact_digest.clone();
    assert!(
        block_on_ready(store.get(&rooted, &ctx()))
            .expect("ready")
            .expect("read")
            .is_some(),
        "the assertion below is only worth making about an object that exists: {rooted}"
    );

    // One object nothing references, dated before any grace period could reach.
    block_on_ready(store.put(
        CasWriteIntent {
            object: CasObjectRef {
                digest: ObjectDigest("obj:orphan".to_owned()),
                kind: ObjectKind::RawSource,
                size_bytes: None,
                content_type: None,
                content_sha256: None,
                stored_at_unix_ms: None,
            },
            source_label: "orphan".to_owned(),
            payload: b"unreferenced-by-anything".to_vec(),
            stored_at_unix_ms: 0,
        },
        &ctx(),
    ))
    .expect("ready")
    .expect("put");

    // `grace_period_ms: 0` puts the *roots* under test rather than the clock: an object of unknown age
    // is protected forever, so a default grace period would hide whether root wiring works at all.
    // The view echoes the bound it used, so the number is never implicit.
    let view = plan(&daemon, GcPlanRequest::new().with_grace_period_ms(0));
    assert!(
        view.gaps.is_empty(),
        "every root class is readable on this backend: {:?}",
        view.gaps
    );
    assert_eq!(
        view.collect,
        vec!["obj:orphan".to_owned()],
        "exactly the object no root reaches: {view:?}"
    );
    assert!(
        !view.collect.contains(&rooted),
        "the active deployment's artifact must never appear in a deletion list: {view:?}"
    );
    assert!(
        view.retained_sample
            .iter()
            .any(|entry| entry.digest == rooted
                && entry
                    .reasons
                    .iter()
                    .any(|reason| reason == "active-snapshot")),
        "and the reason has to name the root that saved it: {:?}",
        view.retained_sample
    );
    assert!(
        view.would_run,
        "a complete, eligible plan says so: {:?}",
        view.refusal
    );
    assert_eq!(
        view.grace_period_ms, 0,
        "the view must report the bounds it was computed under"
    );
    assert_eq!(view.revisions_total, 1, "{view:?}");
    assert!(view.objects_total >= 2, "{view:?}");
    assert!(view.snapshots_total >= 1, "{view:?}");
}

/// On a real filesystem the ages come from the port and `now` comes from the engine's injected clock.
/// When those two timelines disagree, the honest report is a refusal -- not an empty list that looks
/// like "everything is protected by grace".
#[test]
fn a_real_disk_plan_refuses_when_the_clocks_are_not_the_same_timeline() {
    let (root, daemon, _store) = booted_durable("timeline");

    let view = plan(&daemon, GcPlanRequest::new());
    assert!(
        classes(&view).contains(&"clock-timeline".to_owned()),
        "a real mtime against an injected clock at zero must be reported, not swallowed: {:?}",
        view.gaps
    );
    assert!(
        view.collect.is_empty(),
        "no deletion list while freshness cannot be judged: {view:?}"
    );
    assert!(!view.would_run);
    assert!(
        gap_detail(&view, "clock-timeline").contains("not on one timeline"),
        "the detail has to say what is wrong: {}",
        gap_detail(&view, "clock-timeline")
    );
    // Not actionable: no operator setting clears it, only injecting a clock at the composition root.
    // This is why `doctor` can keep "no warnings" meaningful on a healthy durable store.
    assert!(
        view.gaps
            .iter()
            .filter(|gap| gap.class == "clock-timeline")
            .all(|gap| !gap.actionable),
        "a structural gap must not become a permanent warning: {:?}",
        view.gaps
    );
    assert!(
        view.objects_total > 0,
        "and it still describes the store it refused to plan against: {view:?}"
    );

    std::fs::remove_dir_all(&root).ok();
}

/// The failure mode only a plan query can catch: "the snapshot the runtime names is not in the store"
/// must become a *refusal*, not a smaller root set -- the two are the same shape in a naive read.
#[test]
fn a_snapshot_the_store_cannot_produce_refuses_the_plan_instead_of_shrinking_it() {
    let (root, daemon, _store) = booted_durable("gap");

    let active = daemon
        .runtime_snapshot()
        .expect("runtime")
        .active_snapshot
        .expect("a committed apply names its snapshot");
    // Remove the record behind the store's back.
    let stem = caly_storage::fs_store::escape_component(&active);
    let file = Path::new(&root).join(format!(
        "var/caly/records/snapshot/{}/{}.rec",
        caly_storage::record_shard(&stem),
        stem
    ));
    std::fs::remove_file(&file).expect("remove the active snapshot's record");

    let view = plan(&daemon, GcPlanRequest::new());
    let reported = classes(&view);
    assert!(
        reported.contains(&"active-snapshot".to_owned())
            && reported.contains(&"last-known-good".to_owned()),
        "both roots that depended on that record must be named: {reported:?}"
    );
    // And they are named as *damage*, which is what makes `doctor` warn rather than note: a missing
    // record is something an operator can restore, unlike every structural gap in this suite.
    assert!(
        view.gaps
            .iter()
            .filter(|gap| gap.class == "active-snapshot" || gap.class == "last-known-good")
            .all(|gap| gap.actionable),
        "damage has to be reported as actionable: {:?}",
        view.gaps
    );
    assert!(
        view.collect.is_empty(),
        "a partial root set must not hand out a deletion list: {view:?}"
    );
    assert!(!view.would_run);
    let refusal = view.refusal.as_deref().unwrap_or_default().to_owned();
    assert!(
        refusal.contains("root set incomplete"),
        "the refusal has to be actionable: {refusal}"
    );
    assert!(
        view.objects_total > 0,
        "the store facts are still reported -- a refusal is not an empty store: {view:?}"
    );
    assert!(
        view.summary_line().contains("gaps="),
        "the line `doctor` prints has to carry the count: {}",
        view.summary_line()
    );

    std::fs::remove_dir_all(&root).ok();
}

/// Eligibility and a partial root set are different facts, and the view has to keep them apart: a
/// pending transaction does not make the plan blind (it still names what is unreferenced), it makes the
/// cycle unallowed right now. Collapsing the two would let `doctor` say "cannot tell" whenever a
/// deployment is running, which is when an operator most wants the number.
#[test]
fn a_pending_transaction_leaves_the_plan_complete_but_stops_the_cycle() {
    let store = Arc::new(InMemoryStorage::new());
    let daemon = DaemonApp::try_bootstrap(
        config("pending-eligibility"),
        Arc::clone(&store) as Arc<dyn StorageBackend>,
    )
    .expect("boot");
    daemon.set_running().expect("running");
    daemon
        .submit_request_as_command(Actor::Cli, &apply_envelope("demo-tun-profile"))
        .expect("accepted");
    daemon.drain_engine_once().expect("drain");
    // A transaction left mid-cutover: the recovery scan finds it, and `§13.2` gates a cycle on its way.
    daemon
        .seed_recovery_fixture("demo-crash-profile")
        .expect("seed an unfinished transaction");

    let view = plan(&daemon, GcPlanRequest::new().with_grace_period_ms(0));
    assert!(
        view.gaps.is_empty(),
        "every root is still readable -- the refusal is about timing, not knowledge: {:?}",
        view.gaps
    );
    assert!(
        !view.idle || view.pending_deployments >= 1,
        "the plan must report what makes a cycle ineligible: {view:?}"
    );
    assert!(
        !view.would_run,
        "a pending deployment stops the cycle: {view:?}"
    );
    assert!(
        view.refusal
            .as_deref()
            .unwrap_or_default()
            .contains("unfinished deployment transaction"),
        "and name it: {:?}",
        view.refusal
    );
}

/// The plan reaches `doctor` as a note that carries its own refusal, so an operator reading the
/// report sees both the numbers and why a cycle would not run. It is a note rather than a warning on
/// purpose: every state that makes the plan refuse also makes the audit fail this query first, so a
/// warning would either duplicate the audit or never fire (`docs/history/ONBOARDING_NOTES.md §4.76`).
#[test]
fn the_plan_and_its_refusal_reach_doctor_as_one_note() {
    let (root, daemon, _store) = booted_durable("doctor-note");
    let doctor = |tag: &str| match caly_daemon::handle_request(
        &daemon,
        Actor::Cli,
        &RequestEnvelope {
            protocol: ProtocolVersion { major: 1, minor: 0 },
            request_id: RequestId(3),
            trace_id: TraceId::new(tag),
            deadline_ms: None,
            expected_revision: None,
            idempotency_key: None,
            role: Role::Admin,
            io_budget: None,
            operation: Operation::Diagnostics(caly_api::DiagnosticsOp::Doctor {
                request: caly_api::DoctorRequest {
                    include_runtime: false,
                },
            }),
        },
    )
    .result
    {
        Ok(OperationResult::DoctorReport(report)) => report,
        other => panic!("expected a doctor report, got {other:?}"),
    };

    let healthy = doctor("gc-plan-doctor-healthy");
    let note = healthy
        .notes
        .iter()
        .find(|line| line.contains("gc plan objects="))
        .unwrap_or_else(|| panic!("the plan must reach the report: {:?}", healthy.notes));
    assert!(
        note.contains("now=0"),
        "the note has to expose which clock it judged against: {note}"
    );
    assert!(
        note.contains("refused:") && note.contains("clock-timeline"),
        "and why a cycle would not run: {note}"
    );
    assert!(
        healthy.warnings.is_empty(),
        "a structural refusal is not a warning: {:?}",
        healthy.warnings
    );

    // The damage case: the audit refuses the whole report before the plan can even be rendered. That is
    // the ordering the note-tier follows, and it is asserted here so the tier is a decision rather
    // than an oversight.
    let active = daemon
        .runtime_snapshot()
        .expect("runtime")
        .active_snapshot
        .expect("a committed apply names its snapshot");
    let stem = caly_storage::fs_store::escape_component(&active);
    std::fs::remove_file(
        Path::new(&root)
            .join("var/caly/records/snapshot")
            .join(caly_storage::record_shard(&stem))
            .join(format!("{stem}.rec")),
    )
    .expect("remove the active snapshot's record");
    let damaged =
        caly_daemon::handle_request(&daemon, Actor::Cli, &gc_envelope(GcPlanRequest::new()))
            .result
            .expect("the plan query itself still answers, with the gap named");
    match damaged {
        OperationResult::GcPlan(view) => {
            assert!(
                view.gaps.iter().any(|gap| gap.actionable),
                "damage is reported as actionable for a client that tiers on it: {:?}",
                view.gaps
            );
            assert!(view.collect.is_empty(), "{view:?}");
        }
        other => panic!("expected a gc plan, got {other:?}"),
    }

    std::fs::remove_dir_all(&root).ok();
}

/// The seam `ADR-038 §3` added, exercised the way a real host will use it: the daemon is handed a clock
/// from the same port family the store dates by, so both sides of the grace comparison come from one
/// timeline and the plan stops refusing. That is the difference between "reclaim disk" being an operation
/// and being a no-op that reports health.
#[test]
fn injecting_the_storage_clock_turns_the_refusal_into_a_plan() {
    let (root, daemon, store) = booted_durable("clock-injected");
    block_on_ready(store.put(
        CasWriteIntent {
            object: CasObjectRef {
                digest: ObjectDigest("obj:orphan".to_owned()),
                kind: ObjectKind::RawSource,
                size_bytes: None,
                content_type: None,
                content_sha256: None,
                stored_at_unix_ms: None,
            },
            source_label: "orphan".to_owned(),
            payload: b"unreferenced-by-anything".to_vec(),
            stored_at_unix_ms: 0,
        },
        &ctx(),
    ))
    .expect("ready")
    .expect("put");
    let rooted = daemon
        .latest_last_known_good_snapshot()
        .expect("lkg read")
        .expect("a committed apply leaves a snapshot")
        .compiled_artifact_digest
        .clone();

    // The same store state, refused: no clock injected, so `now` is the policy base and the file dates
    // are the host's.
    let before = plan(&daemon, GcPlanRequest::new());
    assert!(
        classes(&before).contains(&"clock-timeline".to_owned()),
        "this is the state `§4.74` describes: {before:?}"
    );
    assert!(before.collect.is_empty(), "{before:?}");
    assert_eq!(before.now_source, "execution-policy-base", "{before:?}");

    daemon
        .set_storage_clock(Some(Arc::new(StdClock::new()) as Arc<dyn Clock>))
        .expect("the seam must accept a port clock");

    // `grace_period_ms: 0` keeps the assertion about roots rather than about elapsed time: the object
    // was written moments ago on the same host clock the plan now reads.
    let after = plan(&daemon, GcPlanRequest::new().with_grace_period_ms(0));
    assert_eq!(after.now_source, "storage-clock", "{after:?}");
    assert!(
        !classes(&after).contains(&"clock-timeline".to_owned()),
        "one timeline, no reason to refuse: {:?}",
        after.gaps
    );
    assert!(
        after.collect.contains(&"obj:orphan".to_owned()),
        "the orphan is now reportable as reclaimable: {after:?}"
    );
    assert!(
        !after.collect.contains(&rooted),
        "and a root still excludes what the deployment is using: {after:?}"
    );
    assert!(
        after
            .retained_sample
            .iter()
            .any(|entry| entry.digest == rooted),
        "the rooted object is counted as retained, with its reason: {:?}",
        after.retained_sample
    );
    assert!(after.would_run, "{:?}", after.refusal);

    std::fs::remove_dir_all(&root).ok();
}

/// Bounds are the caller's contract, so breaking them is `CONFIG_INVALID` and never "the store is
/// unhealthy" -- the same split `docs/guides/ERRORS.md §5.1` draws for paged queries.
#[test]
fn an_out_of_range_bound_is_refused_before_the_store_is_read() {
    let (daemon, _store) = booted_in_memory("bounds");
    let cases = [
        (
            GcPlanRequest::new().with_max_deletions(0),
            "max_deletions must be at least 1",
        ),
        (
            GcPlanRequest::new().with_grace_period_ms(-1),
            "grace_period_ms must not be negative",
        ),
        (
            GcPlanRequest::new().with_max_deletions(u32::MAX),
            "exceeds the supported limit",
        ),
    ];
    for (request, expected) in cases {
        let error = caly_daemon::handle_request(&daemon, Actor::Cli, &gc_envelope(request))
            .result
            .expect_err("an out-of-range bound must not be answered with a plan");
        assert_eq!(error.code.as_str(), "CONFIG_INVALID", "{}", error.summary);
        assert!(
            error.summary.contains(expected),
            "{}: expected {expected}",
            error.summary
        );
    }
}

/// A queued command is work in flight, and its references are not written down anywhere yet -- so the
/// plan refuses, while still reporting what it can see.
#[test]
fn an_engine_with_work_in_flight_refuses_its_own_plan() {
    let (daemon, _store) = booted_in_memory("busy");
    daemon
        .submit_request_as_command(Actor::Cli, &apply_envelope("demo-dns-profile"))
        .expect("accepted");
    // Deliberately not drained.

    let view = plan(&daemon, GcPlanRequest::new().with_grace_period_ms(0));
    assert!(!view.idle, "a queued command is work: {view:?}");
    assert!(
        view.gaps
            .iter()
            .any(|gap| gap.class == "running-job-artifacts"),
        "the refusal has to say which root is unknowable: {:?}",
        view.gaps
    );
    assert!(!view.would_run);
    assert!(
        view.collect.is_empty(),
        "no deletion list while a transaction is in flight: {view:?}"
    );
}

/// `Role::Operator` is the gate this query declares, and the refusal must be the permission one --
/// otherwise the role on the operation is decoration (`ADR-037 §2.1`).
#[test]
fn a_viewer_cannot_ask_for_a_deletion_plan() {
    let (daemon, _store) = booted_in_memory("role");
    let mut envelope = gc_envelope(GcPlanRequest::new());
    envelope.role = Role::Viewer;
    let error = caly_daemon::handle_request(&daemon, Actor::Cli, &envelope)
        .result
        .expect_err("`Operator` must be required, not suggested");
    assert_eq!(error.code.as_str(), "PERMISSION", "{error:?}");
}

/// The content half reaches the caller-facing view: `content_total` and the orphan fields are the
/// same numbers the engine's summary prints, and unknown-age orphans (all an in-memory backend can
/// offer) are reported as kept-by-grace rather than hidden. A DTO that silently dropped these
/// fields would tell a client "the disk is clean" over bytes the plan itself counted.
#[test]
fn the_view_carries_the_content_half_of_the_plan() {
    let (daemon, store) = booted_in_memory("plan-content-view");
    store.keep_orphan_content("sha256:ab", b"bytes no object names");

    let view = plan(
        &daemon,
        GcPlanRequest {
            grace_period_ms: Some(0),
            max_deletions: None,
        },
    );
    assert_eq!(
        view.content_total, 2,
        "the deployed artifact's content plus the orphan: both are in the tree, referenced or not: {view:?}"
    );
    assert!(
        view.orphan_collect.is_empty(),
        "unknown age keeps it out of every deletion list: {view:?}"
    );
    assert_eq!(view.orphan_skipped_for_grace, 1, "{view:?}");
    assert!(
        view.summary_line().contains("content_orphans=1"),
        "the one sentence the client prints agrees with the fields it carries: {}",
        view.summary_line()
    );
}
