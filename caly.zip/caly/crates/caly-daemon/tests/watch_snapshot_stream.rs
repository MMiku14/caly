//! SnapshotThenPatch watch streams (`IPC_STREAM_POLICY §3`): the dashboard/connections
//! snapshot-first contract and the bounded per-pull producer.
//!
//! The wire has carried `SnapshotJson`/`PatchJson` payloads and the CLI has rendered them
//! since the first stream rounds — but no producer ever EMITTED one: a dashboard client
//! that connected mid-flight saw only future changes, with no frame saying what the system
//! looks like NOW. The policy table's `SnapshotThenPatch` row (Dashboard/Connections:
//! snapshot first, Optional ack, reset on gap) was a table, not a behaviour. These judges
//! pin the behaviour end to end over the real daemon session:
//!
//! * the FIRST pull of a Dashboard/Connections watch is exactly ONE `SnapshotJson` frame,
//!   carrying the SAME facts the corresponding one-shot query serves (single source), seq'd
//!   at the live edge so the next patch continues at +1;
//! * after the snapshot only NEW events arrive, as the existing typed patch frames — the
//!   pre-snapshot history is folded into the snapshot, never re-delivered;
//! * a producer with a long backlog is served in BOUNDED pulls (no unbounded frame batch),
//!   contiguous by seq across pulls, nothing lost and nothing repeated;
//! * a client that falls behind RETENTION gets a named Reset — the formal slow-client
//!   policy (`IPC_STREAM_POLICY §7.4`), demonstrated reachable, not asserted on paper.

use caly_api::{
    ApplyRequest, ConnectionQuery, Operation, PageRequest, ProfileId, ProfileOp, ProtocolVersion,
    RequestEnvelope, RequestId, ResponseEnvelope, Role, RuntimeOp, RuntimeSubscription, StreamId,
    TraceId,
};
use caly_common::Actor;
use caly_daemon::{handle_request, DaemonApp, DaemonBootstrapConfig, DaemonSession};
use caly_ipc::{
    json_from_records, ClientHello, ClientKind, Compression, Encoding, NegotiationPolicy,
    ResetReason, ServerFrame, StreamFrame, StreamKind, StreamPayload,
};

/// The per-pull frame bound the producer promises (`IPC_STREAM_POLICY §7`: a pull is a
/// bounded unit of work; the retained window holds the rest).
const MAX_FRAMES_PER_PULL: usize = 64;

fn daemon(tag: &str) -> DaemonApp {
    DaemonApp::bootstrap(DaemonBootstrapConfig {
        instance_id: tag.to_owned(),
        protocol_version: ProtocolVersion { major: 1, minor: 0 },
        recover_on_start: false,
    })
}

fn envelope(operation: Operation, id: u64) -> RequestEnvelope {
    RequestEnvelope {
        protocol: ProtocolVersion { major: 1, minor: 0 },
        request_id: RequestId(id),
        trace_id: TraceId::new(format!("watch-snapshot-{id}")),
        deadline_ms: None,
        expected_revision: None,
        idempotency_key: Some(format!("watch-snapshot-{id}")),
        role: Role::Admin,
        io_budget: None,
        operation,
    }
}

/// Run one real apply of the demo profile and drain it to completion: the proven recipe
/// for putting REAL engine events on the log (each apply resolves, validates, plans,
/// commits a snapshot and reports — the exact events a dashboard exists to show).
fn apply_once(daemon: &DaemonApp, id: u64) {
    let accepted = handle_request(
        daemon,
        Actor::Cli,
        &envelope(
            Operation::Profile(ProfileOp::Apply {
                request: ApplyRequest {
                    profile_id: ProfileId("demo-tun-profile".to_owned()),
                    dry_run: false,
                    strict: false,
                },
            }),
            id,
        ),
    );
    assert!(
        matches!(accepted.result, Ok(caly_api::OperationResult::Accepted(_))),
        "the demo apply must be accepted: {:?}",
        accepted.result
    );
    assert_eq!(daemon.drain_engine_once().expect("drain"), 1);
}

fn handshake(daemon: &DaemonApp) -> DaemonSession {
    let mut session = DaemonSession::new(Actor::System, NegotiationPolicy::default());
    session
        .accept_hello(
            daemon,
            &ClientHello {
                protocol: ProtocolVersion { major: 1, minor: 0 },
                client_kind: ClientKind::Tui,
                client_name: "watch-snapshot-judge".to_owned(),
                requested_encoding: Encoding::Json,
                requested_compression: Compression::None,
                supported_features: Vec::new(),
                role: Role::Admin,
            },
            "watch-snapshot-session",
        )
        .expect("hello");
    session
}

/// Open a watch subscription through the real request path. One stream per open: the
/// judges pull the SAME stream repeatedly, because cursors, bounds and resets are
/// per-stream facts.
fn open_watch(
    daemon: &DaemonApp,
    session: &mut DaemonSession,
    subscription: RuntimeSubscription,
    request_id: u64,
) -> StreamId {
    let opened = session
        .handle_request(
            daemon,
            &envelope(
                Operation::Runtime(RuntimeOp::Watch { subscription }),
                request_id,
            ),
        )
        .expect("watch request");
    let Ok(caly_api::OperationResult::WatchOpened(opened)) = opened.result else {
        panic!("a watch must open, not {opened:?}");
    };
    opened.stream_id
}

/// One pull of an already-opened stream (the client passes no explicit cursor: the session
/// resumes from the stream's own last-emitted/acked position).
fn pull(daemon: &DaemonApp, session: &mut DaemonSession, stream: StreamId) -> Vec<StreamFrame> {
    session
        .follow_opened_stream(daemon, stream, None)
        .expect("pull")
        .into_iter()
        .map(|frame| match frame {
            ServerFrame::Stream(frame) => frame,
            other => panic!("a stream pull yields stream frames, not {other:?}"),
        })
        .collect()
}

/// The flat-record rendering of a `RuntimeStatus` the snapshot must agree with — the same
/// eight keys the records/JSON wire face carries for `runtime.status` (single source: the
/// snapshot is the query, restated as a stream frame).
fn status_json(response: &ResponseEnvelope) -> String {
    let Ok(caly_api::OperationResult::RuntimeStatus(status)) = &response.result else {
        panic!(
            "status query must answer a RuntimeStatus, not {:?}",
            response.result
        );
    };
    let none = String::new;
    json_from_records(&[
        ("core_running".to_owned(), status.core_running.to_string()),
        (
            "active_profile".to_owned(),
            status
                .active_profile
                .as_ref()
                .map(|id| id.0.clone())
                .unwrap_or_else(none),
        ),
        (
            "active_core".to_owned(),
            status.active_core.clone().unwrap_or_else(none),
        ),
        (
            "active_snapshot".to_owned(),
            status.active_snapshot.clone().unwrap_or_else(none),
        ),
        (
            "last_apply_plan_summary".to_owned(),
            status.last_apply_plan_summary.clone().unwrap_or_else(none),
        ),
        (
            "pending_recovery_decisions".to_owned(),
            status.pending_recovery_decisions.to_string(),
        ),
        (
            "last_recovery_summary".to_owned(),
            status.last_recovery_summary.clone().unwrap_or_else(none),
        ),
        (
            "last_failure".to_owned(),
            status.last_failure.clone().unwrap_or_else(none),
        ),
    ])
}

fn status_of(daemon: &DaemonApp, id: u64) -> ResponseEnvelope {
    handle_request(
        daemon,
        Actor::System,
        &envelope(Operation::Runtime(RuntimeOp::Status), id),
    )
}

/// Mid-flight dashboard open: the FIRST pull is exactly one `SnapshotJson` frame — the
/// Status query's own facts, restated — seq'd at the live edge (the last event seq), so the
/// patch stream continues at +1. No typed event frames ride along: the pre-snapshot
/// history is folded into the snapshot.
#[test]
fn a_dashboard_watch_opens_with_one_snapshot_frame_mid_flight() {
    let daemon = daemon("watch-dashboard-snapshot");
    apply_once(&daemon, 1);
    apply_once(&daemon, 2);
    let mut session = handshake(&daemon);

    let expected_json = status_json(&status_of(&daemon, 3));
    let live_edge = daemon
        .event_window(None)
        .expect("event window")
        .next_seq
        .saturating_sub(1);
    assert!(live_edge > 0, "the fixture must have real events first");

    let stream = open_watch(&daemon, &mut session, RuntimeSubscription::Dashboard, 4);
    let frames = pull(&daemon, &mut session, stream);
    assert_eq!(frames.len(), 1, "the first pull is exactly one frame");
    assert_eq!(frames[0].kind, StreamKind::Dashboard);
    assert_eq!(
        frames[0].seq, live_edge,
        "the snapshot sits at the live edge so patches continue at +1"
    );
    match &frames[0].payload {
        StreamPayload::SnapshotJson(json) => assert_eq!(
            json, &expected_json,
            "the snapshot is the Status query's own facts, restated as a stream frame"
        ),
        other => panic!("the first dashboard frame must be a snapshot, not {other:?}"),
    }
}

/// After the snapshot, only NEW events arrive — as the existing typed patch frames. The
/// events that predate the snapshot never re-deliver, a quiet pull delivers nothing (an
/// empty push would claim work happened), and the patches are exactly the events since the
/// snapshot, contiguous by seq.
#[test]
fn after_the_snapshot_only_new_events_arrive_as_patches() {
    let daemon = daemon("watch-dashboard-patch");
    apply_once(&daemon, 1);
    let mut session = handshake(&daemon);
    let stream = open_watch(&daemon, &mut session, RuntimeSubscription::Dashboard, 2);
    let snapshot = pull(&daemon, &mut session, stream);
    assert_eq!(snapshot.len(), 1);
    let snapshot_seq = snapshot[0].seq;

    // Nothing new: a pull delivers nothing at all.
    let quiet = pull(&daemon, &mut session, stream);
    assert!(
        quiet.is_empty(),
        "no news is no frames, not an empty push: {quiet:?}"
    );

    // A new apply puts new events on the log; the next pull is patches for exactly those.
    apply_once(&daemon, 3);
    let after = daemon.event_window(None).expect("window").next_seq;
    let patches = pull(&daemon, &mut session, stream);
    assert!(
        !patches.is_empty(),
        "new events must arrive as patch frames"
    );
    assert!(
        patches[0].seq > snapshot_seq,
        "patches continue after the snapshot: {snapshot_seq} vs {:?}",
        patches.iter().map(|f| f.seq).collect::<Vec<_>>()
    );
    assert_eq!(
        patches.iter().map(|f| f.seq).collect::<Vec<u64>>(),
        (snapshot_seq + 1..after).collect::<Vec<u64>>(),
        "patches are exactly the events since the snapshot, contiguous"
    );
    assert!(
        patches
            .iter()
            .all(|frame| !matches!(frame.payload, StreamPayload::SnapshotJson(_))),
        "the snapshot is a FIRST frame; it does not repeat"
    );
    assert!(
        patches
            .iter()
            .all(|frame| frame.kind == StreamKind::Dashboard),
        "every patch frame carries the dashboard kind"
    );
}

/// A connections watch opens with the connections page as its snapshot: the same items the
/// `runtime.connections` query serves, in the same order, with the page's own cursor and
/// revision — one source of truth for what "connected" means.
#[test]
fn a_connections_watch_opens_with_the_connections_page_as_its_snapshot() {
    let daemon = daemon("watch-connections-snapshot");
    apply_once(&daemon, 1);
    let mut session = handshake(&daemon);

    let page = handle_request(
        &daemon,
        Actor::System,
        &envelope(
            Operation::Runtime(RuntimeOp::Connections {
                query: ConnectionQuery {
                    page: PageRequest {
                        cursor: None,
                        limit: 50,
                    },
                },
            }),
            2,
        ),
    );
    let Ok(caly_api::OperationResult::ConnectionPage(page)) = page.result else {
        panic!("the connections query must answer a page");
    };
    assert!(
        !page.items.is_empty(),
        "the applied demo profile must list its nodes"
    );

    let mut records = Vec::new();
    for (index, item) in page.items.iter().enumerate() {
        records.push((format!("item.{index}.id"), item.id.0.clone()));
        records.push((
            format!("item.{index}.destination"),
            item.destination.clone(),
        ));
        records.push((
            format!("item.{index}.process"),
            item.process.clone().unwrap_or_default(),
        ));
    }
    records.push(("next".to_owned(), page.next.clone().unwrap_or_default()));
    records.push(("revision".to_owned(), page.revision.to_string()));
    let expected = json_from_records(&records);

    let stream = open_watch(&daemon, &mut session, RuntimeSubscription::Connections, 3);
    let frames = pull(&daemon, &mut session, stream);
    assert_eq!(frames.len(), 1, "the first pull is exactly one frame");
    assert_eq!(frames[0].kind, StreamKind::Connections);
    match &frames[0].payload {
        StreamPayload::SnapshotJson(json) => assert_eq!(
            json, &expected,
            "the snapshot is the connections page, restated as a stream frame"
        ),
        other => panic!("the first connections frame must be a snapshot, not {other:?}"),
    }
}

/// A producer with a long backlog is served in BOUNDED pulls: every pull carries at most
/// `MAX_FRAMES_PER_PULL` frames, the pulls together cover the retained window exactly once
/// (contiguous by seq, nothing lost, nothing repeated), and the cursor picks up where the
/// last pull stopped. The retained window — not the pull — is the liability holder.
#[test]
fn a_long_backlog_is_served_in_bounded_pulls_with_nothing_lost_or_repeated() {
    let daemon = daemon("watch-bounded-pulls");
    // Enough applies to put well more than one pull's worth of events on the log.
    for id in 1..=12 {
        apply_once(&daemon, id);
    }
    let total = daemon.event_window(None).expect("window");
    assert!(
        total.next_seq as usize > MAX_FRAMES_PER_PULL,
        "the fixture must exceed one pull's bound ({} events)",
        total.next_seq
    );
    let mut session = handshake(&daemon);

    // Logs: an event-bridged kind with no snapshot semantics — the backlog path itself.
    let stream = open_watch(&daemon, &mut session, RuntimeSubscription::Logs, 900);
    let mut seen: Vec<u64> = Vec::new();
    for _ in 0..8 {
        let frames = pull(&daemon, &mut session, stream);
        if frames.is_empty() {
            break;
        }
        assert!(
            frames.len() <= MAX_FRAMES_PER_PULL,
            "a pull is bounded: {} frames",
            frames.len()
        );
        for frame in &frames {
            seen.push(frame.seq);
        }
        if seen.len() as u64 >= total.next_seq {
            break;
        }
    }
    assert_eq!(
        seen.len(),
        total.next_seq as usize,
        "the pulls together deliver every retained event exactly once"
    );
    let mut sorted = seen.clone();
    sorted.sort_unstable();
    sorted.dedup();
    assert_eq!(sorted.len(), seen.len(), "no seq is delivered twice");
    assert_eq!(
        (sorted.first().copied().unwrap_or(0)..=sorted.last().copied().unwrap_or(0)).count(),
        sorted.len(),
        "coverage is contiguous from the first retained event to the live edge"
    );
}

/// A client that falls behind RETENTION gets a named Reset — not a stale replay, not a
/// silent skip. This is the formal slow-client policy (`IPC_STREAM_POLICY §7.4`) made
/// reachable: the engine's event ring retains 256 events, so a watcher parked at an old
/// seq while the applies roll the window past it must be told to re-open.
#[test]
fn a_client_that_falls_behind_retention_gets_a_named_reset() {
    let daemon = daemon("watch-slow-client-reset");
    apply_once(&daemon, 1);
    let mut session = handshake(&daemon);
    let stream = open_watch(&daemon, &mut session, RuntimeSubscription::Dashboard, 2);
    let snapshot = pull(&daemon, &mut session, stream);
    assert_eq!(snapshot.len(), 1);
    let parked_at = snapshot[0].seq;

    // Roll the retention window past the parked cursor (the ring keeps 256 events).
    for id in 3..=70 {
        apply_once(&daemon, id);
    }
    let window = daemon.event_window(None).expect("window");
    assert!(
        window.retained_from.0 > parked_at + 1,
        "the fixture must actually age the cursor out (retained from {}, parked at {parked_at})",
        window.retained_from.0
    );

    let frames = pull(&daemon, &mut session, stream);
    assert!(
        !frames.is_empty(),
        "the daemon must answer the stalled pull"
    );
    assert!(
        frames.iter().any(|frame| matches!(
            frame.payload,
            StreamPayload::Reset {
                reason: ResetReason::StateGapTooLarge
            }
        )),
        "a stalled client is told to re-open by name, not fed stale or skipped frames: {frames:?}"
    );
}

/// Round 133 (`R131-F1`): the session's opened-stream table is bounded. The wire door's
/// job-follow table has refused by name at 64 since round 96; the watch family's session
/// table had no cap at all — harmless while only harness/tests reach it, an unbounded
/// growth face the moment watch goes on the wire. The 65th stream is refused BY NAME, before
/// anything is allocated, through the same error door every other refusal uses — and the
/// session itself stays alive for non-stream work.
#[test]
fn a_session_stream_table_is_bounded_and_refuses_by_name_when_full() {
    let daemon = daemon("watch-stream-table-cap");
    let mut session = handshake(&daemon);
    for request_id in 2..=65u64 {
        let stream = open_watch(
            &daemon,
            &mut session,
            RuntimeSubscription::Dashboard,
            request_id,
        );
        assert!(
            stream.0 >= 1,
            "the first 64 streams must open (request {request_id})"
        );
    }
    let overflow = session
        .handle_request(
            &daemon,
            &envelope(
                Operation::Runtime(RuntimeOp::Watch {
                    subscription: RuntimeSubscription::Dashboard,
                }),
                66,
            ),
        )
        .expect("the session answers");
    let refusal = overflow
        .result
        .expect_err("the 65th stream must be refused, not opened");
    assert!(
        refusal
            .summary
            .contains("the session stream table is full (64)"),
        "the refusal names the table and its cap: {refusal:?}"
    );
    assert!(
        refusal
            .remediation
            .as_deref()
            .is_some_and(|text| !text.is_empty()),
        "the refusal says what to do about it: {refusal:?}"
    );

    // The session is not poisoned by the refusal: a query through the same session answers.
    let status = session
        .handle_request(
            &daemon,
            &envelope(Operation::Runtime(caly_api::RuntimeOp::Status), 67),
        )
        .expect("the session stays alive after a stream-table refusal");
    assert!(
        matches!(
            status.result,
            Ok(caly_api::OperationResult::RuntimeStatus(_))
        ),
        "a non-stream request still answers: {:?}",
        status.result
    );
}
