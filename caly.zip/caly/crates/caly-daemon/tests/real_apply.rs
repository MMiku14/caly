//! Real-backend apply judges (round 55): the same executor, the same daemon command path,
//! a **real** effect runtime (`effect_std::StdEffectRuntime`) running a real mihomo from the
//! workspace's pinned assets.
//!
//! Three questions, three answers an operator can act on:
//!
//! 1. *全链真核活* — a clean (no-TUN) profile applies end to end and leaves a real core
//!    alive under the daemon, answering its own controller;
//! 2. *restart 旧核真停* — the second apply's restart sequence stops the **old** core for
//!    real (its pid leaves the process table) before the new one takes over;
//! 3. *TUN 诚实拒绝* — a TUN profile is refused **by name** (`unsupported-net-apply`), no
//!    core spawned, the materialized artifact un-materialized — a green path here would
//!    mean the privileged Platform face exists, and it does not (`ADR-042 §2.2`).
//! 4. *第二核心真活* (round 58, `ADR-046`) — a sing-box profile runs the SECOND real core
//!    end to end: pinned tar.gz verified, JSON envelope merged (not concatenated), the
//!    clash-api controller answering `/version`;
//! 5. *跨核复活* (round 58, `ADR-046 §5`) — rollback across a core switch revives the
//!    sing-box deployment the mihomo one displaced, identity-probed against its own
//!    digest;
//! 6. *经核取回* (round 59, `ADR-047`) — an `ActiveCore` fetch really goes through the live
//!    core's mixed inbound (a real proxied round trip on both cores), and with no core it
//!    fails by name, never by silently going direct;
//! 7. *凭据边界* (round 59, `ADR-047 §4`) — the demo credential lives in the artifact on
//!    disk and in NOT ONE word the job stream says about it.
//!
//! Every test owns its scratch under `target/` (disk, not the 993M `/tmp` tmpfs that real
//! cores filled once already — `DEVELOPMENT_LOG_2026-08-27.md §6`) and stops its core
//! before returning; the `ScratchDir` guard removes the tree even on assertion failure.

// The adoption judges of round 125 make this file a small process harness too: delivering
// signals to a core that must survive its runtime (`/bin/kill`), waiting out bounded windows
// (`Instant::now`), and naming scratch paths (`PathBuf`). The workspace bans those symbols to
// keep the core pure (`ADR-011`); the lift is scoped to this file alone, matching the e2e
// harnesses (`calyd_wire.rs`, `caly_cli_e2e.rs`).
#![allow(clippy::disallowed_methods, clippy::disallowed_types)]

use std::path::Path;
use std::sync::Arc;
use std::time::Duration;

use caly_api::{
    ApplyRequest, JobId, ProfileId, ProfileOp, ProtocolVersion, RequestEnvelope, RequestId, Role,
    TraceId,
};
use caly_common::Actor;
use caly_daemon::effect_std::{CoreAssets, StdEffectRuntime};
use caly_daemon::{DaemonApp, DaemonBootstrapConfig};

// --------------------------------------------------------------------------------------------
// harness

struct ScratchDir {
    path: String,
}

impl Drop for ScratchDir {
    fn drop(&mut self) {
        let _ = std::fs::remove_dir_all(&self.path);
    }
}

/// A per-test runtime root under `target/`, not `/tmp`: one real core is ~85MB on disk and
/// the tmpfs has been filled to 100% by exactly that before.
fn scratch(label: &str) -> ScratchDir {
    let path = format!(
        "{}/real-apply-{label}-{}",
        env!("CARGO_TARGET_TMPDIR"),
        std::process::id()
    );
    let _ = std::fs::remove_dir_all(&path);
    std::fs::create_dir_all(&path).expect("scratch dir");
    ScratchDir { path }
}

fn envelope(profile_id: &str, request_id: u64) -> RequestEnvelope {
    RequestEnvelope {
        protocol: ProtocolVersion { major: 1, minor: 0 },
        request_id: RequestId(request_id),
        trace_id: TraceId::new(format!("trace-real-apply-{request_id}")),
        deadline_ms: Some(60_000),
        expected_revision: None,
        idempotency_key: Some(format!("real-apply-{request_id}")),
        role: Role::Admin,
        io_budget: None,
        operation: caly_api::Operation::Profile(ProfileOp::Apply {
            request: ApplyRequest {
                profile_id: ProfileId(profile_id.to_owned()),
                dry_run: false,
                strict: false,
            },
        }),
    }
}

/// A daemon whose engine drives the **real** effect runtime over the daemon's own storage
/// backend. The runtime is handed back too: liveness/shutdown questions go to the thing
/// that owns the child, not to a second bookkeeping.
fn real_app(label: &str) -> (DaemonApp, Arc<StdEffectRuntime>, ScratchDir) {
    let guard = scratch(label);
    let mut app = DaemonApp::bootstrap(DaemonBootstrapConfig {
        instance_id: format!("real-apply-{label}"),
        protocol_version: ProtocolVersion { major: 1, minor: 0 },
        recover_on_start: false,
    });
    let effects = Arc::new(StdEffectRuntime::new(
        guard.path.clone(),
        app.engine_storage(),
        CoreAssets::workspace_default(),
    ));
    app.set_effect_runtime(effects.clone())
        .expect("real runtime swap");
    (app, effects, guard)
}

/// Submit one apply and drain exactly one cycle, the command path's honest shape.
fn apply_once(app: &DaemonApp, profile_id: &str, request_id: u64) -> (u64, String) {
    let submitted = app
        .submit_request_as_command(Actor::Cli, &envelope(profile_id, request_id))
        .expect("admin may submit apply")
        .expect("apply maps to a command");
    assert_eq!(app.drain_engine_once().expect("worker drain"), 1);
    let projection = app
        .follow_job_projection(JobId(submitted.job_id()), None)
        .expect("projection")
        .expect("job exists");
    (submitted.job_id(), projection.summary.state.clone())
}

fn summary_of(app: &DaemonApp, job_id: u64) -> caly_api::JobFollowView {
    app.follow_job_projection(JobId(job_id), None)
        .expect("projection")
        .expect("job exists")
        .summary
}

fn pid_alive(pid: u32) -> bool {
    Path::new(&format!("/proc/{pid}")).exists()
}

/// Kill-after-stop hygiene (`DEVELOPMENT_LOG`: never trust a kill without a sleep): stop
/// reports the reaped exit, and the process table confirms it a beat later.
fn assert_pid_gone(pid: u32) {
    std::thread::sleep(Duration::from_millis(150));
    assert!(!pid_alive(pid), "pid {pid} must be gone after stop");
}

// --------------------------------------------------------------------------------------------
// judge 1 — the whole chain, a real core, alive under the daemon

#[test]
fn nightshift_applies_end_to_end_with_a_live_real_core() {
    let (app, effects, _scratch) = real_app("nightshift");

    let (job, state) = apply_once(&app, "nightshift", 101);
    assert_eq!(state, "completed", "summary: {:?}", summary_of(&app, job));

    let summary = summary_of(&app, job);
    assert_eq!(summary.failure_code, None, "no failure: {summary:?}");
    assert!(
        summary
            .last_stage
            .as_deref()
            .unwrap_or_default()
            .starts_with("snapshot.committed"),
        "last stage must be the commit, got {:?}",
        summary.last_stage
    );

    // The daemon's own view: the profile is active and a core is recorded.
    let runtime = app.runtime_snapshot().expect("runtime snapshot");
    assert_eq!(
        runtime.active_profile,
        Some(ProfileId("nightshift".to_owned()))
    );
    assert!(runtime.active_snapshot.is_some(), "{runtime:?}");

    // The host's view: a real mihomo is running and answering its own controller. This is
    // the sentence this whole round exists to make true — asserted against the process
    // table and the core itself, not against a simulated world's memory of one.
    let pid = effects
        .live_pid()
        .expect("a real core must be live after a completed apply");
    assert!(pid_alive(pid), "pid {pid} must be in the process table");
    assert!(
        effects.controller_ready(),
        "the live core must answer its controller"
    );

    // Teardown is part of the judge: leaving cores behind is a failed test, not a footnote.
    let exit = effects.shutdown(3_000).expect("shutdown stops the core");
    assert_pid_gone(pid);
    let _ = exit;
}

// --------------------------------------------------------------------------------------------
// judge 2 — rollback stops the NEW core and revives the OLD deployment (round 57)
//
// Round 56 made rollback honest about teardown (stop the new core, un-materialize); round
// 57 (`ADR-045`) finishes the sentence an operator actually asked for: after a rollback
// the target snapshot's deployment is ALIVE again — same artifact, same file, a fresh pid,
// answering its controller, with the identity probe having proven the core runs the
// TARGET's config. Judged against the process table and the filesystem, not a world model.

#[test]
fn rollback_stops_the_new_core_and_revives_the_old_deployment() {
    let (app, effects, guard) = real_app("rollback");

    // Deployment A: capture its snapshot id (the rollback target) and its file.
    let (job_a, state_a) = apply_once(&app, "nightshift-a", 201);
    assert_eq!(
        state_a,
        "completed",
        "first apply: {:?}",
        summary_of(&app, job_a)
    );
    let pid_a = effects.live_pid().expect("apply A leaves a live core");
    let snapshot_a = app
        .runtime_snapshot()
        .expect("runtime snapshot")
        .active_snapshot
        .expect("apply A commits a snapshot");
    let config_a = Path::new(&guard.path)
        .join("runtime")
        .join("nightshift-a")
        .join("config.yaml");
    let config_b = Path::new(&guard.path)
        .join("runtime")
        .join("nightshift-b")
        .join("config.yaml");

    // Deployment B replaces it.
    let (job_b, state_b) = apply_once(&app, "nightshift-b", 202);
    assert_eq!(
        state_b,
        "completed",
        "second apply: {:?}",
        summary_of(&app, job_b)
    );
    let pid_b = effects.live_pid().expect("apply B leaves a live core");
    assert_ne!(pid_b, pid_a);

    // Roll back to A, naming A's snapshot.
    let submitted = app
        .submit_request_as_command(
            Actor::Cli,
            &RequestEnvelope {
                protocol: ProtocolVersion { major: 1, minor: 0 },
                request_id: RequestId(203),
                trace_id: TraceId::new("trace-real-apply-rollback"),
                deadline_ms: Some(60_000),
                expected_revision: None,
                idempotency_key: Some("real-apply-203".to_owned()),
                role: Role::Admin,
                io_budget: None,
                operation: caly_api::Operation::Profile(ProfileOp::Rollback {
                    request: caly_api::RollbackRequest {
                        snapshot_id: Some(snapshot_a.clone()),
                    },
                }),
            },
        )
        .expect("admin may submit rollback")
        .expect("rollback maps to a command");
    assert_eq!(app.drain_engine_once().expect("worker drain"), 1);
    let summary = summary_of(&app, submitted.job_id());
    assert_eq!(
        summary.state, "completed",
        "rollback must succeed (revive included): {summary:?}"
    );

    // The revival's own evidence: the stage and the identity probe line are in the job.
    let events = app
        .job_events(JobId(submitted.job_id()))
        .expect("events")
        .expect("job");
    let lines = events
        .iter()
        .filter_map(|event| match event {
            caly_engine::JobEvent::Log { message, .. } => Some(message.clone()),
            caly_engine::JobEvent::Stage { stage, .. } => Some(stage.clone()),
            _ => None,
        })
        .collect::<Vec<_>>();
    assert!(
        lines
            .iter()
            .any(|line| line.contains("rollback.redeploy.executed")),
        "the revival must be its own observable stage: {lines:?}"
    );
    assert!(
        lines
            .iter()
            .any(|line| line.contains("ConfigIdentity") && line.contains("mihomo:")),
        "the revived core must have been identity-probed against the target's config: {lines:?}"
    );

    // The host after rollback: B is dead, A lives again under a fresh pid.
    assert!(
        !pid_alive(pid_b),
        "the NEW core (pid {pid_b}) must be stopped by the compensations"
    );
    let pid_c = effects
        .live_pid()
        .expect("the old deployment must be revived");
    assert_ne!(pid_c, pid_b);
    assert!(pid_alive(pid_c), "the revived core must be running");
    assert!(
        effects.controller_ready(),
        "the revived core answers its controller"
    );
    assert!(
        config_a.exists(),
        "the target's artifact is materialized again"
    );
    assert!(!config_b.exists(), "the replaced deployment's file is gone");

    // And the engine's deployment memory is the revival: re-applying A is an honest Noop.
    let (job_d, state_d) = apply_once(&app, "nightshift-a", 204);
    assert_eq!(
        state_d,
        "completed",
        "re-apply after revive: {:?}",
        summary_of(&app, job_d)
    );
    let runtime = app.runtime_snapshot().expect("runtime snapshot");
    assert_eq!(
        runtime.last_apply_plan_summary.as_deref(),
        Some("Noop"),
        "the revived deployment is what the engine remembers: {:?}",
        runtime.last_apply_plan_summary
    );
    assert_eq!(
        effects.live_pid(),
        Some(pid_c),
        "a Noop leaves the revived core alone"
    );

    let _ = effects.shutdown(3_000).expect("shutdown");
    assert_pid_gone(pid_c);
}

// --------------------------------------------------------------------------------------------
// judge 4 — the restart sequence stops the OLD core for real (redeemed, round 56)
//
// Round 55 found the apply workflow planned every demo apply as a first install
// (`current = None`), so a *second* apply never carried StopCore and the old core was
// orphaned. Round 56 threads the engine's last committed artifact into planning
// (`ADR-044 §5.3` closed): a different profile is a Restart whose first cutover step
// stops what runs — and this judge holds that sentence against the process table.

#[test]
fn restart_sequence_actually_stops_the_old_core() {
    let (app, effects, _scratch) = real_app("restart");

    let (job_a, state_a) = apply_once(&app, "nightshift-a", 201);
    assert_eq!(
        state_a,
        "completed",
        "first apply: {:?}",
        summary_of(&app, job_a)
    );
    let old_pid = effects.live_pid().expect("first apply leaves a live core");
    assert!(pid_alive(old_pid));

    // A different profile: different artifact, different materialization path — the plan
    // must be a Restart that stops the running core before spawning its replacement.
    let (job_b, state_b) = apply_once(&app, "nightshift-b", 202);
    assert_eq!(
        state_b,
        "completed",
        "second apply: {:?}",
        summary_of(&app, job_b)
    );
    let runtime = app.runtime_snapshot().expect("runtime snapshot");
    assert_eq!(
        runtime.last_apply_plan_summary.as_deref(),
        Some("Restart"),
        "a profile switch must plan a Restart: {:?}",
        runtime.last_apply_plan_summary
    );

    let new_pid = effects.live_pid().expect("second apply leaves a live core");
    assert_ne!(
        new_pid, old_pid,
        "the replacement must be a different process"
    );
    assert!(
        !pid_alive(old_pid),
        "the OLD core (pid {old_pid}) must be really stopped by the plan's StopCore"
    );
    assert!(pid_alive(new_pid), "the new core must be running");
    assert!(
        effects.controller_ready(),
        "the new core answers its controller"
    );

    let _ = effects
        .shutdown(3_000)
        .expect("shutdown stops the new core");
    assert_pid_gone(new_pid);
}

// --------------------------------------------------------------------------------------------
// judge 5 — re-applying the same profile is an honest Noop (round 56)
//
// The same demo profile compiles to the same artifact digest, and a plan against the
// artifact that is already deployed is a Noop: no steps, no spawn, no stop — the core
// that runs keeps running, under the same pid. This is the idempotent shape of "apply
// what is already applied", judged on the real host.

#[test]
fn re_applying_the_same_profile_is_a_noop_that_leaves_the_core_alone() {
    let (app, effects, _scratch) = real_app("noop");

    let (job_a, state_a) = apply_once(&app, "nightshift", 401);
    assert_eq!(
        state_a,
        "completed",
        "first apply: {:?}",
        summary_of(&app, job_a)
    );
    let pid = effects
        .live_pid()
        .expect("a live core after the first apply");

    // A *different* idempotency key is a different command: it must run, and what it
    // must do is nothing — plan kind Noop, no effect steps, the core untouched.
    let (job_b, state_b) = apply_once(&app, "nightshift", 402);
    assert_eq!(
        state_b,
        "completed",
        "a Noop apply still completes: {:?}",
        summary_of(&app, job_b)
    );
    let runtime = app.runtime_snapshot().expect("runtime snapshot");
    assert_eq!(
        runtime.last_apply_plan_summary.as_deref(),
        Some("Noop"),
        "same artifact already deployed must plan a Noop: {:?}",
        runtime.last_apply_plan_summary
    );
    assert_eq!(
        effects.live_pid(),
        Some(pid),
        "a Noop must not touch the live core — same pid"
    );
    assert!(effects.controller_ready(), "the core never even noticed");

    let _ = effects.shutdown(3_000).expect("shutdown");
    assert_pid_gone(pid);
}

// --------------------------------------------------------------------------------------------
// judge 6 — TUN is refused honestly, with cleanup, not pretended

#[test]
fn tun_profile_is_refused_by_name_and_leaves_no_core() {
    let (app, effects, guard) = real_app("tun-refused");

    let (job, state) = apply_once(&app, "demo-tun-profile", 301);
    assert_eq!(
        state,
        "failed",
        "a TUN apply must fail, not pretend: {:?}",
        summary_of(&app, job)
    );

    let summary = summary_of(&app, job);
    // The generic class (`UNAVAILABLE`, retryable) is the projection's honest ceiling — the
    // *identity* of the refusal rides in the failure detail, which round 55 made carry the
    // step's own words. An anonymous "a net step failed" here would be exactly the
    // dishonesty this judge exists to catch.
    assert_eq!(
        summary.failure_code.as_deref(),
        Some("UNAVAILABLE"),
        "the refusal must fail the job: {summary:?}"
    );
    let events = app.job_events(JobId(job)).expect("events").expect("job");
    let failed_detail = events
        .iter()
        .find_map(|event| match event {
            caly_engine::JobEvent::Failed { error } => Some(error.detail.clone()),
            _ => None,
        })
        .flatten()
        .unwrap_or_default();
    assert!(
        failed_detail.contains("deliberate absence")
            && failed_detail.contains("ADR-042")
            && failed_detail.contains("TUN"),
        "the refusal must name itself, its authority and its subject, got: {failed_detail:?}"
    );

    // No core was spawned, and the artifact the plan had already materialized was
    // un-materialized by compensation — the host looks like the apply never happened.
    assert!(effects.live_pid().is_none(), "no core may be left running");
    let runtime_root = Path::new(&guard.path);
    let runtime_dir = runtime_root.join("runtime").join("demo-tun-profile");
    assert!(
        !runtime_dir.join("caly-run.yaml").exists(),
        "no run envelope may survive a refused apply"
    );

    // And the daemon did not activate a profile it failed to deploy.
    let runtime = app.runtime_snapshot().expect("runtime snapshot");
    assert!(
        runtime.active_profile.is_none(),
        "a refused apply must not activate anything: {runtime:?}"
    );
}

// --------------------------------------------------------------------------------------------
// judge 7 — the second core is real too: sing-box end to end (round 58)
//
// The mihomo judges proved the executor/runtime contract on one core. This one holds the
// same contract on the second: the pinned tar.gz is digest-checked, the artifact is JSON,
// the envelope MERGES the deployment facts into the adapter's object (a string splice
// would be its own lie), and the core that answers the controller is the one the plan
// named — judged on the process table, the filesystem, and the job's own evidence.

#[test]
fn singbox_profile_runs_a_real_second_core() {
    let (app, effects, guard) = real_app("singbox");

    let (job, state) = apply_once(&app, "nightshift-sing", 501);
    assert_eq!(
        state,
        "completed",
        "a sing-box apply must run end to end: {:?}",
        summary_of(&app, job)
    );
    let pid = effects.live_pid().expect("the sing-box core is live");
    assert!(pid_alive(pid));
    assert!(
        effects.controller_ready(),
        "the sing-box clash-api controller answers /version"
    );

    // The host truth that the tar.gz really unpacked: the core binary and its libcronet
    // sidecar sit in the instance dir next to the envelope (step evidence observations
    // do not ride the job event stream — the files are the harder witness anyway).
    let instance_dir = Path::new(&guard.path)
        .join("runtime")
        .join("nightshift-sing");
    assert!(
        instance_dir.join("sing-box").exists(),
        "the pinned archive's core binary is unpacked in the instance dir: {instance_dir:?}"
    );
    assert!(
        instance_dir.join("libcronet.so").exists(),
        "the archive's sidecar unpacked with it: {instance_dir:?}"
    );

    // The artifact materialized at the sing-box entrypoint, and the envelope is a MERGE:
    // the adapter's JSON with the runtime's own ports written in — never the render's
    // fixed 7890, never a concatenated suffix.
    let config_json = Path::new(&guard.path)
        .join("runtime")
        .join("nightshift-sing")
        .join("config.json");
    assert!(
        config_json.exists(),
        "the JSON artifact is materialized: {config_json:?}"
    );
    let run_json = Path::new(&guard.path)
        .join("runtime")
        .join("nightshift-sing")
        .join("caly-run.json");
    let envelope = std::fs::read_to_string(&run_json)
        .unwrap_or_else(|error| panic!("the envelope must exist at {run_json:?}: {error}"));
    assert!(
        envelope.contains("\"external_controller\": \"127.0.0.1:"),
        "the clash-api controller is merged into the object: {envelope}"
    );
    assert!(
        !envelope.contains("7890"),
        "the mixed listen port is a deployment fact the runtime owns, not the render's: {envelope}"
    );

    // And it really stops.
    let _ = effects
        .shutdown(3_000)
        .expect("shutdown stops the sing-box core");
    assert_pid_gone(pid);
}

// --------------------------------------------------------------------------------------------
// judge 8 — rollback across a core switch revives the sing-box deployment (round 58)
//
// Round 57's revival was mihomo-only by honest scope. With the second spawn face real,
// the harder sentence is now held too: mihomo displaces sing-box, rollback revives the
// SING-BOX deployment — its JSON artifact, its tar.gz, its clash-api controller — with
// the identity probe proving the revived core runs the target's config. The engine's
// memory after that is the revival (re-apply is a Noop that leaves the pid alone).

#[test]
fn rollback_revives_a_singbox_deployment_across_a_mihomo_interlude() {
    let (app, effects, guard) = real_app("singbox-revive");

    // Deployment A: sing-box.
    let (job_a, state_a) = apply_once(&app, "nightshift-sing", 601);
    assert_eq!(
        state_a,
        "completed",
        "sing-box apply A: {:?}",
        summary_of(&app, job_a)
    );
    let pid_a = effects.live_pid().expect("sing-box core A is live");
    let snapshot_a = app
        .runtime_snapshot()
        .expect("runtime snapshot")
        .active_snapshot
        .expect("apply A commits a snapshot");
    let config_sing = Path::new(&guard.path)
        .join("runtime")
        .join("nightshift-sing")
        .join("config.json");
    let config_mihomo = Path::new(&guard.path)
        .join("runtime")
        .join("nightshift-b")
        .join("config.yaml");

    // Deployment B: mihomo, displacing the sing-box core across a Restart.
    let (job_b, state_b) = apply_once(&app, "nightshift-b", 602);
    assert_eq!(
        state_b,
        "completed",
        "mihomo apply B: {:?}",
        summary_of(&app, job_b)
    );
    let pid_b = effects.live_pid().expect("mihomo core B is live");
    assert_ne!(pid_b, pid_a);
    assert!(
        !pid_alive(pid_a),
        "the restart stopped the sing-box core for real"
    );

    // Roll back to A: the revival must dispatch on the RECORDED identity — sing-box.
    let submitted = app
        .submit_request_as_command(
            Actor::Cli,
            &RequestEnvelope {
                protocol: ProtocolVersion { major: 1, minor: 0 },
                request_id: RequestId(603),
                trace_id: TraceId::new("trace-real-apply-singbox-revive"),
                deadline_ms: Some(60_000),
                expected_revision: None,
                idempotency_key: Some("real-apply-603".to_owned()),
                role: Role::Admin,
                io_budget: None,
                operation: caly_api::Operation::Profile(ProfileOp::Rollback {
                    request: caly_api::RollbackRequest {
                        snapshot_id: Some(snapshot_a.clone()),
                    },
                }),
            },
        )
        .expect("admin may submit rollback")
        .expect("rollback maps to a command");
    assert_eq!(app.drain_engine_once().expect("worker drain"), 1);
    let summary = summary_of(&app, submitted.job_id());
    assert_eq!(
        summary.state, "completed",
        "the cross-core rollback must succeed (revive included): {summary:?}"
    );

    let events = app
        .job_events(JobId(submitted.job_id()))
        .expect("events")
        .expect("job");
    let lines = events
        .iter()
        .filter_map(|event| match event {
            caly_engine::JobEvent::Log { message, .. } => Some(message.clone()),
            caly_engine::JobEvent::Stage { stage, .. } => Some(stage.clone()),
            _ => None,
        })
        .collect::<Vec<_>>();
    assert!(
        lines
            .iter()
            .any(|line| line.contains("rollback.redeploy.executed")),
        "the revival is its own observable stage: {lines:?}"
    );
    assert!(
        lines
            .iter()
            .any(|line| line.contains("ConfigIdentity") && line.contains("singbox:")),
        "the revived core is identity-probed against the sing-box target's digest: {lines:?}"
    );

    // The host after rollback: the mihomo core is dead, the sing-box deployment lives.
    assert!(
        !pid_alive(pid_b),
        "the mihomo core (pid {pid_b}) is stopped"
    );
    let pid_c = effects
        .live_pid()
        .expect("the sing-box deployment is revived");
    assert_ne!(pid_c, pid_b);
    assert!(pid_alive(pid_c));
    assert!(
        effects.controller_ready(),
        "the revived sing-box core answers its clash-api controller"
    );
    assert!(
        config_sing.exists(),
        "the sing-box JSON artifact is materialized again"
    );
    assert!(
        !config_mihomo.exists(),
        "the mihomo deployment's file is gone"
    );

    // The engine's deployment memory is the revival.
    let (job_d, state_d) = apply_once(&app, "nightshift-sing", 604);
    assert_eq!(
        state_d,
        "completed",
        "re-apply after revive: {:?}",
        summary_of(&app, job_d)
    );
    let runtime = app.runtime_snapshot().expect("runtime snapshot");
    assert_eq!(
        runtime.last_apply_plan_summary.as_deref(),
        Some("Noop"),
        "the revived sing-box deployment is what the engine remembers: {:?}",
        runtime.last_apply_plan_summary
    );
    assert_eq!(
        effects.live_pid(),
        Some(pid_c),
        "a Noop leaves the revived core alone"
    );

    let _ = effects.shutdown(3_000).expect("shutdown");
    assert_pid_gone(pid_c);
}

// --------------------------------------------------------------------------------------------
// judge 9 — a fetch through the ACTIVE core, on both cores (round 59)
//
// `FetchRoute` used to be a column StdHttp ignored — ActiveCore silently went direct.
// This judge closes the loop with the realest evidence there is: spawn a core whose
// routing sends traffic direct (mihomo `direct` mode / sing-box `final: direct`), fetch a
// real URL through the core's mixed inbound, and expect the round trip to succeed THROUGH
// the core — then stop the core and expect the named refusal. The direct-mode profile is
// what makes the judge honest: the demo proxy nodes are inert, so any 200 came from the
// core dialing out itself.

#[test]
fn a_fetch_through_the_active_core_really_rides_the_core() {
    let _heavy = heavy_turnstile();
    let (app, effects, _guard) = real_app("core-route");

    // No core yet: the refusal is by name, not a dial.
    let fault = effects
        .fetch_via_active_core("http://example.com/", 65_536)
        .expect_err("no live core means no ActiveCore path");
    assert!(
        fault.contains("no live core"),
        "the refusal must name what is missing: {fault}"
    );

    // mihomo in direct mode: every proxied request is dialed directly by the core.
    let (job_a, state_a) = apply_once(&app, "nightshift-direct", 701);
    assert_eq!(
        state_a,
        "completed",
        "the direct-mode mihomo apply must succeed: {:?}",
        summary_of(&app, job_a)
    );
    let pid_a = effects.live_pid().expect("the mihomo core is live");
    let status = effects
        .fetch_via_active_core("http://example.com/", 65_536)
        .expect("a real round trip through the mihomo mixed inbound");
    assert_eq!(status, 200, "example.com answers through the core");

    let _ = effects
        .shutdown(3_000)
        .expect("shutdown stops the mihomo core");
    assert_pid_gone(pid_a);
    let fault = effects
        .fetch_via_active_core("http://example.com/", 65_536)
        .expect_err("a stopped core closes its route");
    assert!(
        fault.contains("no live core"),
        "after a stop the route must fail by name, not by dialing a freed port: {fault}"
    );

    // The second core pays the toll in full (round 60 closes `ADR-047 §5.1`): a
    // DIRECT-mode sing-box demo routes everything out the direct outbound (`ADR-048 §3`),
    // so a fetch through its mixed inbound is a real proxied round trip — not a hang on
    // the demo topology's dead WireGuard tunnel.
    let (job_b, state_b) = apply_once(&app, "nightshift-sing-direct", 702);
    assert_eq!(
        state_b,
        "completed",
        "the direct-mode sing-box apply must succeed: {:?}",
        summary_of(&app, job_b)
    );
    let pid_b = effects.live_pid().expect("the sing-box core is live");
    let status = effects
        .fetch_via_active_core("http://example.com/", 65_536)
        .expect("a real round trip through the sing-box mixed inbound");
    assert_eq!(
        status, 200,
        "example.com answers through the second core too (direct mode, no dead tunnel)"
    );

    let _ = effects.shutdown(3_000).expect("shutdown");
    assert_pid_gone(pid_b);
}

// --------------------------------------------------------------------------------------------
// judge 10 — the credential's boundary is positional (round 59)
//
// The artifact must carry real values (a core refuses to parse a passwordless node), so
// the honest question is not "does the password exist" but "WHERE". This judge applies a
// real profile and holds the boundary: the materialized config file contains the demo
// credential; every line the job stream emitted about that apply — logs, stages, the
// follow view — contains none of it.

#[test]
fn the_demo_credential_never_leaves_the_artifact() {
    let (app, effects, guard) = real_app("canary");

    let (job, state) = apply_once(&app, "nightshift", 801);
    assert_eq!(state, "completed", "apply: {:?}", summary_of(&app, job));

    let events = app.job_events(JobId(job)).expect("events").expect("job");
    let spoken = events
        .iter()
        .filter_map(|event| match event {
            caly_engine::JobEvent::Log { message, .. } => Some(message.clone()),
            caly_engine::JobEvent::Stage { stage, .. } => Some(stage.clone()),
            _ => None,
        })
        .collect::<Vec<_>>();
    assert!(
        spoken.iter().all(|line| !line.contains("caly-demo")),
        "not one word the job says may carry the demo credential: {spoken:?}"
    );

    let config = Path::new(&guard.path)
        .join("runtime")
        .join("nightshift")
        .join("config.yaml");
    let body = std::fs::read_to_string(&config).expect("the artifact is on disk");
    assert!(
        body.contains("caly-demo"),
        "the artifact itself must carry the structural password the core needs"
    );

    let _ = effects.shutdown(3_000).expect("shutdown");
}

// --------------------------------------------------------------------------------------------
// judge 10 — the applied core names itself and counts its own traffic (round 69)
//
// `ProbeKind::CoreIdentity` / `ProbeKind::TelemetryTraffic` were added because a 200 from
// the controller is not an identity, and a skeleton telemetry is not the core's counters.
// The judge runs both real cores and asserts (a) the apply's own evidence carries the
// core's self-reported version beside the kind the plan spawned, (b) a fetch through the
// core moves the core's OWN cumulative counters — hardcoded zeros cannot pass — and
// (c) the same reads through the public controller surface agree with the probe path.

fn evidence_lines(app: &DaemonApp, job_id: u64) -> Vec<String> {
    let events = app
        .job_events(caly_api::JobId(job_id))
        .expect("events")
        .expect("job");
    events
        .iter()
        .filter_map(|event| match event {
            caly_engine::JobEvent::Log { message, .. } => Some(message.clone()),
            caly_engine::JobEvent::Stage { stage, .. } => Some(stage.clone()),
            _ => None,
        })
        .collect()
}

#[test]
fn the_applied_core_names_itself_and_counts_its_own_traffic() {
    let _heavy = heavy_turnstile();
    let (app, effects, _guard) = real_app("core-identity");

    // mihomo half: identity, counters, and the read-back through the shared parse path.
    let (job_a, state_a) = apply_once(&app, "nightshift-direct", 801);
    assert_eq!(
        state_a,
        "completed",
        "the direct-mode mihomo apply must carry the identity/telemetry probes: {:?}",
        summary_of(&app, job_a)
    );
    let lines_a = evidence_lines(&app, job_a);
    let identity_a = lines_a
        .iter()
        .find(|line| line.contains("probe.core-identity"))
        .unwrap_or_else(|| {
            panic!(
                "the mihomo apply carries a core-identity probe: {:?}",
                lines_a
            )
        });
    assert!(
        identity_a.contains("kind=mihomo"),
        "the identity names the kind the plan spawned: {identity_a}"
    );
    let version_a = identity_a
        .split("version=")
        .nth(1)
        .and_then(|rest| rest.split(" controller=").next())
        .unwrap_or("");
    assert!(
        version_a.contains("1.19.30"),
        "the identity is the pinned core's own version, not a literal: {identity_a}"
    );
    let telemetry_a = lines_a
        .iter()
        .find(|line| line.contains("probe.telemetry-traffic"))
        .unwrap_or_else(|| panic!("the mihomo apply carries a telemetry probe: {:?}", lines_a));
    assert!(
        telemetry_a.contains("upload_total=") && telemetry_a.contains("download_total="),
        "the telemetry evidence names both counters: {telemetry_a}"
    );
    // The counters are the core's, not the daemon's: a fetch through the core moves them.
    let (before_u, before_d) = effects
        .controller_traffic_totals()
        .expect("the counters read right after apply");
    let status = effects
        .fetch_via_active_core("http://example.com/", 65_536)
        .expect("a real round trip through the mihomo mixed inbound");
    assert_eq!(status, 200, "example.com answers through the core");
    let (after_u, after_d) = effects
        .controller_traffic_totals()
        .expect("the counters read after the fetch");
    assert!(
        after_u.saturating_add(after_d) > before_u.saturating_add(before_d),
        "the core's own counters moved with the fetch: before={before_u}+{before_d} after={after_u}+{after_d}"
    );
    let (kind, version) = effects.controller_identity().expect("identity readable");
    assert_eq!(kind, "mihomo");
    assert!(version.contains("1.19.30"), "read-back version {version}");

    let pid_a = effects.live_pid().expect("the mihomo core is live");
    let _ = effects
        .shutdown(3_000)
        .expect("shutdown stops the mihomo core");
    assert_pid_gone(pid_a);

    // sing-box half — the same three facts, no shared assumptions with the mihomo half.
    let (job_b, state_b) = apply_once(&app, "nightshift-sing-direct", 802);
    assert_eq!(
        state_b,
        "completed",
        "the direct-mode sing-box apply must carry the identity/telemetry probes: {:?}",
        summary_of(&app, job_b)
    );
    let lines_b = evidence_lines(&app, job_b);
    let identity_b = lines_b
        .iter()
        .find(|line| line.contains("probe.core-identity"))
        .unwrap_or_else(|| {
            panic!(
                "the sing-box apply carries a core-identity probe: {:?}",
                lines_b
            )
        });
    assert!(
        identity_b.contains("kind=singbox"),
        "the identity names the kind the plan spawned: {identity_b}"
    );
    let version_b = identity_b
        .split("version=")
        .nth(1)
        .and_then(|rest| rest.split(" controller=").next())
        .unwrap_or("");
    assert!(
        version_b.contains("1.13.20"),
        "the identity is the pinned core's own version, not a literal: {identity_b}"
    );
    let telemetry_b = lines_b
        .iter()
        .find(|line| line.contains("probe.telemetry-traffic"))
        .unwrap_or_else(|| {
            panic!(
                "the sing-box apply carries a telemetry probe: {:?}",
                lines_b
            )
        });
    assert!(
        telemetry_b.contains("upload_total=") && telemetry_b.contains("download_total="),
        "the telemetry evidence names both counters: {telemetry_b}"
    );
    let (before_u, before_d) = effects
        .controller_traffic_totals()
        .expect("the counters read right after apply");
    let status = effects
        .fetch_via_active_core("http://example.com/", 65_536)
        .expect("a real round trip through the sing-box mixed inbound");
    assert_eq!(status, 200, "example.com answers through the core");
    let (after_u, after_d) = effects
        .controller_traffic_totals()
        .expect("the counters read after the fetch");
    assert!(
        after_u.saturating_add(after_d) > before_u.saturating_add(before_d),
        "the core's own counters moved with the fetch: before={before_u}+{before_d} after={after_u}+{after_d}"
    );
    let (kind, version) = effects.controller_identity().expect("identity readable");
    assert_eq!(kind, "singbox");
    assert!(version.contains("1.13.20"), "read-back version {version}");

    let pid_b = effects.live_pid().expect("the sing-box core is live");
    let _ = effects
        .shutdown(3_000)
        .expect("shutdown stops the sing-box core");
    assert_pid_gone(pid_b);
}

// ---- Round 125 (ADR-060): cross-process core adoption, library face ----
//
// Plus one scheduling fact this round made structural: each adoption judge spawns a REAL
// core (gunzip of an ~85MB asset + controller probes) while two sibling judges below fetch
// http://example.com THROUGH their cores under 3s request deadlines. On this 2-CPU host the
// spawn storms blew those deadlines — the §4.195 flake family, amplified from "rare" to
// "one outbound judge per run" until the two classes were mutually excluded. The turnstile
// serializes ONLY these two classes; every other test keeps running in parallel.

/// The mutual exclusion described above: outbound-through-core judges and adoption judges
/// take it for their whole body.
static REAL_CORE_TURNSTILE: std::sync::Mutex<()> = std::sync::Mutex::new(());

fn heavy_turnstile() -> std::sync::MutexGuard<'static, ()> {
    REAL_CORE_TURNSTILE
        .lock()
        .unwrap_or_else(|poisoned| poisoned.into_inner())
}
//
// The crash half of supervision: the daemon DIES, the deployed core lives. These judges run
// the adoption door on a SECOND runtime over the same root/store (the restarted daemon's
// stand-in), covering the four outcomes of `ADR-060 §2.3`. The both-binaries flagship e2e
// (kill -9 → adopt → stop with the second daemon) lives in `caly_cli_e2e.rs`.

/// A test stand-in for the production pidfd stopper: the same contract — re-verify pid +
/// start_time, then TERM, bounded grace, KILL — built on `/bin/kill`, which is test
/// infrastructure here exactly as in the e2e harnesses. The production FFI path is judged by
/// the e2e through the real `calyd` binary.
fn test_foreign_stopper() -> caly_daemon::effect_std::ForeignStopper {
    Arc::new(|pid: u32, start_time: &str, grace_ms: u64| {
        let stat = std::fs::read_to_string(format!("/proc/{pid}/stat"))
            .map_err(|error| format!("read /proc/{pid}/stat: {error}"))?;
        let observed = stat
            .rsplit_once(')')
            .and_then(|(_, after)| after.split_whitespace().nth(19))
            .ok_or("the stat line is short")?;
        if observed != start_time {
            return Err(format!(
                "pid {pid} start_time {observed} is not the receipt's {start_time}; \
                 refusing to signal"
            ));
        }
        // Zombie-aware: the core stays a child of THIS test process (in-process runtime),
        // so an externally killed core lingers as a zombie until the port-side stop reaps
        // it — a zombie has exited, and "alive" must say so.
        let alive = || {
            std::fs::read_to_string(format!("/proc/{pid}/stat"))
                .ok()
                .and_then(|stat| {
                    stat.rsplit_once(')').and_then(|(_, after)| {
                        after.split_whitespace().next().map(|state| state != "Z")
                    })
                })
                .unwrap_or(false)
        };
        if !alive() {
            return Ok(caly_daemon::effect_std::ForeignStopOutcome::AlreadyGone);
        }
        let _ = std::process::Command::new("/bin/kill")
            .arg("-TERM")
            .arg(pid.to_string())
            .status();
        let deadline =
            std::time::Instant::now() + std::time::Duration::from_millis(grace_ms.max(300));
        while alive() && std::time::Instant::now() < deadline {
            std::thread::sleep(Duration::from_millis(20));
        }
        let mut killed = false;
        if alive() {
            killed = true;
            let _ = std::process::Command::new("/bin/kill")
                .arg("-KILL")
                .arg(pid.to_string())
                .status();
            let kill_deadline = std::time::Instant::now() + Duration::from_secs(3);
            while alive() && std::time::Instant::now() < kill_deadline {
                std::thread::sleep(Duration::from_millis(20));
            }
        }
        if !alive() {
            Ok(if killed {
                caly_daemon::effect_std::ForeignStopOutcome::KilledAfterGrace
            } else {
                caly_daemon::effect_std::ForeignStopOutcome::StoppedWithinGrace
            })
        } else {
            Err(format!("pid {pid} survived SIGKILL"))
        }
    })
}

/// The durable receipt under a runtime root, as text (the operator-readable shape).
fn receipt_text(root: &str) -> String {
    std::fs::read_to_string(format!("{root}/core-receipt")).expect("the spawn wrote a receipt")
}

fn receipt_field(root: &str, key: &str) -> String {
    receipt_text(root)
        .lines()
        .find_map(|line| line.strip_prefix(&format!("{key}=")))
        .unwrap_or_else(|| panic!("receipt field {key}"))
        .to_owned()
}

/// The restarted daemon's stand-in: a FRESH runtime over the same root and store, with the
/// test stopper the real composition root would inject.
fn restarted_runtime(app: &DaemonApp, root: &str) -> Arc<StdEffectRuntime> {
    Arc::new(
        StdEffectRuntime::new(root, app.engine_storage(), CoreAssets::workspace_default())
            .with_foreign_stopper(test_foreign_stopper()),
    )
}

/// Stops the core through the FIRST runtime on the way out of a test — it is that runtime's
/// CHILD, so the plain port stop works even when every other assertion has already failed.
struct CoreLease {
    runtime: Arc<StdEffectRuntime>,
}

impl Drop for CoreLease {
    fn drop(&mut self) {
        let _ = self.runtime.shutdown(3_000);
    }
}

#[test]
fn adoption_rebuilds_a_live_core_across_runtime_death_and_stops_it() {
    let _heavy = heavy_turnstile();
    let (app, effects, guard) = real_app("adopt-live");
    let (job, state) = apply_once(&app, "nightshift-direct", 801);
    assert_eq!(
        state,
        "completed",
        "the deployment must succeed first: {:?}",
        summary_of(&app, job)
    );
    let _lease = CoreLease {
        runtime: effects.clone(),
    };
    let pid = effects.live_pid().expect("the core is live under daemon A");
    let nonce = receipt_field(&guard.path, "nonce");
    let controller_port: u16 = receipt_field(&guard.path, "controller_port")
        .parse()
        .expect("controller port");
    let mixed_port: u16 = receipt_field(&guard.path, "mixed_port")
        .parse()
        .expect("mixed port");

    // "Daemon death": a fresh runtime that never spawned anything, over the same root.
    let restarted = restarted_runtime(&app, &guard.path);
    let outcome = restarted.adopt_on_start().expect("the adoption door runs");
    match &outcome {
        caly_daemon::effect_std::AdoptionOutcome::Adopted {
            pid: adopted_pid,
            nonce: adopted_nonce,
            core_kind,
            controller_port: adopted_controller,
            mixed_port: adopted_mixed,
        } => {
            assert_eq!(*adopted_pid, pid, "the SAME core, not a respawn");
            assert_eq!(adopted_nonce, &nonce);
            assert_eq!(*adopted_controller, controller_port);
            assert_eq!(*adopted_mixed, mixed_port);
            assert!(matches!(core_kind, caly_engine::CoreKind::Mihomo));
        }
        other => panic!("a live, identity-matched core must be adopted: {other:?}"),
    }
    assert_eq!(restarted.live_pid(), Some(pid));
    assert!(
        restarted.controller_ready(),
        "the adopted core's controller answers through the rebuilt live slot"
    );

    // The stop must travel through the FOREIGN path (no child exists for this runtime).
    let exit = restarted
        .shutdown(3_000)
        .expect("the foreign core stops with the restarted daemon");
    assert!(exit.signaled, "a foreign stop reports the escalation fact");
    // The core EXITED; as a child of this test process it now awaits its reap. The first
    // runtime's port-side stop is that reap (in the real flow the orphan belongs to init,
    // which reaps it; here only the in-process parent can).
    let _ = effects.shutdown(3_000);
    assert_pid_gone(pid);
    assert!(
        !Path::new(&format!("{}/core-receipt", guard.path)).exists(),
        "a confirmed stop clears the receipt — the next start must cold start"
    );
}

#[test]
fn adoption_refuses_a_dead_core_and_clears_the_receipt() {
    let _heavy = heavy_turnstile();
    let (app, effects, guard) = real_app("adopt-dead");
    let (job, state) = apply_once(&app, "nightshift-direct", 802);
    assert_eq!(state, "completed", "{:?}", summary_of(&app, job));
    let _lease = CoreLease {
        runtime: effects.clone(),
    };
    let pid = effects.live_pid().expect("live core");

    // The core dies before any restart can happen (operator kill, OOM, ...).
    let _ = std::process::Command::new("/bin/kill")
        .arg("-KILL")
        .arg(pid.to_string())
        .status();
    // Zombie-aware wait (see the stopper above): the corpse keeps its /proc entry until the
    // port-side reap in the lease's drop; what matters for adoption is that it EXITED.
    let exited = || {
        std::fs::read_to_string(format!("/proc/{pid}/stat"))
            .ok()
            .and_then(|stat| {
                stat.rsplit_once(')').and_then(|(_, after)| {
                    after.split_whitespace().next().map(|state| state == "Z")
                })
            })
            .unwrap_or(true)
    };
    let deadline = std::time::Instant::now() + Duration::from_secs(5);
    while !exited() && std::time::Instant::now() < deadline {
        std::thread::sleep(Duration::from_millis(20));
    }
    assert!(exited(), "the core must have exited after SIGKILL");

    let restarted = restarted_runtime(&app, &guard.path);
    let outcome = restarted.adopt_on_start().expect("the adoption door runs");
    assert_eq!(
        outcome,
        caly_daemon::effect_std::AdoptionOutcome::CoreGone { pid },
        "a dead core is CoreGone, never a phantom adoption"
    );
    assert_eq!(restarted.live_pid(), None);
    assert!(
        !Path::new(&format!("{}/core-receipt", guard.path)).exists(),
        "the receipt is cleared — adopting a corpse next start is the dangling state"
    );
}

#[test]
fn adoption_refuses_a_recycled_pid_and_never_signals_the_process() {
    let _heavy = heavy_turnstile();
    let (app, effects, guard) = real_app("adopt-recycled");
    let (job, state) = apply_once(&app, "nightshift-direct", 803);
    assert_eq!(state, "completed", "{:?}", summary_of(&app, job));
    let _lease = CoreLease {
        runtime: effects.clone(),
    };
    let pid = effects.live_pid().expect("live core");
    let real_start_time = receipt_field(&guard.path, "start_time");
    let tampered_value: String = format!(
        "start_time={}",
        real_start_time.parse::<u64>().expect("ticks") + 1
    );
    let tampered_text = receipt_text(&guard.path)
        .replace(&format!("start_time={real_start_time}"), &tampered_value);
    std::fs::write(format!("{}/core-receipt", guard.path), tampered_text)
        .expect("tamper the receipt (a recycled-pid receipt is indistinguishable from this)");

    let restarted = restarted_runtime(&app, &guard.path);
    let outcome = restarted.adopt_on_start().expect("the adoption door runs");
    match outcome {
        caly_daemon::effect_std::AdoptionOutcome::IdentityMismatch {
            pid: refused_pid,
            recorded_start_time,
            observed_start_time,
        } => {
            assert_eq!(refused_pid, pid);
            assert_eq!(
                recorded_start_time,
                tampered_value.replace("start_time=", "")
            );
            assert_eq!(observed_start_time, Some(real_start_time));
        }
        other => panic!("a start_time mismatch is a refusal, not {other:?}"),
    }
    let still_running = || {
        std::fs::read_to_string(format!("/proc/{pid}/stat"))
            .ok()
            .and_then(|stat| {
                stat.rsplit_once(')').and_then(|(_, after)| {
                    after.split_whitespace().next().map(|state| state != "Z")
                })
            })
            .unwrap_or(false)
    };
    assert!(
        still_running(),
        "the STILL-RUNNING process is never signalled on a mismatch — the pid's current \
         owner is not ours to kill"
    );
    assert_eq!(restarted.live_pid(), None, "nothing was adopted");
    assert!(
        !Path::new(&format!("{}/core-receipt", guard.path)).exists(),
        "a receipt that can never verify again is cleared"
    );
}

#[test]
fn adoption_refuses_a_silent_controller_and_keeps_the_receipt() {
    let _heavy = heavy_turnstile();
    let (app, effects, guard) = real_app("adopt-silent-controller");
    let (job, state) = apply_once(&app, "nightshift-direct", 804);
    assert_eq!(state, "completed", "{:?}", summary_of(&app, job));
    let _lease = CoreLease {
        runtime: effects.clone(),
    };
    let pid = effects.live_pid().expect("live core");

    // A port that is provably closed: bind :0, read the port, let go of the listener.
    let dead_port = {
        let probe = std::net::TcpListener::bind("127.0.0.1:0").expect("probe bind");
        let port = probe.local_addr().expect("addr").port();
        drop(probe);
        port
    };
    let tampered_text = receipt_text(&guard.path).replace(
        &format!(
            "controller_port={}",
            receipt_field(&guard.path, "controller_port")
        ),
        &format!("controller_port={dead_port}"),
    );
    std::fs::write(format!("{}/core-receipt", guard.path), tampered_text)
        .expect("point the receipt at a silent controller");

    let restarted = restarted_runtime(&app, &guard.path);
    let outcome = restarted.adopt_on_start().expect("the adoption door runs");
    match outcome {
        caly_daemon::effect_std::AdoptionOutcome::Refused {
            pid: refused_pid,
            reason,
        } => {
            assert_eq!(refused_pid, pid);
            assert!(
                reason.contains("controller"),
                "the refusal names the silent controller: {reason}"
            );
        }
        other => panic!("a silent controller is a named refusal, not {other:?}"),
    }
    assert_eq!(restarted.live_pid(), None, "nothing was adopted");
    assert!(
        !restarted.controller_ready(),
        "the ActiveCore route stays closed for a core that cannot answer"
    );
    assert!(
        Path::new(&format!("{}/core-receipt", guard.path)).exists(),
        "the identity facts are still true — the receipt is KEPT so every start re-reports"
    );
}
