//! A daemon that recovers its state from disk.
//!
//! Until now `DaemonApp` could only "recover" inside one process, and a failed startup recovery
//! scan was discarded with `let _ = ...`: a daemon that could not reconstruct its state came up
//! looking healthy. These tests attach the daemon to `FsStore` over a real directory and assert
//! both directions — a committed deployment is rediscovered after a restart, and a store whose
//! recovery scan fails refuses to start.

use std::path::Path;
use std::sync::atomic::{AtomicU64, Ordering};
use std::sync::Arc;

use caly_api::{
    ApplyRequest, Operation, ProfileId, ProfileOp, ProtocolVersion, RequestEnvelope, RequestId,
    Role, TraceId,
};
use caly_common::Actor;
use caly_daemon::{DaemonApp, DaemonBootstrapConfig, DaemonLifecycle};
use caly_io::{BoxFuture, Fs};
use caly_io_std::StdFs;
use caly_storage::fs_store::FsStore;
use caly_storage::{
    ApplyJournalRecord, ApplyJournalStore, ApplyTxnId, CasObjectRef, CasWriteIntent,
    InMemoryStorage, JournalRecord, JournalRecordId, JournalStore, MaterializationRequest,
    ObjectStore, RevisionId, RevisionRecord, RevisionStore, SnapshotRecord, SnapshotRecordId,
    SnapshotStore, StorageBackend, StorageError, StorageErrorKind,
};

static SEQ: AtomicU64 = AtomicU64::new(0);

fn scratch(tag: &str) -> (String, String) {
    let nth = SEQ.fetch_add(1, Ordering::SeqCst);
    let name = format!("caly-daemon-{tag}-{nth}-{}", std::process::id());
    let dir = std::env::temp_dir().join(name);
    std::fs::create_dir_all(&dir).expect("scratch dir must be creatable");
    (
        dir.to_string_lossy().into_owned(),
        format!("caly-daemon-{tag}-{nth}"),
    )
}

fn config(instance: &str, recover: bool) -> DaemonBootstrapConfig {
    DaemonBootstrapConfig {
        instance_id: instance.to_owned(),
        protocol_version: ProtocolVersion { major: 1, minor: 0 },
        recover_on_start: recover,
    }
}

fn durable(root: &str) -> Arc<dyn StorageBackend> {
    let store = FsStore::open(
        Box::new(StdFs::new(root.to_owned())) as Box<dyn Fs>,
        "var/caly",
    )
    .expect("a fresh or existing store root must open");
    Arc::new(store)
}

fn apply_envelope(profile_id: &str) -> RequestEnvelope {
    RequestEnvelope {
        protocol: ProtocolVersion { major: 1, minor: 0 },
        request_id: RequestId(1),
        trace_id: TraceId::new("durable-boot"),
        deadline_ms: None,
        expected_revision: None,
        // `profile.apply` declares `Idempotency::Required`, so a keyless submission is refused rather
        // than guessed at; this fixture wants a write that runs.
        idempotency_key: Some("durable-boot-apply".to_owned()),
        role: Role::Admin,
        io_budget: None,
        operation: Operation::Profile(ProfileOp::Apply {
            request: ApplyRequest {
                profile_id: ProfileId(profile_id.to_owned()),
                dry_run: false,
                strict: false,
            },
        }),
    }
}

#[test]
fn a_restarted_daemon_rediscovers_the_committed_deployment() {
    let (root, tag) = scratch("ok");
    let snapshot_id = {
        let daemon = DaemonApp::try_bootstrap(config(&tag, true), durable(&root)).expect("boot");
        daemon.set_running().expect("running");
        daemon
            .submit_request_as_command(Actor::Cli, &apply_envelope("demo-tun-profile"))
            .expect("accepted");
        assert_eq!(daemon.drain_engine_once().expect("drain"), 1);
        let snapshot = daemon
            .latest_last_known_good_snapshot()
            .expect("lkg read")
            .expect("a committed apply must leave a snapshot");
        snapshot.id.0.clone()
    };

    // A new daemon, a new store handle, the same directory.
    let reopened = DaemonApp::try_bootstrap(config(&tag, true), durable(&root)).expect("reboot");
    let runtime = reopened.runtime_snapshot().expect("runtime");
    assert_eq!(
        runtime.active_profile,
        Some(ProfileId("demo-tun-profile".to_owned())),
        "the active profile must come from the durable snapshot, not from memory"
    );
    assert_eq!(
        runtime.active_snapshot.as_deref(),
        Some(snapshot_id.as_str())
    );
    assert_eq!(runtime.last_apply_plan_summary.as_deref(), Some("Restart"));
    assert_eq!(runtime.pending_recovery_decisions, 0);
    assert_eq!(
        runtime.last_recovery_summary.as_deref(),
        Some("recovery scan clean"),
        "a clean scan must say so instead of staying silent"
    );
    assert_eq!(runtime.lifecycle, DaemonLifecycle::Starting);
    std::fs::remove_dir_all(&root).ok();
}

/// A transaction left mid-cutover must survive repeated restarts until someone resolves it.
#[test]
fn a_daemon_that_crashed_mid_cutover_comes_up_recovering() {
    let (root, tag) = scratch("crash");
    {
        let daemon = DaemonApp::try_bootstrap(config(&tag, false), durable(&root)).expect("boot");
        let report = daemon
            .seed_recovery_fixture("demo-crash-profile")
            .expect("seed");
        assert_eq!(report.unresolved_apply_journals.len(), 1);
    }

    let daemon = DaemonApp::try_bootstrap(config(&tag, true), durable(&root)).expect("reboot");
    let runtime = daemon.runtime_snapshot().expect("runtime");
    assert_eq!(runtime.lifecycle, DaemonLifecycle::Recovering);
    assert_eq!(runtime.pending_recovery_decisions, 1);
    assert!(runtime
        .last_recovery_summary
        .as_deref()
        .unwrap_or_default()
        .contains("recovery decisions=1"));

    drop(daemon);
    let again =
        DaemonApp::try_bootstrap(config(&tag, true), durable(&root)).expect("second reboot");
    let runtime = again.runtime_snapshot().expect("runtime");
    assert_eq!(
        runtime.pending_recovery_decisions, 1,
        "nothing resolved the transaction, so it must still be reported"
    );
    assert_eq!(
        again
            .durable_scan()
            .expect("scan")
            .unresolved_apply_journals
            .len(),
        1
    );
    std::fs::remove_dir_all(&root).ok();
}

/// Damage to a CAS object must be caught by the store, and the daemon must not start on top of it.
#[test]
fn a_torn_object_on_disk_prevents_the_daemon_from_starting() {
    let (root, tag) = scratch("torn");
    {
        let daemon = DaemonApp::try_bootstrap(config(&tag, true), durable(&root)).expect("boot");
        daemon
            .submit_request_as_command(Actor::Cli, &apply_envelope("demo-tun-profile"))
            .expect("accepted");
        daemon.drain_engine_once().expect("drain");
    }

    // Overwrite the CAS content file, leaving the metadata record intact beside it. The path is read
    // back out of the on-disk records rather than recomputed by guesswork -- which, since
    // `ADR-035 §2.3`, means listing the metadata directory: the same thing the store does.
    let store_dir = Path::new(&root).join("var/caly");
    let meta_rel = std::fs::read_dir(store_dir.join("meta/objects"))
        .expect("object metadata directory")
        .filter_map(|entry| entry.ok())
        .map(|entry| format!("meta/objects/{}", entry.file_name().to_string_lossy()))
        .next()
        .expect("at least one object record");
    let meta_text = std::fs::read_to_string(store_dir.join(meta_rel)).expect("object metadata");
    let anchor = meta_text
        .lines()
        .find_map(|line| line.strip_prefix("content_sha256="))
        .expect("metadata carries the integrity anchor")
        .to_owned();
    let content = store_dir.join(caly_storage::fs_store::content_suffix_for(&anchor));
    std::fs::write(&content, b"torn-by-a-bad-write").expect("damage");

    // The store itself refuses...
    let store = FsStore::open(
        Box::new(StdFs::new(root.clone())) as Box<dyn Fs>,
        "var/caly",
    );
    assert!(
        store.is_err(),
        "a store whose object no longer matches its digest must refuse to open"
    );

    // ...and a daemon built on a backend that cannot answer the recovery scan refuses to start,
    // rather than starting with an empty view of a dirty disk.
    let failure =
        match DaemonApp::try_bootstrap(config(&tag, true), Arc::new(UnreadableStore::default())) {
            Ok(_) => panic!("an unreadable store must block startup, not yield a blank daemon"),
            Err(failure) => failure,
        };
    assert!(failure.store_unusable, "{failure:?}");
    assert!(
        failure.summary.contains("startup recovery failed"),
        "{}",
        failure.summary
    );
    std::fs::remove_dir_all(&root).ok();
}

/// The infallible entry point keeps its contract: it never panics, and an in-memory daemon starts
/// with no recorded failure.
#[test]
fn bootstrap_stays_infallible_and_starts_without_a_recorded_failure() {
    let (_root, tag) = scratch("memory");
    let daemon = DaemonApp::bootstrap(config(&tag, true));
    let runtime = daemon.runtime_snapshot().expect("runtime");
    assert_eq!(runtime.lifecycle, DaemonLifecycle::Starting);
    assert_eq!(runtime.last_error, None);
    assert_eq!(runtime.pending_recovery_decisions, 0);
}

/// A backend whose recovery inputs cannot be read: models "the store is there but unreadable",
/// which is the case the daemon must refuse to start through.
#[derive(Default)]
struct UnreadableStore {
    inner: InMemoryStorage,
}

impl StorageBackend for UnreadableStore {}

impl ObjectStore for UnreadableStore {
    fn put(&self, intent: CasWriteIntent) -> BoxFuture<'_, Result<CasObjectRef, StorageError>> {
        self.inner.put(intent)
    }
    fn get<'a>(
        &'a self,
        digest: &'a str,
    ) -> BoxFuture<'a, Result<Option<CasObjectRef>, StorageError>> {
        self.inner.get(digest)
    }
    fn materialize(
        &self,
        request: MaterializationRequest,
    ) -> BoxFuture<'_, Result<(), StorageError>> {
        self.inner.materialize(request)
    }
    fn list_objects(&self) -> BoxFuture<'_, Result<Vec<CasObjectRef>, StorageError>> {
        self.inner.list_objects()
    }
    fn delete<'a>(&'a self, digest: &'a str) -> BoxFuture<'a, Result<bool, StorageError>> {
        self.inner.delete(digest)
    }
}

impl RevisionStore for UnreadableStore {
    fn put_revision(&self, record: RevisionRecord) -> BoxFuture<'_, Result<(), StorageError>> {
        self.inner.put_revision(record)
    }
    fn get_revision<'a>(
        &'a self,
        revision_id: &'a RevisionId,
    ) -> BoxFuture<'a, Result<Option<RevisionRecord>, StorageError>> {
        self.inner.get_revision(revision_id)
    }
}

impl SnapshotStore for UnreadableStore {
    fn put_snapshot(&self, record: SnapshotRecord) -> BoxFuture<'_, Result<(), StorageError>> {
        self.inner.put_snapshot(record)
    }
    fn get_snapshot<'a>(
        &'a self,
        snapshot_id: &'a SnapshotRecordId,
    ) -> BoxFuture<'a, Result<Option<SnapshotRecord>, StorageError>> {
        self.inner.get_snapshot(snapshot_id)
    }
    fn latest_last_known_good<'a>(
        &'a self,
    ) -> BoxFuture<'a, Result<Option<SnapshotRecord>, StorageError>> {
        self.inner.latest_last_known_good()
    }
}

impl JournalStore for UnreadableStore {
    fn put_journal(&self, record: JournalRecord) -> BoxFuture<'_, Result<(), StorageError>> {
        self.inner.put_journal(record)
    }
    fn get_journal<'a>(
        &'a self,
        journal_id: &'a JournalRecordId,
    ) -> BoxFuture<'a, Result<Option<JournalRecord>, StorageError>> {
        self.inner.get_journal(journal_id)
    }
    fn list_pending(&self) -> BoxFuture<'_, Result<Vec<JournalRecord>, StorageError>> {
        self.inner.list_pending()
    }
}

impl ApplyJournalStore for UnreadableStore {
    fn put_apply_journal(
        &self,
        record: ApplyJournalRecord,
    ) -> BoxFuture<'_, Result<(), StorageError>> {
        self.inner.put_apply_journal(record)
    }
    fn get_apply_journal<'a>(
        &'a self,
        apply_txn_id: &'a ApplyTxnId,
    ) -> BoxFuture<'a, Result<Option<ApplyJournalRecord>, StorageError>> {
        self.inner.get_apply_journal(apply_txn_id)
    }
    fn list_pending_apply(&self) -> BoxFuture<'_, Result<Vec<ApplyJournalRecord>, StorageError>> {
        self.inner.list_pending_apply()
    }
    /// The point of this fixture: the scan cannot be answered.
    fn list_unresolved_apply(
        &self,
    ) -> BoxFuture<'_, Result<Vec<ApplyJournalRecord>, StorageError>> {
        Box::pin(async move {
            Err(StorageError::new(
                StorageErrorKind::IntegrityViolation,
                "apply journal enumeration is unreadable (injected)",
            ))
        })
    }
}

/// `Recovering` must gate new deployments, but never the escape hatch or the diagnostics.
#[test]
fn a_recovering_daemon_refuses_apply_and_still_answers_status_and_rollback() {
    let (root, tag) = scratch("gate");
    let daemon = DaemonApp::try_bootstrap(config(&tag, false), durable(&root)).expect("boot");
    daemon
        .seed_recovery_fixture("demo-crash-profile")
        .expect("seed a mid-cutover transaction");
    let runtime = daemon.runtime_snapshot().expect("runtime");
    assert_eq!(runtime.lifecycle, DaemonLifecycle::Recovering);

    let error = daemon
        .submit_request_as_command(Actor::Cli, &apply_envelope("demo-tun-profile"))
        .expect_err("an apply must not be accepted over an unresolved transaction");
    assert_eq!(error.code, caly_api::ErrorCode::Conflict);
    assert_eq!(error.category, caly_api::ErrorCategory::Platform);
    assert!(
        error.retryable,
        "it becomes acceptable once recovery is resolved"
    );
    assert!(
        error.summary.contains("Recovering"),
        "the message must name the state: {}",
        error.summary
    );
    assert!(
        error
            .remediation
            .as_deref()
            .unwrap_or_default()
            .contains("roll back to the last-known-good"),
        "{:?}",
        error.remediation
    );

    // Queries still work: that is how an operator finds out what to roll back to.
    let status = caly_daemon::query::handle_query(
        &daemon,
        &caly_api::RequestEnvelope {
            request_id: RequestId(2),
            trace_id: TraceId::new("status-during-recovery"),
            role: Role::Operator,
            io_budget: None,
            operation: caly_api::Operation::System(caly_api::SystemOp::Status),
            ..envelope_base()
        },
    )
    .expect("status must stay answerable while recovering")
    .expect("status is a supported query");
    let daemon_state = match status {
        caly_api::OperationResult::SystemStatus(view) => view.daemon_state,
        other => panic!("unexpected status result: {other:?}"),
    };
    // `daemon_state` is the lowercased lifecycle, per `query/system.rs`.
    assert_eq!(daemon_state, "recovering", "{daemon_state}");

    // And the way out is not blocked by the gate.
    let rollback = RequestEnvelope {
        request_id: RequestId(3),
        trace_id: TraceId::new("rollback-during-recovery"),
        // Keyed, so the assertion below is about the lifecycle gate and not about `ADR-037`'s
        // missing-key refusal (which is checked first, on purpose: the caller's own malformed request
        // is the actionable finding).
        idempotency_key: Some("rollback-during-recovery".to_owned()),
        role: Role::Admin,
        io_budget: None,
        operation: Operation::Profile(ProfileOp::Rollback {
            request: caly_api::RollbackRequest { snapshot_id: None },
        }),
        ..envelope_base()
    };
    assert!(
        daemon
            .submit_request_as_command(Actor::Cli, &rollback)
            .expect("rollback must remain available")
            .is_some(),
        "blocking rollback would deadlock the only way out of recovery"
    );
    std::fs::remove_dir_all(&root).ok();
}

/// A backend whose LKG marker and record read disagree must produce a `Failed` daemon, and
/// `Failed` gates every command (queries excepted).
#[test]
fn a_disagreeing_backend_yields_a_failed_daemon_that_refuses_all_commands() {
    let (_root, tag) = scratch("disagree");
    let daemon =
        DaemonApp::try_bootstrap(config(&tag, true), Arc::new(InconsistentStore::default()))
            .expect("a scan that succeeds must still start the daemon");
    let runtime = daemon.runtime_snapshot().expect("runtime");
    assert_eq!(
        runtime.lifecycle,
        DaemonLifecycle::Failed,
        "the marker named a snapshot the store cannot return"
    );
    assert!(runtime
        .last_error
        .as_deref()
        .unwrap_or_default()
        .contains("is not readable"));
    assert_eq!(runtime.active_profile, None);

    let error = daemon
        .submit_request_as_command(Actor::Cli, &apply_envelope("demo-tun-profile"))
        .expect_err("a Failed daemon must not accept any command");
    assert!(error.summary.contains("Failed"), "{}", error.summary);
    let rollback_error = daemon
        .submit_request_as_command(
            Actor::Cli,
            &RequestEnvelope {
                request_id: RequestId(9),
                trace_id: TraceId::new("rollback-while-failed"),
                idempotency_key: Some("rollback-while-failed".to_owned()),
                role: Role::Admin,
                io_budget: None,
                operation: Operation::Profile(ProfileOp::Rollback {
                    request: caly_api::RollbackRequest { snapshot_id: None },
                }),
                ..envelope_base()
            },
        )
        .expect_err("unlike Recovering, Failed blocks rollback too");
    assert!(
        rollback_error.summary.contains("Failed"),
        "{}",
        rollback_error.summary
    );
}

fn envelope_base() -> RequestEnvelope {
    RequestEnvelope {
        protocol: ProtocolVersion { major: 1, minor: 0 },
        request_id: RequestId(0),
        trace_id: TraceId::new("base"),
        deadline_ms: None,
        expected_revision: None,
        idempotency_key: None,
        role: Role::Admin,
        io_budget: None,
        operation: Operation::System(caly_api::SystemOp::Status),
    }
}

/// Reports a last-known-good snapshot, then cannot return it by id.
#[derive(Default)]
struct InconsistentStore {
    inner: InMemoryStorage,
}

impl StorageBackend for InconsistentStore {}

impl ObjectStore for InconsistentStore {
    fn put(&self, intent: CasWriteIntent) -> BoxFuture<'_, Result<CasObjectRef, StorageError>> {
        self.inner.put(intent)
    }
    fn get<'a>(
        &'a self,
        digest: &'a str,
    ) -> BoxFuture<'a, Result<Option<CasObjectRef>, StorageError>> {
        self.inner.get(digest)
    }
    fn materialize(
        &self,
        request: MaterializationRequest,
    ) -> BoxFuture<'_, Result<(), StorageError>> {
        self.inner.materialize(request)
    }
    fn list_objects(&self) -> BoxFuture<'_, Result<Vec<CasObjectRef>, StorageError>> {
        self.inner.list_objects()
    }
    fn delete<'a>(&'a self, digest: &'a str) -> BoxFuture<'a, Result<bool, StorageError>> {
        self.inner.delete(digest)
    }
}

impl RevisionStore for InconsistentStore {
    fn put_revision(&self, record: RevisionRecord) -> BoxFuture<'_, Result<(), StorageError>> {
        self.inner.put_revision(record)
    }
    fn get_revision<'a>(
        &'a self,
        revision_id: &'a RevisionId,
    ) -> BoxFuture<'a, Result<Option<RevisionRecord>, StorageError>> {
        self.inner.get_revision(revision_id)
    }
}

impl SnapshotStore for InconsistentStore {
    fn put_snapshot(&self, record: SnapshotRecord) -> BoxFuture<'_, Result<(), StorageError>> {
        self.inner.put_snapshot(record)
    }
    /// The disagreement: the id is known, the record is not.
    fn get_snapshot<'a>(
        &'a self,
        _snapshot_id: &'a SnapshotRecordId,
    ) -> BoxFuture<'a, Result<Option<SnapshotRecord>, StorageError>> {
        Box::pin(async move { Ok(None) })
    }
    fn latest_last_known_good<'a>(
        &'a self,
    ) -> BoxFuture<'a, Result<Option<SnapshotRecord>, StorageError>> {
        Box::pin(async move {
            Ok(Some(SnapshotRecord {
                id: SnapshotRecordId("snapshot:ghost".to_owned()),
                revision_id: RevisionId("rev-ghost".to_owned()),
                revision_number: caly_storage::RevisionNumber(1),
                profile_id: "demo-tun-profile".to_owned(),
                semantic_digest: "sem:ghost".to_owned(),
                compiled_artifact_digest: "mihomo:ghost".to_owned(),
                core_binary_digest: "bin".to_owned(),
                core_identity: "mihomo@0.1".to_owned(),
                apply_plan_summary: "Restart".to_owned(),
                journal_id: None,
                selection_memory_digest: None,
                validation_summary: "ok".to_owned(),
                created_at_unix_ms: 1,
                is_last_known_good: true,
            }))
        })
    }
}

impl JournalStore for InconsistentStore {
    fn put_journal(&self, record: JournalRecord) -> BoxFuture<'_, Result<(), StorageError>> {
        self.inner.put_journal(record)
    }
    fn get_journal<'a>(
        &'a self,
        journal_id: &'a JournalRecordId,
    ) -> BoxFuture<'a, Result<Option<JournalRecord>, StorageError>> {
        self.inner.get_journal(journal_id)
    }
    fn list_pending(&self) -> BoxFuture<'_, Result<Vec<JournalRecord>, StorageError>> {
        self.inner.list_pending()
    }
}

impl ApplyJournalStore for InconsistentStore {
    fn put_apply_journal(
        &self,
        record: ApplyJournalRecord,
    ) -> BoxFuture<'_, Result<(), StorageError>> {
        self.inner.put_apply_journal(record)
    }
    fn get_apply_journal<'a>(
        &'a self,
        apply_txn_id: &'a ApplyTxnId,
    ) -> BoxFuture<'a, Result<Option<ApplyJournalRecord>, StorageError>> {
        self.inner.get_apply_journal(apply_txn_id)
    }
    fn list_pending_apply(&self) -> BoxFuture<'_, Result<Vec<ApplyJournalRecord>, StorageError>> {
        self.inner.list_pending_apply()
    }
    fn list_unresolved_apply(
        &self,
    ) -> BoxFuture<'_, Result<Vec<ApplyJournalRecord>, StorageError>> {
        Box::pin(async move { Ok(Vec::new()) })
    }
}

/// `STORAGE_RECOVERY_EXECUTION_PLAN.md §9.2` promises `doctor` can report four storage findings.
/// These exercise three of them end to end, through the query path the CLI/TUI would use.
fn doctor(daemon: &DaemonApp) -> caly_api::DoctorReport {
    let envelope = RequestEnvelope {
        request_id: RequestId(77),
        trace_id: TraceId::new("doctor"),
        ..envelope_base()
    };
    let envelope = RequestEnvelope {
        operation: Operation::Diagnostics(caly_api::DiagnosticsOp::Doctor {
            request: caly_api::DoctorRequest {
                include_runtime: true,
            },
        }),
        ..envelope
    };
    match caly_daemon::query::handle_query(daemon, &envelope).expect("doctor query must not error")
    {
        Some(caly_api::OperationResult::DoctorReport(report)) => report,
        other => panic!("unexpected doctor result: {other:?}"),
    }
}

#[test]
fn the_doctor_reports_storage_findings_instead_of_a_placeholder() {
    let (root, tag) = scratch("doctor");
    let daemon = DaemonApp::try_bootstrap(config(&tag, true), durable(&root)).expect("boot");

    // A healthy durable store must say so with empty warnings and empty errors. The old
    // implementation pushed a fixed "diagnostics pipeline is still partial" warning on every call,
    // which made an empty report impossible and a real finding indistinguishable.
    let healthy = doctor(&daemon);
    assert!(
        healthy.summary.contains("storage audit: schema=v1"),
        "the report must be wired to the store: {}",
        healthy.summary
    );
    assert!(healthy.warnings.is_empty(), "{:?}", healthy.warnings);
    assert!(healthy.errors.is_empty(), "{:?}", healthy.errors);
    assert!(
        healthy
            .notes
            .iter()
            .any(|note| note.contains("no findings requiring action")),
        "{:?}",
        healthy.notes
    );
    assert!(
        !healthy
            .warnings
            .iter()
            .any(|line| line.contains("still partial")),
        "the placeholder must be gone"
    );

    // Deploy, then check the audit follows the store forward.
    daemon
        .submit_request_as_command(Actor::Cli, &apply_envelope("demo-tun-profile"))
        .expect("accepted");
    daemon.drain_engine_once().expect("drain");
    let after = doctor(&daemon);
    assert!(after.summary.contains("snapshots=1"), "{}", after.summary);
    assert!(after.summary.contains("objects=1"), "{}", after.summary);
    assert!(
        after.warnings.is_empty() && after.errors.is_empty(),
        "{after:?}"
    );
    std::fs::remove_dir_all(&root).ok();
}

#[test]
fn the_doctor_flags_a_snapshot_whose_object_is_gone() {
    let (root, tag) = scratch("doctor-mismatch");
    {
        // Write a snapshot that references an artifact the object store never held.
        let store = FsStore::open(
            Box::new(StdFs::new(root.clone())) as Box<dyn Fs>,
            "var/caly",
        )
        .expect("open");
        caly_io::block_on_ready(
            store.put_snapshot(snapshot_record("snapshot:ghost", "mihomo:never-written")),
        )
        .expect("ready")
        .expect("commit");
    }

    let daemon = DaemonApp::try_bootstrap(config(&tag, true), durable(&root)).expect("boot");
    let report = doctor(&daemon);
    assert!(
        report
            .errors
            .iter()
            .any(|line| line.contains("snapshot-object-mismatch [error] snapshot:ghost")),
        "{:?}",
        report.errors
    );
    assert!(
        report
            .errors
            .iter()
            .any(|line| line.contains("never-written")),
        "the missing digest must be named: {:?}",
        report.errors
    );
    std::fs::remove_dir_all(&root).ok();
}

#[test]
fn the_doctor_flags_a_dangling_journal_as_an_error_once_cutover_started() {
    let (root, tag) = scratch("doctor-journal");
    let daemon = DaemonApp::try_bootstrap(config(&tag, false), durable(&root)).expect("boot");
    daemon
        .seed_recovery_fixture("demo-crash-profile")
        .expect("seed a cutover-mid-flight transaction");

    let report = doctor(&daemon);
    assert!(
        report
            .warnings
            .iter()
            .any(|line| line.contains("dangling-pending-journal")
                || line.contains("recovery decision")),
        "{:?}",
        report.warnings
    );
    // `seed_recovery_fixture` advances the journal into Cutover, which is not "still running".
    assert!(
        report
            .errors
            .iter()
            .any(|line| line.contains("dangling-pending-journal [error]")),
        "a journal past cutover must escalate: {:?}",
        report.errors
    );
    assert!(
        report
            .errors
            .iter()
            .any(|line| line.contains("no-valid-last-known-good")),
        "unfinished work with nothing to fall back to must be reported: {:?}",
        report.errors
    );
    std::fs::remove_dir_all(&root).ok();
}

/// An unknown job id is "handled, found nothing", not "no handler connected".
#[test]
fn following_an_unknown_job_is_a_typed_error_not_a_missing_handler() {
    let (_root, tag) = scratch("follow-unknown");
    let daemon = DaemonApp::try_bootstrap(config(&tag, false), durable("/tmp")).expect("boot");
    let envelope = RequestEnvelope {
        request_id: RequestId(78),
        trace_id: TraceId::new("follow"),
        role: Role::Operator,
        io_budget: None,
        operation: Operation::Diagnostics(caly_api::DiagnosticsOp::FollowJob {
            request: caly_api::JobFollowRequest {
                job_id: caly_api::JobId(4242),
                from_event_index: None,
            },
        }),
        ..envelope_base()
    };
    let error = caly_daemon::query::handle_query(&daemon, &envelope)
        .expect_err("an unknown job must be an error, not an empty result");
    assert_eq!(error.code, caly_api::ErrorCode::Conflict);
    assert!(
        error.summary.contains("no such job: 4242"),
        "{}",
        error.summary
    );
    assert!(
        !error.summary.contains("no daemon handler"),
        "the message must not claim an unimplemented handler: {}",
        error.summary
    );
}

fn snapshot_record(id: &str, artifact: &str) -> caly_storage::SnapshotRecord {
    caly_storage::SnapshotRecord {
        id: caly_storage::SnapshotRecordId(id.to_owned()),
        revision_id: caly_storage::RevisionId(format!("rev:{id}")),
        revision_number: caly_storage::RevisionNumber(1),
        profile_id: "ghost-profile".to_owned(),
        semantic_digest: "sem:ghost".to_owned(),
        compiled_artifact_digest: artifact.to_owned(),
        core_binary_digest: "bin".to_owned(),
        core_identity: "mihomo@0.1".to_owned(),
        apply_plan_summary: "Restart".to_owned(),
        journal_id: None,
        selection_memory_digest: None,
        validation_summary: "ok".to_owned(),
        created_at_unix_ms: 5,
        is_last_known_good: true,
    }
}
