//! What happens when the daemon has to refuse work it was asked to do.
//!
//! `docs/engineering/OVERLOAD_AND_RETRY_MODEL.md §3.1` is explicit about a `QueueFull` refusal: the request has not
//! entered the execution state, the caller gets a retryable error with `RetryLater`, and it must
//! "不产生 apply side effect". Before this round the engine allocated a job id and advanced its
//! generation *before* trying to enqueue, so a refusal did produce a side effect — it moved the revision
//! that every `expected_revision` is compared against (`docs/history/ONBOARDING_NOTES.md §4.58`). And the
//! caller-facing error was rebuilt by a second mapper that kept only `Unavailable`, the exact shape
//! `§8` forbids (`§4.59`).
//!
//! These tests run the real request path against the real queue cap, because "we handle overload" is
//! only a claim once something has actually overflowed.

use caly_api::{
    Accepted, DelayTestRequest, DiagnosticsOp, DoctorRequest, ErrorCategory, ErrorCode, NodeId,
    Operation, ProtocolVersion, ProxyOp, RequestEnvelope, ResponseEnvelope, Role, TraceId,
};
use caly_common::Actor;
use caly_daemon::{handle_request, DaemonApp, DaemonBootstrapConfig};

/// The engine's own default queue depth (`EngineState::new`), restated here so that raising it has to
/// pass through this file — a silently widened cap would turn every flood below into a no-op.
const QUEUE_CAP: usize = 256;

fn daemon(tag: &str) -> DaemonApp {
    DaemonApp::bootstrap(DaemonBootstrapConfig {
        instance_id: tag.to_owned(),
        protocol_version: ProtocolVersion { major: 1, minor: 0 },
        recover_on_start: false,
    })
}

fn envelope(operation: Operation, id: u64, expected_revision: Option<u64>) -> RequestEnvelope {
    RequestEnvelope {
        protocol: ProtocolVersion { major: 1, minor: 0 },
        request_id: caly_api::RequestId(id),
        trace_id: TraceId::new(format!("overload-{id}")),
        deadline_ms: None,
        expected_revision,
        idempotency_key: None,
        role: Role::Admin,
        io_budget: None,
        operation,
    }
}

/// One cheap command that reaches the queue: a delay test is a command (`ADR-018`: writes are jobs) and
/// it changes no runtime state, so the only thing the flood can move is the revision counter.
fn flood_command(tag: usize) -> Operation {
    Operation::Proxy(ProxyOp::TestDelay {
        request: DelayTestRequest {
            node_ids: vec![NodeId(format!("node-{tag}"))],
        },
    })
}

fn submit(daemon: &DaemonApp, id: u64, expected_revision: Option<u64>) -> ResponseEnvelope {
    handle_request(
        daemon,
        Actor::Cli,
        &envelope(flood_command(id as usize), id, expected_revision),
    )
}

fn accepted(response: &ResponseEnvelope) -> Accepted {
    match &response.result {
        Ok(caly_api::OperationResult::Accepted(accepted)) => accepted.clone(),
        other => panic!("expected an accepted delay test, got {other:?}"),
    }
}

/// Fill the queue to exactly its capacity. The last `Accepted` is returned because its
/// `state_revision` is the live revision counter as the engine sees it — which is what a
/// compare-and-swap caller would have read.
fn fill_queue(daemon: &DaemonApp) -> Accepted {
    let mut last = None;
    for index in 1..=QUEUE_CAP {
        let response = submit(daemon, index as u64, None);
        last = Some(accepted(&response));
    }
    let last = last.expect("the queue accepts at least one command");
    assert_eq!(
        daemon.queue_stats().expect("queue stats"),
        (QUEUE_CAP, QUEUE_CAP),
        "the flood must land exactly on the cap or nothing is being tested"
    );
    last
}

#[test]
fn a_full_queue_is_refused_with_a_class_a_hint_and_a_retry_not_a_bare_unavailable() {
    let daemon = daemon("overload-refusal");
    let last = fill_queue(&daemon);
    assert_eq!(
        last.state_revision, QUEUE_CAP as u64,
        "one accepted command, one revision"
    );

    let response = submit(&daemon, 1_000, None);
    let ResponseEnvelope {
        result: Err(error), ..
    } = &response
    else {
        panic!(
            "a command over the cap must be refused, got {:?}",
            response.result
        );
    };
    assert_eq!(error.code, ErrorCode::Unavailable, "{error:?}");
    assert_eq!(error.category, ErrorCategory::Internal, "{error:?}");
    assert!(error.retryable, "a refusal is transient: {error:?}");
    assert!(error.summary.contains("command queue full"), "{error:?}");
    // The three things `§9` says a caller needs: which class, which hint, and the numbers behind it.
    assert_eq!(
        error.remediation.as_deref(),
        Some("retry after current queued work drains"),
        "{error:?}"
    );
    let detail = error.detail.clone().unwrap_or_default();
    for token in [
        "error=queue_full",
        "retry_hint=RetryLater",
        &format!("queue_cap={QUEUE_CAP}"),
        "queue_len=256",
    ] {
        assert!(detail.contains(token), "{token} missing from {detail}");
    }
    assert!(
        error
            .diagnostics
            .iter()
            .any(|diagnostic| diagnostic.code == "queue_full"),
        "the machine-readable class must survive to the client: {error:?}"
    );
    // And not the two wrong answers this codebase has a history of producing.
    assert!(
        !error.summary.contains("no daemon handler"),
        "a refusal must not look like an unimplemented operation: {error:?}"
    );
    assert_ne!(error.code, ErrorCode::Internal, "{error:?}");
}

/// The regression this round exists for.
///
/// A refusal that advances the generation invalidates a compare-and-swap expectation that was correct
/// when it was read: the first refusal moves the revision, so the next caller — holding the value it
/// read *before* any of this — is told "conflict, the state moved" about a state that never moved.
#[test]
fn a_refusal_does_not_turn_a_valid_cas_expectation_into_a_conflict() {
    let daemon = daemon("overload-cas");
    let last = fill_queue(&daemon);
    let revision = last.state_revision;

    for id in 2_000..2_003 {
        let response = submit(&daemon, id, Some(revision));
        let ResponseEnvelope {
            result: Err(error), ..
        } = &response
        else {
            panic!(
                "still over the cap, so this must be refused: {:?}",
                response.result
            );
        };
        assert_eq!(
            error.code,
            ErrorCode::Unavailable,
            "refusal #{id} changed nothing, so the caller's expectation is still valid: {error:?}"
        );
        assert!(
            error.summary.contains("command queue full"),
            "the refusal must stay about capacity: {error:?}"
        );
    }

    // A refusal is not a write: nothing may be queued that was not accepted.
    assert_eq!(
        daemon.queue_stats().expect("queue stats"),
        (QUEUE_CAP, QUEUE_CAP),
        "refusals must neither enqueue nor evict"
    );
}

/// Differential form of the same claim, for readers who distrust a single daemon's counters: the
/// revision history of a daemon that refused two commands must be identical to one that refused none.
#[test]
fn refusals_are_invisible_in_the_revision_history_of_the_work_that_did_run() {
    let with_refusals = daemon("overload-a");
    let clean = daemon("overload-b");

    let last_a = fill_queue(&with_refusals);
    let last_b = fill_queue(&clean);
    assert_eq!(last_a.state_revision, last_b.state_revision);

    for id in 3_000..3_002 {
        assert!(submit(&with_refusals, id, None).result.is_err());
    }

    // Drain one job each, then submit again; the next accepted revision must match.
    assert_eq!(with_refusals.drain_engine_once().expect("drain a"), 1);
    assert_eq!(clean.drain_engine_once().expect("drain b"), 1);
    let after_a = accepted(&submit(&with_refusals, 5_000, None));
    let after_b = accepted(&submit(&clean, 5_000, None));
    assert_eq!(
        after_a.state_revision, after_b.state_revision,
        "two refusals moved the revision of the flooded daemon"
    );
    assert_eq!(
        after_a.job_id, after_b.job_id,
        "and they consumed a job id too, so the ids drift apart"
    );
}

#[test]
fn doctor_reports_the_pressure_the_caller_was_already_told_about() {
    let daemon = daemon("overload-doctor");
    fill_queue(&daemon);

    let before = doctor(&daemon, 6_000);
    assert!(
        !before
            .warnings
            .iter()
            .any(|line| line.contains("overload queue_full")),
        "no refusal has happened yet: {:?}",
        before.warnings
    );

    for id in 7_000..7_003 {
        assert!(submit(&daemon, id, None).result.is_err());
    }
    let after = doctor(&daemon, 6_001);
    let line = after
        .warnings
        .iter()
        .find(|line| line.contains("overload queue_full"))
        .unwrap_or_else(|| panic!("the refusals never reached doctor: {:?}", after.warnings));
    assert!(line.contains("3 occurrence(s)"), "{line}");
    assert!(line.contains("hint RetryLater"), "{line}");
    assert!(line.contains(&format!("capacity={QUEUE_CAP}")), "{line}");
    // Pressure is a warning, not an error: the engine protected itself.
    assert!(
        !after.errors.iter().any(|line| line.contains("overload")),
        "{:?}",
        after.errors
    );
    // The caller's transient error and the operator's durable line are the same event, once each.
    assert_eq!(
        after
            .warnings
            .iter()
            .filter(|line| line.contains("overload queue_full"))
            .count(),
        1,
        "one line per class, not one per refusal"
    );
}

fn doctor(daemon: &DaemonApp, id: u64) -> caly_api::DoctorReport {
    let response = handle_request(
        daemon,
        Actor::Cli,
        &envelope(
            Operation::Diagnostics(DiagnosticsOp::Doctor {
                request: DoctorRequest {
                    include_runtime: false,
                },
            }),
            id,
            None,
        ),
    );
    match response.result.expect("doctor") {
        caly_api::OperationResult::DoctorReport(report) => report,
        other => panic!("{other:?}"),
    }
}
