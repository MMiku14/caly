//! Durable source inspection through the daemon query boundary.
//!
//! This is intentionally fixture-backed and goes through `handle_request`, not a hand-built DTO:
//! the source worker owns durable verification, the engine owns the typed projection, and the
//! daemon owns only the redaction/facade boundary. A query must read the durable record after the
//! update has been published and must not silently fall back to a process-local estimate.

use std::sync::Arc;

use caly_api::{
    Operation, OperationResult, ProtocolVersion, RequestEnvelope, RequestId, Role, SourceId,
    SourceOp, TraceId,
};
use caly_common::redact::REDACTED;
use caly_common::Actor;
use caly_daemon::{handle_request, DaemonApp, DaemonBootstrapConfig};
use caly_engine::{HttpSourceUpdateWorker, SourceEndpoint, SourceUpdateWorker};
use caly_io::{FetchBody, FetchReq, FetchResp, Http, IoContext, IoFault};
use caly_storage::{InMemoryStorage, StorageBackend};

const SOURCE_ID: &str = "daemon-fixture-source";
const SECRET: &str = "daemon-fixture-secret";

fn ctx() -> IoContext {
    IoContext::new(TraceId::new("source-inspection-test"), Actor::System)
}

fn fixture() -> Vec<u8> {
    std::fs::read(concat!(
        env!("CARGO_MANIFEST_DIR"),
        "/../../fixtures/subscription-20260803.txt"
    ))
    .expect("real subscription fixture")
}

#[derive(Clone)]
struct FixtureHttp {
    body: Arc<Vec<u8>>,
}

impl Http for FixtureHttp {
    fn fetch<'a>(
        &'a self,
        request: FetchReq,
        _ctx: &'a IoContext,
    ) -> caly_io::BoxFuture<'a, Result<FetchResp, IoFault>> {
        let body = Arc::clone(&self.body);
        Box::pin(async move {
            Ok(FetchResp {
                status: 200,
                etag: Some("\"fixture-daemon-v1\"".to_owned()),
                last_modified: Some("Mon, 03 Aug 2026 00:00:00 GMT".to_owned()),
                body: FetchBody {
                    label: format!("http:{}", request.url),
                    bytes: (*body).clone(),
                },
            })
        })
    }
}

fn config() -> DaemonBootstrapConfig {
    DaemonBootstrapConfig {
        instance_id: "source-inspection-test".to_owned(),
        protocol_version: ProtocolVersion { major: 1, minor: 0 },
        recover_on_start: false,
    }
}

fn inspect_envelope() -> RequestEnvelope {
    RequestEnvelope {
        protocol: ProtocolVersion { major: 1, minor: 0 },
        request_id: RequestId(1),
        trace_id: TraceId::new("source-inspection-request"),
        deadline_ms: None,
        expected_revision: None,
        idempotency_key: None,
        role: Role::Operator,
        io_budget: None,
        operation: Operation::Source(SourceOp::Inspect {
            source_id: SourceId(SOURCE_ID.to_owned()),
        }),
    }
}

#[test]
fn daemon_source_inspection_reads_durable_fixture_and_redacts_at_query_boundary() {
    let backend: Arc<dyn StorageBackend> = Arc::new(InMemoryStorage::new());
    let app = DaemonApp::try_bootstrap(config(), Arc::clone(&backend)).expect("daemon boot");
    app.register_secret(SECRET)
        .expect("register fixture secret");

    let endpoint = SourceEndpoint::subscription_named(
        SOURCE_ID,
        format!("Fixture {SECRET}"),
        format!("https://fixture.invalid/subscription?token={SECRET}"),
        4 * 1024 * 1024,
    );
    let worker = Arc::new(
        HttpSourceUpdateWorker::new(
            Arc::new(FixtureHttp {
                body: Arc::new(fixture()),
            }),
            backend,
        )
        .expect("worker startup"),
    );
    worker.register(endpoint).expect("register endpoint");
    let report = worker.update(SOURCE_ID, &ctx()).expect("fixture update");
    assert_eq!(report.normalized.nodes.len(), 30);
    app.set_source_update_worker(worker)
        .expect("install worker");

    let direct = app
        .source_inspection(SourceId(SOURCE_ID.to_owned()), &ctx())
        .expect("direct source inspection");
    assert_eq!(direct.normalized_node_count, 30);
    assert_eq!(direct.route.as_deref(), Some("direct"));
    assert_eq!(direct.etag.as_deref(), Some("\"fixture-daemon-v1\""));
    assert_eq!(direct.provenance.len(), 1);
    let rendered = format!("{direct:?}");
    assert!(
        !rendered.contains(SECRET),
        "direct query leaked secret: {rendered}"
    );
    assert!(
        rendered.contains(REDACTED),
        "direct query has no redaction marker: {rendered}"
    );
    assert_eq!(direct.summary.label, format!("Fixture {REDACTED}"));

    let response = handle_request(&app, Actor::Cli, &inspect_envelope());
    let inspected = match response.result {
        Ok(OperationResult::SourceInspection(value)) => value,
        other => panic!("expected source inspection response, got {other:?}"),
    };
    assert_eq!(inspected.normalized_node_count, 30);
    assert_eq!(inspected.latest_digest, direct.latest_digest);
    assert_eq!(inspected.provenance, direct.provenance);
    let response_text = format!("{inspected:?}");
    assert!(
        !response_text.contains(SECRET),
        "facade query leaked secret: {response_text}"
    );
}
