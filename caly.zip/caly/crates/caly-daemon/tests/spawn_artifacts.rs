//! Spawn-artifact golden judges (round 67, `IMPLEMENTATION_STATUS §8.4` "mihomo / sing-box
//! 产物字节 golden"): after a real apply, the runtime root must hold **the pinned assets'
//! exact bytes** — the gz/tgz copy, the gunzipped/tar-extracted binary, the two geo databases —
//! and the merged config. A digest check on the *asset* proves the asset matches the pin; this
//! judge proves the **deployment** carries the asset bytes to the disk and renders the operational
//! envelope correctly. `cache.db` is the core's own runtime artifact and is explicitly outside the
//! golden (it is not something SpawnCore writes); the whitelist asserts nothing else appears.
//!
//! Golden technique, per the two-implementations doctrine: the merged mihomo config is rebuilt
//! from the artifact bytes plus the documented envelope template (the template is a snapshot in
//! the same sense a golden file is — a deliberate change to the envelope must update both), and
//! the sing-box config is re-merged by an independent oracle into `serde_json::Value` equality.
#![allow(clippy::disallowed_methods, clippy::disallowed_types)]

use std::path::{Path, PathBuf};
use std::sync::Arc;

use caly_api::{
    ApplyRequest, JobId, ProfileId, ProfileOp, ProtocolVersion, RequestEnvelope, RequestId, Role,
    TraceId,
};
use caly_common::Actor;
use caly_daemon::effect_std::{CoreAssets, StdEffectRuntime};
use caly_daemon::{DaemonApp, DaemonBootstrapConfig};

struct ScratchDir {
    path: String,
}
impl Drop for ScratchDir {
    fn drop(&mut self) {
        let _ = std::fs::remove_dir_all(&self.path);
    }
}
fn scratch(label: &str) -> ScratchDir {
    let path = format!(
        "{}/spawn-artifacts-{label}-{}",
        env!("CARGO_TARGET_TMPDIR"),
        std::process::id()
    );
    let _ = std::fs::remove_dir_all(&path);
    std::fs::create_dir_all(&path).expect("scratch dir");
    ScratchDir { path }
}

fn envelope(profile_id: &str, request_id: u64) -> RequestEnvelope {
    RequestEnvelope {
        protocol: ProtocolVersion { major: 1, minor: 0 },
        request_id: RequestId(request_id),
        trace_id: TraceId::new(format!("trace-spawn-artifacts-{request_id}")),
        deadline_ms: Some(60_000),
        expected_revision: None,
        idempotency_key: Some(format!("spawn-artifacts-{request_id}")),
        role: Role::Admin,
        io_budget: None,
        operation: caly_api::Operation::Profile(ProfileOp::Apply {
            request: ApplyRequest {
                profile_id: ProfileId(profile_id.to_owned()),
                dry_run: false,
                strict: false,
            },
        }),
    }
}

fn real_app(label: &str) -> (DaemonApp, Arc<StdEffectRuntime>, ScratchDir) {
    let guard = scratch(label);
    let mut app = DaemonApp::bootstrap(DaemonBootstrapConfig {
        instance_id: format!("spawn-artifacts-{label}"),
        protocol_version: ProtocolVersion { major: 1, minor: 0 },
        recover_on_start: false,
    });
    let effects = Arc::new(StdEffectRuntime::new(
        guard.path.clone(),
        app.engine_storage(),
        CoreAssets::workspace_default(),
    ));
    app.set_effect_runtime(effects.clone())
        .expect("real runtime swap");
    (app, effects, guard)
}

fn apply_once(app: &DaemonApp, profile_id: &str, request_id: u64) -> (u64, String) {
    let submitted = app
        .submit_request_as_command(Actor::Cli, &envelope(profile_id, request_id))
        .expect("admin may submit apply")
        .expect("apply maps to a command");
    assert_eq!(app.drain_engine_once().expect("worker drain"), 1);
    let projection = app
        .follow_job_projection(JobId(submitted.job_id()), None)
        .expect("projection")
        .expect("job exists");
    (submitted.job_id(), projection.summary.state.clone())
}

fn instance_dir(root: &str, label: &str) -> PathBuf {
    Path::new(root).join("runtime").join(label)
}

/// Every file under `dir` must be one of the whitelist (SpawnCore/plan writes plus the core's
/// own `cache.db`, which is explicitly excluded from the golden) and each must exist.
fn assert_tree(dir: &Path, whitelist: &[&str], label: &str) {
    let mut found: Vec<String> = Vec::new();
    for entry in std::fs::read_dir(dir).expect("read the instance dir") {
        let entry = entry.expect("entry");
        assert!(
            entry.file_type().expect("file type").is_file(),
            "{label}: no subdirs expected in the instance dir"
        );
        found.push(entry.file_name().to_string_lossy().into_owned());
    }
    found.sort();
    for name in &found {
        assert!(
            whitelist.contains(&name.as_str()),
            "{label}: {name} is not in the golden whitelist (unexpected artifact)"
        );
    }
    for need in whitelist {
        if *need == "cache.db" {
            continue; // runtime-owned, may or may not exist yet
        }
        assert!(
            dir.join(need).exists(),
            "{label}: golden artifact {need} is missing from the instance dir"
        );
    }
}

fn read(path: &Path) -> Vec<u8> {
    std::fs::read(path).unwrap_or_else(|error| panic!("read {}: {error}", path.display()))
}

/// Independent gunzip: copy the gz beside itself with a new name (the `-k` keep-flag path is
/// what real_core.rs uses; `-k` keeps the archive), gunzip, read the decompressed bytes.
fn gunzip_to_vec(gz: &Path, work: &Path) -> Vec<u8> {
    let copied = work.join("probe.gz");
    std::fs::copy(gz, &copied).expect("copy gz for independent gunzip");
    let status = std::process::Command::new("gunzip")
        .arg("-kf")
        .arg(&copied)
        .status()
        .expect("gunzip must exist on this host");
    assert!(status.success(), "gunzip failed");
    let out = work.join("probe");
    let out_path = if out.exists() {
        out
    } else {
        copied.with_extension("")
    };
    let bytes = read(&out_path);
    std::fs::remove_file(&copied).ok();
    let _ = std::fs::remove_file(&out_path);
    bytes
}

fn parse_port_pair(yaml: &str) -> (u16, u16) {
    let mixed = yaml
        .lines()
        .find_map(|line| line.strip_prefix("mixed-port: "))
        .and_then(|v| v.parse::<u16>().ok())
        .unwrap_or(0);
    let controller = yaml
        .lines()
        .find_map(|line| line.strip_prefix("external-controller: 127.0.0.1:"))
        .and_then(|v| v.parse::<u16>().ok())
        .unwrap_or(0);
    (mixed, controller)
}

#[test]
fn the_spawned_mihomo_artifacts_are_the_pinned_assets_byte_for_byte() {
    let (app, effects, guard) = real_app("mihomo");
    let (_job, state) = apply_once(&app, "nightshift", 101);
    assert_eq!(state, "completed", "mihomo apply must complete");

    let assets = CoreAssets::workspace_default();
    let dir = instance_dir(&guard.path, "nightshift");
    assert_tree(
        &dir,
        &[
            "caly-run.yaml",
            "config.yaml",
            "core",
            "core.gz",
            "geoip.metadb",
            "geosite.dat",
            "cache.db",
        ],
        "mihomo",
    );

    // Pinned bytes, byte for byte: the copies in the instance dir are the workspace assets.
    assert_eq!(
        read(&dir.join("core.gz")),
        read(Path::new(&assets.mihomo_gz)),
        "core.gz must be the pinned mihomo archive"
    );
    assert_eq!(
        read(&dir.join("geoip.metadb")),
        read(Path::new(&assets.geoip)),
        "geoip.metadb must be the pinned asset"
    );
    assert_eq!(
        read(&dir.join("geosite.dat")),
        read(Path::new(&assets.geosite)),
        "geosite.dat must be the pinned asset"
    );
    // The deployed binary is the gunzip of the pinned archive (independent gunzip).
    let work = Path::new(&guard.path).join("probe-work");
    std::fs::create_dir_all(&work).expect("probe work dir");
    let expected_binary = gunzip_to_vec(&dir.join("core.gz"), &work);
    assert_eq!(
        read(&dir.join("core")),
        expected_binary,
        "the deployed core must be the archive's decompressed bytes"
    );

    // The merged config: the artifact verbatim, then the documented envelope with the
    // deployed ports. Rebuilt independently — a snapshot of the envelope contract.
    let config_yaml = read(&dir.join("config.yaml"));
    let run_yaml = read(&dir.join("caly-run.yaml"));
    assert!(
        run_yaml.starts_with(&config_yaml),
        "caly-run.yaml must begin with the artifact bytes"
    );
    let (mixed, controller) = parse_port_pair(&String::from_utf8_lossy(&run_yaml));
    assert!(mixed >= 1, "a real mixed port must be chosen: {mixed}");
    assert!(
        controller >= 1,
        "a real controller port must be chosen: {controller}"
    );
    let expected = format!(
        "{artifact}\n# caly runtime envelope — operational keys, not profile content\n\
         mixed-port: {mixed}\n\
         external-controller: 127.0.0.1:{controller}\n\
         log-level: info\n\
         geox-url:\n  geoip: \"http://127.0.0.1:1/geoip.metadb\"\n  geosite: \"http://127.0.0.1:1/geosite.dat\"\n  mmdb: \"http://127.0.0.1:1/country.mmdb\"\n  asn: \"http://127.0.0.1:1/GeoLite2-ASN.mmdb\"\n",
        artifact = String::from_utf8_lossy(&config_yaml),
    );
    assert_eq!(
        String::from_utf8_lossy(&run_yaml),
        expected,
        "caly-run.yaml must be the artifact plus the deployed envelope, verbatim"
    );

    let pid = effects.live_pid().expect("a live core");
    let _ = effects.shutdown(3_000);
    let _ = pid;
}

#[test]
fn the_spawned_singbox_artifacts_are_the_pinned_assets_byte_for_byte() {
    let (app, effects, guard) = real_app("singbox");
    let (_job, state) = apply_once(&app, "nightshift-sing", 501);
    assert_eq!(state, "completed", "sing-box apply must complete");

    let assets = CoreAssets::workspace_default();
    let dir = instance_dir(&guard.path, "nightshift-sing");
    assert_tree(
        &dir,
        &[
            "caly-run.json",
            "config.json",
            "core.tar.gz",
            "sing-box",
            "libcronet.so",
            "LICENSE",
            "cache.db",
        ],
        "sing-box",
    );

    // Pinned archive, byte for byte.
    assert_eq!(
        read(&dir.join("core.tar.gz")),
        read(Path::new(&assets.singbox_tgz)),
        "core.tar.gz must be the pinned sing-box archive"
    );

    // The deployed members are the archive's members (independent tar extraction).
    let work = Path::new(&guard.path).join("probe-work");
    std::fs::create_dir_all(&work).expect("probe work dir");
    let extracted = work.join("members");
    std::fs::create_dir_all(&extracted).expect("members dir");
    let archived = work.join("archive.tar.gz");
    std::fs::copy(dir.join("core.tar.gz"), &archived).expect("copy archive");
    let status = std::process::Command::new("tar")
        .arg("xzf")
        .arg(&archived)
        .arg("-C")
        .arg(&extracted)
        .status()
        .expect("tar must exist on this host");
    assert!(status.success(), "tar extraction failed");
    let member_root = extracted.join("sing-box-1.13.20-linux-amd64");
    for member in ["sing-box", "libcronet.so", "LICENSE"] {
        assert_eq!(
            read(&dir.join(member)),
            read(&member_root.join(member)),
            "deployed {member} must be the archive member's bytes"
        );
    }

    // The merged config, re-merged by an independent oracle into Value equality: same
    // inbound port injection, same clash-api controller, everything else the artifact.
    let config_doc: serde_json::Value =
        serde_json::from_slice(&read(&dir.join("config.json"))).expect("artifact is JSON");
    let deployed_doc: serde_json::Value =
        serde_json::from_slice(&read(&dir.join("caly-run.json"))).expect("deployed config is JSON");
    let mixed_port = deployed_doc["inbounds"]
        .as_array()
        .and_then(|list| {
            list.iter()
                .find(|inbound| inbound["type"].as_str() == Some("mixed"))
        })
        .and_then(|inbound| inbound["listen_port"].as_u64())
        .unwrap_or(0);
    assert!(
        mixed_port >= 1,
        "the deployed config must carry a real mixed port: {deployed_doc}"
    );
    let controller = deployed_doc["experimental"]["clash_api"]["external_controller"]
        .as_str()
        .and_then(|value| value.strip_prefix("127.0.0.1:"))
        .and_then(|port| port.parse::<u64>().ok())
        .unwrap_or(0);
    assert!(
        controller >= 1,
        "the deployed config must carry a real controller: {deployed_doc}"
    );

    let mut oracle = config_doc;
    if let Some(inbounds) = oracle.get_mut("inbounds").and_then(|v| v.as_array_mut()) {
        for inbound in inbounds.iter_mut() {
            if inbound.get("type").and_then(serde_json::Value::as_str) == Some("mixed") {
                inbound["listen_port"] = serde_json::Value::from(mixed_port);
                break;
            }
        }
    }
    if let Some(experimental) = oracle
        .get_mut("experimental")
        .and_then(|v| v.as_object_mut())
    {
        experimental.insert(
            "clash_api".to_owned(),
            serde_json::json!({
                "external_controller": format!("127.0.0.1:{controller}")
            }),
        );
    }
    assert_eq!(
        deployed_doc, oracle,
        "the deployed config must be the artifact merged with the deployed ports"
    );

    let pid = effects.live_pid().expect("a live core");
    let _ = effects.shutdown(3_000);
    let _ = pid;
}
