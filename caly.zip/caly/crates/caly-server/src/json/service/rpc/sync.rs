//! Server-side synchronous execution (`execute_sync`).
//!
//! The daemon mints an operation id, submits through the normal admission
//! path, then performs the same bounded status polling the CLI used to own.
//! The shared adapter lock is never held across an await.

use std::{
    sync::atomic::{AtomicU64, Ordering},
    time::{Duration, Instant},
};

use caly_application::service::ApplicationServicePort;
use caly_protocol::protocol::v2::{
    ExecuteRequest, ExecuteSyncRequest, ExecuteSyncResponse, GetOperationStatusRequest,
    WireCommand, WireId,
};
use caly_protocol::wire_frames::JsonResponse;

use super::super::{JsonService, ServiceV2, lock_state, service_to_wire};

/// Hard ceiling for one `execute_sync` wait. Longer requests are clamped so a
/// malicious peer cannot pin a connection task indefinitely.
const MAX_SYNC_TIMEOUT_MS: u32 = 30_000;
/// Poll cadence floor; shorter values are clamped to avoid a tight lock loop.
const MIN_SYNC_POLL_MS: u32 = 10;
/// Poll cadence ceiling; one status query per second is plenty for local RPC.
const MAX_SYNC_POLL_MS: u32 = 1_000;

impl<A> JsonService<A> {
    pub(super) async fn dispatch_execute_sync(
        &self,
        request: ExecuteSyncRequest,
    ) -> Result<JsonResponse, caly_protocol::wire_frames::WireError>
    where
        A: ApplicationServicePort,
    {
        let operation_id = mint_operation_id();
        let is_stop = matches!(request.command, WireCommand::StopDaemon);
        let timeout =
            Duration::from_millis(u64::from(request.timeout_ms.clamp(1, MAX_SYNC_TIMEOUT_MS)));
        let poll = Duration::from_millis(u64::from(
            request
                .poll_interval_ms
                .clamp(MIN_SYNC_POLL_MS, MAX_SYNC_POLL_MS),
        ));
        let first = {
            let mut state = lock_state(&self.state)?;
            state
                .adapter
                .execute(ExecuteRequest {
                    operation_id,
                    command: request.command,
                })
                .map_err(service_to_wire)?
        };
        let mut last = first.operation;
        if last.state.is_terminal() {
            if is_stop {
                self.notify_stop();
            }
            return Ok(JsonResponse::ExecuteSync(ExecuteSyncResponse {
                operation: last,
                timed_out: false,
            }));
        }
        let deadline = Instant::now() + timeout;
        let status_request = GetOperationStatusRequest { operation_id };
        loop {
            let status = {
                let mut state = lock_state(&self.state)?;
                state
                    .adapter
                    .status(status_request)
                    .map_err(service_to_wire)?
            };
            last = status;
            if last.state.is_terminal() {
                if is_stop {
                    self.notify_stop();
                }
                return Ok(JsonResponse::ExecuteSync(ExecuteSyncResponse {
                    operation: last,
                    timed_out: false,
                }));
            }
            if Instant::now() >= deadline {
                return Ok(JsonResponse::ExecuteSync(ExecuteSyncResponse {
                    operation: last,
                    timed_out: true,
                }));
            }
            tokio::time::sleep(poll).await;
        }
    }
    /// Signals the daemon serve loop when a synchronous `StopDaemon` reached a
    /// terminal state. Mirrors the non-sync execute path.
    fn notify_stop(&self) {
        if let Ok(state) = lock_state(&self.state)
            && let Some(notifier) = &state.stop_notifier
        {
            notifier.notify_waiters();
        }
    }
}

/// Mints a process-unique operation id without a platform dependency.
/// Operation ids only require uniqueness inside the in-memory operation
/// store; nanosecond wall time + an atomic counter is collision-free for
/// that lifetime.
fn mint_operation_id() -> WireId {
    static COUNTER: AtomicU64 = AtomicU64::new(0);
    let now = std::time::SystemTime::now()
        .duration_since(std::time::UNIX_EPOCH)
        .map_or(0, |duration| {
            u64::try_from(duration.as_nanos()).unwrap_or(u64::MAX)
        });
    let counter = COUNTER.fetch_add(1, Ordering::Relaxed);
    let mut id = [0_u8; 16];
    id[..8].copy_from_slice(&now.to_be_bytes());
    id[8..].copy_from_slice(&counter.to_be_bytes());
    id
}
