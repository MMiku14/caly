//! Tests for `json/service.rs`, extracted to the sibling
//! convention file (audit #70 file-length budget).

use super::*;

use caly_application::{
    command_bus::CommandEnvelope,
    events::SequencedEvent,
    service::{ApplicationServiceError, ApplicationWatch, CancellationResult},
};
use caly_domain::UnixMillis;
use caly_domain::{EventCursor, OperationId, OperationStatus, PresentationSnapshot};
use caly_protocol::protocol::v2::{DecodeLimits, FeatureList, ProtocolVersion};

/// Session-only stub; the validated paths never touch the application.
struct StubApp;

impl ApplicationServicePort for StubApp {
    fn submit(
        &mut self,
        _envelope: CommandEnvelope,
    ) -> Result<OperationStatus, ApplicationServiceError> {
        Err(ApplicationServiceError::Unavailable)
    }
    fn cancel(
        &mut self,
        _operation_id: OperationId,
    ) -> Result<CancellationResult, ApplicationServiceError> {
        Err(ApplicationServiceError::Unavailable)
    }
    fn operation_status(
        &self,
        _operation_id: OperationId,
    ) -> Result<OperationStatus, ApplicationServiceError> {
        Err(ApplicationServiceError::Unavailable)
    }
    fn list_operations(&self) -> Result<caly_domain::OperationList, ApplicationServiceError> {
        Ok(caly_domain::BoundedVec::new())
    }
    fn live_connections(
        &self,
    ) -> Result<Vec<caly_domain::LiveConnection>, ApplicationServiceError> {
        Ok(Vec::new())
    }
    fn snapshot(&self) -> Result<PresentationSnapshot, ApplicationServiceError> {
        Err(ApplicationServiceError::Unavailable)
    }
    fn watch_after(
        &self,
        _cursor: Option<EventCursor>,
    ) -> Result<ApplicationWatch, ApplicationServiceError> {
        Err(ApplicationServiceError::Unavailable)
    }
    fn subscribe_live(&self) -> tokio::sync::broadcast::Receiver<SequencedEvent> {
        tokio::sync::broadcast::channel(1).0.subscribe()
    }
}

fn session(token: [u8; 16], expires: u64) -> ProtocolSession {
    ProtocolSession {
        token,
        version: ProtocolVersion::V2_0,
        features: FeatureList::new(),
        expires_at: UnixMillis::new(expires),
    }
}

fn service_with_registry(capacity: usize) -> Result<JsonService<StubApp>, SessionError> {
    let adapter = ServiceAdapter::new(
        StubApp,
        [1; 16],
        [0xAB; 16],
        crate::admission::TokenAdmission::Open,
        FeatureList::new(),
        DecodeLimits::v2_default(),
    );
    Ok(JsonService {
        state: Arc::new(Mutex::new(ServiceState {
            adapter,
            // tests don't run a transport, so
            // the stop signal is unused.
            stop_notifier: None,
            registry: SessionRegistry::new(capacity)?,
        })),
        connections: Arc::new(tokio::sync::Semaphore::new(
            crate::json::MAX_CONCURRENT_CONNECTIONS,
        )),
    })
}

#[test]
fn adapter_requires_handshake_then_returns_bounded_operation_list() -> Result<(), String> {
    let mut adapter = ServiceAdapter::new(
        StubApp,
        [7; 16],
        [8; 16],
        crate::admission::TokenAdmission::Open,
        FeatureList::new(),
        DecodeLimits::v2_default(),
    );
    assert_eq!(
        adapter.list_operations(),
        Err(ServiceError::HandshakeRequired)
    );
    adapter
        .handshake(HandshakeRequest {
            client_version: ProtocolVersion::V2_0,
            auth_token: None,
            requested_features: FeatureList::new(),
        })
        .map_err(|error| format!("{error:?}"))?;
    let list = adapter
        .list_operations()
        .map_err(|error| format!("{error:?}"))?;
    assert!(list.operations.is_empty());
    Ok(())
}

#[test]
fn validate_session_accepts_live_token_and_rejects_unknown() -> Result<(), SessionError> {
    let service = service_with_registry(4)?;
    service
        .state
        .lock()
        .map_err(|_| SessionError::InvalidToken)?
        .registry
        .insert(session([1; 16], u64::MAX))?;
    let accepted = service.validate_session(Some(caly_domain::to_hex([1; 16])));
    assert!(accepted.is_ok());
    assert!(
        service
            .validate_session(Some(caly_domain::to_hex([2; 16])))
            .is_err()
    );
    Ok(())
}

#[test]
fn validate_session_rejects_missing_token() {
    let service = service_with_registry(4).unwrap();
    assert!(service.validate_session(None).is_err());
}

#[test]
fn validate_session_rejects_expired_token() -> Result<(), SessionError> {
    let service = service_with_registry(4)?;
    service
        .state
        .lock()
        .map_err(|_| SessionError::InvalidToken)?
        .registry
        .insert(session([3; 16], 5))?; // expires at t=5
    // Wall clock is past 5ms since Unix epoch; the token must be expired.
    assert!(
        service
            .validate_session(Some(caly_domain::to_hex([3; 16])))
            .is_err()
    );
    Ok(())
}

#[test]
fn connection_budget_is_bounded_and_reusable() -> Result<(), String> {
    let service = service_with_registry(4).map_err(|error| error.to_string())?;
    let mut slots = Vec::new();
    for _ in 0..crate::json::MAX_CONCURRENT_CONNECTIONS {
        slots.push(
            service
                .try_acquire_connection()
                .map_err(|error| error.to_string())?,
        );
    }
    assert!(
        service.try_acquire_connection().is_err(),
        "the connection budget must refuse work beyond its ceiling"
    );
    drop(slots);
    assert!(
        service.try_acquire_connection().is_ok(),
        "released connection slots must be reusable"
    );
    Ok(())
}

#[tokio::test]
async fn malformed_frame_flood_is_disconnected_after_budget() -> Result<(), String> {
    let service = service_with_registry(4).map_err(|error| error.to_string())?;
    let (mut client, server) = tokio::io::duplex(16 * 1_024);
    let server_task = tokio::spawn(async move {
        service.handle_connection(server).await;
    });
    for _ in 0..MAX_CONSECUTIVE_BAD_FRAMES {
        write_frame(&mut client, b"{")
            .await
            .map_err(FrameError::describe)?;
        let payload = read_frame(&mut client, 1_024)
            .await
            .map_err(FrameError::describe)?;
        let response = decode_json::<ServerFrame>(&payload).map_err(|e| e.to_string())?;
        assert!(
            matches!(response, ServerFrame::Error(_)),
            "malformed request must produce a structured error"
        );
    }
    match read_frame(&mut client, 1_024).await {
        Err(FrameError::Closed) => {}
        other => {
            return Err(format!(
                "expected close after bad-frame budget, got {other:?}"
            ));
        }
    }
    server_task.await.map_err(|error| error.to_string())?;
    Ok(())
}

#[tokio::test]
async fn invalid_session_flood_is_disconnected_after_budget() -> Result<(), String> {
    let service = service_with_registry(4).map_err(|error| error.to_string())?;
    let (mut client, server) = tokio::io::duplex(16 * 1_024);
    let server_task = tokio::spawn(async move {
        service.handle_connection(server).await;
    });
    let handshake = ClientFrame {
        session: None,
        request: JsonRequest::Handshake(HandshakeRequest {
            client_version: ProtocolVersion::V2_0,
            requested_features: FeatureList::new(),
            auth_token: None,
        }),
    };
    write_frame(
        &mut client,
        &encode_json(&handshake).map_err(|error| error.to_string())?,
    )
    .await
    .map_err(FrameError::describe)?;
    let response = read_frame(&mut client, 1_024)
        .await
        .map_err(FrameError::describe)?;
    assert!(
        matches!(
            decode_json::<ServerFrame>(&response),
            Ok(ServerFrame::Result(_))
        ),
        "handshake must succeed before invalid-session flood test"
    );
    let request = ClientFrame {
        session: Some(caly_domain::to_hex([0xAA; 16])),
        request: JsonRequest::GetSnapshot(caly_protocol::protocol::v2::GetSnapshotRequest),
    };
    let payload = encode_json(&request).map_err(|error| error.to_string())?;
    for _ in 0..MAX_CONSECUTIVE_AUTH_FAILURES {
        write_frame(&mut client, &payload)
            .await
            .map_err(FrameError::describe)?;
        let response = read_frame(&mut client, 1_024)
            .await
            .map_err(FrameError::describe)?;
        let decoded = decode_json::<ServerFrame>(&response).map_err(|error| error.to_string())?;
        assert!(
            matches!(decoded, ServerFrame::Error(_)),
            "invalid session must produce a structured error"
        );
    }
    match read_frame(&mut client, 1_024).await {
        Err(FrameError::Closed) => {}
        other => return Err(format!("expected close after auth budget, got {other:?}")),
    }
    server_task.await.map_err(|error| error.to_string())?;
    Ok(())
}
