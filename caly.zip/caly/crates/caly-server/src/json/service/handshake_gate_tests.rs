//! Per-connection handshake gate regression tests, extracted from
//! `json/service/tests.rs` to keep both files within the project's
//! file-length budget.

use super::*;

use caly_application::{
    command_bus::CommandEnvelope,
    events::SequencedEvent,
    service::{ApplicationServiceError, ApplicationWatch, CancellationResult},
};
use caly_domain::{EventCursor, OperationId, OperationStatus, PresentationSnapshot};
use caly_protocol::protocol::v2::{
    DecodeLimits, ExecuteBatchRequest, ExecuteBatchResult, ExecuteRequest, ExecuteSyncRequest,
    FeatureList, HandshakeRequest, ProtocolVersion, WireCommand,
};

/// Handshake-capable stub: every method either answers with an empty bounded
/// value or reports `ApplicationUnavailable`.
struct StubApp;

impl ApplicationServicePort for StubApp {
    fn submit(
        &mut self,
        _envelope: CommandEnvelope,
    ) -> Result<OperationStatus, ApplicationServiceError> {
        Err(ApplicationServiceError::Unavailable)
    }
    fn cancel(
        &mut self,
        _operation_id: OperationId,
    ) -> Result<CancellationResult, ApplicationServiceError> {
        Err(ApplicationServiceError::Unavailable)
    }
    fn operation_status(
        &self,
        _operation_id: OperationId,
    ) -> Result<OperationStatus, ApplicationServiceError> {
        Err(ApplicationServiceError::Unavailable)
    }
    fn list_operations(&self) -> Result<caly_domain::OperationList, ApplicationServiceError> {
        Ok(caly_domain::BoundedVec::new())
    }
    fn live_connections(
        &self,
    ) -> Result<Vec<caly_domain::LiveConnection>, ApplicationServiceError> {
        Ok(Vec::new())
    }
    fn snapshot(&self) -> Result<PresentationSnapshot, ApplicationServiceError> {
        Err(ApplicationServiceError::Unavailable)
    }
    fn watch_after(
        &self,
        _cursor: Option<EventCursor>,
    ) -> Result<ApplicationWatch, ApplicationServiceError> {
        Err(ApplicationServiceError::Unavailable)
    }
    fn subscribe_live(&self) -> tokio::sync::broadcast::Receiver<SequencedEvent> {
        tokio::sync::broadcast::channel(1).0.subscribe()
    }
}

fn service_with_handshake() -> Result<JsonService<StubApp>, SessionError> {
    let adapter = ServiceAdapter::new(
        StubApp,
        [1; 16],
        [0xAB; 16],
        crate::admission::TokenAdmission::Open,
        FeatureList::new(),
        DecodeLimits::v2_default(),
    );
    JsonService::new(adapter, None)
}

async fn write_client_frame(
    client: &mut tokio::io::DuplexStream,
    frame: &ClientFrame,
) -> Result<(), String> {
    write_frame(client, &encode_json(frame).map_err(|e| e.to_string())?)
        .await
        .map_err(FrameError::describe)
}

async fn read_server_frame(client: &mut tokio::io::DuplexStream) -> Result<ServerFrame, String> {
    let payload = read_frame(client, 16 * 1_024)
        .await
        .map_err(FrameError::describe)?;
    decode_json::<ServerFrame>(&payload).map_err(|e| e.to_string())
}

async fn handshake_connection(client: &mut tokio::io::DuplexStream) -> Result<[u8; 16], String> {
    let handshake = ClientFrame {
        session: None,
        request: JsonRequest::Handshake(HandshakeRequest {
            client_version: ProtocolVersion::V2_0,
            requested_features: FeatureList::new(),
            auth_token: None,
        }),
    };
    write_client_frame(client, &handshake).await?;
    match read_server_frame(client).await? {
        ServerFrame::Result(boxed) => match *boxed {
            JsonResponse::Handshake(response) => Ok(response.session_token),
            other => Err(format!("unexpected handshake response: {other:?}")),
        },
        ServerFrame::Error(error) => Err(format!("handshake failed: {error:?}")),
    }
}

#[tokio::test]
async fn each_connection_must_complete_its_own_handshake() -> Result<(), String> {
    let service = service_with_handshake().map_err(|error| error.to_string())?;

    // First connection: complete a handshake and learn the shared token.
    let (mut first_client, first_server) = tokio::io::duplex(16 * 1_024);
    let first_service = service.clone();
    let first_task = tokio::spawn(async move {
        first_service.handle_connection(first_server).await;
    });
    let handshake = ClientFrame {
        session: None,
        request: JsonRequest::Handshake(HandshakeRequest {
            client_version: ProtocolVersion::V2_0,
            requested_features: FeatureList::new(),
            auth_token: None,
        }),
    };
    write_frame(
        &mut first_client,
        &encode_json(&handshake).map_err(|e| e.to_string())?,
    )
    .await
    .map_err(FrameError::describe)?;
    let payload = read_frame(&mut first_client, 1_024)
        .await
        .map_err(FrameError::describe)?;
    let token = match decode_json::<ServerFrame>(&payload).map_err(|e| e.to_string())? {
        ServerFrame::Result(boxed) => match *boxed {
            JsonResponse::Handshake(response) => response.session_token,
            other => return Err(format!("unexpected handshake response: {other:?}")),
        },
        ServerFrame::Error(error) => return Err(format!("handshake failed: {error:?}")),
    };

    // Second connection: a valid token from another connection must NOT
    // bypass this connection's own handshake gate.
    let (mut second_client, second_server) = tokio::io::duplex(16 * 1_024);
    let second_service = service.clone();
    let second_task = tokio::spawn(async move {
        second_service.handle_connection(second_server).await;
    });
    let before_handshake = ClientFrame {
        session: Some(caly_domain::to_hex(token)),
        request: JsonRequest::GetSnapshot(caly_protocol::protocol::v2::GetSnapshotRequest),
    };
    write_frame(
        &mut second_client,
        &encode_json(&before_handshake).map_err(|e| e.to_string())?,
    )
    .await
    .map_err(FrameError::describe)?;
    let payload = read_frame(&mut second_client, 1_024)
        .await
        .map_err(FrameError::describe)?;
    match decode_json::<ServerFrame>(&payload).map_err(|e| e.to_string())? {
        ServerFrame::Error(error) if error.code == WireErrorCode::HandshakeRequired.code() => {
            // Expected: this connection has not handshaken yet.
        }
        other => return Err(format!("expected handshake-required error, got {other:?}")),
    }

    // After its own handshake, the same method is admitted and reaches the
    // application (StubApp reports ApplicationUnavailable for snapshots).
    write_frame(
        &mut second_client,
        &encode_json(&handshake).map_err(|e| e.to_string())?,
    )
    .await
    .map_err(FrameError::describe)?;
    let payload = read_frame(&mut second_client, 1_024)
        .await
        .map_err(FrameError::describe)?;
    if !matches!(
        decode_json::<ServerFrame>(&payload),
        Ok(ServerFrame::Result(_))
    ) {
        return Err(format!(
            "second connection handshake was not accepted: {payload:?}"
        ));
    }
    write_frame(
        &mut second_client,
        &encode_json(&before_handshake).map_err(|e| e.to_string())?,
    )
    .await
    .map_err(FrameError::describe)?;
    let payload = read_frame(&mut second_client, 1_024)
        .await
        .map_err(FrameError::describe)?;
    match decode_json::<ServerFrame>(&payload).map_err(|e| e.to_string())? {
        ServerFrame::Error(error) if error.code == WireErrorCode::ApplicationUnavailable.code() => {
        }
        other => {
            return Err(format!(
                "expected application-unavailable error, got {other:?}"
            ));
        }
    }

    drop(first_client);
    drop(second_client);
    first_task.await.map_err(|error| error.to_string())?;
    second_task.await.map_err(|error| error.to_string())?;
    Ok(())
}

#[tokio::test]
async fn execute_sync_is_dispatched_to_the_application() -> Result<(), String> {
    let service = service_with_handshake().map_err(|error| error.to_string())?;
    let (mut client, server) = tokio::io::duplex(16 * 1_024);
    let task = tokio::spawn(async move {
        service.handle_connection(server).await;
    });
    let token = handshake_connection(&mut client).await?;
    let request = ClientFrame {
        session: Some(caly_domain::to_hex(token)),
        request: JsonRequest::ExecuteSync(ExecuteSyncRequest {
            command: WireCommand::SetMode { mode: 1 },
            timeout_ms: 50,
            poll_interval_ms: 10,
        }),
    };
    write_client_frame(&mut client, &request).await?;
    match read_server_frame(&mut client).await? {
        ServerFrame::Error(error) if error.code == WireErrorCode::ApplicationUnavailable.code() => {
            drop(client);
            task.await.map_err(|error| error.to_string())?;
            Ok(())
        }
        other => Err(format!(
            "expected ApplicationUnavailable from the stub, got {other:?}"
        )),
    }
}

#[tokio::test]
async fn execute_batch_returns_per_item_rejections_and_honours_stop_on_error() -> Result<(), String>
{
    let service = service_with_handshake().map_err(|error| error.to_string())?;
    let (mut client, server) = tokio::io::duplex(16 * 1_024);
    let task = tokio::spawn(async move {
        service.handle_connection(server).await;
    });
    let token = handshake_connection(&mut client).await?;
    let operations = caly_domain::BoundedVec::try_from_vec(vec![
        ExecuteRequest {
            operation_id: [1; 16],
            command: WireCommand::SetMode { mode: 1 },
        },
        ExecuteRequest {
            operation_id: [2; 16],
            command: WireCommand::SetMode { mode: 2 },
        },
    ])
    .map_err(|e| e.to_string())?;
    let request = ClientFrame {
        session: Some(caly_domain::to_hex(token)),
        request: JsonRequest::ExecuteBatch(ExecuteBatchRequest {
            operations,
            stop_on_error: true,
        }),
    };
    write_client_frame(&mut client, &request).await?;
    match read_server_frame(&mut client).await? {
        ServerFrame::Result(boxed) => match *boxed {
            JsonResponse::ExecuteBatch(response) => {
                assert!(response.stopped_early, "stop_on_error must truncate");
                assert_eq!(response.results.len(), 1);
                assert!(matches!(
                    response.results.as_slice(),
                    [ExecuteBatchResult::Rejected { .. }]
                ));
                drop(client);
                task.await.map_err(|error| error.to_string())?;
                Ok(())
            }
            other => Err(format!("unexpected batch response: {other:?}")),
        },
        other @ ServerFrame::Error(_) => Err(format!("expected batch result frame, got {other:?}")),
    }
}
