//! Daemon-side transport adapters for caly.
//!
//! This crate admits authenticated requests, maps protocol commands to
//! application use cases, and maps structured results back to wire responses.
//! It owns no business state and performs no kernel or configuration work.

#![forbid(unsafe_code)]

pub mod compat;
pub mod json;
pub mod tcp;
pub mod uds;
