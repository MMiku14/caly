//! Live kernel connection projection for daemon-mediated flow queries.

/// One active connection with the routing metadata needed by flow UIs.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct LiveConnection {
    /// Kernel connection id (stable across polls for the connection's life).
    pub id: String,
    /// Display host, falling back to the destination IP.
    pub host: String,
    pub destination_port: u16,
    /// `tcp` | `udp`.
    pub network: String,
    /// Sniffed protocol (`http` | `tls` | `quic` | …).
    pub protocol_type: String,
    /// Inbound name (`mixed`, `tun`, …) when the kernel reports it.
    pub inbound_name: String,
    /// Local process path for the owning connection, when reported.
    pub process_path: String,
    /// Matched rule kind (`DomainSuffix`, `MATCH`, …).
    pub rule: String,
    pub rule_payload: String,
    /// Final outbound name/tag the connection is actually dialed through.
    pub outbound: String,
    /// Group chain, innermost last (e.g. `["PROXY", "HK-01"]`).
    pub chain: Vec<String>,
    pub upload_bytes: u64,
    pub download_bytes: u64,
}
