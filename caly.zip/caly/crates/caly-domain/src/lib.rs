//! Pure domain model for caly.
//!
//! This crate contains no async runtime, filesystem, network, process,
//! platform, path, RPC, wall-clock acquisition or random-number generation.
//! Outer owners supply timestamps and generated/hash-derived identities.

#![forbid(unsafe_code)]
#![cfg_attr(test, allow(clippy::unwrap_used, clippy::expect_used, clippy::panic, clippy::todo, clippy::unimplemented, clippy::unreachable))] // #53: tests assert with unwrap/expect/panic (+todo/unreachable in fixtures); production lints stay deny
mod capability;
mod collection;
mod config_mutation;
mod event;
mod identity;
mod live_connection;
mod node;
mod operation;
mod profile;
mod proxy_group;
mod rule;
mod secret;
mod settings;
mod source_view;
mod state;
mod text;
mod tun;
pub mod ports;
pub use ports::*;

pub use capability::{
    Capability, CapabilitySet, CapabilityStatus, ConfiguredSupport, DuplicateCapability,
    RuntimeAvailability,
};
pub use collection::{BoundedExtendError, BoundedPushError, BoundedVec, CapacityError};
pub use config_mutation::{
    ConfigMutation, ConfigResource, MutationOutcome, ProxyGroupMemberRef, ProxyGroupMutation,
    RuleProviderMutation, RuleProviderSourceRef, SubscriptionMutation,
};
pub use event::{
    CursorDisposition, EventCursor, EventSequence, SequenceExhausted, classify_cursor,
};
pub use identity::{
    DaemonInstanceId, IdentityParseError, NodeId, OperationId, SubscriptionId, hex_nibble, to_hex,
};
pub use live_connection::LiveConnection;
pub use node::{
    CongestionControl, Credential, DialableNode, DisplayNode, Endpoint, EndpointHost, HostError,
    NODE_DISPLAY_NAME_MAX_BYTES, NodeBuilder, NodeDisplayName, NodeProtocolLabel, NodeSource,
    NodeTag, NodeTags, NodeValidationError, Protocol, ProtocolText, RealityConfig,
    ShadowsocksCipher, ShadowsocksPlugin, TlsConfig, Transport, TransportText, TransportTextList,
    VmessCipher, WebSocketEarlyData, sanitized_display_name,
};
pub use operation::{
    MAX_OPERATION_LIST, OperationFailure, OperationFailureCode, OperationList, OperationState,
    OperationStatus, OperationStatusError, UnixMillis,
};
pub use profile::{
    MAX_PROFILES, PROFILE_BODY_MAX_BYTES, PROFILE_DESCRIPTION_MAX_BYTES, PROFILE_ID_MAX_BYTES,
    PROFILE_NAME_MAX_BYTES, Profile, ProfileBody, ProfileDescription, ProfileError, ProfileId,
    ProfileName, ProfileSource, is_path_safe_component, validate_id,
};
pub use proxy_group::{
    MAX_PROXY_GROUP_MEMBERS, MAX_PROXY_GROUPS, PROXY_GROUP_NAME_MAX_BYTES,
    PROXY_GROUP_URL_MAX_BYTES, ProxyGroup, ProxyGroupError, ProxyGroupMember, ProxyGroupName,
    ProxyGroupNodeTag, ProxyGroupType, ProxyGroupUrl, UrlTestConfig, ProxyGroupBuilder,
};
pub use rule::{
    GEOSITE_NAME_MAX_BYTES, GeoipCode, GeositeName, INLINE_RULE_PAYLOAD_MAX_BYTES,
    MAX_RULE_PROVIDERS, MAX_RULES, PROCESS_NAME_MAX_BYTES, RULE_PROVIDER_NAME_MAX_BYTES,
    RULE_TEXT_MAX_BYTES, RoutingRule, RuleError, RuleFlags, RuleMatch, RulePolicy, RuleProvider,
    RuleProviderBehavior, RuleProviderFormat, RuleProviderName, RuleProviderSource, RuleText,
    match_host,
};
pub use secret::{SecretError, SecretText};
pub use settings::Controllers;
pub use source_view::SourceView;
pub use state::{
    AppliedState, AppliedStateError, CoreKind, CoreRunState, DesiredState, ObservedState,
    PlatformEffectView, PresentationDelta, PresentationSnapshot, ProxyGroupView, ProxyMode,
    SnapshotNodes, SnapshotRevision, DaemonHealth, HealthState,
};
pub use text::{BoundedText, TextError};
pub use tun::{MAX_TUN_MTU, MIN_TUN_MTU, TunConfig, TunError, TunStack};

/// Canonical crate version synchronized across the workspace.
pub const CALY_WORKSPACE_VERSION: &str = env!("CARGO_PKG_VERSION");

/// Type-safe domain wrapper for network latency in milliseconds.
#[derive(Clone, Copy, Debug, Eq, PartialEq, Ord, PartialOrd, serde::Serialize, serde::Deserialize)]
pub struct LatencyMs(pub u32);

impl LatencyMs {
    pub const ZERO: Self = Self(0);
    pub const TIMEOUT: Self = Self(9999);

    pub fn is_timeout(self) -> bool {
        self.0 >= 9999
    }
}

/// Type-safe domain wrapper for bandwidth in bytes per second.
#[derive(Clone, Copy, Debug, Eq, PartialEq, Ord, PartialOrd, serde::Serialize, serde::Deserialize)]
pub struct BandwidthBps(pub u64);

/// SRE Golden Signals for holistic node/daemon health assessment.
#[derive(Clone, Debug, Eq, PartialEq, serde::Serialize, serde::Deserialize)]
pub struct GoldenSignals {
    pub latency_p50_ms: u32,
    pub latency_p95_ms: u32,
    pub latency_p99_ms: u32,
    pub traffic_in_bps: u64,
    pub traffic_out_bps: u64,
    pub error_rate_per_thousand: u32,
    pub active_connections: u32,
    pub saturation_ratio_percent: u8,
}

pub mod text_ext;
pub use text_ext::CalyStrExt;
