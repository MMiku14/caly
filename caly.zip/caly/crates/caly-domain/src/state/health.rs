//! Daemon health and readiness status model for production observability.
//!
//! Provides structured health reporting aligned with SRE readiness probe specifications.

use crate::{
    AppliedState, BoundedText, CoreKind, CoreRunState, DaemonInstanceId, DesiredState,
    ObservedState, PlatformEffectView,
};

/// Health status category of the daemon or an underlying component.
#[derive(Clone, Debug, Eq, PartialEq, serde::Serialize, serde::Deserialize)]
pub enum HealthState {
    /// Fully functional with all configured services running nominally.
    Healthy,
    /// Operating with degraded capability (e.g., secondary DNS unreachable or high error rate).
    Degraded(BoundedText<256>),
    /// Critical failure preventing proxy operation.
    Unhealthy(BoundedText<256>),
}

impl HealthState {
    /// Returns true if the state is fully Healthy.
    pub fn is_healthy(&self) -> bool {
        matches!(self, Self::Healthy)
    }

    /// Returns true if the state is Degraded.
    pub fn is_degraded(&self) -> bool {
        matches!(self, Self::Degraded(_))
    }

    /// Returns true if the state is Unhealthy.
    pub fn is_unhealthy(&self) -> bool {
        matches!(self, Self::Unhealthy(_))
    }

    /// Returns diagnostic explanation text, if available.
    pub fn reason(&self) -> Option<&str> {
        match self {
            Self::Healthy => None,
            Self::Degraded(reason) | Self::Unhealthy(reason) => Some(reason.as_str()),
        }
    }
}

/// Comprehensive health snapshot for readiness probes, systemd watchdog, and CLI doctor.
#[derive(Clone, Debug, Eq, PartialEq, serde::Serialize, serde::Deserialize)]
pub struct DaemonHealth {
    /// Owning daemon instance identifier.
    pub daemon_id: DaemonInstanceId,
    /// Aggregate health disposition.
    pub status: HealthState,
    /// Running state of the active core kernel.
    pub core_run_state: CoreRunState,
    /// Selected core type (Mihomo or SingBox).
    pub active_core: CoreKind,
    /// Whether system-wide TUN routing is currently active.
    pub tun_active: bool,
    /// Monotonic generation counter of applied state changes.
    pub applied_generation: u64,
}

impl DaemonHealth {
    /// Computes an authoritative health evaluation from current system states.
    pub fn evaluate(
        daemon_id: DaemonInstanceId,
        desired: &DesiredState,
        applied: &AppliedState,
        _observed: &ObservedState,
        platform: &PlatformEffectView,
    ) -> Self {
        let status = match applied.core_state {
            CoreRunState::Running => {
                if desired.tun && !platform.tun {
                    HealthState::Degraded(
                        BoundedText::new("desired TUN state pending or degraded".to_owned())
                            .unwrap_or_default(),
                    )
                } else {
                    HealthState::Healthy
                }
            }
            CoreRunState::Stopped => {
                if desired.mode == crate::ProxyMode::Direct {
                    HealthState::Healthy
                } else {
                    HealthState::Degraded(
                        BoundedText::new("core stopped while non-direct mode requested".to_owned())
                            .unwrap_or_default(),
                    )
                }
            }
            CoreRunState::Starting => HealthState::Degraded(
                BoundedText::new("core is currently initializing".to_owned()).unwrap_or_default(),
            ),
            CoreRunState::Failed => HealthState::Unhealthy(
                BoundedText::new("core process failed or crashed".to_owned()).unwrap_or_default(),
            ),
        };

        Self {
            daemon_id,
            status,
            core_run_state: applied.core_state,
            active_core: applied.active_core,
            tun_active: platform.tun,
            applied_generation: applied.generation,
        }
    }

    /// Whether the daemon is ready to handle network traffic (readiness probe).
    pub fn is_ready(&self) -> bool {
        !self.status.is_unhealthy() && self.core_run_state == CoreRunState::Running
    }

    /// Whether the daemon is alive and not in a terminal failure state (liveness probe).
    pub fn is_live(&self) -> bool {
        self.core_run_state != CoreRunState::Failed
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn health_state_helpers() {
        let h = HealthState::Healthy;
        assert!(h.is_healthy());
        assert!(!h.is_degraded());
        assert!(!h.is_unhealthy());
        assert_eq!(h.reason(), None);

        let d = HealthState::Degraded(BoundedText::new("latency high".to_owned()).unwrap());
        assert!(!d.is_healthy());
        assert!(d.is_degraded());
        assert_eq!(d.reason(), Some("latency high"));

        let u = HealthState::Unhealthy(BoundedText::new("kernel died".to_owned()).unwrap());
        assert!(u.is_unhealthy());
        assert_eq!(u.reason(), Some("kernel died"));
    }
}
