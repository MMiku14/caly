//! Compile-time typestate pattern for proxy core lifecycle management.
//!
//! Enforces at compile-time that invalid runtime transitions are unrepresentable.
//! Reference: Rust API Guidelines (C-TYPEMACRO / Typestate).

use core::marker::PhantomData;
use std::time::Duration;
use crate::{CoreKind, NodeId};

/// Marker trait representing a valid lifecycle state.
pub trait CoreState: private::Sealed {}

/// Unstarted / stopped state.
#[derive(Debug)]
pub struct Stopped;
/// Starting / initializing state.
#[derive(Debug)]
pub struct Starting;
/// Actively running state.
#[derive(Debug)]
pub struct Running;
/// Crashed / terminal failed state.
#[derive(Debug)]
pub struct Failed {
    pub reason: String,
}

mod private {
    pub trait Sealed {}
    impl Sealed for super::Stopped {}
    impl Sealed for super::Starting {}
    impl Sealed for super::Running {}
    impl Sealed for super::Failed {}
}

impl CoreState for Stopped {}
impl CoreState for Starting {}
impl CoreState for Running {}
impl CoreState for Failed {}

/// Typestate-managed proxy kernel instance.
#[derive(Debug)]
pub struct TypedKernel<S: CoreState> {
    kind: CoreKind,
    active_node: Option<NodeId>,
    generation: u64,
    _state: PhantomData<S>,
}

impl TypedKernel<Stopped> {
    /// Creates a new stopped kernel handle.
    pub const fn new(kind: CoreKind) -> Self {
        Self {
            kind,
            active_node: None,
            generation: 1,
            _state: PhantomData,
        }
    }

    /// Transitions from Stopped to Starting.
    pub fn begin_start(self) -> TypedKernel<Starting> {
        TypedKernel {
            kind: self.kind,
            active_node: self.active_node,
            generation: self.generation.saturating_add(1),
            _state: PhantomData,
        }
    }
}

impl TypedKernel<Starting> {
    /// Transitions from Starting to Running once readiness probe succeeds.
    pub fn mark_ready(self, initial_node: Option<NodeId>) -> TypedKernel<Running> {
        TypedKernel {
            kind: self.kind,
            active_node: initial_node,
            generation: self.generation,
            _state: PhantomData,
        }
    }

    /// Transitions from Starting to Failed if verification times out.
    pub fn mark_failed(self, reason: impl Into<String>) -> TypedKernel<Failed> {
        TypedKernel {
            kind: self.kind,
            active_node: None,
            generation: self.generation,
            _state: PhantomData,
        }
    }
}

impl TypedKernel<Running> {
    /// Updates the active selected proxy node during live operation.
    pub fn switch_node(&mut self, node: NodeId) {
        self.active_node = Some(node);
    }

    /// Stops the running kernel gracefully.
    pub fn stop(self) -> TypedKernel<Stopped> {
        TypedKernel {
            kind: self.kind,
            active_node: None,
            generation: self.generation.saturating_add(1),
            _state: PhantomData,
        }
    }

    /// Records unexpected crash.
    pub fn record_crash(self, reason: impl Into<String>) -> TypedKernel<Failed> {
        TypedKernel {
            kind: self.kind,
            active_node: None,
            generation: self.generation,
            _state: PhantomData,
        }
    }
}

impl TypedKernel<Failed> {
    /// Recovers a failed kernel back to Stopped state.
    pub fn recover(self) -> TypedKernel<Stopped> {
        TypedKernel {
            kind: self.kind,
            active_node: None,
            generation: self.generation.saturating_add(1),
            _state: PhantomData,
        }
    }
}
