//! Credential-free presentation deltas shared by Application and clients.

use super::{AppliedState, DesiredState, ObservedState, PlatformEffectView, SnapshotNodes};
use crate::CapabilitySet;

/// One complete replacement of a presentation-state slice.
#[derive(Clone, Debug, Eq, PartialEq)]
pub enum PresentationDelta {
    DesiredReplaced(DesiredState),
    AppliedReplaced(AppliedState),
    ObservedReplaced(ObservedState),
    PlatformReplaced(PlatformEffectView),
    CapabilitiesReplaced(CapabilitySet),
    NodesReplaced(SnapshotNodes),
}
