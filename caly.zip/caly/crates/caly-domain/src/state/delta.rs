//! Credential-free presentation deltas shared by Application and clients.

use super::presentation::ProxyGroupView;
use super::{AppliedState, DesiredState, ObservedState, PlatformEffectView, SnapshotNodes};
use crate::{CapabilitySet, MutationOutcome, SourceView};

/// One complete replacement of a presentation-state slice.
#[derive(Clone, Debug, Eq, PartialEq)]
pub enum PresentationDelta {
    DesiredReplaced(DesiredState),
    AppliedReplaced(AppliedState),
    ObservedReplaced(ObservedState),
    PlatformReplaced(PlatformEffectView),
    CapabilitiesReplaced(CapabilitySet),
    NodesReplaced(SnapshotNodes),
    /// W3b enrichment: the proxy-group slice (kind/members/selection),
    /// published at boot from the declared config and refreshed after
    /// every group-selection command.
    GroupsReplaced(Vec<ProxyGroupView>),
    /// Config-mutation outcome (CLI sinking, 2026-08-14). The outcome is
    /// informational for watch clients; it does not replace a projection
    /// slice by itself — the source-listing publisher follows the bus event
    /// with a `SourcesReplaced` delta when the declaration changes.
    ConfigMutated(MutationOutcome),
    /// Declared subscription-source listing (CLI sinking, 2026-08-14,
    /// read path), replacing the whole source slice.
    SourcesReplaced(Vec<SourceView>),
}
