mod health;
//! Pure views for the five distinct state meanings.

mod applied;
mod delta;
mod desired;
mod observed;
mod platform;
mod presentation;

pub use applied::{AppliedState, AppliedStateError, CoreKind, CoreRunState};
pub use delta::PresentationDelta;
pub use desired::{DesiredState, ProxyMode};
pub use observed::ObservedState;
pub use platform::PlatformEffectView;
pub use presentation::{PresentationSnapshot, ProxyGroupView, SnapshotNodes, SnapshotRevision};
pub use health::{DaemonHealth, HealthState};

/// Persistent record for traffic statistics history across daemon restarts.
#[derive(Clone, Debug, Eq, PartialEq, serde::Serialize, serde::Deserialize)]
pub struct TrafficSnapshotRecord {
    pub timestamp_unix: u64,
    pub upload_bytes_total: u64,
    pub download_bytes_total: u64,
    pub active_connections: u32,
}

pub mod typestate;
pub use typestate::*;
