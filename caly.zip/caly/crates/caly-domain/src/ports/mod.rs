//! Re-export facade: caly-ports has been consolidated into caly-domain::ports.
//! All port traits and types are re-exported here for zero-breakage backward compatibility.

#![forbid(unsafe_code)]
#![cfg_attr(test, allow(clippy::unwrap_used, clippy::expect_used, clippy::panic, clippy::todo, clippy::unimplemented, clippy::unreachable))]

pub use crate::ports::*;
