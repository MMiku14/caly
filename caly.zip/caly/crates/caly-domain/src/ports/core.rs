//! CoreActor command port: proxy selection and connection close.

use crate::{AppliedState, NodeId, ObservedState};

use super::error::ActorFailure;

/// Nonblocking CoreActor backend; process/API I/O belongs to its owned worker.
pub trait CoreCommandBackend {
    fn select_proxy(&mut self, node: NodeId) -> Result<AppliedState, ActorFailure>;
    /// W4 (`node pick`): select a named member inside a named proxy
    /// group. Implementations resolve kernel-side member tags (Mihomo
    /// display names vs sing-box `proxy-<hex>` tags); a kernel without
    /// group selection returns an `Unsupported` failure.
    fn select_proxy_group(
        &mut self,
        group: &str,
        member: &str,
    ) -> Result<AppliedState, ActorFailure>;
    fn close_all_connections(&mut self) -> Result<ObservedState, ActorFailure>;
    /// Closes one active connection by kernel connection id.
    fn close_connection(&mut self, id: &str) -> Result<ObservedState, ActorFailure>;
    /// Applies a routing mode to the running core and returns the new applied state.
    fn set_mode(&mut self, mode: crate::ProxyMode) -> Result<AppliedState, ActorFailure>;
    /// W3b: the kernel's proxy groups — kind, kernel-side membership
    /// (`all`), and the current selection (`now`). Implementations must
    /// forward to their controller; there is deliberately no empty-slice
    /// default because a missing forwarder would silently report "no groups"
    /// while the kernel has groups.
    fn list_proxy_groups(
        &mut self,
        timeout: std::time::Duration,
    ) -> Result<Vec<crate::ProxyGroupView>, ActorFailure>;
}
