//! Idiomatic extension traits for ergonomic, zero-allocation parsing and sanitization.

/// Extension trait on `str` slices for high-performance proxy protocol operations.
pub trait CalyStrExt {
    /// Whether the slice starts with `prefix` ignoring ASCII case (zero-allocation).
    fn starts_with_ignore_case(&self, prefix: &str) -> bool;
    /// Strips leading `#` or `;` comments and trims surrounding whitespace.
    fn strip_proxy_comment(&self) -> &str;
    /// Splits host and port without heap allocation.
    fn split_host_port(&self) -> Option<(&str, u16)>;
}

impl CalyStrExt for str {
    #[inline]
    fn starts_with_ignore_case(&self, prefix: &str) -> bool {
        self.len() >= prefix.len() && self[..prefix.len()].eq_ignore_ascii_case(prefix)
    }

    #[inline]
    fn strip_proxy_comment(&self) -> &str {
        let trimmed = self.trim();
        if trimmed.starts_with('#') || trimmed.starts_with(';') {
            ""
        } else {
            trimmed
        }
    }

    #[inline]
    fn split_host_port(&self) -> Option<(&str, u16)> {
        let (host, port_str) = self.rsplit_once(':')?;
        let port = port_str.parse::<u16>().ok()?;
        Some((host, port))
    }
}
