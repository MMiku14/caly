//! Node types split by dialable and display responsibilities.

mod canonical;
mod dialable;
mod display;
mod endpoint;
mod protocol;
mod source;
mod transport;
mod validation;

pub use dialable::{DialableNode, NodeBuilder, NodeTag, NodeTags};
pub use display::{
    DisplayNode, NODE_DISPLAY_NAME_MAX_BYTES, NodeDisplayName, NodeProtocolLabel,
    sanitized_display_name,
};
pub use endpoint::{Endpoint, EndpointHost, HostError};
pub use protocol::{
    CongestionControl, Credential, Protocol, ProtocolText, ShadowsocksCipher, ShadowsocksPlugin,
    VmessCipher,
};
pub use source::NodeSource;
pub use transport::{
    RealityConfig, TlsConfig, Transport, TransportText, TransportTextList, WebSocketEarlyData,
};
pub use validation::NodeValidationError;

/// Compact, zero-cost capability bitflags and metadata tags for proxy nodes.
#[derive(Clone, Copy, Debug, Eq, PartialEq, Default, serde::Serialize, serde::Deserialize)]
pub struct NodeCapabilityFlags {
    pub is_tls: bool,
    pub is_reality: bool,
    pub is_insecure: bool,
    pub has_utls: bool,
    pub is_udp: bool,
    pub has_vision: bool,
    pub transport_kind: u8, // 0=Tcp, 1=Ws, 2=Grpc, 3=H2, 4=Quic
}

impl NodeCapabilityFlags {
    /// Renders badges as static string slices without heap allocations.
    pub fn badge_labels(&self) -> Vec<&'static str> {
        let mut badges = Vec::with_capacity(6);
        if self.is_reality {
            badges.push("Reality");
        } else if self.is_tls {
            badges.push("TLS");
        }
        if self.has_vision {
            badges.push("Vision");
        }
        if self.has_utls {
            badges.push("uTLS");
        }
        match self.transport_kind {
            1 => badges.push("WS"),
            2 => badges.push("gRPC"),
            3 => badges.push("H2"),
            4 => badges.push("QUIC"),
            _ => {}
        }
        if self.is_insecure {
            badges.push("Insecure");
        }
        if self.is_udp {
            badges.push("UDP");
        }
        badges
    }
}
