//! Pluggable transport and TLS identity values.

use crate::{BoundedText, BoundedVec, SecretText};

/// Maximum path/service/host-label text length.
pub const TRANSPORT_TEXT_MAX_BYTES: usize = 1_024;
/// Maximum H2 hosts or ALPN entries.
pub const MAX_TRANSPORT_LABELS: usize = 16;
/// Maximum Reality key/short-id secret length.
pub const REALITY_SECRET_MAX_BYTES: usize = 512;

/// Validated transport text.
pub type TransportText = BoundedText<TRANSPORT_TEXT_MAX_BYTES>;
/// Bounded transport text list.
pub type TransportTextList = BoundedVec<TransportText, MAX_TRANSPORT_LABELS>;

/// Wire transport used by protocols that support pluggable framing.
#[derive(Clone, Debug, Eq, PartialEq)]
pub enum Transport {
    /// Plain TCP framing.
    Tcp,
    /// WebSocket framing.
    WebSocket {
        path: TransportText,
        host: Option<TransportText>,
    },
    /// gRPC framing.
    Grpc { service_name: TransportText },
    /// HTTP/2 framing.
    Http2 {
        path: TransportText,
        hosts: TransportTextList,
    },
    /// QUIC framing.
    Quic,
}

/// TLS and Reality settings that affect dialing identity.
#[derive(Debug)]
pub struct TlsConfig {
    sni: Option<TransportText>,
    alpn: TransportTextList,
    allow_insecure: bool,
    fingerprint: Option<TransportText>,
    reality: Option<RealityConfig>,
}

impl TlsConfig {
    /// Constructs complete TLS settings.
    pub const fn new(
        sni: Option<TransportText>,
        alpn: TransportTextList,
        allow_insecure: bool,
        fingerprint: Option<TransportText>,
        reality: Option<RealityConfig>,
    ) -> Self {
        Self {
            sni,
            alpn,
            allow_insecure,
            fingerprint,
            reality,
        }
    }

    /// Returns the TLS server-name indicator, if configured.
    pub const fn sni(&self) -> Option<&TransportText> {
        self.sni.as_ref()
    }
    /// Returns the ALPN label list.
    pub const fn alpn(&self) -> &TransportTextList {
        &self.alpn
    }
    /// Returns whether certificate verification is skipped.
    pub const fn allow_insecure(&self) -> bool {
        self.allow_insecure
    }
    /// Returns the TLS client-fingerprint label.
    pub const fn fingerprint(&self) -> Option<&TransportText> {
        self.fingerprint.as_ref()
    }
    /// Returns the Reality handshake identity, when in Reality mode.
    pub const fn reality(&self) -> Option<&RealityConfig> {
        self.reality.as_ref()
    }
}

/// Reality handshake identity.
#[derive(Debug)]
pub struct RealityConfig {
    public_key: SecretText<REALITY_SECRET_MAX_BYTES>,
    /// Reality short id is optional; many subscriptions omit it.
    short_id: Option<SecretText<REALITY_SECRET_MAX_BYTES>>,
    spider_x: Option<TransportText>,
}

impl RealityConfig {
    /// Constructs Reality settings without exposing key material.
    pub const fn new(
        public_key: SecretText<REALITY_SECRET_MAX_BYTES>,
        short_id: Option<SecretText<REALITY_SECRET_MAX_BYTES>>,
        spider_x: Option<TransportText>,
    ) -> Self {
        Self {
            public_key,
            short_id,
            spider_x,
        }
    }

    /// Returns the Reality public key (secret; expose only via `with_exposed`).
    pub const fn public_key(&self) -> &SecretText<REALITY_SECRET_MAX_BYTES> {
        &self.public_key
    }
    /// Returns the optional Reality short id (secret; expose only via `with_exposed`).
    pub const fn short_id(&self) -> Option<&SecretText<REALITY_SECRET_MAX_BYTES>> {
        self.short_id.as_ref()
    }
    /// Returns the Reality spider X (optional).
    pub const fn spider_x(&self) -> Option<&TransportText> {
        self.spider_x.as_ref()
    }
}
