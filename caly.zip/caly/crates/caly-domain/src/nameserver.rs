//! Bounded, validated DNS server and fake-ip range values.

use crate::BoundedText;

/// Maximum bytes in one nameserver textual representation.
pub const DNS_TEXT_MAX_BYTES: usize = 256;
/// Maximum bytes in a fake-ip CIDR range.
pub const FAKE_IP_RANGE_MAX_BYTES: usize = 64;

/// A validated upstream nameserver (IP literal or hostname, optional port).
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct Nameserver(BoundedText<DNS_TEXT_MAX_BYTES>);

/// Validation failure for a single nameserver value.
#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub enum NameserverError {
    Empty,
    TooLong,
    InvalidCharacter,
}

impl core::fmt::Display for NameserverError {
    fn fmt(&self, formatter: &mut core::fmt::Formatter<'_>) -> core::fmt::Result {
        match self {
            Self::Empty => formatter.write_str("nameserver must not be empty"),
            Self::TooLong => write!(formatter, "nameserver exceeds {DNS_TEXT_MAX_BYTES} bytes"),
            Self::InvalidCharacter => formatter
                .write_str("nameserver contains characters outside the allowed host/scheme set"),
        }
    }
}

impl std::error::Error for NameserverError {}

impl Nameserver {
    /// Validates ASCII host/IP/port syntax.
    pub fn new(value: impl Into<String>) -> Result<Self, NameserverError> {
        let value = value.into();
        if value.is_empty() {
            return Err(NameserverError::Empty);
        }
        if value.len() > DNS_TEXT_MAX_BYTES {
            return Err(NameserverError::TooLong);
        }
        if !value.bytes().all(is_nameserver_byte) {
            return Err(NameserverError::InvalidCharacter);
        }
        Ok(Self(
            BoundedText::new(value).map_err(|_| NameserverError::TooLong)?,
        ))
    }

    /// Borrows the validated textual representation.
    pub fn as_str(&self) -> &str {
        self.0.as_str()
    }
}

/// Accepts digits, letters, dot, colon, brackets, hyphen and URL scheme glyphs.
fn is_nameserver_byte(byte: u8) -> bool {
    byte.is_ascii_alphanumeric()
        || matches!(
            byte,
            b'.' | b':' | b'[' | b']' | b'-' | b'/' | b'?' | b'=' | b'_'
        )
}

/// A validated fake-ip CIDR range, e.g. `198.18.0.1/16`.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct FakeIpRange(BoundedText<FAKE_IP_RANGE_MAX_BYTES>);

/// Validation failure for a fake-ip range.
#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub enum FakeIpRangeError {
    Empty,
    TooLong,
    InvalidSyntax,
}

impl core::fmt::Display for FakeIpRangeError {
    fn fmt(&self, formatter: &mut core::fmt::Formatter<'_>) -> core::fmt::Result {
        match self {
            Self::Empty => formatter.write_str("fake-ip range must not be empty"),
            Self::TooLong => write!(
                formatter,
                "fake-ip range exceeds {FAKE_IP_RANGE_MAX_BYTES} bytes"
            ),
            Self::InvalidSyntax => formatter.write_str("fake-ip range must look like a CIDR range"),
        }
    }
}

impl std::error::Error for FakeIpRangeError {}

impl FakeIpRange {
    /// Accepts values matching an IPv4/IPv6 CIDR (`a.b.c.d/len` or `[v6]/len`).
    pub fn new(value: impl Into<String>) -> Result<Self, FakeIpRangeError> {
        let value = value.into();
        if value.is_empty() {
            return Err(FakeIpRangeError::Empty);
        }
        if value.len() > FAKE_IP_RANGE_MAX_BYTES {
            return Err(FakeIpRangeError::TooLong);
        }
        let slash = value.rfind('/').ok_or(FakeIpRangeError::InvalidSyntax)?;
        let (address, prefix) = value.split_at(slash);
        if address.is_empty()
            || prefix.len() == 1
            || !prefix[1..].bytes().all(|byte| byte.is_ascii_digit())
        {
            return Err(FakeIpRangeError::InvalidSyntax);
        }
        if !address.bytes().all(is_range_byte) {
            return Err(FakeIpRangeError::InvalidSyntax);
        }
        Ok(Self(
            BoundedText::new(value).map_err(|_| FakeIpRangeError::TooLong)?,
        ))
    }

    /// Borrows the validated CIDR range.
    pub fn as_str(&self) -> &str {
        self.0.as_str()
    }
}

/// Accepts IP/address glyphs and brackets used in a CIDR address component.
fn is_range_byte(byte: u8) -> bool {
    byte.is_ascii_alphanumeric() || matches!(byte, b'.' | b':' | b'[' | b']' | b'-')
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn nameserver_rejects_whitespace() {
        assert_eq!(
            Nameserver::new("8.8.8.8 53"),
            Err(NameserverError::InvalidCharacter)
        );
        assert_eq!(Nameserver::new(""), Err(NameserverError::Empty));
    }

    #[test]
    fn nameserver_accepts_schemes() -> Result<(), NameserverError> {
        let server = Nameserver::new("tls://dns.google")?;
        assert_eq!(server.as_str(), "tls://dns.google");
        Ok(())
    }

    #[test]
    fn fake_ip_range_rejects_bad_syntax() {
        assert_eq!(
            FakeIpRange::new("198.18.0.1"),
            Err(FakeIpRangeError::InvalidSyntax)
        );
        assert_eq!(
            FakeIpRange::new("198.18.0.1/x"),
            Err(FakeIpRangeError::InvalidSyntax)
        );
    }
}
