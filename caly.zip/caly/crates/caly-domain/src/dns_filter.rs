//! DNS filter values: fake-ip bypass patterns and the anti-poisoning
//! fallback filter. Pure bounded value types; rendering is infrastructure.

use crate::BoundedVec;
use crate::rule::GeoipCode;
use crate::text::BoundedText;

/// Maximum entries in one DNS filter list (fake-ip-filter, fallback-filter).
pub const MAX_DNS_FILTER_ENTRIES: usize = 256;
/// Maximum bytes in one DNS filter pattern (`+.example.com`, `*.wild`, ...).
pub const DNS_PATTERN_MAX_BYTES: usize = 256;
/// Maximum bytes in the DNS listener socket-address text.
pub const DNS_LISTEN_MAX_BYTES: usize = 64;

/// One DNS filter pattern (fake-ip bypass or fallback-filter domain entry).
pub type DnsPattern = BoundedText<DNS_PATTERN_MAX_BYTES>;

/// DNS filter pattern validation failure.
#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub enum DnsFilterError {
    Empty,
    TooLong,
    TooManyEntries,
    InvalidGeoipCode,
}

impl core::fmt::Display for DnsFilterError {
    fn fmt(&self, formatter: &mut core::fmt::Formatter<'_>) -> core::fmt::Result {
        match self {
            Self::Empty => formatter.write_str("DNS filter pattern must not be empty"),
            Self::TooLong => formatter.write_str("DNS filter pattern is too long"),
            Self::TooManyEntries => formatter.write_str("DNS filter list has too many entries"),
            Self::InvalidGeoipCode => formatter.write_str("fallback-filter geoip code is invalid"),
        }
    }
}

/// Anti-poisoning fallback filter (Mihomo `fallback-filter`). Decides when a
/// `nameserver` answer is treated as poisoned and the `fallback` answer wins:
/// GeoIP mismatch, answers inside suspicious CIDRs, or forced domains.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct FallbackFilter {
    geoip: bool,
    geoip_code: Option<GeoipCode>,
    ipcidr: BoundedVec<DnsPattern, MAX_DNS_FILTER_ENTRIES>,
    domain: BoundedVec<DnsPattern, MAX_DNS_FILTER_ENTRIES>,
}

impl FallbackFilter {
    /// Builds a validated filter; patterns must be non-empty and bounded.
    pub fn new(
        geoip: bool,
        geoip_code: Option<String>,
        ipcidr: Vec<String>,
        domain: Vec<String>,
    ) -> Result<Self, DnsFilterError> {
        let geoip_code = match geoip_code {
            Some(value) => {
                Some(GeoipCode::new(value).map_err(|_| DnsFilterError::InvalidGeoipCode)?)
            }
            None => None,
        };
        Ok(Self {
            geoip,
            geoip_code,
            ipcidr: patterns_from(&ipcidr)?,
            domain: patterns_from(&domain)?,
        })
    }

    /// Whether GeoIP checks decide poisoning.
    pub const fn geoip(&self) -> bool {
        self.geoip
    }

    /// The expected GeoIP country code for non-poisoned answers.
    pub fn geoip_code(&self) -> Option<&GeoipCode> {
        self.geoip_code.as_ref()
    }

    /// CIDRs whose answers are treated as poisoned.
    pub const fn ipcidr(&self) -> &BoundedVec<DnsPattern, MAX_DNS_FILTER_ENTRIES> {
        &self.ipcidr
    }

    /// Domains forced through the fallback resolvers.
    pub const fn domain(&self) -> &BoundedVec<DnsPattern, MAX_DNS_FILTER_ENTRIES> {
        &self.domain
    }
}

/// Builds one bounded pattern list, rejecting empty/oversized/over-capacity
/// entries.
pub(crate) fn patterns_from(
    values: &[String],
) -> Result<BoundedVec<DnsPattern, MAX_DNS_FILTER_ENTRIES>, DnsFilterError> {
    let mut list = BoundedVec::new();
    for value in values {
        if value.is_empty() {
            return Err(DnsFilterError::Empty);
        }
        let pattern = DnsPattern::new(value.clone()).map_err(|_| DnsFilterError::TooLong)?;
        list.try_push(pattern)
            .map_err(|_| DnsFilterError::TooManyEntries)?;
    }
    Ok(list)
}
