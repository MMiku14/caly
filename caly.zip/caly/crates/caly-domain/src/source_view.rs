//! Declared subscription-source listing view (CLI sinking, 2026-08-14,
//! read path): the daemon projects a redacted view of `subscriptions`
//! (legacy scalar + `sources`) so `sub list` renders from the daemon
//! snapshot instead of reading config.yaml + cache files directly — the
//! same view future TUI/WebUI clients render.

use serde::{Deserialize, Serialize};

/// One declared subscription source, with the offline-cache-derived
/// counts and cadence the `sub list` table shows.
#[derive(Clone, Debug, Eq, PartialEq, Deserialize, Serialize)]
pub struct SourceView {
    /// 1-based add-order id shown in `sub list`'s ID column (the legacy
    /// scalar `subscriptions.url` counts as id 1 when present).
    pub index: usize,
    /// Display name (`--name`) or the `#N` fallback.
    pub name: String,
    /// Row kind: `"subscription"`.
    pub kind: String,
    /// The stored source URL (`http(s)://` or `file://`).
    pub url: String,
    /// Whether the source is fetched on refresh.
    pub enabled: bool,
    /// Number of parsed nodes in the cached body (0 when never cached).
    pub nodes: usize,
    /// Proxy-group names the cached body declares.
    pub groups: Vec<String>,
    /// Last successful refresh (cache mtime, unix seconds).
    pub last_refresh_unix: Option<u64>,
    /// Next scheduled refresh (`last_refresh + cadence`), unix seconds.
    pub next_refresh_unix: Option<u64>,
    /// A cached body exists (an enabled source without one is "stale").
    pub cached: bool,
}
