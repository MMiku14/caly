//! Config-mutation intents (CLI sinking, 2026-08-14).
//!
//! One CRUD intent per managed resource, carried from the wire
//! (`caly-protocol`) through the command bus (`caly-application`) to the
//! config-mutation actor, whose backend writes `config.yaml` through the
//! shared `caly-configstore` pipeline. Placing the payloads here lets every
//! layer share one serde shape instead of maintaining parallel enums.

use serde::{Deserialize, Serialize};

/// The managed config resource a mutation targets.
#[derive(Clone, Copy, Debug, Eq, PartialEq, Deserialize, Serialize)]
pub enum ConfigResource {
    /// `subscriptions.sources` (`set sub …`).
    Subscription,
    /// `proxy_groups:` (`set proxy-group …`).
    ProxyGroup,
    /// `rule_providers:` (`set rule-provider …`).
    RuleProvider,
}

/// One `set sub` CRUD intent.
#[derive(Clone, Debug, Eq, PartialEq, Deserialize, Serialize)]
pub enum SubscriptionMutation {
    /// `sub add <token> [--name N] [--every M] [--apply]`. `token` is the
    /// raw `http(s)://` URL or local-path argument; normalization happens
    /// daemon-side (single implementation).
    Add {
        token: String,
        name: Option<String>,
        refresh_every_minutes: Option<u64>,
    },
    /// `sub remove <name-or-url> [--purge] [--apply]`.
    Remove { target: String, purge: bool },
    /// `sub set <name-or-url> [--url U] [--name N] [--every M] [--apply]`.
    /// In-place edit of a declared source; every field is optional and
    /// only the supplied ones change.
    Set {
        target: String,
        url: Option<String>,
        name: Option<String>,
        refresh_every_minutes: Option<u64>,
    },
    /// `sub enable <name-or-url> [--apply]`.
    Enable { target: String },
    /// `sub disable <name-or-url> [--apply]`.
    Disable { target: String },
}

/// One `set proxy-group` CRUD intent. The payload mirrors the CLI grammar
/// (`cli::SetProxyGroupCmd`) so the wire shape is exactly what the operator
/// typed; the daemon-side writer maps it onto the schema types.
#[derive(Clone, Debug, Eq, PartialEq, Deserialize, Serialize)]
pub enum ProxyGroupMutation {
    /// `set proxy-group add <name> <type> [members…] [--url U]
    /// [--interval S] [--tolerance MS] [--apply]`.
    Add {
        name: String,
        /// One of `select` / `url-test` / `fallback` / `load-balance` /
        /// `relay`.
        kind: String,
        members: Vec<ProxyGroupMemberRef>,
        /// Probe URL; required for probe-driven kinds, rejected otherwise.
        url: Option<String>,
        /// Probe cadence in seconds; defaults to 300.
        interval_seconds: Option<u32>,
        /// Probe tolerance in milliseconds; defaults to 50.
        tolerance_ms: Option<u32>,
    },
    /// `set proxy-group remove <name> [--apply]`.
    Remove { name: String },
    /// `set proxy-group enable <name> [--apply]`.
    Enable { name: String },
    /// `set proxy-group disable <name> [--apply]`.
    Disable { name: String },
}

/// One `members:` entry of a declared proxy group, in the CLI's `kind:…`
/// spelling.
#[derive(Clone, Debug, Eq, PartialEq, Deserialize, Serialize)]
pub enum ProxyGroupMemberRef {
    /// `node:<tag>` — a node entry by tag.
    Node(String),
    /// `group:<name>` — another declared group by name.
    Group(String),
    /// `direct` — the DIRECT outbound.
    Direct,
    /// `reject` — the REJECT outbound.
    Reject,
}

/// One `set rule-provider` CRUD intent.
#[derive(Clone, Debug, Eq, PartialEq, Deserialize, Serialize)]
pub enum RuleProviderMutation {
    /// `set rule-provider add <name> <http|file|inline> … [--behavior B]
    /// [--apply]`.
    Add {
        name: String,
        source: RuleProviderSourceRef,
        /// One of `domain` / `domain-suffix` / `ip-cidr` / `classical`;
        /// defaults to `domain` when absent.
        behavior: Option<String>,
    },
    /// `set rule-provider remove <name> [--apply]`.
    Remove { name: String },
    /// `set rule-provider enable <name> [--apply]`.
    Enable { name: String },
    /// `set rule-provider disable <name> [--apply]`.
    Disable { name: String },
}

/// The remote/local source of a rule provider, mirroring
/// `cli::RuleProviderSourceSpec`.
#[derive(Clone, Debug, Eq, PartialEq, Deserialize, Serialize)]
pub enum RuleProviderSourceRef {
    /// `http <url> [--interval MS]`.
    Http { url: String, interval_ms: u64 },
    /// `file <path>`.
    File { path: String },
    /// `inline --payload <body>`.
    Inline { payload: String },
}

/// One generic config-mutation intent, discriminated by resource.
#[derive(Clone, Debug, Eq, PartialEq, Deserialize, Serialize)]
pub enum ConfigMutation {
    /// `set sub …`.
    Subscription(SubscriptionMutation),
    /// `set proxy-group …`.
    ProxyGroup(ProxyGroupMutation),
    /// `set rule-provider …`.
    RuleProvider(RuleProviderMutation),
}

impl ConfigMutation {
    /// The resource this mutation targets.
    pub const fn resource(&self) -> ConfigResource {
        match self {
            Self::Subscription(_) => ConfigResource::Subscription,
            Self::ProxyGroup(_) => ConfigResource::ProxyGroup,
            Self::RuleProvider(_) => ConfigResource::RuleProvider,
        }
    }
}

/// Outcome of a config mutation: the dry-run preview or the applied
/// summary (wire-shaped, so the CLI renders it without re-reading the
/// file).
#[derive(Clone, Debug, Eq, PartialEq, Deserialize, Serialize)]
pub struct MutationOutcome {
    /// The resource the mutation targeted (drives watch re-renders).
    pub resource: ConfigResource,
    /// Post-mutation declared count of the resource (preview or applied):
    /// sources for subscriptions, groups for proxy groups, providers for
    /// rule providers.
    pub count: usize,
    /// The mutated entry's addressable id (name or URL), when meaningful.
    pub url: Option<String>,
    /// True when the write actually happened (false = dry-run preview).
    pub applied: bool,
    /// True when the mutation was a no-op (idempotent call, no write).
    pub unchanged: bool,
}
