use caly_io::{Monotonic, Timestamp};

use crate::fault::{FaultInjector, FaultKind, FaultSpec, SharedFaults, EFFECT_STEP_LABEL};

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct VirtualClock {
    pub wall_clock_unix_ms: i64,
    pub monotonic_ms: u64,
}

impl VirtualClock {
    pub fn new(wall_clock_unix_ms: i64) -> Self {
        Self {
            wall_clock_unix_ms,
            monotonic_ms: 0,
        }
    }

    pub fn now(&self) -> Timestamp {
        Timestamp {
            unix_millis: self.wall_clock_unix_ms,
        }
    }

    pub fn mono(&self) -> Monotonic {
        Monotonic {
            ticks_millis: self.monotonic_ms,
        }
    }

    pub fn advance_ms(&mut self, millis: u64) {
        self.monotonic_ms = self.monotonic_ms.saturating_add(millis);
        // `millis as i64` wraps to a negative value above i64::MAX, which would move the
        // wall clock *backwards* while the monotonic clock moved forwards. A virtual clock
        // that can go back in time breaks every deadline and timeout the simulation is meant
        // to exercise, so clamp instead of casting.
        let delta = i64::try_from(millis).unwrap_or(i64::MAX);
        self.wall_clock_unix_ms = self.wall_clock_unix_ms.saturating_add(delta);
    }
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct MemFile {
    pub path: String,
    pub bytes: Vec<u8>,
    /// The virtual time of the last write, or `None` when this world has no clock.
    ///
    /// Mirrors `caly_io::Meta::modified_at_unix_ms`. The value comes from the injected
    /// `VirtualClock` and never from the host, because `ADR-022` makes this simulator the release
    /// gate: a wall clock read here would make grace-period and timeout behaviour unreproducible.
    pub modified_at_unix_ms: Option<i64>,
}

/// The simulated disk: a flat file list plus the set of directories that were created.
///
/// The directory set is not decoration. `Fs::list` must answer "empty" and "not there"
/// differently (`ADR-035 §2.1`), and with a purely flat file list those two cases are
/// indistinguishable — every absent directory would look empty, which is how a sweep would report
/// "nothing to do" about a path nobody ever created. A real `StdFs` gets this for free from the
/// host; here it is recorded when a write creates a path, which is the only way a directory comes
/// to exist through the port at all.
#[derive(Clone, Debug, Default, Eq, PartialEq)]
pub struct MemFs {
    pub files: Vec<MemFile>,
    pub dirs: std::collections::BTreeSet<String>,
}

impl MemFs {
    pub fn put(&mut self, path: impl Into<String>, bytes: Vec<u8>) {
        let path = path.into();
        self.remember_dirs(&path);
        self.files.push(MemFile {
            path,
            bytes,
            modified_at_unix_ms: None,
        });
    }

    pub fn contains_dir(&self, dir: &str) -> bool {
        self.dirs.contains(dir)
    }

    pub fn is_dir_path(&self, path: &str) -> bool {
        self.contains_dir(path)
    }

    /// Record every ancestor of `path`, as `StdFs::ensure_parent` would create them.
    pub fn remember_dirs(&mut self, path: &str) {
        let mut parts: Vec<&str> = path.split('/').collect();
        if parts.last() == Some(&"") {
            parts.pop();
        }
        // Drop the file name; what is left are the directories, each nested in the previous.
        if parts.len() > 1 {
            parts.pop();
        } else if parts.len() == 1 {
            // A bare name (`"payload"`) creates no directory of its own.
            parts.clear();
        }
        let mut prefix = String::new();
        for part in parts {
            if !prefix.is_empty() {
                prefix.push('/');
            }
            prefix.push_str(part);
            self.dirs.insert(prefix.clone());
        }
    }
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct ScriptedResponse {
    pub url: String,
    pub status: u16,
    pub body: Vec<u8>,
}

#[derive(Clone, Debug, Default, Eq, PartialEq)]
pub struct ScriptedHttp {
    pub responses: Vec<ScriptedResponse>,
}

impl ScriptedHttp {
    pub fn push(&mut self, response: ScriptedResponse) {
        self.responses.push(response);
    }
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct FakeChild {
    pub pid: u32,
    pub alive: bool,
    pub label: String,
}

#[derive(Clone, Debug, Default, Eq, PartialEq)]
pub struct FakeProc {
    pub children: Vec<FakeChild>,
}

impl FakeProc {
    pub fn spawn_child(&mut self, label: impl Into<String>) -> u32 {
        let pid = (self.children.len() as u32).saturating_add(1000);
        self.children.push(FakeChild {
            pid,
            alive: true,
            label: label.into(),
        });
        pid
    }
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct SimWorld {
    pub seed: u64,
    pub clock: VirtualClock,
    pub fs: MemFs,
    pub http: ScriptedHttp,
    pub proc: FakeProc,
    pub faults: FaultInjector,
}

impl SimWorld {
    pub fn new(seed: u64) -> Self {
        Self {
            seed,
            clock: VirtualClock::new(0),
            fs: MemFs::default(),
            http: ScriptedHttp::default(),
            proc: FakeProc::default(),
            faults: FaultInjector::new(seed),
        }
    }

    pub fn shared_faults(&self) -> SharedFaults {
        SharedFaults::new(self.faults.clone())
    }

    pub fn crash_after_effect_step(&mut self, step: u64) {
        self.faults.push(FaultSpec {
            label: EFFECT_STEP_LABEL.to_owned(),
            kind: FaultKind::CrashAfterEffect,
            trigger_after_step: Some(step),
        });
    }
}
