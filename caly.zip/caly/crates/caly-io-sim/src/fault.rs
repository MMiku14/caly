use std::sync::{Arc, Mutex};

use caly_io::{IoFault, IoFaultKind};

/// A one-shot hang request for `label`: the next call that asks about it never becomes ready.
pub fn hang(label: impl Into<String>) -> FaultSpec {
    FaultSpec {
        label: label.into(),
        kind: FaultKind::Hang,
        trigger_after_step: None,
    }
}

/// A one-shot stall for `label`: the next call that asks about it returns `Pending` exactly `polls`
/// times before answering.
///
/// The difference from [`hang`] is the whole reason this exists. With only a never-ready port, "the
/// driver gave up too early" and "the port is stuck" produce the *same* observable outcome, so a poll
/// budget can be lowered to 1 and nothing in the suite notices. A stall is answered by a driver with a
/// budget and refused by one without, which is what turns
/// `caly_storage::port_drive::STORE_PORT_POLL_BUDGET` from a decoration into a boundary measured from
/// both sides (`crates/caly-storage/tests/store_port_budget.rs`).
///
/// The poll arithmetic, since a test depends on it: the port's future is polled, consumes the request,
/// and then stalls -- so `stall(label, k)` makes the call ready on poll `k + 1`.
pub fn stall(label: impl Into<String>, polls: u32) -> FaultSpec {
    FaultSpec {
        label: label.into(),
        kind: FaultKind::Stall(polls),
        trigger_after_step: None,
    }
}

/// Label the effect-execution harness queries at every plan step.
///
/// `FaultInjector` matches faults by label, so an injected "crash after step N" must be
/// registered under the label that is actually queried. Registering it under its own
/// descriptive label (`crash-after-step-3`) made the helper unreachable: no caller ever
/// asks for that label, so the fault could never fire.
pub const EFFECT_STEP_LABEL: &str = "effect.step";

#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub enum FaultKind {
    None,
    Timeout,
    Cancelled,
    NotFound,
    PermissionDenied,
    CapacityExceeded,
    IntegrityViolation,
    Unavailable,
    CrashAfterEffect,
    /// Not a fault at all: the call never becomes ready. `ADR-036 §6bis` step 0 needs a port that
    /// *suspends* so that `Timeout` and `Cancelled` can be reached as outcomes of the execution model
    /// rather than only as strings a backend invents. Every real backend here stays immediately-ready;
    /// this exists to be driven, and only by tests.
    Hang,
    /// Also not a fault: the call suspends for a counted number of polls and then answers normally.
    /// See [`stall`] for why "suspends" and "suspends forever" had to be two different injections.
    Stall(u32),
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct FaultSpec {
    pub label: String,
    pub kind: FaultKind,
    pub trigger_after_step: Option<u64>,
}

#[derive(Clone, Debug, Default, Eq, PartialEq)]
pub struct FaultInjector {
    pub seed: u64,
    pub faults: Vec<FaultSpec>,
    pub current_step: u64,
}

impl FaultInjector {
    pub fn new(seed: u64) -> Self {
        Self {
            seed,
            faults: Vec::new(),
            current_step: 0,
        }
    }

    pub fn push(&mut self, fault: FaultSpec) {
        self.faults.push(fault);
    }

    pub fn advance_step(&mut self) {
        self.current_step = self.current_step.saturating_add(1);
    }

    /// Consume one `Hang` request for `label`, if any. Deliberately a separate scan from
    /// [`take_matching`]: a general take would swallow the *next* fault in line and report it as a
    /// hang, which is the kind of cross-talk that makes an injected-failure suite lie.
    pub fn take_hang(&mut self, label: &str) -> bool {
        match self
            .faults
            .iter()
            .position(|fault| fault.label == label && fault.kind == FaultKind::Hang)
        {
            Some(index) => {
                self.faults.remove(index);
                true
            }
            None => false,
        }
    }

    /// Consume one stall request for `label`, if any, and report how many polls it asked for.
    ///
    /// A third deliberate scan next to [`FaultInjector::take_hang`] and [`FaultInjector::take_matching`]:
    /// one general take would let a stall *swallow* the hang behind it (or vice versa) and report the
    /// wrong one, which is exactly the cross-talk that makes an injected-failure suite lie.
    pub fn take_stall(&mut self, label: &str) -> Option<u32> {
        let index = self
            .faults
            .iter()
            .position(|fault| fault.label == label && matches!(fault.kind, FaultKind::Stall(_)))?;
        match self.faults.remove(index).kind {
            FaultKind::Stall(polls) => Some(polls),
            other => unreachable!("a stall was selected by kind: {other:?}"),
        }
    }

    pub fn take_matching(&mut self, label: &str) -> Option<FaultSpec> {
        let index = self.faults.iter().position(|fault| {
            fault.label == label
                && fault
                    .trigger_after_step
                    .map(|step| step <= self.current_step)
                    .unwrap_or(true)
        })?;
        Some(self.faults.remove(index))
    }
}

#[derive(Clone, Default)]
pub struct SharedFaults {
    inner: Arc<Mutex<FaultInjector>>,
}

impl SharedFaults {
    pub fn new(injector: FaultInjector) -> Self {
        Self {
            inner: Arc::new(Mutex::new(injector)),
        }
    }

    pub fn maybe_fail(&self, label: &str) -> Result<(), IoFault> {
        let mut guard = self
            .inner
            .lock()
            .map_err(|_| IoFault::new(IoFaultKind::InternalIo, "fault injector lock poisoned"))?;
        guard.advance_step();
        if let Some(spec) = guard.take_matching(label) {
            return Err(spec.into_io_fault());
        }
        Ok(())
    }

    /// Whether a hang was requested for `label`, consuming it.
    pub fn hang_requested(&self, label: &str) -> Result<bool, IoFault> {
        let mut guard = self
            .inner
            .lock()
            .map_err(|_| IoFault::new(IoFaultKind::InternalIo, "fault injector lock poisoned"))?;
        Ok(guard.take_hang(label))
    }

    /// Whether a stall was requested for `label`, consuming it and reporting the poll count.
    pub fn stall_requested(&self, label: &str) -> Result<Option<u32>, IoFault> {
        let mut guard = self
            .inner
            .lock()
            .map_err(|_| IoFault::new(IoFaultKind::InternalIo, "fault injector lock poisoned"))?;
        Ok(guard.take_stall(label))
    }

    pub fn push(&self, fault: FaultSpec) -> Result<(), IoFault> {
        let mut guard = self
            .inner
            .lock()
            .map_err(|_| IoFault::new(IoFaultKind::InternalIo, "fault injector lock poisoned"))?;
        guard.push(fault);
        Ok(())
    }
}

impl FaultSpec {
    pub fn into_io_fault(self) -> IoFault {
        let kind = match self.kind {
            FaultKind::None => IoFaultKind::InternalIo,
            FaultKind::Timeout => IoFaultKind::Timeout,
            FaultKind::Cancelled => IoFaultKind::Cancelled,
            FaultKind::NotFound => IoFaultKind::NotFound,
            FaultKind::PermissionDenied => IoFaultKind::PermissionDenied,
            FaultKind::CapacityExceeded => IoFaultKind::CapacityExceeded,
            FaultKind::IntegrityViolation => IoFaultKind::IntegrityViolation,
            FaultKind::Unavailable => IoFaultKind::Unavailable,
            // Unreachable by construction: a `Hang`/`Stall` spec is consumed by `hang_requested` /
            // `stall_requested` before `maybe_fail` ever sees it. Mapped to `Busy` rather than
            // `InternalIo` so that if the ordering ever breaks, the text still tells the truth about
            // what happened.
            FaultKind::CrashAfterEffect | FaultKind::Hang | FaultKind::Stall(_) => {
                IoFaultKind::Busy
            }
        };

        IoFault::new(
            kind,
            format!("simulated fault: {} ({:?})", self.label, self.kind),
        )
    }
}
