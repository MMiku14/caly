use std::collections::BTreeMap;
use std::sync::{Arc, Mutex};

use caly_io::{
    BoxFuture, ByteCap, ByteStream, Bytes, ChildHandle, Clock, Durability, FetchReq, FetchResp,
    FileLock, Fs, Http, IoContext, IoFault, IoFaultKind, Keyring, LinkKind, ListCap, Meta,
    Monotonic, Proc, Rand, SpawnSpec, Timestamp, VPath,
};

use std::future::Future;
use std::pin::Pin;
use std::task::{Context, Poll};

use crate::fault::SharedFaults;
use crate::world::{FakeProc, MemFile, MemFs, ScriptedHttp, VirtualClock};

/// The counted version of "not yet": `Pending` for exactly `left` polls, then `Ready`.
///
/// No waker is registered, because nothing here can wake anyone -- the *driver* decides whether to poll
/// again, which is precisely the property under test (`caly_io::drive`'s poll budget). Keeping this in
/// the simulator rather than in the store is also deliberate: the port is the thing that pretends to be
/// slow, and a fake that is told to be slow by its caller would be measuring the caller.
struct Stall {
    left: u32,
}

impl Future for Stall {
    type Output = ();

    fn poll(mut self: Pin<&mut Self>, _cx: &mut Context<'_>) -> Poll<()> {
        if self.left == 0 {
            return Poll::Ready(());
        }
        self.left -= 1;
        Poll::Pending
    }
}

#[derive(Clone)]
pub struct SimFs {
    state: Arc<Mutex<MemFs>>,
    faults: SharedFaults,
    /// The world's clock, when one was attached. `None` means this simulated disk has no notion of
    /// time, and then `Meta::modified_at_unix_ms` is `None` for everything — the honest answer,
    /// rather than a value invented to make a call succeed.
    clock: Option<Arc<Mutex<VirtualClock>>>,
}

impl SimFs {
    pub fn new(state: MemFs, faults: SharedFaults) -> Self {
        Self {
            state: Arc::new(Mutex::new(state)),
            faults,
            clock: None,
        }
    }

    /// Attach a [`SimClock`] so writes stamp mtimes from the *virtual* time.
    ///
    /// Sharing the handle (rather than copying a `VirtualClock`) is the point: advancing the clock
    /// has to be visible to the fs, and a test can then assert that a file's age came from the
    /// injected clock and nowhere else.
    pub fn with_clock(mut self, clock: &SimClock) -> Self {
        self.clock = Some(clock.handle());
        self
    }

    fn now_unix_ms(&self) -> Option<i64> {
        let handle = self.clock.as_ref()?;
        let guard = handle
            .lock()
            .map_err(|_| IoFault::new(IoFaultKind::InternalIo, "sim clock lock poisoned"))
            .ok()?;
        Some(guard.wall_clock_unix_ms)
    }

    pub fn snapshot(&self) -> Result<MemFs, IoFault> {
        self.state
            .lock()
            .map(|guard| guard.clone())
            .map_err(|_| IoFault::new(IoFaultKind::InternalIo, "sim fs lock poisoned"))
    }
}

impl Fs for SimFs {
    fn read<'a>(
        &'a self,
        path: &'a VPath,
        cap: ByteCap,
        ctx: &'a IoContext,
    ) -> BoxFuture<'a, Result<Bytes, IoFault>> {
        let state = Arc::clone(&self.state);
        let faults = self.faults.clone();
        let key = path.as_relative_path();
        Box::pin(async move {
            if faults.hang_requested("fs.read")? {
                // The port that suspends, for the driver's sake: nothing is returned, nothing is
                // failed, and whatever is polling has to decide what that means.
                std::future::pending::<()>().await;
            }
            if let Some(polls) = faults.stall_requested("fs.read")? {
                // The bounded version, so "slow" and "stuck" can be told apart by a driver.
                Stall { left: polls }.await;
            }
            faults.maybe_fail("fs.read")?;
            let guard = state
                .lock()
                .map_err(|_| IoFault::new(IoFaultKind::InternalIo, "sim fs lock poisoned"))?;
            let file = guard
                .files
                .iter()
                .find(|file| file.path == key)
                .ok_or_else(|| {
                    IoFault::new(IoFaultKind::NotFound, format!("file not found: {key}"))
                })?;
            // Same helper as the production adapter, so the two cannot word the same refusal
            // differently -- `RFC-0006 §5.3` binds both, and a simulated gate that disagrees with the
            // real port is worse than no gate (`ADR-022`).
            if let Some(too_big) =
                caly_io::byte_ceiling(ctx, cap.0).violation(file.bytes.len() as u64, &key)
            {
                return Err(too_big);
            }
            Ok(file.bytes.clone())
        })
    }

    fn open_stream<'a>(
        &'a self,
        path: &'a VPath,
        _ctx: &'a IoContext,
    ) -> BoxFuture<'a, Result<ByteStream, IoFault>> {
        let key = path.as_relative_path();
        let state = Arc::clone(&self.state);
        let faults = self.faults.clone();
        Box::pin(async move {
            faults.maybe_fail("fs.open_stream")?;
            let guard = state
                .lock()
                .map_err(|_| IoFault::new(IoFaultKind::InternalIo, "sim fs lock poisoned"))?;
            if guard.files.iter().any(|file| file.path == key) {
                Ok(ByteStream { label: key })
            } else {
                Err(IoFault::new(
                    IoFaultKind::NotFound,
                    "stream target not found",
                ))
            }
        })
    }

    fn write_atomic<'a>(
        &'a self,
        path: &'a VPath,
        data: Bytes,
        _durability: Durability,
        ctx: &'a IoContext,
    ) -> BoxFuture<'a, Result<(), IoFault>> {
        let state = Arc::clone(&self.state);
        let faults = self.faults.clone();
        let key = path.as_relative_path();
        Box::pin(async move {
            // Both suspension shapes, not just the read path: the durable store's writes are where a
            // real backend would fsync, i.e. where a suspension is most plausible and most damaging if
            // the store calls it "broken".
            if faults.hang_requested("fs.write_atomic")? {
                std::future::pending::<()>().await;
            }
            if let Some(polls) = faults.stall_requested("fs.write_atomic")? {
                Stall { left: polls }.await;
            }
            faults.maybe_fail("fs.write_atomic")?;
            // Refused before the file table is touched, exactly as the real port refuses before the
            // disk is: the point of the bound is that nothing half-happens.
            caly_io::check_payload(ctx, &key, data.len() as u64)?;
            let mut guard = state
                .lock()
                .map_err(|_| IoFault::new(IoFaultKind::InternalIo, "sim fs lock poisoned"))?;
            let written_at = self.now_unix_ms();
            guard.remember_dirs(&key);
            if let Some(existing) = guard.files.iter_mut().find(|file| file.path == key) {
                existing.bytes = data;
                existing.modified_at_unix_ms = written_at;
            } else {
                guard.files.push(MemFile {
                    path: key,
                    bytes: data,
                    modified_at_unix_ms: written_at,
                });
            }
            Ok(())
        })
    }

    fn rename<'a>(
        &'a self,
        from: &'a VPath,
        to: &'a VPath,
        _durability: Durability,
        _ctx: &'a IoContext,
    ) -> BoxFuture<'a, Result<(), IoFault>> {
        let state = Arc::clone(&self.state);
        let faults = self.faults.clone();
        let from_key = from.as_relative_path();
        let to_key = to.as_relative_path();
        Box::pin(async move {
            faults.maybe_fail("fs.rename")?;
            let mut guard = state
                .lock()
                .map_err(|_| IoFault::new(IoFaultKind::InternalIo, "sim fs lock poisoned"))?;
            let written_at = self.now_unix_ms();
            // The destination's directories are registered before the file list is borrowed, and
            // they have to be registered at all: a rename that moves a file into a path nobody can
            // list leaves the destination unlinkable. Two views of one world, updated together.
            guard.remember_dirs(&to_key);
            let file = guard
                .files
                .iter_mut()
                .find(|file| file.path == from_key)
                .ok_or_else(|| {
                    IoFault::new(IoFaultKind::NotFound, format!("file not found: {from_key}"))
                })?;
            file.path = to_key;
            file.modified_at_unix_ms = written_at;
            Ok(())
        })
    }

    fn remove<'a>(
        &'a self,
        path: &'a VPath,
        _ctx: &'a IoContext,
    ) -> BoxFuture<'a, Result<(), IoFault>> {
        let state = Arc::clone(&self.state);
        let faults = self.faults.clone();
        let key = path.as_relative_path();
        Box::pin(async move {
            faults.maybe_fail("fs.remove")?;
            let mut guard = state
                .lock()
                .map_err(|_| IoFault::new(IoFaultKind::InternalIo, "sim fs lock poisoned"))?;
            let before = guard.files.len();
            guard.files.retain(|file| file.path != key);
            if guard.files.len() == before {
                Err(IoFault::new(
                    IoFaultKind::NotFound,
                    format!("file not found: {key}"),
                ))
            } else {
                Ok(())
            }
        })
    }

    fn stat<'a>(
        &'a self,
        path: &'a VPath,
        _ctx: &'a IoContext,
    ) -> BoxFuture<'a, Result<Option<Meta>, IoFault>> {
        let state = Arc::clone(&self.state);
        let faults = self.faults.clone();
        let key = path.as_relative_path();
        Box::pin(async move {
            faults.maybe_fail("fs.stat")?;
            let guard = state
                .lock()
                .map_err(|_| IoFault::new(IoFaultKind::InternalIo, "sim fs lock poisoned"))?;
            if let Some(file) = guard.files.iter().find(|file| file.path == key) {
                return Ok(Some(Meta {
                    len: file.bytes.len() as u64,
                    is_file: true,
                    is_dir: false,
                    modified_at_unix_ms: file.modified_at_unix_ms,
                }));
            }
            // Directories report `is_dir`, and their `len` is deliberately 0: on a real disk it is
            // the size of the directory entry, a number with no meaning for callers and no
            // counterpart here. Nothing may compare it across backends.
            if guard.contains_dir(&key) {
                return Ok(Some(Meta {
                    len: 0,
                    is_file: false,
                    is_dir: true,
                    modified_at_unix_ms: None,
                }));
            }
            Ok(None)
        })
    }

    fn link_or_copy<'a>(
        &'a self,
        from: &'a VPath,
        to: &'a VPath,
        _ctx: &'a IoContext,
    ) -> BoxFuture<'a, Result<LinkKind, IoFault>> {
        let state = Arc::clone(&self.state);
        let faults = self.faults.clone();
        let from_key = from.as_relative_path();
        let to_key = to.as_relative_path();
        Box::pin(async move {
            faults.maybe_fail("fs.link_or_copy")?;
            let mut guard = state
                .lock()
                .map_err(|_| IoFault::new(IoFaultKind::InternalIo, "sim fs lock poisoned"))?;
            let source = guard
                .files
                .iter()
                .find(|file| file.path == from_key)
                .cloned()
                .ok_or_else(|| {
                    IoFault::new(IoFaultKind::NotFound, format!("file not found: {from_key}"))
                })?;
            let written_at = self.now_unix_ms();
            guard.remember_dirs(&to_key);
            guard.files.push(MemFile {
                path: to_key,
                bytes: source.bytes,
                modified_at_unix_ms: written_at,
            });
            Ok(LinkKind::Copy)
        })
    }

    fn list<'a>(
        &'a self,
        dir: &'a VPath,
        cap: ListCap,
        _ctx: &'a IoContext,
    ) -> BoxFuture<'a, Result<Vec<VPath>, IoFault>> {
        let base = dir.clone();
        let state = Arc::clone(&self.state);
        let faults = self.faults.clone();
        let key = dir.as_relative_path();
        Box::pin(async move {
            faults.maybe_fail("fs.list")?;
            let guard = state
                .lock()
                .map_err(|_| IoFault::new(IoFaultKind::InternalIo, "sim fs lock poisoned"))?;
            if !guard.contains_dir(&key) {
                // Asking to list a *file* is a different mistake from asking to list nothing: the
                // path is there, it just has no children. `StdFs` reports it as `InvalidInput`
                // (`ENOTDIR`), and the shared contract check makes the two backends agree —
                // "NotFound" here would tell a sweep to give up on the whole subtree.
                if guard.files.iter().any(|file| file.path == key) {
                    return Err(IoFault::new(
                        IoFaultKind::InvalidInput,
                        format!("not a directory: {key}"),
                    ));
                }
                return Err(IoFault::new(
                    IoFaultKind::NotFound,
                    format!("directory not found: {key}"),
                ));
            }
            let prefix = format!("{key}/");
            let mut names: Vec<String> = guard
                .files
                .iter()
                .filter_map(|file| file.path.strip_prefix(&prefix))
                .filter(|rest| !rest.contains('/') && !rest.is_empty())
                .map(str::to_owned)
                .collect();
            for nested in &guard.dirs {
                let Some(rest) = nested.strip_prefix(&prefix) else {
                    continue;
                };
                if !rest.contains('/') && !rest.is_empty() {
                    names.push(rest.to_owned());
                }
            }
            names.sort();
            names.dedup();
            if names.len() > cap.0 as usize {
                return Err(IoFault::new(
                    IoFaultKind::CapacityExceeded,
                    format!(
                        "directory {key} holds {} entries, cap was {}",
                        names.len(),
                        cap.0
                    ),
                ));
            }
            names
                .into_iter()
                .map(|name| {
                    base.join(&name)
                        .map_err(|error| IoFault::new(IoFaultKind::InvalidInput, error.message))
                })
                .collect()
        })
    }

    fn lock_exclusive<'a>(
        &'a self,
        path: &'a VPath,
        _ctx: &'a IoContext,
    ) -> BoxFuture<'a, Result<FileLock, IoFault>> {
        let key = path.as_relative_path();
        let faults = self.faults.clone();
        Box::pin(async move {
            faults.maybe_fail("fs.lock_exclusive")?;
            self.acquire(&lock_key_for(&key))
        })
    }
}

/// Lock files live beside the target, exactly like `StdFs`, so both backends answer the same
/// contention question.
fn lock_key_for(key: &str) -> String {
    format!("{key}.lock")
}

impl SimFs {
    pub(crate) fn acquire(&self, lock_key: &str) -> Result<FileLock, IoFault> {
        let mut guard = self
            .state
            .lock()
            .map_err(|_| IoFault::new(IoFaultKind::InternalIo, "sim fs lock poisoned"))?;
        if guard.files.iter().any(|file| file.path == lock_key) {
            let mut held =
                IoFault::new(IoFaultKind::AlreadyExists, format!("lock held: {lock_key}"));
            held.resource = Some(lock_key.to_owned());
            held.retryable = true;
            return Err(held);
        }
        guard.remember_dirs(lock_key);
        guard.files.push(MemFile {
            path: lock_key.to_owned(),
            bytes: Vec::new(),
            // A lock file is not content, and stamping it with the world clock would suggest the
            // age of a lock means something to a sweep. It does not: listing reports it, ignoring
            // it is the caller's job.
            modified_at_unix_ms: None,
        });
        Ok(FileLock {
            path: lock_key.to_owned(),
        })
    }

    pub(crate) fn release_key(&self, lock_key: &str) -> Result<(), IoFault> {
        let mut guard = self
            .state
            .lock()
            .map_err(|_| IoFault::new(IoFaultKind::InternalIo, "sim fs lock poisoned"))?;
        // Releasing something not held is idempotent: recovery calls this defensively, and the
        // production adapter behaves the same way.
        guard.files.retain(|file| file.path != lock_key);
        Ok(())
    }
}

/// The release half of exclusive locking, which the frozen `Fs` trait cannot express.
///
/// `Fs::lock_exclusive` used to be a no-op that always granted the lock, so any test built on it
/// proved nothing about contention. Modelling the lock as a file next to the target makes the
/// simulator and `StdFs` agree, which is precisely what `RFC-0006 §15` asks for.
impl caly_io::contract::FsLocking for SimFs {
    fn lock<'a>(
        &'a self,
        path: &'a VPath,
        _ctx: &'a IoContext,
    ) -> BoxFuture<'a, Result<FileLock, IoFault>> {
        let key = path.as_relative_path();
        Box::pin(async move { self.acquire(&lock_key_for(&key)) })
    }

    fn release<'a>(
        &'a self,
        lock: &'a FileLock,
        _ctx: &'a IoContext,
    ) -> BoxFuture<'a, Result<(), IoFault>> {
        let key = lock.path.clone();
        Box::pin(async move { self.release_key(&key) })
    }

    fn release_path<'a>(
        &'a self,
        path: &'a VPath,
        _ctx: &'a IoContext,
    ) -> BoxFuture<'a, Result<(), IoFault>> {
        let key = lock_key_for(&path.as_relative_path());
        Box::pin(async move { self.release_key(&key) })
    }
}

#[derive(Clone)]
pub struct SimClock {
    state: Arc<Mutex<VirtualClock>>,
    faults: SharedFaults,
}

impl SimClock {
    pub fn new(clock: VirtualClock, faults: SharedFaults) -> Self {
        Self {
            state: Arc::new(Mutex::new(clock)),
            faults,
        }
    }

    /// The shared clock state, so a [`SimFs`] reads the same virtual time this clock drives.
    ///
    /// A handle rather than a copy on purpose: a cloned `VirtualClock` freezes at the moment of
    /// cloning, so every mtime the fs reported would go stale on the first `advance_ms` — the exact
    /// "plausible but wrong" value this port refuses to invent.
    pub fn handle(&self) -> Arc<Mutex<VirtualClock>> {
        Arc::clone(&self.state)
    }

    pub fn advance_ms(&self, millis: u64) -> Result<(), IoFault> {
        let mut guard = self
            .state
            .lock()
            .map_err(|_| IoFault::new(IoFaultKind::InternalIo, "sim clock lock poisoned"))?;
        guard.advance_ms(millis);
        Ok(())
    }
}

impl Clock for SimClock {
    fn now(&self) -> Timestamp {
        self.state
            .lock()
            .map(|guard| guard.now())
            .unwrap_or(Timestamp { unix_millis: 0 })
    }

    fn mono(&self) -> Monotonic {
        self.state
            .lock()
            .map(|guard| guard.mono())
            .unwrap_or(Monotonic { ticks_millis: 0 })
    }

    fn sleep_until<'a>(&'a self, at: Monotonic) -> BoxFuture<'a, Result<(), IoFault>> {
        let state = Arc::clone(&self.state);
        let faults = self.faults.clone();
        Box::pin(async move {
            faults.maybe_fail("clock.sleep_until")?;
            let mut guard = state
                .lock()
                .map_err(|_| IoFault::new(IoFaultKind::InternalIo, "sim clock lock poisoned"))?;
            let current = guard.monotonic_ms;
            if current < at.ticks_millis {
                guard.advance_ms(at.ticks_millis - current);
            }
            Ok(())
        })
    }
}

#[derive(Clone, Debug)]
pub struct SimRand {
    counter: Arc<Mutex<u64>>,
}

impl SimRand {
    pub fn new(seed: u64) -> Self {
        Self {
            counter: Arc::new(Mutex::new(seed)),
        }
    }
}

impl Rand for SimRand {
    fn fill(&self, buf: &mut [u8]) {
        if let Ok(mut guard) = self.counter.lock() {
            for byte in buf.iter_mut() {
                *byte = (*guard & 0xff) as u8;
                *guard = guard.wrapping_add(1);
            }
        } else {
            for byte in buf.iter_mut() {
                *byte = 0;
            }
        }
    }

    fn uuid(&self) -> String {
        if let Ok(mut guard) = self.counter.lock() {
            let value = *guard;
            *guard = guard.wrapping_add(1);
            format!("sim-{value:016x}")
        } else {
            "sim-0000000000000000".to_owned()
        }
    }
}

#[derive(Clone)]
pub struct SimHttp {
    state: Arc<Mutex<ScriptedHttp>>,
    faults: SharedFaults,
}

impl SimHttp {
    pub fn new(state: ScriptedHttp, faults: SharedFaults) -> Self {
        Self {
            state: Arc::new(Mutex::new(state)),
            faults,
        }
    }
}

impl Http for SimHttp {
    fn fetch<'a>(
        &'a self,
        req: FetchReq,
        ctx: &'a IoContext,
    ) -> BoxFuture<'a, Result<FetchResp, IoFault>> {
        let state = Arc::clone(&self.state);
        let faults = self.faults.clone();
        Box::pin(async move {
            faults.maybe_fail("http.fetch")?;
            let guard = state
                .lock()
                .map_err(|_| IoFault::new(IoFaultKind::InternalIo, "sim http lock poisoned"))?;
            let response = guard
                .responses
                .iter()
                .find(|response| response.url == req.url)
                .ok_or_else(|| {
                    IoFault::new(
                        IoFaultKind::NotFound,
                        format!("no scripted response for {}", req.url),
                    )
                })?;
            // The request's own `max_body_bytes` and the caller's byte budget are both ceilings; the
            // helper picks the tighter one and says which bit. This is `RFC-0006 §15.3`'s item 3, which
            // until now nothing could enforce: there was no carrier for "the body is over budget".
            let ceiling = caly_io::byte_ceiling(ctx, req.max_body_bytes);
            if let Some(too_big) = ceiling.violation(response.body.len() as u64, &req.url) {
                return Err(too_big);
            }
            Ok(FetchResp {
                status: response.status,
                etag: None,
                last_modified: None,
                body: ByteStream {
                    label: format!("http:{}", response.url),
                },
            })
        })
    }
}

#[derive(Clone)]
pub struct SimProc {
    state: Arc<Mutex<FakeProc>>,
    faults: SharedFaults,
}

impl SimProc {
    pub fn new(state: FakeProc, faults: SharedFaults) -> Self {
        Self {
            state: Arc::new(Mutex::new(state)),
            faults,
        }
    }
}

impl Proc for SimProc {
    fn spawn<'a>(
        &'a self,
        spec: SpawnSpec,
        _ctx: &'a IoContext,
    ) -> BoxFuture<'a, Result<ChildHandle, IoFault>> {
        let state = Arc::clone(&self.state);
        let faults = self.faults.clone();
        Box::pin(async move {
            faults.maybe_fail("proc.spawn")?;
            let mut guard = state
                .lock()
                .map_err(|_| IoFault::new(IoFaultKind::InternalIo, "sim proc lock poisoned"))?;
            let pid = guard.spawn_child(spec.program);
            Ok(ChildHandle {
                pid,
                instance_nonce: format!("child-{pid}"),
            })
        })
    }
}

#[derive(Clone, Default)]
pub struct SimKeyring {
    entries: Arc<Mutex<BTreeMap<String, String>>>,
    faults: SharedFaults,
}

impl SimKeyring {
    pub fn new(faults: SharedFaults) -> Self {
        Self {
            entries: Arc::new(Mutex::new(BTreeMap::new())),
            faults,
        }
    }
}

impl Keyring for SimKeyring {
    fn get<'a>(
        &'a self,
        key: &'a str,
        _ctx: &'a IoContext,
    ) -> BoxFuture<'a, Result<Option<String>, IoFault>> {
        let entries = Arc::clone(&self.entries);
        let faults = self.faults.clone();
        let key = key.to_owned();
        Box::pin(async move {
            faults.maybe_fail("keyring.get")?;
            let guard = entries
                .lock()
                .map_err(|_| IoFault::new(IoFaultKind::InternalIo, "sim keyring lock poisoned"))?;
            Ok(guard.get(&key).cloned())
        })
    }

    fn set<'a>(
        &'a self,
        key: &'a str,
        value: String,
        _ctx: &'a IoContext,
    ) -> BoxFuture<'a, Result<(), IoFault>> {
        let entries = Arc::clone(&self.entries);
        let faults = self.faults.clone();
        let key = key.to_owned();
        Box::pin(async move {
            faults.maybe_fail("keyring.set")?;
            let mut guard = entries
                .lock()
                .map_err(|_| IoFault::new(IoFaultKind::InternalIo, "sim keyring lock poisoned"))?;
            guard.insert(key, value);
            Ok(())
        })
    }

    fn delete<'a>(
        &'a self,
        key: &'a str,
        _ctx: &'a IoContext,
    ) -> BoxFuture<'a, Result<(), IoFault>> {
        let entries = Arc::clone(&self.entries);
        let faults = self.faults.clone();
        let key = key.to_owned();
        Box::pin(async move {
            faults.maybe_fail("keyring.delete")?;
            let mut guard = entries
                .lock()
                .map_err(|_| IoFault::new(IoFaultKind::InternalIo, "sim keyring lock poisoned"))?;
            guard.remove(&key);
            Ok(())
        })
    }
}
