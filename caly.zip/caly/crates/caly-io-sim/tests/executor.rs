//! `ADR-036 §2.1` step 1, against a port that really suspends.
//!
//! [`caly_io::BoundedExecutor`] is unit-tested with fixtures, which proves its rules but not its
//! usefulness. These run it over `SimFs`, where `hang("fs.read")` makes a call suspend for real, and
//! where the only clock in the room is the injected virtual one. That combination is the point of the
//! whole step: **a timeout here is a fact the clock said, not a number someone guessed**
//! (`docs/ONBOARDING_NOTES.md §4.86`).

use caly_io::{
    Actor, Advance, BoundedExecutor, ByteCap, Clock, Deadline, Durability, ExecutorLimits, Fs,
    IoContext, IoFaultKind, TaskLimits, TraceId, VPath,
};
use caly_io_sim::{hang, FaultKind, FaultSpec, MemFs, SharedFaults, SimClock, SimFs, VirtualClock};

fn ctx() -> IoContext {
    IoContext::new(TraceId::new("io-sim-executor"), Actor::System)
}

fn write(fs: &SimFs, path: &str, data: &[u8]) -> VPath {
    let vpath = VPath::try_from_str(path).expect("static path");
    caly_io::block_on_ready(fs.write_atomic(&vpath, data.to_vec(), Durability::D2, &ctx()))
        .expect("the write is ready")
        .expect("the simulated disk accepts it");
    vpath
}

/// A queued fault for `label`, so two paths can be handed the *same* one and compared.
fn read_fault(label: &str) -> FaultSpec {
    FaultSpec {
        label: label.to_owned(),
        kind: FaultKind::Unavailable,
        trigger_after_step: None,
    }
}

#[test]
fn a_real_batch_of_reads_flows_through_the_executor_in_order() {
    let fs = SimFs::new(
        MemFs::default(),
        SharedFaults::new(caly_io_sim::FaultInjector::new(1)),
    );
    let ctx = ctx();
    let a = write(&fs, "a.bin", b"aaaa".to_vec().as_slice());
    let b = write(&fs, "b.bin", b"bbbbbbb".to_vec().as_slice());
    let c = write(&fs, "c.bin", b"c".to_vec().as_slice());

    let mut ex = BoundedExecutor::<Vec<u8>>::with_limits(
        None,
        ExecutorLimits::bounded(8).with_polls_per_task(1),
    )
    .expect("these limits are valid");
    for path in [&a, &b, &c] {
        ex.submit(
            format!("read {}", path.as_relative_path()),
            TaskLimits::none(),
            fs.read(path, ByteCap(64), &ctx),
        )
        .expect("capacity 8 for 3 reads");
    }
    assert_eq!(ex.depth(), 3, "everything is queued before any of it runs");
    let report = ex.run_until_idle(4);
    assert!(report.is_idle(), "{:?}", report.stop);
    assert_eq!(
        report
            .completions
            .iter()
            .map(|c| c.result.clone())
            .collect::<Vec<_>>(),
        vec![
            Ok(b"aaaa".to_vec()),
            Ok(b"bbbbbbb".to_vec()),
            Ok(b"c".to_vec())
        ],
        "submission order, and every byte intact"
    );
    let metrics = ex.metrics();
    assert_eq!(
        (metrics.submitted, metrics.completed, metrics.ticks),
        (3, 3, 1),
        "an immediately-ready port costs one round for the whole batch: {metrics:?}"
    );
    assert_eq!(metrics.peak_depth, 3);
}

#[test]
fn a_hanging_read_times_out_because_the_injected_clock_said_so() {
    let faults = SharedFaults::new(caly_io_sim::FaultInjector::new(1));
    let fs = SimFs::new(MemFs::default(), faults.clone());
    let clock = SimClock::new(VirtualClock::new(0), faults.clone());
    let ctx = ctx();
    let path = write(&fs, "hang.bin", b"never arrives".to_vec().as_slice());
    faults.push(hang("fs.read")).expect("one hang is enough");

    let deadline = Deadline(clock.mono().ticks_millis + 50);
    let mut ex = BoundedExecutor::<Vec<u8>>::with_limits(
        Some(&clock),
        ExecutorLimits::bounded(2)
            .with_polls_per_task(1)
            .with_advance(Advance::StepMillis(20)),
    )
    .expect("sleeping with an injected clock is a legal configuration");
    ex.submit(
        "read hang.bin",
        TaskLimits::none().with_deadline(deadline),
        fs.read(&path, ByteCap(64), &ctx),
    )
    .expect("one task fits");

    let report = ex.run_until_idle(10);
    assert!(
        report.is_idle(),
        "an expired task is finished, not stuck: {:?}",
        report.stop
    );
    let only = &report.completions[0];
    assert_eq!(only.fault_kind(), Some(IoFaultKind::Timeout));
    assert!(
        only.result
            .as_ref()
            .unwrap_err()
            .summary
            .contains("deadline at mono 50 expired"),
        "the message has to name the deadline it judged: {:?}",
        only.result
    );
    assert_eq!(
        clock.mono().ticks_millis,
        60,
        "time moved in three steps of 20ms and stopped the round it expired"
    );
    assert_eq!(ex.metrics().advances, 3);
    assert_eq!(ex.metrics().timeouts, 1);
    assert_eq!(ex.metrics().completed, 0);

    // And the port is not wedged: the hang was one-shot, so the same read now answers.
    let again = caly_io::block_on_ready(fs.read(&path, ByteCap(64), &ctx))
        .expect("ready")
        .expect("no hang left");
    assert_eq!(again, b"never arrives".to_vec());
}

#[test]
fn a_hanging_read_is_busy_when_the_caller_forbids_time_to_move() {
    let faults = SharedFaults::new(caly_io_sim::FaultInjector::new(1));
    let fs = SimFs::new(MemFs::default(), faults.clone());
    let clock = SimClock::new(VirtualClock::new(0), faults.clone());
    let ctx = ctx();
    let path = write(&fs, "stuck.bin", b"x".to_vec().as_slice());
    faults.push(hang("fs.read")).expect("inject a hang");

    // A clock is present -- it can *judge* a deadline -- but `Advance::None` says nobody may move it.
    let mut ex = BoundedExecutor::<Vec<u8>>::with_limits(
        Some(&clock),
        ExecutorLimits::bounded(2).with_polls_per_task(1),
    )
    .expect("valid limits");
    ex.submit(
        "read stuck.bin",
        TaskLimits::none(),
        fs.read(&path, ByteCap(64), &ctx),
    )
    .expect("one task fits");
    let report = ex.run_until_idle(2);
    let stop = report.stop.clone().expect("a hang never becomes ready");
    assert_eq!(stop.kind, IoFaultKind::Busy);
    assert!(stop.retryable && stop.transient, "{stop:?}");
    assert!(
        stop.summary.contains("advance=none, clock=yes"),
        "the diagnosis must say a clock was there and unused: {}",
        stop.summary
    );
    assert!(stop.summary.contains("read stuck.bin"), "{stop:?}");
    assert_eq!(
        clock.mono().ticks_millis,
        0,
        "Advance::None must not touch the world's time"
    );
    assert_eq!(
        ex.depth(),
        1,
        "the read is still in flight, still owned by the queue"
    );
    assert_eq!(ex.metrics().advances, 0);
    assert_eq!(ex.metrics().timeouts, 0);
}

#[test]
fn an_injected_port_fault_reaches_the_caller_unwritten() {
    let faults = SharedFaults::new(caly_io_sim::FaultInjector::new(1));
    let fs = SimFs::new(MemFs::default(), faults.clone());
    let ctx = ctx();
    let path = write(&fs, "faulty.bin", b"data".to_vec().as_slice());

    // "survives intact" is only a claim if there is something to compare against: ask the port what
    // the same fault looks like when nobody wraps it, then ask the executor. (My first version of this
    // test asserted `retryable` instead -- a guess about which flags a simulated `Unavailable` carries,
    // and it was wrong: `FaultSpec::into_io_fault` sets none of them.)
    let seen = read_fault("fs.read");
    faults
        .push(seen.clone())
        .expect("queue one fault for the direct read");
    let direct = caly_io::block_on_ready(fs.read(&path, ByteCap(64), &ctx))
        .expect("ready")
        .expect_err("the injected fault");

    faults
        .push(seen)
        .expect("queue the same fault for the executor's read");
    let mut ex = BoundedExecutor::<Vec<u8>>::with_limits(None, ExecutorLimits::bounded(2))
        .expect("valid limits");
    ex.submit(
        "read faulty.bin",
        TaskLimits::none(),
        fs.read(&path, ByteCap(64), &ctx),
    )
    .expect("one task fits");
    let report = ex.run_until_idle(8);
    assert!(
        report.is_idle(),
        "a fault is an answer, not a stuck run: {:?}",
        report.stop
    );
    let only = &report.completions[0];
    assert_eq!(only.fault_kind(), Some(IoFaultKind::Unavailable));
    assert_eq!(
        only.result.as_ref().unwrap_err(),
        &direct,
        "kind, text and retry classification must arrive exactly as the port wrote them"
    );
    let metrics = ex.metrics();
    assert_eq!(
        (metrics.ticks, metrics.completed, metrics.port_faults),
        (1, 0, 1),
        "one round, one fault, no retry loop hiding in the queue: {metrics:?}"
    );
    assert!(ex.is_idle());

    // The fault was spent on the queued read -- which is only true if the executor did not retry it --
    // so the next read answers with its bytes.
    let again = caly_io::block_on_ready(fs.read(&path, ByteCap(64), &ctx))
        .expect("ready")
        .expect("no fault left in the queue");
    assert_eq!(again, b"data".to_vec());
}
