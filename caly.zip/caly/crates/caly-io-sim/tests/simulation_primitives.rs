//! Deterministic simulation primitives (`ADR-022`).
//!
//! `caly-io-sim` was declared `Partial` in `docs/status/IMPLEMENTATION_STATUS.md` with "fault
//! injection 已可用", yet nothing in the workspace depended on it and nothing asserted its
//! semantics. These tests pin the three properties the ADR requires of the simulation layer:
//! a controllable clock, controllable fault injection, and a repeatable seed.

use caly_io::Rand;
use caly_io_sim::{
    fault::{FaultInjector, FaultKind, FaultSpec},
    scenario::ScenarioBuilder,
    world::{FakeProc, MemFs, ScriptedHttp, ScriptedResponse, SimWorld, VirtualClock},
    SharedFaults, SimRand,
};

#[test]
fn virtual_clock_advances_wall_and_monotonic_together() {
    let mut clock = VirtualClock::new(1_000);
    assert_eq!(clock.now().unix_millis, 1_000);
    assert_eq!(clock.mono().ticks_millis, 0);

    clock.advance_ms(250);
    clock.advance_ms(750);

    assert_eq!(
        clock.now().unix_millis,
        2_000,
        "wall clock follows advances"
    );
    assert_eq!(
        clock.mono().ticks_millis,
        1_000,
        "monotonic clock is cumulative"
    );

    let mut rewind = VirtualClock::new(0);
    rewind.advance_ms(0);
    assert_eq!(
        (rewind.now().unix_millis, rewind.mono().ticks_millis),
        (0, 0)
    );
}

#[test]
fn virtual_clock_advance_saturates_and_never_goes_backwards() {
    let mut clock = VirtualClock::new(i64::MAX - 10);
    let before = clock.now().unix_millis;
    clock.advance_ms(u64::MAX);
    assert_eq!(
        clock.now().unix_millis,
        i64::MAX,
        "advance must saturate, not wrap"
    );
    assert!(
        clock.now().unix_millis >= before,
        "a wall clock that moves backwards breaks every simulated deadline"
    );
    assert_eq!(
        clock.mono().ticks_millis,
        u64::MAX,
        "monotonic view saturates too"
    );
}

#[test]
fn memory_fs_records_put_paths_in_insertion_order() {
    let mut fs = MemFs::default();
    fs.put("runtime/p1/config.yaml", b"alpha".to_vec());
    fs.put("cas/ab/cd", b"beta".to_vec());

    assert_eq!(fs.files.len(), 2);
    assert_eq!(fs.files[0].path, "runtime/p1/config.yaml");
    assert_eq!(fs.files[1].bytes, b"beta".to_vec());
}

#[test]
fn fake_proc_assigns_stable_pids() {
    let mut proc = FakeProc::default();
    let first = proc.spawn_child("mihomo");
    let second = proc.spawn_child("sing-box");

    assert_eq!(first, 1000);
    assert_eq!(second, 1001);
    assert!(proc.children.iter().all(|child| child.alive));
    assert_eq!(proc.children[1].label, "sing-box");
}

#[test]
fn scripted_http_is_a_queue_not_a_map() {
    let mut http = ScriptedHttp::default();
    http.push(ScriptedResponse {
        url: "https://example/first".to_owned(),
        status: 200,
        body: b"one".to_vec(),
    });
    http.push(ScriptedResponse {
        url: "https://example/second".to_owned(),
        status: 503,
        body: b"two".to_vec(),
    });

    assert_eq!(http.responses[0].status, 200);
    assert_eq!(http.responses[1].status, 503);
}

#[test]
fn fault_injector_only_fires_once_its_step_threshold_is_reached() {
    let mut injector = FaultInjector::new(7);
    injector.push(FaultSpec {
        label: "fs.write_atomic".to_owned(),
        kind: FaultKind::CapacityExceeded,
        trigger_after_step: Some(2),
    });

    // `take_matching` is the *query*, not the tick: the injector only advances through
    // `advance_step`, which callers like `SharedFaults::maybe_fail` do for every labelled
    // call regardless of which label it was.
    assert!(injector.take_matching("fs.write_atomic").is_none());
    injector.advance_step();
    assert!(injector.take_matching("fs.write_atomic").is_none());
    injector.advance_step();
    assert_eq!(injector.current_step, 2);
    let fired = injector.take_matching("fs.write_atomic");
    assert!(
        matches!(fired, Some(spec) if spec.kind == FaultKind::CapacityExceeded),
        "fault must fire once current_step reaches the threshold"
    );
    assert!(
        injector.take_matching("fs.write_atomic").is_none(),
        "a taken fault is consumed: injection is one-shot, not sticky"
    );
}

#[test]
fn shared_faults_advance_the_step_counter_on_every_labeled_call() {
    let injector = ScenarioBuilder::new(1)
        .fail_at_step("proc.spawn", 1, FaultKind::Unavailable)
        .build();
    let faults = SharedFaults::new(injector);

    // A different label still burns a step, which is the documented-but-subtle part.
    assert!(faults.maybe_fail("fs.read").is_ok());
    assert!(
        faults.maybe_fail("proc.spawn").is_err(),
        "proc.spawn must fail once the shared counter passes the threshold"
    );
    assert!(
        faults.maybe_fail("proc.spawn").is_ok(),
        "the injected fault was consumed; the next call succeeds"
    );
}

#[test]
fn faults_without_a_step_threshold_fire_immediately() {
    let faults = SharedFaults::new(
        ScenarioBuilder::new(0)
            .fail_repeated("http.fetch", 2, FaultKind::Timeout)
            .build(),
    );

    assert!(faults.maybe_fail("http.fetch").is_err());
    assert!(faults.maybe_fail("http.fetch").is_err());
    assert!(
        faults.maybe_fail("http.fetch").is_ok(),
        "fail_repeated(2) must exhaust after two injections"
    );
}

#[test]
fn scenario_builders_are_deterministic_per_seed() {
    let left = caly_io_sim::handshake_timeout_scenario(42);
    let right = caly_io_sim::handshake_timeout_scenario(42);
    assert_eq!(left, right, "same seed must yield the same scenario");
    assert_eq!(left.seed, 42);
    assert_eq!(left.current_step, 0, "a fresh scenario starts at step zero");

    let crash = SimWorld::new(9).faults;
    let mut world = SimWorld::new(9);
    world.crash_after_effect_step(3);
    assert_eq!(world.faults.faults.len(), 1);
    assert_eq!(world.faults.faults[0].trigger_after_step, Some(3));
    assert_eq!(world.faults.faults[0].kind, FaultKind::CrashAfterEffect);
    assert_eq!(
        world.faults.faults[0].label,
        caly_io_sim::EFFECT_STEP_LABEL,
        "the crash fault must be registered under the label the harness actually queries"
    );

    // It must therefore be reachable through SharedFaults. Note the exact semantics:
    // `maybe_fail` advances the counter *before* matching, so a threshold of N fires on
    // the N-th call (i.e. "on step N"), not after N steps have completed ("after step N").
    // That distinction is documented here rather than changed, because every fault kind
    // shares the matcher and the off-by-one reading is a known trap for new callers.
    let faults = world.shared_faults();
    assert!(
        faults.maybe_fail(caly_io_sim::EFFECT_STEP_LABEL).is_ok(),
        "step 1"
    );
    assert!(
        faults.maybe_fail(caly_io_sim::EFFECT_STEP_LABEL).is_ok(),
        "step 2"
    );
    assert!(
        faults.maybe_fail(caly_io_sim::EFFECT_STEP_LABEL).is_err(),
        "crash_after_effect_step(3) must fire when the counter reaches 3"
    );
    assert!(
        faults.maybe_fail(caly_io_sim::EFFECT_STEP_LABEL).is_ok(),
        "injection is one-shot; the run continues if the caller keeps going"
    );
    assert_eq!(world.seed, 9);
    assert!(
        crash.faults.is_empty(),
        "an unmodified world injects nothing"
    );
}

#[test]
fn rand_port_is_repeatable_from_a_seed_and_advances() {
    let left = SimRand::new(5);
    let right = SimRand::new(5);

    let mut a = [0u8; 4];
    let mut b = [0u8; 4];
    left.fill(&mut a);
    right.fill(&mut b);
    assert_eq!(a, b, "same seed must produce identical bytes");
    assert_eq!(
        a,
        [5, 6, 7, 8],
        "the counter stream is explicit, not hashed"
    );
    assert_eq!(left.uuid(), right.uuid(), "ids must be reproducible");

    let mut c = [0u8; 1];
    left.fill(&mut c);
    // 5,6,7,8 from fill, then 9 consumed by uuid(), so the next byte is 10.
    assert_eq!(c, [10u8], "fill must advance the shared stream, not repeat");
}
