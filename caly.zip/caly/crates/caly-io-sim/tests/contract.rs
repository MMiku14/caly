//! The simulator must satisfy the *same* port contract as the production adapter.
//!
//! `RFC-0006 §15` asks for one shared suite across `caly-io-std` and `caly-io-sim`. Running the
//! `caly_io::contract` checks here is what stops `ADR-022`'s release gate from validating a
//! world the real port does not implement.

use caly_io::contract::{
    clock_contract_violations, fault_kind_vocabulary_is_distinguishable, fs_byte_budget_violations,
    fs_contract_violations, fs_listing_violations, fs_lock_violations, fs_mtime_violations,
    vpath_escape_violations,
};
use caly_io::{
    drive, Actor, ByteCap, CancelToken, Deadline, Drive, Durability, Fs, Http, IoContext,
    IoFaultKind, TraceId, VPath,
};
use caly_io_sim::{
    hang, stall, FaultKind, FaultSpec, MemFs, ScriptedHttp, SharedFaults, SimClock, SimFs,
    VirtualClock,
};

fn ctx() -> IoContext {
    IoContext::new(TraceId::new("io-sim-contract"), Actor::System)
}

fn faults() -> SharedFaults {
    SharedFaults::new(caly_io_sim::FaultInjector::new(1))
}

#[test]
fn vpath_rejects_escaping_paths() {
    assert_eq!(vpath_escape_violations(), Vec::<String>::new());
}

#[test]
fn sim_fs_satisfies_the_shared_fs_contract() {
    let fs = SimFs::new(MemFs::default(), faults());
    let violations = fs_contract_violations(&fs, &ctx());
    assert_eq!(
        violations,
        Vec::<String>::new(),
        "sim Fs contract: {violations:?}"
    );
}

/// The same listing contract the production port runs, against the simulated disk.
#[test]
fn sim_fs_satisfies_the_shared_listing_contract() {
    let fs = SimFs::new(MemFs::default(), faults());
    let violations = fs_listing_violations(&fs, &ctx());
    assert_eq!(
        violations,
        Vec::<String>::new(),
        "sim Fs listing contract: {violations:?}"
    );
}

#[test]
fn sim_fs_satisfies_the_shared_byte_budget_contract() {
    let fs = SimFs::new(MemFs::default(), faults());
    let violations = fs_byte_budget_violations(&fs, &ctx());
    assert_eq!(
        violations,
        Vec::<String>::new(),
        "sim Fs byte-budget contract: {violations:?}"
    );
}

#[test]
fn sim_fs_satisfies_the_shared_mtime_contract() {
    let fs = SimFs::new(MemFs::default(), faults())
        .with_clock(&SimClock::new(VirtualClock::new(0), faults()));
    let violations = fs_mtime_violations(&fs, &ctx());
    assert_eq!(
        violations,
        Vec::<String>::new(),
        "sim Fs mtime contract: {violations:?}"
    );
}

/// A world with no clock has no idea what time it is, and must say so.
///
/// This is the half of `ADR-035 §2.2` that a `Option` field tends to lose: once `None` is merely
/// "inconvenient", the next implementation fills it with something plausible. A port that reports
/// *nothing* is honest; a port that reports the epoch makes a brand-new object look ancient, which is
/// exactly how a grace period deletes the wrong file.
#[test]
fn a_world_without_a_clock_reports_no_mtime_at_all() {
    let fs = SimFs::new(MemFs::default(), faults());
    let path = VPath::try_from_str("timeless/file").expect("static path");
    let context = ctx();
    caly_io::contract::block_on_ready(fs.write_atomic(
        &path,
        b"payload".to_vec(),
        Durability::D1,
        &context,
    ))
    .expect("ready")
    .expect("write");
    let meta = caly_io::contract::block_on_ready(fs.stat(&path, &context))
        .expect("ready")
        .expect("stat")
        .expect("present");
    assert_eq!(meta.modified_at_unix_ms, None, "{meta:?}");
    assert_eq!(meta.len, 7, "the length is still real: {meta:?}");
}

/// …and when a clock *is* attached, the mtime is that clock's reading at write time — not a host
/// reading, and not a value refreshed on every `stat`.
/// The port that suspends, and the three answers the driver owes for it.
///
/// `ADR-036 §6bis` step 0 exists because `Timeout` and `Cancelled` were unreachable as outcomes of the
/// **execution model**: the only way to see either was a backend inventing it as its own answer. `SimFs`
/// can now be asked to hang, and the driver -- not the port -- decides what that means.
#[test]
fn a_suspending_port_is_answered_by_the_driver_not_by_the_backend() {
    let slot = faults();
    let fs = SimFs::new(MemFs::default(), slot.clone());
    let path = VPath::try_from_str("pending.bin").expect("path");

    // (1) no limits: one poll and a loud error, which is what every existing call site still sees.
    slot.push(hang("fs.read")).expect("inject a hang");
    let message = caly_io::block_on_ready(fs.read(&path, ByteCap(16), &ctx()))
        .expect_err("a hang is not a success");
    assert!(message.contains("still pending"), "{message}");

    // (2) bounded, nothing else supplied: `Busy`, retryable and transient, and the text says which
    //     limits were in force so a reader can tell "no clock was given" from "the clock said no".
    slot.push(hang("fs.read")).expect("inject another hang");
    let fault =
        drive(fs.read(&path, ByteCap(16), &ctx()), Drive::bounded(3)).expect_err("never ready");
    assert_eq!(fault.kind, IoFaultKind::Busy, "{fault:?}");
    assert!(fault.retryable && fault.transient, "{fault:?}");
    assert!(
        fault.summary.contains("after 3 poll(s)") && fault.summary.contains("clock=no"),
        "{}",
        fault.summary
    );

    // (3) cancelled: `Cancelled`, and not retryable, because retrying a cancelled call is a new call.
    //     The backend never got to answer at all -- that is the point.
    let cancel = CancelToken::pre_cancelled();
    slot.push(hang("fs.read")).expect("inject a third hang");
    let fault = drive(
        fs.read(&path, ByteCap(16), &ctx()),
        Drive::bounded(3).with_cancel(&cancel),
    )
    .expect_err("cancelled before the first poll");
    assert_eq!(fault.kind, IoFaultKind::Cancelled, "{fault:?}");
    assert!(!fault.retryable, "{fault:?}");

    // (4) with a clock that says the deadline passed, `Timeout`: a different kind for a different
    //     reason, which is the entire content of `RFC-0006 §5.2`'s 「可区分」.
    slot.push(hang("fs.read")).expect("inject a fourth hang");
    let clock = SimClock::new(VirtualClock::new(0), faults());
    let fault = drive(
        fs.read(&path, ByteCap(16), &ctx()),
        Drive::bounded(3).with_deadline(Deadline(0), &clock),
    )
    .expect_err("deadline already passed");
    assert_eq!(fault.kind, IoFaultKind::Timeout, "{fault:?}");
    assert!(fault.retryable, "{fault:?}");
}

/// A hang is one-shot and label-scoped. Both halves have been the failure mode of injected-fault
/// machinery before: a general "take the next fault" would let a hang eat an unrelated queued fault,
/// and a hang that never clears wedges every later read of that label.
#[test]
fn a_hang_is_scoped_to_its_label_and_consumed_once() {
    let slot = faults();
    let fs = SimFs::new(MemFs::default(), slot.clone());
    let path = VPath::try_from_str("a.bin").expect("path");
    slot.push(hang("fs.read")).expect("inject a hang on read");
    slot.push(FaultSpec {
        label: "fs.write_atomic".to_owned(),
        kind: FaultKind::Unavailable,
        trigger_after_step: None,
    })
    .expect("inject a write fault");

    let refused =
        caly_io::block_on_ready(fs.write_atomic(&path, b"bytes".to_vec(), Durability::D1, &ctx()))
            .expect("ready");
    let error = refused.expect_err("the queued fault must still fire on its own label");
    assert_eq!(error.kind, IoFaultKind::Unavailable, "{error:?}");
    assert!(
        !fs.snapshot()
            .expect("state")
            .files
            .iter()
            .any(|file| file.path == "a.bin"),
        "a refused write must not have landed anything"
    );

    // The read hangs -- once. After that the injection is spent, so the next read answers honestly.
    let hung = caly_io::block_on_ready(fs.read(&path, ByteCap(8), &ctx())).expect_err("hangs");
    assert!(hung.contains("still pending"), "{hung}");

    // Same-label cross-talk, which is the failure a "take any fault with this label" implementation
    // actually has. The design promise is *not* "whichever was queued first answers first" -- a hang is
    // checked before the fault queue, so the first read hangs either way. The promise is that a hang
    // never **consumes** another fault queued under the same label: the injected `Unavailable` has to
    // still be there for the next read. Under the buggy scan it is eaten as the hang, and the second
    // read then answers `NotFound` instead.
    let faults = faults();
    let fs = SimFs::new(MemFs::default(), faults.clone());
    faults
        .push(FaultSpec {
            label: "fs.read".to_owned(),
            kind: FaultKind::Unavailable,
            trigger_after_step: None,
        })
        .expect("queue a fault on the same label");
    faults.push(hang("fs.read")).expect("and a hang behind it");
    let path2 = VPath::try_from_str("b.bin").expect("path");
    let first = caly_io::block_on_ready(fs.read(&path2, ByteCap(8), &ctx()))
        .expect_err("the hang is checked first, by design");
    assert!(first.contains("still pending"), "{first}");
    let second = caly_io::block_on_ready(fs.read(&path2, ByteCap(8), &ctx()))
        .expect("ready")
        .expect_err("the queued fault must have survived the hang");
    assert_eq!(second.kind, IoFaultKind::Unavailable, "{second:?}");
}

#[test]
fn sim_mtime_comes_from_the_virtual_clock_and_is_stamped_per_write() {
    let clock = SimClock::new(VirtualClock::new(1_000), faults());
    let fs = SimFs::new(MemFs::default(), faults()).with_clock(&clock);
    let context = ctx();
    let path = VPath::try_from_str("stamped/file").expect("static path");

    caly_io::contract::block_on_ready(fs.write_atomic(
        &path,
        b"one".to_vec(),
        Durability::D1,
        &context,
    ))
    .expect("ready")
    .expect("first write");
    let first = caly_io::contract::block_on_ready(fs.stat(&path, &context))
        .expect("ready")
        .expect("stat")
        .expect("present")
        .modified_at_unix_ms;
    assert_eq!(
        first,
        Some(1_000),
        "the write should carry the clock's time"
    );

    clock.advance_ms(5_000).expect("advance");
    let untouched = caly_io::contract::block_on_ready(fs.stat(&path, &context))
        .expect("ready")
        .expect("stat")
        .expect("present")
        .modified_at_unix_ms;
    assert_eq!(
        untouched, first,
        "time passing must not refresh a file's mtime; only a write does"
    );

    caly_io::contract::block_on_ready(fs.write_atomic(
        &path,
        b"two".to_vec(),
        Durability::D1,
        &context,
    ))
    .expect("ready")
    .expect("second write");
    let second = caly_io::contract::block_on_ready(fs.stat(&path, &context))
        .expect("ready")
        .expect("stat")
        .expect("present")
        .modified_at_unix_ms;
    assert_eq!(second, Some(6_000), "{first:?} -> {second:?}");
}

/// The flat simulated disk has to answer the same two questions about directories that a real one
/// does, which is why `MemFs` tracks created directories at all. This pins the tracking itself:
/// `list` of a directory nobody created is `NotFound`, and a file written into a fresh path makes its
/// parents listable.
#[test]
fn sim_records_directories_only_where_a_write_created_them() {
    let fs = SimFs::new(MemFs::default(), faults());
    let context = ctx();
    let deep = VPath::try_from_str("objects/ab/cd/deadbeef").expect("static path");
    let missing = VPath::try_from_str("objects/zz").expect("static path");

    let error = caly_io::contract::block_on_ready(fs.list(&missing, caly_io::ListCap(4), &context))
        .expect("ready")
        .expect_err("a never-created directory must not read as empty");
    assert_eq!(error.kind, caly_io::IoFaultKind::NotFound, "{error:?}");

    caly_io::contract::block_on_ready(fs.write_atomic(
        &deep,
        b"cas".to_vec(),
        Durability::D1,
        &context,
    ))
    .expect("ready")
    .expect("write");
    let parents = caly_io::contract::block_on_ready(fs.list(
        &VPath::try_from_str("objects/ab").expect("static path"),
        caly_io::ListCap(4),
        &context,
    ))
    .expect("ready")
    .expect("list");
    let names: Vec<String> = parents.iter().map(|path| path.as_relative_path()).collect();
    assert_eq!(names, vec!["objects/ab/cd".to_owned()], "{names:?}");

    // A byte cap on a read is unrelated; the point of `ListCap` is that it refuses rather than
    // shortens, which the shared contract covers. Here: reading back the size limit still works.
    let bytes = caly_io::contract::block_on_ready(fs.read(&deep, ByteCap(16), &context))
        .expect("ready")
        .expect("read");
    assert_eq!(bytes, b"cas".to_vec());
}

#[test]
fn sim_locking_can_actually_contend() {
    let fs = SimFs::new(MemFs::default(), faults());
    let violations = fs_lock_violations(&fs, &ctx());
    assert_eq!(
        violations,
        Vec::<String>::new(),
        "sim locking: {violations:?}"
    );
}

#[test]
fn sim_clock_satisfies_the_shared_clock_contract() {
    let clock = SimClock::new(VirtualClock::new(0), faults());
    let violations = clock_contract_violations(&clock);
    assert_eq!(
        violations,
        Vec::<String>::new(),
        "sim clock: {violations:?}"
    );
}

#[test]
fn fault_vocabulary_contract_passes() {
    assert_eq!(
        fault_kind_vocabulary_is_distinguishable(),
        Vec::<String>::new()
    );
}

/// The scripted HTTP state is a queue; assert the shape the `Http` contract will need later, so
/// the gap is visible rather than implied.
#[test]
fn scripted_http_keeps_push_order_for_a_future_body_limit_contract() {
    let mut http = ScriptedHttp::default();
    http.push(caly_io_sim::ScriptedResponse {
        url: "https://example/a".to_owned(),
        status: 200,
        body: vec![1, 2, 3],
    });
    assert_eq!(http.responses[0].body.len(), 3);
}

/// The other suspension the simulator can inject: a *counted* one, so "slow" and "stuck" are two
/// different observable things.
///
/// This is the primitive `crates/caly-storage/tests/store_port_budget.rs` measures its budget against,
/// so it is asserted here at the port layer as well: if a stall silently degraded to "never ready", the
/// store's positive test would be passing because a budget of 64 polls happened to look like a hang.
#[test]
fn an_injected_stall_is_answered_by_a_second_poll_and_not_by_the_first() {
    let slot = faults();
    let fs = SimFs::new(MemFs::default(), slot.clone());
    let path = VPath::try_from_str("slow.bin").expect("path");
    caly_io::block_on_ready(fs.write_atomic(
        &path,
        b"eventually".to_vec(),
        caly_io::Durability::D1,
        &ctx(),
    ))
    .expect("write ok")
    .expect("port ok");

    // One poll is not enough for a one-poll stall: this is the old store-seam behaviour, reproduced
    // exactly, so the difference the store's budget makes is visible from here too.
    slot.push(stall("fs.read", 1)).expect("inject one stall");
    let message = caly_io::block_on_ready(fs.read(&path, ByteCap(16), &ctx()))
        .expect_err("one poll is not two");
    assert!(
        message.contains("still pending after 1 poll(s)"),
        "{message}"
    );

    slot.push(stall("fs.read", 1)).expect("inject it again");
    let bytes = drive(fs.read(&path, ByteCap(16), &ctx()), Drive::bounded(2))
        .expect("the stall plus the answer is two polls")
        .expect("port ok");
    assert_eq!(bytes, b"eventually");

    // And it is one-shot: the next call is answered by the file table, not by the fault queue.
    let again = drive(fs.read(&path, ByteCap(16), &ctx()), Drive::bounded(1))
        .expect("no stall left to spend")
        .expect("port ok");
    assert_eq!(again, b"eventually");
}

/// `RFC-0006 §15.3`'s body limit, finally with a carrier -- and the caller's budget in front of it.
///
/// Three answers, because each one is a way a backend could quietly differ from the file port:
/// the budget is honoured when it is the tighter bound; it is *not* honoured by growing the request's own
/// `max_body_bytes`; and a refusal says which of the two bit. There is no `StdHttp`, so this is a
/// simulator-only check and the shared table in `caly-io/src/contract.rs` says so rather than implying a
/// second backend agrees.
#[test]
fn http_fetch_applies_the_tighter_of_body_limit_and_budget() {
    let body = vec![b'z'; 2_048];
    let mut scripted = caly_io_sim::ScriptedHttp::default();
    scripted.push(caly_io_sim::ScriptedResponse {
        url: "https://example.test/big".to_owned(),
        status: 200,
        body: body.clone(),
    });
    let http = caly_io_sim::SimHttp::new(scripted, faults());
    let request = |max_body_bytes| caly_io::FetchReq {
        url: "https://example.test/big".to_owned(),
        route: caly_io::FetchRoute::Direct,
        etag: None,
        if_modified_since: None,
        max_body_bytes,
    };

    let mut tight = ctx();
    tight.io_budget = caly_io::IoBudget {
        max_bytes: Some(1_024),
        max_requests: None,
    };
    let fault = caly_io::block_on_ready(http.fetch(request(65_536), &tight))
        .expect("ready")
        .expect_err("a 2 KiB body over a 1 KiB budget is a refusal, not a truncation");
    assert_eq!(fault.kind, IoFaultKind::CapacityExceeded, "{fault:?}");
    assert!(
        fault.summary.contains("io_budget.max_bytes = 1024"),
        "the budget is what bit: {}",
        fault.summary
    );

    // The request's own limit still wins when it is tighter, and says so.
    let fault = caly_io::block_on_ready(http.fetch(request(512), &ctx()))
        .expect("ready")
        .expect_err("512 is under a 2 KiB body");
    assert!(
        fault.summary.contains("512 byte cap") && !fault.summary.contains("io_budget"),
        "{}",
        fault.summary
    );

    // And with no budget stated the same fetch is simply allowed: absence is not zero.
    caly_io::block_on_ready(http.fetch(request(65_536), &ctx()))
        .expect("ready")
        .expect("an unbudgeted context must not refuse a body it never bounded");
}
