//! Atomic `config.yaml` write primitives (CLI sinking, 2026-08-14).
//!
//! The backup → validate → atomic-rename recipe shared by every writer:
//! [`backup_config_yaml`] snapshots the current file beside it,
//! [`post_write_validate`] runs the full schema validation, and
//! [`write_atomic`] lands the new bytes with owner-only permissions and
//! an atomic rename so a crash never leaves a half-written config.

use std::path::{Path, PathBuf};
use std::sync::atomic::{AtomicU64, Ordering};

use caly_platform::fs::{
    AtomicFileContents, AtomicWritePlan, LinuxAtomicFileBackend, atomic_write,
};

/// Failure envelope for config-file I/O, split by stage so the caller
/// can map each onto a stable `code:` (read / parse / validate / write).
#[derive(Debug, Clone, PartialEq, Eq)]
pub enum ConfigWriteError {
    Read { path: PathBuf, reason: String },
    Parse { path: PathBuf, reason: String },
    Validate { path: PathBuf, reason: String },
    Write { path: PathBuf, reason: String },
}

impl core::fmt::Display for ConfigWriteError {
    fn fmt(&self, formatter: &mut core::fmt::Formatter<'_>) -> core::fmt::Result {
        match self {
            Self::Read { path, reason } | Self::Write { path, reason } => {
                write!(formatter, "{} {}: {reason}", self.stage(), path.display())
            }
            Self::Parse { path, reason } | Self::Validate { path, reason } => {
                write!(
                    formatter,
                    "{} failed for {}: {reason}",
                    self.stage(),
                    path.display()
                )
            }
        }
    }
}

impl ConfigWriteError {
    fn stage(&self) -> &'static str {
        match self {
            Self::Read { .. } => "read",
            Self::Parse { .. } => "parse",
            Self::Validate { .. } => "validate",
            Self::Write { .. } => "write",
        }
    }
}

impl std::error::Error for ConfigWriteError {}

/// Snapshots `path` to `path.bak` (same directory) before a rewrite.
/// Best-effort at the caller's discretion: a missing source (fresh
/// install) is not an error.
pub fn backup_config_yaml(path: &Path) -> Result<(), ConfigWriteError> {
    let bytes = std::fs::read(path).map_err(|error| ConfigWriteError::Read {
        path: path.to_path_buf(),
        reason: error.to_string(),
    })?;
    let backup = backup_path(path);
    std::fs::write(&backup, &bytes).map_err(|error| ConfigWriteError::Write {
        path: backup,
        reason: error.to_string(),
    })
}

/// The sidecar path for a config file (`config.yaml` → `config.yaml.bak`).
pub fn backup_path(path: &Path) -> PathBuf {
    let mut name = path.as_os_str().to_owned();
    name.push(".bak");
    PathBuf::from(name)
}

/// Full schema validation of the file at `path` (used by the read path
/// as a fast single-file check and by tests).
pub fn post_write_validate(
    path: &Path,
) -> Result<caly_profile::schema::AppConfig, ConfigWriteError> {
    let bytes = std::fs::read(path).map_err(|error| ConfigWriteError::Read {
        path: path.to_path_buf(),
        reason: error.to_string(),
    })?;
    caly_profile::schema::parse_and_validate_yaml(&bytes).map_err(|error| {
        ConfigWriteError::Validate {
            path: path.to_path_buf(),
            reason: error.to_string(),
        }
    })
}

/// Atomically writes `bytes` to `path` through the platform's durable
/// recipe (LOW-3): create-new owner-only → write → file sync → atomic
/// rename → parent-dir sync, so a crash can neither leave a half-written
/// config nor silently roll back a committed one. On any failure the
/// original file is untouched.
pub fn write_atomic(path: &Path, bytes: &[u8]) -> Result<(), ConfigWriteError> {
    let dir = path.parent().unwrap_or_else(|| Path::new("."));
    // Unique per call: our pid separates us from every live process (a
    // pre-existing file under our name is a dead process's stale temp
    // after pid reuse, safe to remove); the counter separates concurrent
    // same-process writers sharing the pid.
    let nonce = TEMP_COUNTER.fetch_add(1, Ordering::Relaxed);
    let temp = dir.join(format!(".config.yaml.tmp-{}-{nonce}", std::process::id()));
    // Best-effort reap of a pid-reused stale temp so the O_EXCL creation
    // inside `atomic_write` cannot fail on a dead process's leftover.
    let _ = std::fs::remove_file(&temp);
    let contents =
        AtomicFileContents::try_from_vec(bytes.to_vec()).map_err(|_| ConfigWriteError::Write {
            path: path.to_path_buf(),
            reason: format!(
                "config body ({} bytes) exceeds the {}-byte atomic-file ceiling",
                bytes.len(),
                caly_platform::fs::MAX_ATOMIC_FILE_BYTES
            ),
        })?;
    atomic_write(
        &mut LinuxAtomicFileBackend,
        AtomicWritePlan {
            destination: path.to_path_buf(),
            temporary: temp,
            contents,
        },
    )
    .map_err(|error| ConfigWriteError::Write {
        path: path.to_path_buf(),
        reason: error.to_string(),
    })
}

/// Process-wide temp-name counter (see `write_atomic`).
static TEMP_COUNTER: AtomicU64 = AtomicU64::new(0);

#[cfg(test)]
mod tests {
    use super::*;
    use crate::test_helpers::temp_root;

    #[test]
    fn backup_config_yaml_writes_a_sidecar() {
        let dir = temp_root("cw-backup");
        let path = dir.join("config.yaml");
        std::fs::write(&path, "a: 1\n").unwrap();
        backup_config_yaml(&path).unwrap();
        assert!(backup_path(&path).exists());
        assert_eq!(
            std::fs::read_to_string(backup_path(&path)).unwrap(),
            "a: 1\n"
        );
    }

    #[test]
    fn write_atomic_replaces_content_and_stays_owner_only() {
        use std::os::unix::fs::PermissionsExt;
        let dir = temp_root("cw-atomic");
        let path = dir.join("config.yaml");
        write_atomic(&path, b"first\n").unwrap();
        write_atomic(&path, b"second\n").unwrap();
        assert_eq!(std::fs::read_to_string(&path).unwrap(), "second\n");
        let mode = std::fs::metadata(&path).unwrap().permissions().mode() & 0o777;
        assert_eq!(mode, 0o600, "config must be owner-only");
    }

    #[test]
    fn post_write_validate_accepts_and_rejects() {
        let dir = temp_root("cw-validate");
        let path = dir.join("config.yaml");
        std::fs::write(&path, "schema_version: 1\ncore: mihomo\n").unwrap();
        assert!(post_write_validate(&path).is_ok());
        std::fs::write(&path, "not: [valid: yaml").unwrap();
        assert!(matches!(
            post_write_validate(&path),
            Err(ConfigWriteError::Parse { .. }) | Err(ConfigWriteError::Validate { .. })
        ));
    }
}
