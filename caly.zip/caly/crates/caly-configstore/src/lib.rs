//!
//! Shared `config.yaml` write path (CLI sinking, step 1).
//! The `set <resource>` writers used to live inside `caly-cli` and wrote
//! the operator's `config.yaml` directly — a second, parallel
//! implementation of the daemon's configuration view that drifted from it
//! (two processes could write the same file concurrently). This crate is
//! the single implementation of the backup → read → parse → mutate →
//! validate → atomic-write recipe:
//!
//! - [`config_writer`] — the generic typed `mutate_yaml_key` /
//!   `backup_config_yaml` / `write_atomic` primitives.
//! - [`resource_writer`] — the unified `set`-writer recipe
//!   (path/URL predicates, layered loader, [`resource_writer::mutate_list`]).
//! - [`yaml_surgery`] — the comment-preserving line patch engine
//!   ([`yaml_surgery::edit_yaml_list`]) with the typed self-check.
//!
//! The daemon's future config-mutation actor and the CLI's `--offline`
//! escape hatch both call THIS code — no second copy anywhere.

#![forbid(unsafe_code)]
#![cfg_attr(
    test,
    allow(
        clippy::unwrap_used,
        clippy::expect_used,
        clippy::panic,
        clippy::todo,
        clippy::unimplemented,
        clippy::unreachable
    )
)] // #53: tests assert with unwrap/expect/panic (+todo/unreachable in fixtures); production lints stay deny

pub mod config_writer;
pub mod resource_mutations;
pub mod resource_writer;
pub mod source_listing;
pub mod subscription_sources;
#[cfg(test)]
mod subscription_sources_tests;
pub mod yaml_surgery;

/// Test-only helpers, re-exported from the canonical home
/// (`caly_platform::paths::test_helpers`, next to `AppPaths`).
#[cfg(test)]
pub(crate) mod test_helpers {
    pub(crate) use caly_platform::paths::test_helpers::{hermetic_paths, temp_root};
}
