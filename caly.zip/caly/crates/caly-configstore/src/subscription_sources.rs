//! Subscription-source mutation semantics (CLI sinking, 2026-08-14,
//! step 2b): the single implementation of `set sub add/remove/set/
//! enable/disable` used by BOTH the daemon's config-mutation actor and
//! the CLI's `--offline` escape hatch. Before this module the semantics
//! lived twice (CLI `sources.rs` and the daemon backend), a drift source
//! that had already produced diverging behaviour once.

use caly_platform::paths::AppPaths;
use caly_profile::schema::SubscriptionSource;

use crate::resource_writer::{ListEditOutcome, ResourceError, is_http_url, mutate_list_at};

/// Default per-source refresh cadence for URL sources when `--every` is
/// not given — 24h in minutes (file sources are pinned static).
pub const DEFAULT_REFRESH_EVERY_MINUTES: u64 = 24 * 60;
/// Maximum display-name length for `sub add --name`.
pub const MAX_SOURCE_NAME_CHARS: usize = 64;

/// Business-level subscription-source error, shared by the daemon actor
/// (mapped to `ActorFailure`) and the CLI `--offline` path (mapped to the
/// CLI's `SubCmdError` envelope).
#[derive(Debug)]
pub enum SubSourceError {
    /// The URL is empty, missing a scheme, or points at a
    /// non-HTTP(S) scheme.
    InvalidUrl(String),
    /// The optional `--name` display name is empty after
    /// trimming, over-long, or contains control characters.
    InvalidName(String),
    /// `add` on a URL that's already in `subscriptions.sources`.
    AlreadyDeclared(String),
    /// `add --name` collides with the display name of an existing source.
    NameTaken(String),
    /// `add` resolved to a local file that does not exist.
    SourceFileNotFound { given: String, resolved: String },
    /// `--every` (non-zero) was passed for a file source (always static).
    EveryOnFile,
    /// A name matching >1 source (hand-edited configs) is not addressable.
    AmbiguousName(String),
    /// The target addresses no declared source.
    NotDeclared(String),
    /// The shared write-pipeline failure (read/parse/validate/write).
    Shared(ResourceError),
}

impl core::fmt::Display for SubSourceError {
    // Wording is kept VERBATIM from the historical CLI error texts so
    // the shared implementation surfaces identical user-facing copy.
    fn fmt(&self, formatter: &mut core::fmt::Formatter<'_>) -> core::fmt::Result {
        match self {
            Self::InvalidUrl(reason) => {
                write!(formatter, "invalid subscription URL: {reason}")
            }
            Self::InvalidName(reason) => write!(formatter, "invalid source name: {reason}"),
            Self::AlreadyDeclared(url) => {
                write!(formatter, "subscription source `{url}` is already declared")
            }
            // §8-4 contract, verbatim wording ("subscription "N"
            // already exists.").
            Self::NameTaken(name) => write!(formatter, "subscription \"{name}\" already exists."),
            // §8-7 contract: the error block itself is three lines —
            // what / resolved-absolute / how to disambiguate.
            Self::SourceFileNotFound { given, resolved } => write!(
                formatter,
                "file not found: {given}\nResolved absolute: {resolved}\nIf you meant a URL, include the scheme: https://..."
            ),
            Self::EveryOnFile => write!(
                formatter,
                "`--every` has no effect on file sources: a local file never changes upstream, so the source stays static (every: 0)."
            ),
            Self::AmbiguousName(name) => write!(
                formatter,
                "multiple subscription sources are named \"{name}\"; address the one you mean by its URL."
            ),
            Self::NotDeclared(url) => {
                write!(formatter, "subscription source `{url}` is not declared")
            }
            Self::Shared(shared) => write!(formatter, "{shared}"),
        }
    }
}

impl std::error::Error for SubSourceError {}

impl From<ResourceError> for SubSourceError {
    fn from(error: ResourceError) -> Self {
        Self::Shared(error)
    }
}

impl From<crate::yaml_surgery::SurgeryError> for SubSourceError {
    fn from(error: crate::yaml_surgery::SurgeryError) -> Self {
        Self::Shared(ResourceError::from(error))
    }
}

/// Outcome of a mutation attempt: the post-mutation declared source
/// count plus whether the write actually happened (dry-run vs applied).
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct SourceWritePreview {
    /// Post-mutation declared source count (preview or applied).
    pub source_count: usize,
    /// The addressed/mutated source's URL.
    pub url: Option<String>,
    /// True when the write actually happened (false = dry-run preview).
    pub applied: bool,
    /// True when the mutation was a no-op (idempotent call, no write).
    pub unchanged: bool,
}

/// How the `set sub add` positional token resolved (Q5).
#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub enum SourceKind {
    /// A trimmed `http(s)://` URL.
    Http,
    /// A local file, stored as a canonical `file://` URL.
    File,
}

/// The canonical form written into `subscriptions.sources[].url`.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct NormalizedSource {
    pub url: String,
    pub kind: SourceKind,
}

// ── add ─────────────────────────────────────────────────────────────

/// `set sub add <token> [--name N] [--every M] [--apply]`.
pub fn add_source(
    paths: &AppPaths,
    token: &str,
    name: Option<&str>,
    refresh_every_minutes: Option<u64>,
    apply: bool,
) -> Result<SourceWritePreview, SubSourceError> {
    let source = normalize_source_token(token)?;
    let refresh_every_minutes = match (source.kind, refresh_every_minutes) {
        (SourceKind::File, Some(minutes)) if minutes > 0 => {
            return Err(SubSourceError::EveryOnFile);
        }
        (SourceKind::File, _) => Some(0),
        (SourceKind::Http, Some(minutes)) => Some(minutes),
        (SourceKind::Http, None) => Some(DEFAULT_REFRESH_EVERY_MINUTES),
    };
    let name = name.map(validate_source_name).transpose()?;
    write_sources(paths, apply, |sources| {
        if sources.iter().any(|s| s.url == source.url) {
            return Err(SubSourceError::AlreadyDeclared(source.url.clone()));
        }
        if let Some(name) = &name
            && sources
                .iter()
                .any(|s| s.name.as_deref() == Some(name.as_str()))
        {
            return Err(SubSourceError::NameTaken(name.clone()));
        }
        let mut next = sources.to_vec();
        next.push(SubscriptionSource {
            url: source.url.clone(),
            enabled: true,
            name: name.clone(),
            refresh_every_minutes,
        });
        Ok(next)
    })
    .map(|preview| SourceWritePreview {
        url: Some(source.url),
        ..preview
    })
}

// ── set (in-place edit) ─────────────────────────────────────────────

/// `set sub set <target> [--url U] [--name N] [--every M] [--apply]`.
pub fn set_source(
    paths: &AppPaths,
    target: &str,
    new_url: Option<&str>,
    new_name: Option<&str>,
    refresh_every_minutes: Option<u64>,
    apply: bool,
) -> Result<SourceWritePreview, SubSourceError> {
    let current_url = resolve_source_ref(paths, target)?;
    let normalized = new_url.map(normalize_source_token).transpose()?;
    let new_name = new_name.map(validate_source_name).transpose()?;
    let sources = load_declared(paths)?.subscriptions.sources;
    if let Some(normalized) = &normalized
        && normalized.url != current_url
        && sources.iter().any(|s| s.url == normalized.url)
    {
        return Err(SubSourceError::AlreadyDeclared(normalized.url.clone()));
    }
    if let Some(name) = &new_name
        && sources
            .iter()
            .any(|s| s.url != current_url && s.name.as_deref() == Some(name))
    {
        return Err(SubSourceError::NameTaken(name.clone()));
    }
    let target_is_file = normalized.as_ref().map_or_else(
        || current_url.starts_with("file://"),
        |n| n.kind == SourceKind::File,
    );
    let final_every = if target_is_file {
        match refresh_every_minutes {
            Some(minutes) if minutes > 0 => return Err(SubSourceError::EveryOnFile),
            _ => Some(0),
        }
    } else {
        let current_every = sources
            .iter()
            .find(|s| s.url == current_url)
            .and_then(|s| s.refresh_every_minutes);
        refresh_every_minutes.or(current_every)
    };
    let target_url = current_url.clone();
    write_sources(paths, apply, |sources| {
        let mut next = sources.to_vec();
        for source in &mut next {
            if source.url == target_url {
                if let Some(normalized) = &normalized {
                    source.url.clone_from(&normalized.url);
                }
                if let Some(name) = &new_name {
                    source.name = Some(name.clone());
                }
                source.refresh_every_minutes = final_every;
                return Ok(next);
            }
        }
        Err(SubSourceError::NotDeclared(target_url))
    })
    .map(|preview| SourceWritePreview {
        url: Some(current_url),
        ..preview
    })
}

// ── remove / enable / disable ───────────────────────────────────────

/// `set sub remove <name-or-url> [--purge] [--apply]`.
pub fn remove_source(
    paths: &AppPaths,
    target: &str,
    purge: bool,
    apply: bool,
) -> Result<SourceWritePreview, SubSourceError> {
    let url = resolve_source_ref(paths, target)?;
    let preview = write_sources(paths, apply, |sources| {
        let kept: Vec<SubscriptionSource> =
            sources.iter().filter(|s| s.url != url).cloned().collect();
        if kept.len() == sources.len() {
            return Err(SubSourceError::NotDeclared(url.clone()));
        }
        Ok(kept)
    })?;
    // Purge only after a real removal — never on a dry-run preview.
    if purge && preview.applied {
        purge_cached_body(paths, &url);
    }
    Ok(SourceWritePreview {
        url: Some(url),
        ..preview
    })
}

/// `set sub enable|disable <name-or-url> [--apply]`.
pub fn set_enabled(
    paths: &AppPaths,
    target: &str,
    enabled: bool,
    apply: bool,
) -> Result<SourceWritePreview, SubSourceError> {
    let url = resolve_source_ref(paths, target)?;
    write_sources(paths, apply, |sources| {
        let mut found = false;
        let next: Vec<SubscriptionSource> = sources
            .iter()
            .map(|s| {
                if s.url == url {
                    found = true;
                    let mut clone = s.clone();
                    clone.enabled = enabled;
                    clone
                } else {
                    s.clone()
                }
            })
            .collect();
        if !found {
            return Err(SubSourceError::NotDeclared(url.clone()));
        }
        Ok(next)
    })
    .map(|preview| SourceWritePreview {
        url: Some(url),
        ..preview
    })
}

// ── shared write tail ───────────────────────────────────────────────

/// Mutates `subscriptions.sources`, validates and writes — or, for a
/// dry-run (`apply: false`), produces the preview without touching disk.
fn write_sources(
    paths: &AppPaths,
    apply: bool,
    mutate: impl FnOnce(&[SubscriptionSource]) -> Result<Vec<SubscriptionSource>, SubSourceError>,
) -> Result<SourceWritePreview, SubSourceError> {
    if !apply {
        // Historical contract: a dry-run preview is always `DryRun` —
        // the caller did not pass `--apply`, so the outcome never claims
        // the target state was already reached.
        let current = load_declared(paths)?.subscriptions.sources;
        let after = mutate(&current)?;
        return Ok(SourceWritePreview {
            source_count: after.len(),
            url: None,
            applied: false,
            unchanged: false,
        });
    }
    let outcome = mutate_list_at::<SubscriptionSource, SubSourceError, _>(
        paths,
        &["subscriptions", "sources"],
        mutate,
    )?;
    let source_count = load_declared(paths)?.subscriptions.sources.len();
    Ok(SourceWritePreview {
        source_count,
        url: None,
        applied: matches!(outcome, ListEditOutcome::Changed),
        unchanged: matches!(outcome, ListEditOutcome::NoChange),
    })
}

// ── token / name / reference resolution ─────────────────────────────

/// Normalizes the `sub add` positional token (Q5: URLs and files
/// auto-detected): `http(s)://` passes through trimmed; `file://` and
/// bare local paths require the file to exist and are stored as
/// canonical `file://` URLs; other schemes are rejected.
pub fn normalize_source_token(raw: &str) -> Result<NormalizedSource, SubSourceError> {
    use std::borrow::Cow;
    use std::path::Path;
    let trimmed = raw.trim();
    if let Ok(url) = is_http_url(trimmed) {
        return Ok(NormalizedSource {
            url: url.to_owned(),
            kind: SourceKind::Http,
        });
    }
    if trimmed.is_empty() {
        return Err(SubSourceError::InvalidUrl(
            "source argument is empty (pass an http(s):// URL or a local file path)".to_owned(),
        ));
    }
    if let Some(rest) = trimmed.strip_prefix("file://") {
        return file_source_from_path(trimmed, Path::new(rest));
    }
    if trimmed.contains("://") {
        return Err(SubSourceError::InvalidUrl(format!(
            "unsupported scheme `{trimmed}`; only http(s):// URLs and local files are supported"
        )));
    }
    let expanded: Cow<'_, str> = if trimmed == "~" {
        std::env::var("HOME").map_or(Cow::Borrowed(trimmed), Cow::Owned)
    } else if let Some(rest) = trimmed.strip_prefix("~/") {
        std::env::var("HOME").map_or(Cow::Borrowed(trimmed), |home| {
            Cow::Owned(format!("{home}/{rest}"))
        })
    } else {
        Cow::Borrowed(trimmed)
    };
    file_source_from_path(trimmed, Path::new(expanded.as_ref()))
}

fn file_source_from_path(
    given: &str,
    path: &std::path::Path,
) -> Result<NormalizedSource, SubSourceError> {
    let resolved = if path.is_absolute() {
        path.display().to_string()
    } else {
        std::env::current_dir().map_or_else(
            |_| path.display().to_string(),
            |cwd| cwd.join(path).display().to_string(),
        )
    };
    let canonical =
        std::fs::canonicalize(path).map_err(|_| SubSourceError::SourceFileNotFound {
            given: given.to_owned(),
            resolved: resolved.clone(),
        })?;
    let url = url::Url::from_file_path(&canonical).map_err(|()| {
        SubSourceError::InvalidUrl(format!(
            "could not form a file:// URL from `{given}` (non-UTF-8 path)"
        ))
    })?;
    Ok(NormalizedSource {
        url: url.to_string(),
        kind: SourceKind::File,
    })
}

/// Validates the optional `--name` display name.
fn validate_source_name(name: &str) -> Result<String, SubSourceError> {
    let trimmed = name.trim();
    if trimmed.is_empty() {
        return Err(SubSourceError::InvalidName("name is empty".to_owned()));
    }
    if trimmed.chars().count() > MAX_SOURCE_NAME_CHARS {
        return Err(SubSourceError::InvalidName(format!(
            "name exceeds {MAX_SOURCE_NAME_CHARS} characters"
        )));
    }
    if trimmed.contains("://") {
        return Err(SubSourceError::InvalidName(
            "name must not contain `://` (it would be parsed as a URL)".to_owned(),
        ));
    }
    if trimmed.chars().any(char::is_control) {
        return Err(SubSourceError::InvalidName(
            "name contains control characters".to_owned(),
        ));
    }
    Ok(trimmed.to_owned())
}

/// Resolves the `<name-or-url>` addressing token shared by every
/// mutation into the source's stored URL: URL-shaped tokens match
/// exactly; otherwise an exact display-name match wins; a bare integer
/// addresses by the 1-based add-order id (the legacy scalar
/// `subscriptions.url` counts as id 1 when present).
pub fn resolve_source_ref(paths: &AppPaths, token: &str) -> Result<String, SubSourceError> {
    let trimmed = token.trim();
    let config = load_declared(paths)?;
    let sources = &config.subscriptions.sources;
    let url_shaped = is_http_url(trimmed).is_ok() || trimmed.starts_with("file://");
    if url_shaped {
        if sources.iter().any(|s| s.url == trimmed)
            || config.subscriptions.url.as_deref() == Some(trimmed)
        {
            return Ok(trimmed.to_owned());
        }
        return Err(SubSourceError::NotDeclared(trimmed.to_owned()));
    }
    if trimmed.is_empty() {
        return Err(SubSourceError::InvalidUrl(
            "source argument is empty (pass an id, a name, an http(s):// URL, or a file)"
                .to_owned(),
        ));
    }
    if trimmed.contains("://") {
        return Err(SubSourceError::InvalidUrl(format!(
            "unsupported scheme `{trimmed}`; only http(s):// URLs and files are supported"
        )));
    }
    let hits: Vec<&str> = sources
        .iter()
        .filter(|s| s.name.as_deref() == Some(trimmed))
        .map(|s| s.url.as_str())
        .collect();
    match hits.as_slice() {
        [] => {}
        [one] => return Ok((*one).to_owned()),
        _ => return Err(SubSourceError::AmbiguousName(trimmed.to_owned())),
    }
    if let Ok(id) = trimmed.parse::<usize>() {
        if id == 0 {
            return Err(SubSourceError::InvalidUrl(
                "source id starts at 1; pass the id shown in `caly sub list`".to_owned(),
            ));
        }
        let mut index = id.saturating_sub(1);
        if let Some(legacy_url) = config.subscriptions.url.as_deref() {
            if index == 0 {
                return Ok(legacy_url.to_owned());
            }
            index -= 1;
        }
        if let Some(source) = sources.get(index) {
            return Ok(source.url.clone());
        }
        let total = sources.len() + usize::from(config.subscriptions.url.is_some());
        return Err(SubSourceError::NotDeclared(format!(
            "source id {id} is out of range; `caly sub list` shows {total} source(s)"
        )));
    }
    Err(SubSourceError::NotDeclared(trimmed.to_owned()))
}

// ── config load / cache purge ───────────────────────────────────────

/// Loads the layered config; a missing file is an error here (the CLI's
/// fresh-install bootstrap runs before this module is reached).
fn load_declared(paths: &AppPaths) -> Result<caly_profile::schema::AppConfig, SubSourceError> {
    use caly_profile::loader::{InMemoryProfileResolver, LayeredConfigPaths, LoaderLimits};
    let limits = LoaderLimits::secure_default();
    let layered = LayeredConfigPaths::new(paths.config.clone(), None);
    caly_profile::loader::load_layered_yaml_with(
        &layered,
        limits,
        &InMemoryProfileResolver::lenient(),
    )
    .map_err(|error| {
        SubSourceError::Shared(ResourceError::Write(format!(
            "load layered config: {error}"
        )))
    })
}

/// `--purge`: deletes the daemon-owned cached body for `url`
/// (`$state/subscriptions/<hex(id)>` plus the `.tmp` sidecar).
/// Best-effort: a missing file is fine, an IO failure warns.
pub fn purge_cached_body(paths: &AppPaths, url: &str) {
    let id = caly_subscription::subscription_id_for_url(url);
    let hex = caly_domain::to_hex(id.into_bytes());
    let dir = paths.state.join("subscriptions");
    for candidate in [dir.join(&hex), dir.join(format!("{hex}.tmp"))] {
        match std::fs::remove_file(&candidate) {
            Ok(()) => {}
            Err(error) if error.kind() == std::io::ErrorKind::NotFound => {}
            Err(error) => eprintln!(
                "warning: could not purge cached body {}: {error}",
                candidate.display()
            ),
        }
    }
}
