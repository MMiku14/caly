//! Declarative `proxy_groups:` / `rule_providers:` mutations
//! (CLI sinking, 2026-08-14, round 2).
//!
//! The daemon's config-mutation actor and the CLI's `--offline` escape
//! hatch share ONE implementation here (same pattern as
//! [`super::subscription_sources`]): the wire payloads
//! (`caly_domain::ConfigMutation`) are decoded once and mapped onto the
//! schema types, then the shared `resource_writer::mutate_list` primitive
//! performs the read-modify-write with dry-run / idempotence semantics.
//!
//! The success shape is the unified [`ResourceWriteOutcome`] (`Applied` /
//! `DryRun` / `NoChange`); errors carry the per-resource business
//! variants (`AlreadyDeclared` / `NotDeclared` / `MissingUrl` /
//! `UnexpectedUrl`) so the CLI dispatch can map them onto stable `code:`
//! strings without string-matching.

use caly_domain::{
    ProxyGroupMemberRef, ProxyGroupMutation, RuleProviderMutation, RuleProviderSourceRef,
};
use caly_platform::paths::AppPaths;
use caly_profile::schema::{
    ProxyGroupConfig, ProxyGroupMemberConfig, ProxyGroupTypeConfig, RuleProviderBehaviorConfig,
    RuleProviderConfig, RuleProviderFormatConfig, RuleProviderSourceConfig, UrlTestConfigConfig,
};

use crate::resource_writer::{
    ListEditOutcome, ResourceError, ResourceWriteOutcome, is_http_url, is_path_safe_name,
    load_app_config, mutate_list,
};

/// Per-resource business error for `proxy_groups:` / `rule_providers:`
/// mutations. The shared [`ResourceError`] cases flow through the
/// `Shared(_)` arm so the dispatch has one `match` instead of two
/// parallel enums.
#[derive(Debug)]
pub enum ResourceMutationError {
    /// The id is empty or not path-safe ASCII.
    InvalidName(String),
    /// `add` on a name that is already declared.
    AlreadyDeclared(String),
    /// `remove` / `enable` / `disable` on a name that is not declared.
    NotDeclared(String),
    /// An unknown `type:` / `--behavior` spelling.
    InvalidKind(String),
    /// A probe-driven proxy group was added without a `--url` flag.
    MissingUrl(String),
    /// A `select` / `relay` group was added with a `--url` flag.
    UnexpectedUrl(String),
    /// The HTTP URL is empty or not `http(s)://`.
    InvalidUrl(String),
    /// Any other failure the shared writer surfaces (read / parse /
    /// validate / IO).
    Shared(ResourceError),
}

impl core::fmt::Display for ResourceMutationError {
    fn fmt(&self, formatter: &mut core::fmt::Formatter<'_>) -> core::fmt::Result {
        match self {
            Self::InvalidName(name) => {
                write!(formatter, "name `{name}` is not path-safe ASCII")
            }
            Self::AlreadyDeclared(name) => {
                write!(formatter, "entry `{name}` is already declared")
            }
            Self::NotDeclared(name) => write!(formatter, "entry `{name}` is not declared"),
            Self::InvalidKind(kind) => write!(formatter, "unknown kind `{kind}`"),
            Self::MissingUrl(name) => write!(
                formatter,
                "entry `{name}` requires --url (url-test / fallback / load-balance)"
            ),
            Self::UnexpectedUrl(name) => write!(
                formatter,
                "entry `{name}` is a select/relay; --url is ignored (drop the flag)"
            ),
            Self::InvalidUrl(reason) => write!(formatter, "invalid URL: {reason}"),
            Self::Shared(shared) => write!(formatter, "{shared}"),
        }
    }
}

impl std::error::Error for ResourceMutationError {}

impl From<ResourceError> for ResourceMutationError {
    fn from(value: ResourceError) -> Self {
        match value {
            ResourceError::AlreadyDeclared(name) => Self::AlreadyDeclared(name),
            ResourceError::NotDeclared(name) => Self::NotDeclared(name),
            other => Self::Shared(other),
        }
    }
}

/// Applies one `set proxy-group` intent with the standard dry-run /
/// idempotence semantics: `apply: false` validates and previews without
/// writing; an idempotent call (`enable` on an enabled group) writes
/// nothing and reports `NoChange`.
pub fn mutate_proxy_group(
    paths: &AppPaths,
    mutation: &ProxyGroupMutation,
    apply: bool,
) -> Result<ResourceWriteOutcome, ResourceMutationError> {
    match mutation {
        ProxyGroupMutation::Add {
            name,
            kind,
            members,
            url,
            interval_seconds,
            tolerance_ms,
        } => add_group(
            paths,
            name,
            kind,
            members,
            url.as_deref(),
            *interval_seconds,
            *tolerance_ms,
            apply,
        ),
        ProxyGroupMutation::Remove { name } => remove_group(paths, name, apply),
        ProxyGroupMutation::Enable { name } => set_enabled(paths, name, true, apply),
        ProxyGroupMutation::Disable { name } => set_enabled(paths, name, false, apply),
    }
}

/// Applies one `set rule-provider` intent with the same dry-run /
/// idempotence semantics as [`mutate_proxy_group`].
pub fn mutate_rule_provider(
    paths: &AppPaths,
    mutation: &RuleProviderMutation,
    apply: bool,
) -> Result<ResourceWriteOutcome, ResourceMutationError> {
    match mutation {
        RuleProviderMutation::Add {
            name,
            source,
            behavior,
        } => add_provider(paths, name, source, behavior.as_deref(), apply),
        RuleProviderMutation::Remove { name } => remove_provider(paths, name, apply),
        RuleProviderMutation::Enable { name } => set_provider_enabled(paths, name, true, apply),
        RuleProviderMutation::Disable { name } => set_provider_enabled(paths, name, false, apply),
    }
}

/// `set proxy-group add <name> <type> [members…] [--url U]`.
///
/// Default: dry-run. `--apply` is the only thing that actually mutates
/// `config.yaml`.
fn add_group(
    paths: &AppPaths,
    name: &str,
    kind: &str,
    members: &[ProxyGroupMemberRef],
    url: Option<&str>,
    interval_seconds: Option<u32>,
    tolerance_ms: Option<u32>,
    apply: bool,
) -> Result<ResourceWriteOutcome, ResourceMutationError> {
    let entry = build_group_config(name, kind, members, url, interval_seconds, tolerance_ms)?;
    if !apply {
        return Ok(ResourceWriteOutcome::DryRun);
    }
    let outcome = mutate_list::<ProxyGroupConfig, _>(paths, "proxy_groups", |current| {
        if current.iter().any(|g| g.name == entry.name) {
            return Err(ResourceError::AlreadyDeclared(entry.name));
        }
        let mut next = current.to_vec();
        next.push(entry);
        Ok(next)
    })?;
    Ok(outcome.write_outcome())
}

/// `set proxy-group remove` — filters the `proxy_groups:` list by name.
fn remove_group(
    paths: &AppPaths,
    name: &str,
    apply: bool,
) -> Result<ResourceWriteOutcome, ResourceMutationError> {
    ensure_safe_name(name)?;
    if !group_exists(paths, name)? {
        return Err(ResourceMutationError::NotDeclared(name.to_owned()));
    }
    if !apply {
        return Ok(ResourceWriteOutcome::DryRun);
    }
    mutate_list::<ProxyGroupConfig, _>(paths, "proxy_groups", |current| {
        let target = name.to_owned();
        Ok(current
            .iter()
            .filter(|g| g.name != target)
            .cloned()
            .collect())
    })
    .map(ListEditOutcome::write_outcome)
    .map_err(ResourceMutationError::from)
}

/// `set proxy-group enable|disable` — flips the `enabled` flag. The
/// schema default is `enabled: true`, so `enable` is a no-op for a fresh
/// entry and `disable` is the meaningful state transition. An idempotent
/// call (the flag is already the target value) writes nothing and
/// reports `NoChange`.
fn set_enabled(
    paths: &AppPaths,
    name: &str,
    enabled: bool,
    apply: bool,
) -> Result<ResourceWriteOutcome, ResourceMutationError> {
    ensure_safe_name(name)?;
    if !group_exists(paths, name)? {
        return Err(ResourceMutationError::NotDeclared(name.to_owned()));
    }
    if let Some(already) = read_enabled(paths, name)?
        && already == enabled
    {
        return Ok(ResourceWriteOutcome::NoChange);
    }
    if !apply {
        return Ok(ResourceWriteOutcome::DryRun);
    }
    mutate_list::<ProxyGroupConfig, _>(paths, "proxy_groups", |current| {
        let target = name.to_owned();
        Ok(current
            .iter()
            .map(|g| {
                let mut g = g.clone();
                if g.name == target {
                    g.enabled = enabled;
                }
                g
            })
            .collect())
    })
    .map(ListEditOutcome::write_outcome)
    .map_err(ResourceMutationError::from)
}

/// `set rule-provider add <name> <http|file|inline> … [--behavior B]`.
fn add_provider(
    paths: &AppPaths,
    name: &str,
    source: &RuleProviderSourceRef,
    behavior: Option<&str>,
    apply: bool,
) -> Result<ResourceWriteOutcome, ResourceMutationError> {
    let entry = build_provider_config(name, source, behavior)?;
    if !apply {
        return Ok(ResourceWriteOutcome::DryRun);
    }
    let outcome = mutate_list::<RuleProviderConfig, _>(paths, "rule_providers", |current| {
        if current.iter().any(|p| p.name == entry.name) {
            return Err(ResourceError::AlreadyDeclared(entry.name));
        }
        let mut next = current.to_vec();
        next.push(entry);
        Ok(next)
    })?;
    Ok(outcome.write_outcome())
}

/// `set rule-provider remove` — filters the `rule_providers:` list by
/// name.
fn remove_provider(
    paths: &AppPaths,
    name: &str,
    apply: bool,
) -> Result<ResourceWriteOutcome, ResourceMutationError> {
    ensure_safe_name(name)?;
    if !provider_exists(paths, name)? {
        return Err(ResourceMutationError::NotDeclared(name.to_owned()));
    }
    if !apply {
        return Ok(ResourceWriteOutcome::DryRun);
    }
    mutate_list::<RuleProviderConfig, _>(paths, "rule_providers", |current| {
        let target = name.to_owned();
        Ok(current
            .iter()
            .filter(|p| p.name != target)
            .cloned()
            .collect())
    })
    .map(ListEditOutcome::write_outcome)
    .map_err(ResourceMutationError::from)
}

/// `set rule-provider enable|disable` — flips the `enabled` flag.
fn set_provider_enabled(
    paths: &AppPaths,
    name: &str,
    enabled: bool,
    apply: bool,
) -> Result<ResourceWriteOutcome, ResourceMutationError> {
    ensure_safe_name(name)?;
    if !provider_exists(paths, name)? {
        return Err(ResourceMutationError::NotDeclared(name.to_owned()));
    }
    if let Some(already) = read_provider_enabled(paths, name)?
        && already == enabled
    {
        return Ok(ResourceWriteOutcome::NoChange);
    }
    if !apply {
        return Ok(ResourceWriteOutcome::DryRun);
    }
    mutate_list::<RuleProviderConfig, _>(paths, "rule_providers", |current| {
        let target = name.to_owned();
        Ok(current
            .iter()
            .map(|p| {
                let mut p = p.clone();
                if p.name == target {
                    p.enabled = enabled;
                }
                p
            })
            .collect())
    })
    .map(ListEditOutcome::write_outcome)
    .map_err(ResourceMutationError::from)
}

/// Builds the schema entry for `proxy_groups:` from the wire payload.
fn build_group_config(
    name: &str,
    kind: &str,
    members: &[ProxyGroupMemberRef],
    url: Option<&str>,
    interval_seconds: Option<u32>,
    tolerance_ms: Option<u32>,
) -> Result<ProxyGroupConfig, ResourceMutationError> {
    ensure_safe_name(name)?;
    let kind = parse_group_kind(kind)?;
    let members = members.iter().map(member_to_schema).collect::<Vec<_>>();
    // `if let Some(...) = ... { … } else { … }` would duplicate the
    // `kind.needs_url()` / `MissingUrl` / `UnexpectedUrl` early-return
    // shape across the two branches; the `match` keeps the
    // probe-validation logic in one place.
    #[allow(clippy::single_match_else)]
    let url_test = match url {
        Some(raw) => {
            let trimmed = is_http_url(raw)
                .map_err(|reason| ResourceMutationError::Shared(ResourceError::Invalid(reason)))?;
            if !kind.needs_url() {
                return Err(ResourceMutationError::UnexpectedUrl(name.to_owned()));
            }
            UrlTestConfigConfig {
                url: trimmed.to_owned(),
                interval_seconds: interval_seconds.unwrap_or(300),
                tolerance_ms: tolerance_ms.unwrap_or(50),
            }
        }
        None => {
            if kind.needs_url() {
                return Err(ResourceMutationError::MissingUrl(name.to_owned()));
            }
            return Ok(ProxyGroupConfig {
                name: name.to_owned(),
                group_type: kind,
                members,
                url_test: None,
                enabled: true,
            });
        }
    };
    Ok(ProxyGroupConfig {
        name: name.to_owned(),
        group_type: kind,
        members,
        url_test: Some(url_test),
        enabled: true,
    })
}

/// Builds the schema entry for `rule_providers:` from the wire payload.
fn build_provider_config(
    name: &str,
    source: &RuleProviderSourceRef,
    behavior: Option<&str>,
) -> Result<RuleProviderConfig, ResourceMutationError> {
    ensure_safe_name(name)?;
    let kind = match source {
        RuleProviderSourceRef::Http { url, interval_ms } => {
            let url = is_http_url(url).map_err(ResourceMutationError::InvalidUrl)?;
            RuleProviderSourceConfig::Http {
                url: url.to_owned(),
                interval_ms: *interval_ms,
            }
        }
        RuleProviderSourceRef::File { path } => {
            RuleProviderSourceConfig::File { path: path.clone() }
        }
        RuleProviderSourceRef::Inline { payload } => RuleProviderSourceConfig::Inline {
            payload: payload.clone(),
        },
    };
    Ok(RuleProviderConfig {
        name: name.to_owned(),
        kind,
        behavior: parse_behavior(behavior)?,
        format: RuleProviderFormatConfig::Source,
        enabled: true,
    })
}

/// Maps the wire `kind:` spelling (`select` / `url-test` / `fallback` /
/// `load-balance` / `relay`) onto the schema enum.
fn parse_group_kind(kind: &str) -> Result<ProxyGroupTypeConfig, ResourceMutationError> {
    match kind {
        "select" => Ok(ProxyGroupTypeConfig::Select),
        "url-test" => Ok(ProxyGroupTypeConfig::UrlTest),
        "fallback" => Ok(ProxyGroupTypeConfig::Fallback),
        "load-balance" => Ok(ProxyGroupTypeConfig::LoadBalance),
        "relay" => Ok(ProxyGroupTypeConfig::Relay),
        other => Err(ResourceMutationError::InvalidKind(other.to_owned())),
    }
}

/// Maps the wire `--behavior` spelling (`domain` / `domain-suffix` /
/// `ip-cidr` / `classical`) onto the schema enum; absent defaults to
/// `domain`.
fn parse_behavior(
    behavior: Option<&str>,
) -> Result<RuleProviderBehaviorConfig, ResourceMutationError> {
    match behavior {
        None | Some("domain") => Ok(RuleProviderBehaviorConfig::Domain),
        Some("domain-suffix") => Ok(RuleProviderBehaviorConfig::DomainSuffix),
        Some("ip-cidr") => Ok(RuleProviderBehaviorConfig::IpCidr),
        Some("classical") => Ok(RuleProviderBehaviorConfig::Classical),
        Some(other) => Err(ResourceMutationError::InvalidKind(other.to_owned())),
    }
}

/// Maps one wire member ref onto the schema `members:` entry.
fn member_to_schema(member: &ProxyGroupMemberRef) -> ProxyGroupMemberConfig {
    match member {
        ProxyGroupMemberRef::Node(tag) => ProxyGroupMemberConfig::Node { tag: tag.clone() },
        ProxyGroupMemberRef::Group(name) => ProxyGroupMemberConfig::Group { name: name.clone() },
        ProxyGroupMemberRef::Direct => ProxyGroupMemberConfig::Direct,
        ProxyGroupMemberRef::Reject => ProxyGroupMemberConfig::Reject,
    }
}

/// Canonical path-safety check for any resource name (character class
/// only; the bounded-length check is the caller's job).
fn ensure_safe_name(name: &str) -> Result<(), ResourceMutationError> {
    if is_path_safe_name(name) {
        Ok(())
    } else {
        Err(ResourceMutationError::InvalidName(name.to_owned()))
    }
}

/// Reads the `enabled` flag of one declared proxy group; `None` when the
/// name is not declared (the same `NotDeclared` condition the writers
/// surface).
fn read_enabled(paths: &AppPaths, name: &str) -> Result<Option<bool>, ResourceMutationError> {
    let config = load_app_config(paths)?;
    Ok(config
        .proxy_groups
        .iter()
        .find(|g| g.name == name)
        .map(|g| g.enabled))
}

/// Reads the `enabled` flag of one declared rule provider.
fn read_provider_enabled(
    paths: &AppPaths,
    name: &str,
) -> Result<Option<bool>, ResourceMutationError> {
    let config = load_app_config(paths)?;
    Ok(config
        .rule_providers
        .iter()
        .find(|p| p.name == name)
        .map(|p| p.enabled))
}

/// Whether a proxy group with this name is declared.
fn group_exists(paths: &AppPaths, name: &str) -> Result<bool, ResourceMutationError> {
    Ok(read_enabled(paths, name)?.is_some())
}

/// Whether a rule provider with this name is declared.
fn provider_exists(paths: &AppPaths, name: &str) -> Result<bool, ResourceMutationError> {
    Ok(read_provider_enabled(paths, name)?.is_some())
}
