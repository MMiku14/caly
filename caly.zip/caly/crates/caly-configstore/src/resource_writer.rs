//! Unified `set`-writer recipe (CLI sinking, 2026-08-14).
//!
//! The cross-resource bookkeeping of every `set <resource>` writer:
//! path-safety and URL predicates, the layered config load, the typed
//! `mutate_list` primitive (read → parse → mutate → validate →
//! atomic-write, with the config.d/ fragment write-target resolution),
//! and the unified `ResourceError` / `ResourceWriteOutcome` envelopes.

use std::path::PathBuf;

use caly_platform::paths::AppPaths;
use serde::Serialize;
use serde::de::DeserializeOwned;

use crate::config_writer::{ConfigWriteError, backup_config_yaml, write_atomic};

/// Unified write failure. The business modules wrap it (via `From`) into
/// their per-resource error types, which the CLI dispatch maps onto the
/// stable `code:` strings.
#[derive(Debug, Clone, PartialEq, Eq)]
pub enum ResourceError {
    /// The mutation is invalid on its own (bad URL, bad shape).
    Invalid(String),
    /// The file could not be read or written.
    Write(String),
    /// The file did not parse as YAML / the schema type.
    Parse(String),
    /// The file parsed but failed schema validation.
    Validate(String),
    /// `add` on an already-declared entry.
    AlreadyDeclared(String),
    /// `remove` / `enable` / `disable` on an undeclared entry.
    NotDeclared(String),
}

impl core::fmt::Display for ResourceError {
    fn fmt(&self, formatter: &mut core::fmt::Formatter<'_>) -> core::fmt::Result {
        match self {
            Self::Invalid(reason) => write!(formatter, "invalid: {reason}"),
            Self::Write(reason) => write!(formatter, "write failed: {reason}"),
            Self::Parse(reason) => write!(formatter, "parse failed: {reason}"),
            Self::Validate(reason) => write!(formatter, "validation failed: {reason}"),
            Self::AlreadyDeclared(name) => write!(formatter, "`{name}` is already declared"),
            Self::NotDeclared(name) => write!(formatter, "`{name}` is not declared"),
        }
    }
}

impl std::error::Error for ResourceError {}

impl From<crate::yaml_surgery::SurgeryError> for ResourceError {
    fn from(value: crate::yaml_surgery::SurgeryError) -> Self {
        Self::Parse(value.to_string())
    }
}

impl From<ConfigWriteError> for ResourceError {
    fn from(value: ConfigWriteError) -> Self {
        match value {
            ConfigWriteError::Read { reason, .. } | ConfigWriteError::Write { reason, .. } => {
                Self::Write(reason)
            }
            ConfigWriteError::Parse { reason, .. } => Self::Parse(reason),
            ConfigWriteError::Validate { reason, .. } => Self::Validate(reason),
        }
    }
}

/// What a `set <resource> VERB` call did, projected to the summary
/// selection: a real write (`Applied`), a preview that would have
/// written (`DryRun`), or an idempotent no-op (`NoChange`).
#[derive(Debug, Clone, Copy, Eq, PartialEq)]
pub enum ResourceWriteOutcome {
    Applied,
    DryRun,
    NoChange,
}

/// Whether a [`mutate_list`] call changed the on-disk file. `NoChange`
/// means the typed before/after were identical: no backup, no
/// validation, no write happened (audit #16).
#[derive(Debug, Clone, Copy, Eq, PartialEq)]
pub enum ListEditOutcome {
    /// The file was backed up, validated and atomically rewritten.
    Changed,
    /// Idempotent no-op: the on-disk state already matched.
    NoChange,
}

impl ListEditOutcome {
    /// Map to the user-facing write outcome: a physical change is
    /// `Applied`; an idempotent no-op surfaces as `NoChange` so the
    /// dispatch can tell "I wrote a no-op" apart from "I changed the
    /// state" (the Round 25 contract).
    pub fn write_outcome(self) -> ResourceWriteOutcome {
        match self {
            Self::Changed => ResourceWriteOutcome::Applied,
            Self::NoChange => ResourceWriteOutcome::NoChange,
        }
    }
}

/// Path to the operator's `config.yaml`. One canonical location so a
/// writer does not drift between path spellings.
pub fn config_yaml_path(paths: &AppPaths) -> PathBuf {
    paths.config.join("config.yaml")
}

/// Canonical path-safety check for any resource name: ASCII alphanumeric,
/// dash, underscore, or dot; non-empty; 1..=64 bytes (the same cap as
/// `ProfileId` / `ProxyGroupName`). The character-class invariant only;
/// bounded-length checks are the caller's job.
pub fn is_path_safe_name(name: &str) -> bool {
    !name.is_empty()
        && name.len() <= 64
        && name
            .chars()
            .all(|c| c.is_ascii_alphanumeric() || matches!(c, '-' | '_' | '.'))
}

/// HTTP(S) URL predicate with trimming: rejects empty strings and
/// non-http(s) schemes; returns the trimmed URL.
pub fn is_http_url(url: &str) -> Result<&str, String> {
    let trimmed = url.trim();
    let parsed = url::Url::parse(trimmed).map_err(|error| format!("not a valid URL: {error}"))?;
    if !matches!(parsed.scheme(), "http" | "https") {
        return Err(format!(
            "unsupported scheme `{}` (use http:// or https://)",
            parsed.scheme()
        ));
    }
    Ok(trimmed)
}

/// Current unix milliseconds (used by cache mtime bookkeeping).
pub fn current_unix_ms() -> u64 {
    std::time::SystemTime::now()
        .duration_since(std::time::UNIX_EPOCH)
        .map_or(0, |duration| {
            u64::try_from(duration.as_millis()).unwrap_or(u64::MAX)
        })
}

/// Loads the LAYERED `AppConfig` (base + active profile + config.d/
/// fragments).
///
/// The layered config is the truth: `config.d/` fragments override /
/// extend the base file, so a base-only read silently misses every key
/// declared in a fragment (`set proxy-group enable`
/// could not see a group declared in `config.d/85-proxy-groups.yaml`).
/// The lenient resolver keeps a fresh install (missing `config.yaml`)
/// readable as an empty `AppConfig`.
pub fn load_app_config(paths: &AppPaths) -> Result<caly_profile::schema::AppConfig, ResourceError> {
    use caly_profile::loader::{InMemoryProfileResolver, LayeredConfigPaths, LoaderLimits};
    let limits = LoaderLimits::secure_default();
    let layered = LayeredConfigPaths::new(paths.config.clone(), None);
    let resolver = InMemoryProfileResolver::lenient();
    caly_profile::loader::load_layered_yaml_with(&layered, limits, &resolver)
        .map_err(|error| ResourceError::Write(format!("load layered config: {error}")))
}

/// [`mutate_list`] with a top-level `key` (e.g. `"proxy_groups"`).
pub fn mutate_list<T, F>(
    paths: &AppPaths,
    key: &str,
    mutate: F,
) -> Result<ListEditOutcome, ResourceError>
where
    T: DeserializeOwned + Serialize + Clone + PartialEq,
    F: FnOnce(&[T]) -> Result<Vec<T>, ResourceError>,
{
    mutate_list_at::<T, ResourceError, _>(paths, &[key], mutate)
}

/// [`mutate_list`] with an explicit nested `key_path` (e.g.
/// `["subscriptions", "sources"]`); the daemon's config-mutation actor
/// uses this for `set sub` CRUD (CLI sinking). The mutator
/// error type is generic so business semantics survive the round-trip
/// instead of collapsing into the shared `ResourceError` bucket.
///
/// The write target follows the layered-merge semantics (2026-08-15
/// debug): a key declared as a **sequence** in a `config.d/` fragment
/// REPLACES the base file's same key on merge, so a base write would be
/// silently invisible. The list is therefore written to the fragment
/// that declares the key (sequence or scalar); a fragment-declared
/// mapping merges recursively, so the base file stays the target there.
pub fn mutate_list_at<T, E, F>(
    paths: &AppPaths,
    key_path: &[&str],
    mutate: F,
) -> Result<ListEditOutcome, E>
where
    T: DeserializeOwned + Serialize + Clone + PartialEq,
    E: From<ResourceError> + From<crate::yaml_surgery::SurgeryError>,
    F: FnOnce(&[T]) -> Result<Vec<T>, E>,
{
    let target = locate_list_target(paths, key_path)?;
    let text = std::fs::read_to_string(&target).map_err(|error| {
        E::from(ResourceError::Write(format!(
            "cannot read {}: {error}",
            target.display()
        )))
    })?;
    let outcome = crate::yaml_surgery::edit_yaml_list::<T, F, E>(
        &text,
        key_path,
        |reason| E::from(ResourceError::Parse(reason)),
        mutate,
    )?;
    let crate::yaml_surgery::EditOutcome::Changed(new_text) = outcome else {
        return Ok(ListEditOutcome::NoChange);
    };
    if target == config_yaml_path(paths) {
        // Base-file write: the single-file schema check is equivalent to
        // a full-config check (fragments only ever override this file's
        // keys, never require them). A failed validation never reaches
        // disk.
        if let Err(error) = caly_profile::schema::parse_and_validate_yaml(&new_text) {
            return Err(E::from(ResourceError::Validate(error.to_string())));
        }
    } else {
        // Fragment write: the file is partial by design, so the full
        // schema check does not apply; at minimum the edited text must
        // still parse as YAML.
        if let Err(error) = serde_norway::from_str::<serde_norway::Value>(
            std::str::from_utf8(&new_text)
                .map_err(|e| E::from(ResourceError::Parse(e.to_string())))?,
        ) {
            return Err(E::from(ResourceError::Parse(error.to_string())));
        }
    }
    backup_config_yaml(&target)
        .map_err(|error| E::from(ResourceError::Write(error.to_string())))?;
    write_atomic(&target, &new_text)
        .map_err(|error| E::from(ResourceError::Write(error.to_string())))?;
    if target != config_yaml_path(paths) {
        // Fragment write: the merged configuration must still load with
        // the production (strict) loader; roll the fragment back to the
        // pre-write text on failure so a bad edit never persists.
        use caly_profile::loader::{LayeredConfigPaths, LoaderLimits};
        let layered = LayeredConfigPaths::new(paths.config.clone(), None);
        if let Err(error) = caly_profile::loader::load_layered_yaml_strict(
            &layered,
            LoaderLimits::secure_default(),
            &paths.state,
        ) {
            let _ = std::fs::write(&target, &text);
            return Err(E::from(ResourceError::Validate(error.to_string())));
        }
    }
    Ok(ListEditOutcome::Changed)
}

/// Resolves the file a `key_path` list lives in: the first `config.d/`
/// fragment (lexicographic order) whose top-level key is declared as a
/// non-mapping wins — its sequence/scalar REPLACES the base file's key
/// on layered merge, so the write must land there to be visible. A
/// fragment-declared mapping merges recursively (the base entries stay),
/// so it does not divert the write. No fragment declaration → the base
/// `config.yaml`.
fn locate_list_target(paths: &AppPaths, key_path: &[&str]) -> Result<PathBuf, ResourceError> {
    let base = config_yaml_path(paths);
    let Some(top) = key_path.first() else {
        return Err(ResourceError::Invalid("empty key path".to_owned()));
    };
    let fragments_dir = paths.config.join("config.d");
    if !fragments_dir.is_dir() {
        return Ok(base);
    }
    let mut fragments: Vec<PathBuf> = std::fs::read_dir(&fragments_dir)
        .map_err(|error| {
            ResourceError::Write(format!("cannot list {}: {error}", fragments_dir.display()))
        })?
        .filter_map(std::result::Result::ok)
        .map(|entry| entry.path())
        .filter(|path| {
            path.extension()
                .and_then(|extension| extension.to_str())
                .is_some_and(|extension| extension == "yaml" || extension == "yml")
        })
        .collect();
    fragments.sort();
    for fragment in fragments {
        let Ok(text) = std::fs::read_to_string(&fragment) else {
            continue;
        };
        let Ok(value) = serde_norway::from_str::<serde_norway::Value>(&text) else {
            continue;
        };
        let Some(declared) = value.get(top) else {
            continue;
        };
        // A mapping fragment merges recursively; the base list stays
        // visible. Anything else (sequence / scalar) replaces the base
        // key wholesale on merge.
        if !declared.is_mapping() {
            return Ok(fragment);
        }
    }
    Ok(base)
}
