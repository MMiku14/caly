//! Comment-preserving line patch engine (CLI sinking, 2026-08-14).
//!
//! [`edit_yaml_list`] mutates ONE `{key}:` list block of a YAML document
//! at the line level: the block's lines are replaced by the serialized
//! new list, while every other line — comments, key order, formatting —
//! stays byte-identical. The typed self-check (before/after decode)
//! guarantees the patch never produces an unreadable document.

mod locate;
mod rewrite;

pub use locate::{KeyBlock, SurgeryError, locate_key_block};
pub use rewrite::{EditOutcome, edit_yaml_list};
