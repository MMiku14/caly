//! Key-block location: finds the line span of a (possibly nested)
//! `{key}:` block in a YAML document by indentation scanning. Pure line
//! arithmetic — no YAML parse round-trip — so the patch engine can
//! preserve every untouched line verbatim.

/// Errors locating or patching a key block.
#[derive(Debug, Clone, PartialEq, Eq)]
pub enum SurgeryError {
    /// The document does not contain the requested key at the expected
    /// nesting depth.
    KeyNotFound(String),
    /// The located block does not decode as the expected list shape.
    TypeMismatch(String),
    /// The document does not parse as YAML.
    Parse(String),
    /// The located block does not decode as the expected value shape.
    Value(String),
}

impl core::fmt::Display for SurgeryError {
    fn fmt(&self, formatter: &mut core::fmt::Formatter<'_>) -> core::fmt::Result {
        match self {
            Self::KeyNotFound(key) => write!(formatter, "YAML key `{key}` not found"),
            Self::TypeMismatch(reason) => write!(formatter, "YAML block shape mismatch: {reason}"),
            Self::Parse(reason) => write!(formatter, "YAML parse error: {reason}"),
            Self::Value(reason) => write!(formatter, "YAML value mismatch: {reason}"),
        }
    }
}

impl std::error::Error for SurgeryError {}

/// The line span of one key block: `start` (inclusive) is the `key:` line,
/// `end` (exclusive) is the first line whose indentation is not deeper
/// than the key's (or EOF). `indent` is the key line's indentation.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub struct KeyBlock {
    pub start: usize,
    pub end: usize,
    pub indent: usize,
}

/// Indentation of a line in columns (spaces only; tabs are treated as
/// zero so a tab-indented document degrades to a top-level match).
fn indent_of(line: &str) -> usize {
    line.len() - line.trim_start_matches(' ').len()
}

/// Whether `line` opens the `{key}:` mapping/sequence at `indent`.
fn opens_key(line: &str, key: &str, indent: usize) -> bool {
    if indent_of(line) != indent {
        return false;
    }
    let trimmed = line.trim_start();
    // `key:` optionally followed by inline content (`key: []`) or a
    // comment (`key: # note`).
    trimmed == format!("{key}:") || trimmed.starts_with(&format!("{key}:"))
}

/// Locates the block of the LAST key in `key_path` (first key at the
/// document root, each further key nested inside the previous block).
/// `None` when any level is missing.
pub fn locate_key_block(lines: &[&str], key_path: &[&str]) -> Option<KeyBlock> {
    let mut search_start = 0usize;
    let mut search_end = lines.len();
    let mut parent_indent = 0usize;
    for key in key_path {
        let mut found = None;
        let mut cursor = search_start;
        while cursor < search_end {
            let indent = indent_of(lines[cursor]);
            if indent < parent_indent && !lines[cursor].trim().is_empty() {
                break; // left the parent block
            }
            if opens_key(lines[cursor], key, indent) && indent >= parent_indent {
                // Prefer the shallowest match at this level (the key
                // directly inside the parent block).
                let block_end = block_end_of(lines, cursor);
                found = Some(KeyBlock {
                    start: cursor,
                    end: block_end,
                    indent,
                });
                break;
            }
            cursor += 1;
        }
        let KeyBlock {
            start, end, indent, ..
        } = found?;
        search_start = start + 1;
        search_end = end;
        parent_indent = indent + 1;
    }
    // Re-locate the final block (the loop above advances past it).
    locate_final(lines, key_path)
}

/// Second pass for the FINAL key: the nested scan above must return the
/// exact span of the deepest block.
fn locate_final(lines: &[&str], key_path: &[&str]) -> Option<KeyBlock> {
    let mut search_start = 0usize;
    let mut search_end = lines.len();
    let mut parent_indent = 0usize;
    let mut result = None;
    for key in key_path {
        let mut cursor = search_start;
        let mut found = None;
        while cursor < search_end {
            let indent = indent_of(lines[cursor]);
            if indent < parent_indent && !lines[cursor].trim().is_empty() {
                break;
            }
            if opens_key(lines[cursor], key, indent) && indent >= parent_indent {
                found = Some(KeyBlock {
                    start: cursor,
                    end: block_end_of(lines, cursor),
                    indent,
                });
                break;
            }
            cursor += 1;
        }
        let block = found?;
        search_start = block.start + 1;
        search_end = block.end;
        parent_indent = block.indent + 1;
        result = Some(block);
    }
    result
}

/// End (exclusive) of the block opened at `key_line`: the next line with
/// indentation <= the key's, skipping blanks; EOF when none.
fn block_end_of(lines: &[&str], key_line: usize) -> usize {
    let indent = indent_of(lines[key_line]);
    for (index, line) in lines.iter().enumerate().skip(key_line + 1) {
        if line.trim().is_empty() {
            continue;
        }
        if indent_of(line) <= indent {
            return index;
        }
    }
    lines.len()
}

#[cfg(test)]
mod tests {
    use super::*;

    const DOC: &str = "# header comment\ncore: mihomo\nproxy_groups:\n  - name: Auto\n    type: select\nrules: []\n";

    #[test]
    fn locates_top_level_block() {
        let lines: Vec<&str> = DOC.lines().collect();
        let block = locate_key_block(&lines, &["proxy_groups"]).unwrap();
        assert_eq!(block.start, 2);
        assert_eq!(block.indent, 0);
        assert_eq!(lines[block.start], "proxy_groups:");
        // Block ends where `rules:` (same indent) starts.
        assert_eq!(block.end, 5);
    }

    #[test]
    fn locates_nested_block() {
        let doc = "subscriptions:\n  sources:\n    - url: a\n    - url: b\ncore: mihomo\n";
        let lines: Vec<&str> = doc.lines().collect();
        let block = locate_key_block(&lines, &["subscriptions", "sources"]).unwrap();
        assert_eq!(block.start, 1);
        assert_eq!(block.indent, 2);
        // Block ends where `core:` (shallower indent) starts.
        assert_eq!(block.end, 4);
    }

    #[test]
    fn missing_key_returns_none() {
        let lines: Vec<&str> = DOC.lines().collect();
        assert!(locate_key_block(&lines, &["rule_providers"]).is_none());
    }
}
