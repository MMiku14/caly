//! The **only** `unsafe` module of the FFmpeg backend.
#![allow(unsafe_code)]

use std::ffi::{c_char, c_int, c_void};
use std::panic::{catch_unwind, AssertUnwindSafe};
use std::ptr;
use std::slice;
use std::time::Duration;
use caly_core::audio::AudioBuffer;
use caly_core::media::{ChannelLayout, Channels};
use caly_core::source::{SourceError, StreamInfo, TrackMeta};
use caly_core::transport::{Transport, TransportError};
use ffmpeg_next::ffi as ff;

const AVERROR_EOF: c_int = -541478725;
const AVERROR_EAGAIN: c_int = -11;
const AVERROR_EIO: c_int = -5;
const AV_NOPTS_VALUE: i64 = i64::MIN;
const AVFMT_FLAG_CUSTOM_IO: c_int = ff::AVFMT_FLAG_CUSTOM_IO;
const AVSEEK_FLAG_BACKWARD: c_int = ff::AVSEEK_FLAG_BACKWARD;
const AVSEEK_SIZE: c_int = 0x10000;
const AV_DISPOSITION_ATTACHED_PIC: c_int = ff::AV_DISPOSITION_ATTACHED_PIC;
const AV_TIME_BASE_Q: ff::AVRational = ff::AVRational {
    num: 1,
    den: 1_000_000,
};
const AVIO_BUF_SIZE: usize = 64 * 1024;

struct TransportBox {
    inner: Box<dyn Transport>,
    pos: u64,
}

struct Avio {
    ctx: *mut ff::AVIOContext,
}

impl Avio {
    fn new(transport: Box<dyn Transport>) -> Result<Self, SourceError> {
        let t = Box::new(TransportBox {
            inner: transport,
            pos: 0,
        });
        let opaque = Box::into_raw(t) as *mut c_void;
        let buf = unsafe { ff::av_malloc(AVIO_BUF_SIZE) };
        if buf.is_null() {
            unsafe { drop(Box::from_raw(opaque as *mut TransportBox)) };
            return Err(SourceError::Decode("av_malloc failed".into()));
        }
        let ctx = unsafe {
            ff::avio_alloc_context(
                buf as *mut u8,
                AVIO_BUF_SIZE as c_int,
                0,
                opaque,
                Some(transport_read_cb),
                None,
                Some(transport_seek_cb),
            )
        };
        if ctx.is_null() {
            unsafe {
                ff::av_free(buf);
                drop(Box::from_raw(opaque as *mut TransportBox));
            }
            return Err(SourceError::Decode("avio_alloc_context failed".into()));
        }
        Ok(Self { ctx })
    }
}

impl Drop for Avio {
    fn drop(&mut self) {
        unsafe {
            if !self.ctx.is_null() {
                let opaque = (*self.ctx).opaque;
                ff::avio_context_free(&mut self.ctx);
                if !opaque.is_null() {
                    drop(Box::from_raw(opaque as *mut TransportBox));
                }
            }
        }
    }
}

unsafe extern "C" fn transport_read_cb(opaque: *mut c_void, buf: *mut u8, size: c_int) -> c_int {
    if opaque.is_null() || buf.is_null() || size <= 0 {
        return AVERROR_EIO;
    }
    catch_unwind(AssertUnwindSafe(|| {
        let t = unsafe { &mut *(opaque as *mut TransportBox) };
        let dst = unsafe { slice::from_raw_parts_mut(buf, size as usize) };
        match t.inner.read(dst) {
            Ok(0) => AVERROR_EOF,
            Ok(n) => {
                t.pos += n as u64;
                n as c_int
            }
            Err(_) => AVERROR_EIO,
        }
    }))
    .unwrap_or(AVERROR_EIO)
}

unsafe extern "C" fn transport_seek_cb(opaque: *mut c_void, offset: i64, whence: c_int) -> i64 {
    if opaque.is_null() {
        return -1;
    }
    catch_unwind(AssertUnwindSafe(|| {
        let t = unsafe { &mut *(opaque as *mut TransportBox) };
        if whence & AVSEEK_SIZE != 0 {
            return t.inner.len().map(|l| l as i64).unwrap_or(-1);
        }
        let base = match whence & 3 {
            0 => offset,
            1 => t.pos as i64 + offset,
            2 => match t.inner.len() {
                Some(l) => l as i64 + offset,
                None => return -1,
            },
            _ => return -1,
        };
        if base < 0 {
            return -1;
        }
        match t.inner.seek(base as u64) {
            Ok(p) => {
                t.pos = p;
                p as i64
            }
            Err(TransportError::Unsupported) | Err(_) => -1,
        }
    }))
    .unwrap_or(-1)
}

struct Packet(*mut ff::AVPacket);

impl Packet {
    fn alloc() -> Result<Self, SourceError> {
        let p = unsafe { ff::av_packet_alloc() };
        if p.is_null() {
            return Err(SourceError::Decode("av_packet_alloc failed".into()));
        }
        Ok(Self(p))
    }
}

impl Drop for Packet {
    fn drop(&mut self) {
        unsafe {
            ff::av_packet_unref(self.0);
            ff::av_packet_free(&mut self.0);
        }
    }
}

struct Frame(*mut ff::AVFrame);

impl Frame {
    fn alloc() -> Result<Self, SourceError> {
        let f = unsafe { ff::av_frame_alloc() };
        if f.is_null() {
            return Err(SourceError::Decode("av_frame_alloc failed".into()));
        }
        Ok(Self(f))
    }
}

impl Drop for Frame {
    fn drop(&mut self) {
        unsafe { ff::av_frame_free(&mut self.0) };
    }
}

fn sample_format_from(v: c_int) -> ff::AVSampleFormat {
    use ff::AVSampleFormat::*;
    match v {
        0 => AV_SAMPLE_FMT_U8,
        1 => AV_SAMPLE_FMT_S16,
        2 => AV_SAMPLE_FMT_S32,
        3 => AV_SAMPLE_FMT_FLT,
        4 => AV_SAMPLE_FMT_DBL,
        5 => AV_SAMPLE_FMT_U8P,
        6 => AV_SAMPLE_FMT_S16P,
        7 => AV_SAMPLE_FMT_S32P,
        8 => AV_SAMPLE_FMT_FLTP,
        9 => AV_SAMPLE_FMT_DBLP,
        10 => AV_SAMPLE_FMT_S64,
        11 => AV_SAMPLE_FMT_S64P,
        _ => AV_SAMPLE_FMT_FLT,
    }
}

pub struct FfmpegReader {
    avio: Avio,
    format: *mut ff::AVFormatContext,
    stream_idx: c_int,
    stream_time_base: ff::AVRational,
    dec: *mut ff::AVCodecContext,
    swr: *mut ff::SwrContext,
    swr_in_fmt: c_int,
    pkt: Packet,
    frame: Frame,
    out_ptr: *mut u8,
    out_capacity_frames: usize,
    meta: TrackMeta,
    duration: Option<Duration>,
    info: Option<StreamInfo>,
    eof: bool,
    input_done: bool,
    flush_sent: bool,
    trim_until_us: Option<i64>,
}

unsafe impl Send for FfmpegReader {}

impl FfmpegReader {
    pub fn open(uri: &str, transport: Box<dyn Transport>) -> Result<Self, SourceError> {
        let avio = Avio::new(transport)?;
        let pkt = Packet::alloc()?;
        let frame = Frame::alloc()?;
        let mut format = unsafe { ff::avformat_alloc_context() };
        if format.is_null() {
            return Err(SourceError::Decode("avformat_alloc_context failed".into()));
        }
        unsafe {
            (*format).pb = avio.ctx;
            (*format).flags |= AVFMT_FLAG_CUSTOM_IO;
        }
        let filename = std::ffi::CString::new(uri.replace('\0', ""))
            .map_err(|_| SourceError::Decode("uri contains NUL".into()))?;
        let mut ret = unsafe {
            ff::avformat_open_input(&mut format, filename.as_ptr(), ptr::null(), ptr::null_mut())
        };
        if ret < 0 {
            let e = ffmpeg_err_str(ret);
            unsafe {
                if !format.is_null() {
                    ff::avformat_close_input(&mut format);
                }
            }
            return Err(SourceError::Decode(format!("avformat_open_input: {e}")));
        }
        ret = unsafe { ff::avformat_find_stream_info(format, ptr::null_mut()) };
        if ret < 0 {
            let e = ffmpeg_err_str(ret);
            unsafe { ff::avformat_close_input(&mut format) };
            return Err(SourceError::Decode(format!(
                "avformat_find_stream_info: {e}"
            )));
        }
        let mut stream_idx = -1;
        let mut time_base = ff::AVRational {
            num: 1,
            den: 1_000_000,
        };
        unsafe {
            let nb = (*format).nb_streams as usize;
            let streams = slice::from_raw_parts((*format).streams, nb);
            for (i, sp) in streams.iter().enumerate() {
                let st = &**sp;
                let par = &*st.codecpar;
                if par.codec_type != ff::AVMediaType::AVMEDIA_TYPE_AUDIO {
                    continue;
                }
                if st.disposition & AV_DISPOSITION_ATTACHED_PIC != 0 {
                    continue;
                }
                stream_idx = i as c_int;
                time_base = st.time_base;
                break;
            }
        }
        if stream_idx < 0 {
            unsafe { ff::avformat_close_input(&mut format) };
            return Err(SourceError::Decode("no audio stream found".into()));
        }
        let mut dec = unsafe { ff::avcodec_alloc_context3(ptr::null()) };
        if dec.is_null() {
            unsafe { ff::avformat_close_input(&mut format) };
            return Err(SourceError::Decode("avcodec_alloc_context3 failed".into()));
        }
        unsafe {
            let st = &**(*format).streams.add(stream_idx as usize);
            let par = &*st.codecpar;
            let codec = ff::avcodec_find_decoder(par.codec_id);
            if codec.is_null() {
                ff::avcodec_free_context(&mut dec);
                ff::avformat_close_input(&mut format);
                return Err(SourceError::Decode(format!(
                    "no decoder for codec id {}",
                    par.codec_id as i32
                )));
            }
            ret = ff::avcodec_parameters_to_context(dec, par);
            if ret < 0 {
                let e = ffmpeg_err_str(ret);
                ff::avcodec_free_context(&mut dec);
                ff::avformat_close_input(&mut format);
                return Err(SourceError::Decode(format!(
                    "avcodec_parameters_to_context: {e}"
                )));
            }
            ret = ff::avcodec_open2(dec, codec, ptr::null_mut());
            if ret < 0 {
                let e = ffmpeg_err_str(ret);
                ff::avcodec_free_context(&mut dec);
                ff::avformat_close_input(&mut format);
                return Err(SourceError::Decode(format!("avcodec_open2: {e}")));
            }
        }
        let meta = unsafe { read_metadata(format) };
        let duration = unsafe {
            let d = (*format).duration;
            if d > 0 {
                Some(Duration::from_micros(d as u64))
            } else {
                None
            }
        };
        let info = unsafe { stream_info_of(dec) };
        let mut meta = meta;
        meta.duration = duration;
        Ok(Self {
            avio,
            format,
            stream_idx,
            stream_time_base: time_base,
            dec,
            swr: ptr::null_mut(),
            swr_in_fmt: -1,
            pkt,
            frame,
            out_ptr: ptr::null_mut(),
            out_capacity_frames: 0,
            meta,
            duration,
            info,
            eof: false,
            input_done: false,
            flush_sent: false,
            trim_until_us: None,
        })
    }

    pub fn track_meta(&self) -> &TrackMeta {
        &self.meta
    }
    pub fn duration(&self) -> Option<Duration> {
        self.duration
    }
    pub fn stream_info(&self) -> Option<&StreamInfo> {
        self.info.as_ref()
    }
    pub fn probe_meta(&self) -> (TrackMeta, Option<StreamInfo>) {
        (self.meta.clone(), self.info)
    }

    pub fn next_chunk(&mut self, max_frames: usize) -> Result<Option<AudioBuffer>, SourceError> {
        if self.eof {
            return Ok(None);
        }
        let info = self.info.ok_or_else(|| {
            SourceError::Decode("stream info unavailable before first frame".into())
        })?;
        let ch = info.channels.get() as usize;
        let mut samples: Vec<f32> = Vec::with_capacity(max_frames * ch);
        while samples.len() / ch < max_frames {
            if self.decode_more(&mut samples)? {
                break;
            }
        }
        if samples.is_empty() && self.eof {
            return Ok(None);
        }
        Ok(Some(AudioBuffer {
            channels: info.channels,
            sample_rate: info.sample_rate,
            layout: info.layout,
            samples,
        }))
    }

    fn decode_more(&mut self, out: &mut Vec<f32>) -> Result<bool, SourceError> {
        if self.eof {
            return Ok(true);
        }
        loop {
            loop {
                let r = unsafe { ff::avcodec_receive_frame(self.dec, self.frame.0) };
                if r >= 0 {
                    break;
                }
                match r {
                    AVERROR_EAGAIN => {
                        if self.input_done {
                            if !self.flush_sent {
                                let sp = unsafe { ff::avcodec_send_packet(self.dec, ptr::null()) };
                                if sp < 0 && sp != AVERROR_EAGAIN {
                                    return Err(ffmpeg_err(sp, "avcodec_send_packet(flush)"));
                                }
                                self.flush_sent = true;
                            }
                            continue;
                        }
                        if !self.read_and_send()? {
                            self.input_done = true;
                        }
                    }
                    AVERROR_EOF => {
                        self.eof = true;
                        return Ok(true);
                    }
                    other => return Err(ffmpeg_err(other, "avcodec_receive_frame")),
                }
            }
            if let Some(target) = self.trim_until_us {
                let pts = unsafe { (*self.frame.0).pts };
                if pts != AV_NOPTS_VALUE {
                    let pts_us =
                        unsafe { ff::av_rescale_q(pts, self.stream_time_base, AV_TIME_BASE_Q) };
                    if pts_us < target {
                        continue;
                    }
                }
                self.trim_until_us = None;
            }
            self.convert_frame(out)?;
            return Ok(false);
        }
    }

    fn read_and_send(&mut self) -> Result<bool, SourceError> {
        loop {
            let r = unsafe { ff::av_read_frame(self.format, self.pkt.0) };
            if r == 0 {
                let idx = unsafe { (*self.pkt.0).stream_index };
                if idx == self.stream_idx {
                    let sp = unsafe { ff::avcodec_send_packet(self.dec, self.pkt.0) };
                    if sp < 0 && sp != AVERROR_EAGAIN {
                        return Err(ffmpeg_err(sp, "avcodec_send_packet"));
                    }
                    return Ok(true);
                }
                continue;
            }
            return match r {
                AVERROR_EOF => Ok(false),
                other => Err(ffmpeg_err(other, "av_read_frame")),
            };
        }
    }

    fn convert_frame(&mut self, out: &mut Vec<f32>) -> Result<(), SourceError> {
        unsafe {
            let frame = self.frame.0;
            let nb_samples = (*frame).nb_samples as usize;
            if nb_samples == 0 {
                return Ok(());
            }
            let in_fmt = (*frame).format;
            let in_layout = (*frame).ch_layout;
            let n_channels = if in_layout.nb_channels > 0 {
                in_layout.nb_channels as usize
            } else {
                self.info
                    .as_ref()
                    .map(|i| i.channels.get() as usize)
                    .unwrap_or(2)
            };
            let rate = (*frame).sample_rate;
            if rate > 0 {
                self.update_info(rate, n_channels);
            }
            if self.swr.is_null() || self.swr_in_fmt != in_fmt {
                if !self.swr.is_null() {
                    ff::swr_free(&mut self.swr);
                }
                self.swr = Self::make_swr(in_fmt, &in_layout, n_channels, rate)?;
                self.swr_in_fmt = in_fmt;
            }
            let in_ptrs: *const *const u8 = if (*frame).extended_data.is_null() {
                (*frame).data.as_ptr() as *const *const u8
            } else {
                (*frame).extended_data as *const *const u8
            };
            let want_out =
                ff::swr_get_out_samples(self.swr, nb_samples as c_int).max(nb_samples as c_int);
            self.ensure_out_capacity(want_out as usize, n_channels)?;
            let got = ff::swr_convert(
                self.swr,
                &self.out_ptr,
                self.out_capacity_frames as c_int,
                in_ptrs,
                nb_samples as c_int,
            );
            if got < 0 {
                return Err(ffmpeg_err(got, "swr_convert"));
            }
            let frames = got as usize;
            let src = slice::from_raw_parts(self.out_ptr as *const f32, frames * n_channels);
            out.extend_from_slice(src);
            Ok(())
        }
    }

    fn make_swr(
        in_fmt: c_int,
        in_layout: &ff::AVChannelLayout,
        n_channels: usize,
        rate: c_int,
    ) -> Result<*mut ff::SwrContext, SourceError> {
        unsafe {
            let mut layout = *in_layout;
            if layout.order == ff::AVChannelOrder::AV_CHANNEL_ORDER_UNSPEC
                || layout.nb_channels <= 0
                || (layout.order == ff::AVChannelOrder::AV_CHANNEL_ORDER_NATIVE
                    && layout.u.mask == 0
                    && n_channels > 0)
            {
                layout = std::mem::zeroed();
                ff::av_channel_layout_default(&mut layout, n_channels as c_int);
            }
            let mut swr: *mut ff::SwrContext = ptr::null_mut();
            let ret = ff::swr_alloc_set_opts2(
                &mut swr,
                &layout,
                sample_format_from(ff::AVSampleFormat::AV_SAMPLE_FMT_FLT as c_int),
                rate,
                &layout,
                sample_format_from(in_fmt),
                rate,
                0,
                ptr::null_mut(),
            );
            if ret < 0 {
                return Err(ffmpeg_err(ret, "swr_alloc_set_opts2"));
            }
            let ret = ff::swr_init(swr);
            if ret < 0 {
                ff::swr_free(&mut swr);
                return Err(ffmpeg_err(ret, "swr_init"));
            }
            Ok(swr)
        }
    }

    fn ensure_out_capacity(&mut self, frames: usize, channels: usize) -> Result<(), SourceError> {
        if self.out_capacity_frames >= frames {
            return Ok(());
        }
        unsafe {
            if !self.out_ptr.is_null() {
                ff::av_freep(&mut self.out_ptr as *mut *mut u8 as *mut c_void);
                self.out_ptr = ptr::null_mut();
            }
            let mut linesize: c_int = 0;
            let ret = ff::av_samples_alloc(
                &mut self.out_ptr,
                &mut linesize,
                channels as c_int,
                frames as c_int,
                sample_format_from(ff::AVSampleFormat::AV_SAMPLE_FMT_FLT as c_int),
                1,
            );
            if ret < 0 || self.out_ptr.is_null() {
                return Err(ffmpeg_err(ret, "av_samples_alloc"));
            }
            self.out_capacity_frames = frames;
        }
        Ok(())
    }

    fn update_info(&mut self, rate: c_int, channels: usize) {
        let Some(ch) = Channels::new(channels as u8).ok() else {
            return;
        };
        if let Some(info) = &mut self.info {
            if info.sample_rate != rate as u32 || info.channels != ch {
                *info = StreamInfo {
                    sample_rate: rate as u32,
                    channels: ch,
                    layout: info.layout,
                    format: info.format,
                };
            }
        }
    }

    pub fn seek(&mut self, pos: Duration) -> Result<(), SourceError> {
        let target_us = pos.as_micros().min(i64::MAX as u128) as i64;
        unsafe {
            let ret = ff::avformat_seek_file(
                self.format,
                -1,
                i64::MIN,
                target_us,
                target_us,
                AVSEEK_FLAG_BACKWARD,
            );
            if ret < 0 {
                return Err(ffmpeg_err(ret, "avformat_seek_file"));
            }
            ff::avcodec_flush_buffers(self.dec);
            if !self.swr.is_null() {
                ff::swr_close(self.swr);
                let r = ff::swr_init(self.swr);
                if r < 0 {
                    return Err(ffmpeg_err(r, "swr_init after seek"));
                }
            }
        }
        self.eof = false;
        self.input_done = false;
        self.flush_sent = false;
        self.trim_until_us = Some(target_us);
        Ok(())
    }

    pub fn reset(&mut self) -> Result<(), SourceError> {
        self.seek(Duration::ZERO)
    }
}

impl Drop for FfmpegReader {
    fn drop(&mut self) {
        let _ = &self.avio;
        unsafe {
            if !self.dec.is_null() {
                ff::avcodec_free_context(&mut self.dec);
            }
            if !self.swr.is_null() {
                ff::swr_free(&mut self.swr);
            }
            if !self.out_ptr.is_null() {
                ff::av_freep(&mut self.out_ptr as *mut *mut u8 as *mut c_void);
            }
            if !self.format.is_null() {
                ff::avformat_close_input(&mut self.format);
            }
        }
    }
}

fn ffmpeg_err(ret: c_int, what: &str) -> SourceError {
    SourceError::Decode(format!("{what}: {}", ffmpeg_err_str(ret)))
}

fn ffmpeg_err_str(ret: c_int) -> String {
    let mut buf = [0u8; 256];
    let n = unsafe { ff::av_strerror(ret, buf.as_mut_ptr() as *mut c_char, buf.len()) };
    if n < 0 {
        return format!("av error {ret}");
    }
    let end = buf.iter().position(|&b| b == 0).unwrap_or(buf.len());
    String::from_utf8_lossy(&buf[..end]).into_owned()
}

unsafe fn read_metadata(format: *mut ff::AVFormatContext) -> TrackMeta {
    let mut meta = TrackMeta::default();
    if format.is_null() {
        return meta;
    }
    let dict = (*format).metadata;
    if dict.is_null() {
        return meta;
    }
    let get = |key: &str| -> Option<String> {
        let ck = std::ffi::CString::new(key).ok()?;
        let e = ff::av_dict_get(dict, ck.as_ptr(), ptr::null(), 0);
        if e.is_null() {
            return None;
        }
        let v = (*e).value;
        if v.is_null() {
            return None;
        }
        Some(std::ffi::CStr::from_ptr(v).to_string_lossy().into_owned())
    };
    meta.title = get("title").filter(|s| !s.is_empty());
    meta.artist = get("artist")
        .or_else(|| get("album_artist"))
        .filter(|s| !s.is_empty());
    meta.album = get("album").filter(|s| !s.is_empty());
    if let Some(date) = get("date") {
        let year: String = date.chars().take(4).collect();
        meta.year = year.parse::<u32>().ok();
    }
    meta
}

unsafe fn stream_info_of(dec: *mut ff::AVCodecContext) -> Option<StreamInfo> {
    if dec.is_null() {
        return None;
    }
    let rate = (*dec).sample_rate;
    if rate <= 0 {
        return None;
    }
    let n = (*dec).ch_layout.nb_channels;
    if n <= 0 || n > 32 {
        return None;
    }
    let channels = Channels::new(n as u8).ok()?;
    let layout = match (*dec).ch_layout.order {
        ff::AVChannelOrder::AV_CHANNEL_ORDER_NATIVE => {
            let mask = (*dec).ch_layout.u.mask as u32;
            ChannelLayout::from_mask(mask_guard(mask, channels))
        }
        _ => caly_core::media::default_layout_for(channels),
    };
    Some(StreamInfo {
        sample_rate: rate as u32,
        channels,
        layout,
        format: crate::FfmpegSource::map_sample_format((*dec).sample_fmt as i32),
    })
}

fn mask_guard(mask: u32, channels: Channels) -> u32 {
    if mask == 0 || mask.count_ones() != channels.get() as u32 {
        caly_core::media::default_layout_for(channels).mask()
    } else {
        mask
    }
}
