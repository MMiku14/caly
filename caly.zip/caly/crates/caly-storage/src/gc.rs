//! Garbage collection over the CAS, per `RFC-0007 §13`.
//!
//! The RFC fixes both the root set and the behaviour rules, and `§15.6` states the acceptance
//! criterion: "GC 不删除被 Active/Snapshot/Journal 引用对象". This module implements that as
//! policy only: it decides *what may be collected*, and hands the deletions to `ObjectStore`.
//! The store stays policy-free on purpose (see `store.rs`), so an accidental
//! `store.delete(digest)` from anywhere else can never be mistaken for a GC-safe act.
//!
//! Why a separate module at all: until this change `ObjectStore` had no enumeration and no
//! deletion, so no backend could implement `§13` even in principle (`ONBOARDING_NOTES.md §4.18`).
//!
//! ## Grace period and the clock
//!
//! `§13.1` protects objects "尚在 grace period 内". There is no clock in this crate (the
//! workspace forbids wall-clock reads outside the gateway), so freshness is judged against
//! `GcPolicy::now_unix_ms`, supplied by the caller on the *same* injected timeline the apply
//! journal uses. `CasObjectRef::stored_at_unix_ms` is written by the store from the caller's
//! intent rather than invented here; when it is absent the object is treated as
//! forever-in-grace, i.e. never collectable. Unknowable freshness must not become a licence to
//! delete.

use std::collections::BTreeMap;

use crate::cas::{CasObjectRef, ObjectDigest};
use crate::execution::ApplyJournalRecord;
use crate::revision::RevisionRecord;
use crate::snapshot::SnapshotRecord;
use crate::store::{ObjectStore, StorageError};

/// Which root is protecting an object. Reported so `doctor` can explain a non-collection.
#[derive(Clone, Copy, Debug, Eq, PartialEq, Ord, PartialOrd)]
pub enum GcRootReason {
    ActiveSnapshot,
    LastKnownGood,
    RegisteredRevision,
    UnfinishedJournal,
    RunningJob,
    GracePeriod,
}

impl GcRootReason {
    pub fn as_str(self) -> &'static str {
        match self {
            Self::ActiveSnapshot => "active-snapshot",
            Self::LastKnownGood => "last-known-good",
            Self::RegisteredRevision => "registered-revision",
            Self::UnfinishedJournal => "unfinished-journal",
            Self::RunningJob => "running-job",
            Self::GracePeriod => "grace-period",
        }
    }
}

/// The set of CAS digests that must survive this cycle, with reasons.
#[derive(Clone, Debug, Default, Eq, PartialEq)]
pub struct GcRootSet {
    protected: BTreeMap<String, Vec<GcRootReason>>,
}

impl GcRootSet {
    fn protect(&mut self, digest: Option<&str>, reason: GcRootReason) {
        let Some(digest) = digest.filter(|value| !value.is_empty()) else {
            return;
        };
        let entry = self.protected.entry(digest.to_owned()).or_default();
        if !entry.contains(&reason) {
            entry.push(reason);
        }
    }

    pub fn protects(&self, digest: &str) -> bool {
        self.protected.contains_key(digest)
    }

    pub fn reasons_for(&self, digest: &str) -> &[GcRootReason] {
        self.protected.get(digest).map(Vec::as_slice).unwrap_or(&[])
    }

    pub fn len(&self) -> usize {
        self.protected.len()
    }

    pub fn is_empty(&self) -> bool {
        self.protected.is_empty()
    }

    pub fn digests(&self) -> Vec<String> {
        self.protected.keys().cloned().collect()
    }
}

/// Everything the root computation reads. Borrowed, so the caller keeps ownership of the records.
#[derive(Clone, Copy, Debug, Default)]
pub struct GcGraph<'a> {
    pub active_snapshot: Option<&'a SnapshotRecord>,
    pub last_known_good: Option<&'a SnapshotRecord>,
    /// Every snapshot the store still holds, not only the current one: superseded snapshots are
    /// what a rollback target reads (`STORAGE_RECOVERY_EXECUTION_PLAN.md §7.2`).
    pub retained_snapshots: &'a [SnapshotRecord],
    pub revisions: &'a [RevisionRecord],
    /// Pending *or* recovery-failed apply journals.
    pub unfinished_journals: &'a [ApplyJournalRecord],
    /// Artifact digests named by transactions that are still running.
    pub running_job_artifacts: &'a [String],
    /// Extra digests a caller wants pinned (e.g. a just-materialized runtime candidate).
    pub pinned: &'a [String],
}

/// Collection policy. Defaults are deliberately conservative.
#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub struct GcPolicy {
    /// Objects stored less than this many ms ago are retained (`§13.1`).
    pub grace_period_ms: i64,
    /// The caller's current time on the injected timeline.
    pub now_unix_ms: i64,
    /// Collect at most this many objects per cycle, so a bug cannot wipe a store in one go.
    pub max_deletions: usize,
}

impl Default for GcPolicy {
    fn default() -> Self {
        Self {
            grace_period_ms: 15 * 60 * 1000,
            now_unix_ms: 0,
            max_deletions: 256,
        }
    }
}

/// Why a GC cycle was not run. `§13.2`: GC *should* run only when idle with no pending
/// deployment; encoding that as a typed refusal is what keeps "I ran GC during an apply" from
/// becoming a plausible-looking accident.
#[derive(Clone, Debug, Eq, PartialEq)]
pub enum GcRefusal {
    NotIdle,
    PendingDeployments(usize),
    NothingToInspect,
}

#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub struct GcEligibility {
    pub idle: bool,
    pub pending_deployments: usize,
}

impl GcEligibility {
    pub fn check(&self) -> Result<(), GcRefusal> {
        if self.pending_deployments > 0 {
            return Err(GcRefusal::PendingDeployments(self.pending_deployments));
        }
        if !self.idle {
            return Err(GcRefusal::NotIdle);
        }
        Ok(())
    }
}

/// One blocked object, kept for reporting.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct GcBlocked {
    pub digest: String,
    pub reasons: Vec<GcRootReason>,
}

/// The decision: what to delete, what was protected and why.
#[derive(Clone, Debug, Default, Eq, PartialEq)]
pub struct GcPlan {
    pub collect: Vec<ObjectDigest>,
    pub retained: usize,
    pub blocked: Vec<GcBlocked>,
    pub skipped_for_grace: usize,
}

impl GcPlan {
    pub fn is_noop(&self) -> bool {
        self.collect.is_empty()
    }
}

/// Compute the root set for one cycle.
pub fn collect_gc_roots(
    graph: &GcGraph<'_>,
    policy: &GcPolicy,
    objects: &[CasObjectRef],
) -> GcRootSet {
    let mut roots = GcRootSet::default();

    for snapshot in graph.active_snapshot.into_iter() {
        roots.protect(
            Some(&snapshot.compiled_artifact_digest),
            GcRootReason::ActiveSnapshot,
        );
        roots.protect(
            Some(&snapshot.core_binary_digest),
            GcRootReason::ActiveSnapshot,
        );
    }
    for snapshot in graph.last_known_good.into_iter() {
        roots.protect(
            Some(&snapshot.compiled_artifact_digest),
            GcRootReason::LastKnownGood,
        );
        roots.protect(
            Some(&snapshot.core_binary_digest),
            GcRootReason::LastKnownGood,
        );
    }
    for snapshot in graph.retained_snapshots {
        roots.protect(
            Some(&snapshot.compiled_artifact_digest),
            GcRootReason::LastKnownGood,
        );
    }
    for revision in graph.revisions {
        roots.protect(
            Some(&revision.semantic_digest),
            GcRootReason::RegisteredRevision,
        );
    }
    for journal in graph.unfinished_journals {
        roots.protect(
            Some(&journal.compiled_artifact_digest),
            GcRootReason::UnfinishedJournal,
        );
        roots.protect(
            Some(&journal.semantic_digest),
            GcRootReason::UnfinishedJournal,
        );
    }
    for digest in graph.running_job_artifacts {
        roots.protect(Some(digest), GcRootReason::RunningJob);
    }
    for digest in graph.pinned {
        roots.protect(Some(digest), GcRootReason::RunningJob);
    }

    // Grace period: judged per object, because "new" is a property of the object, not the plan.
    for object in objects {
        match object.stored_at_unix_ms {
            // Unknown age => never collectable. Silent deletion is unrecoverable; a stale
            // object that survives one extra cycle is not.
            None => roots.protect(Some(&object.digest.0), GcRootReason::GracePeriod),
            Some(stored_at)
                if policy.now_unix_ms.saturating_sub(stored_at) < policy.grace_period_ms =>
            {
                roots.protect(Some(&object.digest.0), GcRootReason::GracePeriod)
            }
            Some(_) => {}
        }
    }
    roots
}

/// Decide what may be collected. Pure: no store access, so the decision can be asserted
/// independently of any backend.
pub fn plan_object_gc(objects: &[CasObjectRef], roots: &GcRootSet, policy: &GcPolicy) -> GcPlan {
    let mut plan = GcPlan::default();
    for object in objects {
        if roots.protects(&object.digest.0) {
            plan.retained += 1;
            let reasons = roots.reasons_for(&object.digest.0).to_vec();
            if reasons.contains(&GcRootReason::GracePeriod) && reasons.len() == 1 {
                plan.skipped_for_grace += 1;
            }
            plan.blocked.push(GcBlocked {
                digest: object.digest.0.clone(),
                reasons,
            });
            continue;
        }
        if plan.collect.len() >= policy.max_deletions {
            plan.blocked.push(GcBlocked {
                digest: object.digest.0.clone(),
                reasons: vec![],
            });
            continue;
        }
        plan.collect.push(object.digest.clone());
    }
    plan.blocked
        .sort_by(|left, right| left.digest.cmp(&right.digest));
    plan
}

/// What one collected cycle actually did.
#[derive(Clone, Debug, Default, Eq, PartialEq)]
pub struct GcReport {
    pub collected: Vec<ObjectDigest>,
    pub failed: Vec<(ObjectDigest, String)>,
    pub retained: usize,
}

impl GcReport {
    pub fn summary_line(&self) -> String {
        format!(
            "gc collected={} retained={} failed={}",
            self.collected.len(),
            self.retained,
            self.failed.len()
        )
    }
}

// -----------------------------------------------------------------------------
// Orphan content (`RFC-0007 §13`, the half the metadata-keyed plan cannot see)
// -----------------------------------------------------------------------------

/// One file found in the content tree, as the walk saw it.
///
/// The content tree (`objects/sha256/<p1>/<p2>/<rest>`, `RFC-0007 §6.1`) holds files that no
/// metadata record names back: the delete path removes metadata first and content second, so a
/// crash between the two leaves content with no reader; the write path lands content before any
/// metadata names it, so a crash there does the same. Until the walk existed, no code in this
/// workspace could see those files at all (`IMPLEMENTATION_STATUS §7` item 10) -- the GC candidate
/// set comes from `list_objects`, which enumerates *metadata*.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct ContentEntry {
    pub target: ContentTarget,
    /// The file's own mtime, when the port can answer. The only age evidence an orphan has:
    /// there is no metadata record to carry `stored_at_unix_ms`, so an entry with `None` is
    /// unageable and -- by the same rule as `collect_gc_roots` -- never collectable.
    pub modified_at_unix_ms: Option<i64>,
}

/// Which file in the content tree an entry is. Typed so a deletion can never be phrased as an
/// arbitrary store path: the store reconstructs the suffix itself, and a caller cannot aim the
/// sweep outside the two shapes this layout can explain.
#[derive(Clone, Debug, Eq, PartialEq, Ord, PartialOrd)]
pub enum ContentTarget {
    /// A content file under its digest path, `sha256:<hex>` exactly as `content_sha256` spells it.
    Anchor(String),
    /// `<name>.tmp-<digits>` beside a content target: the residue of an interrupted
    /// `write_atomic`. The same shape `FsStore::reap_residue` removes in the one-level store
    /// directories; three levels down, nothing reaped it until now.
    Residue {
        p1: String,
        p2: String,
        name: String,
    },
}

impl ContentTarget {
    /// The operator-facing spelling, used by the plan sample and the run record. Deliberately the
    /// *anchor* for content (`sha256:...`) and the *path* for residue (it has no digest to show).
    pub fn as_display(&self) -> String {
        match self {
            ContentTarget::Anchor(anchor) => anchor.clone(),
            ContentTarget::Residue { p1, p2, name } => {
                format!("objects/sha256/{p1}/{p2}/{name}")
            }
        }
    }
}

/// What the pure half decided about the content tree. Same shape as [`GcPlan`]: a collect list the
/// sweep executes, plus the counts that explain everything not on it.
#[derive(Clone, Debug, Default, Eq, PartialEq)]
pub struct OrphanContentPlan {
    /// Orphans past grace, in walk order, already inside the deletion budget the caller handed in.
    pub collect: Vec<ContentTarget>,
    /// Unreferenced entries kept only because their age is unknown or inside the grace period.
    pub skipped_for_grace: usize,
    /// Unreferenced, collectable, but beyond the remaining deletion budget. A later cycle takes
    /// them; the count exists so "collected fewer than planned" is never a mystery.
    pub deferred_over_cap: usize,
}

/// Decide what the sweep may take from the content tree. Pure, for the same reason
/// [`plan_object_gc`] is: the decision can be asserted without a backend.
///
/// * `referenced` is the set of `content_sha256` anchors live metadata still names. An anchor in
///   that set is **content**, not an orphan, whatever its age -- this is the check that makes the
///   sweep safe against its own race (a metadata write that lands between the enumeration and the
///   sweep is covered by the grace gate instead, which is why fresh orphans are kept).
/// * Residue is by construction never referenced: a temp file is a write that never published
///   (`reap_residue`'s argument, now applied three levels down), so only grace protects it -- a
///   *concurrent* writer's in-flight temp is fresh and therefore kept.
/// * The budget is the *remainder* of the cycle's `max_deletions`, so objects and content share
///   one bound instead of each getting a full copy of it.
pub fn plan_orphan_content(
    entries: &[ContentEntry],
    referenced: &std::collections::BTreeSet<String>,
    policy: &GcPolicy,
    remaining_budget: usize,
) -> OrphanContentPlan {
    let mut plan = OrphanContentPlan::default();
    for entry in entries {
        if let ContentTarget::Anchor(anchor) = &entry.target {
            if referenced.contains(anchor) {
                continue;
            }
        }
        let past_grace = match entry.modified_at_unix_ms {
            // Unknown age => never collectable. Same rule as `collect_gc_roots`, same reason:
            // silent deletion is unrecoverable, surviving one extra cycle is not.
            None => false,
            Some(modified_at) => {
                policy.now_unix_ms.saturating_sub(modified_at) >= policy.grace_period_ms
            }
        };
        if !past_grace {
            plan.skipped_for_grace += 1;
            continue;
        }
        if plan.collect.len() >= remaining_budget {
            plan.deferred_over_cap += 1;
            continue;
        }
        plan.collect.push(entry.target.clone());
    }
    plan
}

/// What one content sweep actually did. Kept per target, for the same reason `GcReport` is: a
/// sweep that silently deletes less than it was told is indistinguishable from one that worked.
#[derive(Clone, Debug, Default, Eq, PartialEq)]
pub struct ContentSweepReport {
    pub collected: Vec<String>,
    pub failed: Vec<(String, String)>,
}

/// Delete exactly the targets handed in, and report per target. Mirrors [`sweep_objects`]:
/// policy-free, per-target outcomes, one failure does not abort the rest (the next cycle retries).
pub async fn sweep_orphan_content(
    store: &dyn ObjectStore,
    targets: &[ContentTarget],
    ctx: &caly_io::IoContext,
) -> ContentSweepReport {
    let mut report = ContentSweepReport::default();
    for target in targets {
        match store.delete_content(target, ctx).await {
            Ok(true) => report.collected.push(target.as_display()),
            Ok(false) => report.failed.push((
                target.as_display(),
                "store reported nothing was removed".to_owned(),
            )),
            Err(error) => report.failed.push((target.as_display(), error.summary)),
        }
    }
    report
}

/// `§13.2` mark-then-sweep: the plan is computed first, then deletions are issued. A failure to
/// delete one object does not abort the cycle (the next cycle retries), but it is reported:
/// a collector that silently deletes less than it planned is indistinguishable from one that
/// worked.
pub async fn run_object_gc(
    store: &dyn ObjectStore,
    objects: &[CasObjectRef],
    graph: &GcGraph<'_>,
    policy: &GcPolicy,
    eligibility: GcEligibility,
    ctx: &caly_io::IoContext,
) -> Result<GcReport, StorageError> {
    eligibility.check().map_err(|refusal| {
        StorageError::new(
            crate::store::StorageErrorKind::Busy,
            format!("gc refused by policy: {refusal:?}"),
        )
    })?;
    if objects.is_empty() {
        return Err(StorageError::new(
            crate::store::StorageErrorKind::Internal,
            "gc called with an empty object set; enumerate first, then plan",
        ));
    }

    let roots = collect_gc_roots(graph, policy, objects);
    let plan = plan_object_gc(objects, &roots, policy);
    Ok(sweep_objects(store, &plan.collect, plan.retained, ctx).await)
}

/// Delete exactly the digests handed in, and report per object.
///
/// Split out of [`run_object_gc`] so that a caller which already computed a plan -- the engine's
/// `gc_plan` builder, which gates on root-set completeness before anything is swept -- executes
/// **that** list instead of re-deriving a second one. Two computations of "what is safe to delete" are
/// how a report and an action end up disagreeing; one list, passed along, cannot.
pub async fn sweep_objects(
    store: &dyn ObjectStore,
    digests: &[ObjectDigest],
    retained: usize,
    ctx: &caly_io::IoContext,
) -> GcReport {
    let mut report = GcReport {
        collected: Vec::new(),
        failed: Vec::new(),
        retained,
    };
    for digest in digests {
        match store.delete(&digest.0, ctx).await {
            Ok(true) => report.collected.push(digest.clone()),
            Ok(false) => report.failed.push((
                digest.clone(),
                "store reported nothing was removed".to_owned(),
            )),
            Err(error) => report.failed.push((digest.clone(), error.summary)),
        }
    }
    report
}
