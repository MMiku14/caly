#![forbid(unsafe_code)]

pub mod audit;
pub mod cas;
pub mod execution;
pub mod fs_store;
pub mod gc;
pub mod job_log;
pub mod journal;
pub mod memory;
pub mod port_drive;
pub mod record;
pub mod revision;
pub mod schema;
pub mod snapshot;
pub mod source;
pub mod store;

pub use audit::*;
pub use cas::*;
pub use execution::*;
pub use fs_store::*;
pub use gc::*;
pub use job_log::*;
pub use journal::*;
pub use memory::*;
pub use port_drive::*;
pub use record::*;
pub use revision::*;
pub use schema::*;
pub use snapshot::*;
pub use source::*;
pub use store::*;

pub const STORAGE_SCHEMA_VERSION: u32 = 1;
