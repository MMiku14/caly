//! Durable deployment-job log record shape (`ADR-057`).
//!
//! The storage crate deliberately does not depend on `caly-engine`'s `JobRecord` / `JobEvent`
//! (storage must not depend upward on the engine). It owns the durable envelope; the engine owns
//! the typed encode/decode of its domain events into these stable strings. The terminal state and
//! the stable public failure code are stored as plain strings so a restart can rebuild the same
//! summary a `jobs.follow` / `jobs.list` answer carried, without re-running the job.
//!
//! Durability (`ADR-014` tiers, decided in `ADR-057`): a job log record is written at the job's
//! **terminal** commit point as a D3 record (fsync + rename + dir fsync, same tier as a snapshot
//! commit). The engine keeps appending live events in memory; this record snapshots the retained
//! window of events at termination, so an in-flight crash leaves no job-log file and recovery
//! converges the job as it already does (`RFC-0005 §12`) — no partially-written history is ever
//! read back as fact.

/// One rendered deployment-job event, in the same text shape `jobs.events` prints.
///
/// `kind` is the event tag (`stage` / `log` / `warning` / `done` / `failed`). The storage layer
/// treats the line as an already-redacted, already-rendered string: it greps identically in a
/// support bundle, and the engine — which owns the rendering — is the only writer. A `failed`
/// event additionally carries the stable public code (see [`JobLogRecord::failure_code`]); the
/// line itself is for a human, the code is for exit-code mapping after a restart.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct JobEventRecord {
    pub kind: String,
    pub line: String,
}

/// The durable, terminal snapshot of one deployment job (`ADR-057`).
///
/// Written once when the job reaches a terminal state. Identity is `job_id`; the record directory
/// is keyed by it. `events` are the retained event lines in order (bounded by the engine's
/// retention window, the same window `jobs.events` pages). Counters are denormalised onto the
/// record so `jobs.list` / `jobs.follow` can answer without re-parsing every event.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct JobLogRecord {
    pub job_id: String,
    /// Terminal state name, matching the wire `state` field (`completed` / `failed` /
    /// `cancelled` / `timedout`).
    pub state: String,
    /// The state revision the job's write was accepted at.
    pub revision: u64,
    /// The terminal outcome name (`succeeded` / `failed` / `cancelled` / `timed_out`), or empty for
    /// a record that was persisted without a single terminal `done` event.
    pub outcome: Option<String>,
    /// Stable public failure code (e.g. `PERMISSION`, `STORAGE`) for a failed job; empty otherwise.
    /// This is what lets a post-restart `caly job <id>` map to the same documented exit code.
    pub failure_code: Option<String>,
    /// Short, already-redacted failure summary for a failed job.
    pub failure_summary: Option<String>,
    /// The last stage label the job reported, if any.
    pub last_stage: Option<String>,
    /// The last stage percentage the job reported (0–100), if any.
    pub last_stage_pct: Option<u8>,
    pub warning_count: usize,
    pub log_count: usize,
    /// Retained event lines, oldest first, in the order they were emitted.
    pub events: Vec<JobEventRecord>,
    /// When the record was committed, on the storage-injected clock (unix ms).
    pub committed_at_unix_ms: i64,
}
