//! Durable storage backend on top of the IO gateway.
//!
//! This is what turns `caly-storage` from "traits with one in-memory implementation" into an
//! actual transaction substrate (`docs/engineering/STORAGE_RECOVERY_EXECUTION_PLAN.md §12`).
//!
//! Two design points are forced rather than chosen:
//!
//! 1. **Every byte goes through `caly_io::Fs`.** `ADR-011` makes the port layer the only place
//!    allowed to touch the host, and `caly-io-std::StdFs` supplies `write_atomic` with the
//!    `ADR-014` durability tiers. There is deliberately no `std::fs` call in this crate, which is
//!    also why it stays inside the workspace-wide clippy bans.
//! 2. **Enumeration comes from the port.** `Fs::list` (`ADR-035`) answers "which journals are
//!    pending?" by listing the store's own directories, so a collection has exactly one truth: the
//!    files in it. An earlier revision kept a per-collection index file (`manifest/<kind>.idx`)
//!    written next to every record, which made "the index and the entities disagree" a normal
//!    failure mode -- `docs/history/ONBOARDING_NOTES.md §4.15` records it as the workaround for a port gap
//!    that gap no longer exists. Listing is bounded: a directory too large to enumerate is a
//!    `CapacityExceeded` refusal, never a short list, and a record that does not decode fails
//!    `open` rather than being skipped.
//!
//! Path bases, spelled out because the two are easy to confuse and the simulator cannot reveal the
//! difference:
//!
//! * `caly_io::Fs` paths are relative to *its own* root (for `StdFs`, the directory it was built with).
//! * `MaterializationRequest::runtime_path` is relative to the **store root** (`FsStore::open`'s
//!   `root` argument), because `FsStore` owns the prefixing. Passing an already-prefixed path
//!   produces `<root>/<root>/...`, which only a rooted backend can show.
//!
//! Layout, following `RFC-0007 §6.1`:
//!
//! ```text
//! <root>/objects/sha256/<aa>/<bb>/<rest>   content, addressed by the sha256 of its bytes
//! <root>/meta/objects/<xx>/<digest>.obj    object metadata, including content_sha256; <xx> is the
//!                                          first two hex of the sha256 of the escaped file name
//!                                          (`ADR-062` sharding; the flat layout was v1)
//! <root>/records/<kind>/<xx>/<id>.rec      revision / snapshot / journal / source-index records,
//!                                          sharded the same way, enumerated by walking the
//!                                          buckets (`ADR-035 §2.3` + `ADR-062`)
//! <root>/pointers/last-known-good          the single last-known-good marker
//! ```

use std::collections::BTreeMap;
use std::sync::{Arc, Mutex};

use caly_io::{BoxFuture, ByteCap, Durability, Fs, IoContext, IoFaultKind, ListCap, Meta, VPath};

use crate::cas::{CasObjectRef, CasWriteIntent, MaterializationMode, MaterializationRequest};
use crate::execution::{ApplyJournalRecord, ApplyJournalState, ApplyTxnId};
use crate::job_log::JobLogRecord;
use crate::journal::{JournalRecord, JournalRecordId, JournalState};
use crate::port_drive::{drive_port, from_iofault};
use crate::record::{
    decode_and_check, decode_apply_journal, decode_job_log, decode_object, decode_os_journal,
    decode_revision, decode_snapshot, decode_source_index, encode_apply_journal, encode_job_log,
    encode_object, encode_os_journal, encode_revision, encode_snapshot, encode_source_index,
};
use crate::revision::{RevisionId, RevisionRecord};
use crate::snapshot::{SnapshotRecord, SnapshotRecordId};
use crate::source::SourceIndexRecord;
use crate::store::{
    ApplyJournalStore, JobLogStore, JournalStore, ObjectStore, RevisionStore, SnapshotStore,
    StorageBackend, StorageError, StorageErrorKind,
};

/// Read budget for one record. They are small by construction; the cap exists so a replaced or
/// corrupted file cannot make the store allocate without bound (`RFC-0006 §5.3`).
const MAX_RECORD_BYTES: u64 = 1 << 20;

/// Objects can be arbitrarily large, so content reads get a larger (still bounded) cap.
const MAX_OBJECT_BYTES: u64 = 1 << 30;

/// How many files one store directory may hold (`ADR-035 §2.1`).
///
/// This bound replaces the one the deleted index layer imposed by accident: reading a manifest was
/// capped at [`MAX_RECORD_BYTES`], so an index too big to read was already a refusal. Enumeration
/// has to be bounded for the same reason, and exceeding it is an error rather than a short list.
///
/// Public so an operator-facing check can say what a store directory may hold, and so a test can
/// cross the line deliberately instead of duplicating the number.
pub const MAX_ENTRIES_PER_DIRECTORY: u32 = 4096;

/// The record collections this store owns. Boot verification, enumeration and rollback points all
/// walk this one list, so a new collection cannot be added to one of them and forgotten in another.
const RECORD_KINDS: [&str; 6] = [
    "revision",
    "snapshot",
    "os-journal",
    "apply-journal",
    "source-index",
    "job-log",
];

/// Where object metadata lives: one `.obj` file per digest, always in a single flat directory.
const OBJECT_DIRECTORY: &str = "meta/objects";

/// How many directories one content-tree walk may enumerate before it is called too big to judge.
///
/// The content tree fans out by hex prefix (`objects/sha256/<p1>/<p2>`, `RFC-0007 §6.1`): at most
/// 256 directories per level, in principle 65'536 at the leaf level. A store that dense is a store
/// a *plan* has no business summarising in one unbounded pass -- the walk is what decides what may
/// be **deleted**, so its cost must be bounded like every other bound in this crate (exceeding it
/// is a refusal, never a short list). Real stores sit far below it; the number exists so that
/// "walked 65k directories to delete one orphan" cannot become a silent shape.
///
/// Public so tests can push against the boundary from both sides, like
/// [`MAX_ENTRIES_PER_DIRECTORY`] and `STORE_PORT_POLL_BUDGET`.
pub const MAX_CONTENT_WALK_DIRECTORIES: usize = 1024;

const _: () = assert!(
    MAX_CONTENT_WALK_DIRECTORIES > 0,
    "a zero-directory budget would refuse every walk, including the walk of an empty tree"
);

const _: () = assert!(
    MAX_CONTENT_WALK_DIRECTORIES >= 4,
    "objects, objects/sha256, one prefix level and one leaf level is the smallest tree that can \
     hold one content file; a budget below that cannot express 'store has content' at all"
);

/// The content algorithm directory this layout freezes (`RFC-0007 §6.1`).
const CONTENT_ROOT: &str = "objects/sha256";

/// Whether a name is lowercase hex -- the only alphabet the content layout spells.
pub(crate) fn is_lower_hex(name: &str) -> bool {
    !name.is_empty()
        && name
            .bytes()
            .all(|byte| byte.is_ascii_digit() || (b'a'..=b'f').contains(&byte))
}

/// One file the content walk found: what it is, and the age evidence the port could give.
fn walk_stat(
    fs: &dyn Fs,
    root: &str,
    ctx: &IoContext,
    clock: Option<&dyn caly_io::Clock>,
    suffix: &str,
) -> Result<Option<caly_io::Meta>, StorageError> {
    let path = VPath::try_from_str(&format!("{root}/{suffix}"))
        .map_err(|error| StorageError::new(StorageErrorKind::Internal, error.message))?;
    match drive_port(fs.stat(&path, ctx), ctx, clock)? {
        Ok(meta) => Ok(meta),
        Err(fault) => Err(from_iofault(fault)),
    }
}

/// The store-relative suffix for a [`ContentTarget`], or a refusal when the target does not fit
/// the layout this store can explain.
///
/// Validation lives *here*, with the suffix construction, on purpose: `ContentTarget` is typed so
/// callers cannot phrase a deletion as a raw path, but a bogus anchor (`sha256:../../x`) would
/// still travel through `content_suffix_for` into a path the store never wrote. One function
/// A content anchor is `sha256:` + 64 hex characters (`caly_common::digest`); the layout spends the
/// first four on its two prefix directories, so a leaf name in `objects/sha256` is exactly 60.
/// The relationship is checked, not assumed (`CONTINUATION_PLAYBOOK`: constant relations get
/// `const _` asserts) -- a layout change that renamed this silently would misjudge every leaf.
const CONTENT_ANCHOR_HEX_LEN: usize = 64;
const CONTENT_LEAF_HEX_LEN: usize = CONTENT_ANCHOR_HEX_LEN - 4;
const _: () = assert!(CONTENT_LEAF_HEX_LEN == 60);

/// decides "explainable" and "where", so the two cannot disagree about the alphabet.
///
/// The admission half, separated so the **boot scan** refuses through the same door the GC path
/// already refuses through (`ADR-035 §6bis`: a record that cannot be explained is damage a boot
/// must not walk past -- and until round 38 the scan built a suffix from an unadmitted anchor,
/// misdiagnosing garbage as "missing content" at a path this tree could never hold).
pub(crate) fn admit_content_anchor(anchor: &str) -> Result<(), StorageError> {
    let Some(hex) = anchor.strip_prefix("sha256:") else {
        return Err(StorageError::new(
            StorageErrorKind::IntegrityViolation,
            format!("content anchor is not a sha256 reference: {anchor}"),
        ));
    };
    if !is_lower_hex(hex) {
        return Err(StorageError::new(
            StorageErrorKind::IntegrityViolation,
            format!("content anchor is not lowercase hex: {anchor}"),
        ));
    }
    // The layout needs two prefix characters, two more, and the remaining sixty
    // (`RFC-0007 §6.1`); a shorter anchor cannot name a file this tree could hold, and
    // building its suffix anyway is how a double slash became a path segment
    // (`objects/sha256/00//`) -- found by the contract suite, not by review. A longer, or
    // shorter-but-plausible, hex name is the same refusal: this tree only stores sha256.
    if hex.len() != CONTENT_ANCHOR_HEX_LEN {
        return Err(StorageError::new(
            StorageErrorKind::IntegrityViolation,
            format!(
                "content anchor is not a full {CONTENT_ANCHOR_HEX_LEN}-hex sha256 name: {anchor}"
            ),
        ));
    }
    Ok(())
}

pub(crate) fn content_suffix_for_target(
    target: &crate::gc::ContentTarget,
) -> Result<String, StorageError> {
    match target {
        crate::gc::ContentTarget::Anchor(anchor) => {
            admit_content_anchor(anchor)?;
            Ok(content_suffix_for(anchor))
        }
        crate::gc::ContentTarget::Residue { p1, p2, name } => {
            if !is_lower_hex(p1) || p1.len() != 2 || !is_lower_hex(p2) || p2.len() != 2 {
                return Err(StorageError::new(
                    StorageErrorKind::IntegrityViolation,
                    format!("residue path is not two hex prefixes: {p1}/{p2}"),
                ));
            }
            // A residue is `<hex>.tmp-<digits>` beside a content file: both halves must be the
            // shapes the writer produces, or the target is somebody else's file wearing a suffix.
            let stem = &name[..name.rfind(".tmp-").unwrap_or(0)];
            if !is_temp_residue(name) || !is_lower_hex(stem) || stem.len() != CONTENT_LEAF_HEX_LEN {
                return Err(StorageError::new(
                    StorageErrorKind::IntegrityViolation,
                    format!("residue name is not a temp write beside content: {name}"),
                ));
            }
            Ok(format!("{CONTENT_ROOT}/{p1}/{p2}/{name}"))
        }
    }
}

/// Walk the content tree and name every file it holds (`RFC-0007 §6.1`, the half `list_objects`
/// cannot see).
///
/// Three rules, each the same rule the one-level directories already follow:
///
/// * **One level per call.** The port guarantees one-level listing; the walk composes three of
///   them (algorithm directory, prefix, leaf) rather than asking the port for a recursion it never
///   promised (`ADR-035 §2.1`). A fourth level (`objects/` itself) is checked only to refuse
///   anything but the frozen `sha256` directory.
/// * **Explainable or refusal.** A name that is not lowercase hex (at the prefix levels, exactly
///   two characters) or a residue name at the leaves is damage: `IntegrityViolation`, never a
///   silent skip. A directory that cannot be listed or a file that cannot be stat-ed propagates
///   as-is. The caller that turns this into a *gap* rather than a crash keeps every other line of
///   the plan alive -- but it must not hand out a deletion list over a tree it could not read.
/// * **Bounded.** `dir_budget` counts every enumerated directory; exceeding it is
///   `CapacityExceeded`, not a partial walk. Production passes [`MAX_CONTENT_WALK_DIRECTORIES`];
///   tests pass small numbers so the boundary is measured from both sides.
pub fn walk_content_tree(
    fs: &dyn Fs,
    root: &str,
    ctx: &IoContext,
    clock: Option<&dyn caly_io::Clock>,
    dir_budget: usize,
) -> Result<Vec<crate::gc::ContentEntry>, StorageError> {
    let mut visited = 0usize;
    // Budget and cancellation are spent at the same gate, on purpose: a level of the walk is the
    // unit of work both of them count (`ADR-039 §2.3` -- cancelled refuses *new* units; the unit
    // in flight completes). The first spend is the walk's up-front check.
    let spend = |visited: &mut usize| -> Result<(), StorageError> {
        if ctx.cancel.is_cancelled() {
            return Err(StorageError::new(
                StorageErrorKind::Cancelled,
                "the caller cancelled before this level of the content walk",
            ));
        }
        *visited += 1;
        if *visited > dir_budget {
            return Err(StorageError::new(
                StorageErrorKind::CapacityExceeded,
                format!(
                    "content walk exceeded its directory budget ({dir_budget}); the tree is too \
                     dense to judge in one pass"
                ),
            ));
        }
        Ok(())
    };

    // Level 0: the algorithm directory is frozen to `sha256`. Anything else under `objects/` is a
    // layout this store cannot explain -- reported, because a sweep that silently ignores half of
    // `objects/` is a sweep that reports "clean" over bytes it never looked at.
    spend(&mut visited)?;
    let algos = list_directory(
        fs,
        root,
        ctx,
        clock,
        "objects",
        ListCap(MAX_ENTRIES_PER_DIRECTORY),
    )?;
    for suffix in algos {
        let name = suffix.rsplit('/').next().unwrap_or(&suffix);
        if name != "sha256" {
            return Err(StorageError::new(
                StorageErrorKind::IntegrityViolation,
                format!("unexpected entry in the content tree: {suffix}"),
            ));
        }
    }

    spend(&mut visited)?;
    let prefixes = list_directory(
        fs,
        root,
        ctx,
        clock,
        CONTENT_ROOT,
        ListCap(MAX_ENTRIES_PER_DIRECTORY),
    )?;

    let mut entries = Vec::new();
    for prefix_suffix in prefixes {
        let p1 = prefix_suffix
            .rsplit('/')
            .next()
            .unwrap_or(&prefix_suffix)
            .to_owned();
        if !is_lower_hex(&p1) || p1.len() != 2 {
            return Err(StorageError::new(
                StorageErrorKind::IntegrityViolation,
                format!("unexpected entry in the content tree: {prefix_suffix}"),
            ));
        }
        let meta = walk_stat(fs, root, ctx, clock, &prefix_suffix)?.ok_or_else(|| {
            StorageError::new(
                StorageErrorKind::IntegrityViolation,
                format!("listed but gone when stat-ed: {prefix_suffix}"),
            )
        })?;
        if !meta.is_dir {
            return Err(StorageError::new(
                StorageErrorKind::IntegrityViolation,
                format!("unexpected file in the content tree: {prefix_suffix}"),
            ));
        }

        spend(&mut visited)?;
        let leaves = list_directory(
            fs,
            root,
            ctx,
            clock,
            &prefix_suffix,
            ListCap(MAX_ENTRIES_PER_DIRECTORY),
        )?;
        for leaf_suffix in leaves {
            let p2 = leaf_suffix
                .rsplit('/')
                .next()
                .unwrap_or(&leaf_suffix)
                .to_owned();
            if !is_lower_hex(&p2) || p2.len() != 2 {
                return Err(StorageError::new(
                    StorageErrorKind::IntegrityViolation,
                    format!("unexpected entry in the content tree: {leaf_suffix}"),
                ));
            }
            let meta = walk_stat(fs, root, ctx, clock, &leaf_suffix)?.ok_or_else(|| {
                StorageError::new(
                    StorageErrorKind::IntegrityViolation,
                    format!("listed but gone when stat-ed: {leaf_suffix}"),
                )
            })?;
            if !meta.is_dir {
                return Err(StorageError::new(
                    StorageErrorKind::IntegrityViolation,
                    format!("unexpected file in the content tree: {leaf_suffix}"),
                ));
            }

            spend(&mut visited)?;
            let files = list_directory(
                fs,
                root,
                ctx,
                clock,
                &leaf_suffix,
                ListCap(MAX_ENTRIES_PER_DIRECTORY),
            )?;
            for file_suffix in files {
                let name = file_suffix
                    .rsplit('/')
                    .next()
                    .unwrap_or(&file_suffix)
                    .to_owned();
                let meta = walk_stat(fs, root, ctx, clock, &file_suffix)?.ok_or_else(|| {
                    StorageError::new(
                        StorageErrorKind::IntegrityViolation,
                        format!("listed but gone when stat-ed: {file_suffix}"),
                    )
                })?;
                if !meta.is_file {
                    return Err(StorageError::new(
                        StorageErrorKind::IntegrityViolation,
                        format!("unexpected directory entry in the content tree: {file_suffix}"),
                    ));
                }
                // Both names a healthy leaf can wear share the same 60 hex characters: the
                // content file itself, or its temp twin (`<stem>.tmp-<digits>`). Anything else --
                // hex of another length included -- is damage the walk refuses to translate into
                // a deletable target: a leaf called `ff` is not the anchor `sha256:abcdff`.
                let stem = &name[..name.rfind(".tmp-").unwrap_or(0)];
                let target = if is_temp_residue(&name)
                    && is_lower_hex(stem)
                    && stem.len() == CONTENT_LEAF_HEX_LEN
                {
                    crate::gc::ContentTarget::Residue {
                        p1: p1.clone(),
                        p2: p2.clone(),
                        name,
                    }
                } else if is_lower_hex(&name) && name.len() == CONTENT_LEAF_HEX_LEN {
                    crate::gc::ContentTarget::Anchor(format!("sha256:{p1}{p2}{name}"))
                } else {
                    return Err(StorageError::new(
                        StorageErrorKind::IntegrityViolation,
                        format!("unexpected file in the content tree: {file_suffix}"),
                    ));
                };
                entries.push(crate::gc::ContentEntry {
                    target,
                    modified_at_unix_ms: meta.modified_at_unix_ms,
                });
            }
        }
    }
    Ok(entries)
}

/// A durable backend whose persistence goes through the `Fs` port.
#[derive(Clone)]
pub struct FsStore {
    inner: Arc<StoreInner>,
}

impl std::fmt::Debug for FsStore {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        f.debug_struct("FsStore")
            .field("root", &self.inner.root)
            .field(
                "objects",
                &self.inner.objects.lock().map(|g| g.len()).unwrap_or(0),
            )
            .field(
                "apply_journals",
                &self
                    .inner
                    .apply_journals
                    .lock()
                    .map(|g| g.len())
                    .unwrap_or(0),
            )
            .finish()
    }
}

struct StoreInner {
    fs: Box<dyn Fs>,
    root: String,
    /// The clock caller deadlines are judged against (`ADR-039 §2`, step 3). `None` -- the
    /// default at `open` -- means deadlines on contexts are *ignored*, never guessed: only the
    /// clock's owner may say the time is up (`§4.86`). Injected with [`FsStore::with_clock`].
    clock: Option<Arc<dyn caly_io::Clock>>,
    /// What the schema gate established at open time.
    schema_version: u32,
    migrations_applied: u32,
    revisions: Mutex<BTreeMap<String, RevisionRecord>>,
    snapshots: Mutex<BTreeMap<String, SnapshotRecord>>,
    journals: Mutex<BTreeMap<String, JournalRecord>>,
    apply_journals: Mutex<BTreeMap<String, ApplyJournalRecord>>,
    source_indexes: Mutex<BTreeMap<String, SourceIndexRecord>>,
    job_logs: Mutex<BTreeMap<String, JobLogRecord>>,
    objects: Mutex<BTreeMap<String, CasObjectRef>>,
}

#[derive(Clone, Debug, Eq, PartialEq, Default)]
pub struct FsStoreError {
    pub summary: String,
    /// Set when the refusal came from the schema gate (`RFC-0007 §12.2`), which is a different
    /// operator action than "the files are damaged".
    pub schema: Option<crate::schema::SchemaRefusal>,
}

impl FsStore {
    /// Open (or create) a store rooted at `root`, a *relative* path such as `"var/caly"`.
    ///
    /// Existing manifests are loaded, so constructing a second `FsStore` over the same `Fs` is
    /// exactly a daemon restart: the only thing it can know is what survived on disk. A record
    /// that fails to decode, or whose content no longer matches its digest, makes `open` fail
    /// rather than being skipped: silently dropping a corrupt journal entry is how a recovery
    /// scan ends up reporting "clean" about a half-applied deployment.
    pub fn open(fs: Box<dyn Fs>, root: &str) -> Result<Self, FsStoreError> {
        Self::open_with_migrations(fs, root, &crate::schema::MigrationChain::empty(), false)
    }

    /// Open with a migration chain available, and optionally accept an unversioned-but-empty
    /// directory as new.
    ///
    /// The schema gate runs **before** any record is read: `§12.2.1` requires the compatibility
    /// check first, and reading a layout this build does not understand is exactly what `§12.3`
    /// forbids.
    pub fn open_with_migrations(
        fs: Box<dyn Fs>,
        root: &str,
        chain: &crate::schema::MigrationChain,
        assume_fresh: bool,
    ) -> Result<Self, FsStoreError> {
        let parsed = VPath::try_from_str(root).map_err(|error| FsStoreError {
            summary: format!(
                "store root {root:?} is not a valid relative path: {}",
                error.message
            ),
            schema: None,
        })?;
        // The gate runs before anything is read: `§12.2.1` requires the compatibility check
        // first, and `§12.3` forbids interpreting a layout this build does not understand.
        // Open-time work is store-originated, so it carries a store-made context labelled as
        // such (`ADR-039 §2.4`: self-originated work never borrows a caller's identity). It is
        // local on purpose -- the old stored `ctx` field attributed *every* future port call to
        // this one ghost identity, which is the lie this ADR removes.
        let ctx = caly_io::RequestContext::new(
            caly_io::TraceId::new("storage-open"),
            caly_io::Actor::System,
        );
        let root = parsed.as_relative_path().to_owned();
        let marker = crate::schema::gate(
            fs.as_ref(),
            &root,
            &ctx,
            crate::STORAGE_SCHEMA_VERSION,
            chain,
            assume_fresh,
        )
        .map_err(|refusal| FsStoreError {
            summary: format!("schema gate refused to open the store: {}", refusal.summary),
            schema: Some(refusal),
        })?;

        let store = Self {
            inner: Arc::new(StoreInner {
                fs,
                root,
                clock: None,
                revisions: Mutex::new(BTreeMap::new()),
                snapshots: Mutex::new(BTreeMap::new()),
                journals: Mutex::new(BTreeMap::new()),
                apply_journals: Mutex::new(BTreeMap::new()),
                source_indexes: Mutex::new(BTreeMap::new()),
                job_logs: Mutex::new(BTreeMap::new()),
                objects: Mutex::new(BTreeMap::new()),
                schema_version: marker.storage_schema,
                migrations_applied: marker.migrations_applied,
            }),
        };
        store.load(&ctx).map_err(|summary| FsStoreError {
            summary,
            schema: None,
        })?;
        Ok(store)
    }

    /// The schema this directory is recorded as, once open.
    pub fn storage_schema_version(&self) -> u32 {
        crate::STORAGE_SCHEMA_VERSION
    }

    pub fn root(&self) -> &str {
        &self.inner.root
    }

    fn path(&self, suffix: &str) -> Result<VPath, StorageError> {
        VPath::try_from_str(&format!("{}/{}", self.inner.root, suffix))
            .map_err(|error| StorageError::new(StorageErrorKind::Internal, error.message))
    }

    fn write_bytes(
        &self,
        suffix: &str,
        bytes: Vec<u8>,
        durability: Durability,
        ctx: &IoContext,
    ) -> Result<(), StorageError> {
        let path = self.path(suffix)?;
        // Cumulative budget first (`ADR-039 §2` step 2): a write knows its size before it moves,
        // so it is refused before any byte lands -- a refused write must leave the disk as it was.
        // The port's own per-call `check_payload` still applies underneath; this is the caller's
        // scope on top of it.
        caly_io::budget::admit_bytes(ctx, suffix, bytes.len() as u64).map_err(from_iofault)?;
        let moved = bytes.len() as u64;
        drive_port(
            self.inner.fs.write_atomic(&path, bytes, durability, ctx),
            ctx,
            self.inner.clock.as_deref(),
        )?
        .map_err(from_iofault)?;
        caly_io::budget::charge(ctx, moved);
        Ok(())
    }

    fn read_bytes(
        &self,
        suffix: &str,
        cap: u64,
        ctx: &IoContext,
    ) -> Result<Option<Vec<u8>>, StorageError> {
        let path = self.path(suffix)?;
        // A read discovers its size by moving the bytes, so the cumulative gate is "is anything
        // left" (`admit_unit`): the unit in flight completes, charges what it actually moved, and
        // the *next* unit refuses -- the same in-flight discipline as cancellation (`ADR-039 §2.3`).
        caly_io::budget::admit_unit(ctx, suffix).map_err(from_iofault)?;
        match drive_port(
            self.inner.fs.read(&path, ByteCap(cap), ctx),
            ctx,
            self.inner.clock.as_deref(),
        )? {
            Ok(bytes) => {
                caly_io::budget::charge(ctx, bytes.len() as u64);
                Ok(Some(bytes))
            }
            Err(fault) if fault.kind == IoFaultKind::NotFound => Ok(None),
            Err(fault) => Err(from_iofault(fault)),
        }
    }

    fn write_text(
        &self,
        suffix: &str,
        text: &str,
        durability: Durability,
        ctx: &IoContext,
    ) -> Result<(), StorageError> {
        self.write_bytes(suffix, text.as_bytes().to_vec(), durability, ctx)
    }

    fn read_text(&self, suffix: &str, ctx: &IoContext) -> Result<Option<String>, StorageError> {
        match self.read_bytes(suffix, MAX_RECORD_BYTES, ctx)? {
            Some(bytes) => String::from_utf8(bytes).map(Some).map_err(|_| {
                StorageError::new(
                    StorageErrorKind::IntegrityViolation,
                    format!("record at {suffix} is not valid utf-8"),
                )
            }),
            None => Ok(None),
        }
    }

    /// The recorded size of a file, or `None` when it does not exist.
    fn stat_size(&self, suffix: &str, ctx: &IoContext) -> Result<Option<u64>, StorageError> {
        let path = self.path(suffix)?;
        drive_port(
            self.inner.fs.stat(&path, ctx),
            ctx,
            self.inner.clock.as_deref(),
        )?
        .map_err(from_iofault)
        .map(|meta| meta.map(|meta| meta.len))
    }

    /// Existence, without reading the body. Used by the audit probes, where "not there" is the
    /// answer and a read error is not.
    fn exists(&self, suffix: &str, ctx: &IoContext) -> Result<bool, StorageError> {
        let path = self.path(suffix)?;
        drive_port(
            self.inner.fs.stat(&path, ctx),
            ctx,
            self.inner.clock.as_deref(),
        )?
        .map_err(from_iofault)
        .map(|meta| meta.is_some())
    }

    fn record_path(kind: &str, id: &str) -> String {
        let stem = escape_component(id);
        format!("records/{kind}/{}/{stem}.rec", record_shard(&stem))
    }

    /// Where the records of one collection live, in store-relative suffix form.
    fn record_directory(kind: &str) -> String {
        format!("records/{kind}")
    }

    /// The store-relative paths of the files in one of the store's own directories.
    fn list_suffixes(&self, dir: &str, ctx: &IoContext) -> Result<Vec<String>, StorageError> {
        list_directory(
            self.inner.fs.as_ref(),
            &self.inner.root,
            ctx,
            self.inner.clock.as_deref(),
            dir,
            ListCap(MAX_ENTRIES_PER_DIRECTORY),
        )
    }

    /// The record files in one store directory, sorted, and nothing else.
    ///
    /// The layout reserves `.rec` / `.obj` names for records, so a file with any other name is
    /// either damage or somebody else's data -- both are answers the store must not invent. The
    /// index this function replaced could not see such a file at all, which makes this check the
    /// part of "the directory is the truth" that is a strict improvement rather than a trade-off.
    fn list_records(&self, dir: &str, ctx: &IoContext) -> Result<Vec<String>, StorageError> {
        // Sharded one level (`ADR-062 §2.1`): the top level holds only bucket names
        // (exactly two lower-hex characters) and write residue; the records live inside
        // the buckets. A flat record file at the top level is a v1 store the schema gate
        // has not migrated (or damage) -- both are answers the store must not invent, so
        // the name is refused, not silently read from a path v2 would never occupy.
        let mut records = Vec::new();
        for top in self.list_suffixes(dir, ctx)? {
            let name = top.rsplit('/').next().unwrap_or(&top);
            if is_temp_residue(name) {
                continue;
            }
            if is_lower_hex(name) && name.len() == 2 {
                for suffix in self.list_suffixes(&top, ctx)? {
                    let inner = suffix.rsplit('/').next().unwrap_or(&suffix);
                    if is_temp_residue(inner) {
                        continue;
                    }
                    if !is_record_name(inner) {
                        return Err(StorageError::new(
                            StorageErrorKind::IntegrityViolation,
                            format!("unexpected file in {top}: {inner}"),
                        ));
                    }
                    records.push(suffix);
                }
                continue;
            }
            if is_record_name(name) {
                return Err(StorageError::new(
                    StorageErrorKind::IntegrityViolation,
                    format!(
                        "flat record {top} in {dir}: records live in hash buckets \
                         (ADR-062) -- an unmigrated v1 store or damage"
                    ),
                ));
            }
            return Err(StorageError::new(
                StorageErrorKind::IntegrityViolation,
                format!("unexpected file in {dir}: {name}"),
            ));
        }
        Ok(records)
    }

    /// Remove the write residue of a crashed process from every store directory.
    ///
    /// A temp file is by construction a write that never published: `StdFs::write_atomic` renames it
    /// into place or fails, so nothing may read it. It is not data, but it does occupy the
    /// enumeration budget -- and a crash loop that leaves one behind per attempt would eventually
    /// make `open` refuse to boot for want of [`MAX_ENTRIES_PER_DIRECTORY`] slots, which is why
    /// reaping is the necessary companion of the bound rather than a cosmetic touch. A residue that
    /// cannot be removed is left for the next boot: refusing to start over a file the store will
    /// never read would trade a real start-up for a cosmetic one. Likewise a directory that cannot
    /// be listed is skipped here, because the enumeration right after this reports the same fault
    /// with the message a caller should actually see.
    fn reap_residue(&self, ctx: &IoContext) {
        let mut dirs = vec![OBJECT_DIRECTORY.to_owned()];
        dirs.extend(RECORD_KINDS.map(Self::record_directory));
        for dir in dirs {
            let Ok(tops) = self.list_suffixes(&dir, ctx) else {
                continue;
            };
            for top in tops {
                let name = top.rsplit('/').next().unwrap_or(&top);
                // Buckets hold their own write residue (`ADR-062`); one crash can leave a
                // temp file beside the record it was publishing, inside the bucket.
                if is_lower_hex(name) && name.len() == 2 {
                    let Ok(entries) = self.list_suffixes(&top, ctx) else {
                        continue;
                    };
                    for entry in entries {
                        let inner = entry.rsplit('/').next().unwrap_or(&entry);
                        if is_temp_residue(inner) {
                            let _ = self.delete_text(&entry, ctx);
                        }
                    }
                    continue;
                }
                if is_temp_residue(name) {
                    let _ = self.delete_text(&top, ctx);
                }
            }
        }
    }

    /// Read every collection off the disk, and refuse to open if the disk cannot be explained.
    ///
    /// `ADR-035 §6bis` kept this verification when the index layer was deleted, because the question
    /// it answers was never "does the index match?" but "are the entities self-consistent?" -- a
    /// record that cannot be decoded, or content that no longer matches its anchor, is damage that
    /// a boot must not walk past. What step 2 does give up is the other half of what an index could
    /// detect: a record file removed out of band is now simply absent, since nothing is left to
    /// disagree with. That is the accepted cost, written down in `ADR-035 §6bis-ter`; the
    /// last-known-good pointer and the content anchors are the checks that survive, and both still
    /// refuse the boot.
    fn load(&self, ctx: &IoContext) -> Result<(), String> {
        let mut problems = Vec::new();
        self.reap_residue(ctx);

        for suffix in self.list_records(OBJECT_DIRECTORY, ctx).map_err(text)? {
            let Some(raw) = self.read_text(&suffix, ctx).map_err(text)? else {
                problems.push(format!("object record vanished while reading: {suffix}"));
                continue;
            };
            let object = match decode_and_check(&raw, "object", decode_object).and_then(|object| {
                self.dated(object, &suffix, ctx)
                    .map_err(|error| error.summary)
            }) {
                Ok(object) => object,
                Err(summary) => {
                    problems.push(format!("object record {suffix}: {summary}"));
                    continue;
                }
            };
            // The record's own name is part of its claim (`ADR-041`): a file whose stem is not
            // what `escape_component` would produce for the digest it records is either a legacy
            // tree from the flattening era or a forgery, and a boot must not load it under a
            // name it would never have occupied.
            let stem = escape_component(&object.digest.0);
            let expected = format!("{OBJECT_DIRECTORY}/{}/{stem}.obj", record_shard(&stem));
            if suffix != expected {
                problems.push(format!(
                    "object record {suffix} is not the path its digest ({}) would occupy \
                     -- legacy or forged naming, or the wrong bucket (ADR-062)",
                    object.digest.0
                ));
                continue;
            }
            if let Some(anchor) = &object.content_sha256 {
                // Admission before the path: an anchor a writer could not have produced is
                // damage in the record, not a missing file at a phantom path -- and saying so
                // here is what keeps a `..` anchor from ever becoming a suffix for `read_bytes`.
                if let Err(refusal) = admit_content_anchor(anchor) {
                    problems.push(format!(
                        "object {} records a malformed content anchor: {}",
                        object.digest.0, refusal.summary
                    ));
                    continue;
                }
                let content_suffix = content_suffix_for(anchor);
                match self
                    .read_bytes(&content_suffix, MAX_OBJECT_BYTES, ctx)
                    .map_err(text)?
                {
                    Some(bytes) => {
                        if !caly_common::digest::sha256_matches(anchor, &bytes) {
                            problems.push(format!(
                                "object {} content no longer matches {}",
                                object.digest.0, anchor
                            ));
                        }
                    }
                    None => problems.push(format!(
                        "object {} references missing content {}",
                        object.digest.0, content_suffix
                    )),
                }
            }
            lock(&self.inner.objects).insert(object.digest.0.clone(), object);
        }

        for kind in RECORD_KINDS {
            let dir = Self::record_directory(kind);
            for suffix in self.list_records(&dir, ctx).map_err(text)? {
                let Some(raw) = self.read_text(&suffix, ctx).map_err(text)? else {
                    problems.push(format!("{kind} record vanished while reading: {suffix}"));
                    continue;
                };
                // Every family now carries the same claim its objects do (`ADR-041`): the file's
                // name is `escape_component` of the id inside, so a flattened-era name, a raw
                // un-escaped id, or a forgery is refused by name instead of loading under a key
                // it would never have occupied.
                let mut name_claim = |id: &str| {
                    let stem = escape_component(id);
                    let expected = format!("records/{kind}/{}/{stem}.rec", record_shard(&stem));
                    if suffix != expected {
                        problems.push(format!(
                            "{kind} record {suffix} is not the path its id ({id}) would occupy \
                             -- legacy or forged naming, or the wrong bucket (ADR-062)"
                        ));
                    }
                };
                let result = match kind {
                    "revision" => decode_and_check(&raw, kind, decode_revision).map(|record| {
                        name_claim(&record.id.0.clone());
                        lock(&self.inner.revisions).insert(record.id.0.clone(), record);
                    }),
                    "snapshot" => decode_and_check(&raw, kind, decode_snapshot).map(|record| {
                        name_claim(&record.id.0.clone());
                        lock(&self.inner.snapshots).insert(record.id.0.clone(), record);
                    }),
                    "os-journal" => decode_and_check(&raw, kind, decode_os_journal).map(|record| {
                        name_claim(&record.id.0.clone());
                        lock(&self.inner.journals).insert(record.id.0.clone(), record);
                    }),
                    "source-index" => {
                        decode_and_check(&raw, kind, decode_source_index).map(|record| {
                            name_claim(&record.source_id.clone());
                            lock(&self.inner.source_indexes)
                                .insert(record.source_id.clone(), record);
                        })
                    }
                    "job-log" => decode_and_check(&raw, kind, decode_job_log).map(|record| {
                        name_claim(&record.job_id.clone());
                        lock(&self.inner.job_logs).insert(record.job_id.clone(), record);
                    }),
                    _ => decode_and_check(&raw, kind, decode_apply_journal).map(|record| {
                        name_claim(&record.apply_txn_id.0.clone());
                        lock(&self.inner.apply_journals)
                            .insert(record.apply_txn_id.0.clone(), record);
                    }),
                };
                if let Err(summary) = result {
                    problems.push(format!("{kind} record {suffix}: {summary}"));
                }
            }
        }

        if problems.is_empty() {
            Ok(())
        } else {
            Err(problems.join("; "))
        }
    }

    /// Date one object record with the port's own evidence.
    ///
    /// `CasObjectRef::stored_at_unix_ms` as written is an **assertion** the caller made
    /// (`CasWriteIntent::stored_at_unix_ms`); the metadata file's mtime is **evidence** the port
    /// observed. `ADR-035 §2.4` lands step 3 by preferring the evidence, and the two are combined
    /// by keeping the *newer* one. That direction is the only safe one: the single mistake this field
    /// can cause is a garbage collector deleting something too early, and "looked older than it is"
    /// is how that happens. A caller claiming an absurdly old time (or a restored file whose mtime
    /// went backwards) therefore cannot shorten protection -- at worst an object is retained one
    /// cycle longer, which is the reversible direction (`docs/history/ONBOARDING_NOTES.md §4.20`).
    ///
    /// No clock, no evidence: `SimFs` reports `None` unless it was built `with_clock`, so the
    /// record's own value survives as the documented fallback, and a store with neither keeps the
    /// "unknown age is never collectable" rule intact.
    ///
    /// One `stat` per record on the **single-object** paths (`get`, `put`, `open`), the
    /// cost `ADR-035 §3` accepted when it rejected rich `list` entries ("批量 stat 属于后续
    /// `stat_many` 的优化"). The **batch** path (`object_records`) no longer pays that: it
    /// dates its whole directory with one `stat_many` port call (`ADR-054 §2.3`), which is
    /// the step that sentence registered.
    fn dated(
        &self,
        object: CasObjectRef,
        suffix: &str,
        ctx: &IoContext,
    ) -> Result<CasObjectRef, StorageError> {
        let path = self.path(suffix)?;
        let meta = drive_port(
            self.inner.fs.stat(&path, ctx),
            ctx,
            self.inner.clock.as_deref(),
        )?
        .map_err(from_iofault)?;
        Ok(self.date_object(object, meta))
    }

    /// Apply one port answer to one object's age: port evidence and the caller's claim are
    /// merged by the whichever-is-newer rule (`ADR-035 §6bis-quater` — both sources can lie
    /// in the lossy direction, and "looks older" is the dangerous one). Shared by the
    /// single-object `dated` and the `object_records` batch (`ADR-054 §2.3`), so a record's
    /// age cannot depend on which reading asked for it.
    fn date_object(&self, mut object: CasObjectRef, meta: Option<Meta>) -> CasObjectRef {
        if let Some(port_mtime) = meta.and_then(|meta| meta.modified_at_unix_ms) {
            object.stored_at_unix_ms = Some(
                object
                    .stored_at_unix_ms
                    .map_or(port_mtime, |claim| claim.max(port_mtime)),
            );
        }
        object
    }

    /// Every object record on disk, decoded and sorted by digest.
    ///
    /// Enumeration of the metadata directory *is* the answer, so a `list` that refused surfaces as a
    /// `CapacityExceeded` error rather than as a short list a caller cannot tell apart from "that is
    /// all there is". Sorting is not cosmetic: the support bundle and the audit both export this
    /// list, and `ADR-022` requires the same order out of the simulator and a real disk.
    fn object_records(&self, ctx: &IoContext) -> Result<Vec<CasObjectRef>, StorageError> {
        // One list, one bulk date: the records are read and decoded individually (each is its
        // own file), but their ages come from ONE `stat_many` port call instead of N `stat`s —
        // `ADR-035 §6bis-quater` registered exactly this as the next step ("stat_many 因此是
        // 这条链上明确记下的下一步优化"), and `ADR-054 §2.1` pins that each batch entry is
        // byte-identical to the one-by-one answer.
        let suffixes = self.list_records(OBJECT_DIRECTORY, ctx)?;
        let mut undated = Vec::new();
        for suffix in &suffixes {
            if let Some(object) = self.read_object_record_undated(suffix, ctx)? {
                undated.push((suffix.clone(), object));
            }
        }
        let paths: Vec<VPath> = undated
            .iter()
            .map(|(suffix, _)| self.path(suffix))
            .collect::<Result<_, _>>()?;
        let metas = drive_port(
            self.inner.fs.stat_many(&paths, ctx),
            ctx,
            self.inner.clock.as_deref(),
        )?
        .map_err(from_iofault)?;
        let mut objects = Vec::new();
        for ((_, object), meta) in undated.into_iter().zip(metas) {
            objects.push(self.date_object(object, meta));
        }
        objects.sort_by(|left, right| left.digest.0.cmp(&right.digest.0));
        Ok(objects)
    }

    /// Read, decode and date one object metadata record. `Ok(None)` means the file is not there.
    ///
    /// Every path that hands out a `CasObjectRef` goes through here -- enumeration, `get`, and the
    /// write path -- because a record whose age depends on which call asked for it is two sources of
    /// truth wearing one type.
    fn read_object_record(
        &self,
        suffix: &str,
        ctx: &IoContext,
    ) -> Result<Option<CasObjectRef>, StorageError> {
        let Some(object) = self.read_object_record_undated(suffix, ctx)? else {
            return Ok(None);
        };
        self.dated(object, suffix, ctx).map(Some)
    }

    /// Read and decode one object metadata record without dating it (the caller dates, so a
    /// batch can pay one `stat_many` for many records — `ADR-054 §2.3`).
    fn read_object_record_undated(
        &self,
        suffix: &str,
        ctx: &IoContext,
    ) -> Result<Option<CasObjectRef>, StorageError> {
        let Some(raw) = self.read_text(suffix, ctx)? else {
            return Ok(None);
        };
        let object = decode_and_check(&raw, "object", decode_object)
            .map_err(|summary| StorageError::new(StorageErrorKind::IntegrityViolation, summary))?;
        Ok(Some(object))
    }

    /// Snapshot records, read from the directory rather than from a list of them.
    ///
    /// Every snapshot-facing query goes through here so that `list_snapshots`, the
    /// last-known-good fallback and boot verification cannot disagree about which records exist --
    /// the same "two views of one store" defect `docs/engineering/STORAGE_RECOVERY_EXECUTION_PLAN.md §9` calls
    /// out for the diagnostics, one level down.
    fn load_snapshots(&self, ctx: &IoContext) -> Result<Vec<SnapshotRecord>, StorageError> {
        let dir = Self::record_directory("snapshot");
        let mut values = Vec::new();
        for suffix in self.list_records(&dir, ctx)? {
            let Some(raw) = self.read_text(&suffix, ctx)? else {
                continue;
            };
            values.push(decode_and_check(&raw, "snapshot", decode_snapshot).map_err(
                |summary| StorageError::new(StorageErrorKind::IntegrityViolation, summary),
            )?);
        }
        values.sort_by(|left, right| left.id.0.cmp(&right.id.0));
        Ok(values)
    }

    /// Apply journal records, read from the directory.
    fn load_apply_journals(
        &self,
        ctx: &IoContext,
    ) -> Result<Vec<ApplyJournalRecord>, StorageError> {
        let dir = Self::record_directory("apply-journal");
        let mut values = Vec::new();
        for suffix in self.list_records(&dir, ctx)? {
            let Some(raw) = self.read_text(&suffix, ctx)? else {
                continue;
            };
            values.push(
                decode_and_check(&raw, "apply-journal", decode_apply_journal).map_err(
                    |summary| StorageError::new(StorageErrorKind::IntegrityViolation, summary),
                )?,
            );
        }
        values.sort_by(|left, right| left.apply_txn_id.0.cmp(&right.apply_txn_id.0));
        Ok(values)
    }

    /// Revision records, read from the directory.
    ///
    /// This is the root set's `已登记 Revision` class (`RFC-0007 §13.1`): every revision the store
    /// holds protects the semantic digest it names, whether or not a snapshot has caught up with it.
    fn load_revisions(&self, ctx: &IoContext) -> Result<Vec<RevisionRecord>, StorageError> {
        let dir = Self::record_directory("revision");
        let mut values = Vec::new();
        for suffix in self.list_records(&dir, ctx)? {
            let Some(raw) = self.read_text(&suffix, ctx)? else {
                continue;
            };
            values.push(decode_and_check(&raw, "revision", decode_revision).map_err(
                |summary| StorageError::new(StorageErrorKind::IntegrityViolation, summary),
            )?);
        }
        values.sort_by(|left, right| left.id.0.cmp(&right.id.0));
        Ok(values)
    }

    /// OS journal records, read from the directory.
    fn load_os_journals(&self, ctx: &IoContext) -> Result<Vec<JournalRecord>, StorageError> {
        let dir = Self::record_directory("os-journal");
        let mut values = Vec::new();
        for suffix in self.list_records(&dir, ctx)? {
            let Some(raw) = self.read_text(&suffix, ctx)? else {
                continue;
            };
            values.push(
                decode_and_check(&raw, "os-journal", decode_os_journal).map_err(|summary| {
                    StorageError::new(StorageErrorKind::IntegrityViolation, summary)
                })?,
            );
        }
        values.sort_by(|left, right| left.id.0.cmp(&right.id.0));
        Ok(values)
    }

    /// Source index records, read from the directory. The directory is the durable index: the
    /// in-memory map is only the open-time cache and is never the authority for enumeration.
    fn load_source_indexes(&self, ctx: &IoContext) -> Result<Vec<SourceIndexRecord>, StorageError> {
        let dir = Self::record_directory("source-index");
        let mut values = Vec::new();
        for suffix in self.list_records(&dir, ctx)? {
            let Some(raw) = self.read_text(&suffix, ctx)? else {
                continue;
            };
            values.push(
                decode_and_check(&raw, "source-index", decode_source_index).map_err(|summary| {
                    StorageError::new(StorageErrorKind::IntegrityViolation, summary)
                })?,
            );
        }
        values.sort_by(|left, right| left.source_id.cmp(&right.source_id));
        Ok(values)
    }

    /// Job log records, read from the directory (the directory is the durable index, same as every
    /// other record family). Sorted by `job_id` **descending**: ids are minted monotonically, so
    /// highest-first is most-recent-first, the order `jobs.list` renders. Numeric ids sort
    /// lexicographically only when zero-padded, so sort by the parsed integer when possible.
    fn load_job_logs(&self, ctx: &IoContext) -> Result<Vec<JobLogRecord>, StorageError> {
        let dir = Self::record_directory("job-log");
        let mut values = Vec::new();
        for suffix in self.list_records(&dir, ctx)? {
            let Some(raw) = self.read_text(&suffix, ctx)? else {
                continue;
            };
            values.push(
                decode_and_check(&raw, "job-log", decode_job_log).map_err(|summary| {
                    StorageError::new(StorageErrorKind::IntegrityViolation, summary)
                })?,
            );
        }
        values.sort_by(|left, right| {
            // Numeric ids descending; fall back to string descending for any non-numeric id.
            match (left.job_id.parse::<u64>(), right.job_id.parse::<u64>()) {
                (Ok(a), Ok(b)) => b.cmp(&a),
                _ => right.job_id.cmp(&left.job_id),
            }
        });
        Ok(values)
    }

    /// Read the last-known-good pointer file. A restart resolves LKG through this, not through
    /// whatever the previous process had in memory.
    pub fn last_known_good_id(&self, ctx: &IoContext) -> Result<Option<String>, StorageError> {
        Ok(self
            .read_text("pointers/last-known-good", ctx)?
            .map(|text| text.trim().to_owned())
            .filter(|value| !value.is_empty()))
    }

    pub fn set_last_known_good(
        &self,
        snapshot_id: &SnapshotRecordId,
        ctx: &IoContext,
    ) -> Result<(), StorageError> {
        self.write_text(
            "pointers/last-known-good",
            &format!("{}\n", snapshot_id.0),
            Durability::D3,
            ctx,
        )
    }

    /// Digests the store currently holds, for diagnostics and tests.
    pub fn object_digests(&self) -> Vec<String> {
        lock(&self.inner.objects).keys().cloned().collect()
    }

    pub fn apply_journal_count(&self) -> usize {
        lock(&self.inner.apply_journals).len()
    }

    fn insert_object(&self, object: CasObjectRef) {
        lock(&self.inner.objects).insert(object.digest.0.clone(), object);
    }
}

impl FsStore {
    fn delete_text(&self, suffix: &str, ctx: &IoContext) -> Result<(), StorageError> {
        let path = self.path(suffix)?;
        match drive_port(
            self.inner.fs.remove(&path, ctx),
            ctx,
            self.inner.clock.as_deref(),
        )? {
            Ok(()) => Ok(()),
            Err(fault) if fault.kind == IoFaultKind::NotFound => Ok(()),
            Err(fault) => Err(from_iofault(fault)),
        }
    }

    /// The objects this *process* knows about, from its cache rather than from the disk.
    ///
    /// Deliberate here and nowhere else: the shared-content check below runs once per deletion, and
    /// re-decoding every object record for each one turns a gc cycle into a quadratic read storm --
    /// on the simulator, where every read scans the whole file table. The cost of the cache is that a
    /// record added by another process is not counted as a reference, which is why deletion remains
    /// the caller's decision (`gc.rs` owns the policy) and never happens from inside the store.
    /// Inject the clock this store's caller deadlines are judged against (`ADR-039 §2`, step 3).
    ///
    /// Deliberately a builder and deliberately optional: the composition root owns the clock choice
    /// (`ADR-038 §3`'s doctrine -- `StdClock` on a real host, the simulation's `SimClock` inside the
    /// deterministic gate), and a store opened without one keeps the old answers exactly: contexts
    /// carrying `deadline_mono_ms` are served, their deadline ignored rather than guessed.
    pub fn with_clock(mut self, clock: Arc<dyn caly_io::Clock>) -> Self {
        let inner = Arc::get_mut(&mut self.inner)
            .expect("with_clock is part of construction; the store is not shared yet");
        inner.clock = Some(clock);
        self
    }

    fn list_objects_inline(&self) -> Vec<CasObjectRef> {
        lock(&self.inner.objects).values().cloned().collect()
    }
}

fn text(error: StorageError) -> String {
    error.summary
}

fn lock<T>(slot: &Mutex<T>) -> std::sync::MutexGuard<'_, T> {
    slot.lock().unwrap_or_else(|poisoned| poisoned.into_inner())
}

/// `RFC-0007 §6.1`: `objects/<algo>/<p1>/<p2>/<digest>`.
pub fn content_suffix_for(anchor: &str) -> String {
    let hex = anchor.strip_prefix("sha256:").unwrap_or(anchor);
    let (first, rest) = hex.split_at(hex.len().min(2));
    let (second, remainder) = rest.split_at(rest.len().min(2));
    format!("objects/sha256/{first}/{second}/{remainder}")
}

/// Enumerate one directory of a store, in **store-relative** suffix form.
///
/// This is where the two path bases meet, and it is the only place they do: `Fs` answers with paths
/// under its own root, while `FsStore` thinks in suffixes of `root` (`RFC-0007 §6.4`, frozen by
/// `ADR-035 §2.5`). A missing directory is `Ok(vec![])` -- for a store, "never written under here"
/// and "empty" are the same fact, and `ADR-035 §6bis-bis` is what makes that safe, because a
/// directory only exists where a write created it -- while every other fault propagates. Returning
/// a short list instead of `CapacityExceeded` would be the one lie this port family refuses to tell.
pub(crate) fn list_directory(
    fs: &dyn Fs,
    root: &str,
    ctx: &IoContext,
    clock: Option<&dyn caly_io::Clock>,
    dir: &str,
    cap: ListCap,
) -> Result<Vec<String>, StorageError> {
    let target = VPath::try_from_str(&format!("{root}/{dir}"))
        .map_err(|error| StorageError::new(StorageErrorKind::Internal, error.message))?;
    let entries = match drive_port(fs.list(&target, cap, ctx), ctx, clock)? {
        Ok(entries) => entries,
        Err(fault) if fault.kind == IoFaultKind::NotFound => return Ok(Vec::new()),
        Err(fault) => return Err(from_iofault(fault)),
    };
    let prefix = format!("{root}/");
    Ok(entries
        .into_iter()
        .map(|entry| entry.as_relative_path().to_owned())
        .map(|full| match full.strip_prefix(&prefix) {
            Some(rest) => rest.to_owned(),
            None => full,
        })
        .collect())
}

/// Whether a listed name is a record this store can read.
///
/// `sanitize` rewrites every `.` in an id, so the extension of a record name is unambiguous: no id
/// can produce a second `.rec`, and no object digest can hide one in its middle.
pub(crate) fn is_record_name(name: &str) -> bool {
    name.ends_with(".rec") || name.ends_with(".obj")
}

/// Whether a listed name is the residue of a write that never completed.
///
/// `StdFs::write_atomic` creates `<target>.tmp-<sequence>` beside the target and renames it, so a
/// name of exactly that shape can only be a crash leftover. The suffix has to be digits: `notes.txt`
/// is somebody else's file and must not be mistaken for debris.
fn is_temp_residue(name: &str) -> bool {
    let Some(at) = name.rfind(".tmp-") else {
        return false;
    };
    let tail = &name[at + ".tmp-".len()..];
    !tail.is_empty() && tail.bytes().all(|byte| byte.is_ascii_digit()) && at > 0
}

/// Percent-escape the characters a filename cannot carry, **injectively** (`ADR-041`): the old
/// flattening (`/\\: .` all to `_`) let two distinct caller-coined names occupy one record
/// file -- the second `put` silently overwrote the first, and `get`/`delete` could reach a
/// record through a name the store never held (`obj:orphan` answered as `obj_orphan`), which
/// the in-memory backend refused, so the two backends disagreed. `%` escapes first, so a
/// literal `probe%2Fpath` can never masquerade as an escaped `probe/path`.
/// The bucket one record file name lives in (`ADR-062 §2.1`): the first two lower-hex
/// characters of the sha256 of the ESCAPED file name stem. The whole relative path is
/// derived from the name alone -- no decode, no digest grammar assumed (the digest
/// namespace is caller-coined; production writes `sha256:<hex>` but the rule must not
/// depend on it) -- which is also what makes the v1 -> v2 migration a pure rename: the
/// bucket is computable from the file name a v1 store already has. Public so tests and
/// tooling derive record locations instead of hard-coding paths.
pub fn record_shard(stem: &str) -> String {
    let digest = caly_common::digest::sha256_digest(stem.as_bytes());
    let hex = digest.strip_prefix("sha256:").unwrap_or(&digest);
    hex[..2].to_owned()
}

/// The store-relative path of one object record: bucketed by the escaped digest
/// (`ADR-062`). Single construction point for write/read/delete so the bucket can never
/// disagree with the name.
pub fn object_record_path(digest: &str) -> String {
    let stem = escape_component(digest);
    format!("{OBJECT_DIRECTORY}/{}/{stem}.obj", record_shard(&stem))
}

pub fn escape_component(value: &str) -> String {
    let mut out = String::with_capacity(value.len());
    for ch in value.chars() {
        match ch {
            '%' => out.push_str("%25"),
            '/' => out.push_str("%2F"),
            '\\' => out.push_str("%5C"),
            ':' => out.push_str("%3A"),
            ' ' => out.push_str("%20"),
            '.' => out.push_str("%2E"),
            other => out.push(other),
        }
    }
    out
}

impl ObjectStore for FsStore {
    fn put<'a>(
        &'a self,
        intent: CasWriteIntent,
        ctx: &'a IoContext,
    ) -> BoxFuture<'a, Result<CasObjectRef, StorageError>> {
        let store = self.clone();
        Box::pin(async move {
            let mut object = intent.object.clone();
            object.stored_at_unix_ms = Some(intent.stored_at_unix_ms);

            if intent.payload.is_empty() {
                // Metadata-only write: recorded, but nothing can be verified or materialized
                // from it. Kept legal so callers that merely index an external blob still work.
                let suffix = object_record_path(&object.digest.0);
                store.write_text(&suffix, &encode_object(&object), Durability::D2, ctx)?;
                // Dated after the write, so the caller is told the same age a later enumeration or a
                // restart will report. A store that returned the claim and persisted the evidence
                // would make the first read the only one that flatters the caller.
                let object = store.dated(object, &suffix, ctx)?;
                store.insert_object(object.clone());
                return Ok(object);
            }

            let anchor = caly_common::digest::sha256_digest(&intent.payload);
            if let Some(claimed) = &object.content_sha256 {
                if claimed != &anchor {
                    return Err(StorageError::new(
                        StorageErrorKind::IntegrityViolation,
                        format!("declared content digest {claimed} does not match the payload ({anchor})"),
                    ));
                }
            }
            object.content_sha256 = Some(anchor.clone());
            object.size_bytes = Some(intent.payload.len() as u64);

            // `RFC-0007 §6.2`: write, verify the digest, then rename into place. Here that means
            // the content file is written and read back *before* any metadata names it, so a
            // crash can never leave a manifest entry pointing at a file that does not exist.
            let content_suffix = content_suffix_for(&anchor);
            store.write_bytes(&content_suffix, intent.payload.clone(), Durability::D2, ctx)?;
            let round_trip = store
                .read_bytes(&content_suffix, MAX_OBJECT_BYTES, ctx)?
                .ok_or_else(|| {
                    StorageError::new(
                        StorageErrorKind::IntegrityViolation,
                        "content disappeared between write and verification",
                    )
                })?;
            if !caly_common::digest::sha256_matches(&anchor, &round_trip) {
                return Err(StorageError::new(
                    StorageErrorKind::IntegrityViolation,
                    "content does not match its own digest immediately after the write",
                ));
            }

            // One file, published by existing. Nothing else has to be updated for the object to be
            // enumerable, so there is no second write that can fail independently of the first.
            let meta_suffix = object_record_path(&object.digest.0);
            store.write_text(&meta_suffix, &encode_object(&object), Durability::D2, ctx)?;
            let object = store.dated(object, &meta_suffix, ctx)?;
            store.insert_object(object.clone());
            Ok(object)
        })
    }

    fn get<'a>(
        &'a self,
        digest: &'a str,
        ctx: &'a IoContext,
    ) -> BoxFuture<'a, Result<Option<CasObjectRef>, StorageError>> {
        let store = self.clone();
        let digest = digest.to_owned();
        Box::pin(async move {
            let cached = lock(&store.inner.objects).get(&digest).cloned();
            if let Some(object) = cached {
                return Ok(Some(object));
            }
            let suffix = object_record_path(&digest);
            store.read_object_record(&suffix, ctx)
        })
    }

    /// Enumerated by listing `meta/objects` (`ADR-035 §2.3`), which is what replaced the index file
    /// whose absence used to be the reason this store could not answer the question at all
    /// (`docs/history/ONBOARDING_NOTES.md §4.15`).
    fn list_objects<'a>(
        &'a self,
        ctx: &'a IoContext,
    ) -> BoxFuture<'a, Result<Vec<CasObjectRef>, StorageError>> {
        let store = self.clone();
        Box::pin(async move { store.object_records(ctx) })
    }

    /// Remove an object record and, when nothing else references it, its content.
    ///
    /// Content is shared by construction (two pipeline digests can name the same bytes), so the
    /// content file is only dropped once no remaining metadata references its anchor. A store
    /// that deleted shared content on the first unpin would corrupt an unrelated snapshot.
    fn read_object<'a>(
        &'a self,
        digest: &'a str,
        max_bytes: u64,
        ctx: &'a IoContext,
    ) -> BoxFuture<'a, Result<Option<Vec<u8>>, StorageError>> {
        let store = self.clone();
        let digest = digest.to_owned();
        Box::pin(async move {
            let meta = lock(&store.inner.objects).get(&digest).cloned();
            let Some(meta) = meta else {
                // "No such digest" is the same answer `get` gives, and it is not an error.
                return Ok(None);
            };
            let anchor = meta.content_sha256.clone().ok_or_else(|| {
                StorageError::new(
                    StorageErrorKind::NotFound,
                    format!(
                        "object {digest} was recorded without content, so there is nothing to read back"
                    ),
                )
            })?;
            // `0` means "no caller bound", not "read nothing" — and either way the store's own cap
            // applies, so a huge object cannot be pulled in by accident (`RFC-0007 §6.5`).
            let cap = if max_bytes == 0 {
                MAX_OBJECT_BYTES
            } else {
                max_bytes.min(MAX_OBJECT_BYTES)
            };
            let suffix = content_suffix_for(&anchor);
            // The bound is checked here, in store terms, rather than letting the port's own
            // `CapacityExceeded` surface: that message quotes the **path of the content file**
            // (`file exceeds byte cap: var/caly/objects/sha256/...`), and an error text a client can
            // read is not where a store's internal layout belongs. `RFC-0010 §4.1` treats paths as
            // quasi-secrets for exactly this reason. Checking first also makes the wording identical
            // across backends, which `tests/object_contract.rs` now requires.
            if max_bytes != 0 {
                let size = store.stat_size(&suffix, ctx)?;
                if let Some(size) = size {
                    if size > max_bytes {
                        return Err(StorageError::new(
                            StorageErrorKind::CapacityExceeded,
                            format!(
                                "object {digest} is {size} bytes and the caller allowed {max_bytes}"
                            ),
                        ));
                    }
                }
            }
            let bytes = store.read_bytes(&suffix, cap, ctx)?.ok_or_else(|| {
                StorageError::new(
                    StorageErrorKind::IntegrityViolation,
                    format!("content for {digest} is missing from {suffix}"),
                )
            })?;
            if !caly_common::digest::sha256_matches(&anchor, &bytes) {
                return Err(StorageError::new(
                    StorageErrorKind::IntegrityViolation,
                    format!("object {digest} failed integrity verification on read"),
                ));
            }
            Ok(Some(bytes))
        })
    }

    fn delete<'a>(
        &'a self,
        digest: &'a str,
        ctx: &'a IoContext,
    ) -> BoxFuture<'a, Result<bool, StorageError>> {
        let store = self.clone();
        let digest = digest.to_owned();
        Box::pin(async move {
            let meta_suffix = object_record_path(&digest);
            let Some(removed) = store.read_object_record(&meta_suffix, ctx)? else {
                return Ok(false);
            };
            // Unpublishing the metadata record *is* the deletion: enumeration lists files, so once
            // this file is gone no reader can name the object, and there is no index left to update.
            store.delete_text(&meta_suffix, ctx)?;
            lock(&store.inner.objects).remove(&digest);

            if let Some(anchor) = &removed.content_sha256 {
                let still_referenced = store
                    .list_objects_inline()
                    .iter()
                    .any(|object| object.content_sha256.as_deref() == Some(anchor.as_str()));
                if !still_referenced {
                    let content_suffix = content_suffix_for(anchor);
                    store.delete_text(&content_suffix, ctx)?;
                }
            }
            Ok(true)
        })
    }

    fn list_content<'a>(
        &'a self,
        ctx: &'a IoContext,
    ) -> BoxFuture<'a, Result<Vec<crate::gc::ContentEntry>, StorageError>> {
        let store = self.clone();
        Box::pin(async move {
            walk_content_tree(
                store.inner.fs.as_ref(),
                &store.inner.root,
                ctx,
                store.inner.clock.as_deref(),
                MAX_CONTENT_WALK_DIRECTORIES,
            )
        })
    }

    fn delete_content<'a>(
        &'a self,
        target: &'a crate::gc::ContentTarget,
        ctx: &'a IoContext,
    ) -> BoxFuture<'a, Result<bool, StorageError>> {
        let store = self.clone();
        let target = target.clone();
        Box::pin(async move {
            // A cancelled context refuses the unit before it starts (`ADR-039 §2.3`); deleting is
            // exactly the kind of work that must not begin under a withdrawn call.
            if ctx.cancel.is_cancelled() {
                return Err(StorageError::new(
                    StorageErrorKind::Cancelled,
                    "the caller cancelled before this content deletion began",
                ));
            }
            // The suffix and the decision "explainable" come from one place, so a target that does
            // not fit the layout cannot become a path the store never wrote.
            let suffix = content_suffix_for_target(&target)?;
            if let crate::gc::ContentTarget::Anchor(anchor) = &target {
                // The sweep's second chance: the plan checked references before the caller walked
                // here, and this is the check that covers the window between plan and delete.
                // Refusal, not a silent skip -- metadata naming content is a fact the caller must
                // learn, not one the store should paper over.
                if store
                    .list_objects_inline()
                    .iter()
                    .any(|object| object.content_sha256.as_deref() == Some(anchor.as_str()))
                {
                    return Err(StorageError::new(
                        StorageErrorKind::IntegrityViolation,
                        format!(
                            "content {anchor} is still referenced by an object record; \
                             delete the object, not the content"
                        ),
                    ));
                }
            }
            if !store.exists(&suffix, ctx)? {
                return Ok(false);
            }
            store.delete_text(&suffix, ctx)?;
            Ok(true)
        })
    }

    fn materialize<'a>(
        &'a self,
        request: MaterializationRequest,
        ctx: &'a IoContext,
    ) -> BoxFuture<'a, Result<(), StorageError>> {
        let store = self.clone();
        Box::pin(async move {
            let object = lock(&store.inner.objects)
                .get(&request.object.digest.0)
                .cloned()
                .ok_or_else(|| {
                    StorageError::new(
                        StorageErrorKind::NotFound,
                        format!("object {} not in the store", request.object.digest.0),
                    )
                })?;
            let anchor = object.content_sha256.clone().ok_or_else(|| {
                StorageError::new(
                    StorageErrorKind::IntegrityViolation,
                    format!(
                        "object {} was stored without content, so it cannot be materialized",
                        object.digest.0
                    ),
                )
            })?;
            let content_suffix = content_suffix_for(&anchor);
            let bytes = store
                .read_bytes(&content_suffix, MAX_OBJECT_BYTES, ctx)?
                .ok_or_else(|| {
                    StorageError::new(
                        StorageErrorKind::IntegrityViolation,
                        format!(
                            "content for {} is missing from {}",
                            object.digest.0, content_suffix
                        ),
                    )
                })?;
            if !caly_common::digest::sha256_matches(&anchor, &bytes) {
                return Err(StorageError::new(
                    StorageErrorKind::IntegrityViolation,
                    format!(
                        "content for {} failed integrity verification before materialization",
                        object.digest.0
                    ),
                ));
            }

            let destination = VPath::try_from_str(&request.runtime_path)
                .map_err(|error| StorageError::new(StorageErrorKind::Internal, error.message))?;
            match request.mode {
                // A copy is what a runtime directory needs when the caller may later rewrite the
                // materialized file; the CAS object itself must stay immutable.
                MaterializationMode::Copy => {
                    store.write_bytes(&destination.as_relative_path(), bytes, Durability::D2, ctx)
                }
                MaterializationMode::HardlinkPreferred | MaterializationMode::ReflinkPreferred => {
                    let source = store.path(&content_suffix)?;
                    drive_port(
                        store.inner.fs.link_or_copy(&source, &destination, ctx),
                        ctx,
                        store.inner.clock.as_deref(),
                    )?
                    .map_err(from_iofault)?;
                    Ok(())
                }
            }?;

            // Record the mapping only after the copy succeeded. It is what lets `doctor` answer
            // `§9.2`'s "abandoned runtime directory" question after a restart; losing it to a
            // crash here costs only the diagnostic, never the deployment, so a failure to write
            // it is swallowed deliberately rather than failing an apply that already worked.
            let marker = materialization_marker(&object.digest.0);
            let _ = store.write_text(
                &marker,
                &format!("{}\n", request.runtime_path),
                Durability::D1,
                ctx,
            );
            Ok(())
        })
    }
}

impl RevisionStore for FsStore {
    fn put_revision<'a>(
        &'a self,
        record: RevisionRecord,
        ctx: &'a IoContext,
    ) -> BoxFuture<'a, Result<(), StorageError>> {
        let store = self.clone();
        Box::pin(async move {
            let suffix = FsStore::record_path("revision", &record.id.0);
            store.write_text(&suffix, &encode_revision(&record), Durability::D2, ctx)?;
            lock(&store.inner.revisions).insert(record.id.0.clone(), record);
            Ok(())
        })
    }

    fn list_revisions<'a>(
        &'a self,
        ctx: &'a IoContext,
    ) -> BoxFuture<'a, Result<Vec<RevisionRecord>, StorageError>> {
        let store = self.clone();
        Box::pin(async move { store.load_revisions(ctx) })
    }

    fn get_revision<'a>(
        &'a self,
        revision_id: &'a RevisionId,
        ctx: &'a IoContext,
    ) -> BoxFuture<'a, Result<Option<RevisionRecord>, StorageError>> {
        let store = self.clone();
        let id = revision_id.0.clone();
        Box::pin(async move {
            let suffix = FsStore::record_path("revision", &id);
            match store.read_text(&suffix, ctx)? {
                Some(raw) => decode_and_check(&raw, "revision", decode_revision)
                    .map(Some)
                    .map_err(|summary| {
                        StorageError::new(StorageErrorKind::IntegrityViolation, summary)
                    }),
                None => Ok(None),
            }
        })
    }
}

impl SnapshotStore for FsStore {
    fn put_snapshot<'a>(
        &'a self,
        record: SnapshotRecord,
        ctx: &'a IoContext,
    ) -> BoxFuture<'a, Result<(), StorageError>> {
        let store = self.clone();
        Box::pin(async move {
            // One durable write, not two: the index used to be the second, and a crash between them
            // is exactly the inconsistency `ADR-035` was raised to remove.
            let suffix = FsStore::record_path("snapshot", &record.id.0);
            store.write_text(&suffix, &encode_snapshot(&record), Durability::D3, ctx)?;
            lock(&store.inner.snapshots).insert(record.id.0.clone(), record.clone());
            if record.is_last_known_good {
                store.set_last_known_good(&record.id, ctx)?;
            }
            Ok(())
        })
    }

    fn get_snapshot<'a>(
        &'a self,
        snapshot_id: &'a SnapshotRecordId,
        ctx: &'a IoContext,
    ) -> BoxFuture<'a, Result<Option<SnapshotRecord>, StorageError>> {
        let store = self.clone();
        let id = snapshot_id.0.clone();
        Box::pin(async move {
            let suffix = FsStore::record_path("snapshot", &id);
            match store.read_text(&suffix, ctx)? {
                Some(raw) => decode_and_check(&raw, "snapshot", decode_snapshot)
                    .map(Some)
                    .map_err(|summary| {
                        StorageError::new(StorageErrorKind::IntegrityViolation, summary)
                    }),
                None => Ok(None),
            }
        })
    }

    fn list_snapshots<'a>(
        &'a self,
        ctx: &'a IoContext,
    ) -> BoxFuture<'a, Result<Vec<SnapshotRecord>, StorageError>> {
        let store = self.clone();
        Box::pin(async move { store.load_snapshots(ctx) })
    }

    fn latest_last_known_good<'a>(
        &'a self,
        ctx: &'a IoContext,
    ) -> BoxFuture<'a, Result<Option<SnapshotRecord>, StorageError>> {
        let store = self.clone();
        Box::pin(async move {
            if let Some(id) = store.last_known_good_id(ctx)? {
                let suffix = FsStore::record_path("snapshot", &id);
                return match store.read_text(&suffix, ctx)? {
                    Some(raw) => decode_and_check(&raw, "snapshot", decode_snapshot)
                        .map(Some)
                        .map_err(|summary| {
                            StorageError::new(StorageErrorKind::IntegrityViolation, summary)
                        }),
                    // A pointer at a missing record is the "snapshot/object mismatch" the doctor
                    // must report; guessing a replacement here would hide real damage.
                    None => Err(StorageError::new(
                        StorageErrorKind::NotFound,
                        format!("last-known-good pointer names a missing snapshot record: {id}"),
                    )),
                };
            }

            // No pointer: fall back to the records on disk, not to this process's cache. The cache
            // is what a previous apply left behind, and "which snapshot may a rollback return to" is
            // not a question to answer from stale memory when the disk is right there.
            let candidates = store.load_snapshots(ctx)?;
            Ok(candidates
                .into_iter()
                .filter(|snapshot| snapshot.is_last_known_good)
                .max_by_key(|snapshot| snapshot.created_at_unix_ms))
        })
    }
}

impl FsStore {
    /// Where the runtime candidate for `object_digest` was materialized, if ever.
    pub fn materialized_path(&self, object_digest: &str) -> Option<String> {
        // Sync introspection has no caller context to thread (`ADR-039 §2.1` covers the async
        // traits); this is store-originated work, so it carries a labelled self-made one (§2.4).
        let ctx = caly_io::RequestContext::new(
            caly_io::TraceId::new("storage-introspection"),
            caly_io::Actor::System,
        );
        self.read_text(&materialization_marker(object_digest), &ctx)
            .ok()
            .flatten()
            .map(|text| text.trim().to_owned())
            .filter(|text| !text.is_empty())
    }

    /// Rollback points this store can see, by the version each precedes (`§12.2.2`).
    pub fn observed_rollback_points(&self) -> Vec<u32> {
        let ctx = caly_io::RequestContext::new(
            caly_io::TraceId::new("storage-introspection"),
            caly_io::Actor::System,
        );
        (0..self.inner.schema_version)
            .filter(|version| {
                self.exists(
                    &format!("backups/v{version}/{}", crate::schema::SCHEMA_SUFFIX),
                    &ctx,
                )
                .unwrap_or(false)
            })
            .collect()
    }
}

impl StorageBackend for FsStore {
    fn put_source_index<'a>(
        &'a self,
        record: SourceIndexRecord,
        ctx: &'a IoContext,
    ) -> BoxFuture<'a, Result<(), StorageError>> {
        let store = self.clone();
        Box::pin(async move {
            // The source index is the publish point for a source update. CAS content is written
            // and verified first by the worker; this single D3 atomic record then makes the
            // endpoint, validators, raw anchor, normalized cache, and provenance visible together.
            let suffix = FsStore::record_path("source-index", &record.source_id);
            store.write_text(&suffix, &encode_source_index(&record), Durability::D3, ctx)?;
            lock(&store.inner.source_indexes).insert(record.source_id.clone(), record);
            Ok(())
        })
    }

    fn get_source_index<'a>(
        &'a self,
        source_id: &'a str,
        ctx: &'a IoContext,
    ) -> BoxFuture<'a, Result<Option<SourceIndexRecord>, StorageError>> {
        let store = self.clone();
        let source_id = source_id.to_owned();
        Box::pin(async move {
            let suffix = FsStore::record_path("source-index", &source_id);
            match store.read_text(&suffix, ctx)? {
                Some(raw) => decode_and_check(&raw, "source-index", decode_source_index)
                    .map(Some)
                    .map_err(|summary| {
                        StorageError::new(StorageErrorKind::IntegrityViolation, summary)
                    }),
                None => Ok(None),
            }
        })
    }

    fn list_source_indexes<'a>(
        &'a self,
        ctx: &'a IoContext,
    ) -> BoxFuture<'a, Result<Vec<SourceIndexRecord>, StorageError>> {
        let store = self.clone();
        Box::pin(async move { store.load_source_indexes(ctx) })
    }

    fn delete_source_index<'a>(
        &'a self,
        source_id: &'a str,
        ctx: &'a IoContext,
    ) -> BoxFuture<'a, Result<bool, StorageError>> {
        let store = self.clone();
        let source_id = source_id.to_owned();
        Box::pin(async move {
            let suffix = FsStore::record_path("source-index", &source_id);
            let existed = store.exists(&suffix, ctx)?;
            if existed {
                store.delete_text(&suffix, ctx)?;
            }
            lock(&store.inner.source_indexes).remove(&source_id);
            Ok(existed)
        })
    }

    fn schema_state(&self) -> crate::audit::Observation<u32> {
        crate::audit::Observation::known(self.inner.schema_version)
    }

    fn migrations_applied(&self) -> u32 {
        self.inner.migrations_applied
    }

    fn rollback_points(&self) -> crate::audit::Observation<Vec<u32>> {
        crate::audit::Observation::known(self.observed_rollback_points())
    }

    fn materialization_state(&self, object_digest: &str) -> crate::audit::Observation<bool> {
        let Some(path) = self.materialized_path(object_digest) else {
            return crate::audit::Observation::unavailable(format!(
                "this store never materialized {object_digest}"
            ));
        };
        let probe = caly_io::RequestContext::new(
            caly_io::TraceId::new("storage-introspection"),
            caly_io::Actor::System,
        );
        match self.exists(&path, &probe) {
            Ok(exists) => crate::audit::Observation::known(exists),
            Err(failure) => crate::audit::Observation::unavailable(failure.summary),
        }
    }
}

fn materialization_marker(digest: &str) -> String {
    format!("materialized/{}.ok", escape_component(digest))
}

impl JournalStore for FsStore {
    fn put_journal<'a>(
        &'a self,
        record: JournalRecord,
        ctx: &'a IoContext,
    ) -> BoxFuture<'a, Result<(), StorageError>> {
        let store = self.clone();
        Box::pin(async move {
            let suffix = FsStore::record_path("os-journal", &record.id.0);
            store.write_text(&suffix, &encode_os_journal(&record), Durability::D3, ctx)?;
            lock(&store.inner.journals).insert(record.id.0.clone(), record);
            Ok(())
        })
    }

    fn get_journal<'a>(
        &'a self,
        journal_id: &'a JournalRecordId,
        ctx: &'a IoContext,
    ) -> BoxFuture<'a, Result<Option<JournalRecord>, StorageError>> {
        let store = self.clone();
        let id = journal_id.0.clone();
        Box::pin(async move {
            let suffix = FsStore::record_path("os-journal", &id);
            match store.read_text(&suffix, ctx)? {
                Some(raw) => decode_and_check(&raw, "os-journal", decode_os_journal)
                    .map(Some)
                    .map_err(|summary| {
                        StorageError::new(StorageErrorKind::IntegrityViolation, summary)
                    }),
                None => Ok(None),
            }
        })
    }

    fn list_pending<'a>(
        &'a self,
        ctx: &'a IoContext,
    ) -> BoxFuture<'a, Result<Vec<JournalRecord>, StorageError>> {
        let store = self.clone();
        Box::pin(async move {
            Ok(store
                .load_os_journals(ctx)?
                .into_iter()
                .filter(|record| matches!(record.state, JournalState::Pending))
                .collect())
        })
    }
}

impl ApplyJournalStore for FsStore {
    fn put_apply_journal<'a>(
        &'a self,
        record: ApplyJournalRecord,
        ctx: &'a IoContext,
    ) -> BoxFuture<'a, Result<(), StorageError>> {
        let store = self.clone();
        Box::pin(async move {
            let suffix = FsStore::record_path("apply-journal", &record.apply_txn_id.0);
            // The journal leads the irreversible steps, so it is written at the highest tier.
            store.write_text(&suffix, &encode_apply_journal(&record), Durability::D3, ctx)?;
            lock(&store.inner.apply_journals).insert(record.apply_txn_id.0.clone(), record);
            Ok(())
        })
    }

    fn get_apply_journal<'a>(
        &'a self,
        apply_txn_id: &'a ApplyTxnId,
        ctx: &'a IoContext,
    ) -> BoxFuture<'a, Result<Option<ApplyJournalRecord>, StorageError>> {
        let store = self.clone();
        let id = apply_txn_id.0.clone();
        Box::pin(async move {
            let suffix = FsStore::record_path("apply-journal", &id);
            match store.read_text(&suffix, ctx)? {
                Some(raw) => decode_and_check(&raw, "apply-journal", decode_apply_journal)
                    .map(Some)
                    .map_err(|summary| {
                        StorageError::new(StorageErrorKind::IntegrityViolation, summary)
                    }),
                None => Ok(None),
            }
        })
    }

    fn list_pending_apply<'a>(
        &'a self,
        ctx: &'a IoContext,
    ) -> BoxFuture<'a, Result<Vec<ApplyJournalRecord>, StorageError>> {
        let store = self.clone();
        Box::pin(async move {
            Ok(store
                .load_apply_journals(ctx)?
                .into_iter()
                .filter(|record| matches!(record.state, ApplyJournalState::Pending))
                .collect())
        })
    }

    fn list_unresolved_apply<'a>(
        &'a self,
        ctx: &'a IoContext,
    ) -> BoxFuture<'a, Result<Vec<ApplyJournalRecord>, StorageError>> {
        let store = self.clone();
        Box::pin(async move {
            Ok(store
                .load_apply_journals(ctx)?
                .into_iter()
                .filter(|record| {
                    matches!(
                        record.state,
                        ApplyJournalState::Pending | ApplyJournalState::RecoveryFailed
                    )
                })
                .collect())
        })
    }

    fn list_apply_journals<'a>(
        &'a self,
        ctx: &'a IoContext,
    ) -> BoxFuture<'a, Result<Vec<ApplyJournalRecord>, StorageError>> {
        let store = self.clone();
        Box::pin(async move {
            // Reads the records themselves instead of handing back the cache: the bundle is the
            // artifact a third party reads, so it must show what is on disk, and a record that no
            // longer decodes has to surface as an integrity problem rather than being silently
            // absent from the export. Same enumeration `list_pending_apply` uses, so the two can
            // never report different sets of transactions.
            store.load_apply_journals(ctx)
        })
    }
}

impl JobLogStore for FsStore {
    fn put_job_log<'a>(
        &'a self,
        record: JobLogRecord,
        ctx: &'a IoContext,
    ) -> BoxFuture<'a, Result<(), StorageError>> {
        let store = self.clone();
        Box::pin(async move {
            // Terminal commit point for a deployment job: D3, same tier as a snapshot commit
            // (`ADR-057` / `ADR-014`). One atomic record makes the retained event window, the
            // terminal state and the stable failure code visible together after a restart.
            let suffix = FsStore::record_path("job-log", &record.job_id);
            store.write_text(&suffix, &encode_job_log(&record), Durability::D3, ctx)?;
            lock(&store.inner.job_logs).insert(record.job_id.clone(), record);
            Ok(())
        })
    }

    fn get_job_log<'a>(
        &'a self,
        job_id: &'a str,
        ctx: &'a IoContext,
    ) -> BoxFuture<'a, Result<Option<JobLogRecord>, StorageError>> {
        let store = self.clone();
        let job_id = job_id.to_owned();
        Box::pin(async move {
            let suffix = FsStore::record_path("job-log", &job_id);
            match store.read_text(&suffix, ctx)? {
                Some(raw) => decode_and_check(&raw, "job-log", decode_job_log)
                    .map(Some)
                    .map_err(|summary| {
                        StorageError::new(StorageErrorKind::IntegrityViolation, summary)
                    }),
                None => Ok(None),
            }
        })
    }

    fn list_job_logs<'a>(
        &'a self,
        ctx: &'a IoContext,
    ) -> BoxFuture<'a, Result<Vec<JobLogRecord>, StorageError>> {
        let store = self.clone();
        Box::pin(async move { store.load_job_logs(ctx) })
    }

    fn delete_job_log<'a>(
        &'a self,
        job_id: &'a str,
        ctx: &'a IoContext,
    ) -> BoxFuture<'a, Result<bool, StorageError>> {
        let store = self.clone();
        let job_id = job_id.to_owned();
        Box::pin(async move {
            let suffix = FsStore::record_path("job-log", &job_id);
            let existed = store.exists(&suffix, ctx)?;
            if existed {
                store.delete_text(&suffix, ctx)?;
            }
            lock(&store.inner.job_logs).remove(&job_id);
            Ok(existed)
        })
    }
}
