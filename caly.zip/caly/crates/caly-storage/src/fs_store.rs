//! Durable storage backend on top of the IO gateway.
//!
//! This is what turns `caly-storage` from "traits with one in-memory implementation" into an
//! actual transaction substrate (`docs/STORAGE_RECOVERY_EXECUTION_PLAN.md §12`).
//!
//! Two design points are forced rather than chosen:
//!
//! 1. **Every byte goes through `caly_io::Fs`.** `ADR-011` makes the port layer the only place
//!    allowed to touch the host, and `caly-io-std::StdFs` supplies `write_atomic` with the
//!    `ADR-014` durability tiers. There is deliberately no `std::fs` call in this crate, which is
//!    also why it stays inside the workspace-wide clippy bans.
//! 2. **Enumeration comes from the port.** `Fs::list` (`ADR-035`) answers "which journals are
//!    pending?" by listing the store's own directories, so a collection has exactly one truth: the
//!    files in it. An earlier revision kept a per-collection index file (`manifest/<kind>.idx`)
//!    written next to every record, which made "the index and the entities disagree" a normal
//!    failure mode -- `docs/ONBOARDING_NOTES.md §4.15` records it as the workaround for a port gap
//!    that gap no longer exists. Listing is bounded: a directory too large to enumerate is a
//!    `CapacityExceeded` refusal, never a short list, and a record that does not decode fails
//!    `open` rather than being skipped.
//!
//! Path bases, spelled out because the two are easy to confuse and the simulator cannot reveal the
//! difference:
//!
//! * `caly_io::Fs` paths are relative to *its own* root (for `StdFs`, the directory it was built with).
//! * `MaterializationRequest::runtime_path` is relative to the **store root** (`FsStore::open`'s
//!   `root` argument), because `FsStore` owns the prefixing. Passing an already-prefixed path
//!   produces `<root>/<root>/...`, which only a rooted backend can show.
//!
//! Layout, following `RFC-0007 §6.1`:
//!
//! ```text
//! <root>/objects/sha256/<aa>/<bb>/<rest>   content, addressed by the sha256 of its bytes
//! <root>/meta/objects/<digest>.obj         object metadata, including content_sha256
//! <root>/records/<kind>/<id>.rec           revision / snapshot / journal records, enumerated
//!                                          by listing that directory (`ADR-035 §2.3`)
//! <root>/pointers/last-known-good          the single last-known-good marker
//! ```

use std::collections::BTreeMap;
use std::sync::{Arc, Mutex};

use caly_io::{BoxFuture, ByteCap, Durability, Fs, IoContext, IoFaultKind, ListCap, VPath};

use crate::cas::{CasObjectRef, CasWriteIntent, MaterializationMode, MaterializationRequest};
use crate::execution::{ApplyJournalRecord, ApplyJournalState, ApplyTxnId};
use crate::journal::{JournalRecord, JournalRecordId, JournalState};
use crate::port_drive::{drive_port, from_iofault};
use crate::record::{
    decode_and_check, decode_apply_journal, decode_object, decode_os_journal, decode_revision,
    decode_snapshot, encode_apply_journal, encode_object, encode_os_journal, encode_revision,
    encode_snapshot,
};
use crate::revision::{RevisionId, RevisionRecord};
use crate::snapshot::{SnapshotRecord, SnapshotRecordId};
use crate::store::{
    ApplyJournalStore, JournalStore, ObjectStore, RevisionStore, SnapshotStore, StorageBackend,
    StorageError, StorageErrorKind,
};

/// Read budget for one record. They are small by construction; the cap exists so a replaced or
/// corrupted file cannot make the store allocate without bound (`RFC-0006 §5.3`).
const MAX_RECORD_BYTES: u64 = 1 << 20;

/// Objects can be arbitrarily large, so content reads get a larger (still bounded) cap.
const MAX_OBJECT_BYTES: u64 = 1 << 30;

/// How many files one store directory may hold (`ADR-035 §2.1`).
///
/// This bound replaces the one the deleted index layer imposed by accident: reading a manifest was
/// capped at [`MAX_RECORD_BYTES`], so an index too big to read was already a refusal. Enumeration
/// has to be bounded for the same reason, and exceeding it is an error rather than a short list.
///
/// Public so an operator-facing check can say what a store directory may hold, and so a test can
/// cross the line deliberately instead of duplicating the number.
pub const MAX_ENTRIES_PER_DIRECTORY: u32 = 4096;

/// The record collections this store owns. Boot verification, enumeration and rollback points all
/// walk this one list, so a new collection cannot be added to one of them and forgotten in another.
const RECORD_KINDS: [&str; 4] = ["revision", "snapshot", "os-journal", "apply-journal"];

/// Where object metadata lives: one `.obj` file per digest, always in a single flat directory.
const OBJECT_DIRECTORY: &str = "meta/objects";

/// A durable backend whose persistence goes through the `Fs` port.
#[derive(Clone)]
pub struct FsStore {
    inner: Arc<StoreInner>,
}

impl std::fmt::Debug for FsStore {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        f.debug_struct("FsStore")
            .field("root", &self.inner.root)
            .field(
                "objects",
                &self.inner.objects.lock().map(|g| g.len()).unwrap_or(0),
            )
            .field(
                "apply_journals",
                &self
                    .inner
                    .apply_journals
                    .lock()
                    .map(|g| g.len())
                    .unwrap_or(0),
            )
            .finish()
    }
}

struct StoreInner {
    fs: Box<dyn Fs>,
    root: String,
    ctx: IoContext,
    /// What the schema gate established at open time.
    schema_version: u32,
    migrations_applied: u32,
    revisions: Mutex<BTreeMap<String, RevisionRecord>>,
    snapshots: Mutex<BTreeMap<String, SnapshotRecord>>,
    journals: Mutex<BTreeMap<String, JournalRecord>>,
    apply_journals: Mutex<BTreeMap<String, ApplyJournalRecord>>,
    objects: Mutex<BTreeMap<String, CasObjectRef>>,
}

#[derive(Clone, Debug, Eq, PartialEq, Default)]
pub struct FsStoreError {
    pub summary: String,
    /// Set when the refusal came from the schema gate (`RFC-0007 §12.2`), which is a different
    /// operator action than "the files are damaged".
    pub schema: Option<crate::schema::SchemaRefusal>,
}

impl FsStore {
    /// Open (or create) a store rooted at `root`, a *relative* path such as `"var/caly"`.
    ///
    /// Existing manifests are loaded, so constructing a second `FsStore` over the same `Fs` is
    /// exactly a daemon restart: the only thing it can know is what survived on disk. A record
    /// that fails to decode, or whose content no longer matches its digest, makes `open` fail
    /// rather than being skipped: silently dropping a corrupt journal entry is how a recovery
    /// scan ends up reporting "clean" about a half-applied deployment.
    pub fn open(fs: Box<dyn Fs>, root: &str) -> Result<Self, FsStoreError> {
        Self::open_with_migrations(fs, root, &crate::schema::MigrationChain::empty(), false)
    }

    /// Open with a migration chain available, and optionally accept an unversioned-but-empty
    /// directory as new.
    ///
    /// The schema gate runs **before** any record is read: `§12.2.1` requires the compatibility
    /// check first, and reading a layout this build does not understand is exactly what `§12.3`
    /// forbids.
    pub fn open_with_migrations(
        fs: Box<dyn Fs>,
        root: &str,
        chain: &crate::schema::MigrationChain,
        assume_fresh: bool,
    ) -> Result<Self, FsStoreError> {
        let parsed = VPath::try_from_str(root).map_err(|error| FsStoreError {
            summary: format!(
                "store root {root:?} is not a valid relative path: {}",
                error.message
            ),
            schema: None,
        })?;
        // The gate runs before anything is read: `§12.2.1` requires the compatibility check
        // first, and `§12.3` forbids interpreting a layout this build does not understand.
        let ctx =
            caly_io::RequestContext::new(caly_io::TraceId::new("storage"), caly_io::Actor::System);
        let root = parsed.as_relative_path().to_owned();
        let marker = crate::schema::gate(
            fs.as_ref(),
            &root,
            &ctx,
            crate::STORAGE_SCHEMA_VERSION,
            chain,
            assume_fresh,
        )
        .map_err(|refusal| FsStoreError {
            summary: format!("schema gate refused to open the store: {}", refusal.summary),
            schema: Some(refusal),
        })?;

        let store = Self {
            inner: Arc::new(StoreInner {
                fs,
                root,
                ctx,
                revisions: Mutex::new(BTreeMap::new()),
                snapshots: Mutex::new(BTreeMap::new()),
                journals: Mutex::new(BTreeMap::new()),
                apply_journals: Mutex::new(BTreeMap::new()),
                objects: Mutex::new(BTreeMap::new()),
                schema_version: marker.storage_schema,
                migrations_applied: marker.migrations_applied,
            }),
        };
        store.load().map_err(|summary| FsStoreError {
            summary,
            schema: None,
        })?;
        Ok(store)
    }

    /// The schema this directory is recorded as, once open.
    pub fn storage_schema_version(&self) -> u32 {
        crate::STORAGE_SCHEMA_VERSION
    }

    pub fn root(&self) -> &str {
        &self.inner.root
    }

    fn path(&self, suffix: &str) -> Result<VPath, StorageError> {
        VPath::try_from_str(&format!("{}/{}", self.inner.root, suffix))
            .map_err(|error| StorageError::new(StorageErrorKind::Internal, error.message))
    }

    fn write_bytes(
        &self,
        suffix: &str,
        bytes: Vec<u8>,
        durability: Durability,
    ) -> Result<(), StorageError> {
        let path = self.path(suffix)?;
        drive_port(
            self.inner
                .fs
                .write_atomic(&path, bytes, durability, &self.inner.ctx),
        )?
        .map_err(from_iofault)
    }

    fn read_bytes(&self, suffix: &str, cap: u64) -> Result<Option<Vec<u8>>, StorageError> {
        let path = self.path(suffix)?;
        match drive_port(self.inner.fs.read(&path, ByteCap(cap), &self.inner.ctx))? {
            Ok(bytes) => Ok(Some(bytes)),
            Err(fault) if fault.kind == IoFaultKind::NotFound => Ok(None),
            Err(fault) => Err(from_iofault(fault)),
        }
    }

    fn write_text(
        &self,
        suffix: &str,
        text: &str,
        durability: Durability,
    ) -> Result<(), StorageError> {
        self.write_bytes(suffix, text.as_bytes().to_vec(), durability)
    }

    fn read_text(&self, suffix: &str) -> Result<Option<String>, StorageError> {
        match self.read_bytes(suffix, MAX_RECORD_BYTES)? {
            Some(bytes) => String::from_utf8(bytes).map(Some).map_err(|_| {
                StorageError::new(
                    StorageErrorKind::IntegrityViolation,
                    format!("record at {suffix} is not valid utf-8"),
                )
            }),
            None => Ok(None),
        }
    }

    /// The recorded size of a file, or `None` when it does not exist.
    fn stat_size(&self, suffix: &str) -> Result<Option<u64>, StorageError> {
        let path = self.path(suffix)?;
        drive_port(self.inner.fs.stat(&path, &self.inner.ctx))?
            .map_err(from_iofault)
            .map(|meta| meta.map(|meta| meta.len))
    }

    /// Existence, without reading the body. Used by the audit probes, where "not there" is the
    /// answer and a read error is not.
    fn exists(&self, suffix: &str) -> Result<bool, StorageError> {
        let path = self.path(suffix)?;
        drive_port(self.inner.fs.stat(&path, &self.inner.ctx))?
            .map_err(from_iofault)
            .map(|meta| meta.is_some())
    }

    fn record_path(kind: &str, id: &str) -> String {
        format!("records/{kind}/{}.rec", sanitize(id))
    }

    /// Where the records of one collection live, in store-relative suffix form.
    fn record_directory(kind: &str) -> String {
        format!("records/{kind}")
    }

    /// The store-relative paths of the files in one of the store's own directories.
    fn list_suffixes(&self, dir: &str) -> Result<Vec<String>, StorageError> {
        list_directory(
            self.inner.fs.as_ref(),
            &self.inner.root,
            &self.inner.ctx,
            dir,
            ListCap(MAX_ENTRIES_PER_DIRECTORY),
        )
    }

    /// The record files in one store directory, sorted, and nothing else.
    ///
    /// The layout reserves `.rec` / `.obj` names for records, so a file with any other name is
    /// either damage or somebody else's data -- both are answers the store must not invent. The
    /// index this function replaced could not see such a file at all, which makes this check the
    /// part of "the directory is the truth" that is a strict improvement rather than a trade-off.
    fn list_records(&self, dir: &str) -> Result<Vec<String>, StorageError> {
        let mut records = Vec::new();
        for suffix in self.list_suffixes(dir)? {
            let name = suffix.rsplit('/').next().unwrap_or(&suffix);
            if is_temp_residue(name) {
                continue;
            }
            if !is_record_name(name) {
                return Err(StorageError::new(
                    StorageErrorKind::IntegrityViolation,
                    format!("unexpected file in {dir}: {name}"),
                ));
            }
            records.push(suffix);
        }
        Ok(records)
    }

    /// Remove the write residue of a crashed process from every store directory.
    ///
    /// A temp file is by construction a write that never published: `StdFs::write_atomic` renames it
    /// into place or fails, so nothing may read it. It is not data, but it does occupy the
    /// enumeration budget -- and a crash loop that leaves one behind per attempt would eventually
    /// make `open` refuse to boot for want of [`MAX_ENTRIES_PER_DIRECTORY`] slots, which is why
    /// reaping is the necessary companion of the bound rather than a cosmetic touch. A residue that
    /// cannot be removed is left for the next boot: refusing to start over a file the store will
    /// never read would trade a real start-up for a cosmetic one. Likewise a directory that cannot
    /// be listed is skipped here, because the enumeration right after this reports the same fault
    /// with the message a caller should actually see.
    fn reap_residue(&self) {
        let mut dirs = vec![OBJECT_DIRECTORY.to_owned()];
        dirs.extend(RECORD_KINDS.map(Self::record_directory));
        for dir in dirs {
            let Ok(suffixes) = self.list_suffixes(&dir) else {
                continue;
            };
            for suffix in suffixes {
                let name = suffix.rsplit('/').next().unwrap_or(&suffix);
                if !is_temp_residue(name) {
                    continue;
                }
                let _ = self.delete_text(&suffix);
            }
        }
    }

    /// Read every collection off the disk, and refuse to open if the disk cannot be explained.
    ///
    /// `ADR-035 §6bis` kept this verification when the index layer was deleted, because the question
    /// it answers was never "does the index match?" but "are the entities self-consistent?" -- a
    /// record that cannot be decoded, or content that no longer matches its anchor, is damage that
    /// a boot must not walk past. What step 2 does give up is the other half of what an index could
    /// detect: a record file removed out of band is now simply absent, since nothing is left to
    /// disagree with. That is the accepted cost, written down in `ADR-035 §6bis-ter`; the
    /// last-known-good pointer and the content anchors are the checks that survive, and both still
    /// refuse the boot.
    fn load(&self) -> Result<(), String> {
        let mut problems = Vec::new();
        self.reap_residue();

        for suffix in self.list_records(OBJECT_DIRECTORY).map_err(text)? {
            let Some(raw) = self.read_text(&suffix).map_err(text)? else {
                problems.push(format!("object record vanished while reading: {suffix}"));
                continue;
            };
            let object = match decode_and_check(&raw, "object", decode_object)
                .and_then(|object| self.dated(object, &suffix).map_err(|error| error.summary))
            {
                Ok(object) => object,
                Err(summary) => {
                    problems.push(format!("object record {suffix}: {summary}"));
                    continue;
                }
            };
            if let Some(anchor) = &object.content_sha256 {
                let content_suffix = content_suffix_for(anchor);
                match self
                    .read_bytes(&content_suffix, MAX_OBJECT_BYTES)
                    .map_err(text)?
                {
                    Some(bytes) => {
                        if !caly_common::digest::sha256_matches(anchor, &bytes) {
                            problems.push(format!(
                                "object {} content no longer matches {}",
                                object.digest.0, anchor
                            ));
                        }
                    }
                    None => problems.push(format!(
                        "object {} references missing content {}",
                        object.digest.0, content_suffix
                    )),
                }
            }
            lock(&self.inner.objects).insert(object.digest.0.clone(), object);
        }

        for kind in RECORD_KINDS {
            let dir = Self::record_directory(kind);
            for suffix in self.list_records(&dir).map_err(text)? {
                let Some(raw) = self.read_text(&suffix).map_err(text)? else {
                    problems.push(format!("{kind} record vanished while reading: {suffix}"));
                    continue;
                };
                let result = match kind {
                    "revision" => decode_and_check(&raw, kind, decode_revision).map(|record| {
                        lock(&self.inner.revisions).insert(record.id.0.clone(), record);
                    }),
                    "snapshot" => decode_and_check(&raw, kind, decode_snapshot).map(|record| {
                        lock(&self.inner.snapshots).insert(record.id.0.clone(), record);
                    }),
                    "os-journal" => decode_and_check(&raw, kind, decode_os_journal).map(|record| {
                        lock(&self.inner.journals).insert(record.id.0.clone(), record);
                    }),
                    _ => decode_and_check(&raw, kind, decode_apply_journal).map(|record| {
                        lock(&self.inner.apply_journals)
                            .insert(record.apply_txn_id.0.clone(), record);
                    }),
                };
                if let Err(summary) = result {
                    problems.push(format!("{kind} record {suffix}: {summary}"));
                }
            }
        }

        if problems.is_empty() {
            Ok(())
        } else {
            Err(problems.join("; "))
        }
    }

    /// Date one object record with the port's own evidence.
    ///
    /// `CasObjectRef::stored_at_unix_ms` as written is an **assertion** the caller made
    /// (`CasWriteIntent::stored_at_unix_ms`); the metadata file's mtime is **evidence** the port
    /// observed. `ADR-035 §2.4` lands step 3 by preferring the evidence, and the two are combined
    /// by keeping the *newer* one. That direction is the only safe one: the single mistake this field
    /// can cause is a garbage collector deleting something too early, and "looked older than it is"
    /// is how that happens. A caller claiming an absurdly old time (or a restored file whose mtime
    /// went backwards) therefore cannot shorten protection -- at worst an object is retained one
    /// cycle longer, which is the reversible direction (`docs/ONBOARDING_NOTES.md §4.20`).
    ///
    /// No clock, no evidence: `SimFs` reports `None` unless it was built `with_clock`, so the
    /// record's own value survives as the documented fallback, and a store with neither keeps the
    /// "unknown age is never collectable" rule intact.
    ///
    /// One `stat` per record is the cost, and it is deliberate rather than discovered later:
    /// `ADR-035 §3` rejected rich `list` entries ("批量 stat 属于后续 `stat_many` 的优化"), so the
    /// store pays a stat per object on the paths that need ages. `object_records` already reads and
    /// decodes every record, so this changes no complexity class -- on the simulator both are linear
    /// scans of the file table per call.
    fn dated(&self, mut object: CasObjectRef, suffix: &str) -> Result<CasObjectRef, StorageError> {
        let path = self.path(suffix)?;
        let meta = drive_port(self.inner.fs.stat(&path, &self.inner.ctx))?.map_err(from_iofault)?;
        if let Some(port_mtime) = meta.and_then(|meta| meta.modified_at_unix_ms) {
            object.stored_at_unix_ms = Some(
                object
                    .stored_at_unix_ms
                    .map_or(port_mtime, |claim| claim.max(port_mtime)),
            );
        }
        Ok(object)
    }

    /// Every object record on disk, decoded and sorted by digest.
    ///
    /// Enumeration of the metadata directory *is* the answer, so a `list` that refused surfaces as a
    /// `CapacityExceeded` error rather than as a short list a caller cannot tell apart from "that is
    /// all there is". Sorting is not cosmetic: the support bundle and the audit both export this
    /// list, and `ADR-022` requires the same order out of the simulator and a real disk.
    fn object_records(&self) -> Result<Vec<CasObjectRef>, StorageError> {
        let mut objects = Vec::new();
        for suffix in self.list_records(OBJECT_DIRECTORY)? {
            if let Some(object) = self.read_object_record(&suffix)? {
                objects.push(object);
            }
        }
        objects.sort_by(|left, right| left.digest.0.cmp(&right.digest.0));
        Ok(objects)
    }

    /// Read, decode and date one object metadata record. `Ok(None)` means the file is not there.
    ///
    /// Every path that hands out a `CasObjectRef` goes through here -- enumeration, `get`, and the
    /// write path -- because a record whose age depends on which call asked for it is two sources of
    /// truth wearing one type.
    fn read_object_record(&self, suffix: &str) -> Result<Option<CasObjectRef>, StorageError> {
        let Some(raw) = self.read_text(suffix)? else {
            return Ok(None);
        };
        let object = decode_and_check(&raw, "object", decode_object)
            .map_err(|summary| StorageError::new(StorageErrorKind::IntegrityViolation, summary))?;
        self.dated(object, suffix).map(Some)
    }

    /// Snapshot records, read from the directory rather than from a list of them.
    ///
    /// Every snapshot-facing query goes through here so that `list_snapshots`, the
    /// last-known-good fallback and boot verification cannot disagree about which records exist --
    /// the same "two views of one store" defect `docs/STORAGE_RECOVERY_EXECUTION_PLAN.md §9` calls
    /// out for the diagnostics, one level down.
    fn load_snapshots(&self) -> Result<Vec<SnapshotRecord>, StorageError> {
        let dir = Self::record_directory("snapshot");
        let mut values = Vec::new();
        for suffix in self.list_records(&dir)? {
            let Some(raw) = self.read_text(&suffix)? else {
                continue;
            };
            values.push(decode_and_check(&raw, "snapshot", decode_snapshot).map_err(
                |summary| StorageError::new(StorageErrorKind::IntegrityViolation, summary),
            )?);
        }
        values.sort_by(|left, right| left.id.0.cmp(&right.id.0));
        Ok(values)
    }

    /// Apply journal records, read from the directory.
    fn load_apply_journals(&self) -> Result<Vec<ApplyJournalRecord>, StorageError> {
        let dir = Self::record_directory("apply-journal");
        let mut values = Vec::new();
        for suffix in self.list_records(&dir)? {
            let Some(raw) = self.read_text(&suffix)? else {
                continue;
            };
            values.push(
                decode_and_check(&raw, "apply-journal", decode_apply_journal).map_err(
                    |summary| StorageError::new(StorageErrorKind::IntegrityViolation, summary),
                )?,
            );
        }
        values.sort_by(|left, right| left.apply_txn_id.0.cmp(&right.apply_txn_id.0));
        Ok(values)
    }

    /// Revision records, read from the directory.
    ///
    /// This is the root set's `已登记 Revision` class (`RFC-0007 §13.1`): every revision the store
    /// holds protects the semantic digest it names, whether or not a snapshot has caught up with it.
    fn load_revisions(&self) -> Result<Vec<RevisionRecord>, StorageError> {
        let dir = Self::record_directory("revision");
        let mut values = Vec::new();
        for suffix in self.list_records(&dir)? {
            let Some(raw) = self.read_text(&suffix)? else {
                continue;
            };
            values.push(decode_and_check(&raw, "revision", decode_revision).map_err(
                |summary| StorageError::new(StorageErrorKind::IntegrityViolation, summary),
            )?);
        }
        values.sort_by(|left, right| left.id.0.cmp(&right.id.0));
        Ok(values)
    }

    /// OS journal records, read from the directory.
    fn load_os_journals(&self) -> Result<Vec<JournalRecord>, StorageError> {
        let dir = Self::record_directory("os-journal");
        let mut values = Vec::new();
        for suffix in self.list_records(&dir)? {
            let Some(raw) = self.read_text(&suffix)? else {
                continue;
            };
            values.push(
                decode_and_check(&raw, "os-journal", decode_os_journal).map_err(|summary| {
                    StorageError::new(StorageErrorKind::IntegrityViolation, summary)
                })?,
            );
        }
        values.sort_by(|left, right| left.id.0.cmp(&right.id.0));
        Ok(values)
    }

    /// Read the last-known-good pointer file. A restart resolves LKG through this, not through
    /// whatever the previous process had in memory.
    pub fn last_known_good_id(&self) -> Result<Option<String>, StorageError> {
        Ok(self
            .read_text("pointers/last-known-good")?
            .map(|text| text.trim().to_owned())
            .filter(|value| !value.is_empty()))
    }

    pub fn set_last_known_good(&self, snapshot_id: &SnapshotRecordId) -> Result<(), StorageError> {
        self.write_text(
            "pointers/last-known-good",
            &format!("{}\n", snapshot_id.0),
            Durability::D3,
        )
    }

    /// Digests the store currently holds, for diagnostics and tests.
    pub fn object_digests(&self) -> Vec<String> {
        lock(&self.inner.objects).keys().cloned().collect()
    }

    pub fn apply_journal_count(&self) -> usize {
        lock(&self.inner.apply_journals).len()
    }

    fn insert_object(&self, object: CasObjectRef) {
        lock(&self.inner.objects).insert(object.digest.0.clone(), object);
    }
}

impl FsStore {
    fn delete_text(&self, suffix: &str) -> Result<(), StorageError> {
        let path = self.path(suffix)?;
        match drive_port(self.inner.fs.remove(&path, &self.inner.ctx))? {
            Ok(()) => Ok(()),
            Err(fault) if fault.kind == IoFaultKind::NotFound => Ok(()),
            Err(fault) => Err(from_iofault(fault)),
        }
    }

    /// The objects this *process* knows about, from its cache rather than from the disk.
    ///
    /// Deliberate here and nowhere else: the shared-content check below runs once per deletion, and
    /// re-decoding every object record for each one turns a gc cycle into a quadratic read storm --
    /// on the simulator, where every read scans the whole file table. The cost of the cache is that a
    /// record added by another process is not counted as a reference, which is why deletion remains
    /// the caller's decision (`gc.rs` owns the policy) and never happens from inside the store.
    fn list_objects_inline(&self) -> Vec<CasObjectRef> {
        lock(&self.inner.objects).values().cloned().collect()
    }
}

fn text(error: StorageError) -> String {
    error.summary
}

fn lock<T>(slot: &Mutex<T>) -> std::sync::MutexGuard<'_, T> {
    slot.lock().unwrap_or_else(|poisoned| poisoned.into_inner())
}

/// `RFC-0007 §6.1`: `objects/<algo>/<p1>/<p2>/<digest>`.
pub fn content_suffix_for(anchor: &str) -> String {
    let hex = anchor.strip_prefix("sha256:").unwrap_or(anchor);
    let (first, rest) = hex.split_at(hex.len().min(2));
    let (second, remainder) = rest.split_at(rest.len().min(2));
    format!("objects/sha256/{first}/{second}/{remainder}")
}

/// Enumerate one directory of a store, in **store-relative** suffix form.
///
/// This is where the two path bases meet, and it is the only place they do: `Fs` answers with paths
/// under its own root, while `FsStore` thinks in suffixes of `root` (`RFC-0007 §6.4`, frozen by
/// `ADR-035 §2.5`). A missing directory is `Ok(vec![])` -- for a store, "never written under here"
/// and "empty" are the same fact, and `ADR-035 §6bis-bis` is what makes that safe, because a
/// directory only exists where a write created it -- while every other fault propagates. Returning
/// a short list instead of `CapacityExceeded` would be the one lie this port family refuses to tell.
pub(crate) fn list_directory(
    fs: &dyn Fs,
    root: &str,
    ctx: &IoContext,
    dir: &str,
    cap: ListCap,
) -> Result<Vec<String>, StorageError> {
    let target = VPath::try_from_str(&format!("{root}/{dir}"))
        .map_err(|error| StorageError::new(StorageErrorKind::Internal, error.message))?;
    let entries = match drive_port(fs.list(&target, cap, ctx))? {
        Ok(entries) => entries,
        Err(fault) if fault.kind == IoFaultKind::NotFound => return Ok(Vec::new()),
        Err(fault) => return Err(from_iofault(fault)),
    };
    let prefix = format!("{root}/");
    Ok(entries
        .into_iter()
        .map(|entry| entry.as_relative_path().to_owned())
        .map(|full| match full.strip_prefix(&prefix) {
            Some(rest) => rest.to_owned(),
            None => full,
        })
        .collect())
}

/// Whether a listed name is a record this store can read.
///
/// `sanitize` rewrites every `.` in an id, so the extension of a record name is unambiguous: no id
/// can produce a second `.rec`, and no object digest can hide one in its middle.
pub(crate) fn is_record_name(name: &str) -> bool {
    name.ends_with(".rec") || name.ends_with(".obj")
}

/// Whether a listed name is the residue of a write that never completed.
///
/// `StdFs::write_atomic` creates `<target>.tmp-<sequence>` beside the target and renames it, so a
/// name of exactly that shape can only be a crash leftover. The suffix has to be digits: `notes.txt`
/// is somebody else's file and must not be mistaken for debris.
fn is_temp_residue(name: &str) -> bool {
    let Some(at) = name.rfind(".tmp-") else {
        return false;
    };
    let tail = &name[at + ".tmp-".len()..];
    !tail.is_empty() && tail.bytes().all(|byte| byte.is_ascii_digit()) && at > 0
}

fn sanitize(value: &str) -> String {
    value
        .chars()
        .map(|ch| match ch {
            '/' | '\\' | ':' | ' ' | '.' => '_',
            other => other,
        })
        .collect()
}

impl ObjectStore for FsStore {
    fn put<'a>(
        &'a self,
        intent: CasWriteIntent,
    ) -> BoxFuture<'a, Result<CasObjectRef, StorageError>> {
        let store = self.clone();
        Box::pin(async move {
            let mut object = intent.object.clone();
            object.stored_at_unix_ms = Some(intent.stored_at_unix_ms);

            if intent.payload.is_empty() {
                // Metadata-only write: recorded, but nothing can be verified or materialized
                // from it. Kept legal so callers that merely index an external blob still work.
                let suffix = format!("{OBJECT_DIRECTORY}/{}.obj", sanitize(&object.digest.0));
                store.write_text(&suffix, &encode_object(&object), Durability::D2)?;
                // Dated after the write, so the caller is told the same age a later enumeration or a
                // restart will report. A store that returned the claim and persisted the evidence
                // would make the first read the only one that flatters the caller.
                let object = store.dated(object, &suffix)?;
                store.insert_object(object.clone());
                return Ok(object);
            }

            let anchor = caly_common::digest::sha256_digest(&intent.payload);
            if let Some(claimed) = &object.content_sha256 {
                if claimed != &anchor {
                    return Err(StorageError::new(
                        StorageErrorKind::IntegrityViolation,
                        format!("declared content digest {claimed} does not match the payload ({anchor})"),
                    ));
                }
            }
            object.content_sha256 = Some(anchor.clone());
            object.size_bytes = Some(intent.payload.len() as u64);

            // `RFC-0007 §6.2`: write, verify the digest, then rename into place. Here that means
            // the content file is written and read back *before* any metadata names it, so a
            // crash can never leave a manifest entry pointing at a file that does not exist.
            let content_suffix = content_suffix_for(&anchor);
            store.write_bytes(&content_suffix, intent.payload.clone(), Durability::D2)?;
            let round_trip = store
                .read_bytes(&content_suffix, MAX_OBJECT_BYTES)?
                .ok_or_else(|| {
                    StorageError::new(
                        StorageErrorKind::IntegrityViolation,
                        "content disappeared between write and verification",
                    )
                })?;
            if !caly_common::digest::sha256_matches(&anchor, &round_trip) {
                return Err(StorageError::new(
                    StorageErrorKind::IntegrityViolation,
                    "content does not match its own digest immediately after the write",
                ));
            }

            // One file, published by existing. Nothing else has to be updated for the object to be
            // enumerable, so there is no second write that can fail independently of the first.
            let meta_suffix = format!("{OBJECT_DIRECTORY}/{}.obj", sanitize(&object.digest.0));
            store.write_text(&meta_suffix, &encode_object(&object), Durability::D2)?;
            let object = store.dated(object, &meta_suffix)?;
            store.insert_object(object.clone());
            Ok(object)
        })
    }

    fn get<'a>(
        &'a self,
        digest: &'a str,
    ) -> BoxFuture<'a, Result<Option<CasObjectRef>, StorageError>> {
        let store = self.clone();
        let digest = digest.to_owned();
        Box::pin(async move {
            let cached = lock(&store.inner.objects).get(&digest).cloned();
            if let Some(object) = cached {
                return Ok(Some(object));
            }
            let suffix = format!("{OBJECT_DIRECTORY}/{}.obj", sanitize(&digest));
            store.read_object_record(&suffix)
        })
    }

    /// Enumerated by listing `meta/objects` (`ADR-035 §2.3`), which is what replaced the index file
    /// whose absence used to be the reason this store could not answer the question at all
    /// (`docs/ONBOARDING_NOTES.md §4.15`).
    fn list_objects(&self) -> BoxFuture<'_, Result<Vec<CasObjectRef>, StorageError>> {
        let store = self.clone();
        Box::pin(async move { store.object_records() })
    }

    /// Remove an object record and, when nothing else references it, its content.
    ///
    /// Content is shared by construction (two pipeline digests can name the same bytes), so the
    /// content file is only dropped once no remaining metadata references its anchor. A store
    /// that deleted shared content on the first unpin would corrupt an unrelated snapshot.
    fn read_object(
        &self,
        digest: &str,
        max_bytes: u64,
    ) -> BoxFuture<'_, Result<Option<Vec<u8>>, StorageError>> {
        let store = self.clone();
        let digest = digest.to_owned();
        Box::pin(async move {
            let meta = lock(&store.inner.objects).get(&digest).cloned();
            let Some(meta) = meta else {
                // "No such digest" is the same answer `get` gives, and it is not an error.
                return Ok(None);
            };
            let anchor = meta.content_sha256.clone().ok_or_else(|| {
                StorageError::new(
                    StorageErrorKind::NotFound,
                    format!(
                        "object {digest} was recorded without content, so there is nothing to read back"
                    ),
                )
            })?;
            // `0` means "no caller bound", not "read nothing" — and either way the store's own cap
            // applies, so a huge object cannot be pulled in by accident (`RFC-0007 §6.5`).
            let cap = if max_bytes == 0 {
                MAX_OBJECT_BYTES
            } else {
                max_bytes.min(MAX_OBJECT_BYTES)
            };
            let suffix = content_suffix_for(&anchor);
            // The bound is checked here, in store terms, rather than letting the port's own
            // `CapacityExceeded` surface: that message quotes the **path of the content file**
            // (`file exceeds byte cap: var/caly/objects/sha256/...`), and an error text a client can
            // read is not where a store's internal layout belongs. `RFC-0010 §4.1` treats paths as
            // quasi-secrets for exactly this reason. Checking first also makes the wording identical
            // across backends, which `tests/object_contract.rs` now requires.
            if max_bytes != 0 {
                let size = store.stat_size(&suffix)?;
                if let Some(size) = size {
                    if size > max_bytes {
                        return Err(StorageError::new(
                            StorageErrorKind::CapacityExceeded,
                            format!(
                                "object {digest} is {size} bytes and the caller allowed {max_bytes}"
                            ),
                        ));
                    }
                }
            }
            let bytes = store.read_bytes(&suffix, cap)?.ok_or_else(|| {
                StorageError::new(
                    StorageErrorKind::IntegrityViolation,
                    format!("content for {digest} is missing from {suffix}"),
                )
            })?;
            if !caly_common::digest::sha256_matches(&anchor, &bytes) {
                return Err(StorageError::new(
                    StorageErrorKind::IntegrityViolation,
                    format!("object {digest} failed integrity verification on read"),
                ));
            }
            Ok(Some(bytes))
        })
    }

    fn delete(&self, digest: &str) -> BoxFuture<'_, Result<bool, StorageError>> {
        let store = self.clone();
        let digest = digest.to_owned();
        Box::pin(async move {
            let meta_suffix = format!("{OBJECT_DIRECTORY}/{}.obj", sanitize(&digest));
            let Some(removed) = store.read_object_record(&meta_suffix)? else {
                return Ok(false);
            };
            // Unpublishing the metadata record *is* the deletion: enumeration lists files, so once
            // this file is gone no reader can name the object, and there is no index left to update.
            store.delete_text(&meta_suffix)?;
            lock(&store.inner.objects).remove(&digest);

            if let Some(anchor) = &removed.content_sha256 {
                let still_referenced = store
                    .list_objects_inline()
                    .iter()
                    .any(|object| object.content_sha256.as_deref() == Some(anchor.as_str()));
                if !still_referenced {
                    let content_suffix = content_suffix_for(anchor);
                    store.delete_text(&content_suffix)?;
                }
            }
            Ok(true)
        })
    }

    fn materialize<'a>(
        &'a self,
        request: MaterializationRequest,
    ) -> BoxFuture<'a, Result<(), StorageError>> {
        let store = self.clone();
        Box::pin(async move {
            let object = lock(&store.inner.objects)
                .get(&request.object.digest.0)
                .cloned()
                .ok_or_else(|| {
                    StorageError::new(
                        StorageErrorKind::NotFound,
                        format!("object {} not in the store", request.object.digest.0),
                    )
                })?;
            let anchor = object.content_sha256.clone().ok_or_else(|| {
                StorageError::new(
                    StorageErrorKind::IntegrityViolation,
                    format!(
                        "object {} was stored without content, so it cannot be materialized",
                        object.digest.0
                    ),
                )
            })?;
            let content_suffix = content_suffix_for(&anchor);
            let bytes = store
                .read_bytes(&content_suffix, MAX_OBJECT_BYTES)?
                .ok_or_else(|| {
                    StorageError::new(
                        StorageErrorKind::IntegrityViolation,
                        format!(
                            "content for {} is missing from {}",
                            object.digest.0, content_suffix
                        ),
                    )
                })?;
            if !caly_common::digest::sha256_matches(&anchor, &bytes) {
                return Err(StorageError::new(
                    StorageErrorKind::IntegrityViolation,
                    format!(
                        "content for {} failed integrity verification before materialization",
                        object.digest.0
                    ),
                ));
            }

            let destination = VPath::try_from_str(&request.runtime_path)
                .map_err(|error| StorageError::new(StorageErrorKind::Internal, error.message))?;
            match request.mode {
                // A copy is what a runtime directory needs when the caller may later rewrite the
                // materialized file; the CAS object itself must stay immutable.
                MaterializationMode::Copy => {
                    store.write_bytes(&destination.as_relative_path(), bytes, Durability::D2)
                }
                MaterializationMode::HardlinkPreferred | MaterializationMode::ReflinkPreferred => {
                    let source = store.path(&content_suffix)?;
                    drive_port(store.inner.fs.link_or_copy(
                        &source,
                        &destination,
                        &store.inner.ctx,
                    ))?
                    .map_err(from_iofault)?;
                    Ok(())
                }
            }?;

            // Record the mapping only after the copy succeeded. It is what lets `doctor` answer
            // `§9.2`'s "abandoned runtime directory" question after a restart; losing it to a
            // crash here costs only the diagnostic, never the deployment, so a failure to write
            // it is swallowed deliberately rather than failing an apply that already worked.
            let marker = materialization_marker(&object.digest.0);
            let _ = store.write_text(
                &marker,
                &format!("{}\n", request.runtime_path),
                Durability::D1,
            );
            Ok(())
        })
    }
}

impl RevisionStore for FsStore {
    fn put_revision<'a>(
        &'a self,
        record: RevisionRecord,
    ) -> BoxFuture<'a, Result<(), StorageError>> {
        let store = self.clone();
        Box::pin(async move {
            let suffix = FsStore::record_path("revision", &record.id.0);
            store.write_text(&suffix, &encode_revision(&record), Durability::D2)?;
            lock(&store.inner.revisions).insert(record.id.0.clone(), record);
            Ok(())
        })
    }

    fn list_revisions<'a>(&'a self) -> BoxFuture<'a, Result<Vec<RevisionRecord>, StorageError>> {
        let store = self.clone();
        Box::pin(async move { store.load_revisions() })
    }

    fn get_revision<'a>(
        &'a self,
        revision_id: &'a RevisionId,
    ) -> BoxFuture<'a, Result<Option<RevisionRecord>, StorageError>> {
        let store = self.clone();
        let id = revision_id.0.clone();
        Box::pin(async move {
            let suffix = FsStore::record_path("revision", &id);
            match store.read_text(&suffix)? {
                Some(raw) => decode_and_check(&raw, "revision", decode_revision)
                    .map(Some)
                    .map_err(|summary| {
                        StorageError::new(StorageErrorKind::IntegrityViolation, summary)
                    }),
                None => Ok(None),
            }
        })
    }
}

impl SnapshotStore for FsStore {
    fn put_snapshot<'a>(
        &'a self,
        record: SnapshotRecord,
    ) -> BoxFuture<'a, Result<(), StorageError>> {
        let store = self.clone();
        Box::pin(async move {
            // One durable write, not two: the index used to be the second, and a crash between them
            // is exactly the inconsistency `ADR-035` was raised to remove.
            let suffix = FsStore::record_path("snapshot", &record.id.0);
            store.write_text(&suffix, &encode_snapshot(&record), Durability::D3)?;
            lock(&store.inner.snapshots).insert(record.id.0.clone(), record.clone());
            if record.is_last_known_good {
                store.set_last_known_good(&record.id)?;
            }
            Ok(())
        })
    }

    fn get_snapshot<'a>(
        &'a self,
        snapshot_id: &'a SnapshotRecordId,
    ) -> BoxFuture<'a, Result<Option<SnapshotRecord>, StorageError>> {
        let store = self.clone();
        let id = snapshot_id.0.clone();
        Box::pin(async move {
            let suffix = FsStore::record_path("snapshot", &id);
            match store.read_text(&suffix)? {
                Some(raw) => decode_and_check(&raw, "snapshot", decode_snapshot)
                    .map(Some)
                    .map_err(|summary| {
                        StorageError::new(StorageErrorKind::IntegrityViolation, summary)
                    }),
                None => Ok(None),
            }
        })
    }

    fn list_snapshots(&self) -> BoxFuture<'_, Result<Vec<SnapshotRecord>, StorageError>> {
        let store = self.clone();
        Box::pin(async move { store.load_snapshots() })
    }

    fn latest_last_known_good<'a>(
        &'a self,
    ) -> BoxFuture<'a, Result<Option<SnapshotRecord>, StorageError>> {
        let store = self.clone();
        Box::pin(async move {
            if let Some(id) = store.last_known_good_id()? {
                let suffix = FsStore::record_path("snapshot", &id);
                return match store.read_text(&suffix)? {
                    Some(raw) => decode_and_check(&raw, "snapshot", decode_snapshot)
                        .map(Some)
                        .map_err(|summary| {
                            StorageError::new(StorageErrorKind::IntegrityViolation, summary)
                        }),
                    // A pointer at a missing record is the "snapshot/object mismatch" the doctor
                    // must report; guessing a replacement here would hide real damage.
                    None => Err(StorageError::new(
                        StorageErrorKind::NotFound,
                        format!("last-known-good pointer names a missing snapshot record: {id}"),
                    )),
                };
            }

            // No pointer: fall back to the records on disk, not to this process's cache. The cache
            // is what a previous apply left behind, and "which snapshot may a rollback return to" is
            // not a question to answer from stale memory when the disk is right there.
            let candidates = store.load_snapshots()?;
            Ok(candidates
                .into_iter()
                .filter(|snapshot| snapshot.is_last_known_good)
                .max_by_key(|snapshot| snapshot.created_at_unix_ms))
        })
    }
}

impl FsStore {
    /// Where the runtime candidate for `object_digest` was materialized, if ever.
    pub fn materialized_path(&self, object_digest: &str) -> Option<String> {
        self.read_text(&materialization_marker(object_digest))
            .ok()
            .flatten()
            .map(|text| text.trim().to_owned())
            .filter(|text| !text.is_empty())
    }

    /// Rollback points this store can see, by the version each precedes (`§12.2.2`).
    pub fn observed_rollback_points(&self) -> Vec<u32> {
        (0..self.inner.schema_version)
            .filter(|version| {
                self.exists(&format!(
                    "backups/v{version}/{}",
                    crate::schema::SCHEMA_SUFFIX
                ))
                .unwrap_or(false)
            })
            .collect()
    }
}

impl StorageBackend for FsStore {
    fn schema_state(&self) -> crate::audit::Observation<u32> {
        crate::audit::Observation::known(self.inner.schema_version)
    }

    fn migrations_applied(&self) -> u32 {
        self.inner.migrations_applied
    }

    fn rollback_points(&self) -> crate::audit::Observation<Vec<u32>> {
        crate::audit::Observation::known(self.observed_rollback_points())
    }

    fn materialization_state(&self, object_digest: &str) -> crate::audit::Observation<bool> {
        let Some(path) = self.materialized_path(object_digest) else {
            return crate::audit::Observation::unavailable(format!(
                "this store never materialized {object_digest}"
            ));
        };
        match self.exists(&path) {
            Ok(exists) => crate::audit::Observation::known(exists),
            Err(failure) => crate::audit::Observation::unavailable(failure.summary),
        }
    }
}

fn materialization_marker(digest: &str) -> String {
    format!("materialized/{}.ok", sanitize(digest))
}

impl JournalStore for FsStore {
    fn put_journal<'a>(&'a self, record: JournalRecord) -> BoxFuture<'a, Result<(), StorageError>> {
        let store = self.clone();
        Box::pin(async move {
            let suffix = FsStore::record_path("os-journal", &record.id.0);
            store.write_text(&suffix, &encode_os_journal(&record), Durability::D3)?;
            lock(&store.inner.journals).insert(record.id.0.clone(), record);
            Ok(())
        })
    }

    fn get_journal<'a>(
        &'a self,
        journal_id: &'a JournalRecordId,
    ) -> BoxFuture<'a, Result<Option<JournalRecord>, StorageError>> {
        let store = self.clone();
        let id = journal_id.0.clone();
        Box::pin(async move {
            let suffix = FsStore::record_path("os-journal", &id);
            match store.read_text(&suffix)? {
                Some(raw) => decode_and_check(&raw, "os-journal", decode_os_journal)
                    .map(Some)
                    .map_err(|summary| {
                        StorageError::new(StorageErrorKind::IntegrityViolation, summary)
                    }),
                None => Ok(None),
            }
        })
    }

    fn list_pending<'a>(&'a self) -> BoxFuture<'a, Result<Vec<JournalRecord>, StorageError>> {
        let store = self.clone();
        Box::pin(async move {
            Ok(store
                .load_os_journals()?
                .into_iter()
                .filter(|record| matches!(record.state, JournalState::Pending))
                .collect())
        })
    }
}

impl ApplyJournalStore for FsStore {
    fn put_apply_journal<'a>(
        &'a self,
        record: ApplyJournalRecord,
    ) -> BoxFuture<'a, Result<(), StorageError>> {
        let store = self.clone();
        Box::pin(async move {
            let suffix = FsStore::record_path("apply-journal", &record.apply_txn_id.0);
            // The journal leads the irreversible steps, so it is written at the highest tier.
            store.write_text(&suffix, &encode_apply_journal(&record), Durability::D3)?;
            lock(&store.inner.apply_journals).insert(record.apply_txn_id.0.clone(), record);
            Ok(())
        })
    }

    fn get_apply_journal<'a>(
        &'a self,
        apply_txn_id: &'a ApplyTxnId,
    ) -> BoxFuture<'a, Result<Option<ApplyJournalRecord>, StorageError>> {
        let store = self.clone();
        let id = apply_txn_id.0.clone();
        Box::pin(async move {
            let suffix = FsStore::record_path("apply-journal", &id);
            match store.read_text(&suffix)? {
                Some(raw) => decode_and_check(&raw, "apply-journal", decode_apply_journal)
                    .map(Some)
                    .map_err(|summary| {
                        StorageError::new(StorageErrorKind::IntegrityViolation, summary)
                    }),
                None => Ok(None),
            }
        })
    }

    fn list_pending_apply<'a>(
        &'a self,
    ) -> BoxFuture<'a, Result<Vec<ApplyJournalRecord>, StorageError>> {
        let store = self.clone();
        Box::pin(async move {
            Ok(store
                .load_apply_journals()?
                .into_iter()
                .filter(|record| matches!(record.state, ApplyJournalState::Pending))
                .collect())
        })
    }

    fn list_unresolved_apply<'a>(
        &'a self,
    ) -> BoxFuture<'a, Result<Vec<ApplyJournalRecord>, StorageError>> {
        let store = self.clone();
        Box::pin(async move {
            Ok(store
                .load_apply_journals()?
                .into_iter()
                .filter(|record| {
                    matches!(
                        record.state,
                        ApplyJournalState::Pending | ApplyJournalState::RecoveryFailed
                    )
                })
                .collect())
        })
    }

    fn list_apply_journals<'a>(
        &'a self,
    ) -> BoxFuture<'a, Result<Vec<ApplyJournalRecord>, StorageError>> {
        let store = self.clone();
        Box::pin(async move {
            // Reads the records themselves instead of handing back the cache: the bundle is the
            // artifact a third party reads, so it must show what is on disk, and a record that no
            // longer decodes has to surface as an integrity problem rather than being silently
            // absent from the export. Same enumeration `list_pending_apply` uses, so the two can
            // never report different sets of transactions.
            store.load_apply_journals()
        })
    }
}
