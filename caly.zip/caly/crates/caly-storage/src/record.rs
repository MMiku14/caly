//! Text codec for the persisted record shapes.
//!
//! `RFC-0007` describes CAS objects, revisions, snapshots and two kinds of journal, but says
//! nothing about the on-disk encoding, and the workspace has no serialisation dependency
//! (`docs/ONBOARDING_NOTES.md §1.4`). A line-oriented `key=value` format was chosen over a
//! hand-rolled JSON writer for three reasons: it is trivially greppable in a support bundle,
//! a decoder can reject unknown fields instead of ignoring them, and adding a field does not
//! silently reorder a positional encoding.
//!
//! Rules, all of them asserted in the tests below:
//!
//! * first line is the `record:v<N>` tag; a reader refuses a tag it does not know
//! * keys are unique except for list fields, which repeat
//! * values escape `\`, newline and carriage return; `=` is safe because only the first one splits
//! * unknown keys are an error, not a warning: a silent ignore is how a v2 file gets read as v1

use std::collections::BTreeMap;

use crate::cas::{CasObjectRef, ObjectDigest, ObjectKind};
use crate::execution::{ApplyJournalRecord, ApplyJournalState, ApplyPhase, ApplyTxnId};
use crate::job_log::{JobEventRecord, JobLogRecord};
use crate::journal::{JournalAction, JournalRecord, JournalRecordId, JournalState};
use crate::revision::{RevisionId, RevisionNumber, RevisionRecord};
use crate::snapshot::{SnapshotRecord, SnapshotRecordId};
use crate::source::SourceIndexRecord;

pub const RECORD_TAG_V1: &str = "record:v1";

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct RecordCodecError {
    pub summary: String,
}

impl RecordCodecError {
    fn new(summary: impl Into<String>) -> Self {
        Self {
            summary: summary.into(),
        }
    }
}

/// A decoded record: ordered key/value lines plus the version tag.
#[derive(Clone, Debug, Default, Eq, PartialEq)]
pub struct Record {
    pub tag: String,
    pub fields: BTreeMap<String, Vec<String>>,
}

impl Record {
    pub fn new(tag: &str) -> Self {
        let mut fields = BTreeMap::new();
        fields.insert("_tag".to_owned(), vec![tag.to_owned()]);
        Self {
            tag: tag.to_owned(),
            fields,
        }
    }

    pub fn set(&mut self, key: &str, value: impl Into<String>) {
        self.fields.insert(key.to_owned(), vec![value.into()]);
    }

    pub fn set_opt(&mut self, key: &str, value: Option<impl Into<String>>) {
        if let Some(value) = value {
            self.set(key, value);
        }
    }

    pub fn set_bool(&mut self, key: &str, value: bool) {
        self.set(key, if value { "true" } else { "false" });
    }

    pub fn push(&mut self, key: &str, value: impl Into<String>) {
        self.fields
            .entry(key.to_owned())
            .or_default()
            .push(value.into());
    }

    pub fn req(&self, key: &str) -> Result<&str, RecordCodecError> {
        self.fields
            .get(key)
            .and_then(|values| values.first())
            .map(String::as_str)
            .ok_or_else(|| RecordCodecError::new(format!("missing required field {key:?}")))
    }

    pub fn opt(&self, key: &str) -> Option<&str> {
        self.fields
            .get(key)
            .and_then(|values| values.first())
            .map(String::as_str)
    }

    pub fn list(&self, key: &str) -> Vec<String> {
        self.fields.get(key).cloned().unwrap_or_default()
    }

    pub fn bool_field(&self, key: &str) -> Result<bool, RecordCodecError> {
        match self.req(key)? {
            "true" => Ok(true),
            "false" => Ok(false),
            other => Err(RecordCodecError::new(format!(
                "field {key:?} is not a boolean: {other:?}"
            ))),
        }
    }

    pub fn u64_field(&self, key: &str) -> Result<u64, RecordCodecError> {
        self.req(key)?
            .parse::<u64>()
            .map_err(|_| RecordCodecError::new(format!("field {key:?} is not an integer")))
    }

    pub fn i64_field(&self, key: &str) -> Result<i64, RecordCodecError> {
        self.req(key)?
            .parse::<i64>()
            .map_err(|_| RecordCodecError::new(format!("field {key:?} is not an integer")))
    }

    pub fn enum_field<E: Copy + PartialEq + std::fmt::Debug>(
        &self,
        key: &str,
        table: &[(&str, E)],
    ) -> Result<E, RecordCodecError> {
        let value = self.req(key)?;
        table
            .iter()
            .find(|(name, _)| *name == value)
            .map(|(_, parsed)| *parsed)
            .ok_or_else(|| {
                RecordCodecError::new(format!(
                    "field {key:?} has an unrecognised value {value:?}; known values are {}",
                    table
                        .iter()
                        .map(|(name, _)| *name)
                        .collect::<Vec<_>>()
                        .join(", ")
                ))
            })
    }

    pub fn encode(&self) -> String {
        let mut out = String::from(RECORD_TAG_V1);
        out.push('\n');
        for (key, values) in &self.fields {
            if key == "_tag" {
                continue;
            }
            for value in values {
                out.push_str(&format!("{key}={}\n", escape(value)));
            }
        }
        out
    }

    pub fn decode(raw: &str) -> Result<Self, RecordCodecError> {
        let mut tag: Option<String> = None;
        let mut fields: BTreeMap<String, Vec<String>> = BTreeMap::new();

        for (index, line) in raw.lines().enumerate() {
            let line = line.trim_end_matches('\r');
            if line.is_empty() {
                continue;
            }
            if index == 0 {
                if line != RECORD_TAG_V1 {
                    return Err(RecordCodecError::new(format!(
                        "unsupported record tag {line:?}, expected {RECORD_TAG_V1:?}"
                    )));
                }
                tag = Some(line.to_owned());
                continue;
            }
            let Some((key, value)) = line.split_once('=') else {
                return Err(RecordCodecError::new(format!(
                    "line {} is not a key=value pair: {line:?}",
                    index + 1
                )));
            };
            let key = key.trim();
            if key.is_empty() {
                return Err(RecordCodecError::new(format!(
                    "line {} has an empty key",
                    index + 1
                )));
            }
            fields
                .entry(key.to_owned())
                .or_default()
                .push(unescape(value)?);
        }

        let Some(tag) = tag else {
            return Err(RecordCodecError::new("empty record: no version tag"));
        };
        Ok(Self { tag, fields })
    }
}

fn escape(value: &str) -> String {
    let mut out = String::with_capacity(value.len());
    for ch in value.chars() {
        match ch {
            '\\' => out.push_str("\\\\"),
            '\n' => out.push_str("\\n"),
            '\r' => out.push_str("\\r"),
            other => out.push(other),
        }
    }
    out
}

fn unescape(value: &str) -> Result<String, RecordCodecError> {
    let mut out = String::with_capacity(value.len());
    let mut chars = value.chars();
    while let Some(ch) = chars.next() {
        if ch != '\\' {
            out.push(ch);
            continue;
        }
        match chars.next() {
            Some('\\') => out.push('\\'),
            Some('n') => out.push('\n'),
            Some('r') => out.push('\r'),
            Some(other) => {
                return Err(RecordCodecError::new(format!("unknown escape \\{other}")));
            }
            None => {
                return Err(RecordCodecError::new(
                    "record ends with a dangling backslash",
                ))
            }
        }
    }
    Ok(out)
}

// ---------------------------------------------------------------------------
// per-record mappings
// ---------------------------------------------------------------------------

const OBJECT_KINDS: &[(&str, ObjectKind)] = &[
    ("raw-source", ObjectKind::RawSource),
    ("rule-set", ObjectKind::RuleSet),
    ("compiled-artifact", ObjectKind::CompiledArtifact),
    ("stage-output", ObjectKind::StageOutput),
    ("support-bundle", ObjectKind::SupportBundle),
];

const APPLY_PHASES: &[(&str, ApplyPhase)] = &[
    ("prepare", ApplyPhase::Prepare),
    ("cutover", ApplyPhase::Cutover),
    ("finalize", ApplyPhase::Finalize),
    ("recovery", ApplyPhase::Recovery),
];

const APPLY_STATES: &[(&str, ApplyJournalState)] = &[
    ("pending", ApplyJournalState::Pending),
    ("committed", ApplyJournalState::Committed),
    ("reverted", ApplyJournalState::Reverted),
    ("abandoned", ApplyJournalState::Abandoned),
    ("recovery-failed", ApplyJournalState::RecoveryFailed),
];

const OS_JOURNAL_STATES: &[(&str, JournalState)] = &[
    ("pending", JournalState::Pending),
    ("applied", JournalState::Applied),
    ("reverted", JournalState::Reverted),
    ("abandoned", JournalState::Abandoned),
];

pub fn encode_object(object: &CasObjectRef) -> String {
    let mut record = Record::new(RECORD_TAG_V1);
    record.set("kind", object_kind_name(object.kind));
    record.set("digest", object.digest.0.as_str());
    record.set_opt("size", object.size_bytes.map(|value| value.to_string()));
    record.set_opt("content_type", object.content_type.as_deref());
    record.set_opt("content_sha256", object.content_sha256.as_deref());
    record.set_opt(
        "stored_at",
        object.stored_at_unix_ms.map(|value| value.to_string()),
    );
    record.encode()
}

pub fn decode_object(raw: &str) -> Result<CasObjectRef, RecordCodecError> {
    let record = Record::decode(raw)?;
    Ok(CasObjectRef {
        digest: ObjectDigest(record.req("digest")?.to_owned()),
        kind: record.enum_field("kind", OBJECT_KINDS)?,
        size_bytes: match record.opt("size") {
            Some(value) => Some(value.parse::<u64>().map_err(|_| {
                RecordCodecError::new(format!("size is not an integer: {value:?}"))
            })?),
            None => None,
        },
        content_type: record.opt("content_type").map(str::to_owned),
        content_sha256: record.opt("content_sha256").map(str::to_owned),
        stored_at_unix_ms: match record.opt("stored_at") {
            Some(value) => Some(value.parse::<i64>().map_err(|_| {
                RecordCodecError::new(format!("stored_at is not an integer: {value:?}"))
            })?),
            None => None,
        },
    })
}

pub fn encode_revision(record_in: &RevisionRecord) -> String {
    let mut record = Record::new(RECORD_TAG_V1);
    record.set("id", record_in.id.0.as_str());
    record.set("number", record_in.number.0.to_string());
    record.set("profile_id", record_in.profile_id.as_str());
    record.set("semantic_digest", record_in.semantic_digest.as_str());
    record.set("created_at", record_in.created_at_unix_ms.to_string());
    record.encode()
}

pub fn decode_revision(raw: &str) -> Result<RevisionRecord, RecordCodecError> {
    let record = Record::decode(raw)?;
    Ok(RevisionRecord {
        id: RevisionId(record.req("id")?.to_owned()),
        number: RevisionNumber(record.u64_field("number")?),
        profile_id: record.req("profile_id")?.to_owned(),
        semantic_digest: record.req("semantic_digest")?.to_owned(),
        created_at_unix_ms: record.i64_field("created_at")?,
    })
}

pub fn encode_snapshot(snapshot: &SnapshotRecord) -> String {
    let mut record = Record::new(RECORD_TAG_V1);
    record.set("id", snapshot.id.0.as_str());
    record.set("revision_id", snapshot.revision_id.0.as_str());
    record.set("revision_number", snapshot.revision_number.0.to_string());
    record.set("profile_id", snapshot.profile_id.as_str());
    record.set("semantic_digest", snapshot.semantic_digest.as_str());
    record.set(
        "artifact_digest",
        snapshot.compiled_artifact_digest.as_str(),
    );
    record.set("core_binary_digest", snapshot.core_binary_digest.as_str());
    record.set("core_identity", snapshot.core_identity.as_str());
    record.set("apply_plan_summary", snapshot.apply_plan_summary.as_str());
    record.set_opt(
        "journal_id",
        snapshot.journal_id.as_ref().map(|id| id.0.as_str()),
    );
    record.set_opt(
        "selection_memory_digest",
        snapshot.selection_memory_digest.as_deref(),
    );
    record.set("validation_summary", snapshot.validation_summary.as_str());
    record.set("created_at", snapshot.created_at_unix_ms.to_string());
    record.set_bool("last_known_good", snapshot.is_last_known_good);
    record.encode()
}

pub fn decode_snapshot(raw: &str) -> Result<SnapshotRecord, RecordCodecError> {
    let record = Record::decode(raw)?;
    Ok(SnapshotRecord {
        id: SnapshotRecordId(record.req("id")?.to_owned()),
        revision_id: RevisionId(record.req("revision_id")?.to_owned()),
        revision_number: RevisionNumber(record.u64_field("revision_number")?),
        profile_id: record.req("profile_id")?.to_owned(),
        semantic_digest: record.req("semantic_digest")?.to_owned(),
        compiled_artifact_digest: record.req("artifact_digest")?.to_owned(),
        core_binary_digest: record.req("core_binary_digest")?.to_owned(),
        core_identity: record.req("core_identity")?.to_owned(),
        apply_plan_summary: record.req("apply_plan_summary")?.to_owned(),
        journal_id: record
            .opt("journal_id")
            .map(|value| JournalRecordId(value.to_owned())),
        selection_memory_digest: record.opt("selection_memory_digest").map(str::to_owned),
        validation_summary: record.req("validation_summary")?.to_owned(),
        created_at_unix_ms: record.i64_field("created_at")?,
        is_last_known_good: record.bool_field("last_known_good")?,
    })
}

pub fn encode_apply_journal(journal: &ApplyJournalRecord) -> String {
    let mut record = Record::new(RECORD_TAG_V1);
    record.set("journal_id", journal.journal_id.0.as_str());
    record.set("apply_txn_id", journal.apply_txn_id.0.as_str());
    record.set("trace_id", journal.trace_id.as_str());
    record.set_opt("job_id", journal.job_id.as_deref());
    record.set("profile_id", journal.profile_id.as_str());
    record.set("revision_id", journal.revision_id.0.as_str());
    record.set("semantic_digest", journal.semantic_digest.as_str());
    record.set("artifact_digest", journal.compiled_artifact_digest.as_str());
    record.set("core_identity", journal.core_identity.as_str());
    record.set("effect_plan_id", journal.effect_plan_id.as_str());
    record.set("phase", phase_name(journal.current_phase));
    record.set("step", journal.current_step_index.to_string());
    record.set_bool("net_effect_started", journal.net_effect_started);
    record.set_bool("core_cutover_started", journal.core_cutover_started);
    record.set_opt(
        "previous_snapshot_id",
        journal
            .previous_snapshot_id
            .as_ref()
            .map(|id| id.0.as_str()),
    );
    record.set("created_at", journal.created_at_unix_ms.to_string());
    record.set("updated_at", journal.updated_at_unix_ms.to_string());
    record.set("state", state_name(journal.state));
    record.encode()
}

pub fn decode_apply_journal(raw: &str) -> Result<ApplyJournalRecord, RecordCodecError> {
    let record = Record::decode(raw)?;
    Ok(ApplyJournalRecord {
        journal_id: JournalRecordId(record.req("journal_id")?.to_owned()),
        apply_txn_id: ApplyTxnId(record.req("apply_txn_id")?.to_owned()),
        trace_id: record.req("trace_id")?.to_owned(),
        job_id: record.opt("job_id").map(str::to_owned),
        profile_id: record.req("profile_id")?.to_owned(),
        revision_id: RevisionId(record.req("revision_id")?.to_owned()),
        semantic_digest: record.req("semantic_digest")?.to_owned(),
        compiled_artifact_digest: record.req("artifact_digest")?.to_owned(),
        core_identity: record.req("core_identity")?.to_owned(),
        effect_plan_id: record.req("effect_plan_id")?.to_owned(),
        current_phase: record.enum_field("phase", APPLY_PHASES)?,
        current_step_index: record.u64_field("step")? as usize,
        net_effect_started: record.bool_field("net_effect_started")?,
        core_cutover_started: record.bool_field("core_cutover_started")?,
        previous_snapshot_id: record
            .opt("previous_snapshot_id")
            .map(|value| SnapshotRecordId(value.to_owned())),
        created_at_unix_ms: record.i64_field("created_at")?,
        updated_at_unix_ms: record.i64_field("updated_at")?,
        state: record.enum_field("state", APPLY_STATES)?,
    })
}

pub fn encode_os_journal(journal: &JournalRecord) -> String {
    let mut record = Record::new(RECORD_TAG_V1);
    record.set("id", journal.id.0.as_str());
    record.set("state", os_state_name(journal.state));
    record.set("created_at", journal.created_at_unix_ms.to_string());
    record.set("updated_at", journal.updated_at_unix_ms.to_string());
    for action in &journal.actions {
        record.push("action", encode_action(action));
    }
    record.encode()
}

pub fn decode_os_journal(raw: &str) -> Result<JournalRecord, RecordCodecError> {
    let record = Record::decode(raw)?;
    let mut actions = Vec::new();
    for line in record.list("action") {
        actions.push(decode_action(&line)?);
    }
    Ok(JournalRecord {
        id: JournalRecordId(record.req("id")?.to_owned()),
        state: record.enum_field("state", OS_JOURNAL_STATES)?,
        actions,
        created_at_unix_ms: record.i64_field("created_at")?,
        updated_at_unix_ms: record.i64_field("updated_at")?,
    })
}

/// Encode the source index as one atomically replaceable record.
///
/// The cache/provenance fields are intentionally opaque to this crate.  Their anchors are still
/// checked by `decode_source_index`, which lets the storage layer detect torn or altered text before
/// the engine attempts to interpret it.
pub fn encode_source_index(source: &SourceIndexRecord) -> String {
    let mut record = Record::new(RECORD_TAG_V1);
    record.set("source_id", source.source_id.as_str());
    record.set("source_kind", source.source_kind.as_str());
    record.set("label", source.label.as_str());
    record.set("locator", source.locator.as_str());
    record.set("route", source.route.as_str());
    record.set("max_body_bytes", source.max_body_bytes.to_string());
    record.set_opt("media_type", source.media_type.as_deref());
    record.set_bool("strict_mode", source.strict_mode);
    record.set_opt("etag", source.etag.as_deref());
    record.set_opt("last_modified", source.last_modified.as_deref());
    record.set("raw_object_digest", source.raw_object_digest.as_str());
    record.set("raw_content_sha256", source.raw_content_sha256.as_str());
    record.set("raw_bytes_len", source.raw_bytes_len.to_string());
    record.set_opt(
        "raw_stored_at",
        source.raw_stored_at_unix_ms.map(|value| value.to_string()),
    );
    record.set("normalized_digest", source.normalized_digest.as_str());
    record.set("normalized_cache", source.normalized_cache.as_str());
    record.set("provenance_digest", source.provenance_digest.as_str());
    record.set("parser_provenance", source.parser_provenance.as_str());
    record.set("diagnostics_digest", source.diagnostics_digest.as_str());
    record.set("diagnostics", source.diagnostics.as_str());
    record.set("updated_at", source.updated_at_unix_ms.to_string());
    record.encode()
}

fn source_anchor(value: &str) -> bool {
    let Some(hex) = value.strip_prefix("sha256:") else {
        return false;
    };
    hex.len() == 64 && hex.bytes().all(|byte| byte.is_ascii_hexdigit())
}

fn verify_source_text_anchor(
    field: &str,
    value: &str,
    anchor: &str,
) -> Result<(), RecordCodecError> {
    if anchor != caly_common::digest::sha256_digest(value.as_bytes()) {
        return Err(RecordCodecError::new(format!(
            "source index {field} does not match its content anchor"
        )));
    }
    Ok(())
}

pub fn decode_source_index(raw: &str) -> Result<SourceIndexRecord, RecordCodecError> {
    let record = Record::decode(raw)?;
    let source_id = record.req("source_id")?.to_owned();
    let source_kind = record.req("source_kind")?.to_owned();
    let label = record.req("label")?.to_owned();
    let locator = record.req("locator")?.to_owned();
    let route = record.req("route")?.to_owned();
    let max_body_bytes = record.u64_field("max_body_bytes")?;
    let raw_object_digest = record.req("raw_object_digest")?.to_owned();
    let raw_content_sha256 = record.req("raw_content_sha256")?.to_owned();
    let raw_bytes_len = record.u64_field("raw_bytes_len")?;
    let raw_stored_at_unix_ms =
        match record.opt("raw_stored_at") {
            Some(value) => Some(value.parse::<i64>().map_err(|_| {
                RecordCodecError::new("source index raw_stored_at is not an integer")
            })?),
            None => None,
        };
    let normalized_digest = record.req("normalized_digest")?.to_owned();
    let normalized_cache = record.req("normalized_cache")?.to_owned();
    let provenance_digest = record.req("provenance_digest")?.to_owned();
    let parser_provenance = record.req("parser_provenance")?.to_owned();
    let diagnostics_digest = record.req("diagnostics_digest")?.to_owned();
    let diagnostics = record.req("diagnostics")?.to_owned();
    let updated_at_unix_ms = record.i64_field("updated_at")?;

    if source_id.trim().is_empty() {
        return Err(RecordCodecError::new(
            "source index source_id must not be empty",
        ));
    }
    if locator.trim().is_empty() {
        return Err(RecordCodecError::new(
            "source index locator must not be empty",
        ));
    }
    if max_body_bytes == 0 {
        return Err(RecordCodecError::new(
            "source index max_body_bytes must be greater than zero",
        ));
    }
    if raw_object_digest.trim().is_empty() || raw_content_sha256.trim().is_empty() {
        return Err(RecordCodecError::new(
            "source index raw object anchors must not be empty",
        ));
    }
    // `raw_object_digest` addresses the raw body later (`storage.get(record.raw_object_digest)`),
    // so it is an anchor like `raw_content_sha256` — and an anchor a writer could not have
    // produced (non-sha256) must be refused by name, not accepted (round 75: this field was
    // only checked for emptiness; the fixture itself carried `sha256:raw-object`).
    if !source_anchor(&raw_object_digest) {
        return Err(RecordCodecError::new(
            "source index raw_object_digest is not a sha256 anchor",
        ));
    }
    if !source_anchor(&raw_content_sha256) {
        return Err(RecordCodecError::new(
            "source index raw_content_sha256 is not a sha256 anchor",
        ));
    }
    if normalized_cache.is_empty() || parser_provenance.is_empty() {
        return Err(RecordCodecError::new(
            "source index normalized cache and parser provenance must not be empty",
        ));
    }
    // Name a malformed anchor before the content-anchor comparison: "does not match its
    // content anchor" says the value was *altered*, but a value that is not even an anchor
    // is a different diagnosis, and ADR-035's rule is that a restart should not have to
    // guess which part is corrupt (round 75).
    for (field, anchor) in [
        ("normalized_digest", normalized_digest.as_str()),
        ("provenance_digest", provenance_digest.as_str()),
        ("diagnostics_digest", diagnostics_digest.as_str()),
    ] {
        if !source_anchor(anchor) {
            return Err(RecordCodecError::new(format!(
                "source index {field} is not a sha256 anchor"
            )));
        }
    }
    verify_source_text_anchor("normalized_cache", &normalized_cache, &normalized_digest)?;
    verify_source_text_anchor("parser_provenance", &parser_provenance, &provenance_digest)?;
    verify_source_text_anchor("diagnostics", &diagnostics, &diagnostics_digest)?;

    Ok(SourceIndexRecord {
        source_id,
        source_kind,
        label,
        locator,
        route,
        max_body_bytes,
        media_type: record.opt("media_type").map(str::to_owned),
        strict_mode: record.bool_field("strict_mode")?,
        etag: record.opt("etag").map(str::to_owned),
        last_modified: record.opt("last_modified").map(str::to_owned),
        raw_object_digest,
        raw_content_sha256,
        raw_bytes_len,
        raw_stored_at_unix_ms,
        normalized_digest,
        normalized_cache,
        provenance_digest,
        parser_provenance,
        diagnostics_digest,
        diagnostics,
        updated_at_unix_ms,
    })
}

/// Encode one terminal job log record (`ADR-057`) as an atomically replaceable `record:v1` file.
///
/// Events are repeated `event` keys, each carrying `kind<TAB>line` (the tab cannot occur in the
/// tag, and the line is escaped by the record codec, so a multi-line redacted event survives the
/// round trip without a positional encoding).
pub fn encode_job_log(record_in: &JobLogRecord) -> String {
    let mut record = Record::new(RECORD_TAG_V1);
    record.set("job_id", record_in.job_id.as_str());
    record.set("state", record_in.state.as_str());
    record.set("revision", record_in.revision.to_string());
    record.set_opt("outcome", record_in.outcome.as_deref());
    record.set_opt("failure_code", record_in.failure_code.as_deref());
    record.set_opt("failure_summary", record_in.failure_summary.as_deref());
    record.set_opt("last_stage", record_in.last_stage.as_deref());
    record.set_opt(
        "last_stage_pct",
        record_in.last_stage_pct.map(|pct| pct.to_string()),
    );
    record.set("warning_count", record_in.warning_count.to_string());
    record.set("log_count", record_in.log_count.to_string());
    record.set("committed_at", record_in.committed_at_unix_ms.to_string());
    for event in &record_in.events {
        record.push("event", format!("{}\t{}", event.kind, event.line));
    }
    record.encode()
}

pub fn decode_job_log(raw: &str) -> Result<JobLogRecord, RecordCodecError> {
    let record = Record::decode(raw)?;
    let job_id = record.req("job_id")?.to_owned();
    let mut events = Vec::new();
    for packed in record.list("event") {
        let (kind, line) = packed
            .split_once('\t')
            .ok_or_else(|| RecordCodecError::new("job event is missing its kind<tab>line shape"))?;
        events.push(JobEventRecord {
            kind: kind.to_owned(),
            line: line.to_owned(),
        });
    }
    let pct = match record.opt("last_stage_pct") {
        Some(value) => Some(value.parse::<u8>().map_err(|_| {
            RecordCodecError::new("job log last_stage_pct is not an integer 0..=255")
        })?),
        None => None,
    };
    Ok(JobLogRecord {
        job_id,
        state: record.req("state")?.to_owned(),
        revision: record.u64_field("revision")?,
        outcome: record.opt("outcome").map(str::to_owned),
        failure_code: record
            .opt("failure_code")
            .filter(|value| !value.is_empty())
            .map(str::to_owned),
        failure_summary: record.opt("failure_summary").map(str::to_owned),
        last_stage: record.opt("last_stage").map(str::to_owned),
        last_stage_pct: pct,
        warning_count: record.u64_field("warning_count")? as usize,
        log_count: record.u64_field("log_count")? as usize,
        events,
        committed_at_unix_ms: record.i64_field("committed_at")?,
    })
}

/// Decode `raw` for `kind`, rejecting both an unknown version tag and fields this build does not
/// understand. Shared by every durable reader so a v2 file cannot be half-read as v1.
pub fn decode_and_check<T, F>(raw: &str, kind: &str, decode: F) -> Result<T, String>
where
    F: Fn(&str) -> Result<T, RecordCodecError>,
{
    Record::decode(raw)
        .map_err(|error| error.summary)
        .and_then(|record| reject_unknown_fields(&record, kind).map_err(|error| error.summary))
        .and_then(|()| decode(raw).map_err(|error| error.summary))
}

/// `kind=value` for one OS action. Kept in one field so a list of actions stays one line.
fn encode_action(action: &JournalAction) -> String {
    match action {
        JournalAction::SetSystemProxy { value } => format!("set-system-proxy={value}"),
        JournalAction::ClearSystemProxy => "clear-system-proxy".to_owned(),
        JournalAction::SetDns { value } => format!("set-dns={value}"),
        JournalAction::RestoreDns => "restore-dns".to_owned(),
        JournalAction::UpTun { device } => format!("up-tun={device}"),
        JournalAction::DownTun { device } => format!("down-tun={device}"),
        JournalAction::ApplyRoute { summary } => format!("apply-route={summary}"),
        JournalAction::RestoreRoute { summary } => format!("restore-route={summary}"),
    }
}

fn decode_action(text: &str) -> Result<JournalAction, RecordCodecError> {
    let (kind, value) = match text.split_once('=') {
        Some((kind, value)) => (kind, Some(value)),
        None => (text, None),
    };
    let value = || -> Result<String, RecordCodecError> {
        value
            .map(str::to_owned)
            .ok_or_else(|| RecordCodecError::new(format!("action {kind:?} requires a value")))
    };
    Ok(match kind {
        "set-system-proxy" => JournalAction::SetSystemProxy { value: value()? },
        "clear-system-proxy" => JournalAction::ClearSystemProxy,
        "set-dns" => JournalAction::SetDns { value: value()? },
        "restore-dns" => JournalAction::RestoreDns,
        "up-tun" => JournalAction::UpTun { device: value()? },
        "down-tun" => JournalAction::DownTun { device: value()? },
        "apply-route" => JournalAction::ApplyRoute { summary: value()? },
        "restore-route" => JournalAction::RestoreRoute { summary: value()? },
        other => {
            return Err(RecordCodecError::new(format!(
                "unknown journal action {other:?}"
            )))
        }
    })
}

fn object_kind_name(kind: ObjectKind) -> &'static str {
    OBJECT_KINDS
        .iter()
        .find(|(_, value)| *value == kind)
        .map(|(name, _)| *name)
        .unwrap_or("unknown")
}

fn phase_name(phase: ApplyPhase) -> &'static str {
    APPLY_PHASES
        .iter()
        .find(|(_, value)| *value == phase)
        .map(|(name, _)| *name)
        .unwrap_or("unknown")
}

fn state_name(state: ApplyJournalState) -> &'static str {
    APPLY_STATES
        .iter()
        .find(|(_, value)| *value == state)
        .map(|(name, _)| *name)
        .unwrap_or("unknown")
}

fn os_state_name(state: JournalState) -> &'static str {
    OS_JOURNAL_STATES
        .iter()
        .find(|(_, value)| *value == state)
        .map(|(name, _)| *name)
        .unwrap_or("unknown")
}

/// Names of every field a v1 reader understands for each record kind, used to reject unknown
/// keys instead of quietly dropping forward-incompatible data.
pub fn known_fields(kind: &str) -> &'static [&'static str] {
    match kind {
        "object" => &[
            "kind",
            "digest",
            "size",
            "content_type",
            "content_sha256",
            "stored_at",
        ],
        "revision" => &[
            "id",
            "number",
            "profile_id",
            "semantic_digest",
            "created_at",
        ],
        "snapshot" => &[
            "id",
            "revision_id",
            "revision_number",
            "profile_id",
            "semantic_digest",
            "artifact_digest",
            "core_binary_digest",
            "core_identity",
            "apply_plan_summary",
            "journal_id",
            "selection_memory_digest",
            "validation_summary",
            "created_at",
            "last_known_good",
        ],
        "apply-journal" => &[
            "journal_id",
            "apply_txn_id",
            "trace_id",
            "job_id",
            "profile_id",
            "revision_id",
            "semantic_digest",
            "artifact_digest",
            "core_identity",
            "effect_plan_id",
            "phase",
            "step",
            "net_effect_started",
            "core_cutover_started",
            "previous_snapshot_id",
            "created_at",
            "updated_at",
            "state",
        ],
        "os-journal" => &["id", "state", "created_at", "updated_at", "action"],
        "source-index" => &[
            "source_id",
            "source_kind",
            "label",
            "locator",
            "route",
            "max_body_bytes",
            "media_type",
            "strict_mode",
            "etag",
            "last_modified",
            "raw_object_digest",
            "raw_content_sha256",
            "raw_bytes_len",
            "raw_stored_at",
            "normalized_digest",
            "normalized_cache",
            "provenance_digest",
            "parser_provenance",
            "diagnostics_digest",
            "diagnostics",
            "updated_at",
        ],
        "job-log" => &[
            "job_id",
            "state",
            "revision",
            "outcome",
            "failure_code",
            "failure_summary",
            "last_stage",
            "last_stage_pct",
            "warning_count",
            "log_count",
            "committed_at",
            "event",
        ],
        "schema" => &[
            "storage_schema",
            "written_by",
            "created_at",
            "migrations_applied",
        ],
        other => panic!("no field table for record kind {other:?}"),
    }
}

/// Reject keys a v1 reader cannot interpret, so a newer file fails loudly at open time rather
/// than being read as if the extra fields did not exist.
pub fn reject_unknown_fields(record: &Record, kind: &str) -> Result<(), RecordCodecError> {
    let known = known_fields(kind);
    let unknown: Vec<&String> = record
        .fields
        .keys()
        .filter(|key| key.as_str() != "_tag" && !known.contains(&key.as_str()))
        .collect();
    if unknown.is_empty() {
        return Ok(());
    }
    Err(RecordCodecError::new(format!(
        "{kind} record carries fields this build does not understand: {:?}",
        unknown.into_iter().cloned().collect::<Vec<_>>()
    )))
}
