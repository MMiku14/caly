//! Storage audit: the findings `docs/engineering/STORAGE_RECOVERY_EXECUTION_PLAN.md §9.2` asks `doctor` to report.
//!
//! The doc names four things an operator should be able to see:
//!
//! ```text
//! - dangling pending journal
//! - abandoned runtime directory
//! - no valid last-known-good
//! - snapshot/object mismatch
//! ```
//!
//! This module turns that list into a computation over plain data. It is **pure** on purpose:
//! no store access, no traits, no async. Reading records is the caller's job (the daemon owns
//! both the engine and the concrete store); separating the *judgement* is what lets each finding
//! be provoked directly in a test, instead of requiring a whole deployment to go wrong first.
//!
//! Two rules shape the design:
//!
//! 1. **Absence of evidence is reported, not invented.** Whether a materialized runtime file still
//!    exists is only knowable on a backend that can answer. When it cannot, that is a
//!    [`Observation::Unavailable`] and yields an informational line — never a silent "fine", and
//!    never a fabricated finding.
//! 2. **`§7`'s last-known-good discipline is the yardstick.** A missing LKG *while work is
//!    unfinished* is an error; a missing LKG on a store that has never deployed is just emptiness.

use std::fmt;

/// How loudly a finding should be reported.
#[derive(Clone, Copy, Debug, Eq, PartialEq, Ord, PartialOrd)]
pub enum AuditSeverity {
    /// Worth showing; no action required.
    Info,
    /// Action recommended, but the daemon may keep running.
    Warning,
    /// The store cannot guarantee a safe next step.
    Error,
}

impl AuditSeverity {
    pub fn is_reportable(self) -> bool {
        !matches!(self, Self::Info)
    }

    pub fn as_str(self) -> &'static str {
        match self {
            Self::Info => "info",
            Self::Warning => "warning",
            Self::Error => "error",
        }
    }
}

#[derive(Clone, Copy, Debug, Eq, PartialEq, Ord, PartialOrd)]
pub enum AuditFindingKind {
    /// A transaction journaled but never settled: the crash-recovery entry point.
    DanglingPendingJournal,
    /// Compensation already failed once for this transaction.
    UnresolvedRecoveryFailure,
    /// The materialized runtime candidate is gone while its transaction is still open.
    AbandonedRuntime,
    /// Unfinished work exists but there is nothing to fall back to.
    NoValidLastKnownGood,
    /// The last-known-good marker names a snapshot the store cannot return.
    DanglingLastKnownGood,
    /// Even the last-known-good lookup failed, so the store cannot answer a safety question.
    LastKnownGoodUnreadable,
    /// A snapshot names an artifact the object store cannot return.
    SnapshotObjectMismatch,
    /// A migration recorded its counter but left no rollback point (`§12.2.2`).
    MissingRollbackPoint,
    /// The backend could not answer a question this audit wanted to ask.
    NotObservable,
    /// The schema on disk is older than this build; startup gates it, the audit only notes it.
    OlderSchema,
    /// Everything checked out.
    Clean,
}

impl AuditFindingKind {
    pub fn as_str(self) -> &'static str {
        match self {
            Self::DanglingPendingJournal => "dangling-pending-journal",
            Self::UnresolvedRecoveryFailure => "unresolved-recovery-failure",
            Self::AbandonedRuntime => "abandoned-runtime",
            Self::NoValidLastKnownGood => "no-valid-last-known-good",
            Self::DanglingLastKnownGood => "dangling-last-known-good",
            Self::LastKnownGoodUnreadable => "last-known-good-unreadable",
            Self::SnapshotObjectMismatch => "snapshot-object-mismatch",
            Self::MissingRollbackPoint => "missing-rollback-point",
            Self::NotObservable => "not-observable",
            Self::OlderSchema => "older-schema",
            Self::Clean => "clean",
        }
    }
}

/// One audit finding.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct AuditFinding {
    pub kind: AuditFindingKind,
    pub severity: AuditSeverity,
    /// What it is about: a transaction id, a snapshot id, an object digest, a subsystem name.
    pub subject: String,
    pub detail: String,
}

impl AuditFinding {
    fn new(
        kind: AuditFindingKind,
        severity: AuditSeverity,
        subject: impl Into<String>,
        detail: impl Into<String>,
    ) -> Self {
        Self {
            kind,
            severity,
            subject: subject.into(),
            detail: detail.into(),
        }
    }

    /// The rendered line. One place, so `doctor`, a support bundle and a test cannot drift.
    pub fn line(&self) -> String {
        format!(
            "{} [{}] {}: {}",
            self.kind.as_str(),
            self.severity.as_str(),
            self.subject,
            self.detail
        )
    }
}

/// "Read and found nothing" and "could not look" are different facts, and collapsing them is how a
/// diagnostic starts lying.
#[derive(Clone, Debug, Eq, PartialEq)]
pub enum Observation<T> {
    Known(T),
    Unavailable(String),
}

impl<T: Clone> Observation<T> {
    pub fn known(value: T) -> Self {
        Self::Known(value)
    }

    pub fn unavailable(reason: impl Into<String>) -> Self {
        Self::Unavailable(reason.into())
    }

    pub fn as_ref(&self) -> Observation<&T> {
        match self {
            Self::Known(value) => Observation::Known(value),
            Self::Unavailable(reason) => Observation::Unavailable(reason.clone()),
        }
    }

    pub fn value(&self) -> Option<&T> {
        match self {
            Self::Known(value) => Some(value),
            Self::Unavailable(_) => None,
        }
    }
}

/// A journaled transaction that never reached a settled state.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct UnfinishedJournal {
    pub apply_txn_id: String,
    /// `pending` or `recovery-failed`. Kept as text so the audit does not depend on the enum's
    /// shape, which is also what lets a test write one by hand.
    pub state: String,
    pub current_step_index: usize,
    pub core_cutover_started: bool,
    pub net_effect_started: bool,
    pub updated_at_unix_ms: i64,
    /// Whether the materialized runtime candidate still exists, as far as the backend can tell.
    pub runtime: Observation<bool>,
}

impl UnfinishedJournal {
    pub fn pending(apply_txn_id: impl Into<String>) -> Self {
        Self {
            apply_txn_id: apply_txn_id.into(),
            state: "pending".to_owned(),
            current_step_index: 0,
            core_cutover_started: false,
            net_effect_started: false,
            updated_at_unix_ms: 0,
            runtime: Observation::Unavailable("no runtime path recorded".to_owned()),
        }
    }
}

/// A snapshot and the artifact it expects to be able to materialize.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct SnapshotRef {
    pub id: String,
    pub artifact_digest: String,
}

/// Inputs to one audit pass.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct AuditInput {
    pub storage_schema: Observation<u32>,
    pub expected_schema: u32,
    pub migrations_applied: u32,
    pub objects: Vec<String>,
    pub snapshots: Vec<SnapshotRef>,
    pub last_known_good: Option<String>,
    /// Set when asking the store for the last-known-good snapshot itself failed. "Could not look"
    /// must not be recorded as "there is none": the first is an unreadable store, the second is an
    /// uninitialised one, and they call for different operator actions.
    pub last_known_good_error: Option<String>,
    pub unfinished: Vec<UnfinishedJournal>,
    pub pending_os_journals: usize,
    pub rollback_points: Observation<Vec<u32>>,
    pub now_unix_ms: i64,
    pub stale_after_ms: i64,
}

impl Default for AuditInput {
    fn default() -> Self {
        Self {
            storage_schema: Observation::Unavailable("not read".to_owned()),
            expected_schema: crate::STORAGE_SCHEMA_VERSION,
            migrations_applied: 0,
            objects: Vec::new(),
            snapshots: Vec::new(),
            last_known_good: None,
            last_known_good_error: None,
            unfinished: Vec::new(),
            pending_os_journals: 0,
            rollback_points: Observation::Unavailable("not probed".to_owned()),
            now_unix_ms: 0,
            stale_after_ms: 10 * 60 * 1000,
        }
    }
}

impl AuditInput {
    pub fn with_unfinished(mut self, journal: UnfinishedJournal) -> Self {
        self.unfinished.push(journal);
        self
    }

    pub fn with_object(mut self, digest: impl Into<String>) -> Self {
        self.objects.push(digest.into());
        self
    }

    pub fn with_snapshot(mut self, id: impl Into<String>, artifact: impl Into<String>) -> Self {
        self.snapshots.push(SnapshotRef {
            id: id.into(),
            artifact_digest: artifact.into(),
        });
        self
    }
}

/// The computed audit.
#[derive(Clone, Debug, Default, Eq, PartialEq)]
pub struct StorageAudit {
    pub findings: Vec<AuditFinding>,
    pub object_count: usize,
    pub snapshot_count: usize,
    pub unresolved_count: usize,
    /// `v3`, or `unreadable` when the marker could not be read.
    pub schema_text: String,
    pub expected_schema: u32,
    pub pending_os_journals: usize,
}

impl StorageAudit {
    pub fn has_errors(&self) -> bool {
        self.severity_ceiling() == Some(AuditSeverity::Error)
    }

    pub fn has_warnings(&self) -> bool {
        self.severity_ceiling() >= Some(AuditSeverity::Warning)
    }

    fn severity_ceiling(&self) -> Option<AuditSeverity> {
        self.findings
            .iter()
            .filter(|finding| finding.severity.is_reportable())
            .map(|finding| finding.severity)
            .max()
    }

    pub fn lines_at(&self, severity: AuditSeverity) -> Vec<String> {
        self.findings
            .iter()
            .filter(|finding| finding.severity == severity)
            .map(AuditFinding::line)
            .collect()
    }

    pub fn warning_lines(&self) -> Vec<String> {
        self.lines_at(AuditSeverity::Warning)
    }

    pub fn error_lines(&self) -> Vec<String> {
        self.lines_at(AuditSeverity::Error)
    }

    pub fn info_lines(&self) -> Vec<String> {
        self.lines_at(AuditSeverity::Info)
    }

    /// Every finding, in the order they were raised, regardless of severity.
    ///
    /// `doctor` splits findings into three tiers because an operator has to triage them; an export
    /// does not, and reassembling the three lists in the wrong order is how a bundle ends up
    /// reading as though the info lines were errors.
    pub fn finding_lines(&self) -> Vec<String> {
        self.findings.iter().map(AuditFinding::line).collect()
    }

    pub fn findings_of(&self, kind: AuditFindingKind) -> Vec<&AuditFinding> {
        self.findings
            .iter()
            .filter(|finding| finding.kind == kind)
            .collect()
    }

    /// One-line state summary, used as `DoctorReport.summary`. Carried on the audit itself so a
    /// caller cannot render the numbers from one input and the findings from another.
    pub fn summary_line(&self) -> String {
        format!(
            "storage audit: schema={} expected=v{} objects={} snapshots={} unresolved={} os_journals={} reportable_findings={}",
            self.schema_text,
            self.expected_schema,
            self.object_count,
            self.snapshot_count,
            self.unresolved_count,
            self.pending_os_journals,
            self.findings
                .iter()
                .filter(|finding| finding.severity.is_reportable())
                .count(),
        )
    }
}

impl fmt::Display for StorageAudit {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        let reportable: Vec<&AuditFinding> = self
            .findings
            .iter()
            .filter(|finding| finding.severity.is_reportable())
            .collect();
        if reportable.is_empty() {
            return write!(f, "clean");
        }
        for (index, finding) in reportable.iter().enumerate() {
            if index > 0 {
                writeln!(f)?;
            }
            write!(f, "{}", finding.line())?;
        }
        Ok(())
    }
}

/// Run the audit.
pub fn audit(input: &AuditInput) -> StorageAudit {
    let mut findings: Vec<AuditFinding> = Vec::new();

    // §9.2.1 dangling pending journal, and the escalated variant.
    for journal in &input.unfinished {
        if journal.state == "recovery-failed" {
            findings.push(AuditFinding::new(
                AuditFindingKind::UnresolvedRecoveryFailure,
                AuditSeverity::Error,
                &journal.apply_txn_id,
                format!(
                    "compensation failed and nothing has resolved it (cursor {}); recovery must not be reported as finished",
                    journal.current_step_index
                ),
            ));
            continue;
        }
        let age = input.now_unix_ms.saturating_sub(journal.updated_at_unix_ms);
        // A transaction that already crossed cutover cannot be assumed to be "still running".
        let severity = if journal.core_cutover_started || age >= input.stale_after_ms {
            AuditSeverity::Error
        } else {
            AuditSeverity::Warning
        };
        findings.push(AuditFinding::new(
            AuditFindingKind::DanglingPendingJournal,
            severity,
            &journal.apply_txn_id,
            format!(
                "journal open at step {}, cutover_started={}, net_effect_started={}, age={}ms",
                journal.current_step_index,
                journal.core_cutover_started,
                journal.net_effect_started,
                age
            ),
        ));
    }

    // §9.2.2 abandoned runtime directory. Only assertable where the backend can look.
    let mut runtime_unavailable: Vec<String> = Vec::new();
    for journal in &input.unfinished {
        match &journal.runtime {
            Observation::Known(true) => {}
            Observation::Known(false) => findings.push(AuditFinding::new(
                AuditFindingKind::AbandonedRuntime,
                AuditSeverity::Error,
                &journal.apply_txn_id,
                format!(
                    "transaction {} is unresolved but its materialized candidate is gone",
                    journal.apply_txn_id
                ),
            )),
            Observation::Unavailable(reason) => runtime_unavailable.push(reason.clone()),
        }
    }
    if !runtime_unavailable.is_empty() {
        runtime_unavailable.sort();
        runtime_unavailable.dedup();
        findings.push(AuditFinding::new(
            AuditFindingKind::NotObservable,
            AuditSeverity::Info,
            "runtime-presence",
            runtime_unavailable.join("; "),
        ));
    }

    // §9.2.3 no valid last-known-good, but only where that actually costs something.
    if let Some(reason) = &input.last_known_good_error {
        findings.push(AuditFinding::new(
            AuditFindingKind::LastKnownGoodUnreadable,
            AuditSeverity::Error,
            "store",
            format!(
                "the last-known-good lookup failed ({reason}); the store cannot answer whether a safe fallback exists"
            ),
        ));
    }

    let needs_fallback = !input.unfinished.is_empty() || !input.snapshots.is_empty();
    if input.last_known_good.is_none() && input.last_known_good_error.is_none() && needs_fallback {
        findings.push(AuditFinding::new(
            AuditFindingKind::NoValidLastKnownGood,
            AuditSeverity::Error,
            "store",
            format!(
                "no last-known-good marker while {} unfinished transaction(s) and {} snapshot(s) exist; recovery has nothing to fall back to",
                input.unfinished.len(),
                input.snapshots.len()
            ),
        ));
    }

    // A marker naming a snapshot that is not there is worse than no marker: it lies about safety.
    if let Some(marker) = &input.last_known_good {
        if !input
            .snapshots
            .iter()
            .any(|snapshot| &snapshot.id == marker)
        {
            findings.push(AuditFinding::new(
                AuditFindingKind::DanglingLastKnownGood,
                AuditSeverity::Error,
                marker,
                "the last-known-good pointer names a snapshot record the store does not hold",
            ));
        }
    }

    // §9.2.4 snapshot/object mismatch.
    for snapshot in &input.snapshots {
        if !input
            .objects
            .iter()
            .any(|digest| digest == &snapshot.artifact_digest)
        {
            findings.push(AuditFinding::new(
                AuditFindingKind::SnapshotObjectMismatch,
                AuditSeverity::Error,
                &snapshot.id,
                format!(
                    "referenced artifact {} is not present in the object store",
                    snapshot.artifact_digest
                ),
            ));
        }
    }

    // Schema notes: the startup gate refuses these, the audit only explains them.
    match &input.storage_schema {
        Observation::Known(found) if *found < input.expected_schema => {
            findings.push(AuditFinding::new(
                AuditFindingKind::OlderSchema,
                AuditSeverity::Info,
                format!("v{found}"),
                format!(
                    "store is v{found}, this build is v{}; startup will migrate or refuse",
                    input.expected_schema
                ),
            ))
        }
        Observation::Unavailable(reason) => findings.push(AuditFinding::new(
            AuditFindingKind::NotObservable,
            AuditSeverity::Info,
            "schema-marker",
            reason.clone(),
        )),
        _ => {}
    }
    if input.migrations_applied > 0 {
        if let Observation::Known(points) = &input.rollback_points {
            if points.is_empty() {
                findings.push(AuditFinding::new(
                    AuditFindingKind::MissingRollbackPoint,
                    AuditSeverity::Warning,
                    "backups",
                    format!(
                        "{} migration(s) are recorded but no rollback point exists (`§12.2.2` requires one before migrating)",
                        input.migrations_applied
                    ),
                ));
            }
        }
    }

    let mut audit = StorageAudit {
        findings,
        object_count: input.objects.len(),
        snapshot_count: input.snapshots.len(),
        unresolved_count: input.unfinished.len(),
        schema_text: match &input.storage_schema {
            Observation::Known(version) => format!("v{version}"),
            Observation::Unavailable(_) => "unreadable".to_owned(),
        },
        expected_schema: input.expected_schema,
        pending_os_journals: input.pending_os_journals,
    };
    if !audit.has_errors() && !audit.has_warnings() {
        audit.findings.push(AuditFinding::new(
            AuditFindingKind::Clean,
            AuditSeverity::Info,
            "store",
            format!(
                "{} object(s), {} snapshot(s), {} unfinished transaction(s)",
                audit.object_count, audit.snapshot_count, audit.unresolved_count
            ),
        ));
    }
    audit
}

/// How long an unfinished transaction may sit before the audit calls it stale (`§9.2`).
///
/// One constant on purpose: `doctor` and the support bundle quote the same threshold, and two
/// copies is how the two views of one store disagree.
pub const DEFAULT_STALE_AFTER_MS: i64 = 10 * 60 * 1000;

/// Read everything the audit needs out of a backend, then judge it.
///
/// [`audit`] stays pure (see the module docs); this is the I/O half, and it lives next to the
/// store so that every caller assembles `AuditInput` the same way. The daemon's `doctor` and the
/// engine's support bundle both need it, which is exactly why it is one function: two callers
/// each reading the store for themselves is how two views of one store drift apart.
///
/// A backend that cannot answer a question is passed through as an
/// [`Observation::Unavailable`] (or, for snapshot enumeration, as an empty retained set), so the
/// resulting audit reports what is not knowable rather than reporting health.
pub fn audit_backend(
    backend: &dyn crate::store::StorageBackend,
    now_unix_ms: i64,
    ctx: &caly_io::IoContext,
) -> Result<StorageAudit, String> {
    let objects: Vec<String> = caly_io::block_on_ready(backend.list_objects(ctx))?
        .map_err(|failure| failure.summary)?
        .into_iter()
        .map(|object| object.digest.0)
        .collect();

    let snapshots: Vec<SnapshotRef> = match caly_io::block_on_ready(backend.list_snapshots(ctx))? {
        Ok(records) => records
            .into_iter()
            .map(|record| SnapshotRef {
                id: record.id.0,
                artifact_digest: record.compiled_artifact_digest,
            })
            .collect(),
        // No enumeration means no snapshot/object mismatch finding can fire. That is not the
        // same as "no mismatch", and `audit` reports the difference.
        Err(failure) if matches!(failure.kind, crate::store::StorageErrorKind::Unsupported) => {
            Vec::new()
        }
        Err(failure) => return Err(failure.summary),
    };

    let unfinished: Vec<UnfinishedJournal> =
        caly_io::block_on_ready(backend.list_unresolved_apply(ctx))?
            .map_err(|failure| failure.summary)?
            .into_iter()
            .map(|journal| UnfinishedJournal {
                apply_txn_id: journal.apply_txn_id.0.clone(),
                state: match journal.state {
                    crate::execution::ApplyJournalState::RecoveryFailed => {
                        "recovery-failed".to_owned()
                    }
                    _ => "pending".to_owned(),
                },
                current_step_index: journal.current_step_index,
                core_cutover_started: journal.core_cutover_started,
                net_effect_started: journal.net_effect_started,
                updated_at_unix_ms: journal.updated_at_unix_ms,
                runtime: backend.materialization_state(&journal.compiled_artifact_digest),
            })
            .collect();

    let pending_os = caly_io::block_on_ready(backend.list_pending(ctx))?
        .map_err(|failure| failure.summary)?
        .len();

    let (last_known_good, last_known_good_error) =
        match caly_io::block_on_ready(backend.latest_last_known_good(ctx))? {
            Ok(Some(snapshot)) => (Some(snapshot.id.0), None),
            Ok(None) => (None, None),
            Err(failure) => (None, Some(failure.summary)),
        };

    let input = AuditInput {
        storage_schema: backend.schema_state(),
        expected_schema: crate::STORAGE_SCHEMA_VERSION,
        migrations_applied: backend.migrations_applied(),
        objects,
        snapshots,
        last_known_good,
        last_known_good_error,
        unfinished,
        pending_os_journals: pending_os,
        rollback_points: backend.rollback_points(),
        now_unix_ms,
        stale_after_ms: DEFAULT_STALE_AFTER_MS,
    };
    Ok(audit(&input))
}
