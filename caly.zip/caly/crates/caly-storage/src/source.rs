//! Durable source-index record shape.
//!
//! The storage crate deliberately does not know the pipeline's `NormalizedSource` or provenance
//! types.  It owns the durable envelope and its integrity anchors; the engine owns the typed
//! encode/decode of the opaque cache fields.  Keeping that split prevents the storage layer from
//! depending upward on the pipeline while still making the source facts one atomic record.

/// One atomically published source update index entry.
///
/// `normalized_cache`, `parser_provenance`, and `diagnostics` are deterministic, versioned opaque
/// strings owned by `caly-engine`.  Their SHA-256 anchors are checked here before the record is
/// accepted, so a restart never hands the engine silently altered cache bytes.  The raw body itself
/// remains in CAS and is identified by both `raw_object_digest` and `raw_content_sha256`.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct SourceIndexRecord {
    pub source_id: String,
    pub source_kind: String,
    pub label: String,
    pub locator: String,
    pub route: String,
    pub max_body_bytes: u64,
    pub media_type: Option<String>,
    pub strict_mode: bool,
    pub etag: Option<String>,
    pub last_modified: Option<String>,
    pub raw_object_digest: String,
    pub raw_content_sha256: String,
    pub raw_bytes_len: u64,
    pub raw_stored_at_unix_ms: Option<i64>,
    pub normalized_digest: String,
    pub normalized_cache: String,
    pub provenance_digest: String,
    pub parser_provenance: String,
    pub diagnostics_digest: String,
    pub diagnostics: String,
    pub updated_at_unix_ms: i64,
}
