//! How the durable store drives the port underneath it (`ADR-036 §2.6`).
//!
//! `RFC-0006` gives every port a `BoxFuture`, but until this file existed the store could express
//! exactly one answer about one: "be ready on the first poll, or the store is broken". That made a
//! whole class of backends structurally unwritable. A real `Http` fetch, a `Proc` wait, or a
//! blocking-pool submission all *suspend*, and each would have come back as
//! `StorageErrorKind::Internal` -- the store blaming itself for a port that is merely not finished.
//! `ADR-036 §2.6` named the fix ("`block_on_ready` 的「只 poll 一次」必须升级为「在 `Deadline` 内轮询到
//! ready」"); this file is the store's half of that sentence, and `crates/caly-engine/tests/
//! store_suspension_is_contention.rs` is what it buys.
//!
//! # What the budget counts, and why it is not time
//!
//! [`STORE_PORT_POLL_BUDGET`] counts **polls**, not milliseconds. A deadline can only be judged by
//! whoever holds a clock (`docs/ONBOARDING_NOTES.md §4.86`), and this layer still keeps none of its
//! own: `caly-storage` reaches the world only through `dyn Fs` (`ADR-011`), and a busy-wait against a
//! real clock with nothing to wait *on* would burn CPU to look patient. Since round 35 (`ADR-039 §2`,
//! step 3) the budget **carries a deadline when the caller stated one and the store was opened with a
//! clock** -- `ctx.deadline_mono_ms` plus the store's injected `Clock`, never a `SystemTime::now`
//! here (`clippy.toml` forbids it workspace-wide, and the ban is the point). A deadline without a
//! clock is still ignored rather than guessed at, which is the port layer's own rule
//! (`caly_io::runtime`: only `Drive` has the clock, only the clock may say the time is up).
//!
//! # Why the answer is `Busy` and not `Internal`
//!
//! `caly_io::drive` already answers a non-converging port with a typed
//! [`caly_io::IoFaultKind::Busy`], `retryable` and `transient` set. [`drive_port`] runs that refusal
//! through the *same* table it runs a port's own error through ([`from_iofault`]), so the kind
//! survives: `Busy` stays `Busy`. It matters one layer up, because `caly-engine`'s
//! `StoreRefusal::from_storage_error` promotes exactly that `Busy` into the `storage_busy` class that
//! `OVERLOAD_AND_RETRY_MODEL §3.4` / `§6.2` count for the operator. `Internal` would have been one
//! word for "corrupt" and "not yet", which is the operator's judgement replaced by a guess.
//!
//! The poll loop is not re-implemented here. `caly_io::runtime::drive` is the only place in
//! production that builds a waker, and this file calls it.

use caly_io::{drive, BoxFuture, Drive, IoFault, IoFaultKind};

use crate::store::{StorageError, StorageErrorKind};

/// How many times one store call may poll a port before the port is called stuck.
///
/// Not a throughput knob. Every port in this workspace finishes on its first poll, so production never
/// reaches 64; the number exists so that "a backend that suspends" is a *supported* shape rather than
/// an internal error, and so the boundary is a number a test can push against
/// (`crates/caly-storage/tests/store_port_budget.rs` measures it from both sides). It is also the
/// reason a permanently-stuck port cannot turn a store call into an infinite loop: the bound is what
/// makes "we will get back to you" checkable rather than hopeful (`ADR-036 §2.1`'s argument, applied
/// one layer down).
pub const STORE_PORT_POLL_BUDGET: u32 = 64;

const _: () = assert!(
    STORE_PORT_POLL_BUDGET > 0,
    "a zero-poll budget would refuse every port call, which is an outage and not a limit"
);

const _: () = assert!(
    STORE_PORT_POLL_BUDGET >= 2,
    "one poll is the old behaviour; a budget that cannot accommodate a port that needs a second look \
     is the same bug with a constant on it"
);

/// Drive a port future under the store's budget, translating a *driver* refusal into store terms.
///
/// Only the driver's answer is translated here. A port that answered -- even with an error -- still
/// gets the call site's own context (`stat {suffix}: ...`), because "the port said no" and "the port
/// never said anything" are different facts and the message has to keep them apart.
pub(crate) fn drive_port<T>(
    future: BoxFuture<'_, T>,
    ctx: &caly_io::IoContext,
    clock: Option<&dyn caly_io::Clock>,
) -> Result<T, StorageError> {
    // Cancellation rides every drive (`ADR-039 §2.3`): the leading checks inside the store methods
    // refuse work that has not started; this is the half that covers a port which suspends -- the
    // driver notices a fired token between polls and answers `Cancelled` instead of polling on.
    let mut limits = Drive::bounded(STORE_PORT_POLL_BUDGET).with_cancel(&ctx.cancel);
    // The deadline needs both halves (`ADR-039 §2`, step 3): an absolute instant on the context and
    // a clock to judge it against. Either half alone is *ignored*, not guessed -- a deadline without
    // a clock is never called a timeout, and a clock without a deadline never invents one.
    if let (Some(deadline), Some(clock)) = (ctx.deadline_mono_ms, clock) {
        limits = limits.with_deadline(caly_io::Deadline(deadline), clock);
    }
    drive(future, limits).map_err(from_iofault)
}

/// The one table from a port-layer fault to the store's error kind -- driver refusals included.
///
/// Moved out of `fs_store.rs` rather than copied, because two tables is how the driver's answer and
/// the port's answer start meaning different things in different files
/// (`docs/ONBOARDING_NOTES.md §4.81`'s shape, one fact two spellings).
pub(crate) fn from_iofault(fault: IoFault) -> StorageError {
    let kind = match fault.kind {
        IoFaultKind::NotFound => StorageErrorKind::NotFound,
        IoFaultKind::AlreadyExists => StorageErrorKind::AlreadyExists,
        IoFaultKind::Busy => StorageErrorKind::Busy,
        IoFaultKind::CapacityExceeded => StorageErrorKind::CapacityExceeded,
        IoFaultKind::IntegrityViolation => StorageErrorKind::IntegrityViolation,
        IoFaultKind::Timeout => StorageErrorKind::Timeout,
        IoFaultKind::Cancelled => StorageErrorKind::Cancelled,
        _ => StorageErrorKind::Internal,
    };
    StorageError::new(kind, fault.summary)
}
