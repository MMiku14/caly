//! Storage schema version and migration gating (`RFC-0007 §12`, acceptance `§15.5`).
//!
//! `STORAGE_SCHEMA_VERSION` existed as a constant in `lib.rs` that nothing read and nothing
//! wrote. That satisfies neither `§12.2.1` ("启动时若发现 schema 版本不匹配：MUST 先进行兼容性检查")
//! nor `§15.5` ("Schema 迁移失败会拒绝启动"): a v0 directory would have been opened as if it were
//! v1, silently. This module makes the version a fact on disk and the refusal a code path.
//!
//! ## The rules this module encodes
//!
//! | `§12.2` | where |
//! |---|---|
//! | MUST compatibility-check at startup | [`classify`] + [`SchemaOpener::open`] before any other read |
//! | MUST create a backup / rollback point first | [`create_rollback_point`], invoked before the first hook |
//! | MUST refuse to start if migration fails | any hook error aborts `open` |
//! | SHOULD re-check consistency after migrating | [`STORE-VERIFY`] pass re-run after the chain |
//!
//! `§12.3` ("不得静默把未知旧 schema 当作当前 schema 使用") is implemented literally: a store whose
//! recorded version is *higher* than this build knows is refused outright, with no attempt to
//! interpret it. Forward compatibility cannot be assumed from a format you have not read.
//!
//! ## Version separation (`§12.1`)
//!
//! This version counts the *on-disk layout* only. It is intentionally not shared with the API
//! `ProtocolVersion`, the IR digest scheme, the core compatibility version, or the pipeline epoch;
//! the record carries its own `storage_schema` field name so a reader can never confuse it with
//! another version number that happens to be 1 as well.

use caly_io::{ByteCap, Durability, Fs, IoContext, IoFaultKind, VPath};

use crate::port_drive::drive_port;

use crate::record::Record;
use crate::store::{StorageError, StorageErrorKind};

/// Where the schema marker lives, independent of every other record path.
pub const SCHEMA_SUFFIX: &str = "schema/storage.rec";

/// What a start-up check found on disk.
#[derive(Clone, Debug, Eq, PartialEq)]
pub enum SchemaVerdict {
    /// No marker at all: a brand new (or pre-versioning) directory.
    Absent,
    /// Marker matches this build.
    Current,
    /// Older than this build; `found` is what was on disk.
    Older { found: u32 },
    /// Newer than this build. Always fatal: see the module docs.
    Newer { found: u32 },
    /// Marker exists but cannot be read.
    Corrupt { reason: String },
}

impl SchemaVerdict {
    pub fn is_fatal(&self) -> bool {
        matches!(self, Self::Newer { .. } | Self::Corrupt { .. })
    }

    pub fn needs_migration(&self) -> bool {
        matches!(self, Self::Older { .. })
    }

    /// `found` version, if any was read.
    pub fn found_version(&self) -> Option<u32> {
        match self {
            Self::Absent | Self::Current | Self::Corrupt { .. } => None,
            Self::Older { found } | Self::Newer { found } => Some(*found),
        }
    }
}

/// Compare what was on disk with what this build expects.
///
/// `found == None` means the marker was absent; `Some(Err(..))` means it existed but could not be
/// parsed, which is *not* the same as absent and must never be treated as a fresh directory.
pub fn classify(found: Option<Result<u32, String>>, expected: u32) -> SchemaVerdict {
    match found {
        None => SchemaVerdict::Absent,
        Some(Err(reason)) => SchemaVerdict::Corrupt { reason },
        Some(Ok(version)) if version == expected => SchemaVerdict::Current,
        Some(Ok(version)) if version < expected => SchemaVerdict::Older { found: version },
        Some(Ok(version)) => SchemaVerdict::Newer { found: version },
    }
}

/// The marker record itself.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct SchemaMarker {
    pub storage_schema: u32,
    pub written_by: Option<String>,
    pub created_at_unix_ms: i64,
    /// How many migrations ran to bring this directory up to date.
    pub migrations_applied: u32,
}

impl SchemaMarker {
    /// The version this directory is at, ignoring every other field.
    pub fn storage_schema(&self) -> u32 {
        self.storage_schema
    }

    pub fn new(storage_schema: u32, now_unix_ms: i64) -> Self {
        Self {
            storage_schema,
            written_by: None,
            created_at_unix_ms: now_unix_ms,
            migrations_applied: 0,
        }
    }

    pub fn encode(&self) -> String {
        let mut record = Record::new(crate::record::RECORD_TAG_V1);
        record.set("storage_schema", self.storage_schema.to_string());
        record.set_opt("written_by", self.written_by.as_deref());
        record.set("created_at", self.created_at_unix_ms.to_string());
        record.set("migrations_applied", self.migrations_applied.to_string());
        record.encode()
    }

    pub fn decode(raw: &str) -> Result<Self, String> {
        let record = Record::decode(raw).map_err(|error| error.summary)?;
        crate::record::reject_unknown_fields(&record, "schema").map_err(|e| e.summary)?;
        Ok(Self {
            storage_schema: record
                .u64_field("storage_schema")
                .map_err(|error| error.summary)? as u32,
            written_by: record.opt("written_by").map(str::to_owned),
            created_at_unix_ms: record
                .i64_field("created_at")
                .map_err(|error| error.summary)?,
            migrations_applied: record
                .u64_field("migrations_applied")
                .map_err(|error| error.summary)? as u32,
        })
    }
}

/// A single stepwise schema migration.
///
/// Hooks are one-version steps (`from -> from + 1`) so the chain can be validated for contiguity:
/// a build that claims it can jump v1 -> v3 in one step is a build that will silently skip v2's
/// invariants.
pub trait MigrationHook: Send + Sync {
    /// The version this hook requires the store to be at.
    fn source_version(&self) -> u32;
    /// The version the store is at once this hook has run.
    fn target_version(&self) -> u32;
    /// Human-readable intent, surfaced in logs and in the refusal message.
    fn description(&self) -> String;

    /// Rewrite the on-disk layout. The hook sees the raw port and the store root: it is the only
    /// place allowed to touch files outside the documented record shapes.
    fn apply(&self, fs: &dyn Fs, root: &str, ctx: &IoContext) -> Result<(), String>;
}

/// An ordered set of available hooks.
#[derive(Default)]
pub struct MigrationChain {
    hooks: Vec<Box<dyn MigrationHook>>,
}

impl MigrationChain {
    pub fn empty() -> Self {
        Self::default()
    }

    pub fn with(mut self, hook: impl MigrationHook + 'static) -> Self {
        self.hooks.push(Box::new(hook));
        self
    }

    pub fn len(&self) -> usize {
        self.hooks.len()
    }

    pub fn is_empty(&self) -> bool {
        self.hooks.is_empty()
    }

    /// Plan a contiguous `from -> to` path, or explain why there is none.
    ///
    /// Indices are into `Self::hooks`, so the caller can run them without re-resolving.
    pub fn plan(&self, from: u32, to: u32) -> Result<Vec<usize>, String> {
        if from >= to {
            return Err(format!(
                "migration must move forward: found v{from}, this build is v{to}"
            ));
        }
        let mut path = Vec::new();
        let mut current = from;
        while current < to {
            let next = current + 1;
            let Some(index) = self
                .hooks
                .iter()
                .position(|hook| hook.source_version() == current && hook.target_version() == next)
            else {
                return Err(format!(
                    "no migration step v{current} -> v{next}; refusing to skip versions"
                ));
            };
            path.push(index);
            current = next;
        }
        Ok(path)
    }

    fn describe(&self, path: &[usize]) -> String {
        path.iter()
            .map(|index| self.hooks[*index].description())
            .collect::<Vec<_>>()
            .join(" ; ")
    }
}

/// A rollback point copies small records only; a runaway one is reported instead of copied
/// without bound. The bound is per file, so a store with many large records costs many stats but
/// never an unbounded copy.
const MAX_ROLLBACK_FILE_BYTES: u64 = 1 << 20;

/// The directories a rollback point copies, in addition to the schema marker.
///
/// These used to be the index files (`manifest/<kind>.idx`), which is what `ADR-035` deleted. Copying
/// an index would preserve a *description* of the store instead of the store, and after step 2 there
/// would be nothing to copy at all. Object content stays out on purpose: it is immutable and
/// content-addressed, so a copy would double the size of the directory to preserve bytes that no
/// migration in this design rewrites -- what an operator needs after a failed migration is the answer
/// to "what did the store claim?", which is the records.
const ROLLBACK_DIRECTORIES: &[&str] = &[
    "meta/objects",
    "records/revision",
    "records/snapshot",
    "records/os-journal",
    "records/apply-journal",
];

/// `§12.2.2`: create a rollback point *before* migrating.
///
/// The port has no directory copy, so the point is a copy of the schema marker plus every record,
/// under `backups/<version>/`. That is enough to answer "what did the store claim before?" after the
/// fact, which is what an operator needs when a migration goes wrong; the records themselves are never
/// rewritten by a migration in this design, only re-described.
///
/// Enumeration comes from `Fs::list` (`ADR-035 §2.3`), which is what makes this possible at all: an
/// implementation that could not list a directory could only have copied a list somebody maintained.
pub fn create_rollback_point(
    fs: &dyn Fs,
    root: &str,
    from_version: u32,
    ctx: &IoContext,
) -> Result<String, StorageError> {
    let tag = format!("backups/v{from_version}");
    let mut copied = 0usize;
    let mut sources: Vec<String> = vec![SCHEMA_SUFFIX.to_owned()];
    for dir in ROLLBACK_DIRECTORIES {
        for suffix in crate::fs_store::list_directory(
            fs,
            root,
            ctx,
            None,
            dir,
            caly_io::ListCap(crate::fs_store::MAX_ENTRIES_PER_DIRECTORY),
        )? {
            let name = suffix.rsplit('/').next().unwrap_or(&suffix);
            // A temp file is not part of what the store ever claimed, and `link_or_copy` would copy
            // a half-written one under a name the backup layout does not explain.
            if crate::fs_store::is_record_name(name) {
                sources.push(suffix);
            }
        }
    }
    for suffix in &sources {
        let source = VPath::try_from_str(&format!("{root}/{suffix}"))
            .map_err(|error| StorageError::new(StorageErrorKind::Internal, error.message))?;
        let destination =
            VPath::try_from_str(&format!("{root}/{tag}/{}", suffix.replace('/', "_")))
                .map_err(|error| StorageError::new(StorageErrorKind::Internal, error.message))?;
        // Gate-time work is store-originated (`ADR-039 §2.4`): it runs before the store exists to
        // hold a clock, so it is driven without one -- a deadline nobody stated is not judged.
        let meta = drive_port(fs.stat(&source, ctx), ctx, None)?.map_err(|fault| {
            StorageError::new(
                StorageErrorKind::Internal,
                format!("stat {suffix}: {}", fault.summary),
            )
        })?;
        let Some(meta) = meta else { continue };
        if meta.len > MAX_ROLLBACK_FILE_BYTES {
            return Err(StorageError::new(
                StorageErrorKind::CapacityExceeded,
                format!(
                    "{suffix} is {} bytes, too large for a rollback copy",
                    meta.len
                ),
            ));
        }
        drive_port(fs.link_or_copy(&source, &destination, ctx), ctx, None)?.map_err(|fault| {
            StorageError::new(
                StorageErrorKind::Internal,
                format!("rollback copy of {suffix}: {}", fault.summary),
            )
        })?;
        copied += 1;
    }
    if copied == 0 {
        return Err(StorageError::new(
            StorageErrorKind::NotFound,
            "no schema marker existed to copy, so no rollback point could be created",
        ));
    }
    Ok(format!("{tag} ({} file(s))", copied))
}

/// Read the marker, if any.
///
/// Three distinct outcomes, and they must stay distinct: `None` (absent), `Some(Ok)` (parsed),
/// `Some(Err)` (present but unreadable). Treating the third as the first would let a damaged
/// directory be initialised as fresh and quietly lose everything in it.
pub fn read_marker(
    fs: &dyn Fs,
    root: &str,
    ctx: &IoContext,
) -> Result<Option<Result<SchemaMarker, String>>, StorageError> {
    let path = VPath::try_from_str(&format!("{root}/{SCHEMA_SUFFIX}"))
        .map_err(|error| StorageError::new(StorageErrorKind::Internal, error.message))?;
    let bytes = drive_port(fs.read(&path, ByteCap(1 << 16), ctx), ctx, None)?;
    match bytes {
        Err(fault) if fault.kind == IoFaultKind::NotFound => Ok(None),
        Err(fault) => Err(StorageError::new(
            StorageErrorKind::Internal,
            format!("cannot read the schema marker: {}", fault.summary),
        )),
        Ok(bytes) => Ok(Some(match String::from_utf8(bytes) {
            Err(_) => Err("schema marker is not valid utf-8".to_owned()),
            Ok(text) => SchemaMarker::decode(&text),
        })),
    }
}

/// Write the marker. Always after the layout is known-good, so a crash mid-migration leaves the
/// old version recorded (and therefore still detected) rather than a matching-but-wrong one.
pub fn write_marker(
    fs: &dyn Fs,
    root: &str,
    ctx: &IoContext,
    marker: &SchemaMarker,
) -> Result<(), StorageError> {
    let path = VPath::try_from_str(&format!("{root}/{SCHEMA_SUFFIX}"))
        .map_err(|error| StorageError::new(StorageErrorKind::Internal, error.message))?;
    drive_port(
        fs.write_atomic(&path, marker.encode().into_bytes(), Durability::D3, ctx),
        ctx,
        None,
    )?
    .map_err(|fault| {
        StorageError::new(
            StorageErrorKind::Internal,
            format!("cannot record the schema marker: {}", fault.summary),
        )
    })
}

/// Why a store refused to open on schema grounds.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct SchemaRefusal {
    pub summary: String,
    /// Set when a migration existed but failed, so a caller can tell "no path" from
    /// "path failed partway".
    pub failed_migration: Option<String>,
    /// The rollback point created before that failed migration, if one was made.
    pub rollback_point: Option<String>,
}

impl SchemaRefusal {
    fn new(summary: impl Into<String>) -> Self {
        Self {
            summary: summary.into(),
            failed_migration: None,
            rollback_point: None,
        }
    }
}

/// The startup gate: read, classify, refuse the unrecoverable cases, migrate the recoverable ones.
pub fn gate(
    fs: &dyn Fs,
    root: &str,
    ctx: &IoContext,
    expected: u32,
    chain: &MigrationChain,
    assume_fresh: bool,
) -> Result<SchemaMarker, SchemaRefusal> {
    let found = read_marker(fs, root, ctx).map_err(|error| SchemaRefusal::new(error.summary))?;

    // A directory that predates versioning is the ambiguous case. `§12.3` forbids assuming it is
    // current, so it is accepted only when it holds nothing at all.
    if found.is_none() && !assume_fresh && has_any(fs, root, ctx) {
        return Err(SchemaRefusal::new(format!(
            "the store holds data but no {SCHEMA_SUFFIX} marker; refusing to read an unknown \
             layout as v{expected}"
        )));
    }

    let version = found.as_ref().map(|marker| {
        marker
            .as_ref()
            .map(SchemaMarker::storage_schema)
            .map_err(Clone::clone)
    });
    let verdict = classify(version, expected);

    match (&verdict, found) {
        (SchemaVerdict::Absent, _) => {
            let marker = SchemaMarker::new(expected, 0);
            write_marker(fs, root, ctx, &marker)
                .map_err(|error| SchemaRefusal::new(error.summary))?;
            Ok(marker)
        }
        // Never rewritten: opening a store is a read. Re-writing here would reset
        // `migrations_applied` and destroy the very history an operator needs after a restart.
        (SchemaVerdict::Current, Some(Ok(marker))) => Ok(marker),
        (SchemaVerdict::Current, _) => Ok(SchemaMarker::new(expected, 0)),
        (SchemaVerdict::Corrupt { reason }, _) => Err(SchemaRefusal::new(format!(
            "schema marker is unreadable ({reason}); refusing to start rather than guess a layout"
        ))),
        (SchemaVerdict::Newer { found }, _) => Err(SchemaRefusal::new(format!(
            "store is schema v{found}, this build understands v{expected}; `§12.3` forbids reading \
             a newer layout as a current one"
        ))),
        (SchemaVerdict::Older { found }, Some(Ok(previous))) => {
            let path = chain.plan(*found, expected).map_err(SchemaRefusal::new)?;
            let planned = chain.describe(&path);

            let rollback = create_rollback_point(fs, root, *found, ctx)
                .map_err(|error| SchemaRefusal::new(error.summary))?;

            let mut applied = 0u32;
            for index in path {
                let hook = &chain.hooks[index];
                if let Err(detail) = hook.apply(fs, root, ctx) {
                    let mut refusal = SchemaRefusal::new(format!(
                        "migration v{} -> v{} failed; the store is left untouched and startup is \
                         refused (`§12.2.3`)",
                        hook.source_version(),
                        hook.target_version()
                    ));
                    refusal.failed_migration = Some(format!("{detail} :: {planned}"));
                    refusal.rollback_point = Some(rollback);
                    return Err(refusal);
                }
                applied += 1;
            }

            let marker = SchemaMarker {
                storage_schema: expected,
                written_by: Some(format!("migrated from v{found}")),
                created_at_unix_ms: previous.created_at_unix_ms,
                migrations_applied: previous.migrations_applied.saturating_add(applied),
            };
            write_marker(fs, root, ctx, &marker).map_err(|error| {
                let mut refusal = SchemaRefusal::new(format!(
                    "migrations ran but the new schema version could not be recorded: {}",
                    error.summary
                ));
                refusal.rollback_point = Some(rollback.clone());
                refusal
            })?;
            Ok(marker)
        }
        (SchemaVerdict::Older { .. }, _) => Err(SchemaRefusal::new(
            "the store is older than this build but its marker could not be read",
        )),
    }
}

/// Whether an unversioned directory holds anything a store could have written.
///
/// This used to be a probe of five known index names, because a port without `readdir` could not ask
/// the question at all -- so a directory holding a record that no index named looked empty and was
/// initialised as new. Enumerating the layout's own directories is both weaker to fool and stronger
/// in what it accepts: a stray file the layout does not explain no longer makes a directory look
/// occupied (`list_records` refuses it one step later, when there is a caller to tell), and anything
/// the store cannot enumerate counts as data, because guessing "fresh" is how a directory's contents
/// are quietly discarded.
fn has_any(fs: &dyn Fs, root: &str, ctx: &IoContext) -> bool {
    for dir in ROLLBACK_DIRECTORIES {
        match crate::fs_store::list_directory(
            fs,
            root,
            ctx,
            None,
            dir,
            caly_io::ListCap(crate::fs_store::MAX_ENTRIES_PER_DIRECTORY),
        ) {
            Ok(entries) => {
                if entries
                    .iter()
                    .map(|suffix| suffix.rsplit('/').next().unwrap_or(suffix.as_str()))
                    .any(crate::fs_store::is_record_name)
                {
                    return true;
                }
            }
            Err(_) => return true,
        }
    }
    false
}
