use std::collections::BTreeMap;
use std::sync::{Arc, Mutex};

use crate::cas::{CasObjectRef, CasWriteIntent, MaterializationRequest};
use crate::execution::{ApplyJournalRecord, ApplyTxnId};
use crate::journal::{JournalRecord, JournalRecordId, JournalState};
use crate::revision::{RevisionId, RevisionRecord};
use crate::snapshot::{SnapshotRecord, SnapshotRecordId};
use caly_io::IoContext;

use crate::store::{
    ApplyJournalStore, BoxFuture, JournalStore, ObjectStore, RevisionStore, SnapshotStore,
    StorageBackend, StorageError, StorageErrorKind,
};

/// What `InMemoryStorage` kept for one digest, for tests that must assert on real content.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct StoredObject {
    pub meta: CasObjectRef,
    pub payload: Vec<u8>,
}

#[derive(Clone, Default)]
pub struct InMemoryStorage {
    objects: Arc<Mutex<BTreeMap<String, CasObjectRef>>>,
    /// Content of objects written with a payload, keyed by **content anchor** (`sha256:<hex>`) --
    /// the same key the durable backend's content tree uses (`RFC-0007 §6.1`). Kept separate so
    /// `get` still returns metadata. Keying by anchor rather than by object digest is what makes
    /// the shared-content rules one rule: two objects with one payload share one entry, and a
    /// deletion drops content only when the *last* referencing record is gone -- the semantics
    /// `FsStore::delete` already had. (Until the content sweep landed, the two backends keyed
    /// content differently and nothing could tell: no code path asked "what content exists?"
    /// across both.)
    contents: Arc<Mutex<BTreeMap<String, Vec<u8>>>>,
    revisions: Arc<Mutex<BTreeMap<String, RevisionRecord>>>,
    snapshots: Arc<Mutex<BTreeMap<String, SnapshotRecord>>>,
    journals: Arc<Mutex<BTreeMap<String, JournalRecord>>>,
    apply_journals: Arc<Mutex<BTreeMap<String, ApplyJournalRecord>>>,
}

impl InMemoryStorage {
    pub fn new() -> Self {
        Self::default()
    }

    /// Everything the store kept for `digest`, for assertions about real content.
    pub fn stored(&self, digest: &str) -> Option<StoredObject> {
        let meta = self.objects.lock().ok()?.get(digest).cloned()?;
        let anchor = meta.content_sha256.as_ref()?;
        let payload = self.contents.lock().ok()?.get(anchor).cloned()?;
        Some(StoredObject { meta, payload })
    }

    /// Content with no metadata naming it, placed directly -- for tests and recovery drills.
    ///
    /// This backend's own writes cannot leave that state behind on purpose: `put` stores content
    /// and metadata under locks a test cannot interrupt, and `delete` removes both halves
    /// together. The durable backend reaches the same state by crashing between the two halves
    /// (see `store.rs::delete_content`), which is precisely the state the orphan sweep exists to
    /// find -- so the drill needs a way to place it. Same standing as [`Self::stored`]: a
    /// test-facing accessor with one job.
    pub fn keep_orphan_content(&self, anchor: &str, payload: &[u8]) {
        if let Ok(mut guard) = self.contents.lock() {
            guard.insert(anchor.to_owned(), payload.to_vec());
        }
    }

    pub fn object_digests(&self) -> Vec<String> {
        self.objects
            .lock()
            .map(|guard| guard.keys().cloned().collect())
            .unwrap_or_default()
    }
}

impl ObjectStore for InMemoryStorage {
    fn put<'a>(
        &'a self,
        intent: CasWriteIntent,
        ctx: &'a IoContext,
    ) -> BoxFuture<'a, Result<CasObjectRef, StorageError>> {
        let objects = Arc::clone(&self.objects);
        let contents = Arc::clone(&self.contents);
        Box::pin(async move {
            // The same budget door the durable backend's port applies (`ADR-039 §2` step 2), stated
            // here because this backend makes no port calls: a payload that does not fit the
            // caller's stated budget is refused before anything is stored, and what does fit is
            // charged to the caller's meter. One rule, two backends -- `caly_io::budget` is the
            // single place it is written.
            caly_io::budget::admit_bytes(ctx, &intent.source_label, intent.payload.len() as u64)
                .map_err(|fault| {
                    StorageError::new(StorageErrorKind::CapacityExceeded, fault.summary)
                })?;
            caly_io::budget::charge(ctx, intent.payload.len() as u64);
            let mut object = intent.object.clone();
            object.stored_at_unix_ms = Some(intent.stored_at_unix_ms);
            if !intent.payload.is_empty() {
                // The store, not the caller, decides the integrity anchor — and a *declared* anchor
                // that does not match is refused rather than quietly overwritten. `FsStore` already
                // refused; accepting it here meant the same lying writer produced an error on one
                // backend and a silent rewrite on the other (`docs/ONBOARDING_NOTES.md §4.46`).
                let anchor = caly_common::digest::sha256_digest(&intent.payload);
                if let Some(claimed) = &object.content_sha256 {
                    if claimed != &anchor {
                        return Err(StorageError::new(
                            StorageErrorKind::IntegrityViolation,
                            format!(
                                "declared content digest {claimed} does not match the payload ({anchor})"
                            ),
                        ));
                    }
                }
                object.content_sha256 = Some(anchor.clone());
                object.size_bytes = Some(intent.payload.len() as u64);
                // Keyed by the anchor, like the durable backend's content tree: two objects with
                // one payload share one entry, and `delete` drops it only with the last reference.
                contents
                    .lock()
                    .map_err(|_| {
                        StorageError::new(
                            StorageErrorKind::Internal,
                            "object content lock poisoned",
                        )
                    })?
                    .insert(anchor, intent.payload.clone());
            }
            objects
                .lock()
                .map_err(|_| {
                    StorageError::new(StorageErrorKind::Internal, "object store lock poisoned")
                })?
                .insert(object.digest.0.clone(), object.clone());
            Ok(object)
        })
    }

    fn get<'a>(
        &'a self,
        digest: &'a str,
        _ctx: &'a IoContext,
    ) -> BoxFuture<'a, Result<Option<CasObjectRef>, StorageError>> {
        let objects = Arc::clone(&self.objects);
        let digest = digest.to_owned();
        Box::pin(async move {
            let guard = objects.lock().map_err(|_| {
                StorageError::new(StorageErrorKind::Internal, "object store lock poisoned")
            })?;
            Ok(guard.get(&digest).cloned())
        })
    }

    fn materialize<'a>(
        &'a self,
        request: MaterializationRequest,
        _ctx: &'a IoContext,
    ) -> BoxFuture<'a, Result<(), StorageError>> {
        let objects = Arc::clone(&self.objects);
        let contents = Arc::clone(&self.contents);
        Box::pin(async move {
            let meta = objects
                .lock()
                .map_err(|_| {
                    StorageError::new(StorageErrorKind::Internal, "object store lock poisoned")
                })?
                .get(&request.object.digest.0)
                .cloned();
            let Some(meta) = meta else {
                return Err(StorageError::new(
                    StorageErrorKind::NotFound,
                    format!("object {} not found", request.object.digest.0),
                ));
            };
            let Some(anchor) = meta.content_sha256.clone() else {
                // A metadata-only record has no bytes to place, so "materialized successfully" would
                // be a lie. `§6.3` refuses rather than tolerates, and `FsStore` answers the same way
                // for the same input — which `tests/object_contract.rs` now pins for both backends
                // (this used to diverge: in-memory said `Ok(())`, see `docs/ONBOARDING_NOTES.md §4.45`).
                return Err(StorageError::new(
                    StorageErrorKind::IntegrityViolation,
                    format!(
                        "object {} was recorded without content, so it cannot be materialized",
                        request.object.digest.0
                    ),
                ));
            };
            let payload = contents
                .lock()
                .map_err(|_| {
                    StorageError::new(StorageErrorKind::Internal, "object content lock poisoned")
                })?
                .get(&anchor)
                .cloned()
                .ok_or_else(|| {
                    StorageError::new(
                        StorageErrorKind::IntegrityViolation,
                        format!(
                            "object {} has metadata but no content",
                            request.object.digest.0
                        ),
                    )
                })?;
            if !caly_common::digest::sha256_matches(&anchor, &payload) {
                return Err(StorageError::new(
                    StorageErrorKind::IntegrityViolation,
                    format!(
                        "object {} failed integrity verification",
                        request.object.digest.0
                    ),
                ));
            }
            Ok(())
        })
    }

    fn list_objects<'a>(
        &'a self,
        _ctx: &'a IoContext,
    ) -> BoxFuture<'a, Result<Vec<CasObjectRef>, StorageError>> {
        let objects = Arc::clone(&self.objects);
        Box::pin(async move {
            Ok(objects
                .lock()
                .map_err(|_| {
                    StorageError::new(StorageErrorKind::Internal, "object store lock poisoned")
                })?
                .values()
                .cloned()
                .collect())
        })
    }

    fn read_object<'a>(
        &'a self,
        digest: &'a str,
        max_bytes: u64,
        ctx: &'a IoContext,
    ) -> BoxFuture<'a, Result<Option<Vec<u8>>, StorageError>> {
        let objects = Arc::clone(&self.objects);
        let contents = Arc::clone(&self.contents);
        let digest = digest.to_owned();
        Box::pin(async move {
            // Same door, same words as the durable backend (`ADR-039 §2` step 2): the unit in
            // flight completes and charges; a spent budget refuses new units.
            caly_io::budget::admit_unit(ctx, &digest).map_err(|fault| {
                StorageError::new(StorageErrorKind::CapacityExceeded, fault.summary)
            })?;
            let meta = objects
                .lock()
                .map_err(|_| {
                    StorageError::new(StorageErrorKind::Internal, "object store lock poisoned")
                })?
                .get(&digest)
                .cloned();
            let Some(meta) = meta else {
                // `None` here means "this store has no such digest", the same answer `get` gives.
                return Ok(None);
            };
            let Some(anchor) = meta.content_sha256.clone() else {
                return Err(StorageError::new(
                    StorageErrorKind::NotFound,
                    format!("object {digest} was recorded without content, so there is nothing to read back"),
                ));
            };
            let payload = contents
                .lock()
                .map_err(|_| {
                    StorageError::new(StorageErrorKind::Internal, "object content lock poisoned")
                })?
                .get(&anchor)
                .cloned()
                .ok_or_else(|| {
                    StorageError::new(
                        StorageErrorKind::IntegrityViolation,
                        format!("object {digest} has metadata but no content"),
                    )
                })?;
            // Verified before returning, exactly as `materialize` does: a caller must not be handed
            // bytes that no longer match the anchor the index advertises.
            if !caly_common::digest::sha256_matches(&anchor, &payload) {
                return Err(StorageError::new(
                    StorageErrorKind::IntegrityViolation,
                    format!("object {digest} failed integrity verification on read"),
                ));
            }
            if payload.len() as u64 > max_bytes {
                return Err(StorageError::new(
                    StorageErrorKind::CapacityExceeded,
                    format!(
                        "object {digest} is {} bytes and the caller allowed {max_bytes}",
                        payload.len()
                    ),
                ));
            }
            // Charged at the exit, after verification and the caller's own cap: what the meter
            // records is what the caller actually received.
            caly_io::budget::charge(ctx, payload.len() as u64);
            Ok(Some(payload))
        })
    }

    fn delete<'a>(
        &'a self,
        digest: &'a str,
        _ctx: &'a IoContext,
    ) -> BoxFuture<'a, Result<bool, StorageError>> {
        let objects = Arc::clone(&self.objects);
        let contents = Arc::clone(&self.contents);
        let digest = digest.to_owned();
        Box::pin(async move {
            let mut objects = objects.lock().map_err(|_| {
                StorageError::new(StorageErrorKind::Internal, "object store lock poisoned")
            })?;
            // Unpublishing the metadata record is the deletion, exactly as `FsStore::delete`;
            // content keyed by anchor may be shared, so it goes only when the last referencing
            // record is gone. (Keyed by object digest this guard was impossible -- the two
            // backends answered "what does delete mean?" differently, and no test asked.)
            let removed = objects.remove(&digest);
            if let Some(record) = &removed {
                if let Some(anchor) = &record.content_sha256 {
                    let still_referenced = objects
                        .values()
                        .any(|object| object.content_sha256.as_deref() == Some(anchor.as_str()));
                    if !still_referenced {
                        if let Ok(mut guard) = contents.lock() {
                            guard.remove(anchor);
                        }
                    }
                }
            }
            Ok(removed.is_some())
        })
    }

    fn list_content<'a>(
        &'a self,
        ctx: &'a IoContext,
    ) -> BoxFuture<'a, Result<Vec<crate::gc::ContentEntry>, StorageError>> {
        let contents = Arc::clone(&self.contents);
        Box::pin(async move {
            // Same door as the fs walk's first spend (`ADR-039 §2.3`): a cancelled caller is
            // refused before the unit starts. The contract suite pins both backends to one answer.
            if ctx.cancel.is_cancelled() {
                return Err(StorageError::new(
                    StorageErrorKind::Cancelled,
                    "the caller cancelled before this content walk began",
                ));
            }
            // Referenced or not is the *plan's* question, answered from metadata the caller
            // already holds; this method reports what the tree holds, both halves included.
            let contents = contents.lock().map_err(|_| {
                StorageError::new(StorageErrorKind::Internal, "object content lock poisoned")
            })?;
            let entries = contents
                .keys()
                .map(|anchor| crate::gc::ContentEntry {
                    target: crate::gc::ContentTarget::Anchor(anchor.clone()),
                    // No clock in this backend, so no age evidence: an orphan here is
                    // forever-in-grace by the plan's rule, which is the safe direction.
                    modified_at_unix_ms: None,
                })
                .collect::<Vec<_>>();
            Ok(entries)
        })
    }

    fn delete_content<'a>(
        &'a self,
        target: &'a crate::gc::ContentTarget,
        ctx: &'a IoContext,
    ) -> BoxFuture<'a, Result<bool, StorageError>> {
        let objects = Arc::clone(&self.objects);
        let contents = Arc::clone(&self.contents);
        let target = target.clone();
        Box::pin(async move {
            // Same door as fs-store's, same reason (`ADR-039 §2.3`).
            if ctx.cancel.is_cancelled() {
                return Err(StorageError::new(
                    StorageErrorKind::Cancelled,
                    "the caller cancelled before this content deletion began",
                ));
            }
            let crate::gc::ContentTarget::Anchor(anchor) = &target else {
                // This backend never writes temp files, so there is no residue to remove;
                // "nothing was removed" is the honest answer rather than an error.
                return Ok(false);
            };
            let objects = objects.lock().map_err(|_| {
                StorageError::new(StorageErrorKind::Internal, "object store lock poisoned")
            })?;
            if objects
                .values()
                .any(|object| object.content_sha256.as_deref() == Some(anchor.as_str()))
            {
                return Err(StorageError::new(
                    StorageErrorKind::IntegrityViolation,
                    format!(
                        "content {anchor} is still referenced by an object record; \
                         delete the object, not the content"
                    ),
                ));
            }
            drop(objects);
            let mut contents = contents.lock().map_err(|_| {
                StorageError::new(StorageErrorKind::Internal, "object content lock poisoned")
            })?;
            Ok(contents.remove(anchor).is_some())
        })
    }
}

impl StorageBackend for InMemoryStorage {}

impl RevisionStore for InMemoryStorage {
    fn put_revision<'a>(
        &'a self,
        record: RevisionRecord,
        _ctx: &'a IoContext,
    ) -> BoxFuture<'a, Result<(), StorageError>> {
        let revisions = Arc::clone(&self.revisions);
        Box::pin(async move {
            let mut guard = revisions.lock().map_err(|_| {
                StorageError::new(StorageErrorKind::Internal, "revision store lock poisoned")
            })?;
            guard.insert(record.id.0.clone(), record);
            Ok(())
        })
    }

    fn get_revision<'a>(
        &'a self,
        revision_id: &'a RevisionId,
        _ctx: &'a IoContext,
    ) -> BoxFuture<'a, Result<Option<RevisionRecord>, StorageError>> {
        let revisions = Arc::clone(&self.revisions);
        let key = revision_id.0.clone();
        Box::pin(async move {
            let guard = revisions.lock().map_err(|_| {
                StorageError::new(StorageErrorKind::Internal, "revision store lock poisoned")
            })?;
            Ok(guard.get(&key).cloned())
        })
    }

    fn list_revisions<'a>(
        &'a self,
        _ctx: &'a IoContext,
    ) -> BoxFuture<'a, Result<Vec<RevisionRecord>, StorageError>> {
        let revisions = Arc::clone(&self.revisions);
        Box::pin(async move {
            let guard = revisions.lock().map_err(|_| {
                StorageError::new(StorageErrorKind::Internal, "revision store lock poisoned")
            })?;
            // For this backend the table *is* the entity, so reading it is not a second source of
            // truth -- unlike `FsStore`, where the cache is a copy of what a listing found.
            let mut values: Vec<RevisionRecord> = guard.values().cloned().collect();
            values.sort_by(|left, right| left.id.0.cmp(&right.id.0));
            Ok(values)
        })
    }
}

impl SnapshotStore for InMemoryStorage {
    fn put_snapshot<'a>(
        &'a self,
        record: SnapshotRecord,
        _ctx: &'a IoContext,
    ) -> BoxFuture<'a, Result<(), StorageError>> {
        let snapshots = Arc::clone(&self.snapshots);
        Box::pin(async move {
            let mut guard = snapshots.lock().map_err(|_| {
                StorageError::new(StorageErrorKind::Internal, "snapshot store lock poisoned")
            })?;
            guard.insert(record.id.0.clone(), record);
            Ok(())
        })
    }

    fn get_snapshot<'a>(
        &'a self,
        snapshot_id: &'a SnapshotRecordId,
        _ctx: &'a IoContext,
    ) -> BoxFuture<'a, Result<Option<SnapshotRecord>, StorageError>> {
        let snapshots = Arc::clone(&self.snapshots);
        let key = snapshot_id.0.clone();
        Box::pin(async move {
            let guard = snapshots.lock().map_err(|_| {
                StorageError::new(StorageErrorKind::Internal, "snapshot store lock poisoned")
            })?;
            Ok(guard.get(&key).cloned())
        })
    }

    fn latest_last_known_good<'a>(
        &'a self,
        _ctx: &'a IoContext,
    ) -> BoxFuture<'a, Result<Option<SnapshotRecord>, StorageError>> {
        let snapshots = Arc::clone(&self.snapshots);
        Box::pin(async move {
            let guard = snapshots.lock().map_err(|_| {
                StorageError::new(StorageErrorKind::Internal, "snapshot store lock poisoned")
            })?;
            let mut values: Vec<_> = guard
                .values()
                .filter(|it| it.is_last_known_good)
                .cloned()
                .collect();
            values.sort_by_key(|it| it.created_at_unix_ms);
            Ok(values.pop())
        })
    }

    fn list_snapshots<'a>(
        &'a self,
        _ctx: &'a IoContext,
    ) -> BoxFuture<'a, Result<Vec<SnapshotRecord>, StorageError>> {
        let snapshots = Arc::clone(&self.snapshots);
        Box::pin(async move {
            let mut values: Vec<SnapshotRecord> = snapshots
                .lock()
                .map_err(|_| {
                    StorageError::new(StorageErrorKind::Internal, "snapshot store lock poisoned")
                })?
                .values()
                .cloned()
                .collect();
            values.sort_by(|left, right| left.id.0.cmp(&right.id.0));
            Ok(values)
        })
    }
}

impl JournalStore for InMemoryStorage {
    fn put_journal<'a>(
        &'a self,
        record: JournalRecord,
        _ctx: &'a IoContext,
    ) -> BoxFuture<'a, Result<(), StorageError>> {
        let journals = Arc::clone(&self.journals);
        Box::pin(async move {
            let mut guard = journals.lock().map_err(|_| {
                StorageError::new(StorageErrorKind::Internal, "journal store lock poisoned")
            })?;
            guard.insert(record.id.0.clone(), record);
            Ok(())
        })
    }

    fn get_journal<'a>(
        &'a self,
        journal_id: &'a JournalRecordId,
        _ctx: &'a IoContext,
    ) -> BoxFuture<'a, Result<Option<JournalRecord>, StorageError>> {
        let journals = Arc::clone(&self.journals);
        let key = journal_id.0.clone();
        Box::pin(async move {
            let guard = journals.lock().map_err(|_| {
                StorageError::new(StorageErrorKind::Internal, "journal store lock poisoned")
            })?;
            Ok(guard.get(&key).cloned())
        })
    }

    fn list_pending<'a>(
        &'a self,
        _ctx: &'a IoContext,
    ) -> BoxFuture<'a, Result<Vec<JournalRecord>, StorageError>> {
        let journals = Arc::clone(&self.journals);
        Box::pin(async move {
            let guard = journals.lock().map_err(|_| {
                StorageError::new(StorageErrorKind::Internal, "journal store lock poisoned")
            })?;
            Ok(guard
                .values()
                .filter(|record| matches!(record.state, JournalState::Pending))
                .cloned()
                .collect())
        })
    }
}

impl ApplyJournalStore for InMemoryStorage {
    fn put_apply_journal<'a>(
        &'a self,
        record: ApplyJournalRecord,
        _ctx: &'a IoContext,
    ) -> BoxFuture<'a, Result<(), StorageError>> {
        let apply_journals = Arc::clone(&self.apply_journals);
        Box::pin(async move {
            let mut guard = apply_journals.lock().map_err(|_| {
                StorageError::new(
                    StorageErrorKind::Internal,
                    "apply journal store lock poisoned",
                )
            })?;
            guard.insert(record.apply_txn_id.0.clone(), record);
            Ok(())
        })
    }

    fn get_apply_journal<'a>(
        &'a self,
        apply_txn_id: &'a ApplyTxnId,
        _ctx: &'a IoContext,
    ) -> BoxFuture<'a, Result<Option<ApplyJournalRecord>, StorageError>> {
        let apply_journals = Arc::clone(&self.apply_journals);
        let key = apply_txn_id.0.clone();
        Box::pin(async move {
            let guard = apply_journals.lock().map_err(|_| {
                StorageError::new(
                    StorageErrorKind::Internal,
                    "apply journal store lock poisoned",
                )
            })?;
            Ok(guard.get(&key).cloned())
        })
    }

    fn list_pending_apply<'a>(
        &'a self,
        _ctx: &'a IoContext,
    ) -> BoxFuture<'a, Result<Vec<ApplyJournalRecord>, StorageError>> {
        let apply_journals = Arc::clone(&self.apply_journals);
        Box::pin(async move {
            let guard = apply_journals.lock().map_err(|_| {
                StorageError::new(
                    StorageErrorKind::Internal,
                    "apply journal store lock poisoned",
                )
            })?;
            Ok(guard
                .values()
                .filter(|record| {
                    matches!(record.state, crate::execution::ApplyJournalState::Pending)
                })
                .cloned()
                .collect())
        })
    }

    fn list_unresolved_apply<'a>(
        &'a self,
        _ctx: &'a IoContext,
    ) -> BoxFuture<'a, Result<Vec<ApplyJournalRecord>, StorageError>> {
        let apply_journals = Arc::clone(&self.apply_journals);
        Box::pin(async move {
            let guard = apply_journals.lock().map_err(|_| {
                StorageError::new(
                    StorageErrorKind::Internal,
                    "apply journal store lock poisoned",
                )
            })?;
            Ok(guard
                .values()
                .filter(|record| {
                    matches!(
                        record.state,
                        crate::execution::ApplyJournalState::Pending
                            | crate::execution::ApplyJournalState::RecoveryFailed
                    )
                })
                .cloned()
                .collect())
        })
    }

    fn list_apply_journals<'a>(
        &'a self,
        _ctx: &'a IoContext,
    ) -> BoxFuture<'a, Result<Vec<ApplyJournalRecord>, StorageError>> {
        let apply_journals = Arc::clone(&self.apply_journals);
        Box::pin(async move {
            let guard = apply_journals.lock().map_err(|_| {
                StorageError::new(
                    StorageErrorKind::Internal,
                    "apply journal store lock poisoned",
                )
            })?;
            Ok(guard.values().cloned().collect())
        })
    }
}
