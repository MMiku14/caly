//! The production layout migrations (`ADR-062`).
//!
//! ADR-061 §2.4 drew the line: record-ENVELOPE semantics evolve at read time, but
//! LAYOUT changes (directories moving) go through `caly-storage::schema`'s migration
//! chain with a rollback point. This module is the first real chain entry: v1 -> v2
//! shards every flat record directory into hash buckets, because a flat directory's
//! 4096-entry `list` cap is a boot-refusal cliff the write path can walk past blindly
//! (`STORAGE_SIZING_BASELINE.md` F1: ~2.7 days at the full source quota, and past it
//! even GC cannot run -- its candidate set needs the same listing).

use caly_io::{Durability, Fs, IoContext, ListCap, VPath};

use crate::fs_store::{is_record_name, record_shard, MAX_ENTRIES_PER_DIRECTORY};
use crate::port_drive::drive_port;
use crate::schema::{MigrationChain, MigrationHook};

/// Every directory that holds record files and was flat in v1 (`ADR-062 §2.1`).
const RECORD_DIRECTORIES: &[&str] = &[
    "meta/objects",
    "records/revision",
    "records/snapshot",
    "records/os-journal",
    "records/apply-journal",
    "records/source-index",
    "records/job-log",
];

/// Move every flat record file into the bucket its (already escaped) file name hashes
/// to.
///
/// The move is a pure `rename`: the bucket is derived from the file NAME alone
/// (`record_shard`), so no record is decoded and no digest grammar is assumed. A
/// per-file rename is atomic, which is what makes re-running the hook after a crash
/// safe: a file is at the old path or the new one, never both, and a missing source is
/// skipped rather than treated as damage.
///
/// An over-cap v1 directory refuses here (the flat `list` itself is `CapacityExceeded`
/// -- the port never truncates): the migration fails, the store is left untouched and
/// startup is refused (`RFC-0007 §12.2.3`). The recovery ORDER is the runbook's to
/// tell: shed records out of band first, then upgrade.
pub struct ShardRecordDirectories;

impl MigrationHook for ShardRecordDirectories {
    fn source_version(&self) -> u32 {
        1
    }
    fn target_version(&self) -> u32 {
        2
    }
    fn description(&self) -> String {
        "move flat record files into hash buckets (ADR-062)".to_owned()
    }
    fn apply(&self, fs: &dyn Fs, root: &str, ctx: &IoContext) -> Result<(), String> {
        for dir in RECORD_DIRECTORIES {
            // The store's own listing doctrine (`ADR-035 §6bis-bis`): a directory that
            // was never written is EMPTY, not a fault -- a v1 store with no revisions
            // must migrate just as cleanly as one with them. Gate-time work is
            // store-originated (`ADR-039 §2.4`) and runs before the store exists to hold
            // a clock -- driven without one, like every other schema-gate step.
            let suffixes = crate::fs_store::list_directory(
                fs,
                root,
                ctx,
                None,
                dir,
                ListCap(MAX_ENTRIES_PER_DIRECTORY),
            )
            .map_err(|error| format!("list {dir}: {}", error.summary))?;
            for suffix in suffixes {
                let name = suffix.rsplit('/').next().unwrap_or(&suffix).to_owned();
                // Write residue is not data and is not named the way a record is; it
                // stays for the boot-time reaper, which knows how to walk buckets too.
                if !is_record_name(&name) {
                    continue;
                }
                let from = VPath::try_from_str(&format!("{root}/{suffix}"))
                    .map_err(|error| format!("{suffix}: {}", error.message))?;
                // The bucket is hashed from the STEM, exactly like every write path
                // (`object_record_path` / `record_path`): hashing the name WITH its
                // extension would move every record into a bucket nothing would ever
                // look in -- which is precisely what the wrong-bucket judge is for.
                let stem = name
                    .strip_suffix(".obj")
                    .or_else(|| name.strip_suffix(".rec"))
                    .unwrap_or(&name);
                let shard = record_shard(stem);
                let destination = VPath::try_from_str(&format!("{root}/{dir}/{shard}/{name}"))
                    .map_err(|error| format!("{dir}/{name}: {}", error.message))?;
                drive_port(
                    fs.rename(&from, &destination, Durability::D2, ctx),
                    ctx,
                    None,
                )
                .map_err(|fault| fault.summary)?
                .map_err(|fault| {
                    format!("move {dir}/{name} into bucket {shard}: {}", fault.summary)
                })?;
            }
        }
        Ok(())
    }
}

/// The chain the production bootstrap opens with. Empty was the correct state while no
/// layout had ever changed (`ADR-061 §1`); v2 is the first entry.
pub fn production_migration_chain() -> MigrationChain {
    MigrationChain::empty().with(ShardRecordDirectories)
}
