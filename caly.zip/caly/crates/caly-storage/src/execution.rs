use crate::cas::{
    CasObjectRef, CasWriteIntent, MaterializationMode, MaterializationRequest, ObjectDigest,
    ObjectKind,
};
use crate::journal::JournalRecordId;
use crate::revision::{RevisionId, RevisionNumber, RevisionRecord};
use crate::snapshot::{SnapshotRecord, SnapshotRecordId};

#[derive(Clone, Debug, Eq, PartialEq, Ord, PartialOrd, Hash)]
pub struct ApplyTxnId(pub String);

#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub enum ApplyPhase {
    Prepare,
    Cutover,
    Finalize,
    Recovery,
}

#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub enum ApplyJournalState {
    Pending,
    Committed,
    Reverted,
    Abandoned,
    RecoveryFailed,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct ApplyJournalRecord {
    pub journal_id: JournalRecordId,
    pub apply_txn_id: ApplyTxnId,
    pub trace_id: String,
    pub job_id: Option<String>,
    pub profile_id: String,
    pub revision_id: RevisionId,
    pub semantic_digest: String,
    pub compiled_artifact_digest: String,
    pub core_identity: String,
    pub effect_plan_id: String,
    pub current_phase: ApplyPhase,
    pub current_step_index: usize,
    pub net_effect_started: bool,
    pub core_cutover_started: bool,
    pub previous_snapshot_id: Option<SnapshotRecordId>,
    pub created_at_unix_ms: i64,
    pub updated_at_unix_ms: i64,
    pub state: ApplyJournalState,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct SnapshotCandidate {
    pub snapshot_id: SnapshotRecordId,
    pub revision_id: RevisionId,
    pub revision_number: RevisionNumber,
    pub profile_id: String,
    pub semantic_digest: String,
    pub compiled_artifact_digest: String,
    pub core_binary_digest: String,
    pub core_identity: String,
    pub apply_plan_summary: String,
    pub selection_memory_digest: Option<String>,
    pub validation_summary: String,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub enum RecoveryDecision {
    TakeoverRunningInstance { snapshot_id: SnapshotRecordId },
    RollbackToLastKnownGood { snapshot_id: SnapshotRecordId },
    RevertOsEffectsOnly { journal_id: JournalRecordId },
    CleanupAbandonedRuntime { profile_id: String },
    EnterFailedState { reason: String },
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct ApplyStorageProjection {
    pub artifact_object: CasWriteIntent,
    pub materialization: MaterializationRequest,
    pub apply_journal: ApplyJournalRecord,
    pub snapshot_candidate: SnapshotCandidate,
    pub revision_record: RevisionRecord,
}

pub fn build_apply_storage_projection(
    input: ApplyStorageProjectionInput,
) -> ApplyStorageProjection {
    let artifact_object = CasObjectRef {
        digest: ObjectDigest(input.compiled_artifact_digest.clone()),
        kind: ObjectKind::CompiledArtifact,
        size_bytes: Some(input.artifact_size_bytes),
        content_type: Some(input.content_type.clone()),
        content_sha256: Some(caly_common::digest::sha256_digest(&input.artifact_bytes)),
        stored_at_unix_ms: Some(input.created_at_unix_ms),
    };
    let apply_journal = begin_apply_journal(BeginApplyJournal {
        journal_id: JournalRecordId(format!("journal:{}", input.apply_txn_id.0)),
        apply_txn_id: input.apply_txn_id.clone(),
        trace_id: input.trace_id.clone(),
        job_id: input.job_id.clone(),
        profile_id: input.profile_id.clone(),
        revision_id: input.revision_id.clone(),
        semantic_digest: input.semantic_digest.clone(),
        compiled_artifact_digest: input.compiled_artifact_digest.clone(),
        core_identity: input.core_identity.clone(),
        effect_plan_id: input.effect_plan_id.clone(),
        previous_snapshot_id: input.previous_snapshot_id.clone(),
        created_at_unix_ms: input.created_at_unix_ms,
    });
    let snapshot_candidate = SnapshotCandidate {
        snapshot_id: SnapshotRecordId(format!("snapshot:{}", input.revision_id.0)),
        revision_id: input.revision_id.clone(),
        revision_number: input.revision_number,
        profile_id: input.profile_id.clone(),
        semantic_digest: input.semantic_digest.clone(),
        compiled_artifact_digest: input.compiled_artifact_digest.clone(),
        core_binary_digest: input.core_binary_digest.clone(),
        core_identity: input.core_identity.clone(),
        apply_plan_summary: input.apply_plan_summary.clone(),
        selection_memory_digest: input.selection_memory_digest.clone(),
        validation_summary: input.validation_summary.clone(),
    };
    let revision_record =
        revision_record_from_candidate(&snapshot_candidate, input.created_at_unix_ms);

    ApplyStorageProjection {
        artifact_object: CasWriteIntent {
            object: artifact_object.clone(),
            source_label: input.artifact_file_name,
            payload: input.artifact_bytes,
            stored_at_unix_ms: input.created_at_unix_ms,
        },
        materialization: MaterializationRequest {
            object: artifact_object,
            runtime_path: input.runtime_path,
            mode: MaterializationMode::Copy,
        },
        apply_journal,
        snapshot_candidate,
        revision_record,
    }
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct ApplyStorageProjectionInput {
    pub apply_txn_id: ApplyTxnId,
    pub trace_id: String,
    pub job_id: Option<String>,
    pub profile_id: String,
    pub revision_id: RevisionId,
    pub revision_number: RevisionNumber,
    pub semantic_digest: String,
    pub compiled_artifact_digest: String,
    pub core_binary_digest: String,
    pub core_identity: String,
    pub effect_plan_id: String,
    pub apply_plan_summary: String,
    pub artifact_file_name: String,
    pub artifact_size_bytes: u64,
    /// The compiled bytes themselves. The store needs them to be a content store at all, and to
    /// compute the integrity digest it verifies on read.
    pub artifact_bytes: Vec<u8>,
    pub content_type: String,
    pub runtime_path: String,
    pub selection_memory_digest: Option<String>,
    pub validation_summary: String,
    pub previous_snapshot_id: Option<SnapshotRecordId>,
    pub created_at_unix_ms: i64,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct BeginApplyJournal {
    pub journal_id: JournalRecordId,
    pub apply_txn_id: ApplyTxnId,
    pub trace_id: String,
    pub job_id: Option<String>,
    pub profile_id: String,
    pub revision_id: RevisionId,
    pub semantic_digest: String,
    pub compiled_artifact_digest: String,
    pub core_identity: String,
    pub effect_plan_id: String,
    pub previous_snapshot_id: Option<SnapshotRecordId>,
    pub created_at_unix_ms: i64,
}

pub fn begin_apply_journal(input: BeginApplyJournal) -> ApplyJournalRecord {
    ApplyJournalRecord {
        journal_id: input.journal_id,
        apply_txn_id: input.apply_txn_id,
        trace_id: input.trace_id,
        job_id: input.job_id,
        profile_id: input.profile_id,
        revision_id: input.revision_id,
        semantic_digest: input.semantic_digest,
        compiled_artifact_digest: input.compiled_artifact_digest,
        core_identity: input.core_identity,
        effect_plan_id: input.effect_plan_id,
        current_phase: ApplyPhase::Prepare,
        current_step_index: 0,
        net_effect_started: false,
        core_cutover_started: false,
        previous_snapshot_id: input.previous_snapshot_id,
        created_at_unix_ms: input.created_at_unix_ms,
        updated_at_unix_ms: input.created_at_unix_ms,
        state: ApplyJournalState::Pending,
    }
}

pub fn advance_apply_journal_step(
    record: &ApplyJournalRecord,
    phase: ApplyPhase,
    step_index: usize,
    net_effect_started: bool,
    core_cutover_started: bool,
    updated_at_unix_ms: i64,
) -> ApplyJournalRecord {
    ApplyJournalRecord {
        current_phase: phase,
        current_step_index: step_index,
        net_effect_started,
        core_cutover_started,
        updated_at_unix_ms,
        ..record.clone()
    }
}

pub fn mark_apply_journal_state(
    record: &ApplyJournalRecord,
    state: ApplyJournalState,
    updated_at_unix_ms: i64,
) -> ApplyJournalRecord {
    ApplyJournalRecord {
        state,
        updated_at_unix_ms,
        ..record.clone()
    }
}

pub fn snapshot_record_from_candidate(
    candidate: &SnapshotCandidate,
    journal_id: Option<JournalRecordId>,
    created_at_unix_ms: i64,
    is_last_known_good: bool,
) -> SnapshotRecord {
    SnapshotRecord {
        id: candidate.snapshot_id.clone(),
        revision_id: candidate.revision_id.clone(),
        revision_number: candidate.revision_number,
        profile_id: candidate.profile_id.clone(),
        semantic_digest: candidate.semantic_digest.clone(),
        compiled_artifact_digest: candidate.compiled_artifact_digest.clone(),
        core_binary_digest: candidate.core_binary_digest.clone(),
        core_identity: candidate.core_identity.clone(),
        apply_plan_summary: candidate.apply_plan_summary.clone(),
        journal_id,
        selection_memory_digest: candidate.selection_memory_digest.clone(),
        validation_summary: candidate.validation_summary.clone(),
        created_at_unix_ms,
        is_last_known_good,
    }
}

pub fn revision_record_from_candidate(
    candidate: &SnapshotCandidate,
    created_at_unix_ms: i64,
) -> RevisionRecord {
    RevisionRecord {
        id: candidate.revision_id.clone(),
        number: candidate.revision_number,
        profile_id: candidate.profile_id.clone(),
        semantic_digest: candidate.semantic_digest.clone(),
        created_at_unix_ms,
    }
}

#[derive(Clone, Debug, Default, Eq, PartialEq)]
pub struct RecoveryScanReport {
    /// `Pending` or `RecoveryFailed` transactions. Named `unresolved_*` rather than
    /// `pending_*` because a recovery that failed is precisely what must NOT be dropped from
    /// the scan; the daemon DTO keeps its public `pending_apply_count` name for contract
    /// stability and is fed from this list.
    pub unresolved_apply_journals: Vec<ApplyJournalRecord>,
    pub pending_os_journals: Vec<JournalRecordId>,
    pub latest_last_known_good: Option<SnapshotRecordId>,
    pub decisions: Vec<RecoveryDecision>,
}

pub fn build_recovery_scan_report(
    unresolved_apply_journals: Vec<ApplyJournalRecord>,
    pending_os_journals: Vec<JournalRecordId>,
    latest_last_known_good: Option<SnapshotRecordId>,
) -> RecoveryScanReport {
    let mut decisions = Vec::new();
    for journal in &unresolved_apply_journals {
        if matches!(journal.state, ApplyJournalState::RecoveryFailed) {
            // Compensation already failed once. Re-running the rollback automatically is not
            // provably safe, so keep escalating instead of quietly resolving the record.
            decisions.push(RecoveryDecision::EnterFailedState {
                reason: format!(
                    "apply txn {} has an unresolved recovery failure at phase {:?} step {}",
                    journal.apply_txn_id.0, journal.current_phase, journal.current_step_index
                ),
            });
            continue;
        }
        if !journal.core_cutover_started {
            decisions.push(RecoveryDecision::CleanupAbandonedRuntime {
                profile_id: journal.profile_id.clone(),
            });
        } else if let Some(snapshot_id) = latest_last_known_good.clone() {
            decisions.push(RecoveryDecision::RollbackToLastKnownGood { snapshot_id });
        } else if journal.net_effect_started {
            decisions.push(RecoveryDecision::RevertOsEffectsOnly {
                journal_id: journal.journal_id.clone(),
            });
        } else {
            decisions.push(RecoveryDecision::EnterFailedState {
                reason: format!(
                    "apply txn {} cannot prove a safe recovery target",
                    journal.apply_txn_id.0
                ),
            });
        }
    }

    RecoveryScanReport {
        unresolved_apply_journals,
        pending_os_journals,
        latest_last_known_good,
        decisions,
    }
}
