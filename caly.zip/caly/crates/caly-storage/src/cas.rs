#[derive(Clone, Debug, Eq, PartialEq, Ord, PartialOrd, Hash)]
pub struct ObjectDigest(pub String);

#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub enum ObjectKind {
    RawSource,
    RuleSet,
    CompiledArtifact,
    StageOutput,
    SupportBundle,
}

#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub enum MaterializationMode {
    ReflinkPreferred,
    HardlinkPreferred,
    Copy,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct CasObjectRef {
    pub digest: ObjectDigest,
    pub kind: ObjectKind,
    pub size_bytes: Option<u64>,
    pub content_type: Option<String>,
    /// Content digest the *store* computed while writing, in `sha256:<hex>` form.
    ///
    /// `digest` above is the pipeline's object identity (today an adapter-prefixed checksum).
    /// It cannot double as the integrity anchor that `RFC-0007 §6.2-6.3` demands, because a
    /// 64-bit non-cryptographic checksum cannot detect truncation or corruption. The store
    /// therefore records its own digest and re-verifies it on read/materialize.
    pub content_sha256: Option<String>,
    /// When the store took the bytes, on the caller's injected timeline.
    ///
    /// `RFC-0007 §13.1` protects objects still inside a grace period, but there is no clock in
    /// this crate (wall-clock reads are banned outside the gateway), so the value is carried in
    /// by the writer. `None` means "age unknown", which `gc` treats as permanently in grace
    /// rather than as free to collect.
    pub stored_at_unix_ms: Option<i64>,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct CasWriteIntent {
    pub object: CasObjectRef,
    pub source_label: String,
    /// The bytes to store.
    ///
    /// This field did not exist: `ObjectStore::put` accepted only a `CasWriteIntent`, i.e.
    /// metadata about an object it never received. A "content addressed store" that is handed no
    /// content can only keep an index of digests, so `materialize` could not produce a real file
    /// and `RFC-0007 §6.4` ("得到可供目标消费者使用的工件副本") was unachievable at any backend.
    /// See `docs/history/ONBOARDING_NOTES.md §4.14`.
    pub payload: Vec<u8>,
    /// Write timestamp on the caller's injected clock. `0` is a legal, reproducible value.
    pub stored_at_unix_ms: i64,
}

impl CasWriteIntent {
    /// Metadata-only intent, for callers that genuinely have nothing to store yet.
    pub fn metadata(object: CasObjectRef, source_label: impl Into<String>) -> Self {
        Self {
            object,
            source_label: source_label.into(),
            payload: Vec::new(),
            stored_at_unix_ms: 0,
        }
    }

    pub fn with_payload(mut self, payload: Vec<u8>) -> Self {
        self.payload = payload;
        self
    }
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct MaterializationRequest {
    pub object: CasObjectRef,
    pub runtime_path: String,
    pub mode: MaterializationMode,
}
