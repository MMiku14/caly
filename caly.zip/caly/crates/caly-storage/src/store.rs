use std::future::Future;
use std::pin::Pin;

use caly_io::IoContext;

use crate::cas::{CasObjectRef, CasWriteIntent, MaterializationRequest};
use crate::execution::{ApplyJournalRecord, ApplyTxnId};
use crate::gc::{ContentEntry, ContentTarget};
use crate::job_log::JobLogRecord;
use crate::journal::{JournalRecord, JournalRecordId};
use crate::revision::{RevisionId, RevisionRecord};
use crate::snapshot::{SnapshotRecord, SnapshotRecordId};
use crate::source::SourceIndexRecord;

pub type BoxFuture<'a, T> = Pin<Box<dyn Future<Output = T> + Send + 'a>>;

#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub enum StorageErrorKind {
    NotFound,
    AlreadyExists,
    Busy,
    Timeout,
    CapacityExceeded,
    IntegrityViolation,
    SchemaMismatch,
    MigrationFailed,
    /// The caller withdrew the call (`ADR-039 §2.3`). Distinct from `Timeout` and from every
    /// "tried and failed" kind: nothing went wrong, the work was simply cancelled -- and the
    /// distinction is the caller's to report, not the store's to flatten.
    Cancelled,
    /// The backend cannot do this at all - as distinct from "tried and failed". Used by the
    /// optional introspection hooks below so a caller never mistakes "unsupported" for "empty".
    Unsupported,
    Internal,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct StorageError {
    pub kind: StorageErrorKind,
    pub summary: String,
}

impl StorageError {
    pub fn new(kind: StorageErrorKind, summary: impl Into<String>) -> Self {
        Self {
            kind,
            summary: summary.into(),
        }
    }
}

pub trait ObjectStore: Send + Sync + 'static {
    fn put<'a>(
        &'a self,
        intent: CasWriteIntent,
        ctx: &'a IoContext,
    ) -> BoxFuture<'a, Result<CasObjectRef, StorageError>>;
    fn get<'a>(
        &'a self,
        digest: &'a str,
        ctx: &'a IoContext,
    ) -> BoxFuture<'a, Result<Option<CasObjectRef>, StorageError>>;
    fn materialize<'a>(
        &'a self,
        request: MaterializationRequest,
        ctx: &'a IoContext,
    ) -> BoxFuture<'a, Result<(), StorageError>>;

    /// Every object the store holds.
    ///
    /// `ObjectStore` previously exposed only `put` / `get` / `materialize`: there was no way to
    /// enumerate what exists, and no way to remove anything. That made `RFC-0007 §13` (GC)
    /// unimplementable at any backend — a collector cannot even produce a candidate set.
    /// See `docs/ONBOARDING_NOTES.md §4.18`.
    fn list_objects<'a>(
        &'a self,
        ctx: &'a IoContext,
    ) -> BoxFuture<'a, Result<Vec<CasObjectRef>, StorageError>>;

    /// Drop an object (and its content). Returns whether anything was removed.
    ///
    /// Deliberately policy-free: deciding *what* may be deleted is `gc`'s job, so a caller that
    /// deletes without consulting the root set gets no help from the store.
    fn delete<'a>(
        &'a self,
        digest: &'a str,
        ctx: &'a IoContext,
    ) -> BoxFuture<'a, Result<bool, StorageError>>;

    /// Read an object's bytes back, verifying them against the recorded anchor first.
    ///
    /// The store had `put` / `get` (metadata) / `materialize` (to a runtime path) / `list` / `delete`,
    /// and therefore **no way to obtain content** — `materialize` answers "where a core would read it",
    /// which is not a question a diagnostics consumer asks. It made `RFC-0010 §12.2`'s support bundle
    /// a write-only artifact: the bytes were stored and digested, and no client could read them back
    /// (`docs/ONBOARDING_NOTES.md §4.45`).
    ///
    /// `max_bytes` is a hard bound, honoured in the spirit of `RFC-0007 §6.5` (objects must not be
    /// slurped without a limit): exceeding it is `CapacityExceeded`, not a silent truncation. The
    /// caller that *wants* a prefix asks for one explicitly (see `caly-api`'s read request) rather
    /// than mistaking a partial object for the whole thing.
    ///
    /// The default is `Unsupported`, not an empty read: a backend that cannot hand out content must
    /// not be able to look like a backend whose objects happen to be empty.
    fn read_object<'a>(
        &'a self,
        _digest: &'a str,
        _max_bytes: u64,
        _ctx: &'a IoContext,
    ) -> BoxFuture<'a, Result<Option<Vec<u8>>, StorageError>> {
        Box::pin(async move {
            Err(StorageError::new(
                StorageErrorKind::Unsupported,
                "this backend cannot read object content back",
            ))
        })
    }

    /// Every file the content tree holds, anchors and write residue alike (`RFC-0007 §6.1`).
    ///
    /// The metadata-keyed surface above cannot see these files: the delete path removes metadata
    /// first and content second, so a crash between the two leaves content no record names, and
    /// `list_objects` -- which enumerates metadata -- answers as if the bytes were gone while the
    /// disk keeps them. Until this method existed the store had no way to report that gap at all
    /// (`IMPLEMENTATION_STATUS §7` item 10; the content tree sits three levels deep and the port
    /// guarantees one-level listing, so the walk is the backend's to implement).
    ///
    /// The default is `Unsupported`, not an empty walk: a backend that cannot see its own content
    /// tree must not be able to look like a backend whose tree happens to be empty.
    fn list_content<'a>(
        &'a self,
        _ctx: &'a IoContext,
    ) -> BoxFuture<'a, Result<Vec<ContentEntry>, StorageError>> {
        Box::pin(async move {
            Err(StorageError::new(
                StorageErrorKind::Unsupported,
                "this backend cannot enumerate the content tree",
            ))
        })
    }

    /// Drop one unreferenced file from the content tree. Returns whether anything was removed.
    ///
    /// Two rules, both load-bearing:
    ///
    /// * the target is typed ([`ContentTarget`]), never a raw path -- the store rebuilds the
    ///   suffix itself, so a caller cannot aim a deletion outside the two shapes this layout
    ///   explains;
    /// * an anchor that live metadata still references is **refused** (`IntegrityViolation`), not
    ///   silently skipped. This is the sweep's second chance: the plan checked references before
    ///   the sweep ran, and this check is what covers the window between plan and delete. The
    ///   reference check reads this process's records, exactly like `delete`'s shared-content
    ///   check -- cross-process callers remain the engine's problem (idle gate), not the store's.
    ///
    /// Deliberately policy-free, like `delete`: grace, roots and budgets live in `gc`.
    fn delete_content<'a>(
        &'a self,
        _target: &'a ContentTarget,
        _ctx: &'a IoContext,
    ) -> BoxFuture<'a, Result<bool, StorageError>> {
        Box::pin(async move {
            Err(StorageError::new(
                StorageErrorKind::Unsupported,
                "this backend cannot delete from the content tree",
            ))
        })
    }
}

pub trait RevisionStore: Send + Sync + 'static {
    fn put_revision<'a>(
        &'a self,
        record: RevisionRecord,
        ctx: &'a IoContext,
    ) -> BoxFuture<'a, Result<(), StorageError>>;
    fn get_revision<'a>(
        &'a self,
        revision_id: &'a RevisionId,
        ctx: &'a IoContext,
    ) -> BoxFuture<'a, Result<Option<RevisionRecord>, StorageError>>;

    /// Every registered revision.
    ///
    /// `RFC-0007 §13.1` lists 已登记 Revision as a GC root: an object a revision names must survive
    /// collection even when no snapshot points at it yet. That root was **unassemblable** -- there was
    /// no way to ask which revisions exist, and `ADR-038 §1` found the gap while wiring the collector's
    /// plan (`docs/ONBOARDING_NOTES.md §4.73`). The default answers `Unsupported`, not an empty list:
    /// a caller that cannot see the registered set must refuse to collect, and an empty list would
    /// have made "no revisions" look like permission to delete what they reference.
    fn list_revisions<'a>(
        &'a self,
        _ctx: &'a IoContext,
    ) -> BoxFuture<'a, Result<Vec<RevisionRecord>, StorageError>> {
        Box::pin(async move {
            Err(StorageError::new(
                StorageErrorKind::Unsupported,
                "this backend cannot enumerate registered revisions",
            ))
        })
    }
}

pub trait SnapshotStore: Send + Sync + 'static {
    fn put_snapshot<'a>(
        &'a self,
        record: SnapshotRecord,
        ctx: &'a IoContext,
    ) -> BoxFuture<'a, Result<(), StorageError>>;
    fn get_snapshot<'a>(
        &'a self,
        snapshot_id: &'a SnapshotRecordId,
        ctx: &'a IoContext,
    ) -> BoxFuture<'a, Result<Option<SnapshotRecord>, StorageError>>;
    fn latest_last_known_good<'a>(
        &'a self,
        ctx: &'a IoContext,
    ) -> BoxFuture<'a, Result<Option<SnapshotRecord>, StorageError>>;

    /// Every snapshot the store holds, not only the current one.
    ///
    /// GC needs the retained set to know what a rollback target still reads (`§7.2`: a superseded
    /// snapshot survives until it is explicitly forgotten), and the audit needs it to tell
    /// "no snapshots" apart from "cannot look". The default answers `Unsupported`, not an empty
    /// list, so an unimplemented backend cannot be misread as an empty store.
    fn list_snapshots<'a>(
        &'a self,
        _ctx: &'a IoContext,
    ) -> BoxFuture<'a, Result<Vec<SnapshotRecord>, StorageError>> {
        Box::pin(async move {
            Err(StorageError::new(
                StorageErrorKind::Unsupported,
                "this backend cannot enumerate snapshots",
            ))
        })
    }
}

pub trait JournalStore: Send + Sync + 'static {
    fn put_journal<'a>(
        &'a self,
        record: JournalRecord,
        ctx: &'a IoContext,
    ) -> BoxFuture<'a, Result<(), StorageError>>;
    fn get_journal<'a>(
        &'a self,
        journal_id: &'a JournalRecordId,
        ctx: &'a IoContext,
    ) -> BoxFuture<'a, Result<Option<JournalRecord>, StorageError>>;
    fn list_pending<'a>(
        &'a self,
        ctx: &'a IoContext,
    ) -> BoxFuture<'a, Result<Vec<JournalRecord>, StorageError>>;
}

pub trait ApplyJournalStore: Send + Sync + 'static {
    fn put_apply_journal<'a>(
        &'a self,
        record: ApplyJournalRecord,
        ctx: &'a IoContext,
    ) -> BoxFuture<'a, Result<(), StorageError>>;
    fn get_apply_journal<'a>(
        &'a self,
        apply_txn_id: &'a ApplyTxnId,
        ctx: &'a IoContext,
    ) -> BoxFuture<'a, Result<Option<ApplyJournalRecord>, StorageError>>;
    fn list_pending_apply<'a>(
        &'a self,
        ctx: &'a IoContext,
    ) -> BoxFuture<'a, Result<Vec<ApplyJournalRecord>, StorageError>>;

    /// Journals that still need attention: `Pending` (crashed mid-apply) *or*
    /// `RecoveryFailed` (compensation also failed).
    ///
    /// Listing only `Pending` silently hid the worst case: an apply whose rollback failed is
    /// exactly the transaction a boot-time scan must keep reporting until an operator resolves
    /// it (`docs/STORAGE_RECOVERY_EXECUTION_PLAN.md §6.2` case B, `§9.2`).
    fn list_unresolved_apply<'a>(
        &'a self,
        ctx: &'a IoContext,
    ) -> BoxFuture<'a, Result<Vec<ApplyJournalRecord>, StorageError>>;

    /// Every apply journal the store holds, committed or not.
    ///
    /// The support bundle has to answer "what did this deployment actually do last time", and a
    /// committed transaction is precisely what `list_pending_apply` /
    /// `list_unresolved_apply` leave out. Enumerate-what-exists is again the missing primitive
    /// (`docs/ONBOARDING_NOTES.md §4.18`); the default answers `Unsupported` rather than empty, so
    /// a backend that cannot list is reported as such instead of looking like a store with no
    /// history.
    fn list_apply_journals<'a>(
        &'a self,
        _ctx: &'a IoContext,
    ) -> BoxFuture<'a, Result<Vec<ApplyJournalRecord>, StorageError>> {
        Box::pin(async move {
            Err(StorageError::new(
                StorageErrorKind::Unsupported,
                "this backend cannot enumerate apply journals",
            ))
        })
    }
}

/// Durable deployment-job logs (`ADR-057`).
///
/// A job log record is the terminal, retained snapshot of one deployment job — its identity,
/// terminal state, stable failure code, counters, and the retained event lines. It is written once
/// at the job's terminal commit point (D3) so that after a daemon restart `jobs.list` /
/// `jobs.events` / `jobs.follow` / follow-resume still answer for a past job instead of the
/// in-memory-only `no such job` refusal (`JOB_FLOW_SCENARIO_REVIEW` measured the gap).
///
/// Like the other newer surfaces, the methods are sealed behind an explicit `Unsupported` default:
/// a backend that cannot persist job logs must say so, never look like an empty history.
pub trait JobLogStore: Send + Sync + 'static {
    /// Publish one terminal job record. Re-putting the same `job_id` overwrites atomically (the
    /// terminal record is the last word for that job).
    fn put_job_log<'a>(
        &'a self,
        _record: JobLogRecord,
        _ctx: &'a IoContext,
    ) -> BoxFuture<'a, Result<(), StorageError>> {
        Box::pin(async move {
            Err(StorageError::new(
                StorageErrorKind::Unsupported,
                "this backend cannot persist job log records",
            ))
        })
    }

    /// Read one terminal job record by id.
    fn get_job_log<'a>(
        &'a self,
        _job_id: &'a str,
        _ctx: &'a IoContext,
    ) -> BoxFuture<'a, Result<Option<JobLogRecord>, StorageError>> {
        Box::pin(async move {
            Err(StorageError::new(
                StorageErrorKind::Unsupported,
                "this backend cannot read job log records",
            ))
        })
    }

    /// Enumerate the retained terminal job records, newest first by `job_id` (ids are minted
    /// monotonically, so highest id first is most-recent-first). The engine writes one record at
    /// the terminal commit point and prunes the oldest past the retention window via
    /// [`delete_job_log`](Self::delete_job_log), so the set stays bounded; the caller still caps
    /// the page it reads back.
    fn list_job_logs<'a>(
        &'a self,
        _ctx: &'a IoContext,
    ) -> BoxFuture<'a, Result<Vec<JobLogRecord>, StorageError>> {
        Box::pin(async move {
            Err(StorageError::new(
                StorageErrorKind::Unsupported,
                "this backend cannot enumerate job log records",
            ))
        })
    }

    /// Delete one terminal job record by id, returning whether a record was present (`ADR-057`
    /// §4: the job log is bounded and reclaimed with the same lifecycle as other terminal
    /// records). Deleting a job log never touches a committed snapshot or revision; a job that
    /// the retained set still names must not be offered here.
    fn delete_job_log<'a>(
        &'a self,
        _job_id: &'a str,
        _ctx: &'a IoContext,
    ) -> BoxFuture<'a, Result<bool, StorageError>> {
        Box::pin(async move {
            Err(StorageError::new(
                StorageErrorKind::Unsupported,
                "this backend cannot delete job log records",
            ))
        })
    }
}

/// The full backend surface the control plane needs, as a single object-safe supertrait.
///
/// This exists so that a backend can be passed as `Arc<dyn StorageBackend>`. Before it, the
/// engine hardcoded `InMemoryStorage` (so the five store traits below were decorative), while
/// `caly-engine::coordinator` carried a second, unused copy of the same supertrait list.
/// One definition, in the crate that owns the traits, is what makes "pluggable storage"
/// something the code can actually demonstrate instead of something the docs claim.
pub trait StorageBackend:
    ObjectStore
    + RevisionStore
    + SnapshotStore
    + JournalStore
    + ApplyJournalStore
    + JobLogStore
    + Send
    + Sync
    + 'static
{
    /// Atomically publish one source endpoint/validator/raw/cache/provenance record. The storage
    /// envelope is owned here; typed cache fields stay opaque to this crate. Backends that have not
    /// implemented this newer surface must refuse explicitly instead of looking like an empty index.
    fn put_source_index<'a>(
        &'a self,
        _record: SourceIndexRecord,
        _ctx: &'a IoContext,
    ) -> BoxFuture<'a, Result<(), StorageError>> {
        Box::pin(async move {
            Err(StorageError::new(
                StorageErrorKind::Unsupported,
                "this backend cannot persist source index records",
            ))
        })
    }

    /// Read one durable source record by source id.
    fn get_source_index<'a>(
        &'a self,
        _source_id: &'a str,
        _ctx: &'a IoContext,
    ) -> BoxFuture<'a, Result<Option<SourceIndexRecord>, StorageError>> {
        Box::pin(async move {
            Err(StorageError::new(
                StorageErrorKind::Unsupported,
                "this backend cannot read source index records",
            ))
        })
    }

    /// Enumerate the durable source records. `Unsupported` is not an empty list: without this
    /// answer the worker cannot know whether a conditional request has a body to reuse.
    fn list_source_indexes<'a>(
        &'a self,
        _ctx: &'a IoContext,
    ) -> BoxFuture<'a, Result<Vec<SourceIndexRecord>, StorageError>> {
        Box::pin(async move {
            Err(StorageError::new(
                StorageErrorKind::Unsupported,
                "this backend cannot enumerate source index records",
            ))
        })
    }

    /// Remove one source index record while leaving its raw CAS object for the next GC cycle.
    /// Locator changes use this seam so a stale durable validator can never be restored after a
    /// process restart. The default is explicit `Unsupported`, not a best-effort in-memory delete.
    fn delete_source_index<'a>(
        &'a self,
        _source_id: &'a str,
        _ctx: &'a IoContext,
    ) -> BoxFuture<'a, Result<bool, StorageError>> {
        Box::pin(async move {
            Err(StorageError::new(
                StorageErrorKind::Unsupported,
                "this backend cannot delete source index records",
            ))
        })
    }

    // Everything below is *optional* introspection for diagnostics (`§9.2`). The defaults answer
    // "unknown", never "fine": a backend that cannot look must not be reported as healthy.

    /// The schema version recorded on disk, and how many migrations produced it.
    fn schema_state(&self) -> crate::audit::Observation<u32> {
        crate::audit::Observation::unavailable("this backend does not record a storage schema")
    }

    fn migrations_applied(&self) -> u32 {
        0
    }

    /// Rollback points that exist, by the version each was taken before.
    fn rollback_points(&self) -> crate::audit::Observation<Vec<u32>> {
        crate::audit::Observation::unavailable("this backend has no rollback points")
    }

    /// Whether the materialized runtime candidate for `object_digest` still exists.
    fn materialization_state(&self, _object_digest: &str) -> crate::audit::Observation<bool> {
        crate::audit::Observation::unavailable(
            "this backend does not track materialized runtime candidates",
        )
    }
}

// Implemented per backend rather than by a blanket `impl<T: ..5 traits> StorageBackend for T`.
// A blanket impl would be convenient, but it makes the introspection defaults below
// non-overridable (Rust has no specialization): every backend would report "unknown schema",
// "no rollback points" and "no materialization tracking", including the one durable backend that
// knows all three. Explicit opt-in is the price of a backend being able to say more.
//
// The cost: a new backend must write `impl StorageBackend for X {}` by hand. That is also a
// feature - it is the line where a type declares it is a complete, substitutable backend.
