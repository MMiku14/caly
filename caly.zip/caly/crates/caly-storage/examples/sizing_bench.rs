//! Storage sizing bench (`PLATFORM_FACE_PLAN §2.5`) — the TIMING half of the sizing round.
//!
//! Why an example and not a `#[test]`: the R128 doctrine is "counts gate, timing reports"
//! (`tests/perf_regression.rs`): a shared 2-CPU sandbox makes wall-clock numbers flaky, so
//! the GATE pins scaling by port-call counts (deterministic at any clock speed) and this
//! tool produces the REPORT numbers — run on demand, recorded once in
//! `docs/engineering/STORAGE_SIZING_BASELINE.md`, never asserted in CI.
//!
//! ```sh
//! cargo run -p caly-storage --example sizing_bench --release
//! ```
//!
//! What it measures, on a REAL disk (`StdFs`, fresh temp dir per rung, warm page cache):
//! * **build** — N `put`s of deterministic content (the write path: D2 write + read-back
//!   verify + hash + record write, per object);
//! * **reopen** — `FsStore::open` over the finished directory: the crash-recovery sweep,
//!   which re-reads and re-hashes EVERY content anchor (`load`), i.e. O(total bytes) per
//!   boot — the number a daemon pays at every restart;
//! * **list** — `list_objects` (one `list` + one `stat_many` batch, `ADR-054 §2.3`);
//! * **plan** — `plan_object_gc` full sweep over the N objects (pure compute, no IO).
//!
//! Two ladders separate the two candidate bottlenecks: the COUNT ladder (growing N at
//! fixed 4 KiB payloads) walks toward the 4096 single-directory entry cap; the BYTES
//! ladder (fixed N=128, growing payload) shows reopen cost is driven by bytes, not count.
//! Each rung also reports the deterministic SimFs twin's port-call count, so the report
//! pairs every wall-clock number with a machine-independent one.
//!
//! The tool self-checks loudly (reopen must succeed below the cap, list must return N, the
//! full-sweep plan must collect N) and ends at the cliff rung — 4097 objects — where the
//! reopen must REFUSE: that refusal is pinned as behaviour by
//! `an_object_directory_past_the_entry_cap_refuses_the_next_reopen_naming_the_bound`.

// The clock doctrine disallows `Instant::now` in production code (time is a port,
// `caly_io::Clock`) — and this tool exists to measure wall-clock time from the OUTSIDE,
// exactly like the e2e test files that carry the same file-level allow. The store under
// measurement still gets its clock injected; no timing reaches store internals.
#![allow(clippy::disallowed_methods)]

use std::io::Write as _;
use std::sync::atomic::{AtomicUsize, Ordering};
use std::sync::Arc;
use std::time::Instant;

use caly_io::{block_on_ready, BoxFuture, ByteCap, Fs, IoContext, ListCap, Meta, VPath};
use caly_io_sim::{MemFs, SharedFaults, SimFs};
use caly_io_std::{StdClock, StdFs};
use caly_storage::cas::{CasObjectRef, CasWriteIntent, ObjectDigest, ObjectKind};
use caly_storage::gc::{plan_object_gc, GcPolicy, GcRootSet};
use caly_storage::{FsStore, ObjectStore, MAX_ENTRIES_PER_DIRECTORY};

const ROOT: &str = "var/caly";

fn ctx() -> IoContext {
    IoContext::new(
        caly_io::TraceId::new("sizing-bench"),
        caly_io::Actor::System,
    )
}

/// Deterministic, distinct-per-seed payload: a tiny xorshift stream, so every run of this
/// tool writes byte-identical fixtures (same digest set, same de-dup behaviour) and the
/// report's run-to-run deltas are the STORE's, not the fixture's.
fn payload(seed: u64, len: usize) -> Vec<u8> {
    let mut state = seed.wrapping_mul(0x9E37_79B9_7F4A_7C15).max(1);
    let mut bytes = Vec::with_capacity(len);
    while bytes.len() < len {
        state ^= state << 13;
        state ^= state >> 7;
        state ^= state << 17;
        bytes.extend_from_slice(&state.to_le_bytes());
    }
    bytes.truncate(len);
    bytes
}

fn intent(index: usize, bytes: &[u8]) -> CasWriteIntent {
    CasWriteIntent {
        object: CasObjectRef {
            digest: ObjectDigest(format!("obj:sizing-{index:06}")),
            kind: ObjectKind::RawSource,
            size_bytes: None,
            content_type: None,
            content_sha256: None,
            stored_at_unix_ms: Some(1_000_000),
        },
        source_label: format!("sizing-{index:06}.txt"),
        payload: bytes.to_vec(),
        stored_at_unix_ms: 1_000_000,
    }
}

fn write_objects(store: &FsStore, count: usize, object_bytes: usize) {
    for index in 0..count {
        let bytes = payload(index as u64, object_bytes);
        let admitted = block_on_ready(store.put(intent(index, &bytes), &ctx()))
            .expect("no suspension")
            .expect("write");
        assert!(admitted.content_sha256.is_some());
    }
}

/// The R128 counting wrapper, minimal for the report: one total.
struct CountingFs {
    inner: SimFs,
    total: Arc<AtomicUsize>,
}

impl Fs for CountingFs {
    fn read<'a>(
        &'a self,
        path: &'a VPath,
        cap: ByteCap,
        ctx: &'a IoContext,
    ) -> BoxFuture<'a, Result<caly_io::Bytes, caly_io::IoFault>> {
        self.total.fetch_add(1, Ordering::Relaxed);
        self.inner.read(path, cap, ctx)
    }
    fn write_atomic<'a>(
        &'a self,
        path: &'a VPath,
        bytes: Vec<u8>,
        durability: caly_io::Durability,
        ctx: &'a IoContext,
    ) -> BoxFuture<'a, Result<(), caly_io::IoFault>> {
        self.total.fetch_add(1, Ordering::Relaxed);
        self.inner.write_atomic(path, bytes, durability, ctx)
    }
    fn stat<'a>(
        &'a self,
        path: &'a VPath,
        ctx: &'a IoContext,
    ) -> BoxFuture<'a, Result<Option<Meta>, caly_io::IoFault>> {
        self.total.fetch_add(1, Ordering::Relaxed);
        self.inner.stat(path, ctx)
    }
    fn stat_many<'a>(
        &'a self,
        paths: &'a [VPath],
        ctx: &'a IoContext,
    ) -> BoxFuture<'a, Result<Vec<Option<Meta>>, caly_io::IoFault>> {
        self.total.fetch_add(1, Ordering::Relaxed);
        self.inner.stat_many(paths, ctx)
    }
    fn list<'a>(
        &'a self,
        dir: &'a VPath,
        cap: ListCap,
        ctx: &'a IoContext,
    ) -> BoxFuture<'a, Result<Vec<VPath>, caly_io::IoFault>> {
        self.total.fetch_add(1, Ordering::Relaxed);
        self.inner.list(dir, cap, ctx)
    }
    fn open_stream<'a>(
        &'a self,
        path: &'a VPath,
        ctx: &'a IoContext,
    ) -> BoxFuture<'a, Result<caly_io::ByteStream, caly_io::IoFault>> {
        self.total.fetch_add(1, Ordering::Relaxed);
        self.inner.open_stream(path, ctx)
    }
    fn rename<'a>(
        &'a self,
        from: &'a VPath,
        to: &'a VPath,
        durability: caly_io::Durability,
        ctx: &'a IoContext,
    ) -> BoxFuture<'a, Result<(), caly_io::IoFault>> {
        self.total.fetch_add(1, Ordering::Relaxed);
        self.inner.rename(from, to, durability, ctx)
    }
    fn remove<'a>(
        &'a self,
        path: &'a VPath,
        ctx: &'a IoContext,
    ) -> BoxFuture<'a, Result<(), caly_io::IoFault>> {
        self.total.fetch_add(1, Ordering::Relaxed);
        self.inner.remove(path, ctx)
    }
    fn link_or_copy<'a>(
        &'a self,
        from: &'a VPath,
        to: &'a VPath,
        ctx: &'a IoContext,
    ) -> BoxFuture<'a, Result<caly_io::LinkKind, caly_io::IoFault>> {
        self.total.fetch_add(1, Ordering::Relaxed);
        self.inner.link_or_copy(from, to, ctx)
    }
    fn lock_exclusive<'a>(
        &'a self,
        path: &'a VPath,
        ctx: &'a IoContext,
    ) -> BoxFuture<'a, Result<caly_io::FileLock, caly_io::IoFault>> {
        self.total.fetch_add(1, Ordering::Relaxed);
        self.inner.lock_exclusive(path, ctx)
    }
}

/// One real-disk rung: build, reopen, list, plan — wall times plus the SimFs twin's
/// deterministic port-call count for the same fixture.
fn rung(label: &str, count: usize, object_bytes: usize) {
    let base =
        std::env::temp_dir().join(format!("caly-sizing-bench-{}-{label}", std::process::id()));
    let _ = std::fs::remove_dir_all(&base);
    std::fs::create_dir_all(&base).expect("scratch dir");

    let total_bytes = count as u64 * object_bytes as u64;
    let clock: Arc<dyn caly_io::Clock> = Arc::new(StdClock::new());

    // -- build (real disk, D2 durability: every write fsyncs file + parent) --
    let build_started = Instant::now();
    let store = FsStore::open(
        Box::new(StdFs::new(base.display().to_string())) as Box<dyn Fs>,
        ROOT,
    )
    .expect("open fresh store")
    .with_clock(clock.clone());
    write_objects(&store, count, object_bytes);
    let build_ms = build_started.elapsed().as_secs_f64() * 1e3;
    drop(store);

    // -- reopen: the crash-recovery sweep, re-hash of every content anchor --
    let reopen_started = Instant::now();
    let store = FsStore::open(
        Box::new(StdFs::new(base.display().to_string())) as Box<dyn Fs>,
        ROOT,
    )
    .expect("reopen finished store")
    .with_clock(clock.clone());
    let reopen_ms = reopen_started.elapsed().as_secs_f64() * 1e3;
    let reopen_mib_s = total_bytes as f64 / 1.048_576e6 / (reopen_ms / 1e3);

    // -- list (one list + one stat_many batch) --
    let list_started = Instant::now();
    let objects = block_on_ready(store.list_objects(&ctx()))
        .expect("no suspension")
        .expect("enumerate");
    let list_ms = list_started.elapsed().as_secs_f64() * 1e3;
    assert_eq!(objects.len(), count, "every written object is enumerated");

    // -- plan (pure compute: full sweep, nothing protected, nothing in grace) --
    let policy = GcPolicy {
        now_unix_ms: 10_000_000,
        max_deletions: count,
        ..GcPolicy::default()
    };
    let plan_started = Instant::now();
    let plan = plan_object_gc(&objects, &GcRootSet::default(), &policy);
    let plan_ms = plan_started.elapsed().as_secs_f64() * 1e3;
    assert_eq!(
        plan.collect.len(),
        count,
        "an unprotected, out-of-grace full sweep collects everything"
    );
    drop(store);
    let _ = std::fs::remove_dir_all(&base);

    // -- deterministic twin: the same fixture on SimFs, counted, no wall clock --
    let disk = SimFs::new(MemFs::default(), SharedFaults::default());
    let total = Arc::new(AtomicUsize::new(0));
    {
        let counted = CountingFs {
            inner: disk.clone(),
            total: Arc::clone(&total),
        };
        let store = FsStore::open(Box::new(counted) as Box<dyn Fs>, ROOT).expect("open sim");
        write_objects(&store, count, object_bytes);
    }
    let counted = CountingFs {
        inner: disk.clone(),
        total: Arc::clone(&total),
    };
    let _sim_store = FsStore::open(Box::new(counted) as Box<dyn Fs>, ROOT).expect("reopen sim");
    let calls = total.load(Ordering::Relaxed);

    println!(
        "{label:>10} | {count:>5} x {object_bytes:>6} B = {total_bytes:>9} B \
         | build {build_ms:>9.1} ms | reopen {reopen_ms:>8.1} ms ({reopen_mib_s:>6.1} MiB/s) \
         | list {list_ms:>7.1} ms | plan {plan_ms:>6.1} ms \
         | sim port calls {calls:>7} ({:>5.1}/obj)",
        calls as f64 / count as f64
    );
    let _ = std::io::stdout().flush();
}

/// The cliff rung since `ADR-062`: 4097 objects -- one past the OLD flat-directory cap
/// -- reopen FINE, because the growth is sharded. The bound is per bucket now (ceiling
/// ~256 x 4096 ~= 1.05M records per family); the inverted behaviour is pinned by
/// `tests/sharded_records.rs::forty_ninety_seven_objects_reopen_because_the_growth_is_sharded`.
fn cliff() {
    let disk = SimFs::new(MemFs::default(), SharedFaults::default());
    let started = Instant::now();
    {
        let store = FsStore::open(Box::new(disk.clone()) as Box<dyn Fs>, ROOT).expect("open sim");
        write_objects(&store, MAX_ENTRIES_PER_DIRECTORY as usize + 1, 64);
    }
    let store = FsStore::open(Box::new(disk) as Box<dyn Fs>, ROOT)
        .expect("one past the old flat cap reopens fine (ADR-062)");
    let objects = block_on_ready(store.list_objects(&ctx()))
        .expect("no suspension")
        .expect("enumerate");
    assert_eq!(objects.len(), MAX_ENTRIES_PER_DIRECTORY as usize + 1);
    println!(
        "     cliff  | {} x       64 B           | reopen OK in {:>6.1} ms — the flat-cap \
         boot refusal is retired (ADR-062); the bound is per bucket now",
        MAX_ENTRIES_PER_DIRECTORY + 1,
        started.elapsed().as_secs_f64() * 1e3
    );
}

fn main() {
    println!(
        "caly-storage sizing bench (PLATFORM_FACE_PLAN 2.5) — warm page cache, per-rung fresh dir"
    );
    println!(
        "count ladder (fixed 4 KiB objects, toward the {} entry cap):",
        MAX_ENTRIES_PER_DIRECTORY
    );
    rung("n64", 64, 4 * 1024);
    rung("n512", 512, 4 * 1024);
    rung("n2048", 2048, 4 * 1024);
    rung("n4096", 4096, 4 * 1024);
    println!(
        "bytes ladder (fixed 128 objects, growing payload — reopen is driven by bytes, not count):"
    );
    rung("b4k", 128, 4 * 1024);
    rung("b64k", 128, 64 * 1024);
    rung("b256k", 128, 256 * 1024);
    cliff();
    println!("done.");
}
