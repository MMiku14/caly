//! The durable backend: content addressing, integrity, and what survives a restart.
//!
//! `docs/engineering/STORAGE_RECOVERY_EXECUTION_PLAN.md §12` says storage stops being "a set of types
//! floating beside the centerline" only once it is the substrate apply and recovery actually read
//! and write. These tests use `caly-io-sim`'s `SimFs` as the disk, so the same assertions can be
//! re-run against `caly-io-std::StdFs` without redefining what "durable" means.

use caly_io::{block_on_ready, ByteCap, Durability, Fs, IoContext, ListCap, VPath};
use caly_io_sim::{FaultInjector, MemFs, SharedFaults, SimClock, SimFs, VirtualClock};
use caly_storage::cas::{
    CasObjectRef, CasWriteIntent, MaterializationMode, MaterializationRequest, ObjectDigest,
    ObjectKind,
};
use caly_storage::execution::{ApplyJournalRecord, ApplyJournalState, ApplyPhase, ApplyTxnId};
use caly_storage::fs_store::content_suffix_for;
use caly_storage::gc::{collect_gc_roots, plan_object_gc, GcGraph, GcPolicy};
use caly_storage::journal::JournalRecordId;
use caly_storage::record::encode_object;
use caly_storage::record::encode_snapshot;
use caly_storage::revision::{RevisionId, RevisionNumber};
use caly_storage::snapshot::{SnapshotRecord, SnapshotRecordId};
use caly_storage::{
    ApplyJournalStore, FsStore, ObjectStore, SnapshotStore, StorageError, StorageErrorKind,
};

const ROOT: &str = "var/caly";

fn disk() -> SimFs {
    SimFs::new(MemFs::default(), SharedFaults::new(FaultInjector::new(1)))
}

fn ctx() -> IoContext {
    IoContext::new(caly_io::TraceId::new("test"), caly_io::Actor::System)
}

/// Drive a store future. The store never suspends (see `caly_io::runtime`), so the only
/// interesting outcome is the `Result` it resolves to.
fn done<T>(future: caly_io::BoxFuture<'_, Result<T, StorageError>>) -> Result<T, StorageError> {
    block_on_ready(future).expect("a storage future must not suspend")
}

/// Drive a storage future and assert success.
fn ok<T: std::fmt::Debug>(future: caly_io::BoxFuture<'_, Result<T, StorageError>>) -> T {
    done(future).expect("storage call must succeed")
}

/// Same, for the raw `Fs` port calls the tests use to simulate disk damage.
fn io_ok<T: std::fmt::Debug>(result: Result<Result<T, caly_io::IoFault>, String>) -> T {
    result
        .expect("port future must not suspend")
        .expect("port call must succeed")
}

fn object(digest: &str) -> CasObjectRef {
    CasObjectRef {
        digest: ObjectDigest(digest.to_owned()),
        kind: ObjectKind::CompiledArtifact,
        size_bytes: None,
        content_type: Some("application/x-yaml".to_owned()),
        content_sha256: None,
        stored_at_unix_ms: None,
    }
}

fn write_object(store: &FsStore, digest: &str, payload: &[u8]) -> CasObjectRef {
    ok(store.put(
        CasWriteIntent {
            object: object(digest),
            source_label: format!("{digest}.yaml"),
            payload: payload.to_vec(),
            stored_at_unix_ms: 1_700_000_000_000,
        },
        &ctx(),
    ))
}

fn snapshot_record(id: &str) -> SnapshotRecord {
    SnapshotRecord {
        id: SnapshotRecordId(id.to_owned()),
        revision_id: RevisionId("rev:01".to_owned()),
        revision_number: RevisionNumber(1),
        profile_id: "demo-profile".to_owned(),
        semantic_digest: "sem:1".to_owned(),
        compiled_artifact_digest: "mihomo:ee55".to_owned(),
        core_binary_digest: "bin:1".to_owned(),
        core_identity: "mihomo@0.1".to_owned(),
        apply_plan_summary: "Restart".to_owned(),
        journal_id: None,
        selection_memory_digest: None,
        validation_summary: "ok".to_owned(),
        created_at_unix_ms: 100,
        is_last_known_good: true,
    }
}

fn pending_journal(txn: &str) -> ApplyJournalRecord {
    ApplyJournalRecord {
        journal_id: JournalRecordId(format!("journal:{txn}")),
        apply_txn_id: ApplyTxnId(txn.to_owned()),
        trace_id: "trace-crashed".to_owned(),
        job_id: None,
        profile_id: "demo-profile".to_owned(),
        revision_id: RevisionId("rev:01".to_owned()),
        semantic_digest: "sem:1".to_owned(),
        compiled_artifact_digest: "mihomo:ee55".to_owned(),
        core_identity: "mihomo@0.1".to_owned(),
        effect_plan_id: "plan-1".to_owned(),
        current_phase: ApplyPhase::Cutover,
        current_step_index: 3,
        net_effect_started: true,
        core_cutover_started: true,
        previous_snapshot_id: None,
        created_at_unix_ms: 50,
        updated_at_unix_ms: 60,
        state: ApplyJournalState::Pending,
    }
}

#[test]
fn store_round_trips_content_and_derives_the_integrity_anchor() {
    let store = FsStore::open(Box::new(disk()), ROOT).expect("open");
    let payload = b"proxy-groups:\nproxies:\n".to_vec();
    let written = write_object(&store, "mihomo:aa11", &payload);

    assert_eq!(written.kind, ObjectKind::CompiledArtifact);
    assert_eq!(written.size_bytes, Some(payload.len() as u64));
    assert_eq!(
        written.stored_at_unix_ms,
        Some(1_700_000_000_000),
        "the grace period in `gc` reads this field, so the store must keep it"
    );
    let anchor = written
        .content_sha256
        .clone()
        .expect("a payload write must record an integrity anchor");
    assert!(anchor.starts_with("sha256:"), "{anchor}");
    assert!(caly_common::digest::sha256_matches(&anchor, &payload));

    // Retrieval by digest must return the same metadata the write reported.
    let read_back = ok(store.get("mihomo:aa11", &ctx()));
    assert_eq!(read_back.as_ref(), Some(&written));
}

#[test]
fn materialize_lands_the_exact_bytes_at_the_runtime_path() {
    let fs = disk();
    let store = FsStore::open(Box::new(fs.clone()), ROOT).expect("open");
    let payload = b"final-config".to_vec();
    let written = write_object(&store, "mihomo:bb22", &payload);

    ok(store.materialize(
        MaterializationRequest {
            object: written,
            runtime_path: "runtime/demo/config.yaml".to_owned(),
            mode: MaterializationMode::Copy,
        },
        &ctx(),
    ));

    let destination = VPath::try_from_str("var/caly/runtime/demo/config.yaml").expect("path");
    let bytes = io_ok(block_on_ready(fs.read(&destination, ByteCap(1024), &ctx())));
    assert_eq!(
        bytes, payload,
        "the runtime must receive the bytes it was promised"
    );
}

/// The point of a content store: mismatched bytes are refused, never handed to the runtime
/// (`RFC-0007 §6.3`: 部分写、截断、损坏文件不得静默容忍).
#[test]
fn tampered_content_is_refused_with_an_integrity_violation() {
    let fs = disk();
    let store = FsStore::open(Box::new(fs.clone()), ROOT).expect("open");
    let written = write_object(&store, "mihomo:cc33", b"good-config");
    let anchor = written.content_sha256.clone().expect("anchor");
    let content_path =
        VPath::try_from_str(&format!("{ROOT}/{}", content_suffix_for(&anchor))).expect("path");

    io_ok(block_on_ready(fs.write_atomic(
        &content_path,
        b"truncated-by-filesystem-bug".to_vec(),
        Durability::D2,
        &ctx(),
    )));

    let error = done(store.materialize(
        MaterializationRequest {
            object: written,
            runtime_path: "runtime/demo/config.yaml".to_owned(),
            mode: MaterializationMode::Copy,
        },
        &ctx(),
    ))
    .expect_err("corrupted content must not be materialized");
    assert_eq!(error.kind, StorageErrorKind::IntegrityViolation);
    assert!(
        error.summary.contains("integrity verification"),
        "{}",
        error.summary
    );
}

#[test]
fn opening_over_tampered_content_fails_rather_than_skipping_it() {
    let fs = disk();
    {
        let store = FsStore::open(Box::new(fs.clone()), ROOT).expect("open");
        write_object(&store, "mihomo:dd44", b"payload-before-crash");
    }

    let anchor = caly_common::digest::sha256_digest(b"payload-before-crash");
    let content_path =
        VPath::try_from_str(&format!("{ROOT}/{}", content_suffix_for(&anchor))).expect("path");
    io_ok(block_on_ready(fs.write_atomic(
        &content_path,
        b"short".to_vec(),
        Durability::D2,
        &ctx(),
    )));

    let error = match FsStore::open(Box::new(fs), ROOT) {
        Ok(_) => panic!("open must surface the mismatch, not skip the damaged object"),
        Err(error) => error,
    };
    assert!(
        error.summary.contains("no longer matches"),
        "{}",
        error.summary
    );
}

#[test]
fn a_metadata_only_object_cannot_be_materialized() {
    let store = FsStore::open(Box::new(disk()), ROOT).expect("open");
    let recorded = ok(store.put(
        CasWriteIntent {
            object: object("external:schema-v1"),
            source_label: "external".to_owned(),
            payload: Vec::new(),
            stored_at_unix_ms: 0,
        },
        &ctx(),
    ));
    assert!(recorded.content_sha256.is_none());

    let error = done(store.materialize(
        MaterializationRequest {
            object: recorded,
            runtime_path: "runtime/demo/config.yaml".to_owned(),
            mode: MaterializationMode::Copy,
        },
        &ctx(),
    ))
    .expect_err("there is no content to hand to the runtime");
    assert_eq!(error.kind, StorageErrorKind::IntegrityViolation);
    assert!(
        error.summary.contains("without content"),
        "{}",
        error.summary
    );
}

/// The restart test: a brand new store over the same disk sees exactly what survived.
#[test]
fn a_restarted_store_sees_the_committed_snapshot_and_the_unfinished_journal() {
    let fs = disk();
    let snapshot_id = SnapshotRecordId("snapshot:rev:01".to_owned());
    let txn = "txn:crashed";

    {
        let store = FsStore::open(Box::new(fs.clone()), ROOT).expect("open");
        write_object(&store, "mihomo:ee55", b"committed-config");
        ok(store.put_snapshot(snapshot_record(&snapshot_id.0), &ctx()));
        ok(store.put_apply_journal(pending_journal(txn), &ctx()));
    }

    // Everything the previous process held in memory is gone; only the disk remains.
    let reopened = FsStore::open(Box::new(fs), ROOT).expect("restart must succeed");
    let lkg =
        ok(reopened.latest_last_known_good(&ctx())).expect("the committed snapshot must survive");
    assert_eq!(lkg.id, snapshot_id);
    assert!(lkg.is_last_known_good);
    assert_eq!(
        reopened
            .last_known_good_id(&ctx())
            .expect("pointer read")
            .as_deref(),
        Some(snapshot_id.0.as_str()),
        "the LKG marker must be a durable file, not process state"
    );

    let unresolved = ok(reopened.list_unresolved_apply(&ctx()));
    assert_eq!(
        unresolved.len(),
        1,
        "the unfinished transaction must reappear"
    );
    assert_eq!(unresolved[0].apply_txn_id.0, txn);
    assert_eq!(unresolved[0].current_step_index, 3);
    assert!(unresolved[0].core_cutover_started);
    assert_eq!(reopened.apply_journal_count(), 1);
    assert!(reopened
        .object_digests()
        .contains(&"mihomo:ee55".to_owned()));
}

#[test]
fn an_unresolved_recovery_stays_visible_after_restart() {
    let fs = disk();
    {
        let store = FsStore::open(Box::new(fs.clone()), ROOT).expect("open");
        let mut journal = pending_journal("txn:stuck");
        journal.state = ApplyJournalState::RecoveryFailed;
        ok(store.put_apply_journal(journal, &ctx()));
    }

    let reopened = FsStore::open(Box::new(fs), ROOT).expect("restart");
    let unresolved = ok(reopened.list_unresolved_apply(&ctx()));
    assert_eq!(unresolved.len(), 1);
    assert_eq!(unresolved[0].state, ApplyJournalState::RecoveryFailed);
    assert!(
        ok(reopened.list_pending_apply(&ctx())).is_empty(),
        "it is no longer merely pending, but it must still be reported"
    );
}

/// Write into the store's own tree without going through the store, the way a second writer would.
fn write_raw(fs: &SimFs, suffix: &str, text: &str) {
    let path = VPath::try_from_str(&format!("{ROOT}/{suffix}")).expect("path");
    io_ok(block_on_ready(fs.write_atomic(
        &path,
        text.as_bytes().to_vec(),
        Durability::D2,
        &ctx(),
    )));
}

/// The names one store directory holds, as the port itself lists them.
fn names_in(fs: &SimFs, dir: &str) -> Vec<String> {
    let path = VPath::try_from_str(&format!("{ROOT}/{dir}")).expect("dir path");
    let prefix = format!("{ROOT}/{dir}/");
    block_on_ready(fs.list(&path, ListCap(64), &ctx()))
        .expect("ready")
        .expect("a store directory must be enumerable")
        .into_iter()
        .map(|entry| {
            let full = entry.as_relative_path();
            full.strip_prefix(&prefix)
                .unwrap_or(full.as_str())
                .to_owned()
        })
        .collect()
}

/// `put` with an explicit claimed age, because the point of the next tests is a claim that lies.
fn put_at(store: &FsStore, digest: &str, payload: &[u8], claimed: i64) -> CasObjectRef {
    ok(store.put(
        CasWriteIntent {
            object: object(digest),
            source_label: format!("{digest}.yaml"),
            payload: payload.to_vec(),
            stored_at_unix_ms: claimed,
        },
        &ctx(),
    ))
}

/// A `SimFs` that knows what time it is -- injected, never read off the host (`ADR-011`).
fn disk_with_clock(at_unix_ms: i64) -> (SimFs, SimClock) {
    let clock = SimClock::new(
        VirtualClock::new(at_unix_ms),
        SharedFaults::new(FaultInjector::new(1)),
    );
    let fs =
        SimFs::new(MemFs::default(), SharedFaults::new(FaultInjector::new(1))).with_clock(&clock);
    (fs, clock)
}

#[test]
fn a_missing_object_is_not_an_error() {
    let store = FsStore::open(Box::new(disk()), ROOT).expect("open");
    assert!(ok(store.get("mihomo:absent", &ctx())).is_none());
}

/// A manifest used to be the only way a restart could answer "what is here?", which had a specific
/// blind spot: a record that no index named did not exist. `ADR-035 §2.3` replaced the index with
/// `Fs::list`, and the point of this test is that the blind spot is gone in *both* directions --
/// enumeration now reports exactly the files there are, whoever put them there.
#[test]
fn a_record_written_behind_the_stores_back_is_enumerated_like_any_other() {
    let fs = disk();
    let store = FsStore::open(Box::new(fs.clone()), ROOT).expect("open");
    ok(store.put_snapshot(snapshot_record("snapshot:owned"), &ctx()));

    // The name is the store's own escaped form of the id (`ADR-041`), because a record has to be findable by
    // id *and* by listing; if those two ever disagree about naming, this is where it shows.
    let foreign = snapshot_record("snapshot:foreign");
    // The bucket is derived from the file name (`ADR-062`), so an out-of-band writer
    // computes the same path the store would.
    write_raw(
        &fs,
        &format!(
            "records/snapshot/{}/snapshot%3Aforeign.rec",
            caly_storage::record_shard("snapshot%3Aforeign")
        ),
        &encode_snapshot(&foreign),
    );
    let expected = vec!["snapshot:foreign".to_owned(), "snapshot:owned".to_owned()];
    let ids = |records: Vec<SnapshotRecord>| -> Vec<String> {
        records.into_iter().map(|record| record.id.0).collect()
    };

    // A *running* store has to answer from the directory too, not from the map it accumulated: a
    // cache is only as good as the listing that filled it, and the two differ exactly here.
    assert_eq!(
        ids(ok(store.list_snapshots(&ctx()))),
        expected,
        "a record placed in the directory is part of the collection immediately"
    );
    drop(store);

    // A restart has nothing but the listing, and must reach the same answer.
    let reopened =
        FsStore::open(Box::new(fs), ROOT).expect("a record is a record, whoever wrote it");
    assert_eq!(
        ids(ok(reopened.list_snapshots(&ctx()))),
        expected,
        "both records must be enumerated, in listing order"
    );
    assert!(
        ok(reopened.get_snapshot(&SnapshotRecordId("snapshot:foreign".to_owned()), &ctx()))
            .expect("the enumerated record must be readable by id too")
            .is_last_known_good,
        "enumeration and lookup must be reading the same bytes"
    );
}

/// Since the directory is the truth, it has to distinguish debris from damage -- and the two need
/// opposite answers, because a store that refused its own leftovers could never boot again.
#[test]
fn a_temp_file_is_debris_but_an_unexplained_name_is_damage() {
    let fs = disk();
    {
        let store = FsStore::open(Box::new(fs.clone()), ROOT).expect("open");
        ok(store.put_snapshot(snapshot_record("snapshot:keep"), &ctx()));
    }

    // `StdFs::write_atomic` renames `<target>.tmp-<sequence>` into place, so this is what a crash
    // between create and rename leaves beside a perfectly good record.
    let keep_bucket = format!(
        "records/snapshot/{}",
        caly_storage::record_shard("snapshot%3Akeep")
    );
    write_raw(
        &fs,
        &format!("{keep_bucket}/snapshot%3Akeep.rec.tmp-7"),
        "half a record",
    );
    let reopened = FsStore::open(Box::new(fs.clone()), ROOT)
        .expect("crash residue must not be able to brick a restart");
    assert_eq!(
        ok(reopened.list_snapshots(&ctx())).len(),
        1,
        "the survivor must still be readable"
    );
    assert_eq!(
        names_in(&fs, &keep_bucket),
        vec!["snapshot%3Akeep.rec".to_owned()],
        "the residue must be reaped, not merely skipped: skipped, it would eat the enumeration budget"
    );

    // A name the layout does not explain is the opposite case: damage or somebody else's data, and
    // a store that quietly ignored it would be guessing which. The index this replaced could not see
    // such a file at all, so this check is what listing bought rather than what it cost.
    write_raw(&fs, "records/snapshot/README.txt", "not a record");
    match FsStore::open(Box::new(fs), ROOT) {
        Ok(_) => panic!("an unexplained file in a record directory must not be ignored"),
        Err(failure) => assert!(
            failure
                .summary
                .contains("unexpected file in records/snapshot: README.txt"),
            "{}",
            failure.summary
        ),
    }
}

/// `ADR-035 §2.1`: passing the enumeration bound is a refusal, never a short list. The store used to
/// inherit a bound by accident -- a manifest larger than the read cap could not be read -- and now
/// states one, so the failure has to be loud in exactly the same way.
#[test]
fn enumeration_refuses_rather_than_returning_a_short_list() {
    let fs = disk();
    let limit = caly_storage::MAX_ENTRIES_PER_DIRECTORY;
    // One bucket, deliberately: the top level holds bucket names (256 of them), so the
    // enumeration cap trips inside a bucket (`ADR-062`) -- writing these spread out
    // would need 256 buckets before any cap refused.
    let bucket = format!("records/snapshot/{}", caly_storage::record_shard("ab"));
    for index in 0..=limit {
        write_raw(
            &fs,
            &format!("{bucket}/snapshot_raw{index}.rec"),
            "record:v1\nid=x\n",
        );
    }
    let over = limit + 1;

    // Before any marker exists, the oversized directory is a question the *freshness probe* has to
    // answer, and it answers conservatively: "cannot enumerate" is not "empty", and initialising a
    // store on top of records it could not count is how they get lost.
    let unmark = FsStore::open(Box::new(fs.clone()), ROOT)
        .expect_err("a directory that cannot be listed must not look empty");
    assert!(
        unmark.summary.contains("holds data but no"),
        "{}",
        unmark.summary
    );

    // With a marker on disk the refusal comes from the store's own enumeration, in the port's words
    // rather than a truncated listing the caller cannot tell apart from "that is all there is".
    let failure = FsStore::open_with_migrations(
        Box::new(fs),
        ROOT,
        &caly_storage::schema::MigrationChain::empty(),
        true,
    )
    .expect_err("a directory over the bound must not open as a short list");
    assert!(
        !failure.summary.contains("unexpected file"),
        "a bound is not a layout complaint: {}",
        failure.summary
    );
    assert!(
        failure
            .summary
            .contains(&format!("holds {over} entries, cap was {limit}")),
        "the refusal must say how far over it is and against what: {}",
        failure.summary
    );
}

/// One record, one file. `put_snapshot` used to be two writes, and the second one was a list of the
/// first: the inconsistency `ADR-035` exists to remove. The exact file count is asserted because a
/// new companion file is precisely the thing that must not arrive unnoticed.
#[test]
fn the_store_writes_no_index_of_anything_it_wrote() {
    let fs = disk();
    let store = FsStore::open(Box::new(fs.clone()), ROOT).expect("open");
    write_object(&store, "mihomo:one", b"one");
    ok(store.put_snapshot(snapshot_record("snapshot:one"), &ctx()));
    ok(store.put_apply_journal(pending_journal("txn:one"), &ctx()));

    let files: Vec<String> = fs
        .snapshot()
        .expect("disk")
        .files
        .into_iter()
        .map(|file| file.path)
        .collect();
    assert!(
        files.iter().all(|path| !path.contains("manifest")),
        "no list of the store's contents may be written at all: {files:?}"
    );
    assert_eq!(
        files.len(),
        6,
        "marker + content + object metadata + snapshot record + journal record + pointer: {files:?}"
    );
}

/// `list_pending_apply` used to answer from this process's cache while `list_apply_journals` re-read
/// the disk: one store, two answers, and the boot refusal reads the first. Both enumerate now.
#[test]
fn a_pending_scan_answers_from_the_records_and_not_from_memory() {
    let fs = disk();
    let store = FsStore::open(Box::new(fs.clone()), ROOT).expect("open");
    ok(store.put_apply_journal(pending_journal("txn:gone"), &ctx()));
    ok(store.put_apply_journal(pending_journal("txn:here"), &ctx()));

    let victim = VPath::try_from_str(&format!(
        "var/caly/records/apply-journal/{}/txn%3Agone.rec",
        caly_storage::record_shard("txn%3Agone")
    ))
    .expect("path");
    io_ok(block_on_ready(fs.remove(&victim, &ctx())));

    let ids = |journals: Vec<ApplyJournalRecord>| -> Vec<String> {
        journals
            .into_iter()
            .map(|journal| journal.apply_txn_id.0)
            .collect()
    };
    assert_eq!(
        ids(ok(store.list_pending_apply(&ctx()))),
        vec!["txn:here".to_owned()],
        "the unfinished-transaction scan must not report a record that is gone"
    );
    assert_eq!(
        ids(ok(store.list_apply_journals(&ctx()))),
        vec!["txn:here".to_owned()],
        "the export and the recovery scan must never disagree about which transactions exist"
    );
    assert_eq!(
        store.apply_journal_count(),
        2,
        "the cache still holds both, which is exactly why it no longer answers enumeration"
    );
}

/// `ADR-035 §2.4`, step 3: an object's age is evidence, not an assertion.
///
/// `CasWriteIntent::stored_at_unix_ms` exists because the record has to survive backends without a
/// clock, and until now a caller writing `0` there was believed. That is a licence to delete: the
/// grace period is what protects an object nothing references *yet*, so "the caller says it is
/// ancient" defeats it exactly when no root exists to say otherwise. The port's mtime now wins.
#[test]
fn the_store_dates_objects_from_the_port_and_not_from_the_callers_claim() {
    let (fs, clock) = disk_with_clock(1_700_000_000_000);
    let store = FsStore::open(Box::new(fs.clone()), ROOT).expect("open");

    let written = put_at(&store, "mihomo:lied", b"fresh-bytes", 0);
    assert_eq!(
        written.stored_at_unix_ms,
        Some(1_700_000_000_000),
        "the write must answer with the port's time, not with the claim it was handed"
    );
    let listed = ok(store.list_objects(&ctx()));
    assert_eq!(listed.len(), 1, "the object must be enumerable: {listed:?}");
    assert_eq!(
        listed[0].stored_at_unix_ms,
        Some(1_700_000_000_000),
        "enumeration must agree with the write that produced it"
    );
    assert_eq!(
        ok(store.get("mihomo:lied", &ctx()))
            .expect("the object must be readable by id too")
            .stored_at_unix_ms,
        Some(1_700_000_000_000),
        "and `get` must not be the one call that still reports the claim"
    );

    // Per object, not per query: the stamp is the write's moment, and a second write gets its own.
    clock.advance_ms(60_000).expect("advance the virtual clock");
    let later = put_at(&store, "mihomo:later", b"newer-bytes", 0);
    assert_eq!(
        (written.stored_at_unix_ms, later.stored_at_unix_ms),
        (Some(1_700_000_000_000), Some(1_700_000_060_000),),
        "an age must not be 'whatever the clock reads when somebody asks'"
    );

    // And the evidence is on the disk, not in this process: a restart reports the same ages.
    drop(store);
    let reopened = FsStore::open(Box::new(fs), ROOT).expect("reopen");
    let aged: Vec<(String, Option<i64>)> = ok(reopened.list_objects(&ctx()))
        .into_iter()
        .map(|object| (object.digest.0, object.stored_at_unix_ms))
        .collect();
    assert_eq!(
        ok(reopened.get("mihomo:lied", &ctx()))
            .expect("readable after a restart")
            .stored_at_unix_ms,
        Some(1_700_000_000_000),
        "`get` after a restart answers from the cache the boot filled, so boot must date records too"
    );
    assert_eq!(
        aged,
        vec![
            ("mihomo:later".to_owned(), Some(1_700_000_060_000)),
            ("mihomo:lied".to_owned(), Some(1_700_000_000_000)),
        ],
        "a restart must not re-date an object to now (pairs, because enumeration sorts by digest)"
    );
}

/// The consequence that matters, asserted from both sides so it cannot pass for the wrong reason.
#[test]
fn a_fresh_object_stays_out_of_reach_of_gc_even_when_its_record_claims_otherwise() {
    let (fs, _clock) = disk_with_clock(1_700_000_000_000);
    let store = FsStore::open(Box::new(fs), ROOT).expect("open");
    put_at(&store, "mihomo:lied", b"fresh-bytes", 0);

    let policy = GcPolicy {
        grace_period_ms: 15 * 60 * 1000,
        now_unix_ms: 1_700_000_000_000,
        max_deletions: 16,
    };
    let objects = ok(store.list_objects(&ctx()));
    let roots = collect_gc_roots(&GcGraph::default(), &policy, &objects);
    assert!(
        roots.protects("mihomo:lied"),
        "a freshly written object must be inside the grace period"
    );
    assert!(
        plan_object_gc(&objects, &roots, &policy).is_noop(),
        "nothing may be collected while it is"
    );

    // The counterfactual: the same policy, the same object, with the caller's claim instead of the
    // port's evidence. If the store ever stops dating records, the assertion above goes green by
    // accident and this one goes red -- which is the only reason to write it.
    let mut claimed = objects[0].clone();
    claimed.stored_at_unix_ms = Some(0);
    let claimed = vec![claimed];
    let roots_from_claim = collect_gc_roots(&GcGraph::default(), &policy, &claimed);
    assert_eq!(
        plan_object_gc(&claimed, &roots_from_claim, &policy).collect,
        vec![ObjectDigest("mihomo:lied".to_owned())],
        "if age were only what the caller said, the grace period would be a suggestion"
    );
}

/// The other half of `§2.4`: no evidence is not the same as contradicting evidence. A backend with
/// no clock says nothing, and the record's own value remains -- which is what keeps `SimFs` (the
/// default, clock-less) and `InMemoryStorage` answering identically in `object_contract.rs`.
#[test]
fn a_store_without_a_clock_keeps_the_claim_and_invents_no_age() {
    let store = FsStore::open(Box::new(disk()), ROOT).expect("open");
    let written = put_at(&store, "mihomo:silent", b"bytes", 1_700_000_000_000);
    assert_eq!(
        written.stored_at_unix_ms,
        Some(1_700_000_000_000),
        "with nothing to contradict it, the record stands"
    );
    assert_eq!(
        ok(store.list_objects(&ctx()))[0].stored_at_unix_ms,
        Some(1_700_000_000_000),
        "and the store must not fall back to a fabricated 'now'"
    );
}

/// Which way the two sources are combined is a safety decision, so both directions are pinned.
#[test]
fn a_claim_newer_than_the_port_is_kept_and_a_missing_one_is_filled_in() {
    let (fs, clock) = disk_with_clock(1_700_000_000_000);
    let store = FsStore::open(Box::new(fs.clone()), ROOT).expect("open");

    // Newer claim than the file: kept. Retaining an object one cycle too long is reversible;
    // deleting it too early is not, so the conservative direction wins when they merely disagree.
    let over = put_at(&store, "mihomo:future", b"future-claim", 1_800_000_000_000);
    assert_eq!(over.stored_at_unix_ms, Some(1_800_000_000_000));

    // A record with no claim at all -- which is what every object written before this field
    // existed looks like -- gets the port's date rather than "unknown forever".
    clock.advance_ms(1_000).expect("advance");
    let unclaimed = CasObjectRef {
        digest: ObjectDigest("external:legacy".to_owned()),
        kind: ObjectKind::CompiledArtifact,
        size_bytes: None,
        content_type: None,
        content_sha256: None,
        stored_at_unix_ms: None,
    };
    write_raw(
        &fs,
        &format!(
            "meta/objects/{}/external%3Alegacy.obj",
            caly_storage::record_shard("external%3Alegacy")
        ),
        &encode_object(&unclaimed),
    );

    let ages: Vec<(String, Option<i64>)> = ok(store.list_objects(&ctx()))
        .into_iter()
        .map(|object| (object.digest.0.clone(), object.stored_at_unix_ms))
        .collect();
    assert_eq!(
        ages,
        vec![
            ("external:legacy".to_owned(), Some(1_700_000_001_000)),
            ("mihomo:future".to_owned(), Some(1_800_000_000_000)),
        ],
        "the foreign record must get the file's date (a record with no claim is not a record with          no evidence), and the future claim must be kept as the newer of the two"
    );
}
