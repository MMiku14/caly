//! The deadline half of the store's port driving (`ADR-039 §2`, step 3).
//!
//! Round 28 gave the store's port driver a **poll budget** so a suspending port would be answered
//! `Busy` instead of `Internal`, and recorded the other half as deliberately missing: "在 `Deadline`
//! 内" needs a clock, and only whoever holds a clock may say the time is up (`§4.86`). This file
//! pins the half that now exists:
//!
//! * a context whose `deadline_mono_ms` has passed, on a store opened with a clock, is answered
//!   **`Timeout`** -- a third answer, distinct from `Busy` ("not finished") and from `Internal`;
//! * a deadline in the future changes nothing: the poll budget answers `Busy` as before;
//! * a deadline without a clock is **ignored, never guessed** -- the port layer's own rule, held
//!   here at the store seam;
//! * a cancelled caller is answered **`Cancelled` even mid-port**: round 33's doors were leading
//!   checks inside store methods; the driver's between-polls check is the half that covers a port
//!   which suspends.

use std::sync::Arc;

use caly_io::Clock;
use caly_io::{block_on_ready, Fs, IoContext};
use caly_io_sim::{hang, FaultInjector, MemFs, SharedFaults, SimClock, SimFs, VirtualClock};
use caly_storage::cas::{CasObjectRef, CasWriteIntent, ObjectDigest, ObjectKind};
use caly_storage::{FsStore, ObjectStore, StorageError, StorageErrorKind};

const ROOT: &str = "var/caly";

fn ctx() -> IoContext {
    IoContext::new(
        caly_io::TraceId::new("store-port-deadline"),
        caly_io::Actor::System,
    )
}

fn object(digest: &str) -> CasObjectRef {
    CasObjectRef {
        digest: ObjectDigest(digest.to_owned()),
        kind: ObjectKind::CompiledArtifact,
        size_bytes: None,
        content_type: None,
        content_sha256: None,
        stored_at_unix_ms: Some(1_700_000_000_000),
    }
}

/// A store with an object in it and a clock on it. `read_object` answers `Ok(None)` for a digest
/// with no record *without touching the port*, so the object is written first, on a clean store;
/// callers arm `hang("fs.read")` when they want the port silent.
fn clocked_store_with_object() -> (FsStore, SimClock, SharedFaults) {
    let faults = SharedFaults::new(FaultInjector::new(1));
    let clock = SimClock::new(VirtualClock::new(1_700_000_000_000), faults.clone());
    let fs = SimFs::new(MemFs::default(), faults.clone()).with_clock(&clock);
    let store = FsStore::open(Box::new(fs) as Box<dyn Fs>, ROOT)
        .expect("open")
        .with_clock(Arc::new(clock.clone()) as Arc<dyn Clock>);
    block_on_ready(store.put(
        CasWriteIntent {
            object: object("sha256:the-object"),
            source_label: "the-object.yaml".to_owned(),
            payload: b"payload worth reading".to_vec(),
            stored_at_unix_ms: 1_700_000_000_000,
        },
        &ctx(),
    ))
    .expect("no suspension")
    .expect("place the object");
    (store, clock, faults)
}

/// Every `fs.read` hangs from here on: the port never answers, so the *driver's* answer is the
/// only answer -- which is exactly what these tests need to see.
fn arm_hang(faults: &SharedFaults) {
    faults.push(hang("fs.read")).expect("arm a hang");
}

fn read(store: &FsStore, digest: &str, ctx: &IoContext) -> Result<Option<Vec<u8>>, StorageError> {
    block_on_ready(store.read_object(digest, 1 << 20, ctx)).expect("no suspension at the seam")
}

#[test]
fn an_expired_deadline_times_the_port_out_instead_of_calling_it_busy() {
    let (store, clock, faults) = clocked_store_with_object();
    arm_hang(&faults);
    let now = Clock::mono(&clock).ticks_millis;
    let caller = ctx().with_deadline_from(Some(now), 0);
    // The deadline is `now + 0` -- already expired at the first check, before any poll.
    let error = read(&store, "sha256:the-object", &caller).expect_err("the deadline has passed");
    assert_eq!(error.kind, StorageErrorKind::Timeout, "{}", error.summary);
    assert!(
        error.summary.contains("deadline at mono"),
        "the refusal must name the deadline and the clock that judged it: {}",
        error.summary
    );
    // And it is *not* the budget's answer: the same hang without a deadline says Busy below.
}

#[test]
fn a_future_deadline_keeps_the_budgets_busy_answer() {
    let (store, clock, faults) = clocked_store_with_object();
    arm_hang(&faults);
    // Boundary from the other side: a deadline comfortably in the future must not fire; the
    // poll budget is what answers, and its answer is Busy -- the round-28 behaviour, unchanged.
    let now = Clock::mono(&clock).ticks_millis;
    let caller = ctx().with_deadline_from(Some(now), 60_000);
    let error = read(&store, "sha256:the-object", &caller).expect_err("the port never answers");
    assert_eq!(error.kind, StorageErrorKind::Busy, "{}", error.summary);
    assert!(
        error.summary.contains("poll"),
        "the budget's refusal must say it counted polls: {}",
        error.summary
    );
}

#[test]
fn a_deadline_without_a_clock_is_ignored_rather_than_guessed() {
    // Same hang, same expired deadline, no clock on the store: the old answers hold exactly.
    // A layer that answered Timeout here would have invented a clock it does not hold.
    let faults = SharedFaults::new(FaultInjector::new(1));
    let fs = SimFs::new(MemFs::default(), faults.clone());
    let store = FsStore::open(Box::new(fs) as Box<dyn Fs>, ROOT).expect("open");
    // The object must exist: a digest with no record answers `Ok(None)` without touching the
    // port, and the question here is what the *driver* says about a silent one.
    block_on_ready(store.put(
        CasWriteIntent {
            object: object("sha256:the-object"),
            source_label: "the-object.yaml".to_owned(),
            payload: b"payload worth reading".to_vec(),
            stored_at_unix_ms: 1_700_000_000_000,
        },
        &ctx(),
    ))
    .expect("no suspension")
    .expect("place the object");
    faults.push(hang("fs.read")).expect("arm a hang");
    let caller = ctx().with_deadline_from(Some(0), 0);
    let error = read(&store, "sha256:the-object", &caller).expect_err("the port never answers");
    assert_eq!(
        error.kind,
        StorageErrorKind::Busy,
        "no clock means no deadline judgement: {}",
        error.summary
    );
}

#[test]
fn a_cancelled_caller_is_answered_cancelled_even_mid_port() {
    let (store, _clock, faults) = clocked_store_with_object();
    arm_hang(&faults);
    let mut caller = ctx();
    caller.cancel = caly_common::CancelToken::pre_cancelled();
    let error = read(&store, "sha256:the-object", &caller)
        .expect_err("a cancelled caller is not served a hung port");
    assert_eq!(error.kind, StorageErrorKind::Cancelled, "{}", error.summary);
}

#[test]
fn the_clock_is_judged_by_its_own_ticks_not_by_the_callers_words() {
    // The caller states a *relative* deadline; the store's clock turns it into an absolute one.
    // Advance the clock past that window and the same store that just answered Busy answers
    // Timeout -- the judgement is the clock's, and the clock moved.
    let (store, clock, faults) = clocked_store_with_object();
    arm_hang(&faults);
    let now = Clock::mono(&clock).ticks_millis;
    let caller = ctx().with_deadline_from(Some(now), 5_000);
    let error = read(&store, "sha256:the-object", &caller).expect_err("the port never answers");
    assert_eq!(error.kind, StorageErrorKind::Busy, "{}", error.summary);
    clock.advance_ms(6_000).expect("advance the virtual clock");
    let error = read(&store, "sha256:the-object", &caller)
        .expect_err("the deadline the same caller stated has now passed");
    assert_eq!(error.kind, StorageErrorKind::Timeout, "{}", error.summary);
}
