//! `JobLogStore` contract, both storage backends.
//!
//! The terminal job record is what a daemon reads back after a restart to answer `jobs.list` /
//! `jobs.events` without re-running the job (`ADR-057` §5 slice 1 — the storage primitive). Two
//! properties matter here and must hold identically on `InMemoryStorage` and on `FsStore`:
//!
//! - a written terminal record reads back byte for byte, and
//! - `list_job_logs` reports newest-first (numeric job id descending), because the CLI and the
//!   resume check both read the head of that list.
//!
//! The durable backend has one more property an in-memory map cannot have: a **brand-new store
//! opened on the same root** reloads the record — the crash/reopen path working at the storage
//! layer, before the daemon that will rely on it even exists (slice 2).

use caly_io::{block_on_ready, ByteCap, Fs, IoContext};
use caly_io_sim::{FaultInjector, MemFs, SharedFaults, SimFs};
use caly_storage::fs_store::FsStore;
use caly_storage::job_log::{JobEventRecord, JobLogRecord};
use caly_storage::{InMemoryStorage, JobLogStore, StorageError};

const ROOT: &str = "var/caly";

fn ctx() -> IoContext {
    IoContext::new(
        caly_io::TraceId::new("job-log-contract"),
        caly_io::Actor::System,
    )
}

fn done<T: std::fmt::Debug>(
    future: caly_storage::BoxFuture<'_, Result<T, StorageError>>,
    what: &str,
) -> T {
    block_on_ready(future)
        .unwrap_or_else(|message| panic!("{what}: the store suspended ({message})"))
        .unwrap_or_else(|error| panic!("{what}: {}", error.summary))
}

fn failed_job(id: u64, stage_pct: u8) -> JobLogRecord {
    JobLogRecord {
        job_id: id.to_string(),
        state: "failed".to_owned(),
        revision: id,
        outcome: Some("failed".to_owned()),
        failure_code: Some("PERMISSION".to_owned()),
        failure_summary: Some("role Viewer does not satisfy required role Admin".to_owned()),
        last_stage: Some("storage.project".to_owned()),
        last_stage_pct: Some(stage_pct),
        warning_count: 1,
        log_count: 3,
        events: vec![
            JobEventRecord {
                kind: "stage".to_owned(),
                line: format!("[stage {stage_pct}%] running"),
            },
            JobEventRecord {
                kind: "failed".to_owned(),
                line: "[failed] PERMISSION".to_owned(),
            },
        ],
        committed_at_unix_ms: 1_700_000_000_000 + id as i64,
    }
}

#[test]
fn a_terminal_job_record_round_trips_on_every_backend() {
    assert_contract(&InMemoryStorage::new(), "in-memory");

    let fs = SimFs::new(MemFs::default(), SharedFaults::new(FaultInjector::new(1)));
    let durable = FsStore::open(Box::new(fs.clone()) as Box<dyn Fs>, ROOT).expect("open");
    assert_contract(&durable, "fs-store");

    // Reopen: a brand-new store over the *same* filesystem root must reload the records. This is
    // the storage skeleton of "kill -9, restart same data-dir, `jobs.list` still answers".
    let reopened = FsStore::open(Box::new(fs) as Box<dyn Fs>, ROOT).expect("reopen");
    let after = done(reopened.get_job_log("7", &ctx()), "fs-store reopen get")
        .unwrap_or_else(|| panic!("fs-store: a reopened store must still hold the record"));
    assert_eq!(
        after,
        failed_job(7, 70),
        "fs-store: the terminal record survives a store reopen (restart skeleton)"
    );
    let re_ids: Vec<String> = done(reopened.list_job_logs(&ctx()), "fs-store reopen list")
        .iter()
        .map(|item| item.job_id.clone())
        .collect();
    assert_eq!(
        re_ids,
        vec!["9".to_owned(), "7".to_owned()],
        "fs-store: reopen preserves newest-first order"
    );
}

#[test]
fn a_deleted_job_log_is_gone_on_both_backends_and_stays_gone_after_reopen() {
    // In-memory: delete reports presence then absence.
    let memory = InMemoryStorage::new();
    done(memory.put_job_log(failed_job(5, 10), &ctx()), "memory put");
    assert!(
        done(memory.delete_job_log("5", &ctx()), "memory delete"),
        "deleting a present record reports true"
    );
    assert!(
        !done(memory.delete_job_log("5", &ctx()), "memory delete again"),
        "deleting an absent record reports false"
    );
    assert!(
        done(memory.get_job_log("5", &ctx()), "memory get").is_none(),
        "a deleted record reads back as None"
    );

    // Durable: the file is actually gone, and a reopen on the same root does not bring it back —
    // this is the reclamation side the engine's bounded retention (`ADR-057` §4) relies on.
    let fs = SimFs::new(MemFs::default(), SharedFaults::new(FaultInjector::new(1)));
    {
        let store = FsStore::open(Box::new(fs.clone()) as Box<dyn Fs>, ROOT).expect("open");
        done(store.put_job_log(failed_job(5, 10), &ctx()), "fs put");
        assert!(
            done(store.delete_job_log("5", &ctx()), "fs delete"),
            "present"
        );
        assert!(
            done(store.get_job_log("5", &ctx()), "fs get").is_none(),
            "deleted in the live store"
        );
    }
    let reopened = FsStore::open(Box::new(fs) as Box<dyn Fs>, ROOT).expect("reopen");
    assert!(
        done(reopened.get_job_log("5", &ctx()), "fs reopen get").is_none(),
        "deletion survives a store reopen"
    );
    assert_eq!(
        done(reopened.list_job_logs(&ctx()), "fs reopen list"),
        Vec::new(),
        "the reclaimed record does not reappear in the listing"
    );
}

fn assert_contract(backend: &dyn JobLogStore, label: &str) {
    let record = failed_job(7, 70);

    assert!(
        done(
            backend.get_job_log("7", &ctx()),
            &format!("{label} absent get")
        )
        .is_none(),
        "{label}: an unknown job must read back as None"
    );

    done(
        backend.put_job_log(record.clone(), &ctx()),
        &format!("{label} put"),
    );
    let back = done(backend.get_job_log("7", &ctx()), &format!("{label} get"))
        .unwrap_or_else(|| panic!("{label}: the written record must be readable"));
    assert_eq!(
        back, record,
        "{label}: the terminal record round-trips byte for byte"
    );

    // A second record so ordering and the head-of-list semantics have something to order.
    done(
        backend.put_job_log(failed_job(9, 40), &ctx()),
        &format!("{label} put 2"),
    );

    let listed = done(backend.list_job_logs(&ctx()), &format!("{label} list"));
    let ids: Vec<&str> = listed.iter().map(|item| item.job_id.as_str()).collect();
    assert_eq!(
        ids,
        vec!["9", "7"],
        "{label}: list_job_logs is newest-first (numeric id descending)"
    );
}

#[test]
fn a_job_log_with_an_unknown_field_is_refused_when_the_store_reopens() {
    let fs = SimFs::new(MemFs::default(), SharedFaults::new(FaultInjector::new(1)));
    {
        let store = FsStore::open(Box::new(fs.clone()) as Box<dyn Fs>, ROOT).expect("open");
        done(store.put_job_log(failed_job(11, 55), &ctx()), "put");
    }
    // Forge a field a v1 record never carries — a future schema version wrote this file. The
    // startup scan walks `records/job-log/` and decodes every entry, so the corruption must be
    // caught at *reopen*, before any caller could read a record it only partially understood.
    let path = format!(
        "{ROOT}/records/job-log/{}/11.rec",
        caly_storage::record_shard("11")
    );
    let vpath = caly_io::VPath::try_from_str(&path).expect("relative path");
    let file_ctx = ctx();
    let bytes = block_on_ready(fs.read(&vpath, ByteCap(1 << 20), &file_ctx))
        .expect("no suspension")
        .expect("the record file exists");
    let text = String::from_utf8(bytes.to_vec()).expect("record is utf-8");
    let tampered = format!("{text}sneaked_in_field=true");
    block_on_ready(fs.write_atomic(
        &vpath,
        tampered.into_bytes(),
        caly_io::Durability::D1,
        &file_ctx,
    ))
    .expect("no suspension")
    .expect("the test must be able to corrupt the file");

    let error = FsStore::open(Box::new(fs) as Box<dyn Fs>, ROOT)
        .expect_err("a record carrying fields this build does not understand must fail the reopen");
    assert!(
        error.summary.contains("job-log") && error.summary.contains("sneaked_in_field"),
        "the reopen names both the collection and the unknown field so recovery can pinpoint \
         the file: {}",
        error.summary
    );
}
