//! GC policy over the CAS (`RFC-0007 §13`, acceptance criterion `§15.6`).
//!
//! The rule under test is short — "GC 不删除被 Active/Snapshot/Journal 引用对象" — but it is the
//! one place where a storage bug becomes data loss instead of a failed apply. So the tests assert
//! both directions: rooted objects survive *for the right reason*, and unrooted ones are actually
//! removed. A collector that never deletes anything would pass the first half and is worthless.
//!
//! The last group runs the same policy against `FsStore`, where "removed" means the file is gone.

use caly_io::{block_on_ready, Fs, IoContext, VPath};
use caly_io_sim::{FaultInjector, MemFs, SharedFaults, SimFs};
use caly_storage::cas::{CasObjectRef, CasWriteIntent, ObjectDigest, ObjectKind};
use caly_storage::execution::{ApplyJournalRecord, ApplyJournalState, ApplyPhase, ApplyTxnId};
use caly_storage::fs_store::{content_suffix_for, FsStore};
use caly_storage::gc::{
    collect_gc_roots, plan_object_gc, run_object_gc, GcBlocked, GcEligibility, GcGraph, GcPolicy,
    GcRootReason,
};
use caly_storage::journal::JournalRecordId;
use caly_storage::revision::{RevisionId, RevisionNumber, RevisionRecord};
use caly_storage::snapshot::{SnapshotRecord, SnapshotRecordId};
use caly_storage::{InMemoryStorage, ObjectStore, StorageErrorKind};

const ROOT: &str = "var/caly";

fn ctx() -> IoContext {
    IoContext::new(caly_io::TraceId::new("gc"), caly_io::Actor::System)
}

fn object(digest: &str, stored_at: i64) -> CasObjectRef {
    CasObjectRef {
        digest: ObjectDigest(digest.to_owned()),
        kind: ObjectKind::CompiledArtifact,
        size_bytes: Some(16),
        content_type: Some("application/x-yaml".to_owned()),
        // Left to the store. A declared anchor that does not match the payload is refused, which
        // is the correct behaviour and would break these fixtures if we faked it here.
        content_sha256: None,
        stored_at_unix_ms: Some(stored_at),
    }
}

fn snapshot(id: &str, artifact: &str) -> SnapshotRecord {
    SnapshotRecord {
        id: SnapshotRecordId(id.to_owned()),
        revision_id: RevisionId(format!("rev:{id}")),
        revision_number: RevisionNumber(1),
        profile_id: "p1".to_owned(),
        semantic_digest: format!("sem:{id}"),
        compiled_artifact_digest: artifact.to_owned(),
        core_binary_digest: "bin:1".to_owned(),
        core_identity: "mihomo@0.1".to_owned(),
        apply_plan_summary: "Restart".to_owned(),
        journal_id: None,
        selection_memory_digest: None,
        validation_summary: "ok".to_owned(),
        created_at_unix_ms: 10,
        is_last_known_good: true,
    }
}

fn journal(txn: &str, artifact: &str, state: ApplyJournalState) -> ApplyJournalRecord {
    ApplyJournalRecord {
        journal_id: JournalRecordId(format!("journal:{txn}")),
        apply_txn_id: ApplyTxnId(txn.to_owned()),
        trace_id: "t".to_owned(),
        job_id: None,
        profile_id: "p1".to_owned(),
        revision_id: RevisionId("rev-1".to_owned()),
        semantic_digest: format!("sem:{txn}"),
        compiled_artifact_digest: artifact.to_owned(),
        core_identity: "mihomo@0.1".to_owned(),
        effect_plan_id: "plan".to_owned(),
        current_phase: ApplyPhase::Cutover,
        current_step_index: 1,
        net_effect_started: false,
        core_cutover_started: false,
        previous_snapshot_id: None,
        created_at_unix_ms: 1,
        updated_at_unix_ms: 2,
        state,
    }
}

fn policy(now: i64) -> GcPolicy {
    GcPolicy {
        grace_period_ms: 1_000,
        now_unix_ms: now,
        max_deletions: 64,
    }
}

const IDLE: GcEligibility = GcEligibility {
    idle: true,
    pending_deployments: 0,
};

fn reasons(roots: &caly_storage::gc::GcRootSet, digest: &str) -> Vec<GcRootReason> {
    roots.reasons_for(digest).to_vec()
}

#[test]
fn every_documented_root_category_protects_its_object() {
    let revisions = [RevisionRecord {
        id: RevisionId("rev-1".to_owned()),
        number: RevisionNumber(1),
        profile_id: "p1".to_owned(),
        semantic_digest: "sem:active".to_owned(),
        created_at_unix_ms: 1,
    }];
    let journals = [journal(
        "txn-open",
        "obj:journal",
        ApplyJournalState::Pending,
    )];
    let running = vec!["obj:running".to_owned()];
    let pinned = vec!["obj:pinned".to_owned()];
    let active = snapshot("snap-active", "obj:active");
    let lkg = snapshot("snap-lkg", "obj:lkg");
    let graph = GcGraph {
        active_snapshot: Some(&active),
        last_known_good: Some(&lkg),
        retained_snapshots: &[],
        revisions: &revisions,
        source_raw_objects: &[],
        unfinished_journals: &journals,
        running_job_artifacts: &running,
        pinned: &pinned,
    };

    // Every one of these is older than the grace window, so only a root can save it.
    let objects = [
        "obj:active",
        "obj:lkg",
        "obj:journal",
        "obj:running",
        "obj:pinned",
    ]
    .iter()
    .map(|digest| object(digest, 0))
    .collect::<Vec<_>>();
    let roots = collect_gc_roots(&graph, &policy(10_000), &objects);

    assert_eq!(
        reasons(&roots, "obj:active"),
        vec![GcRootReason::ActiveSnapshot]
    );
    assert_eq!(
        reasons(&roots, "obj:lkg"),
        vec![GcRootReason::LastKnownGood]
    );
    assert_eq!(
        reasons(&roots, "obj:journal"),
        vec![GcRootReason::UnfinishedJournal]
    );
    assert_eq!(
        reasons(&roots, "obj:running"),
        vec![GcRootReason::RunningJob]
    );
    assert!(
        roots.protects("bin:1"),
        "core binaries named by a snapshot are roots as well"
    );
    assert!(
        roots.protects("sem:active"),
        "a registered revision pins its digest"
    );
    assert!(
        roots.protects("sem:txn-open"),
        "an unfinished journal pins its semantic digest"
    );
    // 5 pinned artifacts + the shared core binary (both snapshots name `bin:1`) + the active
    // revision digest + the open journal's semantic digest.
    assert_eq!(
        roots.len(),
        8,
        "one entry per protected digest, reasons merged"
    );

    let plan = plan_object_gc(&objects, &roots, &policy(10_000));
    assert!(
        plan.collect.is_empty(),
        "nothing rooted may be collected: {:?}",
        plan.collect
    );
    assert_eq!(plan.retained, 5);
    assert!(plan.is_noop());
}

#[test]
fn unreferenced_old_objects_are_collected() {
    let objects = vec![
        object("obj:garbage-a", 0),
        object("obj:garbage-b", 1),
        object("obj:recent", 9_500),
    ];
    let roots = collect_gc_roots(&GcGraph::default(), &policy(10_000), &objects);
    let plan = plan_object_gc(&objects, &roots, &policy(10_000));

    assert_eq!(
        plan.collect,
        vec![
            ObjectDigest("obj:garbage-a".to_owned()),
            ObjectDigest("obj:garbage-b".to_owned())
        ],
        "old and unreferenced must actually be collected"
    );
    assert_eq!(plan.skipped_for_grace, 1);
    assert!(plan
        .blocked
        .iter()
        .any(|blocked: &GcBlocked| blocked.digest == "obj:recent"
            && blocked.reasons == vec![GcRootReason::GracePeriod]));
}

#[test]
fn an_object_of_unknown_age_is_never_collectable() {
    let mut unknown = object("obj:unknown", 0);
    unknown.stored_at_unix_ms = None;
    let objects = vec![unknown];
    let roots = collect_gc_roots(&GcGraph::default(), &policy(1_000_000), &objects);
    let plan = plan_object_gc(&objects, &roots, &policy(1_000_000));
    assert!(
        plan.collect.is_empty(),
        "unknown freshness is not a licence to delete"
    );
    assert!(roots.protects("obj:unknown"));
}

#[test]
fn grace_period_expiry_makes_the_same_object_collectable() {
    let objects = vec![object("obj:recent", 1_000)];
    let inside = policy(1_999);
    let outside = policy(2_000);

    let roots_inside = collect_gc_roots(&GcGraph::default(), &inside, &objects);
    assert!(plan_object_gc(&objects, &roots_inside, &inside).is_noop());

    let roots_outside = collect_gc_roots(&GcGraph::default(), &outside, &objects);
    assert_eq!(
        plan_object_gc(&objects, &roots_outside, &outside).collect,
        vec![ObjectDigest("obj:recent".to_owned())]
    );
}

#[test]
fn a_cycle_is_capped_so_one_bug_cannot_wipe_the_store() {
    let objects: Vec<CasObjectRef> = (0..10).map(|i| object(&format!("obj:{i}"), 0)).collect();
    let roots = collect_gc_roots(&GcGraph::default(), &policy(10_000), &objects);
    let capped = GcPolicy {
        max_deletions: 3,
        ..policy(10_000)
    };
    let plan = plan_object_gc(&objects, &roots, &capped);
    assert_eq!(plan.collect.len(), 3, "the cap must bind");
    assert_eq!(
        plan.blocked
            .iter()
            .filter(|blocked| blocked.reasons.is_empty())
            .count(),
        7,
        "over-cap objects must be reported as blocked-but-rootless, not silently dropped"
    );
}

#[test]
fn gc_refuses_to_run_while_a_deployment_is_in_flight() {
    let store = InMemoryStorage::new();
    let objects = vec![object("obj:garbage", 0)];
    let graph = GcGraph::default();

    let busy = GcEligibility {
        idle: true,
        pending_deployments: 1,
    };
    let error = block_on_ready(run_object_gc(
        &store,
        &objects,
        &graph,
        &policy(10_000),
        busy,
        &ctx(),
    ))
    .expect("ready")
    .expect_err("`§13.2`: no collection while a deployment is pending");
    assert_eq!(error.kind, StorageErrorKind::Busy);
    assert!(
        error.summary.contains("gc refused by policy"),
        "{}",
        error.summary
    );

    let not_idle = GcEligibility {
        idle: false,
        pending_deployments: 0,
    };
    let error = block_on_ready(run_object_gc(
        &store,
        &objects,
        &graph,
        &policy(10_000),
        not_idle,
        &ctx(),
    ))
    .expect("ready")
    .expect_err("a non-idle store must also veto the cycle");
    assert!(error.summary.contains("NotIdle"), "{}", error.summary);

    let empty = block_on_ready(run_object_gc(
        &store,
        &[],
        &graph,
        &policy(10_000),
        IDLE,
        &ctx(),
    ))
    .expect("ready")
    .expect_err("an empty candidate set means the caller never enumerated");
    assert_eq!(empty.kind, StorageErrorKind::Internal);
}

#[test]
fn a_collected_object_is_actually_gone_and_a_second_cycle_is_a_noop() {
    let store = InMemoryStorage::new();
    let payload = b"artifact-bytes".to_vec();
    for digest in ["obj:garbage", "obj:rooted"] {
        block_on_ready(store.put(
            CasWriteIntent {
                object: object(digest, 0),
                source_label: "config.yaml".to_owned(),
                payload: payload.clone(),
                stored_at_unix_ms: 0,
            },
            &ctx(),
        ))
        .expect("ready")
        .expect("write");
    }

    let active = snapshot("snap-1", "obj:rooted");
    let graph = GcGraph {
        active_snapshot: Some(&active),
        ..GcGraph::default()
    };

    let listed = block_on_ready(store.list_objects(&ctx()))
        .expect("ready")
        .expect("enumerate");
    assert_eq!(listed.len(), 2);

    let report = block_on_ready(run_object_gc(
        &store,
        &listed,
        &graph,
        &policy(10_000),
        IDLE,
        &ctx(),
    ))
    .expect("ready")
    .expect("gc cycle");
    assert_eq!(
        report.collected,
        vec![ObjectDigest("obj:garbage".to_owned())]
    );
    assert!(report.failed.is_empty(), "{:?}", report.failed);
    assert_eq!(report.retained, 1);
    assert!(
        report.summary_line().contains("collected=1"),
        "{}",
        report.summary_line()
    );

    assert!(block_on_ready(store.get("obj:garbage", &ctx()))
        .expect("ready")
        .expect("get")
        .is_none());
    assert!(block_on_ready(store.get("obj:rooted", &ctx()))
        .expect("ready")
        .expect("get")
        .is_some());

    let remaining = block_on_ready(store.list_objects(&ctx()))
        .expect("ready")
        .expect("re-enumerate");
    let second = block_on_ready(run_object_gc(
        &store,
        &remaining,
        &graph,
        &policy(10_000),
        IDLE,
        &ctx(),
    ))
    .expect("ready")
    .expect("second cycle");
    assert!(
        second.collected.is_empty(),
        "a second pass must be a no-op: {second:?}"
    );
}

/// The same policy against the durable store. `delete` here has to shrink the manifest as well as
/// remove bytes, or a restart resurrects an object the collector already "removed".
///
/// It is also the shared-content check: the two digests below were written from identical bytes
/// and therefore point at one content file. Collecting one must not strand the other.
#[test]
fn fs_store_gc_removes_files_but_keeps_shared_content_for_the_survivor() {
    let disk = SimFs::new(MemFs::default(), SharedFaults::new(FaultInjector::new(1)));
    let store = FsStore::open(Box::new(disk.clone()) as Box<dyn Fs>, ROOT).expect("open");
    let payload = b"same-bytes".to_vec();
    for digest in ["obj:keep", "obj:drop"] {
        block_on_ready(store.put(
            CasWriteIntent {
                object: object(digest, 0),
                source_label: "config.yaml".to_owned(),
                payload: payload.clone(),
                stored_at_unix_ms: 0,
            },
            &ctx(),
        ))
        .expect("ready")
        .expect("write");
    }

    let anchor = caly_common::digest::sha256_digest(&payload);
    let content_path = format!("{ROOT}/{}", content_suffix_for(&anchor));

    let listed = block_on_ready(store.list_objects(&ctx()))
        .expect("ready")
        .expect("enumerate");
    assert_eq!(listed.len(), 2);

    let active = snapshot("snap-shared", "obj:keep");
    let graph = GcGraph {
        active_snapshot: Some(&active),
        ..GcGraph::default()
    };
    let report = block_on_ready(run_object_gc(
        &store,
        &listed,
        &graph,
        &policy(10_000),
        IDLE,
        &ctx(),
    ))
    .expect("ready")
    .expect("gc on the durable store");
    assert_eq!(report.collected, vec![ObjectDigest("obj:drop".to_owned())]);

    let kept = block_on_ready(store.get("obj:keep", &ctx()))
        .expect("ready")
        .expect("get")
        .expect("the rooted object must survive");
    assert_eq!(kept.content_sha256.as_deref(), Some(anchor.as_str()));

    let path = VPath::try_from_str(&content_path).expect("path");
    block_on_ready(disk.stat(&path, &ctx()))
        .expect("ready")
        .expect("stat")
        .expect("content shared with a surviving object must not be deleted");

    // Materializing the survivor still works end to end.
    block_on_ready(store.materialize(
        caly_storage::cas::MaterializationRequest {
            object: kept,
            runtime_path: "runtime/p1/config.yaml".to_owned(),
            mode: caly_storage::cas::MaterializationMode::Copy,
        },
        &ctx(),
    ))
    .expect("ready")
    .expect("materialize after a gc cycle must still succeed");

    assert_eq!(
        block_on_ready(store.list_objects(&ctx()))
            .expect("ready")
            .expect("re-list")
            .len(),
        1,
        "the manifest must shrink too, or a restart resurrects the dead object"
    );

    // A restart sees exactly one object, and its content is still intact.
    let reopened = FsStore::open(Box::new(disk) as Box<dyn Fs>, ROOT).expect("reopen");
    let after_restart = block_on_ready(reopened.list_objects(&ctx()))
        .expect("ready")
        .expect("enumerate after restart");
    assert_eq!(after_restart.len(), 1);
    assert_eq!(after_restart[0].digest.0, "obj:keep");
}

#[test]
fn superseded_snapshots_pin_their_artifacts_until_forgotten() {
    let retained = [
        snapshot("snap-new", "obj:new"),
        snapshot("snap-old", "obj:old"),
    ];
    let objects = vec![
        object("obj:new", 0),
        object("obj:old", 0),
        object("obj:gone", 0),
    ];
    let graph = GcGraph {
        active_snapshot: Some(&retained[0]),
        last_known_good: Some(&retained[0]),
        retained_snapshots: &retained,
        ..GcGraph::default()
    };
    let roots = collect_gc_roots(&graph, &policy(10_000), &objects);
    let plan = plan_object_gc(&objects, &roots, &policy(10_000));
    assert_eq!(
        plan.collect,
        vec![ObjectDigest("obj:gone".to_owned())],
        "a snapshot kept as a rollback target pins its artifact"
    );
    assert!(roots.protects("obj:old"));
}

/// The grace window is a half-open interval `[0, grace)` from the object's own timestamp, and a
/// GC that got the boundary wrong either never collects (leak) or collects one step early
/// (deleting an object a starting daemon may still be reading). Pinning all three points.
#[test]
fn a_source_index_raw_object_is_protected_for_future_conditional_reads() {
    let source_raw_objects = ["obj:source-raw".to_owned()];
    let graph = GcGraph {
        source_raw_objects: &source_raw_objects,
        ..GcGraph::default()
    };
    let objects = vec![object("obj:source-raw", 0)];
    let roots = collect_gc_roots(&graph, &policy(10_000), &objects);
    assert_eq!(
        reasons(&roots, "obj:source-raw"),
        vec![GcRootReason::SourceIndex]
    );
    let plan = plan_object_gc(&objects, &roots, &policy(10_000));
    assert!(
        plan.collect.is_empty(),
        "a source's raw body must survive GC"
    );
}

#[test]
fn the_grace_boundary_is_exclusive_at_the_window_size() {
    let grace: i64 = 1_000;
    for (stored_at, now, collectable, label) in [
        (1_000, 1_000, false, "age 0: just written"),
        (1_000, 1_999, false, "age grace-1: still in the window"),
        (1_000, 2_000, true, "age grace: window elapsed"),
        (1_000, 2_001, true, "age grace+1: clearly expired"),
    ] {
        let objects = vec![caly_storage::cas::CasObjectRef {
            digest: caly_storage::cas::ObjectDigest("obj:boundary".to_owned()),
            kind: ObjectKind::CompiledArtifact,
            size_bytes: Some(8),
            content_type: None,
            content_sha256: None,
            stored_at_unix_ms: Some(stored_at),
        }];
        let roots = collect_gc_roots(
            &GcGraph::default(),
            &GcPolicy {
                grace_period_ms: grace,
                now_unix_ms: now,
                max_deletions: 8,
            },
            &objects,
        );
        let plan = plan_object_gc(
            &objects,
            &roots,
            &GcPolicy {
                grace_period_ms: grace,
                now_unix_ms: now,
                max_deletions: 8,
            },
        );
        assert_eq!(
            plan.collect.is_empty(),
            !collectable,
            "{label}: collectable={collectable} but plan={plan:?}"
        );
    }
}
