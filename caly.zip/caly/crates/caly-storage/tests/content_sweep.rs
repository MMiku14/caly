//! The orphan content sweep: the half of `RFC-0007 §13` the metadata-keyed plan cannot see.
//!
//! The delete path removes metadata first and content second, so a crash between the two leaves
//! a content file no record names; the write path lands content before any metadata names it,
//! so a crash there does the same. Until the walk existed, no code in this workspace could see
//! those files (`docs/IMPLEMENTATION_STATUS.md §7` item 10) -- `list_objects` enumerates
//! *metadata*, and the content tree sits three levels deep while the port guarantees one-level
//! listing. A store that can only grow looked healthy from every existing surface.
//!
//! The properties here are the ones data loss is made of:
//!
//! * **Referenced content is never an orphan.** The sweep's one safety invariant: an anchor live
//!   metadata names is content, whatever its age. Pinned twice -- once in the pure plan, once at
//!   the store (`delete_content` refuses), because the two checks cover different windows.
//! * **Unknown age keeps.** Same rule as `collect_gc_roots`, same reason: silent deletion is
//!   unrecoverable, surviving one cycle is not.
//! * **Bounds bite from both sides.** The directory budget is measured at its edge, and the
//!   shared deletion budget is a remainder, not a second full allowance.

use std::collections::BTreeSet;

use caly_io::{block_on_ready, Durability, Fs, IoContext, VPath};
use caly_io_sim::{FaultInjector, MemFs, SharedFaults, SimClock, SimFs, VirtualClock};
use caly_storage::cas::{CasObjectRef, CasWriteIntent, ObjectDigest, ObjectKind};
use caly_storage::fs_store::{content_suffix_for, FsStore, MAX_CONTENT_WALK_DIRECTORIES};
use caly_storage::gc::{
    plan_orphan_content, sweep_orphan_content, ContentEntry, ContentTarget, GcPolicy,
};
use caly_storage::{InMemoryStorage, ObjectStore, StorageErrorKind};

const ROOT: &str = "var/caly";
const START: i64 = 1_700_000_000_000;
const GRACE_MS: i64 = 15 * 60 * 1000;

fn ctx() -> IoContext {
    IoContext::new(
        caly_io::TraceId::new("content-sweep"),
        caly_io::Actor::System,
    )
}

fn disk() -> SimFs {
    SimFs::new(MemFs::default(), SharedFaults::new(FaultInjector::new(1)))
}

fn clocked_disk(at_unix_ms: i64) -> (SimFs, SimClock) {
    let clock = SimClock::new(
        VirtualClock::new(at_unix_ms),
        SharedFaults::new(FaultInjector::new(1)),
    );
    let fs =
        SimFs::new(MemFs::default(), SharedFaults::new(FaultInjector::new(1))).with_clock(&clock);
    (fs, clock)
}

fn store_on(fs: SimFs) -> FsStore {
    FsStore::open(Box::new(fs) as Box<dyn Fs>, ROOT).expect("open")
}

fn object(digest: &str) -> CasObjectRef {
    CasObjectRef {
        digest: ObjectDigest(digest.to_owned()),
        kind: ObjectKind::RawSource,
        size_bytes: None,
        content_type: None,
        content_sha256: None,
        stored_at_unix_ms: None,
    }
}

fn put(store: &FsStore, digest: &str, payload: &[u8]) -> String {
    let written = block_on_ready(store.put(
        CasWriteIntent {
            object: object(digest),
            source_label: format!("{digest}.txt"),
            payload: payload.to_vec(),
            stored_at_unix_ms: 0,
        },
        &ctx(),
    ))
    .expect("no suspension")
    .expect("write");
    written
        .content_sha256
        .expect("the store records its anchor")
}

/// Place a content file on the disk exactly the way a crashed writer leaves it: bytes under the
/// digest path, and no metadata naming them. This is the sweep's reason to exist.
fn orphan_on_disk(fs: &SimFs, payload: &[u8]) -> String {
    let anchor = caly_common::digest::sha256_digest(payload);
    let path = VPath::try_from_str(&format!("{ROOT}/{}", content_suffix_for(&anchor)))
        .expect("relative path");
    block_on_ready(fs.write_atomic(&path, payload.to_vec(), Durability::D2, &ctx()))
        .expect("no suspension")
        .expect("write the orphan the way a crashed writer would");
    anchor
}

fn list_content(store: &FsStore, ctx: &IoContext) -> Vec<ContentEntry> {
    block_on_ready(store.list_content(ctx))
        .expect("no suspension")
        .expect("walk the content tree")
}

fn anchored(entries: &[ContentEntry]) -> Vec<String> {
    entries
        .iter()
        .filter_map(|entry| match &entry.target {
            ContentTarget::Anchor(anchor) => Some(anchor.clone()),
            ContentTarget::Residue { .. } => None,
        })
        .collect()
}

fn policy(now: i64) -> GcPolicy {
    GcPolicy {
        grace_period_ms: GRACE_MS,
        now_unix_ms: now,
        max_deletions: 256,
    }
}

fn entry(target: ContentTarget, at: Option<i64>) -> ContentEntry {
    ContentEntry {
        target,
        modified_at_unix_ms: at,
    }
}

// ---------------------------------------------------------------------------
// the walk: discovery
// ---------------------------------------------------------------------------

/// The one property the round exists for: a file the metadata does not name is *visible*, spelled
/// the way `content_sha256` spells it. If this fails, every other property below is vacuous.
#[test]
fn the_walk_sees_content_no_metadata_names() {
    let fs = disk();
    let store = store_on(fs.clone());
    let orphan = orphan_on_disk(&fs, b"bytes-from-a-crashed-delete");
    let listed = list_content(&store, &ctx());
    assert_eq!(
        anchored(&listed),
        vec![orphan],
        "an orphan must be reported under its digest, not hidden behind the metadata set"
    );
}

/// Age evidence comes from the port, never from a clock the walk holds: with the virtual clock at
/// `START`, a file written now is dated `START` -- the same discipline `ADR-035 §2.4` fixed for
/// object records, holding for files no record describes.
#[test]
fn the_walk_takes_its_dates_from_the_port() {
    let (fs, _clock) = clocked_disk(START);
    let store = store_on(fs.clone());
    let orphan = orphan_on_disk(&fs, b"dated-by-the-port");
    let listed = list_content(&store, &ctx());
    assert_eq!(anchored(&listed), vec![orphan.clone()]);
    assert_eq!(
        listed[0].modified_at_unix_ms,
        Some(START),
        "mtime is the only age evidence an orphan has, and it must be the port's"
    );
}

/// The leaf alphabet is exactly 60 hex characters -- 64 minus the four the layout spends on its
/// two prefix directories. A leaf of any other length is damage, not an anchor: a walk that
/// accepted `ff` would translate it into the deletable `sha256:abcdff`, a name no writer ever
/// produced. This is the review item round 32 left open, closed as a gate rather than a comment.
#[test]
fn a_leaf_of_the_wrong_hex_length_is_damage_not_an_anchor() {
    let fs = disk();
    let store = store_on(fs.clone());
    let path =
        VPath::try_from_str(&format!("{ROOT}/objects/sha256/ab/cd/ff")).expect("relative path");
    block_on_ready(fs.write_atomic(
        &path,
        b"not a content file".to_vec(),
        Durability::D2,
        &ctx(),
    ))
    .expect("no suspension")
    .expect("plant the misshapen leaf");
    let error = block_on_ready(store.list_content(&ctx()))
        .expect("no suspension")
        .expect_err("hex of the wrong length is not a leaf this layout explains");
    assert_eq!(
        error.kind,
        StorageErrorKind::IntegrityViolation,
        "{}",
        error.summary
    );
}

/// The same rule on the residue twin: `<stem>.tmp-<digits>` is debris only when the stem is a
/// full leaf. A shorter stem is somebody else's file wearing the suffix, and the walk refuses to
/// hand the sweep a deletable target for it.
#[test]
fn a_residue_whose_stem_is_not_a_full_leaf_is_damage() {
    let fs = disk();
    let store = store_on(fs.clone());
    let path = VPath::try_from_str(&format!(
        "{ROOT}/objects/sha256/ab/cd/{}.tmp-7",
        "cd".repeat(15)
    ))
    .expect("relative path");
    block_on_ready(fs.write_atomic(&path, b"half a name".to_vec(), Durability::D2, &ctx()))
        .expect("no suspension")
        .expect("plant the half-length stem");
    let error = block_on_ready(store.list_content(&ctx()))
        .expect("no suspension")
        .expect_err("a temp shape without a full leaf stem is not debris this layout explains");
    assert_eq!(
        error.kind,
        StorageErrorKind::IntegrityViolation,
        "{}",
        error.summary
    );
}

/// A clock-less world must not invent dates: unknown age is reported as `None`, and the plan reads
/// that as forever-in-grace. The walk that *fabricated* a date would be the dangerous half.
#[test]
fn a_clockless_walk_reports_unknown_age_as_none() {
    let fs = disk();
    let store = store_on(fs.clone());
    orphan_on_disk(&fs, b"undated");
    let listed = list_content(&store, &ctx());
    assert_eq!(
        listed[0].modified_at_unix_ms, None,
        "no clock, no date: the safe answer is 'cannot judge', not a guess"
    );
}

/// Residue -- `<hex>.tmp-<digits>` beside a content target -- is a crash leftover of the write
/// itself. `reap_residue` has always removed this shape in the one-level directories; three
/// levels down it was invisible until the walk.
#[test]
fn write_residue_is_discovered_as_its_own_kind() {
    let fs = disk();
    let store = store_on(fs.clone());
    orphan_on_disk(&fs, b"real content");
    let stem = "0f".repeat(30);
    let residue_path = VPath::try_from_str(&format!("{ROOT}/objects/sha256/0f/aa/{stem}.tmp-7"))
        .expect("relative path");
    block_on_ready(fs.write_atomic(
        &residue_path,
        b"half a write".to_vec(),
        Durability::D1,
        &ctx(),
    ))
    .expect("no suspension")
    .expect("place the residue a crashed write leaves");

    let expected = format!("{stem}.tmp-7");
    let listed = list_content(&store, &ctx());
    assert_eq!(listed.len(), 2, "both files are in the tree: {listed:?}");
    assert!(
        listed.iter().any(|found| matches!(
            &found.target,
            ContentTarget::Residue { p1, p2, name }
                if p1 == "0f" && p2 == "aa" && name.as_str() == expected
        )),
        "residue is named as residue, not mistaken for content: {listed:?}"
    );
}

/// A file the layout cannot explain is a refusal, never a silent skip: the sweep decides what may
/// be **deleted**, so a walk that quietly ignored half the tree would report "clean" over bytes it
/// never looked at. Each shape is damage a real disk can hold.
#[test]
fn unexplainable_files_refuse_the_whole_walk() {
    for (name, rel) in [
        ("not hex at the leaf", "objects/sha256/ab/cd/NOT-HEX"),
        (
            "a file where a prefix directory belongs",
            "objects/sha256/zz",
        ),
        ("a second algorithm directory", "objects/md5/ab"),
        ("uppercase hex prefix", "objects/sha256/AB/cd/ef12"),
    ] {
        let fs = disk();
        let store = store_on(fs.clone());
        orphan_on_disk(&fs, b"legit content");
        let path = VPath::try_from_str(&format!("{ROOT}/{rel}")).expect("relative path");
        block_on_ready(fs.write_atomic(&path, b"stray".to_vec(), Durability::D1, &ctx()))
            .expect("no suspension")
            .expect("place the unexplainable file");
        let error = block_on_ready(store.list_content(&ctx()))
            .expect("no suspension")
            .expect_err(name);
        assert_eq!(
            error.kind,
            StorageErrorKind::IntegrityViolation,
            "{name}: the walk refuses rather than skipping: {}",
            error.summary
        );
        assert!(
            error.summary.contains("content tree"),
            "{name}: the refusal must say where: {}",
            error.summary
        );
    }
}

/// The budget is measured from both sides, like every bound in this crate: four directories are
/// exactly what one content file needs (`objects`, `sha256`, one prefix, one leaf), so four passes
/// and three refuses. A budget that only ever passed would be decoration.
#[test]
fn the_directory_budget_is_measured_from_both_sides() {
    let (fs, _clock) = clocked_disk(START);
    orphan_on_disk(&fs, b"one file, four directories");

    let pass = caly_storage::fs_store::walk_content_tree(&fs, ROOT, &ctx(), None, 4)
        .expect("four directories is exactly what one content file needs");
    assert_eq!(pass.len(), 1);

    let error = caly_storage::fs_store::walk_content_tree(&fs, ROOT, &ctx(), None, 3)
        .expect_err("three directories cannot reach one content file");
    assert_eq!(
        error.kind,
        StorageErrorKind::CapacityExceeded,
        "an over-budget walk is a refusal, not a short list: {}",
        error.summary
    );
    assert!(
        error.summary.contains("(3)"),
        "the refusal names the budget that bit: {}",
        error.summary
    );
}

/// The production budget is large enough for a real store's fan-out -- a number nobody could
/// derive from this test alone, pinned so that changing it is a decision, not a typo.
#[test]
fn the_production_budget_can_hold_a_wide_tree() {
    // ab..az spread over prefixes: 1 (objects) + 1 (sha256) + 26 + 26 = 54 directories.
    let (fs, _clock) = clocked_disk(START);
    for index in 0..26u8 {
        let payload = vec![b'a' + index; 8];
        let anchor = caly_common::digest::sha256_digest(&payload);
        let suffix = content_suffix_for(&anchor);
        let path = VPath::try_from_str(&format!("{ROOT}/{suffix}")).expect("relative path");
        block_on_ready(fs.write_atomic(&path, payload, Durability::D2, &ctx()))
            .expect("no suspension")
            .expect("write");
    }
    let walked = caly_storage::fs_store::walk_content_tree(
        &fs,
        ROOT,
        &ctx(),
        None,
        MAX_CONTENT_WALK_DIRECTORIES,
    )
    .expect("26 files across 26 prefixes is far inside the production budget");
    assert_eq!(walked.len(), 26);
}

// ---------------------------------------------------------------------------
// the plan: what may be deleted
// ---------------------------------------------------------------------------

/// The safety invariant, in the pure half: an anchor live metadata names is content, not an
/// orphan, whatever its age. The sibling entry with the same age and no reference is collectable,
/// so the assertion cannot pass by refusing everything.
#[test]
fn referenced_content_is_never_orphaned_no_matter_how_old() {
    let referenced = "sha256:aa".to_owned();
    let set = BTreeSet::from([referenced.clone()]);
    let plan = plan_orphan_content(
        &[
            entry(ContentTarget::Anchor(referenced.clone()), Some(0)),
            entry(ContentTarget::Anchor("sha256:bb".to_owned()), Some(0)),
        ],
        &set,
        &policy(START + 10 * GRACE_MS),
        256,
    );
    assert_eq!(
        plan.collect,
        vec![ContentTarget::Anchor("sha256:bb".to_owned())],
        "only the unreferenced sibling may go"
    );
    assert_eq!(
        plan.skipped_for_grace, 0,
        "a referenced anchor is not 'kept by grace' -- grace had nothing to do with it"
    );
}

/// Grace from both edges: exactly `grace_period_ms` old is collectable (the boundary is
/// inclusive), one millisecond inside is not. Same convention as `collect_gc_roots`.
#[test]
fn grace_boundaries_hold_from_both_sides() {
    let now = START + GRACE_MS;
    let inside = plan_orphan_content(
        &[entry(
            ContentTarget::Anchor("sha256:aa".to_owned()),
            Some(now - GRACE_MS + 1),
        )],
        &BTreeSet::new(),
        &policy(now),
        256,
    );
    assert!(
        inside.collect.is_empty() && inside.skipped_for_grace == 1,
        "one millisecond inside the window keeps: {inside:?}"
    );

    let boundary = plan_orphan_content(
        &[entry(
            ContentTarget::Anchor("sha256:aa".to_owned()),
            Some(now - GRACE_MS),
        )],
        &BTreeSet::new(),
        &policy(now),
        256,
    );
    assert_eq!(
        boundary.collect,
        vec![ContentTarget::Anchor("sha256:aa".to_owned())],
        "exactly the grace period old is collectable: {boundary:?}"
    );
}

/// Unknown age is forever-in-grace. This is not the same assertion as the grace window: `None`
/// must not be read as zero, epoch, or "old enough".
#[test]
fn an_orphan_of_unknown_age_survives_every_cycle() {
    let plan = plan_orphan_content(
        &[entry(ContentTarget::Anchor("sha256:aa".to_owned()), None)],
        &BTreeSet::new(),
        &policy(START + 100 * GRACE_MS),
        256,
    );
    assert!(
        plan.collect.is_empty() && plan.skipped_for_grace == 1,
        "unknowable freshness is not a licence to delete: {plan:?}"
    );
}

/// Objects and content share one deletion budget: the orphan half receives the *remainder*, so a
/// cycle cannot remove double what its bound says. Beyond it, entries defer, visibly.
#[test]
fn the_deletion_budget_is_a_remainder_not_a_second_allowance() {
    let entries: Vec<ContentEntry> = (0..3)
        .map(|index| {
            entry(
                ContentTarget::Anchor(format!("sha256:{index:02x}")),
                Some(0),
            )
        })
        .collect();
    let plan = plan_orphan_content(&entries, &BTreeSet::new(), &policy(START + GRACE_MS), 2);
    assert_eq!(plan.collect.len(), 2, "the remainder bounds the sweep");
    assert_eq!(
        plan.deferred_over_cap, 1,
        "the third orphan defers where a later cycle can see it: {plan:?}"
    );
}

// ---------------------------------------------------------------------------
// the sweep: deletion, and its refusals
// ---------------------------------------------------------------------------

/// Delete an orphan and the walk agrees it is gone; a second delete answers `false` rather than
/// inventing work. The re-walk is the part that makes "deleted" a fact about the disk.
#[test]
fn deleting_an_orphan_makes_the_rewalk_agree() {
    let fs = disk();
    let store = store_on(fs.clone());
    let orphan = orphan_on_disk(&fs, b"the crash leftover");
    let target = ContentTarget::Anchor(orphan);

    let removed = block_on_ready(store.delete_content(&target, &ctx()))
        .expect("no suspension")
        .expect("delete");
    assert!(removed, "the orphan was there and is gone");
    assert!(
        list_content(&store, &ctx()).is_empty(),
        "the re-walk must agree the tree is empty"
    );
    let again = block_on_ready(store.delete_content(&target, &ctx()))
        .expect("no suspension")
        .expect("delete again");
    assert!(
        !again,
        "a second sweep of the same target is a no-op, not an error"
    );
}

/// Residue deletion goes through the same typed door, and the file it names really leaves.
#[test]
fn residue_deletion_removes_the_half_write() {
    let fs = disk();
    let store = store_on(fs.clone());
    let stem = "0f".repeat(30);
    let residue_path = VPath::try_from_str(&format!("{ROOT}/objects/sha256/0f/aa/{stem}.tmp-3"))
        .expect("relative path");
    block_on_ready(fs.write_atomic(&residue_path, b"half".to_vec(), Durability::D1, &ctx()))
        .expect("no suspension")
        .expect("place residue");

    let target = ContentTarget::Residue {
        p1: "0f".to_owned(),
        p2: "aa".to_owned(),
        name: format!("{stem}.tmp-3"),
    };
    assert!(block_on_ready(store.delete_content(&target, &ctx()))
        .expect("no suspension")
        .expect("delete residue"));
    assert!(
        list_content(&store, &ctx()).is_empty(),
        "the residue is gone from the tree"
    );
}

/// The store-side reference check: an anchor live metadata names is refused, with the object
/// still readable afterwards. This is the check that covers the window between plan and sweep --
/// removing it is mutation M5 in this round's harness.
#[test]
fn the_store_refuses_to_delete_content_metadata_still_names() {
    let fs = disk();
    let store = store_on(fs.clone());
    let anchor = put(&store, "obj:live", b"content somebody owns");

    let error =
        block_on_ready(store.delete_content(&ContentTarget::Anchor(anchor.clone()), &ctx()))
            .expect("no suspension")
            .expect_err("referenced content must be refused, not skipped");
    assert_eq!(
        error.kind,
        StorageErrorKind::IntegrityViolation,
        "{}",
        error.summary
    );
    assert!(
        error.summary.contains(&anchor),
        "the refusal names the anchor: {}",
        error.summary
    );
    assert!(
        block_on_ready(store.read_object("obj:live", 1 << 20, &ctx()))
            .expect("no suspension")
            .expect("read")
            .is_some(),
        "the object and its content must be intact after the refusal"
    );
}

/// A typed target that does not fit the layout is refused before any path is built: the sweep can
/// never be aimed at a file the store did not write, however the caller spells it.
#[test]
fn a_target_the_layout_cannot_explain_is_refused() {
    let fs = disk();
    let store = store_on(fs.clone());
    for target in [
        ContentTarget::Anchor("../escape".to_owned()),
        ContentTarget::Anchor("sha256:NOT-HEX".to_owned()),
        // Sixty-four characters that are not hex: the length gate passes this, the alphabet gate
        // is what refuses it -- two halves of "this tree only stores sha256", each with its input.
        ContentTarget::Anchor(format!("sha256:{}", "z".repeat(64))),
        ContentTarget::Anchor("no-prefix".to_owned()),
        // Too short for two prefix levels plus a remainder: building its suffix is how a double
        // slash became a path segment, so it is refused before any path exists.
        ContentTarget::Anchor("sha256:00".to_owned()),
        // Hex, but not 64 of it: this is exactly the misread a wrong-length leaf would produce
        // (`ab/cd/ff` translated as `sha256:abcdff`), refused at the deletion door too.
        ContentTarget::Anchor("sha256:abcdff".to_owned()),
        ContentTarget::Residue {
            p1: "../".to_owned(),
            p2: "aa".to_owned(),
            name: "0f.tmp-3".to_owned(),
        },
        ContentTarget::Residue {
            p1: "0f".to_owned(),
            p2: "aa".to_owned(),
            name: "not-a-temp.txt".to_owned(),
        },
        // A temp shape whose stem is not a full leaf: the suffix is right, the name under it is
        // not one this tree's writer could have produced.
        ContentTarget::Residue {
            p1: "0f".to_owned(),
            p2: "aa".to_owned(),
            name: format!("{}.tmp-3", "0f".repeat(15)),
        },
    ] {
        let error = block_on_ready(store.delete_content(&target, &ctx()))
            .expect("no suspension")
            .expect_err("unexplainable targets are refused");
        assert_eq!(
            error.kind,
            StorageErrorKind::IntegrityViolation,
            "{}",
            error.summary
        );
    }
}

/// End to end on the durable backend: plan over the walked entries, sweep the plan, and the disk
/// answers. One orphan is written half a grace period after the other, so at `now = START + grace`
/// the first is exactly at the collect boundary and the second is safely inside -- the same tree,
/// both answers, with ages that come from the port and nobody advancing a clock under the test.
#[test]
fn a_planned_sweep_takes_the_aged_out_and_leaves_the_fresh_in() {
    let (fs, clock) = clocked_disk(START);
    let store = store_on(fs.clone());
    let older = orphan_on_disk(&fs, b"the older crash leftover");
    clock
        .advance_ms((GRACE_MS / 2).try_into().expect("fits in u64"))
        .expect("advance virtual time");
    let fresher = orphan_on_disk(&fs, b"the fresher crash leftover");

    let entries = list_content(&store, &ctx());
    assert_eq!(entries.len(), 2, "both orphans are visible: {entries:?}");

    let now = START + GRACE_MS;
    let plan = plan_orphan_content(&entries, &BTreeSet::new(), &policy(now), 256);
    assert_eq!(
        plan.collect,
        vec![ContentTarget::Anchor(older.clone())],
        "only the aged-out orphan goes: {plan:?}"
    );
    assert_eq!(plan.skipped_for_grace, 1, "the fresher one waits: {plan:?}");

    let report =
        block_on_ready(sweep_orphan_content(&store, &plan.collect, &ctx())).expect("no suspension");
    assert_eq!(
        report.collected,
        vec![older],
        "the report names what it removed, in the operator spelling: {report:?}"
    );
    assert!(report.failed.is_empty());
    let remaining = list_content(&store, &ctx());
    assert_eq!(
        anchored(&remaining),
        vec![fresher],
        "only the kept orphan remains: {remaining:?}"
    );
}

// ---------------------------------------------------------------------------
// the other backend, and the default
// ---------------------------------------------------------------------------

/// `InMemoryStorage` mirrors the durable semantics through the same trait door: the walk sees
/// content no metadata names, deletion removes it, referenced content is refused, and residue --
/// a concept this backend never writes -- answers `false` rather than inventing a rule.
#[test]
fn the_in_memory_backend_answers_the_same_three_questions() {
    let store = InMemoryStorage::new();
    let anchor = block_on_ready(store.put(
        CasWriteIntent {
            object: object("obj:live"),
            source_label: "live.txt".to_owned(),
            payload: b"owned bytes".to_vec(),
            stored_at_unix_ms: 0,
        },
        &ctx(),
    ))
    .expect("no suspension")
    .expect("write")
    .content_sha256
    .expect("anchor");
    store.keep_orphan_content("sha256:dd", b"nobody owns these bytes");

    let listed = block_on_ready(store.list_content(&ctx()))
        .expect("no suspension")
        .expect("walk");
    // BTreeMap order: deterministic, like the durable backend's sorted walk.
    assert_eq!(
        anchored(&listed),
        {
            let mut both = vec![anchor.clone(), "sha256:dd".to_owned()];
            both.sort();
            both
        },
        "both files are reported, referenced and not: {listed:?}"
    );
    assert!(
        listed
            .iter()
            .all(|found| found.modified_at_unix_ms.is_none()),
        "no clock in this backend: unknown age, reported as such"
    );

    let error =
        block_on_ready(store.delete_content(&ContentTarget::Anchor(anchor.clone()), &ctx()))
            .expect("no suspension")
            .expect_err("referenced content is refused on this backend too");
    assert_eq!(error.kind, StorageErrorKind::IntegrityViolation);

    assert!(block_on_ready(
        store.delete_content(&ContentTarget::Anchor("sha256:dd".to_owned()), &ctx())
    )
    .expect("no suspension")
    .expect("delete the orphan"));
    let residue_removed = block_on_ready(store.delete_content(
        &ContentTarget::Residue {
            p1: "0f".to_owned(),
            p2: "aa".to_owned(),
            name: "0f.tmp-3".to_owned(),
        },
        &ctx(),
    ))
    .expect("no suspension")
    .expect("residue on a backend that never writes temps");
    assert!(
        !residue_removed,
        "no residue exists here; 'nothing was removed' is the honest answer"
    );
    let after = block_on_ready(store.list_content(&ctx()))
        .expect("no suspension")
        .expect("walk");
    assert_eq!(
        anchored(&after),
        vec![anchor],
        "the owned content is all that remains: {after:?}"
    );
}

/// Shared content on the in-memory backend: two objects written from one payload share one
/// content entry, so deleting one object must leave the other's bytes readable. The durable
/// backend has had this guard since round 5's shared-content test; the in-memory one could not
/// have it while content was keyed by object digest, and nothing asked -- which is exactly the
/// divergence `object_contract.rs` exists to catch, found here by giving the key a second reader.
#[test]
fn shared_content_survives_the_first_owner_deletion_in_memory_too() {
    let store = InMemoryStorage::new();
    let payload = b"one payload, two owners".to_vec();
    for digest in ["obj:keeps", "obj:drops"] {
        block_on_ready(store.put(
            CasWriteIntent {
                object: object(digest),
                source_label: format!("{digest}.txt"),
                payload: payload.clone(),
                stored_at_unix_ms: 0,
            },
            &ctx(),
        ))
        .expect("no suspension")
        .expect("write");
    }
    assert!(
        block_on_ready(store.delete("obj:drops", &ctx()))
            .expect("no suspension")
            .expect("delete one owner"),
        "the first deletion must succeed"
    );
    let bytes = block_on_ready(store.read_object("obj:keeps", 1 << 20, &ctx()))
        .expect("no suspension")
        .expect("read")
        .expect("the surviving object is readable, content included");
    assert_eq!(
        bytes, payload,
        "the shared bytes themselves, not a dangling anchor"
    );
    let meta = block_on_ready(store.get("obj:keeps", &ctx()))
        .expect("no suspension")
        .expect("get")
        .expect("the metadata half survived too");
    assert_eq!(
        meta.content_sha256,
        Some(caly_common::digest::sha256_digest(&payload)),
        "and it still names the same anchor"
    );
}

/// The trait default is `Unsupported`, not an empty walk: a backend that cannot see its own
/// content tree must not be able to look like a backend whose tree happens to be empty. This is
/// the answer the engine's plan reads as a gap.
#[test]
fn a_backend_that_cannot_walk_says_so_instead_of_answering_empty() {
    struct Bare;
    impl ObjectStore for Bare {
        fn put<'a>(
            &'a self,
            _intent: CasWriteIntent,
            _ctx: &'a IoContext,
        ) -> caly_storage::BoxFuture<'a, Result<CasObjectRef, caly_storage::StorageError>> {
            unimplemented_box("put")
        }
        fn get<'a>(
            &'a self,
            _digest: &'a str,
            _ctx: &'a IoContext,
        ) -> caly_storage::BoxFuture<'a, Result<Option<CasObjectRef>, caly_storage::StorageError>>
        {
            unimplemented_box("get")
        }
        fn materialize<'a>(
            &'a self,
            _request: caly_storage::cas::MaterializationRequest,
            _ctx: &'a IoContext,
        ) -> caly_storage::BoxFuture<'a, Result<(), caly_storage::StorageError>> {
            unimplemented_box("materialize")
        }
        fn list_objects<'a>(
            &'a self,
            _ctx: &'a IoContext,
        ) -> caly_storage::BoxFuture<'a, Result<Vec<CasObjectRef>, caly_storage::StorageError>>
        {
            unimplemented_box("list_objects")
        }
        fn delete<'a>(
            &'a self,
            _digest: &'a str,
            _ctx: &'a IoContext,
        ) -> caly_storage::BoxFuture<'a, Result<bool, caly_storage::StorageError>> {
            unimplemented_box("delete")
        }
    }
    fn unimplemented_box<T>(
        what: &'static str,
    ) -> caly_storage::BoxFuture<'static, Result<T, caly_storage::StorageError>> {
        Box::pin(async move {
            Err(caly_storage::StorageError::new(
                StorageErrorKind::Internal,
                format!("{what} is not the question this stub answers"),
            ))
        })
    }

    let walk = block_on_ready(Bare.list_content(&ctx()))
        .expect("no suspension")
        .expect_err("the default must refuse");
    assert_eq!(walk.kind, StorageErrorKind::Unsupported);
    assert!(
        walk.summary.contains("content tree"),
        "the refusal says which capability is missing: {}",
        walk.summary
    );
    let drop =
        block_on_ready(Bare.delete_content(&ContentTarget::Anchor("sha256:aa".to_owned()), &ctx()))
            .expect("no suspension")
            .expect_err("the default must refuse");
    assert_eq!(drop.kind, StorageErrorKind::Unsupported);
}

// ---------------------------------------------------------------------------
// ADR-039: the caller's context at the store seam
// ---------------------------------------------------------------------------

/// A probe between the store and the port: every method delegates, and `list` calls back first.
/// Round 33's two port-level questions both need it -- "whose trace does the port see" (the store
/// used to fabricate one identity at open time and attribute every call to it) and "does the walk
/// notice a cancellation that arrives after it started".
struct ProbeFs {
    inner: Box<dyn caly_io::Fs>,
    on_list: Box<dyn Fn(&IoContext) + Send + Sync>,
}

impl caly_io::Fs for ProbeFs {
    fn read<'a>(
        &'a self,
        path: &'a VPath,
        cap: caly_io::ByteCap,
        ctx: &'a IoContext,
    ) -> caly_io::BoxFuture<'a, Result<caly_io::Bytes, caly_io::IoFault>> {
        self.inner.read(path, cap, ctx)
    }
    fn open_stream<'a>(
        &'a self,
        path: &'a VPath,
        ctx: &'a IoContext,
    ) -> caly_io::BoxFuture<'a, Result<caly_io::ByteStream, caly_io::IoFault>> {
        self.inner.open_stream(path, ctx)
    }
    fn write_atomic<'a>(
        &'a self,
        path: &'a VPath,
        data: caly_io::Bytes,
        durability: Durability,
        ctx: &'a IoContext,
    ) -> caly_io::BoxFuture<'a, Result<(), caly_io::IoFault>> {
        self.inner.write_atomic(path, data, durability, ctx)
    }
    fn rename<'a>(
        &'a self,
        from: &'a VPath,
        to: &'a VPath,
        durability: Durability,
        ctx: &'a IoContext,
    ) -> caly_io::BoxFuture<'a, Result<(), caly_io::IoFault>> {
        self.inner.rename(from, to, durability, ctx)
    }
    fn remove<'a>(
        &'a self,
        path: &'a VPath,
        ctx: &'a IoContext,
    ) -> caly_io::BoxFuture<'a, Result<(), caly_io::IoFault>> {
        self.inner.remove(path, ctx)
    }
    fn stat<'a>(
        &'a self,
        path: &'a VPath,
        ctx: &'a IoContext,
    ) -> caly_io::BoxFuture<'a, Result<Option<caly_io::Meta>, caly_io::IoFault>> {
        self.inner.stat(path, ctx)
    }
    fn link_or_copy<'a>(
        &'a self,
        from: &'a VPath,
        to: &'a VPath,
        ctx: &'a IoContext,
    ) -> caly_io::BoxFuture<'a, Result<caly_io::LinkKind, caly_io::IoFault>> {
        self.inner.link_or_copy(from, to, ctx)
    }
    fn lock_exclusive<'a>(
        &'a self,
        path: &'a VPath,
        ctx: &'a IoContext,
    ) -> caly_io::BoxFuture<'a, Result<caly_io::FileLock, caly_io::IoFault>> {
        self.inner.lock_exclusive(path, ctx)
    }
    fn list<'a>(
        &'a self,
        dir: &'a VPath,
        cap: caly_io::ListCap,
        ctx: &'a IoContext,
    ) -> caly_io::BoxFuture<'a, Result<Vec<VPath>, caly_io::IoFault>> {
        (self.on_list)(ctx);
        self.inner.list(dir, cap, ctx)
    }
}

/// The store once fabricated one `IoContext` at open time and attributed every port call to it:
/// the caller's identity died at the engine boundary, and the port answered every caller as the
/// same ghost (`ADR-039 §1`). The walk is where that becomes visible, so it is where the property
/// is pinned: during a store method, the port sees that method's caller.
#[test]
fn the_port_sees_the_callers_trace_not_a_fabricated_ghost() {
    let fs = disk();
    let orphan = orphan_on_disk(&fs, b"attributed-to-the-caller");
    let seen: std::sync::Arc<std::sync::Mutex<Vec<String>>> = std::sync::Arc::default();
    let recorder = std::sync::Arc::clone(&seen);
    let store = FsStore::open(
        Box::new(ProbeFs {
            inner: Box::new(fs),
            on_list: Box::new(move |ctx| {
                recorder
                    .lock()
                    .expect("probe lock")
                    .push(ctx.trace_id.0.clone());
            }),
        }),
        ROOT,
    )
    .expect("open");
    // Open-time work is store-originated and carries its own label; that is honest and not the
    // question here. The question is what the port sees *during* a store method.
    seen.lock().expect("probe lock").clear();
    let caller = IoContext::new(
        caly_io::TraceId::new("the-walkers-own-trace"),
        caly_io::Actor::System,
    );
    let listed = list_content(&store, &caller);
    assert_eq!(
        anchored(&listed),
        vec![orphan],
        "the probe must not change what the walk finds"
    );
    let traces = seen.lock().expect("probe lock");
    assert!(
        !traces.is_empty(),
        "the walk must have asked the port something"
    );
    assert!(
        traces.iter().all(|trace| trace == "the-walkers-own-trace"),
        "every port call during the walk must carry the caller's trace, got {traces:?}"
    );
}

/// A cancellation that arrives *after* the walk started: the up-front check has already passed,
/// so what stops the descent is the between-levels gate -- budget and cancellation are spent at
/// the same gate, on purpose (`ADR-039 §2.3`).
#[test]
fn a_cancellation_that_arrives_mid_walk_stops_the_next_level() {
    let fs = disk();
    orphan_on_disk(&fs, b"cancelled-mid-walk");
    let token = caly_common::CancelToken::new();
    let tripped = std::sync::atomic::AtomicBool::new(false);
    let canceler = token.clone();
    let store = FsStore::open(
        Box::new(ProbeFs {
            inner: Box::new(fs),
            on_list: Box::new(move |_| {
                // Fire once, on the walk's first port call: after the up-front check,
                // before the next level's spend.
                if !tripped.swap(true, std::sync::atomic::Ordering::SeqCst) {
                    canceler.cancel();
                }
            }),
        }),
        ROOT,
    )
    .expect("open");
    let mut caller = ctx();
    caller.cancel = token;
    let error = block_on_ready(store.list_content(&caller))
        .expect("no suspension")
        .expect_err("a cancelled caller must not get a full walk");
    assert_eq!(error.kind, StorageErrorKind::Cancelled, "{}", error.summary);
}
