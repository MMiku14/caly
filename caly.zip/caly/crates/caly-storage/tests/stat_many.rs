//! The `stat_many` adoption judges (`ADR-054` §2.3): `FsStore::object_records` must date a
//! whole directory of object records with **one** `stat_many` port call, not N `stat`s —
//! and the batch must be **behaviorally identical** to the one-by-one reads it replaces
//! (`ADR-035 §6bis-quater` registered this as the chain's next step).
//!
//! The counting is done by a wrapper adapter: it delegates every `Fs` call to a `SimFs` and
//! counts `stat` / `stat_many`. That keeps the judge out of the storage internals — the
//! store only sees a `Box<dyn Fs>`.

use std::sync::atomic::{AtomicUsize, Ordering};
use std::sync::Arc;

use caly_io::{
    block_on_ready, BoxFuture, ByteCap, ByteStream, Bytes, Durability, FileLock, Fs, IoContext,
    IoFault, LinkKind, ListCap, Meta, VPath,
};
use caly_io_sim::{MemFs, SimClock, SimFs, VirtualClock};
use caly_storage::cas::{CasObjectRef, CasWriteIntent, ObjectDigest, ObjectKind};
use caly_storage::{FsStore, ObjectStore};

const ROOT: &str = "var/caly";

/// Counts the two calls this round is about, delegates everything else.
struct CountingFs {
    inner: SimFs,
    stat_calls: Arc<AtomicUsize>,
    stat_many_calls: Arc<AtomicUsize>,
}

impl CountingFs {
    fn new(inner: SimFs) -> (Self, Arc<AtomicUsize>, Arc<AtomicUsize>) {
        let stat_calls = Arc::new(AtomicUsize::new(0));
        let stat_many_calls = Arc::new(AtomicUsize::new(0));
        (
            Self {
                inner,
                stat_calls: Arc::clone(&stat_calls),
                stat_many_calls: Arc::clone(&stat_many_calls),
            },
            stat_calls,
            stat_many_calls,
        )
    }
}

impl Fs for CountingFs {
    fn read<'a>(
        &'a self,
        path: &'a VPath,
        cap: ByteCap,
        ctx: &'a IoContext,
    ) -> BoxFuture<'a, Result<Bytes, IoFault>> {
        self.inner.read(path, cap, ctx)
    }
    fn open_stream<'a>(
        &'a self,
        path: &'a VPath,
        ctx: &'a IoContext,
    ) -> BoxFuture<'a, Result<ByteStream, IoFault>> {
        self.inner.open_stream(path, ctx)
    }
    fn write_atomic<'a>(
        &'a self,
        path: &'a VPath,
        data: Bytes,
        durability: Durability,
        ctx: &'a IoContext,
    ) -> BoxFuture<'a, Result<(), IoFault>> {
        self.inner.write_atomic(path, data, durability, ctx)
    }
    fn rename<'a>(
        &'a self,
        from: &'a VPath,
        to: &'a VPath,
        durability: Durability,
        ctx: &'a IoContext,
    ) -> BoxFuture<'a, Result<(), IoFault>> {
        self.inner.rename(from, to, durability, ctx)
    }
    fn remove<'a>(
        &'a self,
        path: &'a VPath,
        ctx: &'a IoContext,
    ) -> BoxFuture<'a, Result<(), IoFault>> {
        self.inner.remove(path, ctx)
    }
    fn stat<'a>(
        &'a self,
        path: &'a VPath,
        ctx: &'a IoContext,
    ) -> BoxFuture<'a, Result<Option<Meta>, IoFault>> {
        self.stat_calls.fetch_add(1, Ordering::Relaxed);
        self.inner.stat(path, ctx)
    }
    fn stat_many<'a>(
        &'a self,
        paths: &'a [VPath],
        ctx: &'a IoContext,
    ) -> BoxFuture<'a, Result<Vec<Option<Meta>>, IoFault>> {
        self.stat_many_calls.fetch_add(1, Ordering::Relaxed);
        self.inner.stat_many(paths, ctx)
    }
    fn link_or_copy<'a>(
        &'a self,
        from: &'a VPath,
        to: &'a VPath,
        ctx: &'a IoContext,
    ) -> BoxFuture<'a, Result<LinkKind, IoFault>> {
        self.inner.link_or_copy(from, to, ctx)
    }
    fn lock_exclusive<'a>(
        &'a self,
        path: &'a VPath,
        ctx: &'a IoContext,
    ) -> BoxFuture<'a, Result<FileLock, IoFault>> {
        self.inner.lock_exclusive(path, ctx)
    }
    fn list<'a>(
        &'a self,
        dir: &'a VPath,
        cap: ListCap,
        ctx: &'a IoContext,
    ) -> BoxFuture<'a, Result<Vec<VPath>, IoFault>> {
        self.inner.list(dir, cap, ctx)
    }
}

fn ctx() -> IoContext {
    IoContext::new(
        caly_io::TraceId::new("stat-many-judge"),
        caly_io::Actor::System,
    )
}

fn clocked_store(at_unix_ms: i64) -> (FsStore, Arc<AtomicUsize>, Arc<AtomicUsize>) {
    let clock = SimClock::new(
        VirtualClock::new(at_unix_ms),
        caly_io_sim::SharedFaults::new(caly_io_sim::FaultInjector::new(1)),
    );
    let fs = SimFs::new(
        MemFs::default(),
        caly_io_sim::SharedFaults::new(caly_io_sim::FaultInjector::new(1)),
    )
    .with_clock(&clock);
    let (counting, stat_calls, stat_many_calls) = CountingFs::new(fs);
    let store = FsStore::open(Box::new(counting) as Box<dyn Fs>, ROOT).expect("open store");
    (store, stat_calls, stat_many_calls)
}

fn object(digest: &str, claim_ms: i64) -> CasObjectRef {
    CasObjectRef {
        digest: ObjectDigest(digest.to_owned()),
        kind: ObjectKind::RawSource,
        size_bytes: None,
        content_type: None,
        content_sha256: None,
        stored_at_unix_ms: Some(claim_ms),
    }
}

fn write_object(store: &FsStore, digest: &str, claim_ms: i64, payload: &[u8]) {
    let written = block_on_ready(store.put(
        CasWriteIntent {
            object: object(digest, claim_ms),
            source_label: format!("{digest}.txt"),
            payload: payload.to_vec(),
            stored_at_unix_ms: claim_ms,
        },
        &ctx(),
    ))
    .expect("no suspension")
    .expect("write");
    assert_eq!(
        written
            .content_sha256
            .as_deref()
            .expect("the store records its anchor"),
        caly_common::digest::sha256_digest(payload),
        "the integrity anchor is the payload's own digest"
    );
}

/// `ADR-054 §2.3`: enumerating object records pays **one** `stat_many` and zero `stat`s —
/// the caller must not pay per-record round trips for facts the batch answers once.
#[test]
fn object_records_dates_its_whole_directory_with_one_stat_many() {
    let (store, stat_calls, stat_many_calls) = clocked_store(1_000_000);
    write_object(&store, "obj:a", 500, b"alpha");
    write_object(&store, "obj:b", 1_500, b"beta");

    stat_calls.store(0, Ordering::Relaxed);
    stat_many_calls.store(0, Ordering::Relaxed);

    let records = block_on_ready(store.list_objects(&ctx()))
        .expect("no suspension")
        .expect("enumerate");
    assert_eq!(records.len(), 2, "both objects are on the disk");
    assert_eq!(
        stat_many_calls.load(Ordering::Relaxed),
        1,
        "one directory of records is dated by one stat_many port call"
    );
    assert_eq!(
        stat_calls.load(Ordering::Relaxed),
        0,
        "the batch must not fall back to per-record stat calls"
    );

    // The ages follow the ADR-035 whichever-is-newer rule with the port's evidence in the
    // clocked world (mtime = now = 1_000_000).
    let mut by_digest: Vec<&CasObjectRef> = records.iter().collect();
    by_digest.sort_by(|l, r| l.digest.0.cmp(&r.digest.0));
    assert_eq!(by_digest[0].digest.0, "obj:a");
    assert_eq!(
        by_digest[0].stored_at_unix_ms,
        Some(1_000_000),
        "claim 500 < mtime"
    );
    assert_eq!(by_digest[1].digest.0, "obj:b");
    assert_eq!(
        by_digest[1].stored_at_unix_ms,
        Some(1_000_000),
        "claim 1500 > mtime keeps the claim"
    );
}

/// `ADR-054 §2.1`: the batched enumeration is behaviorally identical to the one-by-one reads
/// it replaced — every record the batch returns is dated exactly as a single `get` on the
/// same store would date it.
#[test]
fn object_records_batch_matches_individual_reads() {
    let (store, ..) = clocked_store(2_000_000);
    write_object(&store, "obj:x", 500, b"alpha");
    write_object(&store, "obj:y", 3_000_000, b"beta");

    let records = block_on_ready(store.list_objects(&ctx()))
        .expect("no suspension")
        .expect("enumerate");
    assert_eq!(records.len(), 2);
    for record in &records {
        let single = block_on_ready(store.get(&record.digest.0, &ctx()))
            .expect("no suspension")
            .expect("read")
            .expect("the record we just enumerated is readable");
        assert_eq!(
            single.stored_at_unix_ms, record.stored_at_unix_ms,
            "a record's age must not depend on whether it was read in a batch or alone: {}",
            record.digest.0
        );
    }
    let mut by_digest: Vec<&CasObjectRef> = records.iter().collect();
    by_digest.sort_by(|l, r| l.digest.0.cmp(&r.digest.0));
    assert_eq!(
        by_digest[0].stored_at_unix_ms,
        Some(2_000_000),
        "claim 500 < mtime"
    );
    assert_eq!(
        by_digest[1].stored_at_unix_ms,
        Some(3_000_000),
        "claim 3M > mtime 2M keeps the newer claim"
    );
}
