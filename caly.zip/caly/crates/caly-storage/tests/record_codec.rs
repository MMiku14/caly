//! The on-disk record codec.
//!
//! The format is the store's contract with its own past: a file written by one build must be
//! readable by the next after a crash. These tests pin the round-trip, and more importantly the
//! rejection paths — a decoder that accepts a v2 file as if it were v1 is how a recovery scan
//! ends up reporting "clean" about a deployment it only partially understood.

use caly_storage::cas::{CasObjectRef, CasWriteIntent, ObjectDigest, ObjectKind};
use caly_storage::execution::{ApplyJournalRecord, ApplyJournalState, ApplyPhase, ApplyTxnId};
use caly_storage::fs_store::content_suffix_for as content_suffix_probe;
use caly_storage::journal::{JournalAction, JournalRecord, JournalRecordId, JournalState};
use caly_storage::record::{
    decode_and_check, decode_apply_journal, decode_object, decode_os_journal, decode_revision,
    decode_snapshot, decode_source_index, encode_apply_journal, encode_object, encode_os_journal,
    encode_revision, encode_snapshot, encode_source_index, Record, RECORD_TAG_V1,
};
use caly_storage::revision::{RevisionId, RevisionNumber, RevisionRecord};
use caly_storage::snapshot::{SnapshotRecord, SnapshotRecordId};
use caly_storage::source::SourceIndexRecord;

fn object() -> CasObjectRef {
    CasObjectRef {
        digest: ObjectDigest("mihomo:657b42af62d91e30".to_owned()),
        kind: ObjectKind::CompiledArtifact,
        size_bytes: Some(1430),
        content_type: Some("application/x-yaml".to_owned()),
        content_sha256: Some("sha256:aaaa".to_owned()),
        // A real value, so the round-trip below actually exercises the grace-period field.
        stored_at_unix_ms: Some(1_700_000_000_042),
    }
}

fn revision() -> RevisionRecord {
    RevisionRecord {
        id: RevisionId("rev:0123abcd".to_owned()),
        number: RevisionNumber(7),
        profile_id: "demo-tun-profile".to_owned(),
        semantic_digest: "sem:9911".to_owned(),
        created_at_unix_ms: 1_700_000_000_000,
    }
}

fn snapshot() -> SnapshotRecord {
    SnapshotRecord {
        id: SnapshotRecordId("snapshot:rev:0123abcd".to_owned()),
        revision_id: RevisionId("rev:0123abcd".to_owned()),
        revision_number: RevisionNumber(7),
        profile_id: "demo-tun-profile".to_owned(),
        semantic_digest: "sem:9911".to_owned(),
        compiled_artifact_digest: "mihomo:657b42af62d91e30".to_owned(),
        core_binary_digest: "mihomo-skeleton-binary".to_owned(),
        core_identity: "mihomo@0.1".to_owned(),
        apply_plan_summary: "Restart".to_owned(),
        journal_id: Some(JournalRecordId("journal:txn:rev:0123abcd".to_owned())),
        selection_memory_digest: Some("sel:1234".to_owned()),
        validation_summary: "MIHOMO_NATIVE_VALIDATE:validated | ".to_owned(),
        created_at_unix_ms: 1_700_000_000_500,
        is_last_known_good: true,
    }
}

fn source_index() -> SourceIndexRecord {
    let normalized_cache = "normalized-cache:v1".to_owned();
    let parser_provenance = "provenance:v1".to_owned();
    let diagnostics = "diagnostics:v1".to_owned();
    SourceIndexRecord {
        source_id: "source:fixture".to_owned(),
        source_kind: "subscription".to_owned(),
        label: "fixture".to_owned(),
        locator: "https://fixture.invalid/feed".to_owned(),
        route: "direct".to_owned(),
        max_body_bytes: 4096,
        media_type: Some("text/plain".to_owned()),
        strict_mode: false,
        etag: Some("\"v1\"".to_owned()),
        last_modified: Some("Sat, 03 Aug 2026 00:00:00 GMT".to_owned()),
        raw_object_digest: caly_common::digest::sha256_digest(b"raw-body"),
        raw_content_sha256: caly_common::digest::sha256_digest(b"raw-body"),
        raw_bytes_len: 8,
        raw_stored_at_unix_ms: Some(42),
        normalized_digest: caly_common::digest::sha256_digest(normalized_cache.as_bytes()),
        normalized_cache,
        provenance_digest: caly_common::digest::sha256_digest(parser_provenance.as_bytes()),
        parser_provenance,
        diagnostics_digest: caly_common::digest::sha256_digest(diagnostics.as_bytes()),
        diagnostics,
        updated_at_unix_ms: 43,
    }
}

fn apply_journal() -> ApplyJournalRecord {
    ApplyJournalRecord {
        journal_id: JournalRecordId("journal:txn-1".to_owned()),
        apply_txn_id: ApplyTxnId("txn-1".to_owned()),
        trace_id: "trace-1".to_owned(),
        job_id: Some("job-9".to_owned()),
        profile_id: "demo-tun-profile".to_owned(),
        revision_id: RevisionId("rev:0123abcd".to_owned()),
        semantic_digest: "sem:9911".to_owned(),
        compiled_artifact_digest: "mihomo:657b42af62d91e30".to_owned(),
        core_identity: "mihomo@0.1".to_owned(),
        effect_plan_id: "mihomo-effect-plan".to_owned(),
        current_phase: ApplyPhase::Cutover,
        current_step_index: 4,
        net_effect_started: true,
        core_cutover_started: true,
        previous_snapshot_id: Some(SnapshotRecordId("snapshot:prev".to_owned())),
        created_at_unix_ms: 0,
        updated_at_unix_ms: 3,
        state: ApplyJournalState::Pending,
    }
}

#[test]
fn every_record_kind_round_trips() {
    let object_text = encode_object(&object());
    assert_eq!(
        decode_and_check(&object_text, "object", decode_object).expect("object decodes"),
        object()
    );

    let revision_text = encode_revision(&revision());
    assert_eq!(
        decode_and_check(&revision_text, "revision", decode_revision).expect("revision decodes"),
        revision()
    );

    let snapshot_text = encode_snapshot(&snapshot());
    assert_eq!(
        decode_and_check(&snapshot_text, "snapshot", decode_snapshot).expect("snapshot decodes"),
        snapshot()
    );

    let journal_text = encode_apply_journal(&apply_journal());
    assert_eq!(
        decode_and_check(&journal_text, "apply-journal", decode_apply_journal)
            .expect("apply journal decodes"),
        apply_journal()
    );
}

#[test]
fn source_index_round_trips_its_atomic_cache_and_validator_envelope() {
    let source = source_index();
    let text = caly_storage::record::encode_source_index(&source);
    assert_eq!(
        caly_storage::record::decode_and_check(
            &text,
            "source-index",
            caly_storage::record::decode_source_index,
        )
        .expect("source index decodes"),
        source
    );
}

#[test]
fn os_journal_preserves_action_order_and_variants() {
    let record = JournalRecord {
        id: JournalRecordId("osj-1".to_owned()),
        state: JournalState::Pending,
        actions: vec![
            JournalAction::UpTun {
                device: "utun7".to_owned(),
            },
            JournalAction::SetSystemProxy {
                value: "127.0.0.1:7890".to_owned(),
            },
            JournalAction::ApplyRoute {
                summary: "route 198.18.0.0/15 via utun7".to_owned(),
            },
            JournalAction::RestoreDns,
        ],
        created_at_unix_ms: 1,
        updated_at_unix_ms: 2,
    };
    let text = encode_os_journal(&record);
    let decoded =
        decode_and_check(&text, "os-journal", decode_os_journal).expect("os journal decodes");
    assert_eq!(
        decoded, record,
        "actions must survive in order, including the valueless ones"
    );
    assert_eq!(
        text.lines()
            .filter(|line| line.starts_with("action="))
            .count(),
        4
    );
}

#[test]
fn values_containing_equals_newlines_and_backslashes_survive() {
    let mut record = snapshot();
    record.validation_summary = "line one\nsecond = with equals\\backslash\r\nthird".to_owned();
    let decoded = decode_and_check(&encode_snapshot(&record), "snapshot", decode_snapshot)
        .expect("escapes round-trip");
    assert_eq!(decoded.validation_summary, record.validation_summary);
}

#[test]
fn an_unknown_record_version_is_rejected_not_half_read() {
    let text = encode_revision(&revision()).replacen(RECORD_TAG_V1, "record:v2", 1);
    let error = decode_and_check(&text, "revision", decode_revision)
        .expect_err("a newer format must not be read as v1");
    assert!(error.contains("unsupported record tag"), "{error}");
}

#[test]
fn an_unknown_field_is_rejected() {
    let text = format!("{}\nextra_field=surprise\n", encode_revision(&revision()));
    let error =
        decode_and_check(&text, "revision", decode_revision).expect_err("unknown fields must fail");
    assert!(error.contains("does not understand"), "{error}");
}

#[test]
fn a_missing_required_field_is_reported_by_name() {
    let without_digest = encode_object(&object())
        .lines()
        .filter(|line| !line.starts_with("digest="))
        .collect::<Vec<_>>()
        .join("\n")
        + "\n";
    let error =
        decode_and_check(&without_digest, "object", decode_object).expect_err("digest is required");
    assert!(error.contains("\"digest\""), "{error}");
}

#[test]
fn a_malformed_value_is_reported_not_defaulted() {
    let corrupt = encode_revision(&revision()).replace("number=7", "number=seventeen");
    let error = decode_and_check(&corrupt, "revision", decode_revision)
        .expect_err("an int field must parse");
    assert!(error.contains("not an integer"), "{error}");

    let bad_enum = encode_object(&object()).replace("kind=compiled-artifact", "kind=waffle");
    let error = decode_and_check(&bad_enum, "object", decode_object).expect_err("enum must parse");
    assert!(error.contains("unrecognised value"), "{error}");

    let dangling = format!("{}\nprofile_id=trailing\\\n", RECORD_TAG_V1);
    let error = Record::decode(&dangling).expect_err("a dangling escape is malformed");
    assert!(
        error.summary.contains("dangling backslash"),
        "{}",
        error.summary
    );
}

#[test]
fn an_empty_file_is_not_a_valid_record() {
    let error = Record::decode("").expect_err("empty input must fail");
    assert!(error.summary.contains("empty record"), "{}", error.summary);
}

/// `RFC-0007 §6.1` fixes the layout, so the sharding is part of the contract, not an detail.
#[test]
fn object_content_paths_follow_the_documented_layout() {
    assert_eq!(
        content_suffix_probe("sha256:e3b0c44298fc1c14"),
        "objects/sha256/e3/b0/c44298fc1c14"
    );
    assert_eq!(
        content_suffix_probe("deadbeef"),
        "objects/sha256/de/ad/beef",
        "a bare hex digest is accepted as well"
    );
    let short = content_suffix_probe("sha256:ab");
    assert!(short.starts_with("objects/sha256/ab/"), "{short}");
}

#[test]
fn metadata_only_intents_encode_and_decode() {
    let mut meta = object();
    meta.content_sha256 = None;
    meta.size_bytes = None;
    meta.content_type = None;
    let intent = CasWriteIntent::metadata(meta.clone(), "external-blob");
    assert!(intent.payload.is_empty());
    assert_eq!(
        decode_and_check(&encode_object(&meta), "object", decode_object).expect("decodes"),
        meta
    );
}

/// Replace the value of exactly one `key=` line, asserting the line exists. A source-index
/// record has exactly one line per scalar field, and the whole table is regenerated per arm, so
/// a single `replacen` on the line text is an exact-anchor edit rather than a regex guess.
fn tamper_field(text: &str, field: &str, value: &str) -> String {
    let prefix = format!("{field}=");
    let line = text
        .lines()
        .find(|line| line.starts_with(&prefix))
        .unwrap_or_else(|| panic!("encoded source index carries {field}"));
    text.replacen(line, &format!("{prefix}{value}"), 1)
}

/// The three opaque cache fields are the storage crate's only lever against a silently altered
/// normalized source: each is hashed at publish and re-checked here before the record is
/// accepted, so a tampered field must be refused **by that field's name** — an anchor mismatch
/// read as "corrupt, but which part?" is exactly the diagnosis a restart should not have to make.
#[test]
fn source_index_rejects_cache_fields_detached_from_their_anchors() {
    for (field, tampered) in [
        ("normalized_cache", "tampered-cache"),
        ("parser_provenance", "tampered-provenance"),
        ("diagnostics", "tampered-diagnostics"),
    ] {
        let text = encode_source_index(&source_index());
        let edited = tamper_field(&text, field, tampered);
        let error = decode_and_check(&edited, "source-index", decode_source_index)
            .expect_err("a cache field detached from its anchor must be refused");
        assert!(
            error.contains(&format!(
                "source index {field} does not match its content anchor"
            )),
            "{field}: {error}"
        );
    }
}

#[test]
fn source_index_rejects_a_raw_anchor_that_is_not_sha256() {
    for (label, bad) in [
        ("short hex", "sha256:zz"),
        ("missing prefix", "not-an-anchor"),
        ("empty hex", "sha256:"),
    ] {
        let source = source_index();
        let text = encode_source_index(&source);
        let edited = tamper_field(&text, "raw_content_sha256", bad);
        let error = decode_and_check(&edited, "source-index", decode_source_index)
            .expect_err("an anchor a writer could not have produced must be refused");
        assert!(
            error.contains("source index raw_content_sha256 is not a sha256 anchor"),
            "{label}: {error}"
        );
    }
}

#[test]
fn source_index_rejects_a_raw_object_digest_that_is_not_a_sha256_anchor() {
    // `raw_object_digest` is the CAS object anchor the worker later uses to *address* the raw
    // body (`storage.get(record.raw_object_digest)`), so a record carrying an anchor a writer
    // could not have produced must be refused by name — the same rule `raw_content_sha256`
    // already follows. Before round 75 this field was only checked for emptiness: the fixture
    // itself carried `sha256:raw-object`, which is not a sha256 anchor.
    for (label, bad) in [
        ("short hex", "sha256:zz"),
        ("missing prefix", "not-an-anchor"),
        ("empty hex", "sha256:"),
    ] {
        let source = source_index();
        let text = encode_source_index(&source);
        let edited = tamper_field(&text, "raw_object_digest", bad);
        let error = decode_and_check(&edited, "source-index", decode_source_index)
            .expect_err("an object anchor a writer could not have produced must be refused");
        assert!(
            error.contains("source index raw_object_digest is not a sha256 anchor"),
            "{label}: {error}"
        );
    }
}

#[test]
fn source_index_rejects_malformed_cache_digests_by_name() {
    // The three cache digests were already refused indirectly (their content anchor would not
    // match), but the diagnosis was "does not match its content anchor" — which tells a reader
    // the value was tampered with, not that it is not even an anchor (`ADR-035`'s rule: a
    // restart should not have to guess which part is corrupt).
    for (field, bad) in [
        ("normalized_digest", "sha256:zz"),
        ("provenance_digest", "not-an-anchor"),
        ("diagnostics_digest", "sha256:"),
    ] {
        let source = source_index();
        let text = encode_source_index(&source);
        let edited = tamper_field(&text, field, bad);
        let error = decode_and_check(&edited, "source-index", decode_source_index)
            .expect_err("an anchor a writer could not have produced must be refused");
        assert!(
            error.contains(&format!("source index {field} is not a sha256 anchor")),
            "{field}: {error}"
        );
    }
}

#[test]
fn source_index_rejects_an_unknown_field() {
    let text = format!(
        "{}\nextra_field=surprise\n",
        encode_source_index(&source_index())
    );
    let error =
        decode_and_check(&text, "source-index", decode_source_index).expect_err("must refuse");
    assert!(error.contains("does not understand"), "{error}");
    assert!(
        error.contains("extra_field"),
        "unknown field must be named: {error}"
    );
}

#[test]
fn source_index_reports_a_missing_required_field_by_name() {
    let text = encode_source_index(&source_index());
    let without = text
        .lines()
        .filter(|line| !line.starts_with("normalized_cache="))
        .collect::<Vec<_>>()
        .join("\n")
        + "\n";
    let error = decode_and_check(&without, "source-index", decode_source_index)
        .expect_err("a record without its cache field must not load");
    assert!(error.contains("missing required field"), "{error}");
    assert!(error.contains("\"normalized_cache\""), "{error}");
}

#[test]
fn source_index_rejects_empty_identity_locator_and_zero_cap() {
    for (field, replacement, expected) in [
        ("source_id", "", "source_id must not be empty"),
        ("locator", "", "locator must not be empty"),
        ("max_body_bytes", "0", "must be greater than zero"),
    ] {
        let source = source_index();
        let text = encode_source_index(&source);
        let line = text
            .lines()
            .find(|line| line.starts_with(&format!("{field}=")))
            .unwrap_or_else(|| panic!("encoded source index carries {field}"));
        let edited = text.replacen(line, &format!("{field}={replacement}"), 1);
        let error = decode_and_check(&edited, "source-index", decode_source_index)
            .expect_err("an absent identity or a zero cap must be refused");
        assert!(error.contains(expected), "{field}: {error}");
    }
}

#[test]
fn source_index_rejects_malformed_timestamps_and_flags() {
    for (field, bad, expected) in [
        (
            "updated_at",
            "soon",
            "field \"updated_at\" is not an integer",
        ),
        ("raw_stored_at", "soon", "raw_stored_at is not an integer"),
        (
            "strict_mode",
            "maybe",
            "field \"strict_mode\" is not a boolean",
        ),
    ] {
        let source = source_index();
        let text = encode_source_index(&source);
        let edited = tamper_field(&text, field, bad);
        let error = decode_and_check(&edited, "source-index", decode_source_index)
            .expect_err("a value that is not of its declared shape must be refused");
        assert!(error.contains(expected), "{field}: {error}");
    }
}
