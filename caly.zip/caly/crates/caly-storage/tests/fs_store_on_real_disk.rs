//! The same durable backend, on a real filesystem.
//!
//! `tests/fs_store.rs` runs `FsStore` against `caly-io-sim`'s in-memory disk. That proves the
//! store's logic, but not durability: the interesting failures — a file replaced out of band, a
//! restart with nothing but a directory left — need a real filesystem. `RFC-0006 §15` already
//! requires both port adapters to pass one shared contract; this file extends that idea to the
//! thing built on top of them.
//!
//! If this file and `fs_store.rs` ever disagree about an expected outcome, the difference is in
//! the backend and not in the store. That is the point of running both.

use std::path::Path;
use std::sync::atomic::{AtomicU64, Ordering};

use caly_io::Clock;
use caly_io::{block_on_ready, ByteCap, Durability, Fs, IoContext, VPath};
use caly_io_std::{StdClock, StdFs};
use caly_storage::cas::{
    CasObjectRef, CasWriteIntent, MaterializationMode, MaterializationRequest, ObjectDigest,
    ObjectKind,
};
use caly_storage::execution::{ApplyJournalRecord, ApplyJournalState, ApplyPhase, ApplyTxnId};
use caly_storage::fs_store::{content_suffix_for, FsStore};
use caly_storage::journal::JournalRecordId;
use caly_storage::revision::{RevisionId, RevisionNumber};
use caly_storage::snapshot::{SnapshotRecord, SnapshotRecordId};
use caly_storage::{ApplyJournalStore, ObjectStore, SnapshotStore, StorageErrorKind};

const ROOT: &str = "store";
static SEQ: AtomicU64 = AtomicU64::new(0);

/// A scratch root as a plain `String`: this crate inherits the workspace-wide ban on naming
/// `PathBuf`, and the store only ever speaks relative `VPath` strings anyway.
fn scratch() -> String {
    let nth = SEQ.fetch_add(1, Ordering::SeqCst);
    let dir = std::env::temp_dir().join(format!("caly-fs-store-{}-{nth}", std::process::id()));
    std::fs::create_dir_all(&dir).expect("scratch dir must be creatable");
    dir.to_string_lossy().into_owned()
}

fn ctx() -> IoContext {
    IoContext::new(caly_io::TraceId::new("real-disk"), caly_io::Actor::System)
}

fn done<T>(future: caly_io::BoxFuture<'_, Result<T, caly_storage::StorageError>>) -> T
where
    T: std::fmt::Debug,
{
    block_on_ready(future)
        .expect("a storage future must not suspend")
        .expect("storage call must succeed")
}

fn object(digest: &str) -> CasObjectRef {
    CasObjectRef {
        digest: ObjectDigest(digest.to_owned()),
        kind: ObjectKind::CompiledArtifact,
        size_bytes: None,
        content_type: Some("application/x-yaml".to_owned()),
        content_sha256: None,
        stored_at_unix_ms: None,
    }
}

fn snapshot(id: &str) -> SnapshotRecord {
    SnapshotRecord {
        id: SnapshotRecordId(id.to_owned()),
        revision_id: RevisionId("rev-real".to_owned()),
        revision_number: RevisionNumber(1),
        profile_id: "demo-profile".to_owned(),
        semantic_digest: "sem:real".to_owned(),
        compiled_artifact_digest: "mihomo:real-2".to_owned(),
        core_binary_digest: "bin".to_owned(),
        core_identity: "mihomo@0.1".to_owned(),
        apply_plan_summary: "Restart".to_owned(),
        journal_id: Some(JournalRecordId("journal:real".to_owned())),
        selection_memory_digest: None,
        validation_summary: "ok".to_owned(),
        created_at_unix_ms: 10,
        is_last_known_good: true,
    }
}

fn interrupted(txn: &str) -> ApplyJournalRecord {
    ApplyJournalRecord {
        journal_id: JournalRecordId(format!("journal:{txn}")),
        apply_txn_id: ApplyTxnId(txn.to_owned()),
        trace_id: "trace:real".to_owned(),
        job_id: None,
        profile_id: "demo-profile".to_owned(),
        revision_id: RevisionId("rev-real".to_owned()),
        semantic_digest: "sem:real".to_owned(),
        compiled_artifact_digest: "mihomo:real-2".to_owned(),
        core_identity: "mihomo@0.1".to_owned(),
        effect_plan_id: "plan-real".to_owned(),
        current_phase: ApplyPhase::Cutover,
        current_step_index: 2,
        net_effect_started: true,
        core_cutover_started: true,
        previous_snapshot_id: None,
        created_at_unix_ms: 5,
        updated_at_unix_ms: 6,
        state: ApplyJournalState::Pending,
    }
}

#[test]
fn content_lands_as_a_real_file_under_its_own_digest() {
    let root = scratch();
    let fs = StdFs::new(root.clone());
    let store = FsStore::open(Box::new(fs), ROOT).expect("open");
    let payload = b"proxies:\n  - name: a\n".to_vec();

    let written = done(store.put(CasWriteIntent {
        object: object("mihomo:real-1"),
        source_label: "config.yaml".to_owned(),
        payload: payload.clone(),
        stored_at_unix_ms: 1_700_000_000_000,
    }));
    let anchor = written
        .content_sha256
        .clone()
        .expect("anchor must be recorded");
    let expected = Path::new(&root)
        .join(ROOT)
        .join(content_suffix_for(&anchor));

    assert!(
        expected.is_file(),
        "content must exist at {}",
        expected.display()
    );
    assert_eq!(std::fs::read(&expected).expect("read"), payload);
    // `ADR-035 §2.3`: a collection is enumerable because its files are in a directory, not because
    // something lists them. Asserting the *absence* is the point -- an index nobody reads is still a
    // second truth waiting to disagree, and only a real filesystem can show that `list` finds the
    // content-addressed file under its digest path.
    assert!(
        Path::new(&root).join(ROOT).join("meta/objects").is_dir(),
        "object metadata must live in the directory that enumeration walks"
    );
    assert!(
        !Path::new(&root).join(ROOT).join("manifest").exists(),
        "the store must maintain no index of what it wrote"
    );

    // `runtime_path` is resolved *relative to the store root*, not relative to the port's root:
    // `FsStore` owns the prefixing. Asserting it here is deliberate, because the simulator has no
    // root of its own and so cannot reveal a double-prefix mistake.
    done(store.materialize(MaterializationRequest {
        object: written,
        runtime_path: "runtime/demo/config.yaml".to_owned(),
        mode: MaterializationMode::Copy,
    }));
    let materialized = Path::new(&root).join(format!("{ROOT}/runtime/demo/config.yaml"));
    assert!(
        materialized.is_file(),
        "the runtime must receive a real file at {}",
        materialized.display()
    );
    assert_eq!(std::fs::read(&materialized).expect("read"), payload);

    std::fs::remove_dir_all(&root).ok();
}

/// The same dating rule where faking it actually costs something: a real filesystem, a real mtime,
/// and a clock read through a port -- a test that called `SystemTime::now` here would be asserting
/// with a tool the workspace bans for everyone outside the gateway (`ADR-011`, `clippy.toml`).
#[test]
fn a_real_disk_dates_the_object_inside_the_window_the_write_happened_in() {
    let root = scratch();
    let fs = StdFs::new(root.clone());
    let clock = StdClock::new();
    let before = clock.now().unix_millis;

    let store = FsStore::open(Box::new(fs), ROOT).expect("open");
    let written = done(store.put(CasWriteIntent {
        object: object("mihomo:real-4"),
        source_label: "config.yaml".to_owned(),
        payload: b"dated-by-the-host".to_vec(),
        // The lie again, on a real disk.
        stored_at_unix_ms: 0,
    }));
    let after = clock.now().unix_millis;

    let age = written
        .stored_at_unix_ms
        .expect("a real port reports an mtime for a file it just wrote");
    // Two seconds of slack, and only for granularity: a filesystem that floors mtime to the second
    // would otherwise make a correct implementation fail. A bogus age (1970, or the future) is still
    // far outside this window, which is the thing under test.
    assert!(
        (before - 2_000..=after + 2_000).contains(&age),
        "the age must be the write's own moment: {age} not within {before}..={after}"
    );
    assert_eq!(
        done(store.list_objects())[0].stored_at_unix_ms,
        Some(age),
        "the write and the enumeration must not disagree about one object's age"
    );

    std::fs::remove_dir_all(&root).ok();
}

/// A new process must be able to reconstruct state from the directory alone.
#[test]
fn a_restart_reads_back_only_what_is_on_the_disk() {
    let root = scratch();
    let snapshot_id = "snapshot:rev-real".to_owned();
    {
        let store = FsStore::open(Box::new(StdFs::new(root.clone())), ROOT).expect("open");
        done(store.put(CasWriteIntent {
            object: object("mihomo:real-2"),
            source_label: "config.yaml".to_owned(),
            payload: b"durable-config".to_vec(),
            stored_at_unix_ms: 5,
        }));
        done(store.put_snapshot(snapshot(&snapshot_id)));
        done(store.put_apply_journal(interrupted("txn:crashed")));
    }

    let store = FsStore::open(Box::new(StdFs::new(root.clone())), ROOT).expect("reopen");
    let lkg = done(store.latest_last_known_good()).expect("the committed snapshot must survive");
    assert_eq!(lkg.id.0, snapshot_id);
    assert_eq!(lkg.profile_id, "demo-profile");
    assert!(lkg.is_last_known_good);

    let unresolved = done(store.list_unresolved_apply());
    assert_eq!(
        unresolved.len(),
        1,
        "the unfinished transaction must reappear"
    );
    assert_eq!(
        unresolved[0].apply_txn_id,
        ApplyTxnId("txn:crashed".to_owned())
    );
    assert_eq!(unresolved[0].current_step_index, 2);
    assert!(unresolved[0].core_cutover_started);
    assert_eq!(store.apply_journal_count(), 1);
    assert!(store.object_digests().contains(&"mihomo:real-2".to_owned()));

    // The files are plain, greppable text, which is what a support bundle can show a human.
    let pointer =
        std::fs::read_to_string(Path::new(&root).join(format!("{ROOT}/pointers/last-known-good")))
            .expect("pointer file");
    assert_eq!(pointer.trim(), snapshot_id);
    let journal_text = std::fs::read_to_string(
        Path::new(&root).join(format!("{ROOT}/records/apply-journal/txn_crashed.rec")),
    )
    .expect("journal record");
    assert!(journal_text.starts_with("record:v1"), "{journal_text}");
    assert!(journal_text.contains("state=pending"), "{journal_text}");
    assert!(
        journal_text.contains("net_effect_started=true"),
        "{journal_text}"
    );

    std::fs::remove_dir_all(&root).ok();
}

/// Out-of-band damage must be caught twice: on the way to the runtime, and at restart.
#[test]
fn out_of_band_damage_is_caught_on_materialize_and_on_restart() {
    let root = scratch();
    let fs = StdFs::new(root.clone());
    let store = FsStore::open(Box::new(fs.clone()), ROOT).expect("open");
    let written = done(store.put(CasWriteIntent {
        object: object("mihomo:real-3"),
        source_label: "config.yaml".to_owned(),
        payload: b"healthy-bytes".to_vec(),
        stored_at_unix_ms: 7,
    }));
    let anchor = written.content_sha256.clone().expect("anchor");

    // Truncate the CAS object in place, leaving the metadata record intact beside it.
    let content =
        VPath::try_from_str(&format!("{ROOT}/{}", content_suffix_for(&anchor))).expect("path");
    block_on_ready(fs.write_atomic(&content, b"cut".to_vec(), Durability::D2, &ctx()))
        .expect("ready")
        .expect("tamper");

    let error = block_on_ready(store.materialize(MaterializationRequest {
        object: written,
        runtime_path: "runtime/demo/config.yaml".to_owned(),
        mode: MaterializationMode::Copy,
    }))
    .expect("ready")
    .expect_err("a corrupted object must never reach the runtime path");
    assert_eq!(error.kind, StorageErrorKind::IntegrityViolation);

    match FsStore::open(Box::new(fs), ROOT) {
        Ok(_) => panic!("open must fail when an object no longer matches its digest"),
        Err(failure) => assert!(
            failure.summary.contains("no longer matches"),
            "{}",
            failure.summary
        ),
    }

    std::fs::remove_dir_all(&root).ok();
}

/// Every durability tier must be a real code path that still produces correct bytes, and none of
/// them may leave temp debris behind (`ADR-014` tiers are only meaningful if they differ).
#[test]
fn all_durability_tiers_write_correctly_and_leave_no_debris() {
    let root = scratch();
    let fs = StdFs::new(root.clone());
    for (index, durability) in [
        Durability::D0,
        Durability::D1,
        Durability::D2,
        Durability::D3,
    ]
    .into_iter()
    .enumerate()
    {
        let path = VPath::try_from_str(&format!("{ROOT}/tier/{index}")).expect("path");
        block_on_ready(fs.write_atomic(
            &path,
            format!("tier-{durability:?}").into_bytes(),
            durability,
            &ctx(),
        ))
        .expect("ready")
        .unwrap_or_else(|fault| panic!("{durability:?} write failed: {}", fault.summary));

        let read_back = block_on_ready(fs.read(&path, ByteCap(256), &ctx()))
            .expect("ready")
            .expect("read");
        assert_eq!(
            String::from_utf8(read_back).expect("utf-8"),
            format!("tier-{durability:?}")
        );
    }

    let leftovers: Vec<String> = std::fs::read_dir(Path::new(&root).join(format!("{ROOT}/tier")))
        .expect("tier dir")
        .flatten()
        .map(|entry| entry.file_name().to_string_lossy().into_owned())
        .filter(|name| name.contains(".tmp-"))
        .collect();
    assert!(
        leftovers.is_empty(),
        "temp debris after write: {leftovers:?}"
    );

    std::fs::remove_dir_all(&root).ok();
}
