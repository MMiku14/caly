//! Enumerating apply journals — the primitive the support bundle needed.
//!
//! `ApplyJournalStore` exposed `put`/`get`/`list_pending`/`list_unresolved`, which is enough for
//! recovery and not enough for `docs/STORAGE_RECOVERY_EXECUTION_PLAN.md §9.3`'s "recent apply
//! journal summaries": a *committed* transaction is precisely what those two lists leave out. The
//! same gap showed up for objects (`docs/ONBOARDING_NOTES.md §4.18`), and the same rule applies —
//! a backend that cannot answer must say so, because "no journals" and "cannot look" lead an
//! operator in opposite directions.

use caly_io::{block_on_ready, Durability, Fs, IoContext, VPath};
use caly_io_sim::{FaultInjector, MemFs, SharedFaults, SimFs};
use caly_storage::execution::{ApplyJournalRecord, ApplyJournalState, ApplyPhase, ApplyTxnId};
use caly_storage::fs_store::FsStore;
use caly_storage::journal::JournalRecordId;
use caly_storage::revision::RevisionId;
use caly_storage::{ApplyJournalStore, BoxFuture, InMemoryStorage, StorageError, StorageErrorKind};

const ROOT: &str = "var/caly";

fn ctx() -> IoContext {
    IoContext::new(caly_io::TraceId::new("listing"), caly_io::Actor::System)
}

fn done<T>(future: BoxFuture<'_, Result<T, StorageError>>) -> Result<T, StorageError> {
    block_on_ready(future).expect("a storage future must not suspend")
}

fn ok<T: std::fmt::Debug>(future: BoxFuture<'_, Result<T, StorageError>>) -> T {
    done(future).expect("storage call must succeed")
}

fn journal(txn: &str, state: ApplyJournalState) -> ApplyJournalRecord {
    ApplyJournalRecord {
        journal_id: JournalRecordId(format!("journal:{txn}")),
        apply_txn_id: ApplyTxnId(txn.to_owned()),
        trace_id: "t".to_owned(),
        job_id: Some("7".to_owned()),
        profile_id: "demo-profile".to_owned(),
        revision_id: RevisionId(format!("rev:{txn}")),
        semantic_digest: format!("sem:{txn}"),
        compiled_artifact_digest: format!("artifact:{txn}"),
        core_identity: "mihomo@0.1".to_owned(),
        effect_plan_id: "plan:1".to_owned(),
        current_phase: ApplyPhase::Finalize,
        current_step_index: 3,
        net_effect_started: true,
        core_cutover_started: true,
        previous_snapshot_id: None,
        created_at_unix_ms: 1,
        updated_at_unix_ms: 2,
        state,
    }
}

/// A backend that implements only the four required journal methods: what a new store gets for
/// the enumeration hook, without writing a line about it.
#[derive(Default)]
struct JournalsOnly;

impl ApplyJournalStore for JournalsOnly {
    fn put_apply_journal<'a>(
        &'a self,
        _record: ApplyJournalRecord,
        _ctx: &'a IoContext,
    ) -> BoxFuture<'a, Result<(), StorageError>> {
        Box::pin(async { Ok(()) })
    }

    fn get_apply_journal<'a>(
        &'a self,
        _apply_txn_id: &'a ApplyTxnId,
        _ctx: &'a IoContext,
    ) -> BoxFuture<'a, Result<Option<ApplyJournalRecord>, StorageError>> {
        Box::pin(async { Ok(None) })
    }

    fn list_pending_apply<'a>(
        &'a self,
        _ctx: &'a IoContext,
    ) -> BoxFuture<'a, Result<Vec<ApplyJournalRecord>, StorageError>> {
        Box::pin(async { Ok(Vec::new()) })
    }

    fn list_unresolved_apply<'a>(
        &'a self,
        _ctx: &'a IoContext,
    ) -> BoxFuture<'a, Result<Vec<ApplyJournalRecord>, StorageError>> {
        Box::pin(async { Ok(Vec::new()) })
    }
}

#[test]
fn a_backend_that_does_not_override_enumeration_refuses_rather_than_lying() {
    let store = JournalsOnly;
    let failure =
        done(store.list_apply_journals(&ctx())).expect_err("the default must refuse to answer");
    assert_eq!(failure.kind, StorageErrorKind::Unsupported);
    // Contrast is the point: the same backend legitimately reports zero pending journals. A caller
    // that cannot tell the two apart reads "empty store" out of "no idea".
    assert!(ok(store.list_pending_apply(&ctx())).is_empty());
}

#[test]
fn the_in_memory_store_reports_committed_journals_too() {
    let store = InMemoryStorage::new();
    ok(store.put_apply_journal(journal("t1", ApplyJournalState::Committed), &ctx()));
    ok(store.put_apply_journal(journal("t2", ApplyJournalState::Pending), &ctx()));
    ok(store.put_apply_journal(journal("t3", ApplyJournalState::Reverted), &ctx()));

    let listed = ok(store.list_apply_journals(&ctx()));
    let ids: Vec<String> = listed
        .iter()
        .map(|record| record.apply_txn_id.0.clone())
        .collect();
    assert_eq!(ids, vec!["t1".to_owned(), "t2".to_owned(), "t3".to_owned()]);
    assert_eq!(ok(store.list_unresolved_apply(&ctx())).len(), 1);
}

fn disk() -> SimFs {
    SimFs::new(MemFs::default(), SharedFaults::new(FaultInjector::new(1)))
}

#[test]
fn the_durable_store_lists_what_a_restart_can_read_back() {
    let fs = disk();
    let store = FsStore::open(Box::new(fs.clone()), ROOT).expect("fresh store");
    ok(store.put_apply_journal(journal("t1", ApplyJournalState::Committed), &ctx()));
    ok(store.put_apply_journal(journal("t2", ApplyJournalState::Pending), &ctx()));

    // A second store over the same bytes, with nothing carried in memory.
    let reopened = FsStore::open(Box::new(fs), ROOT).expect("reopen");
    let listed = ok(reopened.list_apply_journals(&ctx()));
    assert_eq!(listed.len(), 2, "{listed:?}");
    assert_eq!(listed[0].apply_txn_id.0, "t1");
    assert_eq!(
        listed[0].state,
        ApplyJournalState::Committed,
        "a committed transaction has to be visible to the bundle, or the export cannot say what \
         this deployment did"
    );
    assert_eq!(listed[1].state, ApplyJournalState::Pending);
}

#[test]
fn a_torn_record_aborts_the_list_instead_of_being_skipped() {
    let fs = disk();
    let store = FsStore::open(Box::new(fs.clone()), ROOT).expect("fresh store");
    ok(store.put_apply_journal(journal("t1", ApplyJournalState::Committed), &ctx()));
    ok(store.put_apply_journal(journal("t2", ApplyJournalState::Committed), &ctx()));

    // Damage one record *after* the store is open, so the cache still looks fine and only the
    // on-disk read can notice.
    let damaged = format!("{ROOT}/records/apply-journal/t1.rec");
    let path = VPath::try_from_str(&damaged).expect("relative path");
    block_on_ready(fs.write_atomic(&path, b"not a record".to_vec(), Durability::D1, &ctx()))
        .expect("port future must not suspend")
        .expect("write must succeed");

    let failure =
        done(store.list_apply_journals(&ctx())).expect_err("a corrupt record must surface");
    assert_eq!(
        failure.kind,
        StorageErrorKind::IntegrityViolation,
        "{failure:?}"
    );
    // And the surviving record is not silently reported as the whole history.
    assert!(!failure.summary.contains("t2"), "{failure:?}");
}
