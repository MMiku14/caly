//! The cumulative half of the byte budget, at the store seam (`ADR-039 §2`, step 2).
//!
//! Round 29 made a stated `max_bytes` a **per-call ceiling the ports enforce**; the cumulative
//! meter was recorded as a deliberate deviation (`ADR-036 §6bis-decies`) for one reason:
//! `StorageBackend`'s methods carried no `Ctx`, so there was no scope to hang a meter on that
//! was the caller's rather than the process's. Round 33 removed that premise. These tests pin
//! the meter that became possible:
//!
//! * **Writes are refused before any byte lands** (their size is known up front), and a refused
//!   write leaves the disk exactly as it was.
//! * **Reads discover their size by moving the bytes**, so the unit in flight completes, charges
//!   what it moved, and the next unit refuses -- the same in-flight discipline as cancellation.
//! * **Clones share one meter**: a context handed down accrues to the command that owns it.
//! * **No stated budget moves unbounded bytes**: the default context (and the engine's own
//!   self-labelled one) is never silently gated.
//! * **Both backends answer the door the same way**: same refusal kind, same words -- one rule
//!   in `caly_io::budget`, called by both stores. Accounting granularity differs (the durable
//!   backend also meters its record files; the memory backend meters payloads), which is why
//!   the contract here pins the door, not the byte counts.

use caly_io::{block_on_ready, Fs, IoContext};
use caly_io_sim::{FaultInjector, MemFs, SharedFaults, SimFs};
use caly_storage::cas::{CasObjectRef, CasWriteIntent, ObjectDigest, ObjectKind};
use caly_storage::fs_store::FsStore;
use caly_storage::gc::ContentTarget;
use caly_storage::{InMemoryStorage, ObjectStore, StorageErrorKind};

const ROOT: &str = "var/caly";

fn disk() -> SimFs {
    SimFs::new(MemFs::default(), SharedFaults::new(FaultInjector::new(1)))
}

fn store_on(fs: SimFs) -> FsStore {
    FsStore::open(Box::new(fs) as Box<dyn Fs>, ROOT).expect("open")
}

/// A context with no stated byte budget: what `RequestContext::new` (and therefore the engine's
/// self-labelled store context) hands the store.
fn unbudgeted() -> IoContext {
    IoContext::new(caly_io::TraceId::new("byte-budget"), caly_io::Actor::System)
}

/// A context that stated `max_bytes` once, for its whole scope.
fn budgeted(max_bytes: u64) -> IoContext {
    let mut ctx = unbudgeted();
    ctx.io_budget.max_bytes = Some(max_bytes);
    ctx
}

fn object(digest: &str) -> CasObjectRef {
    CasObjectRef {
        digest: ObjectDigest(digest.to_owned()),
        kind: ObjectKind::RawSource,
        size_bytes: None,
        content_type: None,
        content_sha256: None,
        stored_at_unix_ms: None,
    }
}

fn put(
    store: &FsStore,
    digest: &str,
    payload: &[u8],
    ctx: &IoContext,
) -> Result<CasObjectRef, caly_storage::StorageError> {
    block_on_ready(store.put(
        CasWriteIntent {
            object: object(digest),
            source_label: format!("{digest}.txt"),
            payload: payload.to_vec(),
            stored_at_unix_ms: 0,
        },
        ctx,
    ))
    .expect("no suspension")
}

#[test]
fn a_write_that_would_cross_the_callers_budget_is_refused_before_it_lands() {
    let fs = disk();
    let store = store_on(fs.clone());
    let caller = budgeted(2_048);

    // A small first write fits (payload plus its record); its charge makes the meter non-zero.
    let first = put(&store, "sha256:small", &[7u8; 16], &caller).expect("the first write fits");
    assert!(first.content_sha256.is_some());

    // The second write's payload exactly equals the cap, so the per-call ceiling alone would
    // admit it (`<=` fits); what refuses it is the cumulative meter -- anything already spent
    // plus this unit passes the cap. That is the door under test, named in the refusal.
    let error = put(&store, "sha256:large", &[9u8; 2_048], &caller)
        .expect_err("a spent meter must refuse a write that would cross the cap");
    assert_eq!(
        error.kind,
        StorageErrorKind::CapacityExceeded,
        "{}",
        error.summary
    );
    assert!(
        error.summary.contains("cumulative io_budget.max_bytes"),
        "the refusal must name the bound that actually applied: {}",
        error.summary
    );

    // A refused write leaves the disk as it was: the large payload's content never landed (the
    // content write is the first byte-moving step of `put`), and the small object is intact.
    let walked = block_on_ready(store.list_content(&unbudgeted()))
        .expect("no suspension")
        .expect("walk");
    let anchors: Vec<String> = walked
        .iter()
        .filter_map(|entry| match &entry.target {
            ContentTarget::Anchor(anchor) => Some(anchor.clone()),
            ContentTarget::Residue { .. } => None,
        })
        .collect();
    let large_anchor = caly_common::digest::sha256_digest(&[9u8; 2_048]);
    assert!(
        !anchors.contains(&large_anchor),
        "a refused write must not leave its bytes on disk"
    );
    assert!(
        block_on_ready(store.get("sha256:small", &unbudgeted()))
            .expect("no suspension")
            .expect("get")
            .is_some(),
        "the earlier write must be intact after a later refusal"
    );
}

#[test]
fn a_read_charges_what_it_moved_and_the_next_unit_refuses() {
    let fs = disk();
    let store = store_on(fs);
    // Place the file on an unbudgeted context (the store's own bootstrap shape), then read it
    // twice on one budgeted caller: the first read completes and charges 64, the second finds
    // the budget spent and refuses before starting.
    put(&store, "sha256:payload", &[5u8; 64], &unbudgeted()).expect("place the file");
    let caller = budgeted(64);

    let first = block_on_ready(store.read_object("sha256:payload", 1 << 10, &caller))
        .expect("no suspension")
        .expect("the first read is inside the budget");
    assert_eq!(first.as_deref(), Some(&[5u8; 64][..]));

    let error = block_on_ready(store.read_object("sha256:payload", 1 << 10, &caller))
        .expect("no suspension")
        .expect_err("the budget was spent by the first read");
    assert_eq!(
        error.kind,
        StorageErrorKind::CapacityExceeded,
        "{}",
        error.summary
    );
    assert!(
        error.summary.contains("already spent"),
        "the refusal must say the meter, not the cap, is what stopped it: {}",
        error.summary
    );
}

#[test]
fn an_in_flight_read_completes_and_only_the_unit_after_it_refuses() {
    let fs = disk();
    let store = store_on(fs);
    put(&store, "sha256:payload", &[5u8; 64], &unbudgeted()).expect("place the file");
    // cap 65: after one 64-byte read the meter (64) is under the cap, so a second read is
    // admitted, completes, and charges to 128; only the third refuses. A meter that tore into
    // the in-flight read, or one that refused the second, would fail this either way.
    let caller = budgeted(65);
    for round in 0..2 {
        let read = block_on_ready(store.read_object("sha256:payload", 1 << 10, &caller))
            .expect("no suspension")
            .unwrap_or_else(|e| panic!("read #{round} should complete: {}", e.summary));
        assert_eq!(read.as_deref(), Some(&[5u8; 64][..]));
    }
    let error = block_on_ready(store.read_object("sha256:payload", 1 << 10, &caller))
        .expect("no suspension")
        .expect_err("128 moved against a stated 65");
    assert_eq!(
        error.kind,
        StorageErrorKind::CapacityExceeded,
        "{}",
        error.summary
    );
}

#[test]
fn clones_share_one_meter_so_a_command_pays_once_for_its_whole_scope() {
    let fs = disk();
    let store = store_on(fs);
    put(&store, "sha256:payload", &[5u8; 64], &unbudgeted()).expect("place the file");
    // The whole point of hanging the meter on the context (`ADR-039 §2`): a context handed down
    // is the same command's scope. A clone that started a fresh meter would serve both reads
    // and the budget would read like one while behaving like two.
    let parent = budgeted(64);
    let child = parent.clone();
    let first = block_on_ready(store.read_object("sha256:payload", 1 << 10, &parent))
        .expect("no suspension")
        .expect("the parent's read is inside the budget");
    assert_eq!(first.as_deref(), Some(&[5u8; 64][..]));
    let error = block_on_ready(store.read_object("sha256:payload", 1 << 10, &child))
        .expect("no suspension")
        .expect_err("the child spends the same meter, not a fresh one");
    assert_eq!(
        error.kind,
        StorageErrorKind::CapacityExceeded,
        "{}",
        error.summary
    );
}

#[test]
fn a_context_without_a_stated_budget_moves_unbounded_bytes() {
    let fs = disk();
    let store = store_on(fs);
    // `unbudgeted()` is `RequestContext::new`'s shape -- the default every existing call site
    // and the engine's self-labelled context use. Step 2 must not turn that into a gate.
    for round in 0..8 {
        put(
            &store,
            &format!("sha256:round-{round}"),
            &[3u8; 4_096],
            &unbudgeted(),
        )
        .expect("no stated budget means no byte gate");
        block_on_ready(store.read_object(&format!("sha256:round-{round}"), 1 << 20, &unbudgeted()))
            .expect("no suspension")
            .expect("reads too");
    }
}

#[test]
fn both_backends_answer_the_budget_door_the_same_way() {
    // The single-payload door: a payload that does not fit the stated budget is refused before
    // anything is stored, with the same kind and the same words, on both backends.
    let fs_store = store_on(disk());
    let memory = InMemoryStorage::new();
    let over = budgeted(32);
    let mut refusals = Vec::new();
    for (label, error) in [
        match put(&fs_store, "sha256:over", &[1u8; 64], &over) {
            Ok(_) => panic!("fs: the payload does not fit the stated budget"),
            Err(e) => ("fs", e),
        },
        match block_on_ready(memory.put(
            CasWriteIntent {
                object: object("sha256:over"),
                source_label: "over.txt".to_owned(),
                payload: vec![1u8; 64],
                stored_at_unix_ms: 0,
            },
            &over,
        ))
        .expect("no suspension")
        {
            Ok(_) => panic!("memory: the payload does not fit the stated budget"),
            Err(e) => ("memory", e),
        },
    ] {
        assert_eq!(
            error.kind,
            StorageErrorKind::CapacityExceeded,
            "{label}: {}",
            error.summary
        );
        assert!(
            error.summary.contains("cumulative io_budget.max_bytes"),
            "{label}: one rule, one wording: {}",
            error.summary
        );
        refusals.push((label, error.summary));
    }
    assert_eq!(refusals.len(), 2);

    // The cumulative door: repeated writes on one budgeted scope are refused on both backends
    // within a bounded number of attempts. The *attempt* at which each refuses differs by
    // accounting granularity (the durable backend also meters its record files) -- the door is
    // the contract, not the byte counts.
    let fs_store = store_on(disk());
    let memory = InMemoryStorage::new();
    let caller = budgeted(96);
    for backend in ["fs", "memory"] {
        let mut refused = false;
        for round in 0..4 {
            let payload = vec![2u8; 48];
            let outcome = if backend == "fs" {
                put(
                    &fs_store,
                    &format!("sha256:{backend}-{round}"),
                    &payload,
                    &caller,
                )
                .map(|_| ())
            } else {
                block_on_ready(memory.put(
                    CasWriteIntent {
                        object: object(&format!("sha256:{backend}-{round}")),
                        source_label: format!("{backend}-{round}.txt"),
                        payload,
                        stored_at_unix_ms: 0,
                    },
                    &caller,
                ))
                .expect("no suspension")
                .map(|_| ())
            };
            if let Err(error) = outcome {
                assert_eq!(
                    error.kind,
                    StorageErrorKind::CapacityExceeded,
                    "{backend}: {}",
                    error.summary
                );
                refused = true;
                break;
            }
        }
        assert!(
            refused,
            "{backend}: a stated 96-byte budget cannot serve unbounded writes"
        );
    }
}

#[test]
fn a_memory_read_charges_and_then_refuses_new_units() {
    let memory = InMemoryStorage::new();
    block_on_ready(memory.put(
        CasWriteIntent {
            object: object("sha256:payload"),
            source_label: "payload.txt".to_owned(),
            payload: vec![5u8; 64],
            stored_at_unix_ms: 0,
        },
        &unbudgeted(),
    ))
    .expect("no suspension")
    .expect("place the content");
    let caller = budgeted(64);
    let first = block_on_ready(memory.read_object("sha256:payload", 1 << 10, &caller))
        .expect("no suspension")
        .expect("the first read is inside the budget");
    assert_eq!(first.as_deref(), Some(&[5u8; 64][..]));
    let error = block_on_ready(memory.read_object("sha256:payload", 1 << 10, &caller))
        .expect("no suspension")
        .expect_err("the budget was spent by the first read");
    assert_eq!(
        error.kind,
        StorageErrorKind::CapacityExceeded,
        "{}",
        error.summary
    );
}

/// The meter itself: accumulation, clone-sharing, and scope independence are `caly_common`
/// behaviour, but they are load-bearing here -- pinned where their consumer lives.
#[test]
fn the_meter_accumulates_shares_on_clone_and_stays_scoped() {
    let meter = caly_common::ByteMeter::new();
    assert_eq!(meter.spent(), 0);
    meter.charge(30);
    meter.charge(2);
    assert_eq!(meter.spent(), 32);
    let shared = meter.clone();
    shared.charge(10);
    assert_eq!(
        meter.spent(),
        42,
        "a clone meters the same scope, it does not fork it"
    );
    let fresh = caly_common::ByteMeter::new();
    fresh.charge(1);
    assert_eq!(meter.spent(), 42, "a fresh context starts a fresh scope");
    assert_ne!(
        meter, fresh,
        "equality is identity: different scopes are different meters"
    );
    assert_eq!(meter, shared, "a clone is the same meter");
}

#[test]
fn a_write_charges_the_bytes_it_wrote_not_just_the_verification_read() {
    let fs = disk();
    let store = store_on(fs);
    // `put` on the durable backend is content write + verification read-back + record write.
    // The read-back charges the same payload, so a lost *write* charge would leave the meter
    // moving anyway -- the door would look alive while writes rode free. This pins each path's
    // own contribution: the floor for "the write charged" is the payload twice (write + read).
    let caller = budgeted(1 << 20);
    put(&store, "sha256:once", &[4u8; 100], &caller).expect("write inside a generous budget");
    assert!(
        caller.byte_meter.spent() >= 200,
        "the content write (100) and the verification read (100) must both be on the meter, got {}",
        caller.byte_meter.spent()
    );
}
