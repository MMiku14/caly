//! Sharded record layout judges (`ADR-062`).
//!
//! The sizing round (`STORAGE_SIZING_BASELINE.md` F1) found the flat record directories'
//! 4096-entry `list` cap to be a boot-refusal cliff the WRITE path can walk past blindly
//! (~2.7 days at the full source quota), and past which even GC cannot run. This file
//! pins the layout that removed it:
//!
//! * records land in hash buckets and the top level holds no records;
//! * the cliff is gone at the store's real scale ceiling (4097 objects reopen fine),
//!   while a single bucket over the cap still refuses LOUDLY, naming bucket and count;
//! * the v1 -> v2 migration moves every flat record into its bucket, losing nothing,
//!   leaving a rollback point behind, and is what the production chain ships;
//! * a record in the wrong bucket is refused by name at reopen (`ADR-041` one level up).

use caly_io::{block_on_ready, ByteCap, Durability, Fs, IoContext, VPath};
use caly_io_sim::{MemFs, SharedFaults, SimFs};
use caly_storage::cas::{CasObjectRef, CasWriteIntent, ObjectDigest, ObjectKind};
use caly_storage::schema::SchemaMarker;
use caly_storage::{
    object_record_path, FsStore, ObjectStore, MAX_ENTRIES_PER_DIRECTORY, STORAGE_SCHEMA_VERSION,
};

const ROOT: &str = "var/caly";

fn disk() -> SimFs {
    SimFs::new(MemFs::default(), SharedFaults::default())
}

fn ctx() -> IoContext {
    IoContext::new(
        caly_io::TraceId::new("sharded-records-judge"),
        caly_io::Actor::System,
    )
}

fn put_object(store: &FsStore, digest: &str, payload: &[u8]) {
    let admitted = block_on_ready(store.put(
        CasWriteIntent {
            object: CasObjectRef {
                digest: ObjectDigest(digest.to_owned()),
                kind: ObjectKind::RawSource,
                size_bytes: None,
                content_type: None,
                content_sha256: None,
                stored_at_unix_ms: Some(1_000_000),
            },
            source_label: format!("{digest}.txt"),
            payload: payload.to_vec(),
            stored_at_unix_ms: 1_000_000,
        },
        &ctx(),
    ))
    .expect("no suspension")
    .expect("write");
    assert!(admitted.content_sha256.is_some());
}

fn write_raw(fs: &SimFs, suffix: &str, text: &str) {
    let path = VPath::try_from_str(&format!("{ROOT}/{suffix}")).expect("path");
    block_on_ready(fs.write_atomic(&path, text.as_bytes().to_vec(), Durability::D3, &ctx()))
        .expect("ready")
        .expect("write");
}

fn read_raw(fs: &SimFs, suffix: &str) -> Option<String> {
    let path = VPath::try_from_str(&format!("{ROOT}/{suffix}")).expect("path");
    block_on_ready(fs.read(&path, ByteCap(1 << 16), &ctx()))
        .expect("ready")
        .ok()
        .map(|bytes| String::from_utf8_lossy(&bytes).into_owned())
}

fn list_names(fs: &SimFs, dir: &str) -> Vec<String> {
    let path = VPath::try_from_str(&format!("{ROOT}/{dir}")).expect("path");
    block_on_ready(fs.list(&path, caly_io::ListCap(MAX_ENTRIES_PER_DIRECTORY), &ctx()))
        .expect("ready")
        .expect("list")
        .into_iter()
        .map(|child| {
            child
                .as_relative_path()
                .rsplit('/')
                .next()
                .unwrap_or_default()
                .to_owned()
        })
        .collect()
}

fn digests(count: usize) -> Vec<String> {
    // Production-shaped digests (`sha256:<hex>`) plus deliberately alien ones -- the
    // bucket rule must not depend on the digest grammar (ADR-062 §2.1).
    (0..count)
        .map(|index| match index % 3 {
            0 => format!("sha256:{index:064x}"),
            1 => format!("obj:weird-{index}"),
            _ => format!("mihomo:anchor-{index}"),
        })
        .collect()
}

/// Writes go into hash buckets; the top level of the record directory holds only bucket
/// names (two lower-hex characters) and no record file, whatever the digest grammar.
#[test]
fn records_land_in_hash_buckets_and_the_top_level_holds_no_records() {
    let fs = disk();
    let store = FsStore::open(Box::new(fs.clone()) as Box<dyn Fs>, ROOT).expect("open");
    for digest in digests(24) {
        put_object(&store, &digest, digest.as_bytes());
    }
    drop(store);

    let tops = list_names(&fs, "meta/objects");
    assert!(!tops.is_empty(), "the buckets exist");
    for name in &tops {
        assert_eq!(
            name.len(),
            2,
            "top-level names are bucket names, got {name:?} in {tops:?}"
        );
        assert!(
            name.bytes()
                .all(|byte| byte.is_ascii_digit() || (b'a'..=b'f').contains(&byte)),
            "bucket names are two lower-hex characters, got {name:?}"
        );
    }
    for digest in digests(24) {
        let stem = caly_storage::escape_component(&digest);
        let bucket = caly_storage::record_shard(&stem);
        let names = list_names(&fs, &format!("meta/objects/{bucket}"));
        assert!(
            names.contains(&format!("{stem}.obj")),
            "the record for {digest} is inside its bucket {bucket}: {names:?}"
        );
        // The store's own derivation agrees with the file that exists -- one construction
        // point for the path is the claim being checked here.
        assert_eq!(
            object_record_path(&digest),
            format!("meta/objects/{bucket}/{stem}.obj")
        );
    }

    let reopened = FsStore::open(Box::new(fs) as Box<dyn Fs>, ROOT).expect("reopen");
    let listed = block_on_ready(reopened.list_objects(&ctx()))
        .expect("no suspension")
        .expect("enumerate");
    assert_eq!(listed.len(), 24, "every sharded record is enumerated");
}

/// The sizing round's cliff, inverted: 4097 objects -- one past the OLD flat-directory
/// cap -- must reopen fine, because the growth is sharded. The refusal the flat layout
/// produced is deliberately retired by `ADR-062`; the bound itself is not (see the
/// bucket-cap judge).
#[test]
fn forty_ninety_seven_objects_reopen_because_the_growth_is_sharded() {
    let fs = disk();
    {
        let store = FsStore::open(Box::new(fs.clone()) as Box<dyn Fs>, ROOT).expect("open");
        // Distinct payloads so the CAS does not collapse them; bytes small enough that
        // this stays a judge of the LAYOUT, not of the hash throughput.
        for digest in digests(MAX_ENTRIES_PER_DIRECTORY as usize + 1) {
            put_object(&store, &digest, digest.as_bytes());
        }
    }
    let reopened = FsStore::open(Box::new(fs) as Box<dyn Fs>, ROOT)
        .expect("one past the old flat cap is not a boot refusal any more (ADR-062)");
    let listed = block_on_ready(reopened.list_objects(&ctx()))
        .expect("no suspension")
        .expect("enumerate");
    assert_eq!(
        listed.len(),
        MAX_ENTRIES_PER_DIRECTORY as usize + 1,
        "all 4097 sharded objects are enumerated after the reopen"
    );
}

/// The cap is not gone, it is PER BUCKET now: a bucket past 4096 refuses the reopen,
/// naming the directory, the count, and the bound (the port never truncates a listing).
#[test]
fn a_record_bucket_past_the_cap_refuses_reopen_naming_the_bucket() {
    let fs = disk();
    {
        let store = FsStore::open(Box::new(fs.clone()) as Box<dyn Fs>, ROOT).expect("open");
        put_object(&store, "sha256:seed", b"seed");
    }
    // One bucket, filled past the cap by hand: record-shaped names, garbage bytes -- the
    // listing refuses BEFORE any decode, which is the point (a short list would be a lie).
    let bucket = caly_storage::record_shard("seed");
    for index in 0..=MAX_ENTRIES_PER_DIRECTORY {
        write_raw(
            &fs,
            &format!("meta/objects/{bucket}/filler-{index:05}.obj"),
            "not a real object record",
        );
    }
    let refused = FsStore::open(Box::new(fs) as Box<dyn Fs>, ROOT)
        .expect_err("a bucket past the entry cap must refuse the reopen");
    assert!(
        refused
            .summary
            .contains(&format!("holds {}", MAX_ENTRIES_PER_DIRECTORY as usize + 1)),
        "the refusal names how many entries the bucket holds: {refused:?}"
    );
    assert!(
        refused.summary.contains("cap was 4096"),
        "the refusal names the bound it exceeded: {refused:?}"
    );
    assert!(
        refused.summary.contains(&format!("meta/objects/{bucket}")),
        "the refusal names the bucket that is over the cap: {refused:?}"
    );
}

/// The v1 -> v2 migration is the production chain's first entry: a flat v1 store must
/// reopen through it with every record moved into its bucket, the marker advanced (with
/// the migration counted), a rollback point holding the FLAT originals, and a second
/// reopen must not migrate again.
#[test]
fn a_v1_flat_store_migrates_to_sharded_buckets_losing_nothing() {
    let fs = disk();
    let keys = digests(9);
    {
        // Write with the CURRENT build, then hand-revert the layout to v1: move each
        // record from its bucket to the flat top level and rewrite the marker as v1.
        let store = FsStore::open(Box::new(fs.clone()) as Box<dyn Fs>, ROOT).expect("open");
        for digest in &keys {
            put_object(&store, digest, digest.as_bytes());
        }
        drop(store);
        for digest in &keys {
            let sharded = object_record_path(digest);
            let stem = caly_storage::escape_component(digest);
            let flat = format!("meta/objects/{stem}.obj");
            let from = VPath::try_from_str(&format!("{ROOT}/{sharded}")).expect("from");
            let to = VPath::try_from_str(&format!("{ROOT}/{flat}")).expect("to");
            block_on_ready(fs.rename(&from, &to, Durability::D2, &ctx()))
                .expect("ready")
                .expect("flatten");
        }
        write_marker_v1(&fs);
    }

    let migrated = FsStore::open_with_migrations(
        Box::new(fs.clone()) as Box<dyn Fs>,
        ROOT,
        &caly_storage::migrations::production_migration_chain(),
        false,
    )
    .expect("the v1 flat store migrates to the sharded layout");
    let listed = block_on_ready(migrated.list_objects(&ctx()))
        .expect("no suspension")
        .expect("enumerate");
    let mut found: Vec<String> = listed
        .iter()
        .map(|object| object.digest.0.clone())
        .collect();
    let mut expected = keys.clone();
    found.sort();
    expected.sort();
    assert_eq!(found, expected, "the migration lost nothing");

    // Every record now lives in a bucket; the flat top level is gone.
    for name in list_names(&fs, "meta/objects") {
        assert_eq!(name.len(), 2, "only bucket names remain: {name:?}");
    }
    for digest in &keys {
        let stem = caly_storage::escape_component(digest);
        let bucket = caly_storage::record_shard(&stem);
        let names = list_names(&fs, &format!("meta/objects/{bucket}"));
        assert!(
            names.contains(&format!("{stem}.obj")),
            "the record moved into its bucket"
        );
    }

    // The marker advanced to the current version with the migration counted.
    let marker = read_marker_text(&fs);
    assert!(
        marker.contains(&format!("storage_schema={STORAGE_SCHEMA_VERSION}")),
        "the marker advanced: {marker}"
    );
    assert!(
        marker.contains("migrations_applied=1"),
        "the migration is counted, not reset: {marker}"
    );

    // §12.2.2: the rollback point holds the FLAT originals.
    for digest in &keys {
        let stem = caly_storage::escape_component(digest);
        let copy = read_raw(&fs, &format!("backups/v1/meta_objects_{stem}.obj"));
        assert!(
            copy.is_some(),
            "the rollback point copied the flat original of {digest}"
        );
    }

    // A second reopen must not migrate again (the marker is already current).
    let again = FsStore::open_with_migrations(
        Box::new(fs.clone()) as Box<dyn Fs>,
        ROOT,
        &caly_storage::migrations::production_migration_chain(),
        false,
    )
    .expect("reopen");
    let listed = block_on_ready(again.list_objects(&ctx()))
        .expect("no suspension")
        .expect("enumerate");
    assert_eq!(listed.len(), keys.len(), "the second reopen is stable");
    assert!(
        read_marker_text(&fs).contains("migrations_applied=1"),
        "no second migration ran"
    );
}

/// A record that lives in the WRONG bucket is refused by name at reopen: the whole
/// relative path is derived from the record's own name (`ADR-062 §2.1` extending
/// `ADR-041`), so a bucket it would never occupy is the same forgery a flattened-era
/// name always was.
#[test]
fn a_record_in_the_wrong_bucket_is_refused_by_name_at_reopen() {
    let fs = disk();
    {
        let store = FsStore::open(Box::new(fs.clone()) as Box<dyn Fs>, ROOT).expect("open");
        put_object(&store, "sha256:aaaa", b"aaaa");
        put_object(&store, "sha256:bbbb", b"bbbb");
    }
    let stem_a = caly_storage::escape_component("sha256:aaaa");
    let stem_b = caly_storage::escape_component("sha256:bbbb");
    let bucket_a = caly_storage::record_shard(&stem_a);
    let bucket_b = caly_storage::record_shard(&stem_b);
    if bucket_a == bucket_b {
        panic!("the fixture needs two distinct buckets");
    }
    let from =
        VPath::try_from_str(&format!("{ROOT}/meta/objects/{bucket_a}/{stem_a}.obj")).expect("from");
    let to =
        VPath::try_from_str(&format!("{ROOT}/meta/objects/{bucket_b}/{stem_a}.obj")).expect("to");
    block_on_ready(fs.rename(&from, &to, Durability::D2, &ctx()))
        .expect("ready")
        .expect("displace");

    let refused = FsStore::open(Box::new(fs) as Box<dyn Fs>, ROOT)
        .expect_err("a record in the wrong bucket must refuse the reopen");
    assert!(
        refused.summary.contains("legacy or forged naming"),
        "the refusal keeps its name: {refused:?}"
    );
    assert!(
        refused.summary.contains(&stem_a),
        "the refusal names the displaced record: {refused:?}"
    );
    assert!(
        refused.summary.contains("wrong bucket"),
        "the refusal says what is wrong with the path: {refused:?}"
    );
}

// ---- helpers ------------------------------------------------------------------

fn write_marker_v1(fs: &SimFs) {
    // The marker a v1 build would have left: same fields, version 1, no migrations.
    write_marker_raw(
        fs,
        &SchemaMarker {
            storage_schema: 1,
            written_by: None,
            created_at_unix_ms: 0,
            migrations_applied: 0,
        },
    );
}

fn write_marker_raw(fs: &SimFs, marker: &SchemaMarker) {
    caly_storage::schema::write_marker(fs as &dyn Fs, ROOT, &ctx(), marker).expect("marker");
}

fn read_marker_text(fs: &SimFs) -> String {
    read_raw(fs, caly_storage::schema::SCHEMA_SUFFIX).expect("marker")
}
