//! The durable store's driving budget (`ADR-036 §2.6`), and the kind a suspension keeps.
//!
//! Before this file, `FsStore` could express exactly one answer about a port: "be ready on the first
//! poll, or the store is broken" (`suspension()` mapped it to `StorageErrorKind::Internal`). That is
//! not a limit, it is a verdict, and it was wrong in two directions at once: a port that would have
//! answered on the third poll was called broken, and a port that never answers was called *broken*
//! rather than *busy* -- which is the difference between an operator restoring a disk and an operator
//! retrying. `crates/caly-storage/src/port_drive.rs` holds the budget; these tests are the boundary,
//! measured from both sides rather than asserted from the constant.

use caly_io::{block_on_ready, ByteCap, Fs, IoContext, VPath};
use caly_io_sim::{hang, stall, FaultInjector, MemFs, SharedFaults, SimFs};
use caly_storage::cas::{CasObjectRef, CasWriteIntent, ObjectDigest, ObjectKind};
use caly_storage::{FsStore, ObjectStore, STORE_PORT_POLL_BUDGET};
use caly_storage::{StorageError, StorageErrorKind};

const ROOT: &str = "var/caly";

fn disk() -> (SimFs, SharedFaults) {
    let faults = SharedFaults::new(FaultInjector::new(1));
    (SimFs::new(MemFs::default(), faults.clone()), faults)
}

fn ctx() -> IoContext {
    IoContext::new(
        caly_io::TraceId::new("store-port-budget"),
        caly_io::Actor::System,
    )
}

/// Drive a store future. The store itself never suspends -- it drives its own ports -- so the only
/// interesting outcome is the `Result` it resolves to.
fn done<T>(future: caly_io::BoxFuture<'_, Result<T, StorageError>>) -> Result<T, StorageError> {
    block_on_ready(future).expect("a storage future must not suspend")
}

fn ok<T: std::fmt::Debug>(future: caly_io::BoxFuture<'_, Result<T, StorageError>>) -> T {
    done(future).expect("storage call must succeed")
}

fn object(digest: &str) -> CasObjectRef {
    CasObjectRef {
        digest: ObjectDigest(digest.to_owned()),
        kind: ObjectKind::CompiledArtifact,
        size_bytes: None,
        content_type: Some("application/x-yaml".to_owned()),
        content_sha256: None,
        stored_at_unix_ms: Some(1_700_000_000_000),
    }
}

fn write_object(store: &FsStore, digest: &str, payload: &[u8]) -> CasObjectRef {
    ok(store.put(
        CasWriteIntent {
            object: object(digest),
            source_label: format!("{digest}.yaml"),
            payload: payload.to_vec(),
            stored_at_unix_ms: 1_700_000_000_000,
        },
        &ctx(),
    ))
}

/// A slow read is not a failed read. This is the sentence `ADR-036 §2.6` was written to make true:
/// without it, no port that suspends -- `Http`, a blocking pool, a chunked `read` -- can be written at
/// all against the durable store.
#[test]
fn a_port_that_stalls_inside_the_budget_still_answers_through_the_store() {
    let (fs, faults) = disk();
    let store = FsStore::open(Box::new(fs.clone()), ROOT).expect("open");
    write_object(&store, "mihomo:stall", b"config: answered late");

    faults.push(stall("fs.read", 3)).expect("arm one slow read");
    let read_back = done(store.read_object("mihomo:stall", 1 << 20, &ctx()))
        .expect("a port that answers on poll 4 answered")
        .expect("the object is there");
    assert_eq!(read_back, b"config: answered late");
}

/// ...and the same call, one layer down, on the write path -- which is where a real fsync lives, and
/// therefore where "suspends" is most plausible.
#[test]
fn a_stalled_write_is_not_an_internal_error_either() {
    let (fs, faults) = disk();
    let store = FsStore::open(Box::new(fs.clone()), ROOT).expect("open");
    faults
        .push(stall("fs.write_atomic", 2))
        .expect("arm one slow write");

    let written = write_object(&store, "mihomo:slowwrite", b"payload");
    assert_eq!(
        written.digest.0, "mihomo:slowwrite",
        "the write completed; nothing here may have been retried or invented"
    );
    // And the bytes really landed: a suspension that is driven to readiness must not be answered by a
    // "success" that wrote nothing.
    let anchor = written.content_sha256.clone().expect("anchor recorded");
    let content = VPath::try_from_str(&format!(
        "{ROOT}/{}",
        caly_storage::fs_store::content_suffix_for(&anchor)
    ))
    .expect("path");
    let bytes = block_on_ready(fs.read(&content, ByteCap(1024), &ctx()))
        .expect("ready")
        .expect("port ok");
    assert_eq!(bytes, b"payload");
}

/// A port that never answers is **busy**, with the driver's own text, and not "the store is broken".
/// The `assert_ne!` is the point of the whole file: `Internal` is what this call used to return, and
/// one layer up it was the difference between a retry and a restore.
#[test]
fn a_port_that_never_becomes_ready_is_reported_as_busy_not_as_a_broken_store() {
    let (fs, faults) = disk();
    let store = FsStore::open(Box::new(fs.clone()), ROOT).expect("open");
    write_object(&store, "mihomo:hang", b"config");

    faults.push(hang("fs.read")).expect("arm a hang");
    let error = done(store.read_object("mihomo:hang", 1 << 20, &ctx())).expect_err("stuck port");
    assert_eq!(error.kind, StorageErrorKind::Busy, "{error:?}");
    assert_ne!(
        error.kind,
        StorageErrorKind::Internal,
        "\"not yet\" may not be reported as \"corrupt\": the operator actions are opposites"
    );
    assert!(
        error.summary.contains(&format!(
            "still pending after {STORE_PORT_POLL_BUDGET} poll(s)"
        )),
        "the driver's own words, verbatim, with the number it actually used: {}",
        error.summary
    );
}

/// The budget is a boundary, so it has to be crossed from both sides. If the constant were lowered to
/// `1` -- i.e. the old behaviour with a name on it -- the first half of this test would fail, which is
/// what makes it a measurement rather than a restatement of the constant.
#[test]
fn the_budget_is_measured_from_both_sides() {
    for (polls, should_answer) in [
        (STORE_PORT_POLL_BUDGET - 1, true),
        (STORE_PORT_POLL_BUDGET, false),
    ] {
        let (fs, faults) = disk();
        let store = FsStore::open(Box::new(fs.clone()), ROOT).expect("open");
        write_object(&store, "mihomo:edge", b"config");
        faults
            .push(stall("fs.read", polls))
            .expect("arm a stall at the edge");
        let outcome = done(store.read_object("mihomo:edge", 1 << 20, &ctx()));
        match should_answer {
            true => assert!(
                outcome.as_ref().is_ok_and(|bytes| bytes.as_deref() == Some(&b"config"[..])),
                "{polls} polls of stall is inside a budget of {STORE_PORT_POLL_BUDGET}: {outcome:?}"
            ),
            false => {
                let error = outcome.expect_err("{polls} polls is one past the budget");
                assert_eq!(error.kind, StorageErrorKind::Busy, "{error:?}");
            }
        }
    }
}

/// One armed stall buys one slow call, and nothing after it. A fault that leaked would make the
/// positive test above pass for the wrong reason (every read slow, and the budget doing the waiting).
#[test]
fn the_stall_is_charged_to_one_call_and_not_to_the_store() {
    let (fs, faults) = disk();
    let store = FsStore::open(Box::new(fs.clone()), ROOT).expect("open");
    write_object(&store, "mihomo:once", b"config");
    write_object(&store, "mihomo:twice", b"other");

    faults
        .push(stall("fs.read", 4))
        .expect("arm exactly one slow read");
    let first = done(store.read_object("mihomo:once", 1 << 20, &ctx())).expect("slow, then fine");
    let second = done(store.read_object("mihomo:twice", 1 << 20, &ctx())).expect("and no slower");
    assert_eq!(first.expect("object").as_slice(), b"config");
    assert_eq!(second.expect("object").as_slice(), b"other");
    // Nothing is left armed: a third call must be answered by the port, not by the fault list.
    assert!(done(store.read_object("mihomo:once", 1 << 20, &ctx())).is_ok());
}

/// The durable store sets **no** byte budget of its own, and that is a decision worth a test: its
/// `IoContext` is created once at `open` and shared by every caller, so a ceiling placed there would
/// accumulate over a whole process and refuse the next innocent write. `RFC-0006 §5.3`'s bound belongs to
/// the caller's context, not to the store's long-lived one -- and this is the assertion that keeps it
/// there (`ADR-036 §6bis-decies`).
#[test]
fn the_store_invents_no_byte_ceiling_of_its_own() {
    let (fs, _faults) = disk();
    let store = FsStore::open(Box::new(fs.clone()), ROOT).expect("open");
    let big = vec![b'q'; 4 * 1024 * 1024];
    write_object(&store, "mihomo:fat", &big);
    let read_back = done(store.read_object("mihomo:fat", 8 * 1024 * 1024, &ctx()))
        .expect("readable")
        .expect("present");
    assert_eq!(read_back.len(), big.len(), "and it comes back whole");
}

/// The store does not keep a second poll loop. `caly_io::drive` is the only production place that
/// builds a waker, and `port_drive` calls it; a local copy here would be how the two start disagreeing
/// about what "give up" means -- the exact defect `caly-engine::run_ready` had before it delegated.
#[test]
fn the_store_drives_through_the_shared_helper_and_nothing_else() {
    let source = include_str!("../src/port_drive.rs");
    assert_eq!(
        source.matches("Waker::noop").count(),
        0,
        "`port_drive.rs` must not grow its own poll loop"
    );
    assert_eq!(
        source.matches("caly_io::drive(").count() + source.matches("drive(future, ").count(),
        1,
        "exactly one call into the shared driver, and it is inside `drive_port`"
    );
    // Which files may drive a port at all is the architecture gate's job
    // (`dependency_direction.rs::the_durable_store_drives_ports_through_the_shared_budget`), because a
    // local text check here cannot see a *new* file that grows its own loop.
}
