//! Enumerating registered revisions — the GC root that could not be assembled before.
//!
//! `RevisionStore` exposed `put` / `get`: enough to write a revision down and look it up by id, not
//! enough to answer "which revisions exist". That is not a nicety. `RFC-0007 §13.1` makes
//! 已登记 Revision a root of the collector, so without enumeration either the collector ignores a
//! whole root class (and deletes content a revision still names) or it refuses to run forever.
//! `ADR-038 §1` adds the query, and these tests pin the two properties that make it safe to build
//! on: the two backends agree, and a backend that cannot answer **says so** instead of reporting an
//! empty set — because "no revisions" is a statement that licenses deletion.

use caly_io::{block_on_ready, Durability, Fs, IoContext, VPath};
use caly_io_sim::{FaultInjector, MemFs, SharedFaults, SimFs};
use caly_storage::fs_store::FsStore;
use caly_storage::revision::{RevisionId, RevisionNumber, RevisionRecord};
use caly_storage::{BoxFuture, InMemoryStorage, RevisionStore, StorageError, StorageErrorKind};

const ROOT: &str = "var/caly";

fn ctx() -> IoContext {
    IoContext::new(caly_io::TraceId::new("revisions"), caly_io::Actor::System)
}

fn done<T>(future: BoxFuture<'_, Result<T, StorageError>>) -> Result<T, StorageError> {
    block_on_ready(future).expect("a storage future must not suspend")
}

fn ok<T: std::fmt::Debug>(future: BoxFuture<'_, Result<T, StorageError>>) -> T {
    done(future).expect("storage call must succeed")
}

fn disk() -> SimFs {
    SimFs::new(MemFs::default(), SharedFaults::new(FaultInjector::new(1)))
}

fn revision(id: &str, number: u64, digest: &str) -> RevisionRecord {
    RevisionRecord {
        id: RevisionId(id.to_owned()),
        number: RevisionNumber(number),
        profile_id: "demo-profile".to_owned(),
        semantic_digest: digest.to_owned(),
        created_at_unix_ms: number as i64,
    }
}

/// A backend that implements only the two required methods: what an integrator gets for the
/// enumeration hook without writing a line about it.
#[derive(Default)]
struct RevisionsOnly;

impl RevisionStore for RevisionsOnly {
    fn put_revision<'a>(
        &'a self,
        _record: RevisionRecord,
    ) -> BoxFuture<'a, Result<(), StorageError>> {
        Box::pin(async { Ok(()) })
    }

    fn get_revision<'a>(
        &'a self,
        _revision_id: &'a RevisionId,
    ) -> BoxFuture<'a, Result<Option<RevisionRecord>, StorageError>> {
        Box::pin(async { Ok(None) })
    }
}

#[test]
fn a_backend_that_cannot_enumerate_refuses_rather_than_reporting_an_empty_set() {
    let store = RevisionsOnly;
    let failure =
        done(store.list_revisions()).expect_err("the trait default must refuse to answer");
    assert_eq!(failure.kind, StorageErrorKind::Unsupported);
    assert!(
        failure.summary.contains("enumerate"),
        "the refusal has to name what is missing: {}",
        failure.summary
    );
    // A caller that treats this as "no revisions" would be concluding the opposite of what was said.
    assert_ne!(failure.kind, StorageErrorKind::NotFound);
}

#[test]
fn both_backends_answer_the_same_question_with_the_same_rows() {
    let memory = InMemoryStorage::new();
    let durable = FsStore::open(Box::new(disk()), ROOT).expect("fresh store");
    // Trait objects, so the two backends are driven by *the same* calls rather than by two copies of
    // the assertion that could drift apart.
    let backends: Vec<(&str, &dyn RevisionStore)> =
        vec![("in-memory", &memory), ("fs-store", &durable)];
    for (backend, store) in backends {
        ok(store.put_revision(revision("rev:03", 3, "sem:c")));
        ok(store.put_revision(revision("rev:01", 1, "sem:a")));
        ok(store.put_revision(revision("rev:02", 2, "sem:b")));
        let listed = ok(store.list_revisions());
        let rows: Vec<(String, String)> = listed
            .iter()
            .map(|record| (record.id.0.clone(), record.semantic_digest.clone()))
            .collect();
        assert_eq!(
            rows,
            vec![
                ("rev:01".to_owned(), "sem:a".to_owned()),
                ("rev:02".to_owned(), "sem:b".to_owned()),
                ("rev:03".to_owned(), "sem:c".to_owned()),
            ],
            "{backend}: sorted by id, and the digest has to travel with it or the root is useless"
        );
    }
}

#[test]
fn the_durable_enumeration_is_the_directory_and_survives_a_restart() {
    let fs = disk();
    let store = FsStore::open(Box::new(fs.clone()), ROOT).expect("fresh store");
    ok(store.put_revision(revision("rev:01", 1, "sem:a")));
    ok(store.put_revision(revision("rev:02", 2, "sem:b")));

    let reopened = FsStore::open(Box::new(fs.clone()), ROOT).expect("reopen");
    assert_eq!(
        ok(reopened.list_revisions()).len(),
        2,
        "a restart has nothing but the directory, so the directory must be enough"
    );

    // And a record that is gone is gone: `ADR-035 §2.3` made the listing the single truth, which
    // means enumeration cannot keep reporting a revision whose file somebody removed.
    let victim = VPath::try_from_str("var/caly/records/revision/rev_01.rec").expect("path");
    block_on_ready(fs.remove(&victim, &ctx()))
        .expect("ready")
        .expect("remove");
    let ids: Vec<String> = ok(reopened.list_revisions())
        .into_iter()
        .map(|record| record.id.0)
        .collect();
    assert_eq!(ids, vec!["rev:02".to_owned()]);
}

#[test]
fn a_torn_revision_record_aborts_the_enumeration() {
    let fs = disk();
    let store = FsStore::open(Box::new(fs.clone()), ROOT).expect("fresh store");
    ok(store.put_revision(revision("rev:01", 1, "sem:a")));
    ok(store.put_revision(revision("rev:02", 2, "sem:b")));

    // Damage one record after the store is open, so the cache still looks fine and only a real read
    // can notice. An enumeration used for a deletion decision must never answer "the rest is safe".
    let damaged = VPath::try_from_str("var/caly/records/revision/rev_01.rec").expect("path");
    block_on_ready(fs.write_atomic(&damaged, b"not a record".to_vec(), Durability::D1, &ctx()))
        .expect("ready")
        .expect("damage");

    let failure = done(store.list_revisions()).expect_err("a corrupt record must surface");
    assert_eq!(
        failure.kind,
        StorageErrorKind::IntegrityViolation,
        "{failure:?}"
    );
    assert!(
        !failure.summary.contains("rev:02"),
        "the message must not smuggle in the surviving record as if it were the whole set: {failure:?}"
    );
}
