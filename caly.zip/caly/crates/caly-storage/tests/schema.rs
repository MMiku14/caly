//! The storage schema gate (`RFC-0007 §12`, acceptance `§15.5`).
//!
//! `STORAGE_SCHEMA_VERSION` used to be a constant that nothing read and nothing wrote, so
//! "schema mismatch at startup" had no defined behaviour: a v0 directory would simply have been
//! opened as v1. These tests pin the four `§12.2` rules and `§12.3`, on a fake filesystem so the
//! file-level effects (marker written, rollback point created, old marker preserved) are observable.

use caly_io::{block_on_ready, ByteCap, Durability, Fs, IoContext, VPath};
use caly_io_sim::{FaultInjector, MemFs, SharedFaults, SimFs};
use caly_storage::fs_store::FsStore;
use caly_storage::schema::{
    classify, create_rollback_point, gate, read_marker, write_marker, MigrationChain,
    MigrationHook, SchemaMarker, SchemaVerdict, SCHEMA_SUFFIX,
};
use caly_storage::snapshot::{SnapshotRecord, SnapshotRecordId};
use caly_storage::{SnapshotStore, STORAGE_SCHEMA_VERSION};
use std::sync::atomic::{AtomicBool, Ordering};

const ROOT: &str = "var/caly";

fn disk() -> SimFs {
    SimFs::new(MemFs::default(), SharedFaults::new(FaultInjector::new(1)))
}

fn ctx() -> IoContext {
    IoContext::new(caly_io::TraceId::new("schema"), caly_io::Actor::System)
}

fn read(fs: &SimFs, suffix: &str) -> Option<String> {
    let path = VPath::try_from_str(&format!("{ROOT}/{suffix}")).expect("path");
    block_on_ready(fs.read(&path, ByteCap(1 << 16), &ctx()))
        .expect("ready")
        .ok()
        .map(|bytes| String::from_utf8_lossy(&bytes).into_owned())
}

fn write(fs: &SimFs, suffix: &str, text: &str) {
    let path = VPath::try_from_str(&format!("{ROOT}/{suffix}")).expect("path");
    block_on_ready(fs.write_atomic(&path, text.as_bytes().to_vec(), Durability::D3, &ctx()))
        .expect("ready")
        .expect("write");
}

/// Advances the layout and records that it ran.
#[derive(Clone, Default)]
struct RenameJournalDir {
    ran: std::sync::Arc<AtomicBool>,
}

impl MigrationHook for RenameJournalDir {
    fn source_version(&self) -> u32 {
        1
    }
    fn target_version(&self) -> u32 {
        2
    }
    fn description(&self) -> String {
        "move apply journals under journals/apply".to_owned()
    }
    fn apply(&self, _fs: &dyn Fs, _root: &str, _ctx: &IoContext) -> Result<(), String> {
        self.ran.store(true, Ordering::SeqCst);
        Ok(())
    }
}

#[derive(Default)]
struct BrokenHook {
    started: std::sync::Arc<AtomicBool>,
}

impl MigrationHook for BrokenHook {
    fn source_version(&self) -> u32 {
        1
    }
    fn target_version(&self) -> u32 {
        2
    }
    fn description(&self) -> String {
        "half-finished experiment".to_owned()
    }
    fn apply(&self, fs: &dyn Fs, root: &str, ctx: &IoContext) -> Result<(), String> {
        self.started.store(true, Ordering::SeqCst);
        // Touch something, then fail: the rollback point is what makes this recoverable to read.
        let path = VPath::try_from_str(&format!("{root}/migrated.partial")).expect("path");
        let written =
            block_on_ready(fs.write_atomic(&path, b"partial".to_vec(), Durability::D1, ctx))
                .expect("a fake port never suspends");
        written.map_err(|fault| fault.summary)?;
        Err("hook died halfway".to_owned())
    }
}

// ---- pure classification -------------------------------------------------------------------

#[test]
fn classify_distinguishes_absent_corrupt_and_both_directions() {
    assert_eq!(classify(None, 5), SchemaVerdict::Absent);
    assert_eq!(classify(Some(Ok(5)), 5), SchemaVerdict::Current);
    assert_eq!(classify(Some(Ok(3)), 5), SchemaVerdict::Older { found: 3 });
    assert_eq!(classify(Some(Ok(7)), 5), SchemaVerdict::Newer { found: 7 });
    assert_eq!(
        classify(Some(Err("junk".to_owned())), 5),
        SchemaVerdict::Corrupt {
            reason: "junk".to_owned()
        }
    );

    let corrupt = SchemaVerdict::Corrupt {
        reason: "x".to_owned(),
    };
    assert!(corrupt.is_fatal(), "an unreadable marker is fatal");
    assert!(
        SchemaVerdict::Newer { found: 9 }.is_fatal(),
        "a future layout is fatal"
    );
    assert!(!SchemaVerdict::Older { found: 1 }.is_fatal());
    assert!(SchemaVerdict::Older { found: 1 }.needs_migration());
    assert_eq!(SchemaVerdict::Newer { found: 9 }.found_version(), Some(9));
    assert_eq!(SchemaVerdict::Absent.found_version(), None);
}

#[test]
fn a_migration_plan_must_be_stepwise_and_forward_only() {
    let ran = std::sync::Arc::new(AtomicBool::new(false));
    let chain = MigrationChain::default()
        .with(RenameJournalDir { ran: ran.clone() })
        .with(SkipAhead);

    assert_eq!(chain.plan(1, 2).expect("contiguous"), vec![0]);
    // v1 -> v3 must run v1->v2 then v2->v3; skipping a step is skipping its invariants.
    assert_eq!(chain.plan(1, 3).expect("two steps"), vec![0, 1]);
    assert_eq!(chain.len(), 2);
    assert!(!chain.is_empty());

    let backwards = chain.plan(3, 2).expect_err("migrations only move forward");
    assert!(backwards.contains("must move forward"), "{backwards}");
    let same = chain.plan(2, 2).expect_err("nothing to do is not a plan");
    assert!(same.contains("must move forward"), "{same}");

    let holes = MigrationChain::default().with(SkipAhead);
    let error = holes.plan(1, 3).expect_err("a v2 step must exist");
    assert!(error.contains("no migration step v1 -> v2"), "{error}");
    assert!(
        !ran.load(Ordering::SeqCst),
        "planning must not run anything"
    );
}

#[derive(Default)]
struct SkipAhead;

impl MigrationHook for SkipAhead {
    fn source_version(&self) -> u32 {
        2
    }
    fn target_version(&self) -> u32 {
        3
    }
    fn description(&self) -> String {
        "v2 -> v3".to_owned()
    }
    fn apply(&self, _fs: &dyn Fs, _root: &str, _ctx: &IoContext) -> Result<(), String> {
        Ok(())
    }
}

// ---- the gate, on a filesystem -------------------------------------------------------------

#[test]
fn a_fresh_store_is_initialised_once_and_never_rewritten_on_read() {
    let fs = disk();
    let marker = gate(
        &fs,
        ROOT,
        &ctx(),
        STORAGE_SCHEMA_VERSION,
        &MigrationChain::empty(),
        false,
    )
    .expect("a verified-empty directory is initialisable");
    assert_eq!(marker.storage_schema, STORAGE_SCHEMA_VERSION);
    assert_eq!(marker.migrations_applied, 0);

    let on_disk = read(&fs, SCHEMA_SUFFIX).expect("marker file");
    assert!(on_disk.contains("storage_schema=1"), "{on_disk}");

    // A second open must not touch the file: an open is a read.
    write(
        &fs,
        SCHEMA_SUFFIX,
        &on_disk.replace(
            "storage_schema=1",
            "storage_schema=1\nwritten_by=operator-note",
        ),
    );
    let again = gate(
        &fs,
        ROOT,
        &ctx(),
        STORAGE_SCHEMA_VERSION,
        &MigrationChain::empty(),
        false,
    )
    .expect("current marker opens cleanly");
    assert_eq!(
        again.written_by.as_deref(),
        Some("operator-note"),
        "the gate must read the existing marker rather than fabricate one"
    );
    assert!(
        read(&fs, SCHEMA_SUFFIX)
            .expect("marker")
            .contains("operator-note"),
        "the file must not have been rewritten"
    );
}

#[test]
fn a_store_with_data_but_no_marker_is_refused_not_assumed_current() {
    let fs = disk();
    // Simulate a pre-versioning directory: data, no marker. The data has to be a *record* in a
    // directory the layout owns, because `has_any` now enumerates the store's own directories
    // instead of probing a handful of known index names (`ADR-035 §2.3`).
    write(&fs, "records/snapshot/a.rec", "record:v1\nid=snapshot:1\n");

    let refusal = gate(
        &fs,
        ROOT,
        &ctx(),
        STORAGE_SCHEMA_VERSION,
        &MigrationChain::empty(),
        false,
    )
    .expect_err("§12.3 forbids reading an unknown layout as current");
    assert!(
        refusal.summary.contains("no schema marker") || refusal.summary.contains(SCHEMA_SUFFIX),
        "{}",
        refusal.summary
    );
    assert!(
        refusal
            .summary
            .contains("refusing to read an unknown layout"),
        "{}",
        refusal.summary
    );
}

#[test]
fn an_empty_directory_without_a_marker_may_be_claimed_fresh() {
    let fs = disk();
    let marker = gate(
        &fs,
        ROOT,
        &ctx(),
        STORAGE_SCHEMA_VERSION,
        &MigrationChain::empty(),
        true,
    )
    .expect("an empty directory may be claimed fresh");
    assert_eq!(marker.storage_schema, STORAGE_SCHEMA_VERSION);
}

#[test]
fn a_newer_store_is_refused_without_being_interpreted() {
    let fs = disk();
    write_marker(
        &fs,
        ROOT,
        &ctx(),
        &SchemaMarker {
            storage_schema: STORAGE_SCHEMA_VERSION + 4,
            written_by: Some("a future build".to_owned()),
            created_at_unix_ms: 0,
            migrations_applied: 3,
        },
    )
    .expect("seed the future marker");

    let refusal = gate(
        &fs,
        ROOT,
        &ctx(),
        STORAGE_SCHEMA_VERSION,
        &MigrationChain::empty(),
        false,
    )
    .expect_err("forward compatibility cannot be assumed from a format you have not read");
    assert!(
        refusal.summary.contains("§12.3"),
        "the message must cite the rule it enforces: {}",
        refusal.summary
    );
    assert!(refusal.summary.contains("v5"), "{}", refusal.summary);

    // Nothing was written, and the future marker is intact for a build that can read it.
    let intact = read_marker(&fs, ROOT, &ctx())
        .expect("read")
        .expect("present")
        .expect("parses");
    assert_eq!(intact.storage_schema, STORAGE_SCHEMA_VERSION + 4);
    assert_eq!(intact.migrations_applied, 3);
}

#[test]
fn an_unreadable_marker_is_refused_rather_than_treated_as_absent() {
    let fs = disk();
    write(&fs, SCHEMA_SUFFIX, "this is not a record\n");
    let refusal = gate(
        &fs,
        ROOT,
        &ctx(),
        STORAGE_SCHEMA_VERSION,
        &MigrationChain::empty(),
        false,
    )
    .expect_err("a damaged marker must not be read as a fresh directory");
    assert!(
        refusal.summary.contains("unreadable"),
        "{}",
        refusal.summary
    );
    assert!(refusal.failed_migration.is_none());
    // The damaged file must be preserved for diagnosis.
    assert!(read(&fs, SCHEMA_SUFFIX)
        .unwrap()
        .contains("this is not a record"));
}

#[test]
fn an_older_store_without_a_path_is_refused_by_name() {
    let fs = disk();
    write_marker(
        &fs,
        ROOT,
        &ctx(),
        &SchemaMarker {
            storage_schema: 1,
            written_by: None,
            created_at_unix_ms: 7,
            migrations_applied: 0,
        },
    )
    .expect("seed v1");

    let refusal = gate(&fs, ROOT, &ctx(), 4, &MigrationChain::empty(), false)
        .expect_err("v1 -> v4 has no path here");
    assert!(
        refusal.summary.contains("no migration step v1 -> v2"),
        "the refusal must say which step is missing: {}",
        refusal.summary
    );
    assert!(
        refusal.rollback_point.is_none(),
        "nothing ran, so nothing was copied"
    );
}

#[test]
fn a_contiguous_chain_migrates_records_history_and_creates_a_rollback_point() {
    let fs = disk();
    write_marker(
        &fs,
        ROOT,
        &ctx(),
        &SchemaMarker {
            storage_schema: 1,
            written_by: None,
            created_at_unix_ms: 1234,
            migrations_applied: 2,
        },
    )
    .expect("seed v1");
    write(
        &fs,
        "records/apply-journal/x.rec",
        "record:v1\napply_txn_id=txn_x\nstate=pending\n",
    );

    let ran = std::sync::Arc::new(AtomicBool::new(false));
    let chain = MigrationChain::default().with(RenameJournalDir { ran: ran.clone() });

    let marker = gate(&fs, ROOT, &ctx(), 2, &chain, false).expect("v1 -> v2 must migrate");
    assert!(ran.load(Ordering::SeqCst), "the hook must have run");
    assert_eq!(marker.storage_schema, 2);
    assert_eq!(
        marker.migrations_applied, 3,
        "the count accumulates instead of resetting"
    );
    assert_eq!(
        marker.created_at_unix_ms, 1234,
        "the original creation time is preserved"
    );
    assert_eq!(marker.written_by.as_deref(), Some("migrated from v1"));

    // `§12.2.2`: the rollback point exists and still holds the OLD version.
    let backup = read(&fs, "backups/v1/schema_storage.rec").expect("backup marker");
    assert!(backup.contains("storage_schema=1"), "{backup}");
    // The rollback point holds the *record*, not an index naming it: after `ADR-035` step 2 there is
    // nothing else to copy, and copying a description would answer "what did the store claim" only
    // as well as the claim did.
    let journal_copy = read(&fs, "backups/v1/records_apply-journal_x.rec").expect("record copy");
    assert!(
        journal_copy.contains("apply_txn_id=txn_x"),
        "the backup must hold the record itself: {journal_copy}"
    );
    assert!(
        read(&fs, "backups/v1/manifest_apply-journal.idx").is_none(),
        "there is no index layer left to copy"
    );

    assert_eq!(
        read_marker(&fs, ROOT, &ctx())
            .expect("read")
            .expect("present")
            .expect("parses")
            .storage_schema,
        2,
        "the live marker must be updated only after the hooks succeed"
    );
}

#[test]
fn a_failing_hook_leaves_the_store_on_the_old_version_and_refuses_startup() {
    let fs = disk();
    write_marker(
        &fs,
        ROOT,
        &ctx(),
        &SchemaMarker {
            storage_schema: 1,
            written_by: None,
            created_at_unix_ms: 9,
            migrations_applied: 0,
        },
    )
    .expect("seed v1");
    write(&fs, "records/snapshot/a.rec", "record:v1\nid=snapshot:1\n");
    let started = std::sync::Arc::new(AtomicBool::new(false));

    let refusal = gate(
        &fs,
        ROOT,
        &ctx(),
        2,
        &MigrationChain::default().with(BrokenHook {
            started: started.clone(),
        }),
        false,
    )
    .expect_err("§12.2.3: a failed migration must refuse startup");
    assert!(
        started.load(Ordering::SeqCst),
        "the hook did start before failing"
    );
    assert!(
        refusal.summary.contains("startup is refused"),
        "{}",
        refusal.summary
    );
    let detail = refusal
        .failed_migration
        .as_deref()
        .expect("the underlying reason must be reported");
    assert!(detail.contains("hook died halfway"), "{detail}");
    assert!(
        detail.contains("half-finished experiment"),
        "the planned step description must be reported too: {detail}"
    );
    assert!(
        refusal.rollback_point.is_some(),
        "{:?}",
        refusal.rollback_point
    );

    // The marker still says v1: a later build cannot mistake this for a migrated store.
    assert_eq!(
        read_marker(&fs, ROOT, &ctx())
            .expect("read")
            .expect("present")
            .expect("parses")
            .storage_schema,
        1
    );
    let backup = read(&fs, "backups/v1/schema_storage.rec").expect("rollback point");
    assert!(backup.contains("storage_schema=1"), "{backup}");
}

#[test]
fn a_rollback_point_over_nothing_is_refused() {
    let fs = disk();
    let error = create_rollback_point(&fs, ROOT, 1, &ctx())
        .expect_err("there is nothing to copy, so there is no rollback point");
    assert_eq!(error.kind, caly_storage::StorageErrorKind::NotFound);
    assert!(
        error.summary.contains("no schema marker"),
        "{}",
        error.summary
    );
}

// ---- store-level integration ---------------------------------------------------------------

#[test]
fn fs_store_writes_the_marker_on_first_open_and_reopens_against_it() {
    let fs = disk();
    let store = FsStore::open(Box::new(fs.clone()) as Box<dyn Fs>, ROOT).expect("first open");
    assert_eq!(store.storage_schema_version(), STORAGE_SCHEMA_VERSION);
    assert!(read(&fs, SCHEMA_SUFFIX)
        .expect("marker")
        .contains("storage_schema=1"));

    // A second store over the same directory must pass the gate and see the same data.
    let id = SnapshotRecordId("snapshot:reopened".to_owned());
    block_on_ready(store.put_snapshot(
        SnapshotRecord {
            id: id.clone(),
            revision_id: caly_storage::RevisionId("rev-1".to_owned()),
            revision_number: caly_storage::RevisionNumber(1),
            profile_id: "p".to_owned(),
            semantic_digest: "sem".to_owned(),
            compiled_artifact_digest: "art".to_owned(),
            core_binary_digest: "bin".to_owned(),
            core_identity: "mihomo@1".to_owned(),
            apply_plan_summary: "Restart".to_owned(),
            journal_id: None,
            selection_memory_digest: None,
            validation_summary: "ok".to_owned(),
            created_at_unix_ms: 1,
            is_last_known_good: true,
        },
        &ctx(),
    ))
    .expect("ready")
    .expect("snapshot commit");
    drop(store);

    let reopened = FsStore::open(Box::new(fs) as Box<dyn Fs>, ROOT).expect("second open");
    let lkg = block_on_ready(reopened.latest_last_known_good(&ctx()))
        .expect("ready")
        .expect("read")
        .expect("the snapshot must survive");
    assert_eq!(lkg.id, id);
}

#[test]
fn fs_store_refuses_a_store_whose_marker_is_from_the_future() {
    let fs = disk();
    // First open at the current version, then forge a newer marker.
    drop(FsStore::open(Box::new(fs.clone()) as Box<dyn Fs>, ROOT).expect("open"));
    write(
        &fs,
        SCHEMA_SUFFIX,
        "record:v1\nstorage_schema=99\ncreated_at=0\nmigrations_applied=0\n",
    );

    let failure =
        FsStore::open(Box::new(fs), ROOT).expect_err("a future layout must not be opened");
    assert!(
        failure.summary.contains("schema gate refused"),
        "{}",
        failure.summary
    );
    let schema = failure.schema.expect("the refusal must be typed");
    assert!(schema.summary.contains("§12.3"), "{}", schema.summary);
    assert!(schema.failed_migration.is_none());
}
