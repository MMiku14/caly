//! One contract, both storage backends.
//!
//! `RFC-0006 §15` already demands that the *port* layer pass the same tests on the simulator and on
//! the real filesystem, and `caly-io::contract` is where that happens. The **store** had no
//! equivalent: `InMemoryStorage` and `FsStore` were each tested on their own, so a behaviour could
//! exist in one and not the other and nothing went red. Two such divergences were found while adding
//! `read_object` and are pinned here:
//!
//! - `materialize` of a metadata-only record: `FsStore` refused, `InMemoryStorage` answered `Ok(())`
//!   — a caller that swapped backends silently lost a guarantee (`docs/ONBOARDING_NOTES.md §4.45`).
//! - `put` with a declared `content_sha256` that does not match the payload: `FsStore` refused,
//!   `InMemoryStorage` overwrote the caller's claim (`§4.46`).
//!
//! Every test below runs against **both** backends with the same assertions.

use caly_io::{block_on_ready, Fs, IoContext};
use caly_io_sim::{FaultInjector, MemFs, SharedFaults, SimFs};
use caly_storage::cas::{
    CasObjectRef, CasWriteIntent, MaterializationMode, ObjectDigest, ObjectKind,
};
use caly_storage::fs_store::FsStore;
use caly_storage::{InMemoryStorage, ObjectStore, StorageBackend, StorageError, StorageErrorKind};

const ROOT: &str = "var/caly";

/// Run `case` against every backend that must satisfy the contract.
fn for_each_backend(mut case: impl FnMut(&dyn StorageBackend, &'static str)) {
    let memory = InMemoryStorage::new();
    case(&memory, "in-memory");

    let fs = SimFs::new(MemFs::default(), SharedFaults::new(FaultInjector::new(1)));
    let durable =
        FsStore::open(Box::new(fs) as Box<dyn Fs>, ROOT).expect("a fresh store must open");
    case(&durable, "fs-store");
}

fn ctx() -> IoContext {
    IoContext::new(
        caly_io::TraceId::new("object-contract"),
        caly_io::Actor::System,
    )
}

fn done<T: std::fmt::Debug>(
    future: caly_storage::BoxFuture<'_, Result<T, StorageError>>,
    what: &str,
) -> T {
    block_on_ready(future)
        .unwrap_or_else(|message| panic!("{what}: the store suspended ({message})"))
        .unwrap_or_else(|error| panic!("{what}: {}", error.summary))
}

fn object(digest: &str, kind: ObjectKind, anchor: Option<String>) -> CasObjectRef {
    CasObjectRef {
        digest: ObjectDigest(digest.to_owned()),
        kind,
        size_bytes: None,
        content_type: Some("text/plain".to_owned()),
        content_sha256: anchor,
        stored_at_unix_ms: Some(1_700_000_000_000),
    }
}

fn write(
    store: &dyn StorageBackend,
    digest: &str,
    kind: ObjectKind,
    payload: &[u8],
    backend: &str,
) -> CasObjectRef {
    done(
        store.put(
            CasWriteIntent {
                object: object(digest, kind, None),
                source_label: format!("{digest}.txt"),
                payload: payload.to_vec(),
                stored_at_unix_ms: 1_700_000_000_000,
            },
            &ctx(),
        ),
        &format!("{backend}: put {digest}"),
    )
}

#[test]
fn content_written_with_a_payload_is_read_back_byte_for_byte() {
    for_each_backend(|store, backend| {
        let payload = b"first 40 bytes of a diagnostic export, and then some".to_vec();
        let meta = write(
            store,
            "sha256:aa11",
            ObjectKind::SupportBundle,
            &payload,
            backend,
        );
        assert_eq!(
            meta.size_bytes,
            Some(payload.len() as u64),
            "{backend}: the store records the size it wrote"
        );
        let anchor = meta
            .content_sha256
            .clone()
            .expect("a payload write records its own anchor");
        assert!(anchor.starts_with("sha256:"), "{backend}: {anchor}");

        let read = done(
            store.read_object("sha256:aa11", 1 << 20, &ctx()),
            &format!("{backend}: read back"),
        );
        assert_eq!(read.as_deref(), Some(payload.as_slice()), "{backend}");
    });
}

#[test]
fn an_unknown_digest_is_absent_rather_than_an_error() {
    for_each_backend(|store, backend| {
        let read = done(
            store.read_object("sha256:never-written", 1 << 20, &ctx()),
            &format!("{backend}: read unknown"),
        );
        assert_eq!(read, None, "{backend}: \"no such object\" is not a failure");
    });
}

#[test]
fn a_declared_anchor_that_does_not_match_the_payload_is_refused() {
    for_each_backend(|store, backend| {
        let lie = "sha256:0000000000000000000000000000000000000000000000000000000000000000";
        let outcome = block_on_ready(store.put(
            CasWriteIntent {
                object: object("sha256:bb22", ObjectKind::RawSource, Some(lie.to_owned())),
                source_label: "lied.txt".to_owned(),
                payload: b"real bytes".to_vec(),
                stored_at_unix_ms: 0,
            },
            &ctx(),
        ))
        .expect("no suspension");
        let error = match outcome {
            Ok(_) => {
                panic!("{backend}: a caller may not choose an anchor the payload does not match")
            }
            Err(error) => error,
        };
        assert_eq!(
            error.kind,
            StorageErrorKind::IntegrityViolation,
            "{backend}"
        );
    });
}

#[test]
fn a_record_without_content_can_be_neither_materialized_nor_read() {
    for_each_backend(|store, backend| {
        // `CasWriteIntent::metadata` is the documented "index an external blob" case.
        done(
            store.put(
                CasWriteIntent::metadata(
                    object("sha256:cc33", ObjectKind::RuleSet, None),
                    "external.txt",
                ),
                &ctx(),
            ),
            &format!("{backend}: metadata-only put"),
        );

        let materialize = block_on_ready(store.materialize(
            caly_storage::MaterializationRequest {
                object: object("sha256:cc33", ObjectKind::RuleSet, None),
                runtime_path: "runtime/candidate.yaml".to_owned(),
                mode: MaterializationMode::Copy,
            },
            &ctx(),
        ))
        .expect("no suspension");
        let error = match materialize {
            Ok(()) => {
                panic!("{backend}: materializing bytes that were never written is not success")
            }
            Err(error) => error,
        };
        assert_eq!(
            error.kind,
            StorageErrorKind::IntegrityViolation,
            "{backend}"
        );

        let read = block_on_ready(store.read_object("sha256:cc33", 1 << 20, &ctx()))
            .expect("no suspension")
            .expect_err(
                "{backend}: reading content that was never written must fail, not yield None",
            );
        assert_eq!(read.kind, StorageErrorKind::NotFound, "{backend}");
    });
}

#[test]
fn a_bound_smaller_than_the_object_is_reported_not_truncated() {
    for_each_backend(|store, backend| {
        write(
            store,
            "sha256:dd44",
            ObjectKind::CompiledArtifact,
            &[7u8; 512],
            backend,
        );
        let outcome =
            block_on_ready(store.read_object("sha256:dd44", 64, &ctx())).expect("no suspension");
        let error = match outcome {
            Ok(Some(bytes)) => panic!(
                "{backend}: a capped read returned {} bytes when the caller allowed 64",
                bytes.len()
            ),
            Ok(None) => panic!("{backend}: the object exists"),
            Err(error) => error,
        };
        assert_eq!(error.kind, StorageErrorKind::CapacityExceeded, "{backend}");
        assert!(
            error.summary.contains("512") && error.summary.contains("64"),
            "{backend}: the message must name both numbers: {}",
            error.summary
        );
    });
}

#[test]
fn deleting_an_object_takes_its_content_with_it() {
    for_each_backend(|store, backend| {
        write(
            store,
            "sha256:ee55",
            ObjectKind::SupportBundle,
            b"bundle bytes",
            backend,
        );
        assert!(
            done(
                store.delete("sha256:ee55", &ctx()),
                &format!("{backend}: delete existing")
            ),
            "{backend}: deleting a stored object reports that it removed something"
        );
        assert_eq!(
            done(
                store.read_object("sha256:ee55", 1 << 20, &ctx()),
                &format!("{backend}: read after delete")
            ),
            None,
            "{backend}: the content must not outlive the object"
        );
        assert!(
            !done(
                store.delete("sha256:ee55", &ctx()),
                &format!("{backend}: delete again")
            ),
            "{backend}: a second delete is not a success"
        );
    });
}

#[test]
fn a_backend_that_cannot_read_content_says_so_instead_of_returning_nothing() {
    // The default `Unsupported` answer is what keeps a future backend from looking empty. A store
    // that answers `Ok(None)` for everything would make `read_object` indistinguishable from "no
    // such object", which is how `§4.18`'s GC gap first appeared.
    /// A store that implements the required `ObjectStore` methods and nothing else: exactly what a
    /// minimal backend gets for the optional ones.
    struct MetadataOnly;
    impl ObjectStore for MetadataOnly {
        fn put<'a>(
            &'a self,
            _intent: CasWriteIntent,
            _ctx: &'a IoContext,
        ) -> caly_storage::BoxFuture<'a, Result<CasObjectRef, StorageError>> {
            unimplemented_box("put")
        }
        fn get<'a>(
            &'a self,
            _digest: &'a str,
            _ctx: &'a IoContext,
        ) -> caly_storage::BoxFuture<'a, Result<Option<CasObjectRef>, StorageError>> {
            unimplemented_box("get")
        }
        fn materialize<'a>(
            &'a self,
            _request: caly_storage::MaterializationRequest,
            _ctx: &'a IoContext,
        ) -> caly_storage::BoxFuture<'a, Result<(), StorageError>> {
            unimplemented_box("materialize")
        }
        fn list_objects<'a>(
            &'a self,
            _ctx: &'a IoContext,
        ) -> caly_storage::BoxFuture<'a, Result<Vec<CasObjectRef>, StorageError>> {
            unimplemented_box("list_objects")
        }
        fn delete<'a>(
            &'a self,
            _digest: &'a str,
            _ctx: &'a IoContext,
        ) -> caly_storage::BoxFuture<'a, Result<bool, StorageError>> {
            unimplemented_box("delete")
        }
    }
    let store = MetadataOnly;
    let error = block_on_ready(store.read_object("sha256:x", 10, &ctx()))
        .expect("no suspension")
        .expect_err("the trait default must refuse rather than yield None");
    assert_eq!(error.kind, StorageErrorKind::Unsupported);
}

fn unimplemented_box<T>(what: &str) -> caly_storage::BoxFuture<'static, Result<T, StorageError>> {
    let what = what.to_owned();
    Box::pin(async move {
        Err(StorageError::new(
            StorageErrorKind::Internal,
            format!("this stub does not implement {what}"),
        ))
    })
}

/// Integrity on **read**, not only on write.
///
/// `read_object` re-checks the bytes against the recorded anchor, which is the only thing standing
/// between "the store's index says this digest" and "a client is handed content nobody verified".
/// Durable and memory backends can only be tampered with the same way if the durable one is reached
/// through its own filesystem, so this case runs against `FsStore` alone — and `InMemoryStorage`
/// cannot even be reached from outside, which is why the assertion is not duplicated.
#[test]
fn tampered_content_is_refused_on_read_rather_than_handed_back() {
    let fs = SimFs::new(MemFs::default(), SharedFaults::new(FaultInjector::new(1)));
    let store = FsStore::open(Box::new(fs.clone()) as Box<dyn Fs>, ROOT).expect("open");
    let meta = write(
        &store,
        "sha256:ff66",
        ObjectKind::SupportBundle,
        b"original bytes of the export".to_vec().as_slice(),
        "fs-store",
    );
    let anchor = meta.content_sha256.clone().expect("anchor recorded");
    let content_path = caly_storage::fs_store::content_suffix_for(&anchor);
    let path = format!("{ROOT}/{content_path}");
    let vpath = caly_io::VPath::try_from_str(&path).expect("relative path");
    caly_io::block_on_ready(fs.write_atomic(
        &vpath,
        b"tampered bytes of the export".to_vec(),
        caly_io::Durability::D1,
        &caly_io::IoContext::new(caly_io::TraceId::new("tamper"), caly_io::Actor::System),
    ))
    .expect("no suspension")
    .expect("the test must be able to corrupt the file");

    let error = block_on_ready(store.read_object("sha256:ff66", 1 << 20, &ctx()))
        .expect("no suspension")
        .expect_err("a store that returns mutated content is worse than one that errors");
    assert_eq!(error.kind, StorageErrorKind::IntegrityViolation);
    assert!(
        error.summary.contains("sha256:ff66"),
        "the refusal must name the object: {}",
        error.summary
    );
}

/// The content-tree door, same assertions on both backends: content a live object names is
/// **refused** at deletion, content nobody names is removed and answers `false` the second time,
/// and a residue target this backend never wrote is a no-op rather than an error. The two halves
/// of this contract are the sweep's safety invariant and its liveness, pinned where a divergence
/// between the backends would otherwise live undetected (the same reason this file exists).
#[test]
fn the_content_tree_door_answers_the_same_way_on_both_backends() {
    for_each_backend(|store, backend| {
        let owned = write(
            store,
            "obj:owned",
            ObjectKind::RawSource,
            b"owned bytes",
            backend,
        );
        let anchor = owned
            .content_sha256
            .clone()
            .expect("the store records its anchor");

        // Referenced: refused, and the refusal names the anchor.
        let error = match block_on_ready(store.delete_content(
            &caly_storage::gc::ContentTarget::Anchor(anchor.clone()),
            &ctx(),
        )) {
            Ok(Ok(_)) => panic!("{backend}: referenced content must be refused, not deleted"),
            Ok(Err(failure)) => failure,
            Err(message) => panic!("{backend}: the store suspended ({message})"),
        };
        assert_eq!(
            error.kind,
            StorageErrorKind::IntegrityViolation,
            "{backend}: {}",
            error.summary
        );
        assert!(
            error.summary.contains(&anchor),
            "{backend}: the refusal names what it kept: {}",
            error.summary
        );

        // Unknown anchor: a no-op that says so, not an error and not a silent true.
        let missing = match block_on_ready(store.delete_content(
            &caly_storage::gc::ContentTarget::Anchor(
                // A digest-shaped anchor nothing owns: full length, zero references.
                format!("sha256:{}", "00".repeat(32)),
            ),
            &ctx(),
        )) {
            Ok(Ok(removed)) => removed,
            Ok(Err(failure)) => panic!("{backend}: {}", failure.summary),
            Err(message) => panic!("{backend}: the store suspended ({message})"),
        };
        assert!(
            !missing,
            "{backend}: nothing was there, so nothing was removed"
        );

        // Residue on a backend that never wrote one: `false`, not a rule invented per backend.
        // The stem is a full 60 hex characters: since the walk enforces the leaf alphabet, a
        // short stem would be *refused* on both backends, which is a different (also true) door.
        let residue = match block_on_ready(store.delete_content(
            &caly_storage::gc::ContentTarget::Residue {
                p1: "0f".to_owned(),
                p2: "aa".to_owned(),
                name: format!("{}.tmp-3", "0f".repeat(30)),
            },
            &ctx(),
        )) {
            Ok(Ok(removed)) => removed,
            Ok(Err(failure)) => panic!("{backend}: {}", failure.summary),
            Err(message) => panic!("{backend}: the store suspended ({message})"),
        };
        assert!(!residue, "{backend}: no residue exists here");
    });
}

/// `ADR-039 §2.3`: a cancelled caller is refused with `Cancelled` before any work starts, and
/// both backends answer the same way -- the door is the contract, not a local habit. The fs walk
/// checks at its first spend, the memory walk at its entry; the deletion door likewise.
#[test]
fn a_cancelled_caller_is_refused_the_same_way_on_both_backends() {
    for_each_backend(|store, backend| {
        let mut cancelled = ctx();
        cancelled.cancel = caly_common::CancelToken::pre_cancelled();
        let error = match block_on_ready(store.list_content(&cancelled)) {
            Ok(Ok(entries)) => panic!("{backend}: served a walk: {entries:?}"),
            Ok(Err(failure)) => failure,
            Err(message) => panic!("{backend}: the store suspended ({message})"),
        };
        assert_eq!(
            error.kind,
            StorageErrorKind::Cancelled,
            "{backend}: {}",
            error.summary
        );
        let error = match block_on_ready(store.delete_content(
            &caly_storage::gc::ContentTarget::Anchor(format!("sha256:{}", "22".repeat(32))),
            &cancelled,
        )) {
            Ok(Ok(removed)) => panic!("{backend}: handed a deletion: removed={removed}"),
            Ok(Err(failure)) => failure,
            Err(message) => panic!("{backend}: the store suspended ({message})"),
        };
        assert_eq!(
            error.kind,
            StorageErrorKind::Cancelled,
            "{backend}: {}",
            error.summary
        );
    });
}

/// `ADR-041`: the escaping must tell sibling names apart. `obj:orphan` and `obj_orphan` are two
/// different caller-coined names; under the old flattening they shared one record file, so the
/// second `put` overwrote the first and `get`/`delete` reached through an alias — and the
/// in-memory backend refused the alias, so the two backends disagreed. Answering `None` for the
/// sibling, and `false` for its deletion, is the contract both backends now keep.
#[test]
fn sibling_names_that_an_escaping_must_tell_apart_are_not_aliases() {
    for_each_backend(|store, backend| {
        done(
            store.put(
                CasWriteIntent {
                    object: object("obj:orphan", ObjectKind::SupportBundle, None),
                    source_label: "alias-probe".to_owned(),
                    payload: b"alias-probe-bytes".to_vec(),
                    stored_at_unix_ms: 1,
                },
                &ctx(),
            ),
            "put",
        );
        assert!(
            done(store.get("obj_orphan", &ctx()), "get sibling").is_none(),
            "{backend}: the sibling is a different name, not an alias"
        );
        assert!(
            !done(store.delete("obj_orphan", &ctx()), "delete sibling"),
            "{backend}: a deletion handed back for a name the store never held"
        );
        assert_eq!(
            done(store.get("obj:orphan", &ctx()), "get survivor")
                .expect("the survivor must be intact after its sibling was invoked")
                .digest
                .0,
            "obj:orphan",
            "{backend}"
        );
    });
}

/// The other half of the same property: sibling puts must **coexist** — on the durable backend
/// that means four records on the disk, still four after a restart (under the flattening the
/// second of a pair silently replaced the first, and the loss only became visible on reopen).
/// The second pair is the escaping's own edge: a literal `probe%2Fpath` must never be able to
/// masquerade as an escaped `probe/path`.
#[test]
fn sibling_puts_coexist_and_survive_the_restart_on_the_durable_backend() {
    let fs = SimFs::new(MemFs::default(), SharedFaults::new(FaultInjector::new(1)));
    let store = FsStore::open(Box::new(fs.clone()) as Box<dyn Fs>, ROOT).expect("open");
    let names = ["obj:orphan", "obj_orphan", "probe%2Fpath", "probe/path"];
    for (index, digest) in names.iter().enumerate() {
        done(
            store.put(
                CasWriteIntent {
                    object: object(digest, ObjectKind::SupportBundle, None),
                    source_label: "coexist-probe".to_owned(),
                    payload: format!("coexist-{index}").into_bytes(),
                    stored_at_unix_ms: index as i64 + 1,
                },
                &ctx(),
            ),
            "put",
        );
    }
    let reopened = FsStore::open(Box::new(fs) as Box<dyn Fs>, ROOT).expect("reopen");
    let listed = done(reopened.list_objects(&ctx()), "list");
    assert_eq!(
        listed.len(),
        names.len(),
        "four names, four records: {:?}",
        listed
            .iter()
            .map(|object| object.digest.0.clone())
            .collect::<Vec<_>>()
    );
    for digest in names {
        assert!(
            done(reopened.get(digest, &ctx()), "get").is_some(),
            "{digest} must still be held after a restart"
        );
    }
}
