//! One contract, both storage backends.
//!
//! `RFC-0006 §15` already demands that the *port* layer pass the same tests on the simulator and on
//! the real filesystem, and `caly-io::contract` is where that happens. The **store** had no
//! equivalent: `InMemoryStorage` and `FsStore` were each tested on their own, so a behaviour could
//! exist in one and not the other and nothing went red. Two such divergences were found while adding
//! `read_object` and are pinned here:
//!
//! - `materialize` of a metadata-only record: `FsStore` refused, `InMemoryStorage` answered `Ok(())`
//!   — a caller that swapped backends silently lost a guarantee (`docs/ONBOARDING_NOTES.md §4.45`).
//! - `put` with a declared `content_sha256` that does not match the payload: `FsStore` refused,
//!   `InMemoryStorage` overwrote the caller's claim (`§4.46`).
//!
//! Every test below runs against **both** backends with the same assertions.

use caly_io::{block_on_ready, Fs};
use caly_io_sim::{FaultInjector, MemFs, SharedFaults, SimFs};
use caly_storage::cas::{
    CasObjectRef, CasWriteIntent, MaterializationMode, ObjectDigest, ObjectKind,
};
use caly_storage::fs_store::FsStore;
use caly_storage::{InMemoryStorage, ObjectStore, StorageBackend, StorageError, StorageErrorKind};

const ROOT: &str = "var/caly";

/// Run `case` against every backend that must satisfy the contract.
fn for_each_backend(mut case: impl FnMut(&dyn StorageBackend, &'static str)) {
    let memory = InMemoryStorage::new();
    case(&memory, "in-memory");

    let fs = SimFs::new(MemFs::default(), SharedFaults::new(FaultInjector::new(1)));
    let durable =
        FsStore::open(Box::new(fs) as Box<dyn Fs>, ROOT).expect("a fresh store must open");
    case(&durable, "fs-store");
}

fn done<T: std::fmt::Debug>(
    future: caly_storage::BoxFuture<'_, Result<T, StorageError>>,
    what: &str,
) -> T {
    block_on_ready(future)
        .unwrap_or_else(|message| panic!("{what}: the store suspended ({message})"))
        .unwrap_or_else(|error| panic!("{what}: {}", error.summary))
}

fn object(digest: &str, kind: ObjectKind, anchor: Option<String>) -> CasObjectRef {
    CasObjectRef {
        digest: ObjectDigest(digest.to_owned()),
        kind,
        size_bytes: None,
        content_type: Some("text/plain".to_owned()),
        content_sha256: anchor,
        stored_at_unix_ms: Some(1_700_000_000_000),
    }
}

fn write(
    store: &dyn StorageBackend,
    digest: &str,
    kind: ObjectKind,
    payload: &[u8],
    backend: &str,
) -> CasObjectRef {
    done(
        store.put(CasWriteIntent {
            object: object(digest, kind, None),
            source_label: format!("{digest}.txt"),
            payload: payload.to_vec(),
            stored_at_unix_ms: 1_700_000_000_000,
        }),
        &format!("{backend}: put {digest}"),
    )
}

#[test]
fn content_written_with_a_payload_is_read_back_byte_for_byte() {
    for_each_backend(|store, backend| {
        let payload = b"first 40 bytes of a diagnostic export, and then some".to_vec();
        let meta = write(
            store,
            "sha256:aa11",
            ObjectKind::SupportBundle,
            &payload,
            backend,
        );
        assert_eq!(
            meta.size_bytes,
            Some(payload.len() as u64),
            "{backend}: the store records the size it wrote"
        );
        let anchor = meta
            .content_sha256
            .clone()
            .expect("a payload write records its own anchor");
        assert!(anchor.starts_with("sha256:"), "{backend}: {anchor}");

        let read = done(
            store.read_object("sha256:aa11", 1 << 20),
            &format!("{backend}: read back"),
        );
        assert_eq!(read.as_deref(), Some(payload.as_slice()), "{backend}");
    });
}

#[test]
fn an_unknown_digest_is_absent_rather_than_an_error() {
    for_each_backend(|store, backend| {
        let read = done(
            store.read_object("sha256:never-written", 1 << 20),
            &format!("{backend}: read unknown"),
        );
        assert_eq!(read, None, "{backend}: \"no such object\" is not a failure");
    });
}

#[test]
fn a_declared_anchor_that_does_not_match_the_payload_is_refused() {
    for_each_backend(|store, backend| {
        let lie = "sha256:0000000000000000000000000000000000000000000000000000000000000000";
        let outcome = block_on_ready(store.put(CasWriteIntent {
            object: object("sha256:bb22", ObjectKind::RawSource, Some(lie.to_owned())),
            source_label: "lied.txt".to_owned(),
            payload: b"real bytes".to_vec(),
            stored_at_unix_ms: 0,
        }))
        .expect("no suspension");
        let error = match outcome {
            Ok(_) => {
                panic!("{backend}: a caller may not choose an anchor the payload does not match")
            }
            Err(error) => error,
        };
        assert_eq!(
            error.kind,
            StorageErrorKind::IntegrityViolation,
            "{backend}"
        );
    });
}

#[test]
fn a_record_without_content_can_be_neither_materialized_nor_read() {
    for_each_backend(|store, backend| {
        // `CasWriteIntent::metadata` is the documented "index an external blob" case.
        done(
            store.put(CasWriteIntent::metadata(
                object("sha256:cc33", ObjectKind::RuleSet, None),
                "external.txt",
            )),
            &format!("{backend}: metadata-only put"),
        );

        let materialize = block_on_ready(store.materialize(caly_storage::MaterializationRequest {
            object: object("sha256:cc33", ObjectKind::RuleSet, None),
            runtime_path: "runtime/candidate.yaml".to_owned(),
            mode: MaterializationMode::Copy,
        }))
        .expect("no suspension");
        let error = match materialize {
            Ok(()) => {
                panic!("{backend}: materializing bytes that were never written is not success")
            }
            Err(error) => error,
        };
        assert_eq!(
            error.kind,
            StorageErrorKind::IntegrityViolation,
            "{backend}"
        );

        let read = block_on_ready(store.read_object("sha256:cc33", 1 << 20))
            .expect("no suspension")
            .expect_err(
                "{backend}: reading content that was never written must fail, not yield None",
            );
        assert_eq!(read.kind, StorageErrorKind::NotFound, "{backend}");
    });
}

#[test]
fn a_bound_smaller_than_the_object_is_reported_not_truncated() {
    for_each_backend(|store, backend| {
        write(
            store,
            "sha256:dd44",
            ObjectKind::CompiledArtifact,
            &[7u8; 512],
            backend,
        );
        let outcome = block_on_ready(store.read_object("sha256:dd44", 64)).expect("no suspension");
        let error = match outcome {
            Ok(Some(bytes)) => panic!(
                "{backend}: a capped read returned {} bytes when the caller allowed 64",
                bytes.len()
            ),
            Ok(None) => panic!("{backend}: the object exists"),
            Err(error) => error,
        };
        assert_eq!(error.kind, StorageErrorKind::CapacityExceeded, "{backend}");
        assert!(
            error.summary.contains("512") && error.summary.contains("64"),
            "{backend}: the message must name both numbers: {}",
            error.summary
        );
    });
}

#[test]
fn deleting_an_object_takes_its_content_with_it() {
    for_each_backend(|store, backend| {
        write(
            store,
            "sha256:ee55",
            ObjectKind::SupportBundle,
            b"bundle bytes",
            backend,
        );
        assert!(
            done(
                store.delete("sha256:ee55"),
                &format!("{backend}: delete existing")
            ),
            "{backend}: deleting a stored object reports that it removed something"
        );
        assert_eq!(
            done(
                store.read_object("sha256:ee55", 1 << 20),
                &format!("{backend}: read after delete")
            ),
            None,
            "{backend}: the content must not outlive the object"
        );
        assert!(
            !done(
                store.delete("sha256:ee55"),
                &format!("{backend}: delete again")
            ),
            "{backend}: a second delete is not a success"
        );
    });
}

#[test]
fn a_backend_that_cannot_read_content_says_so_instead_of_returning_nothing() {
    // The default `Unsupported` answer is what keeps a future backend from looking empty. A store
    // that answers `Ok(None)` for everything would make `read_object` indistinguishable from "no
    // such object", which is how `§4.18`'s GC gap first appeared.
    /// A store that implements the required `ObjectStore` methods and nothing else: exactly what a
    /// minimal backend gets for the optional ones.
    struct MetadataOnly;
    impl ObjectStore for MetadataOnly {
        fn put(
            &self,
            _intent: CasWriteIntent,
        ) -> caly_storage::BoxFuture<'_, Result<CasObjectRef, StorageError>> {
            unimplemented_box("put")
        }
        fn get(
            &self,
            _digest: &str,
        ) -> caly_storage::BoxFuture<'_, Result<Option<CasObjectRef>, StorageError>> {
            unimplemented_box("get")
        }
        fn materialize(
            &self,
            _request: caly_storage::MaterializationRequest,
        ) -> caly_storage::BoxFuture<'_, Result<(), StorageError>> {
            unimplemented_box("materialize")
        }
        fn list_objects(
            &self,
        ) -> caly_storage::BoxFuture<'_, Result<Vec<CasObjectRef>, StorageError>> {
            unimplemented_box("list_objects")
        }
        fn delete(&self, _digest: &str) -> caly_storage::BoxFuture<'_, Result<bool, StorageError>> {
            unimplemented_box("delete")
        }
    }
    let store = MetadataOnly;
    let error = block_on_ready(store.read_object("sha256:x", 10))
        .expect("no suspension")
        .expect_err("the trait default must refuse rather than yield None");
    assert_eq!(error.kind, StorageErrorKind::Unsupported);
}

fn unimplemented_box<T>(what: &str) -> caly_storage::BoxFuture<'static, Result<T, StorageError>> {
    let what = what.to_owned();
    Box::pin(async move {
        Err(StorageError::new(
            StorageErrorKind::Internal,
            format!("this stub does not implement {what}"),
        ))
    })
}

/// Integrity on **read**, not only on write.
///
/// `read_object` re-checks the bytes against the recorded anchor, which is the only thing standing
/// between "the store's index says this digest" and "a client is handed content nobody verified".
/// Durable and memory backends can only be tampered with the same way if the durable one is reached
/// through its own filesystem, so this case runs against `FsStore` alone — and `InMemoryStorage`
/// cannot even be reached from outside, which is why the assertion is not duplicated.
#[test]
fn tampered_content_is_refused_on_read_rather_than_handed_back() {
    let fs = SimFs::new(MemFs::default(), SharedFaults::new(FaultInjector::new(1)));
    let store = FsStore::open(Box::new(fs.clone()) as Box<dyn Fs>, ROOT).expect("open");
    let meta = write(
        &store,
        "sha256:ff66",
        ObjectKind::SupportBundle,
        b"original bytes of the export".to_vec().as_slice(),
        "fs-store",
    );
    let anchor = meta.content_sha256.clone().expect("anchor recorded");
    let content_path = caly_storage::fs_store::content_suffix_for(&anchor);
    let path = format!("{ROOT}/{content_path}");
    let vpath = caly_io::VPath::try_from_str(&path).expect("relative path");
    caly_io::block_on_ready(fs.write_atomic(
        &vpath,
        b"tampered bytes of the export".to_vec(),
        caly_io::Durability::D1,
        &caly_io::IoContext::new(caly_io::TraceId::new("tamper"), caly_io::Actor::System),
    ))
    .expect("no suspension")
    .expect("the test must be able to corrupt the file");

    let error = block_on_ready(store.read_object("sha256:ff66", 1 << 20))
        .expect("no suspension")
        .expect_err("a store that returns mutated content is worse than one that errors");
    assert_eq!(error.kind, StorageErrorKind::IntegrityViolation);
    assert!(
        error.summary.contains("sha256:ff66"),
        "the refusal must name the object: {}",
        error.summary
    );
}
