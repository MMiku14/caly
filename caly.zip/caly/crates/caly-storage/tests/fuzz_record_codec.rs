//! Deterministic structure-aware fuzz for the durable record codec (`caly-storage`):
//! the six typed decoders a REOPENED or TAMPERED store directory feeds — revision,
//! snapshot, apply journal, os journal, source index, job log — plus the generic
//! `Record::decode` they all sit on.
//!
//! A store directory is foreign the moment it is copied between machines, edited by an
//! operator, or written by a newer build. The judge feeds a seeded, reproducible mutation
//! stream over VALID record texts and demands: **never a panic** (the classic deaths here
//! are slicing at a separator some mutation removed, and unwrapping a parse that used to
//! be guaranteed by the writer), and every refusal **by name**. Local xorshift PRNG,
//! fixed budget, no dependencies.

use caly_storage::record::{
    decode_apply_journal, decode_job_log, decode_object, decode_os_journal, decode_revision,
    decode_snapshot, decode_source_index, Record, RECORD_TAG_V1,
};

struct Rng(u64);

impl Rng {
    fn next(&mut self) -> u64 {
        let mut x = self.0;
        x ^= x >> 12;
        x ^= x << 25;
        x ^= x >> 27;
        self.0 = x;
        x.wrapping_mul(0x2545_F491_4F6C_DD1D)
    }

    fn below(&mut self, n: usize) -> usize {
        (self.next() % n.max(1) as u64) as usize
    }
}

const SEED: u64 = 0x510B_1E55_7A9C_3D11;

const DELIMITERS: &[u8] = b"|=&\":\\\n\r\t \x00\xff";

fn mutate(rng: &mut Rng, corpus: &[u8]) -> Vec<u8> {
    let mut bytes = corpus.to_vec();
    let len = bytes.len();
    if len == 0 {
        // The empty corpus entry can only grow: one byte of hostility is the whole
        // space it has.
        return vec![DELIMITERS[rng.below(DELIMITERS.len())]];
    }
    match rng.below(7) {
        0 => bytes.truncate(rng.below(len + 1)),
        1 => {
            let at = rng.below(len);
            bytes[at] ^= 1 << rng.below(8);
        }
        2 => {
            let at = rng.below(len + 1);
            bytes.insert(at, DELIMITERS[rng.below(DELIMITERS.len())]);
        }
        3 => {
            let a = rng.below(len);
            let b = rng.below(len);
            bytes.swap(a, b);
        }
        4 => {
            let start = rng.below(len);
            let end = start + rng.below(len - start + 1);
            let chunk = bytes[start..end].to_vec();
            bytes.extend_from_slice(&chunk);
        }
        5 => {
            let at = rng.below(len + 1);
            bytes.insert(at, b'0' + (rng.below(10) as u8));
        }
        6 => {
            let start = rng.below(len);
            let end = start + rng.below(len - start + 1);
            bytes.drain(start..end);
        }
        _ => unreachable!(),
    }
    bytes
}

/// Valid record texts built through the codec's own generic writer, with the field shapes
/// each typed decoder reads (ids, numbers, timestamps) plus the hostile values a real
/// directory can carry (unicode, `=`, newlines-in-escapes, empty values).
fn corpus() -> Vec<String> {
    let mut simple = Record::new(RECORD_TAG_V1);
    simple.set("id", "rev-1");
    simple.set("number", "7");
    simple.set("profile_id", "demo");
    simple.set("semantic_digest", "sha256:abcd");
    simple.set("created_at", "1700000000000");

    let mut hostile = Record::new(RECORD_TAG_V1);
    hostile.set("id", "节点|=\\n🛡");
    hostile.set("number", "18446744073709551615");
    hostile.set("created_at", "-9223372036854775808");
    hostile.set("empty", "");

    let mut journal = Record::new(RECORD_TAG_V1);
    journal.set("id", "journal-1");
    journal.set("state", "pending");
    journal.set("event", "stage|with=delimiters");

    let empty = String::new();
    let bare_tag = RECORD_TAG_V1.to_owned();
    vec![
        simple.encode(),
        hostile.encode(),
        journal.encode(),
        empty,
        bare_tag,
    ]
}

#[test]
fn the_valid_corpus_decodes_through_the_typed_surface() {
    // The green side: the corpus's field shapes really do satisfy the typed decoders, so
    // the fuzz below cannot vacuously pass on an always-refusing decoder.
    let texts = corpus();
    decode_revision(&texts[0]).expect("the revision-shaped corpus record decodes");
    assert!(
        decode_object(&texts[1]).is_err(),
        "the object decoder refuses a non-object shape"
    );
    Record::decode(&texts[1]).expect("the generic codec accepts its own writer's output");
    assert!(
        Record::decode("").is_err(),
        "empty input is a named refusal"
    );
}

#[test]
fn mutated_records_never_panic_and_refuse_by_name() {
    let texts = corpus();
    let mut rng = Rng(SEED);
    let mut accepted = 0;
    let mut refused = 0;
    for step in 0..3000 {
        let base = &texts[rng.below(texts.len())];
        let input = if step % 8 == 0 {
            base.clone()
        } else {
            String::from_utf8_lossy(&mutate(&mut rng, base.as_bytes())).into_owned()
        };
        let mut this_accepted = false;
        type TypedDecoder = fn(&str) -> Result<(), caly_storage::RecordCodecError>;
        let decoders: [(&str, TypedDecoder); 7] = [
            ("Record::decode", |raw| Record::decode(raw).map(|_| ())),
            ("decode_revision", |raw| decode_revision(raw).map(|_| ())),
            ("decode_snapshot", |raw| decode_snapshot(raw).map(|_| ())),
            ("decode_apply_journal", |raw| {
                decode_apply_journal(raw).map(|_| ())
            }),
            ("decode_os_journal", |raw| {
                decode_os_journal(raw).map(|_| ())
            }),
            ("decode_source_index", |raw| {
                decode_source_index(raw).map(|_| ())
            }),
            ("decode_job_log", |raw| decode_job_log(raw).map(|_| ())),
        ];
        for (label, decode) in decoders {
            let before = std::sync::Arc::new(());
            let _ = &before;
            let outcome = std::panic::catch_unwind(std::panic::AssertUnwindSafe(|| decode(&input)));
            let Ok(result) = outcome else {
                panic!("{label} panicked on {input:?} (step {step})");
            };
            match result {
                Ok(()) => this_accepted = true,
                Err(error) => {
                    assert!(
                        !format!("{error:?}").trim().is_empty(),
                        "{label}: refusal must be by name"
                    );
                }
            }
        }
        if this_accepted {
            accepted += 1;
        } else {
            refused += 1;
        }
    }
    assert!(
        accepted > 0 && refused > 0,
        "the fuzz must exercise both sides (accepted={accepted}, refused={refused})"
    );
}
