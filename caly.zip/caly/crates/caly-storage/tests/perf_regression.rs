//! Counting-based performance regression judges (`ROADMAP` milestone 7, Phase 10): the
//! store's hot paths are pinned by **port-call counts**, never wall clocks — a shared
//! 2-CPU sandbox makes timing flaky, but a quadratic sweep is quadratic at any speed.
//!
//! The counting harness is the `stat_many` round's wrapper pattern generalised: a
//! delegating `Fs` adapter that counts EVERY method, so the judges stay out of the
//! storage internals and the store only ever sees a `Box<dyn Fs>`.
//!
//! * **batch dating stays constant as the directory grows** — `list_objects` dates N
//!   records with exactly one `stat_many` and zero `stat`s, at N=8 and at N=48 alike
//!   (`ADR-054 §2.3`; this judge pins the SCALING, the original pinned the adoption);
//! * **reopening a bigger store costs linearly more port calls** — open over 4× the
//!   objects spends at most ~4.8× the port calls, and strictly more than 2×: a quadratic
//!   reopen sweep (the classic "rescan everything per record" regression) trips the
//!   upper bound, a reopen that stopped reading everything trips the lower one.

use std::sync::atomic::{AtomicUsize, Ordering};
use std::sync::Arc;

use caly_io::{
    block_on_ready, BoxFuture, ByteCap, ByteStream, Bytes, Durability, FileLock, Fs, IoContext,
    IoFault, LinkKind, ListCap, Meta, VPath,
};
use caly_io_sim::{MemFs, SimFs};
use caly_storage::cas::{CasObjectRef, CasWriteIntent, ObjectDigest, ObjectKind};
use caly_storage::{FsStore, ObjectStore};

const ROOT: &str = "var/caly";

/// Delegates every call to a `SimFs`, counting each method (and the total).
struct CountingFs {
    inner: SimFs,
    total: Arc<AtomicUsize>,
    stat: Arc<AtomicUsize>,
    stat_many: Arc<AtomicUsize>,
}

impl CountingFs {
    fn new(inner: SimFs) -> (Self, Arc<AtomicUsize>, Arc<AtomicUsize>, Arc<AtomicUsize>) {
        let total = Arc::new(AtomicUsize::new(0));
        let stat = Arc::new(AtomicUsize::new(0));
        let stat_many = Arc::new(AtomicUsize::new(0));
        (
            Self {
                inner,
                total: Arc::clone(&total),
                stat: Arc::clone(&stat),
                stat_many: Arc::clone(&stat_many),
            },
            total,
            stat,
            stat_many,
        )
    }
}

/// Count one port call, then delegate. (`stat` / `stat_many` are counted separately in
/// their own methods before this fires.)
macro_rules! counted {
    ($self:expr, $call:expr) => {{
        $self.total.fetch_add(1, Ordering::Relaxed);
        $call
    }};
}

impl Fs for CountingFs {
    fn read<'a>(
        &'a self,
        path: &'a VPath,
        cap: ByteCap,
        ctx: &'a IoContext,
    ) -> BoxFuture<'a, Result<Bytes, IoFault>> {
        counted!(self, self.inner.read(path, cap, ctx))
    }
    fn open_stream<'a>(
        &'a self,
        path: &'a VPath,
        ctx: &'a IoContext,
    ) -> BoxFuture<'a, Result<ByteStream, IoFault>> {
        counted!(self, self.inner.open_stream(path, ctx))
    }
    fn write_atomic<'a>(
        &'a self,
        path: &'a VPath,
        data: Bytes,
        durability: Durability,
        ctx: &'a IoContext,
    ) -> BoxFuture<'a, Result<(), IoFault>> {
        counted!(self, self.inner.write_atomic(path, data, durability, ctx))
    }
    fn rename<'a>(
        &'a self,
        from: &'a VPath,
        to: &'a VPath,
        durability: Durability,
        ctx: &'a IoContext,
    ) -> BoxFuture<'a, Result<(), IoFault>> {
        counted!(self, self.inner.rename(from, to, durability, ctx))
    }
    fn remove<'a>(
        &'a self,
        path: &'a VPath,
        ctx: &'a IoContext,
    ) -> BoxFuture<'a, Result<(), IoFault>> {
        counted!(self, self.inner.remove(path, ctx))
    }
    fn stat<'a>(
        &'a self,
        path: &'a VPath,
        ctx: &'a IoContext,
    ) -> BoxFuture<'a, Result<Option<Meta>, IoFault>> {
        self.stat.fetch_add(1, Ordering::Relaxed);
        counted!(self, self.inner.stat(path, ctx))
    }
    fn stat_many<'a>(
        &'a self,
        paths: &'a [VPath],
        ctx: &'a IoContext,
    ) -> BoxFuture<'a, Result<Vec<Option<Meta>>, IoFault>> {
        self.stat_many.fetch_add(1, Ordering::Relaxed);
        counted!(self, self.inner.stat_many(paths, ctx))
    }
    fn link_or_copy<'a>(
        &'a self,
        from: &'a VPath,
        to: &'a VPath,
        ctx: &'a IoContext,
    ) -> BoxFuture<'a, Result<LinkKind, IoFault>> {
        counted!(self, self.inner.link_or_copy(from, to, ctx))
    }
    fn lock_exclusive<'a>(
        &'a self,
        path: &'a VPath,
        ctx: &'a IoContext,
    ) -> BoxFuture<'a, Result<FileLock, IoFault>> {
        counted!(self, self.inner.lock_exclusive(path, ctx))
    }
    fn list<'a>(
        &'a self,
        dir: &'a VPath,
        cap: ListCap,
        ctx: &'a IoContext,
    ) -> BoxFuture<'a, Result<Vec<VPath>, IoFault>> {
        counted!(self, self.inner.list(dir, cap, ctx))
    }
}

fn ctx() -> IoContext {
    IoContext::new(
        caly_io::TraceId::new("perf-regression-judge"),
        caly_io::Actor::System,
    )
}

fn fresh_disk() -> SimFs {
    SimFs::new(MemFs::default(), caly_io_sim::SharedFaults::default())
}

fn open_counted(
    disk: &SimFs,
) -> (
    FsStore,
    Arc<AtomicUsize>,
    Arc<AtomicUsize>,
    Arc<AtomicUsize>,
) {
    let (counting, total, stat, stat_many) = CountingFs::new(disk.clone());
    let store = FsStore::open(Box::new(counting) as Box<dyn Fs>, ROOT).expect("open store");
    (store, total, stat, stat_many)
}

fn write_objects(store: &FsStore, count: usize) {
    for index in 0..count {
        let payload = format!("perf-regression-payload-{index}").into_bytes();
        let result = block_on_ready(store.put(
            CasWriteIntent {
                object: CasObjectRef {
                    digest: ObjectDigest(format!("obj:perf-{index}")),
                    kind: ObjectKind::RawSource,
                    size_bytes: None,
                    content_type: None,
                    content_sha256: None,
                    stored_at_unix_ms: Some(1_000_000 + index as i64),
                },
                source_label: format!("perf-{index}.txt"),
                payload,
                stored_at_unix_ms: 1_000_000 + index as i64,
            },
            &ctx(),
        ))
        .expect("no suspension")
        .expect("write");
        assert!(
            result.content_sha256.is_some(),
            "the store records its anchor"
        );
    }
}

/// `ADR-054 §2.3` pinned the adoption (one `stat_many`, zero `stat`s at N=2). This judge
/// pins the SCALING: the same holds at N=8 and at N=48 — the batch must not quietly
/// degrade into per-record round trips as the directory grows.
#[test]
fn batch_dating_stays_constant_as_the_directory_grows() {
    for size in [8usize, 48] {
        let disk = fresh_disk();
        let (store, _total, stat, stat_many) = open_counted(&disk);
        write_objects(&store, size);

        stat.store(0, Ordering::Relaxed);
        stat_many.store(0, Ordering::Relaxed);

        let records = block_on_ready(store.list_objects(&ctx()))
            .expect("no suspension")
            .expect("enumerate");
        assert_eq!(records.len(), size, "{size} objects are on the disk");
        assert_eq!(
            stat_many.load(Ordering::Relaxed),
            1,
            "a directory of {size} records is dated by ONE stat_many"
        );
        assert_eq!(
            stat.load(Ordering::Relaxed),
            0,
            "the batch must not fall back to per-record stat calls at {size}"
        );
    }
}

/// Reopen (the crash-recovery sweep) must scale LINEARLY with the record count: 4× the
/// objects may cost at most ~4.8× the port calls (a quadratic rescan trips this), and at
/// least 2× (a reopen that stopped reading what it wrote trips that — the open scan's
/// verify-everything discipline is a security property, not an overhead to optimise away).
#[test]
fn reopening_a_bigger_store_costs_linearly_more_port_calls() {
    fn reopen_cost(objects: usize) -> usize {
        let disk = fresh_disk();
        {
            let (store, _total, _stat, _stat_many) = open_counted(&disk);
            write_objects(&store, objects);
        }
        let (_store, total, _stat, _stat_many) = open_counted(&disk);
        total.load(Ordering::Relaxed)
    }

    let small = reopen_cost(12);
    let large = reopen_cost(48);
    assert!(
        small >= 24,
        "the small reopen actually reads what it wrote ({small} calls for 12 objects)"
    );
    assert!(
        large >= small * 2,
        "4x the records must cost strictly more port calls ({small} -> {large})"
    );
    assert!(
        large <= small * 5,
        "4x the records must not cost super-linearly more port calls ({small} -> {large}): \\
         a quadratic reopen sweep is a regression at any clock speed"
    );
}

/// The original linearity judge stops at 48 objects. The sizing round needs the same pin at
/// a scale the platform target actually cares about (thousands of durable objects), still
/// inside the 4096 entry cap: 16x the records may cost at most ~20x the port calls (a
/// quadratic sweep trips this loudly) and at least ~8x (a reopen that stopped verifying
/// what it wrote trips that — the verify-everything open is a security property, not an
/// overhead to optimise away).
#[test]
fn a_sixteenfold_bigger_directory_stays_linear_in_port_calls() {
    fn reopen_cost(objects: usize) -> usize {
        let disk = fresh_disk();
        {
            let (store, _total, _stat, _stat_many) = open_counted(&disk);
            write_objects(&store, objects);
        }
        let (_store, total, _stat, _stat_many) = open_counted(&disk);
        total.load(Ordering::Relaxed)
    }

    let small = reopen_cost(96);
    let large = reopen_cost(1536);
    assert!(
        small >= 192,
        "the small reopen actually reads what it wrote ({small} calls for 96 objects)"
    );
    assert!(
        large >= small * 8,
        "16x the records must cost near-linearly more port calls ({small} -> {large})"
    );
    assert!(
        large <= small * 20,
        "16x the records must not cost super-linearly more port calls ({small} -> {large}): \\\\
         a quadratic reopen sweep is a regression at any clock speed"
    );
}
