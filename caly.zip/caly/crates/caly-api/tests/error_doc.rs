//! `docs/ERRORS.md`'s code names, judged against the enum that must obey them.
//!
//! `ERRORS.md §4` declares the v1 stable code set ("v1 的公共稳定错误码最小集合") and
//! `§4.1` the reserved slots; `caly_api::ErrorCode` is the implementation. The doc gate
//! (`caly-arch-test`) checks table *shape*; nothing checks that the names in §4/§4.1 and
//! the names in the enum are the same set — an enum variant could appear with no doc
//! entry, a doc code could vanish or turn into an undocumented typo, a reserved code
//! could be promoted into the stable table, and every existing gate would stay green.
//!
//! No process is spawned; the whole claim is "two statements agree", and reading the
//! document is enough to check it. The table is parsed with a minimal local parser
//! (a line starting with `|`) — the same "two implementations agreeing" rule the
//! wire oracles use.
//!
//! Scope note (deliberate): §4's `Category` and `Retryable` columns are *not* compared
//! to the code here, because the code has no per-code authority for either — category
//! and retryable are decided per construction site (`ApiError::new` callers), and at
//! least three sites today contradict §4 (see IMPLEMENTATION_STATUS §8.15 residual).
//! What is checkable right now, with both sides already existing, is the name closure:
//! no undocumented code, no undocumented removal, no reserved/stable overlap.

use std::collections::BTreeSet;

use caly_api::ErrorCode;

/// The enum's names via `as_str` — the *implemented* claim. The exhaustive `match`
/// below is the compiler's witness that this list has not silently gone stale:
/// a new variant fails the `match`, so `ALL_CODES` cannot lag the enum.
const ALL_CODES: &[ErrorCode] = &[
    ErrorCode::ConfigInvalid,
    ErrorCode::Conflict,
    ErrorCode::UnsupportedCapability,
    ErrorCode::CoreNotRunning,
    ErrorCode::CoreFailed,
    ErrorCode::Permission,
    ErrorCode::NetOs,
    ErrorCode::Storage,
    ErrorCode::Timeout,
    ErrorCode::Unavailable,
    ErrorCode::ProtoMismatch,
    ErrorCode::CursorStale,
    ErrorCode::Cancelled,
    ErrorCode::Internal,
];

#[allow(dead_code)]
fn prove_exhaustive(code: ErrorCode) {
    match code {
        ErrorCode::ConfigInvalid
        | ErrorCode::Conflict
        | ErrorCode::UnsupportedCapability
        | ErrorCode::CoreNotRunning
        | ErrorCode::CoreFailed
        | ErrorCode::Permission
        | ErrorCode::NetOs
        | ErrorCode::Storage
        | ErrorCode::Timeout
        | ErrorCode::Unavailable
        | ErrorCode::ProtoMismatch
        | ErrorCode::CursorStale
        | ErrorCode::Cancelled
        | ErrorCode::Internal => {}
    }
}

fn read_errors_md() -> String {
    std::fs::read_to_string(format!("{}/docs/ERRORS.md", workspace_root().display()))
        .expect("ERRORS.md is the contract under test")
}

fn workspace_root() -> &'static std::path::Path {
    std::path::Path::new(env!("CARGO_MANIFEST_DIR"))
        .parent()
        .expect("crates/")
        .parent()
        .expect("workspace root")
}

fn after<'a>(text: &'a str, marker: &str) -> &'a str {
    text.split_once(marker).map_or("", |(_, rest)| rest)
}

fn until<'a>(text: &'a str, marker: &str) -> &'a str {
    text.split_once(marker).map_or(text, |(head, _)| head)
}

/// Backticked names of the `| Name | ... |` rows inside `section`.
fn backticked_row_names(section: &str) -> Vec<String> {
    let mut names = Vec::new();
    for line in section.lines() {
        let line = line.trim();
        if !line.starts_with('|') {
            continue;
        }
        let cells: Vec<&str> = line.trim_matches('|').split('|').map(str::trim).collect();
        let Some(first) = cells.first() else {
            continue;
        };
        if let Some(name) = first.strip_prefix('`').and_then(|s| s.strip_suffix('`')) {
            names.push(name.to_owned());
        }
    }
    names
}

/// The §4 stable table's rows as (code, category, retryable) triples.
fn stable_rows(text: &str) -> Vec<(String, String, String)> {
    let section = until(after(text, "## 4. 稳定公共错误码"), "### 4.1");
    let mut rows = Vec::new();
    for line in section.lines() {
        let line = line.trim();
        if !line.starts_with('|') {
            continue;
        }
        let cells: Vec<&str> = line.trim_matches('|').split('|').map(str::trim).collect();
        if cells.len() != 4 {
            continue;
        }
        let Some(code) = cells[0].strip_prefix('`').and_then(|s| s.strip_suffix('`')) else {
            continue;
        };
        rows.push((code.to_owned(), cells[1].to_owned(), cells[2].to_owned()));
    }
    rows
}

/// The §4.1 reserved code names (`- \`NAME\`` bullets).
fn reserved_names(text: &str) -> Vec<String> {
    let section = until(after(text, "### 4.1 保留码位"), "## 5.");
    section
        .lines()
        .filter_map(|line| {
            let line = line.trim();
            line.strip_prefix("- `")
                .and_then(|s| s.strip_suffix('`'))
                .map(|s| s.to_owned())
        })
        .collect()
}

/// The enum and the doc's two name lists must form the right closure, directionally:
///
/// * **every implemented code is documented** (§4 stable or §4.1 reserved) — an enum
///   name with no doc entry is an undocumented public code;
/// * **every stable code is implemented** — a §4 row naming a code the enum lacks is
///   a contract the CLI can never honor;
/// * **the reserved list is half-way by design**: `CANCELLED` and `INTERNAL` are
///   implemented (the enum carries them, EXIT_CODES.md gives them 15/16), the other
///   four reserved slots are *not* — implementing one of them without promoting it to
///   §4 (the doc's own "以新 RFC 或 RFC-0002 修订方式正式引入" rule) is exactly the
///   silent drift this file exists to catch.
#[test]
fn the_name_closure_is_directional_and_pinned() {
    let text = read_errors_md();
    let stable: BTreeSet<String> = stable_rows(&text).into_iter().map(|(c, _, _)| c).collect();
    let reserved: BTreeSet<String> = reserved_names(&text).into_iter().collect();

    assert_eq!(
        stable.len(),
        12,
        "§4 must list the v1 stable set exactly (12 codes)"
    );
    assert_eq!(reserved.len(), 6, "§4.1 must list six reserved slots");
    assert!(
        stable.is_disjoint(&reserved),
        "a code cannot be both stable and reserved: {:?}",
        stable.intersection(&reserved).collect::<Vec<_>>()
    );

    let implemented: BTreeSet<String> = ALL_CODES.iter().map(|c| c.as_str().to_owned()).collect();
    assert_eq!(implemented.len(), 14, "enum names must be unique");

    let mut documented = stable.clone();
    documented.extend(reserved.clone());
    let undocumented: Vec<&String> = implemented.difference(&documented).collect();
    assert!(
        undocumented.is_empty(),
        "codes implemented but not documented in §4/§4.1: {undocumented:?}"
    );
    let unimplemented_stable: Vec<&String> = stable.difference(&implemented).collect();
    assert!(
        unimplemented_stable.is_empty(),
        "stable codes the enum does not have: {unimplemented_stable:?}"
    );

    // The deliberate half-way point: exactly CANCELLED and INTERNAL are implemented
    // reserved codes, and the enum's non-stable names are exactly those two.
    let implemented_reserved: Vec<String> = implemented.intersection(&reserved).cloned().collect();
    assert_eq!(
        implemented_reserved,
        vec!["CANCELLED".to_owned(), "INTERNAL".to_owned()],
        "implementing a reserved code requires promoting it to §4 (or amending this pinned half-way), not silently adding it to the enum"
    );

    // Exhaustiveness witness: the `match` in `prove_exhaustive` fails to compile when a
    // variant is added, so this test cannot silently pass on a stale ALL_CODES list.
    let _ = ALL_CODES
        .iter()
        .map(|code| prove_exhaustive(*code))
        .collect::<Vec<_>>();
}

/// §4 must stay inside the vocabulary the document itself defines: categories only from
/// the §3 table, retryable values only from the four the document uses.
#[test]
fn the_stable_table_stays_inside_the_documented_vocabulary() {
    let text = read_errors_md();
    let section3 = until(after(&text, "## 3. 错误分类"), "### 3.1");
    let categories: BTreeSet<String> = backticked_row_names(section3).into_iter().collect();
    assert_eq!(
        categories.len(),
        7,
        "§3 must define exactly the seven public categories"
    );

    let rows = stable_rows(&text);
    assert_eq!(rows.len(), 12, "the stable set is pinned at 12 rows");
    let retryable = ["否", "视场景", "可能", "是"];
    let mut seen = BTreeSet::new();
    for (code, category, retry) in &rows {
        assert!(
            categories.contains(category),
            "§4 row {code} uses a category not defined in §3: {category}"
        );
        assert!(
            retryable.contains(&retry.as_str()),
            "§4 row {code} uses a retryable value outside {{否,视场景,可能,是}}: {retry}"
        );
        assert!(seen.insert(code), "§4 row for {code} is duplicated");
    }
}

/// §4's stable codes and §5's usage rules must cover each other exactly: every stable
/// code has its usage rules in exactly one §5.x section, and every §5.x section names
/// only stable codes — a rule section for `CANCELLED`/a reserved code would be a de
/// facto promotion that skipped §4, and a §4 code with no rules is a contract nobody
/// can implement against.
#[test]
fn the_usage_rules_cover_exactly_the_stable_codes() {
    let text = read_errors_md();
    let stable: std::collections::BTreeSet<String> =
        stable_rows(&text).into_iter().map(|(c, _, _)| c).collect();

    let section5 = until(after(&text, "## 5. 错误码使用规则"), "## 6.");
    let mut sections: Vec<(u32, Vec<String>)> = Vec::new();
    for line in section5.lines() {
        let line = line.trim();
        let Some(rest) = line.strip_prefix("### 5.") else {
            continue;
        };
        let digits: String = rest.chars().take_while(|c| c.is_ascii_digit()).collect();
        let Ok(number) = digits.parse::<u32>() else {
            continue;
        };
        let names: Vec<String> = rest
            .split('`')
            .skip(1)
            .step_by(2)
            .map(|s| s.trim().to_owned())
            .filter(|s| !s.is_empty())
            .collect();
        sections.push((number, names));
    }
    assert_eq!(sections.len(), 10, "§5 must hold exactly ten rule sections");

    let mut seen_numbers = std::collections::BTreeSet::new();
    let mut occurrences: std::collections::BTreeMap<&str, u32> = std::collections::BTreeMap::new();
    for (number, names) in &sections {
        assert!(
            seen_numbers.insert(*number),
            "duplicate §5 rule section 5.{number}"
        );
        assert!(
            (1..=10).contains(number),
            "§5 section number out of range: 5.{number}"
        );
        let named = names.join(" ");
        for name in names {
            assert!(
                stable.contains(name),
                "§5.{number} gives usage rules to {name}, which is not a §4 stable code"
            );
            *occurrences.entry(name).or_default() += 1;
        }
        assert!(!names.is_empty(), "§5.{number} names no code ({named})");
    }
    for name in &stable {
        assert_eq!(
            occurrences.get(name.as_str()).copied().unwrap_or(0),
            1,
            "§4 code {name} must have usage rules in exactly one §5 section"
        );
    }
}

/// The §4 Category column and the code's canonical per-code category must be one map:
/// `ErrorCode::category()` is the default every deviating construction site has to
/// argue against (docs/ERRORS.md §5.1 pins `CONFIG_INVALID` + `User` as an instance
/// case, so §4's column is a default, not a straitjacket — see §8.18 for the audited
/// deviator inventory).
#[test]
fn the_stable_categories_match_the_code_defaults() {
    let text = read_errors_md();
    let by_name: std::collections::BTreeMap<&str, ErrorCode> = ALL_CODES
        .iter()
        .map(|code| (code.as_str(), *code))
        .collect();

    let documented: std::collections::BTreeMap<String, String> = stable_rows(&text)
        .into_iter()
        .map(|(code, category, _)| (code, category))
        .collect();
    let implemented: std::collections::BTreeMap<String, String> = documented
        .keys()
        .map(|code| {
            let ec = by_name
                .get(code.as_str())
                .unwrap_or_else(|| panic!("stable code {code} must exist in the enum"));
            (code.clone(), ec.category().as_str().to_owned())
        })
        .collect();

    assert_eq!(
        documented, implemented,
        "ERRORS.md §4's Category column and ErrorCode::category() are one map"
    );
}

/// §4's Retryable column and the code's canonical per-code retry character must be one
/// map. The doc's four words map one-to-one onto `RetryPolicy`'s four variants; this
/// mapping lives here, at the judge — it is the contract translation, and the words
/// themselves stay the document's, never the code's.
#[test]
fn the_stable_retryable_column_matches_the_code_policy_defaults() {
    let text = read_errors_md();
    let by_name: std::collections::BTreeMap<&str, ErrorCode> = ALL_CODES
        .iter()
        .map(|code| (code.as_str(), *code))
        .collect();

    let documented: std::collections::BTreeMap<String, String> = stable_rows(&text)
        .into_iter()
        .map(|(code, _, retry)| (code, retry))
        .collect();
    let implemented: std::collections::BTreeMap<String, String> = documented
        .keys()
        .map(|code| {
            let ec = by_name
                .get(code.as_str())
                .unwrap_or_else(|| panic!("stable code {code} must exist in the enum"));
            let word = match ec.retry_policy() {
                caly_api::RetryPolicy::Never => "否",
                caly_api::RetryPolicy::Maybe => "可能",
                caly_api::RetryPolicy::Depends => "视场景",
                caly_api::RetryPolicy::Always => "是",
            };
            (code.clone(), word.to_owned())
        })
        .collect();

    assert_eq!(
        documented, implemented,
        "ERRORS.md §4's Retryable column and ErrorCode::retry_policy() are one map"
    );
}
