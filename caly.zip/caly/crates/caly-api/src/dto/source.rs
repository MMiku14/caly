use crate::operation::SourceId;

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct SourceSummary {
    pub id: SourceId,
    pub label: String,
    pub kind: String,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct SourceDiagnostic {
    pub code: String,
    pub severity: String,
    pub summary: String,
    pub detail: Option<String>,
    pub related_path: Option<String>,
    pub remediation: Option<String>,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct SourceProvenance {
    pub field: String,
    pub origin: String,
    pub locator: Option<String>,
    pub transform: Vec<String>,
    pub superseded: Vec<String>,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct SourceInspection {
    pub summary: SourceSummary,
    /// The endpoint locator after the daemon's normal redaction boundary. It is optional because
    /// legacy/synthetic sources may have no durable endpoint record.
    pub locator: Option<String>,
    pub route: Option<String>,
    pub etag: Option<String>,
    pub last_modified: Option<String>,
    /// The parser's raw-content digest and the CAS object's digest are separate anchors.
    pub latest_digest: Option<String>,
    pub raw_object_digest: Option<String>,
    pub raw_bytes_len: Option<u64>,
    pub raw_stored_at_unix_ms: Option<i64>,
    pub normalized_node_count: usize,
    pub normalized_group_count: usize,
    /// These are the complete bounded facts retained by the durable source index, not a
    /// process-local warning counter or a re-run of the current profile workflow.
    pub diagnostics: Vec<SourceDiagnostic>,
    pub provenance: Vec<SourceProvenance>,
    pub updated_at_unix_ms: Option<i64>,
    pub warning_count: u32,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct SourcePreviewRequest {
    pub source_id: Option<SourceId>,
    pub inline_source: Option<String>,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct SourcePreview {
    pub node_count: usize,
    pub group_count: usize,
    pub warnings: Vec<String>,
}
