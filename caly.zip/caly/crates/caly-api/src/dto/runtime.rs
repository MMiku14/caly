use crate::dto::common::PageRequest;
use crate::operation::{ConnectionId, ProfileId};

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct RuntimeStatus {
    pub core_running: bool,
    pub active_profile: Option<ProfileId>,
    pub active_core: Option<String>,
    pub active_snapshot: Option<String>,
    pub last_apply_plan_summary: Option<String>,
    pub pending_recovery_decisions: usize,
    pub last_recovery_summary: Option<String>,
    pub last_failure: Option<String>,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct ConnectionQuery {
    pub page: PageRequest,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct ConnectionView {
    pub id: ConnectionId,
    pub destination: String,
    pub process: Option<String>,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct ConnectionPage {
    pub items: Vec<ConnectionView>,
    pub next: Option<String>,
    pub revision: u64,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub enum RuntimeSubscription {
    Dashboard,
    Traffic,
    Logs,
    Connections,
    /// The deployment lifecycle stream (`IPC_STREAM_POLICY §2`): `LosslessResumable` + ack
    /// `Required` — every deployment-mutating event, in order, resumable from the acked
    /// cursor. Round 130 gave this kind its producer; the payload filter is the kind's
    /// production semantics (deployment events ONLY — the other kinds on the shared event
    /// window carry everything, and Traffic/Logs still await their real data sources).
    Deployment,
}
