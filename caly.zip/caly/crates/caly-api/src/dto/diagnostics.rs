use crate::dto::common::PageRequest;
use crate::operation::{JobId, ProfileId};

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct RuleQuery {
    pub page: PageRequest,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct RuleView {
    pub id: String,
    pub label: String,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct RulePage {
    pub items: Vec<RuleView>,
    pub next: Option<String>,
    pub revision: u64,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct RouteExplainRequest {
    pub target: String,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct RouteExplainResult {
    pub matched_rule: Option<String>,
    pub action: String,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct RoutingValidation {
    pub warning_count: u32,
    pub error_count: u32,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct DnsExplainRequest {
    pub domain_or_ip: String,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct DnsExplainResult {
    pub resolved_via: String,
    pub outbound: Option<String>,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct DoctorRequest {
    pub include_runtime: bool,
}

/// Three tiers, deliberately separate.
///
/// A single `warnings` bucket invites the placeholder pattern this DTO used to have: a fixed
/// "diagnostics are still partial" line kept every `doctor` call non-empty, so a real finding and
/// a stub were indistinguishable. Informational notes now have their own channel, which means an
/// empty `warnings` list actually means "nothing to warn about".
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct DoctorReport {
    pub summary: String,
    pub warnings: Vec<String>,
    pub errors: Vec<String>,
    /// Context the operator may want, none of which requires action.
    pub notes: Vec<String>,
    /// `true` when any of the three tiers carries less than the source produced.
    ///
    /// A field rather than only a line inside `notes`, because `truncated = false` is a claim a caller can
    /// act on ("what you have is everything") and a sentence in a list is not. `§11.4`'s frame bound is
    /// the reason the cut exists; this is the reason the cut may not be silent
    /// (`docs/history/ONBOARDING_NOTES.md §4.54`).
    pub truncated: bool,
    /// Whole lines that were not carried, across all three tiers. The tiers' own lengths stay visible, so
    /// this is the only number that cannot be derived from what is above.
    pub omitted_lines: usize,
    /// Lines that were carried with their tail elided, because a single finding's text outran the
    /// per-line cap. Kept apart from `omitted_lines`: "there were more findings" and "this finding is
    /// longer than a frame" get read differently, and the second is not fixed by paging.
    pub shortened_lines: usize,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct PipelineExplainRequest {
    pub profile_id: ProfileId,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct PipelineExplain {
    pub stages: Vec<String>,
    pub diagnostics: Vec<String>,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct CapabilityQuery {
    pub target: String,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct CapabilityReport {
    pub target: String,
    pub supported: Vec<String>,
    pub warnings: Vec<String>,
    pub blocked: Vec<String>,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct RecoveryStatusView {
    pub daemon_lifecycle: String,
    pub active_profile: Option<ProfileId>,
    pub active_core: Option<String>,
    pub active_snapshot: Option<String>,
    pub last_apply_plan_summary: Option<String>,
    pub pending_apply_count: usize,
    pub pending_os_count: usize,
    pub decision_count: usize,
    pub decisions: Vec<String>,
    pub last_recovery_summary: Option<String>,
    /// `true` when `decisions` carries fewer than `decision_count`.
    ///
    /// `decision_count` is deliberately *not* the post-cut length: a caller decides "this store has 900
    /// unresolved apply journals" from the total, and a total that shrinks to fit the reply would be the
    /// most convincing kind of lie. The pair is exactly `JobEventsView`'s
    /// `next_event_index`/`byte_len` discipline, applied to a list nobody asked to page.
    pub truncated: bool,
    pub omitted_decisions: usize,
    pub shortened_decisions: usize,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct JobFollowRequest {
    pub job_id: JobId,
    pub from_event_index: Option<u64>,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct JobFollowView {
    pub job_id: JobId,
    pub state: String,
    pub lifecycle: String,
    pub next_event_index: u64,
    pub retained_from_event_index: u64,
    pub reset_required: bool,
    pub event_count: usize,
    pub last_stage: Option<String>,
    pub last_stage_pct: Option<u8>,
    pub warning_count: usize,
    pub log_count: usize,
    pub failure_code: Option<String>,
    pub failure_summary: Option<String>,
}

/// Asking for a support bundle that was already written into the store.
///
/// `DiagnosticsOp::SupportBundle` is a command: it accepts a job, and the job's log names the CAS
/// object the bundle went into. This is the matching read.
#[derive(Clone, Debug, Eq, PartialEq, Default)]
pub struct SupportBundleReadRequest {
    /// The object digest reported by the bundle job, e.g. `sha256:1f0e…`.
    ///
    /// `None` means "the newest bundle this store still holds", which is what a client that only
    /// clicked *Export diagnostics* knows. Choosing it is not a guess: the store is the only place
    /// bundles live, and objects that gc has collected are simply not candidates. A caller that needs
    /// a *specific* export (one quoted in a ticket, say) passes the digest.
    pub digest: Option<String>,
    /// How much of the bundle to return. `None` means all of it (up to the daemon's own read limit);
    /// `Some(n)` returns at most `n` bytes and says so in `SupportBundleView::truncated`.
    ///
    /// This bounds the **response**, never the verification: the store still reads and checks the
    /// whole object first, because a caller asking for less must not be able to make the daemon skip
    /// the integrity check that `RFC-0007 §6.3` requires on read. The store-level bound is a different
    /// thing and is still an error (`CapacityExceeded`) rather than a silent half-artifact.
    pub max_bytes: Option<u64>,
}

/// A support bundle, read back out of the store.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct SupportBundleView {
    pub digest: String,
    /// The anchor the store verified the bytes against. Equal to `digest` for bundles, because the
    /// bundle is addressed by the digest of its own content.
    pub content_sha256: String,
    /// When the store took the bytes, on the injected timeline.
    pub stored_at_unix_ms: Option<i64>,
    /// Bytes of `text`.
    pub byte_len: u64,
    /// Lines in `text`, so a truncated read is visibly partial.
    pub line_count: usize,
    /// `true` when `max_bytes` cut the bundle short.
    pub truncated: bool,
    /// The bundle itself. Already masked: `RFC-0010 §12.1` makes the export strictly stricter than
    /// the process policy, and this is the text a user is meant to hand to someone else.
    pub text: String,
}

impl SupportBundleView {
    pub fn is_partial(&self) -> bool {
        self.truncated
    }

    /// The first section heading in the bundle, or `None` when it is unreadable. A cheap sanity
    /// check for a client: it proves the bytes are a bundle rather than an empty string.
    pub fn first_section(&self) -> Option<&str> {
        self.text
            .lines()
            .find(|line| line.starts_with("== section: "))
            .map(|line| line.trim_start_matches("== section: ").trim())
    }
}

/// Asking for the event lines of one job.
///
/// `from_event_index` is the same cursor `FollowJobStream` resumes with (`RFC-0002 §10.1` exposes
/// `StreamFrame.seq` for exactly this purpose), and it is **exclusive**: the reply starts at the next
/// event. `max_lines` and `max_bytes` bound the answer — a job log is a big collection
/// (`RFC-0002 §9`: those **MUST** be paged or streamed) and a query response is an inline IPC frame
/// (`§11.4`: large payloads **MUST NOT** be returned as one giant frame), so an unbounded read is not
/// a legal implementation. Leaving both out asks for a default page, not for everything; ask for a
/// larger page by name if that is what you want.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct JobEventsRequest {
    pub job_id: JobId,
    /// Resume position; `None` means "from the start of what is still retained".
    pub from_event_index: Option<u64>,
    /// At most this many lines. `None` = the daemon's default page size. Clamped to the daemon's cap.
    pub max_lines: Option<u32>,
    /// At most this many bytes of rendered text, counting the newlines between lines. `None` = the
    /// daemon's default, also clamped. A single line bigger than the cap is still returned, because a
    /// page that returns nothing while lines remain is a cursor that can never advance.
    ///
    /// `Some(0)` on either field is refused with `CONFIG_INVALID` rather than read as "no limit": a
    /// caller that gets back a full page after asking for zero lines cannot tell the daemon's
    /// substitution from its own request being honoured.
    pub max_bytes: Option<u64>,
}

impl JobEventsRequest {
    pub fn new(job_id: JobId) -> Self {
        Self {
            job_id,
            from_event_index: None,
            max_lines: None,
            max_bytes: None,
        }
    }

    pub fn from(mut self, from_event_index: u64) -> Self {
        self.from_event_index = Some(from_event_index);
        self
    }

    pub fn with_max_lines(mut self, max_lines: u32) -> Self {
        self.max_lines = Some(max_lines);
        self
    }

    pub fn with_max_bytes(mut self, max_bytes: u64) -> Self {
        self.max_bytes = Some(max_bytes);
        self
    }
}

/// The retained event window of one job, as text lines.
///
/// `JobFollowView` reports *how many* stages, logs and warnings a job produced; it never carried the
/// lines themselves, so a caller comparing two access paths could see `log_count: 14` on both and
/// conclude they agreed while one of them had dropped a stage and invented another. That is the whole
/// point of this view (`docs/history/ONBOARDING_NOTES.md §4.50`).
///
/// The lines are the same ones the stream path delivers, and they are already masked: redaction
/// happens when a job event is appended (`caly-engine::service::append_job_event`), so every reader —
/// follow, stream, bundle and this query — inherits it rather than remembering to apply it.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct JobEventsView {
    pub job_id: JobId,
    pub state: String,
    /// Rendered lines, oldest first, within the retention window and within the page that was asked
    /// for.
    pub events: Vec<String>,
    /// Index the next event will get.
    pub next_event_index: u64,
    /// First index still retained; non-zero means older lines were dropped by policy, not by us.
    pub retained_from_event_index: u64,
    /// `true` when the caller asked for a position the window no longer covers.
    pub reset_required: bool,
    /// Bytes of `events` joined by newlines, so a caller can tell a capped page from a cheap one.
    pub byte_len: u64,
    /// Put this back in `from_event_index` to read what is left; it is the last index this page
    /// returned, because the request cursor is exclusive. `None` means the page reached
    /// `next_event_index`, so `is_truncated()` is exactly `next_from_event_index.is_some()`.
    pub next_from_event_index: Option<u64>,
}

impl JobEventsView {
    /// Lines dropped by the retention policy before this window started.
    pub fn dropped_event_count(&self) -> u64 {
        self.retained_from_event_index
    }

    pub fn is_empty(&self) -> bool {
        self.events.is_empty()
    }

    /// `true` when this reply is a page rather than the whole remaining window.
    pub fn is_truncated(&self) -> bool {
        self.next_from_event_index.is_some()
    }
}

/// Bounds for a storage garbage-collection **plan** query (`ADR-038 §1`).
///
/// `None` means "use the daemon's default", never "no bound": an unbounded maintenance query is the
/// thing this suite keeps having to take back.
#[derive(Clone, Debug, Default, Eq, PartialEq)]
pub struct GcPlanRequest {
    pub grace_period_ms: Option<i64>,
    pub max_deletions: Option<u32>,
}

impl GcPlanRequest {
    pub fn new() -> Self {
        Self::default()
    }

    pub fn with_grace_period_ms(mut self, millis: i64) -> Self {
        self.grace_period_ms = Some(millis);
        self
    }

    pub fn with_max_deletions(mut self, count: u32) -> Self {
        self.max_deletions = Some(count);
        self
    }
}

/// What to reclaim now (`ADR-038 §2`). The bounds are the same two numbers the plan query takes, and
/// for the same reason: a cycle must not be able to run against bounds the operator never saw reported.
/// There is deliberately **no `dry_run`** field -- `system.gc-plan` *is* the dry run, and a second way
/// to ask for one is a second way to get them to disagree.
#[derive(Clone, Debug, Default, Eq, PartialEq)]
pub struct GcCollectRequest {
    pub grace_period_ms: Option<i64>,
    pub max_deletions: Option<u32>,
}

impl GcCollectRequest {
    pub fn new() -> Self {
        Self::default()
    }

    pub fn with_grace_period_ms(mut self, millis: i64) -> Self {
        self.grace_period_ms = Some(millis);
        self
    }

    pub fn with_max_deletions(mut self, count: u32) -> Self {
        self.max_deletions = Some(count);
        self
    }
}

/// What one collection cycle did. `refused` being `Some` means nothing was deleted and why.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct GcRunView {
    pub at_generation: u64,
    pub now_unix_ms: i64,
    pub now_source: String,
    pub grace_period_ms: i64,
    pub max_deletions: usize,
    pub collected: Vec<String>,
    pub failed: Vec<GcFailureView>,
    pub retained_total: usize,
    pub skipped_for_grace: usize,
    /// Content files the same cycle removed (orphan anchors and write residue). Same split as the
    /// record's lists: `deleted` counts objects, `content_deleted` counts bytes nobody owned.
    pub collected_content: Vec<String>,
    pub failed_content: Vec<GcFailureView>,
    pub refused: Option<String>,
    /// `caller` or `automation:gc.idle` (`ADR-038 §13.2`): who let the daemon touch data on its own.
    ///
    /// Carried as a `String` here rather than an enum because nothing branches on it -- it is read by a
    /// human and by `docs/guides/ERRORS.md`-style triage. Kept **identical in wording** to
    /// `caly_engine::gc_plan::GcRunRecord::summary_line`: this type currently has no producer, so a
    /// second spelling of one sentence would only be discovered by the day someone wires it up.
    pub triggered_by: String,
}

impl GcRunView {
    pub fn deleted_count(&self) -> usize {
        self.collected.len()
    }

    pub fn summary_line(&self) -> String {
        match &self.refused {
            Some(refusal) => format!(
                "gc cycle at revision={} refused: {refusal} triggered_by={}",
                self.at_generation, self.triggered_by
            ),
            None => format!(
                "gc cycle at revision={} deleted={} failed={} retained={} skipped_for_grace={} \
                 content_deleted={} content_failed={} now={}@{} triggered_by={}",
                self.at_generation,
                self.collected.len(),
                self.failed.len(),
                self.retained_total,
                self.skipped_for_grace,
                self.collected_content.len(),
                self.failed_content.len(),
                self.now_unix_ms,
                self.now_source,
                self.triggered_by,
            ),
        }
    }
}

/// One object the store refused to remove, with what it said.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct GcFailureView {
    pub digest: String,
    pub reason: String,
}

/// One retained object and the roots holding it. `reasons` are the stable `§13.1` class names, not
/// prose, because `doctor`, a support bundle and a client all have to key off the same string.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct GcRetainedView {
    pub digest: String,
    pub reasons: Vec<String>,
}

/// A root class the plan could not assemble, and why that matters (`ADR-038 §1`).
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct GcRootGapView {
    pub class: String,
    pub detail: String,
    /// Whether an operator can clear this without shipping anything. `doctor` warns only for the true
    /// ones, so "a finding" keeps meaning "something to do" (`ADR-038 §1`).
    pub actionable: bool,
}

/// What a GC cycle would do, computed without deleting anything.
///
/// `collect` is empty whenever `gaps` is non-empty, and `would_run` says whether a real cycle would be
/// allowed at all right now. Those are different facts: a complete plan can be perfectly ineligible
/// because a deployment is mid-flight, and an eligible one can be refused because a root class could
/// not be read.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct GcPlanView {
    pub now_unix_ms: i64,
    /// Which clock `now_unix_ms` came from (`"storage-clock"` / `"execution-policy-base"`). Part of the
    /// answer rather than a footnote: object ages may be file dates while this may be a deterministic
    /// stand-in, and the two cannot be compared (`ADR-038 §3`).
    pub now_source: String,
    pub grace_period_ms: i64,
    pub max_deletions: usize,
    pub sample_limit: usize,
    pub objects_total: usize,
    pub snapshots_total: usize,
    pub revisions_total: usize,
    pub unfinished_journals: usize,
    pub collect: Vec<String>,
    pub retained_total: usize,
    pub retained_sample: Vec<GcRetainedView>,
    pub deferred_over_cap: usize,
    pub skipped_for_grace: usize,
    /// The content half (`RFC-0007 §6.1`): files under `objects/sha256/**` the metadata-keyed
    /// numbers above cannot see. `content_total` counts what the walk found; the lists and counts
    /// below are the orphan subset, bounded like `retained_sample`.
    pub content_total: usize,
    /// A sample of what the cycle would remove, in the operator spelling the run record echoes.
    pub orphan_collect: Vec<String>,
    pub orphan_skipped_for_grace: usize,
    pub orphan_deferred_over_cap: usize,
    pub idle: bool,
    pub pending_deployments: usize,
    pub gaps: Vec<GcRootGapView>,
    /// Whether a real cycle would be allowed right now. Computed once, in the daemon, from the gaps
    /// and the eligibility counters above -- the view carries the answer rather than re-deriving it,
    /// because a client that recomputes `would_run` from these fields is a second policy.
    pub would_run: bool,
    pub refusal: Option<String>,
    /// What the last collection cycle in this process did, if any (`ADR-038 §2`).
    ///
    /// This field is the reason `GcRunView` exists: it used to be a type with a renderer and **no
    /// producer**, which is the shape that lets a client-facing sentence drift from the operator-facing
    /// one without anything failing (`docs/history/ONBOARDING_NOTES.md §4.102`). `None` is "this process has
    /// not run a cycle" -- not "the cycle did nothing", which is a different answer and is `Some` with
    /// `deleted=0`.
    /// Boxed on purpose: this view travels inside `OperationResult`, so its size is a property
    /// of the whole response channel. Embedding `GcRunView` (three `Vec`s and two `String`s) pushed
    /// `caly_ipc`'s frame enums past clippy's `large_enum_variant` threshold in two files nobody
    /// touched (`docs/history/ONBOARDING_NOTES.md §4.106`) -- a DTO field is not local.
    pub last_run: Option<Box<GcRunView>>,
}

impl GcPlanView {
    /// Derived, never stored: a truncation flag that a producer can forget to set is how a partial
    /// answer starts looking complete (`ADR-035 §2.1`, the same reasoning as `JobEventsView`).
    pub fn is_truncated(&self) -> bool {
        self.retained_total > self.retained_sample.len()
    }

    /// The one-line form `doctor` prints and the parity harness compares. It is built from the same
    /// fields the view carries, so the summary and the detail cannot tell different stories.
    pub fn summary_line(&self) -> String {
        format!(
            "gc plan objects={} collect={} retained={} deferred={} now={}@{} gaps={} would_run={}{}{} content_orphans={} content_collect={} content_grace={} content_deferred={}",
            self.objects_total,
            self.collect.len(),
            self.retained_total,
            self.deferred_over_cap,
            self.now_unix_ms,
            self.now_source,
            self.gaps.len(),
            self.would_run,
            if self.is_truncated() {
                " truncated=true"
            } else {
                ""
            },
            match &self.last_run {
                // The record's own sentence, rendered by this DTO rather than re-spelled: a client and
                // `doctor` reading two wordings of one cycle is how an operator starts doubting both.
                Some(run) => format!(" last_run={}", run.summary_line()),
                None => String::new(),
            },
            // Same totals the plan's own sentence carries, so the view and the summary cannot
            // disagree about the content half either (`content_total` minus referenced is not
            // derivable here -- the referenced count lives in the metadata the plan read).
            self.orphan_collect.len() + self.orphan_skipped_for_grace + self.orphan_deferred_over_cap,
            self.orphan_collect.len(),
            self.orphan_skipped_for_grace,
            self.orphan_deferred_over_cap
        )
    }
}
