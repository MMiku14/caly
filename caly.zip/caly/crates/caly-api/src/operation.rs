pub use crate::dto::{
    Accepted, ApplyRequest, AutomationJobView, CapabilityQuery, CapabilityReport, ConnectionPage,
    ConnectionQuery, ConnectionView, CoreInspection, CoreInstallView, DelayTestRequest,
    DeploymentPlanView, DnsExplainRequest, DnsExplainResult, DnsStatus, DoctorReport,
    DoctorRequest, EstimatedImpact, GcCollectRequest, GcFailureView, GcPlanRequest, GcPlanView,
    GcRetainedView, GcRootGapView, GcRunView, GroupView, JobEventsRequest, JobEventsView,
    JobFollowRequest, JobFollowView, NetworkPlanView, NetworkStatus, NodePage, NodeQuery, NodeView,
    PageRequest, PatchAutomationJob, PipelineExplain, PipelineExplainRequest, ProfileSummary,
    ProfileView, ProtocolVersion, RecoveryStatusView, RollbackRequest, RouteExplainRequest,
    RouteExplainResult, RoutingValidation, RulePage, RuleQuery, RuleView, RuntimeStatus,
    RuntimeSubscription, SelectNode, ServerInfo, SourceInspection, SourcePreview,
    SourcePreviewRequest, SourceSummary, SupportBundleReadRequest, SupportBundleView, SystemStatus,
    WatchOpened,
};
pub use crate::ids::{
    ConnectionId, CoreInstallId, Ctx, GroupId, JobId, NodeId, ProfileId, RequestId, SourceId,
    StreamId,
};
pub use crate::meta::{CostClass, Idempotency, OperationMeta, OperationMode, Role};
pub use crate::ops::{
    AutomationOp, CoreOp, DiagnosticsOp, DnsOp, NetworkOp, ProfileOp, ProxyOp, RoutingOp,
    RuntimeOp, SourceOp, SystemOp,
};

#[derive(Clone, Debug, Eq, PartialEq)]
pub enum Operation {
    System(SystemOp),
    Profile(ProfileOp),
    Source(SourceOp),
    Proxy(ProxyOp),
    Routing(RoutingOp),
    Dns(DnsOp),
    Network(NetworkOp),
    Core(CoreOp),
    Runtime(RuntimeOp),
    Diagnostics(DiagnosticsOp),
    Automation(AutomationOp),
}

impl Operation {
    pub fn meta(&self) -> OperationMeta {
        match self {
            Self::System(op) => op.meta(),
            Self::Profile(op) => op.meta(),
            Self::Source(op) => op.meta(),
            Self::Proxy(op) => op.meta(),
            Self::Routing(op) => op.meta(),
            Self::Dns(op) => op.meta(),
            Self::Network(op) => op.meta(),
            Self::Core(op) => op.meta(),
            Self::Runtime(op) => op.meta(),
            Self::Diagnostics(op) => op.meta(),
            Self::Automation(op) => op.meta(),
        }
    }
}
