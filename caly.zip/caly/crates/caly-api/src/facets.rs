use std::future::Future;
use std::pin::Pin;
use std::sync::Arc;

use crate::{
    Accepted, ApiError, ApplyRequest, AutomationJobView, CapabilityQuery, CapabilityReport,
    ConnectionId, ConnectionPage, ConnectionQuery, CoreInspection, CoreInstallId, CoreInstallView,
    Ctx, DelayTestRequest, DeploymentPlanView, DnsExplainRequest, DnsExplainResult, DnsStatus,
    DoctorReport, DoctorRequest, GcCollectRequest, GcPlanRequest, GcPlanView, GroupView,
    JobEventsRequest, JobEventsView, JobFollowRequest, JobFollowView, NetworkPlanView,
    NetworkStatus, NodePage, NodeQuery, PatchAutomationJob, PipelineExplain,
    PipelineExplainRequest, ProfileId, ProfileSummary, ProfileView, RecoveryStatusView,
    RollbackRequest, RouteExplainRequest, RouteExplainResult, RoutingValidation, RulePage,
    RuleQuery, RuntimeStatus, RuntimeSubscription, SelectNode, ServerInfo, SourceId,
    SourceInspection, SourcePreview, SourcePreviewRequest, SourceSummary, SystemStatus,
    WatchOpened,
};

pub type ApiResult<T> = Result<T, ApiError>;
pub type BoxFuture<'a, T> = Pin<Box<dyn Future<Output = T> + Send + 'a>>;

pub trait CalyFacade: Send + Sync + 'static {
    fn system(&self) -> Arc<dyn SystemFacet>;
    fn profile(&self) -> Arc<dyn ProfileFacet>;
    fn source(&self) -> Arc<dyn SourceFacet>;
    fn proxy(&self) -> Arc<dyn ProxyFacet>;
    fn routing(&self) -> Arc<dyn RoutingFacet>;
    fn dns(&self) -> Arc<dyn DnsFacet>;
    fn network(&self) -> Arc<dyn NetworkFacet>;
    fn core(&self) -> Arc<dyn CoreFacet>;
    fn runtime(&self) -> Arc<dyn RuntimeFacet>;
    fn diagnostics(&self) -> Arc<dyn DiagnosticsFacet>;
    fn automation(&self) -> Arc<dyn AutomationFacet>;
}

pub trait SystemFacet: Send + Sync + 'static {
    fn status<'a>(&'a self, ctx: Ctx) -> BoxFuture<'a, ApiResult<SystemStatus>>;
    fn info<'a>(&'a self, ctx: Ctx) -> BoxFuture<'a, ApiResult<ServerInfo>>;
    /// What a storage GC cycle would do. Read-only by contract; the deletion half is `ADR-038 §2`.
    fn plan_gc<'a>(
        &'a self,
        ctx: Ctx,
        request: GcPlanRequest,
    ) -> BoxFuture<'a, ApiResult<GcPlanView>>;
    /// One storage collection cycle. Returns the accepted job (outcomes are followed as a job, per
    /// `ADR-018`); `doctor` and the bundle report the most recent run.
    fn collect_garbage<'a>(
        &'a self,
        ctx: Ctx,
        request: GcCollectRequest,
    ) -> BoxFuture<'a, ApiResult<Accepted>>;
    fn shutdown<'a>(&'a self, ctx: Ctx) -> BoxFuture<'a, ApiResult<Accepted>>;
}

pub trait ProfileFacet: Send + Sync + 'static {
    fn list<'a>(&'a self, ctx: Ctx) -> BoxFuture<'a, ApiResult<Vec<ProfileSummary>>>;
    fn get<'a>(&'a self, ctx: Ctx, profile_id: ProfileId) -> BoxFuture<'a, ApiResult<ProfileView>>;
    fn plan<'a>(
        &'a self,
        ctx: Ctx,
        request: ApplyRequest,
    ) -> BoxFuture<'a, ApiResult<DeploymentPlanView>>;
    fn apply<'a>(&'a self, ctx: Ctx, request: ApplyRequest) -> BoxFuture<'a, ApiResult<Accepted>>;
    fn rollback<'a>(
        &'a self,
        ctx: Ctx,
        request: RollbackRequest,
    ) -> BoxFuture<'a, ApiResult<Accepted>>;
}

pub trait SourceFacet: Send + Sync + 'static {
    fn list<'a>(&'a self, ctx: Ctx) -> BoxFuture<'a, ApiResult<Vec<SourceSummary>>>;
    fn inspect<'a>(
        &'a self,
        ctx: Ctx,
        source_id: SourceId,
    ) -> BoxFuture<'a, ApiResult<SourceInspection>>;
    fn update<'a>(&'a self, ctx: Ctx, source_id: SourceId) -> BoxFuture<'a, ApiResult<Accepted>>;
    fn preview<'a>(
        &'a self,
        ctx: Ctx,
        request: SourcePreviewRequest,
    ) -> BoxFuture<'a, ApiResult<SourcePreview>>;
}

pub trait ProxyFacet: Send + Sync + 'static {
    fn nodes<'a>(&'a self, ctx: Ctx, query: NodeQuery) -> BoxFuture<'a, ApiResult<NodePage>>;
    fn groups<'a>(&'a self, ctx: Ctx) -> BoxFuture<'a, ApiResult<Vec<GroupView>>>;
    fn select<'a>(&'a self, ctx: Ctx, request: SelectNode) -> BoxFuture<'a, ApiResult<Accepted>>;
    fn test_delay<'a>(
        &'a self,
        ctx: Ctx,
        request: DelayTestRequest,
    ) -> BoxFuture<'a, ApiResult<Accepted>>;
}

pub trait RoutingFacet: Send + Sync + 'static {
    fn rules<'a>(&'a self, ctx: Ctx, query: RuleQuery) -> BoxFuture<'a, ApiResult<RulePage>>;
    fn explain<'a>(
        &'a self,
        ctx: Ctx,
        request: RouteExplainRequest,
    ) -> BoxFuture<'a, ApiResult<RouteExplainResult>>;
    fn validate<'a>(
        &'a self,
        ctx: Ctx,
        profile_id: ProfileId,
    ) -> BoxFuture<'a, ApiResult<RoutingValidation>>;
}

pub trait DnsFacet: Send + Sync + 'static {
    fn status<'a>(&'a self, ctx: Ctx) -> BoxFuture<'a, ApiResult<DnsStatus>>;
    fn explain<'a>(
        &'a self,
        ctx: Ctx,
        request: DnsExplainRequest,
    ) -> BoxFuture<'a, ApiResult<DnsExplainResult>>;
    fn flush_cache<'a>(&'a self, ctx: Ctx) -> BoxFuture<'a, ApiResult<Accepted>>;
}

pub trait NetworkFacet: Send + Sync + 'static {
    fn status<'a>(&'a self, ctx: Ctx) -> BoxFuture<'a, ApiResult<NetworkStatus>>;
    fn inspect_plan<'a>(
        &'a self,
        ctx: Ctx,
        profile_id: ProfileId,
    ) -> BoxFuture<'a, ApiResult<NetworkPlanView>>;
    fn repair<'a>(&'a self, ctx: Ctx) -> BoxFuture<'a, ApiResult<Accepted>>;
}

pub trait CoreFacet: Send + Sync + 'static {
    fn list_installs<'a>(&'a self, ctx: Ctx) -> BoxFuture<'a, ApiResult<Vec<CoreInstallView>>>;
    fn inspect<'a>(
        &'a self,
        ctx: Ctx,
        core_install_id: CoreInstallId,
    ) -> BoxFuture<'a, ApiResult<CoreInspection>>;
    fn capabilities<'a>(
        &'a self,
        ctx: Ctx,
        query: CapabilityQuery,
    ) -> BoxFuture<'a, ApiResult<CapabilityReport>>;
}

pub trait RuntimeFacet: Send + Sync + 'static {
    fn status<'a>(&'a self, ctx: Ctx) -> BoxFuture<'a, ApiResult<RuntimeStatus>>;
    fn connections<'a>(
        &'a self,
        ctx: Ctx,
        query: ConnectionQuery,
    ) -> BoxFuture<'a, ApiResult<ConnectionPage>>;
    fn close_connection<'a>(
        &'a self,
        ctx: Ctx,
        connection_id: ConnectionId,
    ) -> BoxFuture<'a, ApiResult<Accepted>>;
    fn watch<'a>(
        &'a self,
        ctx: Ctx,
        subscription: RuntimeSubscription,
    ) -> BoxFuture<'a, ApiResult<WatchOpened>>;
}

pub trait DiagnosticsFacet: Send + Sync + 'static {
    fn doctor<'a>(
        &'a self,
        ctx: Ctx,
        request: DoctorRequest,
    ) -> BoxFuture<'a, ApiResult<DoctorReport>>;
    fn explain_pipeline<'a>(
        &'a self,
        ctx: Ctx,
        request: PipelineExplainRequest,
    ) -> BoxFuture<'a, ApiResult<PipelineExplain>>;
    fn recovery_status<'a>(&'a self, ctx: Ctx) -> BoxFuture<'a, ApiResult<RecoveryStatusView>>;
    fn follow_job<'a>(
        &'a self,
        ctx: Ctx,
        request: JobFollowRequest,
    ) -> BoxFuture<'a, ApiResult<JobFollowView>>;
    fn follow_job_stream<'a>(
        &'a self,
        ctx: Ctx,
        request: JobFollowRequest,
    ) -> BoxFuture<'a, ApiResult<WatchOpened>>;
    fn support_bundle<'a>(&'a self, ctx: Ctx) -> BoxFuture<'a, ApiResult<Accepted>>;
    /// The retained event lines of a job. A `Query`, deliberately: the stream is the live view, and
    /// this is the one a caller uses to find out what the stream has already shown somebody else —
    /// including on the local path, which has no stream to pull from
    /// (`docs/history/ONBOARDING_NOTES.md §4.52`).
    fn read_job_events<'a>(
        &'a self,
        ctx: Ctx,
        request: JobEventsRequest,
    ) -> BoxFuture<'a, ApiResult<JobEventsView>>;
    /// Read a previously written bundle back out of the store, by digest.
    fn read_support_bundle<'a>(
        &'a self,
        ctx: Ctx,
        request: crate::dto::SupportBundleReadRequest,
    ) -> BoxFuture<'a, ApiResult<crate::dto::SupportBundleView>>;
}

pub trait AutomationFacet: Send + Sync + 'static {
    fn list_jobs<'a>(&'a self, ctx: Ctx) -> BoxFuture<'a, ApiResult<Vec<AutomationJobView>>>;
    fn patch_job<'a>(
        &'a self,
        ctx: Ctx,
        request: PatchAutomationJob,
    ) -> BoxFuture<'a, ApiResult<Accepted>>;
}
