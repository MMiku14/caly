use caly_common::{Actor, IoBudget, RequestContext};

use crate::error::{ApiError, TraceId};
use crate::ids::{Ctx, RequestId};
use crate::meta::Role;
use crate::operation::{Operation, ProtocolVersion};
use crate::result::OperationResult;

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct RequestEnvelope {
    pub protocol: ProtocolVersion,
    pub request_id: RequestId,
    pub trace_id: TraceId,
    pub deadline_ms: Option<u64>,
    pub expected_revision: Option<u64>,
    pub idempotency_key: Option<String>,
    pub role: Role,
    pub operation: Operation,
    /// The caller's IO budget for this request, if it wants one (`ADR-036 §2.4`).
    ///
    /// `None` means "the daemon's default", which is `IoBudget::default_command()`: bounded
    /// `max_requests` (see `caly_common::IoBudget::DEFAULT_COMMAND_STORE_REQUESTS`), no byte cap at
    /// this layer, and *both facts documented*. The field exists because `request_map` used to
    /// hard-code `unlimited()` for every inbound request, so `Ctx::io_budget` had no path to the daemon
    /// at all -- the discrepancy `ADR-036 §6bis.2` recorded against its own text.
    ///
    /// A `Some(_)` here is honoured verbatim, including `max_requests: Some(0)`: "no accounted store
    /// access may be made" is unambiguous, and refusing is the point rather than a value to reject.
    pub io_budget: Option<IoBudget>,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct ResponseEnvelope {
    pub request_id: RequestId,
    pub trace_id: TraceId,
    pub result: Result<OperationResult, ApiError>,
}

pub fn default_ctx(trace_id: impl Into<String>, actor: Actor) -> Ctx {
    RequestContext {
        trace_id: TraceId::new(trace_id),
        actor,
        deadline_ms: None,
        expected_revision: None,
        io_budget: IoBudget::default_command(),
        idempotency_key: None,
        cancel: caly_common::CancelToken::default(),
        deadline_mono_ms: None,
    }
}
