use crate::dto::{
    ApplyRequest, CapabilityQuery, ConnectionQuery, CoreInstallId, DelayTestRequest,
    DnsExplainRequest, DoctorRequest, GcCollectRequest, GcPlanRequest, JobEventsRequest,
    JobFollowRequest, PatchAutomationJob, PipelineExplainRequest, ProfileId, RollbackRequest,
    RouteExplainRequest, RuntimeSubscription, SelectNode, SourceId, SourcePreviewRequest,
    SupportBundleReadRequest,
};
use crate::ids::ConnectionId;
use crate::meta::{CostClass, Idempotency, OperationMeta, Role};

#[derive(Clone, Debug, Eq, PartialEq)]
pub enum SystemOp {
    Status,
    Info,
    /// What a storage GC cycle would remove, computed without removing anything (`ADR-038 §1`).
    /// A query, but not a `Viewer` one: it names internal object digests, and it is the input to a
    /// decision that deletes data, so it sits with the maintenance role rather than the dashboard one.
    GcPlan {
        request: GcPlanRequest,
    },
    /// Reclaim unreferenced objects now (`ADR-038 §2`). A command, not a query: it deletes.
    CollectGarbage {
        request: GcCollectRequest,
    },
    Shutdown,
}

impl SystemOp {
    pub fn meta(&self) -> OperationMeta {
        match self {
            Self::Status | Self::Info => OperationMeta::query(Role::Viewer, CostClass::Tiny),
            Self::GcPlan { .. } => OperationMeta::query(Role::Operator, CostClass::Medium),
            // `Idempotency::Required`, per `ADR-037 §2.3`: a retry of a cycle that already ran must not
            // sweep twice, and unlike an apply there is no natural value to derive -- the store has
            // moved on in between. `mutates_revision` is true because a cycle that removed anything
            // does move the state `expected_revision` compares against; `supports_dry_run` is false
            // because the dry run is its own operation (`system.gc-plan`), not a flag here.
            // `CostClass::Large` measures cost, not privilege -- the role field carries that.
            Self::CollectGarbage { .. } => OperationMeta::command(
                Idempotency::Required,
                Role::Admin,
                true,
                false,
                CostClass::Large,
            ),
            Self::Shutdown => OperationMeta::command(
                Idempotency::Required,
                Role::Admin,
                false,
                false,
                CostClass::Privileged,
            ),
        }
    }
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub enum ProfileOp {
    List,
    Get { profile_id: ProfileId },
    Plan { request: ApplyRequest },
    Apply { request: ApplyRequest },
    Rollback { request: RollbackRequest },
}

impl ProfileOp {
    pub fn meta(&self) -> OperationMeta {
        match self {
            Self::List | Self::Get { .. } => OperationMeta::query(Role::Viewer, CostClass::Small),
            Self::Plan { .. } => OperationMeta::query(Role::Operator, CostClass::Medium),
            Self::Apply { .. } | Self::Rollback { .. } => OperationMeta::command(
                Idempotency::Required,
                Role::Operator,
                true,
                true,
                CostClass::Large,
            ),
        }
    }
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub enum SourceOp {
    List,
    Inspect { source_id: SourceId },
    Update { source_id: SourceId },
    Preview { request: SourcePreviewRequest },
}

impl SourceOp {
    pub fn meta(&self) -> OperationMeta {
        match self {
            Self::List | Self::Inspect { .. } | Self::Preview { .. } => {
                OperationMeta::query(Role::Viewer, CostClass::Small)
            }
            Self::Update { .. } => OperationMeta::command(
                Idempotency::Optional,
                Role::Operator,
                true,
                false,
                CostClass::Medium,
            ),
        }
    }
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub enum ProxyOp {
    Nodes { query: crate::dto::NodeQuery },
    Groups,
    Select { request: SelectNode },
    TestDelay { request: DelayTestRequest },
}

impl ProxyOp {
    pub fn meta(&self) -> OperationMeta {
        match self {
            Self::Nodes { .. } | Self::Groups => {
                OperationMeta::query(Role::Viewer, CostClass::Small)
            }
            Self::Select { .. } => OperationMeta::command(
                Idempotency::Optional,
                Role::Operator,
                true,
                false,
                CostClass::Small,
            ),
            Self::TestDelay { .. } => OperationMeta::command(
                Idempotency::Optional,
                Role::Operator,
                false,
                false,
                CostClass::Medium,
            ),
        }
    }
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub enum RoutingOp {
    Rules { query: crate::dto::RuleQuery },
    Explain { request: RouteExplainRequest },
    Validate { profile_id: ProfileId },
}

impl RoutingOp {
    pub fn meta(&self) -> OperationMeta {
        OperationMeta::query(Role::Viewer, CostClass::Medium)
    }
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub enum DnsOp {
    Status,
    Explain { request: DnsExplainRequest },
    FlushCache,
}

impl DnsOp {
    pub fn meta(&self) -> OperationMeta {
        match self {
            Self::Status | Self::Explain { .. } => {
                OperationMeta::query(Role::Viewer, CostClass::Small)
            }
            Self::FlushCache => OperationMeta::command(
                Idempotency::Optional,
                Role::Operator,
                false,
                false,
                CostClass::Small,
            ),
        }
    }
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub enum NetworkOp {
    Status,
    InspectPlan { profile_id: ProfileId },
    Repair,
}

impl NetworkOp {
    pub fn meta(&self) -> OperationMeta {
        match self {
            Self::Status | Self::InspectPlan { .. } => {
                OperationMeta::query(Role::Viewer, CostClass::Medium)
            }
            Self::Repair => OperationMeta::command(
                Idempotency::Required,
                Role::Admin,
                false,
                false,
                CostClass::Privileged,
            ),
        }
    }
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub enum CoreOp {
    ListInstalls,
    Inspect { core_install_id: CoreInstallId },
    Capabilities { query: CapabilityQuery },
}

impl CoreOp {
    pub fn meta(&self) -> OperationMeta {
        OperationMeta::query(Role::Viewer, CostClass::Small)
    }
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub enum RuntimeOp {
    Status,
    Connections { query: ConnectionQuery },
    CloseConnection { connection_id: ConnectionId },
    Watch { subscription: RuntimeSubscription },
}

impl RuntimeOp {
    pub fn meta(&self) -> OperationMeta {
        match self {
            Self::Status | Self::Connections { .. } => {
                OperationMeta::query(Role::Viewer, CostClass::Small)
            }
            Self::CloseConnection { .. } => OperationMeta::command(
                Idempotency::Optional,
                Role::Operator,
                false,
                false,
                CostClass::Small,
            ),
            Self::Watch { .. } => OperationMeta::stream(Role::Viewer, CostClass::Medium),
        }
    }
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub enum DiagnosticsOp {
    Doctor {
        request: DoctorRequest,
    },
    /// Read back a bundle that the `SupportBundle` command wrote into the store. A query, not a
    /// command: nothing changes, and `RFC-0010 §12.2` would be unenforceable if the only way to
    /// obtain an export were to run another one.
    ReadSupportBundle {
        request: SupportBundleReadRequest,
    },
    ExplainPipeline {
        request: PipelineExplainRequest,
    },
    RecoveryStatus,
    FollowJob {
        request: JobFollowRequest,
    },
    /// The retained event lines of a job, as text. A separate operation from `FollowJob` because the
    /// summary and the content answer different questions, and a caller that only wants counts should
    /// not have to receive (and hash) the whole window. Its request is *not* `JobFollowRequest`: the
    /// content read is a paged query (`RFC-0002 §9`, `§11.4`) and the follow summary is not, so they
    /// cannot share a struct without one of them carrying a field it never reads.
    ReadJobEvents {
        request: JobEventsRequest,
    },
    FollowJobStream {
        request: JobFollowRequest,
    },
    SupportBundle,
}

impl DiagnosticsOp {
    pub fn meta(&self) -> OperationMeta {
        match self {
            Self::Doctor { .. }
            | Self::ReadSupportBundle { .. }
            | Self::ExplainPipeline { .. }
            | Self::RecoveryStatus
            | Self::FollowJob { .. }
            | Self::ReadJobEvents { .. } => OperationMeta::query(Role::Viewer, CostClass::Medium),
            // `ReadJobEvents` deliberately shares the summary's cost class: it reads a bounded
            // window of lines that were rendered and masked long ago, so it must never become the
            // expensive way to look at a job.
            Self::FollowJobStream { .. } => OperationMeta::stream(Role::Viewer, CostClass::Medium),
            Self::SupportBundle => OperationMeta::command(
                Idempotency::Optional,
                Role::Operator,
                false,
                false,
                CostClass::Large,
            ),
        }
    }
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub enum AutomationOp {
    ListJobs,
    PatchJob { request: PatchAutomationJob },
}

impl AutomationOp {
    pub fn meta(&self) -> OperationMeta {
        match self {
            Self::ListJobs => OperationMeta::query(Role::Viewer, CostClass::Small),
            Self::PatchJob { .. } => OperationMeta::command(
                Idempotency::Optional,
                Role::Operator,
                true,
                false,
                CostClass::Medium,
            ),
        }
    }
}
