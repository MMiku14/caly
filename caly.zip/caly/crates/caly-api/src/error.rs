use std::fmt;

pub use caly_common::TraceId;

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct DiagnosticSummary {
    pub code: String,
    pub message: String,
    pub path: Option<String>,
}

#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub enum ErrorCategory {
    User,
    Config,
    Capability,
    Core,
    Io,
    Platform,
    Internal,
}

impl ErrorCategory {
    pub const fn as_str(self) -> &'static str {
        match self {
            Self::User => "User",
            Self::Config => "Config",
            Self::Capability => "Capability",
            Self::Core => "Core",
            Self::Io => "Io",
            Self::Platform => "Platform",
            Self::Internal => "Internal",
        }
    }
}

/// The per-code retry character, as `docs/ERRORS.md §4`'s Retryable column declares it.
///
/// This is richer than `ApiError::retryable`'s bool, which stays the instance-level wire
/// field: `Maybe` and `Depends` are *not* flattenable into it — a call site must still
/// decide per instance. `Cancelled` and `Internal` are not in §4 (`§4.1` reserves them);
/// their ruling is the code's own: a user interrupt and an implementation failure are
/// never worth a blind retry.
#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub enum RetryPolicy {
    /// 否 — retrying the same call cannot succeed.
    Never,
    /// 可能 — may succeed on retry; the caller decides.
    Maybe,
    /// 视场景 — depends on the scenario, per `ERRORS.md §5.x`.
    Depends,
    /// 是 — retry is the documented response.
    Always,
}

#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub enum ErrorCode {
    ConfigInvalid,
    Conflict,
    UnsupportedCapability,
    CoreNotRunning,
    CoreFailed,
    Permission,
    NetOs,
    Storage,
    Timeout,
    Unavailable,
    ProtoMismatch,
    CursorStale,
    Cancelled,
    Internal,
}

impl ErrorCode {
    /// The canonical category for this code, as `docs/ERRORS.md §4`'s Category column
    /// declares it.
    ///
    /// Category is a per-instance classification in this codebase: `§5.1` itself pins
    /// `CONFIG_INVALID` + `User` for the io-budget case, and every site that deviates
    /// from the §4 default does so for caller-mistake reasons (see IMPLEMENTATION_STATUS
    /// §8.18 for the audited inventory; `app.rs`'s lifecycle refusal is the one item
    /// still open). `Cancelled` and `Internal` are not in §4 (`§4.1` reserves them);
    /// their classes are the code's own ruling: a user interrupt, and an implementation
    /// failure.
    pub const fn category(self) -> ErrorCategory {
        match self {
            Self::ConfigInvalid => ErrorCategory::Config,
            Self::Conflict => ErrorCategory::Config,
            Self::UnsupportedCapability => ErrorCategory::Capability,
            Self::CoreNotRunning => ErrorCategory::Core,
            Self::CoreFailed => ErrorCategory::Core,
            Self::Permission => ErrorCategory::Platform,
            Self::NetOs => ErrorCategory::Platform,
            Self::Storage => ErrorCategory::Io,
            Self::Timeout => ErrorCategory::Io,
            Self::Unavailable => ErrorCategory::Io,
            Self::ProtoMismatch => ErrorCategory::User,
            Self::CursorStale => ErrorCategory::User,
            Self::Cancelled => ErrorCategory::User,
            Self::Internal => ErrorCategory::Internal,
        }
    }

    /// The canonical retry character for this code, as `docs/ERRORS.md §4`'s Retryable
    /// column declares it; `error_doc.rs` pins the two never to drift apart.
    pub const fn retry_policy(self) -> RetryPolicy {
        match self {
            Self::ConfigInvalid => RetryPolicy::Never,
            Self::Conflict => RetryPolicy::Never,
            Self::UnsupportedCapability => RetryPolicy::Never,
            Self::CoreNotRunning => RetryPolicy::Never,
            Self::CoreFailed => RetryPolicy::Depends,
            Self::Permission => RetryPolicy::Maybe,
            Self::NetOs => RetryPolicy::Maybe,
            Self::Storage => RetryPolicy::Maybe,
            Self::Timeout => RetryPolicy::Always,
            Self::Unavailable => RetryPolicy::Always,
            Self::ProtoMismatch => RetryPolicy::Never,
            Self::CursorStale => RetryPolicy::Never,
            Self::Cancelled => RetryPolicy::Never,
            Self::Internal => RetryPolicy::Never,
        }
    }

    pub const fn as_str(self) -> &'static str {
        match self {
            Self::ConfigInvalid => "CONFIG_INVALID",
            Self::Conflict => "CONFLICT",
            Self::UnsupportedCapability => "UNSUPPORTED_CAPABILITY",
            Self::CoreNotRunning => "CORE_NOT_RUNNING",
            Self::CoreFailed => "CORE_FAILED",
            Self::Permission => "PERMISSION",
            Self::NetOs => "NET_OS",
            Self::Storage => "STORAGE",
            Self::Timeout => "TIMEOUT",
            Self::Unavailable => "UNAVAILABLE",
            Self::ProtoMismatch => "PROTO_MISMATCH",
            Self::CursorStale => "CURSOR_STALE",
            Self::Cancelled => "CANCELLED",
            Self::Internal => "INTERNAL",
        }
    }
}

impl fmt::Display for ErrorCode {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(self.as_str())
    }
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct ApiError {
    pub code: ErrorCode,
    pub category: ErrorCategory,
    pub retryable: bool,
    pub summary: String,
    pub detail: Option<String>,
    pub remediation: Option<String>,
    pub diagnostics: Vec<DiagnosticSummary>,
    pub trace_id: TraceId,
}

impl ApiError {
    pub fn new(
        code: ErrorCode,
        category: ErrorCategory,
        retryable: bool,
        summary: impl Into<String>,
        trace_id: TraceId,
    ) -> Self {
        Self {
            code,
            category,
            retryable,
            summary: summary.into(),
            detail: None,
            remediation: None,
            diagnostics: Vec::new(),
            trace_id,
        }
    }

    pub fn with_detail(mut self, detail: impl Into<String>) -> Self {
        self.detail = Some(detail.into());
        self
    }

    pub fn with_remediation(mut self, remediation: impl Into<String>) -> Self {
        self.remediation = Some(remediation.into());
        self
    }

    pub fn with_diagnostic(mut self, diagnostic: DiagnosticSummary) -> Self {
        self.diagnostics.push(diagnostic);
        self
    }

    pub fn internal(summary: impl Into<String>, trace_id: TraceId) -> Self {
        Self::new(
            ErrorCode::Internal,
            ErrorCategory::Internal,
            false,
            summary,
            trace_id,
        )
    }

    /// Whether any text in this error still contains something `redactor` would mask.
    pub fn exposes_sensitive_text(&self, redactor: &caly_common::redact::Redactor) -> bool {
        redactor.exposes_sensitive_text(&self.summary)
            || self
                .detail
                .as_deref()
                .is_some_and(|value| redactor.exposes_sensitive_text(value))
            || self
                .remediation
                .as_deref()
                .is_some_and(|value| redactor.exposes_sensitive_text(value))
            || self
                .diagnostics
                .iter()
                .any(|item| item.exposes_sensitive_text(redactor))
    }

    /// This error with every text field masked, `RFC-0010 §7.2`'s 「`ApiError.summary/detail` MUST
    /// 已脱敏」.
    ///
    /// `ADR-020 §3` wants redaction done when the error is *constructed*, but construction is
    /// scattered over a dozen crates and most of those sites interpolate text they do not own (a
    /// profile id from the request, a core's stderr, a path). This is the single place where every
    /// one of those strings has passed — the response boundary — so it is where the guarantee is
    /// actually enforceable. `Redactor::redact` is idempotent, so a site that already masked pays a
    /// comparison and changes nothing; the code below deliberately skips that work when nothing
    /// would change, because an error path must not allocate on a hot failure.
    pub fn redacted(&self, redactor: &caly_common::redact::Redactor) -> Self {
        if !self.exposes_sensitive_text(redactor) {
            return self.clone();
        }
        Self {
            code: self.code,
            category: self.category,
            retryable: self.retryable,
            summary: redactor.redact(&self.summary),
            detail: self
                .detail
                .as_ref()
                .map(|value| redactor.redact(value))
                .filter(|value| !value.is_empty()),
            remediation: self
                .remediation
                .as_ref()
                .map(|value| redactor.redact(value)),
            diagnostics: self
                .diagnostics
                .iter()
                .map(|item| item.redacted(redactor))
                .collect(),
            trace_id: self.trace_id.clone(),
        }
    }
}

impl DiagnosticSummary {
    pub fn exposes_sensitive_text(&self, redactor: &caly_common::redact::Redactor) -> bool {
        redactor.exposes_sensitive_text(&self.message)
            || self
                .path
                .as_deref()
                .is_some_and(|value| redactor.exposes_sensitive_text(value))
    }

    pub fn redacted(&self, redactor: &caly_common::redact::Redactor) -> Self {
        if !self.exposes_sensitive_text(redactor) {
            return self.clone();
        }
        Self {
            code: self.code.clone(),
            message: redactor.redact(&self.message),
            path: self.path.as_ref().map(|value| redactor.redact(value)),
        }
    }
}

/// Move an error back out of a box at a boundary that must speak `ApiError`.
///
/// `ApiError` is wide enough that clippy counts every `Result<_, ApiError>` in the tree as a
/// `result_large_err` — 25 sites, and every one of them is code that only passes the error along. The
/// plumbing therefore carries `Box<ApiError>` and unboxes here, once, where the frozen façade shape
/// requires the value itself. This costs nothing (a move out of the box) and it is why no call site
/// needs a `map_err` for it.
impl From<Box<ApiError>> for ApiError {
    fn from(value: Box<ApiError>) -> Self {
        *value
    }
}
