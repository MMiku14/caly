//! Deterministic cache quota eviction planning.

use caly_domain::BoundedVec;

/// Maximum generations considered in one cache root.
pub const MAX_CACHE_GENERATIONS: usize = 1_024;
pub type EvictionPlan = BoundedVec<[u8; 16], MAX_CACHE_GENERATIONS>;

#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub struct GenerationUsage {
    pub id: [u8; 16],
    pub bytes: u64,
    pub created_sequence: u64,
    pub is_current: bool,
}

#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub enum QuotaError {
    TooManyGenerations,
    CurrentAloneExceedsQuota,
}

/// Selects oldest non-current generations until both quotas are satisfied.
pub fn plan_evictions(
    mut generations: Vec<GenerationUsage>,
    max_generations: usize,
    max_bytes: u64,
) -> Result<EvictionPlan, QuotaError> {
    if generations.len() > MAX_CACHE_GENERATIONS {
        return Err(QuotaError::TooManyGenerations);
    }
    let current_bytes = generations
        .iter()
        .filter(|value| value.is_current)
        .fold(0_u64, |total, value| total.saturating_add(value.bytes));
    if current_bytes > max_bytes {
        return Err(QuotaError::CurrentAloneExceedsQuota);
    }
    generations.sort_by_key(|value| value.created_sequence);
    let mut retained_count = generations.len();
    let mut retained_bytes = generations
        .iter()
        .fold(0_u64, |total, value| total.saturating_add(value.bytes));
    let mut evictions = Vec::new();
    for generation in generations {
        if retained_count <= max_generations && retained_bytes <= max_bytes {
            break;
        }
        if generation.is_current {
            continue;
        }
        retained_count = retained_count.saturating_sub(1);
        retained_bytes = retained_bytes.saturating_sub(generation.bytes);
        evictions.push(generation.id);
    }
    EvictionPlan::try_from_vec(evictions).map_err(|_| QuotaError::TooManyGenerations)
}
