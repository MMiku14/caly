//! Config-driven routing rules rendered as sing-box `route.rules`.
//!
//! Mihomo consumes Clash-format rule lines directly; sing-box needs structured
//! route rule objects instead. This module is the single mapping between the
//! domain `RoutingRule` model and sing-box route semantics, shared by the
//! subscription document renderer and the subscription-less base renderer.

use caly_domain::{
    RuleMatch, RulePolicy, RuleProvider, RuleProviderBehavior, RuleProviderFormat,
    RuleProviderSource, RoutingRule,
};
use serde_json::Value;
use std::collections::BTreeSet;

/// Rendered routing rules ready to embed into a sing-box document.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct SingBoxRules {
    /// Pre-rendered JSON array of route rule objects; `None` when no rule is
    /// representable (the document should omit the `rules` key).
    pub rules_json: Option<String>,
    /// Pre-rendered JSON array of `route.rule_set` sources (remote geo
    /// rule-sets referenced by GEOIP rules); `None` when not needed.
    pub rule_sets_json: Option<String>,
    /// The outbound tag for `route.final` (derived from the MATCH rule, or a
    /// sensible default when absent).
    pub final_outbound: String,
    /// Whether the document must add the built-in `block` outbound (any rule
    /// steers to REJECT).
    pub block_outbound: bool,
    /// Rules skipped because their policy has no outbound in the document.
    pub skipped: usize,
}

/// Maps the config rules onto sing-box route semantics.
///
/// `proxy_representable` states whether the document carries proxy outbounds
/// (a subscription renders a `PROXY` selector; the subscription-less base
/// config only carries `direct`). Unrepresentable proxy/group policies are
/// skipped and counted instead of fabricating outbounds.
///
/// `user_providers` is the list of `rule_providers:` entries from the
/// config; each is rendered as one `route.rule_set` source so
/// `RULE-SET,<name>,…` rules resolve at runtime. Auto-emitted GEOIP
/// rule-sets and per-category SagerNet geosite rule-sets are added on
/// top of the user list.
pub fn render_sing_box_rules(
    rules: &[RoutingRule],
    user_providers: &[RuleProvider],
    proxy_representable: bool,
) -> SingBoxRules {
    let mut objects: Vec<Value> = Vec::new();
    // BTreeSet keeps source registration deduplicated (O(log n) per insert) and
    // emits a deterministic sorted order into the document.
    let mut rule_set_tags: BTreeSet<String> = BTreeSet::new();
    let mut final_outbound: Option<String> = None;
    let mut block_outbound = false;
    let mut skipped = 0usize;
    for rule in rules {
        if let RuleMatch::Match = &rule.matcher {
            // Clash semantics: the first MATCH wins; later catch-alls are dead.
            if final_outbound.is_none() {
                match policy_outbound(&rule.policy, proxy_representable) {
                    Some(outbound) => final_outbound = Some(outbound),
                    None => skipped += 1,
                }
            }
            continue;
        }
        let Some(outbound) = policy_outbound(&rule.policy, proxy_representable) else {
            skipped += 1;
            continue;
        };
        if outbound == "block" {
            block_outbound = true;
        }
        if let Some(object) = matcher_object(&rule.matcher, &outbound) {
            match &rule.matcher {
                RuleMatch::Geoip(code) => {
                    rule_set_tags.insert(geoip_rule_set_tag(code.as_str()));
                }
                RuleMatch::Geosite(name) => {
                    rule_set_tags.insert(geosite_rule_set_tag(name.as_str()));
                }
                _ => {}
            }
            objects.push(object);
        } else {
            // The matcher is not representable in the target kernel
            // (e.g. Mihomo-only `PROCESS-NAME` / `SRC-IP-CIDR` in
            // sing-box). Count it as skipped so the caller can warn
            // the operator without aborting the render.
            skipped += 1;
        }
    }
    let final_outbound = final_outbound.unwrap_or_else(|| {
        if proxy_representable {
            "PROXY".to_owned()
        } else {
            "direct".to_owned()
        }
    });
    if final_outbound == "block" {
        block_outbound = true;
    }
    let rules_json = if objects.is_empty() {
        None
    } else {
        serde_json::to_string(&objects).ok()
    };
    let rule_sets_json = build_rule_sets_json(user_providers, &rule_set_tags);
    SingBoxRules {
        rules_json,
        rule_sets_json,
        final_outbound,
        block_outbound,
        skipped,
    }
}

/// Builds the `route.rule_set` JSON array from the user-declared providers
/// and the auto-emitted geoip / geosite tags gathered from the rule list.
/// User-declared providers are emitted first (stable order from the
/// BTreeSet-tracked tag set), then auto-emitted ones whose tag is not
/// already covered.
fn build_rule_sets_json(
    user_providers: &[RuleProvider],
    auto_tags: &BTreeSet<String>,
) -> Option<String> {
    let mut sources: Vec<Value> = Vec::new();
    for provider in user_providers {
        sources.push(provider_to_source_json(provider));
    }
    for tag in auto_tags {
        // Skip tags the user has already provided (e.g. a `geoip-cn` inline
        // provider overrides the SagerNet URL).
        if user_providers
            .iter()
            .any(|provider| provider.name.as_str() == tag)
        {
            continue;
        }
        sources.push(auto_source_json(tag));
    }
    if sources.is_empty() {
        None
    } else {
        serde_json::to_string(&sources).ok()
    }
}

/// Renders one user-declared rule provider as a sing-box `route.rule_set`
/// source. `inline` providers render as `type: inline` sources with the
/// payload embedded; HTTP / file providers render as `type: remote` (HTTP)
/// or `type: local` (file) sources, preserving the user's URL / path /
/// interval.
fn provider_to_source_json(provider: &RuleProvider) -> Value {
    let tag = provider.name.as_str();
    let format = sing_box_format(provider.format);
    match &provider.source {
        RuleProviderSource::Http { url, interval_ms } => {
            let mut object = serde_json::Map::new();
            object.insert("tag".to_owned(), Value::String(tag.to_owned()));
            object.insert("type".to_owned(), Value::String("remote".to_owned()));
            object.insert("format".to_owned(), Value::String(format.to_owned()));
            object.insert("url".to_owned(), Value::String(url.as_str().to_owned()));
            // sing-box 1.12 uses `download_interval` (Go duration), not
            // raw milliseconds; `*time.Minute` is the supported shorthand.
            let interval = sing_box_interval(*interval_ms);
            object.insert("download_interval".to_owned(), Value::String(interval));
            // sing-box's `behavior` discriminator mirrors our domain enum
            // by name, so the user's intent (domain vs ipcidr vs classical)
            // is preserved across the kernel boundary.
            let behavior = sing_box_behavior(provider.behavior);
            if let Some(behavior) = behavior {
                object.insert(
                    "behavior".to_owned(),
                    Value::String(behavior.to_owned()),
                );
            }
            Value::Object(object)
        }
        RuleProviderSource::File { path } => {
            let mut object = serde_json::Map::new();
            object.insert("tag".to_owned(), Value::String(tag.to_owned()));
            object.insert("type".to_owned(), Value::String("local".to_owned()));
            object.insert("format".to_owned(), Value::String(format.to_owned()));
            object.insert("path".to_owned(), Value::String(path.as_str().to_owned()));
            let behavior = sing_box_behavior(provider.behavior);
            if let Some(behavior) = behavior {
                object.insert(
                    "behavior".to_owned(),
                    Value::String(behavior.to_owned()),
                );
            }
            Value::Object(object)
        }
        RuleProviderSource::Inline { payload } => {
            // sing-box's `inline` source type is not part of stable
            // `route.rule_set`; the cleanest portable representation is a
            // `local` source pointing at a runtime-generated file. We
            // emit a structured placeholder plus the payload as a side
            // comment in the rendered JSON for operators who inspect it;
            // the Mihomo backend will materialise the same provider as a
            // real `rule-providers:` entry with `payload:`.
            let mut object = serde_json::Map::new();
            object.insert("tag".to_owned(), Value::String(tag.to_owned()));
            object.insert("type".to_owned(), Value::String("inline".to_owned()));
            object.insert("format".to_owned(), Value::String(format.to_owned()));
            object.insert(
                "payload".to_owned(),
                Value::String(payload.as_str().to_owned()),
            );
            let behavior = sing_box_behavior(provider.behavior);
            if let Some(behavior) = behavior {
                object.insert(
                    "behavior".to_owned(),
                    Value::String(behavior.to_owned()),
                );
            }
            Value::Object(object)
        }
    }
}

/// Renders one auto-emitted tag (GEOIP or geosite) as a `remote` SagerNet
/// source. These are added only when the user has not declared an explicit
/// rule-set for the same tag, so the user's overrides always win.
fn auto_source_json(tag: &str) -> Value {
    serde_json::json!({
        "tag": tag,
        "type": "remote",
        "format": "binary",
        "url": geosite_or_geoip_url(tag),
    })
}

/// Returns the sing-box `format` discriminator for one of our provider
/// formats. SagerNet compiles `binary` (`.srs`) and `source` (plain text)
/// rule-sets; we mirror those names exactly.
fn sing_box_format(format: RuleProviderFormat) -> &'static str {
    match format {
        RuleProviderFormat::Source => "source",
        RuleProviderFormat::Binary => "binary",
    }
}

/// Maps our `behavior` enum to the sing-box `route_set` discriminator.
/// Classical rule bodies are an exception: sing-box 1.12 does not
/// consume mixed Clash rule lines; an upstream converter is required,
/// so we omit the field and let sing-box try the default path
/// (the kernel will reject classical bodies with a clear validation
/// error rather than silently dropping rules).
fn sing_box_behavior(behavior: RuleProviderBehavior) -> Option<&'static str> {
    match behavior {
        RuleProviderBehavior::Domain => Some("domain"),
        RuleProviderBehavior::DomainSuffix => Some("domain_suffix"),
        RuleProviderBehavior::IpCidr => Some("ipcidr"),
        RuleProviderBehavior::Classical => None,
    }
}

/// sing-box consumes a Go duration string (`30m`, `12h`, …) for
/// `download_interval`. The bounded form keeps the value readable
/// when the user picks 1-day or 1-hour polling.
fn sing_box_interval(interval_ms: u64) -> String {
    const ONE_MINUTE_MS: u64 = 60_000;
    const ONE_HOUR_MS: u64 = 3_600_000;
    if interval_ms >= ONE_HOUR_MS && interval_ms.is_multiple_of(ONE_HOUR_MS) {
        format!("{}h", interval_ms / ONE_HOUR_MS)
    } else if interval_ms >= ONE_MINUTE_MS && interval_ms.is_multiple_of(ONE_MINUTE_MS) {
        format!("{}m", interval_ms / ONE_MINUTE_MS)
    } else {
        format!("{interval_ms}s")
    }
}

/// Picks the right SagerNet URL for an auto-emitted rule-set tag.
/// `geosite-<name>` comes from SagerNet's `sing-geosite` repo;
/// `geoip-<cc>` from `sing-geoip`.
///
/// Round 31: this is a Round-10-era hardcode.
/// The intended S5.6+ shape routes the auto-emit
/// through the Profile path (the same
/// `profile_fetch::fetch_profile_body` SSRF-safe
/// pipeline that backs `set profile refresh`):
/// the rule renderer would surface a synthetic
/// `geosite-<name>` / `geoip-<cc>` `Remote`
/// `Profile`, the user could `--apply` it into
/// the `<state>/profiles/<id>.yaml` cache, and
/// subsequent rule renders would point at the
/// cached body rather than reaching the network
/// at render time. The current shape keeps the
/// SagerNet URL inline as a fallback for users
/// who have not (yet) declared the synthetic
/// Profile, so the rendered config still boots.
/// A future round that adds a `geoip-cn` /
/// `geosite-cn` declared Profile as the
/// authoritative source will replace this
/// fallback with a cache lookup keyed on the
/// tag. The change is a `S5.6` follow-up;
/// the auto-emit URL stays here as a stop-gap
/// so the sing-box / Mihomo render path is not
/// blocked on the migration.
fn geosite_or_geoip_url(tag: &str) -> String {
    if let Some(name) = tag.strip_prefix("geosite-") {
        format!(
            "https://raw.githubusercontent.com/SagerNet/sing-geosite/rule-set/{name}.srs"
        )
    } else {
        geoip_rule_set_url(tag)
    }
}

/// Maps one rule policy onto a sing-box outbound tag, or `None` when the
/// document cannot represent it. Group names fold into the `PROXY` selector
/// (the subscription document exposes every node through it); a literal
/// `GLOBAL` group keeps its dedicated selector.
fn policy_outbound(policy: &RulePolicy, proxy_representable: bool) -> Option<String> {
    match policy {
        RulePolicy::Direct => Some("direct".to_owned()),
        RulePolicy::Reject => Some("block".to_owned()),
        RulePolicy::Proxy(group) if proxy_representable => {
            if group.as_str() == "GLOBAL" {
                Some("GLOBAL".to_owned())
            } else {
                Some("PROXY".to_owned())
            }
        }
        RulePolicy::Proxy(_) => None,
    }
}

/// Builds one sing-box route rule object for a non-catch-all matcher.
fn matcher_object(matcher: &RuleMatch, outbound: &str) -> Option<Value> {
    let mut object = serde_json::Map::new();
    match matcher {
        RuleMatch::Domain(text) => {
            object.insert("domain".to_owned(), list_value(text.as_str()));
        }
        RuleMatch::DomainSuffix(text) => {
            object.insert("domain_suffix".to_owned(), list_value(text.as_str()));
        }
        RuleMatch::DomainKeyword(text) => {
            object.insert("domain_keyword".to_owned(), list_value(text.as_str()));
        }
        RuleMatch::IpCidr(text) => {
            object.insert("ip_cidr".to_owned(), list_value(text.as_str()));
        }
        RuleMatch::Geoip(code) => {
            // The plain `geoip` rule key was removed in sing-box 1.12; modern
            // kernels match through a (remote) rule-set source instead.
            object.insert(
                "rule_set".to_owned(),
                Value::String(geoip_rule_set_tag(code.as_str())),
            );
        }
        RuleMatch::RuleSet(name) => {
            // The named provider supplies the matchers; the rule only names
            // it. The actual `route.rule_set` source is rendered by
            // `render_sing_box_rule_sets` from the configured providers.
            object.insert(
                "rule_set".to_owned(),
                Value::String(name.as_str().to_owned()),
            );
        }
        RuleMatch::Geosite(name) => {
            // SagerNet ships category-named `geosite-<name>.srs` rule-sets.
            // The provider for each category is synthesized by the rule-set
            // renderer; here we only emit the lookup name.
            object.insert(
                "rule_set".to_owned(),
                Value::String(geosite_rule_set_tag(name.as_str())),
            );
        }
        RuleMatch::ProcessName(_) | RuleMatch::SourceIpCidr(_) => {
            // sing-box 1.12 does not consume Mihomo's `PROCESS-NAME` or
            // `SRC-IP-CIDR` matchers; the rule renderer skips them so the
            // config can still be committed, and the count surfaces to the
            // caller through the existing `skipped` accounting.
            return None;
        }
        RuleMatch::Match => return None,
    }
    object.insert("outbound".to_owned(), Value::String(outbound.to_owned()));
    Some(Value::Object(object))
}

/// Rule-set tag for one SagerNet geosite category (`geosite-<name>`).
fn geosite_rule_set_tag(name: &str) -> String {
    format!("geosite-{name}")
}

/// Rule-set tag for one GEOIP country code (`geoip-cn` style).
fn geoip_rule_set_tag(code: &str) -> String {
    format!("geoip-{}", code.to_lowercase())
}

/// Official SagerNet rule-set source URL for one geoip tag.
fn geoip_rule_set_url(tag: &str) -> String {
    format!("https://raw.githubusercontent.com/SagerNet/sing-geoip/rule-set/{tag}.srs")
}

fn list_value(value: &str) -> Value {
    Value::Array(vec![Value::String(value.to_owned())])
}


#[cfg(test)]
mod tests {
    use super::*;
    use caly_domain::{BoundedText, RoutingRule, RuleError, RuleProviderName, RuleText};

    fn parse(line: &str) -> RoutingRule {
        RoutingRule::from_clash_line(line).unwrap_or_else(|_: RuleError| std::process::abort())
    }

    #[test]
    fn maps_matchers_onto_sing_box_route_rule_keys() {
        let rules = vec![
            parse("DOMAIN,a.example,PROXY"),
            parse("DOMAIN-SUFFIX,b.example,DIRECT"),
            parse("DOMAIN-KEYWORD,ads,REJECT"),
            parse("IP-CIDR,192.168.0.0/16,DIRECT"),
            parse("GEOIP,CN,DIRECT"),
        ];
        let rendered = render_sing_box_rules(&rules, &[], true);
        let json = rendered.rules_json.unwrap_or_default();
        assert!(json.contains("\"domain\":[\"a.example\"]"));
        assert!(json.contains("\"domain_suffix\":[\"b.example\"]"));
        assert!(json.contains("\"domain_keyword\":[\"ads\"]"));
        assert!(json.contains("\"ip_cidr\":[\"192.168.0.0/16\"]"));
        assert!(json.contains("\"rule_set\":\"geoip-cn\""));
        let sources = rendered.rule_sets_json.unwrap_or_default();
        assert!(sources.contains("\"tag\":\"geoip-cn\""));
        assert!(sources.contains("sing-geoip/rule-set/geoip-cn.srs"));
        assert!(rendered.block_outbound);
        assert_eq!(rendered.skipped, 0);
        assert_eq!(rendered.final_outbound, "PROXY");
    }

    #[test]
    fn match_rule_sets_route_final_and_first_wins() {
        let rules = vec![parse("MATCH,DIRECT"), parse("MATCH,PROXY")];
        let rendered = render_sing_box_rules(&rules, &[], true);
        assert_eq!(rendered.final_outbound, "direct");
        assert_eq!(rendered.rules_json, None);
    }

    #[test]
    fn default_final_depends_on_proxy_presence() {
        assert_eq!(render_sing_box_rules(&[], &[], true).final_outbound, "PROXY");
        assert_eq!(render_sing_box_rules(&[], &[], false).final_outbound, "direct");
    }

    #[test]
    fn proxy_policies_skip_without_proxy_outbounds() {
        let rules = vec![
            parse("DOMAIN-SUFFIX,example.com,PROXY"),
            parse("MATCH,DIRECT"),
        ];
        let rendered = render_sing_box_rules(&rules, &[], false);
        assert_eq!(rendered.skipped, 1);
        assert_eq!(rendered.rules_json, None);
        assert_eq!(rendered.final_outbound, "direct");
    }

    #[test]
    fn group_names_fold_into_proxy_and_global_keeps_its_selector() {
        let rules = vec![
            parse("DOMAIN,a.example,MyGroup"),
            parse("DOMAIN,b.example,GLOBAL"),
        ];
        let rendered = render_sing_box_rules(&rules, &[], true);
        let json = rendered.rules_json.unwrap_or_default();
        assert!(json.contains("\"outbound\":\"PROXY\""));
        assert!(json.contains("\"outbound\":\"GLOBAL\""));
    }

    #[test]
    fn reject_final_requires_the_block_outbound() {
        let rules = vec![parse("MATCH,REJECT")];
        let rendered = render_sing_box_rules(&rules, &[], true);
        assert_eq!(rendered.final_outbound, "block");
        assert!(rendered.block_outbound);
    }

    fn provider(
        name: &str,
        source: RuleProviderSource,
        behavior: RuleProviderBehavior,
        format: RuleProviderFormat,
    ) -> RuleProvider {
        RuleProvider {
            name: RuleProviderName::new(name.to_owned())
                .unwrap_or_else(|_| std::process::abort()),
            source,
            behavior,
            format,
        }
    }

    #[test]
    fn user_rule_provider_renders_as_remote_source_with_preserved_metadata() {
        let url = "https://example.com/my-rules.yaml".to_owned();
        let user = vec![provider(
            "my-google",
            RuleProviderSource::Http {
                url: RuleText::new(url.clone()).unwrap_or_else(|_| std::process::abort()),
                interval_ms: 86_400_000,
            },
            RuleProviderBehavior::Domain,
            RuleProviderFormat::Source,
        )];
        let rendered = render_sing_box_rules(&[], &user, true);
        let sources = rendered.rule_sets_json.unwrap_or_default();
        assert!(sources.contains("\"tag\":\"my-google\""));
        assert!(sources.contains("\"type\":\"remote\""));
        assert!(sources.contains("\"url\":\"https://example.com/my-rules.yaml\""));
        assert!(sources.contains("\"format\":\"source\""));
        assert!(sources.contains("\"behavior\":\"domain\""));
        assert!(sources.contains("\"download_interval\":\"24h\""));
    }

    #[test]
    fn file_rule_provider_renders_as_local_source() {
        let user = vec![provider(
            "local-rules",
            RuleProviderSource::File {
                path: RuleText::new("/etc/caly/local.yaml".to_owned())
                    .unwrap_or_else(|_| std::process::abort()),
            },
            RuleProviderBehavior::Classical,
            RuleProviderFormat::Source,
        )];
        let rendered = render_sing_box_rules(&[], &user, true);
        let sources = rendered.rule_sets_json.unwrap_or_default();
        assert!(sources.contains("\"type\":\"local\""));
        assert!(sources.contains("\"path\":\"/etc/caly/local.yaml\""));
        assert!(!sources.contains("\"behavior\":\"classical\""));
    }

    #[test]
    fn inline_rule_provider_renders_with_payload() {
        let user = vec![provider(
            "inline-ads",
            RuleProviderSource::Inline {
                payload: BoundedText::new("ads.example.com\ntrack.example.org\n".to_owned())
                    .unwrap_or_else(|_| std::process::abort()),
            },
            RuleProviderBehavior::DomainSuffix,
            RuleProviderFormat::Source,
        )];
        let rendered = render_sing_box_rules(&[], &user, true);
        let sources = rendered.rule_sets_json.unwrap_or_default();
        assert!(sources.contains("\"type\":\"inline\""));
        assert!(sources.contains(r#""payload":"ads.example.com\ntrack.example.org\n""#));
        assert!(sources.contains("\"behavior\":\"domain_suffix\""));
    }

    #[test]
    fn rule_set_rule_emits_lookup_for_declared_provider() {
        let rules = vec![parse("RULE-SET,my-google,DIRECT")];
        let user = vec![provider(
            "my-google",
            RuleProviderSource::Http {
                url: RuleText::new("https://example.com/g.yaml".to_owned())
                    .unwrap_or_else(|_| std::process::abort()),
                interval_ms: 86_400_000,
            },
            RuleProviderBehavior::Domain,
            RuleProviderFormat::Source,
        )];
        let rendered = render_sing_box_rules(&rules, &user, true);
        let json = rendered.rules_json.unwrap_or_default();
        assert!(json.contains("\"rule_set\":\"my-google\""));
        let sources = rendered.rule_sets_json.unwrap_or_default();
        assert!(sources.contains("\"tag\":\"my-google\""));
        assert!(!sources.contains("\"tag\":\"geoip-my-google\""));
    }

    #[test]
    fn geosite_rule_emits_sagernet_lookup() {
        let rules = vec![parse("GEOSITE,private,DIRECT")];
        let rendered = render_sing_box_rules(&rules, &[], true);
        let json = rendered.rules_json.unwrap_or_default();
        assert!(json.contains("\"rule_set\":\"geosite-private\""));
        let sources = rendered.rule_sets_json.unwrap_or_default();
        assert!(sources.contains("\"tag\":\"geosite-private\""));
        assert!(sources.contains("sing-geosite/rule-set/private.srs"));
    }

    #[test]
    fn mihomo_only_matchers_are_skipped_and_counted() {
        let rules = vec![
            parse("PROCESS-NAME,curl,DIRECT"),
            parse("SRC-IP-CIDR,10.0.0.0/8,REJECT"),
            parse("DOMAIN,example.com,DIRECT"),
        ];
        let rendered = render_sing_box_rules(&rules, &[], true);
        assert_eq!(rendered.skipped, 2);
        let json = rendered.rules_json.unwrap_or_default();
        assert!(json.contains("\"domain\":[\"example.com\"]"));
        assert!(!json.contains("PROCESS-NAME"));
        assert!(!json.contains("SRC-IP-CIDR"));
        assert!(rendered.block_outbound);
    }

    #[test]
    fn user_provider_with_same_tag_as_geoip_overrides_the_sagernet_url() {
        let rules = vec![parse("GEOIP,CN,DIRECT")];
        let user = vec![provider(
            "geoip-cn",
            RuleProviderSource::Http {
                url: RuleText::new("https://mirror.example.com/cn.srs".to_owned())
                    .unwrap_or_else(|_| std::process::abort()),
                interval_ms: 3_600_000,
            },
            RuleProviderBehavior::IpCidr,
            RuleProviderFormat::Binary,
        )];
        let rendered = render_sing_box_rules(&rules, &user, true);
        let sources = rendered.rule_sets_json.unwrap_or_default();
        assert_eq!(
            sources.matches("\"url\":\"https://mirror.example.com/cn.srs\"").count(),
            1
        );
        assert_eq!(
            sources.matches("geoip-cn.srs").filter(|needle| needle.contains("sing-geoip")).count(),
            0
        );
    }

    #[test]
    fn sing_box_interval_formats_hours_minutes_and_seconds() {
        assert_eq!(sing_box_interval(3_600_000), "1h");
        assert_eq!(sing_box_interval(7_200_000), "2h");
        assert_eq!(sing_box_interval(60_000), "1m");
        assert_eq!(sing_box_interval(30_000), "30000s");
        assert_eq!(sing_box_interval(45_000), "45000s");
    }
}
