//! Cross-field validation of a parsed `AppConfig`.
//!
//! Kept in a sibling file so `schema/mod.rs` stays within the project's
//! file-size limit. Every check here turns a parseable-but-unusable
//! configuration into an explicit boot failure.

use std::net::SocketAddr;

use super::dns::validated_dns_settings;
use caly_domain::BoundedText;

use super::{AppConfig, ConfigError};
use super::proxy_group::ProxyGroupTypeConfig;
use super::settings::RuleProviderSourceConfig;

/// Validates all cross-field bootstrap invariants of a parsed configuration.
pub fn validate(config: &AppConfig) -> Result<(), ConfigError> {
    if config.schema_version != 1 {
        return Err(ConfigError::UnsupportedSchemaVersion(config.schema_version));
    }
    let listen: SocketAddr = config
        .daemon
        .listen
        .parse()
        .map_err(|_| ConfigError::InvalidListenAddress)?;
    if !listen.ip().is_loopback() && !config.daemon.tls_enabled {
        return Err(ConfigError::RemoteListenRequiresTls);
    }
    if !listen.ip().is_loopback() && config.daemon.auth_token.is_none() {
        return Err(ConfigError::RemoteListenRequiresAuth);
    }
    if !(576..=9_000).contains(&config.tun.mtu) {
        return Err(ConfigError::InvalidTunMtu);
    }
    for (core, address) in [
        ("mihomo", &config.controllers.mihomo),
        ("sing-box", &config.controllers.sing_box),
    ] {
        if address.parse::<SocketAddr>().is_err() {
            return Err(ConfigError::InvalidControllerAddress {
                core: core.to_owned(),
                address: address.clone(),
            });
        }
    }
    if !matches!(
        config.log.level.as_str(),
        "error" | "warn" | "info" | "debug" | "trace"
    ) {
        return Err(ConfigError::InvalidLogLevel);
    }
    if config.telemetry.interval_ms < 100 {
        return Err(ConfigError::InvalidTelemetryInterval);
    }
    if let Some(url) = &config.subscriptions.url {
        let parsed = url::Url::parse(url).map_err(|_| ConfigError::InvalidSubscriptionUrl)?;
        if !matches!(parsed.scheme(), "http" | "https") || parsed.host_str().is_none() {
            return Err(ConfigError::InvalidSubscriptionUrl);
        }
    }
    for source in &config.subscriptions.sources {
        let parsed =
            url::Url::parse(&source.url).map_err(|_| ConfigError::InvalidSubscriptionUrl)?;
        if !matches!(parsed.scheme(), "http" | "https") || parsed.host_str().is_none() {
            return Err(ConfigError::InvalidSubscriptionUrl);
        }
    }
    validate_kernel(config)?;
    validate_dns(config)?;
    validate_dns_filters(config)?;
    validate_fetch_policy(config)?;
    validate_system_proxy(config)?;
    validate_rules(config)?;
    validate_rule_providers(config)?;
    validate_rule_provider_references(config)?;
    validate_profiles(config)?;
    validate_proxy_groups(config)?;
    validate_sniffer(config)?;
    if !is_valid_tun_escalation(&config.tun.escalation) {
        return Err(ConfigError::InvalidTunEscalation);
    }
    Ok(())
}

/// Validates every routing rule through the domain parser so a bad rule fails
/// at config load instead of at render time. IP-CIDR values get full address
/// validation from the infrastructure matcher (the domain only checks the
/// `address/prefix` shape).
fn validate_rules(config: &AppConfig) -> Result<(), ConfigError> {
    if config.rules.len() > caly_domain::MAX_RULES {
        return Err(ConfigError::InvalidRule {
            index: config.rules.len(),
            reason: format!("more than {} rules", caly_domain::MAX_RULES),
        });
    }
    for (index, line) in config.rules.iter().enumerate() {
        let rule = caly_domain::RoutingRule::from_clash_line(line).map_err(|error| {
            ConfigError::InvalidRule {
                index,
                reason: error.to_string(),
            }
        })?;
        if let caly_domain::RuleMatch::IpCidr(cidr) = &rule.matcher
            && !crate::rule_match::is_valid_cidr(cidr.as_str())
        {
            return Err(ConfigError::InvalidRule {
                index,
                reason: format!("`{}` is not a valid CIDR block", cidr.as_str()),
            });
        }
    }
    Ok(())
}

/// Validates every `rule_providers:` entry before render. Names must be
/// unique; HTTP URLs must be public and have a sane polling interval; file
/// paths and inline payloads must be non-empty.
fn validate_rule_providers(config: &AppConfig) -> Result<(), ConfigError> {
    if config.rule_providers.len() > caly_domain::MAX_RULE_PROVIDERS {
        return Err(ConfigError::InvalidRule {
            index: config.rule_providers.len(),
            reason: format!("more than {} rule providers", caly_domain::MAX_RULE_PROVIDERS),
        });
    }
    let mut seen_names: std::collections::HashSet<String> = std::collections::HashSet::new();
    for provider in &config.rule_providers {
        if provider.name.trim().is_empty() {
            return Err(ConfigError::InvalidRule {
                index: 0,
                reason: "rule provider name must not be empty".to_owned(),
            });
        }
        if !seen_names.insert(provider.name.clone()) {
            return Err(ConfigError::DuplicateRuleProvider {
                name: provider.name.clone(),
            });
        }
        match &provider.kind {
            RuleProviderSourceConfig::Http { url, interval_ms } => {
                let parsed = url::Url::parse(url).map_err(|_| {
                    ConfigError::InvalidRuleProviderUrl {
                        name: provider.name.clone(),
                        url: url.clone(),
                    }
                })?;
                if !matches!(parsed.scheme(), "http" | "https") || parsed.host_str().is_none() {
                    return Err(ConfigError::InvalidRuleProviderUrl {
                        name: provider.name.clone(),
                        url: url.clone(),
                    });
                }
                if *interval_ms < 60_000 {
                    return Err(ConfigError::InvalidRuleProviderInterval {
                        name: provider.name.clone(),
                        interval_ms: *interval_ms,
                    });
                }
            }
            RuleProviderSourceConfig::File { path } => {
                if path.trim().is_empty() {
                    return Err(ConfigError::EmptyRuleProviderPath {
                        name: provider.name.clone(),
                    });
                }
            }
            RuleProviderSourceConfig::Inline { payload } => {
                if payload.trim().is_empty() {
                    return Err(ConfigError::EmptyRuleProviderPayload {
                        name: provider.name.clone(),
                    });
                }
            }
        }
    }
    Ok(())
}

/// Validates every `profiles:` entry. Ids must be unique and
/// path-safe; `Remote` URLs must be public http(s); merge parts
/// must reference declared profiles and contain no cycles.
fn validate_profiles(config: &AppConfig) -> Result<(), ConfigError> {
    use caly_domain::MAX_PROFILES;
    if config.profiles.len() > MAX_PROFILES {
        return Err(ConfigError::InvalidRule {
            index: config.profiles.len(),
            reason: format!("more than {MAX_PROFILES} profiles"),
        });
    }
    let declared: std::collections::HashSet<String> = validate_profile_entries(config)?;
    validate_profile_merge_cycles(config, &declared)?;
    Ok(())
}

/// Per-entry structural checks (unique ids, path-safety, valid
/// `Local` / `Remote` / `Merge` shapes). Returns the set of
/// declared ids so [`validate_profile_merge_cycles`] can re-use
/// it without re-walking the list.
fn validate_profile_entries(
    config: &AppConfig,
) -> Result<std::collections::HashSet<String>, ConfigError> {
    use caly_domain::is_path_safe_component;
    let mut seen_ids: std::collections::HashSet<String> = std::collections::HashSet::new();
    let mut declared: std::collections::HashSet<String> = std::collections::HashSet::new();
    for profile in &config.profiles {
        if !is_path_safe_component(&profile.id) {
            return Err(ConfigError::Profile(
                caly_domain::ProfileError::UnknownId {
                    id: profile.id.clone(),
                },
            ));
        }
        if !seen_ids.insert(profile.id.clone()) {
            return Err(ConfigError::Profile(
                caly_domain::ProfileError::DuplicateId {
                    id: profile.id.clone(),
                },
            ));
        }
        declared.insert(profile.id.clone());
        validate_profile_source(&profile.id, &profile.source)?;
    }
    Ok(declared)
}

/// Validates one `Profile.source` against its kind-specific
/// invariants. `Local` rejects empty paths, `..` segments, and
/// absolute paths; `Remote` rejects non-http(s) URLs and a
/// zero `interval_minutes`; `Merge` rejects non-path-safe parts.
fn validate_profile_source(
    id: &str,
    source: &super::ProfileSourceConfig,
) -> Result<(), ConfigError> {
    use super::ProfileSourceConfig;
    use caly_domain::{ProfileError, is_path_safe_component};
    match source {
        ProfileSourceConfig::Local { path } => {
            if path.trim().is_empty() {
                return Err(ConfigError::InvalidRule {
                    index: 0,
                    reason: format!("profile `{id}` local path must not be empty"),
                });
            }
            // The local path must not contain a `..` segment
            // (path-traversal) and must not be an absolute path
            // that points outside the configured root (no leading
            // `/` in the loader's view of `<config>/profiles/`,
            // so absolute paths are rejected at the schema level
            // and resolved relative to the config root at load
            // time).
            if path.contains("..") || path.starts_with('/') {
                return Err(ConfigError::Profile(ProfileError::LocalPathEscape {
                    id: id.to_owned(),
                    path: path.clone(),
                }));
            }
            Ok(())
        }
        ProfileSourceConfig::Remote {
            url,
            interval_minutes,
        } => {
            let parsed = url::Url::parse(url).map_err(|_| ConfigError::InvalidRule {
                index: 0,
                reason: format!("profile `{id}` url `{url}` is not parseable"),
            })?;
            if !matches!(parsed.scheme(), "http" | "https") || parsed.host_str().is_none() {
                return Err(ConfigError::InvalidRule {
                    index: 0,
                    reason: format!(
                        "profile `{id}` url `{url}` must be a public http(s) URL"
                    ),
                });
            }
            if *interval_minutes == 0 {
                return Err(ConfigError::Profile(ProfileError::InvalidInterval {
                    id: id.to_owned(),
                }));
            }
            Ok(())
        }
        ProfileSourceConfig::Merge { parts } => {
            for part in parts {
                if !is_path_safe_component(part) {
                    return Err(ConfigError::Profile(ProfileError::UnknownId {
                        id: part.clone(),
                    }));
                }
            }
            Ok(())
        }
    }
}

/// Depth-first cycle detection across declared `Merge`
/// profiles. The first cycle encountered is reported with the
/// offending id; the rest of the declared set is left
/// untouched (the schema validator never aborts on the first
/// error when subsequent checks can still report a distinct
/// failure).
fn validate_profile_merge_cycles(
    config: &AppConfig,
    declared: &std::collections::HashSet<String>,
) -> Result<(), ConfigError> {
    use super::ProfileSourceConfig;
    for profile in &config.profiles {
        if let ProfileSourceConfig::Merge { parts: _ } = &profile.source {
            let mut visited: std::collections::HashSet<String> = std::collections::HashSet::new();
            let parts_for = |id: &str| -> Option<Vec<String>> {
                config
                    .profiles
                    .iter()
                    .find(|candidate| candidate.id == id)
                    .and_then(|candidate| match &candidate.source {
                        ProfileSourceConfig::Merge { parts } => Some(parts.clone()),
                        _ => None,
                    })
            };
            walk_merge(&profile.id, &parts_for, declared, &mut visited)?;
        }
    }
    Ok(())
}

fn walk_merge(
    id: &str,
    parts_for: &dyn Fn(&str) -> Option<Vec<String>>,
    declared: &std::collections::HashSet<String>,
    visited: &mut std::collections::HashSet<String>,
) -> Result<(), caly_domain::ProfileError> {
    if !visited.insert(id.to_owned()) {
        return Err(caly_domain::ProfileError::Cycle { id: id.to_owned() });
    }
    if let Some(parts) = parts_for(id) {
        for part in parts {
            if !declared.contains(&part) {
                return Err(caly_domain::ProfileError::UnknownId { id: part });
            }
            walk_merge(&part, parts_for, declared, visited)?;
        }
    }
    Ok(())
}

/// Validates that every `RULE-SET,<name>,…` rule references a known
/// provider. Auto-emitted GEOIP rule-sets (`geoip-<cc>`) are exempt —
/// the rule renderer inserts them on demand.
fn validate_rule_provider_references(config: &AppConfig) -> Result<(), ConfigError> {
    let declared: std::collections::HashSet<&str> = config
        .rule_providers
        .iter()
        .map(|p| p.name.as_str())
        .collect();
    for (index, line) in config.rules.iter().enumerate() {
        let rule = caly_domain::RoutingRule::from_clash_line(line).map_err(|error| {
            ConfigError::InvalidRule {
                index,
                reason: error.to_string(),
            }
        })?;
        if let caly_domain::RuleMatch::RuleSet(name) = &rule.matcher
            && !declared.contains(name.as_str())
        {
            return Err(ConfigError::UnknownRuleProvider {
                name: name.as_str().to_owned(),
                rule_index: index,
            });
        }
    }
    Ok(())
}

/// Validates every sniffer port spec so a bad spec fails at config load
/// instead of at render time. Specs are `N` or `N-M` within 1..=65535.
fn validate_sniffer(config: &AppConfig) -> Result<(), ConfigError> {
    for spec in config.sniffer.all_port_specs() {
        if !super::kernel::SnifferConfig::is_valid_port_spec(spec) {
            return Err(ConfigError::InvalidSnifferPort {
                spec: spec.to_owned(),
            });
        }
    }
    Ok(())
}

fn validate_kernel(config: &AppConfig) -> Result<(), ConfigError> {
    if config.kernel.mixed_port == 0 {
        return Err(ConfigError::InvalidKernelPort);
    }
    if !super::kernel::KernelConfig::is_valid_log_level(&config.kernel.log_level) {
        return Err(ConfigError::InvalidKernelLogLevel);
    }
    let restart = &config.kernel.restart;
    if restart.initial_backoff_ms < 100 || restart.max_backoff_ms < restart.initial_backoff_ms {
        return Err(ConfigError::InvalidKernelRestart);
    }
    if config.kernel.transparent.enabled && config.kernel.transparent.port == 0 {
        return Err(ConfigError::InvalidTransparentPort);
    }
    if config.kernel.start_timeout_ms < 100 || config.kernel.stop_timeout_ms < 100 {
        return Err(ConfigError::InvalidKernelTimeout);
    }
    Ok(())
}

fn validate_dns(config: &AppConfig) -> Result<(), ConfigError> {
    validated_dns_settings(&config.dns)
        .map(|_| ())
        .map_err(ConfigError::InvalidDns)
}

/// Structural checks the domain builder cannot express: `dns.listen` must be
/// a socket address and every `fallback_filter.ipcidr` entry a valid CIDR
/// (full address arithmetic lives in the infrastructure matcher). The two
/// checks report distinct error variants so a user-facing diagnostic
/// names the failing field, not the umbrella "DNS filter" bucket.
fn validate_dns_filters(config: &AppConfig) -> Result<(), ConfigError> {
    let dns = &config.dns;
    if let Some(listen) = &dns.listen
        && listen.parse::<SocketAddr>().is_err()
    {
        return Err(ConfigError::InvalidDnsListen);
    }
    if dns
        .fallback_filter
        .ipcidr
        .iter()
        .any(|cidr| !crate::rule_match::is_valid_cidr(cidr))
    {
        return Err(ConfigError::InvalidDnsCidrFilter);
    }
    Ok(())
}

fn validate_fetch_policy(config: &AppConfig) -> Result<(), ConfigError> {
    let subscriptions = &config.subscriptions;
    let valid = subscriptions.connect_timeout_ms >= 100
        && subscriptions.request_timeout_ms >= 1_000
        && (1..=256).contains(&subscriptions.max_body_mb);
    if !valid {
        return Err(ConfigError::InvalidFetchPolicy);
    }
    Ok(())
}

/// Accepts exactly the escalation strategies the platform backend implements.
pub fn is_valid_tun_escalation(value: &str) -> bool {
    matches!(value, "auto" | "pkexec" | "sudo" | "none")
}

fn validate_system_proxy(config: &AppConfig) -> Result<(), ConfigError> {
    let system_proxy = &config.system_proxy;
    if system_proxy.host.trim().is_empty() {
        return Err(ConfigError::InvalidSystemProxy);
    }
    if system_proxy.port == Some(0) {
        return Err(ConfigError::InvalidSystemProxy);
    }
    Ok(())
}

pub(super) fn parse_message(message: String) -> ConfigError {
    match BoundedText::new(message) {
        Ok(message) => ConfigError::Parse {
            line: 0,
            column: 0,
            message,
        },
        Err(_) => ConfigError::ParseDetailsUnavailable,
    }
}

pub(super) fn parse_error(error: serde_json::Error) -> ConfigError {
    match BoundedText::new(error.to_string()) {
        Ok(message) => ConfigError::Parse {
            line: error.line(),
            column: error.column(),
            message,
        },
        Err(_) => ConfigError::ParseDetailsUnavailable,
    }
}

/// Validates every `proxy_groups:` entry before render.
///
/// The validator enforces five invariants the schema cannot
/// express through `serde` alone:
///
/// 1. **Budget.** Total groups are bounded by
///    [`caly_domain::MAX_PROXY_GROUPS`]; each group carries at
///    most [`caly_domain::MAX_PROXY_GROUP_MEMBERS`] members.
/// 2. **Path-safety.** Each `name` is a path-safe ASCII
///    identifier (the same rule as `ProfileId`); this is the
///    only way a group can be referenced from `RULE-SET,`
///    policies and from other groups' `members:` lists without
///    further normalisation.
/// 3. **Probe shape.** A probe-driven group (`url-test` /
///    `fallback` / `load-balance`) must have a `url_test:`
///    block; a non-probe group must not (the renderer would
///    silently drop the field, and the operator deserves to
///    know). A zero `interval_seconds` is rejected.
/// 4. **Member references.** A `Group` member that points at
///    an undeclared name is a hard failure — the live core
///    would refuse to start and the user would get a less
///    precise error.
/// 5. **Relay cycles.** `relay` groups form a graph; a
///    depth-first walk catches every cycle and reports the
///    first id that re-enters the visited set.
///
/// Domain errors are wrapped through [`From`] so the
/// `?` operator at the call site stays one line.
fn validate_proxy_groups(config: &AppConfig) -> Result<(), ConfigError> {
    use caly_domain::{
        ProxyGroupError, ProxyGroupMember, MAX_PROXY_GROUPS, MAX_PROXY_GROUP_MEMBERS,
        ProxyGroupType, is_path_safe_component,
    };
    use super::proxy_group::ProxyGroupMemberConfig;
    if config.proxy_groups.len() > MAX_PROXY_GROUPS {
        return Err(ProxyGroupError::TooManyGroups.into());
    }
    // Step 1: budget + path-safety + probe shape.
    let mut declared: std::collections::HashSet<String> = std::collections::HashSet::new();
    for group in &config.proxy_groups {
        if !is_path_safe_component(&group.name) {
            return Err(ProxyGroupError::UnknownMemberGroup {
                group: group.name.clone(),
                member: group.name.clone(),
            }
            .into());
        }
        if !declared.insert(group.name.clone()) {
            return Err(ProxyGroupError::DuplicateName {
                name: group.name.clone(),
            }
            .into());
        }
        if group.members.len() > MAX_PROXY_GROUP_MEMBERS {
            return Err(ProxyGroupError::TooManyMembers {
                name: group.name.clone(),
            }
            .into());
        }
        let needs_url = group.group_type.needs_url();
        if needs_url && group.url_test.is_none() {
            return Err(ProxyGroupError::MissingUrlTest {
                name: group.name.clone(),
            }
            .into());
        }
        if !needs_url && group.url_test.is_some() {
            return Err(ProxyGroupError::UnexpectedUrlTest {
                name: group.name.clone(),
            }
            .into());
        }
        if let Some(url_test) = &group.url_test
            && url_test.interval_seconds == 0
        {
            return Err(ProxyGroupError::InvalidInterval {
                name: group.name.clone(),
            }
            .into());
        }
    }
    // Step 2: member-reference resolution. A `Group` member
    // that points at an undeclared name is a hard failure
    // (the live core would refuse to start with a less
    // precise error). The schema validator runs **before**
    // the renderer, so a missing reference is the operator's
    // signal to add a `proxy_groups:` entry.
    for group in &config.proxy_groups {
        for member in &group.members {
            if let ProxyGroupMemberConfig::Group { name } = member
                && !declared.contains(name)
            {
                return Err(ProxyGroupError::UnknownMemberGroup {
                    group: group.name.clone(),
                    member: name.clone(),
                }
                .into());
            }
        }
    }
    // Step 3: relay cycles. A `relay` group forms a
    // directed graph where the outgoing edges are the
    // `Group` members. The walk is depth-first over the
    // set of declared `relay` groups; the first cycle
    // encountered is reported with the offending id so
    // the operator can break the loop in one place.
    for group in &config.proxy_groups {
        if group.group_type != ProxyGroupTypeConfig::Relay {
            continue;
        }
        let mut visited: std::collections::HashSet<String> = std::collections::HashSet::new();
        walk_relay(&group.name, &declared, &config.proxy_groups, &mut visited)?;
    }
    // Silence the unused-import warning when no relay
    // group is declared. The import is needed in the
    // match above; the `let _ =` here keeps clippy
    // happy and signals intent.
    let _ = ProxyGroupType::Select;
    let _ = ProxyGroupMember::Direct;
    Ok(())
}

/// DFS over the `relay` member graph. The `declared` set
/// is the full set of group names; the walk is scoped to
/// the `relay` members only. A revisit of the same id
/// during one walk is a cycle.
fn walk_relay(
    id: &str,
    declared: &std::collections::HashSet<String>,
    groups: &[super::ProxyGroupConfig],
    visited: &mut std::collections::HashSet<String>,
) -> Result<(), ConfigError> {
    if !visited.insert(id.to_owned()) {
        return Err(caly_domain::ProxyGroupError::RelayCycle {
            group: id.to_owned(),
        }
        .into());
    }
    let Some(group) = groups.iter().find(|candidate| candidate.name == id) else {
        return Ok(());
    };
    for member in &group.members {
        if let super::ProxyGroupMemberConfig::Group { name } = member
            && declared.contains(name.as_str())
            && let Some(next) = groups.iter().find(|candidate| candidate.name == *name)
            && next.group_type == ProxyGroupTypeConfig::Relay
        {
            walk_relay(name.as_str(), declared, groups, visited)?;
        }
    }
    Ok(())
}
