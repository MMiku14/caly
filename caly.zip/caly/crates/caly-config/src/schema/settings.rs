//! Additional runtime settings sections of the application configuration.
//!
//! Kept in a sibling file so `schema/mod.rs` stays within the project's
//! file-size limit. These sections let the config file drive controller
//! endpoints, log verbosity and telemetry cadence.
//!
//! This module is also the single source of truth for generated default
//! configs: `config generate` writes `render_default_base()` plus
//! `render_default_config_files()`, and `render_default_config()` composes the
//! same pieces into one documented file, so the layouts cannot drift apart.

use std::path::PathBuf;

use caly_domain::{RuleProviderBehavior, RuleProviderFormat, RuleProviderName, RuleText};
use serde::{Deserialize, Serialize};

use super::{DaemonConfig, TunConfig};

/// Per-core Clash-compatible controller endpoints.
///
/// Used by the daemon's command/telemetry control clients and the subscription
/// refresh path. The environment variables `CALY_MIHOMO_CONTROLLER` /
/// `CALY_SINGBOX_CONTROLLER` still override the config values.
#[derive(Clone, Debug, Deserialize, Eq, PartialEq, Serialize)]
#[serde(default, deny_unknown_fields)]
pub struct ControllersConfig {
    /// Mihomo `external-controller` address (host:port).
    pub mihomo: String,
    /// sing-box `external_controller` address (host:port).
    pub sing_box: String,
}

impl Default for ControllersConfig {
    fn default() -> Self {
        Self {
            mihomo: "127.0.0.1:9090".to_owned(),
            sing_box: "127.0.0.1:9091".to_owned(),
        }
    }
}

/// Optional executable locations for managed proxy cores.
///
/// Paths are intentionally not required to exist while the configuration is
/// parsed: packages may install a config before the binary. The lifecycle
/// owner validates existence and executability immediately before start.
#[derive(Clone, Debug, Default, Deserialize, Eq, PartialEq)]
#[serde(default, deny_unknown_fields)]
pub struct CoreBinariesConfig {
    /// Absolute or relative path to the Mihomo executable.
    pub mihomo: Option<PathBuf>,
    /// Absolute or relative path to the sing-box executable.
    pub sing_box: Option<PathBuf>,
}

/// Subscription refresh source and fetch-policy inputs wired to the daemon.
#[derive(Clone, Debug, Deserialize, Eq, PartialEq, Serialize)]
#[serde(default, deny_unknown_fields)]
pub struct SubscriptionConfig {
    /// Public HTTP(S) subscription URL. Omitted means the legacy single-source
    /// path is unavailable; prefer `sources` for multi-source refresh.
    pub url: Option<String>,
    /// Multiple explicit subscription sources; each is refreshed when
    /// `caly sub refresh` runs. `enabled` toggles an individual source.
    #[serde(default)]
    pub sources: Vec<SubscriptionSource>,
    /// TCP connect timeout for one fetch attempt in milliseconds (>= 100).
    pub connect_timeout_ms: u64,
    /// Overall request timeout for one fetch attempt in milliseconds (>= 1000).
    pub request_timeout_ms: u64,
    /// Maximum accepted response body in mebibytes (1..=256).
    pub max_body_mb: u64,
    /// Follow HTTP redirects (disabled by default for SSRF containment).
    pub follow_redirects: bool,
    /// Route the fetch through the environment proxy variables.
    pub use_environment_proxy: bool,
}

/// One explicit subscription source in `subscriptions.sources`.
#[derive(Clone, Debug, Deserialize, Eq, PartialEq, Serialize)]
#[serde(default, deny_unknown_fields)]
pub struct SubscriptionSource {
    /// Public HTTP(S) subscription URL.
    pub url: String,
    /// Refresh this source on `caly sub refresh` (default true).
    pub enabled: bool,
}

impl Default for SubscriptionSource {
    fn default() -> Self {
        Self {
            url: String::new(),
            enabled: true,
        }
    }
}

/// A named provider grouping subscription sources or inline node URIs.
///
/// A provider is the user-visible container for proxy content: a
/// `SubscriptionSources` provider aggregates every enabled subscription source
/// (枚举型), while an `InlineNodes` provider holds bare proxy-node URIs
/// (`vmess://`, `ss://`, …) that carry no upstream subscription URL. When
/// `providers:` is unset, a `default` provider is derived automatically from
/// `subscriptions.*` — the exact set `caly sub list` reads.
#[derive(Clone, Debug, Deserialize, Eq, PartialEq, Serialize)]
#[serde(default, deny_unknown_fields)]
pub struct ProviderConfig {
    /// Provider tag; `default` is the auto-derived one.
    pub name: String,
    /// What the provider contains.
    pub kind: ProviderKind,
}

impl Default for ProviderConfig {
    fn default() -> Self {
        Self {
            name: "default".to_owned(),
            kind: ProviderKind::SubscriptionSources,
        }
    }
}

/// Provider content kind (枚举型).
#[derive(Clone, Debug, Deserialize, Eq, PartialEq, Serialize)]
#[serde(rename_all = "kebab-case")]
pub enum ProviderKind {
    /// Aggregates every enabled subscription source URL
    /// (`subscriptions.url` plus enabled `subscriptions.sources` entries).
    SubscriptionSources,
    /// Bare proxy-node URIs (`vmess://` …) without an upstream URL.
    InlineNodes(Vec<String>),
}

impl SubscriptionConfig {
    /// Returns every enabled source URL: the legacy `url` (always enabled when
    /// set) followed by the enabled entries of `sources`. This is the full set
    /// `caly sub refresh` fetches and merges.
    pub fn enabled_source_urls(&self) -> Vec<String> {
        let mut out = Vec::new();
        if let Some(url) = &self.url {
            out.push(url.clone());
        }
        out.extend(
            self.sources
                .iter()
                .filter(|source| source.enabled)
                .map(|source| source.url.clone()),
        );
        out
    }

    /// The auto-created 枚举型 default provider: contains every enabled
    /// subscription source URL — exactly the set `caly sub list` reads.
    /// Returns `None` when no source is configured, so a node-only config
    /// (inline `vmess://`-style content) never fabricates an empty provider.
    pub fn default_provider(&self) -> Option<ProviderConfig> {
        if self.enabled_source_urls().is_empty() {
            return None;
        }
        Some(ProviderConfig {
            name: "default".to_owned(),
            kind: ProviderKind::SubscriptionSources,
        })
    }
}

/// One user-defined rule provider. Mirrors `ProviderConfig` (a named source
/// of proxy content): `RuleProvider` is a named source of rule content,
/// tagged and referenced from `RULE-SET,<name>,…` rules. Three source
/// kinds cover the common shapes; caly never fetches HTTP bodies itself
/// (the core does, on its own polling cadence).
///
/// `deny_unknown_fields` is omitted because the inner source enum is
/// tagged with `type`; serde consumes that key during flatten and
/// `deny_unknown_fields` on the outer struct would reject the
/// already-consumed field.
#[derive(Clone, Debug, Deserialize, Eq, PartialEq, Serialize)]
pub struct RuleProviderConfig {
    /// Tag referenced from `RULE-SET,<name>,…` rules and from the
    /// rendered core's `rule-providers:` / `route.rule_set` block. Must
    /// be unique within one configuration.
    pub name: String,
    /// Where the rule body comes from. Internally tagged: a `type:` field
    /// selects the variant. Exactly one variant is decoded per entry.
    #[serde(flatten)]
    pub kind: RuleProviderSourceConfig,
    /// What kind of matchers the body contains. Maps to Mihomo's
    /// `behavior:` and sing-box's `route_set` `type` discriminator.
    pub behavior: RuleProviderBehaviorConfig,
    /// On-disk / on-wire format. `Binary` is sing-box's compiled `.srs`
    /// and is only valid for `http` / `file` sources.
    #[serde(default = "default_format")]
    pub format: RuleProviderFormatConfig,
    /// Round 15: `enabled: false` makes the daemon skip this
    /// provider at boot (the entry stays in `rule_providers:`
    /// for the operator to re-enable). Mirrors the
    /// `SubscriptionSource::enabled` shape so the same
    /// `set X enable|disable <name>` policy works for both.
    #[serde(default = "default_rule_provider_enabled")]
    pub enabled: bool,
}

fn default_rule_provider_enabled() -> bool {
    true
}

impl RuleProviderConfig {
    /// Builds the domain [`caly_domain::RuleProvider`] used by the
    /// rule renderer. Returns `Err(String)` when one of the required
    /// fields for the chosen source kind is empty (the loader runs
    /// before validation can enforce them).
    pub fn to_rule_provider(&self) -> Result<caly_domain::RuleProvider, String> {
        let name = RuleProviderName::new(self.name.clone())
            .map_err(|error| format!("rule provider name is too long: {error}"))?;
        let source = match &self.kind {
            RuleProviderSourceConfig::Http { url, interval_ms } => {
                let bounded = RuleText::new(url.clone())
                    .map_err(|error| format!("rule provider url is too long: {error}"))?;
                caly_domain::RuleProviderSource::Http {
                    url: bounded,
                    interval_ms: *interval_ms,
                }
            }
            RuleProviderSourceConfig::File { path } => {
                let bounded = RuleText::new(path.clone())
                    .map_err(|error| format!("rule provider path is too long: {error}"))?;
                caly_domain::RuleProviderSource::File { path: bounded }
            }
            RuleProviderSourceConfig::Inline { payload } => {
                let bounded = caly_domain::BoundedText::<{ caly_domain::INLINE_RULE_PAYLOAD_MAX_BYTES }>::new(
                    payload.clone(),
                )
                .map_err(|error| format!("rule provider payload is too long: {error}"))?;
                caly_domain::RuleProviderSource::Inline {
                    payload: bounded,
                }
            }
        };
        let behavior = self.behavior.to_domain();
        let format = self.format.to_domain();
        Ok(caly_domain::RuleProvider {
            name,
            source,
            behavior,
            format,
        })
    }
}

const fn default_format() -> RuleProviderFormatConfig {
    RuleProviderFormatConfig::Source
}

/// `type:` discriminator for [`RuleProviderConfig`]. The serde `tag`
/// attribute picks the variant by the value of the `type` field, so a
/// single `type: http | file | inline` token selects the body shape.
/// Exactly one variant is decoded per entry.
#[derive(Clone, Debug, Deserialize, Eq, PartialEq, Serialize)]
#[serde(tag = "type", rename_all = "snake_case", deny_unknown_fields)]
pub enum RuleProviderSourceConfig {
    /// `type: http` — fetched from `url` on `interval_ms` cadence.
    Http {
        /// Public HTTP(S) URL serving the rule body.
        url: String,
        /// Polling interval in milliseconds. Defaults to 86400000 (one day).
        #[serde(default = "default_http_interval_ms")]
        interval_ms: u64,
    },
    /// `type: file` — read once from the local file.
    File {
        /// Absolute or working-directory-relative path.
        path: String,
    },
    /// `type: inline` — body lives in the config under `payload:`.
    Inline {
        /// Rule body; one rule per line, same syntax as a Mihomo
        /// `rules:` block.
        payload: String,
    },
}

const fn default_http_interval_ms() -> u64 {
    86_400_000
}

/// `behavior:` field of a rule provider (the kind of matchers the body
/// contains). Mirrors `RouteProviderBehavior` so the rendered kernel
/// config keeps the same vocabulary as the domain model.
#[derive(Clone, Copy, Debug, Deserialize, Eq, PartialEq, Serialize)]
#[serde(rename_all = "snake_case")]
pub enum RuleProviderBehaviorConfig {
    Domain,
    DomainSuffix,
    IpCidr,
    Classical,
}

impl RuleProviderBehaviorConfig {
    const fn to_domain(self) -> RuleProviderBehavior {
        match self {
            Self::Domain => RuleProviderBehavior::Domain,
            Self::DomainSuffix => RuleProviderBehavior::DomainSuffix,
            Self::IpCidr => RuleProviderBehavior::IpCidr,
            Self::Classical => RuleProviderBehavior::Classical,
        }
    }
}

/// `format:` field of a rule provider; defaults to `source`.
#[derive(Clone, Copy, Debug, Deserialize, Eq, PartialEq, Serialize)]
#[serde(rename_all = "snake_case")]
pub enum RuleProviderFormatConfig {
    Source,
    Binary,
}

impl RuleProviderFormatConfig {
    const fn to_domain(self) -> RuleProviderFormat {
        match self {
            Self::Source => RuleProviderFormat::Source,
            Self::Binary => RuleProviderFormat::Binary,
        }
    }
}

impl Default for SubscriptionConfig {
    fn default() -> Self {
        Self {
            url: None,
            sources: Vec::new(),
            connect_timeout_ms: 5_000,
            request_timeout_ms: 30_000,
            max_body_mb: 32,
            follow_redirects: false,
            use_environment_proxy: false,
        }
    }
}

/// Daemon logging verbosity.
#[derive(Clone, Debug, Deserialize, Eq, PartialEq, Serialize)]
#[serde(default, deny_unknown_fields)]
pub struct LogConfig {
    /// One of `error`, `warn`, `info`, `debug`, `trace`.
    pub level: String,
}

impl Default for LogConfig {
    fn default() -> Self {
        Self {
            level: "info".to_owned(),
        }
    }
}

/// Telemetry sampling cadence.
#[derive(Clone, Debug, Deserialize, Eq, PartialEq, Serialize)]
#[serde(default, deny_unknown_fields)]
pub struct TelemetryConfig {
    /// Sampling interval in milliseconds (>= 100).
    pub interval_ms: u64,
}

impl Default for TelemetryConfig {
    fn default() -> Self {
        Self { interval_ms: 1_000 }
    }
}

/// Base `config.yaml` content: minimal and self-validating. Feature sections
/// live in `config.d/` fragments and are deep-merged by the layered loader.
pub fn render_default_base() -> String {
    "# caly base configuration\nschema_version: 1\ncore: mihomo\n".to_owned()
}

/// Renders the generated feature-file layout. `config.yaml` stays minimal and
/// self-validating; fragments are merged later by the existing layered loader.
///
/// Commented examples always show the *complete replacement block* with
/// correct nesting, so uncommenting them can never produce a stray top-level
/// key (rejected by `deny_unknown_fields`).
pub fn render_default_config_files() -> Vec<(PathBuf, String)> {
    let mut fragments = core_and_transport_fragments();
    fragments.extend(effect_and_observability_fragments());
    fragments
}

/// Fragments for core binaries, controllers and the daemon transport.
fn core_and_transport_fragments() -> Vec<(PathBuf, String)> {
    let controllers = ControllersConfig::default();
    let daemon = DaemonConfig::default();
    let kernel = super::KernelConfig::default();
    vec![
        (
            PathBuf::from("config.d/10-core.yaml"),
            format!(
                "# Core binaries and local Clash-compatible controllers.\n\
                 core_binaries: {{}}\n\
                 controllers:\n\
                 \x20 mihomo: {mihomo}\n\
                 \x20 sing_box: {sing_box}\n\
                 \n\
                 # To pin core executables, replace `core_binaries: {{}}` above with:\n\
                 # core_binaries:\n\
                 #   mihomo: /opt/mihomo/mihomo\n\
                 #   sing_box: /opt/sing-box/sing-box\n",
                mihomo = controllers.mihomo,
                sing_box = controllers.sing_box,
            ),
        ),
        (
            PathBuf::from("config.d/15-kernel.yaml"),
            format!(
                "# Runtime tuning for the managed proxy kernel, rendered into the core\n\
                 # config (Mihomo mixed-port/allow-lan/log-level; sing-box mixed inbound).\n\
                 # The desktop system proxy points at mixed_port unless overridden in\n\
                 # 70-system-proxy.yaml. `restart` bounds the crash-loop self-healing\n\
                 # backoff for automatic core restarts.\n\
                 kernel:\n\
                 \x20 mixed_port: {mixed_port}\n\
                 \x20 allow_lan: false\n\
                 \x20 bind_address: '*'        # LAN bind when allow_lan: true ('*' or one interface IP)\n\
                 \x20 log_level: {log_level}       # trace | debug | info | warn | error\n\
                 \x20 start_timeout_ms: 10000      # readiness budget for start/restart\n\
                 \x20 stop_timeout_ms: 5000        # graceful stop budget\n\
                 \x20 restart:                     # crash-loop self-healing backoff\n\
                 \x20\x20\x20 initial_backoff_ms: 1000\n\
                 \x20\x20\x20 max_backoff_ms: 30000\n\
                 \x20 transparent:                 # transparent proxy (default off)\n\
                 \x20\x20\x20 enabled: false\n\
                 \x20\x20\x20 mode: redirect           # redirect | tproxy\n\
                 \x20\x20\x20 port: 7892\n",
                mixed_port = kernel.mixed_port,
                log_level = kernel.log_level,
            ),
        ),
        (
            PathBuf::from("config.d/20-daemon.yaml"),
            format!(
                "# Loopback TCP gRPC listener in addition to the UDS socket.\n\
                 # Remote (non-loopback) listen is not yet supported: enforced TLS and\n\
                 # auth-token admission are unimplemented, so the daemon refuses it at boot.\n\
                 daemon:\n\
                 \x20 listen: {listen}\n\
                 \x20 tls_enabled: false\n\
                 \x20 auto_start_core: true        # engage the core at boot; a failure only warns\n",
                listen = daemon.listen,
            ),
        ),
        (
            PathBuf::from("config.d/30-subscriptions.yaml"),
            "# Public HTTP(S) subscription source(s). The SSRF policy rejects\n\
             # private/loopback destinations.\n\
             subscriptions: {}\n\
             \n\
             # To enable `caly sub refresh`, replace `subscriptions: {}` above with\n\
             # a url or a list of explicit `sources` (fetch tuning is optional;\n\
             # defaults shown). `sources` lets you refresh several providers at\n\
             # once and merge their nodes; `enabled: false` skips one source.\n\
             # subscriptions:\n\
             #   url: https://provider.example/subscription\n\
             #   sources:\n\
             #     - url: https://first.example/sub\n\
             #       enabled: true\n\
             #     - url: https://second.example/sub\n\
             #       enabled: true\n\
             #   connect_timeout_ms: 5000\n\
             #   request_timeout_ms: 30000\n\
             #   max_body_mb: 32\n\
             #   follow_redirects: false\n\
             #\n\
             # Providers (enumeration type): when any source above is configured,\n\
             # caly auto-creates the `default` provider as an enumeration of every\n\
             # enabled source URL — `caly sub list` shows it and `sub refresh`\n\
             # fetches its sources. Bare node URIs (vmess:// …) are not sources\n\
             # (no upstream URL) and stay preview-only in `sub import`. An\n\
             # explicit `providers:` list overrides the derived default:\n\
             # providers:\n\
             #   - name: default\n\
             #     kind: subscription-sources\n\
             #   use_environment_proxy: false\n"
                .to_owned(),
        ),
    ]
}

/// Fragments for platform side effects (TUN, system proxy) and observability.
fn effect_and_observability_fragments() -> Vec<(PathBuf, String)> {
    let tun = TunConfig::default();
    let mut out = vec![
        super::fragments_dns::dns_fragment(),
        (
            PathBuf::from("config.d/60-tun.yaml"),
            format!(
                "# TUN rendering into the core config (stack/auto-route/strict-route).\n\
                 # `caly sys tun on` additionally engages the platform TUN device and\n\
                 # requires CAP_NET_ADMIN. When the daemon lacks it, `escalation` retries\n\
                 # the privileged `ip` commands: auto = pkexec then passwordless sudo.\n\
                 tun:\n\
                 \x20 enabled: false\n\
                 \x20 mtu: {mtu}\n\
                 \x20 stack: gvisor          # gvisor | mixed | system\n\
                 \x20 auto_route: true\n\
                 \x20 strict_route: true\n\
                 \x20 escalation: auto       # auto | pkexec | sudo | none\n",
                mtu = tun.mtu,
            ),
        ),
        (
            PathBuf::from("config.d/70-system-proxy.yaml"),
            "# Desktop system proxy. Supported desktops: GNOME, KDE, niri.\n\
             # `enabled: true` engages the proxy at daemon start (degrading to a\n\
             # warning on unsupported desktops); `caly sys proxy on|off` controls it\n\
             # at runtime. The desktop state found before engagement is captured and\n\
             # restored on graceful shutdown; after a crash the effect is re-applied\n\
             # by restore-first on the next boot.\n\
             system_proxy:\n\
             \x20 enabled: false\n\
             \x20 host: 127.0.0.1\n\
             \x20 # port: 7890       # defaults to kernel.mixed_port when omitted\n"
                .to_owned(),
        ),
        (
            PathBuf::from("config.d/80-observability.yaml"),
            "# Logging and telemetry. CALY_LOG still overrides log.level.\n\
             log:\n\
             \x20 level: info          # error | warn | info | debug | trace\n\
             \n\
             telemetry:\n\
             \x20 interval_ms: 1000    # sampling cadence, >= 100\n"
                .to_owned(),
        ),
    ];
    out.push(super::fragments_proxy_groups::proxy_groups_fragment());
    out.push(super::fragments_routing::routing_fragment());
    out.push(super::fragments_routing::rule_providers_fragment());
    out.push(super::fragments_profiles::profiles_fragment());
    out
}

/// Renders one commented default `config.yaml` documenting every option, for
/// documentation and single-file setups. Composed from the exact base and
/// fragment pieces `config generate` writes, so the two layouts cannot drift.
pub fn render_default_config() -> String {
    let mut out = String::new();
    out.push_str("# caly configuration\n");
    out.push_str(
        "# Default location: $XDG_CONFIG_HOME/caly/config.yaml (usually ~/.config/caly/).\n",
    );
    out.push_str("# Managed proxy core. Values: mihomo | sing-box (xray is not supported).\n");
    out.push_str(&render_default_base());
    out.push('\n');
    for (path, contents) in render_default_config_files() {
        let _ = std::fmt::Write::write_fmt(
            &mut out,
            format_args!("# ---- {} ----\n{contents}\n", path.display()),
        );
    }
    out
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::schema::parse_and_validate_yaml;

    #[test]
    fn generated_base_parses_and_validates() {
        let parsed = parse_and_validate_yaml(render_default_base().as_bytes());
        assert!(parsed.is_ok(), "base config must validate: {parsed:?}");
    }

    #[test]
    fn generated_fragments_validate_individually() {
        for (path, contents) in render_default_config_files() {
            // Fragments are merged onto the base by the layered loader; each one
            // must at least parse as YAML on its own.
            let value: serde_norway::Value =
                serde_norway::from_str(&contents).unwrap_or_else(|error| {
                    eprintln!("{} must parse: {error}", path.display());
                    std::process::abort()
                });
            assert!(
                value.as_mapping().is_some(),
                "{} must be a mapping",
                path.display()
            );
        }
    }

    #[test]
    fn enabled_option_blocks_validate_when_substituted() {
        // The documented replacement blocks must produce valid configurations.
        let core_binaries = "schema_version: 1\ncore: mihomo\n\
                             core_binaries:\n  mihomo: /opt/mihomo/mihomo\n  \
                             sing_box: /opt/sing-box/sing-box\n";
        assert!(parse_and_validate_yaml(core_binaries.as_bytes()).is_ok());
        let subscription = "schema_version: 1\ncore: mihomo\n\
                            subscriptions:\n  url: https://provider.example/subscription\n";
        assert!(parse_and_validate_yaml(subscription.as_bytes()).is_ok());
    }

    #[test]
    fn fragment_paths_are_sorted_deterministically() {
        let paths: Vec<PathBuf> = render_default_config_files()
            .into_iter()
            .map(|(path, _)| path)
            .collect();
        let mut sorted = paths.clone();
        sorted.sort();
        assert_eq!(paths, sorted, "fragment merge order must be stable");
    }

    #[test]
    fn generated_layout_round_trips_through_the_layered_loader() {
        use crate::loader::{LayeredConfigPaths, LoaderLimits, load_layered_yaml};
        // Write exactly what `caly config generate` writes, then load it back
        // through the real layered loader: the generated default must boot.
        let root = std::env::temp_dir().join(format!(
            "caly-settings-roundtrip-{}-{}",
            std::process::id(),
            std::time::SystemTime::now()
                .duration_since(std::time::UNIX_EPOCH)
                .map_or(0, |value| value.as_nanos())
        ));
        std::fs::create_dir_all(&root).unwrap_or_default();
        std::fs::write(root.join("config.yaml"), render_default_base()).unwrap_or_default();
        for (relative, contents) in render_default_config_files() {
            let destination = root.join(relative);
            if let Some(parent) = destination.parent() {
                std::fs::create_dir_all(parent).unwrap_or_default();
            }
            std::fs::write(&destination, contents).unwrap_or_default();
        }
        let loaded = load_layered_yaml(
            &LayeredConfigPaths::new(root.clone(), None),
            LoaderLimits::secure_default(),
        );
        std::fs::remove_dir_all(&root).ok();
        let config = loaded.unwrap_or_else(|error| {
            eprintln!("generated layout must load: {error:?}");
            std::process::abort()
        });
        assert_eq!(config.controllers.mihomo, "127.0.0.1:9090");
        assert_eq!(config.telemetry.interval_ms, 1_000);
        assert!(!config.tun.enabled);
        assert!(config.subscriptions.url.is_none());
    }

    #[test]
    fn generated_routing_fragment_documents_new_matchers() {
        let (_, contents) = crate::schema::fragments_routing::routing_fragment();
        for token in [
            "DOMAIN,",
            "DOMAIN-SUFFIX,",
            "DOMAIN-KEYWORD,",
            "GEOIP,",
            "IP-CIDR,",
            "SRC-IP-CIDR,",
            "PROCESS-NAME,",
            "RULE-SET,",
            "GEOSITE,",
            "MATCH,",
        ] {
            assert!(
                contents.contains(token),
                "routing fragment must document `{token}` matcher"
            );
        }
        // The default config is `rules: []` — every snippet is commented,
        // so a fresh install has zero user rules.
        let parsed: serde_norway::Value =
            serde_norway::from_str(&contents).unwrap_or_else(|error| {
                eprintln!("routing fragment must parse: {error}");
                std::process::abort()
            });
        assert!(parsed.get("rules").is_some(), "rules: key must exist");
        assert_eq!(
            parsed.get("rules").and_then(|v| v.as_sequence()),
            Some(&serde_norway::Sequence::new()),
            "rules default must be an empty list"
        );
    }

    #[test]
    fn generated_rule_providers_fragment_documents_three_source_kinds() {
        let (_, contents) = crate::schema::fragments_routing::rule_providers_fragment();
        for token in [
            "type: http",
            "type: file",
            "type: inline",
            "behavior: domain_suffix",
            "behavior: ip_cidr",
            "format: source",
            "rule_providers:",
            "Loyalsoldier/v2ray-rules-dat",
        ] {
            assert!(
                contents.contains(token),
                "rule-providers fragment must document `{token}`"
            );
        }
        // The default config is `rule_providers: []` — every snippet is
        // commented, so a fresh install has zero user rule providers.
        let parsed: serde_norway::Value =
            serde_norway::from_str(&contents).unwrap_or_else(|error| {
                eprintln!("rule-providers fragment must parse: {error}");
                std::process::abort()
            });
        assert_eq!(
            parsed.get("rule_providers").and_then(|v| v.as_sequence()),
            Some(&serde_norway::Sequence::new()),
            "rule_providers default must be an empty list"
        );
    }

    #[test]
    fn generated_profiles_fragment_documents_three_source_kinds() {
        let (_, contents) = crate::schema::fragments_profiles::profiles_fragment();
        for token in [
            "kind: remote",
            "kind: local",
            "kind: merge",
            "interval_minutes:",
            "parts: [team-shared",
            "profiles:",
        ] {
            assert!(
                contents.contains(token),
                "profiles fragment must document `{token}`"
            );
        }
        let parsed: serde_norway::Value =
            serde_norway::from_str(&contents).unwrap_or_else(|error| {
                eprintln!("profiles fragment must parse: {error}");
                std::process::abort()
            });
        assert_eq!(
            parsed.get("profiles").and_then(|v| v.as_sequence()),
            Some(&serde_norway::Sequence::new()),
            "profiles default must be an empty list"
        );
    }

    #[test]
    fn generated_proxy_groups_fragment_documents_five_kinds() {
        let (_, contents) = crate::schema::fragments_proxy_groups::proxy_groups_fragment();
        for token in [
            "type: select",
            "type: url-test",
            "type: fallback",
            "type: load-balance",
            "type: relay",
            "kind: node",
            "kind: group",
            "kind: direct",
            "kind: reject",
            "proxy_groups:",
        ] {
            assert!(
                contents.contains(token),
                "proxy-groups fragment must document `{token}`"
            );
        }
        // The default config is `proxy_groups: []` — every
        // snippet is commented, so a fresh install has zero
        // user proxy groups.
        let parsed: serde_norway::Value =
            serde_norway::from_str(&contents).unwrap_or_else(|error| {
                eprintln!("proxy-groups fragment must parse: {error}");
                std::process::abort()
            });
        assert!(
            parsed.get("proxy_groups").is_some(),
            "proxy_groups: key must exist"
        );
        assert_eq!(
            parsed.get("proxy_groups").and_then(|v| v.as_sequence()),
            Some(&serde_norway::Sequence::new()),
            "proxy_groups default must be an empty list"
        );
    }
}
