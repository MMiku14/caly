//! sing-box outbound generation from owned dialable subscription nodes.

use caly_domain::{DialableNode, SubscriptionId};

use super::{
    clash::parse_clash_yaml, decode_document, format::SubscriptionDocument,
    uri::parse_any_proxy_uri,
};

mod document;
mod node;

pub use document::{
    SingBoxRenderTuning, sing_box_document, uri_body_to_sing_box_json,
    uri_body_to_sing_box_json_with,
};
pub use node::{node_to_json, node_to_json_string};

use caly_domain::NodeId;
use std::collections::BTreeMap;

/// Extracts dialable nodes from a decoded document, tolerating unparseable URI
/// lines and parsing Clash-YAML bodies atomically. An unusable body is empty.
pub(super) fn dialable_nodes(
    document: SubscriptionDocument,
    subscription: SubscriptionId,
) -> Result<Vec<DialableNode>, SingBoxOutboundError> {
    match document {
        SubscriptionDocument::UriLines { lines, .. } => Ok(lines
            .iter()
            .filter_map(|line| parse_any_proxy_uri(line.as_str(), subscription).ok())
            .collect()),
        SubscriptionDocument::ClashYaml(body) => {
            let source = core::str::from_utf8(body.as_slice())
                .map_err(|_| SingBoxOutboundError::InvalidFormat)?;
            parse_clash_yaml(source, subscription)
                .map_err(|_| SingBoxOutboundError::UnsupportedDocument)
        }
        SubscriptionDocument::Sip008(body) => {
            let source = core::str::from_utf8(body.as_slice())
                .map_err(|_| SingBoxOutboundError::InvalidFormat)?;
            Ok(super::parse_sip008(source, subscription).0)
        }
        // URL lists are expanded by the daemon fetch path before rendering.
        SubscriptionDocument::UrlList(_) => Err(SingBoxOutboundError::UnsupportedDocument),
    }
}

#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub enum SingBoxOutboundError {
    InvalidFormat,
    UnsupportedDocument,
    UnsupportedNode,
    Serialization,
}

impl core::fmt::Display for SingBoxOutboundError {
    fn fmt(&self, formatter: &mut core::fmt::Formatter<'_>) -> core::fmt::Result {
        match self {
            Self::InvalidFormat => formatter.write_str("subscription body is not decodable"),
            Self::UnsupportedDocument => {
                formatter.write_str("document format is not renderable for sing-box")
            }
            Self::UnsupportedNode => formatter.write_str("node is not representable"),
            Self::Serialization => formatter.write_str("sing-box JSON rendering failed"),
        }
    }
}

/// Renders per-node sing-box outbound JSON objects keyed by canonical
/// `NodeId`, skipping nodes the strict renderer cannot represent. The registry
/// stores these so a config backend can rebuild the outbounds array without
/// re-parsing the subscription body (mirrors the Mihomo yaml field).
pub fn uri_body_to_sing_box_outbound_map(
    body: &[u8],
    subscription: SubscriptionId,
) -> Result<BTreeMap<NodeId, String>, SingBoxOutboundError> {
    let document =
        decode_document(body.to_vec()).map_err(|_| SingBoxOutboundError::InvalidFormat)?;
    let mut map = BTreeMap::new();
    for node in dialable_nodes(document, subscription)? {
        if map.contains_key(&node.id()) {
            continue;
        }
        if let Ok(outbound) = node_to_json_string(&node) {
            map.insert(node.id(), outbound);
        }
    }
    Ok(map)
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn trojan_and_vmess_render_tls_alter_id_and_transport() -> Result<(), String> {
        let body = "trojan://secret-pass@example.com:443?security=tls&sni=example.com&type=ws&path=%2Fstream#trojan-ws\n\
                    vmess://eyJhZGQiOiJleGFtcGxlLmNvbSIsInBvcnQiOjQ0MywiaWQiOiI2YTg5YTIxNS0yMmJmLTRiZDctOTY0Mi1iOTViMmUwOTU4M2EiLCJhaWQiOjAsIm5ldCI6IndzIiwicGF0aCI6Ii9zIiwiaG9zdCI6ImV4YW1wbGUuY29tIiwidGxzIjoidGxzIiwicHMiOiJ2bWVzLW5vZGUifQ==\n"
            .as_bytes()
            .to_vec();
        let id = SubscriptionId::from_bytes([8; 16]);
        let json = uri_body_to_sing_box_json(body, id).map_err(|e| format!("{e:?}"))?;
        let text = String::from_utf8_lossy(&json);
        assert!(text.contains("\"tls\""), "trojan/vmess TLS must render");
        assert!(text.contains("\"alter_id\""), "vmess alter_id must render");
        assert!(text.contains("\"security\""), "vmess security must render");
        assert!(text.contains("\"transport\""), "ws transport must render");
        Ok(())
    }

    #[test]
    fn hysteria2_and_tuic_render() -> Result<(), String> {
        let body = "hysteria2://secret@example.com:443?security=tls&sni=example.com&obfs=salamander&obfs-password=obfspass&upmbps=50&downmbps=100#hy2\n\
                    tuic://2DD61D93-75D8-4DA4-AC0E-6AECE7EAC365:hello@example.com:443?congestion_control=bbr#tuic\n"
            .as_bytes()
            .to_vec();
        let id = SubscriptionId::from_bytes([9; 16]);
        let json = uri_body_to_sing_box_json(body, id).map_err(|e| format!("{e:?}"))?;
        let text = String::from_utf8_lossy(&json);
        assert!(text.contains("\"type\":\"hysteria2\""));
        assert!(text.contains("\"password\":\"secret\""));
        assert!(text.contains("\"up_mbps\":50"));
        assert!(text.contains("\"obfs\""));
        assert!(text.contains("\"type\":\"tuic\""));
        assert!(text.contains("\"congestion_control\":\"bbr\""));
        Ok(())
    }

    #[test]
    fn emits_global_selector_and_clash_mode_rules() -> Result<(), String> {
        let body = "vless://2DD61D93-75D8-4DA4-AC0E-6AECE7EAC365@example.com:443?security=tls#n1\n\
                    vless://2DD61D93-75D8-4DA4-AC0E-6AECE7EAC365@example.org:443?security=tls#n2\n"
            .as_bytes()
            .to_vec();
        let id = SubscriptionId::from_bytes([10; 16]);
        let json = uri_body_to_sing_box_json(body, id).map_err(|e| format!("{e:?}"))?;
        let text = String::from_utf8_lossy(&json);
        // A GLOBAL selector over all nodes enables the Global routing mode.
        assert!(
            text.contains("\"tag\":\"GLOBAL\""),
            "must emit a GLOBAL selector"
        );
        // The clash_mode rules make rule/global/direct switchable at runtime.
        assert!(text.contains("\"clash_mode\":\"Global\",\"outbound\":\"GLOBAL\""));
        assert!(text.contains("\"clash_mode\":\"Direct\",\"outbound\":\"direct\""));
        Ok(())
    }
}

#[cfg(test)]
mod outbound_map_tests {
    use super::*;

    #[test]
    fn outbound_map_indexes_deduped_nodes() -> Result<(), String> {
        let body = "ss://YWVzLTEyOC1nY206cGFzc3dvcmQ=@example.com:8388#first\n\
                    ss://YWVzLTEyOC1nY206cGFzc3dvcmQ=@example.com:8388#duplicate\n\
                    ss://YWVzLTEyOC1nY206cGFzc3dvcmQ=@example.net:443#second\n"
            .as_bytes()
            .to_vec();
        let id = SubscriptionId::from_bytes([9; 16]);
        let map = uri_body_to_sing_box_outbound_map(&body, id).map_err(|e| format!("{e:?}"))?;
        // Two distinct canonical nodes (duplicate lines collapse to one).
        assert_eq!(map.len(), 2, "deduplicated nodes expected");
        for outbound in map.values() {
            let value: serde_json::Value =
                serde_json::from_str(outbound).map_err(|e| e.to_string())?;
            let tag = value["tag"].as_str().ok_or("missing tag")?;
            assert!(tag.starts_with("proxy-"), "tag must be proxy-<id>");
            assert_eq!(value["type"], "shadowsocks");
        }
        Ok(())
    }
}
