//! Bounded subscription format detection and document decoding.

use base64::{Engine as _, engine::general_purpose};
use caly_domain::{BoundedText, BoundedVec};
use serde_norway::Value;

/// Subscription body and decoded aggregate ceilings.
pub const MAX_SUBSCRIPTION_BODY_BYTES: usize = 32 * 1_024 * 1_024;
pub const MAX_SUBSCRIPTION_LINES: usize = 10_000;
pub const MAX_SUBSCRIPTION_LINE_BYTES: usize = 8 * 1_024;

pub type SubscriptionBody = BoundedVec<u8, MAX_SUBSCRIPTION_BODY_BYTES>;
pub type SubscriptionLine = BoundedText<MAX_SUBSCRIPTION_LINE_BYTES>;
pub type SubscriptionLines = BoundedVec<SubscriptionLine, MAX_SUBSCRIPTION_LINES>;

/// Supported top-level subscription documents.
#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub enum SubscriptionFormat {
    ClashYaml,
    UriLines,
    Base64UriLines,
}

/// Decoded document without yet constructing dialable nodes.
pub enum SubscriptionDocument {
    ClashYaml(SubscriptionBody),
    UriLines {
        source_format: SubscriptionFormat,
        lines: SubscriptionLines,
    },
    /// Plain-text subscription whose lines are themselves subscription URLs;
    /// the daemon fetches and merges each child before node parsing.
    UrlList(SubscriptionLines),
    /// SIP008 JSON document: an array of Shadowsocks server objects, or a
    /// `{"version":1,"servers":[...]}` envelope.
    Sip008(SubscriptionBody),
}

/// Detection/decode failure; no empty-success fallback.
#[derive(Clone, Debug, Eq, PartialEq)]
pub enum FormatError {
    Empty,
    BodyTooLarge,
    InvalidUtf8,
    UnknownFormat,
    Base64Rejected,
    DecodedBodyTooLarge,
    TooManyLines,
    LineTooLong,
}

/// Detects Clash YAML, direct URI lines, or a Base64 URI aggregate.
pub fn decode_document(body: Vec<u8>) -> Result<SubscriptionDocument, FormatError> {
    let bounded = SubscriptionBody::try_from_vec(body).map_err(|_| FormatError::BodyTooLarge)?;
    if bounded.is_empty() {
        return Err(FormatError::Empty);
    }
    let source = core::str::from_utf8(bounded.as_slice()).map_err(|_| FormatError::InvalidUtf8)?;
    if is_clash_yaml(source) {
        return Ok(SubscriptionDocument::ClashYaml(bounded));
    }
    if is_sip008_json(source) {
        return Ok(SubscriptionDocument::Sip008(bounded));
    }
    if is_url_list(source) {
        return Ok(SubscriptionDocument::UrlList(parse_lines(source)?));
    }
    if contains_supported_uri(source) {
        return Ok(SubscriptionDocument::UriLines {
            source_format: SubscriptionFormat::UriLines,
            lines: parse_lines(source)?,
        });
    }
    let decoded = decode_base64_aggregate(source)?;
    let decoded_text = core::str::from_utf8(&decoded).map_err(|_| FormatError::InvalidUtf8)?;
    // Base64 aggregates may carry a Clash YAML document or a SIP008 JSON
    // payload, not only URI lines.
    if is_clash_yaml(decoded_text) {
        let body = SubscriptionBody::try_from_vec(decoded)
            .map_err(|_| FormatError::DecodedBodyTooLarge)?;
        return Ok(SubscriptionDocument::ClashYaml(body));
    }
    if is_sip008_json(decoded_text) {
        let body = SubscriptionBody::try_from_vec(decoded)
            .map_err(|_| FormatError::DecodedBodyTooLarge)?;
        return Ok(SubscriptionDocument::Sip008(body));
    }
    if !contains_supported_uri(decoded_text) {
        return Err(FormatError::UnknownFormat);
    }
    Ok(SubscriptionDocument::UriLines {
        source_format: SubscriptionFormat::Base64UriLines,
        lines: parse_lines(decoded_text)?,
    })
}

fn is_clash_yaml(source: &str) -> bool {
    let Ok(Value::Mapping(mapping)) = serde_norway::from_str::<Value>(source) else {
        return false;
    };
    mapping.contains_key(Value::String("proxies".to_owned()))
}

/// Detects a SIP008 JSON document: either a JSON array of Shadowsocks server
/// objects, or the `{"version":1,"servers":[...]}` envelope. A candidate must
/// expose `server` plus `method` or `password` so arbitrary JSON is not
/// mistaken for a subscription.
fn is_sip008_json(source: &str) -> bool {
    let Ok(value) = serde_norway::from_str::<Value>(source) else {
        return false;
    };
    let servers: &[Value] = match &value {
        Value::Sequence(items) => items,
        Value::Mapping(mapping) => match mapping.get("servers") {
            Some(Value::Sequence(items)) => items,
            _ => return false,
        },
        _ => return false,
    };
    servers.iter().any(|entry| match entry {
        Value::Mapping(fields) => {
            fields.contains_key("server")
                && (fields.contains_key("method") || fields.contains_key("password"))
        }
        _ => false,
    })
}

/// Detects a plain-text URL-list subscription: every significant line is an
/// HTTP(S) URL and no line carries a fragment (real proxy node URIs use `#`
/// for their display name, subscription URLs do not).
fn is_url_list(source: &str) -> bool {
    let mut any = false;
    for line in source.lines().map(str::trim) {
        if line.is_empty() || line.starts_with('#') {
            continue;
        }
        let is_url =
            (line.starts_with("http://") || line.starts_with("https://")) && !line.contains('#');
        if !is_url {
            return false;
        }
        any = true;
    }
    any
}

fn contains_supported_uri(source: &str) -> bool {
    source.lines().any(|line| {
        let line = line.trim();
        supported_scheme(line.split_once("://").map(|(scheme, _)| scheme))
    })
}

fn supported_scheme(scheme: Option<&str>) -> bool {
    matches!(
        scheme,
        Some(
            "ss" | "ssr"
                | "vmess"
                | "vless"
                | "trojan"
                | "hysteria2"
                | "hy2"
                | "tuic"
                | "wireguard"
                | "http"
                | "https"
                | "socks"
                | "socks5"
        )
    )
}

fn decode_base64_aggregate(source: &str) -> Result<Vec<u8>, FormatError> {
    let compact: String = source
        .chars()
        .filter(|value| !value.is_ascii_whitespace())
        .collect();
    let estimated = compact.len().saturating_mul(3).saturating_div(4);
    if estimated > MAX_SUBSCRIPTION_BODY_BYTES {
        return Err(FormatError::DecodedBodyTooLarge);
    }
    for engine in [
        &general_purpose::STANDARD,
        &general_purpose::STANDARD_NO_PAD,
        &general_purpose::URL_SAFE,
        &general_purpose::URL_SAFE_NO_PAD,
    ] {
        if let Ok(decoded) = engine.decode(compact.as_bytes()) {
            if decoded.len() > MAX_SUBSCRIPTION_BODY_BYTES {
                return Err(FormatError::DecodedBodyTooLarge);
            }
            return Ok(decoded);
        }
    }
    Err(FormatError::Base64Rejected)
}

fn parse_lines(source: &str) -> Result<SubscriptionLines, FormatError> {
    let mut lines = SubscriptionLines::new();
    for line in source
        .lines()
        .map(str::trim)
        .filter(|line| !line.is_empty())
    {
        if line.starts_with('#') {
            continue;
        }
        let value = SubscriptionLine::new(line.to_owned()).map_err(|_| FormatError::LineTooLong)?;
        lines
            .try_push(value)
            .map_err(|_| FormatError::TooManyLines)?;
    }
    if lines.is_empty() {
        return Err(FormatError::Empty);
    }
    Ok(lines)
}

#[cfg(test)]
mod fixture_tests {
    use super::*;

    #[test]
    fn node_singbox_fixture_decodes_as_base64_uri_lines() {
        let body = include_bytes!("../../../../fixtures/subscription-20260803.txt").to_vec();
        let result = decode_document(body);
        assert!(matches!(result, Ok(SubscriptionDocument::UriLines {
            source_format: SubscriptionFormat::Base64UriLines,
            lines,
        }) if !lines.is_empty()));
    }

    fn b64(text: &str) -> Vec<u8> {
        use base64::Engine as _;
        base64::engine::general_purpose::STANDARD
            .encode(text.as_bytes())
            .into_bytes()
    }

    #[test]
    fn base64_encoded_clash_yaml_decodes_to_clash_document() {
        let yaml = "proxies:\n  - name: n\n    type: ss\n    server: s\n    port: 1\n    cipher: aes-128-gcm\n    password: p\n";
        let result = decode_document(b64(yaml));
        assert!(matches!(result, Ok(SubscriptionDocument::ClashYaml(_))));
    }

    #[test]
    fn sip008_array_and_envelope_are_detected() {
        let array = r#"[{"server":"s","server_port":1,"method":"aes-128-gcm","password":"p"}]"#;
        assert!(matches!(
            decode_document(array.as_bytes().to_vec()),
            Ok(SubscriptionDocument::Sip008(_))
        ));
        let envelope = r#"{"version":1,"servers":[{"server":"s","server_port":1,"method":"aes-128-gcm","password":"p"}]}"#;
        assert!(matches!(
            decode_document(envelope.as_bytes().to_vec()),
            Ok(SubscriptionDocument::Sip008(_))
        ));
        // Base64-encoded SIP008 is detected after decoding.
        assert!(matches!(
            decode_document(b64(envelope)),
            Ok(SubscriptionDocument::Sip008(_))
        ));
    }

    #[test]
    fn ssr_lines_are_recognized_as_uri_line_documents() {
        let body = "ssr://c3MtcGxhY2Vob2xkZXI\n";
        assert!(matches!(
            decode_document(body.as_bytes().to_vec()),
            Ok(SubscriptionDocument::UriLines { .. })
        ));
    }
}
