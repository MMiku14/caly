//! A bounded, deterministic executor for port futures (`ADR-036 §2.1`).
//!
//! [`crate::runtime::drive`] answers one question: "push *this* future until it is ready or a limit
//! says stop". That is enough for a single call, but three things a caller still cannot express:
//!
//! * **admission** -- if everything suspends, does the next caller queue forever or get refused?
//!   `ADR-013`'s bounded execution domain and `OVERLOAD_AND_RETRY_MODEL §3.1` both say the answer must be
//!   a retryable refusal that starts no work. Here that is [`BoundedExecutor::submit`], bounded by
//!   [`ExecutorLimits::max_tasks`].
//! * **fairness** -- several suspended callers must not starve each other. [`BoundedExecutor::tick`]
//!   gives every queued task the same poll budget, once, in submission order.
//! * **time** -- a deadline can only be judged by whoever holds a clock (`ONBOARDING_NOTES §4.86`), so
//!   the executor takes one as an injection and never reads a real clock of its own
//!   (`ADR-036 §6bis.1`: no new `clippy.toml` exemption for `caly-io`).
//!
//! # What this is not
//!
//! It is **not** a scheduler that manufactures progress. There is no thread, no waker registry, no
//! park/unpark. Between two rounds the world only moves if the caller allowed it to, via
//! [`Advance::StepMillis`] -- which asks the *injected* [`Clock`] to sleep, so in the simulator time
//! advances deterministically and on a real host it advances through the same port everything else
//! measures it with. With [`Advance::None`] a task that never becomes ready simply stays pending, and
//! the run ends with a typed [`IoFaultKind::Busy`] naming the stuck tasks -- which is the honest answer,
//! because "it will be ready soon" is a fact no one here can check.
//!
//! # Two things that fall out of the design and are asserted by tests
//!
//! * A rejection leaves nothing behind: no id is consumed, no queued task is disturbed, and no future
//!   is started (`OVERLOAD_AND_RETRY_MODEL §3.1`: the request never entered the executing state).
//! * A task ended by a deadline or a cancellation has its future **dropped mid-flight**. Any host
//!   operation that future already performed stays performed; the executor does not and cannot roll it
//!   back. That is why `ADR-036 §4` puts the burden on the ports' idempotent write ordering
//!   (`caly-storage::fs_store` writes content before metadata), not on this file.

use std::collections::VecDeque;

use caly_common::CancelToken;

use crate::{BoxFuture, Clock, Deadline, Drive, IoFault, IoFaultKind, Monotonic};

/// How many suspended tasks the executor holds at once (`ADR-036 §2.1`).
pub const DEFAULT_MAX_TASKS: usize = 64;
/// How many polls each queued task gets inside one [`BoundedExecutor::tick`].
pub const DEFAULT_POLLS_PER_TASK: u32 = 4;
/// How far the injected clock is asked to move when a round made no progress.
pub const DEFAULT_STEP_MILLIS: u64 = 1;

const _: () = assert!(
    DEFAULT_MAX_TASKS > 0,
    "an executor that can never accept a task would make every submission a refusal"
);
const _: () = assert!(
    DEFAULT_POLLS_PER_TASK > 0,
    "a zero poll budget would advance nothing while still counting as a round"
);
const _: () = assert!(
    DEFAULT_STEP_MILLIS > 0,
    "advancing time by zero would spin the round counter without moving the world"
);

/// Whether a round that made no progress is allowed to ask the clock to move.
#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub enum Advance {
    /// Never touch the clock. A task that is not ready stays pending.
    None,
    /// Ask [`Clock::sleep_until`] to move by this many milliseconds before the next round.
    ///
    /// Refused at construction when no clock was injected: without one "sleep" has no meaning, and
    /// silently downgrading to [`Advance::None`] would leave the caller believing time was moving.
    StepMillis(u64),
}

/// The numbers that bound a run.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct ExecutorLimits {
    /// Tasks accepted and not yet finished. A submission beyond this is refused with `Busy`.
    pub max_tasks: usize,
    /// Polls per task per round. `0` is treated as `1`: "one poll" is the smallest real budget, while
    /// "no polls" would be a round that looks like progress and cannot make any.
    pub polls_per_task: u32,
    pub advance: Advance,
}

impl Default for ExecutorLimits {
    fn default() -> Self {
        Self {
            max_tasks: DEFAULT_MAX_TASKS,
            polls_per_task: DEFAULT_POLLS_PER_TASK,
            advance: Advance::None,
        }
    }
}

impl ExecutorLimits {
    /// `max_tasks` only, everything else default -- the shape almost every caller wants.
    pub const fn bounded(max_tasks: usize) -> Self {
        Self {
            max_tasks,
            polls_per_task: DEFAULT_POLLS_PER_TASK,
            advance: Advance::None,
        }
    }

    pub const fn with_advance(mut self, advance: Advance) -> Self {
        self.advance = advance;
        self
    }

    pub const fn with_polls_per_task(mut self, polls_per_task: u32) -> Self {
        self.polls_per_task = polls_per_task;
        self
    }

    /// The budget actually handed to [`crate::drive`], with `0`-means-`1` applied.
    pub const fn effective_polls_per_task(&self) -> u32 {
        if self.polls_per_task == 0 {
            1
        } else {
            self.polls_per_task
        }
    }
}

/// Which task a submission became. Ids are allocated only on acceptance, so a refusal does not
/// advance them: a caller correlating results by id must never see a hole where nothing happened.
#[derive(Clone, Copy, Debug, Eq, PartialEq, Ord, PartialOrd, Hash)]
pub struct TaskId(pub u64);

/// Per-task limits, checked before every poll by [`crate::drive`].
///
/// Deliberately only the two things that can be *decided* from the outside. Byte and request budgets
/// are accounting (`ADR-036 §2.4`), which is step 3 and is not faked here.
#[derive(Clone, Debug, Default, Eq, PartialEq)]
pub struct TaskLimits<'a> {
    pub deadline: Option<Deadline>,
    pub cancel: Option<&'a CancelToken>,
}

impl<'a> TaskLimits<'a> {
    pub const fn none() -> Self {
        Self {
            deadline: None,
            cancel: None,
        }
    }

    pub const fn with_deadline(mut self, deadline: Deadline) -> Self {
        self.deadline = Some(deadline);
        self
    }

    pub const fn with_cancel(mut self, cancel: &'a CancelToken) -> Self {
        self.cancel = Some(cancel);
        self
    }
}

/// One task's answer.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct Completion<T> {
    pub id: TaskId,
    pub label: String,
    /// Rounds this task spent in the queue before it finished, including the finishing one.
    pub rounds: u32,
    pub result: Result<T, IoFault>,
}

impl<T> Completion<T> {
    pub const fn succeeded(&self) -> bool {
        self.result.is_ok()
    }

    /// The fault kind, if the task did not succeed.
    pub fn fault_kind(&self) -> Option<IoFaultKind> {
        match &self.result {
            Ok(_) => None,
            Err(fault) => Some(fault.kind),
        }
    }

    pub fn into_result(self) -> Result<T, IoFault> {
        self.result
    }
}

/// What a run of [`BoundedExecutor::run_until_idle`] did.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct RunReport<T> {
    pub completions: Vec<Completion<T>>,
    pub ticks: u32,
    /// Set when the run stopped with work still queued: either the round budget ran out
    /// (`Busy`, naming the stuck tasks), or a fault ended the run -- including a fault from the
    /// *sleep* path, which is reported as what it is and never relabelled `Busy`.
    pub stop: Option<IoFault>,
    /// Labels still in the queue when the run stopped, in submission order.
    pub stuck: Vec<String>,
}

impl<T> RunReport<T> {
    pub const fn is_idle(&self) -> bool {
        self.stop.is_none()
    }

    /// `Ok(completions)` when the queue drained, otherwise the fault that stopped the run. The
    /// completions gathered before the stop are dropped with the report; inspect them first if the
    /// caller needs them, because a stopped run is not an empty one.
    pub fn into_result(self) -> Result<Vec<Completion<T>>, IoFault> {
        match self.stop {
            None => Ok(self.completions),
            Some(fault) => Err(fault),
        }
    }
}

/// Counters for `caly doctor --io` (`ADR-036 §4` follow-up). Every counter moves at most once per
/// event, and the exits are counted separately so a `Timeout` can never hide inside "failed".
#[derive(Clone, Copy, Debug, Default, Eq, PartialEq)]
pub struct ExecutorMetrics {
    pub submitted: u64,
    pub rejected: u64,
    pub completed: u64,
    /// Tasks that finished with a fault their *own port* returned.
    pub port_faults: u64,
    pub timeouts: u64,
    pub cancellations: u64,
    pub peak_depth: usize,
    pub ticks: u32,
    pub advances: u32,
    /// Rounds that ended with work still queued because nothing became ready in time. A stop caused by
    /// a port fault is **not** counted here: the two answers mean different things to a caller, and one
    /// number for both would make `doctor --io` blind to exactly the difference this file exists to keep.
    pub busy_stops: u64,
}

struct Task<'a, T> {
    id: TaskId,
    label: String,
    deadline: Option<Deadline>,
    cancel: Option<&'a CancelToken>,
    rounds: u32,
    future: BoxFuture<'a, Result<T, IoFault>>,
}

/// Admission + fair advancement for port futures, with an injected clock and no threads.
pub struct BoundedExecutor<'a, T> {
    clock: Option<&'a dyn Clock>,
    limits: ExecutorLimits,
    queue: VecDeque<Task<'a, T>>,
    metrics: ExecutorMetrics,
    next_id: u64,
}

/// Hand-written: a `derive` would need `T: Debug` *and* a `Debug` future, which `Box<dyn Future>`
/// cannot give. What a caller needs when a run goes wrong is the shape of the queue -- capacity,
/// whether time may move, and which labels are still hanging -- so that is what this prints.
impl<T> core::fmt::Debug for BoundedExecutor<'_, T> {
    fn fmt(&self, f: &mut core::fmt::Formatter<'_>) -> core::fmt::Result {
        f.debug_struct("BoundedExecutor")
            .field("capacity", &self.limits.max_tasks)
            .field("polls_per_task", &self.limits.effective_polls_per_task())
            .field("advance", &self.limits.advance)
            .field(
                "clock",
                &if self.clock.is_some() {
                    "injected"
                } else {
                    "none"
                },
            )
            .field("depth", &self.queue.len())
            .field(
                "pending",
                &self
                    .queue
                    .iter()
                    .map(|task| task.label.as_str())
                    .collect::<Vec<_>>(),
            )
            .field("metrics", &self.metrics)
            .finish()
    }
}

impl<'a, T> BoundedExecutor<'a, T> {
    pub fn new(clock: Option<&'a dyn Clock>) -> Result<Self, IoFault> {
        Self::with_limits(clock, ExecutorLimits::default())
    }

    /// Refuses a configuration that cannot do what it says: a zero-capacity queue could never accept
    /// work, and sleeping without a clock has no meaning.
    pub fn with_limits(
        clock: Option<&'a dyn Clock>,
        limits: ExecutorLimits,
    ) -> Result<Self, IoFault> {
        if limits.max_tasks == 0 {
            return Err(IoFault::new(
                IoFaultKind::InvalidInput,
                "max_tasks must be at least 1; a capacity of 0 would refuse every submission, so the \
                 executor could never do the work it was built for",
            ));
        }
        if matches!(limits.advance, Advance::StepMillis(_)) && clock.is_none() {
            return Err(IoFault::new(
                IoFaultKind::InvalidInput,
                format!(
                    "advance={:?} requires an injected clock and none was given: without one there is \
                     nothing to sleep on, and this executor will not read a host clock of its own \
                     (ADR-036 §6bis.1)",
                    limits.advance
                ),
            ));
        }
        Ok(Self {
            clock,
            limits,
            queue: VecDeque::new(),
            metrics: ExecutorMetrics::default(),
            next_id: 0,
        })
    }

    pub const fn capacity(&self) -> usize {
        self.limits.max_tasks
    }

    /// Tasks accepted and not yet finished.
    pub fn depth(&self) -> usize {
        self.queue.len()
    }

    pub fn is_idle(&self) -> bool {
        self.queue.is_empty()
    }

    pub const fn limits(&self) -> &ExecutorLimits {
        &self.limits
    }

    pub const fn metrics(&self) -> ExecutorMetrics {
        self.metrics
    }

    /// Accept `future` under `limits`, or refuse without starting it.
    pub fn submit(
        &mut self,
        label: impl Into<String>,
        limits: TaskLimits<'a>,
        future: BoxFuture<'a, Result<T, IoFault>>,
    ) -> Result<TaskId, IoFault> {
        if self.queue.len() >= self.limits.max_tasks {
            self.metrics.rejected += 1;
            let depth = self.queue.len();
            let capacity = self.limits.max_tasks;
            return Err(IoFault {
                retryable: true,
                transient: true,
                ..IoFault::new(
                    IoFaultKind::Busy,
                    format!(
                        "executor queue is full: {depth} task(s) in flight at capacity {capacity}; \
                         this task was not started"
                    ),
                )
            });
        }
        let id = TaskId(self.next_id);
        self.next_id += 1;
        let task = Task {
            id,
            label: label.into(),
            deadline: limits.deadline,
            cancel: limits.cancel,
            rounds: 0,
            future,
        };
        self.queue.push_back(task);
        self.metrics.submitted += 1;
        if self.queue.len() > self.metrics.peak_depth {
            self.metrics.peak_depth = self.queue.len();
        }
        Ok(id)
    }

    /// One fair round: every task queued at entry gets exactly one [`crate::drive`] with
    /// [`ExecutorLimits::polls_per_task`], in submission order. A task that did not finish goes to the
    /// back of the queue, so a task that always suspends cannot consume the round.
    pub fn tick(&mut self) -> Vec<Completion<T>> {
        let rounds = self.queue.len();
        self.metrics.ticks += 1;
        let budget = self.limits.effective_polls_per_task();
        let mut done = Vec::new();
        for _ in 0..rounds {
            let Some(mut task) = self.queue.pop_front() else {
                break;
            };
            task.rounds += 1;
            let limits = Drive {
                cancel: task.cancel,
                deadline: task.deadline,
                clock: self.clock,
                max_polls: budget,
            };
            let outcome = crate::runtime::drive_pinned(task.future.as_mut(), limits);
            match outcome {
                Ok(result) => done.push(self.finish(task.id, &task.label, task.rounds, result)),
                Err(fault) if fault.kind == IoFaultKind::Busy => {
                    // Nothing became ready inside the budget: the task is still in flight.
                    self.queue.push_back(task);
                }
                Err(fault) => done.push(self.finish(task.id, &task.label, task.rounds, Err(fault))),
            }
        }
        done
    }

    /// Tick until the queue is empty or `max_ticks` rounds have passed, asking the injected clock to
    /// move between unproductive rounds when [`Advance::StepMillis`] allows it.
    pub fn run_until_idle(&mut self, max_ticks: u32) -> RunReport<T> {
        let mut completions: Vec<Completion<T>> = Vec::new();
        let mut ticks = 0u32;
        loop {
            if self.queue.is_empty() {
                break;
            }
            if ticks >= max_ticks {
                let stuck = self.stuck_labels();
                let fault = self.stopped_fault(ticks);
                self.metrics.busy_stops += 1;
                return RunReport {
                    completions,
                    ticks,
                    stop: Some(fault),
                    stuck,
                };
            }
            ticks += 1;
            let before = completions.len();
            completions.extend(self.tick());
            if completions.len() > before || self.queue.is_empty() {
                continue;
            }
            if let Advance::StepMillis(step) = self.limits.advance {
                let Some(clock) = self.clock else {
                    continue;
                };
                let target = Monotonic {
                    ticks_millis: clock.mono().ticks_millis.saturating_add(step),
                };
                let mut sleeping = clock.sleep_until(target);
                match crate::runtime::drive(&mut sleeping, Drive::immediate()) {
                    Ok(Ok(())) => self.metrics.advances += 1,
                    Ok(Err(fault)) | Err(fault) => {
                        let stuck = self.stuck_labels();
                        return RunReport {
                            completions,
                            ticks,
                            stop: Some(fault),
                            stuck,
                        };
                    }
                }
            }
        }
        RunReport {
            completions,
            ticks,
            stop: None,
            stuck: Vec::new(),
        }
    }

    fn stuck_labels(&self) -> Vec<String> {
        self.queue.iter().map(|task| task.label.clone()).collect()
    }

    fn stopped_fault(&self, ticks: u32) -> IoFault {
        let labels: Vec<&str> = self.queue.iter().map(|task| task.label.as_str()).collect();
        let advance = match self.limits.advance {
            Advance::None => "none".to_owned(),
            Advance::StepMillis(step) => format!("{step}ms"),
        };
        IoFault {
            retryable: true,
            transient: true,
            ..IoFault::new(
                IoFaultKind::Busy,
                format!(
                    "executor still had {} task(s) pending after {} tick(s) (budget {} poll(s) per \
                     task per tick; advance={}, clock={}, stuck: {})",
                    self.queue.len(),
                    ticks,
                    self.limits.effective_polls_per_task(),
                    advance,
                    if self.clock.is_some() { "yes" } else { "no" },
                    labels.join(", ")
                ),
            )
        }
    }

    /// Record the exit and build the completion. The counters are mutually exclusive on purpose: a
    /// run whose numbers add up is the cheapest way for a caller to see that nothing was double-counted.
    fn finish(
        &mut self,
        id: TaskId,
        label: &str,
        rounds: u32,
        result: Result<T, IoFault>,
    ) -> Completion<T> {
        match &result {
            Ok(_) => self.metrics.completed += 1,
            Err(fault) => match fault.kind {
                IoFaultKind::Timeout => self.metrics.timeouts += 1,
                IoFaultKind::Cancelled => self.metrics.cancellations += 1,
                _ => self.metrics.port_faults += 1,
            },
        }
        Completion {
            id,
            label: label.to_owned(),
            rounds,
            result,
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::Timestamp;
    use std::future::Future;
    use std::pin::Pin;
    use std::sync::atomic::{AtomicBool, AtomicU64, Ordering};
    use std::sync::Arc;
    use std::task::{Context, Poll};

    /// The only clock the fixtures have: a counter that moves when something *asks* it to. Real time
    /// would make every bound below depend on the machine, and `ADR-022` forbids exactly that.
    #[derive(Clone, Default)]
    struct World(Arc<AtomicU64>);

    impl World {
        fn at(&self) -> u64 {
            self.0.load(Ordering::SeqCst)
        }

        fn advance_to(&self, target: u64) {
            self.0.fetch_max(target, Ordering::SeqCst);
        }
    }

    /// `sleep_until` moves the world rather than waiting for it, like `SimClock`.
    struct WorldClock(World);

    impl Clock for WorldClock {
        fn now(&self) -> Timestamp {
            Timestamp {
                unix_millis: self.0.at() as i64,
            }
        }

        fn mono(&self) -> Monotonic {
            Monotonic {
                ticks_millis: self.0.at(),
            }
        }

        fn sleep_until<'b>(&'b self, at: Monotonic) -> BoxFuture<'b, Result<(), IoFault>> {
            let world = self.0.clone();
            Box::pin(async move {
                world.advance_to(at.ticks_millis);
                Ok(())
            })
        }
    }

    /// A clock whose sleep itself faults: the run must report *that* fault, not a generic `Busy`.
    struct SleepFaults;

    impl Clock for SleepFaults {
        fn now(&self) -> Timestamp {
            Timestamp { unix_millis: 0 }
        }

        fn mono(&self) -> Monotonic {
            Monotonic { ticks_millis: 0 }
        }

        fn sleep_until<'b>(&'b self, _at: Monotonic) -> BoxFuture<'b, Result<(), IoFault>> {
            Box::pin(async {
                Err(IoFault::new(
                    IoFaultKind::Unavailable,
                    "the sleep port refused",
                ))
            })
        }
    }

    /// Ready on the `left + 1`-th poll, so "how many rounds did it take" is a thing a test can count.
    struct ReadyAfter {
        left: u32,
        value: u32,
    }

    impl Future for ReadyAfter {
        type Output = Result<u32, IoFault>;

        fn poll(mut self: Pin<&mut Self>, _cx: &mut Context<'_>) -> Poll<Self::Output> {
            if self.left == 0 {
                Poll::Ready(Ok(self.value))
            } else {
                self.left -= 1;
                Poll::Pending
            }
        }
    }

    /// Ready only once the world's time reaches `at`.
    struct ReadyWhenTime {
        world: World,
        at: u64,
        value: u32,
    }

    impl Future for ReadyWhenTime {
        type Output = Result<u32, IoFault>;

        fn poll(self: Pin<&mut Self>, _cx: &mut Context<'_>) -> Poll<Self::Output> {
            let this = &*self;
            if this.world.at() >= this.at {
                Poll::Ready(Ok(this.value))
            } else {
                Poll::Pending
            }
        }
    }

    /// Never ready, and it says so on both axes a test cares about: how often it was polled, and
    /// whether it was dropped while still suspended.
    struct SuspendsForever {
        polls: Arc<AtomicU64>,
        dropped: Arc<AtomicBool>,
    }

    impl SuspendsForever {
        fn pair() -> (Self, Arc<AtomicU64>, Arc<AtomicBool>) {
            let polls = Arc::new(AtomicU64::new(0));
            let dropped = Arc::new(AtomicBool::new(false));
            (
                Self {
                    polls: Arc::clone(&polls),
                    dropped: Arc::clone(&dropped),
                },
                polls,
                dropped,
            )
        }
    }

    impl Future for SuspendsForever {
        type Output = Result<u32, IoFault>;

        fn poll(self: Pin<&mut Self>, _cx: &mut Context<'_>) -> Poll<Self::Output> {
            self.polls.fetch_add(1, Ordering::SeqCst);
            Poll::Pending
        }
    }

    impl Drop for SuspendsForever {
        fn drop(&mut self) {
            self.dropped.store(true, Ordering::SeqCst);
        }
    }

    /// Fails on the first poll, and counts them, so a retry cannot hide.
    struct FaultOnce {
        polls: Arc<AtomicU64>,
    }

    impl Future for FaultOnce {
        type Output = Result<u32, IoFault>;

        fn poll(self: Pin<&mut Self>, _cx: &mut Context<'_>) -> Poll<Self::Output> {
            self.polls.fetch_add(1, Ordering::SeqCst);
            Poll::Ready(Err(IoFault::new(
                IoFaultKind::Unavailable,
                "the port said no",
            )))
        }
    }

    fn ready(value: u32) -> BoxFuture<'static, Result<u32, IoFault>> {
        Box::pin(async move { Ok(value) })
    }

    fn executor(clock: Option<&dyn Clock>, max_tasks: usize) -> BoundedExecutor<'_, u32> {
        BoundedExecutor::with_limits(
            clock,
            ExecutorLimits::bounded(max_tasks).with_polls_per_task(1),
        )
        .expect("these limits are valid by construction")
    }

    #[test]
    fn a_full_queue_is_refused_as_busy_naming_both_numbers() {
        let mut ex = executor(None, 2);
        ex.submit("a", TaskLimits::none(), ready(1)).unwrap();
        ex.submit("b", TaskLimits::none(), ready(2)).unwrap();
        let refused = ex
            .submit("c", TaskLimits::none(), ready(3))
            .expect_err("capacity is 2");
        assert_eq!(refused.kind, IoFaultKind::Busy);
        assert!(
            refused.retryable && refused.transient,
            "a refusal at admission is congestion, not a lost request: {refused:?}"
        );
        assert!(
            refused
                .summary
                .contains("2 task(s) in flight at capacity 2"),
            "{}",
            refused.summary
        );
        assert!(
            refused.summary.contains("was not started"),
            "{}",
            refused.summary
        );
        assert_eq!(ex.depth(), 2, "the refusal added nothing to the queue");
        assert_eq!(ex.metrics().rejected, 1);
        assert_eq!(ex.metrics().submitted, 2);
    }

    #[test]
    fn a_refusal_leaves_nothing_behind_not_even_an_id() {
        let mut ex = executor(None, 2);
        let a = ex.submit("a", TaskLimits::none(), ready(1)).unwrap();
        let b = ex.submit("b", TaskLimits::none(), ready(2)).unwrap();
        assert!(ex.submit("c", TaskLimits::none(), ready(3)).is_err());
        let done = ex.tick();
        assert_eq!(
            done.iter().map(|c| c.id).collect::<Vec<_>>(),
            vec![a, b],
            "the two accepted tasks must be untouched by the refusal"
        );
        assert_eq!(
            done.iter().map(|c| c.result.clone()).collect::<Vec<_>>(),
            vec![Ok(1), Ok(2)]
        );
        let after_room = ex.submit("d", TaskLimits::none(), ready(4)).unwrap();
        assert_eq!(
            after_room,
            TaskId(2),
            "a refusal must not consume an id, or a caller correlating by id sees a hole"
        );
    }

    #[test]
    fn a_zero_capacity_executor_is_refused_at_construction() {
        let err = BoundedExecutor::<u32>::with_limits(None, ExecutorLimits::bounded(0))
            .expect_err("0 would refuse everything");
        assert_eq!(err.kind, IoFaultKind::InvalidInput);
        assert!(
            err.summary.contains("max_tasks must be at least 1"),
            "{err:?}"
        );
    }

    #[test]
    fn asking_to_sleep_without_a_clock_is_refused_at_construction() {
        let err = BoundedExecutor::<u32>::with_limits(
            None,
            ExecutorLimits::default().with_advance(Advance::StepMillis(10)),
        )
        .expect_err("there is no clock to sleep on");
        assert_eq!(err.kind, IoFaultKind::InvalidInput);
        assert!(
            err.summary.contains("requires an injected clock"),
            "{}",
            err.summary
        );
        assert!(err.summary.contains("host clock"), "{err:?}");
    }

    #[test]
    fn one_round_gives_every_task_the_same_budget_in_submission_order() {
        // Three tasks that each need three polls. If the executor drove greedily, task `a` would be the
        // only answer of round one and the other two would have starved; fairness is observable as
        // "nothing finished in rounds 1 and 2, everything finished in round 3, in order".
        let mut ex = executor(None, 8);
        for (label, value) in [("a", 1u32), ("b", 2), ("c", 3)] {
            ex.submit(
                label,
                TaskLimits::none(),
                Box::pin(ReadyAfter { left: 2, value }),
            )
            .unwrap();
        }
        assert!(ex.tick().is_empty(), "one poll each is not enough yet");
        assert_eq!(ex.depth(), 3);
        assert!(ex.tick().is_empty());
        let done = ex.tick();
        assert_eq!(done.len(), 3);
        assert_eq!(
            done.iter().map(|c| c.label.as_str()).collect::<Vec<_>>(),
            vec!["a", "b", "c"]
        );
        assert!(
            done.iter().all(|c| c.rounds == 3),
            "every task was polled once per round: {done:?}"
        );
        assert_eq!(
            ex.metrics().ticks,
            3,
            "a round is a round, driven by hand or by a run"
        );
    }

    #[test]
    fn a_task_waiting_on_time_finishes_because_the_executor_moved_it() {
        let world = World::default();
        let clock = WorldClock(world.clone());
        let mut ex = BoundedExecutor::with_limits(
            Some(&clock),
            ExecutorLimits::bounded(4)
                .with_polls_per_task(1)
                .with_advance(Advance::StepMillis(10)),
        )
        .unwrap();
        ex.submit(
            "waits",
            TaskLimits::none(),
            Box::pin(ReadyWhenTime {
                world: world.clone(),
                at: 30,
                value: 7,
            }),
        )
        .unwrap();
        let report = ex.run_until_idle(8);
        assert!(report.is_idle(), "{:?}", report.stop);
        assert_eq!(report.completions[0].result, Ok(7));
        assert_eq!(world.at(), 30, "time moved exactly three steps of 10ms");
        assert_eq!(ex.metrics().advances, 3);
        assert_eq!(
            ex.metrics().ticks,
            4,
            "three unproductive rounds plus the one that finished"
        );
    }

    #[test]
    fn a_fault_from_the_sleep_port_ends_the_run_as_that_not_as_busy() {
        // `Advance::StepMillis` puts a *port call* inside the run loop, so the loop has two ways to
        // fail and they must not be conflated: "the world refused to move" is the port's own
        // `Unavailable`, not the executor's `Busy`, and it ends the run where it happened.
        let (forever, _polls, _dropped) = SuspendsForever::pair();
        let clock = SleepFaults;
        let mut ex = BoundedExecutor::with_limits(
            Some(&clock),
            ExecutorLimits::bounded(2)
                .with_polls_per_task(1)
                .with_advance(Advance::StepMillis(5)),
        )
        .unwrap();
        ex.submit("stuck", TaskLimits::none(), Box::pin(forever))
            .unwrap();
        let report = ex.run_until_idle(8);
        let stop = report.stop.expect("the sleep port refused");
        assert_eq!(stop.kind, IoFaultKind::Unavailable, "{stop:?}");
        assert_eq!(
            report.ticks, 1,
            "the run stops on the fault, it does not keep trying"
        );
        assert_eq!(report.stuck, vec!["stuck".to_owned()]);
        assert_eq!(
            ex.metrics().advances,
            0,
            "a refused sleep is not an advance"
        );
        assert_eq!(
            ex.metrics().busy_stops,
            0,
            "this stop came from a port, so it may not be counted as congestion"
        );
    }

    #[test]
    fn a_task_that_never_becomes_ready_ends_the_run_busy_and_names_it() {
        let (forever, polls, _dropped) = SuspendsForever::pair();
        let mut ex = executor(None, 4);
        ex.submit("stuck", TaskLimits::none(), Box::pin(forever))
            .unwrap();
        let report = ex.run_until_idle(2);
        assert!(!report.is_idle());
        let stop = report
            .stop
            .clone()
            .expect("the run must say why it stopped");
        assert_eq!(stop.kind, IoFaultKind::Busy);
        assert!(stop.retryable && stop.transient, "{stop:?}");
        assert!(stop.summary.contains("stuck"), "{}", stop.summary);
        assert!(
            stop.summary.contains("advance=none, clock=no"),
            "the text has to say which limits were in place: {}",
            stop.summary
        );
        assert_eq!(report.stuck, vec!["stuck".to_owned()]);
        assert_eq!(report.ticks, 2);
        assert_eq!(polls.load(Ordering::SeqCst), 2, "one poll per round, twice");
        assert_eq!(
            ex.depth(),
            1,
            "the task is still in flight, not silently finished"
        );
        assert_eq!(ex.metrics().completed, 0);
        assert_eq!(ex.metrics().port_faults, 0);
    }

    #[test]
    fn an_expired_deadline_times_the_task_out_and_drops_its_future() {
        let world = World::default();
        let clock = WorldClock(world.clone());
        let (forever, polls, dropped) = SuspendsForever::pair();
        let mut ex = BoundedExecutor::with_limits(
            Some(&clock),
            ExecutorLimits::bounded(2)
                .with_polls_per_task(1)
                .with_advance(Advance::StepMillis(25)),
        )
        .unwrap();
        ex.submit(
            "slow",
            TaskLimits::none().with_deadline(Deadline(50)),
            Box::pin(forever),
        )
        .unwrap();
        let report = ex.run_until_idle(10);
        assert!(report.is_idle(), "a timed-out task is finished, not stuck");
        assert_eq!(
            report.completions[0].fault_kind(),
            Some(IoFaultKind::Timeout)
        );
        assert_eq!(
            polls.load(Ordering::SeqCst),
            2,
            "the round where the deadline expired may not poll again"
        );
        assert!(
            dropped.load(Ordering::SeqCst),
            "ADR-036 §4: the future is dropped mid-flight, and its host work is left to the ports"
        );
        assert_eq!(world.at(), 50);
        assert_eq!(ex.metrics().timeouts, 1);
        assert_eq!(ex.metrics().completed, 0);
    }

    #[test]
    fn a_deadline_without_a_clock_is_never_called_a_timeout() {
        let (forever, _polls, _dropped) = SuspendsForever::pair();
        let mut ex = executor(None, 4);
        ex.submit(
            "slow",
            TaskLimits::none().with_deadline(Deadline(1)),
            Box::pin(forever),
        )
        .unwrap();
        let report = ex.run_until_idle(1);
        let stop = report
            .stop
            .clone()
            .expect("one tick cannot finish a never-ready task");
        assert_eq!(
            stop.kind,
            IoFaultKind::Busy,
            "claiming a timeout with no clock would invent a fact: {stop:?}"
        );
        assert!(stop.summary.contains("clock=no"), "{}", stop.summary);
        assert_eq!(ex.metrics().timeouts, 0);
        assert_eq!(ex.metrics().cancellations, 0);
    }

    #[test]
    fn a_cancelled_parent_cancels_a_child_task_before_it_runs() {
        let parent = CancelToken::new();
        let child = parent.child();
        let mut ex = executor(None, 4);
        ex.submit("child", TaskLimits::none().with_cancel(&child), ready(5))
            .unwrap();
        parent.cancel();
        let report = ex.run_until_idle(1);
        let only = &report.completions[0];
        assert_eq!(only.fault_kind(), Some(IoFaultKind::Cancelled));
        assert_eq!(ex.metrics().cancellations, 1);
        assert_eq!(
            ex.metrics().completed,
            0,
            "a cancelled task must not be run and then thrown away"
        );
        assert!(child.is_cancelled());
        assert!(parent.is_cancelled());
    }

    #[test]
    fn a_port_fault_is_handed_to_the_caller_once_and_not_retried() {
        let polls = Arc::new(AtomicU64::new(0));
        let mut ex = executor(None, 4);
        ex.submit(
            "port",
            TaskLimits::none(),
            Box::pin(FaultOnce {
                polls: Arc::clone(&polls),
            }),
        )
        .unwrap();
        let report = ex.run_until_idle(4);
        assert!(report.is_idle(), "a fault is an answer, not a stuck run");
        assert_eq!(
            report.completions[0].fault_kind(),
            Some(IoFaultKind::Unavailable)
        );
        assert_eq!(
            polls.load(Ordering::SeqCst),
            1,
            "retry policy belongs to the caller (OVERLOAD_AND_RETRY_MODEL §4)"
        );
        assert_eq!(ex.metrics().port_faults, 1);
        assert_eq!(ex.metrics().ticks, 1);
    }

    #[test]
    fn the_four_exits_are_counted_apart_and_add_up() {
        let world = World::default();
        let clock = WorldClock(world.clone());
        // Declared before the executor on purpose: the queue holds a borrow of the token, so the
        // token has to outlive the executor, and Rust checks the drop order rather than trusting me
        // to remember it.
        let token = CancelToken::pre_cancelled();
        let mut ex = BoundedExecutor::with_limits(
            Some(&clock),
            ExecutorLimits::bounded(4).with_polls_per_task(1),
        )
        .unwrap();
        let (forever, _polls, _dropped) = SuspendsForever::pair();
        let ids = vec![
            ex.submit("ok", TaskLimits::none(), ready(9)).unwrap(),
            ex.submit(
                "cancelled",
                TaskLimits::none().with_cancel(&token),
                ready(9),
            )
            .unwrap(),
            ex.submit(
                "fault",
                TaskLimits::none(),
                Box::pin(FaultOnce {
                    polls: Arc::new(AtomicU64::new(0)),
                }),
            )
            .unwrap(),
            ex.submit(
                "late",
                TaskLimits::none().with_deadline(Deadline(0)),
                Box::pin(forever),
            )
            .unwrap(),
        ];
        assert!(ex.submit("overflow", TaskLimits::none(), ready(1)).is_err());
        let report = ex.run_until_idle(1);
        assert_eq!(
            report.completions.iter().map(|c| c.id).collect::<Vec<_>>(),
            ids,
            "one round answers in submission order"
        );
        let kinds = report
            .completions
            .iter()
            .map(|c| c.fault_kind())
            .collect::<Vec<_>>();
        assert_eq!(
            kinds,
            vec![
                None,
                Some(IoFaultKind::Cancelled),
                Some(IoFaultKind::Unavailable),
                Some(IoFaultKind::Timeout)
            ]
        );
        let metrics = ex.metrics();
        assert_eq!(
            (
                metrics.submitted,
                metrics.completed,
                metrics.cancellations,
                metrics.port_faults,
                metrics.timeouts,
                metrics.rejected
            ),
            (4, 1, 1, 1, 1, 1)
        );
        assert_eq!(
            metrics.submitted,
            metrics.completed + metrics.cancellations + metrics.port_faults + metrics.timeouts,
            "every accepted task leaves through exactly one counter"
        );
        assert_eq!(metrics.peak_depth, 4);
    }
}
