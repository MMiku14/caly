#![forbid(unsafe_code)]

pub mod budget;
pub mod contract;
pub mod executor;
pub mod fault;
pub mod port;
pub mod runtime;
pub mod vpath;

pub use budget::*;
pub use contract::*;
pub use executor::{
    Advance, BoundedExecutor, Completion, ExecutorLimits, ExecutorMetrics, RunReport, TaskId,
    TaskLimits, DEFAULT_MAX_TASKS, DEFAULT_POLLS_PER_TASK, DEFAULT_STEP_MILLIS,
};
pub use fault::*;
pub use port::*;
pub use runtime::{block_on_ready, drive, drive_pinned, Deadline, Drive};
pub use vpath::*;

// The unified `Ctx` type trio is part of every port signature, so the port crate re-exports it:
// a backend should not have to know which crate happens to own `RequestContext`.
pub use caly_common::{Actor, CancelToken, IoBudget, RequestContext, TraceId};
