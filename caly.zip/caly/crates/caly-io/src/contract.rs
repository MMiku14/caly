//! Port contract suite (`RFC-0006-io-port-iofault.md §15`).
//!
//! The RFC says `caly-io-std` and `caly-io-sim` **SHOULD pass the same contract tests**. That
//! requirement had no carrier in code: the two implementations were written independently, and
//! nothing stopped them from disagreeing about what `Fs` even means. A divergent simulator is
//! worse than none, because `ADR-022` makes the simulator the release gate — the gate would then
//! be validating a world the production port does not implement.
//!
//! So the suite lives next to the trait definitions, and both crates run it against their own
//! implementation. Checks return a list of violations instead of panicking, so a backend reports
//! every failure at once.
//!
//! Coverage against the RFC's seven items:
//!
//! | item | status |
//! |---|---|
//! | 1 `VPath` rejects escaping paths | [`vpath_escape_violations`] |
//! | 2 `Fs.write_atomic` durability + visibility | [`fs_contract_violations`] |
//! | 3 `Http` body limit | `RFC-0006 §5.3`'s byte ceiling is honoured by the only `Http` that exists ([`crate::byte_ceiling`], checked in `caly-io-sim`'s suite); `caly-io-std` implements no `Http`, so the cross-backend claim still cannot be made (see `docs/history/ONBOARDING_NOTES.md §3.3`) |
//! | 4 `Proc` shell-free spawn | [`proc_spawn_contract_violations`] + [`proc_supervision_contract_violations`] (`ADR-042`/`ADR-043`: the shared rules are the empty-program refusal, the honest handle, and the four supervision answers — fresh means not-exited, stop reports how it left, exits replay monotonically, ghost handles are NotFound by name; shell-freedom itself is structural — `StdProc` execs the program directly — and is judged by the std-side tests that watch a real child) |
//! | 5 `Clock` monotonicity | [`clock_contract_violations`] |
//! | 6 reproducible `Rand` | covered in `caly-io-sim`'s own suite (a std `Rand` does not exist) |
//! | 7 `Keyring` unsupported vs unavailable | [`fault_kind_vocabulary_is_distinguishable`] |
//!
//! Two more checks were added with `ADR-035` (directory listing and mtimes). They are not RFC items —
//! they are the port capabilities whose absence made `caly-storage` keep a second index and estimate
//! object ages — and each is where the two backends were most likely to disagree:
//!
//! | addition | carrier |
//! |---|---|
//! | `list` is sorted, capped, one level deep, and answers "empty" differently from "missing" | [`fs_listing_violations`] |
//! | `Meta::modified_at_unix_ms` is either consistently known or consistently unknown, and never goes backwards | [`fs_mtime_violations`] |
//! | `Ctx::io_budget.max_bytes` is enforced by the port, before the bytes move, and says which bound bit | [`fs_byte_budget_violations`] |

use std::future::Future;

use crate::{
    ByteCap, ChildExit, ChildHandle, Clock, Durability, FetchResp, FileLock, Fs, IoContext,
    IoFault, IoFaultKind, ListCap, Monotonic, Timestamp, VPath,
};

/// Re-exported so the contract suite, the durable storage backend and the engine all share one
/// driver. The rationale for "must be ready on first poll" lives in [`crate::runtime`].
pub use crate::runtime::block_on_ready;

/// Run a port call to completion and flatten `suspension error` + `port error` into a message.
fn value<T, F>(future: F) -> Result<T, String>
where
    F: Future<Output = Result<T, IoFault>>,
{
    match block_on_ready(future) {
        Ok(Ok(inner)) => Ok(inner),
        Ok(Err(fault)) => Err(fault_text(&fault)),
        Err(message) => Err(message),
    }
}

/// Same, but keep the structured fault so a check can assert on its `kind`.
fn fault<T, F>(future: F) -> Result<IoFault, String>
where
    F: Future<Output = Result<T, IoFault>>,
{
    match block_on_ready(future) {
        Ok(Ok(_)) => Err("expected an error, but the call succeeded".to_owned()),
        Ok(Err(inner)) => Ok(inner),
        Err(message) => Err(message),
    }
}

fn fault_text(fault: &IoFault) -> String {
    format!("{:?}: {}", fault.kind, fault.summary)
}

/// Contract item 1: `VPath` rejects escaping paths.
pub fn vpath_escape_violations() -> Vec<String> {
    let mut violations = Vec::new();
    for candidate in [
        "",
        "/absolute/passwd",
        "../escape",
        "a/../../b",
        "./leading",
        "trailing/",
        "double//slash",
    ] {
        if let Ok(path) = VPath::try_from_str(candidate) {
            violations.push(format!(
                "VPath::try_from_str({candidate:?}) was accepted as {:?}",
                path.as_relative_path()
            ));
        }
    }

    // A plain relative path must still work, otherwise "rejects escapes" is just "rejects all".
    if VPath::try_from_str("objects").is_err() {
        violations.push("VPath::try_from_str(\"objects\") must be accepted".to_owned());
    }
    if let Ok(path) = VPath::try_from_str("a").and_then(|base| base.join("../b")) {
        violations.push(format!(
            "join(\"../b\") escaped to {:?}",
            path.as_relative_path()
        ));
    }
    violations
}

/// Contract item 4 (`RFC-0006 §15`): one spawn suite, two backends. The simulator's idea of
/// "a program the world can run" is a label; `StdProc`'s is a real binary — so the scenario is
/// expressed as closures, exactly like the fetch suite. The shared rules are the answers every
/// `Proc` must give: an empty program is `InvalidInput` that names it (a port must not guess a
/// default binary), and a successful spawn returns a handle with a live pid and a non-empty
/// instance nonce. What stays backend-side is everything a real child can prove on a real host
/// (cwd, env, the named `NotFound`): `caly-io-std/tests/proc_std.rs`.
pub fn proc_spawn_contract_violations(
    spawn_empty: &dyn Fn() -> Result<ChildHandle, IoFault>,
    spawn_noop: &dyn Fn() -> Result<ChildHandle, IoFault>,
) -> Vec<String> {
    let mut violations = Vec::new();
    match spawn_empty() {
        Err(fault) if fault.kind == IoFaultKind::InvalidInput => {
            if !fault.summary.contains("program") {
                violations.push(format!(
                    "an empty-program refusal names the program, got: {}",
                    fault.summary
                ));
            }
        }
        Err(other) => violations.push(format!(
            "an empty program is InvalidInput, not {:?}",
            other.kind
        )),
        Ok(handle) => violations.push(format!(
            "an empty program is a refusal, not a spawn of pid {}",
            handle.pid
        )),
    }
    match spawn_noop() {
        Ok(handle) => {
            if handle.pid < 1 {
                violations.push(format!("a live child has a pid >= 1, got {}", handle.pid));
            }
            if handle.instance_nonce.trim().is_empty() {
                violations.push("the instance nonce is not an empty string".to_owned());
            }
        }
        Err(fault) => violations.push(format!("spawn of a no-op program: {}", fault.summary)),
    }
    violations
}

/// `ADR-043`'s supervision surface: one suite, two backends. The shared rules are the four
/// answers every `Proc` must give about a child it spawned: a fresh child has not exited
/// (`try_wait` is `None`, never a guess), `stop` returns **how it left** (the number, and
/// whether the child chose it or a signal did), the answers are **monotonic once exited**
/// (a port that forgets an exit makes "is it gone?" unanswerable exactly when it matters),
/// and a handle this port never handed out is `NotFound` naming the nonce — on both the
/// wait and the stop path, because a caller retries differently for each.
pub fn proc_supervision_contract_violations(
    spawn_noop: &dyn Fn() -> Result<ChildHandle, IoFault>,
    try_wait: &dyn Fn(&ChildHandle) -> Result<Option<ChildExit>, IoFault>,
    stop: &dyn Fn(&ChildHandle, u64) -> Result<ChildExit, IoFault>,
) -> Vec<String> {
    let mut violations = Vec::new();
    let handle = match spawn_noop() {
        Ok(handle) => handle,
        Err(fault) => return vec![format!("spawn of a no-op program: {}", fault.summary)],
    };
    match try_wait(&handle) {
        Ok(None) => {}
        Ok(Some(exit)) => violations.push(format!(
            "a freshly spawned child has not exited; try_wait guessed {exit:?}"
        )),
        Err(fault) => violations.push(format!("try_wait on a live child: {}", fault.summary)),
    }
    let exit = match stop(&handle, 200) {
        Ok(exit) => exit,
        Err(fault) => {
            violations.push(format!("stop of a live child: {}", fault.summary));
            return violations;
        }
    };
    match try_wait(&handle) {
        Ok(seen) if seen == Some(exit) => {}
        other => violations.push(format!(
            "try_wait after stop must replay the same exit ({exit:?}), got {other:?}"
        )),
    }
    match stop(&handle, 200) {
        Ok(seen) if seen == exit => {}
        Ok(other) => violations.push(format!(
            "stop is idempotent once exited: the same exit ({exit:?}) replays, got {other:?}"
        )),
        Err(fault) => violations.push(format!("stop after exit: {}", fault.summary)),
    }
    let ghost = ChildHandle {
        pid: 999_999,
        instance_nonce: "child-999999".to_owned(),
    };
    for (what, answer) in [
        ("try_wait", try_wait(&ghost).err()),
        ("stop", stop(&ghost, 0).err()),
    ] {
        match answer {
            Some(fault) if fault.kind == IoFaultKind::NotFound => {
                if !fault.summary.contains("child-999999") {
                    violations.push(format!(
                        "a ghost handle's {what} refusal names the nonce: {}",
                        fault.summary
                    ));
                }
            }
            Some(fault) => violations.push(format!(
                "a ghost handle's {what} is NotFound, not {:?} ({})",
                fault.kind, fault.summary
            )),
            None => violations.push(format!(
                "a ghost handle's {what} is a refusal; answering it would invent a child"
            )),
        }
    }
    violations
}

/// Contract items 2 and the shared semantics of every `Fs` operation.
/// `RFC-0006 §15`: one fetch suite, two backends. The simulator is scripted and `StdHttp`
/// talks to a real socket, so the scenario is expressed as a closure: "fetch `url`, whose body
/// is exactly 2 KiB, with this `max_body_bytes` and this optional byte budget". The shared
/// rules are the four answers every `Http` must give: the label is the caller's own name
/// (`ADR-040`), the tighter of budget and bound bites, the refusal says which, and an
/// unbudgeted context does not refuse a body it never bounded.
pub fn http_fetch_contract_violations(
    url: &str,
    fetch: &dyn Fn(u64, Option<u64>) -> Result<FetchResp, IoFault>,
) -> Vec<String> {
    let mut violations = Vec::new();
    match fetch(65_536, None) {
        Ok(resp) if resp.status == 200 => {
            // `ADR-040`: the prefix names the *port* ("this came from Http"), not a URL scheme.
            let expected = format!("http:{url}");
            if resp.body.label != expected {
                violations.push(format!(
                    "fetch label must be {expected:?} (ADR-040: the caller's own name), got {:?}",
                    resp.body.label
                ));
            }
            if resp.body.bytes.len() != 2_048 || resp.body.bytes.iter().any(|byte| *byte != b'z') {
                violations.push(format!(
                    "fetch must return the complete 2 KiB body, got {} bytes",
                    resp.body.bytes.len()
                ));
            }
        }
        Ok(other) => violations.push(format!(
            "fetch of a 2 KiB body under a generous bound must be 200, got {}",
            other.status
        )),
        Err(fault) => violations.push(format!("fetch of a 2 KiB body: {}", fault.summary)),
    }
    match fetch(65_536, Some(1_024)) {
        Err(fault) if fault.kind == IoFaultKind::CapacityExceeded => {
            if !fault.summary.contains("io_budget.max_bytes = 1024") {
                violations.push(format!(
                    "the budget is what bit, and the refusal must say so: {}",
                    fault.summary
                ));
            }
        }
        Err(other) => violations.push(format!(
            "a 2 KiB body over a 1 KiB budget must be CapacityExceeded, got {:?}",
            other.kind
        )),
        Ok(_) => {
            violations.push("a body over the budget is a refusal, not a truncation".to_owned())
        }
    }
    match fetch(512, None) {
        Err(fault) if fault.kind == IoFaultKind::CapacityExceeded => {
            if !fault.summary.contains("byte cap") || fault.summary.contains("io_budget") {
                violations.push(format!(
                    "the request's own cap is what bit, and the refusal must say only that: {}",
                    fault.summary
                ));
            }
        }
        Err(other) => violations.push(format!(
            "a 2 KiB body under a 512 byte cap must be CapacityExceeded, got {:?}",
            other.kind
        )),
        Ok(_) => violations.push("a body over the request's own cap is a refusal".to_owned()),
    }
    match fetch(65_536, None) {
        Ok(_) => {}
        Err(fault) => violations.push(format!(
            "an unbudgeted context must not refuse a body it never bounded: {}",
            fault.summary
        )),
    }
    violations
}

pub fn fs_contract_violations(fs: &dyn Fs, ctx: &IoContext) -> Vec<String> {
    let mut violations = Vec::new();
    let dir = VPath::try_from_str("contract").expect("static path");
    let target = dir.join("payload").expect("static child");
    let moved = dir.join("moved").expect("static child");
    let absent = dir.join("definitely-absent").expect("static child");

    // -- write_atomic must be readable back at every promised durability tier --
    let mut payload_len = 0usize;
    for durability in [
        Durability::D0,
        Durability::D1,
        Durability::D2,
        Durability::D3,
    ] {
        let payload = format!("durability-{durability:?}").into_bytes();
        payload_len = payload.len();
        if let Err(text) = value(fs.write_atomic(&target, payload.clone(), durability, ctx)) {
            violations.push(format!("write_atomic({durability:?}) failed: {text}"));
            continue;
        }
        match value(fs.read(&target, ByteCap(1024), ctx)) {
            Ok(bytes) if bytes == payload => {}
            Ok(bytes) => violations.push(format!(
                "{durability:?}: read back {} bytes, expected {}",
                bytes.len(),
                payload.len()
            )),
            Err(text) => {
                violations.push(format!("{durability:?}: read after write failed: {text}"))
            }
        }
    }

    // -- stat: length for a present file, None for an absent one --
    match value(fs.stat(&target, ctx)) {
        Ok(Some(meta)) => {
            if !meta.is_file || meta.is_dir {
                violations.push(format!(
                    "stat after write must report a plain file, got {meta:?}"
                ));
            }
            if meta.len as usize != payload_len {
                violations.push(format!(
                    "stat reported len {}, expected {payload_len}",
                    meta.len
                ));
            }
        }
        Ok(None) => {
            violations.push("stat of a file that was just written returned None".to_owned())
        }
        Err(text) => violations.push(format!("stat failed: {text}")),
    }
    match value(fs.stat(&absent, ctx)) {
        Ok(None) => {}
        Ok(Some(meta)) => violations.push(format!(
            "stat of an absent path returned {meta:?}, expected None"
        )),
        Err(text) => violations.push(format!(
            "stat of an absent path must be Ok(None), got Err({text})"
        )),
    }

    // -- stat_many: one call answers the same facts as N stat calls, in input order
    //    (`ADR-054 §2.1`) --
    // The one-by-one answer this batch must reproduce; a failure here is already reported
    // by the stat item above, so `None` (the absent answer) is a fine comparison base.
    let single = value(fs.stat(&target, ctx)).ok().flatten();
    let batch = [target.clone(), absent.clone(), target.clone()];
    match value(fs.stat_many(&batch, ctx)) {
        Ok(metas) => {
            if metas.len() != 3 {
                violations.push(format!(
                    "stat_many returned {} entries for 3 paths",
                    metas.len()
                ));
            } else {
                if metas[0] != single {
                    violations.push(format!(
                        "stat_many[0] = {:?}, expected the one-by-one stat answer {:?}",
                        metas[0], single
                    ));
                }
                if metas[1].is_some() {
                    violations.push(format!(
                        "stat_many of an absent path returned {:?}, expected None",
                        metas[1]
                    ));
                }
                if metas[2] != metas[0] {
                    violations.push(
                        "stat_many is not in input order (the two equal inputs differ)".to_owned(),
                    );
                }
            }
        }
        Err(text) => violations.push(format!("stat_many failed: {text}")),
    }
    match value(fs.stat_many(&[], ctx)) {
        Ok(metas) if metas.is_empty() => {}
        Ok(metas) => violations.push(format!(
            "stat_many of an empty input returned {} entries, expected none",
            metas.len()
        )),
        Err(text) => violations.push(format!("stat_many of an empty input failed: {text}")),
    }

    // -- a missing file is NotFound, never an empty success --
    match fault(fs.read(&absent, ByteCap(1024), ctx)) {
        Ok(found) if found.kind == IoFaultKind::NotFound => {}
        Ok(other) => violations.push(format!(
            "read of a missing file must be NotFound, got {:?}",
            other.kind
        )),
        Err(text) => violations.push(format!("read of a missing file: {text}")),
    }

    // -- the byte cap must actually cap (RFC-0006 §5.3 budget rules) --
    match fault(fs.read(&target, ByteCap(4), ctx)) {
        Ok(capped) if capped.kind == IoFaultKind::CapacityExceeded => {}
        Ok(other) => violations.push(format!(
            "read under a too-small cap must be CapacityExceeded, got {:?}",
            other.kind
        )),
        Err(text) => violations.push(format!("capped read: {text}")),
    }

    // -- rename moves the content and leaves nothing behind --
    if let Err(text) = value(fs.rename(&target, &moved, Durability::D2, ctx)) {
        violations.push(format!("rename failed: {text}"));
    } else {
        if !matches!(value(fs.stat(&target, ctx)), Ok(None)) {
            violations.push("rename left the source path in place".to_owned());
        }
        if matches!(value(fs.stat(&moved, ctx)), Ok(None)) {
            violations.push("rename did not create the destination path".to_owned());
        }
    }
    match fault(fs.rename(&absent, &moved, Durability::D2, ctx)) {
        Ok(missing) if missing.kind == IoFaultKind::NotFound => {}
        Ok(other) => violations.push(format!(
            "rename of a missing source must be NotFound, got {:?}",
            other.kind
        )),
        Err(text) => violations.push(format!("rename of a missing source: {text}")),
    }

    // -- link_or_copy leaves both sides present and identical --
    let copy = dir.join("copy").expect("static child");
    match value(fs.link_or_copy(&moved, &copy, ctx)) {
        Ok(kind) => {
            let left = value(fs.read(&moved, ByteCap(1024), ctx));
            let right = value(fs.read(&copy, ByteCap(1024), ctx));
            match (left, right) {
                (Ok(left), Ok(right)) if left == right && !left.is_empty() => {}
                (left, right) => violations.push(format!(
                    "link_or_copy({kind:?}) must leave both sides readable and identical: {:?} vs {:?}",
                    left.map(|bytes| bytes.len()),
                    right.map(|bytes| bytes.len())
                )),
            }
        }
        Err(text) => violations.push(format!("link_or_copy failed: {text}")),
    }

    // -- open_stream resolves a present file and reports a missing one; its label is the
    //    caller's own name for the file, identical on every backend (`ADR-040`) --
    match value(fs.open_stream(&copy, ctx)) {
        Ok(stream) if stream.label == copy.as_relative_path() => {}
        Ok(stream) => violations.push(format!(
            "open_stream's label must be the requested path itself, got {:?} — the caller's \
             own name, never the host's (ADR-040)",
            stream.label
        )),
        Err(text) => violations.push(format!("open_stream of a present file: {text}")),
    }
    match fault(fs.open_stream(&absent, ctx)) {
        Ok(missing) if missing.kind == IoFaultKind::NotFound => {}
        Ok(other) => violations.push(format!(
            "open_stream of a missing file must be NotFound, got {:?}",
            other.kind
        )),
        Err(text) => violations.push(format!("open_stream of a missing file: {text}")),
    }

    // -- remove deletes; a second remove must say so --
    if let Err(text) = value(fs.remove(&copy, ctx)) {
        violations.push(format!("remove failed: {text}"));
    }
    match fault(fs.remove(&copy, ctx)) {
        Ok(gone) if gone.kind == IoFaultKind::NotFound => {}
        Ok(other) => violations.push(format!(
            "second remove must be NotFound, got {:?}",
            other.kind
        )),
        Err(text) => violations.push(format!("second remove: {text}")),
    }

    // Cleanup for re-runs; a failure here is not itself a contract violation.
    let _ = value(fs.remove(&moved, ctx));
    let _ = value(fs.remove(&target, ctx));
    violations
}

/// The release half of exclusive locking.
///
/// `Fs::lock_exclusive` returns a plain `FileLock { path }`, so there is no RAII guard and no
/// `Drop` hook: without an explicit release, "exclusive" cannot be tested and a restart would
/// deadlock forever. This trait supplies the missing half without changing the frozen `Fs`
/// shape; both backends implement it. Folding it into `Fs` proper is a separate, documented
/// recommendation (`docs/history/ONBOARDING_NOTES.md`).
pub trait FsLocking: Send + Sync + 'static {
    fn lock<'a>(
        &'a self,
        path: &'a VPath,
        ctx: &'a IoContext,
    ) -> crate::BoxFuture<'a, Result<FileLock, IoFault>>;

    fn release<'a>(
        &'a self,
        lock: &'a FileLock,
        ctx: &'a IoContext,
    ) -> crate::BoxFuture<'a, Result<(), IoFault>>;

    /// Path-keyed release: a caller that crashed holds a lock *file*, not a `FileLock` value,
    /// so recovery must be able to clear it without the original handle.
    fn release_path<'a>(
        &'a self,
        path: &'a VPath,
        ctx: &'a IoContext,
    ) -> crate::BoxFuture<'a, Result<(), IoFault>>;
}

/// Exclusive locking must be able to conflict, and must be releasable.
pub fn fs_lock_violations(backend: &dyn FsLocking, ctx: &IoContext) -> Vec<String> {
    let mut violations = Vec::new();
    let lock = VPath::try_from_str("contract/lock-me").expect("static path");
    let _ = value(backend.release_path(&lock, ctx));

    let held = match value(backend.lock(&lock, ctx)) {
        Ok(guard) => guard,
        Err(text) => {
            violations.push(format!("first lock_exclusive must succeed: {text}"));
            return violations;
        }
    };

    match fault(backend.lock(&lock, ctx)) {
        Ok(conflict)
            if matches!(
                conflict.kind,
                IoFaultKind::AlreadyExists | IoFaultKind::Busy
            ) => {}
        Ok(other) => violations.push(format!(
            "a contended lock must be AlreadyExists or Busy, got {:?} (an implementation that \
             always grants exclusivity cannot model the crash-recovery cases at all)",
            other.kind
        )),
        Err(text) => violations.push(format!("contended lock: {text}")),
    }

    if let Err(text) = value(backend.release(&held, ctx)) {
        violations.push(format!("release failed: {text}"));
    }
    match value(backend.lock(&lock, ctx)) {
        Ok(reacquired) => {
            let _ = value(backend.release(&reacquired, ctx));
        }
        Err(text) => violations.push(format!("locking after release must succeed: {text}")),
    }
    let _ = value(backend.release_path(&lock, ctx));
    violations
}

/// Contract item 5: monotonic time must never go backwards, and must answer waits.
pub fn clock_contract_violations(clock: &dyn Clock) -> Vec<String> {
    let mut violations = Vec::new();
    let first: Monotonic = clock.mono();
    let second: Monotonic = clock.mono();
    if second.ticks_millis < first.ticks_millis {
        violations.push(format!(
            "mono() went backwards between calls: {} then {}",
            first.ticks_millis, second.ticks_millis
        ));
    }

    let target = Monotonic {
        ticks_millis: second.ticks_millis + 25,
    };
    if let Err(text) = value(clock.sleep_until(target)) {
        violations.push(format!("sleep_until failed: {text}"));
    }
    let after: Monotonic = clock.mono();
    if after.ticks_millis < target.ticks_millis {
        violations.push(format!(
            "mono() did not reach the sleep target: {} < {}",
            after.ticks_millis, target.ticks_millis
        ));
    }

    // A monotonic advance must never move the wall clock backwards; that is exactly the
    // property a naive "wall clock minus adjustment" implementation breaks.
    let wall: Timestamp = clock.now();
    let _ = value(clock.sleep_until(Monotonic {
        ticks_millis: after.ticks_millis + 5,
    }));
    let later_wall: Timestamp = clock.now();
    if later_wall.unix_millis < wall.unix_millis {
        violations.push(format!(
            "now() moved backwards across a monotonic sleep: {} -> {}",
            wall.unix_millis, later_wall.unix_millis
        ));
    }

    // A deadline already in the past must return immediately rather than hang or error.
    let past = Monotonic {
        ticks_millis: clock.mono().ticks_millis.saturating_sub(1_000),
    };
    if let Err(text) = value(clock.sleep_until(past)) {
        violations.push(format!(
            "sleep_until with an elapsed target must return Ok: {text}"
        ));
    }
    violations
}

/// `ADR-035 §2.1`: what `Fs::list` owes every caller, and the four places a backend can quietly
/// differ from its twin. Written as violations rather than panics, for the same reason the rest of the
/// suite is: one backend run should report *every* disagreement, not the first one.
pub fn fs_listing_violations(fs: &dyn Fs, ctx: &IoContext) -> Vec<String> {
    let mut violations = Vec::new();
    let dir = VPath::try_from_str("listing").expect("static path");
    let nested = dir.join("sub").expect("static child");
    let absent = VPath::try_from_str("never-created").expect("static path");
    let empty_dir = VPath::try_from_str("empt").expect("static path");
    let empt_child = empty_dir.join("only").expect("static child");

    // Creation order is deliberately scrambled: a backend that returns host order would pass a test
    // that only checks set membership, and recovery/gc candidate sets would then differ between the
    // simulator (the release gate, `ADR-022`) and the real disk.
    for name in ["c", "a", "b"] {
        let child = dir.join(name).expect("static child");
        if let Err(text) =
            value(fs.write_atomic(&child, name.as_bytes().to_vec(), Durability::D1, ctx))
        {
            violations.push(format!("list: setup write {name:?} failed: {text}"));
        }
    }
    let nested_child = nested.join("d").expect("static grandchild");
    if let Err(text) = value(fs.write_atomic(&nested_child, b"d".to_vec(), Durability::D1, ctx)) {
        violations.push(format!(
            "list: setup write for a subdirectory failed: {text}"
        ));
    }
    if let Err(text) = value(fs.write_atomic(&empt_child, b"x".to_vec(), Durability::D1, ctx)) {
        violations.push(format!(
            "list: setup write in the empty-dir case failed: {text}"
        ));
    }

    let listed = match value(fs.list(&dir, ListCap(64), ctx)) {
        Ok(children) => children,
        Err(text) => {
            violations.push(format!("list of a directory with children failed: {text}"));
            return violations;
        }
    };
    let names: Vec<String> = listed
        .iter()
        .map(|child| child.as_relative_path())
        .collect();
    let mut sorted = names.clone();
    sorted.sort();
    if names != sorted {
        violations.push(format!("list must return children sorted, got {names:?}"));
    }
    let expected = [
        "listing/a".to_owned(),
        "listing/b".to_owned(),
        "listing/c".to_owned(),
        "listing/sub".to_owned(),
    ];
    if names != expected {
        violations.push(format!(
            "list returned {names:?}, expected {expected:?} (one level only, directories included)"
        ));
    }
    // A child of a subdirectory must not leak into the parent listing.
    if names.iter().any(|name| name.ends_with("sub/d")) {
        violations.push("list recursed into a subdirectory".to_owned());
    }

    // -- the cap is an error, not a shorter answer --
    match fault(fs.list(&dir, ListCap(2), ctx)) {
        Ok(capped) if capped.kind == IoFaultKind::CapacityExceeded => {}
        Ok(other) => violations.push(format!(
            "list over the cap must be CapacityExceeded, got {:?}",
            other.kind
        )),
        Err(text) => violations.push(format!("list over the cap: {text}")),
    }
    // Exactly-at-cap is not an error, or the bound is off by one and every "give me all of it" call
    // fails on a full directory.
    if let Err(text) = value(fs.list(&dir, ListCap(4), ctx)) {
        violations.push(format!("list at exactly the cap must succeed: {text}"));
    }

    // -- "empty" and "missing" are different answers --
    match value(fs.list(&absent, ListCap(8), ctx)) {
        Ok(found) => violations.push(format!(
            "list of a directory that never existed returned {found:?}; it must be NotFound"
        )),
        Err(text) if text.starts_with("NotFound") => {}
        Err(text) => violations.push(format!(
            "list of an absent directory must be NotFound, got {text}"
        )),
    }
    if let Err(text) = value(fs.remove(&empt_child, ctx)) {
        violations.push(format!("list: removing the only child failed: {text}"));
    } else {
        match value(fs.list(&empty_dir, ListCap(8), ctx)) {
            Ok(children) if children.is_empty() => {}
            Ok(children) => violations.push(format!(
                "an emptied directory must list as empty, got {children:?}"
            )),
            Err(text) => violations.push(format!(
                "an existing but empty directory must list as Ok([]), got Err({text})"
            )),
        }
    }

    // -- listing a file is its own answer, not "not found" --
    let file = dir.join("a").expect("static child");
    match fault(fs.list(&file, ListCap(8), ctx)) {
        Ok(kind) if kind.kind == IoFaultKind::InvalidInput => {}
        Ok(other) => violations.push(format!(
            "listing a file must be InvalidInput (the path is there, it has no children), got {:?}",
            other.kind
        )),
        Err(text) => violations.push(format!("listing a file: {text}")),
    }
    violations
}

/// `ADR-035 §2.2`: what an mtime is allowed to do. Deliberately permissive about *whether* a port
/// knows the time (a simulated world may have no clock at all) and strict about the two things that
/// must hold wherever it does: it is a fact about each path, reported the same way for every path, and
/// it never moves backwards for a path that was rewritten.
pub fn fs_mtime_violations(fs: &dyn Fs, ctx: &IoContext) -> Vec<String> {
    let mut violations = Vec::new();
    let dir = VPath::try_from_str("mtimes").expect("static path");
    let first = dir.join("first").expect("static child");
    let second = dir.join("second").expect("static child");

    let stamp = |path: &VPath| -> Result<Option<i64>, String> {
        value(fs.stat(path, ctx)).map(|meta| meta.and_then(|meta| meta.modified_at_unix_ms))
    };

    if let Err(text) = value(fs.write_atomic(&first, b"one".to_vec(), Durability::D1, ctx)) {
        violations.push(format!("mtime: setup write failed: {text}"));
        return violations;
    }
    let first_stamp = match stamp(&first) {
        Ok(stamp) => stamp,
        Err(text) => {
            violations.push(format!("mtime: stat after write failed: {text}"));
            return violations;
        }
    };
    if let Err(text) = value(fs.write_atomic(&second, b"two".to_vec(), Durability::D1, ctx)) {
        violations.push(format!("mtime: second write failed: {text}"));
        return violations;
    }
    let second_stamp = stamp(&second).ok().flatten();

    // Consistency first: a port that knows the time for one file must know it for all of them.
    // Half-known mtimes are how a grace period starts trusting the ones that happen to be set.
    if first_stamp.is_some() != second_stamp.is_some() {
        violations.push(format!(
            "mtimes must be known for every file or for none, got {first_stamp:?} and {second_stamp:?}"
        ));
    }

    // Then monotonicity per path: a rewrite cannot make a file younger-than-it-was *older*.
    if let Some(before) = first_stamp {
        if let Err(text) = value(fs.write_atomic(&first, b"three".to_vec(), Durability::D2, ctx)) {
            violations.push(format!("mtime: rewrite failed: {text}"));
        } else {
            match stamp(&first) {
                Ok(Some(after)) if after >= before => {}
                Ok(Some(after)) => violations.push(format!(
                    "rewriting a file moved its mtime backwards: {before} -> {after}"
                )),
                Ok(None) => violations.push(
                    "a file's mtime vanished after a rewrite; a port must not toggle between known \
                     and unknown"
                        .to_owned(),
                ),
                Err(text) => violations.push(format!("mtime: stat after rewrite failed: {text}")),
            }
        }
    }
    violations
}

/// Contract item 7: "unsupported" and "temporarily unavailable" must not collapse.
/// `RFC-0006 §5.3`, as a port obligation, checked on every backend.
///
/// The RFC says `io_budget` bounds 单次操作 and that running out **MUST** answer with a capacity/budget
/// `IoFault`. Four things two backends could still disagree about, one per block below:
///
/// 1. a payload over the budget is refused **before it is written** -- so a refused write must leave no
///    file behind (a half-written object is the failure `RFC-0007 §6.2` exists to prevent, and a port
///    that measures after the fact has only produced a nicer error about a corrupted directory);
/// 2. the exact boundary is *inside* the limit, the same rule `ByteCap` and `ListCap` already follow;
/// 3. a read is bounded by the **tighter** of its own cap and the budget, and a budget looser than the
///    cap must not enlarge the cap;
/// 4. the refusal names the bound that actually bit, because otherwise the caller goes and changes the
///    wrong knob -- and "no budget stated" must refuse nothing at all, which is what keeps an absent
///    bound from being silently read as zero.
///
/// `ctx` is the backend's ordinary (unbudgeted) context; the tight one is derived from it so that the
/// only difference the checks observe is the budget itself.
pub fn fs_byte_budget_violations(fs: &dyn Fs, ctx: &IoContext) -> Vec<String> {
    let mut violations = Vec::new();
    let dir = VPath::try_from_str("budget-probe").expect("static path");
    let big = dir.join("big.bin").expect("static child");
    let edge = dir.join("edge.bin").expect("static child");
    let mut tight = ctx.clone();
    tight.io_budget = crate::IoBudget {
        max_bytes: Some(1_024),
        max_requests: ctx.io_budget.max_requests,
    };
    let payload = vec![b'x'; 2_048];

    // (1) over-budget write: refused, and nothing left behind.
    match fault(fs.write_atomic(&big, payload.clone(), Durability::D1, &tight)) {
        Ok(fault) if fault.kind == IoFaultKind::CapacityExceeded => {
            if !fault.summary.contains("io_budget.max_bytes") {
                violations.push(format!(
                    "a budget refusal has to name the budget, or the caller hunts for a cap it never                      set: {:?}",
                    fault.summary
                ));
            }
        }
        Ok(other) => violations.push(format!(
            "a payload over io_budget.max_bytes must be CapacityExceeded, got {:?}",
            other.kind
        )),
        Err(text) => violations.push(format!("budgeted write: {text}")),
    }
    match value(fs.stat(&big, ctx)) {
        Ok(None) => {}
        Ok(Some(meta)) => violations.push(format!(
            "the refused write left a {} byte file behind at {}",
            meta.len, "budget-probe/big.bin"
        )),
        Err(text) => violations.push(format!("stat after a refused write: {text}")),
    }

    // (2) exactly at the budget is inside it.
    if let Err(text) = value(fs.write_atomic(&edge, vec![b'y'; 1_024], Durability::D1, &tight)) {
        violations.push(format!(
            "a payload exactly at the budget must be accepted: {text}"
        ));
    }

    // (3) a read inside the budget, with a looser cap than the budget, is answered.
    match value(fs.read(&edge, ByteCap(65_536), &tight)) {
        Ok(bytes) if bytes.len() == 1_024 => {}
        Ok(bytes) => violations.push(format!(
            "read back {} bytes where 1024 were written",
            bytes.len()
        )),
        Err(text) => violations.push(format!("a read inside the budget was refused: {text}")),
    }

    // (4) the smaller requested cap still wins, and says so instead of blaming the budget.
    match fault(fs.read(&edge, ByteCap(512), ctx)) {
        Ok(fault) if fault.kind == IoFaultKind::CapacityExceeded => {
            if !fault.summary.contains("512 byte cap") || fault.summary.contains("io_budget") {
                violations.push(format!(
                    "this refusal is about the cap the call passed, not the budget: {:?}",
                    fault.summary
                ));
            }
        }
        Ok(other) => violations.push(format!(
            "reading past a too-small cap must be CapacityExceeded, got {:?}",
            other.kind
        )),
        Err(text) => violations.push(format!("capped read: {text}")),
    }

    // (5) with no budget stated, the same sizes are simply legal: absence is not zero.
    if let Err(text) = value(fs.write_atomic(&big, payload, Durability::D1, ctx)) {
        violations.push(format!(
            "an unbudgeted context must accept any payload size: {text}"
        ));
    }
    match fault(fs.read(&big, ByteCap(65_536), &tight)) {
        Ok(fault) if fault.kind == IoFaultKind::CapacityExceeded => {
            if !fault.summary.contains("io_budget.max_bytes = 1024") {
                violations.push(format!(
                    "the budget is the tighter bound here and must be the one named: {:?}",
                    fault.summary
                ));
            }
        }
        Ok(other) => violations.push(format!(
            "a file larger than the budget must not be slurped into memory, got {:?}",
            other.kind
        )),
        Err(text) => violations.push(format!("budgeted read: {text}")),
    }
    violations
}

pub fn fault_kind_vocabulary_is_distinguishable() -> Vec<String> {
    let mut violations = Vec::new();
    let unsupported = IoFault::new(IoFaultKind::Unsupported, "no keyring backend");
    let unavailable = IoFault::new(IoFaultKind::Unavailable, "agent not running");
    if unsupported.kind == unavailable.kind {
        violations.push("Unsupported and Unavailable collapsed into one kind".to_owned());
    }
    if unsupported.retryable {
        violations.push("Unsupported must not be retryable by default".to_owned());
    }
    if unsupported.summary.is_empty() || unavailable.summary.is_empty() {
        violations.push("an IoFault without a summary cannot be shown to a user".to_owned());
    }
    violations
}
