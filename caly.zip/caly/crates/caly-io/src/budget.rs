//! The caller's byte budget, enforced where the bytes are visible (`RFC-0006 §5.3`).
//!
//! §5.3 says `io_budget` 用于限制**单次操作**的资源消耗, lists 可读取总字节数 among the quantities, and
//! requires that exhausting it return a capacity/budget `IoFault`. Only a port can honour that: it is
//! the one layer that sees a payload's size. The engine above it sees a call, not a size -- which is
//! exactly why `ADR-036 §6bis-sexies` refused to bill bytes there -- and the store in between hands the
//! bytes to the port without measuring them. So the check lives here, next to the trait it serves, and
//! both backends call these two functions rather than each writing its own (round 26's lesson: a rule
//! written per adapter is a rule each adapter can forget).
//!
//! # Why the two axes of `IoBudget` behave differently
//!
//! * `max_requests` is **counted per command execution**, in `caly-engine::run_limits::RunLimits`. A
//!   count needs a scope that outlives one call, and the only party owning that scope is the execution.
//! * `max_bytes` is a **ceiling on one call's payload**, enforced here -- and, since round 34
//!   (`ADR-039 §2` step 2), also a **cumulative meter** at the store seam: the context now carries a
//!   [`ByteMeter`](caly_common::ByteMeter) shared by clone, so the bytes one caller's context moved
//!   accrue to that caller's scope across calls. `ADR-036 §6bis-decies` recorded the per-call-only
//!   deviation while store signatures carried no `Ctx`; round 33 removed that premise and this module
//!   grew the cumulative half (`admit_bytes` / `admit_unit` / `charge`) so both stores call one rule
//!   instead of each writing its own. A meter on the *context* is what keeps the old outage fear
//!   unrealized: the scope is the caller's, not the process's.
//!
//! # Which ceiling bit, said out loud
//!
//! `read` is *already* bounded by the `ByteCap` the call carries; the budget may be tighter. A refusal
//! that says "over a 1024 byte cap" when the caller set `io_budget.max_bytes = 1024` sends it looking for
//! the wrong knob, so [`ByteCeiling::violation`] names the bound that actually applied -- and
//! [`crate::contract::fs_byte_budget_violations`] checks that both backends say it the same way.

use crate::{IoContext, IoFault, IoFaultKind};

/// Which of the two byte bounds is in force for one call.
#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub enum CeilingSource {
    /// The cap the call itself carried: `Fs::read`'s `ByteCap`, `Http::fetch`'s `max_body_bytes`.
    Requested,
    /// `Ctx::io_budget.max_bytes`, stated once by the caller for the whole context.
    Budget,
}

/// The byte bound one call may not exceed, and who set it.
#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub struct ByteCeiling {
    pub bytes: u64,
    pub source: CeilingSource,
}

impl ByteCeiling {
    /// The fault to return when `actual` bytes do not fit, or `None` when they do.
    ///
    /// The exact boundary fits: a 1024-byte file under a 1024-byte ceiling is inside it. That is the same
    /// rule `ByteCap` already follows and the one `fs_listing_violations` pins for lists -- a limit that
    /// refuses its own value is a limit one smaller than it looks.
    pub fn violation(&self, actual: u64, resource: &str) -> Option<IoFault> {
        if actual <= self.bytes {
            return None;
        }
        let summary = match self.source {
            CeilingSource::Requested => format!(
                "{resource} is {} bytes over a {} byte cap",
                actual - self.bytes,
                self.bytes
            ),
            CeilingSource::Budget => format!(
                "{resource} is {actual} bytes over this call's io_budget.max_bytes = {}",
                self.bytes
            ),
        };
        Some(IoFault {
            resource: Some(resource.to_owned()),
            ..IoFault::new(IoFaultKind::CapacityExceeded, summary)
        })
    }
}

/// The byte bound for one call: the tighter of the cap it carries and the caller's budget.
///
/// "Tighter" is the only defensible combination: a budget looser than the call's own cap must not *grow*
/// that cap, or stating a budget would silently raise the limit the caller asked for. One function, two
/// backends -- which is the point (`ADR-036 §6bis-septies`' rule that a check written per adapter is a
/// check each adapter can forget).
pub fn byte_ceiling(ctx: &IoContext, requested: u64) -> ByteCeiling {
    match ctx.io_budget.max_bytes {
        Some(budget) if budget < requested => ByteCeiling {
            bytes: budget,
            source: CeilingSource::Budget,
        },
        _ => ByteCeiling {
            bytes: requested,
            source: CeilingSource::Requested,
        },
    }
}

/// Refuse a payload before any byte of it moves (`RFC-0006 §5.3`).
///
/// Writes have no requested cap to take a minimum with, so the budget is the whole bound. The check runs
/// *before* the write by necessity, not by taste: a half-written file is the failure the durable layer is
/// built to prevent (`RFC-0007 §6.2`), and "we wrote it and then noticed it was too big" is not
/// recoverable at a port.
///
/// `Ok(())` also covers "no budget was stated" -- an absent bound is reported by doing nothing, never by
/// inventing a number to enforce.
pub fn check_payload(ctx: &IoContext, resource: &str, bytes: u64) -> Result<(), IoFault> {
    let cap = match ctx.io_budget.max_bytes {
        Some(cap) => cap,
        None => return Ok(()),
    };
    if bytes <= cap {
        return Ok(());
    }
    Err(IoFault {
        resource: Some(resource.to_owned()),
        ..IoFault::new(
            IoFaultKind::CapacityExceeded,
            format!("{resource} is {bytes} bytes over this call's io_budget.max_bytes = {cap}"),
        )
    })
}

/// The cumulative half: admit a write whose size is known before any byte moves.
///
/// Refuses when the bytes already moved on this context plus this unit would pass the caller's
/// stated `max_bytes`. A write can be refused before it starts, so it is -- a refused write must
/// leave the disk exactly as it was, which is the only recoverable shape at a port that cannot
/// half-write (`RFC-0007 §6.2`). No stated budget admits everything; charging is then still
/// recorded, so a caller that states nothing is reported, never silently protected.
pub fn admit_bytes(ctx: &IoContext, resource: &str, bytes: u64) -> Result<(), IoFault> {
    let Some(cap) = ctx.io_budget.max_bytes else {
        return Ok(());
    };
    let spent = ctx.byte_meter.spent();
    if spent.saturating_add(bytes) <= cap {
        return Ok(());
    }
    Err(IoFault {
        resource: Some(resource.to_owned()),
        ..IoFault::new(
            IoFaultKind::CapacityExceeded,
            format!(
                "{resource} would take this caller past its cumulative io_budget.max_bytes = {cap} \
                 ({spent} already moved, this unit is {bytes})"
            ),
        )
    })
}

/// The cumulative half: admit a read whose size is *not* known until it happens.
///
/// Reads discover their size by moving the bytes, so the honest gate is "is anything left":
/// a context that has already spent its stated budget refuses new units, while the unit in
/// flight completes and then charges what it actually moved -- the same in-flight discipline
/// the cancellation gate follows (`ADR-039 §2.3`), for the same reason: tearing into a read
/// that already started recovers nothing.
pub fn admit_unit(ctx: &IoContext, resource: &str) -> Result<(), IoFault> {
    let Some(cap) = ctx.io_budget.max_bytes else {
        return Ok(());
    };
    let spent = ctx.byte_meter.spent();
    if spent < cap {
        return Ok(());
    }
    Err(IoFault {
        resource: Some(resource.to_owned()),
        ..IoFault::new(
            IoFaultKind::CapacityExceeded,
            format!(
                "this caller's cumulative io_budget.max_bytes = {cap} is already spent \
                 ({spent} moved); {resource} may not start"
            ),
        )
    })
}

/// Record bytes that moved on this context's behalf. Called after the move succeeded; the
/// admission functions above are the refusal path, this is the accounting.
pub fn charge(ctx: &IoContext, bytes: u64) {
    ctx.byte_meter.charge(bytes);
}

#[cfg(test)]
mod tests {
    use super::*;
    use caly_common::{Actor, IoBudget, RequestContext, TraceId};

    fn ctx(max_bytes: Option<u64>) -> RequestContext {
        let mut ctx = RequestContext::new(TraceId::new("budget"), Actor::System);
        ctx.io_budget = IoBudget {
            max_bytes,
            max_requests: None,
        };
        ctx
    }

    /// The minimum is the answer, in both directions -- and the source says which one won.
    #[test]
    fn the_tighter_bound_wins_and_says_which_it_is() {
        let tight = byte_ceiling(&ctx(Some(1_024)), 4_096);
        assert_eq!((tight.bytes, tight.source), (1_024, CeilingSource::Budget));

        // A budget looser than the call's own cap must not enlarge that cap.
        let loose = byte_ceiling(&ctx(Some(8_192)), 4_096);
        assert_eq!(
            (loose.bytes, loose.source),
            (4_096, CeilingSource::Requested)
        );

        let none = byte_ceiling(&ctx(None), 4_096);
        assert_eq!((none.bytes, none.source), (4_096, CeilingSource::Requested));
    }

    /// Both numbers, and the name of the knob to turn. A caller told "over a 1024 byte cap" when it never
    /// passed a cap of 1024 would go looking for the wrong thing.
    #[test]
    fn a_refusal_names_the_bound_that_bit() {
        let budget = byte_ceiling(&ctx(Some(1_024)), 4_096);
        let fault = budget.violation(2_048, "var/caly/x").expect("over");
        assert_eq!(fault.kind, IoFaultKind::CapacityExceeded);
        assert!(
            fault.summary.contains("io_budget.max_bytes = 1024"),
            "{}",
            fault.summary
        );
        assert!(fault.summary.contains("2048 bytes"), "{}", fault.summary);
        assert_eq!(
            fault.resource.as_deref(),
            Some("var/caly/x"),
            "the resource is how a caller finds the file; the port used to set it on this path and must not lose it"
        );

        let requested = byte_ceiling(&ctx(Some(1_024)), 512);
        let fault = requested.violation(1_024, "p").expect("over the cap");
        assert!(
            fault.summary.contains("over a 512 byte cap"),
            "{}",
            fault.summary
        );
        assert!(
            !fault.summary.contains("io_budget"),
            "the cap is what bit here: {}",
            fault.summary
        );
    }

    /// `<=`, not `<`: the boundary is inside its own limit. Off by one here turns every "exactly the
    /// budget" call into a refusal, and the refusal would be a lie about the caller's size.
    #[test]
    fn exactly_at_the_ceiling_fits() {
        let ceiling = byte_ceiling(&ctx(Some(1_024)), 4_096);
        assert!(ceiling.violation(1_024, "p").is_none());
        assert!(ceiling.violation(1_025, "p").is_some());
        assert!(check_payload(&ctx(Some(1_024)), "p", 1_024).is_ok());
        assert!(check_payload(&ctx(Some(1_024)), "p", 1_025).is_err());
    }

    /// No budget stated is not "zero bytes allowed": the field is `Option` so that "unbounded" stays a
    /// reportable answer rather than a value that has to be guessed at.
    #[test]
    fn an_unbounded_context_refuses_nothing_at_all() {
        let unbounded = ctx(None);
        assert!(check_payload(&unbounded, "p", u64::MAX).is_ok());
        assert_eq!(
            byte_ceiling(&unbounded, 7).bytes,
            7,
            "and the read ceiling stays exactly what was asked for"
        );
    }
}
