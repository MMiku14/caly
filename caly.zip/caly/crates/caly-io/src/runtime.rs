//! Driving a port future without a scheduler.
//!
//! Every port method returns a `BoxFuture`, but the workspace has no executor *dependency*
//! (`docs/history/ONBOARDING_NOTES.md §1.4`), and each backend does its work synchronously inside the
//! `async` block. That leaves the helper used across `caly-storage` (durable backend, `audit`,
//! `schema`), `caly-engine` (recovery, bundle), both contract suites and several daemon tests --
//! a couple of dozen call sites. The count is deliberately *not* kept here as a bare number: the
//! same command read 23 when this line was written and 26-27 by the next round, because callers get
//! added and nobody checks a comment (see `ONBOARDING_NOTES §4.97`). To recount:
//! `grep -rn block_on_ready crates/ --include='*.rs' | cut -d: -f1 | sort -u | wc -l` -- 27 that way,
//! 26 if you also drop `runtime.rs` itself, which is the point: state the filter, or the number cannot
//! even be argued about.
//! All of those sites would otherwise write their own loop, and duplicated a few times they drifted:
//! one copy (`caly-engine::recovery::run_ready`) had grown its own hand-written `Wake`.
//!
//! What landed later is a bounded executor of our
//! own ([`crate::BoundedExecutor`]) -- still zero dependencies, still this file as the only place a
//! future is polled.
//!
//! So the helper lives here, next to the trait it serves, and the other sites delegate.
//!
//! # Contract
//!
//! [`drive`] polls until the future is ready **or** a limit says to stop; with [`Drive::immediate`]
//! that is one poll and no limits, which is what every call site in this repo needs today because no
//! production port suspends (the only suspending port is `caly-io-sim`'s injected `hang`, which exists
//! to be driven by tests). A port that *does* suspend and is driven without limits gets a loud
//! [`IoFaultKind::Busy`] rather than a hang, and driven with a cancellation or a deadline it gets
//! [`IoFaultKind::Cancelled`] / [`IoFaultKind::Timeout`] -- distinct kinds, because `RFC-0006 §5.2`
//! requires the caller to be able to tell "I gave up" from "my time ran out".
//!
//! What this deliberately is **not**: a scheduler. There is no waker registry, no parking, no thread:
//! one future at a time, driven by the caller. Admitting several suspended callers at once, keeping them
//! fair to each other, and refusing the 65th is [`crate::BoundedExecutor`] (`ADR-036 §2.1`), which is
//! built on [`drive_pinned`] rather than a second copy of this loop.

use std::future::Future;
use std::pin::{pin, Pin};
use std::task::{Context, Poll, Waker};

use caly_common::CancelToken;

use crate::{Clock, IoFault, IoFaultKind, Monotonic};

/// An absolute deadline, in the monotonic milliseconds of whatever clock drives the call.
///
/// Held as a raw number rather than a `Monotonic` so it can be *stored* (on a `Ctx`, in a queue entry)
/// without implying it was produced by the same clock instance. Comparison is [`Drive`]'s job, and
/// only [`Drive`] has the clock.
#[derive(Clone, Copy, Debug, Eq, PartialEq, Ord, PartialOrd)]
pub struct Deadline(pub u64);

impl Deadline {
    pub const fn expired_at(self, now: Monotonic) -> bool {
        now.ticks_millis >= self.0
    }
}

/// How hard [`drive`] pushes a port future before it gives up.
///
/// Three exits, and they must stay three distinct answers: the caller cancelled, the deadline passed,
/// or nothing became ready within the poll budget. The last one is `Busy`, not `Timeout` -- claiming a
/// deadline passed when no clock said so would invent a fact the caller cannot check, and an
/// uncheckable reason in an error is how a retry loop starts looking rational.
#[derive(Clone, Default)]
pub struct Drive<'a> {
    pub cancel: Option<&'a CancelToken>,
    pub deadline: Option<Deadline>,
    /// The clock the deadline is measured against. Without one, a deadline is *ignored* rather than
    /// guessed at: a `Ctx` carries `deadline_ms` as a relative value precisely because only the driver
    /// knows which clock it means (`ADR-036 §6bis`, `docs/history/ONBOARDING_NOTES.md §4.86`).
    pub clock: Option<&'a dyn Clock>,
    pub max_polls: u32,
}

impl<'a> Drive<'a> {
    /// One poll, no limits -- today's behaviour everywhere it is still the right contract.
    pub const fn immediate() -> Self {
        Self {
            cancel: None,
            deadline: None,
            clock: None,
            max_polls: 1,
        }
    }

    /// A bounded drive with no cancellation and no clock. `max_polls` is clamped to at least 1 so a
    /// caller asking for "zero polls" gets "one poll" rather than a guaranteed `Busy`.
    pub const fn bounded(max_polls: u32) -> Self {
        Self {
            cancel: None,
            deadline: None,
            clock: None,
            max_polls: if max_polls == 0 { 1 } else { max_polls },
        }
    }

    pub const fn with_cancel(mut self, cancel: &'a CancelToken) -> Self {
        self.cancel = Some(cancel);
        self
    }

    pub const fn with_deadline(mut self, deadline: Deadline, clock: &'a dyn Clock) -> Self {
        self.deadline = Some(deadline);
        self.clock = Some(clock);
        self
    }
}

/// Poll `future` once and return its output, or explain why it could not complete immediately.
///
/// [`drive`] with [`Drive::immediate`], with the fault flattened to a `String` because most callers
/// wrap it in their own error type. It delegates rather than carrying its own poll loop: two copies of
/// "poll once and complain" is how the two eventually disagree about what "complain" means.
pub fn block_on_ready<F>(future: F) -> Result<F::Output, String>
where
    F: Future,
{
    drive(future, Drive::immediate()).map_err(|fault| fault.summary)
}

/// Drive `future` to readiness within `limits`, one caller at a time.
///
/// The checks happen *before* each poll: cancellation first (a caller who gave up must not be told the
/// clock ran out), then the deadline if a clock exists to judge it, then the poll. So a port that is
/// already ready costs one poll and no scheduling, and a port that never becomes ready costs
/// `max_polls` polls and one typed fault.
pub fn drive<F>(future: F, limits: Drive<'_>) -> Result<F::Output, IoFault>
where
    F: Future,
{
    let mut future = pin!(future);
    drive_pinned(future.as_mut(), limits)
}

/// [`drive`] for a future the caller keeps owning.
///
/// The executor needs exactly this: after a round in which nothing became ready it must hand the *same*
/// future back to the queue, while [`drive`] takes the future by value -- so a caller that wants the
/// second answer ("not ready yet, keep it") would otherwise destroy the thing it is waiting for. The
/// checks, their order, and the wording are shared with [`drive`] rather than copied, because two loops
/// is how the two start disagreeing about what "give up" means.
pub fn drive_pinned<F>(mut future: Pin<&mut F>, limits: Drive<'_>) -> Result<F::Output, IoFault>
where
    F: Future + ?Sized,
{
    let mut cx = Context::from_waker(Waker::noop());
    let polls = if limits.max_polls == 0 {
        1
    } else {
        limits.max_polls
    };
    for attempt in 1..=polls {
        if let Some(cancel) = limits.cancel {
            if cancel.is_cancelled() {
                return Err(IoFault::new(
                    IoFaultKind::Cancelled,
                    format!(
                        "call cancelled before poll {attempt} (deadline was {:?})",
                        limits.deadline
                    ),
                ));
            }
        }
        if let (Some(deadline), Some(clock)) = (limits.deadline, limits.clock) {
            if deadline.expired_at(clock.mono()) {
                return Err(IoFault {
                    retryable: true,
                    ..IoFault::new(
                        IoFaultKind::Timeout,
                        format!(
                            "deadline at mono {} expired at mono {} before poll {attempt}",
                            deadline.0,
                            clock.mono().ticks_millis
                        ),
                    )
                });
            }
        }
        if let Poll::Ready(value) = future.as_mut().poll(&mut cx) {
            return Ok(value);
        }
    }
    let summary = format!(
        "port was still pending after {polls} poll(s); deadline={}, clock={}, cancel={}",
        limits
            .deadline
            .map(|deadline| deadline.0.to_string())
            .unwrap_or_else(|| "none".to_owned()),
        if limits.clock.is_some() { "yes" } else { "no" },
        limits
            .cancel
            .map(|cancel| cancel.is_cancelled().to_string())
            .unwrap_or_else(|| "none".to_owned()),
    );
    Err(IoFault {
        retryable: true,
        transient: true,
        ..IoFault::new(IoFaultKind::Busy, summary)
    })
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::sync::atomic::{AtomicU64, Ordering};
    use std::sync::Mutex;

    use crate::{BoxFuture, Timestamp};

    /// A clock that steps by a fixed amount every time it is read. The scripted equivalent of "time
    /// passed while we were not looking", and the only way to make `Timeout` deterministic here: a real
    /// timer would make the test depend on the machine.
    struct SteppingClock {
        step: u64,
        ticks: AtomicU64,
    }

    impl SteppingClock {
        fn new(step: u64) -> Self {
            Self {
                step,
                ticks: AtomicU64::new(0),
            }
        }
    }

    impl Clock for SteppingClock {
        fn now(&self) -> Timestamp {
            Timestamp {
                unix_millis: self.ticks.load(Ordering::Relaxed) as i64,
            }
        }

        fn mono(&self) -> Monotonic {
            let at = self.ticks.fetch_add(self.step, Ordering::Relaxed);
            Monotonic { ticks_millis: at }
        }

        fn sleep_until<'a>(&'a self, _at: Monotonic) -> BoxFuture<'a, Result<(), IoFault>> {
            Box::pin(async { Ok(()) })
        }
    }

    /// A future that is never ready, standing in for the port that suspends. Every backend in this
    /// repo returns ready immediately, so without this fixture the three exits below cannot be reached
    /// at all -- which is exactly how `ADR-036 §1` described the gap: untestable, therefore unfixed.
    struct Never;

    impl Future for Never {
        type Output = u32;

        fn poll(self: std::pin::Pin<&mut Self>, _cx: &mut Context<'_>) -> Poll<u32> {
            Poll::Pending
        }
    }

    #[derive(Clone, Default)]
    struct Tracker(std::sync::Arc<Mutex<usize>>);

    struct Counted {
        tracker: Tracker,
        ready_at: usize,
    }

    impl Future for Counted {
        type Output = u32;

        fn poll(mut self: std::pin::Pin<&mut Self>, _cx: &mut Context<'_>) -> Poll<u32> {
            let this = self.as_mut().get_mut();
            let mut count = this
                .tracker
                .0
                .lock()
                .unwrap_or_else(|poisoned| poisoned.into_inner());
            *count += 1;
            if *count >= this.ready_at {
                Poll::Ready(*count as u32)
            } else {
                Poll::Pending
            }
        }
    }

    #[test]
    fn an_immediately_ready_future_costs_exactly_one_poll() {
        let seen = Tracker::default();
        let future = Counted {
            tracker: seen.clone(),
            ready_at: 1,
        };
        assert_eq!(drive(future, Drive::immediate()).expect("ready"), 1);
        assert_eq!(
            *seen.0.lock().unwrap(),
            1,
            "no limit must not mean extra polling: an unchanged call site has to stay unchanged"
        );
    }

    #[test]
    fn a_port_that_becomes_ready_later_is_driven_to_completion() {
        let seen = Tracker::default();
        let future = Counted {
            tracker: seen.clone(),
            ready_at: 3,
        };
        assert_eq!(drive(future, Drive::bounded(8)).expect("ready"), 3);
        assert_eq!(*seen.0.lock().unwrap(), 3);
    }

    #[test]
    fn a_hanging_port_is_busy_not_hung_and_says_what_was_missing() {
        let fault = drive(Never, Drive::bounded(4)).expect_err("never ready");
        assert_eq!(fault.kind, IoFaultKind::Busy);
        assert!(
            fault.summary.contains("after 4 poll(s)"),
            "{}",
            fault.summary
        );
        assert!(
            fault
                .summary
                .contains("deadline=none, clock=no, cancel=none"),
            "the refusal has to admit that no limit could have fired: {}",
            fault.summary
        );
        assert!(
            fault.retryable,
            "a port that is slow is not a port that failed"
        );
    }

    #[test]
    fn cancellation_beats_timeout_and_the_two_stay_distinguishable() {
        let cancel = CancelToken::pre_cancelled();
        let clock = SteppingClock::new(1_000);
        // `Deadline(0)` with a clock that reads 0: both conditions are true at once, which is the only
        // way to pin the *order*. An unexpired deadline here would let a build that judges the timeout
        // first pass this test by accident -- and that is exactly what the first version of this
        // assertion did (`docs/history/ONBOARDING_NOTES.md §4.88`).
        let fault = drive(
            Never,
            Drive::bounded(4)
                .with_cancel(&cancel)
                .with_deadline(Deadline(0), &clock),
        )
        .expect_err("cancelled");
        assert_eq!(fault.kind, IoFaultKind::Cancelled, "{fault:?}");
        assert!(!fault.retryable, "retrying a cancelled call is a new call");

        let fault = drive(Never, Drive::bounded(4).with_deadline(Deadline(1), &clock))
            .expect_err("deadline passed");
        assert_eq!(fault.kind, IoFaultKind::Timeout, "{fault:?}");
        assert!(fault.retryable, "a deadline is a budget, not a verdict");
    }

    #[test]
    fn a_deadline_without_a_clock_is_not_guessed_at() {
        // The poll budget runs out and no clock ever said the deadline passed: `Timeout` here would be
        // a fabricated reason, so the answer stays `Busy`.
        let limits = Drive {
            deadline: Some(Deadline(u64::MAX)),
            ..Drive::bounded(2)
        };
        let fault = drive(Never, limits).expect_err("no clock to judge with");
        assert_eq!(fault.kind, IoFaultKind::Busy, "{fault:?}");
        assert!(fault.summary.contains("clock=no"), "{}", fault.summary);
    }

    #[test]
    fn block_on_ready_delegates_and_keeps_the_flat_shape() {
        assert_eq!(block_on_ready(async { 5u8 }).expect("ready"), 5);
        let message = block_on_ready(Never).expect_err("pending");
        assert!(message.contains("still pending"), "{message}");
        assert_eq!(
            message,
            drive(Never, Drive::immediate())
                .expect_err("same answer")
                .summary,
            "the wrapper must not start disagreeing with the thing it wraps"
        );
    }
}
