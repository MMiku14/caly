use std::future::Future;
use std::pin::Pin;

use caly_common::RequestContext;

use crate::{IoFault, IoFaultKind, VPath};

pub type BoxFuture<'a, T> = Pin<Box<dyn Future<Output = T> + Send + 'a>>;
pub type Bytes = Vec<u8>;
pub type IoContext = RequestContext;

#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub struct ByteCap(pub u64);

/// How many entries [`Fs::list`] may return before it is a problem rather than an answer.
///
/// Same reasoning as [`ByteCap`]: an operation whose result size is decided by the world needs a
/// budget the caller sets, because the alternative is a call that succeeds by returning
/// "everything that happened to fit". `ADR-035 §2.1`.
#[derive(Clone, Copy, Debug, Eq, PartialEq, Ord, PartialOrd)]
pub struct ListCap(pub u32);

#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub enum Durability {
    D0,
    D1,
    D2,
    D3,
}

/// A handle label, not a reader: nothing can be pulled out of it yet, and that is the honest
/// shape until a real consumer exists (`ADR-040`). The label is **the caller's own name** for
/// the resource — the requested `VPath` rendering for files, the request URL for fetch — never
/// the host's resolved path and never backend internals. Growing an actual chunked reader is
/// a new decision, and it arrives with the caller's budget and deadline attached (`ADR-039`).
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct ByteStream {
    pub label: String,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct Meta {
    pub len: u64,
    pub is_file: bool,
    pub is_dir: bool,
    /// When this path was last successfully written, in unix milliseconds.
    ///
    /// `Option` because not every port can answer cheaply: a real filesystem records it, a simulated
    /// world only has it if it was given a clock (`ADR-035 §2.2`). The semantic is *"the last
    /// successful `write_atomic`"*, as recorded by the port itself — never a host reading smuggled in
    /// from somewhere else, because the simulator is the release gate (`ADR-022`) and a fabricated
    /// wall clock there would make timeout and grace-period behaviour unreproducible.
    ///
    /// A port must be consistent about it: `None` for one file and `Some` for another in the same
    /// world is a bug, not flexibility (enforced by `contract::fs_mtime_violations`).
    pub modified_at_unix_ms: Option<i64>,
}

#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub enum LinkKind {
    Reflink,
    Hardlink,
    Copy,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct FileLock {
    pub path: String,
}

#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub enum FetchRoute {
    Direct,
    SystemProxy,
    ActiveCore,
}

/// Which network targets this fetch may reach (`RFC-0010 §11.1`).
///
/// `Default` is the conservative stance: loopback, link-local / cloud-metadata and private
/// ranges are refused, because a control plane must not be turned into a probe of the host
/// it runs on (`RFC-0010 §11`). `AnyPeer` is the explicit opt-in for callers whose target
/// is known to be legitimate — calyd's own spawned core management addresses are the
/// documented case, and the `ActiveCore` route is always exempt (it **is** the management
/// address exception). No variant guesses: a caller that wants a private source must say so.
#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub enum FetchScope {
    Default,
    AnyPeer,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct FetchReq {
    pub url: String,
    pub route: FetchRoute,
    pub scope: FetchScope,
    pub etag: Option<String>,
    pub if_modified_since: Option<String>,
    pub max_body_bytes: u64,
}

/// A complete HTTP response body that has already passed the request and caller byte caps.
///
/// This is deliberately not [`ByteStream`]. `ByteStream` remains the label-only filesystem
/// handle frozen by `ADR-040`; a source consumer needs an owned, bounded snapshot, not a reader
/// whose poll/close semantics nobody has specified yet (`ADR-049`). A successful response carries
/// all bytes or it fails with `CapacityExceeded` -- it never carries a truncated prefix.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct FetchBody {
    /// The caller-owned resource name (`http:<request-url>`), not a resolved host path.
    pub label: String,
    /// The complete body, no larger than the effective request/caller ceiling.
    pub bytes: Bytes,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct FetchResp {
    pub status: u16,
    pub etag: Option<String>,
    pub last_modified: Option<String>,
    pub body: FetchBody,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct ChildHandle {
    pub pid: u32,
    pub instance_nonce: String,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct SpawnSpec {
    pub program: String,
    pub argv: Vec<String>,
    pub cwd: Option<VPath>,
    pub env: Vec<(String, String)>,
}

#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub struct Timestamp {
    pub unix_millis: i64,
}

#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub struct Monotonic {
    pub ticks_millis: u64,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct PlatformCaps {
    pub tun: bool,
    pub system_proxy: bool,
    pub dns_override: bool,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct NetworkPlan {
    pub summary: String,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct NetTxnId(pub String);

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct RevertOutcome {
    pub restored: bool,
    pub summary: String,
}

pub trait Fs: Send + Sync + 'static {
    fn read<'a>(
        &'a self,
        path: &'a VPath,
        cap: ByteCap,
        ctx: &'a IoContext,
    ) -> BoxFuture<'a, Result<Bytes, IoFault>>;
    fn open_stream<'a>(
        &'a self,
        path: &'a VPath,
        ctx: &'a IoContext,
    ) -> BoxFuture<'a, Result<ByteStream, IoFault>>;
    fn write_atomic<'a>(
        &'a self,
        path: &'a VPath,
        data: Bytes,
        durability: Durability,
        ctx: &'a IoContext,
    ) -> BoxFuture<'a, Result<(), IoFault>>;
    fn rename<'a>(
        &'a self,
        from: &'a VPath,
        to: &'a VPath,
        durability: Durability,
        ctx: &'a IoContext,
    ) -> BoxFuture<'a, Result<(), IoFault>>;
    fn remove<'a>(
        &'a self,
        path: &'a VPath,
        ctx: &'a IoContext,
    ) -> BoxFuture<'a, Result<(), IoFault>>;
    fn stat<'a>(
        &'a self,
        path: &'a VPath,
        ctx: &'a IoContext,
    ) -> BoxFuture<'a, Result<Option<Meta>, IoFault>>;
    /// Stat many paths in **one** logical port call (`ADR-054`).
    ///
    /// The output is the same length and order as the input; each entry is exactly the
    /// `Option<Meta>` a one-by-one [`Fs::stat`] would answer (`None` = absent). The `Err`
    /// semantics are the same as `stat`'s: a whole-batch failure (cancelled context, poisoned
    /// lock, real IO error) is an `Err`; per-path absence is a value, never an error. An
    /// empty input answers `Ok(vec![])` without touching anything.
    ///
    /// The single-call shape is the point: a caller that must learn N facts pays one port
    /// operation, not N round trips (`ADR-035` §3 rejected enriching `list` and wrote
    /// "批量 stat 属于后续 `stat_many` 的优化" — this is that step). A port may still do
    /// whatever it needs underneath (the std adapter loops `statx`-equivalent calls), but a
    /// *caller* must not pay the adapter's per-call costs N times, and a fault-injection or
    /// locking world reports one operation, not N.
    fn stat_many<'a>(
        &'a self,
        paths: &'a [VPath],
        ctx: &'a IoContext,
    ) -> BoxFuture<'a, Result<Vec<Option<Meta>>, IoFault>>;
    fn link_or_copy<'a>(
        &'a self,
        from: &'a VPath,
        to: &'a VPath,
        ctx: &'a IoContext,
    ) -> BoxFuture<'a, Result<LinkKind, IoFault>>;
    fn lock_exclusive<'a>(
        &'a self,
        path: &'a VPath,
        ctx: &'a IoContext,
    ) -> BoxFuture<'a, Result<FileLock, IoFault>>;

    /// Enumerate the **direct** children of one directory, sorted by relative path.
    ///
    /// Four rules, each one there because its absence was a real problem
    /// (`ADR-035 §2.1`, `docs/history/ONBOARDING_NOTES.md §4.15`):
    ///
    /// * **Sorted.** Recovery scans and gc have to derive the same candidate set from the simulator
    ///   and from a real disk; an OS-order listing would make the deterministic gate
    ///   (`ADR-022`) validate an order the production port does not have.
    /// * **Bounded.** Exceeding `cap` is a `CapacityExceeded` *error*, not a short list. A truncated
    ///   listing that looks complete is how a sweep silently skips work — the same failure this
    ///   port family already refuses for byte reads.
    /// * **One level.** A directory and a file inside it both appear as children; their kind is
    ///   `stat`'s business. Recursing here would push a walk policy into the gateway.
    /// * **`NotFound` for a directory that does not exist, `Ok(vec![])` for an empty one.** `stat`
    ///   answers "is this here?" so "no" is a value; `list` answers "what is in here?", and an empty
    ///   answer to a question about something that does not exist is a lie. The distinction is the
    ///   whole reason the simulator has to track created directories instead of only files.
    fn list<'a>(
        &'a self,
        dir: &'a VPath,
        cap: ListCap,
        ctx: &'a IoContext,
    ) -> BoxFuture<'a, Result<Vec<VPath>, IoFault>>;
}

pub trait Http: Send + Sync + 'static {
    fn fetch<'a>(
        &'a self,
        req: FetchReq,
        ctx: &'a IoContext,
    ) -> BoxFuture<'a, Result<FetchResp, IoFault>>;
}

/// How a child left the process table, as the port may honestly report it (`ADR-043`).
///
/// `code` is the exit code when the child chose to exit, or the signal number when it was
/// killed; `signaled` says which of the two worlds that number belongs to. The pair is the
/// whole truth a wait status carries on unix, and collapsing it into one number (the shell's
/// negative-code convention) would make "exited with code 9" and "killed by signal 9" the
/// same answer to an operator who asked a question they meant to distinguish.
#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub struct ChildExit {
    pub code: i32,
    pub signaled: bool,
}

/// Fire-and-forget spawn plus the minimal supervision surface a real core lifecycle needs
/// (`ADR-043`): poll without blocking, and stop with a deadline.
pub trait Proc: Send + Sync + 'static {
    fn spawn<'a>(
        &'a self,
        spec: SpawnSpec,
        ctx: &'a IoContext,
    ) -> BoxFuture<'a, Result<ChildHandle, IoFault>>;

    /// Poll one previously spawned child: `Ok(None)` = still running, never a guess.
    ///
    /// Answers are **monotonic once exited**: after the first `Some`, every later call on the
    /// same handle returns the same exit. A port that forgets an exit between calls would
    /// make "is it gone?" unanswerable exactly when it matters most.
    fn try_wait<'a>(
        &'a self,
        handle: &'a ChildHandle,
    ) -> BoxFuture<'a, Result<Option<ChildExit>, IoFault>>;

    /// Stop one child and report how it left. `grace_ms` is the window the child may use to
    /// exit **by itself** (a core flushing state on shutdown); when it elapses, the port
    /// kills — `std` has exactly one signal (`SIGKILL`), so the graceful `TERM` surface is
    /// future port growth with its own decision, not a behaviour this method may imply.
    ///
    /// A handle this port never handed out (or already reaped and forgot) is `NotFound`
    /// **naming the nonce** — the caller's retry depends on knowing the bookkeeping lost the
    /// child, not on a generic spawn failure.
    fn stop<'a>(
        &'a self,
        handle: &'a ChildHandle,
        grace_ms: u64,
    ) -> BoxFuture<'a, Result<ChildExit, IoFault>>;
}

pub trait Clock: Send + Sync + 'static {
    fn now(&self) -> Timestamp;
    fn mono(&self) -> Monotonic;
    fn sleep_until<'a>(&'a self, at: Monotonic) -> BoxFuture<'a, Result<(), IoFault>>;
}

/// Resolve the caller's deadline in the monotonic clock supplied by the composition root.
///
/// A context's `deadline_ms` is relative to the instant the driving layer starts the operation;
/// `deadline_mono_ms` is already anchored when a higher layer has done that work. With no clock,
/// the relative value cannot be judged honestly and is therefore left unresolved. This helper is
/// shared by the simulated and blocking HTTP ports so they cannot grow different anchoring rules.
pub fn caller_deadline_mono_ms(ctx: &IoContext, clock: Option<&dyn Clock>) -> Option<u64> {
    ctx.deadline_mono_ms.or_else(|| {
        ctx.deadline_ms.and_then(|relative| {
            clock.map(|clock| clock.mono().ticks_millis.saturating_add(relative))
        })
    })
}

/// Check cancellation and an absolute caller deadline at one port boundary.
///
/// The phase is included in the refusal because a caller needs to know which boundary refused the
/// operation; the two ports still share the same kind and clock comparison.
pub fn check_caller_control(
    ctx: &IoContext,
    deadline_mono_ms: Option<u64>,
    clock: Option<&dyn Clock>,
    phase: &str,
) -> Result<(), IoFault> {
    if ctx.cancel.is_cancelled() {
        return Err(IoFault::new(
            IoFaultKind::Cancelled,
            format!("caller cancelled before {phase}"),
        ));
    }
    if let (Some(deadline), Some(clock)) = (deadline_mono_ms, clock) {
        let now = clock.mono().ticks_millis;
        if now >= deadline {
            return Err(IoFault::new(
                IoFaultKind::Timeout,
                format!("caller deadline at mono {deadline} expired at mono {now} before {phase}"),
            ));
        }
    }
    Ok(())
}

pub trait Rand: Send + Sync + 'static {
    fn fill(&self, buf: &mut [u8]);
    fn uuid(&self) -> String;
}

pub trait Keyring: Send + Sync + 'static {
    fn get<'a>(
        &'a self,
        key: &'a str,
        ctx: &'a IoContext,
    ) -> BoxFuture<'a, Result<Option<String>, IoFault>>;
    fn set<'a>(
        &'a self,
        key: &'a str,
        value: String,
        ctx: &'a IoContext,
    ) -> BoxFuture<'a, Result<(), IoFault>>;
    fn delete<'a>(&'a self, key: &'a str, ctx: &'a IoContext)
        -> BoxFuture<'a, Result<(), IoFault>>;
}

pub trait Platform: Send + Sync + 'static {
    fn capabilities(&self) -> PlatformCaps;
    fn apply_network<'a>(
        &'a self,
        plan: NetworkPlan,
        ctx: &'a IoContext,
    ) -> BoxFuture<'a, Result<NetTxnId, IoFault>>;
    fn revert_network<'a>(
        &'a self,
        txn_id: NetTxnId,
        ctx: &'a IoContext,
    ) -> BoxFuture<'a, Result<RevertOutcome, IoFault>>;
}
