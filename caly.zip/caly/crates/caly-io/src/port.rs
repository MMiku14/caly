use std::future::Future;
use std::pin::Pin;

use caly_common::RequestContext;

use crate::{IoFault, VPath};

pub type BoxFuture<'a, T> = Pin<Box<dyn Future<Output = T> + Send + 'a>>;
pub type Bytes = Vec<u8>;
pub type IoContext = RequestContext;

#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub struct ByteCap(pub u64);

/// How many entries [`Fs::list`] may return before it is a problem rather than an answer.
///
/// Same reasoning as [`ByteCap`]: an operation whose result size is decided by the world needs a
/// budget the caller sets, because the alternative is a call that succeeds by returning
/// "everything that happened to fit". `ADR-035 §2.1`.
#[derive(Clone, Copy, Debug, Eq, PartialEq, Ord, PartialOrd)]
pub struct ListCap(pub u32);

#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub enum Durability {
    D0,
    D1,
    D2,
    D3,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct ByteStream {
    pub label: String,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct Meta {
    pub len: u64,
    pub is_file: bool,
    pub is_dir: bool,
    /// When this path was last successfully written, in unix milliseconds.
    ///
    /// `Option` because not every port can answer cheaply: a real filesystem records it, a simulated
    /// world only has it if it was given a clock (`ADR-035 §2.2`). The semantic is *"the last
    /// successful `write_atomic`"*, as recorded by the port itself — never a host reading smuggled in
    /// from somewhere else, because the simulator is the release gate (`ADR-022`) and a fabricated
    /// wall clock there would make timeout and grace-period behaviour unreproducible.
    ///
    /// A port must be consistent about it: `None` for one file and `Some` for another in the same
    /// world is a bug, not flexibility (enforced by `contract::fs_mtime_violations`).
    pub modified_at_unix_ms: Option<i64>,
}

#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub enum LinkKind {
    Reflink,
    Hardlink,
    Copy,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct FileLock {
    pub path: String,
}

#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub enum FetchRoute {
    Direct,
    SystemProxy,
    ActiveCore,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct FetchReq {
    pub url: String,
    pub route: FetchRoute,
    pub etag: Option<String>,
    pub if_modified_since: Option<String>,
    pub max_body_bytes: u64,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct FetchResp {
    pub status: u16,
    pub etag: Option<String>,
    pub last_modified: Option<String>,
    pub body: ByteStream,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct ChildHandle {
    pub pid: u32,
    pub instance_nonce: String,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct SpawnSpec {
    pub program: String,
    pub argv: Vec<String>,
    pub cwd: Option<VPath>,
    pub env: Vec<(String, String)>,
}

#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub struct Timestamp {
    pub unix_millis: i64,
}

#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub struct Monotonic {
    pub ticks_millis: u64,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct PlatformCaps {
    pub tun: bool,
    pub system_proxy: bool,
    pub dns_override: bool,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct NetworkPlan {
    pub summary: String,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct NetTxnId(pub String);

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct RevertOutcome {
    pub restored: bool,
    pub summary: String,
}

pub trait Fs: Send + Sync + 'static {
    fn read<'a>(
        &'a self,
        path: &'a VPath,
        cap: ByteCap,
        ctx: &'a IoContext,
    ) -> BoxFuture<'a, Result<Bytes, IoFault>>;
    fn open_stream<'a>(
        &'a self,
        path: &'a VPath,
        ctx: &'a IoContext,
    ) -> BoxFuture<'a, Result<ByteStream, IoFault>>;
    fn write_atomic<'a>(
        &'a self,
        path: &'a VPath,
        data: Bytes,
        durability: Durability,
        ctx: &'a IoContext,
    ) -> BoxFuture<'a, Result<(), IoFault>>;
    fn rename<'a>(
        &'a self,
        from: &'a VPath,
        to: &'a VPath,
        durability: Durability,
        ctx: &'a IoContext,
    ) -> BoxFuture<'a, Result<(), IoFault>>;
    fn remove<'a>(
        &'a self,
        path: &'a VPath,
        ctx: &'a IoContext,
    ) -> BoxFuture<'a, Result<(), IoFault>>;
    fn stat<'a>(
        &'a self,
        path: &'a VPath,
        ctx: &'a IoContext,
    ) -> BoxFuture<'a, Result<Option<Meta>, IoFault>>;
    fn link_or_copy<'a>(
        &'a self,
        from: &'a VPath,
        to: &'a VPath,
        ctx: &'a IoContext,
    ) -> BoxFuture<'a, Result<LinkKind, IoFault>>;
    fn lock_exclusive<'a>(
        &'a self,
        path: &'a VPath,
        ctx: &'a IoContext,
    ) -> BoxFuture<'a, Result<FileLock, IoFault>>;

    /// Enumerate the **direct** children of one directory, sorted by relative path.
    ///
    /// Four rules, each one there because its absence was a real problem
    /// (`ADR-035 §2.1`, `docs/ONBOARDING_NOTES.md §4.15`):
    ///
    /// * **Sorted.** Recovery scans and gc have to derive the same candidate set from the simulator
    ///   and from a real disk; an OS-order listing would make the deterministic gate
    ///   (`ADR-022`) validate an order the production port does not have.
    /// * **Bounded.** Exceeding `cap` is a `CapacityExceeded` *error*, not a short list. A truncated
    ///   listing that looks complete is how a sweep silently skips work — the same failure this
    ///   port family already refuses for byte reads.
    /// * **One level.** A directory and a file inside it both appear as children; their kind is
    ///   `stat`'s business. Recursing here would push a walk policy into the gateway.
    /// * **`NotFound` for a directory that does not exist, `Ok(vec![])` for an empty one.** `stat`
    ///   answers "is this here?" so "no" is a value; `list` answers "what is in here?", and an empty
    ///   answer to a question about something that does not exist is a lie. The distinction is the
    ///   whole reason the simulator has to track created directories instead of only files.
    fn list<'a>(
        &'a self,
        dir: &'a VPath,
        cap: ListCap,
        ctx: &'a IoContext,
    ) -> BoxFuture<'a, Result<Vec<VPath>, IoFault>>;
}

pub trait Http: Send + Sync + 'static {
    fn fetch<'a>(
        &'a self,
        req: FetchReq,
        ctx: &'a IoContext,
    ) -> BoxFuture<'a, Result<FetchResp, IoFault>>;
}

pub trait Proc: Send + Sync + 'static {
    fn spawn<'a>(
        &'a self,
        spec: SpawnSpec,
        ctx: &'a IoContext,
    ) -> BoxFuture<'a, Result<ChildHandle, IoFault>>;
}

pub trait Clock: Send + Sync + 'static {
    fn now(&self) -> Timestamp;
    fn mono(&self) -> Monotonic;
    fn sleep_until<'a>(&'a self, at: Monotonic) -> BoxFuture<'a, Result<(), IoFault>>;
}

pub trait Rand: Send + Sync + 'static {
    fn fill(&self, buf: &mut [u8]);
    fn uuid(&self) -> String;
}

pub trait Keyring: Send + Sync + 'static {
    fn get<'a>(
        &'a self,
        key: &'a str,
        ctx: &'a IoContext,
    ) -> BoxFuture<'a, Result<Option<String>, IoFault>>;
    fn set<'a>(
        &'a self,
        key: &'a str,
        value: String,
        ctx: &'a IoContext,
    ) -> BoxFuture<'a, Result<(), IoFault>>;
    fn delete<'a>(&'a self, key: &'a str, ctx: &'a IoContext)
        -> BoxFuture<'a, Result<(), IoFault>>;
}

pub trait Platform: Send + Sync + 'static {
    fn capabilities(&self) -> PlatformCaps;
    fn apply_network<'a>(
        &'a self,
        plan: NetworkPlan,
        ctx: &'a IoContext,
    ) -> BoxFuture<'a, Result<NetTxnId, IoFault>>;
    fn revert_network<'a>(
        &'a self,
        txn_id: NetTxnId,
        ctx: &'a IoContext,
    ) -> BoxFuture<'a, Result<RevertOutcome, IoFault>>;
}
