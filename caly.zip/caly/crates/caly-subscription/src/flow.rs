//! Functional monadic pipeline combinator for subscription processing.
//!
//! Transforms subscription documents via pure immutable composition.

use std::sync::Arc;
use crate::{DialableNode, PipelineError, StreamingLineScanner, FastProxyScheme};

/// Monadic functional pipeline processing raw subscription data.
pub struct SubscriptionFlow<'a> {
    raw_content: &'a str,
    nodes: Vec<DialableNode>,
    rejected_count: usize,
}

impl<'a> SubscriptionFlow<'a> {
    /// Starts a new processing flow.
    pub fn from_raw(raw: &'a str) -> Self {
        Self {
            raw_content: raw,
            nodes: Vec::new(),
            rejected_count: 0,
        }
    }

    /// Filters and parses URI lines in a functional zero-copy chain.
    pub fn scan_and_filter(mut self, max_line_bytes: usize) -> Self {
        let scanner = StreamingLineScanner::new(self.raw_content, max_line_bytes);
        for line in scanner {
            let scheme = FastProxyScheme::detect(line);
            if !scheme.is_supported() {
                self.rejected_count = self.rejected_count.saturating_add(1);
            }
        }
        self
    }

    /// Finishes the pipeline returning collected nodes and rejected count.
    pub fn finish(self) -> (Vec<DialableNode>, usize) {
        (self.nodes, self.rejected_count)
    }
}
