//! Zero-copy streaming scanner for subscription bodies.
//!
//! Avoids allocating thousands of `BoundedText` heap strings when scanning
//! large proxy node lists (SIP008, Clash, URI lines).

use core::str::Lines;

/// Zero-copy streaming line scanner with comment stripping and length bounds.
pub struct StreamingLineScanner<'a> {
    lines: Lines<'a>,
    max_line_bytes: usize,
    skipped_comments: usize,
    rejected_too_long: usize,
}

impl<'a> StreamingLineScanner<'a> {
    /// Creates a new scanner for raw UTF-8 string content.
    pub fn new(content: &'a str, max_line_bytes: usize) -> Self {
        Self {
            lines: content.lines(),
            max_line_bytes,
            skipped_comments: 0,
            rejected_too_long: 0,
        }
    }

    /// Number of comment lines skipped (# or ;).
    pub fn skipped_comments(&self) -> usize {
        self.skipped_comments
    }

    /// Number of lines rejected because they exceeded max_line_bytes.
    pub fn rejected_too_long(&self) -> usize {
        self.rejected_too_long
    }
}

impl<'a> Iterator for StreamingLineScanner<'a> {
    type Item = &'a str;

    fn next(&mut self) -> Option<Self::Item> {
        while let Some(raw_line) = self.lines.next() {
            let trimmed = raw_line.trim();
            if trimmed.is_empty() {
                continue;
            }
            if trimmed.starts_with('#') || trimmed.starts_with(';') {
                self.skipped_comments = self.skipped_comments.saturating_add(1);
                continue;
            }
            if trimmed.len() > self.max_line_bytes {
                self.rejected_too_long = self.rejected_too_long.saturating_add(1);
                continue;
            }
            return Some(trimmed);
        }
        None
    }
}

/// Fast non-allocating proxy URI scheme detector.
#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub enum FastProxyScheme {
    Shadowsocks,
    Vmess,
    Vless,
    Trojan,
    Hysteria2,
    Tuic,
    Ssr,
    Unknown,
}

impl FastProxyScheme {
    /// Detects proxy protocol scheme from URI prefix without allocation.
    pub fn detect(uri: &str) -> Self {
        let lower_prefix = uri.split("://").next().unwrap_or("");
        if lower_prefix.eq_ignore_ascii_case("ss") {
            Self::Shadowsocks
        } else if lower_prefix.eq_ignore_ascii_case("vmess") {
            Self::Vmess
        } else if lower_prefix.eq_ignore_ascii_case("vless") {
            Self::Vless
        } else if lower_prefix.eq_ignore_ascii_case("trojan") {
            Self::Trojan
        } else if lower_prefix.eq_ignore_ascii_case("hysteria2") || lower_prefix.eq_ignore_ascii_case("hy2") {
            Self::Hysteria2
        } else if lower_prefix.eq_ignore_ascii_case("tuic") {
            Self::Tuic
        } else if lower_prefix.eq_ignore_ascii_case("ssr") {
            Self::Ssr
        } else {
            Self::Unknown
        }
    }

    /// Whether the scheme is representable in current Caly dialable nodes.
    pub fn is_supported(self) -> bool {
        matches!(
            self,
            Self::Shadowsocks
                | Self::Vmess
                | Self::Vless
                | Self::Trojan
                | Self::Hysteria2
                | Self::Tuic
        )
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn streaming_scanner_skips_comments_and_trims() {
        let content = "# Title comment
  ss://YWJj  

; Semicolon comment
vmess://xyz
";
        let mut scanner = StreamingLineScanner::new(content, 1024);
        assert_eq!(scanner.next(), Some("ss://YWJj"));
        assert_eq!(scanner.next(), Some("vmess://xyz"));
        assert_eq!(scanner.next(), None);
        assert_eq!(scanner.skipped_comments(), 2);
    }

    #[test]
    fn scheme_detector_identifies_protocols() {
        assert_eq!(FastProxyScheme::detect("ss://abc"), FastProxyScheme::Shadowsocks);
        assert_eq!(FastProxyScheme::detect("VMESS://abc"), FastProxyScheme::Vmess);
        assert_eq!(FastProxyScheme::detect("hy2://abc"), FastProxyScheme::Hysteria2);
        assert_eq!(FastProxyScheme::detect("ssr://abc"), FastProxyScheme::Ssr);
        assert!(!FastProxyScheme::detect("ssr://abc").is_supported());
        assert!(FastProxyScheme::detect("ss://abc").is_supported());
    }
}
