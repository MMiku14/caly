//! Operator-declared inline entries as a synthetic subscription source.
//!
//! The CLI (`set proxy add …`) round-trips proxy URIs as JSON files
//! under `<state>/inline-proxies/<id>.json`; the daemon folds them
//! into refresh as a reserved [`SubscriptionId`] so operator entries
//! share the subscription pipeline (decode → parse → dedupe → tag →
//! index) instead of growing a parallel intake. Reads are
//! best-effort: a missing directory reads as empty, unreadable files
//! are skipped (the CLI validates on write, and hand-corrupted files
//! must not fail a whole refresh — same ghost-skipping precedent as
//! the subscription cache restore).

use std::path::Path;

use caly_domain::SubscriptionId;

/// State-directory entry holding one JSON file per inline entry.
pub const INLINE_PROXIES_DIR: &str = "inline-proxies";

/// Reserved source id for the folded inline generation. Fixed readable
/// bytes (visible in hex dumps); a hash-derived subscription id
/// collides with it with probability 2^-128.
pub const INLINE_SUBSCRIPTION_ID: SubscriptionId =
    SubscriptionId::from_bytes(*b"caly-inline-src!");

/// Reads every inline entry URI into one `\n`-joined subscription body,
/// sorted by filename so the fold is deterministic across runs.
/// Returns empty when nothing is declared (or readable). Only `uri`
/// is folded — the stored `group` is inert metadata (v1: no pipeline
/// carrier for groups; the fold treats every entry as ungrouped).
pub fn read_inline_body(state_dir: &Path) -> Vec<u8> {
    let dir = state_dir.join(INLINE_PROXIES_DIR);
    let Ok(entries) = std::fs::read_dir(&dir) else {
        return Vec::new();
    };
    let mut files: Vec<_> = entries
        .flatten()
        .map(|entry| entry.path())
        .filter(|path| path.extension().and_then(|e| e.to_str()) == Some("json"))
        .collect();
    files.sort();
    let mut uris: Vec<String> = Vec::new();
    for path in files {
        let Ok(bytes) = std::fs::read(&path) else {
            continue;
        };
        let Ok(value) = serde_json::from_slice::<serde_json::Value>(&bytes) else {
            continue;
        };
        if let Some(uri) = value.get("uri").and_then(|uri| uri.as_str())
            && !uri.is_empty()
        {
            uris.push(uri.to_owned());
        }
    }
    uris.join("\n").into_bytes()
}

#[cfg(test)]
mod tests {
    use super::*;

    /// Reserved id is stable, non-zero and hex-renders readably.
    #[test]
    fn inline_source_id_is_reserved_and_stable() {
        assert_eq!(
            INLINE_SUBSCRIPTION_ID,
            SubscriptionId::from_bytes(*b"caly-inline-src!")
        );
        assert_ne!(INLINE_SUBSCRIPTION_ID.into_bytes(), [0_u8; 16]);
        assert_eq!(
            INLINE_SUBSCRIPTION_ID.to_string(),
            "63616c792d696e6c696e652d73726321"
        );
    }

    fn scratch_dir(case: &str) -> std::path::PathBuf {
        let dir = std::env::temp_dir().join(format!(
            "caly-inline-test-{}-{case}",
            std::process::id()
        ));
        let _ = std::fs::remove_dir_all(&dir);
        std::fs::create_dir_all(dir.join(INLINE_PROXIES_DIR)).expect("scratch dir");
        dir
    }

    #[test]
    fn read_inline_body_joins_uris_sorted_by_filename() {
        let dir = scratch_dir("join");
        let inline = dir.join(INLINE_PROXIES_DIR);
        std::fs::write(
            inline.join("b.json"),
            r#"{"uri":"ss://b","added_at_ms":2}"#,
        )
        .expect("write b");
        std::fs::write(
            inline.join("a.json"),
            r#"{"uri":"trojan://a","group":"G","added_at_ms":1}"#,
        )
        .expect("write a");
        // Noise is skipped, never fatal.
        std::fs::write(inline.join("note.txt"), "ss://ignored").expect("write txt");
        std::fs::write(inline.join("broken.json"), "{oops").expect("write broken");
        std::fs::write(inline.join("empty.json"), r#"{"uri":""}"#).expect("write empty");
        assert_eq!(
            read_inline_body(&dir),
            b"trojan://a\nss://b".to_vec(),
            "sorted by filename, noise skipped"
        );
        let _ = std::fs::remove_dir_all(&dir);
    }

    #[test]
    fn read_inline_body_missing_dir_is_empty() {
        let dir = std::env::temp_dir().join(format!(
            "caly-inline-test-{}-absent",
            std::process::id()
        ));
        let _ = std::fs::remove_dir_all(&dir);
        assert!(read_inline_body(&dir).is_empty());
    }
}
