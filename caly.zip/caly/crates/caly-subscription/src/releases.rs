//! Official kernel-release download (mihomo / sing-box GitHub releases).
//!
//! Unlike [`crate::http::fetch_pinned`] (subscription bodies: redirects
//! disabled, DNS answers pinned, environment proxy off), release assets live
//! behind `/releases/download/` 302s to the asset CDN, so this fetch follows
//! redirects — but ONLY within the release asset-host set below, with a byte
//! cap and (for manifest-pinned releases) a mandatory sha256 check over the
//! downloaded archive. reqwest stays inside this crate: the WAN boundary
//! does not move.
//!
//! Trust notes: TLS verifies every hop; the initial host must be allowlisted
//! (plain `http` is refused except on loopback, which exists only so tests
//! can serve fixtures from a local socket); redirect targets outside the set
//! stop the chain. Manifest installs are additionally pinned by archive +
//! binary sha256; explicit-version installs (no recorded hash) self-verify by
//! executing the binary's version flag and requiring the expected version in
//! its output.

use url::Url;

use super::policy::MAX_REDIRECT_DEPTH;

/// Byte ceiling for a release archive (kernels ship ~10–30 MB; 128 MB
/// leaves headroom while bounding a malicious/compromised response).
pub const RELEASE_MAX_BYTES: u64 = 128 * 1024 * 1024;

/// Hosts a release fetch may start at or be redirected to (see
/// [`RELEASE_HOSTS`]).
/// GitHub release pages plus the asset CDNs they 302 to
/// (`release-assets` is current; `objects` is the legacy tail).
const RELEASE_HOSTS: &[&str] = &[
    "github.com",
    "release-assets.githubusercontent.com",
    "objects.githubusercontent.com",
];

#[derive(Clone, Debug, PartialEq)]
pub enum ReleaseFetchError {
    InvalidUrl,
    /// The initial URL's host is outside [`RELEASE_HOSTS`] (and not
    /// loopback): we never fetch release bytes from anywhere else.
    HostRejected,
    /// Underlying transport failure; carries the HTTP client error detail.
    RequestFailed(String),
    UnexpectedStatus(u16),
    BodyTooLarge,
    HashMismatch { expected: String, actual: String },
}

impl core::fmt::Display for ReleaseFetchError {
    fn fmt(&self, formatter: &mut core::fmt::Formatter<'_>) -> core::fmt::Result {
        match self {
            Self::InvalidUrl => formatter.write_str("release URL is invalid"),
            Self::HostRejected => formatter.write_str(
                "release URL host is not an official release host (github.com)",
            ),
            Self::RequestFailed(reason) => write!(formatter, "HTTP request failed: {reason}"),
            Self::UnexpectedStatus(status) => {
                write!(formatter, "release host returned HTTP {status}")
            }
            Self::BodyTooLarge => formatter.write_str("release archive exceeds 128 MiB"),
            Self::HashMismatch { expected, actual } => write!(
                formatter,
                "archive sha256 mismatch (expected {expected}, got {actual})"
            ),
        }
    }
}

impl std::error::Error for ReleaseFetchError {}

/// Downloads release bytes from `url`, following redirects only inside the
/// asset-host set. `expected_sha256` (hex, case-insensitive) pins the
/// archive when the manifest records it; `None` skips the hash gate (the
/// caller must self-verify the binary instead).
pub async fn fetch_release(
    url: &str,
    expected_sha256: Option<&str>,
) -> Result<Vec<u8>, ReleaseFetchError> {
    let parsed = Url::parse(url).map_err(|_| ReleaseFetchError::InvalidUrl)?;
    let host = parsed.host_str().ok_or(ReleaseFetchError::InvalidUrl)?;
    let loopback = is_loopback_host(host);
    if !loopback && !RELEASE_HOSTS.iter().any(|known| host.eq_ignore_ascii_case(known)) {
        return Err(ReleaseFetchError::HostRejected);
    }
    if parsed.scheme() != "https" && !(loopback && parsed.scheme() == "http") {
        return Err(ReleaseFetchError::InvalidUrl);
    }
    let client = reqwest::Client::builder()
        .connect_timeout(std::time::Duration::from_secs(30))
        .timeout(std::time::Duration::from_secs(300))
        .no_proxy()
        .redirect(reqwest::redirect::Policy::custom(|attempt| {
            let too_deep = attempt.previous().len() >= MAX_REDIRECT_DEPTH;
            let allowed = attempt.url().host_str().is_some_and(|target| {
                is_loopback_host(target)
                    || RELEASE_HOSTS
                        .iter()
                        .any(|known| target.eq_ignore_ascii_case(known))
            });
            if too_deep || !allowed {
                attempt.stop()
            } else {
                attempt.follow()
            }
        }))
        .build()
        .map_err(|error| ReleaseFetchError::RequestFailed(error.to_string()))?;
    let mut response = client
        .get(parsed)
        .send()
        .await
        .map_err(|error| ReleaseFetchError::RequestFailed(error.to_string()))?;
    if !response.status().is_success() {
        return Err(ReleaseFetchError::UnexpectedStatus(
            response.status().as_u16(),
        ));
    }
    if response
        .content_length()
        .is_some_and(|length| length > RELEASE_MAX_BYTES)
    {
        return Err(ReleaseFetchError::BodyTooLarge);
    }
    let mut body = Vec::new();
    while let Some(chunk) = response
        .chunk()
        .await
        .map_err(|error| ReleaseFetchError::RequestFailed(error.to_string()))?
    {
        if body.len().saturating_add(chunk.len()) > RELEASE_MAX_BYTES as usize {
            return Err(ReleaseFetchError::BodyTooLarge);
        }
        body.extend_from_slice(&chunk);
    }
    if let Some(expected) = expected_sha256 {
        let actual = hex_sha256(&body);
        if !actual.eq_ignore_ascii_case(expected) {
            return Err(ReleaseFetchError::HashMismatch {
                expected: expected.to_owned(),
                actual,
            });
        }
    }
    Ok(body)
}

fn is_loopback_host(host: &str) -> bool {
    host.eq_ignore_ascii_case("localhost")
        || host.eq_ignore_ascii_case("127.0.0.1")
        || host.eq_ignore_ascii_case("::1")
}

fn hex_sha256(bytes: &[u8]) -> String {
    use sha2::{Digest, Sha256};
    let mut hasher = Sha256::new();
    hasher.update(bytes);
    let digest = hasher.finalize();
    let mut out = String::with_capacity(digest.len() * 2);
    for byte in digest {
        use std::fmt::Write as _;
        let _ = write!(out, "{byte:02x}");
    }
    out
}

#[cfg(test)]
mod tests {
    use super::*;

    #[tokio::test]
    async fn host_allowlist_rejects_third_parties() {
        let error = fetch_release("https://example.com/mihomo.gz", None)
            .await
            .expect_err("third-party host must be rejected");
        assert_eq!(error, ReleaseFetchError::HostRejected);
    }

    #[tokio::test]
    async fn plain_http_is_rejected_off_loopback() {
        let error = fetch_release("http://github.com/MetaCubeX/mihomo/x.gz", None)
            .await
            .expect_err("plain http to github must be rejected");
        assert_eq!(error, ReleaseFetchError::InvalidUrl);
    }

    #[tokio::test]
    async fn hash_mismatch_names_both_digests() {
        let listener = tokio::net::TcpListener::bind("127.0.0.1:0")
            .await
            .expect("bind loopback");
        let address = listener.local_addr().expect("local addr");
        tokio::spawn(async move {
            let (mut socket, _) = listener.accept().await.expect("accept");
            use tokio::io::{AsyncReadExt as _, AsyncWriteExt as _};
            let mut request = vec![0u8; 1024];
            let _ = socket.read(&mut request).await;
            let body = b"fake-archive-bytes";
            let head = format!(
                "HTTP/1.1 200 OK\r\ncontent-length: {}\r\nconnection: close\r\n\r\n",
                body.len()
            );
            let _ = socket.write_all(head.as_bytes()).await;
            let _ = socket.write_all(body).await;
        });
        let error = fetch_release(&format!("http://{address}/x.gz"), Some("00"))
            .await
            .expect_err("wrong hash must fail");
        match error {
            ReleaseFetchError::HashMismatch { expected, actual } => {
                assert_eq!(expected, "00");
                assert_eq!(actual, hex_sha256(b"fake-archive-bytes"));
            }
            other => panic!("expected HashMismatch, got {other:?}"),
        }
    }

    #[tokio::test]
    async fn loopback_fetch_returns_bytes_without_a_pin() {
        let listener = tokio::net::TcpListener::bind("127.0.0.1:0")
            .await
            .expect("bind loopback");
        let address = listener.local_addr().expect("local addr");
        tokio::spawn(async move {
            let (mut socket, _) = listener.accept().await.expect("accept");
            use tokio::io::{AsyncReadExt as _, AsyncWriteExt as _};
            let mut request = vec![0u8; 1024];
            let _ = socket.read(&mut request).await;
            let body = b"fake-archive-bytes";
            let head = format!(
                "HTTP/1.1 200 OK\r\ncontent-length: {}\r\nconnection: close\r\n\r\n",
                body.len()
            );
            let _ = socket.write_all(head.as_bytes()).await;
            let _ = socket.write_all(body).await;
        });
        let bytes = fetch_release(&format!("http://{address}/x.gz"), None)
            .await
            .expect("loopback fetch works");
        assert_eq!(bytes, b"fake-archive-bytes");
    }
}
