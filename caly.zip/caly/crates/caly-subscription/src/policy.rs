//! Subscription fetch security and resource policy.

use std::{net::IpAddr, time::Duration};

use caly_domain::BoundedVec;

/// Maximum DNS answers pinned for one fetch.
pub const MAX_DNS_ANSWERS: usize = 32;
pub type ResolvedAddresses = BoundedVec<IpAddr, MAX_DNS_ANSWERS>;

/// Maximum redirect hops followed when `redirects_allowed` is enabled.
pub const MAX_REDIRECT_DEPTH: usize = 3;

/// Only HTTP(S) subscription schemes are accepted.
#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub enum SubscriptionScheme {
    Http,
    Https,
}

/// Fail-closed fetch policy.
#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub struct FetchPolicy {
    pub connect_timeout: Duration,
    pub request_timeout: Duration,
    pub max_body_bytes: usize,
    pub redirects_allowed: bool,
    pub use_environment_proxy: bool,
}

impl FetchPolicy {
    /// Safe direct-fetch defaults.
    pub const fn direct_default() -> Self {
        Self {
            connect_timeout: Duration::from_secs(5),
            request_timeout: Duration::from_secs(30),
            max_body_bytes: 32 * 1_024 * 1_024,
            redirects_allowed: false,
            use_environment_proxy: false,
        }
    }
}

/// Classifier supplied by the networking infrastructure and tested independently.
pub trait AddressClassifier {
    fn is_globally_routable(&self, address: IpAddr) -> bool;
}

/// Resolution rejection before a connection is opened.
#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub enum ResolutionError {
    NoAddresses,
    NonPublicAddress(IpAddr),
}

/// Requires every answer to be public; caller must pin the accepted set.
pub fn validate_resolved(
    addresses: ResolvedAddresses,
    classifier: &impl AddressClassifier,
) -> Result<ResolvedAddresses, ResolutionError> {
    if addresses.is_empty() {
        return Err(ResolutionError::NoAddresses);
    }
    for address in &addresses {
        if !classifier.is_globally_routable(*address) {
            return Err(ResolutionError::NonPublicAddress(*address));
        }
    }
    Ok(addresses)
}

/// Operational state of an adaptive circuit breaker for subscription fetches.
#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub enum CircuitBreakerState {
    /// Normal operation: requests proceed directly.
    Closed,
    /// Failing upstream: requests are temporarily tripped and rejected immediately.
    Open,
    /// Probing upstream: a single canary request is permitted to test recovery.
    HalfOpen,
}

/// Adaptive exponential backoff circuit breaker protecting upstream subscription endpoints.
#[derive(Clone, Debug)]
pub struct SubscriptionCircuitBreaker {
    failure_threshold: u32,
    failure_count: u32,
    state: CircuitBreakerState,
    base_backoff: Duration,
    max_backoff: Duration,
    last_failure_elapsed: Option<Duration>,
    current_backoff: Duration,
    half_open_probes_active: u32,
    max_half_open_probes: u32,
}

impl SubscriptionCircuitBreaker {
    /// Creates a new circuit breaker with default parameters.
    pub fn new(failure_threshold: u32, base_backoff: Duration, max_backoff: Duration) -> Self {
        Self {
            failure_threshold,
            failure_count: 0,
            state: CircuitBreakerState::Closed,
            base_backoff,
            max_backoff,
            last_failure_elapsed: None,
            current_backoff: base_backoff,
            half_open_probes_active: 0,
            max_half_open_probes: 1,
        }
    }

    /// Whether an outgoing fetch request is permitted by the circuit policy.
    pub fn allow_request(&self) -> bool {
        match self.state {
            CircuitBreakerState::Closed => true,
            CircuitBreakerState::HalfOpen => self.half_open_probes_active < self.max_half_open_probes,
            CircuitBreakerState::Open => false,
        }
    }

    /// Checks if a request is permitted given elapsed time since last failure,
    /// automatically transitioning from  to  when cooldown expires.
    pub fn check_and_allow(&mut self, elapsed_since_failure: Option<Duration>) -> bool {
        match self.state {
            CircuitBreakerState::Closed => true,
            CircuitBreakerState::Open => {
                if let Some(elapsed) = elapsed_since_failure.or(self.last_failure_elapsed) {
                    if elapsed >= self.current_backoff {
                        self.state = CircuitBreakerState::HalfOpen;
                        self.half_open_probes_active = 1;
                        return true;
                    }
                }
                false
            }
            CircuitBreakerState::HalfOpen => {
                if self.half_open_probes_active < self.max_half_open_probes {
                    self.half_open_probes_active = self.half_open_probes_active.saturating_add(1);
                    true
                } else {
                    false
                }
            }
        }
    }

    /// Records a successful fetch, resetting failure counters and closing the circuit.
    pub fn record_success(&mut self) {
        self.failure_count = 0;
        self.state = CircuitBreakerState::Closed;
        self.half_open_probes_active = 0;
        self.current_backoff = self.base_backoff;
        self.last_failure_elapsed = None;
    }

    /// Records a failed fetch, tripping the circuit to Open if threshold is reached.
    pub fn record_failure(&mut self) -> Duration {
        self.failure_count = self.failure_count.saturating_add(1);
        self.half_open_probes_active = 0;
        if self.failure_count >= self.failure_threshold || self.state == CircuitBreakerState::HalfOpen {
            self.state = CircuitBreakerState::Open;
        }
        let factor = 2u32.saturating_pow(self.failure_count.min(6));
        let backoff = self.base_backoff.saturating_mul(factor);
        self.current_backoff = backoff.min(self.max_backoff);
        self.last_failure_elapsed = Some(Duration::ZERO);
        self.current_backoff
    }

    /// Updates elapsed cooldown duration for deterministic progression.
    pub fn advance_cooldown(&mut self, delta: Duration) {
        if let Some(elapsed) = self.last_failure_elapsed.as_mut() {
            *elapsed = elapsed.saturating_add(delta);
        }
    }

    /// Current circuit state.
    pub fn state(&self) -> CircuitBreakerState {
        self.state
    }

    /// Current backoff duration.
    pub fn current_backoff(&self) -> Duration {
        self.current_backoff
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn circuit_breaker_lifecycle() {
        let mut cb = SubscriptionCircuitBreaker::new(
            3,
            Duration::from_secs(1),
            Duration::from_secs(30),
        );
        assert!(cb.allow_request());
        assert_eq!(cb.state(), CircuitBreakerState::Closed);

        // 2 failures: still closed
        cb.record_failure();
        cb.record_failure();
        assert!(cb.allow_request());
        assert_eq!(cb.state(), CircuitBreakerState::Closed);

        // 3rd failure: trips to Open
        let backoff = cb.record_failure();
        assert_eq!(cb.state(), CircuitBreakerState::Open);
        assert!(!cb.allow_request());
        assert!(backoff >= Duration::from_secs(1));

        // Cooldown not yet expired
        assert!(!cb.check_and_allow(Some(Duration::from_millis(500))));

        // Cooldown expired: transitions to HalfOpen and allows single probe
        assert!(cb.check_and_allow(Some(Duration::from_secs(10))));
        assert_eq!(cb.state(), CircuitBreakerState::HalfOpen);

        // Success closes circuit
        cb.record_success();
        assert_eq!(cb.state(), CircuitBreakerState::Closed);
        assert!(cb.allow_request());
    }
}
