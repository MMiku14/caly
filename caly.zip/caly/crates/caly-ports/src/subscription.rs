//! SubscriptionActor refresh port.

use caly_domain::{SnapshotNodes, SubscriptionId};

use super::error::ActorFailure;

/// Nonblocking backend owning fetch/parse/cache generation work.
pub trait SubscriptionCommandBackend {
    fn refresh(&mut self, subscription: SubscriptionId) -> Result<SnapshotNodes, ActorFailure>;
}
