//! Live kernel query port for daemon-mediated connection views.

use std::time::Duration;

use caly_domain::LiveConnection;

use super::error::ActorFailure;

/// Owns a controller enough to answer live connection-detail queries.
///
/// This is intentionally narrower than the full kernel control trait: flow
/// UIs need connection details, while telemetry and lifecycle own their own
/// control surfaces. Implementations must bound controller I/O and map
/// kernel-specific payloads onto [`LiveConnection`].
pub trait LiveConnectionQuery: Send {
    fn connection_details(
        &mut self,
        timeout: Duration,
    ) -> Result<Vec<LiveConnection>, ActorFailure>;
}
