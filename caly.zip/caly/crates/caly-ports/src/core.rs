//! CoreActor command port: proxy selection and connection close.

use caly_domain::{AppliedState, NodeId, ObservedState};

use super::error::ActorFailure;

/// Nonblocking CoreActor backend; process/API I/O belongs to its owned worker.
pub trait CoreCommandBackend {
    fn select_proxy(&mut self, node: NodeId) -> Result<AppliedState, ActorFailure>;
    fn close_all_connections(&mut self) -> Result<ObservedState, ActorFailure>;
    /// Applies a routing mode to the running core and returns the new applied state.
    fn set_mode(&mut self, mode: caly_domain::ProxyMode) -> Result<AppliedState, ActorFailure>;
}
