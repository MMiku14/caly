//! Shared actor ports and the common bounded error type.
//!
//! This crate sits at the bottom of the product layer (above `caly-domain`) and
//! defines the trait boundaries that owner actors depend on and that concrete
//! adapters implement. Neither the application use-case crate nor the backend
//! adapters need to know each other's concrete types.
//!
//! # Why this crate is a separate workspace member
//!
//! Round 32 considered inlining the ports into `caly-application` (treating
//! the trait boundaries as application-internal) and removing the workspace
//! member. The inlining was attempted and reverted: `caly-application`
//! prod-deps `caly-backends` (it consumes the concrete `HttpSubscriptionBackend`
//! / `LinuxSystemProxyBackend` / `TemplateRenderBackend` structs in
//! `composition::backends`), and `caly-backends` prod-deps the port traits
//! here (it `impl PlatformCommandBackend for LinuxSystemProxyBackend` and
//! friends). Inlining the ports into `caly-application` would require
//! `caly-backends` to `use caly_application::ports::…`, which is a workspace
//! dependency cycle: `application` would depend on `backends` (for the
//! concrete backend types) and `backends` would depend on `application`
//! (for the port traits). `cargo` rejects the cycle at the metadata level,
//! so the only viable shape is for the ports to live in a third crate that
//! both `application` and `backends` depend on. This crate is that third
//! crate.
//!
//! A future round that abstracts the application-to-backends binding behind
//! a trait (so the application no longer names the concrete backend
//! structs) could revisit the inlining. Until then, the port crate stays
//! a separate workspace member.

#![forbid(unsafe_code)]

pub mod config;
pub mod core;
pub mod error;
pub mod lifecycle;
pub mod platform;
pub mod subscription;
pub mod telemetry;
pub mod tun;

pub use config::{CommittedConfig, ConfigActorPort, ConfigCandidate, PreparedConfig};
pub use core::CoreCommandBackend;
pub use error::{ActorFailure, ActorFailureKind, FailureMessage};
pub use lifecycle::CoreLifecycleCommandBackend;
pub use platform::PlatformCommandBackend;
pub use subscription::SubscriptionCommandBackend;
pub use telemetry::TelemetryCommandBackend;
pub use tun::TunCommandBackend;
