//! Core lifecycle command port.

use std::time::Duration;

use caly_domain::{AppliedState, CoreKind};

use super::error::ActorFailure;

/// Result of a config apply/reload against the running kernel.
#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub enum CoreReloadOutcome {
    /// The kernel accepted the new config without a process restart.
    Reloaded,
    /// The kernel has no hot-reload surface and was restarted instead.
    Restarted,
}

/// Concrete process lifecycle operations supplied by the kernel backend.
pub trait CoreLifecycleCommandBackend {
    fn start(&mut self) -> Result<AppliedState, ActorFailure>;
    fn stop(&mut self) -> Result<AppliedState, ActorFailure>;
    fn restart(&mut self) -> Result<AppliedState, ActorFailure>;

    /// Reloads the active core's config. Kernels with a Clash-compatible
    /// config-write endpoint return [`CoreReloadOutcome::Reloaded`]; kernels
    /// without one may perform an internal restart and return
    /// [`CoreReloadOutcome::Restarted`]. An `Err` leaves the restart fallback
    /// (and rollback) to the caller.
    fn hot_reload(&mut self, config: &[u8], timeout: Duration)
    -> Result<CoreReloadOutcome, String>;

    /// Switches the active core to `target`, stopping the previous kernel.
    /// Single-core backends fall back to a restart of the active kernel.
    fn switch_to(&mut self, target: CoreKind) -> Result<AppliedState, ActorFailure> {
        let _ = target;
        self.restart()
    }
}
