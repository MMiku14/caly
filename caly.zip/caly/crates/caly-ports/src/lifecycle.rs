//! Core lifecycle command port.

use caly_domain::{AppliedState, CoreKind};

use super::error::ActorFailure;

/// Concrete process lifecycle operations supplied by the kernel backend.
pub trait CoreLifecycleCommandBackend {
    fn start(&mut self) -> Result<AppliedState, ActorFailure>;
    fn stop(&mut self) -> Result<AppliedState, ActorFailure>;
    fn restart(&mut self) -> Result<AppliedState, ActorFailure>;

    /// Switches the active core to `target`, stopping the previous kernel.
    /// Single-core backends fall back to a restart of the active kernel.
    fn switch_to(&mut self, target: CoreKind) -> Result<AppliedState, ActorFailure> {
        let _ = target;
        self.restart()
    }
}
