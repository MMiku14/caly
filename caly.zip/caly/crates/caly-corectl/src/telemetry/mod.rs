//! Bounded kernel telemetry decode policy.

/// Per-frame and per-line limits before parsing dynamic kernel output.
#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub struct TelemetryLimits {
    pub max_frame_bytes: usize,
    pub max_log_line_bytes: usize,
    pub max_connections: usize,
}

impl TelemetryLimits {
    pub const fn secure_default() -> Self {
        Self {
            max_frame_bytes: 1_048_576,
            max_log_line_bytes: 64 * 1_024,
            max_connections: 10_000,
        }
    }
}

/// Explicit outcome for permitted coalescing/drop policies.
#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub enum TelemetryAdmission {
    Accepted,
    Coalesced { dropped: u64 },
    RejectedOversize,
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn secure_defaults_are_bounded() {
        let limits = TelemetryLimits::secure_default();
        assert_eq!(limits.max_frame_bytes, 1_048_576);
        assert_eq!(limits.max_log_line_bytes, 65_536);
        assert_eq!(limits.max_connections, 10_000);
    }
}
