//! Re-export facade: caly-coreconf has been consolidated into caly-corectl::conf.
//! All configuration renderers and models are re-exported here for backward compatibility.

#![forbid(unsafe_code)]
#![cfg_attr(test, allow(clippy::unwrap_used, clippy::expect_used, clippy::panic, clippy::todo, clippy::unimplemented, clippy::unreachable))]

pub use caly_corectl::conf::*;
