//! Rich Mihomo Clash-compatible API adapters (proxy groups, connections,
//! traffic). Kept separate from the minimal HTTP transport in `http.rs` so
//! each file stays within the project's line limits.

use std::{io::Read, time::Duration};

use crate::contract::{ConnectionSummary, KernelFailure, ProxyGroup};

use super::http::MihomoHttpControl;

impl MihomoHttpControl {
    /// Lists proxy groups and their current selection from `GET /proxies`.
    pub fn list_proxy_groups(&self, timeout: Duration) -> Result<Vec<ProxyGroup>, KernelFailure> {
        let body = self.request("/proxies", timeout)?;
        let json = super::http::response_json(&body)?;
        let Some(proxies) = json.get("proxies").and_then(serde_json::Value::as_object) else {
            return Ok(Vec::new());
        };
        let mut groups = Vec::new();
        for (name, value) in proxies {
            let is_group = matches!(
                value.get("type").and_then(serde_json::Value::as_str),
                Some("Selector" | "URLTest" | "Fallback" | "LoadBalance")
            );
            if !is_group {
                continue;
            }
            let selected = value
                .get("now")
                .and_then(serde_json::Value::as_str)
                .map(str::to_owned);
            groups.push(ProxyGroup {
                name: name.clone(),
                selected,
            });
        }
        Ok(groups)
    }

    /// Summarizes active connections from `GET /connections`.
    pub fn connection_summary(
        &self,
        timeout: Duration,
    ) -> Result<ConnectionSummary, KernelFailure> {
        let body = self.request("/connections", timeout)?;
        let json = super::http::response_json(&body)?;
        let Some(connections) = json
            .get("connections")
            .and_then(serde_json::Value::as_array)
        else {
            return Ok(ConnectionSummary {
                active: 0,
                download_bytes: 0,
                upload_bytes: 0,
            });
        };
        let mut download = 0_u64;
        let mut upload = 0_u64;
        for connection in connections {
            upload = upload.saturating_add(numeric(connection, "upload"));
            download = download.saturating_add(numeric(connection, "download"));
        }
        // Every entry the kernel lists under `/connections` is a *live*
        // connection — filtering by `download > 0` used to drop freshly
        // established or upload-only sessions from the active count.
        let active = u32::try_from(connections.len()).unwrap_or(u32::MAX);
        Ok(ConnectionSummary {
            active,
            download_bytes: download,
            upload_bytes: upload,
        })
    }

    /// Returns the current per-second (download, upload) byte rates from
    /// `GET /traffic`.
    ///
    /// Mihomo's `/traffic` endpoint is an SSE stream: each frame carries the
    /// per-second snapshot in `up`/`down` (and, on Mihomo, cumulative totals
    /// in `upTotal`/`downTotal`). Only the first complete frame is consumed;
    /// the connection is closed instead of draining to EOF (which would
    /// block forever). Reading loops until a whole JSON frame has arrived —
    /// a single `read()` is *not* guaranteed to return a full frame.
    pub fn traffic_bytes(&self, timeout: Duration) -> Result<(u64, u64), KernelFailure> {
        let address = self.resolve_address()?;
        let mut stream = MihomoHttpControl::connect(address, timeout)?;
        self.write_request(&mut stream, "GET", "/traffic", "")?;
        let frame = read_first_sse_frame(&mut stream)?;
        parse_traffic_frame(&frame)
    }

    /// Tests the latency of a named proxy via `GET /proxies/{name}/delay`.
    ///
    /// The endpoint probes a fixed `generate_204` URL and returns `{"delay":n}`
    /// on success; a non-2xx status (e.g. the target host is unreachable) is a
    /// valid HTTP outcome and maps to `Ok(None)` rather than a transport error.
    pub fn probe_delay(
        &self,
        name: &str,
        url: &str,
        timeout: Duration,
    ) -> Result<Option<u32>, KernelFailure> {
        // The kernel-side probe timeout follows the caller's budget (bounded)
        // so slow-but-reachable nodes are not missed by a hardcoded 3s probe.
        let delay_timeout_ms = u64::from(timeout.as_millis().clamp(100, 15_000) as u16);
        let encoded =
            percent_encoding::utf8_percent_encode(name, percent_encoding::NON_ALPHANUMERIC);
        // The probe URL must be percent-encoded: sing-box's Clash API rejects a
        // raw `://` in the query ("Body invalid") while the encoded form works.
        let encoded_url =
            percent_encoding::utf8_percent_encode(url, percent_encoding::NON_ALPHANUMERIC);
        let path = format!("/proxies/{encoded}/delay?url={encoded_url}&timeout={delay_timeout_ms}");
        let address = self.resolve_address()?;
        // Keep the socket timeout comfortably above the probe timeout so a slow
        // target yields a 503 response (mapped to Ok(None)) rather than a socket
        // read timeout (mapped to Err).
        let socket_timeout = timeout.saturating_add(Duration::from_secs(2));
        let mut stream = MihomoHttpControl::connect(address, socket_timeout)?;
        self.write_request(&mut stream, "GET", &path, "")?;
        let mut buffer = Vec::new();
        // Audit #86: bound the probe response like every other controller
        // read (32 MiB ceiling); an unbounded `read_to_end` on a loopback
        // socket can allocate tens of GB before the socket timeout bites.
        stream
            .take(32 * 1_024 * 1_024)
            .read_to_end(&mut buffer)
            .map_err(|error| {
                // A read timeout while awaiting the probe result means the kernel
                // did not answer within the probe budget (sing-box can hang past
                // its own `timeout` param when the dial stalls); a reset/EOF at
                // this stage likewise means the probe did not complete. Both are
                // classified as DeadlineExceeded so callers can treat them like an
                // unreachable node instead of a controller transport failure
                // (connect-phase failures stay ApiUnavailable/loud).
                let kind = if matches!(
                    error.kind(),
                    std::io::ErrorKind::WouldBlock
                        | std::io::ErrorKind::TimedOut
                        | std::io::ErrorKind::ConnectionReset
                        | std::io::ErrorKind::ConnectionAborted
                        | std::io::ErrorKind::UnexpectedEof
                        | std::io::ErrorKind::BrokenPipe
                ) {
                    crate::contract::KernelFailureKind::DeadlineExceeded
                } else {
                    crate::contract::KernelFailureKind::ApiUnavailable
                };
                crate::common::failure_with_kind(
                    kind,
                    &format!("cannot read Mihomo delay response: {error}"),
                    "inspect Mihomo controller health",
                )
            })?;
        let text = core::str::from_utf8(&buffer).unwrap_or("");
        let Some(status) = http_status_code(text) else {
            // No HTTP status line: the kernel closed the probe without
            // answering (sing-box drops the connection for outbounds whose
            // dial fails instantly). The probe did not complete — deadline,
            // not a decode/transport failure.
            return Err(crate::common::failure_with_kind(
                crate::contract::KernelFailureKind::DeadlineExceeded,
                "kernel closed the delay probe without an HTTP response",
                "inspect the kernel controller state",
            ));
        };
        if !(200..300).contains(&status) {
            // A 404 means the name is not configured in the running kernel
            // (a naming/apply mismatch on our side), which must be loud — never
            // silently reported as an "unreachable" node.
            if status == 404 {
                return Err(crate::common::failure_with_kind(
                    crate::contract::KernelFailureKind::ApiUnavailable,
                    &format!("proxy `{name}` is not configured in the running kernel config"),
                    "run `caly config apply` to publish subscription nodes, then retry",
                ));
            }
            // 5xx: the kernel ran the probe and the target did not answer
            // (e.g. 503/504 after the kernel-side timeout) — a genuine
            // unreachable outcome, not a transport failure.
            if (500..600).contains(&status) {
                return Ok(None);
            }
            return Err(crate::common::failure_with_kind(
                crate::contract::KernelFailureKind::ApiUnavailable,
                &format!("kernel delay endpoint returned HTTP {status} for proxy `{name}`"),
                "inspect the kernel controller state",
            ));
        }
        let json_text = match text.split_once("\r\n\r\n") {
            Some((_, body)) => body,
            None => text,
        };
        let json = serde_json::from_str::<serde_json::Value>(json_text).map_err(|_| {
            crate::common::failure_with_kind(
                crate::contract::KernelFailureKind::DecodeRejected,
                "Mihomo delay response is invalid JSON",
                "inspect controller output",
            )
        })?;
        Ok(json
            .get("delay")
            .and_then(numeric_value)
            .and_then(|value| u32::try_from(value).ok()))
    }

    /// Lists the names of real (dialable) proxies from `GET /proxies` — the
    /// input set for a full latency sweep (`delay --all`).
    ///
    /// Mihomo lists every proxy as a top-level entry; sing-box only exposes
    /// selectors plus special entries and keeps the nodes inside each
    /// selector's `all` list, so both shapes are collected and de-duplicated.
    pub fn list_proxy_names(&self, timeout: Duration) -> Result<Vec<String>, KernelFailure> {
        let body = self.request("/proxies", timeout)?;
        let json = super::http::response_json(&body)?;
        Ok(proxy_names_from_json(&json))
    }
}

/// Extracts dialable proxy names from a parsed `GET /proxies` document.
///
/// Pure and shared between the network path and the test-suite mirror (the
/// tests used to carry a third copy of this parser, which let the mapping
/// drift — there is now exactly one implementation).
fn proxy_names_from_json(json: &serde_json::Value) -> Vec<String> {
    let Some(proxies) = json.get("proxies").and_then(serde_json::Value::as_object) else {
        return Vec::new();
    };
    let is_special = |proxy_type: &str| {
        matches!(
            proxy_type,
            "Selector"
                | "URLTest"
                | "Fallback"
                | "LoadBalance"
                | "Direct"
                | "Reject"
                | "Compatible"
                | "Pass"
        )
    };
    let mut names = std::collections::BTreeSet::new();
    for (name, value) in proxies {
        let proxy_type = value
            .get("type")
            .and_then(serde_json::Value::as_str)
            .unwrap_or("");
        if matches!(
            proxy_type,
            "Selector" | "URLTest" | "Fallback" | "LoadBalance"
        ) {
            // sing-box exposes its nodes only as selector members.
            if let Some(all) = value.get("all").and_then(serde_json::Value::as_array) {
                for member in all {
                    if let Some(tag) = member.as_str()
                        && !tag.is_empty()
                        && tag != "direct"
                    {
                        names.insert(tag.to_owned());
                    }
                }
            }
        } else if !is_special(proxy_type) {
            names.insert(name.clone());
        }
    }
    // Deterministic output for the sweep table.
    names.into_iter().collect()
}

/// Extracts the three-digit HTTP status code from a raw response head
/// (delegates to the shared transport parser in `http.rs`).
fn http_status_code(text: &str) -> Option<u16> {
    super::http::status_code(text)
}

/// Reads from the stream until the first *complete* SSE data frame
/// (`data: {…}\n`) has been collected. A single TCP `read()` does not
/// guarantee a full frame; the loop re-scans the accumulator after every
/// chunk and fails loudly on EOF / an over-long frame prefix instead of
/// handing half a JSON document to the parser.
fn read_first_sse_frame(stream: &mut impl Read) -> Result<String, KernelFailure> {
    const MAX_FRAME_BYTES: usize = 64 * 1_024;
    let mut buffer: Vec<u8> = Vec::with_capacity(1_024);
    let mut chunk = [0_u8; 4 * 1_024];
    loop {
        if let Some(frame) = first_complete_frame(&buffer) {
            return Ok(frame);
        }
        if buffer.len() >= MAX_FRAME_BYTES {
            return Err(crate::common::failure_with_kind(
                crate::contract::KernelFailureKind::DecodeRejected,
                "core traffic frame exceeded the 64 KiB snapshot bound",
                "inspect controller output",
            ));
        }
        let read = stream.read(&mut chunk).map_err(|error| {
            crate::common::failure_with_kind(
                crate::contract::KernelFailureKind::ApiUnavailable,
                &format!("cannot read core traffic snapshot: {error}"),
                "inspect controller health",
            )
        })?;
        if read == 0 {
            // EOF before a complete frame: one last scan covers kernels that
            // close the stream right after flushing the snapshot.
            return first_complete_frame(&buffer).ok_or_else(|| {
                crate::common::failure_with_kind(
                    crate::contract::KernelFailureKind::DecodeRejected,
                    "core traffic stream closed before a complete frame",
                    "inspect controller output",
                )
            });
        }
        buffer.extend_from_slice(&chunk[..read]);
    }
}

/// Extracts the first SSE/JSON data line that has fully arrived (starts
/// with `{` and ends with `}`). Returns `None` while only a partial frame
/// is buffered; HTTP response headers preceding the stream are skipped.
fn first_complete_frame(buffer: &[u8]) -> Option<String> {
    let text = core::str::from_utf8(buffer).ok()?;
    for line in text.lines() {
        let line = line.trim();
        let line = line.strip_prefix("data: ").unwrap_or(line);
        if line.starts_with('{') {
            // One JSON frame is one line; an unterminated line means the
            // frame is still in flight — keep reading instead of failing.
            return line.ends_with('}').then(|| line.to_owned());
        }
    }
    None
}

/// Parses a `/traffic` data frame into per-second (download, upload) rates.
///
/// `/traffic` differs between kernels: Mihomo emits `{"up":N,"down":N,
/// "upTotal":N,"downTotal":N}` where `up`/`down` are the *per-second*
/// snapshot and the `*Total` fields are cumulative counters; sing-box emits
/// `{"up":N,"down":N}`. The per-second fields win so telemetry records a
/// rate, not an ever-growing counter; total-only frames (classic Clash)
/// degrade to their cumulative value as a documented fallback.
fn parse_traffic_frame(text: &str) -> Result<(u64, u64), KernelFailure> {
    let json_text = text
        .lines()
        .map(str::trim)
        .filter_map(|line| line.strip_prefix("data: ").or(Some(line)))
        .find(|line| line.starts_with('{'))
        .unwrap_or("");
    let json = serde_json::from_str::<serde_json::Value>(json_text).map_err(|_| {
        crate::common::failure_with_kind(
            crate::contract::KernelFailureKind::DecodeRejected,
            "core traffic snapshot is invalid JSON",
            "inspect controller output",
        )
    })?;
    // Per-second rate first, cumulative totals as the compatibility fallback.
    let download = traffic_field(&json, &["down", "downloadTotal", "downTotal"]).unwrap_or(0);
    let upload = traffic_field(&json, &["up", "uploadTotal", "upTotal"]).unwrap_or(0);
    Ok((download, upload))
}

/// Reads a traffic byte count from the first matching field name.
fn traffic_field(node: &serde_json::Value, keys: &[&str]) -> Option<u64> {
    keys.iter()
        .find_map(|key| node.get(*key).and_then(numeric_value))
}

/// Reads a non-negative numeric field as `u64`.
fn numeric(node: &serde_json::Value, key: &str) -> u64 {
    node.get(key).and_then(numeric_value).unwrap_or(0)
}

/// Extracts a `u64` from a JSON number (handles both signed and unsigned).
fn numeric_value(value: &serde_json::Value) -> Option<u64> {
    value
        .as_u64()
        .or_else(|| value.as_i64().and_then(|v| u64::try_from(v).ok()))
}

#[cfg(test)]
mod tests;

#[cfg(test)]
mod probe_status_tests;

#[cfg(test)]
mod proxy_names_tests;
