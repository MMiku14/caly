//! Adaptive table/TSV emission (list rendering for humans and pipes).
//!
//! The reference look for every caly listing (`sub list`, `node list`,
//! …): space-aligned columns with CJK-aware widths on a TTY, verbatim
//! TAB-separated values with a header row when piped, `--format` pins
//! either. TSV is a script contract — raw values, never painted, never
//! truncated.

use crate::text::{sanitize_cell, truncate_visible, visible_width};

/// The `--format` pin shared by every listing command. `Table`/`Tsv`
/// are consumed here; `Tree`/`Diff` belong to their own commands
/// (`node list --format=tree`, `config diff --format=diff`) and a
/// table-rendering command treats them as unset (adaptive).
#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub enum OutputFormat {
    Table,
    Tsv,
    Tree,
    Diff,
}

/// Effective list-emission mode after adaptive resolution.
#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub enum TableMode {
    /// Space-aligned columns for a human at a terminal.
    Table,
    /// TAB-separated values with a header row — the piped default.
    Tsv,
}

/// Resolves the effective mode: an explicit `--format` always wins;
/// unpinned output is a table on a TTY and TSV when piped, with
/// `--format=table` as the documented opt-out for the window.
pub fn table_mode(pinned: Option<OutputFormat>) -> TableMode {
    match pinned {
        Some(OutputFormat::Table) => TableMode::Table,
        Some(OutputFormat::Tsv) => TableMode::Tsv,
        // Tree / Diff are consumed by their own commands; a
        // table-rendering command receiving them treats the pin as
        // unset (adaptive).
        Some(OutputFormat::Tree | OutputFormat::Diff) | None => {
            if crate::term::stdout_is_tty() {
                TableMode::Table
            } else {
                TableMode::Tsv
            }
        }
    }
}

/// Maximum rendered width of one table column: long cells —
/// subscription URLs, inline proxy URIs — otherwise push the whole
/// table past the terminal edge. A per-column cap, not a terminal
/// query. TSV is exempt: scripts see verbatim bytes.
const MAX_TABLE_COLUMN_WIDTH: usize = 48;

/// Proportionally shrinks column widths so the table fits `max_total`
/// terminal columns (separators included). The widest column absorbs
/// most of the shrink; every column keeps a readable floor so the
/// leftmost identity columns never vanish. No-op when `max_total` is
/// `None` or the table already fits.
pub(crate) fn shrink_widths_to_fit(widths: &mut [usize], max_total: Option<usize>) {
    // Two columns keeps short identity columns (ID, NODES) readable;
    // a higher floor would stop the shrink well above `max_total` on a
    // nine-column table (floor 6 left 70-column rows
    // on a 40-column terminal).
    const FLOOR: usize = 2;
    let Some(max_total) = max_total else {
        return;
    };
    let separators = 2 * widths.len().saturating_sub(1);
    let available = max_total.saturating_sub(separators);
    let total: usize = widths.iter().sum();
    if total <= available {
        return;
    }
    // Integer proportional shrink, then greedily trim the widest
    // column until the table fits (or every column is at the floor).
    for width in widths.iter_mut() {
        *width = ((*width * available) / total).max(FLOOR);
    }
    while widths.iter().sum::<usize>() > available {
        let Some(widest) = widths.iter_mut().max() else {
            break;
        };
        if *widest <= FLOOR {
            break;
        }
        *widest -= 1;
    }
}

/// Renders the table as lines without printing so tests can assert the
/// layout. TSV mode joins header and rows with TAB, verbatim — `caly …
/// | cut -fN` scripts see stable bytes (cells are pre-sanitized at this
/// entry). Table mode right-pads each column to its widest visible cell
/// (capped at 48, overflow cells end with `…`), columns separated by
/// two spaces.
pub fn render_table(
    mode: TableMode,
    headers: &[&str],
    rows: &[Vec<String>],
    max_total: Option<usize>,
) -> Vec<String> {
    let headers: Vec<String> = headers.iter().map(|header| sanitize_cell(header)).collect();
    let headers: Vec<&str> = headers.iter().map(String::as_str).collect();
    let rows: Vec<Vec<String>> = rows
        .iter()
        .map(|row| row.iter().map(|cell| sanitize_cell(cell)).collect())
        .collect();
    match mode {
        TableMode::Tsv => {
            let mut lines = Vec::with_capacity(rows.len() + 1);
            lines.push(headers.join("\t"));
            for row in &rows {
                lines.push(row.join("\t"));
            }
            lines
        }
        TableMode::Table => {
            let mut widths: Vec<usize> = headers
                .iter()
                .map(|h| visible_width(h).min(MAX_TABLE_COLUMN_WIDTH))
                .collect();
            for row in &rows {
                for (idx, cell) in row.iter().enumerate() {
                    if let Some(width) = widths.get_mut(idx) {
                        *width = (*width).max(visible_width(cell).min(MAX_TABLE_COLUMN_WIDTH));
                    }
                }
            }
            // Shrink AFTER the row pass widened the columns to their
            // widest cells — shrinking earlier let the loop push them
            // straight back (audit).
            shrink_widths_to_fit(&mut widths, max_total);
            let pad = |cells: &mut dyn Iterator<Item = (&usize, &str)>| -> String {
                let mut line = String::new();
                let mut first = true;
                for (width, cell) in cells {
                    if !first {
                        line.push_str("  ");
                    }
                    first = false;
                    let rendered = truncate_visible(cell, *width);
                    line.push_str(&rendered);
                    for _ in visible_width(&rendered)..*width {
                        line.push(' ');
                    }
                }
                // The last column's padding is meaningless — keep
                // rows right-clean (trim_end never touches visible
                // content; padding is spaces by construction).
                line.truncate(line.trim_end().len());
                line
            };
            let mut lines = Vec::with_capacity(rows.len() + 1);
            lines.push(pad(&mut widths.iter().zip(headers.iter().copied())));
            for row in rows {
                lines.push(pad(&mut widths.iter().zip(row.iter().map(String::as_str))));
            }
            lines
        }
    }
}

/// Prints [`render_table`] output line by line to stdout. A narrow
/// terminal must not push the rightmost columns past the edge (they
/// wrap and the table visually shifts) — `$COLUMNS` caps the total on
/// a real terminal; piped output keeps the full widths.
pub fn print_table(mode: TableMode, headers: &[&str], rows: &[Vec<String>]) {
    let max_total = if mode == TableMode::Table {
        crate::term::term_width()
    } else {
        None
    };
    for line in render_table(mode, headers, rows, max_total) {
        println!("{line}");
    }
}
