//! The palette: named styles, status badges and latency bands.
//!
//! Two layers: [`paint`] wraps text in a raw ANSI class (the caller has
//! already decided color is allowed — kept for the table engine, which
//! paints cells before it knows the terminal); everything else in this
//! module gates itself on [`crate::term::colors_enabled`], so new call
//! sites never branch on the terminal.

use crate::term::colors_enabled;

/// Wraps `text` in an ANSI colour class. Callers use this only when
/// color is already known-allowed (the table engine, which paints
/// cells up front); new code prefers [`Style::apply`], which gates
/// on the terminal itself. Never used for TSV — scripts see clean bytes.
pub fn paint(color_code: &str, text: &str) -> String {
    format!("\x1b[{color_code}m{text}\x1b[0m")
}

/// The named palette. One name per meaning so `sub list`, `node list`
/// and the delay sweep can never pick different yellows.
#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub enum Style {
    /// Selected / healthy / success.
    Green,
    /// Slow / stale / caution.
    Yellow,
    /// Failing / error accent.
    Red,
    /// Idle / disabled / secondary text.
    Dim,
    /// Links, ids and group markers.
    Cyan,
    /// Headers and emphasis.
    Bold,
}

impl Style {
    /// The raw SGR class (for the table engine's up-front painting).
    pub const fn code(self) -> &'static str {
        match self {
            Self::Green => "32",
            Self::Yellow => "33",
            Self::Red => "31",
            Self::Dim => "90",
            Self::Cyan => "36",
            Self::Bold => "1",
        }
    }

    /// Paints `text` when the terminal allows color, else returns it
    /// verbatim. The default entry for new call sites.
    pub fn apply(self, text: &str) -> String {
        if colors_enabled() {
            paint(self.code(), text)
        } else {
            text.to_owned()
        }
    }
}

/// The node-table status badge: green ● on the selected leaf, grey ○
/// otherwise. Ungated glyphs (●○) off-terminal — `node list` keeps its
/// badge column even into a pipe.
pub fn status_badge(selected: bool) -> String {
    if selected {
        Style::Green.apply("●")
    } else {
        Style::Dim.apply("○")
    }
}

/// The `sub list` STATUS badge: grey ○ when disabled, green ● when a
/// cached body exists, yellow ⚠ when an enabled source has nothing
/// cached (stale). Glyphs stay unpainted off-terminal.
pub fn source_badge(enabled: bool, cached: bool) -> String {
    if !enabled {
        Style::Dim.apply("○")
    } else if cached {
        Style::Green.apply("●")
    } else {
        Style::Yellow.apply("⚠")
    }
}

/// The TSV status word for a subscription source: `ok`, `disabled`
/// or `stale`. Never painted — TSV is a script contract.
pub const fn source_word(enabled: bool, cached: bool) -> &'static str {
    if !enabled {
        "disabled"
    } else if cached {
        "ok"
    } else {
        "stale"
    }
}

/// Paints a delay cell by latency band when the terminal allows
/// color: >1000 ms red, >300 ms yellow, anything else untouched
/// (no green band — fast needs no announcement).
pub fn latency(ms: Option<u32>, text: &str) -> String {
    if !colors_enabled() {
        return text.to_owned();
    }
    match ms {
        Some(value) if value > 1000 => paint(Style::Red.code(), text),
        Some(value) if value > 300 => paint(Style::Yellow.code(), text),
        _ => text.to_owned(),
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn paint_wraps_raw_codes() {
        assert_eq!(paint("32", "●"), "\x1b[32m●\x1b[0m");
    }

    #[test]
    fn styles_gate_on_the_terminal() {
        // Under `cargo test` stdout is captured: everything degrades
        // to verbatim glyphs.
        assert_eq!(Style::Green.apply("●"), "●");
        assert_eq!(status_badge(true), "●");
        assert_eq!(status_badge(false), "○");
        assert_eq!(source_badge(true, false), "⚠");
        assert_eq!(latency(Some(2000), "2000 ms"), "2000 ms");
    }

    #[test]
    fn source_words_cover_the_matrix() {
        assert_eq!(source_word(false, false), "disabled");
        assert_eq!(source_word(false, true), "disabled");
        assert_eq!(source_word(true, true), "ok");
        assert_eq!(source_word(true, false), "stale");
    }
}
