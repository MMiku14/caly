//! Branch-glyph trees for nested listings.
//!
//! The generic renderer takes `(depth, label)` rows and draws classic
//! continuation guides:
//!
//! ```text
//! group-a
//! ├─ node1
//! │  └─ detail
//! └─ node2
//! ```
//!
//! Labels are sanitized at the render entry (see [`crate::text`]).
//! (The entry tree — `node list --format=tree` — keeps its own zonal
//! renderer in `caly-ops`, built on these same primitives.)

use crate::text::strip_controls;

/// One tree row: `depth` 0 prints bare (a root), deeper rows hang
/// under the nearest open ancestor via `├─` / `└─` branches.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct TreeRow {
    pub depth: usize,
    pub label: String,
}

impl TreeRow {
    pub fn new(depth: usize, label: impl Into<String>) -> Self {
        Self {
            depth,
            label: label.into(),
        }
    }
}

/// Renders rows as lines without printing, for tests. A row is the
/// last of its siblings when the next row is shallower-or-equal (or
/// absent); depth jumps (a row deeper than `previous + 1`) degrade to
/// blank guides rather than panicking.
pub fn render_tree(rows: &[TreeRow]) -> Vec<String> {
    // `open[d]` = the depth-`d` node on the current path has later
    // siblings (so deeper rows must draw a `│` guide past it).
    let mut open: Vec<bool> = Vec::new();
    let mut lines = Vec::with_capacity(rows.len());
    for (index, row) in rows.iter().enumerate() {
        let is_last = rows
            .get(index + 1)
            .is_none_or(|next| next.depth <= row.depth);
        open.truncate(row.depth);
        let mut prefix = String::new();
        // Ancestor slots start at depth 1: roots never draw guides,
        // so their children branch at column 0.
        for level in 1..row.depth {
            let continues = open.get(level).copied().unwrap_or(false);
            prefix.push_str(if continues { "│  " } else { "   " });
        }
        if row.depth > 0 {
            prefix.push_str(if is_last { "└─ " } else { "├─ " });
        }
        open.push(!is_last);
        prefix.push_str(&strip_controls(&row.label));
        lines.push(prefix);
    }
    lines
}

/// Left-pads the `[kind]` badge to the 13-column badge lane followed
/// by two spaces, so names align across badge widths. The lane is 13
/// because the widest badge — `[loadbalance]` — must not push its
/// row's name column right of the others.
pub fn badge_lane(kind: &str) -> String {
    const BADGE_LANE_WIDTH: usize = 13;
    let badge = format!("[{kind}]");
    let mut lane = badge.clone();
    for _ in badge.chars().count()..BADGE_LANE_WIDTH {
        lane.push(' ');
    }
    lane.push_str("  ");
    lane
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn nested_guides_and_last_branches() {
        let rows = vec![
            TreeRow::new(0, "group-a"),
            TreeRow::new(1, "node1"),
            TreeRow::new(2, "detail"),
            TreeRow::new(1, "node2"),
            TreeRow::new(0, "group-b"),
        ];
        assert_eq!(
            render_tree(&rows),
            vec![
                "group-a".to_owned(),
                "├─ node1".to_owned(),
                "│  └─ detail".to_owned(),
                "└─ node2".to_owned(),
                "group-b".to_owned(),
            ]
        );
    }

    #[test]
    fn labels_are_sanitized() {
        let rows = vec![TreeRow::new(0, "a\nb\x1bc")];
        assert_eq!(render_tree(&rows), vec!["abc".to_owned()]);
    }

    #[test]
    fn badge_lane_aligns_names() {
        assert_eq!(badge_lane("select"), "[select]       ");
        assert_eq!(badge_lane("loadbalance"), "[loadbalance]  ");
    }
}
