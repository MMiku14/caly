//! Terminal detection: TTY, width and color policy.
//!
//! Single source of truth so tables, badges and latency colors can
//! never disagree about whether stdout is a terminal.

use std::io::IsTerminal;

/// Whether stdout is a real terminal. Piped output stays plain and
/// script-friendly; only a TTY gets aligned tables and paint.
pub fn stdout_is_tty() -> bool {
    std::io::stdout().is_terminal()
}

/// Usable terminal width on a real terminal (piped output keeps full
/// widths). An explicit `$COLUMNS` wins as an operator override; otherwise
/// the width is queried from the terminal itself — `$COLUMNS`-only used to
/// leave every table untruncated on terminals that do not export it
/// (bug ①). Values under 20 columns are ignored (a degenerate width
/// must not collapse every column to its floor).
pub fn term_width() -> Option<usize> {
    if !stdout_is_tty() {
        return None;
    }
    if let Some(cols) = columns_override() {
        return Some(cols);
    }
    ioctl_columns().filter(|cols| *cols >= 20)
}

/// Queries the terminal width via `TIOCGWINSZ` (columns only — rows
/// are irrelevant to line width, and degenerate pseudo-terminals may
/// report zero rows while carrying a valid width).
#[cfg(unix)]
fn ioctl_columns() -> Option<usize> {
    let winsize = rustix::termios::tcgetwinsize(std::io::stdout()).ok()?;
    Some(usize::from(winsize.ws_col)).filter(|cols| *cols > 0)
}

/// Non-Unix builds have no `TIOCGWINSZ`: `$COLUMNS` is the only source.
#[cfg(not(unix))]
fn ioctl_columns() -> Option<usize> {
    None
}

/// Explicit `$COLUMNS` override (valid values only).
fn columns_override() -> Option<usize> {
    std::env::var("COLUMNS")
        .ok()
        .and_then(|value| value.trim().parse::<usize>().ok())
        .filter(|cols| *cols >= 20)
}

/// Whether ANSI color may be emitted: a real terminal, no non-empty
/// `NO_COLOR` in the environment (https://no-color.org), and not a
/// `dumb` terminal.
pub fn colors_enabled() -> bool {
    if !stdout_is_tty() {
        return false;
    }
    if std::env::var_os("NO_COLOR").is_some_and(|value| !value.is_empty()) {
        return false;
    }
    if std::env::var("TERM").is_ok_and(|term| term == "dumb") {
        return false;
    }
    true
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn no_tty_no_width_no_color() {
        // Under `cargo test` stdout is captured (not a TTY): both
        // gates must agree on "plain".
        assert!(!stdout_is_tty());
        assert_eq!(term_width(), None);
        assert!(!colors_enabled());
    }
}
