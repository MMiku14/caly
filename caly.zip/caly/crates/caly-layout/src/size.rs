//! Human byte counts for the Table face (`12.3 MB`).
//!
//! TSV/JSON carry raw byte integers; only the human face renders scaled
//! text, through this single helper — `flow`'s connection table and the
//! TUI header share it so the two can never format differently.

/// Scales `bytes` to `B`/`KB`/`MB`/`GB`/`TB` with one decimal past bytes
/// (`512 B`, `12.3 MB`). Display-only: values beyond the f64 mantissa
/// (≈9 PB) render approximately, which is irrelevant for live traffic.
#[allow(clippy::cast_precision_loss)]
pub fn human_bytes(bytes: u64) -> String {
    const UNITS: [&str; 5] = ["B", "KB", "MB", "GB", "TB"];
    let mut value = bytes as f64;
    let mut unit = 0;
    while value >= 1024.0 && unit < UNITS.len() - 1 {
        value /= 1024.0;
        unit += 1;
    }
    if unit == 0 {
        format!("{bytes} B")
    } else {
        format!("{value:.1} {}", UNITS[unit])
    }
}
