//! The one-line vocabulary: `ok:` / `hint:` / `note:` / `warning:` / `error:`.
//!
//! Fixed prefixes, fixed streams — no call site hand-spells them:
//!
//! | helper  | stream | meaning                                    |
//! |---------|--------|--------------------------------------------|
//! | `ok`    | stdout | a mutation succeeded: `ok: <what changed>` |
//! | `hint`  | stdout | the actionable next step                  |
//! | `note`  | stdout | human info alongside human output         |
//! | `note_err` | stderr | human info while stdout carries data   |
//! | `warning` | stderr | degraded but proceeding                 |
//! | `error` | stderr | human one-line failure (typed errors use  |
//! |         |        | [`crate::envelope`] instead)               |
//!
//! `note` vs `note_err`: a listing command (`flow trace`, the delay
//! sweep) keeps stdout parseable and notes on stderr; a bare leaf
//! (alias expansion) notes on stdout next to its human text.

/// Prints a success line to stdout: `ok: {summary}`.
pub fn ok(summary: &str) {
    println!("ok: {summary}");
}

/// Prints a remediation/next-step line to stdout: `hint: {hint}`.
pub fn hint(hint: &str) {
    println!("hint: {hint}");
}

/// Prints an informational line to stdout: `note: {note}`.
pub fn note(note: &str) {
    println!("note: {note}");
}

/// Prints an informational line to stderr: `note: {note}`. For
/// commands whose stdout carries data (listings, sweeps) — the note
/// must not pollute the parseable stream.
pub fn note_err(note: &str) {
    eprintln!("note: {note}");
}

/// Prints a degradation line to stderr: `warning: {warning}`. The
/// command proceeds (a fallback, a skip) — failures use [`error`]
/// instead.
pub fn warning(warning: &str) {
    eprintln!("warning: {warning}");
}

/// Prints a human failure line to stderr: `error: {message}`. For
/// untyped one-liners; stable-code failures go through
/// [`crate::envelope::CliError`] so scripts can branch on `code`.
pub fn error(message: &str) {
    eprintln!("error: {message}");
}

/// Prints one blank line to stdout (section separator).
pub fn blank() {
    println!();
}

/// Prints the unified empty state to stdout: `no {entity}`, plus an
/// actionable `hint:` line when given. Every `… list` / `… show` leaf
/// with nothing to show funnels through here so the face is identical
/// everywhere (`no nodes …`, `no routing rules …`, `no operations …`).
pub fn empty(entity: &str, hint: Option<&str>) {
    println!("no {entity}");
    if let Some(hint) = hint {
        self::hint(hint);
    }
}
