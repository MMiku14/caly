//! Suite contract tests: envelope + table engine locks (moved from caly-ops).

#[cfg(test)]
mod tests {
    use crate::*;
    use std::process::ExitCode;

    #[test]
    fn success_envelope_merges_payload_over_ok_and_version() {
        let value =
            CliOutput::success_envelope(serde_json::json!({ "id": "team", "dry_run": false }));
        assert_eq!(value["ok"], serde_json::json!(true));
        assert_eq!(value["version"], serde_json::json!(JSON_CONTRACT_VERSION));
        assert_eq!(value["id"], serde_json::json!("team"));
        assert_eq!(value["dry_run"], serde_json::json!(false));
        // A non-object payload leaves the bare `{ok, version}` envelope.
        let bare = CliOutput::success_envelope(serde_json::Value::Null);
        assert_eq!(
            bare,
            serde_json::json!({ "ok": true, "version": JSON_CONTRACT_VERSION })
        );
    }

    #[test]
    fn error_envelope_round_trips_through_json() {
        let error = CliError::new(
            "profile.not_declared",
            "profile `team` is not declared",
            "profile show team",
        )
        .with_hint("run `caly profile add team remote:<url>` to declare it");
        let value = error.to_json();
        let text = value.to_string();
        assert!(text.contains("\"ok\":false"));
        assert!(text.contains("\"version\":1"));
        assert!(text.contains("\"code\":\"profile.not_declared\""));
        assert!(text.contains("\"error\":\"profile `team` is not declared\""));
        assert!(text.contains("\"hint\":\"run `caly profile add"));
        assert!(text.contains("\"command\":\"profile show team\""));
    }

    #[test]
    fn error_envelope_omits_hint_field_when_none() {
        let error = CliError::new("test", "msg", "cmd");
        let value = error.to_json();
        let text = value.to_string();
        assert!(!text.contains("hint"));
    }

    #[test]
    fn usage_error_exits_2_others_exit_1() {
        let usage = CliError::new("usage.bad_arg", "bad", "cmd");
        let runtime = CliError::new("runtime.failed", "fail", "cmd");
        assert_eq!(usage.exit_code(), ExitCode::from(2));
        assert_eq!(runtime.exit_code(), ExitCode::FAILURE);
    }

    #[test]
    fn output_mode_from_json_flag() {
        assert_eq!(CliOutput::from_json_flag(true), CliOutput::Json);
        assert_eq!(CliOutput::from_json_flag(false), CliOutput::Human);
        assert!(CliOutput::Json.is_json());
        assert!(!CliOutput::Human.is_json());
    }

    #[test]
    fn pinned_format_wins_over_adaptivity() {
        use crate::OutputFormat;
        assert_eq!(table_mode(Some(OutputFormat::Table)), TableMode::Table);
        assert_eq!(table_mode(Some(OutputFormat::Tsv)), TableMode::Tsv);
        // Unpinned resolution depends on the test harness's fake
        // TTY — only the contract surface is asserted here (the
        // IsTerminal branch is one line of std).
        let _ = table_mode(None);
    }

    #[test]
    fn tsv_render_is_verbatim_with_header() {
        let rows = vec![
            vec!["[vmess]".to_owned(), "hk-01".to_owned(), "28".to_owned()],
            vec!["[direct]".to_owned(), "DIRECT".to_owned(), String::new()],
        ];
        let lines = render_table(TableMode::Tsv, &["TYPE", "NAME", "DELAY_MS"], &rows, None);
        assert_eq!(lines[0], "TYPE\tNAME\tDELAY_MS");
        assert_eq!(lines[1], "[vmess]\thk-01\t28");
        assert_eq!(lines[2], "[direct]\tDIRECT\t");
        assert_eq!(lines.len(), 3);
    }

    #[test]
    fn table_render_aligns_to_widest_visible_cell() {
        let rows = vec![
            vec!["[vmess]".to_owned(), "hk-01".to_owned()],
            vec!["[direct]".to_owned(), "DIRECT".to_owned()],
        ];
        let lines = render_table(TableMode::Table, &["TYPE", "NAME"], &rows, None);
        assert_eq!(lines[0], "TYPE      NAME");
        assert_eq!(lines[1], "[vmess]   hk-01");
        assert_eq!(lines[2], "[direct]  DIRECT");
    }

    #[test]
    fn painted_cells_do_not_break_alignment() {
        // §5.2 badges arrive pre-painted; the ANSI wrapper must
        // not count toward the column width.
        let rows = vec![
            vec![paint("32", "●"), "hk-01".to_owned()],
            vec!["○".to_owned(), "loooong".to_owned()],
        ];
        let lines = render_table(TableMode::Table, &["S", "NAME"], &rows, None);
        assert_eq!(lines[0], "S  NAME");
        assert_eq!(lines[1], format!("{}  hk-01", paint("32", "●")));
        assert_eq!(lines[2], "○  loooong");
    }

    #[test]
    fn cjk_wide_cells_align_to_two_columns() {
        // Z2: CJK glyphs occupy two terminal columns. A 中文 node name
        // (`香港-节点01` = 香2 港2 -1 节2 点2 0 1 = 11 列) must widen
        // the first column exactly like an 11-column ASCII name.
        let rows = vec![
            vec!["香港-节点01".to_owned(), "28".to_owned()],
            vec!["hk-01".to_owned(), "5".to_owned()],
        ];
        let lines = render_table(TableMode::Table, &["NAME", "DELAY"], &rows, None);
        // Column 1 is 11 wide: header pads 7, `hk-01` pads 6, the
        // CJK cell pads none; all rows hit the column boundary.
        assert_eq!(lines[0], "NAME         DELAY");
        assert_eq!(lines[1], "香港-节点01  28");
        // `hk-01` pads to the same 11-wide column: 5 + 6 pad + 2 sep.
        assert_eq!(lines[2], "hk-01        5");
    }

    #[test]
    fn cjk_char_widths_are_pinned() {
        // The interval table is the alignment contract: one regression
        // here misaligns every CJK table. 中文/日文/全角/emoji = 2;
        // ASCII = 1; joiners / BOM / variation selectors = 0.
        assert_eq!(char_width('香'), 2);
        assert_eq!(char_width('の'), 2);
        assert_eq!(char_width('カ'), 2);
        assert_eq!(char_width('Ａ'), 2); // fullwidth A
        assert_eq!(char_width('😀'), 2);
        assert_eq!(char_width('a'), 1);
        assert_eq!(char_width('-'), 1);
        assert_eq!(char_width('\u{200b}'), 0); // ZWSP
        assert_eq!(char_width('\u{feff}'), 0); // BOM
        assert_eq!(visible_width("a\u{200b}b"), 2);
        assert_eq!(visible_width("香港-节点01"), 11);
    }

    #[test]
    fn truncate_counts_cjk_as_two_columns() {
        // `香港-节点01` = 11 列; cap 8 → 7 列内容 + `…`.
        let truncated = truncate_visible("香港-节点01", 8);
        assert_eq!(visible_width(&truncated), 8);
        assert!(truncated.ends_with('…'));
        // ASCII cells under the cap pass through untouched.
        assert_eq!(truncate_visible("hk-01", 8), "hk-01");
        // A zero-width joiner in the middle changes nothing.
        assert_eq!(truncate_visible("hk\u{200b}-01", 8), "hk\u{200b}-01");
    }
}

#[cfg(test)]
mod table_sanitize_tests {
    use crate::*;

    /// The single-entry cell sanitizer is the table contract: TAB / CR /
    /// LF inside a cell must not break the TSV column shape or forge
    /// terminal rows (refactor — config names and subscription
    /// tags reach the table without per-caller cleaning).
    #[test]
    fn tsv_cells_with_embedded_tabs_stay_one_column() {
        let rows = vec![vec!["a\tb".to_owned(), "c".to_owned()]];
        let lines = render_table(TableMode::Tsv, &["X", "Y"], &rows, None);
        assert_eq!(lines[1], "a b\tc", "embedded tab must not add a column");
        assert_eq!(lines[1].split('\t').count(), 2);
    }

    #[test]
    fn table_cells_with_newlines_cannot_forge_rows() {
        let rows = vec![vec!["line1\nline2".to_owned(), "x".to_owned()]];
        let lines = render_table(TableMode::Table, &["A", "B"], &rows, None);
        assert_eq!(lines.len(), 2, "one header + one row, no forged rows");
        assert!(lines[1].contains("line1 line2"));
    }

    #[test]
    fn header_cells_are_sanitized_too() {
        let rows: Vec<Vec<String>> = Vec::new();
        let lines = render_table(TableMode::Tsv, &["a\tb"], &rows, None);
        assert_eq!(lines[0], "a b");
    }
}

#[cfg(test)]
mod shrink_tests {
    use crate::*;

    /// user-flow audit: a 40-column terminal must not push
    /// the rightmost table columns past the edge. The shrink is a pure
    /// function — verified here directly because CI has no real TTY.
    #[test]
    fn narrow_terminal_shrinks_the_table_into_max_total() {
        let rows = vec![vec![
            "1".to_owned(),
            "zhuhaiuk".to_owned(),
            "subscription".to_owned(),
            "https://raw.githubusercontent.com/zhuhaiuk/free-nodes/main/nodes.txt".to_owned(),
            "30".to_owned(),
            "0".to_owned(),
            "8m ago".to_owned(),
            "51m later".to_owned(),
            "●".to_owned(),
        ]];
        let lines = render_table(
            TableMode::Table,
            &[
                "ID",
                "NAME",
                "TYPE",
                "SOURCE",
                "NODES",
                "GROUPS",
                "LAST REFRESH",
                "NEXT REFRESH",
                "STATUS",
            ],
            &rows,
            Some(40),
        );
        for line in &lines {
            assert!(
                visible_width(line) <= 40,
                "table must fit 40 columns, got {}: {line:?}",
                visible_width(line)
            );
        }
        // The rightmost status column stays visible (no column dropped).
        assert!(lines[1].contains('●'));
        // The long URL is truncated, not wrapped.
        assert!(
            lines[1].contains('…')
                || !lines[1]
                    .contains("raw.githubusercontent.com/zhuhaiuk/free-nodes/main/nodes.txt")
        );
    }

    #[test]
    fn byte_counts_scale_with_one_decimal() {
        assert_eq!(human_bytes(0), "0 B");
        assert_eq!(human_bytes(512), "512 B");
        assert_eq!(human_bytes(1023), "1023 B");
        assert_eq!(human_bytes(1024), "1.0 KB");
        assert_eq!(human_bytes(12_582_912), "12.0 MB");
        assert_eq!(human_bytes(5_497_558_138_880), "5.0 TB");
    }

    #[test]
    fn wide_or_unbounded_tables_keep_full_widths() {
        let rows = vec![vec!["hk-01".to_owned(), "28ms".to_owned()]];
        let lines = render_table(TableMode::Table, &["NAME", "DELAY"], &rows, None);
        assert!(lines[1].contains("hk-01"));
        assert!(lines[1].contains("28ms"));
    }
}
