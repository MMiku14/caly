//! Text measurement and hostile-input sanitizers.
//!
//! All width math is CJK-aware (East Asian Width counts 2 columns)
//! and ANSI-transparent (painted cells align like unpainted ones).
//! All sanitizers run at render entries, never at call sites.

/// Terminal columns one char occupies, per the Unicode East Asian
/// Width standard via `unicode-width` (the ecosystem's de-facto width
/// table — console/ratatui use the same crate). Zero-width / control
/// characters return 0, CJK wide glyphs 2, ASCII 1.
pub fn char_width(ch: char) -> usize {
    unicode_width::UnicodeWidthChar::width(ch).unwrap_or(0)
}

/// Width of `text` in terminal columns with ANSI CSI colour sequences
/// excluded, so pre-painted cells do not break column alignment.
/// CJK wide glyphs count as two columns ([`char_width`]), so tables
/// with 中文/日文 node names stay aligned.
pub fn visible_width(text: &str) -> usize {
    let mut width = 0;
    let mut chars = text.chars();
    while let Some(ch) = chars.next() {
        if ch == '\x1b' {
            // CSI sequence: ESC '[' ... final byte in '@'..='~'.
            if chars.next() == Some('[') {
                for inner in chars.by_ref() {
                    if ('@'..='~').contains(&inner) {
                        break;
                    }
                }
            }
        } else {
            width += char_width(ch);
        }
    }
    width
}

/// Truncates `text` to at most `max` visible columns, appending `…`.
/// ANSI CSI colour sequences are copied through whole (they add no
/// width, and a half-copied sequence would corrupt the terminal).
/// A 2-column CJK glyph that would overflow `max` is dropped rather
/// than pushed (it would render `max + 1` columns and shift the next
/// column).
pub fn truncate_visible(text: &str, max: usize) -> String {
    if visible_width(text) <= max {
        return text.to_owned();
    }
    let mut out = String::new();
    let mut width = 0;
    let mut chars = text.chars().peekable();
    while width < max.saturating_sub(1) {
        let Some(ch) = chars.next() else { break };
        if ch == '\x1b' {
            out.push(ch);
            if chars.peek() == Some(&'[') {
                if let Some(open) = chars.next() {
                    out.push(open);
                }
                for inner in chars.by_ref() {
                    out.push(inner);
                    if ('@'..='~').contains(&inner) {
                        break;
                    }
                }
            }
            continue;
        }
        if width + char_width(ch) > max.saturating_sub(1) {
            break;
        }
        out.push(ch);
        width += char_width(ch);
    }
    out.push('…');
    if out.contains('\x1b') {
        // A truncated painted cell lost its trailing reset — close it
        // here or the terminal leaks the style into the next columns.
        out.push_str("\x1b[0m");
    }
    out
}

/// Right-pads `text` with spaces to exactly `width` visible columns
/// (ANSI-transparent). Over-wide text is returned untouched — callers
/// that need a hard cap truncate first.
pub fn pad_end_visible(text: &str, width: usize) -> String {
    let mut out = text.to_owned();
    for _ in visible_width(text)..width {
        out.push(' ');
    }
    out
}

/// Sanitizes one table cell at the single render entry: TAB / CR / LF
/// would break the TSV column shape (a cell containing `\t` silently
/// adds a column) or forge terminal rows in table mode.
#[must_use]
pub fn sanitize_cell(text: &str) -> String {
    text.replace(['\t', '\n', '\r'], " ")
}

/// Strips control and format characters from a display string: a
/// hostile document (subscription names, rule text, process paths)
/// could otherwise inject ANSI sequences (`\x1b[2J` clear-screen,
/// colour forgery, `\r` overwrites), bidi overrides (`U+202A-202E` —
/// RLO can reorder a display name into an impersonation), line /
/// paragraph separators (`U+2028/2029` — fake rows), zero-width marks
/// and word joiners (`U+200B-200F`, `U+2060-206F`, `U+FEFF`). The JSON
/// face keeps the raw bytes — machine consumers make their own policy.
#[must_use]
pub fn strip_controls(text: &str) -> String {
    text.chars()
        .filter(|ch| {
            !ch.is_control()
                && !matches!(
                    *ch as u32,
                    // Bidi overrides / isolates (incl. U+061C ALM — the
                    // fifth Bidi_Control code point), line & paragraph
                    // separators, ZWSP/ZWNJ/ZWJ/LTR-RTL marks, word
                    // joiners, variation selectors (incl. the
                    // supplementary plane E0100–E01EF), BOM.
                    0x061C
                        | 0x202A..=0x202E
                        | 0x2028
                        | 0x2029
                        | 0x200B..=0x200F
                        | 0x2060..=0x206F
                        | 0xE0100..=0xE01EF
                        | 0xFE00..=0xFE0F
                        | 0xFEFF
                )
        })
        .collect()
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn widths_count_cjk_double_and_ansi_zero() {
        assert_eq!(char_width('a'), 1);
        assert_eq!(char_width('中'), 2);
        assert_eq!(char_width('\0'), 0);
        assert_eq!(visible_width("ab中"), 4);
        assert_eq!(visible_width("\x1b[32m●\x1b[0m"), 1);
    }

    #[test]
    fn truncate_never_splits_cjk_or_ansi() {
        assert_eq!(truncate_visible("abcdef", 4), "abc…");
        // `中` (2 cols) would overflow a 3-col cap: dropped, not pushed.
        assert_eq!(truncate_visible("a中b", 3), "a…");
        let painted = "\x1b[32mabcdef\x1b[0m";
        assert_eq!(truncate_visible(painted, 4), "\x1b[32mabc…\x1b[0m");
    }

    #[test]
    fn pad_counts_visible_columns_only() {
        assert_eq!(pad_end_visible("ab", 4), "ab  ");
        assert_eq!(
            pad_end_visible("\x1b[32mab\x1b[0m", 4),
            "\x1b[32mab\x1b[0m  "
        );
        assert_eq!(pad_end_visible("abcdef", 4), "abcdef");
    }

    #[test]
    fn sanitizers_strip_forgery_characters() {
        assert_eq!(sanitize_cell("a\tb\nc\rd"), "a b c d");
        assert_eq!(strip_controls("a\x1bb\u{202e}c\u{200b}d"), "abcd");
    }
}
