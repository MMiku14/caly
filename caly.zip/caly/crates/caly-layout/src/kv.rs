//! Titled fact blocks (`status`, `core versions`, `flow trace` …).
//!
//! The unified shape for every key/value surface:
//!
//! ```text
//! applied:
//!   core:             mihomo
//!   run-state:        running
//! ```
//!
//! A block is a `title:` header plus colon-aligned `  key:  value`
//! rows (two-space indent, values aligned per block); blocks are
//! separated by one blank line. Keys and values are sanitized at the
//! render entry — hostile values (process paths, domains, node names)
//! can neither forge rows nor inject terminal sequences.

use crate::text::{strip_controls, visible_width};

/// Widest a key column may grow before values stop aligning further
/// right: past this the block would push facts off narrow terminals.
const MAX_KEY_WIDTH: usize = 24;

/// One fact block: an optional `title:` header plus key/value rows.
/// Repeated keys are fine (`store:` lists every installed version).
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct KvBlock {
    title: Option<String>,
    rows: Vec<(String, String)>,
    indent: usize,
}

impl Default for KvBlock {
    fn default() -> Self {
        Self {
            title: None,
            rows: Vec::new(),
            indent: 2,
        }
    }
}

impl KvBlock {
    /// Starts a titled block (`applied:`, `mihomo:`, `geo:` …).
    #[must_use]
    pub fn section(title: impl Into<String>) -> Self {
        Self {
            title: Some(title.into()),
            ..Self::default()
        }
    }

    /// Starts a headerless block (bare aligned rows).
    #[must_use]
    pub fn plain() -> Self {
        Self::default()
    }

    /// Sets the row indent in spaces (default 2). Top-level facts
    /// (`daemon:`, `nodes:` …) use `0`; section rows keep the indent.
    #[must_use]
    pub fn indent(mut self, indent: usize) -> Self {
        self.indent = indent;
        self
    }

    /// Appends one `key: value` row. Values take any [`ToString`], so
    /// numbers and bools need no `to_string()` at the call site.
    #[must_use]
    pub fn row(mut self, key: impl Into<String>, value: impl ToString) -> Self {
        self.rows.push((key.into(), value.to_string()));
        self
    }

    /// Renders the block as lines without printing, for tests.
    pub fn render(&self) -> Vec<String> {
        let mut lines = Vec::with_capacity(self.rows.len() + 1);
        if let Some(title) = &self.title {
            lines.push(format!("{}:", strip_controls(title)));
        }
        let width = self
            .rows
            .iter()
            .map(|(key, _)| visible_width(&strip_controls(key)))
            .max()
            .unwrap_or(0)
            .min(MAX_KEY_WIDTH);
        let pad = " ".repeat(self.indent);
        for (key, value) in &self.rows {
            let key = strip_controls(key);
            let value = strip_controls(value);
            // Values align per block; the widest key still gets a
            // two-space gap (the table column separator).
            let gap = " ".repeat(width.saturating_sub(visible_width(&key)) + 2);
            lines.push(format!("{pad}{key}:{gap}{value}"));
        }
        lines
    }

    /// Prints the block to stdout.
    pub fn print(&self) {
        for line in self.render() {
            println!("{line}");
        }
    }
}

/// Renders several blocks joined by one blank line (no trailing blank
/// line — the caller owns what follows the last block).
pub fn render_blocks(blocks: &[KvBlock]) -> Vec<String> {
    let mut lines = Vec::new();
    for (idx, block) in blocks.iter().enumerate() {
        if idx > 0 {
            lines.push(String::new());
        }
        lines.extend(block.render());
    }
    lines
}

/// Prints several blocks to stdout, joined by one blank line.
pub fn print_blocks(blocks: &[KvBlock]) {
    for line in render_blocks(blocks) {
        println!("{line}");
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn values_align_to_the_widest_key() {
        let block = KvBlock::section("applied")
            .row("core", "mihomo")
            .row("run-state", "running");
        assert_eq!(
            block.render(),
            vec![
                "applied:".to_owned(),
                "  core:       mihomo".to_owned(),
                "  run-state:  running".to_owned(),
            ]
        );
    }

    #[test]
    fn plain_blocks_and_repeated_keys() {
        let block = KvBlock::plain()
            .row("store", "1.19.0")
            .row("store", "1.19.1");
        assert_eq!(
            block.render(),
            vec!["  store:  1.19.0".to_owned(), "  store:  1.19.1".to_owned(),]
        );
    }

    #[test]
    fn blocks_join_with_one_blank_line() {
        let blocks = vec![
            KvBlock::section("a").row("k", "v"),
            KvBlock::section("b").row("k", "v"),
        ];
        assert_eq!(
            render_blocks(&blocks),
            vec![
                "a:".to_owned(),
                "  k:  v".to_owned(),
                String::new(),
                "b:".to_owned(),
                "  k:  v".to_owned(),
            ]
        );
    }

    #[test]
    fn hostile_values_cannot_forge_rows() {
        let block = KvBlock::section("flow").row("process", "a\nb\x1b[2Jc\u{202e}d");
        // The ESC dies; the orphaned `[2J` payload stays as inert text.
        assert_eq!(block.render()[1], "  process:  ab[2Jcd");
    }

    #[test]
    fn indent_zero_for_top_level_facts() {
        let block = KvBlock::plain()
            .indent(0)
            .row("daemon", "ab12")
            .row("nodes", 3);
        assert_eq!(
            block.render(),
            vec!["daemon:  ab12".to_owned(), "nodes:   3".to_owned(),]
        );
    }

    #[test]
    fn overlong_keys_stop_pushing_values_right() {
        let block = KvBlock::plain().row("a-very-long-key-name-past-the-cap", "v");
        assert_eq!(
            block.render(),
            vec!["  a-very-long-key-name-past-the-cap:  v".to_owned()]
        );
    }
}
