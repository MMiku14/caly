//! Human relative times for Table faces (`2h ago` / `10h later`).
//!
//! TSV/JSON carry raw unix seconds; only the human face renders
//! relative text, through this single helper.

/// Current unix time in whole seconds (the `now` every relative
/// rendering compares against).
pub fn now_unix() -> u64 {
    std::time::SystemTime::now()
        .duration_since(std::time::UNIX_EPOCH)
        .map_or(0, |duration| duration.as_secs())
}

/// Relative human time (`2h ago` / `10h later` / `just now` / `—`).
/// A missing timestamp renders as `—`; a future timestamp inside the
/// next minute reads as `in Ns` (never "just now" — a NEXT column
/// would lie).
pub fn relative_time(now: u64, then: Option<u64>) -> String {
    let Some(then) = then else {
        return "—".to_owned();
    };
    let delta = i64::try_from(now).unwrap_or(i64::MAX) - i64::try_from(then).unwrap_or(i64::MAX);
    if delta.abs() < 60 {
        // A future timestamp inside the next minute must not read as
        // "just now" — NEXT REFRESH would lie (CLI audit).
        let seconds = delta.abs().max(1);
        return if delta >= 0 {
            "just now".to_owned()
        } else {
            format!("in {seconds}s")
        };
    }
    let (magnitude, unit) = if delta.abs() < 3600 {
        (delta.abs() / 60, "m")
    } else if delta.abs() < 86400 {
        (delta.abs() / 3600, "h")
    } else {
        (delta.abs() / 86400, "d")
    };
    if delta >= 0 {
        format!("{magnitude}{unit} ago")
    } else {
        format!("{magnitude}{unit} later")
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn shapes() {
        assert_eq!(relative_time(1000, None), "—");
        assert_eq!(relative_time(1000, Some(1000)), "just now");
        assert_eq!(relative_time(1000, Some(950)), "just now");
        assert_eq!(relative_time(1000, Some(940)), "1m ago");
        assert_eq!(relative_time(1000, Some(1010)), "in 10s");
        assert_eq!(relative_time(1000, Some(880)), "2m ago");
        assert_eq!(relative_time(1000, Some(4600)), "1h later");
        assert_eq!(relative_time(100_000, Some(1000)), "1d ago");
    }
}
