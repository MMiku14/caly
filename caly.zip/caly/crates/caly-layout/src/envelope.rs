//! The stable JSON contract and the typed error renderer.
//!
//! # JSON contract
//!
//! Every JSON line the CLI emits starts with a `version`
//! field so consumers can detect contract changes. Success
//! lines have `ok: true`; error lines have `ok: false` and
//! carry `code`, `error`, `hint`, and the `command` the
//! user ran. A pipeline of `caly --json ... | jq` can rely
//! on this shape being stable across all subcommands.
//!
//! # Human contract
//!
//! Successful mutations print `ok: SEMANTIC_SUMMARY`
//! (`ok: profile \`team\` added`); failures print
//! `error: MSG` followed by `hint: REMEDIATION` on
//! the next line. Errors always go to stderr so stdout
//! carries only successful data.

use std::process::ExitCode;

use serde_json::Value;

/// `1` is the first stable JSON contract version. Bump only
/// when the shape of an existing line changes; additive
/// fields (new optional keys) do not bump the version.
pub const JSON_CONTRACT_VERSION: u32 = 1;

/// Prints the §6.1 ok-envelope: `{"ok": true, "version": N, <payload>}`.
/// serde_json's map is a BTreeMap (no `preserve_order`), so keys print
/// sorted regardless of insertion order — merging the payload before
/// printing is byte-identical to building the full object inline.
pub fn print_ok_envelope(payload: serde_json::Value) {
    let mut envelope = match payload {
        serde_json::Value::Object(map) => map,
        _ => serde_json::Map::new(),
    };
    envelope.insert("ok".to_owned(), serde_json::json!(true));
    envelope.insert(
        "version".to_owned(),
        serde_json::json!(JSON_CONTRACT_VERSION),
    );
    println!("{}", serde_json::Value::Object(envelope));
}

/// The shared human message for an interactive picker cancelled by the
/// operator (Esc). Single source of truth: every picker prints it.
pub const CANCELLED_NOTHING_CHANGED: &str = "cancelled, nothing changed";

/// Outputs through either the human or JSON channel. The
/// output is bound to the `--json` flag at parse time so
/// every command uses the same dispatch.
#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub enum CliOutput {
    Human,
    Json,
}

impl CliOutput {
    /// Constructs a `CliOutput` from the `--json` flag value.
    pub const fn from_json_flag(json: bool) -> Self {
        if json { Self::Json } else { Self::Human }
    }

    /// Returns `true` when JSON output is requested.
    pub const fn is_json(self) -> bool {
        matches!(self, Self::Json)
    }

    /// Prints a successful result. The `summary` is the
    /// semantic message shown to the operator (e.g.
    /// `"profile \`team\` added"`); the `payload` is the
    /// additional JSON fields to merge into the success
    /// envelope (ignored in human mode).
    pub fn success(self, summary: &str, payload: Value) {
        match self {
            Self::Human => println!("ok: {summary}"),
            Self::Json => println!("{}", Self::success_envelope(payload)),
        }
    }

    /// Builds the JSON success envelope: `{ok, version}` plus
    /// every field of an object payload (a non-object payload
    /// leaves the bare envelope).
    pub fn success_envelope(payload: Value) -> Value {
        let mut value = serde_json::json!({
            "ok": true,
            "version": JSON_CONTRACT_VERSION,
        });
        if let Value::Object(map) = payload
            && let Value::Object(self_map) = &mut value
        {
            for (k, v) in map {
                self_map.insert(k, v);
            }
        }
        value
    }

    /// Prints an informational message. Goes to stdout in
    /// both modes (the human reads it; a JSON consumer can
    /// ignore the line because it is not a JSON object).
    pub fn info(self, message: &str) {
        match self {
            Self::Human => println!("{message}"),
            Self::Json => println!(
                "{}",
                serde_json::json!({
                    "level": "info",
                    "message": message,
                    "version": JSON_CONTRACT_VERSION,
                })
            ),
        }
    }
}

/// Reports an error to the appropriate channel. JSON emits a
/// structured object on stderr; human mode prints a two-line
/// `error: …` + `hint: …` block on stderr. The caller is
/// responsible for returning the exit code — see
/// [`report_error_returning`] for the common one-shot.
pub fn report_error(output: CliOutput, error: &CliError) {
    match output {
        CliOutput::Human => {
            eprintln!("error: {}", error.message);
            if let Some(hint) = &error.hint {
                eprintln!("hint: {hint}");
            }
        }
        CliOutput::Json => {
            eprintln!("{}", error.to_json());
        }
    }
}

/// Reports an error and returns the appropriate exit code.
/// This is the one-shot helper for the common "do the work,
/// then bail" pattern at the end of a leaf.
pub fn report_error_returning(output: CliOutput, error: CliError) -> ExitCode {
    report_error(output, &error);
    error.exit_code()
}

/// The remediation-hint seam: domain errors that know an actionable
/// next step surface it through [`ErrorHint::hint`]; the shared writer
/// helpers call this on the failing error so the envelope gains a
/// `hint` without every dispatch site growing a bespoke parameter.
/// Default: no hint.
pub trait ErrorHint {
    fn hint(&self) -> Option<String> {
        None
    }
}

/// Structured error with a stable `code`, human `message`,
/// optional `hint`, and the `command` the user ran. All caly
/// CLI failures are represented as one of these so the JSON
/// output is uniform.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct CliError {
    /// Stable machine-readable code (e.g. `"profile.not_declared"`).
    /// Script consumers should branch on this, not the
    /// human `message`.
    pub code: &'static str,
    /// Human-readable message.
    pub message: String,
    /// Optional remediation hint. A single sentence pointing
    /// the operator at the next command to run.
    pub hint: Option<String>,
    /// The `command` the user ran (e.g. `"profile add team ..."`).
    /// Tracked in the error envelope so log-grep can find
    /// which input triggered the failure.
    pub command: String,
}

impl CliError {
    /// Builds a new `CliError` with the given code and message.
    pub fn new(code: &'static str, message: impl Into<String>, command: impl Into<String>) -> Self {
        Self {
            code,
            message: message.into(),
            hint: None,
            command: command.into(),
        }
    }

    /// Attaches a remediation hint.
    #[must_use]
    pub fn with_hint(mut self, hint: impl Into<String>) -> Self {
        self.hint = Some(hint.into());
        self
    }

    /// Returns the exit code for this error class. `Usage`
    /// errors (bad args) exit 2; everything else exits 1.
    pub fn exit_code(&self) -> ExitCode {
        if self.code.starts_with("usage.") {
            ExitCode::from(2)
        } else {
            ExitCode::FAILURE
        }
    }

    /// Serialises the error as a JSON object.
    pub fn to_json(&self) -> Value {
        let mut object = serde_json::json!({
            "ok": false,
            "version": JSON_CONTRACT_VERSION,
            "code": self.code,
            "error": self.message,
            "command": self.command,
        });
        if let Some(hint) = &self.hint
            && let Value::Object(map) = object
        {
            object = Value::Object({
                let mut m = map;
                m.insert("hint".to_owned(), Value::String(hint.clone()));
                m
            });
        }
        object
    }
}

impl std::fmt::Display for CliError {
    fn fmt(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        write!(formatter, "{}", self.message)
    }
}

impl std::error::Error for CliError {}
