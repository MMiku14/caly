//! `StdProc` on a real host (`ADR-042`): the shared spawn contract plus the half only a real
//! child can prove — the cwd is the gateway root the spec named, the env the spec injected is
//! the env the child sees, and a program the host cannot find is refused by name. The adapter
//! under test is the one place allowed to touch `std::process::Command`; this harness reaches
//! it only through the port, so a bypass here would be a bug in the test, not a loophole in
//! the ban.

use std::sync::atomic::{AtomicU64, Ordering};
use std::time::{Duration, Instant};

use caly_io::contract::{proc_spawn_contract_violations, proc_supervision_contract_violations};
use caly_io::{block_on_ready, IoContext, Proc, SpawnSpec, VPath};
use caly_io_std::StdProc;

static SCRATCH_SEQUENCE: AtomicU64 = AtomicU64::new(0);

/// A fresh scratch root per test, so the suite can run in parallel (same shape as the fs
/// contract harness in this crate).
fn scratch_root(label: &str) -> String {
    let sequence = SCRATCH_SEQUENCE.fetch_add(1, Ordering::SeqCst);
    let pid = std::process::id();
    let root = std::env::temp_dir().join(format!("caly-io-std-proc-{label}-{pid}-{sequence}"));
    std::fs::create_dir_all(&root).expect("scratch root must be creatable");
    root.to_string_lossy().into_owned()
}

fn ctx() -> IoContext {
    IoContext::new(
        caly_io::TraceId::new("proc-std-contract"),
        caly_io::Actor::System,
    )
}

fn spawn(proc: &StdProc, spec: SpawnSpec) -> Result<caly_io::ChildHandle, caly_io::IoFault> {
    block_on_ready(proc.spawn(spec, &ctx()))
        .expect("the std port is ready on first poll, like every backend this workspace ships")
}

/// The shared spawn contract (`RFC-0006 §15` item 4), run against a real binary: the no-op
/// closure spawns `/bin/true`, because the one thing the closure owes the contract is "a
/// program this host can actually run".
#[test]
fn the_shared_spawn_contract_holds_on_a_real_host() {
    let root = scratch_root("shared");
    let proc = StdProc::new(&root);
    let violations = proc_spawn_contract_violations(
        &|| {
            spawn(
                &proc,
                SpawnSpec {
                    program: String::new(),
                    argv: Vec::new(),
                    cwd: None,
                    env: Vec::new(),
                },
            )
        },
        &|| {
            spawn(
                &proc,
                SpawnSpec {
                    program: "/bin/true".to_owned(),
                    argv: vec!["--caly-probe".to_owned()],
                    cwd: None,
                    env: Vec::new(),
                },
            )
        },
    );
    assert_eq!(violations, Vec::<String>::new());
}

/// The child runs in the cwd the spec named — resolved under the gateway root — and sees the
/// env the spec injected. The witness is the child itself: a `sh` the *caller* chose (not one
/// the port wrapped around the program) writes the probe file, and the judge waits for the
/// daemon's own filesystem to say it landed.
#[test]
fn a_child_sees_the_cwd_and_env_the_spec_named() {
    let root = scratch_root("cwd-env");
    // A spawn is not a mkdir: the caller's workspace has to exist before the child can work
    // in it (and the port refuses by naming the cwd when it does not — see the test below).
    std::fs::create_dir_all(format!("{root}/work")).expect("the work dir the spec will name");
    let proc = StdProc::new(&root);
    let handle = spawn(
        &proc,
        SpawnSpec {
            program: "/bin/sh".to_owned(),
            argv: vec![
                "-c".to_owned(),
                "printf %s \"$CALY_PROBE\" > probe.txt".to_owned(),
            ],
            cwd: Some(VPath::try_from_str("work").expect("static path")),
            env: vec![("CALY_PROBE".to_owned(), "via-the-port".to_owned())],
        },
    )
    .expect("spawn the probe child");
    assert!(handle.pid >= 1);

    let target = format!("{root}/work/probe.txt");
    let deadline = Instant::now() + Duration::from_secs(5);
    let content = loop {
        if let Ok(text) = std::fs::read_to_string(&target) {
            break text;
        }
        assert!(
            Instant::now() < deadline,
            "the probe child never wrote {target}"
        );
        std::thread::sleep(Duration::from_millis(25));
    };
    assert_eq!(
        content, "via-the-port",
        "the child saw the port's env, in the port's cwd"
    );
}

/// A program the host cannot find is `NotFound` naming the program — "no such binary" and
/// "spawn broken" are different failures with different operator moves, and a generic message
/// would hide which one happened.
#[test]
fn a_missing_program_is_not_found_by_name() {
    let root = scratch_root("missing");
    let proc = StdProc::new(&root);
    let fault = spawn(
        &proc,
        SpawnSpec {
            program: "caly-no-such-program".to_owned(),
            argv: Vec::new(),
            cwd: None,
            env: Vec::new(),
        },
    )
    .expect_err("the host has no such program");
    assert_eq!(
        fault.kind,
        caly_io::IoFaultKind::NotFound,
        "a missing binary is NotFound: {}",
        fault.summary
    );
    assert!(
        fault.summary.contains("caly-no-such-program"),
        "the refusal names the program it could not find: {}",
        fault.summary
    );
}

/// A cwd that does not exist is refused by naming the **cwd** — at the OS level a missing
/// program and a missing cwd are the same ENOENT, and a port that collapsed them into one
/// message about the program would send the operator hunting the wrong file.
#[test]
fn a_missing_cwd_is_refused_by_name_not_blamed_on_the_program() {
    let root = scratch_root("missing-cwd");
    let proc = StdProc::new(&root);
    let fault = spawn(
        &proc,
        SpawnSpec {
            program: "/bin/true".to_owned(),
            argv: Vec::new(),
            cwd: Some(VPath::try_from_str("never-created").expect("static path")),
            env: Vec::new(),
        },
    )
    .expect_err("the cwd does not exist");
    assert_eq!(fault.kind, caly_io::IoFaultKind::NotFound);
    assert!(
        fault.summary.contains("never-created") && fault.summary.contains("cwd"),
        "the refusal names the missing directory, not the program: {}",
        fault.summary
    );
}

/// `ADR-043`'s supervision contract on a real host: the four answers, against a child that
/// is genuinely alive (`sleep 30`) — plus the one check a real process adds for free: a
/// child that exits **by itself** (`true`) is observed as its own exit (code 0, not
/// signalled), which is the grace window's whole meaning.
#[test]
fn the_shared_supervision_contract_holds_on_a_real_host() {
    let root = scratch_root("supervision");
    let proc = StdProc::new(&root);
    let spawn_sleep = || {
        spawn(
            &proc,
            SpawnSpec {
                program: "/bin/sleep".to_owned(),
                argv: vec!["30".to_owned()],
                cwd: None,
                env: Vec::new(),
            },
        )
    };
    let try_wait =
        |handle: &caly_io::ChildHandle| block_on_ready(proc.try_wait(handle)).expect("ready");
    let stop = |handle: &caly_io::ChildHandle, grace_ms: u64| {
        block_on_ready(proc.stop(handle, grace_ms)).expect("ready")
    };
    assert_eq!(
        proc_supervision_contract_violations(&spawn_sleep, &try_wait, &stop),
        Vec::<String>::new()
    );

    // Natural exit: `true` leaves by itself, and the port must report it as the child's own
    // choice (code 0, not signalled) — not as the port's kill.
    let handle = spawn(
        &proc,
        SpawnSpec {
            program: "/bin/true".to_owned(),
            argv: Vec::new(),
            cwd: None,
            env: Vec::new(),
        },
    )
    .expect("spawn the short-lived child");
    let deadline = Instant::now() + Duration::from_secs(5);
    let exit = loop {
        if let Some(exit) = try_wait(&handle).expect("wait must not fail") {
            break exit;
        }
        assert!(
            Instant::now() < deadline,
            "the short-lived child never exited"
        );
        std::thread::sleep(Duration::from_millis(25));
    };
    assert_eq!(
        exit,
        caly_io::ChildExit {
            code: 0,
            signaled: false
        },
        "a child that exited by itself reports its own exit"
    );
}
