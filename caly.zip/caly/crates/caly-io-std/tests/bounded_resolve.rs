//! Bounded DNS resolution judges (`ADR-052` addendum §7): getaddrinfo is the one std
//! blocking call with NO timeout parameter, and before round 129 it ran on the caller's
//! thread with only a boundary check *before* it — a hung resolver parked a fetch past any
//! caller deadline. These judges pin the bounded behaviour end to end:
//!
//! * the real system resolver answers through the ONE shared thread (twice: the thread
//!   count never grows — one thread is the contract, not an implementation detail);
//! * an already-spent deadline refuses BY NAME at the DNS boundary and the resolver is
//!   never entered (zero injected calls — a syscall that cannot be interrupted is never
//!   started on a dead budget);
//! * a hung lookup: the caller times out by name; a second caller also times out (the
//!   honest head-of-line liability of exactly one thread); after the hang is released the
//!   SAME thread serves the next request — reclaim, not a poisoned worker;
//! * the caller's smaller budget wins over the peer timeout: a resolver slower than the
//!   caller's remaining time is a caller-deadline refusal, not a slow success.

use std::io;
use std::net::SocketAddr;
use std::sync::atomic::{AtomicBool, AtomicUsize, Ordering};
use std::sync::Arc;
use std::thread;
use std::time::Duration;

use caly_io::IoFaultKind;
use caly_io_std::{bounded_resolve, bounded_resolve_with, resolver_thread_count};

fn loopback(port: u16) -> SocketAddr {
    format!("127.0.0.1:{port}")
        .parse()
        .expect("loopback address")
}

#[test]
fn the_real_resolver_answers_through_exactly_one_shared_thread() {
    let first = bounded_resolve("localhost", 80, Duration::from_secs(5))
        .expect("localhost resolves through the bounded resolver");
    assert!(
        first.ip().is_loopback(),
        "hosts-file resolution answers a loopback address: {first:?}"
    );
    let second = bounded_resolve("localhost", 81, Duration::from_secs(5))
        .expect("a second resolve reuses the same thread");
    assert_eq!(second.port(), 81);
    assert_eq!(
        resolver_thread_count(),
        1,
        "the resolver is ONE lazily-spawned shared thread — a bounded liability, and a \
         contract (`resolver_thread_count` exists so per-call spawning cannot hide"
    );
}

#[test]
fn an_expired_deadline_refuses_by_name_without_entering_the_resolver() {
    let calls = Arc::new(AtomicUsize::new(0));
    let seen = calls.clone();
    let error = bounded_resolve_with(
        move |_host, _port| {
            seen.fetch_add(1, Ordering::Relaxed);
            Ok(vec![loopback(80)])
        },
        "example.invalid",
        80,
        Duration::ZERO,
    )
    .expect_err("a spent deadline never enters a syscall it cannot interrupt");
    assert_eq!(
        error.kind,
        IoFaultKind::Timeout,
        "the refusal is the caller deadline, not a network error: {}",
        error.summary
    );
    assert!(
        error.summary.contains("DNS resolution"),
        "the refusal names the boundary: {}",
        error.summary
    );
    assert!(
        error.summary.contains("never entered"),
        "the refusal says WHY nothing was started: {}",
        error.summary
    );
    assert_eq!(
        calls.load(Ordering::Relaxed),
        0,
        "a syscall that cannot be interrupted is never started on a dead budget"
    );
}

#[test]
fn a_hung_lookup_times_out_by_name_and_the_single_thread_recovers() {
    let release = Arc::new(AtomicBool::new(false));
    let gate_one = release.clone();
    let hung = move |_host: &str, _port: u16| -> io::Result<Vec<SocketAddr>> {
        while !gate_one.load(Ordering::Relaxed) {
            thread::sleep(Duration::from_millis(5));
        }
        Ok(vec![loopback(9)])
    };

    let first = bounded_resolve_with(hung, "hung.invalid", 80, Duration::from_millis(80))
        .expect_err("a hung resolver is a caller-deadline refusal");
    assert_eq!(first.kind, IoFaultKind::Timeout, "{}", first.summary);
    assert!(
        first.summary.contains("did not answer"),
        "the refusal names what happened: {}",
        first.summary
    );

    // The honest head-of-line liability: ONE thread serves every caller, so the second
    // caller ALSO times out — by name, at its own deadline — while the first lookup hangs.
    let gate_two = release.clone();
    let second = bounded_resolve_with(
        move |_host: &str, _port: u16| -> io::Result<Vec<SocketAddr>> {
            while !gate_two.load(Ordering::Relaxed) {
                thread::sleep(Duration::from_millis(5));
            }
            Ok(vec![loopback(9)])
        },
        "queued.invalid",
        80,
        Duration::from_millis(80),
    )
    .expect_err("head-of-line blocking is the price of exactly one thread");
    assert_eq!(second.kind, IoFaultKind::Timeout, "{}", second.summary);
    assert_eq!(
        resolver_thread_count(),
        1,
        "a hung lookup spawns nothing: the liability stays at one thread"
    );

    // Reclaim: release the hang; the stale requests drain into dropped receivers, and the
    // SAME thread serves a fresh request — the worker recovers, it is not poisoned.
    release.store(true, Ordering::Relaxed);
    let recovered = bounded_resolve_with(
        |_host, _port| Ok(vec![loopback(443)]),
        "after-release.invalid",
        443,
        Duration::from_secs(5),
    )
    .expect("the shared thread recovers after the hang returns");
    assert_eq!(recovered, loopback(443));
    assert_eq!(resolver_thread_count(), 1);
}

#[test]
fn the_callers_smaller_budget_wins_over_the_peer_timeout() {
    // The rule every other blocking syscall already follows (`CallerControl::timeout`):
    // min(peer timeout, caller remaining). A resolver slower than the caller's remaining
    // time must refuse at the CALLER's deadline — not succeed late, and not borrow the
    // peer's full budget.
    let slow = |_host: &str, _port: u16| -> io::Result<Vec<SocketAddr>> {
        thread::sleep(Duration::from_millis(400));
        Ok(vec![loopback(80)])
    };
    let started = std::time::Instant::now();
    let error = bounded_resolve_with(slow, "slow.invalid", 80, Duration::from_millis(50))
        .expect_err("the caller's budget is the bound that matters");
    assert_eq!(error.kind, IoFaultKind::Timeout, "{}", error.summary);
    assert!(
        started.elapsed() < Duration::from_millis(350),
        "the refusal arrives at the caller's budget, not the resolver's pace ({:?})",
        started.elapsed()
    );
}
