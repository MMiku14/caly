//! `StdHttp` on a real socket, against a scripted local server.
//!
//! `RFC-0006 §15` requires one shared suite for both port adapters; the shared half of that
//! suite lives in `caly_io::contract::http_fetch_contract_violations` and runs here exactly as
//! it runs against the simulator. The std-specific half judges what only a real HTTP peer can
//! prove: conditional requests, the honest `https` refusal, and a refused connection naming the
//! host it could not reach.

use std::io::{Read, Write};
use std::net::TcpListener;
use std::sync::Arc;

use caly_io::{block_on_ready, FetchReq, Http, IoContext};
use caly_io_std::{StdClock, StdHttp};

/// What one scripted connection answers: status, extra headers, body.
type Scripted = fn(&str, &str) -> (u16, Vec<(String, String)>, Vec<u8>);

fn ctx() -> IoContext {
    IoContext::new(
        caly_io::TraceId::new("http-std-contract"),
        caly_io::Actor::System,
    )
}

fn budgeted(max_bytes: u64) -> IoContext {
    let mut context = ctx();
    context.io_budget = caly_io::IoBudget {
        max_bytes: Some(max_bytes),
        max_requests: None,
    };
    context
}

fn request(url: &str, max_body_bytes: u64) -> FetchReq {
    FetchReq {
        url: url.to_owned(),
        route: caly_io::FetchRoute::Direct,
        // These judges run against 127.0.0.1; the scope tests below opt out explicitly.
        scope: caly_io::FetchScope::AnyPeer,
        etag: None,
        if_modified_since: None,
        max_body_bytes,
    }
}

/// A one-shot scripted server: every accepted connection is answered by `respond`, then closed.
/// Scripted like `ScriptedHttp`, but over a real socket — the scenario is the same, which is the
/// point of the shared suite.
fn scripted_server(respond: Scripted) -> String {
    let listener = TcpListener::bind("127.0.0.1:0").expect("bind a loopback listener");
    let port = listener.local_addr().expect("bound address").port();
    std::thread::spawn(move || {
        for stream in listener.incoming() {
            let mut stream = match stream {
                Ok(stream) => stream,
                Err(_) => break,
            };
            let mut buffer = [0u8; 8192];
            let read = stream.read(&mut buffer).unwrap_or(0);
            let text = String::from_utf8_lossy(&buffer[..read]).into_owned();
            let path = text.split_whitespace().nth(1).unwrap_or("/").to_owned();
            let conditional = text
                .lines()
                .find(|line| line.to_ascii_lowercase().starts_with("if-none-match:"))
                .map(|line| line.to_owned());
            let (status, headers, body) = respond(&path, conditional.as_deref().unwrap_or(""));
            let mut answer = format!("HTTP/1.1 {status} X\r\nContent-Length: {}\r\n", body.len());
            for (name, value) in headers {
                answer.push_str(&format!("{name}: {value}\r\n"));
            }
            answer.push_str("Connection: close\r\n\r\n");
            stream.write_all(answer.as_bytes()).ok();
            stream.write_all(&body).ok();
        }
    });
    format!("http://127.0.0.1:{port}")
}

/// `/big` answers 2 KiB, like the simulator's scripted body: one scenario, two backends.
fn big_body(path: &str, _conditional: &str) -> (u16, Vec<(String, String)>, Vec<u8>) {
    assert_eq!(
        path, "/big",
        "the shared contract fetches one scripted path"
    );
    (200, Vec::new(), vec![b'z'; 2_048])
}

#[test]
fn std_http_satisfies_the_shared_fetch_contract() {
    let base = scripted_server(big_body);
    let url = format!("{base}/big");
    let http = StdHttp::default();
    let fetch = |max_body_bytes: u64, budget: Option<u64>| {
        let context = match budget {
            Some(max_bytes) => budgeted(max_bytes),
            None => ctx(),
        };
        block_on_ready(http.fetch(request(&url, max_body_bytes), &context)).expect("ready")
    };
    assert_eq!(
        caly_io::contract::http_fetch_contract_violations(&url, &fetch),
        Vec::<String>::new()
    );
}

/// Conditional requests are the capability a real peer adds over the scripted simulator: the
/// first fetch reports the validator, the second presents it, and `304` is the answer, carried
/// as-is — "unchanged" is a result, not an error the adapter translates away.
#[test]
fn a_presented_etag_gets_304_as_the_answer() {
    fn etagged(_path: &str, conditional: &str) -> (u16, Vec<(String, String)>, Vec<u8>) {
        if conditional.is_empty() {
            (
                200,
                vec![("ETag".to_owned(), "W/\"v1\"".to_owned())],
                b"version-one".to_vec(),
            )
        } else {
            (
                304,
                vec![("ETag".to_owned(), "W/\"v1\"".to_owned())],
                Vec::new(),
            )
        }
    }
    let base = scripted_server(etagged);
    let url = format!("{base}/etag");
    let http = StdHttp::default();

    let first = block_on_ready(http.fetch(request(&url, 1_024), &ctx()))
        .expect("ready")
        .expect("the first fetch carries the body");
    assert_eq!(first.status, 200);
    assert_eq!(first.etag.as_deref(), Some("W/\"v1\""));

    let mut conditional = request(&url, 1_024);
    conditional.etag = first.etag.clone();
    let second = block_on_ready(http.fetch(conditional, &ctx()))
        .expect("ready")
        .expect("304 is an answer, not an error");
    assert_eq!(second.status, 304, "the validator held: nothing changed");
}

/// `https` is refused with the doctrine named, before any connection exists: TLS needs a client
/// the no-external-crate rule cannot provide (`RFC-0001 §1.4`), and failing mid-handshake with
/// a socket error would be a lie in the shape of a connection attempt.
#[test]
fn https_is_refused_with_the_doctrine_named_not_a_socket_error() {
    let fault =
        block_on_ready(StdHttp::default().fetch(request("https://example.test/x", 1_024), &ctx()))
            .expect("ready")
            .expect_err("https must be refused before any connection exists");
    assert_eq!(fault.kind, caly_io::IoFaultKind::Unsupported, "{fault:?}");
    assert!(
        fault.summary.contains("https") && fault.summary.contains("no-external-crate"),
        "the refusal must name what and why: {}",
        fault.summary
    );
}

/// A refused connection is `Unavailable` with the address named — reachable-ness is a fact about
/// the peer, not damage inside the adapter.
#[test]
fn a_refused_connection_is_unavailable_and_names_the_address() {
    // Bind, learn the port, drop the listener: connecting there is refused, deterministically.
    let listener = TcpListener::bind("127.0.0.1:0").expect("bind");
    let port = listener.local_addr().expect("addr").port();
    drop(listener);
    let url = format!("http://127.0.0.1:{port}/gone");
    let fault = block_on_ready(StdHttp::default().fetch(request(&url, 1_024), &ctx()))
        .expect("ready")
        .expect_err("nothing is listening there");
    assert!(
        fault.kind == caly_io::IoFaultKind::Unavailable
            || fault.kind == caly_io::IoFaultKind::Timeout,
        "a refused connection is a peer fact: {fault:?}"
    );
    assert!(
        fault.summary.contains("127.0.0.1"),
        "the refusal must name the address it could not reach: {}",
        fault.summary
    );
}

#[test]
fn std_http_checks_cancellation_before_dns_or_socket() {
    let context = ctx();
    context.cancel.cancel();
    let fault = block_on_ready(
        StdHttp::default().fetch(request("http://127.0.0.1:1/never", 1_024), &context),
    )
    .expect("the adapter future is driven to a typed answer")
    .expect_err("a cancelled caller must not start a socket attempt");
    assert_eq!(fault.kind, caly_io::IoFaultKind::Cancelled, "{fault:?}");
}

#[test]
fn std_http_checks_an_expired_deadline_with_the_injected_clock() {
    let clock = Arc::new(StdClock::new());
    let http = StdHttp::default().with_clock(clock);
    let mut context = ctx();
    context.deadline_ms = Some(0);
    let fault = block_on_ready(http.fetch(request("http://127.0.0.1:1/never", 1_024), &context))
        .expect("the adapter future is driven to a typed answer")
        .expect_err("an expired caller deadline must be judged before connect");
    assert_eq!(fault.kind, caly_io::IoFaultKind::Timeout, "{fault:?}");
    assert!(fault.summary.contains("deadline"), "{fault:?}");
}

/// A server that accepts one connection, reads the request, then **stalls** — it never answers.
/// It also reports, in order: when the request arrived, and whether the client's side of the
/// socket was reclaimed (EOF / reset) after the client gave up.
fn stalled_server() -> (
    String,
    std::sync::mpsc::Receiver<()>,
    std::sync::mpsc::Receiver<bool>,
) {
    let listener = TcpListener::bind("127.0.0.1:0").expect("bind a loopback listener");
    let port = listener.local_addr().expect("bound address").port();
    let (seen_tx, seen_rx) = std::sync::mpsc::channel();
    let (eof_tx, eof_rx) = std::sync::mpsc::channel();
    std::thread::spawn(move || {
        let (mut stream, _) = listener.accept().expect("accept the stalled connection");
        // Read the whole request head so the client is definitely blocked in its status-line
        // read when the cancellation token fires.
        let mut buffer = [0u8; 8192];
        let mut head = Vec::new();
        while head.len() < 16_384 && !head.windows(4).any(|w| w == b"\r\n\r\n") {
            match stream.read(&mut buffer) {
                Ok(0) => break,
                Ok(n) => head.extend_from_slice(&buffer[..n]),
                Err(_) => break,
            }
        }
        let _ = seen_tx.send(());
        // Stall: hold the connection open, never write a byte.
        let mut byte = [0u8; 1];
        loop {
            match stream.read(&mut byte) {
                Ok(0) => {
                    let _ = eof_tx.send(true);
                    return;
                }
                Err(_) => {
                    let _ = eof_tx.send(true);
                    return;
                }
                Ok(_) => continue,
            }
        }
    });
    (format!("http://127.0.0.1:{port}/stall"), seen_rx, eof_rx)
}

/// `ADR-052 §2.2`: a stalled peer is reclaimed by the caller deadline, not by the adapter's
/// peer timeout. The deadline is 600ms while the peer timeout is 10s, so a correct
/// implementation returns in under a second; an implementation that ignores the caller
/// deadline and only applies its own IO_TIMEOUT takes 10s and fails the time bound.
#[test]
fn a_stalled_peer_is_reclaimed_by_the_caller_deadline() {
    let (url, _seen, eof) = stalled_server();
    let clock = Arc::new(StdClock::new());
    let http = StdHttp::default().with_clock(clock.clone());
    let mut context = ctx();
    context.deadline_ms = Some(600);
    let begun = std::time::Instant::now();
    let fault = block_on_ready(http.fetch(request(&url, 1_024), &context))
        .expect("the adapter future is driven to a typed answer")
        .expect_err("a stalled peer must be reclaimed, never hang");
    let elapsed = begun.elapsed();
    assert_eq!(fault.kind, caly_io::IoFaultKind::Timeout, "{fault:?}");
    assert!(
        elapsed < std::time::Duration::from_secs(5),
        "the caller deadline (600ms) must bound the read, not the peer timeout (10s): \
         took {elapsed:?}"
    );
    assert!(
        fault.summary.contains("status line"),
        "the refusal must name the phase: {fault:?}"
    );
    assert!(
        eof.recv_timeout(std::time::Duration::from_secs(2))
            .unwrap_or(false),
        "after reclaim the socket must be closed and the peer must see EOF (ADR-052 §2.4)"
    );
}

/// `ADR-052 §2.1`: a cancellation token set while the read is already blocked cannot interrupt
/// the syscall — the honest answer is the bounded reclaim (Timeout after ~the deadline), never
/// a claim of instant interruption (which would be a Cancelled answer returned immediately).
///
/// The judge re-arms the race, deliberately. "The stalled server saw the request" does not
/// prove the client thread is inside the blocked read: after `flush` returns there are two
/// phase-boundary checks before the read syscall starts (`HTTP response headers` and
/// `the HTTP status line`), and the fetch thread can be descheduled in between — a window
/// that is not observable from outside. If the cancel lands there, the boundary answer
/// (`Cancelled` naming the phase, or a deadline `Timeout` naming it) is honest but is not the
/// interleaving under test; the judge records it and re-arms. It passes only on the genuine
/// in-flight interleaving (Timeout reclaim after >= 400ms + peer EOF). Any other answer fails
/// immediately, and an implementation that claims mid-syscall interruption produces the raced
/// answer on every attempt, so the attempt cap turns it into a deterministic failure. The
/// fetch answer itself is awaited under a bound: a read with no bound would hang this judge
/// forever, so "no answer within 5s" is itself the ADR-052 §2.2 failure.
#[test]
fn a_cancel_during_a_blocked_read_does_not_claim_interruption() {
    const ATTEMPTS: u32 = 10;
    let mut raced = 0u32;
    for attempt in 1..=ATTEMPTS {
        let (url, seen, eof) = stalled_server();
        let clock = Arc::new(StdClock::new());
        let http = StdHttp::default().with_clock(clock);
        let mut context = ctx();
        context.deadline_ms = Some(600);
        let cancel = context.cancel.clone();
        let begun = std::time::Instant::now();
        // The fetch runs on its own thread so the test can cancel from outside, while the
        // client is supposed to be blocked inside its status-line read. The answer travels
        // back over a channel so the wait itself is bounded.
        let (answer_tx, answer_rx) = std::sync::mpsc::channel();
        std::thread::spawn(move || {
            let _ = answer_tx.send(
                block_on_ready(http.fetch(request(&url, 1_024), &context))
                    .expect("the adapter future is driven to a typed answer"),
            );
        });
        // The stalled server saw the full request head; the client has written it and is
        // (modulo the deschedule window above) blocked in `read_line`. Only then does the
        // caller give up.
        seen.recv_timeout(std::time::Duration::from_secs(2))
            .expect("the stalled server must have seen the request");
        cancel.cancel();
        let fault = answer_rx
            .recv_timeout(std::time::Duration::from_secs(5))
            .unwrap_or_else(|error| {
                panic!(
                    "no bounded reclaim within 5s (ADR-052 §2.2): the blocked read was never \
                     bounded ({error:?})"
                )
            })
            .expect_err("a stalled peer must be reclaimed, never hang");
        let elapsed = begun.elapsed();
        match (fault.kind, fault.summary.as_str()) {
            // The intended interleaving: the cancel arrived while the status-line read was
            // in flight, so the answer is the read's own timeout (bounded reclaim) and the
            // socket is closed afterwards.
            (caly_io::IoFaultKind::Timeout, summary) if summary.contains("read status line") => {
                assert!(
                    elapsed >= std::time::Duration::from_millis(400),
                    "the reclaim must be the syscall's own timeout, not an instant \
                     'cancelled' claim: took {elapsed:?}"
                );
                assert!(
                    eof.recv_timeout(std::time::Duration::from_secs(2))
                        .unwrap_or(false),
                    "after reclaim the socket must be closed and the peer must see EOF \
                     (ADR-052 §2.4)"
                );
                return;
            }
            // Honest-but-not-the-interleaving answers: the cancel (or the deadline) was
            // observed at a phase boundary while no read syscall was in flight. Record and
            // re-arm; the test passes only once the blocked-read interleaving occurs.
            (caly_io::IoFaultKind::Cancelled | caly_io::IoFaultKind::Timeout, summary)
                if summary.contains("HTTP response headers")
                    || summary.contains("before the HTTP status line") =>
            {
                raced += 1;
                eprintln!(
                    "  note  attempt {attempt}/{ATTEMPTS}: the cancel landed at a phase \
                     boundary before the read syscall ({summary}); re-arming ({raced} race(s))"
                );
                continue;
            }
            (kind, summary) => panic!(
                "unexpected answer on attempt {attempt}/{ATTEMPTS}: {kind:?} ({summary:?}) \
                 after {elapsed:?}; expected the honest timed reclaim (ADR-052 §2.1)"
            ),
        }
    }
    panic!(
        "the blocked-read interleaving was never established in {ATTEMPTS} attempts \
         ({raced} boundary races observed): the environment is too contended, or the \
         implementation claims mid-syscall interruption on every attempt"
    );
}

/// A one-shot server for the SSRF judge: accepts one connection, reports how many request
/// bytes arrived before the client abandoned the conversation, then closes. The client is
/// expected to connect and immediately drop (the boundary check happens after connect,
/// before a single byte is written — RFC-0010 §11.1's "connection-after address check").
fn refusing_server() -> (String, std::sync::mpsc::Receiver<usize>) {
    let listener = TcpListener::bind("127.0.0.1:0").expect("bind a loopback listener");
    let port = listener.local_addr().expect("bound address").port();
    let (seen_tx, seen_rx) = std::sync::mpsc::channel();
    std::thread::spawn(move || {
        let (mut stream, _) = listener.accept().expect("accept");
        let mut buffer = [0u8; 8192];
        let read = stream.read(&mut buffer).unwrap_or(0);
        let _ = seen_tx.send(read);
        // Drop anyway: the conversation is over either way.
    });
    (format!("http://127.0.0.1:{port}/ssrf"), seen_rx)
}

/// RFC-0010 §11.1: the conservative default refuses a loopback peer **by name** — and the
/// refusal is a `PermissionDenied` naming the boundary, not a socket error. The check is
/// post-connect (the SSRF judge for a rebinding answer), so the server sees a connection
/// that carries no request at all.
#[test]
fn the_default_scope_refuses_a_loopback_peer_by_name() {
    let (url, seen) = refusing_server();
    let http = StdHttp::default();
    let context = ctx();
    let mut req = request(&url, 1_024);
    req.scope = caly_io::FetchScope::Default;
    let fault = block_on_ready(http.fetch(req, &context))
        .expect("the adapter future is driven to a typed answer")
        .expect_err("a loopback target must be refused under the default scope");
    assert_eq!(
        fault.kind,
        caly_io::IoFaultKind::PermissionDenied,
        "{fault:?}"
    );
    assert!(
        fault.summary.contains("loopback"),
        "the refusal must name the class: {}",
        fault.summary
    );
    assert!(
        fault.summary.contains("RFC-0010 §11.1"),
        "the refusal must name the policy: {}",
        fault.summary
    );
    let bytes = seen
        .recv_timeout(std::time::Duration::from_secs(2))
        .expect("the server must have seen the connection");
    assert_eq!(
        bytes, 0,
        "nothing may be written to a refused peer: the boundary is checked after connect, \
         before the request"
    );
}

/// The explicit opt-in works: same loopback peer, `AnyPeer` — the request goes through and
/// really arrives. The default is conservative precisely because `AnyPeer` is a decision
/// the caller makes, not a guess the adapter makes.
#[test]
fn an_explicit_any_peer_scope_allows_a_loopback_peer() {
    let (url, seen) = refusing_server();
    let http = StdHttp::default();
    let context = ctx();
    let mut req = request(&url, 1_024);
    req.scope = caly_io::FetchScope::AnyPeer;
    let outcome = block_on_ready(http.fetch(req, &context))
        .expect("the adapter future is driven to a typed answer");
    let bytes = seen
        .recv_timeout(std::time::Duration::from_secs(2))
        .expect("the server must have seen the connection");
    assert!(
        bytes > 0,
        "AnyPeer must let the request through the boundary: {bytes} bytes were not enough"
    );
    // The server answered nothing, so the fetch itself fails — but the boundary was passed,
    // which is what this judge holds down (the refusal error would be PermissionDenied).
    if let Err(fault) = outcome {
        assert_ne!(
            fault.kind,
            caly_io::IoFaultKind::PermissionDenied,
            "an opted-in peer must not be refused by the SSRF gate: {fault:?}"
        );
    }
}

/// RFC-0010 §11.1's partition, pinned: the three sensitive families and everything else.
#[test]
fn peer_address_classification_covers_the_rfc_partition() {
    use caly_io_std::{classify_peer_address, PeerClass};
    use std::net::SocketAddr;
    let classify = |address: &str| -> PeerClass {
        classify_peer_address(&address.parse::<SocketAddr>().expect("a socket address"))
    };
    assert_eq!(classify("127.0.0.1:1"), PeerClass::Loopback);
    assert_eq!(classify("127.255.255.254:1"), PeerClass::Loopback);
    assert_eq!(classify("[::1]:1"), PeerClass::Loopback);
    assert_eq!(
        classify("169.254.169.254:1"),
        PeerClass::LinkLocalOrMetadata
    );
    assert_eq!(classify("169.254.0.1:1"), PeerClass::LinkLocalOrMetadata);
    assert_eq!(classify("[fe80::1]:1"), PeerClass::LinkLocalOrMetadata);
    assert_eq!(classify("10.1.2.3:1"), PeerClass::Private);
    assert_eq!(classify("172.16.0.1:1"), PeerClass::Private);
    assert_eq!(classify("172.31.255.255:1"), PeerClass::Private);
    assert_eq!(classify("192.168.1.1:1"), PeerClass::Private);
    assert_eq!(classify("100.64.0.1:1"), PeerClass::Private);
    assert_eq!(classify("[fc00::1]:1"), PeerClass::Private);
    assert_eq!(classify("8.8.8.8:1"), PeerClass::Public);
    assert_eq!(classify("223.5.5.5:1"), PeerClass::Public);
    assert_eq!(classify("[2001:4860:4860::8888]:1"), PeerClass::Public);
}
