//! `StdHttp` on a real socket, against a scripted local server.
//!
//! `RFC-0006 §15` requires one shared suite for both port adapters; the shared half of that
//! suite lives in `caly_io::contract::http_fetch_contract_violations` and runs here exactly as
//! it runs against the simulator. The std-specific half judges what only a real HTTP peer can
//! prove: conditional requests, the honest `https` refusal, and a refused connection naming the
//! host it could not reach.

use std::io::{Read, Write};
use std::net::TcpListener;
use std::sync::Arc;

use caly_io::{block_on_ready, FetchReq, Http, IoContext};
use caly_io_std::{StdClock, StdHttp};

/// What one scripted connection answers: status, extra headers, body.
type Scripted = fn(&str, &str) -> (u16, Vec<(String, String)>, Vec<u8>);

fn ctx() -> IoContext {
    IoContext::new(
        caly_io::TraceId::new("http-std-contract"),
        caly_io::Actor::System,
    )
}

fn budgeted(max_bytes: u64) -> IoContext {
    let mut context = ctx();
    context.io_budget = caly_io::IoBudget {
        max_bytes: Some(max_bytes),
        max_requests: None,
    };
    context
}

fn request(url: &str, max_body_bytes: u64) -> FetchReq {
    FetchReq {
        url: url.to_owned(),
        route: caly_io::FetchRoute::Direct,
        etag: None,
        if_modified_since: None,
        max_body_bytes,
    }
}

/// A one-shot scripted server: every accepted connection is answered by `respond`, then closed.
/// Scripted like `ScriptedHttp`, but over a real socket — the scenario is the same, which is the
/// point of the shared suite.
fn scripted_server(respond: Scripted) -> String {
    let listener = TcpListener::bind("127.0.0.1:0").expect("bind a loopback listener");
    let port = listener.local_addr().expect("bound address").port();
    std::thread::spawn(move || {
        for stream in listener.incoming() {
            let mut stream = match stream {
                Ok(stream) => stream,
                Err(_) => break,
            };
            let mut buffer = [0u8; 8192];
            let read = stream.read(&mut buffer).unwrap_or(0);
            let text = String::from_utf8_lossy(&buffer[..read]).into_owned();
            let path = text.split_whitespace().nth(1).unwrap_or("/").to_owned();
            let conditional = text
                .lines()
                .find(|line| line.to_ascii_lowercase().starts_with("if-none-match:"))
                .map(|line| line.to_owned());
            let (status, headers, body) = respond(&path, conditional.as_deref().unwrap_or(""));
            let mut answer = format!("HTTP/1.1 {status} X\r\nContent-Length: {}\r\n", body.len());
            for (name, value) in headers {
                answer.push_str(&format!("{name}: {value}\r\n"));
            }
            answer.push_str("Connection: close\r\n\r\n");
            stream.write_all(answer.as_bytes()).ok();
            stream.write_all(&body).ok();
        }
    });
    format!("http://127.0.0.1:{port}")
}

/// `/big` answers 2 KiB, like the simulator's scripted body: one scenario, two backends.
fn big_body(path: &str, _conditional: &str) -> (u16, Vec<(String, String)>, Vec<u8>) {
    assert_eq!(
        path, "/big",
        "the shared contract fetches one scripted path"
    );
    (200, Vec::new(), vec![b'z'; 2_048])
}

#[test]
fn std_http_satisfies_the_shared_fetch_contract() {
    let base = scripted_server(big_body);
    let url = format!("{base}/big");
    let http = StdHttp::default();
    let fetch = |max_body_bytes: u64, budget: Option<u64>| {
        let context = match budget {
            Some(max_bytes) => budgeted(max_bytes),
            None => ctx(),
        };
        block_on_ready(http.fetch(request(&url, max_body_bytes), &context)).expect("ready")
    };
    assert_eq!(
        caly_io::contract::http_fetch_contract_violations(&url, &fetch),
        Vec::<String>::new()
    );
}

/// Conditional requests are the capability a real peer adds over the scripted simulator: the
/// first fetch reports the validator, the second presents it, and `304` is the answer, carried
/// as-is — "unchanged" is a result, not an error the adapter translates away.
#[test]
fn a_presented_etag_gets_304_as_the_answer() {
    fn etagged(_path: &str, conditional: &str) -> (u16, Vec<(String, String)>, Vec<u8>) {
        if conditional.is_empty() {
            (
                200,
                vec![("ETag".to_owned(), "W/\"v1\"".to_owned())],
                b"version-one".to_vec(),
            )
        } else {
            (
                304,
                vec![("ETag".to_owned(), "W/\"v1\"".to_owned())],
                Vec::new(),
            )
        }
    }
    let base = scripted_server(etagged);
    let url = format!("{base}/etag");
    let http = StdHttp::default();

    let first = block_on_ready(http.fetch(request(&url, 1_024), &ctx()))
        .expect("ready")
        .expect("the first fetch carries the body");
    assert_eq!(first.status, 200);
    assert_eq!(first.etag.as_deref(), Some("W/\"v1\""));

    let mut conditional = request(&url, 1_024);
    conditional.etag = first.etag.clone();
    let second = block_on_ready(http.fetch(conditional, &ctx()))
        .expect("ready")
        .expect("304 is an answer, not an error");
    assert_eq!(second.status, 304, "the validator held: nothing changed");
}

/// `https` is refused with the doctrine named, before any connection exists: TLS needs a client
/// the no-external-crate rule cannot provide (`RFC-0001 §1.4`), and failing mid-handshake with
/// a socket error would be a lie in the shape of a connection attempt.
#[test]
fn https_is_refused_with_the_doctrine_named_not_a_socket_error() {
    let fault =
        block_on_ready(StdHttp::default().fetch(request("https://example.test/x", 1_024), &ctx()))
            .expect("ready")
            .expect_err("https must be refused before any connection exists");
    assert_eq!(fault.kind, caly_io::IoFaultKind::Unsupported, "{fault:?}");
    assert!(
        fault.summary.contains("https") && fault.summary.contains("no-external-crate"),
        "the refusal must name what and why: {}",
        fault.summary
    );
}

/// A refused connection is `Unavailable` with the address named — reachable-ness is a fact about
/// the peer, not damage inside the adapter.
#[test]
fn a_refused_connection_is_unavailable_and_names_the_address() {
    // Bind, learn the port, drop the listener: connecting there is refused, deterministically.
    let listener = TcpListener::bind("127.0.0.1:0").expect("bind");
    let port = listener.local_addr().expect("addr").port();
    drop(listener);
    let url = format!("http://127.0.0.1:{port}/gone");
    let fault = block_on_ready(StdHttp::default().fetch(request(&url, 1_024), &ctx()))
        .expect("ready")
        .expect_err("nothing is listening there");
    assert!(
        fault.kind == caly_io::IoFaultKind::Unavailable
            || fault.kind == caly_io::IoFaultKind::Timeout,
        "a refused connection is a peer fact: {fault:?}"
    );
    assert!(
        fault.summary.contains("127.0.0.1"),
        "the refusal must name the address it could not reach: {}",
        fault.summary
    );
}

#[test]
fn std_http_checks_cancellation_before_dns_or_socket() {
    let context = ctx();
    context.cancel.cancel();
    let fault = block_on_ready(
        StdHttp::default().fetch(request("http://127.0.0.1:1/never", 1_024), &context),
    )
    .expect("the adapter future is driven to a typed answer")
    .expect_err("a cancelled caller must not start a socket attempt");
    assert_eq!(fault.kind, caly_io::IoFaultKind::Cancelled, "{fault:?}");
}

#[test]
fn std_http_checks_an_expired_deadline_with_the_injected_clock() {
    let clock = Arc::new(StdClock::new());
    let http = StdHttp::default().with_clock(clock);
    let mut context = ctx();
    context.deadline_ms = Some(0);
    let fault = block_on_ready(http.fetch(request("http://127.0.0.1:1/never", 1_024), &context))
        .expect("the adapter future is driven to a typed answer")
        .expect_err("an expired caller deadline must be judged before connect");
    assert_eq!(fault.kind, caly_io::IoFaultKind::Timeout, "{fault:?}");
    assert!(fault.summary.contains("deadline"), "{fault:?}");
}
