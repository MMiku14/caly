//! The real core, really run (`ROADMAP §13`'s "真 effect 后端", first slice — the assets and
//! the `Proc` surface it needs, judged against a genuine mihomo binary and genuine geo
//! databases). The executor-side composition (`EngineHandle`'s runtime unbind) is the next
//! round's decision; what this file holds down is everything that composition will stand on:
//!
//! * the downloaded assets are **pinned by digest** — a judge that skipped because the file
//!   was missing or corrupt would be a gate that reports clean precisely when it did not run
//!   (`check.sh`'s own design rule, applied to binaries);
//! * a real core's whole lifecycle goes through the **port** (`ADR-043` supervision): spawn,
//!   `try_wait` = still running, health via the `Http` port against the core's own
//!   controller, `stop` inside its grace story, and an exit that replays monotonically;
//! * the geo databases are **load-bearing, not decoration**: the config's GEOSITE/GEOIP rules
//!   make the core fatally refuse to start without them (its download fallback is pointed at
//!   an unreachable address, so the refusal is deterministic and never a network fluke).
//!
//! Harness plumbing (`cp`/`gunzip`/`chmod`, port picking, config writing) is this file's own;
//! everything the daemon will someday do is exercised through the ports.

use std::net::{TcpListener, TcpStream};
use std::process::{Command, Stdio};
use std::sync::atomic::{AtomicU64, Ordering};
use std::time::{Duration, Instant};

use caly_io::{block_on_ready, FetchReq, Http, IoContext, Proc, SpawnSpec};
use caly_io_std::{StdHttp, StdProc};

/// The workspace's committed assets, pinned by the sha256 of the exact bytes this suite was
/// built against (`RFC-0010 §14` item 5: download verification is a gate, not a hope). A
/// drifted or missing asset fails by name — it is never skipped.
const MIHOMO_GZ: &str = "assets/cores/mihomo-linux-amd64-v1.19.30.gz";
const MIHOMO_GZ_SHA256: &str = "cf06ce2c7d1421bdbda14ee4a5b6046672dc35ebf8eecd8e77504ec3c0ed9a84";
// 2026-09-01 re-pin (documented in CHANGELOG.md): the upstream zip shipped assets/ as empty
// directories, and MetaCubeX keeps only a rolling "latest" release — the previously pinned
// geo snapshots are not retrievable from any archive. These pins are the current upstream
// builds, fetched by scripts/fetch_assets.sh. The cores above are still the original pins.
// 2026-09-02 re-pin (environment handover round, documented in CHANGELOG.md): the rolling
// "latest" moved again, so the freshly fetched builds differ from the 2026-09-01 pins. Both
// geo tests stayed green on the new bytes before re-pinning (drift is supply-chain news, not
// a silent swap). Old pins preserved in docs/history/ONBOARDING_NOTES.md §4.192.
const GEOIP_METADB: &str = "assets/geo/geoip.metadb";
const GEOIP_METADB_SHA256: &str =
    "931759498376c6f0fb8ae1f5d062848511d618cf013c40072f65492ee8c0899d";
const GEOSITE_DAT: &str = "assets/geo/geosite.dat";
const GEOSITE_DAT_SHA256: &str = "76d21fd071d108fcd6bf51958fbbc5bd786adb8d7ad1a701aac930d4035e1a1f";

static SCRATCH_SEQUENCE: AtomicU64 = AtomicU64::new(0);

fn workspace_root() -> String {
    // CARGO_MANIFEST_DIR = crates/caly-io-std; the assets live at the workspace root.
    let manifest = env!("CARGO_MANIFEST_DIR");
    let cut = manifest.len() - "crates/caly-io-std".len();
    manifest[..cut].to_owned()
}

fn asset_path(relative: &str) -> String {
    format!("{}/{relative}", workspace_root())
}

/// sha256 of a file, computed by this harness with the system tool — the digest is the claim,
/// and the pinned constant in this file is the independent copy a tampered file cannot reach.
fn sha256_of(path: &str) -> String {
    let output = Command::new("sha256sum")
        .arg(path)
        .output()
        .expect("sha256sum must exist on this host");
    assert!(
        output.status.success(),
        "sha256sum failed on {path}: {}",
        String::from_utf8_lossy(&output.stderr)
    );
    String::from_utf8_lossy(&output.stdout)
        .split_whitespace()
        .next()
        .unwrap_or_default()
        .to_owned()
}

/// A scratch root that removes itself when the test ends. Each run decompresses a real core
/// (~50MB) twice over, so a suite that forgets its scratch is a suite that fills the temp
/// filesystem — which is exactly how this guard was born: the falsify harness ran five
/// mutated suites back to back and `/tmp` (a 1GB tmpfs) hit "no space left on device".
struct ScratchDir {
    path: String,
}

impl Drop for ScratchDir {
    fn drop(&mut self) {
        let _ = std::fs::remove_dir_all(&self.path);
    }
}

fn scratch_root(label: &str) -> ScratchDir {
    let sequence = SCRATCH_SEQUENCE.fetch_add(1, Ordering::SeqCst);
    let path = format!(
        "{}/caly-real-core-{label}-{}-{sequence}",
        std::env::temp_dir().to_string_lossy(),
        std::process::id(),
    );
    std::fs::create_dir_all(&path).expect("scratch root");
    ScratchDir { path }
}

/// Decompress the committed core binary into `dir` and make it executable.
fn materialize_core_binary(dir: &str) -> String {
    let gz = asset_path(MIHOMO_GZ);
    let copied = format!("{dir}/mihomo.gz");
    std::fs::copy(&gz, &copied).unwrap_or_else(|error| panic!("copy {gz}: {error}"));
    let gunzip = Command::new("gunzip")
        .arg("-k")
        .arg(&copied)
        .status()
        .expect("gunzip must exist on this host");
    assert!(gunzip.success(), "gunzip failed on {copied}");
    let binary = format!("{dir}/mihomo");
    let chmod = Command::new("chmod")
        .arg("+x")
        .arg(&binary)
        .status()
        .expect("chmod");
    assert!(chmod.success(), "chmod failed on {binary}");
    binary
}

fn free_port() -> u16 {
    TcpListener::bind("127.0.0.1:0")
        .expect("bind for a free port")
        .local_addr()
        .expect("a local address")
        .port()
}

/// The config a real mihomo will actually run: an inbound, its controller API (so the `Http`
/// port can ask it whether it is alive), GEOIP+GEOSITE rules (so the geo databases are
/// load-bearing), and the download fallback pointed at an unreachable address — missing geo
/// files must be a **deterministic** refusal, never a network fetch that happens to succeed.
fn core_config(mixed_port: u16, controller_port: u16) -> String {
    format!(
        "mode: rule\n\
         profile-name: caly-real-core-judge\n\
         mixed-port: {mixed_port}\n\
         allow-lan: false\n\
         external-controller: 127.0.0.1:{controller_port}\n\
         log-level: info\n\
         geox-url:\n\
         \x20 geoip: \"http://127.0.0.1:1/geoip.metadb\"\n\
         \x20 geosite: \"http://127.0.0.1:1/geosite.dat\"\n\
         \x20 mmdb: \"http://127.0.0.1:1/country.mmdb\"\n\
         \x20 asn: \"http://127.0.0.1:1/GeoLite2-ASN.mmdb\"\n\
         rules:\n\
         \x20 - GEOSITE,category-ads-all,DIRECT\n\
         \x20 - GEOIP,CN,DIRECT\n\
         \x20 - MATCH,DIRECT\n"
    )
}

fn ctx() -> IoContext {
    IoContext::new(
        caly_io::TraceId::new("real-core-judge"),
        caly_io::Actor::System,
    )
}

/// Ask the core's own controller whether it is up — through the `Http` port, which is the
/// same port a future `Probe(ApiReady)` will ride. `200` is the answer; anything else
/// (including a refused connection while booting) is "not yet".
fn controller_answers_200(http: &StdHttp, port: u16) -> bool {
    let request = FetchReq {
        url: format!("http://127.0.0.1:{port}/version"),
        route: caly_io::FetchRoute::Direct,
        // The spawned core's own controller: the RFC-0010 §11.1 explicit management-address
        // exemption, so the conservative default would be wrong here.
        scope: caly_io::FetchScope::AnyPeer,
        etag: None,
        if_modified_since: None,
        max_body_bytes: 65_536,
    };
    matches!(
        block_on_ready(http.fetch(request, &ctx()))
            .expect("ready")
            .map(|resp| resp.status),
        Ok(200)
    )
}

/// The assets are pinned by digest; a missing or drifted file fails **by name**. This is the
/// download-verification gate made real: the day a binary or database is swapped, this judge
/// is the first thing that goes red, and the message says which file and which digest.
#[test]
fn the_committed_core_assets_are_pinned_by_digest() {
    for (relative, pinned) in [
        (MIHOMO_GZ, MIHOMO_GZ_SHA256),
        (GEOIP_METADB, GEOIP_METADB_SHA256),
        (GEOSITE_DAT, GEOSITE_DAT_SHA256),
    ] {
        let path = asset_path(relative);
        let bytes = std::fs::read(&path)
            .unwrap_or_else(|error| panic!("asset {relative} is missing: {error} — a judge that skipped here would be a gate reporting clean while it did not run"));
        assert!(
            !bytes.is_empty(),
            "asset {relative} is present but empty — that is corruption, not absence"
        );
        let digest = sha256_of(&path);
        assert_eq!(
            digest, pinned,
            "asset {relative} drifted: found sha256 {digest}, pinned {pinned}. \
             Re-pin only with the round that deliberately replaces the asset"
        );
    }
}

/// A real core's whole lifecycle through the ports: spawn, "still running" (never a guess),
/// health from the core's own controller via `Http`, stop inside the grace story, and an
/// exit that replays. The port the controller used must come back — a stopped core that
/// still holds its port is a core that was not stopped.
#[test]
fn a_real_core_lives_and_dies_through_the_proc_port() {
    let scratch = scratch_root("lifecycle");
    let root = scratch.path.as_str();
    let binary = materialize_core_binary(root);
    std::fs::copy(asset_path(GEOIP_METADB), format!("{root}/geoip.metadb"))
        .expect("geoip asset copy");
    std::fs::copy(asset_path(GEOSITE_DAT), format!("{root}/geosite.dat"))
        .expect("geosite asset copy");
    let mixed_port = free_port();
    let controller_port = free_port();
    std::fs::write(
        format!("{root}/config.yaml"),
        core_config(mixed_port, controller_port),
    )
    .expect("write the core config");

    let proc = StdProc::new(root);
    // No `cwd` in the spec: the instance dir *is* the gateway root here, and a VPath cannot
    // name "the root itself" (by design — `.` is not a segment). The core is pointed at its
    // working directory by argument instead; the cwd-sandbox rule itself stays judged by
    // `proc_std`'s own cwd test.
    let handle = block_on_ready(proc.spawn(
        SpawnSpec {
            program: binary,
            argv: vec!["-d".to_owned(), root.to_owned()],
            cwd: None,
            env: Vec::new(),
        },
        &ctx(),
    ))
    .expect("ready")
    .expect("the real core spawns");

    // A fresh core is running: None, never a guess and never a fabricated exit.
    assert_eq!(
        block_on_ready(proc.try_wait(&handle))
            .expect("ready")
            .expect("try_wait must not fail"),
        None,
        "a freshly spawned core has not exited"
    );

    // Health from the core's own controller, through the Http port.
    let http = StdHttp::default();
    let deadline = Instant::now() + Duration::from_secs(20);
    loop {
        if controller_answers_200(&http, controller_port) {
            break;
        }
        assert!(
            Instant::now() < deadline,
            "the core never answered its controller on port {controller_port}"
        );
        std::thread::sleep(Duration::from_millis(100));
    }

    // Stop: the grace window passes (this core has no reason to exit by itself), so the
    // port's kill lands — signalled, because a signal chose the number, not the child.
    let exit = block_on_ready(proc.stop(&handle, 1_500))
        .expect("ready")
        .expect("stop must not fail");
    assert!(
        exit.signaled,
        "a core that ignored the grace window dies to the port's kill: {exit:?}"
    );

    // Monotonic once exited: the same exit replays, on both paths.
    assert_eq!(
        block_on_ready(proc.try_wait(&handle))
            .expect("ready")
            .expect("try_wait after stop"),
        Some(exit),
        "try_wait after stop replays the same exit"
    );
    assert_eq!(
        block_on_ready(proc.stop(&handle, 1_500))
            .expect("ready")
            .expect("stop is idempotent"),
        exit,
        "stop after exit replays the same exit"
    );

    // The controller port is back: bindable within a short window, because a stopped core
    // that still holds its port is a core that was not stopped.
    let deadline = Instant::now() + Duration::from_secs(5);
    loop {
        if TcpListener::bind(("127.0.0.1", controller_port)).is_ok() {
            break;
        }
        assert!(
            Instant::now() < deadline,
            "the stopped core still holds controller port {controller_port}"
        );
        std::thread::sleep(Duration::from_millis(100));
    }
    // And the mixed port too, for the same reason, checked the same way.
    let deadline = Instant::now() + Duration::from_secs(5);
    while TcpListener::bind(("127.0.0.1", mixed_port)).is_err() {
        assert!(
            Instant::now() < deadline,
            "the stopped core still holds mixed port {mixed_port}"
        );
        std::thread::sleep(Duration::from_millis(100));
    }
    // The controller really is gone, not just rebindable: a fresh ask is refused.
    assert!(
        !controller_answers_200(&http, controller_port),
        "a stopped core must not answer its controller anymore"
    );
}

/// The geo databases are load-bearing: without them the config's GEOSITE rule makes the core
/// refuse to start, by name, deterministically (its download fallback points at an
/// unreachable address — the sandbox has network, so "it would just download" must be
/// structurally impossible, not merely inconvenient). Two layers: the core's own config
/// check names the missing piece; the port observes the fatal exit.
#[test]
fn the_geo_databases_are_load_bearing_not_decoration() {
    let scratch = scratch_root("geo-load-bearing");
    let root = scratch.path.as_str();
    let binary = materialize_core_binary(root);
    let mixed_port = free_port();
    let controller_port = free_port();
    std::fs::write(
        format!("{root}/config.yaml"),
        core_config(mixed_port, controller_port),
    )
    .expect("write the core config");
    // No geo files copied — that omission is the entire point.

    // Layer 1 — the core's own config check (`-t`), captured: the refusal must name the geo
    // piece it could not initialise, not a generic parse error.
    let check = Command::new(&binary)
        .arg("-t")
        .arg("-d")
        .arg(root)
        .stderr(Stdio::piped())
        .output()
        .expect("run the core's config check");
    assert!(
        !check.status.success(),
        "a config with GEOIP/GEOSITE rules must not validate without the geo databases"
    );
    let said = format!(
        "{}{}",
        String::from_utf8_lossy(&check.stdout),
        String::from_utf8_lossy(&check.stderr)
    );
    assert!(
        said.contains("GeoSite") || said.contains("Geo"),
        "the refusal names the geo piece it could not initialise: {said}"
    );

    // Layer 2 — through the port: spawn the same config, and the core takes itself down.
    let proc = StdProc::new(root);
    let handle = block_on_ready(proc.spawn(
        SpawnSpec {
            program: binary,
            argv: vec!["-d".to_owned(), root.to_owned()],
            cwd: None,
            env: Vec::new(),
        },
        &ctx(),
    ))
    .expect("ready")
    .expect("the core spawns and then refuses its own config");
    let deadline = Instant::now() + Duration::from_secs(20);
    let exit = loop {
        if let Some(exit) = block_on_ready(proc.try_wait(&handle))
            .expect("ready")
            .expect("try_wait must not fail")
        {
            break exit;
        }
        assert!(
            Instant::now() < deadline,
            "the core never exited: a missing geo database must be fatal, not a hang"
        );
        std::thread::sleep(Duration::from_millis(100));
    };
    assert!(
        !exit.signaled && exit.code != 0,
        "a self-refusing core exits by itself with a failure code: {exit:?}"
    );
    // And it never came up: its controller port stays silent.
    let http = StdHttp::default();
    assert!(
        !controller_answers_200(&http, controller_port),
        "a core that refused its config must never answer its controller"
    );
    // Liveness poll used a socket; silence it so the harness leaves no streams behind.
    drop(TcpStream::connect(("127.0.0.1", controller_port)));
}
