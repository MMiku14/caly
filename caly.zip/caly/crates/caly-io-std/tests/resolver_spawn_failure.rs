//! The resolver's spawn-failure path (round 133, `R131-F2`).
//!
//! A dedicated test binary ON PURPOSE: the seam poisons the process-global resolver
//! singleton, so it must never share a process with the happy-path judges in
//! `bounded_resolve.rs` — there, the singleton is live and shared; here, it is broken
//! from the first call.

use std::time::Duration;

/// A resolver whose one thread could not be spawned REFUSES BY NAME instead of panicking
/// through an innocent caller (this used to be the honest-refusal io surface's only panic
/// exit), fails FAST (nothing was spawned), and stays refused (fail-closed-once, no retry
/// churn under exhaustion — remediation is freeing the budget and restarting the process).
#[test]
fn a_resolver_that_cannot_spawn_refuses_by_name_instead_of_panicking() {
    assert!(
        caly_io_std::resolver_spawn_is_broken_for_tests(),
        "the seam must win the singleton race in its own process"
    );

    let fault = caly_io_std::bounded_resolve("localhost", 80, Duration::from_millis(250))
        .expect_err("a broken resolver must refuse, not answer");
    assert!(
        fault.summary.contains("could not be spawned"),
        "the refusal names the spawn failure: {}",
        fault.summary
    );
    assert!(
        !fault.retryable,
        "freeing the budget needs a process restart; the fault must not invite a retry loop"
    );
    assert_eq!(
        caly_io_std::resolver_thread_count(),
        0,
        "nothing was spawned"
    );

    let again = caly_io_std::bounded_resolve("localhost", 80, Duration::from_millis(250));
    assert!(again.is_err(), "the refusal is sticky (fail-closed-once)");
}
