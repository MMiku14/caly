//! The production port adapter must satisfy the same contract as the simulator.
//!
//! `RFC-0006 §15` requires `caly-io-std` and `caly-io-sim` to pass one shared suite. The suite
//! lives in `caly_io::contract` and is run here against real files in a scratch directory.

use std::path::Path;
use std::sync::atomic::{AtomicU64, Ordering};

use caly_io::contract::{
    block_on_ready, clock_contract_violations, fault_kind_vocabulary_is_distinguishable,
    fs_byte_budget_violations, fs_contract_violations, fs_listing_violations, fs_lock_violations,
    fs_mtime_violations, vpath_escape_violations,
};
use caly_io::{Actor, Durability, Fs, IoContext, TraceId, VPath};
use caly_io_std::{StdClock, StdFs};

static SCRATCH_SEQUENCE: AtomicU64 = AtomicU64::new(0);

/// A fresh scratch root per test, so the suite can run in parallel.
fn scratch_root(label: &str) -> String {
    let sequence = SCRATCH_SEQUENCE.fetch_add(1, Ordering::SeqCst);
    let pid = std::process::id();
    let root = std::env::temp_dir().join(format!("caly-io-std-{label}-{pid}-{sequence}"));
    std::fs::create_dir_all(&root).expect("scratch root must be creatable");
    root.to_string_lossy().into_owned()
}

fn ctx() -> IoContext {
    IoContext::new(TraceId::new("io-std-contract"), Actor::System)
}

#[test]
fn vpath_rejects_escaping_paths() {
    assert_eq!(vpath_escape_violations(), Vec::<String>::new());
}

/// `ADR-040`'s sharpest edge lives here, not in the shared suite: only this test knows the
/// host root. `open_stream` used to hand the resolved host path back out in the label — the one
/// thing VPath sandboxing exists to prevent — and the shared contract could not see it, because
/// the simulator has no host root to leak.
#[test]
fn open_stream_label_carries_no_host_path() {
    let root = scratch_root("label");
    let fs = StdFs::new(root.clone());
    let path = VPath::try_from_str("label/probe.txt").expect("static path");
    caly_io::contract::block_on_ready(fs.write_atomic(
        &path,
        b"probe".to_vec(),
        Durability::D2,
        &ctx(),
    ))
    .expect("ready")
    .expect("the probe file must land");
    let stream = caly_io::contract::block_on_ready(fs.open_stream(&path, &ctx()))
        .expect("ready")
        .expect("a present file opens a stream");
    assert_eq!(
        stream.label, "label/probe.txt",
        "the label is the caller's own path"
    );
    assert!(
        !stream.label.contains(&root),
        "the host root must not ride back out of the sandbox: {:?}",
        stream.label
    );
}

#[test]
fn fs_port_contract_passes_against_real_files() {
    let root = scratch_root("fs");
    let fs = StdFs::new(root.clone());
    let violations = fs_contract_violations(&fs, &ctx());
    assert_eq!(
        violations,
        Vec::<String>::new(),
        "std Fs contract: {violations:?}"
    );
    let _ = std::fs::remove_dir_all(&root);
}

#[test]
fn listing_contract_passes_against_real_files() {
    let root = scratch_root("listing");
    let fs = StdFs::new(root.clone());
    let violations = fs_listing_violations(&fs, &ctx());
    assert_eq!(
        violations,
        Vec::<String>::new(),
        "std Fs listing contract: {violations:?}"
    );
    let _ = std::fs::remove_dir_all(&root);
}

/// `RFC-0006 §5.3` is a MUST on the port, so it is checked here and not only in the simulator:
/// a budget the release gate honours and the real disk ignores is a budget nobody can rely on.
#[test]
fn byte_budget_contract_passes_against_real_files() {
    let root = scratch_root("byte-budget");
    let fs = StdFs::new(root.clone());
    let violations = fs_byte_budget_violations(&fs, &ctx());
    assert_eq!(
        violations,
        Vec::<String>::new(),
        "std Fs byte-budget contract: {violations:?}"
    );
    let _ = std::fs::remove_dir_all(&root);
}

#[test]
fn mtime_contract_passes_against_real_files() {
    let root = scratch_root("mtime");
    let fs = StdFs::new(root.clone());
    let violations = fs_mtime_violations(&fs, &ctx());
    assert_eq!(
        violations,
        Vec::<String>::new(),
        "std Fs mtime contract: {violations:?}"
    );

    // The real port is the case where the value is *known*, so `Some` is part of its contract too —
    // otherwise a `StdFs` that dropped the field would still satisfy the permissive shared check.
    let path = VPath::try_from_str("mtimes/first").expect("static path");
    let meta = block_on_ready(fs.stat(&path, &ctx()))
        .expect("ready")
        .expect("stat")
        .expect("the contract wrote this file");
    assert!(
        meta.modified_at_unix_ms.unwrap_or(0) > 0,
        "a real filesystem knows when it was written: {meta:?}"
    );
    let _ = std::fs::remove_dir_all(&root);
}

/// `list` answers about a directory, and only about one. Pointing it at a file is its own error
/// (`InvalidInput`), and the type-level guard that makes an escaping path unrepresentable is still the
/// first line of defence — both layers keep refusing, so a `VPath` bug cannot become a read outside
/// the root (see `docs/history/ONBOARDING_NOTES.md §4.9` for why the duplication is deliberate).
#[test]
fn listing_a_file_is_not_the_same_as_listing_nothing() {
    let root = scratch_root("listing-notdir");
    let fs = StdFs::new(root.clone());
    let path = VPath::try_from_str("plain").expect("static path");
    block_on_ready(fs.write_atomic(&path, b"content".to_vec(), Durability::D1, &ctx()))
        .expect("ready")
        .expect("write");

    let error = block_on_ready(fs.list(&path, caly_io::ListCap(8), &ctx()))
        .expect("ready")
        .expect_err("a file has no children to list");
    assert_eq!(error.kind, caly_io::IoFaultKind::InvalidInput, "{error:?}");
    assert!(
        !error.summary.contains(&root),
        "a port fault must not leak the host's absolute layout: {error:?}"
    );

    // …and the escape never reaches the port at all.
    let error = VPath::try_from_str("../etc").expect_err("VPath must refuse this");
    assert!(error.message.contains("invalid path segment"), "{error:?}");
    let _ = std::fs::remove_dir_all(&root);
}

/// The root is a sandbox: content must land under it and nowhere else.
#[test]
fn the_root_actually_contains_the_writes() {
    let root = scratch_root("rooted");
    let fs = StdFs::new(root.clone());
    let path = VPath::try_from_str("objects/ab/cd/deadbeef").expect("relative path");
    block_on_ready(fs.write_atomic(&path, b"cas-object".to_vec(), Durability::D2, &ctx()))
        .expect("ready")
        .expect("write");

    assert!(Path::new(&root).join("objects/ab/cd/deadbeef").is_file());
    assert!(
        !Path::new(&root).join("../escaped").exists(),
        "nothing may be written outside the root"
    );
    let _ = std::fs::remove_dir_all(&root);
}

/// A rejected path must be reported as `InvalidInput`, not silently rewritten.
#[test]
fn a_traversal_attempt_is_a_typed_error() {
    let root = scratch_root("traversal");
    let fs = StdFs::new(root.clone());
    // VPath itself refuses `..`; the Fs layer must still refuse a smuggled segment rather than
    // resolve it, so the two guards are independent.
    let error = block_on_ready(fs.read(
        &VPath::try_from_str("ok").expect("path"),
        caly_io::ByteCap(8),
        &ctx(),
    ))
    .expect("ready")
    .expect_err("absent file");
    assert_eq!(error.kind, caly_io::IoFaultKind::NotFound);
    let _ = std::fs::remove_dir_all(&root);
}

#[test]
fn exclusive_lock_contract_passes() {
    let root = scratch_root("lock");
    let fs = StdFs::new(root.clone());
    let violations = fs_lock_violations(&fs, &ctx());
    assert_eq!(
        violations,
        Vec::<String>::new(),
        "std locking: {violations:?}"
    );
    let _ = std::fs::remove_dir_all(&root);
}

#[test]
fn clock_contract_passes() {
    let violations = clock_contract_violations(&StdClock::new());
    assert_eq!(
        violations,
        Vec::<String>::new(),
        "std clock: {violations:?}"
    );
}

#[test]
fn fault_vocabulary_contract_passes() {
    assert_eq!(
        fault_kind_vocabulary_is_distinguishable(),
        Vec::<String>::new()
    );
}

/// Durability must be more than an accepted argument: no temp file may outlive the call at any
/// tier, otherwise a crash leaves debris that `GC` and `doctor` would have to reason about.
#[test]
fn write_atomic_leaves_no_temporary_debris() {
    let root = scratch_root("temp");
    let fs = StdFs::new(root.clone());
    let path = VPath::try_from_str("durable/config.yaml").expect("relative path");
    let context = ctx();
    for durability in [
        Durability::D0,
        Durability::D1,
        Durability::D2,
        Durability::D3,
    ] {
        block_on_ready(fs.write_atomic(&path, b"payload".to_vec(), durability, &context))
            .expect("ready")
            .expect("write must succeed");
    }

    let entries: Vec<String> = std::fs::read_dir(Path::new(&root).join("durable"))
        .expect("dir")
        .flatten()
        .map(|entry| entry.file_name().to_string_lossy().into_owned())
        .collect();
    assert_eq!(
        entries.iter().filter(|name| name.contains(".tmp-")).count(),
        0,
        "temp files must not survive a completed write: {entries:?}"
    );
    assert!(entries.contains(&"config.yaml".to_owned()), "{entries:?}");
    let _ = std::fs::remove_dir_all(&root);
}
