//! Round 59 (`ADR-047 §2`): the `FetchRoute` column is honoured, not ignored.
//!
//! `StdHttp` used to read only `url` and dial it directly whatever the route said — an
//! `ActiveCore` fetch silently went direct, which is a lie in the shape of a connection.
//! These judges hold the three-column truth against a scripted local peer:
//!
//! * `ActiveCore` sends an **absolute-form** proxy request to the address in the shared
//!   route source (the live core's mixed inbound in production, a stub here that records
//!   the request line it saw);
//! * `ActiveCore` with no live core fails **by name** ("no live core"), and an adapter
//!   with no route source wired at all says that instead;
//! * `SystemProxy` rides the same absolute-form machinery at the composed proxy address
//!   (round 60, `ADR-048`), and with no proxy composed it is refused by name rather than
//!   silently going direct;
//! * the environment half of proxy resolution is a pure function: one value, one address
//!   or None — no port, no address.

use std::io::{Read, Write};
use std::net::TcpListener;
use std::sync::{Arc, Mutex};

use caly_io::{block_on_ready, FetchReq, FetchRoute, Http, IoContext};
use caly_io_std::{CoreRouteSource, StdHttp};

fn ctx() -> IoContext {
    IoContext::new(
        caly_io::TraceId::new("http-route-judge"),
        caly_io::Actor::System,
    )
}

fn fetch(http: &StdHttp, url: &str, route: FetchRoute) -> Result<u16, String> {
    let request = FetchReq {
        url: url.to_owned(),
        route,
        etag: None,
        if_modified_since: None,
        max_body_bytes: 64 * 1024,
    };
    match block_on_ready(http.fetch(request, &ctx())) {
        Ok(Ok(resp)) => Ok(resp.status),
        Ok(Err(fault)) => Err(fault.summary),
        Err(not_ready) => Err(not_ready),
    }
}

/// A one-shot stand-in for a core's mixed inbound: accepts one connection, records the
/// request line, answers 200 with a two-byte body.
fn stub_mixed_inbound() -> (std::net::SocketAddr, Arc<Mutex<Option<String>>>) {
    let listener = TcpListener::bind("127.0.0.1:0").expect("bind stub mixed inbound");
    let address = listener.local_addr().expect("local addr");
    let seen = Arc::new(Mutex::new(None));
    let seen_handle = Arc::clone(&seen);
    std::thread::spawn(move || {
        if let Ok((mut stream, _)) = listener.accept() {
            let mut buffer = Vec::new();
            let mut chunk = [0u8; 1024];
            loop {
                match stream.read(&mut chunk) {
                    Ok(0) => break,
                    Ok(n) => {
                        buffer.extend_from_slice(&chunk[..n]);
                        if buffer.windows(4).any(|w| w == b"\r\n\r\n") {
                            break;
                        }
                    }
                    Err(_) => break,
                }
            }
            let head = String::from_utf8_lossy(&buffer).into_owned();
            if let Some(line) = head.lines().next() {
                *seen_handle.lock().expect("seen lock") = Some(line.to_owned());
            }
            let response = "HTTP/1.1 200 OK\r\nContent-Length: 2\r\nConnection: close\r\n\r\nok";
            let _ = stream.write_all(response.as_bytes());
            let _ = stream.flush();
        }
    });
    (address, seen)
}

#[test]
fn active_core_sends_an_absolute_form_proxy_request() {
    let (address, seen) = stub_mixed_inbound();
    let route: CoreRouteSource = Arc::new(Mutex::new(Some(address)));
    let http = StdHttp::with_core_route(Arc::clone(&route));

    // A hostname that does not resolve: if the adapter went DIRECT despite the route,
    // the fetch fails on resolve — the stub is the only way this returns 200.
    let status = fetch(
        &http,
        "http://canary-host-that-does-not-resolve.test/path?q=1",
        FetchRoute::ActiveCore,
    )
    .expect("the stub mixed inbound answers the proxied fetch");

    assert_eq!(status, 200, "through the stub core the fetch succeeds");
    let request_line = seen
        .lock()
        .expect("seen lock")
        .clone()
        .expect("the stub saw a request");
    assert!(
        request_line.starts_with(
            "GET http://canary-host-that-does-not-resolve.test:80/path?q=1 HTTP/1.1"
        ),
        "a proxy request carries the ABSOLUTE form, not the origin form: {request_line}"
    );
}

#[test]
fn active_core_without_a_live_core_fails_by_name() {
    let route: CoreRouteSource = Arc::new(Mutex::new(None));
    let http = StdHttp::with_core_route(route);
    let fault = fetch(&http, "http://example.test/x", FetchRoute::ActiveCore)
        .expect_err("no live core means no proxy path");
    assert!(
        fault.contains("no live core"),
        "the refusal must name what is missing: {fault}"
    );
}

#[test]
fn active_core_without_a_route_source_says_so() {
    let http = StdHttp::default();
    let fault = fetch(&http, "http://example.test/x", FetchRoute::ActiveCore)
        .expect_err("no wired route source means no proxy path");
    assert!(
        fault.contains("no core route source"),
        "the refusal must name the wiring, not pretend: {fault}"
    );
}

#[test]
fn system_proxy_rides_absolute_form_to_the_composed_proxy() {
    let (address, seen) = stub_mixed_inbound();
    let http = StdHttp::default().with_system_proxy(address);

    let status = fetch(
        &http,
        "http://canary-host-that-does-not-resolve.test/proxied?q=1",
        FetchRoute::SystemProxy,
    )
    .expect("the stub proxy answers");
    assert_eq!(status, 200);
    let request_line = seen
        .lock()
        .expect("seen lock")
        .clone()
        .expect("the stub saw a request");
    assert!(
        request_line.starts_with(
            "GET http://canary-host-that-does-not-resolve.test:80/proxied?q=1 HTTP/1.1"
        ),
        "the system-proxy request carries the ABSOLUTE form: {request_line}"
    );
}

#[test]
fn system_proxy_without_one_composed_fails_by_name() {
    let http = StdHttp::default();
    let fault = fetch(&http, "http://example.test/x", FetchRoute::SystemProxy)
        .expect_err("no proxy composed means no proxy path");
    assert!(
        fault.contains("no system proxy is configured"),
        "the refusal must name what is missing: {fault}"
    );
}

#[test]
fn proxy_values_parse_purely() {
    use std::str::FromStr;
    let ok = StdHttp::parse_proxy_value("http://127.0.0.1:8888")
        .expect("scheme + host:port parses");
    assert_eq!(
        ok,
        std::net::SocketAddr::from_str("127.0.0.1:8888").unwrap()
    );
    assert!(StdHttp::parse_proxy_value("127.0.0.1:8888").is_some());
    assert!(
        StdHttp::parse_proxy_value("proxy.internal:8888").is_none(),
        "a name needing resolution is not a dialable address; guessing is not parsing"
    );
    assert!(
        StdHttp::parse_proxy_value("127.0.0.1").is_none(),
        "a portless proxy value is not an address this adapter can dial"
    );
}
