//! The production `Http` port: plain HTTP/1.1 over `std::net`, no external crates.
//!
//! `RFC-0006 §15` requires `caly-io-std` and `caly-io-sim` to answer one shared contract; until
//! this module the `Http` side of that requirement had one implementation only, so the "single
//! IO gateway" of `ADR-011` had no production HTTP side at all.
//!
//! What this adapter is, honestly:
//!
//! * `http://` only. `https://` is refused with `Unsupported` naming why: TLS needs a client the
//!   no-external-crate doctrine (`RFC-0001 §1.4`) cannot provide, and pretending otherwise —
//!   silently downgrading, or failing mid-handshake with a socket error — would be a lie in the
//!   shape of a connection attempt.
//! * Blocking `std::net` inside the port's `BoxFuture`, exactly as `StdFs` does blocking
//!   `std::fs` inside its own: the port family's execution model is the caller's `run_ready`,
//!   not an async runtime (`ADR-036`).
//! * The caller's byte budget and the request's own `max_body_bytes` are both ceilings on the
//!   **transfer**, not on a buffered body: the adapter stops at the tighter bound plus one byte
//!   and refuses having read no more than that, so a hostile body cannot spend unbounded memory
//!   before the refusal (`RFC-0006 §15.3`, the same rule the simulator answers).
//! * The response label is `http:{request url}` (`ADR-040`): the caller's own name for the
//!   resource, pinned by the shared contract on both backends.
//! * `FetchRoute` is honoured, not ignored (round 59, `ADR-047`, round 60 `ADR-048`):
//!   `Direct` is this adapter's own socket; `ActiveCore` is an absolute-form proxy request
//!   through the live core's mixed inbound, resolved from a shared route source the effect
//!   runtime updates on spawn/stop; `SystemProxy` is the same absolute-form machinery aimed
//!   at the proxy the environment names (`http_proxy`/`all_proxy`, resolved once at the
//!   composition root — a fetch must not re-read the process environment mid-flight). A
//!   route that asks for a proxy and finds none configured is refused by name; silently
//!   going direct is the lie this port refuses to tell.
//! * Conditional requests (`etag` / `if_modified_since`) are sent and a `304` answer is
//!   returned as-is: the caller asked "changed since?", and `304` **is** the answer "no".

use std::io::{BufRead, BufReader, Read, Write};
use std::net::{SocketAddr, TcpStream, ToSocketAddrs};
use std::sync::{Arc, Mutex};
use std::time::Duration;

use caly_io::{
    BoxFuture, ByteStream, FetchReq, FetchResp, FetchRoute, Http, IoContext, IoFault, IoFaultKind,
};

const CONNECT_TIMEOUT: Duration = Duration::from_secs(5);
const IO_TIMEOUT: Duration = Duration::from_secs(10);
const USER_AGENT: &str = concat!("caly-io-std/", env!("CARGO_PKG_VERSION"));

/// Where the `ActiveCore` route asks for the live core's mixed inbound. Shared so the effect
/// runtime can update it when a core spawns or stops and every holder sees the same truth
/// (`ADR-047 §2`): one source, no second bookkeeping to drift.
pub type CoreRouteSource = Arc<Mutex<Option<SocketAddr>>>;

/// An `Http` port over blocking `std::net`, speaking plain HTTP/1.1 with `Connection: close`.
///
/// Timeouts are fixed and deliberately boring (5 s connect, 10 s per read/write); making them
/// configurable is a decision for the first caller that needs it, not a knob added in advance.
#[derive(Clone, Debug, Default)]
pub struct StdHttp {
    core_route: Option<CoreRouteSource>,
    system_proxy: Option<std::net::SocketAddr>,
}

impl StdHttp {
    /// Wire the live-core route source in (`ADR-047 §2`): without it, an `ActiveCore` fetch
    /// is refused by name rather than silently going direct.
    pub fn with_core_route(core_route: CoreRouteSource) -> Self {
        Self {
            core_route: Some(core_route),
            system_proxy: None,
        }
    }

    /// Aim the `SystemProxy` route at a concrete address (`ADR-048 §2`). Composition roots
    /// resolve the environment ONCE and hand the answer in; fetches never re-read env.
    pub fn with_system_proxy(mut self, proxy: std::net::SocketAddr) -> Self {
        self.system_proxy = Some(proxy);
        self
    }

    /// Resolve a system proxy address from the process environment (`http_proxy` then
    /// `all_proxy`, lower-case only — the conventional keys). The composition root calls
    /// this once; fetches never re-read the environment mid-flight.
    pub fn system_proxy_from_env() -> Option<std::net::SocketAddr> {
        for key in ["http_proxy", "all_proxy"] {
            if let Ok(value) = std::env::var(key) {
                if let Some(address) = Self::parse_proxy_value(&value) {
                    return Some(address);
                }
            }
        }
        None
    }

    /// The pure half of environment resolution: one proxy value -> one address, or None.
    /// `scheme://` prefixes are tolerated, `host:port` is the shape; a value that names no
    /// port is None, because a portless proxy address is not an address this adapter can
    /// dial — guessing a port would be the same lie as going direct.
    pub fn parse_proxy_value(value: &str) -> Option<std::net::SocketAddr> {
        value
            .trim()
            .trim_start_matches("http://")
            .trim_start_matches("https://")
            .parse::<std::net::SocketAddr>()
            .ok()
    }
}

impl StdHttp {
    fn fault(kind: IoFaultKind, summary: impl Into<String>) -> IoFault {
        IoFault::new(kind, summary.into())
    }

    fn poisoned(what: &str) -> IoFault {
        IoFault::new(
            IoFaultKind::InternalIo,
            format!("the {what} lock is poisoned; the sharing thread panicked"),
        )
    }
}

/// The pieces of a URL this adapter needs; anything it cannot honor is refused up front.
struct ParsedUrl {
    host: String,
    port: u16,
    path_with_query: String,
}

fn parse_url(url: &str) -> Result<ParsedUrl, IoFault> {
    let rest = if let Some(rest) = url.strip_prefix("http://") {
        rest
    } else if url.starts_with("https://") {
        return Err(IoFault::new(
            IoFaultKind::Unsupported,
            format!(
                "https is not implemented: TLS needs a client the no-external-crate doctrine \
                 (RFC-0001 §1.4) cannot provide, and refusing is the honest answer: {url}"
            ),
        ));
    } else {
        return Err(IoFault::new(
            IoFaultKind::InvalidInput,
            format!("fetch url must be http://, got: {url}"),
        ));
    };
    let (authority, path_with_query) = match rest.find('/') {
        Some(at) => (&rest[..at], &rest[at..]),
        None => (rest, "/"),
    };
    // Reject userinfo: it is a credential smuggled in a URL, and this adapter has no vault.
    if authority.contains('@') {
        return Err(IoFault::new(
            IoFaultKind::InvalidInput,
            format!("fetch url must not carry credentials: {url}"),
        ));
    }
    let (host, port) = match authority.rsplit_once(':') {
        Some((host, port)) => (
            host.to_owned(),
            port.parse::<u16>().map_err(|_| {
                IoFault::new(
                    IoFaultKind::InvalidInput,
                    format!("fetch url port is not a port number: {url}"),
                )
            })?,
        ),
        None => (authority.to_owned(), 80),
    };
    Ok(ParsedUrl {
        host,
        port,
        path_with_query: path_with_query.to_owned(),
    })
}

/// A response's status line and headers, minimally parsed; the body is consumed by the caller's
/// budget rules rather than handed back (`FetchResp` carries a handle label, not bytes).
struct Head {
    status: u16,
    etag: Option<String>,
    last_modified: Option<String>,
    content_length: Option<u64>,
    chunked: bool,
}

fn header_value(line: &str) -> Option<&str> {
    line.split_once(':').map(|(_, value)| value.trim())
}

impl StdHttp {
    fn read_head(reader: &mut BufReader<TcpStream>) -> Result<Head, IoFault> {
        let mut status_line = String::new();
        reader.read_line(&mut status_line).map_err(|error| {
            Self::fault(IoFaultKind::Timeout, format!("read status line: {error}"))
        })?;
        let status = status_line
            .split_whitespace()
            .nth(1)
            .and_then(|code| code.parse::<u16>().ok())
            .ok_or_else(|| {
                Self::fault(
                    IoFaultKind::InternalIo,
                    format!("malformed HTTP status line: {:?}", status_line.trim()),
                )
            })?;
        let mut head = Head {
            status,
            etag: None,
            last_modified: None,
            content_length: None,
            chunked: false,
        };
        loop {
            let mut line = String::new();
            reader.read_line(&mut line).map_err(|error| {
                Self::fault(IoFaultKind::Timeout, format!("read header: {error}"))
            })?;
            let trimmed = line.trim_end();
            if trimmed.is_empty() {
                break;
            }
            let lower = trimmed.to_ascii_lowercase();
            if lower.starts_with("etag:") {
                head.etag = header_value(trimmed).map(str::to_owned);
            } else if lower.starts_with("last-modified:") {
                head.last_modified = header_value(trimmed).map(str::to_owned);
            } else if lower.starts_with("content-length:") {
                head.content_length = header_value(trimmed).and_then(|v| v.parse().ok());
            } else if lower.starts_with("transfer-encoding:") {
                head.chunked = trimmed.to_ascii_lowercase().contains("chunked");
            }
        }
        Ok(head)
    }

    /// Consume the body under the ceiling, returning how large it is (or at least how large it
    /// already proved itself to be, for an unannounced and over-bound body). Never buffers more
    /// than the ceiling plus one byte: a hostile body cannot spend unbounded memory before the
    /// refusal, and a declared body larger than the ceiling is not transferred at all.
    fn consume_body(
        reader: &mut BufReader<TcpStream>,
        head: &Head,
        ceiling: u64,
    ) -> Result<u64, IoFault> {
        let skip = |reader: &mut BufReader<TcpStream>, mut left: u64| -> Result<(), IoFault> {
            let mut sink = [0u8; 4096];
            while left > 0 {
                let take = left.min(sink.len() as u64) as usize;
                reader.read_exact(&mut sink[..take]).map_err(|error| {
                    Self::fault(IoFaultKind::Timeout, format!("read body: {error}"))
                })?;
                left -= take as u64;
            }
            Ok(())
        };
        if head.chunked {
            let mut seen: u64 = 0;
            loop {
                let mut size_line = String::new();
                reader.read_line(&mut size_line).map_err(|error| {
                    Self::fault(IoFaultKind::Timeout, format!("read chunk size: {error}"))
                })?;
                let size = u64::from_str_radix(size_line.trim(), 16).map_err(|_| {
                    Self::fault(
                        IoFaultKind::InternalIo,
                        format!("malformed chunk size line: {:?}", size_line.trim()),
                    )
                })?;
                if size == 0 {
                    return Ok(seen);
                }
                seen = seen.saturating_add(size);
                if seen > ceiling {
                    // The refusal reports the size the server has already declared; the rest of
                    // the transfer is not worth a timeout to witness.
                    return Ok(seen);
                }
                skip(reader, size)?;
                let mut crlf = [0u8; 2];
                let _ = reader.read_exact(&mut crlf);
            }
        }
        if let Some(total) = head.content_length {
            if total > ceiling {
                return Ok(total);
            }
            skip(reader, total)?;
            return Ok(total);
        }
        // Identity to EOF (`Connection: close`): the ceiling bounds the loop, one byte past it
        // is the refusal, and that extra byte is what makes the reported size truthful.
        let mut seen: u64 = 0;
        let mut one_byte = [0u8; 1];
        loop {
            match reader.read(&mut one_byte) {
                Ok(0) => return Ok(seen),
                Ok(_) => {
                    seen += 1;
                    if seen > ceiling {
                        return Ok(seen);
                    }
                }
                Err(error) => {
                    return Err(Self::fault(
                        IoFaultKind::Timeout,
                        format!("read body: {error}"),
                    ))
                }
            }
        }
    }
}

impl Http for StdHttp {
    fn fetch<'a>(
        &'a self,
        req: FetchReq,
        ctx: &'a IoContext,
    ) -> BoxFuture<'a, Result<FetchResp, IoFault>> {
        Box::pin(async move {
            let url = req.url.clone();
            let parsed = parse_url(&url)?;

            // The route decides WHERE the request is sent and in WHICH form (`ADR-047 §2`):
            // Direct resolves and sends origin-form; ActiveCore sends absolute-form to the
            // live core's mixed inbound; SystemProxy is an honest refusal until a proxy
            // resolution face exists.
            let (address, absolute_form) = match req.route {
                FetchRoute::Direct => {
                    let address: SocketAddr = (parsed.host.as_str(), parsed.port)
                        .to_socket_addrs()
                        .map_err(|error| {
                            Self::fault(
                                IoFaultKind::Unavailable,
                                format!("resolve {}: {error}", parsed.host),
                            )
                        })?
                        .next()
                        .ok_or_else(|| {
                            Self::fault(
                                IoFaultKind::Unavailable,
                                format!("resolve {}: no address", parsed.host),
                            )
                        })?;
                    (address, false)
                }
                FetchRoute::ActiveCore => {
                    let source = self.core_route.as_ref().ok_or_else(|| {
                        Self::fault(
                            IoFaultKind::Unavailable,
                            "the ActiveCore route has no core route source wired on this \
                             adapter — refusing rather than silently going direct (ADR-047 §2)",
                        )
                    })?;
                    let guarded = source
                        .lock()
                        .map_err(|_| Self::poisoned("core route source"))?;
                    let address = guarded.ok_or_else(|| {
                        Self::fault(
                            IoFaultKind::Unavailable,
                            "no live core to route through: the ActiveCore route needs a \
                             spawned core (ADR-047 §2)",
                        )
                    })?;
                    (address, true)
                }
                FetchRoute::SystemProxy => {
                    let address = self.system_proxy.ok_or_else(|| {
                        Self::fault(
                            IoFaultKind::Unavailable,
                            "no system proxy is configured on this adapter \
                             (http_proxy/all_proxy unset or unparseable at composition) — \
                             refusing by name rather than silently going direct (ADR-048 §2)",
                        )
                    })?;
                    (address, true)
                }
            };
            let mut stream =
                TcpStream::connect_timeout(&address, CONNECT_TIMEOUT).map_err(|error| {
                    let kind = if error.kind() == std::io::ErrorKind::TimedOut {
                        IoFaultKind::Timeout
                    } else {
                        IoFaultKind::Unavailable
                    };
                    Self::fault(kind, format!("connect {address}: {error}"))
                })?;
            stream.set_read_timeout(Some(IO_TIMEOUT)).map_err(|error| {
                Self::fault(
                    IoFaultKind::InternalIo,
                    format!("set read timeout: {error}"),
                )
            })?;
            stream
                .set_write_timeout(Some(IO_TIMEOUT))
                .map_err(|error| {
                    Self::fault(
                        IoFaultKind::InternalIo,
                        format!("set write timeout: {error}"),
                    )
                })?;

            // A proxy request carries the absolute form (`GET http://host:port/path`); the
            // origin form is only meaningful on a direct socket.
            let request_target = if absolute_form {
                format!("http://{}:{}{}", parsed.host, parsed.port, parsed.path_with_query)
            } else {
                parsed.path_with_query.clone()
            };
            let mut request = format!(
                "GET {} HTTP/1.1\r\nHost: {}\r\nUser-Agent: {USER_AGENT}\r\nAccept: */*\r\nConnection: close\r\n",
                request_target, parsed.host
            );
            if let Some(etag) = &req.etag {
                request.push_str(&format!("If-None-Match: {etag}\r\n"));
            }
            if let Some(since) = &req.if_modified_since {
                request.push_str(&format!("If-Modified-Since: {since}\r\n"));
            }
            request.push_str("\r\n");
            stream.write_all(request.as_bytes()).map_err(|error| {
                Self::fault(IoFaultKind::Timeout, format!("write request: {error}"))
            })?;
            stream.flush().map_err(|error| {
                Self::fault(IoFaultKind::Timeout, format!("flush request: {error}"))
            })?;

            let mut reader = BufReader::new(stream);
            let head = Self::read_head(&mut reader)?;

            // The caller's budget and the request's own bound are both ceilings on the transfer
            // (`RFC-0006 §15.3`): the tighter one bites, and the refusal says which.
            let ceiling = caly_io::byte_ceiling(ctx, req.max_body_bytes);
            let size = Self::consume_body(&mut reader, &head, ceiling.bytes)?;
            if let Some(too_big) = ceiling.violation(size, &url) {
                return Err(too_big);
            }

            Ok(FetchResp {
                status: head.status,
                etag: head.etag,
                last_modified: head.last_modified,
                body: ByteStream {
                    // `ADR-040`: the prefix names the port ("this came from Http"), not a scheme.
                    label: format!("http:{url}"),
                },
            })
        })
    }
}
