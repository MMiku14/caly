//! The production `Http` port: plain HTTP/1.1 over `std::net`, no external crates.
//!
//! `RFC-0006 §15` requires `caly-io-std` and `caly-io-sim` to answer one shared contract; until
//! this module the `Http` side of that requirement had one implementation only, so the "single
//! IO gateway" of `ADR-011` had no production HTTP side at all.
//!
//! What this adapter is, honestly:
//!
//! * `http://` only. `https://` is refused with `Unsupported` naming why: TLS needs a client the
//!   no-external-crate doctrine (`RFC-0001 §1.4`) cannot provide, and pretending otherwise —
//!   silently downgrading, or failing mid-handshake with a socket error — would be a lie in the
//!   shape of a connection attempt.
//! * Blocking `std::net` inside the port's `BoxFuture`, exactly as `StdFs` does blocking
//!   `std::fs` inside its own: the port family's execution model is the caller's `run_ready`,
//!   not an async runtime (`ADR-036`).
//! * The caller's byte budget and the request's own `max_body_bytes` are both ceilings on the
//!   **transfer**, not on a buffered body: the adapter stops at the tighter bound plus one byte
//!   and refuses having read no more than that, so a hostile body cannot spend unbounded memory
//!   before the refusal (`RFC-0006 §15.3`, the same rule the simulator answers).
//! * The response label is `http:{request url}` (`ADR-040`): the caller's own name for the
//!   resource, pinned by the shared contract on both backends.
//! * `FetchRoute` is honoured, not ignored (round 59, `ADR-047`, round 60 `ADR-048`):
//!   `Direct` is this adapter's own socket; `ActiveCore` is an absolute-form proxy request
//!   through the live core's mixed inbound, resolved from a shared route source the effect
//!   runtime updates on spawn/stop; `SystemProxy` is the same absolute-form machinery aimed
//!   at the proxy the environment names (`http_proxy`/`all_proxy`, resolved once at the
//!   composition root — a fetch must not re-read the process environment mid-flight). A
//!   route that asks for a proxy and finds none configured is refused by name; silently
//!   going direct is the lie this port refuses to tell.
//! * Conditional requests (`etag` / `if_modified_since`) are sent and a `304` answer is
//!   returned as-is: the caller asked "changed since?", and `304` **is** the answer "no".

use std::fmt;
use std::io::{BufRead, BufReader, Read, Write};
use std::net::{SocketAddr, TcpStream, ToSocketAddrs};
use std::sync::{Arc, Mutex};
use std::time::Duration;

use caly_io::{
    caller_deadline_mono_ms, check_caller_control, BoxFuture, Clock, FetchBody, FetchReq,
    FetchResp, FetchRoute, FetchScope, Http, IoContext, IoFault, IoFaultKind,
};

const CONNECT_TIMEOUT: Duration = Duration::from_secs(5);
const IO_TIMEOUT: Duration = Duration::from_secs(10);
const USER_AGENT: &str = concat!("caly-io-std/", env!("CARGO_PKG_VERSION"));

/// Where the `ActiveCore` route asks for the live core's mixed inbound. Shared so the effect
/// runtime can update it when a core spawns or stops and every holder sees the same truth
/// (`ADR-047 §2`): one source, no second bookkeeping to drift.
pub type CoreRouteSource = Arc<Mutex<Option<SocketAddr>>>;

/// The partition `RFC-0010 §11.1` draws: the three sensitive families a control plane must
/// not be turned into a probe of, and everything else. This is the classification applied to
/// the **peer the connection actually reached** (after connect, not before resolve — that is
/// what makes a DNS-rebinding attempt answer to the same rule as an honest lookup).
#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub enum PeerClass {
    /// 127.0.0.0/8 and `::1`.
    Loopback,
    /// 169.254.0.0/16 (link-local, including the cloud-metadata address 169.254.169.254)
    /// and `fe80::/10`.
    LinkLocalOrMetadata,
    /// RFC-1918 IPv4 (10/8, 172.16/12, 192.168/16), the CGNAT shared space (100.64/10) and
    /// IPv6 ULA (`fc00::/7`).
    Private,
    /// Everything else.
    Public,
}

/// Classify a socket address into the `RFC-0010 §11.1` partition.
pub fn classify_peer_address(peer: &SocketAddr) -> PeerClass {
    use std::net::IpAddr;
    match peer.ip() {
        IpAddr::V4(ip) => {
            let octets = ip.octets();
            if octets[0] == 127 {
                PeerClass::Loopback
            } else if octets[0] == 169 && octets[1] == 254 {
                PeerClass::LinkLocalOrMetadata
            } else if octets[0] == 10
                || (octets[0] == 172 && (16..=31).contains(&octets[1]))
                || (octets[0] == 192 && octets[1] == 168)
                || (octets[0] == 100 && (64..=127).contains(&octets[1]))
            {
                PeerClass::Private
            } else {
                PeerClass::Public
            }
        }
        IpAddr::V6(ip) => {
            let segments = ip.segments();
            if ip.is_loopback() {
                PeerClass::Loopback
            } else if (segments[0] & 0xffc0) == 0xfe80 {
                // fe80::/10 — link-local.
                PeerClass::LinkLocalOrMetadata
            } else if (segments[0] & 0xfe00) == 0xfc00 {
                // fc00::/7 — unique local.
                PeerClass::Private
            } else {
                PeerClass::Public
            }
        }
    }
}

/// The `FetchScope` gate over one connected peer: `AnyPeer` admits everything,
/// `Default` admits only `Public`.
pub fn peer_allowed_in_scope(peer: &SocketAddr, scope: FetchScope) -> bool {
    match scope {
        FetchScope::AnyPeer => true,
        FetchScope::Default => classify_peer_address(peer) == PeerClass::Public,
    }
}

/// An `Http` port over blocking `std::net`, speaking plain HTTP/1.1 with `Connection: close`.
///
/// Timeouts are fixed and deliberately boring (5 s connect, 10 s per read/write); making them
/// configurable is a decision for the first caller that needs it, not a knob added in advance.
#[derive(Clone, Default)]
pub struct StdHttp {
    core_route: Option<CoreRouteSource>,
    system_proxy: Option<std::net::SocketAddr>,
    /// The composition root's monotonic clock. `None` is deliberate: a direct caller that has not
    /// supplied a comparable clock must not get a guessed deadline answer.
    clock: Option<Arc<dyn Clock>>,
}

impl fmt::Debug for StdHttp {
    fn fmt(&self, formatter: &mut fmt::Formatter<'_>) -> fmt::Result {
        formatter
            .debug_struct("StdHttp")
            .field("core_route", &self.core_route.is_some())
            .field("system_proxy", &self.system_proxy)
            .field("clock", &self.clock.is_some())
            .finish()
    }
}

impl StdHttp {
    /// Wire the live-core route source in (`ADR-047 §2`): without it, an `ActiveCore` fetch
    /// is refused by name rather than silently going direct.
    pub fn with_core_route(core_route: CoreRouteSource) -> Self {
        Self {
            core_route: Some(core_route),
            system_proxy: None,
            clock: None,
        }
    }

    /// Aim the `SystemProxy` route at a concrete address (`ADR-048 §2`). Composition roots
    /// resolve the environment ONCE and hand the answer in; fetches never re-read env.
    pub fn with_system_proxy(mut self, proxy: std::net::SocketAddr) -> Self {
        self.system_proxy = Some(proxy);
        self
    }

    /// Give this adapter the same monotonic clock the source composition root uses. The adapter
    /// then checks `IoContext::cancel` and `deadline_mono_ms` at route, socket, header, and body
    /// boundaries. It remains cooperative around one blocking syscall; the source worker's outer
    /// post-call probe is what closes that unavoidable gap for the current no-runtime adapter.
    pub fn with_clock(mut self, clock: Arc<dyn Clock>) -> Self {
        self.clock = Some(clock);
        self
    }

    /// Resolve a system proxy address from the process environment (`http_proxy` then
    /// `all_proxy`, lower-case only — the conventional keys). The composition root calls
    /// this once; fetches never re-read the environment mid-flight.
    pub fn system_proxy_from_env() -> Option<std::net::SocketAddr> {
        for key in ["http_proxy", "all_proxy"] {
            if let Ok(value) = std::env::var(key) {
                if let Some(address) = Self::parse_proxy_value(&value) {
                    return Some(address);
                }
            }
        }
        None
    }

    /// The pure half of environment resolution: one proxy value -> one address, or None.
    /// `scheme://` prefixes are tolerated, `host:port` is the shape; a value that names no
    /// port is None, because a portless proxy address is not an address this adapter can
    /// dial — guessing a port would be the same lie as going direct.
    pub fn parse_proxy_value(value: &str) -> Option<std::net::SocketAddr> {
        value
            .trim()
            .trim_start_matches("http://")
            .trim_start_matches("https://")
            .parse::<std::net::SocketAddr>()
            .ok()
    }
}

impl StdHttp {
    fn fault(kind: IoFaultKind, summary: impl Into<String>) -> IoFault {
        IoFault::new(kind, summary.into())
    }

    fn poisoned(what: &str) -> IoFault {
        IoFault::new(
            IoFaultKind::InternalIo,
            format!("the {what} lock is poisoned; the sharing thread panicked"),
        )
    }
}

/// The caller-side guard shared by every blocking HTTP stage. It never reads a host clock: the
/// only time source is the clock the composition root injected into this adapter. A relative
/// `deadline_ms` is anchored once when the fetch starts; source workers normally arrive with the
/// absolute `deadline_mono_ms` already anchored so this and the outer driver share one instant.
struct CallerControl<'a> {
    ctx: &'a IoContext,
    deadline_mono_ms: Option<u64>,
    clock: Option<&'a dyn Clock>,
}

impl<'a> CallerControl<'a> {
    fn new(ctx: &'a IoContext, clock: Option<&'a dyn Clock>) -> Self {
        let deadline_mono_ms = caller_deadline_mono_ms(ctx, clock);
        Self {
            ctx,
            deadline_mono_ms,
            clock,
        }
    }

    fn check(&self, phase: &str) -> Result<(), IoFault> {
        check_caller_control(self.ctx, self.deadline_mono_ms, self.clock, phase)
    }

    /// Bound one blocking syscall by the caller's remaining time without replacing the adapter's
    /// peer timeout. A cancellation-only call keeps the established peer timeout and is checked at
    /// each boundary; a blocking syscall cannot observe a token until the OS returns from it
    /// (`ADR-052` §2.1–2.2: the honest boundary, not a claim of mid-syscall interruption).
    fn timeout(&self, peer: Duration) -> Duration {
        let Some((deadline, clock)) = self.deadline_mono_ms.zip(self.clock) else {
            return peer;
        };
        let now = clock.mono().ticks_millis;
        let remaining = deadline.saturating_sub(now).max(1);
        peer.min(Duration::from_millis(remaining))
    }
}

/// The pieces of a URL this adapter needs; anything it cannot honor is refused up front.
struct ParsedUrl {
    host: String,
    port: u16,
    path_with_query: String,
}

fn parse_url(url: &str) -> Result<ParsedUrl, IoFault> {
    let rest = if let Some(rest) = url.strip_prefix("http://") {
        rest
    } else if url.starts_with("https://") {
        return Err(IoFault::new(
            IoFaultKind::Unsupported,
            format!(
                "https is not implemented: TLS needs a client the no-external-crate doctrine \
                 (RFC-0001 §1.4) cannot provide, and refusing is the honest answer: {url}"
            ),
        ));
    } else {
        return Err(IoFault::new(
            IoFaultKind::InvalidInput,
            format!("fetch url must be http://, got: {url}"),
        ));
    };
    let (authority, path_with_query) = match rest.find('/') {
        Some(at) => (&rest[..at], &rest[at..]),
        None => (rest, "/"),
    };
    // Reject userinfo: it is a credential smuggled in a URL, and this adapter has no vault.
    if authority.contains('@') {
        return Err(IoFault::new(
            IoFaultKind::InvalidInput,
            format!("fetch url must not carry credentials: {url}"),
        ));
    }
    let (host, port) = match authority.rsplit_once(':') {
        Some((host, port)) => (
            host.to_owned(),
            port.parse::<u16>().map_err(|_| {
                IoFault::new(
                    IoFaultKind::InvalidInput,
                    format!("fetch url port is not a port number: {url}"),
                )
            })?,
        ),
        None => (authority.to_owned(), 80),
    };
    Ok(ParsedUrl {
        host,
        port,
        path_with_query: path_with_query.to_owned(),
    })
}

/// A response's status line and headers, minimally parsed. The body is collected only after
/// the caller/request ceiling has been established (`ADR-049`), so a successful response can
/// carry a complete owned snapshot without exposing a fake reader.
struct Head {
    status: u16,
    etag: Option<String>,
    last_modified: Option<String>,
    content_length: Option<u64>,
    chunked: bool,
}

fn header_value(line: &str) -> Option<&str> {
    line.split_once(':').map(|(_, value)| value.trim())
}

impl StdHttp {
    fn read_head(
        reader: &mut BufReader<TcpStream>,
        control: &CallerControl<'_>,
    ) -> Result<Head, IoFault> {
        control.check("the HTTP status line")?;
        let mut status_line = String::new();
        reader.read_line(&mut status_line).map_err(|error| {
            Self::fault(IoFaultKind::Timeout, format!("read status line: {error}"))
        })?;
        control.check("the HTTP headers")?;
        let status = status_line
            .split_whitespace()
            .nth(1)
            .and_then(|code| code.parse::<u16>().ok())
            .ok_or_else(|| {
                Self::fault(
                    IoFaultKind::InternalIo,
                    format!("malformed HTTP status line: {:?}", status_line.trim()),
                )
            })?;
        let mut head = Head {
            status,
            etag: None,
            last_modified: None,
            content_length: None,
            chunked: false,
        };
        loop {
            control.check("the next HTTP header")?;
            let mut line = String::new();
            reader.read_line(&mut line).map_err(|error| {
                Self::fault(IoFaultKind::Timeout, format!("read header: {error}"))
            })?;
            let trimmed = line.trim_end();
            if trimmed.is_empty() {
                break;
            }
            let lower = trimmed.to_ascii_lowercase();
            if lower.starts_with("etag:") {
                head.etag = header_value(trimmed).map(str::to_owned);
            } else if lower.starts_with("last-modified:") {
                head.last_modified = header_value(trimmed).map(str::to_owned);
            } else if lower.starts_with("content-length:") {
                head.content_length = header_value(trimmed).and_then(|v| v.parse().ok());
            } else if lower.starts_with("transfer-encoding:") {
                head.chunked = trimmed.to_ascii_lowercase().contains("chunked");
            }
        }
        Ok(head)
    }

    /// Collect the complete body under `ceiling`, returning no partial body on overflow.
    ///
    /// A declared `Content-Length` is rejected before any body byte is read. Chunked and
    /// connection-close responses read only enough framing to prove an overflow; the socket is
    /// then dropped, so an attacker cannot make the adapter buffer an unbounded body just to
    /// discover that it was too large (`ADR-049 §2.2`).
    fn read_body(
        reader: &mut BufReader<TcpStream>,
        head: &Head,
        ceiling: caly_io::ByteCeiling,
        resource: &str,
        control: &CallerControl<'_>,
    ) -> Result<Vec<u8>, IoFault> {
        control.check("the HTTP body")?;
        if let Some(total) = head.content_length {
            if let Some(fault) = ceiling.violation(total, resource) {
                return Err(fault);
            }
            let len = usize::try_from(total).map_err(|_| {
                Self::fault(
                    IoFaultKind::CapacityExceeded,
                    format!("{resource} body length does not fit this process"),
                )
            })?;
            let mut body = vec![0u8; len];
            control.check("the declared HTTP body")?;
            reader.read_exact(&mut body).map_err(|error| {
                Self::fault(IoFaultKind::Timeout, format!("read body: {error}"))
            })?;
            control.check("completion of the declared HTTP body")?;
            return Ok(body);
        }

        if head.chunked {
            let mut body = Vec::new();
            loop {
                control.check("the next chunk header")?;
                let mut size_line = String::new();
                reader.read_line(&mut size_line).map_err(|error| {
                    Self::fault(IoFaultKind::Timeout, format!("read chunk size: {error}"))
                })?;
                let size_token = size_line
                    .trim()
                    .split_once(';')
                    .map_or(size_line.trim(), |(size, _extensions)| size);
                let size = u64::from_str_radix(size_token, 16).map_err(|_| {
                    Self::fault(
                        IoFaultKind::InternalIo,
                        format!("malformed chunk size line: {:?}", size_line.trim()),
                    )
                })?;
                if size == 0 {
                    // Consume trailers up to the empty line. They are not part of the body, but
                    // consuming the framing keeps this parser honest for a peer that sends them.
                    loop {
                        control.check("the next chunk trailer")?;
                        let mut trailer = String::new();
                        reader.read_line(&mut trailer).map_err(|error| {
                            Self::fault(
                                IoFaultKind::Timeout,
                                format!("read chunk trailer: {error}"),
                            )
                        })?;
                        if trailer.trim_end().is_empty() {
                            break;
                        }
                    }
                    return Ok(body);
                }
                let next = (body.len() as u64).saturating_add(size);
                if let Some(fault) = ceiling.violation(next, resource) {
                    return Err(fault);
                }
                let chunk_len = usize::try_from(size).map_err(|_| {
                    Self::fault(
                        IoFaultKind::CapacityExceeded,
                        format!("{resource} chunk length does not fit this process"),
                    )
                })?;
                let mut chunk = vec![0u8; chunk_len];
                control.check("the next chunk body")?;
                reader.read_exact(&mut chunk).map_err(|error| {
                    Self::fault(IoFaultKind::Timeout, format!("read chunk body: {error}"))
                })?;
                control.check("the next chunk terminator")?;
                body.extend_from_slice(&chunk);
                let mut crlf = [0u8; 2];
                reader.read_exact(&mut crlf).map_err(|error| {
                    Self::fault(
                        IoFaultKind::Timeout,
                        format!("read chunk terminator: {error}"),
                    )
                })?;
                if crlf != *b"\r\n" {
                    return Err(Self::fault(
                        IoFaultKind::InternalIo,
                        format!("malformed chunk terminator for {resource}"),
                    ));
                }
            }
        }

        // No length and no chunk framing means the response ends with the connection. Read in
        // bounded blocks and probe one byte beyond the ceiling; no over-bound byte is retained.
        let mut body = Vec::new();
        let mut buffer = [0u8; 4096];
        loop {
            control.check("the next EOF-framed body block")?;
            // Ask the peer for at most the remaining ceiling plus one byte. The extra byte is
            // enough to prove overflow, while the slice keeps an EOF-framed response from
            // moving a whole 4 KiB block past a 512-byte caller limit.
            let remaining = ceiling.bytes.saturating_sub(body.len() as u64);
            let request_len = remaining.saturating_add(1).min(buffer.len() as u64) as usize;
            let read = reader.read(&mut buffer[..request_len]).map_err(|error| {
                Self::fault(IoFaultKind::Timeout, format!("read body: {error}"))
            })?;
            if read == 0 {
                control.check("completion of the EOF-framed body")?;
                return Ok(body);
            }
            control.check("the next EOF-framed body block")?;
            let next = (body.len() as u64).saturating_add(read as u64);
            if let Some(fault) = ceiling.violation(next, resource) {
                return Err(fault);
            }
            body.extend_from_slice(&buffer[..read]);
        }
    }
}

impl Http for StdHttp {
    fn fetch<'a>(
        &'a self,
        req: FetchReq,
        ctx: &'a IoContext,
    ) -> BoxFuture<'a, Result<FetchResp, IoFault>> {
        Box::pin(async move {
            let control = CallerControl::new(ctx, self.clock.as_deref());
            control.check("HTTP URL parsing")?;
            let url = req.url.clone();
            let scope = req.scope;
            let parsed = parse_url(&url)?;
            control.check("HTTP route resolution")?;

            // The route decides WHERE the request is sent and in WHICH form (`ADR-047 §2`):
            // Direct resolves and sends origin-form; ActiveCore sends absolute-form to the
            // live core's mixed inbound; SystemProxy is an honest refusal until a proxy
            // resolution face exists.
            let (address, absolute_form, exempt_from_peer_check) = match req.route {
                FetchRoute::Direct => {
                    control.check("DNS resolution")?;
                    let address: SocketAddr = (parsed.host.as_str(), parsed.port)
                        .to_socket_addrs()
                        .map_err(|error| {
                            Self::fault(
                                IoFaultKind::Unavailable,
                                format!("resolve {}: {error}", parsed.host),
                            )
                        })?
                        .next()
                        .ok_or_else(|| {
                            Self::fault(
                                IoFaultKind::Unavailable,
                                format!("resolve {}: no address", parsed.host),
                            )
                        })?;
                    (address, false, false)
                }
                FetchRoute::ActiveCore => {
                    let source = self.core_route.as_ref().ok_or_else(|| {
                        Self::fault(
                            IoFaultKind::Unavailable,
                            "the ActiveCore route has no core route source wired on this \
                             adapter — refusing rather than silently going direct (ADR-047 §2)",
                        )
                    })?;
                    let guarded = source
                        .lock()
                        .map_err(|_| Self::poisoned("core route source"))?;
                    let address = guarded.ok_or_else(|| {
                        Self::fault(
                            IoFaultKind::Unavailable,
                            "no live core to route through: the ActiveCore route needs a \
                             spawned core (ADR-047 §2)",
                        )
                    })?;
                    (address, true, true)
                }
                FetchRoute::SystemProxy => {
                    let address = self.system_proxy.ok_or_else(|| {
                        Self::fault(
                            IoFaultKind::Unavailable,
                            "no system proxy is configured on this adapter \
                             (http_proxy/all_proxy unset or unparseable at composition) — \
                             refusing by name rather than silently going direct (ADR-048 §2)",
                        )
                    })?;
                    (address, true, true)
                }
            };
            control.check("TCP connection")?;
            let mut stream = TcpStream::connect_timeout(&address, control.timeout(CONNECT_TIMEOUT))
                .map_err(|error| {
                    let kind = if error.kind() == std::io::ErrorKind::TimedOut {
                        IoFaultKind::Timeout
                    } else {
                        IoFaultKind::Unavailable
                    };
                    Self::fault(kind, format!("connect {address}: {error}"))
                })?;
            control.check("HTTP socket setup")?;
            // RFC-0010 §11.1: the SSRF boundary is checked against the peer the connection
            // actually reached — after connect, not before resolve, so a rebinding answer is
            // judged by the same rule as an honest one. `ActiveCore` (the daemon's own spawned
            // core management address, the RFC's explicit exemption) and `SystemProxy` (a proxy
            // address is the caller's own explicit configuration, and the real target behind it
            // is not visible here to check) do not enter this gate; `Direct` does, and the
            // conservative `Default` scope admits only `Public` peers (`FetchScope`).
            if !exempt_from_peer_check {
                let peer = stream.peer_addr().map_err(|error| {
                    Self::fault(
                        IoFaultKind::InternalIo,
                        format!("read the connected peer address: {error}"),
                    )
                })?;
                if !peer_allowed_in_scope(&peer, scope) {
                    // The connection is dropped with the binding socket: nothing has been
                    // written, so the peer sees a closed handshake, not a request.
                    return Err(Self::fault(
                        IoFaultKind::PermissionDenied,
                        format!(
                            "{} {peer} is outside the default fetch scope (RFC-0010 §11.1                              SSRF boundary: loopback/link-local-metadata/private peers are                              refused unless the caller opts into FetchScope::AnyPeer)",
                            match classify_peer_address(&peer) {
                                PeerClass::Loopback => "loopback peer",
                                PeerClass::LinkLocalOrMetadata => "link-local/metadata peer",
                                PeerClass::Private => "private-range peer",
                                PeerClass::Public => "peer",
                            }
                        ),
                    ));
                }
            }
            stream
                .set_read_timeout(Some(control.timeout(IO_TIMEOUT)))
                .map_err(|error| {
                    Self::fault(
                        IoFaultKind::InternalIo,
                        format!("set read timeout: {error}"),
                    )
                })?;
            stream
                .set_write_timeout(Some(control.timeout(IO_TIMEOUT)))
                .map_err(|error| {
                    Self::fault(
                        IoFaultKind::InternalIo,
                        format!("set write timeout: {error}"),
                    )
                })?;

            // A proxy request carries the absolute form (`GET http://host:port/path`); the
            // origin form is only meaningful on a direct socket.
            let request_target = if absolute_form {
                format!(
                    "http://{}:{}{}",
                    parsed.host, parsed.port, parsed.path_with_query
                )
            } else {
                parsed.path_with_query.clone()
            };
            let mut request = format!(
                "GET {} HTTP/1.1\r\nHost: {}\r\nUser-Agent: {USER_AGENT}\r\nAccept: */*\r\nConnection: close\r\n",
                request_target, parsed.host
            );
            if let Some(etag) = &req.etag {
                request.push_str(&format!("If-None-Match: {etag}\r\n"));
            }
            if let Some(since) = &req.if_modified_since {
                request.push_str(&format!("If-Modified-Since: {since}\r\n"));
            }
            request.push_str("\r\n");
            control.check("HTTP request write")?;
            stream.write_all(request.as_bytes()).map_err(|error| {
                Self::fault(IoFaultKind::Timeout, format!("write request: {error}"))
            })?;
            stream.flush().map_err(|error| {
                Self::fault(IoFaultKind::Timeout, format!("flush request: {error}"))
            })?;
            control.check("HTTP response headers")?;

            let mut reader = BufReader::new(stream);
            let head = Self::read_head(&mut reader, &control)?;

            // The caller's budget and the request's own bound are both ceilings on the transfer
            // (`RFC-0006 §15.3`): the tighter one bites, and the refusal says which.
            let ceiling = caly_io::byte_ceiling(ctx, req.max_body_bytes);
            control.check("HTTP body transfer")?;
            let bytes = Self::read_body(&mut reader, &head, ceiling, &url, &control)?;
            control.check("HTTP body completion")?;

            Ok(FetchResp {
                status: head.status,
                etag: head.etag,
                last_modified: head.last_modified,
                body: FetchBody {
                    // `ADR-040`: the prefix names the port ("this came from Http"), not a scheme.
                    label: format!("http:{url}"),
                    bytes,
                },
            })
        })
    }
}
