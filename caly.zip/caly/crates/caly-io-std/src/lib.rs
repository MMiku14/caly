//! `caly-io-std`: the production Port adapters.
//!
//! This crate was named as a required member by `RFC-0001 §204` / `§1461` and listed as missing
//! in `ROADMAP.md §4`, but did not exist. Its absence left `caly-io`'s ports with exactly one
//! implementation (the simulator), which meant the "single IO gateway" of `ADR-011` was a shape
//! with no production side.
//!
//! Scope of this first cut:
//!
//! * [`StdFs`] — the whole `Fs` port, plus the release half of locking (`caly_io::contract::FsLocking`).
//! * [`StdClock`] — wall + monotonic time with `sleep_until`.
//! * [`StdHttp`] — plain HTTP/1.1 over `std::net` (`http://` only; `https` refused with the
//!   doctrine named), sharing `caly_io::contract`'s fetch suite with the simulator since round 42.
//! * `Proc`, `Platform` are **not** implemented: they need the process/exec decisions that are
//!   still open (`docs/ONBOARDING_NOTES.md §3.3`, `§6.10`). Rather than fake them, the contract
//!   suite simply does not run them here.
//!
//! Durability tiers follow `ADR-014`:
//!
//! | tier | what this crate does |
//! |---|---|
//! | `D0` | plain write; no temp file, no sync |
//! | `D1` | sibling temp file + atomic rename |
//! | `D2` | `D1` + `fsync(file)` + `fsync(parent dir)` |
//! | `D3` | `D2` at this layer; the "DB commit coordination" half belongs to `caly-storage`, which owns journal/snapshot ordering |

#![forbid(unsafe_code)]

mod http;
mod proc;

pub use http::{classify_peer_address, peer_allowed_in_scope, CoreRouteSource, PeerClass, StdHttp};
pub use proc::StdProc;

use std::fs::{self, File, OpenOptions};
use std::io::Write;
use std::path::Path;
use std::sync::atomic::{AtomicU64, Ordering};
use std::time::{Duration, Instant, SystemTime, UNIX_EPOCH};

use caly_io::{
    BoxFuture, ByteCap, ByteStream, Bytes, Clock, Durability, FileLock, Fs, IoContext, IoFault,
    IoFaultKind, LinkKind, ListCap, Meta, Monotonic, Timestamp, VPath,
};

/// The last write time, as the filesystem itself records it.
///
/// A missing `mtime` (some filesystems, some platforms) becomes `None` rather than a synthetic value:
/// a caller that could not tell "unknown" from "epoch" would treat a brand-new file as ancient and
/// delete it, which is the failure `ADR-035 §2.2` exists to avoid.
fn metadata_mtime(meta: &fs::Metadata) -> Option<i64> {
    meta.modified()
        .ok()
        .and_then(|when| when.duration_since(UNIX_EPOCH).ok())
        .and_then(|since| i64::try_from(since.as_millis()).ok())
}

/// Counter used to give temp files distinct names without a clock or randomness.
static TEMP_SEQUENCE: AtomicU64 = AtomicU64::new(0);

/// A filesystem-backed [`Fs`] implementation, confined to one root directory.
///
/// Every path handed to this type is a `VPath`, i.e. already relative and free of `.`/`..`
/// segments; `resolve` re-checks that the joined result still sits under `root`, so a
/// `VPath` bug cannot turn into a write outside the sandbox.
#[derive(Clone, Debug)]
pub struct StdFs {
    root: String,
}

impl StdFs {
    pub fn new(root: impl Into<String>) -> Self {
        let root = root.into();
        let trimmed = root.trim_end_matches('/').to_owned();
        Self {
            root: if trimmed.is_empty() {
                ".".to_owned()
            } else {
                trimmed
            },
        }
    }

    pub fn root(&self) -> &str {
        &self.root
    }

    fn resolve(&self, path: &VPath) -> Result<String, IoFault> {
        let relative = path.as_relative_path();
        if relative.is_empty()
            || relative.contains("..")
            || relative.starts_with('/')
            || Path::new(&relative).is_absolute()
        {
            return Err(IoFault::new(
                IoFaultKind::InvalidInput,
                format!("path must stay inside the root: {relative:?}"),
            ));
        }
        Ok(format!("{root}/{relative}", root = self.root))
    }

    fn ensure_parent(&self, target: &str) -> Result<(), IoFault> {
        let Some((parent, _)) = target.rsplit_once('/') else {
            return Ok(());
        };
        if parent.is_empty() {
            return Ok(());
        }
        fs::create_dir_all(parent).map_err(|error| {
            IoFault::new(IoFaultKind::InternalIo, format!("mkdir {parent}: {error}"))
        })
    }

    fn fsync_path(path: &str) -> Result<(), IoFault> {
        // `File::open` on a directory is the portable-enough way to fsync a directory entry set
        // on unix; on platforms where it is unsupported the error is reported rather than
        // silently skipped, because a durability tier that quietly does nothing is worse than one
        // that fails.
        let handle = File::open(path).map_err(|error| {
            IoFault::new(
                IoFaultKind::InternalIo,
                format!("open {path} for sync: {error}"),
            )
        })?;
        handle.sync_all().map_err(|error| {
            IoFault::new(IoFaultKind::InternalIo, format!("fsync {path}: {error}"))
        })
    }

    /// Build a fault with the optional fields the port contract relies on filled in.
    fn fault(kind: IoFaultKind, summary: impl Into<String>) -> IoFault {
        IoFault {
            kind,
            summary: summary.into(),
            retryable: matches!(
                kind,
                IoFaultKind::Busy | IoFaultKind::Transient | IoFaultKind::Unavailable
            ),
            transient: matches!(kind, IoFaultKind::Busy | IoFaultKind::Transient),
            resource: None,
            source_hint: None,
            trace_id: None,
        }
    }

    fn not_found(context: &str, error: &std::io::Error) -> Option<IoFault> {
        (error.kind() == std::io::ErrorKind::NotFound)
            .then(|| IoFault::new(IoFaultKind::NotFound, format!("{context}: {error}")))
    }
}

impl Fs for StdFs {
    fn read<'a>(
        &'a self,
        path: &'a VPath,
        cap: ByteCap,
        ctx: &'a IoContext,
    ) -> BoxFuture<'a, Result<Bytes, IoFault>> {
        Box::pin(async move {
            let target = self.resolve(path)?;
            // `RFC-0006 §5.3`: the caller's byte budget is a second, possibly tighter bound, and the
            // helper is what keeps this backend from wording the refusal differently from the simulator.
            let ceiling = caly_io::byte_ceiling(ctx, cap.0);
            let meta = fs::metadata(&target).map_err(|error| {
                Self::not_found(&format!("stat {target}"), &error)
                    .unwrap_or_else(|| IoFault::new(IoFaultKind::InternalIo, error.to_string()))
            })?;
            if let Some(too_big) = ceiling.violation(meta.len(), &target) {
                return Err(too_big);
            }
            fs::read(&target).map_err(|error| {
                IoFault::new(IoFaultKind::InternalIo, format!("read {target}: {error}"))
            })
        })
    }

    fn open_stream<'a>(
        &'a self,
        path: &'a VPath,
        _ctx: &'a IoContext,
    ) -> BoxFuture<'a, Result<ByteStream, IoFault>> {
        // The port's `ByteStream` is a handle label, not an iterator, so a chunked reader cannot
        // be expressed yet (`ADR-040`); existence is still verified against the host, which is
        // what the contract asserts. The label is the caller's own path — the resolved host
        // path stays inside the sandbox, where `resolve` put it; handing it back would undo the
        // one thing VPath sandboxing exists to do.
        Box::pin(async move {
            let target = self.resolve(path)?;
            if !Path::new(&target).exists() {
                let mut missing = Self::fault(
                    IoFaultKind::NotFound,
                    format!("stream target missing: {target}"),
                );
                missing.resource = Some(target);
                return Err(missing);
            }
            Ok(ByteStream {
                label: path.as_relative_path(),
            })
        })
    }

    fn write_atomic<'a>(
        &'a self,
        path: &'a VPath,
        data: Bytes,
        durability: Durability,
        ctx: &'a IoContext,
    ) -> BoxFuture<'a, Result<(), IoFault>> {
        Box::pin(async move {
            let target = self.resolve(path)?;
            // Measured **before** anything touches the disk: a payload the caller's budget forbids must
            // not leave a temp file, a rename, or half a write behind (`RFC-0007 §6.2`).
            caly_io::check_payload(ctx, &target, data.len() as u64)?;
            self.ensure_parent(&target)?;
            let durable = matches!(durability, Durability::D2 | Durability::D3);

            if matches!(durability, Durability::D0) {
                return fs::write(&target, data).map_err(|error| {
                    IoFault::new(IoFaultKind::InternalIo, format!("write {target}: {error}"))
                });
            }

            let sequence = TEMP_SEQUENCE.fetch_add(1, Ordering::Relaxed);
            let temp = format!("{target}.tmp-{sequence}");
            {
                let mut handle = File::create(&temp).map_err(|error| {
                    IoFault::new(IoFaultKind::InternalIo, format!("create {temp}: {error}"))
                })?;
                handle.write_all(&data).map_err(|error| {
                    let _ = fs::remove_file(&temp);
                    IoFault::new(IoFaultKind::InternalIo, format!("write {temp}: {error}"))
                })?;
                if durable {
                    handle.sync_all().map_err(|error| {
                        let _ = fs::remove_file(&temp);
                        IoFault::new(IoFaultKind::InternalIo, format!("fsync {temp}: {error}"))
                    })?;
                }
            }

            fs::rename(&temp, &target).map_err(|error| {
                let _ = fs::remove_file(&temp);
                IoFault::new(
                    IoFaultKind::InternalIo,
                    format!("rename {temp} -> {target}: {error}"),
                )
            })?;

            if durable {
                if let Some((parent, _)) = target.rsplit_once('/') {
                    Self::fsync_path(parent)?;
                }
            }
            Ok(())
        })
    }

    fn rename<'a>(
        &'a self,
        from: &'a VPath,
        to: &'a VPath,
        durability: Durability,
        _ctx: &'a IoContext,
    ) -> BoxFuture<'a, Result<(), IoFault>> {
        Box::pin(async move {
            let source = self.resolve(from)?;
            let destination = self.resolve(to)?;
            if !Path::new(&source).exists() {
                let mut missing = Self::fault(
                    IoFaultKind::NotFound,
                    format!("rename source missing: {source}"),
                );
                missing.resource = Some(source);
                return Err(missing);
            }
            self.ensure_parent(&destination)?;
            fs::rename(&source, &destination).map_err(|error| {
                IoFault::new(
                    IoFaultKind::InternalIo,
                    format!("rename {source} -> {destination}: {error}"),
                )
            })?;
            if matches!(durability, Durability::D2 | Durability::D3) {
                if let Some((parent, _)) = destination.rsplit_once('/') {
                    Self::fsync_path(parent)?;
                }
            }
            Ok(())
        })
    }

    fn remove<'a>(
        &'a self,
        path: &'a VPath,
        _ctx: &'a IoContext,
    ) -> BoxFuture<'a, Result<(), IoFault>> {
        Box::pin(async move {
            let target = self.resolve(path)?;
            match fs::remove_file(&target) {
                Ok(()) => {
                    if let Some((parent, _)) = target.rsplit_once('/') {
                        let _ = Self::fsync_path(parent);
                    }
                    Ok(())
                }
                Err(error) => Err(Self::not_found(&format!("remove {target}"), &error)
                    .unwrap_or_else(|| {
                        IoFault::new(IoFaultKind::InternalIo, format!("remove {target}: {error}"))
                    })),
            }
        })
    }

    fn stat<'a>(
        &'a self,
        path: &'a VPath,
        _ctx: &'a IoContext,
    ) -> BoxFuture<'a, Result<Option<Meta>, IoFault>> {
        Box::pin(async move {
            let target = self.resolve(path)?;
            match fs::metadata(&target) {
                Ok(meta) => Ok(Some(Meta {
                    len: meta.len(),
                    is_file: meta.is_file(),
                    is_dir: meta.is_dir(),
                    modified_at_unix_ms: metadata_mtime(&meta),
                })),
                Err(error) => match Self::not_found(&format!("stat {target}"), &error) {
                    Some(_) => Ok(None),
                    None => Err(IoFault::new(
                        IoFaultKind::InternalIo,
                        format!("stat {target}: {error}"),
                    )),
                },
            }
        })
    }

    fn stat_many<'a>(
        &'a self,
        paths: &'a [VPath],
        _ctx: &'a IoContext,
    ) -> BoxFuture<'a, Result<Vec<Option<Meta>>, IoFault>> {
        // One logical port call (`ADR-054 §2.2`); POSIX has no batch metadata syscall, so
        // underneath this loops the same `metadata` calls `stat` makes — but the caller's
        // contract is one operation, and a fault/absent path answers per entry exactly as a
        // one-by-one `stat` would.
        Box::pin(async move {
            let mut metas = Vec::with_capacity(paths.len());
            for path in paths {
                let target = self.resolve(path)?;
                match fs::metadata(&target) {
                    Ok(meta) => metas.push(Some(Meta {
                        len: meta.len(),
                        is_file: meta.is_file(),
                        is_dir: meta.is_dir(),
                        modified_at_unix_ms: metadata_mtime(&meta),
                    })),
                    Err(error) => match Self::not_found(&format!("stat {target}"), &error) {
                        Some(_) => metas.push(None),
                        None => {
                            return Err(IoFault::new(
                                IoFaultKind::InternalIo,
                                format!("stat {target}: {error}"),
                            ))
                        }
                    },
                }
            }
            Ok(metas)
        })
    }

    fn link_or_copy<'a>(
        &'a self,
        from: &'a VPath,
        to: &'a VPath,
        _ctx: &'a IoContext,
    ) -> BoxFuture<'a, Result<LinkKind, IoFault>> {
        Box::pin(async move {
            let source = self.resolve(from)?;
            let destination = self.resolve(to)?;
            self.ensure_parent(&destination)?;
            match fs::hard_link(&source, &destination) {
                Ok(()) => Ok(LinkKind::Hardlink),
                Err(_) => match fs::copy(&source, &destination) {
                    Ok(_) => Ok(LinkKind::Copy),
                    Err(error) => Err(IoFault::new(
                        IoFaultKind::InternalIo,
                        format!("link_or_copy {source} -> {destination}: {error}"),
                    )),
                },
            }
        })
    }

    fn list<'a>(
        &'a self,
        dir: &'a VPath,
        cap: ListCap,
        _ctx: &'a IoContext,
    ) -> BoxFuture<'a, Result<Vec<VPath>, IoFault>> {
        let base = dir.clone();
        Box::pin(async move {
            let relative = base.as_relative_path();
            let target = self.resolve(&base)?;
            let listing = fs::read_dir(&target).map_err(|error| {
                // The summary carries the *relative* path only: the absolute one is the host's
                // layout, and port faults end up in client-visible text once a store re-words them
                // (`docs/ONBOARDING_NOTES.md §4.47`).
                if error.kind() == std::io::ErrorKind::NotFound {
                    IoFault::new(
                        IoFaultKind::NotFound,
                        format!("directory not found: {relative}"),
                    )
                } else if error.kind() == std::io::ErrorKind::NotADirectory {
                    IoFault::new(
                        IoFaultKind::InvalidInput,
                        format!("not a directory: {relative}"),
                    )
                } else {
                    IoFault::new(IoFaultKind::InternalIo, format!("list {relative}: {error}"))
                }
            })?;
            let mut names: Vec<String> = Vec::new();
            for entry in listing {
                let entry = entry.map_err(|error| {
                    IoFault::new(IoFaultKind::InternalIo, format!("list {relative}: {error}"))
                })?;
                // `DirEntry::file_name` is the name itself, which also keeps this crate from naming
                // `PathBuf` — a type the workspace lint bans for a reason (`ADR-011`).
                let Some(name) = entry.file_name().to_str().map(str::to_owned) else {
                    return Err(IoFault::new(
                        IoFaultKind::InvalidInput,
                        format!("list {relative}: a child name is not valid utf-8"),
                    ));
                };
                names.push(name);
            }
            names.sort();
            if names.len() > cap.0 as usize {
                return Err(IoFault::new(
                    IoFaultKind::CapacityExceeded,
                    format!(
                        "directory {relative} holds {} entries, cap was {}",
                        names.len(),
                        cap.0
                    ),
                ));
            }
            names
                .into_iter()
                .map(|name| {
                    base.join(&name)
                        .map_err(|error| IoFault::new(IoFaultKind::InvalidInput, error.message))
                })
                .collect()
        })
    }

    fn lock_exclusive<'a>(
        &'a self,
        path: &'a VPath,
        _ctx: &'a IoContext,
    ) -> BoxFuture<'a, Result<FileLock, IoFault>> {
        Box::pin(async move {
            let target = self.resolve(path)?;
            let lock_path = lock_file_for(&target);
            self.ensure_parent(&lock_path)?;
            match OpenOptions::new()
                .write(true)
                .create_new(true)
                .open(&lock_path)
            {
                Ok(handle) => {
                    let _ = handle.sync_all();
                    Ok(FileLock { path: lock_path })
                }
                Err(error) if error.kind() == std::io::ErrorKind::AlreadyExists => {
                    let mut held = Self::fault(
                        IoFaultKind::AlreadyExists,
                        format!("lock held: {lock_path}"),
                    );
                    held.resource = Some(lock_path);
                    held.retryable = true;
                    Err(held)
                }
                Err(error) => Err(IoFault::new(
                    IoFaultKind::InternalIo,
                    format!("lock {lock_path}: {error}"),
                )),
            }
        })
    }
}

fn lock_file_for(target: &str) -> String {
    format!("{target}.lock")
}

/// Wall + monotonic clock.
///
/// `mono()` is measured from process start, so it cannot be disturbed by a wall-clock step
/// (`RFC-0006 §15.5`). `sleep_until` blocks: with no executor in the workspace this is the only
/// honest way to wait, and callers are bounded by their own `Ctx::deadline_ms`.
#[derive(Clone, Debug)]
pub struct StdClock {
    started: Instant,
    /// Extra monotonic offset, always non-negative, so tests can move time forward without
    /// being able to move it back.
    offset: std::sync::Arc<std::sync::Mutex<u64>>,
}

impl Default for StdClock {
    fn default() -> Self {
        Self::new()
    }
}

impl StdClock {
    pub fn new() -> Self {
        Self {
            started: Instant::now(),
            offset: std::sync::Arc::new(std::sync::Mutex::new(0)),
        }
    }

    fn mono_millis(&self) -> u64 {
        let elapsed = self.started.elapsed().as_millis() as u64;
        let offset = self.offset.lock().map(|guard| *guard).unwrap_or_default();
        elapsed.saturating_add(offset)
    }

    /// Advance the monotonic clock by `millis`. Only ever forward.
    pub fn advance_ms(&self, millis: u64) {
        if let Ok(mut guard) = self.offset.lock() {
            *guard = guard.saturating_add(millis);
        }
    }
}

impl Clock for StdClock {
    fn now(&self) -> Timestamp {
        let millis = SystemTime::now()
            .duration_since(UNIX_EPOCH)
            .map(|since| since.as_millis() as i64)
            .unwrap_or_default();
        Timestamp {
            unix_millis: millis,
        }
    }

    fn mono(&self) -> Monotonic {
        Monotonic {
            ticks_millis: self.mono_millis(),
        }
    }

    fn sleep_until<'a>(&'a self, at: Monotonic) -> BoxFuture<'a, Result<(), IoFault>> {
        Box::pin(async move {
            loop {
                let current = self.mono_millis();
                if current >= at.ticks_millis {
                    return Ok(());
                }
                let remaining = at.ticks_millis - current;
                // Yield in bounded slices so an `advance_ms` from another thread is honoured
                // instead of being slept straight past.
                let slice = remaining.min(5);
                std::thread::sleep(Duration::from_millis(slice));
            }
        })
    }
}

/// The release half of [`Fs::lock_exclusive`], which the frozen `Fs` trait has no way to express.
///
/// `caly_io::contract::FsLocking` documents why this exists; both `StdFs` and the simulator
/// implement it so the same lock contract test can run against either.
impl caly_io::contract::FsLocking for StdFs {
    fn lock<'a>(
        &'a self,
        path: &'a VPath,
        ctx: &'a IoContext,
    ) -> BoxFuture<'a, Result<FileLock, IoFault>> {
        self.lock_exclusive(path, ctx)
    }

    fn release<'a>(
        &'a self,
        lock: &'a FileLock,
        _ctx: &'a IoContext,
    ) -> BoxFuture<'a, Result<(), IoFault>> {
        Box::pin(async move { Self::release_path(&lock.path) })
    }

    fn release_path<'a>(
        &'a self,
        path: &'a VPath,
        _ctx: &'a IoContext,
    ) -> BoxFuture<'a, Result<(), IoFault>> {
        Box::pin(async move {
            let target = self.resolve(path)?;
            Self::release_path(&lock_file_for(&target))
        })
    }
}

impl StdFs {
    fn release_path(lock_path: &str) -> Result<(), IoFault> {
        match fs::remove_file(lock_path) {
            Ok(()) => {
                if let Some((parent, _)) = lock_path.rsplit_once('/') {
                    let _ = Self::fsync_path(parent);
                }
                Ok(())
            }
            Err(error) => match Self::not_found(&format!("release {lock_path}"), &error) {
                // Releasing something not held is idempotent: recovery calls this defensively.
                Some(_) => Ok(()),
                None => Err(IoFault::new(
                    IoFaultKind::InternalIo,
                    format!("release {lock_path}: {error}"),
                )),
            },
        }
    }
}
