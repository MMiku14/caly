//! The `Proc` port on a real host (`ADR-042`).
//!
//! What this adapter is: the one place in the workspace where `std::process::Command` is
//! allowed to exist. The crate's clippy table lifts exactly that ban, exactly here, because
//! `ADR-011` / `ADR-013` route every world contact through `caly-io` ports — and a port with
//! no backend is a promise nobody can check against the simulator (`ADR-022`).
//!
//! What it is **not**: a supervisor. The port's own shape is fire-and-forget — `ChildHandle`
//! carries a pid and a nonce, and deliberately nothing else (no wait, no kill, no signal) —
//! so this adapter spawns and forgets. Wait policies, exit statuses, restart and reaping are
//! a future port-growth decision that arrives with its own ADR, not a silent extra this file
//! could add by itself.
//!
//! Rules that are load-bearing:
//!
//! * **Shell-free** (`RFC-0006 §15` item 4). `program` is exec'd directly and `argv` is the
//!   literal argument vector — no `/bin/sh -c` wrapper, because a shell between the daemon
//!   and its core would turn every space in a path into an injection the port contract
//!   cannot see.
//! * **The child works inside the gateway root.** A `cwd` in the spec resolves under this
//!   adapter's root with `StdFs`'s own rules — a `VPath` bug must not become a process
//!   spawned in someone else's directory.
//! * **The child owns nothing of the daemon's.** stdin/stdout/stderr are `/dev/null`, never
//!   inherited: a fire-and-forget child that kept the daemon's sockets would hold client
//!   connections open for exactly as long as it lives.
//! * **Failure is named.** A program the host cannot find is `NotFound` naming the program —
//!   the operator's next move depends on knowing that, and a generic "spawn failed" hides it.

use std::collections::BTreeMap;
use std::process::{Child, Command, Stdio};
use std::sync::atomic::{AtomicU64, Ordering};
use std::sync::{Arc, Mutex};
use std::time::{Duration, Instant};

use caly_io::{
    BoxFuture, ChildExit, ChildHandle, IoContext, IoFault, IoFaultKind, Proc, SpawnSpec, VPath,
};

/// Counts spawns for the lifetime of this process, so an instance nonce stays unique even
/// though the host recycles pids.
static SPAWN_SEQUENCE: AtomicU64 = AtomicU64::new(0);

/// How often [`Proc::stop`]'s grace window checks whether the child exited on its own.
const STOP_POLL_MS: u64 = 20;

/// Fire-and-forget spawn on the real host, plus the supervision surface of `ADR-043`: the
/// children stay reachable by their nonce so they can be polled and stopped, and they are
/// **reaped** (waited) by this port rather than left for the host's init to collect. `root`
/// is the same gateway root `StdFs` would use: a `cwd` in the spec resolves under it and
/// nowhere else.
#[derive(Clone, Debug)]
pub struct StdProc {
    root: String,
    children: Arc<Mutex<BTreeMap<String, Arc<Mutex<Child>>>>>,
}

impl StdProc {
    pub fn new(root: impl Into<String>) -> Self {
        let root = root.into();
        let trimmed = root.trim_end_matches('/').to_owned();
        Self {
            root: if trimmed.is_empty() {
                ".".to_owned()
            } else {
                trimmed
            },
            children: Arc::new(Mutex::new(BTreeMap::new())),
        }
    }

    pub fn root(&self) -> &str {
        &self.root
    }

    fn child_by_nonce(&self, nonce: &str) -> Result<Arc<Mutex<Child>>, IoFault> {
        self.children
            .lock()
            .map_err(|_| IoFault::new(IoFaultKind::InternalIo, "proc registry lock poisoned"))?
            .get(nonce)
            .cloned()
            .ok_or_else(|| {
                IoFault::new(
                    IoFaultKind::NotFound,
                    format!("no child with instance nonce {nonce:?}: never spawned by this port, or already reaped"),
                )
            })
    }

    /// Same rule as `StdFs::resolve`: relative, no `..`, never absolute — so the spec's cwd
    /// cannot escape the gateway root. `VPath` already refuses these shapes at construction;
    /// this guard is the second layer, kept because "the type checked it once" is not a
    /// sandbox, it is a hope.
    fn resolve_cwd(&self, path: &VPath) -> Result<String, IoFault> {
        let relative = path.as_relative_path();
        if relative.is_empty()
            || relative.contains("..")
            || relative.starts_with('/')
            || std::path::Path::new(&relative).is_absolute()
        {
            return Err(IoFault::new(
                IoFaultKind::InvalidInput,
                format!("spawn cwd must stay inside the root: {relative:?}"),
            ));
        }
        Ok(format!("{root}/{relative}", root = self.root))
    }
}

impl Proc for StdProc {
    fn spawn<'a>(
        &'a self,
        spec: SpawnSpec,
        _ctx: &'a IoContext,
    ) -> BoxFuture<'a, Result<ChildHandle, IoFault>> {
        Box::pin(async move {
            if spec.program.trim().is_empty() {
                return Err(IoFault::new(
                    IoFaultKind::InvalidInput,
                    "spawn: a program name is required, not an empty string",
                ));
            }
            let cwd = match &spec.cwd {
                Some(path) => Some(self.resolve_cwd(path)?),
                None => None,
            };
            if let Some(cwd) = cwd.as_deref() {
                // An ENOENT at spawn time is ambiguous between "no such program" and "no
                // such cwd" — the OS reports both the same way, and mapping either onto the
                // program's name would lie about which one happened. The cwd is ours to
                // check before anything forks, so its refusal names the cwd; from here on, a
                // NotFound really is the program.
                if !std::path::Path::new(cwd).is_dir() {
                    return Err(IoFault::new(
                        IoFaultKind::NotFound,
                        format!("spawn cwd {cwd:?}: no such directory"),
                    ));
                }
            }
            let mut command = Command::new(&spec.program);
            command.args(&spec.argv);
            for (key, value) in &spec.env {
                command.env(key, value);
            }
            // The child owns nothing of the daemon's: no inherited stdio, so a forgotten
            // child cannot hold a client's socket open by accident.
            command
                .stdin(Stdio::null())
                .stdout(Stdio::null())
                .stderr(Stdio::null());
            if let Some(cwd) = cwd.as_deref() {
                command.current_dir(cwd);
            }
            let child = command.spawn().map_err(|error| {
                if error.kind() == std::io::ErrorKind::NotFound {
                    IoFault::new(
                        IoFaultKind::NotFound,
                        format!("spawn {}: the host has no such program", spec.program),
                    )
                } else if error.kind() == std::io::ErrorKind::PermissionDenied {
                    IoFault::new(
                        IoFaultKind::PermissionDenied,
                        format!("spawn {}: permission denied", spec.program),
                    )
                } else {
                    IoFault::new(
                        IoFaultKind::InternalIo,
                        format!("spawn {}: {error}", spec.program),
                    )
                }
            })?;
            let pid = child.id();
            let sequence = SPAWN_SEQUENCE.fetch_add(1, Ordering::SeqCst);
            // The nonce distinguishes *instances*, not identities: the host recycles pids,
            // so the pair (spawn ordinal, pid) is the honest label — and now also the
            // supervision key: the registry keeps the `Child` so poll and stop reach the
            // real process, and the exit is reaped here rather than by init.
            let instance_nonce = format!("spawn-{sequence}-pid-{pid}");
            self.children
                .lock()
                .map_err(|_| IoFault::new(IoFaultKind::InternalIo, "proc registry lock poisoned"))?
                .insert(instance_nonce.clone(), Arc::new(Mutex::new(child)));
            Ok(ChildHandle {
                pid,
                instance_nonce,
            })
        })
    }

    fn try_wait<'a>(
        &'a self,
        handle: &'a ChildHandle,
    ) -> BoxFuture<'a, Result<Option<ChildExit>, IoFault>> {
        Box::pin(async move {
            let child = self.child_by_nonce(&handle.instance_nonce)?;
            let mut guard = child
                .lock()
                .map_err(|_| IoFault::new(IoFaultKind::InternalIo, "child lock poisoned"))?;
            // `try_wait` both polls and reaps: once it answers `Some`, the kernel has
            // released the process and later calls replay the recorded status — which is
            // the monotonicity the port promises.
            guard
                .try_wait()
                .map(|status| status.map(exit_from_status))
                .map_err(|error| {
                    IoFault::new(
                        IoFaultKind::InternalIo,
                        format!("wait pid {}: {error}", handle.pid),
                    )
                })
        })
    }

    fn stop<'a>(
        &'a self,
        handle: &'a ChildHandle,
        grace_ms: u64,
    ) -> BoxFuture<'a, Result<ChildExit, IoFault>> {
        Box::pin(async move {
            let child = self.child_by_nonce(&handle.instance_nonce)?;
            // The grace window belongs to the child: it may exit by itself (a core flushing
            // state), and every poll in that window also reaps it the moment it does.
            let deadline = Instant::now() + Duration::from_millis(grace_ms);
            loop {
                let mut guard = child
                    .lock()
                    .map_err(|_| IoFault::new(IoFaultKind::InternalIo, "child lock poisoned"))?;
                if let Some(status) = guard.try_wait().map_err(|error| {
                    IoFault::new(
                        IoFaultKind::InternalIo,
                        format!("wait pid {}: {error}", handle.pid),
                    )
                })? {
                    return Ok(exit_from_status(status));
                }
                if Instant::now() >= deadline {
                    // std's only signal is SIGKILL; a graceful TERM surface is future port
                    // growth (`ADR-043` keeps that line explicit rather than implied).
                    guard.kill().map_err(|error| {
                        IoFault::new(
                            IoFaultKind::InternalIo,
                            format!("kill pid {}: {error}", handle.pid),
                        )
                    })?;
                    let status = guard.wait().map_err(|error| {
                        IoFault::new(
                            IoFaultKind::InternalIo,
                            format!("reap pid {}: {error}", handle.pid),
                        )
                    })?;
                    return Ok(exit_from_status(status));
                }
                drop(guard);
                std::thread::sleep(Duration::from_millis(STOP_POLL_MS));
            }
        })
    }
}

/// The whole truth a unix wait status carries (`ADR-043`): the number, and whether the child
/// chose it or a signal chose it for the child.
fn exit_from_status(status: std::process::ExitStatus) -> ChildExit {
    #[cfg(unix)]
    {
        use std::os::unix::process::ExitStatusExt;
        if let Some(signal) = status.signal() {
            return ChildExit {
                code: signal,
                signaled: true,
            };
        }
        ChildExit {
            code: status.code().unwrap_or(0),
            signaled: false,
        }
    }
    #[cfg(not(unix))]
    {
        ChildExit {
            code: status.code().unwrap_or(0),
            signaled: false,
        }
    }
}
