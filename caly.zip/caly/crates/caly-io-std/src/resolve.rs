//! Bounded DNS resolution — `ADR-052` addendum §7: the LAST unbounded blocking call on the
//! source chain, bounded.
//!
//! `ADR-052` bounded `connect`/`read`/`write` by the caller's remaining time (socket
//! timeouts), but `getaddrinfo` — `to_socket_addrs` — is the one std blocking call with
//! **no timeout parameter**: `StdHttp` could only check the boundary *before* entering it,
//! so a hung resolver could park a fetch past any caller deadline. This module gives that
//! call the same honest treatment, with the same honesty about what cannot be done:
//!
//! * getaddrinfo **cannot be interrupted**. It therefore never runs on the caller's
//!   thread: ONE lazily-spawned shared resolver thread runs it, and the caller waits for
//!   the answer with `recv_timeout(budget)` — the caller's deadline is enforced *outside*
//!   the syscall, never pretended inside it.
//! * the liability is **exactly one thread**, forever (observable via
//!   [`resolver_thread_count`]). A hung lookup blocks the queue — head-of-line blocking is
//!   the honest price of not spawning a thread per fetch; later lookups fail at their own
//!   deadlines, by name, until the resolver returns.
//! * reclaim is explicit: a late answer to a caller that already timed out finds a dropped
//!   receiver and is discarded; the thread keeps serving the next request. Nothing from a
//!   timed-out lookup survives into another caller's answer.

use std::io;
use std::net::{SocketAddr, ToSocketAddrs};
use std::sync::atomic::{AtomicUsize, Ordering};
use std::sync::mpsc::{self, RecvTimeoutError};
use std::sync::OnceLock;
use std::thread;
use std::time::Duration;

use caly_io::{IoFault, IoFaultKind};

type BoxedResolve = Box<dyn Fn(&str, u16) -> io::Result<Vec<SocketAddr>> + Send>;
type Request = (
    String,
    u16,
    BoxedResolve,
    mpsc::Sender<io::Result<Vec<SocketAddr>>>,
);

static RESOLVER: OnceLock<Option<mpsc::Sender<Request>>> = OnceLock::new();
static RESOLVER_THREADS: AtomicUsize = AtomicUsize::new(0);

fn system_resolve(host: &str, port: u16) -> io::Result<Vec<SocketAddr>> {
    (host, port)
        .to_socket_addrs()
        .map(|addrs| addrs.collect::<Vec<_>>())
}

fn worker(requests: mpsc::Receiver<Request>) {
    for (host, port, resolve, reply) in requests {
        let answer = resolve(&host, port);
        // A late answer to a caller that already timed out finds a dropped receiver: the
        // send fails and the answer is discarded — the reclaim half of the contract.
        let _ = reply.send(answer);
    }
}

/// Round 133 (`R131-F2`): a spawn failure (thread/fd budget exhausted) is a REFUSAL by
/// name, not a panic through an innocent caller — this used to be the honest-refusal io
/// surface's only panic exit. Fail-closed-once: the singleton remembers the failure and
/// every later resolve refuses fast; remediation is freeing the budget and restarting the
/// process (a per-call retry loop under exhaustion would just churn).
fn sender(host: &str) -> Result<&'static mpsc::Sender<Request>, IoFault> {
    let cell = RESOLVER.get_or_init(|| {
        let (sender, receiver) = mpsc::channel::<Request>();
        match thread::Builder::new()
            .name("caly-bounded-resolver".to_owned())
            .spawn(move || worker(receiver))
        {
            Ok(_join_handle) => {
                RESOLVER_THREADS.fetch_add(1, Ordering::Relaxed);
                Some(sender)
            }
            Err(_) => None,
        }
    });
    cell.as_ref().ok_or_else(|| spawn_refused(host))
}

fn spawn_refused(host: &str) -> IoFault {
    IoFault::new(
        IoFaultKind::Unavailable,
        format!(
            "DNS resolution of {host:?} refused: the shared resolver thread could not be \
             spawned (thread/resource budget exhausted); resolution stays refused until the \
             process restarts (ADR-052 §7: the liability is one thread — if even that cannot \
             exist, the honest answer is a named refusal, not a panic)"
        ),
    )
}

/// Test seam for the spawn-failure path (round 133, `R131-F2`): pre-set the singleton as a
/// failed spawn WITHOUT spawning, so a dedicated test binary can prove the refusal. The seam
/// is public for the same reason `bounded_resolve_with` is — the failure path is only
/// reachable with an injection, and a judge that cannot reach it is decoration. Returns
/// whether the seam won the singleton race (a dedicated process always wins).
pub fn resolver_spawn_is_broken_for_tests() -> bool {
    RESOLVER.set(None).is_ok()
}

/// How many resolver threads this process ever spawned — the bounded-liability proof: one,
/// lazily, and never more (`ADR-052 §7`). Exposed because "one shared thread" is a
/// contract, not an implementation detail a per-call spawn could quietly honour in spirit.
pub fn resolver_thread_count() -> usize {
    RESOLVER_THREADS.load(Ordering::Relaxed)
}

fn refused_deadline(host: &str) -> IoFault {
    IoFault::new(
        IoFaultKind::Timeout,
        format!(
            "DNS resolution of {host:?} refused: the caller's deadline is already spent \
             (ADR-052 §7: getaddrinfo cannot be interrupted, so it is never entered)"
        ),
    )
}

fn not_answered(host: &str, budget: Duration) -> IoFault {
    IoFault::new(
        IoFaultKind::Timeout,
        format!(
            "DNS resolution of {host:?} did not answer within the caller's remaining {} ms \
             (ADR-052 §7: one shared resolver thread runs getaddrinfo; a hung lookup blocks \
             the queue and later lookups fail at their own deadlines until it returns)",
            budget.as_millis(),
        ),
    )
}

/// Resolve through a caller-supplied resolver on the shared bounded thread. The injection
/// seam is public because the judges must be able to hand the thread a hanging or slow
/// getaddrinfo — the honest-boundary behaviours this module exists for are only reachable
/// with a resolver that misbehaves on demand.
pub fn bounded_resolve_with(
    resolve: impl Fn(&str, u16) -> io::Result<Vec<SocketAddr>> + Send + 'static,
    host: &str,
    port: u16,
    budget: Duration,
) -> Result<SocketAddr, IoFault> {
    if budget.is_zero() {
        return Err(refused_deadline(host));
    }
    let (reply_sender, reply_receiver) = mpsc::channel();
    let request: Request = (host.to_owned(), port, Box::new(resolve), reply_sender);
    if sender(host)?.send(request).is_err() {
        return Err(IoFault::new(
            IoFaultKind::Unavailable,
            "the bounded resolver thread is gone; DNS resolution is unavailable on this \
             adapter"
                .to_owned(),
        ));
    }
    match reply_receiver.recv_timeout(budget) {
        Ok(Ok(addrs)) => addrs.into_iter().next().ok_or_else(|| {
            IoFault::new(
                IoFaultKind::Unavailable,
                format!("resolve {host}: no address"),
            )
        }),
        Ok(Err(error)) => Err(IoFault::new(
            IoFaultKind::Unavailable,
            format!("resolve {host}: {error}"),
        )),
        Err(RecvTimeoutError::Timeout) => Err(not_answered(host, budget)),
        Err(RecvTimeoutError::Disconnected) => Err(IoFault::new(
            IoFaultKind::Unavailable,
            format!("resolve {host}: the resolver thread stopped before answering"),
        )),
    }
}

/// Resolve `host:port` through the real system resolver, bounded by the caller's remaining
/// time. `budget` is expected to be the `min(peer DNS timeout, caller remaining)` the HTTP
/// adapter's `CallerControl` computes — the same rule every other blocking syscall on the
/// source chain already follows (`ADR-052 §2`).
pub fn bounded_resolve(host: &str, port: u16, budget: Duration) -> Result<SocketAddr, IoFault> {
    bounded_resolve_with(system_resolve, host, port, budget)
}
