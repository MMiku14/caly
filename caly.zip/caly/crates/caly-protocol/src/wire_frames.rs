//! JSON wire envelopes for the v2 local control plane.
//!
//! The wire DTOs in `protocol/v2` are transported directly as compact JSON.
//! A request frame carries an optional 32-hex-char session token; a response
//! frame is either a typed result or a structured error with a stable code.
//! Watch events stream as repeated `WatchEvent` result frames on a dedicated
//! connection until the peer disconnects.

use super::protocol::v2::{
    CancelOperationRequest, CancelOperationResponse, ExecuteBatchRequest, ExecuteBatchResponse,
    ExecuteRequest, ExecuteResponse, ExecuteSyncRequest, ExecuteSyncResponse,
    GetLiveConnectionsRequest, GetOperationStatusRequest, GetSnapshotRequest, HandshakeRequest,
    HandshakeResponse, LiveConnectionsResponse, OperationListResponse, WatchEventsRequest,
    WatchResponse, WireOperationStatus, WirePresentationSnapshot,
};

/// Every daemon method, one discriminant per frame.
#[derive(Clone, Debug, Eq, PartialEq, serde::Serialize, serde::Deserialize)]
#[serde(rename_all = "snake_case")]
pub enum JsonRequest {
    Handshake(HandshakeRequest),
    Execute(ExecuteRequest),
    ExecuteSync(ExecuteSyncRequest),
    ExecuteBatch(ExecuteBatchRequest),
    CancelOperation(CancelOperationRequest),
    GetOperationStatus(GetOperationStatusRequest),
    GetSnapshot(GetSnapshotRequest),
    GetLiveConnections(GetLiveConnectionsRequest),
    ListOperations,
    WatchEvents(WatchEventsRequest),
}

/// Typed daemon reply, mirroring `JsonRequest` one-to-one.
#[derive(Clone, Debug, Eq, PartialEq, serde::Serialize, serde::Deserialize)]
#[serde(rename_all = "snake_case")]
pub enum JsonResponse {
    Handshake(HandshakeResponse),
    Execute(ExecuteResponse),
    ExecuteSync(ExecuteSyncResponse),
    ExecuteBatch(ExecuteBatchResponse),
    CancelOperation(CancelOperationResponse),
    GetOperationStatus(WireOperationStatus),
    GetSnapshot(WirePresentationSnapshot),
    GetLiveConnections(LiveConnectionsResponse),
    ListOperations(OperationListResponse),
    WatchEvent(WatchResponse),
}

/// Client-to-daemon envelope: optional session token plus one request.
#[derive(Clone, Debug, Eq, PartialEq, serde::Serialize, serde::Deserialize)]
pub struct ClientFrame {
    /// 32-hex-char session token; absent only for the handshake.
    #[serde(skip_serializing_if = "Option::is_none")]
    pub session: Option<String>,
    pub request: JsonRequest,
}

/// Daemon-to-client envelope: exactly one result or one structured error.
#[derive(Clone, Debug, Eq, PartialEq, serde::Serialize, serde::Deserialize)]
pub enum ServerFrame {
    /// Typed success payload; boxed to keep the frame small on the stack.
    Result(Box<JsonResponse>),
    Error(WireError),
}

/// Structured transport error with a stable numeric code.
#[derive(Clone, Debug, Eq, PartialEq, serde::Serialize, serde::Deserialize)]
pub struct WireError {
    pub code: u32,
    /// Optional stable error domain (`core.lifecycle`, `proxy.mode`, …).
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub domain: Option<String>,
    pub message: String,
    pub suggested_action: Option<String>,
}

/// Stable wire error discriminants shared by daemon and thin clients.
#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub enum WireErrorCode {
    Unauthenticated,
    PermissionDenied,
    ResourceExhausted,
    InvalidArgument,
    IncompatibleVersion,
    HandshakeRequired,
    ApplicationUnavailable,
}

impl WireErrorCode {
    /// Numeric wire representation.
    pub const fn code(self) -> u32 {
        match self {
            Self::Unauthenticated => 1,
            Self::PermissionDenied => 2,
            Self::ResourceExhausted => 3,
            Self::InvalidArgument => 4,
            Self::IncompatibleVersion => 5,
            Self::HandshakeRequired => 6,
            Self::ApplicationUnavailable => 7,
        }
    }

    /// Strict numeric decode; unknown values are rejected.
    pub const fn from_code(value: u32) -> Option<Self> {
        match value {
            1 => Some(Self::Unauthenticated),
            2 => Some(Self::PermissionDenied),
            3 => Some(Self::ResourceExhausted),
            4 => Some(Self::InvalidArgument),
            5 => Some(Self::IncompatibleVersion),
            6 => Some(Self::HandshakeRequired),
            7 => Some(Self::ApplicationUnavailable),
            _ => None,
        }
    }
}

/// Builds a structured wire error from a known discriminant.
pub fn wire_error(code: WireErrorCode, message: impl Into<String>) -> WireError {
    wire_error_with_domain(code, None, message)
}

/// Builds a structured wire error with a stable domain for client branching.
pub fn wire_error_with_domain(
    code: WireErrorCode,
    domain: impl Into<Option<String>>,
    message: impl Into<String>,
) -> WireError {
    WireError {
        code: code.code(),
        domain: domain.into(),
        message: message.into(),
        suggested_action: None,
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::protocol::v2::{DecodeLimits, FeatureList, ProtocolVersion};

    #[test]
    fn request_frames_round_trip_without_session() -> Result<(), String> {
        let frame = ClientFrame {
            session: None,
            request: JsonRequest::Handshake(HandshakeRequest {
                client_version: ProtocolVersion::V2_0,
                auth_token: None,
                requested_features: FeatureList::new(),
            }),
        };
        let json = serde_json::to_string(&frame).map_err(|e| e.to_string())?;
        assert!(
            !json.contains("session"),
            "absent session must not be serialized"
        );
        let back: ClientFrame = serde_json::from_str(&json).map_err(|e| e.to_string())?;
        assert_eq!(frame, back);
        Ok(())
    }

    #[test]
    fn request_frames_carry_hex_session_token() -> Result<(), String> {
        let frame = ClientFrame {
            session: Some("0102030405060708090a0b0c0d0e0f10".to_owned()),
            request: JsonRequest::GetSnapshot(GetSnapshotRequest),
        };
        let json = serde_json::to_string(&frame).map_err(|e| e.to_string())?;
        assert!(json.contains("\"session\":\"0102030405060708090a0b0c0d0e0f10\""));
        let back: ClientFrame = serde_json::from_str(&json).map_err(|e| e.to_string())?;
        assert_eq!(frame, back);
        Ok(())
    }

    #[test]
    fn error_frames_round_trip_with_known_code() -> Result<(), String> {
        let frame = ServerFrame::Error(wire_error(
            WireErrorCode::ResourceExhausted,
            "bounded resource exhausted",
        ));
        let json = serde_json::to_string(&frame).map_err(|e| e.to_string())?;
        let back: ServerFrame = serde_json::from_str(&json).map_err(|e| e.to_string())?;
        assert_eq!(frame, back);
        assert_eq!(
            WireErrorCode::from_code(3),
            Some(WireErrorCode::ResourceExhausted)
        );
        assert_eq!(WireErrorCode::from_code(999), None);
        Ok(())
    }

    #[test]
    fn snapshot_round_trips_through_json() -> Result<(), String> {
        let snapshot = WirePresentationSnapshot {
            daemon_instance_id: [7; 16],
            revision: 3,
            cursor: crate::protocol::v2::WireEventCursor {
                daemon_instance_id: [8; 16],
                sequence: 11,
            },
            desired: crate::protocol::v2::WireDesiredState {
                mode: 1,
                selected_node_id: Some([9; 16]),
                active_subscription_id: None,
                tun_requested: false,
                system_proxy_requested: false,
            },
            applied: crate::protocol::v2::WireAppliedState {
                core_kind: Some(1),
                run_state: 3,
                selected_node_id: None,
                config_generation: None,
            },
            observed: crate::protocol::v2::WireObservedState {
                upload_bytes_per_second: 0,
                download_bytes_per_second: 0,
                active_connections: 0,
                telemetry_dropped: 0,
                core_restart_count: 0,
                core_restart_backoff_ms: 0,
            },
            platform: crate::protocol::v2::WirePlatformEffect {
                proxy_engaged: false,
                tun_engaged: false,
                recovery_pending: false,
                degraded_reason: None,
            },
            capabilities: caly_domain::BoundedVec::new(),
            nodes: caly_domain::BoundedVec::new(),
            proxy_groups: caly_domain::BoundedVec::new(),
            sources: caly_domain::BoundedVec::new(),
        };
        let json = serde_json::to_string(&snapshot).map_err(|e| e.to_string())?;
        let back: WirePresentationSnapshot =
            serde_json::from_str(&json).map_err(|e| e.to_string())?;
        assert_eq!(snapshot, back);
        Ok(())
    }

    #[test]
    fn operation_list_response_round_trips_through_json() -> Result<(), String> {
        use crate::protocol::v2::{OperationListResponse, RawOperationState, WireOperationStatus};
        let list = OperationListResponse {
            operations: caly_domain::BoundedVec::try_from_vec(vec![WireOperationStatus {
                operation_id: [7; 16],
                command_kind: "config.mutate".to_owned(),
                created_at_unix_ms: 1,
                updated_at_unix_ms: 2,
                state: RawOperationState(1),
                failure: None,
            }])
            .map_err(|e| e.to_string())?,
        };
        let json = serde_json::to_string(&list).map_err(|e| e.to_string())?;
        let back: OperationListResponse = serde_json::from_str(&json).map_err(|e| e.to_string())?;
        assert_eq!(list, back);
        Ok(())
    }

    #[test]
    fn execute_sync_request_round_trips_with_defaulted_poll() -> Result<(), String> {
        let frame = ClientFrame {
            session: Some("0102030405060708090a0b0c0d0e0f10".to_owned()),
            request: JsonRequest::ExecuteSync(crate::protocol::v2::ExecuteSyncRequest {
                command: crate::protocol::v2::WireCommand::SetMode { mode: 2 },
                timeout_ms: 5_000,
                poll_interval_ms: 100,
            }),
        };
        let json = serde_json::to_string(&frame).map_err(|e| e.to_string())?;
        assert!(json.contains("\"execute_sync\""));
        let back: ClientFrame = serde_json::from_str(&json).map_err(|e| e.to_string())?;
        assert_eq!(frame, back);
        Ok(())
    }

    #[test]
    fn batch_request_round_trips_through_json() -> Result<(), String> {
        let operations =
            caly_domain::BoundedVec::try_from_vec(vec![crate::protocol::v2::ExecuteRequest {
                operation_id: [7; 16],
                command: crate::protocol::v2::WireCommand::ReloadConfig,
            }])
            .map_err(|e| e.to_string())?;
        let frame = ClientFrame {
            session: Some("0102030405060708090a0b0c0d0e0f10".to_owned()),
            request: JsonRequest::ExecuteBatch(crate::protocol::v2::ExecuteBatchRequest {
                operations,
                stop_on_error: false,
            }),
        };
        let json = serde_json::to_string(&frame).map_err(|e| e.to_string())?;
        assert!(json.contains("\"execute_batch\""));
        let back: ClientFrame = serde_json::from_str(&json).map_err(|e| e.to_string())?;
        assert_eq!(frame, back);
        Ok(())
    }

    #[test]
    fn error_frames_round_trip_with_domain() -> Result<(), String> {
        let frame = ServerFrame::Error(wire_error_with_domain(
            WireErrorCode::InvalidArgument,
            Some("core.lifecycle".to_owned()),
            "xray is not supported",
        ));
        let json = serde_json::to_string(&frame).map_err(|e| e.to_string())?;
        assert!(json.contains("\"domain\":\"core.lifecycle\""));
        let back: ServerFrame = serde_json::from_str(&json).map_err(|e| e.to_string())?;
        assert_eq!(frame, back);
        Ok(())
    }

    #[test]
    fn watch_request_round_trips_with_event_filter() -> Result<(), String> {
        let frame = ClientFrame {
            session: Some("0102030405060708090a0b0c0d0e0f10".to_owned()),
            request: JsonRequest::WatchEvents(crate::protocol::v2::WatchEventsRequest {
                after: None,
                filter: Some(vec![
                    "AppliedReplaced".to_owned(),
                    "NodesReplaced".to_owned(),
                ]),
            }),
        };
        let json = serde_json::to_string(&frame).map_err(|e| e.to_string())?;
        assert!(json.contains("\"filter\":[\"AppliedReplaced\",\"NodesReplaced\"]"));
        let back: ClientFrame = serde_json::from_str(&json).map_err(|e| e.to_string())?;
        assert_eq!(frame, back);
        Ok(())
    }

    #[test]
    fn decode_limits_negotiate_round_trip() -> Result<(), String> {
        let limits = DecodeLimits::v2_default();
        let json = serde_json::to_string(&limits).map_err(|e| e.to_string())?;
        let back: DecodeLimits = serde_json::from_str(&json).map_err(|e| e.to_string())?;
        assert_eq!(limits, back);
        Ok(())
    }
}
