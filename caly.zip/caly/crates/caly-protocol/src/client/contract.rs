//! Runtime-neutral thin-client contract.

use crate::protocol::v2::{
    CancelOperationRequest, CancelOperationResponse, ExecuteBatchRequest, ExecuteBatchResponse,
    ExecuteRequest, ExecuteResponse, ExecuteSyncRequest, ExecuteSyncResponse,
    GetLiveConnectionsRequest, GetOperationStatusRequest, HandshakeRequest, HandshakeResponse,
    LiveConnectionsResponse, OperationListResponse, WatchEventsRequest, WatchResponse,
    WireOperationStatus, WirePresentationSnapshot,
};

/// Errors exposed by a concrete protocol client implementation.
#[derive(Clone, Debug, Eq, PartialEq)]
pub enum ClientError {
    TransportUnavailable { reason: String },
    DeadlineExceeded,
    IncompatibleVersion,
    AuthenticationRejected,
    ResourceExhausted,
    DecodeRejected {
        reason: String,
        suggested_action: String,
    },
}

impl From<std::io::Error> for ClientError {
    /// Keeps the OS cause and adds a kind-aware hint: a missing socket
    /// almost always means the daemon is not running, while a refusal
    /// mid-handshake means it went away.
    fn from(error: std::io::Error) -> Self {
        let reason = match error.kind() {
            std::io::ErrorKind::NotFound => {
                format!("socket not found ({error}); is the daemon running?")
            }
            std::io::ErrorKind::ConnectionRefused => {
                format!("connection refused ({error}); is the daemon still running?")
            }
            std::io::ErrorKind::PermissionDenied => {
                format!("permission denied ({error}); the socket belongs to another user")
            }
            std::io::ErrorKind::TimedOut => format!("connection timed out ({error})"),
            _ => error.to_string(),
        };
        Self::TransportUnavailable { reason }
    }
}

impl core::fmt::Display for ClientError {
    fn fmt(&self, formatter: &mut core::fmt::Formatter<'_>) -> core::fmt::Result {
        match self {
            Self::TransportUnavailable { reason } => {
                write!(formatter, "transport unavailable: {reason}")
            }
            Self::DeadlineExceeded => write!(formatter, "operation deadline exceeded"),
            Self::IncompatibleVersion => write!(formatter, "incompatible protocol version"),
            Self::AuthenticationRejected => write!(formatter, "authentication rejected"),
            Self::ResourceExhausted => write!(formatter, "daemon resource exhausted"),
            Self::DecodeRejected { reason, .. } => write!(formatter, "decode rejected: {reason}"),
        }
    }
}

impl std::error::Error for ClientError {}

/// Transport-neutral request surface implemented later by local/remote clients.
///
/// This trait intentionally contains no async-runtime type in its signature.
pub trait ClientContract {
    /// Owned bounded/recoverable watch stream selected by an implementation.
    type Watch: Iterator<Item = Result<WatchResponse, ClientError>>;

    fn handshake(&mut self, request: HandshakeRequest) -> Result<HandshakeResponse, ClientError>;
    fn execute(&mut self, request: ExecuteRequest) -> Result<ExecuteResponse, ClientError>;
    /// Server-side execute + poll: one request carries the command and the
    /// client receives the last observed operation status once the operation
    /// reaches a terminal state or the bounded timeout expires.
    fn execute_sync(
        &mut self,
        request: ExecuteSyncRequest,
    ) -> Result<ExecuteSyncResponse, ClientError>;
    /// Sequential batch admission. `stop_on_error` stops before later items
    /// when an earlier item is rejected.
    fn execute_batch(
        &mut self,
        request: ExecuteBatchRequest,
    ) -> Result<ExecuteBatchResponse, ClientError>;
    fn cancel(
        &mut self,
        request: CancelOperationRequest,
    ) -> Result<CancelOperationResponse, ClientError>;
    fn operation_status(
        &mut self,
        request: GetOperationStatusRequest,
    ) -> Result<WireOperationStatus, ClientError>;
    fn snapshot(&mut self) -> Result<WirePresentationSnapshot, ClientError>;
    /// Reads the bounded live connection-detail slice mediated by the daemon.
    fn live_connections(
        &mut self,
        request: GetLiveConnectionsRequest,
    ) -> Result<LiveConnectionsResponse, ClientError>;
    /// Reads the bounded recent-operation dashboard (active + terminal),
    /// intended for TUI/WebUI operation views.
    fn list_operations(&mut self) -> Result<OperationListResponse, ClientError>;
    fn watch(&mut self, request: WatchEventsRequest) -> Result<Self::Watch, ClientError>;
}

#[cfg(test)]
mod tests {
    use super::*;

    /// The io-error chain must keep the OS cause: a missing socket
    /// means "daemon not running" and must say so.
    #[test]
    fn io_error_keeps_kind_aware_reason() {
        let missing = ClientError::from(std::io::Error::new(
            std::io::ErrorKind::NotFound,
            "no such file",
        ));
        let rendered = missing.to_string();
        assert!(rendered.contains("socket not found"), "{rendered}");
        assert!(rendered.contains("is the daemon running"), "{rendered}");

        let refused = ClientError::from(std::io::Error::new(
            std::io::ErrorKind::ConnectionRefused,
            "refused",
        ));
        assert!(refused.to_string().contains("connection refused"));
    }
}
