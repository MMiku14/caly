use super::{UdsClient, map_wire_error};
use crate::client::{ClientContract, ClientError};
use crate::framing::encode_json;
use crate::protocol::v2::{DecodeLimits, HandshakeRequest, HandshakeResponse};
use crate::wire_frames::{JsonResponse, ServerFrame, WireError, WireErrorCode};
use std::path::PathBuf;

/// Spins up a one-shot in-process UDS peer answering a single request
/// frame with a handshake response carrying the given negotiated limits;
/// returns the socket path and the server thread handle.
fn stub_handshake_server(limits: DecodeLimits) -> (PathBuf, std::thread::JoinHandle<()>) {
    use std::io::{Read as _, Write as _};
    let unique = format!(
        "caly-proto-uds-test-{}-{}",
        std::process::id(),
        std::time::SystemTime::now()
            .duration_since(std::time::UNIX_EPOCH)
            .map_or(0, |duration| duration.as_nanos()),
    );
    let path = std::env::temp_dir().join(unique);
    let listener = std::os::unix::net::UnixListener::bind(&path)
        .unwrap_or_else(|error| panic!("bind test socket: {error}"));
    let server = std::thread::spawn(move || {
        let (mut stream, _) = listener
            .accept()
            .unwrap_or_else(|error| panic!("accept test client: {error}"));
        let mut header = [0_u8; 4];
        stream
            .read_exact(&mut header)
            .unwrap_or_else(|error| panic!("read request header: {error}"));
        let length = u32::from_le_bytes(header) as usize;
        let mut payload = vec![0_u8; length];
        stream
            .read_exact(&mut payload)
            .unwrap_or_else(|error| panic!("read request payload: {error}"));
        let response = ServerFrame::Result(Box::new(JsonResponse::Handshake(HandshakeResponse {
            negotiated_version: crate::protocol::v2::ProtocolVersion { major: 2, minor: 0 },
            daemon_instance_id: [7_u8; 16],
            enabled_features: crate::protocol::v2::all_features(),
            unknown_requested_features: crate::protocol::v2::FeatureList::new(),
            limits,
            session_token: [9_u8; 16],
        })));
        let bytes = encode_json(&response)
            .unwrap_or_else(|error| panic!("encode handshake response: {error}"));
        let length = u32::try_from(bytes.len())
            .unwrap_or_else(|error| panic!("response length overflow: {error}"));
        stream
            .write_all(&length.to_le_bytes())
            .and_then(|()| stream.write_all(&bytes))
            .unwrap_or_else(|error| panic!("write handshake response: {error}"));
    });
    (path, server)
}

#[test]
fn handshake_adopts_the_negotiated_message_ceiling() {
    let tightened = DecodeLimits {
        max_message_bytes: 4_096,
        ..DecodeLimits::v2_default()
    };
    let (path, server) = stub_handshake_server(tightened);
    let mut client = UdsClient::connect(path.clone())
        .unwrap_or_else(|error| panic!("connect stub server: {error}"));
    assert_eq!(
        client.message_ceiling,
        DecodeLimits::v2_default().max_message_bytes,
        "pre-handshake ceiling is the conservative v2 default",
    );
    client
        .handshake(HandshakeRequest {
            client_version: crate::protocol::v2::ProtocolVersion { major: 2, minor: 0 },
            requested_features: crate::protocol::v2::all_features(),
            auth_token: None,
        })
        .unwrap_or_else(|error| panic!("handshake: {error}"));
    assert_eq!(
        client.message_ceiling, tightened.max_message_bytes,
        "handshake must tighten the read ceiling to the negotiated limit (#96)",
    );
    server
        .join()
        .unwrap_or_else(|payload| panic!("stub server panicked: {payload:?}"));
    let _ = std::fs::remove_file(&path);
}

#[test]
fn wire_error_codes_map_to_client_errors() {
    let unauthenticated = map_wire_error(WireError {
        code: WireErrorCode::Unauthenticated.code(),
        domain: None,
        message: "token rejected".to_owned(),
        suggested_action: None,
    });
    assert_eq!(unauthenticated, ClientError::AuthenticationRejected);
    let exhausted = map_wire_error(WireError {
        code: WireErrorCode::ResourceExhausted.code(),
        domain: None,
        message: "full".to_owned(),
        suggested_action: None,
    });
    assert_eq!(exhausted, ClientError::ResourceExhausted);
    let version = map_wire_error(WireError {
        code: WireErrorCode::IncompatibleVersion.code(),
        domain: None,
        message: "old".to_owned(),
        suggested_action: None,
    });
    assert_eq!(version, ClientError::IncompatibleVersion);
    let invalid = map_wire_error(WireError {
        code: WireErrorCode::InvalidArgument.code(),
        domain: None,
        message: "bad command".to_owned(),
        suggested_action: Some("fix the command".to_owned()),
    });
    assert!(matches!(invalid, ClientError::DecodeRejected { .. }));
    let unknown = map_wire_error(WireError {
        code: 999,
        domain: None,
        message: "?".to_owned(),
        suggested_action: None,
    });
    assert!(matches!(unknown, ClientError::DecodeRejected { .. }));
}
