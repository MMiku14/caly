//! Tests for [`super::encode`]: wire-clamping discipline plus the
//! encode/decode table roundtrips (extracted sibling: the module plus its
//! locks exceed the file-length budget).

use super::encode::*;
use crate::conversion::{capabilities_from_wire, operation_status_from_wire};
use crate::protocol::v2::{
    DecodeBudget, DecodeLimits, MAX_WIRE_CONNECTION_CHAIN, MAX_WIRE_CONNECTION_TEXT_BYTES,
    MAX_WIRE_PROXY_GROUPS, MAX_WIRE_SOURCES, RawFailureCode, RawOperationState,
    WireCapabilityStatus,
};
use caly_domain::{
    AppliedState, BoundedText, BoundedVec, Capability, CapabilitySet, CapabilityStatus,
    ConfiguredSupport, DesiredState, LiveConnection, ObservedState, OperationFailure,
    OperationFailureCode, OperationId, OperationState, OperationStatus, PlatformEffectView,
    ProxyGroupView, ProxyMode, RuntimeAvailability, SourceView, UnixMillis,
};

fn source(name: &str) -> SourceView {
    SourceView {
        index: 1,
        name: name.to_owned(),
        kind: "subscription".to_owned(),
        url: "https://example.com/sub".to_owned(),
        enabled: true,
        nodes: 7,
        groups: vec!["select".to_owned()],
        last_refresh_unix: Some(1_700_000_000),
        next_refresh_unix: None,
        cached: true,
    }
}

fn connection(id: &str) -> LiveConnection {
    LiveConnection {
        id: id.to_owned(),
        host: "example.com".to_owned(),
        destination_port: 443,
        network: "tcp".to_owned(),
        protocol_type: "tls".to_owned(),
        inbound_name: "mixed".to_owned(),
        process_path: String::new(),
        rule: "MATCH".to_owned(),
        rule_payload: String::new(),
        outbound: "PROXY".to_owned(),
        chain: vec!["PROXY".to_owned()],
        upload_bytes: 10,
        download_bytes: 20,
    }
}

#[test]
fn sources_empty_fields_fall_back() {
    let mut view = source("");
    view.kind = String::new();
    view.url = String::new();
    let wire = sources_to_wire(core::slice::from_ref(&view));
    assert_eq!(wire.len(), 1);
    let row = wire.iter().next().unwrap();
    assert_eq!(row.index, 1);
    assert_eq!(row.name.as_str(), "#");
    assert_eq!(row.kind.as_str(), "subscription");
    assert_eq!(row.url.as_str(), "file://invalid");
    assert_eq!(row.nodes, 7);
    assert!(row.enabled);
}

#[test]
fn sources_overlong_name_truncates_to_wire_bound() {
    let wire = sources_to_wire(core::slice::from_ref(&source(&"x".repeat(100))));
    let row = wire.iter().next().unwrap();
    assert_eq!(row.name.as_str().len(), 64);
}

#[test]
fn sources_extra_entries_and_groups_truncate() {
    let views: Vec<SourceView> = (0..300).map(|_| source("n")).collect();
    assert_eq!(sources_to_wire(&views).len(), MAX_WIRE_SOURCES);
    let mut view = source("n");
    view.groups = (0..70).map(|i| format!("g{i}")).collect();
    let wire = sources_to_wire(core::slice::from_ref(&view));
    assert_eq!(wire.iter().next().unwrap().groups.len(), 64);
}

#[test]
fn connections_fall_back_clamp_and_truncate_chain() {
    let mut view = connection("");
    view.host = "h".repeat(2_000);
    view.chain = (0..40).map(|i| format!("g{i}")).collect();
    let response = live_connections_to_wire(core::slice::from_ref(&view));
    assert_eq!(response.connections.len(), 1);
    let row = response.connections.iter().next().unwrap();
    assert_eq!(row.id, "--");
    assert_eq!(row.host.len(), MAX_WIRE_CONNECTION_TEXT_BYTES);
    assert_eq!(row.chain.len(), MAX_WIRE_CONNECTION_CHAIN);
    assert_eq!(row.destination_port, 443);
    assert_eq!(row.upload_bytes, 10);
}

#[test]
fn proxy_groups_map_one_to_one_and_truncate() {
    let groups: Vec<ProxyGroupView> = (0..300)
        .map(|i| ProxyGroupView {
            name: format!("g{i}"),
            kind: "Selector".to_owned(),
            selected: Some("A".to_owned()),
            members: vec!["A".to_owned()],
        })
        .collect();
    let wire = proxy_groups_to_wire(&groups);
    assert_eq!(wire.len(), MAX_WIRE_PROXY_GROUPS);
    let first = wire.iter().next().unwrap();
    assert_eq!(first.name, "g0");
    assert_eq!(first.selected.as_deref(), Some("A"));
}

#[test]
fn operation_failed_maps_state_and_failure_codes() -> Result<(), Box<dyn std::error::Error>> {
    let failure = OperationFailure::new(
        OperationFailureCode::Conflict,
        BoundedText::new("conflict")?,
        BoundedText::new("retry")?,
    );
    let status = OperationStatus::new(
        OperationId::from_bytes([1; 16]),
        BoundedText::new("config.apply")?,
        UnixMillis::new(11),
        UnixMillis::new(22),
        OperationState::Failed,
        Some(failure),
    )?;
    let wire = operation_status_to_wire(&status);
    assert_eq!(wire.operation_id, [1; 16]);
    assert_eq!(wire.command_kind, "config.apply");
    assert_eq!((wire.created_at_unix_ms, wire.updated_at_unix_ms), (11, 22));
    assert_eq!(wire.state, RawOperationState(4));
    let failure = wire.failure.unwrap();
    assert_eq!(failure.code, RawFailureCode(2));
    assert_eq!(failure.message, "conflict");
    assert_eq!(failure.suggested_action, "retry");
    Ok(())
}

#[test]
fn desired_applied_observed_and_platform_map() {
    let desired = DesiredState::new(ProxyMode::Rule, None, None, true, false);
    let wire = desired_to_wire(&desired);
    assert_eq!(wire.mode, 1);
    assert_eq!(wire.selected_node_id, None);
    assert_eq!(wire.active_subscription_id, None);
    assert!(wire.tun_requested);
    assert!(!wire.system_proxy_requested);

    let applied = applied_to_wire(&AppliedState::stopped());
    assert_eq!(applied.core_kind, None);
    assert_eq!(applied.run_state, 1);

    let observed = observed_to_wire(&ObservedState::default());
    assert_eq!(
        (
            observed.upload_bytes_per_second,
            observed.download_bytes_per_second,
            observed.active_connections,
            observed.telemetry_dropped,
            observed.core_restart_count,
            observed.core_restart_backoff_ms,
        ),
        (0, 0, 0, 0, 0, 0)
    );

    let platform = platform_to_wire(&PlatformEffectView::none());
    assert!(!platform.proxy_engaged);
    assert!(!platform.tun_engaged);
    assert!(!platform.recovery_pending);
    assert_eq!(platform.degraded_reason, None);
}

fn failed_status(
    code: OperationFailureCode,
) -> Result<OperationStatus, Box<dyn std::error::Error>> {
    let failure =
        OperationFailure::new(code, BoundedText::new("boom")?, BoundedText::new("retry")?);
    Ok(OperationStatus::new(
        OperationId::from_bytes([3; 16]),
        BoundedText::new("config.apply")?,
        UnixMillis::new(5),
        UnixMillis::new(6),
        OperationState::Failed,
        Some(failure),
    )?)
}

#[test]
fn every_failure_code_survives_wire_roundtrip() -> Result<(), Box<dyn std::error::Error>> {
    use OperationFailureCode::*;
    for code in [
        InvalidInput,
        Conflict,
        ResourceExhausted,
        Unsupported,
        DeadlineExceeded,
        TooLateToCancel,
        Infrastructure,
        RecoveryRequired,
    ] {
        let wire = operation_status_to_wire(&failed_status(code)?);
        let mut budget = DecodeBudget::new(DecodeLimits::v2_default());
        let back = operation_status_from_wire(wire, &mut budget)?;
        assert_eq!(back.state(), OperationState::Failed);
        assert_eq!(back.failure().map(OperationFailure::code), Some(code));
    }
    Ok(())
}

fn capability_set_covering_all_tables() -> Result<CapabilitySet, Box<dyn std::error::Error>> {
    use Capability::*;
    let capabilities = [
        TunConfiguration,
        DnsConfiguration,
        RuntimeModeSwitch,
        ProxyGroups,
        ProxySelection,
        UrlTest,
        Connections,
        ConnectionClose,
        Traffic,
        Logs,
        Rules,
    ];
    let configured = [
        ConfiguredSupport::Unsupported,
        ConfiguredSupport::Supported,
        ConfiguredSupport::Partial,
    ];
    let runtime = [
        RuntimeAvailability::NotRequired,
        RuntimeAvailability::Available,
        RuntimeAvailability::Unavailable,
        RuntimeAvailability::Unknown,
    ];
    let statuses: Vec<CapabilityStatus> = capabilities
        .into_iter()
        .enumerate()
        .map(|(i, capability)| {
            CapabilityStatus::new(
                capability,
                configured[i % configured.len()],
                runtime[i % runtime.len()],
                None,
            )
        })
        .collect();
    let set = CapabilitySet::new(BoundedVec::try_from_vec(statuses)?)?;
    Ok(set)
}

#[test]
fn every_capability_table_survives_wire_roundtrip() -> Result<(), Box<dyn std::error::Error>> {
    let set = capability_set_covering_all_tables()?;
    let wire = capabilities_to_wire(&set)?;
    let as_vec: Vec<WireCapabilityStatus> = wire.iter().cloned().collect();
    let mut budget = DecodeBudget::new(DecodeLimits::v2_default());
    let back = capabilities_from_wire(as_vec, &mut budget)?;
    let mut before: Vec<(Capability, ConfiguredSupport, RuntimeAvailability)> = set
        .iter()
        .map(|s| (s.capability(), s.configured(), s.runtime()))
        .collect();
    let mut after: Vec<(Capability, ConfiguredSupport, RuntimeAvailability)> = back
        .iter()
        .map(|s| (s.capability(), s.configured(), s.runtime()))
        .collect();
    before.sort_by_key(|row| row.0 as u8);
    after.sort_by_key(|row| row.0 as u8);
    assert_eq!(before, after);
    Ok(())
}
