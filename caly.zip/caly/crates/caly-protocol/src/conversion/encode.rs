//! Strict Domain-to-wire encoding without credentials or lossy defaults.

use caly_domain::{
    BoundedVec, Capability, ConfiguredSupport, CoreKind, CoreRunState, LiveConnection,
    OperationFailureCode, OperationState, PresentationSnapshot, ProxyMode, RuntimeAvailability,
};

use crate::protocol::v2::{
    LiveConnectionsResponse, MAX_WIRE_CONNECTION_CHAIN, MAX_WIRE_CONNECTION_TEXT_BYTES,
    MAX_WIRE_PROXY_GROUPS, MAX_WIRE_SOURCES, RawFailureCode, RawOperationState, WireAppliedState,
    WireCapabilityStatus, WireDesiredState, WireDisplayNode, WireLiveConnection, WireObservedState,
    WireOperationFailure, WireOperationStatus, WirePlatformEffect, WirePresentationSnapshot,
    WireProxyGroup, WireSourceView,
};

use super::cursor_to_wire;

/// Encoding failure means a Domain/Protocol bound changed without migration.
#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub struct EncodeError(pub caly_domain::CapacityError);

impl core::fmt::Display for EncodeError {
    fn fmt(&self, formatter: &mut core::fmt::Formatter<'_>) -> core::fmt::Result {
        write!(
            formatter,
            "domain value exceeds the protocol bound: {}",
            self.0
        )
    }
}

impl std::error::Error for EncodeError {}

/// Encodes a credential-free presentation snapshot.
pub fn snapshot_to_wire(
    snapshot: &PresentationSnapshot,
) -> Result<WirePresentationSnapshot, EncodeError> {
    let capabilities = capabilities_to_wire(snapshot.capabilities())?;
    let nodes = nodes_to_wire(snapshot.nodes())?;
    let proxy_groups = proxy_groups_to_wire(snapshot.proxy_groups());
    let sources = sources_to_wire(snapshot.sources());
    Ok(WirePresentationSnapshot {
        daemon_instance_id: snapshot.daemon_instance().into_bytes(),
        revision: snapshot.revision().value(),
        cursor: cursor_to_wire(snapshot.cursor()),
        desired: desired_to_wire(snapshot.desired()),
        applied: applied_to_wire(snapshot.applied()),
        observed: observed_to_wire(snapshot.observed()),
        platform: platform_to_wire(snapshot.platform()),
        capabilities,
        nodes,
        proxy_groups,
        sources,
    })
}

/// Bounded-text projection with char-boundary truncation and a non-empty
/// fallback: over-long display strings degrade to their truncated form and
/// empty strings degrade to `fallback`, so a produced wire value can always
/// be deserialized by `BoundedText` (which rejects the empty string).
fn clamped_text<const N: usize>(
    value: &str,
    fallback: &'static str,
) -> caly_domain::BoundedText<N> {
    caly_domain::BoundedText::from_nonempty_clamped(value.to_owned(), fallback)
}

/// CLI sinking (2026-08-14, read path): the declared source listing,
/// bounded per field so a hostile config cannot balloon the snapshot.
/// Losslessly narrows a domain count/index to the wire integer. Values
/// beyond `u32::MAX` (impossible for a loaded config today, and an
/// invariant error if they ever occur) clamp to the maximum wire value so
/// a malformed in-memory count can never silently wrap.
fn bounded_count(value: usize) -> u32 {
    u32::try_from(value).map_or(u32::MAX, |value| value)
}

pub fn sources_to_wire(
    sources: &[caly_domain::SourceView],
) -> BoundedVec<WireSourceView, MAX_WIRE_SOURCES> {
    let mut wire = BoundedVec::new();
    for source in sources {
        // Over-long fields clamp to the wire bound (same discipline as
        // nodes): a display string longer than the wire cap degrades to
        // its truncated form instead of failing the whole snapshot.
        let mut groups = caly_domain::BoundedVec::new();
        for group in &source.groups {
            if groups.try_push(clamped_text(group, "#")).is_err() {
                break;
            }
        }
        if wire
            .try_push(WireSourceView {
                index: bounded_count(source.index),
                name: clamped_text(&source.name, "#"),
                kind: clamped_text(&source.kind, "subscription"),
                url: clamped_text(&source.url, "file://invalid"),
                enabled: source.enabled,
                nodes: bounded_count(source.nodes),
                groups,
                last_refresh_unix: source.last_refresh_unix,
                next_refresh_unix: source.next_refresh_unix,
                cached: source.cached,
            })
            .is_err()
        {
            break;
        }
    }
    wire
}

/// Live connection slice for daemon-mediated flow reads. Over-long text
/// fields clamp and over-long slices/chain entries truncate, matching the
/// display-projection discipline used by nodes and sources.
pub fn live_connections_to_wire(connections: &[LiveConnection]) -> LiveConnectionsResponse {
    let mut wire = BoundedVec::new();
    for connection in connections {
        let mut chain = Vec::new();
        for item in &connection.chain {
            if chain.len() >= MAX_WIRE_CONNECTION_CHAIN {
                break;
            }
            chain.push(wire_connection_text(item, "#"));
        }
        if wire
            .try_push(WireLiveConnection {
                id: wire_connection_text(&connection.id, "--"),
                host: wire_connection_text(&connection.host, "-"),
                destination_port: connection.destination_port,
                network: wire_connection_text(&connection.network, "-"),
                protocol_type: wire_connection_text(&connection.protocol_type, "-"),
                inbound_name: wire_connection_text(&connection.inbound_name, "-"),
                process_path: wire_connection_text(&connection.process_path, "-"),
                rule: wire_connection_text(&connection.rule, "-"),
                rule_payload: wire_connection_text(&connection.rule_payload, "-"),
                outbound: wire_connection_text(&connection.outbound, "-"),
                chain,
                upload_bytes: connection.upload_bytes,
                download_bytes: connection.download_bytes,
            })
            .is_err()
        {
            break;
        }
    }
    LiveConnectionsResponse { connections: wire }
}

fn wire_connection_text(value: &str, fallback: &'static str) -> String {
    clamped_text::<MAX_WIRE_CONNECTION_TEXT_BYTES>(value, fallback)
        .as_str()
        .to_owned()
}

/// W3b: the kernel proxy-group slice, mapped 1:1 onto the wire shape.
/// Over-long slices clamp at the wire bound (same discipline as nodes).
pub fn proxy_groups_to_wire(
    groups: &[caly_domain::ProxyGroupView],
) -> BoundedVec<WireProxyGroup, MAX_WIRE_PROXY_GROUPS> {
    let mut wire = BoundedVec::new();
    for group in groups {
        if wire
            .try_push(WireProxyGroup {
                name: group.name.clone(),
                kind: group.kind.clone(),
                selected: group.selected.clone(),
                members: group.members.clone(),
            })
            .is_err()
        {
            break;
        }
    }
    wire
}

/// Encodes queryable operation status.
pub fn operation_status_to_wire(status: &caly_domain::OperationStatus) -> WireOperationStatus {
    WireOperationStatus {
        operation_id: status.id().into_bytes(),
        command_kind: status.kind().as_str().to_owned(),
        created_at_unix_ms: status.created_at().value(),
        updated_at_unix_ms: status.updated_at().value(),
        state: RawOperationState(operation_state(status.state())),
        failure: status.failure().map(|failure| WireOperationFailure {
            code: RawFailureCode(failure_code(failure.code())),
            message: failure.message().as_str().to_owned(),
            suggested_action: failure.suggested_action().as_str().to_owned(),
        }),
    }
}

/// Encodes persisted intent.
pub fn desired_to_wire(value: &caly_domain::DesiredState) -> WireDesiredState {
    WireDesiredState {
        mode: proxy_mode(value.mode()),
        selected_node_id: value.selected_node().map(caly_domain::NodeId::into_bytes),
        active_subscription_id: value
            .active_subscription()
            .map(caly_domain::SubscriptionId::into_bytes),
        tun_requested: value.tun_requested(),
        system_proxy_requested: value.system_proxy_requested(),
    }
}

/// Encodes runtime-applied state.
pub fn applied_to_wire(value: &caly_domain::AppliedState) -> WireAppliedState {
    WireAppliedState {
        core_kind: value.core().map(core_kind),
        run_state: run_state(value.run_state()),
        selected_node_id: value.selected_node().map(caly_domain::NodeId::into_bytes),
        config_generation: value.config_generation(),
    }
}

/// Encodes observed runtime counters.
pub fn observed_to_wire(value: &caly_domain::ObservedState) -> WireObservedState {
    WireObservedState {
        upload_bytes_per_second: value.upload_bytes_per_second(),
        download_bytes_per_second: value.download_bytes_per_second(),
        active_connections: value.active_connections(),
        telemetry_dropped: value.telemetry_dropped(),
        core_restart_count: value.core_restart_count(),
        core_restart_backoff_ms: value.core_restart_backoff_ms(),
    }
}

/// Encodes redacted platform effects.
pub fn platform_to_wire(value: &caly_domain::PlatformEffectView) -> WirePlatformEffect {
    WirePlatformEffect {
        proxy_engaged: value.proxy_engaged(),
        tun_engaged: value.tun_engaged(),
        recovery_pending: value.recovery_pending(),
        degraded_reason: value
            .degraded_reason()
            .map(|reason| reason.as_str().to_owned()),
    }
}

fn capability_to_wire(value: &caly_domain::CapabilityStatus) -> WireCapabilityStatus {
    WireCapabilityStatus {
        capability: capability(value.capability()),
        configured: configured(value.configured()),
        runtime: runtime(value.runtime()),
        caveat: value.caveat().map(|text| text.as_str().to_owned()),
    }
}

/// Encodes a bounded capability set.
pub fn capabilities_to_wire(
    values: &caly_domain::CapabilitySet,
) -> Result<caly_domain::BoundedVec<WireCapabilityStatus, 64>, EncodeError> {
    let converted = values.iter().map(capability_to_wire).collect();
    caly_domain::BoundedVec::try_from_vec(converted).map_err(EncodeError)
}

/// Encodes bounded credential-free display nodes.
pub fn nodes_to_wire(
    values: &caly_domain::SnapshotNodes,
) -> Result<caly_domain::BoundedVec<WireDisplayNode, 10_000>, EncodeError> {
    let converted = values
        .iter()
        .map(|node| WireDisplayNode {
            node_id: node.id().into_bytes(),
            name: node.name().as_str().to_owned(),
            protocol: node.protocol().as_str().to_owned(),
            available: node.is_available(),
            latency_ms: node.latency_ms(),
        })
        .collect();
    caly_domain::BoundedVec::try_from_vec(converted).map_err(EncodeError)
}

fn proxy_mode(value: ProxyMode) -> i32 {
    crate::protocol::v2::WireMode::from(value).wire()
}
fn core_kind(value: CoreKind) -> i32 {
    crate::protocol::v2::WireCoreKind::from(value).wire()
}
fn run_state(value: CoreRunState) -> i32 {
    crate::protocol::v2::WireRunState::from(value).wire()
}
fn operation_state(value: OperationState) -> i32 {
    crate::protocol::v2::WireOperationState::from(value).wire()
}
const fn failure_code(value: OperationFailureCode) -> i32 {
    match value {
        OperationFailureCode::InvalidInput => 1,
        OperationFailureCode::Conflict => 2,
        OperationFailureCode::ResourceExhausted => 3,
        OperationFailureCode::Unsupported => 4,
        OperationFailureCode::DeadlineExceeded => 5,
        OperationFailureCode::TooLateToCancel => 6,
        OperationFailureCode::Infrastructure => 7,
        OperationFailureCode::RecoveryRequired => 8,
    }
}
const fn configured(value: ConfiguredSupport) -> i32 {
    match value {
        ConfiguredSupport::Unsupported => 1,
        ConfiguredSupport::Supported => 2,
        ConfiguredSupport::Partial => 3,
    }
}
const fn runtime(value: RuntimeAvailability) -> i32 {
    match value {
        RuntimeAvailability::NotRequired => 1,
        RuntimeAvailability::Available => 2,
        RuntimeAvailability::Unavailable => 3,
        RuntimeAvailability::Unknown => 4,
    }
}
const fn capability(value: Capability) -> i32 {
    match value {
        Capability::TunConfiguration => 1,
        Capability::DnsConfiguration => 2,
        Capability::RuntimeModeSwitch => 3,
        Capability::ProxyGroups => 4,
        Capability::ProxySelection => 5,
        Capability::UrlTest => 6,
        Capability::Connections => 7,
        Capability::ConnectionClose => 8,
        Capability::Traffic => 9,
        Capability::Logs => 10,
        Capability::Rules => 11,
    }
}
