//! Operation wire DTOs preserving raw enum values.

use super::{WireId, WirePayload};

/// Known v2 mutation command categories.
#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub enum CommandKind {
    ApplyConfig,
    SwitchCore,
    SelectProxy,
    /// W4 (cli-v3-design.md §12): in-group member pick inside a
    /// selector group (`node pick <group> <member> --apply`).
    /// Wire discriminant 11, appended after the frozen 1–10 set.
    SelectProxyGroup,
    /// PAC mode for the desktop system proxy (`sysproxy pac`): the
    /// desktop is switched to its `auto` mode pointing at a PAC URL
    /// (caly-generated `file://` or an operator-supplied one). Wire
    /// discriminant 12, appended after the frozen 1–11 set.
    SetSystemProxyPac,
    SetMode,
    SetTun,
    SetSystemProxy,
    RefreshSubscription,
    CloseConnections,
    /// Close one active connection by kernel connection id.
    /// Wire discriminant 13, appended after the frozen 1–12 set.
    CloseConnection,
    /// daemon-side shutdown request. The
    /// server responds with the operation status, then
    /// breaks its `serve()` loop and exits 0.
    StopDaemon,
    /// daemon-side reload request. The
    /// server re-reads `config.yaml` and re-applies
    /// the current candidate (synonym for `ApplyConfig`
    /// with the latest `candidate_id`).
    ReloadConfig,
}

/// Raw command discriminant; unknown values remain representable.
#[derive(Clone, Copy, Debug, Eq, PartialEq, serde::Serialize, serde::Deserialize)]
pub struct RawCommandKind(pub i32);

impl RawCommandKind {
    /// Converts a known command without fabricating a fallback.
    pub const fn known(self) -> Option<CommandKind> {
        match self.0 {
            1 => Some(CommandKind::ApplyConfig),
            2 => Some(CommandKind::SwitchCore),
            3 => Some(CommandKind::SelectProxy),
            4 => Some(CommandKind::SetMode),
            5 => Some(CommandKind::SetTun),
            6 => Some(CommandKind::SetSystemProxy),
            7 => Some(CommandKind::RefreshSubscription),
            8 => Some(CommandKind::CloseConnections),
            9 => Some(CommandKind::StopDaemon),
            10 => Some(CommandKind::ReloadConfig),
            // W4: `node pick` in-group member selection (wire 11, appended
            // after the frozen 1–10 set — never renumber existing values).
            11 => Some(CommandKind::SelectProxyGroup),
            // `sysproxy pac` (2026-08-12).
            12 => Some(CommandKind::SetSystemProxyPac),
            // Close one active connection by id (future CLI flow panel).
            13 => Some(CommandKind::CloseConnection),
            _ => None,
        }
    }
}
/// Raw operation-state discriminant.
#[derive(Clone, Copy, Debug, Eq, PartialEq, serde::Serialize, serde::Deserialize)]
pub struct RawOperationState(pub i32);

impl RawOperationState {
    /// Typed view of the discriminant; unknown values stay untyped.
    pub const fn known(self) -> Option<super::wire::WireOperationState> {
        super::wire::WireOperationState::from_wire(self.0)
    }

    /// Terminal states end the operation lifecycle permanently.
    pub const fn is_terminal(self) -> bool {
        match super::wire::WireOperationState::from_wire(self.0) {
            Some(state) => state.is_terminal(),
            None => false,
        }
    }

    /// Presentation label; unknown values render as `unknown(<raw>)`.
    pub fn label(self) -> String {
        self.known().map_or_else(
            || format!("unknown({})", self.0),
            |state| state.label().to_owned(),
        )
    }
}
/// Raw operation-failure discriminant.
#[derive(Clone, Copy, Debug, Eq, PartialEq, serde::Serialize, serde::Deserialize)]
pub struct RawFailureCode(pub i32);
/// Raw cancellation outcome discriminant.
#[derive(Clone, Copy, Debug, Eq, PartialEq, serde::Serialize, serde::Deserialize)]
pub struct RawCancelOutcome(pub i32);

/// Known cancellation result.
#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub enum CancelOutcome {
    Requested,
    AlreadyTerminal,
    TooLateToCancel,
}

impl RawCancelOutcome {
    /// Converts a known value without selecting a fallback.
    pub const fn known(self) -> Option<CancelOutcome> {
        match self.0 {
            1 => Some(CancelOutcome::Requested),
            2 => Some(CancelOutcome::AlreadyTerminal),
            3 => Some(CancelOutcome::TooLateToCancel),
            _ => None,
        }
    }
}

/// Typed mutation payload; unknown future commands preserve kind and bytes.
#[derive(Clone, Debug, Eq, PartialEq, serde::Serialize, serde::Deserialize)]
pub enum WireCommand {
    ApplyConfig {
        #[serde(with = "crate::json_serde::hex_id")]
        candidate_id: WireId,
    },
    SwitchCore {
        core_kind: i32,
        action: i32,
    },
    SelectProxy {
        #[serde(with = "crate::json_serde::hex_id")]
        node_id: WireId,
    },
    /// W4: pick a named member inside a named proxy group. Names
    /// travel verbatim (the offline entry tree is the authority for
    /// group/member spelling); the daemon resolves kernel-side tags.
    SelectProxyGroup {
        group: String,
        member: String,
    },
    SetMode {
        mode: i32,
    },
    SetTun {
        enabled: bool,
    },
    SetSystemProxy {
        enabled: bool,
    },
    /// `sysproxy pac <url>`: switch the desktop proxy to auto mode with
    /// the given PAC URL. The URL travels verbatim (`file://` or
    /// `http(s)://`); the backend decides how to consume it.
    SetSystemProxyPac {
        url: String,
    },
    /// CLI sinking (2026-08-14): `set sub` CRUD executed by the daemon's
    /// config-mutation actor. `apply: false` previews without writing.
    /// Superseded by [`WireCommand::MutateConfig`]; kept so pre-round-2
    /// clients keep their exact encoding, mapped onto
    /// `MutateConfig::Subscription` server-side.
    MutateSubscription {
        mutation: caly_domain::SubscriptionMutation,
        apply: bool,
    },
    /// CLI sinking (2026-08-14, round 2): one CRUD intent for any managed
    /// config resource (`set sub` / `set proxy-group` /
    /// `set rule-provider`), executed by the daemon's config-mutation
    /// actor. `apply: false` previews without writing.
    MutateConfig {
        mutation: caly_domain::ConfigMutation,
        apply: bool,
    },
    RefreshSubscription {
        #[serde(with = "crate::json_serde::hex_id")]
        subscription_id: WireId,
        /// W2-β2b (`sub refresh --force`): refetch the body even
        /// when the stored validators would answer 304. Defaults
        /// false so pre-β2b clients keep their exact encoding.
        #[serde(default)]
        force: bool,
    },
    CloseAllConnections,
    /// Close one active connection by kernel connection id.
    CloseConnection {
        id: String,
    },
    /// server-side shutdown request.
    /// No payload. The server returns the operation
    /// status (which completes immediately), then
    /// breaks its serve loop and exits.
    StopDaemon,
    /// server-side reload request. No
    /// payload. The server re-reads `config.yaml`
    /// and re-applies the current candidate.
    ReloadConfig,
    Unknown {
        raw_kind: RawCommandKind,
        payload: WirePayload,
    },
}

/// Idempotent mutation request.
#[derive(Clone, Debug, Eq, PartialEq, serde::Serialize, serde::Deserialize)]
pub struct ExecuteRequest {
    #[serde(with = "crate::json_serde::hex_id")]
    pub operation_id: WireId,
    pub command: WireCommand,
}

/// Immediate operation acknowledgement, not assumed completion.
#[derive(Clone, Debug, Eq, PartialEq, serde::Serialize, serde::Deserialize)]
pub struct ExecuteResponse {
    pub operation: WireOperationStatus,
}
/// Server-side synchronous execution request. The daemon mints an operation
/// id, submits the command through the same admission path as [`ExecuteRequest`],
/// and polls until the operation reaches a terminal state or `timeout_ms`
/// elapses.
#[derive(Clone, Debug, Eq, PartialEq, serde::Serialize, serde::Deserialize)]
pub struct ExecuteSyncRequest {
    pub command: WireCommand,
    /// Maximum wall-clock wait; the server clamps this to a transport-safe
    /// ceiling so one slow peer cannot pin a connection task forever.
    pub timeout_ms: u32,
    /// Status-poll cadence; the server clamps this to a sane lower bound.
    pub poll_interval_ms: u32,
}
/// Synchronous execution result. `timed_out: true` means the operation was
/// still non-terminal when the deadline fired; the returned status is the
/// last observed status.
#[derive(Clone, Debug, Eq, PartialEq, serde::Serialize, serde::Deserialize)]
pub struct ExecuteSyncResponse {
    pub operation: WireOperationStatus,
    pub timed_out: bool,
}
/// Maximum commands accepted in one [`ExecuteBatchRequest`].
pub const MAX_WIRE_BATCH: usize = 64;

/// Rejection of one batch item that did not survive command admission.
#[derive(Clone, Debug, Eq, PartialEq, serde::Serialize, serde::Deserialize)]
pub struct WireBatchRejection {
    pub code: u32,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub domain: Option<String>,
    pub message: String,
}

/// One batch item outcome: either an accepted operation ack or the reason the
/// item was rejected before operation reservation.
#[derive(Clone, Debug, Eq, PartialEq, serde::Serialize, serde::Deserialize)]
pub enum ExecuteBatchResult {
    Accepted(ExecuteResponse),
    Rejected {
        #[serde(with = "crate::json_serde::hex_id")]
        operation_id: WireId,
        rejection: WireBatchRejection,
    },
}

/// Batch execution request. Items are admitted sequentially; the server stops
/// after the first rejection when `stop_on_error` is true.
#[derive(Clone, Debug, Eq, PartialEq, serde::Serialize, serde::Deserialize)]
pub struct ExecuteBatchRequest {
    pub operations: super::BoundedVec<ExecuteRequest, MAX_WIRE_BATCH>,
    #[serde(default)]
    pub stop_on_error: bool,
}

/// Batch outcome. `stopped_early` reports that `stop_on_error` interrupted the
/// remaining unprocessed items.
#[derive(Clone, Debug, Eq, PartialEq, serde::Serialize, serde::Deserialize)]
pub struct ExecuteBatchResponse {
    pub results: super::BoundedVec<ExecuteBatchResult, MAX_WIRE_BATCH>,
    #[serde(default)]
    pub stopped_early: bool,
}

/// Explicit cancellation request.
#[derive(Clone, Copy, Debug, Eq, PartialEq, serde::Serialize, serde::Deserialize)]
pub struct CancelOperationRequest {
    #[serde(with = "crate::json_serde::hex_id")]
    pub operation_id: WireId,
}
/// Cancellation acknowledgement with current operation state.
#[derive(Clone, Debug, Eq, PartialEq, serde::Serialize, serde::Deserialize)]
pub struct CancelOperationResponse {
    pub operation: WireOperationStatus,
    pub outcome: RawCancelOutcome,
}
/// Maximum operation statuses in one list response.
pub const MAX_WIRE_OPERATION_LIST: usize = 64;

/// Bounded operation-dashboard response for CLI/TUI/WebUI consumers.
#[derive(Clone, Debug, Eq, PartialEq, serde::Serialize, serde::Deserialize)]
pub struct OperationListResponse {
    /// Most recently updated first. The server clips to
    /// [`MAX_WIRE_OPERATION_LIST`] before framing.
    pub operations: super::BoundedVec<WireOperationStatus, MAX_WIRE_OPERATION_LIST>,
}

/// Status lookup after timeout, reconnect, or duplicate submission.
#[derive(Clone, Copy, Debug, Eq, PartialEq, serde::Serialize, serde::Deserialize)]
pub struct GetOperationStatusRequest {
    #[serde(with = "crate::json_serde::hex_id")]
    pub operation_id: WireId,
}

/// Bounded conversion is required before this wire failure enters Domain.
#[derive(Clone, Debug, Eq, PartialEq, serde::Serialize, serde::Deserialize)]
pub struct WireOperationFailure {
    pub code: RawFailureCode,
    pub message: String,
    pub suggested_action: String,
}

/// Operation status transported without interpreting unknown enum values.
#[derive(Clone, Debug, Eq, PartialEq, serde::Serialize, serde::Deserialize)]
pub struct WireOperationStatus {
    #[serde(with = "crate::json_serde::hex_id")]
    pub operation_id: WireId,
    pub command_kind: String,
    pub created_at_unix_ms: u64,
    pub updated_at_unix_ms: u64,
    pub state: RawOperationState,
    pub failure: Option<WireOperationFailure>,
}
