//! Cross-module test helpers.
//!
//! collapses the per-module `temp_root` and
//! `hermetic_paths` helpers that were duplicated across 11
//! client / dispatch test modules. Before this round each
//! module had its own private 10-line `temp_root` with a
//! different `caly-{tag}-{pid}-{n}-{nanos}` prefix; a future
//! rename of the tag scheme would have required 11
//! parallel edits. The two helpers here are the single
//! point of truth for "create a hermetic XDG root" and
//! "build a unique temp dir for a test fixture".
//!
//! # Why public and ungated
//!
//! The helpers are only meaningful for tests, but the CLI and TUI
//! frontends' test suites share them across the crate boundary —
//! `#[cfg(test)]` symbols do not survive that crossing (the dependency
//! is built without `test`). Same shape as
//! `caly_platform::paths::test_helpers`: public module, production
//! code must not use it.
//!
//! # Layout
//!
//! - `temp_root`: a unique subdirectory of
//!   `std::env::temp_dir()` for hermetic test fixtures.
//!   The `tag` is the human-readable label the test
//!   uses to identify the fixture in `eprintln!`
//!   diagnostics (e.g. `"sub-dry"`, `"pg-dispatch"`).
//! - `hermetic_paths`: a `caly_platform::paths::AppPaths`
//!   rooted at a per-test temp dir. The two XDG paths
//!   point at the same root (the production operator
//!   layout does the same — `XDG_STATE_HOME` and
//!   `XDG_CONFIG_HOME` are usually the same parent).
//!   `HOME` / `XDG_RUNTIME_DIR` are filled with
//!   hermetic dummy values so the loader does not
//!   accidentally reach the operator's actual XDG
//!   state if the writer forgets to honour the
//!   injected `AppPaths` (defense-in-depth — a
//!   pre-Round 26 regression test caught exactly
//!   this in `set_proxy_dry_run_emits_envelope`).
//!

/// Creates a unique temp directory under
/// `std::env::temp_dir()` for a single test fixture.
/// The directory's name is
/// `caly-{tag}-{pid}-{counter}-{nanos}` where
/// `counter` is a process-global atomic
/// Canonical temp-dir + hermetic-paths helpers, re-exported from
/// `caly_platform::paths::test_helpers` (next to `AppPaths`, so every
/// workspace test shares one naming scheme). Call sites keep using
/// `crate::test_helpers::{temp_root, hermetic_paths}`.
pub use caly_platform::paths::test_helpers::{hermetic_paths, temp_root};

/// Builds a unique file path under `std::env::temp_dir()`
/// for a single test fixture: `caly-{prefix}-{label}-{pid}`.
/// The `pid` disambiguates parallel test processes; the
/// `label` identifies the fixture in failure diagnostics.
/// The file is *not* created — callers write / remove it
/// themselves.
pub fn unique_file(prefix: &str, label: &str) -> std::path::PathBuf {
    std::env::temp_dir().join(format!("caly-{prefix}-{label}-{}", std::process::id()))
}

#[cfg(test)]
mod tests {
    use super::*;

    /// `temp_root` must produce a unique, existing
    /// subdirectory of `std::env::temp_dir()`.
    /// Subsequent calls in the same test process
    /// must not collide (the `counter` part of
    /// the path disambiguates them).
    #[test]
    fn temp_root_creates_a_unique_directory() {
        let a = temp_root("round26-helper");
        let b = temp_root("round26-helper");
        assert_ne!(a, b, "consecutive temp_root calls must be distinct");
        assert!(a.is_dir());
        assert!(b.is_dir());
    }

    /// `temp_root` must embed the tag in the path
    /// so a failed test can `eprintln!` its fixture
    /// path and the operator can find the directory
    /// under `/tmp` (or `$TMPDIR`). The tag is
    /// literally interpolated into the path
    /// component; assert it round-trips.
    #[test]
    fn temp_root_embeds_the_tag() {
        let path = temp_root("hello");
        let name = path.file_name().and_then(|s| s.to_str()).unwrap_or("");
        assert!(name.contains("hello"), "tag must appear in path: {name}");
    }

    /// `hermetic_paths` must produce an `AppPaths`
    /// whose `config` and `state` subdirectories
    /// live under the test dir, so the writer's
    /// `paths.config.join("config.yaml")` lands in
    /// the test fixture and not the operator's
    /// XDG state.
    #[test]
    fn hermetic_paths_root_state_and_config_under_dir() {
        let dir = temp_root("round26-hermetic");
        let paths = hermetic_paths(&dir);
        assert!(paths.config.starts_with(&dir));
        assert!(paths.state.starts_with(&dir));
    }
}
