//! Entry-tree renderer (cli-v3-design.md G1 / W3a).
//!
//! The shared 三区制 layout (策略组区 / 未入组节点区 / 规则区, C-F)
//! behind both offline entry surfaces:
//!
//! - `sub parse` — full tree from a Clash document
//!   ([`from_clash_import`]), degenerate protocol-only listing for
//!   URI-line documents ([`from_uri_nodes`]).
//! - `node list --offline --format=tree` — declared-config tree
//!   ([`from_declared`]).
//!
//! Pure display module: input is a typed entry model, output is a human
//! tree string or the §6.1 JSON contract. Never touches the daemon and
//! never reads anything beyond the caller-supplied model (show-family
//! discipline). Layout laws follow G-§3.2 / v3 §5.3:
//!
//! - declaration order is display order for groups, members and rules;
//! - nested groups show `→ 嵌套组(见 <name>)` without recursion; a
//!   reference cycle (schema-rejected, defensive here) shows `⟲ cycle`
//!   and never panics;
//! - a document with no groups omits the group zone entirely — the
//!   degenerate protocol-only listing is a legal form, not an error;
//! - residual unknown members / policies render as `[unknown]` and the
//!   walk continues.

use std::collections::HashSet;

use caly_domain::{ProxyGroupMember, RoutingRule};
use caly_subscription::ClashImport;

/// How one entry's badge reads in the human tree and in the JSON `kind`
/// field. The CLI vocabulary maps domain spellings to the user-facing
/// ones (G-§3.1): `select`→`selector`, `url-test`→`urltest`,
/// `load-balance`→`loadbalance`, `shadowsocks`→`ss`. The mapping lives
/// only in this module — files keep their own spellings.
pub fn badge_kind(kind: &str) -> String {
    match kind {
        "select" => "selector".to_owned(),
        "url-test" => "urltest".to_owned(),
        "load-balance" => "loadbalance".to_owned(),
        "shadowsocks" => "ss".to_owned(),
        other => other.to_owned(),
    }
}

/// One entry in the tree: a protocol node, a group, or a builtin.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct TreeEntry {
    /// Display name (group tag / node tag / `DIRECT` / `REJECT`).
    pub name: String,
    /// Badge kind after [`badge_kind`] mapping.
    pub kind: String,
    /// `protocol` / `group` / `builtin`.
    pub entry_type: &'static str,
}

/// One member slot inside a group.
#[derive(Clone, Debug, Eq, PartialEq)]
pub enum TreeMember {
    /// A real node reference.
    Node { name: String, kind: String },
    /// A nested-group reference (`ref: true` in JSON).
    Group { name: String, kind: String },
    /// `DIRECT` / `REJECT`.
    Builtin { name: String, kind: String },
    /// Residual unknown reference (schema-rejected; defensive `[unknown]`).
    Unknown { name: String },
}

/// A declared (or imported) proxy group.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct TreeGroup {
    pub name: String,
    /// Badge kind (`selector` / `urltest` / `fallback` / `loadbalance` /
    /// `relay`).
    pub kind: String,
    pub url: Option<String>,
    pub interval_seconds: Option<u32>,
    pub tolerance_ms: Option<u32>,
    pub members: Vec<TreeMember>,
}

/// A protocol entry (grouped or ungrouped).
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct TreeNode {
    pub name: String,
    pub kind: String,
}

/// One routing rule with its policy back-link.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct TreeRule {
    pub text: String,
    pub target: String,
    pub target_kind: Option<String>,
}

/// The whole entry tree: three zones plus provenance.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct EntryTree {
    /// `clash-yaml` / `uri-lines` / `base64-uri-lines` / `config`.
    pub format: String,
    /// 策略组区 — declaration order.
    pub groups: Vec<TreeGroup>,
    /// 未入组节点区 — nodes not referenced by any group member list,
    /// in declaration order.
    pub ungrouped: Vec<TreeNode>,
    /// 规则区 — only the offline faces carry rules.
    pub rules: Vec<TreeRule>,
    /// Distinct builtins referenced (`DIRECT` / `REJECT`), declaration
    /// order of first use.
    pub builtins: Vec<TreeEntry>,
}

impl EntryTree {
    /// Total protocol entry count (grouped + ungrouped, deduplicated).
    pub fn protocol_count(&self) -> usize {
        let mut count = self.ungrouped.len();
        let mut seen: HashSet<&str> = self.ungrouped.iter().map(|n| n.name.as_str()).collect();
        for group in &self.groups {
            for member in &group.members {
                if let TreeMember::Node { name, .. } = member
                    && seen.insert(name.as_str())
                {
                    count += 1;
                }
            }
        }
        count
    }

    /// Total entry count for §6.1 `counts.entries`.
    pub fn entry_count(&self) -> usize {
        self.protocol_count() + self.groups.len() + self.builtins.len()
    }

    /// Whether any group zone exists (drives the human layout: no groups
    /// means the degenerate protocol-only listing).
    pub fn has_groups(&self) -> bool {
        !self.groups.is_empty()
    }
}

// ── builders ───────────────────────────────────────────────────

/// Builds the tree from a parsed Clash import (`sub parse` path).
/// `format` is the document format label (`clash-yaml`).
pub fn from_clash_import(import: &ClashImport, format: &str) -> EntryTree {
    // Node kind lookup table: tag → badge kind.
    let mut node_kinds: Vec<(String, String)> = Vec::with_capacity(import.proxies.len());
    for node in &import.proxies {
        match node.display(true, None) {
            Ok(display) => node_kinds.push((
                display.name().as_str().to_owned(),
                badge_kind(display.protocol().as_str()),
            )),
            Err(_) => {
                // Display projection failure is unreachable for
                // schema-validated nodes; degrade to an [unknown] slot
                // rather than panic (defensive walk law).
                node_kinds.push(("unknown".to_owned(), "unknown".to_owned()));
            }
        }
    }

    let mut groups: Vec<TreeGroup> = import
        .proxy_groups
        .iter()
        .map(|group| build_group(group, &node_kinds))
        .collect();
    resolve_group_refs(&mut groups);

    let ungrouped = collect_ungrouped(&groups, &node_kinds);
    let builtins = collect_builtins(&groups);

    EntryTree {
        format: format.to_owned(),
        groups,
        ungrouped,
        rules: import
            .rules
            .iter()
            .map(|rule| build_rule(rule, import))
            .collect(),
        builtins,
    }
}

/// Builds the degenerate tree for URI-line documents: no group zone, no
/// rule zone — the legal protocol-only listing (G-§3.2). `nodes` are
/// `(tag, badge kind)` pairs in declaration order.
pub fn from_uri_nodes(format: &str, nodes: Vec<(String, String)>) -> EntryTree {
    EntryTree {
        format: format.to_owned(),
        groups: Vec::new(),
        ungrouped: nodes
            .into_iter()
            .map(|(name, kind)| TreeNode { name, kind })
            .collect(),
        rules: Vec::new(),
        builtins: Vec::new(),
    }
}

/// Builds the declared-config group list plus the inline-provider node
/// kind table (`(tag, badge kind)`), shared by the tree renderer and the
/// W4 online leaves.
pub fn declared_groups(
    paths: &caly_platform::paths::AppPaths,
    config: &caly_profile::schema::AppConfig,
    enabled_only: bool,
) -> (Vec<TreeGroup>, Vec<(String, String)>) {
    let mut nodes = collect_inline_nodes(config);
    let mut groups = collect_config_groups(config, &nodes, enabled_only);
    collect_subscription_groups(paths, config, &mut groups, &mut nodes);
    (groups, nodes)
}

/// Inline provider nodes as `(tag, badge kind)`; a URI that fails to parse
/// degrades to an `[unknown]` slot keyed by the raw text.
fn collect_inline_nodes(config: &caly_profile::schema::AppConfig) -> Vec<(String, String)> {
    let subscription = caly_domain::SubscriptionId::from_bytes([0; 16]);
    let mut nodes = Vec::new();
    for provider in &config.providers {
        if let caly_profile::schema::ProviderKind::InlineNodes(uris) = &provider.kind {
            for uri in uris {
                match caly_subscription::parse_any_proxy_uri(uri.as_str(), subscription)
                    .ok()
                    .and_then(|node| node.display(true, None).ok())
                {
                    Some(display) => nodes.push((
                        display.name().as_str().to_owned(),
                        badge_kind(display.protocol().as_str()),
                    )),
                    None => nodes.push((uri.clone(), "unknown".to_owned())),
                }
            }
        }
    }
    nodes
}

/// Schema-declared proxy groups mapped onto the tree model.
fn collect_config_groups(
    config: &caly_profile::schema::AppConfig,
    nodes: &[(String, String)],
    enabled_only: bool,
) -> Vec<TreeGroup> {
    config
        .proxy_groups
        .iter()
        .filter(|group| !enabled_only || group.enabled)
        .map(|group| {
            let members = group
                .members
                .iter()
                .map(|member| match member {
                    caly_profile::schema::ProxyGroupMemberConfig::Node { tag } => {
                        let kind = nodes
                            .iter()
                            .find(|(candidate, _)| candidate == tag)
                            .map_or_else(|| "unknown".to_owned(), |(_, kind)| kind.clone());
                        TreeMember::Node {
                            name: tag.clone(),
                            kind,
                        }
                    }
                    caly_profile::schema::ProxyGroupMemberConfig::Group { name } => {
                        TreeMember::Group {
                            name: name.clone(),
                            kind: "unknown".to_owned(),
                        }
                    }
                    caly_profile::schema::ProxyGroupMemberConfig::Direct => TreeMember::Builtin {
                        name: "DIRECT".to_owned(),
                        kind: "direct".to_owned(),
                    },
                    caly_profile::schema::ProxyGroupMemberConfig::Reject => TreeMember::Builtin {
                        name: "REJECT".to_owned(),
                        kind: "reject".to_owned(),
                    },
                })
                .collect();
            let (url, interval_seconds, tolerance_ms) = match &group.url_test {
                Some(probe) => (
                    Some(probe.url.clone()),
                    Some(probe.interval_seconds),
                    Some(probe.tolerance_ms),
                ),
                None => (None, None, None),
            };
            TreeGroup {
                name: group.name.clone(),
                kind: badge_kind(group.group_type.clash_label()),
                url,
                interval_seconds,
                tolerance_ms,
                members,
            }
        })
        .collect()
}

/// Subscription-author groups from cached bodies. Config groups win on
/// name collisions; each body's own nodes join the kind table so its
/// members do not degrade to `[unknown]`.
fn collect_subscription_groups(
    paths: &caly_platform::paths::AppPaths,
    config: &caly_profile::schema::AppConfig,
    groups: &mut Vec<TreeGroup>,
    nodes: &mut Vec<(String, String)>,
) {
    let mut seen: std::collections::HashSet<String> =
        groups.iter().map(|group| group.name.clone()).collect();
    let mut subscription_urls: Vec<&str> = config
        .subscriptions
        .sources
        .iter()
        .map(|source| source.url.as_str())
        .collect();
    if let Some(legacy) = config.subscriptions.url.as_deref() {
        subscription_urls.push(legacy);
    }
    for url in subscription_urls {
        let id = caly_subscription::subscription_id_for_url(url);
        let body_path = paths
            .state
            .join("subscriptions")
            .join(caly_domain::to_hex(id.into_bytes()));
        let Ok(body) = std::fs::read(&body_path) else {
            continue;
        };
        let Some((subscription_groups, _)) = caly_subscription::clash_routing_from_body(&body, id)
        else {
            continue;
        };
        // 2026-08-13: the subscription's own nodes must join the node list
        // too — `clash_routing_from_body` only surfaces groups.
        if let Ok(import) = caly_subscription::parse_clash_config(
            std::str::from_utf8(&body).unwrap_or_default(),
            id,
        ) {
            for node in &import.proxies {
                if let Ok(display) = node.display(true, None) {
                    nodes.push((
                        display.name().to_string(),
                        badge_kind(display.protocol().as_str()),
                    ));
                }
            }
        }
        for group in subscription_groups {
            if seen.insert(group.name.as_str().to_owned()) {
                groups.push(build_group(&group, nodes));
            }
        }
    }
}

/// Builds the declared-config tree (`node list --offline --format=tree`
/// path): `groups` are the schema-declared `proxy_groups:` (already
/// `enabled`-filtered by the caller), `nodes` are `(tag, badge kind)`
/// pairs resolved from the inline provider URIs, and `rules` are the
/// config `rules:` lines (parse failures degrade to `[unknown]`, never
/// abort the walk).
pub fn from_declared(
    format: &str,
    mut groups: Vec<TreeGroup>,
    nodes: Vec<(String, String)>,
    rules: Vec<TreeRule>,
) -> EntryTree {
    resolve_group_refs(&mut groups);
    let ungrouped = collect_ungrouped(&groups, &nodes);
    let builtins = collect_builtins(&groups);
    EntryTree {
        format: format.to_owned(),
        groups,
        ungrouped,
        rules,
        builtins,
    }
}

fn build_group(group: &caly_domain::ProxyGroup, node_kinds: &[(String, String)]) -> TreeGroup {
    let members: Vec<TreeMember> = group
        .members
        .iter()
        .map(|member| match member {
            ProxyGroupMember::Node { tag } => {
                let name = tag.as_str().to_owned();
                match node_kinds.iter().find(|(candidate, _)| *candidate == name) {
                    Some((_, kind)) => TreeMember::Node {
                        name,
                        kind: kind.clone(),
                    },
                    None => {
                        // Dangling node reference (schema-rejected;
                        // defensive `[unknown]` slot keeps the walk alive).
                        TreeMember::Unknown { name }
                    }
                }
            }
            ProxyGroupMember::Group { name } => TreeMember::Group {
                name: name.as_str().to_owned(),
                // Resolved by `resolve_group_refs` once the group set
                // is complete (forward references are legal in Clash).
                kind: "unknown".to_owned(),
            },
            ProxyGroupMember::Direct => TreeMember::Builtin {
                name: "DIRECT".to_owned(),
                kind: "direct".to_owned(),
            },
            ProxyGroupMember::Reject => TreeMember::Builtin {
                name: "REJECT".to_owned(),
                kind: "reject".to_owned(),
            },
        })
        .collect();
    let kind = badge_kind(group.kind.clash_label());
    let (url, interval_seconds, tolerance_ms) = match &group.url_test {
        Some(probe) => (
            Some(probe.url.as_str().to_owned()),
            Some(probe.interval_seconds),
            Some(probe.tolerance_ms),
        ),
        None => (None, None, None),
    };
    TreeGroup {
        name: group.name.as_str().to_owned(),
        kind,
        url,
        interval_seconds,
        tolerance_ms,
        members,
    }
}

/// Resolves nested-group member kinds once the full group set exists
/// (Clash allows forward references). A schema-rejected dangling
/// reference degrades to `[unknown]` — the walk never aborts.
fn resolve_group_refs(groups: &mut [TreeGroup]) {
    // Snapshot the name→kind map first (the mutable pass cannot hold a
    // borrow of `groups` while reading it back).
    let kinds: Vec<(String, String)> = groups
        .iter()
        .map(|group| (group.name.clone(), group.kind.clone()))
        .collect();
    for group in groups.iter_mut() {
        for member in &mut group.members {
            if let TreeMember::Group { name, kind } = member {
                *kind = kinds
                    .iter()
                    .find(|(candidate, _)| candidate == name)
                    .map_or_else(|| "unknown".to_owned(), |(_, kind)| kind.clone());
            }
        }
    }
}

/// 未入组 = declared nodes not referenced by any group member list.
fn collect_ungrouped(groups: &[TreeGroup], node_kinds: &[(String, String)]) -> Vec<TreeNode> {
    let mut referenced: HashSet<&str> = HashSet::new();
    for group in groups {
        for member in &group.members {
            if let TreeMember::Node { name, .. } = member {
                referenced.insert(name.as_str());
            }
        }
    }
    node_kinds
        .iter()
        .filter(|(name, _)| !referenced.contains(name.as_str()))
        .map(|(name, kind)| TreeNode {
            name: name.clone(),
            kind: kind.clone(),
        })
        .collect()
}

fn collect_builtins(groups: &[TreeGroup]) -> Vec<TreeEntry> {
    let mut builtins: Vec<TreeEntry> = Vec::new();
    let mut seen = HashSet::new();
    for group in groups {
        for member in &group.members {
            if let TreeMember::Builtin { name, kind } = member
                && seen.insert(name.clone())
            {
                builtins.push(TreeEntry {
                    name: name.clone(),
                    kind: kind.clone(),
                    entry_type: "builtin",
                });
            }
        }
    }
    builtins
}

fn build_rule(rule: &RoutingRule, import: &ClashImport) -> TreeRule {
    let text = rule.to_clash_line();
    let (target, target_kind) = match &rule.policy {
        caly_domain::RulePolicy::Direct => ("DIRECT".to_owned(), Some("direct".to_owned())),
        caly_domain::RulePolicy::Reject => ("REJECT".to_owned(), Some("reject".to_owned())),
        caly_domain::RulePolicy::Proxy(name) => {
            let name = name.as_str().to_owned();
            let kind = import
                .proxy_groups
                .iter()
                .find(|group| group.name.as_str() == name)
                .map(|group| badge_kind(group.kind.clash_label()))
                .or_else(|| {
                    import
                        .proxies
                        .iter()
                        .find(|node| node_display_name(node).as_deref() == Some(name.as_str()))
                        .map(|node| badge_kind(node.protocol().label()))
                });
            (name, kind)
        }
    };
    TreeRule {
        text,
        target,
        target_kind,
    }
}

/// Credential-free display name of a node; `None` on a pathological
/// display projection (defensive — see the walk laws).
fn node_display_name(node: &caly_domain::DialableNode) -> Option<String> {
    node.display(true, None)
        .ok()
        .map(|display| display.name().as_str().to_owned())
}

/// Marks a group member slot `⟲ cycle` when the referenced group
/// transitively references back. Defensive only — the schema validator
/// rejects cycles; the walk must still terminate and never panic.
fn member_cycles(groups: &[TreeGroup]) -> Vec<Vec<bool>> {
    let mut cycles: Vec<Vec<bool>> = Vec::with_capacity(groups.len());
    for owner in groups {
        let mut flags = vec![false; owner.members.len()];
        for (index, member) in owner.members.iter().enumerate() {
            if let TreeMember::Group { name, .. } = member
                && reaches_back(
                    groups,
                    name.as_str(),
                    owner.name.as_str(),
                    &mut HashSet::new(),
                )
            {
                flags[index] = true;
            }
        }
        cycles.push(flags);
    }
    cycles
}

/// Whether `from` (a group tag) transitively references `target`
/// through group member slots. `seen` bounds the walk; a schema-valid
/// document terminates immediately at depth 1.
fn reaches_back(
    groups: &[TreeGroup],
    from: &str,
    target: &str,
    seen: &mut HashSet<String>,
) -> bool {
    if from == target {
        return true;
    }
    if !seen.insert(from.to_owned()) {
        return false;
    }
    let Some(group) = groups.iter().find(|candidate| candidate.name == from) else {
        return false;
    };
    for member in &group.members {
        if let TreeMember::Group { name, .. } = member
            && reaches_back(groups, name.as_str(), target, seen)
        {
            return true;
        }
    }
    false
}

mod render;

pub use render::{badge_lane, render_human, render_json, strip_controls};

#[cfg(test)]
mod tests;
