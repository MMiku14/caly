//! Tests for [`super::subscription`] (extracted sibling).

use super::subscription::*;

fn unique_file(label: &str) -> std::path::PathBuf {
    crate::test_helpers::unique_file("sub", label)
}

fn write_then_inspect(label: &str, body: &str) -> Result<SubscriptionSummary, String> {
    let path = unique_file(label);
    std::fs::write(&path, body).map_err(|e| e.to_string())?;
    let summary = inspect_subscription_with_userinfo(&path, None);
    let _ = std::fs::remove_file(&path);
    summary
}

/// Builds a valid shadowsocks URI from a method:password pair.
fn ss_uri(method: &str, password: &str, host: &str, port: u16, name: &str) -> String {
    use base64::{Engine as _, engine::general_purpose};
    let credentials = general_purpose::STANDARD.encode(format!("{method}:{password}"));
    format!("ss://{credentials}@{host}:{port}#{name}")
}

#[test]
fn parses_direct_uri_lines() -> Result<(), String> {
    let a = ss_uri("aes-256-gcm", "pw1", "example.com", 8388, "node-a");
    let b = ss_uri("aes-128-gcm", "pw2", "example.org", 443, "node-b");
    let summary = write_then_inspect("direct", &format!("{a}\n{b}"))?;
    assert_eq!(summary.format, "uri-lines");
    assert!(summary.node_count >= 2);
    assert!(is_usable(&summary));
    assert!(summary.names.iter().any(|n| n == "node-a"));
    Ok(())
}

#[test]
fn detects_base64_aggregate() -> Result<(), String> {
    use base64::{Engine as _, engine::general_purpose};
    let a = ss_uri("aes-256-gcm", "pw1", "example.com", 8388, "a");
    let b = ss_uri("aes-128-gcm", "pw2", "example.org", 443, "b");
    let encoded = general_purpose::STANDARD.encode(format!("{a}\n{b}"));
    let summary = write_then_inspect("b64", &encoded)?;
    assert_eq!(summary.format, "base64-uri-lines");
    assert!(summary.node_count >= 2);
    Ok(())
}

#[test]
fn render_human_and_json_are_well_formed() -> Result<(), String> {
    let uri = ss_uri("aes-256-gcm", "pw1", "example.com", 8388, "node-x");
    let summary = write_then_inspect("render", &uri)?;
    let human = render_human(&summary);
    assert!(human.contains("format:"));
    assert!(human.contains("node-x"));
    let json = render_json(&summary);
    assert!(json.starts_with('{') && json.contains("\"nodes\""));
    Ok(())
}

#[test]
fn unusable_when_no_nodes() {
    let summary = write_then_inspect("garbage", "this is not a subscription");
    // Either it parses to zero nodes or errors; both are fine, but if it
    // parses it must be unusable.
    if let Ok(summary) = summary {
        assert!(!is_usable(&summary));
    }
}

#[test]
fn imports_mixed_protocol_uri_list_in_memory() -> Result<(), String> {
    // Mirrors `caly sub import`: an in-memory body with the protocols a
    // clipboard paste typically carries (vless/vmess/ss/hysteria2/trojan).
    // All credentials are placeholders (TEST-NET-3 / example.com); no
    // real subscription material may land in tests (privacy
    // audit before the public GitHub push).
    let vless = "vless://00000000-0000-0000-0000-000000000001@203.0.113.1:443?security=reality&type=tcp&packetEncoding=none&sni=example.com&fp=firefox&flow=xtls-rprx-vision&sid=0000000000000000&pbk=placeholder#DE_1";
    let vmess_line = "vmess://eyJhZGQiOiIyMDMuMC4xMTMuMSIsInBvcnQiOjQ0MywiaWQiOiIwMDAwMDAwMC0wMDAwLTAwMDAtMDAwMC0wMDAwMDAwMDAwMDEiLCJhaWQiOjAsIm5ldCI6InRjcCIsInRscyI6IiIsInBzIjoiVVMxIn0=";
    let hy2 = "hysteria2://test-password@example.com:443?insecure=1&sni=example.com#TW_1";
    let ss = ss_uri("aes-256-gcm", "pw1", "example.com", 8388, "node-a");
    let trojan = "trojan://test-trojan@example.com:443?sni=example.com&type=tcp#JP_2";
    let bad = "ssr://ssrnotrepresentable";
    let body = format!("{vless}\n{vmess_line}\n{hy2}\n{ss}\n{trojan}\n{bad}\nnot-a-uri");
    let summary = inspect_subscription(body.into_bytes(), None)?;
    assert_eq!(summary.format, "uri-lines");
    assert!(summary.node_count >= 5, "nodes={}", summary.node_count);
    assert_eq!(summary.rejected_lines, 1, "the bare text line rejects");
    assert_eq!(summary.ssr_skipped, 1);
    assert!(summary.names.contains(&"DE_1".to_owned()));
    assert!(summary.names.contains(&"TW_1".to_owned()));
    assert!(summary.names.contains(&"JP_2".to_owned()));
    Ok(())
}

#[test]
fn import_rejects_clipboard_without_tool_gracefully() {
    // `read_clipboard` degrades to a helpful error when no paste tool is
    // resolvable; it must never panic.
    let error = read_clipboard_with(&[("definitely-not-a-real-tool", &[])])
        .err()
        .unwrap_or_else(|| "clipboard read unexpectedly succeeded".to_owned());
    assert!(
        error.contains("no clipboard tool available"),
        "unexpected error: {error}"
    );
}

// ── W3a tree parse (`sub parse`) ────────────────────────────────

/// Small Clash document: one selector with a nested urltest group,
/// two nodes and one rule.
const TREE_YAML: &str = r#"
proxies:
  - {name: hk-01, type: vmess, server: a.example.com, port: 443, uuid: "11111111-1111-1111-1111-111111111111", alterId: 0, cipher: auto}
  - {name: us-02, type: ss, server: b.example.com, port: 8388, cipher: aes-256-gcm, password: pw}
proxy-groups:
  - {name: 节点选择, type: select, proxies: [自动选择, hk-01, DIRECT]}
  - {name: 自动选择, type: url-test, proxies: [hk-01, us-02], url: "http://cp.example.com/generate_204", interval: 600, tolerance: 200}
rules:
  - DOMAIN-SUFFIX,example.com,节点选择
"#;

#[test]
fn clash_yaml_parses_to_full_tree() -> Result<(), String> {
    let outcome = parse_subscription_tree_body(TREE_YAML.as_bytes().to_vec(), None)?;
    match &outcome {
        ParseOutcome::Tree {
            tree,
            rejected_lines,
            ssr_skipped,
            ..
        } => {
            assert_eq!(tree.format, "clash-yaml");
            assert_eq!(tree.groups.len(), 2);
            assert_eq!(tree.protocol_count(), 2);
            assert_eq!(tree.rules.len(), 1);
            assert_eq!(*rejected_lines, 0);
            assert_eq!(*ssr_skipped, 0);
            let human = render_tree_human(&outcome);
            assert!(human.contains("[selector]     节点选择"), "human: {human}");
            assert!(human.contains("rules zone"), "human: {human}");
            assert!(
                !human.contains("rejected"),
                "clean doc has no note: {human}"
            );
            let json = render_tree_json(&outcome);
            assert!(json.contains("\"counts\""), "json: {json}");
            assert!(json.contains("\"ok\":true"), "json: {json}");
        }
        ParseOutcome::Summary(_) => panic!("expected tree, got summary"),
    }
    Ok(())
}

#[test]
fn uri_lines_degrade_to_protocol_listing_with_notes() -> Result<(), String> {
    let ss = ss_uri("aes-256-gcm", "pw1", "example.com", 8388, "node-a");
    let body = format!("{ss}\nnot-a-uri\nssr://skipped");
    let outcome = parse_subscription_tree_body(body.as_bytes().to_vec(), None)?;
    match &outcome {
        ParseOutcome::Tree {
            tree,
            rejected_lines,
            ssr_skipped,
            ..
        } => {
            assert_eq!(tree.format, "uri-lines");
            assert!(!tree.has_groups());
            assert_eq!(tree.ungrouped.len(), 1);
            assert_eq!(*rejected_lines, 1);
            assert_eq!(*ssr_skipped, 1);
            let human = render_tree_human(&outcome);
            assert!(human.contains("# 1 line(s) rejected"), "human: {human}");
            assert!(human.contains("# 1 SSR node(s) skipped"), "human: {human}");
            // The listing carries no zone title (degenerate form).
            assert!(!human.contains("未入组节点"), "human: {human}");
            let json = render_tree_json(&outcome);
            assert!(!json.contains("rejected"), "notes never reach JSON: {json}");
        }
        ParseOutcome::Summary(_) => panic!("expected tree, got summary"),
    }
    Ok(())
}

#[test]
fn url_list_keeps_the_legacy_summary_shape() -> Result<(), String> {
    let body = "https://a.example.com/sub\nhttps://b.example.com/sub";
    let outcome = parse_subscription_tree_body(body.as_bytes().to_vec(), None)?;
    match &outcome {
        ParseOutcome::Summary(summary) => {
            assert_eq!(summary.format, "url-list");
            assert_eq!(summary.names.len(), 2);
            assert!(outcome.is_usable());
            let human = render_tree_human(&outcome);
            assert!(human.contains("entries:"), "human: {human}");
        }
        ParseOutcome::Tree { .. } => panic!("expected summary, got tree"),
    }
    Ok(())
}

#[test]
fn ssr_only_document_keeps_the_legacy_summary_shape() -> Result<(), String> {
    let body = "ssr://ssrnotrepresentable\nssr://anotherone";
    let outcome = parse_subscription_tree_body(body.as_bytes().to_vec(), None)?;
    match &outcome {
        ParseOutcome::Summary(summary) => {
            assert_eq!(summary.format, "ssr-only");
            assert_eq!(summary.ssr_skipped, 2);
            assert!(!outcome.is_usable());
        }
        ParseOutcome::Tree { .. } => panic!("expected summary, got tree"),
    }
    Ok(())
}

#[test]
fn unusable_tree_exits_nonzero_but_renders() -> Result<(), String> {
    // A Clash document with no nodes is a parse success but unusable;
    // the tree render still works and `is_usable` is false.
    let body = "proxies: []\nproxy-groups: []\nrules: []\n";
    let outcome = parse_subscription_tree_body(body.as_bytes().to_vec(), None)?;
    match &outcome {
        ParseOutcome::Tree { .. } => {
            assert!(!outcome.is_usable());
            assert_eq!(render_tree_human(&outcome), "(no entries)\n");
        }
        ParseOutcome::Summary(_) => panic!("expected tree, got summary"),
    }
    Ok(())
}
