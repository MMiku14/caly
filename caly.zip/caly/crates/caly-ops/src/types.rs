//! Frontend-agnostic option/spec types shared by the CLI and the TUI.
//!
//! Moved out of `caly-cli`'s grammar module (`cli.rs`): the operations in
//! [`crate::client`] take these shapes, and both frontends construct them.
//! The CLI grammar keeps its clap-bound twins (e.g. `Editor` as a `ValueEnum`)
//! and maps them onto these plain enums at the dispatch boundary.

use std::path::PathBuf;

#[derive(Clone, Debug, Default, Eq, PartialEq)]
pub struct CliOptions {
    pub socket: Option<PathBuf>,
    pub json: bool,
    pub core: Option<String>,
    pub mihomo_bin: Option<PathBuf>,
    pub sing_box_bin: Option<PathBuf>,
    pub format: Option<OutputFormat>,
}

/// W2 (cli-v3-design.md §5.1): user-pinned list output mode.
/// Owned by the layout suite (`caly_layout::OutputFormat`),
/// re-exported here so option types keep one import root.
pub use caly_layout::OutputFormat;

/// Public type-kind spec for the `set proxy-group add` leaf.
/// Mirrors the kebab-case `type:` field the rendered Mihomo
/// config uses; the dispatch converts to the schema enum.
#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub enum ProxyGroupTypeSpec {
    Select,
    UrlTest,
    Fallback,
    LoadBalance,
    Relay,
}

/// Editor choice for `config edit`, without the clap `ValueEnum`
/// derive (that twin stays grammar-side; the dispatch maps it).
#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub enum Editor {
    Vim,
    Nvim,
}
