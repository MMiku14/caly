//! Embedded known-good release manifest + official URL templates.
//!
//! The table pins the versions CI exercises (mirrored from
//! `vendor/kernels.lock.toml` at the time of writing — same URLs, same
//! archive+binary sha256); `core upgrade` moves the store to these.
//! Explicit-version installs (`core install mihomo@1.18.0`) build the URL
//! from the template and self-verify by executing the binary, since no
//! hash is recorded for unpinned versions.

/// One pinned upstream release.
#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub struct Release {
    pub kernel: &'static str,
    pub version: &'static str,
    pub url: &'static str,
    pub archive_sha256: &'static str,
    pub binary_sha256: &'static str,
}

/// Known-good pins (linux-amd64; mihomo uses the `-compatible` baseline
/// build so it runs without AVX2 — see the lockfile NOTE).
pub const MANIFEST: &[Release] = &[
    Release {
        kernel: "mihomo",
        version: "1.19.29",
        url: "https://github.com/MetaCubeX/mihomo/releases/download/v1.19.29/mihomo-linux-amd64-compatible-v1.19.29.gz",
        archive_sha256:
            "5612e698e96c8b8ad15abc4c0a4f098eba9234354b4f248cb97f2528e215b094",
        binary_sha256:
            "bd2a08ae155b7dffc12a1bdf610ff5f17c45058414a1d2c562e28eb9309abff6",
    },
    Release {
        kernel: "sing-box",
        version: "1.13.14",
        url: "https://github.com/SagerNet/sing-box/releases/download/v1.13.14/sing-box-1.13.14-linux-amd64.tar.gz",
        archive_sha256:
            "f48703461a15476951ac4967cdad339d986f4b8096b4eb3ff0829a500502d697",
        binary_sha256:
            "68aeab83cc4ab2659a5b92232261a20746ccdafc3b3d1e19b2d63247eec3bbf7",
    },
];

/// The pinned release for `kernel`, if any.
pub fn latest(kernel: &str) -> Option<&'static Release> {
    MANIFEST.iter().find(|entry| entry.kernel == kernel)
}

/// Builds the official download URL for an explicit version. The version
/// must be strict `major.minor.patch` (digits only) — anything else is
/// refused BEFORE interpolation so a hostile version string can never
/// reshape the URL.
pub fn release_url(kernel: &str, version: &str) -> Result<String, String> {
    if !is_strict_version(version) {
        return Err(format!(
            "version `{version}` is not strict major.minor.patch (digits only)"
        ));
    }
    match kernel {
        "mihomo" => Ok(format!(
            "https://github.com/MetaCubeX/mihomo/releases/download/v{version}/mihomo-linux-amd64-compatible-v{version}.gz"
        )),
        "sing-box" => Ok(format!(
            "https://github.com/SagerNet/sing-box/releases/download/v{version}/sing-box-{version}-linux-amd64.tar.gz"
        )),
        other => Err(format!("unknown kernel `{other}`")),
    }
}

fn is_strict_version(version: &str) -> bool {
    let parts: Vec<&str> = version.split('.').collect();
    parts.len() == 3
        && parts
            .iter()
            .all(|part| !part.is_empty() && part.bytes().all(|byte| byte.is_ascii_digit()))
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn templates_match_the_pinned_urls() {
        for release in MANIFEST {
            let built = release_url(release.kernel, release.version).expect("pinned builds");
            assert_eq!(built, release.url);
        }
    }

    #[test]
    fn hostile_versions_are_rejected_before_interpolation() {
        for hostile in [
            "../evil",
            "1.2.3/../../../../x",
            "1.2.3?x=1",
            "v1.2.3",
            "1.2",
            "1.2.3.4",
            "",
        ] {
            assert!(
                release_url("mihomo", hostile).is_err(),
                "{hostile} must be rejected"
            );
        }
    }
}
