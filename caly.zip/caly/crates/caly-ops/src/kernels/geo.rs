//! Mihomo geodata updates (GeoIP.dat / GeoSite.dat / geoip.metadb).
//!
//! The daemon's mihomo work dir is ephemeral (`runtime/cores/mihomo`), so
//! geodata cannot live there durably: this module keeps a versioned store
//! under `<data>/geo/` refreshed from MetaCubeX's daily `meta-rules-dat`
//! (mihomo's own org; content tracks Loyalsoldier's builds plus extra
//! categories), and the daemon seeds its work dir from the store at boot.
//!
//! sing-box needs no file management here: caly renders GEOIP/GEOSITE as
//! remote `.srs` rule-sets (`caly-coreconf/src/rules.rs`), which sing-box
//! downloads and refreshes itself.
//!
//! Freshness is sidecar-compared: each asset ships a `.sha256sum` file; an
//! upgrade fetches the tiny sidecars first and downloads only assets whose
//! local hash differs (missing counts as different). File bytes are verified
//! against the sidecar hash before they are placed — a truncated or
//! corrupted download never lands in the store.

use std::path::{Path, PathBuf};

use super::{block_on_fetch, hex_sha256};

/// One managed geodata asset.
#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub struct GeoAsset {
    /// Store filename (lowercase, as published).
    pub name: &'static str,
    /// Filename mihomo expects in its work dir.
    pub work_name: &'static str,
    pub url: &'static str,
    pub sha_url: &'static str,
}

/// Managed set (meta-rules-dat `latest` release; both file and sidecar ride
/// the release-asset redirect chain the fetch allowlist already covers).
pub const GEO_ASSETS: &[GeoAsset] = &[
    GeoAsset {
        name: "geoip.dat",
        work_name: "GeoIP.dat",
        url: "https://github.com/MetaCubeX/meta-rules-dat/releases/latest/download/geoip.dat",
        sha_url:
            "https://github.com/MetaCubeX/meta-rules-dat/releases/latest/download/geoip.dat.sha256sum",
    },
    GeoAsset {
        name: "geosite.dat",
        work_name: "GeoSite.dat",
        url: "https://github.com/MetaCubeX/meta-rules-dat/releases/latest/download/geosite.dat",
        sha_url:
            "https://github.com/MetaCubeX/meta-rules-dat/releases/latest/download/geosite.dat.sha256sum",
    },
    GeoAsset {
        name: "geoip.metadb",
        work_name: "geoip.metadb",
        url: "https://github.com/MetaCubeX/meta-rules-dat/releases/latest/download/geoip.metadb",
        sha_url:
            "https://github.com/MetaCubeX/meta-rules-dat/releases/latest/download/geoip.metadb.sha256sum",
    },
];

/// Durable geodata store under the data dir.
pub fn geo_dir(data_dir: &Path) -> PathBuf {
    data_dir.join("geo")
}

/// A stored geodata file (offline facts for `core versions`).
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct GeoFile {
    pub name: String,
    pub path: PathBuf,
    pub bytes: u64,
    pub sha256: String,
}

/// Scans the store: one [`GeoFile`] per managed asset present on disk
/// (missing assets are simply absent — no network, no failure).
pub fn scan_geo(data_dir: &Path) -> Vec<GeoFile> {
    let root = geo_dir(data_dir);
    let mut found = Vec::new();
    for asset in GEO_ASSETS {
        let path = root.join(asset.name);
        let Ok(bytes) = std::fs::read(&path) else {
            continue;
        };
        found.push(GeoFile {
            name: asset.name.to_owned(),
            path,
            bytes: bytes.len() as u64,
            sha256: hex_sha256(&bytes),
        });
    }
    found
}

/// Per-asset upgrade outcome.
#[derive(Clone, Debug, Eq, PartialEq)]
pub enum GeoOutcome {
    UpToDate { name: String },
    Updated { name: String, bytes: u64 },
    Failed { name: String, reason: String },
}

/// Refreshes every managed asset: sidecar first (freshness check), file
/// bytes only when the local hash differs. One asset's failure never
/// aborts the rest — the caller folds failures into its exit code.
pub fn update_geo(data_dir: &Path) -> Vec<GeoOutcome> {
    GEO_ASSETS
        .iter()
        .map(|asset| update_one(&geo_dir(data_dir), asset))
        .collect()
}

/// Testable core: refresh one asset from explicit URLs.
fn update_one(store: &Path, asset: &GeoAsset) -> GeoOutcome {
    update_one_from(store, asset.name, asset.url, asset.sha_url)
}

pub(crate) fn update_one_from(store: &Path, name: &str, url: &str, sha_url: &str) -> GeoOutcome {
    let failed = |reason: String| GeoOutcome::Failed {
        name: name.to_owned(),
        reason,
    };
    let sidecar = match block_on_fetch(sha_url, None) {
        Ok(bytes) => bytes,
        Err(reason) => return failed(format!("sidecar fetch failed: {reason}")),
    };
    let Some(expected) = parse_sidecar(&sidecar) else {
        return failed("sidecar is not `<sha256>  <file>`".to_owned());
    };
    let target = store.join(name);
    if let Ok(local) = std::fs::read(&target)
        && hex_sha256(&local).eq_ignore_ascii_case(&expected)
    {
        return GeoOutcome::UpToDate {
            name: name.to_owned(),
        };
    }
    let bytes = match block_on_fetch(url, Some(&expected)) {
        Ok(bytes) => bytes,
        Err(reason) => return failed(format!("download failed: {reason}")),
    };
    if let Err(reason) = place_file(&target, &bytes) {
        return failed(reason);
    }
    GeoOutcome::Updated {
        name: name.to_owned(),
        bytes: bytes.len() as u64,
    }
}

/// Parses `<sha256><spaces><filename>` (the meta-rules-dat sidecar shape);
/// refuses anything that is not 64 lowercase-or-upper hex.
fn parse_sidecar(sidecar: &[u8]) -> Option<String> {
    let text = std::str::from_utf8(sidecar).ok()?;
    let hash = text.split_whitespace().next()?;
    if hash.len() == 64 && hash.bytes().all(|byte| byte.is_ascii_hexdigit()) {
        Some(hash.to_owned())
    } else {
        None
    }
}

/// Atomic place: temp file + fsync + rename, so a crash never leaves a
/// half-written database under the live name.
fn place_file(target: &Path, bytes: &[u8]) -> Result<(), String> {
    if let Some(parent) = target.parent()
        && let Err(error) = std::fs::create_dir_all(parent)
    {
        return Err(format!("cannot create {}: {error}", parent.display()));
    }
    let tmp = target.with_extension("tmp");
    std::fs::write(&tmp, bytes).map_err(|error| format!("cannot stage {}: {error}", tmp.display()))?;
    std::fs::rename(&tmp, target)
        .map_err(|error| format!("cannot place {}: {error}", target.display()))?;
    Ok(())
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn sidecar_shapes() {
        assert_eq!(
            parse_sidecar(b"c5fe9448d979391192f5bd553b5e28c39efdc9bd857b7c879a7d995fded0c3fe  geosite.dat\n"),
            Some("c5fe9448d979391192f5bd553b5e28c39efdc9bd857b7c879a7d995fded0c3fe".to_owned())
        );
        assert_eq!(parse_sidecar(b"not-a-hash  x.dat\n"), None);
        assert_eq!(parse_sidecar(b""), None);
        assert_eq!(parse_sidecar(&vec![0xffu8; 80]), None);
    }

    #[test]
    fn scan_lists_only_present_assets() {
        let dir = crate::test_helpers::temp_root("geo-scan");
        assert!(scan_geo(&dir).is_empty());
        let root = geo_dir(&dir);
        std::fs::create_dir_all(&root).expect("mkdir");
        std::fs::write(root.join("geoip.dat"), b"fake-db").expect("seed");
        let found = scan_geo(&dir);
        assert_eq!(found.len(), 1);
        assert_eq!(found[0].name, "geoip.dat");
        assert_eq!(found[0].bytes, 7);
        assert_eq!(found[0].sha256, hex_sha256(b"fake-db"));
    }

    /// Serves path→body routes from a loopback socket; returns the base URL.
    async fn serve_routes(routes: Vec<(String, Vec<u8>)>) -> String {
        let listener = tokio::net::TcpListener::bind("127.0.0.1:0")
            .await
            .expect("bind loopback");
        let address = listener.local_addr().expect("local addr");
        tokio::spawn(async move {
            loop {
                let Ok((mut socket, _)) = listener.accept().await else {
                    return;
                };
                use tokio::io::{AsyncReadExt as _, AsyncWriteExt as _};
                let mut request = vec![0u8; 1024];
                let Ok(count) = socket.read(&mut request).await else {
                    continue;
                };
                let head = String::from_utf8_lossy(&request[..count]);
                let path = head
                    .split_whitespace()
                    .nth(1)
                    .unwrap_or("/")
                    .to_owned();
                let body = routes
                    .iter()
                    .find(|(route, _)| *route == path)
                    .map(|(_, body)| body.clone())
                    .unwrap_or_default();
                let status = if body.is_empty() {
                    "HTTP/1.1 404 Not Found"
                } else {
                    "HTTP/1.1 200 OK"
                };
                let head = format!(
                    "{status}\r\ncontent-length: {}\r\nconnection: close\r\n\r\n",
                    body.len()
                );
                if socket.write_all(head.as_bytes()).await.is_err() {
                    continue;
                }
                let _ = socket.write_all(&body).await;
            }
        });
        format!("http://{address}")
    }

    #[test]
    fn update_round_trips_through_a_loopback_fixture() {
        let runtime = tokio::runtime::Builder::new_multi_thread()
            .enable_all()
            .build()
            .expect("test runtime");
        let payload = b"fake-geodb-bytes".to_vec();
        let digest = hex_sha256(&payload);
        let sidecar = format!("{digest}  geoip.dat\n").into_bytes();
        let base = runtime.block_on(serve_routes(vec![
            ("/geoip.dat".to_owned(), payload.clone()),
            ("/geoip.dat.sha256sum".to_owned(), sidecar),
        ]));
        let dir = crate::test_helpers::temp_root("geo-update");
        let store = geo_dir(&dir);
        // First pass downloads (missing counts as stale)…
        match update_one_from(&store, "geoip.dat", &format!("{base}/geoip.dat"), &format!("{base}/geoip.dat.sha256sum")) {
            GeoOutcome::Updated { bytes, .. } => assert_eq!(bytes, payload.len() as u64),
            other => panic!("expected Updated, got {other:?}"),
        }
        assert_eq!(std::fs::read(store.join("geoip.dat")).expect("placed"), payload);
        // …second pass is a cheap sidecar-only no-op…
        assert!(matches!(
            update_one_from(&store, "geoip.dat", &format!("{base}/geoip.dat"), &format!("{base}/geoip.dat.sha256sum")),
            GeoOutcome::UpToDate { .. }
        ));
        // …and a corrupt sidecar fails the asset without touching the store.
        let bad_base = runtime.block_on(serve_routes(vec![(
            "/geoip.dat.sha256sum".to_owned(),
            b"bogus\n".to_vec(),
        )]));
        assert!(matches!(
            update_one_from(
                &store,
                "geoip.dat",
                &format!("{bad_base}/geoip.dat"),
                &format!("{bad_base}/geoip.dat.sha256sum")
            ),
            GeoOutcome::Failed { .. }
        ));
        assert_eq!(std::fs::read(store.join("geoip.dat")).expect("kept"), payload);
    }
}
