//! Kernel version probing: execute the binary's version flag and parse
//! the self-reported version. Never fails hard — an unparseable or
//! unrunnable binary reports `version: None` with the raw first line, so
//! `core versions` stays truthful instead of crashing on a stray file.

use std::path::Path;
use std::process::Command;
use std::time::Duration;

/// How long a version-flag invocation may run before it is killed.
const PROBE_TIMEOUT: Duration = Duration::from_secs(10);

/// Flag attempts in order: mihomo answers `-v`, sing-box answers
/// `version`; the rest are defensive fallbacks.
const FLAG_ORDER: &[&str] = &["-v", "version", "--version", "-version"];

/// What one probe learned.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct ProbeReport {
    /// Normalized `major.minor.patch` (leading `v` stripped), or `None`
    /// when no flag produced a parseable version.
    pub version: Option<String>,
    /// First stdout line of the winning invocation (stderr when stdout
    /// was empty), or the failure note when nothing ran.
    pub raw_line: String,
}

/// Probes `path` for its self-reported version.
pub fn probe_version(path: &Path) -> ProbeReport {
    let mut last_note = format!("{} is not runnable", path.display());
    for flag in FLAG_ORDER {
        match run_flag(path, flag) {
            Ok(line) => {
                if let Some(version) = parse_version(&line) {
                    return ProbeReport {
                        version: Some(version),
                        raw_line: line,
                    };
                }
                last_note = line;
            }
            Err(note) => last_note = note,
        }
    }
    ProbeReport {
        version: None,
        raw_line: last_note,
    }
}

/// Runs `path flag`, returning the first output line (stdout preferred,
/// stderr as fallback). Timeout, spawn failure and empty output are all
/// soft errors carrying a human note.
fn run_flag(path: &Path, flag: &str) -> Result<String, String> {
    let mut child = Command::new(path)
        .arg(flag)
        .stdin(std::process::Stdio::null())
        .stdout(std::process::Stdio::piped())
        .stderr(std::process::Stdio::piped())
        .spawn()
        .map_err(|error| format!("cannot run {}: {error}", path.display()))?;
    // Poll-then-kill (no `wait-timeout` dependency for one call site):
    // version output is one line, far below the pipe buffer, so reading
    // the pipes after exit cannot deadlock.
    let deadline = std::time::Instant::now() + PROBE_TIMEOUT;
    let status = loop {
        match child.try_wait() {
            Ok(Some(status)) => break status,
            Ok(None) => {
                if std::time::Instant::now() >= deadline {
                    let _ = child.kill();
                    let _ = child.wait();
                    return Err(format!(
                        "probe of {} timed out after {}s",
                        path.display(),
                        PROBE_TIMEOUT.as_secs()
                    ));
                }
                std::thread::sleep(Duration::from_millis(25));
            }
            Err(error) => {
                return Err(format!("probe of {} failed: {error}", path.display()));
            }
        }
    };
    let mut stdout = Vec::new();
    let mut stderr = Vec::new();
    if let Some(mut pipe) = child.stdout.take() {
        use std::io::Read as _;
        let _ = pipe.read_to_end(&mut stdout);
    }
    if let Some(mut pipe) = child.stderr.take() {
        use std::io::Read as _;
        let _ = pipe.read_to_end(&mut stderr);
    }
    let output = std::process::Output {
        status,
        stdout,
        stderr,
    };
    if !output.status.success() {
        return Err(format!(
            "{} {flag} exited {}",
            path.display(),
            output.status.code().unwrap_or(-1)
        ));
    }
    let line = first_line(&output.stdout).or_else(|| first_line(&output.stderr));
    line.map_or_else(
        || Err(format!("{} {flag} printed nothing", path.display())),
        Ok,
    )
}

fn first_line(bytes: &[u8]) -> Option<String> {
    let text = String::from_utf8_lossy(bytes);
    let line = text.lines().next()?.trim();
    if line.is_empty() {
        return None;
    }
    Some(line.chars().take(160).collect())
}

/// Extracts the first `v?major.minor[.patch]` token, normalized without
/// the `v` prefix. Regex-free scan (no new dependency for one pattern).
fn parse_version(line: &str) -> Option<String> {
    let bytes = line.as_bytes();
    let mut index = 0;
    while index < bytes.len() {
        let mut cursor = index;
        if bytes[cursor] == b'v' && cursor + 1 < bytes.len() && bytes[cursor + 1].is_ascii_digit() {
            cursor += 1;
        }
        if bytes[cursor].is_ascii_digit() {
            let major_start = cursor;
            while cursor < bytes.len() && bytes[cursor].is_ascii_digit() {
                cursor += 1;
            }
            if cursor < bytes.len() && bytes[cursor] == b'.' {
                cursor += 1;
                let minor_start = cursor;
                while cursor < bytes.len() && bytes[cursor].is_ascii_digit() {
                    cursor += 1;
                }
                if minor_start < cursor {
                    let mut end = cursor;
                    if cursor + 1 < bytes.len()
                        && bytes[cursor] == b'.'
                        && bytes[cursor + 1].is_ascii_digit()
                    {
                        cursor += 1;
                        while cursor < bytes.len() && bytes[cursor].is_ascii_digit() {
                            cursor += 1;
                        }
                        end = cursor;
                    }
                    return Some(line[major_start..end].to_owned());
                }
            }
        }
        index += 1;
    }
    None
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn parses_common_version_lines() {
        assert_eq!(
            parse_version("Mihomo Meta v1.19.29 linux amd64"),
            Some("1.19.29".to_owned())
        );
        assert_eq!(
            parse_version("sing-box version 1.13.14"),
            Some("1.13.14".to_owned())
        );
        assert_eq!(parse_version("v2.0"), Some("2.0".to_owned()));
        assert_eq!(parse_version("no version here"), None);
        assert_eq!(parse_version(""), None);
    }

    #[test]
    fn probe_reports_unknown_for_missing_binary() {
        let report = probe_version(Path::new("/nonexistent/caly-probe-test"));
        assert_eq!(report.version, None);
        assert!(!report.raw_line.is_empty());
    }

    #[test]
    fn probe_runs_a_script_stand_in() {
        let dir = crate::test_helpers::temp_root("kernel-probe");
        let script = dir.join("fake-mihomo");
        std::fs::write(&script, "#!/bin/sh\necho 'Mihomo Meta v1.19.29 linux amd64'\n")
            .expect("write fixture script");
        #[cfg(unix)]
        {
            use std::os::unix::fs::PermissionsExt as _;
            let mut permissions = std::fs::metadata(&script)
                .expect("stat fixture")
                .permissions();
            permissions.set_mode(0o755);
            std::fs::set_permissions(&script, permissions).expect("chmod fixture");
        }
        let report = probe_version(&script);
        assert_eq!(report.version, Some("1.19.29".to_owned()));
    }
}
