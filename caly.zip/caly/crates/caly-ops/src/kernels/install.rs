//! Kernel installation: download → verify → extract → probe → place.
//!
//! Two trust paths: manifest-pinned releases verify the archive AND the
//! extracted binary against recorded sha256; explicit-version installs
//! (no recorded hash) self-verify by executing the binary's version flag
//! and requiring the expected version in its output. Nothing is placed
//! into the store until every check passes.

use std::io::Read as _;
use std::path::{Path, PathBuf};

use super::manifest::{latest, release_url};
use super::{block_on_fetch, hex_sha256};
use super::probe::probe_version;
use super::store::{binary_name, kernels_dir, normalize_kernel};

/// Decompression bomb guard (a ~30 MB kernel never expands past this).
const MAX_DECOMPRESSED_BYTES: u64 = 256 * 1024 * 1024;

/// What verified this install.
#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub enum VerifiedBy {
    /// Archive + binary sha256 matched the manifest pins.
    ManifestHash,
    /// No recorded hash: the binary self-reported the expected version.
    SelfReport,
}

/// A completed install.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct InstallReport {
    pub kernel: String,
    pub version: String,
    pub path: PathBuf,
    pub verified: VerifiedBy,
}

/// Installs the manifest-pinned release for `kernel` (hash-verified).
pub fn install_latest(data_dir: &Path, kernel: &str, force: bool) -> Result<InstallReport, String> {
    let kernel = normalize_kernel(kernel)?;
    let release = latest(kernel).ok_or_else(|| format!("no pinned release for {kernel}"))?;
    install_from_url(
        data_dir,
        release.kernel,
        release.version,
        release.url,
        Some(release.archive_sha256),
        Some(release.binary_sha256),
        force,
    )
}

/// Installs an explicit version from the official URL template. No hash is
/// recorded for unpinned versions, so the binary self-verifies by executing
/// its version flag (a mismatch aborts before anything is placed).
pub fn install_version(
    data_dir: &Path,
    kernel: &str,
    version: &str,
    force: bool,
) -> Result<InstallReport, String> {
    let kernel = normalize_kernel(kernel)?;
    if let Some(pinned) = latest(kernel)
        && pinned.version == version
    {
        return install_latest(data_dir, kernel, force);
    }
    let url = release_url(kernel, version)?;
    install_from_url(data_dir, kernel, version, &url, None, None, force)
}

/// Shared installer core. Exported (crate-visible) so tests can point it at
/// a loopback fixture server; production callers go through
/// [`install_latest`] / [`install_version`].
#[allow(clippy::too_many_arguments)]
pub(crate) fn install_from_url(
    data_dir: &Path,
    kernel: &str,
    expected_version: &str,
    url: &str,
    archive_sha256: Option<&str>,
    binary_sha256: Option<&str>,
    force: bool,
) -> Result<InstallReport, String> {
    let version_dir = kernels_dir(data_dir)
        .join(kernel)
        .join(expected_version);
    if version_dir.is_dir() && !force {
        return Err(format!(
            "{kernel} {expected_version} is already installed ({}; pass --force to reinstall)",
            version_dir.display()
        ));
    }
    let archive = block_on_fetch(url, archive_sha256)?;
    let binary_bytes = extract_binary(kernel, url, &archive)?;
    if let Some(expected) = binary_sha256 {
        let actual = hex_sha256(&binary_bytes);
        if !actual.eq_ignore_ascii_case(expected) {
            return Err(format!(
                "binary sha256 mismatch (expected {expected}, got {actual})"
            ));
        }
    }
    // Stage outside the store, probe, then move in: the store never holds
    // an unverified binary, even if the probe crashes the process.
    let stage = data_dir.join(format!(".kernels-stage-{kernel}-{expected_version}"));
    if stage.exists() {
        let _ = std::fs::remove_dir_all(&stage);
    }
    std::fs::create_dir_all(&stage)
        .map_err(|error| format!("cannot stage install: {error}"))?;
    let staged = stage.join(binary_name(kernel));
    std::fs::write(&staged, &binary_bytes)
        .map_err(|error| format!("cannot stage install: {error}"))?;
    #[cfg(unix)]
    {
        use std::os::unix::fs::PermissionsExt as _;
        let mut permissions = std::fs::metadata(&staged)
            .map_err(|error| format!("cannot stage install: {error}"))?
            .permissions();
        permissions.set_mode(0o755);
        std::fs::set_permissions(&staged, permissions)
            .map_err(|error| format!("cannot stage install: {error}"))?;
    }
    let cleanup_stage = |message: String| {
        let _ = std::fs::remove_dir_all(&stage);
        message
    };
    let probed = probe_version(&staged).version.ok_or_else(|| {
        cleanup_stage(format!(
            "{kernel} {expected_version} failed its self-check: the downloaded binary reports no version"
        ))
    })?;
    if probed != expected_version {
        return Err(cleanup_stage(format!(
            "{kernel} {expected_version} failed its self-check: the binary reports {probed}"
        )));
    }
    if version_dir.is_dir() {
        std::fs::remove_dir_all(&version_dir)
            .map_err(|error| format!("cannot clear {}: {error}", version_dir.display()))?;
    }
    if let Some(parent) = version_dir.parent() {
        std::fs::create_dir_all(parent)
            .map_err(|error| format!("cannot create {}: {error}", parent.display()))?;
    }
    std::fs::rename(&stage, &version_dir)
        .map_err(|error| format!("cannot place {}: {error}", version_dir.display()))?;
    Ok(InstallReport {
        kernel: kernel.to_owned(),
        version: expected_version.to_owned(),
        path: version_dir.join(binary_name(kernel)),
        verified: if binary_sha256.is_some() {
            VerifiedBy::ManifestHash
        } else {
            VerifiedBy::SelfReport
        },
    })
}

/// Extracts the kernel executable from the downloaded archive. Mihomo
/// ships a bare `.gz` (single stream); sing-box ships a `.tar.gz` whose
/// member is found by exact file name at any depth.
fn extract_binary(kernel: &str, url: &str, archive: &[u8]) -> Result<Vec<u8>, String> {
    if url.ends_with(".tar.gz") {
        extract_tar_member(binary_name(kernel), archive)
    } else if url.ends_with(".gz") {
        gunzip_single(archive)
    } else {
        Err(format!("unsupported archive shape for {kernel} ({url})"))
    }
}

fn gunzip_single(archive: &[u8]) -> Result<Vec<u8>, String> {
    let decoder = flate2::read::GzDecoder::new(archive);
    let mut out = Vec::new();
    decoder
        .take(MAX_DECOMPRESSED_BYTES + 1)
        .read_to_end(&mut out)
        .map_err(|error| format!("cannot decompress archive: {error}"))?;
    if out.len() as u64 > MAX_DECOMPRESSED_BYTES {
        return Err("archive expands past 256 MiB; refusing".to_owned());
    }
    Ok(out)
}

fn extract_tar_member(member: &str, archive: &[u8]) -> Result<Vec<u8>, String> {
    let decoder = flate2::read::GzDecoder::new(archive);
    let mut tar = tar::Archive::new(decoder);
    let entries = tar
        .entries()
        .map_err(|error| format!("cannot read archive: {error}"))?;
    for entry in entries {
        let entry = entry.map_err(|error| format!("cannot read archive: {error}"))?;
        let is_file = entry
            .header()
            .entry_type()
            .is_file();
        if !is_file {
            continue;
        }
        let name = entry
            .path()
            .map_err(|error| format!("cannot read archive: {error}"))?;
        if name.file_name().is_some_and(|base| base == member) {
            let mut out = Vec::new();
            entry
                .take(MAX_DECOMPRESSED_BYTES + 1)
                .read_to_end(&mut out)
                .map_err(|error| format!("cannot read archive: {error}"))?;
            if out.len() as u64 > MAX_DECOMPRESSED_BYTES {
                return Err("archive expands past 256 MiB; refusing".to_owned());
            }
            return Ok(out);
        }
    }
    Err(format!("archive has no `{member}` member"))
}

#[cfg(test)]
mod tests {
    use super::*;

    /// Gzips `payload` into a bare single-stream archive.
    fn gzip(payload: &[u8]) -> Vec<u8> {
        use flate2::Compression;
        use flate2::write::GzEncoder;
        use std::io::Write as _;
        let mut encoder = GzEncoder::new(Vec::new(), Compression::fast());
        encoder.write_all(payload).expect("gzip fixture");
        encoder.finish().expect("finish gzip")
    }

    /// Builds a `.tar.gz` containing one file at a nested path.
    fn targz(path: &str, payload: &[u8]) -> Vec<u8> {
        use flate2::Compression;
        use flate2::write::GzEncoder;
        let tarred = {
            let mut builder = tar::Builder::new(Vec::new());
            let mut header = tar::Header::new_gnu();
            header.set_size(payload.len() as u64);
            header.set_mode(0o755);
            header.set_cksum();
            builder
                .append_data(&mut header, path, payload)
                .expect("append fixture");
            builder.into_inner().expect("finish tar")
        };
        let mut encoder = GzEncoder::new(Vec::new(), Compression::fast());
        use std::io::Write as _;
        encoder.write_all(&tarred).expect("gzip tar");
        encoder.finish().expect("finish gzip")
    }

    /// Serves `archive` from a loopback socket; returns the base URL.
    async fn serve_fixture(archive: Vec<u8>) -> String {
        let listener = tokio::net::TcpListener::bind("127.0.0.1:0")
            .await
            .expect("bind loopback");
        let address = listener.local_addr().expect("local addr");
        tokio::spawn(async move {
                let (mut socket, _) = listener.accept().await.expect("accept");
                use tokio::io::{AsyncReadExt as _, AsyncWriteExt as _};
            let mut request = vec![0u8; 1024];
            let _ = socket.read(&mut request).await;
            let head = format!(
                "HTTP/1.1 200 OK\r\ncontent-length: {}\r\nconnection: close\r\n\r\n",
                archive.len()
            );
            let _ = socket.write_all(head.as_bytes()).await;
            let _ = socket.write_all(&archive).await;
            });
        format!("http://{address}")
    }

    #[test]
    fn extracts_both_archive_shapes() {
        let script = b"#!/bin/sh\necho hi\n";
        assert_eq!(
            extract_binary("mihomo", "https://x/mihomo.gz", &gzip(script)).expect("gz"),
            script
        );
        assert_eq!(
            extract_binary(
                "sing-box",
                "https://x/sing-box.tar.gz",
                &targz("sing-box-9.9.9-linux-amd64/sing-box", script)
            )
            .expect("tar.gz"),
            script
        );
        assert!(extract_binary("mihomo", "https://x/mihomo.zip", &[]).is_err());
    }

    #[test]
    fn full_install_from_a_loopback_fixture() {
        // Multi-thread driver: the fixture servers run on worker threads
        // while the main test thread calls the SYNC installer (which builds
        // its own private runtime — nesting `block_on` would panic, the same
        // constraint production callers obey).
        let runtime = tokio::runtime::Builder::new_multi_thread()
            .enable_all()
            .build()
            .expect("test runtime");
        let script = b"#!/bin/sh\necho 'Mihomo Meta v9.9.9 test'\n";
        let archive = gzip(script);
        let archive_sha = hex_sha256(&archive);
        let base = runtime.block_on(serve_fixture(archive));
        let dir = crate::test_helpers::temp_root("kernel-install");
        // Loopback http (not https) is the documented test seam.
        let outcome = install_from_url(
            &dir,
            "mihomo",
            "9.9.9",
            &format!("{base}/mihomo.gz"),
            Some(&archive_sha),
            Some(&hex_sha256(script)),
            false,
        );
        let report = outcome.expect("fixture install works");
        assert_eq!(report.verified, VerifiedBy::ManifestHash);
        assert!(report.path.is_file());
        // Reinstall without --force refuses; the self-check also
        // rejects a binary that reports the wrong version.
        assert!(install_from_url(
            &dir,
            "mihomo",
            "9.9.9",
            &format!("{base}/mihomo.gz"),
            None,
            None,
            false
        )
        .is_err());
        let wrong =
            runtime.block_on(serve_fixture(gzip(b"#!/bin/sh\necho 'Mihomo Meta v1.0.0'\n")));
        let error = install_from_url(
            &dir,
            "mihomo",
            "9.9.9",
            &format!("{wrong}/mihomo.gz"),
            None,
            None,
            true,
        )
        .expect_err("version mismatch must abort");
        assert!(error.contains("self-check"), "{error}");
    }
}
