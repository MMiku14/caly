//! Local multi-version kernel store: `<data>/kernels/<kernel>/<version>/`.
//!
//! Layout (one directory per installed version, executable bit set):
//!
//! ```text
//! kernels/
//!   mihomo/1.19.29/mihomo
//!   sing-box/1.13.14/sing-box
//! ```
//!
//! There is no `current` pointer file: the active binary is whatever the
//! layered config's `core_binaries` names (the daemon already honors it),
//! so `core use` is a config write, not store-state surgery.

use std::path::{Path, PathBuf};

use super::StoredKernel;
use super::probe::probe_version;

/// Kernels the version manager handles. xray stays out: composition
/// rejects it with `UnsupportedCore`, so version-managing it would be
/// shelfware.
pub const KERNELS: &[&str] = &["mihomo", "sing-box"];

/// Store root under the data dir.
pub fn kernels_dir(data_dir: &Path) -> PathBuf {
    data_dir.join("kernels")
}

/// Executable file name for a (normalized) kernel.
pub fn binary_name(kernel: &str) -> &'static str {
    if kernel == "sing-box" {
        "sing-box"
    } else {
        "mihomo"
    }
}

/// Normalizes a user-supplied kernel name (`singbox` is accepted as an
/// alias; anything else is a usage error naming the two real names).
pub fn normalize_kernel(name: &str) -> Result<&'static str, String> {
    match name {
        "mihomo" => Ok("mihomo"),
        "sing-box" | "singbox" => Ok("sing-box"),
        other => Err(format!(
            "unknown kernel `{other}` (expected mihomo or sing-box)"
        )),
    }
}

/// Scans the store: every `<kernel>/<version>/<binary>` triple becomes one
/// [`StoredKernel`], live-probed for its self-reported version. Unreadable
/// directories and non-executable entries are skipped (a half-extracted
/// install must not break `core versions`). Sorted by (kernel, version).
pub fn scan_store(data_dir: &Path) -> Vec<StoredKernel> {
    let mut found = Vec::new();
    let root = kernels_dir(data_dir);
    for kernel in KERNELS {
        let kernel_dir = root.join(kernel);
        let entries = std::fs::read_dir(&kernel_dir);
        let Ok(entries) = entries else {
            continue;
        };
        for entry in entries.flatten() {
            let version_dir = entry.path();
            if !version_dir.is_dir() {
                continue;
            }
            let binary = version_dir.join(binary_name(kernel));
            if !is_executable_file(&binary) {
                continue;
            }
            let version = version_dir
                .file_name()
                .and_then(|name| name.to_str())
                .unwrap_or("unknown")
                .to_owned();
            let probed = probe_version(&binary).version;
            found.push(StoredKernel {
                kernel: (*kernel).to_owned(),
                version: probed.unwrap_or(version),
                path: binary,
            });
        }
    }
    found.sort_by(|a, b| (&a.kernel, &a.version).cmp(&(&b.kernel, &b.version)));
    found
}

/// Removes one installed version directory. Refuses a missing entry with a
/// usage error (no silent no-op: the caller named something concrete).
pub fn remove_version(
    data_dir: &Path,
    kernel: &str,
    version: &str,
) -> Result<PathBuf, String> {
    let kernel = normalize_kernel(kernel)?;
    let version_dir = kernels_dir(data_dir).join(kernel).join(version);
    if !version_dir.is_dir() {
        return Err(format!(
            "{kernel} {version} is not installed (nothing under {})",
            version_dir.display()
        ));
    }
    std::fs::remove_dir_all(&version_dir)
        .map_err(|error| format!("cannot remove {}: {error}", version_dir.display()))?;
    Ok(version_dir)
}

fn is_executable_file(path: &Path) -> bool {
    let Ok(metadata) = std::fs::metadata(path) else {
        return false;
    };
    if !metadata.is_file() {
        return false;
    }
    #[cfg(unix)]
    {
        use std::os::unix::fs::PermissionsExt as _;
        metadata.permissions().mode() & 0o111 != 0
    }
    #[cfg(not(unix))]
    {
        true
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn kernel_names_normalize() {
        assert_eq!(normalize_kernel("mihomo"), Ok("mihomo"));
        assert_eq!(normalize_kernel("singbox"), Ok("sing-box"));
        assert!(normalize_kernel("xray").is_err());
    }

    #[test]
    fn empty_store_scans_clean() {
        let dir = crate::test_helpers::temp_root("kernel-store-empty");
        assert!(scan_store(&dir).is_empty());
    }

    #[test]
    fn scan_finds_a_planted_binary() {
        let dir = crate::test_helpers::temp_root("kernel-store-scan");
        let target = kernels_dir(&dir).join("mihomo").join("9.9.9");
        std::fs::create_dir_all(&target).expect("mkdir fixture");
        let binary = target.join("mihomo");
        std::fs::write(&binary, "#!/bin/sh\necho 'Mihomo Meta v9.9.9 test'\n")
            .expect("write fixture");
        #[cfg(unix)]
        {
            use std::os::unix::fs::PermissionsExt as _;
            let mut permissions = std::fs::metadata(&binary).expect("stat").permissions();
            permissions.set_mode(0o755);
            std::fs::set_permissions(&binary, permissions).expect("chmod");
        }
        let found = scan_store(&dir);
        assert_eq!(found.len(), 1);
        assert_eq!(found[0].kernel, "mihomo");
        assert_eq!(found[0].version, "9.9.9");
        assert_eq!(found[0].path, binary);
    }

    #[test]
    fn remove_refuses_missing_entries() {
        let dir = crate::test_helpers::temp_root("kernel-store-remove");
        assert!(remove_version(&dir, "mihomo", "0.0.0").is_err());
    }
}
