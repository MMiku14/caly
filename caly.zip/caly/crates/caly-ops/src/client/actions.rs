//! Quiet daemon actions for fullscreen frontends (the TUI).
//!
//! The [`execute`](super::execute) path is built for the one-shot CLI: it
//! prints receipts, prompts, and spinners to stdout as it goes. A
//! fullscreen UI owns every screen cell, so it needs the same operations
//! with the presentation stripped off: connect, handshake, run, and return
//! the outcome as a value. That is what this module provides.
//!
//! Conventions:
//! - Every function prints nothing, prompts nothing, and takes no locks
//!   beyond the RPC round-trip itself — safe to call from a key handler.
//! - Success carries the receipt sentence the UI should flash (no `ok:`
//!   prefix; the UI owns the flash chrome).
//! - Failure carries a one-line human sentence built by
//!   [`describe_error`], including the daemon's `suggested_action` when the
//!   failure is an operation rejection rather than a transport fault.
//! - Sync operations use the same 20 s budget as the CLI so a hung daemon
//!   surfaces as a timeout flash, not a frozen UI.

use std::fmt::Write as _;
use std::path::PathBuf;

use caly_protocol::{
    client::{ClientContract, ClientError, UdsClient},
    protocol::v2::{
        ExecuteRequest, ExecuteSyncRequest, WireCommand, WireCoreAction, WireCoreKind, WireMode,
        WireOperationState, WireOperationStatus,
    },
};

use super::execute;

/// One node's latency after a [`sweep_latencies`] pass.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct SweepLatency {
    /// Lowercase hex node id (the same key `node list` prints).
    pub node_hex: String,
    /// Lower-middle median of the probe samples, or `None` when every
    /// probe for the node failed (unreachable, timeout, or controller gap).
    pub median_ms: Option<u32>,
}

/// One-line human sentence for a client failure, using the exact
/// vocabulary the TUI already flashes for snapshot failures so transport
/// faults read the same everywhere.
#[must_use]
pub fn describe_error(error: &ClientError) -> String {
    match error {
        ClientError::TransportUnavailable { reason } => format!("daemon unreachable: {reason}"),
        ClientError::DeadlineExceeded => {
            "the daemon did not respond before the deadline".to_owned()
        }
        ClientError::IncompatibleVersion => {
            "client/daemon protocol versions differ — restart both from one build".to_owned()
        }
        ClientError::AuthenticationRejected => {
            "the daemon rejected this client session — is the socket yours?".to_owned()
        }
        ClientError::ResourceExhausted => "the daemon is busy; retry shortly".to_owned(),
        ClientError::DecodeRejected { reason, .. } => format!("bad daemon reply: {reason}"),
    }
}

/// Connects and handshakes like the one-shot CLI, minus all output.
/// Public so a fullscreen UI can hold one client across ticks instead of
/// paying connect + handshake per refresh; snapshot calls on the held
/// client are plain request/response pairs.
pub fn connect(socket: Option<&PathBuf>) -> Result<UdsClient, String> {
    let path = super::resolve_client_socket(socket);
    let mut client = execute::connect_with_retry(&path).map_err(|error| describe_error(&error))?;
    execute::handshake(&mut client).map_err(|error| describe_error(&error))?;
    Ok(client)
}

/// Interprets a terminal operation status as a UI receipt sentence.
fn interpret(status: &WireOperationStatus, summary: String) -> Result<String, String> {
    if status.state.known() == Some(WireOperationState::Completed) {
        return Ok(summary);
    }
    if let Some(failure) = &status.failure {
        let mut message = format!("{summary} failed: {}", failure.message);
        if !failure.suggested_action.is_empty() {
            let _ = write!(message, " ({})", failure.suggested_action);
        }
        return Err(message);
    }
    Err(format!("{summary} failed: {}", status.state.label()))
}

/// Runs one synchronous daemon command and interprets the receipt.
fn run_sync(
    socket: Option<&PathBuf>,
    command: WireCommand,
    summary: String,
) -> Result<String, String> {
    let mut client = connect(socket)?;
    let response = client
        .execute_sync(ExecuteSyncRequest {
            command,
            timeout_ms: 20_000,
            poll_interval_ms: 100,
        })
        .map_err(|error| describe_error(&error))?;
    interpret(&response.operation, summary)
}

/// Selects the node `node_id` as the active proxy, the quiet twin of
/// `caly node select`. `label` is the display name echoed in the receipt.
pub fn select_node(
    socket: Option<&PathBuf>,
    node_id: [u8; 16],
    label: &str,
) -> Result<String, String> {
    run_sync(
        socket,
        WireCommand::SelectProxy { node_id },
        format!("selected node `{label}`"),
    )
}

/// Picks `member` inside proxy group `group`, the quiet twin of
/// `caly proxy-group select`.
pub fn pick_group_member(
    socket: Option<&PathBuf>,
    group: &str,
    member: &str,
) -> Result<String, String> {
    run_sync(
        socket,
        WireCommand::SelectProxyGroup {
            group: group.to_owned(),
            member: member.to_owned(),
        },
        format!("group `{group}` now uses `{member}`"),
    )
}

/// Sets the routing mode (`rule`, `global`, or `direct`), the quiet twin
/// of `caly mode set`. Unknown labels fail locally without touching the
/// daemon so a UI mode cycle can never submit garbage.
pub fn set_mode(socket: Option<&PathBuf>, label: &str) -> Result<String, String> {
    let mode = WireMode::from_label(label)
        .ok_or_else(|| format!("unknown mode `{label}` (want rule, global, or direct)"))?;
    run_sync(
        socket,
        WireCommand::SetMode { mode: mode.wire() },
        format!("mode set to `{label}`"),
    )
}

/// Turns the TUN device on or off, the quiet twin of `caly tun on|off`.
/// The receipt names the new state so a TUI flash reads as a sentence.
pub fn set_tun(socket: Option<&PathBuf>, on: bool) -> Result<String, String> {
    run_sync(
        socket,
        WireCommand::SetTun { enabled: on },
        format!("TUN {}", if on { "enabled" } else { "disabled" }),
    )
}

/// Turns the desktop system proxy on or off, the quiet twin of
/// `caly sysproxy on|off`.
pub fn set_system_proxy(socket: Option<&PathBuf>, on: bool) -> Result<String, String> {
    run_sync(
        socket,
        WireCommand::SetSystemProxy { enabled: on },
        format!("system proxy {}", if on { "enabled" } else { "disabled" }),
    )
}

/// Switches the running core (`mihomo` or `sing-box`), the quiet twin
/// of `caly core switch`. The daemon restarts the data plane onto the
/// target core; unknown labels fail locally like [`set_mode`].
pub fn switch_core(socket: Option<&PathBuf>, target: &str) -> Result<String, String> {
    let kind = match target {
        "mihomo" => WireCoreKind::Mihomo,
        "sing-box" => WireCoreKind::SingBox,
        _ => return Err(format!("unknown core `{target}` (want mihomo or sing-box)")),
    };
    run_sync(
        socket,
        WireCommand::SwitchCore {
            core_kind: kind.wire(),
            action: WireCoreAction::Restart.wire(),
        },
        format!("switched core to `{target}`"),
    )
}

/// Submits a refresh-all-subscriptions operation and returns immediately
/// with the submitted operation id. Refreshing is deliberately async: a
/// fetch can outlast the 20 s sync budget, and the TUI re-snapshots on
/// its tick anyway, so the fresh data arrives on its own.
pub fn refresh_all(socket: Option<&PathBuf>, force: bool) -> Result<String, String> {
    submit_refresh(socket, [0; 16], force, "refresh".to_owned())
}

/// Submits a one-source refresh, the quiet twin of
/// `caly sub refresh <name>`. The subscription id is derived from the
/// source URL exactly like the CLI's resolver, so both address the same
/// daemon record.
pub fn refresh_source(socket: Option<&PathBuf>, name: &str, url: &str) -> Result<String, String> {
    let id = caly_subscription::subscription_id_for_url(url).into_bytes();
    submit_refresh(socket, id, false, format!("refresh of `{name}`"))
}

fn submit_refresh(
    socket: Option<&PathBuf>,
    subscription_id: [u8; 16],
    force: bool,
    what: String,
) -> Result<String, String> {
    let mut client = connect(socket)?;
    let response = client
        .execute(ExecuteRequest {
            operation_id: super::operation_id(),
            command: WireCommand::RefreshSubscription {
                subscription_id,
                force,
            },
        })
        .map_err(|error| describe_error(&error))?;
    Ok(format!(
        "{what} submitted (op {})",
        caly_domain::to_hex(response.operation.operation_id)
    ))
}

/// Sweeps every snapshot node's latency and returns the per-node medians.
/// Same probe helper as `caly node sweep`, minus the table: the TUI
/// overlays the medians on its node list.
pub fn sweep_latencies(socket: Option<&PathBuf>) -> Result<Vec<SweepLatency>, String> {
    sweep_latencies_with_progress(socket, None)
}

/// Progress-reporting sweep: `progress` receives (done, total, dead) per
/// completed probe. Passing a callback also suppresses the sweep's own
/// `\r` TTY progress line, which would otherwise scribble over a
/// fullscreen UI's frame (same contract as the live picker's sweep).
pub fn sweep_latencies_with_progress(
    socket: Option<&PathBuf>,
    progress: Option<&(dyn Fn(usize, usize, usize) + Sync)>,
) -> Result<Vec<SweepLatency>, String> {
    let mut client = connect(socket)?;
    let rows = execute::delay::sweep_snapshot_delays_with(&mut client, None, None, None, progress)?;
    Ok(rows
        .iter()
        .map(|row| SweepLatency {
            node_hex: caly_domain::to_hex(row.node_id),
            median_ms: row.outcome.median_ms(),
        })
        .collect())
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn transport_errors_read_like_snapshot_failures() {
        let note = describe_error(&ClientError::TransportUnavailable {
            reason: "socket not found".to_owned(),
        });
        assert_eq!(note, "daemon unreachable: socket not found");
        assert_eq!(
            describe_error(&ClientError::DeadlineExceeded),
            "the daemon did not respond before the deadline"
        );
    }

    #[test]
    fn unknown_core_fails_without_a_socket() {
        let error = switch_core(None, "xray").expect_err("unknown core must fail");
        assert!(error.contains("xray"), "{error}");
    }

    #[test]
    fn unknown_mode_fails_without_a_socket() {
        let error = set_mode(None, "turbo").expect_err("unknown label must fail");
        assert!(error.contains("turbo"), "{error}");
    }
}
