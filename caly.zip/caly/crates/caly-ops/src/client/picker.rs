//! Live-picker seam between the select orchestration and the frontends.
//!
//! `node select` (no argument) opens an interactive picker over the online
//! snapshot. The orchestration — snapshot fetch, `-p` pre-sweep, the
//! in-picker ping worker, selection commit — is frontend-agnostic and lives
//! in [`super::execute`]; the actual key handling + rendering is a
//! [`LivePicker`] implementation owned by the frontend (the CLI's crossterm
//! picker in `caly-cli`'s `interact_live`, a future TUI widget).
//!
//! The shared vocabulary (`LiveItem`, `PingState`, `LiveOutcome`) moved here
//! from the CLI's `interact_live` verbatim: pure data, no terminal crate.

use std::collections::HashMap;
use std::io::IsTerminal;
use std::sync::{Arc, Mutex};

/// One live picker entry.
#[derive(Clone, Debug)]
pub struct LiveItem {
    pub name: String,
    pub protocol: String,
    pub latency_ms: Option<u32>,
    /// Stable payload (hex node id), returned on selection.
    pub payload: String,
}

/// Shared state of the in-picker ping sweep, published by the background
/// probe thread and read by every render.
#[derive(Clone, Copy, Debug, Default)]
pub struct PingState {
    pub running: bool,
    pub done: usize,
    pub total: usize,
    pub dead: usize,
    pub ever_ran: bool,
    /// The sweep itself failed (daemon unreachable): the feature row must
    /// say so instead of presenting `0 unreachable` as a result.
    pub failed: bool,
}

/// Picker exit.
#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub enum LiveOutcome {
    /// Entry index into the `entries` slice (feature row excluded).
    Selected(usize),
    Escaped,
    Interrupted,
}

/// Frontend-owned picker UI. `start_ping` launches the background sweep
/// (and must reset the shared `PingState` to `running: true`); the picker
/// only calls it when the feature row is activated and no sweep is
/// currently running.
pub trait LivePicker {
    fn pick(
        &mut self,
        entries: &[LiveItem],
        ping: &Arc<Mutex<PingState>>,
        latencies: &Arc<Mutex<HashMap<String, Option<u32>>>>,
        start_ping: &mut dyn FnMut(),
    ) -> std::io::Result<LiveOutcome>;
}

/// Picker for non-interactive callers (`run_client` without a frontend):
/// the TTY gate fires before the picker is ever consulted, so this is
/// only a signature placeholder and reports cancellation.
pub struct NopPicker;

impl LivePicker for NopPicker {
    fn pick(
        &mut self,
        _entries: &[LiveItem],
        _ping: &Arc<Mutex<PingState>>,
        _latencies: &Arc<Mutex<HashMap<String, Option<u32>>>>,
        _start_ping: &mut dyn FnMut(),
    ) -> std::io::Result<LiveOutcome> {
        Ok(LiveOutcome::Escaped)
    }
}

/// Whether stdio is a capable interactive terminal (stdin+stdout+stderr
/// are TTYs and `TERM` is not `dumb`). The picker gate: non-interactive
/// callers get the usage error with the available names instead of a
/// blocked read loop.
pub fn interactive_capable() -> bool {
    std::io::stdin().is_terminal()
        && std::io::stdout().is_terminal()
        && std::io::stderr().is_terminal()
        && std::env::var_os("TERM").is_some_and(|term| term != "dumb")
}
