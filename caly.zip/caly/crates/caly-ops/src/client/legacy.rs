//! Private client RPC enums (`ConfigCmd` / `CoreCmd` / `SysCmd`).
//!
//!
//! Internal input shapes for the UDS pipeline; the public CLI surface is the
//! 5-namespace grammar (`daemon` / `tool` / `show` / `set` / `completions`).

#[derive(Clone, Debug, Eq, PartialEq)]
pub enum ConfigCmd {
    Apply,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub enum SysCmd {
    Proxy(bool),
    /// `sysproxy pac <url>`: desktop proxy auto mode with a PAC URL.
    ProxyPac(String),
    Tun(bool),
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub enum CoreCmd {
    Start,
    Stop,
    Restart,
    Switch(String),
    Select {
        node: Option<String>,
        delay: bool,
        poll: bool,
    },
    CloseConnections {
        id: Option<String>,
    },
    Mode(String),
    ProxyGroups,
    ListConnections,
    ListNodes,
    Traffic,
    Delay {
        all: bool,
        name: Option<String>,
        url: Option<String>,
        /// Per-URL sample count (1..=5); `None`
        /// means "use the default". The offline
        /// `Query::UrlTest` path resolves the
        /// default at the dispatch boundary.
        samples: Option<u32>,
    },
    Rules,
    RuleMatch(String),
}
