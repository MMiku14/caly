//! Tests for `client/execute/ops.rs`, extracted to the child
//! convention file (audit #70 file-length budget).

use super::*;

/// A failed daemon connect in the sweep worker must surface as a
/// failed state (honest feature row), never as a fake `0 unreachable`
/// result — and `running` must always be cleared so the header can
/// never stay stuck on "testing...".
#[test]
fn start_ping_connect_failure_marks_state_failed() {
    let ping = std::sync::Arc::new(std::sync::Mutex::new(
        crate::client::picker::PingState::default(),
    ));
    let latencies = std::sync::Arc::new(std::sync::Mutex::new(std::collections::HashMap::new()));
    let mut start_ping = build_start_ping(
        latencies,
        ping.clone(),
        std::path::PathBuf::from("/nonexistent/caly-live-test.sock"),
    );
    start_ping();
    let deadline = std::time::Instant::now() + std::time::Duration::from_secs(5);
    loop {
        let state = *ping
            .lock()
            .unwrap_or_else(std::sync::PoisonError::into_inner);
        if !state.running || std::time::Instant::now() > deadline {
            break;
        }
        std::thread::sleep(std::time::Duration::from_millis(5));
    }
    let state = *ping
        .lock()
        .unwrap_or_else(std::sync::PoisonError::into_inner);
    assert!(
        !state.running,
        "worker must clear running on connect failure"
    );
    assert!(state.failed, "connect failure must mark the sweep failed");
    assert!(state.ever_ran);
}
