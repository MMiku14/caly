//! CLI-side UDS client commands.

pub mod actions;
pub mod config_generate;
pub mod config_kv;
pub mod context;
pub mod execute;
pub mod inline_proxy;
pub mod legacy;
pub mod op;
pub mod output;
mod output_capabilities;
pub mod picker;
pub mod profile;
pub mod proxy_group;
pub mod query;
pub mod rule_provider;
mod rules;
pub mod subscription;

pub use query::{Query, run_query};

use std::{path::PathBuf, process::ExitCode};

use caly_protocol::client::{ClientContract, ClientError, UdsClient};

use legacy::{ConfigCmd, CoreCmd, SysCmd};

/// Client-facing command surface (maps the tree leaves to
/// protocol calls). The variant carries the typed
/// per-family subcommand so the dispatch in [`run_client`]
/// can keep the connection-handshake / error-reporting path
/// in one place.
#[derive(Clone, Debug)]
pub enum ClientCommand {
    Status,
    Core(CoreCmd),
    RefreshSubscription {
        /// W2-β2b: `None` = every enabled source (all-zero wire id);
        /// `Some` pins one source (`sub refresh <name-or-url>`).
        subscription_id: Option<[u8; 16]>,
        force: bool,
        asynchronous: bool,
    },
    Sys(SysCmd),
    Config(ConfigCmd),
    /// `set daemon stop`. The server tears
    /// down the runtime after the response is
    /// serialized. No payload.
    StopDaemon,
    /// `set daemon reload`. The server
    /// re-reads `config.yaml` and re-applies the
    /// current candidate. No payload.
    ReloadConfig,
    /// W4 (`node pick --apply`): pick a named member inside a named
    /// selector group through the daemon's supervised operation path.
    PickProxyGroup {
        group: String,
        member: String,
    },
    /// `op` — inspect or cancel a supervised daemon operation by the
    /// id its receipt printed. Ids arrive pre-parsed (see
    /// [`op::parse_op_id`]) so a malformed id never dials the daemon.
    Op(op::OpQuery),
}

/// Best-effort daemon snapshot read for the currently active core label
/// (`mihomo`/`sing-box`). Falls back to `None` when the daemon is unreachable
/// or reports no core, keeping offline queries usable without a daemon.
pub fn active_core_kind_label(socket: Option<&PathBuf>) -> Option<String> {
    use caly_protocol::protocol::v2::WireCoreKind;
    let socket = resolve_client_socket(socket);
    let mut client = UdsClient::connect(socket).ok()?;
    execute::handshake(&mut client).ok()?;
    let snapshot = client.snapshot().ok()?;
    WireCoreKind::from_wire(snapshot.applied.core_kind?).map(|kind| {
        match kind {
            WireCoreKind::Mihomo => "mihomo",
            WireCoreKind::SingBox => "sing-box",
            WireCoreKind::Xray => "xray",
        }
        .to_owned()
    })
}

/// Loads the layered `AppConfig` (base + optional profile overlay +
/// fragments) with the lenient in-memory profile resolver. The
/// offline readers' shared recipe — previously inlined at six call
/// sites (config_generate / profile / proxy_group ×2 /
/// subscription / config_kv).
pub(crate) fn load_layered_lenient(
    config_root: &std::path::Path,
    profile: Option<caly_platform::paths::SafeName>,
) -> Result<caly_profile::schema::AppConfig, String> {
    use caly_profile::loader::{InMemoryProfileResolver, LayeredConfigPaths, LoaderLimits};
    let layered = LayeredConfigPaths::new(config_root.to_path_buf(), profile);
    caly_profile::loader::load_layered_yaml_with(
        &layered,
        LoaderLimits::secure_default(),
        &InMemoryProfileResolver::lenient(),
    )
    .map_err(|error| error.to_string())
}

/// Executes one bounded client command against the configured UDS.
pub fn run_client(command: ClientCommand, options: crate::types::CliOptions) -> ExitCode {
    let mut picker = picker::NopPicker;
    run_client_with_picker(command, options, &mut picker)
}

/// [`run_client`] with a frontend-owned live picker: the CLI passes its
/// crossterm picker so bare `node select` on a TTY opens the interactive
/// face; the plain twin reports the no-argument usage error instead.
pub fn run_client_with_picker(
    command: ClientCommand,
    options: crate::types::CliOptions,
    picker: &mut dyn picker::LivePicker,
) -> ExitCode {
    match run_client_collect_with_picker(&command, &options, picker) {
        Ok(code) => code,
        Err(error) => output::report_error(error, options.json),
    }
}

/// Result-returning twin of [`run_client`]. Same
/// offline short-circuits + daemon-RPC pipeline, but reports
/// failures as a typed [`ClientError`] so the new
/// `Refreshable` trait (and any future typed caller) can fold
/// the outcome into a unified error envelope without going
/// through `output::report_error` first.
///
/// The two functions are not redundant: `run_client` keeps
/// the existing call sites (status / show / set core / set
/// sys / set config / bridge) on a stable
/// `ExitCode`-returning contract. New callers — primarily the
/// 3 `Refreshable` impls — use `run_client_collect` directly.
/// Result-and-exit-code twin used by both call sites: `Ok` carries the
/// operation's own `ExitCode` (the `execute::*` helpers report
/// operation-level failures as `ExitCode::FAILURE`; swallowing that code
/// used to make every failed `set core start` / `config apply` look like a
/// shell-level success — see the CLI exit-code contract). `Err` is the
/// typed transport/handshake failure the caller folds into an envelope.
pub fn run_client_collect(
    command: &ClientCommand,
    options: &crate::types::CliOptions,
) -> Result<ExitCode, ClientError> {
    let mut picker = picker::NopPicker;
    run_client_collect_with_picker(command, options, &mut picker)
}

/// [`run_client_collect`] with a frontend-owned live picker (see
/// [`run_client_with_picker`]).
pub fn run_client_collect_with_picker(
    command: &ClientCommand,
    options: &crate::types::CliOptions,
    picker: &mut dyn picker::LivePicker,
) -> Result<ExitCode, ClientError> {
    validate_core_option(options)?;
    if let Some(offline) = run_offline_command(command, options) {
        return offline;
    }
    let socket = resolve_client_socket(options.socket.as_ref());
    let mut client = execute::connect_with_retry(&socket)?;
    execute::handshake(&mut client)?;
    Ok(execute_connected_command(
        command,
        options,
        &mut client,
        picker,
    ))
}

/// Fetches one daemon snapshot: socket resolution + connect (with retry) +
/// handshake + a single snapshot read. The TUI's polling primitive (and any
/// future frontend): the CLI's one-shot commands go through [`run_client`]
/// instead, which adds the offline short-circuits and receipt printing.
pub fn fetch_snapshot(
    socket: Option<&std::path::PathBuf>,
) -> Result<caly_protocol::protocol::v2::WirePresentationSnapshot, ClientError> {
    let path = resolve_client_socket(socket);
    let mut client = execute::connect_with_retry(&path)?;
    execute::handshake(&mut client)?;
    client.snapshot()
}

/// Rejects an invalid `--core` target before any daemon connection.
fn validate_core_option(options: &crate::types::CliOptions) -> Result<(), ClientError> {
    if let Some(core) = options.core.as_deref()
        && core != "mihomo"
        && core != "sing-box"
    {
        return Err(ClientError::DecodeRejected {
            reason: format!("invalid --core target `{core}` (expected mihomo or sing-box)"),
            suggested_action: "use --core mihomo or --core sing-box".to_owned(),
        });
    }
    Ok(())
}

/// Read-only Clash queries, rule commands, and config leaves that never need
/// a daemon connection run here. `None` means the command must go online.
/// The config leaves were previously intercepted as a no-op success; they now
/// invoke the same local `config_generate`/`execute` helpers the top-level
/// v3 dispatch uses, so a caller going through [`run_client`] sees identical
/// file-system effects (generate writes, validate checks, edit opens an
/// editor).
fn run_offline_command(
    command: &ClientCommand,
    options: &crate::types::CliOptions,
) -> Option<Result<ExitCode, ClientError>> {
    if let ClientCommand::Core(core_cmd) = command {
        if let Some(query) = execute::core_query(core_cmd) {
            let core = options.core.clone().unwrap_or_else(|| {
                std::env::var("CALY_CORE").unwrap_or_else(|_| {
                    active_core_kind_label(options.socket.as_ref()).unwrap_or_else(|| "mihomo".to_owned())
                })
            });
            return Some(Ok(run_query(&core, query, options.json)));
        }
        if matches!(core_cmd, CoreCmd::Rules | CoreCmd::RuleMatch(_)) {
            return Some(Ok(rules::run_rules(core_cmd, options.json)));
        }
    }
    // `ClientCommand::Config` is online-only (`Apply`): the offline
    // config leaves dispatch straight to `config_generate::*`, so there
    // is no offline arm to intercept here.
    None
}

pub(crate) fn resolve_client_socket(explicit: Option<&PathBuf>) -> PathBuf {
    explicit.cloned().unwrap_or_else(|| {
        std::env::var_os("CALY_SOCKET").map_or_else(
            || caly_platform::paths::AppPaths::from_env().socket_path(),
            PathBuf::from,
        )
    })
}

/// The `execute::*` helpers print their own envelopes and return `ExitCode`;
/// this function is the single dispatch table for every online leaf.
fn execute_connected_command(
    command: &ClientCommand,
    options: &crate::types::CliOptions,
    client: &mut UdsClient,
    picker: &mut dyn picker::LivePicker,
) -> ExitCode {
    let core = options.core.as_deref();
    match command {
        ClientCommand::Status => output::print_status(client, options.json),
        ClientCommand::Core(core_cmd) => execute::execute_core_cmd(
            client,
            core_cmd.clone(),
            core,
            options.json,
            options.format,
            picker,
        ),
        ClientCommand::RefreshSubscription {
            subscription_id,
            force,
            asynchronous,
        } => execute::execute_refresh_subscription(
            client,
            options.json,
            *subscription_id,
            *force,
            *asynchronous,
        ),
        ClientCommand::Sys(sys_cmd) => {
            execute::execute_sys_cmd(client, sys_cmd.clone(), options.json)
        }
        ClientCommand::Config(config_cmd) => {
            execute::execute_config_cmd(client, config_cmd.clone(), options.json)
        }
        ClientCommand::StopDaemon => execute::execute_stop_daemon(client, options.json),
        ClientCommand::ReloadConfig => execute::execute_reload_config(client, options.json),
        // W4: the offline tree validated the group/member spelling;
        // the daemon resolves kernel tags and persists the selection.
        ClientCommand::PickProxyGroup { group, member } => {
            execute::execute_pick_proxy_group(client, group, member, options.json)
        }
        ClientCommand::Op(query) => {
            op::execute_op_query(client, query.clone(), options.json, options.format)
        }
    }
}

/// Generates a random 128-bit operation id.
///
/// Operation ids only need uniqueness (they are not security tokens): 128
/// random bits from the platform CSPRNG give negligible collision probability
/// and carry no time/pid structure, so adjacent operations are never related.
pub(crate) fn operation_id() -> [u8; 16] {
    caly_platform::entropy::random_bytes::<16>()
}

#[cfg(test)]
mod client_tests;
#[cfg(test)]
mod profile_tests;
