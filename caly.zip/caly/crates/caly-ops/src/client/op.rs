//! `op` — follow up on daemon operations (`op list` / `op status` /
//! `op cancel`).
//!
//! Every mutating RPC runs as a supervised operation; fire-and-forget
//! submissions (notably `sub refresh --async`) print the op id on
//! their receipt so the run can be inspected or cancelled here. The
//! daemon keeps a bounded dashboard (active + terminal, most recent
//! first); ids are the 32-hex rendering of the 128-bit op id.

use std::process::ExitCode;

use caly_protocol::client::{ClientContract, UdsClient};
use caly_protocol::protocol::v2::{
    CancelOperationRequest, CancelOutcome, GetOperationStatusRequest, WireOperationStatus,
};

use super::output;

/// A parsed `op` query. Ids are validated hex at the `commands/`
/// boundary so a malformed id is a usage error (exit 2) that never
/// touches the daemon.
#[derive(Clone, Debug)]
pub enum OpQuery {
    List,
    Status { id: [u8; 16] },
    Cancel { id: [u8; 16] },
}

/// Parses the 32-hex op id from a receipt (`op status <id>`).
/// Trims whitespace; both cases accepted.
pub fn parse_op_id(raw: &str) -> Result<[u8; 16], String> {
    let trimmed = raw.trim();
    if trimmed.len() != 32 || !trimmed.bytes().all(|b| b.is_ascii_hexdigit()) {
        return Err(format!(
            "op id `{raw}` is not 32 hex chars (copy it from the async receipt)"
        ));
    }
    let mut id = [0_u8; 16];
    for (slot, pair) in id.iter_mut().zip(trimmed.as_bytes().chunks(2)) {
        let hex = core::str::from_utf8(pair).unwrap_or_default();
        *slot = u8::from_str_radix(hex, 16).unwrap_or_default();
    }
    Ok(id)
}

/// Runs one `op` query against the connected daemon.
pub fn execute_op_query(
    client: &mut UdsClient,
    query: OpQuery,
    json: bool,
    format: Option<crate::types::OutputFormat>,
) -> ExitCode {
    match query {
        OpQuery::List => execute_list(client, json, format),
        OpQuery::Status { id } => {
            match client.operation_status(GetOperationStatusRequest { operation_id: id }) {
                Ok(status) => {
                    // A point query, not a wait: exit 0 on a successful
                    // read whatever the state; the state itself is visible.
                    render_status(&status, json);
                    ExitCode::SUCCESS
                }
                Err(error) => output::report_error(error, json),
            }
        }
        OpQuery::Cancel { id } => {
            match client.cancel(CancelOperationRequest { operation_id: id }) {
                Ok(response) => render_cancel(&response.operation, response.outcome.known(), json),
                Err(error) => output::report_error(error, json),
            }
        }
    }
}

/// Renders one operation status (`op status <id>`).
fn render_status(status: &WireOperationStatus, json: bool) {
    output::print_operation_status(status, json, &format!("operation {}", hex_of(status)));
}

/// Renders the `op list` dashboard (most recently updated first).
fn execute_list(
    client: &mut UdsClient,
    json: bool,
    format: Option<crate::types::OutputFormat>,
) -> ExitCode {
    match client.list_operations() {
        Ok(response) => {
            let operations = response.operations.into_vec();
            if json {
                let items: Vec<serde_json::Value> = operations
                    .iter()
                    .map(|status| {
                        serde_json::json!({
                            "op": hex_of(status),
                            "kind": status.command_kind,
                            "state": status.state.label(),
                            "updated_at_ms": status.updated_at_unix_ms,
                            "failure": status.failure.as_ref().map(|failure| {
                                serde_json::json!({
                                    "code": failure.code.0,
                                    "message": failure.message,
                                })
                            }),
                        })
                    })
                    .collect();
                println!(
                    "{}",
                    caly_layout::CliOutput::success_envelope(serde_json::json!({
                        "command": "op list",
                        "operations": items,
                    }))
                );
            } else {
                let mode = caly_layout::table_mode(format);
                let headers: &[&str] = match mode {
                    caly_layout::TableMode::Tsv => &["op", "kind", "state", "updated"],
                    caly_layout::TableMode::Table => &["OP", "KIND", "STATE", "UPDATED"],
                };
                // TSV carries raw unix millis; the Table face renders
                // them relative (the `sub list` refresh-column split).
                let now = caly_layout::now_unix();
                let rows: Vec<Vec<String>> = operations
                    .iter()
                    .map(|status| {
                        let updated = match mode {
                            caly_layout::TableMode::Tsv => status.updated_at_unix_ms.to_string(),
                            caly_layout::TableMode::Table => caly_layout::relative_time(
                                now,
                                Some(status.updated_at_unix_ms / 1000),
                            ),
                        };
                        vec![
                            hex_of(status),
                            status.command_kind.clone(),
                            status.state.label(),
                            updated,
                        ]
                    })
                    .collect();
                if rows.is_empty() && mode == caly_layout::TableMode::Table {
                    caly_layout::empty("operations", None);
                } else {
                    caly_layout::print_table(mode, headers, &rows);
                }
            }
            ExitCode::SUCCESS
        }
        Err(error) => output::report_error(error, json),
    }
}

/// Renders the `op cancel <id>` acknowledgement.
fn render_cancel(
    status: &WireOperationStatus,
    outcome: Option<CancelOutcome>,
    json: bool,
) -> ExitCode {
    let hex = hex_of(status);
    let (label, code) = match outcome {
        Some(CancelOutcome::Requested) => ("requested", ExitCode::SUCCESS),
        // The goal state (not running) already holds.
        Some(CancelOutcome::AlreadyTerminal) => ("already terminal", ExitCode::SUCCESS),
        Some(CancelOutcome::TooLateToCancel) | None => ("too late to cancel", ExitCode::from(1)),
    };
    if json {
        println!(
            "{}",
            caly_layout::CliOutput::success_envelope(serde_json::json!({
                "command": "op cancel",
                "op": hex,
                "outcome": label,
                "state": status.state.label(),
            }))
        );
    } else {
        caly_layout::ok(&format!(
            "cancel {label} (op {hex}, {})",
            status.state.label()
        ));
    }
    code
}

fn hex_of(status: &WireOperationStatus) -> String {
    caly_domain::to_hex(status.operation_id)
}

#[cfg(test)]
mod tests {
    use super::parse_op_id;

    #[test]
    fn parse_op_id_accepts_32_hex_and_round_trips() {
        let id = parse_op_id("0123456789abcdef0123456789abcdef").unwrap();
        assert_eq!(id[0], 0x01);
        assert_eq!(id[15], 0xef);
        assert_eq!(caly_domain::to_hex(id), "0123456789abcdef0123456789abcdef");
    }

    #[test]
    fn parse_op_id_trims_and_accepts_uppercase() {
        let id = parse_op_id("  FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF\n").unwrap();
        assert_eq!(id, [0xff; 16]);
    }

    #[test]
    fn parse_op_id_rejects_short_and_non_hex() {
        assert!(parse_op_id("abc").is_err());
        assert!(parse_op_id("gggggggggggggggggggggggggggggggg").is_err());
        assert!(parse_op_id("").is_err());
    }
}
