//! `config set <dotted.key> <value> [--apply]` — dry-run by
//! default. Edits the winning layer file in place, re-validates the
//! merged tree, and restores the original bytes on any failure.

use std::path::{Path, PathBuf};
use std::process::ExitCode;

use caly_configstore::yaml_surgery::{KeyBlock, locate_key_block};
use caly_platform::paths::{AppPaths, SafeName};
use serde_norway::Value;

use super::{
    Layer, active_profile, display_scalar, is_scalar, load_layers, parse_key, relative_to, report,
    walk,
};

/// How the winning layer file takes the edit.
enum Edit {
    /// Replace the scalar at `segments` (carries the old display).
    Replace(String),
    /// Insert the leaf under its parent block.
    Insert,
}

/// Quiet scalar-write failure: the same code/reason/hint [`report`] would
/// print, without printing. Returned by [`apply_scalar`] so non-CLI
/// writers (`core use`, the TUI) can fold the outcome into their own
/// receipts.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct ScalarFailure {
    pub code: &'static str,
    pub reason: String,
    pub hint: Option<&'static str>,
}

/// Quiet scalar-write outcome: what changed, without printing.
#[derive(Clone, Debug, Eq, PartialEq)]
pub enum ScalarOutcome {
    Unchanged {
        target: PathBuf,
        rendered: String,
    },
    Changed {
        target: PathBuf,
        old: String,
        rendered: String,
        applied: bool,
    },
}

/// `config set <dotted.key> <value> [--apply]`.
pub fn config_set(json: bool, key: &str, value: &str, apply: bool) -> ExitCode {
    let paths = AppPaths::from_env();
    let profile = match active_profile() {
        Ok(profile) => profile,
        Err(reason) => {
            return report("usage.config_bad_profile", "config set", reason, None, json);
        }
    };
    config_set_under(&paths, profile.as_ref(), json, key, value, apply)
}

pub(super) fn config_set_under(
    paths: &AppPaths,
    profile: Option<&SafeName>,
    json: bool,
    key: &str,
    value: &str,
    apply: bool,
) -> ExitCode {
    match apply_scalar(paths, profile, key, value, apply) {
        Err(failure) => report(
            failure.code,
            "config set",
            failure.reason,
            failure.hint,
            json,
        ),
        Ok(ScalarOutcome::Unchanged { target, rendered }) => {
            report_unchanged(paths, &target, json, key, &rendered)
        }
        Ok(ScalarOutcome::Changed {
            target,
            old,
            rendered,
            applied,
        }) => report_set(paths, &target, json, key, &old, &rendered, applied),
    }
}

/// Quiet scalar write: the full [`config_set_under`] flow (layer winner,
/// trial write, merged re-validation, restore-on-failure) without printing.
/// Returns the outcome so other writers can print their own receipts.
pub fn apply_scalar(
    paths: &AppPaths,
    profile: Option<&SafeName>,
    key: &str,
    value: &str,
    apply: bool,
) -> Result<ScalarOutcome, ScalarFailure> {
    let failure = |code: &'static str, reason: String, hint: Option<&'static str>| ScalarFailure {
        code,
        reason,
        hint,
    };
    let segments =
        parse_key(key).map_err(|reason| failure("usage.config_bad_key", reason, None))?;
    let rendered = render_scalar_value(value)
        .map_err(|reason| failure("usage.config_bad_value", reason, None))?;
    let layers =
        load_layers(paths, profile).map_err(|reason| failure("config.set_failed", reason, None))?;
    if layers.is_empty() {
        return Err(failure(
            "config.set_failed",
            format!("no config files under {}", paths.config.display()),
            Some("run `caly config generate` to create the default layout"),
        ));
    }
    let (winner, edit) = resolve_winner(paths, &layers, &segments)?;
    let old = match &edit {
        Edit::Replace(old) => old.clone(),
        Edit::Insert => "(unset)".to_owned(),
    };
    if old == rendered {
        return Ok(ScalarOutcome::Unchanged {
            target: layers[winner].path.clone(),
            rendered,
        });
    }
    let new_text = patch_layer(&layers[winner].text, &segments, &rendered)
        .map_err(|reason| failure("config.set_failed", reason, None))?;
    // Trial write: backup for crash recovery, atomic swap, merged
    // re-validation, then restore on failure — or on dry-run. A
    // revert restores the backup's exact pre-trial state too: the
    // trial overwrote it, and it may belong to an earlier write.
    let target = layers[winner].path.clone();
    let backup = caly_configstore::config_writer::backup_path(&target);
    let prior_backup = std::fs::read(&backup).ok();
    write_trial(&target, &new_text).map_err(|reason| failure("config.set_failed", reason, None))?;
    let valid = validate_merged(paths, profile);
    if valid.is_err() || !apply {
        if caly_configstore::config_writer::write_atomic(&target, layers[winner].text.as_bytes())
            .is_err()
        {
            return Err(failure(
                "config.set_failed",
                format!("cannot restore {} after a trial write", target.display()),
                Some("the .bak backup was kept — restore it by hand"),
            ));
        }
        match prior_backup {
            Some(bytes) => {
                let _ = std::fs::write(&backup, bytes);
            }
            None => {
                let _ = std::fs::remove_file(&backup);
            }
        }
    }
    match valid {
        Err(reason) => Err(failure(
            "config.set_failed",
            format!("{key}: {reason} (nothing was written)"),
            Some("the merged config rejects this value; check bounds and enums"),
        )),
        Ok(()) => Ok(ScalarOutcome::Changed {
            target,
            old,
            rendered,
            applied: apply,
        }),
    }
}

/// Winner scan: the last layer declaring the full path wins a
/// replacement; otherwise the last layer declaring the parent
/// mapping wins an insertion. Anything else names the missing
/// parent instead of scattering a new key.
fn resolve_winner(
    paths: &AppPaths,
    layers: &[Layer],
    segments: &[&str],
) -> Result<(usize, Edit), ScalarFailure> {
    let mut replace: Option<(usize, String)> = None;
    for (index, layer) in layers.iter().enumerate() {
        if let Some(value) = walk(&layer.value, segments) {
            if !is_scalar(value) {
                return Err(ScalarFailure {
                    code: "usage.config_not_scalar",
                    reason: format!(
                        "`{}` holds a {} in {}; only scalars are settable",
                        segments.join("."),
                        if value.is_mapping() {
                            "section"
                        } else {
                            "list"
                        },
                        relative_to(&paths.config, &layer.path),
                    ),
                    hint: Some("use `caly config edit`, or set a deeper dotted key"),
                });
            }
            replace = Some((index, display_scalar(value)));
        }
    }
    if let Some((index, old)) = replace {
        return Ok((index, Edit::Replace(old)));
    }
    let parent = &segments[..segments.len() - 1];
    let mut holder = None;
    for (index, layer) in layers.iter().enumerate() {
        let holds = if parent.is_empty() {
            layer.value.is_mapping()
        } else {
            matches!(walk(&layer.value, parent), Some(Value::Mapping(_)))
        };
        if holds {
            holder = Some(index);
        }
    }
    holder.map_or_else(
        || {
            Err(ScalarFailure {
                code: "config.unknown_key",
                reason: format!(
                    "parent block `{}` is declared in no layer file",
                    parent.join(".")
                ),
                hint: Some("add the section with `caly config edit`, then set the key"),
            })
        },
        |index| Ok((index, Edit::Insert)),
    )
}

/// Prints the no-op receipt (idempotent call writes nothing).
fn report_unchanged(
    paths: &AppPaths,
    target: &Path,
    json: bool,
    key: &str,
    rendered: &str,
) -> ExitCode {
    if json {
        println!(
            "{}",
            caly_layout::CliOutput::success_envelope(serde_json::json!({
                "command": "config set",
                "key": key,
                "value": rendered,
                "file": relative_to(&paths.config, target),
                "unchanged": true,
            }))
        );
    } else {
        println!("{key} is already {rendered} (no change)");
    }
    ExitCode::SUCCESS
}

/// Prints the validated dry-run / applied receipt.
fn report_set(
    paths: &AppPaths,
    target: &Path,
    json: bool,
    key: &str,
    old: &str,
    rendered: &str,
    apply: bool,
) -> ExitCode {
    let file = relative_to(&paths.config, target);
    if json {
        println!(
            "{}",
            caly_layout::CliOutput::success_envelope(serde_json::json!({
                "command": "config set",
                "key": key,
                "old": old,
                "new": rendered,
                "file": file,
                "applied": apply,
            }))
        );
    } else if apply {
        caly_layout::ok(&format!("{key} = {rendered} (was {old}) in {file}"));
        caly_layout::hint("run `caly config apply` to push to the daemon");
    } else {
        // One line, like every other dry-run receipt (`would … —
        // dry-run, …`).
        println!("would set {key}: {old} → {rendered} in {file} — dry-run, pass --apply to write");
    }
    ExitCode::SUCCESS
}

/// Parses the `config set` value as YAML and renders the canonical
/// single-line scalar. Mappings, sequences, nulls, and anything
/// rendering across lines are refused (usage errors — the shape, not
/// the schema, rejects them).
fn render_scalar_value(raw: &str) -> Result<String, String> {
    let value: Value = serde_norway::from_str(raw.trim()).map_err(|error| {
        format!("value `{raw}` is not valid YAML: {error} (quote strings with special chars)")
    })?;
    if !is_scalar(&value) {
        return Err(format!(
            "only scalar values are settable (got a {}); use `caly config edit`",
            if value.is_mapping() {
                "section"
            } else {
                "list"
            }
        ));
    }
    let rendered =
        serde_norway::to_string(&value).map_err(|error| format!("cannot render value: {error}"))?;
    let rendered = rendered.trim_end().to_owned();
    if rendered.contains('\n') {
        return Err("multiline values are not settable; use `caly config edit`".to_owned());
    }
    Ok(rendered)
}

/// Applies the scalar replacement / insertion to one layer file's
/// text, preserving every other line byte-identically (comments,
/// order, blank lines). The parsed walk already proved the shape;
/// the span guards below are belt-and-braces against line/parse
/// disagreement on exotic documents.
fn patch_layer(text: &str, segments: &[&str], rendered: &str) -> Result<String, String> {
    let mut owned = text.to_owned();
    if !owned.ends_with('\n') {
        owned.push('\n');
    }
    let mut lines: Vec<String> = owned.lines().map(str::to_owned).collect();
    let leaf = segments[segments.len() - 1];
    if segments.len() == 1 {
        // Top-level leaf: replace in place, else append.
        if let Some(block) = locate_in(&lines, segments) {
            replace_line(&mut lines, &block, leaf, rendered)?;
        } else {
            lines.push(format!("{leaf}: {rendered}"));
        }
    } else if let Some(block) = locate_in(&lines, segments) {
        replace_line(&mut lines, &block, leaf, rendered)?;
    } else {
        let parent = &segments[..segments.len() - 1];
        let block = locate_in(&lines, parent).ok_or_else(|| {
            "line scan disagrees with the parsed tree; use `caly config edit`".to_owned()
        })?;
        expand_empty_flow_parent(&mut lines, &block);
        insert_line(&mut lines, &block, leaf, rendered);
    }
    let mut out = lines.join("\n");
    out.push('\n');
    Ok(out)
}

/// Rewrites a single-line empty-flow parent (`key: {}`, the shape the
/// generated default uses for `core_binaries:`) to block form before an
/// insertion: appending `  leaf: value` under `key: {}` would emit invalid
/// YAML. A trailing comment is preserved.
fn expand_empty_flow_parent(lines: &mut [String], block: &KeyBlock) {
    if block.end - block.start != 1 {
        return;
    }
    let line = lines[block.start].clone();
    let mut parts = line.splitn(2, '#');
    let head = parts.next().unwrap_or("");
    let comment = parts
        .next()
        .map(|tail| format!(" #{tail}"))
        .unwrap_or_default();
    let mut head_parts = head.splitn(2, ':');
    let key = head_parts.next().unwrap_or("").trim_end();
    let bare = key.trim_start();
    let rest = head_parts.next().unwrap_or("").trim();
    if rest == "{}" && !bare.is_empty() && !bare.contains([' ', '\t']) {
        lines[block.start] = format!("{key}:{comment}");
    }
}

/// Locates `path` in owned lines (borrows only for the scan).
fn locate_in(lines: &[String], path: &[&str]) -> Option<KeyBlock> {
    let refs: Vec<&str> = lines.iter().map(String::as_str).collect();
    locate_key_block(&refs, path)
}

/// Rewrites the scalar line of a located single-line block,
/// preserving the indentation and any trailing comment.
fn replace_line(
    lines: &mut [String],
    block: &KeyBlock,
    leaf: &str,
    rendered: &str,
) -> Result<(), String> {
    if block.end - block.start != 1 {
        return Err("unexpected block shape under the key; use `caly config edit`".to_owned());
    }
    let comment = extract_comment(&lines[block.start].clone());
    lines[block.start] = format!("{}{leaf}: {rendered}{comment}", " ".repeat(block.indent));
    Ok(())
}

/// Appends `leaf: rendered` to a located parent block: after its last
/// non-blank line, at the existing child indent (or the parent's +2
/// when the block is empty).
fn insert_line(lines: &mut Vec<String>, block: &KeyBlock, leaf: &str, rendered: &str) {
    let mut child_indent = None;
    let mut after = block.start;
    for (index, line) in lines
        .iter()
        .enumerate()
        .take(block.end)
        .skip(block.start + 1)
    {
        if line.trim().is_empty() {
            continue;
        }
        after = index;
        if child_indent.is_none() && !line.trim_start().starts_with('#') {
            child_indent = Some(indent_of(line));
        }
    }
    let indent = child_indent.unwrap_or(block.indent + 2);
    lines.insert(
        after + 1,
        format!("{}{leaf}: {rendered}", " ".repeat(indent)),
    );
}

/// Extracts the trailing ` # comment` of a scalar line (with its
/// leading space), or the empty string. The `#` must sit outside
/// quotes and be preceded by whitespace, mirroring YAML's own rule.
fn extract_comment(line: &str) -> String {
    let bytes = line.as_bytes();
    let mut quote = None;
    for (index, byte) in bytes.iter().enumerate() {
        match quote {
            Some(expected) => {
                if *byte == expected {
                    quote = None;
                }
            }
            None => match byte {
                b'\'' | b'"' => quote = Some(*byte),
                b'#' if index > 0 && bytes[index - 1].is_ascii_whitespace() => {
                    return format!(" {}", line[index..].trim_end());
                }
                _ => {}
            },
        }
    }
    String::new()
}

/// Leading-space width of a line.
fn indent_of(line: &str) -> usize {
    line.len() - line.trim_start_matches(' ').len()
}

/// Backup + atomic swap for the trial write. Errors name the file.
fn write_trial(target: &Path, new_text: &str) -> Result<(), String> {
    caly_configstore::config_writer::backup_config_yaml(target)
        .map_err(|error| format!("cannot back up {}: {error}", target.display()))?;
    caly_configstore::config_writer::write_atomic(target, new_text.as_bytes())
        .map_err(|error| format!("cannot write {}: {error}", target.display()))
}

/// Re-validates the merged tree after a trial write, with the
/// lenient profile resolver (a missing profile cache is unrelated
/// to a scalar edit and must not fail it).
fn validate_merged(paths: &AppPaths, profile: Option<&SafeName>) -> Result<(), String> {
    crate::client::load_layered_lenient(&paths.config, profile.cloned()).map(|_| ())
}
