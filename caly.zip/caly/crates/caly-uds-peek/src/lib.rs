//! The UDS peer probe: `recv(MSG_PEEK | MSG_DONTWAIT)` through a hand-written
//! `extern "C"` declaration — the same "no signal/FFI crate" doctrine as `ADR-056`
//! (`calyd`'s SIGTERM waiter), applied to the one syscall std does not expose for
//! `UnixStream`: a non-destructive peek.
//!
//! Why this crate exists: `caly-ipc` is `#![forbid(unsafe_code)]` — and that is a feature
//! worth keeping (the wire codec should never grow pointer arithmetic). The probe needs
//! four lines of `unsafe`; isolating them here gives the FFI a review surface of its own,
//! keeps the forbid intact at the consumer, and makes the platform scope honest:
//!
//! - Linux is the supported target (the systemd unit, the deployment story). The errno
//!   accessor (`__errno_location`) and the errno values below are glibc/musl facts.
//! - Other unixes compile to `Unknown` rather than guessing an ABI — the consumer maps
//!   `Unknown` to `PeerProbe::Indeterminate`, which is exactly the pre-ADR-059 honest
//!   answer, so nothing gets worse by compiling elsewhere.
//! - Non-unix does not exist for this workspace's binaries (no Windows target), but the
//!   crate stays a no-op there so the workspace still builds.
//!
//! The decision record is `docs/adrs/ADR-059-uds-peer-probe-via-msg-peek.md`.
//!
//! Semantics (mirroring what std's `TcpStream::peek` gives the TCP probe):
//! `recv` returns 0 → the peer performed an orderly shutdown (`Closed`); `> 0` → data is
//! pending (`Alive`); `-1` with `EAGAIN`/`EWOULDBLOCK` → open, nothing to read
//! (`Alive`); `-1` with `ECONNRESET` → the peer is gone (`Closed`); `EINTR` → retried;
//! anything else → `Unknown` (never invented into a verdict — the caller's pump keeps
//! waiting, which is the safe outcome for a live session).

#![cfg(unix)]
#![deny(unsafe_op_in_unsafe_fn)]

use std::os::unix::io::AsRawFd;

/// What the peek learned. `Unknown` is a first-class answer, not an error: the probe's
/// contract is "never invent a closed peer" (`TRANSPORT_RUNTIME_MODEL §5`).
#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub enum UdsPeek {
    /// The peer performed an orderly shutdown (recv 0) or the connection was reset.
    Closed,
    /// Open: data is pending, or nothing to read right now (EAGAIN).
    Alive,
    /// Not ascertainable on this platform/errno: the caller must keep waiting.
    Unknown,
}

#[cfg(target_os = "linux")]
mod ffi {
    // Hand-written, libc-crate-free (ADR-043 §2.5 / ADR-056 doctrine): four declarations,
    // three constants, all stable kernel ABIs.
    const MSG_PEEK: i32 = 0x2;
    const MSG_DONTWAIT: i32 = 0x40;
    const EINTR: i32 = 4;
    const EAGAIN: i32 = 11; // EWOULDBLOCK is the same value on Linux
    const ECONNRESET: i32 = 104;

    extern "C" {
        fn recv(socket: i32, buf: *mut u8, len: usize, flags: i32) -> isize;
        fn __errno_location() -> *mut i32;
    }

    pub fn peek(fd: i32) -> super::UdsPeek {
        // SAFETY: `recv` writes at most 1 byte into `buf`, which is 1 byte long; `fd` is
        // a live descriptor borrowed from the caller's socket for the call's duration.
        let mut buf = [0u8; 1];
        let result = unsafe { recv(fd, buf.as_mut_ptr(), buf.len(), MSG_PEEK | MSG_DONTWAIT) };
        if result == 0 {
            return super::UdsPeek::Closed;
        }
        if result > 0 {
            return super::UdsPeek::Alive;
        }
        // SAFETY: `__errno_location` returns the thread-local errno slot; reading it
        // immediately after the failing call is the documented use.
        let errno = unsafe { *__errno_location() };
        match errno {
            EAGAIN => super::UdsPeek::Alive,
            ECONNRESET => super::UdsPeek::Closed,
            EINTR => peek(fd), // interrupted before anything happened: try again
            _ => super::UdsPeek::Unknown,
        }
    }
}

#[cfg(target_os = "linux")]
pub use ffi::peek;

#[cfg(all(unix, not(target_os = "linux")))]
pub fn peek(_fd: i32) -> UdsPeek {
    // No guessed ABIs (errno accessors and values differ); the honest answer keeps the
    // consumer's pump waiting, exactly as before ADR-059.
    UdsPeek::Unknown
}

/// Peek at what the peer of this stream has (or has not) done, without consuming.
pub fn peek_stream<S: AsRawFd + ?Sized>(stream: &S) -> UdsPeek {
    peek(stream.as_raw_fd())
}

#[cfg(all(test, target_os = "linux"))]
mod tests {
    use super::*;
    use std::io::Write;
    use std::os::unix::net::UnixStream;

    /// A live pair with no traffic is Alive (EAGAIN is "open, nothing to read" —
    /// reporting Closed here would reap every healthy quiet session).
    #[test]
    fn a_quiet_live_pair_is_alive() {
        let (a, b) = UnixStream::pair().expect("pair");
        assert_eq!(peek_stream(&a), UdsPeek::Alive);
        drop(b);
    }

    /// Pending data is Alive and is NOT consumed: two peeks both see it, and the byte is
    /// still readable afterwards (that non-destructiveness is the whole point of PEEK).
    #[test]
    fn pending_data_is_alive_and_not_consumed() {
        let (mut a, mut b) = UnixStream::pair().expect("pair");
        b.write_all(b"x").expect("write");
        // Give the receiver's queue a moment to fill (a same-host pair is fast, but the
        // write is asynchronous from the peer's queue).
        std::thread::sleep(std::time::Duration::from_millis(50));
        assert_eq!(peek_stream(&a), UdsPeek::Alive);
        assert_eq!(peek_stream(&a), UdsPeek::Alive, "a peek consumes nothing");
        let mut buf = [0u8; 1];
        use std::io::Read;
        a.read_exact(&mut buf).expect("the byte is still there");
        assert_eq!(&buf, b"x");
    }

    /// An orderly peer shutdown is Closed — the case std never exposed and the reason
    /// this crate exists (`a stream client that leaves` can now be reaped on UDS too).
    #[test]
    fn a_dropped_peer_is_closed() {
        let (a, b) = UnixStream::pair().expect("pair");
        drop(b);
        // The FIN needs a scheduling tick to surface as recv()==0 on Linux.
        let mut seen = UdsPeek::Alive;
        for _ in 0..100 {
            seen = peek_stream(&a);
            if seen == UdsPeek::Closed {
                break;
            }
            std::thread::sleep(std::time::Duration::from_millis(10));
        }
        assert_eq!(
            seen,
            UdsPeek::Closed,
            "a dropped peer must surface as Closed"
        );
    }
}
