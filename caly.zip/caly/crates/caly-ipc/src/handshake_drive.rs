//! Handshake-only `ClientLoop` over the v0 dialect.
//!
//! Round 87 (`ROADMAP §13#3`): production `caly` used to send dialect hello
//! bytes and validate the ack, never touching `ClientLoop`. The typed loop
//! existed, unused. Wiring `send_request_frame` into the CLI would be a second
//! request table — v0 is a string op plus extras (`§8.11` / R76). This module
//! drives **hello only**:
//!
//! 1. `ClientLoop::open_handshake` advances New → HelloSent.
//! 2. The bytes on the wire are still `client_hello_payload` (dialect), not a
//!    typed `ClientHello` encoding. Typed `Encoding` has no `Records` variant;
//!    a records session still maps to `Encoding::Json` on the typed side.
//! 3. The ack is parsed as dialect records, then `client_validate_hello_ack`.
//! 4. Only after that gate does `observe_hello_ack` run.
//!
//! The CLI role on this config is `Admin`. `ClientSessionConfig::default` is
//! `Operator` (`ADR-037 §2.2`); the production CLI has always identified as
//! Admin, and the daemon's lenient parse maps unknown roles to Admin. Putting
//! Operator on the wire would be a silent privilege drop dressed as "use the
//! default".

use caly_api::Role;

use crate::client::{ClientSessionConfig, ClientSessionState};
use crate::client_loop::{ClientLoop, ClientLoopAction};
use crate::dialect::{
    client_hello_payload, client_validate_hello_ack, server_hello_ack_from_records, HelloAckView,
};
use crate::duplex::FramePump;
use crate::endpoint::WireIo;
use crate::frame::{Compression, Encoding};
use crate::handshake::ServerHelloAck;
use crate::wire::{wire_parse_records, WIRE_KIND_HELLO, WIRE_KIND_HELLO_ACK};

/// The config production `caly` puts on `ClientLoop`. Role is whatever the caller declared
/// (`caly --role`, defaulting to Admin); typed encoding is Json even for a records session —
/// the typed layer has no Records variant, and `apply_hello_ack` only checks protocol major.
pub fn cli_handshake_config(role: Role) -> ClientSessionConfig {
    ClientSessionConfig {
        client_name: "caly-cli".to_owned(),
        role,
        requested_encoding: Encoding::Json,
        requested_compression: Compression::None,
        ..ClientSessionConfig::default()
    }
}

/// What a successful handshake hands back: the loop now `Active`, and the
/// dialect view the CLI already printed to stderr.
pub struct HandshakeDrive {
    pub client: ClientLoop,
    pub ack: HelloAckView,
}

/// Drive hello over an existing pump. The pump owns timeouts; this function
/// does not call `send_request_frame`. The caller declares its wire role
/// (`caly --role`); the daemon's fail-closed parse (`server_hello_role`) is
/// what turns a bogus claim into a named refusal, not this client.
pub fn drive_client_hello<S: WireIo>(
    pump: &mut FramePump<S>,
    json: bool,
    role: Role,
) -> Result<HandshakeDrive, String> {
    let mut client = ClientLoop::new(cli_handshake_config(role));
    match client.open_handshake() {
        ClientLoopAction::OutboundHello(_) => {}
        other => {
            return Err(format!(
                "open_handshake must yield OutboundHello, got {other:?}"
            ))
        }
    }
    if client.snapshot().state != ClientSessionState::HelloSent {
        return Err(format!(
            "open_handshake must leave the client HelloSent, got {:?}",
            client.snapshot().state
        ));
    }

    // Dialect bytes, not the typed ClientHello. A records session omits the
    // encoding key; a json session asks for json. Either way the typed loop
    // still holds Encoding::Json. The bytes carry the caller's declared role —
    // the typed config above and the wire record below must not disagree about
    // it (a role the config holds but the hello bytes omit is a silent
    // promotion to whatever the daemon parses).
    pump.send(WIRE_KIND_HELLO, &client_hello_payload(role, json))
        .map_err(|error| error.summary)?;

    let (kind, payload) = pump
        .recv()
        .map_err(|error| {
            if error.timed_out {
                format!("timed out waiting for hello_ack: {}", error.summary)
            } else {
                error.summary
            }
        })?
        .ok_or_else(|| "the daemon closed the connection during hello".to_owned())?;
    if kind != WIRE_KIND_HELLO_ACK {
        return Err(format!("expected hello_ack, got frame kind {kind}"));
    }

    let text = String::from_utf8_lossy(&payload).into_owned();
    let view = server_hello_ack_from_records(&wire_parse_records(&text))?;
    client_validate_hello_ack(&view, json)?;

    let ack = hello_ack_view_to_typed(&view)?;
    client.observe_hello_ack(ack)?;
    if client.snapshot().state != ClientSessionState::Active {
        return Err(format!(
            "observe_hello_ack must leave the client Active, got {:?}",
            client.snapshot().state
        ));
    }
    Ok(HandshakeDrive { client, ack: view })
}

/// Map a dialect ack onto the typed `ServerHelloAck`. `records` and `json`
/// both become `Encoding::Json` — the typed enum has no Records. `msgpack`
/// becomes `MsgPack`. Anything else is refused by name; guessing would let a
/// peer pick an encoding the typed layer cannot even name.
pub fn hello_ack_view_to_typed(view: &HelloAckView) -> Result<ServerHelloAck, String> {
    Ok(ServerHelloAck {
        protocol: view.protocol,
        daemon_name: view.daemon_name.clone(),
        daemon_version: view.daemon_version.clone(),
        instance_id: view.instance_id.clone(),
        selected_encoding: dialect_encoding_to_typed(&view.encoding)?,
        selected_compression: dialect_compression_to_typed(&view.compression)?,
        server_features: Vec::new(),
        state_revision: 0,
    })
}

pub fn dialect_encoding_to_typed(name: &str) -> Result<Encoding, String> {
    match name {
        "records" | "json" => Ok(Encoding::Json),
        "msgpack" => Ok(Encoding::MsgPack),
        other => Err(format!(
            "encoding {other:?} is not a typed Encoding; the typed layer speaks json and msgpack, \
             and a records session maps to json"
        )),
    }
}

pub fn dialect_compression_to_typed(name: &str) -> Result<Compression, String> {
    match name {
        "none" => Ok(Compression::None),
        "zstd" => Ok(Compression::Zstd),
        other => Err(format!(
            "compression {other:?} is not on the v0 wire; v0 speaks none"
        )),
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::dialect::server_hello_ack_records;
    use crate::duplex::MemoryIo;
    use crate::wire::{wire_records_payload, wire_write_frame, WIRE_KIND_HELLO_ACK};

    fn ack_bytes(session_json: bool) -> Vec<u8> {
        let payload = wire_records_payload(&server_hello_ack_records(
            "calyd",
            "0.0-test",
            "inst-drive",
            session_json,
        ));
        let mut sink = Vec::new();
        wire_write_frame(&mut sink, WIRE_KIND_HELLO_ACK, &payload).expect("frame");
        sink
    }

    fn drive(json: bool) -> HandshakeDrive {
        let mut pump = FramePump::new(MemoryIo::from_bytes(ack_bytes(json)), None).expect("pump");
        drive_client_hello(&mut pump, json, Role::Admin).expect("handshake")
    }

    #[test]
    fn a_records_session_leaves_the_loop_active_and_maps_encoding_to_json() {
        let drive = drive(false);
        assert_eq!(drive.client.snapshot().state, ClientSessionState::Active);
        assert_eq!(drive.ack.encoding, "records");
        assert_eq!(
            drive
                .client
                .session
                .snapshot()
                .daemon
                .as_ref()
                .expect("daemon")
                .selected_encoding,
            Encoding::Json,
            "typed layer has no Records; records maps to Json"
        );
        assert_eq!(
            drive.client.snapshot().daemon_instance_id.as_deref(),
            Some("inst-drive")
        );
    }

    #[test]
    fn a_json_session_is_the_same_typed_encoding() {
        let drive = drive(true);
        assert_eq!(drive.ack.encoding, "json");
        assert_eq!(
            drive
                .client
                .session
                .snapshot()
                .daemon
                .as_ref()
                .expect("daemon")
                .selected_encoding,
            Encoding::Json
        );
    }

    #[test]
    fn the_cli_config_is_admin_not_the_operator_default() {
        let config = cli_handshake_config(Role::Admin);
        assert_eq!(config.role, Role::Admin);
        assert_eq!(config.client_name, "caly-cli");
        assert_eq!(ClientSessionConfig::default().role, Role::Operator);
        assert_ne!(
            config.role,
            ClientSessionConfig::default().role,
            "production CLI must not silently inherit Operator"
        );
    }

    #[test]
    fn an_encoding_lie_is_refused_before_observe() {
        let payload = wire_records_payload(&server_hello_ack_records("fake", "0", "x", false));
        // Rewrite encoding=records to encoding=msgpack after the dialect helper
        // built a honest ack — the lie is the peer's, not ours.
        let text = String::from_utf8(payload)
            .unwrap()
            .replace("encoding=records", "encoding=msgpack");
        let mut sink = Vec::new();
        wire_write_frame(&mut sink, WIRE_KIND_HELLO_ACK, text.as_bytes()).expect("frame");
        let mut pump = FramePump::new(MemoryIo::from_bytes(sink), None).expect("pump");
        let error = match drive_client_hello(&mut pump, false, Role::Admin) {
            Err(error) => error,
            Ok(_) => panic!("an encoding lie must not become Active"),
        };
        assert!(
            error.contains("encoding mismatch") && error.contains("msgpack"),
            "{error}"
        );
    }

    #[test]
    fn a_protocol_lie_is_refused_before_observe() {
        let payload = wire_records_payload(&server_hello_ack_records("fake", "0", "x", false));
        let text = String::from_utf8(payload)
            .unwrap()
            .replace("major=1", "major=2");
        let mut sink = Vec::new();
        wire_write_frame(&mut sink, WIRE_KIND_HELLO_ACK, text.as_bytes()).expect("frame");
        let mut pump = FramePump::new(MemoryIo::from_bytes(sink), None).expect("pump");
        let error = match drive_client_hello(&mut pump, false, Role::Admin) {
            Err(error) => error,
            Ok(_) => panic!("a protocol lie must not become Active"),
        };
        assert!(
            error.contains("protocol mismatch") && error.contains("2"),
            "{error}"
        );
    }

    #[test]
    fn handshake_does_not_advance_the_request_id() {
        let drive = drive(false);
        assert_eq!(
            drive.client.snapshot().next_request_id,
            1,
            "hello must not mint a request id; send_request_frame is out of scope"
        );
    }

    #[test]
    fn dialect_records_and_json_share_typed_json() {
        assert_eq!(
            dialect_encoding_to_typed("records").unwrap(),
            Encoding::Json
        );
        assert_eq!(dialect_encoding_to_typed("json").unwrap(), Encoding::Json);
        assert_eq!(
            dialect_encoding_to_typed("msgpack").unwrap(),
            Encoding::MsgPack
        );
        let error = dialect_encoding_to_typed("cbor").unwrap_err();
        assert!(error.contains("cbor"), "{error}");
    }

    #[test]
    fn dialect_compression_none_is_the_only_v0_value() {
        assert_eq!(
            dialect_compression_to_typed("none").unwrap(),
            Compression::None
        );
        let error = dialect_compression_to_typed("gzip").unwrap_err();
        assert!(error.contains("gzip"), "{error}");
    }

    #[test]
    fn a_wrong_frame_kind_is_named() {
        let mut sink = Vec::new();
        wire_write_frame(&mut sink, 4, b"request_id=1").expect("frame");
        let mut pump = FramePump::new(MemoryIo::from_bytes(sink), None).expect("pump");
        let error = match drive_client_hello(&mut pump, false, Role::Admin) {
            Err(error) => error,
            Ok(_) => panic!("a request frame must not pass for hello_ack"),
        };
        assert!(
            error.contains("expected hello_ack") && error.contains("4"),
            "{error}"
        );
    }
}
