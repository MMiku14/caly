use crate::frame::{ClientFrame, Compression, Encoding, FrameHeader, ServerFrame};

#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub enum FrameSide {
    Client,
    Server,
}

#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub enum FrameType {
    Hello,
    Request,
    Response,
    Stream,
    StreamAck,
    Close,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct EncodedFrame {
    pub header: FrameHeader,
    pub payload: Vec<u8>,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub enum DecodeErrorCode {
    Truncated,
    InvalidLength,
    UnknownFrameType,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct DecodeError {
    pub code: DecodeErrorCode,
    pub summary: String,
}

pub fn classify_client_frame(frame: &ClientFrame) -> FrameType {
    match frame {
        ClientFrame::Request(_) => FrameType::Request,
        ClientFrame::StreamAck(_) => FrameType::StreamAck,
    }
}

pub fn classify_server_frame(frame: &ServerFrame) -> FrameType {
    match frame {
        ServerFrame::Response(_) => FrameType::Response,
        ServerFrame::Stream(_) => FrameType::Stream,
    }
}

pub fn is_control_client_frame(frame: &ClientFrame) -> bool {
    matches!(
        classify_client_frame(frame),
        FrameType::Request | FrameType::StreamAck
    )
}

pub fn is_control_server_frame(frame: &ServerFrame) -> bool {
    matches!(classify_server_frame(frame), FrameType::Response)
}

pub fn make_header(length: usize, encoding: Encoding, compression: Compression) -> FrameHeader {
    FrameHeader {
        // Saturating, not `as u32`: a wrapped length would make an absurd frame look small enough
        // to pass `validate_frame_header`, pushing the rejection to a confusing payload-length
        // mismatch instead of `FrameTooLarge`.
        length: u32::try_from(length).unwrap_or(u32::MAX),
        encoding,
        compression,
    }
}

pub fn encode_raw_json(
    payload: &str,
    encoding: Encoding,
    compression: Compression,
) -> EncodedFrame {
    EncodedFrame {
        header: make_header(payload.len(), encoding, compression),
        payload: payload.as_bytes().to_vec(),
    }
}

/// Why a bounded outbound frame was refused, in the operator's terms.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct EncodeError {
    pub summary: String,
}

/// The outbound half of `MAX_FRAME_SIZE_BYTES` (`OVERLOAD_AND_RETRY_MODEL`'s round-40 note: the
/// cap was checked on *inbound* frames only, so `encode_raw_json` would happily build a frame the
/// peer must refuse to receive — a server handing the transport an error instead of an answer.
///
/// An answer this large is a **server bug** (answers are bounded where they are assembled, e.g.
/// `DiagnosticBudget`), so the refusal is loud and local: the frame is not built, and the caller
/// decides how the connection hears about it. `encode_raw_json` keeps its legacy shape for the
/// handshake, whose messages the protocol itself caps.
pub fn encode_raw_json_bounded(
    payload: &str,
    encoding: Encoding,
    compression: Compression,
) -> Result<EncodedFrame, EncodeError> {
    let cap = crate::policy::MAX_FRAME_SIZE_BYTES as usize;
    if payload.len() > cap {
        return Err(EncodeError {
            summary: format!(
                "outbound frame {} bytes exceeds MAX_FRAME_SIZE_BYTES {cap}; an answer this large \
                 is a server bug, not a frame — bound it where it is assembled",
                payload.len()
            ),
        });
    }
    Ok(encode_raw_json(payload, encoding, compression))
}

pub fn decode_raw_json(frame: &EncodedFrame) -> Result<String, DecodeError> {
    if frame.header.length as usize != frame.payload.len() {
        return Err(DecodeError {
            code: DecodeErrorCode::InvalidLength,
            summary: format!(
                "declared frame length {} does not match payload length {}",
                frame.header.length,
                frame.payload.len()
            ),
        });
    }

    String::from_utf8(frame.payload.clone()).map_err(|_| DecodeError {
        code: DecodeErrorCode::Truncated,
        summary: "frame payload is not valid utf-8 json text".to_owned(),
    })
}
