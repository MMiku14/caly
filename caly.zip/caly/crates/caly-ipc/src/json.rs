//! Flat, string-valued JSON objects: the **negotiated op-payload encoding** (`ADR-034`).
//!
//! The v0 wire speaks record frames by default; a client whose hello carried
//! `encoding=json` gets every op payload (requests and responses, refusals included) as one
//! JSON object instead — with **the same keys the records would have carried and the same
//! string values**. That is the whole contract: the encoding changes how a fact is written,
//! never which facts exist. A key that appears in one encoding and not the other is a bug
//! this module's judges are built to bite.
//!
//! The shape is deliberately narrow — `{ "key": "value", ... }`, nothing else. No numbers, no
//! nesting, no arrays: every value on the v0 wire is a string, and a JSON face wider than the
//! record face would be a second protocol wearing the first one's handshake. Malformed input
//! is refused by name, never repaired: a decoder that forgives trailing garbage is a
//! protocol that accepts messages it cannot explain.

/// Escape a string for a JSON string literal. `"` and `\` first, then the control characters
/// that have short forms, then any other control byte as `\u00xx` — the same set
/// `RFC 8259 §7` names, nothing invented.
fn json_escape(value: &str) -> String {
    let mut out = String::with_capacity(value.len() + 2);
    for ch in value.chars() {
        match ch {
            '"' => out.push_str("\\\""),
            '\\' => out.push_str("\\\\"),
            '\n' => out.push_str("\\n"),
            '\r' => out.push_str("\\r"),
            '\t' => out.push_str("\\t"),
            '\u{08}' => out.push_str("\\b"),
            '\u{0C}' => out.push_str("\\f"),
            ch if (ch as u32) < 0x20 => {
                out.push_str(&format!("\\u{:04x}", ch as u32));
            }
            ch => out.push(ch),
        }
    }
    out
}

/// Records → one flat JSON object. Empty records are `{}` — a present-but-empty answer, not
/// an error: the records face prints an empty answer too.
pub fn json_from_records(records: &[(String, String)]) -> String {
    let mut out = String::from("{");
    for (index, (key, value)) in records.iter().enumerate() {
        if index > 0 {
            out.push(',');
        }
        out.push('"');
        out.push_str(&json_escape(key));
        out.push_str("\":\"");
        out.push_str(&json_escape(value));
        out.push('"');
    }
    out.push('}');
    out
}

/// One flat JSON object → records. Strict: the object must end where it says it ends, every
/// key and value must be a quoted string, and every escape must be one JSON defines. Anything
/// else is an error naming the position — repaired input is input the daemon did not receive.
pub fn json_to_records(payload: &str) -> Result<Vec<(String, String)>, String> {
    let bytes: Vec<char> = payload.chars().collect();
    let mut at = 0usize;
    let skip_ws = |at: &mut usize| {
        while *at < bytes.len() && bytes[*at].is_ascii_whitespace() {
            *at += 1;
        }
    };

    skip_ws(&mut at);
    if at >= bytes.len() || bytes[at] != '{' {
        return Err(format!(
            "expected '{{' at position {at}, found {:?}",
            bytes.get(at).map(|ch| ch.to_string()).unwrap_or_default()
        ));
    }
    at += 1;
    let mut records = Vec::new();
    loop {
        skip_ws(&mut at);
        if at < bytes.len() && bytes[at] == '}' {
            at += 1;
            break;
        }
        if !records.is_empty() {
            if at >= bytes.len() || bytes[at] != ',' {
                return Err(format!(
                    "expected ',' or '}}' at position {at} (a JSON object separates members with ',')"
                ));
            }
            at += 1;
            skip_ws(&mut at);
        }
        let key = json_string(&bytes, &mut at)?;
        skip_ws(&mut at);
        if at >= bytes.len() || bytes[at] != ':' {
            return Err(format!("expected ':' after key at position {at}"));
        }
        at += 1;
        skip_ws(&mut at);
        let value = json_string(&bytes, &mut at)?;
        records.push((key, value));
    }
    skip_ws(&mut at);
    if at != bytes.len() {
        return Err(format!(
            "trailing garbage after the object at position {at}: a repaired payload is a \
             payload the daemon did not receive"
        ));
    }
    Ok(records)
}

/// One quoted JSON string, escapes resolved. The escape set is exactly the one `json_escape`
/// writes; `\u` must be four hex digits.
fn json_string(bytes: &[char], at: &mut usize) -> Result<String, String> {
    if *at >= bytes.len() || bytes[*at] != '"' {
        return Err(format!(
            "expected a quoted string at position {at} (v0 JSON values are strings, nothing else)"
        ));
    }
    *at += 1;
    let mut out = String::new();
    loop {
        if *at >= bytes.len() {
            return Err("unterminated string".to_owned());
        }
        let ch = bytes[*at];
        *at += 1;
        match ch {
            '"' => return Ok(out),
            '\\' => {
                if *at >= bytes.len() {
                    return Err("unterminated escape".to_owned());
                }
                let escape = bytes[*at];
                *at += 1;
                match escape {
                    '"' => out.push('"'),
                    '\\' => out.push('\\'),
                    '/' => out.push('/'),
                    'n' => out.push('\n'),
                    'r' => out.push('\r'),
                    't' => out.push('\t'),
                    'b' => out.push('\u{08}'),
                    'f' => out.push('\u{0C}'),
                    'u' => {
                        if *at + 4 > bytes.len() {
                            return Err("\\u needs four hex digits".to_owned());
                        }
                        let hex: String = bytes[*at..*at + 4].iter().collect();
                        let code = u32::from_str_radix(&hex, 16)
                            .map_err(|_| format!("\\u{hex} is not four hex digits"))?;
                        let ch = char::from_u32(code)
                            .ok_or_else(|| format!("\\u{hex} is not a character"))?;
                        out.push(ch);
                        *at += 4;
                    }
                    other => {
                        return Err(format!(
                            "\\{other} is not a JSON escape (the set is \\\" \\\\ \\/ \\b \\f \\n \\r \\t \\uXXXX)"
                        ));
                    }
                }
            }
            ch => out.push(ch),
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    /// The round trip must survive every character both faces care about: the record
    /// separators (`=`, `%`, newline) and the JSON separators (`"`, `\`, `{`) — a value that
    /// breaks either face under either encoding is a fact that changes with its encoding.
    #[test]
    fn round_trip_survives_both_faces_separators() {
        let records = vec![
            ("probe%3Dx".to_owned(), "a=b\nc\"d\\e{f}".to_owned()),
            ("plain".to_owned(), "value".to_owned()),
        ];
        let json = json_from_records(&records);
        assert!(json.starts_with('{') && json.ends_with('}'));
        assert!(!json.contains('\n'), "compact: one line on the wire");
        let back = json_to_records(&json).expect("round trip");
        assert_eq!(back, records);
    }

    #[test]
    fn keys_are_escaped_like_values() {
        let records = vec![("key\"with\\quotes".to_owned(), "v".to_owned())];
        let json = json_from_records(&records);
        assert_eq!(json_to_records(&json).expect("round trip"), records);
    }

    /// Every way an object can be wrong is refused by name — never repaired into something
    /// nearby: trailing garbage, a number where a string belongs, a bare word, no object at
    /// all, and an invented escape.
    #[test]
    fn malformed_input_is_refused_not_repaired() {
        for bad in [
            "",
            "oops",
            "{} trailing",
            "{\"a\":1}",
            "{a:\"b\"}",
            "{\"a\":\"b\"",
            "{\"a\":\"\\x\"}",
            "{\"a\":\"b\",}",
            "{\"a\" \"b\"}",
        ] {
            assert!(
                json_to_records(bad).is_err(),
                "{bad:?} must be refused, not repaired"
            );
        }
    }

    #[test]
    fn empty_object_and_empty_values_round_trip() {
        assert_eq!(json_from_records(&[]), "{}");
        assert_eq!(json_to_records("{}").expect("empty"), Vec::new());
        let records = vec![("empty".to_owned(), String::new())];
        let json = json_from_records(&records);
        assert_eq!(json_to_records(&json).expect("round trip"), records);
    }

    /// Duplicate keys ride as two records — exactly like the records face, where a value
    /// containing a newline is two lines and first-match readers (wire_field) pick the first.
    /// The two faces must not differ in what they preserve.
    #[test]
    fn duplicate_keys_ride_like_the_records_face() {
        let records = vec![
            ("k".to_owned(), "first".to_owned()),
            ("k".to_owned(), "second".to_owned()),
        ];
        let json = json_from_records(&records);
        assert_eq!(json_to_records(&json).expect("round trip"), records);
    }
}
