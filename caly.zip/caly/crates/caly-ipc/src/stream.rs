use caly_api::{JobId, StreamId};

#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub enum StreamKind {
    Job,
    Deployment,
    Dashboard,
    Traffic,
    Logs,
    Connections,
}

#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub enum ResetReason {
    Overflow,
    DaemonRestarted,
    StateGapTooLarge,
    SubscriptionReplaced,
}

#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub enum JobOutcome {
    Succeeded,
    Failed,
    Cancelled,
    TimedOut,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub enum StreamPayload {
    SnapshotJson(String),
    PatchJson(String),
    Reset {
        reason: ResetReason,
    },
    CommandAccepted {
        job_id: JobId,
        revision: u64,
    },
    CommandRejected {
        reason: String,
    },
    RuntimeState {
        active_profile: Option<String>,
        active_core: Option<String>,
        active_snapshot: Option<String>,
        state_revision: u64,
        summary: String,
    },
    DeploymentEvent {
        summary: String,
    },
    SnapshotCommitted {
        snapshot_id: String,
    },
    RecoveryEvent {
        summary: String,
    },
    JobStage {
        job_id: JobId,
        stage: String,
        pct: Option<u8>,
    },
    JobWarning {
        job_id: JobId,
        message: String,
    },
    JobLog {
        job_id: JobId,
        level: String,
        message: String,
    },
    JobFailed {
        job_id: JobId,
        code: String,
        summary: String,
        remediation: Option<String>,
    },
    JobDone {
        job_id: JobId,
        outcome: JobOutcome,
    },
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct StreamFrame {
    pub stream_id: StreamId,
    pub seq: u64,
    pub kind: StreamKind,
    pub payload: StreamPayload,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct Ack {
    pub stream_id: StreamId,
    pub upto_seq: u64,
}
