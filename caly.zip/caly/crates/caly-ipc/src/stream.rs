use caly_api::{JobId, StreamId};

/// The single home of the subscription→stream-kind mapping (round 133, `R131-F4`): this
/// crate sees both sides (`caly_api::RuntimeSubscription` and `StreamKind`), so the mapping
/// lives here once — five hand copies across daemon/app once drifted by omission risk, and
/// the sixth variant (R130's `Deployment`) had to be threaded through four files.
pub fn stream_kind_for_subscription(subscription: caly_api::RuntimeSubscription) -> StreamKind {
    match subscription {
        caly_api::RuntimeSubscription::Dashboard => StreamKind::Dashboard,
        caly_api::RuntimeSubscription::Traffic => StreamKind::Traffic,
        caly_api::RuntimeSubscription::Logs => StreamKind::Logs,
        caly_api::RuntimeSubscription::Connections => StreamKind::Connections,
        caly_api::RuntimeSubscription::Deployment => StreamKind::Deployment,
    }
}

/// The subscription's wire-facing name, next to the mapping it feeds.
pub const fn subscription_kind_name(subscription: caly_api::RuntimeSubscription) -> &'static str {
    match subscription {
        caly_api::RuntimeSubscription::Dashboard => "dashboard",
        caly_api::RuntimeSubscription::Traffic => "traffic",
        caly_api::RuntimeSubscription::Logs => "logs",
        caly_api::RuntimeSubscription::Connections => "connections",
        caly_api::RuntimeSubscription::Deployment => "deployment",
    }
}

#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub enum StreamKind {
    Job,
    Deployment,
    Dashboard,
    Traffic,
    Logs,
    Connections,
}

#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub enum ResetReason {
    Overflow,
    DaemonRestarted,
    StateGapTooLarge,
    SubscriptionReplaced,
}

#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub enum JobOutcome {
    Succeeded,
    Failed,
    Cancelled,
    TimedOut,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub enum StreamPayload {
    SnapshotJson(String),
    PatchJson(String),
    Reset {
        reason: ResetReason,
    },
    CommandAccepted {
        job_id: JobId,
        revision: u64,
    },
    CommandRejected {
        reason: String,
    },
    RuntimeState {
        active_profile: Option<String>,
        active_core: Option<String>,
        active_snapshot: Option<String>,
        state_revision: u64,
        summary: String,
    },
    DeploymentEvent {
        summary: String,
    },
    SnapshotCommitted {
        snapshot_id: String,
    },
    RecoveryEvent {
        summary: String,
    },
    JobStage {
        job_id: JobId,
        stage: String,
        pct: Option<u8>,
    },
    JobWarning {
        job_id: JobId,
        message: String,
    },
    JobLog {
        job_id: JobId,
        level: String,
        message: String,
    },
    JobFailed {
        job_id: JobId,
        code: String,
        summary: String,
        remediation: Option<String>,
    },
    JobDone {
        job_id: JobId,
        outcome: JobOutcome,
    },
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct StreamFrame {
    pub stream_id: StreamId,
    pub seq: u64,
    pub kind: StreamKind,
    pub payload: StreamPayload,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct Ack {
    pub stream_id: StreamId,
    pub upto_seq: u64,
}
