//! Unified IPC layer for caly: wire protocol framing, client codecs, and server loops.

#![forbid(unsafe_code)]

pub mod protocol;
pub mod server;

pub use protocol::*;
pub use server::*;
