//! The v0 daemon wire: length-prefixed, kind-tagged **record frames**.
//!
//! `calyd` (round 43) defined this format inline; round 44 lifts it here because a second
//! speaker exists — the `caly` CLI — and a wire two implementations speak is a wire one
//! implementation must not own. The E2E judges deliberately keep their own tiny readers as
//! independent oracles: two implementations agreeing is evidence, one implementation
//! round-tripping itself is not.
//!
//! Not JSON: the typed-frame serializer for every operation is the transport runtime's work
//! (Phase 6), and a v0 that pretended to speak it would be a stub in the shape of a protocol.
//!
//! Frame layout: `[kind u8][len u32 BE][payload]`, payload = UTF-8 `key=value` lines with (stream frames carry the same record/JSON payload encoding as every op — one session, one encoding)
//! `%`→`%25`, `=`→`%3D`, newline→`%0A` escaping. The byte cap is `MAX_FRAME_SIZE_BYTES`,
//! enforced inbound (a declared length over the cap is refused before one payload byte is
//! read) and outbound (an over-cap frame is not built).

use std::io::{Read, Write};

use crate::policy::MAX_FRAME_SIZE_BYTES;

pub const WIRE_KIND_HELLO: u8 = 1;
pub const WIRE_KIND_HELLO_ACK: u8 = 2;
pub const WIRE_KIND_REQUEST: u8 = 3;
pub const WIRE_KIND_RESPONSE: u8 = 4;
pub const WIRE_KIND_REFUSAL: u8 = 5;
/// Round 51, the first stream frames: data pushes and the terminal end (job streams replay
/// their window then end; explicit acks belong to the reconnect path, `IPC_STREAM_POLICY §5`).
pub const WIRE_KIND_STREAM_DATA: u8 = 6;
pub const WIRE_KIND_STREAM_END: u8 = 7;
/// Round 52, the reconnect path: the client acks the event cursor it consumed; the daemon
/// confirms (`response` frame echoing `acked_upto`), and a resume continues from the acked
/// position — unacked emissions replay, because a Job stream is at-least-once.
pub const WIRE_KIND_STREAM_ACK: u8 = 8;

/// Escape a record value so `=` and newlines cannot smuggle structure (`%` goes first, so a
/// literal `probe%3Dx` can never masquerade as an escaped `probe=x`).
pub fn wire_escape(value: &str) -> String {
    value
        .replace('%', "%25")
        .replace('=', "%3D")
        .replace('\n', "%0A")
}

/// The one decode direction speakers need; malformed escapes stay literal rather than being
/// silently reinterpreted as structure.
pub fn wire_unescape(value: &str) -> String {
    let mut out = String::with_capacity(value.len());
    let mut rest = value;
    while let Some(at) = rest.find('%') {
        out.push_str(&rest[..at]);
        let tail = &rest[at + 1..];
        if let Some(next) = tail.strip_prefix("25") {
            out.push('%');
            rest = next;
        } else if let Some(next) = tail.strip_prefix("3D") {
            out.push('=');
            rest = next;
        } else if let Some(next) = tail.strip_prefix("0A") {
            out.push('\n');
            rest = next;
        } else {
            out.push('%');
            rest = tail;
        }
    }
    out.push_str(rest);
    out
}

/// Parse a payload into `(key, value)` records; a line without `=` is not a record.
pub fn wire_parse_records(payload: &str) -> Vec<(String, String)> {
    payload
        .lines()
        .filter_map(|line| {
            line.split_once('=')
                .map(|(k, v)| (k.to_owned(), wire_unescape(v)))
        })
        .collect()
}

pub fn wire_field<'a>(records: &'a [(String, String)], key: &str) -> Option<&'a str> {
    records
        .iter()
        .find(|(k, _)| k == key)
        .map(|(_, v)| v.as_str())
}

/// The owned-key form, for records whose keys are built at run time (indexed list lines).
pub fn wire_records_owned(records: &[(String, String)]) -> Vec<u8> {
    records
        .iter()
        .map(|(k, v)| format!("{k}={}", wire_escape(v)))
        .collect::<Vec<_>>()
        .join("\n")
        .into_bytes()
}

pub fn wire_records_payload(records: &[(&str, String)]) -> Vec<u8> {
    records
        .iter()
        .map(|(k, v)| format!("{k}={}", wire_escape(v)))
        .collect::<Vec<_>>()
        .join("\n")
        .into_bytes()
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct WireFrameError {
    pub summary: String,
    /// True when the underlying I/O was a timeout or would-block. Speakers that
    /// map timeouts to `docs/guides/EXIT_CODES.md` 11 (the CLI) need the kind; cap and encode
    /// refusals never set it. Without this field the kind is flattened into a
    /// summary string, and a silent peer becomes PROTO_MISMATCH instead of TIMEOUT.
    pub timed_out: bool,
}

impl WireFrameError {
    fn message(summary: impl Into<String>) -> Self {
        Self {
            summary: summary.into(),
            timed_out: false,
        }
    }

    fn from_io(prefix: &str, error: std::io::Error) -> Self {
        Self {
            summary: format!("{prefix}: {error}"),
            timed_out: matches!(
                error.kind(),
                std::io::ErrorKind::WouldBlock | std::io::ErrorKind::TimedOut
            ),
        }
    }
}

/// Write one frame. Over-cap payloads are refused before anything reaches the stream: a server
/// that cannot answer within the cap says so at home rather than handing the peer a transport
/// refusal shaped like an answer (`OVERLOAD` round 41).
pub fn wire_write_frame(
    stream: &mut impl Write,
    kind: u8,
    payload: &[u8],
) -> Result<(), WireFrameError> {
    if payload.len() > MAX_FRAME_SIZE_BYTES as usize {
        return Err(WireFrameError::message(format!(
            "outbound frame {kind} of {} bytes exceeds MAX_FRAME_SIZE_BYTES \
                 {MAX_FRAME_SIZE_BYTES}; bound the answer where it is assembled",
            payload.len()
        )));
    }
    let mut head = Vec::with_capacity(5);
    head.push(kind);
    head.extend_from_slice(&(payload.len() as u32).to_be_bytes());
    stream
        .write_all(&head)
        .and_then(|()| stream.write_all(payload))
        .and_then(|()| stream.flush())
        .map_err(|error| WireFrameError::from_io("write frame", error))
}

/// Read one frame. `Ok(None)` is a clean EOF — the peer went away. A declared length over the
/// cap is an error **before** any payload byte is read: swallowing over-cap bytes and then
/// answering is the shape the cap judges forbid.
pub fn wire_read_frame(stream: &mut impl Read) -> Result<Option<(u8, Vec<u8>)>, WireFrameError> {
    let mut head = [0u8; 5];
    match stream.read_exact(&mut head) {
        Ok(()) => {}
        Err(error) if error.kind() == std::io::ErrorKind::UnexpectedEof => return Ok(None),
        Err(error) => return Err(WireFrameError::from_io("read frame head", error)),
    }
    let kind = head[0];
    let len = u32::from_be_bytes([head[1], head[2], head[3], head[4]]) as usize;
    if len > MAX_FRAME_SIZE_BYTES as usize {
        return Err(WireFrameError::message(format!(
            "inbound frame of {len} bytes exceeds MAX_FRAME_SIZE_BYTES \
                 {MAX_FRAME_SIZE_BYTES}; refusing before reading the payload"
        )));
    }
    let mut payload = vec![0u8; len];
    stream
        .read_exact(&mut payload)
        .map_err(|error| WireFrameError::from_io("read frame payload", error))?;
    Ok(Some((kind, payload)))
}

#[cfg(test)]
mod tests {
    use super::*;

    /// Escaping is injective in the way that matters: a literal `%3D` in a value cannot come
    /// back out as `=`, and round-tripping preserves every character the format reserves.
    #[test]
    fn escaping_round_trips_and_literals_cannot_masquerade() {
        for value in [
            "plain",
            "a=b",
            "100%",
            "probe%3Dx",
            "line\nbreak",
            "",
            "=+=",
        ] {
            assert_eq!(
                wire_unescape(&wire_escape(value)),
                value,
                "round trip must preserve {value:?}"
            );
        }
        let escaped = wire_escape("probe%3Dx");
        assert_ne!(escaped, "probe=x", "a literal must not become structure");
        assert_eq!(wire_unescape("bad%ZZ"), "bad%ZZ", "malformed stays literal");
    }

    #[test]
    fn records_parse_and_fields_lookup() {
        let payload = String::from_utf8(wire_records_payload(&[
            ("a", "1".to_owned()),
            ("b", "x=y".to_owned()),
        ]))
        .expect("utf8");
        let records = wire_parse_records(&payload);
        assert_eq!(wire_field(&records, "a"), Some("1"));
        assert_eq!(wire_field(&records, "b"), Some("x=y"));
        assert_eq!(wire_field(&records, "c"), None);
    }

    /// The cap is enforced at both doors with the direction named, over an in-memory stream.
    #[test]
    fn the_cap_refuses_both_directions_without_touching_the_stream() {
        let cap = MAX_FRAME_SIZE_BYTES as usize;
        let over = vec![b'x'; cap + 1];
        let mut sink = Vec::new();
        let error = wire_write_frame(&mut sink, WIRE_KIND_RESPONSE, &over)
            .expect_err("an over-cap frame must not be written");
        assert!(error.summary.contains("outbound"), "{}", error.summary);
        assert!(sink.is_empty(), "nothing may reach the stream: {sink:?}");

        // Inbound: a declared length over the cap errors before the payload is read, and the
        // unread bytes are still in the stream for the caller to see.
        let mut head = Vec::new();
        head.push(WIRE_KIND_REQUEST);
        head.extend_from_slice(&((cap + 1) as u32).to_be_bytes());
        head.extend_from_slice(b"payload-bytes-that-must-not-be-read");
        let mut source = std::io::Cursor::new(head);
        let error = wire_read_frame(&mut source).expect_err("over-cap declared length");
        assert!(error.summary.contains("inbound"), "{}", error.summary);
        let position = source.position() as usize;
        assert_eq!(
            position, 5,
            "the payload must not have been read past the 5-byte head"
        );
    }

    /// A timed-out read is named as a timeout, not flattened into a generic I/O
    /// summary. Speakers that map this to `docs/guides/EXIT_CODES.md` 11 (the CLI) would
    /// otherwise report PROTO_MISMATCH for a silent peer.
    #[test]
    fn a_read_timeout_is_named_so_speakers_can_map_exit_11() {
        struct TimedOut;
        impl Read for TimedOut {
            fn read(&mut self, _buf: &mut [u8]) -> std::io::Result<usize> {
                Err(std::io::Error::new(
                    std::io::ErrorKind::TimedOut,
                    "would hang",
                ))
            }
        }
        let error = wire_read_frame(&mut TimedOut).expect_err("timeout");
        assert!(error.timed_out, "{error:?}");
        assert!(
            error.summary.contains("read frame head"),
            "{}",
            error.summary
        );
        assert!(
            !error.summary.starts_with("timed out after"),
            "the codec names the I/O; the speaker owns the exit-11 wording: {}",
            error.summary
        );
    }
}
