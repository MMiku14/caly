//! The v0 wire record dialect — one implementation, two users.
//!
//! `calyd`'s server loop and the `caly` CLI both speak the same record vocabulary
//! (hello / hello_ack / request header). Before round 71 each side parsed and emitted
//! its records by hand, so a key, a default or a validation rule could change on one
//! side without the other noticing — and the CLI, in particular, never read the
//! hello_ack at all (it checked only the frame *kind*). The functions here are the
//! single implementation of that vocabulary, faithful to the pre-existing wire shape:
//! the round moved code, it did not change bytes (one deliberate addition: the hello
//! ack now also echoes `major`/`minor`/`encoding`/`compression`, so a client can
//! *validate* the answer instead of believing the frame kind — see
//! `client_validate_hello_ack`).
//!
//! Handshake frames are always records, whatever the negotiated payload encoding
//! (`ADR-034`): the meta-language does not change with the payload encoding.

use crate::frame::{Compression, Encoding};
use crate::handshake::{ClientHello, ClientKind};
use crate::wire::{wire_field, wire_records_payload};
use caly_api::{ProtocolVersion, Role};

/// The hello the CLI sends — exactly the pre-round-71 shape: client_name, role, major,
/// minor, plus `encoding` when the session is JSON.
pub fn client_hello_records(role: Role, json: bool) -> Vec<(&'static str, String)> {
    let mut records = vec![
        ("client_name", "caly-cli".to_owned()),
        ("role", role_name(role).to_owned()),
        ("major", "1".to_owned()),
        ("minor", "0".to_owned()),
    ];
    if json {
        // The payload encoding is negotiated at hello (`ADR-034`): absent means records,
        // the v0 default. The handshake frames themselves stay records either way — the
        // meta-language does not change with the payload encoding.
        records.push(("encoding", "json".to_owned()));
    }
    records
}

/// The hello as bytes on the wire (the handshake codec is the shared `wire` module).
pub fn client_hello_payload(role: Role, json: bool) -> Vec<u8> {
    wire_records_payload(&client_hello_records(role, json))
}

/// The session payload encoding a hello asks for (the `encoding` record). Absent means
/// records, the v0 default; `json` opts in. Anything else is refused *by name* — the
/// refusal names the value, because a value the daemon cannot parse is not a value it
/// may guess the meaning of.
pub fn server_hello_session_json(records: &[(String, String)]) -> Result<bool, String> {
    match wire_field(records, "encoding") {
        None | Some("records") => Ok(false),
        Some("json") => Ok(true),
        Some(other) => Err(format!(
            "encoding {other:?} is not on the v0 wire; the payload encodings are records \
             (default) and json"
        )),
    }
}

/// The server's reading of a hello — the exact pre-round-71 rules, leniency included:
/// a missing or unparseable protocol field falls back to the v0 default, an unknown
/// role is Admin (the CLI has always identified as Admin), and `requested_encoding` is
/// the daemon's own preference (Json). The caller refuses unknown `encoding` values
/// *before* calling this (`server_hello_session_json`), so nothing here needs to
/// interpret them.
pub fn server_hello_from_records(records: &[(String, String)]) -> ClientHello {
    ClientHello {
        protocol: ProtocolVersion {
            major: wire_field(records, "major")
                .and_then(|value| value.parse().ok())
                .unwrap_or(1),
            minor: wire_field(records, "minor")
                .and_then(|value| value.parse().ok())
                .unwrap_or(0),
        },
        client_kind: ClientKind::Cli,
        client_name: wire_field(records, "client_name")
            .unwrap_or("unnamed")
            .to_owned(),
        requested_encoding: Encoding::Json,
        requested_compression: Compression::None,
        supported_features: Vec::new(),
        role: match wire_field(records, "role") {
            Some("Operator") => Role::Operator,
            Some("Viewer") => Role::Viewer,
            _ => Role::Admin,
        },
    }
}

fn role_name(role: Role) -> &'static str {
    match role {
        Role::Viewer => "Viewer",
        Role::Operator => "Operator",
        Role::Admin => "Admin",
        // Not a wire role: PrivilegedBroker is an in-process credential family, and the
        // CLI never claims it. The server's lenient parse maps any unknown value to
        // Admin, so emitting the label would be a lie — refuse to emit instead.
        Role::PrivilegedBroker => "Admin",
    }
}

/// The hello_ack the daemon emits: the pre-round-71 keys first and unchanged
/// (`daemon_name`, `daemon_version`, `instance_id`), then the round-71 echo of
/// `major`/`minor`/`encoding`/`compression` — the content a client can check the
/// answer against rather than believing the frame kind. `session_json` is the encoding
/// this session actually negotiated (records is the default).
pub fn server_hello_ack_records(
    daemon_name: &str,
    daemon_version: &str,
    instance_id: &str,
    session_json: bool,
) -> Vec<(&'static str, String)> {
    vec![
        ("daemon_name", daemon_name.to_owned()),
        ("daemon_version", daemon_version.to_owned()),
        ("instance_id", instance_id.to_owned()),
        ("major", "1".to_owned()),
        ("minor", "0".to_owned()),
        (
            "encoding",
            if session_json { "json" } else { "records" }.to_owned(),
        ),
        ("compression", "none".to_owned()),
    ]
}

/// What a client needs from the ack, parsed. Strict by design: a peer that does not
/// speak the dialect (a missing key) is not a peer to guess about — every key is named
/// in the refusal.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct HelloAckView {
    pub protocol: ProtocolVersion,
    pub daemon_name: String,
    pub daemon_version: String,
    pub instance_id: String,
    pub encoding: String,
    pub compression: String,
}

pub fn server_hello_ack_from_records(records: &[(String, String)]) -> Result<HelloAckView, String> {
    let required = |key: &str| {
        wire_field(records, key)
            .map(str::to_owned)
            .ok_or_else(|| format!("the daemon's hello_ack omits `{key}` — not the v0 dialect"))
    };
    let protocol = ProtocolVersion {
        major: required("major")?
            .parse()
            .map_err(|_| "the daemon's hello_ack `major` is not a number".to_owned())?,
        minor: required("minor")?
            .parse()
            .map_err(|_| "the daemon's hello_ack `minor` is not a number".to_owned())?,
    };
    Ok(HelloAckView {
        protocol,
        daemon_name: required("daemon_name")?,
        daemon_version: required("daemon_version")?,
        instance_id: required("instance_id")?,
        encoding: required("encoding")?,
        compression: required("compression")?,
    })
}

/// The client's compatibility gate over an answered hello: the daemon must speak the
/// same protocol major and the session encoding must be the one this session asked for.
/// A mismatch is a refusal that names both sides — the v0 client never looked at this
/// content at all before round 71.
pub fn client_validate_hello_ack(view: &HelloAckView, json_session: bool) -> Result<(), String> {
    if view.protocol.major != 1 {
        return Err(format!(
            "protocol mismatch: caly speaks major 1, the daemon answered {}.{}",
            view.protocol.major, view.protocol.minor
        ));
    }
    let expected = if json_session { "json" } else { "records" };
    if view.encoding != expected {
        return Err(format!(
            "payload encoding mismatch: this session asked for {expected}, the daemon \
             selected {}",
            view.encoding
        ));
    }
    Ok(())
}

/// The request the CLI sends (pre-round-71 shape: request_id, trace_id, operation,
/// extras, then records or JSON per the session encoding). The trace_id names its
/// caller — the CLI's own convention, now part of the dialect.
pub fn request_payload(
    request_id: u64,
    operation: &str,
    extra: &[(&str, String)],
    json: bool,
) -> Vec<u8> {
    let mut records: Vec<(&str, String)> = vec![
        ("request_id", request_id.to_string()),
        ("trace_id", format!("caly-cli-{request_id}")),
        ("operation", operation.to_owned()),
    ];
    records.extend_from_slice(extra);
    if json {
        let owned: Vec<(String, String)> = records
            .iter()
            .map(|(key, value)| ((*key).to_owned(), value.clone()))
            .collect();
        crate::json::json_from_records(&owned).into_bytes()
    } else {
        wire_records_payload(&records)
    }
}

/// The request header the daemon reads off the wire — the fields every operation
/// shares. Pre-round-71 leniency preserved exactly: a missing request_id is 0 (the v0
/// default; the reply sequence still works because there is one outstanding request per
/// session), a missing trace_id is "calyd-wire", deadline and idempotency_key are
/// optional. The operation string is left to the caller's op table: this is the header,
/// not the dispatch.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct RequestHead {
    pub request_id: u64,
    pub trace_id: String,
    pub deadline_ms: Option<u64>,
    pub idempotency_key: Option<String>,
    pub operation: String,
}

pub fn request_head_from_records(records: &[(String, String)]) -> RequestHead {
    RequestHead {
        request_id: wire_field(records, "request_id")
            .and_then(|value| value.parse().ok())
            .unwrap_or(0),
        trace_id: wire_field(records, "trace_id")
            .unwrap_or("calyd-wire")
            .to_owned(),
        deadline_ms: wire_field(records, "deadline_ms").and_then(|value| value.parse().ok()),
        idempotency_key: wire_field(records, "idempotency_key").map(str::to_owned),
        operation: wire_field(records, "operation").unwrap_or("").to_owned(),
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::json::json_to_records;

    fn parse(payload: &[u8]) -> Vec<(String, String)> {
        crate::wire::wire_parse_records(&String::from_utf8_lossy(payload))
    }

    #[test]
    fn client_hello_records_are_the_legacy_shape() {
        let records = client_hello_records(Role::Admin, false);
        let keys: Vec<&str> = records.iter().map(|(key, _)| *key).collect();
        assert_eq!(keys, ["client_name", "role", "major", "minor"]);
        let json_records = client_hello_records(Role::Admin, true);
        let json_keys: Vec<&str> = json_records.iter().map(|(key, _)| *key).collect();
        assert_eq!(
            json_keys,
            ["client_name", "role", "major", "minor", "encoding"]
        );
        assert_eq!(
            wire_field(
                &parse(&client_hello_payload(Role::Admin, false)),
                "client_name"
            )
            .unwrap(),
            "caly-cli"
        );
    }

    #[test]
    fn client_hello_payload_is_the_legacy_bytes() {
        assert_eq!(
            client_hello_payload(Role::Admin, false),
            b"client_name=caly-cli\nrole=Admin\nmajor=1\nminor=0".to_vec()
        );
        assert_eq!(
            client_hello_payload(Role::Admin, true),
            b"client_name=caly-cli\nrole=Admin\nmajor=1\nminor=0\nencoding=json".to_vec()
        );
    }

    #[test]
    fn request_payload_is_the_legacy_bytes_across_encodings() {
        let extra = [("job_id", "7".to_owned())];
        let records_bytes = request_payload(1, "jobs.events", &extra, false);
        assert_eq!(
            records_bytes,
            b"request_id=1\ntrace_id=caly-cli-1\noperation=jobs.events\njob_id=7".to_vec()
        );
        let json_bytes = request_payload(1, "jobs.events", &extra, true);
        let text = String::from_utf8(json_bytes).unwrap();
        let parsed = json_to_records(&text).unwrap();
        let plain = parse(&records_bytes);
        assert_eq!(parsed, plain, "both encodings carry the same records");
    }

    #[test]
    fn server_hello_session_json_defaults_to_records_and_accepts_json() {
        let empty: Vec<(String, String)> = Vec::new();
        assert!(!server_hello_session_json(&empty).unwrap());
        let records = vec![("encoding".to_owned(), "json".to_owned())];
        assert!(server_hello_session_json(&records).unwrap());
        let records = vec![("encoding".to_owned(), "records".to_owned())];
        assert!(!server_hello_session_json(&records).unwrap());
    }

    #[test]
    fn server_hello_session_json_refuses_unknown_names_by_name() {
        let records = vec![("encoding".to_owned(), "xml".to_owned())];
        let problem = server_hello_session_json(&records).unwrap_err();
        assert!(
            problem.contains("\"xml\"") && problem.contains("not on the v0 wire"),
            "{problem}"
        );
    }

    #[test]
    fn server_hello_from_records_keeps_the_legacy_defaults() {
        let empty: Vec<(String, String)> = Vec::new();
        let hello = server_hello_from_records(&empty);
        assert_eq!(hello.protocol, ProtocolVersion { major: 1, minor: 0 });
        assert_eq!(hello.client_name, "unnamed");
        assert_eq!(hello.role, Role::Admin);
        assert_eq!(hello.requested_encoding, Encoding::Json);
        assert_eq!(hello.requested_compression, Compression::None);
        assert!(hello.supported_features.is_empty());
        assert_eq!(hello.client_kind, ClientKind::Cli);
    }

    #[test]
    fn server_hello_from_records_maps_the_wire_roles_and_protocol() {
        let records = vec![
            ("major".to_owned(), "2".to_owned()),
            ("role".to_owned(), "Operator".to_owned()),
            ("client_name".to_owned(), "x".to_owned()),
        ];
        let hello = server_hello_from_records(&records);
        assert_eq!(hello.protocol, ProtocolVersion { major: 2, minor: 0 });
        assert_eq!(hello.role, Role::Operator);
        let records = vec![("role".to_owned(), "Viewer".to_owned())];
        assert_eq!(server_hello_from_records(&records).role, Role::Viewer);
        let records = vec![("role".to_owned(), "Root".to_owned())];
        assert_eq!(server_hello_from_records(&records).role, Role::Admin);
    }

    #[test]
    fn server_hello_ack_records_keep_the_legacy_keys_first_then_echo_the_session() {
        let records = server_hello_ack_records("calyd", "1.2.3", "inst-1", false);
        let keys: Vec<&str> = records.iter().map(|(key, _)| *key).collect();
        assert_eq!(
            keys,
            [
                "daemon_name",
                "daemon_version",
                "instance_id",
                "major",
                "minor",
                "encoding",
                "compression"
            ]
        );
        let json_records = server_hello_ack_records("calyd", "1.2.3", "inst-1", true);
        let encoding = json_records
            .iter()
            .find(|(key, _)| *key == "encoding")
            .unwrap()
            .1
            .as_str();
        assert_eq!(encoding, "json");
        let records_encoding = records
            .iter()
            .find(|(key, _)| *key == "encoding")
            .unwrap()
            .1
            .as_str();
        assert_eq!(records_encoding, "records");
    }

    #[test]
    fn server_hello_ack_from_records_names_every_omitted_key() {
        let view = server_hello_ack_from_records(&[]).unwrap_err();
        assert!(
            view.contains("`major`") && view.contains("not the v0 dialect"),
            "{view}"
        );
        let partial = server_hello_ack_from_records(&[
            ("major".to_owned(), "1".to_owned()),
            ("minor".to_owned(), "0".to_owned()),
        ])
        .unwrap_err();
        assert!(partial.contains("`daemon_name`"), "{partial}");
        let bad = server_hello_ack_from_records(&[
            ("major".to_owned(), "x".to_owned()),
            ("minor".to_owned(), "0".to_owned()),
            ("daemon_name".to_owned(), "calyd".to_owned()),
            ("daemon_version".to_owned(), "1".to_owned()),
            ("instance_id".to_owned(), "i".to_owned()),
            ("encoding".to_owned(), "records".to_owned()),
            ("compression".to_owned(), "none".to_owned()),
        ])
        .unwrap_err();
        assert!(bad.contains("not a number"), "{bad}");
    }

    #[test]
    fn client_validate_hello_ack_accepts_the_matching_session() {
        let view = HelloAckView {
            protocol: ProtocolVersion { major: 1, minor: 0 },
            daemon_name: "calyd".to_owned(),
            daemon_version: "1".to_owned(),
            instance_id: "i".to_owned(),
            encoding: "records".to_owned(),
            compression: "none".to_owned(),
        };
        assert!(client_validate_hello_ack(&view, false).is_ok());
        assert!(client_validate_hello_ack(&view, true).is_err());
        let json_view = HelloAckView {
            encoding: "json".to_owned(),
            ..view.clone()
        };
        assert!(client_validate_hello_ack(&json_view, true).is_ok());
        assert!(client_validate_hello_ack(&json_view, false).is_err());
    }

    #[test]
    fn client_validate_hello_ack_refuses_a_protocol_major_mismatch() {
        let mut view = HelloAckView {
            protocol: ProtocolVersion { major: 1, minor: 0 },
            daemon_name: "calyd".to_owned(),
            daemon_version: "1".to_owned(),
            instance_id: "i".to_owned(),
            encoding: "records".to_owned(),
            compression: "none".to_owned(),
        };
        view.protocol.major = 2;
        let problem = client_validate_hello_ack(&view, false).unwrap_err();
        assert!(
            problem.contains("protocol mismatch") && problem.contains("2"),
            "{problem}"
        );
    }

    #[test]
    fn request_head_from_records_keeps_the_legacy_defaults() {
        let empty: Vec<(String, String)> = Vec::new();
        let head = request_head_from_records(&empty);
        assert_eq!(head.request_id, 0);
        assert_eq!(head.trace_id, "calyd-wire");
        assert_eq!(head.deadline_ms, None);
        assert_eq!(head.idempotency_key, None);
        assert_eq!(head.operation, "");
        let full = request_head_from_records(&[
            ("request_id".to_owned(), "41".to_owned()),
            ("trace_id".to_owned(), "t".to_owned()),
            ("deadline_ms".to_owned(), "500".to_owned()),
            ("idempotency_key".to_owned(), "k".to_owned()),
            ("operation".to_owned(), "runtime.status".to_owned()),
        ]);
        assert_eq!(full.request_id, 41);
        assert_eq!(full.trace_id, "t");
        assert_eq!(full.deadline_ms, Some(500));
        assert_eq!(full.idempotency_key.as_deref(), Some("k"));
        assert_eq!(full.operation, "runtime.status");
    }

    #[test]
    fn the_dialect_round_trips_a_hello_and_its_ack() {
        // The two implementations of one vocabulary: what the client sends, the server
        // reads; what the server answers, the client checks.
        let hello = client_hello_records(Role::Admin, true);
        let hello_owned: Vec<(String, String)> = hello
            .iter()
            .map(|(key, value)| ((*key).to_owned(), value.clone()))
            .collect();
        assert!(server_hello_session_json(&hello_owned).unwrap());
        let server_hello = server_hello_from_records(&hello_owned);
        assert_eq!(server_hello.client_name, "caly-cli");
        assert_eq!(server_hello.role, Role::Admin);

        let ack = server_hello_ack_records("calyd", "9.9", "inst", true);
        let ack_owned: Vec<(String, String)> = ack
            .iter()
            .map(|(key, value)| ((*key).to_owned(), value.clone()))
            .collect();
        let view = server_hello_ack_from_records(&ack_owned).unwrap();
        assert_eq!(view.daemon_name, "calyd");
        assert_eq!(view.instance_id, "inst");
        assert!(client_validate_hello_ack(&view, true).is_ok());
    }
}
