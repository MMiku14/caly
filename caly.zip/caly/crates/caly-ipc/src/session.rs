use caly_api::{ProtocolVersion, RequestEnvelope, Role};

use crate::frame::{Compression, Encoding, FrameHeader};
use crate::handshake::{ClientHello, ClientKind, ServerHelloAck};
use crate::negotiate::{
    negotiate_hello, validate_frame_header, FrameValidationError, HandshakeError, NegotiationPolicy,
};

#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub enum SessionState {
    AwaitingHello,
    Active,
    Closed,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct SessionInfo {
    pub session_id: String,
    pub daemon_instance_id: String,
    pub protocol: ProtocolVersion,
    pub client_kind: ClientKind,
    pub role: Role,
    pub encoding: Encoding,
    pub compression: Compression,
    pub state_revision: u64,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct SessionMachine {
    pub policy: NegotiationPolicy,
    pub state: SessionState,
    pub info: Option<SessionInfo>,
}

#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub enum SessionValidationErrorCode {
    NotHandshaken,
    SessionClosed,
    ProtocolMismatch,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct SessionValidationError {
    pub code: SessionValidationErrorCode,
    pub summary: String,
}

impl SessionMachine {
    pub fn new(policy: NegotiationPolicy) -> Self {
        Self {
            policy,
            state: SessionState::AwaitingHello,
            info: None,
        }
    }

    pub fn accept_hello(
        &mut self,
        hello: &ClientHello,
        session_id: impl Into<String>,
        daemon_name: impl Into<String>,
        daemon_version: impl Into<String>,
        daemon_instance_id: impl Into<String>,
        state_revision: u64,
    ) -> Result<ServerHelloAck, HandshakeError> {
        if !matches!(self.state, SessionState::AwaitingHello) {
            return Err(HandshakeError {
                code: crate::negotiate::HandshakeErrorCode::ProtoMismatch,
                summary: "session is not awaiting hello".to_owned(),
            });
        }

        let daemon_instance_id = daemon_instance_id.into();
        let ack = negotiate_hello(
            hello,
            &self.policy,
            daemon_name,
            daemon_version,
            daemon_instance_id.clone(),
            state_revision,
        )?;

        self.info = Some(SessionInfo {
            session_id: session_id.into(),
            daemon_instance_id,
            protocol: ack.protocol,
            client_kind: hello.client_kind,
            role: hello.role,
            encoding: ack.selected_encoding,
            compression: ack.selected_compression,
            state_revision,
        });
        self.state = SessionState::Active;
        Ok(ack)
    }

    pub fn validate_frame(
        &self,
        header: &FrameHeader,
        is_control_message: bool,
    ) -> Result<(), FrameValidationError> {
        validate_frame_header(header, self.policy.max_frame_size_bytes, is_control_message)
    }

    pub fn validate_request(
        &self,
        envelope: &RequestEnvelope,
    ) -> Result<(), SessionValidationError> {
        match self.state {
            SessionState::AwaitingHello => {
                return Err(SessionValidationError {
                    code: SessionValidationErrorCode::NotHandshaken,
                    summary: "request received before hello negotiation".to_owned(),
                })
            }
            SessionState::Closed => {
                return Err(SessionValidationError {
                    code: SessionValidationErrorCode::SessionClosed,
                    summary: "request received on closed session".to_owned(),
                })
            }
            SessionState::Active => {}
        }

        let info = self.info.as_ref().ok_or_else(|| SessionValidationError {
            code: SessionValidationErrorCode::NotHandshaken,
            summary: "active session missing negotiated info".to_owned(),
        })?;

        if envelope.protocol.major != info.protocol.major {
            return Err(SessionValidationError {
                code: SessionValidationErrorCode::ProtocolMismatch,
                summary: format!(
                    "request protocol major mismatch: request={} session={}",
                    envelope.protocol.major, info.protocol.major
                ),
            });
        }

        Ok(())
    }

    pub fn close(&mut self) {
        self.state = SessionState::Closed;
    }
}
