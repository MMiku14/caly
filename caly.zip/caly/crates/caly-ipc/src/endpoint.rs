//! Shared bind / connect surface for the v0 production transport.
//!
//! Round 87 (`ROADMAP §13#3`): `calyd` and `caly` previously each owned a TCP-only
//! listener / `TcpStream` session. A Unix-domain socket was a second transport
//! dressed as a flag, not a second implementation of the same frame pump. This
//! module is the one parse + one bind + one stream type both binaries speak.
//!
//! Constraints this file is written against, not around:
//!
//! - `clippy.toml` bans `std::path::PathBuf` and `std::fs::File`. A UDS path is a
//!   `String`; the OS is addressed with `Path::new`. Tests that need a scratch
//!   name use process-id + a counter, not `Instant::now` / `SystemTime::now`.
//! - `std::os::unix::net::UnixStream` has no `peek`. TCP dead-peer detection
//!   stays `TcpStream::peek`; a UDS probe is `Alive` or `Indeterminate`, never a
//!   libc/`nix` peek without an ADR.
//! - TCP `--bind 127.0.0.1:0` plus `--port-file` still publishes a bare `u16` so
//!   `calyd_wire` / `caly_cli_e2e` keep parsing. A UDS listener publishes
//!   `unix:<path>` in the same file; that is a different advertise string, not a
//!   different port-file format pretending to be a number.
//!
//! Named pipes (`npipe:`, `\\.\pipe\`) and Linux abstract sockets (`@name`) are
//! refused by name. Windows is not a v0 host; an abstract address is a different
//! namespace that `unlink` cannot clean up.

use std::fmt;
use std::io::{self, Read, Write};
use std::net::{SocketAddr, TcpListener, TcpStream, ToSocketAddrs};
use std::path::Path;
use std::time::Duration;

#[cfg(unix)]
use std::os::unix::fs::{FileTypeExt, PermissionsExt};
#[cfg(unix)]
use std::os::unix::net::{UnixListener, UnixStream};

/// Conservative `sockaddr_un.sun_path` budget: Linux is 108 bytes including the
/// trailing NUL, so 107 usable. We refuse at 104 so a test that pads to 105 is
/// still under the kernel's hard cap and the refusal is ours, not `EINVAL`.
pub const UNIX_PATH_MAX: usize = 104;

/// Mode applied to a freshly bound UDS path by DEFAULT. World-readable sockets are how
/// `RFC-0010 §14` "UDS permissions" fails in production; 0o600 stays the default —
/// group sharing (e.g. 0o660 for an operator group) is an EXPLICIT opt-in via
/// [`WireListener::bind_with_unix_mode`] (round 134, the platform face: the daemon's
/// flag validates and passes it through; world-accessible bits are refused there).
pub const UNIX_SOCKET_MODE: u32 = 0o600;

#[derive(Clone, Debug, Eq, PartialEq)]
pub enum EndpointErrorKind {
    Usage,
    Unsupported,
    Io,
    /// A non-blocking listener had no client waiting yet (`accept` returned `WouldBlock`).
    /// Not a failure: the poll loop's "try again later".
    WouldBlock,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct EndpointError {
    pub kind: EndpointErrorKind,
    pub summary: String,
}

impl EndpointError {
    pub fn usage(summary: impl Into<String>) -> Self {
        Self {
            kind: EndpointErrorKind::Usage,
            summary: summary.into(),
        }
    }

    pub fn unsupported(summary: impl Into<String>) -> Self {
        Self {
            kind: EndpointErrorKind::Unsupported,
            summary: summary.into(),
        }
    }

    pub fn io(summary: impl Into<String>) -> Self {
        Self {
            kind: EndpointErrorKind::Io,
            summary: summary.into(),
        }
    }

    pub fn from_io(prefix: &str, error: io::Error) -> Self {
        Self::io(format!("{prefix}: {error}"))
    }
}

impl fmt::Display for EndpointError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.summary)
    }
}

impl std::error::Error for EndpointError {}

/// What an operator wrote on `--bind` / `--addr`. Parsing does not resolve DNS
/// and does not open a socket: a hostname without a port is still usage, and a
/// unix path that does not yet exist is still a valid spec.
#[derive(Clone, Debug, Eq, PartialEq)]
pub enum BindSpec {
    Tcp { host: String, port: u16 },
    Unix { path: String },
}

impl BindSpec {
    pub fn parse(raw: &str) -> Result<Self, EndpointError> {
        let raw = raw.trim();
        if raw.is_empty() {
            return Err(EndpointError::usage(
                "a bind spec is empty; expected host:port or unix:/path",
            ));
        }
        if raw.starts_with("npipe:")
            || raw.starts_with(r"\\.\pipe\")
            || raw.starts_with("//./pipe/")
        {
            return Err(EndpointError::unsupported(
                "named pipes are a Windows transport; this host speaks tcp and unix",
            ));
        }
        if raw.starts_with('@') || raw.starts_with("unix:@") {
            return Err(EndpointError::unsupported(
                "abstract unix sockets are not a v0 transport; unlink cannot clean them up",
            ));
        }
        if let Some(path) = raw.strip_prefix("unix://") {
            return unix_path(path);
        }
        if let Some(path) = raw.strip_prefix("unix:") {
            return unix_path(path);
        }
        if raw.starts_with('/') || raw.starts_with("./") || raw.starts_with("../") {
            return unix_path(raw);
        }
        parse_tcp(raw)
    }

    pub fn is_unix(&self) -> bool {
        matches!(self, BindSpec::Unix { .. })
    }

    pub fn is_tcp(&self) -> bool {
        matches!(self, BindSpec::Tcp { .. })
    }
}

impl fmt::Display for BindSpec {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            BindSpec::Tcp { host, port } => f.write_str(&display_tcp(host, *port)),
            BindSpec::Unix { path } => write!(f, "unix:{path}"),
        }
    }
}

fn unix_path(path: &str) -> Result<BindSpec, EndpointError> {
    if path.is_empty() {
        return Err(EndpointError::usage(
            "unix: is missing a path; expected unix:/absolute/path",
        ));
    }
    if path.contains('\0') {
        return Err(EndpointError::usage(
            "a unix path may not contain a NUL; sockaddr_un is a C string",
        ));
    }
    if path.len() > UNIX_PATH_MAX {
        return Err(EndpointError::usage(format!(
            "unix path is {} bytes; sockaddr_un.sun_path holds at most {UNIX_PATH_MAX}",
            path.len()
        )));
    }
    Ok(BindSpec::Unix {
        path: path.to_owned(),
    })
}

fn parse_tcp(raw: &str) -> Result<BindSpec, EndpointError> {
    if raw.starts_with('[') {
        let close = raw.find(']').ok_or_else(|| {
            EndpointError::usage(format!(
                "ipv6 bind {raw:?} is missing the closing bracket; expected [host]:port"
            ))
        })?;
        let host = &raw[1..close];
        let rest = &raw[close + 1..];
        let port = rest.strip_prefix(':').ok_or_else(|| {
            EndpointError::usage(format!(
                "ipv6 bind {raw:?} is missing :port after the bracket"
            ))
        })?;
        return tcp_host_port(host, port, raw);
    }
    match raw.rsplit_once(':') {
        Some((host, port))
            if !host.is_empty() && !host.contains('/') && !port.is_empty() && !host.contains('[') =>
        {
            tcp_host_port(host, port, raw)
        }
        _ => Err(EndpointError::usage(format!(
            "{raw:?} is not host:port and not a unix path; prefix with unix: or use an absolute path"
        ))),
    }
}

fn tcp_host_port(host: &str, port: &str, raw: &str) -> Result<BindSpec, EndpointError> {
    if host.is_empty() {
        return Err(EndpointError::usage(format!(
            "tcp bind {raw:?} has an empty host"
        )));
    }
    let port: u16 = port.parse().map_err(|_| {
        EndpointError::usage(format!(
            "tcp bind {raw:?} has a port that is not a u16: {port:?}"
        ))
    })?;
    Ok(BindSpec::Tcp {
        host: host.to_owned(),
        port,
    })
}

fn display_tcp(host: &str, port: u16) -> String {
    if host.contains(':') {
        format!("[{host}]:{port}")
    } else {
        format!("{host}:{port}")
    }
}

/// What the listener actually bound. For TCP with port 0 this is the kernel-chosen
/// port; for UDS it is the path after stale-socket unlink and chmod.
#[derive(Clone, Debug, Eq, PartialEq)]
pub enum BoundAddr {
    Tcp { host: String, port: u16 },
    Unix { path: String },
}

impl BoundAddr {
    /// TCP `--port-file` content is still a bare decimal `u16` so existing e2e
    /// parsers keep working. UDS writes `unix:<path>` — never a number.
    pub fn port_file_text(&self) -> String {
        match self {
            BoundAddr::Tcp { port, .. } => port.to_string(),
            BoundAddr::Unix { path } => format!("unix:{path}"),
        }
    }

    pub fn display(&self) -> String {
        match self {
            BoundAddr::Tcp { host, port } => display_tcp(host, *port),
            BoundAddr::Unix { path } => format!("unix:{path}"),
        }
    }

    pub fn tcp_port(&self) -> Option<u16> {
        match self {
            BoundAddr::Tcp { port, .. } => Some(*port),
            BoundAddr::Unix { .. } => None,
        }
    }
}

/// Result of a non-blocking liveness probe. TCP can distinguish closed from
/// alive via `peek`. UDS cannot, without libc; it reports `Indeterminate` and
/// the pump treats that as "keep waiting", matching the documented honesty.
#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub enum PeerProbe {
    Alive,
    Closed,
    Indeterminate,
}

/// Read/write + the two extra verbs the production pump needs: a read deadline
/// and a dead-peer probe. Implemented for `TcpStream`, `UnixStream`, and the
/// `WireStream` enum so `calyd` / `caly` share one loop.
pub trait WireIo: Read + Write {
    fn set_read_timeout(&self, timeout: Option<Duration>) -> io::Result<()>;
    fn set_write_timeout(&self, timeout: Option<Duration>) -> io::Result<()>;
    fn probe_peer(&self) -> io::Result<PeerProbe>;
    fn transport_kind(&self) -> &'static str;
}

impl WireIo for TcpStream {
    fn set_read_timeout(&self, timeout: Option<Duration>) -> io::Result<()> {
        TcpStream::set_read_timeout(self, timeout)
    }

    fn set_write_timeout(&self, timeout: Option<Duration>) -> io::Result<()> {
        TcpStream::set_write_timeout(self, timeout)
    }

    fn probe_peer(&self) -> io::Result<PeerProbe> {
        let mut buf = [0u8; 1];
        match self.peek(&mut buf) {
            Ok(0) => Ok(PeerProbe::Closed),
            Ok(_) => Ok(PeerProbe::Alive),
            Err(error)
                if error.kind() == io::ErrorKind::WouldBlock
                    || error.kind() == io::ErrorKind::TimedOut =>
            {
                Ok(PeerProbe::Alive)
            }
            Err(error) => Err(error),
        }
    }

    fn transport_kind(&self) -> &'static str {
        "tcp"
    }
}

#[cfg(unix)]
impl WireIo for UnixStream {
    fn set_read_timeout(&self, timeout: Option<Duration>) -> io::Result<()> {
        UnixStream::set_read_timeout(self, timeout)
    }

    fn set_write_timeout(&self, timeout: Option<Duration>) -> io::Result<()> {
        UnixStream::set_write_timeout(self, timeout)
    }

    fn probe_peer(&self) -> io::Result<PeerProbe> {
        // std has no `UnixStream::peek`; ADR-059 adds one through a hand-written
        // `recv(MSG_PEEK | MSG_DONTWAIT)` in the FFI-isolated `caly-uds-peek` crate
        // (this crate stays `#![forbid(unsafe_code)]`). `Unknown` (non-Linux, or an
        // errno we do not interpret) maps to Indeterminate — the pre-ADR-059 honest
        // answer, so an unprobed platform only loses the reap, never invents one.
        match caly_uds_peek::peek_stream(self) {
            caly_uds_peek::UdsPeek::Closed => Ok(PeerProbe::Closed),
            caly_uds_peek::UdsPeek::Alive => Ok(PeerProbe::Alive),
            caly_uds_peek::UdsPeek::Unknown => Ok(PeerProbe::Indeterminate),
        }
    }

    fn transport_kind(&self) -> &'static str {
        "unix"
    }
}

pub enum WireStream {
    Tcp(TcpStream),
    #[cfg(unix)]
    Unix(UnixStream),
}

impl WireStream {
    pub fn connect(spec: &BindSpec, timeout: Duration) -> Result<Self, EndpointError> {
        match spec {
            BindSpec::Tcp { host, port } => connect_tcp(host, *port, timeout),
            BindSpec::Unix { path } => connect_unix(path),
        }
    }

    pub fn from_tcp(stream: TcpStream) -> Self {
        WireStream::Tcp(stream)
    }

    #[cfg(unix)]
    pub fn from_unix(stream: UnixStream) -> Self {
        WireStream::Unix(stream)
    }
}

impl Read for WireStream {
    fn read(&mut self, buf: &mut [u8]) -> io::Result<usize> {
        match self {
            WireStream::Tcp(stream) => stream.read(buf),
            #[cfg(unix)]
            WireStream::Unix(stream) => stream.read(buf),
        }
    }
}

impl Write for WireStream {
    fn write(&mut self, buf: &[u8]) -> io::Result<usize> {
        match self {
            WireStream::Tcp(stream) => stream.write(buf),
            #[cfg(unix)]
            WireStream::Unix(stream) => stream.write(buf),
        }
    }

    fn flush(&mut self) -> io::Result<()> {
        match self {
            WireStream::Tcp(stream) => stream.flush(),
            #[cfg(unix)]
            WireStream::Unix(stream) => stream.flush(),
        }
    }
}

impl<T: WireIo + ?Sized> WireIo for &mut T {
    fn set_read_timeout(&self, timeout: Option<Duration>) -> io::Result<()> {
        (**self).set_read_timeout(timeout)
    }

    fn set_write_timeout(&self, timeout: Option<Duration>) -> io::Result<()> {
        (**self).set_write_timeout(timeout)
    }

    fn probe_peer(&self) -> io::Result<PeerProbe> {
        (**self).probe_peer()
    }

    fn transport_kind(&self) -> &'static str {
        (**self).transport_kind()
    }
}

impl WireIo for WireStream {
    fn set_read_timeout(&self, timeout: Option<Duration>) -> io::Result<()> {
        match self {
            WireStream::Tcp(stream) => stream.set_read_timeout(timeout),
            #[cfg(unix)]
            WireStream::Unix(stream) => stream.set_read_timeout(timeout),
        }
    }

    fn set_write_timeout(&self, timeout: Option<Duration>) -> io::Result<()> {
        match self {
            WireStream::Tcp(stream) => stream.set_write_timeout(timeout),
            #[cfg(unix)]
            WireStream::Unix(stream) => stream.set_write_timeout(timeout),
        }
    }

    fn probe_peer(&self) -> io::Result<PeerProbe> {
        match self {
            WireStream::Tcp(stream) => stream.probe_peer(),
            #[cfg(unix)]
            WireStream::Unix(stream) => stream.probe_peer(),
        }
    }

    fn transport_kind(&self) -> &'static str {
        match self {
            WireStream::Tcp(_) => "tcp",
            #[cfg(unix)]
            WireStream::Unix(_) => "unix",
        }
    }
}

fn connect_tcp(host: &str, port: u16, timeout: Duration) -> Result<WireStream, EndpointError> {
    let display = display_tcp(host, port);
    if let Ok(addr) = display.parse::<SocketAddr>() {
        let stream = TcpStream::connect_timeout(&addr, timeout)
            .map_err(|error| EndpointError::from_io(&format!("connect {display}"), error))?;
        return Ok(WireStream::Tcp(stream));
    }
    let mut addrs = (host, port)
        .to_socket_addrs()
        .map_err(|error| EndpointError::from_io(&format!("resolve {display}"), error))?;
    let addr = addrs.next().ok_or_else(|| {
        EndpointError::io(format!("resolve {display}: the name produced no addresses"))
    })?;
    let stream = TcpStream::connect_timeout(&addr, timeout)
        .map_err(|error| EndpointError::from_io(&format!("connect {display}"), error))?;
    Ok(WireStream::Tcp(stream))
}

#[cfg(unix)]
fn connect_unix(path: &str) -> Result<WireStream, EndpointError> {
    let stream = UnixStream::connect(Path::new(path))
        .map_err(|error| EndpointError::from_io(&format!("connect unix:{path}"), error))?;
    Ok(WireStream::Unix(stream))
}

#[cfg(not(unix))]
fn connect_unix(path: &str) -> Result<WireStream, EndpointError> {
    Err(EndpointError::unsupported(format!(
        "unix:{path} is not available on this host"
    )))
}

pub enum WireListener {
    Tcp(TcpListener),
    #[cfg(unix)]
    Unix {
        listener: UnixListener,
        path: String,
    },
}

impl WireListener {
    pub fn bind(spec: &BindSpec) -> Result<(Self, BoundAddr), EndpointError> {
        Self::bind_with_unix_mode(spec, UNIX_SOCKET_MODE)
    }

    /// Bind with an explicit UDS mode (round 134): the group-sharing shape for operator
    /// access — `0o660` with the unit's group is the intended use. The default
    /// [`WireListener::bind`] stays `0o600`. The one rule enforced here is the one
    /// `RFC-0010 §14.4` freezes: the socket must not be open to OTHER users — any mode with
    /// other-bits set is a named usage refusal, group bits are yours to grant. Owner rw is
    /// required too: a mode the daemon itself cannot read and write is a socket that dies
    /// on first accept.
    pub fn bind_with_unix_mode(
        spec: &BindSpec,
        unix_mode: u32,
    ) -> Result<(Self, BoundAddr), EndpointError> {
        if unix_mode & 0o007 != 0 {
            return Err(EndpointError::usage(format!(
                "socket mode {unix_mode:o} is world-accessible; RFC-0010 §14.4 requires the \
                 socket not be open to other users (group sharing, e.g. 0660, is the \
                 supported shape)"
            )));
        }
        if unix_mode & 0o600 != 0o600 {
            return Err(EndpointError::usage(format!(
                "socket mode {unix_mode:o} drops the owner's read/write; the daemon itself \
                 could not use its own socket"
            )));
        }
        match spec {
            BindSpec::Tcp { host, port } => bind_tcp(host, *port),
            BindSpec::Unix { path } => bind_unix(path, unix_mode),
        }
    }

    pub fn accept(&self) -> Result<WireStream, EndpointError> {
        match self {
            WireListener::Tcp(listener) => {
                let (stream, _) = listener
                    .accept()
                    .map_err(|error| Self::accept_error(error, "accept tcp"))?;
                Ok(WireStream::Tcp(stream))
            }
            #[cfg(unix)]
            WireListener::Unix { listener, path } => {
                let (stream, _) = listener
                    .accept()
                    .map_err(|error| Self::accept_error(error, &format!("accept unix:{path}")))?;
                Ok(WireStream::Unix(stream))
            }
        }
    }

    /// Keep the io KIND, not just its text: a non-blocking listener's `WouldBlock` is the
    /// poll loop's "no client yet" (round 124) and must be distinguishable from a real
    /// accept failure — string-matching the summary would be locale/OS text roulette.
    fn accept_error(error: io::Error, prefix: &str) -> EndpointError {
        if error.kind() == io::ErrorKind::WouldBlock {
            EndpointError {
                kind: EndpointErrorKind::WouldBlock,
                summary: format!("{prefix}: {error}"),
            }
        } else {
            EndpointError::from_io(prefix, error)
        }
    }

    pub fn transport_kind(&self) -> &'static str {
        match self {
            WireListener::Tcp(_) => "tcp",
            #[cfg(unix)]
            WireListener::Unix { .. } => "unix",
        }
    }

    /// Put the listener in non-blocking mode so the accept loop can POLL (round 124): a
    /// blocked-signal process has no EINTR to wake a blocking `accept` — TERM/SIGINT are
    /// sigwaited on another thread — so the loop must be able to check a shutdown flag
    /// between attempts. `WouldBlock` from `accept` means "no client yet", not an error.
    pub fn set_nonblocking(&self, nonblocking: bool) -> Result<(), EndpointError> {
        match self {
            WireListener::Tcp(listener) => listener
                .set_nonblocking(nonblocking)
                .map_err(|error| EndpointError::from_io("set_nonblocking tcp", error)),
            #[cfg(unix)]
            WireListener::Unix { listener, .. } => listener
                .set_nonblocking(nonblocking)
                .map_err(|error| EndpointError::from_io("set_nonblocking unix", error)),
        }
    }
}

fn bind_tcp(host: &str, port: u16) -> Result<(WireListener, BoundAddr), EndpointError> {
    let display = display_tcp(host, port);
    let listener = TcpListener::bind(&display)
        .map_err(|error| EndpointError::from_io(&format!("bind {display}"), error))?;
    let local = listener
        .local_addr()
        .map_err(|error| EndpointError::from_io("local_addr", error))?;
    let bound_host = match local {
        SocketAddr::V4(addr) => addr.ip().to_string(),
        SocketAddr::V6(addr) => addr.ip().to_string(),
    };
    Ok((
        WireListener::Tcp(listener),
        BoundAddr::Tcp {
            host: bound_host,
            port: local.port(),
        },
    ))
}

#[cfg(unix)]
fn bind_unix(path: &str, mode: u32) -> Result<(WireListener, BoundAddr), EndpointError> {
    prepare_unix_path(path)?;
    let listener = UnixListener::bind(Path::new(path))
        .map_err(|error| EndpointError::from_io(&format!("bind unix:{path}"), error))?;
    std::fs::set_permissions(Path::new(path), std::fs::Permissions::from_mode(mode))
        .map_err(|error| EndpointError::from_io(&format!("chmod unix:{path}"), error))?;
    Ok((
        WireListener::Unix {
            listener,
            path: path.to_owned(),
        },
        BoundAddr::Unix {
            path: path.to_owned(),
        },
    ))
}

#[cfg(not(unix))]
fn bind_unix(path: &str) -> Result<(WireListener, BoundAddr), EndpointError> {
    Err(EndpointError::unsupported(format!(
        "unix:{path} is not available on this host"
    )))
}

/// Unlink a stale socket so a restarted daemon can rebind. A regular file at the
/// same path is refused by name — unlinking it would be deleting the operator's
/// data dressed as "make bind work".
#[cfg(unix)]
fn prepare_unix_path(path: &str) -> Result<(), EndpointError> {
    let os_path = Path::new(path);
    match std::fs::metadata(os_path) {
        Ok(meta) => {
            if meta.file_type().is_socket() {
                std::fs::remove_file(os_path).map_err(|error| {
                    EndpointError::from_io(&format!("unlink stale unix:{path}"), error)
                })?;
                Ok(())
            } else if meta.is_dir() {
                Err(EndpointError::usage(format!(
                    "unix:{path} is a directory; a socket path must not be"
                )))
            } else {
                Err(EndpointError::usage(format!(
                    "unix:{path} exists and is not a socket; refusing to unlink a regular file"
                )))
            }
        }
        Err(error) if error.kind() == io::ErrorKind::NotFound => Ok(()),
        Err(error) => Err(EndpointError::from_io(&format!("stat unix:{path}"), error)),
    }
}

/// Socket mode after bind, for tests and doctor. Missing path is `None`, not 0 —
/// 0o000 would look like "we chmod'd it shut" when the file was never created.
#[cfg(unix)]
pub fn unix_socket_mode(path: &str) -> Result<Option<u32>, EndpointError> {
    match std::fs::metadata(Path::new(path)) {
        Ok(meta) => Ok(Some(meta.permissions().mode() & 0o777)),
        Err(error) if error.kind() == io::ErrorKind::NotFound => Ok(None),
        Err(error) => Err(EndpointError::from_io(&format!("stat unix:{path}"), error)),
    }
}

#[cfg(not(unix))]
pub fn unix_socket_mode(_path: &str) -> Result<Option<u32>, EndpointError> {
    Ok(None)
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn parse_rejects_empty_and_whitespace() {
        for raw in ["", "   ", "\t"] {
            let error = BindSpec::parse(raw).expect_err(raw);
            assert_eq!(error.kind, EndpointErrorKind::Usage, "{raw:?}");
            assert!(error.summary.contains("empty"), "{}", error.summary);
        }
    }

    #[test]
    fn parse_rejects_named_pipes_by_name() {
        for raw in [r"npipe://./pipe/caly", r"\\.\pipe\caly", "//./pipe/caly"] {
            let error = BindSpec::parse(raw).expect_err(raw);
            assert_eq!(error.kind, EndpointErrorKind::Unsupported, "{raw:?}");
            assert!(error.summary.contains("named pipes"), "{}", error.summary);
        }
    }

    #[test]
    fn parse_rejects_abstract_unix_by_name() {
        for raw in ["@caly.sock", "unix:@caly.sock"] {
            let error = BindSpec::parse(raw).expect_err(raw);
            assert_eq!(error.kind, EndpointErrorKind::Unsupported, "{raw:?}");
            assert!(error.summary.contains("abstract"), "{}", error.summary);
        }
    }

    #[test]
    fn parse_tcp_loopback_and_ephemeral() {
        let spec = BindSpec::parse("127.0.0.1:0").expect("loopback");
        assert_eq!(
            spec,
            BindSpec::Tcp {
                host: "127.0.0.1".into(),
                port: 0
            }
        );
        assert_eq!(spec.to_string(), "127.0.0.1:0");
    }

    #[test]
    fn parse_tcp_ipv6_loopback() {
        let spec = BindSpec::parse("[::1]:9090").expect("ipv6");
        assert_eq!(
            spec,
            BindSpec::Tcp {
                host: "::1".into(),
                port: 9090
            }
        );
        assert_eq!(spec.to_string(), "[::1]:9090");
    }

    #[test]
    fn parse_unix_prefixes_and_absolute_path() {
        for raw in [
            "unix:/tmp/caly.sock",
            "unix:///tmp/caly.sock",
            "/tmp/caly.sock",
        ] {
            let spec = BindSpec::parse(raw).expect(raw);
            match spec {
                BindSpec::Unix { path } => {
                    assert!(path.ends_with("caly.sock"), "{raw} -> {path}");
                    assert!(path.contains("/tmp/"), "{raw} -> {path}");
                }
                other => panic!("{raw} parsed as {other:?}"),
            }
        }
    }

    #[test]
    fn parse_unix_rejects_empty_path_nul_and_overlong() {
        let empty = BindSpec::parse("unix:").expect_err("empty");
        assert!(
            empty.summary.contains("missing a path"),
            "{}",
            empty.summary
        );

        let nul = BindSpec::parse("unix:/tmp/ca\0ly").expect_err("nul");
        assert!(nul.summary.contains("NUL"), "{}", nul.summary);

        let long = format!("unix:/{}", "a".repeat(UNIX_PATH_MAX));
        let error = BindSpec::parse(&long).expect_err("overlong");
        assert!(error.summary.contains("sun_path"), "{}", error.summary);
    }

    #[test]
    fn parse_bare_hostname_without_port_is_usage() {
        let error = BindSpec::parse("localhost").expect_err("no port");
        assert_eq!(error.kind, EndpointErrorKind::Usage);
        assert!(error.summary.contains("host:port"), "{}", error.summary);
    }

    #[test]
    fn tcp_port_file_text_is_a_bare_u16() {
        let bound = BoundAddr::Tcp {
            host: "127.0.0.1".into(),
            port: 43123,
        };
        assert_eq!(bound.port_file_text(), "43123");
        assert_eq!(bound.tcp_port(), Some(43123));
    }

    #[test]
    fn unix_port_file_text_is_the_unix_prefix() {
        let bound = BoundAddr::Unix {
            path: "/tmp/caly.sock".into(),
        };
        assert_eq!(bound.port_file_text(), "unix:/tmp/caly.sock");
        assert_eq!(bound.tcp_port(), None);
    }
}
