use caly_api::ProtocolVersion;

use crate::frame::{Compression, Encoding, FrameHeader};
use crate::handshake::{ClientHello, ServerHelloAck};
use crate::policy::{
    CONTROL_MESSAGES_COMPRESS_BY_DEFAULT, DEFAULT_HELLO_TIMEOUT_MS, MAX_FRAME_SIZE_BYTES,
};

pub const SERVER_PROTOCOL_VERSION: ProtocolVersion = ProtocolVersion { major: 1, minor: 0 };

#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub enum HandshakeErrorCode {
    ProtoMismatch,
    InvalidClientName,
    UnsupportedEncoding,
    UnsupportedCompression,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct HandshakeError {
    pub code: HandshakeErrorCode,
    pub summary: String,
}

#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub enum FrameValidationErrorCode {
    FrameTooLarge,
    CompressionNotAllowed,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct FrameValidationError {
    pub code: FrameValidationErrorCode,
    pub summary: String,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct NegotiationPolicy {
    pub protocol: ProtocolVersion,
    pub allow_msgpack: bool,
    pub allow_zstd: bool,
    pub hello_timeout_ms: u64,
    pub max_frame_size_bytes: u32,
}

impl Default for NegotiationPolicy {
    fn default() -> Self {
        Self {
            protocol: SERVER_PROTOCOL_VERSION,
            allow_msgpack: false,
            allow_zstd: false,
            hello_timeout_ms: DEFAULT_HELLO_TIMEOUT_MS,
            max_frame_size_bytes: MAX_FRAME_SIZE_BYTES,
        }
    }
}

pub fn negotiate_hello(
    client: &ClientHello,
    policy: &NegotiationPolicy,
    daemon_name: impl Into<String>,
    daemon_version: impl Into<String>,
    instance_id: impl Into<String>,
    state_revision: u64,
) -> Result<ServerHelloAck, HandshakeError> {
    if client.client_name.trim().is_empty() {
        return Err(HandshakeError {
            code: HandshakeErrorCode::InvalidClientName,
            summary: "client_name must not be empty".to_owned(),
        });
    }

    if client.protocol.major != policy.protocol.major {
        return Err(HandshakeError {
            code: HandshakeErrorCode::ProtoMismatch,
            summary: format!(
                "protocol major mismatch: client={} server={}",
                client.protocol.major, policy.protocol.major
            ),
        });
    }

    let selected_encoding = match client.requested_encoding {
        Encoding::Json => Encoding::Json,
        Encoding::MsgPack if policy.allow_msgpack => Encoding::MsgPack,
        Encoding::MsgPack => {
            return Err(HandshakeError {
                code: HandshakeErrorCode::UnsupportedEncoding,
                summary: "msgpack is not enabled by server policy".to_owned(),
            })
        }
    };

    let selected_compression = match client.requested_compression {
        Compression::None => Compression::None,
        Compression::Zstd if policy.allow_zstd => Compression::Zstd,
        Compression::Zstd => {
            return Err(HandshakeError {
                code: HandshakeErrorCode::UnsupportedCompression,
                summary: "zstd is not enabled by server policy".to_owned(),
            })
        }
    };

    Ok(ServerHelloAck {
        protocol: policy.protocol,
        daemon_name: daemon_name.into(),
        daemon_version: daemon_version.into(),
        instance_id: instance_id.into(),
        selected_encoding,
        selected_compression,
        server_features: client.supported_features.clone(),
        state_revision,
    })
}

pub fn validate_frame_header(
    header: &FrameHeader,
    max_size_bytes: u32,
    is_control_message: bool,
) -> Result<(), FrameValidationError> {
    if header.length > max_size_bytes {
        return Err(FrameValidationError {
            code: FrameValidationErrorCode::FrameTooLarge,
            summary: format!(
                "frame length {} exceeds max {}",
                header.length, max_size_bytes
            ),
        });
    }

    if is_control_message
        && !CONTROL_MESSAGES_COMPRESS_BY_DEFAULT
        && !matches!(header.compression, Compression::None)
    {
        return Err(FrameValidationError {
            code: FrameValidationErrorCode::CompressionNotAllowed,
            summary: "control messages must not be compressed by default".to_owned(),
        });
    }

    Ok(())
}
