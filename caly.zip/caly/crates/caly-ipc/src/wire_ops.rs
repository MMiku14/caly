//! The single source for the v0 wire request shape: a typed `Operation` knows the record
//! fields that carry its request and the wire name the daemon dispatches on.
//!
//! `ROADMAP §13#3`'s transport is a two-table system today: the CLI hand-encodes
//! (`crates/caly-cli/src/bin/caly.rs`) and the daemon hand-decodes
//! (`crates/caly-daemon/src/bin/calyd.rs`), and they meet only in e2e tests. This module is
//! the *one* encode table; the daemon's decode stays the judge of it (the e2e sweep proves a
//! wire request built here passes the daemon's door). A typed operation with no v0 wire
//! representation is refused by name — never guessed, spelled out — the same doctrine as the
//! daemon's own door (`an_operation_off_the_v0_wire_is_refused_by_name_not_guessed`).
//!
//! The exact spellings (field names, boolean `"true"`/`"false"`, decimal numbers, optional
//! present-iff-`Some`) are what `calyd.rs` enforces; the unit tests below pin them so a
//! rename on either side is a test failure, not a silent drift.

use caly_api::{DiagnosticsOp, Operation, ProfileOp, RuntimeOp, SystemOp};

/// The v0 wire shape of one request: the dispatch name plus the op-specific records.
///
/// Session-level fields (`request_id`, `trace_id`, `operation`, `idempotency_key`) are not
/// this module's: they are per-conversation state and travel in the request head
/// (`dialect::request_payload`).
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct WireRequest {
    pub name: &'static str,
    pub extras: Vec<(&'static str, String)>,
}

/// A typed operation that has no v0 wire representation.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct WireRequestError {
    pub operation: String,
}

impl WireRequestError {
    fn no_wire_name(operation: &Operation) -> Self {
        Self {
            operation: format!("{operation:?}"),
        }
    }

    pub fn summary(&self) -> String {
        format!(
            "{} is a typed operation with no v0 wire name; refusing rather than inventing one",
            self.operation
        )
    }
}

fn plain(name: &'static str) -> Result<WireRequest, WireRequestError> {
    Ok(WireRequest {
        name,
        extras: Vec::new(),
    })
}

fn fields(
    name: &'static str,
    extras: Vec<(&'static str, String)>,
) -> Result<WireRequest, WireRequestError> {
    Ok(WireRequest { name, extras })
}

fn gc_extras(
    name: &'static str,
    grace_period_ms: Option<i64>,
    max_deletions: Option<u32>,
) -> Result<WireRequest, WireRequestError> {
    let mut extras = Vec::new();
    if let Some(grace) = grace_period_ms {
        extras.push(("grace_period_ms", grace.to_string()));
    }
    if let Some(max) = max_deletions {
        extras.push(("max_deletions", max.to_string()));
    }
    fields(name, extras)
}

pub fn wire_request(operation: &Operation) -> Result<WireRequest, WireRequestError> {
    match operation {
        Operation::Runtime(RuntimeOp::Status) => plain("runtime.status"),
        Operation::Diagnostics(DiagnosticsOp::Doctor { request }) => fields(
            "diagnostics.doctor",
            vec![("include_runtime", request.include_runtime.to_string())],
        ),
        Operation::Diagnostics(DiagnosticsOp::SupportBundle) => plain("diagnostics.support-bundle"),
        Operation::Profile(ProfileOp::List) => plain("profiles.list"),
        Operation::Profile(ProfileOp::Get { profile_id }) => {
            fields("profiles.get", vec![("profile_id", profile_id.0.clone())])
        }
        Operation::Profile(ProfileOp::Apply { request }) => fields(
            "profiles.apply",
            vec![
                ("profile_id", request.profile_id.0.clone()),
                ("dry_run", request.dry_run.to_string()),
                ("strict", request.strict.to_string()),
            ],
        ),
        Operation::Profile(ProfileOp::Rollback { request }) => {
            let mut extras = Vec::new();
            if let Some(snapshot_id) = &request.snapshot_id {
                extras.push(("snapshot_id", snapshot_id.clone()));
            }
            fields("profiles.rollback", extras)
        }
        Operation::Diagnostics(DiagnosticsOp::ReadJobEvents { request }) => {
            let mut extras = vec![("job_id", request.job_id.0.to_string())];
            if let Some(from) = request.from_event_index {
                extras.push(("from_event_index", from.to_string()));
            }
            if let Some(max) = request.max_lines {
                extras.push(("max_lines", max.to_string()));
            }
            fields("jobs.events", extras)
        }
        Operation::Diagnostics(DiagnosticsOp::ListJobs) => fields("jobs.list", Vec::new()),
        Operation::Diagnostics(DiagnosticsOp::FollowJob { request }) => fields(
            "jobs.follow",
            vec![("job_id", request.job_id.0.to_string())],
        ),
        Operation::Diagnostics(DiagnosticsOp::FollowJobStream { request }) => {
            let mut extras = vec![("job_id", request.job_id.0.to_string())];
            if let Some(from) = request.from_event_index {
                extras.push(("from_event_index", from.to_string()));
            }
            fields("jobs.follow-stream", extras)
        }
        Operation::System(SystemOp::GcPlan { request }) => gc_extras(
            "system.gc-plan",
            request.grace_period_ms,
            request.max_deletions,
        ),
        Operation::System(SystemOp::CollectGarbage { request }) => {
            gc_extras("system.gc", request.grace_period_ms, request.max_deletions)
        }
        Operation::Diagnostics(DiagnosticsOp::ReadSupportBundle { request }) => {
            let mut extras = Vec::new();
            if let Some(digest) = &request.digest {
                extras.push(("digest", digest.clone()));
            }
            if let Some(max) = request.max_bytes {
                extras.push(("max_bytes", max.to_string()));
            }
            fields("diagnostics.support-bundle-read", extras)
        }
        other => Err(WireRequestError::no_wire_name(other)),
    }
}

/// The v0 wire's dispatch names, in the order the daemon's door already documents them
/// (with `jobs.follow-stream` — the stream pair's opened/resumed shapes — appended where the
/// older prose forgot it). Encode and decode share this list: a rename in either direction
/// is a test failure, not a silent drift.
pub const WIRE_OPERATION_NAMES: [&str; 14] = [
    "runtime.status",
    "diagnostics.doctor",
    "profiles.list",
    "profiles.get",
    "jobs.events",
    "jobs.follow",
    "jobs.list",
    "profiles.apply",
    "profiles.rollback",
    "system.gc-plan",
    "system.gc",
    "diagnostics.support-bundle",
    "diagnostics.support-bundle-read",
    "jobs.follow-stream",
];

/// One request decoded off the v0 wire, before any session state is consulted. The daemon
/// attaches session state (the stream table, role checks) after this returns; the wire shape
/// knowledge lives here so the encode table above and this decode table cannot drift apart
/// without a round-trip test failing.
#[derive(Clone, Debug, Eq, PartialEq)]
pub enum DecodedRequest {
    /// The stateless ops, executable as decoded.
    Op(Operation),
    /// `jobs.follow-stream` opened by job id.
    FollowStreamOpen {
        job_id: u64,
        from_event_index: Option<u64>,
    },
    /// `jobs.follow-stream` resumed by the logical stream id.
    FollowStreamResume { stream_id: u64 },
}

/// Why a request off the v0 wire could not be decoded. The daemon turns each into its own
/// refusal wording; this type names the *field* so the summary never has to guess.
#[derive(Clone, Debug, Eq, PartialEq)]
pub enum WireDecodeError {
    /// No record named `operation`, or a name the v0 wire does not carry.
    UnknownOperation { operation: String },
    /// A required textual record is absent.
    MissingField {
        operation: &'static str,
        field: &'static str,
    },
    /// A numeric record is absent (`raw: None`) or not a decimal integer (`raw: Some`).
    BadNumber {
        operation: &'static str,
        field: &'static str,
        raw: Option<String>,
    },
}

/// The two shapes `jobs.follow-stream` travels in: a fresh open names the job, a reconnect
/// names the logical stream the daemon still remembers. This was the last hand-encoded table
/// on the client (round 76 swept the rest); it lives here now.
#[derive(Clone, Debug, Eq, PartialEq)]
pub enum StreamRequest {
    Open {
        job_id: u64,
        from_event_index: Option<u64>,
    },
    Resume {
        stream_id: u64,
    },
}

/// `numbered_bound`'s rule, moved here with the rest of the wire shape: **absent means the
/// daemon's default**, present-but-unparseable is a refusal that names the field.
fn numbered<T: std::str::FromStr>(
    records: &[(String, String)],
    operation: &'static str,
    field: &'static str,
) -> Result<Option<T>, WireDecodeError> {
    match crate::wire::wire_field(records, field) {
        None => Ok(None),
        Some(raw) => raw
            .parse::<T>()
            .map(Some)
            .map_err(|_| WireDecodeError::BadNumber {
                operation,
                field,
                raw: Some(raw.to_owned()),
            }),
    }
}

/// An id record, with the rule the door already applies: absent and unparseable are the same
/// refusal, worded by the daemon as "needs a numeric … record".
fn numeric_id(
    records: &[(String, String)],
    operation: &'static str,
    field: &'static str,
) -> Result<u64, WireDecodeError> {
    match crate::wire::wire_field(records, field) {
        None => Err(WireDecodeError::BadNumber {
            operation,
            field,
            raw: None,
        }),
        Some(raw) => raw.parse::<u64>().map_err(|_| WireDecodeError::BadNumber {
            operation,
            field,
            raw: Some(raw.to_owned()),
        }),
    }
}

/// Decode one v0 request into the typed operation the daemon executes. The contract is the
/// mirror of `wire_request`: every record the encoder writes is read here under the same
/// name, so `decode_request(records(wire_request(op)))` is `op` for every stateless op.
pub fn decode_request(records: &[(String, String)]) -> Result<DecodedRequest, WireDecodeError> {
    match crate::wire::wire_field(records, "operation").unwrap_or("") {
        "runtime.status" => Ok(DecodedRequest::Op(Operation::Runtime(RuntimeOp::Status))),
        "diagnostics.doctor" => {
            let include_runtime =
                crate::wire::wire_field(records, "include_runtime") == Some("true");
            Ok(DecodedRequest::Op(Operation::Diagnostics(
                caly_api::DiagnosticsOp::Doctor {
                    request: caly_api::DoctorRequest { include_runtime },
                },
            )))
        }
        "diagnostics.support-bundle" => Ok(DecodedRequest::Op(Operation::Diagnostics(
            caly_api::DiagnosticsOp::SupportBundle,
        ))),
        "profiles.list" => Ok(DecodedRequest::Op(Operation::Profile(ProfileOp::List))),
        "profiles.get" => {
            let profile_id = required_text(records, "profiles.get", "profile_id")?;
            Ok(DecodedRequest::Op(Operation::Profile(ProfileOp::Get {
                profile_id: caly_api::ProfileId(profile_id.to_owned()),
            })))
        }
        "profiles.apply" => {
            let profile_id = required_text(records, "profiles.apply", "profile_id")?;
            Ok(DecodedRequest::Op(Operation::Profile(ProfileOp::Apply {
                request: caly_api::ApplyRequest {
                    profile_id: caly_api::ProfileId(profile_id.to_owned()),
                    dry_run: crate::wire::wire_field(records, "dry_run") == Some("true"),
                    strict: crate::wire::wire_field(records, "strict") == Some("true"),
                },
            })))
        }
        "profiles.rollback" => Ok(DecodedRequest::Op(Operation::Profile(
            ProfileOp::Rollback {
                request: caly_api::RollbackRequest {
                    snapshot_id: crate::wire::wire_field(records, "snapshot_id").map(str::to_owned),
                },
            },
        ))),
        "jobs.events" => {
            let job_id = numeric_id(records, "jobs.events", "job_id")?;
            let from_event_index = numbered(records, "jobs.events", "from_event_index")?;
            let max_lines = numbered(records, "jobs.events", "max_lines")?;
            Ok(DecodedRequest::Op(Operation::Diagnostics(
                caly_api::DiagnosticsOp::ReadJobEvents {
                    request: caly_api::JobEventsRequest {
                        job_id: caly_api::JobId(job_id),
                        from_event_index,
                        max_lines,
                        max_bytes: None,
                    },
                },
            )))
        }
        "jobs.follow" => {
            let job_id = numeric_id(records, "jobs.follow", "job_id")?;
            Ok(DecodedRequest::Op(Operation::Diagnostics(
                caly_api::DiagnosticsOp::FollowJob {
                    request: caly_api::JobFollowRequest {
                        job_id: caly_api::JobId(job_id),
                        from_event_index: None,
                    },
                },
            )))
        }
        "jobs.list" => Ok(DecodedRequest::Op(Operation::Diagnostics(
            caly_api::DiagnosticsOp::ListJobs,
        ))),
        "jobs.follow-stream" => decode_stream_request(records),
        "system.gc-plan" => {
            let grace_period_ms = numbered(records, "system.gc-plan", "grace_period_ms")?;
            let max_deletions = numbered(records, "system.gc-plan", "max_deletions")?;
            Ok(DecodedRequest::Op(Operation::System(SystemOp::GcPlan {
                request: caly_api::GcPlanRequest {
                    grace_period_ms,
                    max_deletions,
                },
            })))
        }
        "system.gc" => {
            let grace_period_ms = numbered(records, "system.gc", "grace_period_ms")?;
            let max_deletions = numbered(records, "system.gc", "max_deletions")?;
            Ok(DecodedRequest::Op(Operation::System(
                SystemOp::CollectGarbage {
                    request: caly_api::GcCollectRequest {
                        grace_period_ms,
                        max_deletions,
                    },
                },
            )))
        }
        "diagnostics.support-bundle-read" => {
            let max_bytes = numbered(records, "diagnostics.support-bundle-read", "max_bytes")?;
            Ok(DecodedRequest::Op(Operation::Diagnostics(
                caly_api::DiagnosticsOp::ReadSupportBundle {
                    request: caly_api::SupportBundleReadRequest {
                        digest: crate::wire::wire_field(records, "digest").map(str::to_owned),
                        max_bytes,
                    },
                },
            )))
        }
        other => Err(WireDecodeError::UnknownOperation {
            operation: other.to_owned(),
        }),
    }
}

fn required_text<'a>(
    records: &'a [(String, String)],
    operation: &'static str,
    field: &'static str,
) -> Result<&'a str, WireDecodeError> {
    crate::wire::wire_field(records, field)
        .ok_or(WireDecodeError::MissingField { operation, field })
}

/// Encode the follow-stream pair. `resume` is written as the record the daemon's reconnect
/// path reads (`stream_id` + `resume=true`); `open` carries the job and the exclusive cursor.
pub fn wire_stream_request(request: &StreamRequest) -> WireRequest {
    match request {
        StreamRequest::Resume { stream_id } => fields(
            "jobs.follow-stream",
            vec![
                ("stream_id", stream_id.to_string()),
                ("resume", "true".to_owned()),
            ],
        )
        .expect("the resume shape is on the v0 wire"),
        StreamRequest::Open {
            job_id,
            from_event_index,
        } => {
            let mut extras = vec![("job_id", job_id.to_string())];
            if let Some(from) = from_event_index {
                extras.push(("from_event_index", from.to_string()));
            }
            fields("jobs.follow-stream", extras).expect("the open shape is on the v0 wire")
        }
    }
}

/// Decode the follow-stream pair; the mirror of `wire_stream_request`.
pub fn decode_stream_request(
    records: &[(String, String)],
) -> Result<DecodedRequest, WireDecodeError> {
    if crate::wire::wire_field(records, "resume") == Some("true") {
        let stream_id = numeric_id(records, "jobs.follow-stream", "stream_id")?;
        Ok(DecodedRequest::FollowStreamResume { stream_id })
    } else {
        let job_id = numeric_id(records, "jobs.follow-stream", "job_id")?;
        let from_event_index = numbered(records, "jobs.follow-stream", "from_event_index")?;
        Ok(DecodedRequest::FollowStreamOpen {
            job_id,
            from_event_index,
        })
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use caly_api::{
        ApplyRequest, GcCollectRequest, GcPlanRequest, JobEventsRequest, JobFollowRequest, JobId,
        ProfileId, RollbackRequest, SupportBundleReadRequest, SystemOp,
    };

    /// The dictated v0 wire contract, exactly as `calyd.rs` decodes it: name, required
    /// record names in the daemon's required order, optional record names that are present
    /// iff the typed field is `Some`.
    fn records(wire: &WireRequest) -> Vec<(&'static str, String)> {
        wire.extras.clone()
    }

    fn apply(profile_id: &str, dry_run: bool, strict: bool) -> Operation {
        Operation::Profile(ProfileOp::Apply {
            request: ApplyRequest {
                profile_id: ProfileId(profile_id.to_owned()),
                dry_run,
                strict,
            },
        })
    }

    #[test]
    fn runtime_status_is_the_plain_wire_request() {
        let wire = wire_request(&Operation::Runtime(RuntimeOp::Status)).expect("wired op");
        assert_eq!(wire.name, "runtime.status");
        assert!(wire.extras.is_empty(), "{:?}", wire.extras);
    }

    #[test]
    fn the_wire_names_are_distinct_and_dotted() {
        let ops = [
            wire_request(&Operation::Runtime(RuntimeOp::Status)).unwrap(),
            wire_request(&Operation::Diagnostics(DiagnosticsOp::Doctor {
                request: caly_api::DoctorRequest {
                    include_runtime: false,
                },
            }))
            .unwrap(),
            wire_request(&Operation::Diagnostics(DiagnosticsOp::SupportBundle)).unwrap(),
            wire_request(&Operation::Profile(ProfileOp::List)).unwrap(),
            wire_request(&Operation::Profile(ProfileOp::Get {
                profile_id: ProfileId("nightshift".into()),
            }))
            .unwrap(),
            wire_request(&apply("nightshift", false, false)).unwrap(),
            wire_request(&Operation::Profile(ProfileOp::Rollback {
                request: RollbackRequest { snapshot_id: None },
            }))
            .unwrap(),
            wire_request(&Operation::Diagnostics(DiagnosticsOp::ReadJobEvents {
                request: JobEventsRequest {
                    job_id: JobId(7),
                    from_event_index: None,
                    max_lines: None,
                    max_bytes: None,
                },
            }))
            .unwrap(),
            wire_request(&Operation::Diagnostics(DiagnosticsOp::FollowJob {
                request: JobFollowRequest {
                    job_id: JobId(7),
                    from_event_index: None,
                },
            }))
            .unwrap(),
            wire_request(&Operation::Diagnostics(DiagnosticsOp::FollowJobStream {
                request: JobFollowRequest {
                    job_id: JobId(7),
                    from_event_index: None,
                },
            }))
            .unwrap(),
            wire_request(&Operation::System(SystemOp::GcPlan {
                request: GcPlanRequest {
                    grace_period_ms: None,
                    max_deletions: None,
                },
            }))
            .unwrap(),
            wire_request(&Operation::System(SystemOp::CollectGarbage {
                request: GcCollectRequest {
                    grace_period_ms: None,
                    max_deletions: None,
                },
            }))
            .unwrap(),
            wire_request(&Operation::Diagnostics(DiagnosticsOp::ReadSupportBundle {
                request: SupportBundleReadRequest {
                    digest: None,
                    max_bytes: None,
                },
            }))
            .unwrap(),
        ];
        let mut names: Vec<&str> = ops.iter().map(|w| w.name).collect();
        names.sort_unstable();
        names.dedup();
        assert_eq!(names.len(), 13, "13 distinct wire names: {names:?}");
        for name in &names {
            assert!(
                name.contains('.') && !name.starts_with('.') && !name.ends_with('.'),
                "wire names are dotted and non-degenerate: {name}"
            );
        }
    }

    #[test]
    fn apply_encodes_the_three_required_records_and_booleans_are_decimal_free() {
        let wire = wire_request(&apply("nightshift", true, false)).expect("wired op");
        assert_eq!(wire.name, "profiles.apply");
        assert_eq!(
            records(&wire),
            vec![
                ("profile_id", "nightshift".into()),
                ("dry_run", "true".into()),
                ("strict", "false".into()),
            ]
        );
    }

    #[test]
    fn optionals_are_present_iff_some() {
        let wire = wire_request(&Operation::Profile(ProfileOp::Rollback {
            request: RollbackRequest {
                snapshot_id: Some("snap-9".into()),
            },
        }))
        .unwrap();
        assert_eq!(wire.name, "profiles.rollback");
        assert_eq!(records(&wire), vec![("snapshot_id", "snap-9".into())]);

        let wire = wire_request(&Operation::Profile(ProfileOp::Rollback {
            request: RollbackRequest { snapshot_id: None },
        }))
        .unwrap();
        assert_eq!(records(&wire), Vec::<(&'static str, String)>::new());

        let wire = wire_request(&Operation::Diagnostics(DiagnosticsOp::ReadJobEvents {
            request: JobEventsRequest {
                job_id: JobId(42),
                from_event_index: Some(10),
                max_lines: None,
                max_bytes: Some(64),
            },
        }))
        .unwrap();
        assert_eq!(wire.name, "jobs.events");
        assert_eq!(
            records(&wire),
            vec![("job_id", "42".into()), ("from_event_index", "10".into()),]
        );

        let wire = wire_request(&Operation::System(SystemOp::GcPlan {
            request: GcPlanRequest {
                grace_period_ms: Some(60_000),
                max_deletions: None,
            },
        }))
        .unwrap();
        assert_eq!(wire.name, "system.gc-plan");
        assert_eq!(records(&wire), vec![("grace_period_ms", "60000".into())]);
    }

    #[test]
    fn an_operation_without_a_wire_name_is_refused_by_name() {
        let err = wire_request(&Operation::Diagnostics(DiagnosticsOp::RecoveryStatus))
            .expect_err("no v0 wire representation");
        assert!(
            err.summary().contains("RecoveryStatus"),
            "the refusal must name the typed operation: {}",
            err.summary()
        );
    }

    /// The wire bytes a client actually sends: head fields then the op's extras.
    fn request_records(wire: &WireRequest) -> Vec<(String, String)> {
        let payload = crate::dialect::request_payload(1, wire.name, &wire.extras, false);
        crate::wire::wire_parse_records(&String::from_utf8(payload).expect("records payload"))
    }

    /// The round-trip contract: what the encoder writes, the decoder reads back as the same
    /// typed operation — the exact symmetric pair that used to live in two files.
    #[test]
    fn every_encoded_operation_decodes_back_to_itself() {
        let ops: Vec<Operation> = vec![
            Operation::Runtime(RuntimeOp::Status),
            Operation::Diagnostics(DiagnosticsOp::Doctor {
                request: caly_api::DoctorRequest {
                    include_runtime: false,
                },
            }),
            Operation::Diagnostics(DiagnosticsOp::SupportBundle),
            Operation::Profile(ProfileOp::List),
            Operation::Profile(ProfileOp::Get {
                profile_id: caly_api::ProfileId("nightshift".into()),
            }),
            Operation::Profile(ProfileOp::Apply {
                request: caly_api::ApplyRequest {
                    profile_id: caly_api::ProfileId("nightshift".into()),
                    dry_run: true,
                    strict: false,
                },
            }),
            Operation::Profile(ProfileOp::Rollback {
                request: caly_api::RollbackRequest {
                    snapshot_id: Some("snap-9".into()),
                },
            }),
            Operation::Diagnostics(DiagnosticsOp::ReadJobEvents {
                request: caly_api::JobEventsRequest {
                    job_id: caly_api::JobId(42),
                    from_event_index: Some(10),
                    max_lines: None,
                    max_bytes: None,
                },
            }),
            Operation::Diagnostics(DiagnosticsOp::ListJobs),
            Operation::Diagnostics(DiagnosticsOp::FollowJob {
                request: caly_api::JobFollowRequest {
                    job_id: caly_api::JobId(42),
                    from_event_index: None,
                },
            }),
            Operation::Diagnostics(DiagnosticsOp::FollowJobStream {
                request: caly_api::JobFollowRequest {
                    job_id: caly_api::JobId(7),
                    from_event_index: None,
                },
            }),
            Operation::System(SystemOp::GcPlan {
                request: caly_api::GcPlanRequest {
                    grace_period_ms: Some(60_000),
                    max_deletions: None,
                },
            }),
            Operation::System(SystemOp::CollectGarbage {
                request: caly_api::GcCollectRequest {
                    grace_period_ms: Some(60_000),
                    max_deletions: Some(2),
                },
            }),
            Operation::Diagnostics(DiagnosticsOp::ReadSupportBundle {
                request: caly_api::SupportBundleReadRequest {
                    digest: Some("112233".into()),
                    max_bytes: Some(64),
                },
            }),
        ];
        for op in &ops {
            let wire = wire_request(op).expect("wired op");
            let decoded = decode_request(&request_records(&wire))
                .unwrap_or_else(|problem| panic!("{} must decode: {problem:?}", wire.name));
            match decoded {
                DecodedRequest::Op(decoded_op) => {
                    assert_eq!(&decoded_op, op, "{} must round-trip", wire.name);
                }
                DecodedRequest::FollowStreamOpen {
                    job_id,
                    from_event_index,
                } => match op {
                    Operation::Diagnostics(DiagnosticsOp::FollowJobStream { request }) => {
                        assert_eq!(job_id, request.job_id.0, "{}", wire.name);
                        assert_eq!(from_event_index, request.from_event_index, "{}", wire.name);
                    }
                    _ => panic!("{} decoded into the stream pair, not {op:?}", wire.name),
                },
                DecodedRequest::FollowStreamResume { .. } => {
                    panic!("{} (an open shape) decoded into a resume", wire.name)
                }
            }
        }
    }

    /// The other half of the list contract: every name the door documents is recognized by
    /// the decoder (a minimal request fails on a field, not as an unknown operation).
    #[test]
    fn the_decode_table_accepts_every_wire_name() {
        for name in WIRE_OPERATION_NAMES {
            let records = vec![("operation".to_owned(), name.to_owned())];
            match decode_request(&records) {
                Ok(_) => {}
                Err(WireDecodeError::UnknownOperation { .. }) => {
                    panic!("{name} is documented but the decoder does not recognize it")
                }
                Err(_) => {}
            }
        }
    }

    /// The decoder's refusals name the field, never a guessed default.
    #[test]
    fn decode_refusals_name_the_field() {
        let apply = vec![
            ("operation".to_owned(), "profiles.apply".to_owned()),
            ("dry_run".to_owned(), "true".to_owned()),
        ];
        assert_eq!(
            decode_request(&apply),
            Err(WireDecodeError::MissingField {
                operation: "profiles.apply",
                field: "profile_id",
            })
        );
        let events = vec![
            ("operation".to_owned(), "jobs.events".to_owned()),
            ("job_id".to_owned(), "abc".to_owned()),
        ];
        assert_eq!(
            decode_request(&events),
            Err(WireDecodeError::BadNumber {
                operation: "jobs.events",
                field: "job_id",
                raw: Some("abc".to_owned()),
            })
        );
        let gc = vec![
            ("operation".to_owned(), "system.gc".to_owned()),
            ("grace_period_ms".to_owned(), "soon".to_owned()),
        ];
        assert_eq!(
            decode_request(&gc),
            Err(WireDecodeError::BadNumber {
                operation: "system.gc",
                field: "grace_period_ms",
                raw: Some("soon".to_owned()),
            })
        );
        let unknown = vec![("operation".to_owned(), "profiles.applyx".to_owned())];
        assert!(matches!(
            decode_request(&unknown),
            Err(WireDecodeError::UnknownOperation { .. })
        ));
    }

    fn stream_pairs() -> Vec<StreamRequest> {
        vec![
            StreamRequest::Resume { stream_id: 4242 },
            StreamRequest::Open {
                job_id: 7,
                from_event_index: None,
            },
            StreamRequest::Open {
                job_id: 7,
                from_event_index: Some(3),
            },
        ]
    }

    /// The doctor's runtime opt-in is a record on the wire, not a decoder guess: the round
    /// trip above covers the default shape; this one pins the opt-in's spelling.
    #[test]
    fn the_doctor_opt_in_round_trips_with_the_projection_record() {
        let op = Operation::Diagnostics(DiagnosticsOp::Doctor {
            request: caly_api::DoctorRequest {
                include_runtime: true,
            },
        });
        let wire = wire_request(&op).expect("wired op");
        assert_eq!(
            wire.extras,
            vec![("include_runtime", "true".to_owned())],
            "the opt-in must ride as a record: {:?}",
            wire.extras
        );
        let decoded = decode_request(&request_records(&wire)).expect("decodes");
        assert_eq!(decoded, DecodedRequest::Op(op));
    }

    /// The follow-stream pair round-trips in both shapes — the tables this module replaced
    /// were the last ones a client hand-wrote.
    #[test]
    fn stream_requests_round_trip_both_shapes() {
        let pair = stream_pairs();
        for request in &pair {
            let wire = wire_stream_request(request);
            assert_eq!(wire.name, "jobs.follow-stream");
            match (request, decode_stream_request(&request_records(&wire))) {
                (
                    StreamRequest::Resume { stream_id },
                    Ok(DecodedRequest::FollowStreamResume {
                        stream_id: decoded_id,
                    }),
                ) => assert_eq!(stream_id, &decoded_id),
                (
                    StreamRequest::Open {
                        job_id,
                        from_event_index,
                    },
                    Ok(DecodedRequest::FollowStreamOpen {
                        job_id: decoded_job,
                        from_event_index: decoded_from,
                    }),
                ) => {
                    assert_eq!(job_id, &decoded_job);
                    assert_eq!(from_event_index, &decoded_from);
                }
                (request, decoded) => panic!(
                    "{request:?} decoded into {decoded:?}; the mirror of wire_stream_request must hold"
                ),
            }
        }
        // The open shape with a resume flag is a resume; the flag is not optional prose.
        let stubborn = vec![
            ("operation".to_owned(), "jobs.follow-stream".to_owned()),
            ("job_id".to_owned(), "7".to_owned()),
            ("resume".to_owned(), "true".to_owned()),
        ];
        assert!(matches!(
            decode_stream_request(&stubborn),
            Err(WireDecodeError::BadNumber {
                operation: "jobs.follow-stream",
                field: "stream_id",
                raw: None,
            })
        ));
    }

    /// The documented name list and the encode table are the same set: a rename in either
    /// direction is a test failure.
    #[test]
    fn wire_operation_names_cover_the_encode_table() {
        let mut encoded: Vec<&str> = vec![];
        for op in [
            Operation::Runtime(RuntimeOp::Status),
            Operation::Diagnostics(DiagnosticsOp::Doctor {
                request: caly_api::DoctorRequest {
                    include_runtime: false,
                },
            }),
            Operation::Diagnostics(DiagnosticsOp::SupportBundle),
            Operation::Profile(ProfileOp::List),
            Operation::Profile(ProfileOp::Get {
                profile_id: caly_api::ProfileId("x".into()),
            }),
            Operation::Profile(ProfileOp::Apply {
                request: caly_api::ApplyRequest {
                    profile_id: caly_api::ProfileId("x".into()),
                    dry_run: false,
                    strict: false,
                },
            }),
            Operation::Profile(ProfileOp::Rollback {
                request: caly_api::RollbackRequest { snapshot_id: None },
            }),
            Operation::Diagnostics(DiagnosticsOp::ReadJobEvents {
                request: caly_api::JobEventsRequest {
                    job_id: caly_api::JobId(1),
                    from_event_index: None,
                    max_lines: None,
                    max_bytes: None,
                },
            }),
            Operation::Diagnostics(DiagnosticsOp::ListJobs),
            Operation::Diagnostics(DiagnosticsOp::FollowJob {
                request: caly_api::JobFollowRequest {
                    job_id: caly_api::JobId(1),
                    from_event_index: None,
                },
            }),
            Operation::Diagnostics(DiagnosticsOp::FollowJobStream {
                request: caly_api::JobFollowRequest {
                    job_id: caly_api::JobId(1),
                    from_event_index: None,
                },
            }),
            Operation::System(SystemOp::GcPlan {
                request: caly_api::GcPlanRequest {
                    grace_period_ms: None,
                    max_deletions: None,
                },
            }),
            Operation::System(SystemOp::CollectGarbage {
                request: caly_api::GcCollectRequest {
                    grace_period_ms: None,
                    max_deletions: None,
                },
            }),
            Operation::Diagnostics(DiagnosticsOp::ReadSupportBundle {
                request: caly_api::SupportBundleReadRequest {
                    digest: None,
                    max_bytes: None,
                },
            }),
        ] {
            encoded.push(wire_request(&op).expect("wired op").name);
        }
        let mut documented: Vec<&str> = WIRE_OPERATION_NAMES.to_vec();
        documented.sort_unstable();
        encoded.sort_unstable();
        encoded.dedup();
        assert_eq!(
            encoded, documented,
            "the encode table and the documented name list must be one set"
        );
    }
}
