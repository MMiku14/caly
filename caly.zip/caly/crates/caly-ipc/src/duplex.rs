//! Duplex frame pump over [`crate::endpoint::WireIo`].
//!
//! The production daemon and CLI used to own their own `wire_read_frame` /
//! `wire_write_frame` loops against a `TcpStream`. Round 87 lifts the loop onto
//! the shared stream type so a Unix-domain listener is not a second copy of the
//! same pump. This module does not invent a request scheduler: it writes one
//! dialect frame and reads one dialect frame, and it asks the stream whether
//! the peer is still there *before* blocking on a read.
//!
//! Probe honesty:
//!
//! - TCP: `TcpStream::peek` distinguishes `Closed` (0-byte) from `Alive`
//!   (would-block or a byte waiting).
//! - UDS: `UnixStream` has no std `peek`. The probe is `Indeterminate` and the
//!   pump proceeds to `wire_read_frame`. Inventing a closed peer from a
//!   would-block write would drop live sessions.

use std::io::{self, Read, Write};
use std::time::Duration;

use crate::endpoint::{PeerProbe, WireIo};
use crate::wire::{wire_read_frame, wire_write_frame, WireFrameError};

/// One connected session: a stream plus the idle timeout `calyd` already
/// applied per connection. The pump does not own the listener.
pub struct FramePump<S: WireIo> {
    stream: S,
    idle: Option<Duration>,
}

impl<S: WireIo> FramePump<S> {
    pub fn new(stream: S, idle: Option<Duration>) -> io::Result<Self> {
        if let Some(idle) = idle {
            stream.set_read_timeout(Some(idle))?;
            stream.set_write_timeout(Some(idle))?;
        }
        Ok(Self { stream, idle })
    }

    pub fn inner(&self) -> &S {
        &self.stream
    }

    pub fn inner_mut(&mut self) -> &mut S {
        &mut self.stream
    }

    pub fn into_inner(self) -> S {
        self.stream
    }

    pub fn idle(&self) -> Option<Duration> {
        self.idle
    }

    /// Replace the bounded transport deadline for both directions, like `new` did.
    ///
    /// One conversation can span two timing shapes: a request/answer op owes the peer a fast
    /// answer (the short `idle` from `new`), but a lossless-resumable stream legitimately waits
    /// through silent ticks — the daemon's pump emits nothing on a `Wait` (an empty push would
    /// claim work happened), and a real core's spawn/probe can stay quiet for seconds. Reading a
    /// that stream with the short op deadline makes a healthy long job surface a false timeout.
    /// `set_idle` re-bounds BOTH read and write to the stream deadline (write stays symmetric,
    /// per the daemon's `set_transport_deadlines` rule); passing `None` clears the deadlines.
    pub fn set_idle(&mut self, idle: Option<Duration>) -> io::Result<()> {
        if let Some(idle) = idle {
            self.stream.set_read_timeout(Some(idle))?;
            self.stream.set_write_timeout(Some(idle))?;
        } else {
            self.stream.set_read_timeout(None)?;
            self.stream.set_write_timeout(None)?;
        }
        self.idle = idle;
        Ok(())
    }

    pub fn transport_kind(&self) -> &'static str {
        self.stream.transport_kind()
    }

    /// Probe before a blocking read. `Closed` is an error the caller maps to
    /// "peer gone". `Indeterminate` (UDS) is not an error — the next read is
    /// the source of truth.
    pub fn probe(&self) -> io::Result<PeerProbe> {
        self.stream.probe_peer()
    }

    pub fn send(&mut self, kind: u8, payload: &[u8]) -> Result<(), WireFrameError> {
        wire_write_frame(&mut self.stream, kind, payload)
    }

    /// The dead-peer probe runs on a SHORT leash, never on the read deadline the caller is
    /// waiting on. A TCP `peek` blocks until a byte arrives or the read timeout fires; if the
    /// probe borrowed the caller's full deadline, a silent peer would make every `recv` wait out
    /// that deadline in `peek` (its timeout is mapped to `Alive`, not an error) and THEN wait it
    /// out again in `read_exact` — doubling the effective silent-peer budget and making a stream
    /// idle widening useless for any gap shorter than two deadlines. Narrow the read deadline to
    /// the probe window, peek, then restore the caller's deadline before the real blocking read.
    /// This mirrors the daemon's stream pump, which narrows to 50ms around its own probe and
    /// restores `session_idle` for the read. UDS has no peek (`Indeterminate`), so the narrowing
    /// is harmless there.
    const PROBE_WINDOW: Duration = crate::timeout::PROBE_WINDOW;

    pub fn recv(&mut self) -> Result<Option<(u8, Vec<u8>)>, WireFrameError> {
        // Narrow to the probe window, peek, restore — the probe must not spend the read budget.
        let restore = self.idle;
        if let Err(error) = self.stream.set_read_timeout(Some(Self::PROBE_WINDOW)) {
            return Err(WireFrameError {
                summary: format!("narrow read deadline for probe: {error}"),
                timed_out: false,
            });
        }
        let probed = self.stream.probe_peer();
        if let Err(error) = self.stream.set_read_timeout(restore) {
            return Err(WireFrameError {
                summary: format!("restore read deadline after probe: {error}"),
                timed_out: false,
            });
        }
        match probed {
            Ok(PeerProbe::Closed) => Err(WireFrameError {
                summary: format!(
                    "{} peer closed before the next frame (peek returned 0)",
                    self.stream.transport_kind()
                ),
                timed_out: false,
            }),
            Ok(PeerProbe::Alive) | Ok(PeerProbe::Indeterminate) => {
                wire_read_frame(&mut self.stream)
            }
            Err(error) => Err(WireFrameError {
                summary: format!("probe peer: {error}"),
                timed_out: matches!(
                    error.kind(),
                    io::ErrorKind::WouldBlock | io::ErrorKind::TimedOut
                ),
            }),
        }
    }

    /// Send then recv. Handshake uses this once. The production CLI does not call the
    /// typed `ClientLoop::send_request_frame` — round 76 excluded the double-table
    /// wiring and round 123 re-evaluated and upheld that: requests go through the ONE
    /// typed encode table (`wire_ops::wire_request`) on the Session/FramePump path.
    pub fn round_trip(
        &mut self,
        kind: u8,
        payload: &[u8],
    ) -> Result<Option<(u8, Vec<u8>)>, WireFrameError> {
        self.send(kind, payload)?;
        self.recv()
    }
}

/// A pair of in-memory pipes used by unit tests that must not open a socket.
/// Each direction is a cursor plus a sink. Tests that need a real duplex use
/// `WireListener` or `UnixStream::pair`.
pub struct MemoryIo {
    read: std::io::Cursor<Vec<u8>>,
    write: Vec<u8>,
    probe: PeerProbe,
    /// The deadlines the pump last set, recorded so a test can assert `set_idle` re-bounds BOTH
    /// directions symmetrically (`None` means cleared). Interior mutability because `WireIo` takes
    /// `&self`.
    read_deadline: std::cell::Cell<Option<Duration>>,
    write_deadline: std::cell::Cell<Option<Duration>>,
    /// Every read deadline the pump set, in order — so a test can assert `recv` narrows to the
    /// probe window and then restores the caller's idle deadline (the probe must not borrow the
    /// read budget). Interior mutability because `WireIo` takes `&self`.
    read_deadline_history: std::cell::RefCell<Vec<Option<Duration>>>,
}

impl MemoryIo {
    pub fn from_bytes(bytes: Vec<u8>) -> Self {
        Self {
            read: std::io::Cursor::new(bytes),
            write: Vec::new(),
            probe: PeerProbe::Alive,
            read_deadline: std::cell::Cell::new(None),
            write_deadline: std::cell::Cell::new(None),
            read_deadline_history: std::cell::RefCell::new(Vec::new()),
        }
    }

    pub fn closed() -> Self {
        Self {
            probe: PeerProbe::Closed,
            ..Self::from_bytes(Vec::new())
        }
    }

    pub fn indeterminate() -> Self {
        Self {
            probe: PeerProbe::Indeterminate,
            ..Self::from_bytes(Vec::new())
        }
    }

    pub fn written(&self) -> &[u8] {
        &self.write
    }

    pub fn set_probe(&mut self, probe: PeerProbe) {
        self.probe = probe;
    }

    /// The (read, write) deadlines last set (`(None, None)` until the pump sets one).
    pub fn deadlines(&self) -> (Option<Duration>, Option<Duration>) {
        (self.read_deadline.get(), self.write_deadline.get())
    }

    /// The sequence of read deadlines the pump was asked to set, in order. A `recv` that keeps
    /// the probe off the read budget narrows to the probe window and restores the idle deadline,
    /// so a recv-driven history ends with the idle deadline — never the short probe window.
    pub fn read_deadline_history(&self) -> Vec<Option<Duration>> {
        self.read_deadline_history.borrow().clone()
    }
}

impl Read for MemoryIo {
    fn read(&mut self, buf: &mut [u8]) -> io::Result<usize> {
        self.read.read(buf)
    }
}

impl Write for MemoryIo {
    fn write(&mut self, buf: &[u8]) -> io::Result<usize> {
        self.write.extend_from_slice(buf);
        Ok(buf.len())
    }

    fn flush(&mut self) -> io::Result<()> {
        Ok(())
    }
}

impl WireIo for MemoryIo {
    fn set_read_timeout(&self, timeout: Option<Duration>) -> io::Result<()> {
        self.read_deadline.set(timeout);
        self.read_deadline_history.borrow_mut().push(timeout);
        Ok(())
    }

    fn set_write_timeout(&self, timeout: Option<Duration>) -> io::Result<()> {
        self.write_deadline.set(timeout);
        Ok(())
    }

    fn probe_peer(&self) -> io::Result<PeerProbe> {
        Ok(self.probe)
    }

    fn transport_kind(&self) -> &'static str {
        "memory"
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::dialect::client_hello_payload;
    use crate::wire::WIRE_KIND_HELLO;
    use caly_api::Role;

    #[test]
    fn closed_probe_does_not_read() {
        let mut pump = FramePump::new(MemoryIo::closed(), None).expect("pump");
        let error = pump.recv().expect_err("closed");
        assert!(
            error.summary.contains("peek returned 0"),
            "{}",
            error.summary
        );
        assert!(!error.timed_out);
    }

    #[test]
    fn indeterminate_probe_falls_through_to_read() {
        let mut pump = FramePump::new(MemoryIo::indeterminate(), None).expect("pump");
        let frame = pump
            .recv()
            .expect("empty cursor is a clean EOF, not a probe close");
        assert!(
            frame.is_none(),
            "uds-shaped probe must not pretend peek saw a close"
        );
    }

    #[test]
    fn send_writes_a_framed_hello() {
        let mut pump = FramePump::new(MemoryIo::from_bytes(Vec::new()), None).expect("pump");
        let payload = client_hello_payload(Role::Admin, false);
        pump.send(WIRE_KIND_HELLO, &payload).expect("send");
        let written = pump.inner().written();
        assert!(
            written.len() > 5,
            "kind + length prefix plus payload, got {}",
            written.len()
        );
        assert_eq!(written[0], WIRE_KIND_HELLO);
        let len = u32::from_be_bytes(written[1..5].try_into().expect("prefix"));
        assert_eq!(len as usize, written.len() - 5);
        assert_eq!(&written[5..], payload.as_slice());
    }

    #[test]
    fn transport_kind_is_memory_for_the_fixture() {
        let pump = FramePump::new(MemoryIo::from_bytes(Vec::new()), None).expect("pump");
        assert_eq!(pump.transport_kind(), "memory");
    }

    /// `set_idle` (round 91, the follow-stream widen) re-bounds BOTH directions and records the
    /// live value. A stream waits through silent ticks, so its deadline is wider than the
    /// request/answer one — but the write half must never be left behind (round 90's symmetry).
    #[test]
    fn set_idle_rebounds_both_directions_and_reports_the_live_deadline() {
        let mut pump = FramePump::new(
            MemoryIo::from_bytes(Vec::new()),
            Some(Duration::from_secs(3)),
        )
        .expect("pump");
        assert_eq!(pump.idle(), Some(Duration::from_secs(3)));
        assert_eq!(
            pump.inner().deadlines(),
            (Some(Duration::from_secs(3)), Some(Duration::from_secs(3)))
        );

        pump.set_idle(Some(Duration::from_secs(30))).expect("widen");
        assert_eq!(pump.idle(), Some(Duration::from_secs(30)));
        assert_eq!(
            pump.inner().deadlines(),
            (Some(Duration::from_secs(30)), Some(Duration::from_secs(30))),
            "set_idle must move the write deadline with the read one"
        );
    }

    /// `set_idle(None)` clears both deadlines (and `idle()` then reports None). This is the
    /// symmetric clear; it must not leave one direction bounded while the other is not.
    #[test]
    fn set_idle_none_clears_both_deadlines() {
        let mut pump = FramePump::new(
            MemoryIo::from_bytes(Vec::new()),
            Some(Duration::from_secs(3)),
        )
        .expect("pump");
        pump.set_idle(None).expect("clear");
        assert_eq!(pump.idle(), None);
        assert_eq!(pump.inner().deadlines(), (None, None));
    }

    /// The dead-peer probe must run on a short leash and then restore the caller's read
    /// deadline. A `peek` blocks up to the read timeout and maps that timeout to `Alive`; if the
    /// probe borrowed the caller's full deadline, every silent `recv` would wait it out in `peek`
    /// and AGAIN in `read_exact` — doubling the effective silent-peer budget and making a stream
    /// idle widening useless for short gaps. This asserts the deadline sequence a `recv` drives:
    /// narrow to the probe window, then restore the idle deadline before the blocking read.
    #[test]
    fn recvs_probe_uses_a_short_window_and_restores_the_idle_deadline() {
        let idle = Duration::from_secs(30);
        let mut pump = FramePump::new(MemoryIo::from_bytes(Vec::new()), Some(idle)).expect("pump");
        // An empty read cursor is a clean EOF after the Alive probe — `recv` returns Ok(None).
        let frame = pump
            .recv()
            .expect("an Alive probe followed by an empty cursor is Ok(None)");
        assert_eq!(frame, None);
        let history = pump.inner().read_deadline_history();
        assert!(
            history.len() >= 2,
            "recv must narrow for the probe and then restore; got {history:?}"
        );
        // The last deadline recv leaves in place is the caller's idle deadline, never the short
        // probe window — the blocking read that follows runs on the caller's budget.
        assert_eq!(
            history.last().copied().flatten(),
            Some(idle),
            "the read deadline after a recv must be the idle deadline, got {history:?}"
        );
        // Somewhere in the recv the deadline was narrowed to the (shorter) probe window.
        assert!(
            history.iter().any(|d| d.is_some_and(|d| d < idle)),
            "recv must narrow to a probe window shorter than the idle deadline; got {history:?}"
        );
    }
}
