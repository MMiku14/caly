//! Duplex frame pump over [`crate::endpoint::WireIo`].
//!
//! The production daemon and CLI used to own their own `wire_read_frame` /
//! `wire_write_frame` loops against a `TcpStream`. Round 87 lifts the loop onto
//! the shared stream type so a Unix-domain listener is not a second copy of the
//! same pump. This module does not invent a request scheduler: it writes one
//! dialect frame and reads one dialect frame, and it asks the stream whether
//! the peer is still there *before* blocking on a read.
//!
//! Probe honesty:
//!
//! - TCP: `TcpStream::peek` distinguishes `Closed` (0-byte) from `Alive`
//!   (would-block or a byte waiting).
//! - UDS: `UnixStream` has no std `peek`. The probe is `Indeterminate` and the
//!   pump proceeds to `wire_read_frame`. Inventing a closed peer from a
//!   would-block write would drop live sessions.

use std::io::{self, Read, Write};
use std::time::Duration;

use crate::endpoint::{PeerProbe, WireIo};
use crate::wire::{wire_read_frame, wire_write_frame, WireFrameError};

/// One connected session: a stream plus the idle timeout `calyd` already
/// applied per connection. The pump does not own the listener.
pub struct FramePump<S: WireIo> {
    stream: S,
    idle: Option<Duration>,
}

impl<S: WireIo> FramePump<S> {
    pub fn new(stream: S, idle: Option<Duration>) -> io::Result<Self> {
        if let Some(idle) = idle {
            stream.set_read_timeout(Some(idle))?;
            stream.set_write_timeout(Some(idle))?;
        }
        Ok(Self { stream, idle })
    }

    pub fn inner(&self) -> &S {
        &self.stream
    }

    pub fn inner_mut(&mut self) -> &mut S {
        &mut self.stream
    }

    pub fn into_inner(self) -> S {
        self.stream
    }

    pub fn idle(&self) -> Option<Duration> {
        self.idle
    }

    pub fn transport_kind(&self) -> &'static str {
        self.stream.transport_kind()
    }

    /// Probe before a blocking read. `Closed` is an error the caller maps to
    /// "peer gone". `Indeterminate` (UDS) is not an error — the next read is
    /// the source of truth.
    pub fn probe(&self) -> io::Result<PeerProbe> {
        self.stream.probe_peer()
    }

    pub fn send(&mut self, kind: u8, payload: &[u8]) -> Result<(), WireFrameError> {
        wire_write_frame(&mut self.stream, kind, payload)
    }

    pub fn recv(&mut self) -> Result<Option<(u8, Vec<u8>)>, WireFrameError> {
        match self.stream.probe_peer() {
            Ok(PeerProbe::Closed) => Err(WireFrameError {
                summary: format!(
                    "{} peer closed before the next frame (peek returned 0)",
                    self.stream.transport_kind()
                ),
                timed_out: false,
            }),
            Ok(PeerProbe::Alive) | Ok(PeerProbe::Indeterminate) => {
                wire_read_frame(&mut self.stream)
            }
            Err(error) => Err(WireFrameError {
                summary: format!("probe peer: {error}"),
                timed_out: matches!(
                    error.kind(),
                    io::ErrorKind::WouldBlock | io::ErrorKind::TimedOut
                ),
            }),
        }
    }

    /// Send then recv. Handshake uses this once; a request/response pair in a
    /// later round can reuse it. Round 87 does not call the typed
    /// `ClientLoop::send_request_frame` from the CLI.
    pub fn round_trip(
        &mut self,
        kind: u8,
        payload: &[u8],
    ) -> Result<Option<(u8, Vec<u8>)>, WireFrameError> {
        self.send(kind, payload)?;
        self.recv()
    }
}

/// A pair of in-memory pipes used by unit tests that must not open a socket.
/// Each direction is a cursor plus a sink. Tests that need a real duplex use
/// `WireListener` or `UnixStream::pair`.
pub struct MemoryIo {
    read: std::io::Cursor<Vec<u8>>,
    write: Vec<u8>,
    probe: PeerProbe,
}

impl MemoryIo {
    pub fn from_bytes(bytes: Vec<u8>) -> Self {
        Self {
            read: std::io::Cursor::new(bytes),
            write: Vec::new(),
            probe: PeerProbe::Alive,
        }
    }

    pub fn closed() -> Self {
        Self {
            read: std::io::Cursor::new(Vec::new()),
            write: Vec::new(),
            probe: PeerProbe::Closed,
        }
    }

    pub fn indeterminate() -> Self {
        Self {
            read: std::io::Cursor::new(Vec::new()),
            write: Vec::new(),
            probe: PeerProbe::Indeterminate,
        }
    }

    pub fn written(&self) -> &[u8] {
        &self.write
    }

    pub fn set_probe(&mut self, probe: PeerProbe) {
        self.probe = probe;
    }
}

impl Read for MemoryIo {
    fn read(&mut self, buf: &mut [u8]) -> io::Result<usize> {
        self.read.read(buf)
    }
}

impl Write for MemoryIo {
    fn write(&mut self, buf: &[u8]) -> io::Result<usize> {
        self.write.extend_from_slice(buf);
        Ok(buf.len())
    }

    fn flush(&mut self) -> io::Result<()> {
        Ok(())
    }
}

impl WireIo for MemoryIo {
    fn set_read_timeout(&self, _timeout: Option<Duration>) -> io::Result<()> {
        Ok(())
    }

    fn set_write_timeout(&self, _timeout: Option<Duration>) -> io::Result<()> {
        Ok(())
    }

    fn probe_peer(&self) -> io::Result<PeerProbe> {
        Ok(self.probe)
    }

    fn transport_kind(&self) -> &'static str {
        "memory"
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::dialect::client_hello_payload;
    use crate::wire::WIRE_KIND_HELLO;
    use caly_api::Role;

    #[test]
    fn closed_probe_does_not_read() {
        let mut pump = FramePump::new(MemoryIo::closed(), None).expect("pump");
        let error = pump.recv().expect_err("closed");
        assert!(
            error.summary.contains("peek returned 0"),
            "{}",
            error.summary
        );
        assert!(!error.timed_out);
    }

    #[test]
    fn indeterminate_probe_falls_through_to_read() {
        let mut pump = FramePump::new(MemoryIo::indeterminate(), None).expect("pump");
        let frame = pump
            .recv()
            .expect("empty cursor is a clean EOF, not a probe close");
        assert!(
            frame.is_none(),
            "uds-shaped probe must not pretend peek saw a close"
        );
    }

    #[test]
    fn send_writes_a_framed_hello() {
        let mut pump = FramePump::new(MemoryIo::from_bytes(Vec::new()), None).expect("pump");
        let payload = client_hello_payload(Role::Admin, false);
        pump.send(WIRE_KIND_HELLO, &payload).expect("send");
        let written = pump.inner().written();
        assert!(
            written.len() > 5,
            "kind + length prefix plus payload, got {}",
            written.len()
        );
        assert_eq!(written[0], WIRE_KIND_HELLO);
        let len = u32::from_be_bytes(written[1..5].try_into().expect("prefix"));
        assert_eq!(len as usize, written.len() - 5);
        assert_eq!(&written[5..], payload.as_slice());
    }

    #[test]
    fn transport_kind_is_memory_for_the_fixture() {
        let pump = FramePump::new(MemoryIo::from_bytes(Vec::new()), None).expect("pump");
        assert_eq!(pump.transport_kind(), "memory");
    }
}
