//! The shared timeout scheduler: ONE home for every transport deadline.
//!
//! Before round 122 the deadlines were right but scattered — the client owned three
//! constants (`CONNECT_TIMEOUT`/`READ_TIMEOUT`/`STREAM_IDLE_TIMEOUT` in `caly.rs`), the
//! daemon owned two more (`HELLO_TIMEOUT`, `--session-idle-ms`'s default) plus a
//! hand-rolled probe dance in the stream pump, and `FramePump::recv` owned its own probe
//! window. Each site applied its value by calling `set_read_timeout`/`set_write_timeout`
//! directly (rounds 44/89/90/91 fixed them one site at a time). That is four places to
//! forget the write half, five values to keep consistent with the docs, and no single
//! object that can answer "what deadline is THIS connection on right now".
//!
//! This module is that object. The policy table below is the single source every
//! production speaker reads (`caly` and `calyd` no longer define transport `Duration`
//! literals — the arch gate `the_transport_deadlines_have_one_home` keeps it structural);
//! the [`TimeoutScheduler`] applies the table to a connection's transport on phase
//! transitions and remembers which phase the connection is on, so the probe window can
//! be narrowed and **restored to the live phase** (round 91's lesson, server side) rather
//! than to whatever a call site remembers.
//!
//! The phases, in the order a connection meets them:
//!
//! | Phase | Value | Who enters it | Why this wide / this narrow |
//! |---|---|---|---|
//! | Connecting | 3s | client only | a daemon that is down must fail fast, not hang dialing |
//! | Handshaking | 5s | both | strangers owe a quick hello (`HELLO_TIMEOUT`) |
//! | Requesting | 3s | client | a request/answer op owes a fast answer (exit 11 past it) |
//! | Streaming | 30s idle | both | a lossless stream legitimately waits through silent ticks |
//! | Serving | session idle (default 30s, `--session-idle-ms`) | daemon | a session that stops talking is reaped by idle policy |
//! | Draining | 3s | daemon, post-SIGTERM | established sessions finish their in-flight requests; the listener is already closed (round 124) |
//!
//! Every phase sets BOTH the read and the write deadline (round 90: a peer that stops
//! reading must not pin the writer; round 89: ditto the client). The probe window (50ms)
//! is not a phase — it is the short leash a liveness peek runs on, restored to the live
//! phase immediately after (`PROBE_WINDOW`, the same value `FramePump::recv` narrows to).

use std::io;
use std::time::Duration;

use crate::endpoint::{PeerProbe, WireIo};

/// Connect budget: how long dialing the daemon may take (client only; TCP
/// `connect_timeout`/UDS `connect`). A daemon that is down is exit 12 territory, and a
/// client that hangs in `connect` cannot even reach its own timeout wording.
pub const CONNECT_TIMEOUT: Duration = Duration::from_secs(3);

/// Stranger budget: hello AND hello_ack both owe this (round 90 — a peer that accepts
/// the connection then never reads hello_ack must not pin a server thread).
pub const HANDSHAKE_TIMEOUT: Duration = Duration::from_secs(5);

/// One request/answer op's budget on the client. Past it the CLI reports timeout as
/// exit 11 (`docs/guides/EXIT_CODES.md §3`), so the wording "timed out after {ms}ms" is
/// part of the contract and reads the scheduler's live phase.
pub const REQUEST_TIMEOUT: Duration = Duration::from_secs(3);

/// A followed Job stream's per-frame idle budget (round 91). A lossless-resumable
/// stream is NOT request/answer: the daemon's pump emits nothing on a quiet tick and a
/// real core's spawn/probe can stay silent for seconds, so the stream waits on the
/// stream's scale — still bounded, just wider than an answer's.
pub const STREAM_IDLE_TIMEOUT: Duration = Duration::from_secs(30);

/// The daemon's default session idle (`--session-idle-ms` overrides per invocation).
pub const DEFAULT_SESSION_IDLE: Duration = Duration::from_secs(30);

/// The daemon's shutdown drain window (round 124, the ADR-056 stop sequence): after
/// SIGTERM the listener closes and sessions ALREADY established keep being served for
/// exactly this long before the core stops and the process exits 0. Request-sized on
/// purpose: an in-flight request/answer is bounded by `REQUEST_TIMEOUT` anyway, so a
/// window equal to it serves every conversation that could still complete. Streams that
/// outlive the window are cut — honestly recoverable, because job events are durable
/// (`ADR-057`) and `caly follow --resume` reconnects against the restarted daemon.
pub const SHUTDOWN_DRAIN: Duration = Duration::from_secs(3);

/// The liveness peek's short leash. A TCP `peek` blocks until a byte arrives or the read
/// deadline fires; a probe that borrowed the caller's full deadline would double the
/// effective silent-peer budget (round 91). Narrowed and restored around every probe.
pub const PROBE_WINDOW: Duration = Duration::from_millis(50);

/// What the scheduler may apply deadlines to. `FramePump` implements it by delegating
/// to `set_idle` (which also keeps the pump's own restore-on-probe in sync), a bare
/// `WireIo` implements it by setting both halves itself.
pub trait DeadlineIo {
    /// Set BOTH the read and the write deadline. `None` clears them (the same contract
    /// as `FramePump::set_idle`).
    fn apply_deadline(&mut self, idle: Option<Duration>) -> io::Result<()>;
}

impl<S: WireIo + ?Sized> DeadlineIo for S {
    fn apply_deadline(&mut self, idle: Option<Duration>) -> io::Result<()> {
        self.set_read_timeout(idle)?;
        self.set_write_timeout(idle)
    }
}

impl<S: WireIo> DeadlineIo for crate::duplex::FramePump<S> {
    fn apply_deadline(&mut self, idle: Option<Duration>) -> io::Result<()> {
        self.set_idle(idle)
    }
}

/// A per-connection timeout scheduler: the policy table resolved for THIS connection
/// (the daemon's session idle may be operator-tuned) plus the phase it is currently in.
///
/// One scheduler instance per connection — the phase memory is exactly the thing the
/// hand-rolled sites kept forgetting (the daemon's probe dance restored the read
/// deadline to a value a different site once set; if the two disagreed, the probe
/// quietly CHANGED the connection's deadline). Created via [`TimeoutScheduler::client`]
/// (connecting side) or [`TimeoutScheduler::server`] (accepting side, which owns the
/// session idle policy).
pub struct TimeoutScheduler {
    session_idle: Duration,
    phase: Duration,
}

impl TimeoutScheduler {
    /// The scheduler a connecting speaker (`caly`) uses: session idle is never its
    /// policy to apply, so the default stands in the table only.
    pub fn client() -> Self {
        Self {
            session_idle: DEFAULT_SESSION_IDLE,
            phase: CONNECT_TIMEOUT,
        }
    }

    /// The scheduler an accepting speaker (`calyd`) uses; `session_idle` is the
    /// resolved `--session-idle-ms` policy for this invocation.
    pub fn server(session_idle: Duration) -> Self {
        Self {
            session_idle,
            phase: HANDSHAKE_TIMEOUT,
        }
    }

    /// The connect budget (client only — the server never dials).
    pub fn connect_timeout(&self) -> Duration {
        CONNECT_TIMEOUT
    }

    /// The deadline this connection is currently on (the phase last entered). The CLI's
    /// timeout wording reads this so "timed out after Nms" always names the live phase.
    pub fn current(&self) -> Duration {
        self.phase
    }

    /// The session idle policy this server was built with (diagnostics/tests).
    pub fn session_idle(&self) -> Duration {
        self.session_idle
    }

    /// Phase: a stranger owes a fast hello. Both halves (round 90).
    pub fn enter_handshake<T: DeadlineIo + ?Sized>(&mut self, io: &mut T) -> io::Result<()> {
        self.enter(io, HANDSHAKE_TIMEOUT)
    }

    /// Phase: one request/answer op (client). Both halves.
    pub fn enter_request<T: DeadlineIo + ?Sized>(&mut self, io: &mut T) -> io::Result<()> {
        self.enter(io, REQUEST_TIMEOUT)
    }

    /// Phase: a lossless stream's idle window (both speakers). Both halves.
    pub fn enter_stream<T: DeadlineIo + ?Sized>(&mut self, io: &mut T) -> io::Result<()> {
        self.enter(io, STREAM_IDLE_TIMEOUT)
    }

    /// Phase: the server's session idle (post-hello serving). Both halves.
    pub fn enter_session<T: DeadlineIo + ?Sized>(&mut self, io: &mut T) -> io::Result<()> {
        self.enter(io, self.session_idle)
    }

    fn enter<T: DeadlineIo + ?Sized>(&mut self, io: &mut T, idle: Duration) -> io::Result<()> {
        io.apply_deadline(Some(idle))?;
        self.phase = idle;
        Ok(())
    }

    /// Liveness probe on the short leash: narrow the read deadline to [`PROBE_WINDOW`],
    /// peek, then restore BOTH halves to the **live phase** — not to a value the caller
    /// remembers (the round-91 lesson, now applied server-side too: a restore that
    /// names a different value than the phase silently re-deadlines the connection).
    ///
    /// `Indeterminate` (UDS: std has no peek) is returned as-is; inventing a close from
    /// a would-block write would drop live sessions (`TRANSPORT_RUNTIME_MODEL §5`).
    pub fn probe_peer<T: WireIo + ?Sized>(&mut self, io: &mut T) -> io::Result<PeerProbe> {
        io.set_read_timeout(Some(PROBE_WINDOW))?;
        let probed = io.probe_peer()?;
        // Restore to the live phase, both halves (read was narrowed; write is set again
        // idempotently so there is exactly one application path).
        let phase = self.phase;
        io.apply_deadline(Some(phase))?;
        Ok(probed)
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    /// A WireIo that records every deadline it is told to apply (and reads/writes
    /// nothing). The recorded sequence IS the judge's evidence. `WireIo`'s setters take
    /// `&self` (the OS socket mutates behind the handle), so the log lives in a RefCell.
    #[derive(Default)]
    struct RecordingIo {
        log: std::cell::RefCell<Vec<(char, String)>>,
    }

    impl RecordingIo {
        fn reads(&self) -> Vec<String> {
            self.log
                .borrow()
                .iter()
                .filter(|(half, _)| *half == 'r')
                .map(|(_, v)| v.clone())
                .collect()
        }

        fn writes(&self) -> Vec<String> {
            self.log
                .borrow()
                .iter()
                .filter(|(half, _)| *half == 'w')
                .map(|(_, v)| v.clone())
                .collect()
        }

        fn clear(&self) {
            self.log.borrow_mut().clear();
        }
    }

    impl std::io::Read for RecordingIo {
        fn read(&mut self, _: &mut [u8]) -> std::io::Result<usize> {
            Ok(0)
        }
    }

    impl std::io::Write for RecordingIo {
        fn write(&mut self, buf: &[u8]) -> std::io::Result<usize> {
            Ok(buf.len())
        }

        fn flush(&mut self) -> std::io::Result<()> {
            Ok(())
        }
    }

    impl WireIo for RecordingIo {
        fn transport_kind(&self) -> &'static str {
            "recording"
        }

        fn probe_peer(&self) -> std::io::Result<PeerProbe> {
            Ok(PeerProbe::Alive)
        }

        fn set_read_timeout(&self, timeout: Option<Duration>) -> std::io::Result<()> {
            self.log.borrow_mut().push(('r', fmt(timeout)));
            Ok(())
        }

        fn set_write_timeout(&self, timeout: Option<Duration>) -> std::io::Result<()> {
            self.log.borrow_mut().push(('w', fmt(timeout)));
            Ok(())
        }
    }

    fn fmt(timeout: Option<Duration>) -> String {
        timeout
            .map(|d| format!("{}ms", d.as_millis()))
            .unwrap_or_else(|| "none".to_owned())
    }

    /// The table IS the documented contract: every value the docs name, named once,
    /// here. A value that moves must move in the same commit as the docs (and the e2e
    /// judges that time against it).
    #[test]
    fn the_documented_table_is_the_one_production_reads() {
        assert_eq!(CONNECT_TIMEOUT, Duration::from_secs(3));
        assert_eq!(HANDSHAKE_TIMEOUT, Duration::from_secs(5));
        assert_eq!(REQUEST_TIMEOUT, Duration::from_secs(3));
        assert_eq!(STREAM_IDLE_TIMEOUT, Duration::from_secs(30));
        assert_eq!(DEFAULT_SESSION_IDLE, Duration::from_secs(30));
        assert_eq!(PROBE_WINDOW, Duration::from_millis(50));
        assert_eq!(SHUTDOWN_DRAIN, Duration::from_secs(3));
        // Relations that carry meaning, not just numbers: a stream's idle window must
        // OUT-WAIT a request's (else the round-91 widening is a no-op), a probe window
        // must be far SHORTER than any phase (else a probe spends the read budget), and
        // a stranger's hello budget must out-wait the connect budget that precedes it.
        assert!(
            STREAM_IDLE_TIMEOUT > REQUEST_TIMEOUT,
            "a silent-but-healthy stream must not time out on the answer's clock"
        );
        assert!(
            PROBE_WINDOW < REQUEST_TIMEOUT,
            "the liveness peek must not borrow the caller's deadline"
        );
        assert!(
            HANDSHAKE_TIMEOUT >= CONNECT_TIMEOUT,
            "a slow-but-live handshake must not be pre-empted by a shorter connect budget"
        );
        assert_eq!(
            SHUTDOWN_DRAIN, REQUEST_TIMEOUT,
            "the drain window is request-sized: every in-flight conversation that could \
             still complete, can; longer windows would only delay the core stop"
        );
    }

    /// The client journey: connect → handshake → request → stream. Every phase sets
    /// BOTH halves (rounds 89/90: a read-only deadline pins the writer), and the phase
    /// the scheduler reports is the one it just applied.
    #[test]
    fn a_client_connection_walks_its_deadline_phases() {
        let mut io = RecordingIo::default();
        let mut scheduler = TimeoutScheduler::client();
        assert_eq!(scheduler.connect_timeout(), CONNECT_TIMEOUT);
        scheduler.enter_handshake(&mut io).expect("handshake");
        assert_eq!(io.reads(), ["5000ms"]);
        assert_eq!(io.writes(), ["5000ms"]);
        assert_eq!(scheduler.current(), HANDSHAKE_TIMEOUT);
        scheduler.enter_request(&mut io).expect("request");
        assert_eq!(io.reads(), ["5000ms", "3000ms"]);
        assert_eq!(io.writes(), ["5000ms", "3000ms"]);
        scheduler.enter_stream(&mut io).expect("stream");
        assert_eq!(io.reads(), ["5000ms", "3000ms", "30000ms"]);
        assert_eq!(io.writes(), ["5000ms", "3000ms", "30000ms"]);
        assert_eq!(scheduler.current(), STREAM_IDLE_TIMEOUT);
    }

    /// The server journey: accept (a stranger's hello) → session (the operator's
    /// `--session-idle-ms` policy, not a hardcoded default). The override must actually
    /// land on the wire deadlines — a flag that parses but never applies is a silent
    /// no-op.
    #[test]
    fn a_server_connection_walks_its_deadline_phases_and_honours_the_idle_flag() {
        let mut io = RecordingIo::default();
        let mut scheduler = TimeoutScheduler::server(Duration::from_secs(7));
        scheduler.enter_handshake(&mut io).expect("handshake");
        assert_eq!(io.reads(), ["5000ms"]);
        assert_eq!(io.writes(), ["5000ms"]);
        scheduler.enter_session(&mut io).expect("session");
        assert_eq!(io.reads(), ["5000ms", "7000ms"]);
        assert_eq!(io.writes(), ["5000ms", "7000ms"]);
        assert_eq!(scheduler.current(), Duration::from_secs(7));
        // Without the override the documented default applies.
        let mut io = RecordingIo::default();
        let mut scheduler = TimeoutScheduler::server(DEFAULT_SESSION_IDLE);
        scheduler.enter_session(&mut io).expect("session");
        assert_eq!(io.reads(), ["30000ms"]);
    }

    /// The probe runs on the short leash and restores the LIVE phase, both halves. The
    /// restore is the load-bearing part: round 91 found a probe that spent the caller's
    /// deadline (client), and the daemon's hand-rolled dance restored a value another
    /// site remembered — a disagreement would silently re-deadline the connection.
    #[test]
    fn a_probe_narrows_the_window_and_restores_the_live_phase() {
        let mut io = RecordingIo::default();
        let mut scheduler = TimeoutScheduler::server(Duration::from_secs(7));
        scheduler.enter_session(&mut io).expect("session");
        io.clear();
        let probed = scheduler.probe_peer(&mut io).expect("probe");
        assert!(matches!(probed, PeerProbe::Alive));
        assert_eq!(
            io.reads(),
            ["50ms", "7000ms"],
            "narrow, then restore the phase"
        );
        assert_eq!(
            io.writes(),
            ["7000ms"],
            "the restore re-asserts the write half too"
        );
        // On a stream-phase connection the same probe restores the stream window.
        scheduler.enter_stream(&mut io).expect("stream");
        io.clear();
        scheduler.probe_peer(&mut io).expect("probe");
        assert_eq!(io.reads(), ["50ms", "30000ms"]);
        assert_eq!(io.writes(), ["30000ms"]);
    }

    /// The scheduler talks to a FramePump through the same `DeadlineIo` door, so the
    /// client's pump-internal probe restore (which replays `pump.idle()`) and the
    /// scheduler's phase can never disagree: entering a phase through the scheduler
    /// sets the pump's idle to the same value.
    #[test]
    fn a_scheduler_phase_and_the_pumps_idle_stay_in_agreement() {
        use crate::duplex::{FramePump, MemoryIo};
        let pump = FramePump::new(MemoryIo::from_bytes(Vec::new()), None).expect("pump");
        let mut pump = pump;
        let mut scheduler = TimeoutScheduler::client();
        scheduler.enter_handshake(&mut pump).expect("handshake");
        assert_eq!(pump.idle(), Some(HANDSHAKE_TIMEOUT));
        scheduler.enter_request(&mut pump).expect("request");
        assert_eq!(pump.idle(), Some(REQUEST_TIMEOUT));
        scheduler.enter_stream(&mut pump).expect("stream");
        assert_eq!(pump.idle(), Some(STREAM_IDLE_TIMEOUT));
        assert_eq!(scheduler.current(), pump.idle().unwrap_or_default());
    }
}
