use std::collections::BTreeMap;

use caly_api::{
    Operation, OperationResult, ProtocolVersion, RequestEnvelope, RequestId, ResponseEnvelope,
    Role, StreamId, TraceId,
};

use crate::frame::{ClientFrame, Compression, Encoding, ServerFrame};
use crate::handshake::{ClientHello, ClientKind, ServerHelloAck};
use crate::policy::{stream_policy, AckPolicy};
use crate::stream::{ResetReason, StreamFrame, StreamKind, StreamPayload};

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct ClientSessionConfig {
    pub protocol: ProtocolVersion,
    pub client_kind: ClientKind,
    pub client_name: String,
    pub role: Role,
    pub requested_encoding: Encoding,
    pub requested_compression: Compression,
    pub supported_features: Vec<String>,
}

impl Default for ClientSessionConfig {
    fn default() -> Self {
        Self {
            protocol: ProtocolVersion { major: 1, minor: 0 },
            client_kind: ClientKind::Cli,
            client_name: "caly-client".to_owned(),
            // Least privilege, and it has to match the local path's default: `ADR-037 §2.2`.
            // A session that gets `Admin` for free while an embedded caller gets `Operator` would make
            // `required_role` differ by access path, which `RFC-0002 §4.1` forbids.
            role: Role::Operator,
            requested_encoding: Encoding::Json,
            requested_compression: Compression::None,
            supported_features: vec![
                "query-command-stream".to_owned(),
                "reset".to_owned(),
                "job-follow".to_owned(),
            ],
        }
    }
}

#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub enum ClientSessionState {
    New,
    HelloSent,
    Active,
    Closed,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct KnownDaemonState {
    pub daemon_name: String,
    pub daemon_version: String,
    pub instance_id: String,
    pub protocol: ProtocolVersion,
    pub selected_encoding: Encoding,
    pub selected_compression: Compression,
    pub state_revision: u64,
}

#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub enum ClientStreamHealth {
    Healthy,
    ResetRequired,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct ClientStreamState {
    pub stream_id: StreamId,
    pub kind: StreamKind,
    pub last_seq: Option<u64>,
    pub acked_upto: Option<u64>,
    pub health: ClientStreamHealth,
    pub last_reset_reason: Option<ResetReason>,
}

impl ClientStreamState {
    pub fn new(stream_id: StreamId, kind: StreamKind) -> Self {
        Self {
            stream_id,
            kind,
            last_seq: None,
            acked_upto: None,
            health: ClientStreamHealth::Healthy,
            last_reset_reason: None,
        }
    }

    pub fn observe_frame(&mut self, frame: &StreamFrame) {
        self.last_seq = Some(frame.seq);
        if let StreamPayload::Reset { reason } = frame.payload.clone() {
            self.health = ClientStreamHealth::ResetRequired;
            self.last_reset_reason = Some(reason);
        }
    }

    pub fn note_ack(&mut self, upto_seq: u64) {
        self.acked_upto = Some(
            self.acked_upto
                .map(|current| current.max(upto_seq))
                .unwrap_or(upto_seq),
        );
    }

    pub fn expected_resume_from(&self) -> Option<u64> {
        match stream_policy(self.kind).ack {
            AckPolicy::Required | AckPolicy::Optional => self.acked_upto.or(self.last_seq),
            AckPolicy::None => self.last_seq,
        }
    }
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct ClientSnapshot {
    pub state: ClientSessionState,
    pub next_request_id: u64,
    pub daemon: Option<KnownDaemonState>,
    pub streams: Vec<ClientStreamState>,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct ClientSession {
    pub config: ClientSessionConfig,
    pub state: ClientSessionState,
    pub next_request_id: u64,
    pub daemon: Option<KnownDaemonState>,
    pub streams: BTreeMap<u64, ClientStreamState>,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub enum ObserveErrorCode {
    UnexpectedHelloAck,
    UnexpectedStream,
    ProtocolMismatch,
    ResponseOnClosedSession,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct ObserveError {
    pub code: ObserveErrorCode,
    pub summary: String,
}

impl ClientSession {
    pub fn new(config: ClientSessionConfig) -> Self {
        Self {
            config,
            state: ClientSessionState::New,
            next_request_id: 1,
            daemon: None,
            streams: BTreeMap::new(),
        }
    }

    pub fn snapshot(&self) -> ClientSnapshot {
        ClientSnapshot {
            state: self.state,
            next_request_id: self.next_request_id,
            daemon: self.daemon.clone(),
            streams: self.streams.values().cloned().collect(),
        }
    }

    pub fn build_hello(&mut self) -> ClientHello {
        self.state = ClientSessionState::HelloSent;
        ClientHello {
            protocol: self.config.protocol,
            client_kind: self.config.client_kind,
            client_name: self.config.client_name.clone(),
            requested_encoding: self.config.requested_encoding,
            requested_compression: self.config.requested_compression,
            supported_features: self.config.supported_features.clone(),
            role: self.config.role,
        }
    }

    pub fn apply_hello_ack(&mut self, ack: &ServerHelloAck) -> Result<(), ObserveError> {
        if !matches!(self.state, ClientSessionState::HelloSent) {
            return Err(ObserveError {
                code: ObserveErrorCode::UnexpectedHelloAck,
                summary: "hello ack received when client is not waiting for negotiation".to_owned(),
            });
        }

        if ack.protocol.major != self.config.protocol.major {
            return Err(ObserveError {
                code: ObserveErrorCode::ProtocolMismatch,
                summary: format!(
                    "daemon protocol major {} does not match client {}",
                    ack.protocol.major, self.config.protocol.major
                ),
            });
        }

        self.daemon = Some(KnownDaemonState {
            daemon_name: ack.daemon_name.clone(),
            daemon_version: ack.daemon_version.clone(),
            instance_id: ack.instance_id.clone(),
            protocol: ack.protocol,
            selected_encoding: ack.selected_encoding,
            selected_compression: ack.selected_compression,
            state_revision: ack.state_revision,
        });
        self.state = ClientSessionState::Active;
        Ok(())
    }

    pub fn next_request_id(&mut self) -> RequestId {
        let id = self.next_request_id;
        self.next_request_id = self.next_request_id.saturating_add(1);
        RequestId(id)
    }

    pub fn make_request(
        &mut self,
        trace_id: impl Into<String>,
        operation: Operation,
        deadline_ms: Option<u64>,
        expected_revision: Option<u64>,
        idempotency_key: Option<String>,
        io_budget: Option<caly_api::IoBudget>,
    ) -> Result<ClientFrame, ObserveError> {
        if !matches!(self.state, ClientSessionState::Active) {
            return Err(ObserveError {
                code: ObserveErrorCode::ResponseOnClosedSession,
                summary: "cannot build request before session becomes active".to_owned(),
            });
        }

        Ok(ClientFrame::Request(RequestEnvelope {
            protocol: self.config.protocol,
            request_id: self.next_request_id(),
            trace_id: TraceId::new(trace_id),
            deadline_ms,
            expected_revision,
            idempotency_key,
            role: self.config.role,
            io_budget,
            operation,
        }))
    }

    pub fn make_stream_ack(
        &mut self,
        stream_id: StreamId,
        upto_seq: u64,
    ) -> Result<ClientFrame, ObserveError> {
        let stream = self
            .streams
            .get_mut(&stream_id.0)
            .ok_or_else(|| ObserveError {
                code: ObserveErrorCode::UnexpectedStream,
                summary: format!("unknown stream id: {}", stream_id.0),
            })?;

        match stream_policy(stream.kind).ack {
            AckPolicy::None => Err(ObserveError {
                code: ObserveErrorCode::UnexpectedStream,
                summary: format!("stream {:?} does not accept ack", stream.kind),
            }),
            AckPolicy::Required | AckPolicy::Optional => {
                stream.note_ack(upto_seq);
                Ok(ClientFrame::StreamAck(crate::stream::Ack {
                    stream_id,
                    upto_seq,
                }))
            }
        }
    }

    pub fn register_stream(&mut self, stream_id: StreamId, kind: StreamKind) {
        self.streams
            .insert(stream_id.0, ClientStreamState::new(stream_id, kind));
    }

    pub fn observe_response(&mut self, response: &ResponseEnvelope) {
        if let Some(daemon) = self.daemon.as_mut() {
            if let Ok(OperationResult::Accepted(accepted)) = &response.result {
                daemon.state_revision = daemon.state_revision.max(accepted.state_revision);
            }
        }
    }

    pub fn observe_stream_frame(&mut self, frame: &StreamFrame) -> Result<(), ObserveError> {
        let stream = self
            .streams
            .get_mut(&frame.stream_id.0)
            .ok_or_else(|| ObserveError {
                code: ObserveErrorCode::UnexpectedStream,
                summary: format!("stream frame for unknown stream {}", frame.stream_id.0),
            })?;
        stream.observe_frame(frame);
        Ok(())
    }

    pub fn observe_server_frame(&mut self, frame: &ServerFrame) -> Result<(), ObserveError> {
        match frame {
            ServerFrame::Response(response) => {
                self.observe_response(response);
                Ok(())
            }
            ServerFrame::Stream(stream) => self.observe_stream_frame(stream),
        }
    }

    pub fn close(&mut self) {
        self.state = ClientSessionState::Closed;
    }
}
