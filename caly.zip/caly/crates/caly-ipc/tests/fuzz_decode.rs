//! Deterministic structure-aware fuzz for the IPC decode boundary (`caly-ipc`): the three
//! parsers a WIRE PEER's bytes reach first — the strict negotiated-JSON reader
//! (`json_to_records`), the tolerant records splitter (`wire_parse_records`), and the
//! frame payload decoder with its length/UTF-8 checks (`decode_raw_json`).
//!
//! Everything on the other end of a socket is foreign. The judge feeds a seeded,
//! reproducible mutation stream over valid wire shapes and demands: **never a panic**, a
//! refusal is **by name**, and the byte layer (frames) answers invalid UTF-8 and lying
//! length headers with typed refusals — never by slicing into bytes it does not have.
//! Local xorshift PRNG, fixed budget, no dependencies: the fuzz runs in the normal gate.

use caly_ipc::{
    codec::{decode_raw_json, encode_raw_json, EncodedFrame},
    json_from_records, json_to_records, wire_parse_records, Compression, Encoding,
};

struct Rng(u64);

impl Rng {
    fn next(&mut self) -> u64 {
        let mut x = self.0;
        x ^= x >> 12;
        x ^= x << 25;
        x ^= x >> 27;
        self.0 = x;
        x.wrapping_mul(0x2545_F491_4F6C_DD1D)
    }

    fn below(&mut self, n: usize) -> usize {
        (self.next() % n.max(1) as u64) as usize
    }
}

const SEED: u64 = 0x1A2B_3C4D_5E6F_7081;

const DELIMITERS: &[u8] = b"|=&\":\\\n\r\t {}[]\x00\xff";

fn mutate(rng: &mut Rng, corpus: &[u8]) -> Vec<u8> {
    let mut bytes = corpus.to_vec();
    let len = bytes.len();
    if len == 0 {
        // The empty corpus entry can only grow: one byte of hostility is the whole
        // space it has.
        return vec![DELIMITERS[rng.below(DELIMITERS.len())]];
    }
    match rng.below(7) {
        0 => bytes.truncate(rng.below(len + 1)),
        1 => {
            let at = rng.below(len);
            bytes[at] ^= 1 << rng.below(8);
        }
        2 => {
            let at = rng.below(len + 1);
            bytes.insert(at, DELIMITERS[rng.below(DELIMITERS.len())]);
        }
        3 => {
            let a = rng.below(len);
            let b = rng.below(len);
            bytes.swap(a, b);
        }
        4 => {
            let start = rng.below(len);
            let end = start + rng.below(len - start + 1);
            let chunk = bytes[start..end].to_vec();
            bytes.extend_from_slice(&chunk);
        }
        5 => {
            let at = rng.below(len + 1);
            bytes.insert(at, b'0' + (rng.below(10) as u8));
        }
        6 => {
            let start = rng.below(len);
            let end = start + rng.below(len - start + 1);
            bytes.drain(start..end);
        }
        _ => unreachable!(),
    }
    bytes
}

#[test]
fn mutated_json_payloads_never_panic_and_refuse_by_name() {
    let corpus = [
        json_from_records(&[]),
        json_from_records(&[("k".to_owned(), "v".to_owned())]),
        json_from_records(&[
            ("节点".to_owned(), "值=|\n\"".to_owned()),
            ("b".to_owned(), String::new()),
        ]),
        "{\"broken".to_owned(),
        String::new(),
    ];
    let mut rng = Rng(SEED);
    let mut accepted = 0;
    let mut refused = 0;
    for step in 0..3000 {
        let base = &corpus[rng.below(corpus.len())];
        let input = if step % 8 == 0 {
            base.clone()
        } else {
            String::from_utf8_lossy(&mutate(&mut rng, base.as_bytes())).into_owned()
        };
        let outcome =
            std::panic::catch_unwind(std::panic::AssertUnwindSafe(|| json_to_records(&input)));
        let Ok(result) = outcome else {
            panic!("json_to_records panicked on {input:?} (step {step})");
        };
        match result {
            Ok(records) => {
                accepted += 1;
                // The green side is real: a document that round-trips through the writer
                // must decode to exactly its records (strict, lossless both ways).
                if step % 8 == 0 {
                    let rebuilt = json_from_records(&records);
                    let Ok(again) = json_to_records(&rebuilt) else {
                        panic!("the writer's own output must decode: {rebuilt:?}");
                    };
                    assert_eq!(again, records, "record round trip is lossless");
                }
            }
            Err(message) => {
                refused += 1;
                assert!(
                    !message.trim().is_empty(),
                    "a refusal must say something by name"
                );
            }
        }
    }
    assert!(accepted > 0 && refused > 0, "both sides exercised");
}

#[test]
fn mutated_record_payloads_never_panic() {
    // `wire_parse_records` is deliberately tolerant (a filter_map over lines); its fuzz
    // invariant is only the never-panic half — but it must hold for ANY line shape,
    // because a hostile peer controls every byte.
    let corpus = [
        "k=v\nk2=v2".to_owned(),
        "no-equals-line".to_owned(),
        "=empty-key".to_owned(),
        "esc=va|nl=l|co=:\\n".to_owned(),
        String::new(),
    ];
    let mut rng = Rng(SEED ^ 0xBEEF);
    for step in 0..3000 {
        let base = &corpus[rng.below(corpus.len())];
        let input = if step % 8 == 0 {
            base.clone()
        } else {
            String::from_utf8_lossy(&mutate(&mut rng, base.as_bytes())).into_owned()
        };
        let outcome =
            std::panic::catch_unwind(std::panic::AssertUnwindSafe(|| wire_parse_records(&input)));
        let Ok(records) = outcome else {
            panic!("wire_parse_records panicked on {input:?} (step {step})");
        };
        if step % 8 == 0 && base == "k=v\nk2=v2" {
            assert_eq!(
                records,
                vec![
                    ("k".to_owned(), "v".to_owned()),
                    ("k2".to_owned(), "v2".to_owned())
                ],
                "the unmutated corpus keeps its documented meaning"
            );
        }
    }
}

#[test]
fn mutated_frames_answer_by_name_never_by_slicing() {
    // The frame layer faces RAW BYTES: mutations may break UTF-8 or lie about length.
    // `decode_raw_json` must answer with a typed refusal; the two classic panics here are
    // slicing by a header length the payload does not have and `str::from_utf8` on a
    // truncated boundary.
    let corpus: Vec<Vec<u8>> = vec![
        encode_raw_json("{\"k\":\"v\"}", Encoding::Json, Compression::None).payload,
        encode_raw_json("节点=值", Encoding::Json, Compression::None).payload,
        b"".to_vec(),
    ];
    let mut rng = Rng(SEED ^ 0xFACE);
    let mut refused = 0;
    for step in 0..3000 {
        let base = &corpus[rng.below(corpus.len())];
        let payload = if step % 8 == 0 {
            base.clone()
        } else {
            mutate(&mut rng, base)
        };
        // A lying header is half the attack surface: declare lengths around the truth.
        let declared = if step % 3 == 0 {
            payload.len() + rng.below(64)
        } else {
            payload.len()
        };
        let frame = EncodedFrame {
            header: caly_ipc::make_header(declared, Encoding::Json, Compression::None),
            payload,
        };
        let outcome =
            std::panic::catch_unwind(std::panic::AssertUnwindSafe(|| decode_raw_json(&frame)));
        let Ok(result) = outcome else {
            panic!("decode_raw_json panicked (step {step}, declared {declared})");
        };
        match result {
            Ok(text) => {
                // Accepted means the bytes were valid UTF-8 at the declared length.
                assert_eq!(text.len(), declared, "accepted text is the declared length");
            }
            Err(error) => {
                refused += 1;
                assert!(
                    !error.summary.trim().is_empty(),
                    "a frame refusal must say something by name"
                );
            }
        }
    }
    assert!(refused > 0, "lying headers must be refused, not guessed");
}
