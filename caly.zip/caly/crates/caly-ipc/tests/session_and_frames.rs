//! IPC framing, negotiation and session state machine.
//!
//! `caly-ipc` had no assertions at all: the framed-JSON transport, the `Hello/HelloAck` rules of
//! `docs/IPC_SESSION_MODEL.md`, and the delivery policies of `docs/IPC_STREAM_POLICY.md` were
//! only described. These tests pin them, including the failure branches a client can trigger.

use caly_api::{
    Operation, ProtocolVersion, RequestEnvelope, RequestId, ResponseEnvelope, Role, StreamId,
    SystemOp,
};
use caly_ipc::{
    classify_client_frame, classify_server_frame, decode_raw_json, encode_raw_json,
    is_control_client_frame, is_control_server_frame, make_header, negotiate_hello, stream_policy,
    validate_frame_header, Ack, AckPolicy, ClientFrame, ClientHello, ClientKind, Compression,
    DecodeErrorCode, DeliveryGuarantee, Encoding, FrameType, FrameValidationErrorCode,
    HandshakeErrorCode, NegotiationPolicy, ServerFrame, SessionMachine, SessionState,
    SessionValidationErrorCode, StreamFrame, StreamKind, StreamPayload, MAX_FRAME_SIZE_BYTES,
    SERVER_PROTOCOL_VERSION,
};

fn hello(encoding: Encoding, compression: Compression) -> ClientHello {
    ClientHello {
        protocol: ProtocolVersion { major: 1, minor: 0 },
        client_kind: ClientKind::Cli,
        client_name: "caly-cli".to_owned(),
        requested_encoding: encoding,
        requested_compression: compression,
        supported_features: vec!["job-follow".to_owned()],
        role: Role::Operator,
    }
}

fn request(protocol: ProtocolVersion) -> RequestEnvelope {
    RequestEnvelope {
        protocol,
        request_id: RequestId(1),
        trace_id: caly_api::TraceId::new("t-1"),
        deadline_ms: None,
        expected_revision: None,
        idempotency_key: None,
        role: Role::Operator,
        io_budget: None,
        operation: Operation::System(SystemOp::Status),
    }
}

fn handshake(policy: NegotiationPolicy) -> SessionMachine {
    let mut machine = SessionMachine::new(policy);
    machine
        .accept_hello(
            &hello(Encoding::Json, Compression::None),
            "session-1",
            "calyd",
            "0.1.0",
            "instance-1",
            7,
        )
        .expect("handshake");
    machine
}

// ---- framing ---------------------------------------------------------------------------

#[test]
fn frame_round_trip_preserves_the_payload() {
    let frame = encode_raw_json("{\"op\":\"status\"}", Encoding::Json, Compression::None);
    assert_eq!(frame.header.length as usize, 15);
    assert_eq!(frame.header.encoding, Encoding::Json);
    assert_eq!(
        decode_raw_json(&frame).expect("payload must decode"),
        "{\"op\":\"status\"}"
    );
}

#[test]
fn a_length_that_does_not_match_the_payload_is_rejected() {
    let mut frame = encode_raw_json("{}", Encoding::Json, Compression::None);
    frame.header.length = 99;
    let error = decode_raw_json(&frame).expect_err("declared length must be checked");
    assert_eq!(error.code, DecodeErrorCode::InvalidLength);
    assert!(
        error.summary.contains("does not match payload length"),
        "{}",
        error.summary
    );
}

#[test]
fn non_utf8_payload_is_reported_as_truncated() {
    let frame = caly_ipc::EncodedFrame {
        header: make_header(2, Encoding::Json, Compression::None),
        payload: vec![0xff, 0xfe],
    };
    let error = decode_raw_json(&frame).expect_err("invalid utf-8 must fail");
    assert_eq!(error.code, DecodeErrorCode::Truncated);
}

/// `make_header` used to cast `usize -> u32`, which silently wraps for absurd payloads and lets
/// an oversized frame pass header validation with a truncated length. Saturating keeps the
/// rejection at the right place (`FrameTooLarge`).
#[test]
fn header_length_saturates_instead_of_wrapping() {
    let huge = (1u64 << 32) as usize;
    let header = make_header(huge, Encoding::Json, Compression::None);
    assert!(
        header.length == u32::MAX || header.length as usize == huge,
        "length must not wrap to a small value: {}",
        header.length
    );

    let oversized = make_header(usize::MAX, Encoding::Json, Compression::None);
    let error = validate_frame_header(&oversized, MAX_FRAME_SIZE_BYTES, true)
        .expect_err("an oversized frame must be rejected by the header check");
    assert_eq!(error.code, FrameValidationErrorCode::FrameTooLarge);
}

#[test]
fn frame_classification_separates_control_from_stream_traffic() {
    let ack_frame = ClientFrame::StreamAck(Ack {
        stream_id: StreamId(3),
        upto_seq: 12,
    });
    assert_eq!(classify_client_frame(&ack_frame), FrameType::StreamAck);
    assert!(is_control_client_frame(&ack_frame));

    let stream_frame = ServerFrame::Stream(StreamFrame {
        stream_id: StreamId(3),
        seq: 13,
        kind: StreamKind::Logs,
        payload: StreamPayload::PatchJson("{}".to_owned()),
    });
    assert_eq!(classify_server_frame(&stream_frame), FrameType::Stream);
    assert!(
        !is_control_server_frame(&stream_frame),
        "stream data is not control traffic and may therefore be compressed"
    );

    let response = ServerFrame::Response(ResponseEnvelope {
        request_id: RequestId(1),
        trace_id: caly_api::TraceId::new("t"),
        result: Ok(caly_api::OperationResult::SystemStatus(
            caly_api::SystemStatus {
                daemon_state: "running".to_owned(),
                active_profile: None,
                active_core: None,
                state_revision: 1,
            },
        )),
    });
    assert_eq!(classify_server_frame(&response), FrameType::Response);
    assert!(is_control_server_frame(&response));
}

// ---- negotiation -----------------------------------------------------------------------

#[test]
fn json_without_compression_negotiates_cleanly() {
    let ack = negotiate_hello(
        &hello(Encoding::Json, Compression::None),
        &NegotiationPolicy::default(),
        "calyd",
        "0.1.0",
        "instance-1",
        42,
    )
    .expect("json must be accepted");
    assert_eq!(ack.protocol, SERVER_PROTOCOL_VERSION);
    assert_eq!(ack.selected_encoding, Encoding::Json);
    assert_eq!(ack.selected_compression, Compression::None);
    assert_eq!(ack.state_revision, 42);
    assert_eq!(ack.server_features, vec!["job-follow".to_owned()]);
    assert_eq!(ack.instance_id, "instance-1");
}

#[test]
fn opt_in_transports_are_honoured_only_when_policy_allows_them() {
    let policy = NegotiationPolicy {
        allow_msgpack: true,
        allow_zstd: true,
        ..NegotiationPolicy::default()
    };
    let ack = negotiate_hello(
        &hello(Encoding::MsgPack, Compression::Zstd),
        &policy,
        "calyd",
        "0.1.0",
        "i",
        1,
    )
    .expect("policy opted in");
    assert_eq!(ack.selected_encoding, Encoding::MsgPack);
    assert_eq!(ack.selected_compression, Compression::Zstd);

    let strict = NegotiationPolicy::default();
    let error = negotiate_hello(
        &hello(Encoding::MsgPack, Compression::None),
        &strict,
        "calyd",
        "0.1.0",
        "i",
        1,
    )
    .expect_err("msgpack is off by default");
    assert_eq!(error.code, HandshakeErrorCode::UnsupportedEncoding);

    let error = negotiate_hello(
        &hello(Encoding::Json, Compression::Zstd),
        &strict,
        "calyd",
        "0.1.0",
        "i",
        1,
    )
    .expect_err("zstd is off by default");
    assert_eq!(error.code, HandshakeErrorCode::UnsupportedCompression);
}

#[test]
fn protocol_major_mismatch_blocks_but_minor_mismatch_does_not() {
    // ADR-033: version lines evolve independently, so a differing minor version must not
    // break the handshake; only a major change is a hard mismatch.
    let older_minor = ClientHello {
        protocol: ProtocolVersion { major: 1, minor: 4 },
        ..hello(Encoding::Json, Compression::None)
    };
    assert!(negotiate_hello(
        &older_minor,
        &NegotiationPolicy::default(),
        "calyd",
        "0.1.0",
        "i",
        1
    )
    .is_ok());

    let different_major = ClientHello {
        protocol: ProtocolVersion { major: 2, minor: 0 },
        ..hello(Encoding::Json, Compression::None)
    };
    let error = negotiate_hello(
        &different_major,
        &NegotiationPolicy::default(),
        "calyd",
        "0.1.0",
        "i",
        1,
    )
    .expect_err("major version changes are not compatible");
    assert_eq!(error.code, HandshakeErrorCode::ProtoMismatch);
    assert!(
        error.summary.contains("client=2 server=1"),
        "{}",
        error.summary
    );
}

#[test]
fn an_anonymous_client_is_not_a_session_anyone_can_audit() {
    let blank = ClientHello {
        client_name: "   ".to_owned(),
        ..hello(Encoding::Json, Compression::None)
    };
    let error = negotiate_hello(
        &blank,
        &NegotiationPolicy::default(),
        "calyd",
        "0.1.0",
        "i",
        1,
    )
    .expect_err("client_name is required");
    assert_eq!(error.code, HandshakeErrorCode::InvalidClientName);
}

#[test]
fn transport_defaults_match_the_frozen_policy_document() {
    let policy = NegotiationPolicy::default();
    assert_eq!(policy.max_frame_size_bytes, MAX_FRAME_SIZE_BYTES);
    assert_eq!(MAX_FRAME_SIZE_BYTES, 4 * 1024 * 1024);
    assert_eq!(policy.hello_timeout_ms, caly_ipc::DEFAULT_HELLO_TIMEOUT_MS);
    assert!(!policy.allow_msgpack && !policy.allow_zstd);
}

// ---- frame validation ------------------------------------------------------------------

#[test]
fn control_frames_may_not_be_compressed_but_data_frames_may() {
    let compressed_control = make_header(64, Encoding::Json, Compression::Zstd);
    let error = validate_frame_header(&compressed_control, MAX_FRAME_SIZE_BYTES, true)
        .expect_err("control messages stay uncompressed by default");
    assert_eq!(error.code, FrameValidationErrorCode::CompressionNotAllowed);

    assert!(
        validate_frame_header(&compressed_control, MAX_FRAME_SIZE_BYTES, false).is_ok(),
        "stream data may be compressed"
    );
}

#[test]
fn the_size_limit_is_inclusive() {
    let at_limit = make_header(
        MAX_FRAME_SIZE_BYTES as usize,
        Encoding::Json,
        Compression::None,
    );
    assert!(validate_frame_header(&at_limit, MAX_FRAME_SIZE_BYTES, true).is_ok());
    let over = make_header(
        MAX_FRAME_SIZE_BYTES as usize + 1,
        Encoding::Json,
        Compression::None,
    );
    assert!(validate_frame_header(&over, MAX_FRAME_SIZE_BYTES, true).is_err());
}

// ---- session state machine -------------------------------------------------------------

#[test]
fn a_request_before_hello_is_rejected_and_after_hello_is_accepted() {
    let mut machine = SessionMachine::new(NegotiationPolicy::default());
    assert_eq!(machine.state, SessionState::AwaitingHello);

    let error = machine
        .validate_request(&request(ProtocolVersion { major: 1, minor: 0 }))
        .expect_err("hello must come first");
    assert_eq!(error.code, SessionValidationErrorCode::NotHandshaken);

    machine
        .accept_hello(
            &hello(Encoding::Json, Compression::None),
            "session-9",
            "calyd",
            "0.1.0",
            "instance-9",
            3,
        )
        .expect("handshake");
    assert_eq!(machine.state, SessionState::Active);
    assert_eq!(machine.info.as_ref().expect("info").session_id, "session-9");
    assert_eq!(machine.info.as_ref().expect("info").role, Role::Operator);
    assert_eq!(machine.info.as_ref().expect("info").state_revision, 3);
    machine
        .validate_request(&request(ProtocolVersion { major: 1, minor: 0 }))
        .expect("an active session accepts a matching protocol");
}

#[test]
fn a_second_hello_is_rejected_rather_than_resetting_the_session() {
    let mut machine = handshake(NegotiationPolicy::default());
    let error = machine
        .accept_hello(
            &hello(Encoding::Json, Compression::None),
            "session-2",
            "calyd",
            "0.1.0",
            "instance-1",
            8,
        )
        .expect_err("hello is a one-shot transition");
    assert_eq!(error.code, HandshakeErrorCode::ProtoMismatch);
    assert!(
        error.summary.contains("not awaiting hello"),
        "{}",
        error.summary
    );
    assert_eq!(machine.state, SessionState::Active);
}

#[test]
fn a_closed_session_rejects_requests() {
    let mut machine = handshake(NegotiationPolicy::default());
    machine
        .validate_request(&request(ProtocolVersion { major: 1, minor: 0 }))
        .expect("active");
    machine.close();
    assert_eq!(machine.state, SessionState::Closed);
    let error = machine
        .validate_request(&request(ProtocolVersion { major: 1, minor: 0 }))
        .expect_err("closed sessions are inert");
    assert_eq!(error.code, SessionValidationErrorCode::SessionClosed);
}

#[test]
fn a_request_from_a_different_protocol_major_is_refused_on_an_active_session() {
    let machine = handshake(NegotiationPolicy::default());
    let error = machine
        .validate_request(&request(ProtocolVersion {
            major: 99,
            minor: 0,
        }))
        .expect_err("the negotiated major version binds the session");
    assert_eq!(error.code, SessionValidationErrorCode::ProtocolMismatch);
    assert!(
        error.summary.contains("request=99 session=1"),
        "{}",
        error.summary
    );

    // The same session still accepts its own major version, and a minor difference is fine.
    assert!(machine
        .validate_request(&request(ProtocolVersion { major: 1, minor: 9 }))
        .is_ok());
}

// ---- stream policy ---------------------------------------------------------------------

#[test]
fn stream_policies_match_the_delivery_model() {
    // ADR-019 / docs/IPC_STREAM_POLICY.md: job and deployment streams are lossless and
    // ack-required; UI-ish streams trade guarantees for freshness; reset is first-class.
    let job = stream_policy(StreamKind::Job);
    assert_eq!(job.delivery, DeliveryGuarantee::LosslessResumable);
    assert_eq!(job.ack, AckPolicy::Required);
    assert!(!job.reset_on_gap, "a job stream must resume, not reset");

    let deployment = stream_policy(StreamKind::Deployment);
    assert_eq!(deployment.delivery, DeliveryGuarantee::LosslessResumable);
    assert_eq!(deployment.ack, AckPolicy::Required);

    let dashboard = stream_policy(StreamKind::Dashboard);
    assert_eq!(dashboard.delivery, DeliveryGuarantee::SnapshotThenPatch);
    assert_eq!(dashboard.ack, AckPolicy::Optional);
    assert!(
        dashboard.reset_on_gap,
        "a gapped dashboard may be re-snapshotted"
    );

    assert_eq!(
        stream_policy(StreamKind::Traffic).delivery,
        DeliveryGuarantee::LatestValue
    );
    assert_eq!(
        stream_policy(StreamKind::Logs).delivery,
        DeliveryGuarantee::LossyRing
    );
    assert_eq!(stream_policy(StreamKind::Logs).ack, AckPolicy::None);
}

#[test]
fn a_reset_is_a_payload_not_an_error() {
    let reset = StreamFrame {
        stream_id: StreamId(1),
        seq: 0,
        kind: StreamKind::Dashboard,
        payload: StreamPayload::Reset {
            reason: caly_ipc::ResetReason::StateGapTooLarge,
        },
    };
    assert!(matches!(reset.payload, StreamPayload::Reset { .. }));
    assert_eq!(reset.seq, 0, "a reset re-bases the stream sequence");
}

/// The outbound half of `MAX_FRAME_SIZE_BYTES` (`OVERLOAD` round-41): a payload at the cap is a
/// frame, one byte over is a refusal that names both numbers, and the legacy unbounded encoder
/// keeps its shape for the handshake — so the two are distinguishable, not interchangeable.
#[test]
fn outbound_frames_are_bounded_on_the_way_out_too() {
    use caly_ipc::codec::{encode_raw_json, encode_raw_json_bounded};
    use caly_ipc::frame::{Compression, Encoding};
    use caly_ipc::policy::MAX_FRAME_SIZE_BYTES;

    let cap = MAX_FRAME_SIZE_BYTES as usize;
    let at_cap = "x".repeat(cap);
    assert!(
        encode_raw_json_bounded(&at_cap, Encoding::Json, Compression::None).is_ok(),
        "exactly at the cap is a frame, not a refusal"
    );
    let over = "x".repeat(cap + 1);
    let error = encode_raw_json_bounded(&over, Encoding::Json, Compression::None)
        .expect_err("one byte over the cap must not become a frame the peer must refuse");
    assert!(
        error.summary.contains(&format!("{} bytes", cap + 1))
            && error
                .summary
                .contains(&format!("MAX_FRAME_SIZE_BYTES {cap}")),
        "the refusal must name the actual size and the cap: {}",
        error.summary
    );
    // The legacy shape is unchanged for the handshake path.
    assert_eq!(
        encode_raw_json(&over, Encoding::Json, Compression::None)
            .payload
            .len(),
        cap + 1,
        "the unbounded encoder keeps its documented shape"
    );
}
