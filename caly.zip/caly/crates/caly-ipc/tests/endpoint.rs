//! BindSpec / WireListener / WireStream / FramePump against real sockets.
//!
//! Unit tests in `endpoint.rs` cover parse refusals without opening anything.
//! This file is the production shape: TCP with port 0, UDS with chmod 0o600,
//! stale-socket unlink, refuse-to-unlink a regular file, TCP peek vs UDS
//! Indeterminate, and a dialect hello round-trip on both transports.
//!
//! Scratch names are `pid` + a counter, not `Instant::now`. The workspace bans
//! PathBuf / File / Instant / Command in production; this harness is the one
//! place those symbols are honest.

#![allow(clippy::disallowed_methods, clippy::disallowed_types)]

use std::io::{Read, Write};
use std::path::Path;
use std::sync::atomic::{AtomicU64, Ordering};
use std::time::Duration;

use caly_api::Role;
use caly_ipc::dialect::client_hello_payload;
use caly_ipc::{
    unix_socket_mode, BindSpec, BoundAddr, EndpointErrorKind, FramePump, PeerProbe, WireIo,
    WireListener, WireStream, UNIX_PATH_MAX, UNIX_SOCKET_MODE, WIRE_KIND_HELLO,
};

static SEQ: AtomicU64 = AtomicU64::new(1);

fn scratch_unix(tag: &str) -> String {
    let n = SEQ.fetch_add(1, Ordering::Relaxed);
    format!("/tmp/caly-r87-{}-{}-{tag}.sock", std::process::id(), n)
}

struct UnlinkOnDrop(String);

impl Drop for UnlinkOnDrop {
    fn drop(&mut self) {
        let _ = std::fs::remove_file(&self.0);
    }
}

fn hello_payload() -> Vec<u8> {
    client_hello_payload(Role::Admin, false)
}

/// Grammar of `--bind` / `--addr`. One test, many productions: empty, named
/// pipe, abstract UDS, unix prefixes, absolute/relative paths, TCP v4/v6,
/// missing port, bad port, NUL, overlong. A table that does not name the
/// refusal is not a parse test.
#[test]
fn bind_spec_parse_table() {
    struct Case {
        raw: &'static str,
        want: Want,
    }
    enum Want {
        Tcp(&'static str, u16),
        Unix(&'static str),
        Usage(&'static str),
        Unsupported(&'static str),
    }

    let cases = [
        Case {
            raw: "",
            want: Want::Usage("empty"),
        },
        Case {
            raw: "   ",
            want: Want::Usage("empty"),
        },
        Case {
            raw: "npipe://./pipe/caly",
            want: Want::Unsupported("named pipes"),
        },
        Case {
            raw: r"\\.\pipe\caly",
            want: Want::Unsupported("named pipes"),
        },
        Case {
            raw: "//./pipe/caly",
            want: Want::Unsupported("named pipes"),
        },
        Case {
            raw: "@caly.sock",
            want: Want::Unsupported("abstract"),
        },
        Case {
            raw: "unix:@caly.sock",
            want: Want::Unsupported("abstract"),
        },
        Case {
            raw: "unix:",
            want: Want::Usage("missing a path"),
        },
        Case {
            raw: "unix://",
            want: Want::Usage("missing a path"),
        },
        Case {
            raw: "127.0.0.1:0",
            want: Want::Tcp("127.0.0.1", 0),
        },
        Case {
            raw: "127.0.0.1:9090",
            want: Want::Tcp("127.0.0.1", 9090),
        },
        Case {
            raw: "0.0.0.0:1",
            want: Want::Tcp("0.0.0.0", 1),
        },
        Case {
            raw: "[::1]:9090",
            want: Want::Tcp("::1", 9090),
        },
        Case {
            raw: "[::]:0",
            want: Want::Tcp("::", 0),
        },
        Case {
            raw: "localhost:8080",
            want: Want::Tcp("localhost", 8080),
        },
        Case {
            raw: "localhost",
            want: Want::Usage("host:port"),
        },
        Case {
            raw: "127.0.0.1",
            want: Want::Usage("host:port"),
        },
        Case {
            raw: "127.0.0.1:65536",
            want: Want::Usage("u16"),
        },
        Case {
            raw: "127.0.0.1:-1",
            want: Want::Usage("u16"),
        },
        Case {
            raw: "127.0.0.1:port",
            want: Want::Usage("u16"),
        },
        Case {
            raw: "[::1]",
            want: Want::Usage(":port"),
        },
        Case {
            raw: "[::1:9090",
            want: Want::Usage("closing bracket"),
        },
        Case {
            raw: "unix:/tmp/caly.sock",
            want: Want::Unix("/tmp/caly.sock"),
        },
        Case {
            raw: "unix:///tmp/caly.sock",
            want: Want::Unix("/tmp/caly.sock"),
        },
        Case {
            raw: "/tmp/caly.sock",
            want: Want::Unix("/tmp/caly.sock"),
        },
        Case {
            raw: "./caly.sock",
            want: Want::Unix("./caly.sock"),
        },
        Case {
            raw: "../caly.sock",
            want: Want::Unix("../caly.sock"),
        },
        Case {
            raw: "  127.0.0.1:9  ",
            want: Want::Tcp("127.0.0.1", 9),
        },
        Case {
            raw: "  unix:/tmp/x  ",
            want: Want::Unix("/tmp/x"),
        },
        Case {
            raw: "unix:/tmp/ca\0ly",
            want: Want::Usage("NUL"),
        },
    ];

    for case in cases {
        match (BindSpec::parse(case.raw), case.want) {
            (Ok(BindSpec::Tcp { host, port }), Want::Tcp(want_host, want_port)) => {
                assert_eq!(host, want_host, "tcp host for {:?}", case.raw);
                assert_eq!(port, want_port, "tcp port for {:?}", case.raw);
            }
            (Ok(BindSpec::Unix { path }), Want::Unix(want_path)) => {
                assert_eq!(path, want_path, "unix path for {:?}", case.raw);
            }
            (Err(error), Want::Usage(needle)) => {
                assert_eq!(
                    error.kind,
                    EndpointErrorKind::Usage,
                    "{:?}: {}",
                    case.raw,
                    error.summary
                );
                assert!(
                    error.summary.contains(needle),
                    "{:?} should mention {needle:?}: {}",
                    case.raw,
                    error.summary
                );
            }
            (Err(error), Want::Unsupported(needle)) => {
                assert_eq!(
                    error.kind,
                    EndpointErrorKind::Unsupported,
                    "{:?}: {}",
                    case.raw,
                    error.summary
                );
                assert!(
                    error.summary.contains(needle),
                    "{:?} should mention {needle:?}: {}",
                    case.raw,
                    error.summary
                );
            }
            (other, _) => panic!("parse({:?}) = {other:?}", case.raw),
        }
    }

    let long = format!("unix:/{}", "a".repeat(UNIX_PATH_MAX));
    let error = BindSpec::parse(&long).expect_err("overlong");
    assert_eq!(error.kind, EndpointErrorKind::Usage);
    assert!(error.summary.contains("sun_path"), "{}", error.summary);
}

#[test]
fn tcp_ephemeral_bind_advertises_a_bare_u16() {
    let spec = BindSpec::parse("127.0.0.1:0").expect("spec");
    let (listener, bound) = WireListener::bind(&spec).expect("bind");
    match &bound {
        BoundAddr::Tcp { host, port } => {
            assert_eq!(host, "127.0.0.1");
            assert_ne!(*port, 0, "kernel must pick a real port");
            assert_eq!(bound.port_file_text(), port.to_string());
            assert!(
                bound.port_file_text().chars().all(|ch| ch.is_ascii_digit()),
                "TCP port-file must stay a bare u16: {}",
                bound.port_file_text()
            );
        }
        other => panic!("tcp bind advertised {other:?}"),
    }
    assert_eq!(listener.transport_kind(), "tcp");
}

#[test]
fn tcp_connect_and_hello_round_trip() {
    let spec = BindSpec::parse("127.0.0.1:0").expect("spec");
    let (listener, bound) = WireListener::bind(&spec).expect("bind");
    let port = bound.tcp_port().expect("tcp");
    let server = std::thread::spawn(move || {
        let stream = listener.accept().expect("accept");
        let mut pump = FramePump::new(stream, None).expect("pump");
        let (kind, payload) = pump.recv().expect("recv").expect("hello frame");
        assert_eq!(kind, WIRE_KIND_HELLO);
        assert_eq!(payload, hello_payload());
        pump.send(2, b"daemon_name=calyd").expect("ack");
        pump.into_inner()
    });

    let client_spec = BindSpec::parse(&format!("127.0.0.1:{port}")).expect("client spec");
    let stream = WireStream::connect(&client_spec, Duration::from_secs(2)).expect("connect");
    let mut pump = FramePump::new(stream, Some(Duration::from_secs(2))).expect("pump");
    assert_eq!(pump.transport_kind(), "tcp");
    pump.send(WIRE_KIND_HELLO, &hello_payload()).expect("hello");
    let (kind, payload) = pump.recv().expect("ack").expect("ack frame");
    assert_eq!(kind, 2);
    assert_eq!(payload, b"daemon_name=calyd");
    let _ = server.join().expect("server");
}

#[cfg(unix)]
#[test]
fn unix_bind_chmods_600_and_advertises_unix_prefix() {
    let path = scratch_unix("chmod");
    let _guard = UnlinkOnDrop(path.clone());
    let spec = BindSpec::parse(&format!("unix:{path}")).expect("spec");
    let (listener, bound) = WireListener::bind(&spec).expect("bind");
    assert_eq!(listener.transport_kind(), "unix");
    assert_eq!(bound.port_file_text(), format!("unix:{path}"));
    assert_eq!(bound.tcp_port(), None);
    let mode = unix_socket_mode(&path)
        .expect("stat")
        .expect("socket exists");
    assert_eq!(
        mode, UNIX_SOCKET_MODE,
        "a world-readable socket is how RFC-0010 §14 UDS permissions fails"
    );
}

#[cfg(unix)]
#[test]
fn unix_bind_unlinks_a_stale_socket_and_refuses_a_regular_file() {
    let path = scratch_unix("stale");
    let _guard = UnlinkOnDrop(path.clone());
    let spec = BindSpec::parse(&format!("unix:{path}")).expect("spec");
    let (first, _) = WireListener::bind(&spec).expect("first bind");
    drop(first);
    assert!(
        Path::new(&path).exists(),
        "dropping the listener must leave the inode for the next bind to see"
    );
    let (_second, bound) = WireListener::bind(&spec).expect("rebind after stale unlink");
    assert_eq!(bound.port_file_text(), format!("unix:{path}"));

    let file_path = scratch_unix("regular");
    let _file_guard = UnlinkOnDrop(file_path.clone());
    std::fs::write(&file_path, b"not a socket").expect("regular file");
    let file_spec = BindSpec::parse(&format!("unix:{file_path}")).expect("spec");
    let error = match WireListener::bind(&file_spec) {
        Err(error) => error,
        Ok(_) => panic!("must not unlink a regular file"),
    };
    assert_eq!(error.kind, EndpointErrorKind::Usage);
    assert!(
        error.summary.contains("not a socket") && error.summary.contains("refusing to unlink"),
        "{}",
        error.summary
    );
    let leftover = std::fs::read(&file_path).expect("file still there");
    assert_eq!(leftover, b"not a socket");
}

#[cfg(unix)]
#[test]
fn unix_bind_refuses_a_directory() {
    let path = format!(
        "/tmp/caly-r87-{}-{}-dir",
        std::process::id(),
        SEQ.fetch_add(1, Ordering::Relaxed)
    );
    std::fs::create_dir_all(&path).expect("dir");
    let spec = BindSpec::parse(&format!("unix:{path}")).expect("spec");
    let error = match WireListener::bind(&spec) {
        Err(error) => error,
        Ok(_) => panic!("directory"),
    };
    let _ = std::fs::remove_dir_all(&path);
    assert_eq!(error.kind, EndpointErrorKind::Usage);
    assert!(error.summary.contains("directory"), "{}", error.summary);
}

#[cfg(unix)]
#[test]
fn unix_connect_and_hello_round_trip() {
    let path = scratch_unix("hello");
    let _guard = UnlinkOnDrop(path.clone());
    let spec = BindSpec::parse(&format!("unix:{path}")).expect("spec");
    let (listener, _) = WireListener::bind(&spec).expect("bind");
    let server = std::thread::spawn(move || {
        let stream = listener.accept().expect("accept");
        let mut pump = FramePump::new(stream, None).expect("pump");
        let (kind, payload) = pump.recv().expect("recv").expect("hello");
        assert_eq!(kind, WIRE_KIND_HELLO);
        assert_eq!(payload, hello_payload());
        pump.send(2, b"daemon_name=calyd").expect("ack");
    });
    let stream = WireStream::connect(&spec, Duration::from_secs(2)).expect("connect");
    let mut pump = FramePump::new(stream, Some(Duration::from_secs(2))).expect("pump");
    assert_eq!(pump.transport_kind(), "unix");
    assert_eq!(
        pump.probe().expect("probe"),
        PeerProbe::Indeterminate,
        "UnixStream has no std peek; honesty is Indeterminate"
    );
    pump.send(WIRE_KIND_HELLO, &hello_payload()).expect("hello");
    let (kind, payload) = pump.recv().expect("ack").expect("ack frame");
    assert_eq!(kind, 2);
    assert_eq!(payload, b"daemon_name=calyd");
    server.join().expect("server");
}

#[test]
fn tcp_probe_reports_closed_after_the_peer_drops() {
    let spec = BindSpec::parse("127.0.0.1:0").expect("spec");
    let (listener, bound) = WireListener::bind(&spec).expect("bind");
    let port = bound.tcp_port().expect("port");
    let server = std::thread::spawn(move || listener.accept().expect("accept"));
    let client = WireStream::connect(
        &BindSpec::parse(&format!("127.0.0.1:{port}")).expect("spec"),
        Duration::from_secs(2),
    )
    .expect("connect");
    let accepted = server.join().expect("accepted");
    drop(client);
    // The next peek should see EOF. A short timeout keeps a slow stack from hanging.
    let _ = accepted.set_read_timeout(Some(Duration::from_millis(500)));
    let probe = accepted.probe_peer().expect("probe");
    assert_eq!(
        probe,
        PeerProbe::Closed,
        "TCP peek of a dropped peer is Closed, not Indeterminate"
    );
}

#[cfg(unix)]
#[test]
fn unix_probe_stays_indeterminate_after_the_peer_drops() {
    let path = scratch_unix("probe");
    let _guard = UnlinkOnDrop(path.clone());
    let spec = BindSpec::parse(&format!("unix:{path}")).expect("spec");
    let (listener, _) = WireListener::bind(&spec).expect("bind");
    let server = std::thread::spawn(move || listener.accept().expect("accept"));
    let client = WireStream::connect(&spec, Duration::from_secs(2)).expect("connect");
    let accepted = server.join().expect("accepted");
    drop(client);
    let probe = accepted.probe_peer().expect("probe");
    assert_eq!(
        probe,
        PeerProbe::Indeterminate,
        "UDS must not invent Closed without a peek; libc/nix is an ADR"
    );
}

#[cfg(unix)]
#[test]
fn client_loop_handshake_over_a_unix_pair() {
    use caly_ipc::client::ClientSessionState;
    use caly_ipc::dialect::server_hello_ack_records;
    use caly_ipc::drive_client_hello;
    use caly_ipc::wire::{wire_records_payload, WIRE_KIND_HELLO_ACK};
    use std::os::unix::net::UnixStream;

    let (client, mut server) = UnixStream::pair().expect("pair");
    let server_thread = std::thread::spawn(move || {
        let mut head = [0u8; 5];
        server.read_exact(&mut head).expect("hello head");
        assert_eq!(head[0], WIRE_KIND_HELLO);
        let len = u32::from_be_bytes([head[1], head[2], head[3], head[4]]) as usize;
        let mut payload = vec![0u8; len];
        server.read_exact(&mut payload).expect("hello body");
        assert_eq!(payload, hello_payload());
        let ack = wire_records_payload(&server_hello_ack_records(
            "calyd",
            "0.0-test",
            "pair-inst",
            false,
        ));
        let mut frame = vec![WIRE_KIND_HELLO_ACK];
        frame.extend_from_slice(&(ack.len() as u32).to_be_bytes());
        frame.extend_from_slice(&ack);
        server.write_all(&frame).expect("ack");
    });

    let mut stream = WireStream::from_unix(client);
    let mut pump = FramePump::new(&mut stream, Some(Duration::from_secs(2))).expect("pump");
    let driven = drive_client_hello(&mut pump, false, caly_api::Role::Admin).expect("handshake");
    assert_eq!(driven.client.snapshot().state, ClientSessionState::Active);
    assert_eq!(driven.ack.instance_id, "pair-inst");
    assert_eq!(driven.client.snapshot().next_request_id, 1);
    server_thread.join().expect("server");
}
