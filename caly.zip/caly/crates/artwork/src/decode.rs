//! FFmpeg-based artwork extraction & scaling.
use ffmpeg_next::ffi as ff;
use std::ffi::c_int;
use std::path::Path;
use std::ptr;

const AVERROR_EAGAIN: c_int = -11;
const AVERROR_EOF: c_int = -541478725;
pub const MAX_DIM: u32 = 256;

pub struct RgbaImage {
    pub width: u32,
    pub height: u32,
    pub rgba: Vec<u8>,
}

pub fn first_frame_rgba(path: &Path) -> Option<RgbaImage> {
    let c_path = std::ffi::CString::new(path.to_string_lossy().as_bytes()).ok()?;
    let mut fmt: *mut ff::AVFormatContext = ptr::null_mut();
    let ret =
        unsafe { ff::avformat_open_input(&mut fmt, c_path.as_ptr(), ptr::null(), ptr::null_mut()) };
    if ret < 0 || fmt.is_null() {
        return None;
    }
    let mut fmt_guard = Fmt(fmt);
    unsafe {
        if ff::avformat_find_stream_info(fmt_guard.0, ptr::null_mut()) < 0 {
            return None;
        }
    }
    let n = unsafe { (*fmt_guard.0).nb_streams as usize };
    let mut video_idx: Option<usize> = None;
    for i in 0..n {
        let st = unsafe { &**(*fmt_guard.0).streams.add(i) };
        let par = st.codecpar;
        if par.is_null() {
            continue;
        }
        if unsafe { (*par).codec_type } != ff::AVMediaType::AVMEDIA_TYPE_VIDEO {
            continue;
        }
        if st.disposition & ff::AV_DISPOSITION_ATTACHED_PIC != 0 {
            return decode_stream(&mut fmt_guard, i);
        }
        if video_idx.is_none() {
            video_idx = Some(i);
        }
    }
    decode_stream(&mut fmt_guard, video_idx?)
}

fn decode_stream(fmt_guard: &mut Fmt, idx: usize) -> Option<RgbaImage> {
    let codecpar = unsafe { &*(**(*fmt_guard.0).streams.add(idx)).codecpar };
    let codec = unsafe { ff::avcodec_find_decoder(codecpar.codec_id) };
    if codec.is_null() {
        return None;
    }
    let dec: *mut ff::AVCodecContext = unsafe { ff::avcodec_alloc_context3(codec) };
    if dec.is_null() {
        return None;
    }
    let dec_guard = Codec(dec);
    unsafe {
        if ff::avcodec_parameters_to_context(dec_guard.0, codecpar) < 0 {
            return None;
        }
        if ff::avcodec_open2(dec_guard.0, codec, ptr::null_mut()) < 0 {
            return None;
        }
    }
    let pkt_guard = Packet(unsafe { ff::av_packet_alloc() });
    if pkt_guard.0.is_null() {
        return None;
    }
    let frame_guard = Frame(unsafe { ff::av_frame_alloc() });
    if frame_guard.0.is_null() {
        return None;
    }
    let mut got = false;

    // Fast-path: for AV_DISPOSITION_ATTACHED_PIC streams, libavformat stores
    // the picture packet directly in `st.attached_pic` during find_stream_info.
    // Calling `av_read_frame` on such files would otherwise demux audio packets
    // or fail to yield the picture packet.
    let st = unsafe { &**(*fmt_guard.0).streams.add(idx) };
    if st.disposition & ff::AV_DISPOSITION_ATTACHED_PIC != 0 && st.attached_pic.size > 0 {
        unsafe {
            let sr = ff::avcodec_send_packet(dec_guard.0, &st.attached_pic);
            if sr >= 0 {
                let rr = ff::avcodec_receive_frame(dec_guard.0, frame_guard.0);
                if rr >= 0 && !(*frame_guard.0).data[0].is_null() {
                    got = true;
                }
            }
        }
    }

    if !got {
        loop {
            let ret = unsafe { ff::av_read_frame(fmt_guard.0, pkt_guard.0) };
        if ret < 0 {
            break;
        }
        let stream_index = unsafe { (*pkt_guard.0).stream_index as usize };
        if stream_index != idx {
            unsafe { ff::av_packet_unref(pkt_guard.0) };
            continue;
        }
        unsafe {
            let sr = ff::avcodec_send_packet(dec_guard.0, pkt_guard.0);
            ff::av_packet_unref(pkt_guard.0);
            if sr < 0 {
                break;
            }
            loop {
                let rr = ff::avcodec_receive_frame(dec_guard.0, frame_guard.0);
                if rr == AVERROR_EAGAIN || rr == AVERROR_EOF {
                    break;
                }
                if rr < 0 {
                    return None;
                }
                if (*frame_guard.0).data[0].is_null() {
                    ff::av_frame_unref(frame_guard.0);
                    continue;
                }
                got = true;
                break;
            }
        }
        if got {
            break;
        }
    }
    } // end of if !got around loop

    if !got {
        unsafe {
            let _ = ff::avcodec_send_packet(dec_guard.0, ptr::null());
            let rr = ff::avcodec_receive_frame(dec_guard.0, frame_guard.0);
            if rr >= 0 && !(*frame_guard.0).data[0].is_null() {
                got = true;
            }
        }
    }
    if !got {
        return None;
    }
    let (sw, sh) = unsafe {
        (
            (*frame_guard.0).width.max(1) as u32,
            (*frame_guard.0).height.max(1) as u32,
        )
    };
    let scale = (MAX_DIM as f64 / sw as f64)
        .min(MAX_DIM as f64 / sh as f64)
        .min(1.0);
    let (dw, dh) = (
        ((sw as f64 * scale).round() as u32).max(1),
        ((sh as f64 * scale).round() as u32).max(1),
    );
    let pix_fmt = pix_fmt_from(unsafe { (*frame_guard.0).format })?;
    let sws = unsafe {
        ff::sws_getContext(
            sw as c_int,
            sh as c_int,
            pix_fmt,
            dw as c_int,
            dh as c_int,
            ff::AVPixelFormat::AV_PIX_FMT_RGBA,
            ff::SWS_BILINEAR,
            ptr::null_mut(),
            ptr::null_mut(),
            ptr::null_mut(),
        )
    };
    if sws.is_null() {
        return None;
    }
    let mut rgba = vec![0u8; (dw * dh * 4) as usize];
    unsafe {
        let dst_ptr = rgba.as_mut_ptr();
        let dst_stride = (dw * 4) as c_int;
        let r = ff::sws_scale(
            sws,
            (*frame_guard.0).data.as_ptr().cast::<*const u8>(),
            (*frame_guard.0).linesize.as_ptr(),
            0,
            sh as c_int,
            &dst_ptr,
            &dst_stride,
        );
        ff::sws_freeContext(sws);
        if r < dh as c_int {
            return None;
        }
    }
    Some(RgbaImage {
        width: dw,
        height: dh,
        rgba,
    })
}

fn pix_fmt_from(v: c_int) -> Option<ff::AVPixelFormat> {
    use ff::AVPixelFormat as P;
    Some(match v {
        0 => P::AV_PIX_FMT_YUV420P,
        1 => P::AV_PIX_FMT_YUYV422,
        2 => P::AV_PIX_FMT_RGB24,
        3 => P::AV_PIX_FMT_BGR24,
        4 => P::AV_PIX_FMT_YUV422P,
        5 => P::AV_PIX_FMT_YUV444P,
        6 => P::AV_PIX_FMT_YUV410P,
        7 => P::AV_PIX_FMT_YUV411P,
        8 => P::AV_PIX_FMT_GRAY8,
        11 => P::AV_PIX_FMT_GRAY16LE,
        12 => P::AV_PIX_FMT_YUVJ420P,
        13 => P::AV_PIX_FMT_YUVJ422P,
        14 => P::AV_PIX_FMT_YUVJ444P,
        16 => P::AV_PIX_FMT_YUVA420P,
        17 => P::AV_PIX_FMT_YUVA422P,
        18 => P::AV_PIX_FMT_YUVA444P,
        19 => P::AV_PIX_FMT_RGB565BE,
        20 => P::AV_PIX_FMT_RGB565LE,
        21 => P::AV_PIX_FMT_RGB555BE,
        22 => P::AV_PIX_FMT_RGB555LE,
        24 => P::AV_PIX_FMT_BGR565LE,
        26 => P::AV_PIX_FMT_RGBA,
        27 => P::AV_PIX_FMT_BGRA,
        28 => P::AV_PIX_FMT_ARGB,
        29 => P::AV_PIX_FMT_ABGR,
        _ => return None,
    })
}

struct Fmt(*mut ff::AVFormatContext);
impl Drop for Fmt {
    fn drop(&mut self) {
        unsafe { ff::avformat_close_input(&mut self.0) };
    }
}

struct Codec(*mut ff::AVCodecContext);
impl Drop for Codec {
    fn drop(&mut self) {
        unsafe { ff::avcodec_free_context(&mut self.0) };
    }
}

struct Frame(*mut ff::AVFrame);
impl Drop for Frame {
    fn drop(&mut self) {
        unsafe { ff::av_frame_free(&mut self.0) };
    }
}

struct Packet(*mut ff::AVPacket);
impl Drop for Packet {
    fn drop(&mut self) {
        if !self.0.is_null() {
            unsafe {
                ff::av_packet_unref(self.0);
                ff::av_packet_free(&mut self.0);
            }
        }
    }
}
