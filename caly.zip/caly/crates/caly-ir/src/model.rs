use std::collections::BTreeMap;

use crate::digest::{ArtifactDigest, Digest, SemanticDigest, StableBytes};
use crate::ids::{
    ExtensionKey, GroupId, InboundId, NodeId, OutboundId, ProfileId, RevisionId, RuleId, RuleSetId,
    SourceId,
};

#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub enum CoreTarget {
    Mihomo,
    SingBox,
    Auto,
}

#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub enum RoutingMode {
    Rule,
    Global,
    Direct,
}

#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub enum SourceKind {
    Subscription,
    LocalFile,
    Inline,
}

#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub enum ProxyProtocol {
    Shadowsocks,
    Vmess,
    Vless,
    Trojan,
    Hysteria2,
    Tuic,
    WireGuard,
    Unknown,
}

#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub enum GroupType {
    Select,
    UrlTest,
    Fallback,
    LoadBalance,
    Relay,
}

#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub enum RuleAction {
    UseGroup,
    Direct,
    Reject,
    UseOutbound,
}

#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub enum DnsMode {
    System,
    FakeIp,
    Redirect,
    Mixed,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct RawSource {
    pub id: SourceId,
    pub kind: SourceKind,
    pub origin_label: String,
    pub content_digest: Digest,
    pub bytes_len: u64,
    pub media_type: Option<String>,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct NormalizedSource {
    pub id: SourceId,
    pub raw_digest: Digest,
    pub source_kind: SourceKind,
    pub node_count_estimate: usize,
    pub group_count_estimate: usize,
    pub rule_count_estimate: usize,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct ProxyNode {
    pub id: NodeId,
    pub label: String,
    pub protocol: ProxyProtocol,
    pub server: String,
    pub port: u16,
    pub extensions: BTreeMap<ExtensionKey, String>,
    pub passthrough: BTreeMap<String, String>,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct ProxyGroup {
    pub id: GroupId,
    pub label: String,
    pub kind: GroupType,
    pub members: Vec<NodeId>,
    pub selected: Option<NodeId>,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct RouteRule {
    pub id: RuleId,
    pub label: String,
    pub matcher: String,
    pub action: RuleAction,
    pub target_group: Option<GroupId>,
    pub target_outbound: Option<OutboundId>,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct RuleSetRef {
    pub id: RuleSetId,
    pub label: String,
    pub digest: Digest,
    pub source: Option<SourceId>,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct DnsPolicy {
    pub mode: DnsMode,
    pub servers: Vec<String>,
    pub fake_ip_filter: Vec<String>,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct TunPolicy {
    pub enabled: bool,
    pub auto_route: bool,
    pub strict_route: bool,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct Inbound {
    pub id: InboundId,
    pub label: String,
    pub listen: String,
    pub port: u16,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct Outbound {
    pub id: OutboundId,
    pub label: String,
    pub proxy_group: Option<GroupId>,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct CalyIr {
    pub profile_id: ProfileId,
    pub source_ids: Vec<SourceId>,
    pub core_target: CoreTarget,
    pub routing_mode: RoutingMode,
    pub nodes: Vec<ProxyNode>,
    pub groups: Vec<ProxyGroup>,
    pub rules: Vec<RouteRule>,
    pub rulesets: Vec<RuleSetRef>,
    pub dns: Option<DnsPolicy>,
    pub tun: Option<TunPolicy>,
    pub inbounds: Vec<Inbound>,
    pub outbounds: Vec<Outbound>,
    pub extensions: BTreeMap<ExtensionKey, String>,
    pub passthrough: BTreeMap<String, String>,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct ResolvedProfile {
    pub profile_id: ProfileId,
    pub revision_id: RevisionId,
    pub semantic_digest: SemanticDigest,
    pub core_target: CoreTarget,
    pub routing_mode: RoutingMode,
    pub nodes: Vec<ProxyNode>,
    pub groups: Vec<ProxyGroup>,
    pub rules: Vec<RouteRule>,
    pub rulesets: Vec<RuleSetRef>,
    pub dns: Option<DnsPolicy>,
    pub tun: Option<TunPolicy>,
    pub inbounds: Vec<Inbound>,
    pub outbounds: Vec<Outbound>,
    pub generated_bytes: Option<StableBytes>,
}

#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub enum NativeConfigFormat {
    Yaml,
    Json,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct CompiledArtifact {
    pub profile_id: ProfileId,
    pub target_core: CoreTarget,
    pub adapter_version: u32,
    pub artifact_digest: ArtifactDigest,
    pub file_name_hint: String,
    pub format: NativeConfigFormat,
    pub entrypoint: String,
    pub media_type: String,
    pub bytes: StableBytes,
    pub annotations: BTreeMap<String, String>,
}

impl CompiledArtifact {
    pub fn size_bytes(&self) -> usize {
        self.bytes.len()
    }
}
