use std::collections::BTreeMap;

use crate::digest::{ArtifactDigest, Digest, SemanticDigest, StableBytes};
use crate::ids::{
    ExtensionKey, GroupId, InboundId, NodeId, OutboundId, ProfileId, RevisionId, RuleId, RuleSetId,
    SourceId,
};
use crate::model::{
    CalyIr, CompiledArtifact, CoreTarget, DnsMode, DnsPolicy, GroupType, Inbound, Outbound,
    ProxyGroup, ProxyNode, ProxyProtocol, ResolvedProfile, RouteRule, RoutingMode, RuleAction,
    RuleSetRef, TunPolicy,
};

pub fn normalized_source_stub(
    id: impl Into<String>,
    _label: impl Into<String>,
) -> crate::model::NormalizedSource {
    let id = SourceId::new(id);
    crate::model::NormalizedSource {
        id: id.clone(),
        raw_digest: Digest(format!("raw:{}", id.0)),
        source_kind: crate::model::SourceKind::Subscription,
        node_count_estimate: 1,
        group_count_estimate: 1,
        rule_count_estimate: 1,
    }
}

pub fn proxy_node_stub(
    id: impl Into<String>,
    label: impl Into<String>,
    protocol: ProxyProtocol,
) -> ProxyNode {
    let id = NodeId::new(id);
    ProxyNode {
        id,
        label: label.into(),
        protocol,
        server: "127.0.0.1".to_owned(),
        port: 1080,
        extensions: BTreeMap::<ExtensionKey, String>::new(),
        passthrough: BTreeMap::<String, String>::new(),
    }
}

pub fn proxy_group_stub(
    id: impl Into<String>,
    label: impl Into<String>,
    members: Vec<NodeId>,
) -> ProxyGroup {
    ProxyGroup {
        id: GroupId::new(id),
        label: label.into(),
        kind: GroupType::Select,
        members,
        selected: None,
    }
}

pub fn rule_stub(
    id: impl Into<String>,
    label: impl Into<String>,
    target_group: Option<GroupId>,
) -> RouteRule {
    RouteRule {
        id: RuleId::new(id),
        label: label.into(),
        matcher: "MATCH".to_owned(),
        action: RuleAction::UseGroup,
        target_group,
        target_outbound: None,
    }
}

pub fn ruleset_stub(id: impl Into<String>, label: impl Into<String>) -> RuleSetRef {
    let id = RuleSetId::new(id);
    RuleSetRef {
        id: id.clone(),
        label: label.into(),
        digest: Digest(format!("ruleset:{}", id.0)),
        source: None,
    }
}

pub fn dns_policy_stub() -> DnsPolicy {
    DnsPolicy {
        mode: DnsMode::FakeIp,
        servers: vec!["https://dns.example/dns-query".to_owned()],
        fake_ip_filter: vec!["*.lan".to_owned()],
    }
}

pub fn tun_policy_stub() -> TunPolicy {
    TunPolicy {
        enabled: false,
        auto_route: false,
        strict_route: false,
    }
}

pub fn inbound_stub(id: impl Into<String>, label: impl Into<String>, port: u16) -> Inbound {
    Inbound {
        id: InboundId::new(id),
        label: label.into(),
        listen: "127.0.0.1".to_owned(),
        port,
    }
}

pub fn outbound_stub(
    id: impl Into<String>,
    label: impl Into<String>,
    group: Option<GroupId>,
) -> Outbound {
    Outbound {
        id: OutboundId::new(id),
        label: label.into(),
        proxy_group: group,
    }
}

pub fn caly_ir_stub(
    profile_id: impl Into<String>,
    source_ids: Vec<SourceId>,
    core_target: CoreTarget,
) -> CalyIr {
    let node = proxy_node_stub("node-01", "Node 01", ProxyProtocol::Shadowsocks);
    let group = proxy_group_stub("group-01", "Proxy", vec![node.id.clone()]);
    let rule = rule_stub("rule-01", "Match All", Some(group.id.clone()));
    let ruleset = ruleset_stub("ruleset-01", "Default RuleSet");

    CalyIr {
        profile_id: ProfileId::new(profile_id),
        source_ids,
        core_target,
        routing_mode: RoutingMode::Rule,
        nodes: vec![node],
        groups: vec![group.clone()],
        rules: vec![rule],
        rulesets: vec![ruleset],
        dns: Some(dns_policy_stub()),
        tun: Some(tun_policy_stub()),
        inbounds: vec![inbound_stub("inbound-01", "mixed", 7890)],
        outbounds: vec![outbound_stub("outbound-01", "proxy", Some(group.id))],
        extensions: BTreeMap::new(),
        passthrough: BTreeMap::new(),
    }
}

pub fn resolved_profile_stub(
    profile_id: impl Into<String>,
    core_target: CoreTarget,
) -> ResolvedProfile {
    let profile_id = ProfileId::new(profile_id);
    let ir = caly_ir_stub(
        profile_id.0.clone(),
        vec![SourceId::new("source-01")],
        core_target,
    );
    ResolvedProfile {
        profile_id,
        revision_id: RevisionId::new("rev-01"),
        semantic_digest: SemanticDigest("semantic:stub".to_owned()),
        core_target: ir.core_target,
        routing_mode: ir.routing_mode,
        nodes: ir.nodes,
        groups: ir.groups,
        rules: ir.rules,
        rulesets: ir.rulesets,
        dns: ir.dns,
        tun: ir.tun,
        inbounds: ir.inbounds,
        outbounds: ir.outbounds,
        generated_bytes: None,
    }
}

pub fn compiled_artifact_stub(
    profile_id: impl Into<String>,
    core_target: CoreTarget,
) -> CompiledArtifact {
    let profile_id = ProfileId::new(profile_id);
    CompiledArtifact {
        profile_id,
        target_core: core_target,
        adapter_version: 1,
        artifact_digest: ArtifactDigest("artifact:stub".to_owned()),
        file_name_hint: "config.stub".to_owned(),
        format: crate::model::NativeConfigFormat::Yaml,
        entrypoint: "config.stub".to_owned(),
        media_type: "application/x-yaml".to_owned(),
        bytes: StableBytes::new(b"mode: rule\nproxies: []\n".to_vec()),
        annotations: BTreeMap::new(),
    }
}
