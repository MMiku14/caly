use caly_common::Actor;
use caly_daemon::{DaemonBootstrapConfig, ServerLoop, ServerLoopConfig, ServerLoopStep};
use caly_ipc::{make_header, ClientFrame, Compression, Encoding, SessionCloseReason};

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct WireProbeReport {
    pub session_id: String,
    pub hello_payload_len: usize,
    pub response_frame_count: usize,
    pub stream_frame_count: usize,
    pub daemon_lifecycle: String,
}

pub fn run_basic_wire_probe() -> Result<WireProbeReport, String> {
    let mut server = ServerLoop::new(ServerLoopConfig {
        actor: Actor::Cli,
        daemon: DaemonBootstrapConfig {
            instance_id: "wire-probe-daemon".to_owned(),
            protocol_version: caly_api::ProtocolVersion { major: 1, minor: 0 },
            recover_on_start: false,
        },
        negotiation: caly_ipc::NegotiationPolicy::default(),
        hello_timeout_ms: 5_000,
    });

    let session_id = server.open_session("wire-probe-session");
    let hello = server.handshake(&session_id, "wire-probe-client")?;
    let hello_payload_len = match hello {
        ServerLoopStep::HelloAck(frame) => frame.payload.len(),
        other => return Err(format!("unexpected hello step: {:?}", other)),
    };

    let frame = ClientFrame::Request(caly_api::RequestEnvelope {
        protocol: caly_api::ProtocolVersion { major: 1, minor: 0 },
        request_id: caly_api::RequestId(1),
        trace_id: caly_api::TraceId::new("wire-probe"),
        deadline_ms: Some(30_000),
        expected_revision: None,
        idempotency_key: None,
        role: caly_api::Role::Admin,
        io_budget: None,
        operation: caly_api::Operation::System(caly_api::SystemOp::Status),
    });

    let response = server.send_client_frame(&session_id, frame)?;
    let response_frame_count = match response {
        ServerLoopStep::ResponseFrames(frames) => frames.len(),
        other => return Err(format!("unexpected response step: {:?}", other)),
    };

    let _ = server.close_session(&session_id, SessionCloseReason::ClientClosed)?;
    let snapshot = server.inspect();

    Ok(WireProbeReport {
        session_id,
        hello_payload_len,
        response_frame_count,
        stream_frame_count: 0,
        daemon_lifecycle: snapshot.daemon_lifecycle,
    })
}

pub fn encode_probe_header(payload_len: usize) -> caly_ipc::FrameHeader {
    make_header(payload_len, Encoding::Json, Compression::None)
}
