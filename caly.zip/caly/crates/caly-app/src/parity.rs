use caly_api::{
    default_ctx, ApplyRequest, AutomationJobView, CalyFacade, CapabilityQuery, CapabilityReport,
    ConnectionPage, ConnectionQuery, Ctx, DeploymentPlanView, JobFollowRequest, JobFollowView,
    PageRequest, PipelineExplain, PipelineExplainRequest, ProfileId, RecoveryStatusView,
    RuntimeStatus, ServerInfo, SystemStatus,
};
use caly_common::Actor;

#[derive(Clone, Debug, Eq, PartialEq)]
pub enum ParityStatus {
    Match,
    Mismatch,
    Missing,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct ParityItem {
    pub name: String,
    pub status: ParityStatus,
    pub detail: String,
}

#[derive(Clone, Debug, Default, Eq, PartialEq)]
pub struct ParityReport {
    pub items: Vec<ParityItem>,
}

impl ParityReport {
    pub fn push(
        &mut self,
        name: impl Into<String>,
        status: ParityStatus,
        detail: impl Into<String>,
    ) {
        self.items.push(ParityItem {
            name: name.into(),
            status,
            detail: detail.into(),
        });
    }

    pub fn all_match(&self) -> bool {
        self.items
            .iter()
            .all(|item| matches!(item.status, ParityStatus::Match))
    }
}

pub fn compare_system_status(local: &SystemStatus, remote: &SystemStatus) -> ParityItem {
    compare_value(
        "system.status",
        local,
        remote,
        "local and remote system status match",
    )
}

pub fn compare_server_info(local: &ServerInfo, remote: &ServerInfo) -> ParityItem {
    compare_value(
        "system.info",
        local,
        remote,
        "local and remote server info match",
    )
}

pub fn compare_runtime_status(local: &RuntimeStatus, remote: &RuntimeStatus) -> ParityItem {
    compare_value(
        "runtime.status",
        local,
        remote,
        "local and remote runtime status match",
    )
}

pub fn compare_connection_page(local: &ConnectionPage, remote: &ConnectionPage) -> ParityItem {
    compare_value(
        "runtime.connections",
        local,
        remote,
        "local and remote runtime connection pages match",
    )
}

pub fn compare_job_follow(local: &JobFollowView, remote: &JobFollowView) -> ParityItem {
    compare_value(
        "diagnostics.follow_job",
        local,
        remote,
        "local and remote job follow views match",
    )
}

pub fn compare_profile_list(
    local: &[caly_api::ProfileSummary],
    remote: &[caly_api::ProfileSummary],
) -> ParityItem {
    compare_value(
        "profile.list",
        &local.to_vec(),
        &remote.to_vec(),
        "local and remote profile lists match",
    )
}

pub fn compare_profile_view(
    local: &caly_api::ProfileView,
    remote: &caly_api::ProfileView,
) -> ParityItem {
    compare_value(
        "profile.get",
        local,
        remote,
        "local and remote profile views match",
    )
}

pub fn compare_deployment_plan(
    local: &DeploymentPlanView,
    remote: &DeploymentPlanView,
) -> ParityItem {
    compare_value(
        "profile.plan",
        local,
        remote,
        "local and remote deployment plans match",
    )
}

pub fn compare_pipeline_explain(local: &PipelineExplain, remote: &PipelineExplain) -> ParityItem {
    compare_value(
        "diagnostics.explain_pipeline",
        local,
        remote,
        "local and remote pipeline explain views match",
    )
}

pub fn compare_core_install_list(
    local: &[caly_api::CoreInstallView],
    remote: &[caly_api::CoreInstallView],
) -> ParityItem {
    compare_value(
        "core.list_installs",
        &local.to_vec(),
        &remote.to_vec(),
        "local and remote core install lists match",
    )
}

pub fn compare_core_inspection(
    local: &caly_api::CoreInspection,
    remote: &caly_api::CoreInspection,
) -> ParityItem {
    compare_value(
        "core.inspect",
        local,
        remote,
        "local and remote core inspection views match",
    )
}

pub fn compare_capability_report(
    local: &CapabilityReport,
    remote: &CapabilityReport,
) -> ParityItem {
    compare_value(
        "core.capabilities",
        local,
        remote,
        "local and remote capability reports match",
    )
}

pub fn compare_automation_jobs(
    local: &[AutomationJobView],
    remote: &[AutomationJobView],
) -> ParityItem {
    compare_value(
        "automation.list_jobs",
        &local.to_vec(),
        &remote.to_vec(),
        "local and remote automation job lists match",
    )
}

pub fn compare_recovery_status(
    local: &RecoveryStatusView,
    remote: &RecoveryStatusView,
) -> ParityItem {
    compare_value(
        "diagnostics.recovery_status",
        local,
        remote,
        "local and remote recovery status views match",
    )
}

pub async fn run_basic_parity_check(
    local: &dyn CalyFacade,
    remote: &dyn CalyFacade,
    ctx: Ctx,
    job_follow_request: Option<JobFollowRequest>,
) -> Result<ParityReport, caly_api::ApiError> {
    let mut report = ParityReport::default();

    let local_system = local.system().status(ctx.clone()).await?;
    let remote_system = remote.system().status(ctx.clone()).await?;
    report
        .items
        .push(compare_system_status(&local_system, &remote_system));

    let local_info = local.system().info(ctx.clone()).await?;
    let remote_info = remote.system().info(ctx.clone()).await?;
    report
        .items
        .push(compare_server_info(&local_info, &remote_info));

    let local_runtime = local.runtime().status(ctx.clone()).await?;
    let remote_runtime = remote.runtime().status(ctx.clone()).await?;
    report
        .items
        .push(compare_runtime_status(&local_runtime, &remote_runtime));

    let connection_query = ConnectionQuery {
        page: PageRequest {
            cursor: None,
            limit: 16,
        },
    };
    let local_connections = local
        .runtime()
        .connections(ctx.clone(), connection_query.clone())
        .await?;
    let remote_connections = remote
        .runtime()
        .connections(ctx.clone(), connection_query)
        .await?;
    report.items.push(compare_connection_page(
        &local_connections,
        &remote_connections,
    ));

    let local_profiles = local.profile().list(ctx.clone()).await?;
    let remote_profiles = remote.profile().list(ctx.clone()).await?;
    report
        .items
        .push(compare_profile_list(&local_profiles, &remote_profiles));
    if let (Some(local_profile), Some(remote_profile)) =
        (local_profiles.first(), remote_profiles.first())
    {
        let local_profile_view = local
            .profile()
            .get(ctx.clone(), local_profile.id.clone())
            .await?;
        let remote_profile_view = remote
            .profile()
            .get(ctx.clone(), remote_profile.id.clone())
            .await?;
        report.items.push(compare_profile_view(
            &local_profile_view,
            &remote_profile_view,
        ));
    }

    let local_installs = local.core().list_installs(ctx.clone()).await?;
    let remote_installs = remote.core().list_installs(ctx.clone()).await?;
    report
        .items
        .push(compare_core_install_list(&local_installs, &remote_installs));
    if let (Some(local_install), Some(remote_install)) =
        (local_installs.first(), remote_installs.first())
    {
        let local_inspect = local
            .core()
            .inspect(ctx.clone(), local_install.id.clone())
            .await?;
        let remote_inspect = remote
            .core()
            .inspect(ctx.clone(), remote_install.id.clone())
            .await?;
        report
            .items
            .push(compare_core_inspection(&local_inspect, &remote_inspect));
    }

    let plan_request = ApplyRequest {
        profile_id: ProfileId("parity-profile".to_owned()),
        dry_run: true,
        strict: false,
    };
    let local_plan = local
        .profile()
        .plan(ctx.clone(), plan_request.clone())
        .await?;
    let remote_plan = remote.profile().plan(ctx.clone(), plan_request).await?;
    report
        .items
        .push(compare_deployment_plan(&local_plan, &remote_plan));

    let explain_request = PipelineExplainRequest {
        profile_id: ProfileId("parity-profile".to_owned()),
    };
    let local_explain = local
        .diagnostics()
        .explain_pipeline(ctx.clone(), explain_request.clone())
        .await?;
    let remote_explain = remote
        .diagnostics()
        .explain_pipeline(ctx.clone(), explain_request)
        .await?;
    report
        .items
        .push(compare_pipeline_explain(&local_explain, &remote_explain));

    let capability_query = CapabilityQuery {
        target: "mihomo".to_owned(),
    };
    let local_capability = local
        .core()
        .capabilities(ctx.clone(), capability_query.clone())
        .await?;
    let remote_capability = remote
        .core()
        .capabilities(ctx.clone(), capability_query)
        .await?;
    report.items.push(compare_capability_report(
        &local_capability,
        &remote_capability,
    ));

    let local_recovery = local.diagnostics().recovery_status(ctx.clone()).await?;
    let remote_recovery = remote.diagnostics().recovery_status(ctx.clone()).await?;
    report
        .items
        .push(compare_recovery_status(&local_recovery, &remote_recovery));

    let local_automation = local.automation().list_jobs(ctx.clone()).await?;
    let remote_automation = remote.automation().list_jobs(ctx.clone()).await?;
    report.items.push(compare_automation_jobs(
        &local_automation,
        &remote_automation,
    ));

    if let Some(request) = job_follow_request {
        let local_job = local
            .diagnostics()
            .follow_job(ctx.clone(), request.clone())
            .await?;
        let remote_job = remote
            .diagnostics()
            .follow_job(ctx.clone(), request)
            .await?;
        report
            .items
            .push(compare_job_follow(&local_job, &remote_job));
    }

    Ok(report)
}

/// One compared field. `pub` because the write-side bundle in `contract.rs` compares its own
/// value types with the same rule: equal ⇒ Match, otherwise a `local=… remote=…` detail.
pub fn compare_value<T: std::fmt::Debug + Eq>(
    name: &str,
    local: &T,
    remote: &T,
    ok_detail: &str,
) -> ParityItem {
    if local == remote {
        ParityItem {
            name: name.to_owned(),
            status: ParityStatus::Match,
            detail: ok_detail.to_owned(),
        }
    } else {
        ParityItem {
            name: name.to_owned(),
            status: ParityStatus::Mismatch,
            detail: format!("local={:?} remote={:?}", local, remote),
        }
    }
}

pub fn default_parity_ctx() -> Ctx {
    default_ctx("parity", Actor::Cli)
}

/// A pass, with whatever evidence the caller found worth keeping.
pub fn matched(name: &str, detail: impl Into<String>) -> ParityItem {
    ParityItem {
        name: name.to_owned(),
        status: ParityStatus::Match,
        detail: detail.into(),
    }
}

/// A failure of something that is not a two-sided comparison, so the detail carries the evidence
/// rather than a `local=… remote=…` pair.
pub fn mismatch(name: &str, detail: impl Into<String>) -> ParityItem {
    ParityItem {
        name: name.to_owned(),
        status: ParityStatus::Mismatch,
        detail: detail.into(),
    }
}
