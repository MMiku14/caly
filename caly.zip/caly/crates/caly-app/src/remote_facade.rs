use std::sync::{Arc, Mutex};

use caly_api::{
    Accepted, ApiError, ApiResult, ApplyRequest, AutomationFacet, AutomationJobView, AutomationOp,
    BoxFuture, CalyFacade, CapabilityQuery, CapabilityReport, ConnectionId, ConnectionPage,
    ConnectionQuery, CoreFacet, CoreInspection, CoreInstallId, CoreInstallView, CoreOp, Ctx,
    DelayTestRequest, DiagnosticsFacet, DiagnosticsOp, DnsExplainRequest, DnsExplainResult,
    DnsFacet, DnsOp, DnsStatus, DoctorReport, DoctorRequest, ErrorCategory, ErrorCode, GroupView,
    JobEventsRequest, JobFollowRequest, JobFollowView, NetworkFacet, NetworkOp, NetworkPlanView,
    NetworkStatus, NodePage, NodeQuery, Operation, OperationResult, PatchAutomationJob,
    PipelineExplain, PipelineExplainRequest, ProfileFacet, ProfileId, ProfileOp, ProfileSummary,
    ProfileView, ProxyFacet, ProxyOp, RecoveryStatusView, RollbackRequest, RouteExplainRequest,
    RouteExplainResult, RoutingFacet, RoutingOp, RoutingValidation, RulePage, RuleQuery,
    RuntimeFacet, RuntimeOp, RuntimeStatus, RuntimeSubscription, SelectNode, ServerInfo,
    SourceFacet, SourceId, SourceInspection, SourceOp, SourcePreview, SourcePreviewRequest,
    SourceSummary, SystemFacet, SystemOp, SystemStatus, WatchOpened,
};

use crate::remote::{RemoteSessionClient, RemoteTransport};

#[derive(Clone)]
pub struct RemoteFacade<T: RemoteTransport + Send + 'static> {
    client: Arc<Mutex<RemoteSessionClient<T>>>,
}

impl<T: RemoteTransport + Send + 'static> RemoteFacade<T> {
    pub fn new(client: RemoteSessionClient<T>) -> Self {
        Self {
            client: Arc::new(Mutex::new(client)),
        }
    }

    pub fn client(&self) -> Arc<Mutex<RemoteSessionClient<T>>> {
        Arc::clone(&self.client)
    }
}

impl<T: RemoteTransport + Send + 'static> CalyFacade for RemoteFacade<T> {
    fn system(&self) -> Arc<dyn SystemFacet> {
        Arc::new(RemoteSystemFacet {
            client: self.client(),
        })
    }

    fn profile(&self) -> Arc<dyn ProfileFacet> {
        Arc::new(RemoteProfileFacet {
            client: self.client(),
        })
    }

    fn source(&self) -> Arc<dyn SourceFacet> {
        Arc::new(RemoteSourceFacet {
            client: self.client(),
        })
    }

    fn proxy(&self) -> Arc<dyn ProxyFacet> {
        Arc::new(RemoteProxyFacet {
            client: self.client(),
        })
    }

    fn routing(&self) -> Arc<dyn RoutingFacet> {
        Arc::new(RemoteRoutingFacet {
            client: self.client(),
        })
    }

    fn dns(&self) -> Arc<dyn DnsFacet> {
        Arc::new(RemoteDnsFacet {
            client: self.client(),
        })
    }

    fn network(&self) -> Arc<dyn NetworkFacet> {
        Arc::new(RemoteNetworkFacet {
            client: self.client(),
        })
    }

    fn core(&self) -> Arc<dyn CoreFacet> {
        Arc::new(RemoteCoreFacet {
            client: self.client(),
        })
    }

    fn runtime(&self) -> Arc<dyn RuntimeFacet> {
        Arc::new(RemoteRuntimeFacet {
            client: self.client(),
        })
    }

    fn diagnostics(&self) -> Arc<dyn DiagnosticsFacet> {
        Arc::new(RemoteDiagnosticsFacet {
            client: self.client(),
        })
    }

    fn automation(&self) -> Arc<dyn AutomationFacet> {
        Arc::new(RemoteAutomationFacet {
            client: self.client(),
        })
    }
}

fn remote_unavailable(ctx: &Ctx, summary: impl Into<String>) -> ApiError {
    ApiError::new(
        ErrorCode::Unavailable,
        ErrorCategory::Internal,
        true,
        summary,
        ctx.trace_id.clone(),
    )
}

/// The typed sibling of [`with_client`]: a daemon refusal is returned as it was written.
///
/// Only a lock failure — which is the client's own bug, not the daemon's answer — becomes a
/// synthesised `Unavailable`. Keeping the two wrappers apart is deliberate: the string-shaped
/// [`with_client`] is what the report builders use, and silently routing typed errors through it is
/// exactly how the identity got lost in the first place.
fn with_client_api<T, R>(
    shared: &Arc<Mutex<RemoteSessionClient<T>>>,
    ctx: &Ctx,
    f: impl FnOnce(&mut RemoteSessionClient<T>) -> Result<R, Box<ApiError>>,
) -> Result<R, Box<ApiError>>
where
    T: RemoteTransport + Send + 'static,
{
    let mut guard = shared.lock().map_err(|_| {
        Box::new(ApiError::new(
            ErrorCode::Unavailable,
            ErrorCategory::Internal,
            true,
            "remote session client lock poisoned",
            ctx.trace_id.clone(),
        ))
    })?;
    // The client hands back a boxed error so its closures stay small (`result_large_err` is a real
    // cost, not a style taste). Each façade method returns the frozen `ApiResult`, and `?` unboxes
    // through `impl From<Box<ApiError>> for ApiError` — so the boundary is a move, not a clone, and no
    // call site needs to know about the box.
    f(&mut guard)
}

#[derive(Clone)]
struct RemoteSystemFacet<T: RemoteTransport + Send + 'static> {
    client: Arc<Mutex<RemoteSessionClient<T>>>,
}

impl<T: RemoteTransport + Send + 'static> SystemFacet for RemoteSystemFacet<T> {
    fn status<'a>(&'a self, ctx: Ctx) -> BoxFuture<'a, ApiResult<SystemStatus>> {
        let client = Arc::clone(&self.client);
        Box::pin(async move {
            let result = with_client_api(&client, &ctx, |remote| {
                remote.send_operation_checked(&ctx, Operation::System(SystemOp::Status))
            })?;
            match result {
                OperationResult::SystemStatus(value) => Ok(value),
                other => Err(remote_unavailable(
                    &ctx,
                    format!("unexpected result for system.status: {:?}", other),
                )),
            }
        })
    }

    fn info<'a>(&'a self, ctx: Ctx) -> BoxFuture<'a, ApiResult<ServerInfo>> {
        let client = Arc::clone(&self.client);
        Box::pin(async move {
            let result = with_client_api(&client, &ctx, |remote| {
                remote.send_operation_checked(&ctx, Operation::System(SystemOp::Info))
            })?;
            match result {
                OperationResult::ServerInfo(value) => Ok(value),
                other => Err(remote_unavailable(
                    &ctx,
                    format!("unexpected result for system.info: {:?}", other),
                )),
            }
        })
    }

    fn plan_gc<'a>(
        &'a self,
        ctx: Ctx,
        request: caly_api::GcPlanRequest,
    ) -> BoxFuture<'a, ApiResult<caly_api::GcPlanView>> {
        let client = Arc::clone(&self.client);
        Box::pin(async move {
            let result = with_client_api(&client, &ctx, |remote| {
                remote.send_operation_checked(
                    &ctx,
                    Operation::System(caly_api::SystemOp::GcPlan { request }),
                )
            })?;
            match result {
                OperationResult::GcPlan(value) => Ok(value),
                other => Err(remote_unavailable(
                    &ctx,
                    format!("unexpected result for system.gc-plan: {:?}", other),
                )),
            }
        })
    }

    fn collect_garbage<'a>(
        &'a self,
        ctx: Ctx,
        request: caly_api::GcCollectRequest,
    ) -> BoxFuture<'a, ApiResult<Accepted>> {
        let client = Arc::clone(&self.client);
        Box::pin(async move {
            let result = with_client_api(&client, &ctx, |remote| {
                remote.send_operation_checked(
                    &ctx,
                    Operation::System(caly_api::SystemOp::CollectGarbage { request }),
                )
            })?;
            match result {
                OperationResult::Accepted(value) => Ok(value),
                other => Err(remote_unavailable(
                    &ctx,
                    format!("unexpected result for system.gc-collect: {:?}", other),
                )),
            }
        })
    }

    fn shutdown<'a>(&'a self, ctx: Ctx) -> BoxFuture<'a, ApiResult<Accepted>> {
        let client = Arc::clone(&self.client);
        Box::pin(async move {
            let result = with_client_api(&client, &ctx, |remote| {
                remote.send_operation_checked(&ctx, Operation::System(SystemOp::Shutdown))
            })?;
            match result {
                OperationResult::Accepted(value) => Ok(value),
                other => Err(remote_unavailable(
                    &ctx,
                    format!("unexpected result for system.shutdown: {:?}", other),
                )),
            }
        })
    }
}

#[derive(Clone)]
struct RemoteProfileFacet<T: RemoteTransport + Send + 'static> {
    client: Arc<Mutex<RemoteSessionClient<T>>>,
}

impl<T: RemoteTransport + Send + 'static> ProfileFacet for RemoteProfileFacet<T> {
    fn list<'a>(&'a self, ctx: Ctx) -> BoxFuture<'a, ApiResult<Vec<ProfileSummary>>> {
        let client = Arc::clone(&self.client);
        Box::pin(async move {
            let result = with_client_api(&client, &ctx, |remote| {
                remote.send_operation_checked(&ctx, Operation::Profile(ProfileOp::List))
            })?;
            match result {
                OperationResult::ProfileList(value) => Ok(value),
                other => Err(remote_unavailable(
                    &ctx,
                    format!("unexpected result for profile.list: {:?}", other),
                )),
            }
        })
    }

    fn get<'a>(&'a self, ctx: Ctx, profile_id: ProfileId) -> BoxFuture<'a, ApiResult<ProfileView>> {
        let client = Arc::clone(&self.client);
        Box::pin(async move {
            let result = with_client_api(&client, &ctx, |remote| {
                remote
                    .send_operation_checked(&ctx, Operation::Profile(ProfileOp::Get { profile_id }))
            })?;
            match result {
                OperationResult::ProfileView(value) => Ok(value),
                other => Err(remote_unavailable(
                    &ctx,
                    format!("unexpected result for profile.get: {:?}", other),
                )),
            }
        })
    }

    fn plan<'a>(
        &'a self,
        ctx: Ctx,
        request: ApplyRequest,
    ) -> BoxFuture<'a, ApiResult<caly_api::DeploymentPlanView>> {
        let client = Arc::clone(&self.client);
        Box::pin(async move {
            let result = with_client_api(&client, &ctx, |remote| {
                remote.send_operation_checked(&ctx, Operation::Profile(ProfileOp::Plan { request }))
            })?;
            match result {
                OperationResult::DeploymentPlan(value) => Ok(value),
                other => Err(remote_unavailable(
                    &ctx,
                    format!("unexpected result for profile.plan: {:?}", other),
                )),
            }
        })
    }

    fn apply<'a>(&'a self, ctx: Ctx, request: ApplyRequest) -> BoxFuture<'a, ApiResult<Accepted>> {
        let client = Arc::clone(&self.client);
        Box::pin(async move {
            let result = with_client_api(&client, &ctx, |remote| {
                remote
                    .send_operation_checked(&ctx, Operation::Profile(ProfileOp::Apply { request }))
            })?;
            match result {
                OperationResult::Accepted(value) => Ok(value),
                other => Err(remote_unavailable(
                    &ctx,
                    format!("unexpected result for profile.apply: {:?}", other),
                )),
            }
        })
    }

    fn rollback<'a>(
        &'a self,
        ctx: Ctx,
        request: RollbackRequest,
    ) -> BoxFuture<'a, ApiResult<Accepted>> {
        let client = Arc::clone(&self.client);
        Box::pin(async move {
            let result = with_client_api(&client, &ctx, |remote| {
                remote.send_operation_checked(
                    &ctx,
                    Operation::Profile(ProfileOp::Rollback { request }),
                )
            })?;
            match result {
                OperationResult::Accepted(value) => Ok(value),
                other => Err(remote_unavailable(
                    &ctx,
                    format!("unexpected result for profile.rollback: {:?}", other),
                )),
            }
        })
    }
}

#[derive(Clone)]
struct RemoteSourceFacet<T: RemoteTransport + Send + 'static> {
    client: Arc<Mutex<RemoteSessionClient<T>>>,
}

impl<T: RemoteTransport + Send + 'static> SourceFacet for RemoteSourceFacet<T> {
    fn list<'a>(&'a self, ctx: Ctx) -> BoxFuture<'a, ApiResult<Vec<SourceSummary>>> {
        let client = Arc::clone(&self.client);
        Box::pin(async move {
            let result = with_client_api(&client, &ctx, |remote| {
                remote.send_operation_checked(&ctx, Operation::Source(SourceOp::List))
            })?;
            match result {
                OperationResult::SourceList(value) => Ok(value),
                other => Err(remote_unavailable(
                    &ctx,
                    format!("unexpected result for source.list: {:?}", other),
                )),
            }
        })
    }

    fn inspect<'a>(
        &'a self,
        ctx: Ctx,
        source_id: SourceId,
    ) -> BoxFuture<'a, ApiResult<SourceInspection>> {
        let client = Arc::clone(&self.client);
        Box::pin(async move {
            let result = with_client_api(&client, &ctx, |remote| {
                remote.send_operation_checked(
                    &ctx,
                    Operation::Source(SourceOp::Inspect { source_id }),
                )
            })?;
            match result {
                OperationResult::SourceInspection(value) => Ok(value),
                other => Err(remote_unavailable(
                    &ctx,
                    format!("unexpected result for source.inspect: {:?}", other),
                )),
            }
        })
    }

    fn update<'a>(&'a self, ctx: Ctx, source_id: SourceId) -> BoxFuture<'a, ApiResult<Accepted>> {
        let client = Arc::clone(&self.client);
        Box::pin(async move {
            let result = with_client_api(&client, &ctx, |remote| {
                remote
                    .send_operation_checked(&ctx, Operation::Source(SourceOp::Update { source_id }))
            })?;
            match result {
                OperationResult::Accepted(value) => Ok(value),
                other => Err(remote_unavailable(
                    &ctx,
                    format!("unexpected result for source.update: {:?}", other),
                )),
            }
        })
    }

    fn preview<'a>(
        &'a self,
        ctx: Ctx,
        request: SourcePreviewRequest,
    ) -> BoxFuture<'a, ApiResult<SourcePreview>> {
        let client = Arc::clone(&self.client);
        Box::pin(async move {
            let result = with_client_api(&client, &ctx, |remote| {
                remote
                    .send_operation_checked(&ctx, Operation::Source(SourceOp::Preview { request }))
            })?;
            match result {
                OperationResult::SourcePreview(value) => Ok(value),
                other => Err(remote_unavailable(
                    &ctx,
                    format!("unexpected result for source.preview: {:?}", other),
                )),
            }
        })
    }
}

#[derive(Clone)]
struct RemoteProxyFacet<T: RemoteTransport + Send + 'static> {
    client: Arc<Mutex<RemoteSessionClient<T>>>,
}

impl<T: RemoteTransport + Send + 'static> ProxyFacet for RemoteProxyFacet<T> {
    fn nodes<'a>(&'a self, ctx: Ctx, query: NodeQuery) -> BoxFuture<'a, ApiResult<NodePage>> {
        let client = Arc::clone(&self.client);
        Box::pin(async move {
            let result = with_client_api(&client, &ctx, |remote| {
                remote.send_operation_checked(&ctx, Operation::Proxy(ProxyOp::Nodes { query }))
            })?;
            match result {
                OperationResult::NodePage(value) => Ok(value),
                other => Err(remote_unavailable(
                    &ctx,
                    format!("unexpected result for proxy.nodes: {:?}", other),
                )),
            }
        })
    }

    fn groups<'a>(&'a self, ctx: Ctx) -> BoxFuture<'a, ApiResult<Vec<GroupView>>> {
        let client = Arc::clone(&self.client);
        Box::pin(async move {
            let result = with_client_api(&client, &ctx, |remote| {
                remote.send_operation_checked(&ctx, Operation::Proxy(ProxyOp::Groups))
            })?;
            match result {
                OperationResult::GroupList(value) => Ok(value),
                other => Err(remote_unavailable(
                    &ctx,
                    format!("unexpected result for proxy.groups: {:?}", other),
                )),
            }
        })
    }

    fn select<'a>(&'a self, ctx: Ctx, request: SelectNode) -> BoxFuture<'a, ApiResult<Accepted>> {
        let client = Arc::clone(&self.client);
        Box::pin(async move {
            let result = with_client_api(&client, &ctx, |remote| {
                remote.send_operation_checked(&ctx, Operation::Proxy(ProxyOp::Select { request }))
            })?;
            match result {
                OperationResult::Accepted(value) => Ok(value),
                other => Err(remote_unavailable(
                    &ctx,
                    format!("unexpected result for proxy.select: {:?}", other),
                )),
            }
        })
    }

    fn test_delay<'a>(
        &'a self,
        ctx: Ctx,
        request: DelayTestRequest,
    ) -> BoxFuture<'a, ApiResult<Accepted>> {
        let client = Arc::clone(&self.client);
        Box::pin(async move {
            let result = with_client_api(&client, &ctx, |remote| {
                remote
                    .send_operation_checked(&ctx, Operation::Proxy(ProxyOp::TestDelay { request }))
            })?;
            match result {
                OperationResult::Accepted(value) => Ok(value),
                other => Err(remote_unavailable(
                    &ctx,
                    format!("unexpected result for proxy.test_delay: {:?}", other),
                )),
            }
        })
    }
}

#[derive(Clone)]
struct RemoteRoutingFacet<T: RemoteTransport + Send + 'static> {
    client: Arc<Mutex<RemoteSessionClient<T>>>,
}

impl<T: RemoteTransport + Send + 'static> RoutingFacet for RemoteRoutingFacet<T> {
    fn rules<'a>(&'a self, ctx: Ctx, query: RuleQuery) -> BoxFuture<'a, ApiResult<RulePage>> {
        let client = Arc::clone(&self.client);
        Box::pin(async move {
            let result = with_client_api(&client, &ctx, |remote| {
                remote.send_operation_checked(&ctx, Operation::Routing(RoutingOp::Rules { query }))
            })?;
            match result {
                OperationResult::RulePage(value) => Ok(value),
                other => Err(remote_unavailable(
                    &ctx,
                    format!("unexpected result for routing.rules: {:?}", other),
                )),
            }
        })
    }

    fn explain<'a>(
        &'a self,
        ctx: Ctx,
        request: RouteExplainRequest,
    ) -> BoxFuture<'a, ApiResult<RouteExplainResult>> {
        let client = Arc::clone(&self.client);
        Box::pin(async move {
            let result = with_client_api(&client, &ctx, |remote| {
                remote.send_operation_checked(
                    &ctx,
                    Operation::Routing(RoutingOp::Explain { request }),
                )
            })?;
            match result {
                OperationResult::RouteExplain(value) => Ok(value),
                other => Err(remote_unavailable(
                    &ctx,
                    format!("unexpected result for routing.explain: {:?}", other),
                )),
            }
        })
    }

    fn validate<'a>(
        &'a self,
        ctx: Ctx,
        profile_id: ProfileId,
    ) -> BoxFuture<'a, ApiResult<RoutingValidation>> {
        let client = Arc::clone(&self.client);
        Box::pin(async move {
            let result = with_client_api(&client, &ctx, |remote| {
                remote.send_operation_checked(
                    &ctx,
                    Operation::Routing(RoutingOp::Validate { profile_id }),
                )
            })?;
            match result {
                OperationResult::RoutingValidation(value) => Ok(value),
                other => Err(remote_unavailable(
                    &ctx,
                    format!("unexpected result for routing.validate: {:?}", other),
                )),
            }
        })
    }
}

#[derive(Clone)]
struct RemoteDnsFacet<T: RemoteTransport + Send + 'static> {
    client: Arc<Mutex<RemoteSessionClient<T>>>,
}

impl<T: RemoteTransport + Send + 'static> DnsFacet for RemoteDnsFacet<T> {
    fn status<'a>(&'a self, ctx: Ctx) -> BoxFuture<'a, ApiResult<DnsStatus>> {
        let client = Arc::clone(&self.client);
        Box::pin(async move {
            let result = with_client_api(&client, &ctx, |remote| {
                remote.send_operation_checked(&ctx, Operation::Dns(DnsOp::Status))
            })?;
            match result {
                OperationResult::DnsStatus(value) => Ok(value),
                other => Err(remote_unavailable(
                    &ctx,
                    format!("unexpected result for dns.status: {:?}", other),
                )),
            }
        })
    }

    fn explain<'a>(
        &'a self,
        ctx: Ctx,
        request: DnsExplainRequest,
    ) -> BoxFuture<'a, ApiResult<DnsExplainResult>> {
        let client = Arc::clone(&self.client);
        Box::pin(async move {
            let result = with_client_api(&client, &ctx, |remote| {
                remote.send_operation_checked(&ctx, Operation::Dns(DnsOp::Explain { request }))
            })?;
            match result {
                OperationResult::DnsExplain(value) => Ok(value),
                other => Err(remote_unavailable(
                    &ctx,
                    format!("unexpected result for dns.explain: {:?}", other),
                )),
            }
        })
    }

    fn flush_cache<'a>(&'a self, ctx: Ctx) -> BoxFuture<'a, ApiResult<Accepted>> {
        let client = Arc::clone(&self.client);
        Box::pin(async move {
            let result = with_client_api(&client, &ctx, |remote| {
                remote.send_operation_checked(&ctx, Operation::Dns(DnsOp::FlushCache))
            })?;
            match result {
                OperationResult::Accepted(value) => Ok(value),
                other => Err(remote_unavailable(
                    &ctx,
                    format!("unexpected result for dns.flush_cache: {:?}", other),
                )),
            }
        })
    }
}

#[derive(Clone)]
struct RemoteNetworkFacet<T: RemoteTransport + Send + 'static> {
    client: Arc<Mutex<RemoteSessionClient<T>>>,
}

impl<T: RemoteTransport + Send + 'static> NetworkFacet for RemoteNetworkFacet<T> {
    fn status<'a>(&'a self, ctx: Ctx) -> BoxFuture<'a, ApiResult<NetworkStatus>> {
        let client = Arc::clone(&self.client);
        Box::pin(async move {
            let result = with_client_api(&client, &ctx, |remote| {
                remote.send_operation_checked(&ctx, Operation::Network(NetworkOp::Status))
            })?;
            match result {
                OperationResult::NetworkStatus(value) => Ok(value),
                other => Err(remote_unavailable(
                    &ctx,
                    format!("unexpected result for network.status: {:?}", other),
                )),
            }
        })
    }

    fn inspect_plan<'a>(
        &'a self,
        ctx: Ctx,
        profile_id: ProfileId,
    ) -> BoxFuture<'a, ApiResult<NetworkPlanView>> {
        let client = Arc::clone(&self.client);
        Box::pin(async move {
            let result = with_client_api(&client, &ctx, |remote| {
                remote.send_operation_checked(
                    &ctx,
                    Operation::Network(NetworkOp::InspectPlan { profile_id }),
                )
            })?;
            match result {
                OperationResult::NetworkPlan(value) => Ok(value),
                other => Err(remote_unavailable(
                    &ctx,
                    format!("unexpected result for network.inspect_plan: {:?}", other),
                )),
            }
        })
    }

    fn repair<'a>(&'a self, ctx: Ctx) -> BoxFuture<'a, ApiResult<Accepted>> {
        let client = Arc::clone(&self.client);
        Box::pin(async move {
            let result = with_client_api(&client, &ctx, |remote| {
                remote.send_operation_checked(&ctx, Operation::Network(NetworkOp::Repair))
            })?;
            match result {
                OperationResult::Accepted(value) => Ok(value),
                other => Err(remote_unavailable(
                    &ctx,
                    format!("unexpected result for network.repair: {:?}", other),
                )),
            }
        })
    }
}

#[derive(Clone)]
struct RemoteCoreFacet<T: RemoteTransport + Send + 'static> {
    client: Arc<Mutex<RemoteSessionClient<T>>>,
}

impl<T: RemoteTransport + Send + 'static> CoreFacet for RemoteCoreFacet<T> {
    fn list_installs<'a>(&'a self, ctx: Ctx) -> BoxFuture<'a, ApiResult<Vec<CoreInstallView>>> {
        let client = Arc::clone(&self.client);
        Box::pin(async move {
            let result = with_client_api(&client, &ctx, |remote| {
                remote.send_operation_checked(&ctx, Operation::Core(CoreOp::ListInstalls))
            })?;
            match result {
                OperationResult::CoreInstallList(value) => Ok(value),
                other => Err(remote_unavailable(
                    &ctx,
                    format!("unexpected result for core.list_installs: {:?}", other),
                )),
            }
        })
    }

    fn inspect<'a>(
        &'a self,
        ctx: Ctx,
        core_install_id: CoreInstallId,
    ) -> BoxFuture<'a, ApiResult<CoreInspection>> {
        let client = Arc::clone(&self.client);
        Box::pin(async move {
            let result = with_client_api(&client, &ctx, |remote| {
                remote.send_operation_checked(
                    &ctx,
                    Operation::Core(CoreOp::Inspect { core_install_id }),
                )
            })?;
            match result {
                OperationResult::CoreInspection(value) => Ok(value),
                other => Err(remote_unavailable(
                    &ctx,
                    format!("unexpected result for core.inspect: {:?}", other),
                )),
            }
        })
    }

    fn capabilities<'a>(
        &'a self,
        ctx: Ctx,
        query: CapabilityQuery,
    ) -> BoxFuture<'a, ApiResult<CapabilityReport>> {
        let client = Arc::clone(&self.client);
        Box::pin(async move {
            let result = with_client_api(&client, &ctx, |remote| {
                remote.send_operation_checked(&ctx, Operation::Core(CoreOp::Capabilities { query }))
            })?;
            match result {
                OperationResult::CapabilityReport(value) => Ok(value),
                other => Err(remote_unavailable(
                    &ctx,
                    format!("unexpected result for core.capabilities: {:?}", other),
                )),
            }
        })
    }
}

#[derive(Clone)]
struct RemoteRuntimeFacet<T: RemoteTransport + Send + 'static> {
    client: Arc<Mutex<RemoteSessionClient<T>>>,
}

impl<T: RemoteTransport + Send + 'static> RuntimeFacet for RemoteRuntimeFacet<T> {
    fn status<'a>(&'a self, ctx: Ctx) -> BoxFuture<'a, ApiResult<RuntimeStatus>> {
        let client = Arc::clone(&self.client);
        Box::pin(async move {
            let result = with_client_api(&client, &ctx, |remote| {
                remote.send_operation_checked(&ctx, Operation::Runtime(RuntimeOp::Status))
            })?;
            match result {
                OperationResult::RuntimeStatus(value) => Ok(value),
                other => Err(remote_unavailable(
                    &ctx,
                    format!("unexpected result for runtime.status: {:?}", other),
                )),
            }
        })
    }

    fn connections<'a>(
        &'a self,
        ctx: Ctx,
        query: ConnectionQuery,
    ) -> BoxFuture<'a, ApiResult<ConnectionPage>> {
        let client = Arc::clone(&self.client);
        Box::pin(async move {
            let result = with_client_api(&client, &ctx, |remote| {
                remote.send_operation_checked(
                    &ctx,
                    Operation::Runtime(RuntimeOp::Connections { query }),
                )
            })?;
            match result {
                OperationResult::ConnectionPage(value) => Ok(value),
                other => Err(remote_unavailable(
                    &ctx,
                    format!("unexpected result for runtime.connections: {:?}", other),
                )),
            }
        })
    }

    fn close_connection<'a>(
        &'a self,
        ctx: Ctx,
        connection_id: ConnectionId,
    ) -> BoxFuture<'a, ApiResult<Accepted>> {
        let client = Arc::clone(&self.client);
        Box::pin(async move {
            let result = with_client_api(&client, &ctx, |remote| {
                remote.send_operation_checked(
                    &ctx,
                    Operation::Runtime(RuntimeOp::CloseConnection { connection_id }),
                )
            })?;
            match result {
                OperationResult::Accepted(value) => Ok(value),
                other => Err(remote_unavailable(
                    &ctx,
                    format!(
                        "unexpected result for runtime.close_connection: {:?}",
                        other
                    ),
                )),
            }
        })
    }

    fn watch<'a>(
        &'a self,
        ctx: Ctx,
        subscription: RuntimeSubscription,
    ) -> BoxFuture<'a, ApiResult<WatchOpened>> {
        let client = Arc::clone(&self.client);
        Box::pin(async move {
            Ok(with_client_api(&client, &ctx, |remote| {
                remote.open_runtime_stream_checked(&ctx, subscription)
            })?)
        })
    }
}

#[derive(Clone)]
struct RemoteDiagnosticsFacet<T: RemoteTransport + Send + 'static> {
    client: Arc<Mutex<RemoteSessionClient<T>>>,
}

impl<T: RemoteTransport + Send + 'static> DiagnosticsFacet for RemoteDiagnosticsFacet<T> {
    fn doctor<'a>(
        &'a self,
        ctx: Ctx,
        request: DoctorRequest,
    ) -> BoxFuture<'a, ApiResult<DoctorReport>> {
        let client = Arc::clone(&self.client);
        Box::pin(async move {
            let result = with_client_api(&client, &ctx, |remote| {
                remote.send_operation_checked(
                    &ctx,
                    Operation::Diagnostics(DiagnosticsOp::Doctor { request }),
                )
            })?;
            match result {
                OperationResult::DoctorReport(value) => Ok(value),
                other => Err(remote_unavailable(
                    &ctx,
                    format!("unexpected result for diagnostics.doctor: {:?}", other),
                )),
            }
        })
    }

    fn explain_pipeline<'a>(
        &'a self,
        ctx: Ctx,
        request: PipelineExplainRequest,
    ) -> BoxFuture<'a, ApiResult<PipelineExplain>> {
        let client = Arc::clone(&self.client);
        Box::pin(async move {
            let result = with_client_api(&client, &ctx, |remote| {
                remote.send_operation_checked(
                    &ctx,
                    Operation::Diagnostics(DiagnosticsOp::ExplainPipeline { request }),
                )
            })?;
            match result {
                OperationResult::PipelineExplain(value) => Ok(value),
                other => Err(remote_unavailable(
                    &ctx,
                    format!(
                        "unexpected result for diagnostics.explain_pipeline: {:?}",
                        other
                    ),
                )),
            }
        })
    }

    fn recovery_status<'a>(&'a self, ctx: Ctx) -> BoxFuture<'a, ApiResult<RecoveryStatusView>> {
        let client = Arc::clone(&self.client);
        Box::pin(async move {
            let result = with_client_api(&client, &ctx, |remote| {
                remote.send_operation_checked(
                    &ctx,
                    Operation::Diagnostics(DiagnosticsOp::RecoveryStatus),
                )
            })?;
            match result {
                OperationResult::RecoveryStatus(value) => Ok(value),
                other => Err(remote_unavailable(
                    &ctx,
                    format!(
                        "unexpected result for diagnostics.recovery_status: {:?}",
                        other
                    ),
                )),
            }
        })
    }

    fn follow_job<'a>(
        &'a self,
        ctx: Ctx,
        request: JobFollowRequest,
    ) -> BoxFuture<'a, ApiResult<JobFollowView>> {
        let client = Arc::clone(&self.client);
        Box::pin(async move {
            let view = with_client_api(&client, &ctx, |remote| {
                remote.follow_job_query_with_ctx(&ctx, request.job_id, request.from_event_index)
            })?;
            Ok(view)
        })
    }

    fn follow_job_stream<'a>(
        &'a self,
        ctx: Ctx,
        request: JobFollowRequest,
    ) -> BoxFuture<'a, ApiResult<WatchOpened>> {
        let client = Arc::clone(&self.client);
        Box::pin(async move {
            Ok(with_client_api(&client, &ctx, |remote| {
                remote.open_job_follow_stream_checked(&ctx, request)
            })?)
        })
    }

    fn read_job_events<'a>(
        &'a self,
        ctx: Ctx,
        request: JobEventsRequest,
    ) -> BoxFuture<'a, ApiResult<caly_api::JobEventsView>> {
        let client = Arc::clone(&self.client);
        Box::pin(async move {
            Ok(with_client_api(&client, &ctx, |remote| {
                remote.read_job_events(&ctx, request)
            })?)
        })
    }

    fn read_support_bundle<'a>(
        &'a self,
        ctx: Ctx,
        request: caly_api::SupportBundleReadRequest,
    ) -> BoxFuture<'a, ApiResult<caly_api::SupportBundleView>> {
        let client = Arc::clone(&self.client);
        Box::pin(async move {
            let result = with_client_api(&client, &ctx, |remote| {
                remote.send_operation_checked(
                    &ctx,
                    Operation::Diagnostics(DiagnosticsOp::ReadSupportBundle { request }),
                )
            })?;
            match result {
                OperationResult::SupportBundle(value) => Ok(value),
                other => Err(remote_unavailable(
                    &ctx,
                    format!(
                        "unexpected result for diagnostics.read_support_bundle: {:?}",
                        other
                    ),
                )),
            }
        })
    }

    fn support_bundle<'a>(&'a self, ctx: Ctx) -> BoxFuture<'a, ApiResult<Accepted>> {
        let client = Arc::clone(&self.client);
        Box::pin(async move {
            let result = with_client_api(&client, &ctx, |remote| {
                remote.send_operation_checked(
                    &ctx,
                    Operation::Diagnostics(DiagnosticsOp::SupportBundle),
                )
            })?;
            match result {
                OperationResult::Accepted(value) => Ok(value),
                other => Err(remote_unavailable(
                    &ctx,
                    format!(
                        "unexpected result for diagnostics.support_bundle: {:?}",
                        other
                    ),
                )),
            }
        })
    }
}

#[derive(Clone)]
struct RemoteAutomationFacet<T: RemoteTransport + Send + 'static> {
    client: Arc<Mutex<RemoteSessionClient<T>>>,
}

impl<T: RemoteTransport + Send + 'static> AutomationFacet for RemoteAutomationFacet<T> {
    fn list_jobs<'a>(&'a self, ctx: Ctx) -> BoxFuture<'a, ApiResult<Vec<AutomationJobView>>> {
        let client = Arc::clone(&self.client);
        Box::pin(async move {
            let result = with_client_api(&client, &ctx, |remote| {
                remote.send_operation_checked(&ctx, Operation::Automation(AutomationOp::ListJobs))
            })?;
            match result {
                OperationResult::AutomationJobs(value) => Ok(value),
                other => Err(remote_unavailable(
                    &ctx,
                    format!("unexpected result for automation.list_jobs: {:?}", other),
                )),
            }
        })
    }

    fn patch_job<'a>(
        &'a self,
        ctx: Ctx,
        request: PatchAutomationJob,
    ) -> BoxFuture<'a, ApiResult<Accepted>> {
        let client = Arc::clone(&self.client);
        Box::pin(async move {
            let result = with_client_api(&client, &ctx, |remote| {
                remote.send_operation_checked(
                    &ctx,
                    Operation::Automation(AutomationOp::PatchJob { request }),
                )
            })?;
            match result {
                OperationResult::Accepted(value) => Ok(value),
                other => Err(remote_unavailable(
                    &ctx,
                    format!("unexpected result for automation.patch_job: {:?}", other),
                )),
            }
        })
    }
}
