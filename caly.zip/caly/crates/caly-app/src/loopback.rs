use caly_api::StreamId;
use caly_common::Actor;
use caly_daemon::{
    DaemonApp, DaemonBootstrapConfig, DaemonTransport, DaemonTransportConfig, TransportStepOutput,
};
use caly_ipc::{
    make_header, ClientFrame, ClientHello, ClientSessionConfig, Compression, Encoding,
    NegotiationPolicy, ServerFrame, ServerHelloAck, SessionCloseReason, StreamFrame,
};

use crate::remote::{RemoteSessionClient, RemoteTransport};

pub struct LoopbackRemoteTransport {
    pub app: DaemonApp,
    pub transport: DaemonTransport,
}

impl LoopbackRemoteTransport {
    pub fn new() -> Self {
        Self::with_app(DaemonApp::bootstrap(DaemonBootstrapConfig {
            instance_id: "loopback-daemon".to_owned(),
            protocol_version: caly_api::ProtocolVersion { major: 1, minor: 0 },
            recover_on_start: false,
        }))
    }

    /// Wrap an existing daemon.
    ///
    /// Local/remote parity is only meaningful when both access paths see the *same* state; a
    /// remote built over its own fresh daemon compares two different processes and can never
    /// detect divergence. This constructor is what makes that sharing explicit.
    pub fn with_app(daemon: DaemonApp) -> Self {
        let transport = DaemonTransport::new(
            NegotiationPolicy::default(),
            DaemonTransportConfig {
                actor: Actor::Cli,
                session_id: "loopback-session".to_owned(),
                hello_timeout_ms: 5_000,
            },
        );
        Self {
            app: daemon,
            transport,
        }
    }
}

impl RemoteTransport for LoopbackRemoteTransport {
    fn send_hello(&mut self, hello: ClientHello) -> Result<ServerHelloAck, String> {
        let header = make_header(0, Encoding::Json, Compression::None);
        match self.transport.on_hello(&self.app, header, hello)? {
            TransportStepOutput::HelloAck(ack) => Ok(ack),
            other => Err(format!("unexpected output for hello: {:?}", other)),
        }
    }

    fn send_frame(
        &mut self,
        frame: ClientFrame,
        is_control_message: bool,
    ) -> Result<Vec<ServerFrame>, String> {
        let header = make_header(0, Encoding::Json, Compression::None);
        match self
            .transport
            .on_client_frame(&self.app, header, frame, is_control_message)?
        {
            TransportStepOutput::ResponseFrames(frames) => Ok(frames),
            other => Err(format!("unexpected output for client frame: {:?}", other)),
        }
    }

    fn pull_stream(
        &mut self,
        stream_id: StreamId,
        from_seq_exclusive: Option<u64>,
    ) -> Result<Vec<StreamFrame>, String> {
        match self
            .transport
            .pull_stream(&self.app, stream_id, from_seq_exclusive)?
        {
            TransportStepOutput::StreamFrames(frames) => {
                let mut out = Vec::new();
                for frame in frames {
                    match frame {
                        ServerFrame::Stream(stream) => out.push(stream),
                        ServerFrame::Response(_) => {
                            return Err("unexpected response frame during stream pull".to_owned())
                        }
                    }
                }
                Ok(out)
            }
            other => Err(format!("unexpected output for stream pull: {:?}", other)),
        }
    }

    fn close(&mut self) -> Result<(), String> {
        match self
            .transport
            .close(&self.app, SessionCloseReason::ClientClosed)?
        {
            TransportStepOutput::Closed(_) => Ok(()),
            other => Err(format!("unexpected output for close: {:?}", other)),
        }
    }

    fn process_next_job(&mut self) -> Result<bool, String> {
        self.app.process_next_job()
    }

    fn seed_recovery_fixture(&mut self, profile_id: String) -> Result<usize, String> {
        let report = self.app.seed_recovery_fixture(profile_id)?;
        Ok(report.decisions.len())
    }
}

pub fn build_loopback_remote_client() -> RemoteSessionClient<LoopbackRemoteTransport> {
    build_loopback_remote_client_for(LoopbackRemoteTransport::new())
}

/// A remote client wired to `daemon`, so a local façade over the same daemon and this client
/// describe one state through two access paths.
pub fn build_loopback_remote_client_with(
    daemon: DaemonApp,
) -> RemoteSessionClient<LoopbackRemoteTransport> {
    build_loopback_remote_client_for(LoopbackRemoteTransport::with_app(daemon))
}

fn build_loopback_remote_client_for(
    transport: LoopbackRemoteTransport,
) -> RemoteSessionClient<LoopbackRemoteTransport> {
    RemoteSessionClient::new(ClientSessionConfig::default(), transport)
}
