// This module used to carry a second, parallel scenario suite: its own `ScenarioSuite`/`ScenarioCase`
// types (`passed: bool`) and a five-row `run_loopback_scenarios()`. It is gone, for two reasons.
//
// First, two `ScenarioSuite` types in one crate is a drift machine: the `bool` one had no status
// enum, no contract/parity adapter, and — unlike the 123 rows of `scenario_suite::run_smoke_bundle` —
// it was the *only* one the gate judged.
//
// Second, and worse, three of its five rows were **hard-coded** to `true`:
// `runtime-dashboard-stream`, `runtime-dashboard-ack` and `hello-timeout-path` reported success while
// discarding what they exercised (`let _ = harness.ack_stream(..)`). A row that cannot fail is not a
// test — and `docs/ONBOARDING_NOTES.md §4.23` is the archive entry about exactly that shape of defect,
// which came back in the newer suite while the older one looked greener. The same scenarios now exist
// as `runtime.watch.*` and `session.hello-timeout` rows in `scenario_suite.rs` with real assertions,
// and `every_scenario_suite_row_passes` judges all of them.

use crate::contract::{run_basic_loopback_parity, run_follow_smoke, run_loopback_remote_contract};
use crate::follow::{
    follow_job_once_query, follow_job_once_stream, open_runtime_dashboard, FollowSummary,
};
use crate::loopback::build_loopback_remote_client;

pub async fn run_remote_follow_scenarios() -> Result<Vec<FollowSummary>, String> {
    let mut client = build_loopback_remote_client();
    client.handshake()?;

    // Create the job before following it. Following a hard-coded `JobId(1)` could never observe
    // progress, because no such job existed: the scenario was asserting against an empty store.
    let accepted = client.send_operation(
        "scenario-follow-apply",
        caly_api::Operation::Profile(caly_api::ProfileOp::Apply {
            request: caly_api::ApplyRequest {
                profile_id: caly_api::ProfileId("demo-follow-profile".to_owned()),
                dry_run: false,
                strict: false,
            },
        }),
        // A key, because `profile.apply` declares `Idempotency::Required` and the daemon refuses to
        // guess one (`ADR-037 §2.3`).
        Some("scenario-follow-apply".to_owned()),
    )?;
    let job_id = match accepted {
        caly_api::OperationResult::Accepted(accepted) => accepted.job_id,
        other => return Err(format!("expected an accepted job, got {other:?}")),
    };
    if !client.process_next_job()? {
        return Err("the follow job was not processed".to_owned());
    }

    let query = follow_job_once_query(&mut client, job_id, None)?;
    let stream = follow_job_once_stream(&mut client, job_id, None)?;
    let _opened = open_runtime_dashboard(&mut client)?;
    Ok(vec![query, stream])
}

pub async fn run_facade_parity_scenario() -> Result<crate::parity::ParityReport, caly_api::ApiError>
{
    // One daemon, two access paths: the local façade and the loopback remote must agree.
    let daemon = caly_daemon::DaemonApp::bootstrap(caly_daemon::DaemonBootstrapConfig {
        instance_id: "parity-daemon".to_owned(),
        protocol_version: caly_api::ProtocolVersion { major: 1, minor: 0 },
        recover_on_start: false,
    });
    run_basic_loopback_parity(&daemon).await
}

pub async fn run_contract_bundle() -> Result<crate::contract::ContractReport, String> {
    run_loopback_remote_contract().await
}

pub async fn run_follow_bundle() -> Result<FollowSummary, String> {
    run_follow_smoke().await
}
