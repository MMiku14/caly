use caly_api::{
    Accepted, ApplyRequest, AutomationJobView, ConnectionId, ConnectionPage, ConnectionQuery,
    CoreInspection, CoreInstallView, DiagnosticsOp, DoctorReport, DoctorRequest, JobEventsRequest,
    JobFollowRequest, JobId, Operation, OperationResult, PatchAutomationJob, ProfileSummary,
    ProfileView, RecoveryStatusView, RuntimeOp, RuntimeStatus, RuntimeSubscription, StreamId,
    WatchOpened,
};
use caly_ipc::{
    make_header, ClientFrame, ClientHello, ClientSession, ClientSessionConfig, Compression,
    Encoding, ServerFrame, ServerHelloAck, StreamFrame,
};

pub trait RemoteTransport {
    fn send_hello(&mut self, hello: ClientHello) -> Result<ServerHelloAck, String>;
    fn send_frame(
        &mut self,
        frame: ClientFrame,
        is_control_message: bool,
    ) -> Result<Vec<ServerFrame>, String>;
    fn pull_stream(
        &mut self,
        stream_id: StreamId,
        from_seq_exclusive: Option<u64>,
    ) -> Result<Vec<StreamFrame>, String>;
    fn close(&mut self) -> Result<(), String>;

    fn process_next_job(&mut self) -> Result<bool, String> {
        Ok(false)
    }

    fn seed_recovery_fixture(&mut self, _profile_id: String) -> Result<usize, String> {
        Ok(0)
    }
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct RemoteSnapshot {
    pub session_state: caly_ipc::ClientSessionState,
    pub open_stream_count: usize,
    pub daemon_instance_id: Option<String>,
}

pub struct RemoteSessionClient<T: RemoteTransport> {
    pub session: ClientSession,
    pub transport: T,
}

impl<T: RemoteTransport> RemoteSessionClient<T> {
    pub fn new(config: ClientSessionConfig, transport: T) -> Self {
        Self {
            session: ClientSession::new(config),
            transport,
        }
    }

    pub fn handshake(&mut self) -> Result<(), String> {
        let hello = self.session.build_hello();
        let ack = self.transport.send_hello(hello)?;
        self.session.apply_hello_ack(&ack).map_err(|e| e.summary)
    }

    /// The request deadline a façade call gets when the caller did not set one.
    pub const DEFAULT_REQUEST_DEADLINE_MS: u64 = 30_000;

    /// Send one operation and hand back the daemon's answer with its **error identity intact**.
    ///
    /// `RFC-0002 §4.1` requires `ErrorCode` to be shared between Local and Remote, and `ADR-020`
    /// makes the façade the boundary where errors are normalised. The façade used to route through
    /// a `Result<_, String>` and then wrap that string in a fresh `Unavailable / Internal`, which
    /// meant a refusal the daemon typed as `CONFLICT` reached a remote caller as a retryable
    /// transport failure — and `docs/guides/ERRORS.md`'s whole premise (stable codes, exit-code mapping)
    /// was unreachable over the only path a CLI actually uses.
    pub fn send_operation_checked(
        &mut self,
        ctx: &caly_api::Ctx,
        operation: Operation,
    ) -> Result<OperationResult, Box<caly_api::ApiError>> {
        let trace_id = ctx.trace_id.clone();
        let deadline_ms = ctx.deadline_ms.unwrap_or(Self::DEFAULT_REQUEST_DEADLINE_MS);
        let frame = self
            .session
            .make_request(
                // The caller's trace, verbatim. The façade used to pass its own per-method literal
                // ("remote-profile-apply" and friends) here, which *replaced* `ctx.trace_id` for
                // everything the daemon then recorded — a violation of `RFC-0002 §6.3`
                // (「`trace_id` MUST 在日志、错误、Job、IPC 之间保持一致」) that only the remote path
                // could commit, because `LocalFacade` does forward the context.
                trace_id.0.clone(),
                operation,
                Some(deadline_ms),
                ctx.expected_revision,
                ctx.idempotency_key.clone(),
                Some(ctx.io_budget.clone()),
            )
            .map_err(|error| transport_failure(&trace_id, error.summary))?;
        let mut result = None;
        for frame in self
            .transport
            .send_frame(frame, true)
            .map_err(|message| transport_failure(&trace_id, message))?
        {
            self.session
                .observe_server_frame(&frame)
                .map_err(|error| transport_failure(&trace_id, error.summary))?;
            if let ServerFrame::Response(response) = frame {
                // The daemon's own `ApiError`, forwarded whole: code, category, retryability,
                // remediation and diagnostics all survive the round trip.
                result = Some(response.result.map_err(Box::new));
            }
        }
        result.unwrap_or_else(|| {
            Err(transport_failure(
                &trace_id,
                "remote operation returned no response frame",
            ))
        })
    }

    /// The string-shaped form, kept for the report builders (`contract.rs`, the scenario suite and
    /// the CLI driver) whose cases are `Result<_, String>` by design.
    ///
    /// Flattening an `ApiError` to its summary is lossy on purpose here: these are human-facing
    /// evidence lines. The **façade** never uses this — `send_operation_checked` is the path a
    /// program reads, and it keeps the daemon's code, category, retry hint, remediation and
    /// diagnostics intact (`RFC-0002 §4.1` shares `ErrorCode`; a report string cannot).
    pub fn send_operation(
        &mut self,
        trace: impl Into<String>,
        operation: Operation,
        idempotency_key: Option<String>,
    ) -> Result<OperationResult, String> {
        self.send_operation_typed(trace, operation, idempotency_key)
            .map_err(|error| error.summary)
    }

    fn send_operation_typed(
        &mut self,
        trace: impl Into<String>,
        operation: Operation,
        idempotency_key: Option<String>,
    ) -> Result<OperationResult, Box<caly_api::ApiError>> {
        let tag: String = trace.into();
        let trace_id = caly_common::TraceId::new(tag.clone());
        let frame = self
            .session
            .make_request(
                tag,
                operation,
                Some(Self::DEFAULT_REQUEST_DEADLINE_MS),
                None,
                idempotency_key,
                None,
            )
            .map_err(|error| transport_failure(&trace_id, error.summary))?;
        let mut result = None;
        for frame in self
            .transport
            .send_frame(frame, true)
            .map_err(|message| transport_failure(&trace_id, message))?
        {
            self.session
                .observe_server_frame(&frame)
                .map_err(|error| transport_failure(&trace_id, error.summary))?;
            if let ServerFrame::Response(response) = frame {
                result = Some(response.result.map_err(Box::new));
            }
        }
        result.unwrap_or_else(|| {
            Err(transport_failure(
                &trace_id,
                "remote operation returned no response frame",
            ))
        })
    }

    pub fn submit_apply(
        &mut self,
        request: ApplyRequest,
        idempotency_key: Option<String>,
    ) -> Result<Accepted, String> {
        let result = self.send_operation(
            "remote-profile-apply",
            Operation::Profile(caly_api::ProfileOp::Apply { request }),
            idempotency_key,
        )?;
        match result {
            OperationResult::Accepted(value) => Ok(value),
            other => Err(format!("unexpected apply result: {:?}", other)),
        }
    }

    /// `open_runtime_stream` with the caller's context forwarded, and the daemon's refusal kept intact.
    ///
    /// The stream-open path used to be the one place the façade still went through the string-shaped
    /// wrapper, so an `Unavailable` there was indistinguishable from a refusal by the daemon. Round 9
    /// left it as a documented, counted exception; this closes it.
    pub fn open_runtime_stream_checked(
        &mut self,
        ctx: &caly_api::Ctx,
        subscription: RuntimeSubscription,
    ) -> Result<WatchOpened, Box<caly_api::ApiError>> {
        let kind = caly_ipc::stream_kind_for_subscription(subscription.clone());
        let opened = self.send_and_expect_watch(
            ctx,
            Operation::Runtime(RuntimeOp::Watch { subscription }),
            "runtime watch",
        )?;
        self.session.register_stream(opened.stream_id, kind);
        Ok(opened)
    }

    /// `open_job_follow_stream` with the caller's context forwarded, refusal intact.
    pub fn open_job_follow_stream_checked(
        &mut self,
        ctx: &caly_api::Ctx,
        request: JobFollowRequest,
    ) -> Result<WatchOpened, Box<caly_api::ApiError>> {
        let opened = self.send_and_expect_watch(
            ctx,
            Operation::Diagnostics(DiagnosticsOp::FollowJobStream { request }),
            "job follow stream",
        )?;
        self.session
            .register_stream(opened.stream_id, caly_ipc::StreamKind::Job);
        Ok(opened)
    }

    /// Read one bounded page of a job's retained event lines, keeping the daemon's error identity.
    pub fn read_job_events(
        &mut self,
        ctx: &caly_api::Ctx,
        request: JobEventsRequest,
    ) -> Result<caly_api::JobEventsView, Box<caly_api::ApiError>> {
        let result = self.send_operation_checked(
            ctx,
            Operation::Diagnostics(DiagnosticsOp::ReadJobEvents { request }),
        )?;
        match result {
            OperationResult::JobEvents(view) => Ok(view),
            other => Err(Box::new(caly_api::ApiError::internal(
                format!("unexpected job events result: {other:?}"),
                ctx.trace_id.clone(),
            ))),
        }
    }

    fn send_and_expect_watch(
        &mut self,
        ctx: &caly_api::Ctx,
        operation: Operation,
        what: &str,
    ) -> Result<WatchOpened, Box<caly_api::ApiError>> {
        match self.send_operation_checked(ctx, operation)? {
            OperationResult::WatchOpened(opened) => Ok(opened),
            other => Err(Box::new(caly_api::ApiError::internal(
                format!("unexpected {what} result: {other:?}"),
                ctx.trace_id.clone(),
            ))),
        }
    }

    pub fn open_runtime_stream(
        &mut self,
        subscription: RuntimeSubscription,
    ) -> Result<WatchOpened, String> {
        let result = self.send_operation(
            "remote-open-runtime-stream",
            Operation::Runtime(RuntimeOp::Watch {
                subscription: subscription.clone(),
            }),
            None,
        )?;
        match result {
            OperationResult::WatchOpened(opened) => {
                self.session.register_stream(
                    opened.stream_id,
                    caly_ipc::stream_kind_for_subscription(subscription),
                );
                Ok(opened)
            }
            other => Err(format!(
                "unexpected runtime stream open result: {:?}",
                other
            )),
        }
    }

    pub fn open_job_follow_stream(
        &mut self,
        request: JobFollowRequest,
    ) -> Result<WatchOpened, String> {
        let result = self.send_operation(
            "remote-open-job-follow-stream",
            Operation::Diagnostics(DiagnosticsOp::FollowJobStream {
                request: request.clone(),
            }),
            None,
        )?;
        match result {
            OperationResult::WatchOpened(opened) => {
                self.session
                    .register_stream(opened.stream_id, caly_ipc::StreamKind::Job);
                Ok(opened)
            }
            other => Err(format!(
                "unexpected job follow stream open result: {:?}",
                other
            )),
        }
    }

    pub fn pull_stream_once(
        &mut self,
        stream_id: StreamId,
        from_seq_exclusive: Option<u64>,
    ) -> Result<Vec<StreamFrame>, String> {
        let frames = self.transport.pull_stream(stream_id, from_seq_exclusive)?;
        for frame in &frames {
            self.session
                .observe_stream_frame(frame)
                .map_err(|e| e.summary)?;
        }
        Ok(frames)
    }

    pub fn ack_stream_if_needed(
        &mut self,
        stream_id: StreamId,
    ) -> Result<Option<ClientFrame>, String> {
        let stream = self
            .session
            .streams
            .get(&stream_id.0)
            .ok_or_else(|| format!("unknown stream id: {}", stream_id.0))?;
        let upto = match stream.expected_resume_from() {
            Some(value) => value,
            None => return Ok(None),
        };
        let ack = self
            .session
            .make_stream_ack(stream_id, upto)
            .map_err(|e| e.summary)?;
        Ok(Some(ack))
    }

    /// Follow one job **on behalf of a caller**, so the caller's trace id and CAS context travel.
    ///
    /// This is the variant the façade uses. [`Self::follow_job_query`] stays for the report builders,
    /// which have no `Ctx` and label the request with its operation name instead.
    pub fn follow_job_query_with_ctx(
        &mut self,
        ctx: &caly_api::Ctx,
        job_id: JobId,
        from_event_index: Option<u64>,
    ) -> Result<caly_api::JobFollowView, Box<caly_api::ApiError>> {
        let result = self.send_operation_checked(
            ctx,
            Operation::Diagnostics(DiagnosticsOp::FollowJob {
                request: JobFollowRequest {
                    job_id,
                    from_event_index,
                },
            }),
        )?;
        match result {
            OperationResult::JobFollow(view) => Ok(view),
            other => Err(Box::new(caly_api::ApiError::internal(
                format!("unexpected follow result: {other:?}"),
                ctx.trace_id.clone(),
            ))),
        }
    }

    pub fn follow_job_query(
        &mut self,
        job_id: JobId,
        from_event_index: Option<u64>,
    ) -> Result<caly_api::JobFollowView, Box<caly_api::ApiError>> {
        let result = self.send_operation_typed(
            "remote-follow-job-query",
            Operation::Diagnostics(DiagnosticsOp::FollowJob {
                request: JobFollowRequest {
                    job_id,
                    from_event_index,
                },
            }),
            None,
        )?;
        match result {
            OperationResult::JobFollow(view) => Ok(view),
            other => Err(Box::new(caly_api::ApiError::internal(
                format!("unexpected recovery status result: {other:?}"),
                caly_common::TraceId::new("remote-follow-job-query"),
            ))),
        }
    }

    pub fn profile_list(&mut self) -> Result<Vec<ProfileSummary>, String> {
        let result = self.send_operation(
            "remote-profile-list",
            Operation::Profile(caly_api::ProfileOp::List),
            None,
        )?;
        match result {
            OperationResult::ProfileList(value) => Ok(value),
            other => Err(format!("unexpected profile list result: {:?}", other)),
        }
    }

    pub fn profile_get(&mut self, profile_id: caly_api::ProfileId) -> Result<ProfileView, String> {
        let result = self.send_operation(
            "remote-profile-get",
            Operation::Profile(caly_api::ProfileOp::Get { profile_id }),
            None,
        )?;
        match result {
            OperationResult::ProfileView(value) => Ok(value),
            other => Err(format!("unexpected profile get result: {:?}", other)),
        }
    }

    pub fn core_list_installs(&mut self) -> Result<Vec<CoreInstallView>, String> {
        let result = self.send_operation(
            "remote-core-list-installs",
            Operation::Core(caly_api::CoreOp::ListInstalls),
            None,
        )?;
        match result {
            OperationResult::CoreInstallList(value) => Ok(value),
            other => Err(format!("unexpected core install list result: {:?}", other)),
        }
    }

    pub fn core_inspect(
        &mut self,
        core_install_id: caly_api::CoreInstallId,
    ) -> Result<CoreInspection, String> {
        let result = self.send_operation(
            "remote-core-inspect",
            Operation::Core(caly_api::CoreOp::Inspect { core_install_id }),
            None,
        )?;
        match result {
            OperationResult::CoreInspection(value) => Ok(value),
            other => Err(format!("unexpected core inspect result: {:?}", other)),
        }
    }

    pub fn runtime_status(&mut self) -> Result<RuntimeStatus, String> {
        let result = self.send_operation(
            "remote-runtime-status",
            Operation::Runtime(RuntimeOp::Status),
            None,
        )?;
        match result {
            OperationResult::RuntimeStatus(value) => Ok(value),
            other => Err(format!("unexpected runtime status result: {:?}", other)),
        }
    }

    pub fn runtime_connections(
        &mut self,
        query: ConnectionQuery,
    ) -> Result<ConnectionPage, String> {
        let result = self.send_operation(
            "remote-runtime-connections",
            Operation::Runtime(RuntimeOp::Connections { query }),
            None,
        )?;
        match result {
            OperationResult::ConnectionPage(value) => Ok(value),
            other => Err(format!(
                "unexpected runtime connections result: {:?}",
                other
            )),
        }
    }

    pub fn runtime_close_connection(
        &mut self,
        connection_id: ConnectionId,
    ) -> Result<Accepted, String> {
        let result = self.send_operation(
            "remote-runtime-close-connection",
            Operation::Runtime(RuntimeOp::CloseConnection { connection_id }),
            None,
        )?;
        match result {
            OperationResult::Accepted(value) => Ok(value),
            other => Err(format!(
                "unexpected runtime close-connection result: {:?}",
                other
            )),
        }
    }

    pub fn recovery_status(&mut self) -> Result<RecoveryStatusView, String> {
        let result = self.send_operation(
            "remote-recovery-status",
            Operation::Diagnostics(DiagnosticsOp::RecoveryStatus),
            None,
        )?;
        match result {
            OperationResult::RecoveryStatus(value) => Ok(value),
            other => Err(format!("unexpected recovery status result: {:?}", other)),
        }
    }

    pub fn doctor(&mut self, include_runtime: bool) -> Result<DoctorReport, String> {
        let result = self.send_operation(
            "remote-doctor",
            Operation::Diagnostics(DiagnosticsOp::Doctor {
                request: DoctorRequest { include_runtime },
            }),
            None,
        )?;
        match result {
            OperationResult::DoctorReport(value) => Ok(value),
            other => Err(format!("unexpected doctor result: {:?}", other)),
        }
    }

    pub fn support_bundle(&mut self) -> Result<Accepted, String> {
        let result = self.send_operation(
            "remote-support-bundle",
            Operation::Diagnostics(DiagnosticsOp::SupportBundle),
            None,
        )?;
        match result {
            OperationResult::Accepted(value) => Ok(value),
            other => Err(format!("unexpected support bundle result: {:?}", other)),
        }
    }

    pub fn automation_list_jobs(&mut self) -> Result<Vec<AutomationJobView>, String> {
        let result = self.send_operation(
            "remote-automation-list",
            Operation::Automation(caly_api::AutomationOp::ListJobs),
            None,
        )?;
        match result {
            OperationResult::AutomationJobs(value) => Ok(value),
            other => Err(format!("unexpected automation list result: {:?}", other)),
        }
    }

    pub fn automation_patch_job(
        &mut self,
        request: PatchAutomationJob,
    ) -> Result<Accepted, String> {
        let result = self.send_operation(
            "remote-automation-patch",
            Operation::Automation(caly_api::AutomationOp::PatchJob { request }),
            None,
        )?;
        match result {
            OperationResult::Accepted(value) => Ok(value),
            other => Err(format!("unexpected automation patch result: {:?}", other)),
        }
    }

    pub fn process_next_job(&mut self) -> Result<bool, String> {
        self.transport.process_next_job()
    }

    pub fn seed_recovery_fixture(
        &mut self,
        profile_id: impl Into<String>,
    ) -> Result<usize, String> {
        self.transport.seed_recovery_fixture(profile_id.into())
    }

    pub fn snapshot(&self) -> RemoteSnapshot {
        let snapshot = self.session.snapshot();
        RemoteSnapshot {
            session_state: snapshot.state,
            open_stream_count: snapshot.streams.len(),
            daemon_instance_id: snapshot.daemon.map(|it| it.instance_id),
        }
    }

    pub fn encode_probe_header(&self, payload_len: usize) -> caly_ipc::FrameHeader {
        make_header(payload_len, Encoding::Json, Compression::None)
    }

    pub fn close(&mut self) -> Result<(), String> {
        self.transport.close()?;
        self.session.close();
        Ok(())
    }
}

/// A failure of the *call*, not of the request: no answer arrived, or the session itself broke.
/// Everything the daemon answered with keeps its own identity instead.
fn transport_failure(
    trace_id: &caly_common::TraceId,
    summary: impl Into<String>,
) -> Box<caly_api::ApiError> {
    // Boxed on purpose: this error crosses several `Result`s inside `RemoteSessionClient`, and the
    // unboxed variant is large enough that clippy counts every one of them as a `result_large_err`.
    // The façade boundary unboxes once, so the public shape is unchanged.
    Box::new(caly_api::ApiError::new(
        caly_api::ErrorCode::Unavailable,
        caly_api::ErrorCategory::Internal,
        true,
        summary,
        trace_id.clone(),
    ))
}
