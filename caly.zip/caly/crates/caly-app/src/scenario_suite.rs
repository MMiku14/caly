use caly_api::{CalyFacade, JobFollowRequest, RuntimeSubscription};
use caly_daemon::{
    DaemonApp, DaemonBootstrapConfig, LocalFacade, LoopbackHarness, LoopbackHarnessConfig,
};
use caly_ipc::StreamPayload;

use crate::contract::{
    run_basic_loopback_parity, run_follow_smoke, run_job_follow_contract,
    run_loopback_remote_contract, run_system_contract, ContractReport,
};
use crate::follow::{follow_job_once_query, follow_job_once_stream};
use crate::loopback::{build_loopback_remote_client, build_loopback_remote_client_with};
use crate::remote_facade::RemoteFacade;
use crate::wire_probe::run_basic_wire_probe;

#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub enum ScenarioStatus {
    Passed,
    Failed,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct ScenarioEntry {
    pub name: String,
    pub status: ScenarioStatus,
    pub detail: String,
}

#[derive(Clone, Debug, Default, Eq, PartialEq)]
pub struct ScenarioSuite {
    pub entries: Vec<ScenarioEntry>,
}

impl ScenarioSuite {
    pub fn push(
        &mut self,
        name: impl Into<String>,
        status: ScenarioStatus,
        detail: impl Into<String>,
    ) {
        self.entries.push(ScenarioEntry {
            name: name.into(),
            status,
            detail: detail.into(),
        });
    }

    pub fn all_passed(&self) -> bool {
        self.entries
            .iter()
            .all(|entry| matches!(entry.status, ScenarioStatus::Passed))
    }

    pub fn extend_contract(&mut self, prefix: &str, report: ContractReport) {
        for case in report.cases {
            self.push(
                format!("{}.{}", prefix, case.name),
                if case.passed {
                    ScenarioStatus::Passed
                } else {
                    ScenarioStatus::Failed
                },
                case.detail,
            );
        }
    }
}

pub fn run_handshake_scenario() -> Result<ScenarioSuite, String> {
    let mut suite = ScenarioSuite::default();
    let mut harness = LoopbackHarness::new(LoopbackHarnessConfig::default());
    harness.handshake()?;
    let snapshot = harness.snapshot();
    suite.push(
        "handshake.active-client-session",
        if matches!(snapshot.client_state, caly_ipc::ClientSessionState::Active) {
            ScenarioStatus::Passed
        } else {
            ScenarioStatus::Failed
        },
        format!("snapshot={:?}", snapshot),
    );
    Ok(suite)
}

pub fn run_runtime_watch_scenario() -> Result<ScenarioSuite, String> {
    let mut suite = ScenarioSuite::default();
    let mut harness = LoopbackHarness::new(LoopbackHarnessConfig::default());
    harness.handshake()?;
    let accepted = harness.submit_apply(
        caly_api::ApplyRequest {
            profile_id: caly_api::ProfileId("runtime-watch-scenario".to_owned()),
            dry_run: false,
            strict: false,
        },
        Some("runtime-watch-scenario".to_owned()),
    )?;
    let processed = harness.process_next_job()?;
    let opened = harness.open_runtime_stream(RuntimeSubscription::Dashboard)?;
    let frames = harness.follow_stream(opened.stream_id, None)?;
    let has_command_accepted = frames
        .iter()
        .any(|frame| matches!(frame.payload, StreamPayload::CommandAccepted { .. }));
    let has_runtime_state = frames
        .iter()
        .any(|frame| matches!(frame.payload, StreamPayload::RuntimeState { .. }));
    let has_deployment_event = frames
        .iter()
        .any(|frame| matches!(frame.payload, StreamPayload::DeploymentEvent { .. }));
    let has_snapshot_event = frames
        .iter()
        .any(|frame| matches!(frame.payload, StreamPayload::SnapshotCommitted { .. }));
    let ack_result = harness.ack_stream(opened.stream_id, 0);
    suite.push(
        "runtime.watch.open",
        if processed {
            ScenarioStatus::Passed
        } else {
            ScenarioStatus::Failed
        },
        format!(
            "accepted_job={} stream_id={} frames={}",
            accepted.job_id.0,
            opened.stream_id.0,
            frames.len()
        ),
    );
    suite.push(
        "runtime.watch.structured-command-accepted",
        if has_command_accepted {
            ScenarioStatus::Passed
        } else {
            ScenarioStatus::Failed
        },
        format!("frames={:?}", frames),
    );
    suite.push(
        "runtime.watch.structured-runtime-state",
        if has_runtime_state {
            ScenarioStatus::Passed
        } else {
            ScenarioStatus::Failed
        },
        format!("frames={:?}", frames),
    );
    suite.push(
        "runtime.watch.structured-deployment",
        if has_deployment_event {
            ScenarioStatus::Passed
        } else {
            ScenarioStatus::Failed
        },
        format!("frames={:?}", frames),
    );
    suite.push(
        "runtime.watch.structured-snapshot",
        if has_snapshot_event {
            ScenarioStatus::Passed
        } else {
            ScenarioStatus::Failed
        },
        format!("frames={:?}", frames),
    );
    suite.push(
        "runtime.watch.ack-path",
        if ack_result.is_ok() {
            ScenarioStatus::Passed
        } else {
            ScenarioStatus::Failed
        },
        format!("ack_result={:?}", ack_result),
    );
    Ok(suite)
}

/// Follow one job both ways the protocol offers — the `Query` snapshot and the stream — and compare
/// what a caller ends up reading.
///
/// It takes no job id on purpose. It used to take one and ignore it (`_job_id`) while the CLI driver
/// passed whatever the operator typed, which read like "follow this job" and was in fact "follow the
/// job this scenario happens to create". A parameter nobody can honour is worse than no parameter.
pub fn run_job_follow_query_stream_scenario() -> Result<ScenarioSuite, String> {
    let mut suite = ScenarioSuite::default();
    let mut remote = build_loopback_remote_client();
    remote.handshake()?;
    let accepted = remote.submit_apply(
        caly_api::ApplyRequest {
            profile_id: caly_api::ProfileId("job-follow-scenario-profile".to_owned()),
            dry_run: false,
            strict: false,
        },
        Some("job-follow-scenario".to_owned()),
    )?;
    let processed = remote.process_next_job()?;
    suite.push(
        "job-follow.process",
        if processed {
            ScenarioStatus::Passed
        } else {
            ScenarioStatus::Failed
        },
        format!("accepted_job={} processed={}", accepted.job_id.0, processed),
    );

    let query = follow_job_once_query(&mut remote, accepted.job_id, None)?;
    suite.push(
        "job-follow.query",
        if !query.reset_required
            && query
                .lines
                .iter()
                .any(|line| line.contains("state=completed"))
        {
            ScenarioStatus::Passed
        } else {
            ScenarioStatus::Failed
        },
        format!("summary={:?}", query),
    );

    let stream = follow_job_once_stream(&mut remote, accepted.job_id, None)?;
    suite.push(
        "job-follow.stream",
        if !stream.reset_required && !stream.lines.is_empty() {
            ScenarioStatus::Passed
        } else {
            ScenarioStatus::Failed
        },
        format!("summary={:?}", stream),
    );

    Ok(suite)
}

pub fn run_wire_probe_scenario() -> Result<ScenarioSuite, String> {
    let mut suite = ScenarioSuite::default();
    let probe = run_basic_wire_probe()?;
    suite.push(
        "wire-probe.hello",
        if probe.hello_payload_len > 0 {
            ScenarioStatus::Passed
        } else {
            ScenarioStatus::Failed
        },
        format!("probe={:?}", probe),
    );
    suite.push(
        "wire-probe.response",
        if probe.response_frame_count > 0 {
            ScenarioStatus::Passed
        } else {
            ScenarioStatus::Failed
        },
        format!("probe={:?}", probe),
    );
    Ok(suite)
}

pub fn run_timeout_scenario() -> Result<ScenarioSuite, String> {
    let mut suite = ScenarioSuite::default();
    let mut harness = LoopbackHarness::new(LoopbackHarnessConfig::default());
    let result = harness.force_hello_timeout();
    suite.push(
        "session.hello-timeout",
        if result.is_ok() {
            ScenarioStatus::Passed
        } else {
            ScenarioStatus::Failed
        },
        format!("result={:?}", result),
    );
    Ok(suite)
}

pub async fn run_loopback_contract_scenario() -> Result<ScenarioSuite, String> {
    let report = run_loopback_remote_contract().await?;
    let mut suite = ScenarioSuite::default();
    suite.extend_contract("loopback-contract", report);
    Ok(suite)
}

pub fn run_apply_execution_scenario() -> Result<ScenarioSuite, String> {
    let mut suite = ScenarioSuite::default();
    let mut harness = LoopbackHarness::new(LoopbackHarnessConfig::default());
    harness.handshake()?;
    let accepted = harness.submit_apply(
        caly_api::ApplyRequest {
            profile_id: caly_api::ProfileId("apply-execution-scenario".to_owned()),
            dry_run: false,
            strict: false,
        },
        Some("apply-execution-scenario".to_owned()),
    )?;
    let processed = harness.process_next_job()?;
    let follow = harness.follow_job_query(accepted.job_id, None)?;
    let runtime = harness.runtime_status()?;
    let connections = harness.runtime_connections(caly_api::ConnectionQuery {
        page: caly_api::PageRequest {
            cursor: None,
            limit: 16,
        },
    })?;
    let close_result = if let Some(first) = connections.items.first() {
        let accepted = harness.close_connection(first.id.clone())?;
        let processed = harness.process_next_job()?;
        Some((accepted, processed))
    } else {
        None
    };
    let profiles = harness.profile_list()?;
    let active_profile = profiles.iter().find(|profile| profile.active).cloned();
    let profile_view = if let Some(active) = &active_profile {
        Some(harness.profile_get(active.id.clone())?)
    } else {
        None
    };
    let installs = harness.core_list_installs()?;
    let active_install = installs.iter().find(|install| install.active).cloned();
    let core_inspect = if let Some(active) = &active_install {
        Some(harness.core_inspect(active.id.clone())?)
    } else {
        None
    };
    let recovery = harness.recovery_status()?;

    suite.push(
        "apply.execution.processed",
        if processed {
            ScenarioStatus::Passed
        } else {
            ScenarioStatus::Failed
        },
        format!("accepted_job={} processed={}", accepted.job_id.0, processed),
    );
    suite.push(
        "apply.execution.follow-completed",
        if follow.state == "completed" {
            ScenarioStatus::Passed
        } else {
            ScenarioStatus::Failed
        },
        format!("follow={:?}", follow),
    );
    suite.push(
        "apply.execution.runtime-snapshot",
        if runtime.active_snapshot.is_some() {
            ScenarioStatus::Passed
        } else {
            ScenarioStatus::Failed
        },
        format!("runtime={:?}", runtime),
    );
    suite.push(
        "apply.execution.runtime-connections",
        if !connections.items.is_empty() {
            ScenarioStatus::Passed
        } else {
            ScenarioStatus::Failed
        },
        format!("connections={:?}", connections),
    );
    suite.push(
        "apply.execution.close-connection",
        if close_result
            .as_ref()
            .map(|(_, processed)| *processed)
            .unwrap_or(false)
        {
            ScenarioStatus::Passed
        } else {
            ScenarioStatus::Failed
        },
        format!("close_result={:?}", close_result),
    );
    suite.push(
        "apply.execution.profile-active",
        if active_profile.is_some()
            && profile_view
                .as_ref()
                .map(|view| view.summary.active)
                .unwrap_or(false)
        {
            ScenarioStatus::Passed
        } else {
            ScenarioStatus::Failed
        },
        format!("profiles={:?} profile_view={:?}", profiles, profile_view),
    );
    suite.push(
        "apply.execution.core-active",
        if active_install.is_some()
            && core_inspect
                .as_ref()
                .map(|view| view.install.active)
                .unwrap_or(false)
        {
            ScenarioStatus::Passed
        } else {
            ScenarioStatus::Failed
        },
        format!("installs={:?} core_inspect={:?}", installs, core_inspect),
    );
    suite.push(
        "apply.execution.recovery-view",
        if recovery.active_snapshot.is_some() && recovery.decision_count == 0 {
            ScenarioStatus::Passed
        } else {
            ScenarioStatus::Failed
        },
        format!("recovery={:?}", recovery),
    );
    Ok(suite)
}

pub fn run_support_bundle_scenario() -> Result<ScenarioSuite, String> {
    let mut suite = ScenarioSuite::default();
    let mut harness = LoopbackHarness::new(LoopbackHarnessConfig::default());
    harness.handshake()?;
    let accepted = harness.support_bundle()?;
    let processed = harness.process_next_job()?;
    let follow = harness.follow_job_query(accepted.job_id, None)?;

    suite.push(
        "support-bundle.accepted",
        if accepted.job_id.0 > 0 {
            ScenarioStatus::Passed
        } else {
            ScenarioStatus::Failed
        },
        format!("accepted={:?}", accepted),
    );
    suite.push(
        "support-bundle.processed",
        if processed {
            ScenarioStatus::Passed
        } else {
            ScenarioStatus::Failed
        },
        format!("processed={processed}"),
    );
    suite.push(
        "support-bundle.follow-visible",
        if follow.event_count > 0 {
            ScenarioStatus::Passed
        } else {
            ScenarioStatus::Failed
        },
        format!("follow={:?}", follow),
    );
    // The export has to be committed by the time the job finishes, with a log line naming the
    // object it was written to. `§9.3` is about an artifact, not about a job that succeeded.
    suite.push(
        "support-bundle.committed",
        if follow.state == "completed"
            && follow.last_stage.as_deref() == Some("bundle.committed")
            && follow.log_count > 0
            && follow.warning_count == 0
        {
            ScenarioStatus::Passed
        } else {
            ScenarioStatus::Failed
        },
        format!("follow={:?}", follow),
    );
    // The point of writing an export is that someone can read it. A scenario that stopped at
    // `bundle.committed` would still pass with a store nobody can query, so this closes the loop and
    // checks the content is a bundle rather than a blob.
    let read_back = harness.read_support_bundle(caly_api::SupportBundleReadRequest {
        digest: None,
        max_bytes: None,
    });
    let read_back_ok = matches!(
        &read_back,
        Ok(view) if view.first_section() == Some("header")
            && !view.truncated
            && view.line_count > 0
            && view.content_sha256 == view.digest
    );
    suite.push(
        "support-bundle.readback",
        if read_back_ok {
            ScenarioStatus::Passed
        } else {
            ScenarioStatus::Failed
        },
        match &read_back {
            Ok(view) => format!(
                "digest={} bytes={} lines={} sections_start={:?}",
                view.digest,
                view.byte_len,
                view.line_count,
                view.first_section()
            ),
            Err(error) => format!("readback failed: {error}"),
        },
    );
    // Reading a digest that names no object must be a refusal, not an empty bundle: an export API
    // that answers `Ok` with nothing is how "we have no diagnostics" becomes invisible.
    let missing = harness.read_support_bundle(caly_api::SupportBundleReadRequest {
        digest: Some("sha256:absent".to_owned()),
        max_bytes: None,
    });
    suite.push(
        "support-bundle.readback-missing-is-refused",
        if missing.is_err() {
            ScenarioStatus::Passed
        } else {
            ScenarioStatus::Failed
        },
        format!("{:?}", missing.map(|_| "returned a bundle")),
    );

    Ok(suite)
}

pub fn run_automation_scenario() -> Result<ScenarioSuite, String> {
    let mut suite = ScenarioSuite::default();
    let mut harness = LoopbackHarness::new(LoopbackHarnessConfig::default());
    harness.handshake()?;
    let before = harness.automation_list_jobs()?;
    let first = before
        .first()
        .cloned()
        .ok_or_else(|| "automation job list unexpectedly empty".to_owned())?;
    let accepted = harness.automation_patch_job(caly_api::PatchAutomationJob {
        job_id: first.id.clone(),
        enabled: !first.enabled,
    })?;
    let processed = harness.process_next_job()?;
    let after = harness.automation_list_jobs()?;
    let toggled = after
        .iter()
        .find(|job| job.id == first.id)
        .map(|job| job.enabled == !first.enabled)
        .unwrap_or(false);

    suite.push(
        "automation.patch.accepted",
        if accepted.job_id.0 > 0 {
            ScenarioStatus::Passed
        } else {
            ScenarioStatus::Failed
        },
        format!("accepted={:?}", accepted),
    );
    suite.push(
        "automation.patch.processed",
        if processed {
            ScenarioStatus::Passed
        } else {
            ScenarioStatus::Failed
        },
        format!("processed={processed}"),
    );
    suite.push(
        "automation.patch.visible",
        if toggled {
            ScenarioStatus::Passed
        } else {
            ScenarioStatus::Failed
        },
        format!("before={:?} after={:?}", before, after),
    );
    Ok(suite)
}

pub fn run_recovery_scan_scenario() -> Result<ScenarioSuite, String> {
    let mut suite = ScenarioSuite::default();
    let mut harness = LoopbackHarness::new(LoopbackHarnessConfig::default());
    harness.handshake()?;
    let decisions = harness.seed_recovery_fixture("recovery-scan-scenario")?;
    let doctor = harness.doctor(true)?;
    let runtime = harness.runtime_status()?;
    let opened = harness.open_runtime_stream(RuntimeSubscription::Dashboard)?;
    let frames = harness.follow_stream(opened.stream_id, None)?;
    let stream_has_recovery = frames
        .iter()
        .any(|frame| matches!(frame.payload, StreamPayload::RecoveryEvent { .. }));

    suite.push(
        "recovery.scan.seeded",
        if decisions > 0 {
            ScenarioStatus::Passed
        } else {
            ScenarioStatus::Failed
        },
        format!("decisions={decisions}"),
    );
    suite.push(
        "recovery.scan.doctor-visible",
        if doctor
            .warnings
            .iter()
            .any(|line| line.contains("recovery decision"))
        {
            ScenarioStatus::Passed
        } else {
            ScenarioStatus::Failed
        },
        format!("doctor={:?}", doctor),
    );
    suite.push(
        "recovery.scan.runtime-visible",
        if runtime.active_snapshot.is_none() {
            ScenarioStatus::Passed
        } else {
            ScenarioStatus::Failed
        },
        format!("runtime={:?}", runtime),
    );
    suite.push(
        "recovery.scan.stream-visible",
        if stream_has_recovery {
            ScenarioStatus::Passed
        } else {
            ScenarioStatus::Failed
        },
        format!("frames={:?}", frames),
    );
    Ok(suite)
}

pub async fn run_parity_scenarios() -> Result<ScenarioSuite, String> {
    // One daemon behind both façades. Each side used to bootstrap its own, which made the
    // "parity" comparison a diff of two unrelated processes.
    let daemon = DaemonApp::bootstrap(DaemonBootstrapConfig {
        instance_id: "scenario-shared-daemon".to_owned(),
        protocol_version: caly_api::ProtocolVersion { major: 1, minor: 0 },
        recover_on_start: false,
    });
    let local = LocalFacade::new(daemon.clone());

    let mut remote = build_loopback_remote_client_with(daemon.clone());
    remote.handshake()?;
    let remote_facade = RemoteFacade::new(remote);

    let mut suite = ScenarioSuite::default();

    let system = run_system_contract(&local, &remote_facade)
        .await
        .map_err(|error| error.summary)?;
    suite.extend_contract("contract", system);

    // Write-side parity first, while the daemon is still pristine: it drives four submissions
    // through each path plus two CAS probes, and every one of those items is a comparison of what a
    // caller *receives* from a write rather than from a query. `run_basic_loopback_parity` below only
    // ever reads, so without this the aggregate bundle could never see a write-path divergence.
    let write = crate::contract::run_write_parity(&daemon, "scenario-write-profile").await?;
    for item in write.items {
        suite.push(
            format!("parity.{}", item.name),
            if matches!(item.status, crate::parity::ParityStatus::Match) {
                ScenarioStatus::Passed
            } else {
                ScenarioStatus::Failed
            },
            item.detail,
        );
    }

    let parity = run_basic_loopback_parity(&daemon)
        .await
        .map_err(|error| error.summary)?;
    for item in parity.items {
        suite.push(
            format!("parity.{}", item.name),
            if matches!(item.status, crate::parity::ParityStatus::Match) {
                ScenarioStatus::Passed
            } else {
                ScenarioStatus::Failed
            },
            item.detail,
        );
    }

    Ok(suite)
}

/// The event window of a job, read back through the loopback transport: content, counters and the
/// reset a stale cursor earns.
pub fn run_job_events_scenario() -> Result<ScenarioSuite, String> {
    let mut suite = ScenarioSuite::default();
    let mut harness = LoopbackHarness::new(LoopbackHarnessConfig::default());
    harness.handshake()?;
    let accepted = harness.submit_apply(
        caly_api::ApplyRequest {
            profile_id: caly_api::ProfileId("events-profile".to_owned()),
            dry_run: false,
            strict: false,
        },
        Some("events-scenario".to_owned()),
    )?;
    let _ = harness.process_next_job()?;

    let view = harness.read_job_events(caly_api::JobEventsRequest::new(accepted.job_id))?;
    suite.push(
        "job-events.content",
        if view.events.len() >= 8
            && view
                .events
                .iter()
                .any(|line| line.contains("snapshot.committed"))
        {
            ScenarioStatus::Passed
        } else {
            ScenarioStatus::Failed
        },
        format!("lines={} state={}", view.events.len(), view.state),
    );
    suite.push(
        "job-events.counters",
        if view.next_event_index as usize == view.events.len() && !view.reset_required {
            ScenarioStatus::Passed
        } else {
            ScenarioStatus::Failed
        },
        format!(
            "next={} retained_from={} reset={}",
            view.next_event_index, view.retained_from_event_index, view.reset_required
        ),
    );
    // A window asked for past the end reports the reset instead of returning nothing.
    let past = harness.read_job_events(
        caly_api::JobEventsRequest::new(accepted.job_id).from(view.next_event_index),
    )?;
    suite.push(
        "job-events.at-end-is-empty-not-broken",
        if past.events.is_empty() && !past.reset_required {
            ScenarioStatus::Passed
        } else {
            ScenarioStatus::Failed
        },
        format!("lines={} reset={}", past.events.len(), past.reset_required),
    );

    // The reply is a page, and a page has to be walkable back into the window it came from
    // (`RFC-0002 §9`, `§11.4`; `docs/ONBOARDING_NOTES.md §4.54`).
    let mut seen: Vec<String> = Vec::new();
    let mut cursor = None;
    let mut pages = 0usize;
    let mut stranded = false;
    loop {
        let mut request = caly_api::JobEventsRequest::new(accepted.job_id).with_max_lines(3);
        request.from_event_index = cursor;
        let reply = harness.read_job_events(request)?;
        seen.extend(reply.events.iter().cloned());
        pages += 1;
        match reply.next_from_event_index {
            Some(next) => {
                // The cursor and the flag have to agree: a client that loops on one and trusts the
                // other is either stuck or stops early.
                stranded = !reply.is_truncated();
                cursor = Some(next);
            }
            None => break,
        }
        if pages > 64 {
            stranded = true;
            break;
        }
    }
    suite.push(
        "job-events.bounded-page-roundtrip",
        if !stranded && seen == view.events && pages > 1 {
            ScenarioStatus::Passed
        } else {
            ScenarioStatus::Failed
        },
        format!(
            "pages={pages} lines={} of {} truncated={stranded}",
            seen.len(),
            view.events.len()
        ),
    );
    let zero =
        harness.read_job_events(caly_api::JobEventsRequest::new(accepted.job_id).with_max_lines(0));
    let (status, detail) = match zero {
        Ok(reply) => (
            ScenarioStatus::Failed,
            format!("a zero page size returned {} line(s)", reply.events.len()),
        ),
        Err(message) => (
            if message.contains("CONFIG_INVALID") && message.contains("max_lines") {
                ScenarioStatus::Passed
            } else {
                ScenarioStatus::Failed
            },
            message,
        ),
    };
    suite.push(
        "job-events.zero-bound-refused",
        status,
        format!("{detail} — a refusal must name the field, not the daemon"),
    );
    Ok(suite)
}

/// What the daemon does when it has more work than it agreed to hold.
///
/// Two things are checked, and they are checked on **one** daemon so the comparison means something:
/// the refusal must look the same from either access path, and it must not look like work happened
/// (`RFC-0002 §4.1` for the first half, `docs/OVERLOAD_AND_RETRY_MODEL.md §3.1` for the second — see
/// `docs/ONBOARDING_NOTES.md §4.58` for what this scenario replaced).
pub async fn run_overload_scenario() -> Result<ScenarioSuite, String> {
    let mut suite = ScenarioSuite::default();
    let daemon = DaemonApp::bootstrap(DaemonBootstrapConfig {
        instance_id: "overload-scenario".to_owned(),
        protocol_version: caly_api::ProtocolVersion { major: 1, minor: 0 },
        recover_on_start: false,
    });
    let local = LocalFacade::new(daemon.clone());
    let local: &dyn CalyFacade = &local;
    let mut remote = build_loopback_remote_client_with(daemon.clone());
    remote.handshake()?;
    let remote_facade = RemoteFacade::new(remote);
    let remote: &dyn CalyFacade = &remote_facade;

    let (_, capacity) = daemon.queue_stats()?;
    assert!(capacity > 1, "the flood needs a real queue to fill");

    for index in 0..capacity {
        local
            .proxy()
            .test_delay(
                ctx(&format!("overload-fill-{index}")),
                caly_api::DelayTestRequest {
                    node_ids: vec![caly_api::NodeId(format!("node-{index}"))],
                },
            )
            .await
            .map_err(|error| format!("fill step {index} was refused early: {}", error.summary))?;
    }
    let (depth, _) = daemon.queue_stats()?;
    suite.push(
        "overload.queue-is-exactly-full",
        if depth == capacity {
            ScenarioStatus::Passed
        } else {
            ScenarioStatus::Failed
        },
        format!("depth={depth} capacity={capacity}"),
    );

    // Sampled *after* the flood: the accepted commands legitimately moved the revision, and the
    // claim under test is only that a refusal does not move it further.
    let revision_before = local
        .system()
        .status(ctx("overload-before"))
        .await
        .map_err(|error| error.summary)?
        .state_revision;

    let refused = local
        .proxy()
        .test_delay(
            ctx("overload-refused"),
            caly_api::DelayTestRequest {
                node_ids: vec![caly_api::NodeId("late".to_owned())],
            },
        )
        .await
        .err()
        .map(|error| identity(&error));
    let remote_refused = remote
        .proxy()
        .test_delay(
            ctx("overload-refused"),
            caly_api::DelayTestRequest {
                node_ids: vec![caly_api::NodeId("late".to_owned())],
            },
        )
        .await
        .err()
        .map(|error| identity(&error));
    let refused_identically = refused
        .as_ref()
        .zip(remote_refused.as_ref())
        .is_some_and(|(left, right)| left == right && left.contains("UNAVAILABLE"));
    suite.push(
        "overload.refused-on-both-paths-identically",
        if refused_identically {
            ScenarioStatus::Passed
        } else {
            ScenarioStatus::Failed
        },
        format!("local={refused:?} remote={remote_refused:?}"),
    );
    suite.push(
        "overload.refusal-says-what-to-do",
        match &refused {
            Some(text) => {
                if text.contains("error=queue_full")
                    && text.contains("retry_hint=RetryLater")
                    && text.contains("queue_cap=")
                    && text.contains("retry after current queued work drains")
                {
                    ScenarioStatus::Passed
                } else {
                    ScenarioStatus::Failed
                }
            }
            None => ScenarioStatus::Failed,
        },
        refused.clone().unwrap_or_default(),
    );

    let revision_after = local
        .system()
        .status(ctx("overload-after"))
        .await
        .map_err(|error| error.summary)?
        .state_revision;
    let (depth_after, _) = daemon.queue_stats()?;
    suite.push(
        "overload.refusal-produced-no-side-effect",
        if revision_after == revision_before && depth_after == capacity {
            ScenarioStatus::Passed
        } else {
            ScenarioStatus::Failed
        },
        format!(
            "revision {revision_before} -> {revision_after}, depth {capacity} -> {depth_after}"
        ),
    );

    let doctor = remote
        .diagnostics()
        .doctor(
            ctx("overload-doctor"),
            caly_api::DoctorRequest {
                include_runtime: false,
            },
        )
        .await
        .map_err(|error| error.summary)?;
    suite.push(
        "overload.visible-in-doctor-over-the-transport",
        if doctor
            .warnings
            .iter()
            .any(|line| line.contains("overload queue_full: 2 occurrence(s)"))
            && !doctor.errors.iter().any(|line| line.contains("overload"))
        {
            ScenarioStatus::Passed
        } else {
            ScenarioStatus::Failed
        },
        format!("warnings={:?}", doctor.warnings),
    );
    Ok(suite)
}

/// The full public identity of a refusal, as a comparable string. `detail` is included on purpose:
/// the numbers in it are the same on both paths precisely because a refusal changed nothing.
fn identity(error: &caly_api::ApiError) -> String {
    format!(
        "{} {:?} retryable={} {} | {} | {}",
        error.code.as_str(),
        error.category,
        error.retryable,
        error.summary,
        error.detail.clone().unwrap_or_default(),
        error.remediation.clone().unwrap_or_default(),
    )
}

fn ctx(tag: &str) -> caly_api::Ctx {
    caly_api::Ctx::new(
        caly_common::TraceId::new(tag.to_owned()),
        caly_common::Actor::Cli,
    )
}

/// One job, followed through both façades, against **one** daemon.
///
/// Two details are load-bearing, and both are here because the first version of this scenario got
/// them wrong (`docs/ONBOARDING_NOTES.md §4.55`):
///
/// * it used to follow `JobId(1)` on two *separately bootstrapped* daemons, where no job 1 existed —
///   so as soon as the daemon started refusing unknown ids (round 10) the whole smoke bundle returned
///   `Err("no such job: 1")`, and nothing judged that either;
/// * a job id from one daemon means nothing to another, so both façades have to be wrapped around the
///   same `DaemonApp` for the comparison to be about the access path rather than about the data.
pub async fn run_job_follow_contract_scenario() -> Result<ScenarioSuite, String> {
    let daemon = DaemonApp::bootstrap(DaemonBootstrapConfig {
        instance_id: "follow-contract-shared".to_owned(),
        protocol_version: caly_api::ProtocolVersion { major: 1, minor: 0 },
        recover_on_start: false,
    });
    let local = LocalFacade::new(daemon.clone());
    let mut remote = build_loopback_remote_client_with(daemon.clone());
    remote.handshake()?;
    let remote_facade = RemoteFacade::new(remote);

    let accepted = local
        .profile()
        .apply(
            caly_api::Ctx::new(
                caly_common::TraceId::new("follow-contract-apply"),
                caly_common::Actor::Cli,
            )
            .with_idempotency_key("follow-contract-apply".to_owned()),
            caly_api::ApplyRequest {
                profile_id: caly_api::ProfileId("follow-contract-profile".to_owned()),
                dry_run: false,
                strict: false,
            },
        )
        .await
        .map_err(|error| error.summary)?;
    for _ in 0..8 {
        if !daemon.process_next_job()? {
            break;
        }
    }

    let report = run_job_follow_contract(
        &local,
        &remote_facade,
        JobFollowRequest {
            job_id: accepted.job_id,
            from_event_index: None,
        },
    )
    .await
    .map_err(|error| error.summary)?;

    let mut suite = ScenarioSuite::default();
    suite.extend_contract("job-follow-contract", report);
    // The caller that resumes *past* the end is the interesting half of a follow: both paths must
    // report the same "nothing new", and neither may invent a reset.
    let stale = run_job_follow_contract(
        &local,
        &remote_facade,
        JobFollowRequest {
            job_id: accepted.job_id,
            from_event_index: Some(accepted.job_id.0 + 10_000),
        },
    )
    .await
    .map_err(|error| error.summary)?;
    suite.extend_contract("job-follow-contract-stale", stale);
    Ok(suite)
}

pub async fn run_smoke_bundle() -> Result<ScenarioSuite, String> {
    let mut suite = ScenarioSuite::default();
    for entry in run_handshake_scenario()?.entries {
        suite.entries.push(entry);
    }
    for entry in run_runtime_watch_scenario()?.entries {
        suite.entries.push(entry);
    }
    for entry in run_job_follow_query_stream_scenario()?.entries {
        suite.entries.push(entry);
    }
    for entry in run_wire_probe_scenario()?.entries {
        suite.entries.push(entry);
    }
    for entry in run_timeout_scenario()?.entries {
        suite.entries.push(entry);
    }
    for entry in run_apply_execution_scenario()?.entries {
        suite.entries.push(entry);
    }
    for entry in run_support_bundle_scenario()?.entries {
        suite.entries.push(entry);
    }
    for entry in run_automation_scenario()?.entries {
        suite.entries.push(entry);
    }
    for entry in run_recovery_scan_scenario()?.entries {
        suite.entries.push(entry);
    }
    for entry in run_loopback_contract_scenario().await?.entries {
        suite.entries.push(entry);
    }
    for entry in run_parity_scenarios().await?.entries {
        suite.entries.push(entry);
    }
    for entry in run_job_events_scenario()?.entries {
        suite.entries.push(entry);
    }
    for entry in run_overload_scenario().await?.entries {
        suite.entries.push(entry);
    }
    for entry in run_job_follow_contract_scenario().await?.entries {
        suite.entries.push(entry);
    }
    let smoke = run_follow_smoke().await?;
    suite.push(
        "follow.smoke",
        if !smoke.reset_required {
            ScenarioStatus::Passed
        } else {
            ScenarioStatus::Failed
        },
        format!("summary={:?}", smoke),
    );
    Ok(suite)
}
