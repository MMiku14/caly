use caly_api::{
    default_ctx, ApplyRequest, CalyFacade, CapabilityQuery, ConnectionQuery, JobFollowRequest,
    Operation, PageRequest, PatchAutomationJob, PipelineExplainRequest, SupportBundleReadRequest,
};
use caly_common::Actor;

use caly_daemon::{DaemonApp, DaemonBootstrapConfig, LocalFacade};

use crate::follow::{
    follow_job_once_query, follow_job_once_stream, open_runtime_dashboard, FollowSummary,
};
use crate::loopback::{build_loopback_remote_client, build_loopback_remote_client_with};
use crate::parity::{run_basic_parity_check, ParityReport};
use crate::remote_facade::RemoteFacade;

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct ContractCase {
    pub name: String,
    pub detail: String,
    pub passed: bool,
}

#[derive(Clone, Debug, Default, Eq, PartialEq)]
pub struct ContractReport {
    pub cases: Vec<ContractCase>,
}

impl ContractReport {
    pub fn push(&mut self, name: impl Into<String>, detail: impl Into<String>, passed: bool) {
        self.cases.push(ContractCase {
            name: name.into(),
            detail: detail.into(),
            passed,
        });
    }

    pub fn all_passed(&self) -> bool {
        self.cases.iter().all(|case| case.passed)
    }
}

pub async fn run_system_contract(
    local: &dyn CalyFacade,
    remote: &dyn CalyFacade,
) -> Result<ContractReport, caly_api::ApiError> {
    let ctx = default_ctx("contract-system", Actor::Cli);
    let mut report = ContractReport::default();

    let local_status = local.system().status(ctx.clone()).await?;
    let remote_status = remote.system().status(ctx.clone()).await?;
    report.push(
        "system.status",
        format!("local={:?} remote={:?}", local_status, remote_status),
        local_status == remote_status,
    );

    let local_info = local.system().info(ctx.clone()).await?;
    let remote_info = remote.system().info(ctx.clone()).await?;
    report.push(
        "system.info",
        format!("local={:?} remote={:?}", local_info, remote_info),
        local_info == remote_info,
    );

    // The storage GC plan is compared here because it is the first maintenance read whose *answer*
    // depends on the store: a path that resolved the roots differently (or swallowed a gap) would
    // show up as a mismatch rather than as two plausible-looking reports.
    let local_gc = local
        .system()
        .plan_gc(ctx.clone(), caly_api::GcPlanRequest::new())
        .await?;
    let remote_gc = remote
        .system()
        .plan_gc(ctx.clone(), caly_api::GcPlanRequest::new())
        .await?;
    report.push(
        "system.gc-plan",
        format!(
            "{} | local_collect={:?} remote_collect={:?}",
            local_gc.summary_line(),
            local_gc.collect,
            remote_gc.collect
        ),
        local_gc == remote_gc,
    );

    let local_profiles = local.profile().list(ctx.clone()).await?;
    let remote_profiles = remote.profile().list(ctx.clone()).await?;
    report.push(
        "profile.list",
        format!("local={:?} remote={:?}", local_profiles, remote_profiles),
        local_profiles == remote_profiles,
    );
    if let (Some(local_profile), Some(remote_profile)) =
        (local_profiles.first(), remote_profiles.first())
    {
        let local_profile_view = local
            .profile()
            .get(ctx.clone(), local_profile.id.clone())
            .await?;
        let remote_profile_view = remote
            .profile()
            .get(ctx.clone(), remote_profile.id.clone())
            .await?;
        report.push(
            "profile.get",
            format!(
                "local={:?} remote={:?}",
                local_profile_view, remote_profile_view
            ),
            local_profile_view == remote_profile_view,
        );
    }

    let local_installs = local.core().list_installs(ctx.clone()).await?;
    let remote_installs = remote.core().list_installs(ctx.clone()).await?;
    report.push(
        "core.list_installs",
        format!("local={:?} remote={:?}", local_installs, remote_installs),
        local_installs == remote_installs,
    );
    if let (Some(local_install), Some(remote_install)) =
        (local_installs.first(), remote_installs.first())
    {
        let local_inspect = local
            .core()
            .inspect(ctx.clone(), local_install.id.clone())
            .await?;
        let remote_inspect = remote
            .core()
            .inspect(ctx.clone(), remote_install.id.clone())
            .await?;
        report.push(
            "core.inspect",
            format!("local={:?} remote={:?}", local_inspect, remote_inspect),
            local_inspect == remote_inspect,
        );
    }

    let connection_query = ConnectionQuery {
        page: PageRequest {
            cursor: None,
            limit: 16,
        },
    };
    let local_connections = local
        .runtime()
        .connections(ctx.clone(), connection_query.clone())
        .await?;
    let remote_connections = remote
        .runtime()
        .connections(ctx.clone(), connection_query)
        .await?;
    report.push(
        "runtime.connections",
        format!(
            "local={:?} remote={:?}",
            local_connections, remote_connections
        ),
        local_connections == remote_connections,
    );

    let plan_request = ApplyRequest {
        profile_id: caly_api::ProfileId("contract-system-profile".to_owned()),
        dry_run: true,
        strict: false,
    };
    let local_plan = local
        .profile()
        .plan(ctx.clone(), plan_request.clone())
        .await?;
    let remote_plan = remote.profile().plan(ctx.clone(), plan_request).await?;
    report.push(
        "profile.plan",
        format!("local={:?} remote={:?}", local_plan, remote_plan),
        local_plan == remote_plan,
    );

    let local_explain = local
        .diagnostics()
        .explain_pipeline(
            ctx.clone(),
            PipelineExplainRequest {
                profile_id: caly_api::ProfileId("contract-system-profile".to_owned()),
            },
        )
        .await?;
    let remote_explain = remote
        .diagnostics()
        .explain_pipeline(
            ctx.clone(),
            PipelineExplainRequest {
                profile_id: caly_api::ProfileId("contract-system-profile".to_owned()),
            },
        )
        .await?;
    report.push(
        "diagnostics.explain_pipeline",
        format!("local={:?} remote={:?}", local_explain, remote_explain),
        local_explain == remote_explain,
    );

    let local_capability = local
        .core()
        .capabilities(
            ctx.clone(),
            CapabilityQuery {
                target: "mihomo".to_owned(),
            },
        )
        .await?;
    let remote_capability = remote
        .core()
        .capabilities(
            ctx.clone(),
            CapabilityQuery {
                target: "mihomo".to_owned(),
            },
        )
        .await?;
    report.push(
        "core.capabilities",
        format!(
            "local={:?} remote={:?}",
            local_capability, remote_capability
        ),
        local_capability == remote_capability,
    );

    let local_recovery = local.diagnostics().recovery_status(ctx.clone()).await?;
    let remote_recovery = remote.diagnostics().recovery_status(ctx.clone()).await?;
    report.push(
        "diagnostics.recovery_status",
        format!("local={:?} remote={:?}", local_recovery, remote_recovery),
        local_recovery == remote_recovery,
    );

    let local_automation = local.automation().list_jobs(ctx.clone()).await?;
    let remote_automation = remote.automation().list_jobs(ctx.clone()).await?;
    report.push(
        "automation.list_jobs",
        format!(
            "local={:?} remote={:?}",
            local_automation, remote_automation
        ),
        local_automation == remote_automation,
    );

    Ok(report)
}

pub async fn run_job_follow_contract(
    local: &dyn CalyFacade,
    remote: &dyn CalyFacade,
    request: JobFollowRequest,
) -> Result<ContractReport, caly_api::ApiError> {
    let ctx = default_ctx("contract-job-follow", Actor::Cli);
    let mut report = ContractReport::default();
    let local_view = local
        .diagnostics()
        .follow_job(ctx.clone(), request.clone())
        .await?;
    let remote_view = remote
        .diagnostics()
        .follow_job(ctx.clone(), request.clone())
        .await?;
    report.push(
        "diagnostics.follow_job",
        format!("local={:?} remote={:?}", local_view, remote_view),
        local_view == remote_view,
    );
    Ok(report)
}

pub async fn run_loopback_remote_contract() -> Result<ContractReport, String> {
    let mut client = build_loopback_remote_client();
    client.handshake()?;
    let mut report = ContractReport::default();

    let result = client.send_operation(
        "contract-system-status",
        Operation::System(caly_api::SystemOp::Status),
        None,
    )?;
    report.push(
        "remote.system.status",
        format!("result={:?}", result),
        matches!(result, caly_api::OperationResult::SystemStatus(_)),
    );

    let plan = client.send_operation(
        "contract-profile-plan",
        Operation::Profile(caly_api::ProfileOp::Plan {
            request: ApplyRequest {
                profile_id: caly_api::ProfileId("loopback-plan-profile".to_owned()),
                dry_run: true,
                strict: false,
            },
        }),
        None,
    )?;
    report.push(
        "remote.profile.plan",
        format!("result={:?}", plan),
        matches!(plan, caly_api::OperationResult::DeploymentPlan(_)),
    );

    let explain = client.send_operation(
        "contract-explain-pipeline",
        Operation::Diagnostics(caly_api::DiagnosticsOp::ExplainPipeline {
            request: PipelineExplainRequest {
                profile_id: caly_api::ProfileId("loopback-plan-profile".to_owned()),
            },
        }),
        None,
    )?;
    report.push(
        "remote.diagnostics.explain_pipeline",
        format!("result={:?}", explain),
        matches!(explain, caly_api::OperationResult::PipelineExplain(_)),
    );

    let capabilities = client.send_operation(
        "contract-core-capabilities",
        Operation::Core(caly_api::CoreOp::Capabilities {
            query: CapabilityQuery {
                target: "mihomo".to_owned(),
            },
        }),
        None,
    )?;
    report.push(
        "remote.core.capabilities",
        format!("result={:?}", capabilities),
        matches!(capabilities, caly_api::OperationResult::CapabilityReport(_)),
    );

    let apply = client.submit_apply(
        ApplyRequest {
            profile_id: caly_api::ProfileId("loopback-apply-profile".to_owned()),
            dry_run: false,
            strict: false,
        },
        Some("loopback-apply-contract".to_owned()),
    )?;
    report.push(
        "remote.profile.apply.accepted",
        format!("accepted={:?}", apply),
        apply.job_id.0 > 0,
    );

    let processed = client.process_next_job()?;
    report.push(
        "remote.profile.apply.processed",
        format!("processed={processed}"),
        processed,
    );

    // The report builder is string-shaped by design; the code is kept in the detail so a failing
    // case still says *why* rather than only what the daemon wrote.
    let follow = client
        .follow_job_query(apply.job_id, None)
        .map_err(|error| format!("{:?}: {}", error.code, error.summary))?;
    report.push(
        "remote.profile.apply.follow",
        format!("follow={:?}", follow),
        follow.state == "completed",
    );

    // The same job, its **lines** this time. `follow` above only proves the counters; this is the half
    // that shows the text a client would put on screen, and that it survives framing unchanged.
    let events = match client.send_operation(
        "remote-read-job-events",
        Operation::Diagnostics(caly_api::DiagnosticsOp::ReadJobEvents {
            request: caly_api::JobEventsRequest::new(apply.job_id),
        }),
        None,
    )? {
        caly_api::OperationResult::JobEvents(view) => view,
        other => return Err(format!("unexpected job events result: {other:?}")),
    };
    report.push(
        "remote.diagnostics.job_events",
        format!(
            "state={} lines={} next={} retained_from={}",
            events.state,
            events.events.len(),
            events.next_event_index,
            events.retained_from_event_index
        ),
        events.state == "completed"
            && events.events.len() >= 8
            && events.events.iter().any(|line| line.contains("apply.plan"))
            && events
                .events
                .iter()
                .any(|line| line.contains("snapshot.committed"))
            && events.next_event_index as usize == events.events.len(),
    );
    // An unknown job id is a refusal, not an empty window (`docs/ONBOARDING_NOTES.md §4.25`). The
    // *stale cursor* case is separate and lives just below: same operation, different answer.
    let stale = match client.send_operation(
        "remote-read-job-events-stale",
        Operation::Diagnostics(caly_api::DiagnosticsOp::ReadJobEvents {
            request: caly_api::JobEventsRequest::new(caly_api::JobId(9_321)),
        }),
        None,
    ) {
        Ok(value) => Some(value),
        Err(message) => {
            report.push(
                "remote.diagnostics.job_events.unknown_job",
                format!("refused: {message}"),
                message.contains("no such job: 9321"),
            );
            None
        }
    };
    if let Some(caly_api::OperationResult::JobEvents(view)) = stale {
        report.push(
            "remote.diagnostics.job_events.unknown_job",
            format!("unexpectedly returned {:?}", view),
            false,
        );
    }

    // Paging is the daemon's decision, but it has to survive the transport: the resume cursor is only
    // worth having if a client on the other end of a socket gets the same one back, byte for byte.
    let mut bounded = caly_api::JobEventsRequest::new(apply.job_id);
    bounded.max_lines = Some(3);
    let first = match client.send_operation(
        "remote-read-job-events-page-1",
        Operation::Diagnostics(caly_api::DiagnosticsOp::ReadJobEvents {
            request: bounded.clone(),
        }),
        None,
    )? {
        caly_api::OperationResult::JobEvents(view) => view,
        other => return Err(format!("unexpected bounded job events result: {other:?}")),
    };
    report.push(
        "remote.diagnostics.job_events.bounded",
        format!(
            "lines={} next_from={:?} bytes={} window_next={}",
            first.events.len(),
            first.next_from_event_index,
            first.byte_len,
            first.next_event_index
        ),
        first.events.len() == 3
            && first.is_truncated()
            && first.next_from_event_index == Some(2)
            && first.byte_len == first.events.join("\n").len() as u64
            && first.next_event_index == events.next_event_index
            && first.events == events.events[..3],
    );
    // …and following that cursor returns the *next* three lines, so a client that pages through the
    // loopback transport reassembles the same window it would have got in one reply.
    let mut walked = first.events.clone();
    let mut cursor = first.next_from_event_index;
    let mut hops = 0usize;
    while let Some(from) = cursor {
        bounded.from_event_index = Some(from);
        match client.send_operation(
            "remote-read-job-events-page-n",
            Operation::Diagnostics(caly_api::DiagnosticsOp::ReadJobEvents {
                request: bounded.clone(),
            }),
            None,
        )? {
            caly_api::OperationResult::JobEvents(view) => {
                walked.extend(view.events.iter().cloned());
                hops += 1;
                cursor = view.next_from_event_index;
            }
            other => return Err(format!("unexpected paged result: {other:?}")),
        }
        if hops > 64 {
            return Err(format!("paging did not terminate after {hops} pages"));
        }
    }
    report.push(
        "remote.diagnostics.job_events.walk",
        format!("pages={hops} lines={}", walked.len()),
        walked == events.events,
    );

    let stream_follow = follow_job_once_stream(&mut client, apply.job_id, None)?;
    report.push(
        "remote.profile.apply.follow-stream",
        format!("stream_follow={:?}", stream_follow),
        !stream_follow.lines.is_empty(),
    );

    let runtime_status = client.runtime_status()?;
    report.push(
        "remote.runtime.status.after-apply",
        format!("runtime={:?}", runtime_status),
        runtime_status.active_snapshot.is_some(),
    );

    let connections = client.runtime_connections(ConnectionQuery {
        page: PageRequest {
            cursor: None,
            limit: 16,
        },
    })?;
    report.push(
        "remote.runtime.connections",
        format!("connections={:?}", connections),
        !connections.items.is_empty(),
    );
    if let Some(first) = connections.items.first() {
        let close = client.runtime_close_connection(first.id.clone())?;
        report.push(
            "remote.runtime.close_connection.accepted",
            format!("close={:?}", close),
            close.job_id.0 > 0,
        );
        let processed = client.process_next_job()?;
        report.push(
            "remote.runtime.close_connection.processed",
            format!("processed={processed}"),
            processed,
        );
    }

    let doctor = client.doctor(true)?;
    // Asserts the doctor is wired to the storage layer, not that it emitted something. The old
    // predicate was `!warnings.is_empty()`, which a hardcoded placeholder warning kept permanently
    // true - a stub and a finding looked identical. An empty warnings list is now a valid answer.
    report.push(
        "remote.doctor.runtime",
        format!("doctor={:?}", doctor),
        doctor.summary.contains("storage audit: schema=")
            && doctor.summary.contains("runtime active_profile="),
    );

    let support_bundle = client.support_bundle()?;
    report.push(
        "remote.diagnostics.support_bundle.accepted",
        format!("bundle={:?}", support_bundle),
        support_bundle.job_id.0 > 0,
    );
    let processed = client.process_next_job()?;
    report.push(
        "remote.diagnostics.support_bundle.processed",
        format!("processed={processed}"),
        processed,
    );
    // `§9.3` turned the bundle from a skeleton into an export, and this is the half that proves it
    // over a façade: the accepted job has to *commit* something and leave an operator-visible line.
    // Accept + "succeeded" + nothing written is exactly what used to pass here.
    let bundle_follow = client
        .follow_job_query(support_bundle.job_id, None)
        .map_err(|error| format!("{:?}: {}", error.code, error.summary))?;
    report.push(
        "remote.diagnostics.support_bundle.committed",
        format!("follow={bundle_follow:?}"),
        bundle_follow.state == "completed"
            && bundle_follow.last_stage.as_deref() == Some("bundle.committed")
            && bundle_follow.log_count > 0,
    );

    // Retrieve what that job wrote. `§12.2`'s export is only real if a client over the framed path
    // can obtain it, and the digest here comes from the store rather than from parsing a log line.
    let read_back = match client.send_operation(
        "remote-read-support-bundle",
        Operation::Diagnostics(caly_api::DiagnosticsOp::ReadSupportBundle {
            request: SupportBundleReadRequest {
                digest: None,
                max_bytes: None,
            },
        }),
        None,
    )? {
        caly_api::OperationResult::SupportBundle(view) => view,
        other => return Err(format!("unexpected bundle read result: {other:?}")),
    };
    report.push(
        "remote.diagnostics.support_bundle.readback",
        format!(
            "digest={} bytes={} lines={} truncated={}",
            read_back.digest, read_back.byte_len, read_back.line_count, read_back.truncated
        ),
        read_back.first_section() == Some("header")
            && !read_back.truncated
            && read_back.line_count > 0
            && read_back.content_sha256 == read_back.digest,
    );

    let automation_before = client.automation_list_jobs()?;
    report.push(
        "remote.automation.list.before",
        format!("automation={:?}", automation_before),
        !automation_before.is_empty(),
    );
    if let Some(first) = automation_before.first() {
        let patch = client.automation_patch_job(PatchAutomationJob {
            job_id: first.id.clone(),
            enabled: !first.enabled,
        })?;
        report.push(
            "remote.automation.patch.accepted",
            format!("patch={:?}", patch),
            patch.job_id.0 > 0,
        );
        let processed = client.process_next_job()?;
        report.push(
            "remote.automation.patch.processed",
            format!("processed={processed}"),
            processed,
        );
        let automation_after = client.automation_list_jobs()?;
        let toggled = automation_after
            .iter()
            .find(|job| job.id == first.id)
            .map(|job| job.enabled == !first.enabled)
            .unwrap_or(false);
        report.push(
            "remote.automation.patch.visible",
            format!("automation={:?}", automation_after),
            toggled,
        );
    }

    let recovery_seeded = client.seed_recovery_fixture("loopback-recovery-profile")?;
    report.push(
        "remote.recovery.seed",
        format!("decisions={recovery_seeded}"),
        recovery_seeded > 0,
    );

    let doctor_after_recovery = client.doctor(true)?;
    report.push(
        "remote.doctor.recovery",
        format!("doctor={:?}", doctor_after_recovery),
        doctor_after_recovery
            .warnings
            .iter()
            .any(|line| line.contains("recovery decision")),
    );

    let opened = open_runtime_dashboard(&mut client)?;
    let frames = client.pull_stream_once(opened.stream_id, None)?;
    report.push(
        "remote.runtime.watch",
        format!("stream_id={} frames={}", opened.stream_id.0, frames.len()),
        true,
    );

    Ok(report)
}

/// Parity between the local façade and the loopback remote, over **one** daemon.
///
/// This used to take a caller-built local façade while the remote side silently constructed its
/// own daemon, so the two sides compared different processes: `system.info.instance_id` differed
/// on every run, and any genuine divergence in shared state would have been lost in that noise.
pub async fn run_basic_loopback_parity(
    daemon: &DaemonApp,
) -> Result<ParityReport, caly_api::ApiError> {
    let local = LocalFacade::new(daemon.clone());
    let local: &dyn CalyFacade = &local;
    let mut remote = build_loopback_remote_client_with(daemon.clone());
    remote.handshake().map_err(|message| {
        caly_api::ApiError::new(
            caly_api::ErrorCode::Unavailable,
            caly_api::ErrorCategory::Internal,
            true,
            message,
            caly_common::TraceId::new("loopback-parity"),
        )
    })?;
    let remote_facade = RemoteFacade::new(remote);
    run_basic_parity_check(
        local,
        &remote_facade,
        default_ctx("loopback-parity", Actor::Cli),
        None,
    )
    .await
}

pub async fn run_follow_smoke() -> Result<FollowSummary, String> {
    let mut remote = build_loopback_remote_client();
    remote.handshake()?;
    let accepted = remote.submit_apply(
        ApplyRequest {
            profile_id: caly_api::ProfileId("follow-smoke-profile".to_owned()),
            dry_run: false,
            strict: false,
        },
        Some("follow-smoke".to_owned()),
    )?;
    let _ = remote.process_next_job()?;
    follow_job_once_query(&mut remote, accepted.job_id, None)
}

/// One write, driven end to end through **one** access path, described by what the façades can see.
///
/// `docs/REMOTE_FACADE_PARITY.md` and `ADR-017` claim Local and Remote are two paths to one
/// behaviour, but every comparison so far was a query: `status`, `list`, `plan(dry_run)`… A read
/// path can be identical while the write path is not — and it was, for as long as `RemoteFacade`
/// invented its own idempotency key (see `docs/ONBOARDING_NOTES.md §4.37`). These fields are what a
/// caller can actually observe about a write: the answer it got, what the job did, and what the
/// daemon looks like afterwards.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct WriteTrace {
    /// `Accepted.estimated_impact`, as text. The replay path must answer identically here too.
    pub impact: String,
    /// `system.status.state_revision` consumed by this write. A write that never ran consumes
    /// nothing, which is how a silently deduped command shows up without trusting any id.
    pub revision_delta: u64,
    pub job_state: String,
    pub last_stage: String,
    pub log_count: usize,
    pub warning_count: usize,
    pub failure_code: String,
    pub active_profile: String,
    /// `present` / `absent`, not the id: two writes at two different times get two different
    /// snapshot ids and that is *not* a divergence between the paths.
    pub snapshot_after: String,
    pub pending_apply_count: usize,
    pub decision_count: usize,
    pub doctor_errors: usize,
}

/// One named write within a run, plus whether it landed on the previous case's job.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct WriteCase {
    pub name: String,
    pub trace: WriteTrace,
    pub reused_previous_job: bool,
    /// Volatile: the two paths necessarily create different job ids. Kept for diagnosis and for the
    /// cross-path dedup check, excluded from the comparison by [`WriteCase::comparable`].
    pub job_id: u64,
    /// The job's retained event lines, as reported by the same façade that ran the write.
    ///
    /// Counts alone were not enough: two paths can each produce 14 log lines and 8 warnings while one
    /// of them renamed a stage or lost the commit marker. Content is what makes the comparison able to
    /// fail (`docs/ONBOARDING_NOTES.md §4.50`), so the lines travel here and are compared through
    /// [`WriteCase::normalized_events`] — normalised because a job line legitimately quotes the
    /// revision and digest it wrote, which differ between two runs of the same request.
    pub events: Vec<String>,
    /// `true` when the retention window had already dropped lines before this one started.
    pub events_partial: bool,
}

impl WriteCase {
    /// The part of a case that must agree across access paths.
    pub fn comparable(&self) -> (&str, bool, &WriteTrace) {
        (self.name.as_str(), self.reused_previous_job, &self.trace)
    }

    /// The event lines with volatile numbers masked, for comparing one path's run against the other's.
    pub fn normalized_events(&self) -> Vec<String> {
        self.events
            .iter()
            .map(|line| normalize_counters(line))
            .collect()
    }

    pub fn display(&self) -> String {
        format!(
            "{} reused={} job={} {:?}",
            self.name, self.reused_previous_job, self.job_id, self.trace
        )
    }
}

/// The four writes every path must survive identically.
///
/// `fresh-a`/`fresh-b` are the same request twice with no key: both must run. `dedup-a`/`dedup-b`
/// carry the same key: the second must be the *same job*, answered exactly as the first was
/// (`RFC-0002 §8.3`).
pub const WRITE_PARITY_CASES: [&str; 4] = ["fresh-a", "fresh-b", "dedup-a", "dedup-b"];

/// The key both paths use for the two dedup cases (each path gets its own namespace below).
pub const WRITE_DEDUP_KEY: &str = "write-parity-dedup";

/// A harness failure keeps the daemon's code in the text: a parity report is evidence, and
/// "the comparison could not be run" without a code is how a real refusal gets mistaken for a bug in
/// the harness.
fn describe_str(message: String) -> String {
    message
}

fn describe(error: &caly_api::ApiError) -> String {
    // `as_str`, not `{:?}`: `docs/ERRORS.md` documents the stable wire code, and a report that quotes
    // the Rust variant spelling is one rename away from asserting on an implementation detail.
    format!("{}: {}", error.code.as_str(), error.summary)
}

/// What one [`WRITE_PARITY_CASES`] entry must do, whichever façade submitted it:
/// `(must_have_reused_the_previous_job, must_have_advanced_the_daemon_revision)`.
///
/// Total by design: the `dedup-*` suffix is the only thing that licenses a replay, so a renamed or
/// added case falls back to "this is a real write, it must run" rather than panicking inside a report.
pub fn write_case_expectation(name: &str) -> (bool, bool) {
    if name.starts_with("dedup-") && name.ends_with("-b") {
        (true, false)
    } else {
        (false, true)
    }
}

/// Whether a write's `Accepted.estimated_impact` says something the caller can act on.
///
/// `caly-engine::dispatch::classify_command` derives the impact per command kind, and
/// `RFC-0002 §5.2` hands it to the caller precisely so a frontend can warn before following the job
/// ("this restarts the core"). `ReadOnly` for a `profile.apply` is therefore not a conservative
/// default — it is the classification being dropped on the floor, which is what happened while
/// `handler.rs` rebuilt the DTO itself (`docs/ONBOARDING_NOTES.md §4.38`).
pub fn write_impact_is_reported(case: &WriteCase) -> bool {
    case.trace.impact != "ReadOnly"
}

async fn capture_write_case(
    facade: &dyn CalyFacade,
    daemon: &DaemonApp,
    ctx: caly_api::Ctx,
    profile_id: &str,
    previous_job: Option<caly_api::JobId>,
) -> Result<(WriteCase, caly_api::JobId), Box<caly_api::ApiError>> {
    let before = facade
        .system()
        .status(ctx.clone())
        .await
        .map_err(Box::new)?;
    let accepted = facade
        .profile()
        .apply(
            ctx.clone(),
            ApplyRequest {
                profile_id: caly_api::ProfileId(profile_id.to_owned()),
                dry_run: false,
                strict: false,
            },
        )
        .await
        .map_err(Box::new)?;

    // The worker is driven through the daemon, not the façade: "who runs the queue" is not part of
    // the public surface, so leaving it outside the comparison keeps the comparison about the path.
    for _ in 0..16 {
        if !daemon.process_next_job().map_err(|message| {
            Box::new(caly_api::ApiError::internal(message, ctx.trace_id.clone()))
        })? {
            break;
        }
    }

    let after = facade
        .system()
        .status(ctx.clone())
        .await
        .map_err(Box::new)?;
    let follow = facade
        .diagnostics()
        .follow_job(
            ctx.clone(),
            JobFollowRequest {
                job_id: accepted.job_id,
                from_event_index: None,
            },
        )
        .await
        .map_err(Box::new)?;
    let runtime = facade
        .runtime()
        .status(ctx.clone())
        .await
        .map_err(Box::new)?;
    let recovery = facade
        .diagnostics()
        .recovery_status(ctx.clone())
        .await
        .map_err(Box::new)?;
    let doctor = facade
        .diagnostics()
        .doctor(
            ctx.clone(),
            caly_api::DoctorRequest {
                include_runtime: false,
            },
        )
        .await
        .map_err(Box::new)?;

    let window = facade
        .diagnostics()
        .read_job_events(
            ctx.clone(),
            caly_api::JobEventsRequest::new(accepted.job_id),
        )
        .await
        .map_err(Box::new)?;
    let events = window.events;
    let events_partial = window.retained_from_event_index > 0;
    let job_id = accepted.job_id;
    let case = WriteCase {
        name: String::new(),
        events,
        events_partial,
        job_id: job_id.0,
        // Job ids are volatile numbers across paths, so the *fact* of a replay is what travels in the
        // trace: `true` means "this write did not create a new job".
        reused_previous_job: previous_job == Some(job_id),
        trace: WriteTrace {
            impact: format!("{:?}", accepted.estimated_impact),
            revision_delta: after.state_revision.saturating_sub(before.state_revision),
            job_state: follow.state.clone(),
            last_stage: follow.last_stage.clone().unwrap_or_default(),
            log_count: follow.log_count,
            warning_count: follow.warning_count,
            failure_code: follow.failure_code.clone().unwrap_or_default(),
            active_profile: runtime
                .active_profile
                .map(|id| id.0)
                .unwrap_or_else(|| "<none>".to_owned()),
            snapshot_after: if runtime.active_snapshot.is_some() {
                "present".to_owned()
            } else {
                "absent".to_owned()
            },
            pending_apply_count: recovery.pending_apply_count,
            decision_count: recovery.decision_count,
            doctor_errors: doctor.errors.len(),
        },
    };
    Ok((case, job_id))
}

/// Drive the four [`WRITE_PARITY_CASES`] through `facade`, in order, against `daemon`.
pub async fn capture_write_cases(
    facade: &dyn CalyFacade,
    daemon: &DaemonApp,
    profile_id: &str,
    dedup_key: &str,
) -> Result<Vec<WriteCase>, Box<caly_api::ApiError>> {
    let mut cases = Vec::new();
    let mut previous_job = None;
    for name in WRITE_PARITY_CASES {
        // A distinct trace per case, and the key only on the two cases that ask for dedup: both
        // façades must read it off the same `Ctx` field (`RFC-0002 §4.1`).
        let ctx = default_ctx(format!("write-parity-{name}"), Actor::Cli);
        // Keys are path-namespaced. Two cases that must run as *separate* writes cannot share a key
        // across the local and remote runs either, because the dedup window is `(actor, key)` and
        // daemon-wide: the first `fresh-a` would swallow the second, and parity would compare a write
        // against a replay (`docs/ONBOARDING_NOTES.md §4.42`, and `§4.62` for why this round made the
        // key mandatory rather than derived).
        let ctx = if name.starts_with("dedup") {
            ctx.with_idempotency_key(dedup_key.to_owned())
        } else {
            ctx.with_idempotency_key(format!("{dedup_key}-{name}"))
        };
        let (mut case, job_id) =
            capture_write_case(facade, daemon, ctx, profile_id, previous_job).await?;
        case.name = name.to_owned();
        previous_job = Some(job_id);
        cases.push(case);
    }
    Ok(cases)
}

/// How a façade answered a write whose CAS precondition was deliberately wrong, and one whose was right.
///
/// `RFC-0002 §6.2` makes `expected_revision` a compare-and-swap precondition and `§4.1` requires the
/// two access paths to share that semantic. The remote path used to send `None` regardless of what the
/// caller put in `Ctx`, so a stale expectation was accepted silently over the wire while the same call
/// in process was refused — which no amount of read-side parity can show.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct CasAnswer {
    /// `true` when the write was refused because the revision did not match.
    pub refused: bool,
    pub code: String,
    pub category: String,
    /// Whether the daemon actually moved, which is how "refused" is told apart from "accepted but
    /// mislabelled".
    pub advanced: bool,
    /// The trace the refusal came back tagged with. Compared because `RFC-0002 §6.3` says the trace
    /// id **MUST** stay identical across logs, errors, jobs and IPC — and the remote façade used to
    /// overwrite it with a per-method literal, so only one path returned the caller's trace.
    pub trace_id: String,
}

impl CasAnswer {
    pub fn display(&self) -> String {
        format!(
            "refused={} code={} category={} advanced={} trace={}",
            self.refused, self.code, self.category, self.advanced, self.trace_id
        )
    }
}

/// Probe the CAS precondition through `facade`: one deliberately stale expectation, one current.
pub async fn capture_cas_answers(
    facade: &dyn CalyFacade,
    daemon: &DaemonApp,
    profile_id: &str,
    key_namespace: &str,
) -> Result<(CasAnswer, CasAnswer), Box<caly_api::ApiError>> {
    let current = facade
        .system()
        .status(default_ctx("cas-read", Actor::Cli))
        .await
        .map_err(Box::new)?;
    // Both probes are keyed, and keyed per path: `profile.apply` requires a key (`ADR-037 §2.3`), and
    // an unkeyed submission would be refused for the wrong reason. The namespace keeps the local and
    // remote probes from resolving to each other's job through the daemon-wide window.
    let stale = probe_single_write(
        facade,
        daemon,
        default_ctx("cas-stale", Actor::Cli)
            .with_expected_revision(current.state_revision + 7)
            .with_idempotency_key(format!("{key_namespace}-stale")),
        profile_id,
        current.state_revision,
    )
    .await?;
    let between = facade
        .system()
        .status(default_ctx("cas-between", Actor::Cli))
        .await
        .map_err(Box::new)?;
    let matched = probe_single_write(
        facade,
        daemon,
        default_ctx("cas-current", Actor::Cli)
            .with_expected_revision(between.state_revision)
            .with_idempotency_key(format!("{key_namespace}-current")),
        profile_id,
        between.state_revision,
    )
    .await?;
    Ok((stale, matched))
}

async fn probe_single_write(
    facade: &dyn CalyFacade,
    daemon: &DaemonApp,
    ctx: caly_api::Ctx,
    profile_id: &str,
    revision_before: u64,
) -> Result<CasAnswer, Box<caly_api::ApiError>> {
    let request = ApplyRequest {
        profile_id: caly_api::ProfileId(profile_id.to_owned()),
        dry_run: false,
        strict: false,
    };
    let (refused, code, category, trace_id) =
        match facade.profile().apply(ctx.clone(), request).await {
            Ok(_) => (false, String::new(), String::new(), ctx.trace_id.0.clone()),
            Err(error) => (
                true,
                error.code.to_string(),
                format!("{:?}", error.category),
                error.trace_id.0.clone(),
            ),
        };
    if !refused {
        for _ in 0..16 {
            if !daemon.process_next_job().map_err(|message| {
                Box::new(caly_api::ApiError::internal(message, ctx.trace_id.clone()))
            })? {
                break;
            }
        }
    }
    let after = facade
        .system()
        .status(default_ctx(
            format!("cas-after-{}", if refused { "refused" } else { "accepted" }),
            Actor::Cli,
        ))
        .await
        .map_err(Box::new)?;
    Ok(CasAnswer {
        refused,
        code,
        category,
        trace_id,
        advanced: after.state_revision != revision_before,
    })
}

/// What a response envelope says, minus the field only a transport can fill in.
///
/// `ADR-026` maps every facet call onto one envelope shape on both paths, and the envelope is where
/// `trace_id` and the answer live. `request_id` is excluded on purpose: it is allocated by whoever
/// frames the request, so the remote session increments a counter while an in-process call has no
/// frame to number. Correlation is what a transport needs and an in-process call does not, so
/// requiring agreement on it would compare the pipe rather than the decision.
pub fn parity_of(envelope: &caly_api::ResponseEnvelope) -> String {
    normalize_counters(&format!(
        "trace_id={} result={:?}",
        envelope.trace_id.0, envelope.result
    ))
}

/// Replace every run of digits with `#`.
///
/// Two submissions to one daemon cannot land on the same job id or the same revision — the second
/// sees a counter the first already advanced. What stays un-normalised is everything that could differ
/// because of the *path* rather than the clock: which variant of `OperationResult` came back, whether
/// it was an error and which code/category/remediation it carried, the impact class, the trace id, and
/// how many events a job produced.
fn normalize_counters(text: &str) -> String {
    let mut out = String::with_capacity(text.len());
    let mut in_digits = false;
    for ch in text.chars() {
        if ch.is_ascii_digit() {
            if !in_digits {
                out.push('#');
                in_digits = true;
            }
        } else {
            in_digits = false;
            out.push(ch);
        }
    }
    out
}

/// Recorded requests whose *envelopes* — not just their DTOs — must match across the two paths.
///
/// Comparing at the façade alone would hide a class of divergence: a path can return the same
/// `Accepted` while losing the caller's trace id on the way in, which is what `RFC-0002 §6.3` forbids
/// and what the remote façade did until this file started checking it.
pub const ENVELOPE_PARITY_CASES: [&str; 8] = [
    "profile-apply",
    "profile-apply-keyed",
    "profile-apply-stale-revision",
    "follow-unknown-job",
    "support-bundle",
    "system-gc-plan",
    // A destructive command, keyed so the second path replays the first's job instead of sweeping
    // twice, and unkeyed to check the refusal arrives identically -- `ADR-037 §2.3` and `ADR-038 §2`
    // meet here, because a retry of a collection cycle is exactly the case a derived key cannot serve.
    "system-gc-collect-keyed",
    "system-gc-collect",
];

fn envelope_for_case(case: &str, request_id: u64) -> caly_api::RequestEnvelope {
    let operation = match case {
        "profile-apply" | "profile-apply-keyed" | "profile-apply-stale-revision" => {
            caly_api::Operation::Profile(caly_api::ProfileOp::Apply {
                request: ApplyRequest {
                    profile_id: caly_api::ProfileId("envelope-parity-profile".to_owned()),
                    dry_run: false,
                    strict: false,
                },
            })
        }
        "system-gc-plan" => caly_api::Operation::System(caly_api::SystemOp::GcPlan {
            request: caly_api::GcPlanRequest::new(),
        }),
        "system-gc-collect" | "system-gc-collect-keyed" => {
            caly_api::Operation::System(caly_api::SystemOp::CollectGarbage {
                request: caly_api::GcCollectRequest::new(),
            })
        }
        "follow-unknown-job" => {
            caly_api::Operation::Diagnostics(caly_api::DiagnosticsOp::FollowJob {
                request: caly_api::JobFollowRequest {
                    job_id: caly_api::JobId(9_999),
                    from_event_index: None,
                },
            })
        }
        _ => caly_api::Operation::Diagnostics(caly_api::DiagnosticsOp::SupportBundle),
    };
    caly_api::RequestEnvelope {
        protocol: caly_api::ProtocolVersion { major: 1, minor: 0 },
        request_id: caly_api::RequestId(request_id),
        // A trace the daemon has to carry through unchanged on both paths.
        trace_id: caly_common::TraceId::new(format!("envelope-{case}")),
        deadline_ms: Some(9_000),
        expected_revision: if case.ends_with("stale-revision") {
            Some(u64::MAX - 1)
        } else {
            None
        },
        idempotency_key: if case.ends_with("-keyed") {
            Some("envelope-parity-key".to_owned())
        } else {
            None
        },
        // The role is hardwired here and on both façades today; `docs/ONBOARDING_NOTES.md §4.41` and
        // `ADR-037` record that as an open decision rather than pretending this covers it.
        role: caly_api::Role::Admin,
        io_budget: None,
        operation,
    }
}

/// Compare the envelopes both façades would produce, one per [`ENVELOPE_PARITY_CASES`] entry.
///
/// Synchronous on purpose: `handle_request` is the shared boundary, so this needs no executor and sees
/// exactly what each path put into and got out of the daemon.
pub fn run_envelope_parity(daemon: &DaemonApp) -> Vec<crate::parity::ParityItem> {
    let mut items = Vec::new();
    for (index, case) in ENVELOPE_PARITY_CASES.iter().enumerate() {
        // Same request twice, two paths. `request_id` differs by construction and is excluded by
        // `parity_of`; the keyed case deliberately replays, which is part of what must agree.
        let local = caly_daemon::handle_request(
            daemon,
            caly_common::Actor::Cli,
            &envelope_for_case(case, index as u64 + 1),
        );
        let remote = caly_daemon::handle_request(
            daemon,
            caly_common::Actor::Cli,
            &envelope_for_case(case, index as u64 + 101),
        );
        items.push(crate::parity::compare_value(
            &format!("envelope.{case}"),
            &parity_of(&local),
            &parity_of(&remote),
            "both paths produced the same envelope",
        ));
    }
    items
}

/// Local/remote parity over the **write** path, on one daemon.
///
/// The read-side bundle already compares queries; this compares the four [`WRITE_PARITY_CASES`]
/// driven through each access path, case by case. Comparing per case rather than "both façades agree
/// at the end" is what makes it able to fail: an asymmetry in how a write is *submitted* (a fabricated
/// idempotency key, a dropped `estimated_impact`, one path draining a different number of stages)
/// shows up in one case and not in the final state.
pub async fn run_write_parity(
    daemon: &DaemonApp,
    profile_id: &str,
) -> Result<ParityReport, String> {
    let local = LocalFacade::new(daemon.clone());
    let local: &dyn CalyFacade = &local;
    // Round 56: the remote path gets its own *daemon*. Apply now plans against the
    // engine's last deployment (`ADR-044 §5.3` closed), so a second run of the same case
    // on a shared daemon is legitimately a Noop — a different operation, not a parity
    // violation. The premise this comparison has always meant is *equal starting states*:
    // two fresh deployments that differ only in how the client reached the daemon.
    let remote_daemon = DaemonApp::bootstrap(DaemonBootstrapConfig {
        instance_id: "write-parity-remote".to_owned(),
        protocol_version: caly_api::ProtocolVersion { major: 1, minor: 0 },
        recover_on_start: false,
    });
    let mut remote = build_loopback_remote_client_with(remote_daemon.clone());
    remote.handshake()?;
    let remote_facade = RemoteFacade::new(remote);
    let remote: &dyn CalyFacade = &remote_facade;

    let mut report = ParityReport::default();
    // Each path gets its own key namespace. The dedup window lives in the daemon rather than in a
    // connection, so sharing one key would make the remote run's *first* use of it a replay of the
    // local run and compare two different things. The cross-path behaviour is asserted below instead
    // (and that asymmetry is how this file caught its own first draft: §4.42).
    //
    let local_cases = capture_write_cases(
        local,
        daemon,
        profile_id,
        &format!("{WRITE_DEDUP_KEY}-local"),
    )
    .await
    .map_err(|error| describe(&error))?;
    let remote_cases = capture_write_cases(
        remote,
        &remote_daemon,
        profile_id,
        &format!("{WRITE_DEDUP_KEY}-remote"),
    )
    .await
    .map_err(|error| describe(&error))?;

    for (index, name) in WRITE_PARITY_CASES.iter().enumerate() {
        let left = &local_cases[index];
        let right = &remote_cases[index];
        report.items.push(crate::parity::compare_value(
            &format!("write.{name}"),
            &left.comparable(),
            &right.comparable(),
            "local and remote wrote the same way",
        ));
    }

    // A parity comparison cannot see a constant: if both paths report the same wrong thing they
    // agree, so the dispatch classification is asserted outright for each side's first write.
    for (side, cases) in [("local", &local_cases), ("remote", &remote_cases)] {
        let case = &cases[0];
        report.items.push(if write_impact_is_reported(case) {
            crate::parity::matched(
                &format!("write.{side}.impact_is_classified"),
                format!("{}: impact={}", case.name, case.trace.impact),
            )
        } else {
            crate::parity::mismatch(
                &format!("write.{side}.impact_is_classified"),
                format!(
                    "{}: a deployment reported impact=ReadOnly, so the classification never reached the caller",
                    case.name
                ),
            )
        });
    }

    // CAS: the same two probes through each path. A stale expectation must be refused and must not
    // advance the daemon; a current one must be accepted and must. `trace_id` is part of the check
    // because `RFC-0002 §6.3` demands it survive unchanged — the refusal carrying a trace the caller
    // never sent is exactly how the remote façade used to behave.
    for (side, facade) in [("local", local), ("remote", remote)] {
        let (stale, matched) =
            capture_cas_answers(facade, daemon, profile_id, &format!("cas-{side}"))
                .await
                .map_err(|error| describe(&error))?;
        for (label, answer, expect_refused, expect_trace) in [
            ("cas_stale", &stale, true, "cas-stale"),
            ("cas_current", &matched, false, "cas-current"),
        ] {
            let expected_code = if expect_refused { "CONFLICT" } else { "" };
            let sound = answer.refused == expect_refused
                && answer.advanced != expect_refused
                && answer.code == expected_code
                && answer.trace_id == expect_trace;
            report.items.push(if sound {
                crate::parity::matched(&format!("write.{side}.{label}"), answer.display())
            } else {
                crate::parity::mismatch(
                    &format!("write.{side}.{label}"),
                    format!(
                        "expected refused={expect_refused} code={expected_code:?} trace={expect_trace}; got {}",
                        answer.display()
                    ),
                )
            });
        }
    }

    // The cross-path rows below are the *shared-state* half of the contract: dedup
    // honouring a key minted by the other path (`RFC-0002 §8.3`) and a bundle written
    // locally read back remotely. Those need ONE daemon by definition, so the remote
    // side here is a second client on the same daemon the local path wrote through —
    // not the fresh-daemon remote used for the equal-state comparison above.
    let mut cross_remote_client = build_loopback_remote_client_with(daemon.clone());
    cross_remote_client.handshake()?;
    let cross_remote_facade = RemoteFacade::new(cross_remote_client);
    let cross_remote: &dyn CalyFacade = &cross_remote_facade;

    // `RFC-0002 §8.3` dedups on `(actor, idempotency_key)` at the daemon, so a key minted by the
    // local path must be honoured when the remote path replays it. If dedup were per-connection, a
    // reconnecting CLI would deploy twice — the very failure the window exists to prevent.
    let cross = capture_write_case(
        cross_remote,
        daemon,
        default_ctx("write-parity-cross", Actor::Cli)
            .with_idempotency_key(format!("{WRITE_DEDUP_KEY}-local")),
        profile_id,
        None,
    )
    .await
    .map_err(|error| describe(&error))?;
    let local_dedup = &local_cases[WRITE_PARITY_CASES.len() - 2];
    report.items.push(
        if cross.0.job_id == local_dedup.job_id && cross.0.trace.revision_delta == 0 {
            crate::parity::matched(
                "write.dedup_spans_access_paths",
                format!(
                    "remote replay resolved to local job {} without advancing the daemon",
                    cross.0.job_id
                ),
            )
        } else {
            crate::parity::mismatch(
                "write.dedup_spans_access_paths",
                format!(
                    "expected the remote replay of the local key to resolve to job {}; got {}",
                    local_dedup.job_id,
                    cross.0.display()
                ),
            )
        },
    );

    // Produce one bundle through the local path, so the readback below has real bytes to agree on
    // rather than two identical "nothing yet" refusals (which would pass and prove nothing).
    let _ = local
        .diagnostics()
        .support_bundle(default_ctx("bundle-readback-producer", Actor::Cli))
        .await
        .map_err(|error| describe(&error))?;
    for _ in 0..8 {
        if !daemon.process_next_job()? {
            break;
        }
    }

    // And the export has to be *retrievable* the same way from either side. `RFC-0010 §12.2` is only
    // satisfied if a caller can actually obtain the bundle; a write-only export is a store operation
    // with a receipt, and a remote path that loses text or re-encodes it would pass every comparison
    // above. `absent-digest` is the refusal half: a miss must look the same on both paths too.
    for (label, request) in [
        (
            "bundle_readback",
            caly_api::SupportBundleReadRequest {
                digest: None,
                max_bytes: None,
            },
        ),
        (
            "bundle_readback_missing",
            caly_api::SupportBundleReadRequest {
                digest: Some(
                    "sha256:0000000000000000000000000000000000000000000000000000000000000000"
                        .to_owned(),
                ),
                max_bytes: None,
            },
        ),
    ] {
        let local_read = read_through(local, daemon, request.clone()).await;
        let remote_read = read_through(cross_remote, daemon, request).await;
        report.items.push(if local_read == remote_read {
            crate::parity::matched(&format!("write.{label}"), local_read)
        } else {
            crate::parity::mismatch(
                &format!("write.{label}"),
                format!("local={local_read} remote={remote_read}"),
            )
        });
    }

    // Event **content**, per case. The case comparison above covers counters and outcome; a stage can
    // be renamed, or the commit marker lost, without changing any of them. Digits are masked because
    // each path legitimately records the revision and digest its own run produced.
    for index in 0..WRITE_PARITY_CASES.len() {
        let name = WRITE_PARITY_CASES[index];
        let left = local_cases[index].normalized_events();
        let right = remote_cases[index].normalized_events();
        // Two empty lists agree too, so the comparison has to refuse to count that as a pass —
        // otherwise a read path that quietly returns nothing would green-light the whole item set.
        report.items.push(if left.is_empty() || right.is_empty() {
            crate::parity::mismatch(
                &format!("write.{name}.events"),
                format!(
                    "local reported {} line(s) and remote {}, which is not a comparison of content",
                    left.len(),
                    right.len()
                ),
            )
        } else {
            crate::parity::compare_value(
                &format!("write.{name}.events"),
                &left,
                &right,
                &format!("{} event lines agree", left.len()),
            )
        });
    }

    // …and the same job read from both sides must agree line for line, un-normalised. If this fails,
    // the divergence is in the read path (framing, encoding, ordering), not in what the job did.
    let shared_job = caly_api::JobId(local_cases[0].job_id);
    let mut shared = Vec::new();
    for (side, facade) in [("local", local), ("remote", remote)] {
        match facade
            .diagnostics()
            .read_job_events(
                default_ctx(format!("events-same-job-{side}"), Actor::Cli),
                caly_api::JobEventsRequest::new(shared_job),
            )
            .await
        {
            Ok(view) => shared.push((side, view.events)),
            Err(error) => return Err(describe_str(format!("{side}: {:?}", error.code))),
        }
    }
    // …and *paged* the same way. A bound that only the local path honours, or a resume cursor the
    // transport rounds differently, shows up as two walks that disagree on how many lines a job
    // produced — which is `§4.50` again, one page size away.
    let mut walked = Vec::new();
    for (side, facade) in [("local", local), ("remote", remote)] {
        let mut request = caly_api::JobEventsRequest::new(shared_job).with_max_lines(3);
        let mut lines = Vec::new();
        for _ in 0..64 {
            let view = facade
                .diagnostics()
                .read_job_events(
                    default_ctx(format!("events-paged-{side}"), Actor::Cli),
                    request.clone(),
                )
                .await
                .map_err(|error| describe_str(format!("{side}: {:?}", error.code)))?;
            lines.extend(view.events.iter().cloned());
            match view.next_from_event_index {
                Some(next) => request.from_event_index = Some(next),
                None => break,
            }
        }
        walked.push(lines);
    }
    report.items.push(
        if walked.len() == 2 && !walked[0].is_empty() && walked[0] == walked[1] {
            crate::parity::matched(
                "write.events_paged_identical",
                format!("{} lines in 3-line pages agree", walked[0].len()),
            )
        } else {
            crate::parity::mismatch(
                "write.events_paged_identical",
                format!(
                    "local={} remote={}",
                    walked
                        .first()
                        .map_or_else(String::new, |lines| lines.len().to_string()),
                    walked
                        .get(1)
                        .map_or_else(String::new, |lines| lines.len().to_string())
                ),
            )
        },
    );

    let populated = shared.len() == 2 && !shared[0].1.is_empty();
    report
        .items
        .push(if populated && shared[0].1 == shared[1].1 {
            crate::parity::matched(
                "write.events_same_job_identical",
                format!("{} lines, byte for byte", shared[0].1.len()),
            )
        } else {
            crate::parity::mismatch(
                "write.events_same_job_identical",
                format!(
                    "local={:?} remote={:?}",
                    shared.first().map(|(_, lines)| lines.len()),
                    shared.get(1).map(|(_, lines)| lines.len())
                ),
            )
        });

    report.items.extend(run_envelope_parity(daemon));

    // Path-independent invariants, spelled out per case rather than inferred from the comparison: a
    // write that did not ask for dedup must have *run*, and the only case allowed to land on an
    // existing job is the second one that carried a key. Symmetric breakage — both paths silently
    // deduping every write, or both never deduping — passes the comparisons above and fails here,
    // because it changes what the daemon did, not merely what one path reported.
    for index in 0..WRITE_PARITY_CASES.len() {
        let name = WRITE_PARITY_CASES[index];
        let (expect_reused, expect_ran) = write_case_expectation(name);
        let mut evidence = Vec::new();
        let mut broken = false;
        for (side, cases) in [("local", &local_cases), ("remote", &remote_cases)] {
            let case = &cases[index];
            let ran = case.trace.revision_delta > 0;
            if case.reused_previous_job != expect_reused || ran != expect_ran {
                broken = true;
            }
            evidence.push(format!(
                "{side} reused={} delta={} job={} stage={}",
                case.reused_previous_job,
                case.trace.revision_delta,
                case.trace.job_state,
                case.trace.last_stage
            ));
        }
        report.items.push(if broken {
            crate::parity::mismatch(
                &format!("write.{name}.behaved"),
                format!(
                    "expected reused={expect_reused} advanced={expect_ran}; got {}",
                    evidence.join(" | ")
                ),
            )
        } else {
            crate::parity::matched(&format!("write.{name}.behaved"), evidence.join(" | "))
        });
    }
    Ok(report)
}

/// One bundle read through `facade`, flattened to comparable text.
///
/// Flattening is deliberate and lossless for this comparison: the value being checked is that the two
/// paths produce *the same* answer, so both are reduced through the identical function — including
/// the error half, where the danger is exactly that one path reports a code the other does not.
async fn read_through(
    facade: &dyn CalyFacade,
    _daemon: &DaemonApp,
    request: caly_api::SupportBundleReadRequest,
) -> String {
    match facade
        .diagnostics()
        .read_support_bundle(default_ctx("bundle-readback", Actor::Cli), request)
        .await
    {
        Ok(view) => format!(
            "read digest={} bytes={} lines={} truncated={} sha={} stored={:?} head={:?} text_sha256={}",
            view.digest,
            view.byte_len,
            view.line_count,
            view.truncated,
            view.content_sha256,
            view.stored_at_unix_ms,
            view.first_section().map(|name| name.to_owned()),
            // A digest of the returned text, not its length: two paths that each lost a different part
            // of the bundle would agree on a length and disagree here.
            caly_common::digest::sha256_digest(view.text.as_bytes())
        ),
        Err(error) => format!(
            "refused {} {:?} retryable={} {}",
            error.code.as_str(), error.category, error.retryable, error.summary
        ),
    }
}
