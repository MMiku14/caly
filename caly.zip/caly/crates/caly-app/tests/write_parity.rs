//! Local/remote parity over the **write** path.
//!
//! Parity used to be entirely read-side: `status`, `list`, `plan(dry_run)`, `recovery_status`. Two
//! access paths can agree on every query and still not do the same thing when asked to *change*
//! something, and that gap was not hypothetical — `RemoteFacade` invented an idempotency key per
//! operation type (`"profile-apply"`), so the second remote apply of anything resolved to the first
//! job and never ran, while the local path ran both. `docs/ONBOARDING_NOTES.md §4.37` records it.
//!
//! These tests drive four writes through each façade against **one** daemon and compare what the
//! caller can observe: the `Accepted` each path got back, what the job did, and what the daemon
//! looks like afterwards.

use std::future::Future;
use std::pin::pin;
use std::task::{Context, Poll, Waker};

use caly_api::{ApplyRequest, CalyFacade, Ctx, JobId, ProfileId, ProtocolVersion, TraceId};
use caly_app::contract::{
    capture_write_cases, run_write_parity, write_impact_is_reported, WriteCase, WRITE_PARITY_CASES,
};
use caly_app::parity::ParityStatus;
use caly_common::Actor;
use caly_daemon::{DaemonApp, LocalFacade};

const PROFILE: &str = "parity-write-profile";

/// The façade methods resolve on first poll over the loopback transport; a suspension here means
/// someone made the write path await real I/O inside a contract, which would hang the suite.
/// Drive a loopback future to completion. Generic over the error type on purpose: the parity
/// helpers use `Box<ApiError>` internally (so a large error is not copied around) and `String` at the
/// public boundary, and a test harness should not have to mirror that.
fn ready<T, E: std::fmt::Debug>(future: impl Future<Output = Result<T, E>>) -> T {
    let mut cx = Context::from_waker(Waker::noop());
    let mut future = pin!(future);
    match future.as_mut().poll(&mut cx) {
        Poll::Ready(Ok(value)) => value,
        Poll::Ready(Err(error)) => panic!("write parity returned an error: {error:?}"),
        Poll::Pending => panic!("a loopback write suspended; it is expected to be synchronous"),
    }
}

fn daemon() -> DaemonApp {
    DaemonApp::bootstrap(caly_daemon::DaemonBootstrapConfig {
        instance_id: "write-parity".to_owned(),
        protocol_version: ProtocolVersion { major: 1, minor: 0 },
        recover_on_start: false,
    })
}

fn case<'a>(cases: &'a [WriteCase], name: &str) -> &'a WriteCase {
    cases
        .iter()
        .find(|case| case.name == name)
        .unwrap_or_else(|| {
            panic!(
                "no {name} case: {:?}",
                cases.iter().map(|c| &c.name).collect::<Vec<_>>()
            )
        })
}

#[test]
fn every_write_case_matches_across_the_two_paths() {
    let app = daemon();
    let parity = ready(run_write_parity(&app, PROFILE));
    let mismatches: Vec<String> = parity
        .items
        .iter()
        .filter(|item| !matches!(item.status, ParityStatus::Match))
        .map(|item| format!("{:?} {} :: {}", item.status, item.name, item.detail))
        .collect();
    assert!(
        parity.items.len() >= WRITE_PARITY_CASES.len() + 2,
        "expected one item per case plus the classification checks, got {:?}",
        parity
            .items
            .iter()
            .map(|item| item.name.as_str())
            .collect::<Vec<_>>()
    );
    assert!(
        parity.all_match(),
        "{} write-parity item(s) do not match:\n{}",
        mismatches.len(),
        mismatches.join("\n")
    );

    // Anti-vacuity: matching "refused" answers on both paths would also be green, so the readback
    // items are checked to have actually read bytes. Without this the producer step could silently
    // do nothing and the comparison would compare two identical failures.
    let read = parity
        .items
        .iter()
        .find(|item| item.name == "write.bundle_readback")
        .expect("the readback item is part of the report");
    assert!(
        read.detail.starts_with("read digest=sha256:")
            && read.detail.contains("text_sha256=sha256:"),
        "the readback did not return a bundle: {}",
        read.detail
    );
    assert!(
        read.detail.contains("head=Some(\"header\")"),
        "the returned text is not a bundle: {}",
        read.detail
    );
    // Content addressing has to survive the round trip: the object key, the verified anchor and the
    // digest of the text the caller received are one and the same value.
    let sha = read
        .detail
        .split("sha=")
        .nth(1)
        .and_then(|rest| rest.split(' ').next())
        .expect("the readback reports its anchor");
    let text_sha = read
        .detail
        .split("text_sha256=")
        .nth(1)
        .and_then(|rest| rest.split(' ').next())
        .expect("the readback digests the text it returned");
    let key = read
        .detail
        .trim_start_matches("read digest=")
        .split(' ')
        .next()
        .expect("the readback names the object it read");
    assert_eq!(
        sha, text_sha,
        "the returned bytes differ from the verified anchor"
    );
    assert_eq!(sha, key, "the object is not addressed by its own content");
    let missing = parity
        .items
        .iter()
        .find(|item| item.name == "write.bundle_readback_missing")
        .expect("the missing-digest item is part of the report");
    assert!(
        missing.detail.starts_with("refused CONFLICT "),
        "a digest that names nothing must be refused on both paths, quoting the stable code \
         `docs/ERRORS.md` defines (not a Debug spelling a rename could change): {}",
        missing.detail
    );
}

/// Paging is a daemon decision, so a remote caller must end up with the same log after walking it as
/// a local caller gets in one reply. Two paths disagreeing by a page size would otherwise hide inside
/// the full-window comparison above, which never exercises the resume cursor at all.
#[test]
fn walking_the_window_in_pages_agrees_across_the_two_paths() {
    let app = daemon();
    let parity = ready(run_write_parity(&app, PROFILE));
    let item = parity
        .items
        .iter()
        .find(|item| item.name == "write.events_paged_identical")
        .expect("the paged walk is part of the report");
    assert!(
        matches!(item.status, ParityStatus::Match),
        "the paged walk diverged: {}",
        item.detail
    );
    // Anti-vacuity: two paths that both returned nothing would "agree", so the count has to be in the
    // detail and has to be a real window — several 3-line pages, not one short read.
    let lines: usize = item
        .detail
        .split(' ')
        .next()
        .and_then(|head| head.parse().ok())
        .unwrap_or(0);
    assert!(
        lines >= 8 && item.detail.contains("3-line pages agree"),
        "the walk is not reading a real window: {}",
        item.detail
    );
}

#[test]
fn a_keyed_write_always_runs() {
    let app = daemon();
    let local = LocalFacade::new(app.clone());
    let local_cases = ready(capture_write_cases(&local, &app, PROFILE, "unused-key"));

    for name in ["fresh-a", "fresh-b", "dedup-a"] {
        let item = case(&local_cases, name);
        assert!(
            !item.reused_previous_job,
            "{name} resolved to an existing job: {}",
            item.display()
        );
        assert!(
            item.trace.revision_delta > 0,
            "{name} did not advance the daemon at all: {}",
            item.display()
        );
        assert_eq!(
            item.trace.job_state, "completed",
            "{name}: {:?}",
            item.trace
        );
        assert_eq!(item.trace.failure_code, "", "{name}: {:?}", item.trace);
        assert_eq!(
            item.trace.active_profile.as_str(),
            PROFILE,
            "{name} left a different profile active: {:?}",
            item.trace
        );
        assert_eq!(
            item.trace.snapshot_after, "present",
            "{name}: {:?}",
            item.trace
        );
    }
}

#[test]
fn a_repeated_key_replays_the_original_answer_on_both_paths() {
    // `RFC-0002 §8.3`: a duplicate command returns the original job *or an equivalent outcome*, and
    // must not trigger a second deployment.
    let app = daemon();
    for (side, cases) in [
        (
            "local",
            ready(capture_write_cases(
                &LocalFacade::new(app.clone()),
                &app,
                PROFILE,
                "dedup-parity-key",
            )),
        ),
        (
            "remote",
            ready(run_capture_remote_cases(&app, "dedup-parity-key")),
        ),
    ] {
        let first = case(&cases, "dedup-a");
        let second = case(&cases, "dedup-b");
        assert!(
            second.reused_previous_job,
            "{side}: a repeated key started a new job: {}",
            second.display()
        );
        assert_eq!(
            second.trace.revision_delta,
            0,
            "{side}: a replay deployed anyway: {}",
            second.display()
        );
        assert_eq!(
            second.trace.impact, first.trace.impact,
            "{side}: a replay answered with a different impact"
        );
        assert_eq!(
            second.trace.job_state, first.trace.job_state,
            "{side}: a replay answered with a different job state"
        );
    }
}

/// Drive `capture_write_cases` through a `RemoteFacade` over the same daemon.
///
/// `ready(...)` is used at the call sites because the loopback transport completes on first poll.
async fn run_capture_remote_cases(
    app: &DaemonApp,
    key: &str,
) -> Result<Vec<WriteCase>, Box<caly_api::ApiError>> {
    let mut client = caly_app::build_loopback_remote_client_with(app.clone());
    client.handshake().expect("handshake");
    let facade = caly_app::RemoteFacade::new(client);
    let facade: &dyn CalyFacade = &facade;
    capture_write_cases(facade, app, PROFILE, key).await
}

#[test]
fn a_deployment_reports_the_impact_the_engine_classified() {
    // `RemoteFacade` and `LocalFacade` would both happily agree on a constant, so this is asserted
    // outright: the engine classifies `profile.apply` as `Restart`, and `Accepted` is the only place
    // a caller learns that before following the job.
    let app = daemon();
    let local = LocalFacade::new(app.clone());
    let cases = ready(capture_write_cases(&local, &app, PROFILE, "unused"));
    let first = case(&cases, "fresh-a");
    assert!(
        write_impact_is_reported(first),
        "impact was reported as {}/ReadOnly: {}",
        first.trace.impact,
        first.display()
    );
    assert_eq!(first.trace.impact, "Restart", "{:?}", first.trace);
}

#[test]
fn the_two_paths_leave_the_daemon_in_the_same_shape() {
    // After both runs, `run_write_parity` has already compared every case; what is worth stating
    // separately is that the *last* case of each side describes the same daemon state, because both
    // paths write through one engine.
    let app = daemon();
    let local = ready(capture_write_cases(
        &LocalFacade::new(app.clone()),
        &app,
        PROFILE,
        "shared-key",
    ));
    let remote = ready(run_capture_remote_cases(&app, "shared-key"));
    for name in WRITE_PARITY_CASES {
        assert_eq!(
            case(&local, name).trace.active_profile,
            case(&remote, name).trace.active_profile,
            "{name}"
        );
        assert_eq!(
            case(&local, name).trace.pending_apply_count,
            case(&remote, name).trace.pending_apply_count,
            "{name}: one path left a journal open"
        );
        assert_eq!(
            case(&local, name).trace.doctor_errors,
            case(&remote, name).trace.doctor_errors,
            "{name}: one path made doctor angry"
        );
    }
}

/// The defect this whole file exists for, pinned as behaviour rather than as a comment.
///
/// A key derived from the *operation type* is not an idempotency key: it is one slot for every
/// caller of that operation. Two different profiles, submitted twice with the same constant, resolve
/// to the same job — the second deployment is silently dropped. `RemoteFacade` used to do exactly
/// this for `apply`, `rollback`, `source.update`, `network.repair` and `system.shutdown`.
#[test]
fn a_constant_key_would_swallow_the_second_deployment() {
    let app = daemon();
    let mut client = caly_app::build_loopback_remote_client_with(app.clone());
    client.handshake().expect("handshake");

    let submit = |client: &mut caly_app::RemoteSessionClient<caly_app::LoopbackRemoteTransport>,
                  profile: &str|
     -> JobId {
        client
            .submit_apply(
                ApplyRequest {
                    profile_id: ProfileId(profile.to_owned()),
                    dry_run: false,
                    strict: false,
                },
                Some("profile-apply".to_owned()),
            )
            .expect("accepted")
            .job_id
    };

    let first = submit(&mut client, "profile-alpha");
    let second = submit(&mut client, "profile-beta");
    assert_eq!(
        first, second,
        "the low-level client is where a caller supplies a key, and a repeated key must replay — \
         if this stops being true the dedup path changed under the façade"
    );

    // …and with distinct keys, both writes run. This is the assertion the façade fix is for: the
    // daemon must be able to tell "the same logical write again" from "a different write".
    let local = LocalFacade::new(app.clone());
    let submit_keyed = |profile: &str| {
        let tag = format!("distinct-{profile}");
        let ctx = Ctx::new(TraceId::new(&tag), Actor::Cli).with_idempotency_key(tag);
        ready(local.profile().apply(
            ctx,
            ApplyRequest {
                profile_id: ProfileId(profile.to_owned()),
                dry_run: false,
                strict: false,
            },
        ))
    };
    let a = submit_keyed("profile-alpha");
    let b = submit_keyed("profile-beta");
    assert_ne!(
        a.job_id, b.job_id,
        "two applies with distinct keys must be two jobs, not one job twice"
    );
}

#[test]
fn the_case_list_is_the_documented_four() {
    assert_eq!(
        WRITE_PARITY_CASES,
        ["fresh-a", "fresh-b", "dedup-a", "dedup-b"]
    );
}

#[test]
fn event_content_is_compared_not_merely_counted() {
    let app = daemon();
    let parity = ready(run_write_parity(&app, PROFILE));
    let detail = |name: &str| -> String {
        parity
            .items
            .iter()
            .find(|item| item.name == name)
            .unwrap_or_else(|| {
                panic!(
                    "no {name} item in {:?}",
                    parity
                        .items
                        .iter()
                        .map(|i| i.name.as_str())
                        .collect::<Vec<_>>()
                )
            })
            .detail
            .clone()
    };
    for name in WRITE_PARITY_CASES {
        let got = detail(&format!("write.{name}.events"));
        let lines: usize = got
            .split(' ')
            .next()
            .and_then(|head| head.parse().ok())
            .unwrap_or(0);
        assert!(
            lines >= 8,
            "{name}: only {lines} event lines were compared, which is not content: {got}"
        );
    }
    let same_job = detail("write.events_same_job_identical");
    let shared_lines: usize = same_job
        .split(' ')
        .next()
        .and_then(|head| head.parse().ok())
        .expect("the item reports how many lines it compared");
    assert!(
        same_job.contains("byte for byte") && shared_lines >= 8,
        "the same job must read back identically on both paths: {same_job}"
    );
}

#[test]
fn the_compared_lines_are_the_ones_the_operator_would_read() {
    // The point of exposing the window is that a caller sees the *same* text the stream and the
    // support bundle render, including the commit marker that says the deployment was persisted.
    let app = daemon();
    let cases = ready(capture_write_cases(
        &LocalFacade::new(app.clone()),
        &app,
        PROFILE,
        "unused",
    ));
    let events = &cases[0].events;
    assert!(
        events
            .iter()
            .any(|line| line.starts_with("[stage 60%] apply.plan ") || line.contains("apply.plan ")),
        "{events:?}"
    );
    assert!(
        events
            .iter()
            .any(|line| line.contains("snapshot.committed")),
        "no commit marker in {events:?}"
    );
    assert!(
        events.iter().any(|line| line == "[done] Succeeded"),
        "no terminal outcome in {events:?}"
    );
    assert!(
        !cases[0].events_partial,
        "a fresh job's window should not already be dropping lines"
    );
}
