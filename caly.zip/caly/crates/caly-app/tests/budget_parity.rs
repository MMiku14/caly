//! The deferred parity assertion from `ADR-036` step 0 (`docs/history/ONBOARDING_NOTES.md §4.86`).
//!
//! Round 21 wired `RequestEnvelope.io_budget` through both façades and admitted in three places that
//! `caly-app::remote`'s one-line `Some(ctx.io_budget.clone())` had **no end-to-end assertion**: a
//! budget had no observable consequence yet, so the only way to check the line was to expose an
//! internal value or invent a public API for tests. Both were more expensive than the gap, so the gap
//! was written down instead. Step 3 gave budgets a consequence -- the engine refuses an access it has
//! no budget left for -- and with that, this file can ask the only question that matters:
//!
//! > does the same request get the same answer over either access path?
//!
//! Nothing here reads a private field. Both paths submit through their own façade and read their own
//! `JobFollowView` back, which is also what makes a dropped-forwarding bug *visible*: if the remote
//! line disappeared, the remote job would spend the daemon's default budget, succeed, and stop matching.

use std::future::Future;
use std::pin::pin;
use std::task::{Context, Poll, Waker};

use caly_api::{
    ApplyRequest, CalyFacade, Ctx, IoBudget, JobFollowRequest, JobFollowView, ProfileId,
    ProtocolVersion,
};
use caly_app::{build_loopback_remote_client_with, RemoteFacade};
use caly_common::Actor;
use caly_daemon::{DaemonApp, DaemonBootstrapConfig, LocalFacade};

const PROFILE: &str = "budget-parity-profile";

/// The façade methods resolve on the first poll over the loopback transport; a suspension here would
/// mean someone put real I/O inside a contract check.
fn ready<T, E: std::fmt::Debug>(future: impl Future<Output = Result<T, E>>) -> T {
    let mut cx = Context::from_waker(Waker::noop());
    let mut future = pin!(future);
    match future.as_mut().poll(&mut cx) {
        Poll::Ready(Ok(value)) => value,
        Poll::Ready(Err(error)) => panic!("budget parity call failed: {error:?}"),
        Poll::Pending => panic!("a loopback call suspended; it is expected to be synchronous"),
    }
}

fn daemon() -> DaemonApp {
    DaemonApp::bootstrap(DaemonBootstrapConfig {
        instance_id: "budget-parity".to_owned(),
        protocol_version: ProtocolVersion { major: 1, minor: 0 },
        recover_on_start: false,
    })
}

/// `profile.apply` is `Idempotency::Required` (`ADR-037`), so a key is mandatory -- and it is derived
/// from the trace, which is unique per call. Sharing one key across the two paths would make the
/// remote run a *replay* of the local one and compare nothing (the trap `§4.42` records).
fn ctx(trace: &str, budget: IoBudget) -> Ctx {
    let mut ctx = caly_api::default_ctx(trace, Actor::Cli)
        .with_idempotency_key(format!("budget-parity-{trace}"));
    ctx.io_budget = budget;
    ctx
}

fn apply_request() -> ApplyRequest {
    ApplyRequest {
        profile_id: ProfileId(PROFILE.to_owned()),
        dry_run: false,
        strict: false,
    }
}

/// What a caller can see about one submitted apply, projected through the public follow view.
#[derive(Clone, Debug, Eq, PartialEq)]
struct Outcome {
    state: String,
    failure_code: Option<String>,
    failure_summary: Option<String>,
    event_count: usize,
}

impl Outcome {
    fn from(view: &JobFollowView) -> Self {
        Self {
            state: view.state.clone(),
            failure_code: view.failure_code.clone(),
            failure_summary: view.failure_summary.clone(),
            event_count: view.event_count,
        }
    }
}

/// Submit on one façade, run the worker, read the job back **on that same façade**.
fn run(facade: &dyn CalyFacade, app: &DaemonApp, trace: &str, budget: IoBudget) -> Outcome {
    let accepted = ready(
        facade
            .profile()
            .apply(ctx(trace, budget.clone()), apply_request()),
    );
    app.drain_engine_once().expect("one worker cycle");
    let view = ready(facade.diagnostics().follow_job(
        ctx(trace, budget),
        JobFollowRequest {
            job_id: accepted.job_id,
            from_event_index: None,
        },
    ));
    Outcome::from(&view)
}

/// The refusal both paths must produce, byte for byte, for a request whose budget is spent before it
/// starts.
#[test]
fn a_spent_budget_refuses_the_apply_the_same_way_over_either_path() {
    let app = daemon();
    let local = LocalFacade::new(app.clone());
    let local: &dyn CalyFacade = &local;
    let mut client = build_loopback_remote_client_with(app.clone());
    client.handshake().expect("loopback handshake");
    let remote = RemoteFacade::new(client);
    let remote: &dyn CalyFacade = &remote;

    let spent = IoBudget {
        max_bytes: None,
        max_requests: Some(0),
    };
    let over_local = run(local, &app, "budget-parity-local", spent.clone());
    let over_remote = run(remote, &app, "budget-parity-remote", spent);

    assert_eq!(
        over_local, over_remote,
        "`Ctx::io_budget` is forwarded by both façades; if the remote line ever stops forwarding it, \
         the remote job spends the daemon default and this comparison stops matching -- which is \
         exactly the assertion `ADR-036` step 0 had to leave out"
    );
    assert_eq!(
        over_local.failure_code.as_deref(),
        Some("CONFIG_INVALID"),
        "a spent caller budget is the caller's own limit, not a storage fault: {over_local:?}"
    );
    assert!(
        over_local
            .failure_summary
            .as_deref()
            .unwrap_or_default()
            .contains("io budget"),
        "{over_local:?}"
    );
    assert!(
        over_local.state.to_lowercase().contains("fail"),
        "{over_local:?}"
    );
    assert_eq!(
        over_local.event_count, over_remote.event_count,
        "the refusal is reported, not silently swallowed on one path"
    );
}

/// The default is not merely "bounded": it is exactly the generous bound the caller could name, so a
/// real apply is unaffected by the change from `unlimited()`.
#[test]
fn the_stated_default_applies_exactly_like_naming_that_number() {
    let app = daemon();
    let local = LocalFacade::new(app.clone());
    let local: &dyn CalyFacade = &local;
    // Round 56: the remote path gets its own daemon. Apply plans against the engine's
    // last deployment now, so the same case on a shared daemon is a Noop the second time
    // — a different plan, not a budget difference. Equal starting states are the premise
    // of this comparison.
    let remote_app = daemon();
    let mut client = build_loopback_remote_client_with(remote_app.clone());
    client.handshake().expect("loopback handshake");
    let remote = RemoteFacade::new(client);
    let remote: &dyn CalyFacade = &remote;

    let explicit = IoBudget {
        max_bytes: None,
        max_requests: Some(IoBudget::DEFAULT_COMMAND_STORE_REQUESTS),
    };
    // The local path states the default through `default_ctx`, which now carries it explicitly -- the
    // other half of the same claim, that the fallback in `request_map` is the identical value, is
    // asserted in `crates/caly-daemon/src/request_map.rs`.
    let over_local = run(local, &app, "default-local", IoBudget::default_command());
    let over_remote = run(remote, &remote_app, "default-remote", explicit);

    assert_eq!(
        over_local, over_remote,
        "the default and the explicit number it stands for must be indistinguishable from outside"
    );
    assert!(
        over_local.failure_code.is_none() && over_remote.failure_code.is_none(),
        "a 64-access budget must not bite a real apply: {over_local:?} vs {over_remote:?}"
    );
    assert_eq!(
        over_local.state, over_remote.state,
        "{over_local:?} vs {over_remote:?}"
    );
}
