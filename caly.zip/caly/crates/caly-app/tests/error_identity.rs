//! Error identity across the two access paths.
//!
//! `RFC-0002 §4.1` lists `ErrorCode` among what Local 与 Remote **MUST** share, and `ADR-020` makes
//! the façade the boundary where errors are normalised. The remote façade did the opposite: its
//! transport returned `Result<_, String>`, so every daemon refusal was flattened to its summary and
//! then re-wrapped as a fresh `Unavailable / Internal / retryable=true`. A CLI reading a local
//! `CONFLICT` read a retryable transport failure for the same request over the socket — the worst
//! possible combination, because it invites an automatic retry of something the daemon refused on
//! purpose. `docs/history/ONBOARDING_NOTES.md §4.39` records it.
//!
//! These tests pin the *identity*, not just the text: code, category, retryability and remediation
//! must survive the round trip, while a genuine transport failure stays distinguishable.

use std::future::Future;
use std::pin::pin;
use std::task::{Context, Poll, Waker};

use caly_api::{
    ApplyRequest, CalyFacade, Ctx, JobFollowRequest, JobId, ProfileId, ProtocolVersion, TraceId,
};
use caly_app::{build_loopback_remote_client_with, RemoteFacade, RemoteSessionClient};
use caly_common::Actor;
use caly_daemon::{DaemonApp, DaemonBootstrapConfig, LocalFacade};

fn daemon() -> DaemonApp {
    DaemonApp::bootstrap(DaemonBootstrapConfig {
        instance_id: "error-identity".to_owned(),
        protocol_version: ProtocolVersion { major: 1, minor: 0 },
        recover_on_start: false,
    })
}

/// Drive a loopback future to completion, returning the outcome as a value.
///
/// Generic over the error so the test does not have to name the box, and it never carries a wide
/// `Result` further than one line — the same reason the client plumbing boxes.
fn poll<T, E>(future: impl Future<Output = Result<T, E>>) -> Outcome<T, E> {
    let mut cx = Context::from_waker(Waker::noop());
    let mut future = pin!(future);
    match future.as_mut().poll(&mut cx) {
        Poll::Ready(Ok(value)) => Outcome::Done(value),
        Poll::Ready(Err(error)) => Outcome::Failed(error),
        Poll::Pending => panic!("a loopback call suspended; it is expected to be synchronous"),
    }
}

enum Outcome<T, E> {
    Done(T),
    Failed(E),
}

impl<T, E: std::fmt::Debug> Outcome<T, E> {
    fn unwrap_or_failed(self, why: &str) -> T {
        match self {
            Self::Done(value) => value,
            Self::Failed(error) => panic!("{why}: {error:?}"),
        }
    }
}

impl<T, E> Outcome<T, E> {
    fn failed(self, why: &str) -> E {
        match self {
            Self::Failed(error) => error,
            Self::Done(_) => panic!("{why}: unexpectedly succeeded"),
        }
    }
}

fn ready<T, E: std::fmt::Debug>(future: impl Future<Output = Result<T, E>>) -> T {
    poll(future).unwrap_or_failed("loopback call failed")
}

fn identity(error: &caly_api::ApiError) -> (String, String, bool, String) {
    (
        error.code.to_string(),
        format!("{:?}", error.category),
        error.retryable,
        error.remediation.clone().unwrap_or_default(),
    )
}

fn ctx(tag: &str) -> Ctx {
    Ctx::new(TraceId::new(tag), Actor::Cli)
}

/// A refusal produced *inside* the daemon must arrive identically over both paths.
#[test]
fn a_daemon_refusal_arrives_with_the_same_identity_on_both_paths() {
    let app = daemon();
    let local = LocalFacade::new(app.clone());
    let mut client = build_loopback_remote_client_with(app.clone());
    client.handshake().expect("handshake");
    let remote = RemoteFacade::new(client);

    // `FollowJob` for a job id this daemon never accepted: the daemon answers with a typed
    // `CONFLICT` (it is *not* an unimplemented handler — `docs/history/ONBOARDING_NOTES.md §4.25`).
    let request = JobFollowRequest {
        job_id: JobId(4242),
        from_event_index: None,
    };
    let local_error = poll(
        local
            .diagnostics()
            .follow_job(ctx("local-follow"), request.clone()),
    )
    .failed("an unknown job must be refused");
    let remote_error = poll(
        remote
            .diagnostics()
            .follow_job(ctx("remote-follow"), request),
    )
    .failed("an unknown job must be refused over the remote path too");

    assert_eq!(
        identity(&local_error),
        identity(&remote_error),
        "local={local_error:?}\nremote={remote_error:?}"
    );
    assert_eq!(local_error.code.to_string(), "CONFLICT");
    assert_eq!(local_error.category, caly_api::ErrorCategory::User);
    assert!(
        !local_error.retryable,
        "a follow of a nonexistent job is not a timeout"
    );
    assert!(
        local_error.summary.contains("no such job: 4242"),
        "{}",
        local_error.summary
    );
    assert_eq!(
        remote_error.summary, local_error.summary,
        "the message a caller reads must not depend on the path"
    );
    assert!(
        remote_error.remediation.is_some(),
        "the remediation was dropped on the way over the transport"
    );
}

/// The CAS precondition is refused the same way on both paths — and accepted when it holds.
#[test]
fn a_cas_refusal_arrives_identically_and_a_matching_revision_is_accepted() {
    let app = daemon();
    let local = LocalFacade::new(app.clone());
    let mut client = build_loopback_remote_client_with(app.clone());
    client.handshake().expect("handshake");
    let remote = RemoteFacade::new(client);

    let facades: [(&str, &dyn CalyFacade); 2] = [("local", &local), ("remote", &remote)];
    for (side, facade) in facades {
        let current = ready(facade.system().status(ctx("cas-read")));
        // Keyed, per side: `profile.apply` declares `Idempotency::Required` (`ADR-037 §2.3`), so an
        // unkeyed submission is refused before the CAS is ever consulted — and this test is about the
        // CAS. The key also has to differ per side, because the dedup window is daemon-wide.
        let stale = ctx(&format!("cas-stale-{side}"))
            .with_expected_revision(current.state_revision + 9)
            .with_idempotency_key(format!("cas-stale-{side}"));
        let error = poll(facade.profile().apply(stale, apply_request("cas-profile")))
            .failed("a stale expected_revision must be refused");
        assert_eq!(error.code.to_string(), "CONFLICT", "{side}: {error:?}");
        assert_eq!(
            error.category,
            caly_api::ErrorCategory::Config,
            "{side}: `docs/guides/ERRORS.md §5.2` puts a compare-and-swap miss under CONFLICT/Config"
        );
        assert!(
            !error.retryable,
            "{side}: retrying the same revision cannot work"
        );
        assert!(
            error
                .remediation
                .as_deref()
                .unwrap_or_default()
                .contains("state_revision"),
            "{side}: the caller needs to be told to re-read: {error:?}"
        );

        let matched = ctx(&format!("cas-current-{side}"))
            .with_expected_revision(current.state_revision)
            .with_idempotency_key(format!("cas-current-{side}"));
        let accepted = poll(
            facade
                .profile()
                .apply(matched, apply_request("cas-profile")),
        )
        .unwrap_or_failed(&format!("{side}: a matching revision must be accepted"));
        assert!(accepted.job_id.0 > 0, "{side}: {accepted:?}");
    }
}

/// The key rule itself, as a parity property.
///
/// `ADR-037 §2.3` makes a `Required` command without a usable key a caller error. Asserting it here
/// rather than only in a daemon test is the point: the failure this codebase already had was one path
/// inventing an identity (`profile-apply` as a constant key) while the other had none, which made
/// "did the write run?" a question with two answers. Refusing on **both** paths is the only semantics
/// that cannot drift, and a refusal that reaches one caller but not the other is the same bug mirrored.
#[test]
fn a_keyless_required_write_is_refused_identically_on_both_paths() {
    let app = daemon();
    let local = LocalFacade::new(app.clone());
    let mut client = build_loopback_remote_client_with(app.clone());
    client.handshake().expect("handshake");
    let remote = RemoteFacade::new(client);

    let mut seen = Vec::new();
    for (side, facade) in [
        ("local", &local as &dyn CalyFacade),
        ("remote", &remote as &dyn CalyFacade),
    ] {
        let error = poll(
            facade
                .profile()
                .apply(ctx(side), apply_request("keyless-profile")),
        )
        .failed(&format!("{side}: a keyless Required write must be refused"));
        assert_eq!(
            error.code.to_string(),
            "CONFIG_INVALID",
            "{side}: {error:?}"
        );
        assert_eq!(
            error.category,
            caly_api::ErrorCategory::User,
            "{side}: this is the caller's input, not the daemon's state"
        );
        assert!(
            !error.retryable,
            "{side}: retrying the same keyless request cannot succeed: {error:?}"
        );
        assert!(
            error.summary.contains("profile.apply"),
            "{side}: the refusal has to name the operation: {error:?}"
        );
        assert!(
            error.summary.contains("idempotency_key"),
            "{side}: …and the field it is missing: {error:?}"
        );
        let refusal = format!(
            "{} {:?} retryable={} {}",
            error.code.as_str(),
            error.category,
            error.retryable,
            error.summary
        );
        seen.push(refusal);
    }
    assert_eq!(
        seen[0], seen[1],
        "the two paths answered the same request with different words"
    );

    // And the refusal is not a deferred write: nothing was queued, nothing ran.
    let status = ready(local.system().status(ctx("keyless-aftermath")));
    assert_eq!(
        status.state_revision, 0,
        "a refused submission still advanced the daemon"
    );
    assert!(
        status.active_profile.is_none(),
        "a refused submission still deployed something: {status:?}"
    );
}

fn apply_request(profile_id: &str) -> ApplyRequest {
    ApplyRequest {
        profile_id: ProfileId(profile_id.to_owned()),
        dry_run: false,
        strict: false,
    }
}

/// A call that never reached the daemon must not be reported as a refusal by it.
#[test]
fn a_transport_failure_stays_distinguishable_from_a_refusal() {
    let app = daemon();
    // No handshake: the session itself refuses to frame a request.
    let client: RemoteSessionClient<_> = build_loopback_remote_client_with(app);
    let remote = RemoteFacade::new(client);
    let error = poll(remote.diagnostics().follow_job(
        ctx("no-session"),
        JobFollowRequest {
            job_id: JobId(1),
            from_event_index: None,
        },
    ))
    .failed("an unopened session must not look like a daemon answer");
    assert_eq!(error.code.to_string(), "UNAVAILABLE", "{error:?}");
    assert_eq!(
        error.category,
        caly_api::ErrorCategory::Internal,
        "{error:?}"
    );
    assert!(error.retryable, "a call that never landed is retryable");
    assert!(
        !error.summary.contains("no such job"),
        "the daemon was never asked, so its reasoning must not be quoted: {}",
        error.summary
    );
}

/// No façade path may flatten a daemon error.
///
/// Round 9 replaced the string-shaped wrapper everywhere it mattered and *counted* the two stream
/// opens that still used it, with a test that failed if a third appeared. Round 11 removed those last
/// two, so the rule is now absolute rather than a ceiling: the lossy wrapper does not exist in the
/// façade file at all. A counted ratchet quietly accepts its own limit; this asserts the limit is zero,
/// which is the only number that is actually right here.
#[test]
fn no_facade_path_flattens_a_daemon_error() {
    let source =
        std::fs::read_to_string(concat!(env!("CARGO_MANIFEST_DIR"), "/src/remote_facade.rs"))
            .expect("the façade source is part of this crate");
    assert_eq!(
        source.matches("with_client(&client").count(),
        0,
        "a façade call site is using the string-shaped wrapper again, so its error would lose the code"
    );
    assert!(
        !source.contains("fn with_client<"),
        "the lossy wrapper itself came back; the façade has no reason to own it"
    );
    // The two paths that used to be exempt are typed now, and stay that way.
    assert!(
        source.contains("open_runtime_stream_checked"),
        "the runtime stream open must use the typed wrapper"
    );
    assert!(
        source.contains("open_job_follow_stream_checked"),
        "the job follow stream open must use the typed wrapper"
    );
    assert!(
        source.contains("remote.read_job_events(&ctx, request)"),
        "the event-content query must use the typed wrapper too"
    );
}

/// `RFC-0002 §6.3`: 「`trace_id` MUST 在日志、错误、Job、IPC 之间保持一致」.
///
/// The remote façade used to hand the session its own per-method literal as the trace, so the same
/// call carried one trace in-process and another over the socket. The trace id of a refusal is the
/// observable, so that is what is compared.
#[test]
fn the_callers_trace_id_survives_both_paths() {
    let app = daemon();
    let local = LocalFacade::new(app.clone());
    let mut client = build_loopback_remote_client_with(app.clone());
    client.handshake().expect("handshake");
    let remote = RemoteFacade::new(client);

    let request = JobFollowRequest {
        job_id: JobId(9),
        from_event_index: None,
    };
    let local_error = poll(local.diagnostics().follow_job(
        Ctx::new(TraceId::new("caller-trace-local"), Actor::Cli),
        request.clone(),
    ))
    .failed("refused");
    let remote_error = poll(remote.diagnostics().follow_job(
        Ctx::new(TraceId::new("caller-trace-remote"), Actor::Cli),
        request,
    ))
    .failed("refused");
    assert_eq!(local_error.trace_id.0, "caller-trace-local");
    assert_eq!(
        remote_error.trace_id.0, "caller-trace-remote",
        "the remote path replaced the caller's trace with its own label"
    );
}
