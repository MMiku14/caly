//! The contract, parity and scenario bundles must actually pass.
//!
//! `docs/LOOPBACK_CONTRACTS.md` and `docs/SCENARIO_SUITE.md` describe this apparatus as a quality
//! gate, and `caly-app` grew `ContractReport::all_passed`, `ParityReport::all_match` and
//! `ScenarioSuite::all_passed` to support it. Before this file **nothing called any of them**: the
//! bundles produced a report, the report was dropped, and a failing case was indistinguishable
//! from a passing one. Same defect class as a guardrail nobody invokes or a test suite with no
//! tests - the machinery exists, the judgement does not.
//!
//! These tests invert that. Every recorded case must pass, and a failure prints the offending case
//! names and details rather than a bare `false`.

use std::future::Future;
use std::pin::pin;
use std::task::{Context, Poll, Waker};

use caly_app::contract::{run_basic_loopback_parity, run_loopback_remote_contract, ContractReport};
use caly_app::parity::ParityStatus;
use caly_app::scenario::{
    run_contract_bundle, run_facade_parity_scenario, run_remote_follow_scenarios,
};
use caly_app::scenario_suite::run_smoke_bundle;

/// These bundles run over the loopback transport, whose futures complete on first poll. Driving
/// them here avoids pulling in an executor for one test - and if one ever suspends, that is
/// reported as a failure instead of hanging the suite.
fn ready<T>(future: impl Future<Output = Result<T, String>>) -> T {
    let mut cx = Context::from_waker(Waker::noop());
    let mut future = pin!(future);
    match future.as_mut().poll(&mut cx) {
        Poll::Ready(Ok(value)) => value,
        Poll::Ready(Err(message)) => panic!("bundle returned an error: {message}"),
        Poll::Pending => panic!("a contract bundle suspended; it is expected to be synchronous"),
    }
}

fn ready_api<T>(future: impl Future<Output = Result<T, caly_api::ApiError>>) -> T {
    let mut cx = Context::from_waker(Waker::noop());
    let mut future = pin!(future);
    match future.as_mut().poll(&mut cx) {
        Poll::Ready(Ok(value)) => value,
        Poll::Ready(Err(error)) => panic!("bundle returned an API error: {:?}", error),
        Poll::Pending => panic!("a contract bundle suspended; it is expected to be synchronous"),
    }
}

fn failures(report: &ContractReport) -> Vec<String> {
    report
        .cases
        .iter()
        .filter(|case| !case.passed)
        .map(|case| format!("{} :: {}", case.name, case.detail))
        .collect()
}

#[test]
fn the_loopback_remote_contract_bundle_passes_every_case() {
    let report = ready(run_loopback_remote_contract());
    assert!(
        report.cases.len() >= 20,
        "the bundle should cover the remote surface, saw only {} case(s): {:?}",
        report.cases.len(),
        report
            .cases
            .iter()
            .map(|case| case.name.as_str())
            .collect::<Vec<_>>()
    );
    assert!(
        report.all_passed(),
        "{} contract case(s) failed:\n{}",
        failures(&report).len(),
        failures(&report).join("\n")
    );
}

#[test]
fn the_contract_bundle_alias_covers_the_same_cases() {
    // `run_contract_bundle` is the entry point the scenario docs name. If it drifted from the
    // direct call, the docs would be describing a path that never runs.
    let via_bundle = ready(run_contract_bundle());
    let direct = ready(run_loopback_remote_contract());
    let names = |report: &ContractReport| -> Vec<String> {
        report.cases.iter().map(|case| case.name.clone()).collect()
    };
    assert_eq!(names(&via_bundle), names(&direct));
    assert_eq!(via_bundle.all_passed(), direct.all_passed());
}

/// One judger for the whole scenario suite.
///
/// Until now the workspace judged only `scenario::run_loopback_scenarios`, a five-row list whose
/// middle three rows were hard-coded to `true`. The real suite — `scenario_suite::run_smoke_bundle`
/// and the ~14 `run_*_scenario` functions it aggregates, including everything added in the last three
/// rounds — was **judged by nothing**: `cargo test` compiled it, and that was the whole check. A row
/// could report `Failed` forever and the gate stayed green.
///
/// Adding the judger found three real defects on its first run, all recorded in
/// `docs/ONBOARDING_NOTES.md §4.55`: the bundle returned `Err("no such job: 1")`, because two
/// scenarios followed a hard-coded job id that never existed on the daemons they built;
/// `runtime.watch.structured-runtime-state` had been failing since the day it was written, because no
/// deployment ever emitted the runtime-state patch the Dashboard stream is documented to carry
/// (`RFC-0002 §10.3`); and `LoopbackHarness` dropped `ErrorCode` on the floor, so no scenario could
/// have asserted *which* refusal arrived.
#[test]
fn every_scenario_suite_row_passes() {
    use caly_app::scenario_suite::ScenarioStatus;

    let suite = ready(run_smoke_bundle());
    let failures: Vec<String> = suite
        .entries
        .iter()
        .filter(|entry| !matches!(entry.status, ScenarioStatus::Passed))
        .map(|entry| format!("{} :: {}", entry.name, entry.detail))
        .collect();
    // The floor is deliberately high: a stub that aggregated three easy rows would also be green.
    assert!(
        suite.entries.len() >= 100,
        "the aggregate must be the real suite, not a stub: {} row(s)",
        suite.entries.len()
    );
    assert!(
        suite.all_passed(),
        "{} row(s) failed:\n{}",
        failures.len(),
        failures.join("\n")
    );
}

#[test]
fn loopback_parity_matches_after_a_real_deployment() {
    // Parity on a pristine daemon mostly compares empty values. Deploying first makes the
    // comparison non-trivial: both façades must now agree on the active profile, the active core,
    // the recovery status and the job history that the apply produced.
    let daemon = caly_daemon::DaemonApp::bootstrap(caly_daemon::DaemonBootstrapConfig {
        instance_id: "parity-after-apply".to_owned(),
        protocol_version: caly_api::ProtocolVersion { major: 1, minor: 0 },
        recover_on_start: false,
    });
    let envelope = caly_api::RequestEnvelope {
        protocol: caly_api::ProtocolVersion { major: 1, minor: 0 },
        request_id: caly_api::RequestId(1),
        trace_id: caly_api::TraceId::new("parity-apply"),
        deadline_ms: None,
        expected_revision: None,
        idempotency_key: Some("parity-apply".to_owned()),
        role: caly_api::Role::Admin,
        io_budget: None,
        operation: caly_api::Operation::Profile(caly_api::ProfileOp::Apply {
            request: caly_api::ApplyRequest {
                profile_id: caly_api::ProfileId("demo-tun-profile".to_owned()),
                dry_run: false,
                strict: false,
            },
        }),
    };
    daemon
        .submit_request_as_command(caly_common::Actor::Cli, &envelope)
        .expect("apply accepted")
        .expect("apply maps to a command");
    assert_eq!(daemon.drain_engine_once().expect("worker drain"), 1);
    assert!(
        daemon
            .latest_last_known_good_snapshot_id()
            .expect("lkg read")
            .is_some(),
        "the fixture must leave a committed snapshot, or parity has nothing to agree about"
    );

    let parity = ready_api(run_basic_loopback_parity(&daemon));
    let mismatches = mismatch_lines(&parity);
    assert!(
        parity.items.len() >= 4,
        "expected several compared fields, saw {:?}",
        parity
            .items
            .iter()
            .map(|item| item.name.as_str())
            .collect::<Vec<_>>()
    );
    assert!(
        parity.all_match(),
        "{} parity item(s) do not match after a deployment:\n{}",
        mismatches.len(),
        mismatches.join("\n")
    );
}

#[test]
fn facade_parity_scenario_also_matches() {
    let parity = ready_api(run_facade_parity_scenario());
    let mismatches = mismatch_lines(&parity);
    assert!(
        !parity.items.is_empty() && parity.all_match(),
        "facade parity failed:\n{}",
        mismatches.join("\n")
    );
}

fn mismatch_lines(parity: &caly_app::parity::ParityReport) -> Vec<String> {
    parity
        .items
        .iter()
        .filter(|item| !matches!(item.status, ParityStatus::Match))
        .map(|item| format!("{:?} {} :: {}", item.status, item.name, item.detail))
        .collect()
}

#[test]
fn remote_follow_scenarios_report_progress() {
    let summaries = ready(run_remote_follow_scenarios());
    assert!(
        !summaries.is_empty(),
        "follow scenarios produced nothing; the follow path is not exercised"
    );
    for summary in &summaries {
        assert!(
            !summary.lines.is_empty() || summary.reset_required,
            "a follow run with no lines and no reset means the stream was never read: {summary:?}"
        );
    }
}
