//! Round 59 (`ADR-047 §4`), sing-box half: the core's own `check` judges the render, and
//! a real passthrough credential stays inside the artifact.
//!
//! The render's shape table (round 58) was verified by hand against 1.13.20 once; this
//! judge makes the binary re-verify it on every run — schema drift in either direction
//! (a core upgrade that renames a field, a render regression) surfaces as a refused
//! `sing-box check`, before any spawn path reaches it.

use std::collections::BTreeMap;

use caly_core::CoreAdapter;
use caly_ir::{
    CoreTarget, DnsMode, DnsPolicy, GroupId, GroupType, NodeId, ProfileId, ProxyGroup, ProxyNode,
    ProxyProtocol, ResolvedProfile, RevisionId, RouteRule, RoutingMode, RuleAction, RuleId,
    SemanticDigest, TunPolicy,
};
use caly_singbox::SingBoxAdapter;

fn profile_with_real_credential() -> ResolvedProfile {
    ResolvedProfile {
        profile_id: ProfileId::new("sb-selfcheck"),
        revision_id: RevisionId("rev:0".to_owned()),
        semantic_digest: SemanticDigest("semantic:0".to_owned()),
        core_target: CoreTarget::SingBox,
        routing_mode: RoutingMode::Rule,
        nodes: vec![ProxyNode {
            id: NodeId::new("node-ss"),
            label: "Shadowsocks 01".to_owned(),
            protocol: ProxyProtocol::Shadowsocks,
            server: "ss.example.net".to_owned(),
            port: 10001,
            extensions: BTreeMap::new(),
            passthrough: BTreeMap::from([
                ("method".to_owned(), "aes-256-gcm".to_owned()),
                ("password".to_owned(), "CANARY-real-secret".to_owned()),
            ]),
        }],
        groups: vec![ProxyGroup {
            id: GroupId::new("group-main"),
            label: "Main".to_owned(),
            kind: GroupType::Select,
            members: vec![NodeId::new("node-ss")],
            selected: None,
        }],
        rules: vec![RouteRule {
            id: RuleId::new("rule-01"),
            label: "Match All".to_owned(),
            matcher: "MATCH".to_owned(),
            action: RuleAction::UseGroup,
            target_group: Some(GroupId::new("group-main")),
            target_outbound: None,
        }],
        rulesets: Vec::new(),
        dns: Some(DnsPolicy {
            mode: DnsMode::System,
            servers: vec!["8.8.8.8".to_owned()],
            fake_ip_filter: Vec::new(),
        }),
        tun: Some(TunPolicy {
            enabled: false,
            auto_route: false,
            strict_route: false,
        }),
        inbounds: Vec::new(),
        outbounds: Vec::new(),
        generated_bytes: None,
    }
}

/// The render must survive `sing-box check` — the core's own verdict, not ours.
#[expect(clippy::disallowed_methods)]
#[test]
fn the_rendered_artifact_passes_the_cores_own_config_check() {
    let adapter = SingBoxAdapter;
    let identity = adapter.inspect_binary().expect("identity");
    let capabilities = adapter.capability_set(&identity).expect("capabilities");
    let artifact = adapter
        .compile(&profile_with_real_credential(), &capabilities)
        .expect("compile");

    let target_dir =
        std::env::var("CARGO_TARGET_TMPDIR").unwrap_or_else(|_| "target/tmp".to_owned());
    let root = format!("{target_dir}/singbox-selfcheck-{}", std::process::id());
    let _ = std::fs::remove_dir_all(&root);
    std::fs::create_dir_all(&root).expect("scratch");

    std::fs::write(format!("{root}/config.json"), &artifact.bytes.bytes)
        .expect("write the artifact");
    let manifest = env!("CARGO_MANIFEST_DIR");
    let workspace = &manifest[..manifest.len() - "crates/caly-singbox".len()];
    let asset = format!("{workspace}assets/cores/sing-box-1.13.20-linux-amd64.tar.gz");
    let extract = std::process::Command::new("/bin/sh")
        .arg("-c")
        .arg(format!(
            "tar -xzf {asset} -C {root} --strip-components=1 && chmod +x {root}/sing-box"
        ))
        .output()
        .expect("extract the pinned core");
    assert!(
        extract.status.success(),
        "extracting the pinned asset failed: {}",
        String::from_utf8_lossy(&extract.stderr)
    );

    let verdict = std::process::Command::new(format!("{root}/sing-box"))
        .arg("check")
        .arg("-c")
        .arg(format!("{root}/config.json"))
        .output()
        .expect("run the core's own config check");
    let spoken = format!(
        "{}{}",
        String::from_utf8_lossy(&verdict.stdout),
        String::from_utf8_lossy(&verdict.stderr)
    );
    assert!(
        verdict.status.success(),
        "sing-box check must accept the rendered artifact:\n{spoken}"
    );

    // And while the artifact is in hand: the credential stays inside the bytes.
    let body = String::from_utf8_lossy(&artifact.bytes.bytes);
    assert!(
        body.contains("CANARY-real-secret"),
        "a real passthrough password must ride verbatim into the artifact"
    );
    for (key, value) in &artifact.annotations {
        assert!(
            !value.contains("CANARY-real-secret"),
            "an annotation ({key}) must not carry the credential: {value}"
        );
    }
    let _ = std::fs::remove_dir_all(&root);
}
