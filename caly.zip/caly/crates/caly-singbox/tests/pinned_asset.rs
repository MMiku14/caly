//! The second core's asset pin (round 57, `ADR-045 §4`): the archive exists in the
//! workspace and hashes to exactly what `SINGBOX_BINARY_SHA256` names. The real backend
//! cannot spawn a sing-box core yet — it refuses by name — but the pin is what makes that
//! refusal a dated scope decision instead of a permanent shrug: the asset is here, hashed,
//! waiting for its spawn path.
//!
//! The hash is taken with the system `sha256sum` (`caly-singbox` deliberately does not
//! depend on `caly-common`; adding a crate edge for one test is not a reason — no ADR, no
//! dependency).

use caly_singbox::SINGBOX_BINARY_SHA256;

// The workspace disallows ad-hoc process spawning by default; this judge *is* the
// deliberate exception — the whole point is to ask the system's own sha256sum instead
// of re-implementing the hash with a crate this package does not depend on.
#[expect(clippy::disallowed_methods)]
#[test]
fn the_pinned_singbox_archive_hashes_to_what_the_plan_names() {
    let manifest = env!("CARGO_MANIFEST_DIR");
    let cut = manifest.len() - "crates/caly-singbox".len();
    let root = &manifest[..cut];
    let path = format!("{root}/assets/cores/sing-box-1.13.20-linux-amd64.tar.gz");
    let metadata = std::fs::metadata(&path)
        .unwrap_or_else(|error| panic!("the pinned sing-box asset must exist at {path}: {error}"));
    assert!(
        metadata.len() > 1_000_000,
        "a real core archive is tens of MB; {} bytes is not the asset",
        metadata.len()
    );
    let output = std::process::Command::new("sha256sum")
        .arg(&path)
        .output()
        .expect("sha256sum is available to the test environment");
    assert!(output.status.success(), "sha256sum failed on {path}");
    let line = String::from_utf8_lossy(&output.stdout);
    let digest = line.split_whitespace().next().unwrap_or_default();
    assert_eq!(
        digest, SINGBOX_BINARY_SHA256,
        "the archive on disk no longer matches the digest the plan carries"
    );
}
