//! Round 58 (`ADR-046 §1`): the sing-box render is schema-honest for a REAL 1.13 core.
//!
//! Every shape asserted here was verified against the pinned sing-box 1.13.20 binary
//! before the render was written (decode + boot): the legacy dns `address` server shape
//! is a FATAL without a deprecation flag, a top-level `tun` key is an unknown-field
//! FATAL, a string `rule_set` rule resolves nothing and kills startup, and a WireGuard
//! *outbound* does not decode at all (it is an endpoint since 1.11). A render that emits
//! any of those is a config the core refuses — these judges hold the render to the
//! shapes the binary actually accepts.

use caly_ir::{
    DnsMode, DnsPolicy, GroupId, GroupType, NodeId, ProfileId, ProxyGroup, ProxyNode,
    ProxyProtocol, ResolvedProfile, RevisionId, RouteRule, RoutingMode, RuleAction, RuleId,
    SemanticDigest, TunPolicy, CoreTarget,
};
use caly_singbox::SingBoxAdapter;
use caly_core::CoreAdapter;
use std::collections::BTreeMap;

fn profile_with(rules: Vec<RouteRule>, tun: Option<TunPolicy>, dns: Option<DnsPolicy>) -> ResolvedProfile {
    ResolvedProfile {
        profile_id: ProfileId::new("sb-render"),
        revision_id: RevisionId("rev:0".to_owned()),
        semantic_digest: SemanticDigest("semantic:0".to_owned()),
        core_target: CoreTarget::SingBox,
        routing_mode: RoutingMode::Rule,
        nodes: vec![
            ProxyNode {
                id: NodeId::new("node-wg"),
                label: "WireGuard 01".to_owned(),
                protocol: ProxyProtocol::WireGuard,
                server: "203.0.113.10".to_owned(),
                port: 10000,
                extensions: BTreeMap::new(),
                passthrough: BTreeMap::new(),
            },
            ProxyNode {
                id: NodeId::new("node-ss"),
                label: "Shadowsocks 01".to_owned(),
                protocol: ProxyProtocol::Shadowsocks,
                server: "ss.example.net".to_owned(),
                port: 10001,
                extensions: BTreeMap::new(),
                // mihomo-shaped key on purpose: the render must translate `cipher` ->
                // sing-box's `method` (`ADR-046 §1`).
                passthrough: BTreeMap::from([
                    ("cipher".to_owned(), "aes-256-gcm".to_owned()),
                    ("password".to_owned(), "real-secret".to_owned()),
                ]),
            },
        ],
        groups: vec![ProxyGroup {
            id: GroupId::new("group-main"),
            label: "Main".to_owned(),
            kind: GroupType::Select,
            members: vec![NodeId::new("node-wg"), NodeId::new("node-ss")],
            selected: None,
        }],
        rules,
        rulesets: Vec::new(),
        dns,
        tun,
        inbounds: Vec::new(),
        outbounds: Vec::new(),
        generated_bytes: None,
    }
}

fn compile(profile: &ResolvedProfile) -> (String, BTreeMap<String, String>) {
    let adapter = SingBoxAdapter;
    let identity = adapter.inspect_binary().expect("identity");
    let capabilities = adapter.capability_set(&identity).expect("capabilities");
    let artifact = adapter.compile(profile, &capabilities).expect("compile");
    (
        String::from_utf8_lossy(&artifact.bytes.bytes).into_owned(),
        artifact.annotations,
    )
}

fn catch_all_rule() -> RouteRule {
    RouteRule {
        id: RuleId::new("rule-01"),
        label: "Match All".to_owned(),
        matcher: "MATCH".to_owned(),
        action: RuleAction::UseGroup,
        target_group: Some(GroupId::new("group-main")),
        target_outbound: None,
    }
}

/// The bootable shape: wireguard is an ENDPOINT, dns servers are typed with a local
/// resolver, the catch-all rule is conditionless, the protocol keys are sing-box's own
/// names, and none of the verified-fatal shapes appear anywhere in the body.
#[test]
fn render_emits_the_shapes_singbox_113_accepts() {
    let (body, annotations) = compile(&profile_with(
        vec![catch_all_rule()],
        Some(TunPolicy { enabled: false, auto_route: false, strict_route: false }),
        Some(DnsPolicy {
            mode: DnsMode::System,
            servers: vec!["https://dns.example/dns-query".to_owned()],
            fake_ip_filter: vec!["*.lan".to_owned()],
        }),
    ));
    println!("{body}");

    // FATAL shapes on 1.13.20 — none of these may appear.
    assert!(!body.contains("\"tun\":"), "a top-level tun key is an unknown-field FATAL");
    assert!(!body.contains("\"rule_set\""), "a string rule_set names a rule-set that does not exist");
    // precise on purpose: a wg endpoint carries `,"address":[…` (an array) and a peer
    // `{"address":"…"` legitimately; the legacy dns shape is `,"address":"…"` — a STRING
    // address that follows a comma.
    assert!(
        !body.contains(",\"address\":\""),
        "the legacy dns address shape (a string address after the tag) is a deprecation FATAL"
    );

    // The verified-bootable shapes.
    assert!(
        body.contains("\"endpoints\":[{\"type\":\"wireguard\""),
        "wireguard is an endpoint since 1.11; the outbound shape does not decode"
    );
    assert!(
        body.contains("\"peers\":[{\"address\":\"203.0.113.10\""),
        "the wg peer carries the node's server/port"
    );
    assert!(
        body.contains("\"type\":\"local\",\"tag\":\"caly-local\""),
        "a local resolver server must exist: domain-addressed servers name it"
    );
    assert!(
        body.contains("\"type\":\"https\",\"tag\":\"dns-1\""),
        "IR dns servers render typed"
    );
    assert!(
        body.contains("\"default_domain_resolver\":\"caly-local\""),
        "route.default_domain_resolver is required when outbounds use domains"
    );
    assert!(
        body.contains("\"method\":\"aes-256-gcm\""),
        "the mihomo-shaped `cipher` key must arrive as sing-box's `method`"
    );
    assert!(
        body.contains("\"password\":\"real-secret\""),
        "real passthrough values ride verbatim"
    );
    assert!(
        body.contains("\"type\":\"selector\",\"tag\":\"group-main\""),
        "groups render as selectors under their group id"
    );
    assert!(
        body.contains("\"rules\":[{\"outbound\":\"group-main\"}]"),
        "the MATCH catch-all renders as a conditionless rule — a condition would not mean MATCH"
    );
    assert!(
        body.contains("{\"type\":\"direct\",\"tag\":\"direct\"}"),
        "an explicit direct outbound exists: route.final needs a real target"
    );
    assert_eq!(
        annotations.get("contains.wireguard").map(String::as_str),
        Some("true"),
        "the wireguard annotation still says so: {annotations:?}"
    );
}

/// A matcher the render cannot translate is elided and COUNTED, never emitted as a
/// reference the core would die on. The annotation is the honesty: the operator sees
/// what the config does not carry.
#[test]
fn untranslatable_matchers_are_elided_and_counted() {
    let mut rule = catch_all_rule();
    rule.matcher = "geoip-cn".to_owned();
    let (body, annotations) = compile(&profile_with(
        vec![rule],
        Some(TunPolicy { enabled: false, auto_route: false, strict_route: false }),
        None,
    ));
    assert_eq!(
        annotations.get("route.rules.elided").map(String::as_str),
        Some("1"),
        "the elision must be counted in annotations: {annotations:?}"
    );
    assert!(
        body.contains("\"rules\":[]"),
        "an untranslatable rule must not be emitted: {body}"
    );
}

/// fake-ip is a tun-side feature: without a tun inbound it is elided (and said so);
/// with one, the fakeip server and its dns rule appear — and still no top-level tun.
#[test]
fn fakeip_is_tun_scoped() {
    let disabled = TunPolicy { enabled: false, auto_route: false, strict_route: false };
    let (_, annotations) = compile(&profile_with(
        vec![catch_all_rule()],
        Some(disabled),
        Some(DnsPolicy {
            mode: DnsMode::FakeIp,
            servers: vec!["8.8.8.8".to_owned()],
            fake_ip_filter: Vec::new(),
        }),
    ));
    assert!(
        annotations.contains_key("dns.fakeip.elided"),
        "fake-ip without tun is elided and the annotation says so: {annotations:?}"
    );

    let (body, _) = compile(&profile_with(
        vec![catch_all_rule()],
        Some(TunPolicy { enabled: true, auto_route: true, strict_route: false }),
        Some(DnsPolicy {
            mode: DnsMode::FakeIp,
            servers: vec!["8.8.8.8".to_owned()],
            fake_ip_filter: Vec::new(),
        }),
    ));
    assert!(
        body.contains("\"type\":\"fakeip\""),
        "with tun enabled the fakeip server renders: {body}"
    );
    assert!(
        body.contains("\"type\":\"tun\",\"tag\":\"caly-tun-inbound\""),
        "tun renders as an INBOUND, never a top-level key: {body}"
    );
    assert!(!body.contains("\"tun\":"), "still no top-level tun key");
}

/// Direct routing mode is its own routing decision (round 60, `ADR-048 §3`): the final
/// outbound is direct and NO rule re-routes traffic into selectors whose demo members are
/// dead tunnels — a Direct-mode core must be able to fetch.
#[test]
fn direct_routing_mode_sends_everything_out_the_direct_outbound() {
    let mut profile = profile_with(
        vec![catch_all_rule()],
        Some(TunPolicy { enabled: false, auto_route: false, strict_route: false }),
        None,
    );
    profile.routing_mode = caly_ir::RoutingMode::Direct;
    let (body, _) = compile(&profile);
    assert!(
        body.contains("\"rules\":[]"),
        "Direct mode must not re-route into groups: {body}"
    );
    assert!(
        body.contains("\"final\":\"direct\""),
        "the final outbound stays direct: {body}"
    );
}

/// Real WireGuard credentials win over the inert constants (round 60 closes
/// `ADR-046 §3.2`): private/peer keys verbatim, comma lists for address and allowed_ips.
#[test]
fn wireguard_passthrough_credentials_override_the_inert_constants() {
    let mut profile = profile_with(
        vec![catch_all_rule()],
        Some(TunPolicy { enabled: false, auto_route: false, strict_route: false }),
        None,
    );
    profile.nodes[0].passthrough = std::collections::BTreeMap::from([
        ("private_key".to_owned(), "REAL-PRIVATE-KEY=".to_owned()),
        ("peer_public_key".to_owned(), "REAL-PEER-PUBLIC-KEY=".to_owned()),
        ("local_address".to_owned(), "10.99.0.2/32, fd00::2/128".to_owned()),
        ("peer_allowed_ips".to_owned(), "10.0.0.0/8, 192.168.0.0/16".to_owned()),
    ]);
    let (body, _) = compile(&profile);
    assert!(
        body.contains("\"private_key\":\"REAL-PRIVATE-KEY=\""),
        "a real private key rides verbatim: {body}"
    );
    assert!(
        body.contains("\"public_key\":\"REAL-PEER-PUBLIC-KEY=\""),
        "a real peer key rides verbatim: {body}"
    );
    assert!(
        body.contains("\"address\":[\"10.99.0.2/32\",\"fd00::2/128\"]"),
        "local_address renders as a comma-split list: {body}"
    );
    assert!(
        body.contains("\"allowed_ips\":[\"10.0.0.0/8\",\"192.168.0.0/16\"]"),
        "peer_allowed_ips renders as a comma-split list: {body}"
    );
    assert!(
        !body.contains(WG_INERT_PRIVATE_KEY_MARK),
        "the inert constant must lose when a real key exists: {body}"
    );
}

/// The inert constants are what a credential-less endpoint still gets (deterministic,
/// shape-valid) — the override judge above is only honest if this side holds too.
const WG_INERT_PRIVATE_KEY_MARK: &str = "AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA=";

/// Determinism: the same profile compiles to the same identity — the whole apply
/// idempotence story stands on it.
#[test]
fn compiling_twice_names_the_same_identity() {
    let profile = profile_with(
        vec![catch_all_rule()],
        Some(TunPolicy { enabled: false, auto_route: false, strict_route: false }),
        None,
    );
    let (_, first) = compile(&profile);
    let (_, second) = compile(&profile);
    assert_eq!(
        first.get("config.identity"),
        second.get("config.identity"),
        "the identity a core is asked to confirm must be stable"
    );
}
