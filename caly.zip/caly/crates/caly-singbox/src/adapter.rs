use std::collections::BTreeMap;

use caly_cap::{
    CapabilityDescriptor, CapabilityDomain, CapabilityKey, CapabilityState, Constraint,
    EvidenceRef, FallbackPolicy, SupportLevel,
};
use caly_core::{
    artifact_digest, stable_checksum_text, ApplyPlanningResult, CapabilitySet, CoreAdapter,
    CoreIdentity, CoreIssue, CoreKind, IssueLevel, NativeValidationReport, RuntimeDriver,
};
use caly_ir::{
    CompiledArtifact, NativeConfigFormat, ProxyProtocol, ResolvedProfile, RuleAction, StableBytes,
};
use caly_plan::{
    ApplyIssue, ApplyIssueLevel, ApplyPlan, ApplyPlanKind, BlobRef, CoreKind as PlanCoreKind,
    CoreSpec, DeployImpact, Durability, EffectPlan, EffectStep, FileMode, InstanceId, NetworkPlan,
    PlanId, PrivilegeSet, ProbeKind, ProbeSpec, SnapshotId,
};

use crate::runtime::SingBoxRuntimeDriver;

#[derive(Default)]
pub struct SingBoxAdapter;

/// The sha256 of the workspace's pinned sing-box asset
/// (`assets/cores/sing-box-1.13.20-linux-amd64.tar.gz`; the archive runs
/// `sing-box version 1.13.20 / go1.25.12 linux/amd64`). Round 57 (`ADR-045 §4`): the plan
/// carries the real digest even though the real backend cannot spawn a sing-box core yet —
/// the asset is pinned now so the day the spawn path exists, the check exists with it.
pub const SINGBOX_BINARY_SHA256: &str =
    "646bc01bf128c32a12eb50d8690e387bba7504da7b1d65c704bd53916e38595a";

impl CoreAdapter for SingBoxAdapter {
    fn inspect_binary(&self) -> Result<CoreIdentity, String> {
        Ok(CoreIdentity {
            kind: CoreKind::SingBox,
            version: "1.0.0-skeleton".to_owned(),
            build: Some("sing-box".to_owned()),
            binary_digest: SINGBOX_BINARY_SHA256.to_owned(),
        })
    }

    fn capability_set(&self, _identity: &CoreIdentity) -> Result<CapabilitySet, String> {
        Ok(CapabilitySet {
            descriptors: vec![
                capability(
                    "dns.fake_ip",
                    "sing-box Fake-IP",
                    CapabilityDomain::Dns,
                    SupportLevel::CalyManaged,
                    CapabilityState::SupportedExact,
                    Details {
                        constraints: vec![Constraint {
                            field: "mode".to_owned(),
                            expected: "fake-ip".to_owned(),
                        }],
                        fallback: None,
                        notes: vec!["sing-box fake-ip is modeled directly".to_owned()],
                    },
                ),
                capability(
                    "outbound.wireguard",
                    "sing-box WireGuard outbound",
                    CapabilityDomain::Outbounds,
                    SupportLevel::NativeManaged,
                    CapabilityState::SupportedNativeOnly,
                    Details {
                        constraints: Vec::new(),
                        fallback: Some(FallbackPolicy::UseNativeOnlyMode),
                        notes: vec!["wireguard remains native-shaped in this slice".to_owned()],
                    },
                ),
                capability(
                    "routing.rules",
                    "sing-box route rules",
                    CapabilityDomain::Routing,
                    SupportLevel::CalyManaged,
                    CapabilityState::SupportedExact,
                    Details {
                        constraints: Vec::new(),
                        fallback: None,
                        notes: vec!["sing-box route rules are compiled from Caly IR".to_owned()],
                    },
                ),
                capability(
                    "network.tun",
                    "sing-box TUN",
                    CapabilityDomain::Tun,
                    SupportLevel::CalyManaged,
                    CapabilityState::SupportedExact,
                    Details {
                        constraints: Vec::new(),
                        fallback: Some(FallbackPolicy::EscalateToRestart),
                        notes: vec!["tun requires coordinated restart".to_owned()],
                    },
                ),
            ],
        })
    }

    fn preflight(
        &self,
        profile: &ResolvedProfile,
        _capabilities: &CapabilitySet,
    ) -> Result<Vec<CoreIssue>, String> {
        let mut issues = vec![CoreIssue {
            level: if profile.outbounds.is_empty() {
                IssueLevel::Warning
            } else {
                IssueLevel::Info
            },
            code: "SINGBOX_PREFLIGHT".to_owned(),
            summary: "sing-box adapter preflight executed".to_owned(),
        }];

        if profile
            .nodes
            .iter()
            .any(|node| matches!(node.protocol, ProxyProtocol::Unknown))
        {
            issues.push(CoreIssue {
                level: IssueLevel::Warning,
                code: "SINGBOX_UNKNOWN_PROTOCOL".to_owned(),
                summary: "some nodes still use unknown protocol in sing-box slice".to_owned(),
            });
        }

        Ok(issues)
    }

    fn compile(
        &self,
        profile: &ResolvedProfile,
        _capabilities: &CapabilitySet,
    ) -> Result<CompiledArtifact, String> {
        let (bytes, notes) = render_singbox_json(profile);
        let mut annotations = common_annotations(profile);
        annotations.insert("core.kind".to_owned(), "sing-box".to_owned());
        if notes.elided_rules > 0 {
            annotations.insert(
                "route.rules.elided".to_owned(),
                notes.elided_rules.to_string(),
            );
        }
        if notes.fakeip_elided {
            annotations.insert(
                "dns.fakeip.elided".to_owned(),
                "fake-ip without a tun inbound changes nothing a core can observe".to_owned(),
            );
        }
        // The identity a core is asked to confirm at apply time must be the artifact it
        // is actually handed (CoreSpec::config_digest), not a digest of the semantic
        // profile. Deriving it from the semantic digest made the ConfigIdentity probe
        // unanswerable: it could never match, for any plan.
        let artifact_digest = artifact_digest("singbox", &bytes);
        annotations.insert("config.identity".to_owned(), artifact_digest.0.clone());
        annotations.insert(
            "contains.wireguard".to_owned(),
            profile
                .nodes
                .iter()
                .any(|node| matches!(node.protocol, ProxyProtocol::WireGuard))
                .to_string(),
        );

        Ok(CompiledArtifact {
            profile_id: profile.profile_id.clone(),
            target_core: CoreKind::SingBox.target(),
            adapter_version: 1,
            artifact_digest,
            file_name_hint: format!("{}.singbox.json", profile.profile_id.0),
            format: NativeConfigFormat::Json,
            entrypoint: "config.json".to_owned(),
            media_type: "application/json".to_owned(),
            bytes,
            annotations,
        })
    }

    fn validate_native(
        &self,
        artifact: &CompiledArtifact,
    ) -> Result<NativeValidationReport, String> {
        let body = String::from_utf8_lossy(&artifact.bytes.bytes);
        let accepted = body.contains("\"outbounds\"") && body.contains("\"route\"");
        let mut issues = vec![CoreIssue {
            level: IssueLevel::Info,
            code: "SINGBOX_NATIVE_VALIDATE".to_owned(),
            summary: format!("sing-box validated {}", artifact.file_name_hint),
        }];

        if !accepted {
            issues.push(CoreIssue {
                level: IssueLevel::Error,
                code: "SINGBOX_NATIVE_REJECTED".to_owned(),
                summary: "sing-box native validation expected outbounds and route sections"
                    .to_owned(),
            });
        }

        Ok(NativeValidationReport { accepted, issues })
    }

    fn plan_apply(
        &self,
        current: Option<&CompiledArtifact>,
        next: &CompiledArtifact,
    ) -> Result<ApplyPlanningResult, String> {
        let tun_enabled = annotation_bool(next, "tun.enabled");
        let wireguard = annotation_bool(next, "contains.wireguard");
        let selection_only = current
            .map(|artifact| selection_only_change(artifact, next))
            .unwrap_or(false);

        let kind = if current
            .map(|artifact| artifact.artifact_digest == next.artifact_digest)
            .unwrap_or(false)
        {
            ApplyPlanKind::Noop
        } else if current.is_none() {
            if tun_enabled || wireguard {
                ApplyPlanKind::RebuildAndRestart
            } else {
                ApplyPlanKind::Restart
            }
        } else if tun_enabled || wireguard {
            ApplyPlanKind::RebuildAndRestart
        } else {
            ApplyPlanKind::Restart
        };

        let impact = match kind {
            ApplyPlanKind::Noop => DeployImpact::Noop,
            ApplyPlanKind::ApiPatch => DeployImpact::RuntimePatch,
            ApplyPlanKind::HotReload => DeployImpact::Reload,
            ApplyPlanKind::Restart => DeployImpact::Restart,
            ApplyPlanKind::RebuildAndRestart => {
                if tun_enabled {
                    DeployImpact::NetworkChange
                } else {
                    DeployImpact::RebuildAndRestart
                }
            }
        };
        let requires = PrivilegeSet {
            needs_admin: tun_enabled,
            needs_network_control: tun_enabled,
            needs_process_control: !matches!(kind, ApplyPlanKind::Noop),
            needs_secret_access: false,
        };
        let mut reasons = vec!["target core=sing-box".to_owned()];
        if selection_only {
            reasons
                .push("selection-only delta still requires restart in sing-box slice".to_owned());
        } else {
            reasons.push("native configuration content changed".to_owned());
        }
        if wireguard {
            reasons.push(
                "wireguard outbound is native-only and escalates to rebuild/restart".to_owned(),
            );
        }
        if tun_enabled {
            reasons.push("tun is enabled and implies network side effects".to_owned());
        }
        reasons.push(format!("selected apply plan kind={kind:?}"));

        let effect_plan = build_effect_plan(kind, current, next, impact, requires.clone());

        Ok(ApplyPlanningResult {
            apply_plan: ApplyPlan {
                kind,
                impact,
                requires,
                issues: vec![ApplyIssue {
                    level: ApplyIssueLevel::Info,
                    code: "SINGBOX_APPLY_PLAN".to_owned(),
                    summary: format!("sing-box selected {:?}", kind),
                }],
                reasons,
            },
            effect_plan,
        })
    }

    fn runtime(&self) -> Result<Box<dyn RuntimeDriver>, String> {
        Ok(Box::new(SingBoxRuntimeDriver::default()))
    }
}

/// The tail of a descriptor row — bundled so `capability` stays inside the argument
/// budget (`crates/caly-cap/src/catalog.rs` pays the same toll with eight bare params;
/// this crate does not).
struct Details {
    constraints: Vec<Constraint>,
    fallback: Option<FallbackPolicy>,
    notes: Vec<String>,
}

fn capability(
    key: &str,
    title: &str,
    domain: CapabilityDomain,
    support_level: SupportLevel,
    state: CapabilityState,
    details: Details,
) -> CapabilityDescriptor {
    CapabilityDescriptor {
        key: CapabilityKey(key.to_owned()),
        title: title.to_owned(),
        domain,
        support_level,
        state,
        constraints: details.constraints,
        fallback: details.fallback,
        evidence_ref: EvidenceRef {
            fixture_id: Some(format!("singbox-{key}")),
            golden_test_id: None,
            native_validation_test_id: None,
            runtime_test_id: None,
        },
        notes: details.notes,
    }
}

fn render_singbox_json(profile: &ResolvedProfile) -> (StableBytes, RenderNotes) {
    let mut notes = RenderNotes::default();

    // --- dns -------------------------------------------------------------------
    // sing-box 1.12+ refuses the legacy `address` server shape outright (verified
    // against 1.13.20: FATAL without ENABLE_DEPRECATED_LEGACY_DNS_SERVERS), so servers
    // are typed. A `local` server comes first: every server whose address is a domain
    // must name a domain resolver, and `route.default_domain_resolver` needs one too.
    let mut dns_servers = vec!["{\"type\":\"local\",\"tag\":\"caly-local\"}".to_owned()];
    let dns_policy = profile.dns.as_ref();
    for (index, server) in dns_policy
        .map(|dns| dns.servers.iter().enumerate().collect::<Vec<_>>())
        .unwrap_or_default()
    {
        let tag = format!("dns-{}", index + 1);
        let kind = if server.starts_with("https://") {
            "https"
        } else {
            "udp"
        };
        let resolver = if server.parse::<std::net::IpAddr>().is_ok() {
            ""
        } else {
            ",\"domain_resolver\":\"caly-local\""
        };
        dns_servers.push(format!(
            "{{\"type\":\"{kind}\",\"tag\":\"{tag}\",\"server\":\"{server}\"{resolver}}}"
        ));
    }
    let wants_fakeip = dns_policy
        .map(|dns| matches!(dns.mode, caly_ir::DnsMode::FakeIp | caly_ir::DnsMode::Mixed))
        .unwrap_or(false);
    let tun_enabled = profile.tun.as_ref().map(|tun| tun.enabled).unwrap_or(false);
    // fake-ip is a TUN-side feature: without a tun inbound it changes nothing a running
    // core can observe, and the fakeip server shape (default-server + dns rules +
    // resolver chain) is its own migration. Elided without tun, said so in annotations.
    let fakeip_server = if wants_fakeip && tun_enabled {
        let _ = &mut notes;
        Some(
            "{\"type\":\"fakeip\",\"tag\":\"caly-fakeip\",\"inet4_range\":\"198.18.0.0/15\"}"
                .to_owned(),
        )
    } else {
        if wants_fakeip {
            notes.fakeip_elided = true;
        }
        None
    };
    let dns_rules = if fakeip_server.is_some() {
        "[{\"server\":\"caly-fakeip\",\"query_type\":[\"A\",\"AAAA\"]}]"
    } else {
        "[]"
    };
    if let Some(server) = fakeip_server {
        dns_servers.push(server);
    }
    let dns_block = format!(
        "{{\"servers\":[{}],\"strategy\":\"prefer_ipv4\",\"rules\":{dns_rules}}}",
        dns_servers.join(",")
    );

    // --- endpoints (wireguard) and outbounds -----------------------------------
    // WireGuard became an endpoint in sing-box 1.11+; an outbound entry is refused at
    // decode (verified: `unknown field "server"` on the outbound shape). The demo IR
    // carries no wg credentials, so the structural keys are inert constants — the same
    // doctrine as `structural_params` in the merge: keys load-bearing, values inert,
    // real `passthrough` overrides win.
    let mut endpoints = Vec::new();
    let mut outbounds = vec!["{\"type\":\"direct\",\"tag\":\"direct\"}".to_owned()];
    for node in &profile.nodes {
        if matches!(node.protocol, ProxyProtocol::WireGuard) {
            endpoints.push(render_wg_endpoint(node));
            continue;
        }
        outbounds.push(render_node_outbound(node));
    }

    for group in &profile.groups {
        let members = group
            .members
            .iter()
            .map(|member| format!("\"{}\"", member.0))
            .collect::<Vec<_>>()
            .join(",");
        let selected = group
            .selected
            .as_ref()
            .map(|node| format!(",\"default\":\"{}\"", node.0))
            .unwrap_or_default();
        outbounds.push(format!(
            "{{\"type\":\"selector\",\"tag\":\"{}\",\"outbounds\":[{}]{} }}",
            group.id.0, members, selected
        ));
    }

    // --- inbounds ---------------------------------------------------------------
    let mut inbounds = vec![
        "{\"type\":\"mixed\",\"tag\":\"mixed-in\",\"listen\":\"127.0.0.1\",\"listen_port\":7890}"
            .to_owned(),
    ];
    if tun_enabled {
        // A tun *inbound*, never a top-level `tun` key — sing-box refuses the latter at
        // decode (verified: `unknown field "tun"`). Plans that enable it still die at
        // NetApply before any spawn, so this entry is decode-honest only.
        inbounds.push("{\"type\":\"tun\",\"tag\":\"caly-tun-inbound\"}".to_owned());
    }

    // --- route -------------------------------------------------------------------
    // `MATCH` is the IR's catch-all and translates to a conditionless rule (verified
    // bootable); any other matcher names a rule-set this render cannot honestly produce
    // yet, so it is elided and COUNTED rather than emitted as a decode-fatal reference.
    //
    // Direct routing mode (round 60, `ADR-048 §3`) is the one mode that IS its own
    // routing decision: `final: direct` already sends everything out the direct
    // outbound, and a rule that re-routes traffic into a selector whose demo members are
    // dead tunnels would make the whole core unable to fetch anything. Rule mode keeps
    // its rules; Direct mode keeps its word.
    let mut rules = Vec::new();
    let rule_mode = matches!(profile.routing_mode, caly_ir::RoutingMode::Rule);
    for rule in &profile.rules {
        if !rule_mode {
            continue;
        }
        if rule.matcher != "MATCH" {
            notes.elided_rules += 1;
            continue;
        }
        let action = match rule.action {
            RuleAction::UseGroup => rule
                .target_group
                .as_ref()
                .map(|group| format!("\"outbound\":\"{}\"", group.0))
                .unwrap_or_else(|| "\"action\":\"direct\"".to_owned()),
            RuleAction::Direct => "\"action\":\"direct\"".to_owned(),
            RuleAction::Reject => "\"action\":\"reject\"".to_owned(),
            RuleAction::UseOutbound => rule
                .target_outbound
                .as_ref()
                .map(|outbound| format!("\"outbound\":\"{}\"", outbound.0))
                .unwrap_or_else(|| "\"action\":\"direct\"".to_owned()),
        };
        rules.push(format!("{{{action}}}"));
    }
    let route_block = format!(
        "{{\"final\":\"direct\",\"default_domain_resolver\":\"caly-local\",\"rules\":[{}]}}",
        rules.join(",")
    );

    let endpoints_block = if endpoints.is_empty() {
        String::new()
    } else {
        format!("\"endpoints\":[{}],", endpoints.join(","))
    };

    let body = format!(
        "{{\"log\":{{\"level\":\"info\"}},{endpoints_block}\"dns\":{dns_block},\
         \"inbounds\":[{}],\"outbounds\":[{}],\"route\":{route_block},\
         \"experimental\":{{\"cache_file\":{{\"enabled\":true}}}}}}",
        inbounds.join(","),
        outbounds.join(","),
    );
    (StableBytes::new(body.into_bytes()), notes)
}

/// A WireGuard endpoint (the only shape sing-box 1.11+ decodes, `ADR-046 §1`). Real
/// credentials ride from `passthrough` when the source provided them (round 60 closes the
/// promise of `ADR-046 §3.2`): `private_key`/`peer_public_key` verbatim, `local_address`
/// and `peer_allowed_ips` as comma lists. Absent keys fall back to the deterministic
/// inert constants — keys load-bearing, values inert, real values always winning.
fn render_wg_endpoint(node: &caly_ir::ProxyNode) -> String {
    let passthrough = |key: &str| node.passthrough.get(key).cloned();
    let private_key = passthrough("private_key").unwrap_or_else(|| WG_INERT_PRIVATE_KEY.to_owned());
    let peer_public_key =
        passthrough("peer_public_key").unwrap_or_else(|| WG_INERT_PUBLIC_KEY.to_owned());
    let address = passthrough("local_address").unwrap_or_else(|| "172.16.0.2/32".to_owned());
    let allowed_ips = passthrough("peer_allowed_ips").unwrap_or_else(|| "0.0.0.0/0".to_owned());
    let list = |csv: &str| {
        csv.split(',')
            .map(|entry| format!("\"{}\"", entry.trim()))
            .collect::<Vec<_>>()
            .join(",")
    };
    format!(
        "{{\"type\":\"wireguard\",\"tag\":\"{tag}\",\"address\":[{address}],\
         \"private_key\":\"{private_key}\",\"peers\":[{{\"address\":\"{server}\",\
         \"port\":{port},\"public_key\":\"{peer_public_key}\",\
         \"allowed_ips\":[{allowed_ips}]}}]}}",
        address = list(&address),
        allowed_ips = list(&allowed_ips),
        tag = node.id.0,
        server = node.server,
        port = node.port,
    )
}

/// sing-box names protocol parameters differently than the IR's mihomo-shaped
/// `passthrough` keys (`cipher` -> `method`/`security`); the structural ones are filled
/// inert when absent — a node without them is a config the core refuses to parse, and
/// inventing them silently would be the same lie in the other direction.
fn render_node_outbound(node: &caly_ir::ProxyNode) -> String {
    let get = |singbox_key: &str, ir_keys: &[&str]| -> Option<String> {
        for ir_key in ir_keys {
            if let Some(value) = node.passthrough.get(*ir_key) {
                return Some(format!("\"{singbox_key}\":\"{value}\""));
            }
        }
        None
    };
    let mut params = Vec::new();
    match node.protocol {
        ProxyProtocol::Shadowsocks => {
            params.push(
                get("method", &["method", "cipher"])
                    .unwrap_or("\"method\":\"aes-128-gcm\"".to_owned()),
            );
            params.push(
                get("password", &["password"])
                    .unwrap_or_else(|| "\"password\":\"caly-demo\"".to_owned()),
            );
        }
        ProxyProtocol::Vmess => {
            params.push(
                get("uuid", &["uuid"]).unwrap_or_else(|| format!("\"uuid\":\"{INERT_UUID}\"")),
            );
            params.push(
                get("security", &["security", "cipher"])
                    .unwrap_or("\"security\":\"auto\"".to_owned()),
            );
        }
        ProxyProtocol::Vless | ProxyProtocol::Tuic => {
            params.push(
                get("uuid", &["uuid"]).unwrap_or_else(|| format!("\"uuid\":\"{INERT_UUID}\"")),
            );
            params.push(
                get("password", &["password"])
                    .unwrap_or_else(|| "\"password\":\"caly-demo\"".to_owned()),
            );
        }
        ProxyProtocol::Trojan | ProxyProtocol::Hysteria2 => {
            params.push(
                get("password", &["password"])
                    .unwrap_or_else(|| "\"password\":\"caly-demo\"".to_owned()),
            );
        }
        _ => {}
    }
    format!(
        "{{\"type\":\"{}\",\"tag\":\"{}\",\"server\":\"{}\",\"server_port\":{}{}}}",
        proxy_protocol_name(node.protocol),
        node.id.0,
        node.server,
        node.port,
        params
            .iter()
            .map(|param| format!(",{param}"))
            .collect::<Vec<_>>()
            .join("")
    )
}

/// Side facts the compiler folds into annotations: what the render honestly left out.
#[derive(Default)]
struct RenderNotes {
    elided_rules: usize,
    fakeip_elided: bool,
}

/// base64(32 zero bytes) — inert, deterministic, and shape-valid: sing-box wants a
/// 32-byte key in base64 and refuses shorter garbage at decode.
const WG_INERT_PRIVATE_KEY: &str = "AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA=";
const WG_INERT_PUBLIC_KEY: &str = "BBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBB=";
const INERT_UUID: &str = "00000000-0000-0000-0000-000000000000";

fn common_annotations(profile: &ResolvedProfile) -> BTreeMap<String, String> {
    let mut annotations = BTreeMap::new();
    annotations.insert(
        "semantic_digest".to_owned(),
        profile.semantic_digest.0.clone(),
    );
    annotations.insert(
        "tun.enabled".to_owned(),
        profile
            .tun
            .as_ref()
            .map(|tun| tun.enabled)
            .unwrap_or(false)
            .to_string(),
    );
    annotations.insert("selection_digest".to_owned(), selection_digest(profile));
    annotations.insert("selections".to_owned(), selection_pairs(profile).join(","));
    annotations
}

fn selection_digest(profile: &ResolvedProfile) -> String {
    format!(
        "sel:{:016x}",
        stable_checksum_text(&selection_pairs(profile).join("|"))
    )
}

fn selection_pairs(profile: &ResolvedProfile) -> Vec<String> {
    profile
        .groups
        .iter()
        .map(|group| {
            format!(
                "{}={}",
                group.id.0,
                group
                    .selected
                    .as_ref()
                    .map(|node| node.0.clone())
                    .unwrap_or_else(|| "none".to_owned())
            )
        })
        .collect()
}

fn selection_only_change(current: &CompiledArtifact, next: &CompiledArtifact) -> bool {
    current.annotations.get("semantic_digest") == next.annotations.get("semantic_digest")
        && current.annotations.get("selection_digest") != next.annotations.get("selection_digest")
}

fn annotation_bool(artifact: &CompiledArtifact, key: &str) -> bool {
    artifact
        .annotations
        .get(key)
        .map(|value| value == "true")
        .unwrap_or(false)
}

fn build_effect_plan(
    kind: ApplyPlanKind,
    current: Option<&CompiledArtifact>,
    next: &CompiledArtifact,
    impact: DeployImpact,
    requires: PrivilegeSet,
) -> Option<EffectPlan> {
    if matches!(kind, ApplyPlanKind::Noop) {
        return None;
    }

    let instance = InstanceId("singbox-core-instance".to_owned());
    let snapshot = SnapshotId(format!("singbox-snapshot-{}", next.profile_id.0));
    let core_spec = CoreSpec {
        kind: PlanCoreKind::SingBox,
        binary_digest: SINGBOX_BINARY_SHA256.to_owned(),
        config_digest: next.artifact_digest.0.clone(),
    };
    let blob = BlobRef {
        digest: next.artifact_digest.0.clone(),
        size_hint: Some(next.size_bytes() as u64),
    };

    let mut steps = vec![
        EffectStep::WriteObject {
            digest: next.artifact_digest.0.clone(),
            source: blob,
            durability: Durability::D2,
        },
        EffectStep::MaterializeArtifact {
            digest: next.artifact_digest.0.clone(),
            at: format!("runtime/{}/{}", next.profile_id.0, next.entrypoint),
            mode: FileMode::ReadOnlyArtifact,
        },
    ];

    if annotation_bool(next, "tun.enabled") {
        steps.push(EffectStep::NetApply {
            plan: NetworkPlan {
                summary: "configure TUN + routes for sing-box".to_owned(),
                requires_privilege: true,
            },
        });
    }

    if current.is_some() {
        steps.push(EffectStep::StopCore {
            instance: instance.clone(),
            grace_ms: 2_500,
        });
    }
    steps.push(EffectStep::SpawnCore { spec: core_spec });
    steps.push(EffectStep::Probe {
        probe: ProbeSpec {
            kind: ProbeKind::ApiReady,
            target: None,
        },
        deadline_ms: 3_000,
    });
    // Round 59 (`ADR-047 §3`): the controller answering is not the proxy door being
    // open — the two come up milliseconds apart, and a completed apply must mean both.
    steps.push(EffectStep::Probe {
        probe: ProbeSpec {
            kind: ProbeKind::InboundListening,
            target: None,
        },
        deadline_ms: 3_000,
    });
    steps.push(EffectStep::Probe {
        probe: ProbeSpec {
            kind: ProbeKind::ConfigIdentity,
            target: next.annotations.get("config.identity").cloned(),
        },
        deadline_ms: 3_000,
    });
    // Round 69 (`IMPLEMENTATION_STATUS §8.4`): `ApiReady` proved the controller answers;
    // this probe names what the plan spawned. The real backend reads `GET /version` so the
    // evidence carries the core's self-reported version (`probe.core-identity kind=…
    // version=…`) — a 200 with an unreadable body is a refusal, not an identity.
    steps.push(EffectStep::Probe {
        probe: ProbeSpec {
            kind: ProbeKind::CoreIdentity,
            target: None,
        },
        deadline_ms: 3_000,
    });
    // Round 69: and it proves the counters are the core's own, then records their value as
    // the apply-time baseline (`probe.telemetry-traffic upload_total=… download_total=…`),
    // so a later judge can show a fetch through the core moves them.
    steps.push(EffectStep::Probe {
        probe: ProbeSpec {
            kind: ProbeKind::TelemetryTraffic,
            target: None,
        },
        deadline_ms: 3_000,
    });
    steps.push(EffectStep::MarkSnapshot {
        snapshot_id: snapshot,
    });
    steps.push(EffectStep::CommitRevision { revision: 1 });

    let mut compensations = Vec::new();
    if annotation_bool(next, "tun.enabled") {
        compensations.push(EffectStep::NetRevert {
            txn_id: caly_plan::NetTxnId("singbox-net-revert".to_owned()),
        });
    }
    if current.is_some() {
        compensations.push(EffectStep::StopCore {
            instance,
            grace_ms: 1_000,
        });
    }

    Some(EffectPlan {
        id: PlanId(format!("singbox-effect-plan-{}", next.profile_id.0)),
        steps,
        compensations,
        requires,
        impact,
    })
}

fn proxy_protocol_name(protocol: ProxyProtocol) -> &'static str {
    match protocol {
        ProxyProtocol::Shadowsocks => "shadowsocks",
        ProxyProtocol::Vmess => "vmess",
        ProxyProtocol::Vless => "vless",
        ProxyProtocol::Trojan => "trojan",
        ProxyProtocol::Hysteria2 => "hysteria2",
        ProxyProtocol::Tuic => "tuic",
        ProxyProtocol::WireGuard => "wireguard",
        ProxyProtocol::Unknown => "direct",
    }
}
