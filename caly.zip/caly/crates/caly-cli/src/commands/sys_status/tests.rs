//! Tests for `commands/sys_status.rs`, extracted to the child
//! convention file (audit #70 file-length budget).

use super::*;


fn declared(enabled: bool) -> SystemProxyConfig {
    SystemProxyConfig {
        enabled,
        host: "127.0.0.1".to_owned(),
        port: Some(7890),
    }
}

fn actual(mode: &str, endpoint: &str) -> (String, String) {
    (mode.to_owned(), endpoint.to_owned())
}

#[test]
fn diagnose_consistent_states_are_silent() {
    // Engaged by caly: manual + matching endpoint + recovery record.
    assert_eq!(
        diagnose(
            &declared(true),
            &actual("manual", "127.0.0.1:7890"),
            true,
            "127.0.0.1:7890"
        ),
        None
    );
    // Declared disabled and the desktop is off.
    assert_eq!(
        diagnose(
            &declared(false),
            &actual("none", ""),
            false,
            "127.0.0.1:7890"
        ),
        None
    );
}

#[test]
fn diagnose_declared_enabled_but_not_engaged() {
    assert!(
        diagnose(
            &declared(true),
            &actual("none", ""),
            false,
            "127.0.0.1:7890"
        )
        .is_some()
    );
    assert!(
        diagnose(
            &declared(true),
            &actual("auto", "file:///x"),
            true,
            "127.0.0.1:7890"
        )
        .is_some()
    );
    // Manual but no recovery record — likely engaged outside caly.
    let d = diagnose(
        &declared(true),
        &actual("manual", "127.0.0.1:7890"),
        false,
        "127.0.0.1:7890",
    )
    .expect("missing record must be flagged");
    assert!(d.contains("no recovery record"), "{d}");
    // Manual but pointing elsewhere.
    let d = diagnose(
        &declared(true),
        &actual("manual", "10.0.0.1:3128"),
        true,
        "127.0.0.1:7890",
    )
    .expect("endpoint mismatch must be flagged");
    assert!(d.contains("points at 10.0.0.1:3128"), "{d}");
}

#[test]
fn diagnose_declared_disabled_but_desktop_engaged() {
    assert!(
        diagnose(
            &declared(false),
            &actual("manual", "10.0.0.1:3128"),
            false,
            "127.0.0.1:7890"
        )
        .is_some()
    );
    assert!(
        diagnose(
            &declared(false),
            &actual("auto", "file:///x"),
            true,
            "127.0.0.1:7890"
        )
        .is_some()
    );
}

#[test]
fn diagnose_unreadable_desktop_is_flagged_not_fatal() {
    let d = diagnose(
        &declared(true),
        &actual("unknown", ""),
        false,
        "127.0.0.1:7890",
    )
    .expect("unreadable state must be flagged");
    assert!(d.contains("unreadable"), "{d}");
}

#[test]
fn actual_label_renders_modes() {
    assert_eq!(
        actual_label(&actual("manual", "127.0.0.1:7890")),
        "manual 127.0.0.1:7890"
    );
    assert_eq!(actual_label(&actual("manual", "")), "manual (no endpoint)");
    assert_eq!(
        actual_label(&actual("auto", "file:///x")),
        "auto (PAC file:///x)"
    );
    assert_eq!(actual_label(&actual("auto", "")), "auto (PAC)");
    assert_eq!(actual_label(&actual("none", "")), "disabled");
    assert_eq!(actual_label(&actual("bogus", "")), "unknown");
}

#[test]
fn desktop_label_prefixes_backend_before_session() {
    // the session half is ambient (reads the live environment), so
    // only the backend prefix is asserted.
    assert!(
        desktop_label(DesktopProxyMode::SessionEnv).starts_with("session-env ("),
        "{}",
        desktop_label(DesktopProxyMode::SessionEnv)
    );
    assert!(
        desktop_label(DesktopProxyMode::Gnome).starts_with("gnome ("),
        "{}",
        desktop_label(DesktopProxyMode::Gnome)
    );
}
