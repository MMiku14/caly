//! `set config …` dispatch.
//!
//! `apply` / `generate` / `default` / `edit` route
//! through the typed `client::run_client` / `client::*`
//! helpers (the `bridge` shim was retired). 
//! `diff` is a real line-by-line diff (current vs
//! `--file <PATH>` or vs the documented default).

use std::process::ExitCode;

use crate::cli::SetConfigCmd;
use caly_ops::client::legacy::ConfigCmd;
use caly_layout::CliOutput;

pub fn dispatch(c: SetConfigCmd, options: crate::cli::CliOptions, _output: CliOutput) -> ExitCode {
    match c {
        SetConfigCmd::Apply => {
            caly_ops::client::run_client(crate::ClientCommand::Config(ConfigCmd::Apply), options)
        }
        SetConfigCmd::Generate => caly_ops::client::config_generate::generate_config(options.json),
        SetConfigCmd::Default => caly_ops::client::config_generate::reset_default_config(options.json),
        SetConfigCmd::Edit(editor) => {
            let editor = match editor {
                crate::cli::Editor::Vim => caly_ops::types::Editor::Vim,
                crate::cli::Editor::Nvim => caly_ops::types::Editor::Nvim,
            };
            caly_ops::client::config_generate::edit_config(editor, options.json)
        }
        SetConfigCmd::Diff { file } => {
            caly_ops::client::config_generate::diff_config(file.as_deref(), options.json)
        }
        SetConfigCmd::Set { key, value, apply } => {
            caly_ops::client::config_kv::config_set(options.json, &key, &value, apply)
        }
    }
}
