//! `caly status` — daemon snapshot with the R5 probe budget.

use std::io::IsTerminal;
use std::process::ExitCode;
use std::time::Duration;

use caly_protocol::client::{ClientContract, UdsClient};
use caly_protocol::protocol::v2::{WatchEventsRequest, WatchResponse};

use caly_layout::CliOutput;

/// R5 (cli-v3-design.md §14): `caly status` is the triage surface
/// and must never hang on a wedged socket. Connect + handshake +
/// one snapshot race this budget on a helper thread.
const PROBE_BUDGET: Duration = Duration::from_millis(500);

pub fn run(options: crate::cli::CliOptions, _output: CliOutput, watch: bool) -> ExitCode {
    let socket = resolve_socket(&options);
    if watch {
        return run_watch(&options, &socket);
    }
    match caly_ops::client::execute::probe_snapshot_with_budget(&socket, PROBE_BUDGET) {
        Ok(snapshot) => {
            render_snapshot(&snapshot, options.json);
            ExitCode::SUCCESS
        }
        Err(reason) => offline_digest(&socket, options.json, &reason),
    }
}

/// `caly status --watch`: subscribe to daemon projection events, but re-fetch
/// the full snapshot before every redraw so the renderer stays authoritative.
/// The event filter only limits wakeups; it never drops recovery snapshots.
fn run_watch(options: &crate::cli::CliOptions, socket: &std::path::Path) -> ExitCode {
    let json = options.json;
    let mut client = match UdsClient::connect(socket.to_path_buf()) {
        Ok(client) => client,
        Err(error) => return offline_digest(socket, json, &error.to_string()),
    };
    if let Err(error) = caly_ops::client::execute::handshake(&mut client) {
        return offline_digest(socket, json, &error.to_string());
    }
    let filter = Some(vec![
        "DesiredReplaced".to_owned(),
        "AppliedReplaced".to_owned(),
        "ObservedReplaced".to_owned(),
        "PlatformReplaced".to_owned(),
        "CapabilitiesReplaced".to_owned(),
        "NodesReplaced".to_owned(),
        "GroupsReplaced".to_owned(),
        "SourcesReplaced".to_owned(),
    ]);
    let stream = match client.watch(WatchEventsRequest {
        after: None,
        filter,
    }) {
        Ok(stream) => stream,
        Err(error) => return offline_digest(socket, json, &error.to_string()),
    };
    for item in stream {
        match item {
            Ok(WatchResponse::FullSnapshot(snapshot)) => {
                redraw_snapshot(&snapshot, json);
            }
            Ok(WatchResponse::Event(_)) => match client.snapshot() {
                Ok(snapshot) => redraw_snapshot(&snapshot, json),
                Err(error) => return offline_digest(socket, json, &error.to_string()),
            },
            Err(error) => return offline_digest(socket, json, &error.to_string()),
        }
    }
    offline_digest(socket, json, "daemon watch stream ended")
}

/// Renders one snapshot for `caly status`, including the best-effort
/// kernel-side live-selection enrichment.
fn render_snapshot(snapshot: &caly_protocol::protocol::v2::WirePresentationSnapshot, json: bool) {
    // The running kernel's live selection is the authority for the
    // `selected-node` line: the daemon's applied projection only records
    // `select_proxy`/group picks it witnessed, so kernel-side switches and
    // restarts left `status` stale (audit). Best-effort: offline
    // kernel or query failure keeps the snapshot value.
    let kernel_selected = kernel_selected_display(snapshot);
    caly_ops::client::output::render_status_snapshot(snapshot, json, kernel_selected.as_deref());
}

/// Watch-mode redraw: clear a TTY between frames, piped JSON keeps one line
/// per event so it stays consumable by `jq`-style pipelines.
fn redraw_snapshot(snapshot: &caly_protocol::protocol::v2::WirePresentationSnapshot, json: bool) {
    if std::io::stdout().is_terminal() && !json {
        print!("\x1b[2J\x1b[H");
    }
    render_snapshot(snapshot, json);
}

/// Resolves the daemon UDS exactly like the one-shot status path.
fn resolve_socket(options: &crate::cli::CliOptions) -> std::path::PathBuf {
    options.socket.clone().unwrap_or_else(|| {
        std::env::var_os("CALY_SOCKET").map_or_else(
            || caly_platform::paths::AppPaths::from_env().socket_path(),
            std::path::PathBuf::from,
        )
    })
}

/// Resolves the running kernel's live selection (proxy-group `now`) onto a
/// display name, or `None` when the kernel is offline, reports no selection,
/// or the selection does not map to a snapshot node (builtins like
/// DIRECT/REJECT pass through verbatim).
fn kernel_selected_display(
    snapshot: &caly_protocol::protocol::v2::WirePresentationSnapshot,
) -> Option<String> {
    // M3 (boundary audit): the kernel query can block up to
    // 2×QUERY_TIMEOUT on a wedged control socket — far beyond status's
    // 500ms probe budget. Run it on a helper thread and give up after the
    // budget; the renderer then falls back to the snapshot value.
    let core_kind = snapshot.applied.core_kind;
    let nodes: Vec<([u8; 16], String)> = snapshot
        .nodes
        .iter()
        .map(|node| (node.node_id, node.name.as_str().to_owned()))
        .collect();
    let (sender, receiver) = std::sync::mpsc::channel();
    std::thread::spawn(move || {
        let _ = sender.send(kernel_selected_display_sync(core_kind, &nodes));
    });
    receiver
        .recv_timeout(std::time::Duration::from_millis(500))
        .ok()
        .flatten()
}

fn kernel_selected_display_sync(
    core_kind: Option<i32>,
    nodes: &[([u8; 16], String)],
) -> Option<String> {
    use std::str::FromStr;
    let core = caly_protocol::protocol::v2::WireCoreKind::from_wire(core_kind?)?;
    let label = core.label().to_owned();
    let mut control = caly_ops::client::query::build_control(&label).ok()?;
    let groups = control
        .proxy_groups(caly_ops::client::query::QUERY_TIMEOUT)
        .ok()?;
    let now = groups.iter().find_map(|group| group.selected.clone())?;
    if core == caly_protocol::protocol::v2::WireCoreKind::SingBox {
        // The Clash-compat surface reports the outbound tag `proxy-<hex>`,
        // whose hex is exactly the node id; map back to the display name.
        let hex = now.strip_prefix("proxy-")?;
        let node_id = caly_domain::NodeId::from_str(hex).ok()?;
        let name = nodes
            .iter()
            .find(|(id, _)| *id == node_id.into_bytes())
            .map(|(_, name)| caly_ops::client::output::decode_display_name(name));
        return Some(name.unwrap_or(now));
    }
    // Mihomo reports the plain display name; pass it through verbatim.
    Some(now)
}

/// The R5 degraded face: an offline digest (daemon / socket /
/// context profile) on stdout for humans, plus the standard error
/// envelope on stderr; the JSON envelope gains `profile` and
/// `socket` keys so a script need not re-probe. The exit code
/// stays 1 (C-A contract: an unreachable daemon is a failure,
/// never a clean degraded zero).
fn offline_digest(socket: &std::path::Path, json: bool, reason: &str) -> ExitCode {
    let paths = caly_platform::paths::AppPaths::from_env();
    let profile = caly_ops::client::context::current(&paths);
    let error = caly_ops::error::CliError::new(caly_ops::error::DAEMON_UNREACHABLE, reason, "status")
        .with_hint("start it with `caly daemon`, or check `caly doctor`");
    if json {
        let mut value = error.to_json();
        value["profile"] = serde_json::json!(profile);
        value["socket"] = serde_json::json!(socket.display().to_string());
        eprintln!("{value}");
        return ExitCode::FAILURE;
    }
    caly_layout::KvBlock::plain()
        .indent(0)
        .row("daemon", "unreachable")
        .row("socket", socket.display().to_string())
        .row(
            "profile",
            profile
                .as_deref()
                .unwrap_or("(no context; see `caly profile list`)"),
        )
        .print();
    caly_layout::report_error(CliOutput::Human, &error);
    ExitCode::FAILURE
}
