use caly_api::{ApiError, ErrorCode};

#[derive(Clone, Copy, Debug, Eq, PartialEq)]
#[repr(i32)]
pub enum ExitCode {
    Success = 0,
    GeneralFailure = 1,
    Usage = 2,
    ConfigInvalid = 3,
    Conflict = 4,
    UnsupportedCapability = 5,
    CoreNotRunning = 6,
    CoreFailed = 7,
    Permission = 8,
    NetOs = 9,
    Storage = 10,
    Timeout = 11,
    Unavailable = 12,
    ProtoMismatch = 13,
    CursorStale = 14,
    Cancelled = 15,
    Internal = 16,
}

impl ExitCode {
    pub const fn as_i32(self) -> i32 {
        self as i32
    }

    /// The documented exit-code name, as `docs/EXIT_CODES.md §2/§3` spell it. For
    /// 3..=16 this is the same string as `ErrorCode::as_str` for the mapped code;
    /// `exit_code_table.rs` pins the two never to drift apart.
    pub const fn as_str(self) -> &'static str {
        match self {
            ExitCode::Success => "SUCCESS",
            ExitCode::GeneralFailure => "GENERAL_FAILURE",
            ExitCode::Usage => "USAGE",
            ExitCode::ConfigInvalid => "CONFIG_INVALID",
            ExitCode::Conflict => "CONFLICT",
            ExitCode::UnsupportedCapability => "UNSUPPORTED_CAPABILITY",
            ExitCode::CoreNotRunning => "CORE_NOT_RUNNING",
            ExitCode::CoreFailed => "CORE_FAILED",
            ExitCode::Permission => "PERMISSION",
            ExitCode::NetOs => "NET_OS",
            ExitCode::Storage => "STORAGE",
            ExitCode::Timeout => "TIMEOUT",
            ExitCode::Unavailable => "UNAVAILABLE",
            ExitCode::ProtoMismatch => "PROTO_MISMATCH",
            ExitCode::CursorStale => "CURSOR_STALE",
            ExitCode::Cancelled => "CANCELLED",
            ExitCode::Internal => "INTERNAL",
        }
    }
}

pub const fn from_error_code(code: ErrorCode) -> ExitCode {
    match code {
        ErrorCode::ConfigInvalid => ExitCode::ConfigInvalid,
        ErrorCode::Conflict => ExitCode::Conflict,
        ErrorCode::UnsupportedCapability => ExitCode::UnsupportedCapability,
        ErrorCode::CoreNotRunning => ExitCode::CoreNotRunning,
        ErrorCode::CoreFailed => ExitCode::CoreFailed,
        ErrorCode::Permission => ExitCode::Permission,
        ErrorCode::NetOs => ExitCode::NetOs,
        ErrorCode::Storage => ExitCode::Storage,
        ErrorCode::Timeout => ExitCode::Timeout,
        ErrorCode::Unavailable => ExitCode::Unavailable,
        ErrorCode::ProtoMismatch => ExitCode::ProtoMismatch,
        ErrorCode::CursorStale => ExitCode::CursorStale,
        ErrorCode::Cancelled => ExitCode::Cancelled,
        ErrorCode::Internal => ExitCode::Internal,
    }
}

pub const fn from_api_error(error: &ApiError) -> ExitCode {
    from_error_code(error.code)
}

/// Map a daemon's wire refusal code (the `code` record on a REFUSAL frame) to the exit code the
/// CLI must report, per `docs/EXIT_CODES.md §4.1`: a stable public `ApiError.code` maps to its
/// documented exit number. The 14 [`ErrorCode`]s are the public vocabulary (CONFIG_INVALID -> 3,
/// PERMISSION -> 8, TIMEOUT -> 11, UNAVAILABLE -> 12, CURSOR_STALE -> 14, CANCELLED -> 15, ...),
/// so each is recognised and mapped.
///
/// The frame loop also emits transport/session codes that are NOT public `ApiError.code`s
/// (USAGE, UNSUPPORTED, NOT_FOUND, HANDSHAKE, HELLO_REQUIRED, PROTOCOL, TRANSPORT,
/// STREAM_CAPACITY): those describe the CLI and daemon disagreeing about the wire or the session
/// order, which is exactly `PROTO_MISMATCH` (13) — and so does any code the client does not
/// recognise (a newer daemon's code must not be guessed at).
pub fn from_wire_refusal_code(code: &str) -> ExitCode {
    [
        ErrorCode::ConfigInvalid,
        ErrorCode::Conflict,
        ErrorCode::UnsupportedCapability,
        ErrorCode::CoreNotRunning,
        ErrorCode::CoreFailed,
        ErrorCode::Permission,
        ErrorCode::NetOs,
        ErrorCode::Storage,
        ErrorCode::Timeout,
        ErrorCode::Unavailable,
        ErrorCode::ProtoMismatch,
        ErrorCode::CursorStale,
        ErrorCode::Cancelled,
        ErrorCode::Internal,
    ]
    .into_iter()
    .find(|error_code| error_code.as_str() == code)
    .map_or(ExitCode::ProtoMismatch, from_error_code)
}
