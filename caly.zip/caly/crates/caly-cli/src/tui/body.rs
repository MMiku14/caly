//! Tab body rendering: full lists, memoized in [`BodyCache`].
//!
//! Rebuilding a body walks the whole snapshot while a frame shows one
//! ~20-line window. The key covers every body input, so a hit equals a
//! fresh render; the cursor highlight is applied later by the frame.

use std::collections::hash_map::DefaultHasher;
use std::hash::{Hash, Hasher};

use super::{Snapshot, Tab, app::Tui};

/// Memoized full body list plus its key. `rows` is the
/// cursor-addressable row count (`None` for scroll-only bodies/help).
pub(super) struct BodyCache {
    key: BodyKey,
    lines: Vec<String>,
    rows: Option<usize>,
}

impl BodyCache {
    /// Row count the cached lines were rendered for (`None` for
    /// scroll-only bodies, help, and cache misses on other tabs).
    pub(super) fn rows_for(&self, tab: Tab) -> Option<usize> {
        if self.key.tab == tab { self.rows } else { None }
    }
}

/// Every input that can change the body (see the module docs).
#[derive(Eq, PartialEq)]
struct BodyKey {
    tab: Tab,
    content: u64,
    filter: String,
    overlay_gen: u64,
    width: usize,
    minute: u64,
}

/// Content hash over every snapshot field any body renders. Only
/// rendered fields are hashed (a field no body reads cannot change the
/// output, so it must not invalidate the cache either).
fn fingerprint(snapshot: &Snapshot) -> u64 {
    let mut hasher = DefaultHasher::new();
    hash_identity_state(snapshot, &mut hasher);
    hash_capabilities(snapshot, &mut hasher);
    hash_nodes(snapshot, &mut hasher);
    hash_groups(snapshot, &mut hasher);
    hash_sources(snapshot, &mut hasher);
    hasher.finish()
}

/// Daemon identity plus the four state structs the Status tab renders.
fn hash_identity_state(snapshot: &Snapshot, hasher: &mut DefaultHasher) {
    snapshot.revision.hash(hasher);
    snapshot.daemon_instance_id.hash(hasher);
    snapshot.cursor.sequence.hash(hasher);
    snapshot.desired.mode.hash(hasher);
    snapshot.desired.selected_node_id.hash(hasher);
    snapshot.desired.active_subscription_id.hash(hasher);
    snapshot.desired.tun_requested.hash(hasher);
    snapshot.desired.system_proxy_requested.hash(hasher);
    snapshot.applied.core_kind.hash(hasher);
    snapshot.applied.run_state.hash(hasher);
    snapshot.applied.selected_node_id.hash(hasher);
    snapshot.applied.config_generation.hash(hasher);
    snapshot.observed.upload_bytes_per_second.hash(hasher);
    snapshot.observed.download_bytes_per_second.hash(hasher);
    snapshot.observed.active_connections.hash(hasher);
    snapshot.observed.telemetry_dropped.hash(hasher);
    snapshot.observed.core_restart_count.hash(hasher);
    snapshot.observed.core_restart_backoff_ms.hash(hasher);
    snapshot.platform.proxy_engaged.hash(hasher);
    snapshot.platform.tun_engaged.hash(hasher);
    snapshot.platform.recovery_pending.hash(hasher);
    snapshot.platform.degraded_reason.hash(hasher);
}

fn hash_capabilities(snapshot: &Snapshot, hasher: &mut DefaultHasher) {
    for capability in &snapshot.capabilities {
        capability.capability.hash(hasher);
        capability.configured.hash(hasher);
        capability.runtime.hash(hasher);
        capability.caveat.hash(hasher);
    }
}

fn hash_nodes(snapshot: &Snapshot, hasher: &mut DefaultHasher) {
    for node in &snapshot.nodes {
        node.node_id.hash(hasher);
        node.name.hash(hasher);
        node.protocol.hash(hasher);
        node.latency_ms.hash(hasher);
    }
}

fn hash_groups(snapshot: &Snapshot, hasher: &mut DefaultHasher) {
    for group in &snapshot.proxy_groups {
        group.name.hash(hasher);
        group.kind.hash(hasher);
        group.selected.hash(hasher);
        group.members.hash(hasher);
    }
}

fn hash_sources(snapshot: &Snapshot, hasher: &mut DefaultHasher) {
    for source in &snapshot.sources {
        source.index.hash(hasher);
        source.name.as_str().hash(hasher);
        source.kind.as_str().hash(hasher);
        source.url.as_str().hash(hasher);
        source.enabled.hash(hasher);
        source.nodes.hash(hasher);
        for name in &source.groups {
            name.as_str().hash(hasher);
        }
        source.last_refresh_unix.hash(hasher);
        source.next_refresh_unix.hash(hasher);
        source.cached.hash(hasher);
    }
}

/// Memoized full body list plus the cursor-addressable row count.
pub(super) fn full_body(
    tui: &Tui,
    snapshot: &Snapshot,
    width: usize,
) -> (Vec<String>, Option<usize>) {
    let key = BodyKey {
        tab: tui.tab,
        content: fingerprint(snapshot),
        filter: tui.filter.clone(),
        overlay_gen: tui.overlay_gen,
        width,
        minute: caly_layout::now_unix() / 60,
    };
    if let Some(cached) = tui.body_cache.borrow().as_ref() {
        if cached.key == key {
            return (cached.lines.clone(), cached.rows);
        }
    }
    let (lines, rows) = render_full_body(tui, snapshot, width);
    *tui.body_cache.borrow_mut() = Some(BodyCache {
        key,
        lines: lines.clone(),
        rows,
    });
    (lines, rows)
}

fn render_full_body(tui: &Tui, snapshot: &Snapshot, width: usize) -> (Vec<String>, Option<usize>) {
    match tui.tab {
        Tab::Nodes => {
            let indices = super::nodes::filtered_indices(snapshot, &tui.filter);
            if indices.is_empty() {
                return (vec![center(&empty_pool_line(&tui.filter), width)], Some(0));
            }
            table_body(
                &super::nodes::HEADERS,
                super::nodes::render_rows(snapshot, &indices, &tui.sweep_overlay),
                width,
            )
        }
        Tab::Groups => {
            let rows = super::groups::flatten(snapshot);
            if rows.is_empty() {
                return (
                    vec![center(
                        "no proxy groups — plain node lists have nothing to pick.",
                        width,
                    )],
                    Some(0),
                );
            }
            table_body(
                &super::groups::HEADERS,
                super::groups::render_rows(&rows),
                width,
            )
        }
        Tab::Status => (super::status_view::lines(snapshot, width), None),
        Tab::Subs => {
            if snapshot.sources.is_empty() {
                return (
                    vec![center("no sources — add one (`caly sub add`).", width)],
                    Some(0),
                );
            }
            table_body(
                &super::subs::HEADERS,
                super::subs::render_rows(snapshot),
                width,
            )
        }
    }
}

/// Renders a table body: header line plus one line per data row, with
/// the row count for the cursor/highlight math.
fn table_body(
    headers: &[&str],
    rows: Vec<Vec<String>>,
    width: usize,
) -> (Vec<String>, Option<usize>) {
    let count = rows.len();
    (
        caly_layout::render_table(caly_layout::TableMode::Table, headers, &rows, Some(width)),
        Some(count),
    )
}

/// Centers a single-line empty state in the body width.
fn center(line: &str, width: usize) -> String {
    let pad = width.saturating_sub(caly_layout::visible_width(line)) / 2;
    format!("{}{line}", " ".repeat(pad))
}

/// Absolute body line of the cursor (+1 for the table header line).
pub(super) fn cursor_abs(tui: &Tui, rows: Option<usize>, full_len: usize) -> Option<usize> {
    let count = rows?;
    if count == 0 || full_len == 0 {
        return None;
    }
    // `rows` is `Some` only for cursor tabs, whose cursor slot matches
    // the active tab; the clamp is belt-and-braces against a cursor that
    // outran a shrink (refresh clamping normally prevents it).
    let pos = tui.cursor[tui.tab.index()] + 1;
    Some(pos.min(full_len - 1))
}

fn empty_pool_line(filter: &str) -> String {
    if filter.is_empty() {
        "no nodes — add a subscription (`caly sub add`) or refresh (`R`).".to_owned()
    } else {
        format!("no node matches `{filter}` — Esc clears the filter.")
    }
}

#[cfg(test)]
mod tests {
    use super::super::app::Tui;
    use super::super::fixtures::tests::fixture_snapshot;
    use super::super::frame::frame;
    use super::*;

    fn online_tui() -> Tui {
        let mut tui = Tui::new(None);
        tui.snapshot = Some(fixture_snapshot(3));
        tui
    }

    #[test]
    fn fingerprint_flips_on_any_rendered_field() {
        let base = fingerprint(&fixture_snapshot(2));
        let mut changed = fixture_snapshot(2);
        if let Some(node) = changed.nodes.iter_mut().next() {
            node.latency_ms = Some(999);
        }
        assert_ne!(fingerprint(&changed), base);
        let mut changed = fixture_snapshot(2);
        changed.applied.selected_node_id = Some([9u8; 16]);
        assert_ne!(fingerprint(&changed), base);
        let mut changed = fixture_snapshot(2);
        if let Some(group) = changed.proxy_groups.iter_mut().next() {
            group.selected = Some("node-1".to_owned());
        }
        assert_ne!(fingerprint(&changed), base);
    }

    #[test]
    fn memoized_body_never_goes_stale() {
        let mut tui = online_tui();
        let first = frame(&tui, 100, 24);
        assert!(tui.body_cache.borrow().is_some(), "first frame populates");
        let second = frame(&tui, 100, 24);
        assert_eq!(first, second, "identical input reuses the cache");
        if let Some(snapshot) = tui.snapshot.as_mut() {
            if let Some(node) = snapshot.nodes.iter_mut().nth(1) {
                node.latency_ms = Some(4242);
            }
        }
        let third = frame(&tui, 100, 24);
        assert!(
            third.iter().any(|line| line.contains("4242 ms")),
            "mutated latency invalidates the cache"
        );
    }
}
