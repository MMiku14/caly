//! Footer assembly: flash notices, state segments, key hints.
//!
//! The footer is one styled line: a receipt/error flash owns it for
//! four seconds, otherwise state segments (filter, sweep progress),
//! the tab's key hints with bold keys, a cursor position readout, and
//! the global hints — truncated to the terminal width.

use super::{Tab, app::Tui};

/// One styled key hint: the key reads bold, the description plain.
fn hint(key: &str, desc: &str) -> String {
    format!("{} {desc}", caly_layout::paint("1", key))
}

pub(super) fn footer_line(tui: &Tui, width: usize) -> String {
    if let Some(notice) = tui.notice_text() {
        return caly_layout::truncate_visible(&notice, width);
    }
    if tui.snapshot.is_none() {
        let line = format!("{} · {}", hint("r", "retry"), hint("q", "quit"));
        return caly_layout::truncate_visible(&line, width);
    }
    let mut parts = Vec::new();
    if tui.filtering {
        parts.push(format!("filter: {}_", tui.filter));
    } else if !tui.filter.is_empty() {
        parts.push(format!("filter: {}", tui.filter));
    }
    if let Some((done, total, dead)) = tui.sweep_progress {
        parts.push(format!("sweeping {done}/{total} ({dead} down)"));
    } else if tui.sweeping() {
        parts.push("sweeping…".to_owned());
    }
    parts.extend(tab_hints(tui.tab).iter().map(|(key, desc)| hint(key, desc)));
    if let Some(position) = position_segment(tui) {
        parts.push(position);
    }
    parts.extend(global_hints().iter().map(|(key, desc)| hint(key, desc)));
    caly_layout::truncate_visible(&parts.join(" · "), width)
}

fn tab_hints(tab: Tab) -> &'static [(&'static str, &'static str)] {
    match tab {
        Tab::Nodes => &[
            ("↑/↓", "move"),
            ("Enter", "select"),
            ("v", "view"),
            ("/", "filter"),
            ("t", "ping"),
        ],
        Tab::Groups => &[("↑/↓", "move"), ("Enter", "pick")],
        Tab::Status => &[("↑/↓", "scroll")],
        Tab::Subs => &[("↑/↓", "move"), ("Enter", "details"), ("R", "refresh all")],
    }
}

fn global_hints() -> &'static [(&'static str, &'static str)] {
    &[
        ("Tab", "tabs"),
        ("m", "mode"),
        ("C", "core"),
        ("S", "settings"),
        ("?", "help"),
        ("q", "quit"),
    ]
}

/// Cursor position readout for cursor tabs (`12/300`): the grouped
/// count reads in members, not flat rows, so headers never skew it.
/// `None` for the scroll-only Status tab and empty lists.
fn position_segment(tui: &Tui) -> Option<String> {
    let snapshot = tui.snapshot.as_ref()?;
    match tui.tab {
        Tab::Nodes | Tab::Subs => {
            let total = tui
                .body_cache
                .borrow()
                .as_ref()
                .and_then(|cached| cached.rows_for(tui.tab))?;
            if total == 0 {
                return None;
            }
            Some(format!("{}/{}", tui.cursor[tui.tab.index()] + 1, total))
        }
        Tab::Groups => {
            let rows = super::groups::flatten(snapshot);
            let (ordinal, total) =
                super::groups::member_position(&rows, tui.cursor[Tab::Groups.index()])?;
            Some(format!("{ordinal}/{total}"))
        }
        Tab::Status => None,
    }
}

#[cfg(test)]
mod tests {
    use super::super::app::Tui;
    use super::super::fixtures::tests::fixture_snapshot;
    use super::super::frame::frame;
    use super::*;

    fn online_tui() -> Tui {
        let mut tui = Tui::new(None);
        tui.snapshot = Some(fixture_snapshot(3));
        tui
    }

    #[test]
    fn footer_fits_narrow_terminals() {
        let tui = online_tui();
        let frame = frame(&tui, 40, 24);
        assert!(
            caly_layout::visible_width(&frame[23]) <= 40,
            "{}",
            frame[23]
        );
    }

    #[test]
    fn footer_styles_keys_bold_and_shows_position() {
        let mut tui = online_tui();
        tui.cursor[Tab::Nodes.index()] = 1;
        let frame = frame(&tui, 100, 24);
        assert!(
            frame[23].contains("\x1b[1mEnter\x1b[0m select"),
            "{}",
            frame[23]
        );
        assert!(frame[23].contains("2/3"), "{}", frame[23]);
    }

    #[test]
    fn sweeping_footer_shows_live_progress() {
        let mut tui = online_tui();
        tui.sweep_progress = Some((7, 20, 2));
        let frame = frame(&tui, 100, 24);
        assert!(
            frame[23].contains("sweeping 7/20 (2 down)"),
            "{}",
            frame[23]
        );
    }
}
