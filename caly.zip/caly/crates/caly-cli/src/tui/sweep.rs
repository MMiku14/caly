//! Background ping-all sweep: worker thread, progress messages, overlay.
//!
//! Probing every node takes seconds to minutes, so the sweep runs on a
//! worker thread and talks to the UI through [`SweepMsg`]: one
//! `Progress` per completed probe, one terminal `Done`. The loop
//! [`poll_sweep`](Tui::poll_sweep)s without blocking, so the UI stays
//! live throughout. The progress callback doubles as the sweep's TTY
//! progress-line suppressor (see `sweep_latencies_with_progress`) —
//! without it the worker would scribble `\rprobed…` over the frame.

use std::sync::mpsc;

use super::app::Tui;

type SweepSample = caly_ops::client::actions::SweepLatency;

/// Sweep worker -> UI messages. Progress arrives per completed probe;
/// `Done` arrives exactly once, last.
pub(super) enum SweepMsg {
    Progress {
        done: usize,
        total: usize,
        dead: usize,
    },
    Done(Result<Vec<SweepSample>, String>),
}

impl Tui {
    pub(super) fn sweeping(&self) -> bool {
        self.sweep_rx.is_some()
    }

    /// Drains every queued sweep message without blocking: progress
    /// updates the footer, `Done` folds the overlay (or flashes its
    /// error). The worker thread owns all probe latency.
    pub(super) fn poll_sweep(&mut self) {
        loop {
            let next = self.sweep_rx.as_ref().map(mpsc::Receiver::try_recv);
            match next {
                None | Some(Err(mpsc::TryRecvError::Empty)) => return,
                Some(Err(mpsc::TryRecvError::Disconnected)) => {
                    self.sweep_rx = None;
                    self.sweep_progress = None;
                    self.flash("sweep worker died before reporting");
                    return;
                }
                Some(Ok(msg)) => self.handle_sweep_msg(msg),
            }
        }
    }

    pub(super) fn handle_sweep_msg(&mut self, msg: SweepMsg) {
        match msg {
            SweepMsg::Progress { done, total, dead } => {
                self.sweep_progress = Some((done, total, dead));
            }
            SweepMsg::Done(result) => {
                self.sweep_rx = None;
                self.sweep_progress = None;
                match result {
                    Err(reason) => self.flash(&reason),
                    Ok(samples) => {
                        let reachable = samples.iter().filter(|s| s.median_ms.is_some()).count();
                        self.sweep_overlay = samples
                            .into_iter()
                            .map(|sample| (sample.node_hex, sample.median_ms))
                            .collect();
                        self.overlay_gen += 1;
                        self.flash(&format!(
                            "sweep: {reachable} of {} nodes reachable",
                            self.sweep_overlay.len()
                        ));
                    }
                }
            }
        }
    }

    /// Starts a background ping-all sweep; a no-op (with a flash) while
    /// one is already running. The progress callback doubles as the
    /// sweep's TTY-spam suppressor (see `sweep_latencies_with_progress`).
    pub(super) fn start_sweep(&mut self) {
        if self.sweep_rx.is_some() {
            self.flash("a sweep is already running");
            return;
        }
        let socket = self.socket.clone();
        let (tx, rx) = mpsc::channel();
        std::thread::spawn(move || {
            let outcome = caly_ops::client::actions::sweep_latencies_with_progress(
                socket.as_ref(),
                Some(&|done, total, dead| {
                    let _ = tx.send(SweepMsg::Progress { done, total, dead });
                }),
            );
            let _ = tx.send(SweepMsg::Done(outcome));
        });
        self.sweep_rx = Some(rx);
        self.sweep_progress = None;
        self.flash("sweeping every node…");
    }
}

#[cfg(test)]
mod tests {
    use super::super::app::Tui;
    use super::*;

    #[test]
    fn sweep_progress_updates_the_footer_state() {
        let mut tui = Tui::new(None);
        tui.handle_sweep_msg(SweepMsg::Progress {
            done: 3,
            total: 10,
            dead: 1,
        });
        assert_eq!(tui.sweep_progress, Some((3, 10, 1)));
    }

    #[test]
    fn sweep_done_folds_the_overlay_and_bumps_the_generation() {
        let mut tui = Tui::new(None);
        tui.sweep_progress = Some((10, 10, 0));
        tui.handle_sweep_msg(SweepMsg::Done(Ok(vec![
            SweepSample {
                node_hex: "aa".to_owned(),
                median_ms: Some(12),
            },
            SweepSample {
                node_hex: "bb".to_owned(),
                median_ms: None,
            },
        ])));
        assert!(tui.sweep_progress.is_none());
        assert!(!tui.sweeping());
        assert_eq!(tui.overlay_gen, 1);
        assert_eq!(tui.sweep_overlay.get("aa"), Some(&Some(12)));
        assert_eq!(tui.sweep_overlay.get("bb"), Some(&None));
        let notice = tui.notice_text().expect("fold flashes a receipt");
        assert!(notice.contains("1 of 2"), "{notice}");
    }

    #[test]
    fn sweep_failure_clears_state_and_flashes() {
        let mut tui = Tui::new(None);
        tui.handle_sweep_msg(SweepMsg::Done(Err("boom".to_owned())));
        assert!(tui.sweep_progress.is_none());
        assert!(tui.sweep_overlay.is_empty());
        assert_eq!(tui.overlay_gen, 0);
        assert_eq!(tui.notice_text().as_deref(), Some("boom"));
    }
}
