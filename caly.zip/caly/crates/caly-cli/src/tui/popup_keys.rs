//! Modal popup key dispatch for the TUI.
//!
//! An open popup owns the keyboard: `Esc`/`q` close it, scroll keys
//! drive its own offset (or the core radio), `Enter`/`R` fire its
//! action, and everything else is swallowed. Only Ctrl-C escapes the
//! modal loop (handled before dispatch, in [`super::keys`]).

use crossterm::event::KeyCode;

use super::app::Tui;
use super::popup::{CORES, Popup, SettingsRow};

impl Tui {
    /// Modal popup dispatch. `Esc`/`q` close (never quit); scroll keys
    /// drive the popup's own offset (or the core radio); `Enter`/`R`
    /// fire the popup's action; everything else is swallowed.
    pub(super) fn handle_popup_key(&mut self, code: KeyCode) -> bool {
        match code {
            KeyCode::Esc | KeyCode::Char('q') => self.popup = None,
            KeyCode::Char('?') => {
                if matches!(self.popup, Some(Popup::Help { .. })) {
                    self.popup = None;
                }
            }
            KeyCode::Up | KeyCode::Char('k') => self.popup_scroll(-1),
            KeyCode::Down | KeyCode::Char('j') => self.popup_scroll(1),
            KeyCode::Home | KeyCode::Char('g') => self.popup_scroll_first(),
            KeyCode::End | KeyCode::Char('G') => self.popup_scroll_last(),
            KeyCode::Enter => self.popup_activate(),
            KeyCode::Char(' ') => {
                if matches!(self.popup, Some(Popup::Settings { .. })) {
                    self.popup_activate();
                }
            }
            KeyCode::Char('R') => self.popup_refresh_source(),
            _ => {}
        }
        false
    }

    /// Scrolls a detail popup blindly (the box builder clamps to the
    /// real content); moves the core radio with wraparound, disarming a
    /// pending confirm (a moved cursor must never confirm a stale row);
    /// moves the settings cursor with wraparound.
    fn popup_scroll(&mut self, delta: i32) {
        match self.popup.as_mut() {
            Some(Popup::Help { scroll })
            | Some(Popup::Node { scroll, .. })
            | Some(Popup::Source { scroll, .. }) => {
                if delta < 0 {
                    *scroll = scroll.saturating_sub(1);
                } else {
                    *scroll = scroll.saturating_add(1);
                }
            }
            Some(Popup::Cores { selected, armed }) => {
                *armed = false;
                let len = CORES.len();
                *selected = if delta < 0 {
                    (*selected + len - 1) % len
                } else {
                    (*selected + 1) % len
                };
            }
            Some(Popup::Settings { selected }) => {
                let len = SettingsRow::COUNT;
                *selected = if delta < 0 {
                    (*selected + len - 1) % len
                } else {
                    (*selected + 1) % len
                };
            }
            None => {}
        }
    }

    fn popup_scroll_first(&mut self) {
        match self.popup.as_mut() {
            Some(Popup::Help { scroll })
            | Some(Popup::Node { scroll, .. })
            | Some(Popup::Source { scroll, .. }) => *scroll = 0,
            Some(Popup::Cores { selected, armed }) => {
                *armed = false;
                *selected = 0;
            }
            Some(Popup::Settings { selected }) => *selected = 0,
            None => {}
        }
    }

    fn popup_scroll_last(&mut self) {
        match self.popup.as_mut() {
            // Saturates: the box builder clamps to the real content.
            Some(Popup::Help { scroll })
            | Some(Popup::Node { scroll, .. })
            | Some(Popup::Source { scroll, .. }) => *scroll = usize::MAX,
            Some(Popup::Cores { selected, armed }) => {
                *armed = false;
                *selected = CORES.len() - 1;
            }
            Some(Popup::Settings { selected }) => *selected = SettingsRow::COUNT - 1,
            None => {}
        }
    }

    /// `Enter` inside a popup: help closes, node selects + closes,
    /// source closes, core arms/confirms the switch, settings applies
    /// its row.
    fn popup_activate(&mut self) {
        match self.popup.as_ref() {
            Some(Popup::Help { .. }) | Some(Popup::Source { .. }) => self.popup = None,
            Some(Popup::Settings { .. }) => self.activate_settings_row(),
            Some(Popup::Node { node_id, .. }) => {
                let pick = self.snapshot.as_ref().and_then(|snapshot| {
                    snapshot
                        .nodes
                        .iter()
                        .find(|node| node.node_id == *node_id)
                        .map(|node| {
                            (
                                node.node_id,
                                caly_ops::client::output::decode_display_name(&node.name),
                            )
                        })
                });
                self.popup = None;
                match pick {
                    Some((node_id, label)) => self.action_select(node_id, &label),
                    None => self.flash("that node left the snapshot"),
                }
            }
            Some(Popup::Cores { selected, armed }) => {
                let selected = *selected % CORES.len();
                let armed = *armed;
                let target = CORES[selected];
                let is_current = self.current_core() == Some(target);
                if is_current {
                    self.popup = None;
                    self.flash(&format!("already on `{target}`"));
                } else if !armed {
                    if let Some(Popup::Cores { armed, .. }) = self.popup.as_mut() {
                        *armed = true;
                    }
                } else {
                    self.action_switch_core(target);
                }
            }
            None => {}
        }
    }

    /// `R` inside a source popup refreshes that one source.
    fn popup_refresh_source(&mut self) {
        let target = match self.popup.as_ref() {
            Some(Popup::Source { index, .. }) => self.snapshot.as_ref().and_then(|snapshot| {
                snapshot
                    .sources
                    .iter()
                    .find(|source| source.index == *index)
                    .map(|source| {
                        (
                            source.name.as_str().to_owned(),
                            source.url.as_str().to_owned(),
                        )
                    })
            }),
            _ => None,
        };
        if let Some((name, url)) = target {
            self.action_refresh_source(&name, &url);
        }
    }

    /// The daemon's live core label, if it reports a known one.
    pub(super) fn current_core(&self) -> Option<&'static str> {
        use caly_protocol::protocol::v2::WireCoreKind;
        self.snapshot.as_ref().and_then(|snapshot| {
            snapshot
                .applied
                .core_kind
                .and_then(WireCoreKind::from_wire)
                .map(WireCoreKind::label)
        })
    }
}

#[cfg(test)]
mod tests {
    use super::super::Tab;
    use super::super::fixtures::tests::{fixture_snapshot, press};
    use super::*;
    use crossterm::event::KeyCode;

    fn online_tui() -> Tui {
        let mut tui = Tui::new(None);
        tui.snapshot = Some(fixture_snapshot(3));
        tui
    }

    fn settings_tui(selected: usize) -> Tui {
        let mut tui = online_tui();
        tui.popup = Some(Popup::Settings { selected });
        tui
    }

    #[test]
    fn settings_cursor_wraps_both_ways() {
        let mut tui = settings_tui(0);
        press(&mut tui, KeyCode::Char('k'));
        assert!(matches!(tui.popup, Some(Popup::Settings { selected: 4 })));
        press(&mut tui, KeyCode::Char('j'));
        assert!(matches!(tui.popup, Some(Popup::Settings { selected: 0 })));
    }

    #[test]
    fn settings_toggle_stays_open_and_flashes_without_a_daemon() {
        let mut tui = settings_tui(1);
        press(&mut tui, KeyCode::Enter);
        assert!(matches!(tui.popup, Some(Popup::Settings { selected: 1 })));
        assert!(tui.notice_text().is_some());
    }

    #[test]
    fn settings_space_activates_like_enter() {
        let mut tui = settings_tui(2);
        press(&mut tui, KeyCode::Char(' '));
        assert!(matches!(tui.popup, Some(Popup::Settings { selected: 2 })));
        assert!(tui.notice_text().is_some());
    }

    #[test]
    fn settings_core_row_swaps_in_the_switcher() {
        let mut tui = settings_tui(3);
        press(&mut tui, KeyCode::Enter);
        assert!(matches!(tui.popup, Some(Popup::Cores { .. })));
    }

    #[test]
    fn escape_closes_the_popup_first() {
        let mut tui = online_tui();
        tui.popup = Some(Popup::Help { scroll: 0 });
        assert!(!press(&mut tui, KeyCode::Esc));
        assert!(tui.popup.is_none());
    }

    #[test]
    fn popup_swallows_tab_switches_and_q_closes_without_quitting() {
        let mut tui = online_tui();
        tui.popup = Some(Popup::Help { scroll: 0 });
        assert!(!press(&mut tui, KeyCode::Tab));
        assert_eq!(tui.tab, Tab::Nodes);
        assert!(!press(&mut tui, KeyCode::Char('q')));
        assert!(tui.popup.is_none());
    }

    #[test]
    fn core_radio_preselects_current_and_arms_before_firing() {
        let mut tui = online_tui();
        if let Some(snapshot) = tui.snapshot.as_mut() {
            snapshot.applied.core_kind = Some(1);
        }
        press(&mut tui, KeyCode::Char('C'));
        assert_eq!(
            tui.popup,
            Some(Popup::Cores {
                selected: 0,
                armed: false
            })
        );
        // Move to sing-box, then Enter arms (no daemon touched offline).
        press(&mut tui, KeyCode::Char('j'));
        press(&mut tui, KeyCode::Enter);
        assert_eq!(
            tui.popup,
            Some(Popup::Cores {
                selected: 1,
                armed: true
            })
        );
        // Moving disarms.
        press(&mut tui, KeyCode::Char('k'));
        assert_eq!(
            tui.popup,
            Some(Popup::Cores {
                selected: 0,
                armed: false
            })
        );
    }

    #[test]
    fn ctrl_c_quits_from_inside_a_popup() {
        let mut tui = online_tui();
        tui.popup = Some(Popup::Help { scroll: 0 });
        assert!(tui.handle_key(KeyCode::Char('c'), crossterm::event::KeyModifiers::CONTROL));
    }
}
