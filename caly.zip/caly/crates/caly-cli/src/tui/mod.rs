//! `caly tui`: fullscreen node/group/status/source browser with actions.
//!
//! Hand-rolled on crossterm — the same crates as the live picker, no
//! ratatui until the widget set earns it. Every data projection is reused
//! from `caly-ops` and `caly-layout` (snapshot blocks, table engine,
//! badges, relative times); every mutation goes through the quiet
//! [`actions`](caly_ops::client::actions) API, which returns receipts as
//! values instead of printing them. This module owns only the screen loop,
//! so the CLI and the TUI can never disagree about what the daemon
//! reported or did.
//!
//! Scope (four tabs + modal secondary windows):
//! - Nodes: navigate, `/` filter, `Enter` select, `v` details, `t`
//!   ping-all sweep.
//! - Groups: navigate, `Enter` picks the member under the cursor.
//! - Status: the `caly status` facts, read-only, scrollable.
//! - Subs: navigate, `Enter` opens source details, `R` refreshes every
//!   source (or just this one inside its details).
//! - Global: `Tab`/`1-4` switch tabs, `m` cycles rule→global→direct,
//!   `C` switches core (radio + two-step confirm), `r` refreshes, `?`
//!   opens help, `q`/`Esc` quits (`Esc` first closes windows, then
//!   clears the filter).
//!
//! Still out of scope: rule management and any destructive operation —
//! nothing here can delete anything (core switches restart the data
//! plane, which is why they confirm twice).

mod actions;
mod app;
mod body;
mod cursor;
mod footer;
mod frame;
mod groups;
mod keys;
mod nodes;
mod popup;
mod popup_keys;
mod popup_views;
mod status_view;
mod subs;
mod sweep;

#[cfg(test)]
mod fixtures;

use std::path::PathBuf;
use std::process::ExitCode;

type Snapshot = caly_protocol::protocol::v2::WirePresentationSnapshot;

/// The four v1 tabs. The discriminant order is the tab-bar order and the
/// index into the per-tab cursor/scroll arrays.
#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub(crate) enum Tab {
    Nodes,
    Groups,
    Status,
    Subs,
}

impl Tab {
    const ALL: [Tab; 4] = [Tab::Nodes, Tab::Groups, Tab::Status, Tab::Subs];

    fn index(self) -> usize {
        match self {
            Tab::Nodes => 0,
            Tab::Groups => 1,
            Tab::Status => 2,
            Tab::Subs => 3,
        }
    }

    fn from_index(index: usize) -> Tab {
        Tab::ALL[index % Tab::ALL.len()]
    }

    fn title(self) -> &'static str {
        match self {
            Tab::Nodes => "Nodes",
            Tab::Groups => "Groups",
            Tab::Status => "Status",
            Tab::Subs => "Subs",
        }
    }
}

/// Runs the fullscreen UI until the operator quits.
pub fn run_tui(socket: Option<&PathBuf>) -> ExitCode {
    if !caly_ops::client::picker::interactive_capable() {
        caly_layout::error("tui needs an interactive terminal (stdin/stdout/stderr on a TTY)");
        return ExitCode::from(2);
    }
    let socket = socket.cloned();
    let mut tui = app::Tui::new(socket);
    match tui.run() {
        Ok(()) => ExitCode::SUCCESS,
        Err(reason) => {
            caly_layout::error(&format!("tui failed: {reason}"));
            ExitCode::FAILURE
        }
    }
}
