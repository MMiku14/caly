//! Cursor and scroll movement for the TUI tabs.
//!
//! Cursor tabs (Nodes, Groups, Subs) move a selection the frame
//! highlights; the scroll-only Status tab moves its viewport instead.
//! Groups movement skips header rows so the cursor always rests on a
//! pickable member.

use super::Tab;
use super::app::Tui;

impl Tui {
    pub(super) fn move_up(&mut self) {
        match self.tab {
            Tab::Nodes | Tab::Subs => {
                let slot = &mut self.cursor[self.tab.index()];
                *slot = slot.saturating_sub(1);
            }
            Tab::Groups => self.move_group_cursor(-1),
            Tab::Status => {
                let slot = &mut self.scroll[self.tab.index()];
                *slot = slot.saturating_sub(1);
            }
        }
    }

    pub(super) fn move_down(&mut self) {
        match self.tab {
            Tab::Nodes => {
                let max = self.node_rows().saturating_sub(1);
                let slot = &mut self.cursor[Tab::Nodes.index()];
                *slot = (*slot + 1).min(max);
            }
            Tab::Subs => {
                let max = self.subs_rows().saturating_sub(1);
                let slot = &mut self.cursor[Tab::Subs.index()];
                *slot = (*slot + 1).min(max);
            }
            Tab::Groups => self.move_group_cursor(1),
            Tab::Status => {
                // The frame clamps the scroll to the real line count, so
                // `G`/endless `j` needs no width-dependent total here.
                let slot = &mut self.scroll[self.tab.index()];
                *slot = slot.saturating_add(1);
            }
        }
    }

    fn move_group_cursor(&mut self, delta: i32) {
        let Some(snapshot) = self.snapshot.as_ref() else {
            return;
        };
        let rows = super::groups::flatten(snapshot);
        let pos = self.cursor[Tab::Groups.index()];
        let next = if delta < 0 {
            super::groups::prev_member(&rows, pos.saturating_sub(1))
        } else {
            super::groups::next_member(&rows, pos + 1)
        };
        if let Some(landed) = next {
            self.cursor[Tab::Groups.index()] = landed;
        }
    }

    pub(super) fn move_first(&mut self) {
        match self.tab {
            Tab::Nodes | Tab::Subs => self.cursor[self.tab.index()] = 0,
            Tab::Groups => {
                if let Some(snapshot) = self.snapshot.as_ref() {
                    let rows = super::groups::flatten(snapshot);
                    self.cursor[Tab::Groups.index()] =
                        super::groups::next_member(&rows, 0).unwrap_or(0);
                }
            }
            Tab::Status => self.scroll[self.tab.index()] = 0,
        }
    }

    pub(super) fn move_last(&mut self) {
        match self.tab {
            Tab::Nodes => {
                self.cursor[Tab::Nodes.index()] = self.node_rows().saturating_sub(1);
            }
            Tab::Subs => {
                self.cursor[Tab::Subs.index()] = self.subs_rows().saturating_sub(1);
            }
            Tab::Groups => {
                if let Some(snapshot) = self.snapshot.as_ref() {
                    let rows = super::groups::flatten(snapshot);
                    self.cursor[Tab::Groups.index()] =
                        super::groups::prev_member(&rows, rows.len().saturating_sub(1))
                            .unwrap_or(0);
                }
            }
            // Saturates: the frame clamps to the real line count.
            Tab::Status => self.scroll[self.tab.index()] = usize::MAX,
        }
    }

    fn node_rows(&self) -> usize {
        self.snapshot.as_ref().map_or(0, |snapshot| {
            super::nodes::filtered_indices(snapshot, &self.filter).len()
        })
    }

    fn subs_rows(&self) -> usize {
        self.snapshot
            .as_ref()
            .map_or(0, |snapshot| snapshot.sources.len())
    }
}

#[cfg(test)]
mod tests {
    use super::super::fixtures::tests::{fixture_snapshot, press};
    use super::*;
    use crossterm::event::KeyCode;

    fn online_tui() -> Tui {
        let mut tui = Tui::new(None);
        tui.snapshot = Some(fixture_snapshot(3));
        tui
    }

    #[test]
    fn node_cursor_clamps_to_the_filtered_pool() {
        let mut tui = online_tui();
        tui.cursor[Tab::Nodes.index()] = 9;
        press(&mut tui, KeyCode::Char('j'));
        assert_eq!(tui.cursor[Tab::Nodes.index()], 2);
        for _ in 0..5 {
            press(&mut tui, KeyCode::Char('k'));
        }
        assert_eq!(tui.cursor[Tab::Nodes.index()], 0);
    }

    #[test]
    fn group_cursor_lands_on_members_only() {
        let mut tui = online_tui();
        // Flat rows: [header, node-0, node-1]; cursor starts at 0.
        press(&mut tui, KeyCode::Tab);
        press(&mut tui, KeyCode::Char('j'));
        assert_eq!(tui.cursor[Tab::Groups.index()], 1);
        press(&mut tui, KeyCode::Char('k'));
        // No member above row 1: the cursor stays put.
        assert_eq!(tui.cursor[Tab::Groups.index()], 1);
    }

    #[test]
    fn subs_cursor_clamps_to_the_source_list() {
        let mut tui = online_tui();
        tui.tab = Tab::Subs;
        // The fixture declares exactly one source.
        press(&mut tui, KeyCode::Char('j'));
        assert_eq!(tui.cursor[Tab::Subs.index()], 0);
    }
}
