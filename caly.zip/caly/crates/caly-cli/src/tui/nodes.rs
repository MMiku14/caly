//! The Nodes tab: filter + row projection for the snapshot node pool.
//!
//! The name match is a case-insensitive substring over the decoded
//! display name (the same text the row shows), so the filter can never
//! hide a row whose visible name matches. Latency cells reuse the
//! suite [`latency`](caly_layout::latency) paint: amber past 300 ms,
//! red past 1 s — the same thresholds as the delay sweep.

use std::collections::HashMap;

use super::Snapshot;

pub(super) const HEADERS: [&str; 4] = ["", "NODE", "PROTO", "LATENCY"];

/// Snapshot indices of the nodes matching `filter` (in pool order).
/// An empty filter matches everything.
pub(super) fn filtered_indices(snapshot: &Snapshot, filter: &str) -> Vec<usize> {
    if filter.is_empty() {
        return (0..snapshot.nodes.len()).collect();
    }
    let needle = filter.to_lowercase();
    snapshot
        .nodes
        .iter()
        .enumerate()
        .filter(|(_, node)| {
            caly_ops::client::output::decode_display_name(&node.name)
                .to_lowercase()
                .contains(&needle)
        })
        .map(|(index, _)| index)
        .collect()
}

/// Table rows for the filtered indices. `overlay` carries fresh sweep
/// medians by lowercase hex id and wins over the snapshot latency; a
/// swept-but-unreachable node renders `down` instead of a stale number.
pub(super) fn render_rows(
    snapshot: &Snapshot,
    indices: &[usize],
    overlay: &HashMap<String, Option<u32>>,
) -> Vec<Vec<String>> {
    let selected = snapshot.applied.selected_node_id;
    indices
        .iter()
        .map(|&index| {
            let node = &snapshot.nodes[index];
            let marker = if selected.is_some_and(|id| id == node.node_id) {
                "*"
            } else {
                ""
            };
            vec![
                marker.to_owned(),
                caly_ops::client::output::decode_display_name(&node.name),
                node.protocol.clone(),
                latency_cell(node, overlay),
            ]
        })
        .collect()
}

fn latency_cell(
    node: &caly_protocol::protocol::v2::WireDisplayNode,
    overlay: &HashMap<String, Option<u32>>,
) -> String {
    let hex = caly_domain::to_hex(node.node_id);
    if let Some(swept) = overlay.get(&hex) {
        return match swept {
            Some(median) => {
                let text = format!("{median} ms");
                caly_layout::latency(Some(*median), &text)
            }
            None => "down".to_owned(),
        };
    }
    node.latency_ms.map_or_else(
        || "—".to_owned(),
        |latency| {
            let text = format!("{latency} ms");
            caly_layout::latency(Some(latency), &text)
        },
    )
}

#[cfg(test)]
mod tests {
    use super::super::fixtures::tests::fixture_snapshot;
    use super::*;

    #[test]
    fn empty_filter_matches_the_whole_pool() {
        let snapshot = fixture_snapshot(3);
        assert_eq!(filtered_indices(&snapshot, ""), vec![0, 1, 2]);
    }

    #[test]
    fn filter_matches_case_insensitively() {
        let snapshot = fixture_snapshot(3);
        assert_eq!(filtered_indices(&snapshot, "NODE-1"), vec![1]);
        assert_eq!(filtered_indices(&snapshot, "node-"), vec![0, 1, 2]);
        assert!(filtered_indices(&snapshot, "hk").is_empty());
    }

    #[test]
    fn selected_node_gets_the_star() {
        let mut snapshot = fixture_snapshot(2);
        snapshot.applied.selected_node_id = Some([1u8; 16]);
        let rows = render_rows(&snapshot, &[0, 1], &HashMap::new());
        assert_eq!(rows[0][0], "");
        assert_eq!(rows[1][0], "*");
        assert_eq!(rows[1][1], "node-1");
    }

    #[test]
    fn sweep_overlay_wins_and_down_replaces_stale_numbers() {
        let snapshot = fixture_snapshot(2);
        let mut overlay = HashMap::new();
        overlay.insert(caly_domain::to_hex([0u8; 16]), Some(42));
        overlay.insert(caly_domain::to_hex([1u8; 16]), None);
        let rows = render_rows(&snapshot, &[0, 1], &overlay);
        assert!(rows[0][3].contains("42 ms"), "{}", rows[0][3]);
        assert_eq!(rows[1][3], "down");
    }
}
