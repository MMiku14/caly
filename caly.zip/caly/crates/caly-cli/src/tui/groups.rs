//! The Groups tab: proxy groups flattened to header + member rows.
//!
//! Headers are landmarks, not targets: the cursor skips them
//! ([`next_member`]/[`prev_member`]) and `Enter` on a header is a
//! no-op hint, so a pick can never address a group instead of a member.
//! The only load-bearing kinds are the kernel's four (`Selector`,
//! `URLTest`, `Fallback`, `LoadBalance`); unknown kinds render as-is.

use super::Snapshot;

pub(super) const HEADERS: [&str; 3] = ["", "GROUP", "DETAIL"];

/// One flattened row: a group header or a pickable member.
#[derive(Clone, Debug, Eq, PartialEq)]
pub(super) enum GroupRow {
    Header {
        name: String,
        kind: String,
        members: usize,
    },
    Member {
        group: String,
        name: String,
        is_selected: bool,
    },
}

impl GroupRow {
    fn is_member(&self) -> bool {
        matches!(self, GroupRow::Member { .. })
    }
}

/// Flattens the snapshot groups to header + member rows in order.
pub(super) fn flatten(snapshot: &Snapshot) -> Vec<GroupRow> {
    let mut rows = Vec::new();
    for group in &snapshot.proxy_groups {
        rows.push(GroupRow::Header {
            name: group.name.clone(),
            kind: group.kind.clone(),
            members: group.members.len(),
        });
        for member in &group.members {
            rows.push(GroupRow::Member {
                group: group.name.clone(),
                name: member.clone(),
                is_selected: group.selected.as_deref() == Some(member.as_str()),
            });
        }
    }
    rows
}

/// Table rows: headers bare, members indented two spaces with `*` on the
/// group's live selection.
pub(super) fn render_rows(rows: &[GroupRow]) -> Vec<Vec<String>> {
    rows.iter()
        .map(|row| match row {
            GroupRow::Header {
                name,
                kind,
                members,
            } => vec![
                String::new(),
                name.clone(),
                format!("{kind} · {members} members"),
            ],
            GroupRow::Member {
                name, is_selected, ..
            } => vec![
                if *is_selected { "*" } else { "" }.to_owned(),
                format!("  {name}"),
                if *is_selected {
                    "selected".to_owned()
                } else {
                    String::new()
                },
            ],
        })
        .collect()
}

/// Nearest member at or after `pos` (cursor landing when moving down or
/// after a refresh re-flattens the list).
pub(super) fn next_member(rows: &[GroupRow], pos: usize) -> Option<usize> {
    (pos..rows.len()).find(|&index| rows[index].is_member())
}

/// Member ordinal under `pos` (1-based) and total members, for the
/// footer's position readout. Headers don't count; the cursor rests on
/// members only, so a header landing reads as its section's first
/// member (belt-and-braces — movement and clamping never land there).
pub(super) fn member_position(rows: &[GroupRow], pos: usize) -> Option<(usize, usize)> {
    let total = rows.iter().filter(|row| row.is_member()).count();
    if total == 0 {
        return None;
    }
    let ordinal = rows
        .iter()
        .take(pos + 1)
        .filter(|row| row.is_member())
        .count();
    Some((ordinal.max(1), total))
}

/// Nearest member at or before `pos` (cursor landing when moving up).
pub(super) fn prev_member(rows: &[GroupRow], pos: usize) -> Option<usize> {
    if rows.is_empty() {
        return None;
    }
    (0..=pos.min(rows.len() - 1))
        .rev()
        .find(|&index| rows[index].is_member())
}

#[cfg(test)]
mod tests {
    use super::super::fixtures::tests::fixture_snapshot;
    use super::*;

    #[test]
    fn flatten_marks_the_live_selection() {
        let rows = flatten(&fixture_snapshot(2));
        assert_eq!(rows.len(), 3);
        assert!(matches!(rows[0], GroupRow::Header { ref name, .. } if name == "select"));
        assert_eq!(
            rows[1],
            GroupRow::Member {
                group: "select".to_owned(),
                name: "node-0".to_owned(),
                is_selected: true,
            }
        );
        assert!(matches!(
            rows[2],
            GroupRow::Member {
                is_selected: false,
                ..
            }
        ));
    }

    #[test]
    fn cursor_movement_skips_headers() {
        let rows = flatten(&fixture_snapshot(2));
        assert_eq!(next_member(&rows, 0), Some(1));
        assert_eq!(next_member(&rows, 1), Some(1));
        assert_eq!(next_member(&rows, 2), Some(2));
        assert_eq!(next_member(&rows, 3), None);
        assert_eq!(prev_member(&rows, 2), Some(2));
        assert_eq!(prev_member(&rows, 1), Some(1));
        assert_eq!(prev_member(&rows, 0), None);
    }

    #[test]
    fn empty_groups_have_no_member_to_land_on() {
        let rows: Vec<GroupRow> = Vec::new();
        assert_eq!(next_member(&rows, 0), None);
        assert_eq!(prev_member(&rows, 0), None);
        assert!(render_rows(&rows).is_empty());
    }

    #[test]
    fn member_position_ignores_headers() {
        let rows = flatten(&fixture_snapshot(2));
        assert_eq!(member_position(&rows, 0), Some((1, 2)));
        assert_eq!(member_position(&rows, 1), Some((1, 2)));
        assert_eq!(member_position(&rows, 2), Some((2, 2)));
        assert_eq!(member_position(&[], 0), None);
    }

    #[test]
    fn selection_renders_starred_and_indented() {
        let rendered = render_rows(&flatten(&fixture_snapshot(2)));
        assert_eq!(rendered[0][2], "Selector · 2 members");
        assert_eq!(rendered[1][0], "*");
        assert_eq!(rendered[1][1], "  node-0");
        assert_eq!(rendered[2][0], "");
    }
}
