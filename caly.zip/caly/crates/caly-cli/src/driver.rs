use caly_api::{default_ctx, ApplyRequest, CalyFacade, JobFollowRequest};
use caly_app::{build_loopback_remote_client, LocalAppClient, RemoteFacade};
use caly_common::Actor;

#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub enum DriverMode {
    Local,
    LoopbackRemote,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct DriverSummary {
    pub mode: DriverMode,
    pub headline: String,
    pub lines: Vec<String>,
}

pub async fn run_local_status(
    client: &LocalAppClient,
) -> Result<DriverSummary, caly_api::ApiError> {
    let ctx = default_ctx("cli-local-status", Actor::Cli);
    let system = client.system().status(ctx.clone()).await?;
    let runtime = client.runtime().status(ctx.clone()).await?;
    Ok(DriverSummary {
        mode: DriverMode::Local,
        headline: format!(
            "local daemon_state={} revision={}",
            system.daemon_state, system.state_revision
        ),
        lines: vec![
            format!("active_profile={:?}", system.active_profile),
            format!("active_core={:?}", system.active_core),
            format!("runtime_core_running={}", runtime.core_running),
            format!("runtime_active_profile={:?}", runtime.active_profile),
            format!("runtime_active_core={:?}", runtime.active_core),
            format!("runtime_active_snapshot={:?}", runtime.active_snapshot),
            format!(
                "runtime_last_apply_plan_summary={:?}",
                runtime.last_apply_plan_summary
            ),
            format!(
                "runtime_pending_recovery_decisions={}",
                runtime.pending_recovery_decisions
            ),
            format!(
                "runtime_last_recovery_summary={:?}",
                runtime.last_recovery_summary
            ),
            format!("runtime_last_failure={:?}", runtime.last_failure),
        ],
    })
}

pub async fn run_loopback_status() -> Result<DriverSummary, String> {
    let mut remote = build_loopback_remote_client();
    remote.handshake()?;
    let facade = RemoteFacade::new(remote);
    let ctx = default_ctx("cli-loopback-status", Actor::Cli);
    let system = facade
        .system()
        .status(ctx.clone())
        .await
        .map_err(|e| e.summary)?;
    let runtime = facade
        .runtime()
        .status(ctx.clone())
        .await
        .map_err(|e| e.summary)?;
    Ok(DriverSummary {
        mode: DriverMode::LoopbackRemote,
        headline: format!(
            "remote daemon_state={} revision={}",
            system.daemon_state, system.state_revision
        ),
        lines: vec![
            format!("active_profile={:?}", system.active_profile),
            format!("active_core={:?}", system.active_core),
            format!("runtime_core_running={}", runtime.core_running),
            format!("runtime_active_profile={:?}", runtime.active_profile),
            format!("runtime_active_core={:?}", runtime.active_core),
            format!("runtime_active_snapshot={:?}", runtime.active_snapshot),
            format!(
                "runtime_last_apply_plan_summary={:?}",
                runtime.last_apply_plan_summary
            ),
            format!(
                "runtime_pending_recovery_decisions={}",
                runtime.pending_recovery_decisions
            ),
            format!(
                "runtime_last_recovery_summary={:?}",
                runtime.last_recovery_summary
            ),
            format!("runtime_last_failure={:?}", runtime.last_failure),
        ],
    })
}

pub async fn run_loopback_follow_job(job_id: caly_api::JobId) -> Result<DriverSummary, String> {
    let mut remote = build_loopback_remote_client();
    remote.handshake()?;
    let facade = RemoteFacade::new(remote);
    let ctx = default_ctx("cli-loopback-follow-job", Actor::Cli);
    let view = facade
        .diagnostics()
        .follow_job(
            ctx,
            JobFollowRequest {
                job_id,
                from_event_index: None,
            },
        )
        .await
        .map_err(|e| e.summary)?;
    Ok(DriverSummary {
        mode: DriverMode::LoopbackRemote,
        headline: format!(
            "job={} state={} lifecycle={}",
            view.job_id.0, view.state, view.lifecycle
        ),
        lines: vec![
            format!("next_event_index={}", view.next_event_index),
            format!(
                "retained_from_event_index={}",
                view.retained_from_event_index
            ),
            format!("reset_required={}", view.reset_required),
            format!("event_count={}", view.event_count),
        ],
    })
}

pub async fn run_local_recovery_status(
    client: &LocalAppClient,
) -> Result<DriverSummary, caly_api::ApiError> {
    let ctx = default_ctx("cli-local-recovery-status", Actor::Cli);
    let recovery = client.diagnostics().recovery_status(ctx).await?;
    Ok(DriverSummary {
        mode: DriverMode::Local,
        headline: format!(
            "local recovery lifecycle={} decisions={}",
            recovery.daemon_lifecycle, recovery.decision_count
        ),
        lines: vec![
            format!("active_profile={:?}", recovery.active_profile),
            format!("active_core={:?}", recovery.active_core),
            format!("active_snapshot={:?}", recovery.active_snapshot),
            format!(
                "last_apply_plan_summary={:?}",
                recovery.last_apply_plan_summary
            ),
            format!("pending_apply_count={}", recovery.pending_apply_count),
            format!("pending_os_count={}", recovery.pending_os_count),
            format!("last_recovery_summary={:?}", recovery.last_recovery_summary),
            format!("decisions={:?}", recovery.decisions),
        ],
    })
}

pub async fn run_loopback_recovery_status() -> Result<DriverSummary, String> {
    let mut remote = build_loopback_remote_client();
    remote.handshake()?;
    let facade = RemoteFacade::new(remote);
    let ctx = default_ctx("cli-loopback-recovery-status", Actor::Cli);
    let recovery = facade
        .diagnostics()
        .recovery_status(ctx)
        .await
        .map_err(|e| e.summary)?;
    Ok(DriverSummary {
        mode: DriverMode::LoopbackRemote,
        headline: format!(
            "remote recovery lifecycle={} decisions={}",
            recovery.daemon_lifecycle, recovery.decision_count
        ),
        lines: vec![
            format!("active_profile={:?}", recovery.active_profile),
            format!("active_core={:?}", recovery.active_core),
            format!("active_snapshot={:?}", recovery.active_snapshot),
            format!(
                "last_apply_plan_summary={:?}",
                recovery.last_apply_plan_summary
            ),
            format!("pending_apply_count={}", recovery.pending_apply_count),
            format!("pending_os_count={}", recovery.pending_os_count),
            format!("last_recovery_summary={:?}", recovery.last_recovery_summary),
            format!("decisions={:?}", recovery.decisions),
        ],
    })
}

pub async fn run_local_apply_lifecycle(
    client: &LocalAppClient,
    profile_id: impl Into<String>,
) -> Result<DriverSummary, caly_api::ApiError> {
    let profile_id = profile_id.into();
    let ctx = default_ctx("cli-local-apply", Actor::Cli);
    let accepted = client
        .profile()
        .apply(
            ctx.clone(),
            ApplyRequest {
                profile_id: caly_api::ProfileId(profile_id.clone()),
                dry_run: false,
                strict: false,
            },
        )
        .await?;
    let processed = client
        .facade()
        .app()
        .process_next_job()
        .map_err(|message| {
            caly_api::ApiError::internal(
                message,
                caly_common::TraceId::new("cli-local-apply-process"),
            )
        })?;
    let follow = client
        .diagnostics()
        .follow_job(
            ctx.clone(),
            JobFollowRequest {
                job_id: accepted.job_id,
                from_event_index: None,
            },
        )
        .await?;
    let runtime = client.runtime().status(ctx.clone()).await?;
    let recovery = client.diagnostics().recovery_status(ctx.clone()).await?;
    let doctor = client
        .diagnostics()
        .doctor(
            ctx,
            caly_api::DoctorRequest {
                include_runtime: true,
            },
        )
        .await?;

    Ok(DriverSummary {
        mode: DriverMode::Local,
        headline: format!(
            "local apply job={} processed={}",
            accepted.job_id.0, processed
        ),
        lines: vec![
            format!("follow_state={}", follow.state),
            format!("follow_events={}", follow.event_count),
            format!("runtime_active_snapshot={:?}", runtime.active_snapshot),
            format!("runtime_active_profile={:?}", runtime.active_profile),
            format!(
                "runtime_last_apply_plan_summary={:?}",
                runtime.last_apply_plan_summary
            ),
            format!("recovery_decision_count={}", recovery.decision_count),
            format!("recovery_last_summary={:?}", recovery.last_recovery_summary),
            format!("doctor_warnings={}", doctor.warnings.len()),
            format!("doctor_errors={}", doctor.errors.len()),
        ],
    })
}

pub async fn run_loopback_apply_lifecycle(
    profile_id: impl Into<String>,
) -> Result<DriverSummary, String> {
    let profile_id = profile_id.into();
    let mut remote = build_loopback_remote_client();
    remote.handshake()?;
    let accepted = remote.submit_apply(
        ApplyRequest {
            profile_id: caly_api::ProfileId(profile_id),
            dry_run: false,
            strict: false,
        },
        Some("cli-loopback-apply".to_owned()),
    )?;
    let processed = remote.process_next_job()?;
    // The code is spelled into the text on purpose. This driver reports `Result<_, String>`, while
    // `docs/EXIT_CODES.md §1` wants an exit code derived from `ApiError.code` — so until the CLI
    // gets its `[[bin]]` and the typed error flows end to end (see
    // `docs/ONBOARDING_NOTES.md §4.40`), the code at least survives the trip into the summary line
    // instead of being flattened away.
    let follow = remote
        .follow_job_query(accepted.job_id, None)
        .map_err(|error| format!("{:?}: {}", error.code, error.summary))?;
    let runtime = remote.runtime_status()?;
    let recovery_view = remote.recovery_status()?;
    let doctor = remote.doctor(true)?;

    Ok(DriverSummary {
        mode: DriverMode::LoopbackRemote,
        headline: format!(
            "remote apply job={} processed={}",
            accepted.job_id.0, processed
        ),
        lines: vec![
            format!("follow_state={}", follow.state),
            format!("follow_events={}", follow.event_count),
            format!("runtime_active_snapshot={:?}", runtime.active_snapshot),
            format!("runtime_active_profile={:?}", runtime.active_profile),
            format!(
                "runtime_last_apply_plan_summary={:?}",
                runtime.last_apply_plan_summary
            ),
            format!("recovery_decision_count={}", recovery_view.decision_count),
            format!(
                "recovery_last_summary={:?}",
                recovery_view.last_recovery_summary
            ),
            format!("doctor_warnings={}", doctor.warnings.len()),
            format!("doctor_errors={}", doctor.errors.len()),
        ],
    })
}
