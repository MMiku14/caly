//! Declarative CLI mapping tests, W1-β edition.
//!
//! The v3 resource-domain grammar (cli-v3-design.md §4) is the
//! single source of truth; the v1 5-namespace paths (`show` /
//! `set` / v1 `tool` leaves) keep parsing through the alias
//! expansion layer (`aliases.rs`), so most v1-era assertions below
//! still run against the deprecated spellings AND the canonical
//! v3 spellings — the final block asserts the two are equal.

use super::*;

fn parse(values: &[&str]) -> Invocation {
    match parse_args(values.iter().map(|value| (*value).to_owned())) {
        Ok(invocation) => invocation,
        Err(error) => {
            panic!("parse failed for {values:?}: {error}")
        }
    }
}

fn parse_err(values: &[&str]) -> clap::Error {
    match parse_args(values.iter().map(|value| (*value).to_owned())) {
        Ok(_) => {
            panic!("expected parse failure for {values:?}")
        }
        Err(error) => error,
    }
}

// ── Global options ──────────────────────────────────────────────

#[test]
fn global_options_are_mapped_to_all_namespaces() {
    let invocation = parse(&["--json", "show", "status"]);
    assert!(invocation.options.json);
    assert_eq!(
        invocation.command,
        Command::Show(ShowCmd::Status { watch: false })
    );

    let invocation = parse(&["--core", "mihomo", "show", "core", "nodes"]);
    assert_eq!(invocation.options.core.as_deref(), Some("mihomo"));
    assert_eq!(
        invocation.command,
        Command::Show(ShowCmd::Core(ShowCoreCmd::Nodes))
    );

    let invocation = parse(&[
        "daemon",
        "--mihomo-bin=/opt/mihomo",
        "--sing-box-bin",
        "/opt/sing-box",
    ]);
    assert_eq!(invocation.command, Command::Daemon);
    assert_eq!(
        invocation.options.mihomo_bin,
        Some(PathBuf::from("/opt/mihomo"))
    );
    assert_eq!(
        invocation.options.sing_box_bin,
        Some(PathBuf::from("/opt/sing-box"))
    );
}

// ── tool namespace (5 leaves) ──────────────────────────────────

#[test]
fn tool_namespace_parses_all_four_leaves() {
    assert_eq!(
        parse(&["tool", "help"]).command,
        Command::Tool(ToolCmd::Help(None))
    );
    assert_eq!(
        parse(&["tool", "help", "set"]).command,
        Command::Tool(ToolCmd::Help(Some("set".to_owned())))
    );
    assert_eq!(
        parse(&["tool", "version"]).command,
        Command::Tool(ToolCmd::Version)
    );
    assert_eq!(
        parse(&["tool", "doctor"]).command,
        Command::Tool(ToolCmd::Doctor { fix: false })
    );
    assert_eq!(
        parse(&["tool", "doctor", "--fix"]).command,
        Command::Tool(ToolCmd::Doctor { fix: true })
    );
    assert_eq!(
        parse(&["tool", "dns", "example.com"]).command,
        Command::Tool(ToolCmd::Dns(Some("example.com".to_owned())))
    );
    assert_eq!(
        parse(&["tool", "dns"]).command,
        Command::Tool(ToolCmd::Dns(None))
    );
}

// ── show namespace (6 resources) ───────────────────────────────

#[test]
fn show_status_is_a_top_level_subcommand() {
    assert_eq!(
        parse(&["show", "status"]).command,
        Command::Show(ShowCmd::Status { watch: false })
    );
}

#[test]
fn show_core_parses_seven_leaves() {
    assert_eq!(
        parse(&["show", "core", "nodes"]).command,
        Command::Show(ShowCmd::Core(ShowCoreCmd::Nodes))
    );
    assert_eq!(
        parse(&["show", "core", "groups"]).command,
        Command::Show(ShowCmd::Core(ShowCoreCmd::Groups))
    );
    assert_eq!(
        parse(&["show", "core", "connections"]).command,
        Command::Show(ShowCmd::Core(ShowCoreCmd::Connections { watch: false }))
    );
    assert_eq!(
        parse(&["show", "core", "traffic"]).command,
        Command::Show(ShowCmd::Core(ShowCoreCmd::Traffic { watch: false }))
    );
    assert_eq!(
        parse(&["show", "core", "mode"]).command,
        Command::Show(ShowCmd::Core(ShowCoreCmd::Mode))
    );
    assert_eq!(
        parse(&["show", "core", "rules"]).command,
        Command::Show(ShowCmd::Core(ShowCoreCmd::Rules { r#match: None }))
    );
    assert_eq!(
        parse(&["show", "core", "rules", "--match", "example.com"]).command,
        Command::Show(ShowCmd::Core(ShowCoreCmd::Rules {
            r#match: Some("example.com".to_owned())
        }))
    );
    // New Round 11 capability: `show core health`
    assert_eq!(
        parse(&["show", "core", "health"]).command,
        Command::Show(ShowCmd::Core(ShowCoreCmd::Health))
    );
}

#[test]
fn show_sub_parses_three_leaves_including_renamed_parse() {
    assert_eq!(
        parse(&["show", "sub", "providers"]).command,
        Command::Show(ShowCmd::Sub(ShowSubCmd::Providers))
    );
    assert_eq!(
        parse(&["show", "sub", "parse", "/tmp/sub.txt"]).command,
        Command::Show(ShowCmd::Sub(ShowSubCmd::Parse {
            path: PathBuf::from("/tmp/sub.txt"),
            userinfo: None,
            apply: false,
            name: None,
        }))
    );
    assert_eq!(
        parse(&[
            "show",
            "sub",
            "parse",
            "/tmp/sub.txt",
            "--userinfo",
            "u=100"
        ])
        .command,
        Command::Show(ShowCmd::Sub(ShowSubCmd::Parse {
            path: PathBuf::from("/tmp/sub.txt"),
            userinfo: Some("u=100".to_owned()),
            apply: false,
            name: None,
        }))
    );
    // W1-β: the v1 preview leaf is aliased onto `sub import`,
    // whose dry-run default IS the same preview (cli.rs note).
    assert_eq!(
        parse(&["show", "sub", "import"]).command,
        Command::Set(SetCmd::Sub(SetSubCmd::Import {
            path: None,
            clipboard: false,
            apply: false,
            dry_run: false,
        }))
    );
    assert_eq!(
        parse(&["show", "sub", "import", "--clipboard"]).command,
        Command::Set(SetCmd::Sub(SetSubCmd::Import {
            path: None,
            clipboard: true,
            apply: false,
            dry_run: false,
        }))
    );
}

#[test]
fn show_profile_parses_list_and_show() {
    assert_eq!(
        parse(&["show", "profile", "list"]).command,
        Command::Show(ShowCmd::Profile(ShowProfileCmd::List))
    );
    assert_eq!(
        parse(&["show", "profile", "show", "team"]).command,
        Command::Show(ShowCmd::Profile(ShowProfileCmd::Show {
            id: "team".to_owned()
        }))
    );
}

#[test]
fn show_proxy_parses_three_leaves() {
    // W1-β: the deprecated v1 leaves rewrite onto the node
    // domain — `node list` (online) / `node groups` (T-1).
    assert_eq!(
        parse(&["show", "proxy", "list"]).command,
        Command::Show(ShowCmd::Core(ShowCoreCmd::Nodes))
    );
    assert_eq!(
        parse(&["show", "proxy", "show", "abc"]).command,
        Command::Show(ShowCmd::Proxy(ShowProxyCmd::Show {
            id: "abc".to_owned()
        }))
    );
    assert_eq!(
        parse(&["show", "proxy", "groups"]).command,
        Command::Show(ShowCmd::Core(ShowCoreCmd::Groups))
    );
}

#[test]
fn show_config_parses_three_leaves() {
    assert_eq!(
        parse(&["show", "config", "path"]).command,
        Command::Show(ShowCmd::Config(ShowConfigCmd::Path))
    );
    assert_eq!(
        parse(&["show", "config", "files"]).command,
        Command::Show(ShowCmd::Config(ShowConfigCmd::Files))
    );
    assert_eq!(
        parse(&["show", "config", "validate"]).command,
        Command::Show(ShowCmd::Config(ShowConfigCmd::Validate { file: None }))
    );
    assert_eq!(
        parse(&["show", "config", "validate", "--file", "/tmp/x.yaml"]).command,
        Command::Show(ShowCmd::Config(ShowConfigCmd::Validate {
            file: Some(PathBuf::from("/tmp/x.yaml")),
        }))
    );
}

#[path = "cli_tests/presentation_tests.rs"]
mod presentation;
#[path = "cli_tests/proxy_group_tests.rs"]
mod proxy_group;
#[path = "cli_tests/set_namespace_tests.rs"]
mod set_namespace;
#[path = "cli_tests/tree_tests.rs"]
mod tree;
