use super::*;

// ── Dry-run semantics ──────────────────────────────────────────

fn expect_set_proxy_add(command: Command) -> (bool, bool) {
    match command {
        Command::Set(SetCmd::Proxy(SetProxyCmd::Add { apply, dry_run, .. })) => (apply, dry_run),
        other => {
            panic!("expected set proxy add, got {other:?}")
        }
    }
}

fn expect_set_proxy_remove(command: Command) -> (bool, bool) {
    match command {
        // W1-β: remove routes through the Entry seam (C-M).
        Command::Set(SetCmd::Entry(EntryWriteCmd::Remove { apply, dry_run, .. })) => {
            (apply, dry_run)
        }
        other => {
            panic!("expected entry remove, got {other:?}")
        }
    }
}

fn expect_set_proxy_import(command: Command) -> (bool, bool) {
    match command {
        Command::Set(SetCmd::Proxy(SetProxyCmd::Import { apply, dry_run, .. })) => (apply, dry_run),
        other => {
            panic!("expected set proxy import, got {other:?}")
        }
    }
}

fn expect_set_sub_add(command: Command) -> (bool, bool) {
    match command {
        Command::Set(SetCmd::Sub(SetSubCmd::Add { apply, dry_run, .. })) => (apply, dry_run),
        other => {
            panic!("expected set sub add, got {other:?}")
        }
    }
}

fn expect_set_sub_remove(command: Command) -> (bool, bool) {
    match command {
        Command::Set(SetCmd::Sub(SetSubCmd::Remove { apply, dry_run, .. })) => (apply, dry_run),
        other => {
            panic!("expected set sub remove, got {other:?}")
        }
    }
}

fn expect_set_profile_remove(command: Command) -> (bool, bool) {
    match command {
        Command::Set(SetCmd::Profile(SetProfileCmd::Remove { apply, dry_run, .. })) => {
            (apply, dry_run)
        }
        other => {
            panic!("expected set profile remove, got {other:?}")
        }
    }
}

#[test]
fn dry_run_defaults_to_false_on_writes() {
    // Every write command should default to `apply: false, dry_run: false`
    // per the Round 11 spec (dry-run is the SAFE default; the user must
    // explicitly opt in to writing by adding `--apply`).
    let (apply, dry_run) =
        expect_set_proxy_add(parse(&["set", "proxy", "add", "ss://abc"]).command);
    assert!(!apply);
    assert!(!dry_run);

    let (apply, dry_run) =
        expect_set_proxy_remove(parse(&["set", "proxy", "remove", "id1"]).command);
    assert!(!apply);
    assert!(!dry_run);

    let (apply, dry_run) =
        expect_set_proxy_import(parse(&["set", "proxy", "import", "/tmp/u"]).command);
    assert!(!apply);
    assert!(!dry_run);

    let (apply, dry_run) = expect_set_sub_add(parse(&["set", "sub", "add", "https://x"]).command);
    assert!(!apply);
    assert!(!dry_run);
}

#[test]
fn apply_flag_sets_apply_true() {
    let (apply, dry_run) =
        expect_set_proxy_add(parse(&["set", "proxy", "add", "ss://abc", "--apply"]).command);
    assert!(apply);
    assert!(!dry_run);

    let (apply, dry_run) =
        expect_set_sub_remove(parse(&["set", "sub", "remove", "https://x", "--apply"]).command);
    assert!(apply);
    assert!(!dry_run);

    let (apply, dry_run) =
        expect_set_profile_remove(parse(&["set", "profile", "remove", "team", "--apply"]).command);
    assert!(apply);
    assert!(!dry_run);
}

#[test]
fn dry_run_flag_is_still_accepted_explicitly() {
    // Round 10 had --dry-run as the opt-in. Round 11 makes it the default
    // via `--apply`, but the legacy `--dry-run` flag must still parse and
    // be honored for backwards compatibility.
    let (apply, dry_run) =
        expect_set_proxy_remove(parse(&["set", "proxy", "remove", "id1", "--dry-run"]).command);
    assert!(!apply);
    assert!(dry_run);

    let (apply, dry_run) =
        expect_set_sub_add(parse(&["set", "sub", "add", "https://x", "--dry-run"]).command);
    assert!(!apply);
    assert!(dry_run);
}

#[test]
fn apply_and_dry_run_must_not_both_be_true() {
    // Clap should reject the contradictory combination; a parse error
    // is the expected outcome.
    let err = parse_err(&["set", "proxy", "add", "ss://abc", "--apply", "--dry-run"]);
    let message = err.to_string();
    assert!(
        message.contains("cannot be used with") || message.contains("conflict"),
        "expected conflict error, got: {message}"
    );
}

// ── Retired spellings are rejected ─────────────────────────────

#[test]
fn old_top_level_spellings_are_rejected() {
    // W1-β: the earlier generations of this test asserted that
    // the pre-Round-11 spellings were gone. v3 inverts part of
    // that on purpose (bare `status` / `doctor` / `dns` ARE the
    // canonical v3 shapes now), so the contract becomes: the v1
    // namespace roots and mid-layers only parse through the
    // complete alias paths — never bare — and never-landed
    // spellings stay rejected.
    for removed in [
        vec!["show".to_owned()],
        vec!["set".to_owned()],
        vec!["show".to_owned(), "core".to_owned()],
        vec!["set".to_owned(), "core".to_owned()],
        vec!["set".to_owned(), "proxy".to_owned()],
        vec!["set".to_owned(), "proxy-group".to_owned()],
        // Q3/D3: `daemon run` was explicitly not adopted.
        vec!["daemon".to_owned(), "run".to_owned()],
        // v3 `core` owns only the kernel lifecycle.
        vec!["core".to_owned(), "nodes".to_owned()],
        // The v0 `sys` namespace stays retired.
        vec!["sys".to_owned(), "tun".to_owned(), "on".to_owned()],
        // Retired leaf names from earlier generations.
        vec!["sub".to_owned(), "check".to_owned(), "/tmp/x".to_owned()],
        vec!["config".to_owned(), "check".to_owned(), "/tmp/x".to_owned()],
        vec!["config".to_owned(), "vim".to_owned()],
        // `help` / `version` live under `tool` only.
        vec!["help".to_owned()],
        vec!["version".to_owned()],
        // Unknown leaves under a new domain (never a bare word).
        vec!["node".to_owned(), "bogus".to_owned()],
    ] {
        assert!(
            parse_args(removed.clone()).is_err(),
            "expected retired spelling to be rejected: {removed:?}"
        );
    }
}

#[test]
fn old_short_flag_aliases_are_rejected() {
    for removed in [
        vec!["-t".to_owned()],
        vec!["-d".to_owned()],
        vec!["-c".to_owned(), "start".to_owned()],
        vec!["-s".to_owned(), "refresh".to_owned()],
        vec!["-p".to_owned(), "proxy".to_owned(), "on".to_owned()],
    ] {
        assert!(
            parse_args(removed.clone()).is_err(),
            "expected removed short flag to be rejected: {removed:?}"
        );
    }
}

// ── Completions (top-level) ────────────────────────────────────

#[test]
fn completions_stays_as_a_top_level_subcommand() {
    assert_eq!(
        parse(&["completions", "zsh"]).command,
        Command::Completions(CompletionShell::Zsh)
    );
    assert_eq!(
        parse(&["completions", "bash"]).command,
        Command::Completions(CompletionShell::Bash)
    );
    assert_eq!(
        parse(&["completions", "fish"]).command,
        Command::Completions(CompletionShell::Fish)
    );
    assert_eq!(
        parse(&["completions", "elvish"]).command,
        Command::Completions(CompletionShell::Elvish)
    );
    assert_eq!(
        parse(&["completions", "powershell"]).command,
        Command::Completions(CompletionShell::PowerShell)
    );
}

// ── Help-text contract ─────────────────────────────────────────

#[test]
fn top_level_help_lists_all_four_namespaces() {
    // W1-β: the v3 resource-domain tree. The test name is
    // historical (Round 11); the contract now covers every v3
    // head so a missing domain fails loudly.
    let mut cmd = <grammar::ClapCli as clap::CommandFactory>::command();
    let mut buffer = Vec::new();
    cmd.write_long_help(&mut buffer)
        .unwrap_or_else(|error| panic!("help render failed: {error}"));
    let text =
        String::from_utf8(buffer).unwrap_or_else(|error| panic!("help text is not UTF-8: {error}"));
    for head in [
        "daemon",
        "stop",
        "reload",
        "restart",
        "status",
        "node",
        "sub",
        "profile",
        "config",
        "core",
        "rule-provider",
        "provider",
        "rules",
        "connections",
        "traffic",
        "mode",
        "sysproxy",
        "tun",
        "dns",
        "doctor",
        "tool",
        "completions",
    ] {
        assert!(text.contains(head), "top-level help must list `{head}`");
    }
    assert!(
        text.contains("Common workflows"),
        "after-help must point at the common workflows section"
    );
    assert!(
        text.contains("caly config apply"),
        "after-help must include an example write command"
    );
    assert!(
        text.contains("--apply"),
        "after-help must mention the --apply flag (dry-run policy)"
    );
}

#[test]
fn node_subcommand_help_lists_every_entry_verb() {
    // W1-β: the v3 node domain (nodes + groups, one resource).
    let mut cmd = <grammar::ClapCli as clap::CommandFactory>::command();
    let Some(node_cmd) = cmd.find_subcommand_mut("node") else {
        panic!("node subcommand must exist")
    };
    let mut buffer = Vec::new();
    node_cmd
        .write_long_help(&mut buffer)
        .unwrap_or_else(|error| panic!("help render failed: {error}"));
    let text =
        String::from_utf8(buffer).unwrap_or_else(|error| panic!("help text is not UTF-8: {error}"));
    for leaf in [
        "list", "groups", "show", "select", "ping", "test", "add", "edit", "remove", "enable",
        "disable", "import",
    ] {
        assert!(text.contains(leaf), "node help must list leaf `{leaf}`");
    }
}

#[test]
fn config_subcommand_help_lists_every_leaf() {
    // W1-β: the v3 config domain owns both the read leaves
    // (path/files/validate) and the write leaves (apply/…).
    let mut cmd = <grammar::ClapCli as clap::CommandFactory>::command();
    let Some(config_cmd) = cmd.find_subcommand_mut("config") else {
        panic!("config subcommand must exist")
    };
    let mut buffer = Vec::new();
    config_cmd
        .write_long_help(&mut buffer)
        .unwrap_or_else(|error| panic!("help render failed: {error}"));
    let text =
        String::from_utf8(buffer).unwrap_or_else(|error| panic!("help text is not UTF-8: {error}"));
    for leaf in [
        "show", "path", "files", "validate", "apply", "generate", "default", "diff", "edit",
    ] {
        assert!(text.contains(leaf), "config help must list leaf `{leaf}`");
    }
}

#[test]
fn tool_subcommand_help_lists_the_three_retained_leaves() {
    // W1-β: dns/doctor are top-level verbs in v3; `tool` keeps
    // help/version only.
    let mut cmd = <grammar::ClapCli as clap::CommandFactory>::command();
    let Some(tool_cmd) = cmd.find_subcommand_mut("tool") else {
        panic!("tool subcommand must exist")
    };
    let mut buffer = Vec::new();
    tool_cmd
        .write_long_help(&mut buffer)
        .unwrap_or_else(|error| panic!("help render failed: {error}"));
    let text =
        String::from_utf8(buffer).unwrap_or_else(|error| panic!("help text is not UTF-8: {error}"));
    for leaf in ["help", "version"] {
        assert!(text.contains(leaf), "tool help must list leaf `{leaf}`");
    }
}
