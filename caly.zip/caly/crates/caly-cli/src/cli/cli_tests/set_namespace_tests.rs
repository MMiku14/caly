use super::*;

// ── set namespace (7 resources) ────────────────────────────────

#[test]
fn set_core_parses_eight_leaves_including_url_test() {
    assert_set_core_lifecycle_and_select_leaves();
    // Round 24 (debug): the `--group Auto` flag on
    // `set core select` was silently dropped by the
    // dispatch (the wire `SelectProxy { node_id }` has
    // no group field). The right contract is to refuse
    // the flag at parse time so the operator sees a
    // clap error instead of a no-op success. Lock the
    // rejection: `--group` is now an unknown flag.
    for removed in [
        vec!["set", "core", "select", "--group", "Auto"],
        vec!["set", "core", "select", "node1", "--group", "Auto"],
    ] {
        let result = parse_args(removed.iter().map(|s| (*s).to_owned()));
        assert!(
            result.is_err(),
            "expected --group on select to be rejected: {removed:?} got {result:?}"
        );
    }
    assert_eq!(
        parse(&["set", "core", "mode", "global"]).command,
        Command::Set(SetCmd::Core(SetCoreCmd::Mode("global".to_owned())))
    );
    assert_eq!(
        parse(&["set", "core", "close-connections"]).command,
        Command::Set(SetCmd::Core(SetCoreCmd::CloseConnections { id: None }))
    );
    assert_eq!(
        parse(&["set", "core", "delay", "--all"]).command,
        Command::Set(SetCmd::Core(SetCoreCmd::Delay {
            name: None,
            all: true,
            url: None,
            samples: None,
        }))
    );
    // New Round 11 capability: `set core url-test`
    assert_eq!(
        parse(&["set", "core", "url-test", "node1"]).command,
        Command::Set(SetCmd::Core(SetCoreCmd::UrlTest {
            name: "node1".to_owned(),
            url: None,
            samples: None,
            apply: false
        }))
    );
    assert_eq!(
        parse(&["set", "core", "url-test", "node1", "--url", "http://g"]).command,
        Command::Set(SetCmd::Core(SetCoreCmd::UrlTest {
            name: "node1".to_owned(),
            url: Some("http://g".to_owned()),
            samples: None,
            apply: false
        }))
    );
    // Round 24 (debug): the `--timeout` flag was
    // silently dropped by the dispatch (the offline
    // `Query::UrlTest` resolver has a hard-coded
    // `QUERY_TIMEOUT`, no per-call override). Drop the
    // flag from the grammar so the operator sees a
    // clap error instead of a no-op success. Lock the
    // rejection here.
    for removed in [
        vec!["set", "core", "url-test", "node1", "--timeout", "3000"],
        vec![
            "set",
            "core",
            "url-test",
            "node1",
            "--url",
            "http://g",
            "--timeout",
            "3000",
        ],
    ] {
        let result = parse_args(removed.iter().map(|s| (*s).to_owned()));
        assert!(
            result.is_err(),
            "expected --timeout on url-test to be rejected: {removed:?} got {result:?}"
        );
    }
}

fn assert_set_core_lifecycle_and_select_leaves() {
    assert_eq!(
        parse(&["set", "core", "start"]).command,
        Command::Set(SetCmd::Core(SetCoreCmd::Start))
    );
    assert_eq!(
        parse(&["set", "core", "stop"]).command,
        Command::Set(SetCmd::Core(SetCoreCmd::Stop))
    );
    assert_eq!(
        parse(&["set", "core", "restart"]).command,
        Command::Set(SetCmd::Core(SetCoreCmd::Restart))
    );
    assert_eq!(
        parse(&["set", "core", "switch", "mihomo"]).command,
        Command::Set(SetCmd::Core(SetCoreCmd::Switch("mihomo".to_owned())))
    );
    assert_eq!(
        parse(&["set", "core", "switch", "sing-box"]).command,
        Command::Set(SetCmd::Core(SetCoreCmd::Switch("sing-box".to_owned())))
    );
    assert_eq!(
        parse(&["set", "core", "select"]).command,
        Command::Set(SetCmd::Core(SetCoreCmd::Select {
            node: None,
            delay: false,
            poll: false,
        }))
    );
    assert_eq!(
        parse(&["set", "core", "select", "node1", "--delay"]).command,
        Command::Set(SetCmd::Core(SetCoreCmd::Select {
            node: Some("node1".to_owned()),
            delay: true,
            poll: false,
        }))
    );
}

#[test]
fn set_core_delay_samples_flag_is_optional_and_parses() {
    // Round 20: `--samples N` lets the operator
    // pick the per-URL sample count for jitter-
    // sensitive probes. The default (None) is
    // resolved at the dispatch boundary; the
    // CLI just preserves whatever the user passed.
    assert_eq!(
        parse(&["set", "core", "delay", "node1", "--samples", "1"]).command,
        Command::Set(SetCmd::Core(SetCoreCmd::Delay {
            name: Some("node1".to_owned()),
            all: false,
            url: None,
            samples: Some(1),
        }))
    );
    assert_eq!(
        parse(&["set", "core", "delay", "--all", "--samples", "5"]).command,
        Command::Set(SetCmd::Core(SetCoreCmd::Delay {
            name: None,
            all: true,
            url: None,
            samples: Some(5),
        }))
    );
    assert_eq!(
        parse(&["set", "core", "url-test", "node1", "--samples", "3"]).command,
        Command::Set(SetCmd::Core(SetCoreCmd::UrlTest {
            name: "node1".to_owned(),
            url: None,
            samples: Some(3),
            apply: false
        }))
    );
}

#[test]
fn set_proxy_parses_four_crud_leaves_plus_on_off() {
    // New Round 11 capabilities: add / edit / remove / import
    assert_eq!(
        parse(&["set", "proxy", "add", "ss://abc"]).command,
        Command::Set(SetCmd::Proxy(SetProxyCmd::Add {
            uri: "ss://abc".to_owned(),
            group: None,
            apply: false,
            dry_run: false,
        }))
    );
    assert_eq!(
        parse(&["set", "proxy", "add", "ss://abc", "--group", "G", "--apply"]).command,
        Command::Set(SetCmd::Proxy(SetProxyCmd::Add {
            uri: "ss://abc".to_owned(),
            group: Some("G".to_owned()),
            apply: true,
            dry_run: false,
        }))
    );
    assert_eq!(
        parse(&["set", "proxy", "edit", "id1", "--apply"]).command,
        Command::Set(SetCmd::Proxy(SetProxyCmd::Edit {
            id: "id1".to_owned(),
            apply: true,
            dry_run: false,
        }))
    );
    // W1-β (C-M): remove routes through the Entry seam — the v1
    // node path and the proxy-group path share the v3 leaf.
    assert_eq!(
        parse(&["set", "proxy", "remove", "id1"]).command,
        Command::Set(SetCmd::Entry(EntryWriteCmd::Remove {
            id: "id1".to_owned(),
            apply: false,
            dry_run: false,
        }))
    );
    assert_eq!(
        parse(&["set", "proxy", "import", "/tmp/uri.list", "--apply"]).command,
        Command::Set(SetCmd::Proxy(SetProxyCmd::Import {
            path: PathBuf::from("/tmp/uri.list"),
            apply: true,
            dry_run: false,
        }))
    );
    // Old `set sys proxy on/off` is now `set proxy on/off`
    assert_eq!(
        parse(&["set", "proxy", "on"]).command,
        Command::Set(SetCmd::Proxy(SetProxyCmd::On))
    );
    assert_eq!(
        parse(&["set", "proxy", "off"]).command,
        Command::Set(SetCmd::Proxy(SetProxyCmd::Off))
    );
}

#[test]
fn set_tun_parses_on_off() {
    assert_eq!(
        parse(&["set", "tun", "on"]).command,
        Command::Set(SetCmd::Tun(true))
    );
    assert_eq!(
        parse(&["set", "tun", "off"]).command,
        Command::Set(SetCmd::Tun(false))
    );
}

#[test]
fn set_sub_refresh_leaf_parses_beta2b_flags() {
    // W2-β2b (§4.3): [name-or-url] [--force] [--async].
    assert_eq!(
        parse(&["sub", "refresh"]).command,
        Command::Set(SetCmd::Sub(SetSubCmd::Refresh {
            target: None,
            force: false,
            asynchronous: false,
        }))
    );
    assert_eq!(
        parse(&["sub", "refresh", "airport", "--force", "--async"]).command,
        Command::Set(SetCmd::Sub(SetSubCmd::Refresh {
            target: Some("airport".to_owned()),
            force: true,
            asynchronous: true,
        }))
    );
    // The legacy spelling still expands onto the same leaf.
    assert_eq!(
        parse(&["set", "sub", "refresh"]).command,
        Command::Set(SetCmd::Sub(SetSubCmd::Refresh {
            target: None,
            force: false,
            asynchronous: false,
        }))
    );
}

#[test]
fn set_sub_set_leaf_parses_change_flags() {
    // W2-β2b (§4.3): the three change flags each map through;
    // `--every` hours scale to minutes like `sub add`.
    assert_eq!(
        parse(&["sub", "set", "airport", "--url", "https://n", "--apply"]).command,
        Command::Set(SetCmd::Sub(SetSubCmd::Set {
            target: "airport".to_owned(),
            url: Some("https://n".to_owned()),
            name: None,
            refresh_every_minutes: None,
            apply: true,
            dry_run: false,
        }))
    );
    assert_eq!(
        parse(&["sub", "set", "airport", "--every", "12"]).command,
        Command::Set(SetCmd::Sub(SetSubCmd::Set {
            target: "airport".to_owned(),
            url: None,
            name: None,
            refresh_every_minutes: Some(720),
            apply: false,
            dry_run: false,
        }))
    );
    // The required ArgGroup rejects a bare `set` with no change.
    let result = parse_args(["sub", "set", "airport"].iter().map(|v| (*v).to_owned()));
    assert!(result.is_err(), "sub set without a change flag must fail");
    // --purge reaches the remove leaf.
    assert_eq!(
        parse(&["sub", "remove", "https://x", "--purge", "--apply"]).command,
        Command::Set(SetCmd::Sub(SetSubCmd::Remove {
            url: "https://x".to_owned(),
            purge: true,
            apply: true,
            dry_run: false,
        }))
    );
}

fn assert_sub_refresh_and_add_leaves() {
    assert_eq!(
        parse(&["set", "sub", "refresh"]).command,
        Command::Set(SetCmd::Sub(SetSubCmd::Refresh {
            target: None,
            force: false,
            asynchronous: false,
        }))
    );
    assert_eq!(
        parse(&["set", "sub", "add", "https://x"]).command,
        Command::Set(SetCmd::Sub(SetSubCmd::Add {
            url: "https://x".to_owned(),
            name: None,
            refresh_every_minutes: None,
            apply: false,
            dry_run: false,
        }))
    );
    assert_eq!(
        parse(&[
            "set",
            "sub",
            "add",
            "https://x",
            "--name",
            "team",
            "--apply"
        ])
        .command,
        Command::Set(SetCmd::Sub(SetSubCmd::Add {
            url: "https://x".to_owned(),
            name: Some("team".to_owned()),
            refresh_every_minutes: None,
            apply: true,
            dry_run: false,
        }))
    );
    // W2-β2a (Q5): `--every <hours>` scales to minutes in the
    // convert step; explicit 0 means "static".
    assert_eq!(
        parse(&["set", "sub", "add", "https://x", "--every", "24"]).command,
        Command::Set(SetCmd::Sub(SetSubCmd::Add {
            url: "https://x".to_owned(),
            name: None,
            refresh_every_minutes: Some(1_440),
            apply: false,
            dry_run: false,
        }))
    );
    assert_eq!(
        parse(&["set", "sub", "add", "https://x", "--every", "0"]).command,
        Command::Set(SetCmd::Sub(SetSubCmd::Add {
            url: "https://x".to_owned(),
            name: None,
            refresh_every_minutes: Some(0),
            apply: false,
            dry_run: false,
        }))
    );
    // The hours range is capped so the ×60 scale can never overflow.
    let result = parse_args(
        ["set", "sub", "add", "https://x", "--every", "1000001"]
            .iter()
            .map(|value| (*value).to_owned()),
    );
    assert!(result.is_err(), "--every beyond the cap must fail to parse");
}

#[test]
fn set_sub_parses_five_crud_leaves() {
    assert_sub_refresh_and_add_leaves();
    assert_eq!(
        parse(&["set", "sub", "remove", "https://x", "--apply"]).command,
        Command::Set(SetCmd::Sub(SetSubCmd::Remove {
            url: "https://x".to_owned(),
            purge: false,
            apply: true,
            dry_run: false,
        }))
    );
    assert_eq!(
        parse(&["set", "sub", "enable", "https://x", "--apply"]).command,
        Command::Set(SetCmd::Sub(SetSubCmd::Enable {
            url: "https://x".to_owned(),
            apply: true,
            dry_run: false,
        }))
    );
    assert_eq!(
        parse(&["set", "sub", "disable", "https://x", "--apply"]).command,
        Command::Set(SetCmd::Sub(SetSubCmd::Disable {
            url: "https://x".to_owned(),
            apply: true,
            dry_run: false,
        }))
    );
    assert_eq!(
        parse(&["set", "sub", "import", "/tmp/u", "--clipboard", "--apply"]).command,
        Command::Set(SetCmd::Sub(SetSubCmd::Import {
            path: Some(PathBuf::from("/tmp/u")),
            clipboard: true,
            apply: true,
            dry_run: false,
        }))
    );
}

#[test]
fn set_profile_parses_seven_leaves() {
    assert_eq!(
        parse(&["set", "profile", "add", "team", "remote:https://x"]).command,
        Command::Set(SetCmd::Profile(SetProfileCmd::Add {
            id: "team".to_owned(),
            source: "remote:https://x".to_owned(),
            apply: false,
            dry_run: false,
        }))
    );
    assert_eq!(
        parse(&["set", "profile", "remove", "team", "--apply"]).command,
        Command::Set(SetCmd::Profile(SetProfileCmd::Remove {
            id: "team".to_owned(),
            apply: true,
            dry_run: false,
        }))
    );
    // New Round 11: edit / export / enable / disable
    assert_eq!(
        parse(&["set", "profile", "edit", "team", "--apply"]).command,
        Command::Set(SetCmd::Profile(SetProfileCmd::Edit {
            id: "team".to_owned(),
            apply: true,
            dry_run: false,
        }))
    );
    assert_eq!(
        parse(&["set", "profile", "export", "team", "--out", "/tmp/p.yaml"]).command,
        Command::Set(SetCmd::Profile(SetProfileCmd::Export {
            id: "team".to_owned(),
            out: PathBuf::from("/tmp/p.yaml"),
        }))
    );
    assert_eq!(
        parse(&["set", "profile", "enable", "team", "--apply"]).command,
        Command::Set(SetCmd::Profile(SetProfileCmd::Enable {
            id: "team".to_owned(),
            apply: true,
            dry_run: false,
        }))
    );
    assert_eq!(
        parse(&["set", "profile", "disable", "team", "--apply"]).command,
        Command::Set(SetCmd::Profile(SetProfileCmd::Disable {
            id: "team".to_owned(),
            apply: true,
            dry_run: false,
        }))
    );
    // Refresh stays (was Round 10); now under `set` namespace.
    // Round 12: refresh always writes (the body IS the cache),
    // so `--apply` / `--dry-run` flags are not accepted.
    assert_eq!(
        parse(&["set", "profile", "refresh"]).command,
        Command::Set(SetCmd::Profile(SetProfileCmd::Refresh { id: None }))
    );
    assert_eq!(
        parse(&["set", "profile", "refresh", "team"]).command,
        Command::Set(SetCmd::Profile(SetProfileCmd::Refresh {
            id: Some("team".to_owned())
        }))
    );
}

#[test]
fn set_profile_refresh_rejects_apply_and_dry_run_flags() {
    // Round 12: refresh always writes. A `--apply` / `--dry-run`
    // flag is rejected at parse time, not silently coerced
    // (the previous behavior was a no-op that confused
    // operators about whether a refresh actually wrote).
    for removed in [
        vec!["set", "profile", "refresh", "--apply"],
        vec!["set", "profile", "refresh", "--dry-run"],
        vec!["set", "profile", "refresh", "team", "--apply"],
    ] {
        let result = parse_args(removed.iter().map(|s| (*s).to_owned()));
        assert!(
            result.is_err(),
            "expected refresh flag to be rejected: {removed:?}"
        );
    }
}

#[test]
fn set_config_parses_six_leaves_including_diff() {
    assert_eq!(
        parse(&["set", "config", "apply"]).command,
        Command::Set(SetCmd::Config(SetConfigCmd::Apply))
    );
    assert_eq!(
        parse(&["set", "config", "generate"]).command,
        Command::Set(SetCmd::Config(SetConfigCmd::Generate))
    );
    assert_eq!(
        parse(&["set", "config", "default"]).command,
        Command::Set(SetCmd::Config(SetConfigCmd::Default))
    );
    // New Round 11 capability: `set config diff`
    assert_eq!(
        parse(&["set", "config", "diff"]).command,
        Command::Set(SetCmd::Config(SetConfigCmd::Diff { file: None }))
    );
    assert_eq!(
        parse(&["set", "config", "diff", "--file", "/tmp/c.yaml"]).command,
        Command::Set(SetCmd::Config(SetConfigCmd::Diff {
            file: Some(PathBuf::from("/tmp/c.yaml")),
        }))
    );
    assert_eq!(
        parse(&["set", "config", "edit", "vim"]).command,
        Command::Set(SetCmd::Config(SetConfigCmd::Edit(Editor::Vim)))
    );
    assert_eq!(
        parse(&["set", "config", "edit", "nvim"]).command,
        Command::Set(SetCmd::Config(SetConfigCmd::Edit(Editor::Nvim)))
    );
}

#[test]
fn set_daemon_parses_four_lifecycle_leaves() {
    // New Round 11 capability: `set daemon stop/reload/restart/status`
    assert_eq!(
        parse(&["set", "daemon", "stop"]).command,
        Command::Set(SetCmd::Daemon(SetDaemonCmd::Stop))
    );
    assert_eq!(
        parse(&["set", "daemon", "reload"]).command,
        Command::Set(SetCmd::Daemon(SetDaemonCmd::Reload))
    );
    assert_eq!(
        parse(&["set", "daemon", "restart"]).command,
        Command::Set(SetCmd::Daemon(SetDaemonCmd::Restart))
    );
    // W1-β (C-J): the v1 leaf delegated to the health snapshot;
    // the alias preserves that exactly via `status --verbose`.
    assert_eq!(
        parse(&["set", "daemon", "status"]).command,
        Command::Show(ShowCmd::Core(ShowCoreCmd::Health))
    );
}

#[test]
fn set_rule_provider_parses_six_leaves() {
    // Round 12: declarative CRUD for `rule_providers:`. The
    // grammar uses three sub-commands (`add-http` /
    // `add-file` / `add-inline`) so each source kind has its
    // own typed argument shape (no `kind <KIND> <body>` slot).
    use crate::cli::RuleProviderSourceSpec;
    assert_eq!(
        parse(&[
            "set",
            "rule-provider",
            "add-http",
            "geosite-cn",
            "https://x/y"
        ])
        .command,
        Command::Set(SetCmd::RuleProvider(SetRuleProviderCmd::Add {
            name: "geosite-cn".to_owned(),
            source: RuleProviderSourceSpec::Http {
                url: "https://x/y".to_owned(),
                interval_ms: 86_400_000
            },
            apply: false,
            dry_run: false,
        }))
    );
    assert_eq!(
        parse(&["set", "rule-provider", "add-file", "adblock", "/etc/r.yaml"]).command,
        Command::Set(SetCmd::RuleProvider(SetRuleProviderCmd::Add {
            name: "adblock".to_owned(),
            source: RuleProviderSourceSpec::File {
                path: PathBuf::from("/etc/r.yaml")
            },
            apply: false,
            dry_run: false,
        }))
    );
    assert_eq!(
        parse(&[
            "set",
            "rule-provider",
            "add-inline",
            "small",
            "--payload",
            "a\nb"
        ])
        .command,
        Command::Set(SetCmd::RuleProvider(SetRuleProviderCmd::Add {
            name: "small".to_owned(),
            source: RuleProviderSourceSpec::Inline {
                payload: "a\nb".to_owned()
            },
            apply: false,
            dry_run: false,
        }))
    );
    assert_eq!(
        parse(&["set", "rule-provider", "remove", "geosite-cn"]).command,
        Command::Set(SetCmd::RuleProvider(SetRuleProviderCmd::Remove {
            name: "geosite-cn".to_owned(),
            apply: false,
            dry_run: false
        }))
    );
    assert_eq!(
        parse(&["set", "rule-provider", "enable", "geosite-cn"]).command,
        Command::Set(SetCmd::RuleProvider(SetRuleProviderCmd::Enable {
            name: "geosite-cn".to_owned(),
            apply: false,
            dry_run: false
        }))
    );
    assert_eq!(
        parse(&["set", "rule-provider", "disable", "geosite-cn"]).command,
        Command::Set(SetCmd::RuleProvider(SetRuleProviderCmd::Disable {
            name: "geosite-cn".to_owned(),
            apply: false,
            dry_run: false
        }))
    );
    assert_eq!(
        parse(&["set", "rule-provider", "refresh"]).command,
        Command::Set(SetCmd::RuleProvider(SetRuleProviderCmd::Refresh {
            name: None
        }))
    );
    assert_eq!(
        parse(&["set", "rule-provider", "refresh", "geosite-cn"]).command,
        Command::Set(SetCmd::RuleProvider(SetRuleProviderCmd::Refresh {
            name: Some("geosite-cn".to_owned())
        }))
    );
    assert_eq!(
        parse(&["set", "rule-provider", "list"]).command,
        Command::Set(SetCmd::RuleProvider(SetRuleProviderCmd::List))
    );
}

#[test]
fn set_rule_provider_dry_run_policy_matches_sibling_resources() {
    // The CRUD leaves take the same `--apply` / `--dry-run`
    // policy as the other `set` resources: default dry-run,
    // `--apply` writes, the two flags are mutually exclusive.
    for args in [
        vec![
            "set",
            "rule-provider",
            "add-http",
            "n",
            "https://x",
            "--apply",
        ],
        vec!["set", "rule-provider", "add-file", "n", "/etc/r", "--apply"],
        vec![
            "set",
            "rule-provider",
            "add-inline",
            "n",
            "--payload",
            "x",
            "--apply",
        ],
        vec!["set", "rule-provider", "remove", "n", "--apply"],
        vec!["set", "rule-provider", "enable", "n", "--apply"],
        vec!["set", "rule-provider", "disable", "n", "--apply"],
    ] {
        let result = parse_args(args.iter().map(|s| (*s).to_owned()));
        assert!(
            result.is_ok(),
            "expected apply leaf to parse: {args:?} -> {result:?}"
        );
    }
    for args in [
        vec![
            "set",
            "rule-provider",
            "remove",
            "n",
            "--apply",
            "--dry-run",
        ],
        vec![
            "set",
            "rule-provider",
            "add-http",
            "n",
            "https://x",
            "--apply",
            "--dry-run",
        ],
    ] {
        let result = parse_args(args.iter().map(|s| (*s).to_owned()));
        assert!(
            result.is_err(),
            "expected conflict to be rejected: {args:?}"
        );
    }
}

#[test]
fn set_rule_provider_refresh_rejects_apply_and_dry_run_flags() {
    // Like `set profile refresh`, this leaf always writes.
    // A `--apply` / `--dry-run` flag is rejected at parse time.
    for removed in [
        vec!["set", "rule-provider", "refresh", "--apply"],
        vec!["set", "rule-provider", "refresh", "--dry-run"],
    ] {
        let result = parse_args(removed.iter().map(|s| (*s).to_owned()));
        assert!(
            result.is_err(),
            "expected refresh flag to be rejected: {removed:?}"
        );
    }
}
