use super::*;

// ── set proxy-group (Round 20) ─────────────────────────────────

#[test]
fn set_proxy_group_parses_six_leaves() {
    use crate::cli::{ProxyGroupMemberSpec, ProxyGroupTypeSpec};
    // `add` with no members parses to an empty members list;
    // the writer rejects a `select` group with zero members
    // at the schema layer.
    assert_eq!(
        parse(&["set", "proxy-group", "add", "Proxy", "--type", "select"]).command,
        Command::Set(SetCmd::ProxyGroup(SetProxyGroupCmd::Add {
            name: "Proxy".to_owned(),
            group_type: ProxyGroupTypeSpec::Select,
            members: Ok(Vec::new()),
            url: None,
            interval_seconds: None,
            tolerance_ms: None,
            apply: false,
            dry_run: false,
        }))
    );
    // `add` with comma-separated `kind:value` members.
    assert_eq!(
        parse(&[
            "set",
            "proxy-group",
            "add",
            "Auto",
            "--type",
            "url-test",
            "--members",
            "node:hk-1,group:Proxy,direct,reject",
            "--url",
            "http://www.gstatic.com/generate_204",
            "--interval-seconds",
            "300",
            "--tolerance-ms",
            "50",
        ])
        .command,
        Command::Set(SetCmd::ProxyGroup(SetProxyGroupCmd::Add {
            name: "Auto".to_owned(),
            group_type: ProxyGroupTypeSpec::UrlTest,
            members: Ok(vec![
                ProxyGroupMemberSpec::Node {
                    tag: "hk-1".to_owned()
                },
                ProxyGroupMemberSpec::Group {
                    name: "Proxy".to_owned()
                },
                ProxyGroupMemberSpec::Direct,
                ProxyGroupMemberSpec::Reject,
            ]),
            url: Some("http://www.gstatic.com/generate_204".to_owned()),
            interval_seconds: Some(300),
            tolerance_ms: Some(50),
            apply: false,
            dry_run: false,
        }))
    );
    // W1-β (C-M): the proxy-group lifecycle leaves rewrite onto
    // the same `node …` Entry seam as the node ones.
    assert_eq!(
        parse(&["set", "proxy-group", "remove", "Proxy"]).command,
        Command::Set(SetCmd::Entry(EntryWriteCmd::Remove {
            id: "Proxy".to_owned(),
            apply: false,
            dry_run: false,
        }))
    );
    assert_eq!(
        parse(&["set", "proxy-group", "enable", "Proxy"]).command,
        Command::Set(SetCmd::Entry(EntryWriteCmd::Enable {
            id: "Proxy".to_owned(),
            apply: false,
            dry_run: false,
        }))
    );
    assert_eq!(
        parse(&["set", "proxy-group", "disable", "Proxy"]).command,
        Command::Set(SetCmd::Entry(EntryWriteCmd::Disable {
            id: "Proxy".to_owned(),
            apply: false,
            dry_run: false,
        }))
    );
    assert_eq!(
        parse(&["set", "proxy-group", "list"]).command,
        Command::Set(SetCmd::ProxyGroup(SetProxyGroupCmd::List {
            enabled_only: false
        }))
    );
    // `--enabled-only` parses to `List { enabled_only: true }` so the
    // dispatcher's `list(paths, true, output)` filters the in-memory
    // projection. The flag default (`false`) keeps the
    // pre-Round 31 behaviour (`list` shows every declared group).
    assert_eq!(
        parse(&["set", "proxy-group", "list", "--enabled-only"]).command,
        Command::Set(SetCmd::ProxyGroup(SetProxyGroupCmd::List {
            enabled_only: true
        }))
    );
}

#[test]
fn set_proxy_group_dry_run_policy_matches_sibling_resources() {
    // The CRUD leaves take the same `--apply` / `--dry-run`
    // policy as the other `set` resources: default dry-run,
    // `--apply` writes, the two flags are mutually exclusive.
    for args in [
        vec![
            "set",
            "proxy-group",
            "add",
            "n",
            "--type",
            "select",
            "--apply",
        ],
        vec!["set", "proxy-group", "remove", "n", "--apply"],
        vec!["set", "proxy-group", "enable", "n", "--apply"],
        vec!["set", "proxy-group", "disable", "n", "--apply"],
    ] {
        let result = parse_args(args.iter().map(|s| (*s).to_owned()));
        assert!(
            result.is_ok(),
            "expected parse to succeed: {args:?} got {result:?}"
        );
    }
    // The `--apply` / `--dry-run` flags are mutually exclusive
    // (clap enforces it).
    let result = parse_args(
        [
            "set",
            "proxy-group",
            "add",
            "n",
            "--type",
            "select",
            "--apply",
            "--dry-run",
        ]
        .iter()
        .map(|s| (*s).to_owned()),
    );
    assert!(result.is_err(), "expected mutual exclusion: {result:?}");
}

#[test]
fn set_proxy_group_add_rejects_unknown_type() {
    // clap's ValueEnum rejects unknown `--type` values
    // before the dispatch ever runs.
    let result = parse_args(
        ["set", "proxy-group", "add", "n", "--type", "round-robin"]
            .iter()
            .map(|s| (*s).to_owned()),
    );
    assert!(result.is_err(), "expected unknown type to be rejected");
}

#[test]
fn set_proxy_group_add_rejects_unknown_member_kinds() {
    assert_rejected_member_spellings();
    assert_accepted_member_spellings();
}

fn assert_rejected_member_spellings() {
    for removed in [
        vec![
            "set",
            "proxy-group",
            "add",
            "n",
            "--type",
            "select",
            "--members",
            "ndoe:hk-1",
        ],
        vec![
            "set",
            "proxy-group",
            "add",
            "n",
            "--type",
            "select",
            "--members",
            "rejct",
        ],
        vec![
            "set",
            "proxy-group",
            "add",
            "n",
            "--type",
            "select",
            "--members",
            "grop:Auto",
        ],
    ] {
        let result = parse_args(removed.iter().map(|s| (*s).to_owned()));
        assert!(
            result.is_err(),
            "expected unknown member to be rejected: {removed:?} got {result:?}"
        );
    }
}

fn assert_accepted_member_spellings() {
    for accepted in [
        vec![
            "set",
            "proxy-group",
            "add",
            "n",
            "--type",
            "select",
            "--members",
            "node:hk-1",
        ],
        vec![
            "set",
            "proxy-group",
            "add",
            "n",
            "--type",
            "select",
            "--members",
            "group:Auto",
        ],
        vec![
            "set",
            "proxy-group",
            "add",
            "n",
            "--type",
            "select",
            "--members",
            "direct",
        ],
        vec![
            "set",
            "proxy-group",
            "add",
            "n",
            "--type",
            "select",
            "--members",
            "reject",
        ],
    ] {
        let result = parse_args(accepted.iter().map(|s| (*s).to_owned()));
        assert!(
            result.is_ok(),
            "expected known member to parse: {accepted:?} got {result:?}"
        );
    }
}
