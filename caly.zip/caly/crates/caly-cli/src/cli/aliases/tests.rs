//! Tests for `cli/aliases.rs`, extracted to the child
//! convention file (audit #70 file-length budget).

use super::*;


fn strings(tokens: &[&str]) -> Vec<String> {
    tokens.iter().map(|token| (*token).to_owned()).collect()
}

#[test]
fn empty_tables_are_identity() {
    for argv in [
        &["node", "list"][..],
        &["--json", "status"],
        &["--socket", "/tmp/x.sock", "daemon"],
        &["--socket=/tmp/x.sock", "node", "select", "hk-01"],
        &[],
    ] {
        let expansion = expand_with(strings(argv), &[], &[], &[]);
        assert_eq!(expansion.argv, strings(argv));
        assert!(expansion.notices.is_empty());
    }
}

#[test]
fn canonical_v3_heads_pass_through_untouched() {
    // Heads that are already v3 must never be rewritten (and
    // never emit notices).
    for argv in [
        &["node", "list"][..],
        &["status", "--verbose"],
        &[
            "node",
            "add",
            "--type",
            "urltest",
            "--name",
            "g",
            "--members",
            "direct",
        ],
        &["sub", "parse", "f.yaml"],
        &["config", "diff"],
        &["connections", "close"],
    ] {
        let expansion = expand(strings(argv));
        assert_eq!(expansion.argv, strings(argv), "rewrote canonical {argv:?}");
        assert!(expansion.notices.is_empty());
    }
}

#[test]
fn global_flags_ride_before_a_rewritten_head() {
    let deprecated: &[Rule] = &[(&["show", "status"], &["status"])];
    let expansion = expand_with(
        strings(&["--json", "--socket", "/x", "show", "status"]),
        deprecated,
        &[],
        &[],
    );
    assert_eq!(
        expansion.argv,
        strings(&["--json", "--socket", "/x", "status"])
    );
    assert_eq!(expansion.notices.len(), 1);
    assert!(expansion.notices[0].contains("show status"));
    assert!(expansion.notices[0].contains("caly status"));
}

#[test]
fn equals_form_global_flag_still_finds_the_head() {
    let deprecated: &[Rule] = &[(&["show", "status"], &["status"])];
    let expansion = expand_with(
        strings(&["--socket=/x", "show", "status"]),
        deprecated,
        &[],
        &[],
    );
    assert_eq!(expansion.argv, strings(&["--socket=/x", "status"]));
}

#[test]
fn unknown_dash_token_or_double_dash_blocks_expansion() {
    let deprecated: &[Rule] = &[(&["show", "status"], &["status"])];
    for argv in [&["--foo", "show", "status"][..], &["--", "show", "status"]] {
        let expansion = expand_with(strings(argv), deprecated, &[], &[]);
        assert_eq!(expansion.argv, strings(argv));
        assert!(expansion.notices.is_empty());
    }
}

#[test]
fn longest_prefix_wins() {
    let shortcuts: &[Rule] = &[
        (&["show"], &["display"]),
        (&["show", "sub", "parse"], &["sub", "parse"]),
    ];
    let expansion = expand_with(
        strings(&["show", "sub", "parse", "f.yaml"]),
        &[],
        shortcuts,
        &[],
    );
    assert_eq!(expansion.argv, strings(&["sub", "parse", "f.yaml"]));
}

#[test]
fn rewrite_chains_are_depth_limited() {
    // Pathological cyclic table: a→b, b→a. Must terminate with
    // one of the two heads, never hang.
    let shortcuts: &[Rule] = &[(&["a"], &["b"]), (&["b"], &["a"])];
    let expansion = expand_with(strings(&["a", "x"]), &[], shortcuts, &[]);
    assert_eq!(expansion.argv.len(), 2);
    assert!(expansion.argv[0] == "a" || expansion.argv[0] == "b");
}

#[test]
fn shortcut_expansion_keeps_arguments() {
    let shortcuts: &[Rule] = &[(&["n"], &["node"]), (&["n", "s"], &["node", "select"])];
    let expansion = expand_with(strings(&["n", "s", "hk-01"]), &[], shortcuts, &[]);
    assert_eq!(expansion.argv, strings(&["node", "select", "hk-01"]));
    assert!(expansion.notices.is_empty());
}

#[test]
fn user_aliases_join_the_expansion_and_win_ties() {
    // User table (cli-v3-design.md §9.2) participates in the same
    // loop; equal-prefix ties go to the user table.
    let user: &[(Vec<String>, Vec<String>)] = &[(
        vec!["gg".to_owned()],
        vec!["node".to_owned(), "list".to_owned()],
    )];
    let expansion = expand_with_user(strings(&["gg", "--offline"]), user);
    assert_eq!(expansion.argv, strings(&["node", "list", "--offline"]));
    // A user alias whose target is itself a user alias chains
    // through the same depth-limited loop.
    let chained: &[(Vec<String>, Vec<String>)] = &[
        (vec!["a".to_owned()], vec!["b".to_owned()]),
        (vec!["b".to_owned()], vec!["status".to_owned()]),
    ];
    let expansion = expand_with_user(strings(&["a"]), chained);
    assert_eq!(expansion.argv, strings(&["status"]));
    // Cyclic user aliases terminate (depth limit), never hang.
    let cyclic: &[(Vec<String>, Vec<String>)] = &[
        (vec!["x".to_owned()], vec!["y".to_owned()]),
        (vec!["y".to_owned()], vec!["x".to_owned()]),
    ];
    let expansion = expand_with_user(strings(&["x"]), cyclic);
    assert!(expansion.argv[0] == "x" || expansion.argv[0] == "y");
}

#[test]
fn user_alias_shadows_builtin_shortcut_on_equal_prefix() {
    // `t` is the built-in tree shortcut; a user alias named `t`
    // must win (customization value), without a deprecation notice.
    let user: &[(Vec<String>, Vec<String>)] =
        &[(vec!["t".to_owned()], vec!["status".to_owned()])];
    let expansion = expand_with_user(strings(&["t"]), user);
    assert_eq!(expansion.argv, strings(&["status"]));
    assert!(expansion.notices.is_empty(), "user aliases carry no notice");
}

#[test]
fn deprecated_chain_collects_each_notice() {
    let deprecated: &[Rule] = &[
        (&["show", "core"], &["core-state"]),
        (&["core-state"], &["status"]),
    ];
    let expansion = expand_with(strings(&["show", "core", "nodes"]), deprecated, &[], &[]);
    assert_eq!(expansion.argv, strings(&["status", "nodes"]));
    assert_eq!(expansion.notices.len(), 2);
}

#[test]
fn unknown_command_passes_through_for_clap_to_reject() {
    let expansion = expand(strings(&["frobnicate", "--widget"]));
    assert_eq!(expansion.argv, strings(&["frobnicate", "--widget"]));
    assert!(expansion.notices.is_empty());
}

// ── W1-β: built-in table integrity (D12) ────────────────────

#[test]
fn builtin_tables_have_no_duplicate_prefixes() {
    // Extension rows (`n` and `n s`) are legal — longest match
    // is deterministic. Duplicate `from` prefixes (same table
    // or across tables) are not: one of the pair is dead.
    let all: Vec<&[&str]> = SHORTCUTS
        .iter()
        .chain(DEPRECATED)
        .map(|(from, _)| *from)
        .collect();
    for (index, from) in all.iter().enumerate() {
        assert!(!from.is_empty(), "empty from prefix at #{index}");
        for other in all.iter().skip(index + 1) {
            assert_ne!(
                from, other,
                "duplicate rule prefix {from:?} (one rule can never fire)",
            );
        }
    }
}

#[test]
fn builtin_rule_targets_start_with_builtin_heads() {
    for (from, to) in SHORTCUTS.iter().chain(DEPRECATED) {
        assert!(
            BUILTIN_HEADS.contains(&to[0]),
            "rule {from:?} → {to:?}: head `{}` is not a built-in v3 command",
            to[0],
        );
        assert_ne!(from, to, "fixed-point rule {from:?} shadows nothing");
    }
}

#[test]
fn shortcut_heads_do_not_collide_with_builtin_heads() {
    for (from, _) in SHORTCUTS {
        assert!(
            !BUILTIN_HEADS.contains(&from[0]),
            "shortcut `{from:?}` collides with a built-in command head",
        );
    }
}

#[test]
fn deprecated_notices_name_both_paths() {
    let expansion = expand(strings(&["show", "sub", "parse", "f.yaml"]));
    assert_eq!(expansion.argv, strings(&["sub", "parse", "f.yaml"]));
    assert_eq!(expansion.notices.len(), 1);
    assert!(expansion.notices[0].contains("[deprecated]"));
    assert!(expansion.notices[0].contains("show sub parse"));
    assert!(expansion.notices[0].contains("caly sub parse"));
}

#[test]
fn typed_keeps_the_original_spelling_for_r1_backlink() {
    let expansion = expand(strings(&["st"]));
    assert_eq!(expansion.typed, strings(&["st"]));
    assert_eq!(expansion.argv, strings(&["status"]));
    // Pass-through input keeps typed == argv, so parse_args
    // prints no back-link note for un-rewritten spellings.
    let plain = expand(strings(&["node", "list"]));
    assert_eq!(plain.typed, plain.argv);
}
