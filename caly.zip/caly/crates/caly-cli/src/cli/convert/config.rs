//! Config command conversion.

use super::super::grammar::{
    ClapConfigCmd,
    Editor as ClapEditor,
};
use super::super::{
    Command,
    Editor,
    SetCmd,
    SetConfigCmd,
    ShowCmd,
    ShowConfigCmd,
};
pub(crate) fn config_command(command: Option<ClapConfigCmd>) -> Command {
    let Some(command) = command else {
        // Bare `caly config` = the files overview (C-I extension).
        return Command::Show(ShowCmd::Config(ShowConfigCmd::Files));
    };
    match command {
        ClapConfigCmd::Show | ClapConfigCmd::Files => {
            Command::Show(ShowCmd::Config(ShowConfigCmd::Files))
        }
        ClapConfigCmd::Path => Command::Show(ShowCmd::Config(ShowConfigCmd::Path)),
        ClapConfigCmd::Validate { file } => {
            Command::Show(ShowCmd::Config(ShowConfigCmd::Validate { file }))
        }
        ClapConfigCmd::Apply => Command::Set(SetCmd::Config(SetConfigCmd::Apply)),
        ClapConfigCmd::Generate => Command::Set(SetCmd::Config(SetConfigCmd::Generate)),
        ClapConfigCmd::Default => Command::Set(SetCmd::Config(SetConfigCmd::Default)),
        ClapConfigCmd::Diff { file } => Command::Set(SetCmd::Config(SetConfigCmd::Diff { file })),
        ClapConfigCmd::Edit { editor } => {
            Command::Set(SetCmd::Config(SetConfigCmd::Edit(match editor {
                ClapEditor::Vim => Editor::Vim,
                ClapEditor::Nvim => Editor::Nvim,
            })))
        }
        ClapConfigCmd::Get { key } => Command::Show(ShowCmd::Config(ShowConfigCmd::Get { key })),
        ClapConfigCmd::Set { key, value, apply } => {
            Command::Set(SetCmd::Config(SetConfigCmd::Set { key, value, apply }))
        }
    }
}

// ── remaining From impls ────────────────────────────────────────
