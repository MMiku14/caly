//! Subscription command conversion.

use super::super::grammar::{
    ClapSubCmd,
};
use super::super::{
    Command,
    SetCmd,
    SetSubCmd,
    ShowCmd,
    ShowSubCmd,
};
pub(crate) fn sub_command(command: Option<ClapSubCmd>) -> Command {
    let Some(command) = command else {
        return Command::Show(ShowCmd::Sub(ShowSubCmd::Providers));
    };
    match command {
        ClapSubCmd::List => Command::Show(ShowCmd::Sub(ShowSubCmd::Providers)),
        ClapSubCmd::Parse {
            path,
            userinfo,
            apply,
            name,
        } => Command::Show(ShowCmd::Sub(ShowSubCmd::Parse {
            path,
            userinfo,
            apply,
            name,
        })),
        ClapSubCmd::Add {
            url,
            name,
            every,
            apply,
            dry_run,
        } => Command::Set(SetCmd::Sub(SetSubCmd::Add {
            url,
            name,
            // Hours → minutes; the clap range cap (≤1_000_000h) keeps
            // this multiply far from u64 overflow.
            refresh_every_minutes: every.map(|hours| hours.saturating_mul(60)),
            apply,
            dry_run,
        })),
        ClapSubCmd::Refresh {
            target,
            force,
            asynchronous,
        } => Command::Set(SetCmd::Sub(SetSubCmd::Refresh {
            target,
            force,
            asynchronous,
        })),
        ClapSubCmd::Remove {
            url,
            purge,
            apply,
            dry_run,
        } => Command::Set(SetCmd::Sub(SetSubCmd::Remove {
            url,
            purge,
            apply,
            dry_run,
        })),
        ClapSubCmd::Set {
            target,
            url,
            name,
            every,
            apply,
            dry_run,
        } => Command::Set(SetCmd::Sub(SetSubCmd::Set {
            target,
            url,
            name,
            // Hours → minutes, same scale rule as `sub add` (Q5).
            refresh_every_minutes: every.map(|hours| hours.saturating_mul(60)),
            apply,
            dry_run,
        })),
        ClapSubCmd::Enable {
            url,
            apply,
            dry_run,
        } => Command::Set(SetCmd::Sub(SetSubCmd::Enable {
            url,
            apply,
            dry_run,
        })),
        ClapSubCmd::Disable {
            url,
            apply,
            dry_run,
        } => Command::Set(SetCmd::Sub(SetSubCmd::Disable {
            url,
            apply,
            dry_run,
        })),
        ClapSubCmd::Import {
            path,
            clipboard,
            apply,
            dry_run,
        } => Command::Set(SetCmd::Sub(SetSubCmd::Import {
            path,
            clipboard,
            apply,
            dry_run,
        })),
    }
}

// ── profile domain ──────────────────────────────────────────────
