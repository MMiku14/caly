//! Profile command conversion.

use super::super::grammar::{
    ClapProfileCmd,
};
use super::super::{
    Command,
    SetCmd,
    SetProfileCmd,
    ShowCmd,
    ShowProfileCmd,
};
pub(crate) fn profile_command(command: Option<ClapProfileCmd>) -> Command {
    let Some(command) = command else {
        return Command::Show(ShowCmd::Profile(ShowProfileCmd::List));
    };
    match command {
        ClapProfileCmd::List => Command::Show(ShowCmd::Profile(ShowProfileCmd::List)),
        ClapProfileCmd::Show { id } => Command::Show(ShowCmd::Profile(ShowProfileCmd::Show { id })),
        ClapProfileCmd::Use { id } => Command::Set(SetCmd::Profile(SetProfileCmd::Use { id })),
        ClapProfileCmd::Add {
            id,
            source,
            apply,
            dry_run,
        } => Command::Set(SetCmd::Profile(SetProfileCmd::Add {
            id,
            source,
            apply,
            dry_run,
        })),
        ClapProfileCmd::Remove { id, apply, dry_run } => {
            Command::Set(SetCmd::Profile(SetProfileCmd::Remove {
                id,
                apply,
                dry_run,
            }))
        }
        ClapProfileCmd::Edit { id, apply, dry_run } => {
            Command::Set(SetCmd::Profile(SetProfileCmd::Edit { id, apply, dry_run }))
        }
        ClapProfileCmd::Refresh { id } => {
            Command::Set(SetCmd::Profile(SetProfileCmd::Refresh { id }))
        }
        ClapProfileCmd::Export { id, out } => {
            Command::Set(SetCmd::Profile(SetProfileCmd::Export { id, out }))
        }
        ClapProfileCmd::Enable { id, apply, dry_run } => {
            Command::Set(SetCmd::Profile(SetProfileCmd::Enable {
                id,
                apply,
                dry_run,
            }))
        }
        ClapProfileCmd::Disable { id, apply, dry_run } => {
            Command::Set(SetCmd::Profile(SetProfileCmd::Disable {
                id,
                apply,
                dry_run,
            }))
        }
    }
}

// ── config domain ───────────────────────────────────────────────
