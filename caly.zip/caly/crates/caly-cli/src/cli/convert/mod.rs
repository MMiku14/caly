//! clap grammar → public command-model conversions.
//!
//! Split out of `cli.rs` (audit #70 file-length budget): one
//! mechanical `From<Clap*> for <public enum>` impl per command
//! enum, plus the `kind:value` member-token parser used by the
//! proxy-group grammar. The public enums themselves live in the
//! parent `cli` module.
//!
//! W1-β (cli-v3-design.md): the v3 resource-domain grammar maps
//! onto the SAME public command model the v1 handlers already
//! consume — this is the mechanical-routing seam. Notable
//! mappings:
//!
//! - bare `caly` → `Command::Daemon` (Q3);
//! - `status` / `status --verbose` → `Show(Status)` /
//!   `Show(Core(Health))` (C-J);
//! - `node list` → `Show(Core(Nodes))`; the transitional
//!   `node groups` leaf → `Show(Core(Groups))` (T-1);
//! - `node list --offline` → the offline `proxy_groups:`
//!   projection (W1 compromise; the unified offline entry tree
//!   arrives in W3a — C-K/C-O);
//! - `node add` dual form (C-P): URI positional →
//!   `Set(Proxy(Add))`; `--type` (+ positional/`--name` name
//!   slot) → `Set(ProxyGroup(Add))`;
//! - `node remove|enable|disable` → `Set(Entry(…))`, the C-M
//!   seam resolved by `commands::node_dispatch`;
//! - `mode` / `connections` / `rules` / `traffic` are get/set
//!   or read/write pairs split by optional argument/subcommand.

use super::grammar::{
    ClapCli,
    ClapCommand,
    ClapConnectionsCmd,
    ClapCoreCmd,
    ClapFlowCmd,
    ClapHistoryCmd,
    ClapOpCmd,
    ClapSetRuleProviderCmd,
    ClapSysproxyCmd,
    ClapToolCmd,
    ClapTunCmd,
    FormatFlag,
};
use super::{
    CliOptions,
    Command,
    HistoryCmd,
    Invocation,
    OpCmd,
    OutputFormat,
    RuleProviderSourceSpec,
    SetCmd,
    SetCoreCmd,
    SetDaemonCmd,
    SetProxyCmd,
    SetRuleProviderCmd,
    ShowCmd,
    ShowCoreCmd,
    ToolCmd,
};

mod config;
mod node;
mod profile;
mod sub;

impl From<FormatFlag> for OutputFormat {
    fn from(flag: FormatFlag) -> Self {
        match flag {
            FormatFlag::Table => Self::Table,
            FormatFlag::Tsv => Self::Tsv,
            FormatFlag::Tree => Self::Tree,
            FormatFlag::Diff => Self::Diff,
        }
    }
}

impl From<ClapCli> for Invocation {
    fn from(cli: ClapCli) -> Self {
        let options = CliOptions {
            socket: cli.global.socket,
            json: cli.global.json,
            core: cli.global.core.map(|v| v.as_str().to_owned()),
            mihomo_bin: cli.global.mihomo_bin,
            sing_box_bin: cli.global.sing_box_bin,
            format: cli.global.format.map(OutputFormat::from),
        };
        let command = match cli.command {
            // Q3: a bare `caly` runs the daemon foreground.
            None => Command::Daemon,
            Some(ClapCommand::Daemon) => Command::Daemon,
            Some(ClapCommand::Stop) => Command::Set(SetCmd::Daemon(SetDaemonCmd::Stop)),
            Some(ClapCommand::Reload) => Command::Set(SetCmd::Daemon(SetDaemonCmd::Reload)),
            Some(ClapCommand::Restart) => Command::Set(SetCmd::Daemon(SetDaemonCmd::Restart)),
            Some(ClapCommand::Status { verbose, watch }) => {
                if verbose && !watch {
                    Command::Show(ShowCmd::Core(ShowCoreCmd::Health))
                } else {
                    Command::Show(ShowCmd::Status { watch })
                }
            }
            Some(ClapCommand::Node { command }) => node::node_command(command),
            Some(ClapCommand::Sub { command }) => sub::sub_command(command),
            Some(ClapCommand::Profile { command }) => profile::profile_command(command),
            Some(ClapCommand::Config { command }) => config::config_command(command),
            Some(ClapCommand::Core { command }) => Command::Set(SetCmd::Core(command.into())),
            Some(ClapCommand::RuleProvider { command }) => {
                Command::Set(SetCmd::RuleProvider(command.into()))
            }
            Some(ClapCommand::Rules { r#match }) => {
                Command::Show(ShowCmd::Core(ShowCoreCmd::Rules { r#match }))
            }
            Some(ClapCommand::Connections { watch, command }) => match command {
                None => Command::Show(ShowCmd::Core(ShowCoreCmd::Connections { watch })),
                Some(ClapConnectionsCmd::Close { id }) => {
                    Command::Set(SetCmd::Core(SetCoreCmd::CloseConnections { id }))
                }
            },
            Some(ClapCommand::Flow { watch, command }) => match command {
                None => Command::Show(ShowCmd::Core(ShowCoreCmd::Flow { watch })),
                Some(ClapFlowCmd::Trace { id }) => {
                    Command::Show(ShowCmd::Core(ShowCoreCmd::FlowTrace { id, watch }))
                }
            },
            Some(ClapCommand::Traffic { watch }) => {
                Command::Show(ShowCmd::Core(ShowCoreCmd::Traffic { watch }))
            }
            Some(ClapCommand::Mode { mode }) => match mode {
                None => Command::Show(ShowCmd::Core(ShowCoreCmd::Mode)),
                Some(mode) => {
                    Command::Set(SetCmd::Core(SetCoreCmd::Mode(mode.as_str().to_owned())))
                }
            },
            Some(ClapCommand::Sysproxy { action }) => match action {
                ClapSysproxyCmd::On => Command::Set(SetCmd::Proxy(SetProxyCmd::On)),
                ClapSysproxyCmd::Off => Command::Set(SetCmd::Proxy(SetProxyCmd::Off)),
                ClapSysproxyCmd::Pac { url } => {
                    Command::Set(SetCmd::Proxy(SetProxyCmd::Pac { url }))
                }
                ClapSysproxyCmd::Status => Command::Show(ShowCmd::SysproxyStatus),
            },
            Some(ClapCommand::Tun { action }) => match action {
                ClapTunCmd::On => Command::Set(SetCmd::Tun(true)),
                ClapTunCmd::Off => Command::Set(SetCmd::Tun(false)),
                ClapTunCmd::Status => Command::Show(ShowCmd::TunStatus),
            },
            Some(ClapCommand::Dns { domain }) => Command::Tool(ToolCmd::Dns(domain)),
            Some(ClapCommand::Doctor { fix }) => Command::Tool(ToolCmd::Doctor { fix }),
            Some(ClapCommand::Tool { command }) => Command::Tool(command.into()),
            Some(ClapCommand::Tui) => Command::Tui,
            Some(ClapCommand::History { command }) => match command {
                None => Command::History(HistoryCmd::List { limit: None }),
                Some(ClapHistoryCmd::List { limit }) => {
                    Command::History(HistoryCmd::List { limit })
                }
                Some(ClapHistoryCmd::Replay { target }) => {
                    Command::History(HistoryCmd::Replay { target })
                }
                Some(ClapHistoryCmd::Clear) => Command::History(HistoryCmd::Clear),
            },
            Some(ClapCommand::Op { command }) => match command {
                None => Command::Op(OpCmd::List),
                Some(ClapOpCmd::List) => Command::Op(OpCmd::List),
                Some(ClapOpCmd::Status { id }) => Command::Op(OpCmd::Status { id }),
                Some(ClapOpCmd::Cancel { id }) => Command::Op(OpCmd::Cancel { id }),
            },
            Some(ClapCommand::Completions { shell }) => Command::Completions(shell),
        };
        Self { command, options }
    }
}

// ── node domain ─────────────────────────────────────────────────

impl From<ClapToolCmd> for ToolCmd {
    fn from(c: ClapToolCmd) -> Self {
        match c {
            ClapToolCmd::Help { command } => Self::Help(command),
            ClapToolCmd::Version => Self::Version,
        }
    }
}

impl From<ClapCoreCmd> for SetCoreCmd {
    fn from(c: ClapCoreCmd) -> Self {
        match c {
            ClapCoreCmd::Start => Self::Start,
            ClapCoreCmd::Stop => Self::Stop,
            ClapCoreCmd::Restart => Self::Restart,
            ClapCoreCmd::Switch { core } => Self::Switch(core.as_str().to_owned()),
            ClapCoreCmd::Versions => Self::Versions,
            ClapCoreCmd::Install { spec, force } => Self::Install { spec, force },
            ClapCoreCmd::Use { spec } => Self::Use { spec },
            ClapCoreCmd::Remove { spec, force } => Self::Remove { spec, force },
            ClapCoreCmd::Upgrade { kernel } => Self::Upgrade { kernel },
        }
    }
}

impl From<ClapSetRuleProviderCmd> for SetRuleProviderCmd {
    fn from(c: ClapSetRuleProviderCmd) -> Self {
        match c {
            ClapSetRuleProviderCmd::AddHttp {
                name,
                url,
                interval_ms,
                apply,
                dry_run,
            } => Self::Add {
                name,
                source: RuleProviderSourceSpec::Http { url, interval_ms },
                apply,
                dry_run,
            },
            ClapSetRuleProviderCmd::AddFile {
                name,
                path,
                apply,
                dry_run,
            } => Self::Add {
                name,
                source: RuleProviderSourceSpec::File { path },
                apply,
                dry_run,
            },
            ClapSetRuleProviderCmd::AddInline {
                name,
                payload,
                apply,
                dry_run,
            } => Self::Add {
                name,
                source: RuleProviderSourceSpec::Inline { payload },
                apply,
                dry_run,
            },
            ClapSetRuleProviderCmd::Remove {
                name,
                apply,
                dry_run,
            } => Self::Remove {
                name,
                apply,
                dry_run,
            },
            ClapSetRuleProviderCmd::Enable {
                name,
                apply,
                dry_run,
            } => Self::Enable {
                name,
                apply,
                dry_run,
            },
            ClapSetRuleProviderCmd::Disable {
                name,
                apply,
                dry_run,
            } => Self::Disable {
                name,
                apply,
                dry_run,
            },
            ClapSetRuleProviderCmd::Refresh { name } => Self::Refresh { name },
            ClapSetRuleProviderCmd::List => Self::List,
        }
    }
}

