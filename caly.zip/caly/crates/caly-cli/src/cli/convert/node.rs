//! Node command conversion (read/write/add leaves).

use super::super::grammar::{
    ClapNodeCmd,
};
use super::super::{
    Command,
    EntryWriteCmd,
    ProxyGroupMemberSpec,
    SetCmd,
    SetCoreCmd,
    SetProxyCmd,
    SetProxyGroupCmd,
    ShowCmd,
    ShowCoreCmd,
    ShowProxyCmd,
};
pub(crate) fn node_command(command: Option<ClapNodeCmd>) -> Command {
    let Some(command) = command else {
        // A bare `caly node` / `caly n` opens the interactive live
        // picker (node select without an argument); on a non-TTY it
        // degrades to the same usage error as `node select`.
        return Command::Set(SetCmd::Core(SetCoreCmd::Select {
            node: None,
            delay: false,
            poll: false,
        }));
    };
    match command {
        read @ (ClapNodeCmd::List { .. }
        | ClapNodeCmd::Groups
        | ClapNodeCmd::Inline
        | ClapNodeCmd::Show { .. }
        | ClapNodeCmd::Select { .. }
        | ClapNodeCmd::Ping { .. }
        | ClapNodeCmd::Test { .. }
        | ClapNodeCmd::Pick { .. }) => node_read_command(read),
        write @ (ClapNodeCmd::Add { .. }
        | ClapNodeCmd::Edit { .. }
        | ClapNodeCmd::Remove { .. }
        | ClapNodeCmd::Enable { .. }
        | ClapNodeCmd::Disable { .. }
        | ClapNodeCmd::Import { .. }) => node_write_command(write),
    }
}

/// Read-side `node` leaves: list/show plus select/ping/test/pick.
fn node_read_command(command: ClapNodeCmd) -> Command {
    match command {
        ClapNodeCmd::List { offline, enabled } => {
            if offline {
                Command::Set(SetCmd::ProxyGroup(SetProxyGroupCmd::List {
                    enabled_only: enabled,
                }))
            } else {
                Command::Show(ShowCmd::Core(ShowCoreCmd::Nodes))
            }
        }
        ClapNodeCmd::Groups => Command::Show(ShowCmd::Core(ShowCoreCmd::Groups)),
        ClapNodeCmd::Inline => Command::Show(ShowCmd::Proxy(ShowProxyCmd::List)),
        ClapNodeCmd::Show { id } => Command::Show(ShowCmd::Proxy(ShowProxyCmd::Show { id })),
        ClapNodeCmd::Select { node, delay, poll } => {
            Command::Set(SetCmd::Core(SetCoreCmd::Select { node, delay, poll }))
        }
        ClapNodeCmd::Ping {
            name,
            all,
            url,
            samples,
        } => Command::Set(SetCmd::Core(SetCoreCmd::Delay {
            name,
            all,
            url,
            samples,
        })),
        ClapNodeCmd::Test {
            name,
            url,
            samples,
            apply,
        } => Command::Set(SetCmd::Core(SetCoreCmd::UrlTest {
            name,
            url,
            samples,
            apply,
        })),
        ClapNodeCmd::Pick {
            group,
            member,
            apply,
            dry_run,
        } => Command::Set(SetCmd::Core(SetCoreCmd::Pick {
            group,
            member,
            apply,
            dry_run,
        })),
        write => node_write_command(write),
    }
}

/// Write-side `node` leaves: `add` resolves the dual URI/group form while
/// edit/remove/enable/disable/import map one-to-one onto their set leaves.
fn node_write_command(command: ClapNodeCmd) -> Command {
    match command {
        ClapNodeCmd::Add {
            value,
            group,
            r#type,
            name,
            members,
            url,
            interval_seconds,
            tolerance_ms,
            apply,
            dry_run,
        } => node_add(
            value,
            group,
            r#type,
            name,
            members,
            url,
            interval_seconds,
            tolerance_ms,
            apply,
            dry_run,
        ),
        ClapNodeCmd::Edit { id, apply, dry_run } => {
            Command::Set(SetCmd::Proxy(SetProxyCmd::Edit { id, apply, dry_run }))
        }
        // C-M seam S-W1-1: node vs group is resolved at dispatch.
        ClapNodeCmd::Remove { id, apply, dry_run } => {
            Command::Set(SetCmd::Entry(EntryWriteCmd::Remove { id, apply, dry_run }))
        }
        ClapNodeCmd::Enable { id, apply, dry_run } => {
            Command::Set(SetCmd::Entry(EntryWriteCmd::Enable { id, apply, dry_run }))
        }
        ClapNodeCmd::Disable { id, apply, dry_run } => {
            Command::Set(SetCmd::Entry(EntryWriteCmd::Disable { id, apply, dry_run }))
        }
        ClapNodeCmd::Import {
            path,
            apply,
            dry_run,
        } => Command::Set(SetCmd::Proxy(SetProxyCmd::Import {
            path,
            apply,
            dry_run,
        })),
        read => node_read_command(read),
    }
}

/// Dual-form `node add` (C-P). With `--type` the positional/name
/// slot is the group name and the probe flags apply; without it
/// the slot must be the node URI. The ArgGroup `target` makes the
/// slot clap-required either way (`--name` via `requires = "type"`
/// keeps the flag form legal).
fn node_add(
    value: Option<String>,
    group: Option<String>,
    r#type: Option<super::super::grammar::ProxyGroupKind>,
    name: Option<String>,
    members: Vec<String>,
    url: Option<String>,
    interval_seconds: Option<u32>,
    tolerance_ms: Option<u32>,
    apply: bool,
    dry_run: bool,
) -> Command {
    if let Some(kind) = r#type {
        // The ArgGroup guarantees one of the two slots; an empty
        // fallback here is unreachable in practice, and the schema
        // validator rejects an empty group name before any write.
        let group_name = name.or(value).unwrap_or_default();
        let parsed_members = members
            .into_iter()
            .map(parse_member_spec)
            .collect::<Result<Vec<_>, String>>()
            .map_err(|error| {
                format!(
                    "proxy-group member parse failed after clap accepted \
                     the token: {error} (clap's value_parser should have \
                     rejected it at parse time; please report this bug)"
                )
            });
        Command::Set(SetCmd::ProxyGroup(SetProxyGroupCmd::Add {
            name: group_name,
            group_type: kind.to_public(),
            members: parsed_members,
            url,
            interval_seconds,
            tolerance_ms,
            apply,
            dry_run,
        }))
    } else {
        let node_uri = value.or(name).unwrap_or_default();
        Command::Set(SetCmd::Proxy(SetProxyCmd::Add {
            uri: node_uri,
            group,
            apply,
            dry_run,
        }))
    }
}

// ── sub domain ──────────────────────────────────────────────────


/// Parses one `kind:value` member token into a
/// [`ProxyGroupMemberSpec`]. The grammar shape is
/// `node:<tag>`, `group:<name>`, `direct`, `reject`. An
/// unrecognised `kind:` is silently dropped at the
/// grammar level; the schema validator is the strict
/// path so a typo is caught before the kernel starts.
fn parse_member_spec(token: String) -> Result<ProxyGroupMemberSpec, String> {
    let token = token.trim();
    if token.is_empty() {
        return Err("empty member spec".to_owned());
    }
    if let Some((kind, value)) = token.split_once(':') {
        match kind {
            "node" => Ok(ProxyGroupMemberSpec::Node {
                tag: value.to_owned(),
            }),
            "group" => Ok(ProxyGroupMemberSpec::Group {
                name: value.to_owned(),
            }),
            other => Err(format!(
                "unknown member kind `{other}` (use `node:<tag>`, `group:<name>`, `direct`, or `reject`)"
            )),
        }
    } else {
        match token {
            "direct" => Ok(ProxyGroupMemberSpec::Direct),
            "reject" => Ok(ProxyGroupMemberSpec::Reject),
            other => Err(format!(
                "unknown member `{other}` (use `node:<tag>`, `group:<name>`, `direct`, or `reject`)"
            )),
        }
    }
}
