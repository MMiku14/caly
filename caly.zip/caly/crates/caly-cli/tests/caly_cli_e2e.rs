//! The `caly` CLI against the real `calyd`, both as built binaries (`ROADMAP §1bis.2`:
//! executables 1 → 2 — the daemon gets a client that is not the test harness).
//!
//! The ground truth for the happy path is this test's **own minimal wire reader**, not the
//! shared codec: two implementations agreeing is evidence about the wire, one implementation
//! round-tripping itself is not (`caly-ipc/src/wire.rs`'s header says the same thing).
//!
//! Locating `calyd` from the `caly` crate: `CARGO_BIN_EXE_*` only exists for same-crate bins,
//! so this test starts from its own binary's path — workspace builds put every member's bins
//! in the same target directory, which makes the sibling path deterministic, and the assert
//! says what to do if that ever stops being true.

// This file is a process-spawning integration harness: judging the `caly` CLI *is* spawning
// it (`Command::new`), waiting (`Instant::now`), and naming scratch paths (`PathBuf`). The
// workspace bans those symbols to keep the core pure (`ADR-011`); the lift is scoped to this
// file alone, matching `calyd_wire.rs`.
#![allow(clippy::disallowed_methods, clippy::disallowed_types)]

use std::io::{Read, Write};
use std::net::{TcpListener, TcpStream};
use std::path::PathBuf;
use std::process::{Command, Stdio};
use std::sync::atomic::{AtomicBool, Ordering};
use std::sync::Arc;
use std::time::{Duration, Instant};

fn calyd_binary() -> PathBuf {
    let own = PathBuf::from(env!("CARGO_BIN_EXE_caly"));
    let sibling = own
        .parent()
        .expect("the test binary lives in a directory")
        .join("calyd");
    assert!(
        sibling.exists(),
        "calyd should sit next to caly in the shared target dir ({}); if the layout changed, \
         teach this test the new address — do not skip the judge",
        sibling.display()
    );
    sibling
}

struct Daemon {
    child: std::process::Child,
    port: u16,
    data_dir: PathBuf,
}

impl Drop for Daemon {
    fn drop(&mut self) {
        let _ = self.child.kill();
        let _ = self.child.wait();
        let _ = std::fs::remove_dir_all(&self.data_dir);
    }
}

fn spawn_daemon(tag: &str) -> Daemon {
    spawn_daemon_with(tag, &[])
}

/// The `--source-endpoint` variant (round 114): the subscription-pipeline judges need a daemon
/// that registered an endpoint at startup, before any fetch.
fn spawn_daemon_with(tag: &str, extra_args: &[&str]) -> Daemon {
    let stamp = std::time::SystemTime::now()
        .duration_since(std::time::UNIX_EPOCH)
        .expect("clock")
        .as_millis();
    let data_dir =
        std::env::temp_dir().join(format!("caly-cli-e2e-{}-{stamp}-{tag}", std::process::id()));
    let port_file = data_dir.with_extension("port");
    std::fs::create_dir_all(&data_dir).expect("scratch");
    let child = Command::new(calyd_binary())
        .arg("--data-dir")
        .arg(&data_dir)
        .arg("--bind")
        .arg("127.0.0.1:0")
        .arg("--port-file")
        .arg(&port_file)
        .args(extra_args)
        .stdout(Stdio::null())
        .stderr(Stdio::null())
        .spawn()
        .expect("calyd must be built with the test run");
    let deadline = Instant::now() + Duration::from_secs(10);
    let port = loop {
        if let Ok(text) = std::fs::read_to_string(&port_file) {
            break text.trim().parse::<u16>().expect("port");
        }
        assert!(
            Instant::now() < deadline,
            "calyd did not report a port in 10s"
        );
        std::thread::sleep(Duration::from_millis(25));
    };
    Daemon {
        child,
        port,
        data_dir,
    }
}

/// This test's own minimal reader: an oracle independent of the shared codec.
fn oracle_status(port: u16) -> Vec<(String, String)> {
    let mut stream = TcpStream::connect(("127.0.0.1", port)).expect("daemon is listening");
    let hello = b"client_name=oracle\nrole=Admin\nmajor=1\nminor=0";
    let mut frame = vec![1u8];
    frame.extend_from_slice(&(hello.len() as u32).to_be_bytes());
    frame.extend_from_slice(hello);
    stream.write_all(&frame).expect("hello");
    let mut head = [0u8; 5];
    stream.read_exact(&mut head).expect("ack head");
    let mut ack = vec![0u8; u32::from_be_bytes([head[1], head[2], head[3], head[4]]) as usize];
    stream.read_exact(&mut ack).expect("ack body");
    assert_eq!(head[0], 2, "hello_ack");

    let request = b"request_id=41\ntrace_id=oracle\noperation=runtime.status";
    let mut frame = vec![3u8];
    frame.extend_from_slice(&(request.len() as u32).to_be_bytes());
    frame.extend_from_slice(request);
    stream.write_all(&frame).expect("request");
    stream.read_exact(&mut head).expect("response head");
    assert_eq!(head[0], 4, "response frame");
    let mut body = vec![0u8; u32::from_be_bytes([head[1], head[2], head[3], head[4]]) as usize];
    stream.read_exact(&mut body).expect("response body");
    String::from_utf8_lossy(&body)
        .lines()
        .filter_map(|line| {
            line.split_once('=')
                .map(|(k, v)| (k.to_owned(), v.to_owned()))
        })
        .collect()
}

/// One full oracle conversation: hello, one request (plus optional extra records, as
/// `profiles.get` needs), and the parsed response. The oracle speaks the documented wire by
/// hand and parses it independently — including value escaping, for the same reason the doctor
/// oracle does: an oracle that skips a documented transform flags a CLI that correctly did it.
fn oracle_conversation(port: u16, operation: &str, extra_records: &[u8]) -> Vec<(String, String)> {
    let unescape = |value: &str| -> String {
        let mut out = String::new();
        let mut rest = value;
        while let Some(at) = rest.find('%') {
            out.push_str(&rest[..at]);
            let tail = &rest[at + 1..];
            if let Some(next) = tail.strip_prefix("25") {
                out.push('%');
                rest = next;
            } else if let Some(next) = tail.strip_prefix("3D") {
                out.push('=');
                rest = next;
            } else if let Some(next) = tail.strip_prefix("0A") {
                out.push('\n');
                rest = next;
            } else {
                out.push('%');
                rest = tail;
            }
        }
        out.push_str(rest);
        out
    };
    let mut stream = TcpStream::connect(("127.0.0.1", port)).expect("daemon is listening");
    let hello = b"client_name=oracle\nrole=Admin\nmajor=1\nminor=0";
    let mut frame = vec![1u8];
    frame.extend_from_slice(&(hello.len() as u32).to_be_bytes());
    frame.extend_from_slice(hello);
    stream.write_all(&frame).expect("hello");
    let read_frame = |stream: &mut TcpStream| -> (u8, Vec<u8>) {
        let mut head = [0u8; 5];
        stream.read_exact(&mut head).expect("frame head");
        let mut body = vec![0u8; u32::from_be_bytes([head[1], head[2], head[3], head[4]]) as usize];
        stream.read_exact(&mut body).expect("frame body");
        (head[0], body)
    };
    let (kind, _ack) = read_frame(&mut stream);
    assert_eq!(kind, 2, "hello_ack");

    let mut request = format!("request_id=71\ntrace_id=oracle\noperation={operation}").into_bytes();
    if !extra_records.is_empty() {
        request.push(b'\n');
        request.extend_from_slice(extra_records);
    }
    let mut frame = vec![3u8];
    frame.extend_from_slice(&(request.len() as u32).to_be_bytes());
    frame.extend_from_slice(&request);
    stream.write_all(&frame).expect("request");
    let (kind, body) = read_frame(&mut stream);
    assert_eq!(
        kind,
        4,
        "response frame; refusal body: {}",
        String::from_utf8_lossy(&body)
    );
    String::from_utf8_lossy(&body)
        .lines()
        .filter_map(|line| {
            line.split_once('=')
                .map(|(k, v)| (k.to_owned(), unescape(v)))
        })
        .collect()
}

/// Round 53: acceptance means queued — the worker thread runs the job on its own tick, so a
/// judge that needs a terminal job waits until the daemon itself says so. The daemon's state
/// is the only clock that never lies here.
fn oracle_wait_terminal(port: u16, job_id: &str) -> String {
    let deadline = Instant::now() + Duration::from_secs(10);
    loop {
        let truth = oracle_conversation(port, "jobs.events", format!("job_id={job_id}").as_bytes());
        let state = truth
            .iter()
            .find(|(k, _)| k == "state")
            .map(|(_, v)| v.clone())
            .unwrap_or_default();
        if matches!(
            state.as_str(),
            "completed" | "failed" | "cancelled" | "timedout"
        ) {
            return state;
        }
        assert!(
            Instant::now() < deadline,
            "job {job_id} never reached a terminal state (last state: {state})"
        );
        std::thread::sleep(Duration::from_millis(25));
    }
}

#[cfg(unix)]
struct UnixDaemon {
    child: std::process::Child,
    path: String,
    data_dir: PathBuf,
}

#[cfg(unix)]
impl Drop for UnixDaemon {
    fn drop(&mut self) {
        let _ = self.child.kill();
        let _ = self.child.wait();
        let _ = std::fs::remove_file(&self.path);
        let _ = std::fs::remove_dir_all(&self.data_dir);
    }
}

#[cfg(unix)]
fn spawn_daemon_unix(tag: &str) -> UnixDaemon {
    let stamp = std::time::SystemTime::now()
        .duration_since(std::time::UNIX_EPOCH)
        .expect("clock")
        .as_millis();
    let data_dir =
        std::env::temp_dir().join(format!("caly-cli-uds-{}-{stamp}-{tag}", std::process::id()));
    let port_file = data_dir.with_extension("port");
    let sock = data_dir.with_extension("sock");
    std::fs::create_dir_all(&data_dir).expect("scratch");
    let child = Command::new(calyd_binary())
        .arg("--data-dir")
        .arg(&data_dir)
        .arg("--bind")
        .arg(format!("unix:{}", sock.display()))
        .arg("--port-file")
        .arg(&port_file)
        .stdout(Stdio::null())
        .stderr(Stdio::null())
        .spawn()
        .expect("calyd must be built with the test run");
    let deadline = Instant::now() + Duration::from_secs(10);
    let path = loop {
        if let Ok(text) = std::fs::read_to_string(&port_file) {
            let text = text.trim();
            let rest = text
                .strip_prefix("unix:")
                .unwrap_or_else(|| panic!("UDS port-file must be unix:<path>, got {text:?}"));
            break rest.to_owned();
        }
        assert!(
            Instant::now() < deadline,
            "calyd did not report a unix path in 10s"
        );
        std::thread::sleep(Duration::from_millis(25));
    };
    UnixDaemon {
        child,
        path,
        data_dir,
    }
}

fn run_cli(args: &[&str]) -> (i32, String, String) {
    let output = Command::new(env!("CARGO_BIN_EXE_caly"))
        .args(args)
        .output()
        .expect("caly must be built with the test run");
    (
        output.status.code().unwrap_or(-1),
        String::from_utf8_lossy(&output.stdout).into_owned(),
        String::from_utf8_lossy(&output.stderr).into_owned(),
    )
}

#[test]
fn caly_status_prints_what_the_wire_actually_says() {
    let daemon = spawn_daemon("happy");
    let address = format!("127.0.0.1:{}", daemon.port);
    let (code, stdout, stderr) = run_cli(&["status", "--addr", &address]);
    assert_eq!(code, 0, "success is exit 0; stderr: {stderr}");
    for key in [
        "core_running",
        "active_profile",
        "active_core",
        "active_snapshot",
        "last_apply_plan_summary",
        "pending_recovery_decisions",
        "last_recovery_summary",
        "last_failure",
    ] {
        assert!(
            stdout.contains(&format!("{key}: ")),
            "field {key} must be printed: {stdout}"
        );
    }
    // Ground truth: the oracle's own conversation with the same daemon must agree, value for
    // value, with what the CLI printed — a client that fabricates or drops values fails here.
    let truth = oracle_status(daemon.port);
    for (key, value) in &truth {
        if key == "request_id" {
            continue;
        }
        assert!(
            stdout.contains(&format!("{key}: {value}")),
            "{key} must be printed as the wire said ({value:?}): {stdout}"
        );
    }
}

#[test]
fn an_unreachable_daemon_is_exit_12_and_names_the_address() {
    let listener = TcpListener::bind("127.0.0.1:0").expect("bind");
    let port = listener.local_addr().expect("addr").port();
    drop(listener);
    let (code, stdout, stderr) = run_cli(&["status", "--addr", &format!("127.0.0.1:{port}")]);
    assert_eq!(
        code, 12,
        "UNAVAILABLE per docs/guides/EXIT_CODES.md; stdout: {stdout}"
    );
    assert!(
        stderr.contains(&format!("127.0.0.1:{port}")),
        "the refusal must name the address it could not reach: {stderr}"
    );
}

#[test]
fn missing_addr_is_a_usage_error_not_a_connection_attempt() {
    let (code, _stdout, stderr) = run_cli(&["status"]);
    assert_eq!(
        code, 2,
        "usage per docs/guides/EXIT_CODES.md; stderr: {stderr}"
    );
    assert!(stderr.contains("--addr"), "{stderr}");
}

/// A daemon that accepts and never speaks must not hang the client forever: the CLI times out
/// its reads and exits 11 (`TIMEOUT` per `docs/guides/EXIT_CODES.md`), naming the wait. Found by round 44's
/// own falsification — a mutant that skipped hello deadlocked with no timeout on either side.
#[test]
fn a_silent_daemon_times_out_as_exit_11_not_a_hang() {
    let listener = TcpListener::bind("127.0.0.1:0").expect("bind");
    let port = listener.local_addr().expect("addr").port();
    // Accept and hold the connection open, saying nothing, forever-ish.
    let _server = std::thread::spawn(move || {
        if let Ok((stream, _)) = listener.accept() {
            std::thread::sleep(Duration::from_secs(30));
            drop(stream);
        }
    });
    let started = Instant::now();
    let (code, _stdout, stderr) = run_cli(&["status", "--addr", &format!("127.0.0.1:{port}")]);
    assert!(
        started.elapsed() < Duration::from_secs(10),
        "the CLI must answer by itself, not wait for the server"
    );
    assert_eq!(
        code, 11,
        "TIMEOUT per docs/guides/EXIT_CODES.md; stderr: {stderr}"
    );
    assert!(
        stderr.contains("timed out"),
        "the failure must say it was a timeout: {stderr}"
    );
}

/// A peer that declares a length over `MAX_FRAME_SIZE_BYTES` must be refused by the
/// CLI **before** the payload is read. `Session::recv` used to claim the shared codec
/// did this while allocating `vec![0u8; len]` and blocking on the body. A fake daemon
/// that writes only the 5-byte over-cap head (plus a few dummy bytes, never the
/// declared length) distinguishes the two: the shared codec returns immediately; the
/// hand-roll waits out the 3s read timeout.
#[test]
fn an_over_cap_inbound_frame_is_refused_before_the_payload_is_read() {
    let listener = TcpListener::bind("127.0.0.1:0").expect("bind");
    let port = listener.local_addr().expect("addr").port();
    let _server = std::thread::spawn(move || {
        if let Ok((mut stream, _)) = listener.accept() {
            let mut head = [0u8; 5];
            if stream.read_exact(&mut head).is_err() {
                return;
            }
            let len = u32::from_be_bytes([head[1], head[2], head[3], head[4]]) as usize;
            let mut hello = vec![0u8; len];
            let _ = stream.read_exact(&mut hello);
            let cap = caly_ipc::MAX_FRAME_SIZE_BYTES;
            let mut frame = vec![2u8];
            frame.extend_from_slice(&(cap.saturating_add(1)).to_be_bytes());
            frame.extend_from_slice(b"not-the-declared-payload");
            let _ = stream.write_all(&frame);
            std::thread::sleep(Duration::from_secs(30));
        }
    });
    let started = Instant::now();
    let (code, _stdout, stderr) = run_cli(&["status", "--addr", &format!("127.0.0.1:{port}")]);
    assert!(
        started.elapsed() < Duration::from_secs(2),
        "the CLI must refuse at the 5-byte head, not wait out the 3s read timeout: {stderr}"
    );
    assert_eq!(
        code, 13,
        "an over-cap frame is PROTO_MISMATCH, not TIMEOUT: {stderr}"
    );
    assert!(
        stderr.contains("inbound") && stderr.contains("MAX_FRAME_SIZE_BYTES"),
        "the refusal must name the inbound cap: {stderr}"
    );
}

/// `caly doctor` prints what the wire actually said — every tier line the oracle's own
/// conversation received appears in the CLI output, and the printed counts match the oracle's.
#[test]
fn caly_doctor_prints_the_tiers_the_wire_actually_said() {
    let daemon = spawn_daemon("cli-doctor");
    let address = format!("127.0.0.1:{}", daemon.port);

    let (code, stdout, stderr) = run_cli(&["doctor", "--addr", &address]);
    assert_eq!(code, 0, "stderr: {stderr}");
    for key in ["summary:", "truncated:", "warnings:", "errors:", "notes:"] {
        assert!(stdout.contains(key), "{key} heading must print: {stdout}");
    }

    // Ground truth from this test's own conversation.
    let mut stream = TcpStream::connect(("127.0.0.1", daemon.port)).expect("daemon");
    let hello = b"client_name=oracle
role=Admin
major=1
minor=0";
    let mut frame = vec![1u8];
    frame.extend_from_slice(&(hello.len() as u32).to_be_bytes());
    frame.extend_from_slice(hello);
    stream.write_all(&frame).expect("hello");
    let mut head = [0u8; 5];
    stream.read_exact(&mut head).expect("ack head");
    let mut ack = vec![0u8; u32::from_be_bytes([head[1], head[2], head[3], head[4]]) as usize];
    stream.read_exact(&mut ack).expect("ack body");
    let request = b"request_id=61
trace_id=oracle
operation=diagnostics.doctor";
    let mut frame = vec![3u8];
    frame.extend_from_slice(&(request.len() as u32).to_be_bytes());
    frame.extend_from_slice(request);
    stream.write_all(&frame).expect("request");
    stream.read_exact(&mut head).expect("response head");
    let mut body = vec![0u8; u32::from_be_bytes([head[1], head[2], head[3], head[4]]) as usize];
    stream.read_exact(&mut body).expect("response body");
    // The oracle parses the documented format independently — including the value escaping the
    // shared codec performs: without this, an oracle that never unescapes would flag a CLI that
    // correctly did (which is exactly what happened on this judge's first run).
    fn oracle_unescape(value: &str) -> String {
        let mut out = String::new();
        let mut rest = value;
        while let Some(at) = rest.find('%') {
            out.push_str(&rest[..at]);
            let tail = &rest[at + 1..];
            if let Some(next) = tail.strip_prefix("25") {
                out.push('%');
                rest = next;
            } else if let Some(next) = tail.strip_prefix("3D") {
                out.push('=');
                rest = next;
            } else if let Some(next) = tail.strip_prefix("0A") {
                out.push('\n');
                rest = next;
            } else {
                out.push('%');
                rest = tail;
            }
        }
        out.push_str(rest);
        out
    }
    let truth: Vec<(String, String)> = String::from_utf8_lossy(&body)
        .lines()
        .filter_map(|line| {
            line.split_once('=')
                .map(|(k, v)| (k.to_owned(), oracle_unescape(v)))
        })
        .collect();
    let find = |key: &str| {
        truth
            .iter()
            .find(|(k, _)| k == key)
            .map(|(_, v)| v.clone())
            .unwrap_or_default()
    };
    for (prefix, count_key) in [
        ("warning", "warning_count"),
        ("error", "error_count"),
        ("note", "note_count"),
    ] {
        let heading = format!("{prefix}s:");
        assert!(
            stdout.contains(&format!("{heading} {}", find(count_key))),
            "the printed {prefix} count ({heading}) must be the wire's own: {stdout}"
        );
        for index in 0..find(count_key).parse::<usize>().unwrap_or(0) {
            let line = find(&format!("{prefix}_{index}"));
            // The gc note carries a live clock reading (`now=...@storage-clock`) that differs
            // between the CLI's conversation and this oracle's seconds later: parity is judged
            // on the stable prefix, not on a timestamp neither side controls.
            let stable = line.split(" now=").next().unwrap_or(&line).to_owned();
            assert!(
                !stable.is_empty() && stdout.contains(&stable),
                "{prefix}_{index} ({stable:?}) must appear in the CLI output: {stdout}"
            );
        }
    }
}

/// `caly doctor --runtime`: the runtime projection is an opt-in the CLI can reach — the
/// default shape keeps the older summary, the flag widens it to name the runtime snapshot.
#[test]
fn caly_doctor_runtime_flag_names_the_runtime_projection() {
    let daemon = spawn_daemon("cli-doctor-runtime");
    let address = format!("127.0.0.1:{}", daemon.port);

    let (code, stdout, stderr) = run_cli(&["doctor", "--addr", &address]);
    assert_eq!(code, 0, "stderr: {stderr}");
    let plain = stdout
        .lines()
        .find(|line| line.starts_with("summary: "))
        .unwrap_or_default()
        .to_owned();
    assert!(
        !plain.contains("runtime active_profile="),
        "the default shape must not widen the summary: {plain}"
    );

    let (code, stdout, stderr) = run_cli(&["doctor", "--runtime", "--addr", &address]);
    assert_eq!(code, 0, "stderr: {stderr}");
    let widened = stdout
        .lines()
        .find(|line| line.starts_with("summary: "))
        .unwrap_or_default()
        .to_owned();
    assert!(
        widened.contains("runtime active_profile=") && widened.contains("engine_lifecycle="),
        "--runtime must name the runtime snapshot the doctor saw: {widened}"
    );
}

/// `caly profiles`: the count and every profile line must be what the wire said, in an
/// independent oracle's conversation. The oracle speaks the raw wire itself — two
/// implementations agreeing is evidence, one implementation round-tripping itself is not.
#[test]
fn caly_profiles_prints_the_list_the_wire_actually_said() {
    let daemon = spawn_daemon("cli-profiles");
    let address = format!("127.0.0.1:{}", daemon.port);

    let (code, stdout, stderr) = run_cli(&["profiles", "--addr", &address]);
    assert_eq!(code, 0, "stderr: {stderr}");

    let truth = oracle_conversation(daemon.port, "profiles.list", b"");
    let find = |key: &str| {
        truth
            .iter()
            .find(|(k, _)| k == key)
            .map(|(_, v)| v.clone())
            .unwrap_or_default()
    };
    let count = find("profile_count").parse::<usize>().unwrap_or(0);
    assert!(
        stdout.contains(&format!("profiles: {count}")),
        "the printed count must be the wire's own: {stdout}"
    );
    for index in 0..count {
        let id = find(&format!("profile_{index}_id"));
        let label = find(&format!("profile_{index}_label"));
        assert!(
            !id.is_empty() && stdout.contains(&id),
            "profile_{index}_id ({id:?}) must appear in the CLI output: {stdout}"
        );
        assert!(
            !label.is_empty() && stdout.contains(&label),
            "profile_{index}_label ({label:?}) must appear in the CLI output: {stdout}"
        );
    }
}

/// `caly profile <id>`: an id outside the registry is a named refusal with the wire's own
/// exit code (CONFLICT → 4), never a fabricated success — round 113 closed the false success
/// where `caly profile nonexistent` printed a default-labelled view and exited 0 (`§4.187`).
/// A registered id prints every field with the wire's value, and an absent id is a usage
/// error at the client — not a guessed default that travels to the daemon.
#[test]
fn caly_profile_refuses_an_unknown_id_and_prints_the_view_for_a_registered_one() {
    let daemon = spawn_daemon("cli-profile");
    let address = format!("127.0.0.1:{}", daemon.port);

    let (code, stdout, stderr) = run_cli(&["profile", "nightshift", "--addr", &address]);
    assert_eq!(code, 4, "an unknown profile is CONFLICT → exit 4: {stderr}");
    assert!(
        stdout.is_empty(),
        "a refusal prints nothing to stdout: {stdout}"
    );
    assert!(
        stderr.contains("CONFLICT") && stderr.contains("no such profile: nightshift"),
        "the refusal must name the code and the asked id: {stderr}"
    );

    let (code, stdout, stderr) = run_cli(&["profile", "default-profile", "--addr", &address]);
    assert_eq!(code, 0, "a registered profile answers: {stderr}");

    let truth = oracle_conversation(daemon.port, "profiles.get", b"profile_id=default-profile");
    let find = |key: &str| {
        truth
            .iter()
            .find(|(k, _)| k == key)
            .map(|(_, v)| v.clone())
            .unwrap_or_default()
    };
    assert_eq!(find("profile_id"), "default-profile".to_owned());
    for key in [
        "profile_id",
        "label",
        "active",
        "source_count",
        "core_target",
    ] {
        let value = find(key);
        assert!(
            stdout.contains(&format!("{key}: {value}")),
            "{key} must print with the wire's own value ({value:?}): {stdout}"
        );
    }

    // An absent operand is the client's own usage error: the daemon must never be asked.
    let (code, _stdout, stderr) = run_cli(&["profile", "--addr", &address]);
    assert_eq!(code, 2, "missing id is exit 2, not a guessed default");
    assert!(
        stderr.contains("profile needs an id"),
        "the usage error must name the operand: {stderr}"
    );
}

/// Round 114: the subscription pipeline's user surface — `caly sources` lists an endpoint
/// registered at startup (before any fetch), and `caly source <id>` prints the wire's own view;
/// an unknown id is CONFLICT → exit 4 with nothing on stdout, the round-113 profile contract
/// applied to sources.
#[test]
fn caly_sources_lists_the_registered_endpoint_and_source_refuses_unknown_ids() {
    let daemon = spawn_daemon_with(
        "cli-sources",
        &[
            "--source-endpoint",
            "airport=http://example.test/subscription-20260803.txt",
        ],
    );
    let address = format!("127.0.0.1:{}", daemon.port);

    let (code, stdout, stderr) = run_cli(&["sources", "--addr", &address]);
    assert_eq!(code, 0, "sources.list answers: {stderr}");
    let truth = oracle_conversation(daemon.port, "sources.list", b"");
    let find = |key: &str| {
        truth
            .iter()
            .find(|(k, _)| k == key)
            .map(|(_, v)| v.clone())
            .unwrap_or_default()
    };
    let count = find("source_count").parse::<usize>().unwrap_or(0);
    assert!(count >= 1, "the list must carry the registered endpoint");
    let mut listed = false;
    for index in 0..count {
        let id = find(&format!("source_{index}_id"));
        let label = find(&format!("source_{index}_label"));
        let kind = find(&format!("source_{index}_kind"));
        if id == "airport" {
            listed = true;
            assert_eq!(label, "Source airport", "the endpoint keeps its label");
            assert_eq!(kind, "subscription", "the endpoint keeps its kind");
        }
        assert!(
            stdout.contains(&format!("  {id}  {label}  ({kind})")),
            "each source prints with the wire's own fields ({id}): {stdout}"
        );
    }
    assert!(listed, "airport must be on the printed list: {stdout}");

    let (code, stdout, stderr) = run_cli(&["source", "airport", "--addr", &address]);
    assert_eq!(code, 0, "a registered source answers: {stderr}");
    let truth = oracle_conversation(daemon.port, "sources.inspect", b"source_id=airport");
    let find = |key: &str| {
        truth
            .iter()
            .find(|(k, _)| k == key)
            .map(|(_, v)| v.clone())
            .unwrap_or_default()
    };
    for key in ["source_id", "label", "kind", "normalized_node_count"] {
        let value = find(key);
        assert!(
            stdout.contains(&format!("{key}: {value}")),
            "{key} must print with the wire's own value ({value:?}): {stdout}"
        );
    }
    assert!(
        stdout.contains("raw_stored_at_unix_ms: never"),
        "an absent durable fact prints as never-fetched, not a blank: {stdout}"
    );
    assert!(
        stdout.contains("normalized_node_count: 0"),
        "nothing was fetched, so no node count may be invented: {stdout}"
    );

    let (code, stdout, stderr) = run_cli(&["source", "nope", "--addr", &address]);
    assert_eq!(code, 4, "an unknown source is CONFLICT → exit 4: {stderr}");
    assert!(
        stdout.is_empty(),
        "a refusal prints nothing to stdout: {stdout}"
    );
    assert!(
        stderr.contains("CONFLICT") && stderr.contains("no such source: nope"),
        "the refusal must name the code and the asked id: {stderr}"
    );

    // An absent operand is the client's own usage error: the daemon must never be asked.
    let (code, _stdout, stderr) = run_cli(&["source", "--addr", &address]);
    assert_eq!(code, 2, "missing id is exit 2, not a guessed default");
    assert!(
        stderr.contains("source needs an id"),
        "the usage error must name the operand: {stderr}"
    );
}

/// `caly apply`: exit 0, the acceptance's three fields printed, and — because v0 drains inline —
/// the printed job id must already be terminal when this test asks the wire about it.
#[test]
fn caly_apply_prints_an_acceptance_and_the_worker_finishes_the_job() {
    let daemon = spawn_daemon("cli-apply");
    let address = format!("127.0.0.1:{}", daemon.port);

    let (code, stdout, stderr) = run_cli(&[
        "apply",
        "demo-tun-profile",
        "--idempotency-key",
        "cli-e2e-apply",
        "--addr",
        &address,
    ]);
    assert_eq!(code, 0, "stderr: {stderr}");
    for key in ["job_id:", "state_revision:", "estimated_impact:"] {
        assert!(stdout.contains(key), "{key} must print: {stdout}");
    }
    let job_id = stdout
        .lines()
        .find_map(|line| line.strip_prefix("job_id: "))
        .unwrap_or_default()
        .trim()
        .to_owned();
    let state = oracle_wait_terminal(daemon.port, &job_id);
    assert_eq!(state, "completed", "stdout: {stdout}");
    let truth = oracle_conversation(
        daemon.port,
        "jobs.events",
        format!("job_id={job_id}").as_bytes(),
    );
    let find = |key: &str| {
        truth
            .iter()
            .find(|(k, _)| k == key)
            .map(|(_, v)| v.clone())
            .unwrap_or_default()
    };
    assert_eq!(find("state"), "completed".to_owned(), "stdout: {stdout}");
    assert_eq!(find("job_id"), job_id);
}

/// Round 115: `caly apply --wait` is the documented `apply`+`follow` composition as one
/// command — the acceptance prints first, then the same session streams the accepted job to
/// its terminal frame, and the stream's verdict is the exit code. On the real daemon the
/// default spawn drains inline, so the follow half replays the window and ends Succeeded.
#[test]
fn caly_apply_with_wait_prints_the_acceptance_then_streams_the_job_and_takes_its_verdict() {
    let daemon = spawn_daemon("cli-apply-wait");
    let address = format!("127.0.0.1:{}", daemon.port);

    let (code, stdout, stderr) = run_cli(&[
        "apply",
        "demo-tun-profile",
        "--idempotency-key",
        "wk1",
        "--wait",
        "--addr",
        &address,
    ]);
    assert_eq!(code, 0, "a succeeded job's verdict is exit 0: {stderr}");
    assert!(
        stdout.contains("job_id: 1") && stdout.contains("estimated_impact"),
        "the acceptance fields print first: {stdout}"
    );
    assert!(
        stdout.contains("  - "),
        "the wait half streams the job's events: {stdout}"
    );
    assert!(
        stdout.contains("[done] Succeeded"),
        "the terminal line rides the stream: {stdout}"
    );
    let acceptance = stdout.find("job_id: 1").expect("acceptance present");
    let first_event = stdout.find("  - ").expect("events present");
    assert!(
        acceptance < first_event,
        "acceptance precedes the streamed events: {stdout}"
    );
}

/// Round 115, verdict twin (fake daemon): the `--wait` half must take the stream's verdict
/// as the exit code — a failed job is exit 1, exactly like `caly follow`, not the
/// acceptance's exit 0.
#[test]
fn a_wait_apply_of_a_failed_job_exits_nonzero_like_a_follow() {
    let listener = TcpListener::bind("127.0.0.1:0").expect("bind fake daemon");
    let port = listener.local_addr().expect("port").port();
    let _server = std::thread::spawn(move || {
        let (mut stream, _) = listener.accept().expect("accept");
        if read_hello(&mut stream).is_none() {
            return;
        }
        if write_hello_ack(&mut stream).is_err() {
            return;
        }
        // Request one is the apply; answer it with an acceptance naming job 7.
        if read_request(&mut stream).is_none() {
            return;
        }
        if write_frame(
            &mut stream,
            4,
            b"request_id=1\njob_id=7\nstate_revision=1\nestimated_impact=Restart",
        )
        .is_err()
        {
            return;
        }
        // Request two is the follow-stream open for job 7; open stream 9 and complete it
        // with one event and a Failed verdict.
        if read_request(&mut stream).is_none() {
            return;
        }
        if write_frame(&mut stream, 4, b"request_id=1\nstream_id=9\nresumed=false").is_err() {
            return;
        }
        if write_frame(
            &mut stream,
            6,
            b"stream_id=9\nnext_event_index=1\nevent_0=[stage 100%25] failed",
        )
        .is_err()
        {
            return;
        }
        if write_frame(&mut stream, 7, b"stream_id=9\noutcome=Failed").is_err() {
            return;
        }
        if let Some(kind) = read_ack(&mut stream) {
            if kind == 8 {
                let _ = write_frame(&mut stream, 4, b"stream_id=9\nacked_upto=1");
            }
        }
        std::thread::sleep(Duration::from_secs(2));
    });

    let (code, stdout, stderr) = run_cli(&[
        "apply",
        "demo-tun-profile",
        "--idempotency-key",
        "wk2",
        "--wait",
        "--addr",
        &format!("127.0.0.1:{port}"),
    ]);
    assert_eq!(
        code, 1,
        "a failed job's verdict is exit 1, not the acceptance's 0: stdout={stdout} stderr={stderr}"
    );
    assert!(
        stdout.contains("job_id: 7"),
        "the acceptance still prints: {stdout}"
    );
    assert!(
        stdout.contains("[stage 100%] failed"),
        "the streamed events still print: {stdout}"
    );
}

/// Round 116 (ADR-058), fake-daemon side: run one `caly follow` against a fake daemon whose
/// stream END frame is exactly `end_body`, and hand back the CLI's verdict. No DATA frames,
/// so the conversation is opened-frame then END — the exit code must come from the END
/// records alone.
fn run_follow_against_fake_end(end_body: &'static [u8]) -> (i32, String, String) {
    let listener = TcpListener::bind("127.0.0.1:0").expect("bind fake daemon");
    let port = listener.local_addr().expect("port").port();
    let _server = std::thread::spawn(move || {
        let (mut stream, _) = listener.accept().expect("accept");
        if read_hello(&mut stream).is_none() {
            return;
        }
        if write_hello_ack(&mut stream).is_err() {
            return;
        }
        if read_request(&mut stream).is_none() {
            return;
        }
        if write_frame(&mut stream, 4, b"request_id=1\nstream_id=7\nresumed=false").is_err() {
            return;
        }
        if write_frame(&mut stream, 7, end_body).is_err() {
            return;
        }
        std::thread::sleep(Duration::from_secs(2));
    });
    run_cli(&["follow", "1", "--addr", &format!("127.0.0.1:{port}")])
}

/// A `Failed` end carrying a recognised public code exits with that code's number
/// (PERMISSION -> 8), exactly like the one-shot `caly job` of the same failed job.
#[test]
fn a_streamed_failure_carrying_a_failure_code_exits_with_that_code() {
    let (code, stdout, stderr) =
        run_follow_against_fake_end(b"stream_id=7\noutcome=Failed\nfailure_code=PERMISSION");
    assert_eq!(
        code, 8,
        "a streamed PERMISSION failure exits 8, not a blanket 1: stdout={stdout} stderr={stderr}"
    );
}

/// A `Failed` end without a `failure_code` (an older daemon, or a failure without a public
/// code) keeps the historical blanket exit 1 — the new field must never turn an absent code
/// into a guessed success or a wire-disagreement.
#[test]
fn a_streamed_failure_without_a_failure_code_stays_exit_one() {
    let (code, stdout, stderr) = run_follow_against_fake_end(b"stream_id=7\noutcome=Failed");
    assert_eq!(
        code, 1,
        "an uncoded streamed failure keeps exit 1: stdout={stdout} stderr={stderr}"
    );
}

/// The outcome is the verdict; `failure_code` only refines `Failed`. A stray code on a
/// succeeded end must not flip the verdict (the daemon never emits it — this is the
/// client's defensive read), and an unrecognised code on a failed end falls to 13 exactly
/// like the one-shot path (`from_wire_refusal_code`), never to a guessed success.
#[test]
fn a_stream_end_verdict_is_not_overridden_by_a_stray_failure_code() {
    let (code, stdout, stderr) =
        run_follow_against_fake_end(b"stream_id=7\noutcome=Succeeded\nfailure_code=PERMISSION");
    assert_eq!(
        code, 0,
        "a stray failure_code on a Succeeded end is ignored: stdout={stdout} stderr={stderr}"
    );

    let (code, stdout, stderr) =
        run_follow_against_fake_end(b"stream_id=7\noutcome=Failed\nfailure_code=BOGUS");
    assert_eq!(
        code, 13,
        "an unrecognised failure_code is a proto disagreement (13), not a guessed success: \
         stdout={stdout} stderr={stderr}"
    );
}

/// Round 115, opt-in twin (fake daemon): without `--wait`, apply must not open a stream —
/// the daemon answering the acceptance and then staying silent must still let the CLI exit 0
/// promptly (the flag is opt-in; an unconditional follow would hang here and time out).
#[test]
fn an_apply_without_wait_never_opens_a_stream() {
    let listener = TcpListener::bind("127.0.0.1:0").expect("bind fake daemon");
    let port = listener.local_addr().expect("port").port();
    let saw_follow_request = Arc::new(AtomicBool::new(false));
    let flag = Arc::clone(&saw_follow_request);
    let server = std::thread::spawn(move || {
        let (mut stream, _) = listener.accept().expect("accept");
        if read_hello(&mut stream).is_none() {
            return;
        }
        if write_hello_ack(&mut stream).is_err() {
            return;
        }
        if read_request(&mut stream).is_none() {
            return;
        }
        if write_frame(
            &mut stream,
            4,
            b"request_id=1\njob_id=7\nstate_revision=1\nestimated_impact=Restart",
        )
        .is_err()
        {
            return;
        }
        // No stream may follow the acceptance: any further request frame is the mutation's
        // fingerprint. Bounded read so a well-behaved CLI is not punished with a hang.
        stream
            .set_read_timeout(Some(Duration::from_millis(700)))
            .expect("fake read deadline");
        if read_request(&mut stream).is_some() {
            flag.store(true, Ordering::SeqCst);
        }
    });

    let (code, stdout, stderr) = run_cli(&[
        "apply",
        "demo-tun-profile",
        "--idempotency-key",
        "wk3",
        "--addr",
        &format!("127.0.0.1:{port}"),
    ]);
    assert_eq!(
        code, 0,
        "acceptance alone exits 0: stdout={stdout} stderr={stderr}"
    );
    assert!(
        stdout.contains("job_id: 7"),
        "the acceptance prints: {stdout}"
    );
    assert!(
        !stdout.contains("  - "),
        "no streamed events without --wait: {stdout}"
    );
    server.join().expect("fake daemon thread");
    assert!(
        !saw_follow_request.load(Ordering::SeqCst),
        "apply without --wait must not open a stream"
    );
}

/// Round 115, usage half: `--wait` on a non-apply verb is a client-side usage error — a flag
/// that silently did nothing would let a script believe it was waiting on a verdict.
#[test]
fn caly_wait_on_a_non_apply_verb_is_a_usage_error() {
    let daemon = spawn_daemon("cli-wait-usage");
    let address = format!("127.0.0.1:{}", daemon.port);
    let (code, _stdout, stderr) = run_cli(&["status", "--wait", "--addr", &address]);
    assert_eq!(code, 2, "--wait outside apply is exit 2: {stderr}");
    assert!(
        stderr.contains("--wait belongs to apply"),
        "the usage error must name the flag's home: {stderr}"
    );
}

/// `caly jobs`: state, count and every event line must match an independent oracle's
/// conversation about the same job. Stored event lines are immutable once the job is terminal,
/// so full-string parity is the bar — no stable-prefix carve-outs here.
#[test]
fn caly_jobs_prints_the_events_the_wire_said() {
    let daemon = spawn_daemon("cli-jobs");
    let address = format!("127.0.0.1:{}", daemon.port);

    let (code, stdout, stderr) = run_cli(&[
        "apply",
        "demo-tun-profile",
        "--idempotency-key",
        "cli-e2e-jobs",
        "--addr",
        &address,
    ]);
    assert_eq!(code, 0, "stderr: {stderr}");
    let job_id = stdout
        .lines()
        .find_map(|line| line.strip_prefix("job_id: "))
        .unwrap_or_default()
        .trim()
        .to_owned();
    oracle_wait_terminal(daemon.port, &job_id);

    let (code, stdout, stderr) = run_cli(&["jobs", &job_id, "--addr", &address]);
    assert_eq!(code, 0, "stderr: {stderr}");
    let truth = oracle_conversation(
        daemon.port,
        "jobs.events",
        format!("job_id={job_id}").as_bytes(),
    );
    let find = |key: &str| {
        truth
            .iter()
            .find(|(k, _)| k == key)
            .map(|(_, v)| v.clone())
            .unwrap_or_default()
    };
    assert_eq!(find("state"), "completed".to_owned());
    let count = find("event_count").parse::<usize>().unwrap_or(0);
    assert!(
        stdout.contains(&format!("events: {count}")),
        "the printed count must be the wire's own: {stdout}"
    );
    for index in 0..count {
        let line = find(&format!("event_{index}"));
        assert!(
            !line.is_empty() && stdout.contains(&line),
            "event_{index} ({line:?}) must appear in the CLI output: {stdout}"
        );
    }
}

/// `caly jobs` with NO id is the discovery verb (`jobs.list`): it must list the jobs the daemon
/// holds, newest first, against an independent oracle's `jobs.list` conversation. This is the half
/// of the job family that did not exist (`JOB_FLOW_SCENARIO_REVIEW`): without it a client cannot
/// find an id after losing its shell. `caly jobs <id>` is unaffected (still `jobs.events`).
#[test]
fn caly_jobs_without_an_id_lists_recent_jobs_newest_first() {
    let daemon = spawn_daemon("cli-jobs-list");
    let address = format!("127.0.0.1:{}", daemon.port);

    // Two distinct writes, so the list has an order to be wrong about.
    for (profile, key) in [
        ("demo-tun-profile", "cli-e2e-list-1"),
        ("nightshift", "cli-e2e-list-2"),
    ] {
        let (code, _out, err) = run_cli(&[
            "apply",
            profile,
            "--idempotency-key",
            key,
            "--addr",
            &address,
        ]);
        assert_eq!(code, 0, "apply must be accepted: {err}");
    }
    // The worker drains inline in v0; wait for the newest job to be terminal so both rows exist.
    oracle_wait_terminal(daemon.port, "2");

    let (code, stdout, stderr) = run_cli(&["jobs", "--addr", &address]);
    assert_eq!(code, 0, "stderr: {stderr}");

    // Human render: count header plus one row per job, ids newest first.
    assert!(
        stdout.starts_with("jobs: 2\n"),
        "the list header must report the wire's own count: {stdout}"
    );
    let ids: Vec<&str> = stdout
        .lines()
        .skip(1)
        .filter_map(|line| line.split_whitespace().next())
        .collect();
    assert_eq!(ids, vec!["2", "1"], "rows must be newest first: {stdout}");

    // The same numbers from an independent wire conversation about `jobs.list`.
    let truth = oracle_conversation(daemon.port, "jobs.list", b"");
    let find = |key: &str| {
        truth
            .iter()
            .find(|(k, _)| k == key)
            .map(|(_, v)| v.clone())
            .unwrap_or_default()
    };
    assert_eq!(find("job_count"), "2".to_owned());
    assert_eq!(find("job_0_id"), "2".to_owned(), "oracle row 0 is newest");
    assert_eq!(find("job_1_id"), "1".to_owned());
    assert_eq!(find("job_0_state"), "completed".to_owned());
    // Row fields the CLI render drew from must really be on the wire.
    assert!(!find("job_0_pct").is_empty(), "a row carries its pct");
}

/// The key is the caller's own name for the write: the CLI requires it as a flag and never
/// mints one — a silently minted key would turn every shell retry into a second write.
#[test]
fn apply_without_an_idempotency_key_is_a_usage_error_not_a_minted_one() {
    let daemon = spawn_daemon("cli-apply-nokey");
    let address = format!("127.0.0.1:{}", daemon.port);
    let (code, _stdout, stderr) = run_cli(&["apply", "demo-tun-profile", "--addr", &address]);
    assert_eq!(code, 2, "missing key is exit 2, not a minted key");
    assert!(
        stderr.contains("--idempotency-key"),
        "the usage error must name the flag: {stderr}"
    );
}

/// `caly job <id>`: the follow summary, every field, against an independent oracle's
/// `jobs.follow` conversation about the same (terminal, immutable) job.
#[test]
fn caly_job_prints_the_summary_the_wire_said() {
    let daemon = spawn_daemon("cli-job");
    let address = format!("127.0.0.1:{}", daemon.port);

    let (code, stdout, stderr) = run_cli(&[
        "apply",
        "demo-tun-profile",
        "--idempotency-key",
        "cli-e2e-job",
        "--addr",
        &address,
    ]);
    assert_eq!(code, 0, "stderr: {stderr}");
    let job_id = stdout
        .lines()
        .find_map(|line| line.strip_prefix("job_id: "))
        .unwrap_or_default()
        .trim()
        .to_owned();

    let (code, stdout, stderr) = run_cli(&["job", &job_id, "--addr", &address]);
    assert_eq!(code, 0, "stderr: {stderr}");
    oracle_wait_terminal(daemon.port, &job_id);
    let truth = oracle_conversation(
        daemon.port,
        "jobs.follow",
        format!("job_id={job_id}").as_bytes(),
    );
    let find = |key: &str| {
        truth
            .iter()
            .find(|(k, _)| k == key)
            .map(|(_, v)| v.clone())
            .unwrap_or_default()
    };
    assert_eq!(find("state"), "completed".to_owned());
    for key in [
        "job_id",
        "state",
        "lifecycle",
        "next_event_index",
        "retained_from_event_index",
        "reset_required",
        "event_count",
        "last_stage",
        "warning_count",
        "log_count",
        "failure_code",
        "failure_summary",
    ] {
        let value = find(key);
        assert!(
            stdout.contains(&format!("{key}: {value}")),
            "{key} must print with the wire's own value ({value:?}): {stdout}"
        );
    }
}

/// `caly rollback --snapshot <id>`: exit 0, and the rollback job's own event lines must name
/// the snapshot that was asked for — the guessed-default mutation (silently rolling back to
/// the last-known-good instead) would pass every other assertion. Missing key is exit 2.
#[test]
fn caly_rollback_targets_the_named_snapshot_and_requires_a_key() {
    let daemon = spawn_daemon("cli-rollback");
    let address = format!("127.0.0.1:{}", daemon.port);
    let apply = |key: &str, profile: &str| {
        let (code, stdout, stderr) = run_cli(&[
            "apply",
            profile,
            "--idempotency-key",
            key,
            "--addr",
            &address,
        ]);
        assert_eq!(code, 0, "stderr: {stderr}");
        let job_id = stdout
            .lines()
            .find_map(|line| line.strip_prefix("job_id: "))
            .unwrap_or_default()
            .trim()
            .to_owned();
        // The snapshot the next read looks for is published by the run, and the worker owns
        // the run — wait for the daemon to say the job is done, not for luck.
        oracle_wait_terminal(daemon.port, &job_id);
        stdout
    };
    let active_snapshot = |stdout: &str| {
        stdout
            .lines()
            .find_map(|line| line.strip_prefix("active_snapshot: "))
            .unwrap_or_default()
            .trim()
            .to_owned()
    };
    let status = || {
        let (code, stdout, stderr) = run_cli(&["status", "--addr", &address]);
        assert_eq!(code, 0, "stderr: {stderr}");
        stdout
    };
    apply("cli-e2e-rb-1", "demo-tun-profile");
    let first = active_snapshot(&status());
    apply("cli-e2e-rb-2", "nightshift");
    let second = active_snapshot(&status());
    assert!(!first.is_empty() && !second.is_empty() && first != second);

    let (code, stdout, stderr) = run_cli(&[
        "rollback",
        "--snapshot",
        &first,
        "--idempotency-key",
        "cli-e2e-rb-3",
        "--addr",
        &address,
    ]);
    assert_eq!(code, 0, "stderr: {stderr}");
    let job_id = stdout
        .lines()
        .find_map(|line| line.strip_prefix("job_id: "))
        .unwrap_or_default()
        .trim()
        .to_owned();
    oracle_wait_terminal(daemon.port, &job_id);
    let (code, events_out, stderr) = run_cli(&["jobs", &job_id, "--addr", &address]);
    assert_eq!(code, 0, "stderr: {stderr}");
    assert!(
        events_out.contains(&format!("target={first}")),
        "the rollback job must name the snapshot it used: {events_out}"
    );
    assert!(
        !events_out.contains(&format!("target={second}")),
        "a named rollback must not use the last-known-good instead: {events_out}"
    );

    let (code, _stdout, stderr) = run_cli(&["rollback", "--addr", &address]);
    assert_eq!(code, 2, "missing key is exit 2, not a minted key");
    assert!(
        stderr.contains("--idempotency-key"),
        "the usage error must name the flag: {stderr}"
    );
}

/// `caly jobs <id> --max/--from`: the cursor contract from the client side. A capped page says
/// so (`next_from_event_index` non-empty), resuming from it yields exactly the rest, and the
/// two pages concatenated are the whole window — no line lost, none repeated.
#[test]
fn caly_jobs_pages_by_cursor_and_the_pages_tile_the_window() {
    let daemon = spawn_daemon("cli-jobs-paging");
    let address = format!("127.0.0.1:{}", daemon.port);

    let (code, stdout, stderr) = run_cli(&[
        "apply",
        "demo-tun-profile",
        "--idempotency-key",
        "cli-e2e-paging",
        "--addr",
        &address,
    ]);
    assert_eq!(code, 0, "stderr: {stderr}");
    let job_id = stdout
        .lines()
        .find_map(|line| line.strip_prefix("job_id: "))
        .unwrap_or_default()
        .trim()
        .to_owned();
    oracle_wait_terminal(daemon.port, &job_id);

    let event_lines = |stdout: &str| -> Vec<String> {
        stdout
            .lines()
            .filter_map(|line| line.strip_prefix("  - "))
            .map(str::to_owned)
            .collect()
    };
    let next_from = |stdout: &str| {
        stdout
            .lines()
            .find_map(|line| line.strip_prefix("next_from_event_index: "))
            .unwrap_or_default()
            .trim()
            .to_owned()
    };

    let (code, whole, stderr) = run_cli(&["jobs", &job_id, "--addr", &address]);
    assert_eq!(code, 0, "stderr: {stderr}");
    let all = event_lines(&whole);
    assert!(
        all.len() >= 6,
        "an executed job logs enough to page: {all:?}"
    );
    assert_eq!(next_from(&whole), "", "the unpaged read reaches the end");

    let (code, page1, stderr) = run_cli(&["jobs", &job_id, "--max", "3", "--addr", &address]);
    assert_eq!(code, 0, "stderr: {stderr}");
    assert_eq!(
        event_lines(&page1).len(),
        3,
        "--max bounds the page: {page1}"
    );
    let cursor = next_from(&page1);
    assert!(
        !cursor.is_empty(),
        "a capped page must say where to resume: {page1}"
    );

    let (code, page2, stderr) = run_cli(&["jobs", &job_id, "--from", &cursor, "--addr", &address]);
    assert_eq!(code, 0, "stderr: {stderr}");
    assert_eq!(
        next_from(&page2),
        "",
        "the resumed page reaches the end: {page2}"
    );

    let mut tiled = event_lines(&page1);
    tiled.extend(event_lines(&page2));
    assert_eq!(
        tiled, all,
        "the two pages must tile the window exactly — no line lost, none repeated"
    );
}

/// `caly gc-plan`: the plan's scalars must match an independent oracle's `system.gc-plan`
/// conversation. The live clock reading is the one field allowed to differ (it is a clock);
/// everything else is the same fact asked twice.
#[test]
fn caly_gc_plan_matches_an_independent_oracle() {
    let daemon = spawn_daemon("cli-gc-plan");
    let address = format!("127.0.0.1:{}", daemon.port);

    let (code, stdout, stderr) = run_cli(&["gc-plan", "--addr", &address]);
    assert_eq!(code, 0, "stderr: {stderr}");
    let truth = oracle_conversation(daemon.port, "system.gc-plan", b"");
    let find = |key: &str| {
        truth
            .iter()
            .find(|(k, _)| k == key)
            .map(|(_, v)| v.clone())
            .unwrap_or_default()
    };
    assert_eq!(find("now_source"), "storage-clock".to_owned());
    for key in [
        "now_source",
        "grace_period_ms",
        "max_deletions",
        "objects_total",
        "snapshots_total",
        "revisions_total",
        "collect_count",
        "retained_total",
        "content_total",
        "gap_count",
        "would_run",
    ] {
        let value = find(key);
        assert!(
            stdout.contains(&format!("{key}: {value}")),
            "{key} must print with the wire's own value ({value:?}): {stdout}"
        );
    }
    let count = find("collect_count").parse::<usize>().unwrap_or(0);
    for index in 0..count {
        let digest = find(&format!("collect_{index}"));
        assert!(
            !digest.is_empty() && stdout.contains(&digest),
            "collect_{index} ({digest:?}) must appear in the CLI output: {stdout}"
        );
    }
}

/// The maintenance command from the client: no key is exit 2 at the door, a keyed run prints
/// the acceptance, a replay reuses the job, and the next plan shows the run — the command
/// surface must be visible from the query surface.
#[test]
fn caly_gc_is_keyed_replays_and_shows_up_in_the_next_plan() {
    let daemon = spawn_daemon("cli-gc");
    let address = format!("127.0.0.1:{}", daemon.port);

    let (code, _stdout, stderr) = run_cli(&["gc", "--addr", &address]);
    assert_eq!(code, 2, "no key is exit 2, not a minted key: {stderr}");
    assert!(stderr.contains("--idempotency-key"), "{stderr}");

    let run = |key: &str| {
        let (code, stdout, stderr) = run_cli(&["gc", "--idempotency-key", key, "--addr", &address]);
        assert_eq!(code, 0, "stderr: {stderr}");
        stdout
            .lines()
            .find_map(|line| line.strip_prefix("job_id: "))
            .unwrap_or_default()
            .trim()
            .to_owned()
    };
    let first = run("cli-e2e-gc");
    let replay = run("cli-e2e-gc");
    assert_eq!(first, replay, "the same key replays the same sweep");
    assert!(!first.is_empty());
    oracle_wait_terminal(daemon.port, &first);

    let (code, plan, stderr) = run_cli(&["gc-plan", "--addr", &address]);
    assert_eq!(code, 0, "stderr: {stderr}");
    assert!(
        plan.contains("last_run: gc cycle") && plan.contains("deleted="),
        "the plan must show the run this client just made: {plan}"
    );
}

/// The role the CLI declares with `--role` must reach the daemon's role gate: a Viewer can
/// read, and the same Viewer asking for an Admin-only command gets the daemon's PERMISSION
/// refusal (exit 8), not an acceptance. The wire daemon's own fail-closed judges (R92/R93)
/// cover the daemon side; this one is the client side of the same contract — a CLI whose
/// hello never carries the declared role (or a handshake that hardcodes Admin on the bytes)
/// makes this red while everything else stays green.
#[test]
fn caly_role_viewer_reads_but_is_refused_an_admin_only_command() {
    let daemon = spawn_daemon("cli-role-viewer");
    let address = format!("127.0.0.1:{}", daemon.port);

    let (code, _stdout, stderr) = run_cli(&["--role", "viewer", "status", "--addr", &address]);
    assert_eq!(code, 0, "a Viewer reads runtime.status: {stderr}");

    let (code, stdout, stderr) = run_cli(&[
        "--role",
        "viewer",
        "gc",
        "--idempotency-key",
        "cli-role-viewer-gc",
        "--addr",
        &address,
    ]);
    assert_eq!(code, 8, "PERMISSION maps to exit 8: {stderr}");
    assert!(
        stderr.contains("PERMISSION") && stderr.contains("required role Admin"),
        "the refusal must name the gate that fired: {stderr}"
    );
    assert!(
        stdout.is_empty(),
        "a refusal prints nothing to stdout: {stdout}"
    );
}

/// Operator is the middle role: more than a Viewer, still not Admin — the Admin-only gc
/// gate must refuse it too. Its own name must appear in the refusal (the gate names the
/// role it saw), so the pair with the viewer test above stays specific.
#[test]
fn caly_role_operator_is_refused_an_admin_only_command_too() {
    let daemon = spawn_daemon("cli-role-operator");
    let address = format!("127.0.0.1:{}", daemon.port);

    let (code, _stdout, stderr) = run_cli(&[
        "--role",
        "operator",
        "gc",
        "--idempotency-key",
        "cli-role-operator-gc",
        "--addr",
        &address,
    ]);
    assert_eq!(code, 8, "PERMISSION maps to exit 8: {stderr}");
    assert!(
        stderr.contains("PERMISSION") && stderr.contains("Operator"),
        "the refusal must name the role the hello declared: {stderr}"
    );
}

/// A role the client cannot name is a usage error at the client (exit 2), before any
/// round trip — sending `Root` to the daemon would otherwise surface as a handshake
/// refusal (exit 13) and the scripts get a protocol error for their own typo.
#[test]
fn caly_role_flag_rejects_an_unknown_role_as_usage_before_any_round_trip() {
    let daemon = spawn_daemon("cli-role-usage");
    let address = format!("127.0.0.1:{}", daemon.port);

    let (code, _stdout, stderr) = run_cli(&["--role", "root", "status", "--addr", &address]);
    assert_eq!(code, 2, "a role the CLI cannot name is usage: {stderr}");
    assert!(
        stderr.contains("--role needs viewer, operator or admin"),
        "the message must name the accepted spellings: {stderr}"
    );

    let (code, _stdout, stderr) = run_cli(&["--role", "admin", "status", "--addr", &address]);
    assert_eq!(code, 0, "the accepted spelling still works: {stderr}");
}

/// The anti-vacuity twin: without `--role` the CLI keeps its documented default (Admin)
/// and Admin-only commands still succeed — the viewer/operator refusals above must come
/// from the flag, not from a blanket refusal of gc or a flipped default.
#[test]
fn caly_role_admin_is_the_default_and_still_reaches_admin_commands() {
    let daemon = spawn_daemon("cli-role-default");
    let address = format!("127.0.0.1:{}", daemon.port);

    let (code, stdout, stderr) = run_cli(&[
        "gc",
        "--idempotency-key",
        "cli-role-default-nokey",
        "--addr",
        &address,
    ]);
    assert_eq!(code, 0, "no --role keeps the Admin default: {stderr}");
    assert!(stdout.contains("job_id: "), "{stdout}");

    let (code, stdout, stderr) = run_cli(&[
        "--role",
        "admin",
        "gc",
        "--idempotency-key",
        "cli-role-default-explicit",
        "--addr",
        &address,
    ]);
    assert_eq!(code, 0, "explicit admin is accepted too: {stderr}");
    assert!(stdout.contains("job_id: "), "{stdout}");
}

/// The bundle pair from the client: export (no key demanded — `Idempotency::Optional`), then
/// read the newest bundle back, then a bounded read that says it was cut.
#[test]
fn caly_bundle_exports_and_reads_back_with_honest_bounds() {
    let daemon = spawn_daemon("cli-bundle");
    let address = format!("127.0.0.1:{}", daemon.port);

    let (code, stdout, stderr) = run_cli(&["support-bundle", "--addr", &address]);
    assert_eq!(code, 0, "stderr: {stderr}");
    assert!(stdout.contains("job_id: "), "{stdout}");
    let bundle_job = stdout
        .lines()
        .find_map(|line| line.strip_prefix("job_id: "))
        .unwrap_or_default()
        .trim()
        .to_owned();
    // "the newest bundle the store still holds" only exists once the worker has run the
    // export job — the read waits for the daemon to say it happened.
    oracle_wait_terminal(daemon.port, &bundle_job);

    let (code, stdout, stderr) = run_cli(&["bundle", "--addr", &address]);
    assert_eq!(code, 0, "stderr: {stderr}");
    let digest = stdout
        .lines()
        .find_map(|line| line.strip_prefix("digest: "))
        .unwrap_or_default()
        .trim()
        .to_owned();
    assert!(digest.starts_with("sha256:"), "{stdout}");
    let content = stdout
        .lines()
        .find_map(|line| line.strip_prefix("content_sha256: "))
        .unwrap_or_default()
        .trim()
        .to_owned();
    assert_eq!(digest, content, "a bundle is its own content address");
    assert!(stdout.contains("truncated: false"), "{stdout}");
    assert!(
        stdout.contains("# caly support bundle"),
        "the text rides and prints verbatim: {stdout}"
    );

    let (code, capped, stderr) = run_cli(&["bundle", "--max-bytes", "100", "--addr", &address]);
    assert_eq!(code, 0, "stderr: {stderr}");
    assert!(capped.contains("truncated: true"), "{capped}");
    assert!(capped.contains("byte_len: 100"), "{capped}");
}

// The e2e harness's own flat-JSON oracle: parse exactly what the daemon may emit (one object,
// string values), independently of the codec both binaries share.
fn oracle_parse_flat_json(payload: &str) -> Vec<(String, String)> {
    let chars: Vec<char> = payload.chars().collect();
    let mut at = 0usize;
    let mut out = Vec::new();
    let string = |at: &mut usize| -> String {
        assert_eq!(chars[*at], '"', "oracle: expected a string: {payload}");
        *at += 1;
        let mut value = String::new();
        while chars[*at] != '"' {
            if chars[*at] == '\\' {
                *at += 1;
                match chars[*at] {
                    'n' => value.push('\n'),
                    't' => value.push('\t'),
                    'r' => value.push('\r'),
                    '"' => value.push('"'),
                    '\\' => value.push('\\'),
                    other => panic!("oracle: unhandled escape \\{other}"),
                }
            } else {
                value.push(chars[*at]);
            }
            *at += 1;
        }
        *at += 1;
        value
    };
    while chars[at].is_ascii_whitespace() {
        at += 1;
    }
    assert_eq!(chars[at], '{', "oracle: expected an object: {payload}");
    at += 1;
    loop {
        while chars[at].is_ascii_whitespace() {
            at += 1;
        }
        if chars[at] == '}' {
            break;
        }
        if !out.is_empty() {
            assert_eq!(chars[at], ',', "oracle: expected ',': {payload}");
            at += 1;
        }
        let key = string(&mut at);
        assert_eq!(chars[at], ':', "oracle: expected ':': {payload}");
        at += 1;
        let value = string(&mut at);
        out.push((key, value));
    }
    out
}

/// `--json` on two verbs: the output is one JSON object whose facts are exactly the facts the
/// records wire carries — the encoding changes how a fact is written, never which facts
/// exist. Ground truth comes from this test's own records-mode oracle conversation.
#[test]
fn json_output_carries_the_same_facts_the_records_wire_carries() {
    let daemon = spawn_daemon("cli-json");
    let address = format!("127.0.0.1:{}", daemon.port);

    let (code, stdout, stderr) = run_cli(&["status", "--json", "--addr", &address]);
    assert_eq!(code, 0, "stderr: {stderr}");
    let line = stdout.trim();
    assert!(
        line.starts_with('{') && line.ends_with('}'),
        "one JSON object: {stdout}"
    );
    let json_facts = oracle_parse_flat_json(line);

    let truth = oracle_conversation(daemon.port, "runtime.status", b"");
    let find = |facts: &[(String, String)], key: &str| {
        facts
            .iter()
            .find(|(k, _)| k == key)
            .map(|(_, v)| v.clone())
            .unwrap_or_default()
    };
    for key in [
        "core_running",
        "active_profile",
        "active_snapshot",
        "pending_recovery_decisions",
        "last_recovery_summary",
    ] {
        assert_eq!(
            find(&json_facts, key),
            find(&truth, key),
            "{key} must be the same fact in both encodings"
        );
    }

    let (code, stdout, stderr) = run_cli(&["profiles", "--json", "--addr", &address]);
    assert_eq!(code, 0, "stderr: {stderr}");
    let profiles_facts = oracle_parse_flat_json(stdout.trim());
    let profiles_truth = oracle_conversation(daemon.port, "profiles.list", b"");
    assert_eq!(
        find(&profiles_facts, "profile_count"),
        find(&profiles_truth, "profile_count"),
        "the count is the same fact in both encodings"
    );
    let count = find(&profiles_truth, "profile_count")
        .parse::<usize>()
        .unwrap_or(0);
    for index in 0..count {
        assert_eq!(
            find(&profiles_facts, &format!("profile_{index}_id")),
            find(&profiles_truth, &format!("profile_{index}_id")),
            "indexed lines ride both encodings"
        );
    }
}

/// `--json` asks for JSON at hello and speaks JSON on the way in too: the proof is that a
/// daemon which only spoke records could not answer this client at all — and it does.
#[test]
fn a_json_cli_is_answered_by_a_json_session_end_to_end() {
    let daemon = spawn_daemon("cli-json-e2e");
    let address = format!("127.0.0.1:{}", daemon.port);

    let (code, stdout, stderr) = run_cli(&[
        "apply",
        "demo-tun-profile",
        "--idempotency-key",
        "cli-e2e-json",
        "--json",
        "--addr",
        &address,
    ]);
    assert_eq!(code, 0, "stderr: {stderr}");
    let facts = oracle_parse_flat_json(stdout.trim());
    let find = |key: &str| {
        facts
            .iter()
            .find(|(k, _)| k == key)
            .map(|(_, v)| v.clone())
            .unwrap_or_default()
    };
    assert!(
        !find("job_id").is_empty(),
        "the acceptance rides JSON too: {stdout}"
    );
    let job_id = find("job_id");

    let (code, stdout, stderr) = run_cli(&["job", &job_id, "--json", "--addr", &address]);
    assert_eq!(code, 0, "stderr: {stderr}");
    let summary = oracle_parse_flat_json(stdout.trim());
    let state = summary
        .iter()
        .find(|(k, _)| k == "state")
        .map(|(_, v)| v.clone())
        .unwrap_or_default();
    assert_eq!(
        state, "completed",
        "the whole verb surface speaks JSON: {stdout}"
    );
}

/// `caly follow <job>`: the lines it prints are exactly the lines `caly jobs` prints (two
/// verbs, one projection), the cursor works (`--from N` is the exclusive resume the events op
/// serves), and the exit code is the verdict.
#[test]
fn caly_follow_prints_what_jobs_prints_and_exits_by_the_verdict() {
    let daemon = spawn_daemon("cli-follow");
    let address = format!("127.0.0.1:{}", daemon.port);

    let (code, stdout, stderr) = run_cli(&[
        "apply",
        "demo-tun-profile",
        "--idempotency-key",
        "cli-e2e-follow",
        "--addr",
        &address,
    ]);
    assert_eq!(code, 0, "stderr: {stderr}");
    let job_id = stdout
        .lines()
        .find_map(|line| line.strip_prefix("job_id: "))
        .unwrap_or_default()
        .trim()
        .to_owned();

    let lines_of = |stdout: &str| -> Vec<String> {
        stdout
            .lines()
            .filter_map(|line| line.strip_prefix("  - "))
            .map(str::to_owned)
            .collect()
    };
    let (code, jobs_out, stderr) = run_cli(&["jobs", &job_id, "--addr", &address]);
    assert_eq!(code, 0, "stderr: {stderr}");
    let (code, follow_out, stderr) = run_cli(&["follow", &job_id, "--addr", &address]);
    assert_eq!(code, 0, "a succeeded job exits 0; stderr: {stderr}");
    assert_eq!(
        lines_of(&follow_out),
        lines_of(&jobs_out),
        "follow streams exactly what jobs pages — one projection, two verbs"
    );

    // The cursor: `--from N` is the exclusive resume (the same N `jobs --from` takes).
    let all = lines_of(&jobs_out);
    let (code, tail, stderr) = run_cli(&["follow", &job_id, "--from", "3", "--addr", &address]);
    assert_eq!(code, 0, "stderr: {stderr}");
    assert_eq!(
        lines_of(&tail),
        all[4..].to_vec(),
        "from=3 replays after event 3 — the cursor contract the events op serves"
    );

    // An unknown job: named on stderr, and the conversation disagrees (13).
    let (code, _out, stderr) = run_cli(&["follow", "424242", "--addr", &address]);
    assert_eq!(code, 13, "{stderr}");
    assert!(stderr.contains("424242"), "{stderr}");
}

/// A failed job's stream: the lines still flush (the failure is in the lines), and the exit
/// code is the verdict — 1, not 0. A rollback with no snapshot to roll back to is the honest
/// way to make a job fail over the wire.
#[test]
/// Round 116 (ADR-058): a failed job's stream exits with the job's public failure code —
/// the same number `caly job <id>` maps — instead of a blanket 1. The rollback with no
/// target fails with CONFLICT (exit 4) on both paths, human and `--json` alike; the END
/// frame's `failure_code` must appear in the `--json` frame for programs to read.
fn caly_follow_of_a_failed_job_exits_with_the_jobs_failure_code() {
    let daemon = spawn_daemon("cli-follow-failed-code");
    let address = format!("127.0.0.1:{}", daemon.port);

    let (code, stdout, stderr) = run_cli(&[
        "rollback",
        "--idempotency-key",
        "cli-e2e-fail",
        "--addr",
        &address,
    ]);
    assert_eq!(code, 0, "the rollback command itself is accepted: {stderr}");
    let job_id = stdout
        .lines()
        .find_map(|line| line.strip_prefix("job_id: "))
        .unwrap_or_default()
        .trim()
        .to_owned();

    // The one-shot view is the reference number for this job's failure.
    let (code, stdout, _stderr) = run_cli(&["job", &job_id, "--addr", &address]);
    assert_eq!(
        code, 4,
        "the one-shot view maps CONFLICT to 4: stdout={stdout}"
    );

    let (code, stdout, stderr) = run_cli(&["follow", &job_id, "--addr", &address]);
    assert_eq!(
        code, 4,
        "ADR-058: a streamed failure exits with the failure code's number (4), not a blanket 1; \
         stderr: {stderr}"
    );
    assert!(
        stdout.contains("[done] Failed"),
        "the verdict is in the flushed lines: {stdout}"
    );

    let (code, stdout, stderr) = run_cli(&["follow", &job_id, "--json", "--addr", &address]);
    assert_eq!(
        code, 4,
        "the --json render takes the same verdict as the human render; stderr: {stderr}"
    );
    assert!(
        stdout.contains("\"outcome\":\"Failed\"")
            && stdout.contains("\"failure_code\":\"CONFLICT\""),
        "the --json END frame carries the code for programs: {stdout}"
    );
}

/// The reconnect path from the client: `caly follow` acks what it printed (the confirmation
/// is the conversation's last frame), says its stream id on stderr, and `--resume <id>`
/// prints **nothing new** — the acked cursor is where the daemon picks up. A resume of an
/// unknown stream is a named refusal (13).
#[test]
fn caly_follow_acks_and_a_resume_prints_nothing_new() {
    let daemon = spawn_daemon("cli-resume");
    let address = format!("127.0.0.1:{}", daemon.port);

    let (code, stdout, stderr) = run_cli(&[
        "apply",
        "demo-tun-profile",
        "--idempotency-key",
        "cli-e2e-resume",
        "--addr",
        &address,
    ]);
    assert_eq!(code, 0, "stderr: {stderr}");
    let job_id = stdout
        .lines()
        .find_map(|line| line.strip_prefix("job_id: "))
        .unwrap_or_default()
        .trim()
        .to_owned();

    let (code, first, stderr) = run_cli(&["follow", &job_id, "--addr", &address]);
    assert_eq!(code, 0, "stderr: {stderr}");
    let printed = first
        .lines()
        .filter(|line| line.starts_with("  - "))
        .count();
    assert!(printed >= 6, "the fresh stream prints its lines: {first}");
    let stream_id = stderr
        .lines()
        .find_map(|line| line.strip_prefix("caly: stream "))
        .and_then(|line| line.split(' ').next())
        .unwrap_or_default()
        .to_owned();
    assert!(
        !stream_id.is_empty(),
        "the stream id rides stderr: {stderr}"
    );

    let (code, resumed, stderr) = run_cli(&["follow", "--resume", &stream_id, "--addr", &address]);
    assert_eq!(
        code, 0,
        "an acked-complete resume still exits 0; stderr: {stderr}"
    );
    assert!(
        resumed
            .lines()
            .filter(|line| line.starts_with("  - "))
            .count()
            == 0,
        "the acked cursor is where the daemon picks up — nothing repeats: {resumed}"
    );

    let (code, _out, stderr) = run_cli(&["follow", "--resume", "424242", "--addr", &address]);
    assert_eq!(code, 13, "{stderr}");
    assert!(stderr.contains("424242"), "{stderr}");
}

/// A fake daemon that answers hello with a hello_ack whose **content** contradicts the
/// session (round 71's judge): the CLI must refuse on what the ack says, not on the frame
/// kind — v0 believed the kind alone and never read the answer. `mismatch` names the lie:
/// "encoding" answers `encoding=msgpack` to a records session (which asked for records),
/// "protocol" answers major 2. If the client accepts the lie it sends a request next; the
/// fake rewards that bug with a successful-looking response, so the test observes the
/// outcome instead of a hang.
fn spawn_mismatching_daemon(mismatch: &str) -> u16 {
    let listener = TcpListener::bind("127.0.0.1:0").expect("bind fake daemon");
    let port = listener.local_addr().expect("port").port();
    let mismatch = mismatch.to_owned();
    std::thread::spawn(move || {
        let (mut stream, _) = listener.accept().expect("accept");
        let mut head = [0u8; 5];
        stream.read_exact(&mut head).expect("hello head");
        let mut hello =
            vec![0u8; u32::from_be_bytes([head[1], head[2], head[3], head[4]]) as usize];
        stream.read_exact(&mut hello).expect("hello body");
        let ack: &[u8] = match mismatch.as_str() {
            "encoding" => {
                b"daemon_name=fake\ndaemon_version=0\ninstance_id=fake\nmajor=1\nminor=0\nencoding=msgpack\ncompression=none"
            }
            _ => {
                b"daemon_name=fake\ndaemon_version=0\ninstance_id=fake\nmajor=2\nminor=0\nencoding=records\ncompression=none"
            }
        };
        let mut frame = vec![2u8];
        frame.extend_from_slice(&(ack.len() as u32).to_be_bytes());
        frame.extend_from_slice(ack);
        stream.write_all(&frame).expect("ack");
        // Only a client that accepted the lie reaches this point; answer it successfully.
        let mut request_head = [0u8; 5];
        if stream.read_exact(&mut request_head).is_ok() {
            let mut payload = vec![
                0u8;
                u32::from_be_bytes([
                    request_head[1],
                    request_head[2],
                    request_head[3],
                    request_head[4],
                ]) as usize
            ];
            let _ = stream.read_exact(&mut payload);
            let response = b"request_id=1";
            let mut frame = vec![4u8];
            frame.extend_from_slice(&(response.len() as u32).to_be_bytes());
            frame.extend_from_slice(response);
            let _ = stream.write_all(&frame);
        }
    });
    port
}

#[test]
fn caly_refuses_a_hello_ack_that_contradicts_the_session() {
    let port = spawn_mismatching_daemon("encoding");
    let (code, _stdout, stderr) = run_cli(&["status", "--addr", &format!("127.0.0.1:{port}")]);
    assert_eq!(code, 13, "an encoding lie is PROTO_MISMATCH: {stderr}");
    assert!(
        stderr.contains("encoding mismatch") && stderr.contains("msgpack"),
        "the refusal must name both sides: {stderr}"
    );

    let port = spawn_mismatching_daemon("protocol");
    let (code, _stdout, stderr) = run_cli(&["status", "--addr", &format!("127.0.0.1:{port}")]);
    assert_eq!(code, 13, "a protocol lie is PROTO_MISMATCH: {stderr}");
    assert!(
        stderr.contains("protocol mismatch") && stderr.contains("2"),
        "the refusal must name both majors: {stderr}"
    );
}

/// Round 87: `caly status --addr unix:<path>` against a UDS-bound calyd. The
/// printed facts must still be what the wire said; the transport is not a
/// second status verb.
#[cfg(unix)]
#[test]
fn caly_status_over_a_unix_domain_socket() {
    let daemon = spawn_daemon_unix("cli-uds");
    let address = format!("unix:{}", daemon.path);
    let (code, stdout, stderr) = run_cli(&["status", "--addr", &address]);
    assert_eq!(code, 0, "success is exit 0; stderr: {stderr}");
    assert!(
        stdout.contains("core_running: false"),
        "status over UDS must still print the runtime: {stdout}"
    );
    assert!(
        stderr.contains("caly: connected to calyd"),
        "handshake still prints the daemon identity: {stderr}"
    );
}

/// Round 91: a followed Job stream waits through silent ticks — a real core's spawn/probe can be
/// quiet for seconds while the daemon's pump emits nothing (an empty push would claim progress).
/// The stream's per-frame read deadline must be the stream's own (`STREAM_IDLE_TIMEOUT`, 30s), not
/// the 3s request/answer deadline: otherwise a healthy long job makes `caly follow` exit 11
/// (TIMEOUT) while the job is fine. The fake daemon opens the stream, stays silent for a gap LONGER
/// than the 3s op deadline but shorter than the 30s stream deadline, then pushes one data line and
/// a Succeeded end. Before the fix the CLI times out during the gap; after it the line is printed
/// and the verdict is exit 0. The silent-daemon exit-11 case (`a_silent_daemon_times_out...`) stays
/// covered by its own test — this is NOT "remove the timeout", it is "a stream waits on its scale".
#[test]
fn caly_follow_survives_a_silent_gap_longer_than_the_request_deadline() {
    let listener = TcpListener::bind("127.0.0.1:0").expect("bind fake daemon");
    let port = listener.local_addr().expect("port").port();
    let _server = std::thread::spawn(move || {
        let (mut stream, _) = listener.accept().expect("accept");
        // Consume hello, reply with a valid records hello_ack (the CLI validates it, round 71).
        let mut head = [0u8; 5];
        if stream.read_exact(&mut head).is_err() {
            return;
        }
        let mut hello =
            vec![0u8; u32::from_be_bytes([head[1], head[2], head[3], head[4]]) as usize];
        if stream.read_exact(&mut hello).is_err() {
            return;
        }
        let ack = b"daemon_name=fake\ndaemon_version=0\ninstance_id=fake\nmajor=1\nminor=0\nencoding=records\ncompression=none";
        let mut frame = vec![2u8]; // hello_ack
        frame.extend_from_slice(&(ack.len() as u32).to_be_bytes());
        frame.extend_from_slice(ack);
        if stream.write_all(&frame).is_err() {
            return;
        }
        // Consume the follow-stream open request.
        let mut req_head = [0u8; 5];
        if stream.read_exact(&mut req_head).is_err() {
            return;
        }
        let mut req = vec![
            0u8;
            u32::from_be_bytes([req_head[1], req_head[2], req_head[3], req_head[4]])
                as usize
        ];
        let _ = stream.read_exact(&mut req);

        // Opened frame (response, kind 4): the CLI widens to the stream deadline when it reads it.
        let opened = b"request_id=1\nstream_id=7\nresumed=false";
        let mut frame = vec![4u8];
        frame.extend_from_slice(&(opened.len() as u32).to_be_bytes());
        frame.extend_from_slice(opened);
        if stream.write_all(&frame).is_err() {
            return;
        }

        // The silent gap: LONGER than the 3s op deadline, SHORTER than the 30s stream deadline.
        std::thread::sleep(Duration::from_secs(4));

        // One data line (kind 6) then a Succeeded end (kind 7).
        let data = b"stream_id=7\nnext_event_index=1\nevent_0=%5Bdone%5D%20Succeeded";
        let mut frame = vec![6u8];
        frame.extend_from_slice(&(data.len() as u32).to_be_bytes());
        frame.extend_from_slice(data);
        if stream.write_all(&frame).is_err() {
            return;
        }
        let end = b"stream_id=7\noutcome=Succeeded";
        let mut frame = vec![7u8];
        frame.extend_from_slice(&(end.len() as u32).to_be_bytes());
        frame.extend_from_slice(end);
        if stream.write_all(&frame).is_err() {
            return;
        }
        // The CLI acks the consumed cursor once at end of stream, then waits for the daemon's
        // confirmation (the conversation's last frame) before exiting. Read the ack and confirm
        // it — dropping the connection here would give the CLI a broken pipe instead of exit 0.
        let mut ack_head = [0u8; 5];
        if stream.read_exact(&mut ack_head).is_ok() {
            let ack_kind = ack_head[0];
            let mut ack = vec![
                0u8;
                u32::from_be_bytes([ack_head[1], ack_head[2], ack_head[3], ack_head[4]])
                    as usize
            ];
            let _ = stream.read_exact(&mut ack);
            if ack_kind == 8 {
                // KIND_STREAM_ACK (8): confirm with a response frame naming the acked cursor.
                let confirm = b"stream_id=7\nacked_upto=1";
                let mut frame = vec![4u8];
                frame.extend_from_slice(&(confirm.len() as u32).to_be_bytes());
                frame.extend_from_slice(confirm);
                let _ = stream.write_all(&frame);
            }
        }
    });

    let started = Instant::now();
    let (code, stdout, stderr) = run_cli(&["follow", "1", "--addr", &format!("127.0.0.1:{port}")]);
    // It must wait through the 4s gap and succeed — not return at the 3s op timeout.
    assert!(
        started.elapsed() >= Duration::from_secs(4),
        "the judge must really traverse the silent gap, not race it; stderr: {stderr}"
    );
    assert_eq!(
        code, 0,
        "a follow must not time out on a silent gap shorter than the stream deadline; stderr: {stderr}"
    );
    assert!(
        stdout.contains("Succeeded") || stdout.contains("[done]"),
        "the data line after the gap must be printed: {stdout}"
    );
}

/// Round 94: a response/refusal is only THIS verb's answer if it carries the request id the
/// verb sent. v0 has one outstanding request per session and the daemon echoes that id; the CLI
/// used to accept any RESPONSE/REFUSAL frame kind without reading the correlation id (the same
/// "believe the kind, never read the content" shape round 71 closed for the handshake). A peer
/// that answers with a foreign id (a stale/misrouted frame) must not be printed as the answer —
/// it is a protocol disagreement (exit 13), and the failure names both ids.
#[test]
fn a_response_with_a_foreign_request_id_is_refused_not_printed_as_the_answer() {
    let listener = TcpListener::bind("127.0.0.1:0").expect("bind fake daemon");
    let port = listener.local_addr().expect("port").port();
    let _server = std::thread::spawn(move || {
        let (mut stream, _) = listener.accept().expect("accept");
        let mut head = [0u8; 5];
        if stream.read_exact(&mut head).is_err() {
            return;
        }
        let mut hello =
            vec![0u8; u32::from_be_bytes([head[1], head[2], head[3], head[4]]) as usize];
        if stream.read_exact(&mut hello).is_err() {
            return;
        }
        let ack = b"daemon_name=fake\ndaemon_version=0\ninstance_id=fake\nmajor=1\nminor=0\nencoding=records\ncompression=none";
        let mut frame = vec![2u8]; // hello_ack
        frame.extend_from_slice(&(ack.len() as u32).to_be_bytes());
        frame.extend_from_slice(ack);
        if stream.write_all(&frame).is_err() {
            return;
        }
        // Consume the request.
        let mut req_head = [0u8; 5];
        if stream.read_exact(&mut req_head).is_err() {
            return;
        }
        let mut req = vec![
            0u8;
            u32::from_be_bytes([req_head[1], req_head[2], req_head[3], req_head[4]])
                as usize
        ];
        let _ = stream.read_exact(&mut req);

        // Answer with a FOREIGN request id (999) — a stale/misrouted frame, not this verb's answer.
        let bogus = b"request_id=999\ncore_running=true";
        let mut frame = vec![4u8]; // response
        frame.extend_from_slice(&(bogus.len() as u32).to_be_bytes());
        frame.extend_from_slice(bogus);
        let _ = stream.write_all(&frame);
        std::thread::sleep(Duration::from_secs(5));
    });

    let (code, stdout, stderr) = run_cli(&["status", "--addr", &format!("127.0.0.1:{port}")]);
    assert_eq!(
        code, 13,
        "a foreign-id answer is PROTO_MISMATCH (13), not the answer: stdout={stdout} stderr={stderr}"
    );
    assert!(
        stderr.contains("request id") && stderr.contains("999"),
        "the failure must name the foreign id and the correlation rule: {stderr}"
    );
    assert!(
        !stdout.contains("core_running: true"),
        "the misrouted frame's facts must not be printed as the status answer: {stdout}"
    );
}

/// The correlate half of round 94: a response that DOES carry the sent id is accepted (the check
/// is a correlation check, not a refusal of every answer). The real-daemon e2e suite already
/// exercises happy answers at length; this pins the in-range case against the fake daemon shape
/// so a future change that rejects every non-empty id would fail here too.
#[test]
fn a_response_with_the_sent_request_id_is_accepted() {
    let listener = TcpListener::bind("127.0.0.1:0").expect("bind fake daemon");
    let port = listener.local_addr().expect("port").port();
    let _server = std::thread::spawn(move || {
        let (mut stream, _) = listener.accept().expect("accept");
        let mut head = [0u8; 5];
        if stream.read_exact(&mut head).is_err() {
            return;
        }
        let mut hello =
            vec![0u8; u32::from_be_bytes([head[1], head[2], head[3], head[4]]) as usize];
        if stream.read_exact(&mut hello).is_err() {
            return;
        }
        let ack = b"daemon_name=fake\ndaemon_version=0\ninstance_id=fake\nmajor=1\nminor=0\nencoding=records\ncompression=none";
        let mut frame = vec![2u8];
        frame.extend_from_slice(&(ack.len() as u32).to_be_bytes());
        frame.extend_from_slice(ack);
        if stream.write_all(&frame).is_err() {
            return;
        }
        let mut req_head = [0u8; 5];
        if stream.read_exact(&mut req_head).is_err() {
            return;
        }
        let mut req = vec![
            0u8;
            u32::from_be_bytes([req_head[1], req_head[2], req_head[3], req_head[4]])
                as usize
        ];
        let _ = stream.read_exact(&mut req);

        // The sent id (1) echoed back: this IS the answer.
        let answer = b"request_id=1\ncore_running=false";
        let mut frame = vec![4u8];
        frame.extend_from_slice(&(answer.len() as u32).to_be_bytes());
        frame.extend_from_slice(answer);
        let _ = stream.write_all(&frame);
        std::thread::sleep(Duration::from_secs(5));
    });

    let (code, stdout, stderr) = run_cli(&["status", "--addr", &format!("127.0.0.1:{port}")]);
    assert_eq!(
        code, 0,
        "a correctly-correlated answer is success: {stderr}"
    );
    assert!(
        stdout.contains("core_running: false"),
        "the correlated answer must be printed: {stdout}"
    );
}

/// Round 94, missing-id half: a response that carries NO `request_id` at all is not this verb's
/// answer either — the correlation id is part of the answer, and its absence is a protocol
/// disagreement (exit 13), not an answer to print. Without this, defaulting an unparseable/missing
/// id to the sent value (`.or(Some(REQUEST_ID))`) would silently accept an answer that forgot to
/// say which request it answers.
#[test]
fn a_response_with_no_request_id_is_refused_not_printed_as_the_answer() {
    let listener = TcpListener::bind("127.0.0.1:0").expect("bind fake daemon");
    let port = listener.local_addr().expect("port").port();
    let _server = std::thread::spawn(move || {
        let (mut stream, _) = listener.accept().expect("accept");
        let mut head = [0u8; 5];
        if stream.read_exact(&mut head).is_err() {
            return;
        }
        let mut hello =
            vec![0u8; u32::from_be_bytes([head[1], head[2], head[3], head[4]]) as usize];
        if stream.read_exact(&mut hello).is_err() {
            return;
        }
        let ack = b"daemon_name=fake\ndaemon_version=0\ninstance_id=fake\nmajor=1\nminor=0\nencoding=records\ncompression=none";
        let mut frame = vec![2u8];
        frame.extend_from_slice(&(ack.len() as u32).to_be_bytes());
        frame.extend_from_slice(ack);
        if stream.write_all(&frame).is_err() {
            return;
        }
        let mut req_head = [0u8; 5];
        if stream.read_exact(&mut req_head).is_err() {
            return;
        }
        let mut req = vec![
            0u8;
            u32::from_be_bytes([req_head[1], req_head[2], req_head[3], req_head[4]])
                as usize
        ];
        let _ = stream.read_exact(&mut req);

        // A response frame with facts but NO request_id record.
        let answer = b"core_running=true\nactive_profile=demo";
        let mut frame = vec![4u8];
        frame.extend_from_slice(&(answer.len() as u32).to_be_bytes());
        frame.extend_from_slice(answer);
        let _ = stream.write_all(&frame);
        std::thread::sleep(Duration::from_secs(5));
    });

    let (code, stdout, stderr) = run_cli(&["status", "--addr", &format!("127.0.0.1:{port}")]);
    assert_eq!(
        code, 13,
        "an answer with no correlation id is PROTO_MISMATCH (13): stdout={stdout} stderr={stderr}"
    );
    assert!(
        !stdout.contains("core_running: true"),
        "the uncorrelated frame's facts must not be printed: {stdout}"
    );
    assert!(
        stderr.contains("request id"),
        "the failure must name the correlation rule: {stderr}"
    );
}

/// Round 95: a follow stream's data/end frames are only THIS follow's frames if they carry the
/// stream id the opened frame named. The wire multiplexes streams on one session, so a frame for
/// a DIFFERENT stream can legally arrive; the follow path used to believe the frame kind and never
/// read `stream_id` (the stream-shaped cousin of the request_id hole round 94 closed on the
/// request/answer path). Here the opened frame names stream 7 but the DATA frame carries 999 with
/// a foreign event line: that line must not be printed and the follow fails as PROTO_MISMATCH (13).
#[test]
fn a_follow_data_frame_with_a_foreign_stream_id_is_refused_not_printed() {
    let listener = TcpListener::bind("127.0.0.1:0").expect("bind fake daemon");
    let port = listener.local_addr().expect("port").port();
    let _server = std::thread::spawn(move || {
        let (mut stream, _) = listener.accept().expect("accept");
        if read_hello(&mut stream).is_none() {
            return;
        }
        if write_hello_ack(&mut stream).is_err() {
            return;
        }
        if read_request(&mut stream).is_none() {
            return;
        }
        // Opened frame (response, kind 4) names stream 7.
        if write_frame(&mut stream, 4, b"request_id=1\nstream_id=7\nresumed=false").is_err() {
            return;
        }
        // A DATA frame (kind 6) for a DIFFERENT stream (999) carrying a foreign event line.
        if write_frame(
            &mut stream,
            6,
            b"stream_id=999\nnext_event_index=1\nevent_0=FOREIGN-STREAM-EVENT",
        )
        .is_err()
        {
            return;
        }
        std::thread::sleep(Duration::from_secs(5));
    });

    let (code, stdout, stderr) = run_cli(&["follow", "1", "--addr", &format!("127.0.0.1:{port}")]);
    assert_eq!(
        code, 13,
        "a foreign-stream data frame is PROTO_MISMATCH (13), not this stream's event: stdout={stdout} stderr={stderr}"
    );
    assert!(
        !stdout.contains("FOREIGN-STREAM-EVENT"),
        "the foreign stream's event must never be printed: {stdout}"
    );
    assert!(
        stderr.contains("stream") && stderr.contains("999") && stderr.contains("7"),
        "the failure must name the foreign stream and the opened one: {stderr}"
    );
}

/// Round 95, verdict half: a STREAM_END frame decides the follow's exit code (Succeeded 0, Failed
/// 1, Cancelled 15, TimedOut 11). If the end frame carries a foreign stream id, its `outcome`
/// must NOT set the verdict — otherwise a misrouted frame from another stream could report a
/// failed job as success. The opened frame names 7, a foreign end (999, outcome=Succeeded) must
/// fail as PROTO_MISMATCH (13) instead of exit 0.
#[test]
fn a_follow_end_frame_with_a_foreign_stream_id_does_not_set_the_verdict() {
    let listener = TcpListener::bind("127.0.0.1:0").expect("bind fake daemon");
    let port = listener.local_addr().expect("port").port();
    let _server = std::thread::spawn(move || {
        let (mut stream, _) = listener.accept().expect("accept");
        if read_hello(&mut stream).is_none() {
            return;
        }
        if write_hello_ack(&mut stream).is_err() {
            return;
        }
        if read_request(&mut stream).is_none() {
            return;
        }
        if write_frame(&mut stream, 4, b"request_id=1\nstream_id=7\nresumed=false").is_err() {
            return;
        }
        // A correctly-correlated data frame first (proves data is fine), then a foreign END.
        if write_frame(
            &mut stream,
            6,
            b"stream_id=7\nnext_event_index=1\nevent_0=%5Bstart%5D",
        )
        .is_err()
        {
            return;
        }
        // An END frame (kind 7) for a DIFFERENT stream (999) claiming Succeeded.
        if write_frame(&mut stream, 7, b"stream_id=999\noutcome=Succeeded").is_err() {
            return;
        }
        std::thread::sleep(Duration::from_secs(5));
    });

    let (code, _stdout, stderr) = run_cli(&["follow", "1", "--addr", &format!("127.0.0.1:{port}")]);
    assert_eq!(
        code, 13,
        "a foreign-stream end frame must not decide the verdict; PROTO_MISMATCH (13), not 0: stderr={stderr}"
    );
    assert!(
        stderr.contains("999") && stderr.contains("7"),
        "the failure must name the foreign stream and the opened one: {stderr}"
    );
}

/// Round 95, happy half (anti-vacuous): frames whose stream id matches the opened frame are
/// accepted and the verdict is the end frame's outcome. Stream 7 opened, a 7 data line prints and
/// a 7 Succeeded end exits 0 — the same fake-daemon conversation the correlation must not reject.
#[test]
fn a_follow_data_and_end_with_the_opened_stream_id_are_accepted() {
    let listener = TcpListener::bind("127.0.0.1:0").expect("bind fake daemon");
    let port = listener.local_addr().expect("port").port();
    let _server = std::thread::spawn(move || {
        let (mut stream, _) = listener.accept().expect("accept");
        if read_hello(&mut stream).is_none() {
            return;
        }
        if write_hello_ack(&mut stream).is_err() {
            return;
        }
        if read_request(&mut stream).is_none() {
            return;
        }
        if write_frame(&mut stream, 4, b"request_id=1\nstream_id=7\nresumed=false").is_err() {
            return;
        }
        if write_frame(
            &mut stream,
            6,
            b"stream_id=7\nnext_event_index=1\nevent_0=%5Bdone%5D%20Succeeded",
        )
        .is_err()
        {
            return;
        }
        if write_frame(&mut stream, 7, b"stream_id=7\noutcome=Succeeded").is_err() {
            return;
        }
        // The CLI acks the consumed cursor then waits for the daemon's confirmation (the
        // conversation's last frame); read the ack and confirm so the CLI exits 0, not broken pipe.
        if let Some(kind) = read_ack(&mut stream) {
            if kind == 8 {
                let _ = write_frame(&mut stream, 4, b"stream_id=7\nacked_upto=1");
            }
        }
        std::thread::sleep(Duration::from_secs(2));
    });

    let (code, stdout, stderr) = run_cli(&["follow", "1", "--addr", &format!("127.0.0.1:{port}")]);
    assert_eq!(
        code, 0,
        "a correctly-correlated stream must succeed: stdout={stdout} stderr={stderr}"
    );
    assert!(
        stdout.contains("Succeeded") || stdout.contains("[done]"),
        "the matched stream's data line must be printed: {stdout}"
    );
}

// --- Round 95 fake-daemon follow helpers (small framed-conversation I/O used by the tests above) ---

/// Read a hello frame; returns None if the peer closed or the frame is malformed.
fn read_hello(stream: &mut std::net::TcpStream) -> Option<()> {
    let mut head = [0u8; 5];
    stream.read_exact(&mut head).ok()?;
    let len = u32::from_be_bytes([head[1], head[2], head[3], head[4]]) as usize;
    let mut body = vec![0u8; len];
    stream.read_exact(&mut body).ok()?;
    Some(())
}

/// Read a request frame (the follow-stream open); returns None if the peer closed.
fn read_request(stream: &mut std::net::TcpStream) -> Option<()> {
    read_hello(stream)
}

/// Read an ack frame; returns its frame kind if the client sent one.
fn read_ack(stream: &mut std::net::TcpStream) -> Option<u8> {
    let mut head = [0u8; 5];
    stream.read_exact(&mut head).ok()?;
    let kind = head[0];
    let len = u32::from_be_bytes([head[1], head[2], head[3], head[4]]) as usize;
    let mut body = vec![0u8; len];
    let _ = stream.read_exact(&mut body);
    Some(kind)
}

/// Write a records hello_ack frame valid for round 71's handshake check.
fn write_hello_ack(stream: &mut std::net::TcpStream) -> std::io::Result<()> {
    write_frame(
        stream,
        2,
        b"daemon_name=fake\ndaemon_version=0\ninstance_id=fake\nmajor=1\nminor=0\nencoding=records\ncompression=none",
    )
    .map(|_| ())
}

/// Write one length-prefixed wire frame: 1-byte kind then 4-byte big-endian length then body.
fn write_frame(stream: &mut std::net::TcpStream, kind: u8, body: &[u8]) -> std::io::Result<()> {
    let mut frame = vec![kind];
    frame.extend_from_slice(&(body.len() as u32).to_be_bytes());
    frame.extend_from_slice(body);
    stream.write_all(&frame)
}

/// Round 96, resume half: `caly follow --resume <id>` names the stream the daemon must
/// reconnect. The opened frame must echo that SAME id and flag `resumed=true`; a daemon that
/// opens a DIFFERENT stream (id 9) for a `--resume 7` request is misrouted, and treating that as
/// a successful resume would reconnect at the wrong cursor. It must be a PROTO_MISMATCH (13).
#[test]
fn a_resume_opening_a_different_stream_is_refused() {
    let listener = TcpListener::bind("127.0.0.1:0").expect("bind fake daemon");
    let port = listener.local_addr().expect("port").port();
    let _server = std::thread::spawn(move || {
        let (mut stream, _) = listener.accept().expect("accept");
        if read_hello(&mut stream).is_none() {
            return;
        }
        if write_hello_ack(&mut stream).is_err() {
            return;
        }
        if read_request(&mut stream).is_none() {
            return;
        }
        // The client asked to resume stream 7; lie by opening a DIFFERENT stream (9), flagged as
        // resumed so only the id mismatch is under test. Then complete stream 9 normally (the
        // data/end carry 9, matching the opened id) so that if the resume-id check were dropped
        // the CLI would follow stream 9 and exit 0 instead of failing at the opened frame.
        if write_frame(&mut stream, 4, b"request_id=1\nstream_id=9\nresumed=true").is_err() {
            return;
        }
        if write_frame(
            &mut stream,
            6,
            b"stream_id=9\nnext_event_index=1\nevent_0=%5Bdone%5D",
        )
        .is_err()
        {
            return;
        }
        if write_frame(&mut stream, 7, b"stream_id=9\noutcome=Succeeded").is_err() {
            return;
        }
        if let Some(kind) = read_ack(&mut stream) {
            if kind == 8 {
                let _ = write_frame(&mut stream, 4, b"stream_id=9\nacked_upto=1");
            }
        }
        std::thread::sleep(Duration::from_secs(2));
    });

    let (code, _stdout, stderr) = run_cli(&[
        "follow",
        "--resume",
        "7",
        "--addr",
        &format!("127.0.0.1:{port}"),
    ]);
    assert_eq!(
        code, 13,
        "an opened frame naming a different stream than --resume is PROTO_MISMATCH (13): stderr={stderr}"
    );
    assert!(
        stderr.contains("7") && stderr.contains("9") && stderr.contains("resume"),
        "the failure must name the requested id 7, the opened id 9, and the resume rule: {stderr}"
    );
}

/// Round 96, resume-flag half: a `--resume 7` must be answered with `resumed=true`. If the daemon
/// opens stream 7 but flags it as a FRESH open (`resumed=false`), it is not the resumption asked
/// for — the client must refuse rather than silently treat a fresh stream as the resumed cursor.
#[test]
fn a_resume_opened_without_the_resumed_flag_is_refused() {
    let listener = TcpListener::bind("127.0.0.1:0").expect("bind fake daemon");
    let port = listener.local_addr().expect("port").port();
    let _server = std::thread::spawn(move || {
        let (mut stream, _) = listener.accept().expect("accept");
        if read_hello(&mut stream).is_none() {
            return;
        }
        if write_hello_ack(&mut stream).is_err() {
            return;
        }
        if read_request(&mut stream).is_none() {
            return;
        }
        // Right id (7), but flagged as a FRESH open, not a resumption. Then complete the
        // stream normally (data + Succeeded end) so that, if the resumed-flag check were
        // dropped, the CLI would accept it and exit 0 instead of failing at the opened frame.
        if write_frame(&mut stream, 4, b"request_id=1\nstream_id=7\nresumed=false").is_err() {
            return;
        }
        if write_frame(
            &mut stream,
            6,
            b"stream_id=7\nnext_event_index=1\nevent_0=%5Bdone%5D",
        )
        .is_err()
        {
            return;
        }
        if write_frame(&mut stream, 7, b"stream_id=7\noutcome=Succeeded").is_err() {
            return;
        }
        if let Some(kind) = read_ack(&mut stream) {
            if kind == 8 {
                let _ = write_frame(&mut stream, 4, b"stream_id=7\nacked_upto=1");
            }
        }
        std::thread::sleep(Duration::from_secs(2));
    });

    let (code, _stdout, stderr) = run_cli(&[
        "follow",
        "--resume",
        "7",
        "--addr",
        &format!("127.0.0.1:{port}"),
    ]);
    assert_eq!(
        code, 13,
        "an opened frame that matches the id but is not flagged resumed is PROTO_MISMATCH (13): stderr={stderr}"
    );
    assert!(
        stderr.contains("resumed"),
        "the failure must name the resumed flag: {stderr}"
    );
}

/// Round 96, resume happy half (anti-vacuity): a resume whose opened frame echoes the requested
/// id with `resumed=true` is accepted — a correct resumption must not be refused. The daemon
/// immediately ends (nothing new to replay), the client acks the (empty) cursor and exits 0.
#[test]
fn a_resume_opening_the_requested_stream_flagged_resumed_is_accepted() {
    let listener = TcpListener::bind("127.0.0.1:0").expect("bind fake daemon");
    let port = listener.local_addr().expect("port").port();
    let _server = std::thread::spawn(move || {
        let (mut stream, _) = listener.accept().expect("accept");
        if read_hello(&mut stream).is_none() {
            return;
        }
        if write_hello_ack(&mut stream).is_err() {
            return;
        }
        if read_request(&mut stream).is_none() {
            return;
        }
        // Opened frame: right id and resumed=true.
        if write_frame(&mut stream, 4, b"request_id=1\nstream_id=7\nresumed=true").is_err() {
            return;
        }
        // A Succeeded end for the same stream (nothing to replay).
        if write_frame(&mut stream, 7, b"stream_id=7\noutcome=Succeeded").is_err() {
            return;
        }
        // Read the ack and confirm it for the same stream (the conversation's last frame).
        if let Some(kind) = read_ack(&mut stream) {
            if kind == 8 {
                let _ = write_frame(&mut stream, 4, b"stream_id=7\nacked_upto=0");
            }
        }
        std::thread::sleep(Duration::from_secs(2));
    });

    let (code, _stdout, stderr) = run_cli(&[
        "follow",
        "--resume",
        "7",
        "--addr",
        &format!("127.0.0.1:{port}"),
    ]);
    assert_eq!(
        code, 0,
        "a correctly-correlated resume must succeed (anti-vacuity): stderr={stderr}"
    );
}

/// Round 96, ack-confirmation half: after the client sends a STREAM_ACK for stream 7, the
/// confirmation frame must be for stream 7 too. A confirmation that names a DIFFERENT stream (9)
/// but happens to echo the matching `acked_upto` is not proof that stream 7's cursor landed —
/// the client must refuse it (PROTO_MISMATCH 13) rather than trust the resume position.
#[test]
fn an_ack_confirmation_for_a_different_stream_is_refused() {
    let listener = TcpListener::bind("127.0.0.1:0").expect("bind fake daemon");
    let port = listener.local_addr().expect("port").port();
    let _server = std::thread::spawn(move || {
        let (mut stream, _) = listener.accept().expect("accept");
        if read_hello(&mut stream).is_none() {
            return;
        }
        if write_hello_ack(&mut stream).is_err() {
            return;
        }
        if read_request(&mut stream).is_none() {
            return;
        }
        // Open stream 7, one data frame (cursor -> 1), then a Succeeded end.
        if write_frame(&mut stream, 4, b"request_id=1\nstream_id=7\nresumed=false").is_err() {
            return;
        }
        if write_frame(
            &mut stream,
            6,
            b"stream_id=7\nnext_event_index=1\nevent_0=%5Bdone%5D",
        )
        .is_err()
        {
            return;
        }
        if write_frame(&mut stream, 7, b"stream_id=7\noutcome=Succeeded").is_err() {
            return;
        }
        // The client acks stream 7 cursor 1; confirm for a DIFFERENT stream (9) but echo the same
        // acked_upto (1) so only the stream_id correlation is under test.
        if let Some(kind) = read_ack(&mut stream) {
            if kind == 8 {
                let _ = write_frame(&mut stream, 4, b"stream_id=9\nacked_upto=1");
            }
        }
        std::thread::sleep(Duration::from_secs(2));
    });

    let (code, _stdout, stderr) = run_cli(&["follow", "1", "--addr", &format!("127.0.0.1:{port}")]);
    assert_eq!(
        code, 13,
        "an ack confirmation for a different stream is PROTO_MISMATCH (13): stderr={stderr}"
    );
    assert!(
        stderr.contains("9") && stderr.contains("7"),
        "the failure must name the confirmed stream 9 and the acked stream 7: {stderr}"
    );
}

/// Round 97: the follow OPENED frame is the follow request's direct answer and the daemon echoes
/// that request's `request_id` (the client sends 1). Round 94 made `ask` correlate a response by
/// request_id but the follow path's opened frame was only checked for stream_id/resumed — a
/// response carrying a valid stream but a FOREIGN request id was accepted as this follow's open.
/// Here the opened frame says request_id=999 (but a fine stream 7): it must be refused (13), not
/// followed.
#[test]
fn a_follow_opened_frame_with_a_foreign_request_id_is_refused() {
    let listener = TcpListener::bind("127.0.0.1:0").expect("bind fake daemon");
    let port = listener.local_addr().expect("port").port();
    let _server = std::thread::spawn(move || {
        let (mut stream, _) = listener.accept().expect("accept");
        if read_hello(&mut stream).is_none() {
            return;
        }
        if write_hello_ack(&mut stream).is_err() {
            return;
        }
        if read_request(&mut stream).is_none() {
            return;
        }
        // Opened frame: a valid stream (7) but a FOREIGN request id (999). Then complete stream 7
        // normally so that, without the request_id check, the CLI would follow it to exit 0.
        if write_frame(
            &mut stream,
            4,
            b"request_id=999\nstream_id=7\nresumed=false",
        )
        .is_err()
        {
            return;
        }
        if write_frame(
            &mut stream,
            6,
            b"stream_id=7\nnext_event_index=1\nevent_0=FOREIGN-REQUEST-OPEN",
        )
        .is_err()
        {
            return;
        }
        if write_frame(&mut stream, 7, b"stream_id=7\noutcome=Succeeded").is_err() {
            return;
        }
        if let Some(kind) = read_ack(&mut stream) {
            if kind == 8 {
                let _ = write_frame(&mut stream, 4, b"stream_id=7\nacked_upto=1");
            }
        }
        std::thread::sleep(Duration::from_secs(2));
    });

    let (code, stdout, stderr) = run_cli(&["follow", "1", "--addr", &format!("127.0.0.1:{port}")]);
    assert_eq!(
        code, 13,
        "an opened frame with a foreign request_id is PROTO_MISMATCH (13), not this follow: stdout={stdout} stderr={stderr}"
    );
    assert!(
        !stdout.contains("FOREIGN-REQUEST-OPEN"),
        "the foreign-request opened stream must never be followed/printed: {stdout}"
    );
    assert!(
        stderr.contains("999") && stderr.contains("request"),
        "the failure must name the foreign request id and the correlation rule: {stderr}"
    );
}

/// Round 97, missing-id half: an opened frame that carries a valid stream but NO request_id is not
/// the follow request's answer either (a missing id parses to None != Some(1)). It must be refused.
#[test]
fn a_follow_opened_frame_with_no_request_id_is_refused() {
    let listener = TcpListener::bind("127.0.0.1:0").expect("bind fake daemon");
    let port = listener.local_addr().expect("port").port();
    let _server = std::thread::spawn(move || {
        let (mut stream, _) = listener.accept().expect("accept");
        if read_hello(&mut stream).is_none() {
            return;
        }
        if write_hello_ack(&mut stream).is_err() {
            return;
        }
        if read_request(&mut stream).is_none() {
            return;
        }
        // Opened frame: a valid stream (7) but NO request_id record.
        if write_frame(&mut stream, 4, b"stream_id=7\nresumed=false").is_err() {
            return;
        }
        if write_frame(
            &mut stream,
            6,
            b"stream_id=7\nnext_event_index=1\nevent_0=NO-REQUEST-OPEN",
        )
        .is_err()
        {
            return;
        }
        if write_frame(&mut stream, 7, b"stream_id=7\noutcome=Succeeded").is_err() {
            return;
        }
        std::thread::sleep(Duration::from_secs(2));
    });

    let (code, stdout, stderr) = run_cli(&["follow", "1", "--addr", &format!("127.0.0.1:{port}")]);
    assert_eq!(
        code, 13,
        "an opened frame with no request_id is PROTO_MISMATCH (13): stdout={stdout} stderr={stderr}"
    );
    assert!(
        !stdout.contains("NO-REQUEST-OPEN"),
        "the uncorrelated opened stream must not be followed: {stdout}"
    );
    assert!(
        stderr.contains("request"),
        "the failure must name the request-id correlation rule: {stderr}"
    );
}

/// Round 97, happy half (anti-vacuity): an opened frame that echoes the sent request id (1) with a
/// valid stream is accepted and followed to the verdict — the request_id check must not reject a
/// correctly-correlated open.
#[test]
fn a_follow_opened_frame_with_the_sent_request_id_is_accepted() {
    let listener = TcpListener::bind("127.0.0.1:0").expect("bind fake daemon");
    let port = listener.local_addr().expect("port").port();
    let _server = std::thread::spawn(move || {
        let (mut stream, _) = listener.accept().expect("accept");
        if read_hello(&mut stream).is_none() {
            return;
        }
        if write_hello_ack(&mut stream).is_err() {
            return;
        }
        if read_request(&mut stream).is_none() {
            return;
        }
        // Opened frame echoes the sent request id 1.
        if write_frame(&mut stream, 4, b"request_id=1\nstream_id=7\nresumed=false").is_err() {
            return;
        }
        if write_frame(
            &mut stream,
            6,
            b"stream_id=7\nnext_event_index=1\nevent_0=%5Bdone%5D%20Succeeded",
        )
        .is_err()
        {
            return;
        }
        if write_frame(&mut stream, 7, b"stream_id=7\noutcome=Succeeded").is_err() {
            return;
        }
        if let Some(kind) = read_ack(&mut stream) {
            if kind == 8 {
                let _ = write_frame(&mut stream, 4, b"stream_id=7\nacked_upto=1");
            }
        }
        std::thread::sleep(Duration::from_secs(2));
    });

    let (code, stdout, stderr) = run_cli(&["follow", "1", "--addr", &format!("127.0.0.1:{port}")]);
    assert_eq!(
        code, 0,
        "a correctly request-id-correlated open must be followed to success: stdout={stdout} stderr={stderr}"
    );
    assert!(
        stdout.contains("Succeeded") || stdout.contains("[done]"),
        "the matched stream's data line must be printed: {stdout}"
    );
}

/// Round 98: a one-shot verb's REFUSAL carries the daemon's stable public code, and the CLI must
/// map it to its documented exit number (docs/guides/EXIT_CODES.md §4.1), not collapse it to PROTO_MISMATCH.
/// A `PERMISSION` refusal must exit 8 (not 13): a script/CI can then tell "you may not" from
/// "the daemon and CLI cannot talk". The fake daemon answers `status` with a correlated REFUSAL.
#[test]
fn a_permission_refusal_maps_to_exit_8_not_protocol_mismatch() {
    let listener = TcpListener::bind("127.0.0.1:0").expect("bind fake daemon");
    let port = listener.local_addr().expect("port").port();
    let _server = std::thread::spawn(move || {
        let (mut stream, _) = listener.accept().expect("accept");
        if read_hello(&mut stream).is_none() {
            return;
        }
        if write_hello_ack(&mut stream).is_err() {
            return;
        }
        if read_request(&mut stream).is_none() {
            return;
        }
        // A correlated REFUSAL (request_id=1) carrying a stable public business code.
        if write_frame(
            &mut stream,
            5,
            b"request_id=1\ncode=PERMISSION\nsummary=role Viewer may not read runtime",
        )
        .is_err()
        {
            return;
        }
        std::thread::sleep(Duration::from_secs(2));
    });

    let (code, stdout, stderr) = run_cli(&["status", "--addr", &format!("127.0.0.1:{port}")]);
    assert_eq!(
        code, 8,
        "a PERMISSION refusal is exit 8 (PERMISSION), not 13 (PROTO_MISMATCH): stdout={stdout} stderr={stderr}"
    );
    assert!(
        !stdout.contains("core_running"),
        "a refusal prints no facts: {stdout}"
    );
    assert!(
        stderr.contains("PERMISSION"),
        "the wire code must travel to stderr: {stderr}"
    );
}

/// Round 98, transport-code half: a refusal whose code is a wire/session code (NOT_FOUND is the
/// frame loop's reply to an unknown stream, not a public ApiError code) still means the CLI and
/// daemon disagree about the conversation -> PROTO_MISMATCH (13).
#[test]
fn a_transport_layer_refusal_code_still_maps_to_protocol_mismatch() {
    let listener = TcpListener::bind("127.0.0.1:0").expect("bind fake daemon");
    let port = listener.local_addr().expect("port").port();
    let _server = std::thread::spawn(move || {
        let (mut stream, _) = listener.accept().expect("accept");
        if read_hello(&mut stream).is_none() {
            return;
        }
        if write_hello_ack(&mut stream).is_err() {
            return;
        }
        if read_request(&mut stream).is_none() {
            return;
        }
        // A correlated REFUSAL carrying a frame-loop transport code.
        if write_frame(
            &mut stream,
            5,
            b"request_id=1\ncode=NOT_FOUND\nsummary=no such thing",
        )
        .is_err()
        {
            return;
        }
        std::thread::sleep(Duration::from_secs(2));
    });

    let (code, _stdout, stderr) = run_cli(&["status", "--addr", &format!("127.0.0.1:{port}")]);
    assert_eq!(
        code, 13,
        "a NOT_FOUND (frame-loop transport code) refusal is still PROTO_MISMATCH (13): stderr={stderr}"
    );
    assert!(
        stderr.contains("NOT_FOUND"),
        "the code rides stderr: {stderr}"
    );
}

/// Round 98, ordering half: request_id correlation still runs BEFORE the code mapping, so a
/// refusal that carries a valid public code but a FOREIGN request id is refused as a mismatched
/// answer (13), not honoured with that code's exit number.
#[test]
fn a_foreign_request_refusal_is_protocol_mismatch_even_with_a_public_code() {
    let listener = TcpListener::bind("127.0.0.1:0").expect("bind fake daemon");
    let port = listener.local_addr().expect("port").port();
    let _server = std::thread::spawn(move || {
        let (mut stream, _) = listener.accept().expect("accept");
        if read_hello(&mut stream).is_none() {
            return;
        }
        if write_hello_ack(&mut stream).is_err() {
            return;
        }
        if read_request(&mut stream).is_none() {
            return;
        }
        // A REFUSAL with a public code (PERMISSION) but a FOREIGN request id (999).
        if write_frame(
            &mut stream,
            5,
            b"request_id=999\ncode=PERMISSION\nsummary=stale frame",
        )
        .is_err()
        {
            return;
        }
        std::thread::sleep(Duration::from_secs(2));
    });

    let (code, _stdout, stderr) = run_cli(&["status", "--addr", &format!("127.0.0.1:{port}")]);
    assert_eq!(
        code, 13,
        "a foreign-request-id refusal is a PROTO_MISMATCH before any code mapping (not 8): stderr={stderr}"
    );
}

/// Round 99: a one-shot `caly job <id>` (jobs.follow query) that describes a TERMINALLY FAILED
/// job carries the stable `failure_code`; printing it but exiting 0 would report a failed job as
/// success (docs/guides/EXIT_CODES.md §4.3). The fake daemon answers the query with a jobs.follow view whose
/// failure_code is a stable public code (PERMISSION): the CLI must exit that code (8), not 0.
#[test]
fn a_one_shot_job_query_for_a_failed_job_maps_its_failure_code() {
    let listener = TcpListener::bind("127.0.0.1:0").expect("bind fake daemon");
    let port = listener.local_addr().expect("port").port();
    let _server = std::thread::spawn(move || {
        let (mut stream, _) = listener.accept().expect("accept");
        if read_hello(&mut stream).is_none() {
            return;
        }
        if write_hello_ack(&mut stream).is_err() {
            return;
        }
        if read_request(&mut stream).is_none() {
            return;
        }
        // A jobs.follow RESPONSE (kind 4) for a failed job: request_id + failure_code.
        if write_frame(
            &mut stream,
            4,
            b"request_id=1\njob_id=7\nstate=failed\nlifecycle=failed\nevent_count=0\nfailure_code=PERMISSION\nfailure_summary=role may not\nretained_from_event_index=0\nnext_event_index=0\nreset_required=false",
        )
        .is_err()
        {
            return;
        }
        std::thread::sleep(Duration::from_secs(2));
    });

    let (code, stdout, stderr) = run_cli(&["job", "7", "--addr", &format!("127.0.0.1:{port}")]);
    assert_eq!(
        code, 8,
        "a failed job carrying failure_code=PERMISSION must exit 8, not 0: stdout={stdout} stderr={stderr}"
    );
    assert!(
        stdout.contains("failure_code: PERMISSION"),
        "the failure code is still printed for the human: {stdout}"
    );
}

/// Round 99, success half (anti-vacuity): a one-shot job query for a job that has NOT failed
/// (no failure_code) must still exit 0 — the failure mapping must not turn every job query into
/// a nonzero exit.
#[test]
fn a_one_shot_job_query_for_a_non_failed_job_stays_exit_zero() {
    let listener = TcpListener::bind("127.0.0.1:0").expect("bind fake daemon");
    let port = listener.local_addr().expect("port").port();
    let _server = std::thread::spawn(move || {
        let (mut stream, _) = listener.accept().expect("accept");
        if read_hello(&mut stream).is_none() {
            return;
        }
        if write_hello_ack(&mut stream).is_err() {
            return;
        }
        if read_request(&mut stream).is_none() {
            return;
        }
        // A succeeded job: failure_code present but EMPTY (the daemon always emits the field).
        if write_frame(
            &mut stream,
            4,
            b"request_id=1\njob_id=7\nstate=completed\nlifecycle=completed\nevent_count=3\nfailure_code=\nfailure_summary=\nretained_from_event_index=0\nnext_event_index=3\nreset_required=false",
        )
        .is_err()
        {
            return;
        }
        std::thread::sleep(Duration::from_secs(2));
    });

    let (code, stdout, stderr) = run_cli(&["job", "7", "--addr", &format!("127.0.0.1:{port}")]);
    assert_eq!(
        code, 0,
        "a non-failed job (empty failure_code) must exit 0: stdout={stdout} stderr={stderr}"
    );
}

/// Round 99, json half: `--json` does not change exit-code semantics (docs/guides/EXIT_CODES.md §1.4); a
/// failed job queried with --json still exits the failure code's number, not 0.
#[test]
fn a_one_shot_json_job_query_for_a_failed_job_maps_its_failure_code_too() {
    let listener = TcpListener::bind("127.0.0.1:0").expect("bind fake daemon");
    let port = listener.local_addr().expect("port").port();
    let _server = std::thread::spawn(move || {
        let (mut stream, _) = listener.accept().expect("accept");
        if read_hello(&mut stream).is_none() {
            return;
        }
        // json session: the hello_ack itself must select json (the client asks for json and
        // validates the negotiated encoding); the answer body is then json.
        let json_ack = b"daemon_name=fake\ndaemon_version=0\ninstance_id=fake\nmajor=1\nminor=0\nencoding=json\ncompression=none";
        if write_frame(&mut stream, 2, json_ack).is_err() {
            return;
        }
        if read_request(&mut stream).is_none() {
            return;
        }
        // A json jobs.follow response for a failed job (json_to_records flattens the keys).
        let body = br#"{"request_id":"1","job_id":"7","state":"failed","failure_code":"STORAGE","failure_summary":"disk full"}"#;
        let mut frame = vec![4u8];
        frame.extend_from_slice(&(body.len() as u32).to_be_bytes());
        frame.extend_from_slice(body);
        if stream.write_all(&frame).is_err() {
            return;
        }
        std::thread::sleep(Duration::from_secs(2));
    });

    let (code, _stdout, stderr) =
        run_cli(&["job", "7", "--json", "--addr", &format!("127.0.0.1:{port}")]);
    assert_eq!(
        code, 10,
        "STORAGE failure_code maps to exit 10 even under --json: stderr={stderr}"
    );
}

/// Round 103: `caly follow <id> --json` must take the stream's verdict for its exit code, just like
/// the human render (docs/guides/EXIT_CODES.md §1.4: --json changes the rendering, not the exit semantics). Before
/// R103 the STREAM_END json branch returned Success unconditionally, so a failed job followed with
/// --json reported exit 0 — a script gating on the exit code got a false success. The fake daemon opens
/// a json follow stream and ends it outcome=Failed; the CLI must exit 1, not 0.
#[test]
fn a_json_follow_of_a_failed_job_exits_nonzero_like_the_human_render() {
    let listener = TcpListener::bind("127.0.0.1:0").expect("bind fake daemon");
    let port = listener.local_addr().expect("port").port();
    let _server = std::thread::spawn(move || {
        let (mut stream, _) = listener.accept().expect("accept");
        if read_hello(&mut stream).is_none() {
            return;
        }
        // json session: hello_ack must select json.
        let ack = b"daemon_name=fake\ndaemon_version=0\ninstance_id=fake\nmajor=1\nminor=0\nencoding=json\ncompression=none";
        if write_frame(&mut stream, 2, ack).is_err() {
            return;
        }
        // Consume the follow-stream open request.
        let mut req_head = [0u8; 5];
        if stream.read_exact(&mut req_head).is_err() {
            return;
        }
        let mut req = vec![
            0u8;
            u32::from_be_bytes([req_head[1], req_head[2], req_head[3], req_head[4]])
                as usize
        ];
        if stream.read_exact(&mut req).is_err() {
            return;
        }
        // Opened frame (response kind 4) as json, naming stream 7 + request_id 1.
        let opened = br#"{"request_id":"1","stream_id":"7","resumed":"false"}"#;
        if write_frame(&mut stream, 4, opened).is_err() {
            return;
        }
        // A data line then a Failed end, both json (v0 json values are strings).
        let data = br#"{"stream_id":"7","next_event_index":"1","event_0":"[done] Failed"}"#;
        if write_frame(&mut stream, 6, data).is_err() {
            return;
        }
        let end = br#"{"stream_id":"7","outcome":"Failed","state":"failed"}"#;
        if write_frame(&mut stream, 7, end).is_err() {
            return;
        }
        // Confirm the cursor ack (conversation's last frame) so the CLI exits cleanly, not on a pipe.
        let mut ack_head = [0u8; 5];
        if stream.read_exact(&mut ack_head).is_ok() {
            let ack_kind = ack_head[0];
            let mut body = vec![
                0u8;
                u32::from_be_bytes([ack_head[1], ack_head[2], ack_head[3], ack_head[4]])
                    as usize
            ];
            let _ = stream.read_exact(&mut body);
            if ack_kind == 8 {
                let confirm = br#"{"stream_id":"7","acked_upto":"1"}"#;
                let _ = write_frame(&mut stream, 4, confirm);
            }
        }
        std::thread::sleep(Duration::from_secs(2));
    });

    let (code, _stdout, stderr) = run_cli(&[
        "follow",
        "1",
        "--json",
        "--addr",
        &format!("127.0.0.1:{port}"),
    ]);
    assert_eq!(
        code, 1,
        "a json follow of a FAILED job must exit 1 (GeneralFailure), not 0: stderr={stderr}"
    );
}

/// Round 103, success half (anti-vacuity): a json follow that ends Succeeded must still exit 0 — the
/// fix must not turn every json follow non-zero.
#[test]
fn a_json_follow_of_a_succeeded_job_stays_exit_zero() {
    let listener = TcpListener::bind("127.0.0.1:0").expect("bind fake daemon");
    let port = listener.local_addr().expect("port").port();
    let _server = std::thread::spawn(move || {
        let (mut stream, _) = listener.accept().expect("accept");
        if read_hello(&mut stream).is_none() {
            return;
        }
        let ack = b"daemon_name=fake\ndaemon_version=0\ninstance_id=fake\nmajor=1\nminor=0\nencoding=json\ncompression=none";
        if write_frame(&mut stream, 2, ack).is_err() {
            return;
        }
        let mut req_head = [0u8; 5];
        if stream.read_exact(&mut req_head).is_err() {
            return;
        }
        let mut req = vec![
            0u8;
            u32::from_be_bytes([req_head[1], req_head[2], req_head[3], req_head[4]])
                as usize
        ];
        if stream.read_exact(&mut req).is_err() {
            return;
        }
        let opened = br#"{"request_id":"1","stream_id":"7","resumed":"false"}"#;
        if write_frame(&mut stream, 4, opened).is_err() {
            return;
        }
        let data = br#"{"stream_id":"7","next_event_index":"1","event_0":"[done] Succeeded"}"#;
        if write_frame(&mut stream, 6, data).is_err() {
            return;
        }
        let end = br#"{"stream_id":"7","outcome":"Succeeded","state":"completed"}"#;
        if write_frame(&mut stream, 7, end).is_err() {
            return;
        }
        let mut ack_head = [0u8; 5];
        if stream.read_exact(&mut ack_head).is_ok() {
            let ack_kind = ack_head[0];
            let mut body = vec![
                0u8;
                u32::from_be_bytes([ack_head[1], ack_head[2], ack_head[3], ack_head[4]])
                    as usize
            ];
            let _ = stream.read_exact(&mut body);
            if ack_kind == 8 {
                let confirm = br#"{"stream_id":"7","acked_upto":"1"}"#;
                let _ = write_frame(&mut stream, 4, confirm);
            }
        }
        std::thread::sleep(Duration::from_secs(2));
    });

    let (code, _stdout, stderr) = run_cli(&[
        "follow",
        "1",
        "--json",
        "--addr",
        &format!("127.0.0.1:{port}"),
    ]);
    assert_eq!(
        code, 0,
        "a json follow of a SUCCEEDED job must still exit 0: stderr={stderr}"
    );
}
