//! The `caly` CLI against the real `calyd`, both as built binaries (`ROADMAP §1bis.2`:
//! executables 1 → 2 — the daemon gets a client that is not the test harness).
//!
//! The ground truth for the happy path is this test's **own minimal wire reader**, not the
//! shared codec: two implementations agreeing is evidence about the wire, one implementation
//! round-tripping itself is not (`caly-ipc/src/wire.rs`'s header says the same thing).
//!
//! Locating `calyd` from the `caly` crate: `CARGO_BIN_EXE_*` only exists for same-crate bins,
//! so this test starts from its own binary's path — workspace builds put every member's bins
//! in the same target directory, which makes the sibling path deterministic, and the assert
//! says what to do if that ever stops being true.

// This file is a process-spawning integration harness: judging the `caly` CLI *is* spawning
// it (`Command::new`), waiting (`Instant::now`), and naming scratch paths (`PathBuf`). The
// workspace bans those symbols to keep the core pure (`ADR-011`); the lift is scoped to this
// file alone, matching `calyd_wire.rs`.
#![allow(clippy::disallowed_methods, clippy::disallowed_types)]

use std::io::{Read, Write};
use std::net::{TcpListener, TcpStream};
use std::path::PathBuf;
use std::process::{Command, Stdio};
use std::time::{Duration, Instant};

fn calyd_binary() -> PathBuf {
    let own = PathBuf::from(env!("CARGO_BIN_EXE_caly"));
    let sibling = own
        .parent()
        .expect("the test binary lives in a directory")
        .join("calyd");
    assert!(
        sibling.exists(),
        "calyd should sit next to caly in the shared target dir ({}); if the layout changed, \
         teach this test the new address — do not skip the judge",
        sibling.display()
    );
    sibling
}

struct Daemon {
    child: std::process::Child,
    port: u16,
    data_dir: PathBuf,
}

impl Drop for Daemon {
    fn drop(&mut self) {
        let _ = self.child.kill();
        let _ = self.child.wait();
        let _ = std::fs::remove_dir_all(&self.data_dir);
    }
}

fn spawn_daemon(tag: &str) -> Daemon {
    let stamp = std::time::SystemTime::now()
        .duration_since(std::time::UNIX_EPOCH)
        .expect("clock")
        .as_millis();
    let data_dir =
        std::env::temp_dir().join(format!("caly-cli-e2e-{}-{stamp}-{tag}", std::process::id()));
    let port_file = data_dir.with_extension("port");
    std::fs::create_dir_all(&data_dir).expect("scratch");
    let child = Command::new(calyd_binary())
        .arg("--data-dir")
        .arg(&data_dir)
        .arg("--bind")
        .arg("127.0.0.1:0")
        .arg("--port-file")
        .arg(&port_file)
        .stdout(Stdio::null())
        .stderr(Stdio::null())
        .spawn()
        .expect("calyd must be built with the test run");
    let deadline = Instant::now() + Duration::from_secs(10);
    let port = loop {
        if let Ok(text) = std::fs::read_to_string(&port_file) {
            break text.trim().parse::<u16>().expect("port");
        }
        assert!(
            Instant::now() < deadline,
            "calyd did not report a port in 10s"
        );
        std::thread::sleep(Duration::from_millis(25));
    };
    Daemon {
        child,
        port,
        data_dir,
    }
}

/// This test's own minimal reader: an oracle independent of the shared codec.
fn oracle_status(port: u16) -> Vec<(String, String)> {
    let mut stream = TcpStream::connect(("127.0.0.1", port)).expect("daemon is listening");
    let hello = b"client_name=oracle\nrole=Admin\nmajor=1\nminor=0";
    let mut frame = vec![1u8];
    frame.extend_from_slice(&(hello.len() as u32).to_be_bytes());
    frame.extend_from_slice(hello);
    stream.write_all(&frame).expect("hello");
    let mut head = [0u8; 5];
    stream.read_exact(&mut head).expect("ack head");
    let mut ack = vec![0u8; u32::from_be_bytes([head[1], head[2], head[3], head[4]]) as usize];
    stream.read_exact(&mut ack).expect("ack body");
    assert_eq!(head[0], 2, "hello_ack");

    let request = b"request_id=41\ntrace_id=oracle\noperation=runtime.status";
    let mut frame = vec![3u8];
    frame.extend_from_slice(&(request.len() as u32).to_be_bytes());
    frame.extend_from_slice(request);
    stream.write_all(&frame).expect("request");
    stream.read_exact(&mut head).expect("response head");
    assert_eq!(head[0], 4, "response frame");
    let mut body = vec![0u8; u32::from_be_bytes([head[1], head[2], head[3], head[4]]) as usize];
    stream.read_exact(&mut body).expect("response body");
    String::from_utf8_lossy(&body)
        .lines()
        .filter_map(|line| {
            line.split_once('=')
                .map(|(k, v)| (k.to_owned(), v.to_owned()))
        })
        .collect()
}

/// One full oracle conversation: hello, one request (plus optional extra records, as
/// `profiles.get` needs), and the parsed response. The oracle speaks the documented wire by
/// hand and parses it independently — including value escaping, for the same reason the doctor
/// oracle does: an oracle that skips a documented transform flags a CLI that correctly did it.
fn oracle_conversation(port: u16, operation: &str, extra_records: &[u8]) -> Vec<(String, String)> {
    let unescape = |value: &str| -> String {
        let mut out = String::new();
        let mut rest = value;
        while let Some(at) = rest.find('%') {
            out.push_str(&rest[..at]);
            let tail = &rest[at + 1..];
            if let Some(next) = tail.strip_prefix("25") {
                out.push('%');
                rest = next;
            } else if let Some(next) = tail.strip_prefix("3D") {
                out.push('=');
                rest = next;
            } else if let Some(next) = tail.strip_prefix("0A") {
                out.push('\n');
                rest = next;
            } else {
                out.push('%');
                rest = tail;
            }
        }
        out.push_str(rest);
        out
    };
    let mut stream = TcpStream::connect(("127.0.0.1", port)).expect("daemon is listening");
    let hello = b"client_name=oracle\nrole=Admin\nmajor=1\nminor=0";
    let mut frame = vec![1u8];
    frame.extend_from_slice(&(hello.len() as u32).to_be_bytes());
    frame.extend_from_slice(hello);
    stream.write_all(&frame).expect("hello");
    let read_frame = |stream: &mut TcpStream| -> (u8, Vec<u8>) {
        let mut head = [0u8; 5];
        stream.read_exact(&mut head).expect("frame head");
        let mut body = vec![0u8; u32::from_be_bytes([head[1], head[2], head[3], head[4]]) as usize];
        stream.read_exact(&mut body).expect("frame body");
        (head[0], body)
    };
    let (kind, _ack) = read_frame(&mut stream);
    assert_eq!(kind, 2, "hello_ack");

    let mut request = format!("request_id=71\ntrace_id=oracle\noperation={operation}").into_bytes();
    if !extra_records.is_empty() {
        request.push(b'\n');
        request.extend_from_slice(extra_records);
    }
    let mut frame = vec![3u8];
    frame.extend_from_slice(&(request.len() as u32).to_be_bytes());
    frame.extend_from_slice(&request);
    stream.write_all(&frame).expect("request");
    let (kind, body) = read_frame(&mut stream);
    assert_eq!(kind, 4, "response frame");
    String::from_utf8_lossy(&body)
        .lines()
        .filter_map(|line| {
            line.split_once('=')
                .map(|(k, v)| (k.to_owned(), unescape(v)))
        })
        .collect()
}

/// Round 53: acceptance means queued — the worker thread runs the job on its own tick, so a
/// judge that needs a terminal job waits until the daemon itself says so. The daemon's state
/// is the only clock that never lies here.
fn oracle_wait_terminal(port: u16, job_id: &str) -> String {
    let deadline = Instant::now() + Duration::from_secs(10);
    loop {
        let truth = oracle_conversation(port, "jobs.events", format!("job_id={job_id}").as_bytes());
        let state = truth
            .iter()
            .find(|(k, _)| k == "state")
            .map(|(_, v)| v.clone())
            .unwrap_or_default();
        if matches!(
            state.as_str(),
            "completed" | "failed" | "cancelled" | "timedout"
        ) {
            return state;
        }
        assert!(
            Instant::now() < deadline,
            "job {job_id} never reached a terminal state (last state: {state})"
        );
        std::thread::sleep(Duration::from_millis(25));
    }
}

fn run_cli(args: &[&str]) -> (i32, String, String) {
    let output = Command::new(env!("CARGO_BIN_EXE_caly"))
        .args(args)
        .output()
        .expect("caly must be built with the test run");
    (
        output.status.code().unwrap_or(-1),
        String::from_utf8_lossy(&output.stdout).into_owned(),
        String::from_utf8_lossy(&output.stderr).into_owned(),
    )
}

#[test]
fn caly_status_prints_what_the_wire_actually_says() {
    let daemon = spawn_daemon("happy");
    let address = format!("127.0.0.1:{}", daemon.port);
    let (code, stdout, stderr) = run_cli(&["status", "--addr", &address]);
    assert_eq!(code, 0, "success is exit 0; stderr: {stderr}");
    for key in [
        "core_running",
        "active_profile",
        "active_core",
        "active_snapshot",
        "last_apply_plan_summary",
        "pending_recovery_decisions",
        "last_recovery_summary",
        "last_failure",
    ] {
        assert!(
            stdout.contains(&format!("{key}: ")),
            "field {key} must be printed: {stdout}"
        );
    }
    // Ground truth: the oracle's own conversation with the same daemon must agree, value for
    // value, with what the CLI printed — a client that fabricates or drops values fails here.
    let truth = oracle_status(daemon.port);
    for (key, value) in &truth {
        if key == "request_id" {
            continue;
        }
        assert!(
            stdout.contains(&format!("{key}: {value}")),
            "{key} must be printed as the wire said ({value:?}): {stdout}"
        );
    }
}

#[test]
fn an_unreachable_daemon_is_exit_12_and_names_the_address() {
    let listener = TcpListener::bind("127.0.0.1:0").expect("bind");
    let port = listener.local_addr().expect("addr").port();
    drop(listener);
    let (code, stdout, stderr) = run_cli(&["status", "--addr", &format!("127.0.0.1:{port}")]);
    assert_eq!(code, 12, "UNAVAILABLE per EXIT_CODES.md; stdout: {stdout}");
    assert!(
        stderr.contains(&format!("127.0.0.1:{port}")),
        "the refusal must name the address it could not reach: {stderr}"
    );
}

#[test]
fn missing_addr_is_a_usage_error_not_a_connection_attempt() {
    let (code, _stdout, stderr) = run_cli(&["status"]);
    assert_eq!(code, 2, "usage per EXIT_CODES.md; stderr: {stderr}");
    assert!(stderr.contains("--addr"), "{stderr}");
}

/// A daemon that accepts and never speaks must not hang the client forever: the CLI times out
/// its reads and exits 11 (`TIMEOUT` per `EXIT_CODES.md`), naming the wait. Found by round 44's
/// own falsification — a mutant that skipped hello deadlocked with no timeout on either side.
#[test]
fn a_silent_daemon_times_out_as_exit_11_not_a_hang() {
    let listener = TcpListener::bind("127.0.0.1:0").expect("bind");
    let port = listener.local_addr().expect("addr").port();
    // Accept and hold the connection open, saying nothing, forever-ish.
    let _server = std::thread::spawn(move || {
        if let Ok((stream, _)) = listener.accept() {
            std::thread::sleep(Duration::from_secs(30));
            drop(stream);
        }
    });
    let started = Instant::now();
    let (code, _stdout, stderr) = run_cli(&["status", "--addr", &format!("127.0.0.1:{port}")]);
    assert!(
        started.elapsed() < Duration::from_secs(10),
        "the CLI must answer by itself, not wait for the server"
    );
    assert_eq!(code, 11, "TIMEOUT per EXIT_CODES.md; stderr: {stderr}");
    assert!(
        stderr.contains("timed out"),
        "the failure must say it was a timeout: {stderr}"
    );
}

/// `caly doctor` prints what the wire actually said — every tier line the oracle's own
/// conversation received appears in the CLI output, and the printed counts match the oracle's.
#[test]
fn caly_doctor_prints_the_tiers_the_wire_actually_said() {
    let daemon = spawn_daemon("cli-doctor");
    let address = format!("127.0.0.1:{}", daemon.port);

    let (code, stdout, stderr) = run_cli(&["doctor", "--addr", &address]);
    assert_eq!(code, 0, "stderr: {stderr}");
    for key in ["summary:", "truncated:", "warnings:", "errors:", "notes:"] {
        assert!(stdout.contains(key), "{key} heading must print: {stdout}");
    }

    // Ground truth from this test's own conversation.
    let mut stream = TcpStream::connect(("127.0.0.1", daemon.port)).expect("daemon");
    let hello = b"client_name=oracle
role=Admin
major=1
minor=0";
    let mut frame = vec![1u8];
    frame.extend_from_slice(&(hello.len() as u32).to_be_bytes());
    frame.extend_from_slice(hello);
    stream.write_all(&frame).expect("hello");
    let mut head = [0u8; 5];
    stream.read_exact(&mut head).expect("ack head");
    let mut ack = vec![0u8; u32::from_be_bytes([head[1], head[2], head[3], head[4]]) as usize];
    stream.read_exact(&mut ack).expect("ack body");
    let request = b"request_id=61
trace_id=oracle
operation=diagnostics.doctor";
    let mut frame = vec![3u8];
    frame.extend_from_slice(&(request.len() as u32).to_be_bytes());
    frame.extend_from_slice(request);
    stream.write_all(&frame).expect("request");
    stream.read_exact(&mut head).expect("response head");
    let mut body = vec![0u8; u32::from_be_bytes([head[1], head[2], head[3], head[4]]) as usize];
    stream.read_exact(&mut body).expect("response body");
    // The oracle parses the documented format independently — including the value escaping the
    // shared codec performs: without this, an oracle that never unescapes would flag a CLI that
    // correctly did (which is exactly what happened on this judge's first run).
    fn oracle_unescape(value: &str) -> String {
        let mut out = String::new();
        let mut rest = value;
        while let Some(at) = rest.find('%') {
            out.push_str(&rest[..at]);
            let tail = &rest[at + 1..];
            if let Some(next) = tail.strip_prefix("25") {
                out.push('%');
                rest = next;
            } else if let Some(next) = tail.strip_prefix("3D") {
                out.push('=');
                rest = next;
            } else if let Some(next) = tail.strip_prefix("0A") {
                out.push('\n');
                rest = next;
            } else {
                out.push('%');
                rest = tail;
            }
        }
        out.push_str(rest);
        out
    }
    let truth: Vec<(String, String)> = String::from_utf8_lossy(&body)
        .lines()
        .filter_map(|line| {
            line.split_once('=')
                .map(|(k, v)| (k.to_owned(), oracle_unescape(v)))
        })
        .collect();
    let find = |key: &str| {
        truth
            .iter()
            .find(|(k, _)| k == key)
            .map(|(_, v)| v.clone())
            .unwrap_or_default()
    };
    for (prefix, count_key) in [
        ("warning", "warning_count"),
        ("error", "error_count"),
        ("note", "note_count"),
    ] {
        let heading = format!("{prefix}s:");
        assert!(
            stdout.contains(&format!("{heading} {}", find(count_key))),
            "the printed {prefix} count ({heading}) must be the wire's own: {stdout}"
        );
        for index in 0..find(count_key).parse::<usize>().unwrap_or(0) {
            let line = find(&format!("{prefix}_{index}"));
            // The gc note carries a live clock reading (`now=...@storage-clock`) that differs
            // between the CLI's conversation and this oracle's seconds later: parity is judged
            // on the stable prefix, not on a timestamp neither side controls.
            let stable = line.split(" now=").next().unwrap_or(&line).to_owned();
            assert!(
                !stable.is_empty() && stdout.contains(&stable),
                "{prefix}_{index} ({stable:?}) must appear in the CLI output: {stdout}"
            );
        }
    }
}

/// `caly doctor --runtime`: the runtime projection is an opt-in the CLI can reach — the
/// default shape keeps the older summary, the flag widens it to name the runtime snapshot.
#[test]
fn caly_doctor_runtime_flag_names_the_runtime_projection() {
    let daemon = spawn_daemon("cli-doctor-runtime");
    let address = format!("127.0.0.1:{}", daemon.port);

    let (code, stdout, stderr) = run_cli(&["doctor", "--addr", &address]);
    assert_eq!(code, 0, "stderr: {stderr}");
    let plain = stdout
        .lines()
        .find(|line| line.starts_with("summary: "))
        .unwrap_or_default()
        .to_owned();
    assert!(
        !plain.contains("runtime active_profile="),
        "the default shape must not widen the summary: {plain}"
    );

    let (code, stdout, stderr) = run_cli(&["doctor", "--runtime", "--addr", &address]);
    assert_eq!(code, 0, "stderr: {stderr}");
    let widened = stdout
        .lines()
        .find(|line| line.starts_with("summary: "))
        .unwrap_or_default()
        .to_owned();
    assert!(
        widened.contains("runtime active_profile=") && widened.contains("engine_lifecycle="),
        "--runtime must name the runtime snapshot the doctor saw: {widened}"
    );
}

/// `caly profiles`: the count and every profile line must be what the wire said, in an
/// independent oracle's conversation. The oracle speaks the raw wire itself — two
/// implementations agreeing is evidence, one implementation round-tripping itself is not.
#[test]
fn caly_profiles_prints_the_list_the_wire_actually_said() {
    let daemon = spawn_daemon("cli-profiles");
    let address = format!("127.0.0.1:{}", daemon.port);

    let (code, stdout, stderr) = run_cli(&["profiles", "--addr", &address]);
    assert_eq!(code, 0, "stderr: {stderr}");

    let truth = oracle_conversation(daemon.port, "profiles.list", b"");
    let find = |key: &str| {
        truth
            .iter()
            .find(|(k, _)| k == key)
            .map(|(_, v)| v.clone())
            .unwrap_or_default()
    };
    let count = find("profile_count").parse::<usize>().unwrap_or(0);
    assert!(
        stdout.contains(&format!("profiles: {count}")),
        "the printed count must be the wire's own: {stdout}"
    );
    for index in 0..count {
        let id = find(&format!("profile_{index}_id"));
        let label = find(&format!("profile_{index}_label"));
        assert!(
            !id.is_empty() && stdout.contains(&id),
            "profile_{index}_id ({id:?}) must appear in the CLI output: {stdout}"
        );
        assert!(
            !label.is_empty() && stdout.contains(&label),
            "profile_{index}_label ({label:?}) must appear in the CLI output: {stdout}"
        );
    }
}

/// `caly profile <id>`: every view field prints with the wire's value, the id is the one that
/// was asked for, and an absent id is a usage error at the client — not a guessed default that
/// travels to the daemon.
#[test]
fn caly_profile_prints_the_view_the_wire_said_for_that_id() {
    let daemon = spawn_daemon("cli-profile");
    let address = format!("127.0.0.1:{}", daemon.port);

    let (code, stdout, stderr) = run_cli(&["profile", "nightshift", "--addr", &address]);
    assert_eq!(code, 0, "stderr: {stderr}");

    let truth = oracle_conversation(daemon.port, "profiles.get", b"profile_id=nightshift");
    let find = |key: &str| {
        truth
            .iter()
            .find(|(k, _)| k == key)
            .map(|(_, v)| v.clone())
            .unwrap_or_default()
    };
    assert_eq!(find("profile_id"), "nightshift".to_owned());
    for key in [
        "profile_id",
        "label",
        "active",
        "source_count",
        "core_target",
    ] {
        let value = find(key);
        assert!(
            stdout.contains(&format!("{key}: {value}")),
            "{key} must print with the wire's own value ({value:?}): {stdout}"
        );
    }

    // An absent operand is the client's own usage error: the daemon must never be asked.
    let (code, _stdout, stderr) = run_cli(&["profile", "--addr", &address]);
    assert_eq!(code, 2, "missing id is exit 2, not a guessed default");
    assert!(
        stderr.contains("profile needs an id"),
        "the usage error must name the operand: {stderr}"
    );
}

/// `caly apply`: exit 0, the acceptance's three fields printed, and — because v0 drains inline —
/// the printed job id must already be terminal when this test asks the wire about it.
#[test]
fn caly_apply_prints_an_acceptance_and_the_worker_finishes_the_job() {
    let daemon = spawn_daemon("cli-apply");
    let address = format!("127.0.0.1:{}", daemon.port);

    let (code, stdout, stderr) = run_cli(&[
        "apply",
        "demo-tun-profile",
        "--idempotency-key",
        "cli-e2e-apply",
        "--addr",
        &address,
    ]);
    assert_eq!(code, 0, "stderr: {stderr}");
    for key in ["job_id:", "state_revision:", "estimated_impact:"] {
        assert!(stdout.contains(key), "{key} must print: {stdout}");
    }
    let job_id = stdout
        .lines()
        .find_map(|line| line.strip_prefix("job_id: "))
        .unwrap_or_default()
        .trim()
        .to_owned();
    let state = oracle_wait_terminal(daemon.port, &job_id);
    assert_eq!(state, "completed", "stdout: {stdout}");
    let truth = oracle_conversation(
        daemon.port,
        "jobs.events",
        format!("job_id={job_id}").as_bytes(),
    );
    let find = |key: &str| {
        truth
            .iter()
            .find(|(k, _)| k == key)
            .map(|(_, v)| v.clone())
            .unwrap_or_default()
    };
    assert_eq!(find("state"), "completed".to_owned(), "stdout: {stdout}");
    assert_eq!(find("job_id"), job_id);
}

/// `caly jobs`: state, count and every event line must match an independent oracle's
/// conversation about the same job. Stored event lines are immutable once the job is terminal,
/// so full-string parity is the bar — no stable-prefix carve-outs here.
#[test]
fn caly_jobs_prints_the_events_the_wire_said() {
    let daemon = spawn_daemon("cli-jobs");
    let address = format!("127.0.0.1:{}", daemon.port);

    let (code, stdout, stderr) = run_cli(&[
        "apply",
        "demo-tun-profile",
        "--idempotency-key",
        "cli-e2e-jobs",
        "--addr",
        &address,
    ]);
    assert_eq!(code, 0, "stderr: {stderr}");
    let job_id = stdout
        .lines()
        .find_map(|line| line.strip_prefix("job_id: "))
        .unwrap_or_default()
        .trim()
        .to_owned();
    oracle_wait_terminal(daemon.port, &job_id);

    let (code, stdout, stderr) = run_cli(&["jobs", &job_id, "--addr", &address]);
    assert_eq!(code, 0, "stderr: {stderr}");
    let truth = oracle_conversation(
        daemon.port,
        "jobs.events",
        format!("job_id={job_id}").as_bytes(),
    );
    let find = |key: &str| {
        truth
            .iter()
            .find(|(k, _)| k == key)
            .map(|(_, v)| v.clone())
            .unwrap_or_default()
    };
    assert_eq!(find("state"), "completed".to_owned());
    let count = find("event_count").parse::<usize>().unwrap_or(0);
    assert!(
        stdout.contains(&format!("events: {count}")),
        "the printed count must be the wire's own: {stdout}"
    );
    for index in 0..count {
        let line = find(&format!("event_{index}"));
        assert!(
            !line.is_empty() && stdout.contains(&line),
            "event_{index} ({line:?}) must appear in the CLI output: {stdout}"
        );
    }
}

/// The key is the caller's own name for the write: the CLI requires it as a flag and never
/// mints one — a silently minted key would turn every shell retry into a second write.
#[test]
fn apply_without_an_idempotency_key_is_a_usage_error_not_a_minted_one() {
    let daemon = spawn_daemon("cli-apply-nokey");
    let address = format!("127.0.0.1:{}", daemon.port);
    let (code, _stdout, stderr) = run_cli(&["apply", "demo-tun-profile", "--addr", &address]);
    assert_eq!(code, 2, "missing key is exit 2, not a minted key");
    assert!(
        stderr.contains("--idempotency-key"),
        "the usage error must name the flag: {stderr}"
    );
}

/// `caly job <id>`: the follow summary, every field, against an independent oracle's
/// `jobs.follow` conversation about the same (terminal, immutable) job.
#[test]
fn caly_job_prints_the_summary_the_wire_said() {
    let daemon = spawn_daemon("cli-job");
    let address = format!("127.0.0.1:{}", daemon.port);

    let (code, stdout, stderr) = run_cli(&[
        "apply",
        "demo-tun-profile",
        "--idempotency-key",
        "cli-e2e-job",
        "--addr",
        &address,
    ]);
    assert_eq!(code, 0, "stderr: {stderr}");
    let job_id = stdout
        .lines()
        .find_map(|line| line.strip_prefix("job_id: "))
        .unwrap_or_default()
        .trim()
        .to_owned();

    let (code, stdout, stderr) = run_cli(&["job", &job_id, "--addr", &address]);
    assert_eq!(code, 0, "stderr: {stderr}");
    oracle_wait_terminal(daemon.port, &job_id);
    let truth = oracle_conversation(
        daemon.port,
        "jobs.follow",
        format!("job_id={job_id}").as_bytes(),
    );
    let find = |key: &str| {
        truth
            .iter()
            .find(|(k, _)| k == key)
            .map(|(_, v)| v.clone())
            .unwrap_or_default()
    };
    assert_eq!(find("state"), "completed".to_owned());
    for key in [
        "job_id",
        "state",
        "lifecycle",
        "next_event_index",
        "retained_from_event_index",
        "reset_required",
        "event_count",
        "last_stage",
        "warning_count",
        "log_count",
        "failure_code",
        "failure_summary",
    ] {
        let value = find(key);
        assert!(
            stdout.contains(&format!("{key}: {value}")),
            "{key} must print with the wire's own value ({value:?}): {stdout}"
        );
    }
}

/// `caly rollback --snapshot <id>`: exit 0, and the rollback job's own event lines must name
/// the snapshot that was asked for — the guessed-default mutation (silently rolling back to
/// the last-known-good instead) would pass every other assertion. Missing key is exit 2.
#[test]
fn caly_rollback_targets_the_named_snapshot_and_requires_a_key() {
    let daemon = spawn_daemon("cli-rollback");
    let address = format!("127.0.0.1:{}", daemon.port);
    let apply = |key: &str, profile: &str| {
        let (code, stdout, stderr) = run_cli(&[
            "apply",
            profile,
            "--idempotency-key",
            key,
            "--addr",
            &address,
        ]);
        assert_eq!(code, 0, "stderr: {stderr}");
        let job_id = stdout
            .lines()
            .find_map(|line| line.strip_prefix("job_id: "))
            .unwrap_or_default()
            .trim()
            .to_owned();
        // The snapshot the next read looks for is published by the run, and the worker owns
        // the run — wait for the daemon to say the job is done, not for luck.
        oracle_wait_terminal(daemon.port, &job_id);
        stdout
    };
    let active_snapshot = |stdout: &str| {
        stdout
            .lines()
            .find_map(|line| line.strip_prefix("active_snapshot: "))
            .unwrap_or_default()
            .trim()
            .to_owned()
    };
    let status = || {
        let (code, stdout, stderr) = run_cli(&["status", "--addr", &address]);
        assert_eq!(code, 0, "stderr: {stderr}");
        stdout
    };
    apply("cli-e2e-rb-1", "demo-tun-profile");
    let first = active_snapshot(&status());
    apply("cli-e2e-rb-2", "nightshift");
    let second = active_snapshot(&status());
    assert!(!first.is_empty() && !second.is_empty() && first != second);

    let (code, stdout, stderr) = run_cli(&[
        "rollback",
        "--snapshot",
        &first,
        "--idempotency-key",
        "cli-e2e-rb-3",
        "--addr",
        &address,
    ]);
    assert_eq!(code, 0, "stderr: {stderr}");
    let job_id = stdout
        .lines()
        .find_map(|line| line.strip_prefix("job_id: "))
        .unwrap_or_default()
        .trim()
        .to_owned();
    oracle_wait_terminal(daemon.port, &job_id);
    let (code, events_out, stderr) = run_cli(&["jobs", &job_id, "--addr", &address]);
    assert_eq!(code, 0, "stderr: {stderr}");
    assert!(
        events_out.contains(&format!("target={first}")),
        "the rollback job must name the snapshot it used: {events_out}"
    );
    assert!(
        !events_out.contains(&format!("target={second}")),
        "a named rollback must not use the last-known-good instead: {events_out}"
    );

    let (code, _stdout, stderr) = run_cli(&["rollback", "--addr", &address]);
    assert_eq!(code, 2, "missing key is exit 2, not a minted key");
    assert!(
        stderr.contains("--idempotency-key"),
        "the usage error must name the flag: {stderr}"
    );
}

/// `caly jobs <id> --max/--from`: the cursor contract from the client side. A capped page says
/// so (`next_from_event_index` non-empty), resuming from it yields exactly the rest, and the
/// two pages concatenated are the whole window — no line lost, none repeated.
#[test]
fn caly_jobs_pages_by_cursor_and_the_pages_tile_the_window() {
    let daemon = spawn_daemon("cli-jobs-paging");
    let address = format!("127.0.0.1:{}", daemon.port);

    let (code, stdout, stderr) = run_cli(&[
        "apply",
        "demo-tun-profile",
        "--idempotency-key",
        "cli-e2e-paging",
        "--addr",
        &address,
    ]);
    assert_eq!(code, 0, "stderr: {stderr}");
    let job_id = stdout
        .lines()
        .find_map(|line| line.strip_prefix("job_id: "))
        .unwrap_or_default()
        .trim()
        .to_owned();
    oracle_wait_terminal(daemon.port, &job_id);

    let event_lines = |stdout: &str| -> Vec<String> {
        stdout
            .lines()
            .filter_map(|line| line.strip_prefix("  - "))
            .map(str::to_owned)
            .collect()
    };
    let next_from = |stdout: &str| {
        stdout
            .lines()
            .find_map(|line| line.strip_prefix("next_from_event_index: "))
            .unwrap_or_default()
            .trim()
            .to_owned()
    };

    let (code, whole, stderr) = run_cli(&["jobs", &job_id, "--addr", &address]);
    assert_eq!(code, 0, "stderr: {stderr}");
    let all = event_lines(&whole);
    assert!(
        all.len() >= 6,
        "an executed job logs enough to page: {all:?}"
    );
    assert_eq!(next_from(&whole), "", "the unpaged read reaches the end");

    let (code, page1, stderr) = run_cli(&["jobs", &job_id, "--max", "3", "--addr", &address]);
    assert_eq!(code, 0, "stderr: {stderr}");
    assert_eq!(
        event_lines(&page1).len(),
        3,
        "--max bounds the page: {page1}"
    );
    let cursor = next_from(&page1);
    assert!(
        !cursor.is_empty(),
        "a capped page must say where to resume: {page1}"
    );

    let (code, page2, stderr) = run_cli(&["jobs", &job_id, "--from", &cursor, "--addr", &address]);
    assert_eq!(code, 0, "stderr: {stderr}");
    assert_eq!(
        next_from(&page2),
        "",
        "the resumed page reaches the end: {page2}"
    );

    let mut tiled = event_lines(&page1);
    tiled.extend(event_lines(&page2));
    assert_eq!(
        tiled, all,
        "the two pages must tile the window exactly — no line lost, none repeated"
    );
}

/// `caly gc-plan`: the plan's scalars must match an independent oracle's `system.gc-plan`
/// conversation. The live clock reading is the one field allowed to differ (it is a clock);
/// everything else is the same fact asked twice.
#[test]
fn caly_gc_plan_matches_an_independent_oracle() {
    let daemon = spawn_daemon("cli-gc-plan");
    let address = format!("127.0.0.1:{}", daemon.port);

    let (code, stdout, stderr) = run_cli(&["gc-plan", "--addr", &address]);
    assert_eq!(code, 0, "stderr: {stderr}");
    let truth = oracle_conversation(daemon.port, "system.gc-plan", b"");
    let find = |key: &str| {
        truth
            .iter()
            .find(|(k, _)| k == key)
            .map(|(_, v)| v.clone())
            .unwrap_or_default()
    };
    assert_eq!(find("now_source"), "storage-clock".to_owned());
    for key in [
        "now_source",
        "grace_period_ms",
        "max_deletions",
        "objects_total",
        "snapshots_total",
        "revisions_total",
        "collect_count",
        "retained_total",
        "content_total",
        "gap_count",
        "would_run",
    ] {
        let value = find(key);
        assert!(
            stdout.contains(&format!("{key}: {value}")),
            "{key} must print with the wire's own value ({value:?}): {stdout}"
        );
    }
    let count = find("collect_count").parse::<usize>().unwrap_or(0);
    for index in 0..count {
        let digest = find(&format!("collect_{index}"));
        assert!(
            !digest.is_empty() && stdout.contains(&digest),
            "collect_{index} ({digest:?}) must appear in the CLI output: {stdout}"
        );
    }
}

/// The maintenance command from the client: no key is exit 2 at the door, a keyed run prints
/// the acceptance, a replay reuses the job, and the next plan shows the run — the command
/// surface must be visible from the query surface.
#[test]
fn caly_gc_is_keyed_replays_and_shows_up_in_the_next_plan() {
    let daemon = spawn_daemon("cli-gc");
    let address = format!("127.0.0.1:{}", daemon.port);

    let (code, _stdout, stderr) = run_cli(&["gc", "--addr", &address]);
    assert_eq!(code, 2, "no key is exit 2, not a minted key: {stderr}");
    assert!(stderr.contains("--idempotency-key"), "{stderr}");

    let run = |key: &str| {
        let (code, stdout, stderr) = run_cli(&["gc", "--idempotency-key", key, "--addr", &address]);
        assert_eq!(code, 0, "stderr: {stderr}");
        stdout
            .lines()
            .find_map(|line| line.strip_prefix("job_id: "))
            .unwrap_or_default()
            .trim()
            .to_owned()
    };
    let first = run("cli-e2e-gc");
    let replay = run("cli-e2e-gc");
    assert_eq!(first, replay, "the same key replays the same sweep");
    assert!(!first.is_empty());
    oracle_wait_terminal(daemon.port, &first);

    let (code, plan, stderr) = run_cli(&["gc-plan", "--addr", &address]);
    assert_eq!(code, 0, "stderr: {stderr}");
    assert!(
        plan.contains("last_run: gc cycle") && plan.contains("deleted="),
        "the plan must show the run this client just made: {plan}"
    );
}

/// The bundle pair from the client: export (no key demanded — `Idempotency::Optional`), then
/// read the newest bundle back, then a bounded read that says it was cut.
#[test]
fn caly_bundle_exports_and_reads_back_with_honest_bounds() {
    let daemon = spawn_daemon("cli-bundle");
    let address = format!("127.0.0.1:{}", daemon.port);

    let (code, stdout, stderr) = run_cli(&["support-bundle", "--addr", &address]);
    assert_eq!(code, 0, "stderr: {stderr}");
    assert!(stdout.contains("job_id: "), "{stdout}");
    let bundle_job = stdout
        .lines()
        .find_map(|line| line.strip_prefix("job_id: "))
        .unwrap_or_default()
        .trim()
        .to_owned();
    // "the newest bundle the store still holds" only exists once the worker has run the
    // export job — the read waits for the daemon to say it happened.
    oracle_wait_terminal(daemon.port, &bundle_job);

    let (code, stdout, stderr) = run_cli(&["bundle", "--addr", &address]);
    assert_eq!(code, 0, "stderr: {stderr}");
    let digest = stdout
        .lines()
        .find_map(|line| line.strip_prefix("digest: "))
        .unwrap_or_default()
        .trim()
        .to_owned();
    assert!(digest.starts_with("sha256:"), "{stdout}");
    let content = stdout
        .lines()
        .find_map(|line| line.strip_prefix("content_sha256: "))
        .unwrap_or_default()
        .trim()
        .to_owned();
    assert_eq!(digest, content, "a bundle is its own content address");
    assert!(stdout.contains("truncated: false"), "{stdout}");
    assert!(
        stdout.contains("# caly support bundle"),
        "the text rides and prints verbatim: {stdout}"
    );

    let (code, capped, stderr) = run_cli(&["bundle", "--max-bytes", "100", "--addr", &address]);
    assert_eq!(code, 0, "stderr: {stderr}");
    assert!(capped.contains("truncated: true"), "{capped}");
    assert!(capped.contains("byte_len: 100"), "{capped}");
}

// The e2e harness's own flat-JSON oracle: parse exactly what the daemon may emit (one object,
// string values), independently of the codec both binaries share.
fn oracle_parse_flat_json(payload: &str) -> Vec<(String, String)> {
    let chars: Vec<char> = payload.chars().collect();
    let mut at = 0usize;
    let mut out = Vec::new();
    let string = |at: &mut usize| -> String {
        assert_eq!(chars[*at], '"', "oracle: expected a string: {payload}");
        *at += 1;
        let mut value = String::new();
        while chars[*at] != '"' {
            if chars[*at] == '\\' {
                *at += 1;
                match chars[*at] {
                    'n' => value.push('\n'),
                    't' => value.push('\t'),
                    'r' => value.push('\r'),
                    '"' => value.push('"'),
                    '\\' => value.push('\\'),
                    other => panic!("oracle: unhandled escape \\{other}"),
                }
            } else {
                value.push(chars[*at]);
            }
            *at += 1;
        }
        *at += 1;
        value
    };
    while chars[at].is_ascii_whitespace() {
        at += 1;
    }
    assert_eq!(chars[at], '{', "oracle: expected an object: {payload}");
    at += 1;
    loop {
        while chars[at].is_ascii_whitespace() {
            at += 1;
        }
        if chars[at] == '}' {
            break;
        }
        if !out.is_empty() {
            assert_eq!(chars[at], ',', "oracle: expected ',': {payload}");
            at += 1;
        }
        let key = string(&mut at);
        assert_eq!(chars[at], ':', "oracle: expected ':': {payload}");
        at += 1;
        let value = string(&mut at);
        out.push((key, value));
    }
    out
}

/// `--json` on two verbs: the output is one JSON object whose facts are exactly the facts the
/// records wire carries — the encoding changes how a fact is written, never which facts
/// exist. Ground truth comes from this test's own records-mode oracle conversation.
#[test]
fn json_output_carries_the_same_facts_the_records_wire_carries() {
    let daemon = spawn_daemon("cli-json");
    let address = format!("127.0.0.1:{}", daemon.port);

    let (code, stdout, stderr) = run_cli(&["status", "--json", "--addr", &address]);
    assert_eq!(code, 0, "stderr: {stderr}");
    let line = stdout.trim();
    assert!(
        line.starts_with('{') && line.ends_with('}'),
        "one JSON object: {stdout}"
    );
    let json_facts = oracle_parse_flat_json(line);

    let truth = oracle_conversation(daemon.port, "runtime.status", b"");
    let find = |facts: &[(String, String)], key: &str| {
        facts
            .iter()
            .find(|(k, _)| k == key)
            .map(|(_, v)| v.clone())
            .unwrap_or_default()
    };
    for key in [
        "core_running",
        "active_profile",
        "active_snapshot",
        "pending_recovery_decisions",
        "last_recovery_summary",
    ] {
        assert_eq!(
            find(&json_facts, key),
            find(&truth, key),
            "{key} must be the same fact in both encodings"
        );
    }

    let (code, stdout, stderr) = run_cli(&["profiles", "--json", "--addr", &address]);
    assert_eq!(code, 0, "stderr: {stderr}");
    let profiles_facts = oracle_parse_flat_json(stdout.trim());
    let profiles_truth = oracle_conversation(daemon.port, "profiles.list", b"");
    assert_eq!(
        find(&profiles_facts, "profile_count"),
        find(&profiles_truth, "profile_count"),
        "the count is the same fact in both encodings"
    );
    let count = find(&profiles_truth, "profile_count")
        .parse::<usize>()
        .unwrap_or(0);
    for index in 0..count {
        assert_eq!(
            find(&profiles_facts, &format!("profile_{index}_id")),
            find(&profiles_truth, &format!("profile_{index}_id")),
            "indexed lines ride both encodings"
        );
    }
}

/// `--json` asks for JSON at hello and speaks JSON on the way in too: the proof is that a
/// daemon which only spoke records could not answer this client at all — and it does.
#[test]
fn a_json_cli_is_answered_by_a_json_session_end_to_end() {
    let daemon = spawn_daemon("cli-json-e2e");
    let address = format!("127.0.0.1:{}", daemon.port);

    let (code, stdout, stderr) = run_cli(&[
        "apply",
        "demo-tun-profile",
        "--idempotency-key",
        "cli-e2e-json",
        "--json",
        "--addr",
        &address,
    ]);
    assert_eq!(code, 0, "stderr: {stderr}");
    let facts = oracle_parse_flat_json(stdout.trim());
    let find = |key: &str| {
        facts
            .iter()
            .find(|(k, _)| k == key)
            .map(|(_, v)| v.clone())
            .unwrap_or_default()
    };
    assert!(
        !find("job_id").is_empty(),
        "the acceptance rides JSON too: {stdout}"
    );
    let job_id = find("job_id");

    let (code, stdout, stderr) = run_cli(&["job", &job_id, "--json", "--addr", &address]);
    assert_eq!(code, 0, "stderr: {stderr}");
    let summary = oracle_parse_flat_json(stdout.trim());
    let state = summary
        .iter()
        .find(|(k, _)| k == "state")
        .map(|(_, v)| v.clone())
        .unwrap_or_default();
    assert_eq!(
        state, "completed",
        "the whole verb surface speaks JSON: {stdout}"
    );
}

/// `caly follow <job>`: the lines it prints are exactly the lines `caly jobs` prints (two
/// verbs, one projection), the cursor works (`--from N` is the exclusive resume the events op
/// serves), and the exit code is the verdict.
#[test]
fn caly_follow_prints_what_jobs_prints_and_exits_by_the_verdict() {
    let daemon = spawn_daemon("cli-follow");
    let address = format!("127.0.0.1:{}", daemon.port);

    let (code, stdout, stderr) = run_cli(&[
        "apply",
        "demo-tun-profile",
        "--idempotency-key",
        "cli-e2e-follow",
        "--addr",
        &address,
    ]);
    assert_eq!(code, 0, "stderr: {stderr}");
    let job_id = stdout
        .lines()
        .find_map(|line| line.strip_prefix("job_id: "))
        .unwrap_or_default()
        .trim()
        .to_owned();

    let lines_of = |stdout: &str| -> Vec<String> {
        stdout
            .lines()
            .filter_map(|line| line.strip_prefix("  - "))
            .map(str::to_owned)
            .collect()
    };
    let (code, jobs_out, stderr) = run_cli(&["jobs", &job_id, "--addr", &address]);
    assert_eq!(code, 0, "stderr: {stderr}");
    let (code, follow_out, stderr) = run_cli(&["follow", &job_id, "--addr", &address]);
    assert_eq!(code, 0, "a succeeded job exits 0; stderr: {stderr}");
    assert_eq!(
        lines_of(&follow_out),
        lines_of(&jobs_out),
        "follow streams exactly what jobs pages — one projection, two verbs"
    );

    // The cursor: `--from N` is the exclusive resume (the same N `jobs --from` takes).
    let all = lines_of(&jobs_out);
    let (code, tail, stderr) = run_cli(&["follow", &job_id, "--from", "3", "--addr", &address]);
    assert_eq!(code, 0, "stderr: {stderr}");
    assert_eq!(
        lines_of(&tail),
        all[4..].to_vec(),
        "from=3 replays after event 3 — the cursor contract the events op serves"
    );

    // An unknown job: named on stderr, and the conversation disagrees (13).
    let (code, _out, stderr) = run_cli(&["follow", "424242", "--addr", &address]);
    assert_eq!(code, 13, "{stderr}");
    assert!(stderr.contains("424242"), "{stderr}");
}

/// A failed job's stream: the lines still flush (the failure is in the lines), and the exit
/// code is the verdict — 1, not 0. A rollback with no snapshot to roll back to is the honest
/// way to make a job fail over the wire.
#[test]
fn caly_follow_exits_nonzero_for_a_failed_job() {
    let daemon = spawn_daemon("cli-follow-failed");
    let address = format!("127.0.0.1:{}", daemon.port);

    let (code, stdout, stderr) = run_cli(&[
        "rollback",
        "--idempotency-key",
        "cli-e2e-fail",
        "--addr",
        &address,
    ]);
    assert_eq!(code, 0, "the rollback command itself is accepted: {stderr}");
    let job_id = stdout
        .lines()
        .find_map(|line| line.strip_prefix("job_id: "))
        .unwrap_or_default()
        .trim()
        .to_owned();

    let (code, stdout, stderr) = run_cli(&["follow", &job_id, "--addr", &address]);
    assert_eq!(code, 1, "a failed job exits 1, not 0; stderr: {stderr}");
    assert!(
        stdout.contains("[done] Failed"),
        "the verdict is in the flushed lines: {stdout}"
    );
}

/// The reconnect path from the client: `caly follow` acks what it printed (the confirmation
/// is the conversation's last frame), says its stream id on stderr, and `--resume <id>`
/// prints **nothing new** — the acked cursor is where the daemon picks up. A resume of an
/// unknown stream is a named refusal (13).
#[test]
fn caly_follow_acks_and_a_resume_prints_nothing_new() {
    let daemon = spawn_daemon("cli-resume");
    let address = format!("127.0.0.1:{}", daemon.port);

    let (code, stdout, stderr) = run_cli(&[
        "apply",
        "demo-tun-profile",
        "--idempotency-key",
        "cli-e2e-resume",
        "--addr",
        &address,
    ]);
    assert_eq!(code, 0, "stderr: {stderr}");
    let job_id = stdout
        .lines()
        .find_map(|line| line.strip_prefix("job_id: "))
        .unwrap_or_default()
        .trim()
        .to_owned();

    let (code, first, stderr) = run_cli(&["follow", &job_id, "--addr", &address]);
    assert_eq!(code, 0, "stderr: {stderr}");
    let printed = first
        .lines()
        .filter(|line| line.starts_with("  - "))
        .count();
    assert!(printed >= 6, "the fresh stream prints its lines: {first}");
    let stream_id = stderr
        .lines()
        .find_map(|line| line.strip_prefix("caly: stream "))
        .and_then(|line| line.split(' ').next())
        .unwrap_or_default()
        .to_owned();
    assert!(
        !stream_id.is_empty(),
        "the stream id rides stderr: {stderr}"
    );

    let (code, resumed, stderr) = run_cli(&["follow", "--resume", &stream_id, "--addr", &address]);
    assert_eq!(
        code, 0,
        "an acked-complete resume still exits 0; stderr: {stderr}"
    );
    assert!(
        resumed
            .lines()
            .filter(|line| line.starts_with("  - "))
            .count()
            == 0,
        "the acked cursor is where the daemon picks up — nothing repeats: {resumed}"
    );

    let (code, _out, stderr) = run_cli(&["follow", "--resume", "424242", "--addr", &address]);
    assert_eq!(code, 13, "{stderr}");
    assert!(stderr.contains("424242"), "{stderr}");
}

/// A fake daemon that answers hello with a hello_ack whose **content** contradicts the
/// session (round 71's judge): the CLI must refuse on what the ack says, not on the frame
/// kind — v0 believed the kind alone and never read the answer. `mismatch` names the lie:
/// "encoding" answers `encoding=msgpack` to a records session (which asked for records),
/// "protocol" answers major 2. If the client accepts the lie it sends a request next; the
/// fake rewards that bug with a successful-looking response, so the test observes the
/// outcome instead of a hang.
fn spawn_mismatching_daemon(mismatch: &str) -> u16 {
    let listener = TcpListener::bind("127.0.0.1:0").expect("bind fake daemon");
    let port = listener.local_addr().expect("port").port();
    let mismatch = mismatch.to_owned();
    std::thread::spawn(move || {
        let (mut stream, _) = listener.accept().expect("accept");
        let mut head = [0u8; 5];
        stream.read_exact(&mut head).expect("hello head");
        let mut hello =
            vec![0u8; u32::from_be_bytes([head[1], head[2], head[3], head[4]]) as usize];
        stream.read_exact(&mut hello).expect("hello body");
        let ack: &[u8] = match mismatch.as_str() {
            "encoding" => {
                b"daemon_name=fake\ndaemon_version=0\ninstance_id=fake\nmajor=1\nminor=0\nencoding=msgpack\ncompression=none"
            }
            _ => {
                b"daemon_name=fake\ndaemon_version=0\ninstance_id=fake\nmajor=2\nminor=0\nencoding=records\ncompression=none"
            }
        };
        let mut frame = vec![2u8];
        frame.extend_from_slice(&(ack.len() as u32).to_be_bytes());
        frame.extend_from_slice(ack);
        stream.write_all(&frame).expect("ack");
        // Only a client that accepted the lie reaches this point; answer it successfully.
        let mut request_head = [0u8; 5];
        if stream.read_exact(&mut request_head).is_ok() {
            let mut payload = vec![
                0u8;
                u32::from_be_bytes([
                    request_head[1],
                    request_head[2],
                    request_head[3],
                    request_head[4],
                ]) as usize
            ];
            let _ = stream.read_exact(&mut payload);
            let response = b"request_id=1";
            let mut frame = vec![4u8];
            frame.extend_from_slice(&(response.len() as u32).to_be_bytes());
            frame.extend_from_slice(response);
            let _ = stream.write_all(&frame);
        }
    });
    port
}

#[test]
fn caly_refuses_a_hello_ack_that_contradicts_the_session() {
    let port = spawn_mismatching_daemon("encoding");
    let (code, _stdout, stderr) = run_cli(&["status", "--addr", &format!("127.0.0.1:{port}")]);
    assert_eq!(code, 13, "an encoding lie is PROTO_MISMATCH: {stderr}");
    assert!(
        stderr.contains("encoding mismatch") && stderr.contains("msgpack"),
        "the refusal must name both sides: {stderr}"
    );

    let port = spawn_mismatching_daemon("protocol");
    let (code, _stdout, stderr) = run_cli(&["status", "--addr", &format!("127.0.0.1:{port}")]);
    assert_eq!(code, 13, "a protocol lie is PROTO_MISMATCH: {stderr}");
    assert!(
        stderr.contains("protocol mismatch") && stderr.contains("2"),
        "the refusal must name both majors: {stderr}"
    );
}
