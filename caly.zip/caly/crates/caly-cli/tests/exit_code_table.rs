//! The exit-code table's content, judged against the code that must obey it.
//!
//! `docs/guides/EXIT_CODES.md` is the contract shell scripts and CI depend on; `caly_cli::ExitCode`
//! and `caly_api::ErrorCode` are the implementation. The doc gate (`caly-arch-test`) checks
//! table *shape*; nothing checks that the table's numbers and names are the code's numbers
//! and names. That is this file: a document claim made checkable the way every other claim
//! in this workspace is — with a command.
//!
//! No process is spawned here (unlike `caly_cli_e2e`): the whole claim is "two statements
//! agree", and reading the document is enough to check it.
//!
//! The oracle reads the table with its own minimal parser (a line starting with `|`, three
//! cells, the first cell a backticked number) — the same "two implementations agreeing"
//! rule the wire e2e oracles use; a table that stops matching the code's shape fails here,
//! not in a renderer.

use std::collections::BTreeMap;

use caly_api::ErrorCode;
use caly_cli::ExitCode;

fn workspace_root() -> &'static std::path::Path {
    std::path::Path::new(env!("CARGO_MANIFEST_DIR"))
        .parent()
        .expect("crates/")
        .parent()
        .expect("workspace root")
}

/// One row of the ErrorCode table: the number and the (first token of the) name cell.
#[derive(Debug, PartialEq, Eq)]
struct DocRow {
    code: u8,
    name: String,
}

/// The slice of `text` between two `## ` markers (exclusive on both ends).
fn section<'a>(text: &'a str, start: &str, end: &str) -> &'a str {
    let after_start = text.split_once(start).map_or("", |(_, rest)| rest);
    after_start
        .split_once(end)
        .map_or(after_start, |(head, _)| head)
}

fn parse_error_code_table(text: &str) -> Vec<DocRow> {
    let mut rows = Vec::new();
    for line in text.lines() {
        let line = line.trim();
        if !line.starts_with('|') {
            continue;
        }
        let cells: Vec<&str> = line.trim_matches('|').split('|').map(str::trim).collect();
        if cells.len() != 3 {
            continue;
        }
        let Some(code) = cells[0].trim_matches('`').parse::<u8>().ok() else {
            continue;
        };
        // `CANCELLED` / interrupted — the first backticked token is the stable name.
        // The name cell is "`CANCELLED` / interrupted": the first backticked token is the
        // stable name, and the closing backtick sits before the slash — strip after the
        // split, not before.
        let name = cells[1]
            .split('/')
            .next()
            .unwrap_or_default()
            .trim()
            .trim_matches('`')
            .trim()
            .to_owned();
        if name.is_empty() {
            continue;
        }
        rows.push(DocRow { code, name });
    }
    rows
}

const ERROR_CODES: &[ErrorCode] = &[
    ErrorCode::ConfigInvalid,
    ErrorCode::Conflict,
    ErrorCode::UnsupportedCapability,
    ErrorCode::CoreNotRunning,
    ErrorCode::CoreFailed,
    ErrorCode::Permission,
    ErrorCode::NetOs,
    ErrorCode::Storage,
    ErrorCode::Timeout,
    ErrorCode::Unavailable,
    ErrorCode::ProtoMismatch,
    ErrorCode::CursorStale,
    ErrorCode::Cancelled,
    ErrorCode::Internal,
];

const EXIT_VARIANTS: &[ExitCode] = &[
    ExitCode::Success,
    ExitCode::GeneralFailure,
    ExitCode::Usage,
    ExitCode::ConfigInvalid,
    ExitCode::Conflict,
    ExitCode::UnsupportedCapability,
    ExitCode::CoreNotRunning,
    ExitCode::CoreFailed,
    ExitCode::Permission,
    ExitCode::NetOs,
    ExitCode::Storage,
    ExitCode::Timeout,
    ExitCode::Unavailable,
    ExitCode::ProtoMismatch,
    ExitCode::CursorStale,
    ExitCode::Cancelled,
    ExitCode::Internal,
];

/// The document's ErrorCode table and the code's `ErrorCode` enum must be the same map:
/// name -> exit number, both directions covered by a set equality.
#[test]
fn the_exit_code_table_matches_the_enumeration() {
    let text = std::fs::read_to_string(format!(
        "{}/docs/guides/EXIT_CODES.md",
        workspace_root().display()
    ))
    .expect("docs/guides/EXIT_CODES.md is the contract under test");

    // Scoped to §3: the §2 table (0/1/2) gained a name column in round 81 and is
    // judged by `the_zero_one_two_names_are_documented_and_twinned` instead.
    let rows = parse_error_code_table(section(&text, "## 3. 稳定业务退出码", "## 4. 映射规则"));
    let documented: BTreeMap<&str, u8> = rows
        .iter()
        .map(|row| (row.name.as_str(), row.code))
        .collect();

    // The code's own map: every ErrorCode names its exit number via `from_error_code`.
    let implemented: BTreeMap<&str, u8> = ERROR_CODES
        .iter()
        .map(|code| {
            (
                code.as_str(),
                caly_cli::from_error_code(*code).as_i32() as u8,
            )
        })
        .collect();

    assert_eq!(
        documented, implemented,
        "docs/guides/EXIT_CODES.md and the ErrorCode enum disagree; the document is the contract \
         scripts depend on, the enum is what the CLI actually exits with"
    );
    assert_eq!(
        rows.len(),
        ERROR_CODES.len(),
        "the table must have exactly one row per ErrorCode variant"
    );
}

/// The two small exit codes (0/1/2) are in the enum, and the whole 0..=16 range is
/// covered exactly once: no skipped number, no duplicate, no leftover variant outside it.
#[test]
fn the_exit_code_range_is_complete_and_unique() {
    let mut seen: std::collections::BTreeSet<i32> =
        EXIT_VARIANTS.iter().map(|code| code.as_i32()).collect();
    assert_eq!(seen.len(), EXIT_VARIANTS.len(), "exit codes must be unique");
    for expected in 0..=16 {
        assert!(
            seen.remove(&expected),
            "exit code {expected} is missing from the enum"
        );
    }
    assert!(seen.is_empty(), "exit codes outside 0..=16: {seen:?}");
}

/// §2's 0/1/2 table carries names since round 81; the document and the code must agree
/// on them, and the two crates' names for the shared codes must never drift apart:
/// `ExitCode::as_str` and `ErrorCode::as_str` are twin spellings of the same contract,
/// and a mismatch would mean the CLI's exit names and the API's error names disagree.
#[test]
fn the_zero_one_two_names_are_documented_and_twinned() {
    let text = std::fs::read_to_string(format!(
        "{}/docs/guides/EXIT_CODES.md",
        workspace_root().display()
    ))
    .expect("docs/guides/EXIT_CODES.md is the contract under test");

    let documented: BTreeMap<u8, &str> = section(&text, "## 2. 成功与通用失败", "## 3.")
        .lines()
        .filter_map(|line| {
            let line = line.trim();
            if !line.starts_with('|') {
                return None;
            }
            let cells: Vec<&str> = line.trim_matches('|').split('|').map(str::trim).collect();
            if cells.len() != 3 {
                return None;
            }
            let number = cells[0].trim_matches('`').parse::<u8>().ok()?;
            let name = cells[1].trim_matches('`');
            Some((number, name))
        })
        .collect::<BTreeMap<_, _>>();

    let expected: BTreeMap<u8, &str> =
        [ExitCode::Success, ExitCode::GeneralFailure, ExitCode::Usage]
            .into_iter()
            .map(|code| (code.as_i32() as u8, code.as_str()))
            .collect();
    assert_eq!(
        documented, expected,
        "docs/guides/EXIT_CODES.md §2 must name 0/1/2 exactly as the enum does"
    );

    // Twin names: for every ErrorCode, the CLI exit name and the API error name are
    // the same string. These live in two crates; only this judge keeps them together.
    for code in ERROR_CODES {
        let exit = caly_cli::from_error_code(*code);
        assert_eq!(
            exit.as_str(),
            code.as_str(),
            "ExitCode::as_str({exit:?}) and ErrorCode::as_str({code:?}) must agree"
        );
    }
}

/// Round 98: a daemon's wire refusal code must map to its documented exit number
/// (docs/guides/EXIT_CODES.md §4.1), not collapse every refusal to PROTO_MISMATCH. Each of the 14 stable
/// public `ApiError.code`s maps to its own exit code; transport/session codes that are not public
/// error codes, plus anything the client does not recognise, fall through to PROTO_MISMATCH (13).
#[test]
fn wire_refusal_codes_map_to_their_documented_exit_codes() {
    // The 14 stable public codes map to the same numbers the §3 table documents.
    let stable = [
        ("CONFIG_INVALID", ExitCode::ConfigInvalid),
        ("CONFLICT", ExitCode::Conflict),
        ("UNSUPPORTED_CAPABILITY", ExitCode::UnsupportedCapability),
        ("CORE_NOT_RUNNING", ExitCode::CoreNotRunning),
        ("CORE_FAILED", ExitCode::CoreFailed),
        ("PERMISSION", ExitCode::Permission),
        ("NET_OS", ExitCode::NetOs),
        ("STORAGE", ExitCode::Storage),
        ("TIMEOUT", ExitCode::Timeout),
        ("UNAVAILABLE", ExitCode::Unavailable),
        ("PROTO_MISMATCH", ExitCode::ProtoMismatch),
        ("CURSOR_STALE", ExitCode::CursorStale),
        ("CANCELLED", ExitCode::Cancelled),
        ("INTERNAL", ExitCode::Internal),
    ];
    for (wire, expected) in stable {
        assert_eq!(
            caly_cli::from_wire_refusal_code(wire),
            expected,
            "wire code {wire} must map to its documented exit code {expected:?}"
        );
        // The string is exactly what the twin ErrorCode name spells (no silent renaming).
        assert_eq!(wire, expected.as_str());
    }

    // Transport/session codes the frame loop emits are NOT public ApiError codes: they mean the
    // CLI and daemon disagree about the wire or session order -> PROTO_MISMATCH.
    for wire in [
        "USAGE",
        "UNSUPPORTED",
        "NOT_FOUND",
        "HANDSHAKE",
        "HELLO_REQUIRED",
        "PROTOCOL",
        "TRANSPORT",
        "STREAM_CAPACITY",
    ] {
        assert_eq!(
            caly_cli::from_wire_refusal_code(wire),
            ExitCode::ProtoMismatch,
            "transport code {wire} is a wire disagreement -> PROTO_MISMATCH (13)"
        );
    }

    // An absent or unrecognised code (e.g. a newer daemon) must not be guessed at.
    assert_eq!(
        caly_cli::from_wire_refusal_code("UNKNOWN"),
        ExitCode::ProtoMismatch
    );
    assert_eq!(
        caly_cli::from_wire_refusal_code(""),
        ExitCode::ProtoMismatch
    );
    assert_eq!(
        caly_cli::from_wire_refusal_code("SOME_FUTURE_CODE"),
        ExitCode::ProtoMismatch
    );
}

/// Round 99: a one-shot `caly job <id>` (jobs.follow) that describes a TERMINALLY FAILED job
/// carries the engine's stable `failure_code` (an ApiError code over the same public code set).
/// The bin helper `job_follow_failure_exit_code` maps it via the same R98 wire-code table so a
/// public failure code exits its documented number, an absent/empty code stays success, and only
/// the jobs.follow operation reads the verdict (other queries always succeed at the exit level).
///
/// The helper lives in the bin (caly.rs), so this test pins the *table* it delegates to: the
/// mapping from failure_code text to exit number is exactly from_wire_refusal_code (R98). The
/// bin-level wiring (only jobs.follow, empty = success) is pinned by the three caly_cli_e2e
/// fixtures `a_one_shot_job_query_*`.
#[test]
fn a_job_failure_code_uses_the_same_public_code_table_as_a_refusal() {
    // The engine's JobEvent::Failed sets failure_code = error.code.as_str() (an ErrorCode over
    // the 14-code public set). Every such code maps to its documented exit number through the
    // R98 table — failure_code is NOT a separate vocabulary.
    for (code, expected) in [
        ("CONFIG_INVALID", ExitCode::ConfigInvalid),
        ("CORE_FAILED", ExitCode::CoreFailed),
        ("PERMISSION", ExitCode::Permission),
        ("NET_OS", ExitCode::NetOs),
        ("STORAGE", ExitCode::Storage),
        ("TIMEOUT", ExitCode::Timeout),
        ("INTERNAL", ExitCode::Internal),
    ] {
        assert_eq!(
            caly_cli::from_wire_refusal_code(code),
            expected,
            "a failed job carrying failure_code={code} must exit its documented number"
        );
    }

    // A failure_code that is empty/absent (a job that has not failed) is the caller's "success"
    // case — the bin helper filters it before reaching this table, pinning exit 0.
    // An unrecognised code on the wire stays a ProtoMismatch (13): the table never guesses.
    assert_eq!(
        caly_cli::from_wire_refusal_code("STORAGE"),
        ExitCode::Storage
    );
}
