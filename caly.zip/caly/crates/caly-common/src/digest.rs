//! SHA-256, for content integrity checks that can actually fail.
//!
//! Why this exists: `RFC-0007 §6.2` requires CAS writes to "完成摘要校验", and `§6.3` requires a
//! content/path mismatch to surface as `IntegrityViolation`. The workspace's existing
//! `artifact_digest` is a 64-bit FNV-style checksum (`caly-core::native::stable_checksum_bytes`).
//! That is fine as a *within-pipeline identity*, but it cannot serve as an integrity check: a
//! 64-bit non-cryptographic hash collides under trivial truncation and says nothing about
//! corruption. Storing a file and "verifying" it against such a checksum would be theatre.
//!
//! So the store layer gets a real digest. Pure `core::::core`-only, matching the workspace's
//! zero-dependency constraint (`docs/history/ONBOARDING_NOTES.md §1.4`); the test vectors are the NIST
//! ones, so the implementation is falsifiable rather than self-consistent.

const K: [u32; 64] = [
    0x428a2f98, 0x71374491, 0xb5c0fbcf, 0xe9b5dba5, 0x3956c25b, 0x59f111f1, 0x923f82a4, 0xab1c5ed5,
    0xd807aa98, 0x12835b01, 0x243185be, 0x550c7dc3, 0x72be5d74, 0x80deb1fe, 0x9bdc06a7, 0xc19bf174,
    0xe49b69c1, 0xefbe4786, 0x0fc19dc6, 0x240ca1cc, 0x2de92c6f, 0x4a7484aa, 0x5cb0a9dc, 0x76f988da,
    0x983e5152, 0xa831c66d, 0xb00327c8, 0xbf597fc7, 0xc6e00bf3, 0xd5a79147, 0x06ca6351, 0x14292967,
    0x27b70a85, 0x2e1b2138, 0x4d2c6dfc, 0x53380d13, 0x650a7354, 0x766a0abb, 0x81c2c92e, 0x92722c85,
    0xa2bfe8a1, 0xa81a664b, 0xc24b8b70, 0xc76c51a3, 0xd192e819, 0xd6990624, 0xf40e3585, 0x106aa070,
    0x19a4c116, 0x1e376c08, 0x2748774c, 0x34b0bcb5, 0x391c0cb3, 0x4ed8aa4a, 0x5b9cca4f, 0x682e6ff3,
    0x748f82ee, 0x78a5636f, 0x84c87814, 0x8cc70208, 0x90befffa, 0xa4506ceb, 0xbef9a3f7, 0xc67178f2,
];

const H0: [u32; 8] = [
    0x6a09e667, 0xbb67ae85, 0x3c6ef372, 0xa54ff53a, 0x510e527f, 0x9b05688c, 0x1f83d9ab, 0x5be0cd19,
];

/// Lowercase hex SHA-256 of `data`.
pub fn sha256_hex(data: &[u8]) -> String {
    let hash = sha256(data);
    let mut out = String::with_capacity(64);
    for byte in hash {
        out.push_str(&format!("{byte:02x}"));
    }
    out
}

/// Prefixed form used by the store layer, so the algorithm is recorded rather than implied.
pub fn sha256_digest(data: &[u8]) -> String {
    format!("sha256:{}", sha256_hex(data))
}

/// True when `digest` matches `data`.
///
/// Accepts `sha256:<hex>` or a bare 64-char hex string. The *hex* is compared case-insensitively
/// (it is data), but the algorithm prefix is matched exactly: `SHA256:` / `Sha256:` are rejected
/// rather than treated as equivalent, because an algorithm identifier is not something to
/// fuzzy-match. A store that silently accepted a differently-named algorithm is a store that
/// cannot tell you which function produced the value it just "verified".
pub fn sha256_matches(digest: &str, data: &[u8]) -> bool {
    let expected = sha256_hex(data);
    let provided = match digest.strip_prefix("sha256:") {
        Some(rest) => rest,
        None if digest.contains(':') => return false,
        None => digest,
    };
    provided.len() == expected.len() && provided.eq_ignore_ascii_case(&expected)
}

fn sha256(data: &[u8]) -> [u8; 32] {
    let mut h = H0;
    let bit_len = (data.len() as u64).saturating_mul(8);

    // Padding: 0x80, then zeros, then the 64-bit big-endian length.
    let mut message = Vec::with_capacity(data.len() + 72);
    message.extend_from_slice(data);
    message.push(0x80);
    while message.len() % 64 != 56 {
        message.push(0);
    }
    message.extend_from_slice(&bit_len.to_be_bytes());

    // `as_chunks` rather than `chunks_exact(64)`: the size is a compile-time constant, so the
    // split cannot produce a ragged tail to reason about.
    let (blocks, tail) = message.as_chunks::<64>();
    debug_assert!(
        tail.is_empty(),
        "the padded message is always a multiple of 64"
    );
    for block in blocks {
        let mut w = [0u32; 64];
        for (i, slot) in w.iter_mut().take(16).enumerate() {
            let offset = i * 4;
            *slot = u32::from_be_bytes([
                block[offset],
                block[offset + 1],
                block[offset + 2],
                block[offset + 3],
            ]);
        }
        for i in 16..64 {
            let s0 = w[i - 15].rotate_right(7) ^ w[i - 15].rotate_right(18) ^ (w[i - 15] >> 3);
            let s1 = w[i - 2].rotate_right(17) ^ w[i - 2].rotate_right(19) ^ (w[i - 2] >> 10);
            w[i] = w[i - 16]
                .wrapping_add(s0)
                .wrapping_add(w[i - 7])
                .wrapping_add(s1);
        }

        let [mut a, mut b, mut c, mut d, mut e, mut f, mut g, mut hh] = h;
        for i in 0..64 {
            let s1 = e.rotate_right(6) ^ e.rotate_right(11) ^ e.rotate_right(25);
            let ch = (e & f) ^ ((!e) & g);
            let temp1 = hh
                .wrapping_add(s1)
                .wrapping_add(ch)
                .wrapping_add(K[i])
                .wrapping_add(w[i]);
            let s0 = a.rotate_right(2) ^ a.rotate_right(13) ^ a.rotate_right(22);
            let maj = (a & b) ^ (a & c) ^ (b & c);
            let temp2 = s0.wrapping_add(maj);
            hh = g;
            g = f;
            f = e;
            e = d.wrapping_add(temp1);
            d = c;
            c = b;
            b = a;
            a = temp1.wrapping_add(temp2);
        }

        for (slot, value) in h.iter_mut().zip([a, b, c, d, e, f, g, hh]) {
            *slot = slot.wrapping_add(value);
        }
    }

    let mut out = [0u8; 32];
    for (i, word) in h.iter().enumerate() {
        out[i * 4..i * 4 + 4].copy_from_slice(&word.to_be_bytes());
    }
    out
}

#[cfg(test)]
mod tests {
    use super::*;

    /// NIST FIPS 180-4 example vectors. These are external ground truth: an implementation that
    /// merely agrees with itself would pass a round-trip test and still be wrong.
    #[test]
    fn matches_known_vectors() {
        assert_eq!(
            sha256_hex(b""),
            "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
        );
        assert_eq!(
            sha256_hex(b"abc"),
            "ba7816bf8f01cfea414140de5dae2223b00361a396177a9cb410ff61f20015ad"
        );
        assert_eq!(
            sha256_hex(b"abcdbcdecdefdefgefghfghighijhijkijkljklmklmnlmnomnopnopq"),
            "248d6a61d20638b8e5c026930c3e6039a33ce45964ff2167f6ecedd419db06c1"
        );
    }

    #[test]
    fn handles_multi_block_and_padding_boundaries() {
        // 55 bytes: the length field must spill into a second block.
        let input = vec![b'a'; 55];
        assert_eq!(sha256_hex(&input).len(), 64);
        // 56 bytes: padding needs a whole extra block.
        let boundary = vec![b'a'; 56];
        assert_ne!(sha256_hex(&input), sha256_hex(&boundary));
        let long = vec![b'z'; 200];
        assert_eq!(sha256_hex(&long).len(), 64);
    }

    #[test]
    fn a_single_bit_change_changes_the_digest() {
        let left = sha256_hex(b"snapshot-record-v1");
        let right = sha256_hex(b"snapshot-record-v2");
        assert_ne!(left, right);
        assert_eq!(left.matches("sha256:").count(), 0);
    }

    #[test]
    fn matcher_accepts_prefixed_bare_and_uppercase_forms() {
        let data = b"payload".to_vec();
        let hex = sha256_hex(&data);
        assert!(sha256_matches(&hex, &data));
        assert!(sha256_matches(&format!("sha256:{hex}"), &data));
        assert!(
            !sha256_matches(&format!("SHA256:{}", hex.to_uppercase()), &data),
            "the algorithm prefix is an identifier and is matched exactly"
        );
        assert!(
            !sha256_matches("sha256:deadbeef", &data),
            "wrong length must not match"
        );
        assert!(
            !sha256_matches(&sha256_hex(b"other"), &data),
            "foreign digest must not match"
        );
    }

    #[test]
    fn prefixed_form_is_stable_and_self_describing() {
        assert_eq!(
            sha256_digest(b"abc"),
            "sha256:ba7816bf8f01cfea414140de5dae2223b00361a396177a9cb410ff61f20015ad"
        );
    }
}
