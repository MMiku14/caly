#![forbid(unsafe_code)]

pub mod digest;
pub mod redact;

#[derive(Clone, Debug, Eq, PartialEq, Hash)]
pub struct TraceId(pub String);

impl TraceId {
    pub fn new(value: impl Into<String>) -> Self {
        Self(value.into())
    }
}

#[derive(Clone, Copy, Debug, Eq, PartialEq, Ord, PartialOrd, Hash)]
pub enum Actor {
    Cli,
    Tui,
    Timer,
    Recovery,
    Automation,
    System,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct IoBudget {
    pub max_bytes: Option<u64>,
    pub max_requests: Option<u32>,
}

impl IoBudget {
    /// No bound on either axis. Correct for a path that is not running on anyone's behalf -- and only
    /// for those: as the *default for a command* it meant `Ctx::io_budget` could never be read for
    /// anything, which is how `ADR-036 §1` described it ("`IoBudget::unlimited()` 是唯一构造方式").
    pub const fn unlimited() -> Self {
        Self {
            max_bytes: None,
            max_requests: None,
        }
    }

    /// How many **accounted** store accesses one command execution may make by default. See
    /// [`IoBudget::default_command`] for what "accounted" means and why bytes are not in it.
    pub const DEFAULT_COMMAND_STORE_REQUESTS: u32 = 64;

    /// What a caller gets when it states no budget: bounded on requests, unbounded on bytes, and
    /// *stated in the docs* rather than unlimited-by-accident (`ADR-036 §2.4`).
    ///
    /// Two decisions are baked into this value, and both are the honest ones:
    ///
    /// * **requests are capped** because the layer that can see an access can also count it. The engine
    ///   bills every store access it can *refuse* (see `crates/caly-engine/src/run_limits.rs`) -- so the
    ///   cap is enforceable where it applies and silent where it cannot be, never a number that looks
    ///   protective while nothing reads it.
    /// * **bytes are not capped** here, because this layer cannot see them all -- and the field is not
    ///   inert: since round 29 a stated `max_bytes` is a ceiling **the ports enforce** (`caly_io::budget`,
    ///   `RFC-0006 §5.3`), checked on both backends by one shared contract pass. What was never true, and
    ///   still is not, is a *cumulative* byte count: the caller's budget cannot reach the port that sees
    ///   sizes, because `StorageBackend`'s methods carry no `Ctx` (`ADR-036 §6bis-decies`).
    pub const fn default_command() -> Self {
        Self {
            max_bytes: None,
            max_requests: Some(Self::DEFAULT_COMMAND_STORE_REQUESTS),
        }
    }

    pub const fn is_unlimited(&self) -> bool {
        self.max_bytes.is_none() && self.max_requests.is_none()
    }
}

/// A cooperative cancellation handle (`ADR-036 §2.2`).
///
/// Deliberately the smallest thing that can be honest: two shared flags, no waker registry, no task
/// table. A parked port future cannot be woken by this (nothing parks it -- that is `ADR-036`'s
/// executor step); what the token *does* do is make cancellation decidable at the points where work is
/// actually driven: [`caly_io::runtime::drive`] checks it before every poll, and the engine checks it
/// between the steps of a command. Anything more would imply a scheduler this workspace does not have,
/// and pretending otherwise is how a `cancel_token` field turns into decoration.
///
/// `child()` is the derivation direction the ADR asks for: the child fires when the parent does, while
/// cancelling the child leaves the parent alone. That is the safe direction for a fan-out -- one
/// sub-call giving up must not cancel its siblings.
#[derive(Clone, Debug, Default)]
pub struct CancelToken {
    fired: std::sync::Arc<std::sync::atomic::AtomicBool>,
    parent: Option<std::sync::Arc<std::sync::atomic::AtomicBool>>,
}

impl CancelToken {
    pub fn new() -> Self {
        Self::default()
    }

    /// Already cancelled. A caller does not need a background thread or a second future to test the
    /// "gave up" path, and the driver must answer `Cancelled` before it spends a poll.
    pub fn pre_cancelled() -> Self {
        let token = Self::new();
        token.cancel();
        token
    }

    pub fn cancel(&self) {
        self.fired.store(true, std::sync::atomic::Ordering::Relaxed);
    }

    pub fn is_cancelled(&self) -> bool {
        let fired = |flag: &std::sync::Arc<std::sync::atomic::AtomicBool>| {
            flag.load(std::sync::atomic::Ordering::Relaxed)
        };
        fired(&self.fired) || self.parent.as_ref().is_some_and(fired)
    }

    pub fn child(&self) -> Self {
        Self {
            fired: std::sync::Arc::new(std::sync::atomic::AtomicBool::new(false)),
            parent: Some(std::sync::Arc::clone(&self.fired)),
        }
    }
}

impl PartialEq for CancelToken {
    /// Identity, not state: two handles are equal when they refer to the *same* cancellation, i.e. a
    /// clone or the token itself. Comparing `is_cancelled()` instead would call every pair of fresh
    /// tokens equal, which is a lie about whether cancelling one cancels the other -- and `Ctx` derives
    /// `PartialEq` on top of this, so the wrong choice here would silently weaken every envelope
    /// comparison in the tests that use it.
    fn eq(&self, other: &Self) -> bool {
        std::sync::Arc::ptr_eq(&self.fired, &other.fired)
            && match (&self.parent, &other.parent) {
                (Some(a), Some(b)) => std::sync::Arc::ptr_eq(a, b),
                (None, None) => true,
                _ => false,
            }
    }
}

impl Eq for CancelToken {}

/// The cumulative half of the byte budget: bytes already moved on this caller's context.
///
/// `IoBudget::max_bytes` is the *statement*; this is the *meter*. The distinction is the whole
/// design: a statement without a scope can only bound one call (the ports' per-call ceiling,
/// round 29), while a meter cloned alongside the context accrues across every call one command
/// makes -- which is what `RFC-0006 §2.4` meant by 前后累加 and what `ADR-036 §6bis-decies`
/// recorded as unreachable while store signatures carried no `Ctx`. Round 33 removed that
/// premise; round 34 (`ADR-039 §2`, step 2) hangs the meter here, on the context, so the scope
/// is the caller's, never a process-wide outage dressed up as a budget.
///
/// Same shape as `CancelToken` on purpose: interior mutability over an atomic, shared by
/// `clone`, identity for equality (two handles are equal when they meter the same scope).
#[derive(Clone, Debug, Default)]
pub struct ByteMeter {
    moved: std::sync::Arc<std::sync::atomic::AtomicU64>,
}

impl ByteMeter {
    pub fn new() -> Self {
        Self::default()
    }

    /// Record bytes that moved. Relaxed: the meter reports spending, it does not order it --
    /// the admission checks below are the refusal path, and they read the same atomic.
    pub fn charge(&self, bytes: u64) {
        self.moved
            .fetch_add(bytes, std::sync::atomic::Ordering::Relaxed);
    }

    /// Bytes charged to this scope so far.
    pub fn spent(&self) -> u64 {
        self.moved.load(std::sync::atomic::Ordering::Relaxed)
    }
}

impl PartialEq for ByteMeter {
    /// Identity, not amount: equal means "meters the same scope", for the same reason
    /// `CancelToken`'s equality is identity -- comparing `spent()` would call every fresh
    /// meter equal, which is a lie about whether charging one charges the other.
    fn eq(&self, other: &Self) -> bool {
        std::sync::Arc::ptr_eq(&self.moved, &other.moved)
    }
}

impl Eq for ByteMeter {}

/// The per-call context every layer shares.
///
/// `ADR-021 §2` froze its meaning (trace / actor / deadline / CAS revision / IO budget). The one
/// addition here is `idempotency_key`, and it follows the note at the end of that ADR — 「未来若扩展
/// `Ctx` 字段，应优先保持向后兼容的默认语义」: the default is `None`, so every existing call site
/// keeps behaving exactly as before.
///
/// It exists because `RFC-0002 §4.1` lists 「`idempotency_key` 处理语义」 among what Local 与 Remote
/// **MUST** share. A key therefore has to be expressible on the one input both façades receive —
/// otherwise one path can dedupe and the other cannot, which is the divergence this field closes.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct RequestContext {
    pub trace_id: TraceId,
    pub actor: Actor,
    pub deadline_ms: Option<u64>,
    pub expected_revision: Option<u64>,
    pub io_budget: IoBudget,
    /// Caller-supplied dedup handle for `Command`s (`RFC-0002 §8.3`). `None` means "this call is
    /// not deduped", which is what both façades used to mean — and what they must continue to mean
    /// identically.
    pub idempotency_key: Option<String>,
    /// Cooperative cancellation (`ADR-036 §2.2`). `Default` is "not cancelled", so every existing call
    /// site keeps behaving exactly as before.
    ///
    /// It cannot cross a wire: a token is a handle, not data. Over the socket, cancellation *is* the
    /// session going away, and mapping that back into a `Cancelled` outcome is `ADR-036`'s later step
    /// -- so the remote façade installs a fresh token per call rather than pretending to forward one
    /// (`docs/history/ONBOARDING_NOTES.md §4.86`).
    pub cancel: CancelToken,
    /// Cumulative bytes moved on this context's behalf (`ADR-039 §2` step 2). Shared by
    /// `clone`, so a context handed down accrues to the command that owns it; fresh contexts
    /// start a fresh scope. Read by the store seam's admission checks (`caly_io::budget`).
    pub byte_meter: ByteMeter,
    /// Absolute monotonic deadline, in milliseconds, in the clock of whoever **drives** the call.
    ///
    /// Not computed here on purpose. `deadline_ms` above is the relative inbound value and is left
    /// untouched; an absolute instant only exists relative to a monotonic clock, and the layer holding
    /// that clock is the layer doing the driving. Storing a pre-computed deadline on `Ctx` would put a
    /// derived value where its owner has no source for it and must remember to refresh it -- the same
    /// mistake `docs/history/ONBOARDING_NOTES.md §4.81` records for the active-snapshot mirror.
    pub deadline_mono_ms: Option<u64>,
}

impl RequestContext {
    pub fn new(trace_id: TraceId, actor: Actor) -> Self {
        Self {
            trace_id,
            actor,
            deadline_ms: None,
            expected_revision: None,
            io_budget: IoBudget::default_command(),
            idempotency_key: None,
            cancel: CancelToken::default(),
            byte_meter: ByteMeter::default(),
            deadline_mono_ms: None,
        }
    }

    /// Turn the relative inbound `deadline_ms` into an absolute monotonic deadline, given the driving
    /// clock's current reading. `now_mono == None` (no clock) leaves it unset -- "no clock" must not
    /// silently mean "deadline at zero", which would cancel everything.
    #[must_use]
    pub fn with_deadline_from(mut self, now_mono: Option<u64>, millis: u64) -> Self {
        self.deadline_mono_ms = now_mono.map(|now| now.saturating_add(millis));
        self
    }

    /// Attach an idempotency key. Both façades forward it unchanged, so a retry that carries the
    /// same key resolves to the same job over either access path.
    pub fn with_idempotency_key(mut self, key: impl Into<String>) -> Self {
        self.idempotency_key = Some(key.into());
        self
    }

    /// CAS precondition (`ADR-021`): refuse the call unless the state is still at `revision`.
    pub fn with_expected_revision(mut self, revision: u64) -> Self {
        self.expected_revision = Some(revision);
        self
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn a_cancel_token_shares_state_with_clones_only() {
        let parent = CancelToken::new();
        let clone = parent.clone();
        let child = parent.child();
        assert!(!parent.is_cancelled() && !clone.is_cancelled() && !child.is_cancelled());

        parent.cancel();
        assert!(clone.is_cancelled(), "a clone is the same handle");
        assert!(
            child.is_cancelled(),
            "a derived token must fire when its parent does -- that is the only direction `ADR-036 §2.2` promises"
        );

        // And the reverse: a sibling giving up must not cancel the operation it was derived from.
        let parent = CancelToken::new();
        let first = parent.child();
        let second = parent.child();
        first.cancel();
        assert!(
            !second.is_cancelled() && !parent.is_cancelled(),
            "one sub-call's cancellation must not take down its siblings or its parent"
        );

        // Equality is identity of the handle, not a snapshot of the flag.
        assert_eq!(parent, parent.clone());
        assert_ne!(parent, parent.child());
    }

    #[test]
    fn a_deadline_is_only_absolute_when_a_clock_says_so() {
        let base = RequestContext::new(TraceId::new("t"), Actor::Cli);
        assert_eq!(base.deadline_ms, None);
        assert_eq!(base.deadline_mono_ms, None);

        let bounded = base.clone().with_deadline_from(Some(1_000), 250);
        assert_eq!(bounded.deadline_mono_ms, Some(1_250));
        assert_eq!(
            bounded.deadline_ms, None,
            "the relative inbound value is left alone; the driver reads the absolute one"
        );

        let blind = base.with_deadline_from(None, 250);
        assert_eq!(
            blind.deadline_mono_ms, None,
            "no clock must mean no deadline, not a deadline at zero -- the latter cancels everything"
        );
    }

    #[test]
    fn a_context_starts_with_no_dedup_handle() {
        let ctx = RequestContext::new(TraceId::new("t"), Actor::Cli);
        assert_eq!(ctx.idempotency_key, None);
        // the same for every other entry point: no constructor hands out a key implicitly
        let mut ctx = ctx;
        ctx.deadline_ms = Some(1);
        assert_eq!(ctx.idempotency_key, None);
        assert!(
            !ctx.cancel.is_cancelled(),
            "the default token must be inert, or every existing call site would arrive cancelled"
        );
    }

    #[test]
    fn the_key_is_carried_without_touching_the_other_fields() {
        let ctx = RequestContext::new(TraceId::new("t"), Actor::Tui)
            .with_idempotency_key("retry-1")
            .with_expected_revision(7);
        assert_eq!(ctx.idempotency_key.as_deref(), Some("retry-1"));
        assert_eq!(ctx.expected_revision, Some(7));
        assert_eq!(ctx.trace_id, TraceId::new("t"));
        assert_eq!(
            ctx.io_budget,
            IoBudget::default_command(),
            "a fresh context has to *name* the budget it runs under. An unset one used to mean\
             `unlimited()`, which was a policy nobody wrote down anywhere"
        );
        assert!(!ctx.io_budget.is_unlimited());
    }
}
