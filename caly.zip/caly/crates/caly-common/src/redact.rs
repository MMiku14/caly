//! Redaction of sensitive text — the machinery behind `RFC-0010 §6`/`§7` and `ADR-020 §3`.
//!
//! Both documents ask for the same thing and neither was implemented: `RFC-0010 §3.3` says
//! masking **MUST** happen when an object is constructed or at a boundary conversion, "not only at
//! display time", and `ADR-020`'s follow-up work names it directly: 「为 `ApiError` 建立统一
//! redactor」. Before this module there was no redactor anywhere in the tree (`grep` over `crates/`
//! for `redact`/`Secret` returned zero hits), so every operator-visible string — job log lines,
//! error summaries, and the support bundle below — left the process exactly as it was produced.
//!
//! # What is masked
//!
//! `RFC-0010 §6.2` lists the minimum targets. Each is a rule here, applied in order:
//!
//! 1. **registered literal secrets** — values the caller knows are secrets, scrubbed wherever they
//!    appear;
//! 2. **PEM blocks** — `-----BEGIN … -----END …`, line inclusive;
//! 3. **URL structure** — userinfo password, sensitive or nested query values, keyless segments;
//! 4. **`key: value` / `key=value` / `"key": "value"`** for a sensitive key name, whole line for
//!    headers whose value is an opaque blob (`Authorization: Bearer …`);
//! 5. **strict mode only** (`§4.1` quasi-secrets): UUIDs, private IPv4 addresses, home-directory
//!    usernames. `§12.1` wants a support bundle to be safe to hand to a stranger, which is where
//!    strict mode belongs.
//!
//! # Deliberate limits
//!
//! * A token carried as an *opaque path segment* (`https://host/S4m3ToK3n…`, no `?`, no key name)
//!   carries no text signal, so no pattern rule can find it. Whoever knows the URL must
//!   [`Redactor::register_secret`] it. That is not a shortcut — it is `§3.3` doing the work at
//!   construction instead of guessing at render time.
//! * Percent-encoded values are matched on their literal bytes only.
//! * Rules never invent a mask: text matching nothing is returned unchanged. Redaction is
//!   therefore idempotent, which is what makes it safe to apply at more than one boundary.
//!
//! The module is pure: no clock, no filesystem, no traits. `ADR-011` keeps that property as the
//! price of being callable from every layer, including the one that renders to a terminal.

/// The stable masked form `RFC-0010 §6.3` asks for.
///
/// A constant rather than a per-callsite format string: `§6.3`'s real requirement is
/// 「同一路径输出行为一致 … 不因前端不同而一处脱敏、一处泄漏」, and a marker that differs between
/// the CLI, the TUI and a bundle is exactly the failure that clause names.
pub const REDACTED: &str = "***REDACTED***";

/// How much additional convergence to apply.
#[derive(Clone, Copy, Debug, Default, Eq, PartialEq, Hash)]
pub enum RedactionPolicy {
    /// `RFC-0010 §6.2` minimum: secrets masked, diagnostics still useful.
    #[default]
    Default,
    /// `§4.1`/`§12.1`: also converge quasi-secrets. Used by the support bundle, whose reader is
    /// not necessarily the person who owns the machine.
    Strict,
}

impl RedactionPolicy {
    pub const fn is_strict(self) -> bool {
        matches!(self, Self::Strict)
    }

    pub const fn as_str(self) -> &'static str {
        match self {
            Self::Default => "default",
            Self::Strict => "strict",
        }
    }

    pub const fn from_strict(strict: bool) -> Self {
        if strict {
            Self::Strict
        } else {
            Self::Default
        }
    }
}

/// Key names whose *value* is secret material in any text shape we emit (`§6.2`).
const SENSITIVE_KEYS: &[&str] = &[
    "token",
    "access_token",
    "id_token",
    "refresh_token",
    "api_key",
    "apikey",
    "api-key",
    "x-api-key",
    "secret",
    "client_secret",
    "subscription_secret",
    "password",
    "passwd",
    "passphrase",
    "psk",
    "private_key",
    "privatekey",
    "privkey",
    "credential",
    "credentials",
    "auth",
    "authorization",
    "proxy-authorization",
    "proxy_authorization",
    "cookie",
    "set-cookie",
    "signature",
    "uuid",
];

/// Extra query-parameter names that carry a secret in a subscription link. The short names are
/// legal *only* here: `?k=…`, `?ud=…` and `?key=…` are how those URLs actually look, and masking
/// a bare `key` field in an arbitrary config line would cost more than it buys.
const QUERY_ONLY_SENSITIVE_KEYS: &[&str] = &["k", "key", "ud", "sub", "subscription", "data"];

/// Query parameters whose value is itself a URL. Masking the nested token by name is not enough:
/// it sits one level down and is usually percent-encoded, so the whole value goes.
const NESTED_URL_KEYS: &[&str] = &["url", "link", "uri", "target_url"];

/// Keys whose value cannot be delimited safely — `Authorization: Bearer abc.def.ghi` contains the
/// spaces and dots that belong to the secret. Everything after the separator is the value.
const WHOLE_LINE_KEYS: &[&str] = &[
    "authorization",
    "proxy-authorization",
    "proxy_authorization",
    "cookie",
    "set-cookie",
    "privkey",
    "private_key",
    "privatekey",
];

/// A "secret" shorter than this is too generic to scrub by literal match without mangling
/// ordinary text (`password: "ab"` aside, a two-character literal would hit everywhere).
const MIN_LITERAL_LEN: usize = 4;

/// Text rules plus the literal secrets a caller registered.
///
/// One instance per process is the point: `§6.3` demands every output path agree, and two
/// independently configured redactors is how one path ends up leaking.
#[derive(Clone, Debug, Eq, PartialEq, Default)]
pub struct Redactor {
    policy: RedactionPolicy,
    literals: Vec<String>,
}

impl Redactor {
    pub fn new(policy: RedactionPolicy) -> Self {
        Self {
            policy,
            literals: Vec::new(),
        }
    }

    /// `policy = Strict`: the support-bundle level of convergence.
    pub fn strict() -> Self {
        Self::new(RedactionPolicy::Strict)
    }

    pub const fn policy(&self) -> RedactionPolicy {
        self.policy
    }

    pub fn literal_secret_count(&self) -> usize {
        self.literals.len()
    }

    /// Remember a value that is a secret, so it is masked wherever it turns up — including inside
    /// text that carries no key name to recognise.
    pub fn register_secret(&mut self, value: &str) {
        let trimmed = value.trim();
        if trimmed.len() < MIN_LITERAL_LEN {
            return;
        }
        if !self.literals.iter().any(|known| known == trimmed) {
            self.literals.push(trimmed.to_owned());
        }
    }

    /// Return a copy whose policy is at least `requested`, keeping the registered secrets.
    ///
    /// Only escalation is offered: a caller that wants *more* convergence (a support bundle, whose
    /// reader is someone else — `RFC-0010 §12.1`) can ask for it, and nothing can use this to make
    /// a stricter process quieter.
    pub fn escalate_to(mut self, requested: RedactionPolicy) -> Self {
        if requested.is_strict() {
            self.policy = RedactionPolicy::Strict;
        }
        self
    }

    pub fn with_secret(mut self, value: impl Into<String>) -> Self {
        let value = value.into();
        self.register_secret(&value);
        self
    }

    /// Return `input` with every rule applied. Idempotent, so applying it at a second boundary
    /// changes nothing but is not wrong either.
    pub fn redact(&self, input: &str) -> String {
        if input.is_empty() {
            return String::new();
        }
        let mut text = self.scrub_literals(input);
        text = scrub_pem_blocks(&text);
        text = scrub_urls(&text, self.policy.is_strict());
        text = scrub_key_values(&text);
        if self.policy.is_strict() {
            text = scrub_uuids(&text);
            text = scrub_private_ipv4(&text);
            text = scrub_home_user(&text);
        }
        text
    }

    /// True when `input` still contains something this redactor would mask.
    ///
    /// This is the predicate the `RFC-0010 §14` gates assert on: "the bundle contains no plaintext
    /// secret" becomes "redaction changes nothing about it", which does not depend on the test
    /// enumerating every secret the production code might have missed.
    pub fn exposes_sensitive_text(&self, input: &str) -> bool {
        self.redact(input) != input
    }

    fn scrub_literals(&self, input: &str) -> String {
        let mut text = input.to_owned();
        for secret in &self.literals {
            if text.contains(secret.as_str()) {
                text = replace_all(&text, secret, REDACTED);
            }
        }
        text
    }
}

/// Replace every occurrence of `needle`.
///
/// Hand-written because the crate has no regex dependency, and because "replace the first only" is
/// the kind of bug that silently turns a redactor into a decoy.
fn replace_all(haystack: &str, needle: &str, replacement: &str) -> String {
    let mut out = String::with_capacity(haystack.len());
    let mut rest = haystack;
    while let Some(at) = rest.find(needle) {
        out.push_str(&rest[..at]);
        out.push_str(replacement);
        rest = &rest[at + needle.len()..];
    }
    out.push_str(rest);
    out
}

fn key_is_sensitive(key: &str) -> bool {
    let Some(normalised) = normalise_key(key) else {
        return false;
    };
    SENSITIVE_KEYS.contains(&normalised.as_str())
        || normalised.ends_with("_token")
        || normalised.ends_with("_secret")
        || normalised.ends_with("_key")
        || normalised.ends_with("password")
        || normalised.ends_with("passphrase")
}

fn query_key_is_sensitive(key: &str) -> bool {
    let Some(normalised) = normalise_key(key) else {
        return false;
    };
    key_is_sensitive(&normalised) || QUERY_ONLY_SENSITIVE_KEYS.contains(&normalised.as_str())
}

fn key_matches(key: &str, candidates: &[&str]) -> bool {
    normalise_key(key)
        .map(|normalised| candidates.contains(&normalised.as_str()))
        .unwrap_or(false)
}

/// Lowercase a candidate key and drop the quoting/namespace decoration a config file or JSON body
/// leaves on it. `None` when the candidate cannot be a key (empty, or not identifier-shaped).
fn normalise_key(raw: &str) -> Option<String> {
    let trimmed = raw.trim().trim_matches('"').trim_matches('\'');
    if trimmed.is_empty() {
        return None;
    }
    if !trimmed
        .chars()
        .all(|ch| ch.is_ascii_alphanumeric() || matches!(ch, '_' | '-' | '.'))
    {
        return None;
    }
    // `proxies.0.password` is a path to a field; the field name is what carries the meaning.
    let leaf = trimmed.rsplit('.').next().unwrap_or(trimmed);
    Some(leaf.to_ascii_lowercase())
}

fn is_key_char(ch: char) -> bool {
    ch.is_ascii_alphanumeric() || matches!(ch, '_' | '-' | '.')
}

/// `RFC-0010 §6.2`: private key material. An unterminated `BEGIN` masks to the end of the input —
/// a truncated bundle is still a bundle that must not carry a half-copied key.
fn scrub_pem_blocks(input: &str) -> String {
    let mut text = input.to_owned();
    while let Some(begin) = text.find("-----BEGIN") {
        let Some(end_rel) = text[begin..].find("-----END") else {
            text = format!("{}{REDACTED}", &text[..begin]);
            break;
        };
        let end_marker = begin + end_rel;
        let line_end = text[end_marker..]
            .find('\n')
            .map(|offset| end_marker + offset)
            .unwrap_or(text.len());
        text = format!("{}{REDACTED}{}", &text[..begin], &text[line_end..]);
    }
    text
}

/// Mask the sensitive parts of every `scheme://…` token in the text.
fn scrub_urls(input: &str, strict: bool) -> String {
    let chars: Vec<char> = input.chars().collect();
    let mut out = String::with_capacity(input.len());
    let mut index = 0usize;
    while index < chars.len() {
        let Some(sep) = find_substring(&chars, index, "://") else {
            out.extend(chars[index..].iter());
            break;
        };
        let mut scheme_start = sep;
        while scheme_start > index
            && (chars[scheme_start - 1].is_ascii_alphanumeric() || chars[scheme_start - 1] == '+')
        {
            scheme_start -= 1;
        }
        let mut end = sep + 3;
        while end < chars.len() && !is_url_delimiter(chars[end]) {
            end += 1;
        }
        out.extend(chars[index..scheme_start].iter());
        let token: String = chars[scheme_start..end].iter().collect();
        out.push_str(&mask_url_token(&token, strict));
        index = end;
    }
    out
}

fn is_url_delimiter(ch: char) -> bool {
    ch.is_whitespace()
        || matches!(
            ch,
            '"' | '\'' | '`' | ',' | ';' | ')' | ']' | '}' | '<' | '>' | '\\'
        )
}

fn find_substring(haystack: &[char], from: usize, needle: &str) -> Option<usize> {
    let target: Vec<char> = needle.chars().collect();
    if target.is_empty() || haystack.len() < target.len() || from + target.len() > haystack.len() {
        return None;
    }
    (from..=haystack.len() - target.len())
        .find(|start| haystack[*start..*start + target.len()] == target[..])
}

fn mask_url_token(token: &str, strict: bool) -> String {
    let mut out = String::with_capacity(token.len());
    let mut remainder = token;
    if let Some(at) = token.find("://") {
        out.push_str(&token[..at + 3]);
        remainder = &token[at + 3..];
    }
    // Split the authority off the path, then the query/fragment off the path.
    let authority_end = remainder.find(['/', '?', '#']).unwrap_or(remainder.len());
    let authority = &remainder[..authority_end];
    let rest = &remainder[authority_end..];
    match authority.rsplit_once('@') {
        Some((userinfo, host)) => {
            if strict {
                out.push_str(REDACTED);
            } else if let Some((user, _)) = userinfo.split_once(':') {
                out.push_str(user);
                out.push(':');
                out.push_str(REDACTED);
            } else {
                out.push_str(userinfo);
            }
            out.push('@');
            out.push_str(host);
        }
        None => out.push_str(authority),
    }
    let (path, query) = split_query(rest);
    out.push_str(path);
    if let Some((separator, value)) = query {
        out.push(separator);
        out.push_str(&mask_query(value));
    }
    out
}

/// Return the path plus the `?`/`#` section, so a fragment is masked as a query would be: a
/// subscription link that carries its credential in the fragment has no key names either.
fn split_query(rest: &str) -> (&str, Option<(char, &str)>) {
    if let Some(at) = rest.find(['?', '#']) {
        (
            &rest[..at],
            Some((rest.as_bytes()[at] as char, &rest[at + 1..])),
        )
    } else {
        (rest, None)
    }
}

fn mask_query(query: &str) -> String {
    let mut segments: Vec<String> = Vec::new();
    for segment in query.split('&') {
        if segment.is_empty() {
            continue;
        }
        match segment.split_once('=') {
            Some((key, _)) if key_matches(key, NESTED_URL_KEYS) || query_key_is_sensitive(key) => {
                segments.push(format!("{key}={REDACTED}"));
            }
            Some((_, _)) => segments.push(segment.to_owned()),
            // A section with no key at all: nothing marks it as benign, so it is masked.
            None => segments.push(REDACTED.to_owned()),
        }
    }
    segments.join("&")
}

/// `key: value`, `key=value`, `"key": "value"` — the shape most diagnostics in this tree use.
fn scrub_key_values(input: &str) -> String {
    if !input.contains(':') && !input.contains('=') {
        return input.to_owned();
    }
    let mut lines: Vec<String> = input.lines().map(redact_line).collect();
    // `lines()` drops line terminators; restore one so a caller's own offsets and the number of
    // lines in a multi-line record do not shift under redaction.
    if input.ends_with('\n') {
        lines.push(String::new());
    }
    lines.join("\n")
}

fn redact_line(line: &str) -> String {
    let chars: Vec<char> = line.chars().collect();
    let mut out = String::with_capacity(line.len());
    let mut index = 0usize;
    while index < chars.len() {
        let ch = chars[index];
        if ch == ':' || ch == '=' {
            if let Some(key) = key_before(&chars, index) {
                if key_is_sensitive(&key) {
                    out.push(ch);
                    let whole = key_matches(&key, WHOLE_LINE_KEYS);
                    let value_start = skip_spaces(&chars, index + 1);
                    // Keep the spacing between the separator and the value: `Authorization: X` and
                    // `Authorization:X` must differ in exactly the same way before and after.
                    out.extend(chars[index + 1..value_start].iter());
                    let quoted = matches!(chars.get(value_start), Some('"') | Some('\''));
                    let open = if quoted { value_start + 1 } else { value_start };
                    let value_end = if whole {
                        chars.len()
                    } else if quoted {
                        closing_quote(&chars, open, chars[value_start])
                    } else {
                        unquoted_value_end(&chars, open)
                    };
                    if value_end > open {
                        out.push_str(REDACTED);
                        if quoted && value_end < chars.len() {
                            out.push(chars[value_end]);
                        }
                        index = value_end + usize::from(quoted);
                        continue;
                    }
                    // Nothing to mask after the separator; keep scanning from there.
                    index = value_start;
                    continue;
                }
            }
        }
        out.push(ch);
        index += 1;
    }
    out
}

/// Walk back from a `:`/`=` to the key it belongs to.
fn key_before(chars: &[char], separator: usize) -> Option<String> {
    let mut cursor = separator;
    while cursor > 0 && matches!(chars[cursor - 1], ' ' | '\t') {
        cursor -= 1;
    }
    let mut quote: Option<char> = None;
    if cursor > 0 && matches!(chars[cursor - 1], '"' | '\'') {
        quote = Some(chars[cursor - 1]);
        cursor -= 1;
    }
    let start = cursor;
    while cursor > 0 && is_key_char(chars[cursor - 1]) {
        cursor -= 1;
    }
    if cursor == start {
        return None;
    }
    let key: String = chars[cursor..start].iter().collect();
    if let Some(quote) = quote {
        // A quoted key has to be closed on this side; `"password: x` is not a key.
        if cursor == 0 || chars[cursor - 1] != quote {
            return None;
        }
    }
    Some(key)
}

fn skip_spaces(chars: &[char], from: usize) -> usize {
    let mut cursor = from;
    while cursor < chars.len() && matches!(chars[cursor], ' ' | '\t') {
        cursor += 1;
    }
    cursor
}

fn closing_quote(chars: &[char], from: usize, quote: char) -> usize {
    (from..chars.len())
        .find(|index| chars[*index] == quote)
        .unwrap_or(chars.len())
}

fn unquoted_value_end(chars: &[char], from: usize) -> usize {
    (from..chars.len())
        .find(|index| {
            matches!(
                chars[*index],
                ',' | ';' | '}' | ']' | ')' | '"' | '\'' | '&' | ' ' | '\t'
            )
        })
        .unwrap_or(chars.len())
}

/// `RFC-0010 §4` counts node UUIDs as secret material; `§4.1` lets strict mode收敛 them.
fn scrub_uuids(input: &str) -> String {
    let chars: Vec<char> = input.chars().collect();
    let mut out = String::with_capacity(input.len());
    let mut index = 0usize;
    while index < chars.len() {
        if looks_like_uuid(&chars, index) {
            out.push_str(REDACTED);
            index += 36;
            continue;
        }
        out.push(chars[index]);
        index += 1;
    }
    out
}

fn looks_like_uuid(chars: &[char], at: usize) -> bool {
    const GROUPS: [usize; 5] = [8, 4, 4, 4, 12];
    if at + 36 > chars.len() {
        return false;
    }
    let mut cursor = at;
    for (position, length) in GROUPS.iter().enumerate() {
        if cursor + *length > chars.len() {
            return false;
        }
        for offset in 0..*length {
            if !chars[cursor + offset].is_ascii_hexdigit() {
                return false;
            }
        }
        cursor += length;
        if position + 1 < GROUPS.len() {
            if chars.get(cursor) != Some(&'-') {
                return false;
            }
            cursor += 1;
        }
    }
    // Refuse to match inside a longer hex run: an object digest is not a UUID.
    !chars
        .get(cursor)
        .is_some_and(|next| next.is_ascii_hexdigit() || *next == '-')
        && !at
            .checked_sub(1)
            .is_some_and(|prev| chars[prev].is_ascii_hexdigit() || chars[prev] == '-')
}

/// `§4.1`: a LAN address identifies the user's network. Strict mode keeps the prefix — enough to
/// say "this was a LAN address" without saying which one.
fn scrub_private_ipv4(input: &str) -> String {
    let chars: Vec<char> = input.chars().collect();
    let mut out = String::with_capacity(input.len());
    let mut index = 0usize;
    while index < chars.len() {
        if let Some(octets) = read_ipv4(&chars, index) {
            if is_private(&octets) {
                out.push_str(&octets[0].to_string());
                out.push_str(&format!(".{REDACTED}.{REDACTED}.{REDACTED}"));
                index += ip_len(&chars, index);
                continue;
            }
        }
        out.push(chars[index]);
        index += 1;
    }
    out
}

fn ip_len(chars: &[char], at: usize) -> usize {
    let mut cursor = at;
    while cursor < chars.len() && (chars[cursor].is_ascii_digit() || chars[cursor] == '.') {
        cursor += 1;
    }
    cursor - at
}

fn read_ipv4(chars: &[char], at: usize) -> Option<[u32; 4]> {
    if at > 0 && (chars[at - 1].is_ascii_digit() || chars[at - 1] == '.') {
        return None;
    }
    let mut octets = [0u32; 4];
    let mut cursor = at;
    for (position, octet) in octets.iter_mut().enumerate() {
        let start = cursor;
        while cursor < chars.len() && chars[cursor].is_ascii_digit() {
            cursor += 1;
        }
        if cursor == start || cursor - start > 3 {
            return None;
        }
        let digits: String = chars[start..cursor].iter().collect();
        *octet = digits.parse().ok()?;
        if *octet > 255 {
            return None;
        }
        if position + 1 < 4 {
            if chars.get(cursor) != Some(&'.') {
                return None;
            }
            cursor += 1;
        }
    }
    if chars
        .get(cursor)
        .is_some_and(|next| next.is_ascii_digit() || *next == '.')
    {
        return None;
    }
    Some(octets)
}

fn is_private(octets: &[u32; 4]) -> bool {
    octets[0] == 10
        || (octets[0] == 192 && octets[1] == 168)
        || (octets[0] == 172 && (16..=31).contains(&octets[1]))
        || octets[0] == 127
        || (octets[0] == 169 && octets[1] == 254)
}

/// `§4.1` lists 进程名/路径 as quasi-secrets; the username inside a home path is the part that
/// identifies a person, so that is the segment that goes.
fn scrub_home_user(input: &str) -> String {
    let mut text = input.to_owned();
    for prefix in ["/home/", "/Users/"] {
        let mut rebuilt = String::with_capacity(text.len());
        let mut rest = text.as_str();
        while let Some(at) = rest.find(prefix) {
            rebuilt.push_str(&rest[..at + prefix.len()]);
            let after = &rest[at + prefix.len()..];
            let user_len = after
                .find(['/', '"', '\'', ' ', ',', ';', ')'])
                .unwrap_or(after.len());
            if user_len == 0 {
                rest = after;
                continue;
            }
            rebuilt.push_str(REDACTED);
            rest = &after[user_len..];
        }
        rebuilt.push_str(rest);
        text = rebuilt;
    }
    text
}

#[cfg(test)]
mod tests {
    use super::*;

    fn redact(input: &str) -> String {
        Redactor::default().redact(input)
    }

    #[test]
    fn benign_text_is_returned_unchanged() {
        // A false positive that destroyed a digest would make diagnostics useless, so the exact
        // shapes the pipeline already prints are pinned here.
        let clean = "apply plan ok artifact=sha256:ba7816bf8f01cfea414140de5dae2223b00361a396177a9cb410ff61f20015ad steps=7 revision=42";
        assert_eq!(redact(clean), clean);
        assert_eq!(redact(""), "");
        assert_eq!(
            redact("group=auto; plan=effect-plan-3"),
            "group=auto; plan=effect-plan-3"
        );
    }

    #[test]
    fn masks_url_query_tokens_and_keeps_other_parameters() {
        let out = redact("fetch https://sub.example.com/y?token=abc123XYZ&name=home");
        assert!(out.contains("token=***"), "{out}");
        assert!(!out.contains("abc123XYZ"), "{out}");
        assert!(out.contains("name=home"), "{out}");
    }

    #[test]
    fn masks_short_subscription_query_keys() {
        for query in ["?k=ABCDEF12345", "?ud=ABCDEF12345", "?key=ABCDEF12345"] {
            let out = redact(&format!("https://host/sub{query}&tls=1.3"));
            assert!(!out.contains("ABCDEF12345"), "{query} -> {out}");
            assert!(out.contains("tls=1.3"), "{query} -> {out}");
        }
    }

    #[test]
    fn masks_an_unkeyed_query_segment_and_a_fragment() {
        let out = redact("https://host/sub?YWJjZGVmZ2hpamts");
        assert!(!out.contains("YWJjZGVmZ2hpamts"), "{out}");
        let out = redact("https://host/sub#YWJjZGVmZ2hpamts");
        assert!(!out.contains("YWJjZGVmZ2hpamts"), "{out}");
    }

    #[test]
    fn masks_a_nested_subscription_url_wholesale() {
        // The converter carries the real subscription link, token included, one level down and
        // percent-encoded: name-matching the inner token is impossible, so the value goes.
        let out = redact(
            "https://conv.example.com/sub?url=https%3A%2F%2Fapi.example.com%2Flink%3Ftoken%3DSEKRIT",
        );
        assert!(out.contains("url=***"), "{out}");
        assert!(!out.contains("SEKRIT"), "{out}");
    }

    #[test]
    fn masks_url_userinfo_password_but_keeps_the_host() {
        let out = redact("core api at http://admin:corr3ct@127.0.0.1:9090/version");
        assert!(out.contains("http://admin:***"), "{out}");
        assert!(!out.contains("corr3ct"), "{out}");
        assert!(out.contains("127.0.0.1:9090/version"), "{out}");
    }

    #[test]
    fn masks_quoted_json_and_toml_values() {
        assert!(!redact(r#"{"name":"hk-1","password":"hunter2!"}"#).contains("hunter2!"));
        assert!(!redact("password = \"hunter2!\"").contains("hunter2!"));
        assert!(
            !redact("[proxy]\nuuid = \"d1ae09f6-1e0e-4f77-9a51-7a3b1f0e2b6c\"")
                .contains("d1ae09f6")
        );
    }

    #[test]
    fn masks_an_authorization_header_to_end_of_line() {
        assert_eq!(
            redact("Authorization: Bearer eyJhbGciOi.secretpart"),
            format!("Authorization: {REDACTED}")
        );
    }

    #[test]
    fn masks_a_pem_block_into_one_marker() {
        let out =
            redact("key:\n-----BEGIN PRIVATE KEY-----\nQUJDRA\n-----END PRIVATE KEY-----\ntail");
        assert!(!out.contains("QUJDRA"), "{out}");
        assert!(!out.contains("BEGIN PRIVATE"), "{out}");
        assert!(out.contains("tail"), "{out}");
    }

    #[test]
    fn masks_an_unterminated_pem_to_the_end() {
        let out = redact("-----BEGIN RSA PRIVATE KEY-----\nQUJDRA\nmore");
        assert_eq!(out, REDACTED, "{out}");
    }

    #[test]
    fn masks_a_registered_literal_without_any_key_context() {
        // `https://host/<opaque token>` has no textual signal. The caller knows the secret, so it
        // registers it — the `RFC-0010 §3.3` route, not a guess.
        let redactor = Redactor::default().with_secret("S4m3ToK3nBase64ishValue");
        let input = "subscription https://host/S4m3ToK3nBase64ishValue";
        let out = redactor.redact(input);
        assert!(!out.contains("S4m3ToK3n"), "{out}");
        assert!(out.contains(REDACTED), "{out}");
    }

    #[test]
    fn literal_registration_ignores_values_too_short_to_be_safe() {
        let redactor = Redactor::default().with_secret("ab");
        assert_eq!(redactor.literal_secret_count(), 0);
        assert_eq!(redactor.redact("abc abd"), "abc abd");
    }

    #[test]
    fn redaction_is_idempotent() {
        let input = "get https://u:p@h/x?token=T Authorization: Bearer T password: \"p4\"";
        let once = redact(input);
        assert_eq!(once, redact(&once));
    }

    #[test]
    fn exposes_sensitive_text_is_the_negative_of_unchanged() {
        let redactor = Redactor::default();
        assert!(redactor.exposes_sensitive_text("token=abc"));
        assert!(!redactor.exposes_sensitive_text("group=auto"));
    }

    #[test]
    fn strict_mode_also_converges_quasi_secrets() {
        let input =
            "peer 192.168.1.23 at /home/mika/caly node d1ae09f6-1e0e-4f77-9a51-7a3b1f0e2b6c";
        assert_eq!(
            redact(input),
            input,
            "default policy must not touch §4.1 items"
        );
        let out = Redactor::strict().redact(input);
        assert!(!out.contains("192.168.1.23"), "{out}");
        assert!(!out.contains("mika"), "{out}");
        assert!(!out.contains("d1ae09f6"), "{out}");
    }

    #[test]
    fn strict_mode_keeps_public_addresses_and_digests() {
        let input = "mirror 1.1.1.1 artifact=sha256:d1ae09f61e0e4f779a517a3b1f0e2b6c";
        assert_eq!(Redactor::strict().redact(input), input);
    }

    #[test]
    fn loopback_counts_as_private_so_strict_masks_its_host_part() {
        let out = Redactor::strict().redact("core api at 127.0.0.1:9090");
        assert!(out.contains("127."), "{out}");
        assert!(!out.contains("127.0.0.1:9090"), "{out}");
    }

    #[test]
    fn keeps_every_other_field_on_a_masked_line() {
        let out = redact("job=7 profile=main password=hunter2 latency=12ms");
        assert!(out.contains("job=7"), "{out}");
        assert!(out.contains("profile=main"), "{out}");
        assert!(out.contains("latency=12ms"), "{out}");
        assert!(!out.contains("hunter2"), "{out}");
    }

    #[test]
    fn line_structure_survives_redaction() {
        let out = redact("line one\ntoken=x\nline three\n");
        assert_eq!(out.lines().count(), 3, "{out:?}");
        assert!(out.ends_with('\n'), "{out:?}");
        assert_eq!(out.lines().nth(2), Some("line three"));
    }

    #[test]
    fn policy_from_strict_flag_is_the_documented_mapping() {
        assert_eq!(RedactionPolicy::from_strict(true), RedactionPolicy::Strict);
        assert_eq!(
            RedactionPolicy::from_strict(false),
            RedactionPolicy::Default
        );
        assert!(RedactionPolicy::Strict.is_strict());
        assert_eq!(RedactionPolicy::Default.as_str(), "default");
    }
}
