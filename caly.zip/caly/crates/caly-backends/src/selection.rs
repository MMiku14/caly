//! Node-selection persistence shared by the command and lifecycle backends.
//!
//! `remember` runs on every successful `select_proxy`; `restore` runs after a
//! core start/restart and re-applies the saved choice. Restoring is
//! best-effort: a missing/corrupt record is a no-op, and a failed re-apply
//! (e.g. the node vanished after a subscription refresh) clears the record
//! instead of retrying forever.

use std::path::Path;
use std::time::Duration;

use caly_domain::NodeId;
use caly_platform::node_selection::{
    NodeSelectionRecord, clear_node_selection, load_node_selection, save_node_selection,
};
use caly_platform::paths::AppPaths;
use tracing::{info, warn};

/// Persists the user's last successful `select_proxy`.
///
/// The stored `group`/`name` pair is exactly what the core controller select
/// API consumes, so a later restore needs no registry lookup.
pub fn remember(node_id: NodeId, group: &str, name: &str) {
    let path = AppPaths::from_env().node_selection_path();
    let record = NodeSelectionRecord {
        node_id: node_id.to_string(),
        group: group.to_owned(),
        name: name.to_owned(),
    };
    if let Err(error) = save_node_selection(&path, &record) {
        warn!(
            message = %error,
            operation = ?error.operation,
            "could not persist node selection"
        );
    }
}

/// Re-applies the persisted selection after a core (re)start.
///
/// The `select` closure drives the actual controller call; the timeout is
/// budgeted by the caller so a slow controller cannot stall the lifecycle
/// window beyond its own budget.
pub fn restore(timeout: Duration, select: impl FnOnce(&str, &str) -> Result<(), String>) {
    let path = AppPaths::from_env().node_selection_path();
    restore_at(&path, timeout, select);
}

/// `restore` with an explicit record path (test seam; production callers use
/// `restore`).
fn restore_at(path: &Path, timeout: Duration, select: impl FnOnce(&str, &str) -> Result<(), String>) {
    let Some(record) = load_node_selection(path) else {
        return;
    };
    match select(&record.group, &record.name) {
        Ok(()) => {
            info!(group = %record.group, node = %record.name, "restored node selection after core start");
        }
        Err(error) => {
            warn!(
                group = %record.group,
                node = %record.name,
                error,
                "node selection re-apply failed; dropping the saved selection"
            );
            clear_node_selection(path);
        }
    }
    let _ = timeout;
}

#[cfg(test)]
mod tests {
    use super::*;

    fn scratch() -> std::path::PathBuf {
        let dir = std::env::temp_dir().join(format!(
            "caly-backends-selection-test-{}-{:?}",
            std::process::id(),
            std::time::SystemTime::now()
                .duration_since(std::time::UNIX_EPOCH)
                .map(|d| d.as_nanos())
                .unwrap_or_default()
        ));
        std::fs::create_dir_all(&dir).ok();
        dir
    }

    #[test]
    fn restore_drives_the_select_closure_with_the_record() {
        let dir = scratch();
        let path = dir.join("node-selection.json");
        save_node_selection(
            &path,
            &NodeSelectionRecord {
                node_id: "node-07".to_owned(),
                group: "PROXY".to_owned(),
                name: "Tokyo-02".to_owned(),
            },
        )
        .ok();
        let mut seen = None;
        restore_at(&path, Duration::from_secs(2), |group, name| {
            seen = Some((group.to_owned(), name.to_owned()));
            Ok(())
        });
        assert_eq!(seen, Some(("PROXY".to_owned(), "Tokyo-02".to_owned())));
        // A successful restore keeps the record for the next restart.
        assert!(path.exists());
        let _ = std::fs::remove_dir_all(&dir);
    }

    #[test]
    fn failed_restore_drops_the_record() {
        let dir = scratch();
        let path = dir.join("node-selection.json");
        save_node_selection(
            &path,
            &NodeSelectionRecord {
                node_id: "node-09".to_owned(),
                group: "PROXY".to_owned(),
                name: "Gone-Node".to_owned(),
            },
        )
        .ok();
        restore_at(&path, Duration::from_secs(2), |_, _| {
            Err("proxy not found".to_owned())
        });
        // The node no longer exists; the stale record is cleared so the next
        // restart does not retry it forever.
        assert!(!path.exists());
        let _ = std::fs::remove_dir_all(&dir);
    }

    #[test]
    fn restore_without_record_is_a_noop() {
        let dir = scratch();
        let path = dir.join("missing.json");
        let mut called = false;
        restore_at(&path, Duration::from_secs(2), |_, _| {
            called = true;
            Ok(())
        });
        assert!(!called);
        let _ = std::fs::remove_dir_all(&dir);
    }
}