//! Dual-core switching owners: lifecycle, command and telemetry adapters that
//! dispatch to one active core while holding both managed kernels.

use std::{sync::Arc, time::Duration};

use caly_corectl::contract::{
    ConnectionDetail, ConnectionSummary, KernelControl, KernelFailure, ProxyGroup,
};
use caly_domain::{
    AppliedState, CapabilitySet, CoreKind, LiveConnection, ObservedState, ProxyGroupView, ProxyMode,
};
use caly_ports::{
    ActorFailure, CoreCommandBackend, CoreLifecycleCommandBackend, CoreReloadOutcome,
    LiveConnectionQuery,
};

use super::{
    CoreLifecycleBackend, MihomoCoreBackend, SharedCoreLifecycleBackend, SingBoxCoreBackend,
    failure,
};

// P7:cell 定义上移 caly-ports(actors 与组装根跨 crate 共享);此 re-export
// 保持 `caly_backends::dual::SharedActiveCore` 既存签名不动(R3 纯移动)。
pub use caly_ports::SharedActiveCore;

/// Lifecycle owner that holds both managed kernels and dispatches start/stop/
/// restart to the active one. `switch_to` stops the running kernel, flips the
/// active cell, then starts the target.
#[derive(Clone)]
pub struct DualCoreLifecycle {
    active: SharedActiveCore,
    mihomo: SharedCoreLifecycleBackend,
    sing_box: SharedCoreLifecycleBackend,
}

impl DualCoreLifecycle {
    pub fn new(
        active: SharedActiveCore,
        mihomo: SharedCoreLifecycleBackend,
        sing_box: SharedCoreLifecycleBackend,
    ) -> Self {
        Self {
            active,
            mihomo,
            sing_box,
        }
    }

    /// Returns the shared active-cell handle for command/telemetry adapters.
    pub fn active_cell(&self) -> SharedActiveCore {
        Arc::clone(&self.active)
    }

    fn backend_for(&self, kind: CoreKind) -> SharedCoreLifecycleBackend {
        match kind {
            CoreKind::Mihomo | CoreKind::Xray => self.mihomo.clone(),
            CoreKind::SingBox => self.sing_box.clone(),
        }
    }

    /// Resolves the active kernel under a loud poisoned-lock guard and
    /// dispatches one lifecycle operation to it (a poisoned
    /// active-core lock must fail loudly instead of silently dispatching
    /// to the wrong kernel).
    fn dispatch_active(
        &self,
        op: impl FnOnce(SharedCoreLifecycleBackend) -> Result<AppliedState, ActorFailure>,
    ) -> Result<AppliedState, ActorFailure> {
        let kind = *self.active.lock().map_err(|poisoned| {
            failure(
                &format!("active-core lock poisoned ({poisoned})"),
                "restart daemon",
            )
        })?;
        op(self.backend_for(kind))
    }

    /// Stops the active kernel (if running), flips the active cell to `target`
    /// and starts it. Idempotent when the target is already active.
    pub fn switch_to(&self, target: CoreKind) -> Result<AppliedState, ActorFailure> {
        let mut active = self.active.lock().map_err(|poisoned| {
            failure(
                &format!("active-core lock poisoned ({poisoned})"),
                "restart daemon",
            )
        })?;
        if *active == target {
            return self.backend_for(target).restart();
        }
        // Gracefully stop the previously active kernel before switching so two
        // kernels never race for the same mixed/controller ports.
        let previous = *active;
        self.backend_for(previous).stop()?;
        *active = target;
        drop(active);
        match self.backend_for(target).start() {
            Ok(state) => Ok(state),
            Err(failure) => {
                // the pre-fix path left BOTH kernels stopped with
                // the active cell pointing at the one that would not start.
                // Best-effort: flip the cell back and try to bring the
                // previous core back up so the operator keeps service.
                if let Ok(mut cell) = self.active.lock() {
                    *cell = previous;
                }
                if let Err(restore_error) = self.backend_for(previous).start() {
                    tracing::error!(
                        restore_error = %restore_error,
                        "also failed to restore the previous core after a failed switch"
                    );
                }
                Err(failure)
            }
        }
    }
}

impl DualCoreLifecycle {
    /// Polls the active kernel for an abnormal exit (crash monitor).
    pub fn poll_abnormal_exit(&self) -> Result<Option<AppliedState>, String> {
        // a poisoned active-core lock used to fall back to
        // polling the *wrong* kernel (Mihomo) instead of erroring.
        let kind = self
            .active
            .lock()
            .map_err(|poisoned| format!("active-core lock poisoned ({poisoned})"))
            .map(|active| *active)?;
        let mut backend = match kind {
            CoreKind::Mihomo | CoreKind::Xray => self
                .mihomo
                .lock()
                .map_err(|poisoned| format!("Mihomo lifecycle lock poisoned ({poisoned})"))?,
            CoreKind::SingBox => self
                .sing_box
                .lock()
                .map_err(|poisoned| format!("sing-box lifecycle lock poisoned ({poisoned})"))?,
        };
        CoreLifecycleBackend::poll_abnormal_exit(&mut backend).map_err(|error| error.clone())
    }
}

impl CoreLifecycleCommandBackend for DualCoreLifecycle {
    fn switch_to(&mut self, target: CoreKind) -> Result<AppliedState, ActorFailure> {
        DualCoreLifecycle::switch_to(self, target)
    }
    fn start(&mut self) -> Result<AppliedState, ActorFailure> {
        self.dispatch_active(|mut backend| backend.start())
    }
    fn stop(&mut self) -> Result<AppliedState, ActorFailure> {
        self.dispatch_active(|mut backend| backend.stop())
    }
    fn restart(&mut self) -> Result<AppliedState, ActorFailure> {
        self.dispatch_active(|mut backend| backend.restart())
    }

    fn hot_reload(
        &mut self,
        config: &[u8],
        timeout: Duration,
    ) -> Result<CoreReloadOutcome, String> {
        let kind = *self
            .active
            .lock()
            .map_err(|poisoned| format!("active-core lock poisoned ({poisoned})"))?;
        self.backend_for(kind).hot_reload(config, timeout)
    }
}

/// Command backend dispatching node selection/mode/connection control to the
/// active core while sharing one subscription node registry across both.
pub struct SwitchableCoreBackend {
    active: SharedActiveCore,
    mihomo: MihomoCoreBackend,
    sing_box: SingBoxCoreBackend,
    /// Rendered kernel config paths, synced in place on `set_mode`
    /// (bug ⑪). `None` in compositions without on-disk configs.
    config_paths: Option<(std::path::PathBuf, std::path::PathBuf)>,
}

impl SwitchableCoreBackend {
    pub fn new(
        mihomo: MihomoCoreBackend,
        sing_box: SingBoxCoreBackend,
        active_cell: SharedActiveCore,
    ) -> Self {
        Self {
            active: active_cell,
            mihomo,
            sing_box,
            config_paths: None,
        }
    }

    /// Attaches the rendered kernel config paths: after the active
    /// core's PATCH lands, both files' mode fields are synced in
    /// place so later starts/switches land on the current mode.
    #[must_use]
    pub fn with_config_paths(
        mut self,
        mihomo: std::path::PathBuf,
        sing_box: std::path::PathBuf,
    ) -> Self {
        self.config_paths = Some((mihomo, sing_box));
        self
    }

    /// The registry shared by both core adapters (subscription indexing target).
    pub fn registry(&self) -> super::CoreNodeRegistry {
        self.mihomo.registry()
    }

    fn active_kind(&self) -> CoreKind {
        self.active
            .lock()
            .map_or(CoreKind::Mihomo, |active| *active)
    }
}

/// Dispatches one command to the active core's adapter.
macro_rules! active_command {
    ($self:ident, $method:ident $(, $args:expr)*) => {
        match $self.active_kind() {
            CoreKind::Mihomo | CoreKind::Xray => $self.mihomo.$method($($args),*),
            CoreKind::SingBox => $self.sing_box.$method($($args),*),
        }
    };
}

impl CoreCommandBackend for SwitchableCoreBackend {
    fn select_proxy(&mut self, node: caly_domain::NodeId) -> Result<AppliedState, ActorFailure> {
        active_command!(self, select_proxy, node)
    }

    fn select_proxy_group(
        &mut self,
        group: &str,
        member: &str,
    ) -> Result<AppliedState, ActorFailure> {
        active_command!(self, select_proxy_group, group, member)
    }

    fn close_all_connections(&mut self) -> Result<ObservedState, ActorFailure> {
        active_command!(self, close_all_connections)
    }

    fn close_connection(&mut self, id: &str) -> Result<ObservedState, ActorFailure> {
        active_command!(self, close_connection, id)
    }

    fn set_mode(&mut self, mode: ProxyMode) -> Result<AppliedState, ActorFailure> {
        let state = active_command!(self, set_mode, mode)?;
        // The leaf persisted the mode record; sync the rendered
        // configs too (best-effort, warns inside) — mode is
        // daemon-global, so the inactive core's file is synced as
        // well for a later `core switch` (bug ⑪).
        if let Some((mihomo, sing_box)) = &self.config_paths {
            crate::mode::sync_rendered_configs(mihomo, sing_box, mode);
        }
        Ok(state)
    }

    fn list_proxy_groups(
        &mut self,
        timeout: Duration,
    ) -> Result<Vec<ProxyGroupView>, ActorFailure> {
        active_command!(self, list_proxy_groups, timeout)
    }
}

/// Kernel control dispatching telemetry sampling to the active core's
/// controller. A switch mid-session keeps sampling truthful without rebuilding
/// the telemetry task.
pub struct SwitchableKernelControl {
    active: SharedActiveCore,
    mihomo: Box<dyn KernelControl + Send>,
    sing_box: Box<dyn KernelControl + Send>,
}

impl SwitchableKernelControl {
    pub fn new(
        active: SharedActiveCore,
        mihomo: Box<dyn KernelControl + Send>,
        sing_box: Box<dyn KernelControl + Send>,
    ) -> Self {
        Self {
            active,
            mihomo,
            sing_box,
        }
    }

    fn active_kind(&self) -> CoreKind {
        self.active
            .lock()
            .map_or(CoreKind::Mihomo, |active| *active)
    }
}

impl LiveConnectionQuery for SwitchableKernelControl {
    fn connection_details(
        &mut self,
        timeout: Duration,
    ) -> Result<Vec<LiveConnection>, ActorFailure> {
        let details = match self.active_kind() {
            CoreKind::Mihomo | CoreKind::Xray => self.mihomo.connection_details(timeout),
            CoreKind::SingBox => self.sing_box.connection_details(timeout),
        }
        .map_err(|error| failure(error.message.as_str(), error.suggested_action.as_str()))?;
        Ok(details.into_iter().map(live_connection).collect())
    }
}

fn live_connection(value: ConnectionDetail) -> LiveConnection {
    LiveConnection {
        id: value.id,
        host: value.host,
        destination_port: value.destination_port,
        network: value.network,
        protocol_type: value.protocol_type,
        inbound_name: value.inbound_name,
        process_path: value.process_path,
        rule: value.rule,
        rule_payload: value.rule_payload,
        outbound: value.outbound,
        chain: value.chain,
        upload_bytes: value.upload_bytes,
        download_bytes: value.download_bytes,
    }
}

impl KernelControl for SwitchableKernelControl {
    fn capabilities(&self) -> CapabilitySet {
        match self.active_kind() {
            CoreKind::Mihomo | CoreKind::Xray => self.mihomo.capabilities(),
            CoreKind::SingBox => self.sing_box.capabilities(),
        }
    }
    fn wait_ready(&mut self, timeout: Duration) -> Result<(), KernelFailure> {
        match self.active_kind() {
            CoreKind::Mihomo | CoreKind::Xray => self.mihomo.wait_ready(timeout),
            CoreKind::SingBox => self.sing_box.wait_ready(timeout),
        }
    }
    fn health_check(&mut self, timeout: Duration) -> Result<(), KernelFailure> {
        match self.active_kind() {
            CoreKind::Mihomo | CoreKind::Xray => self.mihomo.health_check(timeout),
            CoreKind::SingBox => self.sing_box.health_check(timeout),
        }
    }
    fn proxy_groups(&mut self, timeout: Duration) -> Result<Vec<ProxyGroup>, KernelFailure> {
        match self.active_kind() {
            CoreKind::Mihomo | CoreKind::Xray => self.mihomo.proxy_groups(timeout),
            CoreKind::SingBox => self.sing_box.proxy_groups(timeout),
        }
    }
    fn connections(&mut self, timeout: Duration) -> Result<ConnectionSummary, KernelFailure> {
        match self.active_kind() {
            CoreKind::Mihomo | CoreKind::Xray => self.mihomo.connections(timeout),
            CoreKind::SingBox => self.sing_box.connections(timeout),
        }
    }
    fn connection_details(
        &mut self,
        timeout: Duration,
    ) -> Result<Vec<ConnectionDetail>, KernelFailure> {
        // Must forward explicitly: the trait default errors, and a silent
        // empty list here would make every daemon-side flow query
        // indistinguishable from "no active connections"
        // (flow agent audit).
        match self.active_kind() {
            CoreKind::Mihomo | CoreKind::Xray => self.mihomo.connection_details(timeout),
            CoreKind::SingBox => self.sing_box.connection_details(timeout),
        }
    }
    fn traffic(&mut self, timeout: Duration) -> Result<(u64, u64), KernelFailure> {
        match self.active_kind() {
            CoreKind::Mihomo | CoreKind::Xray => self.mihomo.traffic(timeout),
            CoreKind::SingBox => self.sing_box.traffic(timeout),
        }
    }
    fn test_delay(&mut self, name: &str, timeout: Duration) -> Result<Option<u32>, KernelFailure> {
        match self.active_kind() {
            CoreKind::Mihomo | CoreKind::Xray => self.mihomo.test_delay(name, timeout),
            CoreKind::SingBox => self.sing_box.test_delay(name, timeout),
        }
    }
}
