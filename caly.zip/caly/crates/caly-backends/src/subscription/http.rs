//! Direct HTTP subscription backend using the repository's SSRF-safe fetch policy.

use crate::core::MihomoNodeRegistry;
use caly_domain::{SnapshotNodes, SubscriptionId};
use caly_platform::paths::{AppPaths, SafeName};
use caly_ports::{ActorFailure, SubscriptionCommandBackend};
use caly_profile::loader::{LayeredConfigPaths, LoaderLimits, load_layered_yaml_strict};
use caly_subscription::net::{prefer_public_addresses, resolve_host_with_retry};
use caly_subscription::{
    FetchPolicy, FetchResult, FetchValidators, ResolvedAddresses, fetch_pinned,
};

use super::PublicAddressClassifier;
use super::render_compose::uri_body_to_sing_box_json_with;

mod expansion;

/// HTTP fetch attempts before surfacing a failure (absorbs transient blips).
const FETCH_ATTEMPTS: usize = 2;
/// Inter-attempt delay in milliseconds for a transient fetch failure.
const FETCH_RETRY_MILLIS: u64 = 250;

/// A fetch attempt result carrying an explicit transient flag, so retry
/// decisions are structural rather than string-matched.
type Attempt = Result<(), (bool, ActorFailure)>;

/// Runs `attempt` with up to `max_attempts` tries, retrying only transient
/// failures with `retry_millis` backoff. Non-transient failures surface
/// immediately. Pure and testable without network I/O.
fn retry_fetch<F>(
    max_attempts: usize,
    retry_millis: u64,
    mut attempt: F,
) -> Result<(), ActorFailure>
where
    F: FnMut() -> Attempt,
{
    let mut last = crate::failure("fetch failed", "retry");
    for index in 0..max_attempts {
        match attempt() {
            Ok(()) => return Ok(()),
            Err((transient, error)) if index + 1 < max_attempts && transient => {
                last = error;
                std::thread::sleep(std::time::Duration::from_millis(retry_millis));
            }
            Err((_, error)) => return Err(error),
        }
    }
    Err(last)
}

/// Direct HTTP subscription backend using the repository's SSRF-safe fetch policy.
pub struct HttpSubscriptionBackend {
    sources: std::collections::BTreeMap<SubscriptionId, String>,
    cache: super::CachedSubscriptionBackend,
    handle: tokio::runtime::Handle,
    policy: FetchPolicy,
}

impl HttpSubscriptionBackend {
    /// Creates an HTTP backend using the current application runtime handle.
    pub fn new() -> Result<Self, ActorFailure> {
        let handle = tokio::runtime::Handle::try_current().map_err(|_| {
            crate::failure(
                "subscription backend requires a Tokio runtime",
                "construct it inside daemon runtime composition",
            )
        })?;
        Ok(Self {
            sources: std::collections::BTreeMap::new(),
            cache: super::CachedSubscriptionBackend::new(),
            handle,
            policy: FetchPolicy::direct_default(),
        })
    }

    /// Overrides the SSRF-safe fetch policy bounds (timeouts, body cap,
    /// redirects, environment proxy) from configuration.
    #[must_use]
    pub fn with_policy(mut self, policy: FetchPolicy) -> Self {
        self.policy = policy;
        self
    }

    /// Shares an automatic NodeId → Mihomo group/node registry.
    #[must_use]
    pub fn with_node_registry(mut self, registry: MihomoNodeRegistry) -> Self {
        self.cache = self.cache.with_node_registry(registry);
        self
    }

    /// Shares the subscription-author routing registry (groups + rules) so a
    /// refresh indexes author-declared topology alongside the nodes.
    #[must_use]
    pub fn with_routing_registry(mut self, registry: crate::core::CoreRoutingRegistry) -> Self {
        self.cache = self.cache.with_routing_registry(registry);
        self
    }

    /// Enables a persistent raw-body cache directory so the node registry can
    /// be rebuilt after a daemon restart without re-fetching.
    #[must_use]
    pub fn with_cache_dir(mut self, cache_dir: std::path::PathBuf) -> Self {
        self.cache = self.cache.with_cache_dir(cache_dir);
        self
    }

    /// Restores every persisted subscription body into the node registry.
    /// Best-effort: unreadable entries are skipped with a warning. Returns
    /// the restored projection slices for seeding the presentation snapshot.
    pub fn restore_cached(&mut self) -> Result<Vec<caly_domain::SnapshotNodes>, ActorFailure> {
        self.cache.restore_from_cache()
    }

    /// Registers a source URL for a subscription id.
    pub fn put_url(&mut self, id: SubscriptionId, url: String) {
        self.sources.insert(id, url);
    }

    /// Returns the last committed generation.
    pub fn generation(&self, id: SubscriptionId) -> u64 {
        self.cache.generation(id)
    }

    /// Fetches the source and generates a sing-box JSON config from dialable
    /// nodes, rendering the document header from `tuning`.
    pub fn refresh_sing_box_config(
        &mut self,
        id: SubscriptionId,
        tuning: &caly_coreconf::sing_box::SingBoxRenderTuning,
    ) -> Result<Vec<u8>, ActorFailure> {
        self.fetch(id)?;
        let body = self.cache.raw_source(id).ok_or_else(|| {
            crate::failure(
                "sing-box raw subscription cache is missing",
                "retry the source fetch",
            )
        })?;
        uri_body_to_sing_box_json_with(body, id, tuning).map_err(|error| {
            crate::failure(
                &format!("sing-box outbound rendering failed: {error}"),
                "inspect subscription protocol support",
            )
        })
    }

    fn fetch(&mut self, id: SubscriptionId) -> Result<(), ActorFailure> {
        let source = self.sources.get(&id).cloned().ok_or_else(|| {
            crate::failure(
                "subscription URL is not configured",
                "configure a source URL",
            )
        })?;
        let addresses = resolve_addresses(&source)?;
        retry_fetch(FETCH_ATTEMPTS, FETCH_RETRY_MILLIS, || {
            self.fetch_once(&source, &addresses, id)
        })?;
        self.expand_url_list(id)
    }

    fn fetch_once(
        &mut self,
        source: &str,
        addresses: &ResolvedAddresses,
        id: SubscriptionId,
    ) -> Attempt {
        let validators = self.cache.validators(id);
        match self.request_body(source, addresses, &validators)? {
            FetchResult::Updated {
                body,
                etag,
                last_modified,
                userinfo,
            } => {
                self.cache.put_source(id, body.into_vec());
                self.cache.put_userinfo(id, userinfo);
                // Feed the validators back into the next conditional request:
                // without this the server never sees If-None-Match again and
                // every refresh pulls the full body (and the NotModified arm
                // stays dead code).
                self.cache.put_validators(
                    id,
                    FetchValidators {
                        etag,
                        last_modified,
                    },
                );
                Ok(())
            }
            FetchResult::NotModified => Ok(()),
        }
    }

    /// One SSRF-safe pinned HTTP request shared by the primary fetch and the
    /// URL-list child fetches. `validators` carries the conditional-request
    /// metadata from the previous successful fetch of the same URL.
    pub(super) fn request_body(
        &mut self,
        source: &str,
        addresses: &ResolvedAddresses,
        validators: &FetchValidators,
    ) -> Result<FetchResult, (bool, ActorFailure)> {
        // The backend runs inside a `spawn_blocking` actor, so a direct
        // `block_on` is safe and avoids the multi-thread-runtime dependency of
        // `block_in_place` (which would panic on a current-thread runtime).
        self.handle
            .block_on(fetch_pinned(
                source,
                addresses.clone(),
                &PublicAddressClassifier,
                self.policy,
                validators,
            ))
            .map_err(|error| {
                let transient = is_transient_fetch(&error);
                let failure = crate::failure(
                    &format!("subscription fetch failed: {error}"),
                    "inspect HTTP, DNS, and source policy",
                );
                (transient, failure)
            })
    }
}

/// Whether a fetch error is transient and worth retrying: connect/request
/// timeouts and temporary (5xx) server statuses. Policy rejections (bad URL,
/// unsupported scheme, non-public address, body too large) are not retried.
fn is_transient_fetch(error: &caly_subscription::FetchError) -> bool {
    use caly_subscription::FetchError;
    match error {
        FetchError::RequestFailed(_) | FetchError::ClientBuild => true,
        FetchError::UnexpectedStatus(status) => (500..600).contains(status),
        _ => false,
    }
}

fn resolve_addresses(source: &str) -> Result<ResolvedAddresses, ActorFailure> {
    let parsed = url::Url::parse(source)
        .map_err(|_| crate::failure("subscription URL is invalid", "use an HTTP(S) URL"))?;
    let host = parsed
        .host_str()
        .ok_or_else(|| crate::failure("subscription URL has no host", "configure a valid host"))?;
    let port = parsed.port_or_known_default().ok_or_else(|| {
        crate::failure(
            "subscription URL has no port",
            "configure a valid HTTP(S) URL",
        )
    })?;
    // Shared resolver (single implementation lives in caly_subscription::net):
    // retries transient/empty lookups, then filters to public addresses with
    // IPv4 preferred.
    let addresses = resolve_host_with_retry(host, port).map_err(|rejection| {
        let detail = match rejection {
            caly_subscription::net::ResolveRejection::Empty => {
                "subscription DNS returned no answers"
            }
            caly_subscription::net::ResolveRejection::Lookup => {
                "subscription DNS resolution failed"
            }
        };
        crate::failure(detail, "inspect DNS and source availability")
    })?;
    let addresses = prefer_public_addresses(addresses, &PublicAddressClassifier);
    if addresses.is_empty() {
        return Err(crate::failure(
            "subscription resolved only to non-public addresses",
            "use a public subscription host",
        ));
    }
    ResolvedAddresses::try_from_vec(addresses).map_err(|_| {
        crate::failure(
            "subscription has too many DNS answers",
            "use a bounded source host",
        )
    })
}

impl SubscriptionCommandBackend for HttpSubscriptionBackend {
    fn refresh(&mut self, _subscription: SubscriptionId) -> Result<SnapshotNodes, ActorFailure> {
        // Re-resolve the sources each refresh: env wins, then layered config,
        // so a config edit takes effect without a daemon restart. A source
        // registered by bootstrap (e.g. sing-box document rendering) is never
        // overwritten. A broken config.yaml is surfaced as its own error
        // instead of masquerading as "no subscription source is configured".
        let sources = resolve_sources()?;
        for (id, url) in &sources {
            self.sources.insert(*id, url.clone());
        }
        // Fetch every enabled source and merge their projections into one
        // snapshot. A single failing source does not abort the rest; its
        // failure is reported and the remaining sources still land.
        let mut merged = Vec::new();
        let mut first_error: Option<ActorFailure> = None;
        for (id, url) in &sources {
            // Audit #89: a partially-failed multi-source refresh used to drop
            // the failing source's error silently (only returned when ALL
            // sources failed). Warn per failure so the stale nodes that keep
            // serving are at least visible to the operator.
            if let Err(error) = self.fetch(*id) {
                tracing::warn!(
                    subscription = %id,
                    source = %url,
                    error = %error.message,
                    "subscription source fetch failed; keeping any cached nodes"
                );
                if first_error.is_none() {
                    first_error = Some(error);
                }
                continue;
            }
            match self.cache.refresh(*id) {
                Ok(nodes) => merged.extend(nodes.into_vec()),
                Err(error) => {
                    tracing::warn!(
                        subscription = %id,
                        source = %url,
                        error = %error.message,
                        "subscription source re-projection failed; keeping prior nodes"
                    );
                    if first_error.is_none() {
                        first_error = Some(error);
                    }
                }
            }
        }
        if merged.is_empty() {
            return Err(first_error.unwrap_or_else(|| {
                crate::failure(
                    "no subscription source is configured",
                    "configure a source URL",
                )
            }));
        }
        caly_domain::SnapshotNodes::try_from_vec(merged).map_err(|_| {
            crate::failure(
                "merged subscription nodes exceeded the snapshot bound",
                "reduce the number of subscription sources or their node counts",
            )
        })
    }
}

/// Resolves every enabled subscription source: `CALY_SUBSCRIPTION_URL` first
/// (single-source override), then the layered config (`subscriptions.url` plus
/// each enabled `subscriptions.sources` entry). Each URL maps to a stable
/// `SubscriptionId` derived from its SHA-256 digest, so the same URL always
/// targets the same cache entry across restarts; re-evaluated per refresh.
/// A present-but-broken `config.yaml` is a hard error: swallowing it used to
/// bury the parse failure behind a misleading "no subscription source" hint.
fn resolve_sources() -> Result<Vec<(SubscriptionId, String)>, ActorFailure> {
    let mut urls = Vec::new();
    if let Ok(value) = std::env::var("CALY_SUBSCRIPTION_URL") {
        urls.push(value);
    } else {
        let app_paths = AppPaths::from_env();
        let root = app_paths.config.clone();
        if root.join("config.yaml").is_file() {
            let profile = std::env::var("CALY_PROFILE")
                .ok()
                .and_then(|v| SafeName::new(v).ok());
            let paths = LayeredConfigPaths::new(root, profile);
            let config =
                load_layered_yaml_strict(&paths, LoaderLimits::secure_default(), &app_paths.state)
                    .map_err(|error| {
                        crate::failure(
                            &format!("config load failed while resolving subscriptions: {error}"),
                            "run `caly config validate` and fix the configuration",
                        )
                    })?;
            urls.extend(config.subscriptions.enabled_source_urls());
        }
    }
    let mut out: Vec<(SubscriptionId, String)> = Vec::new();
    let mut seen: std::collections::BTreeSet<SubscriptionId> = std::collections::BTreeSet::new();
    for url in urls {
        let id = subscription_id_for_url(&url);
        if seen.insert(id) {
            out.push((id, url));
        }
    }
    Ok(out)
}

/// Stable 16-byte `SubscriptionId` from a source URL digest.
///
/// Audit #120: hash the *normalised* URL — `url::Url` parsing lowercases
/// scheme/host, strips a redundant default port and the empty-path
/// distinction, so equivalent spellings of one source share the id/cache
/// entry instead of fragmenting validators and cached bodies across
/// duplicates.
pub fn subscription_id_for_url(url: &str) -> SubscriptionId {
    use sha2::{Digest, Sha256};
    let normalized =
        url::Url::parse(url).map_or_else(|_| url.to_owned(), |parsed| parsed.to_string());
    let mut hasher = Sha256::new();
    hasher.update(normalized.as_bytes());
    let digest = hasher.finalize();
    let mut bytes = [0_u8; 16];
    bytes.copy_from_slice(&digest[..16]);
    SubscriptionId::from_bytes(bytes)
}

#[cfg(test)]
mod tests;
