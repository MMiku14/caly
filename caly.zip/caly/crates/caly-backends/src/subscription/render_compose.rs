//! Subscription-intake × coreconf-renderer fusion (the daemon path).
//!
//! The pure renderers live in `caly-coreconf` (domain values in, config bytes
//! out); intake of a fetched subscription body (decode → dialable nodes)
//! lives in `caly-profile`. This module is the single meeting point: it
//! drives the coreconf renderers with intake output so the rest of the
//! backend never re-implements either half.

use std::collections::BTreeMap;

use caly_corectl::conf::{
    mihomo::{
        proxy_sections::{
            MihomoGroupName, MihomoProxyEntry, MihomoProxyError, MihomoProxySet, MihomoProxyTag,
        },
        render::proxy_to_entry,
    },
    sing_box::{
        SingBoxOutboundError, SingBoxRenderTuning, node_to_json, nodes_to_outbounds,
        sing_box_document,
    },
};
use caly_domain::{BoundedVec, DialableNode, NodeId, SubscriptionId};
use serde_json::Value;
use caly_subscription::{
    PipelineError, SubscriptionDocument, decode_document, dedupe, display_tags,
    parse_document_dialable_lossy,
};

/// Kernel-agnostic shape of the two subscription-render errors: both the
/// Mihomo and sing-box error types expose `InvalidFormat`/`UnsupportedDocument`
/// variants with the same meaning, which is all the shared extraction needs.
trait DialableExtraction {
    const INVALID_FORMAT: Self;
    const UNSUPPORTED_DOCUMENT: Self;
}

impl DialableExtraction for SingBoxOutboundError {
    const INVALID_FORMAT: Self = Self::InvalidFormat;
    const UNSUPPORTED_DOCUMENT: Self = Self::UnsupportedDocument;
}

impl DialableExtraction for MihomoProxyError {
    const INVALID_FORMAT: Self = Self::InvalidFormat;
    const UNSUPPORTED_DOCUMENT: Self = Self::UnsupportedDocument;
}

/// Decodes a raw subscription body exactly once, then hands the document to
/// `decode` — the single-pass entry point shared by the kernel renderers
/// (see [`sing_box_outbound_map_from_document`] for the pipeline rule).
fn decode_once<D, E>(
    body: &[u8],
    decode: impl FnOnce(&SubscriptionDocument) -> Result<D, E>,
) -> Result<D, E>
where
    E: DialableExtraction,
{
    let document = decode_document(body).map_err(|_| E::INVALID_FORMAT)?;
    decode(&document)
}

/// Generates a bounded sing-box JSON document from URI subscription lines.
pub fn uri_body_to_sing_box_json(
    body: &[u8],
    subscription: SubscriptionId,
) -> Result<Vec<u8>, SingBoxOutboundError> {
    uri_body_to_sing_box_json_with(body, subscription, &SingBoxRenderTuning::standard())
}

/// Generates the document with config-driven header tuning (controller, secret,
/// log level, mixed inbound).
pub fn uri_body_to_sing_box_json_with(
    body: &[u8],
    subscription: SubscriptionId,
    tuning: &SingBoxRenderTuning,
) -> Result<Vec<u8>, SingBoxOutboundError> {
    let nodes = decode_once(body, |document| {
        dialable_nodes::<SingBoxOutboundError>(document, subscription)
    })?;
    let outbounds = nodes_to_outbounds(nodes)?;
    sing_box_document(tuning, outbounds)
}

/// One node a kernel renderer skipped, with the reason the operator can
/// act on. Shared by the sing-box and Mihomo compose paths: both carry the
/// display tag plus a stable reason label (the unsupported protocol label,
/// possibly refined — `shadowsocks+plugin`, … — or `tag-rejected` when the
/// display name cannot become a tag).
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct NodeSkip {
    /// The node's display tag (what lists and groups show).
    pub tag: String,
    /// Stable reason label (see above).
    pub reason: &'static str,
}

/// Renders per-node sing-box outbound JSON values keyed by canonical
/// `NodeId`, skipping nodes the strict renderer cannot represent, and
/// returning the skip list alongside so the caller can warn with the
/// reason (a silently shrinking node pool is a routing change the
/// operator cannot see). The registry stores the map so a config backend
/// can rebuild the outbounds array without re-parsing the subscription
/// body (mirrors the Mihomo yaml field). Values (not strings) are stored:
/// the config backend assembles `Value`s, so strings would pay a
/// serialize→parse roundtrip per node per refresh+apply (O1).
pub fn uri_body_to_sing_box_outbound_map(
    body: &[u8],
    subscription: SubscriptionId,
) -> Result<(BTreeMap<NodeId, Value>, Vec<NodeSkip>), SingBoxOutboundError> {
    decode_once(body, |document| {
        sing_box_outbound_map_from_document(document, subscription)
    })
}

/// [`uri_body_to_sing_box_outbound_map`] on an already-decoded document —
/// the single-pass pipeline entry (`cached.rs` decodes once per refresh and
/// shares the document across the projection / mihomo / sing-box / routing
/// consumers instead of decoding the body up to four times).
pub fn sing_box_outbound_map_from_document(
    document: &SubscriptionDocument,
    subscription: SubscriptionId,
) -> Result<(BTreeMap<NodeId, Value>, Vec<NodeSkip>), SingBoxOutboundError> {
    let nodes = dialable_nodes::<SingBoxOutboundError>(document, subscription)?;
    Ok(sing_box_outbound_map_from_nodes(&nodes))
}

/// Renders the outbound map from already-parsed nodes (P2: the daemon parses
/// once and shares the nodes across the projection and both renderers).
/// Infallible: unrepresentable nodes land in the skip list, never in `Err`.
/// Accepts raw or deduped nodes — the first-seen guard below keeps both
/// shapes identical.
pub fn sing_box_outbound_map_from_nodes(
    nodes: &[DialableNode],
) -> (BTreeMap<NodeId, Value>, Vec<NodeSkip>) {
    let mut map = BTreeMap::new();
    let mut skipped = Vec::new();
    for node in nodes {
        if map.contains_key(&node.id()) {
            continue;
        }
        if let Ok(outbound) = node_to_json(node) {
            map.insert(node.id(), outbound);
        } else {
            let tag = node.display(true, None).map_or_else(
                |_| format!("node-{}", caly_domain::to_hex(node.id().into_bytes())),
                |display| display.name().as_str().to_owned(),
            );
            // A finer label than the bare protocol: a shadowsocks node
            // with a v2ray-plugin/obfs parameter is *not* a plain ss
            // node — the warning must say which variant lost.
            let reason = match node.protocol() {
                caly_domain::Protocol::Shadowsocks {
                    plugin: Some(_), ..
                } => "shadowsocks+plugin",
                // Legacy CFB ciphers: Mihomo dials them, sing-box does
                // not — name the exact cipher so the operator can see
                // why the node pool differs between cores.
                caly_domain::Protocol::Shadowsocks {
                    method: caly_domain::ShadowsocksCipher::Aes128Cfb,
                    plugin: None,
                    ..
                } => "shadowsocks+aes-128-cfb",
                caly_domain::Protocol::Shadowsocks {
                    method: caly_domain::ShadowsocksCipher::Aes256Cfb,
                    plugin: None,
                    ..
                } => "shadowsocks+aes-256-cfb",
                other => other.label(),
            };
            skipped.push(NodeSkip { tag, reason });
        }
    }
    (map, skipped)
}

/// Renders a Mihomo proxy section (proxies/groups/rules) from a subscription
/// body, reusing the same dialable pipeline as the sing-box renderer.
/// Skipped nodes ride along for the caller to warn about.
pub fn uri_body_to_mihomo_proxy_set(
    body: &[u8],
    subscription: SubscriptionId,
) -> Result<(MihomoProxySet, Vec<NodeSkip>), MihomoProxyError> {
    decode_once(body, |document| {
        mihomo_proxy_set_from_document(document, subscription)
    })
}

/// [`uri_body_to_mihomo_proxy_set`] on an already-decoded document (single-
/// pass pipeline; see [`sing_box_outbound_map_from_document`]).
/// Nodes the Mihomo renderer cannot represent (unsupported protocol, tag
/// rejection) are collected into the skip list instead of vanishing.
pub fn mihomo_proxy_set_from_document(
    document: &SubscriptionDocument,
    subscription: SubscriptionId,
) -> Result<(MihomoProxySet, Vec<NodeSkip>), MihomoProxyError> {
    // Dedupe by NodeId with the same first-seen order the projection uses, so
    // the `#N` suffix numbering assigned below matches what list UIs show.
    let deduped = dedupe(dialable_nodes::<MihomoProxyError>(document, subscription)?)
        .map_err(|_| MihomoProxyError::InvalidFormat)?;
    let nodes = deduped.nodes.as_slice();
    // Fail-closed like the projection (the old `filter_map`+`zip` truncation
    // arm is dead — `display()` cannot fail — and is not preserved; P2).
    let tags = display_tags(nodes).map_err(|_| MihomoProxyError::InvalidFormat)?;
    mihomo_proxy_set_from_nodes(nodes, &tags)
}

/// Renders the proxy set from already-parsed, already-tagged nodes (P2: the
/// daemon parses/dedupes/tags once and shares them across the projection and
/// both renderers). `tags` must align 1:1 with `nodes`; a length mismatch
/// fails closed rather than mislabeling proxies.
pub fn mihomo_proxy_set_from_nodes(
    nodes: &[DialableNode],
    tags: &[String],
) -> Result<(MihomoProxySet, Vec<NodeSkip>), MihomoProxyError> {
    if tags.len() != nodes.len() {
        return Err(MihomoProxyError::InvalidFormat);
    }
    let mut entries: Vec<MihomoProxyEntry> = Vec::with_capacity(nodes.len());
    let mut skipped = Vec::new();
    for (node, tag_text) in nodes.iter().zip(tags) {
        let Ok(tag) = MihomoProxyTag::new(tag_text.clone()) else {
            skipped.push(NodeSkip {
                tag: tag_text.clone(),
                reason: "tag-rejected",
            });
            continue;
        };
        match proxy_to_entry(node, tag) {
            Ok(entry) => entries.push(entry),
            Err(MihomoProxyError::NoUsableNodes) => {
                skipped.push(NodeSkip {
                    tag: tag_text.clone(),
                    reason: node.protocol().label(),
                });
            }
            Err(error) => return Err(error),
        }
    }
    if entries.is_empty() {
        return Err(MihomoProxyError::NoUsableNodes);
    }
    let entries =
        BoundedVec::try_from_vec(entries).map_err(|_| MihomoProxyError::TooManyProxies)?;
    let group = MihomoGroupName::new(group_name())?;
    Ok((MihomoProxySet::from_parts(entries, group), skipped))
}

/// Extracts dialable nodes through the canonical lossy intake so body-level
/// renders parse exactly what the daemon projection parses — no second
/// traversal to drift. A body with zero usable nodes now fails closed
/// instead of rendering hollow (the bootstrap maps that to
/// `BackendUnavailable`). `Clash` keeps today's `UNSUPPORTED_DOCUMENT`
/// label for unparseable YAML; every other unusable shape is
/// `INVALID_FORMAT`, matching the previous arms.
fn dialable_nodes<E: DialableExtraction>(
    document: &SubscriptionDocument,
    subscription: SubscriptionId,
) -> Result<Vec<DialableNode>, E> {
    parse_document_dialable_lossy(document, subscription)
        .map(|lossy| lossy.nodes)
        .map_err(|error| match error {
            PipelineError::UnsupportedDocument | PipelineError::Clash => E::UNSUPPORTED_DOCUMENT,
            _ => E::INVALID_FORMAT,
        })
}

/// Selects the configured Clash proxy-group name with a safe default.
fn group_name() -> String {
    match std::env::var("CALY_MIHOMO_PROXY_GROUP").as_deref() {
        Ok(value) if !value.trim().is_empty() => value.trim().to_owned(),
        _ => "AUTO".to_owned(),
    }
}

#[cfg(test)]
mod tests;
