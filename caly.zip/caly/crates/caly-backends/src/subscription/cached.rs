//! Bounded raw subscription source cache with generation tracking.

use crate::core::{MihomoNodeRegistry, RegisteredProxy};
use caly_config::subscription::{SubscriptionProjection, uri_body_to_mihomo_proxy_set};
use caly_domain::{SnapshotNodes, SubscriptionId};
use caly_platform::fs::{
    AtomicFileContents, AtomicWritePlan, LinuxAtomicFileBackend, atomic_write,
};
use caly_ports::{ActorFailure, SubscriptionCommandBackend};

use super::hex_id;

/// Bounded raw subscription source cache with generation tracking.
pub struct CachedSubscriptionBackend {
    sources: std::collections::BTreeMap<SubscriptionId, Vec<u8>>,
    generations: std::collections::BTreeMap<SubscriptionId, u64>,
    userinfo:
        std::collections::BTreeMap<SubscriptionId, caly_config::subscription::SubscriptionUserInfo>,
    cache_dir: Option<std::path::PathBuf>,
    filesystem: LinuxAtomicFileBackend,
    node_registry: Option<MihomoNodeRegistry>,
}

impl CachedSubscriptionBackend {
    /// Creates an empty source cache.
    pub fn new() -> Self {
        Self {
            sources: std::collections::BTreeMap::new(),
            generations: std::collections::BTreeMap::new(),
            userinfo: std::collections::BTreeMap::new(),
            cache_dir: None,
            filesystem: LinuxAtomicFileBackend,
            node_registry: None,
        }
    }

    /// Enables a persistent raw-body cache directory.
    #[must_use]
    pub fn with_cache_dir(mut self, cache_dir: std::path::PathBuf) -> Self {
        self.cache_dir = Some(cache_dir);
        self
    }

    /// Returns the configured persistent raw-body cache directory.
    pub fn cache_dir(&self) -> Option<&std::path::Path> {
        self.cache_dir.as_deref()
    }

    /// Re-indexes every subscription body persisted in the cache directory,
    /// restoring the node registry after a daemon restart without re-fetching.
    /// Cached bodies are best-effort: a corrupt or unreadable entry is skipped
    /// with a warning rather than failing the daemon bootstrap. Returns the
    /// restored projection slices so the caller can seed the presentation
    /// snapshot with the same names the registry now serves.
    pub fn restore_from_cache(&mut self) -> Result<Vec<SnapshotNodes>, ActorFailure> {
        let Some(directory) = self.cache_dir.clone() else {
            return Ok(Vec::new());
        };
        let mut restored = Vec::new();
        let entries = match std::fs::read_dir(&directory) {
            Ok(entries) => entries,
            Err(error) if error.kind() == std::io::ErrorKind::NotFound => {
                // Round 31: a fresh install that
                // has not yet cached anything —
                // the canonical "first boot"
                // condition. The pre-Round 31
                // shape logged the same
                // "unreadable" warning on every
                // fresh boot, which is operator
                // noise that hides the real
                // "your state directory is
                // locked" failure when one
                // happens. A missing directory
                // now returns an empty `Ok` so
                // the daemon bootstrap continues
                // normally; the directory is
                // synthesised on the first
                // `put_source` (see
                // [`Self::persist_source`]).
                return Ok(Vec::new());
            }
            Err(error) => {
                return Err(crate::failure(
                    &format!("subscription cache directory is unreadable: {error}"),
                    "inspect state-directory ownership and that the parent is not a symlink to a read-only mount",
                ));
            }
        };
        for entry in entries.flatten() {
            let Ok(name) = entry.file_name().into_string() else {
                continue;
            };
            // These are exact suffix markers for files we generate ourselves
            // (commit-tmp / rollback), not user file extensions, so matching is
            // intentionally case-sensitive to the lowercase literals we write.
            #[allow(clippy::case_sensitive_file_extension_comparisons)]
            if name.ends_with(".tmp") || name.ends_with(".rollback") {
                continue;
            }
            let Ok(id) = name.parse::<SubscriptionId>() else {
                continue;
            };
            match self.refresh_projection(id) {
                Ok(projection) => restored.push(projection.nodes),
                Err(error) => {
                    eprintln!(
                        "caly: cached subscription {id} did not restore: {}; hint: {}",
                        error.message, error.suggested_action
                    );
                }
            }
        }
        Ok(restored)
    }

    /// Shares an automatic NodeId → Mihomo group/node registry.
    #[must_use]
    pub fn with_node_registry(mut self, registry: MihomoNodeRegistry) -> Self {
        self.node_registry = Some(registry);
        self
    }

    /// Installs fetched raw bytes and persists them when a cache directory is configured.
    pub fn put_source(&mut self, id: SubscriptionId, body: Vec<u8>) {
        self.persist_source(id, &body);
        self.sources.insert(id, body);
    }

    /// Records the latest subscription quota metadata (from the fetch header).
    pub fn put_userinfo(
        &mut self,
        id: SubscriptionId,
        userinfo: caly_config::subscription::SubscriptionUserInfo,
    ) {
        self.userinfo.insert(id, userinfo);
    }

    /// Returns the last subscription quota metadata, or all-None.
    pub fn userinfo(&self, id: SubscriptionId) -> caly_config::subscription::SubscriptionUserInfo {
        self.userinfo
            .get(&id)
            .copied()
            .unwrap_or(caly_config::subscription::SubscriptionUserInfo {
                upload_bytes: None,
                download_bytes: None,
                total_bytes: None,
                expire_unix: None,
            })
    }

    fn persist_source(&mut self, id: SubscriptionId, body: &[u8]) {
        let Some(directory) = &self.cache_dir else {
            return;
        };
        let _ = std::fs::create_dir_all(directory);
        let Ok(contents) = AtomicFileContents::try_from_vec(body.to_vec()) else {
            return;
        };
        let destination = directory.join(hex_id(id));
        let temporary = directory.join(format!("{}.tmp", hex_id(id)));
        let _ = atomic_write(
            &mut self.filesystem,
            AtomicWritePlan {
                destination,
                temporary,
                contents,
            },
        );
    }

    /// Returns cached raw bytes for controlled outbound rendering.
    pub fn raw_source(&self, id: SubscriptionId) -> Option<Vec<u8>> {
        self.sources.get(&id).cloned().or_else(|| {
            self.cache_dir
                .as_ref()
                .and_then(|directory| std::fs::read(directory.join(hex_id(id))).ok())
        })
    }

    /// Returns the committed source generation.
    pub fn generation(&self, id: SubscriptionId) -> u64 {
        self.generations.get(&id).copied().unwrap_or(0)
    }

    /// Parses, normalizes, deduplicates, projects and commits one generation.
    pub fn refresh_projection(
        &mut self,
        id: SubscriptionId,
    ) -> Result<SubscriptionProjection, ActorFailure> {
        let body = self.cached_body(id)?;
        let projection = parse_projection(body.clone(), id)?;
        if let Some(registry) = &self.node_registry {
            index_nodes(registry, body, id);
        }
        self.generations
            .insert(id, self.generation(id).saturating_add(1));
        Ok(projection)
    }

    fn cached_body(&self, id: SubscriptionId) -> Result<Vec<u8>, ActorFailure> {
        self.sources
            .get(&id)
            .cloned()
            .or_else(|| {
                self.cache_dir
                    .as_ref()
                    .and_then(|directory| std::fs::read(directory.join(hex_id(id))).ok())
            })
            .ok_or_else(|| {
                crate::failure(
                    "subscription source is not cached",
                    "fetch the subscription before refresh",
                )
            })
    }
}

fn parse_projection(
    body: Vec<u8>,
    id: SubscriptionId,
) -> Result<SubscriptionProjection, ActorFailure> {
    super::parse_uri_body_to_display_lossy(body, id).map_err(|error| {
        crate::failure(
            &format!("subscription pipeline failed: {error}"),
            "inspect source format and URI diagnostics",
        )
    })
}

fn index_nodes(registry: &MihomoNodeRegistry, body: Vec<u8>, id: SubscriptionId) {
    // Rendering is best-effort; a mixed or unsupported subscription leaves the
    // registry unchanged rather than failing the whole refresh.
    let Ok(set) = uri_body_to_mihomo_proxy_set(body.clone(), id) else {
        return;
    };
    // sing-box outbound JSON for the same body, keyed by canonical NodeId, so
    // the sing-box config backend renders from the registry without re-parsing.
    let singbox =
        caly_config::subscription::uri_body_to_sing_box_outbound_map(&body, id).unwrap_or_default();
    if let Ok(mut mapping) = registry.lock() {
        // A refresh replaces the previous generation of this subscription:
        // drop stale entries (an older cached body or a changed source that
        // produced different NodeIds) before indexing the new document, so
        // duplicate proxy names can never accumulate across generations.
        mapping.retain(|_, entry| entry.subscription != id);
        for entry in set.entries() {
            mapping.insert(
                entry.id,
                RegisteredProxy {
                    group: set.group().to_owned(),
                    name: entry.tag.as_str().to_owned(),
                    yaml: entry.yaml.as_str().to_owned(),
                    singbox: singbox.get(&entry.id).cloned(),
                    subscription: id,
                },
            );
        }
    }
}

impl Default for CachedSubscriptionBackend {
    fn default() -> Self {
        Self::new()
    }
}

impl SubscriptionCommandBackend for CachedSubscriptionBackend {
    fn refresh(&mut self, subscription: SubscriptionId) -> Result<SnapshotNodes, ActorFailure> {
        self.refresh_projection(subscription)
            .map(|projection| projection.nodes)
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::collections::BTreeMap;
    use std::sync::{Arc, Mutex};

    /// A minimal dialable body with one vless node; the port distinguishes
    /// node identity (NodeId hashes the dialable target, not the name).
    fn one_node(name: &str, port: u16) -> Vec<u8> {
        format!(
            "vless://a5ea9247-79f3-4655-aece-3fb51e1e669e@example.com:{port}?security=tls#{name}\n"
        )
        .into_bytes()
    }

    fn names(registry: &MihomoNodeRegistry) -> Vec<String> {
        let mut names: Vec<String> = registry
            .lock()
            .map(|mapping| mapping.values().map(|entry| entry.name.clone()).collect())
            .unwrap_or_default();
        names.sort();
        names
    }

    #[test]
    fn refresh_replaces_previous_generation_of_same_subscription() {
        let registry: MihomoNodeRegistry = Arc::new(Mutex::new(BTreeMap::new()));
        let id = SubscriptionId::from_bytes([7; 16]);
        index_nodes(&registry, one_node("node-a", 8443), id);
        assert_eq!(names(&registry), vec!["node-a"]);
        // Same subscription refreshed with a changed body: the old identity
        // must disappear instead of accumulating a duplicate proxy name.
        index_nodes(&registry, one_node("node-b", 8444), id);
        assert_eq!(names(&registry), vec!["node-b"]);
    }

    #[test]
    fn distinct_subscriptions_coexist() {
        let registry: MihomoNodeRegistry = Arc::new(Mutex::new(BTreeMap::new()));
        let first = SubscriptionId::from_bytes([8; 16]);
        let second = SubscriptionId::from_bytes([9; 16]);
        index_nodes(&registry, one_node("node-a", 8443), first);
        index_nodes(&registry, one_node("node-b", 8444), second);
        assert_eq!(names(&registry), vec!["node-a", "node-b"]);
    }
}
