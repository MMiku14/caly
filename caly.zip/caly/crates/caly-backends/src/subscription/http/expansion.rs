//! URL-list subscription expansion: a plain-text body whose lines are
//! subscription URLs is fetched child-by-child (same SSRF-safe path) and
//! merged before node parsing. Nested URL lists are expanded recursively with
//! a small depth/work budget and cycle detection.

use std::collections::BTreeSet;

use caly_domain::SubscriptionId;
use caly_ports::ActorFailure;
use caly_subscription::{FetchResult, FetchValidators, decode_url_list};

use super::{
    FETCH_ATTEMPTS, FETCH_RETRY_MILLIS, HttpSubscriptionBackend, request_body, resolve_addresses,
    subscription_id_for_url,
};

/// Maximum child subscriptions expanded from one URL-list document.
const MAX_URL_LIST_CHILDREN: usize = 32;
/// Maximum URL-list levels nested beneath the top-level URL list. The
/// top list itself is level zero, so a chain may have at most four deeper
/// list documents (five list documents in total).
const MAX_NESTED_URL_LIST_LEVELS: usize = 4;
/// Total URL-list children expanded during one refresh. Depth and the
/// per-document child cap already bound the shape; this bound keeps a deep
/// chain's total request count visibly small for operators.
const MAX_URL_LIST_TOTAL_CHILDREN: usize = 128;

impl HttpSubscriptionBackend {
    /// Expands a plain-text URL-list subscription: fetches each child
    /// subscription through the same SSRF-safe path and merges the bodies so
    /// downstream parsing sees one URI-line/base64/Clash document. A child
    /// that is itself a URL list is flattened recursively before merging.
    /// Returns whether any child delivered updated content (a fresh child
    /// means the node set may have moved even when the parent answered 304).
    pub(super) fn expand_url_list(
        &mut self,
        id: SubscriptionId,
        touched: &mut BTreeSet<SubscriptionId>,
    ) -> Result<bool, ActorFailure> {
        let Some(body) = self.cache.raw_source(id) else {
            return Ok(false);
        };
        // Not a URL list (or undecodable): leave the body untouched so the
        // regular parse path reports it.
        let Some(lines) = decode_url_list(&body) else {
            return Ok(false);
        };
        if lines.len() > MAX_URL_LIST_CHILDREN {
            return Err(crate::failure(
                "URL-list subscription has too many entries",
                "reduce the list to at most 32 URLs",
            ));
        }
        // The top-level id is part of every cycle: a child pointing back at
        // its parent is a configuration error, not a reason to re-fetch the
        // same body forever.
        let mut visiting = BTreeSet::from([id]);
        let mut total_children = 0_usize;
        let mut merged: Vec<u8> = Vec::new();
        let mut changed = false;
        for line in &lines {
            let child_id = subscription_id_for_url(line.as_str());
            if visiting.contains(&child_id) {
                return Err(crate::failure(
                    "URL-list subscription cycle detected",
                    "remove the self-referential URL list entry",
                ));
            }
            touched.insert(child_id);
            let (child, child_changed) = self.fetch_child(line.as_str(), touched)?;
            let (flattened, nested_changed, nested_children) = self.flatten_url_list_body(
                child_id,
                child,
                0,
                &mut visiting,
                &mut total_children,
                touched,
            )?;
            changed |= child_changed || nested_changed;
            total_children = total_children.saturating_add(nested_children.saturating_add(1));
            append_merged(&mut merged, &flattened)?;
        }
        self.cache.put_source(id, merged);
        Ok(changed)
    }

    /// Flattens one fetched child body. URL-list bodies are expanded
    /// recursively; every other document shape is returned verbatim.
    /// Returns `(body, changed, child_count)` where `changed` covers fresh
    /// bodies found at this level and below, and `child_count` counts direct
    /// children consumed by this list (not the top-level child itself).
    fn flatten_url_list_body(
        &mut self,
        id: SubscriptionId,
        body: Vec<u8>,
        depth: usize,
        visiting: &mut BTreeSet<SubscriptionId>,
        total_children: &mut usize,
        touched: &mut BTreeSet<SubscriptionId>,
    ) -> Result<(Vec<u8>, bool, usize), ActorFailure> {
        if depth >= MAX_NESTED_URL_LIST_LEVELS {
            return Err(crate::failure(
                "URL-list subscription nesting is too deep",
                "flatten the subscription to at most 4 nested levels below the top URL list",
            ));
        }
        let Some(lines) = decode_url_list(&body) else {
            return Ok((body, false, 0));
        };
        if !visiting.insert(id) {
            return Err(crate::failure(
                "URL-list subscription cycle detected",
                "remove the self-referential URL list entry",
            ));
        }
        if lines.len() > MAX_URL_LIST_CHILDREN {
            return Err(crate::failure(
                "URL-list subscription has too many entries",
                "reduce the list to at most 32 URLs",
            ));
        }
        let mut merged: Vec<u8> = Vec::new();
        let mut changed = false;
        let mut children = 0_usize;
        for line in &lines {
            *total_children = total_children.saturating_add(1);
            if *total_children > MAX_URL_LIST_TOTAL_CHILDREN {
                return Err(crate::failure(
                    "URL-list subscription expands to too many children",
                    "reduce the list to at most 128 total URLs",
                ));
            }
            let child_id = subscription_id_for_url(line.as_str());
            if visiting.contains(&child_id) {
                return Err(crate::failure(
                    "URL-list subscription cycle detected",
                    "remove the self-referential URL list entry",
                ));
            }
            touched.insert(child_id);
            let (child, child_changed) = self.fetch_child(line.as_str(), touched)?;
            let (flattened, nested_changed, nested_children) = self.flatten_url_list_body(
                child_id,
                child,
                depth + 1,
                visiting,
                total_children,
                touched,
            )?;
            changed |= child_changed || nested_changed;
            children += 1;
            children += nested_children;
            append_merged(&mut merged, &flattened)?;
        }
        visiting.remove(&id);
        Ok((merged, changed, children))
    }

    /// Fetches one child subscription body with the shared retry policy.
    ///
    /// Children get the same conditional-request treatment as top-level
    /// sources, keyed by the derived `SubscriptionId` of their URL. Their
    /// bodies are cached **memory-only** (never persisted), so a daemon
    /// restart cannot mistake a merged child for a top-level subscription.
    /// A `304 NotModified` therefore reuses the previously cached child body
    /// instead of merging an empty document. The `bool` is the
    /// "content updated" flag (false for 304).
    fn fetch_child(
        &mut self,
        source: &str,
        touched: &mut BTreeSet<SubscriptionId>,
    ) -> Result<(Vec<u8>, bool), ActorFailure> {
        let child_id = subscription_id_for_url(source);
        touched.insert(child_id);
        let addresses = resolve_addresses(source)?;
        let mut last = crate::failure("child subscription fetch failed", "retry the refresh");
        for index in 0..FETCH_ATTEMPTS {
            let validators = self.cache.validators(child_id);
            match request_body(&self.handle, self.policy, source, &addresses, &validators) {
                Ok(FetchResult::Updated {
                    body,
                    etag,
                    last_modified,
                    ..
                }) => {
                    let body = body.into_vec();
                    self.cache.put_source_memory(child_id, body.clone());
                    self.cache.put_validators(
                        child_id,
                        FetchValidators {
                            etag,
                            last_modified,
                        },
                    );
                    return Ok((body, true));
                }
                Ok(FetchResult::NotModified) => {
                    // Reuse the previously cached child body; sending
                    // validators without a cached body cannot happen (the
                    // validators only exist after an Updated response), but
                    // a missing entry degrades to an empty merge input rather
                    // than fabricating content.
                    return Ok((self.cache.raw_source(child_id).unwrap_or_default(), false));
                }
                Err((transient, error)) => {
                    last = error;
                    if !transient || index + 1 >= FETCH_ATTEMPTS {
                        return Err(last);
                    }
                    std::thread::sleep(std::time::Duration::from_millis(FETCH_RETRY_MILLIS));
                }
            }
        }
        Err(last)
    }
}

/// Appends one flattened child to the merged document, enforcing the
/// subscription body ceiling incrementally while the merge is still cheap to
/// stop (the pre-fix path built a ~1 GiB merge before rejecting).
fn append_merged(merged: &mut Vec<u8>, child: &[u8]) -> Result<(), ActorFailure> {
    let projected = merged.len().saturating_add(child.len()).saturating_add(1);
    if projected > caly_subscription::MAX_SUBSCRIPTION_BODY_BYTES {
        return Err(crate::failure(
            "merged URL-list subscription exceeds the subscription body ceiling",
            "reduce the number or size of the listed subscriptions",
        ));
    }
    merged.extend_from_slice(child);
    merged.push(b'\n');
    Ok(())
}
