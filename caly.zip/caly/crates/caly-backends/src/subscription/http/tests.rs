//! Tests for `subscription/http.rs`, extracted to the sibling
//! convention file (audit #70 file-length budget).

use super::*;

fn transient() -> ActorFailure {
    crate::failure("subscription fetch failed: RequestFailed", "retry")
}

#[test]
fn transient_failure_is_retried_then_succeeds() {
    let mut calls = 0;
    let result = retry_fetch(3, || {
        calls += 1;
        if calls < 2 {
            Err((true, transient()))
        } else {
            Ok(true)
        }
    });
    assert!(result.is_ok());
    assert_eq!(calls, 2, "second attempt should succeed");
}

#[test]
fn persistent_transient_failure_surfaces_after_exhausting_attempts() {
    let mut calls = 0;
    let result: Result<bool, ActorFailure> = retry_fetch(3, || {
        calls += 1;
        Err((true, transient()))
    });
    assert!(result.is_err());
    assert_eq!(calls, 3, "all attempts exhausted");
}

#[test]
fn nontransient_failure_returns_immediately() {
    let mut calls = 0;
    let result: Result<bool, ActorFailure> = retry_fetch(3, || {
        calls += 1;
        Err((false, transient()))
    });
    assert!(result.is_err());
    assert_eq!(calls, 1, "non-transient failure must not retry");
}

#[test]
fn transient_classification_matches_fetch_errors() {
    use caly_subscription::FetchError;
    assert!(is_transient_fetch(&FetchError::RequestFailed(
        "connect error".to_owned()
    )));
    assert!(is_transient_fetch(&FetchError::ClientBuild));
    assert!(is_transient_fetch(&FetchError::UnexpectedStatus(503)));
    assert!(!is_transient_fetch(&FetchError::UnexpectedStatus(404)));
    assert!(!is_transient_fetch(&FetchError::UnsupportedScheme));
    assert!(!is_transient_fetch(&FetchError::BodyTooLarge));
}

#[test]
fn subscription_id_for_url_is_stable_and_distinct() {
    // Same URL always maps to the same id (stable cache key across restarts),
    // and different URLs map to different ids (per-source merge/dedup).
    let a1 = subscription_id_for_url("https://provider.example/sub");
    let a2 = subscription_id_for_url("https://provider.example/sub");
    let b = subscription_id_for_url("https://second.example/sub?token=xyz");
    assert_eq!(a1, a2, "same URL must yield the same SubscriptionId");
    assert_ne!(a1, b, "different URLs must yield distinct SubscriptionIds");
    // Id is a full 16-byte value, not a zero-padded truncation.
    assert_ne!(a1.into_bytes(), [0_u8; 16]);
    // #113: the id is derived from the CANONICAL form (WHATWG parse +
    // re-serialize), so cosmetic differences — trailing whitespace, scheme
    // case, a default port — fold into one id instead of splitting one
    // source into duplicate cache entries.
    let c1 = subscription_id_for_url("https://p.example/x");
    let c2 = subscription_id_for_url("https://p.example/x ");
    assert_eq!(c1, c2, "canonical-equal URLs must share one SubscriptionId");
    let c3 = subscription_id_for_url("HTTPS://p.example:443/x");
    assert_eq!(c1, c3, "scheme case / default port must normalize away");
    // Genuinely different URLs still differ.
    let c4 = subscription_id_for_url("https://p.example/y");
    assert_ne!(c1, c4, "distinct paths must yield distinct SubscriptionIds");
}

// ---------------------------------------------------------------- W2-β2b --
// Scheduled-refresh due rulings (Q5 cadence consumption).

#[test]
fn scheduled_due_rules_follow_the_q5_cadence() {
    let now = std::time::Instant::now();
    // Static pin: never due.
    assert!(!due_for_scheduled_refresh(Some(0), None, now));
    assert!(!due_for_scheduled_refresh(Some(0), Some(&now), now));
    // No per-source cadence: inherits the batch tick — always due.
    assert!(due_for_scheduled_refresh(None, Some(&now), now));
    // Explicit cadence: due when never fetched, or after the period.
    assert!(due_for_scheduled_refresh(Some(60), None, now));
    let recent = now
        .checked_sub(std::time::Duration::from_secs(30 * 60))
        .unwrap();
    assert!(!due_for_scheduled_refresh(Some(60), Some(&recent), now));
    let stale = now
        .checked_sub(std::time::Duration::from_secs(61 * 60))
        .unwrap();
    assert!(due_for_scheduled_refresh(Some(60), Some(&stale), now));
}

// ------------------------------------------------- parallel refresh wave --
// The refresh fan-out (`fetch_waves`) must run items concurrently on scoped
// threads, yet never exceed the configured wave width, and keep outcome
// order aligned with item order.

#[test]
fn fetch_waves_runs_items_on_parallel_scoped_threads() {
    use std::collections::HashSet;
    use std::sync::Mutex;
    let seen: Mutex<HashSet<std::thread::ThreadId>> = Mutex::new(HashSet::new());
    let items = vec![1_u8, 2, 3];
    let outcomes = fetch_waves(&items, 8, &|_: &u8| {
        seen.lock().unwrap().insert(std::thread::current().id());
        Ok(FetchResult::NotModified)
    });
    assert_eq!(outcomes.len(), 3, "one outcome per item, in item order");
    assert!(outcomes.iter().all(Result::is_ok));
    assert_eq!(
        seen.into_inner().unwrap().len(),
        3,
        "every item must run on its own scoped thread (parallel, not serial)"
    );
}

#[test]
fn fetch_waves_bounds_in_flight_fetches_to_the_wave_width() {
    use std::sync::Arc;
    use std::sync::atomic::{AtomicUsize, Ordering};
    let in_flight = Arc::new(AtomicUsize::new(0));
    let peak = Arc::new(AtomicUsize::new(0));
    let items = vec![1_u8, 2, 3, 4, 5, 6];
    let outcomes = fetch_waves(&items, 2, &|_: &u8| {
        let current = in_flight.fetch_add(1, Ordering::SeqCst) + 1;
        let mut observed = peak.load(Ordering::SeqCst);
        while current > observed {
            match peak.compare_exchange(observed, current, Ordering::SeqCst, Ordering::SeqCst) {
                Ok(_) => break,
                Err(latest) => observed = latest,
            }
        }
        std::thread::sleep(std::time::Duration::from_millis(40));
        in_flight.fetch_sub(1, Ordering::SeqCst);
        Ok(FetchResult::NotModified)
    });
    assert!(outcomes.iter().all(Result::is_ok));
    assert_eq!(
        peak.load(Ordering::SeqCst),
        2,
        "wave width must cap the number of concurrent fetches"
    );
    assert_eq!(
        in_flight.load(Ordering::SeqCst),
        0,
        "every fetch must return before fetch_waves completes"
    );
}

/// Builds a backend inside a scratch runtime (construction needs a
/// Tokio handle; the fold itself is synchronous) plus a scratch
/// state dir holding `inline-proxies/`.
fn fold_fixture(case: &str) -> (HttpSubscriptionBackend, std::path::PathBuf) {
    let runtime = tokio::runtime::Builder::new_current_thread()
        .enable_all()
        .build()
        .expect("scratch runtime");
    let _guard = runtime.enter();
    let backend = HttpSubscriptionBackend::new().expect("backend");
    let dir = std::env::temp_dir().join(format!("caly-fold-test-{}-{case}", std::process::id()));
    let _ = std::fs::remove_dir_all(&dir);
    std::fs::create_dir_all(dir.join("inline-proxies")).expect("inline dir");
    // The fold never touches the runtime handle, so dropping the
    // scratch runtime after construction is safe.
    drop(runtime);
    (backend, dir)
}

/// Proven-parseable single-node body (same shape as the pipeline's
/// own `ss://` fixture).
const FOLD_SS_URI: &str = "ss://YWVzLTI1Ni1nY206cGFzc3dvcmQ@203.0.113.9:8388#fold-node";

#[test]
fn inline_fold_empty_state_is_quiet_noop() {
    let (mut backend, dir) = fold_fixture("empty");
    let (nodes, changed, active, error) = backend.refresh_inline_source(&dir);
    assert!(nodes.is_empty());
    assert!(!changed);
    assert!(!active);
    assert!(error.is_none());
    let _ = std::fs::remove_dir_all(&dir);
}

#[test]
fn inline_fold_adds_then_clears_nodes() {
    let (mut backend, dir) = fold_fixture("add-clear");
    let inline = dir.join("inline-proxies");
    std::fs::write(
        inline.join("a.json"),
        format!(r#"{{"uri":"{FOLD_SS_URI}","added_at_ms":1}}"#),
    )
    .expect("write entry");
    let (nodes, changed, active, error) = backend.refresh_inline_source(&dir);
    assert_eq!(nodes.len(), 1, "one folded node");
    assert!(changed);
    assert!(active);
    assert!(error.is_none());

    std::fs::remove_file(inline.join("a.json")).expect("remove entry");
    let (nodes, changed, active, error) = backend.refresh_inline_source(&dir);
    assert!(nodes.is_empty());
    assert!(changed, "removing the last entry moves the generation");
    assert!(!active, "empty body is not declared, so retain releases it");
    assert!(error.is_none());

    // Production `refresh()` runs `retain_declared` after the fold with
    // the inactive id absent from both sets, releasing the record.
    assert!(
        backend.cache.retain_declared(
            &std::collections::BTreeSet::new(),
            &std::collections::BTreeSet::new(),
        ),
        "releasing the stale inline record reports true"
    );
    let (_, changed, active, _) = backend.refresh_inline_source(&dir);
    assert!(!changed, "steady empty is quiet");
    assert!(!active);
    let _ = std::fs::remove_dir_all(&dir);
}

#[test]
fn inline_fold_undecodable_body_warns_and_keeps_last_good() {
    let (mut backend, dir) = fold_fixture("undecodable");
    let inline = dir.join("inline-proxies");
    std::fs::write(
        inline.join("a.json"),
        format!(r#"{{"uri":"{FOLD_SS_URI}","added_at_ms":1}}"#),
    )
    .expect("write entry");
    let (nodes, _, _, _) = backend.refresh_inline_source(&dir);
    assert_eq!(nodes.len(), 1);

    std::fs::write(inline.join("a.json"), r#"{"uri":"http://foo"}"#).expect("corrupt entry");
    let before = backend.cache.generation(INLINE_SUBSCRIPTION_ID);
    let (nodes, changed, active, error) = backend.refresh_inline_source(&dir);
    assert!(nodes.is_empty());
    assert!(!changed, "failed fold keeps the generation");
    assert!(active, "last good stays declared, mirroring the fetch path");
    assert!(error.is_some());
    assert_eq!(backend.cache.generation(INLINE_SUBSCRIPTION_ID), before);
    let _ = std::fs::remove_dir_all(&dir);
}

/// Bug ⑧: a targeted refresh must carry the other declared sources'
/// cached nodes in its outcome — otherwise `NodesReplaced` narrows
/// the live table (and the reconciler's re-render) to the target.
#[test]
fn kept_merge_returns_declared_non_targets() {
    let (mut backend, dir) = fold_fixture("kept");
    let target = SubscriptionId::from_bytes([21; 16]);
    let kept = SubscriptionId::from_bytes([22; 16]);
    backend.cache.put_source(
        target,
        "vless://a5ea9247-79f3-4655-aece-3fb51e1e669e@example.com:8443?security=tls#node-target\n".as_bytes().to_vec(),
    );
    backend.cache.put_source(
        kept,
        "vless://a5ea9247-79f3-4655-aece-3fb51e1e669e@example.com:9443?security=tls#node-kept\n".as_bytes().to_vec(),
    );
    backend.cache.refresh_projection(target).expect("target projects");
    backend.cache.refresh_projection(kept).expect("kept projects");
    let declared: std::collections::BTreeSet<SubscriptionId> =
        [target, kept].into_iter().collect();
    let source = ResolvedSource {
        id: target,
        url: "https://example.com/sub".to_owned(),
        every_minutes: None,
    };
    let merged = backend.merge_kept_projections(&declared, &[&source]);
    assert_eq!(merged.len(), 1);
    assert_eq!(merged[0].name().as_str(), "node-kept");
    let _ = std::fs::remove_dir_all(&dir);
}

/// Bug ⑧ (inline half): the targeted arm re-projects the cached
/// inline generation instead of re-reading state — a folded entry
/// must be re-projectable, and declaring it must survive retain.
#[test]
fn targeted_arm_keeps_cached_inline_generation() {
    let (mut backend, dir) = fold_fixture("inline-keep");
    let inline = dir.join("inline-proxies");
    std::fs::write(
        inline.join("a.json"),
        format!(r#"{{"uri":"{FOLD_SS_URI}","added_at_ms":1}}"#),
    )
    .expect("write entry");
    let (nodes, _, active, _) = backend.refresh_inline_source(&dir);
    assert_eq!(nodes.len(), 1);
    assert!(active);
    // What the targeted arm does: re-project from cache, declare, retain.
    let cached = backend
        .cache
        .refresh_projection(INLINE_SUBSCRIPTION_ID)
        .expect("cached inline re-projects");
    assert_eq!(cached.nodes.len(), 1);
    let declared: std::collections::BTreeSet<SubscriptionId> =
        [INLINE_SUBSCRIPTION_ID].into_iter().collect();
    assert!(
        !backend.cache.retain_declared(&declared, &declared),
        "steady-state retain reports false"
    );
    let still = backend
        .cache
        .refresh_projection(INLINE_SUBSCRIPTION_ID)
        .expect("declared inline survives retain");
    assert_eq!(still.nodes.len(), 1);
    let _ = std::fs::remove_dir_all(&dir);
}
