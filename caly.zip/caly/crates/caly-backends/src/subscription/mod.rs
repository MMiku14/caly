//! HTTP and cached subscription backends.

mod cached;
mod http;
pub mod render_compose;

pub use cached::CachedSubscriptionBackend;
pub use http::{HttpSubscriptionBackend, subscription_id_for_url};

pub(crate) use caly_subscription::PublicAddressClassifier;
pub(crate) use caly_subscription::parse_uri_body_to_display_lossy;

use caly_domain::SubscriptionId;

fn hex_id(id: SubscriptionId) -> String {
    caly_domain::to_hex(id.into_bytes())
}
