//! HTTP and cached subscription backends.

mod cached;
mod http;

pub use cached::CachedSubscriptionBackend;
pub use http::HttpSubscriptionBackend;

pub(crate) use caly_config::subscription::PublicAddressClassifier;
pub(crate) use caly_config::subscription::parse_uri_body_to_display_lossy;

use caly_domain::SubscriptionId;

fn hex_id(id: SubscriptionId) -> String {
    caly_domain::to_hex(id.into_bytes())
}
