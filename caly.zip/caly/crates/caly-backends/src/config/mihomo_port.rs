//! `ConfigActorPort` transaction for the Mihomo backend.
//!
//! Split out of `backends/config/mod.rs` (audit #70 file-length
//! budget): prepare (render + real-binary validation staging),
//! commit (atomic publish + generation trim) and rollback for one
//! Mihomo destination file.

use caly_platform::fs::{AtomicFileContents, AtomicWritePlan, atomic_write};
use caly_ports::{ActorFailure, CommittedConfig, ConfigActorPort, ConfigCandidate, PreparedConfig};
use std::path::PathBuf;

use super::MihomoConfigBackend;
use super::failure;
use super::mihomo_backend::clean_stale_validation_files;
use super::{MAX_CONFIG_HISTORY, resolve_tun_from_config};

impl ConfigActorPort for MihomoConfigBackend {
    fn parse_and_render(
        &mut self,
        candidate: ConfigCandidate,
    ) -> Result<PreparedConfig, ActorFailure> {
        // Re-read the TUN tuning per apply (like the subscription URL re-reads
        // on refresh): a `tun.enabled` edit takes effect without a restart.
        self.tun = resolve_tun_from_config();
        let settings = self.build_settings()?;
        let contents = self.renderer.render(&settings).map_err(|error| {
            failure(
                &format!("Mihomo config render failed: {error}"),
                "inspect config generation",
            )
        })?;
        let generation = self.generation.saturating_add(1);
        // Validate against the real binary before the candidate is considered
        // prepared, so a rejected config can never reach commit.
        if let Some(binary) = self.binary.clone() {
            clean_stale_validation_files(&self.workdir);
            let validation_path = self
                .workdir
                .join(format!("config.validate.{generation}.yaml"));
            let write = AtomicWritePlan {
                destination: validation_path.clone(),
                temporary: self
                    .workdir
                    .join(format!("config.validate.{generation}.tmp")),
                contents: contents.clone(),
            };
            atomic_write(&mut self.filesystem, write).map_err(|error| {
                failure(
                    &format!("Mihomo validation staging failed: {error}"),
                    "inspect working-directory ownership",
                )
            })?;
            let report = self.validate_config(
                binary,
                self.workdir.clone(),
                validation_path.clone(),
                generation,
            )?;
            let _ = std::fs::remove_file(&validation_path);
            let _ = std::fs::remove_file(
                self.workdir
                    .join(format!("config.validate.{generation}.tmp")),
            );
            if !report.accepted {
                // Surface the kernel's own rejection reason instead of a generic
                // "rejected" summary; the diagnostic is the stderr from the
                // validation executable and directly points at the bad field.
                let detail = report
                    .diagnostic
                    .as_ref()
                    .map(|d| d.as_str().trim())
                    .filter(|d| !d.is_empty())
                    .map(|d| format!(": {d}"))
                    .unwrap_or_default();
                return Err(failure(
                    &format!("generated config was rejected by the Mihomo binary{detail}"),
                    "inspect the validation diagnostic above or the base settings",
                ));
            }
        }
        self.prepared.insert(candidate.id, (generation, contents));
        Ok(PreparedConfig {
            candidate_id: candidate.id,
            generation,
        })
    }

    fn discard_prepared(&mut self, prepared: PreparedConfig) -> Result<(), ActorFailure> {
        self.prepared.remove(&prepared.candidate_id);
        Ok(())
    }

    fn commit_candidate(
        &mut self,
        prepared: PreparedConfig,
    ) -> Result<CommittedConfig, ActorFailure> {
        let (_, contents) = self
            .prepared
            .remove(&prepared.candidate_id)
            .ok_or_else(|| failure("prepared config is missing", "re-render the candidate"))?;
        // Ensure the owner-only destination directory exists before atomic publish.
        if let Some(parent) = self.destination.parent() {
            std::fs::create_dir_all(parent).map_err(|error| {
                failure(
                    &format!("cannot create config directory: {error}"),
                    "inspect config filesystem ownership",
                )
            })?;
            #[cfg(unix)]
            {
                use std::os::unix::fs::PermissionsExt;
                let _ = std::fs::set_permissions(parent, std::fs::Permissions::from_mode(0o700));
            }
        }
        let mut bytes = contents.into_vec();
        bytes.extend_from_slice(format!("# caly-generation: {}\n", prepared.generation).as_bytes());
        let contents = AtomicFileContents::try_from_vec(bytes).map_err(|_| {
            failure(
                "Mihomo generation is too large",
                "reduce generated configuration",
            )
        })?;
        let temporary = PathBuf::from(format!(
            "{}.tmp.{}",
            self.destination.display(),
            prepared.generation
        ));
        atomic_write(
            &mut self.filesystem,
            AtomicWritePlan {
                destination: self.destination.clone(),
                temporary,
                contents: contents.clone(),
            },
        )
        .map_err(|error| {
            failure(
                &format!("Mihomo config publish failed: {error}"),
                "inspect config filesystem ownership",
            )
        })?;
        self.history.insert(prepared.generation, contents);
        while self.history.len() > MAX_CONFIG_HISTORY {
            if let Some(oldest) = self.history.keys().next().copied() {
                self.history.remove(&oldest);
            }
        }
        self.generation = prepared.generation;
        Ok(CommittedConfig {
            candidate_id: prepared.candidate_id,
            generation: prepared.generation,
        })
    }

    fn rollback_commit(&mut self, committed: CommittedConfig) -> Result<(), ActorFailure> {
        if self.generation != committed.generation {
            return Ok(());
        }
        let previous = self
            .history
            .range(..committed.generation)
            .next_back()
            .map(|(generation, contents)| (*generation, contents.clone()));
        if let Some((generation, contents)) = previous {
            let temporary = PathBuf::from(format!(
                "{}.rollback.{}",
                self.destination.display(),
                generation
            ));
            atomic_write(
                &mut self.filesystem,
                AtomicWritePlan {
                    destination: self.destination.clone(),
                    temporary,
                    contents,
                },
            )
            .map_err(|error| {
                failure(
                    &format!("config rollback failed: {error}"),
                    "inspect generation filesystem ownership",
                )
            })?;
            self.generation = generation;
        }
        Ok(())
    }
}
