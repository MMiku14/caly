//! Core command backend: proxy selection and connection close, unified by the
//! active core. Mirrors the `CoreLifecycleBackend` dispatch so every command
//! hits the kernel controller that is actually running.

use caly_corectl::{mihomo::MihomoHttpControl, sing_box::SingBoxHttpControl};
use caly_domain::{
    AppliedState, CoreKind, CoreRunState, NodeId, ObservedState, ProxyMode, SubscriptionId,
};
use caly_ports::{ActorFailure, CoreCommandBackend};
use std::{
    collections::BTreeMap,
    sync::{Arc, Mutex},
    time::Duration,
};

/// Controller request budget for core commands.
const CONTROL_TIMEOUT: Duration = Duration::from_secs(5);

/// A subscription node indexed for both core selection and config rendering.
#[derive(Clone, Debug)]
pub struct RegisteredProxy {
    /// Clash proxy-group core-selection calls address for this node. With
    /// subscription-owned routing the node "lands" in the author's first
    /// containing `select` group (else any containing group, else the
    /// implicit fallback name); without subscription groups it is the
    /// implicit fallback group derived from the subscription body.
    pub landing_group: String,
    /// Clash proxy tag used by core selection and config rendering.
    pub name: String,
    /// Rendered `- name: ...` Mihomo YAML block (bounded upstream).
    pub yaml: String,
    /// sing-box outbound JSON object (tag `proxy-<id>`), when representable.
    /// Stored alongside the Mihomo YAML so both config backends render from
    /// the same registry without re-parsing the subscription body.
    pub singbox: Option<String>,
    /// Subscription the node came from, so a refresh replaces (not merges
    /// into) the previous generation of that subscription. Without this, a
    /// cached older body and a newer fetch with changed identities would
    /// accumulate duplicate proxy names and Mihomo would reject the render.
    pub subscription: SubscriptionId,
}

/// A source document's full routing surface (2026-08-09 规划:
/// "subscriptions own the routing"). When a subscription declares
/// `proxy-groups`, they are indexed here alongside the per-node registry and
/// rendered into the kernel verbatim; the implicit `url-test` fallback group
/// is then omitted, and the subscription's rule table follows the schema's
/// own `rules:` in render order. Indexed per subscription so a refresh
/// replaces (not merges into) the previous routing generation.
#[derive(Clone, Debug, Default)]
pub struct SubscriptionRouting {
    pub groups: Vec<caly_domain::ProxyGroup>,
    pub rules: Vec<caly_domain::RoutingRule>,
}

/// Shared subscription-author routing registry (`None`-equivalent when empty
/// for a given `SubscriptionId`).
pub type CoreRoutingRegistry = Arc<Mutex<BTreeMap<SubscriptionId, SubscriptionRouting>>>;

/// Builds the shared routing registry, mirroring the inline construction of
/// the per-node [`CoreNodeRegistry`].
#[must_use]
pub fn shared_routing_registry() -> CoreRoutingRegistry {
    Arc::new(Mutex::new(BTreeMap::new()))
}

/// Merges every subscription's declared routing into one render input.
/// Groups key by name with first-subscription-wins (a duplicate name would
/// make the kernel reject the document, so the loser is dropped loudly);
/// rules concatenate in `SubscriptionId` order. `None` when no subscription
/// declares any group — the caller then renders the implicit fallback.
#[must_use]
pub fn merged_subscription_routing(
    store: &CoreRoutingRegistry,
) -> Option<(Vec<caly_domain::ProxyGroup>, Vec<caly_domain::RoutingRule>)> {
    let stored = store.lock().ok()?;
    let mut groups = Vec::new();
    let mut seen = std::collections::HashSet::new();
    let mut rules = Vec::new();
    for (id, routing) in stored.iter() {
        for group in &routing.groups {
            if seen.insert(group.name.as_str().to_owned()) {
                groups.push(group.clone());
            } else {
                tracing::warn!(
                    subscription = %id,
                    group = group.name.as_str(),
                    "duplicate subscription proxy-group name dropped (first source wins)"
                );
            }
        }
        rules.extend(routing.rules.iter().cloned());
    }
    if groups.is_empty() {
        return None;
    }
    Some((groups, rules))
}

/// Shared subscription-to-core proxy registry.
///
/// Ordered by canonical node identity (`NodeId: Ord`) so config rendering and
/// enumeration are deterministic across runs — a `HashMap` made the rendered
/// proxy order random per process.
pub type CoreNodeRegistry = Arc<Mutex<BTreeMap<NodeId, RegisteredProxy>>>;

/// Back-compat alias used by the subscription backend.
pub type MihomoNodeRegistry = CoreNodeRegistry;

/// Active-core command dispatch.
pub enum CoreBackend {
    /// Mihomo controller adapter.
    Mihomo(MihomoCoreBackend),
    /// sing-box controller adapter.
    SingBox(SingBoxCoreBackend),
}

impl CoreCommandBackend for CoreBackend {
    fn select_proxy(&mut self, node: NodeId) -> Result<AppliedState, ActorFailure> {
        match self {
            Self::Mihomo(backend) => backend.select_proxy(node),
            Self::SingBox(backend) => backend.select_proxy(node),
        }
    }

    fn close_all_connections(&mut self) -> Result<ObservedState, ActorFailure> {
        match self {
            Self::Mihomo(backend) => backend.close_all_connections(),
            Self::SingBox(backend) => backend.close_all_connections(),
        }
    }

    fn set_mode(&mut self, mode: ProxyMode) -> Result<AppliedState, ActorFailure> {
        match self {
            Self::Mihomo(backend) => backend.set_mode(mode),
            Self::SingBox(backend) => backend.set_mode(mode),
        }
    }
}

/// Mihomo core command adapter owning the shared node registry.
pub struct MihomoCoreBackend {
    control: MihomoHttpControl,
    nodes: CoreNodeRegistry,
}

impl MihomoCoreBackend {
    /// Wraps a ready controller with a fresh node registry.
    pub fn new(control: MihomoHttpControl) -> Self {
        Self {
            control,
            nodes: Arc::new(Mutex::new(BTreeMap::new())),
        }
    }

    /// Shares the registry the subscription backend indexes nodes into.
    pub fn registry(&self) -> CoreNodeRegistry {
        Arc::clone(&self.nodes)
    }
}

impl CoreCommandBackend for MihomoCoreBackend {
    fn select_proxy(&mut self, node: NodeId) -> Result<AppliedState, ActorFailure> {
        let registered = resolve_node(&self.nodes, node)?;
        self.control
            .select_proxy(&registered.landing_group, &registered.name, CONTROL_TIMEOUT)
            .map_err(kernel_failure)?;
        crate::selection::remember(node, &registered.landing_group, &registered.name);
        applied_running(CoreKind::Mihomo, Some(node))
    }

    fn close_all_connections(&mut self) -> Result<ObservedState, ActorFailure> {
        self.control
            .close_all_connections(CONTROL_TIMEOUT)
            .map_err(kernel_failure)?;
        Ok(ObservedState::new(0, 0, 0, 0))
    }

    fn set_mode(&mut self, mode: ProxyMode) -> Result<AppliedState, ActorFailure> {
        self.control
            .set_mode(mode_label(mode), CONTROL_TIMEOUT)
            .map_err(kernel_failure)?;
        applied_running(CoreKind::Mihomo, None)
    }
}

/// sing-box core command adapter owning the shared node registry.
pub struct SingBoxCoreBackend {
    control: SingBoxHttpControl,
    nodes: CoreNodeRegistry,
}

impl SingBoxCoreBackend {
    /// Wraps a ready controller with a fresh node registry.
    pub fn new(control: SingBoxHttpControl) -> Self {
        Self {
            control,
            nodes: Arc::new(Mutex::new(BTreeMap::new())),
        }
    }

    /// Wraps a ready controller sharing an existing registry (dual-core mode).
    pub fn new_with_registry(control: SingBoxHttpControl, nodes: CoreNodeRegistry) -> Self {
        Self { control, nodes }
    }

    /// Shares the registry the subscription backend indexes nodes into.
    pub fn registry(&self) -> CoreNodeRegistry {
        Arc::clone(&self.nodes)
    }
}

impl CoreCommandBackend for SingBoxCoreBackend {
    fn select_proxy(&mut self, node: NodeId) -> Result<AppliedState, ActorFailure> {
        // Verify the node is subscription-indexed before dialing the kernel.
        resolve_node(&self.nodes, node)?;
        // sing-box renders outbounds tagged `proxy-<canonical-hex>` under the
        // PROXY/GLOBAL selectors, so the Clash API select must address that
        // tag in the PROXY group — not the Mihomo display name/group ("AUTO")
        // stored on the shared registry entry.
        let tag = format!("proxy-{}", caly_domain::to_hex(node.into_bytes()));
        self.control
            .select_proxy("PROXY", &tag, CONTROL_TIMEOUT)
            .map_err(kernel_failure)?;
        crate::selection::remember(node, "PROXY", &tag);
        applied_running(CoreKind::SingBox, Some(node))
    }

    fn close_all_connections(&mut self) -> Result<ObservedState, ActorFailure> {
        self.control
            .close_all_connections(CONTROL_TIMEOUT)
            .map_err(kernel_failure)?;
        Ok(ObservedState::new(0, 0, 0, 0))
    }

    fn set_mode(&mut self, mode: ProxyMode) -> Result<AppliedState, ActorFailure> {
        self.control
            .set_mode(mode_label(mode), CONTROL_TIMEOUT)
            .map_err(kernel_failure)?;
        applied_running(CoreKind::SingBox, None)
    }
}

/// Resolves a node identity through the subscription-indexed registry.
fn resolve_node(nodes: &CoreNodeRegistry, node: NodeId) -> Result<RegisteredProxy, ActorFailure> {
    let mapping = nodes.lock().map_err(|_| {
        ActorFailure::infrastructure(
            "core node registry is poisoned",
            "restart the application runtime",
        )
    })?;
    mapping.get(&node).cloned().ok_or_else(|| {
        ActorFailure::infrastructure(
            "node is not registered by any subscription",
            "refresh the subscription and retry",
        )
    })
}

/// Builds the applied-state projection for a running core after a command.
fn applied_running(
    core: CoreKind,
    selected_node: Option<NodeId>,
) -> Result<AppliedState, ActorFailure> {
    AppliedState::new(Some(core), CoreRunState::Running, selected_node, None).map_err(|_| {
        ActorFailure::infrastructure(
            "applied state projection is invalid",
            "restart the application runtime",
        )
    })
}

/// Maps a kernel controller failure onto an actor failure, preserving the
/// kernel's human-readable message and suggested action.
fn kernel_failure(error: caly_corectl::contract::KernelFailure) -> ActorFailure {
    ActorFailure::infrastructure(error.message.as_str(), error.suggested_action.as_str())
}

/// Clash API mode label for a routing mode.
fn mode_label(mode: ProxyMode) -> &'static str {
    match mode {
        ProxyMode::Rule => "rule",
        ProxyMode::Global => "global",
        ProxyMode::Direct => "direct",
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    fn registry_with(entries: &[(u8, &str)]) -> CoreNodeRegistry {
        let registry: CoreNodeRegistry = Arc::new(Mutex::new(BTreeMap::new()));
        if let Ok(mut map) = registry.lock() {
            for (seed, name) in entries {
                map.insert(
                    NodeId::from_bytes([*seed; 16]),
                    RegisteredProxy {
                        landing_group: "PROXY".to_owned(),
                        name: (*name).to_owned(),
                        yaml: format!("- name: {name}\n"),
                        singbox: None,
                        subscription: caly_domain::SubscriptionId::from_bytes([0; 16]),
                    },
                );
            }
        }
        registry
    }

    #[test]
    fn unregistered_node_is_rejected_before_any_controller_call() {
        let mut backend = SingBoxCoreBackend {
            control: SingBoxHttpControl::new("127.0.0.1:1".to_owned(), None).unwrap(),
            nodes: registry_with(&[(1, "node-a")]),
        };
        let error = backend
            .select_proxy(NodeId::from_bytes([9; 16]))
            .err()
            .unwrap();
        assert!(error.message.as_str().contains("not registered"));
    }

    #[test]
    fn registered_node_reaches_the_wire() {
        // Nothing listens on port 1: a transport failure (not a registry
        // failure) proves resolution succeeded.
        let mut backend = SingBoxCoreBackend {
            control: SingBoxHttpControl::new("127.0.0.1:1".to_owned(), None).unwrap(),
            nodes: registry_with(&[(1, "node-a")]),
        };
        let error = backend
            .select_proxy(NodeId::from_bytes([1; 16]))
            .err()
            .unwrap();
        assert!(!error.message.as_str().contains("not registered"));
    }

    #[test]
    fn registry_iterates_in_node_id_order() {
        let registry = registry_with(&[(3, "node-c"), (1, "node-a"), (2, "node-b")]);
        let mapping = registry.lock().unwrap();
        let names: Vec<String> = mapping.values().map(|entry| entry.name.clone()).collect();
        assert_eq!(names, vec!["node-a", "node-b", "node-c"]);
    }
}
