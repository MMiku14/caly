//! Concrete application backends.

#![forbid(unsafe_code)]
#![cfg_attr(test, allow(clippy::unwrap_used, clippy::expect_used, clippy::panic, clippy::todo, clippy::unimplemented, clippy::unreachable))] // #53: tests assert with unwrap/expect/panic (+todo/unreachable in fixtures); production lints stay deny
pub mod capabilities;
pub mod config;
pub mod config_mutation;
pub mod core;
pub mod dns_env;
pub mod dual;
pub mod lifecycle;
pub mod mode;
pub mod platform;
pub mod selection;
pub mod sing_box;
pub mod subscription;
pub mod telemetry;

pub use capabilities::core_capability_set;
pub use config::MihomoConfigBackend;
pub use config_mutation::ConfigMutationBackendImpl;
pub use core::{
    CoreNodeRegistry, CoreRoutingRegistry, MihomoCoreBackend, SingBoxCoreBackend,
    SubscriptionRouting, shared_routing_registry,
};
// P7:cell 定义上移 caly-ports;re-export 保持本 crate 对外根路径不动。
pub use caly_domain::ports::SharedDesiredState;
pub use lifecycle::{CoreLifecycleBackend, MihomoLifecycleBackend, SharedCoreLifecycleBackend};
pub use platform::{LinuxSystemProxyBackend, LinuxTunCommandBackend};
pub use sing_box::SingBoxLifecycleBackend;
pub use subscription::{CachedSubscriptionBackend, HttpSubscriptionBackend};
pub use telemetry::{SharedObservedState, TelemetryBackend};

/// Builds an infrastructure `ActorFailure`, delegating to the shared clamped
/// constructor in `caly-ports` so a long runtime string can never abort.
pub(crate) fn failure(message: &str, action: &str) -> caly_domain::ports::ActorFailure {
    caly_domain::ports::ActorFailure::infrastructure(message, action)
}

/// Builds an `Unsupported` `ActorFailure` for capability gaps (desktop
/// without a system-proxy backend, PAC mode on a backend that does not
/// implement it, …). Distinct from `failure` so callers can distinguish
/// "this environment cannot do it" from "the operation failed".
pub(crate) fn unsupported_failure(message: &str, action: &str) -> caly_domain::ports::ActorFailure {
    caly_domain::ports::ActorFailure {
        kind: caly_domain::ports::ActorFailureKind::Unsupported,
        message: caly_domain::BoundedText::from_nonempty_clamped(message.to_owned(), "unsupported"),
        suggested_action: caly_domain::BoundedText::from_nonempty_clamped(action.to_owned(), ""),
    }
}

#[cfg(test)]
mod tests;
