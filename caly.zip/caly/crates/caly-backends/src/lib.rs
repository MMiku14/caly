//! Concrete application backends.

pub mod capabilities;
pub mod selection;
pub mod config;
pub mod core;
pub mod desired;
pub mod dns_env;
pub mod dual;
pub mod lifecycle;
pub mod platform;
pub mod sing_box;
pub mod subscription;
pub mod telemetry;
pub mod template;

pub use capabilities::core_capability_set;
pub use config::MihomoConfigBackend;
pub use core::{
    CoreBackend, CoreNodeRegistry, MihomoCoreBackend, MihomoNodeRegistry, SingBoxCoreBackend,
};
pub use desired::SharedDesiredState;
pub use lifecycle::{CoreLifecycleBackend, MihomoLifecycleBackend, SharedCoreLifecycleBackend};
pub use platform::{LinuxSystemProxyBackend, LinuxTunCommandBackend};
pub use sing_box::SingBoxLifecycleBackend;
pub use subscription::{CachedSubscriptionBackend, HttpSubscriptionBackend};
pub use telemetry::{SharedObservedState, TelemetryBackend};
pub use template::{TemplateRenderBackend, TemplateRenderInput, default_worker_executable};

/// Builds an infrastructure `ActorFailure`, delegating to the shared clamped
/// constructor in `caly-ports` so a long runtime string can never abort.
pub(crate) fn failure(message: &str, action: &str) -> caly_ports::ActorFailure {
    caly_ports::ActorFailure::infrastructure(message, action)
}

#[cfg(test)]
mod tests;
