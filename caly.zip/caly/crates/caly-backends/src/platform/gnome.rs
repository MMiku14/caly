//! GNOME proxy support via `gsettings` (`org.gnome.system.proxy`).

use std::path::PathBuf;

use caly_platform::command::{CommandRequest, CommandResult, CommandRunner};

use caly_ports::ActorFailure;

const TIMEOUT: std::time::Duration = std::time::Duration::from_secs(2);

/// Builds a bounded `gsettings` argument list from plain slices.
fn arguments(values: &[&str]) -> Result<caly_platform::command::CommandArguments, ActorFailure> {
    crate::platform::argv(&[values])
}

/// Runs one `gsettings` invocation and requires exit code zero.
pub(crate) fn run<R: CommandRunner>(
    runner: &mut R,
    values: &[&str],
) -> Result<CommandResult, ActorFailure> {
    let request = CommandRequest {
        executable: PathBuf::from("gsettings"),
        arguments: arguments(values)?,
        timeout: TIMEOUT,
    };
    let result = runner.run_bounded(request).map_err(|_| {
        crate::failure(
            "system proxy command failed",
            "install the desktop backend or use a supported desktop",
        )
    })?;
    if result.exit_code != Some(0) {
        return Err(crate::failure(
            "system proxy command returned failure",
            "inspect desktop proxy permissions",
        ));
    }
    Ok(result)
}

/// Enables or disables the GNOME proxy; enabling points at `host:port`.
pub(crate) fn apply<R: CommandRunner>(
    runner: &mut R,
    host: &str,
    port: u16,
    enabled: bool,
) -> Result<(), ActorFailure> {
    if enabled {
        let endpoint = format!("{host}:{port}");
        run(
            runner,
            &["set", "org.gnome.system.proxy.http", "host", &endpoint],
        )?;
    }
    run(
        runner,
        &[
            "set",
            "org.gnome.system.proxy",
            "mode",
            if enabled { "manual" } else { "none" },
        ],
    )?;
    Ok(())
}

/// Captures the current GNOME proxy state as `(mode, endpoint)`.
///
/// The endpoint is only meaningful for `manual` mode and is rendered as
/// `host:port`. Any unreadable component degrades to an empty endpoint rather
/// than failing the capture.
pub(crate) fn capture<R: CommandRunner>(runner: &mut R) -> (String, String) {
    let mode = run(runner, &["get", "org.gnome.system.proxy", "mode"])
        .ok()
        .and_then(|result| parse_gsettings_value(stdout_text(&result)))
        .unwrap_or_else(|| "none".to_owned());
    if mode != "manual" {
        return (mode, String::new());
    }
    let host = run(runner, &["get", "org.gnome.system.proxy.http", "host"])
        .ok()
        .and_then(|result| parse_gsettings_value(stdout_text(&result)))
        .unwrap_or_default();
    if host.is_empty() {
        return (mode, String::new());
    }
    // Some tools (including earlier caly versions) store a combined
    // `host:port` in the host key; accept it directly when well-formed.
    if endpoint_port(&host).is_some() {
        return (mode, host);
    }
    let port = run(runner, &["get", "org.gnome.system.proxy.http", "port"])
        .ok()
        .and_then(|result| parse_gsettings_u32(stdout_text(&result)));
    let Some(port) = port else {
        return (mode, String::new());
    };
    (mode, format!("{host}:{port}"))
}

/// Parses a `gsettings get` numeric value, tolerating the `uint32 ` prefix.
pub(crate) fn parse_gsettings_u32(raw: &str) -> Option<u16> {
    let trimmed = raw.trim();
    let digits = trimmed.strip_prefix("uint32 ").unwrap_or(trimmed);
    digits.parse::<u16>().ok()
}

/// The trailing port of a `host:port` endpoint, when well-formed.
fn endpoint_port(endpoint: &str) -> Option<u16> {
    endpoint
        .rfind(':')
        .and_then(|index| endpoint.get(index + 1..)?.parse::<u16>().ok())
}

/// Restores a previously captured GNOME proxy state.
///
/// `manual` without a usable endpoint degrades to disabling the proxy: an
/// unknown manual endpoint must not be replaced with a guess.
pub(crate) fn restore<R: CommandRunner>(
    runner: &mut R,
    mode: &str,
    endpoint: &str,
) -> Result<(), ActorFailure> {
    match mode {
        "manual" if !endpoint.is_empty() => {
            let (host, port) = split_endpoint(endpoint);
            run(
                runner,
                &["set", "org.gnome.system.proxy.http", "host", host],
            )?;
            run(
                runner,
                &["set", "org.gnome.system.proxy.http", "port", port],
            )?;
            run(runner, &["set", "org.gnome.system.proxy", "mode", "manual"])?;
        }
        "auto" => {
            run(runner, &["set", "org.gnome.system.proxy", "mode", "auto"])?;
        }
        _ => {
            run(runner, &["set", "org.gnome.system.proxy", "mode", "none"])?;
        }
    }
    Ok(())
}

/// Splits a `host:port` endpoint for the gsettings host/port keys.
fn split_endpoint(endpoint: &str) -> (&str, &str) {
    match endpoint.rfind(':') {
        Some(index) if index > 0 => (&endpoint[..index], &endpoint[index + 1..]),
        _ => (endpoint, "0"),
    }
}

/// Decodes the bounded stdout bytes of a command result as UTF-8.
fn stdout_text(result: &CommandResult) -> &str {
    std::str::from_utf8(result.stdout.as_slice()).unwrap_or_default()
}

/// Parses one `gsettings get` value, stripping the surrounding single quotes.
pub(crate) fn parse_gsettings_value(raw: &str) -> Option<String> {
    let trimmed = raw.trim();
    let unquoted = trimmed.strip_prefix('\'')?.strip_suffix('\'')?;
    Some(unquoted.to_owned())
}

#[cfg(test)]
mod tests {
    use super::*;
    use caly_domain::BoundedVec;

    /// Runner returning scripted stdout values in order (exit code zero).
    struct ScriptedRunner {
        outputs: std::collections::VecDeque<&'static str>,
    }

    impl CommandRunner for ScriptedRunner {
        fn run_bounded(
            &mut self,
            _request: CommandRequest,
        ) -> Result<CommandResult, caly_platform::PlatformFailure> {
            let text = self.outputs.pop_front().unwrap_or_default();
            let mut stdout = BoundedVec::new();
            let _ = stdout.try_extend(text.as_bytes().to_vec());
            Ok(CommandResult {
                exit_code: Some(0),
                stdout,
                stderr: BoundedVec::new(),
            })
        }
    }

    /// Runner recording every command line for assertion.
    struct RecordingRunner {
        commands: Vec<String>,
    }

    impl CommandRunner for RecordingRunner {
        fn run_bounded(
            &mut self,
            request: CommandRequest,
        ) -> Result<CommandResult, caly_platform::PlatformFailure> {
            let args: Vec<String> = request
                .arguments
                .iter()
                .map(|argument| argument.as_str().to_owned())
                .collect();
            self.commands.push(format!(
                "{} {}",
                request.executable.display(),
                args.join(" ")
            ));
            Ok(CommandResult {
                exit_code: Some(0),
                stdout: BoundedVec::new(),
                stderr: BoundedVec::new(),
            })
        }
    }

    #[test]
    fn parse_gsettings_value_strips_quotes() {
        assert_eq!(
            parse_gsettings_value("'manual'\n").as_deref(),
            Some("manual")
        );
        assert_eq!(parse_gsettings_value("").as_deref(), None);
        assert_eq!(parse_gsettings_value("manual").as_deref(), None);
    }

    #[test]
    fn parse_gsettings_u32_tolerates_type_prefix() {
        assert_eq!(parse_gsettings_u32("uint32 3128"), Some(3128));
        assert_eq!(parse_gsettings_u32("3128\n"), Some(3128));
        assert_eq!(parse_gsettings_u32("not-a-port"), None);
    }

    #[test]
    fn split_endpoint_separates_host_and_port() {
        assert_eq!(split_endpoint("127.0.0.1:7890"), ("127.0.0.1", "7890"));
        assert_eq!(split_endpoint("[::1]:7890"), ("[::1]", "7890"));
        assert_eq!(split_endpoint("noport"), ("noport", "0"));
    }

    #[test]
    fn capture_reads_split_host_and_port_keys() {
        let mut runner = ScriptedRunner {
            outputs: ["'manual'", "'10.0.0.1'", "uint32 3128"].into(),
        };
        assert_eq!(
            capture(&mut runner),
            ("manual".into(), "10.0.0.1:3128".into())
        );
    }

    #[test]
    fn capture_accepts_combined_host_port_value() {
        let mut runner = ScriptedRunner {
            outputs: ["'manual'", "'10.0.0.1:3128'"].into(),
        };
        assert_eq!(
            capture(&mut runner),
            ("manual".into(), "10.0.0.1:3128".into())
        );
    }

    #[test]
    fn capture_none_mode_has_no_endpoint() {
        let mut runner = ScriptedRunner {
            outputs: ["'none'"].into(),
        };
        assert_eq!(capture(&mut runner), ("none".into(), String::new()));
    }

    #[test]
    fn restore_manual_writes_endpoint_then_mode() -> Result<(), ActorFailure> {
        let mut runner = RecordingRunner {
            commands: Vec::new(),
        };
        restore(&mut runner, "manual", "10.0.0.1:3128")?;
        let joined = runner.commands.join("\n");
        assert!(joined.contains("set org.gnome.system.proxy.http host 10.0.0.1"));
        assert!(joined.contains("set org.gnome.system.proxy.http port 3128"));
        assert!(joined.contains("set org.gnome.system.proxy mode manual"));
        Ok(())
    }

    #[test]
    fn restore_manual_without_endpoint_disables() -> Result<(), ActorFailure> {
        let mut runner = RecordingRunner {
            commands: Vec::new(),
        };
        restore(&mut runner, "manual", "")?;
        assert!(runner.commands.join("\n").contains("mode none"));
        Ok(())
    }

    #[test]
    fn restore_auto_sets_auto_mode() -> Result<(), ActorFailure> {
        let mut runner = RecordingRunner {
            commands: Vec::new(),
        };
        restore(&mut runner, "auto", "")?;
        assert!(runner.commands.join("\n").contains("mode auto"));
        Ok(())
    }
}
