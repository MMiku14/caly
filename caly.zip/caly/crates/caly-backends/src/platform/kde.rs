//! KDE Plasma proxy support via `kwriteconfig` and KIO reload.

use std::path::PathBuf;

use caly_platform::command::{CommandRequest, CommandRunner};
use caly_platform::desktop::{http_proxy_url, http_proxy_url_from_endpoint};

use caly_ports::ActorFailure;

/// Picks kwriteconfig5 or kwriteconfig6 based on the running KDE major version.
pub(crate) fn kwriteconfig_tool() -> PathBuf {
    if std::env::var("KDE_SESSION_VERSION").as_deref() == Ok("6") {
        PathBuf::from("kwriteconfig6")
    } else {
        PathBuf::from("kwriteconfig5")
    }
}

/// KDE proxy-config keys written to `kioslaverc`.
pub(crate) const PROXY_GROUP: &[&str] = &["--file", "kioslaverc", "--group", "Proxy Settings"];
/// KDE's PAC key (`ProxyType=2` + this URL). The key contains a space, so
/// it is passed through `kwriteconfig` as one bounded argument rather than
/// being split into two argv entries.
pub(crate) const PAC_KEY: &str = "Proxy Config Script";

/// Runs one `kwriteconfig` write and notifies KIO to reload slave config.
pub(crate) fn apply_kde_proxy<R: CommandRunner>(
    runner: &mut R,
    tool: PathBuf,
    host: &str,
    port: u16,
    enabled: bool,
) -> Result<(), ActorFailure> {
    let group = PROXY_GROUP;
    write_key(
        runner,
        &tool,
        group,
        "ProxyType",
        if enabled { "1" } else { "0" },
    )?;
    if enabled {
        let endpoint = http_proxy_url(host, port);
        for key in ["httpProxy", "httpsProxy", "ftpProxy", "socksProxy"] {
            write_key(runner, &tool, group, key, &endpoint)?;
        }
    }
    reload_kio(runner)
}

/// `sysproxy pac <url>`: switch KDE to automatic mode pointing at the PAC
/// URL (`ProxyType=2` + `Proxy Config Script`).
pub(crate) fn apply_pac<R: CommandRunner>(
    runner: &mut R,
    tool: PathBuf,
    url: &str,
) -> Result<(), ActorFailure> {
    let group = PROXY_GROUP;
    write_key(runner, &tool, group, PAC_KEY, url)?;
    write_key(runner, &tool, group, "ProxyType", "2")?;
    reload_kio(runner)
}

/// Restores a previously captured KDE proxy state.
///
/// `manual` writes `ProxyType=1` and the endpoint across the four proxy
/// keys; `auto` writes `ProxyType=2`; `unknown` is a no-op (Audit #114);
/// anything else writes `ProxyType=0`. KIO is reloaded afterwards.
pub(crate) fn restore<R: CommandRunner>(
    runner: &mut R,
    mode: &str,
    endpoint: &str,
) -> Result<(), ActorFailure> {
    let tool = kwriteconfig_tool();
    let group = PROXY_GROUP;
    match mode {
        "manual" if !endpoint.is_empty() => {
            write_key(runner, &tool, group, "ProxyType", "1")?;
            let endpoint_url = http_proxy_url_from_endpoint(endpoint);
            for key in ["httpProxy", "httpsProxy", "ftpProxy", "socksProxy"] {
                write_key(runner, &tool, group, key, &endpoint_url)?;
            }
        }
        "auto" => {
            // Re-point the PAC URL (captured alongside the auto mode) before
            // re-engaging auto; restoring mode-only would leave caly's own
            // PAC active.
            if !endpoint.is_empty() {
                write_key(runner, &tool, group, PAC_KEY, endpoint)?;
            }
            write_key(runner, &tool, group, "ProxyType", "2")?;
        }
        "unknown" => {
            // a capture failure yields `unknown`; restoring must
            // not disable a proxy we never observed. Leave KIO untouched.
            return Ok(());
        }
        _ => write_key(runner, &tool, group, "ProxyType", "0")?,
    }
    reload_kio(runner)
}

/// Asks KIO to reload slave configuration so proxy changes apply live.
///
/// Best-effort: `kioslaverc` is already written when this runs, so a
/// failed reload (no session bus in a headless context, `dbus-send`
/// missing, …) must not fail the whole engagement — KIO picks the
/// config up on its next read. The failure is logged, not swallowed.
fn reload_kio<R: CommandRunner>(runner: &mut R) -> Result<(), ActorFailure> {
    let reload = CommandRequest {
        executable: PathBuf::from("dbus-send"),
        arguments: crate::platform::argv(&[&[
            "--type=signal",
            "/KIO/Scheduler",
            "org.kde.KIO.Scheduler.reparseSlaveConfiguration",
            "string:",
        ]])?,
        timeout: std::time::Duration::from_secs(2),
    };
    if let Err(error) = super::run_ok(runner, reload) {
        tracing::warn!(
            error = %error,
            "KIO reload signal failed after the proxy config was written; \
             running KDE apps pick it up on their next read"
        );
    }
    Ok(())
}

fn write_key<R: CommandRunner>(
    runner: &mut R,
    tool: &std::path::Path,
    group: &[&str],
    key: &str,
    value: &str,
) -> Result<(), ActorFailure> {
    let request = CommandRequest {
        executable: tool.to_path_buf(),
        arguments: crate::platform::argv(&[group, &["--key", key, value]])?,
        timeout: std::time::Duration::from_secs(2),
    };
    super::run_ok(runner, request).map(|_| ())
}

#[cfg(test)]
mod tests {
    use super::*;
    use caly_domain::BoundedVec;
    use caly_platform::command::CommandResult;

    struct RecordingRunner {
        commands: Vec<String>,
    }
    impl CommandRunner for RecordingRunner {
        fn run_bounded(
            &mut self,
            request: CommandRequest,
        ) -> Result<CommandResult, caly_platform::PlatformFailure> {
            let args: Vec<String> = request
                .arguments
                .iter()
                .map(|arg| arg.as_str().to_owned())
                .collect();
            self.commands.push(format!(
                "{} {}",
                request.executable.display(),
                args.join(" ")
            ));
            Ok(CommandResult {
                exit_code: Some(0),
                stdout: BoundedVec::new(),
                stderr: BoundedVec::new(),
            })
        }
    }

    #[test]
    fn kde_enable_writes_kioslaverc_and_reloads_kio() -> Result<(), ActorFailure> {
        let mut runner = RecordingRunner {
            commands: Vec::new(),
        };
        apply_kde_proxy(
            &mut runner,
            PathBuf::from("kwriteconfig5"),
            "127.0.0.1",
            7890,
            true,
        )?;
        let joined = runner.commands.join("\n");
        assert!(
            joined.contains(
                "kwriteconfig5 --file kioslaverc --group Proxy Settings --key ProxyType 1"
            )
        );
        assert!(joined.contains("--key httpProxy http://127.0.0.1:7890"));
        assert!(joined.contains("dbus-send --type=signal /KIO/Scheduler org.kde.KIO.Scheduler.reparseSlaveConfiguration string:"));
        Ok(())
    }

    #[test]
    fn kde_disable_writes_proxy_type_zero() -> Result<(), ActorFailure> {
        let mut runner = RecordingRunner {
            commands: Vec::new(),
        };
        apply_kde_proxy(
            &mut runner,
            PathBuf::from("kwriteconfig5"),
            "127.0.0.1",
            7890,
            false,
        )?;
        let joined = runner.commands.join("\n");
        assert!(joined.contains("--key ProxyType 0"));
        assert!(!joined.contains("httpProxy"));
        Ok(())
    }

    #[test]
    fn apply_pac_writes_script_then_auto_mode() -> Result<(), ActorFailure> {
        let mut runner = RecordingRunner {
            commands: Vec::new(),
        };
        apply_pac(
            &mut runner,
            PathBuf::from("kwriteconfig5"),
            "file:///tmp/caly/proxy.pac",
        )?;
        let joined = runner.commands.join("\n");
        assert!(
            joined.contains(
                "kwriteconfig5 --file kioslaverc --group Proxy Settings --key Proxy Config Script file:///tmp/caly/proxy.pac"
            ),
            "{joined}"
        );
        assert!(joined.contains("--key ProxyType 2"), "{joined}");
        assert!(joined.contains("dbus-send"));
        Ok(())
    }

    #[test]
    fn restore_auto_writes_captured_pac_url() -> Result<(), ActorFailure> {
        let mut runner = RecordingRunner {
            commands: Vec::new(),
        };
        restore(&mut runner, "auto", "http://example.com/proxy.pac")?;
        let joined = runner.commands.join("\n");
        assert!(
            joined.contains("--key Proxy Config Script http://example.com/proxy.pac"),
            "{joined}"
        );
        assert!(joined.contains("--key ProxyType 2"), "{joined}");
        Ok(())
    }

    #[test]
    fn restore_manual_writes_endpoint_and_reloads() -> Result<(), ActorFailure> {
        let mut runner = RecordingRunner {
            commands: Vec::new(),
        };
        restore(&mut runner, "manual", "10.0.0.1:8080")?;
        let joined = runner.commands.join("\n");
        assert!(joined.contains("--key ProxyType 1"));
        assert!(joined.contains("--key httpProxy http://10.0.0.1:8080"));
        assert!(joined.contains("dbus-send"));
        Ok(())
    }

    #[test]
    fn restore_manual_without_endpoint_disables() -> Result<(), ActorFailure> {
        let mut runner = RecordingRunner {
            commands: Vec::new(),
        };
        restore(&mut runner, "manual", "")?;
        let joined = runner.commands.join("\n");
        assert!(joined.contains("--key ProxyType 0"));
        assert!(!joined.contains("httpProxy"));
        Ok(())
    }

    #[test]
    fn kde_enable_brackets_ipv6_hosts() -> Result<(), ActorFailure> {
        let mut runner = RecordingRunner {
            commands: Vec::new(),
        };
        apply_kde_proxy(
            &mut runner,
            PathBuf::from("kwriteconfig5"),
            "::1",
            7890,
            true,
        )?;
        let joined = runner.commands.join("\n");
        assert!(
            joined.contains("--key httpProxy http://[::1]:7890"),
            "{joined}"
        );
        Ok(())
    }

    /// Runner failing only the KIO reload signal (no session bus).
    struct ReloadFailingRunner {
        commands: Vec<String>,
    }
    impl CommandRunner for ReloadFailingRunner {
        fn run_bounded(
            &mut self,
            request: CommandRequest,
        ) -> Result<CommandResult, caly_platform::PlatformFailure> {
            let exe = request.executable.display().to_string();
            self.commands.push(exe.clone());
            let exit_code = if exe == "dbus-send" { Some(1) } else { Some(0) };
            Ok(CommandResult {
                exit_code,
                stdout: BoundedVec::new(),
                stderr: BoundedVec::new(),
            })
        }
    }

    #[test]
    fn kde_enable_survives_failed_kio_reload() -> Result<(), ActorFailure> {
        // the config write already succeeded; a failed reload signal
        // must not fail the engagement.
        let mut runner = ReloadFailingRunner {
            commands: Vec::new(),
        };
        apply_kde_proxy(
            &mut runner,
            PathBuf::from("kwriteconfig5"),
            "127.0.0.1",
            7890,
            true,
        )?;
        assert!(runner.commands.iter().any(|c| c == "dbus-send"));
        Ok(())
    }
}
