//! Session-env proxy fallback via user `environment.d`.
//!
//! Serves every desktop without a proxy database (Wayland compositors
//! such as niri/sway/Hyprland, XFCE, LXQt/LXDE, bare window managers):
//! the session manager exports these variables into every login
//! session, which is exactly when the proxy takes effect —
//! re-login (or a new login shell) is required after a change.

use std::{fmt::Write as FmtWrite, path::PathBuf};

use caly_platform::desktop::{http_proxy_url, http_proxy_url_from_endpoint, session_env_file_path};

use caly_ports::ActorFailure;

/// Proxy variables written to the session file.
const PROXY_VARS: [&str; 4] = ["http_proxy", "https_proxy", "HTTP_PROXY", "HTTPS_PROXY"];
/// Bypass variables written alongside the proxy variables.
const NO_PROXY_VARS: [&str; 2] = ["no_proxy", "NO_PROXY"];
/// Minimal bypass set understood by every `no_proxy` consumer.
/// Loopback-only on purpose: wider entries (LAN CIDRs) have uneven
/// support across runtimes, while loopback must never be proxied.
const NO_PROXY_LOOPBACK: &str = "localhost,127.0.0.1,::1";

/// Renders the `environment.d` proxy file contents for an enabled/disabled state.
pub(crate) fn proxy_environment_contents(host: &str, port: u16, enabled: bool) -> String {
    let endpoint = if enabled {
        http_proxy_url(host, port)
    } else {
        String::new()
    };
    let mut lines = String::new();
    for var in PROXY_VARS {
        if endpoint.is_empty() {
            let _ = writeln!(lines, "unset {var}");
        } else {
            let _ = writeln!(lines, "export {var}=\"{endpoint}\"");
        }
    }
    // Without `no_proxy` every loopback call (health checks, the
    // daemon's own UDS-adjacent HTTP, browser-to-local-dev) loops
    // through the proxy; with it set, direct stays direct.
    for var in NO_PROXY_VARS {
        if endpoint.is_empty() {
            let _ = writeln!(lines, "unset {var}");
        } else {
            let _ = writeln!(lines, "export {var}=\"{NO_PROXY_LOOPBACK}\"");
        }
    }
    lines
}

/// Writes the user-level `environment.d` proxy file atomically.
pub(crate) fn write_environment_d(contents: &str) -> Result<(), ActorFailure> {
    let path = env_path()?;
    std::fs::create_dir_all(
        path.parent().ok_or_else(|| {
            crate::failure("no home directory", "configure HOME to write proxy env")
        })?,
    )
    .map_err(|_| {
        crate::failure(
            "cannot create environment.d directory",
            "inspect HOME permissions",
        )
    })?;
    // Staging + rename so a concurrent login shell never reads a
    // half-written file (same discipline as the PAC and geoip writes).
    let staging = path.with_extension("tmp");
    std::fs::write(&staging, contents).map_err(|_| {
        crate::failure(
            "cannot write session proxy environment file",
            "inspect HOME permissions",
        )
    })?;
    std::fs::rename(&staging, &path).map_err(|error| {
        let _ = std::fs::remove_file(&staging);
        crate::failure(
            &format!("cannot publish session proxy environment file: {error}"),
            "inspect HOME permissions",
        )
    })?;
    Ok(())
}

/// Resolves the session file through the shared path so the read side
/// (`caly-platform::desktop`) and this writer can never drift apart.
fn env_path() -> Result<PathBuf, ActorFailure> {
    session_env_file_path().ok_or_else(|| {
        crate::failure(
            "no HOME to locate environment.d",
            "set HOME in the daemon environment",
        )
    })
}

/// Restores a captured session-env proxy state: rewrites the
/// `environment.d` file with the captured endpoint (manual), or
/// clears the proxy variables.
pub(crate) fn restore(endpoint: &str, manual: bool) -> Result<(), ActorFailure> {
    let contents = if manual && !endpoint.is_empty() {
        manual_environment_contents(endpoint)
    } else {
        proxy_environment_contents("127.0.0.1", 0, false)
    };
    write_environment_d(&contents)
}

/// Renders an enabled environment file from a captured endpoint
/// (`host:port`, IPv6 brackets preserved) through the shared URL
/// renderer.
pub(crate) fn manual_environment_contents(endpoint: &str) -> String {
    let url = http_proxy_url_from_endpoint(endpoint);
    let mut lines = String::new();
    for var in PROXY_VARS {
        let _ = writeln!(lines, "export {var}=\"{url}\"");
    }
    for var in NO_PROXY_VARS {
        let _ = writeln!(lines, "export {var}=\"{NO_PROXY_LOOPBACK}\"");
    }
    lines
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn enabled_environment_exports_proxy_vars() {
        let contents = proxy_environment_contents("127.0.0.1", 7890, true);
        assert!(contents.contains("export http_proxy=\"http://127.0.0.1:7890\""));
        assert!(contents.contains("export https_proxy=\"http://127.0.0.1:7890\""));
        assert!(contents.contains("export HTTP_PROXY=\"http://127.0.0.1:7890\""));
        assert!(contents.contains("export HTTPS_PROXY=\"http://127.0.0.1:7890\""));
    }

    #[test]
    fn enabled_environment_exports_no_proxy_bypass() {
        let contents = proxy_environment_contents("127.0.0.1", 7890, true);
        assert!(contents.contains("export no_proxy=\"localhost,127.0.0.1,::1\""));
        assert!(contents.contains("export NO_PROXY=\"localhost,127.0.0.1,::1\""));
    }

    #[test]
    fn enabled_environment_brackets_ipv6_hosts() {
        let contents = proxy_environment_contents("::1", 7890, true);
        assert!(contents.contains("export http_proxy=\"http://[::1]:7890\""));
    }

    #[test]
    fn disabled_environment_unexports_proxy_vars() {
        let contents = proxy_environment_contents("127.0.0.1", 7890, false);
        assert!(contents.contains("unset http_proxy"));
        assert!(contents.contains("unset https_proxy"));
        assert!(contents.contains("unset no_proxy"));
        assert!(contents.contains("unset NO_PROXY"));
        assert!(!contents.contains("export http_proxy"));
    }

    #[test]
    fn manual_environment_uses_captured_endpoint() {
        let contents = manual_environment_contents("10.0.0.1:8080");
        assert!(contents.contains("export http_proxy=\"http://10.0.0.1:8080\""));
    }

    #[test]
    fn manual_environment_brackets_ipv6_endpoint() {
        let contents = manual_environment_contents("[::1]:8080");
        assert!(contents.contains("export http_proxy=\"http://[::1]:8080\""));
    }

    #[test]
    fn manual_environment_without_port_keeps_legacy_shape() {
        let contents = manual_environment_contents("proxy.lan");
        assert!(contents.contains("export http_proxy=\"http://proxy.lan\""));
        assert!(!contents.contains(":0\""));
    }
}
