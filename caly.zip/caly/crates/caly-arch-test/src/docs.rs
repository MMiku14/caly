//! Documentation-shape guardrails.
//!
//! `docs/ONBOARDING_NOTES.md §5` and `§4.34-§4.35` record the same class of problem over and over:
//! prose that was true when it was measured and is quietly false afterwards — a status table that
//! still says "19 members" after a crate was added, a "not yet implemented" line about something
//! that shipped two rounds ago, two sections numbered `6.10` in one file, a table whose rows lost a
//! column, an ordered list that jumps from `3.` to `3.` to `4.`.
//!
//! Those are not stylistic complaints. This repo's whole methodology is "the docs claim X, verify X
//! with a command", and a doc that cites a path that does not exist, or numbers two sections the
//! same way, breaks that loop at its entry point. Every check here is one a human performed by hand
//! during the eighth round and got wrong until a script was run; this module is that script, kept
//! in the guardrail crate so `cargo test` runs it like every other gate.
//!
//! All functions are pure over `(file name, text)`; reading the filesystem is the caller's job, so
//! the checks can be exercised on synthetic input in a unit test. That matters: a gate with no
//! falsification test is a gate nobody has seen fail.

/// What kind of documentation problem was found.
#[derive(Clone, Copy, Debug, Eq, PartialEq, Ord, PartialOrd)]
pub enum DocIssueKind {
    /// Rows of one Markdown table disagree on column count, or a table has no header separator.
    TableShape,
    /// A numbered list is not contiguous (`1. 2. 4.`, or the same number twice).
    ListNumbering,
    /// Two sections in one file carry the same heading number.
    DuplicateHeadingNumber,
    /// Text cites a `crates/…`, `docs/…` or `scripts/…` path that is not present.
    BrokenPathReference,
    /// A number the document measured is no longer the number the tree shows.
    StaleCount,
    /// Text names a `caly-*` crate that is neither a workspace member nor documented as absent.
    UnknownCrateName,
    /// A table row is glued onto the end of a paragraph instead of standing on its own line.
    StrayTableRow,
    LedgerNumbering,
    /// A document exists but the index does not name it, or the index names a document that is gone.
    UnindexedDocument,
}

impl DocIssueKind {
    pub const fn as_str(self) -> &'static str {
        match self {
            Self::TableShape => "table-shape",
            Self::ListNumbering => "list-numbering",
            Self::DuplicateHeadingNumber => "duplicate-heading-number",
            Self::BrokenPathReference => "broken-path-reference",
            Self::StaleCount => "stale-count",
            Self::UnknownCrateName => "unknown-crate-name",
            Self::StrayTableRow => "stray-table-row",
            Self::LedgerNumbering => "ledger-numbering",
            Self::UnindexedDocument => "unindexed-document",
        }
    }
}

/// One problem, with the file and 1-based line so a reader can go straight to it.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct DocIssue {
    pub kind: DocIssueKind,
    pub file: String,
    pub line: usize,
    pub detail: String,
}

impl DocIssue {
    pub fn new(kind: DocIssueKind, file: &str, line: usize, detail: impl Into<String>) -> Self {
        Self {
            kind,
            file: file.to_owned(),
            line,
            detail: detail.into(),
        }
    }

    pub fn display(&self) -> String {
        format!(
            "{}:{} {}: {}",
            self.file,
            self.line,
            self.kind.as_str(),
            self.detail
        )
    }
}

/// Crate names that legitimately appear in docs without being workspace members.
///
/// An allow-list rather than silence, so each entry has to carry its reason: `caly-tui` is listed in
/// `RFC-0001`'s crate map and `IMPLEMENTATION_STATUS` but has no directory, which
/// `docs/ONBOARDING_NOTES.md §5.3` records as a navigation trap. A new name appearing here is a
/// signal to write that kind of note, not to extend the list casually.
pub const DOCUMENTED_NON_MEMBER_CRATES: &[&str] = &["caly-tui", "caly-foo"];

/// Column count of a Markdown table row, honouring `\|` escapes and code spans.
///
/// Both are needed in this repo specifically: doc cells quote shell one-liners such as
/// `` `grep -rn 'a\|b' crates` ``, and counting raw `|` bytes would flag a well-formed row.
fn table_cells(line: &str) -> Option<Vec<String>> {
    let trimmed = line.trim();
    if !trimmed.starts_with('|') || !trimmed.ends_with('|') || trimmed.len() < 2 {
        return None;
    }
    let mut cells = Vec::new();
    let mut current = String::new();
    let mut code = false;
    let mut escaped = false;
    for ch in trimmed.chars().skip(1) {
        if escaped {
            current.push(ch);
            escaped = false;
            continue;
        }
        match ch {
            // A backslash escapes only **outside** a code span; inside one it is a literal
            // character (CommonMark). Honoring escapes inside code spans made a span that ends
            // in a backslash (`| `\` | b | c |` -- quoting the character itself) swallow its own
            // closing delimiter, so the span never closed and every pipe after it went
            // uncounted: a three-column row read as two. Found by round 39's own disposition
            // row, which quotes the missing escape character by name.
            '\\' if !code => {
                escaped = true;
                current.push(ch);
            }
            '\\' => current.push(ch),
            '`' => {
                code = !code;
                current.push(ch);
            }
            '|' if !code => {
                cells.push(current.trim().to_owned());
                current = String::new();
            }
            _ => current.push(ch),
        }
    }
    // A row like `| a | b |` opened with the leading `|` skipped, so each separator closed a cell
    // and the trailing `|` left an empty remainder: keep it as a cell only when it has content, and
    // never let the closing pipe masquerade as a column (that off-by-one made every well-formed row
    // look one column short, and the first thing it "caught" was a row that was fine).
    if !current.trim().is_empty() {
        cells.push(current.trim().to_owned());
    }
    Some(cells)
}

fn is_separator_row(cells: &[String]) -> bool {
    !cells.is_empty()
        && cells
            .iter()
            .all(|cell| !cell.is_empty() && cell.chars().all(|ch| matches!(ch, '-' | ':' | ' ')))
}

/// Counts `|` characters that are not inside an inline code span. Backticks are consumed as
/// toggles, matching how [`table_cells`] treats them, so a doc may quote a row as an example
/// (`` `| 6.99 |` ``) without the quote being mistaken for a row that lost its newline.
fn pipes_outside_code_spans(line: &str) -> usize {
    let mut count = 0usize;
    let mut code = false;
    for ch in line.chars() {
        match ch {
            '`' => code = !code,
            '|' if !code => count += 1,
            _ => {}
        }
    }
    count
}

/// Tables must be rectangular and must have a separator row after the header.
/// Find table rows that do not start their own line.
///
/// Why this exists: two rounds of `docs/ONBOARDING_NOTES.md` gained a disposition row that *nobody
/// could see as a row*. The patch text ended with the row and the next heading, the anchor began with
/// the blank lines before that heading, and the replacement dropped them -- so the row landed at the
/// end of the preceding paragraph (`…理由。| 6.42 | … || 6.43 | …`). Every existing check passed:
/// `check_markdown_tables` only inspects lines that begin with `|`, so a row with a prefix is not a row
/// at all, and no gate asked whether each round had an entry. A document that quietly stops being a
/// table is how "we keep a disposition ledger" becomes false while the file grows.
pub fn check_stray_table_rows(file: &str, text: &str) -> Vec<DocIssue> {
    let mut issues = Vec::new();
    let mut inside_fence = false;
    for (index, line) in text.lines().enumerate() {
        let trimmed = line.trim();
        if trimmed.starts_with("```") {
            inside_fence = !inside_fence;
            continue;
        }
        if inside_fence || trimmed.starts_with('|') || !trimmed.ends_with('|') {
            continue;
        }
        // Three cell boundaries is the smallest shape that cannot be prose: text may legitimately
        // contain one `|` (an alternation in a quoted command), and two would still be an inline
        // expression. A line that ends on a pipe *and* holds three boundaries is a row that lost its
        // newline. The count is of pipes, not of spaced `" | "` runs, because the incident this gate
        // exists for was a row glued with no space (`…理由。| 6.51 | …`) whose last cell closed on the
        // final character of the line -- three boundaries, but only two spaced runs.
        if pipes_outside_code_spans(trimmed) >= 3 {
            issues.push(DocIssue::new(
                DocIssueKind::StrayTableRow,
                file,
                index + 1,
                format!(
                    "this line ends in `|` and holds at least three cells, so it is a table row that \
                     does not start its own line; rows glued to a paragraph are invisible to every \
                     other table check: {trimmed}"
                ),
            ));
        }
    }
    issues
}

/// The one number `docs/CENTERLINE_PROGRESS.md` quotes about the whole workspace: its closing sentence
/// 「这 N 个断言是否依然成立」. It is re-copied by hand every round and no other check reads it, which is
/// the profile of a number that goes stale.
///
/// The scan is deliberately narrow -- lines containing 「个断言是否依然成立」, not every 「N 个断言」 in the
/// file. Round paragraphs legitimately say things like 「新增 14 个断言」, and counting those would turn this
/// into a check on prose style rather than on the one claim that is supposed to equal the tree.
///
/// Three failures: no claim (deleting the sentence would otherwise silently "pass" a compare-the-numbers
/// check), more than one claim (what a bad splice leaves behind), and a claim that disagrees with `total`.
pub fn check_round_claim(file: &str, text: &str, total: usize) -> Vec<DocIssue> {
    let claims: Vec<(usize, usize)> = text
        .lines()
        .enumerate()
        .filter(|(_, line)| line.contains("个断言是否依然成立"))
        .filter_map(|(index, line)| {
            let at = line.find("个断言是否依然成立")?;
            let head = line[..at].trim_end();
            let digits: String = head
                .chars()
                .rev()
                .take_while(|c| c.is_ascii_digit())
                .collect::<String>()
                .chars()
                .rev()
                .collect();
            // A number that is part of a longer alphanumeric run is not this claim: `x499 个断言` would
            // otherwise be read as 499.
            let clean = head
                .chars()
                .last()
                .map(|c| c.is_ascii_digit())
                .unwrap_or(false);
            match (clean, digits.parse::<usize>()) {
                (true, Ok(value)) => Some((index + 1, value)),
                _ => None,
            }
        })
        .collect();

    match claims.as_slice() {
        [] => vec![DocIssue::new(
            DocIssueKind::StaleCount,
            file,
            1,
            format!(
                "the closing claim \u{300c}这 N 个断言是否依然成立\u{300d} is gone, so there is nothing to \
                 compare the tree's {total} assertions against -- deleting a sentence is not the way to make \
                 a check pass"
            ),
        )],
        [(_, claimed)] if *claimed == total => Vec::new(),
        [(line, claimed)] => vec![DocIssue::new(
            DocIssueKind::StaleCount,
            file,
            *line,
            format!(
                "the centerline claims {claimed} assertions; the tree holds {total}. Re-copy the number \
                 after the last change -- `ONBOARDING_NOTES §4.105` states the rule, this is its machine"
            ),
        )],
        many => vec![DocIssue::new(
            DocIssueKind::StaleCount,
            file,
            many[1].0,
            format!(
                "the closing claim appears {} times ({many:?}); after a splice a reader cannot tell which \
                 number is current",
                many.len()
            ),
        )],
    }
}

/// The index in `docs/README.md §1` is the only place that answers "what documents exist at all".
///
/// Both directions are checked, because each fails quietly in its own way: a new document missing from
/// the index is *unfindable* (and a reader who never finds it writes a sixth copy of the same rule --
/// which is `§4.81` with a bigger blast radius), while an index entry with no file behind it is the
/// same broken-path defect that `check_path_references` catches elsewhere, just in the one place
/// nobody thinks to cite a path from.
///
/// `doc_names` are the top-level `.md` files as bare names (``ROADMAP.md``, not ``docs/ROADMAP.md``),
/// which is the shape the index tree uses; entries that are directories are the caller's to exclude.
pub fn check_doc_index(index_file: &str, index_text: &str, doc_names: &[String]) -> Vec<DocIssue> {
    let listed: Vec<String> = index_text
        .lines()
        .filter(|line| {
            line.contains("\u{251c}\u{2500}\u{2500} ") || line.contains("\u{2514}\u{2500}\u{2500} ")
        })
        .filter_map(|line| line.rsplit("\u{2500}\u{2500} ").next().map(str::to_owned))
        .filter(|name| name.ends_with(".md"))
        .collect();

    let mut issues = Vec::new();
    for name in doc_names {
        if !listed.iter().any(|entry| entry == name) {
            issues.push(DocIssue::new(
                DocIssueKind::UnindexedDocument,
                index_file,
                1,
                format!(
                    "`docs/{name}` exists but `\u{00a7}1` does not list it -- a document nobody can find \
                     is a document nobody reads, and the next reader rewrites it instead"
                ),
            ));
        }
    }
    for entry in &listed {
        if !doc_names.iter().any(|name| name == entry) {
            issues.push(DocIssue::new(
                DocIssueKind::UnindexedDocument,
                index_file,
                1,
                format!(
                    "the index lists `docs/{entry}`, which is not in the tree -- the file was renamed or \
                     deleted and the index kept promising it"
                ),
            ));
        }
    }
    issues
}

/// `docs/ONBOARDING_NOTES.md`'s disposition ledger numbers its rows `| 6.N |` and gives the
/// "deliberately **not** doing" heading the next number (`### 6.N+1 明确…`). Each half is legal markdown
/// on its own, so nothing else in the suite notices when they drift -- and the numbering is the only way a
/// reader can tell, without reading prose, whether a round got recorded at all. Four rounds of hand repair
/// (`§4.78`, `§4.89`, `§4.90`, and a fifth found while writing `§4.106`) is what made this a check.
pub fn check_disposition_ledger(file: &str, text: &str) -> Vec<DocIssue> {
    let mut rows: Vec<(usize, u32)> = Vec::new();
    // Whether each row's own line closes the cell, kept in submission order so the split-row report
    // below never has to look the text up again (and never needs an unreachable fallback: a branch
    // no test can reach is not a safety net, it is a claim nobody can check -- `§4.94`).
    let mut row_ends: Vec<(usize, u32, bool)> = Vec::new();
    let mut headings: Vec<(usize, u32)> = Vec::new();
    let mut inside_fence = false;
    // Rows separated by a blank line are not rows any more: markdown ends the table, and what a reader
    // gets is a paragraph that happens to contain pipes. Numbering checks cannot see that (they read
    // the rows in order, blank line or no blank line), so the scan tracks adjacency too.
    let mut split: Vec<DocIssue> = Vec::new();
    let mut previous_row_line: Option<usize> = None;
    let mut previous_ended = true;

    for (index, line) in text.lines().enumerate() {
        let trimmed = line.trim();
        if trimmed.starts_with("```") {
            inside_fence = !inside_fence;
            continue;
        }
        if inside_fence {
            continue;
        }
        if let Some(rest) = trimmed.strip_prefix("| 6.") {
            if let Some(digits) = rest.split(" |").next() {
                if let Ok(number) = digits.trim().parse::<u32>() {
                    let line = index + 1;
                    if let Some(previous) = previous_row_line {
                        // A gap whose cause is a split row gets the precise report instead: the row above
                        // did not end, so the table ended there for markdown, and saying "blank line"
                        // would send the reader to fix something that is not wrong.
                        if line - previous > 1 && previous_ended {
                            split.push(DocIssue::new(
                                DocIssueKind::LedgerNumbering,
                                file,
                                line,
                                format!(
                                    "disposition row 6.{number} is separated from the row above by a blank \
                                     line, which ends the markdown table -- below the gap a reader sees a \
                                     paragraph, not a ledger entry"
                                ),
                            ));
                        }
                    }
                    let ends_ok = trimmed.ends_with('|');
                    row_ends.push((line, number, ends_ok));
                    previous_row_line = Some(line);
                    previous_ended = ends_ok;
                    rows.push((line, number));
                    continue;
                }
            }
        }
        if let Some(rest) = trimmed.strip_prefix("### 6.") {
            if let Some(digits) = rest.split(' ').next() {
                if let Ok(number) = digits.trim().parse::<u32>() {
                    if rest.contains("明确") {
                        headings.push((index + 1, number));
                    }
                }
            }
        }
    }

    if rows.is_empty() {
        // Not a ledger file; the heading alone is nobody's business.
        return Vec::new();
    }

    let mut issues = split;
    // A row that does not close with `|` on its own line is a row that was written across lines -- which
    // is what two consecutive rounds actually did (a newline was left inside the middle cell). Markdown
    // then renders the continuation as paragraph text, and the column checks never see the second
    // fragment, so the shape is checked here.
    for (line, number, ends_ok) in &row_ends {
        if !ends_ok {
            issues.push(DocIssue::new(
                DocIssueKind::LedgerNumbering,
                file,
                *line,
                format!(
                    "disposition row 6.{number} does not end with `|` on its own line; the row was split \
                     across lines, so markdown ends the table and a reader sees a paragraph where an \
                     entry should be"
                ),
            ));
        }
    }
    let mut seen: std::collections::BTreeSet<u32> = std::collections::BTreeSet::new();
    for (line, number) in &rows {
        if !seen.insert(*number) {
            issues.push(DocIssue::new(
                DocIssueKind::LedgerNumbering,
                file,
                *line,
                format!(
                    "disposition row {number} appears twice; the ledger is read as a count of rounds, so a \
                     duplicate silently hides one"
                ),
            ));
        }
    }
    let highest = *seen.iter().max().unwrap_or(&0);
    for expected in 1..=highest {
        if !seen.contains(&expected) {
            issues.push(DocIssue::new(
                DocIssueKind::LedgerNumbering,
                file,
                rows.last().map(|(line, _)| *line).unwrap_or(1),
                format!(
                    "the disposition ledger jumps over {expected}; a gap is indistinguishable from \
                     \"nobody remembered to record that round\""
                ),
            ));
        }
    }
    match headings.as_slice() {
        [(line, number)] => {
            if *number != highest + 1 {
                issues.push(DocIssue::new(
                    DocIssueKind::LedgerNumbering,
                    file,
                    *line,
                    format!(
                        "the \"deliberately not doing\" heading is numbered 6.{number} but the last ledger row \
                         is 6.{highest}; it must be exactly the next number, otherwise the two lists claim \
                         different round counts"
                    ),
                ));
            }
        }
        [] => issues.push(DocIssue::new(
            DocIssueKind::LedgerNumbering,
            file,
            rows.last().map(|(line, _)| *line).unwrap_or(1),
            format!(
                "the ledger ends at 6.{highest} but there is no \"### 6.{} 明确**不做**的项\" heading to say \
                 what was left out on purpose",
                highest + 1
            ),
        )),
        _ => {
            for (line, number) in &headings[1..] {
                issues.push(DocIssue::new(
                    DocIssueKind::LedgerNumbering,
                    file,
                    *line,
                    format!("a second \"deliberately not doing\" heading (6.{number}) splits the list in two"),
                ));
            }
        }
    }
    issues
}

pub fn check_markdown_tables(file: &str, text: &str) -> Vec<DocIssue> {
    let mut issues = Vec::new();
    let lines: Vec<&str> = text.lines().collect();
    let mut index = 0usize;
    while index < lines.len() {
        let Some(cells) = table_cells(lines[index]) else {
            index += 1;
            continue;
        };
        let start = index;
        let width = cells.len();
        let mut rows = 1usize;
        let mut saw_separator = false;
        let mut cursor = index + 1;
        while let Some(next) = lines.get(cursor).and_then(|line| table_cells(line)) {
            if rows == 1 && is_separator_row(&next) {
                saw_separator = true;
            }
            if next.len() != width {
                issues.push(DocIssue::new(
                    DocIssueKind::TableShape,
                    file,
                    cursor + 1,
                    format!(
                        "row has {} column(s), the header of this table (line {}) has {width}",
                        next.len(),
                        start + 1
                    ),
                ));
            }
            rows += 1;
            cursor += 1;
        }
        if rows >= 2 && !saw_separator {
            issues.push(DocIssue::new(
                DocIssueKind::TableShape,
                file,
                start + 1,
                "a table needs a `|---|` separator row after its header; without it no renderer \
                 (including the workspace preview) shows a table at all",
            ));
        }
        index = cursor;
    }
    issues
}

fn list_number(line: &str) -> Option<usize> {
    if line.starts_with(' ') || line.starts_with('\t') {
        // Indented items belong to a nested list, which may legitimately restart its numbering.
        return None;
    }
    let digits = line.chars().take_while(|ch| ch.is_ascii_digit()).count();
    if digits == 0 || !line[digits..].starts_with(". ") {
        return None;
    }
    line[..digits].parse().ok()
}

/// Numbered lists must count up by one.
///
/// Markdown would happily renumber `1. 3. 3.` on render, which is why nobody notices by reading:
/// two rows of `docs/README.md §2.5` carried the same number for as long as the file existed.
pub fn check_list_numbering(file: &str, text: &str) -> Vec<DocIssue> {
    let mut issues = Vec::new();
    let mut previous: Option<(usize, usize)> = None;
    for (offset, line) in text.lines().enumerate() {
        match list_number(line) {
            Some(number) => {
                if let Some((last_number, last_line)) = previous {
                    // Any non-item line clears `previous`, so a blank line starts a new list and a
                    // restarted `1.` after prose is not a violation. Only a within-list jump is.
                    if number != last_number + 1 {
                        issues.push(DocIssue::new(
                            DocIssueKind::ListNumbering,
                            file,
                            offset + 1,
                            format!(
                                "starts item {number} right after item {last_number} (line {last_line})"
                            ),
                        ));
                    }
                }
                previous = Some((number, offset + 1));
            }
            None => previous = None,
        }
    }
    issues
}

/// Section headings must be unique within a file.
///
/// Only numbered headings are considered (`## 3. …`, `### 4.28 …`), because those are what other
/// documents cite (`§4.28`), and a duplicate makes the citation ambiguous.
pub fn check_heading_numbers(file: &str, text: &str) -> Vec<DocIssue> {
    let mut issues = Vec::new();
    let mut seen: Vec<(String, usize)> = Vec::new();
    for (offset, line) in text.lines().enumerate() {
        let Some(heading) = heading_number(line) else {
            continue;
        };
        if let Some((_, first)) = seen.iter().find(|(number, _)| *number == heading) {
            issues.push(DocIssue::new(
                DocIssueKind::DuplicateHeadingNumber,
                file,
                offset + 1,
                format!("section `{heading}` is also the number used on line {first}"),
            ));
        }
        seen.push((heading, offset + 1));
    }
    issues
}

fn heading_number(line: &str) -> Option<String> {
    let hashes = line.chars().take_while(|ch| *ch == '#').count();
    if !(2..=4).contains(&hashes) {
        return None;
    }
    let rest = line[hashes..].trim_start();
    let mut digits = String::new();
    for ch in rest.chars() {
        if ch.is_ascii_digit() || ch == '.' {
            digits.push(ch);
        } else {
            break;
        }
    }
    if digits.is_empty() || !rest[digits.len()..].starts_with(' ') {
        return None;
    }
    // Normalise `3` and `3.` to the same key so they cannot hide from each other.
    let normalised = digits.trim_end_matches('.').to_owned();
    if normalised.is_empty() {
        return None;
    }
    Some(normalised)
}

/// Extract the back-quoted spans of a line.
///
/// Docs here cite paths inside backticks, which is what makes a mechanical check worth writing:
/// the same path also appears in prose, but only the backticked form is a reference, and a
/// renderer-independent rule needs that distinction.
pub fn code_spans(line: &str) -> Vec<String> {
    let mut spans = Vec::new();
    let mut current: Option<String> = None;
    let mut chars = line.chars().peekable();
    while let Some(ch) = chars.next() {
        match ch {
            '`' => match current.take() {
                Some(span) => spans.push(span),
                None => current = Some(String::new()),
            },
            other => {
                if let Some(span) = current.as_mut() {
                    span.push(other);
                }
            }
        }
        let _ = chars.peek();
    }
    spans
}

fn looks_like_repo_path(span: &str) -> bool {
    let span = span.trim();
    let Some((prefix, _)) = span.split_once('/') else {
        return false;
    };
    matches!(prefix, "crates" | "docs" | "scripts")
        && span.ends_with(".rs")
        && (span.contains("/src/") || span.contains("/tests/"))
}

fn looks_like_doc_path(span: &str) -> bool {
    let span = span.trim();
    // A glob (`crates/*/Cargo.toml`) is a pattern, not a reference: there is nothing for it to
    // resolve to, and treating one as a broken link would push the docs towards writing
    // "each crate's manifest" in prose — strictly worse for a reader.
    if span.contains('*') || span.contains('?') || span.contains("…") || span.contains("...") {
        return false;
    }
    (span.starts_with("docs/") || span.starts_with("crates/") || span.starts_with("scripts/"))
        && (span.ends_with(".md")
            || span.ends_with(".sh")
            || span.ends_with(".toml")
            || span.ends_with(".rs")
            || span.ends_with(".json"))
}

/// Every `docs/…`, `crates/…` or `scripts/…` path cited in a backtick must exist.
///
/// `exists` is injected so the check is pure and unit-testable; the gate passes `Path::new(p).exists()`.
pub fn check_path_references(
    file: &str,
    text: &str,
    exists: impl Fn(&str) -> bool,
) -> Vec<DocIssue> {
    let mut issues = Vec::new();
    for (offset, line) in text.lines().enumerate() {
        for span in code_spans(line) {
            let span = span.trim();
            if !looks_like_doc_path(span) && !looks_like_repo_path(span) {
                continue;
            }
            if !exists(span) {
                issues.push(DocIssue::new(
                    DocIssueKind::BrokenPathReference,
                    file,
                    offset + 1,
                    format!("cites `{span}`, which does not exist"),
                ));
            }
        }
    }
    issues
}

fn crate_name_in_backticks(span: &str) -> Option<String> {
    let span = span.trim();
    let rest = span.strip_prefix("caly-")?;
    if rest.is_empty()
        || !rest
            .chars()
            .all(|ch| ch.is_ascii_lowercase() || ch.is_ascii_digit() || ch == '-')
    {
        return None;
    }
    Some(span.to_owned())
}

/// Crate names used in docs must be real members or be documented as absent.
///
/// `docs/ONBOARDING_NOTES.md §5.3` records the cost of the alternative: `caly-tui` appears in a
/// status table and reads as an existing directory, so a newcomer looks for it. Listing it
/// explicitly is what turns "the docs are wrong" into "the docs say this is planned".
pub fn check_crate_names(file: &str, text: &str, members: &[String]) -> Vec<DocIssue> {
    let mut issues = Vec::new();
    for (offset, line) in text.lines().enumerate() {
        for span in code_spans(line) {
            let Some(name) = crate_name_in_backticks(&span) else {
                continue;
            };
            if members.contains(&name) || DOCUMENTED_NON_MEMBER_CRATES.contains(&name.as_str()) {
                continue;
            }
            issues.push(DocIssue::new(
                DocIssueKind::UnknownCrateName,
                file,
                offset + 1,
                format!("mentions `{name}`, which is not a workspace member and is not listed in `DOCUMENTED_NON_MEMBER_CRATES`"),
            ));
        }
    }
    issues
}

/// Count the `#[test]` attributes in a source file.
///
/// Line-anchored rather than substring-matched: this repo's tests *about* test accounting have to
/// write the token in prose (and in doc examples), and a substring count would then inflate the
/// number the gate is trying to verify. A line whose content begins with `#[test]` is an attribute.
pub fn count_test_attributes(text: &str) -> usize {
    text.lines()
        .filter(|line| line.trim_start().starts_with("#[test]"))
        .count()
}

/// One row of a "file → declared test count" table.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct DeclaredCount {
    pub file: String,
    pub declared: usize,
    pub line: usize,
}

/// Parse a Markdown table of `| path | count | … |` rows, plus the declared total from a
/// `合计 **N**` sentence in the same text.
///
/// This exists because `docs/IMPLEMENTATION_STATUS.md §3.3` writes 「合计 **N**，逐行相加核对一致」—
/// a claim about numbers that is trivially true to write and trivially false to keep. Parsing it is
/// cheaper than another round of finding out by hand that a row went stale.
pub fn parse_test_count_table(text: &str) -> (Vec<DeclaredCount>, Option<usize>) {
    parse_test_count_table_with_lines(text).0
}

/// [`parse_test_count_table`], plus the line the declared total was found on (0 when absent), so a
/// reported arithmetic problem can be pointed at instead of at the file in general.
pub fn parse_test_count_table_with_lines(
    text: &str,
) -> ((Vec<DeclaredCount>, Option<usize>), usize) {
    let mut rows = Vec::new();
    let mut total = None;
    let mut total_line = 0usize;
    for (offset, line) in text.lines().enumerate() {
        if let Some(caps) = line.match_total_marker() {
            if total.is_none() {
                total = Some(caps);
                total_line = offset + 1;
            }
            continue;
        }
        let Some((path, count)) = line.table_row_with_count() else {
            continue;
        };
        rows.push(DeclaredCount {
            file: path,
            declared: count,
            line: offset + 1,
        });
    }
    ((rows, total), total_line)
}

trait DocLine {
    fn match_total_marker(&self) -> Option<usize>;
    fn table_row_with_count(&self) -> Option<(String, usize)>;
}

impl DocLine for &str {
    /// `合计 **226**` (with or without spacing/markdown noise).
    fn match_total_marker(&self) -> Option<usize> {
        let at = self.find("合计")? + "合计".len();
        let rest = self[at..].trim_start();
        let rest = rest.trim_start_matches('*').trim_start();
        let digits: String = rest.chars().take_while(|ch| ch.is_ascii_digit()).collect();
        digits.parse().ok()
    }

    /// `| `crates/x/tests/y.rs` | 8 | … |` → `("crates/x/tests/y.rs", 8)`.
    ///
    /// A cell may list two files joined by `+`; each is emitted as its own row with its own count,
    /// which is exactly how the document groups sibling files (`fs_store.rs` + `fs_store_on_real_disk.rs`).
    fn table_row_with_count(&self) -> Option<(String, usize)> {
        let cells = table_cells(self.trim())?;
        if cells.len() < 2 {
            return None;
        }
        let path_cell = cells.first()?;
        let count_cell = cells.get(1)?;
        if path_cell.starts_with("---")
            || path_cell.contains("测试位置")
            || count_cell.contains("数量")
        {
            return None;
        }
        let count: usize = count_cell
            .chars()
            .take_while(|ch| ch.is_ascii_digit())
            .collect::<String>()
            .parse()
            .ok()?;
        let path = path_cell
            .split('+')
            .next()?
            .trim()
            .trim_matches('`')
            .trim_start_matches('`')
            .to_owned();
        // A row may decorate the path (`crates/x/src/y.rs`（单元）), so the reference is the leading
        // run of path characters and nothing else — otherwise the annotation becomes part of the
        // filename and every annotated row looks like a missing file.
        let path: String = path
            .chars()
            .take_while(|ch| ch.is_alphanumeric() || matches!(ch, '_' | '-' | '.' | '/'))
            .collect();
        if !path.contains(".rs") {
            return None;
        }
        Some((path, count))
    }
}

/// Compare a parsed table against the real tree.
///
/// `actual` maps a path to its `#[test]` count, or `None` when the file does not exist. Injecting it
/// keeps this pure: the unit test passes a map, the gate passes the filesystem.
pub fn check_test_count_claims(
    file: &str,
    text: &str,
    actual: impl Fn(&str) -> Option<usize>,
) -> Vec<DocIssue> {
    let ((rows, total), total_line) = parse_test_count_table_with_lines(text);
    let mut issues = Vec::new();
    let mut sum = 0usize;
    let _seen: Vec<String> = Vec::new();
    for row in &rows {
        sum += row.declared;
        match actual(&row.file) {
            None => issues.push(DocIssue::new(
                DocIssueKind::BrokenPathReference,
                file,
                row.line,
                format!("row cites `{}`, which is not in the tree", row.file),
            )),
            Some(found) if found != row.declared => issues.push(DocIssue::new(
                DocIssueKind::StaleCount,
                file,
                row.line,
                format!(
                    "`{}` is declared as holding {} test(s); the file holds {found}",
                    row.file, row.declared
                ),
            )),
            Some(_) => {}
        }
    }
    if let Some(declared_total) = total {
        if declared_total != sum {
            issues.push(DocIssue::new(
                DocIssueKind::StaleCount,
                file,
                total_line,
                format!(
                    "the section declares a total of {declared_total} on line {total_line}; its rows sum to {sum}"
                ),
            ));
        }
    }
    issues
}

/// Rows the document forgot: a file with tests that has no row is a silent undercount.
pub fn check_unlisted_test_files(
    file: &str,
    text: &str,
    files_with_tests: &[String],
) -> Vec<DocIssue> {
    let (rows, _) = parse_test_count_table(text);
    let mut issues = Vec::new();
    for path in files_with_tests {
        let named = rows
            .iter()
            .any(|row| row.file.ends_with(path) || path.ends_with(&row.file));
        if !named {
            issues.push(DocIssue::new(
                DocIssueKind::StaleCount,
                file,
                0,
                format!("`{path}` contains `#[test]`s but has no row in the table"),
            ));
        }
    }
    issues
}

/// Run every pure check over one file.
pub fn check_document(file: &str, text: &str, members: &[String]) -> Vec<DocIssue> {
    let mut issues = check_markdown_tables(file, text);
    issues.extend(check_list_numbering(file, text));
    issues.extend(check_heading_numbers(file, text));
    issues.extend(check_crate_names(file, text, members));
    issues
}

#[cfg(test)]
mod tests {
    use super::*;

    fn lines(issues: &[DocIssue]) -> Vec<usize> {
        issues.iter().map(|issue| issue.line).collect()
    }

    /// The counting rule itself, pinned: `| a | b | c |` is three columns, and both the leading and
    /// the trailing pipe are delimiters rather than cells. Without this the checker reports every
    /// table as one column short and starts inventing defects.
    #[test]
    fn column_counting_treats_the_edge_pipes_as_delimiters() {
        assert_eq!(table_cells("| a | b | c |").unwrap().len(), 3);
        assert_eq!(table_cells("| a |").unwrap().len(), 1);
        assert_eq!(table_cells("| `x | y` | b |").unwrap().len(), 2);
        assert_eq!(table_cells(r"| a \| b | c |").unwrap().len(), 2);
        // A code span ending in a backslash must not swallow its closing delimiter: the escape
        // rule does not reach inside code spans (`ADR-041`'s disposition row quotes `\`).
        assert_eq!(table_cells("| `a \\` | b | c |").unwrap().len(), 3);
        assert!(table_cells("not a row").is_none());
    }

    #[test]
    fn a_rectangular_table_passes_and_a_short_row_does_not() {
        let good = "| a | b |\n|---|---|\n| 1 | 2 |\n";
        assert!(check_markdown_tables("t.md", good).is_empty());

        let bad = "| a | b |\n|---|---|\n| 1 |\n";
        let issues = check_markdown_tables("t.md", bad);
        assert_eq!(issues.len(), 1, "{issues:?}");
        assert_eq!(lines(&issues), vec![3]);
        assert_eq!(issues[0].kind, DocIssueKind::TableShape);
    }

    #[test]
    fn escaped_and_coded_pipes_are_not_column_separators() {
        // Exactly the shape this repo's docs use when quoting a grep pipeline in a table cell.
        let text = "| rule | command |\n|---|---|\n| redaction | `grep -rn 'redact\\|Redact\\|Secret' crates --include='*.rs'` |\n";
        assert!(
            check_markdown_tables("t.md", text).is_empty(),
            "{:?}",
            check_markdown_tables("t.md", text)
        );
    }

    #[test]
    fn a_table_without_a_separator_row_is_reported() {
        let text = "| a | b |\n| 1 | 2 |\n";
        let issues = check_markdown_tables("t.md", text);
        assert_eq!(lines(&issues), vec![1], "{issues:?}");
    }

    #[test]
    fn numbering_must_count_up_but_a_restarted_list_is_fine() {
        assert!(check_list_numbering("t.md", "1. a\n2. b\n3. c\n").is_empty());
        let issues = check_list_numbering("t.md", "1. a\n3. b\n");
        assert_eq!(lines(&issues), vec![2], "{issues:?}");
        // two separate lists, the way `docs/README.md` stacks them
        assert!(check_list_numbering("t.md", "1. a\n2. b\n\ntext\n\n1. c\n2. d\n").is_empty());
    }

    #[test]
    fn a_duplicated_section_number_is_caught() {
        let text = "## 6. Results\n\n### 6.10 one\n\n### 6.10 two\n";
        let issues = check_heading_numbers("t.md", text);
        assert_eq!(lines(&issues), vec![5], "{issues:?}");
        assert_eq!(issues[0].kind, DocIssueKind::DuplicateHeadingNumber);
        // unnumbered headings are nobody's citation target
        assert!(check_heading_numbers("t.md", "## Notes\n\n## Notes\n").is_empty());
        // `3.` and `3` must collide rather than hide
        let same = "### 3 x\n\n### 3. y\n";
        assert_eq!(check_heading_numbers("t.md", same).len(), 1);
    }

    #[test]
    fn path_references_are_checked_through_an_injected_predicate() {
        let text = "see `docs/exists.md` and `docs/missing.md` and `crates/x/src/y.rs`\n";
        let issues = check_path_references("t.md", text, |path| {
            path == "docs/exists.md" || path == "crates/x/src/y.rs"
        });
        assert_eq!(lines(&issues), vec![1], "{issues:?}");
        assert!(
            issues[0].detail.contains("docs/missing.md"),
            "{}",
            issues[0].detail
        );
    }

    fn table_text() -> &'static str {
        "按文件实测（合计 **3**）：\n\n| 测试位置 | 数量 | 覆盖 |\n|---|---|---|\n| `a/tests/x.rs` | 2 | … |\n| `a/tests/y.rs` | 1 | … |\n"
    }

    #[test]
    fn a_row_annotation_does_not_become_part_of_the_path() {
        let annotated = "按文件实测（合计 **2**）：\n\n| 测试位置 | 数量 | 覆盖 |\n|---|---|---|\n| `a/tests/x.rs`（单元） | 1 | … |\n| `a/tests/y.rs` | 1 | … |\n";
        let actual = |path: &str| match path {
            "a/tests/x.rs" => Some(1),
            "a/tests/y.rs" => Some(1),
            _ => None,
        };
        assert!(
            check_test_count_claims("STATUS.md", annotated, actual).is_empty(),
            "{:?}",
            check_test_count_claims("STATUS.md", annotated, actual)
        );
    }

    #[test]
    fn declared_test_counts_are_parsed_and_compared() {
        let actual = |path: &str| match path {
            "a/tests/x.rs" => Some(2),
            "a/tests/y.rs" => Some(1),
            _ => None,
        };
        assert!(check_test_count_claims("STATUS.md", table_text(), actual).is_empty());
    }

    #[test]
    fn a_stale_count_and_a_missing_file_are_both_reported() {
        let actual = |path: &str| match path {
            // the file grew since the doc was written
            "a/tests/x.rs" => Some(5),
            _ => None,
        };
        let issues = check_test_count_claims("STATUS.md", table_text(), actual);
        assert_eq!(issues.len(), 2, "{issues:?}");
        assert_eq!(issues[0].kind, DocIssueKind::StaleCount);
        assert!(issues[0].detail.contains("holds 5"), "{}", issues[0].detail);
        assert_eq!(issues[1].kind, DocIssueKind::BrokenPathReference);
    }

    #[test]
    fn a_declared_total_must_equal_the_sum_of_its_rows() {
        let actual = |path: &str| match path {
            "a/tests/x.rs" => Some(2),
            "a/tests/y.rs" => Some(1),
            _ => None,
        };
        // rows and files agree, so the only possible complaint is the heading's arithmetic
        let stale_total = table_text().replace("合计 **3**", "合计 **4**");
        let issues = check_test_count_claims("STATUS.md", &stale_total, actual);
        assert_eq!(issues.len(), 1, "{issues:?}");
        assert!(
            issues[0].detail.contains("declares a total of 4")
                && issues[0].detail.contains("sum to 3"),
            "{:?}",
            issues[0]
        );
        // and with the arithmetic right, the same table passes
        assert!(check_test_count_claims("STATUS.md", table_text(), actual).is_empty());
    }

    #[test]
    fn a_file_with_tests_but_no_row_is_caught() {
        let issues =
            check_unlisted_test_files("STATUS.md", table_text(), &["b/tests/z.rs".to_owned()]);
        assert_eq!(issues.len(), 1, "{issues:?}");
        assert!(issues[0].detail.contains("no row"), "{:?}", issues[0]);
        assert!(
            check_unlisted_test_files("STATUS.md", table_text(), &["a/tests/x.rs".to_owned()])
                .is_empty()
        );
    }

    #[test]
    fn a_glob_is_a_pattern_not_a_reference() {
        let text = "reads `crates/*/Cargo.toml` and also `docs/…/x.md`\n";
        assert!(
            check_path_references("t.md", text, |_| false).is_empty(),
            "a wildcard citation must not be reported as a broken link"
        );
    }

    /// The gate is only worth having if all three failures are its own cases, so each is shown -- and the
    /// fourth case is the one that would make this check a nuisance: a round paragraph that mentions its
    /// own assertion count must not be read as the closing claim.
    #[test]
    fn a_stale_round_claim_and_its_two_evasion_paths_are_all_reported() {
        let good = "判据是“这 499 个断言是否依然成立”（且第十五轮起，
";
        assert!(check_round_claim("centerline.md", good, 499).is_empty());

        let stale = check_round_claim("centerline.md", good, 500);
        assert_eq!(stale.len(), 1, "{stale:?}");
        assert!(stale[0].detail.contains("claims 499"), "{:?}", stale[0]);

        let gone = check_round_claim(
            "centerline.md",
            "no numbers here
",
            499,
        );
        assert_eq!(gone.len(), 1, "{gone:?}");
        assert!(gone[0].detail.contains("is gone"), "{:?}", gone[0]);

        let doubled = "判据是“这 499 个断言是否依然成立”
判据是“这 499 个断言是否依然成立”
";
        let issues = check_round_claim("centerline.md", doubled, 499);
        assert_eq!(issues.len(), 1, "{issues:?}");
        assert!(
            issues[0].detail.contains("appears 2 times"),
            "{:?}",
            issues[0]
        );

        let prose = "第三十轮补充：新增 14 个断言，全咬住。
判据是“这 499 个断言是否依然成立”
";
        assert!(
            check_round_claim("centerline.md", prose, 499).is_empty(),
            "a round paragraph's own count is prose, not the claim under test"
        );
    }

    /// The index check has two directions, and each is demonstrated on the failure it exists for.
    /// The case two consecutive rounds produced: a newline left inside the row's middle cell. Nothing
    /// else in the suite notices -- the split row still *starts* with `| 6.N |`, and the adjacency rule
    /// reports it as a "blank line", which sends the reader hunting for the wrong defect.
    #[test]
    fn a_disposition_row_split_across_lines_is_reported() {
        let split =
            "| 6.1 | first half\nsecond half | refs |\n| 6.2 | second | x |\n\n### 6.3 明确**不做**的项\n";
        let issues = check_disposition_ledger("notes.md", split);
        assert_eq!(issues.len(), 1, "{issues:?}");
        assert!(
            issues[0].detail.contains("does not end with `|`"),
            "{:?}",
            issues[0]
        );

        let whole =
            "| 6.1 | first half | refs |\n| 6.2 | second | x |\n\n### 6.3 明确**不做**的项\n";
        assert!(check_disposition_ledger("notes.md", whole).is_empty());
    }

    #[test]
    fn the_document_index_is_checked_in_both_directions() {
        let index = "```text\ndocs/\n\u{251c}\u{2500}\u{2500} README.md\n\u{251c}\u{2500}\u{2500} ROADMAP.md\n\u{2514}\u{2500}\u{2500} rfcs/\n```\n";
        let present = || vec!["README.md".to_owned(), "ROADMAP.md".to_owned()];
        assert!(check_doc_index("README.md", index, &present()).is_empty());

        let added = vec![
            "README.md".to_owned(),
            "ROADMAP.md".to_owned(),
            "PLAYBOOK.md".to_owned(),
        ];
        let issues = check_doc_index("README.md", index, &added);
        assert_eq!(issues.len(), 1, "{issues:?}");
        assert!(
            issues[0].detail.contains("PLAYBOOK.md")
                && issues[0].detail.contains("does not list it"),
            "{:?}",
            issues[0]
        );

        let removed = vec!["README.md".to_owned()];
        let issues = check_doc_index("README.md", index, &removed);
        assert_eq!(issues.len(), 1, "{issues:?}");
        assert!(
            issues[0]
                .detail
                .contains("`docs/ROADMAP.md`, which is not in the tree"),
            "{:?}",
            issues[0]
        );

        // The clean case above already proves directories are skipped: the index lists `rfcs/`, and if
        // the filter let it through, the "index names a missing document" arm would have fired there.
    }

    #[test]
    fn a_gap_in_the_disposition_ledger_is_reported() {
        let text = "| 6.1 | first | x |\n| 6.3 | third | y |\n\n### 6.4 明确**不做**的项\n";
        let issues = check_disposition_ledger("notes.md", text);
        assert_eq!(issues.len(), 1, "{issues:?}");
        assert_eq!(issues[0].kind, DocIssueKind::LedgerNumbering);
        assert!(issues[0].detail.contains("jumps over 2"), "{:?}", issues[0]);
    }

    /// The shape this round actually produced: a splice left one blank line between two rows. Every
    /// numbering check still passed, because they read rows in order and never ask whether the table is
    /// still open -- and a single orphan row does not look like a table to the shape check either.
    #[test]
    fn a_ledger_row_separated_by_a_blank_line_is_reported() {
        let broken = "| 6.1 | first | x |\n\n| 6.2 | second | y |\n\n### 6.3 明确**不做**的项\n";
        let issues = check_disposition_ledger("notes.md", broken);
        assert_eq!(issues.len(), 1, "{issues:?}");
        assert!(
            issues[0]
                .detail
                .contains("separated from the row above by a blank line"),
            "{:?}",
            issues[0]
        );

        let fine = "| 6.1 | first | x |\n| 6.2 | second | y |\n\n### 6.3 明确**不做**的项\n";
        assert!(check_disposition_ledger("notes.md", fine).is_empty());
    }

    #[test]
    fn the_not_doing_heading_has_to_be_the_next_number() {
        // This is the exact slip the gate exists for: a row was extended instead of added, and the
        // heading was bumped anyway -- both shapes are legal markdown, only the numbering is wrong.
        let text = "| 6.1 | first | x |\n| 6.2 | second | y |\n\n### 6.4 明确**不做**的项\n";
        let issues = check_disposition_ledger("notes.md", text);
        assert_eq!(issues.len(), 1, "{issues:?}");
        assert!(
            issues[0].detail.contains("last ledger row is 6.2"),
            "{:?}",
            issues[0]
        );

        let fine = "| 6.1 | first | x |\n| 6.2 | second | y |\n\n### 6.3 明确**不做**的项\n";
        assert!(check_disposition_ledger("notes.md", fine).is_empty());
    }

    #[test]
    fn a_quoted_row_inside_a_fence_is_not_part_of_the_ledger() {
        // `§4.89` recorded a repair script that ate prose because a code span quoted a row shape; the
        // same trap aimed at this check is fenced examples, so they are skipped outright.
        let text = "```markdown\n| 6.7 | example of the shape | x |\n```\n\n| 6.1 | real | y |\n\n### 6.2 明确**不做**的项\n";
        assert!(check_disposition_ledger("notes.md", text).is_empty());
    }

    #[test]
    fn a_row_glued_to_a_paragraph_is_reported() {
        let text = "some prose about the round. | 6.42 | did the thing | 4.68 |\n\n### 6.43 next";
        let issues = check_stray_table_rows("notes.md", text);
        assert_eq!(issues.len(), 1, "{issues:?}");
        assert_eq!(issues[0].line, 1);
        assert_eq!(issues[0].kind, DocIssueKind::StrayTableRow);
    }

    #[test]
    fn a_row_glued_without_a_space_and_flush_with_the_line_end_is_reported() {
        // The shape that actually happened in `docs/ONBOARDING_NOTES.md`: a disposition row was
        // appended to the tail of a blockquote line, with no space before its first pipe, so its
        // last cell closed on the very last character of the line. The rule that counted `" | "`
        // separators saw two and reported nothing -- which means the gate written for this exact
        // failure could not see the failure. A pipe is a cell boundary whether or not anyone
        // spaced it, so the count is now over pipes, not over spaced pipes.
        let text = "> prose about the ledger。| 6.51 | the fix | 4.89 |\n";
        let issues = check_stray_table_rows("notes.md", text);
        assert_eq!(issues.len(), 1, "{issues:?}");
        assert_eq!(issues[0].line, 1);
        assert_eq!(issues[0].kind, DocIssueKind::StrayTableRow);
    }

    #[test]
    fn a_real_table_row_and_prose_with_one_pipe_are_not_reported() {
        // The row on its own line is the shape that must stay legal, and prose quoting a shell
        // alternation must not become a finding -- that is why the rule counts three separators
        // rather than one.
        let text = "| 6.42 | did the thing | 4.68 |\n\ngrep -rn std::fs | std::process crates/\n";
        assert!(check_stray_table_rows("notes.md", text).is_empty());
        let fenced = "```text\nprose | a | b |\n```\n";
        assert!(
            check_stray_table_rows("notes.md", fenced).is_empty(),
            "inside a fence, the shape of a line means nothing"
        );
    }

    #[test]
    fn crate_names_must_be_members_or_documented_as_absent() {
        let members = vec!["caly-engine".to_owned(), "caly-io-std".to_owned()];
        let text = "in `caly-engine`, in `caly-tui` (planned), in `caly-nonexistent`\n";
        let issues = check_crate_names("t.md", text, &members);
        assert_eq!(issues.len(), 1, "{issues:?}");
        assert!(
            issues[0].detail.contains("caly-nonexistent"),
            "{:?}",
            issues[0]
        );
    }
}
