#![forbid(unsafe_code)]

pub mod docs;

#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub struct DependencyEdge {
    pub from: &'static str,
    pub to: &'static str,
}

#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub enum ViolationKind {
    ForbiddenDependency,
    MissingAllowedEdge,
    ForbiddenType,
    ForbiddenMethod,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct Violation {
    pub kind: ViolationKind,
    pub crate_name: String,
    pub detail: String,
}

#[derive(Clone, Debug, Default, Eq, PartialEq)]
pub struct ArchReport {
    pub violations: Vec<Violation>,
}

impl ArchReport {
    pub fn is_clean(&self) -> bool {
        self.violations.is_empty()
    }
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct CrateMeta {
    pub name: String,
    pub dependencies: Vec<String>,
}

#[derive(Clone, Debug, Default, Eq, PartialEq)]
pub struct WorkspaceMeta {
    pub crates: Vec<CrateMeta>,
}

pub const PURE_CORE_CRATES: &[&str] = &[
    "caly-domain",
    "caly-ir",
    "caly-pipeline",
    "caly-cap",
    "caly-plan",
];

pub const IO_FORBIDDEN_TYPES: &[&str] = &[
    "std::fs::File",
    "std::path::PathBuf",
    "std::process::Command",
];

pub const IO_FORBIDDEN_METHODS: &[&str] = &[
    "std::time::SystemTime::now",
    "std::time::Instant::now",
    "std::process::Command::new",
];

pub const WORKSPACE_TARGET_CRATES: &[&str] = &[
    "caly-api",
    "caly-app",
    "caly-arch-test",
    "caly-cap",
    "caly-cli",
    "caly-common",
    "caly-core",
    "caly-daemon",
    "caly-domain",
    "caly-engine",
    "caly-io",
    "caly-io-std",
    "caly-io-sim",
    "caly-ipc",
    "caly-ir",
    "caly-mihomo",
    "caly-pipeline",
    "caly-plan",
    "caly-singbox",
    "caly-storage",
];

/// Edges that are known architecture debt rather than approved structure.
///
/// `caly-engine` should reach core adapters through the `caly_core::CoreAdapter` trait, not
/// depend on `caly-mihomo` / `caly-singbox` concretely (`adapter_for_target` in
/// `caly-engine/src/apply.rs` matches on the target and news up a concrete adapter). The debt
/// is declared here so the ratchet test fails on any *new* undeclared edge, while these two
/// stay visible instead of being quietly allow-listed.
pub const KNOWN_ARCH_DEBT: &[DependencyEdge] = &[
    DependencyEdge {
        from: "caly-engine",
        to: "caly-mihomo",
    },
    DependencyEdge {
        from: "caly-engine",
        to: "caly-singbox",
    },
];

/// Development-only edges (tests / benches). Kept separate so a test-only dependency on the
/// simulation crate is not mistaken for a production edge.
pub const ALLOWED_DEV_DEPENDENCY_EDGES: &[DependencyEdge] = &[
    // Simulation is a development-only facility by design (ADR-022), so a crate may depend on
    // it from [dev-dependencies] without widening its production edge set.
    DependencyEdge {
        from: "caly-engine",
        to: "caly-io-sim",
    },
    DependencyEdge {
        from: "caly-storage",
        to: "caly-io-sim",
    },
    // Development-only, so the durable backend can be exercised against the production port
    // adapter as well as the simulator. It must never become a production edge: storage reaches
    // the host only through `dyn Fs`, which the gateway *or* the simulator can fill.
    DependencyEdge {
        from: "caly-storage",
        to: "caly-io-std",
    },
    DependencyEdge {
        from: "caly-daemon",
        to: "caly-io",
    },
    // Test-only: the daemon receives its backend injected, so composing `FsStore` over `StdFs`
    // belongs to the caller (here, the test). This edge must never move into [dependencies].
    DependencyEdge {
        from: "caly-daemon",
        to: "caly-io-std",
    },
];

pub const ALLOWED_DEPENDENCY_EDGES: &[DependencyEdge] = &[
    // Declared in the manifests before this guardrail ran for the first time; each of these
    // directions is consistent with RFC-0001 (leaf data crates may consume caly-common,
    // adapters may consume the pipeline/domain layers they project from, and the daemon is a
    // legitimate consumer of the storage facade for recovery scans).
    DependencyEdge {
        from: "caly-cli",
        to: "caly-common",
    },
    DependencyEdge {
        from: "caly-daemon",
        to: "caly-storage",
    },
    // Round 43, `calyd`: the bin target inside caly-daemon is the workspace's composition root —
    // the one place that constructs real port adapters (`StdFs`, `StdClock`) and hands them to a
    // daemon that still takes its backend injected (`ADR-011` unchanged for the lib). Naming the
    // port traits (`caly_io::Fs`) and the adapters (`caly-io-std`) there is that role, not a
    // new architectural direction: no host contact exists outside the bin and the tests.
    DependencyEdge {
        from: "caly-daemon",
        to: "caly-io",
    },
    DependencyEdge {
        from: "caly-daemon",
        to: "caly-io-std",
    },
    DependencyEdge {
        from: "caly-engine",
        to: "caly-cap",
    },
    DependencyEdge {
        from: "caly-ir",
        to: "caly-common",
    },
    DependencyEdge {
        from: "caly-mihomo",
        to: "caly-domain",
    },
    DependencyEdge {
        from: "caly-mihomo",
        to: "caly-pipeline",
    },
    DependencyEdge {
        from: "caly-singbox",
        to: "caly-domain",
    },
    DependencyEdge {
        from: "caly-singbox",
        to: "caly-pipeline",
    },
    DependencyEdge {
        from: "caly-api",
        to: "caly-common",
    },
    DependencyEdge {
        from: "caly-app",
        to: "caly-api",
    },
    DependencyEdge {
        from: "caly-app",
        to: "caly-common",
    },
    DependencyEdge {
        from: "caly-app",
        to: "caly-daemon",
    },
    DependencyEdge {
        from: "caly-app",
        to: "caly-ipc",
    },
    DependencyEdge {
        from: "caly-cli",
        to: "caly-api",
    },
    DependencyEdge {
        from: "caly-cli",
        to: "caly-app",
    },
    DependencyEdge {
        from: "caly-cli",
        to: "caly-ipc",
    },
    DependencyEdge {
        from: "caly-core",
        to: "caly-cap",
    },
    DependencyEdge {
        from: "caly-core",
        to: "caly-ir",
    },
    DependencyEdge {
        from: "caly-core",
        to: "caly-plan",
    },
    DependencyEdge {
        from: "caly-daemon",
        to: "caly-api",
    },
    DependencyEdge {
        from: "caly-daemon",
        to: "caly-common",
    },
    DependencyEdge {
        from: "caly-daemon",
        to: "caly-engine",
    },
    DependencyEdge {
        from: "caly-daemon",
        to: "caly-ipc",
    },
    DependencyEdge {
        from: "caly-domain",
        to: "caly-ir",
    },
    DependencyEdge {
        from: "caly-engine",
        to: "caly-api",
    },
    DependencyEdge {
        from: "caly-engine",
        to: "caly-common",
    },
    DependencyEdge {
        from: "caly-engine",
        to: "caly-core",
    },
    DependencyEdge {
        from: "caly-engine",
        to: "caly-domain",
    },
    DependencyEdge {
        from: "caly-engine",
        to: "caly-ir",
    },
    DependencyEdge {
        from: "caly-engine",
        to: "caly-pipeline",
    },
    DependencyEdge {
        from: "caly-engine",
        to: "caly-plan",
    },
    // Only to reach the shared future driver (caly_io::block_on_ready), so the engine's
    // "poll once, require ready" rule lives in one place instead of three. It is not a licence
    // to do IO from the engine: the ports themselves stay behind caly-io-std / caly-io-sim.
    DependencyEdge {
        from: "caly-engine",
        to: "caly-io",
    },
    DependencyEdge {
        from: "caly-engine",
        to: "caly-storage",
    },
    // Storage may use the shared context types and must reach the world only through the port
    // layer (ADR-011): `FsStore` therefore depends on `caly-io` and on `caly-common`'s digest,
    // and contains no `std::fs` of its own.
    DependencyEdge {
        from: "caly-storage",
        to: "caly-common",
    },
    DependencyEdge {
        from: "caly-storage",
        to: "caly-io",
    },
    DependencyEdge {
        from: "caly-io",
        to: "caly-common",
    },
    // The production port adapter depends on the ports and on nothing else, which is the point:
    // it is the only crate allowed to touch host files and the host clock (see its `clippy.toml`).
    DependencyEdge {
        from: "caly-io-std",
        to: "caly-io",
    },
    DependencyEdge {
        from: "caly-io-sim",
        to: "caly-io",
    },
    DependencyEdge {
        from: "caly-ipc",
        to: "caly-api",
    },
    DependencyEdge {
        from: "caly-mihomo",
        to: "caly-cap",
    },
    DependencyEdge {
        from: "caly-mihomo",
        to: "caly-core",
    },
    DependencyEdge {
        from: "caly-mihomo",
        to: "caly-ir",
    },
    DependencyEdge {
        from: "caly-mihomo",
        to: "caly-plan",
    },
    DependencyEdge {
        from: "caly-pipeline",
        to: "caly-cap",
    },
    DependencyEdge {
        from: "caly-pipeline",
        to: "caly-core",
    },
    DependencyEdge {
        from: "caly-pipeline",
        to: "caly-domain",
    },
    DependencyEdge {
        from: "caly-pipeline",
        to: "caly-ir",
    },
    DependencyEdge {
        from: "caly-pipeline",
        to: "caly-plan",
    },
    DependencyEdge {
        from: "caly-singbox",
        to: "caly-cap",
    },
    DependencyEdge {
        from: "caly-singbox",
        to: "caly-core",
    },
    DependencyEdge {
        from: "caly-singbox",
        to: "caly-ir",
    },
    DependencyEdge {
        from: "caly-singbox",
        to: "caly-plan",
    },
    // `caly-storage` deliberately owns no `caly-plan` types: it persists opaque digests and
    // journal records, not plans. The edge used to be listed here after the manifest edge was
    // removed, which made the allow-list a wish list rather than a mirror of reality.
];

pub fn is_pure_core(crate_name: &str) -> bool {
    PURE_CORE_CRATES.contains(&crate_name)
}

pub fn check_dependency_edges(meta: &WorkspaceMeta) -> ArchReport {
    let mut report = ArchReport::default();

    for krate in &meta.crates {
        if !WORKSPACE_TARGET_CRATES
            .iter()
            .any(|name| *name == krate.name)
        {
            continue;
        }

        for dependency in &krate.dependencies {
            let allowed = ALLOWED_DEPENDENCY_EDGES
                .iter()
                .any(|edge| edge.from == krate.name && edge.to == dependency);

            if !allowed {
                report.violations.push(Violation {
                    kind: ViolationKind::ForbiddenDependency,
                    crate_name: krate.name.clone(),
                    detail: format!("{} -> {} is not in the allow-list", krate.name, dependency),
                });
            }
        }
    }

    report
}

pub fn check_forbidden_symbol_usage(
    crate_name: &str,
    referenced_types: &[&str],
    referenced_methods: &[&str],
) -> ArchReport {
    let mut report = ArchReport::default();

    if !is_pure_core(crate_name) {
        return report;
    }

    for ty in referenced_types {
        if IO_FORBIDDEN_TYPES.contains(ty) {
            report.violations.push(Violation {
                kind: ViolationKind::ForbiddenType,
                crate_name: crate_name.to_owned(),
                detail: (*ty).to_owned(),
            });
        }
    }

    for method in referenced_methods {
        if IO_FORBIDDEN_METHODS.contains(method) {
            report.violations.push(Violation {
                kind: ViolationKind::ForbiddenMethod,
                crate_name: crate_name.to_owned(),
                detail: (*method).to_owned(),
            });
        }
    }

    report
}

// ---------------------------------------------------------------------------
// Manifest parsing
//
// The guardrail above is only useful if something feeds it the real workspace.
// These helpers read `Cargo.toml` text without any external dependency, so the
// dependency-direction invariant can actually be asserted in a test.
// ---------------------------------------------------------------------------

#[derive(Clone, Debug, Default, Eq, PartialEq)]
pub struct CargoManifest {
    pub name: String,
    pub dependencies: Vec<String>,
    pub dev_dependencies: Vec<String>,
}

/// Minimal `Cargo.toml` reader for the subset Caly uses.
///
/// It understands `[package] name`, and the crate-name keys inside
/// `[dependencies]` / `[dev-dependencies]` only. Anything else is ignored on purpose:
/// this exists to police internal edges, not to validate manifests.
pub fn parse_cargo_manifest(raw: &str) -> CargoManifest {
    let mut manifest = CargoManifest::default();
    let mut section = String::new();

    for line in raw.lines() {
        let line = line.trim();
        if line.is_empty() || line.starts_with('#') {
            continue;
        }
        if let Some(header) = line
            .strip_prefix('[')
            .and_then(|rest| rest.strip_suffix(']'))
        {
            section = header.trim().to_owned();
            continue;
        }
        let Some((key, _value)) = line.split_once('=') else {
            continue;
        };
        let key = key.trim();
        match section.as_str() {
            "package" => {
                if key == "name" {
                    manifest.name = unquote(_value.trim());
                }
            }
            "dependencies" => {
                if let Some(name) = caly_dependency_name(key) {
                    manifest.dependencies.push(name.to_owned());
                }
            }
            "dev-dependencies" => {
                if let Some(name) = caly_dependency_name(key) {
                    manifest.dev_dependencies.push(name.to_owned());
                }
            }
            _ => {}
        }
    }

    manifest.dependencies.sort();
    manifest.dependencies.dedup();
    manifest.dev_dependencies.sort();
    manifest.dev_dependencies.dedup();
    manifest
}

fn caly_dependency_name(key: &str) -> Option<&str> {
    key.strip_prefix("caly-").map(|_| key)
}

fn unquote(value: &str) -> String {
    value.trim().trim_matches('"').trim_matches('\'').to_owned()
}

/// Build the workspace view from already-read manifests, keyed by directory name.
pub fn workspace_meta_from_manifests(entries: &[(String, String)]) -> WorkspaceMeta {
    let mut crates: Vec<CrateMeta> = entries
        .iter()
        .map(|(_dir, raw)| {
            let manifest = parse_cargo_manifest(raw);
            CrateMeta {
                name: if manifest.name.is_empty() {
                    _dir.clone()
                } else {
                    manifest.name
                },
                dependencies: manifest.dependencies,
            }
        })
        .collect();
    crates.sort_by(|left, right| left.name.cmp(&right.name));
    WorkspaceMeta { crates }
}

pub fn manifest_dependency_edges(entries: &[(String, String)]) -> Vec<(String, String)> {
    let mut edges = Vec::new();
    for (dir, raw) in entries {
        let manifest = parse_cargo_manifest(raw);
        let from = if manifest.name.is_empty() {
            dir.clone()
        } else {
            manifest.name
        };
        for to in manifest.dependencies {
            edges.push((from.clone(), to));
        }
    }
    edges.sort();
    edges.dedup();
    edges
}

pub fn dev_dependency_edges(entries: &[(String, String)]) -> Vec<(String, String)> {
    let mut edges = Vec::new();
    for (dir, raw) in entries {
        let manifest = parse_cargo_manifest(raw);
        let from = if manifest.name.is_empty() {
            dir.clone()
        } else {
            manifest.name
        };
        for to in manifest.dev_dependencies {
            edges.push((from.clone(), to));
        }
    }
    edges.sort();
    edges.dedup();
    edges
}

/// Report allow-listed edges that no manifest actually declares.
///
/// A stale allow-list is as misleading as a missing one: it advertises a dependency the
/// workspace does not have, so the next reader trusts a structure that no longer exists.
pub fn check_missing_allowed_edges(meta: &WorkspaceMeta) -> ArchReport {
    let mut report = ArchReport::default();
    for edge in ALLOWED_DEPENDENCY_EDGES {
        let declared = meta
            .crates
            .iter()
            .find(|krate| krate.name == edge.from)
            .map(|krate| krate.dependencies.iter().any(|dep| dep == edge.to))
            .unwrap_or(false);
        if !declared {
            report.violations.push(Violation {
                kind: ViolationKind::MissingAllowedEdge,
                crate_name: edge.from.to_owned(),
                detail: format!(
                    "{} -> {} is allow-listed but not declared",
                    edge.from, edge.to
                ),
            });
        }
    }
    report
}

/// True when an undeclared edge is already tracked as known debt.
pub fn is_known_debt(from: &str, to: &str) -> bool {
    KNOWN_ARCH_DEBT
        .iter()
        .any(|edge| edge.from == from && edge.to == to)
}

/// Every edge the workspace may declare: approved structure plus declared debt.
pub fn permitted_edges() -> Vec<(&'static str, &'static str)> {
    let mut edges: Vec<(&'static str, &'static str)> = ALLOWED_DEPENDENCY_EDGES
        .iter()
        .map(|edge| (edge.from, edge.to))
        .collect();
    edges.extend(KNOWN_ARCH_DEBT.iter().map(|edge| (edge.from, edge.to)));
    edges.sort_unstable();
    edges.dedup();
    edges
}
