//! Dependency-direction gate.
//!
//! `caly-arch-test` has long contained `check_dependency_edges`, but nothing ever called it
//! and nothing built a `WorkspaceMeta`, so the invariant "依赖方向" that RFC-0001 states as
//! an architecture rule was unenforced. The first time the real manifests were fed to it, ten
//! production edges were undeclared and one allow-list entry was stale.
//!
//! These tests make that check run on every `cargo test`.

use std::collections::BTreeSet;
use std::path::Path;

use caly_arch_test::{
    check_dependency_edges, check_forbidden_symbol_usage, check_missing_allowed_edges,
    dev_dependency_edges, is_known_debt, manifest_dependency_edges, parse_cargo_manifest,
    permitted_edges, workspace_meta_from_manifests, ALLOWED_DEPENDENCY_EDGES,
    ALLOWED_DEV_DEPENDENCY_EDGES, IO_FORBIDDEN_METHODS, IO_FORBIDDEN_TYPES, KNOWN_ARCH_DEBT,
    PURE_CORE_CRATES, WORKSPACE_TARGET_CRATES,
};

/// The `crates/` directory, as an owned path string.
///
/// Kept as a `String` rather than a `PathBuf` because `clippy.toml` disallows
/// `std::path::PathBuf` workspace-wide, and the guardrail crate should not itself need an
/// `#[allow]` to read manifests.
fn crates_dir() -> String {
    Path::new(env!("CARGO_MANIFEST_DIR"))
        .parent()
        .and_then(Path::parent)
        .expect("workspace root is two levels above a crate directory")
        .join("crates")
        .to_string_lossy()
        .into_owned()
}

/// Read every `crates/*/Cargo.toml`, keyed by directory name, in a deterministic order.
fn read_manifests() -> Vec<(String, String)> {
    let dir = crates_dir();
    let dir = Path::new(&dir);
    let mut entries = Vec::new();
    let read = std::fs::read_dir(dir).expect("crates directory must be readable");
    for entry in read {
        let entry = entry.expect("readable directory entry");
        let path = entry.path();
        if !path.is_dir() {
            continue;
        }
        let name = entry.file_name().to_string_lossy().into_owned();
        let manifest_path = path.join("Cargo.toml");
        if !manifest_path.is_file() {
            continue;
        }
        let raw = std::fs::read_to_string(&manifest_path)
            .unwrap_or_else(|error| panic!("cannot read {name}/Cargo.toml: {error}"));
        entries.push((name, raw));
    }
    entries.sort();
    entries
}

fn edge_set(edges: impl IntoIterator<Item = (String, String)>) -> BTreeSet<String> {
    edges
        .into_iter()
        .map(|(from, to)| format!("{from} -> {to}"))
        .collect()
}

fn permitted_edge_strings() -> BTreeSet<String> {
    permitted_edges()
        .into_iter()
        .map(|(from, to)| format!("{from} -> {to}"))
        .collect()
}

#[test]
fn manifest_parser_reads_package_name_and_dependency_sections() {
    let sample = r#"
[package]
name = "caly-demo"
edition.workspace = true

[lib]
path = "src/lib.rs"

[dependencies]
caly-api = { path = "../caly-api" }
caly-plan = { path = "../caly-plan" }

# external crates are not Caly's internal edges
serde = "1"

[dev-dependencies]
caly-io-sim = { path = "../caly-io-sim" }
"#;
    let manifest = parse_cargo_manifest(sample);
    assert_eq!(manifest.name, "caly-demo");
    assert_eq!(manifest.dependencies, vec!["caly-api", "caly-plan"]);
    assert_eq!(manifest.dev_dependencies, vec!["caly-io-sim"]);
}

#[test]
fn every_workspace_member_is_covered_by_the_guardrail() {
    let declared: BTreeSet<String> = read_manifests().into_iter().map(|(dir, _)| dir).collect();
    let known: BTreeSet<String> = WORKSPACE_TARGET_CRATES
        .iter()
        .map(|name| (*name).to_owned())
        .collect();
    assert_eq!(
        declared, known,
        "a crate was added or removed without updating WORKSPACE_TARGET_CRATES"
    );
}

#[test]
fn no_undeclared_production_dependency_edges() {
    let entries = read_manifests();
    let actual = edge_set(manifest_dependency_edges(&entries));
    let permitted = permitted_edge_strings();

    let violations: Vec<&String> = actual
        .iter()
        .filter(|edge| !permitted.contains(*edge))
        .collect();
    assert!(
        violations.is_empty(),
        "undeclared dependency edges (add them to ALLOWED_DEPENDENCY_EDGES, or remove the \
         manifest dependency, or declare them in KNOWN_ARCH_DEBT with a rationale): {violations:?}"
    );

    // The checker must agree, and must flag *exactly* the declared debt: this is what keeps
    // `check_dependency_edges` itself from rotting into an unused helper.
    let meta = workspace_meta_from_manifests(&entries);
    let report = check_dependency_edges(&meta);
    let reported: BTreeSet<String> = report
        .violations
        .iter()
        .map(|violation| {
            let detail = violation
                .detail
                .trim_end_matches(" is not in the allow-list");
            assert_eq!(
                violation.kind,
                caly_arch_test::ViolationKind::ForbiddenDependency
            );
            detail.to_owned()
        })
        .collect();
    let declared_debt: BTreeSet<String> = KNOWN_ARCH_DEBT
        .iter()
        .map(|edge| format!("{} -> {}", edge.from, edge.to))
        .collect();
    assert_eq!(
        reported, declared_debt,
        "the dependency checker must report exactly the declared debt, nothing more"
    );
}

#[test]
fn no_stale_allow_list_entries() {
    let entries = read_manifests();
    let meta = workspace_meta_from_manifests(&entries);
    let report = check_missing_allowed_edges(&meta);
    assert!(
        report.is_clean(),
        "the allow-list advertises edges the manifests no longer declare: {:?}",
        report.violations
    );

    // Every allow-listed edge must also be a real manifest edge (same fact, checked directly).
    let actual = edge_set(manifest_dependency_edges(&entries));
    let listed: BTreeSet<String> = ALLOWED_DEPENDENCY_EDGES
        .iter()
        .map(|edge| format!("{} -> {}", edge.from, edge.to))
        .collect();
    let stale: Vec<&String> = listed
        .iter()
        .filter(|edge| !actual.contains(*edge))
        .collect();
    assert!(stale.is_empty(), "stale allow-list entries: {stale:?}");
}

/// Ratchet: known debt must stay exactly as declared.
///
/// Adding a `caly-engine -> <concrete adapter>` edge elsewhere, or removing the debt, fails
/// here until the list is updated deliberately.
#[test]
fn adapter_wiring_debt_is_declared_and_bounded() {
    let entries = read_manifests();
    let actual = edge_set(manifest_dependency_edges(&entries));
    let approved: BTreeSet<String> = ALLOWED_DEPENDENCY_EDGES
        .iter()
        .map(|edge| format!("{} -> {}", edge.from, edge.to))
        .collect();

    let undeclared: BTreeSet<String> = actual.difference(&approved).cloned().collect();
    let declared: BTreeSet<String> = KNOWN_ARCH_DEBT
        .iter()
        .map(|edge| format!("{} -> {}", edge.from, edge.to))
        .collect();

    assert_eq!(
        undeclared, declared,
        "undeclared-but-used edges must match KNOWN_ARCH_DEBT exactly; \
         any new edge needs an explicit decision"
    );
    for edge in &declared {
        let (from, to) = edge.split_once(" -> ").expect("edge string");
        assert!(is_known_debt(from, to));
    }
}

#[test]
fn test_only_edges_stay_test_only() {
    let entries = read_manifests();
    let allowed = {
        let mut set = permitted_edge_strings();
        set.extend(
            ALLOWED_DEV_DEPENDENCY_EDGES
                .iter()
                .map(|edge| format!("{} -> {}", edge.from, edge.to)),
        );
        set
    };
    let offenders: Vec<String> = dev_dependency_edges(&entries)
        .into_iter()
        .filter(|(from, to)| {
            let edge = format!("{from} -> {to}");
            !allowed.contains(&edge)
        })
        .map(|(from, to)| format!("{from} -> {to}"))
        .collect();
    assert!(
        offenders.is_empty(),
        "dev-dependencies must be declared in ALLOWED_DEV_DEPENDENCY_EDGES: {offenders:?}"
    );

    // A simulation crate must never become a production edge by accident.
    let production = manifest_dependency_edges(&entries);
    assert!(
        !production.iter().any(|(_from, to)| to == "caly-io-sim"),
        "caly-io-sim must stay out of production dependency edges"
    );
}

/// `ADR-011` / `ADR-013`: the pure core must not touch filesystem, process or wall-clock APIs.
///
/// `clippy.toml` lists the same symbols, but `caly-arch-test` is the place where the rule is
/// stated as an invariant, so this checks the source text of each pure crate directly.
#[test]
fn pure_core_crates_do_not_reference_io_or_wall_clock_symbols() {
    let root = crates_dir();
    let root = Path::new(&root);
    for crate_name in PURE_CORE_CRATES {
        let src = root.join(crate_name).join("src");
        let mut referenced_types: Vec<&str> = Vec::new();
        let mut referenced_methods: Vec<&str> = Vec::new();
        let mut offenders: Vec<String> = Vec::new();

        for source in collect_rust_files(&src) {
            let text = std::fs::read_to_string(&source)
                .unwrap_or_else(|error| panic!("cannot read {source}: {error}"));
            for ty in IO_FORBIDDEN_TYPES {
                if text.contains(*ty) {
                    referenced_types.push(*ty);
                    offenders.push(format!("{source}: type {ty}"));
                }
            }
            for method in IO_FORBIDDEN_METHODS {
                if text.contains(*method) {
                    referenced_methods.push(*method);
                    offenders.push(format!("{source}: method {method}"));
                }
            }
        }

        let report =
            check_forbidden_symbol_usage(crate_name, &referenced_types, &referenced_methods);
        assert!(
            offenders.is_empty() && report.violations.is_empty(),
            "{crate_name} is pure core but references IO/host symbols: {offenders:?}"
        );
    }
}

/// `APPLY_EXECUTION_CENTERLINE.md §6.1` Phase B's pending guard has to be *wired*, not merely
/// available.
///
/// `caly_engine::executor::execute_effect_plan` is the cursor-less entry point: it runs the plan and
/// hands its caller a journal record that the caller may or may not write.
/// `execute_effect_plan_with_cursor` is the one that puts the intent into the store *before* the
/// cutover window opens, which is the only version under which a process that dies mid-window leaves
/// evidence behind. Production code may therefore name only the second; `crates/*/**.rs` under `src/`
/// is the scanned set, with the defining file excluded because its whole job is the delegation.
///
/// Why a text gate rather than a type: making the cursor mandatory on the only public entry point
/// would push `NoCursor` into every simulation harness in the workspace, and the guard's value is
/// precisely that it is invisible to those harnesses. The rule "and nobody may quietly go back" needs
/// a gate, and this is the cheapest one that is not a comment.
#[test]
fn production_code_drives_effect_plans_through_the_cursor_entry_point() {
    let dir = crates_dir();
    let root = Path::new(&dir);
    let mut offenders: Vec<String> = Vec::new();
    for entry in std::fs::read_dir(root).expect("crates directory must be readable") {
        let crate_dir = entry.expect("readable directory entry").path();
        if !crate_dir.is_dir() {
            continue;
        }
        for source in collect_rust_files(&crate_dir.join("src")) {
            if source.ends_with("caly-engine/src/executor.rs") {
                continue;
            }
            let text = std::fs::read_to_string(&source)
                .unwrap_or_else(|error| panic!("cannot read {source}: {error}"));
            for (index, line) in text.lines().enumerate() {
                let code = line.trim_start();
                if code.starts_with("//") {
                    continue;
                }
                if line.contains("execute_effect_plan(") {
                    offenders.push(format!("{source}:{}: {code}", index + 1));
                }
            }
        }
    }
    assert!(
        offenders.is_empty(),
        "an apply path must record the cutover intent before it touches the world \
         (`APPLY_EXECUTION_CENTERLINE.md §6.1` Phase B); use `execute_effect_plan_with_cursor`: \
         {offenders:?}"
    );
}

/// `ADR-036 §2.6`: the durable store drives its ports through the shared budget, in one place.
///
/// A store seam that polls once and calls the result `StorageErrorKind::Internal` is a verdict, not a
/// limit: it says "the store is broken" about a port that is merely not finished yet, and it throws away
/// the one typed signal (`Busy`) that `OVERLOAD_AND_RETRY_MODEL §3.4`/`§6.2` and `doctor`'s pressure
/// tally are built on. `caly-storage::port_drive::drive_port` is the only allowed way to reach a port
/// from inside the crate, and this gate is what keeps a *new* store file from quietly growing its own
/// loop -- the exact drift `caly-io/src/runtime.rs` documents for the era before it existed.
///
/// `audit.rs` is exempt, and the exemption is the point of writing it out: it drives
/// `dyn StorageBackend` futures, whose answers are already typed `StorageError`s, so there is no
/// port-level kind there for it to lose. Adding a file to this list has to come with a sentence like
/// that one, which is a higher price than calling `drive_port`.
#[test]
fn the_durable_store_drives_ports_through_the_shared_budget() {
    const DRIVES_BACKENDS_NOT_PORTS: &[&str] = &["audit.rs"];
    let dir = crates_dir();
    let src = Path::new(&dir).join("caly-storage").join("src");
    let mut offenders: Vec<String> = Vec::new();
    let mut files = 0usize;
    for file in collect_rust_files(&src) {
        let name = Path::new(&file)
            .file_name()
            .and_then(|name| name.to_str())
            .unwrap_or_default()
            .to_owned();
        if DRIVES_BACKENDS_NOT_PORTS.contains(&name.as_str()) {
            continue;
        }
        files += 1;
        let text = std::fs::read_to_string(&file)
            .unwrap_or_else(|error| panic!("cannot read {file}: {error}"));
        for (index, line) in text.lines().enumerate() {
            let code = line.trim_start();
            if code.starts_with("//") {
                continue;
            }
            if line.contains("block_on_ready(") {
                offenders.push(format!("{file}:{}: {code}", index + 1));
            }
        }
    }
    // The anti-vacuity half: a gate that scans nothing must say so out loud.
    assert!(
        files >= 8,
        "the storage scan found only {files} files; the layout moved and this gate stopped meaning \
         anything"
    );
    assert!(
        offenders.is_empty(),
        "`caly-storage` drives a port outside `port_drive::drive_port`: a suspension there loses the \
         driver's kind and reaches the engine as `Internal`. Offenders: {offenders:?}"
    );
}

/// `RFC-0006 §15` asks for one contract suite that **both** port backends pass. A new check added to
/// `caly-io::contract` therefore has to be *called* by every backend that runs the suite at all --
/// otherwise it silently becomes a simulator-only assertion, which is the exact failure mode
/// `ADR-022` warns about (a release gate validating a world the production port does not implement).
///
/// The rule is stated as: any test file that calls `fs_contract_violations` must also call
/// `fs_byte_budget_violations`. A backend that opts out of the budget check has to delete the base-suite
/// call too, which is a visible and arguable change rather than a forgotten line.
#[test]
fn every_backend_that_runs_the_fs_suite_runs_the_byte_budget_check_too() {
    let dir = crates_dir();
    let mut found = 0usize;
    let mut offenders: Vec<String> = Vec::new();
    for crate_name in ["caly-io-std", "caly-io-sim"] {
        let tests = Path::new(&dir).join(crate_name).join("tests");
        for file in collect_rust_files(&tests) {
            let text = std::fs::read_to_string(&file)
                .unwrap_or_else(|error| panic!("cannot read {file}: {error}"));
            if !text.contains("fs_contract_violations(") {
                continue;
            }
            found += 1;
            if !text.contains("fs_byte_budget_violations(") {
                offenders.push(file);
            }
        }
    }
    assert_eq!(
        found, 2,
        "both port backends are expected to run the shared fs suite; the gate itself has gone stale"
    );
    assert!(
        offenders.is_empty(),
        "`RFC-0006 §5.3`'s byte budget is enforced inside the shared helpers, but a backend that never          runs the check can still drift: {offenders:?}"
    );
}

/// `ADR-051`: the checked-in `capability-registry.json` / `coverage-matrix.json` are
/// **export** artifacts — regenerated by a test under `CALY_REGENERATE_CAPABILITY_ARTIFACTS=1`
/// and proven equal to the built-in Rust document by `registry_drift.rs`. The single source of
/// truth is the code document; production `src/` must never *read* the artifact.
///
/// The gate is line-based: a line that names the artifact (the constants or their literal file
/// names) AND carries a data-fetching call (`read`/`File::open`/`include_str!`/`include_bytes!`)
/// is a runtime loader creeping in. A line that merely names the constant (e.g. a doc comment)
/// is fine — naming is not reading. This is a text gate, the cheapest that is not a comment and
/// cannot be satisfied by re-exporting the constant into a consumer crate.
#[test]
fn the_registry_artifacts_are_exports_not_runtime_inputs() {
    const TOKENS: [&str; 4] = [
        "REGISTRY_PATH",
        "COVERAGE_MATRIX_PATH",
        "capability-registry.json",
        "coverage-matrix.json",
    ];
    const READS: [&str; 5] = [
        "read_to_string",
        "fs::read",
        "File::open",
        "include_str",
        "include_bytes",
    ];

    let crates = crates_dir();
    let root = Path::new(&crates);
    let mut offenders: Vec<String> = Vec::new();
    let mut crate_dirs: Vec<String> = std::fs::read_dir(root)
        .expect("crates dir")
        .flatten()
        .filter(|entry| entry.path().is_dir())
        .map(|entry| entry.file_name().to_string_lossy().into_owned())
        .collect();
    crate_dirs.sort();
    for crate_name in crate_dirs {
        if !crate_name.starts_with("caly-") {
            continue;
        }
        let src = root.join(&crate_name).join("src");
        for source in collect_rust_files(&src) {
            let text = std::fs::read_to_string(&source)
                .unwrap_or_else(|error| panic!("cannot read {source}: {error}"));
            for line in text.lines() {
                let names_artifact = TOKENS.iter().any(|token| line.contains(token));
                if !names_artifact {
                    continue;
                }
                if READS.iter().any(|read| line.contains(read)) {
                    offenders.push(format!("{}: {}", source, line.trim()));
                }
            }
        }
    }
    assert!(
        offenders.is_empty(),
        "production code reads a registry artifact (ADR-051: artifacts are exports, \
         never runtime inputs): {offenders:?}"
    );
}

fn collect_rust_files(dir: &Path) -> Vec<String> {
    let mut files = Vec::new();
    let Ok(read) = std::fs::read_dir(dir) else {
        return files;
    };
    for entry in read.flatten() {
        let path = entry.path();
        if path.is_dir() {
            files.extend(collect_rust_files(&path));
        } else if path.extension().and_then(|ext| ext.to_str()) == Some("rs") {
            files.push(path.to_string_lossy().into_owned());
        }
    }
    files.sort();
    files
}
