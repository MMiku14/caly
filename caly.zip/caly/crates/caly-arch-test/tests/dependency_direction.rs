//! Dependency-direction gate.
//!
//! `caly-arch-test` has long contained `check_dependency_edges`, but nothing ever called it
//! and nothing built a `WorkspaceMeta`, so the invariant "依赖方向" that RFC-0001 states as
//! an architecture rule was unenforced. The first time the real manifests were fed to it, ten
//! production edges were undeclared and one allow-list entry was stale.
//!
//! These tests make that check run on every `cargo test`.

use std::collections::BTreeSet;
use std::path::Path;

use caly_arch_test::{
    check_dependency_edges, check_forbidden_symbol_usage, check_missing_allowed_edges,
    dev_dependency_edges, is_known_debt, manifest_dependency_edges, parse_cargo_manifest,
    permitted_edges, workspace_meta_from_manifests, ALLOWED_DEPENDENCY_EDGES,
    ALLOWED_DEV_DEPENDENCY_EDGES, IO_FORBIDDEN_METHODS, IO_FORBIDDEN_TYPES, KNOWN_ARCH_DEBT,
    PURE_CORE_CRATES, WORKSPACE_TARGET_CRATES,
};

/// The `crates/` directory, as an owned path string.
///
/// Kept as a `String` rather than a `PathBuf` because `clippy.toml` disallows
/// `std::path::PathBuf` workspace-wide, and the guardrail crate should not itself need an
/// `#[allow]` to read manifests.
fn crates_dir() -> String {
    Path::new(env!("CARGO_MANIFEST_DIR"))
        .parent()
        .and_then(Path::parent)
        .expect("workspace root is two levels above a crate directory")
        .join("crates")
        .to_string_lossy()
        .into_owned()
}

/// Read every `crates/*/Cargo.toml`, keyed by directory name, in a deterministic order.
fn read_manifests() -> Vec<(String, String)> {
    let dir = crates_dir();
    let dir = Path::new(&dir);
    let mut entries = Vec::new();
    let read = std::fs::read_dir(dir).expect("crates directory must be readable");
    for entry in read {
        let entry = entry.expect("readable directory entry");
        let path = entry.path();
        if !path.is_dir() {
            continue;
        }
        let name = entry.file_name().to_string_lossy().into_owned();
        let manifest_path = path.join("Cargo.toml");
        if !manifest_path.is_file() {
            continue;
        }
        let raw = std::fs::read_to_string(&manifest_path)
            .unwrap_or_else(|error| panic!("cannot read {name}/Cargo.toml: {error}"));
        entries.push((name, raw));
    }
    entries.sort();
    entries
}

fn edge_set(edges: impl IntoIterator<Item = (String, String)>) -> BTreeSet<String> {
    edges
        .into_iter()
        .map(|(from, to)| format!("{from} -> {to}"))
        .collect()
}

fn permitted_edge_strings() -> BTreeSet<String> {
    permitted_edges()
        .into_iter()
        .map(|(from, to)| format!("{from} -> {to}"))
        .collect()
}

#[test]
fn manifest_parser_reads_package_name_and_dependency_sections() {
    let sample = r#"
[package]
name = "caly-demo"
edition.workspace = true

[lib]
path = "src/lib.rs"

[dependencies]
caly-api = { path = "../caly-api" }
caly-plan = { path = "../caly-plan" }

# external crates are not Caly's internal edges
serde = "1"

[dev-dependencies]
caly-io-sim = { path = "../caly-io-sim" }
"#;
    let manifest = parse_cargo_manifest(sample);
    assert_eq!(manifest.name, "caly-demo");
    assert_eq!(manifest.dependencies, vec!["caly-api", "caly-plan"]);
    assert_eq!(manifest.dev_dependencies, vec!["caly-io-sim"]);
}

#[test]
fn every_workspace_member_is_covered_by_the_guardrail() {
    let declared: BTreeSet<String> = read_manifests().into_iter().map(|(dir, _)| dir).collect();
    let known: BTreeSet<String> = WORKSPACE_TARGET_CRATES
        .iter()
        .map(|name| (*name).to_owned())
        .collect();
    assert_eq!(
        declared, known,
        "a crate was added or removed without updating WORKSPACE_TARGET_CRATES"
    );
}

#[test]
fn no_undeclared_production_dependency_edges() {
    let entries = read_manifests();
    let actual = edge_set(manifest_dependency_edges(&entries));
    let permitted = permitted_edge_strings();

    let violations: Vec<&String> = actual
        .iter()
        .filter(|edge| !permitted.contains(*edge))
        .collect();
    assert!(
        violations.is_empty(),
        "undeclared dependency edges (add them to ALLOWED_DEPENDENCY_EDGES, or remove the \
         manifest dependency, or declare them in KNOWN_ARCH_DEBT with a rationale): {violations:?}"
    );

    // The checker must agree, and must flag *exactly* the declared debt: this is what keeps
    // `check_dependency_edges` itself from rotting into an unused helper.
    let meta = workspace_meta_from_manifests(&entries);
    let report = check_dependency_edges(&meta);
    let reported: BTreeSet<String> = report
        .violations
        .iter()
        .map(|violation| {
            let detail = violation
                .detail
                .trim_end_matches(" is not in the allow-list");
            assert_eq!(
                violation.kind,
                caly_arch_test::ViolationKind::ForbiddenDependency
            );
            detail.to_owned()
        })
        .collect();
    let declared_debt: BTreeSet<String> = KNOWN_ARCH_DEBT
        .iter()
        .map(|edge| format!("{} -> {}", edge.from, edge.to))
        .collect();
    assert_eq!(
        reported, declared_debt,
        "the dependency checker must report exactly the declared debt, nothing more"
    );
}

#[test]
fn no_stale_allow_list_entries() {
    let entries = read_manifests();
    let meta = workspace_meta_from_manifests(&entries);
    let report = check_missing_allowed_edges(&meta);
    assert!(
        report.is_clean(),
        "the allow-list advertises edges the manifests no longer declare: {:?}",
        report.violations
    );

    // Every allow-listed edge must also be a real manifest edge (same fact, checked directly).
    let actual = edge_set(manifest_dependency_edges(&entries));
    let listed: BTreeSet<String> = ALLOWED_DEPENDENCY_EDGES
        .iter()
        .map(|edge| format!("{} -> {}", edge.from, edge.to))
        .collect();
    let stale: Vec<&String> = listed
        .iter()
        .filter(|edge| !actual.contains(*edge))
        .collect();
    assert!(stale.is_empty(), "stale allow-list entries: {stale:?}");
}

/// Ratchet: known debt must stay exactly as declared.
///
/// Adding a `caly-engine -> <concrete adapter>` edge elsewhere, or removing the debt, fails
/// here until the list is updated deliberately.
#[test]
fn adapter_wiring_debt_is_declared_and_bounded() {
    let entries = read_manifests();
    let actual = edge_set(manifest_dependency_edges(&entries));
    let approved: BTreeSet<String> = ALLOWED_DEPENDENCY_EDGES
        .iter()
        .map(|edge| format!("{} -> {}", edge.from, edge.to))
        .collect();

    let undeclared: BTreeSet<String> = actual.difference(&approved).cloned().collect();
    let declared: BTreeSet<String> = KNOWN_ARCH_DEBT
        .iter()
        .map(|edge| format!("{} -> {}", edge.from, edge.to))
        .collect();

    assert_eq!(
        undeclared, declared,
        "undeclared-but-used edges must match KNOWN_ARCH_DEBT exactly; \
         any new edge needs an explicit decision"
    );
    for edge in &declared {
        let (from, to) = edge.split_once(" -> ").expect("edge string");
        assert!(is_known_debt(from, to));
    }
}

#[test]
fn test_only_edges_stay_test_only() {
    let entries = read_manifests();
    let allowed = {
        let mut set = permitted_edge_strings();
        set.extend(
            ALLOWED_DEV_DEPENDENCY_EDGES
                .iter()
                .map(|edge| format!("{} -> {}", edge.from, edge.to)),
        );
        set
    };
    let offenders: Vec<String> = dev_dependency_edges(&entries)
        .into_iter()
        .filter(|(from, to)| {
            let edge = format!("{from} -> {to}");
            !allowed.contains(&edge)
        })
        .map(|(from, to)| format!("{from} -> {to}"))
        .collect();
    assert!(
        offenders.is_empty(),
        "dev-dependencies must be declared in ALLOWED_DEV_DEPENDENCY_EDGES: {offenders:?}"
    );

    // A simulation crate must never become a production edge by accident.
    let production = manifest_dependency_edges(&entries);
    assert!(
        !production.iter().any(|(_from, to)| to == "caly-io-sim"),
        "caly-io-sim must stay out of production dependency edges"
    );
}

/// `ADR-011` / `ADR-013`: the pure core must not touch filesystem, process or wall-clock APIs.
///
/// `clippy.toml` lists the same symbols, but `caly-arch-test` is the place where the rule is
/// stated as an invariant, so this checks the source text of each pure crate directly.
#[test]
fn pure_core_crates_do_not_reference_io_or_wall_clock_symbols() {
    let root = crates_dir();
    let root = Path::new(&root);
    for crate_name in PURE_CORE_CRATES {
        let src = root.join(crate_name).join("src");
        let mut referenced_types: Vec<&str> = Vec::new();
        let mut referenced_methods: Vec<&str> = Vec::new();
        let mut offenders: Vec<String> = Vec::new();

        for source in collect_rust_files(&src) {
            let text = std::fs::read_to_string(&source)
                .unwrap_or_else(|error| panic!("cannot read {source}: {error}"));
            for ty in IO_FORBIDDEN_TYPES {
                if text.contains(*ty) {
                    referenced_types.push(*ty);
                    offenders.push(format!("{source}: type {ty}"));
                }
            }
            for method in IO_FORBIDDEN_METHODS {
                if text.contains(*method) {
                    referenced_methods.push(*method);
                    offenders.push(format!("{source}: method {method}"));
                }
            }
        }

        let report =
            check_forbidden_symbol_usage(crate_name, &referenced_types, &referenced_methods);
        assert!(
            offenders.is_empty() && report.violations.is_empty(),
            "{crate_name} is pure core but references IO/host symbols: {offenders:?}"
        );
    }
}

/// `APPLY_EXECUTION_CENTERLINE.md §6.1` Phase B's pending guard has to be *wired*, not merely
/// available.
///
/// `caly_engine::executor::execute_effect_plan` is the cursor-less entry point: it runs the plan and
/// hands its caller a journal record that the caller may or may not write.
/// `execute_effect_plan_with_cursor` is the one that puts the intent into the store *before* the
/// cutover window opens, which is the only version under which a process that dies mid-window leaves
/// evidence behind. Production code may therefore name only the second; `crates/*/**.rs` under `src/`
/// is the scanned set, with the defining file excluded because its whole job is the delegation.
///
/// Why a text gate rather than a type: making the cursor mandatory on the only public entry point
/// would push `NoCursor` into every simulation harness in the workspace, and the guard's value is
/// precisely that it is invisible to those harnesses. The rule "and nobody may quietly go back" needs
/// a gate, and this is the cheapest one that is not a comment.
#[test]
fn production_code_drives_effect_plans_through_the_cursor_entry_point() {
    let dir = crates_dir();
    let root = Path::new(&dir);
    let mut offenders: Vec<String> = Vec::new();
    for entry in std::fs::read_dir(root).expect("crates directory must be readable") {
        let crate_dir = entry.expect("readable directory entry").path();
        if !crate_dir.is_dir() {
            continue;
        }
        for source in collect_rust_files(&crate_dir.join("src")) {
            if source.ends_with("caly-engine/src/executor.rs") {
                continue;
            }
            let text = std::fs::read_to_string(&source)
                .unwrap_or_else(|error| panic!("cannot read {source}: {error}"));
            for (index, line) in text.lines().enumerate() {
                let code = line.trim_start();
                if code.starts_with("//") {
                    continue;
                }
                if line.contains("execute_effect_plan(") {
                    offenders.push(format!("{source}:{}: {code}", index + 1));
                }
            }
        }
    }
    assert!(
        offenders.is_empty(),
        "an apply path must record the cutover intent before it touches the world \
         (`APPLY_EXECUTION_CENTERLINE.md §6.1` Phase B); use `execute_effect_plan_with_cursor`: \
         {offenders:?}"
    );
}

/// `ADR-036 §2.6`: the durable store drives its ports through the shared budget, in one place.
///
/// A store seam that polls once and calls the result `StorageErrorKind::Internal` is a verdict, not a
/// limit: it says "the store is broken" about a port that is merely not finished yet, and it throws away
/// the one typed signal (`Busy`) that `OVERLOAD_AND_RETRY_MODEL §3.4`/`§6.2` and `doctor`'s pressure
/// tally are built on. `caly-storage::port_drive::drive_port` is the only allowed way to reach a port
/// from inside the crate, and this gate is what keeps a *new* store file from quietly growing its own
/// loop -- the exact drift `caly-io/src/runtime.rs` documents for the era before it existed.
///
/// `audit.rs` is exempt, and the exemption is the point of writing it out: it drives
/// `dyn StorageBackend` futures, whose answers are already typed `StorageError`s, so there is no
/// port-level kind there for it to lose. Adding a file to this list has to come with a sentence like
/// that one, which is a higher price than calling `drive_port`.
#[test]
fn the_durable_store_drives_ports_through_the_shared_budget() {
    const DRIVES_BACKENDS_NOT_PORTS: &[&str] = &["audit.rs"];
    let dir = crates_dir();
    let src = Path::new(&dir).join("caly-storage").join("src");
    let mut offenders: Vec<String> = Vec::new();
    let mut files = 0usize;
    for file in collect_rust_files(&src) {
        let name = Path::new(&file)
            .file_name()
            .and_then(|name| name.to_str())
            .unwrap_or_default()
            .to_owned();
        if DRIVES_BACKENDS_NOT_PORTS.contains(&name.as_str()) {
            continue;
        }
        files += 1;
        let text = std::fs::read_to_string(&file)
            .unwrap_or_else(|error| panic!("cannot read {file}: {error}"));
        for (index, line) in text.lines().enumerate() {
            let code = line.trim_start();
            if code.starts_with("//") {
                continue;
            }
            if line.contains("block_on_ready(") {
                offenders.push(format!("{file}:{}: {code}", index + 1));
            }
        }
    }
    // The anti-vacuity half: a gate that scans nothing must say so out loud.
    assert!(
        files >= 8,
        "the storage scan found only {files} files; the layout moved and this gate stopped meaning \
         anything"
    );
    assert!(
        offenders.is_empty(),
        "`caly-storage` drives a port outside `port_drive::drive_port`: a suspension there loses the \
         driver's kind and reaches the engine as `Internal`. Offenders: {offenders:?}"
    );
}

/// `RFC-0006 §15` asks for one contract suite that **both** port backends pass. A new check added to
/// `caly-io::contract` therefore has to be *called* by every backend that runs the suite at all --
/// otherwise it silently becomes a simulator-only assertion, which is the exact failure mode
/// `ADR-022` warns about (a release gate validating a world the production port does not implement).
///
/// The rule is stated as: any test file that calls `fs_contract_violations` must also call
/// `fs_byte_budget_violations`. A backend that opts out of the budget check has to delete the base-suite
/// call too, which is a visible and arguable change rather than a forgotten line.
#[test]
fn every_backend_that_runs_the_fs_suite_runs_the_byte_budget_check_too() {
    let dir = crates_dir();
    let mut found = 0usize;
    let mut offenders: Vec<String> = Vec::new();
    for crate_name in ["caly-io-std", "caly-io-sim"] {
        let tests = Path::new(&dir).join(crate_name).join("tests");
        for file in collect_rust_files(&tests) {
            let text = std::fs::read_to_string(&file)
                .unwrap_or_else(|error| panic!("cannot read {file}: {error}"));
            if !text.contains("fs_contract_violations(") {
                continue;
            }
            found += 1;
            if !text.contains("fs_byte_budget_violations(") {
                offenders.push(file);
            }
        }
    }
    assert_eq!(
        found, 2,
        "both port backends are expected to run the shared fs suite; the gate itself has gone stale"
    );
    assert!(
        offenders.is_empty(),
        "`RFC-0006 §5.3`'s byte budget is enforced inside the shared helpers, but a backend that never          runs the check can still drift: {offenders:?}"
    );
}

/// `ADR-051`: the checked-in `capability-registry.json` / `coverage-matrix.json` are
/// **export** artifacts — regenerated by a test under `CALY_REGENERATE_CAPABILITY_ARTIFACTS=1`
/// and proven equal to the built-in Rust document by `registry_drift.rs`. The single source of
/// truth is the code document; production `src/` must never *read* the artifact.
///
/// The gate is line-based: a line that names the artifact (the constants or their literal file
/// names) AND carries a data-fetching call (`read`/`File::open`/`include_str!`/`include_bytes!`)
/// is a runtime loader creeping in. A line that merely names the constant (e.g. a doc comment)
/// is fine — naming is not reading. This is a text gate, the cheapest that is not a comment and
/// cannot be satisfied by re-exporting the constant into a consumer crate.
#[test]
fn the_registry_artifacts_are_exports_not_runtime_inputs() {
    const TOKENS: [&str; 4] = [
        "REGISTRY_PATH",
        "COVERAGE_MATRIX_PATH",
        "capability-registry.json",
        "coverage-matrix.json",
    ];
    const READS: [&str; 5] = [
        "read_to_string",
        "fs::read",
        "File::open",
        "include_str",
        "include_bytes",
    ];

    let crates = crates_dir();
    let root = Path::new(&crates);
    let mut offenders: Vec<String> = Vec::new();
    let mut crate_dirs: Vec<String> = std::fs::read_dir(root)
        .expect("crates dir")
        .flatten()
        .filter(|entry| entry.path().is_dir())
        .map(|entry| entry.file_name().to_string_lossy().into_owned())
        .collect();
    crate_dirs.sort();
    for crate_name in crate_dirs {
        if !crate_name.starts_with("caly-") {
            continue;
        }
        let src = root.join(&crate_name).join("src");
        for source in collect_rust_files(&src) {
            let text = std::fs::read_to_string(&source)
                .unwrap_or_else(|error| panic!("cannot read {source}: {error}"));
            for line in text.lines() {
                let names_artifact = TOKENS.iter().any(|token| line.contains(token));
                if !names_artifact {
                    continue;
                }
                if READS.iter().any(|read| line.contains(read)) {
                    offenders.push(format!("{}: {}", source, line.trim()));
                }
            }
        }
    }
    assert!(
        offenders.is_empty(),
        "production code reads a registry artifact (ADR-051: artifacts are exports, \
         never runtime inputs): {offenders:?}"
    );
}

/// Round 89 (`ROADMAP §13#3`): the production CLI may not own a second frame loop.
///
/// The v0 transport has ONE bounded pump — `caly_ipc::FramePump` — which sets both the read
/// and the write deadline at construction and probes the peer before a blocking read. After
/// round 87 the *handshake* drove that pump, but the post-handshake conversation (requests,
/// stream acks, follow frames) called the raw `wire_read_frame` / `wire_write_frame` codec
/// straight against the stream, so only a read timeout ever applied to those frames: a peer
/// that stops reading could block `write_all` forever, the write half of round 44's "a
/// daemon that never answers must not hang the client".
///
/// This gate keeps the single-pump fact structural: a CLI source line in `src/bin/` or
/// `src/` that calls the raw codec functions is a second loop even if it behaves identically
/// today (round 76's lesson — a behavior-preserving second seam only fails here). The library
/// codecs themselves live in `caly-ipc` and are exercised by the daemon and by tests; this
/// gate only governs the shipped client.
#[test]
fn the_cli_drives_every_frame_through_the_shared_pump() {
    const RAW_CODEC: [&str; 2] = ["wire_read_frame", "wire_write_frame"];

    let caly_cli = Path::new(&crates_dir()).join("caly-cli");
    assert!(
        caly_cli.join("Cargo.toml").exists(),
        "the gate must find the caly-cli crate; an anti-vacuity check, so a moved crate \
         cannot turn this into a scan over zero files"
    );

    // Only the shipped client is gated. The bin lives under `src/bin`; library helpers live
    // under `src` (the driver/follow crates). Tests are deliberately excluded — they keep
    // their own independent oracle readers on purpose (two implementations agreeing is
    // evidence; see `caly-ipc/src/wire.rs` module docs).
    let mut scanned: usize = 0;
    let mut offenders: Vec<String> = Vec::new();
    for source in collect_rust_files(&caly_cli.join("src")) {
        // collect_rust_files walks the whole `src` tree, including #[cfg(test)] modules; the
        // gate is about shipped frames, so skip anything under a tests/ integration dir.
        if source.contains(&format!(
            "{}tests{}",
            std::path::MAIN_SEPARATOR,
            std::path::MAIN_SEPARATOR
        )) {
            continue;
        }
        scanned += 1;
        let text = std::fs::read_to_string(&source)
            .unwrap_or_else(|error| panic!("cannot read {source}: {error}"));
        for (idx, line) in text.lines().enumerate() {
            // A `use ... wire_read_frame ...` import is not itself a frame loop; the call is.
            let is_import = line.trim_start().starts_with("use ");
            if is_import {
                continue;
            }
            for call in RAW_CODEC {
                // Match a call site (`name(`), not the token appearing in a comment or path.
                if line.contains(&format!("{call}(")) {
                    offenders.push(format!("{}:{}: {}", source, idx + 1, line.trim()));
                }
            }
        }
    }

    assert!(
        scanned >= 3,
        "anti-vacuity: expected to scan at least the caly bin plus driver/follow sources, \
         got {scanned} files"
    );
    assert!(
        offenders.is_empty(),
        "the production CLI must send/receive every frame through caly_ipc::FramePump \
         (bounded read AND write timeouts, peer probe); a direct wire_read_frame / \
         wire_write_frame call is a second, write-unbounded loop: {offenders:#?}"
    );
}

/// Round 90 (`§13#3`, the server-side counterpart of round 89): the daemon must bound the
/// WRITE direction of every connection phase symmetrically with the read deadline.
///
/// Reads have been bounded since rounds 45/46 (`HELLO_TIMEOUT` for strangers, `session_idle`
/// for sessions). Writes were not: a peer that accepts the connection and never reads fills the
/// kernel send buffer, then `write_all` blocks forever — one thread pinned per non-reading client
/// (the model is one-thread-per-connection), and the read-side dead-peer probe never fires
/// because it runs only in the stream pump's *wait* branch. Round 89 fixed the CLI via
/// `FramePump`; `calyd` sets both directions through one helper (`set_transport_deadlines`).
///
/// This gate keeps the write deadline structural on the daemon side: the production calyd bin
/// must (a) define the symmetric setter — one call site that sets BOTH read and write timeouts —
/// and (b) install it at both phase points (accept/hello, post-hello session). The stream-pump
/// wait tick narrows the READ deadline for a peek and is not a phase point, so read-only
/// `set_read_timeout` calls stay allowed there.
#[test]
fn the_daemon_bounds_the_write_deadline_symmetrically_with_the_read_one() {
    let calyd = Path::new(&crates_dir())
        .join("caly-daemon")
        .join("src")
        .join("bin")
        .join("calyd.rs");
    assert!(
        calyd.exists(),
        "the gate must find the calyd bin; an anti-vacuity check so a moved bin cannot turn this \
         into a scan over a missing file"
    );
    let text = std::fs::read_to_string(&calyd).expect("read calyd bin");

    // The helper sets BOTH deadlines. (A regression that drops the write line removes the
    // second symbol from the function body.)
    let fn_start = text
        .find("fn set_transport_deadlines(")
        .expect("calyd must define the symmetric deadline setter set_transport_deadlines");
    let fn_body = &text[fn_start..fn_start + 600.min(text.len() - fn_start)];
    assert!(
        fn_body.contains("set_read_timeout"),
        "set_transport_deadlines must set the read deadline"
    );
    assert!(
        fn_body.contains("set_write_timeout"),
        "set_transport_deadlines must set the write deadline too; a non-reading peer must not \
         block write_all past the phase deadline (round 90)"
    );

    // Installed at both phase points: the accept/hello phase and the post-hello session phase.
    // The accept loop sets HELLO_TIMEOUT, the hello handler promotes to session_idle.
    let installs = text.matches("set_transport_deadlines(stream").count()
        + text.matches("set_transport_deadlines(&stream").count();
    assert!(
        installs >= 2,
        "the symmetric deadline must be installed at both connection phase points \
         (accept/hello and post-hello session); found {installs} call site(s)"
    );
}

/// Round 91 (`§13#3`, the client-side follow stream): a followed Job stream waits on the
/// stream's own idle scale, not the request/answer deadline — and the dead-peer probe must not
/// borrow the read budget.
///
/// Two defects compounded. (1) A real core's spawn/probe can stay silent for tens of seconds
/// while the daemon's stream pump emits nothing (a `Wait` push would claim work happened), yet
/// `caly follow` read every frame with the 3s request/answer deadline, so a healthy long job
/// surfaced a false exit-11 timeout. (2) `FramePump::recv` ran its TCP `peek` on the caller's full
/// read deadline; a peek blocks until a byte or the timeout, and that timeout maps to `Alive`, so
/// a silent peer waited out the deadline in `peek` and AGAIN in `read_exact` — doubling the
/// effective silent budget and making any widening useless for short gaps (the probe now runs on a
/// short window and restores the caller's deadline).
///
/// This gate keeps the fix structural on the client side: the production caly bin must
/// (a) define a stream idle deadline distinct from the request deadline, (b) widen through the
/// pump (`enter_stream_mode` → `set_idle`, which moves BOTH directions), and (c) call it when the
/// follow stream opens (the response/"opened" frame), not for request/answer ops.
#[test]
fn the_cli_widens_a_follow_stream_to_its_own_idle_deadline_when_opened() {
    let caly = Path::new(&crates_dir())
        .join("caly-cli")
        .join("src")
        .join("bin")
        .join("caly.rs");
    assert!(
        caly.exists(),
        "the gate must find the caly bin; an anti-vacuity check so a moved bin cannot turn this \
         into a scan over a missing file"
    );
    let text = std::fs::read_to_string(&caly).expect("read caly bin");

    // (a) A distinct stream idle deadline constant exists (longer than the request deadline).
    assert!(
        text.contains("STREAM_IDLE_TIMEOUT"),
        "the CLI must define a STREAM_IDLE_TIMEOUT for followed streams; without it a healthy \
         long job is read on the short request/answer deadline and times out"
    );
    assert!(
        text.contains("READ_TIMEOUT"),
        "the request/answer READ_TIMEOUT must remain — widening is for the stream only, not a \
         removal of the fast-answer deadline (a silent daemon must still exit 11)"
    );

    // (b) The widening goes through the pump's set_idle (which bounds BOTH directions).
    let fn_start = text
        .find("fn enter_stream_mode(")
        .expect("the CLI must define Session::enter_stream_mode");
    let fn_body = &text[fn_start..fn_start + 400.min(text.len() - fn_start)];
    assert!(
        fn_body.contains("set_idle"),
        "enter_stream_mode must widen through pump.set_idle (bounds read AND write symmetrically)"
    );
    assert!(
        fn_body.contains("STREAM_IDLE_TIMEOUT"),
        "enter_stream_mode must widen to STREAM_IDLE_TIMEOUT, not the request deadline"
    );

    // (c) It is called on a Session receiver when the follow stream opens (the response frame
    // is the "opened" frame). The definition is `fn enter_stream_mode(&mut self)`, so a call
    // site is the method invoked through a receiver (`.enter_stream_mode()`).
    let call_count = text.matches(".enter_stream_mode()").count();
    assert!(
        call_count >= 1,
        "enter_stream_mode must be called on the session when the follow stream opens; found \
         {call_count} call site(s)"
    );
}

/// Round 92 (security, `ADR-037` / `RFC-0002 §7.2`): the production wire daemon must derive a
/// remote peer's role from the role it negotiated at hello — never hard-code `Role::Admin` on the
/// request envelope. The frame loop rebuilds each request from wire records; stamping `Admin`
/// there makes every remote caller (including one that declared `Operator`/`Viewer`) pass an
/// Admin-only operation, silently defeating `require_role` on the wire (the local façade's
/// matching hole was closed in `ADR-037 §2.2`; the typed `DaemonTransport` already keeps the
/// role, which is why the loopback parity test could not see this one).
///
/// The gate pins the two sides structurally: the daemon transport exposes the negotiated peer
/// role (`peer_role`), and the production frame loop uses it on the request envelope instead of
/// a hard-coded `Role::Admin` in that envelope.
#[test]
fn the_wire_daemon_carries_the_hello_negotiated_role_into_request_envelopes() {
    let calyd = Path::new(&crates_dir())
        .join("caly-daemon")
        .join("src")
        .join("bin")
        .join("calyd.rs");
    assert!(
        calyd.exists(),
        "the gate must find the calyd bin; an anti-vacuity check so a moved bin cannot turn this \
         into a scan over a missing file"
    );
    let calyd_text = std::fs::read_to_string(&calyd).expect("read calyd bin");

    // The request envelope must source its role from the negotiated peer role, not a literal.
    assert!(
        calyd_text.contains("transport.peer_role()"),
        "the production frame loop must take the request envelope's role from \
         transport.peer_role() (the role negotiated at hello); hard-coding Admin there escalates \
         every wire peer past require_role (ADR-037 / RFC-0002 §7.2)"
    );
    // The RequestEnvelope in the frame loop must not stamp the literal admin role. We scope the
    // check to the envelope literal: the `peer_role` accessor's own `unwrap_or(Role::Admin)`
    // fallback is allowed (a pre-hello envelope cannot happen, and the fallback is the least
    // privilege issue's safe default for a missing negotiation record).
    let envelope_start = calyd_text
        .find("let envelope = RequestEnvelope {")
        .expect("the frame loop builds a RequestEnvelope");
    let envelope_body = &calyd_text[envelope_start..envelope_start + 700];
    assert!(
        !envelope_body.contains("role: Role::Admin"),
        "the wire request envelope must not hard-code role: Role::Admin — that makes every \
         remote peer pass Admin-only ops; use the negotiated peer_role"
    );
    assert!(
        envelope_body.contains("role: peer_role"),
        "the wire request envelope must carry the negotiated peer_role"
    );

    // The accessor exists on the transport and reads the negotiated session info.
    let transport = Path::new(&crates_dir())
        .join("caly-daemon")
        .join("src")
        .join("transport.rs");
    assert!(transport.exists(), "the gate must find transport.rs");
    let transport_text = std::fs::read_to_string(&transport).expect("read transport");
    assert!(
        transport_text.contains("pub fn peer_role("),
        "DaemonTransport must expose the negotiated peer role via a peer_role() accessor"
    );
    assert!(
        transport_text.contains("info.role") || transport_text.contains(".role"),
        "peer_role must read the role recorded from the negotiated hello (session info)"
    );
}

/// Round 93 (security, companion to round 92): the daemon must parse a hello's claimed role
/// **fail-closed** at the trust boundary. The lenient dialect parser keeps its legacy
/// "unrecognised role => Admin" default for old callers, but the daemon inheriting it would
/// promote a peer that asserts `role=Root` (or any bogus label), or no role at all, to the
/// highest privilege — a silent escalation that defeats the round-92 wire role gate. The
/// handshake must route the role through the fallible `server_hello_role` (unknown => refuse by
/// name, missing => least-privilege Viewer), not trust `server_hello_from_records`'s default.
#[test]
fn the_wire_daemon_parses_a_hello_role_fail_closed_at_handshake() {
    // The fail-closed parser exists in the shared dialect.
    let dialect = Path::new(&crates_dir())
        .join("caly-ipc")
        .join("src")
        .join("dialect.rs");
    assert!(dialect.exists(), "the gate must find dialect.rs");
    let dialect_text = std::fs::read_to_string(&dialect).expect("read dialect");
    assert!(
        dialect_text.contains("pub fn server_hello_role("),
        "the dialect must expose a fail-closed server_hello_role parser (unknown role refused, \
         missing role least-privilege)"
    );

    // The production daemon handshake must call it and refuse on error before accepting the hello.
    let calyd = Path::new(&crates_dir())
        .join("caly-daemon")
        .join("src")
        .join("bin")
        .join("calyd.rs");
    assert!(calyd.exists(), "the gate must find the calyd bin");
    let calyd_text = std::fs::read_to_string(&calyd).expect("read calyd bin");
    assert!(
        calyd_text.contains("server_hello_role(&records)"),
        "the daemon handshake must validate the hello role through server_hello_role; trusting \
         the lenient parser's Admin default would escalate an unknown/missing role claim"
    );
    // The negotiated role must override whatever the lenient parser defaulted (fail-closed
    // result is authoritative), and a parse error must be a handshake refusal. Anchor on the
    // handshake match arm, not the `WIRE_KIND_HELLO as KIND_HELLO` import alias.
    let hello_branch = calyd_text
        .find("KIND_HELLO if !hello_seen")
        .expect("daemon has a hello match arm");
    let window = &calyd_text[hello_branch..hello_branch + 3000];
    assert!(
        window.contains("hello.role = negotiated_role"),
        "the fail-closed negotiated role must override the lenient hello.role"
    );
    assert!(
        window.contains("\"HANDSHAKE\"") && window.contains("server_hello_role"),
        "an unparseable role must be refused as a HANDSHAKE error, not accepted"
    );
}

/// Round 94: a response or refusal is only THIS verb's answer if it carries the request id the
/// verb sent. v0 has one outstanding request per session and the daemon echoes the id on every
/// response/refusal; the CLI used to accept a frame purely on its kind (the "believe the kind,
/// never read the content" hole round 71 closed for the handshake). This gate pins the
/// correlation structurally: the one-shot `ask` path must name a request id, send it, and check
/// the answer's `request_id` equals it before treating the frame as an answer.
#[test]
fn the_cli_correlates_each_answer_with_its_request_id() {
    let caly = Path::new(&crates_dir())
        .join("caly-cli")
        .join("src")
        .join("bin")
        .join("caly.rs");
    assert!(
        caly.exists(),
        "the gate must find the caly bin; an anti-vacuity check so a moved bin cannot turn this \
         into a scan over a missing file"
    );
    let text = std::fs::read_to_string(&caly).expect("read caly bin");

    // The sent id is a named constant, and `ask` sends it through request_payload.
    assert!(
        text.contains("const REQUEST_ID: u64"),
        "the one-shot answer id must be a named REQUEST_ID constant (one outstanding request per \
         v0 session), not an unexplained literal"
    );
    let ask_start = text
        .find("fn ask(")
        .expect("the one-shot ask() path must exist");
    let ask_end = text[ask_start..]
        .find("\n}\n")
        .map(|offset| ask_start + offset + 2)
        .unwrap_or(text.len());
    let ask_body = &text[ask_start..ask_end];

    assert!(
        ask_body.contains("request_payload(REQUEST_ID"),
        "ask must send the named REQUEST_ID in the request payload"
    );
    assert!(
        ask_body.contains("request_id") && ask_body.contains("REQUEST_ID"),
        "ask must read the answer's request_id record and compare it to REQUEST_ID"
    );
    // The mismatch must actually be tested against the sent id — binding the parsed value and
    // not comparing it (or renaming the binding away) leaves a foreign/stale frame accepted.
    assert!(
        ask_body.contains("answer_id != Some(REQUEST_ID)"),
        "ask must reject an answer whose request_id != REQUEST_ID; a foreign id or an absent id \
         is not this verb's answer (a renamed/unused binding must not satisfy this gate)"
    );
}

/// Round 95: a follow stream's data/end frames are only THIS follow's frames if they carry the
/// stream id the opened frame named. The wire multiplexes streams per session (the typed state
/// machine in `caly_ipc::client` rejects an unknown stream id from its `streams` table), but the
/// hand-written follow path used to believe the frame kind and never read `stream_id` — a foreign
/// stream's events would print as this job's and a foreign end's `outcome` would set the exit code.
/// This gate pins the correlation structurally: the opened frame must establish the authoritative
/// stream id, and the STREAM_DATA / STREAM_END arms must call a comparison that pins the frame id
/// to the opened id.
#[test]
fn the_cli_correlates_each_follow_frame_with_its_opened_stream_id() {
    let caly = Path::new(&crates_dir())
        .join("caly-cli")
        .join("src")
        .join("bin")
        .join("caly.rs");
    assert!(
        caly.exists(),
        "the gate must find the caly bin; an anti-vacuity check so a moved bin cannot turn this \
         into a scan over a missing file"
    );
    let text = std::fs::read_to_string(&caly).expect("read caly bin");

    // The opened frame must establish the authoritative id for the conversation.
    let follow_start = text
        .find("fn follow_stream(")
        .expect("the follow_stream path must exist");
    let follow_end = text[follow_start..]
        .find("\n}\n")
        .map(|offset| follow_start + offset + 2)
        .unwrap_or(text.len());
    let follow_body = &text[follow_start..follow_end];

    assert!(
        follow_body.contains("opened_stream"),
        "follow must remember the opened frame's stream_id as the authoritative id for the \
         conversation"
    );
    assert!(
        follow_body.contains("WIRE_KIND_STREAM_DATA")
            && follow_body.contains("WIRE_KIND_STREAM_END"),
        "follow must handle both stream data and stream end frames"
    );

    // The correlation helper must be called on the data/end frames (before printing/verdict),
    // and must actually compare the frame id against the opened id. Pin the comparison
    // expression, not just the helper name: a helper that binds but never compares leaves a
    // foreign stream accepted (the same "pin the expression, not the symbol" lesson as round 94).
    assert!(
        text.contains("fn stream_frame_id_matches("),
        "a stream-frame correlation helper must exist"
    );
    assert!(
        text.contains("frame_id == opened"),
        "the correlation helper must accept only a frame whose stream_id equals the opened id; \
         a foreign id or a missing id must be a PROTO_MISMATCH (a binding that is never compared \
         must not satisfy this gate)"
    );
    let helper_start = text
        .find("fn stream_frame_id_matches(")
        .expect("helper located");
    let helper_end = text[helper_start..]
        .find("\n}\n")
        .map(|offset| helper_start + offset + 2)
        .unwrap_or(text.len());
    let helper_body = &text[helper_start..helper_end];
    assert!(
        helper_body.contains("PROTO_MISMATCH"),
        "a mismatched or uncorrelated stream frame must be reported as a PROTO_MISMATCH"
    );
    // The ONLY acceptance path is the equality match. Pin it structurally so a mutant cannot
    // (a) add an early unconditional `return Ok(())` ahead of the match (M1) — the helper may not
    // return Ok before the match is reached; nor (b) bolt on a second accepting arm such as
    // `(None, _) => Ok(())` that treats a missing/foreign id as correlated (M2). Counting the
    // accepting matches (an arm ending in `=> Ok(())`) pins both: exactly one acceptance, and it
    // must be the `== opened` one.
    let accept_arms = helper_body.matches("=> Ok(())").count();
    assert_eq!(
        accept_arms, 1,
        "the correlation helper must have EXACTLY ONE accepting path (the frame_id == opened          arm); an early return Ok or a second accepting arm (e.g. for a missing id) silently          accepts a foreign/uncorrelated stream. Found {accept_arms} `=> Ok(())` arms"
    );
    let equality_guards = helper_body.matches("frame_id == opened").count();
    assert_eq!(
        equality_guards, 1,
        "the single accepting arm must be guarded by frame_id == opened"
    );
    // The acceptance arm must come AFTER the frame id is read (no unconditional pass before the
    // comparison): the literal match line must follow the `let frame_id = wire_field` read.
    let read_pos = helper_body
        .find("wire_field(records, \"stream_id\")")
        .expect("the helper must read the frame's stream_id record");
    let accept_pos = helper_body
        .find("frame_id == opened")
        .expect("the equality guard must exist");
    assert!(
        read_pos < accept_pos,
        "the stream_id read must precede the equality guard; an accept that does not first read          the frame id cannot correlate it"
    );
    // Both stream frame arms in follow must invoke the correlation before trusting the frame.
    let data_arm = follow_body.find("WIRE_KIND_STREAM_DATA").expect("data arm");
    let end_arm = follow_body.find("WIRE_KIND_STREAM_END").expect("end arm");
    assert!(
        &follow_body[data_arm..end_arm].contains("stream_frame_id_matches("),
        "the STREAM_DATA arm must correlate the frame's stream_id before printing its events"
    );
    assert!(
        follow_body[end_arm..].contains("stream_frame_id_matches("),
        "the STREAM_END arm must correlate the frame's stream_id before letting its outcome set \
         the verdict"
    );
}

/// Round 96: the stream correlation closes its last two gaps on the follow/reconnect path.
///
/// (1) RESUME: `caly follow --resume <id>` names the stream to reconnect; the opened frame must
/// echo that SAME id and flag `resumed=true`. An opened frame that names a different stream, or
/// matches the id but is a fresh open (`resumed=false`), is a protocol disagreement — calling it
/// a resume reconnects at the wrong cursor.
///
/// (2) ACK CONFIRMATION: after the client sends a STREAM_ACK naming a stream, the daemon's
/// confirmation must name that SAME stream. A confirmation for a different stream that merely
/// echoes a matching `acked_upto` is not proof this stream's cursor landed (a resume would then
/// replay from an unacked position).
#[test]
fn the_cli_correlates_resumes_and_ack_confirmations_to_their_stream() {
    let caly = Path::new(&crates_dir())
        .join("caly-cli")
        .join("src")
        .join("bin")
        .join("caly.rs");
    assert!(
        caly.exists(),
        "the gate must find the caly bin; an anti-vacuity check so a moved bin cannot turn this \
         into a scan over a missing file"
    );
    let text = std::fs::read_to_string(&caly).expect("read caly bin");

    let follow_start = text
        .find("fn follow_stream(")
        .expect("follow_stream exists");
    let follow_end = text[follow_start..]
        .find("\n}\n")
        .map(|o| follow_start + o + 2)
        .unwrap_or(text.len());
    let follow_body = &text[follow_start..follow_end];

    // (1) The resume expectation must be derived from the requested resume id, and the opened
    // frame must compare its stream_id to it AND require the resumed flag.
    // The resume-named id must be captured so the opened frame can be correlated to it.
    assert!(
        follow_body.contains("resume_expect") || follow_body.contains("if let Some(expected)"),
        "follow must remember the resume-named stream to correlate the opened frame against"
    );
    // The opened frame's stream_id must actually be compared to the resume-requested id; the
    // concrete error names both ids (a renamed/unused binding must not satisfy the gate).
    assert!(
        follow_body.contains("stream_id != expected"),
        "a resume must refuse an opened frame whose stream_id != the requested resume id"
    );
    assert!(
        follow_body.contains("not the resume") || follow_body.contains("asked to resume stream"),
        "the resume-id mismatch must be a PROTO_MISMATCH naming both ids"
    );
    assert!(
        follow_body.contains("resumed != \"true\""),
        "a resume must also refuse an opened frame that matches the id but is not flagged \
         resumed=true (a fresh open is not the resumption asked for)"
    );

    // (2) The ack confirmation helper must compare the confirmation's stream_id against the ack's
    // stream_id, and the comparison must be a real inequality (not a symbol that is never read).
    let ack_start = text
        .find("fn ack_and_confirm(")
        .expect("ack_and_confirm exists");
    let ack_end = text[ack_start..]
        .find("\n}\n")
        .map(|o| ack_start + o + 2)
        .unwrap_or(text.len());
    let ack_body = &text[ack_start..ack_end];

    assert!(
        ack_body.contains("confirmed_stream"),
        "ack_and_confirm must read the confirmation frame's stream_id record"
    );
    assert!(
        ack_body.contains("confirmed_stream != stream_id")
            || ack_body.contains("confirmed_stream == stream_id"),
        "the confirmation's stream_id must actually be compared to the ack's stream_id; a \
         confirmation for a different stream that merely echoes acked_upto must be refused"
    );
    assert!(
        ack_body.contains("PROTO_MISMATCH"),
        "a foreign-stream ack confirmation must be reported as a PROTO_MISMATCH"
    );
}

/// Round 97: the follow OPENED frame (and an open-time REFUSAL) is the follow request's direct
/// answer and the daemon echoes that request's `request_id`. Round 94 correlated a one-shot
/// answer by request_id but only in `ask()`; the follow path correlated DATA/END by stream_id
/// (rounds 95/96) yet never checked the opened frame's request_id — a response carrying a valid
/// stream but a FOREIGN/missing request id was accepted as this follow's open. This gate pins:
/// the follow open must be sent with the SAME named REQUEST_ID constant as ask (not a literal 1),
/// and the opened frame and the follow-path refusal must each actually compare their request_id
/// to REQUEST_ID.
#[test]
fn the_cli_correlates_the_follow_opened_frame_by_its_request_id() {
    let caly = Path::new(&crates_dir())
        .join("caly-cli")
        .join("src")
        .join("bin")
        .join("caly.rs");
    assert!(
        caly.exists(),
        "the gate must find the caly bin; anti-vacuity so a moved bin cannot turn this into a \
         scan over a missing file"
    );
    let text = std::fs::read_to_string(&caly).expect("read caly bin");

    let follow_start = text
        .find("fn follow_stream(")
        .expect("follow_stream exists");
    let follow_end = text[follow_start..]
        .find("\n}\n")
        .map(|o| follow_start + o + 2)
        .unwrap_or(text.len());
    let follow_body = &text[follow_start..follow_end];

    // The follow open request must be sent with the named REQUEST_ID constant (one symbol for the
    // sent value and the checked value), not a bare literal 1.
    assert!(
        follow_body.contains("request_payload(REQUEST_ID"),
        "follow must send its open request with the named REQUEST_ID constant (the same symbol \
         the answer is checked against), not a literal 1"
    );

    // The opened frame arm must read its request_id and compare it to REQUEST_ID.
    let opened_pos = follow_body
        .find("The opened frame is the follow request")
        .expect("the opened-arm request_id correlation must be documented and present");
    let data_pos = follow_body
        .find("WIRE_KIND_STREAM_DATA")
        .expect("data arm present");
    let opened_region = &follow_body[opened_pos..data_pos];
    assert!(
        opened_region.contains("Some(REQUEST_ID)"),
        "the opened frame must be refused when its request_id != REQUEST_ID (a foreign/missing \
         request id on a valid stream is not this follow's open)"
    );

    // The follow-path refusal arm (the open request's refusal answer) must also correlate its
    // request_id before being read as THIS follow being refused.
    let refusal_pos = follow_body
        .find("WIRE_KIND_REFUSAL")
        .expect("refusal arm present");
    let refusal_region = &follow_body[refusal_pos..];
    assert!(
        refusal_region.contains("Some(REQUEST_ID)"),
        "a follow-path refusal must carry the verb's request_id; a refusal for a different \
         request must not be read as this follow being refused"
    );
}

/// Round 98: a daemon REFUSAL carries a stable public code and the CLI must map it to its
/// documented exit number (EXIT_CODES.md §4.1), not collapse every refusal to PROTO_MISMATCH.
/// `from_wire_refusal_code` recognises the 14 public ApiError codes and falls back to
/// PROTO_MISMATCH for transport/session codes and unknown codes. Both places the bin acts on a
/// REFUSAL frame — the one-shot `ask()` answer and the follow-path refusal arm — must route
/// through that mapping (and not hard-code `ExitCode::ProtoMismatch`).
#[test]
fn the_cli_maps_a_wire_refusal_code_to_its_documented_exit_code() {
    let caly = Path::new(&crates_dir())
        .join("caly-cli")
        .join("src")
        .join("bin")
        .join("caly.rs");
    assert!(
        caly.exists(),
        "the gate must find the caly bin; anti-vacuity"
    );
    let text = std::fs::read_to_string(&caly).expect("read caly bin");

    // The one-shot answer path maps its refusal code.
    assert!(
        text.contains("from_wire_refusal_code"),
        "the bin must route a REFUSAL frame's code through from_wire_refusal_code (a public \
         business code maps to its documented exit number; only wire/session codes fall to 13)"
    );
    let call_count = text.matches("from_wire_refusal_code(").count();
    assert!(
        call_count >= 2,
        "both refusal consumers must map the code: ask()'s Answer::Refused and follow's \
         WIRE_KIND_REFUSAL arm; found {call_count} call sites"
    );

    // The mapping helper exists in the CLI library and recognises a public code via as_str,
    // falling back to ProtoMismatch — a full re-table in the bin would drift from EXIT_CODES.md.
    let lib = Path::new(&crates_dir())
        .join("caly-cli")
        .join("src")
        .join("exit_code.rs");
    assert!(lib.exists(), "exit_code.rs must exist; anti-vacuity");
    let lib_text = std::fs::read_to_string(&lib).expect("read exit_code.rs");
    assert!(
        lib_text.contains("fn from_wire_refusal_code("),
        "from_wire_refusal_code must live in the CLI library alongside from_error_code"
    );
    assert!(
        lib_text.contains(".as_str()") && lib_text.contains("ProtoMismatch"),
        "the mapping must recognise codes by their canonical as_str name and fall back to \
         ProtoMismatch for unknown/transport codes (never guess a newer daemon's code)"
    );
}

/// Round 99: a one-shot `caly job <id>` (jobs.follow query) that describes a TERMINALLY FAILED
/// job carries the engine's stable `failure_code`; the bin must map that verdict to the code's
/// documented exit number instead of always exiting 0 (EXIT_CODES.md §4.3 — a failed job does not
/// report success). The verdict is only meaningful for jobs.follow: other queries always succeed
/// at the exit level, and an absent/empty failure_code means "not failed". This gate pins the bin
/// wiring; the three caly_cli_e2e fixtures `a_one_shot_job_query_*` pin the runtime behaviour.
#[test]
fn the_cli_maps_a_one_shot_job_follow_failure_code_to_an_exit_code() {
    let caly = Path::new(&crates_dir())
        .join("caly-cli")
        .join("src")
        .join("bin")
        .join("caly.rs");
    assert!(
        caly.exists(),
        "the gate must find the caly bin; anti-vacuity"
    );
    let text = std::fs::read_to_string(&caly).expect("read caly bin");

    // A helper names the failure-verdict mapping so both the json and the records answer arms
    // share it (one piece of exit-code knowledge, not two).
    assert!(
        text.contains("fn job_follow_failure_exit_code("),
        "the bin must own a job_follow_failure_exit_code helper mapping a jobs.follow failure_code to its exit number"
    );

    // The verdict is gated on the jobs.follow operation and on a NON-EMPTY failure_code:
    // every other query (and a non-failed job) still exits success.
    assert!(
        text.contains("\"jobs.follow\"") && text.contains("\"failure_code\""),
        "the helper must read the failure_code field only for the jobs.follow operation"
    );
    assert!(
        text.contains("filter(|code| !code.is_empty())"),
        "an absent or EMPTY failure_code (the daemon always emits the field, empty when not failed) must mean success, not a failure exit"
    );

    // It routes the recognised code through the same R98 wire-code table — a job failure_code is
    // an ApiError code over the same 14-code public vocabulary, not a separate mapping. The check
    // is scoped to the HELPER BODY: the bin also calls from_wire_refusal_code from the R98 REFUSAL
    // arms, so a whole-file contains() would pass even if this helper hard-coded its own verdict.
    let fn_start = text
        .find("fn job_follow_failure_exit_code(")
        .expect("helper must exist (asserted above)");
    let body_open = text[fn_start..].find('{').expect("helper body opens");
    // The helper's closing brace is the first line that is a lone "}" after the open brace.
    let after_open = &text[fn_start + body_open..];
    let body_len = after_open
        .find("\n}\n")
        .expect("helper body must close with a lone brace");
    let helper_body = &after_open[..body_len];
    assert!(
        helper_body.contains("from_wire_refusal_code(code)"),
        "the jobs.follow failure_code must map through from_wire_refusal_code INSIDE the helper (same public code table as a REFUSAL frame), not a parallel/hard-coded verdict that could drift; helper body was:\n{helper_body}"
    );

    // Both answer arms (json verbatim payload and human records render) must apply the verdict:
    // --json does not change exit-code semantics (EXIT_CODES.md §1.4).
    let uses = text.matches("job_follow_failure_exit_code(").count();
    assert!(
        uses >= 3,
        "the failure-verdict helper must be used by both answer arms plus its definition; found {uses} mentions (need >= 3: 1 fn + 2 call sites)"
    );
}

/// Round 101: the systemd deployment artifact (shipped round 100, ADR-055) must be a judge of
/// its CONTENT, not just its existence. `doc_consistency::every_documented_path_reference_resolves`
/// only proves the runbook points at a file that exists — a typo'd flag, a dropped Restart=, a
/// simulated-vs-real mistake, or a mihomo/sing-box core launched as its OWN systemd process
/// (violating the two-layer supervision boundary, RFC-0005 §11.2 / ADR-055) would all pass that
/// gate silently. This gate reads the unit and pins the invariants.
#[test]
fn the_systemd_unit_is_a_foreground_managed_calyd_supervising_the_core() {
    // Workspace root is two levels above this crate; packaging/ is a top-level tree sibling.
    let crates = crates_dir();
    let root = Path::new(&crates)
        .parent()
        .expect("crates/ has a parent (the workspace root)");
    let unit = root.join("packaging").join("systemd").join("calyd.service");
    assert!(
        unit.exists(),
        "the shipped systemd unit must exist; anti-vacuity"
    );
    let raw = std::fs::read_to_string(&unit).expect("read calyd.service");

    // Strip comment lines, then join backslash line-continuations so a multi-line ExecStart is
    // read as one directive.
    let active: Vec<&str> = raw
        .lines()
        .filter(|line| !line.trim_start().starts_with('#'))
        .collect();
    let joined = active.join("\n").replace("\\\n", " ");
    let directives: Vec<&str> = joined
        .lines()
        .map(str::trim)
        .filter(|line| !line.is_empty())
        .collect();

    let directive = |key: &str| -> String {
        directives
            .iter()
            .find(|line| line.starts_with(&format!("{key}=")))
            .map(|line| line.to_string())
            .unwrap_or_default()
    };

    // --- Foreground, externally supervised (ADR-055 §2.1) -----------------------------
    let service = directive("Type");
    assert_eq!(
        service, "Type=simple",
        "calyd must be a foreground Type=simple service (no self-daemonization); got {service:?}"
    );
    let restart = directive("Restart");
    assert!(
        restart == "Restart=on-failure" || restart == "Restart=always",
        "systemd must supervise (auto-restart) calyd; got {restart:?}"
    );
    let wanted = directive("WantedBy");
    assert!(
        wanted.contains("multi-user.target"),
        "the unit must be installable/enabled (WantedBy=multi-user.target); got {wanted:?}"
    );

    // --- The ExecStart launches calyd, and only flags the daemon parses ----------------
    let exec = directive("ExecStart");
    assert!(
        exec.contains("calyd") && !exec.contains("/caly "),
        "ExecStart must launch calyd (the daemon), not the caly CLI; got {exec:?}"
    );
    const SUPPORTED: &[&str] = &[
        "--bind",
        "--data-dir",
        "--effect-runtime",
        "--runtime-root",
        "--assets-dir",
        "--port-file",
        "--source-endpoint",
        "--session-idle-ms",
        "--worker-tick-ms",
    ];
    for tok in exec.split_whitespace() {
        if let Some(flag) = tok.strip_prefix("--") {
            let flag = format!("--{flag}");
            assert!(
                SUPPORTED.contains(&flag.as_str()),
                "ExecStart uses {flag:?} which calyd does not parse (flag drift/typo): {exec}"
            );
        }
    }

    // --- Real runtime is an explicit opt-in with BOTH required paths (ADR-050 §2.1) ----
    assert!(
        exec.contains("--effect-runtime real"),
        "the shipped production unit must opt into the real effect runtime explicitly: {exec}"
    );
    assert!(
        exec.contains("--runtime-root") && exec.contains("--assets-dir"),
        "--effect-runtime real REQUIRES both --runtime-root and --assets-dir (ADR-050 usage refusal): {exec}"
    );

    // --- Binds the RuntimeDirectory UDS (no stray TCP port; file-permission access) ----
    assert!(
        exec.contains("--bind unix:/run/calyd/"),
        "the unit must bind the UDS under its RuntimeDirectory (/run/calyd); got {exec:?}"
    );
    assert!(
        directive("RuntimeDirectory").contains("calyd")
            && directive("StateDirectory").contains("calyd"),
        "the unit must declare RuntimeDirectory + StateDirectory for /run/calyd and /var/lib/calyd"
    );

    // --- The two-layer supervision boundary: systemd never launches a Core -------------
    for line in &directives {
        let is_exec_directive = line.starts_with("ExecStart")
            || line.starts_with("ExecStartPre")
            || line.starts_with("ExecStartPost")
            || line.starts_with("ExecReload")
            || line.starts_with("ExecStop");
        if is_exec_directive {
            assert!(
                !line.contains("mihomo") && !line.contains("sing-box"),
                "systemd must NOT launch the proxy core (mihomo/sing-box) as its own process — the \
                 core is supervised by calyd's Core Supervisor inside apply transactions \
                 (RFC-0005 §11.2 / ADR-055). Found: {line}"
            );
        }
    }
}

/// Round 102 / ADR-056: calyd must install a SIGTERM/SIGINT graceful-shutdown surface. Before it,
/// calyd had no signal handler, so `systemctl stop` (ADR-055) used the default action — immediate
/// termination — leaving the live core un-stopped for next-start crash recovery (RFC-0005 §12).
/// This gate pins the wiring; the runtime behaviour (real SIGTERM -> exit code 0, not signal 15)
/// is pinned by the calyd_wire integration test `sigterm_shuts_calyd_down_gracefully_with_exit_zero`.
#[test]
fn the_daemon_installs_a_term_signal_handler_that_shuts_the_core_down() {
    let crates = crates_dir();
    let bin = Path::new(&crates)
        .join("caly-daemon")
        .join("src")
        .join("bin")
        .join("calyd.rs");
    assert!(
        bin.exists(),
        "the gate must find the calyd bin; anti-vacuity"
    );
    let bin_text = std::fs::read_to_string(&bin).expect("read calyd bin");

    // The composition root installs the term handler (module pulled in by path; cfg-gated in body).
    assert!(
        bin_text.contains("mod signal;") || bin_text.contains("mod signal {"),
        "calyd must declare the signal module (ADR-056 TERM surface)"
    );
    assert!(
        bin_text.contains("signal::install_term_handler("),
        "the calyd composition root must call signal::install_term_handler(..) before spawning accept/worker threads"
    );
    // The handler's shutdown closure must gracefully stop the real runtime's core.
    assert!(
        bin_text.contains(".shutdown(SHUTDOWN_GRACE_MS)") || bin_text.contains(".shutdown("),
        "the term handler must invoke the effect runtime's shutdown(grace) to stop the live core"
    );
    assert!(
        bin_text.contains("SHUTDOWN_GRACE_MS"),
        "the graceful stop must be bounded (SHUTDOWN_GRACE_MS), sized under the systemd TimeoutStopSec"
    );

    // The FFI waiter module exists and uses the minimal pthread signal surface (no libc crate).
    let signal_mod = Path::new(&crates)
        .join("caly-daemon")
        .join("src")
        .join("bin")
        .join("support")
        .join("signal.rs");
    assert!(
        signal_mod.exists(),
        "the signal FFI module must live at src/bin/support/signal.rs (under bin/support so it is not treated as a separate binary)"
    );
    let sig = std::fs::read_to_string(&signal_mod).expect("read signal module");
    assert!(
        sig.contains("sigwait"),
        "the waiter must consume SIGTERM/SIGINT via sigwait (POSIX non-handler context, ADR-056)"
    );
    assert!(
        sig.contains("pthread_sigmask"),
        "the main thread must block SIGTERM/SIGINT via pthread_sigmask before spawning threads"
    );
    assert!(
        sig.contains("fn install_term_handler"),
        "the module must expose a safe install_term_handler entry (unsafe localised inside)"
    );
}

/// Round 103: a `caly follow <id> --json` stream must exit by the stream's verdict, not an
/// unconditional success. Before this fix the STREAM_END json branch printed the payload and then
/// `return Ok(ExitCode::Success)` regardless of the job's outcome — a failed/cancelled/timed-out job
/// followed under --json reported exit 0 (EXIT_CODES.md §1.4: --json changes the rendering, not the
/// exit semantics). The human render already mapped the outcome; json diverged.
///
/// This gate pins that both renderings share ONE verdict function; the behaviour is pinned at runtime
/// by the two caly_cli_e2e fixtures `a_json_follow_of_a_failed_job_exits_nonzero_like_the_human_render`
/// and `a_json_follow_of_a_succeeded_job_stays_exit_zero`.
#[test]
fn the_follow_stream_end_exit_code_is_shared_between_json_and_records() {
    let caly = Path::new(&crates_dir())
        .join("caly-cli")
        .join("src")
        .join("bin")
        .join("caly.rs");
    assert!(
        caly.exists(),
        "the gate must find the caly bin; anti-vacuity"
    );
    let text = std::fs::read_to_string(&caly).expect("read caly bin");

    // A shared verdict function exists and maps every documented outcome.
    assert!(
        text.contains("fn stream_end_exit_code("),
        "the bin must own a stream_end_exit_code helper mapping the END frame to an exit code"
    );
    for outcome in ["Succeeded", "Failed", "Cancelled", "TimedOut"] {
        assert!(
            text.contains(&format!("\"{outcome}\" =>")),
            "stream_end_exit_code must map the {outcome} outcome to its exit code"
        );
    }
    // The state-gap verdict (CursorStale) is handled in the shared function, not only one branch.
    assert!(
        text.contains("state-gap") && text.contains("CursorStale"),
        "the shared function must honour a state-gap end as CursorStale"
    );

    // The STREAM_END arm must end on the shared verdict — it is the return statement on the
    // stream's terminal frame, reachable from BOTH the json print path and the records path (the
    // json verbatim print happens first, then the same `return stream_end_exit_code` runs). Pin the
    // exact call form so a json-only `return Ok(ExitCode::Success)` short-circuit cannot creep back
    // between the json print and the shared verdict.
    assert!(
        text.contains("return stream_end_exit_code(&records);"),
        "the STREAM_END arm must return stream_end_exit_code(&records) for BOTH json and records \
         (a json-only Success short-circuit would diverge from EXIT_CODES.md §1.4)"
    );

    // Pin the json sub-branch: it prints verbatim but MUST NOT return before the shared verdict —
    // the round-103 bug was `if json { println!(..); return Ok(ExitCode::Success); }`, which kept
    // the shared call below it as dead code (so the contains-assertion above alone cannot catch it).
    // Slice from the follow-stream json verbatim print to the shared verdict and forbid a `return`.
    let json_print = text
        .find("String::from_utf8_lossy(&payload))")
        .expect("the follow json verbatim print exists");
    let verdict = text[json_print..]
        .find("return stream_end_exit_code(&records);")
        .map(|i| json_print + i)
        .expect("the shared verdict follows the json print");
    let between = &text[json_print..verdict];
    assert!(
        !between.contains("return Ok(") && !between.contains("return Ok "),
        "the json sub-branch of STREAM_END must not return before the shared verdict (EXIT_CODES.md \
         §1.4: --json does not change exit semantics); a json-only Success short-circuit diverged"
    );
}

/// Round 106: `caly jobs` with no id is the discovery verb (`jobs.list`); `caly jobs <id>` still
/// pages one job's events (`jobs.events`). Before this round there was no way to learn which job
/// ids exist after losing your shell (`JOB_FLOW_SCENARIO_REVIEW`). This gate pins the whole path so
/// the four seams cannot quietly drift apart: the CLI routes the id-less verb to a typed ListJobs,
/// the wire codec names `jobs.list` in both directions, the engine serves a capped list, and the
/// daemon caps it at its own bound (local/remote cannot disagree). The runtime behaviour is judged
/// by `caly_jobs_without_an_id_lists_recent_jobs_newest_first` (real binary) plus the engine's
/// newest-first/cap unit tests.
#[test]
fn the_jobs_discovery_verb_is_wired_end_to_end_under_a_daemon_cap() {
    let read = |crate_name: &str, tail: &[&str]| {
        let mut path = Path::new(&crates_dir()).join(crate_name);
        for part in tail {
            path = path.join(part);
        }
        assert!(path.exists(), "{path:?} must exist; anti-vacuity");
        std::fs::read_to_string(&path).expect("read source")
    };

    // CLI: the id-less `jobs` verb routes to jobs.list, and the typed op is ListJobs.
    let caly = read("caly-cli", &["src", "bin", "caly.rs"]);
    assert!(
        caly.contains("\"jobs.list\""),
        "the id-less `caly jobs` verb must wire to jobs.list"
    );
    assert!(
        caly.contains("DiagnosticsOp::ListJobs"),
        "the CLI must build the typed ListJobs operation (not an untyped string)"
    );
    assert!(
        caly.contains("fn print_job_list("),
        "the list answer has a human rendering, not the default status layout"
    );

    // Wire codec: `jobs.list` is a named operation the encoder and decoder share.
    let wire_ops = read("caly-ipc", &["src", "wire_ops.rs"]);
    assert!(
        wire_ops.contains("\"jobs.list\""),
        "the v0 wire codec must name jobs.list"
    );
    assert!(
        wire_ops.contains("DiagnosticsOp::ListJobs")
            && wire_ops.matches("DiagnosticsOp::ListJobs").count() >= 2,
        "jobs.list must appear on both the encode and decode sides of the codec"
    );

    // API: ListJobs is a Viewer query (a directory of jobs is read-only).
    let ops = read("caly-api", &["src", "ops.rs"]);
    assert!(
        ops.contains("ListJobs"),
        "DiagnosticsOp::ListJobs must be declared"
    );

    // Engine: serves a list; daemon: applies its own bound in the one place both façades reach.
    let service = read("caly-engine", &["src", "service.rs"]);
    assert!(
        service.contains("fn list_job_views("),
        "the engine must project a list of job summaries"
    );
    let app = read("caly-daemon", &["src", "app.rs"]);
    assert!(
        app.contains("fn job_list(") && app.contains("list_job_views("),
        "the daemon app handle must expose job_list backed by the engine"
    );
    let cap_hits = app.matches("JOB_LIST_CAP").count();
    assert!(
        cap_hits >= 1,
        "the daemon must bound the reply with its own JOB_LIST_CAP so local/remote agree"
    );
    let calyd = read("caly-daemon", &["src", "bin", "calyd.rs"]);
    assert!(
        calyd.contains("OperationResult::JobList(") && calyd.contains("fn job_list_records("),
        "the daemon must render the JobList result onto the wire"
    );
}

fn collect_rust_files(dir: &Path) -> Vec<String> {
    let mut files = Vec::new();
    let Ok(read) = std::fs::read_dir(dir) else {
        return files;
    };
    for entry in read.flatten() {
        let path = entry.path();
        if path.is_dir() {
            files.extend(collect_rust_files(&path));
        } else if path.extension().and_then(|ext| ext.to_str()) == Some("rs") {
            files.push(path.to_string_lossy().into_owned());
        }
    }
    files.sort();
    files
}
