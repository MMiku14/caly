//! Documentation consistency gate.
//!
//! Runs `caly_arch_test::docs` over every Markdown file in `docs/`. The checks exist because the
//! eighth round found three defects of this kind by hand — two sections numbered `6.10` in
//! `ONBOARDING_NOTES.md`, `docs/README.md §2.5` carrying the same list number twice, and a status
//! table still claiming "19 members" (20 since `caly-io-std` was added) — and because this repo's
//! method is 「文档说 X，用命令验证 X」, which stops working the moment a doc cites a path that is
//! not there.
//!
//! `caly-arch-test` is the right home: it is already the crate that turns a stated invariant into
//! something `cargo test` enforces (`§2.5` of the onboarding notes recorded that its dependency
//! checks had zero callers; these do not).

use std::path::Path;

use caly_arch_test::docs::{
    check_crate_names, check_disposition_ledger, check_doc_index, check_heading_numbers,
    check_list_numbering, check_markdown_tables, check_path_references, check_round_claim,
    check_stray_table_rows, check_test_count_claims, check_unlisted_test_files,
    count_test_attributes, DocIssue,
};

/// Workspace root as an owned path string.
///
/// `String` rather than `PathBuf` because `clippy.toml` bans `std::path::PathBuf` workspace-wide,
/// including for the guardrail crate (`docs/ONBOARDING_NOTES.md §4.9`) — a gate that needs an
/// `#[allow]` to run is a gate that will be weakened.
fn workspace_root() -> String {
    Path::new(env!("CARGO_MANIFEST_DIR"))
        .parent()
        .and_then(Path::parent)
        .expect("workspace root is two levels above a crate directory")
        .to_string_lossy()
        .into_owned()
}

/// Every `.md` file under `docs/`, recursively, in deterministic order.
fn markdown_files(dir: &Path, out: &mut Vec<String>) {
    let mut entries: Vec<String> = match std::fs::read_dir(dir) {
        Ok(reader) => reader
            .filter_map(|entry| {
                entry
                    .ok()
                    .map(|entry| entry.path().to_string_lossy().into_owned())
            })
            .collect(),
        Err(_) => return,
    };
    entries.sort();
    for entry in entries {
        let path = Path::new(&entry);
        if path.is_dir() {
            markdown_files(path, out);
        } else if entry.ends_with(".md") {
            out.push(entry);
        }
    }
}

fn read(path: &str) -> String {
    std::fs::read_to_string(path).unwrap_or_default()
}

/// Display name of a file, relative to the workspace root, so an issue points somewhere usable.
fn display_name(path: &str) -> String {
    path.strip_prefix(&format!("{}/", workspace_root()))
        .unwrap_or(path)
        .to_owned()
}

fn workspace_member_names() -> Vec<String> {
    let dir = Path::new(&workspace_root()).join("crates");
    let mut names: Vec<String> = match std::fs::read_dir(&dir) {
        Ok(reader) => reader
            .filter_map(|entry| {
                let path = entry.ok()?.path();
                path.is_dir().then(|| {
                    path.file_name()
                        .map(|name| name.to_string_lossy().into_owned())
                        .unwrap_or_default()
                })
            })
            .collect(),
        Err(_) => Vec::new(),
    };
    names.sort();
    names
}

/// All docs, scanned once. Shared so the "the scan is not vacuous" assertion uses the same numbers.
fn scan() -> (Vec<String>, usize, usize) {
    let root = Path::new(&workspace_root()).join("docs");
    let mut files = Vec::new();
    markdown_files(&root, &mut files);
    files.sort();
    let mut references = 0usize;
    let mut lines = 0usize;
    for file in &files {
        let text = read(file);
        lines += text.lines().count();
        references += text
            .lines()
            .flat_map(caly_arch_test::docs::code_spans)
            .filter(|span| {
                span.starts_with("docs/")
                    || span.starts_with("crates/")
                    || span.starts_with("scripts/")
            })
            .count();
    }
    (files, references, lines)
}

fn report(issues: &[DocIssue]) -> String {
    issues
        .iter()
        .take(20)
        .map(DocIssue::display)
        .collect::<Vec<_>>()
        .join("\n")
}

/// A guardrail nobody can see working is not one: an empty file list, or a docs tree with no
/// references, must fail here rather than pass silently.
#[test]
fn the_doc_tree_is_actually_scanned() {
    let (files, references, lines) = scan();
    assert!(
        files.len() >= 60,
        "expected the whole docs tree, found {} files",
        files.len()
    );
    assert!(references >= 100, "only {references} path references found");
    assert!(
        lines >= 8_000,
        "docs seem suspiciously short: {lines} lines"
    );
}

#[test]
fn every_documented_path_reference_resolves() {
    let (files, _, _) = scan();
    let root = workspace_root();
    let mut issues = Vec::new();
    for file in &files {
        let text = read(file);
        let name = display_name(file);
        issues.extend(check_path_references(&name, &text, |relative| {
            Path::new(&root).join(relative).exists()
        }));
    }
    assert!(
        issues.is_empty(),
        "{} issue(s):\n{}",
        issues.len(),
        report(&issues)
    );
}

#[test]
fn doc_tables_and_lists_are_well_formed() {
    let (files, _, _) = scan();
    let mut issues = Vec::new();
    for file in &files {
        let text = read(file);
        let name = display_name(file);
        issues.extend(check_markdown_tables(&name, &text));
        issues.extend(check_list_numbering(&name, &text));
        issues.extend(check_stray_table_rows(&name, &text));
        issues.extend(check_disposition_ledger(&name, &text));
        issues.extend(check_heading_numbers(&name, &text));
    }
    assert!(
        issues.is_empty(),
        "{} issue(s):\n{}",
        issues.len(),
        report(&issues)
    );
}

#[test]
fn crate_names_in_docs_are_members_or_documented_as_absent() {
    let members = workspace_member_names();
    assert!(
        members.len() >= 20,
        "workspace members look wrong: {members:?}"
    );
    let (files, _, _) = scan();
    let mut issues = Vec::new();
    for file in &files {
        let text = read(file);
        issues.extend(check_crate_names(&display_name(file), &text, &members));
    }
    assert!(
        issues.is_empty(),
        "{} issue(s):\n{}",
        issues.len(),
        report(&issues)
    );
}

/// `docs/IMPLEMENTATION_STATUS.md §3.3` claims a per-file test census and the arithmetic to go with
/// it. Claiming 「逐行相加核对一致」 without a checker is how that table sat at 129 while the tree had
/// 168, and at 213 while it had 225 — so the claim is now computed here, from the same counting rule
/// the document names.
#[test]
fn status_table_test_counts_match_the_tree() {
    let root = workspace_root();
    let status_path = format!("{root}/docs/IMPLEMENTATION_STATUS.md");
    let status = read(&status_path);
    // Scanned as a whole document rather than sliced to §3.3, for two reasons: the reported line
    // numbers are then the ones an editor will find, and the census is the only table in the file
    // whose second column is a bare count — so slicing would only hide rows from the check.
    let section = status.as_str();

    let test_files = test_bearing_files(&root);
    let mut issues = check_test_count_claims("docs/IMPLEMENTATION_STATUS.md", section, |path| {
        let full = format!("{root}/{path}");
        std::fs::read_to_string(&full)
            .ok()
            .map(|text| count_test_attributes(text.as_str()))
    });
    issues.extend(check_unlisted_test_files(
        "docs/IMPLEMENTATION_STATUS.md",
        section,
        &test_files,
    ));
    assert!(
        issues.is_empty(),
        "the §3.3 census has drifted from the tree:\n{}",
        report(&issues)
    );
    // and the census must not be vacuously satisfied by an empty table
    assert!(
        test_files.len() >= 20,
        "expected at least 20 test-bearing files, found {}",
        test_files.len()
    );
}

/// The centerline's 「这 N 个断言是否依然成立」 is the only workspace-wide number that file carries, and
/// every round re-copies it by hand. The census has its own judge; this is the same idea for the claim
/// outside that table. It exists because round 30 found that line half-replaced by an aborted patch
/// script while every gate stayed green -- the gates check the census and the tables, and nothing read
/// this sentence.
#[test]
fn the_centerline_assertion_count_matches_the_tree() {
    let root = workspace_root();
    let file = "docs/CENTERLINE_PROGRESS.md";
    let text = read(&format!("{root}/{file}"));
    let total: usize = test_bearing_files(&root)
        .iter()
        .map(|path| count_test_attributes(&read(&format!("{root}/{path}"))))
        .sum();
    assert!(
        total >= 100,
        "the tree total has to be a real number, not an empty scan: {total}"
    );
    let issues = check_round_claim(file, &text, total);
    assert!(
        issues.is_empty(),
        "the centerline's assertion count has drifted from the tree:\n{}",
        report(&issues)
    );
}

/// The index is the entry point for the whole `docs/` tree, so it is the one document that must be
/// *complete* rather than merely well-formed. This round added `docs/CONTINUATION_PLAYBOOK.md`, and the
/// only thing standing between a new document and "nobody ever reads it" is this check.
#[test]
fn the_document_index_lists_every_top_level_document() {
    let root = workspace_root();
    let docs = Path::new(&root).join("docs");
    let mut names: Vec<String> = std::fs::read_dir(&docs)
        .expect("docs directory must be readable")
        .flatten()
        .filter_map(|entry| {
            let path = entry.path();
            if !(path.is_file() && path.extension().and_then(|ext| ext.to_str()) == Some("md")) {
                return None;
            }
            path.file_name()
                .map(|name| name.to_string_lossy().into_owned())
        })
        .collect();
    names.sort();
    let index_path = format!("{root}/docs/README.md");
    let issues = check_doc_index("docs/README.md", &read(&index_path), &names);
    assert!(
        issues.is_empty(),
        "`docs/README.md` and the document tree disagree:\n{}",
        report(&issues)
    );
    assert!(
        names.len() >= 30,
        "the scan found {} top-level documents; below that this check is reading an empty directory",
        names.len()
    );
}

/// Paths (relative to the workspace root) of every file with at least one `#[test]` attribute.
fn test_bearing_files(root: &str) -> Vec<String> {
    let mut out = Vec::new();
    collect_test_files(&format!("{root}/crates"), &mut out);
    out.sort();
    out
}

fn collect_test_files(dir: &str, out: &mut Vec<String>) {
    let mut entries: Vec<String> = match std::fs::read_dir(dir) {
        Ok(reader) => reader
            .filter_map(|entry| entry.ok().map(|e| e.path().to_string_lossy().into_owned()))
            .collect(),
        Err(_) => return,
    };
    entries.sort();
    for entry in entries {
        let path = Path::new(&entry);
        if path.is_dir() {
            collect_test_files(&entry, out);
        } else if entry.ends_with(".rs") {
            let text = read(&entry);
            if count_test_attributes(&text) > 0 {
                let relative = entry
                    .strip_prefix(&format!("{}/", workspace_root()))
                    .unwrap_or(&entry)
                    .to_owned();
                out.push(relative);
            }
        }
    }
}
