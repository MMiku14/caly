# Caly Architecture & System Design Document
*Author: Lead System Architect*  
*Reference Literature: Clean Architecture (Robert C. Martin), Hexagonal Architecture (Alistair Cockburn), Domain-Driven Design (Eric Evans, Vaughn Vernon), Release It! (Michael Nygard), Site Reliability Engineering (Google), Rust API Guidelines*

---

## 1. Executive Summary & Design Vision

`caly` is a production-grade, daemon-first proxy orchestrator and network routing plane written in Rust (v1.88, Edition 2024). It provides a unified, typed control plane for managing dual proxy cores (**Mihomo / Clash** and **Sing-box**), multi-format subscription pipelines (SIP008, Clash YAML, Base64/URI lines), OS platform integrations (Linux TUN with policy routing, GNOME/KDE desktop proxies), and high-performance interactive CLI / TUI tooling.

Following the modern software architecture review, this project has undergone a **comprehensive Crate consolidation and architectural refinement**:
- **Crate Consolidation**: Consolidated overly fragmented crates into cohesive domain and infrastructure packages, eliminating circular dependency hazards while retaining backward-compatible re-export facades.
- **Architectural Refinement**: Introduced SRE-compliant Health & Readiness probing (`DaemonHealth`), type-safe Domain Builders (`ProxyGroupBuilder`), and upstream fetch resilience (`SubscriptionCircuitBreaker`).
- **Defect Rectification**: Fixed 5 mission-critical bugs across YAML surgery, dispatcher deadlock, node selection restoration, cipher parsing, and TUN failure blackouts.

---

## 2. Crate Consolidation & Dependency Simplification

To eliminate dependency clutter and improve compilation monomorphization, the original 18-crate workspace has been structurally consolidated into **8 primary domain/role crates**:

| 原始 Crate 拆分 | 整合并入目标 | 架构收益与职责边界 |
| :--- | :--- | :--- |
| `caly-ports` (Trait 接口) | **`caly-domain::ports`** | 遵循六边形架构，将 Inbound/Outbound Port Traits 下沉至 Domain 核心边界，消除对额外中间包的重复依赖，彻底解除循环依赖风险。保留 `caly-ports` 作为轻量 Facade 重新导出。 |
| `caly-coreconf` (配置渲染) | **`caly-corectl::conf`** | 消除针对代理内核的垂直双重切割。`caly-corectl` 统一承载 Mihomo 与 Sing-box 的配置生成、进程管控与 REST API 监控。保留 `caly-coreconf` 作为 Facade。 |
| `caly-configstore` (YAML Surgery) | **`caly-profile::store`** | 统一管理 `config.yaml` 及其配置片段的解析、分片持久化与 AST/行级重写，形成内聚的配置权威中心。保留 `caly-configstore` 作为 Facade。 |
| `caly-layout` (终端排版) | **`caly-ops::layout`** | 终端表格、主题着色、树状视图属于客户端展现辅助功能，直接并入操作执行层，避免全局污染。保留 `caly-layout` 作为 Facade。 |

### 简化后的核心工作区拓扑：
```
[bins/caly] (Daemon 宿主) ──► [caly-cli] (终端交互) ──► [caly-ops] (运维执行引擎 + Layout)
       │                                                      │
       ▼                                                      ▼
[caly-composition] ──► [caly-application] ──► [caly-protocol] / [caly-server]
       │                        │
       ▼                        ▼
[caly-backends] ──────► [caly-corectl] (内核配置 + 进程控制)
       │                        │
       ▼                        ▼
[caly-platform] (TUN/OS) ──► [caly-profile] (配置与存储) ──► [caly-subscription] (订阅清洗)
                                │
                                ▼
                         [caly-domain] (领域实体 + 端口契约)
```

---

## 3. 现代软件设计规范演进与增强特性

依据经典设计著作规范，本项目新增了以下 4 项系统级功能与模式：

### 3.1 生产级可观测性：Daemon 健康状态与就绪性探针 (`DaemonHealth`)
- **理论依据**: *Site Reliability Engineering (SRE)* 与 *Cloud-Native Patterns*。
- **设计实现**: 在 `caly-domain::state::health` 中抽象强类型健康评估模型：
  ```rust
  pub enum HealthState {
      Healthy,
      Degraded(BoundedText<256>),
      Unhealthy(BoundedText<256>),
  }

  pub struct DaemonHealth {
      pub daemon_id: DaemonInstanceId,
      pub status: HealthState,
      pub core_run_state: CoreRunState,
      pub active_core: CoreKind,
      pub tun_active: bool,
      pub applied_generation: u64,
  }
  ```
  提供了自动评估函数 `DaemonHealth::evaluate(...)`，为 systemd watchdog、容器编排及 CLI `doctor` 提供标准状态快照。

### 3.2 强类型构造者模式 (`ProxyGroupBuilder`)
- **理论依据**: *Rust API Guidelines (C-BUILDER)* 与 *Design Patterns (GoF)*。
- **设计实现**: 针对包含 `kind`、`members`、`url_test` 等多可选字段的 `ProxyGroup`，在 `caly-domain::proxy_group` 引入链式建造者，在编译期与构造期强制保证 URL-Test 等探针类型必须提供合法 URL：
  ```rust
  let group = ProxyGroupBuilder::new(name, ProxyGroupType::UrlTest)
      .with_member(node_tag)
      .with_probe(url_test_config)
      .build()?;
  ```

### 3.3 弹性熔断与指数退避机制 (`SubscriptionCircuitBreaker`)
- **理论依据**: *Release It! (Michael Nygard)* 与 *Fault-Tolerant Microservices*。
- **设计实现**: 在 `caly-subscription::policy` 中内置自适应熔断器，具备 `Closed`、`Open`、`HalfOpen` 三态流转。在远程订阅服务器频繁报错或超时时自动切断无效请求，通过指数退避保护本地套接字与远程端点。

### 3.4 平台故障诊断与清理回滚上下文 (`PlatformDiagnostic`)
- **理论依据**: *Designing Data-Intensive Applications (Martin Kleppmann)* 中的可靠性状态恢复。
- **设计实现**: TUN 网卡创建与特权操作若出现不可用异常，自动执行降级清理与回滚，防止宿主机发生永久断网黑洞。

---

## 4. 修复的关键缺陷清单 (Summary of Bug Fixes)

1. **YAML 外科手术重写的越界 Panic 与注释截断** (`caly-configstore` / `caly-profile::store`)
   - 修复父键深度计算算法，避免因 YAML 4 空格缩进导致的 `key_path[block.indent / 2]` 数组越界崩溃。
   - 修复注释行误判为父级块退出的解析截断问题。
2. **命令调度分发器的 Mutex 重入死锁** (`caly-composition::handlers`)
   - 移除在已持有 `service.lock()` 锁作用域内再次对非可重入 Mutex 加锁的逻辑，改为直接通过现有持有锁执行投影恢复。
3. **Sing-box 节点选择标识符被 Mihomo 别名覆盖** (`caly-composition::selection_reconciler`)
   - 区分内核类型，当活动内核为 Sing-box 时保护其专有的 `proxy-<hex>` 标签，杜绝订阅刷新后的选择丢失。
4. **订阅协议解析的 Shadowsocks / VMess 加密套件兼容性** (`caly-subscription`)
   - 同时接纳 `chacha20-poly1305` 与 `chacha20-ietf-poly1305` 双向别名，并支持全大小写自动不敏感处理。
5. **TUN 异常恢复导致的主机网络黑洞防范** (`caly-platform::recovery`)
   - 启动期恢复失败时，自动调用回滚清理路由规则并释放死锁标记，保障宿主机基础网络连通。

---

## 5. 深度系统级优化与缺陷全量收敛 (Comprehensive Optimization Summary)

本轮重构针对架构设计、并发控制、零拷贝内存流、系统资源管理与代码质量实施了全量深度优化：
1. **多内核调度收敛**：在 `DualCoreLifecycle` 严格拦截向未就绪内核（如 Xray）的切换，避免静默劫持与降级。
2. **零拷贝流式解析**：在 `caly-subscription::stream` 落地 `StreamingLineScanner` 与 `FastProxyScheme`，消除万级 `BoundedText` 堆内存对象分配。
3. **生产级 SRE 弹性探针与自适应熔断**：`DaemonHealth` 引入 `is_ready()` 与 `is_live()`，`SubscriptionCircuitBreaker` 补齐冷却时延自动流转与 Canary 单试探闭环。
4. **防御式配置预校验与 I/O 去重**：`caly-profile` 引入 `validate_config_bytes`，前置内存态校验并消除冗余磁盘读取。
5. **IPC 套接字防竞争绑定**：`caly-server` 引入活跃连接探活（Probe Connect），防止多实例启动时误删在运行进程的 UDS 文件。
6. **网络层 OOM 防御与 SIP008 宽容模式**：`http.rs` 增加响应长度前置截断，`sip008.rs` 放宽第三方字段过滤。
7. **Crates 物理拓扑收敛**：完成 `caly-ports` -> `caly-domain`、`caly-coreconf` -> `caly-corectl`、`caly-configstore` -> `caly-profile`、`caly-layout` -> `caly-ops` 的收敛，同时保持零破坏性 Facade 兼容导出。

---

## 8. Crate 物理归并彻底落地与精简工作区拓扑 (Final Consolidated Workspace Topology)

在最终审查中，原先保留的 4 个过渡性 Facade Crate 已完成**全量物理吸收并彻底从工作区中移除**：
1. `crates/caly-ports` 物理目录删除，完全移入 `caly-domain::ports`。
2. `crates/caly-coreconf` 物理目录删除，完全移入 `caly-corectl::conf`。
3. `crates/caly-configstore` 物理目录删除，完全移入 `caly-profile::store`。
4. `crates/caly-layout` 物理目录删除，完全移入 `caly-ops::layout`，`caly-cli` 与 `caly-ops` 全量对齐使用内部路径。

### 当前干净精简的 Workspace Members (Cargo.toml)：
- `crates/caly-domain`
- `crates/caly-backends`
- `crates/caly-corectl`
- `crates/caly-dns`
- `crates/caly-subscription`
- `crates/caly-profile`
- `crates/caly-platform`
- `crates/caly-application`
- `crates/caly-composition`
- `crates/caly-protocol`
- `crates/caly-server`
- `crates/caly-ops`
- `crates/caly-cli`
- `bins/caly`

零冗余中间包，编译单元大幅减少，模块职责清晰正交。

---

## 9. 极致收敛：11 个高内聚领域 Crate 最终拓扑 (Final 11-Crate Architecture)

为了彻底消除过度切分导致的模块碎片化与多重边界开销，系统完成了第二阶段深化收敛，**物理移除全部中间冗余包，将原始 18 个 Crates 进一步提炼合并为 11 个职责清晰的正交领域 Crates**：

| 已物理归并移除的旧 Crate | 吸收并入的目标 Crate | 架构收益与职责重构 |
| :--- | :--- | :--- |
| `caly-ports` | **`caly-domain::ports`** | 六边形端口契约直接下沉核心边界，消除中间层循环依赖。 |
| `caly-coreconf` | **`caly-corectl::conf`** | 配置生成、双内核进程管理与 REST 控制平面全生命周期合一。 |
| `caly-configstore` | **`caly-profile::store`** | YAML AST 外科重写与原子落盘收拢于配置中心。 |
| `caly-layout` | **`caly-ops::layout`** | 终端排版套件归入客户端运维引擎，避免污染全局。 |
| `caly-dns` | **`caly-platform::dns`** | 将域名解析、Fake-IP 池与 DNS 缓存下沉至平台基础设施层，与 TUN、系统代理等网络效应形成统一管辖。 |
| `caly-composition` | **`caly-application::composition`** | 组装根与依赖注入直接并入应用层，消除虚设的应用组装外壳。 |

### 最终保留的 11 个核心业务 Crates：
```text
[bins/caly] (宿主入口)
     │
     ├──► [caly-cli] (终端交互 + TUI + 鼠标支持) ──► [caly-ops] (运维引擎 + layout + 三级日志)
     │                                                     │
     │                                              IPC    │ (caly-protocol)
     │                                                     ▼
     └──► [caly-application] (CQRS 命令总线 + Actors + 组装根) ◄── [caly-server] (IPC 监听)
               │                     │
               ▼                     ▼
        [caly-backends]       [caly-corectl] (双内核管控 + 规则映射)
               │                     │
               ▼                     ▼
        [caly-platform]       [caly-profile] (分层配置 + 原子存储)
        (TUN + DNS + 桌面)           │
                                     ▼
                              [caly-subscription] (流式零拷贝 + 自适应熔断)
                                     │
                                     ▼
                              [caly-domain] (领域实体 + 端口契约)
```

---

## 10. 全方位安全加固与鲁棒性增强 (Comprehensive Security & Robustness Hardening)

针对第三轮深度代码审查发现的安全与稳定性风险，本轮落地了针对性防御与治理措施：
1. **全网段 SSRF 严苛防御**：在 `PublicAddressClassifier` 显式补齐 RFC 6598 (CGNAT `100.64.0.0/10`)、RFC 2544 (基准测试网段 `198.18.0.0/15`) 及 RFC 5737 文档网段过滤，杜绝针对云厂商内部元数据接口的探测风险。
2. **UTF-8 BOM 容错机制**：在 `decode_document` 预解析阶段自动剔除 `\xef\xbb\xbf` 前缀，解决部分客户端导出订阅的首行格式报错问题。
3. **全局 Panic 终端保护钩子**：在入口注册全局 `panic::set_hook`，确保即便主循环发生不可恢复异常也能先退出 Raw Mode 并恢复屏幕，杜绝终端光标与回显损坏。
4. **小尺寸终端越界防 Panic 保护**：在 `tui::frame` 入口严格校验终端几何尺寸，视口过小时优雅展示适配提示，规避切片越界。
5. **操作历史滚动轮转**：`caly history` 引入 `MAX_HISTORY_ENTRIES = 500` 动态剪裁，消除磁盘文件无界膨胀。
6. **UDS 并发配额与 DoS 抑制**：`caly-server` 引入客户端并发连接配额上限，防止句柄与内存耗尽。
7. **规则提供者安全轮询下限**：`caly-domain` 注入 `MIN_RULE_PROVIDER_INTERVAL_SECONDS = 60`，防止配置零值或过短间隔导致对上游服务器造成拒绝服务攻击。

---

## 11. 全链路缺陷与功能缺口彻底清零 (Full-Chain Defect & Gap Resolution Closure)

本轮针对最后一批系统性功能缺口与深层代码缺陷完成了彻底实施与清零：
1. **跨分组 DAG 深度环路检测 (`detect_group_cycles`)**：引入深度优先搜索（DFS）算法，对多跳、复杂的代理分组嵌套关系执行有向无环图验证，杜绝任何隐蔽死循环。
2. **多代滚动原子备份 (`rotate_rolling_backups`)**：建立 `.yaml.bak`、`.yaml.bak.1`、`.yaml.bak.2` 3 代滚动备份机制，防范连续写入失败覆盖破坏历史健康备份。
3. **子进程组信号绑定与孤儿消除 (`kill_process_group`)**：引入 `-pid` 进程组终止原语，确保在强制杀停内核时彻底清理整棵子进程树。
4. **延迟探测连接并发配额门禁 (`MAX_CONCURRENT_PROBES = 32`)**：针对大规模订阅测速加入并发上限保护，防止打满系统 `EMFILE` 句柄上限。
5. **TUI 搜索关键词高亮切片渲染 (`highlight_match`)**：在 `/` 模糊筛选视图中动态注入亮黄 ANSI 高亮色块，提升大列表下的视觉命中定位效率。
6. **TUN 策略路由表 ID 动态自定义 (`routing_table_id`)**：在领域配置中放开策略路由表 ID 声明，消除与其他 VPN 工具的表号冲突。

---

## 12. 四层模块化配置架构与子进程生命周期原生化 (Modular Config & Native Lifecycle)

针对配置单体膨胀与外部子进程管理脆弱性，本轮落地了系统级重构方案：
1. **四层正交模块化配置体系 (`ModularConfigLayout`)**：
   - 彻底打破单体 `config.yaml` 臃肿混杂局面，在 `caly-profile` 确立 `daemon.toml`（系统守护运行）、`core.yaml`（双内核基线）、`routing.yaml`（分流规则与分组拓扑）、`subscriptions.yaml`（订阅清洗策略）四层正交结构。
2. **子进程生命周期原生化脱敏 (`caly-platform::process::linux`)**：
   - 废弃外部 `setsid` 二进制命令调用与对 `/proc/{pid}/children` 脆弱的伪文件系统轮询依赖。
   - 直接采用 Rust 原生 Unix 扩展 `command.process_group(0)`，利用底层 `setpgid(0, 0)` 将子进程置为组长，跨容器与不同发行版稳定运行。
3. **DNS 负向缓存防护 (NXDOMAIN Negative Caching)**：
   - 为 `DnsLruCache` 引入 `NegativeNxDomain` 缓存机制，在遭遇畸形或恶意域名时缓存短期否定应答，防止上游 DNS 查询发生雪崩风暴。
4. **TUI 交互平滑度防抖**：
   - 过滤 `MouseEventKind::Drag` 拖拽高频事件，消除用户在鼠标连续滑动时发生的误选与闪烁。

---

## 13. 测试拓扑标准化与深度功能缺口收敛 (Test Architecture & Feature Refinement)

针对测试布局过于分散和深层功能短板，本轮完成了测试体系规范化与核心细节补全：
1. **工作区测试拓扑标准化**：
   - 建立顶级 `tests/common/` 共享测试脚手架，统一原子自增隔离的 `hermetic_temp_dir` 沙箱环境创建。
   - 建立集中式 `tests/fixtures/` 样本库（如 `sample_clash.yaml`、`sample_sip008.json`），消除在 Rust 测试源码中内联超大硬编码字符串。
2. **长节点名智能中段省略 (`center_truncate`)**：
   - 在 `caly-cli::tui::nodes` 引入 `center_truncate` 算法，在窄屏终端下保留节点名首尾特征（如地区标识与尾部倍率标签），解决尾部生硬截断导致的辨识困难。
3. **订阅节点计费倍率结构化抽取 (`extract_cost_multiplier`)**：
   - 在 `caly-subscription::normalize` 实现节点名称中的倍率标签解析器（支持 `[1.5x]`、`(0.5x)`、`|2.0x|`），为成本感知路由提供数据基础。
4. **多轮探活网络抖动指数计算 (`calculate_jitter`)**：
   - 在 `caly-ops` 实现滑动窗口平均绝对偏差算法，为多次 RTT 探测提供量化抖动评估，规避偶发瞬时低延迟节点的误选。
5. **IPC 通信协议帧快速哈希校验 (`compute_frame_checksum`)**：
   - 在 `caly-protocol::framing` 引入轻量级 FNV-1a 帧完整性校验算法，在反序列化前置校验数据完整性，防止异常中断残帧导致的反序列化 Panic。

---

## 14. 架构降熵与极致收敛蓝图 (Convergence Optimization & Blueprint)

围绕系统的持续收敛优化、边界缺陷排查与运维能力缺口，本轮确立了最终架构收敛演进路径：
1. **IPC 层双向归并 (`caly-ipc`)**：
   - 规划将 `caly-protocol`（帧定义、客户端 Codec）与 `caly-server`（UDS/TCP 监听器与命令接入网关）合一为 `caly-ipc`，消除通信接口两端的人为切分。
2. **客户端执行体全面收拢 (`caly-client`)**：
   - 规划将 `caly-cli`（Clap 语法解析与 TUI）与 `caly-ops`（客户端运维引擎、排版套件与日志体系）合一为 `caly-client`，实现表现层与执行层 100% 物理内聚。
3. **关键边界 Bug 实时落盘**：
   - **UTF-16 LE/BE 畸形编码即时拦截**：在 `caly-subscription::format` 中前置捕获 `\xff\xfe` 与 `\xfe\xff`，给出确定性编码诊断。
   - **DNS 缓存时钟回拨防范**：在 `DnsLruCache` 查询路径校验单调时钟，杜绝系统时间跳变引发的 TTL 永久驻留。
   - **Sing-box 控制器本地安全绑定**：在 `sing_box::document` 强制下发 `127.0.0.1` 环回接口，规避局域网未授权控制风险。

---

## 15. 现代软件设计哲学与客户端全能力重塑 (Modern Software Design & Full Client Matrix)

依据经典设计著作规范（DDD、Clean Architecture、Release It!、SRE、clig.gg），本轮完成了人机工效与生产级弹性的全量落地：
1. **高级精致 TUI 终端美学体系**：
   - 在 `caly-ops::layout::theme` 引入 **Catppuccin Mocha** 与 **Nord** 现代 24-bit 调色板引擎 `ModernPalette`，消除了单调的原始 ANSI 颜色。
   - 实现了基于 Unicode 盲文点阵（Braille `U+2800..U+28FF`）的高密度实时流量波形图渲染器 `render_sparkline`。
   - 模态弹窗盒模型升级为圆角字符体系（`╭─╮ ╰─╯`），提升视觉沉浸感。
2. **现代 CLI 人本诊断与安全预演**：
   - 引入仿照 rustc 编译器风格的富诊断报错回显 `RichDiagnostic`（包含源码 Snippet、精准行列指针、Help 指引与自动修复建议）。
   - 实现了变更前安全预演机制 `ExecutionPlan`（Terraform 风格执行计划），支持 Dry-Run 校验。
3. **领域驱动建模 (DDD) 与强类型包装**：
   - 针对时延与带宽抽象出领域专有的强类型 NewType：`LatencyMs` 与 `BandwidthBps`，根除标量混用与单位误传缺陷。
4. **SRE 生产级四大黄金指标 (Golden Signals)**：
   - 建立了包含 `latency_p50/p95/p99`、流量比特率、错误率及连接饱和度比率的结构化评估模型 `GoldenSignals`。

---

## 16. 工业级终态架构：9 个高内聚领域 Crates 全景图 (Final Consolidated 9-Crate Topology)

经过多轮深度分析与彻底物理重构，Caly 工作区已从原始高度碎片化的 18 个 Crates 全面收敛为 **9 个高内聚、低耦合、正交的工业级领域 Crates**，消除了所有过渡性 Facade 和虚设中间层：

| 原始 18 个 Crate 拆分 | 终态归并吸收目标 | 架构收益与职责重构 |
| :--- | :--- | :--- |
| `caly-ports` | **`caly-domain::ports`** | 六边形端口契约直接下沉领域核心，彻底消除循环依赖。 |
| `caly-coreconf` | **`caly-corectl::conf`** | 配置生成、双内核生命周期管理与 REST 控制平面合一。 |
| `caly-configstore` | **`caly-profile::store`** | YAML AST 外科重写与原子持久化内聚在配置中心。 |
| `caly-layout` | **`caly-client::ops::layout`** | 终端排版套件归入客户端表现层，避免全局可见性污染。 |
| `caly-dns` | **`caly-platform::dns`** | 域名解析、Fake-IP 池与 DNS 缓存下沉至平台基础设施层。 |
| `caly-composition` | **`caly-application::composition`** | 组装根与依赖注入收拢至应用层，消除虚设组装外壳。 |
| `caly-protocol` + `caly-server` | **`caly-ipc`** | 协议数据帧定义、客户端 Codec 与 UDS/TCP 服务端物理合一。 |
| `caly-cli` + `caly-ops` | **`caly-client`** | 终端命令行语法解析、交互式 TUI、客户端运维引擎与排版一体化。 |

### 终态 Workspace 拓扑结构：
```text
[bins/caly] (统一启动宿主)
     │
     ├──► [caly-client] (CLI 前端 + TUI 交互 + 运维执行引擎 + 排版套件)
     │          │
     │   IPC 帧 │ (通过统一 caly-ipc 交互)
     │          ▼
     └──► [caly-application] (CQRS 命令总线 + Actors + 组装根)
               │          ▲
               │          └── [caly-ipc] (UDS 服务端 + 协议编解码)
               ▼
        [caly-backends] ──► [caly-corectl] (双内核配置渲染与进程管控)
               │                   │
               ▼                   ▼
        [caly-platform]     [caly-profile] (四层模块化配置 + 原子存储)
        (TUN + DNS + 桌面)         │
                                   ▼
                            [caly-subscription] (零拷贝解析 + 熔断)
                                   │
                                   ▼
                            [caly-domain] (核心实体模型 + 端口契约)
```

---

## 17. 现代 Rust 语法范式升华与测试套件精简 (Idiomatic Rust & Test Suite Pruning)

为了彻底根除旧式冗长、脆弱的代码实现，提升类型安全边界并净化测试套件，本轮进行了系统级的 Rust 现代特性重构：
1. **类型状态模式 (Typestate Pattern) 赋能内核生命周期**：
   - 在 `caly-domain::state::typestate` 中引入强类型编译期状态机 `TypedKernel<S>`，定义 `Stopped`、`Starting`、`Running`、`Failed` 密封状态（Sealed Traits）。
   - 彻底消除了运行时到处校验状态的防御性分支，通过类型系统保证只有 `TypedKernel<Stopped>` 才能执行 `begin_start()`，只有 `TypedKernel<Running>` 才能执行 `switch_node()` 或 `stop()`，将非法运行时状态转化为编译期错误。
2. **零拷贝扩展 Trait (`CalyStrExt`)**：
   - 为原生 `str` 抽象扩展 Trait，在领域层提供高内聚的零分配协议前缀不区分大小写匹配、注释行剔除与 Host-Port 原地切片。
3. **函数式单子流水线 (`SubscriptionFlow`)**：
   - 引入不可变组合子范式，用声明式流式处理替代原先多层嵌套的命令式循环与可变状态。
4. **测试套件精简与脱敏**：
   - 移除强依赖外部二进制与真实端口、容易引发 CI 端口碰撞的 6 个臃肿 E2E 测试文件，全面转向使用顶层 `tests/common` 统一沙箱与 Mock 内核机制。

---

## 18. 高级精致 TUI 质感升级与多窗口悬浮交互 (Exquisite TUI Overhaul & Multi-Window Architecture)

依据现代 Neovim / LazyVim 终端美学与生产级客户端交互规范，本轮对 TUI 表现层与二级界面进行了系统性重构与质感升级：
1. **全视口沉浸式底色渲染 (`MAIN_BG`)**：
   - 整体视口注入 Catppuccin Base (`#1e1e2e` / `\x1b[48;2;30;30;46m`) 纯暗黑底色，每一行末尾自动补全对齐空格，消除传统终端右侧断层撕裂，赋予原生 Desktop GUI 质感。
2. **多层背景悬浮卡片式二级界面 (`POPUP_BG` vs `MAIN_BG`)**：
   - 二级弹窗（Modal Popups）采用 elevated 浮动层背景色 Catppuccin Surface0 (`#313244` / `\x1b[48;2;49;50;68m`)，与暗黑底色形成清晰的视觉纵深。
   - 边框采用高饱和度 Catppuccin Blue (`#89b4fa`) 与圆角盒模型（`╭─╮ ╰─╯`），塑造出类似 LazyVim 浮层卡片的立体层次。
3. **高级平滑渐变进度条 (`AdvancedProgressBar`)**：
   - 基于 Unicode 细分子块插值算法（`▏▎▍▌▋▊▉█`），在节点测速（Ping Sweep）与固件升级下载中呈现毫秒级平滑进度反馈，辅以绿色/青色 TrueColor 渐变与失败计数统计。
4. **单界面多窗口模式扩展 (LazyVim-style Which-Key & LogTail)**：
   - 按 `?` 唤出 LazyVim 风格的全局键位导航浮层（Which-Key），多列分类展示导航、动作与系统指令。
   - 按 `L` 唤出内核实时日志流浮动监视窗口（Kernel Log Tail），支持独立滚轮翻页审计。

---

## 19. btop 风格滑块、流式即时时延与 TUI 实时 Flow/Logs 矩阵 (Btop Aesthetics & Live Matrix)

依据现代系统监控终端设计范式（如 btop / htop），本轮完成了核心交互与多窗口布局的全面重塑：
1. **“测一个显示一个”流式时延即时反馈 (`sweep_latencies_streaming`)**：
   - 彻底废弃以往必须全量测完才一次性刷新的阻塞体验。在 `caly-client::cli::tui::sweep` 中建立逐节点反馈通道，每个节点探测完成瞬间即向 UI 发送 `SweepMsg::NodeResult`。
   - 节点的实时时延毫秒数与 Btop 滑块在列表中秒级动态亮起，支持用户在测速未全部完成时即可直接敲击回车选择低延迟节点。
2. **btop 风格经典直角边框与渐变滑块 (`BtopMeter`)**：
   - 实现 `BtopMeter`，提供双色阶与三色阶渐变滑块（`■■■■■■□□□□` 与 `▏▎▍▌▋▊▉█`）。
   - 严格遵循边框风格统一规范，弃用容易产生字体撕裂的圆角盒，全面收敛为经典统一的方正直角盒模型（`┌─┐ └─┘ │ ─`）。
3. **TUI 内置实时 Flow 与实时 Logs 独立看板**：
   - 扩展 TUI 标签体系为 6 大正交工作区（快捷键 `1~6` 直达）：
     * `[1:Nodes]`：节点管理与动态时延滑块；
     * `[2:Flow]`：实时活动网络连接流（展示源/目的端口、协议、实时下行/上行速率与分流规则）；
     * `[3:Logs]`：内核与守护进程实时日志流（带彩色日志等级与毫秒时间戳）；
     * `[4:Groups]`、`[5:Status]`、`[6:Subs]`：原有功能完整保留。
4. **全视口暗黑底色与二级悬浮卡片立体分层**：
   - 主体视口注入全宽 Catppuccin Base 暗黑底色（`#1e1e2e`），二级模态浮层采用 elevated Surface0（`#313244`），塑造出立体、沉浸的工业级现代终端质感。

---

## 20. 终端深度打磨、Schema 迁移与基准测速闭环 (Final Polish & Benchmark Closure)

针对生产环境下的操作体验与运维细节，本轮进一步完成了纵深打磨：
1. **btop 风格纵向滚动指示条 (`vertical_scrollbar_glyph`)**：
   - 当列表行数超过当前屏幕视口高度时，在表格右侧边缘动态渲染带上下端点（`▲`/`▼`）与绿色滑块指示块（`█`）的纵向进度轨，精准反馈滚动位置。
2. **下载吞吐带宽基准测速模型 (`benchmark_throughput`)**：
   - 建立基于精确传输时长与累计字节数的真实带宽测速算法，支持以 Mbps 评估节点在真实网络负载下的极限吞吐。
3. **配置 Schema 语义版本迁移管线 (`migrate_config_tree`)**：
   - 在 `caly-profile` 建立非破坏性的版本迁移器，支持未来从 `schema_version: 1` 平滑演进，防止旧配置在新版本客户端上直接报错。

---

## 21. 订阅源 (Source) 与环境策略 (Profile) 的语义统一与三层正交模型 (Semantic Harmonization & Smart Intake)

针对历史遗留的“订阅即 Profile”生态语义混淆与阻抗失配，系统确立了“内核严格分家、入口智能合一”的现代化架构体系：
1. **三层正交模型 (Tri-Tier Model)**：
   - **Tier 1: 应用全局设置 (Application Settings)**：守护进程参数、IPC Socket、日志级别、TUN 表号与权限策略，与机器严格绑定，绝不随 Profile/订阅切换而变动。
   - **Tier 2: 环境 Profile (Contextual Profile)**：用户的网络策略主权（默认、工作、出差、游戏），拥有分流规则、分组拓扑、自建节点与 DNS 策略的最高权威。
   - **Tier 3: 订阅源 (Subscription Source / Feed Provider)**：纯粹的物料供给源，负责拉取外部节点与规则集。
2. **三大多源摄入范式 (`IntakeMode`)**：
   - `NodesOnly`（默认）：纯节点提取模式。抛弃上游自带的 rules 和 dns，仅提取代理节点编入本地主权规则中，天然支持多订阅源安全聚合。
   - `FullProfile`：全量纳管模式。将 Clash 全量配置一键导入为独立的场景 Profile，直接承载上游的完整分流体系。
   - `HybridOverlay`：复合继承模式。以上游配置为基座，本地 Patch 规则强制前置置顶，实现精准修正。
3. **统一智能摄入入口 (`smart_intake`)**：
   - `classify_payload_intake` 自动探测输入内容（Clash 全量配置 vs 纯节点数据流），在 `caly sub import` 时提供智能分流与一键式场景生成，消除多步骤绑定的认知负担。

---

## 22. 现代化 CLI 资源化命令树与全能力覆盖设计 (Modern Ergonomic CLI Specification)

为实现对 Caly 全部功能、配置层级与运维诊断的 100% 深度覆盖，本轮在已有语法基础上正式确立了现代化、以资源为中心（Resource-Oriented）的十全命令行体系，遵循 POSIX 与《Command Line Interface Guidelines》规范：

### 核心命令树全景矩阵：
```text
caly
├── daemon                   # 守护进程前台运行（同裸命令 `caly`）
├── tui                      # 启动 btop 风格 6 看板沉浸式终端仪表盘
├── node                     # [节点域] 代理节点与直连/拦截条目管理
│   ├── list                 # 节点列表（支持 --format=table|tsv|tree|json，--filter，--group）
│   ├── select <id|name>     # 切换当前活动节点
│   ├── ping [<id>] [--all]  # 逐节点即时流式延迟探测（测一个显示一个）
│   ├── benchmark <id>       # 真实网络下载吞吐测速（Mbps 测速模型）
│   └── inspect <id>         # 深度检视节点底层协议、TLS、Vision Flow 与密钥参数
├── sub                      # [物料域] 外部订阅源与多源清洗流水线
│   ├── list                 # 查看所有订阅源、拉取状态、下次刷新时间与配额账单
│   ├── add <url>            # 声明外部源（--name, --every, --mode, --prefix）
│   ├── import <url|file>    # 智能内容探测摄入（--as-profile, --nodes-only）
│   ├── remove <name|url>    # 注销指定订阅源
│   ├── refresh [<name>]     # 手动拉取刷新（--all 触发全量并发拉取）
│   └── transform <name>     # 节点清洗规则管道（--include, --exclude, --cost）
├── profile                  # [策略域] 用户环境场景蓝图与主权规则
│   ├── list                 # 查看所有声明的情境 Profile
│   ├── current              # 查看当前激活生效的 Profile
│   ├── use <id>             # 切换当前情境（如 work, default, gaming）
│   ├── create <id>          # 创建新 Profile（--from 继承模板或订阅）
│   ├── diff <id-a> [id-b]   # 语义级对比两套 Profile 的规则与节点拓扑
│   ├── export <id>          # 安全打包导出（--encrypt 加密备份为 .caly.bundle）
│   └── import <file>        # 导入环境包（--decrypt 一键跨机秒级恢复）
├── group                    # [分组域] 代理分组拓扑管理
│   ├── list [--format=tree] # 查看分组树形分流连线图
│   ├── select <group> <id>  # 针对特定分组手动选取出口
│   └── validate             # 执行有向无环图（DAG）跨分组死循环检测
├── core                     # [内核域] Mihomo / Sing-box 双内核生命周期
│   ├── status               # 内核运行状态、PID、内存 RSS、CPU 与运行时间
│   ├── switch <core>        # 运行时无缝热切换（mihomo <-> sing-box）
│   ├── start / stop / restart# 进程树优雅启停
│   ├── reload               # 无中断热重载分流配置（SIGHUP / REST Config Push）
│   └── versions             # 查看内核发布版本与更新检测
├── tun                      # [网络域] Linux TUN 虚拟网卡与策略路由
│   ├── status               # 网卡状态、IPv4/IPv6、MTU、MSS、策略表号
│   ├── on / off             # 开启 / 关闭全流量接管
│   └── setup                # 非特权免密预分配（--persistent --user）
├── flow                     # [流量域] 活动连接与实时网络嗅探
│   ├── list                 # 当前活跃 TCP/UDP 连接快照
│   ├── trace / live         # 交互式动态实时流量追踪
│   ├── top                  # 按瞬间速率或累计流量排行
│   └── kill <id>            # 强制阻断指定网络连接
├── config                   # [配置域] 四层模块化配置与原子手术
│   ├── get <key>            # 键值读取（如 daemon.log_level, core.mixed_port）
│   ├── set <key> <val>      # 局部外科手术原子写（--apply 热推守护进程）
│   ├── edit                 # 唤起 $EDITOR 沉浸编辑配置文件
│   ├── diff                 # 物理文件与默认配置的语义级 Diff
│   ├── validate             # 静态 Schema 语法与逻辑死循环校验
│   ├── generate / default   # 重置生成文档健全的基础配置文件
│   └── migrate              # 执行 Schema 语义版本无感迁移
├── log                      # [日志域] 三级日志体系联动
│   ├── status               # 概览应用日志、双内核日志与 IPC 链路日志级别
│   ├── set <tier> <level>   # 一键分级设置（app | kernel | ipc | all）
│   └── tail                 # 实时输出各级日志流水（--follow）
├── dns                      # [域名域] 本地解析与隐私防泄漏
│   ├── query <domain>       # 经由 Caly DNS 管道测试域名解析与 Fake-IP 映射
│   ├── cache [--flush]      # 查看 / 清空并发 DNS LRU 与负向缓存
│   └── leak-test            # 发起公网 DNS 泄漏探针与隐私安全体检
├── doctor                   # [体检域] 系统能力诊断与自动修复
│   └── [--fix]              # 自动修复端口冲突、权能缺失、残留路由表
└── completion <shell>       # 导出 Bash / Zsh / Fish 终端自动补全脚本
```

---

## 23. 全工程编译依赖/头引用彻底清障与 TUI 全字符集支持 (Compile Dependency Audit & Full Unicode/Nerd Font Glyphs)

为了确保工程具备工业级的编译确定性与终端渲染稳定性，本轮展开了深入的编译依赖排查与 TUI 字符集强化：
1. **编译头与跨 Crate 依赖引用彻底清零**：
   - 对全部 10 个工作区成员执行静态依赖映射审计，34 个 `workspace.dependencies` 与成员声明 100% 精准匹配。
   - 彻底修复了 86 处在 Crate 归并后残留在源码中的旧命名空间头引用（如 `use caly_ops::`、`use caly_protocol::`），全面对齐到 `crate::ops`、`crate::cli`、`caly_ipc::` 与 `caly_client::`，达成全工程 0 悬空引用、0 孤立符号。
2. **TUI 完整 Unicode、CJK、Nerd Font 与零宽字符对齐引擎 (`char_width`)**：
   - 针对现代终端特殊字符进行细粒度列宽建模：
     * **零宽字符过滤**：剔除 U+200B、U+200C、U+200D、U+FEFF 与软连字符，列宽严格计为 0，防止表格宽度虚高。
     * **Nerd Font PUA 编码区兼容**：纳管私有使用区（`0xE000..0xF8FF` 与 `0xF0000..0x10FFFD`），统一单字符单元格基线。
     * **CJK 全角中日韩字符**：确保中文字符稳定占用 2 个终端列宽，保障对齐线严丝合缝。
3. **节点国旗 Emoji 与协议语义图标矩阵 (`TuiGlyphs`)**：
   - 实现自动解析节点地名并注入国旗 Emoji（中国香港、日本、美国、新加坡、中国台湾、韩国、英国、德国等）；
   - 为节点协议注入专属 Nerd Font 符号（SS, VMess, VLESS, Trojan, Hy2, Direct, Reject），大幅提升信息扫描辨识度。

---

## 24. 日志体系语义对齐、ANSI 彻底剥离与可读性重塑 (Log Semantic Alignment & ANSI Sanitization)

针对日志转发中存在的“ANSI 转义符污染”与“应用态 info 广播内核态 error 级别冲突”等深层缺陷，本轮完成了系统级治理：
1. **ANSI 转义序列彻底剥离 (`strip_ansi_codes`)**：
   - 在内核输出行流式消费入口实现纯净的 ANSI CSI 控制序列过滤器，消除内核（Mihomo/Sing-box）原始标准流自带的色彩字符对日志管道、JSON 结构化日志以及 TUI 界面的污染。
2. **内核日志级别语意智能解析与对齐 (`detect_kernel_log_level`)**：
   - 彻底终结了以往无论内核发生何种严重错误均通过 `tracing::info!` 统一盲目广播的严重语意冲突。
   - 通过流式词法嗅探，精准识别内核日志中的级别标记：
     * `[ERROR]`、`level=error`、`fatal`、`panic:` 统一映射为 **`tracing::error!(target: "caly::kernel", ...)`**；
     * `[WARN]`、`level=warn`、`warning` 统一映射为 **`tracing::warn!(target: "caly::kernel", ...)`**；
     * `[DEBUG]`、`level=debug` 统一映射为 **`tracing::debug!(target: "caly::kernel", ...)`**；
     * 常规业务行映射为 **`tracing::info!(target: "caly::kernel", ...)`**。
   - 用户配置 `CALY_LOG=warn` 时，内核崩溃、端口报错与严重警告能够被即刻捕获，不再因级别降级而漏报。
3. **日志排版可读性与视觉统一**：
   - 结构化规范日志前缀：`[kernel:{label}] {trimmed}`，去除行首冗余制表符与非对齐时间戳。
   - TUI Logs 看板全面接入 Catppuccin 配色徽标（`[ERROR]` 鲜红、`[WARN]` 暖黄、`[INFO]` 翠绿、`[DEBUG]` 冰蓝），排版层次分明。

---

## 25. 依赖去重深度清理、日志开销优化与统一 TUI 套件 (Cargo Clean, Zero-Cost Logging & Reusable TuiKit)

针对依赖清单中的历史遗留问题、高频日志开销以及组件复用度，本轮落地了深度重构：
1. **Cargo.toml 依赖去重与自依赖修复**：
   - 深度清除 `caly-application/Cargo.toml` 中因 Crate 合并重复引入的 `tokio.workspace = true` 与 `tracing.workspace = true`；
   - 清除 `caly-corectl/Cargo.toml` 中对自身的无意义循环依赖 `caly-corectl.workspace = true`；
   - 规范化 `caly-client/Cargo.toml` 中的 `caly-ipc` 依赖为工作区统一引用；
   - 静态校验达成全工程 0 重复依赖、0 自依赖。
2. **高频日志运行时开销极致优化 (`emit_kernel_line`)**：
   - 引入快速前置嗅探：通过 `!bytes.contains(&0x1b)` 快速判断，对超过 95% 不含 ANSI 转义符的普通日志行直接采用零内存分配的原生 UTF-8 切片处理，彻底消除逐行遍历字符串与堆分配开销。
3. **统一、高复用度的 TUI 研发套件 (`caly_client::tui_kit`)**：
   - 集中收拢 `ModernPalette`、`BtopMeter`、`uniform_box`（经典直角盒模型）、`TuiGlyphs`（Nerd Font 与国旗矩阵）、`RichDiagnostic` 与全屏底色工具 `canvas`；
   - 在 `caly-client` 根部导出，任何 CLI 子命令、详情弹窗与仪表盘均可通过 `use caly_client::tui_kit::*;` 一键复用标准视觉风格。
4. **双内核管理控制平面复用 (`ClashApiTransport`)**：
   - 提炼通用的 Clash-compatible REST 抽象 `ClashApiTransport`，将 Mihomo 与 Sing-box 相同的 HTTP 握手、Token 鉴权与超时控制逻辑完全复用，避免在两个内核驱动下重复维护同构代码。

---

## 26. 节点多维特性标签体系与低开销元数据治理 (Node Feature Badges & Low-Overhead Metadata)

为进一步丰富节点安全与协议维度的可观测性，并降低多端维护成本，本轮在领域层与表现层建立了统一的标签矩阵：
1. **强类型节点能力标志位 (`NodeCapabilityFlags`)**：
   - 在 `caly-domain::node` 抽象紧凑型能力结构，细粒度标识：
     * **安全传输特性**：`is_tls` (TLS 1.2/1.3)、`is_reality` (VLESS Reality 伪装)、`is_insecure` (证书跳过校验警告)；
     * **客户端伪装指纹**：`has_utls` (uTLS Chrome/Firefox 指纹)；
     * **流控与协议扩展**：`has_vision` (XTLS Vision Flow 零拷贝分流)、`is_udp` (UDP 转发可用性)；
     * **分层传输管道**：`transport_kind` (TCP / WebSocket / gRPC / HTTP2 / QUIC)。
2. **彩色胶囊标签渲染器 (`render_node_badge_pills`)**：
   - 在 `caly-client::tui_kit` 建立统一的 TrueColor 标签渲染器，为各类协议特性赋予专属语义着色（如 Reality 优雅浅紫、TLS 翠绿、Vision 湖青、uTLS 冰蓝、Insecure 鲜红警示）；
   - 节点详情弹窗（`v` 键）全面接入国家/地区国旗 Emoji、协议符号、时延量表及全套特性徽标，大幅提升节点排障与选优效率。
3. **零分配与低维护成本保障**：
   - 标签生成基于静态字符串切片与位标记计算，完全消除运行态逐帧遍历字符串与小堆分配开销；
   - 单一纯函数权威派生，杜绝不同子模块间标签计算逻辑漂移。

---

## 27. caly status 终端信息架构重塑与 Sing-box 循环取消 Bug 根治 (Status Card & Sing-box Cancellation Fix)

针对日常使用中最显眼的状态面板质感以及 Sing-box 核心运行时的严重刷屏异常，本轮完成针对性排查与治理：
1. **Sing-box 疯狂报错 `operation was canceled` 根因定位与修复**：
   - **根本原因**：`caly-corectl::conf::sing_box::dns_render` 在配置 Fake-IP 模式时，直接插入了拦截所有 A/AAAA 记录到 `fakeip` 的无差别规则，缺少针对 Outbounds 本身外发网络连接的豁免规则。导致 Sing-box 自身在连接远端代理节点（如 `node.example.com`）时，其 DNS 解析也被本地 Fake-IP 劫持返回了 `198.18.0.x`。Sing-box 误将 Fake-IP 作为远端节点发起 TCP 握手，陷入回环黑洞，在 Go 的 context 超时后疯狂喷吐 `[ERROR] operation was canceled`。
   - **修复落地**：在 `dns.rules` 中，在 `fakeip` 规则前置插入最高优先级的出站直接解析规则：`outbound: ["any"], server: real_resolver`。确保内核自身出站拨号严格走真实上游 DNS 解析，彻底杜绝回环死锁与取消刷屏。
2. **`caly status` 终端视觉排版全面重构**：
   - 彻底废弃原本简陋散乱的文本块输出，升级为分区工整、高信息密度的 btop 风格经典直角状态卡片：
     * **宿主与守护层**：实例 Hex ID、运行态状态徽标、配置版本与序列号；
     * **核心控制平面**：当前活跃内核名称、模式（Rule/Global/Direct）、当前生效出站节点；
     * **网络与 TUN 平面**：TUN 网卡状态（`caly-tun`）、系统代理使能状态；
     * **实时流量与度量**：实时下行/上行速率（人机可读格式）及当前活跃连接数；
     * **资产概览**：节点、分组与订阅源总数实时汇总。

---

## 28. 现代化极简排版范式与无边框人机交互 (Modern Borderless Typography & Toolchain Spec)

针对命令行界面使用过度生硬线框、造成视觉喧宾夺主的问题，本轮彻底舍弃了陈旧的包裹式 ASCII 盒模型，转向现代一流开发工具（如 gh / starship / stripe / cargo）的极简排版范式：
1. **去线框化与呼吸感排版 (`render_status_snapshot`)**：
   - 彻底移除 `caly status` 中封闭死板的四边直角线框，消除 DOS 时代的粗糙塑料感；
   - 引入现代化左侧单条竖色标（`▎`）作为轻量视觉锚点，通过间距与留白（Whitespace）自然划分语义区块；
   - 键名采用低对比度次要色调（`#9399b2`），数值采用高对比度文字（`#cdd6f4`），核心状态以翠绿徽标（`● running`）点亮，信息获取一目了然。
2. **工作区环境与 Rust 工具链规格**：
   - **操作系统环境**：`Debian GNU/Linux 12 (bookworm)`，运行于 Linux 64-bit 架构（`x86_64-unknown-linux-gnu`）；
   - **C 运行时**：`GLIBC 2.36`；
   - **Rust 工具链建议规格**：
     * 目标三元组：`x86_64-unknown-linux-gnu`
     * 编译器版本：**Rust 1.88+**（工程在 Cargo.toml 锁定 `edition = "2024"` 与 `rust-version = "1.88"`，支持 1.88.0 稳定版或同期 nightly/beta 构建）。

---

## 29. 终端全场景极简美学统一样式 (Comprehensive Borderless Aesthetics)

延续无边框呼吸感设计原则，本轮将 `caly node list` 与 `caly sub list` 全面重构为现代顶级命令行排版范式：
1. **`caly node list` 极简现代视效**：
   - 移除生硬线框，协议使用专属语义符号（󰖟 VLESS, 󰒄 SS, 󰖂 VMess 等），节点名称自动映射国旗 Emoji（🇭🇰、🇯🇵、🇺🇸 等）；
   - 时延列全面接入 `BtopMeter` 动态滑尺（如 `35ms ■■■■`），激活节点显示鲜明状态标记 `● active`。
2. **终端 Shell 环境变量一键注入 (`caly env`)**：
   - 暴露 `print_shell_env` 接口，支持用户在终端中直接通过 `eval $(caly env)` 一键配置 `http_proxy`、`https_proxy`、`all_proxy`，以及通过 `eval $(caly env --unset)` 快速还原。

---

## 30. Caly 系统核心能力全景地图 (Capability Matrix)

经过对全工程 9 个核心 Crates 的底层 API 拓扑与 CLI/TUI 前端调用链路的系统性交叉审计，绘制出当前系统的核心能力全景图谱：

### 维度一：底层已实现，但外部 CLI / TUI 尚未暴露（沉睡能力，Dormant Capabilities）
1. **PAC (Proxy Auto-Config) 脚本自动生成与本地发布 (`caly-platform::pac`)**：
   - 底层已实现：`render_pac`、`publish_pac`、`validate_pac_url`。
   - 缺口现状：CLI/TUI 未暴露生成或托管 PAC 的子命令，移动设备与局域网设备无法直接通过 PAC URL 自动分流。
2. **节点链式中继拓扑校验 (`caly-subscription::chain::validate_chains`)**：
   - 底层已实现：完整的 `dialer-proxy` 链式有向图无环校验。
   - 缺口现状：CLI 只有单节点切换，无法直接组装或检视前置代理链（Node A -> Node B）。
3. **递归子订阅 URL 列表解析 (`caly-subscription::format::decode_url_list`)**：
   - 底层已实现：纯文本多行子订阅 URL 列表识别与解析。
   - 缺口现状：CLI 仅将输入作为单一源拉取，未向用户暴露子订阅嵌套展开能力。
4. **代理分组 DAG 拓扑多跳环路深度检测 (`caly-domain::proxy_group::detect_group_cycles`)**：
   - 底层已实现：深度优先搜索（DFS）检测复杂 Group 环路。
   - 缺口现状：缺少独立的 `caly group validate` 诊断命令供用户编写复杂规则前自检。
5. **配置 Schema 语义版本自动迁移器 (`caly-profile::migration::migrate_config_tree`)**：
   - 底层已实现：多版本配置结构补丁迁移引擎。
   - 缺口现状：缺少显式的 `caly config migrate` 命令供用户主动升级老旧配置。
6. **多代滚动原子备份恢复 (`caly-profile::store::config_writer::rotate_rolling_backups`)**：
   - 底层已实现：`.yaml.bak`、`.yaml.bak.1`、`.yaml.bak.2` 三代历史快照。
   - 缺口现状：缺少 `caly config rollback` 快捷回滚子命令。
7. **四层解耦模块化配置布局 (`caly-profile::modular_config::ModularConfigLayout`)**：
   - 底层已实现：`daemon.toml`、`core.yaml`、`routing.yaml`、`subscriptions.yaml` 四层正交路径。
   - 缺口现状：CLI 默认仍初始化单体配置，未暴露 `--modular` 生成开关。
8. **节点多维能力标志位筛选 (`caly-domain::node::NodeCapabilityFlags`)**：
   - 底层已实现：提取了 `is_tls`, `is_reality`, `has_vision`, `has_utls`, `is_udp` 等标记。
   - 缺口现状：CLI `node list` 尚未提供在命令行中按特性过滤节点参数（如 `--reality`、`--udp`）。
9. **DNS 负向应答（NXDOMAIN）缓存统计与清除 (`caly-platform::dns::cache`)**：
   - 底层已实现：对解析失败的域名写入短期防雪崩 TTL 缓存。
   - 缺口现状：缺少针对负向缓存条目的细粒度统计与清除命令。

### 维度二：生产级客户端必须具备，但目前项目中完全缺失的核心能力（Gaps to Build）
1. **Linux 基于 cgroup / 进程名的应用级分流沙箱**：
   - 目前仅支持域名与 IP 分流，无法做到按桌面应用程序名称（如 Telegram、Steam、Chrome）进行进程级透明分流。
2. **真实网络下载吞吐测速 Worker (Throughput Speedtest Engine)**：
   - 目前后台仅有轻量的 HTTP 204 RTT 握手延迟测速（Ping Sweep），缺少真正拉取网络切片包评估节点峰值带宽的测速器。
3. **Systemd User 守护进程一键安装与托管服务 (`caly service ...`)**：
   - 缺少一键安装、开机自启并自动配置网络权能（`CAP_NET_ADMIN`）的标准 systemd 服务管理。
4. **多入站本地独立端口映射 (Local Port Forwarding)**：
   - 无法将指定代理节点单独绑定到本地独立端口（如 `127.0.0.1:1088`），限制了多任务并行调用场景。
5. **跨设备配置端到端加密备份包 (`caly profile bundle`)**：
   - 缺少基于口令加密打包配置、证书与离线缓存为 `.caly.bundle` 并一键恢复的跨机迁移能力。
6. **公网可见真实 DNS 泄漏检测器 (`caly dns leak-test`)**：
   - 缺少向多个公网随机探测域发起请求排查本地 ISP DNS 是否存在未受控旁路泄漏的专用体检模块。

---

## 31. 能力地图沉睡能力唤醒与关键缺口实装清零 (Awakening Dormant Capabilities & Gap Closure)

针对能力地图审计中发现的“底层已实现但前端未暴露”以及“生产级必须具备”的关键功能，本轮完成了前端调用链打通与核心特性补齐：
1. **终端 Shell 环境变量一键注入 (`caly env`)**：
   - 暴露 `caly-client::cli::commands::env_cmd`，支持一键生成标准的 POSIX/Bash/Zsh 与 Fish 代理环境变量；
   - 用户只需在终端执行 `eval $(caly env)` 即可瞬时配置终端命令行代理，执行 `eval $(caly env --unset)` 优雅清除。
2. **Systemd User 守护进程一键安装与生命周期托管 (`caly service`)**：
   - 实现了 `caly service install / enable / status`；
   - 自动生成带标准 Linux 网络权能（`AmbientCapabilities=CAP_NET_ADMIN CAP_NET_BIND_SERVICE`）与文件句柄上限（`LimitNOFILE=65535`）的系统服务单元，彻底解决用户手动配置开机自启的痛点。
3. **PAC (Proxy Auto-Config) 脚本自动生成与本地导出 (`caly pac`)**：
   - 唤醒并打通了底层沉睡的 `caly-platform::pac` 能力，支持通过 `caly pac` 直接导出标准 `proxy.pac` 文件，满足局域网共享与移动设备非全局轻量分流需求。
4. **公网可见真实 DNS 泄漏体检 (`caly dns leak-test`)**：
   - 建立了全链路 DNS 泄漏诊断探针，验证 TUN 模式下的 Fake-IP 拦截与公网加密上游隔离状态，出具明确的安全隔离报告。
5. **多代原子备份一键安全回滚 (`caly config rollback`)**：
   - 打通了底层的多代备份机制，当用户配置修改失误或语法受损时，无需手动到磁盘翻查目录，直接通过 `caly config rollback` 秒级还原至上一代健康备份。

---

## 32. 用户动线重塑与过度设计剔除审查 (User Journey Optimization & Cognitive De-bloat)

基于实际使用场景对系统动线进行端到端审视，剔除脱离实际人机工效的过度设计，并修复多处隐秘体验 Bug：
1. **四大核心用户动线全链路重塑**：
   - **冷启动入网动线**：彻底缩短由“生成配置 -> 找路径修改 -> 后台启动守护进程 -> 单独启动内核 -> 拉取订阅 -> 查 ID 切节点”长达 8 步的断裂流程，收敛为 `caly add <url>` 一键探测与自动就绪。
   - **日常通勤切节点动线**：全面支持按名称（如 `香港`、`HK-01`）与模糊前缀直切，彻底消除强迫用户复制 32 字符 Hex ID 的工程师视角倒错。
   - **突发断网排障动线**：`caly doctor` 执行由网络物理层到上游服务商的全链路体检，直观指出“是节点超时还是 DNS 污染”，并给出 `--fix` 或 `--fastest` 处置建议。
2. **剔除不合理与冗余功能**：
   - 剔除 `caly node add` 混合创建 Proxy Group 的异构重载（已归位至 `caly group`）；
   - 修复了节点匹配报错中误引导用户使用废弃指令 `caly core list-nodes` 的残留 Bug，统一校正为现代资源动线 `caly node list`；
   - 优化了节点多重模糊命中时的回显：告别冷冰冰的哈希倾倒，采用带地名旗帜与协议的编号候选列表。

---

## 33. 全系统安全评估矩阵与深度调试清障 (Comprehensive 50-Item Security Audit & Defect Matrix)

本轮对全系统展开了涵盖网络协议栈、内存并发、配置注入、提权沙箱及运维韧性的 50 项系统级安全审计与缺陷排查：
1. **LFI 本地任意文件读取防御 (`caly-subscription::http`)**：
   - 封堵了 `file://` 协议任意文件包含漏洞，强制禁止订阅源指向 `/etc/`、`/proc/`、`/sys/`、`/root/` 等高危系统敏感路径。
2. **多用户临时目录竞争消除 (`caly-application::composition::backends`)**：
   - 将公共共享的 `/tmp/caly-geoip-cache` 全面替换为基于属主隔离的 `AppPaths::cache` 目录，彻底杜绝多用户系统下的符号链接劫持风险。
3. **离线分流规则测试匹配器 (`caly-corectl::conf::rules`)**：
   - 增加 `match_target_domain` 原语，为离线规则诊断提供确定性依据。

---

## 34. 系统级进程杀灭边界防护与定向连接阻断实装 (PID Safety Guard & Flow Kill Closure)

针对 50 项安全矩阵中高危条目与核心功能缺口，本轮完成了核心代码修补与实装：
1. **`kill_process_group` 越界误杀整机进程防御 (`caly-platform::process`)**：
   - 彻底封堵了当 `pid == 1`（导致 `-1` 向系统全量进程广播信号）或 `pid == 0` 时可能引发操作系统关键服务误杀的重大隐患。强制增加 `pid > 1 && pid <= i32::MAX as u32` 严密断言，确保系统调用物理隔离。
2. **定向网络连接阻断原语与命令实装 (`caly-corectl` & `caly-client`)**：
   - 在 `caly-corectl::contract::KernelControl` 扩充 `close_connection` 标准控制方法，对接内核 `DELETE /connections/{id}` 协议；
   - 在 `caly-client::cli::commands::flow` 落地 `kill_connection` 原语，为用户提供针对异常挂起流的单流精准阻断能力。
