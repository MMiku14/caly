# Changelog

## [0.1.8] - 2026-09-01（流式 END failure_code 轮，ADR-058）

### 新增

- **流 END 帧携带 `failure_code`**（OPERATOR_SCENARIO_REPORT 发现 #6，先 ADR 后动 wire）：
  终局为 failed 且作业携带公共失败码时，END 帧加可选 `failure_code` record（与 `jobs.follow`
  同拼写、同一来源）；`caly follow` 与 `apply --wait` 的流式失败按该码落精确退出码
  （如 CONFLICT→4、PERMISSION→8），缺失→1（旧行为不变）、未识别→13——同一失败作业经
  `caly job` / `caly follow` / `apply --wait` 三条路径退出同一数字（`docs/adrs/ADR-058`）。

### 变更

- daemon：`app.job_failure_code()` 从 `JobRecordSummary.failure_code` 取码（jobs.follow 同源），
  calyd 的 END 帧写者仅在 `outcome=Failed` 时附码（成功/取消/超时终局永不带码）。
- CLI：`stream_end_exit_code` 的 Failed 臂经 `from_wire_refusal_code` 路由（同一公共码表）；
  非 Failed 终局上的杂散码一律忽略（判决是 outcome，码只细化 Failed）。
- 纯字段可加扩展：无 wire 版本升级、无 journal 格式迁移（码已耐存在 ADR-057 记录里）；
  旧 daemon 不发即降级 exit 1。
- 门禁 census 897→902（caly_cli_e2e 57→60、calyd_wire 47→48、dependency_direction 26→27）；
  `scripts/archive/falsify_round116.py` 五变异（daemon 不发码 / CLI 判决不读码 / 每次 END 都编码 /
  识别码猜成功 / 缺码猜成功）全 BIT。

---


Caly 的变更记录。2026-09-01 之前上游没有 git 历史（zip 上传），此前的逐轮明细在
`docs/history/logs/`；本文件从文档重整这一轮起记录，每段按「新增 / 修复 / 变更」三类列条目，
并注明依据（测试名或门禁名）。

---

## [0.1.7] - 2026-09-01（apply --wait 轮）

### 新增

- **`caly apply <id> --idempotency-key <k> --wait`**（OPERATOR_SCENARIO_REPORT 发现 #5）：
  acceptance 三字段照打，随后**同一会话**开 follow 流把事件照打、按流判决退出码
  （Succeeded 0 / Failed 1 / Cancelled 15 / TimedOut 11 / 状态缺口 14），`--wait --json` 同语义。
  纯 CLI 组合——协议不动，仍是同一连接上的两个请求（`ONBOARDING_NOTES §4.189`）。

### 变更

- `follow_stream` 拆为握手 + `follow_stream_after_hello`：`caly follow` 与 `--wait` 共用同一份
  流循环（二次握手会撞 ClientLoop 状态机；两份实现必漂移）。
- `--wait` 只属于 apply：其他动词上它是 usage（exit 2），不做「静默无效的旗标」。
- 门禁 census 893→897（caly_cli_e2e 53→57）；`scripts/archive/falsify_round115.py` 四变异
  （wait 半程被删 / apply 恒跟流 / 流判决被丢 / 归属守卫被关）全 BIT。

## [0.1.6] - 2026-09-01（订阅管道用户面轮）

### 新增

- **`caly sources` / `caly source <id>`**（OPERATOR_SCENARIO_REPORT 发现 #3）：
  wire `sources.list`/`sources.inspect` 上线（`WIRE_OPERATION_NAMES` 14→16）；列表的注册表 =
  worker 端点（`--source-endpoint` 注册 ∪ durable index 恢复）∪ profile workflow 引用，
  **注册端点未拉取即列得出**；单源视图带 locator/route/etag/digest/节点数/诊断/来源，
  未拉取的 durable 事实在 wire 上显式为空（CLI 渲染为 `never`）。
- `sources.inspect` 契约收窄为注册表语义：表外 id 按 `no such source: <id>`（CONFLICT，exit 4）
  点名拒绝，列表与查询同源一致（R113 profiles 契约的 sources 版，`ONBOARDING_NOTES §4.188`）。

### 变更

- `source_summaries` 不再只读 apply 的 workflow 投影（否则订阅注册在列表里永远不可见）；
  `source_inspection` 的「任意 id 合成视图」fallback 删除（旧代码还借 profile workflow 的
  warning_count 当自己的警告数，现已归零）。
- 门禁 census 890→893（calyd_wire 45→47、caly_cli_e2e 52→53）；door sweep 加两个 source op；
  `scripts/archive/falsify_round114.py` 四变异（去守卫任意答 / 恒拒 / 拒绝码换 Internal /
  列表丢端点注册表）全 BIT。

## [0.1.5] - 2026-09-01（profiles.get 假成功修复轮）

### 修复

- **`caly profile <不存在>` 不再假成功**（OPERATOR_SCENARIO_REPORT 发现 #1）：`profiles.get`
  契约收窄为注册表语义（`default-profile` ∪ active，与 `profiles` 列表同源）——表外 id 按
  `no such profile: <id>`（CONFLICT，exit 4）点名拒绝，列表与查询两面对齐（round-46 占位
  语义被自家裁判钉成契约，`ONBOARDING_NOTES §4.187`）。
- `no_such_job` 的 remediation 文案「job history is not durable」→「terminal job history
  survives restarts (ADR-057)」（R109 之后旧文案是假话）。

### 变更

- 两条旧语义裁判更新为新契约（calyd_wire `profiles_get_refuses_a_missing_id_and_an_unknown
  _profile_but_answers_registered_ones`、caly_cli_e2e `caly_profile_refuses_an_unknown_id_and
  _prints_the_view_for_a_registered_one`）；`scripts/archive/falsify_round113.py` 三变异
  （去守卫任意答 / 恒拒 / 拒绝码换 Internal）全 BIT。
- census/floor 持平 890（改裁判非新增）；OPERATOR_SCENARIO_REPORT 发现 #1/#2 标记已修。

## [0.1.4] - 2026-09-01（使用场景报告 + CLI --role 轮）

### 新增

- `docs/engineering/OPERATOR_SCENARIO_REPORT.md`：全产品用户面实测（五场景：新网关上线 /
  订阅接入 / 变更回滚 / kill -9 故障演练 / 脚本化运维），逐条原始输出与退出码，7 条
  用户面发现（含 `caly profile <不存在>` 假成功、订阅导入黑盒等）。
- **CLI `--role viewer|operator|admin`**（P1 分权可达性）：`drive_client_hello` 接角色参数
  （typed config 与 hello 字节同源），`caly` 旗标解析（坏值 usage exit 2、默认 admin 保兼容）。
  实测 `--role viewer gc` → PERMISSION/exit 8、`--role viewer status` → 正常。
- e2e 四胎裁判（`caly_cli_e2e` 48→52）：viewer 读+拒写 / operator 拒写 / 坏角色 usage /
  admin 默认反空转；`scripts/archive/falsify_round112.py` 三变异全 BIT。

### 修复

- `scripts/archive/falsify_round110.py` 与 `falsify_round112.py`：还原后的 mtime bump 移到
  **每次 restore 之后立即执行**——放循环外会让下一变异复用上一变异的构建产物
  （round-112 首跑自咬，`ONBOARDING_NOTES §4.186`）。

### 变更

- census 886→890、TEST_FLOOR 890、CENTERLINE 886→890；FEATURES §4.4/§8、
  JOB_FLOW_SCENARIO_REVIEW（§2.4/P1）、JOB_FLOW_COST_BENEFIT_REPORT 同步分权落地状态。

## [0.1.3] - 2026-09-01（Job/Flow 成本收益评估轮）

### 新增

- `docs/engineering/JOB_FLOW_COST_BENEFIT_REPORT.md`：以纯用户面重跑「部署日」全链的实测记录
  （原始输出+退出码），按模块核算代码量（生产 ≈3.5–4.5k 行）、测试份额（≈13–15%）、决策文档
  与轮次投入（≈25 轮），给出分级必要性判定与「主体冻结 + 三个小缺口（CLI --role / END 帧
  failure_code / apply 同步组合面文档化）+ 轮次转向（P2、§13#3）」的结论。

### 修复

- `docs/guides/FEATURES.md §3.2`：删掉过时「注意」行（仍称跨重启持久化为未做项）——R109/R110
  已落地，实测 kill -9 重启后 jobs/job/翻页/follow 全命中。
- `docs/engineering/JOB_FLOW_SCENARIO_REVIEW.md`：加姊妹篇指路横幅。

## [0.1.2] - 2026-09-01（ADR-057 切片 4：真二进制耐久裁判轮）

### 新增

- `crates/caly-daemon/tests/calyd_wire.rs` +2（43→45）：**ADR-057 §5 切片 4 的两条承诺裁判**
  `a_terminal_job_survives_a_kill_9_restart_and_answers_every_query_surface`（apply→SIGKILL→同
  data-dir 重启→`jobs.list`/`jobs.events`/`jobs.follow` 三查询面全命中）与
  `a_gc_collect_cycle_never_reclaims_the_durable_job_history`（真实 collect 后历史仍可答，钉住
  GC 收集路径不触碰 job-log 的边界）；harness 基建 `Daemon.kill_9()` / `spawn_daemon_in(data_dir)`
  / `keep_dir_on_drop`。
- `scripts/archive/falsify_round110.py`：三变异（启动不恢复 / 终态不落盘 / collect 吞历史）全 BIT。

### 变更

- `docs/adrs/ADR-057-job-event-durability.md` §5：切片 1/2/4 标注落地状态，切片 3 剩 support
  bundle 收录作业轨迹。
- ADR-057 状态同步：`docs/adrs/README.md`、`docs/status/ROADMAP.md`、`docs/guides/FEATURES.md`、
  `docs/engineering/JOB_FLOW_SCENARIO_REVIEW.md`、`docs/status/IMPLEMENTATION_STATUS.md` §3.3、
  `docs/history/ONBOARDING_NOTES.md`（§4.184 + 处置行 6.136）。
- `scripts/check.sh` 的 `TEST_FLOOR` 884→886；CENTERLINE 断言数 884→886。
- 重建 git 仓库（`.git` 未随工作区快照存活；内容无损，以本基线提交为唯一历史起点）。

### 修复

- `scripts/archive/falsify_round110.py`：还原 mtime 会让 cargo 把变异构建的二进制当最新，
  首次全量门禁因此跑在 M3 污染的产物上（`caly_cli_e2e` gc 裁判红）；脚本现在在全部变异
  跑完后对还原文件 `os.utime(path, None)`，强制后续构建从干净源码重编（`ONBOARDING_NOTES
  §4.184`）。
- `crates/caly-cli/tests/caly_cli_e2e.rs`：oracle 断言失败时打印 refusal 正文（此前只有
  kind 5 vs 4 两个数字，排查无从下手）。

## [0.1.1] - 2026-09-01（文档重整与开发范式轮）

### 新增

- 根 `README.md`（项目入口：是什么、快速开始、文档地图）。
- `docs/` 六目录结构（`guides/`、`rfcs/`、`adrs/`、`status/`、`engineering/`、`history/`），
  取代原先 40+ 份文档平铺 + 根目录两份重复旧规格的布局。
- `docs/guides/DEVELOPMENT_WORKFLOW.md`：新的开发范式（git 分支模型、Conventional Commits、
  七步循环、门禁清单），取代旧的 `CONTINUATION_PLAYBOOK.md`（已归档 `docs/history/`）。
- `scripts/regenerate_doc_index.py`（+`--check`）：`docs/README.md §1` 树生成器。
- `.github/workflows/ci.yml`：CI 与本地 `scripts/check.sh` 同一套门禁（此前仓库无任何 CI）。
- `.gitignore`；`docs/history/logs/README.md` 逐轮日志索引。
- 门禁 `the_document_index_lists_every_document`（递归版，取代只查顶层的旧版）。

### 修复

- `crates/caly-engine/tests/job_log_durability.rs`：交付物中 4 处编译错误（缺 lifetime、
  私有常数、不存在的方法、类型失配）——交付物此前 `cargo test` 无法编译通过。
- **钉死资产恢复**：交付物把 `assets/` 打成空目录，真核测试全红。新增
  `scripts/fetch_assets.sh` 按 sha256 恢复 mihomo v1.19.30 / sing-box 1.13.20（与测试钉死的
  `cf06ce2c…`/`646bc01b…` 逐字节一致）；geo 数据上游只保留滚动 `latest`，原钉死的快照已无
  任何存档可获取，故**本轮故意重钉** `geoip.metadb`/`geosite.dat` 为当前上游构建
  （`real_core.rs` 内注明，旧钉值保留在 `docs/history/ONBOARDING_NOTES.md`）。资产不入 git
  （`.gitignore`），CI 经 cache + fetch 恢复。
- census 漂移两行（`job_log_durability` 4→5、`job_log_contract` 2→3）——交付物中
  `status_table_test_counts_match_the_tree` 是红的。
- CENTERLINE 断言数 882→884（`the_centerline_assertion_count_matches_the_tree` 是红的）。
- `docs/adrs/README.md` 缺 ADR-051 ~ ADR-057（表与文件清单已补）。
- 根目录重复文件 `Caly_Architecture_RFC.md`（与 `docs/rfcs/RFC-0001-core-architecture.md`
  逐字节相同）与旧草稿 `Caly_Unified_Architecture.md` → 归档 `docs/history/legacy/`。
- 打包残留 `.profile` 从树中移除。

### 变更

- 全仓 `cargo fmt`；`fmt` 从 advisory 变为 `check.sh` 硬门禁（格式欠账归零）。
- `check.sh` 的 `TEST_FLOOR` 882→884（与实测一致）。
- `docs/` 引用全面更新为新路径（约 128 个文件）；`scripts/falsify_round*.py` 等一次性脚本
  移入 `scripts/archive/`。
- `docs/README.md` 重写：目录职责、阅读路径、权威级别、维护规则。
