# Changelog

## [0.1.27] - 2026-09-02（ADR-062 记录目录分片：拒启悬崖拆除+首个生产迁移链）

### 新增

- **ADR-062 分片记录布局**：六个记录目录统一一级哈希桶（桶=转义文件名 sha256 前 2 hex，路径即主张、不假设 digest 语法）；单桶 cap 4096 ⇒ 每族上限 ≈105 万条（旧平铺=4096 全族即拒启）。4097 对象重开正常（量选 F1 悬崖退役）；单桶超限仍具名拒启。
- **首个生产 schema 迁移链**（v1→v2，ADR-061 §2.4 分工兑现）：纯 rename 迁桶（幂等）+回退点；calyd bootstrap 接线。保真修复：新鲜度探针与回退点桶感知；`records/job-log` 补入回退目录集。
- **裁判五胎**（sharded_records）：落桶布局/4097 重开/单桶 cap 具名拒/迁移零丢失+回退点+不重迁/错桶按名拒；falsify 四变异全 BIT（开发中另咬住迁移钩子后缀哈希真 bug）。

### 变更

- census 978→**982**（+5 −1 退役悬崖裁判）、floor 982；clippy 持平 31；R135 基线补记分片遍历开销（7.0→7.1-9.3 calls/obj，随 N 摊薄）；量选工装 cliff rung 改写。

## [0.1.26] - 2026-09-02（storage 量选：工装+基线+悬崖行为钉）

### 新增

- **storage 量选工装**（`cargo run -p caly-storage --example sizing_bench --release`）：确定性 fixture+真盘 StdFs，计数/字节两条阶梯测 build/reopen/list/plan，墙钟配 SimFs 孪生 port-call 计数；计数进门禁、计时进报告（R128 教义）。
- **行为钉两裁判**（perf_regression）：4097 个对象→下次 open 具名拒启（点名条目数/上限/目录）；96→1536 十六倍对象重开 port calls 保持线性（原 48 对象线裁判的量级扩展）。
- **基线报告** `docs/engineering/STORAGE_SIZING_BASELINE.md`：reopen/list/plan 全线性（105-205 MiB/s、7.0 calls/obj）；结论=layout 演进需要——`meta/objects/` 平面目录 4096 条目上限是拒启悬崖（≈2.7 天可达@满配 source；越崖后 GC 亦失效），下一轮立 ADR（分片/分页+GC 排干率+恢复 runbook）。

### 变更

- census 976→**978**（floor 978）、clippy 持平 31；无新依赖；PLATFORM_FACE_PLAN §2.5 收口。

## [0.1.25] - 2026-09-02（平台面第一轮：UDS socket-mode+sources 配额）

### 新增

- **`calyd --socket-mode <octal>`（RFC-0010 §14.4 边界内）**：socket 默认保持 0600，组共享（如 0660）成为显式 opt-in——配 systemd `Group=caly` 即运维组直连（工作流见 DEPLOYMENT_SYSTEMD §8）。带 other 位的模式（0666 等）与丢 owner rw 的模式（060 等）具名拒绝；`--socket-mode` 与 TCP bind 错配=usage 拒。裁判：endpoint 两胎+calyd 二进制实测 stat。
- **sources 注册配额（RFC-0010 §14.8 执行面）**：`MAX_SOURCE_ENDPOINTS=64`，engine 注册表增长点按名拒绝（`import quota: sources`），重注册同 id=更新不拒；calyd 65 个 `--source-endpoint` 启动即拒（无 port 文件）。

### 变更

- census 971→**976**（floor 976）、clippy 持平 31；无新依赖。PLATFORM_FACE_PLAN §2.3/§2.4 标记收口（导入限额量选结论：HTTP body cap 已有、profiles 无导入面随 RFC-0009 轮）；falsify_round134 四变异全 BIT。

## [0.1.24] - 2026-09-02（R131 审查账本修复批）

### 修复

- **会话流表无界（R131-F1）**：watch 家族的 `DaemonSession.opened_streams` 无 cap（wire 侧 job-follow 表自 R96 起有 64 上限的镜像缺口）。现 `MAX_OPENED_SESSION_STREAMS=64`，超限经统一 redacting error 门具名拒绝（Unavailable+remediation），会话不因拒绝中毒；裁判=首 64 条开绿、第 65 条具名拒、拒后非流请求照常答。
- **解析线程 spawn 失败=panic（R131-F2）**：`resolve.rs` 的 `.expect` 改为具名 `Unavailable` 拒绝（fail-closed-once 粘性：单例记住失败、后续快速拒绝、remediation=释放预算+重启进程）；专用测试二进制 `resolver_spawn_failure.rs`（seam `resolver_spawn_is_broken_for_tests`）。
- **Stream 门错误类别失真（R131-F3）**：`handle_stream` 三路化（`Ok(None)`=UNSUPPORTED / `Err`=内部错），`.ok()?` 曾把锁毒化报成「不支持的操作」。
- **follow 畸形 JSON 静默（R131-F5）**：解码失败具名（`json decode of a response frame failed: …`，exit 13 不变），不再伪装成「opened 帧缺 stream_id」；假 daemon e2e 裁判。
- **映射五处拷贝（R131-F4）**：subscription→StreamKind 收敛 `caly_ipc` 单一家+结构门禁 `subscription_to_stream_kind_has_one_home`（首跑抓到残余拷贝）；**拉取先建后截（R131-F6）**：64 帧上界移到铸帧处（纯等值，语义由既有流裁判钉住）；**运维文档漂移（R131-F9）**：`calyd.service`+`DEPLOYMENT_SYSTEMD.md §7` 的 SIGTERM 语义改为 ADR-056 优雅排空现实（原注释与行为相反）。

### 变更

- census 967→**971**（floor 971）、clippy 持平 31；无新依赖。falsify_round133 四变异全 BIT（M2 变异三次改形才保类型真咬——「没编译≠咬住」的现场教训）。

## [0.1.23] - 2026-09-02（构建后 CLI 功能测试轮）

### 修复

- **`follow` 的恰一操作数规则移到解析期（顺序无关）**：此前「缺 job id 且缺 `--resume`」在**握手之后**才报错、且经 wire 错误映射冒 exit 13（协议错）——纯客户端用法错应为 exit 2 且不该为一次用法错付握手费；「双参」检查只覆盖 `--resume` 在前的顺序，`follow 1 --resume 2` 静默取 resume。现于解析循环后、连接前单点校验（缺/双均 USAGE 2）；裁判用不可达 `--addr` 证明不需 daemon（`follow_operand_rule_is_a_usage_error_before_any_connection`），falsify 单变异 BIT。
- 功能巡检面（40+ 例实测全绿）：15 动词×TCP/UDS×records/json×三角色、用法错全族 exit 2、不可达 exit 12、SIGTERM 优雅停（R129 修复产线成立）、重启恢复（active 标记/作业事件/快照全恢复）、幂等同 key 同 daemon 去重、跨重启重放=ADR-037 内存窗口设计内。

### 变更

- census 966→**967**（floor 967）、clippy 持平 31；无新依赖。

## [0.1.22] - 2026-09-02（ROADMAP §12#4/#5 收口轮：Deployment 流生产者+背压生产者）

### 新增

- **Deployment 流的生产者（IPC_STREAM_POLICY §7 残余收口）**：`StreamKind::Deployment` 此前有 policy（LosslessResumable+ack Required）无开流也无生产语义——watch bridge 对所有 kind 放行全部事件。现 `RuntimeSubscription::Deployment` 经真请求路径开流（subscription_kind=`deployment`），bridge **逐帧 kind 过滤**：只在该流主题事件（`DeploymentChanged`）发生时铸帧，seq/恢复/Reset 沿共享事件窗（显式游标恢复=排他且无损、滞后=具名 `Reset{StateGapTooLarge}`）。裁判 `crates/caly-daemon/tests/deployment_stream.rs` 四胎（重放与日志 oracle 逐 seq 全等且断言窗口内非部署事件更多）。
- **`EventBacklog` / `StreamBackpressure` 首有真实生产者（OVERLOAD_AND_RETRY_MODEL §3.2/§3.3）**：此前两类有名有 mapper 零生产者（与 StorageBusy 补生产者前同形）。现 engine 在 `events_since` 观察到事件窗滚过 follower 游标处记 `EventBacklog`（恰一次/滞后事件）；watch/job bridge 铸 `Reset` 帧处记 `StreamBackpressure`——帧告知客户端、报告经 `overload_lines` 告知 doctor/support bundle（一次事件两个出口）；两 hint 均 `ReopenSession`。滞后裁判断言 healthy daemon 零压力行、滞后后两类行俱在。

### 变更

- census 962→**966**（floor 966）、clippy 持平 31；无新依赖。ROADMAP §12#4 三条款收口注记（typed `send_request_frame`=R123 定案显式不做；Traffic/Logs 待真实数据源）、§12#5 收口注记（ADR-051 早已定案 JSON=导出物）、§13#3 残余清单去陈旧项；IPC_STREAM_POLICY §7 / OVERLOAD_AND_RETRY_MODEL §2ter 同步。

## [0.1.21] - 2026-09-02（有界 DNS 解析轮：ADR-052 增补 §7）

### 新增

- **getaddrinfo 的边界化——source 主链最后一个无界阻塞调用**：`to_socket_addrs` 是 std 里唯一没有超时参数的阻塞调用，此前 `StdHttp` 只能在进入前做边界检查，挂住的解析器可把 fetch 停过任何 caller deadline（既有裁判全用 IP 字面量，DNS 从未被真穿过）。新 `caly-io-std::resolve`：getaddrinfo 不可中断→**永不在调用者线程上运行**——一根惰性单例解析线程执行它，调用者以 `recv_timeout(min(peer 5s, caller remaining))` 等答案；负债恰为一根线程且是**可观察契约**（`resolver_thread_count()`）；挂住查询阻塞队列=队头阻塞如实命名；迟到答案面对已超时调用者的 dropped receiver 即丢弃（回收显式）；预算已尽**根本不进入**该 syscall（按名拒绝+零进入）。`StdHttp` Direct 路由接入，与其余 syscall 同规。
- 裁判：`bounded_resolve.rs` 四胎（单例恒 1+真 localhost 绿 / 过期按名+注入计数器为 0 / 挂住→双超时→释放→**同一线程**恢复 / caller 预算胜过 peer 超时）；注入缝 `bounded_resolve_with` 公开（挂起的 getaddrinfo 只有注入才可达）；`falsify_round129.py` 四变异全 BIT（单例退化每调用一线程 / 过期仍入 / deadline 拒绝错标 / 预算换固定 peer 超时）。既有 io-std 契约 39 断言全绿。
- ADR-052 增补 §7（新阻塞端口的解析需求一律走 `crate::resolve`，不得在调用者线程上直接 `to_socket_addrs`）。

### 变更

- census 958→**962**（floor 962）、rs 105,200→105,497 行、clippy 持平 31；无新依赖。http.rs 的 DNS 拒绝语保持「resolve host: …」形状（成功/失败词汇不变，新增 Timeout 词汇）。

### 修复

- **SIGTERM 掩码顺序（ADR-056 增补 §8，R125 起潜伏）**：掩码此前在 `bootstrap_app` 之后才落，real-mode bootstrap 期 spawn 的线程未屏蔽 TERM；而 glibc `sigwait` 底层是 `sigtimedwait`（waiter 自身不需屏蔽），投递变成内核在未屏蔽线程间的掷硬币——旧沙箱四连优雅、新沙箱四连裸 signal 15（adopt flagship e2e 死于信号、无优雅日志）。修复=`block_term_signals()` 提为 main() 第一条语句（先于一切 spawn），此后所有线程继承屏蔽、TERM 只能挂起直到 waiter 认领。修后旗舰 8/8 绿；无新测试（既有 962 覆盖）。

## [0.1.20] - 2026-09-02（硬化与发布门禁轮：fuzz + 计数制性能回归入常规门禁）

### 新增

- **确定性结构感知 fuzz（里程碑 7，四面入常规门禁）**：固定种子 xorshift + 固定预算的进程内变异流（截断/位翻转/分隔符注入/拼接/数字膨胀/区间删除+空串），打在一切「面对外来字节」的解析层——①`caly-cap` 自研 JSON 读入器（registry 工件=外来文件）；②`caly-ipc` wire 边界三入口（严格协商 JSON / 宽容 records 分裂器 / 字节层帧解码——变异可破坏 UTF-8、谎报长度头，typed 拒绝而非按头切片）；③`caly-storage` 六个 typed 记录解码器+通用 `Record::decode`（被搬动/手改的 store 目录=外来）；④`caly-engine` durable cache 解码（ADR-061 tag 文法是最新的攻击面）。共享不变量：**catch_unwind 永不 panic** + **拒绝按名非空**；每面带绿侧防「永远拒绝」空转。发现可重演：种子即复现。零依赖、无 nightly。
- **计数制性能回归（无挂钟）**：共享 2 核沙箱计时不稳，但二次扫在任何钟速下都是二次——stat_many 轮的包裹计数 Fs 推广为全方法计数，两裁判：批量定年随目录增长**恒定**（N=8/48 同为 1×stat_many、0×stat，把 ADR-054 的「采纳」升级为「伸缩」）；重开扫描随记录数**线性**（4× 对象的端口调用 ∈[2×,5×]——上界咬二次重扫，下界咬「不再读自己所写」：开扫的逐项校验是安全属性不是开销）。
- 裁判即自证：fuzz 落地当场咬出的第一个 bug 在裁判自己的 mutate 里（空语料索引，三处同款——先咬工具再咬产品）；`falsify_round128.py` 四变异全 BIT（JSON 读入器空串/多字节边界切片、Record::decode 空文档索引、批量定年退化成逐项 stat、tag 文法对缺席 tag 切片）。

### 变更

- census 948→**958**（+10：caly-cap 2、caly-ipc 3、caly-storage 4、caly-engine in-mod 1）、floor 958；rs 104,205→105,200 行；clippy 持平 31；无新依赖、无生产代码变更（纯增量裁判）。
- 明确不采用：cargo-fuzz/libFuzzer 外部基建（需 nightly+外部 runner，与零依赖确定性门禁文化相抵——登记为不采用项而非缺口）。

## [0.1.19] - 2026-09-02（SnapshotThenPatch watch 流轮）

### 新增

- **快照首帧（IPC_STREAM_POLICY §3 的 Dashboard/Connections 行首次成为行为）**：dashboard/connections watch 的第一次拉取现在返回恰好一帧 `SnapshotJson`——对应一次性查询（`runtime.status` / `runtime.connections`）的同一事实、单一 records 渲染（`runtime_status_field_records`，calyd 响应面复用同一渲染）——seq 钉在活边使补丁流从 +1 续，快照前历史折入快照永不重发。此前 `SnapshotJson` 载荷在 wire 与 CLI 两侧早已就绪但生产面零产出：中途接入的 dashboard 客户端只见未来变化，没有任何一帧说「现在是什么样」。
- **有界分拉（backpressure producer，IPC_STREAM_POLICY §7）**：事件桥每拉至多 `MAX_WATCH_FRAMES_PER_PULL=64` 帧；引擎 256 事件保留窗持有余量，流游标接续，跨拉按 seq 连续、不丢不重。此前一次拉取可整批返回保留窗全部事件——最慢客户的拉取成了 daemon 最大的一次写。
- **慢客户正式策略可达（§7.4）**：落后保留窗的拉取收到点名 `Reset{StateGapTooLarge}`，不是陈旧重放也不是静默跳过——引擎 256 事件环使该路径真实可达并有裁判。
- 裁判：新文件 `watch_snapshot_stream.rs` 五胎（真 DaemonSession+真 apply 事件）；场景套件同步为新契约（`runtime.watch.snapshot-first` 新行、structured-* 行改补丁语义、恢复事实在快照内可见）；`falsify_round127.py` 五变异全 BIT（快照不发射/快照渲染第二份发散事实/拉取上界消失/Reset 吞沉默/恢复游标被忽略）。

### 变更

- `app.runtime_status()` 成为 Status 事实唯一构造点（query handler/快照帧/records 三面共用）；`DaemonSession::follow_opened_stream` 对 SnapshotThenPatch 首拉走快照路径、事件桥路径每拉截断。Job 流泵与 Deployment/Traffic/Logs 的事件桥行为不变。
- census 943→**948**（floor 948）、rs 103,605→104,205 行、clippy 持平 31；无新依赖、无 wire 新帧（既有载荷变体首次有了生产者）。

## [0.1.18] - 2026-09-02（durable source index 的 schema 演进轮：ADR-061）

### 新增

- **cache tag 演进与读时前向迁移（ADR-061，ROADMAP 里程碑 2 收口）**：durable source index 的三个 opaque cache tag 从 `normalized:v1` 演进为 `normalized:v2:<pipeline_epoch>`（provenance/diagnostics 同形）——epoch 在摘要锚覆盖之内，谎报可检测；`caly_pipeline::stage::PIPELINE_EPOCH` 成为唯一比较点（原三处硬编码收敛）。读取前向迁移：v1 tag ⇒ epoch 1（v1 只被 epoch-1 build 写过——历史事实），迁移纯内存（锚仍验盘上 v1 字节，下次 update 在同一原子提交以当前 tag 重写）；未知 tag 按名拒启（找到的 tag+支持列表俱在拒绝语，RFC-0007 §12.3）。
- **陈旧降级语义**：epoch ≠ 当前的 cache 不是损坏——endpoint/locator/raw CAS 照常恢复（原子提交、CAS root、locator 失效全保持），但旧管线的 normalization 不进 `restored_sources()`（引擎不消费陈旧语义）；三 cache epoch 互斥（任何 build 都没写过的形状）按三个实际值点名拒绝。代价如实：陈旧源下次 update 全量重取（304 上复用陈旧 normalization 正是要堵的洞）。
- 裁判：e2e 三胎（v1 反砖+恢复为当前 / epoch-9 陈旧不进引擎且 worker 照常起 / 未知 tag 按名拒启）+ 单元三胎（v1≡v2:1 值保真 / 未知 tag 四形状按名 / 混合 epoch 拒绝且一致陈旧降级）；既有损坏参数化裁判全保绿（锚校验路径未动）；`falsify_round126.py` 四变异全 BIT（历史事实变 epoch 0 / 未知当 v1 / 陈旧照常消费 / 锚改在迁移后重编码上算）。

### 变更

- `source_persistence` 的 decode API 返回 `(值, epoch)`；`report_from_record` 带 `current_epoch` 并返回 `CacheRecency`；`HttpSourceUpdateWorker` 恢复循环按 recency 分流（陈旧：注册 endpoint、跳过 cache）。`sources.inspect` 语义不变（记录投影，不咨询 recency——ADR-061 §2.3）。
- census 937→**943**（floor 943）、rs 103,176→103,605 行、clippy 持平 31；无新依赖、无 wire 变更。

## [0.1.17] - 2026-09-02（跨进程 core adoption 轮：ADR-060）

### 新增

- **跨进程 core adoption（ADR-060，RFC-0005 §12 真进程层）**：`kill -9`/崩溃后存活的孤儿核不再失管——真实 spawn 落盘 durable core receipt（`<runtime-root>/core-receipt`，records 文本）；`calyd --effect-runtime real` 启动时（listener 前）按 pid + `/proc` start_time（RFC §12.3 身份三要素，nonce 钉凭据到 spawn）验证后**接管仍存活的核**（同 pid，不重 spawn；重开 ActiveCore 路由，日志带 pid/nonce/端口），核死清凭据冷收敛、pid 复用按名拒绝且绝不向不匹配进程发信号、controller 哑则拒绝且保留凭据每次启动如实再报（§12.4 收敛，无悬空态）。
- **可停的接管**：lib 定义 `ForeignStopper` 注入契约（未注入按名失败）；生产实现在 calyd bin 的新 FFI 模块（pidfd：先钉进程再复核身份，次序消除 bare-kill 的 pid 复用 TOCTOU；TERM→宽限→KILL；非子进程退出状态归 init，只报结果档不编造码）。SIGTERM 停机序列对被接管核同样生效：排空→pidfd 停核→exit 0，无孤儿残留。
- 裁判：库层四胎（同 pid 接管+FOREIGN 停止+凭据清除 / 核死清凭据 / pid 复用拒绝且不动进程 / controller 哑拒绝保凭据）+ 单元四条（stat 解析、receipt 解析、start_time、僵尸≠活进程）+ 双二进制旗舰 e2e（kill -9→接管→随第二 daemon 优雅停核）；`falsify_round125.py` 四变异全 BIT（身份比较灭活 / 只记日志不建实例 / foreign 停止谎报 already-gone / 核死不清凭据），且红绿判定新增**可编译守卫**（编译错误不再伪装成 RED）。

### 变更

- `StdEffectRuntime` spawn 成功即写凭据、三条停路径（stop/补偿/shutdown）按 foreign 分流并清凭据；`stop_instance` 子路径证据措辞不变。
- `real_apply.rs` 因 adoption 裁判升级为进程 harness 文件（文件级 clippy disallowed 提升，同 `calyd_wire.rs`/`caly_cli_e2e.rs` 先例）；生产侧 `foreign.rs` 用 tick 计数不用 `Instant::now`（工作区禁用方法）。
- census 928→**937**（floor 937）、rs 101,856→103,176 行、clippy 持平 31；无新外部依赖（FFI 三符号零 crate）。
- 基础设施两修 + 一闸门：`check.sh` 的 GATE_ROOT 从裸 `mktemp -d`（/tmp tmpfs）钉到 `target/gate-XXXXXX`（门禁自己的 throwaway 编译目录曾与真核 e2e 的 /tmp scratch 争同一块 993M 内存盘，症状为 check 必红、手跑必绿）；旗舰裁判 scratch 挪 `CARGO_TARGET_TMPDIR`；`real_apply` 加 `REAL_CORE_TURNSTILE`（出网裁判与接管裁判 whole-body 互斥，2 核宿主上 spawn 风暴曾把出网 3s 期限顶爆）。

## [0.1.16] - 2026-09-02（calyd 优雅排空轮：ADR-056 增补）

### 新增

- **停机序列补全（ADR-056 Addendum §5）**：SIGTERM 不再瞬间切断在途会话——
  stop accepting（丢弃 listener，新连接立即拒绝；accept 轮询化，listener 非阻塞 +
  `EndpointErrorKind::WouldBlock` 判别）→ 有界排空（`SHUTDOWN_DRAIN` 3s 入共享政策表，
  请求尺度：在途请求/应答本就 3s 有界；超窗的流诚实切断，ADR-057 耐久作业 +
  `--resume` 对重启后 daemon 可恢复）→ 优雅停核（原 10s 不变）→ exit 0（从 waiter
  移到 main，waiter 只置标记）。
- 裁判：`a_sigterm_drains_the_inflight_session_and_refuses_new_clients`（三事实一对话：
  信号后已建立会话的请求仍得关联回答 / 新连接被拒 / exit 0 有界）；
  `sigterm_shuts_calyd_down_gracefully_with_exit_zero` 保绿。
- `WireListener::set_nonblocking` + `EndpointErrorKind::WouldBlock`（accept 的「暂无客户端」
  与真错误分开，不做字符串嗅探）。

### 变更

- 门禁 census 927→**928**、floor 928；`falsify_round124.py` 三变异全 BIT。

## [0.1.15] - 2026-09-02（§13#3 残余三项收口轮：UDS peek / 会话递增 id+复用 / typed 表定案）

### 新增

- **ADR-059：UDS 对端探测经 MSG_PEEK**——新 workspace crate `caly-uds-peek`（手写四行
  FFI，零依赖；unsafe 集中一处；caly-ipc 保持 `forbid(unsafe_code)`）。UDS 流泵获得与
  TCP 同级的死对端 reap（裁判 `a_uds_stream_client_that_leaves_mid_wait_is_reaped_too`）；
  探测不到的 errno/非 Linux 平台如实 Unknown→Indeterminate，绝不发明关闭。
- **会话内递增 request_id + 逐请求关联（R123）**：`Session` 持 id 计数（hello 后从 1 起），
  每个请求带自己的 id、每个回答核自己请求的 id——`apply --wait` 的双请求现在是 1、2，
  陈旧回显（以 1 答 2）= exit 13（此前双请求同 id，陈旧回显不可分辨）。裁判两胎
  （假 daemon 逐请求解析回显 / 陈旧回显拒收）。
- **连接复用钉**：`a_connection_serves_a_second_stream_after_the_first_ends`——一条连接
  第一条流 END 后不报废，第二条 open 得新 stream id、回显递增 request id、整窗重放。

### 变更

- typed `send_request_frame` 双表接线：R123 重估**维持 R76 排除并定案**——单一 typed
  编码表（`wire_ops::wire_request`）已是生产路径（每动词构造 typed `Operation`），
  typed 循环是 Session/FramePump 之外的第二条对话路径；新结构门禁
  `the_cli_speaks_the_one_typed_request_table`（typed 表必须生产使用 + 禁手拼写 op
  字面量）。
- 门禁 census 919→**927**、floor 927（新 crate caly-uds-peek 3 裁判 + e2e 3 + wire 1 +
  arch 2）；`falsify_round123.py` 六变异全 BIT。

## [0.1.14] - 2026-09-02（共享 timeout scheduler 轮：§13#3 大活收口）

### 新增

- **`caly_ipc::timeout`：每个传输期限的唯一事实源**（R122，`TRANSPORT_RUNTIME_MODEL §5`）。
  政策表六值：connect 3s / handshake 5s / request 3s / stream idle 30s / session idle
  默认 30s（`--session-idle-ms` 覆盖）/ probe window 50ms。每连接一个
  `TimeoutScheduler`（`client()`/`server(session_idle)`）按阶段把 deadline 施加到传输
  的**双半**（`DeadlineIo`：裸 `WireIo` 或经 `FramePump::set_idle`，泵内探活恢复与
  阶段永不分歧），并记住当前阶段——daemon 流泵的 50ms 探测窗恢复从「调用点记忆值」
  改为「活阶段」（R91 教训的服务端对位）。
- 裁判五钉（表值与关系、客户端/服务端旅程序列、`--session-idle-ms` 真落地、探测
  窄化-恢复、scheduler 与泵 idle 一致）+ 结构门禁 `the_transport_deadlines_have_one_home`
  （两 binary 生产代码零直接 setter、零秒级 Duration 字面量、防空心化）；R90/R91 两条
  旧结构门禁 re-pin 到 scheduler 形状。

### 变更

- `caly.rs` 三个本地常量（CONNECT/READ/STREAM_IDLE）与 `calyd.rs` 的
  `HELLO_TIMEOUT`/`SESSION_IDLE_TIMEOUT_DEFAULT_MS`/`set_transport_deadlines` 全部删除，
  生产路径经 scheduler 取值施加；CLI 超时措辞（exit 11 的 `timed out after Nms`）改读
  活阶段。行为零变化（R44/R89/R90/R91 的既有裁判全绿）。
- 门禁 census 913→**919**、floor 919（timeout.rs 新行 5 裁判）；
  `scripts/archive/falsify_round122.py` 四变异全 BIT。

## [0.1.13] - 2026-09-02（state-gap 提示游标化轮：R120 留观项收口）

### 修复

- **state-gap 的 `resume_from` 从「最老保留行的索引」改为可回喂的排他游标**：CLI 提示
  `resume with --from N`，而 `--from N` 的契约是排他请求游标（「已拥有到 N」，从 N+1 起）——
  旧值照提示做必跳过最老保留行本身。泵现在交付「下一次读恰好落在最老保留行上」的游标
  （retained 边沿减一；gap 只在已裁 ≥2 条时触发，无下溢）。裁判：
  `a_gap_hands_back_a_cursor_that_lands_on_the_oldest_retained_line`（真 slice+真泵+回喂
  组合——引擎侧自注没有足够大的真实 fixture 能踩 reset 分支）与
  `a_state_gap_end_names_the_cursor_to_resume_with`（CLI 提示逐字透传，假 daemon e2e）。
  值语义修复、wire 形状不变（同 R120 先例）。`IPC_STREAM_POLICY §5.1` 的留观段收口为契约。

### 环境

- `.git/` 第二次被跨回合快照清除（§4.194 首次）：以 R120 收口工作树为恢复基线重建
  （b6d0b69），并自此**每轮提交后在树内写 `git bundle`**（`.git-history.bundle`，已
  gitignore）——快照丢 `.git` 不丢工作树文件，bundle 让历史可完整还原。

## [0.1.12] - 2026-09-02（真核部署流式/resume 用户面 e2e 轮，P2 切片）

### 新增

- **两条真核 binary 级 e2e**（`JOB_FLOW_COST_BENEFIT_REPORT §4` 点名的 P2 第一片）：
  `an_apply_wait_streams_a_real_core_deployment_with_the_cores_own_identity`——真 calyd
  （`--effect-runtime real` + 钉死资产 + worker 线程）上 `caly apply nightshift-direct
  --wait` 全流：acceptance 先于事件、identity 探针携带核自己的 `/version` 答案
  （`probe.core-identity kind=mihomo version=…1.19.30…`，是「真核而非 sim」的判别锚——
  sim 的 identity 观测为 `core.identity simulated` 且永不含 version）、
  `snapshot.committed`、`[done] Succeeded`、60s 有界；
  `a_resume_after_a_zero_ack_disconnect_replays_the_whole_real_deployment`——raw 客户端
  开流后只读 opened 帧即消失（零 ack 是构造出的确定性，不是时机），`--resume` 输出与
  同作业全新 follow 的整窗逐行相等（at-least-once 重放在真核时序下成立）。
- 真核 e2e 清理范式：`RealDaemon` drop-guard——SIGTERM 走 ADR-056 优雅停核（SIGKILL 会
  孤儿化活核），有界等待 + SIGKILL 兜底，再清 runtime root。

### 修复

- **流泵游标极性（真核 e2e 抓到的静默跳行，R120 follow-up）**：`slice_job_events` 的请求游标
  是排他的（「已拥有到 N」），但 `JobStreamPump` 曾把「下一个想要的索引」喂回去——页恰好落在
  活边沿、或首页为空时，下一次回读跳过一条事件（真核 `apply --wait` 带载下间歇丢
  `[stage 0%] running` / `mark-snapshot` 等行；sim 下「流先开、事件后到」100% 复现）。
  修复：泵 `cursor()` 与 DATA 帧 `next_event_index` 一律「已交付到的最后索引」，空页不设游标；
  ACK `acked_upto` 与 resume 重放因此精确对接（无丢无重）。裁判：
  `a_stream_opened_before_the_first_event_still_delivers_it`（e2e，确定性）+ 泵单测两钉；
  `IPC_STREAM_POLICY §5.1` 记录极性约定。留观：state-gap `resume_from` 提示直接喂 `--from`
  会跳过最老保留行（`§4.195`）。

### 变更

- 门禁 census 906→**911**、floor 911、CENTERLINE 911（caly_cli_e2e 60→63、job_stream 单测 8→10）；
  `scripts/archive/falsify_round120.py` 五变异（daemon 静默退回 simulated / CLI 丢弃
  `--resume` 接线 / daemon 把「零 ack」当「已收」跳过未确认事件 / 泵游标退回活边沿 /
  空页种子 retained 边沿）全 BIT。
- 环境留档（`§4.194`）：跨回合快照不保留工具链与 `target/`；rustup 重装需
  `-c rustfmt,clippy` 逗号语法；单跑 caly-cli 测试前先构建 calyd（sibling 定位依赖
  workspace 构建布局）。

## [0.1.11] - 2026-09-02（bundle 收录耐久作业轨迹轮，ADR-057 §5 切片 3 收口）

### 新增

- **support bundle 第 13 段 `job-history`**（`ADR-057` §5 切片 3 的残余项）：枚举
  `JobLogStore::list_job_logs`（最新在前），每作业一行头（id/state/outcome/failure 稳定公共
  码/warnings/logs/events shown/total/committed）+ 尾部最多 12 行事件（缩进两格，存储记录的
  文档契约本就承诺「在 support bundle 里逐字可 grep」）；8 作业有界、段尾 `total=N shown=M`、
  空集显式说明、`Unsupported` 后端照旧 `not enumerable`。
- **该段是存储投影而非内存投影**：不依赖本进程 `restore_job_logs`——新引擎直接 collect 也
  能携带重启前的部署轨迹，与 `runtime-log`（「本进程见过什么」）回答不同的问题。

### 变更

- `BUNDLE_SECTIONS` 12→13（`job-history` 位于 `runtime-log` 之后）；裁判
  `the_bundle_carries_every_section_the_docs_require` 经常量自动纳入新段。
- 文档同步：`REDACTION_AND_SUPPORT_BUNDLE`（段史/清单/表）、
  `STORAGE_RECOVERY_EXECUTION_PLAN §9.3`（段数）、`ADR-057 §5` 切片 3 标记落地、FEATURES §5.4、
  IMPLEMENTATION_STATUS 活性数字重测（267 rs / 100,063 行 / 94 二进制 / 126 md）、ROADMAP §1 快照。
- 门禁 census 902→**906**、floor 906、CENTERLINE 906（support_bundle.rs 9→13：跨进程生命可见 /
  失败码上头行 / 有界与总数 / 空集显式四条新裁判，先红后绿）；`scripts/archive/falsify_round119.py`
  三变异全 BIT。

## [0.1.10] - 2026-09-02（环境接手轮：geo 滚动资产显式重钉）

### 修复

- **geo 数据重钉**（环境接手）：新环境按 `scripts/fetch_assets.sh` 重建资产时，geo 上游的
  滚动 `latest` 已漂移（geoip `106c69bb…`→`93175949…`、geosite `13b7cde1…`→`76d21fd0…`），
  裁判 `the_committed_core_assets_are_pinned_by_digest` 如期点名变红。按既定规程**显式重钉**
  `real_core.rs` 两个 geo 常量（重钉前 geo 承重裁判与真核生命周期裁判已在新字节上绿；
  旧钉值留档 `docs/history/ONBOARDING_NOTES.md §4.192`）。mihomo v1.19.30 / sing-box 1.13.20
  钉的是不可变 release，不随 geo 漂移。
- 环境教训留档（`§4.192`）：`cargo test` 默认 fail-fast，前面的红会遮住后面的红——首遍
  `check.sh` 被 example.com 502 瞬态挡在 caly-io-std 之前，geo 漂移第二遍才暴露；环境接手
  轮首遍有任何失败时，修复后必须整遍重跑。

### 变更

- 基线入库：zip 解包后 `git init`，原始树（R117 半程状态）提交为基线；R117 收尾与本轮
  各自独立提交。census/floor 持平 902（仅改两个测试常量与注释，无新测试）。

## [0.1.9] - 2026-09-01（脚本化运维合同轮，发现 #7 收口）

### 新增

- **`docs/guides/SCRIPTING.md`——脚本化运维合同**（OPERATOR_SCENARIO_REPORT 发现 #7，文档指引
  收口）：钉住脚本/CI 能依赖什么、不能假设什么——退出码是合同（`caly job` / `caly follow` /
  `apply --wait` 同一失败作业同一退出码，ADR-058）；稳定事实字段清单（acceptance 三字段、
  jobs.follow 摘要字段、流 END 帧字段）；事件行是部署工作量的投影不是常量（同 profile 二次
  apply 事件 25 < 首版 44 是正确行为），脚本不得假设恒定事件数/固定 stage 序列；未列出的
  输出细节一律视为随实现演进的展示层。

### 变更

- OPERATOR_SCENARIO_REPORT §5/§7/§8 标记发现 #7 已收（R112–R117 七发现全部收口）；
  FEATURES §8 命令表后补脚本合同指针。
- 轮次收尾补齐（上游交付快照停在 R117 半程）：`regenerate_doc_index.py` 重建 docs/README.md
  §1 树（原样树上 `the_document_index_lists_every_document` 实测 FAILED、重建后 ok——半程
  快照本身就是该门禁的活变异）；处置表 6.143 + `ONBOARDING_NOTES §4.191` 留档，「明确不做」
  尾标题重编号 6.144。
- 纯文档轮：无 Rust 改动，census/floor 持平 902；完整门禁复跑全绿（一次 example.com 502
  瞬态，`§4.155` 族，复跑绿）。

## [0.1.8] - 2026-09-01（流式 END failure_code 轮，ADR-058）

### 新增

- **流 END 帧携带 `failure_code`**（OPERATOR_SCENARIO_REPORT 发现 #6，先 ADR 后动 wire）：
  终局为 failed 且作业携带公共失败码时，END 帧加可选 `failure_code` record（与 `jobs.follow`
  同拼写、同一来源）；`caly follow` 与 `apply --wait` 的流式失败按该码落精确退出码
  （如 CONFLICT→4、PERMISSION→8），缺失→1（旧行为不变）、未识别→13——同一失败作业经
  `caly job` / `caly follow` / `apply --wait` 三条路径退出同一数字（`docs/adrs/ADR-058`）。

### 变更

- daemon：`app.job_failure_code()` 从 `JobRecordSummary.failure_code` 取码（jobs.follow 同源），
  calyd 的 END 帧写者仅在 `outcome=Failed` 时附码（成功/取消/超时终局永不带码）。
- CLI：`stream_end_exit_code` 的 Failed 臂经 `from_wire_refusal_code` 路由（同一公共码表）；
  非 Failed 终局上的杂散码一律忽略（判决是 outcome，码只细化 Failed）。
- 纯字段可加扩展：无 wire 版本升级、无 journal 格式迁移（码已耐存在 ADR-057 记录里）；
  旧 daemon 不发即降级 exit 1。
- 门禁 census 897→902（caly_cli_e2e 57→60、calyd_wire 47→48、dependency_direction 26→27）；
  `scripts/archive/falsify_round116.py` 五变异（daemon 不发码 / CLI 判决不读码 / 每次 END 都编码 /
  识别码猜成功 / 缺码猜成功）全 BIT。

---


Caly 的变更记录。2026-09-01 之前上游没有 git 历史（zip 上传），此前的逐轮明细在
`docs/history/logs/`；本文件从文档重整这一轮起记录，每段按「新增 / 修复 / 变更」三类列条目，
并注明依据（测试名或门禁名）。

---

## [0.1.7] - 2026-09-01（apply --wait 轮）

### 新增

- **`caly apply <id> --idempotency-key <k> --wait`**（OPERATOR_SCENARIO_REPORT 发现 #5）：
  acceptance 三字段照打，随后**同一会话**开 follow 流把事件照打、按流判决退出码
  （Succeeded 0 / Failed 1 / Cancelled 15 / TimedOut 11 / 状态缺口 14），`--wait --json` 同语义。
  纯 CLI 组合——协议不动，仍是同一连接上的两个请求（`ONBOARDING_NOTES §4.189`）。

### 变更

- `follow_stream` 拆为握手 + `follow_stream_after_hello`：`caly follow` 与 `--wait` 共用同一份
  流循环（二次握手会撞 ClientLoop 状态机；两份实现必漂移）。
- `--wait` 只属于 apply：其他动词上它是 usage（exit 2），不做「静默无效的旗标」。
- 门禁 census 893→897（caly_cli_e2e 53→57）；`scripts/archive/falsify_round115.py` 四变异
  （wait 半程被删 / apply 恒跟流 / 流判决被丢 / 归属守卫被关）全 BIT。

## [0.1.6] - 2026-09-01（订阅管道用户面轮）

### 新增

- **`caly sources` / `caly source <id>`**（OPERATOR_SCENARIO_REPORT 发现 #3）：
  wire `sources.list`/`sources.inspect` 上线（`WIRE_OPERATION_NAMES` 14→16）；列表的注册表 =
  worker 端点（`--source-endpoint` 注册 ∪ durable index 恢复）∪ profile workflow 引用，
  **注册端点未拉取即列得出**；单源视图带 locator/route/etag/digest/节点数/诊断/来源，
  未拉取的 durable 事实在 wire 上显式为空（CLI 渲染为 `never`）。
- `sources.inspect` 契约收窄为注册表语义：表外 id 按 `no such source: <id>`（CONFLICT，exit 4）
  点名拒绝，列表与查询同源一致（R113 profiles 契约的 sources 版，`ONBOARDING_NOTES §4.188`）。

### 变更

- `source_summaries` 不再只读 apply 的 workflow 投影（否则订阅注册在列表里永远不可见）；
  `source_inspection` 的「任意 id 合成视图」fallback 删除（旧代码还借 profile workflow 的
  warning_count 当自己的警告数，现已归零）。
- 门禁 census 890→893（calyd_wire 45→47、caly_cli_e2e 52→53）；door sweep 加两个 source op；
  `scripts/archive/falsify_round114.py` 四变异（去守卫任意答 / 恒拒 / 拒绝码换 Internal /
  列表丢端点注册表）全 BIT。

## [0.1.5] - 2026-09-01（profiles.get 假成功修复轮）

### 修复

- **`caly profile <不存在>` 不再假成功**（OPERATOR_SCENARIO_REPORT 发现 #1）：`profiles.get`
  契约收窄为注册表语义（`default-profile` ∪ active，与 `profiles` 列表同源）——表外 id 按
  `no such profile: <id>`（CONFLICT，exit 4）点名拒绝，列表与查询两面对齐（round-46 占位
  语义被自家裁判钉成契约，`ONBOARDING_NOTES §4.187`）。
- `no_such_job` 的 remediation 文案「job history is not durable」→「terminal job history
  survives restarts (ADR-057)」（R109 之后旧文案是假话）。

### 变更

- 两条旧语义裁判更新为新契约（calyd_wire `profiles_get_refuses_a_missing_id_and_an_unknown
  _profile_but_answers_registered_ones`、caly_cli_e2e `caly_profile_refuses_an_unknown_id_and
  _prints_the_view_for_a_registered_one`）；`scripts/archive/falsify_round113.py` 三变异
  （去守卫任意答 / 恒拒 / 拒绝码换 Internal）全 BIT。
- census/floor 持平 890（改裁判非新增）；OPERATOR_SCENARIO_REPORT 发现 #1/#2 标记已修。

## [0.1.4] - 2026-09-01（使用场景报告 + CLI --role 轮）

### 新增

- `docs/engineering/OPERATOR_SCENARIO_REPORT.md`：全产品用户面实测（五场景：新网关上线 /
  订阅接入 / 变更回滚 / kill -9 故障演练 / 脚本化运维），逐条原始输出与退出码，7 条
  用户面发现（含 `caly profile <不存在>` 假成功、订阅导入黑盒等）。
- **CLI `--role viewer|operator|admin`**（P1 分权可达性）：`drive_client_hello` 接角色参数
  （typed config 与 hello 字节同源），`caly` 旗标解析（坏值 usage exit 2、默认 admin 保兼容）。
  实测 `--role viewer gc` → PERMISSION/exit 8、`--role viewer status` → 正常。
- e2e 四胎裁判（`caly_cli_e2e` 48→52）：viewer 读+拒写 / operator 拒写 / 坏角色 usage /
  admin 默认反空转；`scripts/archive/falsify_round112.py` 三变异全 BIT。

### 修复

- `scripts/archive/falsify_round110.py` 与 `falsify_round112.py`：还原后的 mtime bump 移到
  **每次 restore 之后立即执行**——放循环外会让下一变异复用上一变异的构建产物
  （round-112 首跑自咬，`ONBOARDING_NOTES §4.186`）。

### 变更

- census 886→890、TEST_FLOOR 890、CENTERLINE 886→890；FEATURES §4.4/§8、
  JOB_FLOW_SCENARIO_REVIEW（§2.4/P1）、JOB_FLOW_COST_BENEFIT_REPORT 同步分权落地状态。

## [0.1.3] - 2026-09-01（Job/Flow 成本收益评估轮）

### 新增

- `docs/engineering/JOB_FLOW_COST_BENEFIT_REPORT.md`：以纯用户面重跑「部署日」全链的实测记录
  （原始输出+退出码），按模块核算代码量（生产 ≈3.5–4.5k 行）、测试份额（≈13–15%）、决策文档
  与轮次投入（≈25 轮），给出分级必要性判定与「主体冻结 + 三个小缺口（CLI --role / END 帧
  failure_code / apply 同步组合面文档化）+ 轮次转向（P2、§13#3）」的结论。

### 修复

- `docs/guides/FEATURES.md §3.2`：删掉过时「注意」行（仍称跨重启持久化为未做项）——R109/R110
  已落地，实测 kill -9 重启后 jobs/job/翻页/follow 全命中。
- `docs/engineering/JOB_FLOW_SCENARIO_REVIEW.md`：加姊妹篇指路横幅。

## [0.1.2] - 2026-09-01（ADR-057 切片 4：真二进制耐久裁判轮）

### 新增

- `crates/caly-daemon/tests/calyd_wire.rs` +2（43→45）：**ADR-057 §5 切片 4 的两条承诺裁判**
  `a_terminal_job_survives_a_kill_9_restart_and_answers_every_query_surface`（apply→SIGKILL→同
  data-dir 重启→`jobs.list`/`jobs.events`/`jobs.follow` 三查询面全命中）与
  `a_gc_collect_cycle_never_reclaims_the_durable_job_history`（真实 collect 后历史仍可答，钉住
  GC 收集路径不触碰 job-log 的边界）；harness 基建 `Daemon.kill_9()` / `spawn_daemon_in(data_dir)`
  / `keep_dir_on_drop`。
- `scripts/archive/falsify_round110.py`：三变异（启动不恢复 / 终态不落盘 / collect 吞历史）全 BIT。

### 变更

- `docs/adrs/ADR-057-job-event-durability.md` §5：切片 1/2/4 标注落地状态，切片 3 剩 support
  bundle 收录作业轨迹。
- ADR-057 状态同步：`docs/adrs/README.md`、`docs/status/ROADMAP.md`、`docs/guides/FEATURES.md`、
  `docs/engineering/JOB_FLOW_SCENARIO_REVIEW.md`、`docs/status/IMPLEMENTATION_STATUS.md` §3.3、
  `docs/history/ONBOARDING_NOTES.md`（§4.184 + 处置行 6.136）。
- `scripts/check.sh` 的 `TEST_FLOOR` 884→886；CENTERLINE 断言数 884→886。
- 重建 git 仓库（`.git` 未随工作区快照存活；内容无损，以本基线提交为唯一历史起点）。

### 修复

- `scripts/archive/falsify_round110.py`：还原 mtime 会让 cargo 把变异构建的二进制当最新，
  首次全量门禁因此跑在 M3 污染的产物上（`caly_cli_e2e` gc 裁判红）；脚本现在在全部变异
  跑完后对还原文件 `os.utime(path, None)`，强制后续构建从干净源码重编（`ONBOARDING_NOTES
  §4.184`）。
- `crates/caly-cli/tests/caly_cli_e2e.rs`：oracle 断言失败时打印 refusal 正文（此前只有
  kind 5 vs 4 两个数字，排查无从下手）。

## [0.1.1] - 2026-09-01（文档重整与开发范式轮）

### 新增

- 根 `README.md`（项目入口：是什么、快速开始、文档地图）。
- `docs/` 六目录结构（`guides/`、`rfcs/`、`adrs/`、`status/`、`engineering/`、`history/`），
  取代原先 40+ 份文档平铺 + 根目录两份重复旧规格的布局。
- `docs/guides/DEVELOPMENT_WORKFLOW.md`：新的开发范式（git 分支模型、Conventional Commits、
  七步循环、门禁清单），取代旧的 `CONTINUATION_PLAYBOOK.md`（已归档 `docs/history/`）。
- `scripts/regenerate_doc_index.py`（+`--check`）：`docs/README.md §1` 树生成器。
- `.github/workflows/ci.yml`：CI 与本地 `scripts/check.sh` 同一套门禁（此前仓库无任何 CI）。
- `.gitignore`；`docs/history/logs/README.md` 逐轮日志索引。
- 门禁 `the_document_index_lists_every_document`（递归版，取代只查顶层的旧版）。

### 修复

- `crates/caly-engine/tests/job_log_durability.rs`：交付物中 4 处编译错误（缺 lifetime、
  私有常数、不存在的方法、类型失配）——交付物此前 `cargo test` 无法编译通过。
- **钉死资产恢复**：交付物把 `assets/` 打成空目录，真核测试全红。新增
  `scripts/fetch_assets.sh` 按 sha256 恢复 mihomo v1.19.30 / sing-box 1.13.20（与测试钉死的
  `cf06ce2c…`/`646bc01b…` 逐字节一致）；geo 数据上游只保留滚动 `latest`，原钉死的快照已无
  任何存档可获取，故**本轮故意重钉** `geoip.metadb`/`geosite.dat` 为当前上游构建
  （`real_core.rs` 内注明，旧钉值保留在 `docs/history/ONBOARDING_NOTES.md`）。资产不入 git
  （`.gitignore`），CI 经 cache + fetch 恢复。
- census 漂移两行（`job_log_durability` 4→5、`job_log_contract` 2→3）——交付物中
  `status_table_test_counts_match_the_tree` 是红的。
- CENTERLINE 断言数 882→884（`the_centerline_assertion_count_matches_the_tree` 是红的）。
- `docs/adrs/README.md` 缺 ADR-051 ~ ADR-057（表与文件清单已补）。
- 根目录重复文件 `Caly_Architecture_RFC.md`（与 `docs/rfcs/RFC-0001-core-architecture.md`
  逐字节相同）与旧草稿 `Caly_Unified_Architecture.md` → 归档 `docs/history/legacy/`。
- 打包残留 `.profile` 从树中移除。

### 变更

- 全仓 `cargo fmt`；`fmt` 从 advisory 变为 `check.sh` 硬门禁（格式欠账归零）。
- `check.sh` 的 `TEST_FLOOR` 882→884（与实测一致）。
- `docs/` 引用全面更新为新路径（约 128 个文件）；`scripts/falsify_round*.py` 等一次性脚本
  移入 `scripts/archive/`。
- `docs/README.md` 重写：目录职责、阅读路径、权威级别、维护规则。
