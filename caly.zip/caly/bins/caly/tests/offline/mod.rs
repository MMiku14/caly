//! Offline dry-run contract tests split from the real-daemon lifecycle
//! suite: these leaves never connect to a daemon, so they live in a sibling
//! module that keeps the main suite under its file budget.

use super::*;
use std::{fs, path::Path, process::Command};

/// Runner used by both offline dry-run assertions.
type ClientRunner = dyn Fn(&[&str], &Path) -> Result<String, String>;

/// Round 18: `set proxy add` dry-run is the canonical
/// example of an offline leaf (no daemon round-trip).
/// The contract is:
/// - JSON envelope is `{ok, version, dry_run:true, id, uri, group}`
///   so a `jq` consumer can branch on `dry_run` without
///   parsing the human message.
/// - The default mode (no `--apply`) must NOT write the
///   proxy file under `<state>/inline-proxies/`.
/// - The `--apply` mode MUST write the file and report
///   `dry_run:false`.
///
/// This is the integration-level guard for the dry-run
/// JSON envelope the rest of the `set` namespace
/// (proxy / sub / rule_provider / profile) emits.
#[test]
fn set_proxy_dry_run_emits_envelope_and_does_not_write() -> Result<(), String> {
    let _guard = e2e_lock();
    let root = workspace_root();
    let _ = root; // not used; this test runs offline.
    let runtime = unique_runtime("proxy-dryrun");
    fs::create_dir_all(&runtime).map_err(|error| error.to_string())?;
    fs::create_dir_all(runtime.join("state")).map_err(|error| error.to_string())?;
    fs::create_dir_all(runtime.join("config")).map_err(|error| error.to_string())?;
    // Pre-create the inline-proxies dir so the
    // existence-check is meaningful: the dry-run path
    // must not even open a file handle here. The
    // writer appends `caly/` to `XDG_STATE_HOME`
    // (see `AppPaths::resolve` in
    // `crates/caly-platform/src/paths/mod.rs`).
    let inline_dir = runtime.join("state").join("caly").join("inline-proxies");
    fs::create_dir_all(&inline_dir).map_err(|error| error.to_string())?;
    let inline_dir_after_apply = inline_dir.clone();

    let run = |args: &[&str], env_state: &Path| -> Result<String, String> {
        let output = Command::new(caly_binary())
            .args(args)
            .env("HOME", env_state)
            .env("XDG_RUNTIME_DIR", env_state)
            .env("XDG_STATE_HOME", env_state.join("state"))
            .env("XDG_CONFIG_HOME", env_state.join("config"))
            .output()
            .map_err(|error| error.to_string())?;
        if !output.status.success() {
            return Err(format!(
                "client {:?} failed: stderr={} stdout={}",
                args,
                String::from_utf8_lossy(&output.stderr),
                String::from_utf8_lossy(&output.stdout),
            ));
        }
        String::from_utf8(output.stdout).map_err(|error| error.to_string())
    };

    assert_proxy_dry_run(&run, &runtime, &inline_dir)?;
    assert_proxy_apply(&run, &runtime, &inline_dir_after_apply)?;
    let _ = fs::remove_dir_all(&runtime);
    Ok(())
}
fn assert_proxy_dry_run(
    run: &ClientRunner,
    runtime: &Path,
    inline_dir: &Path,
) -> Result<(), String> {
    let dry = run(
        &["set", "proxy", "add", "vmess://round18-dryrun", "--json"],
        runtime,
    )?;
    if !dry.contains("\"ok\":true") {
        return Err(format!("dry-run did not report ok: {dry}"));
    }
    if !dry.contains("\"dry_run\":true") {
        return Err(format!("dry-run did not flag `dry_run:true`: {dry}"));
    }
    if !dry.contains("\"id\":") || !dry.contains("vmess://round18-dryrun") {
        return Err(format!("dry-run envelope missing id/uri: {dry}"));
    }
    let entries: Vec<_> = fs::read_dir(inline_dir)
        .map_err(|error| error.to_string())?
        .flatten()
        .collect();
    assert!(
        entries.is_empty(),
        "dry-run must not write any inline proxy file (found {} entries)",
        entries.len()
    );
    Ok(())
}

fn assert_proxy_apply(run: &ClientRunner, runtime: &Path, inline_dir: &Path) -> Result<(), String> {
    let apply = run(
        &[
            "set",
            "proxy",
            "add",
            "vmess://round18-dryrun",
            "--apply",
            "--json",
        ],
        runtime,
    )?;
    if !apply.contains("\"ok\":true") {
        return Err(format!("apply did not report ok: {apply}"));
    }
    if !apply.contains("\"dry_run\":false") {
        return Err(format!("apply did not flag `dry_run:false`: {apply}"));
    }
    let id = apply
        .split("\"id\":\"")
        .nth(1)
        .and_then(|part| part.split('"').next())
        .ok_or_else(|| format!("apply envelope missing id: {apply}"))?;
    let proxy_file = inline_dir.join(format!("{id}.json"));
    if !proxy_file.is_file() {
        return Err(format!(
            "apply did not write the proxy file at {}",
            proxy_file.display()
        ));
    }
    Ok(())
}

/// Round 19: `set sub add` dry-run is the canonical
/// example of a writer that does NOT touch disk in
/// dry-run mode.
#[test]
fn set_sub_dry_run_emits_envelope_and_does_not_write() -> Result<(), String> {
    let _guard = e2e_lock();
    let root = workspace_root();
    let _ = root;
    let runtime = unique_runtime("sub-dryrun");
    fs::create_dir_all(&runtime).map_err(|error| error.to_string())?;
    fs::create_dir_all(runtime.join("state")).map_err(|error| error.to_string())?;
    fs::create_dir_all(runtime.join("config").join("caly")).map_err(|error| error.to_string())?;
    let config_yaml = runtime.join("config").join("caly").join("config.yaml");
    fs::write(
        &config_yaml,
        "schema_version: 1\ncore: mihomo\nsubscriptions: {}\n",
    )
    .map_err(|error| error.to_string())?;

    let run = |args: &[&str]| -> Result<String, String> {
        let output = Command::new(caly_binary())
            .args(args)
            .env("HOME", &runtime)
            .env("XDG_RUNTIME_DIR", &runtime)
            .env("XDG_STATE_HOME", runtime.join("state"))
            .env("XDG_CONFIG_HOME", runtime.join("config"))
            .output()
            .map_err(|error| error.to_string())?;
        if !output.status.success() {
            return Err(format!(
                "client {:?} failed: stderr={} stdout={}",
                args,
                String::from_utf8_lossy(&output.stderr),
                String::from_utf8_lossy(&output.stdout),
            ));
        }
        String::from_utf8(output.stdout).map_err(|error| error.to_string())
    };

    let dry = run(&["set", "sub", "add", "https://example.com/sub", "--json"])?;
    if !dry.contains("\"ok\":true") {
        return Err(format!("dry-run did not report ok: {dry}"));
    }
    if !dry.contains("\"dry_run\":true") {
        return Err(format!("dry-run did not flag `dry_run:true`: {dry}"));
    }
    if !dry.contains("\"name\":\"https://example.com/sub\"") {
        return Err(format!("dry-run envelope missing name: {dry}"));
    }
    let after_dry = fs::read_to_string(&config_yaml).map_err(|error| error.to_string())?;
    if after_dry.contains("https://example.com/sub") {
        return Err(format!(
            "dry-run must not write the source into config.yaml (found URL in: {after_dry})"
        ));
    }

    let apply = run(&[
        "set",
        "sub",
        "add",
        "https://example.com/sub",
        "--apply",
        "--json",
    ])?;
    if !apply.contains("\"ok\":true") {
        return Err(format!("apply did not report ok: {apply}"));
    }
    if !apply.contains("\"dry_run\":false") {
        return Err(format!("apply did not flag `dry_run:false`: {apply}"));
    }
    let after_apply = fs::read_to_string(&config_yaml).map_err(|error| error.to_string())?;
    if !after_apply.contains("https://example.com/sub") {
        return Err(format!(
            "apply did not write the source into config.yaml: {after_apply}"
        ));
    }

    let _ = fs::remove_dir_all(&runtime);
    Ok(())
}

/// Round 19: `set profile edit` / `enable` / `disable`
/// dry-run must surface `NotDeclared` instead of
/// fabricating an `ok: would be …` success.
#[test]
fn set_profile_dry_run_rejects_unknown_id() -> Result<(), String> {
    let _guard = e2e_lock();
    let root = workspace_root();
    let _ = root;
    let runtime = unique_runtime("profile-dryrun");
    fs::create_dir_all(&runtime).map_err(|error| error.to_string())?;
    fs::create_dir_all(runtime.join("state")).map_err(|error| error.to_string())?;
    fs::create_dir_all(runtime.join("config").join("caly")).map_err(|error| error.to_string())?;
    let config_yaml = runtime.join("config").join("caly").join("config.yaml");
    fs::write(
        &config_yaml,
        "schema_version: 1\ncore: mihomo\nprofiles: []\n",
    )
    .map_err(|error| error.to_string())?;

    let run = |args: &[&str]| -> Result<String, String> {
        let output = Command::new(caly_binary())
            .args(args)
            .env("HOME", &runtime)
            .env("XDG_RUNTIME_DIR", &runtime)
            .env("XDG_STATE_HOME", runtime.join("state"))
            .env("XDG_CONFIG_HOME", runtime.join("config"))
            .output()
            .map_err(|error| error.to_string())?;
        if output.status.success() {
            return Err(format!(
                "client {:?} must fail: stdout={}",
                args,
                String::from_utf8_lossy(&output.stdout),
            ));
        }
        Ok(format!(
            "{}{}",
            String::from_utf8_lossy(&output.stdout),
            String::from_utf8_lossy(&output.stderr),
        ))
    };

    for leaf in [
        vec!["set", "profile", "edit", "missing-id", "--json"],
        vec!["set", "profile", "enable", "missing-id", "--json"],
        vec!["set", "profile", "disable", "missing-id", "--json"],
    ] {
        let combined = run(&leaf)?;
        if !combined.contains("profile.not_declared") {
            return Err(format!(
                "{leaf:?} must report profile.not_declared, got: {combined}"
            ));
        }
        if combined.contains("\"ok\":true") {
            return Err(format!("{leaf:?} must not report ok:true, got: {combined}"));
        }
    }

    let _ = fs::remove_dir_all(&runtime);
    Ok(())
}
