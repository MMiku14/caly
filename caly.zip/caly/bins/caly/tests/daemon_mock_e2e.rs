//! Mock-kernel daemon E2E (#68): the full daemon-lifecycle contract without
//! the pinned `vendor/bin` kernels, so every CI host exercises the
//! spawn → render → readiness → command → shutdown loop instead of skipping.
//!
//! The `caly_mock_kernel` binary emulates the small contract the daemon
//! composes against (version probe, `-t`/`check` validation exit codes and
//! the Clash API endpoints used by command and telemetry paths). These tests
//! never skip; a failure here is a real regression in the daemon lifecycle,
//! not an environment shortage. Real-kernel wire fidelity stays covered by
//! `daemon_real_e2e.rs` (skip-guarded, `CALY_REQUIRE_REAL_E2E=1` to enforce).

use std::{
    fs,
    io::{Read, Write},
    net::{TcpListener, TcpStream},
    os::unix::net::UnixStream,
    path::{Path, PathBuf},
    process::{Child, Command, ExitStatus},
    thread,
    time::{Duration, Instant},
};

const START_TIMEOUT: Duration = Duration::from_secs(12);
const STOP_TIMEOUT: Duration = Duration::from_secs(5);

/// Serializes the mock suite: a daemon under test owns its mocked controller
/// port, so two mock daemons in flight at once could still race the kernel
/// port allocator. Same discipline as the real suite's `E2E_LOCK`.
static E2E_LOCK: std::sync::Mutex<()> = std::sync::Mutex::new(());

fn e2e_lock<'a>() -> std::sync::MutexGuard<'a, ()> {
    match E2E_LOCK.lock() {
        Ok(guard) => guard,
        Err(poisoned) => poisoned.into_inner(),
    }
}

struct DaemonGuard {
    child: Child,
    runtime: PathBuf,
}

impl DaemonGuard {
    fn terminate(mut self) -> Result<ExitStatus, String> {
        signal_term(self.child.id())?;
        wait_for_exit(&mut self.child, STOP_TIMEOUT)
    }
}

impl Drop for DaemonGuard {
    fn drop(&mut self) {
        if self.child.try_wait().ok().flatten().is_none() {
            let _ = signal_term(self.child.id());
            let deadline = Instant::now() + STOP_TIMEOUT;
            while Instant::now() < deadline {
                if self.child.try_wait().ok().flatten().is_some() {
                    break;
                }
                thread::sleep(Duration::from_millis(20));
            }
            if self.child.try_wait().ok().flatten().is_none() {
                let _ = self.child.kill();
                let _ = self.child.wait();
            }
        }
        // Reap any orphaned mock kernel so its controller port cannot poison
        // a later phase (mirrors the real suite's runtime-path pkill).
        let _ = Command::new("pkill")
            .args(["-9", "-f"])
            .arg(self.runtime.display().to_string())
            .status();
    }
}

#[test]
fn mock_daemon_lifecycle_for_mihomo() -> Result<(), String> {
    let _guard = e2e_lock();
    run_mock_core("mihomo")
}

#[test]
fn mock_daemon_lifecycle_for_sing_box() -> Result<(), String> {
    let _guard = e2e_lock();
    run_mock_core("sing-box")
}

/// The daemon-lifecycle contract, identical in shape to the real-kernel
/// suite: boot, status, config apply, restart, stop/start, graceful exit —
/// with the one difference that the managed core is the mock binary, so the
/// test proves out-of-the-box coverage instead of skipping.
fn run_mock_core(core: &str) -> Result<(), String> {
    let controller_port = alloc_port()?;
    let runtime = unique_runtime(&format!("mock-{core}"));
    fs::create_dir_all(&runtime).map_err(|error| error.to_string())?;
    let lock = runtime.join("caly.lock");
    let workdir = runtime.join("caly").join("cores").join(core);
    fs::create_dir_all(&workdir).map_err(|error| error.to_string())?;
    let log = runtime.join("daemon.log");
    let log_handle = fs::File::create(&log).map_err(|error| error.to_string())?;
    let mut command = Command::new(caly_binary());
    command
        .arg("daemon")
        .env("CALY_CORE", core)
        .env("CALY_LOCK", &lock)
        .env("CALY_MIHOMO_DIR", &workdir)
        .env("XDG_RUNTIME_DIR", &runtime)
        .env("XDG_STATE_HOME", runtime.join("state"))
        .env("XDG_CONFIG_HOME", runtime.join("config"))
        .env("HOME", &runtime)
        .stdout(log_handle.try_clone().map_err(|error| error.to_string())?)
        .stderr(log_handle);
    if core == "sing-box" {
        command.env("CALY_SINGBOX_BIN", mock_binary());
        command.env(
            "CALY_SINGBOX_CONTROLLER",
            format!("127.0.0.1:{controller_port}"),
        );
    } else {
        command.env("CALY_MIHOMO_BIN", mock_binary());
        command.env(
            "CALY_MIHOMO_CONTROLLER",
            format!("127.0.0.1:{controller_port}"),
        );
    }
    let child = command.spawn().map_err(|error| error.to_string())?;
    let daemon = DaemonGuard {
        child,
        runtime: runtime.clone(),
    };
    let socket = socket_path(&runtime);
    wait_for_socket(&socket, START_TIMEOUT)?;
    wait_for_port(controller_port, START_TIMEOUT).map_err(|error| {
        let log = fs::read_to_string(runtime.join("daemon.log")).unwrap_or_default();
        format!("{error}\ndaemon log:\n{log}")
    })?;
    // The readiness gate must be satisfied by OUR mock — not by a stray
    // real kernel on the same port — so the suite cannot silently test the
    // wrong core implementation.
    let banner = http_get(controller_port, "/version")?;
    if !banner.contains("caly-mock-kernel") {
        return Err(format!(
            "controller answered by an unexpected implementation: {banner}"
        ));
    }

    let status = client(core, &runtime, &["show", "status", "--json"])?;
    if !status.contains(&format!("\"core\":\"{core}\""))
        || !status.contains("\"run_state\":\"running\"")
    {
        return Err(format!("unexpected {core} status: {status}"));
    }
    check_config_apply(core, &runtime)?;
    client(core, &runtime, &["set", "core", "restart", "--json"])?;
    client(core, &runtime, &["set", "core", "stop", "--json"])?;
    wait_for_port_closed(controller_port, STOP_TIMEOUT)?;
    client(core, &runtime, &["set", "core", "start", "--json"])?;
    wait_for_port(controller_port, START_TIMEOUT)?;

    let status = daemon.terminate()?;
    if !status.success() {
        return Err(format!("{core} mock daemon exited with {status}"));
    }
    if socket.exists() || lock.exists() {
        return Err(format!("{core} mock daemon leaked socket or lock"));
    }
    fs::remove_dir_all(&runtime).map_err(|error| error.to_string())
}

/// Exercises the mock binary standalone: the three invocation modes the
/// daemon composes (`version`, Mihomo `-t`, sing-box `check`) plus one
/// direct serve loop against a Mihomo-shaped config.
#[test]
fn mock_kernel_serves_the_advertised_contract() -> Result<(), String> {
    let _guard = e2e_lock();
    let version = Command::new(mock_binary())
        .arg("version")
        .output()
        .map_err(|error| error.to_string())?;
    if !version.status.success() {
        return Err("mock kernel rejected the version probe".to_owned());
    }
    let root = unique_runtime("mock-selftest");
    fs::create_dir_all(&root).map_err(|error| error.to_string())?;
    let port = alloc_port()?;
    let yaml = root.join("mihomo.yaml");
    fs::write(
        &yaml,
        format!("mixed-port: 7890\nexternal-controller: 127.0.0.1:{port}\nsecret: mock\n"),
    )
    .map_err(|error| error.to_string())?;
    let validate = Command::new(mock_binary())
        .args(["-d", ".", "-f"])
        .arg(&yaml)
        .arg("-t")
        .output()
        .map_err(|error| error.to_string())?;
    if !validate.status.success() {
        return Err("mock kernel rejected the Mihomo -t validation mode".to_owned());
    }
    let json = root.join("sing-box.json");
    fs::write(
        &json,
        format!("{{\"experimental\":{{\"clash_api\":{{\"external_controller\":\"127.0.0.1:{port}\"}}}}}}"),
    )
    .map_err(|error| error.to_string())?;
    let check = Command::new(mock_binary())
        .arg("check")
        .arg("-c")
        .arg(&json)
        .output()
        .map_err(|error| error.to_string())?;
    if !check.status.success() {
        return Err("mock kernel rejected the sing-box check mode".to_owned());
    }
    let mut serve = Command::new(mock_binary())
        .args(["-d", ".", "-f"])
        .arg(&yaml)
        .spawn()
        .map_err(|error| error.to_string())?;
    let outcome = wait_for_port(port, START_TIMEOUT)
        .and_then(|()| http_get(port, "/version"))
        .and_then(|body| {
            if body.contains("caly-mock-kernel") {
                Ok(())
            } else {
                Err(format!("unexpected /version body: {body}"))
            }
        });
    let _ = serve.kill();
    let _ = serve.wait();
    fs::remove_dir_all(&root).map_err(|error| error.to_string())?;
    outcome
}

/// One raw HTTP GET against the mocked controller, returning the body.
fn http_get(port: u16, path: &str) -> Result<String, String> {
    let mut stream = TcpStream::connect(("127.0.0.1", port)).map_err(|error| error.to_string())?;
    stream
        .set_read_timeout(Some(Duration::from_secs(3)))
        .map_err(|error| error.to_string())?;
    write!(
        stream,
        "GET {path} HTTP/1.1\r\nHost: 127.0.0.1\r\nConnection: close\r\n\r\n"
    )
    .map_err(|error| error.to_string())?;
    let mut response = String::new();
    stream
        .read_to_string(&mut response)
        .map_err(|error| error.to_string())?;
    if !response.starts_with("HTTP/1.1 200") {
        return Err(format!("GET {path} -> {response}"));
    }
    Ok(response)
}

fn check_config_apply(core: &str, runtime: &Path) -> Result<(), String> {
    let apply = client(core, runtime, &["set", "config", "apply", "--json"])?;
    if !apply.contains("\"state\":3") {
        return Err(format!("config apply did not complete: {apply}"));
    }
    let committed = if core == "mihomo" {
        runtime.join("config").join("caly").join("mihomo.yaml")
    } else {
        runtime.join("config").join("caly").join("sing-box.json")
    };
    if !committed.is_file() {
        return Err(format!(
            "config apply did not publish {}",
            committed.display()
        ));
    }
    Ok(())
}

/// The thin JSON-framed CLI client used to drive daemon operations.
fn client(core: &str, runtime: &Path, arguments: &[&str]) -> Result<String, String> {
    let output = Command::new(caly_binary())
        .args(arguments)
        .env("CALY_CORE", core)
        .env("XDG_RUNTIME_DIR", runtime)
        .output()
        .map_err(|error| error.to_string())?;
    if !output.status.success() {
        return Err(format!(
            "client {:?} failed: stderr={} stdout={}",
            arguments,
            String::from_utf8_lossy(&output.stderr),
            String::from_utf8_lossy(&output.stdout)
        ));
    }
    String::from_utf8(output.stdout).map_err(|error| error.to_string())
}

/// The owner-only UDS socket path the daemon binds under an XDG runtime root.
fn socket_path(runtime: &Path) -> PathBuf {
    runtime.join("caly").join("daemon.sock")
}

fn wait_for_socket(path: &Path, timeout: Duration) -> Result<(), String> {
    let deadline = Instant::now() + timeout;
    while Instant::now() < deadline {
        if UnixStream::connect(path).is_ok() {
            return Ok(());
        }
        thread::sleep(Duration::from_millis(20));
    }
    Err(format!("socket did not become ready: {}", path.display()))
}

fn wait_for_port(port: u16, timeout: Duration) -> Result<(), String> {
    let deadline = Instant::now() + timeout;
    while Instant::now() < deadline {
        if TcpStream::connect(("127.0.0.1", port)).is_ok() {
            return Ok(());
        }
        thread::sleep(Duration::from_millis(20));
    }
    Err(format!("controller port {port} did not become ready"))
}

fn wait_for_port_closed(port: u16, timeout: Duration) -> Result<(), String> {
    let deadline = Instant::now() + timeout;
    while Instant::now() < deadline {
        if TcpStream::connect(("127.0.0.1", port)).is_err() {
            return Ok(());
        }
        thread::sleep(Duration::from_millis(20));
    }
    Err(format!("controller port {port} remained open"))
}

fn wait_for_exit(child: &mut Child, timeout: Duration) -> Result<ExitStatus, String> {
    let deadline = Instant::now() + timeout;
    while Instant::now() < deadline {
        if let Some(status) = child.try_wait().map_err(|error| error.to_string())? {
            return Ok(status);
        }
        thread::sleep(Duration::from_millis(20));
    }
    let _ = child.kill();
    child.wait().map_err(|error| error.to_string())
}

fn signal_term(pid: u32) -> Result<(), String> {
    let status = Command::new("kill")
        .args(["-TERM", &pid.to_string()])
        .status()
        .map_err(|error| error.to_string())?;
    if status.success() {
        Ok(())
    } else {
        Err(format!("cannot signal daemon {pid}: {status}"))
    }
}

/// Allocates a free TCP port by binding a listener and releasing it; the
/// mock binds it moments later, so collisions are practically impossible.
fn alloc_port() -> Result<u16, String> {
    let listener = TcpListener::bind(("127.0.0.1", 0)).map_err(|error| error.to_string())?;
    let port = listener
        .local_addr()
        .map_err(|error| error.to_string())?
        .port();
    drop(listener);
    Ok(port)
}

/// A short runtime root under `/tmp` (the workspace-root layout historically
/// exceeded the 108-byte Unix `SUN_LEN` for the UDS socket).
fn unique_runtime(name: &str) -> PathBuf {
    caly_platform::paths::test_helpers::unique_path_under("caly-e2e", name)
}

fn caly_binary() -> &'static str {
    env!("CARGO_BIN_EXE_caly")
}

fn mock_binary() -> &'static str {
    env!("CARGO_BIN_EXE_caly_mock_kernel")
}
