//! Real daemon + UDS + kernel lifecycle E2E.
//!
//! The ordinary test suite reports a skip when pinned binaries are absent.
//! `CALY_REQUIRE_REAL_E2E=1` turns missing prerequisites into a hard failure.

#![allow(clippy::panic)]
// L1: like `panic` above, these assertion-style macros in test helpers stay
// allowed here; the workspace denies still govern all production code.
#![allow(clippy::todo, clippy::unimplemented, clippy::unreachable)]

mod offline;

mod common;

use common::{
    DaemonGuard, START_TIMEOUT, STOP_TIMEOUT, alloc_port, caly_binary, check_config_apply,
    client, e2e_lock, socket_path, unique_runtime, wait_for_exit,
    wait_for_port, wait_for_port_closed, wait_for_socket,
};

use std::{
    fs,
    path::{Path, PathBuf},
    process::Command,
};

#[test]
fn real_daemon_lifecycle_for_pinned_kernels() -> Result<(), String> {
    let _guard = e2e_lock();
    let root = workspace_root();
    let mihomo = root.join("vendor/bin/mihomo");
    let sing_box = root.join("vendor/bin/sing-box");
    if !mihomo.is_file() || !sing_box.is_file() {
        if require_real_e2e() {
            return Err(
                "pinned kernels are required; run scripts/fetch-test-kernels.sh".to_owned(),
            );
        }
        eprintln!("skipping: pinned Mihomo/sing-box binaries are unavailable");
        return Ok(());
    }
    let mihomo_runtime = unique_runtime("mihomo");
    run_core(&root, "mihomo", &mihomo, &mihomo_runtime)?;
    let sing_runtime = unique_runtime("sing-box");
    run_core(&root, "sing-box", &sing_box, &sing_runtime)
}


fn run_core(_root: &Path, core: &str, binary: &Path, runtime: &Path) -> Result<(), String> {
    // `alloc_port` binds-and-releases, so another process can grab the port
    // in the window before the daemon's kernel binds it (observed in the
    // wild: controller readiness timeout). Retry the whole launch on a fresh
    // port instead of trusting the "practically impossible" assumption.
    for attempt in 1..=3 {
        let controller_port = alloc_port()?;
        let mixed_port = alloc_port()?;
        match run_core_once(core, binary, controller_port, mixed_port, runtime) {
            Ok(()) => return Ok(()),
            Err(error) if attempt < 3 && error.contains("did not become ready") => {
                eprintln!("port {controller_port} contested (attempt {attempt}/3); retrying");
            }
            Err(error) => return Err(error),
        }
    }
    unreachable!("loop always returns")
}

fn run_core_once(
    core: &str,
    binary: &Path,
    controller_port: u16,
    mixed_port: u16,
    runtime: &Path,
) -> Result<(), String> {
    fs::create_dir_all(runtime).map_err(|error| error.to_string())?;
    let lock = runtime.join("caly.lock");
    let workdir = runtime.join("caly").join("cores").join(core);
    fs::create_dir_all(&workdir).map_err(|error| error.to_string())?;
    let mut command = Command::new(caly_binary());
    let log = runtime.join("daemon.log");
    let log_handle = fs::File::create(&log).map_err(|error| error.to_string())?;
    command
        .arg("daemon")
        .env("CALY_CORE", core)
        .env("CALY_LOCK", &lock)
        .env("CALY_MIHOMO_DIR", &workdir)
        // Ephemeral mixed port (product override, see caly-cli::config
        // kernel_from_config): the real kernel binds it, so a fixed 7890
        // would race with any other daemon on this host.
        .env("CALY_MIXED_PORT", mixed_port.to_string())
        .env("XDG_RUNTIME_DIR", runtime)
        .env("XDG_STATE_HOME", runtime.join("state"))
        .env("XDG_CONFIG_HOME", runtime.join("config"))
        .env("HOME", runtime)
        .stdout(log_handle.try_clone().map_err(|error| error.to_string())?)
        .stderr(log_handle);
    if core == "sing-box" {
        command.env("CALY_SINGBOX_BIN", binary);
        command.env(
            "CALY_SINGBOX_CONTROLLER",
            format!("127.0.0.1:{controller_port}"),
        );
    } else {
        command.env("CALY_MIHOMO_BIN", binary);
        command.env(
            "CALY_MIHOMO_CONTROLLER",
            format!("127.0.0.1:{controller_port}"),
        );
    }
    let child = command.spawn().map_err(|error| error.to_string())?;
    let daemon = DaemonGuard {
        child,
        runtime: runtime.to_path_buf(),
    };
    let socket = socket_path(runtime);
    wait_for_socket(&socket, START_TIMEOUT)?;
    wait_for_port(controller_port, START_TIMEOUT).map_err(|error| {
        let log = fs::read_to_string(runtime.join("daemon.log")).unwrap_or_default();
        format!("{error}\ndaemon log:\n{log}")
    })?;

    let status = client(core, runtime, &["show", "status", "--json"])?;
    if !status.contains(&format!("\"core\":\"{core}\""))
        || !status.contains("\"run_state\":\"running\"")
    {
        return Err(format!("unexpected {core} status: {status}"));
    }
    check_config_apply(core, runtime)?;
    client(core, runtime, &["set", "core", "restart", "--json"])?;
    client(core, runtime, &["set", "core", "stop", "--json"])?;
    wait_for_port_closed(controller_port, STOP_TIMEOUT)?;
    client(core, runtime, &["set", "core", "start", "--json"])?;
    wait_for_port(controller_port, START_TIMEOUT)?;

    let status = daemon.terminate()?;
    if !status.success() {
        return Err(format!("{core} daemon exited with {status}"));
    }
    if socket.exists() || lock.exists() {
        return Err(format!("{core} daemon leaked socket or lock"));
    }
    if let Err(error) = fs::remove_dir_all(runtime) {
        return Err(error.to_string());
    }
    Ok(())
}


fn workspace_root() -> PathBuf {
    Path::new(env!("CARGO_MANIFEST_DIR"))
        .parent()
        .and_then(Path::parent)
        .unwrap_or_else(|| Path::new("."))
        .to_path_buf()
}


fn require_real_e2e() -> bool {
    std::env::var("CALY_REQUIRE_REAL_E2E").as_deref() == Ok("1")
}

/// Spawn the real daemon (mihomo core) for the `set daemon *` wire tests.
/// Mirrors `run_core`'s retry: `alloc_port` binds-and-releases, so another
/// process can grab the port before the daemon's kernel binds it. Retry the
/// whole launch on a fresh port, but ONLY when the controller did not become
/// ready (contention), never to mask a real failure.
fn start_daemon_for_wire_tests(
    runtime_suffix: &str,
    mihomo: &Path,
) -> Result<(DaemonGuard, PathBuf), String> {
    for attempt in 1..=3 {
        let port = alloc_port()?;
        match start_daemon_once(runtime_suffix, mihomo, port) {
            Ok(daemon) => {
                let runtime = daemon.runtime.clone();
                return Ok((daemon, runtime));
            }
            Err(error) if attempt < 3 && error.contains("did not become ready") => {
                eprintln!("port {port} contested (attempt {attempt}/3); retrying");
            }
            Err(error) => return Err(error),
        }
    }
    unreachable!("loop always returns")
}

fn start_daemon_once(
    runtime_suffix: &str,
    mihomo: &Path,
    controller_port: u16,
) -> Result<DaemonGuard, String> {
    let runtime = unique_runtime(runtime_suffix);
    fs::create_dir_all(&runtime).map_err(|error| error.to_string())?;
    let socket = socket_path(&runtime);
    let lock = runtime.join("caly.lock");
    let workdir = runtime.join("caly/cores/mihomo");
    fs::create_dir_all(&workdir).map_err(|error| error.to_string())?;
    let log = runtime.join("daemon.log");
    let log_handle = fs::File::create(&log).map_err(|error| error.to_string())?;
    let mut daemon_cmd = Command::new(caly_binary());
    daemon_cmd
        .arg("daemon")
        .env("CALY_CORE", "mihomo")
        .env("CALY_LOCK", &lock)
        .env("CALY_MIHOMO_DIR", &workdir)
        .env("XDG_RUNTIME_DIR", &runtime)
        .env("XDG_STATE_HOME", runtime.join("state"))
        .env("XDG_CONFIG_HOME", runtime.join("config"))
        .env("HOME", &runtime)
        .env("CALY_MIHOMO_BIN", mihomo)
        .env(
            "CALY_MIHOMO_CONTROLLER",
            format!("127.0.0.1:{controller_port}"),
        )
        .stdout(log_handle.try_clone().map_err(|error| error.to_string())?)
        .stderr(log_handle);
    let daemon = DaemonGuard {
        child: daemon_cmd.spawn().map_err(|error| error.to_string())?,
        runtime: runtime.clone(),
    };
    wait_for_socket(&socket, START_TIMEOUT)?;
    wait_for_port(controller_port, START_TIMEOUT).map_err(|error| {
        let log = fs::read_to_string(runtime.join("daemon.log")).unwrap_or_default();
        format!("{error}\ndaemon log:\n{log}")
    })?;
    Ok(daemon)
}

/// `set daemon stop` is a real wire command
/// (`WireCommand::StopDaemon`). The server tears down
/// the runtime after serializing the response. The
/// client receives the final operation status, then
/// the daemon process exits and the UDS socket +
/// lockfile are cleaned up.
///
/// This test is the integration-level guarantee that
/// the typed `StopDaemon` path is wired end-to-end; the
/// unit suite only covers the dispatch shape.
#[test]
fn set_daemon_stop_exits_daemon_and_cleans_up() -> Result<(), String> {
    let _guard = e2e_lock();
    let root = workspace_root();
    let mihomo = root.join("vendor/bin/mihomo");
    if !mihomo.is_file() {
        if require_real_e2e() {
            return Err(
                "pinned kernels are required; run scripts/fetch-test-kernels.sh".to_owned(),
            );
        }
        eprintln!("skipping: pinned Mihomo binary is unavailable");
        return Ok(());
    }
    let (mut daemon, runtime) = start_daemon_for_wire_tests("daemon-stop", &mihomo)?;
    let socket = socket_path(&runtime);
    let lock = runtime.join("caly.lock");

    // Sanity: `show status` works.
    let _ = client("mihomo", &runtime, &["show", "status", "--json"])?;

    // `set daemon stop` is a real wire command.
    // The client receives a successful operation status;
    // the server then tears down the runtime, which
    // closes the UDS socket and exits the process.
    let stop = client("mihomo", &runtime, &["set", "daemon", "stop", "--json"])?;
    if !stop.contains("\"ok\":true") {
        return Err(format!("set daemon stop did not return ok: {stop}"));
    }

    // The daemon process should exit on its own. Wait
    // for it (the GracefulShutdown path runs in
    // ~100ms; the test allows 5s for slow CI).
    let exited = wait_for_exit(&mut daemon.child, STOP_TIMEOUT)?;
    if !exited.success() {
        return Err(format!("daemon exited with {exited}"));
    }
    if socket.exists() || lock.exists() {
        return Err("daemon leaked socket or lock after stop".to_owned());
    }

    let _ = fs::remove_dir_all(&runtime);
    Ok(())
}

/// `set daemon reload` is a real wire command
/// (`WireCommand::ReloadConfig`). The server
/// completes the operation on the application side
/// (the config actor's `reload_config` reports an
/// empty success delta) and the client receives the
/// final `Completed` status. The daemon stays up —
/// reload is non-destructive.
///
/// This test guards the typed `ReloadConfig` path
/// against a regression to the planned_ok stub.
#[test]
fn set_daemon_reload_returns_completed_and_keeps_daemon_up() -> Result<(), String> {
    let _guard = e2e_lock();
    let root = workspace_root();
    let mihomo = root.join("vendor/bin/mihomo");
    if !mihomo.is_file() {
        if require_real_e2e() {
            return Err(
                "pinned kernels are required; run scripts/fetch-test-kernels.sh".to_owned(),
            );
        }
        eprintln!("skipping: pinned Mihomo binary is unavailable");
        return Ok(());
    }
    let (mut daemon, runtime) = start_daemon_for_wire_tests("daemon-reload", &mihomo)?;
    let _ = client("mihomo", &runtime, &["show", "status", "--json"])?;

    // `set daemon reload` is a real wire command.
    // The server returns a Completed operation status.
    let reload = client("mihomo", &runtime, &["set", "daemon", "reload", "--json"])?;
    if !reload.contains("\"ok\":true") || !reload.contains("\"state\":3") {
        return Err(format!("set daemon reload did not complete: {reload}"));
    }

    // The daemon must stay up after reload — it's a
    // non-destructive runtime reconfiguration.
    let status = client("mihomo", &runtime, &["show", "status", "--json"])?;
    if !status.contains("\"run_state\":\"running\"") {
        return Err(format!("daemon stopped after reload: {status}"));
    }
    if daemon.child.try_wait().ok().flatten().is_some() {
        return Err("daemon exited after reload".to_owned());
    }

    // Tidy up via `set daemon stop` so the lockfile /
    // socket are released before the test runtime is
    // removed.
    let _ = client("mihomo", &runtime, &["set", "daemon", "stop", "--json"]);
    let _ = wait_for_exit(&mut daemon.child, STOP_TIMEOUT);

    let _ = fs::remove_dir_all(&runtime);
    Ok(())
}

/// `set daemon restart` is a client-side
/// composition of `StopDaemon` (typed wire command)
/// followed by `Command::spawn("caly daemon")`. The
/// new daemon inherits the same env / XDG / config
/// the operator had running, so a restart is
/// transparent: same UDS socket path, same
/// controller port, same `CALY_*` env vars.
///
/// The test verifies the contract the client-side
/// spawn is responsible for: the Stop completes,
/// the old daemon exits, the spawned PID is
/// reported, and the spawned process exists. The
/// new daemon's full UDS bind is environment-
/// dependent (the auto-start must wait for the
/// previous core process to release the controller
/// port; a running kernel already bound to the
/// same port races the new boot) so this test
/// scopes the assertion to the client contract
/// rather than the full post-restart reachability
/// already covered by `set_daemon_stop_*` and the
/// main `real_daemon_lifecycle_for_pinned_kernels`
/// flow.
#[test]
fn set_daemon_restart_reports_spawned_pid_and_exits_old_daemon() -> Result<(), String> {
    let _guard = e2e_lock();
    let root = workspace_root();
    let mihomo = root.join("vendor/bin/mihomo");
    if !mihomo.is_file() {
        if require_real_e2e() {
            return Err(
                "pinned kernels are required; run scripts/fetch-test-kernels.sh".to_owned(),
            );
        }
        eprintln!("skipping: pinned Mihomo binary is unavailable");
        return Ok(());
    }
    let (mut daemon, runtime) = start_daemon_for_wire_tests("daemon-restart", &mihomo)?;
    let _ = client("mihomo", &runtime, &["show", "status", "--json"])?;

    // `set daemon restart` is a client-side
    // `Stop` + spawn. The first envelope is the
    // operation status of the Stop ({"ok":true,
    // "state":3, ...}), the second is the spawn
    // ack ({"ok":true,"pid":<new>}). Both must
    // succeed.
    let restart = client("mihomo", &runtime, &["set", "daemon", "restart", "--json"])?;
    if !restart.contains("\"ok\":true") {
        return Err(format!("set daemon restart did not report ok: {restart}"));
    }
    if !restart.contains("\"pid\":") {
        return Err(format!(
            "set daemon restart did not return a pid: {restart}"
        ));
    }
    // The Stop operation must have reached Completed
    // (state 3) — the previous test (stop only)
    // already proves the typed wire path; the
    // restart just chains two calls.
    if !restart.contains("\"state\":3") {
        return Err(format!(
            "set daemon restart did not show Completed stop: {restart}"
        ));
    }

    // Old daemon must exit cleanly. The Drop on
    // DaemonGuard will TERM the new (reused PID
    // slot) process if it never exited; the
    // wait_for_exit first asserts the old PID
    // exited so we don't accidentally TERM a
    // still-running process.
    let exited = wait_for_exit(&mut daemon.child, STOP_TIMEOUT)?;
    if !exited.success() {
        return Err(format!("old daemon exited with {exited}"));
    }

    // Best-effort cleanup of the spawned daemon
    // (its env points to the test's runtime dir,
    // and pkill by runtime path reaps it without
    // us holding its handle).
    let _ = Command::new("pkill")
        .args(["-TERM", "-f"])
        .arg(format!("{} daemon", caly_binary()))
        .status();

    let _ = fs::remove_dir_all(&runtime);
    Ok(())
}
