//! Shared daemon-lifecycle E2E harness (mock + real suites).
//!
//! Both suites spawn a real `caly` daemon and differ only in the kernel
//! behind it, so the suite lock, daemon guard, wait probes and client
//! helpers live here instead of drifting as two copies.

use std::{
    env, fs,
    net::{TcpListener, TcpStream},
    os::unix::net::UnixStream,
    path::{Path, PathBuf},
    process::{self, Child, Command, ExitStatus},
    thread,
    time::{Duration, Instant},
};

pub const START_TIMEOUT: Duration = Duration::from_secs(12);

pub const STOP_TIMEOUT: Duration = Duration::from_secs(5);

/// Serializes the e2e suite. The real daemons in
/// these tests bind UDS sockets under `/tmp` and
/// TCP controllers on loopback ports; running them
/// in parallel can race the kernel port allocator
/// (the historical `alloc_port` helper drops its
/// probe listener before the daemon binds, so a
/// concurrent allocation can hand out the same
/// port). All four real-daemon tests acquire this
/// lock so the suite is deterministic on shared
/// CI hosts without changing the test contracts.
/// The lock is a cross-process `mkdir` directory
/// (a process-local `Mutex` cannot see the parallel
/// mock-e2e binary — agent audit); a
/// stale lock whose recorded pid is dead is taken
/// over after a wait.
pub struct E2eLockGuard(PathBuf);

impl Drop for E2eLockGuard {
    fn drop(&mut self) {
        let _ = fs::remove_dir_all(&self.0);
    }
}

/// Acquires the suite-wide lock for the duration
/// of the calling test. Waits up to 90 s for a
/// live holder; a dead holder's lock is reclaimed.
pub fn e2e_lock() -> E2eLockGuard {
    use Instant;
    let path = env::temp_dir().join("caly-e2e-suite.lock");
    let deadline = Instant::now() + Duration::from_secs(90);
    loop {
        match fs::create_dir(&path) {
            Ok(()) => break,
            Err(error) if error.kind() == std::io::ErrorKind::AlreadyExists => {
                let holder = fs::read_to_string(path.join("pid"))
                    .ok()
                    .and_then(|text| text.trim().parse::<i32>().ok());
                let holder_alive = holder.is_some_and(|pid| {
                    process::Command::new("kill")
                        .args(["-0", &pid.to_string()])
                        .status()
                        .is_ok_and(|status| status.success())
                });
                if !holder_alive {
                    // A missing/unparseable pid does NOT mean the holder is
                    // dead: an acquirer creates the dir and only then writes
                    // the pid file, so a waiter polling inside that window
                    // would steal the lock from a LIVE holder — two suites
                    // then run concurrently (observed in the wild: two
                    // daemons racing for the fixed mixed-port 7890, and the
                    // restart test's pkill terminating the lifecycle test's
                    // daemon mid-phase). Only take over a dir whose pid is
                    // missing AND whose mtime is older than a few seconds
                    // (holder died inside the create -> write window). A
                    // live holder's window is microseconds, so it resolves
                    // on the next poll.
                    let stale = fs::metadata(&path)
                        .and_then(|meta| meta.modified())
                        .ok()
                        .and_then(|modified| modified.elapsed().ok())
                        .is_some_and(|age| age > Duration::from_secs(5));
                    if stale {
                        let _ = fs::remove_dir_all(&path);
                        continue;
                    }
                }
                if Instant::now() > deadline {
                    panic!("timed out waiting for the e2e suite lock");
                } else {
                    // keep waiting for the live holder
                }
                thread::sleep(Duration::from_millis(50));
            }
            Err(error) => panic!("cannot acquire the e2e suite lock: {error}"),
        }
    }
    let _ = fs::write(path.join("pid"), process::id().to_string());
    E2eLockGuard(path)
}

pub struct DaemonGuard {
    pub child: Child,
    pub runtime: PathBuf,
}

impl DaemonGuard {
    pub fn terminate(mut self) -> Result<ExitStatus, String> {
        signal_term(self.child.id())?;
        wait_for_exit(&mut self.child, STOP_TIMEOUT)
    }
}

impl Drop for DaemonGuard {
    fn drop(&mut self) {
        // Graceful TERM first so the daemon stops and reaps its core process;
        // a bare SIGKILL orphans the kernel, whose ports then block the next
        // test phase. Fall back to KILL only if the daemon does not exit.
        if self.child.try_wait().ok().flatten().is_none() {
            let _ = signal_term(self.child.id());
            let deadline = Instant::now() + STOP_TIMEOUT;
            while Instant::now() < deadline {
                if self.child.try_wait().ok().flatten().is_some() {
                    break;
                }
                thread::sleep(Duration::from_millis(20));
            }
            if self.child.try_wait().ok().flatten().is_none() {
                let _ = self.child.kill();
                let _ = self.child.wait();
            }
        }
        // A killed or stalled daemon can orphan its managed kernel, whose
        // ports would poison the next phase; reap by runtime-path match.
        let _ = Command::new("pkill")
            .args(["-9", "-f"])
            .arg(self.runtime.display().to_string())
            .status();
    }
}

/// The owner-only UDS socket path the daemon binds under an XDG runtime root.
pub fn socket_path(runtime: &Path) -> PathBuf {
    runtime.join("caly").join("daemon.sock")
}

pub fn wait_for_socket(path: &Path, timeout: Duration) -> Result<(), String> {
    let deadline = Instant::now() + timeout;
    while Instant::now() < deadline {
        if UnixStream::connect(path).is_ok() {
            return Ok(());
        }
        thread::sleep(Duration::from_millis(20));
    }
    Err(format!("socket did not become ready: {}", path.display()))
}

pub fn wait_for_port_closed(port: u16, timeout: Duration) -> Result<(), String> {
    let deadline = Instant::now() + timeout;
    while Instant::now() < deadline {
        if TcpStream::connect(("127.0.0.1", port)).is_err() {
            return Ok(());
        }
        thread::sleep(Duration::from_millis(20));
    }
    Err(format!("controller port {port} remained open"))
}

pub fn wait_for_port(port: u16, timeout: Duration) -> Result<(), String> {
    let deadline = Instant::now() + timeout;
    while Instant::now() < deadline {
        if TcpStream::connect(("127.0.0.1", port)).is_ok() {
            return Ok(());
        }
        thread::sleep(Duration::from_millis(20));
    }
    Err(format!("controller port {port} did not become ready"))
}

pub fn wait_for_exit(child: &mut Child, timeout: Duration) -> Result<ExitStatus, String> {
    let deadline = Instant::now() + timeout;
    while Instant::now() < deadline {
        if let Some(status) = child.try_wait().map_err(|error| error.to_string())? {
            return Ok(status);
        }
        thread::sleep(Duration::from_millis(20));
    }
    let _ = child.kill();
    child.wait().map_err(|error| error.to_string())
}

pub fn signal_term(pid: u32) -> Result<(), String> {
    let status = Command::new("kill")
        .args(["-TERM", &pid.to_string()])
        .status()
        .map_err(|error| error.to_string())?;
    if status.success() {
        Ok(())
    } else {
        Err(format!("cannot signal daemon {pid}: {status}"))
    }
}

/// Allocates a free TCP port by binding a listener and releasing it; the
/// daemon binds it moments later, so collisions are practically impossible.
pub fn alloc_port() -> Result<u16, String> {
    let listener = TcpListener::bind(("127.0.0.1", 0)).map_err(|error| error.to_string())?;
    let port = listener
        .local_addr()
        .map_err(|error| error.to_string())?
        .port();
    drop(listener);
    Ok(port)
}

/// A short runtime root under `/tmp`: the historical workspace-root layout
/// exceeded the 108-byte Unix `SUN_LEN` for the UDS socket on deep checkouts.
pub fn unique_runtime(core: &str) -> PathBuf {
    caly_platform::paths::test_helpers::unique_path_under("caly-e2e", core)
}

pub fn caly_binary() -> &'static str {
    env!("CARGO_BIN_EXE_caly")
}

pub fn check_config_apply(core: &str, runtime: &Path) -> Result<(), String> {
    // Exercise the config-apply loop: render → validate → commit. Both cores
    // publish an owner-only generation under the XDG config root (sing-box
    // landed its dedicated backend, so no more fail-fast).
    let apply = client(core, runtime, &["set", "config", "apply", "--json"])?;
    if !apply.contains("\"state\":3") {
        return Err(format!("config apply did not complete: {apply}"));
    }
    let committed = if core == "mihomo" {
        runtime.join("config").join("caly").join("mihomo.yaml")
    } else {
        runtime.join("config").join("caly").join("sing-box.json")
    };
    if !committed.is_file() {
        return Err(format!(
            "config apply did not publish {}",
            committed.display()
        ));
    }
    Ok(())
}

/// The thin JSON-framed client used to drive daemon operations.
pub fn client(core: &str, runtime: &Path, arguments: &[&str]) -> Result<String, String> {
    let output = Command::new(caly_binary())
        .args(arguments)
        .env("CALY_CORE", core)
        .env("XDG_RUNTIME_DIR", runtime)
        .output()
        .map_err(|error| error.to_string())?;
    if !output.status.success() {
        return Err(format!(
            "client {:?} failed: stderr={} stdout={}",
            arguments,
            String::from_utf8_lossy(&output.stderr),
            String::from_utf8_lossy(&output.stdout)
        ));
    }
    String::from_utf8(output.stdout).map_err(|error| error.to_string())
}
