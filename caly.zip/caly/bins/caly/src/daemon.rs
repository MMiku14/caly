//! Daemon runtime assembly: Tokio runtime, UDS/TCP transport, lock and cleanup.
//!
//! Kept as a sibling of `main.rs` so the composition root stays within the
//! project's file-size limit.

use std::{path::PathBuf, process::ExitCode};

use caly_domain::DaemonInstanceId;
use caly_platform::instance_lock::{
    InstanceLock, InstanceLockBackend, LinuxInstanceLockBackend, LockOwner,
    current_process_start_id,
};
use caly_protocol::protocol::v2::{DecodeLimits, all_features};
use caly_server::{json::ServiceAdapter, uds::serve_owner_only_until};

/// Owns the shared daemon Tokio runtime and the running application tasks.
pub(crate) struct DaemonRuntime {
    runtime: tokio::runtime::Runtime,
    running: caly_application::composition::RunningApplication,
    pub(crate) daemon_instance: [u8; 16],
    pub(crate) socket: PathBuf,
    pub(crate) listen: Option<std::net::SocketAddr>,
}

pub(crate) fn start_daemon_runtime(
    application: caly_application::composition::ApplicationComposition,
    daemon_instance: DaemonInstanceId,
    socket: PathBuf,
    listen: Option<std::net::SocketAddr>,
    auto_start_core: bool,
) -> Result<DaemonRuntime, String> {
    let runtime = tokio::runtime::Runtime::new()
        .map_err(|error| format!("daemon runtime creation failed: {error}"))?;
    let running = runtime.block_on(async {
        application
            .start_runtime(auto_start_core)
            .map_err(|error| format!("application runtime failed: {error:?}"))
    })?;
    Ok(DaemonRuntime {
        runtime,
        running,
        daemon_instance: daemon_instance.into_bytes(),
        socket,
        listen,
    })
}

async fn wait_for_fatal(
    mut receiver: tokio::sync::watch::Receiver<Option<caly_application::runtime::FatalFault>>,
) {
    if receiver.borrow().is_some() {
        return;
    }
    while receiver.changed().await.is_ok() {
        if receiver.borrow_and_update().is_some() {
            return;
        }
    }
}

impl DaemonRuntime {
    pub(crate) fn serve(&self) -> Result<(), Box<dyn std::error::Error + Send + Sync>> {
        // Refuse to bind over a regular file, symlink, or another user's socket.
        caly_platform::uds::validate_uds_path(&self.socket).map_err(|reason| {
            std::io::Error::other(format!(
                "refusing to bind unsafe UDS path {}: {reason:?}",
                self.socket.display()
            ))
        })?;
        let adapter = ServiceAdapter::new(
            self.running.service_handle(),
            self.daemon_instance,
            self.daemon_instance,
            all_features(),
            DecodeLimits::v2_default(),
        );
        let socket = self.socket.clone();
        let fatal = self.running.fatal_receiver().map_err(|error| {
            std::io::Error::other(format!("runtime fatal subscription failed: {error:?}"))
        })?;
        // Serve the owner-only UDS plus the configured loopback TCP transport
        // concurrently. Both share one `JsonService` (and thus the daemon
        // session registry); a shared notify stops both on a runtime fatal.
        //
        // Round 17: the `stop_notifier` is the same `Notify`
        // as `fatal_shutdown` — both signal "the serve loop
        // must end, then `shutdown()` cleans up". A
        // successful `StopDaemon` operation triggers the
        // notifier (clean exit); a fatal fault does the
        // same. The transport's `shutdown` future is
        // `fatal_shutdown.notified()` (so a fatal or a
        // successful Stop both break the serve loop).
        let stop_notifier = std::sync::Arc::new(tokio::sync::Notify::new());
        let grpc = caly_server::json::JsonService::new(adapter, Some(stop_notifier.clone()))
            .map_err(|error| {
                std::io::Error::other(format!("session registry init failed: {error:?}"))
            })?;
        let notify_task = stop_notifier.clone();
        self.runtime.spawn(async move {
            wait_for_fatal(fatal).await;
            notify_task.notify_waiters();
        });
        self.runtime.block_on(async {
            let uds_grpc = grpc.clone();
            let uds_shutdown = stop_notifier.clone();
            let uds = async move {
                let shutdown = async move { uds_shutdown.notified().await };
                serve_owner_only_until(socket.clone(), uds_grpc, shutdown).await
            };
            if let Some(listen) = self.listen {
                let tcp_grpc = grpc.clone();
                let tcp_shutdown = stop_notifier.clone();
                let tcp = async move {
                    let shutdown = async move { tcp_shutdown.notified().await };
                    caly_server::tcp::serve_tcp_until(listen, tcp_grpc, shutdown).await
                };
                tokio::select! { result = uds => result, result = tcp => result }
            } else {
                uds.await
            }
        })
    }

    pub(crate) fn shutdown(self) -> Result<(), Box<dyn std::error::Error + Send + Sync>> {
        let first_fault = self.running.first_fault();
        let _ = self.running.stop_core();
        self.runtime
            .block_on(self.running.shutdown())
            .map_err(|error| {
                format!("daemon shutdown failed: {error:?}; first runtime fault: {first_fault:?}")
                    .into()
            })
    }
}

pub(crate) fn acquire_lock(lock_path: PathBuf) -> Result<Box<dyn InstanceLock>, String> {
    let process_start_id = current_process_start_id().map_err(|error| error.to_string())?;
    // A fresh random owner token per attempt keeps the lock file's owner
    // identity unpredictable even if the PID/start pair were ever replayed.
    let owner_token = caly_platform::entropy::random_bytes::<16>();
    LinuxInstanceLockBackend
        .acquire(
            lock_path,
            LockOwner {
                pid: std::process::id(),
                process_start_id,
                owner_token,
            },
        )
        // Render the structured failure as a human sentence; the raw Debug
        // form leaks internal types into user-facing diagnostics.
        .map_err(|error| {
            format!(
                "{} ({}); hint: {}",
                error.message, error.resource, error.suggested_action
            )
        })
}

pub(crate) fn bootstrap_ready(assembly: &mut crate::bootstrap::DaemonAssembly) -> bool {
    for phase in [
        crate::bootstrap::BootstrapPhase::AcquireInstanceLock,
        crate::bootstrap::BootstrapPhase::RestorePendingEffects,
        crate::bootstrap::BootstrapPhase::BuildOwnedRuntime,
        crate::bootstrap::BootstrapPhase::BindTransport,
    ] {
        if let Err(error) = assembly.bootstrap.complete(phase) {
            tracing::error!(phase = ?phase, "daemon bootstrap failed: {error:?}");
            return false;
        }
    }
    true
}

pub(crate) fn finish_daemon(
    result: Result<(), Box<dyn std::error::Error + Send + Sync>>,
    lock: Box<dyn InstanceLock>,
    socket: &std::path::Path,
) -> ExitCode {
    let socket_result = std::fs::remove_file(socket);
    // Best-effort cleanup of the owner-only controller-secret file so a stopped
    // daemon never leaves a stale secret for offline queries to read.
    let _ =
        std::fs::remove_file(caly_platform::paths::AppPaths::from_env().controller_secret_path());
    let release_result = lock.release();
    match (result, socket_result, release_result) {
        (Ok(()), _, Ok(())) => ExitCode::SUCCESS,
        (Err(error), _, _) => {
            tracing::error!("daemon transport failed: {error}");
            ExitCode::FAILURE
        }
        (Ok(()), _, Err(error)) => {
            tracing::error!("daemon lock release failed: {error:?}");
            ExitCode::FAILURE
        }
    }
}

#[cfg(test)]
mod runtime_tests {
    use super::*;

    #[tokio::test]
    async fn fatal_signal_completes_transport_shutdown_future() {
        let (sender, receiver) = tokio::sync::watch::channel(None);
        sender.send_replace(Some(caly_application::runtime::FatalFault::Projection));
        let completed = tokio::time::timeout(
            std::time::Duration::from_millis(50),
            wait_for_fatal(receiver),
        )
        .await;
        assert!(completed.is_ok());
    }
}
