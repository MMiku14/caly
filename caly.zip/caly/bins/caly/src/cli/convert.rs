//! clap grammar → public command-model conversions.
//!
//! Split out of `cli.rs` (audit #70 file-length budget): one
//! mechanical `From<Clap*> for <public enum>` impl per command
//! enum, plus the `kind:value` member-token parser used by the
//! proxy-group grammar. The public enums themselves live in the
//! parent `cli` module.

use super::grammar::{
    ClapCli, ClapCommand, ClapSetCmd, ClapSetConfigCmd, ClapSetCoreCmd, ClapSetDaemonCmd,
    ClapSetProfileCmd, ClapSetProviderCmd, ClapSetProxyCmd, ClapSetProxyGroupCmd,
    ClapSetRuleProviderCmd, ClapSetSubCmd, ClapShowCmd, ClapShowConfigCmd, ClapShowCoreCmd,
    ClapShowProfileCmd, ClapShowProxyCmd, ClapShowSubCmd, ClapToolCmd, Editor as ClapEditor,
};
use super::{
    CliOptions, Command, Invocation, ProxyGroupMemberSpec, SetCmd, SetConfigCmd, SetCoreCmd,
    SetDaemonCmd, SetProfileCmd, SetProviderCmd, SetProxyCmd, SetProxyGroupCmd, SetRuleProviderCmd,
    SetSubCmd, ShowCmd, ShowConfigCmd, ShowCoreCmd, ShowProfileCmd, ShowProxyCmd, ShowSubCmd,
    ToolCmd,
};
use super::{Editor, RuleProviderSourceSpec};

impl From<ClapCli> for Invocation {
    fn from(cli: ClapCli) -> Self {
        let options = CliOptions {
            socket: cli.global.socket,
            json: cli.global.json,
            core: cli.global.core.map(|v| v.as_str().to_owned()),
            mihomo_bin: cli.global.mihomo_bin,
            sing_box_bin: cli.global.sing_box_bin,
        };
        let command = match cli.command {
            ClapCommand::Daemon => Command::Daemon,
            ClapCommand::Tool { command } => Command::Tool(command.into()),
            ClapCommand::Show { command } => Command::Show(command.into()),
            ClapCommand::Set { command } => Command::Set(command.into()),
            ClapCommand::Completions { shell } => Command::Completions(shell),
        };
        Self { command, options }
    }
}

// ── From impls: clap grammar → public enums ──

impl From<ClapToolCmd> for ToolCmd {
    fn from(c: ClapToolCmd) -> Self {
        match c {
            ClapToolCmd::Help { command } => Self::Help(command),
            ClapToolCmd::Version => Self::Version,
            ClapToolCmd::Doctor { fix } => Self::Doctor { fix },
            ClapToolCmd::Tui { readonly } => Self::Tui { readonly },
            ClapToolCmd::Dns { domain } => Self::Dns(domain),
        }
    }
}

impl From<ClapShowCmd> for ShowCmd {
    fn from(c: ClapShowCmd) -> Self {
        match c {
            ClapShowCmd::Status => Self::Status,
            ClapShowCmd::Core { command } => Self::Core(command.into()),
            ClapShowCmd::Sub { command } => Self::Sub(command.into()),
            ClapShowCmd::Profile { command } => Self::Profile(command.into()),
            ClapShowCmd::Proxy { command } => Self::Proxy(command.into()),
            ClapShowCmd::Config { command } => Self::Config(command.into()),
        }
    }
}

impl From<ClapShowCoreCmd> for ShowCoreCmd {
    fn from(c: ClapShowCoreCmd) -> Self {
        match c {
            ClapShowCoreCmd::Nodes => Self::Nodes,
            ClapShowCoreCmd::Groups => Self::Groups,
            ClapShowCoreCmd::Connections => Self::Connections,
            ClapShowCoreCmd::Traffic => Self::Traffic,
            ClapShowCoreCmd::Mode => Self::Mode,
            ClapShowCoreCmd::Rules { r#match } => Self::Rules { r#match },
            ClapShowCoreCmd::Health => Self::Health,
        }
    }
}

impl From<ClapShowSubCmd> for ShowSubCmd {
    fn from(c: ClapShowSubCmd) -> Self {
        match c {
            ClapShowSubCmd::Providers => Self::Providers,
            ClapShowSubCmd::Parse { path, userinfo } => Self::Parse { path, userinfo },
            ClapShowSubCmd::Import { path, clipboard } => Self::Import { path, clipboard },
        }
    }
}

impl From<ClapShowProfileCmd> for ShowProfileCmd {
    fn from(c: ClapShowProfileCmd) -> Self {
        match c {
            ClapShowProfileCmd::List => Self::List,
            ClapShowProfileCmd::Show { id } => Self::Show { id },
        }
    }
}

impl From<ClapShowProxyCmd> for ShowProxyCmd {
    fn from(c: ClapShowProxyCmd) -> Self {
        match c {
            ClapShowProxyCmd::List => Self::List,
            ClapShowProxyCmd::Show { id } => Self::Show { id },
            ClapShowProxyCmd::Groups => Self::Groups,
        }
    }
}

impl From<ClapShowConfigCmd> for ShowConfigCmd {
    fn from(c: ClapShowConfigCmd) -> Self {
        match c {
            ClapShowConfigCmd::Path => Self::Path,
            ClapShowConfigCmd::Files => Self::Files,
            ClapShowConfigCmd::Validate { file } => Self::Validate { file },
        }
    }
}

impl From<ClapSetCmd> for SetCmd {
    fn from(c: ClapSetCmd) -> Self {
        match c {
            ClapSetCmd::Core { command } => Self::Core(command.into()),
            ClapSetCmd::Proxy { command } => Self::Proxy(command.into()),
            ClapSetCmd::Tun { state } => Self::Tun(state.enabled()),
            ClapSetCmd::Sub { command } => Self::Sub(command.into()),
            ClapSetCmd::Profile { command } => Self::Profile(command.into()),
            ClapSetCmd::Config { command } => Self::Config(command.into()),
            ClapSetCmd::Daemon { command } => Self::Daemon(command.into()),
            ClapSetCmd::RuleProvider { command } => Self::RuleProvider(command.into()),
            ClapSetCmd::ProxyGroup { command } => Self::ProxyGroup(command.into()),
            ClapSetCmd::Provider { command } => Self::Provider(command.into()),
        }
    }
}

impl From<ClapSetCoreCmd> for SetCoreCmd {
    fn from(c: ClapSetCoreCmd) -> Self {
        match c {
            ClapSetCoreCmd::Start => Self::Start,
            ClapSetCoreCmd::Stop => Self::Stop,
            ClapSetCoreCmd::Restart => Self::Restart,
            ClapSetCoreCmd::Switch { core } => Self::Switch(core.as_str().to_owned()),
            ClapSetCoreCmd::Select { node, delay } => Self::Select { node, delay },
            ClapSetCoreCmd::Mode { mode } => Self::Mode(mode.as_str().to_owned()),
            ClapSetCoreCmd::CloseConnections => Self::CloseConnections,
            ClapSetCoreCmd::Delay {
                name,
                all,
                url,
                samples,
            } => Self::Delay {
                name,
                all,
                url,
                samples,
            },
            ClapSetCoreCmd::UrlTest { name, url, samples } => Self::UrlTest { name, url, samples },
        }
    }
}

impl From<ClapSetProxyCmd> for SetProxyCmd {
    fn from(c: ClapSetProxyCmd) -> Self {
        match c {
            ClapSetProxyCmd::Add {
                uri,
                group,
                apply,
                dry_run,
            } => Self::Add {
                uri,
                group,
                apply,
                dry_run,
            },
            ClapSetProxyCmd::Edit { id, apply, dry_run } => Self::Edit { id, apply, dry_run },
            ClapSetProxyCmd::Remove { id, apply, dry_run } => Self::Remove { id, apply, dry_run },
            ClapSetProxyCmd::Import {
                path,
                apply,
                dry_run,
            } => Self::Import {
                path,
                apply,
                dry_run,
            },
            ClapSetProxyCmd::On => Self::On,
            ClapSetProxyCmd::Off => Self::Off,
        }
    }
}

impl From<ClapSetSubCmd> for SetSubCmd {
    fn from(c: ClapSetSubCmd) -> Self {
        match c {
            ClapSetSubCmd::Refresh => Self::Refresh,
            ClapSetSubCmd::Add {
                url,
                name,
                apply,
                dry_run,
            } => Self::Add {
                url,
                name,
                apply,
                dry_run,
            },
            ClapSetSubCmd::Remove {
                url,
                apply,
                dry_run,
            } => Self::Remove {
                url,
                apply,
                dry_run,
            },
            ClapSetSubCmd::Enable {
                url,
                apply,
                dry_run,
            } => Self::Enable {
                url,
                apply,
                dry_run,
            },
            ClapSetSubCmd::Disable {
                url,
                apply,
                dry_run,
            } => Self::Disable {
                url,
                apply,
                dry_run,
            },
            ClapSetSubCmd::Import {
                path,
                clipboard,
                apply,
                dry_run,
            } => Self::Import {
                path,
                clipboard,
                apply,
                dry_run,
            },
        }
    }
}

impl From<ClapSetProfileCmd> for SetProfileCmd {
    fn from(c: ClapSetProfileCmd) -> Self {
        match c {
            ClapSetProfileCmd::Add {
                id,
                source,
                apply,
                dry_run,
            } => Self::Add {
                id,
                source,
                apply,
                dry_run,
            },
            ClapSetProfileCmd::Remove { id, apply, dry_run } => Self::Remove { id, apply, dry_run },
            ClapSetProfileCmd::Edit { id, apply, dry_run } => Self::Edit { id, apply, dry_run },
            ClapSetProfileCmd::Refresh { id } => Self::Refresh { id },
            ClapSetProfileCmd::Export { id, out } => Self::Export { id, out },
            ClapSetProfileCmd::Enable { id, apply, dry_run } => Self::Enable { id, apply, dry_run },
            ClapSetProfileCmd::Disable { id, apply, dry_run } => {
                Self::Disable { id, apply, dry_run }
            }
        }
    }
}

impl From<ClapSetConfigCmd> for SetConfigCmd {
    fn from(c: ClapSetConfigCmd) -> Self {
        match c {
            ClapSetConfigCmd::Apply => Self::Apply,
            ClapSetConfigCmd::Generate => Self::Generate,
            ClapSetConfigCmd::Default => Self::Default,
            ClapSetConfigCmd::Diff { file } => Self::Diff { file },
            ClapSetConfigCmd::Edit { editor } => Self::Edit(match editor {
                ClapEditor::Vim => Editor::Vim,
                ClapEditor::Nvim => Editor::Nvim,
            }),
        }
    }
}

impl From<ClapSetDaemonCmd> for SetDaemonCmd {
    fn from(c: ClapSetDaemonCmd) -> Self {
        match c {
            ClapSetDaemonCmd::Stop => Self::Stop,
            ClapSetDaemonCmd::Reload => Self::Reload,
            ClapSetDaemonCmd::Restart => Self::Restart,
            ClapSetDaemonCmd::Status => Self::Status,
        }
    }
}

impl From<ClapSetRuleProviderCmd> for SetRuleProviderCmd {
    fn from(c: ClapSetRuleProviderCmd) -> Self {
        match c {
            ClapSetRuleProviderCmd::AddHttp {
                name,
                url,
                interval_ms,
                apply,
                dry_run,
            } => Self::Add {
                name,
                source: RuleProviderSourceSpec::Http { url, interval_ms },
                apply,
                dry_run,
            },
            ClapSetRuleProviderCmd::AddFile {
                name,
                path,
                apply,
                dry_run,
            } => Self::Add {
                name,
                source: RuleProviderSourceSpec::File { path },
                apply,
                dry_run,
            },
            ClapSetRuleProviderCmd::AddInline {
                name,
                payload,
                apply,
                dry_run,
            } => Self::Add {
                name,
                source: RuleProviderSourceSpec::Inline { payload },
                apply,
                dry_run,
            },
            ClapSetRuleProviderCmd::Remove {
                name,
                apply,
                dry_run,
            } => Self::Remove {
                name,
                apply,
                dry_run,
            },
            ClapSetRuleProviderCmd::Enable {
                name,
                apply,
                dry_run,
            } => Self::Enable {
                name,
                apply,
                dry_run,
            },
            ClapSetRuleProviderCmd::Disable {
                name,
                apply,
                dry_run,
            } => Self::Disable {
                name,
                apply,
                dry_run,
            },
            ClapSetRuleProviderCmd::Refresh { name } => Self::Refresh { name },
            ClapSetRuleProviderCmd::List => Self::List,
        }
    }
}

impl From<ClapSetProviderCmd> for SetProviderCmd {
    fn from(c: ClapSetProviderCmd) -> Self {
        match c {
            ClapSetProviderCmd::AddSources {
                name,
                apply,
                dry_run,
            } => Self::AddSources {
                name,
                apply,
                dry_run,
            },
            ClapSetProviderCmd::AddNodes {
                name,
                nodes,
                apply,
                dry_run,
            } => Self::AddNodes {
                name,
                nodes,
                apply,
                dry_run,
            },
            ClapSetProviderCmd::Remove {
                name,
                apply,
                dry_run,
            } => Self::Remove {
                name,
                apply,
                dry_run,
            },
        }
    }
}

impl From<ClapSetProxyGroupCmd> for SetProxyGroupCmd {
    fn from(c: ClapSetProxyGroupCmd) -> Self {
        match c {
            ClapSetProxyGroupCmd::Add {
                name,
                r#type,
                members,
                url,
                interval_seconds,
                tolerance_ms,
                apply,
                dry_run,
            } => {
                // Parse the `kind:value` member specs. The
                // grammar's `value_delimiter = ','` splits
                // the operator's `--members a,b,c` into a
                // `Vec<String>`, but does not validate each
                // token. The `parse_member_spec` helper
                // rejects an unrecognised `kind:` (e.g.
                // `ndoe:hk-1` for a typo of `node:`) or
                // bare token.
                //
                // Round 24 (debug): the pre-Round 24
                // behaviour was
                // `.unwrap_or_default()`, which silently
                // turned a parse error into an empty
                // `members:` list. The schema then
                // rejected the entry as "select group with
                // zero members" — a misleading error
                // pointing at the wrong field.
                //
                // Round 24 also added a clap `value_parser`
                // (`parse_member_token`) that rejects
                // unknown `kind:` prefixes and unknown
                // bare tokens at parse time. The dispatch
                // re-runs the same parse logic as
                // defense-in-depth; a parse failure here
                // is unreachable in practice because clap
                // already rejected bad tokens. The
                // `expect`-shaped fall-through would be a
                // `panic!`, but the workspace forbids
                // `clippy::expect_used` and `clippy::panic`.
                // Carry the parse result through to the
                // dispatch: a failure here means clap's
                // `value_parser` and `parse_member_spec`
                // drifted apart, and the operator must see
                // a real error, not an empty-member group
                // written behind their back (#55).
                let parsed_members = members
                    .into_iter()
                    .map(parse_member_spec)
                    .collect::<Result<Vec<_>, String>>()
                    .map_err(|error| {
                        format!(
                            "proxy-group member parse failed after clap accepted \
                         the token: {error} (clap's value_parser should have \
                         rejected it at parse time; please report this bug)"
                        )
                    });
                Self::Add {
                    name,
                    group_type: r#type.to_public(),
                    members: parsed_members,
                    url,
                    interval_seconds,
                    tolerance_ms,
                    apply,
                    dry_run,
                }
            }
            ClapSetProxyGroupCmd::Remove {
                name,
                apply,
                dry_run,
            } => Self::Remove {
                name,
                apply,
                dry_run,
            },
            ClapSetProxyGroupCmd::Enable {
                name,
                apply,
                dry_run,
            } => Self::Enable {
                name,
                apply,
                dry_run,
            },
            ClapSetProxyGroupCmd::Disable {
                name,
                apply,
                dry_run,
            } => Self::Disable {
                name,
                apply,
                dry_run,
            },
            ClapSetProxyGroupCmd::List { enabled_only } => Self::List { enabled_only },
        }
    }
}

/// Parses one `kind:value` member token into a
/// [`ProxyGroupMemberSpec`]. The grammar shape is
/// `node:<tag>`, `group:<name>`, `direct`, `reject`. An
/// unrecognised `kind:` is silently dropped at the
/// grammar level; the schema validator is the strict
/// path so a typo is caught before the kernel starts.
fn parse_member_spec(token: String) -> Result<ProxyGroupMemberSpec, String> {
    let token = token.trim();
    if token.is_empty() {
        return Err("empty member spec".to_owned());
    }
    if let Some((kind, value)) = token.split_once(':') {
        match kind {
            "node" => Ok(ProxyGroupMemberSpec::Node {
                tag: value.to_owned(),
            }),
            "group" => Ok(ProxyGroupMemberSpec::Group {
                name: value.to_owned(),
            }),
            other => Err(format!(
                "unknown member kind `{other}` (use `node:<tag>`, `group:<name>`, `direct`, or `reject`)"
            )),
        }
    } else {
        match token {
            "direct" => Ok(ProxyGroupMemberSpec::Direct),
            "reject" => Ok(ProxyGroupMemberSpec::Reject),
            other => Err(format!(
                "unknown member `{other}` (use `node:<tag>`, `group:<name>`, `direct`, or `reject`)"
            )),
        }
    }
}
