//! Clap derive grammar for the `set proxy-group …` leaves.
//!
//! Split out of `cli/grammar.rs` (audit #70 file-length budget):
//! Round 20 declarative CRUD for `proxy_groups:`; member tokens
//! are validated at parse time ([`parse_member_token`]) so a typo
//! surfaces as a clap error instead of a silent empty `members:`
//! list.

use clap::Subcommand;

use super::{ProxyGroupKind, parse_member_token};

/// Round 20: clap grammar for `set proxy-group …`. The
/// five leaves mirror the `set rule-provider` family but
/// the `add` shape is one variant (not one per source
/// kind): a `proxy_groups:` entry has the same shape
/// regardless of the `type:` kind, only the
/// `url:` / `interval-seconds` / `tolerance-ms` flags
/// differ.
#[derive(Subcommand, Debug)]
#[command(disable_help_subcommand = true)]
pub(in crate::cli) enum ClapSetProxyGroupCmd {
    /// Add a new `proxy_group`. The `type:` field is one
    /// of `select` / `url-test` / `fallback` / `load-balance`
    /// / `relay`. Probe-driven groups (`url-test` /
    /// `fallback` / `load-balance`) require `--url`.
    Add {
        name: String,
        #[arg(long, value_enum, value_name = "KIND")]
        r#type: ProxyGroupKind,
        /// Comma-separated list of `kind:…` member specs,
        /// e.g. `node:hk-1,group:Auto,direct,reject`. The
        /// order matches the rendered Mihomo `proxies:`
        /// list; the schema validator preserves it.
        ///
        /// Round 24 (debug): the `value_parser` rejects
        /// unknown `kind:` prefixes (`node` / `group`) and
        /// unknown bare tokens (`direct` / `reject`) at
        /// parse time, so a typo (`ndoe:hk-1` or
        /// `rejct`) surfaces a clap error instead of the
        /// pre-Round-24 silent drop that produced an
        /// empty `members:` list and a misleading
        /// "select group with zero members" schema
        /// rejection.
        #[arg(
            long,
            value_name = "MEMBERS",
            value_delimiter = ',',
            value_parser = parse_member_token,
        )]
        members: Vec<String>,
        /// Probe URL; required for `url-test` / `fallback` /
        /// `load-balance`.
        #[arg(long, value_name = "URL")]
        url: Option<String>,
        /// Probe cadence in seconds (default 300).
        #[arg(long, value_name = "SECONDS")]
        interval_seconds: Option<u32>,
        /// Probe tolerance in milliseconds (default 50).
        #[arg(long, value_name = "MS")]
        tolerance_ms: Option<u32>,
        #[arg(long, conflicts_with = "dry_run")]
        apply: bool,
        #[arg(long, conflicts_with = "apply")]
        dry_run: bool,
    },
    /// Remove a group from `proxy_groups:`.
    Remove {
        name: String,
        #[arg(long, conflicts_with = "dry_run")]
        apply: bool,
        #[arg(long, conflicts_with = "apply")]
        dry_run: bool,
    },
    /// Enable a disabled group.
    Enable {
        name: String,
        #[arg(long, conflicts_with = "dry_run")]
        apply: bool,
        #[arg(long, conflicts_with = "apply")]
        dry_run: bool,
    },
    /// Disable a group (the daemon boot skips it).
    Disable {
        name: String,
        #[arg(long, conflicts_with = "dry_run")]
        apply: bool,
        #[arg(long, conflicts_with = "apply")]
        dry_run: bool,
    },
    /// List declared groups (and their type and member count).
    ///
    /// `--enabled-only` restricts the list to groups whose
    /// `enabled:` flag is `true`; the default is to
    /// list every declared group. The flag is
    /// dispatch-side (it does not need a server
    /// round-trip — the layered config already
    /// carries the full `proxy_groups:` list) and
    /// filters the in-memory projection in
    /// `commands::proxy_group::list`. A future
    /// `--type <kind>` flag can sit next to it for
    /// type-filtered list (`--type url-test`,
    /// `--type select`); the dispatcher's list path
    /// already knows the kind.
    List {
        #[arg(long, default_value_t = false)]
        enabled_only: bool,
    },
}
