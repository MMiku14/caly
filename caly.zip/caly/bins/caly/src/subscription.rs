//! Offline subscription parsing diagnostics (`caly sub check`).
//!
//! Reads a subscription file (Clash YAML, direct URI lines, or Base64 URI
//! aggregate), detects its format, and reports the parsed node count and any
//! rejected lines. This is a pure, offline preview of what the daemon's
//! subscription pipeline would ingest.

use std::path::Path;

use caly_config::subscription::{
    SubscriptionFormat, decode_document, parse_uri_body_to_display_lossy,
};
use caly_domain::SubscriptionId;

/// Outcome of parsing a subscription file.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct SubscriptionSummary {
    pub format: String,
    pub node_count: usize,
    pub rejected_lines: usize,
    /// Recognized `ssr://` nodes skipped (SSR is not representable).
    pub ssr_skipped: usize,
    pub names: Vec<String>,
    /// Optional Clash subscription quota metadata (upload/download/total/expire).
    pub userinfo: caly_config::subscription::SubscriptionUserInfo,
}

/// Reads and parses `path`, returning a human-readable summary. An optional
/// `subscription-userinfo` header value supplies quota metadata.
pub fn inspect_subscription_with_userinfo(
    path: &Path,
    userinfo_header: Option<&str>,
) -> Result<SubscriptionSummary, String> {
    let body =
        std::fs::read(path).map_err(|error| format!("cannot read {}: {error}", path.display()))?;
    inspect_subscription(body, userinfo_header)
}

/// Reads proxy URIs from the system clipboard and parses them as a synthetic
/// document. Tries Wayland (`wl-paste`) first, then X11 (`xclip`, `xsel`).
/// Returns an error that also suggests `caly sub check <file>` as a fallback.
/// Reads proxy URIs from the system clipboard and parses them as a synthetic
/// document. Tries Wayland (`wl-paste`) first, then X11 (`xclip`, `xsel`).
/// Returns an error that also suggests `caly sub check <file>` as a fallback.
pub fn read_clipboard() -> Result<SubscriptionSummary, String> {
    const TOOLS: [(&str, &[&str]); 3] = [
        ("wl-paste", &[]),
        ("xclip", &["-selection", "clipboard", "-o"]),
        ("xsel", &["--clipboard", "--output"]),
    ];
    read_clipboard_with(&TOOLS)
}

/// Core implementation of `read_clipboard` over an injectable candidate list,
/// so the fallback-error path is unit-testable without mutating `PATH`.
fn read_clipboard_with(tools: &[(&str, &[&str])]) -> Result<SubscriptionSummary, String> {
    use std::process::{Command, Stdio};
    let mut errors = Vec::new();
    for &(tool, args) in tools {
        let output = Command::new(tool)
            .args(args)
            .stdout(Stdio::piped())
            .stderr(Stdio::null())
            .output();
        match output {
            Ok(output) if output.status.success() => {
                return inspect_subscription(output.stdout, None);
            }
            Ok(_) => errors.push(tool.to_owned()),
            Err(_) => errors.push(format!("{tool}: not found")),
        }
    }
    Err(format!(
        "no clipboard tool available (tried {}); paste the URIs into a file and run `caly sub check <file>`",
        errors.join(", ")
    ))
}

/// Parses an in-memory subscription body (from a file or clipboard) into a
/// summary, sharing the offline pipeline with `caly sub check`.
pub fn inspect_subscription(
    body: Vec<u8>,
    userinfo_header: Option<&str>,
) -> Result<SubscriptionSummary, String> {
    let userinfo = userinfo_header.map_or_else(
        || caly_config::subscription::SubscriptionUserInfo {
            upload_bytes: None,
            download_bytes: None,
            total_bytes: None,
            expire_unix: None,
        },
        caly_config::subscription::parse_subscription_userinfo,
    );
    // URL-list documents carry no nodes offline; the daemon fetches and merges
    // the children during refresh. Report the entries instead of parsing.
    if let Ok(caly_config::subscription::SubscriptionDocument::UrlList(lines)) =
        decode_document(body.clone())
    {
        return Ok(SubscriptionSummary {
            format: "url-list".to_owned(),
            node_count: 0,
            rejected_lines: 0,
            ssr_skipped: 0,
            names: lines.iter().map(|line| line.as_str().to_owned()).collect(),
            userinfo,
        });
    }
    let format = detect_format(&body).unwrap_or_else(|| "unknown".to_owned());
    // A stable, all-zero subscription id for an offline preview.
    let subscription = SubscriptionId::from_bytes([0; 16]);
    let projection = match parse_uri_body_to_display_lossy(body, subscription) {
        Ok(projection) => projection,
        Err(caly_config::subscription::PipelineError::SsrOnly(count)) => {
            return Ok(SubscriptionSummary {
                format: "ssr-only".to_owned(),
                node_count: 0,
                rejected_lines: 0,
                ssr_skipped: count,
                names: Vec::new(),
                userinfo,
            });
        }
        Err(error) => return Err(format!("subscription parse failed: {error:?}")),
    };
    let names = projection
        .nodes
        .iter()
        .map(|node| node.name().as_str().to_owned())
        .collect();
    Ok(SubscriptionSummary {
        format,
        node_count: projection.nodes.len(),
        rejected_lines: projection.rejected_lines,
        ssr_skipped: projection.ssr_skipped,
        names,
        userinfo,
    })
}

/// Detects the top-level subscription format without failing on parse details.
fn detect_format(body: &[u8]) -> Option<String> {
    use caly_config::subscription::SubscriptionDocument;
    match decode_document(body.to_vec()) {
        Ok(SubscriptionDocument::ClashYaml(_)) => Some("clash-yaml".to_owned()),
        Ok(SubscriptionDocument::UrlList(_)) => Some("url-list".to_owned()),
        Ok(SubscriptionDocument::Sip008(_)) => Some("sip008".to_owned()),
        Ok(SubscriptionDocument::UriLines { source_format, .. }) => Some(match source_format {
            SubscriptionFormat::UriLines => "uri-lines".to_owned(),
            SubscriptionFormat::Base64UriLines => "base64-uri-lines".to_owned(),
            SubscriptionFormat::ClashYaml => "clash-yaml".to_owned(),
        }),
        Err(_) => None,
    }
}

/// Renders a summary as human-readable text.
pub fn render_human(summary: &SubscriptionSummary) -> String {
    let mut out = format!(
        "format:      {}\nnodes:       {}\nrejected:    {}\n",
        summary.format, summary.node_count, summary.rejected_lines
    );
    if summary.format == "ssr-only" {
        let _ = std::fmt::Write::write_fmt(
            &mut out,
            format_args!(
                "note:        all {} nodes are SSR, which caly cannot represent;\n             convert the subscription to a supported format\n",
                summary.ssr_skipped
            ),
        );
    } else if summary.ssr_skipped > 0 {
        let _ = std::fmt::Write::write_fmt(
            &mut out,
            format_args!(
                "ssr-skipped: {} (SSR nodes are recognized but not representable)\n",
                summary.ssr_skipped
            ),
        );
    }
    if summary.format == "url-list" {
        let _ = std::fmt::Write::write_fmt(
            &mut out,
            format_args!(
                "entries:     {} (child subscriptions; the daemon fetches and merges them on refresh)\n",
                summary.names.len()
            ),
        );
    }
    let usage = caly_config::subscription::render_usage_human(&summary.userinfo);
    if !usage.is_empty() {
        out.push_str(&usage);
        out.push('\n');
    }
    for (index, name) in summary.names.iter().enumerate() {
        let _ = std::fmt::Write::write_fmt(&mut out, format_args!("  {index}: {name}\n"));
    }
    out
}

/// Renders a summary as one-line JSON.
pub fn render_json(summary: &SubscriptionSummary) -> String {
    let mut value = serde_json::json!({
        "format": summary.format,
        "nodes": summary.node_count,
        "rejected": summary.rejected_lines,
        "ssr_skipped": summary.ssr_skipped,
        "names": summary.names,
    });
    if let Some(total) = summary.userinfo.total_bytes {
        let used = summary
            .userinfo
            .upload_bytes
            .unwrap_or(0)
            .saturating_add(summary.userinfo.download_bytes.unwrap_or(0));
        let remaining = total.saturating_sub(used);
        value["quota_total"] = serde_json::json!(total);
        value["quota_used"] = serde_json::json!(used);
        value["quota_remaining"] = serde_json::json!(remaining);
    }
    value.to_string()
}

/// Returns whether the subscription parsed with any nodes and no hard failure.
/// Returns whether the subscription parsed into something the refresh path can
/// use: dialable nodes, or a URL list the daemon expands at fetch time.
pub fn is_usable(summary: &SubscriptionSummary) -> bool {
    summary.node_count > 0 || summary.format == "url-list"
}

#[cfg(test)]
mod tests {
    use super::*;

    fn unique_file(label: &str) -> std::path::PathBuf {
        std::env::temp_dir().join(format!("caly-sub-{label}-{}", std::process::id()))
    }

    fn write_then_inspect(label: &str, body: &str) -> Result<SubscriptionSummary, String> {
        let path = unique_file(label);
        std::fs::write(&path, body).map_err(|e| e.to_string())?;
        let summary = inspect_subscription_with_userinfo(&path, None);
        let _ = std::fs::remove_file(&path);
        summary
    }

    /// Builds a valid shadowsocks URI from a method:password pair.
    fn ss_uri(method: &str, password: &str, host: &str, port: u16, name: &str) -> String {
        use base64::{Engine as _, engine::general_purpose};
        let credentials = general_purpose::STANDARD.encode(format!("{method}:{password}"));
        format!("ss://{credentials}@{host}:{port}#{name}")
    }

    #[test]
    fn parses_direct_uri_lines() -> Result<(), String> {
        let a = ss_uri("aes-256-gcm", "pw1", "example.com", 8388, "node-a");
        let b = ss_uri("aes-128-gcm", "pw2", "example.org", 443, "node-b");
        let summary = write_then_inspect("direct", &format!("{a}\n{b}"))?;
        assert_eq!(summary.format, "uri-lines");
        assert!(summary.node_count >= 2);
        assert!(is_usable(&summary));
        assert!(summary.names.iter().any(|n| n == "node-a"));
        Ok(())
    }

    #[test]
    fn detects_base64_aggregate() -> Result<(), String> {
        use base64::{Engine as _, engine::general_purpose};
        let a = ss_uri("aes-256-gcm", "pw1", "example.com", 8388, "a");
        let b = ss_uri("aes-128-gcm", "pw2", "example.org", 443, "b");
        let encoded = general_purpose::STANDARD.encode(format!("{a}\n{b}"));
        let summary = write_then_inspect("b64", &encoded)?;
        assert_eq!(summary.format, "base64-uri-lines");
        assert!(summary.node_count >= 2);
        Ok(())
    }

    #[test]
    fn render_human_and_json_are_well_formed() -> Result<(), String> {
        let uri = ss_uri("aes-256-gcm", "pw1", "example.com", 8388, "node-x");
        let summary = write_then_inspect("render", &uri)?;
        let human = render_human(&summary);
        assert!(human.contains("format:"));
        assert!(human.contains("node-x"));
        let json = render_json(&summary);
        assert!(json.starts_with('{') && json.contains("\"nodes\""));
        Ok(())
    }

    #[test]
    fn unusable_when_no_nodes() {
        let summary = write_then_inspect("garbage", "this is not a subscription");
        // Either it parses to zero nodes or errors; both are fine, but if it
        // parses it must be unusable.
        if let Ok(summary) = summary {
            assert!(!is_usable(&summary));
        }
    }

    #[test]
    fn imports_mixed_protocol_uri_list_in_memory() -> Result<(), String> {
        // Mirrors `caly sub import`: an in-memory body with the protocols a
        // clipboard paste typically carries (vless/vmess/ss/hysteria2/trojan).
        let vless = "vless://b6f3b292-00c9-430e-bc4c-b1294bd895c0@185.126.67.76:443?security=reality&type=tcp&packetEncoding=none&sni=cdn-de-4.ai-apiroute.cc&fp=firefox&flow=xtls-rprx-vision&sid=b512d49930874a31&pbk=abc#DE_1";
        let vmess_line = "vmess://eyJhZGQiOiIxODUuMTI2LjY3Ljc2IiwicG9ydCI6NDQzLCJpZCI6ImI2ZjNiMjkyLTAwYzktNDMwZS1iYzRjLWIxMjk0YmQ4OTVjMCIsImFpZCI6MCwibmV0IjoidGNwIiwidGxzIjoiIiwicHMiOiJVUzEifQ==";
        let hy2 = "hysteria2://H7mP2xY9kJ4nQ8wR5tF6vB3z@vpn-tw-002.fastervpn.world:443?insecure=1&sni=vpn-tw-002.fastervpn.world#TW_1";
        let ss = ss_uri("aes-256-gcm", "pw1", "example.com", 8388, "node-a");
        let trojan = "trojan://ND91608427@nearby-egret.rooster465.autos:443?sni=nearby-egret.rooster465.autos&type=tcp#JP_2";
        let bad = "ssr://ssrnotrepresentable";
        let body = format!("{vless}\n{vmess_line}\n{hy2}\n{ss}\n{trojan}\n{bad}\nnot-a-uri");
        let summary = inspect_subscription(body.into_bytes(), None)?;
        assert_eq!(summary.format, "uri-lines");
        assert!(summary.node_count >= 5, "nodes={}", summary.node_count);
        assert_eq!(summary.rejected_lines, 1, "the bare text line rejects");
        assert_eq!(summary.ssr_skipped, 1);
        assert!(summary.names.contains(&"DE_1".to_owned()));
        assert!(summary.names.contains(&"TW_1".to_owned()));
        assert!(summary.names.contains(&"JP_2".to_owned()));
        Ok(())
    }

    #[test]
    fn import_rejects_clipboard_without_tool_gracefully() {
        // `read_clipboard` degrades to a helpful error when no paste tool is
        // resolvable; it must never panic.
        let error = read_clipboard_with(&[("definitely-not-a-real-tool", &[])])
            .err()
            .unwrap_or_else(|| "clipboard read unexpectedly succeeded".to_owned());
        assert!(
            error.contains("no clipboard tool available"),
            "unexpected error: {error}"
        );
    }
}
