//! Centralised CLI output, error reporting, and JSON contract.
//!
//! Every command in caly produces output through one of two
//! helpers — [`CliOutput::success`] / [`CliOutput::info`]
//! in human or JSON mode — based on the `--json` flag. Every
//! error flows through [`report_error`] (or its exit-code-returning
//! wrapper [`report_error_returning`]) so the JSON shape is
//! stable across the surface.
//!
//! # JSON contract
//!
//! Every JSON line the CLI emits starts with a `version`
//! field so consumers can detect contract changes. Success
//! lines have `ok: true`; error lines have `ok: false` and
//! carry `code`, `error`, `hint`, and the `command` the
//! user ran. A pipeline of `caly --json ... | jq` can rely
//! on this shape being stable across all subcommands.
//!
//! # Human contract
//!
//! Successful mutations print `ok: SEMANTIC_SUMMARY`
//! (`ok: profile \`team\` added`); failures print
//! `error: MSG` followed by `hint: REMEDIATION` on
//! the next line. Errors always go to stderr so stdout
//! carries only successful data.

use std::process::ExitCode;

use serde_json::Value;

/// `1` is the first stable JSON contract version. Bump only
/// when the shape of an existing line changes; additive
/// fields (new optional keys) do not bump the version.
pub const JSON_CONTRACT_VERSION: u32 = 1;

/// Outputs through either the human or JSON channel. The
/// output is bound to the `--json` flag at parse time so
/// every command in `main.rs` uses the same dispatch.
#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub enum CliOutput {
    Human,
    Json,
}

impl CliOutput {
    /// Constructs a `CliOutput` from the `--json` flag value.
    pub const fn from_json_flag(json: bool) -> Self {
        if json { Self::Json } else { Self::Human }
    }

    /// Returns `true` when JSON output is requested.
    pub const fn is_json(self) -> bool {
        matches!(self, Self::Json)
    }

    /// Prints a successful result. The `summary` is the
    /// semantic message shown to the operator (e.g.
    /// `"profile \`team\` added"`); the `payload` is the
    /// additional JSON fields to merge into the success
    /// envelope (ignored in human mode).
    pub fn success(self, summary: &str, payload: Value) {
        match self {
            Self::Human => println!("ok: {summary}"),
            Self::Json => {
                let mut value = serde_json::json!({
                    "ok": true,
                    "version": JSON_CONTRACT_VERSION,
                });
                if let Value::Object(map) = payload {
                    if let Value::Object(self_map) = &mut value {
                        for (k, v) in map {
                            self_map.insert(k, v);
                        }
                    }
                }
                println!("{value}");
            }
        }
    }

    /// Prints a successful result with no extra payload. Use
    /// this when the JSON envelope is just `{ok, version}`.
    pub fn success_empty(self, summary: &str) {
        self.success(summary, Value::Null);
    }

    /// Round 12: prints a "grammar-locked, wire-deferred" success.
    /// Used by `set` leaves whose CLI shape is locked but whose
    /// real writer is not yet wired. The JSON envelope is identical
    /// to a normal success but the `summary` ends with `: planned.`
    /// so a downstream tool can branch on it without parsing the
    /// human message.
    ///
    /// Replaces the 19-site `eprintln!(... Round 12 ...)` +
    /// `output.success_empty("...: planned.")` + `let _ = output;`
    /// pattern in `commands::set`. After this call, the caller can
    /// simply `return ExitCode::SUCCESS` (or use `planned_ok` to
    /// get the exit code directly).
    pub fn planned(self, action: &str) {
        self.success_empty(&format!("{action}: planned."));
    }

    /// Round 12: same as `planned` but returns the appropriate
    /// `ExitCode` so a stub leaf body is a one-liner:
    ///
    /// ```ignore
    /// output.planned_ok("set proxy add")
    /// ```
    pub fn planned_ok(self, action: &str) -> ExitCode {
        self.planned(action);
        ExitCode::SUCCESS
    }

    /// Prints an informational message. Goes to stdout in
    /// both modes (the human reads it; a JSON consumer can
    /// ignore the line because it is not a JSON object).
    pub fn info(self, message: &str) {
        match self {
            Self::Human => println!("{message}"),
            Self::Json => println!(
                "{}",
                serde_json::json!({
                    "level": "info",
                    "message": message,
                    "version": JSON_CONTRACT_VERSION,
                })
            ),
        }
    }
}

/// Reports an error to the appropriate channel. JSON emits a
/// structured object on stderr; human mode prints a two-line
/// `error: …` + `hint: …` block on stderr. The caller is
/// responsible for returning the exit code — see
/// [`report_error_returning`] for the common one-shot.
pub fn report_error(output: CliOutput, error: &CliError) {
    match output {
        CliOutput::Human => {
            eprintln!("error: {}", error.message);
            if let Some(hint) = &error.hint {
                eprintln!("hint: {hint}");
            }
        }
        CliOutput::Json => {
            eprintln!("{}", error.to_json());
        }
    }
}

/// Reports an error and returns the appropriate exit code.
/// This is the one-shot helper for the common "do the work,
/// then bail" pattern at the end of a leaf.
pub fn report_error_returning(output: CliOutput, error: CliError) -> ExitCode {
    report_error(output, &error);
    error.exit_code()
}

/// Structured error with a stable `code`, human `message`,
/// optional `hint`, and the `command` the user ran. All caly
/// CLI failures are represented as one of these so the JSON
/// output is uniform.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct CliError {
    /// Stable machine-readable code (e.g. `"profile.not_declared"`).
    /// Script consumers should branch on this, not the
    /// human `message`.
    pub code: &'static str,
    /// Human-readable message.
    pub message: String,
    /// Optional remediation hint. A single sentence pointing
    /// the operator at the next command to run.
    pub hint: Option<String>,
    /// The `command` the user ran (e.g. `"profile add team ..."`).
    /// Tracked in the error envelope so log-grep can find
    /// which input triggered the failure.
    pub command: String,
}

impl CliError {
    /// Builds a new `CliError` with the given code and message.
    pub fn new(code: &'static str, message: impl Into<String>, command: impl Into<String>) -> Self {
        Self {
            code,
            message: message.into(),
            hint: None,
            command: command.into(),
        }
    }

    /// Attaches a remediation hint.
    #[must_use]
    pub fn with_hint(mut self, hint: impl Into<String>) -> Self {
        self.hint = Some(hint.into());
        self
    }

    /// Returns the exit code for this error class. `Usage`
    /// errors (bad args) exit 2; everything else exits 1.
    pub fn exit_code(&self) -> ExitCode {
        if self.code.starts_with("usage.") {
            ExitCode::from(2)
        } else {
            ExitCode::FAILURE
        }
    }

    /// Serialises the error as a JSON object.
    pub fn to_json(&self) -> Value {
        let mut object = serde_json::json!({
            "ok": false,
            "version": JSON_CONTRACT_VERSION,
            "code": self.code,
            "error": self.message,
            "command": self.command,
        });
        if let Some(hint) = &self.hint {
            if let Value::Object(map) = object {
                object = Value::Object({
                    let mut m = map;
                    m.insert("hint".to_owned(), Value::String(hint.clone()));
                    m
                });
            }
        }
        object
    }
}

impl std::fmt::Display for CliError {
    fn fmt(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        write!(formatter, "{}", self.message)
    }
}

impl std::error::Error for CliError {}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn success_with_payload_merges_into_envelope() {
        let out = CliOutput::Json;
        // Smoke: just confirm we don't panic; full assertion
        // is on the to_string path below.
        out.success(
            "test",
            serde_json::json!({ "id": "team", "dry_run": false }),
        );
    }

    #[test]
    fn json_envelope_contains_version_and_ok() {
        let value = serde_json::json!({
            "ok": true,
            "version": JSON_CONTRACT_VERSION,
        });
        let text = value.to_string();
        assert!(text.contains("\"ok\":true"));
        assert!(text.contains("\"version\":1"));
    }

    #[test]
    fn error_envelope_round_trips_through_json() {
        let error = CliError::new(
            "profile.not_declared",
            "profile `team` is not declared",
            "profile show team",
        )
        .with_hint("run `caly profile add team remote:<url>` to declare it");
        let value = error.to_json();
        let text = value.to_string();
        assert!(text.contains("\"ok\":false"));
        assert!(text.contains("\"version\":1"));
        assert!(text.contains("\"code\":\"profile.not_declared\""));
        assert!(text.contains("\"error\":\"profile `team` is not declared\""));
        assert!(text.contains("\"hint\":\"run `caly profile add"));
        assert!(text.contains("\"command\":\"profile show team\""));
    }

    #[test]
    fn error_envelope_omits_hint_field_when_none() {
        let error = CliError::new("test", "msg", "cmd");
        let value = error.to_json();
        let text = value.to_string();
        assert!(!text.contains("hint"));
    }

    #[test]
    fn usage_error_exits_2_others_exit_1() {
        let usage = CliError::new("usage.bad_arg", "bad", "cmd");
        let runtime = CliError::new("runtime.failed", "fail", "cmd");
        assert_eq!(usage.exit_code(), ExitCode::from(2));
        assert_eq!(runtime.exit_code(), ExitCode::FAILURE);
    }

    #[test]
    fn output_mode_from_json_flag() {
        assert_eq!(CliOutput::from_json_flag(true), CliOutput::Json);
        assert_eq!(CliOutput::from_json_flag(false), CliOutput::Human);
        assert!(CliOutput::Json.is_json());
        assert!(!CliOutput::Human.is_json());
    }

    #[test]
    fn planned_emits_summarized_success() {
        // Round 12: `planned_ok` is the single call site for
        // a stub leaf. The human summary must end with
        // `: planned.` so a downstream tool can branch on it
        // without parsing the rest of the message.
        let out = CliOutput::Json;
        out.planned("set proxy add");
        // Re-render with no payload: just `ok: true, version: 1`.
        out.success_empty("set proxy add: planned.");
    }
}
