//! Tests for `daemon.rs`, extracted to the sibling
//! convention file (audit #70 file-length budget).

use super::*;

#[test]
fn session_token_resolves_and_differs_from_any_instance_id() {
    // The token must never equal a public daemon-instance id (#28);
    // resolution succeeds in any environment with a usable state root
    // or a working kernel CSPRNG (L2: only a broken CSPRNG refuses).
    let token = session_token().expect("test env resolves a session secret");
    assert_ne!(
        token,
        [7u8; 16],
        "the session token must never equal a daemon-instance id (#28)"
    );
}

#[test]
fn derived_token_is_deterministic_and_differs_from_its_secret() {
    // Pure-derivation contract: the same secret always yields the same
    // token, and the token is not the secret itself.
    let secret = [9u8; 16];
    assert_eq!(derive_session_token(secret), derive_session_token(secret));
    assert_ne!(derive_session_token(secret), secret);
}
