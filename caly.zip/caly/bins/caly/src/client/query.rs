//! Offline Clash API queries against the running core's controller.
//!
//! These are read-only queries (proxy groups, connections, traffic) that the
//! CLI executes directly against the controller address, without going through
//! a daemon mutation operation. The core kind is resolved from `--core` or
//! `CALY_CORE`, and the controller address from `CALY_MIHOMO_CONTROLLER` /
//! `CALY_SINGBOX_CONTROLLER` (defaulting to the standard loopback ports).

use std::process::ExitCode;

use caly_kernel::ports::{ConnectionSummary, KernelControl, ProxyGroup};

/// The controller timeout for read-only queries.
const QUERY_TIMEOUT: std::time::Duration = std::time::Duration::from_secs(5);

/// Default sample count per probe URL. Three is the
/// sweet spot for residential / mobile / cross-Pacific
/// links: a single sample is dominated by DNS cache
/// misses and TCP slow-start; two samples are still
/// affected by a single hiccup; five is overkill for
/// the operator's day-to-day use. `--samples N` on
/// `core delay` / `set core url-test` overrides this.
pub const DEFAULT_SAMPLES: u32 = 3;

/// Resolves a `--samples` argument into a clamped
/// sample count. CLI callers pass `Option<u32>` so
/// the operator can ask for 1 (fast probe) or 5
/// (jitter-heavy) without re-binding the dispatch.
/// The clamp [1, 5] is the same one the writer
/// applies, so the dispatch and the writer agree
/// on the contract.
pub fn resolve_samples(samples: Option<u32>) -> u32 {
    samples.unwrap_or(DEFAULT_SAMPLES).clamp(1, 5)
}

/// Probe targets for latency estimation, ordered by reachability of a clean
/// 204 across egresses. The kernel dials each node through the proxy, so a
/// node that cannot reach one target may reach another (different egress /
/// anycast); the first URL that answers wins, double-sampled for stability.
///
/// Cloudflare's anycast CDN leads: it is reachable from most egresses even
/// where the Google endpoints are blocked or constrained (e.g. a CN exit),
/// so the common case answers on the first URL rather than stalling the whole
/// failover across the blocked Google targets.
pub const PROBE_URLS: [&str; 3] = [
    "https://cp.cloudflare.com/generate_204",
    "https://www.google.com/generate_204",
    "https://www.gstatic.com/generate_204",
];

/// Multi-sample latency probe outcome for one node /
/// URL pair. Carries the raw samples so callers can
/// render the median *and* the spread (`jitter_ms`)
/// — a node at "50ms median ± 200ms jitter" is
/// qualitatively different from "50ms steady" even
/// though the median is the same.
///
/// `samples` is sorted ascending. `None` is the
/// "the kernel could not reach the URL at all"
/// case (HTTP 5xx, transport reset, etc.); the
/// caller distinguishes it from a kernel-side
/// `DeadlineExceeded` (which is mapped to
/// `Ok(None)` by the per-probe call and surfaces
/// upstream as the next URL in the failover chain).
#[derive(Clone, Debug, PartialEq, Eq)]
pub struct DelayProbe {
    /// Per-sample latencies in milliseconds, sorted
    /// ascending. `len() == samples` requested;
    /// `is_empty()` means the node could not reach
    /// the URL at all (kernel returned `Ok(None)`
    /// for every attempt).
    samples: Vec<u32>,
    /// Which URL the kernel answered. `None` when
    /// the node could not reach any URL.
    url: Option<String>,
}

impl DelayProbe {
    /// `true` when at least one sample answered. The
    /// human output uses this to render "reachable"
    /// vs "unreachable".
    pub fn is_reachable(&self) -> bool {
        !self.samples.is_empty()
    }

    /// Builds a `DelayProbe` from a raw sample
    /// vector. The samples are sorted ascending
    /// so `jitter_ms` and the JSON `samples`
    /// payload are stable across runs (kernel
    /// scheduling jitter can otherwise reorder
    /// the `VecDeque.pop_front` results).
    pub(crate) fn from_raw(samples: Vec<u32>, url: Option<String>) -> Self {
        let mut sorted = samples;
        sorted.sort_unstable();
        Self { samples: sorted, url }
    }

    /// The single-number summary: median of the
    /// samples (3-sample median is more spike-
    /// resistant than 2-sample min and avoids the
    /// "first sample won" bias of the historical
    /// `min` policy). Empty samples return `None`.
    pub fn median_ms(&self) -> Option<u32> {
        median(&self.samples)
    }

    /// `max - min` of the samples, or `None` when
    /// fewer than 2 samples answered. The operator
    /// uses this to spot flaky links: a node with a
    /// 200ms median and 600ms jitter is unreliable
    /// even if the median is in the "fast" tier.
    pub fn jitter_ms(&self) -> Option<u32> {
        if self.samples.len() < 2 {
            return None;
        }
        let min = *self.samples.first()?;
        let max = *self.samples.last()?;
        Some(max - min)
    }

    /// Round 31: minimum of the sorted
    /// samples. `None` for fewer than 1
    /// sample (the empty / all-drops
    /// case). For 1 sample the value is
    /// trivially that single sample. The
    /// operator uses this to spot a
    /// "lucky first probe" pattern: a node
    /// at `min = 50ms, max = 800ms, median
    /// = 200ms` answered 50ms once but is
    /// otherwise spiky — the `min` makes
    /// the bias visible alongside the
    /// already-reported `median_ms` /
    /// `jitter_ms` / `samples` triple.
    pub fn min_ms(&self) -> Option<u32> {
        self.samples.first().copied()
    }

    /// Round 31: maximum of the sorted
    /// samples. The mirror of `min_ms`;
    /// see that method's doc for the
    /// operator-facing rationale.
    pub fn max_ms(&self) -> Option<u32> {
        self.samples.last().copied()
    }

    /// Round 31: population standard deviation
    /// of the samples, rounded to the nearest
    /// `u32` millisecond. `None` for fewer than
    /// 2 samples (a single observation has no
    /// spread). The operator reads `stdev` as
    /// the "shape" of the latency distribution:
    /// `median = 100ms, stdev = 5ms` is
    /// rock-solid; `median = 100ms, stdev =
    /// 50ms` is "around 100ms" but the actual
    /// dial could land anywhere from 50 to
    /// 150ms. The helper uses the
    /// population formula (divide by `n`, not
    /// `n - 1`) because every sample is the
    /// full set (no sampling-from-a-larger-
    /// distribution inference). The integer
    /// `u32` representation is bounded at
    /// ~4.29e9 ms (~50 days) which is well
    /// above the operator-relevant range.
    ///
    /// The `f64` accumulator trades the
    /// `u64`-mantissa precision for the
    /// `sqrt` operation (no native integer
    /// square root); the precision loss is
    /// acceptable for a `n <= 5` sample count
    /// (the kernel's `samples` clamp is `[1,
    /// 5]`) because the per-sample magnitude
    /// is bounded by the kernel's `5s` probe
    /// timeout (5_000 ms), well within `f64`'s
    /// 52-bit mantissa. The `cast_*_lossy`
    /// allow on the `as` casts documents the
    /// intentional precision trade.
    #[allow(clippy::cast_precision_loss, clippy::cast_sign_loss, clippy::cast_possible_truncation)]
    pub fn stdev_ms(&self) -> Option<u32> {
        if self.samples.len() < 2 {
            return None;
        }
        let n = self.samples.len() as u64;
        let sum: u64 = self.samples.iter().map(|s| u64::from(*s)).sum();
        let mean = sum as f64 / n as f64;
        let variance = self
            .samples
            .iter()
            .map(|s| {
                let diff = f64::from(*s) - mean;
                diff * diff
            })
            .sum::<f64>()
            / n as f64;
        Some(variance.sqrt().round() as u32)
    }

    /// Raw samples (sorted ascending). Useful for
    /// script consumers who want the full
    /// distribution, not just the summary.
    pub fn samples(&self) -> &[u32] {
        &self.samples
    }

    /// The URL that answered. Stable for any single
    /// `DelayProbe` instance.
    pub fn url(&self) -> Option<&str> {
        self.url.as_deref()
    }
}

/// Returns the median of `samples`. For even counts
/// the lower of the two middle values is returned —
/// this matches the operator's mental model "a
/// latency of N is the smallest range that contains
/// the middle of the distribution" and avoids the
/// averaging that would inflate a single 50ms spike
/// into a 60ms answer.
pub(super) fn median(samples: &[u32]) -> Option<u32> {
    if samples.is_empty() {
        return None;
    }
    let mut sorted: Vec<u32> = samples.to_vec();
    sorted.sort_unstable();
    // `len / 2` rounds *down* for both odd and
    // even lengths: `[a]` → `[0]` (the single
    // element), `[a, b]` → `[0]` (the lower of
    // the two), `[a, b, c]` → `[1]` (the middle).
    Some(sorted[(sorted.len() - 1) / 2])
}

/// Probes one node through the active core controller with URL failover
/// and a 3-sample median summary.
///
/// * URLs are tried in order; the first URL the node can reach wins.
/// * On the winning URL the writer collects `samples` measurements
///   (default 3) and reports the median. Earlier the writer took
///   `min` of 2 samples, which under-estimated a single-shot spike
///   on the *second* sample: the kernel's first response includes
///   the operator's TCP / TLS handshake (cold cache), the second
///   response is warm, so `min` always picked the second. Median
///   of 3 is unbiased across cold/warm/hiccup.
/// * `samples = 1` keeps the historical single-shot
///   behaviour for callers that want the absolute
///   fastest probe (a script piping `delay` into
///   `core select --delay` round-trips).
/// * All URLs unreachable maps to `Ok(DelayProbe{ samples: vec![], url: None })`;
///   a controller transport error (connect failure, kernel
///   gone) stays `Err` so callers can distinguish an
///   unreachable node from a probe infrastructure
///   fault.
pub(super) fn probe_delay(
    control: &mut dyn KernelControl,
    name: &str,
    url: Option<&str>,
    timeout: std::time::Duration,
    samples: u32,
) -> Result<DelayProbe, caly_kernel::ports::KernelFailure> {
    let urls: Vec<&str> = match url {
        Some(value) => vec![value],
        None => PROBE_URLS.to_vec(),
    };
    // Clamp the sample count: 1 keeps the legacy
    // "fast probe" path; >5 wastes operator time on
    // a `delay --all` sweep without materially
    // changing the median. The CLI validates the
    // upper bound at parse time, so reaching this
    // branch with a too-large value means a
    // programmatic caller (test / future wire
    // command) tried to override the contract.
    let samples = samples.clamp(1, 5);
    for probe_url in urls {
        let collected = collect_samples(control, name, probe_url, timeout, samples, SAMPLE_GAP);
        match collected {
            Ok(Some(measurement)) => {
                return Ok(DelayProbe::from_raw(
                    measurement,
                    Some(probe_url.to_owned()),
                ));
            }
            Ok(None) => {
                // This URL is unreachable from this
                // node; try the next one in the
                // failover chain.
            }
            Err(error) => return Err(error),
        }
    }
    Ok(DelayProbe {
        samples: Vec::new(),
        url: None,
    })
}

/// Inter-sample gap between probes. The kernel's
/// per-name cache (TFO / TLS session resumption)
/// keeps a back-to-back probe from exercising a
/// fresh dial path, so a small gap is required.
/// 100ms is short enough to keep the operator's
/// wall-clock low for `delay --all`, long enough
/// to defeat the cache on a hot egress.
const SAMPLE_GAP: std::time::Duration = std::time::Duration::from_millis(100);

/// Probes one URL with up to `samples` measurements
/// and returns the successful ones. A 100ms gap
/// between samples keeps a hot egress from queueing
/// the second and third requests behind the first
/// (Mihomo's controller is single-threaded per
/// connection group; back-to-back probes otherwise
/// all serialise on the same TFO cache key).
///
/// `gap` is the inter-sample sleep; the test suite
/// passes a sub-millisecond gap to keep the suite
/// fast, production callers pass [`SAMPLE_GAP`].
fn collect_samples(
    control: &mut dyn KernelControl,
    name: &str,
    url: &str,
    timeout: std::time::Duration,
    samples: u32,
    gap: std::time::Duration,
) -> Result<Option<Vec<u32>>, caly_kernel::ports::KernelFailure> {
    let mut collected: Vec<u32> = Vec::with_capacity(samples as usize);
    for _ in 0..samples {
        match control.test_delay_url(name, url, timeout) {
            Ok(Some(ms)) => {
                collected.push(ms);
            }
            Ok(None) => {
                // A late sample lost the race; the
                // earlier samples are still
                // representative. Return them.
                if collected.is_empty() {
                    return Ok(None);
                }
                return Ok(Some(collected));
            }
            Err(error)
                if error.kind == caly_kernel::ports::KernelFailureKind::DeadlineExceeded =>
            {
                // The probe stalled on this URL.
                // The node might still answer a
                // different URL; surface the
                // partial result if we have any,
                // otherwise let the caller try
                // the next URL.
                if collected.is_empty() {
                    return Ok(None);
                }
                return Ok(Some(collected));
            }
            Err(error) => return Err(error),
        }
        // The unit tests pass a sub-millisecond
        // gap so the suite runs in milliseconds,
        // not seconds. Production callers use
        // [`SAMPLE_GAP`] to defeat the kernel's
        // per-name cache.
        if samples > 1 {
            std::thread::sleep(gap);
        }
    }
    Ok(Some(collected))
}

/// Executes a read-only Clash API query against the resolved core controller.
pub fn run_query(core: &str, query: Query, json: bool) -> ExitCode {
    let mut control = match build_control(core) {
        Ok(control) => control,
        Err(error) => {
            return crate::client::output::report_failure(&format!("query failed: {error}"), json);
        }
    };
    match query {
        Query::ProxyGroups => match control.proxy_groups(QUERY_TIMEOUT) {
            Ok(groups) => print_groups(&groups, json),
            Err(error) => report_query_error(&format!("{error}"), json),
        },
        Query::Connections => match control.connections(QUERY_TIMEOUT) {
            Ok(summary) => print_connections(&summary, json),
            Err(error) => report_query_error(&format!("{error}"), json),
        },
        Query::Traffic => match control.traffic(QUERY_TIMEOUT) {
            Ok((download, upload)) => print_traffic(download, upload, json),
            Err(error) => report_query_error(&format!("{error}"), json),
        },
        Query::UrlTest {
            name,
            url,
            samples,
        } => match probe_delay(
            &mut *control,
            &name,
            url.as_deref(),
            QUERY_TIMEOUT,
            samples,
        ) {
            Ok(probe) => print_delay(&name, &probe, json),
            Err(error) => report_query_error(&format!("{error}"), json),
        },
    }
}

/// A read-only Clash API query.
#[derive(Clone, Debug, Eq, PartialEq)]
pub enum Query {
    ProxyGroups,
    Connections,
    Traffic,
    /// Latency test for a named proxy (`GET /proxies/{name}/delay`).
    UrlTest {
        name: String,
        /// Probe target URL override (default: Google generate_204).
        url: Option<String>,
        /// Sample count (1..=5). Defaults to
        /// [`DEFAULT_SAMPLES`] when the operator
        /// doesn't pass `--samples`.
        samples: u32,
    },
}

/// Builds the core controller from the resolved core kind.
pub(super) fn build_control(core: &str) -> Result<Box<dyn KernelControl + Send>, String> {
    // The daemon persists its generated controller secret to an owner-only file
    // so offline queries authenticate; `CALY_CONTROLLER_SECRET` overrides it.
    let secret = std::env::var("CALY_CONTROLLER_SECRET")
        .ok()
        .or_else(read_daemon_secret)
        .and_then(|value| caly_domain::BoundedText::new(value).ok());
    // Controller endpoints come from the config file (then env, then defaults).
    let controllers = crate::daemon_config::controllers().map_err(|e| format!("{e:?}"))?;
    match core {
        "mihomo" => caly_kernel::mihomo::MihomoHttpControl::new(controllers.mihomo, secret)
            .map(|control| Box::new(control) as Box<dyn KernelControl + Send>)
            .map_err(|error| format!("{error:?}")),
        "sing-box" => caly_kernel::sing_box::SingBoxHttpControl::new(controllers.sing_box, secret)
            .map(|control| Box::new(control) as Box<dyn KernelControl + Send>)
            .map_err(|error| format!("{error:?}")),
        other => Err(format!("unknown core `{other}`; use mihomo or sing-box")),
    }
}

/// Reads the controller secret the daemon persisted under the XDG runtime root.
fn read_daemon_secret() -> Option<String> {
    let path = caly_platform::paths::AppPaths::from_env().controller_secret_path();
    std::fs::read_to_string(&path)
        .ok()
        .map(|value| value.trim().to_owned())
        .filter(|value| !value.is_empty())
}

fn print_groups(groups: &[ProxyGroup], json: bool) -> ExitCode {
    if json {
        let value: Vec<serde_json::Value> = groups
            .iter()
            .map(|group| {
                serde_json::json!({
                    "name": group.name,
                    "selected": group.selected,
                })
            })
            .collect();
        println!("{}", serde_json::json!({ "proxy_groups": value }));
    } else {
        println!("proxy groups:");
        for group in groups {
            let selected = group.selected.as_deref().unwrap_or("-");
            println!("  {} (selected: {selected})", group.name);
        }
    }
    ExitCode::SUCCESS
}

fn print_connections(summary: &ConnectionSummary, json: bool) -> ExitCode {
    if json {
        println!(
            "{}",
            serde_json::json!({
                "active": summary.active,
                "download_bytes": summary.download_bytes,
                "upload_bytes": summary.upload_bytes,
            })
        );
    } else {
        println!(
            "connections: {} active | download {} B | upload {} B",
            summary.active, summary.download_bytes, summary.upload_bytes
        );
    }
    ExitCode::SUCCESS
}

fn print_traffic(download: u64, upload: u64, json: bool) -> ExitCode {
    if json {
        println!(
            "{}",
            serde_json::json!({ "download_bytes": download, "upload_bytes": upload })
        );
    } else {
        println!("traffic: download {download} B | upload {upload} B");
    }
    ExitCode::SUCCESS
}

/// Renders one node's probe result. The human form
/// always shows the median and the spread so the
/// operator can see jitter at a glance; the JSON
/// form carries the full sample list for scripts
/// that want the distribution.
fn print_delay(name: &str, probe: &DelayProbe, json: bool) -> ExitCode {
    if json {
        let mut payload = serde_json::json!({
            "name": name,
            "samples": probe.samples(),
            "median_ms": probe.median_ms(),
            "min_ms": probe.min_ms(),
            "max_ms": probe.max_ms(),
            "jitter_ms": probe.jitter_ms(),
            "stdev_ms": probe.stdev_ms(),
            "url": probe.url(),
        });
        // The legacy `delay_ms` field stays in the
        // envelope so the historical `jq .delay_ms`
        // queries keep working — it is the median,
        // the same value the human form prints.
        if let Some(ms) = probe.median_ms() {
            if let serde_json::Value::Object(ref mut map) = payload {
                map.insert("delay_ms".to_owned(), serde_json::Value::from(ms));
            }
        }
        println!("{payload}");
    } else {
        match probe.median_ms() {
            Some(median) => {
                let jitter = probe
                    .jitter_ms()
                    .map(|j| format!(" (± {j} ms)"))
                    .unwrap_or_default();
                println!("{name}: {median} ms{jitter}");
            }
            None => println!("{name}: unreachable / no latency"),
        }
    }
    ExitCode::SUCCESS
}

fn report_query_error(message: &str, json: bool) -> ExitCode {
    crate::client::output::report_failure(&format!("query failed: {message}"), json)
}

#[cfg(test)]
mod probe_tests {
    use super::*;
    use caly_kernel::ports::{KernelControl, KernelFailure};
    use std::sync::PoisonError;
    use std::time::Duration;

    /// A test controller whose delay is a
    /// caller-supplied sequence. Lets the unit
    /// suite assert the median / jitter math
    /// without spinning up a real kernel.
    struct ScriptedController {
        /// Each entry is one `test_delay_url` call's
        /// outcome. The probe loop drains this FIFO
        /// in order; once exhausted it returns
        /// `Ok(None)` (the URL dropped mid-sweep).
        queue: std::sync::Mutex<std::collections::VecDeque<u32>>,
    }

    impl ScriptedController {
        fn with_samples(samples: &[u32]) -> Self {
            Self {
                queue: std::sync::Mutex::new(
                    samples.iter().copied().collect(),
                ),
            }
        }
    }

    impl KernelControl for ScriptedController {
        fn capabilities(&self) -> caly_domain::CapabilitySet {
            // The test stub does not exercise the
            // capabilities surface; an empty
            // capability set is the correct
            // "no capabilities declared" answer
            // for a unit test.
            use caly_domain::BoundedVec;
            caly_domain::CapabilitySet::from_bounded_dedup(BoundedVec::default())
        }
        fn wait_ready(&mut self, _timeout: Duration) -> Result<(), KernelFailure> {
            Ok(())
        }
        fn select_proxy(
            &mut self,
            _node: caly_domain::NodeId,
            _timeout: Duration,
        ) -> Result<(), KernelFailure> {
            Ok(())
        }
        fn health_check(&mut self, _timeout: Duration) -> Result<(), KernelFailure> {
            Ok(())
        }
        fn test_delay_url(
            &mut self,
            _name: &str,
            _url: &str,
            _timeout: Duration,
        ) -> Result<Option<u32>, KernelFailure> {
            let mut guard = self.queue.lock().unwrap_or_else(PoisonError::into_inner);
            Ok(guard.pop_front())
        }

        fn proxy_names(&mut self, _timeout: Duration) -> Result<Vec<String>, KernelFailure> {
            Ok(Vec::new())
        }
        fn proxy_groups(&mut self, _timeout: Duration) -> Result<Vec<ProxyGroup>, KernelFailure> {
            Ok(Vec::new())
        }
        fn connections(&mut self, _timeout: Duration) -> Result<ConnectionSummary, KernelFailure> {
            Ok(ConnectionSummary {
                active: 0,
                download_bytes: 0,
                upload_bytes: 0,
            })
        }
        fn traffic(&mut self, _timeout: Duration) -> Result<(u64, u64), KernelFailure> {
            Ok((0, 0))
        }
    }

    #[test]
    fn median_of_three_samples_is_the_middle() {
        // [50, 200, 800] → median 200. The historical
        // `min` policy would have answered 50; the
        // operator never saw the true hot/warm/hiccup
        // distribution.
        let mut controller = ScriptedController::with_samples(&[50, 200, 800]);
        let probe = probe_delay(
            &mut controller,
            "test",
            Some("https://probe.example/"),
            Duration::from_millis(100),
            3,
        )
        .unwrap_or_else(|_| std::process::abort());
        assert_eq!(probe.median_ms(), Some(200));
        assert_eq!(probe.jitter_ms(), Some(800 - 50));
        assert_eq!(probe.samples(), &[50, 200, 800]);
    }

    #[test]
    fn jitter_is_none_for_a_single_sample() {
        let mut controller = ScriptedController::with_samples(&[42]);
        let probe = probe_delay(
            &mut controller,
            "test",
            Some("https://probe.example/"),
            Duration::from_millis(100),
            1,
        )
        .unwrap_or_else(|_| std::process::abort());
        assert_eq!(probe.samples().len(), 1);
        assert_eq!(probe.jitter_ms(), None);
        assert_eq!(probe.median_ms(), Some(42));
    }

    #[test]
    fn samples_clamps_to_a_safe_range() {
        // `samples = 0` is clamped to 1 (one
        // measurement still answers the question);
        // `samples = 99` is clamped to 5 (more
        // wastes wall-clock time without changing
        // the median). The Queue has only 5 entries
        // so the clamp prevents a panic on a too-
        // large requested sample count.
        let mut controller = ScriptedController::with_samples(&[10, 20, 30, 40, 50]);
        let mut probe_zero_controller = ScriptedController::with_samples(&[99]);
        let probe_zero = probe_delay(
            &mut probe_zero_controller,
            "test",
            Some("https://probe.example/"),
            Duration::from_millis(100),
            0,
        )
        .unwrap_or_else(|_| std::process::abort());
        assert_eq!(probe_zero.samples().len(), 1);
        let probe_huge = probe_delay(
            &mut controller,
            "test",
            Some("https://probe.example/"),
            Duration::from_millis(100),
            99,
        )
        .unwrap_or_else(|_| std::process::abort());
        assert_eq!(probe_huge.samples().len(), 5);
    }

    #[test]
    fn empty_samples_after_url_drain_returns_unreachable() {
        // No samples answered. The probe is
        // reachable=false; the median is None; the
        // envelope `url` is None so the dispatch can
        // tell the operator "we tried every URL, all
        // were silent".
        let mut controller = ScriptedController::with_samples(&[]);
        let probe = probe_delay(
            &mut controller,
            "test",
            Some("https://probe.example/"),
            Duration::from_millis(100),
            3,
        )
        .unwrap_or_else(|_| std::process::abort());
        assert!(!probe.is_reachable());
        assert_eq!(probe.median_ms(), None);
        assert_eq!(probe.url(), None);
    }

    #[test]
    fn partial_samples_preserved_when_url_keeps_failing() {
        // First two samples answered (50, 200 ms);
        // the third call returns `Ok(None)`
        // (kernel dropped the connection). The
        // historical implementation would have
        // returned `Ok(None)` and lost the two
        // good samples. The new implementation
        // returns the partial result so the operator
        // sees *some* number for the node instead of
        // a misleading "unreachable" verdict that
        // ignored the two good measurements.
        let mut controller = ScriptedController::with_samples(&[50, 200]);
        let probe = probe_delay(
            &mut controller,
            "test",
            Some("https://probe.example/"),
            Duration::from_millis(100),
            3,
        )
        .unwrap_or_else(|_| std::process::abort());
        assert_eq!(probe.samples(), &[50, 200]);
        // Median of sorted [50, 200] is the lower
        // middle (50). The historical `min` policy
        // also returned 50 here, so this case is
        // unchanged from Round 17. The behavioural
        // change is `[50, 200, 800]` → 200 (the
        // middle), not 50 (the min).
        assert_eq!(probe.median_ms(), Some(50));
    }

    #[test]
    fn even_sample_count_picks_the_lower_middle() {
        // For 2 samples the median is the lower
        // value: [50, 200] → 50. The historical
        // `min` policy had the same answer; the
        // behaviour is now consistent across 1, 2,
        // 3, 4, 5 samples and documented in the
        // `median` doc-comment.
        let mut controller = ScriptedController::with_samples(&[50, 200]);
        let probe = probe_delay(
            &mut controller,
            "test",
            Some("https://probe.example/"),
            Duration::from_millis(100),
            2,
        )
        .unwrap_or_else(|_| std::process::abort());
        assert_eq!(probe.median_ms(), Some(50));
    }

    /// Round 31: `min_ms` / `max_ms` are the
    /// endpoints of the sorted sample vector.
    /// The pre-Round 31 envelope only surfaced
    /// the median / jitter / samples triple;
    /// the new shape surfaces the min and max
    /// explicitly so a script consumer can see
    /// the bias without re-deriving it from the
    /// `samples` array. A single sample has
    /// `min = max = sample` (no spread).
    #[test]
    fn min_and_max_are_sample_endpoints() {
        let mut controller = ScriptedController::with_samples(&[50, 200, 800]);
        let probe = probe_delay(
            &mut controller,
            "test",
            Some("https://probe.example/"),
            Duration::from_millis(100),
            3,
        )
        .unwrap_or_else(|_| std::process::abort());
        assert_eq!(probe.min_ms(), Some(50));
        assert_eq!(probe.max_ms(), Some(800));
        assert_eq!(probe.min_ms(), probe.samples().first().copied());
        assert_eq!(probe.max_ms(), probe.samples().last().copied());
    }

    /// Round 31: a single sample has
    /// `min = max = median = sample` and
    /// `stdev = jitter = None` (no spread to
    /// measure). The pre-Round 31 envelope had
    /// the same answer for the median but
    /// silently did not surface min / max /
    /// stdev at all. The new shape surfaces
    /// every scalar the operator can derive
    /// from the samples.
    #[test]
    fn single_sample_has_min_max_equal_to_sample() {
        let mut controller = ScriptedController::with_samples(&[42]);
        let probe = probe_delay(
            &mut controller,
            "test",
            Some("https://probe.example/"),
            Duration::from_millis(100),
            1,
        )
        .unwrap_or_else(|_| std::process::abort());
        assert_eq!(probe.min_ms(), Some(42));
        assert_eq!(probe.max_ms(), Some(42));
        assert_eq!(probe.median_ms(), Some(42));
        assert_eq!(probe.stdev_ms(), None);
        assert_eq!(probe.jitter_ms(), None);
    }

    /// Round 31: the population standard
    /// deviation for the canonical
    /// `[50, 200, 800]` shape. The mean is
    /// `(50 + 200 + 800) / 3 = 350`. The
    /// squared deviations are
    /// `(50 - 350)^2 = 90000`,
    /// `(200 - 350)^2 = 22500`,
    /// `(800 - 350)^2 = 202500`. Sum
    /// = `315000`. Population variance
    /// = `315000 / 3 = 105000`. Population
    /// stdev = `sqrt(105000) ≈ 324.04`,
    /// rounded to `324`. The integer rounding
    /// means a future change to `f64`
    /// precision in the JSON envelope stays
    /// stable.
    #[test]
    fn stdev_for_canonical_three_samples_is_documented_constant() {
        let mut controller = ScriptedController::with_samples(&[50, 200, 800]);
        let probe = probe_delay(
            &mut controller,
            "test",
            Some("https://probe.example/"),
            Duration::from_millis(100),
            3,
        )
        .unwrap_or_else(|_| std::process::abort());
        assert_eq!(probe.stdev_ms(), Some(324));
    }

    /// Round 31: an even sample count of
    /// `[50, 100, 200, 800]`. The mean is
    /// `(50 + 100 + 200 + 800) / 4 = 287.5`.
    /// Squared deviations:
    /// `(50 - 287.5)^2 = 56406.25`,
    /// `(100 - 287.5)^2 = 35156.25`,
    /// `(200 - 287.5)^2 = 7656.25`,
    /// `(800 - 287.5)^2 = 262656.25`. Sum
    /// = `361875`. Population variance
    /// = `361875 / 4 = 90468.75`.
    /// Population stdev
    /// = `sqrt(90468.75) ≈ 300.78`,
    /// rounded to `301`.
    #[test]
    fn stdev_for_even_sample_count_uses_population_formula() {
        let mut controller = ScriptedController::with_samples(&[50, 100, 200, 800]);
        let probe = probe_delay(
            &mut controller,
            "test",
            Some("https://probe.example/"),
            Duration::from_millis(100),
            4,
        )
        .unwrap_or_else(|_| std::process::abort());
        assert_eq!(probe.stdev_ms(), Some(301));
    }

    /// Round 31: a uniform sample vector
    /// (e.g. `[100, 100, 100]`) has zero
    /// spread. The pre-Round 31 jitter helper
    /// returned 0 for the difference but
    /// `None` for a single sample; the new
    /// `stdev_ms` returns 0 for any
    /// `n >= 2` uniform distribution. The
    /// test pins the contract so a future
    /// "always return 0 for `n >= 2`" change
    /// surfaces here.
    #[test]
    fn stdev_is_zero_for_a_uniform_sample_vector() {
        let mut controller = ScriptedController::with_samples(&[100, 100, 100]);
        let probe = probe_delay(
            &mut controller,
            "test",
            Some("https://probe.example/"),
            Duration::from_millis(100),
            3,
        )
        .unwrap_or_else(|_| std::process::abort());
        assert_eq!(probe.stdev_ms(), Some(0));
        assert_eq!(probe.jitter_ms(), Some(0));
        assert_eq!(probe.min_ms(), Some(100));
        assert_eq!(probe.max_ms(), Some(100));
    }
}
