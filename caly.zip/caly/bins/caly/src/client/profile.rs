//! Offline profile resource management for the `caly profile` subcommand.
//!
//! The five subcommands (`add`, `list`, `show`, `refresh`, `remove`)
//! operate on the operator's `<config>/config.yaml` and the
//! `<state>/profiles/` cache. `refresh` is the only one that
//! reaches out to the network: it routes `kind: remote` profiles
//! through the SSRF-safe [`caly_config::profile_fetch::fetch_profile_body`]
//! pipeline and materialises the body through the on-disk
//! `ProfileStore`. The `Merge` recursive walk is implemented in
//! [`refresh_recursive`] so a merge's `Remote` dependencies are
//! refreshed before the merge itself is reported as done.

use std::{
    fs,
    path::Path,
};

use caly_config::{
    loader::{InMemoryProfileResolver, LayeredConfigPaths, LoaderLimits},
    profile_store::{ProfileStore, ProfileStoreError},
    schema::{AppConfig, ProfileConfig, ProfileSourceConfig},
};
use caly_domain::{Profile, is_path_safe_component};
use caly_platform::paths::AppPaths;

use super::resource_writer::{ResourceWriteOutcome, current_unix_ms};

/// One declared profile as it appears in `config.yaml`'s
/// `profiles:` list, with the rendered source field expanded
/// into a machine-readable shape.
#[derive(Clone, Debug, PartialEq)]
pub struct DeclaredProfile {
    /// User-supplied id; path-safe ASCII.
    pub id: String,
    /// Optional human label.
    pub name: Option<String>,
    /// Optional free-form description.
    pub description: Option<String>,
    /// Source kind expanded to a known variant.
    pub source: ProfileSourceKind,
}

/// Source kind for the CLI presentation. Mirrors
/// [`caly_domain::ProfileSource`] but erases the bounded text
/// (the CLI has no concept of "size exceeded" diagnostics; the
/// domain already enforces that at parse time).
#[derive(Clone, Debug, PartialEq)]
pub enum ProfileSourceKind {
    Local {
        path: String,
    },
    Remote {
        url: String,
        interval_minutes: u32,
    },
    Merge {
        parts: Vec<String>,
    },
}

impl DeclaredProfile {
    // `display_label` was removed in Round 32: the JSON
    // envelope already carries `id` and `name` for
    // `show profile list` callers, and the operator-facing
    // text path uses `id` directly. The domain
    // `Profile::display_label` stays for the typed
    // rendering path (where the `Profile` struct is
    // available; the CLI never has a `Profile` in hand
    // — it only has a `DeclaredProfile`).
}

/// Failure mode for the offline profile commands.
#[derive(Debug)]
pub enum ProfileCmdError {
    /// The operator-supplied id is not path-safe ASCII.
    InvalidId(String),
    /// The supplied `source` spec is not parseable.
    InvalidSource(String),
    /// The base config could not be read.
    ReadConfig(String),
    /// The base config could not be parsed or validated.
    ParseConfig(String),
    /// The cache write failed.
    Store(ProfileStoreError),
    /// The operator asked to refresh / show / remove an id that is
    /// not declared in the base config.
    NotDeclared(String),
    /// The operator asked to add an id that already exists.
    AlreadyDeclared(String),
    /// The `Remote` body could not be fetched (network or SSRF).
    Fetch(caly_config::profile_fetch::ProfileFetchError),
    /// `Merge.parts` referenced a `Remote` whose fetch failed; the
    /// outer error wraps the inner failure so the operator sees
    /// both the offender and the cause.
    FetchChain { id: String, source: caly_config::profile_fetch::ProfileFetchError },
    /// The pre-write backup of `<config>/config.yaml` failed.
    /// Carries the source and destination paths so the
    /// operator can investigate without re-running with a
    /// debug log.
    Backup {
        from: std::path::PathBuf,
        to: std::path::PathBuf,
        reason: String,
    },
}

impl core::fmt::Display for ProfileCmdError {
    fn fmt(&self, formatter: &mut core::fmt::Formatter<'_>) -> core::fmt::Result {
        match self {
            Self::InvalidId(id) => write!(formatter, "profile id `{id}` is not path-safe ASCII"),
            Self::InvalidSource(spec) => write!(formatter, "source spec `{spec}` is invalid"),
            Self::ReadConfig(reason) => write!(formatter, "read config: {reason}"),
            Self::ParseConfig(reason) => write!(formatter, "parse config: {reason}"),
            Self::Store(error) => write!(formatter, "profile store: {error}"),
            Self::NotDeclared(id) => write!(formatter, "profile `{id}` is not declared"),
            Self::AlreadyDeclared(id) => write!(formatter, "profile `{id}` is already declared"),
            Self::Fetch(error) => write!(formatter, "profile fetch: {error}"),
            Self::FetchChain { id, source } => {
                write!(formatter, "profile `{id}` chain fetch: {source}")
            }
            Self::Backup { from, to, reason } => write!(
                formatter,
                "config backup from {} to {} failed: {reason}",
                from.display(),
                to.display()
            ),
        }
    }
}

impl std::error::Error for ProfileCmdError {}

impl From<ProfileStoreError> for ProfileCmdError {
    fn from(value: ProfileStoreError) -> Self {
        Self::Store(value)
    }
}

/// Round 22: every `set profile <verb>` writer
/// returns the same [`ProfileWriteOutcome`] so the
/// dispatch in `commands::set::profile` routes every
/// CRUD leaf through the shared
/// `commands::set::common::run_writer` envelope
/// (the same shape `set sub` / `set rule-provider` /
/// `set proxy-group` use). Pre-Round 22 the writers
/// returned two different enums (`AddOutcome` /
/// `RemoveOutcome`) and the dispatch hand-rolled 8
/// near-identical envelope / error matches.
pub type ProfileWriteOutcome = ResourceWriteOutcome;

/// Resolves the operator's XDG config and state roots. Tests
/// inject a custom root by overriding `HOME` / `XDG_*`; the
/// default uses `AppPaths::from_env()`.
pub fn resolve_paths() -> AppPaths {
    AppPaths::from_env()
}

/// Loads the declared profiles from `<config>/config.yaml` and the
/// `config.d/` fragments. The base must be readable; missing
/// `config.d/` is not an error (the empty-fragment path is
/// already exercised by the loader). The resolver is **lenient**:
/// a `Remote` profile whose cache is missing is treated as an
/// empty body, so the operator-facing CLI can list and show
/// declared profiles before the first `refresh`. Production
/// boot uses the strict [`ProfileStore`], which fails loudly
/// when the cache is missing. The returned `AppConfig` reflects
/// the merged state.
pub fn load_declared_profiles(
    paths: &AppPaths,
) -> Result<(AppConfig, ProfileStore), ProfileCmdError> {
    let limits = LoaderLimits::secure_default();
    let layered = LayeredConfigPaths::new(paths.config.clone(), None);
    let resolver = InMemoryProfileResolver::lenient();
    let config = caly_config::loader::load_layered_yaml_with(&layered, limits, &resolver)
        .map_err(|error| ProfileCmdError::ReadConfig(error.to_string()))?;
    let store = ProfileStore::new(paths.config.clone(), paths.state.clone());
    Ok((config, store))
}

/// Parses a `source` spec argument of the form
/// `remote:<url>`, `local:<path>` or `merge:<id1,id2,…>`.
pub fn parse_source_spec(spec: &str) -> Result<ProfileSourceKind, ProfileCmdError> {
    let (kind, body) = spec.split_once(':').ok_or_else(|| {
        ProfileCmdError::InvalidSource(format!(
            "{spec}: expected `remote:<url>`, `local:<path>` or `merge:<id1,id2,…>`"
        ))
    })?;
    match kind.trim() {
        "remote" => {
            let url = body.trim();
            if url.is_empty() {
                return Err(ProfileCmdError::InvalidSource(spec.to_owned()));
            }
            Ok(ProfileSourceKind::Remote {
                url: url.to_owned(),
                interval_minutes: 60,
            })
        }
        "local" => {
            let path = body.trim();
            if path.is_empty() {
                return Err(ProfileCmdError::InvalidSource(spec.to_owned()));
            }
            Ok(ProfileSourceKind::Local {
                path: path.to_owned(),
            })
        }
        "merge" => {
            let parts: Vec<String> = body
                .split(',')
                .map(|part| part.trim().to_owned())
                .filter(|part| !part.is_empty())
                .collect();
            if parts.is_empty() {
                return Err(ProfileCmdError::InvalidSource(spec.to_owned()));
            }
            Ok(ProfileSourceKind::Merge { parts })
        }
        other => Err(ProfileCmdError::InvalidSource(format!(
            "unknown source kind `{other}`: expected `remote`, `local` or `merge`"
        ))),
    }
}

/// Lists the declared profiles in declaration order.
pub fn list_declared(config: &AppConfig) -> Vec<DeclaredProfile> {
    config
        .profiles
        .iter()
        .map(expand_declared)
        .collect()
}

fn expand_declared(profile: &ProfileConfig) -> DeclaredProfile {
    let source = match &profile.source {
        ProfileSourceConfig::Local { path } => ProfileSourceKind::Local { path: path.clone() },
        ProfileSourceConfig::Remote {
            url,
            interval_minutes,
        } => ProfileSourceKind::Remote {
            url: url.clone(),
            interval_minutes: *interval_minutes,
        },
        ProfileSourceConfig::Merge { parts } => ProfileSourceKind::Merge {
            parts: parts.clone(),
        },
    };
    DeclaredProfile {
        id: profile.id.clone(),
        name: profile.name.clone(),
        description: profile.description.clone(),
        source,
    }
}

/// Looks up a single declared profile by id.
pub fn find_declared<'a>(config: &'a AppConfig, id: &str) -> Option<&'a ProfileConfig> {
    config.profiles.iter().find(|profile| profile.id == id)
}

/// Fetches one `Remote` profile body through the SSRF-safe
/// pipeline and materialises it in the on-disk cache. `Local`
/// and `Merge` profiles are not network-touching; the
/// caller is expected to skip them.
pub fn refresh_one(
    store: &ProfileStore,
    profile: &Profile,
) -> Result<(), ProfileCmdError> {
    use caly_config::profile_fetch::{
        ProfileFetchError, fetch_profile_body, is_transient_profile_error,
    };
    use caly_config::subscription::{FetchPolicy, FetchValidators};
    let url = match &profile.source {
        caly_domain::ProfileSource::Remote { url, .. } => url.as_str(),
        caly_domain::ProfileSource::Local { .. } | caly_domain::ProfileSource::Merge { .. } => {
            // Non-network profiles are no-ops at the fetcher level.
            return Ok(());
        }
    };
    let policy = FetchPolicy::direct_default();
    let validators = FetchValidators {
        etag: None,
        last_modified: None,
    };
    let handle = tokio::runtime::Handle::try_current().map_err(|_| {
        ProfileCmdError::Fetch(ProfileFetchError::ClientBuild)
    })?;
    // Bounded retry loop: 2 attempts on transient failures,
    // 250 ms backoff. Mirrors the subscription backend's
    // pattern so the operator-facing diagnostics stay
    // consistent across fetches.
    let mut last_transient: Option<ProfileFetchError> = None;
    for attempt in 0..2 {
        let outcome = handle.block_on(fetch_profile_body(
            url,
            &caly_config::subscription::PublicAddressClassifier,
            policy,
            &validators,
        ));
        match outcome {
            Ok(caly_config::profile_fetch::ProfileFetchOutcome::Updated { body }) => {
                store.write(profile.id.as_str(), &body, url, current_unix_ms())?;
                return Ok(());
            }
            Ok(caly_config::profile_fetch::ProfileFetchOutcome::NotModified) => {
                // ETag matched; the body on disk is still the
                // truth. Re-write the metadata so the operator
                // sees a fresh `fetched_at_ms` without touching
                // the body.
                let cached = store.read(profile.id.as_str())?.unwrap_or_default();
                store.write(profile.id.as_str(), &cached, url, current_unix_ms())?;
                return Ok(());
            }
            Err(error) if is_transient_profile_error(&error) && attempt + 1 < 2 => {
                last_transient = Some(error);
                std::thread::sleep(std::time::Duration::from_millis(250));
            }
            Err(error) => return Err(ProfileCmdError::Fetch(error)),
        }
    }
    Err(ProfileCmdError::Fetch(
        last_transient.unwrap_or(ProfileFetchError::ClientBuild),
    ))
}

/// Appends a new `ProfileConfig` to the operator's
/// `<config>/config.yaml`. The base config is parsed, validated,
/// and re-emitted with the new entry; the layout is preserved
/// (the existing top-level order is kept). `Local` source kinds
/// must already point at a file the operator owns; this function
/// does not materialise the body.
///
/// `dry_run` builds the new `AppConfig` and runs every check
/// (uniqueness, path safety, validation) but does **not**
/// write to disk. The caller surfaces the result so the CLI
/// can print "would have added profile `x`" without touching
/// the operator's file.
pub fn add_profile(
    paths: &AppPaths,
    id: &str,
    source: ProfileSourceKind,
    dry_run: bool,
) -> Result<ProfileWriteOutcome, ProfileCmdError> {
    if !is_path_safe_component(id) {
        return Err(ProfileCmdError::InvalidId(id.to_owned()));
    }
    let (config, _store) = load_declared_profiles(paths)?;
    if find_declared(&config, id).is_some() {
        return Err(ProfileCmdError::AlreadyDeclared(id.to_owned()));
    }
    let entry = build_profile_config(id, source);
    if dry_run {
        return Ok(ProfileWriteOutcome::DryRun);
    }
    backup_config(&paths.config.join("config.yaml"))?;
    mutate_profiles_in_config(&paths.config.join("config.yaml"), |current| {
        let mut next = current.to_vec();
        next.push(entry);
        Ok(next)
    })?;
    Ok(ProfileWriteOutcome::Applied)
}

/// Removes a profile from `config.yaml` and clears its cache.
/// When `dry_run` is set, the call validates and prints
/// "would have removed profile `x`" without touching the
/// file.
pub fn remove_profile(
    paths: &AppPaths,
    id: &str,
    dry_run: bool,
) -> Result<ProfileWriteOutcome, ProfileCmdError> {
    if !is_path_safe_component(id) {
        return Err(ProfileCmdError::InvalidId(id.to_owned()));
    }
    let (config, store) = load_declared_profiles(paths)?;
    if find_declared(&config, id).is_none() {
        return Err(ProfileCmdError::NotDeclared(id.to_owned()));
    }
    if dry_run {
        return Ok(ProfileWriteOutcome::DryRun);
    }
    backup_config(&paths.config.join("config.yaml"))?;
    store.remove(id)?;
    let target = id.to_owned();
    mutate_profiles_in_config(&paths.config.join("config.yaml"), |current| {
        Ok(current.iter().filter(|entry| entry.id != target).cloned().collect())
    })?;
    Ok(ProfileWriteOutcome::Applied)
}

/// Flips the `enabled` flag on a declared profile. The
/// schema default is `enabled: true` (Round 15 added the
/// field), so `enable` is a no-op for a fresh entry and
/// `disable` is the meaningful state transition.
///
/// Round 30: the `apply: bool` parameter was added so
/// the dry-run path lives in the writer (matching the
/// pre-Round-22 contract that all 5 profile writers
/// accept a dry-run flag). Pre-Round 30 the dispatch
/// inlined the dry-run validation: it duplicated the
/// path-safety check, the load, the existence scan, and
/// the `CliError::new(…)` construction — a 60-line
/// dry-run shape that mirrored the apply path but lived
/// in a separate code path. Folding the dry-run branch
/// into the writer removes the duplication: the
/// writer's single existence scan now drives both the
/// apply and the dry-run outcome, and the dispatch's
/// `set_enabled_dispatch` collapses to a 1-line
/// `run_writer` call.
pub fn set_profile_enabled(
    paths: &AppPaths,
    id: &str,
    enabled: bool,
    apply: bool,
) -> Result<ProfileWriteOutcome, ProfileCmdError> {
    if !is_path_safe_component(id) {
        return Err(ProfileCmdError::InvalidId(id.to_owned()));
    }
    let (config, _store) = load_declared_profiles(paths)?;
    if find_declared(&config, id).is_none() {
        return Err(ProfileCmdError::NotDeclared(id.to_owned()));
    }
    if !apply {
        return Ok(ProfileWriteOutcome::DryRun);
    }
    let target = id.to_owned();
    mutate_profiles_in_config(&paths.config.join("config.yaml"), |current| {
        Ok(current
            .iter()
            .map(|entry| {
                let mut entry = entry.clone();
                if entry.id == target {
                    entry.enabled = enabled;
                }
                entry
            })
            .collect())
    })?;
    Ok(ProfileWriteOutcome::Applied)
}

/// Round 16: spawn `$EDITOR` (or `vi` as a fallback) with
/// the current cached body as the starting content, then
/// write the result back to the cache. Returns
/// `ProfileCmdError::NotDeclared` if the profile has no
/// cached body yet (the operator must `set profile refresh`
/// first).
///
/// `apply: false` is a no-op (the dry-run path); the editor
/// is never spawned and the cache is never touched.
pub fn edit_profile(
    paths: &AppPaths,
    id: &str,
    apply: bool,
) -> Result<ProfileWriteOutcome, ProfileCmdError> {
    if !is_path_safe_component(id) {
        return Err(ProfileCmdError::InvalidId(id.to_owned()));
    }
    let (config, store) = load_declared_profiles(paths)?;
    if find_declared(&config, id).is_none() {
        return Err(ProfileCmdError::NotDeclared(id.to_owned()));
    }
    if !apply {
        return Ok(ProfileWriteOutcome::DryRun);
    }
    let body = store
        .read(id)?
        .ok_or_else(|| ProfileCmdError::Store(ProfileStoreError::Io(
            std::io::Error::new(
                std::io::ErrorKind::NotFound,
                format!("profile `{id}` has no cached body; run `set profile refresh` first"),
            ),
        )))?;
    let editor = std::env::var("EDITOR").unwrap_or_else(|_| "vi".to_owned());
    let tmp = std::env::temp_dir().join(format!("caly-profile-{id}-{}.yaml", std::process::id()));
    std::fs::write(&tmp, &body)
        .map_err(|e| ProfileCmdError::Store(ProfileStoreError::Io(e)))?;
    let status = std::process::Command::new(&editor)
        .arg(&tmp)
        .status()
        .map_err(|error| {
            ProfileCmdError::Store(ProfileStoreError::Io(std::io::Error::other(
                format!("cannot spawn editor `{editor}`: {error}"),
            )))
        })?;
    if !status.success() {
        let _ = std::fs::remove_file(&tmp);
        return Err(ProfileCmdError::Store(ProfileStoreError::Io(
            std::io::Error::other(format!("editor `{editor}` exited with {status}")),
        )));
    }
    let new_body = std::fs::read(&tmp)
        .map_err(|e| ProfileCmdError::Store(ProfileStoreError::Io(e)))?;
    let _ = std::fs::remove_file(&tmp);
    let url = store
        .read_metadata(id)?
        .map(|m| m.url)
        .unwrap_or_default();
    let now_ms = current_unix_ms();
    store.write(id, &new_body, &url, now_ms)?;
    Ok(ProfileWriteOutcome::Applied)
}

/// Round 16: write the current cached body to `<out>`.
/// Returns `ProfileCmdError::NotDeclared` if the profile
/// has no cached body yet.
///
/// Round 22: returns [`ProfileWriteOutcome`] so the
/// dispatch can route `export` through the same
/// `run_writer` envelope as the other verbs. `export`
/// has no dry-run path (the operation is either the
/// write or an error), so the writer always returns
/// `Applied` on success.
pub fn export_profile(
    paths: &AppPaths,
    id: &str,
    out: &Path,
) -> Result<ProfileWriteOutcome, ProfileCmdError> {
    if !is_path_safe_component(id) {
        return Err(ProfileCmdError::InvalidId(id.to_owned()));
    }
    let (_config, store) = load_declared_profiles(paths)?;
    let body = store
        .read(id)?
        .ok_or_else(|| ProfileCmdError::Store(ProfileStoreError::Io(
            std::io::Error::new(
                std::io::ErrorKind::NotFound,
                format!("profile `{id}` has no cached body; run `set profile refresh` first"),
            ),
        )))?;
    if let Some(parent) = out.parent() {
        std::fs::create_dir_all(parent)
            .map_err(|e| ProfileCmdError::Store(ProfileStoreError::Io(e)))?;
    }
    std::fs::write(out, &body)
        .map_err(|e| ProfileCmdError::Store(ProfileStoreError::Io(e)))?;
    Ok(ProfileWriteOutcome::Applied)
}

/// Refreshes the cache for every `kind: remote` profile.
/// `Merge` profiles are walked depth-first: each `Remote`
/// `parts` entry is refreshed before the merge itself, and
/// a single failing dependency surfaces as
/// [`ProfileCmdError::FetchChain`] with the offending id.
/// `Local` profiles are no-ops.
pub fn refresh_all(paths: &AppPaths, id: Option<&str>) -> Result<usize, ProfileCmdError> {
    let (config, store) = load_declared_profiles(paths)?;
    if let Some(target) = id {
        if !config.profiles.iter().any(|profile| profile.id == target) {
            return Err(ProfileCmdError::NotDeclared(target.to_owned()));
        }
        // Single-target refresh path: walk the (possible)
        // merge tree so a `Merge` `target` triggers a full
        // chain refresh. The outermost id is `target`
        // itself; a nested failure surfaces with
        // `FetchChain { id: target, source: ... }`.
        let mut visited: std::collections::HashSet<String> = std::collections::HashSet::new();
        let count = refresh_recursive(&config, &store, target, target, &mut visited)?;
        return Ok(count);
    }
    let mut visited: std::collections::HashSet<String> = std::collections::HashSet::new();
    let mut count = 0;
    for profile in &config.profiles {
        if !matches!(profile.source, ProfileSourceConfig::Remote { .. }) {
            continue;
        }
        refresh_recursive(&config, &store, &profile.id, &profile.id, &mut visited)?;
        count += 1;
    }
    Ok(count)
}

/// Recursive depth-first refresh. Walks `Merge` parts
/// recursively, fetches `Remote` bodies through the
/// SSRF-safe pipeline, and skips `Local` profiles (they
/// are always-fresh). Returns the number of `Remote`
/// profiles fetched (a `Merge` itself is a no-op for
/// the fetcher). `visited` breaks cycles for malformed
/// merge trees (the schema validator already rejects
/// them, but the runtime guard is independent).
///
/// A single failing dependency surfaces as
/// [`ProfileCmdError::FetchChain`] with the **outermost
/// merge** id (the user's declared entry point into
/// the merge tree). The internal recursion passes the
/// outermost id through every nested frame, so a
/// three-level merge `outer → inner → leaf-bad` labels
/// the error with `outer`, not `inner`. The operator
/// identifies which declared `Merge` reached into the
/// broken dependency at a glance, without walking the
/// parts tree.
fn refresh_recursive(
    config: &AppConfig,
    store: &ProfileStore,
    id: &str,
    outer_id: &str,
    visited: &mut std::collections::HashSet<String>,
) -> Result<usize, ProfileCmdError> {
    if !visited.insert(id.to_owned()) {
        return Ok(0);
    }
    let Some(profile) = find_declared(config, id) else {
        return Err(ProfileCmdError::NotDeclared(id.to_owned()));
    };
    let source = profile.source.clone();
    match &source {
        ProfileSourceConfig::Local { .. } => Ok(0),
        ProfileSourceConfig::Remote { .. } => {
            let domain = profile.to_domain().map_err(ProfileCmdError::ParseConfig)?;
            refresh_one(store, &domain)?;
            Ok(1)
        }
        ProfileSourceConfig::Merge { parts } => {
            // Refresh every `Remote` (and recursively, every
            // nested `Merge`) before declaring the merge done.
            // `Local` parts are always-fresh; skip them.
            //
            // The `outer_id` is threaded unchanged through the
            // recursion so any error surfaced from a nested
            // frame is attributed to the user-visible entry
            // point (the outermost declared `Merge`).
            let mut fetched = 0;
            for part in parts {
                match refresh_recursive(config, store, part, outer_id, visited) {
                    Ok(n) => fetched += n,
                    Err(error) => {
                        return Err(match error {
                            ProfileCmdError::Fetch(source) => ProfileCmdError::FetchChain {
                                id: outer_id.to_owned(),
                                source,
                            },
                            other => other,
                        });
                    }
                }
            }
            Ok(fetched)
        }
    }
}

fn build_profile_config(id: &str, source: ProfileSourceKind) -> ProfileConfig {
    let source_config = match source {
        ProfileSourceKind::Local { path } => ProfileSourceConfig::Local { path },
        ProfileSourceKind::Remote {
            url,
            interval_minutes,
        } => ProfileSourceConfig::Remote {
            url,
            interval_minutes,
        },
        ProfileSourceKind::Merge { parts } => ProfileSourceConfig::Merge { parts },
    };
    ProfileConfig {
        id: id.to_owned(),
        name: None,
        description: None,
        source: source_config,
        enabled: true,
    }
}

/// Mutates the `profiles:` list in `<config>/config.yaml` through
/// a single canonical read → parse → mutate → write pipeline.
///
/// `mutator` is called with the current `Vec<ProfileConfig>` and
/// returns the desired next list (the contract is "produce the
/// new state" rather than "mutate in place" so the function can
/// validate the result with the schema before writing). The
/// file's top-level layout (other top-level keys, key order) is
/// preserved; only the `profiles:` list is touched.
///
/// `profiles:` is auto-created as an empty list when missing, so
/// the operator's first `add` works on a fresh install.
///
/// Round 21 note: the profile writer keeps its own
/// bespoke mutator because [`ProfileCmdError::Backup`]
/// carries the source / destination paths in a
/// `ProfileCmdError` shape the shared
/// [`super::resource_writer::ResourceError`] doesn't
/// model; the file-I/O / atomic-rename cycle is otherwise
/// identical to the shared primitive. A future round
/// can extend `ResourceError` to carry a path / reason
/// payload so the profile writer can route through
/// `mutate_list` too.
fn mutate_profiles_in_config<F>(
    config_path: &Path,
    mutator: F,
) -> Result<(), ProfileCmdError>
where
    F: FnOnce(&[ProfileConfig]) -> Result<Vec<ProfileConfig>, ProfileCmdError>,
{
    let bytes = fs::read(config_path)
        .map_err(|error| ProfileCmdError::ReadConfig(error.to_string()))?;
    let mut value: serde_norway::Value = serde_norway::from_slice(&bytes)
        .map_err(|error| ProfileCmdError::ParseConfig(error.to_string()))?;
    let mapping = value
        .as_mapping_mut()
        .ok_or_else(|| ProfileCmdError::ParseConfig("config root must be a mapping".to_owned()))?;
    let key = serde_norway::Value::String("profiles".to_owned());
    // Pull the current profiles out of the YAML. The
    // `deny_unknown_fields` policy and bounded constants are
    // re-checked when the new list is serialised back, so a
    // hand-edited file with a broken `profiles:` value fails
    // here before the rewrite.
    let current: Vec<ProfileConfig> = match mapping.get(&key) {
        Some(serde_norway::Value::Sequence(_)) => serde_norway::from_value(mapping[&key].clone())
            .map_err(|error| ProfileCmdError::ParseConfig(error.to_string()))?,
        Some(_) => {
            return Err(ProfileCmdError::ParseConfig(
                "`profiles:` must be a list".to_owned(),
            ));
        }
        None => Vec::new(),
    };
    let next = mutator(&current)?;
    let rendered: serde_norway::Value = serde_norway::to_value(&next)
        .map_err(|error| ProfileCmdError::ParseConfig(error.to_string()))?;
    mapping.insert(key, rendered);
    let serialized = serde_norway::to_string(&value)
        .map_err(|error| ProfileCmdError::ParseConfig(error.to_string()))?;
    fs::write(config_path, serialized)
        .map_err(|error| ProfileCmdError::ReadConfig(error.to_string()))?;
    Ok(())
}

/// Copies `config_path` to a single `config.yaml.bak`
/// sidecar before any destructive operation. Wraps the
/// shared [`super::config_writer::backup_config_yaml`] with
/// the profile-specific [`ProfileCmdError::Backup`]
/// variant so the operator can read the source /
/// destination paths off the failure envelope.
///
/// The shared helper returns
/// [`super::config_writer::ConfigWriteError::Write`] on
/// `fs::copy` failure, which carries the same path +
/// reason payload; the profile writer surfaces the same
/// shape through its own error so a future
/// `From<ConfigWriteError> for ProfileCmdError` lift can
/// drop this wrapper.
fn backup_config(config_path: &Path) -> Result<(), ProfileCmdError> {
    if !config_path.is_file() {
        // A fresh install: no prior config to back up. The
        // caller is creating a brand-new file, so a backup
        // would be a no-op anyway.
        return Ok(());
    }
    let backup = config_path.with_extension("yaml.bak");
    fs::copy(config_path, &backup).map_err(|error| ProfileCmdError::Backup {
        from: config_path.to_path_buf(),
        to: backup,
        reason: error.to_string(),
    })?;
    Ok(())
}
