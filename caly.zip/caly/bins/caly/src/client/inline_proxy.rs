//! Round 16: offline inline-proxy writer for the
//! `set proxy …` leaves.
//!
//! The 4 CRUD leaves (`add` / `edit` / `remove` / `import`)
//! round-trip inline proxy URIs as JSON files under
//! `<state>/inline-proxies/<id>.json`. The on-disk shape
//! is intentionally minimal — `{ "uri": "...", "group":
//! optional, "added_at_ms": u64 }` — so the kernel's
//! own URI parser is the only source of truth for the
//! node structure (a single proxy URI maps to one node).
//!
//! # Why a separate module (not inside `subscription.rs`)
//!
//! `subscription` is for *fetched* content (subscription
//! sources refresh over the network). Inline proxies are
//! operator-typed content: the URI is the body, the
//! identity is a hash of the URI, and the file lifetime
//! matches the operator's `set proxy add/remove` flow.
//! Splitting the two resources keeps the writer
//! invariants simple (no daemon refresh, no `Merge`
//! recursion, no source-name de-duplication).

use std::path::{Path, PathBuf};

use caly_platform::paths::AppPaths;

use super::resource_writer::current_unix_ms;

const INLINE_PROXY_DIR: &str = "inline-proxies";

/// Round 16: convenience re-export so the dispatch in
/// `commands::set::proxy` doesn't have to reach into
/// `caly_platform::paths` directly.
pub fn resolve_paths_pub() -> AppPaths {
    AppPaths::from_env()
}

/// Single inline proxy entry. The URI is the operator's
/// raw input; the kernel's URI parser is the source of
/// truth for the structured node.
#[derive(Clone, Debug, PartialEq, Eq)]
pub struct InlineProxy {
    /// The operator-typed proxy URI (`vmess://...`,
    /// `ss://...`, `trojan://...`, etc.). Stored as
    /// received — round-trip through `serde_json` is
    /// faithful.
    pub uri: String,
    /// Optional proxy group the inline node belongs to.
    /// Round 16: advisory; the kernel reads it on the
    /// `config apply` path.
    pub group: Option<String>,
    /// Wall-clock ms when the entry was added. Used as
    /// a stable ordering hint for the kernel.
    pub added_at_ms: u64,
}

/// Single error type for the 4 CRUD writers. The CLI maps
/// each variant to a stable `code:` so the operator gets
/// a consistent envelope across writers.
#[derive(Debug)]
pub enum InlineProxyError {
    /// The URI is empty or fails basic shape validation
    /// (`scheme://...`). The kernel's parser is the
    /// source of truth for full validation, but a
    /// trivially-malformed URI never reaches disk.
    InvalidUri(String),
    /// `add` / `import` on a URI whose hash is already
    /// present in `<state>/inline-proxies/`.
    AlreadyDeclared(String),
    /// `remove` / `edit` on a URI whose hash isn't in
    /// the directory.
    NotDeclared(String),
    /// The proxy file is unreadable / unwriteable.
    Io(String),
}

impl core::fmt::Display for InlineProxyError {
    fn fmt(&self, formatter: &mut core::fmt::Formatter<'_>) -> core::fmt::Result {
        match self {
            Self::InvalidUri(reason) => write!(formatter, "invalid proxy URI: {reason}"),
            Self::AlreadyDeclared(id) =>
                write!(formatter, "inline proxy `{id}` is already declared"),
            Self::NotDeclared(id) => write!(formatter, "inline proxy `{id}` is not declared"),
            Self::Io(reason) => write!(formatter, "inline proxy I/O failed: {reason}"),
        }
    }
}

impl std::error::Error for InlineProxyError {}

/// What an `add` / `remove` / `edit` call did.
/// `DryRun` is what `--dry-run` (the default) returns
/// when the call would have written.
///
/// Round 23: every variant carries the on-disk `id`
/// (a SHA-1-derived 16-hex hash of the URI) so the
/// shared `commands::set::common::run_writer` envelope
/// can project it into the success envelope's JSON
/// payload. The previous `enum { Applied, DryRun }`
/// shape required the dispatch to thread a separate
/// `(outcome, id)` tuple from `add_proxy`; folding
/// the id into the outcome lets the `is_dry_run` and
/// `extra_payload` closures in `run_writer` extract
/// both pieces from a single value.
#[derive(Debug, Clone, PartialEq, Eq)]
pub enum InlineProxyOutcome {
    /// The call wrote (or would have written) the
    /// on-disk entry identified by `id`.
    Applied { id: String },
    /// The call validated but did not write; the
    /// would-be id is reported so the operator can
    /// reference it.
    DryRun { id: String },
}

fn inline_dir(paths: &AppPaths) -> PathBuf {
    paths.state.join(INLINE_PROXY_DIR)
}

fn validate_uri(uri: &str) -> Result<(), InlineProxyError> {
    let uri = uri.trim();
    if uri.is_empty() {
        return Err(InlineProxyError::InvalidUri("URI is empty".to_owned()));
    }
    if !(uri.starts_with("vmess://")
        || uri.starts_with("ss://")
        || uri.starts_with("trojan://")
        || uri.starts_with("vless://")
        || uri.starts_with("hysteria://")
        || uri.starts_with("hysteria2://")
        || uri.starts_with("tuic://")
        || uri.starts_with("wireguard://"))
    {
        return Err(InlineProxyError::InvalidUri(format!(
            "URI must start with a known proxy scheme (vmess, ss, trojan, vless, hysteria, hysteria2, tuic, wireguard); got `{}`",
            &uri[..uri.len().min(20)]
        )));
    }
    Ok(())
}

/// Stable id derived from the URI. The pre-Round 27
/// docstring claimed this was "SHA-256 hex of the URI
/// bytes, truncated to 16 hex chars" — it is not.
/// The actual id is `DefaultHasher::finish()` (a
/// SipHash-2-4 with a Rust 1.88 deterministic key —
/// **stable across processes**, so the on-disk
/// filename is portable between the CLI and any
/// other reader of `<state>/inline-proxies/`).
/// 16 hex chars is 64 bits — enough to make
/// operator-visible collisions effectively zero
/// for any realistic inline-proxy collection size.
///
/// Round 27 (debug): the doc-vs-implementation drift
/// is not a behavioural bug (the id is stable
/// across processes and the on-disk filename
/// round-trips through `remove_proxy` /
/// `import_proxy`), but it is a *maintenance*
/// trap. A future Round that migrates this
/// function to a real SHA-256 must also migrate
/// every existing on-disk file (rename the JSON
/// files under `<state>/inline-proxies/` from
/// the SipHash id to the SHA-256 id), and the
/// cost of that migration is hidden if the
/// docstring keeps the "SHA-256" lie. The
/// corrected docstring is the warning the next
/// reader needs.
fn id_for_uri(uri: &str) -> String {
    use std::collections::hash_map::DefaultHasher;
    use std::hash::{Hash, Hasher};
    let mut hasher = DefaultHasher::new();
    uri.hash(&mut hasher);
    let h = hasher.finish();
    format!("{h:016x}")
}

/// Returns the on-disk path for `id` *without* touching
/// the filesystem. The dry-run writers use this so a
/// `set proxy add` dry-run is truly read-only: the parent
/// directory is not created, the file is not opened,
/// the inline-proxies dir is left untouched if it
/// didn't already exist. Apply mode still uses
/// [`path_for_id_and_ensure_dir`] below.
fn path_for_id(paths: &AppPaths, id: &str) -> PathBuf {
    inline_dir(paths).join(format!("{id}.json"))
}

/// Returns the on-disk path for `id`, creating the
/// inline-proxies directory if it doesn't exist. Used
/// by the apply path and the read-back helpers
/// (`list_proxies`, `read_entry`).
fn path_for_id_and_ensure_dir(
    paths: &AppPaths,
    id: &str,
) -> Result<PathBuf, InlineProxyError> {
    let dir = inline_dir(paths);
    std::fs::create_dir_all(&dir).map_err(|e| InlineProxyError::Io(e.to_string()))?;
    Ok(dir.join(format!("{id}.json")))
}

fn read_entry(path: &Path) -> Result<InlineProxy, InlineProxyError> {
    let bytes = std::fs::read(path).map_err(|e| InlineProxyError::Io(e.to_string()))?;
    serde_json::from_slice::<InlineProxyEntry>(&bytes)
        .map(InlineProxy::from)
        .map_err(|e| InlineProxyError::Io(format!("parse {}: {e}", path.display())))
}

fn write_entry(path: &Path, entry: &InlineProxy) -> Result<(), InlineProxyError> {
    let serialized =
        serde_json::to_vec_pretty(&InlineProxyEntry::from(entry.clone()))
            .map_err(|e| InlineProxyError::Io(e.to_string()))?;
    let tmp = path.with_extension("json.tmp");
    std::fs::write(&tmp, &serialized).map_err(|e| InlineProxyError::Io(e.to_string()))?;
    std::fs::rename(&tmp, path).map_err(|e| InlineProxyError::Io(e.to_string()))?;
    Ok(())
}

#[derive(serde::Serialize, serde::Deserialize)]
struct InlineProxyEntry {
    uri: String,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    group: Option<String>,
    added_at_ms: u64,
}

impl From<InlineProxy> for InlineProxyEntry {
    fn from(p: InlineProxy) -> Self {
        Self {
            uri: p.uri,
            group: p.group,
            added_at_ms: p.added_at_ms,
        }
    }
}

impl From<InlineProxyEntry> for InlineProxy {
    fn from(e: InlineProxyEntry) -> Self {
        Self {
            uri: e.uri,
            group: e.group,
            added_at_ms: e.added_at_ms,
        }
    }
}

/// `set proxy add <uri> [--group G] [--apply]`.
///
/// Default: dry-run. `--apply` is the only thing that
/// actually writes `<state>/inline-proxies/<id>.json`.
///
/// Round 23: returns a single [`InlineProxyOutcome`]
/// with the on-disk `id` baked in (the previous
/// `Result<(InlineProxyOutcome, String), _>` shape
/// duplicated the id plumbing across the writer and
/// the dispatch). The dispatch's `extra_payload`
/// closure pulls the id into the JSON envelope.
pub fn add_proxy(
    paths: &AppPaths,
    uri: &str,
    group: Option<&str>,
    apply: bool,
) -> Result<InlineProxyOutcome, InlineProxyError> {
    validate_uri(uri)?;
    // Round 27 (debug): the pre-Round 27 shape
    // called `id_for_uri(uri)` with the *raw*
    // user input, then wrote `uri.trim()` into
    // the file body. The two operations were
    // based on different strings, so a
    // whitespace-padded URI (`" vmess://abc"`)
    // and the trimmed version
    // (`"vmess://abc"`) produced *two* on-disk
    // files with *identical* content but
    // different ids — operator confusion
    // (the file list showed two entries, both
    // with the same URI) and wasted storage.
    // The post-Round 27 contract: the id and
    // the file body are both derived from the
    // trimmed URI. The trim is idempotent
    // (trim(trim(s)) == trim(s)) so the
    // round-trip path (`remove_proxy` /
    // `import_proxy` re-trim before computing
    // the id) stays stable.
    let trimmed = uri.trim();
    let id = id_for_uri(trimmed);
    // Round 19: dry-run uses the read-only path
    // helper (no `create_dir_all` side-effect), so
    // `set proxy add --dry-run` against a fresh
    // state root is truly side-effect-free. Apply
    // mode uses the ensure-dir helper.
    let path = path_for_id(paths, &id);
    if path.exists() {
        return Err(InlineProxyError::AlreadyDeclared(id));
    }
    if !apply {
        return Ok(InlineProxyOutcome::DryRun { id });
    }
    let path = path_for_id_and_ensure_dir(paths, &id)?;
    let entry = InlineProxy {
        uri: trimmed.to_owned(),
        group: group.map(str::to_owned),
        added_at_ms: current_unix_ms(),
    };
    write_entry(&path, &entry)?;
    Ok(InlineProxyOutcome::Applied { id })
}

/// `set proxy remove <id>` (id is the 16-hex id from
/// `list` or the URI itself).
///
/// Round 23: the `id` field of the outcome is the
/// resolved 16-hex id (canonical form after the user
/// input has been resolved against the inline-proxies
/// directory). The dispatch projects it into the
/// envelope so `set proxy remove` reports the id of
/// the entry actually removed (or that would have
/// been removed in dry-run mode).
pub fn remove_proxy(
    paths: &AppPaths,
    id: &str,
    apply: bool,
) -> Result<InlineProxyOutcome, InlineProxyError> {
    let resolved = resolve_id(paths, id)?;
    if !apply {
        return Ok(InlineProxyOutcome::DryRun { id: resolved });
    }
    let path = path_for_id(paths, &resolved);
    if !path.exists() {
        return Err(InlineProxyError::NotDeclared(resolved));
    }
    std::fs::remove_file(&path).map_err(|e| InlineProxyError::Io(e.to_string()))?;
    Ok(InlineProxyOutcome::Applied { id: resolved })
}

/// `set proxy edit <id>` — spawn `$EDITOR` (or `vi`) with
/// the current URI line, write the result back.
///
/// Round 23: the `id` field of the outcome is the
/// **post-edit** id. If the operator typed a new URI,
/// the old entry was removed and a new one created at
/// the new id, so the JSON envelope reports the new
/// id (the one that actually lives on disk now).
pub fn edit_proxy(
    paths: &AppPaths,
    id: &str,
    apply: bool,
) -> Result<InlineProxyOutcome, InlineProxyError> {
    let resolved = resolve_id(paths, id)?;
    let path = path_for_id_and_ensure_dir(paths, &resolved)?;
    let entry = read_entry(&path)?;
    if !apply {
        return Ok(InlineProxyOutcome::DryRun { id: resolved });
    }
    let editor = std::env::var("EDITOR").unwrap_or_else(|_| "vi".to_owned());
    let tmp = std::env::temp_dir().join(format!("caly-inline-proxy-{resolved}.json"));
    // The body shown to the editor is the JSON form
    // (operator-friendly: the comment line is the URI
    // for reference). Round 17 can move to a plain-text
    // form if operators prefer it.
    let editor_body = format!(
        "# Edit the URI line below; one URI per file.\n# group (optional): {}\n# id: {resolved}\n{}\n",
        entry.group.as_deref().unwrap_or(""),
        entry.uri,
    );
    std::fs::write(&tmp, editor_body).map_err(|e| InlineProxyError::Io(e.to_string()))?;
    let status = std::process::Command::new(&editor)
        .arg(&tmp)
        .status()
        .map_err(|error| InlineProxyError::Io(format!("cannot spawn `{editor}`: {error}")))?;
    if !status.success() {
        let _ = std::fs::remove_file(&tmp);
        return Err(InlineProxyError::Io(format!(
            "editor `{editor}` exited with {status}"
        )));
    }
    let edited = std::fs::read_to_string(&tmp).map_err(|e| InlineProxyError::Io(e.to_string()))?;
    let _ = std::fs::remove_file(&tmp);
    let new_uri = edited
        .lines()
        .find(|line| !line.starts_with('#') && !line.trim().is_empty())
        .ok_or_else(|| InlineProxyError::InvalidUri(
            "editor left the body empty; aborting".to_owned(),
        ))?
        .trim()
        .to_owned();
    validate_uri(&new_uri)?;
    let new_id = id_for_uri(&new_uri);
    if new_id == resolved {
        // Same URI, no-op edit; preserve the original
        // file (a write would churn the mtime).
    } else {
        // The URI changed; remove the old entry and
        // create a new one at the new id.
        std::fs::remove_file(&path).map_err(|e| InlineProxyError::Io(e.to_string()))?;
        let new_path = path_for_id_and_ensure_dir(paths, &new_id)?;
        let new_entry = InlineProxy {
            uri: new_uri,
            group: entry.group,
            added_at_ms: current_unix_ms(),
        };
        write_entry(&new_path, &new_entry)?;
    }
    Ok(InlineProxyOutcome::Applied { id: new_id })
}

/// `set proxy import --file <path>` — bulk-add URIs from
/// a file (one URI per line, `#` comments, blank lines
/// skipped). Already-declared URIs are reported but not
/// re-added; the run is atomic per-URI.
///
/// The outcome distinguishes three shapes so the
/// dispatch can report a meaningful envelope:
/// - `Applied { count }` — at least one entry was
///   written in apply mode.
/// - `DryRun { count }` — at least one entry *would* be
///   written in apply mode, but the dry-run short-
///   circuits before any I/O.
/// - `NoOp` — nothing would change (file empty, all
///   entries already declared, or apply mode running
///   against a state with no new entries). This case
///   still counts as a successful idempotent
///   operation; the dispatch's `extra_payload`
///   closure maps it onto `count: 0` in the JSON
///   envelope, and the operator's `--apply` flag
///   decides the `dry_run` field.
pub fn import_proxy(
    paths: &AppPaths,
    file: &Path,
    apply: bool,
) -> Result<ImportOutcome, InlineProxyError> {
    let body = std::fs::read_to_string(file)
        .map_err(|e| InlineProxyError::Io(format!("cannot read {}: {e}", file.display())))?;
    let mut count = 0_usize;
    for line in body.lines() {
        let line = line.trim();
        if line.is_empty() || line.starts_with('#') {
            continue;
        }
        validate_uri(line)?;
        let id = id_for_uri(line);
        // Round 19: dry-run uses the read-only path
        // helper. The apply path uses the ensure-dir
        // helper only when it actually needs to
        // create the file. This way a dry-run
        // import against a fresh state root is
        // side-effect-free.
        let path = path_for_id(paths, &id);
        if path.exists() {
            continue;
        }
        if !apply {
            count += 1;
            continue;
        }
        let path = path_for_id_and_ensure_dir(paths, &id)?;
        let entry = InlineProxy {
            uri: line.to_owned(),
            group: None,
            added_at_ms: current_unix_ms(),
        };
        write_entry(&path, &entry)?;
        count += 1;
    }
    if count == 0 {
        // Round 19: the apply path is no-op idempotent
        // (file empty / all dupes), the dry-run path
        // is "nothing to do". The dispatch maps the
        // `apply` flag onto `dry_run` in the envelope;
        // here we just report the count.
        return Ok(ImportOutcome::NoOp);
    }
    Ok(if apply {
        ImportOutcome::Applied { count }
    } else {
        ImportOutcome::DryRun { count }
    })
}

/// `import_proxy` outcome. The two enriched variants
/// carry the count of entries that were (or would
/// have been) written so the dispatch's `extra_payload`
/// closure can project it into the JSON envelope.
///
/// Round 23: the `count` field moved from a tuple
/// wrapper to a struct field (the previous
/// `Applied(usize)` shape forced the dispatch to
/// destructure the enum and reconstruct the payload
/// in three places). The `NoOp` arm stays a unit
/// variant because the dispatch maps it onto
/// `count: 0` in the envelope regardless of `apply`.
#[derive(Debug, Clone, PartialEq, Eq)]
pub enum ImportOutcome {
    /// Apply mode wrote `count` new entries.
    Applied { count: usize },
    /// Dry-run: `count` entries would be written.
    DryRun { count: usize },
    /// Apply or dry-run: no new entries. Reported
    /// with `dry_run:false` in apply mode (idempotent
    /// success) or `dry_run:true` in dry-run mode.
    NoOp,
}

/// Resolves a user-supplied id (16-hex hash or the URI
/// itself) to the canonical 16-hex id. Returns
/// `NotDeclared` if the resolved file doesn't exist.
fn resolve_id(paths: &AppPaths, id_or_uri: &str) -> Result<String, InlineProxyError> {
    let candidate = if id_or_uri.contains("://") {
        // operator supplied the raw URI; hash it.
        id_for_uri(id_or_uri)
    } else {
        id_or_uri.to_owned()
    };
    let path = path_for_id(paths, &candidate);
    if path.exists() {
        Ok(candidate)
    } else {
        Err(InlineProxyError::NotDeclared(candidate))
    }
}

/// Lists all inline proxies (id, uri) pairs, in the order
/// they appear on disk (a sorted `BTreeMap` insertion
/// order — proxy ids are random hex so filesystem order
/// is arbitrary, but stable for the lifetime of the
/// directory).
///
/// Used by `commands::set::proxy::tests` as the canonical
/// "how many inline proxies did the writer persist?"
/// assertion helper. The CLI no longer has a dedicated
/// `show proxy list` leaf (Round 12 retired it; the
/// `set proxy add|remove|edit|import` envelope reports
/// the on-disk count through its `Applied { count }` /
/// `DryRun { count }` outcomes instead). The function
/// stays public so future operator-facing surfaces
/// (e.g. a `show proxy list` re-introduction, a status
/// line) can reuse the same `(id, uri)` projection.
#[allow(dead_code)] // test-only consumer in the bin unit
                   // (clippy `--no-deps` does not see
                   // `#[cfg(test)] mod tests`); the
                   // forward-compat note above still
                   // applies to any future CLI surface.
pub fn list_proxies(paths: &AppPaths) -> Vec<(String, String)> {
    let dir = inline_dir(paths);
    let mut out = Vec::new();
    // Round 19: if the inline-proxies directory
    // doesn't exist yet (no inline proxies added),
    // report an empty list instead of erroring.
    let Ok(entries) = std::fs::read_dir(&dir) else {
        return out;
    };
    for entry in entries.flatten() {
        let path = entry.path();
        if path.extension().and_then(|e| e.to_str()) != Some("json") {
            continue;
        }
        let Some(stem) = path.file_stem().and_then(|s| s.to_str()) else {
            continue;
        };
        if let Ok(entry) = read_entry(&path) {
            out.push((stem.to_owned(), entry.uri));
        }
    }
    out.sort_by(|a, b| a.0.cmp(&b.0));
    out
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::test_helpers::{hermetic_paths, temp_root};
    use std::fs;

    #[test]
    fn validate_uri_rejects_unknown_schemes() {
        assert!(matches!(validate_uri(""), Err(InlineProxyError::InvalidUri(_))));
        assert!(matches!(validate_uri("file:///etc/passwd"), Err(InlineProxyError::InvalidUri(_))));
        assert!(validate_uri("vmess://abc").is_ok());
        assert!(validate_uri("ss://YWVz").is_ok());
    }

    #[test]
    fn add_proxy_dry_run_against_existing_uri_reports_already_declared() {
        // Round 24 (debug): the `add_proxy` path checks
        // `path.exists()` *before* the `apply` flag, so
        // a dry-run against an already-declared URI
        // surfaces `AlreadyDeclared` (the same shape
        // the apply path would surface) instead of a
        // fabricated `DryRun { id }`. This is the
        // right contract: the writer's path-safety +
        // existence checks must fire on every entry,
        // regardless of the dispatch's intent, so the
        // operator's `set proxy add` against an
        // existing URI always errors (not silently
        // reports "would be added").
        let dir = temp_root("drydup");
        let paths = hermetic_paths(dir.as_path());
        add_proxy(&paths, "ss://x", None, true)
            .unwrap_or_else(|_| std::process::abort());
        let result = add_proxy(&paths, "ss://x", None, false);
        assert!(matches!(result, Err(InlineProxyError::AlreadyDeclared(_))));
        let _ = fs::remove_dir_all(&dir);
    }

    #[test]
    fn import_proxy_fails_fast_on_first_invalid_line() {
        // Round 24 (debug): `import_proxy` calls
        // `validate_uri(line)?` on every non-comment
        // line, so the first invalid URI short-circuits
        // the whole import with `InvalidUri`. That's
        // the right contract (a hard fail on a
        // non-proxy line is better than a partial
        // write — silent partial writes would be
        // noticed only after `config apply`, by which
        // time the operator doesn't remember which
        // lines of the import file were which). Lock
        // the current fail-fast contract: the import
        // stops at the first invalid line and returns
        // the `InvalidUri` error verbatim.
        let dir = temp_root("invalid");
        let paths = hermetic_paths(dir.as_path());
        let list_path = dir.join("list.txt");
        std::fs::write(
            &list_path,
            "ss://a\nbogus://x\nvmess://b\n",
        )
        .unwrap_or_else(|_| std::process::abort());
        let result = import_proxy(&paths, &list_path, true);
        assert!(
            matches!(result, Err(InlineProxyError::InvalidUri(_))),
            "expected InvalidUri on the second non-comment line, got {result:?}"
        );
        // The first valid line was written before the
        // `?` short-circuited. The fail-fast contract
        // is "stop on first error", NOT "rollback
        // already-written entries". A future round
        // could add a transactional `import_atomic`
        // that buffers all entries in memory and
        // writes them on a successful parse; the
        // current `import_proxy` is the simpler
        // fail-fast variant.
        let list = list_proxies(&paths);
        assert_eq!(list.len(), 1);
        assert_eq!(list[0].1, "ss://a");
        let _ = fs::remove_dir_all(&dir);
    }

    #[test]
    fn add_proxy_dry_run_does_not_write() {
        let dir = temp_root("__FUNC__");
        let paths = hermetic_paths(dir.as_path());
        let outcome = add_proxy(&paths, "ss://YWVz", None, false)
            .unwrap_or_else(|_| std::process::abort());
        assert!(matches!(outcome, InlineProxyOutcome::DryRun { .. }));
        let list = list_proxies(&paths);
        assert!(list.is_empty());
    }

    #[test]
    #[allow(clippy::panic, clippy::match_wildcard_for_single_variants)] // test assertion: a non-`Applied` outcome
    // is a contract violation we want to surface
    // loud, not silently absorb. The wildcard arm
    // and the `panic!` are deliberate.
    fn add_proxy_apply_persists_an_entry() {
        let dir = temp_root("__FUNC__");
        let paths = hermetic_paths(dir.as_path());
        let outcome = add_proxy(&paths, "ss://YWVz", Some("auto"), true)
            .unwrap_or_else(|_| std::process::abort());
        let id = match &outcome {
            InlineProxyOutcome::Applied { id } => id.clone(),
            other => panic!("expected Applied, got {other:?}"),
        };
        let list = list_proxies(&paths);
        assert_eq!(list.len(), 1);
        assert_eq!(list[0].0, id);
        assert_eq!(list[0].1, "ss://YWVz");
        // Re-adding the same URI is a no-op error.
        let result = add_proxy(&paths, "ss://YWVz", None, true);
        assert!(matches!(result, Err(InlineProxyError::AlreadyDeclared(_))));
    }

    #[test]
    #[allow(clippy::panic, clippy::match_wildcard_for_single_variants)] // test assertion: a non-`Applied` outcome
    // is a contract violation we want to surface
    // loud, not silently absorb.
    fn remove_proxy_filters_a_matching_id() {
        let dir = temp_root("__FUNC__");
        let paths = hermetic_paths(dir.as_path());
        let id = match add_proxy(&paths, "ss://a", None, true)
            .unwrap_or_else(|_| std::process::abort())
        {
            InlineProxyOutcome::Applied { id } => id,
            other => panic!("expected Applied, got {other:?}"),
        };
        add_proxy(&paths, "ss://b", None, true)
            .unwrap_or_else(|_| std::process::abort());
        let outcome = remove_proxy(&paths, &id, true)
            .unwrap_or_else(|_| std::process::abort());
        assert!(matches!(outcome, InlineProxyOutcome::Applied { .. }));
        let list = list_proxies(&paths);
        assert_eq!(list.len(), 1);
    }

    #[test]
    fn remove_proxy_rejects_unknown_id() {
        let dir = temp_root("__FUNC__");
        let paths = hermetic_paths(dir.as_path());
        let result = remove_proxy(&paths, "deadbeef", true);
        assert!(matches!(result, Err(InlineProxyError::NotDeclared(_))));
    }

    #[test]
    fn remove_proxy_accepts_a_raw_uri() {
        let dir = temp_root("__FUNC__");
        let paths = hermetic_paths(dir.as_path());
        add_proxy(&paths, "vmess://abc", None, true)
            .unwrap_or_else(|_| std::process::abort());
        let outcome = remove_proxy(&paths, "vmess://abc", true)
            .unwrap_or_else(|_| std::process::abort());
        assert!(matches!(outcome, InlineProxyOutcome::Applied { .. }));
    }

    #[test]
    fn add_proxy_trims_uri_before_hashing() {
        // Round 27 (debug): the pre-Round 27 shape
        // computed the id from the *raw* user
        // input but stored the *trimmed* URI in
        // the file body. A whitespace-padded URI
        // (`" vmess://abc"`) and the trimmed
        // version (`"vmess://abc"`) produced two
        // different on-disk files with identical
        // body content — operator confusion
        // (the file list showed two entries,
        // both with the same URI) and wasted
        // storage. The post-Round 27 contract:
        // the id is derived from the trimmed
        // URI, so the two strings map to the
        // same id and the same on-disk file.
        // The duplicate check (`AlreadyDeclared`)
        // is the operator-visible contract: a
        // second `add` with a whitespace-padded
        // URI is rejected as a duplicate of the
        // already-stored trimmed entry.
        let dir = temp_root("__FUNC__");
        let paths = hermetic_paths(dir.as_path());
        // First add: the trimmed URI.
        add_proxy(&paths, "vmess://abc", None, true)
            .unwrap_or_else(|_| std::process::abort());
        // Second add: a whitespace-padded variant
        // of the same URI. Pre-Round 27 this
        // would have created a second on-disk
        // file with a different id; post-Round 27
        // the trim normalizes the input and the
        // duplicate check fires.
        let result = add_proxy(&paths, "  vmess://abc  ", None, true);
        assert!(
            matches!(result, Err(InlineProxyError::AlreadyDeclared(_))),
            "expected AlreadyDeclared for whitespace-padded duplicate, got {result:?}"
        );
        // The on-disk file count is exactly one
        // (the trim-normalized entry), not two.
        let list = list_proxies(&paths);
        assert_eq!(list.len(), 1, "pre-Round 27 would have created 2 entries");
        assert_eq!(list[0].1, "vmess://abc");
    }

    #[test]
    fn import_proxy_bulk_reads_a_file() {
        let dir = temp_root("__FUNC__");
        let paths = hermetic_paths(dir.as_path());
        let list_path = dir.join("list.txt");
        std::fs::write(
            &list_path,
            "# comment\n\nss://a\nvmess://b\nss://a\n",
        )
        .unwrap_or_else(|_| std::process::abort());
        let outcome = import_proxy(&paths, &list_path, true)
            .unwrap_or_else(|_| std::process::abort());
        assert_eq!(outcome, ImportOutcome::Applied { count: 2 });
        let list = list_proxies(&paths);
        assert_eq!(list.len(), 2, "duplicate `ss://a` must be skipped");
    }
}
