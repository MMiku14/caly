//! TUI daemon-operation execution over a fresh UDS connection.

use std::path::Path;

use caly_protocol::{
    client::{ClientContract, UdsClient},
    protocol::v2::{
        ExecuteRequest, GetOperationStatusRequest, HandshakeRequest, ProtocolVersion, WireCommand,
        WireCoreAction, WireMode, all_features,
    },
};

use super::operation_id;

/// Executes one TUI control action against the daemon over a fresh connection,
/// returning a one-line status. Used by the interactive TUI so the render loop
/// is never blocked by a long-running operation.
pub fn run_control_action(
    socket: &Path,
    action: caly_tui::operation::ControlAction,
    core_wire: i32,
) -> Result<String, String> {
    let mut client =
        UdsClient::connect(socket.to_path_buf()).map_err(|error| format!("{error:?}"))?;
    client
        .handshake(HandshakeRequest {
            client_version: ProtocolVersion::V2_0,
            requested_features: all_features(),
            auth_token: crate::daemon_config::auth_token(),
        })
        .map_err(|error| format!("{error:?}"))?;
    let id = operation_id();
    let command = match action {
        caly_tui::operation::ControlAction::SelectNode(node) => WireCommand::SelectProxy {
            node_id: node.into_bytes(),
        },
        caly_tui::operation::ControlAction::SetMode(mode) => WireCommand::SetMode {
            mode: WireMode::from(mode).wire(),
        },
        caly_tui::operation::ControlAction::RestartCore => WireCommand::SwitchCore {
            core_kind: core_wire,
            action: WireCoreAction::Restart.wire(),
        },
        caly_tui::operation::ControlAction::CloseConnections => WireCommand::CloseAllConnections,
    };
    tracing::debug!(action = ?action, operation = ?id, "TUI control action submitted");
    client
        .execute(ExecuteRequest {
            operation_id: id,
            command,
        })
        .map_err(|error| format!("{error:?}"))?;
    let deadline = std::time::Instant::now() + std::time::Duration::from_secs(5);
    loop {
        let status = client
            .operation_status(GetOperationStatusRequest { operation_id: id })
            .map_err(|error| format!("{error:?}"))?;
        if status.state.is_terminal() {
            tracing::debug!(operation = ?id, state = status.state.0, "TUI control action terminal");
            return Ok(terminal_label(status.state));
        }
        if std::time::Instant::now() >= deadline {
            return Ok("operation still running".to_owned());
        }
        std::thread::sleep(std::time::Duration::from_millis(150));
    }
}

/// One-line label for a terminal operation state, derived from the typed
/// wire mapping (completed -> ok, failed/cancelled keep their names).
fn terminal_label(state: caly_protocol::protocol::v2::RawOperationState) -> String {
    use caly_protocol::protocol::v2::WireOperationState;
    match state.known() {
        Some(WireOperationState::Completed) => "ok".to_owned(),
        Some(other) => other.label().to_owned(),
        None => "finished".to_owned(),
    }
}
