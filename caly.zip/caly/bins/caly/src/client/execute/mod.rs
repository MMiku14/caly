//! Daemon operation execution for CLI leaves.
//!
//! Maps each mutation leaf to its wire command, executes it with a fresh
//! operation id, and polls to a terminal state. Human output reports a
//! semantic summary of the requested change; JSON output keeps the raw
//! operation record for scripts. All wire discriminants come from the
//! protocol's typed wire layer (`caly_protocol::protocol::v2`).
//!
//! Round 23: the latency probe / sweep / select-by-delay
//! logic moved to [`delay`] so the top-level file is a
//! 1-page dispatch table again (S4.1 advisory). The
//! remaining `execute_*` functions here are the
//! daemon-RPC core: config / sys / core lifecycle /
//! daemon lifecycle / refresh.

use caly_platform::paths::AppPaths;
use std::process::ExitCode;

use caly_protocol::{
    client::{ClientContract, ClientError, UdsClient},
    protocol::v2::{
        ExecuteRequest, GetOperationStatusRequest, HandshakeRequest, ProtocolVersion,
        RawOperationState, WireCommand, WireCoreAction, WireCoreKind, WireMode, all_features,
    },
};

use super::{Query, hex, operation_id, output};
use crate::client::legacy::{ConfigCmd, CoreCmd, SysCmd};

mod delay;

pub(super) use delay::execute_delay_all;
pub(super) use delay::lowest_latency_node;

/// Validates a single configuration file offline (`config check <file>`).
pub(crate) fn check_single_config_file(path: &std::path::Path, json: bool) -> ExitCode {
    match crate::cli::check_config_file(path) {
        Ok(()) => {
            if json {
                println!(
                    "{}",
                    serde_json::json!({"ok": true, "configuration": "valid"})
                );
            } else {
                println!("configuration is valid");
            }
            ExitCode::SUCCESS
        }
        Err(error) => output::report_config_check_failed(&error.to_string(), json),
    }
}

/// Executes a `config` family leaf.
pub(super) fn execute_config_cmd(client: &mut UdsClient, cmd: ConfigCmd, json: bool) -> ExitCode {
    match cmd {
        ConfigCmd::Apply => execute_operation_with(client, json, "apply configuration", |id| {
            WireCommand::ApplyConfig { candidate_id: id }
        }),
        // Intercepted as offline commands before connecting; defensive.
        ConfigCmd::Generate
        | ConfigCmd::Default
        | ConfigCmd::Validate
        | ConfigCmd::Check(_)
        | ConfigCmd::Path
        | ConfigCmd::Files
        | ConfigCmd::Edit(_) => ExitCode::FAILURE,
    }
}

/// Maps a `core` command leaf to an offline read-only query, if it is one.
pub(super) fn core_query(cmd: &CoreCmd) -> Option<Query> {
    match cmd {
        CoreCmd::ProxyGroups => Some(Query::ProxyGroups),
        CoreCmd::ListConnections => Some(Query::Connections),
        CoreCmd::Traffic => Some(Query::Traffic),
        CoreCmd::Delay { all: true, .. } => None,
        CoreCmd::Delay {
            name: Some(name),
            url,
            samples,
            ..
        } => Some(Query::UrlTest {
            name: name.clone(),
            url: url.clone(),
            samples: crate::client::query::resolve_samples(*samples),
        }),
        CoreCmd::Delay {
            all: false,
            name: None,
            ..
        } => {
            // Unreachable: clap rejects delay with neither --all nor a name.
            None
        }
        _ => None,
    }
}

/// Executes a `core` family leaf. `core` is the resolved `--core` target;
/// only lifecycle leaves (start/stop/restart) use it.
pub(super) fn execute_core_cmd(
    client: &mut UdsClient,
    cmd: CoreCmd,
    core: Option<&str>,
    json: bool,
) -> ExitCode {
    match cmd {
        CoreCmd::Start => execute_core(client, WireCoreAction::Start, core, json),
        CoreCmd::Stop => execute_core(client, WireCoreAction::Stop, core, json),
        CoreCmd::Restart => execute_core(client, WireCoreAction::Restart, core, json),
        CoreCmd::Switch(target) => execute_switch_core(client, &target, json),
        CoreCmd::Select { node, delay } => {
            execute_select_proxy(client, node.as_deref(), delay, json)
        }
        CoreCmd::Delay { all: true, url, .. } => execute_delay_all(client, url.as_deref(), json),
        CoreCmd::CloseConnections => {
            execute_operation_with(client, json, "close all connections", |_| {
                WireCommand::CloseAllConnections
            })
        }
        CoreCmd::Mode(mode) => execute_set_mode(client, &mode, json),
        CoreCmd::ListNodes => output::print_nodes(client, json),
        // These are intercepted as offline queries before connecting.
        CoreCmd::ProxyGroups
        | CoreCmd::ListConnections
        | CoreCmd::Traffic
        | CoreCmd::Delay { .. }
        | CoreCmd::Rules
        | CoreCmd::RuleMatch(_) => ExitCode::FAILURE,
    }
}

/// The layered override fragment `caly sys tun` writes so the TUN intent
/// survives daemon restarts without editing the user's 60-tun.yaml: it sorts
/// after that file, so its `tun.enabled` wins in the layered merge.
const TUN_TOGGLE_OVERRIDE: &str = "65-tun-toggle.yaml";

/// Persists the hot TUN intent into the layered config directory. Returns an
/// exit code on failure; the caller aborts before touching the daemon.
fn patch_tun_enabled(enabled: bool, json: bool) -> Result<(), ExitCode> {
    let directory = AppPaths::from_env().config.join("config.d");
    let contents = format!(
        "# Hot TUN toggle written by `caly sys tun`; layered over\n\
         # config.d/60-tun.yaml so the core renderer sees tun.enabled={enabled}\n\
         # without editing the user's config. Delete this file to hand the\n\
         # TUN setting back to the layered config files.\n\
         tun:\n  enabled: {enabled}\n"
    );
    let path = directory.join(TUN_TOGGLE_OVERRIDE);
    std::fs::write(&path, contents).map_err(|error| {
        output::report_failure(
            &format!(
                "cannot persist TUN toggle {}: {error} (inspect config-directory ownership)",
                path.display()
            ),
            json,
        )
    })?;
    Ok(())
}

/// Executes a `sys` family leaf.
pub(super) fn execute_sys_cmd(client: &mut UdsClient, cmd: SysCmd, json: bool) -> ExitCode {
    match cmd {
        SysCmd::Proxy(enabled) => {
            let summary = if enabled {
                "enable system proxy"
            } else {
                "disable system proxy"
            };
            execute_operation_with(client, json, summary, |_| WireCommand::SetSystemProxy {
                enabled,
            })
        }
        SysCmd::Tun(enabled) => {
            // Hot TUN toggle: no daemon restart needed. The core renderer
            // re-reads the layered TUN config on every apply, so persist the
            // intent into a small override fragment layered after
            // config.d/60-tun.yaml, re-render+commit the core config, then
            // engage/restore the platform TUN device and routes. Ordering
            // matters: the engine must expose the tun inbound before the
            // device comes up (no silent half-engagement), and the inbound
            // goes away before the device is restored on shutdown.
            if let Err(code) = patch_tun_enabled(enabled, json) {
                return code;
            }
            let applied = execute_operation_with(
                client,
                json,
                "apply configuration for TUN",
                |id| WireCommand::ApplyConfig { candidate_id: id },
            );
            if applied != ExitCode::SUCCESS {
                return applied;
            }
            let summary = if enabled { "engage TUN" } else { "restore TUN" };
            let outcome =
                execute_operation_with(client, json, summary, |_| WireCommand::SetTun { enabled });
            // Rollback transaction: a failed engage must never leave the
            // committed tun-inbound config in effect — the core would keep
            // hijacking traffic into a device the platform layer did not
            // confirm, black-holing the network (the half-engaged state that
            // broke direct connectivity in the field). Reversing the enable
            // sequence restores the invariant: toggle off, then re-apply so
            // the core restarts without the tun inbound, releasing the
            // device and tearing down auto-route rules.
            if enabled && outcome != ExitCode::SUCCESS {
                let _ = patch_tun_enabled(false, json);
                let reverted = execute_operation_with(
                    client,
                    json,
                    "revert TUN configuration after failed engage",
                    |id| WireCommand::ApplyConfig { candidate_id: id },
                );
                let message = if reverted == ExitCode::SUCCESS {
                    "TUN engage failed; the configuration was reverted, so routing is restored (fix the cause and retry `caly set tun on`)"
                } else {
                    "TUN engage failed AND the config revert failed; the core may still route traffic through the TUN device — run `caly set tun off` to restore"
                };
                crate::output::CliOutput::from_json_flag(json).info(message);
            }
            outcome
        }
    }
}

/// Executes the configured subscription refresh.
pub(super) fn execute_refresh_subscription(client: &mut UdsClient, json: bool) -> ExitCode {
    execute_operation_with(client, json, "refresh subscription", |_| {
        WireCommand::RefreshSubscription {
            subscription_id: [0_u8; 16],
        }
    })
}

/// Round 17: `set daemon stop`. The server
/// tears down the runtime after the response is
/// serialized; the client gets the final operation
/// status before the daemon process exits, so
/// polling is unnecessary (and would race the
/// `stop_notifier` that closes the UDS socket right
/// after this response is written).
pub(super) fn execute_stop_daemon(client: &mut UdsClient, json: bool) -> ExitCode {
    execute_lifecycle_immediate(client, json, "stop daemon", |_id| WireCommand::StopDaemon)
}

/// Round 17: `set daemon reload`. The server
/// re-reads `config.yaml` and re-applies the current
/// candidate; the operation completes immediately
/// on the application side, so the response is
/// already terminal and polling is unnecessary.
pub(super) fn execute_reload_config(client: &mut UdsClient, json: bool) -> ExitCode {
    execute_lifecycle_immediate(client, json, "reload config", |_id| WireCommand::ReloadConfig)
}

/// Executes a Round-17 lifecycle command whose operation completes on the
/// application side in the same `execute` call: the server returns the
/// final `WireOperationStatus` inside the `ExecuteResponse`, so the client
/// must NOT poll (the `StopDaemon` path closes the UDS socket right after
/// the response, and polling for a stale id would surface a confusing
/// `connect_failed` error). If the response is somehow non-terminal
/// (defensive), fall through to a bounded poll.
fn execute_lifecycle_immediate(
    client: &mut UdsClient,
    json: bool,
    summary: &str,
    build: impl FnOnce([u8; 16]) -> WireCommand,
) -> ExitCode {
    let id = operation_id();
    match client.execute(ExecuteRequest {
        operation_id: id,
        command: build(id),
    }) {
        Ok(response) => {
            let status = response.operation;
            if status.state.is_terminal() {
                output::print_operation_status(&status, json, summary);
                terminal_exit_code(status.state)
            } else {
                // Defensive: the typed path is supposed to be terminal here,
                // but the server may be running an older build that returns a
                // non-terminal status. Poll for a bounded window so the
                // caller still gets a definitive answer.
                poll_operation(client, id, json, summary)
            }
        }
        Err(error) => output::report_error(error, json),
    }
}

/// The single mutation path: assign an operation id, execute the command the
/// caller builds from it, then poll to a terminal state.
fn execute_operation_with(
    client: &mut UdsClient,
    json: bool,
    summary: &str,
    build: impl FnOnce([u8; 16]) -> WireCommand,
) -> ExitCode {
    let id = operation_id();
    match client.execute(ExecuteRequest {
        operation_id: id,
        command: build(id),
    }) {
        Ok(_) => poll_operation(client, id, json, summary),
        Err(error) => output::report_error(error, json),
    }
}

/// Executes a `SetMode` operation against the daemon.
fn execute_set_mode(client: &mut UdsClient, mode: &str, json: bool) -> ExitCode {
    let Some(mode_value) = WireMode::from_label(mode) else {
        return output::report_usage_error("mode must be rule, global, or direct", json);
    };
    execute_operation_with(client, json, &format!("set mode to {mode}"), |_| {
        WireCommand::SetMode {
            mode: mode_value.wire(),
        }
    })
}

/// Switches the active core to `target` (stop previous kernel, start target).
fn execute_switch_core(client: &mut UdsClient, target: &str, json: bool) -> ExitCode {
    let kind = match target {
        "sing-box" => WireCoreKind::SingBox,
        "mihomo" => WireCoreKind::Mihomo,
        other => {
            return output::report_usage_error(
                &format!("unknown core `{other}`; use mihomo or sing-box"),
                json,
            );
        }
    };
    execute_operation_with(
        client,
        json,
        &format!("switch core to {}", kind.label()),
        |_| WireCommand::SwitchCore {
            core_kind: kind.wire(),
            action: WireCoreAction::Restart.wire(),
        },
    )
}

/// Executes a core lifecycle action (start/stop/restart) for the resolved core.
///
/// Without an explicit `--core`/`CALY_CORE`, the target follows the daemon's
/// runtime active core — so `caly core restart` restarts the kernel the user
/// actually switched to instead of silently switching to (or stopping it for)
/// a hardcoded mihomo.
fn execute_core(
    client: &mut UdsClient,
    action: WireCoreAction,
    core: Option<&str>,
    json: bool,
) -> ExitCode {
    let effective = match core {
        Some(core) => Some(core.to_owned()),
        None => active_core_kind(client).map(|kind| kind.label().to_owned()),
    };
    let kind = match resolved_core_kind(effective.as_deref()) {
        Ok(kind) => kind,
        Err(message) => {
            if json {
                println!("{}", serde_json::json!({ "ok": false, "error": message }));
            } else {
                eprintln!("error: {message}");
            }
            return ExitCode::from(2);
        }
    };
    let label = kind.label();
    let verb = match action {
        WireCoreAction::Start => "start",
        WireCoreAction::Stop => "stop",
        WireCoreAction::Restart => "restart",
    };
    execute_operation_with(client, json, &format!("{verb} {label}"), |_| {
        WireCommand::SwitchCore {
            core_kind: kind.wire(),
            action: action.wire(),
        }
    })
}

/// Reads the daemon snapshot for the runtime active core kind.
fn active_core_kind(client: &mut UdsClient) -> Option<WireCoreKind> {
    use caly_protocol::client::ClientContract;
    let snapshot = client.snapshot().ok()?;
    WireCoreKind::from_wire(snapshot.applied.core_kind?)
}

/// Resolves the target core: `--core` flag first, then `CALY_CORE`, default
/// mihomo. Unknown values fail loudly instead of silently falling back to
/// mihomo (a typo like `--core mihomoo` must not silently act on the wrong
/// kernel).
fn resolved_core_kind(core: Option<&str>) -> Result<WireCoreKind, String> {
    let effective = core
        .map(str::to_owned)
        .or_else(|| std::env::var("CALY_CORE").ok());
    match effective.as_deref() {
        None | Some("mihomo") => Ok(WireCoreKind::Mihomo),
        Some("sing-box") => Ok(WireCoreKind::SingBox),
        Some("xray") => Ok(WireCoreKind::Xray),
        Some(other) => Err(format!(
            "unknown core target `{other}` (expected mihomo, sing-box or xray)"
        )),
    }
}

/// Selects a proxy node: by ID/name/prefix, or automatically the lowest
/// latency node (never direct) with `--delay`.
fn execute_select_proxy(
    client: &mut UdsClient,
    node: Option<&str>,
    delay: bool,
    json: bool,
) -> ExitCode {
    if delay {
        let Some(best) = lowest_latency_node(client, json) else {
            return ExitCode::from(2);
        };
        let label = best.1;
        return execute_operation_with(client, json, &format!("select node `{label}`"), |_| {
            WireCommand::SelectProxy { node_id: best.0 }
        });
    }
    let Some(node) = node else {
        return output::report_usage_error(
            "select needs a node ID/name, or --delay to pick the fastest node",
            json,
        );
    };
    let Some((node_id, label)) = resolve_node(client, node, json) else {
        return ExitCode::from(2);
    };
    execute_operation_with(client, json, &format!("select node `{label}`"), |_| {
        WireCommand::SelectProxy { node_id }
    })
}

/// Resolves a `select` argument: a 32-hex node ID is used as-is; anything
/// else is matched against the snapshot's node display names (exact match
/// first, then a unique case-insensitive match).
fn resolve_node(client: &mut UdsClient, node: &str, json: bool) -> Option<([u8; 16], String)> {
    if let Some(id) = parse_node_id(node) {
        return Some((id, node.to_owned()));
    }
    let snapshot = match client.snapshot() {
        Ok(snapshot) => snapshot,
        Err(error) => {
            let _ = output::report_error(error, json);
            return None;
        }
    };
    let exact: Vec<_> = snapshot
        .nodes
        .iter()
        .filter(|candidate| {
            candidate.name == node || output::decode_display_name(&candidate.name) == node
        })
        .collect();
    if exact.len() == 1 {
        return Some((exact[0].node_id, exact[0].name.clone()));
    }
    if exact.len() > 1 {
        let ids = exact
            .iter()
            .map(|candidate| format!("  {} ({})", hex(candidate.node_id), candidate.protocol))
            .collect::<Vec<_>>()
            .join("\n");
        output::report_usage_error(
            &format!(
                "{} nodes share the name `{node}`; select one by ID:\n{ids}",
                exact.len()
            ),
            json,
        );
        return None;
    }
    let fuzzy: Vec<_> = snapshot
        .nodes
        .iter()
        .filter(|candidate| candidate.name.eq_ignore_ascii_case(node))
        .collect();
    if fuzzy.len() == 1 {
        return Some((fuzzy[0].node_id, fuzzy[0].name.clone()));
    }
    // Unique case-insensitive prefix match: select by a short unambiguous
    // fragment of the display name (e.g. the country flag or keyword).
    let prefix: Vec<_> = snapshot
        .nodes
        .iter()
        .filter(|candidate| {
            candidate
                .name
                .to_lowercase()
                .starts_with(&node.to_lowercase())
        })
        .collect();
    if prefix.len() == 1 {
        return Some((prefix[0].node_id, prefix[0].name.clone()));
    }
    if prefix.len() > 1 {
        let ids = prefix
            .iter()
            .take(8)
            .map(|candidate| format!("  {} ({})", hex(candidate.node_id), candidate.name))
            .collect::<Vec<_>>()
            .join("\n");
        output::report_usage_error(
            &format!(
                "`{node}` matches {} nodes; use a longer prefix or an ID:\n{ids}",
                prefix.len()
            ),
            json,
        );
        return None;
    }
    output::report_usage_error(
        &format!("no node named `{node}`; list nodes with `caly core list-nodes`"),
        json,
    );
    None
}

/// Parses a 32-hex-character node id into its 16-byte wire form.
pub(super) fn parse_node_id(hex_value: &str) -> Option<[u8; 16]> {
    if hex_value.len() != 32 {
        return None;
    }
    let mut id = [0_u8; 16];
    for (index, pair) in hex_value.as_bytes().chunks(2).enumerate() {
        let hi = u8::try_from((pair[0] as char).to_digit(16)?).ok()?;
        let lo = u8::try_from((pair[1] as char).to_digit(16)?).ok()?;
        id[index] = (hi << 4) | lo;
    }
    Some(id)
}

/// Polls an operation until it reaches a terminal state (or a bounded timeout).
/// `summary` describes the requested change for the human-readable result line.
fn poll_operation(client: &mut UdsClient, id: [u8; 16], json: bool, summary: &str) -> ExitCode {
    let deadline = std::time::Instant::now() + std::time::Duration::from_secs(20);
    loop {
        match client.operation_status(GetOperationStatusRequest { operation_id: id }) {
            Ok(status) => {
                if status.state.is_terminal() {
                    output::print_operation_status(&status, json, summary);
                    return terminal_exit_code(status.state);
                }
                if std::time::Instant::now() >= deadline {
                    output::print_operation_status(&status, json, summary);
                    return ExitCode::from(6); // TimedOutStillRunning
                }
            }
            Err(error) => return output::report_error(error, json),
        }
        std::thread::sleep(std::time::Duration::from_millis(200));
    }
}

/// Maps a terminal operation state to the CLI exit-code contract.
fn terminal_exit_code(state: RawOperationState) -> ExitCode {
    use caly_protocol::protocol::v2::WireOperationState;
    match state.known() {
        Some(WireOperationState::Completed) => ExitCode::SUCCESS,
        Some(WireOperationState::Failed) => ExitCode::from(3),
        Some(WireOperationState::Cancelled) => ExitCode::from(7),
        _ => ExitCode::from(6), // still running / unknown
    }
}

/// Performs the v2 handshake over an established client connection.
pub(crate) fn handshake(client: &mut UdsClient) -> Result<(), ClientError> {
    client.handshake(HandshakeRequest {
        client_version: ProtocolVersion::V2_0,
        requested_features: all_features(),
    })?;
    Ok(())
}

/// Connects to the UDS, retrying briefly on `TransportUnavailable` to absorb a
/// daemon-startup race. Non-transport failures surface immediately.
pub(super) fn connect_with_retry(socket: &std::path::Path) -> Result<UdsClient, ClientError> {
    const MAX_ATTEMPTS: u32 = 5;
    const RETRY_MS: u64 = 200;
    let mut last = ClientError::TransportUnavailable;
    for attempt in 0..MAX_ATTEMPTS {
        match UdsClient::connect(socket.to_path_buf()) {
            Ok(client) => return Ok(client),
            Err(error) => {
                last = error;
                if !matches!(last, ClientError::TransportUnavailable) || attempt + 1 == MAX_ATTEMPTS
                {
                    break;
                }
                std::thread::sleep(std::time::Duration::from_millis(RETRY_MS));
            }
        }
    }
    Err(last)
}

/// Connects to the daemon, performs the v2 handshake, and
/// reads the presentation snapshot. The single helper
/// the read-only `show <resource>` leaves go through so
/// the connect + handshake + snapshot boilerplate
/// (three error paths, three `eprintln!`s, three
/// `ExitCode::from(1)`s) is owned in one place.
///
/// `CALY_SOCKET` overrides the default socket path; the
/// default is `AppPaths::from_env().socket_path()`.
///
/// Returns the snapshot on success; on failure, the
/// helper has already printed the typed error envelope
/// and returned the right exit code, so the dispatch
/// can `return match with_uds_snapshot() { ... }` or
/// `return with_uds_snapshot()` for the simple "render
/// the snapshot" path.
pub(crate) fn with_uds_snapshot<F>(
    on_snapshot: F,
) -> ExitCode
where
    F: FnOnce(UdsClient, caly_protocol::protocol::v2::WirePresentationSnapshot) -> ExitCode,
{
    use caly_protocol::client::ClientContract;
    use caly_protocol::protocol::v2::WirePresentationSnapshot;
    let socket = std::env::var_os("CALY_SOCKET")
        .map_or_else(
            || caly_platform::paths::AppPaths::from_env().socket_path(),
            std::path::PathBuf::from,
        );
    let mut client = match UdsClient::connect(socket) {
        Ok(c) => c,
        Err(error) => {
            eprintln!("error: cannot connect to daemon: {error}");
            return ExitCode::from(1);
        }
    };
    if let Err(error) = handshake(&mut client) {
        eprintln!("error: handshake failed: {error}");
        return ExitCode::from(1);
    }
    let snapshot: WirePresentationSnapshot = match client.snapshot() {
        Ok(s) => s,
        Err(error) => {
            eprintln!("error: snapshot read failed: {error}");
            return ExitCode::from(1);
        }
    };
    on_snapshot(client, snapshot)
}

#[cfg(test)]
mod core_target_tests {
    use super::resolved_core_kind;
    use caly_protocol::protocol::v2::WireCoreKind;

    #[test]
    fn accepts_known_targets() -> Result<(), String> {
        assert_eq!(
            resolved_core_kind(None).map_err(|e| e.clone())?,
            WireCoreKind::Mihomo
        );
        assert_eq!(
            resolved_core_kind(Some("mihomo")).map_err(|e| e.clone())?,
            WireCoreKind::Mihomo
        );
        assert_eq!(
            resolved_core_kind(Some("sing-box")).map_err(|e| e.clone())?,
            WireCoreKind::SingBox
        );
        Ok(())
    }

    #[test]
    fn rejects_unknown_targets_loudly() {
        // A typo must fail instead of silently acting on mihomo.
        assert!(resolved_core_kind(Some("mihomoo")).is_err());
        assert!(resolved_core_kind(Some("singbox")).is_err());
        assert!(resolved_core_kind(Some("")).is_err());
    }
}
