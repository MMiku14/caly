//! Latency probe / sweep / select-by-delay logic.
//!
//! Round 23: extracted from `client/execute.rs` so the
//! 1100+ line `execute.rs` is a 1-page file again
//! (S4.1 advisory). The select-by-delay + sweep
//! pipeline is self-contained: it reads the daemon
//! snapshot, reconciles against the kernel's
//! controller-side proxy list, then probes the
//! surviving nodes with bounded concurrency. The
//! dispatch in `client::execute::execute_core_cmd`
//! reaches in via [`execute_delay_all`] /
//! [`lowest_latency_node`]; nothing else in the
//! `client` tree needs the internals.

use std::process::ExitCode;
use std::sync::PoisonError;

use caly_protocol::client::UdsClient;

use crate::client::output;

/// Per-probe timeout for the full latency sweep (`delay --all`).
const PROBE_TIMEOUT: std::time::Duration = std::time::Duration::from_secs(5);

/// Maximum concurrent controller probes in one sweep. Bounded so a 267-node
/// subscription never opens one socket/thread per node against the kernel;
/// the kernel serves probes concurrently, but unbounded client fan-out is
/// wasteful and noisy. 32 balances wall-clock time (dead-node probes burn
/// their full per-probe timeout) against connection fan-out.
const MAX_CONCURRENT_PROBES: usize = 32;

/// Latency-sweeps the daemon snapshot's nodes against the active core
/// controller (offline). The controller-side name is derived from the core:
/// sing-box outbounds are tagged `proxy-<canonical-hex>`; Mihomo uses the
/// rendered display name. Output rows carry the node ID so they can feed
/// `core select` directly.
pub(crate) fn execute_delay_all(client: &mut UdsClient, url: Option<&str>, json: bool) -> ExitCode {
    match sweep_snapshot_delays(client, url) {
        Ok(rows) => {
            print_delay_sweep(&rows, json);
            ExitCode::SUCCESS
        }
        Err(error) => output::report_failure(&error, json),
    }
}

/// Sweeps the snapshot's registered nodes against the active core controller
/// and returns the lowest-latency reachable one, or `None` when none answers.
/// Every non-reachable outcome is reported so a silent "no node answers" is
/// never confused with a naming/apply mismatch or a controller outage.
pub(crate) fn lowest_latency_node(
    client: &mut UdsClient,
    json: bool,
) -> Option<([u8; 16], String)> {
    let rows = match sweep_snapshot_delays(client, None) {
        Ok(rows) => rows,
        Err(error) => {
            let _ = output::report_failure(&error, json);
            return None;
        }
    };
    let reachable: Vec<(u32, [u8; 16], String)> = rows
        .iter()
        .filter_map(|row| match &row.outcome {
            DelayOutcome::Reachable { samples, .. } => {
                row.outcome
                    .median_ms()
                    .map(|ms| (ms, row.node_id, row.name.clone()))
                    .or_else(|| {
                        // Defensive: an empty
                        // `Reachable` shouldn't
                        // happen (the writer
                        // maps empty to
                        // `Unreachable`), but the
                        // contract is "reachable
                        // has at least one sample".
                        let _ = samples;
                        None
                    })
            }
            _ => None,
        })
        .collect();
    let best = reachable.iter().min_by_key(|(ms, _, _)| *ms);
    if best.is_none() {
        let unreachable = rows
            .iter()
            .filter(|row| row.outcome == DelayOutcome::Unreachable)
            .count();
        let not_in_kernel = rows
            .iter()
            .filter(|row| row.outcome == DelayOutcome::NotInKernel)
            .count();
        let failed = rows
            .iter()
            .filter(|row| row.outcome == DelayOutcome::ProbeFailed)
            .count();
        let _ = output::report_failure(
            &format!(
                "no node answered the latency probe ({unreachable} unreachable, {not_in_kernel} not in the kernel config, {failed} probe errors)"
            ),
            json,
        );
        return None;
    }
    best.map(|(_, node_id, name)| (*node_id, name.clone()))
}

/// How one node's latency probe ended. Every failure mode stays distinct so a
/// sweep never silently collapses a naming/apply mismatch or a controller
/// outage into the same "unreachable" row. The reachable variant carries
/// the full per-sample list (sorted ascending) so the JSON envelope can
/// report `samples` and `jitter_ms` alongside the median.
#[derive(Clone, Debug, Eq, PartialEq)]
enum DelayOutcome {
    /// Kernel answered at least one probe; the
    /// `samples` are sorted ascending in milliseconds.
    /// `median` (the lower middle on even counts) is
    /// the historical single-number summary.
    Reachable {
        samples: Vec<u32>,
        /// URL the kernel answered (stable for this
        /// row; `None` only for the
        /// unreachable-from-every-URL case, but
        /// that lives in the `Unreachable` variant).
        url: String,
    },
    /// Kernel ran the probe but no URL answered.
    Unreachable,
    /// The controller name is not present in the running kernel's proxy set.
    NotInKernel,
    /// Transport/API failure while probing (controller went away, etc.).
    ProbeFailed,
}

impl DelayOutcome {
    /// One-number summary for sorting / printing.
    /// `Reachable` returns the median; every other
    /// variant returns `None` so the caller can
    /// skip the row in `core select --delay`.
    ///
    /// Round 31: delegates to the central
    /// `query::median` helper so the per-node leaf
    /// and the bulk sweep share the same
    /// lower-middle algorithm. The pre-Round 31
    /// shape indexed into the sorted `Vec` with
    /// `len / 2`, which is the upper middle on even
    /// counts (`[50, 200] → 200` instead of the
    /// canonical lower middle 50 — see
    /// `query::median`'s regression test
    /// `even_sample_count_picks_the_lower_middle`).
    fn median_ms(&self) -> Option<u32> {
        match self {
            Self::Reachable { samples, .. } => super::super::query::median(samples),
            _ => None,
        }
    }
}

/// Builds the `Reachable` outcome from a successful
/// probe. Extracted so the worker closure inside
/// `sweep_snapshot_delays` stays under the 100-line
/// clippy ceiling; the helper is trivial but the
/// closure is the hot loop that has to inline-clean.
fn build_reachable_outcome(probe: super::super::query::DelayProbe) -> DelayOutcome {
    let url = probe.url().unwrap_or("").to_owned();
    DelayOutcome::Reachable {
        samples: probe.samples().to_vec(),
        url,
    }
}

/// One row of a latency sweep: the node identity plus its probe outcome.
struct SweepRow {
    node_id: [u8; 16],
    name: String,
    /// Controller-side name used for the probe (and the kernel-set match).
    controller_name: String,
    outcome: DelayOutcome,
}

/// Probes every snapshot node through the active core controller with bounded
/// concurrency. Nodes whose controller name is absent from the kernel's real
/// proxy list are reported as `NotInKernel` without probing: probing them
/// would only yield a 404 that the old algorithm silently rendered as
/// "unreachable" (e.g. a subscription that was never applied).
#[allow(clippy::too_many_lines)]
fn sweep_snapshot_delays(
    client: &mut UdsClient,
    url: Option<&str>,
) -> Result<Vec<SweepRow>, String> {
    use caly_protocol::client::ClientContract;
    let snapshot = client.snapshot().map_err(|error| {
        let _ = error;
        "cannot read the daemon snapshot for the node list (is the daemon running?)".to_owned()
    })?;
    let core = super::active_core_kind(client)
        .map_or_else(|| "mihomo".to_owned(), |kind| kind.label().to_owned());
    let mut rows: Vec<SweepRow> = snapshot
        .nodes
        .iter()
        .map(|node| {
            let controller_name = if core == "sing-box" {
                format!("proxy-{}", caly_domain::to_hex(node.node_id))
            } else {
                node.name.clone()
            };
            SweepRow {
                node_id: node.node_id,
                name: node.name.clone(),
                controller_name,
                outcome: DelayOutcome::Unreachable,
            }
        })
        .collect();
    // Reconcile against the kernel's real proxy set before probing anything, so
    // a stale/unapplied kernel config surfaces as `NotInKernel` instead of a
    // wall of silent 404s.
    let mut control = crate::client::query::build_control(&core)
        .map_err(|error| format!("cannot reach the {core} controller: {error}"))?;
    let kernel_names: std::collections::BTreeSet<String> = control
        .proxy_names(PROBE_TIMEOUT)
        .map_err(|error| format!("cannot read the {core} kernel proxy list: {error}"))?
        .into_iter()
        .collect();
    let mut targets: Vec<(usize, String)> = Vec::new();
    for (index, row) in rows.iter_mut().enumerate() {
        if kernel_names.contains(&row.controller_name) {
            targets.push((index, row.controller_name.clone()));
        } else {
            row.outcome = DelayOutcome::NotInKernel;
        }
    }
    if targets.is_empty() {
        return Ok(rows);
    }
    // Bounded worker pool; each worker owns one controller (fresh secret read)
    // and drains the shared target queue.
    let worker_count = targets.len().min(MAX_CONCURRENT_PROBES);
    let mut controls = Vec::with_capacity(worker_count);
    controls.push(control); // reuse the reconcile controller for probing
    for _ in 1..worker_count {
        if let Ok(control) = crate::client::query::build_control(&core) {
            controls.push(control);
        }
    }
    if controls.is_empty() {
        return Err(format!("cannot build a {core} controller for probing"));
    }
    let shared = std::sync::Mutex::new(targets);
    let shared = &shared;
    let results: Vec<(usize, DelayOutcome)> = std::thread::scope(|scope| {
        let mut workers = Vec::new();
        for mut control in controls {
            workers.push(scope.spawn(move || {
                let mut local = Vec::new();
                loop {
                    let item = {
                        let mut guard = shared.lock().unwrap_or_else(PoisonError::into_inner);
                        guard.pop()
                    };
                    let Some((index, controller_name)) = item else {
                        break;
                    };
                    let outcome = match super::super::query::probe_delay(
                        &mut *control,
                        &controller_name,
                        url,
                        PROBE_TIMEOUT,
                        // The sweep always takes 3 samples:
                        // a single sample is dominated by
                        // TCP slow-start, two is
                        // sensitive to a single
                        // hiccup, three is the
                        // sweet spot. `--samples N` on
                        // the per-node leaf is the
                        // operator-level escape
                        // hatch; the bulk sweep keeps
                        // its own policy so a
                        // 267-node sweep doesn't take
                        // 22 minutes.
                        3,
                    ) {
                        Ok(probe) if probe.is_reachable() => build_reachable_outcome(probe),
                        Ok(_) => DelayOutcome::Unreachable,
                        // A probe that outlived the socket budget (the
                        // kernel hung past its own timeout) is unreachable
                        // from the user's viewpoint, not a controller
                        // transport failure; connect failures stay loud.
                        Err(error)
                            if error.kind
                                == caly_corectl::contract::KernelFailureKind::DeadlineExceeded =>
                        {
                            DelayOutcome::Unreachable
                        }
                        Err(_) => DelayOutcome::ProbeFailed,
                    };
                    local.push((index, outcome));
                }
                local
            }));
        }
        workers
            .into_iter()
            .flat_map(|worker| worker.join().ok().into_iter().flatten())
            .collect()
    });
    for (index, outcome) in results {
        rows[index].outcome = outcome;
    }
    Ok(rows)
}

mod render;

use render::print_delay_sweep;
