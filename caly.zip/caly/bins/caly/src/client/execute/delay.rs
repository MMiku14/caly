//! Latency probe / sweep / select-by-delay logic.
//!
//! Round 23: extracted from `client/execute.rs` so the
//! 1100+ line `execute.rs` is a 1-page file again
//! (S4.1 advisory). The select-by-delay + sweep
//! pipeline is self-contained: it reads the daemon
//! snapshot, reconciles against the kernel's
//! controller-side proxy list, then probes the
//! surviving nodes with bounded concurrency. The
//! dispatch in `client::execute::execute_core_cmd`
//! reaches in via [`execute_delay_all`] /
//! [`lowest_latency_node`]; nothing else in the
//! `client` tree needs the internals.

use std::process::ExitCode;
use std::sync::PoisonError;

use caly_protocol::client::UdsClient;

use super::hex;
use crate::client::output;

/// Per-probe timeout for the full latency sweep (`delay --all`).
const PROBE_TIMEOUT: std::time::Duration = std::time::Duration::from_secs(5);

/// Maximum concurrent controller probes in one sweep. Bounded so a 267-node
/// subscription never opens one socket/thread per node against the kernel;
/// the kernel serves probes concurrently, but unbounded client fan-out is
/// wasteful and noisy. 32 balances wall-clock time (dead-node probes burn
/// their full per-probe timeout) against connection fan-out.
const MAX_CONCURRENT_PROBES: usize = 32;

/// Latency-sweeps the daemon snapshot's nodes against the active core
/// controller (offline). The controller-side name is derived from the core:
/// sing-box outbounds are tagged `proxy-<canonical-hex>`; Mihomo uses the
/// rendered display name. Output rows carry the node ID so they can feed
/// `core select` directly.
pub(crate) fn execute_delay_all(
    client: &mut UdsClient,
    url: Option<&str>,
    json: bool,
) -> ExitCode {
    match sweep_snapshot_delays(client, url) {
        Ok(rows) => {
            print_delay_sweep(&rows, json);
            ExitCode::SUCCESS
        }
        Err(error) => output::report_failure(&error, json),
    }
}

/// Sweeps the snapshot's registered nodes against the active core controller
/// and returns the lowest-latency reachable one, or `None` when none answers.
/// Every non-reachable outcome is reported so a silent "no node answers" is
/// never confused with a naming/apply mismatch or a controller outage.
pub(crate) fn lowest_latency_node(
    client: &mut UdsClient,
    json: bool,
) -> Option<([u8; 16], String)> {
    let rows = match sweep_snapshot_delays(client, None) {
        Ok(rows) => rows,
        Err(error) => {
            let _ = output::report_failure(&error, json);
            return None;
        }
    };
    let reachable: Vec<(u32, [u8; 16], String)> = rows
        .iter()
        .filter_map(|row| match &row.outcome {
            DelayOutcome::Reachable { samples, .. } => {
                row.outcome
                    .median_ms()
                    .map(|ms| (ms, row.node_id, row.name.clone()))
                    .or_else(|| {
                        // Defensive: an empty
                        // `Reachable` shouldn't
                        // happen (the writer
                        // maps empty to
                        // `Unreachable`), but the
                        // contract is "reachable
                        // has at least one sample".
                        let _ = samples;
                        None
                    })
            }
            _ => None,
        })
        .collect();
    let best = reachable.iter().min_by_key(|(ms, _, _)| *ms);
    if best.is_none() {
        let unreachable = rows
            .iter()
            .filter(|row| row.outcome == DelayOutcome::Unreachable)
            .count();
        let not_in_kernel = rows
            .iter()
            .filter(|row| row.outcome == DelayOutcome::NotInKernel)
            .count();
        let failed = rows
            .iter()
            .filter(|row| row.outcome == DelayOutcome::ProbeFailed)
            .count();
        let _ = output::report_failure(
            &format!(
                "no node answered the latency probe ({unreachable} unreachable, {not_in_kernel} not in the kernel config, {failed} probe errors)"
            ),
            json,
        );
        return None;
    }
    best.map(|(_, node_id, name)| (*node_id, name.clone()))
}

/// How one node's latency probe ended. Every failure mode stays distinct so a
/// sweep never silently collapses a naming/apply mismatch or a controller
/// outage into the same "unreachable" row. The reachable variant carries
/// the full per-sample list (sorted ascending) so the JSON envelope can
/// report `samples` and `jitter_ms` alongside the median.
#[derive(Clone, Debug, Eq, PartialEq)]
enum DelayOutcome {
    /// Kernel answered at least one probe; the
    /// `samples` are sorted ascending in milliseconds.
    /// `median` (the lower middle on even counts) is
    /// the historical single-number summary.
    Reachable {
        samples: Vec<u32>,
        /// URL the kernel answered (stable for this
        /// row; `None` only for the
        /// unreachable-from-every-URL case, but
        /// that lives in the `Unreachable` variant).
        url: String,
    },
    /// Kernel ran the probe but no URL answered.
    Unreachable,
    /// The controller name is not present in the running kernel's proxy set.
    NotInKernel,
    /// Transport/API failure while probing (controller went away, etc.).
    ProbeFailed,
}

impl DelayOutcome {
    /// One-number summary for sorting / printing.
    /// `Reachable` returns the median; every other
    /// variant returns `None` so the caller can
    /// skip the row in `core select --delay`.
    ///
    /// Round 31: delegates to the central
    /// `query::median` helper so the per-node leaf
    /// and the bulk sweep share the same
    /// lower-middle algorithm. The pre-Round 31
    /// shape indexed into the sorted `Vec` with
    /// `len / 2`, which is the upper middle on even
    /// counts (`[50, 200] → 200` instead of the
    /// canonical lower middle 50 — see
    /// `query::median`'s regression test
    /// `even_sample_count_picks_the_lower_middle`).
    fn median_ms(&self) -> Option<u32> {
        match self {
            Self::Reachable { samples, .. } => super::super::query::median(samples),
            _ => None,
        }
    }
}

/// Builds the `Reachable` outcome from a successful
/// probe. Extracted so the worker closure inside
/// `sweep_snapshot_delays` stays under the 100-line
/// clippy ceiling; the helper is trivial but the
/// closure is the hot loop that has to inline-clean.
fn build_reachable_outcome(probe: super::super::query::DelayProbe) -> DelayOutcome {
    let url = probe.url().unwrap_or("").to_owned();
    DelayOutcome::Reachable {
        samples: probe.samples().to_vec(),
        url,
    }
}

/// One row of a latency sweep: the node identity plus its probe outcome.
struct SweepRow {
    node_id: [u8; 16],
    name: String,
    /// Controller-side name used for the probe (and the kernel-set match).
    controller_name: String,
    outcome: DelayOutcome,
}

/// Probes every snapshot node through the active core controller with bounded
/// concurrency. Nodes whose controller name is absent from the kernel's real
/// proxy list are reported as `NotInKernel` without probing: probing them
/// would only yield a 404 that the old algorithm silently rendered as
/// "unreachable" (e.g. a subscription that was never applied).
#[allow(clippy::too_many_lines)]
fn sweep_snapshot_delays(
    client: &mut UdsClient,
    url: Option<&str>,
) -> Result<Vec<SweepRow>, String> {
    use caly_protocol::client::ClientContract;
    let snapshot = client.snapshot().map_err(|error| {
        let _ = error;
        "cannot read the daemon snapshot for the node list (is the daemon running?)".to_owned()
    })?;
    let core = super::active_core_kind(client)
        .map_or_else(|| "mihomo".to_owned(), |kind| kind.label().to_owned());
    let mut rows: Vec<SweepRow> = snapshot
        .nodes
        .iter()
        .map(|node| {
            let controller_name = if core == "sing-box" {
                format!("proxy-{}", caly_domain::to_hex(node.node_id))
            } else {
                node.name.clone()
            };
            SweepRow {
                node_id: node.node_id,
                name: node.name.clone(),
                controller_name,
                outcome: DelayOutcome::Unreachable,
            }
        })
        .collect();
    // Reconcile against the kernel's real proxy set before probing anything, so
    // a stale/unapplied kernel config surfaces as `NotInKernel` instead of a
    // wall of silent 404s.
    let mut control = crate::client::query::build_control(&core)
        .map_err(|error| format!("cannot reach the {core} controller: {error}"))?;
    let kernel_names: std::collections::BTreeSet<String> = control
        .proxy_names(PROBE_TIMEOUT)
        .map_err(|error| format!("cannot read the {core} kernel proxy list: {error}"))?
        .into_iter()
        .collect();
    let mut targets: Vec<(usize, String)> = Vec::new();
    for (index, row) in rows.iter_mut().enumerate() {
        if kernel_names.contains(&row.controller_name) {
            targets.push((index, row.controller_name.clone()));
        } else {
            row.outcome = DelayOutcome::NotInKernel;
        }
    }
    if targets.is_empty() {
        return Ok(rows);
    }
    // Bounded worker pool; each worker owns one controller (fresh secret read)
    // and drains the shared target queue.
    let worker_count = targets.len().min(MAX_CONCURRENT_PROBES);
    let mut controls = Vec::with_capacity(worker_count);
    controls.push(control); // reuse the reconcile controller for probing
    for _ in 1..worker_count {
        if let Ok(control) = crate::client::query::build_control(&core) {
            controls.push(control);
        }
    }
    if controls.is_empty() {
        return Err(format!("cannot build a {core} controller for probing"));
    }
    let shared = std::sync::Mutex::new(targets);
    let shared = &shared;
    let results: Vec<(usize, DelayOutcome)> = std::thread::scope(|scope| {
        let mut workers = Vec::new();
        for mut control in controls {
            workers.push(scope.spawn(move || {
                let mut local = Vec::new();
                loop {
                    let item = {
                        let mut guard = shared.lock().unwrap_or_else(PoisonError::into_inner);
                        guard.pop()
                    };
                    let Some((index, controller_name)) = item else {
                        break;
                    };
                    let outcome = match super::super::query::probe_delay(
                        &mut *control,
                        &controller_name,
                        url,
                        PROBE_TIMEOUT,
                        // The sweep always takes 3 samples:
                        // a single sample is dominated by
                        // TCP slow-start, two is
                        // sensitive to a single
                        // hiccup, three is the
                        // sweet spot. `--samples N` on
                        // the per-node leaf is the
                        // operator-level escape
                        // hatch; the bulk sweep keeps
                        // its own policy so a
                        // 267-node sweep doesn't take
                        // 22 minutes.
                        3,
                    ) {
                        Ok(probe) if probe.is_reachable() => {
                            build_reachable_outcome(probe)
                        }
                        Ok(_) => DelayOutcome::Unreachable,
                        // A probe that outlived the socket budget (the
                        // kernel hung past its own timeout) is unreachable
                        // from the user's viewpoint, not a controller
                        // transport failure; connect failures stay loud.
                        Err(error)
                            if error.kind
                                == caly_kernel::ports::KernelFailureKind::DeadlineExceeded =>
                        {
                            DelayOutcome::Unreachable
                        }
                        Err(_) => DelayOutcome::ProbeFailed,
                    };
                    local.push((index, outcome));
                }
                local
            }));
        }
        workers
            .into_iter()
            .flat_map(|worker| worker.join().ok().into_iter().flatten())
            .collect()
    });
    for (index, outcome) in results {
        rows[index].outcome = outcome;
    }
    Ok(rows)
}

/// Renders one sweep row as a JSON object. The
/// `delay_ms` field is the median (kept for
/// historical `jq .delay_ms` consumers); `jitter_ms`,
/// `min_ms`, `max_ms`, `stdev_ms`, and the full
/// `samples` array are additive so a script
/// consumer can see the spread and the per-sample
/// distribution. `controller_name` is added to
/// every row so a script can grep the kernel-side
/// name even when the snapshot's `name` is a
/// hash-derived label (sing-box).
///
/// Round 31: the JSON envelope now mirrors the
/// per-node `print_delay` shape — the
/// `min_ms` / `max_ms` / `stdev_ms` fields are the
/// same values the per-node `core delay` path
/// reports, so a script consumer can run
/// `core delay <node>` and get the exact same
/// distribution numbers as `delay --all` (the
/// pre-Round 31 shape only reported the median
/// and `jitter` / `samples` in the sweep, so a
/// script consumer had to redo the math to
/// compare the two paths).
fn sweep_row_to_json(row: &SweepRow) -> serde_json::Value {
    use serde_json::json;
    let mut value = match &row.outcome {
        DelayOutcome::Reachable { samples, url } => {
            let median = row.outcome.median_ms();
            let jitter = samples
                .first()
                .zip(samples.last())
                .map_or(0, |(lo, hi)| hi - lo);
            // Round 31: min / max / stdev are
            // derived from the same `samples`
            // vector the JSON envelope
            // already carries. The pre-Round 31
            // shape had only `median_ms` /
            // `jitter_ms` / `samples`; the new
            // shape adds `min_ms` / `max_ms` /
            // `stdev_ms` so a script consumer
            // can read the full distribution
            // shape without re-deriving the
            // numbers from `samples`.
            let min_ms = samples.first().copied();
            let max_ms = samples.last().copied();
            // Round 31: the inline stdev matches
            // `query::DelayProbe::stdev_ms` but
            // is duplicated here because the
            // `SweepRow` shape keeps the samples
            // inside `DelayOutcome::Reachable`
            // (not in a `DelayProbe`), so the
            // helper that lives on `DelayProbe`
            // is not directly reachable. The
            // precision-loss allows mirror the
            // helper's contract: a `n <= 5`
            // sample count under a `5s` timeout
            // is well within `f64`'s 52-bit
            // mantissa, so the `as f64` and
            // `as u32` casts are the
            // intentional (documented) trade.
            #[allow(
                clippy::cast_precision_loss,
                clippy::cast_sign_loss,
                clippy::cast_possible_truncation
            )]
            let stdev_ms = if samples.len() >= 2 {
                let n = samples.len() as u64;
                let sum: u64 = samples.iter().map(|s| u64::from(*s)).sum();
                let mean = sum as f64 / n as f64;
                let variance = samples
                    .iter()
                    .map(|s| {
                        let diff = f64::from(*s) - mean;
                        diff * diff
                    })
                    .sum::<f64>()
                    / n as f64;
                Some(variance.sqrt().round() as u32)
            } else {
                None
            };
            json!({
                "id": hex(row.node_id),
                "name": row.name.as_str(),
                "status": "ok",
                "median_ms": median,
                "delay_ms": median,
                "min_ms": min_ms,
                "max_ms": max_ms,
                "jitter_ms": if samples.len() >= 2 { Some(jitter) } else { None },
                "stdev_ms": stdev_ms,
                "samples": samples,
                "url": url,
            })
        }
        DelayOutcome::Unreachable => json!({
            "id": hex(row.node_id),
            "name": row.name.as_str(),
            "status": "unreachable",
            "median_ms": null,
            "delay_ms": null,
        }),
        DelayOutcome::NotInKernel => json!({
            "id": hex(row.node_id),
            "name": row.name.as_str(),
            "status": "not_in_kernel",
            "median_ms": null,
            "delay_ms": null,
        }),
        DelayOutcome::ProbeFailed => json!({
            "id": hex(row.node_id),
            "name": row.name.as_str(),
            "status": "error",
            "median_ms": null,
            "delay_ms": null,
        }),
    };
    if let serde_json::Value::Object(map) = &mut value {
        map.insert(
            "controller_name".to_owned(),
            serde_json::Value::String(row.controller_name.clone()),
        );
    }
    value
}

/// Renders the delay sweep: reachable first (ascending by median), then
/// unreachable in name order, then nodes missing from the kernel config.
/// Every row includes the node ID for `core select`. The JSON form
/// carries `samples` and `jitter_ms` per reachable row so a script
/// consumer can see the full distribution; the human form prints the
/// median and a one-character jitter glyph.
fn print_delay_sweep(rows: &[SweepRow], json: bool) {
    use serde_json::json;
    let mut reachable: Vec<&SweepRow> = rows
        .iter()
        .filter(|row| matches!(row.outcome, DelayOutcome::Reachable { .. }))
        .collect();
    // Sort by the median (the lower middle), not the
    // min — a node with [50, 200, 800] sorts at 200,
    // the historical `min` policy would have placed
    // it at 50 next to a node that answered 50, 50,
    // 50. The operator's `core select --delay`
    // choice should be the stable one, not the lucky
    // sample.
    reachable.sort_by_key(|row| row.outcome.median_ms().unwrap_or(u32::MAX));
    let unreachable = sorted_by_name(rows, DelayOutcome::Unreachable);
    let not_in_kernel = sorted_by_name(rows, DelayOutcome::NotInKernel);
    let probe_failed = sorted_by_name(rows, DelayOutcome::ProbeFailed);
    if json {
        let rows_json: Vec<serde_json::Value> = rows
            .iter()
            .map(sweep_row_to_json)
            .collect();
        println!(
            "{}",
            json!({
                "probes": rows_json,
                "total": rows.len(),
                "reachable": reachable.len(),
                "unreachable": unreachable.len(),
                "not_in_kernel": not_in_kernel.len(),
                "probe_errors": probe_failed.len(),
            })
        );
        return;
    }
    let suffix = if not_in_kernel.is_empty() {
        String::new()
    } else {
        format!(", {} not in kernel config", not_in_kernel.len())
    };
    let failed_suffix = if probe_failed.is_empty() {
        String::new()
    } else {
        format!(", {} probe errors", probe_failed.len())
    };
    println!(
        "probes: {} total, {} reachable, {} unreachable{suffix}{failed_suffix} (run `core select --delay` for the fastest)",
        rows.len(),
        reachable.len(),
        unreachable.len()
    );
    for row in &reachable {
        let DelayOutcome::Reachable { samples, .. } = &row.outcome else {
            continue;
        };
        let median = row.outcome.median_ms().unwrap_or(0);
        // One-character jitter glyph:
        // `.` — steady (jitter <= 10ms, or single sample)
        // `~` — mild   (jitter <= 25% of median)
        // `!` — spiky  (jitter > 25% of median)
        // The operator learns at a glance which
                        // "fast" nodes are actually reliable.
        let jitter = samples
            .first()
            .zip(samples.last())
            .map_or(0, |(lo, hi)| hi - lo);
        let glyph = if samples.len() < 2 {
            '.'
        } else if median == 0 {
            '~'
        } else if jitter * 4 <= median {
            '.'
        } else if jitter * 4 <= median * 5 {
            '~'
        } else {
            '!'
        };
        print_sweep_row(
            row,
            &format!("{median:>6} ms {glyph}"),
            "",
        );
    }
    for row in &unreachable {
        print_sweep_row(row, "-", "");
    }
    for row in &not_in_kernel {
        print_sweep_row(row, "!", "  not in kernel config");
    }
    for row in &probe_failed {
        print_sweep_row(row, "?", "  probe error");
    }
    if !not_in_kernel.is_empty() {
        println!(
            "hint: nodes not in the running kernel config — run `caly config apply` to publish subscription nodes, then retry `delay --all`"
        );
    }
}

/// Rows with the given outcome, name-ordered (deterministic sweep tables).
fn sorted_by_name(rows: &[SweepRow], outcome: DelayOutcome) -> Vec<&SweepRow> {
    let mut selected: Vec<&SweepRow> = rows.iter().filter(|row| row.outcome == outcome).collect();
    selected.sort_by(|a, b| a.name.cmp(&b.name));
    selected
}

/// Prints one sweep row: `<marker>  <32-hex ID>  <name>[annotation]`.
/// The marker column is fixed-width so every row's ID column aligns.
/// Width 10 accommodates `9999 ms !` (the `!` glyph marks
/// spiky jitter; the per-row human rendering adds a single
/// trailing character so 7 was the historical width and 10
/// covers the four-digit case without clipping).
fn print_sweep_row(row: &SweepRow, marker: &str, annotation: &str) {
    println!(
        "  {marker:<10}  {}  {}{}",
        hex(row.node_id),
        row.name.as_str(),
        annotation
    );
}

#[cfg(test)]
mod sweep_median_tests {
    //! Round 31: the bulk-sweep median must use the
    //! same lower-middle algorithm as the per-node
    //! `core delay` leaf. Pre-Round 31 the
    //! `DelayOutcome::median_ms` helper indexed into
    //! the sorted samples with `len / 2` (the upper
    //! middle on even counts — e.g. `[50, 200]` →
    //! 200 instead of the canonical lower middle
    //! 50). The two callers now share the central
    //! `query::median` helper, so this test pins
    //! the bulk-sweep shape to the same contract
    //! `query::median`'s `even_sample_count_picks_the_lower_middle`
    //! test pins for the per-node leaf.
    use super::{DelayOutcome, SweepRow};

    /// Two reachable samples `[50, 200]` must
    /// report median 50 (lower middle), matching
    /// `query::DelayProbe`'s 2-sample median. The
    /// pre-Round 31 bulk-sweep shape reported 200
    /// (upper middle) — an inconsistency that
    /// made the `core select --delay` winner
    /// disagree with the per-node leaf for any
    /// 2-sample node.
    #[test]
    fn sweep_even_sample_count_picks_the_lower_middle() {
        let outcome = DelayOutcome::Reachable {
            samples: vec![50, 200],
            url: "https://probe.example/".to_owned(),
        };
        assert_eq!(outcome.median_ms(), Some(50));
    }

    /// Three reachable samples `[50, 200, 800]` →
    /// median 200 (the middle). The pre-Round 31
    /// shape also returned 200 for odd counts
    /// (the algorithm was the same as the new
    /// shape modulo the even-counts corner), so
    /// this case is unchanged from before. The
    /// test exists as a forward-compatibility
    /// guard: a future algorithm drift must keep
    /// the canonical 3-sample median.
    #[test]
    fn sweep_three_sample_median_is_the_middle() {
        let outcome = DelayOutcome::Reachable {
            samples: vec![50, 200, 800],
            url: "https://probe.example/".to_owned(),
        };
        assert_eq!(outcome.median_ms(), Some(200));
    }

    /// Four reachable samples `[50, 100, 200, 800]`
    /// → median 100 (the lower middle, the lower of
    /// the two middle indices 1 and 2). The
    /// pre-Round 31 shape reported 200 (the upper
    /// middle). Sorting is assumed upstream
    /// (`DelayProbe::from_raw` sorts on
    /// construction), so the helper indexes
    /// without re-sorting.
    #[test]
    fn sweep_four_sample_count_picks_the_lower_middle() {
        let outcome = DelayOutcome::Reachable {
            samples: vec![50, 100, 200, 800],
            url: "https://probe.example/".to_owned(),
        };
        assert_eq!(outcome.median_ms(), Some(100));
    }

    /// Empty `Reachable` (the kernel dropped every
    /// sample — e.g. an immediate disconnect on
    /// the very first probe) returns `None`, same
    /// as every other non-`Reachable` outcome. The
    /// pre-Round 31 shape returned `Some(0)` for
    /// the empty case (it indexed into a `len = 0`
    /// `Vec` and returned the 0th element, which is
    /// 0 — a value that would have been conflated
    /// with a real 0ms answer). The new shape
    /// treats empty samples as unreachable.
    #[test]
    fn sweep_empty_reachable_returns_none() {
        let outcome = DelayOutcome::Reachable {
            samples: Vec::new(),
            url: "https://probe.example/".to_owned(),
        };
        assert_eq!(outcome.median_ms(), None);
    }

    /// Round 31: the sweep JSON envelope now
    /// surfaces `min_ms` / `max_ms` / `stdev_ms`
    /// alongside the existing `median_ms` /
    /// `jitter_ms` / `samples` triple. The test
    /// pins the envelope shape by serialising a
    /// known `[50, 200, 800]` reachable outcome
    /// and asserting every scalar matches the
    /// canonical derivation: `min = 50`, `max =
    /// 800`, `median = 200`, `jitter = 750`,
    /// `stdev = 324` (rounded from
    /// `sqrt(105000) ≈ 324.04`).
    ///
    /// The shape is the same one the per-node
    /// `print_delay` JSON envelope uses, so a
    /// script consumer running both `core
    /// delay <node>` and `delay --all` can
    /// compare the two paths field-by-field
    /// without re-deriving the math.
    #[test]
    fn sweep_json_envelope_surfaces_min_max_stdev() {
        let row = SweepRow {
            node_id: [0xab; 16],
            name: "node-a".to_owned(),
            controller_name: "proxy-ab".to_owned(),
            outcome: DelayOutcome::Reachable {
                samples: vec![50, 200, 800],
                url: "https://probe.example/".to_owned(),
            },
        };
        let value = super::sweep_row_to_json(&row);
        let obj = value.as_object().unwrap_or_else(|| std::process::abort());
        assert_eq!(obj["status"], "ok");
        assert_eq!(obj["median_ms"], 200);
        assert_eq!(obj["min_ms"], 50);
        assert_eq!(obj["max_ms"], 800);
        assert_eq!(obj["jitter_ms"], 750);
        assert_eq!(obj["stdev_ms"], 324);
        // `delay_ms` is the historical alias for
        // `median_ms`; the sweep envelope keeps
        // it for `jq .delay_ms` consumers that
        // pre-date the `median_ms` rename.
        assert_eq!(obj["delay_ms"], 200);
        assert_eq!(
            obj["samples"],
            serde_json::json!([50, 200, 800])
        );
        assert_eq!(obj["controller_name"], "proxy-ab");
    }

    /// Round 31: a single-sample reachable
    /// outcome reports `min = max = median =
    /// sample` and `stdev = jitter = None`
    /// (no spread to measure). The pre-Round 31
    /// envelope only reported `median` and
    /// `samples`, so a single-sample node's
    /// spread was invisible to script
    /// consumers; the new shape surfaces the
    /// `min` / `max` pair (which collapse to the
    /// single sample) so a `jq` consumer can
    /// see "this node answered exactly one
    /// probe" without inspecting the `samples`
    /// length.
    #[test]
    fn sweep_single_sample_reports_min_max_collapsed() {
        let row = SweepRow {
            node_id: [0xcd; 16],
            name: "node-b".to_owned(),
            controller_name: "proxy-cd".to_owned(),
            outcome: DelayOutcome::Reachable {
                samples: vec![42],
                url: "https://probe.example/".to_owned(),
            },
        };
        let value = super::sweep_row_to_json(&row);
        let obj = value.as_object().unwrap_or_else(|| std::process::abort());
        assert_eq!(obj["min_ms"], 42);
        assert_eq!(obj["max_ms"], 42);
        assert_eq!(obj["median_ms"], 42);
        assert_eq!(obj["stdev_ms"], serde_json::Value::Null);
        assert_eq!(obj["jitter_ms"], serde_json::Value::Null);
    }
}
