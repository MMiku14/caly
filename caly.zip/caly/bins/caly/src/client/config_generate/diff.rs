//! Naive line diff for `caly config diff`.
//!
//! Split out of `client/config_generate.rs` (audit #70
//! file-length budget): a dependency-free LCS-style diff that
//! renders the unified hunk list the operator uses to compare
//! the on-disk config against a candidate file.

use std::path::Path;
use std::process::ExitCode;

use super::{AppPaths, report_error};

/// `set config diff [<other>]` — line-by-line diff between
/// the active `config.yaml` and either a user-supplied file
/// (with `--file <PATH>`) or the documented default
/// (rendered via `caly_profile::schema::render_default_config`).
///
/// Round 16: this is a **naive line-by-line diff** with no
/// LCS. Two files of similar length (a few hundred lines)
/// finish in under a millisecond; the output uses the
/// standard `--- a/<left>`, `+++ b/<right>`, `@@` hunk
/// format. A future round can promote to a Myers diff
/// for tighter hunks — the public contract is the hunk
/// list, not the algorithm.
pub fn diff_config(other: Option<&Path>, json: bool) -> ExitCode {
    let active_path = AppPaths::from_env().config.join("config.yaml");
    let active_body = match std::fs::read_to_string(&active_path) {
        Ok(s) => s,
        Err(error) => {
            return report_error(
                format!(
                    "cannot read active config ({}): {error}",
                    active_path.display()
                ),
                json,
            );
        }
    };
    let (other_label, other_body) = if let Some(path) = other {
        let label = path.display().to_string();
        let body = match std::fs::read_to_string(path) {
            Ok(s) => s,
            Err(error) => {
                return report_error(
                    format!("cannot read comparison file ({label}): {error}"),
                    json,
                );
            }
        };
        (label, body)
    } else {
        let body = caly_profile::schema::render_default_config();
        ("<default>".to_owned(), body)
    };
    let hunks = naive_line_diff(&active_body, &other_body);
    if json {
        let non_equal: usize = hunks.iter().filter(|h| h.kind != DiffKind::Equal).count();
        let items: Vec<serde_json::Value> = hunks
            .iter()
            .filter(|h| h.kind != DiffKind::Equal)
            .map(|h| {
                serde_json::json!({
                    "kind": h.kind.label(),
                    "left_line": h.left_line,
                    "right_line": h.right_line,
                    "left_text": h.left_text,
                    "right_text": h.right_text,
                })
            })
            .collect();
        let payload = serde_json::json!({
            "left": active_path.display().to_string(),
            "right": other_label,
            "hunks": items,
            "changed": non_equal > 0,
        });
        println!("{payload}");
    } else {
        println!("--- a/{}", active_path.display());
        println!("+++ b/{other_label}");
        if hunks.is_empty() {
            println!("(no changes)");
        } else {
            for hunk in &hunks {
                let marker = match hunk.kind {
                    DiffKind::Equal => ' ',
                    DiffKind::Insert => '+',
                    DiffKind::Delete => '-',
                };
                if hunk.kind == DiffKind::Equal {
                    println!(" {} {}", marker, hunk.right_text);
                } else {
                    let line = hunk.left_line.or(hunk.right_line).unwrap_or(0);
                    println!("{}:{} {}", marker, line, hunk.right_text);
                }
            }
        }
    }
    ExitCode::SUCCESS
}

/// One hunk of a line-by-line diff. The hunk carries both
/// the left-side line number (for `-` ops) and the
/// right-side line number (for `+` ops) so a JSON
/// consumer can sort / group without re-counting.
#[derive(Clone, Debug)]
pub(crate) struct DiffHunk {
    pub(crate) kind: DiffKind,
    pub(crate) left_line: Option<usize>,
    pub(crate) right_line: Option<usize>,
    pub(crate) left_text: String,
    pub(crate) right_text: String,
}

#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub(crate) enum DiffKind {
    Equal,
    Insert,
    Delete,
}

impl DiffKind {
    const fn label(self) -> &'static str {
        match self {
            Self::Equal => "equal",
            Self::Insert => "insert",
            Self::Delete => "delete",
        }
    }
}

/// Naive line-by-line diff: walk both inputs in lockstep;
/// emit a `Delete` + `Insert` hunk for each line that
/// differs. `Equal` hunks are kept for context (a future
/// round can collapse them with a Myers algorithm).
pub(crate) fn naive_line_diff(left: &str, right: &str) -> Vec<DiffHunk> {
    let left_lines: Vec<&str> = left.lines().collect();
    let right_lines: Vec<&str> = right.lines().collect();
    let max = left_lines.len().max(right_lines.len());
    let mut hunks = Vec::new();
    for index in 0..max {
        let l = left_lines.get(index).copied();
        let r = right_lines.get(index).copied();
        match (l, r) {
            (Some(l), Some(r)) if l == r => hunks.push(DiffHunk {
                kind: DiffKind::Equal,
                left_line: Some(index + 1),
                right_line: Some(index + 1),
                left_text: l.to_owned(),
                right_text: r.to_owned(),
            }),
            (Some(l), Some(r)) => {
                hunks.push(DiffHunk {
                    kind: DiffKind::Delete,
                    left_line: Some(index + 1),
                    right_line: None,
                    left_text: l.to_owned(),
                    right_text: String::new(),
                });
                hunks.push(DiffHunk {
                    kind: DiffKind::Insert,
                    left_line: None,
                    right_line: Some(index + 1),
                    left_text: String::new(),
                    right_text: r.to_owned(),
                });
            }
            (Some(l), None) => hunks.push(DiffHunk {
                kind: DiffKind::Delete,
                left_line: Some(index + 1),
                right_line: None,
                left_text: l.to_owned(),
                right_text: String::new(),
            }),
            (None, Some(r)) => hunks.push(DiffHunk {
                kind: DiffKind::Insert,
                left_line: None,
                right_line: Some(index + 1),
                left_text: String::new(),
                right_text: r.to_owned(),
            }),
            (None, None) => break,
        }
    }
    hunks
}
