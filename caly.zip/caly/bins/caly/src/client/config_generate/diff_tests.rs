//! Tests for `client/config_generate.rs`, extracted to the sibling
//! convention file (audit #70 file-length budget).

use super::{DiffKind, naive_line_diff};

#[test]
fn identical_inputs_have_no_insert_or_delete_hunks() {
    let left = "schema_version: 1\ncore: mihomo\n";
    let right = "schema_version: 1\ncore: mihomo\n";
    let hunks = naive_line_diff(left, right);
    let non_equal = hunks.iter().filter(|h| h.kind != DiffKind::Equal).count();
    assert_eq!(non_equal, 0, "identical inputs must produce no diff hunks");
}

#[test]
fn insertion_produces_an_insert_hunk() {
    let left = "schema_version: 1\n";
    let right = "schema_version: 1\ncore: mihomo\n";
    let hunks = naive_line_diff(left, right);
    let inserts: Vec<_> = hunks
        .iter()
        .filter(|h| h.kind == DiffKind::Insert)
        .collect();
    assert_eq!(inserts.len(), 1);
    assert_eq!(inserts[0].right_text, "core: mihomo");
    assert_eq!(inserts[0].right_line, Some(2));
}

#[test]
fn deletion_produces_a_delete_hunk() {
    let left = "schema_version: 1\ncore: mihomo\n";
    let right = "schema_version: 1\n";
    let hunks = naive_line_diff(left, right);
    let deletes: Vec<_> = hunks
        .iter()
        .filter(|h| h.kind == DiffKind::Delete)
        .collect();
    assert_eq!(deletes.len(), 1);
    assert_eq!(deletes[0].left_text, "core: mihomo");
    assert_eq!(deletes[0].left_line, Some(2));
}

#[test]
fn replacement_emits_a_delete_then_an_insert() {
    let left = "core: mihomo\n";
    let right = "core: sing-box\n";
    let hunks = naive_line_diff(left, right);
    let inserts: Vec<_> = hunks
        .iter()
        .filter(|h| h.kind == DiffKind::Insert)
        .collect();
    let deletes: Vec<_> = hunks
        .iter()
        .filter(|h| h.kind == DiffKind::Delete)
        .collect();
    assert_eq!(inserts.len(), 1);
    assert_eq!(deletes.len(), 1);
    assert_eq!(inserts[0].right_text, "core: sing-box");
    assert_eq!(deletes[0].left_text, "core: mihomo");
}
