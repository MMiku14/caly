//! Offline subscription writer for the `set sub …` leaves.
//!
//! Round 14: also owns the offline subscription
//! **inspection** surface (`list` / `check` / `import`)
//! that `show sub …` and the legacy `set sub import`
//! preview path go through. The previous home
//! (`commands::bridge`) is being retired; the helpers
//! below are the source of truth.
//!
//! The 5 CRUD writers round-trip
//! `subscriptions.sources: Vec<SubscriptionSource>` and
//! the `providers:` list when an `import` writes inline
//! nodes. The per-source writers live in [`sources`]
//! (audit #70 file-length budget); the inspection
//! surface stays here.

use caly_platform::paths::AppPaths;

use super::resource_writer::{ResourceError, ResourceWriteOutcome};

#[cfg(test)]
use super::resource_writer::is_http_url;

mod sources;

pub use sources::{add_source, disable_source, enable_source, remove_source};

/// Subscription-specific error variants. The shared
/// [`ResourceError`] cases flow through the `Shared(_)` arm.
#[derive(Debug)]
pub enum SubCmdError {
    /// The URL is empty, missing a scheme, or points at a
    /// non-HTTP(S) scheme (the SSRF guard refuses
    /// `file://` and `data://`).
    InvalidUrl(String),
    /// The optional `--name` display name is empty after
    /// trimming, over-long, or contains control characters.
    InvalidName(String),
    /// `add` on a URL that's already in
    /// `subscriptions.sources`.
    AlreadyDeclared(String),
    /// `remove` / `enable` / `disable` on a URL that's
    /// not in `subscriptions.sources`.
    NotDeclared(String),
    /// Any other failure the shared writer surfaces
    /// (read / parse / validate / IO). Carries the
    /// human-readable reason.
    Shared(ResourceError),
}

impl core::fmt::Display for SubCmdError {
    fn fmt(&self, formatter: &mut core::fmt::Formatter<'_>) -> core::fmt::Result {
        match self {
            Self::InvalidUrl(reason) => write!(formatter, "invalid subscription URL: {reason}"),
            Self::InvalidName(reason) => write!(formatter, "invalid source name: {reason}"),
            Self::AlreadyDeclared(url) => {
                write!(formatter, "subscription source `{url}` is already declared")
            }
            Self::NotDeclared(url) => {
                write!(formatter, "subscription source `{url}` is not declared")
            }
            Self::Shared(shared) => write!(formatter, "{shared}"),
        }
    }
}

impl std::error::Error for SubCmdError {}

impl From<ResourceError> for SubCmdError {
    fn from(value: ResourceError) -> Self {
        match value {
            ResourceError::AlreadyDeclared(name) => Self::AlreadyDeclared(name),
            ResourceError::NotDeclared(name) => Self::NotDeclared(name),
            other => Self::Shared(other),
        }
    }
}

impl From<super::config_writer::ConfigWriteError> for SubCmdError {
    fn from(value: super::config_writer::ConfigWriteError) -> Self {
        Self::Shared(ResourceError::from(value))
    }
}

/// Resolves the operator's XDG roots. Mirrors
/// `client::profile::resolve_paths` so the test
/// fixtures can inject a custom `HOME` / `XDG_*` and the
/// behaviour is identical across writers.
pub fn resolve_paths() -> AppPaths {
    AppPaths::from_env()
}

/// Loads the active `AppConfig` from `paths` (so the
/// tests can inject a hermetic root via
/// `AppPaths::from_env_vars(&test_env())`).
pub fn load_declared_with(
    paths: &AppPaths,
) -> Result<caly_profile::schema::AppConfig, SubCmdError> {
    use caly_profile::loader::{InMemoryProfileResolver, LayeredConfigPaths, LoaderLimits};
    let limits = LoaderLimits::secure_default();
    let layered = LayeredConfigPaths::new(paths.config.clone(), None);
    caly_profile::loader::load_layered_yaml_with(
        &layered,
        limits,
        &InMemoryProfileResolver::lenient(),
    )
    .map_err(|error| {
        SubCmdError::Shared(ResourceError::Write(format!(
            "load layered config: {error}"
        )))
    })
}

/// What an `add` / `remove` / `enable` / `disable` /
/// `import` call did. `DryRun` is what `--dry-run` (the
/// default) returns when the call would have written.
pub type SubWriteOutcome = ResourceWriteOutcome;

/// Maximum length (in chars) of a `--name` display name. Mirrors
/// the TUI filter buffer bound so an over-long name never breaks
/// the presentation layer.
pub const MAX_SOURCE_NAME_CHARS: usize = 64;

// ── Round 16: offline subscription inspection ───────────────

/// `show sub providers` — list the configured
/// subscription providers.
pub fn list_providers(json: bool) -> std::process::ExitCode {
    use std::process::ExitCode;
    let root = caly_platform::paths::AppPaths::from_env().config;
    let (declared, providers) = match crate::daemon_config::load_from(root) {
        Ok(None) => (
            caly_profile::schema::SubscriptionConfig::default(),
            Vec::new(),
        ),
        Ok(Some(config)) => (config.subscriptions.clone(), config.resolved_providers()),
        Err(error) => {
            if json {
                eprintln!(
                    "{}",
                    serde_json::json!({ "ok": false, "error": error.to_string() })
                );
            } else {
                eprintln!("subscription list failed: {error}");
            }
            return ExitCode::FAILURE;
        }
    };
    let sources = source_rows(&declared);
    if providers.is_empty() {
        if json {
            println!(
                "{}",
                serde_json::json!({ "providers": [], "sources": sources, "count": 0 })
            );
        } else {
            println!("no subscription provider configured");
            println!(
                "hint: set `subscriptions.url` or `subscriptions.sources` in config.yaml to create the default provider"
            );
        }
        return ExitCode::SUCCESS;
    }
    if json {
        let items: Vec<serde_json::Value> = providers
            .iter()
            .map(|p| provider_json_item(p, &sources))
            .collect();
        println!(
            "{}",
            serde_json::json!({
                "providers": items,
                "sources": sources,
                "count": providers.len(),
            })
        );
    } else {
        for p in &providers {
            print_provider_human(p, &sources);
        }
        println!("{} provider(s)", providers.len());
    }
    ExitCode::SUCCESS
}

/// Renders one provider as its JSON row. Kind-specific
/// payload lives under its own key so consumers never
/// see a subscription provider's source list mirrored
/// onto an inline provider.
fn provider_json_item(
    p: &caly_profile::schema::ProviderConfig,
    sources: &[serde_json::Value],
) -> serde_json::Value {
    use caly_profile::schema::ProviderKind;
    match &p.kind {
        ProviderKind::SubscriptionSources => serde_json::json!({
            "name": p.name,
            "kind": "subscription-sources",
            "source_urls": sources
                .iter()
                .filter(|row| row["enabled"].as_bool() == Some(true))
                .filter_map(|row| row["url"].as_str().map(str::to_owned))
                .collect::<Vec<_>>(),
        }),
        ProviderKind::InlineNodes(nodes) => serde_json::json!({
            "name": p.name,
            "kind": "inline-nodes",
            "nodes": nodes,
        }),
    }
}

/// Prints one provider in the human-readable layout.
fn print_provider_human(p: &caly_profile::schema::ProviderConfig, sources: &[serde_json::Value]) {
    use caly_profile::schema::ProviderKind;
    match &p.kind {
        ProviderKind::SubscriptionSources => {
            println!(
                "provider: {} (enumeration of {} enabled source(s))",
                p.name,
                sources
                    .iter()
                    .filter(|row| row["enabled"].as_bool() == Some(true))
                    .count()
            );
            for row in sources {
                let enabled = if row["enabled"].as_bool() == Some(true) {
                    "enabled"
                } else {
                    "disabled"
                };
                let label = row["name"]
                    .as_str()
                    .map_or_else(String::new, |name| format!(" ({name})"));
                println!(
                    "  [{}] {}{} ({enabled})",
                    row["index"].as_u64().map_or(0, |i| i + 1),
                    row["url"].as_str().unwrap_or(""),
                    label,
                );
            }
        }
        ProviderKind::InlineNodes(nodes) => {
            println!("provider: {} ({} inline node(s))", p.name, nodes.len());
            for n in nodes {
                println!("  - {n}");
            }
        }
    }
}

/// Projects the declared subscription sources into the JSON row
/// model both `list_sources` and `list_providers` print: one row
/// per entry with the real `enabled` flag plus the optional
/// `--name` label (previously every row was hardcoded
/// `enabled: true`). The legacy scalar `subscriptions.url`
/// counts as index 0 when set (it is always enabled).
fn source_rows(declared: &caly_profile::schema::SubscriptionConfig) -> Vec<serde_json::Value> {
    let mut rows = Vec::new();
    if let Some(url) = &declared.url {
        rows.push(serde_json::json!({
            "index": rows.len(), "url": url, "enabled": true,
        }));
    }
    for source in &declared.sources {
        let mut row = serde_json::json!({
            "index": rows.len(), "url": source.url, "enabled": source.enabled,
        });
        if let Some(name) = &source.name {
            row["name"] = serde_json::Value::String(name.clone());
        }
        rows.push(row);
    }
    rows
}

#[cfg(test)]
mod list_render_tests;

/// `show sub parse <path>` — offline subscription
/// summary for one file.
pub fn check_subscription(
    path: &std::path::Path,
    userinfo: Option<&str>,
    json: bool,
) -> std::process::ExitCode {
    use std::process::ExitCode;
    match crate::subscription::inspect_subscription_with_userinfo(path, userinfo) {
        Ok(summary) => {
            if json {
                println!("{}", crate::subscription::render_json(&summary));
            } else {
                print!("{}", crate::subscription::render_human(&summary));
            }
            if crate::subscription::is_usable(&summary) {
                ExitCode::SUCCESS
            } else {
                ExitCode::from(1)
            }
        }
        Err(error) => {
            if json {
                eprintln!(
                    "{}",
                    serde_json::json!({ "ok": false, "error": error.to_string() })
                );
            } else {
                eprintln!("subscription check failed: {error}");
            }
            ExitCode::FAILURE
        }
    }
}

/// `show sub import <path>` / `--clipboard` — parse a
/// URI list and print a preview.
pub fn import_preview(
    path: Option<&std::path::Path>,
    clipboard: bool,
    json: bool,
) -> std::process::ExitCode {
    use std::process::ExitCode;
    let summary = match (clipboard, path) {
        (true, Some(_)) => {
            eprintln!("error: `sub import --clipboard` takes no path argument");
            return ExitCode::from(2);
        }
        (true, None) | (false, None) => crate::subscription::read_clipboard(),
        (false, Some(path)) => crate::subscription::inspect_subscription_with_userinfo(path, None),
    };
    match summary {
        Ok(summary) => {
            if json {
                println!("{}", crate::subscription::render_json(&summary));
            } else {
                print!("{}", crate::subscription::render_human(&summary));
                if summary.format == "url-list" {
                    println!(
                        "This is a subscription *source* (fetchable URL). It is not persisted by `import`; add its URL to `subscriptions.sources` in config.yaml and it will appear in `caly sub list` as the default provider."
                    );
                } else {
                    println!(
                        "Preview only — nothing was saved. These are proxy node URIs (no upstream subscription URL), so they cannot form a subscription provider and won't appear in `sub list`. Paste a source subscription URL for a refreshable provider."
                    );
                }
            }
            if crate::subscription::is_usable(&summary) {
                ExitCode::SUCCESS
            } else {
                ExitCode::from(1)
            }
        }
        Err(error) => {
            if json {
                eprintln!(
                    "{}",
                    serde_json::json!({ "ok": false, "error": error.to_string() })
                );
            } else {
                eprintln!("subscription import failed: {error}");
            }
            ExitCode::FAILURE
        }
    }
}

#[cfg(test)]
mod tests;
