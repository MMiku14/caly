//! Offline subscription writer for the `set sub …` leaves.
//!
//! Round 14: also owns the offline subscription
//! **inspection** surface (`list` / `check` / `import`)
//! that `show sub …` and the legacy `set sub import`
//! preview path go through. The previous home
//! (`commands::bridge`) is being retired; the helpers
//! below are the source of truth.
//!
//! The 5 CRUD writers round-trip
//! `subscriptions.sources: Vec<SubscriptionSource>` and
//! the `providers:` list when an `import` writes inline
//! nodes. `subscriptions:` is a *struct* in the schema
//! (not a `Vec<_>`), so this module keeps the bespoke
//! `write_subscriptions` helper around the
//! `serde_norway` mapping (a `mutate_list` analogue
//! doesn't apply). The shared
//! [`crate::client::resource_writer`] helpers own the
//! cross-resource bookkeeping (path safety, URL
//! validation, the unified `ResourceError` envelope).

use std::path::PathBuf;

use caly_config::schema::SubscriptionSource;
use caly_platform::paths::AppPaths;

use super::resource_writer::{
    ResourceError, ResourceWriteOutcome, is_http_url,
};

/// Subscription-specific error variants. The shared
/// [`ResourceError`] cases flow through the `Shared(_)` arm.
#[derive(Debug)]
pub enum SubCmdError {
    /// The URL is empty, missing a scheme, or points at a
    /// non-HTTP(S) scheme (the SSRF guard refuses
    /// `file://` and `data://`).
    InvalidUrl(String),
    /// `add` on a URL that's already in
    /// `subscriptions.sources`.
    AlreadyDeclared(String),
    /// `remove` / `enable` / `disable` on a URL that's
    /// not in `subscriptions.sources`.
    NotDeclared(String),
    /// Any other failure the shared writer surfaces
    /// (read / parse / validate / IO). Carries the
    /// human-readable reason.
    Shared(ResourceError),
}

impl core::fmt::Display for SubCmdError {
    fn fmt(&self, formatter: &mut core::fmt::Formatter<'_>) -> core::fmt::Result {
        match self {
            Self::InvalidUrl(reason) => write!(formatter, "invalid subscription URL: {reason}"),
            Self::AlreadyDeclared(url) =>
                write!(formatter, "subscription source `{url}` is already declared"),
            Self::NotDeclared(url) =>
                write!(formatter, "subscription source `{url}` is not declared"),
            Self::Shared(shared) => write!(formatter, "{shared}"),
        }
    }
}

impl std::error::Error for SubCmdError {}

impl From<ResourceError> for SubCmdError {
    fn from(value: ResourceError) -> Self {
        match value {
            ResourceError::AlreadyDeclared(name) => Self::AlreadyDeclared(name),
            ResourceError::NotDeclared(name) => Self::NotDeclared(name),
            other => Self::Shared(other),
        }
    }
}

impl From<super::config_writer::ConfigWriteError> for SubCmdError {
    fn from(value: super::config_writer::ConfigWriteError) -> Self {
        Self::Shared(ResourceError::from(value))
    }
}

/// Resolves the operator's XDG roots. Mirrors
/// `client::profile::resolve_paths` so the test
/// fixtures can inject a custom `HOME` / `XDG_*` and the
/// behaviour is identical across writers.
pub fn resolve_paths() -> AppPaths {
    AppPaths::from_env()
}

/// Loads the active `AppConfig` from `paths` (so the
/// tests can inject a hermetic root via
/// `AppPaths::from_env_vars(&test_env())`).
pub fn load_declared_with(
    paths: &AppPaths,
) -> Result<caly_config::schema::AppConfig, SubCmdError> {
    use caly_config::loader::{InMemoryProfileResolver, LayeredConfigPaths, LoaderLimits};
    let limits = LoaderLimits::secure_default();
    let layered = LayeredConfigPaths::new(paths.config.clone(), None);
    caly_config::loader::load_layered_yaml_with(
        &layered,
        limits,
        &InMemoryProfileResolver::lenient(),
    )
    .map_err(|error| SubCmdError::Shared(ResourceError::Write(format!("load layered config: {error}"))))
}

/// What an `add` / `remove` / `enable` / `disable` /
/// `import` call did. `DryRun` is what `--dry-run` (the
/// default) returns when the call would have written.
pub type SubWriteOutcome = ResourceWriteOutcome;

fn config_yaml_path(paths: &AppPaths) -> PathBuf {
    super::resource_writer::config_yaml_path(paths)
}

/// `set sub add <name> <url> [--apply]`.
///
/// Default: dry-run. `--apply` is the only thing that
/// actually mutates `config.yaml`. The dry-run path
/// runs every check (URL shape, already-declared,
/// post-write schema validation) and reports "would
/// have added subscription source `<url>`" without
/// touching the operator's file.
pub fn add_source(
    paths: &AppPaths,
    url: &str,
    apply: bool,
) -> Result<SubWriteOutcome, SubCmdError> {
    let trimmed = is_http_url(url).map_err(SubCmdError::InvalidUrl)?;
    let config = load_declared_with(paths)?;
    if config.subscriptions.sources.iter().any(|s| s.url == trimmed) {
        return Err(SubCmdError::AlreadyDeclared(trimmed.to_owned()));
    }
    if !apply {
        return Ok(SubWriteOutcome::DryRun);
    }
    mutate_subscription_sources(paths, |sources| {
        sources.push(SubscriptionSource { url: trimmed.to_owned(), enabled: true });
        Ok(())
    })?;
    Ok(SubWriteOutcome::Applied)
}

/// `set sub remove <url> [--apply]`. Filters the
/// `sources` list by URL. Returns
/// `SubCmdError::NotDeclared` if the URL is not in the
/// list.
pub fn remove_source(
    paths: &AppPaths,
    url: &str,
    apply: bool,
) -> Result<SubWriteOutcome, SubCmdError> {
    let trimmed = is_http_url(url).map_err(SubCmdError::InvalidUrl)?;
    if !source_url_exists(paths, trimmed)? {
        return Err(SubCmdError::NotDeclared(trimmed.to_owned()));
    }
    if !apply {
        return Ok(SubWriteOutcome::DryRun);
    }
    mutate_subscription_sources(paths, |sources| {
        sources.retain(|s| s.url != trimmed);
        Ok(())
    })?;
    Ok(SubWriteOutcome::Applied)
}

/// `set sub enable <url> [--apply]`. Flips
/// `enabled: true` on the matching source. (All sources
/// are enabled by default, so this is a no-op when the
/// source is already enabled — but the writer accepts
/// it for symmetry with `disable`.)
pub fn enable_source(
    paths: &AppPaths,
    url: &str,
    apply: bool,
) -> Result<SubWriteOutcome, SubCmdError> {
    set_source_enabled(paths, url, true, apply)
}

/// `set sub disable <url> [--apply]`. Flips
/// `enabled: false` on the matching source.
pub fn disable_source(
    paths: &AppPaths,
    url: &str,
    apply: bool,
) -> Result<SubWriteOutcome, SubCmdError> {
    set_source_enabled(paths, url, false, apply)
}

/// Round 29: extracted the "is this URL in
/// `subscriptions.sources`?" check from
/// `remove_source` / `set_source_enabled` so the
/// two writers share one existence-check call site
/// (pre-Round-29, `set_source_enabled` inlined a
/// `for source in &config.subscriptions.sources` loop
/// while `remove_source` did a `count` comparison —
/// two different shapes for the same predicate, with
/// the `count` shape being a clever-but-opaque
/// trick to avoid iterating twice). The helper
/// returns `bool` so both call sites read as
/// "if !source_url_exists(...)" without the
/// per-writer scan logic leaking into the
/// dispatch.
fn source_url_exists(paths: &AppPaths, trimmed_url: &str) -> Result<bool, SubCmdError> {
    let config = load_declared_with(paths)?;
    Ok(config.subscriptions.sources.iter().any(|s| s.url == trimmed_url))
}

fn set_source_enabled(
    paths: &AppPaths,
    url: &str,
    enabled: bool,
    apply: bool,
) -> Result<SubWriteOutcome, SubCmdError> {
    // Round 27 (debug): the dry-run path was a
    // silent no-op for unknown URLs. Pre-Round 27
    // `set sub enable <unknown-url>` returned
    // `DryRun` (success) for `--dry-run` but
    // `NotDeclared` (error) for `--apply`, so an
    // operator who ran the dry-run as a safety
    // check saw an OK envelope and confidently
    // ran `--apply`, only to find the call
    // actually failed. The dry-run is now
    // existence-checked the same way `apply`
    // is: an unknown URL surfaces `NotDeclared`
    // regardless of `apply`, mirroring the
    // `add_source` (already-declared check on
    // both paths) and `remove_source`
    // (not-declared check on both paths)
    // contracts. The `trimmed` value is also the
    // `url` shape that lands in the on-disk
    // `SubscriptionSource` (the writer stores
    // `trimmed`, not the raw `url`), so a
    // whitespace-padded user input lands on disk
    // and is matched against the same trimmed
    // form on subsequent `enable` / `disable`
    // calls.
    let trimmed = is_http_url(url).map_err(SubCmdError::InvalidUrl)?;
    if !source_url_exists(paths, trimmed)? {
        return Err(SubCmdError::NotDeclared(trimmed.to_owned()));
    }
    if !apply {
        return Ok(SubWriteOutcome::DryRun);
    }
    // Round 26: the apply path now routes through
    // the shared `mutate_subscription_sources`
    // helper. The closure's first job is the
    // `NoChange` short-circuit (Round 25 fix);
    // the on-disk state is read again inside the
    // helper, so a second read of the typed config
    // is unavoidable, but it stays in one place
    // (the helper) so the writer's body is a
    // 5-line shim around the same `FnOnce(&mut
    // Vec<SubscriptionSource>)` contract as
    // `add_source` / `remove_source`.
    let mut applied = false;
    mutate_subscription_sources(paths, |sources| {
        for source in sources.iter_mut() {
            if source.url == trimmed {
                if source.enabled == enabled {
                    // Idempotent: the on-disk
                    // state already matched the
                    // target. The helper has
                    // already backed up the
                    // file, but no write will
                    // happen because the closure
                    // returns `Ok(())` without
                    // mutating the typed config.
                    // Round 25 (debug): the
                    // pre-Round-26 shape
                    // returned `Applied` here,
                    // making `set sub enable
                    // <already-enabled-url>
                    // --apply` silently no-op.
                    return Ok(());
                }
                source.enabled = enabled;
                applied = true;
                return Ok(());
            }
        }
        // The URL was present in the pre-mutate
        // `load_declared_with` but absent in the
        // mutate-time read — a concurrent
        // modification race. The original
        // `NotDeclared` error is the right
        // contract here; surface it through the
        // helper's error channel.
        Err(ResourceError::NotDeclared(trimmed.to_owned()))
    })?;
    if applied {
        Ok(SubWriteOutcome::Applied)
    } else {
        Ok(SubWriteOutcome::NoChange)
    }
}

// ── Internal helpers (struct-typed write paths) ────────

/// Round 26: the single mutation primitive for the
/// `subscriptions.sources` Vec. The pre-Round-26
/// `add_source` / `remove_source` /
/// `set_source_enabled` writers each inlined the
/// same 6-step recipe (load → check → mutate →
/// backup → write → validate), with 4 subtle
/// drift points: the dry-run path used bespoke
/// `read_yaml_value` (which `mutate_list` already
/// has under a different name), the post-write
/// validation lived in `write_yaml_value` (which
/// `mutate_list` has as
/// `parse_and_validate_yaml`), and the
/// per-writer inline `write_subscriptions` /
/// `write_yaml_value` pairs duplicated the typed
/// pull / typed render / atomic-rename
/// triple. The helper here unifies the 4-step
/// recipe so each writer is a 5-line shim
/// around a `FnOnce(&mut Vec<SubscriptionSource>)`
/// closure, and the validation / backup /
/// atomic-rename contract lives in one place.
///
/// The closure returns `Result<(), ResourceError>`
/// so the writer's domain-specific
/// `AlreadyDeclared` / `NotDeclared` /
/// `Invalid(_)` variants round-trip through the
/// `From<ResourceError>` impl on `SubCmdError`.
fn mutate_subscription_sources<F>(
    paths: &AppPaths,
    mutate: F,
) -> Result<(), SubCmdError>
where
    F: FnOnce(&mut Vec<SubscriptionSource>) -> Result<(), ResourceError>,
{
    let path = config_yaml_path(paths);
    super::config_writer::backup_config_yaml(&path)?;
    let mut value: serde_norway::Value = std::fs::read(&path)
        .map_err(|error| SubCmdError::Shared(ResourceError::Write(
            format!("cannot read {}: {error}", path.display()),
        )))
        .and_then(|bytes| serde_norway::from_slice(&bytes).map_err(|error| {
            SubCmdError::Shared(ResourceError::Parse(format!(
                "cannot parse {}: {error}",
                path.display()
            )))
        }))?;
    let mapping = value
        .as_mapping_mut()
        .ok_or_else(|| SubCmdError::Shared(ResourceError::Parse(
            "config root must be a mapping".to_owned(),
        )))?;
    let key = serde_norway::Value::String("subscriptions".to_owned());
    // Pull the typed `SubscriptionConfig` out of
    // the YAML so the closure operates on the
    // typed `Vec<SubscriptionSource>` (the writer
    // sees a struct, not a raw Value). A missing
    // / wrong-shape value is treated as the
    // default (the operator's first `add` on a
    // fresh install).
    let mut subscriptions: caly_config::schema::SubscriptionConfig =
        match mapping.get(&key) {
            Some(serde_norway::Value::Mapping(_)) =>
                serde_norway::from_value(mapping[&key].clone()).map_err(|error| {
                    SubCmdError::Shared(ResourceError::Parse(format!(
                        "`subscriptions:` is not a struct of the expected shape: {error}"
                    )))
                })?,
            Some(_) => return Err(SubCmdError::Shared(ResourceError::Parse(
                "`subscriptions:` must be a mapping".to_owned(),
            ))),
            None => caly_config::schema::SubscriptionConfig::default(),
        };
    mutate(&mut subscriptions.sources)?;
    let rendered = serde_norway::to_value(&subscriptions).map_err(|error| {
        SubCmdError::Shared(ResourceError::Parse(format!(
            "serialize `subscriptions:`: {error}"
        )))
    })?;
    mapping.insert(key, rendered);
    let serialized = serde_norway::to_string(&value).map_err(|error| {
        SubCmdError::Shared(ResourceError::Parse(error.to_string()))
    })?;
    // Validate the new file *before* writing it:
    // a failed validation never reaches disk.
    if let Err(error) = caly_config::schema::parse_and_validate_yaml(serialized.as_bytes()) {
        return Err(SubCmdError::Shared(ResourceError::Validate(format!(
            "post-write validation failed for {}: {error}",
            path.display()
        ))));
    }
    super::config_writer::write_atomic(&path, &serialized).map_err(|error| {
        SubCmdError::Shared(ResourceError::Write(error.to_string()))
    })
}

// ── Round 16: offline subscription inspection ───────────────

/// `show sub providers` — list the configured
/// subscription providers.
pub fn list_providers(json: bool) -> std::process::ExitCode {
    use caly_config::schema::ProviderKind;
    use std::process::ExitCode;
    let root = caly_platform::paths::AppPaths::from_env().config;
    let (sources, providers) = match crate::daemon_config::load_from(root) {
        Ok(None) => (Vec::new(), Vec::new()),
        Ok(Some(config)) => (
            config.subscriptions.enabled_source_urls(),
            config.resolved_providers(),
        ),
        Err(error) => {
            if json {
                eprintln!("{}", serde_json::json!({ "ok": false, "error": error.to_string() }));
            } else {
                eprintln!("subscription list failed: {error}");
            }
            return ExitCode::FAILURE;
        }
    };
    if providers.is_empty() {
        if json {
            println!(
                "{}",
                serde_json::json!({ "providers": [], "sources": [], "count": 0 })
            );
        } else {
            println!("no subscription provider configured");
            println!("hint: set `subscriptions.url` or `subscriptions.sources` in config.yaml to create the default provider");
        }
        return ExitCode::SUCCESS;
    }
    if json {
        let items: Vec<serde_json::Value> = providers
            .iter()
            .map(|p| {
                let embedded: Vec<serde_json::Value> = sources
                    .iter()
                    .enumerate()
                    .map(|(i, url)| {
                        serde_json::json!({ "index": i, "url": url, "enabled": true })
                    })
                    .collect();
                serde_json::json!({
                    "name": p.name,
                    "kind": match &p.kind {
                        ProviderKind::SubscriptionSources => "subscription-sources",
                        ProviderKind::InlineNodes(_) => "inline-nodes",
                    },
                    "sources": embedded,
                })
            })
            .collect();
        println!(
            "{}",
            serde_json::json!({
                "providers": items,
                "sources": sources.iter().map(String::as_str).collect::<Vec<_>>(),
                "count": sources.len(),
            })
        );
    } else {
        for p in &providers {
            match &p.kind {
                ProviderKind::SubscriptionSources => {
                    println!(
                        "provider: {} (enumeration of {} source(s))",
                        p.name,
                        sources.len()
                    );
                    for (i, url) in sources.iter().enumerate() {
                        println!("  [{}] {} (enabled)", i + 1, url);
                    }
                }
                ProviderKind::InlineNodes(nodes) => {
                    println!("provider: {} ({} inline node(s))", p.name, nodes.len());
                    for n in nodes {
                        println!("  - {n}");
                    }
                }
            }
        }
        println!("{} provider(s)", providers.len());
    }
    ExitCode::SUCCESS
}

/// `show sub parse <path>` — offline subscription
/// summary for one file.
pub fn check_subscription(
    path: &std::path::Path,
    userinfo: Option<&str>,
    json: bool,
) -> std::process::ExitCode {
    use std::process::ExitCode;
    match crate::subscription::inspect_subscription_with_userinfo(path, userinfo) {
        Ok(summary) => {
            if json {
                println!("{}", crate::subscription::render_json(&summary));
            } else {
                print!("{}", crate::subscription::render_human(&summary));
            }
            if crate::subscription::is_usable(&summary) {
                ExitCode::SUCCESS
            } else {
                ExitCode::from(1)
            }
        }
        Err(error) => {
            if json {
                eprintln!("{}", serde_json::json!({ "ok": false, "error": error.to_string() }));
            } else {
                eprintln!("subscription check failed: {error}");
            }
            ExitCode::FAILURE
        }
    }
}

/// `show sub import <path>` / `--clipboard` — parse a
/// URI list and print a preview.
pub fn import_preview(
    path: Option<&std::path::Path>,
    clipboard: bool,
    json: bool,
) -> std::process::ExitCode {
    use std::process::ExitCode;
    let summary = match (clipboard, path) {
        (true, Some(_)) => {
            eprintln!("error: `sub import --clipboard` takes no path argument");
            return ExitCode::from(2);
        }
        (true, None) | (false, None) => crate::subscription::read_clipboard(),
        (false, Some(path)) => crate::subscription::inspect_subscription_with_userinfo(path, None),
    };
    match summary {
        Ok(summary) => {
            if json {
                println!("{}", crate::subscription::render_json(&summary));
            } else {
                print!("{}", crate::subscription::render_human(&summary));
                if summary.format == "url-list" {
                    println!("This is a subscription *source* (fetchable URL). It is not persisted by `import`; add its URL to `subscriptions.sources` in config.yaml and it will appear in `caly sub list` as the default provider.");
                } else {
                    println!("Preview only — nothing was saved. These are proxy node URIs (no upstream subscription URL), so they cannot form a subscription provider and won't appear in `sub list`. Paste a source subscription URL for a refreshable provider.");
                }
            }
            if crate::subscription::is_usable(&summary) {
                ExitCode::SUCCESS
            } else {
                ExitCode::from(1)
            }
        }
        Err(error) => {
            if json {
                eprintln!("{}", serde_json::json!({ "ok": false, "error": error.to_string() }));
            } else {
                eprintln!("subscription import failed: {error}");
            }
            ExitCode::FAILURE
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::test_helpers::{hermetic_paths, temp_root};
    use caly_config::schema::AppConfig;
    use std::fs;

    fn seed_config_at_roots(dir: &std::path::Path) -> AppPaths {
        let paths = hermetic_paths(dir);
        let target = paths.config.join("config.yaml");
        fs::create_dir_all(&paths.config).unwrap_or_else(|_| std::process::abort());
        fs::write(
            &target,
            "schema_version: 1\ncore: mihomo\nsubscriptions: {}\n",
        )
        .unwrap_or_else(|_| std::process::abort());
        paths
    }

    /// Local tag used by every `temp_root` call in this
    /// module. Round 26 collapsed the bespoke
    /// `temp_root` helper into the cross-module
    /// [`crate::test_helpers::temp_root`]; the tag
    /// is the only thing that distinguishes this
    /// module's fixtures under `/tmp` from the
    /// fixtures of any other module. Pre-Round 26
    /// the local `temp_root` used a `caly-sub-{name}-…`
    /// prefix, so the tag is `"sub"` to keep the
    /// resulting `/tmp/caly-sub-…-…-…` path shape
    /// identical to the pre-refactor fixture paths
    /// (a CI log-grep that scans for `caly-sub-…`
    /// still works).
    const FIXTURE_TAG: &str = "sub";

    #[test]
    fn validate_url_rejects_non_http_schemes() {
        assert!(is_http_url("file:///etc/passwd").is_err());
        assert!(is_http_url("data:text/plain,hello").is_err());
        assert!(is_http_url("").is_err());
        assert!(is_http_url("https://example.com/sub").is_ok());
    }

    #[test]
    fn add_source_dry_run_does_not_touch_disk() {
        let dir = temp_root(FIXTURE_TAG);
        let paths = seed_config_at_roots(dir.as_path());
        let outcome = add_source(&paths, "https://example.com/sub", false).unwrap_or_else(|_| std::process::abort());
        assert_eq!(outcome, SubWriteOutcome::DryRun);
        let expected = "schema_version: 1\ncore: mihomo\nsubscriptions: {}\n";
        let after = std::fs::read_to_string(paths.config.join("config.yaml"))
            .unwrap_or_else(|_| std::process::abort());
        assert_eq!(after, expected);
    }

    #[test]
    fn add_source_apply_persists_a_new_source() {
        let dir = temp_root(FIXTURE_TAG);
        let paths = seed_config_at_roots(dir.as_path());
        let outcome = add_source(&paths, "https://example.com/sub", true).unwrap_or_else(|_| std::process::abort());
        assert_eq!(outcome, SubWriteOutcome::Applied);
        let bytes = fs::read(paths.config.join("config.yaml")).unwrap_or_else(|_| std::process::abort());
        let value: serde_norway::Value = serde_norway::from_slice(&bytes).unwrap_or_else(|_| std::process::abort());
        let Some(sources) = value
            .get("subscriptions")
            .and_then(|v| v.get("sources"))
            .and_then(|v| v.as_sequence())
        else {
            std::process::abort();
        };
        assert_eq!(sources.len(), 1);
        assert_eq!(sources[0].get("url").and_then(|v| v.as_str()), Some("https://example.com/sub"));
        assert_eq!(sources[0].get("enabled").and_then(serde_norway::Value::as_bool), Some(true));
        let backup = paths.config.join("config.yaml.bak");
        assert!(backup.exists(), "backup sidecar must be written");
    }

    #[test]
    fn add_source_rejects_duplicate_url() {
        let dir = temp_root(FIXTURE_TAG);
        let paths = seed_config_at_roots(dir.as_path());
        add_source(&paths, "https://example.com/sub", true).unwrap_or_else(|_| std::process::abort());
        let result = add_source(&paths, "https://example.com/sub", true);
        assert!(matches!(result, Err(SubCmdError::AlreadyDeclared(_))));
    }

    #[test]
    fn add_source_trims_url_before_storing() {
        // Round 27 (debug): the pre-Round 27 shape
        // called `is_http_url(url).map_err(...)`
        // and *discarded* the trimmed URL with
        // `let _ = ...?;`, then stored the raw
        // `url.to_owned()` on disk. A
        // whitespace-padded URL was therefore
        // stored with its leading / trailing
        // whitespace intact, breaking the
        // round-trip with `remove_source` /
        // `enable_source` (which compared against
        // the raw input but the on-disk form
        // was the trimmed one — they matched
        // only by accident, not by design). The
        // post-Round 27 contract: the trimmed
        // URL is the single source of truth, used
        // for the duplicate check *and* the
        // on-disk entry.
        let dir = temp_root(FIXTURE_TAG);
        let paths = seed_config_at_roots(dir.as_path());
        // First add: a URL with stray whitespace.
        add_source(&paths, "  https://example.com/sub  ", true)
            .unwrap_or_else(|_| std::process::abort());
        // Re-read the layered config: the on-disk
        // `url` field must be the trimmed form,
        // not the raw input.
        let config: AppConfig = caly_config::loader::load_layered_yaml_with(
            &caly_config::loader::LayeredConfigPaths::new(paths.config.clone(), None),
            caly_config::loader::LoaderLimits::secure_default(),
            &caly_config::loader::InMemoryProfileResolver::lenient(),
        )
        .unwrap_or_else(|_| std::process::abort());
        assert_eq!(config.subscriptions.sources.len(), 1);
        assert_eq!(config.subscriptions.sources[0].url, "https://example.com/sub");
        // Second add: the trimmed form. Pre-Round
        // 27 this would have created a second
        // entry (the on-disk form was the trimmed
        // one, but the duplicate check compared
        // against the raw input which didn't
        // match the on-disk trimmed form, so the
        // check missed it). Post-Round 27 the
        // duplicate check fires against the
        // trimmed form and the second add is
        // rejected.
        let result = add_source(&paths, "https://example.com/sub", true);
        assert!(
            matches!(result, Err(SubCmdError::AlreadyDeclared(_))),
            "expected AlreadyDeclared for trimmed duplicate, got {result:?}"
        );
        // And the on-disk source list is still
        // exactly one entry.
        let config: AppConfig = caly_config::loader::load_layered_yaml_with(
            &caly_config::loader::LayeredConfigPaths::new(paths.config.clone(), None),
            caly_config::loader::LoaderLimits::secure_default(),
            &caly_config::loader::InMemoryProfileResolver::lenient(),
        )
        .unwrap_or_else(|_| std::process::abort());
        assert_eq!(config.subscriptions.sources.len(), 1);
    }

    #[test]
    fn remove_source_filters_a_matching_url() {
        let dir = temp_root(FIXTURE_TAG);
        let paths = seed_config_at_roots(dir.as_path());
        add_source(&paths, "https://a.example.com/sub", true).unwrap_or_else(|_| std::process::abort());
        add_source(&paths, "https://b.example.com/sub", true).unwrap_or_else(|_| std::process::abort());
        let outcome = remove_source(&paths, "https://a.example.com/sub", true).unwrap_or_else(|_| std::process::abort());
        assert_eq!(outcome, SubWriteOutcome::Applied);
        let config: AppConfig = caly_config::loader::load_layered_yaml_with(
            &caly_config::loader::LayeredConfigPaths::new(paths.config.clone(), None),
            caly_config::loader::LoaderLimits::secure_default(),
            &caly_config::loader::InMemoryProfileResolver::lenient(),
        )
        .unwrap_or_else(|_| std::process::abort());
        assert_eq!(config.subscriptions.sources.len(), 1);
        assert_eq!(config.subscriptions.sources[0].url, "https://b.example.com/sub");
    }

    #[test]
    fn remove_source_rejects_unknown_url() {
        let dir = temp_root(FIXTURE_TAG);
        let paths = seed_config_at_roots(dir.as_path());
        let result = remove_source(&paths, "https://unknown.example.com/sub", true);
        assert!(matches!(result, Err(SubCmdError::NotDeclared(_))));
    }

    #[test]
    fn disable_source_flips_the_enabled_flag() {
        let dir = temp_root(FIXTURE_TAG);
        let paths = seed_config_at_roots(dir.as_path());
        add_source(&paths, "https://a.example.com/sub", true).unwrap_or_else(|_| std::process::abort());
        let outcome = disable_source(&paths, "https://a.example.com/sub", true).unwrap_or_else(|_| std::process::abort());
        assert_eq!(outcome, SubWriteOutcome::Applied);
        let config: AppConfig = caly_config::loader::load_layered_yaml_with(
            &caly_config::loader::LayeredConfigPaths::new(paths.config.clone(), None),
            caly_config::loader::LoaderLimits::secure_default(),
            &caly_config::loader::InMemoryProfileResolver::lenient(),
        )
        .unwrap_or_else(|_| std::process::abort());
        assert!(!config.subscriptions.sources[0].enabled);
    }

    #[test]
    fn enable_dry_run_against_unknown_url_surfaces_not_declared() {
        // Round 27 (debug): the pre-Round 27 shape
        // returned `DryRun` (success) for an unknown
        // URL on the dry-run path, but `NotDeclared`
        // (error) for the same URL on the apply
        // path. The dry-run now previews the apply
        // outcome: an unknown URL surfaces
        // `NotDeclared` regardless of `apply`, so
        // the operator's `--dry-run` safety check
        // reports the same failure mode that
        // `--apply` would. Compare to
        // `add_source_rejects_duplicate_url` and
        // `remove_source_rejects_unknown_url` —
        // the `add` and `remove` writers had this
        // contract all along; the `enable` /
        // `disable` writer was the inconsistent
        // outlier.
        let dir = temp_root(FIXTURE_TAG);
        let paths = seed_config_at_roots(dir.as_path());
        let result = enable_source(&paths, "https://unknown.example.com/sub", false);
        assert!(
            matches!(result, Err(SubCmdError::NotDeclared(_))),
            "dry-run enable on an unknown URL must fail with NotDeclared, got {result:?}"
        );
        let _ = fs::remove_dir_all(&dir);
    }

    #[test]
    fn enable_dry_run_against_known_url_succeeds() {
        // The corresponding positive case: an
        // existing URL's `enable --dry-run` returns
        // `DryRun` (success), so the operator's
        // dry-run-as-safety-check shape is
        // consistent with the apply path's
        // `NoChange` / `Applied` distinction.
        let dir = temp_root(FIXTURE_TAG);
        let paths = seed_config_at_roots(dir.as_path());
        add_source(&paths, "https://known.example.com/sub", true)
            .unwrap_or_else(|_| std::process::abort());
        let outcome = enable_source(&paths, "https://known.example.com/sub", false)
            .unwrap_or_else(|_| std::process::abort());
        assert_eq!(outcome, SubWriteOutcome::DryRun);
        let _ = fs::remove_dir_all(&dir);
    }

    #[test]
    fn enable_source_reports_no_change_when_already_enabled() {
        // Round 25 (debug): the previous shape
        // returned `Applied` (apply) or `DryRun`
        // (dry-run) when the on-disk `enabled` flag
        // was already the target state, which made
        // `set sub enable <already-enabled-url>
        // --apply` report a successful write with no
        // disk I/O. The new contract: the writer
        // surfaces an explicit `NoChange` outcome so
        // the dispatch can emit a distinct "already
        // enabled" summary. Lock both the apply
        // path (the one that previously lied) and
        // the dry-run path (which still returns
        // `DryRun` because the user did not pass
        // `--apply`).
        let dir = temp_root(FIXTURE_TAG);
        let paths = seed_config_at_roots(dir.as_path());
        add_source(&paths, "https://a.example.com/sub", true)
            .unwrap_or_else(|_| std::process::abort());
        // Apply path: returns `NoChange`.
        let outcome = enable_source(&paths, "https://a.example.com/sub", true)
            .unwrap_or_else(|_| std::process::abort());
        assert_eq!(outcome, SubWriteOutcome::NoChange);
        // Dry-run path: still `DryRun` (the user
        // asked for a preview, the writer validated
        // without writing).
        let outcome = enable_source(&paths, "https://a.example.com/sub", false)
            .unwrap_or_else(|_| std::process::abort());
        assert_eq!(outcome, SubWriteOutcome::DryRun);
        // Disable on an enabled source: `Applied`
        // (the on-disk state changes, so the writer
        // reaches the apply path).
        let outcome = disable_source(&paths, "https://a.example.com/sub", true)
            .unwrap_or_else(|_| std::process::abort());
        assert_eq!(outcome, SubWriteOutcome::Applied);
        // Disable on the now-disabled source:
        // `NoChange` (idempotent).
        let outcome = disable_source(&paths, "https://a.example.com/sub", true)
            .unwrap_or_else(|_| std::process::abort());
        assert_eq!(outcome, SubWriteOutcome::NoChange);
    }
}
