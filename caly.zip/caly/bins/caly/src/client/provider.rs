//! Audit #61: the `set provider` writer — the CLI management
//! plane for the `providers:` section.
//!
//! The schema (`ProviderConfig` / `ProviderKind`), the resolved
//! view (`resolved_providers()`) and the `sub list` display
//! existed, but the only way to declare an `InlineNodes`
//! provider was to hand-edit YAML (`sub import` is a
//! preview-only path). This module adds the three mutation
//! leaves every other `set` resource has:
//!
//! - `add-sources <name>` — declare a provider aggregating
//!   every enabled subscription source,
//! - `add-nodes <name> <uri>…` — declare an inline-node
//!   provider (bare `vmess://` / `ss://` URIs),
//! - `remove <name>` — drop a provider from `providers:`.
//!
//! The write path is the shared
//! [`super::resource_writer::mutate_list`] primitive, so the
//! dry-run-first contract, the targeted line edit (#15) and
//! the idempotent `NoChange` short-circuit (#16) all apply.

use caly_platform::paths::AppPaths;
use caly_profile::schema::{ProviderConfig, ProviderKind};

use super::resource_writer::{
    ListEditOutcome, ResourceError, ResourceWriteOutcome, is_path_safe_name, mutate_list,
};

/// What an `add` / `remove` call did (re-exported as the
/// dispatch's expected `Outcome` shape).
pub type ProviderWriteOutcome = ResourceWriteOutcome;

/// Provider-writer failure variants. The shared
/// [`ResourceError`] cases flow through the `Shared(_)` arm
/// so the dispatch has one `match`.
#[derive(Debug)]
pub enum ProviderWriteError {
    /// The id is empty or not path-safe ASCII.
    InvalidName(String),
    /// An inline node URI failed the schema-level parse.
    InvalidNode(String),
    /// `add` on a name that's already declared.
    AlreadyDeclared(String),
    /// `remove` on a name that's not declared.
    NotDeclared(String),
    /// Any other failure the shared writer surfaces.
    Shared(ResourceError),
}

impl core::fmt::Display for ProviderWriteError {
    fn fmt(&self, formatter: &mut core::fmt::Formatter<'_>) -> core::fmt::Result {
        match self {
            Self::InvalidName(name) => {
                write!(formatter, "provider name `{name}` is not path-safe ASCII")
            }
            Self::InvalidNode(reason) => write!(formatter, "{reason}"),
            Self::AlreadyDeclared(name) => {
                write!(formatter, "provider `{name}` is already declared")
            }
            Self::NotDeclared(name) => write!(formatter, "provider `{name}` is not declared"),
            Self::Shared(error) => write!(formatter, "{error}"),
        }
    }
}

impl std::error::Error for ProviderWriteError {}

impl From<ResourceError> for ProviderWriteError {
    fn from(value: ResourceError) -> Self {
        Self::Shared(value)
    }
}

/// Is `name` declared in `providers:`? Both the apply and
/// dry-run paths share the check so an unknown name reports
/// `NotDeclared` (and a duplicate `AlreadyDeclared`) on the
/// dry-run too — the Round 27 consistent-UX contract.
fn provider_exists(paths: &AppPaths, name: &str) -> Result<bool, ProviderWriteError> {
    let config = super::resource_writer::load_app_config(paths)?;
    Ok(config
        .providers
        .iter()
        .any(|provider| provider.name == name))
}

/// Trim + schema-parse every inline node URI. The parse is
/// validation-only: the subscription id is part of the node
/// identity, not of the URI's syntactic validity, so a zeroed
/// placeholder is fine (mirrors the schema validator).
fn validate_nodes(nodes: &[String]) -> Result<Vec<String>, ProviderWriteError> {
    let placeholder = caly_domain::SubscriptionId::from_bytes([0u8; 16]);
    let mut checked = Vec::with_capacity(nodes.len());
    for raw in nodes {
        let uri = raw.trim();
        if uri.is_empty() {
            return Err(ProviderWriteError::InvalidNode(
                "inline node URI is empty".to_owned(),
            ));
        }
        caly_subscription::parse_any_proxy_uri(uri, placeholder).map_err(|error| {
            ProviderWriteError::InvalidNode(format!("inline node `{uri}` is invalid: {error:?}"))
        })?;
        checked.push(uri.to_owned());
    }
    Ok(checked)
}

fn add_provider(
    paths: &AppPaths,
    name: &str,
    kind: ProviderKind,
    apply: bool,
) -> Result<ProviderWriteOutcome, ProviderWriteError> {
    if provider_exists(paths, name)? {
        return Err(ProviderWriteError::AlreadyDeclared(name.to_owned()));
    }
    if !apply {
        return Ok(ProviderWriteOutcome::DryRun);
    }
    let target = name.to_owned();
    let outcome = mutate_list::<ProviderConfig, _>(paths, "providers", |current| {
        if current.iter().any(|provider| provider.name == target) {
            return Err(ResourceError::AlreadyDeclared(target));
        }
        let mut next = current.to_vec();
        next.push(ProviderConfig { name: target, kind });
        Ok(next)
    })?;
    debug_assert!(matches!(outcome, ListEditOutcome::Changed));
    Ok(outcome.write_outcome())
}

/// `set provider add-sources <name> [--apply]`: declare a
/// provider aggregating every enabled subscription source.
pub fn add_sources_provider(
    paths: &AppPaths,
    name: &str,
    apply: bool,
) -> Result<ProviderWriteOutcome, ProviderWriteError> {
    if !is_path_safe_name(name) {
        return Err(ProviderWriteError::InvalidName(name.to_owned()));
    }
    add_provider(paths, name, ProviderKind::SubscriptionSources, apply)
}

/// `set provider add-nodes <name> <uri>… [--apply]`: declare
/// an inline-node provider from bare proxy URIs.
pub fn add_nodes_provider(
    paths: &AppPaths,
    name: &str,
    nodes: &[String],
    apply: bool,
) -> Result<ProviderWriteOutcome, ProviderWriteError> {
    if !is_path_safe_name(name) {
        return Err(ProviderWriteError::InvalidName(name.to_owned()));
    }
    if nodes.is_empty() {
        return Err(ProviderWriteError::InvalidNode(
            "an inline-nodes provider needs at least one URI".to_owned(),
        ));
    }
    let checked = validate_nodes(nodes)?;
    add_provider(paths, name, ProviderKind::InlineNodes(checked), apply)
}

/// `set provider remove <name> [--apply]`: drop the provider
/// from `providers:`.
pub fn remove_provider(
    paths: &AppPaths,
    name: &str,
    apply: bool,
) -> Result<ProviderWriteOutcome, ProviderWriteError> {
    if !is_path_safe_name(name) {
        return Err(ProviderWriteError::InvalidName(name.to_owned()));
    }
    if !provider_exists(paths, name)? {
        return Err(ProviderWriteError::NotDeclared(name.to_owned()));
    }
    if !apply {
        return Ok(ProviderWriteOutcome::DryRun);
    }
    let target = name.to_owned();
    let outcome = mutate_list::<ProviderConfig, _>(paths, "providers", |current| {
        Ok(current
            .iter()
            .filter(|provider| provider.name != target)
            .cloned()
            .collect())
    })?;
    Ok(outcome.write_outcome())
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::test_helpers::temp_root;
    use std::ffi::OsString;

    fn paths(tag: &str) -> AppPaths {
        let dir = temp_root(tag);
        let env = |key: &str| -> Option<OsString> {
            match key {
                "HOME" => Some(OsString::from("/home/test")),
                "XDG_RUNTIME_DIR" => Some(OsString::from("/run/user/1000")),
                "XDG_STATE_HOME" => Some(OsString::from(dir.as_os_str())),
                "XDG_CONFIG_HOME" => Some(OsString::from(dir.as_os_str())),
                _ => None,
            }
        };
        AppPaths::from_env_vars(&env)
    }

    fn write_config(paths: &AppPaths, body: &str) {
        let config = paths.config.join("config.yaml");
        std::fs::create_dir_all(&paths.config).unwrap();
        std::fs::write(config, body).unwrap();
    }

    #[test]
    fn add_nodes_rejects_an_invalid_uri_before_any_write() {
        let paths = paths("invalid-node");
        write_config(&paths, "schema_version: 1\ncore: mihomo\n");
        let result = add_nodes_provider(&paths, "team", &["not-a-uri".to_owned()], true);
        assert!(matches!(result, Err(ProviderWriteError::InvalidNode(_))));
        // No write happened: the file is untouched.
        let text = std::fs::read_to_string(paths.config.join("config.yaml")).unwrap();
        assert!(!text.contains("providers:"));
    }

    #[test]
    fn add_then_remove_round_trips_through_mutate_list() {
        let paths = paths("add-remove");
        write_config(&paths, "schema_version: 1\ncore: mihomo\n");
        let applied = add_sources_provider(&paths, "team", true).unwrap();
        assert_eq!(applied, ProviderWriteOutcome::Applied);
        let config = super::super::resource_writer::load_app_config(&paths).unwrap();
        assert!(
            config
                .providers
                .iter()
                .any(|provider| provider.name == "team")
        );
        // Duplicate add surfaces AlreadyDeclared on the dry-run too.
        assert!(matches!(
            add_sources_provider(&paths, "team", false),
            Err(ProviderWriteError::AlreadyDeclared(_))
        ));
        let removed = remove_provider(&paths, "team", true).unwrap();
        assert_eq!(removed, ProviderWriteOutcome::Applied);
        let config = super::super::resource_writer::load_app_config(&paths).unwrap();
        assert!(config.providers.is_empty());
        assert!(matches!(
            remove_provider(&paths, "team", false),
            Err(ProviderWriteError::NotDeclared(_))
        ));
    }

    #[test]
    fn add_nodes_persists_validated_uris() {
        let paths = paths("add-nodes");
        write_config(&paths, "schema_version: 1\ncore: mihomo\n");
        let uri = "ss://YWVzLTI1Ni1nY206cGFzc0BleGFtcGxlLmNvbTo4Mzg4#node".to_owned();
        let applied =
            add_nodes_provider(&paths, "manual", std::slice::from_ref(&uri), true).unwrap();
        assert_eq!(applied, ProviderWriteOutcome::Applied);
        let config = super::super::resource_writer::load_app_config(&paths).unwrap();
        let provider = config
            .providers
            .iter()
            .find(|provider| provider.name == "manual")
            .unwrap();
        assert!(matches!(
            &provider.kind,
            ProviderKind::InlineNodes(nodes) if nodes.len() == 1
        ));
    }
}
