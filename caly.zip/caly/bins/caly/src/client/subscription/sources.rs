//! Subscription source writers (`set sub add/remove/enable/disable`).
//!
//! Split out of `client/subscription.rs` (audit #70 file-length
//! budget). Every writer round-trips the `subscriptions.sources`
//! list through the shared
//! [`super::super::super::yaml_surgery::edit_yaml_list`] primitive, so
//! comments and unknown keys elsewhere in `config.yaml` survive
//! and an idempotent call produces no disk write (audit #15/#16).

use caly_platform::paths::AppPaths;
use caly_profile::schema::SubscriptionSource;

use super::super::resource_writer::{
    ListEditOutcome, ResourceError, config_yaml_path, is_http_url,
};
use super::{MAX_SOURCE_NAME_CHARS, SubCmdError, SubWriteOutcome, load_declared_with};

/// Validates the optional `--name` display name. Trimming is
/// applied by the caller's write path; here we only reject the
/// unusable shapes (empty / over-long / control characters) and
/// hand the trimmed name back for storage.
fn validate_source_name(name: &str) -> Result<String, SubCmdError> {
    let trimmed = name.trim();
    if trimmed.is_empty() {
        return Err(SubCmdError::InvalidName("name is empty".to_owned()));
    }
    if trimmed.chars().count() > MAX_SOURCE_NAME_CHARS {
        return Err(SubCmdError::InvalidName(format!(
            "name exceeds {MAX_SOURCE_NAME_CHARS} characters"
        )));
    }
    if trimmed.chars().any(char::is_control) {
        return Err(SubCmdError::InvalidName(
            "name contains control characters".to_owned(),
        ));
    }
    Ok(trimmed.to_owned())
}

pub fn add_source(
    paths: &AppPaths,
    url: &str,
    name: Option<&str>,
    apply: bool,
) -> Result<SubWriteOutcome, SubCmdError> {
    let trimmed = is_http_url(url).map_err(SubCmdError::InvalidUrl)?;
    let name = name.map(validate_source_name).transpose()?;
    let config = load_declared_with(paths)?;
    if config
        .subscriptions
        .sources
        .iter()
        .any(|s| s.url == trimmed)
    {
        return Err(SubCmdError::AlreadyDeclared(trimmed.to_owned()));
    }
    if !apply {
        return Ok(SubWriteOutcome::DryRun);
    }
    mutate_subscription_sources(paths, |sources| {
        sources.push(SubscriptionSource {
            url: trimmed.to_owned(),
            enabled: true,
            name,
        });
        Ok(())
    })?;
    Ok(SubWriteOutcome::Applied)
}

/// `set sub remove <url> [--apply]`. Filters the
/// `sources` list by URL. Returns
/// `SubCmdError::NotDeclared` if the URL is not in the
/// list.
pub fn remove_source(
    paths: &AppPaths,
    url: &str,
    apply: bool,
) -> Result<SubWriteOutcome, SubCmdError> {
    let trimmed = is_http_url(url).map_err(SubCmdError::InvalidUrl)?;
    if !source_url_exists(paths, trimmed)? {
        return Err(SubCmdError::NotDeclared(trimmed.to_owned()));
    }
    if !apply {
        return Ok(SubWriteOutcome::DryRun);
    }
    mutate_subscription_sources(paths, |sources| {
        sources.retain(|s| s.url != trimmed);
        Ok(())
    })?;
    Ok(SubWriteOutcome::Applied)
}

/// `set sub enable <url> [--apply]`. Flips
/// `enabled: true` on the matching source. (All sources
/// are enabled by default, so this is a no-op when the
/// source is already enabled — but the writer accepts
/// it for symmetry with `disable`.)
pub fn enable_source(
    paths: &AppPaths,
    url: &str,
    apply: bool,
) -> Result<SubWriteOutcome, SubCmdError> {
    set_source_enabled(paths, url, true, apply)
}

/// `set sub disable <url> [--apply]`. Flips
/// `enabled: false` on the matching source.
pub fn disable_source(
    paths: &AppPaths,
    url: &str,
    apply: bool,
) -> Result<SubWriteOutcome, SubCmdError> {
    set_source_enabled(paths, url, false, apply)
}

/// Round 29: extracted the "is this URL in
/// `subscriptions.sources`?" check from
/// `remove_source` / `set_source_enabled` so the
/// two writers share one existence-check call site
/// (pre-Round-29, `set_source_enabled` inlined a
/// `for source in &config.subscriptions.sources` loop
/// while `remove_source` did a `count` comparison —
/// two different shapes for the same predicate, with
/// the `count` shape being a clever-but-opaque
/// trick to avoid iterating twice). The helper
/// returns `bool` so both call sites read as
/// "if !source_url_exists(...)" without the
/// per-writer scan logic leaking into the
/// dispatch.
fn source_url_exists(paths: &AppPaths, trimmed_url: &str) -> Result<bool, SubCmdError> {
    let config = load_declared_with(paths)?;
    Ok(config
        .subscriptions
        .sources
        .iter()
        .any(|s| s.url == trimmed_url))
}

fn set_source_enabled(
    paths: &AppPaths,
    url: &str,
    enabled: bool,
    apply: bool,
) -> Result<SubWriteOutcome, SubCmdError> {
    // Round 27 (debug): the dry-run path was a
    // silent no-op for unknown URLs. Pre-Round 27
    // `set sub enable <unknown-url>` returned
    // `DryRun` (success) for `--dry-run` but
    // `NotDeclared` (error) for `--apply`, so an
    // operator who ran the dry-run as a safety
    // check saw an OK envelope and confidently
    // ran `--apply`, only to find the call
    // actually failed. The dry-run is now
    // existence-checked the same way `apply`
    // is: an unknown URL surfaces `NotDeclared`
    // regardless of `apply`, mirroring the
    // `add_source` (already-declared check on
    // both paths) and `remove_source`
    // (not-declared check on both paths)
    // contracts. The `trimmed` value is also the
    // `url` shape that lands in the on-disk
    // `SubscriptionSource` (the writer stores
    // `trimmed`, not the raw `url`), so a
    // whitespace-padded user input lands on disk
    // and is matched against the same trimmed
    // form on subsequent `enable` / `disable`
    // calls.
    let trimmed = is_http_url(url).map_err(SubCmdError::InvalidUrl)?;
    if !source_url_exists(paths, trimmed)? {
        return Err(SubCmdError::NotDeclared(trimmed.to_owned()));
    }
    if !apply {
        return Ok(SubWriteOutcome::DryRun);
    }
    // Round 26: the apply path routes through the shared
    // `mutate_subscription_sources` helper. The
    // `NoChange` short-circuit (Round 25) now lives in
    // the helper itself (audit #16): setting the flag to
    // its current value produces an identical typed
    // before/after pair, so the helper returns `NoChange`
    // before any backup or write happens — an idempotent
    // `set sub enable` no longer touches the disk at all.
    let outcome = mutate_subscription_sources(paths, |sources| {
        for source in sources.iter_mut() {
            if source.url == trimmed {
                source.enabled = enabled;
                return Ok(());
            }
        }
        // The URL was present in the pre-mutate
        // `load_declared_with` but absent in the
        // mutate-time read — a concurrent
        // modification race. The original
        // `NotDeclared` error is the right
        // contract here; surface it through the
        // helper's error channel.
        Err(ResourceError::NotDeclared(trimmed.to_owned()))
    })?;
    Ok(outcome.write_outcome())
}

// ── Internal helpers (struct-typed write paths) ────────

/// Round 26: the single mutation primitive for the
/// `subscriptions.sources` Vec. The pre-Round-26
/// `add_source` / `remove_source` /
/// `set_source_enabled` writers each inlined the
/// same 6-step recipe (load → check → mutate →
/// backup → write → validate), with 4 subtle
/// drift points: the dry-run path used bespoke
/// `read_yaml_value` (which `mutate_list` already
/// has under a different name), the post-write
/// validation lived in `write_yaml_value` (which
/// `mutate_list` has as
/// `parse_and_validate_yaml`), and the
/// per-writer inline `write_subscriptions` /
/// `write_yaml_value` pairs duplicated the typed
/// pull / typed render / atomic-rename
/// triple. The helper here unifies the 4-step
/// recipe so each writer is a 5-line shim
/// around a `FnOnce(&mut Vec<SubscriptionSource>)`
/// closure, and the validation / backup /
/// atomic-rename contract lives in one place.
///
/// Audit #15/#16: the helper now writes through
/// [`super::super::yaml_surgery::edit_yaml_list`] — a
/// targeted line edit of the `sources:` block
/// that preserves comments / unknown keys /
/// formatting elsewhere in the file and no
/// longer materialises the `subscriptions:`
/// scalar defaults — and an idempotent mutation
/// short-circuits as [`ListEditOutcome::NoChange`]
/// before any backup or write runs.
///
/// The closure returns `Result<(), ResourceError>`
/// so the writer's domain-specific
/// `AlreadyDeclared` / `NotDeclared` /
/// `Invalid(_)` variants round-trip through the
/// `From<ResourceError>` impl on `SubCmdError`.
fn mutate_subscription_sources<F>(
    paths: &AppPaths,
    mutate: F,
) -> Result<ListEditOutcome, SubCmdError>
where
    F: FnOnce(&mut Vec<SubscriptionSource>) -> Result<(), ResourceError>,
{
    let path = config_yaml_path(paths);
    let text = std::fs::read_to_string(&path).map_err(|error| {
        SubCmdError::Shared(ResourceError::Write(format!(
            "cannot read {}: {error}",
            path.display()
        )))
    })?;
    // Audit #15/#16: the write is a targeted line edit of the
    // `subscriptions.sources` block (comments / unknown keys /
    // formatting elsewhere in the file survive; the scalar defaults
    // of `subscriptions:` are no longer materialised), and a no-op
    // mutation returns `NoChange` *before* the backup / write
    // pipeline runs, so an idempotent call produces no disk write.
    let outcome =
        super::super::yaml_surgery::edit_yaml_list::<SubscriptionSource, _, ResourceError>(
            &text,
            &["subscriptions", "sources"],
            ResourceError::Parse,
            |current| {
                let mut next = current.to_vec();
                mutate(&mut next)?;
                Ok(next)
            },
        )
        .map_err(SubCmdError::Shared)?;
    let super::super::yaml_surgery::EditOutcome::Changed(new_text) = outcome else {
        return Ok(ListEditOutcome::NoChange);
    };
    // Validate the new file *before* writing it:
    // a failed validation never reaches disk.
    if let Err(error) = caly_profile::schema::parse_and_validate_yaml(new_text.as_bytes()) {
        return Err(SubCmdError::Shared(ResourceError::Validate(format!(
            "post-write validation failed for {}: {error}",
            path.display()
        ))));
    }
    super::super::config_writer::backup_config_yaml(&path)?;
    super::super::config_writer::write_atomic(&path, &new_text)
        .map_err(|error| SubCmdError::Shared(ResourceError::Write(error.to_string())))?;
    Ok(ListEditOutcome::Changed)
}
