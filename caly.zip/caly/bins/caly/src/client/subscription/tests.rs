//! Tests for `client/subscription.rs`, extracted to the sibling
//! convention file (audit #70 file-length budget).

use super::*;
use crate::test_helpers::{hermetic_paths, temp_root};
use caly_profile::schema::AppConfig;
use std::fs;

fn seed_config_at_roots(dir: &std::path::Path) -> AppPaths {
    let paths = hermetic_paths(dir);
    let target = paths.config.join("config.yaml");
    fs::create_dir_all(&paths.config).unwrap();
    fs::write(
        &target,
        "schema_version: 1\ncore: mihomo\nsubscriptions: {}\n",
    )
    .unwrap();
    paths
}

/// Local tag used by every `temp_root` call in this
/// module. Round 26 collapsed the bespoke
/// `temp_root` helper into the cross-module
/// [`crate::test_helpers::temp_root`]; the tag
/// is the only thing that distinguishes this
/// module's fixtures under `/tmp` from the
/// fixtures of any other module. Pre-Round 26
/// the local `temp_root` used a `caly-sub-{name}-…`
/// prefix, so the tag is `"sub"` to keep the
/// resulting `/tmp/caly-sub-…-…-…` path shape
/// identical to the pre-refactor fixture paths
/// (a CI log-grep that scans for `caly-sub-…`
/// still works).
const FIXTURE_TAG: &str = "sub";

#[test]
fn validate_url_rejects_non_http_schemes() {
    assert!(is_http_url("file:///etc/passwd").is_err());
    assert!(is_http_url("data:text/plain,hello").is_err());
    assert!(is_http_url("").is_err());
    assert!(is_http_url("https://example.com/sub").is_ok());
}

#[test]
fn add_source_dry_run_does_not_touch_disk() {
    let dir = temp_root(FIXTURE_TAG);
    let paths = seed_config_at_roots(dir.as_path());
    let outcome = add_source(&paths, "https://example.com/sub", None, false).unwrap();
    assert_eq!(outcome, SubWriteOutcome::DryRun);
    let expected = "schema_version: 1\ncore: mihomo\nsubscriptions: {}\n";
    let after = std::fs::read_to_string(paths.config.join("config.yaml")).unwrap();
    assert_eq!(after, expected);
}

#[test]
fn add_source_apply_persists_a_new_source() {
    let dir = temp_root(FIXTURE_TAG);
    let paths = seed_config_at_roots(dir.as_path());
    let outcome = add_source(&paths, "https://example.com/sub", None, true).unwrap();
    assert_eq!(outcome, SubWriteOutcome::Applied);
    let bytes = fs::read(paths.config.join("config.yaml")).unwrap();
    let value: serde_norway::Value = serde_norway::from_slice(&bytes).unwrap();
    let Some(sources) = value
        .get("subscriptions")
        .and_then(|v| v.get("sources"))
        .and_then(|v| v.as_sequence())
    else {
        panic!("subscriptions.sources must exist after a successful write");
    };
    assert_eq!(sources.len(), 1);
    assert_eq!(
        sources[0].get("url").and_then(|v| v.as_str()),
        Some("https://example.com/sub")
    );
    assert_eq!(
        sources[0]
            .get("enabled")
            .and_then(serde_norway::Value::as_bool),
        Some(true)
    );
    let backup = paths.config.join("config.yaml.bak");
    assert!(backup.exists(), "backup sidecar must be written");
}

#[test]
fn add_source_rejects_duplicate_url() {
    let dir = temp_root(FIXTURE_TAG);
    let paths = seed_config_at_roots(dir.as_path());
    add_source(&paths, "https://example.com/sub", None, true).unwrap();
    let result = add_source(&paths, "https://example.com/sub", None, true);
    assert!(matches!(result, Err(SubCmdError::AlreadyDeclared(_))));
}

#[test]
fn add_source_trims_url_before_storing() {
    // Round 27 (debug): the pre-Round 27 shape
    // called `is_http_url(url).map_err(...)`
    // and *discarded* the trimmed URL with
    // `let _ = ...?;`, then stored the raw
    // `url.to_owned()` on disk. A
    // whitespace-padded URL was therefore
    // stored with its leading / trailing
    // whitespace intact, breaking the
    // round-trip with `remove_source` /
    // `enable_source` (which compared against
    // the raw input but the on-disk form
    // was the trimmed one — they matched
    // only by accident, not by design). The
    // post-Round 27 contract: the trimmed
    // URL is the single source of truth, used
    // for the duplicate check *and* the
    // on-disk entry.
    let dir = temp_root(FIXTURE_TAG);
    let paths = seed_config_at_roots(dir.as_path());
    // First add: a URL with stray whitespace.
    add_source(&paths, "  https://example.com/sub  ", None, true).unwrap();
    // Re-read the layered config: the on-disk
    // `url` field must be the trimmed form,
    // not the raw input.
    let config: AppConfig = caly_profile::loader::load_layered_yaml_with(
        &caly_profile::loader::LayeredConfigPaths::new(paths.config.clone(), None),
        caly_profile::loader::LoaderLimits::secure_default(),
        &caly_profile::loader::InMemoryProfileResolver::lenient(),
    )
    .unwrap();
    assert_eq!(config.subscriptions.sources.len(), 1);
    assert_eq!(
        config.subscriptions.sources[0].url,
        "https://example.com/sub"
    );
    // Second add: the trimmed form. Pre-Round
    // 27 this would have created a second
    // entry (the on-disk form was the trimmed
    // one, but the duplicate check compared
    // against the raw input which didn't
    // match the on-disk trimmed form, so the
    // check missed it). Post-Round 27 the
    // duplicate check fires against the
    // trimmed form and the second add is
    // rejected.
    let result = add_source(&paths, "https://example.com/sub", None, true);
    assert!(
        matches!(result, Err(SubCmdError::AlreadyDeclared(_))),
        "expected AlreadyDeclared for trimmed duplicate, got {result:?}"
    );
    // And the on-disk source list is still
    // exactly one entry.
    let config: AppConfig = caly_profile::loader::load_layered_yaml_with(
        &caly_profile::loader::LayeredConfigPaths::new(paths.config.clone(), None),
        caly_profile::loader::LoaderLimits::secure_default(),
        &caly_profile::loader::InMemoryProfileResolver::lenient(),
    )
    .unwrap();
    assert_eq!(config.subscriptions.sources.len(), 1);
}

#[test]
fn remove_source_filters_a_matching_url() {
    let dir = temp_root(FIXTURE_TAG);
    let paths = seed_config_at_roots(dir.as_path());
    add_source(&paths, "https://a.example.com/sub", None, true).unwrap();
    add_source(&paths, "https://b.example.com/sub", None, true).unwrap();
    let outcome = remove_source(&paths, "https://a.example.com/sub", true).unwrap();
    assert_eq!(outcome, SubWriteOutcome::Applied);
    let config: AppConfig = caly_profile::loader::load_layered_yaml_with(
        &caly_profile::loader::LayeredConfigPaths::new(paths.config.clone(), None),
        caly_profile::loader::LoaderLimits::secure_default(),
        &caly_profile::loader::InMemoryProfileResolver::lenient(),
    )
    .unwrap();
    assert_eq!(config.subscriptions.sources.len(), 1);
    assert_eq!(
        config.subscriptions.sources[0].url,
        "https://b.example.com/sub"
    );
}

#[test]
fn remove_source_rejects_unknown_url() {
    let dir = temp_root(FIXTURE_TAG);
    let paths = seed_config_at_roots(dir.as_path());
    let result = remove_source(&paths, "https://unknown.example.com/sub", true);
    assert!(matches!(result, Err(SubCmdError::NotDeclared(_))));
}

#[test]
fn disable_source_flips_the_enabled_flag() {
    let dir = temp_root(FIXTURE_TAG);
    let paths = seed_config_at_roots(dir.as_path());
    add_source(&paths, "https://a.example.com/sub", None, true).unwrap();
    let outcome = disable_source(&paths, "https://a.example.com/sub", true).unwrap();
    assert_eq!(outcome, SubWriteOutcome::Applied);
    let config: AppConfig = caly_profile::loader::load_layered_yaml_with(
        &caly_profile::loader::LayeredConfigPaths::new(paths.config.clone(), None),
        caly_profile::loader::LoaderLimits::secure_default(),
        &caly_profile::loader::InMemoryProfileResolver::lenient(),
    )
    .unwrap();
    assert!(!config.subscriptions.sources[0].enabled);
}

#[test]
fn enable_dry_run_against_unknown_url_surfaces_not_declared() {
    // Round 27 (debug): the pre-Round 27 shape
    // returned `DryRun` (success) for an unknown
    // URL on the dry-run path, but `NotDeclared`
    // (error) for the same URL on the apply
    // path. The dry-run now previews the apply
    // outcome: an unknown URL surfaces
    // `NotDeclared` regardless of `apply`, so
    // the operator's `--dry-run` safety check
    // reports the same failure mode that
    // `--apply` would. Compare to
    // `add_source_rejects_duplicate_url` and
    // `remove_source_rejects_unknown_url` —
    // the `add` and `remove` writers had this
    // contract all along; the `enable` /
    // `disable` writer was the inconsistent
    // outlier.
    let dir = temp_root(FIXTURE_TAG);
    let paths = seed_config_at_roots(dir.as_path());
    let result = enable_source(&paths, "https://unknown.example.com/sub", false);
    assert!(
        matches!(result, Err(SubCmdError::NotDeclared(_))),
        "dry-run enable on an unknown URL must fail with NotDeclared, got {result:?}"
    );
    let _ = fs::remove_dir_all(&dir);
}

#[test]
fn enable_dry_run_against_known_url_succeeds() {
    // The corresponding positive case: an
    // existing URL's `enable --dry-run` returns
    // `DryRun` (success), so the operator's
    // dry-run-as-safety-check shape is
    // consistent with the apply path's
    // `NoChange` / `Applied` distinction.
    let dir = temp_root(FIXTURE_TAG);
    let paths = seed_config_at_roots(dir.as_path());
    add_source(&paths, "https://known.example.com/sub", None, true).unwrap();
    let outcome = enable_source(&paths, "https://known.example.com/sub", false).unwrap();
    assert_eq!(outcome, SubWriteOutcome::DryRun);
    let _ = fs::remove_dir_all(&dir);
}

#[test]
fn enable_source_reports_no_change_when_already_enabled() {
    // Round 25 (debug): the previous shape
    // returned `Applied` (apply) or `DryRun`
    // (dry-run) when the on-disk `enabled` flag
    // was already the target state, which made
    // `set sub enable <already-enabled-url>
    // --apply` report a successful write with no
    // disk I/O. The new contract: the writer
    // surfaces an explicit `NoChange` outcome so
    // the dispatch can emit a distinct "already
    // enabled" summary. Lock both the apply
    // path (the one that previously lied) and
    // the dry-run path (which still returns
    // `DryRun` because the user did not pass
    // `--apply`).
    let dir = temp_root(FIXTURE_TAG);
    let paths = seed_config_at_roots(dir.as_path());
    add_source(&paths, "https://a.example.com/sub", None, true).unwrap();
    // Apply path: returns `NoChange`.
    let outcome = enable_source(&paths, "https://a.example.com/sub", true).unwrap();
    assert_eq!(outcome, SubWriteOutcome::NoChange);
    // Dry-run path: still `DryRun` (the user
    // asked for a preview, the writer validated
    // without writing).
    let outcome = enable_source(&paths, "https://a.example.com/sub", false).unwrap();
    assert_eq!(outcome, SubWriteOutcome::DryRun);
    // Disable on an enabled source: `Applied`
    // (the on-disk state changes, so the writer
    // reaches the apply path).
    let outcome = disable_source(&paths, "https://a.example.com/sub", true).unwrap();
    assert_eq!(outcome, SubWriteOutcome::Applied);
    // Disable on the now-disabled source:
    // `NoChange` (idempotent).
    let outcome = disable_source(&paths, "https://a.example.com/sub", true).unwrap();
    assert_eq!(outcome, SubWriteOutcome::NoChange);
}
