//! Tests for `client/subscription.rs`, extracted to the sibling
//! convention file (audit #70 file-length budget).

use super::*;

#[test]
fn disabled_and_named_rows_survive_the_projection() {
    let declared = caly_profile::schema::SubscriptionConfig {
        url: None,
        sources: vec![
            caly_profile::schema::SubscriptionSource {
                url: "https://a.example.com/sub".to_owned(),
                enabled: true,
                name: Some("alpha".to_owned()),
            },
            caly_profile::schema::SubscriptionSource {
                url: "https://b.example.com/sub".to_owned(),
                enabled: false,
                name: None,
            },
        ],
        ..caly_profile::schema::SubscriptionConfig::default()
    };
    let projected = source_rows(&declared);
    assert_eq!(projected.len(), 2, "one row per declared source");
    assert_eq!(projected[0]["name"].as_str(), Some("alpha"));
    assert_eq!(projected[0]["enabled"].as_bool(), Some(true));
    assert_eq!(projected[1]["enabled"].as_bool(), Some(false));
    assert!(projected[1].get("name").is_none());
}
