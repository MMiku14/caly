//! Round 15: offline rule-provider writer for the
//! `set rule-provider …` leaves.
//!
//! The 6 CRUD leaves (`add-http` / `add-file` / `add-inline` /
//! `remove` / `enable` / `disable`) round-trip
//! `rule_providers: Vec<RuleProviderConfig>` in
//! `config.yaml`. `refresh` is the daemon-RPC
//! path (separate wire command) and stays outside this
//! module.
//!
//! The shared [`crate::client::resource_writer`] helpers
//! own the cross-resource bookkeeping (path safety, URL
//! validation, the typed `mutate_list` primitive, the
//! unified `ResourceError` envelope). The per-resource
//! code here is the **type** discriminator
//! (`RuleProviderSourceConfig` has three source kinds)
//! and the `RpBehavior` shim that bridges the CLI
//! grammar to the schema enum.

use std::path::PathBuf;

use caly_config::schema::{
    RuleProviderBehaviorConfig, RuleProviderConfig, RuleProviderFormatConfig,
    RuleProviderSourceConfig,
};
use caly_platform::paths::AppPaths;

use super::resource_writer::{
    ResourceError, ResourceWriteOutcome, is_http_url, is_path_safe_name, mutate_list,
};

/// Rule-provider-specific error variants. The shared
/// [`ResourceError`] cases flow through the `Shared(_)` arm
/// so the dispatch has one `match` instead of two parallel
/// enums.
#[allow(dead_code)] // `InvalidBehavior` is reserved for a
                   // future `set rule-provider add --behavior`
                   // flag (Round 16+). Round 15 defaults
                   // to `Domain` for all new entries.
#[derive(Debug)]
pub enum RpWriteError {
    /// The id is empty or not path-safe ASCII.
    InvalidName(String),
    /// `add` on a name that's already declared.
    AlreadyDeclared(String),
    /// `remove` / `enable` / `disable` on a name that's not
    /// declared.
    NotDeclared(String),
    /// The `behavior:` is not a known matcher kind
    /// (rejected by the schema enum, surfaced for
    /// diagnostics).
    InvalidBehavior(String),
    /// The HTTP URL is empty or not `http(s)://`.
    InvalidUrl(String),
    /// Any other failure the shared writer surfaces.
    Shared(ResourceError),
}

impl core::fmt::Display for RpWriteError {
    fn fmt(&self, formatter: &mut core::fmt::Formatter<'_>) -> core::fmt::Result {
        match self {
            Self::InvalidName(name) =>
                write!(formatter, "rule provider name `{name}` is not path-safe ASCII"),
            Self::AlreadyDeclared(name) =>
                write!(formatter, "rule provider `{name}` is already declared"),
            Self::NotDeclared(name) =>
                write!(formatter, "rule provider `{name}` is not declared"),
            Self::InvalidBehavior(reason) =>
                write!(formatter, "invalid rule provider behavior: {reason}"),
            Self::InvalidUrl(reason) =>
                write!(formatter, "invalid rule provider URL: {reason}"),
            Self::Shared(shared) => write!(formatter, "{shared}"),
        }
    }
}

impl std::error::Error for RpWriteError {}

impl From<ResourceError> for RpWriteError {
    fn from(value: ResourceError) -> Self {
        match value {
            ResourceError::AlreadyDeclared(name) => Self::AlreadyDeclared(name),
            ResourceError::NotDeclared(name) => Self::NotDeclared(name),
            other => Self::Shared(other),
        }
    }
}

/// Source-kind spec for the CLI writer. Mirrors
/// `cli::RuleProviderSourceSpec` but erases the bounded
/// text / the file path. The CLI dispatch converts
/// between the two shapes.
#[derive(Debug, Clone)]
pub enum RpSourceSpec {
    Http { url: String, interval_ms: u64 },
    File { path: PathBuf },
    Inline { payload: String },
}

/// The behavior the rule body contains. Mirrors
/// `RuleProviderBehaviorConfig` but stays a CLI-side enum
/// (the dispatch maps the user-typed `--behavior` flag to
/// one of these; the writer converts to the schema enum).
#[allow(dead_code)] // `DomainSuffix` / `IpCidr` / `Classical`
                   // / `parse` are reserved for a future
                   // `set rule-provider add-* --behavior` flag
                   // (Round 16+). Round 15 defaults to `Domain`
                   // for all new entries.
#[derive(Debug, Clone, Copy)]
pub enum RpBehavior {
    Domain,
    DomainSuffix,
    IpCidr,
    Classical,
}

impl RpBehavior {
    /// The default behavior when the operator does not pass
    /// `--behavior` explicitly. Round 15 default: `Domain`
    /// (the most common pattern in mihomo rule-providers).
    pub const DEFAULT: Self = Self::Domain;

    pub const fn to_schema(self) -> RuleProviderBehaviorConfig {
        match self {
            Self::Domain => RuleProviderBehaviorConfig::Domain,
            Self::DomainSuffix => RuleProviderBehaviorConfig::DomainSuffix,
            Self::IpCidr => RuleProviderBehaviorConfig::IpCidr,
            Self::Classical => RuleProviderBehaviorConfig::Classical,
        }
    }
}

/// Re-export of the unified `Outcome` shape. The dispatch
/// sees this as the writer's `Ok(_)` type.
pub type RpWriteOutcome = ResourceWriteOutcome;

fn build_config(
    name: &str,
    source: &RpSourceSpec,
    behavior: RpBehavior,
) -> Result<RuleProviderConfig, RpWriteError> {
    if !is_path_safe_name(name) {
        return Err(RpWriteError::InvalidName(name.to_owned()));
    }
    let kind = match source {
        RpSourceSpec::Http { url, interval_ms } => {
            let url = is_http_url(url).map_err(RpWriteError::InvalidUrl)?;
            RuleProviderSourceConfig::Http {
                url: url.to_owned(),
                interval_ms: *interval_ms,
            }
        }
        RpSourceSpec::File { path } => RuleProviderSourceConfig::File {
            path: path.display().to_string(),
        },
        RpSourceSpec::Inline { payload } => RuleProviderSourceConfig::Inline {
            payload: payload.clone(),
        },
    };
    Ok(RuleProviderConfig {
        name: name.to_owned(),
        kind,
        behavior: behavior.to_schema(),
        format: RuleProviderFormatConfig::Source,
        enabled: true,
    })
}

/// `set rule-provider add-http|add-file|add-inline`.
///
/// Default: dry-run. `--apply` is the only thing that
/// actually mutates `config.yaml`.
pub fn add_provider(
    paths: &AppPaths,
    name: &str,
    source: &RpSourceSpec,
    behavior: RpBehavior,
    apply: bool,
) -> Result<RpWriteOutcome, RpWriteError> {
    let entry = build_config(name, source, behavior)?;
    if !apply {
        return Ok(RpWriteOutcome::DryRun);
    }
    mutate_list::<RuleProviderConfig, _>(paths, "rule_providers", |current| {
        if current.iter().any(|p| p.name == entry.name) {
            return Err(ResourceError::AlreadyDeclared(entry.name));
        }
        let mut next = current.to_vec();
        next.push(entry);
        Ok(next)
    })?;
    Ok(RpWriteOutcome::Applied)
}

/// `set rule-provider remove` — filters the
/// `rule_providers:` list by name. Returns
/// `RpWriteError::NotDeclared` if the name is not in the
/// list.
pub fn remove_provider(
    paths: &AppPaths,
    name: &str,
    apply: bool,
) -> Result<RpWriteOutcome, RpWriteError> {
    if !is_path_safe_name(name) {
        return Err(RpWriteError::InvalidName(name.to_owned()));
    }
    if !provider_exists(paths, name)? {
        return Err(RpWriteError::NotDeclared(name.to_owned()));
    }
    if !apply {
        return Ok(RpWriteOutcome::DryRun);
    }
    mutate_list::<RuleProviderConfig, _>(paths, "rule_providers", |current| {
        let target = name.to_owned();
        Ok(current.iter().filter(|p| p.name != target).cloned().collect())
    })?;
    Ok(RpWriteOutcome::Applied)
}

/// `set rule-provider enable|disable` — flips the
/// `enabled` flag. The schema default is `enabled: true`
/// (Round 15 added the field), so `enable` is a no-op
/// for a fresh entry and `disable` is the meaningful
/// state transition.
pub fn set_enabled(
    paths: &AppPaths,
    name: &str,
    enabled: bool,
    apply: bool,
) -> Result<RpWriteOutcome, RpWriteError> {
    if !is_path_safe_name(name) {
        return Err(RpWriteError::InvalidName(name.to_owned()));
    }
    // Round 27 (debug): the dry-run path was a
    // silent no-op for unknown names. Pre-Round 27
    // `set rule-provider enable <unknown-name>`
    // returned `DryRun` (success) for `--dry-run`
    // but `NotDeclared` (error) for `--apply`.
    // The dry-run is now existence-checked the
    // same way `add_provider` / `remove_provider`
    // are: an unknown name surfaces `NotDeclared`
    // regardless of `apply`. Round 29: the
    // existence check folded into the shared
    // [`provider_exists`] helper so the predicate
    // lives in one place (the pre-Round-29 shape
    // inlined the same `iter().any(...)` in three
    // different branches).
    if !provider_exists(paths, name)? {
        return Err(RpWriteError::NotDeclared(name.to_owned()));
    }
    if !apply {
        return Ok(RpWriteOutcome::DryRun);
    }
    mutate_list::<RuleProviderConfig, _>(paths, "rule_providers", |current| {
        let target = name.to_owned();
        let next: Vec<RuleProviderConfig> = current
            .iter()
            .map(|p| {
                let mut p = p.clone();
                if p.name == target {
                    p.enabled = enabled;
                }
                p
            })
            .collect();
        Ok(next)
    })?;
    Ok(RpWriteOutcome::Applied)
}

/// Round 29: extracted the "is this name in
/// `rule_providers:`?" check from `remove_provider`
/// / `set_enabled` so the two writers share one
/// existence-check call site (pre-Round-29, each
/// writer inlined its own `current.iter().any(...)`
/// / `config.rule_providers.iter().any(...)` loop,
/// with `set_enabled` going through the full
/// `load_app_config` while `remove_provider` did
/// the check inside the `mutate` closure's `&[T]`
/// borrow). The helper returns `bool` so both call
/// sites read as `if !provider_exists(paths, name)?` —
/// the existence check is now decoupled from the
/// write primitive.
fn provider_exists(paths: &AppPaths, name: &str) -> Result<bool, RpWriteError> {
    let config = super::resource_writer::load_app_config(paths)
        .map_err(RpWriteError::Shared)?;
    Ok(config.rule_providers.iter().any(|p| p.name == name))
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::test_helpers::temp_root;
    use std::ffi::OsString;
    use std::fs;


    fn seed_at_roots(dir: &std::path::Path) -> AppPaths {
        let env = |key: &str| -> Option<OsString> {
            match key {
                "HOME" => Some(OsString::from("/home/test")),
                "XDG_RUNTIME_DIR" => Some(OsString::from("/run/user/1000")),
                "XDG_STATE_HOME" => Some(OsString::from(dir.as_os_str())),
                "XDG_CONFIG_HOME" => Some(OsString::from(dir.as_os_str())),
                _ => None,
            }
        };
        let paths = AppPaths::from_env_vars(&env);
        let target = paths.config.join("config.yaml");
        fs::create_dir_all(&paths.config).unwrap_or_else(|_| std::process::abort());
        fs::write(
            &target,
            "schema_version: 1\ncore: mihomo\nrule_providers: []\n",
        )
        .unwrap_or_else(|_| std::process::abort());
        paths
    }

    #[test]
    fn add_http_dry_run_does_not_touch_disk() {
        let dir = temp_root("__FUNC__");
        let paths = seed_at_roots(dir.as_path());
        let outcome = add_provider(
            &paths,
            "geoip-cn",
            &RpSourceSpec::Http {
                url: "https://example.com/geoip-cn".to_owned(),
                interval_ms: 86_400_000,
            },
            RpBehavior::Domain,
            false,
        )
        .unwrap_or_else(|_| std::process::abort());
        assert_eq!(outcome, RpWriteOutcome::DryRun);
        let expected = "schema_version: 1\ncore: mihomo\nrule_providers: []\n";
        let after = std::fs::read_to_string(paths.config.join("config.yaml"))
            .unwrap_or_else(|_| std::process::abort());
        assert_eq!(after, expected);
    }

    #[test]
    fn add_http_apply_persists_a_new_provider() {
        let dir = temp_root("__FUNC__");
        let paths = seed_at_roots(dir.as_path());
        let outcome = add_provider(
            &paths,
            "geoip-cn",
            &RpSourceSpec::Http {
                url: "https://example.com/geoip-cn".to_owned(),
                interval_ms: 86_400_000,
            },
            RpBehavior::DomainSuffix,
            true,
        )
        .unwrap_or_else(|_| std::process::abort());
        assert_eq!(outcome, RpWriteOutcome::Applied);
        let bytes = std::fs::read(paths.config.join("config.yaml"))
            .unwrap_or_else(|_| std::process::abort());
        let value: serde_norway::Value =
            serde_norway::from_slice(&bytes).unwrap_or_else(|_| std::process::abort());
        let Some(providers) = value.get("rule_providers").and_then(|v| v.as_sequence()) else { std::process::abort(); };
        assert_eq!(providers.len(), 1);
        assert_eq!(
            providers[0].get("name").and_then(|v| v.as_str()),
            Some("geoip-cn")
        );
        assert_eq!(
            providers[0].get("type").and_then(|v| v.as_str()),
            Some("http")
        );
        assert_eq!(
            providers[0].get("behavior").and_then(|v| v.as_str()),
            Some("domain_suffix")
        );
        // The default `enabled: true` is preserved.
        assert_eq!(
            providers[0].get("enabled").and_then(serde_norway::Value::as_bool),
            Some(true)
        );
        // A backup sidecar must exist.
        let backup = paths.config.join("config.yaml.bak");
        assert!(backup.exists(), "backup sidecar must be written");
    }

    #[test]
    fn add_inline_apply_writes_an_inline_provider() {
        let dir = temp_root("__FUNC__");
        let paths = seed_at_roots(dir.as_path());
        let outcome = add_provider(
            &paths,
            "local-rules",
            &RpSourceSpec::Inline {
                payload: "DOMAIN,example.com,auto\n".to_owned(),
            },
            RpBehavior::Classical,
            true,
        )
        .unwrap_or_else(|_| std::process::abort());
        assert_eq!(outcome, RpWriteOutcome::Applied);
        let bytes = std::fs::read(paths.config.join("config.yaml"))
            .unwrap_or_else(|_| std::process::abort());
        let value: serde_norway::Value =
            serde_norway::from_slice(&bytes).unwrap_or_else(|_| std::process::abort());
        let Some(providers) = value.get("rule_providers").and_then(|v| v.as_sequence()) else { std::process::abort(); };
        assert_eq!(providers.len(), 1);
        assert_eq!(
            providers[0].get("type").and_then(|v| v.as_str()),
            Some("inline")
        );
    }

    #[test]
    fn add_provider_rejects_duplicate_name() {
        let dir = temp_root("__FUNC__");
        let paths = seed_at_roots(dir.as_path());
        add_provider(
            &paths,
            "geoip-cn",
            &RpSourceSpec::Http {
                url: "https://example.com/geoip-cn".to_owned(),
                interval_ms: 86_400_000,
            },
            RpBehavior::Domain,
            true,
        )
        .unwrap_or_else(|_| std::process::abort());
        let result = add_provider(
            &paths,
            "geoip-cn",
            &RpSourceSpec::Http {
                url: "https://example.com/other".to_owned(),
                interval_ms: 86_400_000,
            },
            RpBehavior::Domain,
            true,
        );
        // Round 21: the duplicate check now surfaces
        // `AlreadyDeclared` (not the generic `Write`).
        assert!(matches!(result, Err(RpWriteError::AlreadyDeclared(_))));
    }

    #[test]
    fn add_provider_rejects_unsafe_name() {
        let dir = temp_root("__FUNC__");
        let paths = seed_at_roots(dir.as_path());
        let result = add_provider(
            &paths,
            "../escape",
            &RpSourceSpec::Http {
                url: "https://example.com/x".to_owned(),
                interval_ms: 86_400_000,
            },
            RpBehavior::Domain,
            true,
        );
        assert!(matches!(result, Err(RpWriteError::InvalidName(_))));
    }

    #[test]
    fn add_provider_rejects_non_http_url() {
        let dir = temp_root("__FUNC__");
        let paths = seed_at_roots(dir.as_path());
        let result = add_provider(
            &paths,
            "x",
            &RpSourceSpec::Http {
                url: "file:///etc/passwd".to_owned(),
                interval_ms: 86_400_000,
            },
            RpBehavior::Domain,
            true,
        );
        assert!(matches!(result, Err(RpWriteError::InvalidUrl(_))));
    }

    #[test]
    fn remove_provider_filters_a_matching_name() {
        let dir = temp_root("__FUNC__");
        let paths = seed_at_roots(dir.as_path());
        add_provider(
            &paths,
            "a",
            &RpSourceSpec::Http {
                url: "https://example.com/a".to_owned(),
                interval_ms: 86_400_000,
            },
            RpBehavior::Domain,
            true,
        )
        .unwrap_or_else(|_| std::process::abort());
        add_provider(
            &paths,
            "b",
            &RpSourceSpec::Http {
                url: "https://example.com/b".to_owned(),
                interval_ms: 86_400_000,
            },
            RpBehavior::Domain,
            true,
        )
        .unwrap_or_else(|_| std::process::abort());
        let outcome = remove_provider(&paths, "a", true).unwrap_or_else(|_| std::process::abort());
        assert_eq!(outcome, RpWriteOutcome::Applied);
        let bytes = std::fs::read(paths.config.join("config.yaml"))
            .unwrap_or_else(|_| std::process::abort());
        let value: serde_norway::Value =
            serde_norway::from_slice(&bytes).unwrap_or_else(|_| std::process::abort());
        let Some(providers) = value.get("rule_providers").and_then(|v| v.as_sequence()) else { std::process::abort(); };
        assert_eq!(providers.len(), 1);
        assert_eq!(
            providers[0].get("name").and_then(|v| v.as_str()),
            Some("b")
        );
    }

    #[test]
    fn remove_provider_rejects_unknown_name() {
        let dir = temp_root("__FUNC__");
        let paths = seed_at_roots(dir.as_path());
        let result = remove_provider(&paths, "nope", true);
        // Round 21: the unknown-name check now surfaces
        // `NotDeclared` (not the generic `Write`).
        assert!(matches!(result, Err(RpWriteError::NotDeclared(_))));
    }

    #[test]
    fn set_enabled_flips_the_flag() {
        let dir = temp_root("__FUNC__");
        let paths = seed_at_roots(dir.as_path());
        add_provider(
            &paths,
            "a",
            &RpSourceSpec::Http {
                url: "https://example.com/a".to_owned(),
                interval_ms: 86_400_000,
            },
            RpBehavior::Domain,
            true,
        )
        .unwrap_or_else(|_| std::process::abort());
        let outcome =
            set_enabled(&paths, "a", false, true).unwrap_or_else(|_| std::process::abort());
        assert_eq!(outcome, RpWriteOutcome::Applied);
        let bytes = std::fs::read(paths.config.join("config.yaml"))
            .unwrap_or_else(|_| std::process::abort());
        let value: serde_norway::Value =
            serde_norway::from_slice(&bytes).unwrap_or_else(|_| std::process::abort());
        let Some(providers) = value.get("rule_providers").and_then(|v| v.as_sequence()) else { std::process::abort(); };
        assert_eq!(
            providers[0].get("enabled").and_then(serde_norway::Value::as_bool),
            Some(false)
        );
    }

    #[test]
    fn set_enabled_dry_run_against_unknown_name_surfaces_not_declared() {
        // Round 27 (debug): the pre-Round 27 shape
        // returned `DryRun` (success) for an unknown
        // name on the dry-run path, but `NotDeclared`
        // (error) on the apply path. The dry-run now
        // previews the apply outcome: an unknown
        // name surfaces `NotDeclared` regardless of
        // `apply`, matching the `add_provider` /
        // `remove_provider` writers' contract. The
        // `set_enabled_flips_the_flag` positive test
        // above locks the `apply` path; this test
        // locks the `dry-run` path's existence
        // check.
        let dir = temp_root("__FUNC__");
        let paths = seed_at_roots(dir.as_path());
        let result = set_enabled(&paths, "nope", false, false);
        assert!(
            matches!(result, Err(RpWriteError::NotDeclared(_))),
            "dry-run enable on an unknown name must fail with NotDeclared, got {result:?}"
        );
        let _ = fs::remove_dir_all(&dir);
    }
}
