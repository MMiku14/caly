//! caly composition root (5-namespace dispatch; P8a: host shell).

#![forbid(unsafe_code)]
#![cfg_attr(test, allow(clippy::unwrap_used, clippy::expect_used, clippy::panic, clippy::todo, clippy::unimplemented, clippy::unreachable))] // #53: tests assert with unwrap/expect/panic (+todo/unreachable in fixtures); production lints stay deny
use std::process::ExitCode;

pub mod bootstrap;
mod commands;
mod daemon;
mod daemon_config;
mod logging;

fn main() -> ExitCode {
    // Install panic hook to cleanly restore terminal if crashed
    let default_hook = std::panic::take_hook();
    std::panic::set_hook(Box::new(move |info| {
        let _ = crossterm::terminal::disable_raw_mode();
        let _ = crossterm::execute!(
            std::io::stdout(),
            crossterm::cursor::Show,
            crossterm::terminal::LeaveAlternateScreen
        );
        default_hook(info);
    }));
    let _ = logging::init();
    let args: Vec<String> = std::env::args().skip(1).collect();
    // `caly daemon` (the bare host command) is dispatched back here by the
    // presentation layer (caly-cli); every other command runs inside it.
    caly_client::cli::run(args, commands::daemon::run)
}
