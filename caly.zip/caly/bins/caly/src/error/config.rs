//! Config-family error codes (`caly config …`).

use crate::output::CliError;

pub const CHECK_FAILED: &str = "config.check_failed";
pub const GENERATE_FAILED: &str = "config.generate_failed";
pub const DEFAULT_FAILED: &str = "config.default_failed";
pub const EDITOR_NOT_FOUND: &str = "config.editor_not_found";
pub const USAGE_INVALID: &str = "config.usage_invalid";

pub fn check_failed(detail: &str, command: &str) -> CliError {
    CliError::new(CHECK_FAILED, format!("configuration check failed: {detail}"), command)
        .with_hint("fix the reported line; the schema rejects unknown fields and out-of-bounds values")
}

pub fn generate_failed(detail: &str, command: &str) -> CliError {
    CliError::new(GENERATE_FAILED, format!("config generate failed: {detail}"), command)
        .with_hint("check the XDG config root is writable; run `caly config path` to see the target")
}

pub fn default_failed(detail: &str, command: &str) -> CliError {
    CliError::new(DEFAULT_FAILED, format!("config default failed: {detail}"), command)
}

pub fn editor_not_found(editor: &str, command: &str) -> CliError {
    CliError::new(
        EDITOR_NOT_FOUND,
        format!("{editor} is not installed"),
        command,
    )
    .with_hint("install the editor, or set $EDITOR and run `config vim` / `config nvim` via a wrapper")
}

pub fn usage_invalid(detail: &str, command: &str) -> CliError {
    CliError::new(USAGE_INVALID, detail.to_string(), command)
}
