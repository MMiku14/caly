//! Daemon control plane error codes (`caly daemon`).

use crate::output::CliError;

pub const ALREADY_RUNNING: &str = "daemon.already_running";
pub const INVALID_CONFIG: &str = "daemon.invalid_config";
pub const COMPOSITION_FAILED: &str = "daemon.composition_failed";
pub const RUNTIME_FAILED: &str = "daemon.runtime_failed";

pub fn already_running(detail: &str, command: &str) -> CliError {
    CliError::new(ALREADY_RUNNING, format!("another daemon is running: {detail}"), command)
        .with_hint("stop the existing daemon or pass `--socket PATH` to a fresh one")
}

pub fn invalid_config(detail: &str, command: &str) -> CliError {
    CliError::new(INVALID_CONFIG, format!("daemon configuration invalid: {detail}"), command)
        .with_hint("run `caly config validate` for a precise failure list")
}
