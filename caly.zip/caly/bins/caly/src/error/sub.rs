//! Subscription-family error codes (`caly sub …`).

use crate::output::CliError;

pub const CHECK_FAILED: &str = "sub.check_failed";
pub const READ_FAILED: &str = "sub.read_failed";
pub const CLIPBOARD_CONFLICT: &str = "sub.clipboard_conflict";
pub const USAGE_CONFLICT: &str = "sub.usage_conflict";
pub const LIST_FAILED: &str = "sub.list_failed";
pub const NO_PROVIDER: &str = "sub.no_provider";

pub fn check_failed(message: impl Into<String>, command: &str) -> CliError {
    CliError::new(CHECK_FAILED, message, command)
        .with_hint("verify the file is a valid subscription; try `caly sub list` to see configured providers")
}

pub fn read_failed(message: impl Into<String>, command: &str) -> CliError {
    CliError::new(READ_FAILED, message, command)
        .with_hint("check the file exists and is readable; pass an explicit path if you meant a local file")
}

pub fn clipboard_conflict(command: &str) -> CliError {
    CliError::new(
        CLIPBOARD_CONFLICT,
        "`sub import --clipboard` takes no path argument",
        command,
    )
    .with_hint("omit the path, or drop `--clipboard` to read a file")
}

pub fn usage_conflict(message: impl Into<String>, command: &str) -> CliError {
    CliError::new(USAGE_CONFLICT, message, command)
}

pub fn list_failed(message: impl Into<String>, command: &str) -> CliError {
    CliError::new(LIST_FAILED, message, command)
        .with_hint("run `caly config validate` to check the config tree")
}
