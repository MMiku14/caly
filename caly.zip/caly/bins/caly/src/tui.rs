//! Interactive `caly tui` driver: a crossterm-backed terminal adapter feeding
//! the `caly-tui` renderer/app from daemon snapshots over UDS.

use std::{path::PathBuf, process::ExitCode, time::Duration};

use caly_protocol::{
    client::{ClientContract, ClientError, UdsClient},
    conversion::snapshot_from_wire,
    protocol::v2::{DecodeBudget, DecodeLimits, HandshakeRequest, ProtocolVersion},
};
use caly_tui::{
    app::TuiApp,
    render::{Renderer, input::Key},
    terminal::{Event, Terminal, TerminalError},
};
use crossterm::{
    event::{self, Event as CrosstermEvent, KeyCode, KeyEventKind},
    execute,
    terminal::{EnterAlternateScreen, LeaveAlternateScreen, disable_raw_mode, enable_raw_mode},
};

use crate::cli::CliOptions;

/// Entry point for `caly tui`; returns a process exit code.
///
/// `readonly` (the `--readonly` flag) arms the app's read-only
/// gate: daemon-mutating key bindings are swallowed inside the
/// app, so the flag is honoured even if the outer control
/// executor were bypassed.
pub fn run_tui(options: CliOptions, readonly: bool) -> ExitCode {
    let socket = options.socket.unwrap_or_else(|| {
        std::env::var_os("CALY_SOCKET").map_or_else(
            || caly_platform::paths::AppPaths::from_env().socket_path(),
            PathBuf::from,
        )
    });
    let mut client = match connect_with_retry(&socket) {
        Ok(client) => client,
        Err(error) => return report_connect_error(error),
    };
    if let Err(error) = client.handshake(handshake_request()) {
        eprintln!("tui handshake failed: {error:?}");
        return ExitCode::FAILURE;
    }
    // Fetch the initial authoritative snapshot to seed the session model.
    let Some(initial) = fetch_initial_snapshot(&mut client) else {
        eprintln!("tui initial snapshot failed");
        return ExitCode::FAILURE;
    };
    let shared = std::sync::Arc::new(std::sync::Mutex::new(Some(initial.clone())));
    // Drive the live watch stream (via ConnectionSupervisor + WatchDriver) on a
    // worker thread so the blocking watch iterator never freezes terminal input.
    let shared_writer = std::sync::Arc::clone(&shared);
    let _watch_thread = std::thread::spawn(move || {
        run_watch_loop(client, initial, shared_writer);
    });
    let mut terminal = CrosstermTerminal;
    let mut app = TuiApp::new(Renderer::default());
    app.set_readonly(readonly);
    if readonly {
        eprintln!("tui: read-only mode — node/mode/core control bindings are disabled");
    }
    let reader = std::sync::Arc::clone(&shared);
    let mut source = move || {
        // Poison recovery: a panicking watch writer must not
        // take the whole terminal down with an abort; the last
        // successfully published snapshot is still coherent.
        reader
            .lock()
            .unwrap_or_else(std::sync::PoisonError::into_inner)
            .clone()
    };
    // Daemon-operation execution (audit #106): one serial worker drains control
    // batches from a bounded channel, so a burst of key presses can never spawn
    // an unbounded number of threads; when the queue is full the batch is
    // dropped with a queued notice instead. Worker results are collected into
    // a bounded message list and printed only after the terminal leaves its
    // alternate screen — eprintln! while the TUI is live garbles rendered
    // frames. The core kind is resolved from the latest snapshot for
    // `restart core` before a batch is enqueued.
    let (control_tx, control_rx) = std::sync::mpsc::sync_channel::<(
        i32,
        Vec<caly_tui::operation::ControlAction>,
    )>(CONTROL_QUEUE_BATCHES);
    let control_messages = std::sync::Arc::new(std::sync::Mutex::new(Vec::<String>::new()));
    let control_socket = socket.clone();
    let worker_messages = std::sync::Arc::clone(&control_messages);
    let _control_worker = std::thread::spawn(move || {
        while let Ok((core_wire, actions)) = control_rx.recv() {
            for action in actions {
                let line =
                    match crate::client::run_control_action(&control_socket, action, core_wire) {
                        Ok(status) => format!("[caly] {status}"),
                        Err(error) => format!("[caly] control failed: {error}"),
                    };
                queue_control_message(&worker_messages, line);
            }
        }
    });
    let control_shared = std::sync::Arc::clone(&shared);
    let busy_messages = std::sync::Arc::clone(&control_messages);
    let mut on_control = move |actions: Vec<caly_tui::operation::ControlAction>| {
        let core_wire = match control_shared.lock() {
            Ok(guard) => guard
                .as_ref()
                .and_then(|snapshot| snapshot.applied().core())
                .map_or(1, core_wire),
            Err(_) => 1,
        };
        if control_tx.try_send((core_wire, actions)).is_err() {
            queue_control_message(
                &busy_messages,
                "[caly] control queue busy — action dropped until pending operations finish"
                    .to_owned(),
            );
        }
    };
    // The watch and control worker threads are intentionally not joined: on
    // quit the process exits, terminating them; dropping `on_control` closes
    // the channel so the control worker winds down on its own.
    let exit = match app.run(&mut terminal, &mut source, &mut on_control) {
        Ok(()) => ExitCode::SUCCESS,
        Err(error) => {
            match error {
                TerminalError::EnterFailed => eprintln!(
                    "tui terminal error: EnterFailed (run caly tui inside a real terminal (TTY); redirecting stdin or a non-interactive shell fails here)"
                ),
                other @ TerminalError::WriteFailed => eprintln!("tui terminal error: {other:?}"),
            }
            ExitCode::FAILURE
        }
    };
    // The alternate screen is already left at this point: flush the queued
    // control results so every operation outcome stays visible to the user.
    let mut messages = control_messages
        .lock()
        .unwrap_or_else(std::sync::PoisonError::into_inner);
    for line in messages.drain(..) {
        eprintln!("{line}");
    }
    exit
}

/// Bounded depth of the serial control worker's batch queue (audit #106).
const CONTROL_QUEUE_BATCHES: usize = 8;
/// Bounded size of the post-exit control message queue (audit #106).
const MAX_CONTROL_MESSAGES: usize = 128;

/// Appends one control result line to the post-exit queue, discarding the
/// oldest line past `MAX_CONTROL_MESSAGES` so a spamming worker cannot grow
/// memory without bound. Poison recovery keeps the queue's coherent lines.
fn queue_control_message(messages: &std::sync::Mutex<Vec<String>>, line: String) {
    let mut guard = messages
        .lock()
        .unwrap_or_else(std::sync::PoisonError::into_inner);
    if guard.len() >= MAX_CONTROL_MESSAGES {
        guard.remove(0);
    }
    guard.push(line);
}

/// Fetches and decodes the initial authoritative snapshot, re-handshaking on a
/// session rejection (expired TTL).
fn fetch_initial_snapshot(client: &mut UdsClient) -> Option<caly_domain::PresentationSnapshot> {
    let wire = match client.snapshot() {
        Ok(value) => value,
        Err(error) if is_session_reject(&error) => {
            if client.handshake(handshake_request()).is_err() {
                return None;
            }
            client.snapshot().ok()?
        }
        Err(_) => return None,
    };
    let mut budget = DecodeBudget::new(DecodeLimits::v2_default());
    snapshot_from_wire(wire, &mut budget).ok()
}

/// Runs the live watch loop on a worker thread, publishing the latest snapshot
/// into `shared`. It drives a `LiveWatchSource` (which owns the
/// `ConnectionSupervisor` + `WatchDriver` + `SessionModel`) and blocks on the
/// watch stream until it ends or the app exits.
fn run_watch_loop(
    client: UdsClient,
    initial: caly_domain::PresentationSnapshot,
    shared: std::sync::Arc<std::sync::Mutex<Option<caly_domain::PresentationSnapshot>>>,
) {
    let transport = UdsWatchTransport::open(client);
    let mut source = caly_tui::client::LiveWatchSource::new(
        initial,
        DecodeLimits::v2_default(),
        Box::new(transport),
    );
    loop {
        // Blocks until a live update or recovery; returns None only on an
        // unrecoverable connection failure.
        let Some(snapshot) = source.refresh() else {
            return;
        };
        if let Ok(mut guard) = shared.lock() {
            *guard = Some(snapshot);
        }
    }
}

/// A `WatchTransport` backed by the UDS client's continuous watch stream.
struct UdsWatchTransport {
    client: UdsClient,
    watch: Option<<UdsClient as caly_protocol::client::ClientContract>::Watch>,
}

impl UdsWatchTransport {
    fn open(mut client: UdsClient) -> Self {
        let watch = client
            .watch(caly_protocol::protocol::v2::WatchEventsRequest { after: None })
            .ok();
        Self { client, watch }
    }
}

impl caly_tui::client::WatchTransport for UdsWatchTransport {
    fn next(&mut self) -> Option<caly_protocol::protocol::v2::WatchResponse> {
        self.watch.as_mut()?.next()?.ok()
    }

    fn reconnect(&mut self) -> bool {
        if self.client.handshake(handshake_request()).is_err() {
            return false;
        }
        match self
            .client
            .watch(caly_protocol::protocol::v2::WatchEventsRequest { after: None })
        {
            Ok(watch) => {
                self.watch = Some(watch);
                true
            }
            Err(_) => false,
        }
    }
}

/// Returns whether an error is a session expiry that a fresh handshake can
/// recover, so a long-running TUI does not freeze on the session TTL.
fn is_session_reject(error: &ClientError) -> bool {
    matches!(error, ClientError::AuthenticationRejected)
}

/// Builds the handshake request used for initial connect and re-handshake.
fn handshake_request() -> HandshakeRequest {
    HandshakeRequest {
        client_version: ProtocolVersion { major: 2, minor: 0 },
        requested_features: caly_protocol::protocol::v2::all_features(),
        auth_token: crate::daemon_config::auth_token(),
    }
}

fn connect_with_retry(socket: &std::path::Path) -> Result<UdsClient, ClientError> {
    const MAX_ATTEMPTS: u32 = 5;
    const RETRY_MS: u64 = 200;
    let mut last = ClientError::TransportUnavailable;
    for attempt in 0..MAX_ATTEMPTS {
        match UdsClient::connect(socket.to_path_buf()) {
            Ok(client) => return Ok(client),
            Err(error) => {
                last = error;
                if !matches!(last, ClientError::TransportUnavailable) || attempt + 1 == MAX_ATTEMPTS
                {
                    break;
                }
                std::thread::sleep(Duration::from_millis(RETRY_MS));
            }
        }
    }
    Err(last)
}

fn report_connect_error(error: ClientError) -> ExitCode {
    eprintln!("tui connect failed: {error:?}");
    ExitCode::FAILURE
}

/// crossterm-backed `Terminal` used only in a real TTY session.
struct CrosstermTerminal;

impl Terminal for CrosstermTerminal {
    fn size(&self) -> (usize, usize) {
        crossterm::terminal::size().map_or((80, 24), |(cols, rows)| (cols as usize, rows as usize))
    }

    fn enter(&mut self) -> Result<(), TerminalError> {
        enable_raw_mode().map_err(|_| TerminalError::EnterFailed)?;
        execute!(
            std::io::stdout(),
            EnterAlternateScreen,
            crossterm::event::EnableMouseCapture
        )
        .map_err(|_| TerminalError::EnterFailed)?;
        Ok(())
    }

    fn leave(&mut self) {
        let _ = execute!(
            std::io::stdout(),
            crossterm::event::DisableMouseCapture,
            LeaveAlternateScreen
        );
        let _ = disable_raw_mode();
    }

    fn write(&mut self, frame: &str) -> Result<(), TerminalError> {
        use std::io::Write;
        let mut stdout = std::io::stdout();
        execute!(stdout, crossterm::cursor::MoveTo(0, 0))
            .and_then(|()| stdout.write_all(frame.as_bytes()))
            .and_then(|()| stdout.flush())
            .map_err(|_| TerminalError::WriteFailed)
    }

    fn read_event(&mut self) -> Option<Event> {
        if !event::poll(Duration::from_millis(0)).unwrap_or(false) {
            return None;
        }
        let event = event::read().ok()?;
        Some(map_event(event))
    }
}

/// Maps a Domain core kind to its Clash-compatible wire integer (used by the
/// TUI's `restart core` control action).
fn core_wire(kind: caly_domain::CoreKind) -> i32 {
    match kind {
        caly_domain::CoreKind::Mihomo | caly_domain::CoreKind::Xray => 1,
        caly_domain::CoreKind::SingBox => 2,
    }
}

/// Maps a crossterm event into the TUI event model.
fn map_event(event: CrosstermEvent) -> Event {
    match event {
        CrosstermEvent::Key(key) if key.kind == KeyEventKind::Press => {
            Event::Key(map_key(key.code))
        }
        CrosstermEvent::Mouse(mouse)
            if mouse.kind
                == crossterm::event::MouseEventKind::Down(crossterm::event::MouseButton::Left) =>
        {
            Event::Click {
                col: mouse.column as usize,
                row: mouse.row as usize,
            }
        }
        CrosstermEvent::Resize(cols, rows) => Event::Resize {
            cols: cols as usize,
            rows: rows as usize,
        },
        _ => Event::Key(Key::Char(' ')),
    }
}

/// Maps a crossterm key code into the TUI key model.
fn map_key(code: KeyCode) -> Key {
    match code {
        KeyCode::Char(ch) => Key::Char(ch),
        KeyCode::Enter => Key::Enter,
        KeyCode::Tab => Key::Tab,
        KeyCode::Esc => Key::Esc,
        KeyCode::Up => Key::Up,
        KeyCode::Down => Key::Down,
        KeyCode::Left => Key::Left,
        KeyCode::Right => Key::Right,
        KeyCode::Home => Key::Home,
        KeyCode::End => Key::End,
        KeyCode::PageUp => Key::PageUp,
        KeyCode::PageDown => Key::PageDown,
        _ => Key::Char(' '),
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn session_reject_triggers_rehandshake_only_for_auth_rejection() {
        assert!(is_session_reject(&ClientError::AuthenticationRejected));
        assert!(!is_session_reject(&ClientError::TransportUnavailable));
        assert!(!is_session_reject(&ClientError::DeadlineExceeded));
        assert!(!is_session_reject(&ClientError::ResourceExhausted));
    }

    #[test]
    fn handshake_request_is_stable_v2() {
        let request = handshake_request();
        assert_eq!(request.client_version.major, 2);
        assert_eq!(request.client_version.minor, 0);
    }

    #[test]
    fn key_codes_map_to_tui_keys() {
        assert_eq!(map_key(KeyCode::Up), Key::Up);
        assert_eq!(map_key(KeyCode::Char('q')), Key::Char('q'));
        assert_eq!(map_key(KeyCode::Esc), Key::Esc);
        assert_eq!(map_key(KeyCode::PageDown), Key::PageDown);
    }

    #[test]
    fn mouse_maps_to_click() {
        let mapped = map_event(CrosstermEvent::Mouse(crossterm::event::MouseEvent {
            kind: crossterm::event::MouseEventKind::Down(crossterm::event::MouseButton::Left),
            column: 5,
            row: 3,
            modifiers: crossterm::event::KeyModifiers::NONE,
        }));
        assert_eq!(mapped, Event::Click { col: 5, row: 3 });
    }

    #[test]
    fn scroll_and_move_do_not_map_to_click() {
        let scroll = CrosstermEvent::Mouse(crossterm::event::MouseEvent {
            kind: crossterm::event::MouseEventKind::ScrollDown,
            column: 78,
            row: 0,
            modifiers: crossterm::event::KeyModifiers::NONE,
        });
        assert_ne!(map_event(scroll), Event::Click { col: 78, row: 0 });
        let moved = CrosstermEvent::Mouse(crossterm::event::MouseEvent {
            kind: crossterm::event::MouseEventKind::Moved,
            column: 78,
            row: 0,
            modifiers: crossterm::event::KeyModifiers::NONE,
        });
        assert_ne!(map_event(moved), Event::Click { col: 78, row: 0 });
    }
}
