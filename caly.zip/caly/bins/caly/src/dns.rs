//! `caly dns` — DNS reachability diagnostic.
//!
//! Probes the configured (or default public) nameservers for a domain and
//! reports each result. Uses the bounded `caly_platform::dns_probe` client so
//! it works without a full DNS library.

use caly_platform::dns_probe::{DNS_PROBE_TIMEOUT, DnsProbeOutcome, probe_nameserver};
use std::process::ExitCode;

/// Default nameservers to probe when `CALY_DNS_NAMESERVERS` is unset.
const DEFAULT_NAMESERVERS: &[&str] = &["8.8.8.8", "1.1.1.1", "223.5.5.5"];

/// Runs a DNS reachability diagnostic for `domain`.
pub fn run_dns(domain: Option<String>) -> ExitCode {
    let domain = domain.unwrap_or_else(|| "example.com".to_owned());
    let nameservers = configured_nameservers();
    let mut any_resolved = false;
    println!("dns probe for {domain}:");
    for nameserver in &nameservers {
        let outcome = probe_nameserver(nameserver, &domain, DNS_PROBE_TIMEOUT);
        match outcome {
            DnsProbeOutcome::Resolved(Some(address)) => {
                println!("  {nameserver:<16} {address}");
                any_resolved = true;
            }
            DnsProbeOutcome::Resolved(None) => {
                println!("  {nameserver:<16} resolved");
                any_resolved = true;
            }
            other => println!("  {nameserver:<16} {other:?}"),
        }
    }
    if any_resolved {
        ExitCode::SUCCESS
    } else {
        eprintln!("dns: no configured nameserver resolved {domain}");
        ExitCode::from(3)
    }
}

/// Resolves the nameservers to probe: `CALY_DNS_NAMESERVERS` first, then the
/// `dns` section of the layered config, then built-in public defaults.
fn configured_nameservers() -> Vec<String> {
    nameservers_from(|| std::env::var("CALY_DNS_NAMESERVERS").ok())
}

fn nameservers_from(get: impl Fn() -> Option<String>) -> Vec<String> {
    let parsed = get().map_or_else(Vec::new, parse_nameserver_list);
    if !parsed.is_empty() {
        return parsed;
    }
    let configured = crate::daemon_config::dns_nameservers();
    if !configured.is_empty() {
        return configured;
    }
    DEFAULT_NAMESERVERS
        .iter()
        .map(|value| (*value).to_owned())
        .collect()
}

fn parse_nameserver_list(value: String) -> Vec<String> {
    value
        .split(',')
        .map(str::trim)
        .filter(|part| !part.is_empty())
        .map(str::to_owned)
        .collect()
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn nameservers_parse_comma_list() {
        assert_eq!(
            parse_nameserver_list("1.1.1.1, 9.9.9.9".to_owned()),
            vec!["1.1.1.1", "9.9.9.9"]
        );
        assert!(parse_nameserver_list("   ".to_owned()).is_empty());
    }

    #[test]
    fn defaults_are_public_resolvers() {
        assert_eq!(DEFAULT_NAMESERVERS[0], "8.8.8.8");
    }
}
