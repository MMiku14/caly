//! Structured logging bootstrap for the daemon and CLI.
//!
//! Installs a `tracing` subscriber that writes timestamped, level-filtered
//! log lines to stderr. The filter is taken from `CALY_LOG` when present,
//! then `RUST_LOG`, then a conservative default (`info`) so a daemon does
//! not flood its log in the common case. `CALY_LOG_FORMAT=json` switches
//! the human line format to one JSON object per line (for journald / log
//! shippers); anything else keeps the human format.
//!
//! # Event convention (all crates)
//!
//! - one event per state change, not per poll tick: `started`, `stopped`,
//!   `failed`, `rejected`, `submitted`, `completed`.
//! - correlation fields, always spelled the same way: `daemon_id` (the
//!   `daemon` span), `operation` (a [`caly_domain::OperationId`]), `core`
//!   (`mihomo` / `sing-box`), `source` (subscription URL host), `path`.
//! - messages are sentences, never `Debug` dumps: no `{error:?}` in the
//!   message — structured errors carry `message` + `hint` fields instead.
//! - secrets never appear in fields: tokens, keys, and full URLs with
//!   credentials stay out (hosts are fine).
//!
//! The subscriber is installed at most once; callers that spawn a client (a
//! separate process, or before the daemon initializes) are safe to call this
//! again because it is idempotent and never panics on a duplicate install.

use tracing_subscriber::EnvFilter;

/// Installs the process-wide tracing subscriber, honoring `CALY_LOG` then
/// `RUST_LOG` for the filter and `CALY_LOG_FORMAT=json` for JSON lines.
/// Returns whether a subscriber is now active for this process.
pub fn init() -> bool {
    let filter = std::env::var("CALY_LOG")
        .ok()
        .or_else(|| std::env::var("RUST_LOG").ok())
        .or_else(|| Some(caly_ops::config::log_level()))
        .unwrap_or_else(|| "info".to_owned());
    // `EnvFilter::new` *panics* on an unparseable directive, and
    // the directive comes from the process environment — one bad `CALY_LOG`
    // value used to abort every caly process at startup. Fall back to the
    // default level instead.
    let filter = EnvFilter::try_new(with_third_party_caps(filter)).unwrap_or_else(|error| {
        eprintln!("caly: ignoring invalid log filter ({error}); using `info`");
        EnvFilter::new("info")
    });
    if json_format_requested() {
        return tracing_subscriber::fmt()
            .json()
            .with_env_filter(filter)
            .with_writer(std::io::stderr)
            .with_target(false)
            .try_init()
            .is_ok();
    }
    tracing_subscriber::fmt()
        .with_env_filter(filter)
        .with_writer(std::io::stderr)
        .with_target(false)
        .try_init()
        .is_ok()
}

/// Whether `CALY_LOG_FORMAT` asks for JSON lines. Compared
/// case-insensitively; unset or anything else keeps human lines.
fn json_format_requested() -> bool {
    is_json_format(std::env::var("CALY_LOG_FORMAT").ok())
}

/// Pure predicate behind [`json_format_requested`] so the matching is
/// unit-testable without touching the process environment.
fn is_json_format(value: Option<String>) -> bool {
    value.is_some_and(|value| value.eq_ignore_ascii_case("json"))
}

/// Caps verbose third-party transport crates at `info` so a `debug` filter
/// surfaces caly business events instead of per-frame h2/hyper noise. A target
/// the user already configured explicitly is left untouched.
fn with_third_party_caps(filter: String) -> String {
    let mut out = filter;
    for target in ["h2", "hyper", "tonic", "tower"] {
        // also treat `target::sub=level` (a more specific module
        // under the cap) as "already configured" — capping `h2` when the
        // operator set `h2::codec=debug` was untidy even though EnvFilter's
        // specificity rules made the outcome accidentally correct.
        let already_configured = out.split(',').any(|directive| {
            let trimmed = directive.trim();
            trimmed == target
                || trimmed
                    .strip_prefix(target)
                    .is_some_and(|rest| rest.starts_with('=') || rest.starts_with("::"))
        });
        if !already_configured {
            let _ = std::fmt::Write::write_fmt(&mut out, format_args!(",{target}=info"));
        }
    }
    out
}

#[cfg(test)]
mod tests {
    use super::*;

    /// A duplicate install must not panic (idempotent) and only the first wins.
    #[test]
    fn init_is_idempotent_and_does_not_panic() {
        // Whichever call wins, neither may panic; a process may call init more
        // than once (e.g. client then daemon paths).
        let _first = init();
        let _second = init();
        // A structured event through the subscriber must also not panic.
        tracing::info!("structured logging initialized for test");
    }

    #[test]
    fn json_format_matches_case_insensitively_with_human_default() {
        assert!(is_json_format(Some("json".to_owned())));
        assert!(is_json_format(Some("JSON".to_owned())));
        assert!(!is_json_format(None));
        assert!(!is_json_format(Some("human".to_owned())));
        assert!(!is_json_format(Some(String::new())));
    }

    #[test]
    fn third_party_caps_skip_sub_module_directives() {
        // a `h2::codec=debug` user directive counts as
        // configured for the `h2` cap.
        let capped = with_third_party_caps("debug,h2::codec=debug".to_owned());
        assert!(!capped.contains("h2=info"));
        assert!(capped.contains("h2::codec=debug"));
        assert!(capped.contains("hyper=info"));
    }

    #[test]
    fn third_party_caps_append_without_overriding_user_directives() {
        let capped = with_third_party_caps("debug".to_owned());
        assert!(capped.contains("h2=info"));
        assert!(capped.contains("hyper=info"));
        assert!(capped.starts_with("debug"));
        // Explicit user configuration of a noisy target is preserved.
        let preserved = with_third_party_caps("debug,h2=debug".to_owned());
        assert!(!preserved.contains("h2=info"));
        assert!(preserved.contains("h2=debug"));
        assert!(preserved.contains("hyper=info"));
    }
}
