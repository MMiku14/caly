//! Audit #61: `set provider` CLI leaf dispatcher.
//!
//! Each `SetProviderCmd` variant is one leaf in the
//! `set provider` family (the management plane for the
//! `providers:` section — declared proxy-content containers).
//! All 3 leaves round-trip `providers: Vec<ProviderConfig>`
//! in `config.yaml` through `client::provider`, and route
//! through the shared `commands::set::common::run_standard_writer`
//! envelope so the JSON shape / human summary /
//! `--apply` / `--dry-run` policy is identical to the
//! other `set` resources.

use std::process::ExitCode;

use crate::cli::SetProviderCmd;
use crate::client::provider as cmd;
use crate::commands::set::common::{ResourceVerb, run_standard_writer};
use crate::output::CliOutput;

/// The singular resource name used by
/// [`run_standard_writer`] for every `set provider` leaf.
const NOUN: &str = "provider";

/// The leaf-prefix token (the second token in the
/// `set provider <verb> <id>` leaf string).
const CLI_PREFIX: &str = "provider";

/// Projects a `cmd::ProviderWriteError` to the stable CLI
/// `code:` used in the JSON error envelope.
fn code_for(error: &cmd::ProviderWriteError) -> &'static str {
    use cmd::ProviderWriteError as E;
    match error {
        E::InvalidName(_) => "provider.invalid_name",
        E::InvalidNode(_) => "provider.invalid_node",
        E::AlreadyDeclared(_) => "provider.already_declared",
        E::NotDeclared(_) => "provider.not_declared",
        E::Shared(shared) => match shared {
            crate::client::resource_writer::ResourceError::Invalid(_) => "provider.invalid",
            crate::client::resource_writer::ResourceError::Write(_) => "provider.write_failed",
            crate::client::resource_writer::ResourceError::Parse(_) => "provider.parse_failed",
            crate::client::resource_writer::ResourceError::Validate(_) => {
                "provider.validate_failed"
            }
            crate::client::resource_writer::ResourceError::AlreadyDeclared(_) => {
                "provider.already_declared"
            }
            crate::client::resource_writer::ResourceError::NotDeclared(_) => {
                "provider.not_declared"
            }
        },
    }
}

/// Dispatches a `set provider` leaf to the matching writer.
/// The `dispatch` shim resolves the operator's `AppPaths`
/// from process env (the production path);
/// `dispatch_with_paths` takes the paths explicitly so a
/// test can drive the dispatch with a hermetic fixture.
pub fn dispatch(
    cmd_arg: SetProviderCmd,
    options: crate::cli::CliOptions,
    output: CliOutput,
) -> ExitCode {
    let paths = caly_platform::paths::AppPaths::from_env();
    dispatch_with_paths(cmd_arg, &paths, options, output)
}

/// The path-injected dispatch (see [`dispatch`]).
pub fn dispatch_with_paths(
    cmd_arg: SetProviderCmd,
    paths: &caly_platform::paths::AppPaths,
    _options: crate::cli::CliOptions,
    output: CliOutput,
) -> ExitCode {
    match cmd_arg {
        SetProviderCmd::AddSources {
            name,
            apply,
            dry_run,
        } => {
            let effective_apply = apply && !dry_run;
            run_standard_writer(
                output,
                CLI_PREFIX,
                NOUN,
                ResourceVerb::Add,
                &name,
                || cmd::add_sources_provider(paths, &name, effective_apply),
                code_for,
            )
        }
        SetProviderCmd::AddNodes {
            name,
            nodes,
            apply,
            dry_run,
        } => {
            let effective_apply = apply && !dry_run;
            run_standard_writer(
                output,
                CLI_PREFIX,
                NOUN,
                ResourceVerb::Add,
                &name,
                || cmd::add_nodes_provider(paths, &name, &nodes, effective_apply),
                code_for,
            )
        }
        SetProviderCmd::Remove {
            name,
            apply,
            dry_run,
        } => {
            let effective_apply = apply && !dry_run;
            run_standard_writer(
                output,
                CLI_PREFIX,
                NOUN,
                ResourceVerb::Remove,
                &name,
                || cmd::remove_provider(paths, &name, effective_apply),
                code_for,
            )
        }
    }
}
