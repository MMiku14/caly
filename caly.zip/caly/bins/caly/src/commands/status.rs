//! `caly show status` — daemon snapshot.

use std::process::ExitCode;

use crate::output::CliOutput;

pub fn run(options: crate::cli::CliOptions, _output: CliOutput) -> ExitCode {
    crate::client::run_client(crate::ClientCommand::Status, options)
}
