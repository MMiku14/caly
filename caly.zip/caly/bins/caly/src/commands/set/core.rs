//! `set core …` dispatch.
//!
//! Round 15: each `SetCoreCmd` variant maps to the typed
//! `client::ClientCommand::Core(...)` path directly (the
//! `bridge` shim was retired). Round 16: `url-test` is
//! the single-node `core delay` path with explicit
//! `--url`. Round 24 (debug): the `--timeout` flag on
//! `url-test` was silently dropped by the dispatch (the
//! offline `Query::UrlTest` resolver has a hard-coded
//! `QUERY_TIMEOUT` constant, no per-call override path).
//! The flag is removed from the grammar so the operator
//! sees a clap error instead of a no-op success.

use std::process::ExitCode;

use crate::cli::SetCoreCmd;
use crate::client::legacy::CoreCmd;
use crate::output::CliOutput;

pub fn dispatch(c: SetCoreCmd, options: crate::cli::CliOptions, _output: CliOutput) -> ExitCode {
    let mapped = match c {
        SetCoreCmd::Start => CoreCmd::Start,
        SetCoreCmd::Stop => CoreCmd::Stop,
        SetCoreCmd::Restart => CoreCmd::Restart,
        SetCoreCmd::Switch(core) => CoreCmd::Switch(core),
        SetCoreCmd::Select { node, delay } => CoreCmd::Select { node, delay },
        SetCoreCmd::Mode(m) => CoreCmd::Mode(m),
        SetCoreCmd::CloseConnections => CoreCmd::CloseConnections,
        SetCoreCmd::Delay {
            name,
            all,
            url,
            samples,
        } => CoreCmd::Delay {
            all,
            name,
            url,
            samples,
        },
        // Round 15: `set core url-test` is still routed
        // through the existing single-node `core delay`
        // path. A dedicated `WireCommand::UrlTest` is on
        // the roadmap; the fallback means a Round 15
        // user can already exercise the new leaf today.
        // The `samples` argument is honoured: the
        // offline `Query::UrlTest` resolver maps
        // `None` to the writer's default (3).
        SetCoreCmd::UrlTest { name, url, samples } => {
            return crate::client::run_client(
                crate::ClientCommand::Core(CoreCmd::Delay {
                    all: false,
                    name: Some(name),
                    url,
                    samples,
                }),
                options,
            );
        }
    };
    crate::client::run_client(crate::ClientCommand::Core(mapped), options)
}
