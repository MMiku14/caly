//! Shared helpers for `set` resource dispatch.
//!
//! Round 13: extracted from `commands::set::profile` so the
//! other resources can reuse the same shape if they grow
//! past pure planned-ok stubs.
//!
//! Round 21: the per-resource `run_writer` closures in
//! `commands::set::{sub, rule_provider, proxy_group}` were
//! three near-identical copies of the same `Ok(_)` / `Err(_)`
//! match — each projected a per-resource `XxxWriteError`
//! to a `code: &str` and a human summary. This module
//! owns the *common* part (the JSON envelope shape, the
//! success / dry-run differentiation, the error reporting
//! pipeline); the per-resource dispatch is a one-line
//! shim that supplies a `code_for` closure and a `summary`
//! lookup.

use std::process::ExitCode;

use crate::output::{self, CliOutput};

/// The shape every `set RESOURCE VERB` dispatch
/// surfaces in the JSON envelope: a `name:` (the
/// resource's stable id) and a `leaf:` (the literal
/// verb the user typed, for log-grep). The `dry_run`
/// flag is added from the writer's outcome.
#[derive(Debug, Clone)]
pub struct WriteEnvelope<'a> {
    /// The resource's stable id (`group` / `provider` /
    /// `rule_provider` / etc.).
    pub name: &'a str,
    /// The verb the user typed (`set sub add
    /// https://…` → `set sub add https://…`).
    pub leaf: &'a str,
}

/// The three human summaries a `set RESOURCE VERB` leaf
/// emits. The applied-path line is the verb in past
/// tense (`X added`); the dry-run line is the same
/// with `would be` and `(dry-run)` (`X would be added
/// (dry-run)`); the no-change line is the noun in its
/// target state (`X already enabled`, `X already disabled`).
///
/// Round 25: the `no_change` variant was added so idempotent
/// operations (e.g. `enable` on an already-enabled source)
/// report a distinct summary instead of a fabricated
/// `Applied`. The previous writer shape short-circuited
/// such calls with a literal `Applied` outcome but no
/// disk I/O, so the operator saw `ok: subscription source
/// enabled` and assumed the state was just changed. The
/// new variant round-trips through [`Summaries::standard`]
/// (which builds the no-change string from a noun + verb
/// pair the same way it builds the applied / dry-run
/// pairs); a bespoke leaf (e.g. `proxy import`) inlines
/// all three strings explicitly.
///
/// Round 30: the previous `Summaries { applied: String,
/// dry_run: String, no_change: String }` struct eagerly
/// built all 3 strings at construction time even though
/// every dispatch only consumed one of them. The new
/// enum stores either the (noun, verb) pair used by
/// [`Summaries::standard`] (which derives all 3 lines
/// from a single past-tense lookup at read time) or
/// the 3 literal `&'static str` lines used by
/// [`Summaries::custom`]; [`Summaries::summary_for`]
/// builds the single needed `String` per call, cutting
/// 2 of 3 heap allocations on the hot path. The
/// `Copy` derive means the dispatch can pass it around
/// without a `Clone` shim.
#[derive(Debug, Clone, Copy)]
pub enum Summaries {
    /// A `X <past-tense>` / `X would be <past-tense>
    /// (dry-run)` / `X already <past-tense>` triple
    /// built lazily from a noun + [`ResourceVerb`] pair
    /// (the 4 standard resources' shape).
    Standard {
        /// The singular resource name (`"subscription
        /// source"` / `"rule provider"` / `"proxy
        /// group"` / `"profile"` / etc.). Distinct from
        /// the CLI prefix used in the leaf string.
        noun: &'static str,
        /// The verb that drives the past-tense lookup.
        verb: ResourceVerb,
    },
    /// A bespoke 3-line summary for verbs that don't
    /// fit the standard `X <past-tense>` template
    /// (`set profile edit` / `set profile export` /
    /// `set proxy edit` / `set proxy import`). The
    /// 3 `&'static str` are the applied / dry-run /
    /// no-change lines verbatim.
    Custom {
        /// The applied-path summary (e.g. `"profile
        /// edited"`).
        applied: &'static str,
        /// The dry-run-path summary (e.g. `"profile
        /// would be edited (dry-run)"`).
        dry_run: &'static str,
        /// The no-change-path summary (e.g. `"profile
        /// already edited"`). For writers that don't
        /// currently surface a `NoChange` outcome this
        /// string is reserved for a future round that
        /// adds the comparison; the dispatch still
        /// pattern-matches the [`OutcomeKind`] arm.
        no_change: &'static str,
    },
}

/// The four standard CRUD verbs every `set RESOURCE`
/// dispatch exposes. `Edit` and `Export` are
/// resource-specific (only `set profile` uses them)
/// and stay outside this enum; `Import` is a 1-of-1
/// oddity (only `set proxy import` exists, with its
/// own bespoke summary shape).
///
/// Round 23: the enum is the dispatch-time source of
/// truth for the verb's English past tense and CLI
/// name. The 4 standard resources use
/// [`Summaries::standard`] with one of these variants;
/// the profile dispatch uses its own typed `ProfileVerb`
/// enum to extend the set with `Edit` / `Export`.
#[derive(Clone, Copy, Eq, PartialEq, Debug)]
pub enum ResourceVerb {
    Add,
    Remove,
    Enable,
    Disable,
}

impl ResourceVerb {
    /// The verb's English past-tense form, used in
    /// the applied-path summary ("added" / "removed" / ...).
    pub const fn past_tense(self) -> &'static str {
        match self {
            Self::Add => "added",
            Self::Remove => "removed",
            Self::Enable => "enabled",
            Self::Disable => "disabled",
        }
    }

    /// The verb's CLI name (the second token in the
    /// `set RESOURCE VERB ID` leaf). The
    /// `set_profile_verb::leaf()` method uses the
    /// same convention; the two are kept consistent
    /// so a future caller can use one table for both.
    /// Round 29: the `#[allow(dead_code)]` was
    /// removed — `run_standard_writer` is now the
    /// primary consumer of the table, and the table
    /// would surface a typo here as a compile error
    /// in every standard-resource dispatch.
    pub const fn cli_name(self) -> &'static str {
        match self {
            Self::Add => "add",
            Self::Remove => "remove",
            Self::Enable => "enable",
            Self::Disable => "disable",
        }
    }
}

impl Summaries {
    /// The standard 4-verb `X <past-tense>` /
    /// `X would be <past-tense> (dry-run)` /
    /// `X already <past-tense>` summary triple. The 4
    /// standard resources (`set sub` /
    /// `set rule-provider` / `set proxy-group` /
    /// `set proxy`) call this once per verb; the
    /// profile dispatch uses its own `summaries_for`
    /// helper (private to the profile module)
    /// because it has 2 extra verbs (edit / export)
    /// that don't fit the standard shape.
    ///
    /// Round 25: the `no_change` line is `X already
    /// <past-tense>` (e.g. `subscription source
    /// already enabled`). The verb's past-tense form
    /// is reused: `Add` → `added` → `already added`,
    /// which is correct for `remove` (an `add` after
    /// a `remove` re-`add`s the entry) and for
    /// `enable` / `disable` (an `enable` against an
    /// already-enabled source is the canonical
    /// idempotent case).
    ///
    /// Round 30: stores only the `(noun, verb)` pair;
    /// the 3 `String` lines are built lazily in
    /// [`Summaries::summary_for`] when the dispatch
    /// reaches the `Ok(outcome)` arm. This avoids 2
    /// of 3 heap allocations on every dispatch (the
    /// 2 summary lines the writer's outcome doesn't
    /// pick are never built).
    pub fn standard(noun: &'static str, verb: ResourceVerb) -> Self {
        Self::Standard { noun, verb }
    }

    /// The bespoke-summary constructor for verbs that
    /// do not fit the `X <past-tense>` template (e.g.
    /// `set profile edit` / `set profile export` /
    /// `set proxy import`). The three strings are the
    /// applied / dry-run / no-change lines verbatim;
    /// the dispatch's `run_writer` envelope projects
    /// them into the JSON envelope and the human
    /// summary unchanged. Round 26 introduced this
    /// helper so the 4 inline `Summaries { ... }`
    /// literals (profile Edit / Export, proxy Edit /
    /// Import) collapse into a one-line call site.
    ///
    /// Round 30: takes `&'static str` (the previous
    /// `impl Into<String>` was unused — every call
    /// site passed a string literal). The
    /// `&'static str` shape lets `Custom` participate
    /// in the same `Copy` enum as `Standard`, so the
    /// dispatch can pass `Summaries` by value without
    /// a `Clone` shim.
    pub fn custom(
        applied: &'static str,
        dry_run: &'static str,
        no_change: &'static str,
    ) -> Self {
        Self::Custom {
            applied,
            dry_run,
            no_change,
        }
    }

    /// Build the single human-summary line the
    /// dispatch needs for the writer's outcome kind.
    /// Round 30: replaces the previous 3-arm `match
    /// kind { Applied => summaries.applied, ... }`
    /// inside [`run_writer`]. The `Standard` arm
    /// does the `format!` per call (1 alloc per
    /// outcome, not 3), the `Custom` arm does a
    /// `String::from` on the relevant `&'static
    /// str` (1 alloc per outcome, not 3). The
    /// pre-Round-30 implementation eagerly built
    /// all 3 lines in [`Summaries::standard`] /
    /// [`Summaries::custom`] even though the
    /// dispatch consumed only one; the
    /// lazy-evaluated version saves 2 of 3
    /// allocations on every call.
    pub fn summary_for(&self, kind: OutcomeKind) -> String {
        match (self, kind) {
            (
                Self::Standard { noun, verb },
                OutcomeKind::Applied,
            ) => format!("{noun} {}", verb.past_tense()),
            (
                Self::Standard { noun, verb },
                OutcomeKind::DryRun,
            ) => format!("{noun} would be {} (dry-run)", verb.past_tense()),
            (
                Self::Standard { noun, verb },
                OutcomeKind::NoChange,
            ) => format!("{noun} already {}", verb.past_tense()),
            (Self::Custom { applied, .. }, OutcomeKind::Applied) => {
                (*applied).to_owned()
            }
            (Self::Custom { dry_run, .. }, OutcomeKind::DryRun) => {
                (*dry_run).to_owned()
            }
            (Self::Custom { no_change, .. }, OutcomeKind::NoChange) => {
                (*no_change).to_owned()
            }
        }
    }
}

/// Round 25: the per-call outcome classification the
/// dispatch's [`run_writer`] uses to pick the right
/// human summary. The previous `is_dry_run: Fn(&O) ->
/// bool` could not distinguish `Applied` from
/// `NoChange` (both rendered as "applied" with
/// `dry_run: false`), which is how the Round 25 bug
/// (`set sub enable` against an already-enabled URL
/// reporting `Applied` with no disk I/O) stayed
/// hidden. The new closure returns one of three
/// explicit kinds; the dispatch maps each kind to a
/// distinct summary line.
#[derive(Debug, Clone, Copy, Eq, PartialEq)]
pub enum OutcomeKind {
    /// The writer actually mutated the on-disk state.
    Applied,
    /// The writer validated the change but did not
    /// write (the user did not pass `--apply`).
    DryRun,
    /// The writer observed that the on-disk state was
    /// already the target state (idempotent call), so
    /// neither the apply path nor the dry-run path did
    /// any I/O. The dispatch emits a distinct "already
    /// in the target state" summary.
    NoChange,
}

impl OutcomeKind {
    /// True when the writer performed a no-op
    /// (idempotent success). The dispatch surfaces
    /// this as `dry_run: false` in the JSON envelope
    /// — the user did not opt in to a preview — but
    /// uses a distinct human summary so the operator
    /// can tell apart "I changed the state" from "I
    /// confirmed the state was already what I asked
    /// for".
    #[allow(dead_code)] // test-only consumer in the bin
                       // unit (the locked-table test in
                       // `tests` matches every kind).
                       // Reserved for a future refresh
                       // leaf that needs the
                       // discriminator without
                       // hand-rolling the match.
    pub const fn is_no_change(self) -> bool {
        matches!(self, Self::NoChange)
    }
}

/// Round 23: the no-op `extra_payload` closure. The
/// `set RESOURCE VERB` writers that don't carry any
/// outcome-specific data beyond the envelope's `name` /
/// `leaf` / `dry_run` (every existing writer except
/// `add proxy` and `import proxy`) pass this so the
/// type-inferred `X: Fn(&O) -> serde_json::Value` slot
/// in [`run_writer`] is satisfied. The closure ignores
/// the outcome and returns an empty JSON object, which
/// the envelope merge treats as a no-op.
pub fn no_extra_payload<O>(_outcome: &O) -> serde_json::Value {
    serde_json::Value::Object(serde_json::Map::new())
}

/// Round 26: the canonical `classify` closure for
/// every writer that surfaces the standard
/// [`crate::client::resource_writer::ResourceWriteOutcome`]
/// (5 type aliases: `SubWriteOutcome` /
/// `ProfileWriteOutcome` / `RpWriteOutcome` /
/// `PgWriteOutcome` / `InlineProxyOutcome`-aliased).
///
/// Before this round each dispatch module had its own
/// 5-line `match` closure that did the same
/// `Applied` → `Applied` / `DryRun` → `DryRun` /
/// `NoChange` → `NoChange` projection (see
/// `commands::set::sub::classify` for the most
/// literal copy of the 3-arm pattern). The closure
/// here is the single source of truth; the 4
/// `set RESOURCE` dispatch modules call it
/// directly, and the `set proxy` dispatch keeps its
/// bespoke `classify_inline` / `classify_import`
/// because the inline-proxy enums carry per-call
/// payloads (the `id` for `add` / the `count` for
/// `import`).
///
/// The `&ResourceWriteOutcome` argument is the
/// `Fn(&O) -> OutcomeKind` trait bound on
/// [`run_writer`]; the type is `Copy` so the `&`
/// triggers a pedantic
/// `trivially_copy_pass_by_ref` lint. The `#[allow]`
/// lives on the `pub fn` so the lint is silenced
/// here (the function definition is the one source
/// of truth for the parameter shape; silencing at
/// the call sites would require 4 parallel
/// `#[allow]` attributes — one per dispatch module).
#[allow(clippy::trivially_copy_pass_by_ref)]
pub fn classify_resource_outcome(
    outcome: &crate::client::resource_writer::ResourceWriteOutcome,
) -> OutcomeKind {
    use crate::client::resource_writer::ResourceWriteOutcome as O;
    match outcome {
        O::Applied => OutcomeKind::Applied,
        O::DryRun => OutcomeKind::DryRun,
        O::NoChange => OutcomeKind::NoChange,
    }
}

#[cfg(test)]
mod summaries_tests {
    //! Round 23: the `Summaries::standard(noun, verb)`
    //! constructor is the single point of truth for the
    //! 16 standard-verb summary pairs (4 nouns × 4
    //! verbs). These tests lock the strings so a future
    //! typo in `ResourceVerb::past_tense` or in the
    //! `format!` template surfaces here, not in a
    //! dispatch regression test.
    //!
    //! Round 25: the constructor now returns a *triple*
    //! (applied / dry-run / no-change). The tests
    //! extend the lock to the third column so a
    //! future rename of the no-change shape surfaces
    //! here, not in a dispatch regression.
    //!
    //! Round 30: `Summaries` is an enum (`Standard` /
    //! `Custom`); the 3 lines are built lazily by
    //! [`Summaries::summary_for`]. The tests now
    //! exercise the 3 [`OutcomeKind`] arms so a
    //! future typo in the `summary_for` match arms
    //! surfaces here, not in a dispatch regression.
    use super::{OutcomeKind, ResourceVerb, Summaries};

    #[test]
    fn standard_summary_matches_legacy_inlined_strings() {
        // The 4 standard nouns + 4 verbs × 3 paths =
        // 12 expected strings. Cross-checked against
        // the pre-Round-23 inline `Summaries { ... }`
        // literals in `commands/set/{sub,rule_provider,
        // proxy_group,proxy}.rs` for the applied /
        // dry-run pair, and against the Round 25
        // `no_change` template for the third column.
        for (noun, verb, applied, dry_run, no_change) in [
            (
                "subscription source",
                ResourceVerb::Add,
                "subscription source added",
                "subscription source would be added (dry-run)",
                "subscription source already added",
            ),
            (
                "subscription source",
                ResourceVerb::Remove,
                "subscription source removed",
                "subscription source would be removed (dry-run)",
                "subscription source already removed",
            ),
            (
                "rule provider",
                ResourceVerb::Enable,
                "rule provider enabled",
                "rule provider would be enabled (dry-run)",
                "rule provider already enabled",
            ),
            (
                "proxy group",
                ResourceVerb::Disable,
                "proxy group disabled",
                "proxy group would be disabled (dry-run)",
                "proxy group already disabled",
            ),
        ] {
            let summaries = Summaries::standard(noun, verb);
            assert_eq!(summaries.summary_for(OutcomeKind::Applied), applied);
            assert_eq!(summaries.summary_for(OutcomeKind::DryRun), dry_run);
            assert_eq!(summaries.summary_for(OutcomeKind::NoChange), no_change);
        }
    }

    #[test]
    fn past_tense_table_is_locked() {
        // A typo in `past_tense` (e.g. "add" instead of
        // "added") would silently produce a wrong
        // summary line. Lock the 4 entries here.
        assert_eq!(ResourceVerb::Add.past_tense(), "added");
        assert_eq!(ResourceVerb::Remove.past_tense(), "removed");
        assert_eq!(ResourceVerb::Enable.past_tense(), "enabled");
        assert_eq!(ResourceVerb::Disable.past_tense(), "disabled");
    }

    #[test]
    fn cli_name_table_is_locked() {
        // The CLI name table feeds a future unified
        // dispatch router (it would build the `set
        // RESOURCE VERB ID` leaf prefix). Lock
        // it here so a rename lands in the tests
        // before it lands in the dispatch.
        assert_eq!(ResourceVerb::Add.cli_name(), "add");
        assert_eq!(ResourceVerb::Remove.cli_name(), "remove");
        assert_eq!(ResourceVerb::Enable.cli_name(), "enable");
        assert_eq!(ResourceVerb::Disable.cli_name(), "disable");
    }

    #[test]
    fn custom_summary_for_each_kind() {
        // Round 30: the `Custom` arm of
        // `summary_for` projects the 3
        // `&'static str` lines to the right
        // `OutcomeKind`. The bespoke strings
        // (e.g. `set profile edit` /
        // `set profile export` / `set proxy
        // edit` / `set proxy import`) don't fit
        // the standard `X <past-tense>` template,
        // so they live in `Custom` and are
        // returned verbatim per kind. Locking
        // the 3 arm outputs surfaces a future
        // mix-up (e.g. swapping `applied` and
        // `no_change` in the match) here, not
        // in a dispatch regression.
        let summaries = Summaries::custom(
            "profile edited",
            "profile would be edited (dry-run)",
            "profile already edited",
        );
        assert_eq!(summaries.summary_for(OutcomeKind::Applied), "profile edited");
        assert_eq!(summaries.summary_for(OutcomeKind::DryRun), "profile would be edited (dry-run)");
        assert_eq!(summaries.summary_for(OutcomeKind::NoChange), "profile already edited");
    }
}

#[cfg(test)]
mod outcome_kind_tests {
    //! Round 25: the `OutcomeKind` enum is the dispatch's
    //! source of truth for "what kind of write just
    //! happened". A typo or accidental addition to the
    //! enum would silently break the per-resource
    //! `classify` closures (a closure that doesn't
    //! match a future kind would compile-error today,
    //! but a typo in the kind's `Debug` / equality
    //! behaviour would still slip through). These
    //! tests lock the discriminator table.
    use super::OutcomeKind;

    #[test]
    fn outcome_kind_is_no_change_table_is_locked() {
        assert!(OutcomeKind::NoChange.is_no_change());
        assert!(!OutcomeKind::Applied.is_no_change());
        assert!(!OutcomeKind::DryRun.is_no_change());
    }

    #[test]
    fn outcome_kind_distinctness_is_locked() {
        // The three kinds must compare as distinct so
        // the dispatch's `match kind` arm selection
        // never silently falls through to the wrong
        // arm. The compiler enforces `Eq` + `Copy`
        // already, but locking the comparison
        // behaviour at the test boundary surfaces
        // future "aliasing" mistakes (e.g. a
        // `#[derive(Eq)]` that two arms accidentally
        // compare equal to).
        assert_ne!(OutcomeKind::Applied, OutcomeKind::DryRun);
        assert_ne!(OutcomeKind::Applied, OutcomeKind::NoChange);
        assert_ne!(OutcomeKind::DryRun, OutcomeKind::NoChange);
    }
}

/// Runs a resource writer through the shared success /
/// failure envelope. The single point every `set
/// RESOURCE VERB` leaf reaches.
///
/// # Arguments
///
/// - `output` — the JSON / human output sink.
/// - `summaries` — pre-computed human summaries for the
///   applied / dry-run / no-change paths.
/// - `envelope` — the `name` / `leaf` fields the JSON
///   envelope carries (the `dry_run` field is filled from
///   the outcome kind).
/// - `write` — the per-resource writer call. Returns the
///   outcome (which decides the summary + the
///   `dry_run: bool` envelope field).
/// - `classify` — projects the writer's outcome type
///   into an [`OutcomeKind`] so the dispatch can pick
///   the right summary. The per-resource module passes a
///   closure that knows its concrete `Outcome` type
///   (e.g. `|o| match o { RpWriteOutcome::DryRun =>
///   DryRun, RpWriteOutcome::NoChange => NoChange,
///   _ => Applied }`). Writers that never emit `NoChange`
///   pass a 2-arm match.
/// - `code_for` — a closure that maps the resource's
///   domain error type to a stable `code: &str`.
/// - `extra_payload` — a closure that projects any
///   outcome-specific fields into the success envelope
///   (e.g. the on-disk `id` for `add proxy`, the
///   imported `count` for `import proxy`). Returns
///   `serde_json::Value::Object(...)` whose entries are
///   merged into the envelope; pass `|_| json!({})` when
///   the writer has no extra data.
///
/// Round 23: this is the seventh `run_writer` argument
/// (the original six), added so the `set proxy` dispatch
/// can route the `add` and `import` leaves through the
/// shared envelope — `add_proxy` returns the on-disk
/// id (a hash of the URI) and `import_proxy` returns
/// the number of new entries, both of which the JSON
/// envelope needs. Every existing call site was
/// updated to pass `|_| json!({})` (no extra fields).
///
/// Round 25: the `is_dry_run: Fn(&O) -> bool` sixth
/// argument was upgraded to `classify: Fn(&O) ->
/// OutcomeKind` so the dispatch can distinguish a real
/// `Applied` from an idempotent `NoChange` (the
/// subscription writer's `set_source_enabled` short-
/// circuit used to fabricate `Applied` with no disk
/// I/O, which the operator saw as a successful write).
pub fn run_writer<O, E, F, K, C, X>(
    output: CliOutput,
    summaries: Summaries,
    envelope: &WriteEnvelope<'_>,
    write: F,
    classify: K,
    code_for: C,
    extra_payload: X,
) -> ExitCode
where
    F: FnOnce() -> Result<O, E>,
    K: Fn(&O) -> OutcomeKind,
    C: Fn(&E) -> &'static str,
    X: Fn(&O) -> serde_json::Value,
    E: core::fmt::Display,
{
    match write() {
        Ok(outcome) => {
            let kind = classify(&outcome);
            // The `dry_run` envelope flag is only
            // `true` when the user opted in to a
            // preview (the dispatch's `apply` flag was
            // `false`). An idempotent `NoChange` is
            // NOT a dry-run: the user did not ask for
            // a preview, the writer observed the
            // on-disk state was already the target.
            let dry_run = matches!(kind, OutcomeKind::DryRun);
            // Round 30: the previous 3-arm match
            // selected the eager pre-built `String`
            // field. `summary_for` builds only the
            // needed line, which lets the
            // `Summaries::standard` /
            // `Summaries::custom` constructors stay
            // allocation-free (they store `(noun,
            // verb)` or 3 `&'static str` instead of
            // 3 owned `String`s).
            let summary = summaries.summary_for(kind);
            let mut payload = serde_json::json!({
                "name": envelope.name,
                "leaf": envelope.leaf,
                "dry_run": dry_run,
            });
            // Round 25: surface the no-change flag in
            // the JSON envelope so a downstream tool
            // can branch on it without parsing the
            // human message. `no_change: true` is
            // mutually exclusive with the implicit
            // `applied` (which is `true` when the
            // writer changed the on-disk state).
            if kind == OutcomeKind::NoChange {
                payload["no_change"] = serde_json::Value::Bool(true);
            }
            // Merge the writer's extra fields into the
            // base envelope. `Object` is the only shape
            // that can extend the base map; `Array` /
            // `Number` / `String` / `Bool` / `Null` from
            // the writer would silently drop. A writer
            // that needs an array field (e.g. `ids: [...]`)
            // wraps the array in a single-key object.
            if let (serde_json::Value::Object(map), serde_json::Value::Object(extra)) =
                (&mut payload, extra_payload(&outcome))
            {
                map.extend(extra);
            }
            output.success(&summary, payload);
            ExitCode::SUCCESS
        }
        Err(error) => {
            let code = code_for(&error);
            let cli = crate::output::CliError::new(code, format!("{error}"), envelope.leaf);
            output::report_error_returning(output, cli)
        }
    }
}

/// Round 29: the standard-CRU envelope for resources
/// whose writer returns
/// [`crate::client::resource_writer::ResourceWriteOutcome`]
/// and whose summary fits the `X <past-tense>` /
/// `X would be <past-tense> (dry-run)` / `X already
/// <past-tense>` template (every resource except
/// `profile`, which extends the verb set with `Edit`
/// and `Export`).
///
/// The 4 standard resources (`set sub` /
/// `set rule-provider` / `set proxy-group` / `set
/// proxy add|remove`) all followed the same
/// 9-line shape before this round:
///
/// ```ignore
/// let leaf = format!("set {prefix} {verb} {name}");
/// common::run_writer(
///     output,
///     Summaries::standard(NOUN, verb),
///     &WriteEnvelope { name, leaf: &leaf },
///     || cmd::writer(paths, name, apply),
///     classify_resource_outcome,
///     code_for,
///     no_extra_payload,
/// )
/// ```
///
/// Round 29 collapses the 4 repeated 9-line blocks
/// per resource (4 resources × 4 verbs × 9 lines ≈
/// 144 lines of structurally identical dispatch
/// boilerplate) into a single function call per
/// verb. The call site becomes a one-liner that
/// reads as the *intent* — "run a `set {prefix}
/// {verb}` against this writer with this name" —
/// rather than the *mechanics* — "build a leaf
/// string, call the envelope with these 7
/// arguments, all of which are the same per
/// resource".
///
/// # Arguments
///
/// - `output` — the JSON / human output sink.
/// - `cli_prefix` — the second token in the leaf
///   string (`"sub"` / `"rule-provider"` /
///   `"proxy-group"` / `"proxy"`). The leaf is
///   built as `format!("set {cli_prefix} {verb.cli_name()} {name}")`.
/// - `noun` — the singular resource name used by
///   [`Summaries::standard`] (e.g. `"subscription
///   source"` / `"rule provider"` / `"proxy
///   group"`). Distinct from `cli_prefix` because
///   the human summary wants the long form
///   (`"subscription source added"`) while the leaf
///   wants the CLI form (`"set sub add https://…"`).
/// - `verb` — the standard [`ResourceVerb`] variant
///   (drives both the leaf token and the
///   `Summaries::standard` past-tense).
/// - `name` — the operator-supplied id / url.
/// - `write` — the per-resource writer call.
/// - `code_for` — maps the resource's domain error
///   to a stable `code: &str`.
///
/// Round 29 also folds the
/// `Summaries::standard(NOUN, verb)` +
/// `WriteEnvelope { name, leaf: &leaf }` +
/// `classify_resource_outcome` +
/// `no_extra_payload` quartet into the helper. The
/// `classify` and `extra_payload` slots are
/// *not* caller parameters because the 4 standard
/// resources all use the same canonical projection
/// (the writer's `ResourceWriteOutcome` enum) and
/// the same no-op extra payload (every standard
/// writer carries the per-call id / url in
/// `envelope.name`, not in a separate
/// `extra_payload` field). Bespoke writers like
/// `InlineProxyOutcome` / `ImportOutcome` keep
/// using [`run_writer`] directly because their
/// payloads project into the envelope.
pub fn run_standard_writer<E, F, C>(
    output: CliOutput,
    cli_prefix: &'static str,
    noun: &'static str,
    verb: ResourceVerb,
    name: &str,
    write: F,
    code_for: C,
) -> ExitCode
where
    F: FnOnce() -> Result<crate::client::resource_writer::ResourceWriteOutcome, E>,
    C: Fn(&E) -> &'static str,
    E: core::fmt::Display,
{
    let leaf = format!("set {cli_prefix} {} {name}", verb.cli_name());
    let envelope = WriteEnvelope { name, leaf: &leaf };
    run_writer(
        output,
        Summaries::standard(noun, verb),
        &envelope,
        write,
        classify_resource_outcome,
        code_for,
        no_extra_payload,
    )
}
