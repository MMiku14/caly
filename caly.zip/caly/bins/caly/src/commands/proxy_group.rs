//! Round 20: `set proxy-group` CLI leaf dispatcher.
//!
//! Each `SetProxyGroupCmd` variant is one leaf in the
//! `set proxy-group` family. The 5 CRUD leaves
//! (`add` / `remove` / `enable` / `disable` / `list`)
//! round-trip `proxy_groups: Vec<ProxyGroupConfig>` in
//! `config.yaml` through `client::proxy_group`. The
//! shared `commands::set::common::run_standard_writer`
//! envelope (Round 29) does the success / dry-run /
//! error projection so the dispatch stays a
//! one-page file with **one-line** CRUD bodies.
//!
//! The `add` leaf is **one** variant (not one per
//! `type:` kind) because every `proxy_groups:` entry
//! has the same shape; the `type:` field is a
//! discriminator the writer forwards verbatim to the
//! schema layer. Probe-driven groups (`url-test` /
//! `fallback` / `load-balance`) require `--url`; the
//! schema validator surfaces a missing probe as a
//! `MissingUrl` error so the operator sees a
//! precise reason.

use std::process::ExitCode;

use crate::cli::{ProxyGroupMemberSpec, SetProxyGroupCmd};
use crate::client::proxy_group as cmd;
use crate::commands::set::common::{ResourceVerb, run_standard_writer};
use crate::output::{self, CliOutput};

/// The singular resource name used by
/// [`run_standard_writer`] for every `set
/// proxy-group` CRUD leaf. Kept as a `const` so the
/// `Summaries::standard(NOUN, verb)` call inside
/// the helper doesn't pay a string-allocation cost
/// on every dispatch.
const NOUN: &str = "proxy group";

/// The leaf-prefix token (the second token in the
/// `set proxy-group <verb> <id>` leaf string). Kept
/// distinct from [`NOUN`] because the leaf wants
/// the CLI form (`"set proxy-group add Proxy"`)
/// while the human summary wants the long form
/// (`"proxy group added"`).
const CLI_PREFIX: &str = "proxy-group";

/// Projects a `cmd::PgWriteError` to the stable CLI
/// `code:` used in the JSON error envelope. The
/// `Shared` arm covers the `ResourceError::Write` /
/// `Parse` / `Validate` variants the writer passes
/// through.
fn code_for(error: &cmd::PgWriteError) -> &'static str {
    use cmd::PgWriteError as E;
    match error {
        E::InvalidName(_) => "proxy_group.invalid_name",
        E::AlreadyDeclared(_) => "proxy_group.already_declared",
        E::NotDeclared(_) => "proxy_group.not_declared",
        E::MissingUrl(_) => "proxy_group.missing_url",
        E::UnexpectedUrl(_) => "proxy_group.unexpected_url",
        E::Shared(shared) => match shared {
            crate::client::resource_writer::ResourceError::Invalid(_) => "proxy_group.invalid",
            crate::client::resource_writer::ResourceError::Write(_) => "proxy_group.write_failed",
            crate::client::resource_writer::ResourceError::Parse(_) => "proxy_group.parse_failed",
            crate::client::resource_writer::ResourceError::Validate(_) => {
                "proxy_group.validate_failed"
            }
            // The `From<ResourceError> for PgWriteError`
            // impl already lifted these to the
            // per-resource variants; the residual
            // arms are defensive.
            crate::client::resource_writer::ResourceError::AlreadyDeclared(_)
            | crate::client::resource_writer::ResourceError::NotDeclared(_) => {
                "proxy_group.invalid"
            }
        },
    }
}

/// Dispatches a `set proxy-group` leaf to the matching
/// implementation. Every CRUD leaf is a real writer; `list`
/// reads the layered `proxy_groups:` list.
pub fn dispatch(
    cmd_arg: SetProxyGroupCmd,
    options: crate::cli::CliOptions,
    output: CliOutput,
) -> ExitCode {
    let paths = caly_platform::paths::AppPaths::from_env();
    dispatch_with_paths(cmd_arg, &paths, options, output)
}

/// Round 25: the path-injected dispatch. The
/// `dispatch` shim resolves the operator's `AppPaths`
/// from process env (the production path); the
/// `dispatch_with_paths` form takes the paths
/// explicitly so a test can drive the dispatch with
/// a hermetic `AppPaths::from_env_vars` fixture
/// without mutating the operator's XDG state. The
/// two arms are 1-for-1 — the path resolution is
/// the only thing that differs.
///
/// Round 30: the 4 CRUD bodies (`add` / `remove` /
/// `enable` / `disable`) inlined into the match
/// arms. Pre-Round 30 each was a 5-arg private
/// helper (`add(paths, name, group_type, members,
/// url, interval_seconds, tolerance_ms, apply,
/// output)` etc.) that did nothing but build a
/// `run_standard_writer` call. The 4 helpers were
/// 60 lines of pure indirection — the dispatch's
/// `match` had 5 lines of `match X => helper_x(…)`
/// with no logic in between. The Round 30 shape
/// inlines each helper into its `match` arm so
/// the dispatch is one expression per verb: the
/// 4 helper functions and the 5 `match arm =>
/// helper_x(…)` call sites collapse into the
/// 4-arm `match` below.
pub fn dispatch_with_paths(
    cmd_arg: SetProxyGroupCmd,
    paths: &caly_platform::paths::AppPaths,
    _options: crate::cli::CliOptions,
    output: CliOutput,
) -> ExitCode {
    match cmd_arg {
        SetProxyGroupCmd::Add {
            name,
            group_type,
            members,
            url,
            interval_seconds,
            tolerance_ms,
            apply,
            dry_run,
        } => {
            // Round 30: the previous 5-arm
            // `to_writer_type` helper collapsed into
            // the canonical `From<cli::ProxyGroupTypeSpec>
            // for cmd::PgTypeSpec` impl. The `.into()`
            // call site reads as "the writer expects
            // its own `PgTypeSpec`" instead of the
            // mechanical 5-arm match.
            let writer_type: cmd::PgTypeSpec = group_type.into();
            // The CLI grammar carries a possible member
            // re-parse failure as data (#55); surface it
            // as a command error instead of writing an
            // empty-member group.
            let members = match members {
                Ok(members) => members,
                Err(error) => {
                    return output::report_error_returning(
                        output,
                        crate::error::CliError::new(
                            "proxy_group.member_parse_failed",
                            error,
                            "set proxy-group add",
                        ),
                    );
                }
            };
            let writer_members: Vec<cmd::PgMemberSpec> =
                members.iter().map(to_writer_member).collect();
            let effective_apply = apply && !dry_run;
            run_standard_writer(
                output,
                CLI_PREFIX,
                NOUN,
                ResourceVerb::Add,
                &name,
                || {
                    cmd::add_group(
                        paths,
                        &name,
                        writer_type,
                        &writer_members,
                        url.as_deref(),
                        interval_seconds,
                        tolerance_ms,
                        effective_apply,
                    )
                },
                code_for,
            )
        }
        SetProxyGroupCmd::Remove {
            name,
            apply,
            dry_run,
        } => crud_dispatch(
            output,
            paths,
            &name,
            apply,
            dry_run,
            ResourceVerb::Remove,
            cmd::remove_group,
        ),
        SetProxyGroupCmd::Enable {
            name,
            apply,
            dry_run,
        } => crud_dispatch(
            output,
            paths,
            &name,
            apply,
            dry_run,
            ResourceVerb::Enable,
            |paths, name, apply| cmd::set_enabled(paths, name, true, apply),
        ),
        SetProxyGroupCmd::Disable {
            name,
            apply,
            dry_run,
        } => crud_dispatch(
            output,
            paths,
            &name,
            apply,
            dry_run,
            ResourceVerb::Disable,
            |paths, name, apply| cmd::set_enabled(paths, name, false, apply),
        ),
        SetProxyGroupCmd::List { enabled_only } => list(paths, enabled_only, output),
    }
}

/// Round 33: the inner dispatch helper for the 3
/// simple-CRUD leaves (`remove` / `enable` / `disable`).
/// Pre-Round 33 each of the 3 arms in [`dispatch_with_paths`]
/// was a 9-line `run_standard_writer(...)` call that
/// differed only in the `ResourceVerb` variant and the
/// `cmd::*` writer function. The 3 arms are now collapsed
/// into a single helper: the verb + the writer closure
/// are the only per-call data, the leaf string / envelope
/// / summary / classify / payload are all folded into
/// `run_standard_writer`. Mirrors the
/// `commands::set::sub::crud_dispatch` helper (Round 30)
/// and `commands::rule_provider::crud_dispatch` (Round 30)
/// — all three resources now share the same inner dispatch
/// shape, just with their own writer closure type.
///
/// `W` is the writer closure type; the
/// `Fn(&AppPaths, &str, bool) -> Result<PgWriteOutcome, PgWriteError>`
/// signature matches the 3 `cmd::*` functions exactly.
fn crud_dispatch<W>(
    output: CliOutput,
    paths: &caly_platform::paths::AppPaths,
    name: &str,
    apply: bool,
    dry_run: bool,
    verb: ResourceVerb,
    writer: W,
) -> ExitCode
where
    W: FnOnce(
        &caly_platform::paths::AppPaths,
        &str,
        bool,
    ) -> Result<cmd::PgWriteOutcome, cmd::PgWriteError>,
{
    // `--apply` and `--dry-run` are mutually
    // exclusive (clap enforces it). `apply: true`
    // writes, `dry_run: true` runs every check +
    // reports planned, both `false` (default) is the
    // safe dry-run path.
    let effective_apply = apply && !dry_run;
    run_standard_writer(
        output,
        CLI_PREFIX,
        NOUN,
        verb,
        name,
        || writer(paths, name, effective_apply),
        code_for,
    )
}

/// Maps the CLI [`ProxyGroupMemberSpec`] to the writer's
/// internal [`cmd::PgMemberSpec`]. The conversion is
/// mechanical; the writer does not import the CLI grammar
/// (separation of concerns). Round 30: the
/// `ProxyGroupTypeSpec` → `cmd::PgTypeSpec` conversion
/// folded into `From<cli::ProxyGroupTypeSpec> for
/// cmd::PgTypeSpec` (the equivalent `to_writer_type`
/// helper was a verbatim 5-arm remap that the
/// canonical `From` impl subsumes); the `Member`
/// conversion stays hand-rolled because the
/// `tag.clone()` / `name.clone()` calls make a
/// `From<&ProxyGroupMemberSpec>` impl borrow-shaped
/// and a `From<ProxyGroupMemberSpec>` impl would
/// consume the CLI enum (the dispatch's `members:
/// Vec<ProxyGroupMemberSpec>` is iterated by
/// reference).
fn to_writer_member(member: &ProxyGroupMemberSpec) -> cmd::PgMemberSpec {
    match member {
        ProxyGroupMemberSpec::Node { tag } => cmd::PgMemberSpec::Node { tag: tag.clone() },
        ProxyGroupMemberSpec::Group { name } => cmd::PgMemberSpec::Group { name: name.clone() },
        ProxyGroupMemberSpec::Direct => cmd::PgMemberSpec::Direct,
        ProxyGroupMemberSpec::Reject => cmd::PgMemberSpec::Reject,
    }
}

fn list(paths: &caly_platform::paths::AppPaths, enabled_only: bool, output: CliOutput) -> ExitCode {
    let groups = cmd::read_declared(paths);
    // Round 31: `--enabled-only` filter. The
    // pre-Round 31 shape listed every declared
    // group, including the disabled ones the
    // operator had explicitly turned off. For an
    // operator with 30+ groups (a real-world
    // Loyalsoldier-style config), the disabled
    // entries drowned out the active ones in
    // the human form (`proxy-group: <name> ...
    // enabled: false` repeated 20 times). The
    // filter lives in the dispatcher (not the
    // writer) because the writer's `read_declared`
    // contract is "the full layered list"; the
    // dispatcher's `enabled_only: bool` is the
    // one consumer-facing knob that decides what
    // shape of the list to show. The JSON form
    // carries the filter in the `enabled_only`
    // field so a script consumer can branch on
    // "the caller asked for enabled-only" (e.g.
    // a CI check that asserts "every enabled
    // group has a non-empty members list").
    let filtered: Vec<_> = if enabled_only {
        groups
            .iter()
            .filter(|(_, enabled, _, _, _)| *enabled)
            .cloned()
            .collect()
    } else {
        groups
    };
    if output.is_json() {
        let items: Vec<serde_json::Value> = filtered
            .iter()
            .map(|(name, enabled, group_type, member_count, has_url_test)| {
                serde_json::json!({
                    "name": name,
                    "enabled": enabled,
                    "type": group_type,
                    "member_count": member_count,
                    "has_url_test": has_url_test,
                })
            })
            .collect();
        output.success(
            &format!("listed {} proxy group(s)", items.len()),
            serde_json::json!({
                "groups": items,
                "count": items.len(),
                "enabled_only": enabled_only,
            }),
        );
    } else {
        for (name, enabled, group_type, member_count, has_url_test) in &filtered {
            let url_test_marker = if *has_url_test { " (url-test)" } else { "" };
            println!(
                "proxy-group: {name} ({group_type}, {member_count} member(s), enabled: {enabled}){url_test_marker}"
            );
        }
        let suffix = if enabled_only { " (enabled-only)" } else { "" };
        println!("{} group(s){suffix}", filtered.len());
    }
    ExitCode::SUCCESS
}

#[cfg(test)]
mod dispatch_tests;
