//! `caly daemon` — the long-running control plane (unchanged from Round 10).
//! Foreground by design: the daemon never fork-detaches, so it must run
//! under supervision (a systemd unit or container init) that restarts it and
//! owns its stdio. A bare `nohup` loses both restart and log routing.

use std::process::ExitCode;

pub fn run(options: caly_client::cli::cli::CliOptions) -> ExitCode {
    let paths = caly_platform::paths::AppPaths::from_env();
    // `--socket` / `CALY_SOCKET` must steer the daemon's bind path exactly
    // like they steer every client command — previously the daemon always
    // bound the default path while `show status --socket x` aimed elsewhere,
    // and the two sides never met.
    let socket_path = options.socket.clone().unwrap_or_else(|| {
        std::env::var_os("CALY_SOCKET")
            .map_or_else(|| paths.socket_path(), std::path::PathBuf::from)
    });
    let daemon_id =
        caly_domain::DaemonInstanceId::from_bytes(caly_platform::entropy::random_bytes::<16>());
    // Lifetime span: every sync-context line below (startup, serve, shutdown)
    // inherits `daemon_id`; spawned async tasks log their own context.
    let _daemon_span = tracing::info_span!("daemon", daemon_id = %daemon_id).entered();
    let lock = match crate::daemon::acquire_lock(paths.lock_path()) {
        Ok(value) => value,
        Err(message) => {
            tracing::error!(daemon_id = %daemon_id, "daemon lock failed: {message}");
            return ExitCode::FAILURE;
        }
    };
    let mut settings = match resolve_daemon_config() {
        Ok(value) => value,
        Err(error) => {
            tracing::error!(daemon_id = %daemon_id, "daemon configuration invalid: {error}");
            release_startup_lock(lock, daemon_id);
            return ExitCode::FAILURE;
        }
    };
    if let Err(code) = apply_daemon_overrides(&mut settings, options, daemon_id) {
        release_startup_lock(lock, daemon_id);
        return code;
    }
    let mut assembly = match crate::bootstrap::DaemonAssembly::new(
        daemon_id,
        settings.core_override,
        settings.tun,
        settings.controllers,
        settings.binaries,
        settings.subscription_urls.clone(),
        settings.tuning,
    ) {
        Ok(value) => value,
        Err(error) => {
            tracing::error!(daemon_id = %daemon_id, "daemon composition failed: {error}");
            release_startup_lock(lock, daemon_id);
            return ExitCode::FAILURE;
        }
    };
    if !crate::daemon::bootstrap_ready(&mut assembly) {
        release_startup_lock(lock, daemon_id);
        return ExitCode::FAILURE;
    }
    let daemon = match crate::daemon::start_daemon_runtime(
        assembly.application,
        daemon_id,
        socket_path,
        settings.listen,
        settings.auth_token,
        settings.tls_material,
        settings.subscription_refresh,
        settings.auto_start_core,
    ) {
        Ok(value) => value,
        Err(error) => {
            tracing::error!(daemon_id = %daemon_id, "{error}");
            release_startup_lock(lock, daemon_id);
            return ExitCode::FAILURE;
        }
    };
    let socket = daemon.socket.clone();
    // Transport summary: one line names every listener posture so the
    // operator never has to guess whether auth/TLS/refresh are on.
    // `listen` is pre-rendered so JSON carries `127.0.0.1:17890` / `none`
    // instead of the `Option` Debug form (`Some(..)`).
    let listen = daemon
        .listen
        .map_or_else(|| "none".to_owned(), |address| address.to_string());
    tracing::info!(
        socket = %socket.display(),
        listen,
        auth = if daemon.auth_token.is_some() { "token" } else { "none" },
        tls = daemon.tls_material.is_some(),
        periodic_refresh = daemon.subscription_refresh.is_some(),
        "caly daemon started"
    );
    let result = daemon.serve();
    let first_fault = daemon.running.first_fault();
    let shutdown_error = daemon.shutdown();
    crate::daemon::finish_daemon(result.and(shutdown_error), lock, &socket, first_fault)
}

/// Releases the instance lock on a startup-abort path, warning instead
/// of `let _`-swallowing: a stuck lock blocks the next daemon start.
fn release_startup_lock(
    lock: Box<dyn caly_platform::instance_lock::InstanceLock>,
    daemon_id: caly_domain::DaemonInstanceId,
) {
    if let Err(error) = lock.release() {
        tracing::warn!(daemon_id = %daemon_id, "daemon lock release failed during startup abort: {error}");
    }
}

fn resolve_daemon_config()
-> Result<crate::daemon_config::DaemonSettings, caly_client::ops::config::DaemonConfigError> {
    crate::daemon_config::resolve_daemon(caly_platform::paths::AppPaths::from_env().config)
}

fn apply_daemon_overrides(
    settings: &mut crate::daemon_config::DaemonSettings,
    options: caly_client::cli::cli::CliOptions,
    daemon_id: caly_domain::DaemonInstanceId,
) -> Result<(), ExitCode> {
    if let Some(core) = options.core.as_deref() {
        settings.core_override = match core {
            "mihomo" => Some(caly_domain::CoreKind::Mihomo),
            "sing-box" => Some(caly_domain::CoreKind::SingBox),
            _ => {
                tracing::error!(daemon_id = %daemon_id, "invalid daemon core override");
                return Err(ExitCode::from(2));
            }
        };
    }
    if options.mihomo_bin.is_some() {
        settings.binaries.mihomo = options.mihomo_bin;
    }
    if options.sing_box_bin.is_some() {
        settings.binaries.sing_box = options.sing_box_bin;
    }
    Ok(())
}
