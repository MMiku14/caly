//! Composition-root startup ordering.

use caly_application::composition::{ApplicationComposition, CompositionError, RuntimeCapacities};
use caly_domain::DaemonInstanceId;

/// Required daemon assembly order.
#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub enum BootstrapPhase {
    AcquireInstanceLock,
    RestorePendingEffects,
    BuildOwnedRuntime,
    BindTransport,
    Ready,
}

impl BootstrapPhase {
    pub const fn next(self) -> Option<Self> {
        match self {
            Self::AcquireInstanceLock => Some(Self::RestorePendingEffects),
            Self::RestorePendingEffects => Some(Self::BuildOwnedRuntime),
            Self::BuildOwnedRuntime => Some(Self::BindTransport),
            Self::BindTransport => Some(Self::Ready),
            Self::Ready => None,
        }
    }
}

/// Runtime/application owners assembled before transport binding.
pub struct DaemonAssembly {
    pub bootstrap: BootstrapDriver,
    pub resources: DaemonResources,
    pub application: ApplicationComposition,
}

impl DaemonAssembly {
    pub fn new(
        daemon_instance: DaemonInstanceId,
        core_override: Option<caly_domain::CoreKind>,
        tun: Option<caly_domain::TunConfig>,
        controllers: caly_domain::Controllers,
        binaries: caly_application::composition::CoreBinaryPaths,
        subscription_url: Option<String>,
        tuning: caly_application::composition::RuntimeTuning,
    ) -> Result<Self, CompositionError> {
        let telemetry_interval_ms = crate::daemon_config::telemetry_interval_ms();
        Ok(Self {
            bootstrap: BootstrapDriver::new(),
            resources: DaemonResources::default(),
            application: ApplicationComposition::new_with_binaries(
                daemon_instance,
                RuntimeCapacities::default(),
                core_override,
                tun,
                controllers,
                binaries,
                subscription_url,
                telemetry_interval_ms,
                tuning,
            )?,
        })
    }
}

#[allow(clippy::struct_excessive_bools)]
#[derive(Clone, Copy, Debug, Default, Eq, PartialEq)]
pub struct DaemonResources {
    pub lock_acquired: bool,
    pub effects_restored: bool,
    pub runtime_built: bool,
    pub transport_bound: bool,
}

impl DaemonResources {
    pub const fn ready() -> Self {
        Self {
            lock_acquired: true,
            effects_restored: true,
            runtime_built: true,
            transport_bound: true,
        }
    }

    #[must_use]
    pub const fn clear_transport(mut self) -> Self {
        self.transport_bound = false;
        self
    }

    #[must_use]
    pub const fn clear_runtime(mut self) -> Self {
        self.runtime_built = false;
        self
    }

    #[must_use]
    pub const fn clear_effects(mut self) -> Self {
        self.effects_restored = false;
        self
    }

    #[must_use]
    pub const fn clear_lock(mut self) -> Self {
        self.lock_acquired = false;
        self
    }
}

/// Driver preventing transport/core startup before restore-first succeeds.
pub struct BootstrapDriver {
    phase: BootstrapPhase,
}

impl BootstrapDriver {
    pub const fn new() -> Self {
        Self {
            phase: BootstrapPhase::AcquireInstanceLock,
        }
    }
    pub const fn phase(&self) -> BootstrapPhase {
        self.phase
    }

    pub fn complete(
        &mut self,
        completed: BootstrapPhase,
    ) -> Result<BootstrapPhase, BootstrapError> {
        if completed != self.phase {
            return Err(BootstrapError::OutOfOrder);
        }
        let next = self.phase.next().ok_or(BootstrapError::AlreadyReady)?;
        self.phase = next;
        Ok(next)
    }
}

impl Default for BootstrapDriver {
    fn default() -> Self {
        Self::new()
    }
}

#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub enum BootstrapError {
    OutOfOrder,
    AlreadyReady,
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn resources_release_in_reverse_startup_order() {
        let resources = DaemonResources::ready()
            .clear_transport()
            .clear_runtime()
            .clear_effects()
            .clear_lock();
        assert_eq!(resources, DaemonResources::default());
    }

    #[test]
    fn runtime_cannot_precede_restore() {
        let mut driver = BootstrapDriver::new();
        assert_eq!(
            driver.complete(BootstrapPhase::BuildOwnedRuntime),
            Err(BootstrapError::OutOfOrder),
        );
        assert_eq!(driver.phase(), BootstrapPhase::AcquireInstanceLock);
    }
}
