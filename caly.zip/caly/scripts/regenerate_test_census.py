#!/usr/bin/env python3
"""Regenerate the `docs/IMPLEMENTATION_STATUS.md §3.3` test census from the tree.

The table's numbers are asserted on every `cargo test` by
`crates/caly-arch-test/tests/doc_consistency.rs::status_table_test_counts_match_the_tree`, so this
script is the authoring half of the same rule: it counts exactly what the gate counts (line-leading
`#[test]`, matching `caly_arch_test::docs::count_test_attributes`) and rewrites the table and its
"按文件实测" sentence in place.

Why it lives in the repo: the table has to be refreshed whenever a test is added, and a generator that
only exists in `/tmp` turns a mechanical step into hand-edited numbers — which is how the census drifted
in earlier rounds (`docs/ONBOARDING_NOTES.md §4.36`, and `§4.49` for a bug found in the first version of
this very table).

Usage:
    python3 scripts/regenerate_test_census.py            # rewrite the section
    python3 scripts/regenerate_test_census.py --check    # exit 1 if it is stale
"""

from __future__ import annotations

import re
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
DOC = ROOT / "docs" / "IMPLEMENTATION_STATUS.md"
HEADER = "| 测试位置 | 数量 | 覆盖的断言 |"
SEPARATOR = "|---|---|---|"
UNIT = "（单元）"
PLACEHOLDER = "（本轮新增，见 `docs/DEVELOPMENT_LOG_2026-08-27.md` 对应小节）"
INTRO = re.compile(r"按文件实测（\*\*(\d+)\*\* 个文件、合计 \*\*(\d+)\*\*）")


def count_tests(path: Path) -> int:
    """Count line-leading `#[test]` — the rule the gate asserts.

    A substring search would also match the token inside prose, and a test *about* test counts has to
    write that token in its own comments. Counting it there is how a table starts disagreeing with the
    code it describes.
    """
    return sum(1 for line in path.read_text().split("\n") if line.strip().startswith("#[test]"))


def scan() -> dict[str, int]:
    counts: dict[str, int] = {}
    for path in sorted(ROOT.glob("crates/**/*.rs")):
        found = count_tests(path)
        if found:
            counts[path.relative_to(ROOT).as_posix()] = found
    return counts


def row_cells(line: str) -> list[str]:
    return [cell.strip() for cell in line.strip().strip("|").split("|")]


def table_bounds(lines: list[str]) -> tuple[int, int]:
    start = next(i for i, line in enumerate(lines) if line.startswith(HEADER))
    assert lines[start + 1] == SEPARATOR, "the census table lost its separator row"
    end = start + 2
    while end < len(lines) and lines[end].startswith("|"):
        end += 1
    return start, end


def existing_descriptions(lines: list[str], start: int, end: int) -> dict[str, str]:
    described: dict[str, str] = {}
    for line in lines[start + 2 : end]:
        cells = row_cells(line)
        if len(cells) < 3:
            raise SystemExit(f"malformed census row: {line!r}")
        path = cells[0].replace(UNIT, "").strip().strip("`")
        described[path] = cells[2]
    return described


def build(counts: dict[str, int], described: dict[str, str]) -> tuple[list[str], list[str]]:
    rows: list[str] = []
    new_entries: list[str] = []
    for path in sorted(counts):
        if path not in described:
            new_entries.append(path)
        shown = f"`{path}`{UNIT}" if "/src/" in path else f"`{path}`"
        rows.append(f"| {shown} | {counts[path]} | {described.get(path, PLACEHOLDER)} |")
    return rows, new_entries


def main() -> int:
    check_only = "--check" in sys.argv
    counts = scan()
    total = sum(counts.values())
    text = DOC.read_text()
    lines = text.split("\n")
    start, end = table_bounds(lines)
    described = existing_descriptions(lines, start, end)
    rows, new_entries = build(counts, described)
    dropped = sorted(set(described) - set(counts))

    lines[start + 2 : end] = rows
    text = "\n".join(lines)
    text = INTRO.sub(f"按文件实测（**{len(counts)}** 个文件、合计 **{total}**）", text, count=1)

    if check_only:
        if text != DOC.read_text():
            print("census is stale; run: python3 scripts/regenerate_test_census.py")
            for path in new_entries:
                print(f"  no row for test-bearing file: {path}")
            for path in dropped:
                print(f"  row cites a file with no tests: {path}")
            return 1
        return 0

    DOC.write_text(text)
    print(f"files={len(counts)} total={total} rows={len(rows)}", file=sys.stderr)
    if new_entries:
        print(f"describe these new rows: {new_entries}", file=sys.stderr)
    if dropped:
        print(f"removed rows (no tests left in the tree): {dropped}", file=sys.stderr)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
