#!/usr/bin/env python3
"""Round 93 falsification harness.

Target property: a hello's claimed role is parsed FAIL-CLOSED at the daemon trust boundary
(companion to round 92, which made the envelope carry the negotiated role). The lenient dialect
parser keeps its legacy "unknown role => Admin" default for old callers, but the daemon must NOT
inherit it: an unparseable role claim (e.g. `role=Root`) is refused by name at handshake, and a
hello with no role defaults to the least-privilege Viewer (never Admin).

Fix under test:
  - `caly_ipc::dialect::server_hello_role(records) -> Result<Role, String>`: Admin/Operator/Viewer
    map literally, an unknown value is `Err` (named), a missing role is `Ok(Viewer)`.
  - calyd hello branch: call `server_hello_role`, refuse (`HANDSHAKE`) on error, and override the
    lenient `hello.role` with the negotiated role.

Judges:
  - dialect unit tests `server_hello_role_maps_the_wire_roles_and_defaults_missing_to_viewer`
    and `server_hello_role_refuses_an_unparseable_role_by_name`.
  - wire e2e `a_hello_claiming_an_unknown_role_is_refused_not_promoted_to_admin` (kind 5 refusal,
    code HANDSHAKE) and `a_hello_with_no_role_defaults_to_the_least_privileged_viewer` (role-less
    hello + Admin command -> PERMISSION).
  - arch gate `the_wire_daemon_parses_a_hello_role_fail_closed_at_handshake`.

Mutations (build stays green; the judge bites):
  M1 (parser fail-open): unknown/missing role -> Admin. Bites the dialect unit tests AND the
     unknown-role e2e (it gets hello_ack kind 2, not refusal kind 5).
  M2 (daemon skips the fail-closed parse): drop the `server_hello_role` call/override. Bites the
     arch gate (no call site) and both e2e (Root accepted; missing role treated as Admin).
  M3 (parser refuses missing role as an error instead of least-privilege default): make the
     `None` arm an Err. Bites the dialect unit test (missing must be Ok(Viewer)) AND the
     missing-role e2e (a role-less hello would be refused, not handshaken) — pins the "missing
     defaults safe" half that a blanket "reject every non-literal role" would get wrong.

Restoration is content + mtime, sha256-verified. cwd = workspace root.
"""

import hashlib
import os
import pathlib
import shutil
import subprocess
import sys

ROOT = pathlib.Path(__file__).resolve().parents[1]
DIALECT = ROOT / "crates/caly-ipc/src/dialect.rs"
CALYD = ROOT / "crates/caly-daemon/src/bin/calyd.rs"
SUFFIX = ".r93bak"


def sha256(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def backup(path):
    digest = sha256(path)
    shutil.move(str(path), str(path.with_name(path.name + SUFFIX)))
    return digest


def backup_text(path):
    return path.with_name(path.name + SUFFIX).read_text()


def restore(path, expected):
    shutil.move(str(path.with_name(path.name + SUFFIX)), str(path))
    os.utime(path, None)
    got = sha256(path)
    assert got == expected, f"restore mismatch {path}: {got} != {expected}"


def cargo(args, timeout=400):
    proc = subprocess.run(
        ["cargo", *args], cwd=ROOT, capture_output=True, text=True, timeout=timeout
    )
    return proc.returncode, proc.stdout + proc.stderr


def build_failed(out):
    return "error[" in out or "could not compile" in out


def dialect_unit_result():
    rc, out = cargo(["test", "-p", "caly-ipc", "--lib", "server_hello_role"])
    red = "FAILED" in out
    return build_failed(out), (not red and "test result: ok" in out), out


def e2e_role_result():
    rc, out = cargo(["build", "-p", "caly-daemon", "--bin", "calyd"])
    if build_failed(out):
        return True, False, False, out
    # One substring filter (`role`) covers every role e2e judge (rounds 92 and 93); cargo test
    # takes a single TESTNAME positional. Judge each named test's line for red/green.
    rc, out = cargo(
        ["test", "-p", "caly-daemon", "--test", "calyd_wire", "role"]
    )
    unknown_red = "a_hello_claiming_an_unknown_role_is_refused_not_promoted_to_admin ... FAILED" in out
    missing_red = "a_hello_with_no_role_defaults_to_the_least_privileged_viewer ... FAILED" in out
    return False, ("FAILED" not in out and "test result: ok" in out), (unknown_red, missing_red), out


def gate_result():
    rc, out = cargo(
        ["test", "-p", "caly-arch-test", "--test", "dependency_direction",
         "the_wire_daemon_parses_a_hello_role_fail_closed_at_handshake"]
    )
    red = "test result: FAILED" in out or "panicked" in out
    return build_failed(out), (not red and "test result: ok" in out), out


def sweep():
    for f in ROOT.glob("crates/**/*.r93bak"):
        f.unlink()


def main():
    sweep()
    bf, ok, out = dialect_unit_result()
    assert not bf and ok, "clean dialect units must pass:\n" + out[-1200:]
    bf, green, _reds, out = e2e_role_result()
    assert not bf and green, "clean wire e2e must pass:\n" + out[-1200:]
    bf, gok, out = gate_result()
    assert not bf and gok, "clean gate must pass:\n" + out[-1200:]
    print("baseline: dialect units + wire e2e + gate green")

    results = {}

    # M1: parser fails open (unknown/missing -> Admin).
    d1 = backup(DIALECT)
    try:
        t = backup_text(DIALECT)
        old = (
            "    match wire_field(records, \"role\") {\n"
            "        Some(\"Admin\") => Ok(Role::Admin),\n"
            "        Some(\"Operator\") => Ok(Role::Operator),\n"
            "        Some(\"Viewer\") => Ok(Role::Viewer),\n"
            "        Some(other) => Err(format!(\n"
            "            \"role {other:?} is not on the v0 wire; the roles are Viewer, Operator and Admin\"\n"
            "        )),\n"
            "        None => Ok(Role::Viewer),\n"
            "    }"
        )
        new = (
            "    match wire_field(records, \"role\") {\n"
            "        Some(\"Operator\") => Ok(Role::Operator),\n"
            "        Some(\"Viewer\") => Ok(Role::Viewer),\n"
            "        _ => Ok(Role::Admin), // MUTANT: fail-open\n"
            "    }"
        )
        assert t.count(old) == 1, f"M1 anchor {t.count(old)}"
        DIALECT.write_text(t.replace(old, new, 1))
        bf, unit_ok, unit_out = dialect_unit_result()
        unit_bit = (not bf) and (not unit_ok)
        bf, green, reds, e2e_out = e2e_role_result()
        # Unknown role must be refused; fail-open grants it -> that judge reds.
        e2e_bit = (not bf) and (not green) and reds[0]
        bit = unit_bit and e2e_bit
        results["M1 parser-fail-open"] = bit
        print(f"M1: unit_green={unit_ok} (bit={unit_bit}) e2e_green={green} unknown_red={reds[0]} "
              f"(bit={e2e_bit}) -> {bit}")
    finally:
        restore(DIALECT, d1)

    # M2: daemon skips the fail-closed parse (no override/refusal). Build stays green because the
    # call is replaced by the lenient default role binding.
    d2 = backup(CALYD)
    try:
        t = backup_text(CALYD)
        old = (
            "                let negotiated_role = match caly_ipc::dialect::server_hello_role(&records) {\n"
            "                    Ok(role) => role,\n"
            "                    Err(problem) => {\n"
            "                        refusal(stream, false, 0, \"HANDSHAKE\", &problem)?;\n"
            "                        return Ok(());\n"
            "                    }\n"
            "                };\n"
            "                let mut hello = server_hello_from_records(&records);\n"
            "                hello.role = negotiated_role;\n"
        )
        new = (
            "                // MUTANT: skip the fail-closed role parse; trust the lenient Admin default\n"
            "                let hello = server_hello_from_records(&records);\n"
        )
        assert t.count(old) == 1, f"M2 anchor {t.count(old)}"
        CALYD.write_text(t.replace(old, new, 1))
        bf, gok, gate_out = gate_result()
        gate_bit = (not bf) and (not gok) and "server_hello_role" in gate_out
        bf, green, reds, e2e_out = e2e_role_result()
        # Root accepted (unknown red) AND missing role treated as Admin (missing red: it runs gc).
        e2e_bit = (not bf) and (not green) and reds[0] and reds[1]
        bit = gate_bit and e2e_bit
        results["M2 daemon-skips-fail-closed-parse"] = bit
        print(f"M2: gate_green={gok} (bit={gate_bit}) e2e_unknown_red={reds[0]} "
              f"e2e_missing_red={reds[1]} (bit={e2e_bit}) -> {bit}")
    finally:
        restore(CALYD, d2)

    # M3: parser treats a MISSING role as an error (instead of least-privilege Viewer). This keeps
    # the unknown-refusal green while breaking the "missing defaults safe" half.
    d3 = backup(DIALECT)
    try:
        t = backup_text(DIALECT)
        old = "        None => Ok(Role::Viewer),\n    }"
        new = (
            "        None => Err(format!(\n"
            "            \"role is required; the roles are Viewer, Operator and Admin\"\n"
            "        )), // MUTANT: reject missing instead of least-privilege default\n"
            "    }"
        )
        assert t.count(old) == 1, f"M3 anchor {t.count(old)}"
        DIALECT.write_text(t.replace(old, new, 1))
        bf, unit_ok, unit_out = dialect_unit_result()
        unit_bit = (not bf) and (not unit_ok)
        bf, green, reds, e2e_out = e2e_role_result()
        # Missing-role hello must handshake; the mutant refuses it -> that judge reds (it does not
        # get far enough to PERMISSION; the refusal shape differs).
        e2e_bit = (not bf) and (not green) and reds[1]
        bit = unit_bit and e2e_bit
        results["M3 missing-role-rejected-not-defaulted"] = bit
        print(f"M3: unit_green={unit_ok} (bit={unit_bit}) missing_red={reds[1]} (bit={e2e_bit}) -> {bit}")
    finally:
        restore(DIALECT, d3)

    sweep()
    all_bit = all(results.values())
    print(f"\nall mutations bit: {all_bit}")
    for name, bit in results.items():
        print(f"  {'BIT' if bit else 'MISS'}  {name}")
    return 0 if all_bit else 1


if __name__ == "__main__":
    sys.exit(main())
