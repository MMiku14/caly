#!/usr/bin/env python3
"""Round 77 falsification harness.

The claim under test (the wire shape's symmetric closure): the decoder added to
`caly_ipc::wire_ops` is the exact mirror of its encoder — `decode_request(encode(op))`
round-trips to the same typed operation for every stateless op, and the follow-stream
pair round-trips in both of its shapes (`open` by job id, `resume` by stream id).

The judges are:

- `caly-ipc` lib unit tests (`wire_ops`): the round-trip contracts (encoder -> decoder),
  the 13-name list coverage, the refusal shapes that name the field.
- `calyd_wire`'s door sweep: every encode-table output still crosses the real daemon's
  door without a shape refusal — the decoder migration must not have moved the door.

- M1 (must bite)  the resume shape's `stream_id` record is typo'd in the **encoder**
      (`stream_id` -> `stream_id_x`) — the decoder reads `stream_id`, the round-trip
      judge goes red (a drift this table used to hide: the client hand-wrote it).
- M2 (must bite)  the apply arm's `profile_id` record is typo'd in the **decoder**
      (`profile_id` -> `profile`) — the round-trip judge goes red, and so does the
      daemon's door (the daemon now decodes through this module).

Usage: `python3 scripts/falsify_round77.py` (exit 0 = both bit, files restored).
"""

import hashlib
import os
import pathlib
import shutil
import subprocess
import sys
import time

ROOT = pathlib.Path("/home/user/caly_extract/caly")
ENV = dict(os.environ)
ENV["PATH"] = str(pathlib.Path.home() / ".cargo/bin") + ":" + ENV.get("PATH", "")

WIRE_OPS = ROOT / "crates/caly-ipc/src/wire_ops.rs"
BAK = ROOT / "crates/caly-ipc/src/wire_ops.rs.r77bak"

JUDGE = [
    # The round-trip contracts that only exist now that both tables are in one module.
    ("-p", "caly-ipc", "--lib", "wire_ops"),
    # The daemon's door, judged off the same encoder (the migrated decode path is under it).
    ("-p", "caly-daemon", "--test", "calyd_wire",
     "every_request_op_encoded_by_the_single_source_passes_the_daemons_door"),
]
JUDGE_TIMEOUT_SECS = 180


def digest(path):
    return hashlib.sha256(pathlib.Path(path).read_bytes()).hexdigest()


def sweep_strays():
    for path in ROOT.rglob("*.r77bak"):
        print(f"  note  sweeping stale {path}")
        path.unlink()


def run_judge():
    for judge in JUDGE:
        begin = time.time()
        proc = subprocess.Popen(
            ["cargo", "test", "-q", *judge],
            cwd=ROOT,
            env=ENV,
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            text=True,
            start_new_session=True,
        )
        try:
            out, _ = proc.communicate(timeout=JUDGE_TIMEOUT_SECS)
        except subprocess.TimeoutExpired:
            os.killpg(proc.pid, 9)
            proc.wait()
            return None, time.time() - begin, "HANG"
        ok = "0 failed" in (out or "") and "test result: ok" in (out or "")
        return ok, time.time() - begin, ""


def apply(needle, replacement):
    # Always snapshot the pristine file first (round 76 learned: a "backup already taken"
    # flag plus an earlier restore deleting the backup leaves the mutation in the tree).
    text = WIRE_OPS.read_text()
    assert text.count(needle) == 1, f"needle not unique: {needle!r}"
    shutil.copy2(WIRE_OPS, BAK)
    WIRE_OPS.write_text(text.replace(needle, replacement))


def restore():
    if BAK.exists():
        shutil.copy2(BAK, WIRE_OPS)
        BAK.unlink()


M1_OLD = '("stream_id", stream_id.to_string()),'
M1_NEW = '("stream_id_x", stream_id.to_string()),'

M2_OLD = 'required_text(records, "profiles.apply", "profile_id")?;'
M2_NEW = 'required_text(records, "profiles.apply", "profile")?;'


def main():
    sweep_strays()
    results = []

    # M1: typo the encoder's resume record name.
    apply(M1_OLD, M1_NEW)
    ok, secs, note = run_judge()
    results.append(("M1", "the resume record is typo'd in the encoder (must bite)", ok, secs, note))
    restore()

    # M2: typo the decoder's apply record name.
    apply(M2_OLD, M2_NEW)
    ok, secs, note = run_judge()
    results.append(("M2", "the apply record is typo'd in the decoder (must bite)", ok, secs, note))
    restore()

    all_bite = True
    for name, label, bit, secs, note in results:
        if note:
            print(f"  {'ok' if not bit else 'MISS'}    {name} {label} ({note} in {secs:.1f}s)")
        else:
            print(f"  {'ok' if not bit else 'MISS'}    {name} {label} (bite in {secs:.1f}s)")
        # bit == the judge stayed green under the mutation (it did NOT bite): a miss.
        if note or bit:
            all_bite = False

    pristine = digest(WIRE_OPS)
    print(f"restored digest {pristine[:16]}…")
    print("all mutations behaved as predicted: " + ("True" if all_bite else "False"))
    sys.exit(0 if all_bite else 1)


if __name__ == "__main__":
    main()
