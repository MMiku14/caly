"""Falsification harness for round 41 (outbound frame bound + latest-bundle determinism).

Same discipline as rounds 16/32–40: one mutation per run, exact-anchor replacement with
`assert count == 1`, restore by content and mtime, sha256-verified, stale `*.r41bak` swept at
startup. A mutation that cannot compile proves nothing (`§4.112`).

Four mutations: the outbound bound disarmed at the codec, the server loop bypassing it back to
the legacy encoder, the latest-bundle tie-break deleted (an unstable "newest"), and the
kind filter dropped (any newest object answering as a bundle).

Usage: `python3 scripts/falsify_round41.py` (exit 0 = every mutation bit, every file restored).
"""

import hashlib
import os
import pathlib
import shutil
import subprocess
import sys

ROOT = pathlib.Path("/home/user/caly")
ENV = dict(os.environ)
ENV["PATH"] = str(pathlib.Path.home() / ".cargo/bin") + ":" + ENV.get("PATH", "")
SRC = {
    "codec": ROOT / "crates/caly-ipc/src/codec.rs",
    "loop": ROOT / "crates/caly-daemon/src/server_loop.rs",
    "engine": ROOT / "crates/caly-engine/src/service.rs",
}

MUTATIONS = [
    (
        "M1 the outbound bound is disarmed at the codec",
        "codec",
        "    if payload.len() > cap {",
        "    if false && payload.len() > cap {",
        ["outbound_frames_are_bounded_on_the_way_out_too"],
    ),
    (
        "M2 the server loop bypasses back to the legacy encoder",
        "loop",
        """        let encoded = encode_raw_json_bounded(json, Encoding::Json, Compression::None)
            .map_err(|error| error.summary)?;""",
        "        let encoded = caly_ipc::encode_raw_json(json, Encoding::Json, Compression::None);",
        ["the_server_loop_refuses_to_build_a_frame_the_peer_must_refuse"],
    ),
    (
        "M3 the latest-bundle tie-break is deleted",
        "engine",
        "        candidates.sort_by(|left, right| right.0.cmp(&left.0).then_with(|| right.1.cmp(&left.1)));",
        "        candidates.sort_by(|left, right| right.0.cmp(&left.0));",
        ["the_newest_bundle_wins_and_a_tie_is_broken_deterministically"],
    ),
    (
        "M4 the kind filter drops: any newest object answers",
        "engine",
        "            .filter(|object| object.kind == caly_storage::ObjectKind::SupportBundle)",
        "            .filter(|_| true)",
        [
            "the_newest_bundle_wins_and_a_tie_is_broken_deterministically",
            "a_store_with_no_bundle_at_all_answers_none_even_if_it_holds_newer_objects",
        ],
    ),
]


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def run_cargo():
    proc = subprocess.run(
        [
            "cargo",
            "test",
            "-p",
            "caly-ipc",
            "-p",
            "caly-daemon",
            "-p",
            "caly-engine",
            "--no-fail-fast",
        ],
        cwd=str(ROOT),
        env=ENV,
        capture_output=True,
        text=True,
    )
    out = proc.stdout + proc.stderr
    failed = sorted(
        {
            line[5:].split(" ... ")[0].split("::")[-1].strip()
            for line in out.splitlines()
            if line.startswith("test ") and line.rstrip().endswith("... FAILED")
        }
    )
    return proc.returncode, failed, out


def main():
    for path in ROOT.rglob("*.r41bak"):
        original = pathlib.Path(str(path)[: -len(".r41bak")])
        shutil.move(str(path), str(original))
        print("swept leftover backup:", path.name)

    originals = {name: digest(path) for name, path in SRC.items()}
    results = []
    bad = False
    for label, key, old, new, expected in MUTATIONS:
        path = SRC[key]
        s = path.read_text()
        assert s.count(old) == 1, "%s: anchor x%d" % (label, s.count(old))
        backup = pathlib.Path(str(path) + ".r41bak")
        shutil.copyfile(path, backup)
        try:
            path.write_text(s.replace(old, new, 1))
            code, failed, out = run_cargo()
            red = [name for name in expected if name in failed]
            compile_error = "error[" in out or "could not compile" in out
            ok = bool(red) and not compile_error
            results.append((label, ok))
            print("%-50s %s  red=%s" % (label, "BIT" if ok else "NO EFFECT", red or failed[:4]))
            if not ok:
                if compile_error:
                    print("   !! the mutation did not compile; it proves nothing")
                print("   output tail:\n", out[-1200:])
        finally:
            shutil.move(str(backup), str(path))
            os.utime(path, None)
            assert digest(path) == originals[key], "%s: restore did not reproduce the file" % label

    print("\n== summary ==")
    for label, ok in results:
        print("%-50s %s" % (label, "bit" if ok else "DID NOT BIT"))
        if not ok:
            bad = True
    print("all mutations bit:", not bad)
    sys.exit(1 if bad else 0)


if __name__ == "__main__":
    main()
