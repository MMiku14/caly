#!/usr/bin/env python3
"""Round 106 falsification harness (`jobs.list` discovery verb).

Each mutation breaks ONE property in ONE file, keeping bindings/arity/types so the crate still
compiles. A mutation "bites" when the named test(s) fail on a green build (a compile error proves
rustc, not the assertion). Restore is content+mtime (shutil.move back + os.utime) and sha-verified.

Mutations:
  M1  Engine: flip the list order to oldest-first (`.rev()` removed) -> newest-first unit test +
      real-binary e2e (expects rows [2,1]) must go red.
  M2  CLI: route the id-less `jobs` verb to the OLD behaviour -> there is no old string that still
      compiles, so instead point the typed arm away from ListJobs (make id-less build nothing /
      fall through). Concretely: change the parse so an id-less verb sets NO operation (the
      operation stays None) -> the CLI refuses / the e2e `caly jobs` listing goes red.
  M3  Daemon: remove the cap (list every retained job) -> structural gate `..._under_a_daemon_cap`
      loses JOB_LIST_CAP usage and goes red.
  M4  Wire: drop the decode arm for "jobs.list" -> round-trip test `every_encoded_operation_decodes_back...`
      (ListJobs no longer decodes) goes red.
"""
import os
import shutil
import subprocess
import sys
import hashlib
import tempfile

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
CARGO = os.environ.get("CARGO", "cargo")


def sha(path):
    h = hashlib.sha256()
    with open(path, "rb") as fh:
        h.update(fh.read())
    return h.hexdigest()


def run(cmd):
    proc = subprocess.run(cmd, cwd=ROOT, capture_output=True, text=True)
    return proc.returncode, proc.stdout + proc.stderr


def mutate(path, old, new, count=1):
    with open(path, encoding="utf-8") as fh:
        text = fh.read()
    hits = text.count(old)
    assert hits == count, f"{path}: expected {count} of {old!r}, found {hits}"
    backup = path + ".r106bak"
    shutil.move(path, backup)
    with open(path, "w", encoding="utf-8") as fh:
        fh.write(text.replace(old, new, count))
    os.utime(path, None)
    return backup


def restore(path, backup):
    shutil.move(backup, path)
    os.utime(path, None)


MUTATIONS = [
    {
        "name": "M1 engine oldest-first instead of newest-first",
        "file": "crates/caly-engine/src/service.rs",
        "old": "        let rows: Vec<JobFollowView> = guard\n            .jobs\n            .iter()\n            .rev()\n            .take(limit.max(1))",
        "new": "        let rows: Vec<JobFollowView> = guard\n            .jobs\n            .iter()\n            .take(limit.max(1))",
        "expect": [
            ("caly-engine", "--lib", "list_job_views_is_newest_first_and_capped"),
            ("caly-cli", "--test", "caly_cli_e2e caly_jobs_without_an_id_lists_recent_jobs_newest_first"),
        ],
        "build_crates": ["caly-engine", "caly-cli"],
    },
    {
        # The e2e calls `caly jobs --addr HOST`, so after the `jobs` verb the next token is the
        # `--addr` flag: the id-less path runs through the FLAG-requeue arm (not the bare `None`
        # arm, which only a bare `caly jobs` with no trailing tokens hits). Mutate the flag arm so
        # an id-less verb with a following flag stops selecting jobs.list.
        "name": "M2 CLI id-less jobs verb (flag-requeue arm) no longer routes to jobs.list",
        "file": "crates/caly-cli/src/bin/caly.rs",
        "old": "                        rest.insert(0, value);\n                        args = rest.into_iter();\n                        operation = Some(\"jobs.list\");",
        "new": "                        rest.insert(0, value);\n                        args = rest.into_iter();\n                        operation = None;",
        "expect": [
            ("caly-cli", "--test", "caly_cli_e2e caly_jobs_without_an_id_lists_recent_jobs_newest_first"),
        ],
        "build_crates": ["caly-cli"],
    },
    {
        "name": "M3 daemon drops its own reply cap",
        "file": "crates/caly-daemon/src/app.rs",
        "old": "        const JOB_LIST_CAP: usize = 64;\n        self.sync_runtime_from_engine()?;\n        self.engine.list_job_views(JOB_LIST_CAP)",
        "new": "        self.sync_runtime_from_engine()?;\n        self.engine.list_job_views(usize::MAX)",
        "expect": [
            ("caly-arch-test", "--test", "dependency_direction the_jobs_discovery_verb_is_wired_end_to_end_under_a_daemon_cap"),
        ],
        "build_crates": ["caly-daemon", "caly-arch-test"],
    },
    {
        "name": "M4 wire drops the jobs.list decode arm",
        "file": "crates/caly-ipc/src/wire_ops.rs",
        "old": "        \"jobs.list\" => Ok(DecodedRequest::Op(Operation::Diagnostics(\n            caly_api::DiagnosticsOp::ListJobs,\n        ))),\n",
        "new": "",
        "expect": [
            ("caly-ipc", "--lib", "every_encoded_operation_decodes_back_to_itself"),
        ],
        "build_crates": ["caly-ipc"],
    },
]


def main():
    results = []
    for m in MUTATIONS:
        path = os.path.join(ROOT, m["file"])
        before = sha(path)
        print(f"\n=== {m['name']} ===")
        backup = mutate(path, m["old"], m["new"])
        try:
            build_failed = False
            for crate in m["build_crates"]:
                code, out = run([CARGO, "test", "-p", crate, "--no-run"])
                if code != 0:
                    build_failed = True
                    print(f"  BUILD FAILED for {crate} (proves rustc, not the judge):\n{out[-800:]}")
                    break
            bitten = {}
            if build_failed:
                for crate, _flag, test in m["expect"]:
                    bitten[test] = "build-failed"
            else:
                for crate, flag, test in m["expect"]:
                    # `test` may be "<target> <name>" for an integration-test filter. The full
                    # `cargo test` (not --no-run) rebuilds the binary dependencies (calyd/caly), so
                    # a mutation in caly-engine actually reaches the process-spawning e2e.
                    parts = test.split()
                    if flag == "--test" and len(parts) == 2:
                        cmd = [CARGO, "test", "-p", crate, "--test", parts[0], parts[1], "--", "--nocapture"]
                    elif flag == "--test":
                        cmd = [CARGO, "test", "-p", crate, "--test", parts[0]]
                    else:
                        cmd = [CARGO, "test", "-p", crate, "--lib", parts[0]]
                    code, out = run(cmd)
                    # A lib/integration filter that matches nothing is a harness miss, not a pass.
                    ran = "test result: ok" in out or "test result: FAILED" in out or "FAILED" in out
                    if not ran:
                        verdict = "NO-MATCH(!!)"
                    else:
                        verdict = "RED" if code != 0 else "GREEN(!!)"
                    bitten[test] = verdict
            ok = all(v != "GREEN(!!)" for v in bitten.values())
            for test, verdict in bitten.items():
                print(f"  {test}: {verdict}")
            results.append((m["name"], ok))
        finally:
            restore(path, backup)
            after = sha(path)
            assert after == before, f"restore mismatch for {path}"
            print(f"  restored (sha matches)")

    print("\n=== summary ===")
    all_ok = True
    for name, ok in results:
        print(f"  {'BIT' if ok else 'DID NOT BIT'}: {name}")
        all_ok = all_ok and ok
    sys.exit(0 if all_ok else 1)


if __name__ == "__main__":
    main()
