"""Falsification harness for round 35 (the deadline half of the store's port driving).

Same discipline as `falsify_round16/32/33/34`: one mutation per run, one file per mutation,
exact-anchor replacement with `assert count == 1`, restore by content and mtime, sha256-verified,
stale `*.r35bak` swept at startup. A mutation that fails to compile proves nothing (`§4.112`).

The five mutations are `ADR-039 §2` step 3's doors as removals: the deadline reaching the drive,
the cancellation reaching the drive, the two error-kind translations that keep `Timeout` and
`Cancelled` distinct from `Busy`/`Internal`, and the clock injection that makes a deadline real.

Usage: `python3 scripts/falsify_round35.py` (exit 0 = every mutation bit, every file restored).
"""

import hashlib
import os
import pathlib
import shutil
import subprocess
import sys

ROOT = pathlib.Path("/home/user/caly")
ENV = dict(os.environ)
ENV["PATH"] = str(pathlib.Path.home() / ".cargo/bin") + ":" + ENV.get("PATH", "")
SRC = {
    "port_drive": ROOT / "crates/caly-storage/src/port_drive.rs",
    "fs_store": ROOT / "crates/caly-storage/src/fs_store.rs",
}

MUTATIONS = [
    (
        "M1 the deadline never reaches the drive",
        "port_drive",
        "    if let (Some(deadline), Some(clock)) = (ctx.deadline_mono_ms, clock) {",
        "    if let (Some(deadline), Some(clock)) = (None, clock) {",
        ["an_expired_deadline_times_the_port_out_instead_of_calling_it_busy"],
    ),
    (
        "M2 the cancellation never reaches the drive",
        "port_drive",
        "    let mut limits = Drive::bounded(STORE_PORT_POLL_BUDGET).with_cancel(&ctx.cancel);",
        "    let mut limits = Drive::bounded(STORE_PORT_POLL_BUDGET);",
        ["a_cancelled_caller_is_answered_cancelled_even_mid_port"],
    ),
    (
        "M3 the driver's Cancelled is flattened to Internal",
        "port_drive",
        "        IoFaultKind::Cancelled => StorageErrorKind::Cancelled,",
        "        IoFaultKind::Cancelled => StorageErrorKind::Internal,",
        ["a_cancelled_caller_is_answered_cancelled_even_mid_port"],
    ),
    (
        "M4 the driver's Timeout is flattened to Busy",
        "port_drive",
        "        IoFaultKind::Timeout => StorageErrorKind::Timeout,",
        "        IoFaultKind::Timeout => StorageErrorKind::Busy,",
        ["an_expired_deadline_times_the_port_out_instead_of_calling_it_busy"],
    ),
    (
        "M5 with_clock accepts the clock and drops it",
        "fs_store",
        "        inner.clock = Some(clock);",
        "        let _ = clock;\n        inner.clock = None;",
        ["an_expired_deadline_times_the_port_out_instead_of_calling_it_busy"],
    ),
]


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def run_cargo():
    proc = subprocess.run(
        ["cargo", "test", "-p", "caly-storage", "--no-fail-fast"],
        cwd=str(ROOT),
        env=ENV,
        capture_output=True,
        text=True,
    )
    out = proc.stdout + proc.stderr
    failed = sorted(
        {
            line[5:].split(" ... ")[0].split("::")[-1].strip()
            for line in out.splitlines()
            if line.startswith("test ") and line.rstrip().endswith("... FAILED")
        }
    )
    return proc.returncode, failed, out


def main():
    for path in ROOT.rglob("*.r35bak"):
        original = pathlib.Path(str(path)[: -len(".r35bak")])
        shutil.move(str(path), str(original))
        print("swept leftover backup:", path.name)

    originals = {name: digest(path) for name, path in SRC.items()}
    results = []
    bad = False
    for label, key, old, new, expected in MUTATIONS:
        path = SRC[key]
        s = path.read_text()
        assert s.count(old) == 1, "%s: anchor x%d" % (label, s.count(old))
        backup = pathlib.Path(str(path) + ".r35bak")
        shutil.copyfile(path, backup)
        try:
            path.write_text(s.replace(old, new, 1))
            code, failed, out = run_cargo()
            red = [name for name in expected if name in failed]
            compile_error = "error[" in out or "could not compile" in out
            ok = bool(red) and not compile_error
            results.append((label, ok))
            print("%-48s %s  red=%s" % (label, "BIT" if ok else "NO EFFECT", red or failed[:4]))
            if not ok:
                if compile_error:
                    print("   !! the mutation did not compile; it proves nothing")
                print("   output tail:\n", out[-1200:])
        finally:
            shutil.move(str(backup), str(path))
            os.utime(path, None)
            assert digest(path) == originals[key], "%s: restore did not reproduce the file" % label

    print("\n== summary ==")
    for label, ok in results:
        print("%-48s %s" % (label, "bit" if ok else "DID NOT BIT"))
        if not ok:
            bad = True
    print("all mutations bit:", not bad)
    sys.exit(1 if bad else 0)


if __name__ == "__main__":
    main()
