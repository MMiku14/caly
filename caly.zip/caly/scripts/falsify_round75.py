#!/usr/bin/env python3
"""Round 75 falsification harness.

The claim under test: every anchor a source-index record carries is validated as a
`sha256:<64 hex>` anchor **by that field's name** (round 75 closed two gaps found by
measurement):

- `raw_object_digest` was only checked for emptiness — the field the worker later uses to
  *address* the raw body (`storage.get(record.raw_object_digest)`), so a record carrying a
  non-anchor here was accepted (the test fixture itself carried `sha256:raw-object`).
- the three cache digests (`normalized_digest`/`provenance_digest`/`diagnostics_digest`)
  were refused indirectly via the content-anchor comparison, but the diagnosis said "does
  not match its content anchor" — "you altered a value", not "this is not an anchor at all".

The judges are `caly-storage/tests/record_codec.rs`:
`source_index_rejects_a_raw_object_digest_that_is_not_a_sha256_anchor` and
`source_index_rejects_malformed_cache_digests_by_name`.

- M1 (must bite)  the `raw_object_digest` format check is removed — the judge accepts a
      non-anchor and fails.
- M2 (must bite)  the cache-digest format loop is removed — the malformed-digit judge gets
      the old "does not match" diagnosis and fails.

Usage: `python3 scripts/falsify_round75.py` (exit 0 = both bit, files restored).
"""

import hashlib
import os
import pathlib
import subprocess
import sys
import time

ROOT = pathlib.Path("/home/user/caly_extract/caly")
ENV = dict(os.environ)
ENV["PATH"] = str(pathlib.Path.home() / ".cargo/bin") + ":" + ENV.get("PATH", "")

RECORD = ROOT / "crates/caly-storage/src/record.rs"

M1_OLD = """    if !source_anchor(&raw_object_digest) {
        return Err(RecordCodecError::new(
            "source index raw_object_digest is not a sha256 anchor",
        ));
    }"""
M1_NEW = """    // M1: removed on purpose — the judge must bite."""
M1_JUDGE = [
    "-p", "caly-storage", "--test", "record_codec",
    "source_index_rejects_a_raw_object_digest_that_is_not_a_sha256_anchor",
]

M2_OLD = """    for (field, anchor) in [
        ("normalized_digest", normalized_digest.as_str()),
        ("provenance_digest", provenance_digest.as_str()),
        ("diagnostics_digest", diagnostics_digest.as_str()),
    ] {
        if !source_anchor(anchor) {
            return Err(RecordCodecError::new(format!(
                "source index {field} is not a sha256 anchor"
            )));
        }
    }"""
M2_NEW = """    // M2: removed on purpose — the judge must bite."""
M2_JUDGE = [
    "-p", "caly-storage", "--test", "record_codec",
    "source_index_rejects_malformed_cache_digests_by_name",
]


def digest(path):
    return hashlib.sha256(pathlib.Path(path).read_bytes()).hexdigest()


def sweep_strays():
    for path in ROOT.rglob("*.r75bak"):
        print(f"  note  sweeping stale {path}")
        path.unlink()


def run_judge(args):
    begin = time.time()
    proc = subprocess.run(
        ["cargo", "test"] + args,
        cwd=ROOT,
        env=ENV,
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
        text=True,
        timeout=300,
    )
    return proc, time.time() - begin


def main():
    original = RECORD.read_text()
    all_ok = True
    try:
        for label, old, new, judge in [
            ("M1 raw_object_digest format check removed (must bite)", M1_OLD, M1_NEW, M1_JUDGE),
            ("M2 cache-digest format loop removed (must bite)", M2_OLD, M2_NEW, M2_JUDGE),
        ]:
            if RECORD.read_text() != original:
                print(f"  FAIL  {label}: tree is dirty before mutation")
                all_ok = False
                break
            if old not in original:
                print(f"  FAIL  {label}: anchor not found — pattern drifted")
                all_ok = False
                break
            backup = ROOT / ".r75bak"
            backup.write_bytes(RECORD.read_bytes())
            RECORD.write_text(RECORD.read_text().replace(old, new, 1))
            proc, elapsed = run_judge(judge)
            if proc.returncode != 0 and "error[E" not in proc.stdout:
                print(f"  ok    {label} (bite in {elapsed:.1f}s)")
            elif "error[E" in proc.stdout:
                print(f"  FAIL  {label}: compiler error, not a property failure ({elapsed:.1f}s)")
                all_ok = False
            else:
                print(f"  FAIL  {label}: judge stayed green ({elapsed:.1f}s)")
                all_ok = False
            RECORD.write_bytes(backup.read_bytes())
            backup.unlink()
            if RECORD.read_text() != original:
                print(f"  FAIL  {label}: restore mismatch")
                all_ok = False
    finally:
        sweep_strays()
        if RECORD.read_text() != original:
            RECORD.write_text(original)
            print("  note  hard-restored record.rs")

    if all_ok:
        print("all mutations behaved as predicted: True")
        return 0
    print("all mutations behaved as predicted: False")
    return 1


if __name__ == "__main__":
    sys.exit(main())
