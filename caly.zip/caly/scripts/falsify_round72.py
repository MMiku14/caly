#!/usr/bin/env python3
"""Round 72 falsification harness.

The claim under test (`ADR-052`, blocking syscall 的中断/回收语义): a **stalled peer**
(accepts then never answers) is reclaimed by min(caller deadline remaining, peer timeout),
mapped to `IoFaultKind::Timeout`, and the socket is closed (peer sees EOF) — an in-flight
syscall is never claimed to be interruptible. The judge is
`caly-io-std/tests/http_contract.rs`:

- `a_stalled_peer_is_reclaimed_by_the_caller_deadline` (returns within ~600ms, Timeout, EOF)
- `a_cancel_during_a_blocked_read_does_not_claim_interruption` (cancel mid-read still times out)

- M1 (must bite)  the read timeout is dropped (`set_read_timeout(None)`) — the stalled
      peer makes the client block forever; the judge process is killed by the harness
      timeout (a hang is the bug ADR-052 §2.2 exists for).
- M2 (must bite)  a read error is mis-mapped to `Unavailable` instead of `Timeout` —
      the judge's kind assertion fails.

Usage: `python3 scripts/falsify_round72.py` (exit 0 = both bit, files restored).
"""

import hashlib
import os
import pathlib
import signal
import subprocess
import sys
import time

ROOT = pathlib.Path("/home/user/caly_extract/caly")
ENV = dict(os.environ)
ENV["PATH"] = str(pathlib.Path.home() / ".cargo/bin") + ":" + ENV.get("PATH", "")

HTTP = ROOT / "crates/caly-io-std/src/http.rs"

M1_OLD = "                .set_read_timeout(Some(control.timeout(IO_TIMEOUT)))"
M1_NEW = "                .set_read_timeout(None) // M1: no bound on a blocking read"

M2_OLD = 'Self::fault(IoFaultKind::Timeout, format!("read status line: {error}"))'
M2_NEW = 'Self::fault(IoFaultKind::Unavailable, format!("read status line: {error}"))'

JUDGE = [
    "-p", "caly-io-std", "--test", "http_contract",
    "a_stalled_peer_is_reclaimed_by_the_caller_deadline",
]
JUDGE_TIMEOUT_SECS = 30

# M1 makes the judge hang (no bound on the read); 30s must be enough for the warm test
# (~1s) to finish in the healthy case, and for the harness to notice the hang otherwise.


def digest(path):
    return hashlib.sha256(pathlib.Path(path).read_bytes()).hexdigest()


def sweep_strays():
    for path in ROOT.rglob("*.r72bak"):
        print(f"  note  sweeping stale {path}")
        path.unlink()


def run_judge():
    begin = time.time()
    proc = subprocess.Popen(
        ["cargo", "test"] + JUDGE,
        cwd=ROOT,
        env=ENV,
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
        text=True,
        start_new_session=True,
    )
    try:
        out, _ = proc.communicate(timeout=JUDGE_TIMEOUT_SECS)
    except subprocess.TimeoutExpired:
        # The harness killed the hung run: that is the M1 signature (no bounded reclaim).
        os.killpg(proc.pid, signal.SIGKILL)
        proc.wait()
        return None, time.time() - begin, "HANG"
    out = out or ""
    # Mimic subprocess.run's interface for the caller.
    proc.stdout = out
    proc.returncode = proc.returncode
    return proc, time.time() - begin, "RETURNED"


def main():
    original = HTTP.read_text()
    all_ok = True
    try:
        for label, old, new in [
            ("M1 the read timeout is dropped (must bite on a hang)", M1_OLD, M1_NEW),
            ("M2 a read error is mis-mapped to Unavailable (must bite)", M2_OLD, M2_NEW),
        ]:
            if HTTP.read_text() != original:
                print(f"  FAIL  {label}: tree is dirty before mutation")
                all_ok = False
                break
            if old not in original:
                print(f"  FAIL  {label}: anchor not found — pattern drifted")
                all_ok = False
                break
            backup = ROOT / ".r72bak"
            backup.write_bytes(HTTP.read_bytes())
            HTTP.write_text(HTTP.read_text().replace(old, new, 1))
            proc, elapsed, mode = run_judge()
            if mode == "HANG":
                print(f"  ok    {label} (hang = no bounded reclaim; killed after "
                      f"{JUDGE_TIMEOUT_SECS}s)")
            elif proc.returncode != 0 and "error[E" not in proc.stdout:
                print(f"  ok    {label} (bite in {elapsed:.1f}s)")
            elif "error[E" in proc.stdout:
                print(f"  FAIL  {label}: compiler error, not a property failure ({elapsed:.1f}s)")
                all_ok = False
            else:
                print(f"  FAIL  {label}: judge stayed green ({elapsed:.1f}s)")
                all_ok = False
            HTTP.write_bytes(backup.read_bytes())
            backup.unlink()
            if HTTP.read_text() != original:
                print(f"  FAIL  {label}: restore mismatch")
                all_ok = False
    finally:
        sweep_strays()
        if HTTP.read_text() != original:
            HTTP.write_text(original)
            print("  note  hard-restored http.rs")

    if all_ok:
        print("all mutations behaved as predicted: True")
        return 0
    print("all mutations behaved as predicted: False")
    return 1


if __name__ == "__main__":
    sys.exit(main())
