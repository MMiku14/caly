#!/usr/bin/env python3
"""Round 89 documentation surgery.

Append-only §4.163 + disposition ledger 6.115 (and renumber the
"deliberately not doing" heading to 6.116), update the Phase-6 transport status,
and refresh the current-snapshot test counts 813 -> 814. Historical numbers are
never rewritten.
"""
import pathlib

ROOT = pathlib.Path(__file__).resolve().parents[1]
NOTES = ROOT / "docs/ONBOARDING_NOTES.md"

text = NOTES.read_text(encoding="utf-8")

# 1. §4.163 after §4.162 (the env-round entry ends with the scheduling sentence + fence).
anchor = "  真核 E2E 串行跑约 90s，完整 `check.sh`（两次 clippy 冷编）约 4–5 分钟，排期按此。\n\n---\n"
entry = anchor + """
### 4.163 握手走泵、会话之后绕开泵：生产 CLI 的写半没有超时（第八十九轮）

- **Observed**：第八十七轮把握手收进共享 `FramePump`（构造时同时设 read+write 超时、读前 `probe_peer`），
  但那个泵在 `handshake()` 里是**临时借用** `&mut session.stream` 建的，握手结束即 drop。会话其余整段
  （`ask`/`follow_stream`/`ack_and_confirm` 的请求帧、stream-ack、流数据帧）走 `Session::send/recv`，
  它直调裸 codec `wire_write_frame`/`wire_read_frame`；而 `Session::open` 只 `set_read_timeout(3s)`，
  **从不设 `set_write_timeout`**。于是读有 3s 上限、写没有——一个停止读取的对端（接收窗口耗尽）会让
  `write_all` **无限挂起**。这是 R44「不会回答的 daemon 不许挂死客户端」（读半，falsify 发现）的**写半**遗漏。
- **量选**：`grep wire_write_frame crates/caly-cli/` 在 `bin/caly.rs` 命中生产调用；`FramePump::new`
  是唯一同时设两个超时的地方；`calyd` 侧设 read+write（每连接 `serve_connection`），不对称只在客户端。
- **Fix**：`Session` 改为**持有** `FramePump<WireStream>`（不再持裸 `WireStream`），`Session::open`
  在连接时一次性建泵（read+write 上限、探活全在泵里），`send/recv` 委托泵；`handshake()` 直接驱动
  `session.pump`（删掉临时建泵）。整连接一个泵，读/写/探活同一有界 transport；wire 形状逐字不变
  （`caly_cli_e2e` 25 条真二进制链路全绿）。
- **新门禁**：`dependency_direction.rs::the_cli_drives_every_frame_through_the_shared_pump`
  ——生产 `caly-cli/src/**`（tests/ 目录取外，oracle 自持实现是证据）不许出现裸
  `wire_read_frame(`/`wire_write_frame(` 调用（`use ` 导入不算）；带「扫到 ≥3 个源文件」与
  「`caly-cli/Cargo.toml` 存在」两条反空转断言。证伪：M1 把扫描指向不存在的 crate ⇒ 反空转红、
  编译绿；M2 把 `Session::send` 改回经 `inner_mut()` 直调 `wire_write_frame` ⇒ 门禁红、编译绿
  （行为不变的第二接缝只有这条门禁能咬——R76 同族教训）。两变异全咬。
- **规则**：一个有界泵被引入后，要问它覆盖的是**整段会话**还是只覆盖第一个帧；「握手安全了、之后
  各走各路」是同一类挂死面换了件衣服。结构性保证（不许裸调）比「记得每处都设超时」可靠。

---
"""
assert text.count(anchor) == 1, "§4.162 end anchor count"
text = text.replace(anchor, entry, 1)

# 2. Disposition ledger row 6.115 above 6.114 (newest-first).
anchor_6114 = "| 6.114 | 第八十八轮"
row_6115 = (
    "| 6.115 | 第八十九轮：**生产 CLI 全会话走共享泵，关闭写半无超时面（§13#3 小切片）**——R87 后握手走 "
    "`FramePump`（read+write 超时+读前探活）但泵是临时借用、握手即 drop；会话其余帧走 `Session` "
    "直调裸 `wire_write_frame/wire_read_frame`，且只设 read 超时、**write 无超时**（停止读取的对端可让 "
    "`write_all` 无限挂起=R44 挂死面的写半）。修：`Session` 持 `FramePump<WireStream>`，open 时建泵、"
    "send/recv/handshake 全委托，整连接一个泵；wire 形状不变（`caly_cli_e2e` 25 条全绿）。新门禁 "
    "`the_cli_drives_every_frame_through_the_shared_pump`（生产 caly-cli src 禁裸 `wire_read_frame("
    "`/`wire_write_frame(`，两条反空转断言）+1，census 813→**814**、floor 814；证伪 `falsify_round89.py` "
    "M1（扫指向不存在 crate→反空转红、编译绿）/M2（send 改回裸 codec→门禁红、编译绿）全咬。明确没做："
    "共享 timeout scheduler、typed `send_request_frame` 生产化、SessionRegistry 生产化（§13#3 主体，下一轮）；"
    "无新 ADR（闭合 R87 既有泵，不引新架构决策）。 | §4.163 |\n"
)
assert text.count(anchor_6114) == 1, "6.114 anchor count"
text = text.replace(anchor_6114, row_6115 + anchor_6114, 1)

# 3. Renumber the "deliberately not doing" heading 6.115 -> 6.116.
old_heading = "### 6.115 历史上明确**不做**的项"
new_heading = "### 6.116 历史上明确**不做**的项"
assert text.count(old_heading) == 1, "heading anchor count"
text = text.replace(old_heading, new_heading, 1)

NOTES.write_text(text, encoding="utf-8")
print("ONBOARDING_NOTES patched (§4.163 + 6.115 + heading 6.116)")

# 4. Current-snapshot numbering 813 -> 814 across the state docs (historical 1,813 untouched).
def replace_once(rel, old, new):
    p = ROOT / rel
    t = p.read_text(encoding="utf-8")
    assert t.count(old) == 1, f"{rel}: count({old[:50]!r}) = {t.count(old)}"
    p.write_text(t.replace(old, new, 1), encoding="utf-8")
    print(f"numbered {rel}")

replace_once("docs/IMPLEMENTATION_STATUS.md",
    "813 个行首 `#[test]` 断言（105 个文件；数字来自 `python3 scripts/regenerate_test_census.py`，`cargo test --workspace` 门禁 floor 同步为 813）",
    "814 个行首 `#[test]` 断言（105 个文件；数字来自 `python3 scripts/regenerate_test_census.py`，`cargo test --workspace` 门禁 floor 同步为 814）")
replace_once("docs/IMPLEMENTATION_STATUS.md",
    "cargo test --workspace                    # 813 passed / 0 failed（门禁 TEST_FLOOR=813）",
    "cargo test --workspace                    # 814 passed / 0 failed（门禁 TEST_FLOOR=814）")
replace_once("docs/IMPLEMENTATION_STATUS.md",
    "./scripts/check.sh                         # 本轮完整门禁通过（813 / 31 / 0）",
    "./scripts/check.sh                         # 本轮完整门禁通过（814 / 31 / 0）")
replace_once("docs/IMPLEMENTATION_STATUS.md",
    "**813** 个行首 `#[test]`（105 个文件）",
    "**814** 个行首 `#[test]`（105 个文件）")
replace_once("docs/IMPLEMENTATION_STATUS.md",
    "当前门禁为 813 tests / floor 813 / clippy 基线 31；格式漂移 0 行。",
    "当前门禁为 814 tests / floor 814 / clippy 基线 31；格式漂移 0 行。")

replace_once("docs/CENTERLINE_PROGRESS.md",
    "# `./scripts/check.sh` 最终结果：813 tests / floor 813 / clippy baseline 31 / fmt 0 lines；all gates passed（第八十七轮",
    "# `./scripts/check.sh` 最终结果：814 tests / floor 814 / clippy baseline 31 / fmt 0 lines；all gates passed（第八十九轮")
replace_once("docs/CENTERLINE_PROGRESS.md",
    "# files=105 total=813 rows=105",
    "# files=105 total=814 rows=105")
replace_once("docs/CENTERLINE_PROGRESS.md",
    "> 当前门禁为 813 tests / floor 813 / clippy baseline 31；格式漂移 0 行。",
    "> 当前门禁为 814 tests / floor 814 / clippy baseline 31；格式漂移 0 行。")
replace_once("docs/CENTERLINE_PROGRESS.md",
    "> 判据是“这 813 个断言是否依然成立”",
    "> 判据是“这 814 个断言是否依然成立”")

replace_once("docs/ROADMAP.md",
    "813 个行首 `#[test]`，105 个文件；契约、parity、scenario",
    "814 个行首 `#[test]`，105 个文件；契约、parity、scenario")
replace_once("docs/ROADMAP.md",
    "813 tests / floor 813；clippy 31；fmt 0 行；无 CI/fuzz/perf regression",
    "814 tests / floor 814；clippy 31；fmt 0 行；无 CI/fuzz/perf regression")

# The ONBOARDING current-snapshot census line now reads 814 (row above set 6.115 text but not this line).
replace_once("docs/ONBOARDING_NOTES.md",
    "- `python3 scripts/regenerate_test_census.py --check`：`files=105 total=813 rows=105`；门禁 floor 为 813。",
    "- `python3 scripts/regenerate_test_census.py --check`：`files=105 total=814 rows=105`；门禁 floor 为 814。")

print("all round-89 doc patches applied")
