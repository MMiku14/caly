#!/usr/bin/env python3
"""Round 66 falsification harness.

The claim under test: `jobs.follow-stream` DATA frames are the events op's window
line for line (the judge is `calyd_wire::the_stream_data_payload_matches_the_events_page_line_for_line`).
Each mutation makes the stream disagree with the events page (or lie about its own
frame's line count) while everything still compiles — a count-vs-count judge would
stay green, which is exactly the gap round 66 closes.

Mutations (one file each, all in `crates/caly-daemon/src/bin/calyd.rs`, the DATA-frame
assembly):
- V1  lines pushed in reverse order;
- V2  each line truncated to 16 chars;
- V3  `event_count` reports one line fewer than the frame carries;
- V4  the loop runs one extra iteration (an empty `event_i` row).

Usage: `python3 scripts/falsify_round66.py` (exit 0 = every mutation bit, files restored).
"""

import hashlib
import os
import pathlib
import subprocess
import sys
import time

ROOT = pathlib.Path("/home/user/caly_extract/caly")
ENV = dict(os.environ)
ENV["PATH"] = str(pathlib.Path.home() / ".cargo/bin") + ":" + ENV.get("PATH", "")

JUDGE = "the_stream_data_payload_matches_the_events_page_line_for_line"

SRC = ROOT / "crates/caly-daemon/src/bin/calyd.rs"

LOOP_OLD = """                                                    for (index, line) in lines.iter().enumerate() {
                                                        records.push((
                                                            format!("event_{index}"),
                                                            line.clone(),
                                                        ));
                                                    }
"""

MUTATIONS = [
    (
        "V1 stream lines pushed in reverse order",
        LOOP_OLD,
        """                                                    for (index, line) in lines.iter().rev().enumerate() {
                                                        records.push((
                                                            format!("event_{index}"),
                                                            line.clone(),
                                                        ));
                                                    }
""",
    ),
    (
        "V2 stream lines truncated to 16 chars",
        LOOP_OLD,
        """                                                    for (index, line) in lines.iter().enumerate() {
                                                        records.push((
                                                            format!("event_{index}"),
                                                            line.chars().take(16).collect::<String>(),
                                                        ));
                                                    }
""",
    ),
    (
        "V3 event_count reported one line fewer",
        """                                                        (
                                                            "event_count".to_owned(),
                                                            lines.len().to_string(),
                                                        ),""",
        """                                                        (
                                                            "event_count".to_owned(),
                                                            (lines.len() - 1).to_string(),
                                                        ),""",
    ),
    (
        "V4 the loop runs one extra line",
        LOOP_OLD,
        """                                                    for index in 0..=lines.len() {
                                                        let line = lines
                                                            .get(index)
                                                            .map(String::as_str)
                                                            .unwrap_or("");
                                                        records.push((
                                                            format!("event_{index}"),
                                                            line.to_owned(),
                                                        ));
                                                    }
""",
    ),
]


def digest(path):
    return hashlib.sha256(pathlib.Path(path).read_bytes()).hexdigest()


def sweep_strays():
    for path in ROOT.rglob("*.r66bak"):
        print(f"  note  sweeping stale {path}")
        path.unlink()


def run_judge():
    begin = time.time()
    proc = subprocess.run(
        [
            "cargo",
            "test",
            "-p",
            "caly-daemon",
            "--test",
            "calyd_wire",
            JUDGE,
        ],
        cwd=ROOT,
        env=ENV,
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
        text=True,
        timeout=900,
    )
    return proc, time.time() - begin


def main():
    original = SRC.read_text()
    original_digest = digest(SRC)
    anchors = set()
    for name, old, new in MUTATIONS:
        anchors.add(old)
    for anchor in sorted(anchors):
        count = original.count(anchor)
        if count != 1:
            print(f"  FAIL  anchor count={count} (want 1) for: {anchor[:60]!r}")
            return 1

    sweep_strays()
    all_bit = True
    try:
        for name, old, new in MUTATIONS:
            backup = ROOT / ".r66bak"
            backup.write_text(SRC.read_text())
            SRC.write_text(SRC.read_text().replace(old, new, 1))
            if digest(SRC) == original_digest:
                print(f"  FAIL  {name}: mutation produced no change")
                SRC.write_text(backup.read_text())
                all_bit = False
                continue
            try:
                proc, elapsed = run_judge()
                if proc.returncode != 0:
                    print(f"  ok    {name} (bite in {elapsed:.1f}s)")
                    if JUDGE not in proc.stdout:
                        print(f"        NOTE: judge did not run? tail: {proc.stdout[-400:]}")
                else:
                    print(f"  FAIL  {name}: judge stayed green ({elapsed:.1f}s)")
                    all_bit = False
            except subprocess.TimeoutExpired:
                print(f"  FAIL  {name}: timed out (900s) — hanging mutation, not a bite")
                all_bit = False
            finally:
                SRC.write_text(backup.read_text())
                backup.unlink()
            if SRC.read_text() != original:
                print(f"  FAIL  {name}: restore mismatch")
                all_bit = False
    finally:
        sweep_strays()

    final_digest = digest(SRC)
    if final_digest != original_digest:
        print(f"  FAIL  final digest mismatch: {final_digest} != {original_digest}")
        all_bit = False
    if all_bit:
        print("all mutations bit: True")
        return 0
    print("all mutations bit: False")
    return 1


if __name__ == "__main__":
    sys.exit(main())
