#!/usr/bin/env python3
"""Round 90 doc numbering: TEST_FLOOR/census 814 -> 816 (2 new tests).
Historical numbers untouched."""
import pathlib

ROOT = pathlib.Path(__file__).resolve().parents[1]


def replace_once(rel, old, new):
    p = ROOT / rel
    t = p.read_text(encoding="utf-8")
    assert t.count(old) == 1, f"{rel}: count({old[:46]!r}) = {t.count(old)}"
    p.write_text(t.replace(old, new, 1), encoding="utf-8")
    print(f"numbered {rel}: ...{old[:30]}...")


replace_once("docs/IMPLEMENTATION_STATUS.md",
    "814 个行首 `#[test]` 断言（105 个文件；数字来自 `python3 scripts/regenerate_test_census.py`，`cargo test --workspace` 门禁 floor 同步为 814）",
    "816 个行首 `#[test]` 断言（105 个文件；数字来自 `python3 scripts/regenerate_test_census.py`，`cargo test --workspace` 门禁 floor 同步为 816）")
replace_once("docs/IMPLEMENTATION_STATUS.md",
    "cargo test --workspace                    # 814 passed / 0 failed（门禁 TEST_FLOOR=814）",
    "cargo test --workspace                    # 816 passed / 0 failed（门禁 TEST_FLOOR=816）")
replace_once("docs/IMPLEMENTATION_STATUS.md",
    "./scripts/check.sh                         # 本轮完整门禁通过（814 / 31 / 0）",
    "./scripts/check.sh                         # 本轮完整门禁通过（816 / 31 / 0）")
replace_once("docs/IMPLEMENTATION_STATUS.md",
    "**814** 个行首 `#[test]`（105 个文件）",
    "**816** 个行首 `#[test]`（105 个文件）")
replace_once("docs/IMPLEMENTATION_STATUS.md",
    "当前门禁为 814 tests / floor 814 / clippy 基线 31；格式漂移 0 行。",
    "当前门禁为 816 tests / floor 816 / clippy 基线 31；格式漂移 0 行。")

replace_once("docs/CENTERLINE_PROGRESS.md",
    "# `./scripts/check.sh` 最终结果：814 tests / floor 814 / clippy baseline 31 / fmt 0 lines；all gates passed（第八十九轮",
    "# `./scripts/check.sh` 最终结果：816 tests / floor 816 / clippy baseline 31 / fmt 0 lines；all gates passed（第九十轮")
replace_once("docs/CENTERLINE_PROGRESS.md",
    "# files=105 total=814 rows=105",
    "# files=105 total=816 rows=105")
replace_once("docs/CENTERLINE_PROGRESS.md",
    "> 当前门禁为 814 tests / floor 814 / clippy baseline 31；格式漂移 0 行。",
    "> 当前门禁为 816 tests / floor 816 / clippy baseline 31；格式漂移 0 行。")
replace_once("docs/CENTERLINE_PROGRESS.md",
    "> 判据是“这 814 个断言是否依然成立”",
    "> 判据是“这 816 个断言是否依然成立”")

replace_once("docs/ROADMAP.md",
    "814 个行首 `#[test]`，105 个文件；契约、parity、scenario",
    "816 个行首 `#[test]`，105 个文件；契约、parity、scenario")
replace_once("docs/ROADMAP.md",
    "814 tests / floor 814；clippy 31；fmt 0 行；无 CI/fuzz/perf regression",
    "816 tests / floor 816；clippy 31；fmt 0 行；无 CI/fuzz/perf regression")

replace_once("docs/ONBOARDING_NOTES.md",
    "- `python3 scripts/regenerate_test_census.py --check`：`files=105 total=814 rows=105`；门禁 floor 为 814。",
    "- `python3 scripts/regenerate_test_census.py --check`：`files=105 total=816 rows=105`；门禁 floor 为 816。")

print("round-90 numbering applied")
