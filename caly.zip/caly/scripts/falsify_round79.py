#!/usr/bin/env python3
"""Round 79 falsification harness.

The claim: `docs/EXIT_CODES.md`'s ErrorCode table and the code the CLI actually exits with
(`caly_cli::ExitCode` + `caly_api::ErrorCode`) are one map, and the judge is
`caly-cli/tests/exit_code_table.rs`.

- M1 (must bite)  a document-side drift: the table's `CURSOR_STALE` name is typo'd —
    the table-vs-enumeration judge goes red (shell scripts read the document).
- M2 (must bite)  a code-side drift: `Timeout = 11` becomes `Timeout = 21` — the
    enumeration judge goes red twice (the range is no longer 0..=16 and the documented
    map no longer matches what `from_error_code` returns).

Usage: `python3 scripts/falsify_round79.py` (exit 0 = both bit, files restored).
"""

import hashlib
import os
import pathlib
import shutil
import subprocess
import sys
import time

ROOT = pathlib.Path("/home/user/caly_extract/caly")
ENV = dict(os.environ)
ENV["PATH"] = str(pathlib.Path.home() / ".cargo/bin") + ":" + ENV.get("PATH", "")

DOC = ROOT / "docs/EXIT_CODES.md"
CODE = ROOT / "crates/caly-cli/src/exit_code.rs"

JUDGE = ["cargo", "test", "-q", "-p", "caly-cli", "--test", "exit_code_table"]
JUDGE_TIMEOUT_SECS = 180


def digest(path):
    return hashlib.sha256(pathlib.Path(path).read_bytes()).hexdigest()


def sweep_strays():
    for path in ROOT.rglob("*.r79bak"):
        print(f"  note  sweeping stale {path}")
        path.unlink()


def run_judge():
    begin = time.time()
    proc = subprocess.Popen(
        JUDGE,
        cwd=ROOT,
        env=ENV,
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
        text=True,
        start_new_session=True,
    )
    try:
        out, _ = proc.communicate(timeout=JUDGE_TIMEOUT_SECS)
    except subprocess.TimeoutExpired:
        os.killpg(proc.pid, 9)
        proc.wait()
        return None, time.time() - begin, "HANG"
    ok = "0 failed" in (out or "") and "test result: ok" in (out or "")
    return ok, time.time() - begin, ""


def apply_one(path, needle, replacement):
    text = path.read_text()
    assert text.count(needle) == 1, f"{path}: needle not unique: {needle!r}"
    bak = pathlib.Path(str(path) + ".r79bak")
    shutil.copy2(path, bak)
    path.write_text(text.replace(needle, replacement))


def restore_one(path):
    bak = pathlib.Path(str(path) + ".r79bak")
    if bak.exists():
        shutil.copy2(bak, path)
        bak.unlink()
        # copy2 keeps the ORIGINAL mtime, which can be OLDER than a rlib built
        # from the mutated text — cargo then trusts the stale artifact forever
        # (the R78 stale-fingerprint trap). Bump mtime to now: forces a rebuild
        # and keeps the tree honest after every run.
        os.utime(path, None)


M1_OLD = "| `14` | `CURSOR_STALE` |"
M1_NEW = "| `14` | `CURSOR_STALEX` |"

M2_OLD = "    Timeout = 11,"
M2_NEW = "    Timeout = 21,"


def main():
    sweep_strays()
    results = []

    # M1: document-side drift on the stable name.
    apply_one(DOC, M1_OLD, M1_NEW)
    ok, secs, note = run_judge()
    results.append(("M1", "the documented name drifts (must bite)", ok, secs, note))
    restore_one(DOC)

    # M2: code-side drift on the exit number.
    apply_one(CODE, M2_OLD, M2_NEW)
    ok, secs, note = run_judge()
    results.append(("M2", "the code's exit number drifts (must bite)", ok, secs, note))
    restore_one(CODE)

    all_bite = True
    for name, label, bit, secs, note in results:
        if note:
            print(f"  {'ok' if not bit else 'MISS'}    {name} {label} ({note} in {secs:.1f}s)")
        else:
            print(f"  {'ok' if not bit else 'MISS'}    {name} {label} (bite in {secs:.1f}s)")
        # bit == the judge stayed green under the mutation (it did NOT bite): a miss.
        if note or bit:
            all_bite = False

    print(f"restored: doc={digest(DOC)[:12]}… code={digest(CODE)[:12]}…")
    print("all mutations behaved as predicted: " + ("True" if all_bite else "False"))
    sys.exit(0 if all_bite else 1)


if __name__ == "__main__":
    main()
