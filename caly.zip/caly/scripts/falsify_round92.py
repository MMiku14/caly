#!/usr/bin/env python3
"""Round 92 falsification harness.

Target property: the production WIRE daemon derives a remote peer's role from the role it
negotiated at hello, and carries that role into the request envelope — never a hard-coded
`Role::Admin` (`ADR-037` / `RFC-0002 §7.2`). The frame loop rebuilds each request from wire
records; stamping Admin there made every remote caller (including one that declared Operator)
pass an Admin-only operation, silently defeating `require_role` on the wire.

Fix under test:
  - `DaemonTransport::peer_role()` (transport.rs) reads the role recorded from the negotiated
    hello (`session.machine.info.role`).
  - the calyd frame loop (calyd.rs) builds `RequestEnvelope { role: peer_role, .. }` instead of
    `role: Role::Admin`.

Judges:
  - e2e `a_wire_peer_declaring_operator_is_refused_an_admin_command` (Operator hello + Admin
    `system.gc` -> KIND_REFUSAL, code PERMISSION) and its anti-vacuity twin
    `a_wire_peer_declaring_admin_is_not_refused_by_the_role_gate` (Admin hello is not refused on
    privilege).
  - arch-test gate `the_wire_daemon_carries_the_hello_negotiated_role_into_request_envelopes`
    (the frame loop calls `transport.peer_role()`, the envelope carries `role: peer_role`, and
    no literal `role: Role::Admin` survives in the envelope body; the accessor exists).

Mutations (one file each; bindings/types/arity preserved so the build stays green and the
*judge* is what bites):

  M1 (hard-code Admin in the envelope): replace `role: peer_role` with `role: Role::Admin` in
      the calyd frame loop. Expected to bite: the Operator e2e (it gets a response, not a
      PERMISSION refusal) and the arch gate (envelope body has the literal admin role).
  M2 (drop the peer_role call): replace `let peer_role = transport.peer_role()...` with a
      hard-coded Admin binding. Expected to bite: the arch gate (no `transport.peer_role()`
      call) and the Operator e2e.
  M3 (peer_role lies): make `DaemonTransport::peer_role` always report Admin regardless of the
      negotiated hello. Expected to bite: the Operator e2e (the accessor no longer reflects the
      Operator hello) while the gate — which only checks structural wiring — stays green; this
      proves the behavioral e2e covers what the structural gate cannot.

Restoration is content + mtime, sha256-verified. cwd = workspace root.
"""

import hashlib
import os
import pathlib
import shutil
import subprocess
import sys

ROOT = pathlib.Path(__file__).resolve().parents[1]
GATE = ROOT / "crates/caly-arch-test/tests/dependency_direction.rs"
CALYD = ROOT / "crates/caly-daemon/src/bin/calyd.rs"
TRANSPORT = ROOT / "crates/caly-daemon/src/transport.rs"
SUFFIX = ".r92bak"


def sha256(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def backup(path):
    digest = sha256(path)
    shutil.move(str(path), str(path.with_name(path.name + SUFFIX)))
    return digest


def backup_text(path):
    return path.with_name(path.name + SUFFIX).read_text()


def restore(path, expected):
    shutil.move(str(path.with_name(path.name + SUFFIX)), str(path))
    os.utime(path, None)
    got = sha256(path)
    assert got == expected, f"restore mismatch {path}: {got} != {expected}"


def cargo(args, timeout=400):
    proc = subprocess.run(
        ["cargo", *args], cwd=ROOT, capture_output=True, text=True, timeout=timeout
    )
    return proc.returncode, proc.stdout + proc.stderr


def build_failed(out):
    return "error[" in out or "could not compile" in out


def wire_role_e2e_result():
    # Build the calyd binary the test spawns first, so a stale binary cannot mask a mutation.
    rc, out = cargo(["build", "-p", "caly-daemon", "--bin", "calyd"])
    if build_failed(out):
        return True, False, False, out
    rc, out = cargo(
        [
            "test", "-p", "caly-daemon", "--test", "calyd_wire",
            "wire_peer_declaring",
        ]
    )
    # The Operator refusal judge and the Admin anti-vacuity judge run together under that filter.
    operator_red = "a_wire_peer_declaring_operator_is_refused_an_admin_command ... FAILED" in out
    # All tests in the filtered run green?
    all_green = "test result: ok" in out and "FAILED" not in out
    return False, all_green, operator_red, out


def gate_result():
    rc, out = cargo(
        [
            "test", "-p", "caly-arch-test", "--test", "dependency_direction",
            "the_wire_daemon_carries_the_hello_negotiated_role_into_request_envelopes",
        ]
    )
    red = "test result: FAILED" in out or "panicked" in out
    return build_failed(out), (not red and "test result: ok" in out), out


def sweep():
    for f in ROOT.glob("crates/**/*.r92bak"):
        f.unlink()


def main():
    sweep()
    # Baseline: every judge green on the fixed tree.
    bf, green, _red, out = wire_role_e2e_result()
    assert not bf and green, "clean tree wire-role e2e must pass:\n" + out[-1500:]
    bf, gok, out = gate_result()
    assert not bf and gok, "clean tree gate must pass:\n" + out[-1500:]
    print("baseline: wire-role e2e + gate green")

    results = {}

    # M1: envelope stamps the literal Admin role -> Operator e2e gets a response (refusal judge
    # fails) AND the arch gate sees the literal in the envelope body. Build stays green.
    d1 = backup(CALYD)
    try:
        t = backup_text(CALYD)
        old = "                    role: peer_role,\n"
        new = "                    role: Role::Admin,\n"
        assert t.count(old) == 1, f"M1 anchor {t.count(old)}"
        CALYD.write_text(t.replace(old, new, 1))
        bf, green, operator_red, e2e_out = wire_role_e2e_result()
        e2e_bit = (not bf) and (not green) and operator_red
        bf_g, gok, gate_out = gate_result()
        gate_bit = (not bf_g) and (not gok) and ("peer_role" in gate_out or "Admin" in gate_out)
        bit = e2e_bit and gate_bit
        results["M1 envelope-hardcodes-admin"] = bit
        print(f"M1: e2e_build_failed={bf} e2e_green={green} op_red={operator_red} (bit={e2e_bit}) | "
              f"gate_green={gok} (bit={gate_bit}) -> {bit}")
    finally:
        restore(CALYD, d1)

    # M2: drop the peer_role() call (bind Admin directly) -> the gate loses the call site and the
    # Operator e2e is not refused. Build stays green.
    d2 = backup(CALYD)
    try:
        t = backup_text(CALYD)
        old = "                let peer_role = transport.peer_role().unwrap_or(Role::Admin);\n"
        new = "                let peer_role = Role::Admin;\n"
        assert t.count(old) == 1, f"M2 anchor {t.count(old)}"
        CALYD.write_text(t.replace(old, new, 1))
        bf, green, operator_red, e2e_out = wire_role_e2e_result()
        e2e_bit = (not bf) and (not green) and operator_red
        bf_g, gok, gate_out = gate_result()
        gate_bit = (not bf_g) and (not gok) and "peer_role" in gate_out
        bit = e2e_bit and gate_bit
        results["M2 no-peer_role-call"] = bit
        print(f"M2: e2e_build_failed={bf} e2e_green={green} op_red={operator_red} (bit={e2e_bit}) | "
              f"gate_green={gok} (bit={gate_bit}) -> {bit}")
    finally:
        restore(CALYD, d2)

    # M3: peer_role() always reports Admin regardless of the negotiated hello -> the Operator e2e
    # is escalated (refusal judge red); the structural gate stays green (it checks wiring, not the
    # returned value), proving the behavioral e2e covers the value the gate cannot.
    d3 = backup(TRANSPORT)
    try:
        t = backup_text(TRANSPORT)
        old = "        self.session.machine.info.as_ref().map(|info| info.role)\n"
        new = "        let _ = &self.session;\n        Some(caly_api::Role::Admin)\n"
        assert t.count(old) == 1, f"M3 anchor {t.count(old)}"
        TRANSPORT.write_text(t.replace(old, new, 1))
        bf, green, operator_red, e2e_out = wire_role_e2e_result()
        # Operator must be refused; with the lie it is escalated -> that judge fails. The Admin
        # twin still passes (Admin is not refused), so the run reports exactly one FAILED judge.
        bit = (not bf) and (not green) and operator_red
        results["M3 peer_role-always-admin"] = bit
        print(f"M3: build_failed={bf} e2e_green={green} op_red={operator_red} bit={bit}")
    finally:
        restore(TRANSPORT, d3)

    sweep()
    all_bit = all(results.values())
    print(f"\nall mutations bit: {all_bit}")
    for name, bit in results.items():
        print(f"  {'BIT' if bit else 'MISS'}  {name}")
    return 0 if all_bit else 1


if __name__ == "__main__":
    sys.exit(main())
