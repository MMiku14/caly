"""Falsification harness for round 56 (deployment truth: apply plans against the engine's
last committed artifact, and the plan pins the real binary digest).

Same discipline as rounds 16/32–55: one mutation per run, exact-anchor replacement with
`assert count == 1`, restore by content and mtime, sha256-verified, stale `*.r56bak`
swept at startup. A mutation that cannot compile proves nothing (`§4.112`); backups are
per-mutation (`§4.137`); each cargo run carries a hard timeout — a mutation that wedges
the suite counts as DID NOT BIT (`§4.139`). Real cores may outlive a judge whose plan
forgot to stop them, so stray `caly-run.yaml` cores are swept — with a sleep — after
every mutation (`DEVELOPMENT_LOG_2026-08-27 §6`).

Five mutations, each bitten by a judge this round created or redeemed:

- M1  the cross-profile guard removed from the plan-kind choice — a profile switch
      plans HotReload, which the real backend refuses (`unsupported-core-call`), and the
      restart judge goes red at "the old core must be stopped";
- M2  the pinned binary digest const off by one character — the real backend hashes the
      bytes it is about to deploy and refuses (`binary-digest-mismatch`);
- M3  the worker planning against `None` again (first install forever) — no StopCore, the
      second spawn hits `instance-already-running`;
- M4  the digest check flattened to `false` — the unit judge that names both digests
      goes red (the check is the supply-chain fence, not decoration);
- M5  the digest-equality arm poisoned (`false && …`) — a Noop can never be chosen, the
      re-apply is planned as a reload and refused on the real backend.

Usage: `python3 scripts/falsify_round56.py` (exit 0 = every mutation bit, every file restored).
"""

import hashlib
import os
import pathlib
import shutil
import subprocess
import sys
import time

ROOT = pathlib.Path("/home/user/caly")
ENV = dict(os.environ)
ENV["PATH"] = str(pathlib.Path.home() / ".cargo/bin") + ":" + ENV.get("PATH", "")
SRC = {
    "adapter": ROOT / "crates/caly-mihomo/src/adapter.rs",
    "worker": ROOT / "crates/caly-engine/src/worker.rs",
    "std": ROOT / "crates/caly-daemon/src/effect_std.rs",
}

MUTATIONS = [
    (
        "M1 cross-profile guard removed from plan-kind",
        "adapter",
        "        } else if current.is_some() && !tun_enabled && !cross_profile {",
        "        } else if current.is_some() && !tun_enabled {",
        [
            "restart_sequence_actually_stops_the_old_core",
        ],
    ),
    (
        "M2 pinned binary digest off by one char",
        "adapter",
        '''pub const MIHOMO_BINARY_SHA256: &str =
    "cf06ce2c7d1421bdbda14ee4a5b6046672dc35ebf8eecd8e77504ec3c0ed9a84";''',
        '''pub const MIHOMO_BINARY_SHA256: &str =
    "cf06ce2c7d1421bdbda14ee4a5b6046672dc35ebf8eecd8e77504ec3c0ed9a85";''',
        [
            "nightshift_applies_end_to_end_with_a_live_real_core",
        ],
    ),
    (
        "M3 worker plans against None (first install forever)",
        "worker",
        "    let workflow = match plan_apply_request_with_current(request, current.as_ref()) {",
        "    let workflow = match plan_apply_request_with_current(request, None) {",
        [
            "restart_sequence_actually_stops_the_old_core",
        ],
    ),
    (
        "M4 spawn digest check flattened to false",
        "std",
        "                if *binary_digest != core_sha256 {",
        "                if false && *binary_digest != core_sha256 {",
        [
            "spawn_refuses_a_binary_the_plan_did_not_name",
        ],
    ),
    (
        "M5 digest-equality poisoned (Noop never chosen)",
        "adapter",
        "            .map(|artifact| artifact.artifact_digest == next.artifact_digest)",
        "            .map(|artifact| false && artifact.artifact_digest == next.artifact_digest)",
        [
            "re_applying_the_same_profile_is_a_noop_that_leaves_the_core_alone",
        ],
    ),
]


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def sweep_stray_cores():
    """A plan that forgot to stop its core leaves it running after the judge died; the next
    verdict needs a clean host. The pattern never matches this harness's own command line."""
    subprocess.run(
        ["pkill", "-f", "caly-run.yaml"],
        stdout=subprocess.DEVNULL,
        stderr=subprocess.DEVNULL,
    )
    time.sleep(1.0)  # a kill is not done until a beat has passed


def run_cargo():
    argv = [
        "cargo",
        "test",
        "-p",
        "caly-daemon",
        "--lib",
        "--test",
        "real_apply",
        "--no-fail-fast",
    ]
    try:
        proc = subprocess.run(
            argv,
            cwd=str(ROOT),
            env=ENV,
            capture_output=True,
            text=True,
            timeout=900,  # §4.139: a wedged suite is a wedged mutant, not a verdict
        )
    except subprocess.TimeoutExpired:
        return 124, [], "TIMEOUT: the mutation wedged the suite (§4.139) — redesign it"
    out = proc.stdout + proc.stderr
    failed = sorted(
        {
            line[5:].split(" ... ")[0].split("::")[-1].strip()
            for line in out.splitlines()
            if line.startswith("test ") and line.rstrip().endswith("... FAILED")
        }
    )
    return proc.returncode, failed, out


def main():
    for path in ROOT.rglob("*.r56bak"):
        original = pathlib.Path(str(path)[: -len(".r56bak")])
        shutil.move(str(path), str(original))
        print("swept leftover backup:", path.name)
    sweep_stray_cores()

    originals = {name: digest(path) for name, path in SRC.items()}
    results = []
    bad = False
    for label, key, old, new, expected in MUTATIONS:
        path = SRC[key]
        backup = pathlib.Path(str(path) + ".r56bak")
        shutil.copyfile(path, backup)  # per-mutation backup (§4.137)
        s = path.read_text()
        assert s.count(old) == 1, "%s: anchor x%d" % (label, s.count(old))
        try:
            mutated = s.replace(old, new, 1)
            path.write_text(mutated)
            code, failed, out = run_cargo()
            wedged = code == 124
            red = [name for name in expected if name in failed]
            compile_error = "error[" in out or "could not compile" in out
            ok = bool(red) and not compile_error and not wedged
            results.append((label, ok))
            print("%-52s %s  red=%s" % (label, "BIT" if ok else "NO EFFECT", red or failed[:4]))
            if not ok:
                if compile_error:
                    print("   !! the mutation did not compile; it proves nothing")
                if wedged:
                    print("   !! the mutation wedged the suite; it proves nothing (§4.139)")
                print("   output tail:\n", out[-1200:])
        finally:
            shutil.move(str(backup), str(path))
            os.utime(path, None)
            assert digest(path) == originals[key], "%s: restore did not reproduce the file" % label
            sweep_stray_cores()

    print("\n== summary ==")
    for label, ok in results:
        print("%-52s %s" % (label, "bit" if ok else "DID NOT BIT"))
        if not ok:
            bad = True
    print("all mutations bit:", not bad)
    sys.exit(1 if bad else 0)


if __name__ == "__main__":
    main()
