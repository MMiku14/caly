"""Falsification harness for round 38 (the boot scan admits content anchors before paths).

Same discipline as rounds 16/32–37: one mutation per run, exact-anchor replacement with
`assert count == 1`, restore by content and mtime, sha256-verified, stale `*.r38bak` swept at
startup. A mutation that cannot compile proves nothing (`§4.112`).

The four mutations walk the admission's failure modes: the boot scan building a suffix from
unadmitted garbage again (the original misdiagnosis), the length rule quietly dropped, an
admission that refuses nothing *and says nothing* (vacuous — the boot would walk past damage),
and the GC door bypassing the shared helper so the two doors can disagree again.

Usage: `python3 scripts/falsify_round38.py` (exit 0 = every mutation bit, every file restored).
"""

import hashlib
import os
import pathlib
import shutil
import subprocess
import sys

ROOT = pathlib.Path("/home/user/caly")
ENV = dict(os.environ)
ENV["PATH"] = str(pathlib.Path.home() / ".cargo/bin") + ":" + ENV.get("PATH", "")
SRC = ROOT / "crates/caly-storage/src/fs_store.rs"

MUTATIONS = [
    (
        "M1 the boot scan builds a suffix from unadmitted garbage",
        """                if let Err(refusal) = admit_content_anchor(anchor) {
                    problems.push(format!(
                        "object {} records a malformed content anchor: {}",
                        object.digest.0, refusal.summary
                    ));
                    continue;
                }
                let content_suffix = content_suffix_for(anchor);""",
        "                let content_suffix = content_suffix_for(anchor);",
        ["boot_names_a_malformed_content_anchor_instead_of_inventing_a_missing_file"],
    ),
    (
        "M2 the length rule is quietly dropped",
        """    if hex.len() != CONTENT_ANCHOR_HEX_LEN {
        return Err(StorageError::new(
            StorageErrorKind::IntegrityViolation,
            format!(
                "content anchor is not a full {CONTENT_ANCHOR_HEX_LEN}-hex sha256 name: {anchor}"
            ),
        ));
    }
    Ok(())""",
        "    Ok(())",
        ["boot_refuses_a_record_whose_anchor_has_the_wrong_length"],
    ),
    (
        "M3 the admission refuses nothing and says nothing",
        """                if let Err(refusal) = admit_content_anchor(anchor) {
                    problems.push(format!(
                        "object {} records a malformed content anchor: {}",
                        object.digest.0, refusal.summary
                    ));
                    continue;
                }""",
        "                let _ = admit_content_anchor(anchor);",
        [
            "boot_names_a_malformed_content_anchor_instead_of_inventing_a_missing_file",
            "boot_refuses_a_record_whose_anchor_has_the_wrong_length",
        ],
    ),
    (
        "M4 the GC door bypasses the shared admission",
        """        crate::gc::ContentTarget::Anchor(anchor) => {
            admit_content_anchor(anchor)?;
            Ok(content_suffix_for(anchor))
        }""",
        """        crate::gc::ContentTarget::Anchor(anchor) => Ok(content_suffix_for(anchor)),""",
        ["a_target_the_layout_cannot_explain_is_refused"],
    ),
]


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def run_cargo():
    proc = subprocess.run(
        ["cargo", "test", "-p", "caly-storage", "--no-fail-fast"],
        cwd=str(ROOT),
        env=ENV,
        capture_output=True,
        text=True,
    )
    out = proc.stdout + proc.stderr
    failed = sorted(
        {
            line[5:].split(" ... ")[0].split("::")[-1].strip()
            for line in out.splitlines()
            if line.startswith("test ") and line.rstrip().endswith("... FAILED")
        }
    )
    return proc.returncode, failed, out


def main():
    for path in ROOT.rglob("*.r38bak"):
        original = pathlib.Path(str(path)[: -len(".r38bak")])
        shutil.move(str(path), str(original))
        print("swept leftover backup:", path.name)

    original = digest(SRC)
    results = []
    bad = False
    for label, old, new, expected in MUTATIONS:
        s = SRC.read_text()
        assert s.count(old) == 1, "%s: anchor x%d" % (label, s.count(old))
        backup = pathlib.Path(str(SRC) + ".r38bak")
        shutil.copyfile(SRC, backup)
        try:
            SRC.write_text(s.replace(old, new, 1))
            code, failed, out = run_cargo()
            red = [name for name in expected if name in failed]
            compile_error = "error[" in out or "could not compile" in out
            ok = bool(red) and not compile_error
            results.append((label, ok))
            print("%-52s %s  red=%s" % (label, "BIT" if ok else "NO EFFECT", red or failed[:4]))
            if not ok:
                if compile_error:
                    print("   !! the mutation did not compile; it proves nothing")
                print("   output tail:\n", out[-1200:])
        finally:
            shutil.move(str(backup), str(SRC))
            os.utime(SRC, None)
            assert digest(SRC) == original, "%s: restore did not reproduce the file" % label

    print("\n== summary ==")
    for label, ok in results:
        print("%-52s %s" % (label, "bit" if ok else "DID NOT BIT"))
        if not ok:
            bad = True
    print("all mutations bit:", not bad)
    sys.exit(1 if bad else 0)


if __name__ == "__main__":
    main()
