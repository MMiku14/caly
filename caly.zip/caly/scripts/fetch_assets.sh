#!/usr/bin/env bash
# Fetch the pinned real-core assets into assets/ (not tracked by git — see .gitignore).
#
# The workspace tests that exercise the real effect runtime (effect_std unit tests, real_apply,
# spawn_artifacts, calyd wire e2e) refuse or fail without these files: the upstream delivery
# stripped them (assets/ shipped as empty directories). This script restores the exact artifacts
# the tests pin.
#
# Cores are immutable release artifacts, pinned by sha256 (the same prefixes the tests assert:
# mihomo cf06ce2c…, sing-box 646bc01b…). The geo data files are rolling upstream releases; the
# *current* pins live in crates/caly-io-std/tests/real_core.rs (re-pinned 2026-09-01 because
# upstream keeps only a "latest" release). If the pin drifts, the judge goes red and names the
# new digest — re-pin deliberately (see the rule quoted in that test), do not paper over it.
set -euo pipefail
cd "$(dirname "$0")/.."

mkdir -p assets/cores assets/geo

MIHOMO_URL="https://github.com/MetaCubeX/mihomo/releases/download/v1.19.30/mihomo-linux-amd64-v1.19.30.gz"
MIHOMO_SHA="cf06ce2c7d1421bdbda14ee4a5b6046672dc35ebf8eecd8e77504ec3c0ed9a84"
SINGBOX_URL="https://github.com/SagerNet/sing-box/releases/download/v1.13.20/sing-box-1.13.20-linux-amd64.tar.gz"
SINGBOX_SHA="646bc01bf128c32a12eb50d8690e387bba7504da7b1d65c704bd53916e38595a"
GEOIP_URL="https://github.com/MetaCubeX/meta-rules-dat/releases/download/latest/geoip.metadb"
GEOSITE_URL="https://github.com/MetaCubeX/meta-rules-dat/releases/download/latest/geosite.dat"

fetch_verify() { # <url> <dest> <sha256>
  local url="$1" dest="$2" sha="$3"
  if [ -f "$dest" ] && echo "$sha  $dest" | sha256sum -c --quiet 2>/dev/null; then
    echo "  ok    $dest (already pinned)"
    return 0
  fi
  echo "  fetch $dest"
  curl -sL --fail -o "$dest.tmp" "$url"
  echo "$sha  $dest.tmp" | sha256sum -c --quiet
  mv "$dest.tmp" "$dest"
  echo "  ok    $dest"
}

fetch_verify "$MIHOMO_URL" "assets/cores/mihomo-linux-amd64-v1.19.30.gz" "$MIHOMO_SHA"
fetch_verify "$SINGBOX_URL" "assets/cores/sing-box-1.13.20-linux-amd64.tar.gz" "$SINGBOX_SHA"

# Geo data: rolling upstream, unpinned by design (see header comment).
for spec in "$GEOIP_URL|assets/geo/geoip.metadb" "$GEOSITE_URL|assets/geo/geosite.dat"; do
  url="${spec%%|*}"; dest="${spec##*|}"
  if [ -s "$dest" ]; then
    echo "  ok    $dest (present)"
  else
    echo "  fetch $dest"
    curl -sL --fail -o "$dest.tmp" "$url"
    [ -s "$dest.tmp" ] || { echo "  FAIL  $dest empty"; exit 1; }
    mv "$dest.tmp" "$dest"
    echo "  ok    $dest (sha256 $(sha256sum "$dest" | cut -d' ' -f1))"
  fi
done

echo "assets ready"
