#!/usr/bin/env python3
"""Round 78 falsification harness.

The claim: `diagnostics.doctor`'s runtime projection is reachable over the wire — the
opt-in record `include_runtime` (values `"true"`/`"false"`, the bool family's spelling)
rides the v0 wire shape in both directions, and the daemon's summary widens to name the
runtime snapshot when (and only when) the client asks for it.

The judges are:

- `caly-ipc` lib unit tests (`wire_ops`): the doctor opt-in's round-trip (encode paints
  the record, decode reads it back into the same typed request).
- `calyd_wire`'s `a_doctor_request_can_opt_into_the_runtime_projection`: the real daemon's
  door, reached with a hand-written payload — the oracle's own wire, agreeing with the
  single-source shape only if the daemon's decode really honors the record.

- M1 (must bite)  the **decode** arm drops the record (include_runtime pinned to false) —
  the round-trip judge goes red, and so does the door judge (the daemon decodes through
  this module; the hand-written opt-in request's summary stays unwidened).
- M2 (must bite)  the **encode** arm drops the record (plain doctor) — the opt-in
  round-trip judge goes red (the wire no longer carries what the typed request means).

Usage: `python3 scripts/falsify_round78.py` (exit 0 = both bit, files restored).
"""

import hashlib
import os
import pathlib
import shutil
import subprocess
import sys
import time

ROOT = pathlib.Path("/home/user/caly_extract/caly")
ENV = dict(os.environ)
ENV["PATH"] = str(pathlib.Path.home() / ".cargo/bin") + ":" + ENV.get("PATH", "")

WIRE_OPS = ROOT / "crates/caly-ipc/src/wire_ops.rs"
BAK = ROOT / "crates/caly-ipc/src/wire_ops.rs.r78bak"

JUDGE = [
    ("-p", "caly-ipc", "--lib", "wire_ops"),
    ("-p", "caly-daemon", "--test", "calyd_wire",
     "a_doctor_request_can_opt_into_the_runtime_projection"),
]
JUDGE_TIMEOUT_SECS = 180


def digest(path):
    return hashlib.sha256(pathlib.Path(path).read_bytes()).hexdigest()


def sweep_strays():
    for path in ROOT.rglob("*.r78bak"):
        print(f"  note  sweeping stale {path}")
        path.unlink()


def run_judge():
    for judge in JUDGE:
        begin = time.time()
        proc = subprocess.Popen(
            ["cargo", "test", "-q", *judge],
            cwd=ROOT,
            env=ENV,
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            text=True,
            start_new_session=True,
        )
        try:
            out, _ = proc.communicate(timeout=JUDGE_TIMEOUT_SECS)
        except subprocess.TimeoutExpired:
            os.killpg(proc.pid, 9)
            proc.wait()
            return None, time.time() - begin, "HANG"
        ok = "0 failed" in (out or "") and "test result: ok" in (out or "")
        return ok, time.time() - begin, ""


def apply(needle, replacement):
    # Always snapshot first (round 76: a "backup already taken" flag plus an earlier
    # restore deleting the backup leaves the mutation in the tree).
    text = WIRE_OPS.read_text()
    assert text.count(needle) == 1, f"needle not unique: {needle!r}"
    shutil.copy2(WIRE_OPS, BAK)
    WIRE_OPS.write_text(text.replace(needle, replacement))


def restore():
    if BAK.exists():
        shutil.copy2(BAK, WIRE_OPS)
        BAK.unlink()


M1_OLD = '''        "diagnostics.doctor" => {
            let include_runtime =
                crate::wire::wire_field(records, "include_runtime") == Some("true");'''
M1_NEW = '''        "diagnostics.doctor" => {
            let include_runtime = false; // M1: the record is dropped'''
assert WIRE_OPS.read_text().count(M1_OLD) == 1, "M1 needle drifted"

M2_OLD = '''        Operation::Diagnostics(DiagnosticsOp::Doctor { request }) => fields(
            "diagnostics.doctor",
            vec![("include_runtime", request.include_runtime.to_string())],
        ),'''
M2_NEW = '''        Operation::Diagnostics(DiagnosticsOp::Doctor { .. }) => plain("diagnostics.doctor"),
'''
assert WIRE_OPS.read_text().count(M2_OLD) == 1, "M2 needle drifted"


def main():
    sweep_strays()
    results = []

    # M1: the decoder drops the opt-in record.
    apply(M1_OLD, M1_NEW)
    ok, secs, note = run_judge()
    results.append(("M1", "the decoder drops the opt-in record (must bite)", ok, secs, note))
    restore()

    # M2: the encoder drops the opt-in record.
    apply(M2_OLD, M2_NEW)
    ok, secs, note = run_judge()
    results.append(("M2", "the encoder drops the opt-in record (must bite)", ok, secs, note))
    restore()

    all_bite = True
    for name, label, bit, secs, note in results:
        if note:
            print(f"  {'ok' if not bit else 'MISS'}    {name} {label} ({note} in {secs:.1f}s)")
        else:
            print(f"  {'ok' if not bit else 'MISS'}    {name} {label} (bite in {secs:.1f}s)")
        # bit == the judge stayed green under the mutation (it did NOT bite): a miss.
        if note or bit:
            all_bite = False

    print(f"restored digest {digest(WIRE_OPS)[:16]}…")
    print("all mutations behaved as predicted: " + ("True" if all_bite else "False"))
    sys.exit(0 if all_bite else 1)


if __name__ == "__main__":
    main()
