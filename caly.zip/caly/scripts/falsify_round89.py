#!/usr/bin/env python3
"""Round 89 falsification harness.

Target property: the production CLI drives every frame through the shared
`caly_ipc::FramePump` (bounded read AND write timeouts, peer probe) — enforced
by the new arch-test gate `the_cli_drives_every_frame_through_the_shared_pump`.

Two mutations, each in one file, each preserving bindings/types/arity (the goal
is "the property stops holding", not "the program fails to compile"):

  M1 (gate strength): drop the gate's call-site detection so a second raw frame
      loop is invisible — append `and False` to the offender `if`. The gate must
      then go RED (it exists to catch precisely this; a gate that cannot see its
      own predicate removed judges nothing). Expected to bite: the gate test.
  M2 (the real seam): make the shipped CLI write one frame through the raw codec
      again (the pre-round-89 shape — write-unbounded, bypassing the pump),
      disguised to still compile. The gate must go RED while the build stays
      green (a behavior-preserving second seam is exactly what only this gate
      catches — round 76's lesson).

Each mutation is restored (content + mtime) and verified by sha256 against the
pre-mutation digest. Run with the workspace root as cwd.
"""

import hashlib
import os
import pathlib
import shutil
import subprocess
import sys

ROOT = pathlib.Path(__file__).resolve().parents[1]
GATE = ROOT / "crates/caly-arch-test/tests/dependency_direction.rs"
CLI = ROOT / "crates/caly-cli/src/bin/caly.rs"
BACKUP_SUFFIX = ".r89bak"


def sha256(path: pathlib.Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def take_backup(path: pathlib.Path) -> str:
    digest = sha256(path)
    backup = path.with_name(path.name + BACKUP_SUFFIX)
    shutil.move(str(path), str(backup))
    return digest


def restore(path: pathlib.Path, expected_digest: str) -> None:
    backup = path.with_name(path.name + BACKUP_SUFFIX)
    shutil.move(str(backup), str(path))
    # Restore mtime too (round 79's stale-artifact lesson): a retained old mtime
    # can make cargo reuse a newer artifact over the restored source.
    os.utime(path, None)
    got = sha256(path)
    assert got == expected_digest, f"restore digest mismatch for {path}: {got} != {expected_digest}"


def run_gate() -> tuple[bool, bool, str]:
    """Returns (build_failed, gate_passed, output)."""
    proc = subprocess.run(
        [
            "cargo",
            "test",
            "-p",
            "caly-arch-test",
            "--test",
            "dependency_direction",
            "the_cli_drives_every_frame_through_the_shared_pump",
        ],
        cwd=ROOT,
        capture_output=True,
        text=True,
    )
    out = proc.stdout + proc.stderr
    build_failed = "error[" in out or "could not compile" in out
    # `test result: ok` with 1 passed means the gate held; a FAILED line means it bit.
    gate_passed = "test result: ok" in out and "1 passed" in out
    return build_failed, gate_passed, out


def sweep_backups() -> None:
    for leftover in ROOT.glob("crates/**/*.r89bak"):
        leftover.unlink()


def mutate_gate_blind() -> None:
    # Point the scan at a crate that does not exist. The gate's anti-vacuity guard (the
    # `caly-cli/Cargo.toml` must exist assert) must then go RED while the build stays
    # green — a scan over zero files is exactly how "no offenders" can lie.
    text = GATE.with_name(GATE.name + BACKUP_SUFFIX).read_text()
    old = 'let caly_cli = Path::new(&crates_dir()).join("caly-cli");'
    new = 'let caly_cli = Path::new(&crates_dir()).join("caly-cli-missing");'
    assert text.count(old) == 1, f"gate anchor count={text.count(old)}"
    GATE.write_text(text.replace(old, new, 1))


def mutate_cli_second_loop() -> None:
    text = CLI.with_name(CLI.name + BACKUP_SUFFIX).read_text()
    # Route Session::send back through the raw codec against the underlying stream.
    # The pump exposes the stream via `inner_mut()`; the call is a compile-valid use of
    # the imported codec, so the build stays green — only the gate can see the bypass.
    old = (
        "    fn send(&mut self, kind: u8, payload: &[u8]) -> Result<(), String> {\n"
        "        self.pump\n"
        "            .send(kind, payload)\n"
        '            .map_err(|error| format!("write frame: {}", error.summary))\n'
        "    }"
    )
    new = (
        "    fn send(&mut self, kind: u8, payload: &[u8]) -> Result<(), String> {\n"
        "        caly_ipc::wire_write_frame(self.pump.inner_mut(), kind, payload)\n"
        '            .map_err(|error| format!("write frame: {}", error.summary))\n'
        "    }"
    )
    assert text.count(old) == 1, f"cli anchor count={text.count(old)}"
    CLI.write_text(text.replace(old, new, 1))


def main() -> int:
    sweep_backups()

    # Sanity: gate is green on the clean tree before we mutate anything.
    build_failed, gate_passed, out = run_gate()
    assert not build_failed, "clean tree must compile:\n" + out[-2000:]
    assert gate_passed, "clean tree gate must pass before mutation:\n" + out[-2000:]
    print("baseline: gate passes on clean tree")

    results = {}

    # M1: gate predicate disabled -> gate must go red (and still compile).
    d1 = take_backup(GATE)
    try:
        mutate_gate_blind()
        bf, gp, out = run_gate()
        bit = (not bf) and (not gp) and "caly-cli crate" in out
        results["M1 gate-blind"] = bit
        print(f"M1 (anti-vacuity pointed away from caly-cli): build_failed={bf} gate_passed={gp} bit={bit}")
    finally:
        restore(GATE, d1)
    _bf, _gp, out = run_gate()
    assert _gp, "gate must pass again after M1 restore:\n" + out[-2000:]

    # M2: CLI second raw-codec loop -> gate must go red while the build stays green.
    d2 = take_backup(CLI)
    try:
        mutate_cli_second_loop()
        bf, gp, out = run_gate()
        bit = (not bf) and (not gp) and "wire_write_frame" in out
        results["M2 cli-second-loop"] = bit
        print(f"M2 (CLI raw-codec send): build_failed={bf} gate_passed={gp} bit={bit}")
    finally:
        restore(CLI, d2)
    _bf, _gp, out = run_gate()
    assert _gp, "gate must pass again after M2 restore:\n" + out[-2000:]

    sweep_backups()
    all_bit = all(results.values())
    print(f"\nall mutations bit: {all_bit}")
    for name, bit in results.items():
        print(f"  {'BIT' if bit else 'MISS'}  {name}")
    return 0 if all_bit else 1


if __name__ == "__main__":
    sys.exit(main())
