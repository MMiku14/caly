#!/usr/bin/env python3
"""Round 70 falsification harness.

The claim under test (`IMPLEMENTATION_STATUS §8.4` "纯核心缓存/记忆化"): the built-in
capability registry and coverage-matrix documents are **constants constructed once per
process** (`OnceLock` memoization in `caly-cap/src/catalog.rs`). Every apply/validate/bundle
merges its base from them, so a per-call rebuild re-allocated the whole constant each time.
The judge is `registry_drift::the_builtin_documents_are_constructed_once_per_process`
(pointer equality between two calls).

- M1 (must bite)  the registry accessor builds per call (`Box::leak` each time) — the
      pointer-equality judge catches the regression.
- M2 (must bite)  the coverage accessor does the same.

Usage: `python3 scripts/falsify_round70.py` (exit 0 = both bit, files restored).
"""

import hashlib
import os
import pathlib
import subprocess
import sys
import time

ROOT = pathlib.Path("/home/user/caly_extract/caly")
ENV = dict(os.environ)
ENV["PATH"] = str(pathlib.Path.home() / ".cargo/bin") + ":" + ENV.get("PATH", "")

JUDGE = "the_builtin_documents_are_constructed_once_per_process"
CATALOG = ROOT / "crates/caly-cap/src/catalog.rs"

M1_OLD = """pub fn default_registry_document() -> &'static RegistryDocument {
    static DOCUMENT: OnceLock<RegistryDocument> = OnceLock::new();
    DOCUMENT.get_or_init(build_default_registry_document)
}"""
M1_NEW = """pub fn default_registry_document() -> &'static RegistryDocument {
    Box::leak(Box::new(build_default_registry_document()))
}"""

M2_OLD = """pub fn default_coverage_matrix_document() -> &'static CoverageMatrixDocument {
    static DOCUMENT: OnceLock<CoverageMatrixDocument> = OnceLock::new();
    DOCUMENT.get_or_init(build_default_coverage_matrix_document)
}"""
M2_NEW = """pub fn default_coverage_matrix_document() -> &'static CoverageMatrixDocument {
    Box::leak(Box::new(build_default_coverage_matrix_document()))
}"""


def digest(path):
    return hashlib.sha256(pathlib.Path(path).read_bytes()).hexdigest()


def sweep_strays():
    for path in ROOT.rglob("*.r70bak"):
        print(f"  note  sweeping stale {path}")
        path.unlink()


def run_judge():
    begin = time.time()
    proc = subprocess.run(
        ["cargo", "test", "-p", "caly-cap", "--test", "registry_drift", JUDGE],
        cwd=ROOT,
        env=ENV,
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
        text=True,
        timeout=900,
    )
    return proc, time.time() - begin


def main():
    original = CATALOG.read_text()
    anchors = {"M1": original.count(M1_OLD), "M2": original.count(M2_OLD)}
    for name, count in anchors.items():
        if count != 1:
            print(f"  FAIL  {name} anchor count={count} (want 1)")
            return 1

    all_ok = True
    try:
        for label, old, new in [
            ("M1 registry built per call (must bite)", M1_OLD, M1_NEW),
            ("M2 coverage built per call (must bite)", M2_OLD, M2_NEW),
        ]:
            if CATALOG.read_text() != original:
                print(f"  FAIL  {label}: tree is dirty before mutation")
                all_ok = False
                break
            backup = ROOT / ".r70bak"
            backup.write_bytes(CATALOG.read_bytes())
            CATALOG.write_text(CATALOG.read_text().replace(old, new, 1))
            proc, elapsed = run_judge()
            if proc.returncode != 0 and "error[E" not in proc.stdout:
                print(f"  ok    {label} (bite in {elapsed:.1f}s)")
            elif "error[E" in proc.stdout:
                print(f"  FAIL  {label}: compiler error, not a property failure ({elapsed:.1f}s)")
                all_ok = False
            else:
                print(f"  FAIL  {label}: judge stayed green ({elapsed:.1f}s)")
                all_ok = False
            CATALOG.write_bytes(backup.read_bytes())
            backup.unlink()
            if CATALOG.read_text() != original:
                print(f"  FAIL  {label}: restore mismatch")
                all_ok = False
    finally:
        sweep_strays()
        if CATALOG.read_text() != original:
            CATALOG.write_text(original)
            print("  note  hard-restored catalog.rs")

    if all_ok:
        print("all mutations behaved as predicted: True")
        return 0
    print("all mutations behaved as predicted: False")
    return 1


if __name__ == "__main__":
    sys.exit(main())
