#!/usr/bin/env python3
"""Round 68 falsification harness.

The claim under test (`ADR-051`): the checked-in capability registry/coverage JSON are
**export** artifacts; production `src/` never *reads* them. The judge is
`caly-arch-test::dependency_direction::the_registry_artifacts_are_exports_not_runtime_inputs`
(a text gate over `crates/*/src/**/*.rs`, so the mutations below need not compile — the gate
reads files, not the type system).

- M1  (must bite)  a production source line that fetches the artifact:
      `catalog.rs` gains `let _ = std::fs::read_to_string(REGISTRY_PATH);` — a runtime
      loader creeping in, exactly what ADR-051 forbids.
- M2  (must stay green) production code merely NAMES the constant without reading it:
      `executor.rs` gains `const _REF: &str = caly_cap::REGISTRY_PATH;` — naming is not
      reading, the gate must not over-reach.

Usage: `python3 scripts/falsify_round68.py` (exit 0 = M1 bit, M2 stayed green, files restored).
"""

import hashlib
import os
import pathlib
import subprocess
import sys
import time

ROOT = pathlib.Path("/home/user/caly_extract/caly")
ENV = dict(os.environ)
ENV["PATH"] = str(pathlib.Path.home() / ".cargo/bin") + ":" + ENV.get("PATH", "")

JUDGE = "the_registry_artifacts_are_exports_not_runtime_inputs"

CATALOG = ROOT / "crates/caly-cap/src/catalog.rs"
EXECUTOR = ROOT / "crates/caly-engine/src/executor.rs"

# M1: insert a data-fetching line right after the registry-document function signature.
M1_OLD = "pub fn default_registry_document() -> RegistryDocument {"
M1_NEW = (
    "pub fn default_registry_document() -> RegistryDocument {\n"
    "    let _ = std::fs::read_to_string(REGISTRY_PATH);\n"
)

# M2: append a line that names the constant but performs no read.
M2_APPEND = (
    "\n/// ADR-051: naming the export path is not reading it.\n"
    "const _REGISTRY_ARTIFACT_PATH_REF: &str = caly_cap::REGISTRY_PATH;\n"
)


def digest(path):
    return hashlib.sha256(pathlib.Path(path).read_bytes()).hexdigest()


def sweep_strays():
    for path in ROOT.rglob("*.r68bak"):
        print(f"  note  sweeping stale {path}")
        path.unlink()


def run_judge():
    begin = time.time()
    proc = subprocess.run(
        [
            "cargo",
            "test",
            "-p",
            "caly-arch-test",
            "--test",
            "dependency_direction",
            JUDGE,
        ],
        cwd=ROOT,
        env=ENV,
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
        text=True,
        timeout=900,
    )
    return proc, time.time() - begin


def main():
    catalog_original = CATALOG.read_text()
    executor_original = EXECUTOR.read_text()

    if catalog_original.count(M1_OLD) != 1:
        print(f"  FAIL  M1 anchor count={catalog_original.count(M1_OLD)} (want 1)")
        return 1

    all_ok = True
    try:
        # --- M1: must bite ---------------------------------------------------
        backup = ROOT / ".r68bak"
        backup.write_bytes(CATALOG.read_bytes())
        CATALOG.write_text(catalog_original.replace(M1_OLD, M1_NEW, 1))
        proc, elapsed = run_judge()
        if proc.returncode != 0 and "error[E" not in proc.stdout:
            print(f"  ok    M1 production read of the artifact (bite in {elapsed:.1f}s)")
        elif "error[E" in proc.stdout:
            print(f"  FAIL  M1: compiler error, not a property failure ({elapsed:.1f}s)")
            all_ok = False
        else:
            print(f"  FAIL  M1: judge stayed green ({elapsed:.1f}s)")
            all_ok = False
        CATALOG.write_bytes(backup.read_bytes())
        backup.unlink()
        if CATALOG.read_text() != catalog_original:
            print("  FAIL  M1: restore mismatch")
            all_ok = False

        # --- M2: must stay green (naming is not reading) ----------------------
        backup.write_bytes(EXECUTOR.read_bytes())
        EXECUTOR.write_text(executor_original + M2_APPEND)
        proc, elapsed = run_judge()
        if proc.returncode == 0:
            print(f"  ok    M2 naming-only reference (judge stayed green in {elapsed:.1f}s)")
        else:
            print(f"  FAIL  M2: judge went red on a naming-only reference ({elapsed:.1f}s)")
            all_ok = False
        EXECUTOR.write_bytes(backup.read_bytes())
        backup.unlink()
        if EXECUTOR.read_text() != executor_original:
            print("  FAIL  M2: restore mismatch")
            all_ok = False
    finally:
        sweep_strays()
        # hard safety: restore by content if anything above failed mid-way
        if CATALOG.read_text() != catalog_original:
            CATALOG.write_text(catalog_original)
        if EXECUTOR.read_text() != executor_original:
            EXECUTOR.write_text(executor_original)

    if all_ok:
        print("all mutations behaved as predicted: True")
        return 0
    print("all mutations behaved as predicted: False")
    return 1


if __name__ == "__main__":
    sys.exit(main())
