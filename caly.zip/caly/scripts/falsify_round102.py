#!/usr/bin/env python3
"""Round 102 / ADR-056 falsification harness.

Target property: calyd installs a SIGTERM/SIGINT graceful-shutdown surface — on TERM it
gracefully stops the live core (effect runtime `shutdown`) and exits with code 0, instead of
the default signal action (immediate termination by signal 15), which left the core for
next-start crash recovery.

Judges:
  - integration: calyd_wire::sigterm_shuts_calyd_down_gracefully_with_exit_zero
    (spawns the real binary, sends a real SIGTERM, asserts exit code 0 not signal 15).
  - structural: dependency_direction::the_daemon_installs_a_term_signal_handler_that_shuts_the_core_down
    (bin declares the signal module, calls install_term_handler, invokes shutdown; the FFI
    module uses pthread_sigmask + sigwait + exposes install_term_handler).

Mutations (rebuilt; a judge must go red):
  M1 remove the signal handler installation (delete the `signal::install_term_handler(..);` call).
     Bites the INTEGRATION test: without the handler SIGTERM takes its default action and the
     process dies by signal 15 (status.signal() == Some(15), code() != Some(0)). Also bites the
     gate (no install_term_handler call).
  M2 replace the graceful shutdown with a plain exit (drop `.shutdown(..)` inside the handler).
     Bites the STRUCTURAL gate (no `.shutdown(` on the term path) while still exiting 0 —
     proves the gate independently pins the core-stop action, not just the exit code.

Restoration is content sha256-verified. cwd = workspace root.
"""

import hashlib
import pathlib
import shutil
import subprocess
import sys

ROOT = pathlib.Path(__file__).resolve().parents[1]
BIN = ROOT / "crates/caly-daemon/src/bin/calyd.rs"
SUFFIX = ".r102bak"

INTEGRATION = "sigterm_shuts_calyd_down_gracefully_with_exit_zero ... FAILED"
GATE = "the_daemon_installs_a_term_signal_handler_that_shuts_the_core_down ... FAILED"


def sha256(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def cargo(test, binary):
    proc = subprocess.run(
        ["cargo", "test", "-p", "caly-daemon", "--test", binary, test],
        cwd=ROOT, capture_output=True, text=True,
    )
    return proc.stdout + proc.stderr


def cargo_gate():
    proc = subprocess.run(
        ["cargo", "test", "-p", "caly-arch-test", "--test", "dependency_direction",
         "the_daemon_installs"],
        cwd=ROOT, capture_output=True, text=True,
    )
    return proc.stdout + proc.stderr


def main():
    digest = sha256(BIN)
    bak = BIN.with_name(BIN.name + SUFFIX)
    shutil.copy2(str(BIN), str(bak))
    base = bak.read_text()
    ok = True
    try:
        # M1: remove the install call but keep code compiling (drop the handler entirely).
        # Replace the whole `signal::install_term_handler(move || { ... });` statement by an empty
        # block: find the call start and its matching closing `});`.
        marker = "signal::install_term_handler("
        start = base.find(marker)
        assert start != -1, "M1: install call not found"
        # The statement ends at the line that is exactly "    });" after the marker.
        tail = base[start:]
        close_idx = tail.find("});\n")
        assert close_idx != -1, "M1: closing }); not found"
        end = start + close_idx + len("});\n")
        # Determine indentation of the start line for a tidy (compiling) replacement.
        line_start = base.rfind("\n", 0, start) + 1
        indent = base[line_start:start]
        m1 = base[:line_start] + indent + "// M1: term handler removed for falsification\n" + base[end:]
        assert m1 != base and "install_term_handler" not in m1, "M1 replacement failed"
        BIN.write_text(m1)
        integ = cargo("sigterm", "calyd_wire")
        if INTEGRATION in integ:
            print("  BIT  [M1 no-handler]: integration test went red (dies by signal 15)")
        else:
            print("  FAIL [M1 no-handler]: integration stayed green")
            ok = False
        gate_out = cargo_gate()
        if GATE in gate_out:
            print("  BIT  [M1 no-handler]: gate went red (no install_term_handler call)")
        else:
            print("  FAIL [M1 no-handler]: gate stayed green")
            ok = False

        # M2: keep handler + exit but drop the core shutdown inside the closure.
        m2 = base.replace("runtime.shutdown(SHUTDOWN_GRACE_MS)",
                          "let _grace = SHUTDOWN_GRACE_MS; None::<caly_io::ChildExit>")
        assert m2 != base, "M2 anchor not found"
        BIN.write_text(m2)
        gate_out = cargo_gate()
        if GATE in gate_out:
            print("  BIT  [M2 no-shutdown]: gate went red (term path no longer calls shutdown)")
        else:
            print("  FAIL [M2 no-shutdown]: gate stayed green")
            ok = False
        # The integration test stays green (still exits 0) — expected; the gate is what catches M2.
        integ2 = cargo("sigterm", "calyd_wire")
        if INTEGRATION not in integ2:
            print("  ok   [M2 no-shutdown]: integration still green (exit 0 unchanged), as designed")
        else:
            print("  note [M2 no-shutdown]: integration also red (acceptable)")
    finally:
        shutil.move(str(bak), str(BIN))
        got = sha256(BIN)
        assert got == digest, f"restore mismatch: {got} != {digest}"

    if not ok:
        print("ROUND 102 FALSIFICATION: RED (a mutation was not caught)")
        sys.exit(1)
    print("ROUND 102 FALSIFICATION: all mutations BIT; restore sha256-verified.")


if __name__ == "__main__":
    main()
