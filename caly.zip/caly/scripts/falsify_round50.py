"""Falsification harness for round 50 (the negotiated JSON payload encoding, `ADR-034`'s first
slice: flat string-valued JSON objects with the same keys and values the records face carries).

Same discipline as rounds 16/32–49: one mutation per run, exact-anchor replacement with
`assert count == 1`, restore by content and mtime, sha256-verified, stale `*.r50bak` swept at
startup. A mutation that cannot compile proves nothing (`§4.112`). Backups are taken **per
mutation** (`§4.137`).

Six mutations: the daemon ignoring the negotiated encoding for its answers, the JSON encoder
dropping its escaping, the decoder forgiving trailing garbage, the daemon swallowing an
unknown encoding at the handshake, the CLI not negotiating JSON at hello, and the CLI printing
a human rendering under `--json`.

Usage: `python3 scripts/falsify_round50.py` (exit 0 = every mutation bit, every file restored).
"""

import hashlib
import os
import pathlib
import shutil
import subprocess
import sys

ROOT = pathlib.Path("/home/user/caly")
ENV = dict(os.environ)
ENV["PATH"] = str(pathlib.Path.home() / ".cargo/bin") + ":" + ENV.get("PATH", "")
SRC = {
    "daemon": ROOT / "crates/caly-daemon/src/bin/calyd.rs",
    "cli": ROOT / "crates/caly-cli/src/bin/caly.rs",
    "json": ROOT / "crates/caly-ipc/src/json.rs",
}

MUTATIONS = [
    (
        "M1 the daemon ignores the negotiated encoding",
        "daemon",
        """    if json_session {
        caly_ipc::json_from_records(records).into_bytes()""",
        """    if false && json_session {
        caly_ipc::json_from_records(records).into_bytes()""",
        [
            "a_json_session_answers_the_same_facts_as_a_records_session",
            "a_malformed_json_payload_is_refused_in_json_and_the_session_survives",
            "json_output_carries_the_same_facts_the_records_wire_carries",
            "a_json_cli_is_answered_by_a_json_session_end_to_end",
        ],
    ),
    (
        "M2 the JSON encoder drops its escaping",
        "json",
        """            '"' => out.push_str("\\\\\\""),""",
        """            '"' => out.push(ch),""",
        [
            # The unit round-trip judge bites; so does any payload carrying a quote.
        ],
    ),
    (
        "M3 the decoder forgives trailing garbage",
        "json",
        "    if at != bytes.len() {",
        "    if false /* at != bytes.len() */ {",
        [],
    ),
    (
        "M4 an unknown encoding is swallowed as records",
        "daemon",
        "                    None | Some(\"records\") => false,",
        "                    None | Some(_) => false,",
        [
            "an_unknown_encoding_is_refused_by_name_at_the_handshake",
        ],
    ),
    (
        "M5 the CLI never asks for JSON at hello",
        "cli",
        '        records.push(("encoding", "json".to_owned()));',
        "        let _ = json;",
        [
            "json_output_carries_the_same_facts_the_records_wire_carries",
            "a_json_cli_is_answered_by_a_json_session_end_to_end",
        ],
    ),
    (
        "M6 --json prints a human rendering anyway",
        "cli",
        "        Ok(Answer::Records(records)) if json_mode => {",
        "        Ok(Answer::Records(records)) if false => {",
        [
            "json_output_carries_the_same_facts_the_records_wire_carries",
            "a_json_cli_is_answered_by_a_json_session_end_to_end",
        ],
    ),
]

# The unit judges live in the ipc lib target, so mutations M2/M3 also run it.
EXTRA_PACKAGES = ["--lib", "-p", "caly-ipc"]


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def run_cargo():
    proc = subprocess.run(
        [
            "cargo",
            "test",
            "-p",
            "caly-daemon",
            "--test",
            "calyd_wire",
            "-p",
            "caly-cli",
            "--test",
            "caly_cli_e2e",
            "-p",
            "caly-ipc",
            "--lib",
            "--no-fail-fast",
        ],
        cwd=str(ROOT),
        env=ENV,
        capture_output=True,
        text=True,
    )
    out = proc.stdout + proc.stderr
    failed = sorted(
        {
            line[5:].split(" ... ")[0].split("::")[-1].strip()
            for line in out.splitlines()
            if line.startswith("test ") and line.rstrip().endswith("... FAILED")
        }
    )
    return proc.returncode, failed, out


def main():
    for path in ROOT.rglob("*.r50bak"):
        original = pathlib.Path(str(path)[: -len(".r50bak")])
        shutil.move(str(path), str(original))
        print("swept leftover backup:", path.name)

    originals = {name: digest(path) for name, path in SRC.items()}
    results = []
    bad = False
    for label, key, old, new, expected in MUTATIONS:
        path = SRC[key]
        backup = pathlib.Path(str(path) + ".r50bak")
        shutil.copyfile(path, backup)  # per-mutation backup (§4.137)
        s = path.read_text()
        assert s.count(old) == 1, "%s: anchor x%d" % (label, s.count(old))
        try:
            path.write_text(s.replace(old, new, 1))
            code, failed, out = run_cargo()
            red = [name for name in expected if name in failed]
            compile_error = "error[" in out or "could not compile" in out
            # Mutations without named judges (M2/M3) prove themselves by ANY red in the
            # unit target they live next to.
            ok = (bool(red) or (key == "json" and failed)) and not compile_error
            results.append((label, ok))
            print("%-48s %s  red=%s" % (label, "BIT" if ok else "NO EFFECT", red or failed[:4]))
            if not ok:
                if compile_error:
                    print("   !! the mutation did not compile; it proves nothing")
                print("   output tail:\n", out[-1200:])
        finally:
            shutil.move(str(backup), str(path))
            os.utime(path, None)
            assert digest(path) == originals[key], "%s: restore did not reproduce the file" % label

    print("\n== summary ==")
    for label, ok in results:
        print("%-48s %s" % (label, "bit" if ok else "DID NOT BIT"))
        if not ok:
            bad = True
    print("all mutations bit:", not bad)
    sys.exit(1 if bad else 0)


if __name__ == "__main__":
    main()
