#!/usr/bin/env python3
"""Round 98 falsification harness.

Target property: a daemon REFUSAL frame carries a stable public code and the CLI maps it to its
documented exit number (EXIT_CODES.md §4.1), not a blanket PROTO_MISMATCH. `from_wire_refusal_code`
recognises the 14 public ApiError codes (PERMISSION -> 8, CONFIG_INVALID -> 3, TIMEOUT -> 11, ...)
and falls back to PROTO_MISMATCH (13) for frame-loop transport/session codes (USAGE, NOT_FOUND,
HANDSHAKE, ...) and any unknown code. Both refusal consumers in the bin (ask()'s Answer::Refused
and follow's WIRE_KIND_REFUSAL arm) route through it. Request-id correlation (round 94/97) still
runs first.

Judges:
  - exit_code_table::wire_refusal_codes_map_to_their_documented_exit_codes (unit: 14 codes map
    to their exit numbers; transport/unknown codes -> 13);
  - e2e a_permission_refusal_maps_to_exit_8_not_protocol_mismatch (PERMISSION refusal -> 8);
  - e2e a_transport_layer_refusal_code_still_maps_to_protocol_mismatch (NOT_FOUND refusal -> 13);
  - arch gate the_cli_maps_a_wire_refusal_code_to_its_documented_exit_code.

Mutations (build green; a judge bites):
  M1 collapse the mapping so every code falls to PROTO_MISMATCH (find never matches). Bites the
     PERMISSION e2e (gets 13 not 8) and the unit test (public codes all map to 13) and the gate
     (the `.as_str()` recognition disappears).
  M2 hard-code ask()'s refusal back to PROTO_MISMATCH. Bites the PERMISSION e2e (the status verb
     goes through ask) and the gate (only one call site remains).
  M3 change the unknown-code fallback to GENERAL_FAILURE instead of PROTO_MISMATCH. Bites the
     transport e2e (NOT_FOUND gets 1 not 13) and the unit test; the PERMISSION e2e stays green
     (its code is still recognised) — proves the fallback is a real part of the behaviour.

Restoration is content + mtime, sha256-verified. cwd = workspace root.
"""

import hashlib
import os
import pathlib
import shutil
import subprocess
import sys

ROOT = pathlib.Path(__file__).resolve().parents[1]
BIN = ROOT / "crates/caly-cli/src/bin/caly.rs"
LIB = ROOT / "crates/caly-cli/src/exit_code.rs"
SUFFIX = ".r98bak"

PERM = "a_permission_refusal_maps_to_exit_8_not_protocol_mismatch ... FAILED"
TRANSPORT = "a_transport_layer_refusal_code_still_maps_to_protocol_mismatch ... FAILED"
UNIT = "wire_refusal_codes_map_to_their_documented_exit_codes ... FAILED"


def sha256(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def backup(path):
    digest = sha256(path)
    shutil.move(str(path), str(path.with_name(path.name + SUFFIX)))
    return digest


def backup_text(path):
    return path.with_name(path.name + SUFFIX).read_text()


def restore(path, expected):
    shutil.move(str(path.with_name(path.name + SUFFIX)), str(path))
    os.utime(path, None)
    got = sha256(path)
    assert got == expected, f"restore mismatch {path}: {got} != {expected}"


def cargo(args, timeout=400):
    proc = subprocess.run(["cargo", *args], cwd=ROOT, capture_output=True, text=True, timeout=timeout)
    return proc.returncode, proc.stdout + proc.stderr


def build_failed(out):
    return "error[" in out or "could not compile" in out


def judges():
    """Run the refusal e2e + the unit test; return (build_fail, perm_red, transport_red, unit_red)."""
    rc, out = cargo(["test", "-p", "caly-cli", "--test", "caly_cli_e2e", "refusal"])
    if build_failed(out):
        return True, False, False, False, out
    perm_red = PERM in out
    transport_red = TRANSPORT in out
    rc, uout = cargo(["test", "-p", "caly-cli", "--test", "exit_code_table", "wire_refusal"])
    unit_red = UNIT in uout
    red = "FAILED" in out and (perm_red or transport_red)
    return False, perm_red, transport_red, unit_red, out + uout


def gate_result():
    rc, out = cargo(["test", "-p", "caly-arch-test", "--test", "dependency_direction",
                     "the_cli_maps_a_wire_refusal_code"])
    red = "test result: FAILED" in out or "panicked" in out
    return build_failed(out), (not red and "test result: ok" in out), out


def sweep():
    for f in ROOT.glob("crates/**/*.r98bak"):
        f.unlink()


def main():
    sweep()
    bf, perm, trans, unit, out = judges()
    bf_g, gok, gout = gate_result()
    assert not bf and not perm and not trans and not unit, "clean judges must pass:\n" + out[-1500:]
    assert not bf_g and gok, "clean gate must pass:\n" + gout[-1200:]
    print("baseline: refusal-code mapping judges + gate green")

    results = {}

    # M1: collapse the whole mapping to PROTO_MISMATCH (recognition never matches).
    d1 = backup(LIB)
    try:
        t = backup_text(LIB)
        anchor = ".find(|error_code| error_code.as_str() == code)"
        assert t.count(anchor) == 1, f"M1 anchor {t.count(anchor)}"
        LIB.write_text(t.replace(anchor, ".find(|_error_code| false)", 1))
        bf, perm, trans, unit, _ = judges()
        bf_g, gok, gate_out = gate_result()
        # PERMISSION now maps to 13 (e2e + unit red); transport code still 13 (stays correct);
        # gate reds because the `.as_str()` recognition is gone.
        bit = (not bf) and perm and (not trans) and unit and (not bf_g) and (not gok)
        results["M1 collapse-mapping-to-proto-mismatch"] = bit
        print(f"M1: perm_red={perm} trans_red={trans} unit_red={unit} gate_green={gok} -> {bit}")
    finally:
        restore(LIB, d1)

    # M2: hard-code ask()'s refusal back to ProtoMismatch.
    d2 = backup(BIN)
    try:
        t = backup_text(BIN)
        anchor = "exit_code(caly_cli::from_wire_refusal_code(&code))"
        assert t.count(anchor) == 1, f"M2 anchor {t.count(anchor)}"
        BIN.write_text(t.replace(anchor, "exit_code(ExitCode::ProtoMismatch)", 1))
        bf, perm, trans, unit, _ = judges()
        bf_g, gok, gate_out = gate_result()
        # The PERMISSION verb (status -> ask) now exits 13 not 8 -> e2e red; the gate's call-site
        # count drops below 2 -> gate red. Transport codes were already 13, so that e2e stays green.
        bit = (not bf) and perm and (not trans) and (not bf_g) and (not gok)
        results["M2 hardcode-ask-refusal-proto-mismatch"] = bit
        print(f"M2: perm_red={perm} trans_red={trans} unit_red={unit} gate_green={gok} -> {bit}")
    finally:
        restore(BIN, d2)

    # M3: break the unknown-code fallback (GENERAL_FAILURE instead of PROTO_MISMATCH).
    d3 = backup(LIB)
    try:
        t = backup_text(LIB)
        anchor = ".map_or(ExitCode::ProtoMismatch, from_error_code)"
        assert t.count(anchor) == 1, f"M3 anchor {t.count(anchor)}"
        LIB.write_text(t.replace(anchor, ".map_or(ExitCode::GeneralFailure, from_error_code)", 1))
        bf, perm, trans, unit, _ = judges()
        bf_g, gok, gate_out = gate_result()
        # Transport/unknown codes now exit 1 not 13 -> transport e2e + unit red; PERMISSION is
        # still recognised -> that e2e stays green, proving the fallback (not the recognition)
        # is what bit.
        bit = (not bf) and (not perm) and trans and unit
        results["M3 unknown-fallback-general-failure"] = bit
        print(f"M3: perm_red={perm} trans_red={trans} unit_red={unit} gate_green={gok} -> {bit}")
    finally:
        restore(LIB, d3)

    sweep()
    all_bit = all(results.values())
    print(f"\nall mutations bit: {all_bit}")
    for name, bit in results.items():
        print(f"  {'BIT' if bit else 'MISS'}  {name}")
    return 0 if all_bit else 1


if __name__ == "__main__":
    sys.exit(main())
