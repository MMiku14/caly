#!/usr/bin/env python3
"""Round 97 falsification harness.

Target property: the follow OPENED frame (and an open-time REFUSAL) is the follow request's
direct answer, so it must carry the request id the verb sent (REQUEST_ID=1). Round 94 correlated
a one-shot answer by request_id in `ask()`, but follow's opened frame was only checked for
stream_id/resumed (rounds 95/96) — a response with a valid stream but a FOREIGN/missing request
id was accepted as this follow's open. Also, follow sent its request with a literal `1` instead
of the named REQUEST_ID constant (send value and check value as different symbols, the round 94
drift rule).

Fix under test (crates/caly-cli/src/bin/caly.rs):
  - follow sends via request_payload(REQUEST_ID, ..) (was the literal 1);
  - the opened (RESPONSE) arm parses the frame's request_id and refuses `!= Some(REQUEST_ID)`;
  - the follow-path REFUSAL arm does the same before reading the frame as this follow refused.

Judges (caly_cli_e2e.rs fake daemon + real `caly` binary):
  - a_follow_opened_frame_with_a_foreign_request_id_is_refused (opened request_id=999 -> 13);
  - a_follow_opened_frame_with_no_request_id_is_refused (no request_id -> 13);
  - a_follow_opened_frame_with_the_sent_request_id_is_accepted (request_id=1 -> exit 0; anti-vacuity);
  - arch gate the_cli_correlates_the_follow_opened_frame_by_its_request_id.

Mutations (build green; a judge bites):
  M1 drop the opened-frame comparison (parse but accept everything) -> foreign-id and missing-id
     e2e exit 0 and follow the foreign stream + gate red.
  M2 compare against a foreign constant (Some(999)) -> the happy (request_id=1) open is wrongly
     refused, the happy e2e reds (proves the checked id must equal the sent id).
  M3 default a missing id to the sent id (`.or(Some(REQUEST_ID))`) -> the missing-id e2e exits 0;
     foreign-id still refused and happy still green (proves absence is refused, not defaulted).

Restoration is content + mtime, sha256-verified. cwd = workspace root.
"""

import hashlib
import os
import pathlib
import shutil
import subprocess
import sys

ROOT = pathlib.Path(__file__).resolve().parents[1]
CALY = ROOT / "crates/caly-cli/src/bin/caly.rs"
SUFFIX = ".r97bak"

FOREIGN = "a_follow_opened_frame_with_a_foreign_request_id_is_refused ... FAILED"
MISSING = "a_follow_opened_frame_with_no_request_id_is_refused ... FAILED"
HAPPY = "a_follow_opened_frame_with_the_sent_request_id_is_accepted ... FAILED"


def sha256(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def backup(path):
    digest = sha256(path)
    shutil.move(str(path), str(path.with_name(path.name + SUFFIX)))
    return digest


def backup_text(path):
    return path.with_name(path.name + SUFFIX).read_text()


def restore(path, expected):
    shutil.move(str(path.with_name(path.name + SUFFIX)), str(path))
    os.utime(path, None)
    got = sha256(path)
    assert got == expected, f"restore mismatch {path}: {got} != {expected}"


def cargo(args, timeout=400):
    proc = subprocess.run(["cargo", *args], cwd=ROOT, capture_output=True, text=True, timeout=timeout)
    return proc.returncode, proc.stdout + proc.stderr


def build_failed(out):
    return "error[" in out or "could not compile" in out


def e2e_result():
    rc, out = cargo(["test", "-p", "caly-cli", "--test", "caly_cli_e2e", "follow_opened_frame"])
    reds = (FOREIGN in out, MISSING in out, HAPPY in out)
    green = "FAILED" not in out and "test result: ok" in out
    return build_failed(out), green, reds, out


def gate_result():
    rc, out = cargo(["test", "-p", "caly-arch-test", "--test", "dependency_direction",
                     "the_cli_correlates_the_follow_opened_frame_by_its_request_id"])
    red = "test result: FAILED" in out or "panicked" in out
    return build_failed(out), (not red and "test result: ok" in out), out


def sweep():
    for f in ROOT.glob("crates/**/*.r97bak"):
        f.unlink()


def main():
    sweep()
    bf, green, reds, out = e2e_result()
    assert not bf and green and not any(reds), "clean e2e must pass:\n" + out[-1500:]
    bf, gok, out = gate_result()
    assert not bf and gok, "clean gate must pass:\n" + out[-1200:]
    print("baseline: follow opened-frame request_id correlation e2e + gate green")

    results = {}

    # M1: drop the opened-frame comparison (parse but never check).
    d1 = backup(CALY)
    try:
        t = backup_text(CALY)
        anchor = '                if opened_request_id != Some(REQUEST_ID) {\n'
        assert t.count(anchor) == 1, f"M1 anchor {t.count(anchor)}"
        CALY.write_text(t.replace(anchor, '                if false {\n', 1))
        bf, green, reds, _ = e2e_result()
        e2e_bit = (not bf) and (not green) and reds[0] and reds[1] and (not reds[2])
        bf_g, gok, gate_out = gate_result()
        gate_bit = (not bf_g) and (not gok) and "correlates" in gate_out
        results["M1 drop-opened-request-id-check"] = e2e_bit and gate_bit
        print(f"M1: foreign_red={reds[0]} missing_red={reds[1]} happy_red={reds[2]} gate_green={gok} -> {e2e_bit and gate_bit}")
    finally:
        restore(CALY, d1)

    # M2: compare against a foreign constant instead of the sent REQUEST_ID.
    d2 = backup(CALY)
    try:
        t = backup_text(CALY)
        anchor = '                if opened_request_id != Some(REQUEST_ID) {\n'
        assert t.count(anchor) == 1, f"M2 anchor {t.count(anchor)}"
        CALY.write_text(t.replace(anchor, '                if opened_request_id != Some(999) {\n', 1))
        bf, green, reds, _ = e2e_result()
        # The correctly-correlated open (request_id=1) is now wrongly refused -> happy reds.
        bit = (not bf) and (not green) and reds[2]
        results["M2 check-foreign-constant"] = bit
        print(f"M2: foreign_red={reds[0]} missing_red={reds[1]} happy_red={reds[2]} -> {bit}")
    finally:
        restore(CALY, d2)

    # M3: default a missing request id to the sent id (accept absence).
    d3 = backup(CALY)
    try:
        t = backup_text(CALY)
        anchor = (
            '                let opened_request_id =\n'
            '                    wire_field(&records, "request_id").and_then(|value| value.parse::<u64>().ok());\n'
        )
        assert t.count(anchor) == 1, f"M3 anchor {t.count(anchor)}"
        mutant = (
            '                let opened_request_id =\n'
            '                    wire_field(&records, "request_id")\n'
            '                        .and_then(|value| value.parse::<u64>().ok())\n'
            '                        .or(Some(REQUEST_ID)); // MUTANT: a missing id silently matches\n'
        )
        CALY.write_text(t.replace(anchor, mutant, 1))
        bf, green, reds, _ = e2e_result()
        # A frame with NO request_id now passes (missing judge reds); foreign (999) still refused
        # and happy (1) still green — proves absence is refused, not defaulted.
        bit = (not bf) and reds[1] and (not reds[0]) and (not reds[2])
        results["M3 missing-id-default-accepted"] = bit
        print(f"M3: foreign_red={reds[0]} missing_red={reds[1]} happy_red={reds[2]} -> {bit}")
    finally:
        restore(CALY, d3)

    sweep()
    all_bit = all(results.values())
    print(f"\nall mutations bit: {all_bit}")
    for name, bit in results.items():
        print(f"  {'BIT' if bit else 'MISS'}  {name}")
    return 0 if all_bit else 1


if __name__ == "__main__":
    sys.exit(main())
