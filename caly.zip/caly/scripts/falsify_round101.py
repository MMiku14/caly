#!/usr/bin/env python3
"""Round 101 falsification harness.

Target property: the shipped systemd unit (packaging/systemd/calyd.service, delivered round 100
/ ADR-055) is a Type=simple, externally-supervised (Restart=, enableable) calyd process that
binds a UDS, explicitly opts into the real effect runtime with both required paths, and — most
importantly — does NOT launch the proxy core (mihomo/sing-box) as a systemd-managed process (the
core is supervised by calyd's Core Supervisor inside apply transactions; RFC-0005 §11.2 / ADR-055).

The doc gate (every_documented_path_reference_resolves) only proves the runbook points at a file
that EXISTS; this arch gate judges its CONTENT.

Judge: dependency_direction::the_systemd_unit_is_a_foreground_managed_calyd_supervising_the_core.

Mutations (each turns the unit into a plausible-but-wrong deployment; the gate must go red):
  M1 drop the auto-restart (Restart=on-failure -> Restart=no): systemd no longer supervises calyd
     on crash, defeating the whole point of external supervision (RFC-0005 §12 recovery trigger).
  M2 drop the real runtime to simulated in the shipped production unit (or a real flag): the unit
     silently stops managing the proxy — an operator enabling it gets a no-op daemon.
  M3 launch mihomo as its own systemd ExecStartPre process: violates the two-layer supervision
     boundary (the core must stay calyd's child, not an init-managed process).

Restoration is content sha256-verified. cwd = workspace root.
"""

import hashlib
import pathlib
import shutil
import subprocess
import sys

ROOT = pathlib.Path(__file__).resolve().parents[1]
UNIT = ROOT / "packaging" / "systemd" / "calyd.service"
SUFFIX = ".r101bak"
GATE = "the_systemd_unit_is_a_foreground_managed_calyd_supervising_the_core ... FAILED"


def sha256(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def run_gate():
    proc = subprocess.run(
        [
            "cargo", "test", "-p", "caly-arch-test", "--test",
            "dependency_direction",
            "the_systemd_unit_is_a_foreground_managed_calyd_supervising_the_core",
            "--", "--exact",
        ],
        cwd=ROOT, capture_output=True, text=True,
    )
    return proc.stdout + proc.stderr


def main():
    digest = sha256(UNIT)
    bak = UNIT.with_name(UNIT.name + SUFFIX)
    shutil.copy2(str(UNIT), str(bak))
    base = bak.read_text()
    ok = True
    try:
        mutations = [
            (
                "M1 no-auto-restart",
                base.replace("Restart=on-failure", "Restart=no"),
            ),
            (
                "M2 production-unit-runs-simulated",
                base.replace("--effect-runtime real", "--effect-runtime simulated"),
            ),
            (
                "M3 core-launched-as-systemd-process",
                base.replace(
                    "ExecStart=/usr/bin/calyd",
                    "ExecStartPre=/usr/bin/mihomo -d /var/lib/mihomo\nExecStart=/usr/bin/calyd",
                ),
            ),
        ]
        for name, mutated in mutations:
            assert mutated != base, f"{name}: anchor not found"
            UNIT.write_text(mutated)
            out = run_gate()
            if GATE in out:
                print(f"  BIT  [{name}]: gate went red")
            else:
                print(f"  FAIL [{name}]: gate stayed GREEN (mutation not caught)")
                ok = False
    finally:
        shutil.move(str(bak), str(UNIT))
        got = sha256(UNIT)
        assert got == digest, f"restore mismatch: {got} != {digest}"

    if not ok:
        print("ROUND 101 FALSIFICATION: RED (a mutation was not caught)")
        sys.exit(1)
    print("ROUND 101 FALSIFICATION: all mutations BIT; restore sha256-verified.")


if __name__ == "__main__":
    main()
