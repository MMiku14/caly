"""Falsification harness for round 39 (`ADR-041`: injective record-name escaping at the store).

Same discipline as rounds 16/32–38: one mutation per run, exact-anchor replacement with
`assert count == 1`, restore by content and mtime, sha256-verified, stale `*.r39bak` swept at
startup. A mutation that cannot compile proves nothing (`§4.112`).

The four mutations walk the escaping's failure modes: the flattening revert (two names, one
file — the original silent-overwrite/alias defect), the boot name check disarmed (legacy or
forged names load again), a *partial* escape that keeps the old collapse for one character
(injectivity lost quietly, not all at once), and the `%` escape dropped so a literal name can
masquerade as an escaped one.

Usage: `python3 scripts/falsify_round39.py` (exit 0 = every mutation bit, every file restored).
"""

import hashlib
import os
import pathlib
import shutil
import subprocess
import sys

ROOT = pathlib.Path("/home/user/caly")
ENV = dict(os.environ)
ENV["PATH"] = str(pathlib.Path.home() / ".cargo/bin") + ":" + ENV.get("PATH", "")
SRC = ROOT / "crates/caly-storage/src/fs_store.rs"

MUTATIONS = [
    (
        "M1 the flattening returns: specials all to '_'",
        """            '%' => out.push_str("%25"),
            '/' => out.push_str("%2F"),
            '\\\\' => out.push_str("%5C"),
            ':' => out.push_str("%3A"),
            ' ' => out.push_str("%20"),
            '.' => out.push_str("%2E"),
            other => out.push(other),""",
        """            '%' | '/' | '\\\\' | ':' | ' ' | '.' => out.push('_'),
            other => out.push(other),""",
        [
            "sibling_names_that_an_escaping_must_tell_apart_are_not_aliases",
            "sibling_puts_coexist_and_survive_the_restart_on_the_durable_backend",
        ],
    ),
    (
        "M2 the boot name check is disarmed",
        "            if stem != Some(escape_component(&object.digest.0).as_str()) {",
        "            if false && stem != Some(escape_component(&object.digest.0).as_str()) {",
        ["boot_refuses_a_record_whose_file_name_its_digest_would_not_occupy"],
    ),
    (
        "M3 a partial escape keeps the old collapse for ':'",
        """            ':' => out.push_str("%3A"),""",
        """            ':' => out.push('_'),""",
        [
            "sibling_names_that_an_escaping_must_tell_apart_are_not_aliases",
            "sibling_puts_coexist_and_survive_the_restart_on_the_durable_backend",
        ],
    ),
    (
        "M4 the '%' escape drops: literals can masquerade",
        """            '%' => out.push_str("%25"),
""",
        "",
        ["sibling_puts_coexist_and_survive_the_restart_on_the_durable_backend"],
    ),
]


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def run_cargo():
    proc = subprocess.run(
        ["cargo", "test", "-p", "caly-storage", "--no-fail-fast"],
        cwd=str(ROOT),
        env=ENV,
        capture_output=True,
        text=True,
    )
    out = proc.stdout + proc.stderr
    failed = sorted(
        {
            line[5:].split(" ... ")[0].split("::")[-1].strip()
            for line in out.splitlines()
            if line.startswith("test ") and line.rstrip().endswith("... FAILED")
        }
    )
    return proc.returncode, failed, out


def main():
    for path in ROOT.rglob("*.r39bak"):
        original = pathlib.Path(str(path)[: -len(".r39bak")])
        shutil.move(str(path), str(original))
        print("swept leftover backup:", path.name)

    original = digest(SRC)
    results = []
    bad = False
    for label, old, new, expected in MUTATIONS:
        s = SRC.read_text()
        assert s.count(old) == 1, "%s: anchor x%d" % (label, s.count(old))
        backup = pathlib.Path(str(SRC) + ".r39bak")
        shutil.copyfile(SRC, backup)
        try:
            SRC.write_text(s.replace(old, new, 1))
            code, failed, out = run_cargo()
            red = [name for name in expected if name in failed]
            compile_error = "error[" in out or "could not compile" in out
            ok = bool(red) and not compile_error
            results.append((label, ok))
            print("%-52s %s  red=%s" % (label, "BIT" if ok else "NO EFFECT", red or failed[:4]))
            if not ok:
                if compile_error:
                    print("   !! the mutation did not compile; it proves nothing")
                print("   output tail:\n", out[-1200:])
        finally:
            shutil.move(str(backup), str(SRC))
            os.utime(SRC, None)
            assert digest(SRC) == original, "%s: restore did not reproduce the file" % label

    print("\n== summary ==")
    for label, ok in results:
        print("%-52s %s" % (label, "bit" if ok else "DID NOT BIT"))
        if not ok:
            bad = True
    print("all mutations bit:", not bad)
    sys.exit(1 if bad else 0)


if __name__ == "__main__":
    main()
