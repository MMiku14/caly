#!/usr/bin/env python3
"""Round 94 falsification harness.

Target property: the CLI correlates every one-shot answer with the request it sent — a
RESPONSE/REFUSAL frame is only THIS verb's answer when its `request_id` equals the id the verb
sent. A frame with a foreign id OR no id at all is a protocol disagreement (exit 13), not an
answer to print. The CLI used to accept a frame purely on its kind — the request/answer twin of
the handshake hole round 71 closed ("believe the kind, never read the content").

Fix under test (crates/caly-cli/src/bin/caly.rs):
  - `const REQUEST_ID: u64 = 1`, sent via `request_payload(REQUEST_ID, ..)`;
  - in `ask`, the answer's `request_id` record is parsed and must equal `Some(REQUEST_ID)`;
    a foreign id or an absent/unparseable id is an error -> exit 13.

Judges (all in caly_cli_e2e.rs, fake daemon + real `caly` binary):
  - a_response_with_a_foreign_request_id_is_refused_not_printed_as_the_answer (answers id 999 -> 13);
  - a_response_with_no_request_id_is_refused_not_printed_as_the_answer (no id record -> 13);
  - a_response_with_the_sent_request_id_is_accepted (id 1 -> exit 0; anti-vacuity);
  - arch gate the_cli_correlates_each_answer_with_its_request_id.

Mutations (build stays green; a judge bites):
  M1 (drop the comparison): parse+if replaced by a no-op. Bites the foreign-id e2e (exits 0 and
     prints the stale frame) AND the arch gate (no answer_id check).
  M2 (check a foreign constant): compare against Some(999) instead of the sent REQUEST_ID. Bites
     the in-range happy judge (id 1 wrongly refused) — proves the checked id must equal the sent id.
  M3 (accept a missing id): `.or(Some(REQUEST_ID))` on the parsed id. Bites the missing-id e2e
     (a frame with no id record exits 0 and prints) — proves absence is refused, not defaulted.

Restoration is content + mtime, sha256-verified. cwd = workspace root.
"""

import hashlib
import os
import pathlib
import shutil
import subprocess
import sys

ROOT = pathlib.Path(__file__).resolve().parents[1]
CALY = ROOT / "crates/caly-cli/src/bin/caly.rs"
SUFFIX = ".r94bak"

FOREIGN = "a_response_with_a_foreign_request_id_is_refused_not_printed_as_the_answer ... FAILED"
MISSING = "a_response_with_no_request_id_is_refused_not_printed_as_the_answer ... FAILED"
SENT = "a_response_with_the_sent_request_id_is_accepted ... FAILED"


def sha256(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def backup(path):
    digest = sha256(path)
    shutil.move(str(path), str(path.with_name(path.name + SUFFIX)))
    return digest


def backup_text(path):
    return path.with_name(path.name + SUFFIX).read_text()


def restore(path, expected):
    shutil.move(str(path.with_name(path.name + SUFFIX)), str(path))
    os.utime(path, None)
    got = sha256(path)
    assert got == expected, f"restore mismatch {path}: {got} != {expected}"


def cargo(args, timeout=400):
    proc = subprocess.run(
        ["cargo", *args], cwd=ROOT, capture_output=True, text=True, timeout=timeout
    )
    return proc.returncode, proc.stdout + proc.stderr


def build_failed(out):
    return "error[" in out or "could not compile" in out


def e2e_result():
    rc, out = cargo(["build", "-p", "caly-cli", "--bin", "caly"])
    if build_failed(out):
        return True, False, (False, False, False), out
    rc, out = cargo(
        ["test", "-p", "caly-cli", "--test", "caly_cli_e2e", "request_id"]
    )
    reds = (FOREIGN in out, MISSING in out, SENT in out)
    green = "FAILED" not in out and "test result: ok" in out
    return False, green, reds, out


def gate_result():
    rc, out = cargo(
        ["test", "-p", "caly-arch-test", "--test", "dependency_direction",
         "the_cli_correlates_each_answer_with_its_request_id"]
    )
    red = "test result: FAILED" in out or "panicked" in out
    return build_failed(out), (not red and "test result: ok" in out), out


def sweep():
    for f in ROOT.glob("crates/**/*.r94bak"):
        f.unlink()


def main():
    sweep()
    bf, green, reds, out = e2e_result()
    assert not bf and green, "clean e2e must pass:\n" + out[-1500:]
    bf, gok, out = gate_result()
    assert not bf and gok, "clean gate must pass:\n" + out[-1200:]
    print("baseline: request-id correlation e2e + gate green")

    results = {}

    # M1: drop the comparison entirely.
    d1 = backup(CALY)
    try:
        t = backup_text(CALY)
        old = (
            '    let answer_id = wire_field(&records, "request_id").and_then(|value| value.parse::<u64>().ok());\n'
            "    if answer_id != Some(REQUEST_ID) {\n"
            "        return Err(format!(\n"
            '            "the daemon answered request id {:?}, but this verb sent {REQUEST_ID} — a mismatched \\\n'
            '             frame is not the answer (PROTO_MISMATCH)",\n'
            "            answer_id\n"
            "        ));\n"
            "    }\n"
        )
        new = "    let _answer_id = (); // MUTANT: correlation check removed\n"
        assert t.count(old) == 1, f"M1 anchor {t.count(old)}"
        CALY.write_text(t.replace(old, new, 1))
        bf, green, reds, _ = e2e_result()
        e2e_bit = (not bf) and (not green) and reds[0] and reds[1]
        bf_g, gok, gate_out = gate_result()
        # The gate reds when ask no longer compares the answer id to REQUEST_ID.
        gate_bit = (not bf_g) and (not gok) and "correlates" in gate_out
        bit = e2e_bit and gate_bit
        results["M1 drop-correlation-check"] = bit
        print(f"M1: e2e foreign_red={reds[0]} missing_red={reds[1]} (bit={e2e_bit}) | "
              f"gate_green={gok} (bit={gate_bit}) -> {bit}")
    finally:
        restore(CALY, d1)

    # M2: check a foreign constant (999) instead of the sent id.
    d2 = backup(CALY)
    try:
        t = backup_text(CALY)
        old = "    if answer_id != Some(REQUEST_ID) {\n"
        new = "    if answer_id != Some(999) { // MUTANT: compare a foreign constant, not the sent id\n"
        assert t.count(old) == 1, f"M2 anchor {t.count(old)}"
        CALY.write_text(t.replace(old, new, 1))
        bf, green, reds, _ = e2e_result()
        # The in-range answer (id 1) is now wrongly refused -> the happy judge reds.
        bit = (not bf) and (not green) and reds[2]
        results["M2 check-foreign-constant"] = bit
        print(f"M2: sent_red={reds[2]} foreign_red={reds[0]} (bit={bit}) -> {bit}")
    finally:
        restore(CALY, d2)

    # M3: default a missing/unparseable id to the sent id (accept absence).
    d3 = backup(CALY)
    try:
        t = backup_text(CALY)
        old = (
            '    let answer_id = wire_field(&records, "request_id").and_then(|value| value.parse::<u64>().ok());\n'
        )
        new = (
            '    let answer_id = wire_field(&records, "request_id")\n'
            "        .and_then(|value| value.parse::<u64>().ok())\n"
            "        .or(Some(REQUEST_ID)); // MUTANT: a missing id silently matches\n"
        )
        assert t.count(old) == 1, f"M3 anchor {t.count(old)}"
        CALY.write_text(t.replace(old, new, 1))
        bf, green, reds, _ = e2e_result()
        # A frame with NO id record now passes (missing judge reds); the foreign (999) frame is
        # still refused (present-but-wrong) — that judge must stay green-on-correctly-red.
        bit = (not bf) and reds[1] and (not reds[0]) and (not reds[2])
        results["M3 missing-id-default-accepted"] = bit
        print(f"M3: missing_red={reds[1]} foreign_red={reds[0]} sent_red={reds[2]} (bit={bit}) -> {bit}")
    finally:
        restore(CALY, d3)

    sweep()
    all_bit = all(results.values())
    print(f"\nall mutations bit: {all_bit}")
    for name, bit in results.items():
        print(f"  {'BIT' if bit else 'MISS'}  {name}")
    return 0 if all_bit else 1


if __name__ == "__main__":
    sys.exit(main())
