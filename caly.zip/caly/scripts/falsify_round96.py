#!/usr/bin/env python3
"""Round 96 falsification harness.

Target property: the follow/reconnect path closes its last two stream-correlation gaps.

(1) RESUME — `caly follow --resume <id>` names the stream to reconnect. The opened frame must
echo that SAME stream id AND flag `resumed=true`; a frame for a different stream, or a matching
id flagged as a fresh open, is a protocol disagreement (exit 13), not a successful resume.

(2) ACK CONFIRMATION — after the client sends a STREAM_ACK naming a stream, the daemon's
confirmation (RESPONSE) must name that SAME stream. A confirmation for a different stream that
merely echoes a matching `acked_upto` is not proof this stream's cursor landed.

Fix under test (crates/caly-cli/src/bin/caly.rs):
  - follow_stream captures `resume_expect = resume`; in the opened arm, `if let Some(expected) =
    resume_expect` refuses `stream_id != expected` and `resumed != "true"`;
  - ack_and_confirm reads the confirmation's `stream_id` into `confirmed_stream` and refuses
    `confirmed_stream != stream_id`.

Judges (caly_cli_e2e.rs fake daemon + real `caly` binary):
  - a_resume_opening_a_different_stream_is_refused (resume 7, opened id 9 resumed=true -> 13);
  - a_resume_opened_without_the_resumed_flag_is_refused (resume 7, opened id 7 resumed=false -> 13);
  - a_resume_opening_the_requested_stream_flagged_resumed_is_accepted (id 7 resumed=true -> 0);
  - an_ack_confirmation_for_a_different_stream_is_refused (follow 7, ack confirmed for 9 -> 13);
  - arch gate the_cli_correlates_resumes_and_ack_confirmations_to_their_stream.

Mutations (build green; a judge bites):
  M1 drop the resume stream_id check  -> resume-different-id e2e exits 0 + gate red.
  M2 drop the resumed-flag check      -> resume-not-flagged e2e exits 0 + gate red (different-id
     e2e still refused; accepted happy still green — proves the flag half independently).
  M3 drop the ack-confirmation stream_id check -> foreign-confirmation e2e exits 0 + gate red
     (resume e2es unaffected — proves the confirmation half independently).

Restoration is content + mtime, sha256-verified. cwd = workspace root.
"""

import hashlib
import os
import pathlib
import shutil
import subprocess
import sys

ROOT = pathlib.Path(__file__).resolve().parents[1]
CALY = ROOT / "crates/caly-cli/src/bin/caly.rs"
SUFFIX = ".r96bak"

RDIFF = "a_resume_opening_a_different_stream_is_refused ... FAILED"
RFLAG = "a_resume_opened_without_the_resumed_flag_is_refused ... FAILED"
RHAPPY = "a_resume_opening_the_requested_stream_flagged_resumed_is_accepted ... FAILED"
ACKDIFF = "an_ack_confirmation_for_a_different_stream_is_refused ... FAILED"


def sha256(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def backup(path):
    digest = sha256(path)
    shutil.move(str(path), str(path.with_name(path.name + SUFFIX)))
    return digest


def backup_text(path):
    return path.with_name(path.name + SUFFIX).read_text()


def restore(path, expected):
    shutil.move(str(path.with_name(path.name + SUFFIX)), str(path))
    os.utime(path, None)
    got = sha256(path)
    assert got == expected, f"restore mismatch {path}: {got} != {expected}"


def cargo(args, timeout=400):
    proc = subprocess.run(["cargo", *args], cwd=ROOT, capture_output=True, text=True, timeout=timeout)
    return proc.returncode, proc.stdout + proc.stderr


def build_failed(out):
    return "error[" in out or "could not compile" in out


def e2e_result():
    rc, out = cargo(["build", "-p", "caly-cli", "--bin", "caly"])
    if build_failed(out):
        return True, False, (False, False, False, False), out
    rc, out = cargo(["test", "-p", "caly-cli", "--test", "caly_cli_e2e"])
    reds = (RDIFF in out, RFLAG in out, RHAPPY in out, ACKDIFF in out)
    green = "FAILED" not in out and "test result: ok" in out
    return False, green, reds, out


def gate_result():
    rc, out = cargo(["test", "-p", "caly-arch-test", "--test", "dependency_direction",
                     "the_cli_correlates_resumes_and_ack_confirmations_to_their_stream"])
    red = "test result: FAILED" in out or "panicked" in out
    return build_failed(out), (not red and "test result: ok" in out), out


def sweep():
    for f in ROOT.glob("crates/**/*.r96bak"):
        f.unlink()


def main():
    sweep()
    bf, green, reds, out = e2e_result()
    assert not bf and green and not any(reds), "clean e2e must pass:\n" + out[-1500:]
    bf, gok, out = gate_result()
    assert not bf and gok, "clean gate must pass:\n" + out[-1200:]
    print("baseline: resume + ack-confirmation correlation e2e + gate green")

    results = {}

    # M1: drop the resume stream_id comparison (leave the resumed-flag check).
    d1 = backup(CALY)
    try:
        t = backup_text(CALY)
        old = (
            '                    if stream_id != expected {\n'
            '                        return Err(format!(\n'
        )
        new = (
            '                    if false {\n'
            '                        return Err(format!(\n'
        )
        assert t.count(old) == 1, f"M1 anchor {t.count(old)}"
        CALY.write_text(t.replace(old, new, 1))
        bf, green, reds, _ = e2e_result()
        # resume-different-id now accepted (exits 0) -> that e2e reds; flag e2e (id matches) still
        # refused; happy (matches) still green; ack e2e unaffected.
        e2e_bit = (not bf) and (not green) and reds[0] and (not reds[1]) and (not reds[2]) and (not reds[3])
        bf_g, gok, gate_out = gate_result()
        gate_bit = (not bf_g) and (not gok) and "correlates" in gate_out
        results["M1 drop-resume-id-check"] = e2e_bit and gate_bit
        print(f"M1: rdiff_red={reds[0]} rflag_red={reds[1]} rhappy_red={reds[2]} ack_red={reds[3]} "
              f"gate_green={gok} -> {e2e_bit and gate_bit}")
    finally:
        restore(CALY, d1)

    # M2: drop the resumed-flag comparison (leave the stream_id check).
    d2 = backup(CALY)
    try:
        t = backup_text(CALY)
        old = '                    if resumed != "true" {\n'
        new = '                    if false {\n'
        assert t.count(old) == 1, f"M2 anchor {t.count(old)}"
        CALY.write_text(t.replace(old, new, 1))
        bf, green, reds, _ = e2e_result()
        # resume-not-flagged now accepted (exits 0) -> that e2e reds; different-id still refused
        # (id mismatch check intact); happy still green; ack unaffected.
        e2e_bit = (not bf) and (not green) and reds[1] and (not reds[0]) and (not reds[2]) and (not reds[3])
        bf_g, gok, gate_out = gate_result()
        gate_bit = (not bf_g) and (not gok) and "correlates" in gate_out
        results["M2 drop-resumed-flag-check"] = e2e_bit and gate_bit
        print(f"M2: rdiff_red={reds[0]} rflag_red={reds[1]} rhappy_red={reds[2]} ack_red={reds[3]} "
              f"gate_green={gok} -> {e2e_bit and gate_bit}")
    finally:
        restore(CALY, d2)

    # M3: drop the ack-confirmation stream_id comparison (leave the acked_upto check).
    d3 = backup(CALY)
    try:
        t = backup_text(CALY)
        old = '    if confirmed_stream != stream_id {\n'
        new = '    if false {\n'
        assert t.count(old) == 1, f"M3 anchor {t.count(old)}"
        CALY.write_text(t.replace(old, new, 1))
        bf, green, reds, _ = e2e_result()
        # the foreign-stream confirmation is now trusted -> the follow exits 0 instead of 13, so
        # the ack e2e reds; all resume e2es unaffected.
        e2e_bit = (not bf) and (not green) and reds[3] and not any(reds[:3])
        bf_g, gok, gate_out = gate_result()
        gate_bit = (not bf_g) and (not gok) and "correlates" in gate_out
        results["M3 drop-ack-confirmation-id-check"] = e2e_bit and gate_bit
        print(f"M3: rdiff_red={reds[0]} rflag_red={reds[1]} rhappy_red={reds[2]} ack_red={reds[3]} "
              f"gate_green={gok} -> {e2e_bit and gate_bit}")
    finally:
        restore(CALY, d3)

    sweep()
    all_bit = all(results.values())
    print(f"\nall mutations bit: {all_bit}")
    for name, bit in results.items():
        print(f"  {'BIT' if bit else 'MISS'}  {name}")
    return 0 if all_bit else 1


if __name__ == "__main__":
    sys.exit(main())
