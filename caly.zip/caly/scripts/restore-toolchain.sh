#!/bin/bash
# Restore cargo/rustup after sandbox snapshot wipes ~/.rustup and shims.
set -e
chmod +x "$HOME/.cargo/bin/"* 2>/dev/null || true
if ! "$HOME/.cargo/bin/cargo" --version >/dev/null 2>&1; then
  if "$HOME/.cargo/bin/rustup" toolchain list 2>/dev/null | grep -q '1.88.0'; then
    "$HOME/.cargo/bin/rustup" default 1.88.0 >/dev/null
  else
    "$HOME/.cargo/bin/rustup" toolchain install 1.88.0 --profile minimal --component clippy >/dev/null 2>&1
    "$HOME/.cargo/bin/rustup" default 1.88.0 >/dev/null
  fi
fi
if ! "$HOME/.cargo/bin/cargo" clippy --version >/dev/null 2>&1; then
  "$HOME/.cargo/bin/rustup" component add clippy >/dev/null 2>&1
fi
"$HOME/.cargo/bin/cargo" --version
