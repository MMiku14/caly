#!/usr/bin/env python3
"""Round 95 falsification harness.

Target property: the CLI correlates every follow-stream frame with the stream it opened — a
STREAM_DATA / STREAM_END frame is only THIS follow's data/verdict when its `stream_id` equals the
id the opened frame named. The wire multiplexes streams per session (the typed state machine in
`caly_ipc::client` rejects an unknown stream id from its `streams` table), so a frame for a
different stream can legally arrive; the hand-written follow path used to believe the frame kind
and never read `stream_id` — a foreign stream's events printed as this job's and a foreign end's
`outcome` set the exit code. This is the stream-shaped cousin of the request_id hole round 94
closed on the request/answer path.

Fix under test (crates/caly-cli/src/bin/caly.rs):
  - `follow_stream` captures the opened frame's stream_id into `opened_stream` (an opened frame
    with no id is refused);
  - the STREAM_DATA and STREAM_END arms call `stream_frame_id_matches(&records, opened)`;
  - `stream_frame_id_matches` accepts only `frame_id == opened`; a foreign id or a frame with no
    id / before any opened frame is a PROTO_MISMATCH error -> exit 13.

Judges (all in caly_cli_e2e.rs, fake daemon + real `caly` binary):
  - a_follow_data_frame_with_a_foreign_stream_id_is_refused_not_printed (opened 7, data 999 -> 13,
    foreign event not printed);
  - a_follow_end_frame_with_a_foreign_stream_id_does_not_set_the_verdict (opened 7, data 7,
    end 999 Succeeded -> 13, not exit 0);
  - a_follow_data_and_end_with_the_opened_stream_id_are_accepted (7 data + 7 Succeeded end -> 0;
    anti-vacuity);
  - arch gate the_cli_correlates_each_follow_frame_with_its_opened_stream_id.

Mutations (build stays green; a judge bites):
  M1 (drop the comparison): the helper returns Ok(()) unconditionally. Bites the foreign-data and
     foreign-end e2e (they exit 0 / print) AND the arch gate (no frame_id == opened comparison).
  M2 (accept a missing id): add a guard mapping an absent frame id to a pass. Bites the missing-id
     shape — proved structurally: the gate pins the exact acceptance arm `frame_id == opened`, so
     a mutant that also accepts `(None, _)` reds the gate (no dedicated missing-id e2e; a frame
     always carries stream_id over the wire, and the pre-opened case is a daemon-impossible
     ordering — the guard exists purely to fail closed).
  M3 (drop the end-frame correlation only): remove the STREAM_END call. Bites the foreign-end e2e
     (a foreign Succeeded end sets verdict 0) but NOT the foreign-data e2e (data still correlated)
     — proves the verdict path is covered, not just the print path.

Restoration is content + mtime, sha256-verified. cwd = workspace root.
"""

import hashlib
import os
import pathlib
import shutil
import subprocess
import sys

ROOT = pathlib.Path(__file__).resolve().parents[1]
CALY = ROOT / "crates/caly-cli/src/bin/caly.rs"
GATE = ROOT / "crates/caly-arch-test/tests/dependency_direction.rs"
SUFFIX = ".r95bak"

FDATA = "a_follow_data_frame_with_a_foreign_stream_id_is_refused_not_printed ... FAILED"
FEND = "a_follow_end_frame_with_a_foreign_stream_id_does_not_set_the_verdict ... FAILED"
HAPPY = "a_follow_data_and_end_with_the_opened_stream_id_are_accepted ... FAILED"


def sha256(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def backup(path):
    digest = sha256(path)
    shutil.move(str(path), str(path.with_name(path.name + SUFFIX)))
    return digest


def backup_text(path):
    return path.with_name(path.name + SUFFIX).read_text()


def restore(path, expected):
    shutil.move(str(path.with_name(path.name + SUFFIX)), str(path))
    os.utime(path, None)
    got = sha256(path)
    assert got == expected, f"restore mismatch {path}: {got} != {expected}"


def cargo(args, timeout=400):
    proc = subprocess.run(
        ["cargo", *args], cwd=ROOT, capture_output=True, text=True, timeout=timeout
    )
    return proc.returncode, proc.stdout + proc.stderr


def build_failed(out):
    return "error[" in out or "could not compile" in out


def e2e_result():
    rc, out = cargo(["build", "-p", "caly-cli", "--bin", "caly"])
    if build_failed(out):
        return True, False, (False, False, False), out
    rc, out = cargo(
        ["test", "-p", "caly-cli", "--test", "caly_cli_e2e", "stream_id"]
    )
    reds = (FDATA in out, FEND in out, HAPPY in out)
    green = "FAILED" not in out and "test result: ok" in out
    return False, green, reds, out


def gate_result():
    rc, out = cargo(
        [
            "test",
            "-p", "caly-arch-test",
            "--test", "dependency_direction",
            "the_cli_correlates_each_follow_frame_with_its_opened_stream_id",
        ]
    )
    red = "test result: FAILED" in out or "panicked" in out
    return build_failed(out), (not red and "test result: ok" in out), out


def sweep():
    for f in ROOT.glob("crates/**/*.r95bak"):
        f.unlink()


def main():
    sweep()
    bf, green, reds, out = e2e_result()
    assert not bf and green and not any(reds), "clean e2e must pass:\n" + out[-1500:]
    bf, gok, out = gate_result()
    assert not bf and gok, "clean gate must pass:\n" + out[-1200:]
    print("baseline: follow stream-id correlation e2e + gate green")

    results = {}

    # M1: the correlation helper always accepts (the whole comparison removed, not shadowed by
    # dead code — a mutant that leaves the old match after an early `return Ok(())` keeps the
    # `frame_id == opened` text in dead code and fools a substring gate, the round 94 lesson).
    d1 = backup(CALY)
    try:
        t = backup_text(CALY)
        anchor = (
            "    let frame_id = wire_field(records, \"stream_id\");\n"
            "    match (frame_id, opened) {\n"
            "        (Some(frame_id), Some(opened)) if frame_id == opened => Ok(()),\n"
            "        (Some(frame_id), Some(opened)) => Err(format!(\n"
            "            \"the daemon sent a stream frame for stream {frame_id}, but this follow opened \\\n"
            "             {opened} - a different stream frame is not this stream's data or verdict \\\n"
            "             (PROTO_MISMATCH)\",\n"
            "        )),\n"
            "        (frame_id, _) => Err(format!(\n"
            "            \"a stream frame arrived with no correlated stream id ({frame_id:?}) before the \\\n"
            "             opened frame named one - refusing to treat it as this stream (PROTO_MISMATCH)\",\n"
            "        )),\n"
            "    }\n"
        )
        mutant = (
            "    let _frame_id = wire_field(records, \"stream_id\"); // MUTANT: read but not compared\n"
            "    let _ = opened;\n"
            "    Ok(()) // MUTANT: stream correlation removed — every frame accepted\n"
        )
        assert t.count(anchor) == 1, f"M1 anchor {t.count(anchor)}"
        CALY.write_text(t.replace(anchor, mutant, 1))
        bf, green, reds, _ = e2e_result()
        e2e_bit = (not bf) and (not green) and reds[0] and reds[1] and (not reds[2])
        bf_g, gok, gate_out = gate_result()
        gate_bit = (not bf_g) and (not gok) and "correlates" in gate_out
        bit = e2e_bit and gate_bit
        results["M1 drop-correlation"] = bit
        print(
            f"M1: e2e foreign_data_red={reds[0]} foreign_end_red={reds[1]} happy_red={reds[2]} "
            f"(e2e_bit={e2e_bit}) | gate_green={gok} (gate_bit={gate_bit}) -> {bit}"
        )
    finally:
        restore(CALY, d1)

    # M2: accept a frame with no stream id as correlated (missing id defaulted).
    d2 = backup(CALY)
    try:
        t = backup_text(CALY)
        anchor = "        (Some(frame_id), Some(opened)) if frame_id == opened => Ok(()),\n"
        mutant = (
            "        (Some(frame_id), Some(opened)) if frame_id == opened => Ok(()),\n"
            "        (None, _) => Ok(()), // MUTANT: a frame with no stream id silently matches\n"
        )
        assert t.count(anchor) == 1, f"M2 anchor {t.count(anchor)}"
        CALY.write_text(t.replace(anchor, mutant, 1))
        bf, green, reds, _ = e2e_result()
        bf_g, gok, gate_out = gate_result()
        # The gate pins the single acceptance arm `frame_id == opened`; a second accepting arm
        # (or an unconditional pass) reds it. e2e judges stay green (every wire frame carries an
        # id), so M2 is carried by the gate — its job is to prove absence is not defaulted.
        gate_bit = (not bf_g) and (not gok) and "correlates" in gate_out
        e2e_unaffected = (not bf) and green and not any(reds)
        bit = gate_bit and e2e_unaffected
        results["M2 accept-missing-id"] = bit
        print(f"M2: gate_green={gok} (gate_bit={gate_bit}) e2e_unaffected={e2e_unaffected} -> {bit}")
    finally:
        restore(CALY, d2)

    # M3: drop the STREAM_END correlation only (verdict path left unguarded).
    d3 = backup(CALY)
    try:
        t = backup_text(CALY)
        # The end arm's correlation call is the second occurrence in follow_stream (data arm is
        # first). Replace the call that appears inside the STREAM_END arm.
        marker = "            WIRE_KIND_STREAM_END => {\n"
        idx = t.find(marker)
        assert idx != -1, "M3 end arm not found"
        call = "                stream_frame_id_matches(&records, opened_stream.as_deref())?;\n"
        # The call immediately follows the marker line in the end arm.
        region = t[idx : idx + 400]
        assert region.count(call) == 1, f"M3 end call {region.count(call)}"
        t = t[:idx] + region.replace(call, "                // MUTANT: end frame not correlated\n", 1) + t[idx + 400 :]
        CALY.write_text(t)
        bf, green, reds, _ = e2e_result()
        bf_g, gok, gate_out = gate_result()
        # Foreign-end e2e reds (foreign Succeeded end now sets verdict 0); foreign-data stays
        # red-on-mutant? No — data is still correlated so foreign-data stays correctly refused
        # (its judge must NOT red); happy stays green.
        e2e_bit = (not bf) and (not green) and reds[1] and (not reds[0]) and (not reds[2])
        gate_bit = (not bf_g) and (not gok) and "correlates" in gate_out
        bit = e2e_bit and gate_bit
        results["M3 drop-end-correlation"] = bit
        print(
            f"M3: e2e foreign_end_red={reds[1]} foreign_data_red={reds[0]} happy_red={reds[2]} "
            f"(e2e_bit={e2e_bit}) | gate_green={gok} (gate_bit={gate_bit}) -> {bit}"
        )
    finally:
        restore(CALY, d3)

    sweep()
    all_bit = all(results.values())
    print(f"\nall mutations bit: {all_bit}")
    for name, bit in results.items():
        print(f"  {'BIT' if bit else 'MISS'}  {name}")
    return 0 if all_bit else 1


if __name__ == "__main__":
    sys.exit(main())
