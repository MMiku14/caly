#!/usr/bin/env python3
"""Round 85 falsification harness.

The claim: production CLI inbound refuses a declared length over
`MAX_FRAME_SIZE_BYTES` before reading the payload, and a silent peer
still exits 11 (not 13). Two mutations, one file each:

- M1 (must bite)  drop the inbound cap in `wire_read_frame` — the
    codec unit judge goes red (it used to read only the 5-byte head).
- M2 (must bite)  the CLI maps every wire error to the timeout wording
    — the over-cap e2e judge goes red (exit 11 + "timed out" instead of
    13 + "inbound").

Usage: `python3 scripts/falsify_round85.py` (exit 0 = all bit, files restored).
Restore bumps mtime (stale-fingerprint bomb; R79.5.1). ROOT is this
workspace (`/home/user/caly`), not a leftover extract path.
"""

import hashlib
import os
import pathlib
import shutil
import subprocess
import sys
import time

ROOT = pathlib.Path("/home/user/caly")
ENV = dict(os.environ)
ENV["PATH"] = str(pathlib.Path.home() / ".cargo/bin") + ":" + ENV.get("PATH", "")

WIRE = ROOT / "crates/caly-ipc/src/wire.rs"
CLI = ROOT / "crates/caly-cli/src/bin/caly.rs"

M1_JUDGE = ["cargo", "test", "-q", "-p", "caly-ipc", "--lib", "wire"]
M2_JUDGE = [
    "cargo",
    "test",
    "-q",
    "-p",
    "caly-cli",
    "--test",
    "caly_cli_e2e",
    "an_over_cap_inbound_frame_is_refused_before_the_payload_is_read",
]
JUDGE_TIMEOUT_SECS = 180


def digest(path):
    return hashlib.sha256(pathlib.Path(path).read_bytes()).hexdigest()


def sweep_strays():
    for path in ROOT.rglob("*.r85bak"):
        print(f"  note  sweeping stale {path}")
        path.unlink()


def run_judge(cmd):
    begin = time.time()
    proc = subprocess.Popen(
        cmd,
        cwd=ROOT,
        env=ENV,
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
        text=True,
        start_new_session=True,
    )
    try:
        out, _ = proc.communicate(timeout=JUDGE_TIMEOUT_SECS)
    except subprocess.TimeoutExpired:
        os.killpg(proc.pid, 9)
        proc.wait()
        return None, time.time() - begin, "HANG"
    combined = out or ""
    build_failed = "error[" in combined or "could not compile" in combined
    if build_failed:
        return None, time.time() - begin, "COMPILE"
    ok = "0 failed" in combined and "test result: ok" in combined
    return ok, time.time() - begin, ""


def apply_one(path, needle, replacement):
    text = path.read_text()
    assert text.count(needle) == 1, f"{path}: needle not unique: {needle!r}"
    bak = pathlib.Path(str(path) + ".r85bak")
    shutil.copy2(path, bak)
    path.write_text(text.replace(needle, replacement))


def restore_one(path):
    bak = pathlib.Path(str(path) + ".r85bak")
    if bak.exists():
        shutil.copy2(bak, path)
        bak.unlink()
        os.utime(path, None)


M1_OLD = "    if len > MAX_FRAME_SIZE_BYTES as usize {"
M1_NEW = "    if false && len > MAX_FRAME_SIZE_BYTES as usize {"

M2_OLD = """            Err(error) if error.timed_out => Err(format!(
                "timed out after {}ms waiting for the daemon to speak",
                READ_TIMEOUT.as_millis()
            )),
            Err(error) => Err(error.summary),"""
M2_NEW = """            Err(_error) => Err(format!(
                "timed out after {}ms waiting for the daemon to speak",
                READ_TIMEOUT.as_millis()
            )),"""


def main():
    sweep_strays()
    before_wire = digest(WIRE)
    before_cli = digest(CLI)
    results = []

    apply_one(WIRE, M1_OLD, M1_NEW)
    ok, secs, note = run_judge(M1_JUDGE)
    results.append(("M1", "inbound cap dropped in wire_read_frame (must bite)", ok, secs, note))
    restore_one(WIRE)

    apply_one(CLI, M2_OLD, M2_NEW)
    ok, secs, note = run_judge(M2_JUDGE)
    results.append(("M2", "CLI maps every wire error to timeout wording (must bite)", ok, secs, note))
    restore_one(CLI)

    all_bite = True
    for name, label, bit, secs, note in results:
        if note:
            print(f"  {'ok' if not bit else 'MISS'}    {name} {label} ({note} in {secs:.1f}s)")
        else:
            print(f"  {'ok' if not bit else 'MISS'}    {name} {label} (bite in {secs:.1f}s)")
        if bit:
            all_bite = False

    after_wire = digest(WIRE)
    after_cli = digest(CLI)
    assert after_wire == before_wire, "wire.rs not restored"
    assert after_cli == before_cli, "caly.rs not restored"
    print(f"restored: wire={after_wire[:12]}… cli={after_cli[:12]}…")
    print("all mutations behaved as predicted: " + ("True" if all_bite else "False"))
    sys.exit(0 if all_bite else 1)


if __name__ == "__main__":
    main()
