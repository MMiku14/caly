"""Falsification harness for round 51 (the first stream: `jobs.follow-stream` on the wire, the
job-stream pump, and `caly follow`).

Same discipline as rounds 16/32–50: one mutation per run, exact-anchor replacement with
`assert count == 1`, restore by content and mtime, sha256-verified, stale `*.r51bak` swept at
startup. A mutation that cannot compile proves nothing (`§4.112`). Backups are taken **per
mutation** (`§4.137`). No hang-shaped mutations: every mutant still ends its conversations.

Six mutations: the pump swallows a gap (a lossless stream skipping), the pump ends before
flushing its lines, the end frame always claims Succeeded, a data frame that drops its first
line, the CLI ignoring data frames, and the CLI exiting 0 on a failed verdict.

Usage: `python3 scripts/falsify_round51.py` (exit 0 = every mutation bit, every file restored).
"""

import hashlib
import os
import pathlib
import shutil
import subprocess
import sys

ROOT = pathlib.Path("/home/user/caly")
ENV = dict(os.environ)
ENV["PATH"] = str(pathlib.Path.home() / ".cargo/bin") + ":" + ENV.get("PATH", "")
SRC = {
    "daemon": ROOT / "crates/caly-daemon/src/bin/calyd.rs",
    "cli": ROOT / "crates/caly-cli/src/bin/caly.rs",
    "pump": ROOT / "crates/caly-daemon/src/job_stream.rs",
}

MUTATIONS = [
    (
        "M1 the pump swallows a gap (a lossless stream skips)",
        "pump",
        "        if page.reset_required {",
        "        if false && page.reset_required {",
        [
            "a_gap_is_named_with_a_resume_position_never_skipped",
        ],
    ),
    (
        "M2 the pump ends before flushing its lines",
        "pump",
        "        if !page.events.is_empty() {",
        "        if false && !page.events.is_empty() {",
        [
            "a_terminal_job_flushes_then_ends",
            "a_failed_job_flushes_then_ends",
        ],
    ),
    (
        "M3 the end frame always claims Succeeded",
        "daemon",
        '                                                                    format!("{outcome:?}"),',
        '                                                                    "Succeeded".to_owned(),',
        [
            "caly_follow_exits_nonzero_for_a_failed_job",
        ],
    ),
    (
        "M4 a data frame drops its first line",
        "daemon",
        "                                                    for (index, line) in lines.iter().enumerate() {",
        "                                                    for (index, line) in lines.iter().enumerate().skip(1) {",
        [
            "caly_follow_prints_what_jobs_prints_and_exits_by_the_verdict",
        ],
    ),
    (
        "M5 the CLI ignores data frames",
        "cli",
        """            WIRE_KIND_STREAM_DATA => {
                for line in indexed(&records, "event") {
                    println!("  - {line}");
                }
            }""",
        """            WIRE_KIND_STREAM_DATA => {
                let _ = &records;
            }""",
        [
            "caly_follow_prints_what_jobs_prints_and_exits_by_the_verdict",
        ],
    ),
    (
        "M6 the CLI exits 0 on a failed verdict",
        "cli",
        '                    "Failed" => ExitCode::GeneralFailure,',
        '                    "Failed" => ExitCode::Success,',
        [
            "caly_follow_exits_nonzero_for_a_failed_job",
        ],
    ),
]


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def run_cargo():
    proc = subprocess.run(
        [
            "cargo",
            "test",
            "-p",
            "caly-daemon",
            "--lib",
            "--test",
            "calyd_wire",
            "-p",
            "caly-cli",
            "--test",
            "caly_cli_e2e",
            "--no-fail-fast",
        ],
        cwd=str(ROOT),
        env=ENV,
        capture_output=True,
        text=True,
    )
    out = proc.stdout + proc.stderr
    failed = sorted(
        {
            line[5:].split(" ... ")[0].split("::")[-1].strip()
            for line in out.splitlines()
            if line.startswith("test ") and line.rstrip().endswith("... FAILED")
        }
    )
    return proc.returncode, failed, out


def main():
    for path in ROOT.rglob("*.r51bak"):
        original = pathlib.Path(str(path)[: -len(".r51bak")])
        shutil.move(str(path), str(original))
        print("swept leftover backup:", path.name)

    originals = {name: digest(path) for name, path in SRC.items()}
    results = []
    bad = False
    for label, key, old, new, expected in MUTATIONS:
        path = SRC[key]
        backup = pathlib.Path(str(path) + ".r51bak")
        shutil.copyfile(path, backup)  # per-mutation backup (§4.137)
        s = path.read_text()
        assert s.count(old) == 1, "%s: anchor x%d" % (label, s.count(old))
        try:
            path.write_text(s.replace(old, new, 1))
            code, failed, out = run_cargo()
            red = [name for name in expected if name in failed]
            compile_error = "error[" in out or "could not compile" in out
            ok = bool(red) and not compile_error
            results.append((label, ok))
            print("%-48s %s  red=%s" % (label, "BIT" if ok else "NO EFFECT", red or failed[:4]))
            if not ok:
                if compile_error:
                    print("   !! the mutation did not compile; it proves nothing")
                print("   output tail:\n", out[-1200:])
        finally:
            shutil.move(str(backup), str(path))
            os.utime(path, None)
            assert digest(path) == originals[key], "%s: restore did not reproduce the file" % label

    print("\n== summary ==")
    for label, ok in results:
        print("%-48s %s" % (label, "bit" if ok else "DID NOT BIT"))
        if not ok:
            bad = True
    print("all mutations bit:", not bad)
    sys.exit(1 if bad else 0)


if __name__ == "__main__":
    main()
