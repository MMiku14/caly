"""Falsification harness for round 54 (the Proc supervision surface of `ADR-043` and the real
core lifecycle that rides on it).

Same discipline as rounds 16/32–53: one mutation per run, exact-anchor replacement with
`assert count == 1`, restore by content and mtime, sha256-verified, stale `*.r54bak` swept at
startup. A mutation that cannot compile proves nothing (`§4.112`). Backups are per-mutation
(`§4.137`). Each cargo run carries a hard 15-minute timeout: a mutation that wedges the suite
counts as DID NOT BIT and gets redesigned (`§4.139`). A mutation may also leave a real core
running when its judge dies mid-lifecycle (a fabricated stop does not stop anything), so the
harness sweeps stray `caly-real-core` children after every mutation — the tree must be clean
for the next verdict to mean anything.

Five mutations: try_wait always answering "still running", stop fabricating an exit instead
of stopping, the simulator's stop overwriting a scripted natural exit with its own kill,
spawn not registering the child into the supervision table, and the signal flag flattened out
of the exit mapping.

Usage: `python3 scripts/falsify_round54.py` (exit 0 = every mutation bit, every file restored).
"""

import hashlib
import os
import pathlib
import shutil
import subprocess
import sys

ROOT = pathlib.Path("/home/user/caly")
ENV = dict(os.environ)
ENV["PATH"] = str(pathlib.Path.home() / ".cargo/bin") + ":" + ENV.get("PATH", "")
SRC = {
    "proc": ROOT / "crates/caly-io-std/src/proc.rs",
    "sim": ROOT / "crates/caly-io-sim/src/port_impl.rs",
}

MUTATIONS = [
    (
        "M1 try_wait always answers still-running",
        "proc",
        """            guard
                .try_wait()
                .map(|status| status.map(exit_from_status))
                .map_err(|error| {
                    IoFault::new(
                        IoFaultKind::InternalIo,
                        format!("wait pid {}: {error}", handle.pid),
                    )
                })""",
        """            let _ = &mut guard;
            Ok(None)""",
        [
            "a_real_core_lives_and_dies_through_the_proc_port",
            "the_geo_databases_are_load_bearing_not_decoration",
            "the_shared_supervision_contract_holds_on_a_real_host",
        ],
    ),
    (
        "M2 stop fabricates an exit and stops nothing",
        "proc",
        """            let deadline = Instant::now() + Duration::from_millis(grace_ms);
            loop {""",
        """            let _ = grace_ms;
            return Ok(ChildExit { code: 0, signaled: false });
            #[allow(unreachable_code)]
            let deadline = Instant::now() + Duration::from_millis(grace_ms);
            loop {""",
        [
            "a_real_core_lives_and_dies_through_the_proc_port",
        ],
    ),
    (
        "M3 the simulator's stop overwrites a natural exit with its kill",
        "sim",
        """            if child.exit.is_none() {""",
        """            if true {""",
        [
            "sim_proc_satisfies_the_shared_supervision_contract",
        ],
    ),
    (
        "M4 spawn does not register the child into the supervision table",
        "proc",
        """            self.children
                .lock()
                .map_err(|_| IoFault::new(IoFaultKind::InternalIo, "proc registry lock poisoned"))?
                .insert(instance_nonce.clone(), Arc::new(Mutex::new(child)));""",
        """            let _ = (instance_nonce.clone(), child);""",
        [
            "a_real_core_lives_and_dies_through_the_proc_port",
            "the_shared_supervision_contract_holds_on_a_real_host",
        ],
    ),
    (
        "M5 the signal flag is flattened out of the exit mapping",
        "proc",
        """        if let Some(signal) = status.signal() {
            return ChildExit {
                code: signal,
                signaled: true,
            };
        }""",
        """        if let Some(signal) = status.signal() {
            return ChildExit {
                code: signal,
                signaled: false,
            };
        }""",
        [
            "a_real_core_lives_and_dies_through_the_proc_port",
        ],
    ),
]


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def sweep_stray_cores():
    """A mutated stop can leave a real core running after its judge died; the next verdict
    needs a clean host (ports, processes) to mean anything."""
    subprocess.run(
        ["pkill", "-f", "caly-real-core"],
        stdout=subprocess.DEVNULL,
        stderr=subprocess.DEVNULL,
    )


def run_cargo():
    argv = [
        "cargo",
        "test",
        "-p",
        "caly-io-std",
        "--test",
        "proc_std",
        "--test",
        "real_core",
        "-p",
        "caly-io-sim",
        "--test",
        "contract",
        "--no-fail-fast",
    ]
    try:
        proc = subprocess.run(
            argv,
            cwd=str(ROOT),
            env=ENV,
            capture_output=True,
            text=True,
            timeout=900,  # a wedged suite is a wedged *mutant*, not a verdict (§4.139)
        )
    except subprocess.TimeoutExpired:
        return 124, [], "TIMEOUT: the mutation wedged the suite (§4.139) — redesign it"
    out = proc.stdout + proc.stderr
    failed = sorted(
        {
            line[5:].split(" ... ")[0].split("::")[-1].strip()
            for line in out.splitlines()
            if line.startswith("test ") and line.rstrip().endswith("... FAILED")
        }
    )
    return proc.returncode, failed, out


def main():
    for path in ROOT.rglob("*.r54bak"):
        original = pathlib.Path(str(path)[: -len(".r54bak")])
        shutil.move(str(path), str(original))
        print("swept leftover backup:", path.name)
    sweep_stray_cores()

    originals = {name: digest(path) for name, path in SRC.items()}
    results = []
    bad = False
    for label, key, old, new, expected in MUTATIONS:
        path = SRC[key]
        backup = pathlib.Path(str(path) + ".r54bak")
        shutil.copyfile(path, backup)  # per-mutation backup (§4.137)
        s = path.read_text()
        assert s.count(old) == 1, "%s: anchor x%d" % (label, s.count(old))
        try:
            mutated = s.replace(old, new, 1)
            path.write_text(mutated)
            code, failed, out = run_cargo()
            wedged = code == 124
            red = [name for name in expected if name in failed]
            compile_error = "error[" in out or "could not compile" in out
            ok = bool(red) and not compile_error and not wedged
            results.append((label, ok))
            print("%-52s %s  red=%s" % (label, "BIT" if ok else "NO EFFECT", red or failed[:4]))
            if not ok:
                if compile_error:
                    print("   !! the mutation did not compile; it proves nothing")
                if wedged:
                    print("   !! the mutation wedged the suite; it proves nothing (§4.139)")
                print("   output tail:\n", out[-1200:])
        finally:
            shutil.move(str(backup), str(path))
            os.utime(path, None)
            assert digest(path) == originals[key], "%s: restore did not reproduce the file" % label
            sweep_stray_cores()

    print("\n== summary ==")
    for label, ok in results:
        print("%-52s %s" % (label, "bit" if ok else "DID NOT BIT"))
        if not ok:
            bad = True
    print("all mutations bit:", not bad)
    sys.exit(1 if bad else 0)


if __name__ == "__main__":
    main()
