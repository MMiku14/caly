#!/usr/bin/env python3
"""Round 81 falsification harness.

The claim: `docs/EXIT_CODES.md §2`'s 0/1/2 names and the code's `ExitCode::as_str` are
one map, and the two crates' names (ExitCode vs ErrorCode, through `from_error_code`)
never drift apart, judged by `caly-cli/tests/exit_code_table.rs` (+ `error_doc.rs` for M3):

- M1 (must bite)  a document-side drift: §2's `SUCCESS` becomes `SUCCEED` — the R81
    judge goes red (the doc names a code the enum doesn't).
- M2 (must bite)  a code-side drift: `ExitCode::Usage` names itself `USAGE_` — the R81
    judge goes red (the doc names `USAGE`).
- M3 (must bite)  a twin-name drift: `ErrorCode::Timeout` names itself `TIMEOUT_` — the
    R81 twin assertion goes red, and the R80 closure judge goes red too (both run; the
    report says which). R79's map judge also covers this name and is expected to redden
    but is not run — its harness is unchanged and its M1/M2 already proved it.

Usage: `python3 scripts/falsify_round81.py` (exit 0 = all bit, files restored).
Restore bumps mtime — copy2's preserved mtime leaves a stale-fingerprint bomb (R79.5.1).
"""

import hashlib
import os
import pathlib
import shutil
import subprocess
import sys
import time

ROOT = pathlib.Path("/home/user/caly_extract/caly")
ENV = dict(os.environ)
ENV["PATH"] = str(pathlib.Path.home() / ".cargo/bin") + ":" + ENV.get("PATH", "")

DOC = ROOT / "docs/EXIT_CODES.md"
CLI_CODE = ROOT / "crates/caly-cli/src/exit_code.rs"
API_CODE = ROOT / "crates/caly-api/src/error.rs"

JUDGE_R81 = ["cargo", "test", "-q", "-p", "caly-cli", "--test", "exit_code_table"]
JUDGE_R80 = ["cargo", "test", "-q", "-p", "caly-api", "--test", "error_doc"]
JUDGE_TIMEOUT_SECS = 300


def digest(path):
    return hashlib.sha256(pathlib.Path(path).read_bytes()).hexdigest()


def sweep_strays():
    for path in ROOT.rglob("*.r81bak"):
        print(f"  note  sweeping stale {path}")
        path.unlink()


def run_judge(command):
    begin = time.time()
    proc = subprocess.Popen(
        command,
        cwd=ROOT,
        env=ENV,
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
        text=True,
        start_new_session=True,
    )
    try:
        out, _ = proc.communicate(timeout=JUDGE_TIMEOUT_SECS)
    except subprocess.TimeoutExpired:
        os.killpg(proc.pid, 9)
        proc.wait()
        return None, time.time() - begin, "HANG"
    ok = "0 failed" in (out or "") and "test result: ok" in (out or "")
    return ok, time.time() - begin, ""


def apply_one(path, needle, replacement):
    text = path.read_text()
    assert text.count(needle) == 1, f"{path}: needle not unique: {needle!r}"
    bak = pathlib.Path(str(path) + ".r81bak")
    shutil.copy2(path, bak)
    path.write_text(text.replace(needle, replacement))


def restore_one(path):
    bak = pathlib.Path(str(path) + ".r81bak")
    if bak.exists():
        shutil.copy2(bak, path)
        bak.unlink()
        os.utime(path, None)


M1_OLD = "| `0` | `SUCCESS` | 成功 |"
M1_NEW = "| `0` | `SUCCEED` | 成功 |"

M2_OLD = "            ExitCode::Usage => \"USAGE\","
M2_NEW = "            ExitCode::Usage => \"USAGE_\","

M3_OLD = '            Self::Timeout => "TIMEOUT",'
M3_NEW = '            Self::Timeout => "TIMEOUT_",'


def main():
    sweep_strays()
    results = []

    apply_one(DOC, M1_OLD, M1_NEW)
    ok, secs, note = run_judge(JUDGE_R81)
    results.append(("M1", "the §2 name SUCCESS is typo'd (must bite)", ok, secs, note))
    restore_one(DOC)

    apply_one(CLI_CODE, M2_OLD, M2_NEW)
    ok, secs, note = run_judge(JUDGE_R81)
    results.append(("M2", "ExitCode::Usage names itself USAGE_ (must bite)", ok, secs, note))
    restore_one(CLI_CODE)

    apply_one(API_CODE, M3_OLD, M3_NEW)
    ok81, secs81, note81 = run_judge(JUDGE_R81)
    ok80, secs80, _ = run_judge(JUDGE_R80)
    note81 = (note81 or "") + f"; R80 judge red={not ok80} ({secs80:.1f}s)"
    results.append(("M3", "ErrorCode::Timeout names itself TIMEOUT_ (must bite, R80 too)", ok81, secs81, note81))
    restore_one(API_CODE)

    all_bite = True
    for name, label, bit, secs, note in results:
        if note:
            print(f"  {'ok' if not bit else 'MISS'}    {name} {label} ({note} in {secs:.1f}s)")
        else:
            print(f"  {'ok' if not bit else 'MISS'}    {name} {label} (bite in {secs:.1f}s)")
        if bit:
            all_bite = False

    print(f"restored: doc={digest(DOC)[:12]}… cli={digest(CLI_CODE)[:12]}… api={digest(API_CODE)[:12]}…")
    print("all mutations behaved as predicted: " + ("True" if all_bite else "False"))
    sys.exit(0 if all_bite else 1)


if __name__ == "__main__":
    main()
