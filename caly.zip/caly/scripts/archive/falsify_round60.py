"""Falsification harness for round 60 (SystemProxy; Direct-mode routing; wg override).

Same discipline as rounds 16/32–59: one mutation per run, exact-anchor replacement with
`assert count == 1`, restore by content and mtime, sha256-verified, stale `*.r60bak`
swept at startup. A mutation that cannot compile proves nothing (`§4.112`); backups are
per-mutation (`§4.137`); each cargo run carries a hard timeout (`§4.139`). Real cores
that outlive their judge are swept (both core patterns, split — `§4.143`).

Five mutations, each bitten by a judge this round created:

- M1  SystemProxy silently goes direct — the stub proxy never sees the request and the
      rides judge fails on a host that does not resolve;
- M2  the pure proxy parser always says None — the parse judge goes looking for an
      address that was never parsed;
- M3  Direct mode still emits the group rules — the direct-mode render judge (and the
      through-the-core ride) die on the dead-tunnel routing the mode was supposed to
      forbid;
- M4  the wg endpoint ignores passthrough credentials — the override judge misses the
      real keys;
- M5  the render drops the explicit direct outbound — `sing-box check` itself FATALs
      (default outbound not found), the core's own validator bites.

Usage: `python3 scripts/archive/falsify_round60.py` (exit 0 = every mutation bit, every file restored).
"""

import hashlib
import os
import pathlib
import shutil
import subprocess
import sys
import time

ROOT = pathlib.Path("/home/user/caly")
ENV = dict(os.environ)
ENV["PATH"] = str(pathlib.Path.home() / ".cargo/bin") + ":" + ENV.get("PATH", "")
SRC = {
    "http": ROOT / "crates/caly-io-std/src/http.rs",
    "singbox": ROOT / "crates/caly-singbox/src/adapter.rs",
}

M1_DIRECT_ARM = """                FetchRoute::SystemProxy => {
                    let address: SocketAddr = (parsed.host.as_str(), parsed.port)
                        .to_socket_addrs()
                        .map_err(|error| {
                            Self::fault(
                                IoFaultKind::Unavailable,
                                format!("resolve {}: {{error}}", parsed.host),
                            )
                        }})?
                        .next()
                        .ok_or_else(|| {{
                            Self::fault(
                                IoFaultKind::Unavailable,
                                format!("resolve {}: no address", parsed.host),
                            )
                        }})?;
                    (address, false)
                }}""".replace("}}", "}").replace("{{", "{")

MUTATIONS = [
    (
        "M1 SystemProxy silently goes direct",
        "http",
        """                FetchRoute::SystemProxy => {
                    let address = self.system_proxy.ok_or_else(|| {
                        Self::fault(
                            IoFaultKind::Unavailable,
                            "no system proxy is configured on this adapter \\
                             (http_proxy/all_proxy unset or unparseable at composition) — \\
                             refusing by name rather than silently going direct (ADR-048 §2)",
                        )
                    })?;
                    (address, true)
                }""",
        M1_DIRECT_ARM,
        [
            "system_proxy_rides_absolute_form_to_the_composed_proxy",
        ],
    ),
    (
        "M2 proxy parser always says None",
        "http",
        """    pub fn parse_proxy_value(value: &str) -> Option<std::net::SocketAddr> {
        value
            .trim()
            .trim_start_matches("http://")
            .trim_start_matches("https://")
            .parse::<std::net::SocketAddr>()
            .ok()
    }""",
        """    pub fn parse_proxy_value(value: &str) -> Option<std::net::SocketAddr> {
        let _ = value;
        None
    }""",
        [
            "proxy_values_parse_purely",
        ],
    ),
    (
        "M3 Direct mode still emits group rules",
        "singbox",
        """        if !rule_mode {
            continue;
        }""",
        """        let _ = rule_mode;""",
        [
            "direct_routing_mode_sends_everything_out_the_direct_outbound",
            "a_fetch_through_the_active_core_really_rides_the_core",
        ],
    ),
    (
        "M4 wg endpoint ignores passthrough",
        "singbox",
        """    let passthrough = |key: &str| node.passthrough.get(key).cloned();""",
        """    let passthrough = |_: &str| Option::<String>::None;""",
        [
            "wireguard_passthrough_credentials_override_the_inert_constants",
        ],
    ),
    (
        "M5 render drops the explicit direct outbound",
        "singbox",
        """    let mut outbounds = vec!["{\\"type\\":\\"direct\\",\\"tag\\":\\"direct\\"}".to_owned()];""",
        """    let mut outbounds = Vec::new();""",
        [
            "singbox_profile_runs_a_real_second_core",
        ],
    ),
]


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def sweep_stray_cores():
    for pattern in ("caly-ru" "n.yaml", "sing-box" " run"):
        subprocess.run(
            ["pkill", "-f", pattern],
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
        )
    time.sleep(1.0)  # a kill is not done until a beat has passed


def run_cargo():
    argvs = [
        ["cargo", "test", "-p", "caly-io-std", "--test", "http_route", "--no-fail-fast"],
        ["cargo", "test", "-p", "caly-singbox", "--no-fail-fast"],
        ["cargo", "test", "-p", "caly-daemon", "--test", "real_apply", "--no-fail-fast"],
    ]
    failed = []
    tail = ""
    for argv in argvs:
        try:
            proc = subprocess.run(
                argv,
                cwd=str(ROOT),
                env=ENV,
                capture_output=True,
                text=True,
                timeout=900,  # §4.139
            )
        except subprocess.TimeoutExpired:
            return 124, [], "TIMEOUT: the mutation wedged the suite (§4.139) — redesign it"
        out = proc.stdout + proc.stderr
        tail += out[-2000:]
        failed += [
            line[5:].split(" ... ")[0].split("::")[-1].strip()
            for line in out.splitlines()
            if line.startswith("test ") and line.rstrip().endswith("... FAILED")
        ]
    return 0, sorted(set(failed)), tail


def main():
    for path in ROOT.rglob("*.r60bak"):
        original = pathlib.Path(str(path)[: -len(".r60bak")])
        shutil.move(str(path), str(original))
        print("swept leftover backup:", path.name)
    sweep_stray_cores()

    originals = {name: digest(path) for name, path in SRC.items()}
    results = []
    bad = False
    for label, key, old, new, expected in MUTATIONS:
        path = SRC[key]
        backup = pathlib.Path(str(path) + ".r60bak")
        shutil.copyfile(path, backup)  # per-mutation backup (§4.137)
        s = path.read_text()
        assert s.count(old) == 1, "%s: anchor x%d" % (label, s.count(old))
        try:
            path.write_text(s.replace(old, new, 1))
            code, failed, out = run_cargo()
            wedged = code == 124
            red = [name for name in expected if name in failed]
            compile_error = "error[" in out or "could not compile" in out
            ok = bool(red) and not compile_error and not wedged
            results.append((label, ok))
            print("%-42s %s  red=%s" % (label, "BIT" if ok else "NO EFFECT", red or failed[:4]))
            if not ok:
                if compile_error:
                    print("   !! the mutation did not compile; it proves nothing")
                if wedged:
                    print("   !! the mutation wedged the suite; it proves nothing (§4.139)")
                print("   output tail:\n", out[-1200:])
        finally:
            shutil.move(str(backup), str(path))
            os.utime(path, None)
            assert digest(path) == originals[key], "%s: restore did not reproduce the file" % label
            sweep_stray_cores()

    print("\n== summary ==")
    for label, ok in results:
        print("%-42s %s" % (label, "bit" if ok else "DID NOT BIT"))
        if not ok:
            bad = True
    print("all mutations bit:", not bad)
    sys.exit(1 if bad else 0)


if __name__ == "__main__":
    main()
