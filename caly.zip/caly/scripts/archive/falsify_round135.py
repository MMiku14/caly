#!/usr/bin/env python3
"""Round 135 falsify: storage sizing — the two behaviour pins behind the baseline report.

Two mutations:
  M1 the entry-cap refusal disappears from the simulator's list (the cliff judge must go
     red: reopen past 4096 must be a NAMED refusal, not a silent success);
  M2 reopen degrades to the classic rescan-everything sweep — every record re-lists and
     re-reads the whole directory (quadratic port calls; the sixteenfold linearity judge's
     UPPER bound exists exactly for this shape).

Byte-for-byte restore per mutation (sha256 + mtime bump); RED verdicts carry the
compiled-guard.
"""
import hashlib
import os
import subprocess
import sys

CALY = "/home/user/caly/caly"
SIM = f"{CALY}/crates/caly-io-sim/src/port_impl.rs"
STORE = f"{CALY}/crates/caly-storage/src/fs_store.rs"

T_CLIFF = (
    "-p caly-storage --test perf_regression "
    "an_object_directory_past_the_entry_cap_refuses_the_next_reopen_naming_the_bound"
)
T_LINEAR = (
    "-p caly-storage --test perf_regression "
    "a_sixteenfold_bigger_directory_stays_linear_in_port_calls"
)


def run(*args: str) -> tuple[int, str]:
    proc = subprocess.run(args, cwd=CALY, capture_output=True, text=True, timeout=900)
    return proc.returncode, proc.stdout + proc.stderr


def test(name: str, expect_ok: bool) -> str:
    code, out = run("cargo", "test", *name.split(), "--", "--test-threads=1")
    compiled = "error[" not in out and "error: " not in out
    passed = code == 0 and compiled
    if passed == expect_ok:
        return "GREEN" if expect_ok else "RED"
    verdict = "UNEXPECTED-RED" if expect_ok else "MISSED-BIT"
    tail = "\n".join(out.splitlines()[-10:])
    print(f"    [{verdict}] {name}\n    --------\n{tail}\n    --------")
    return verdict


MUTATIONS = [
    dict(
        name="M1 the entry-cap refusal disappears from list",
        file=SIM,
        old="""            if names.len() > cap.0 as usize {""",
        new="""            if false && names.len() > cap.0 as usize {""",
        red=[(T_CLIFF, False)],
        green=[(T_LINEAR, True)],
    ),
    dict(
        name="M2 reopen rescans the whole directory per record",
        file=STORE,
        old="""        for suffix in self.list_records(OBJECT_DIRECTORY, ctx).map_err(text)? {
            let Some(raw) = self.read_text(&suffix, ctx).map_err(text)? else {""",
        new="""        for suffix in self.list_records(OBJECT_DIRECTORY, ctx).map_err(text)? {
            for other in self.list_records(OBJECT_DIRECTORY, ctx).map_err(text)? {
                let _ = self.read_text(&other, ctx);
            }
            let Some(raw) = self.read_text(&suffix, ctx).map_err(text)? else {""",
        red=[(T_LINEAR, False)],
        green=[(T_CLIFF, True)],
    ),
]


def main() -> int:
    leftovers: list[str] = []
    for mutation in MUTATIONS:
        path = mutation["file"]
        original = open(path, "rb").read().decode()
        original_sha = hashlib.sha256(original.encode()).hexdigest()
        if mutation["old"] not in original:
            print(f"{mutation['name']}: ANCHOR NOT FOUND (skipped)")
            continue
        mutated = original.replace(mutation["old"], mutation["new"], 1)
        open(path, "w").write(mutated)
        os.utime(path, None)
        try:
            verdicts = []
            for name, expect in mutation["red"] + mutation["green"]:
                verdicts.append(test(name, expect))
            reds = verdicts[: len(mutation["red"])]
            greens = verdicts[len(mutation["red"]) :]
            ok = all(v == "RED" for v in reds) and all(v == "GREEN" for v in greens)
            print(
                f"{mutation['name']}: {'BIT' if ok else 'MISSED-BIT'} "
                f"(red={reds} green={greens})"
            )
        finally:
            open(path, "w").write(original)
            os.utime(path, None)
            if hashlib.sha256(open(path, "rb").read().decode().encode()).hexdigest() != original_sha:
                leftovers.append(path)
    if leftovers:
        print(f"LEFTOVERS: {leftovers}")
        return 1
    print("leftovers: []")
    return 0


if __name__ == "__main__":
    sys.exit(main())
