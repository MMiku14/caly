#!/usr/bin/env python3
"""Round 99 falsification harness.

Target property: a one-shot `caly job <id>` (jobs.follow query) that describes a TERMINALLY
FAILED job carries the engine's stable `failure_code` over the wire; the bin must map that
verdict to the code's documented exit number (docs/guides/EXIT_CODES.md §4.3) instead of always exiting 0.
The verdict is read ONLY for the jobs.follow operation, an absent/EMPTY failure_code means
"not failed" (success), and the recognised code routes through the same R98 public-code table
(from_wire_refusal_code) — failure_code is an ApiError code, not a separate vocabulary. Both
answer arms (human records render and --json verbatim payload) apply the verdict.

Judges:
  - e2e a_one_shot_job_query_for_a_failed_job_maps_its_failure_code (PERMISSION failure -> 8);
  - e2e a_one_shot_job_query_for_a_non_failed_job_stays_exit_zero (empty failure_code -> 0);
  - e2e a_one_shot_json_job_query_for_a_failed_job_maps_its_failure_code_too (json STORAGE -> 10);
  - arch gate the_cli_maps_a_one_shot_job_follow_failure_code_to_an_exit_code.

Mutations (build green; a judge bites):
  M1 collapse the helper to always return Success (drop the failure mapping). Bites the failed
     e2e (PERMISSION gets 0 not 8) and the json e2e (STORAGE gets 0 not 10); the non-failed e2e
     stays green (proving M1 disables *only* the failure verdict).
  M2 drop the empty-code filter so an EMPTY failure_code is treated as a code to map. The empty
     string maps through from_wire_refusal_code to ProtoMismatch (13): the non-failed e2e bites
     (a succeeded job with failure_code="" exits 13 not 0). Proves the `!is_empty()` filter is
     what keeps a healthy job at exit 0.
  M3 hard-code the mapping to Success in the records arm only (bypass from_wire_refusal_code).
     Bites the arch gate (no `from_wire_refusal_code(code)` in the helper) — pins that the job
     failure code shares the R98 refusal table rather than drifting into a parallel mapping.

Restoration is content + mtime, sha256-verified. cwd = workspace root.
"""

import hashlib
import pathlib
import shutil
import subprocess
import sys

ROOT = pathlib.Path(__file__).resolve().parents[1]
BIN = ROOT / "crates/caly-cli/src/bin/caly.rs"
SUFFIX = ".r99bak"

FAILED_E2E = "a_one_shot_job_query_for_a_failed_job_maps_its_failure_code ... FAILED"
NONFAILED_E2E = "a_one_shot_job_query_for_a_non_failed_job_stays_exit_zero ... FAILED"
JSON_E2E = "a_one_shot_json_job_query_for_a_failed_job_maps_its_failure_code_too ... FAILED"
GATE = "the_cli_maps_a_one_shot_job_follow_failure_code_to_an_exit_code ... FAILED"


def sha256(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def backup(path):
    digest = sha256(path)
    shutil.move(str(path), str(path.with_name(path.name + SUFFIX)))
    return digest


def restore(path, digest):
    bak = path.with_name(path.name + SUFFIX)
    shutil.move(str(bak), str(path))
    got = sha256(path)
    assert got == digest, f"restore mismatch for {path}: {got} != {digest}"


def write_bin(text):
    BIN.write_text(text)


def run_e2e():
    proc = subprocess.run(
        ["cargo", "test", "-p", "caly-cli", "--test", "caly_cli_e2e"],
        cwd=ROOT, capture_output=True, text=True,
    )
    return proc.stdout + proc.stderr


def run_gate():
    proc = subprocess.run(
        ["cargo", "test", "-p", "caly-arch-test", "--test", "dependency_direction"],
        cwd=ROOT, capture_output=True, text=True,
    )
    return proc.stdout + proc.stderr


def expect_bites(name, output, markers):
    missing = [m for m in markers if m not in output]
    if missing:
        print(f"  FAIL [{name}]: expected judges to bite, missing: {missing}")
        return False
    print(f"  BIT  [{name}]: {[m.split(' ...')[0] for m in markers]}")
    return True


def expect_green(name, output, must_not):
    present = [m for m in must_not if m in output]
    if present:
        print(f"  FAIL [{name}]: expected green but saw: {present}")
        return False
    print(f"  OK   [{name}]: no unexpected bite")
    return True


def main():
    original = backup(BIN)
    base = BIN.with_name(BIN.name + SUFFIX).read_text()
    ok = True
    try:
        # M1: helper always returns Success (failure mapping removed).
        m1 = base.replace(
            "    match failure_code {\n        Some(code) => caly_cli::from_wire_refusal_code(code),\n        None => ExitCode::Success,\n    }",
            "    let _ = failure_code;\n    ExitCode::Success",
        )
        assert m1 != base, "M1 anchor not found"
        write_bin(m1)
        out = run_e2e()
        ok &= expect_bites("M1 collapse-to-success", out, [FAILED_E2E, JSON_E2E])
        ok &= expect_green("M1 non-failed stays green", out, [NONFAILED_E2E])

        # M2: drop the empty-code filter (empty failure_code maps to ProtoMismatch 13).
        m2 = base.replace(
            'wire_field(records, "failure_code").filter(|code| !code.is_empty())',
            'wire_field(records, "failure_code")',
        )
        assert m2 != base, "M2 anchor not found"
        write_bin(m2)
        out = run_e2e()
        ok &= expect_bites("M2 no-empty-filter bites non-failed", out, [NONFAILED_E2E])

        # M3: bypass from_wire_refusal_code in the helper (parallel mapping / gate structural).
        m3 = base.replace(
            "        Some(code) => caly_cli::from_wire_refusal_code(code),",
            "        Some(_code) => ExitCode::Success,",
        )
        assert m3 != base, "M3 anchor not found"
        write_bin(m3)
        gout = run_gate()
        ok &= expect_bites("M3 gate pins shared table", gout, [GATE])
    finally:
        restore(BIN, original)

    if not ok:
        print("ROUND 99 FALSIFICATION: RED (a mutation was not caught)")
        sys.exit(1)
    print("ROUND 99 FALSIFICATION: all mutations BIT; restore sha256-verified.")


if __name__ == "__main__":
    main()
