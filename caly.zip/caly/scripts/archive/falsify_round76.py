#!/usr/bin/env python3
"""Round 76 falsification harness.

The claim under test (`ROADMAP §13#3` single-source wire shape): `caly_ipc::wire_request`
encodes the v0 wire request shape the daemon decodes — op names and record names agree. The
judges are:

- `caly-ipc` lib unit tests (`wire_ops`): the dictated per-op name + record contract plus the
  no-wire-name refusal.
- `calyd_wire`'s `every_request_op_encoded_by_the_single_source_passes_the_daemons_door`:
  every op the encoder ships crosses the real daemon's door without a `USAGE` (record shape)
  or `UNSUPPORTED` (unknown op) refusal.

- M1 (must bite)  a wire name is typo'd (`profiles.apply` -> `profiles.applyx`) — the daemon
      does not dispatch it: `UNSUPPORTED` at the door, judge red.
- M2 (must bite)  a required record name is typo'd (`profile_id` -> `profile` in the apply
      arm) — the daemon's door refuses `USAGE` ("needs a profile_id record"), judge red.

Usage: `python3 scripts/archive/falsify_round76.py` (exit 0 = both bit, files restored).
"""

import hashlib
import os
import pathlib
import shutil
import subprocess
import sys
import time

ROOT = pathlib.Path("/home/user/caly_extract/caly")
ENV = dict(os.environ)
ENV["PATH"] = str(pathlib.Path.home() / ".cargo/bin") + ":" + ENV.get("PATH", "")

WIRE_OPS = ROOT / "crates/caly-ipc/src/wire_ops.rs"
BAK = ROOT / "crates/caly-ipc/src/wire_ops.rs.r76bak"

JUDGE = [
    # The door sweep (the falsify target) plus the unit contract tests.
    ("-p", "caly-daemon", "--test", "calyd_wire",
     "every_request_op_encoded_by_the_single_source_passes_the_daemons_door"),
    ("-p", "caly-ipc", "--lib", "wire_ops"),
]
JUDGE_TIMEOUT_SECS = 180


def digest(path):
    return hashlib.sha256(pathlib.Path(path).read_bytes()).hexdigest()


def sweep_strays():
    for path in ROOT.rglob("*.r76bak"):
        print(f"  note  sweeping stale {path}")
        path.unlink()


def run_judge():
    for judge in JUDGE:
        begin = time.time()
        proc = subprocess.Popen(
            ["cargo", "test", "-q", *judge],
            cwd=ROOT,
            env=ENV,
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            text=True,
            start_new_session=True,
        )
        try:
            out, _ = proc.communicate(timeout=JUDGE_TIMEOUT_SECS)
        except subprocess.TimeoutExpired:
            os.killpg(proc.pid, 9)
            proc.wait()
            return None, time.time() - begin, "HANG"
        ok = "0 failed" in (out or "") and "test result: ok" in (out or "")
        return ok, time.time() - begin, ""


def apply(needle, replacement):
    # Always snapshot the pristine file first. M1 restores and deletes BAK, so M2 must
    # re-snapshot before mutating — the old `backup_taken` flag skipped the copy when the
    # backup was already gone, which left M2's mutation in the tree after "restore".
    text = WIRE_OPS.read_text()
    assert text.count(needle) == 1, f"needle not unique: {needle!r}"
    shutil.copy2(WIRE_OPS, BAK)
    WIRE_OPS.write_text(text.replace(needle, replacement))


def restore():
    if BAK.exists():
        shutil.copy2(BAK, WIRE_OPS)
        BAK.unlink()


M1_OLD = 'fields(\n            "profiles.apply",'
M1_NEW = 'fields(\n            "profiles.applyx",'

M2_OLD = '("profile_id", request.profile_id.0.clone()),'
M2_NEW = '("profile", request.profile_id.0.clone()),'


def main():
    sweep_strays()
    results = []

    # M1: typo the wire name.
    apply(M1_OLD, M1_NEW)
    ok, secs, note = run_judge()
    results.append(("M1", "the wire name is typo'd (must bite)", ok, secs, note))
    restore()

    # M2: typo the required record name.
    apply(M2_OLD, M2_NEW)
    ok, secs, note = run_judge()
    results.append(("M2", "a required record name is typo'd (must bite)", ok, secs, note))
    restore()

    all_bite = True
    for name, label, bit, secs, note in results:
        if note:
            print(f"  {'ok' if not bit else 'MISS'}    {name} {label} ({note} in {secs:.1f}s)")
        else:
            print(f"  {'ok' if not bit else 'MISS'}    {name} {label} (bite in {secs:.1f}s)")
        if bit:
            all_bite = False
    # The judges must FAIL (bit) under each mutation; `bit` = judge passed = missed.
    print(f"all mutations behaved as predicted: {all_bite}")
    return 0 if all_bite else 1


if __name__ == "__main__":
    sys.exit(main())
