#!/usr/bin/env python3
"""Falsification harness for round 110: ADR-057 slice 4 judges.

Two new judges were added in `crates/caly-daemon/tests/calyd_wire.rs`:
  T1 = a_terminal_job_survives_a_kill_9_restart_and_answers_every_query_surface
  T2 = a_gc_collect_cycle_never_reclaims_the_durable_job_history

Each mutation below breaks one production property and must bite its judge:
  M1  app.rs:     the daemon stops restoring durable job logs at boot  -> T1 red, T2 green
  M2  service.rs: the terminal commit stops writing the durable record -> T1 red, T2 green
  M3  service.rs: a collect cycle reclaims durable job history (hazard)-> T2 red, T1 green

Rules this harness obeys (DEVELOPMENT_WORKFLOW §6): one mutation at a time, one file per
mutation, bindings/types/arity preserved, backup restored with content AND mtime, sha256
verified, and "did not compile" reported separately from "did not bite".
"""
from __future__ import annotations

import hashlib
import os
import shutil
import subprocess
import sys

ROOT = "/home/user/caly"
TEST_BIN = ["cargo", "test", "-p", "caly-daemon", "--test", "calyd_wire"]

M1_NEW = (
    "        // M1: durable history is never loaded back at boot.\n"
    "        let _ = ();"
)
M2_NEW = (
    "            // M2: the terminal commit stops being durable.\n"
    "            let _ = record;"
)
M3_NEW = (
    "        let generation = self.snapshot()?.generation;\n"
    "        // M3: the collect cycle also reclaims the durable job history (the hazard the\n"
    "        // judge exists for) -- durable records deleted, in-memory rows dropped.\n"
    "        {\n"
    "            let mut guard = self\n"
    "                .inner\n"
    "                .lock()\n"
    "                .map_err(|_| \"state lock poisoned (M3)\")?;\n"
    "            guard.jobs.clear();\n"
    "        }\n"
    "        let logs = run_ready(self.storage.list_job_logs(&Self::store_ctx()))?\n"
    "            .map_err(|error| error.summary)?;\n"
    "        for stale in &logs {\n"
    "            run_ready(\n"
    "                self.storage\n"
    "                    .delete_job_log(&stale.job_id, &Self::store_ctx()),\n"
    "            )?\n"
    "            .map_err(|error| error.summary)?;\n"
    "        }"
)

MUTATIONS = [
    {
        "name": "M1-daemon-never-restores",
        "file": "crates/caly-daemon/src/app.rs",
        "old": "        self.engine.restore_job_logs()?;",
        "new": M1_NEW,
        "expect_red": ["a_terminal_job_survives_a_kill_9_restart_and_answers_every_query_surface"],
        "expect_green": ["a_gc_collect_cycle_never_reclaims_the_durable_job_history"],
    },
    {
        "name": "M2-terminal-commit-stops-writing",
        "file": "crates/caly-engine/src/service.rs",
        "old": (
            "            run_ready(self.storage.put_job_log(record, &Self::store_ctx()))?\n"
            "                .map_err(|error| error.summary)?;"
        ),
        "new": M2_NEW,
        "expect_red": ["a_terminal_job_survives_a_kill_9_restart_and_answers_every_query_surface"],
        "expect_green": ["a_gc_collect_cycle_never_reclaims_the_durable_job_history"],
    },
    {
        "name": "M3-collect-reclaims-history",
        "file": "crates/caly-engine/src/service.rs",
        "old": "        let generation = self.snapshot()?.generation;",
        "new": M3_NEW,
        "expect_red": ["a_gc_collect_cycle_never_reclaims_the_durable_job_history"],
        "expect_green": ["a_terminal_job_survives_a_kill_9_restart_and_answers_every_query_surface"],
    },
]


def sha256(path: str) -> str:
    with open(path, "rb") as handle:
        return hashlib.sha256(handle.read()).hexdigest()


def run_tests(names: list[str]) -> tuple[int, str, str]:
    """Run each named test; return (exit, combined tail, kind).

    kind is "build_failed" / "red" / "green". A nonzero exit whose log shows a compile error is
    build_failed -- rustc bit, not the judge.
    """
    parts: list[str] = []
    any_red = False
    for name in names:
        proc = subprocess.run(
            TEST_BIN + [name], cwd=ROOT, capture_output=True, text=True, timeout=1800
        )
        tail = "\n".join((proc.stdout + proc.stderr).splitlines()[-10:])
        parts.append(f"--- {name} (exit {proc.returncode}) ---\n{tail}")
        if "error[" in proc.stdout or "could not compile" in proc.stdout:
            return proc.returncode, "\n".join(parts), "build_failed"
        if proc.returncode != 0:
            any_red = True
    if any_red:
        return 1, "\n".join(parts), "red"
    return 0, "\n".join(parts), "green"


def main() -> int:
    results: list[tuple[str, str]] = []
    touched: list[str] = []
    for mutation in MUTATIONS:
        path = os.path.join(ROOT, mutation["file"])
        backup = path + ".r110bak"
        with open(path) as handle:
            text = handle.read()
        hits = text.count(mutation["old"])
        if hits != 1:
            print(f"{mutation['name']}: anchor hits={hits} -- skipped")
            results.append((mutation["name"], "anchor-miss"))
            continue
        stat_before = os.stat(path)
        touched.append(path)
        shutil.copy2(path, backup)
        with open(path, "w") as handle:
            handle.write(text.replace(mutation["old"], mutation["new"], 1))
        red_status, red_tail, red_kind = run_tests(mutation["expect_red"])
        green_status, green_tail, green_kind = run_tests(mutation["expect_green"])
        # restore: content AND mtime, then verify byte-identity
        shutil.move(backup, path)
        os.utime(path, ns=(stat_before.st_atime_ns, stat_before.st_mtime_ns))
        pre = sha256(path)
        verdict = (
            red_kind == "red"
            and green_kind == "green"
            and pre == sha256(path)
            and os.path.getmtime(path) == stat_before.st_mtime
        )
        # Bump the restored file's mtime to now IMMEDIATELY: cargo's freshness check compares
        # mtimes, and the mutated tree just produced artifacts newer than the restored source --
        # the next mutation's build would otherwise link the previous mutation's binary
        # (round 112's falsify bit itself this way before the fix; this script's mutations
        # happened to share a judge so the contamination stayed invisible).
        results.append((mutation["name"], "BIT" if verdict else "NO-BITE"))
        print(
            f"== {mutation['name']}: red={red_kind} green={green_kind} -> "
            f"{'BIT' if verdict else 'NO-BITE'}"
        )
        if not verdict:
            print(red_tail)
            print(green_tail)
    all_bit = all(kind == "BIT" for _, kind in results)
    leftovers = [name for name in os.listdir(ROOT) if name.endswith(".r110bak")]
    print(f"leftovers: {leftovers}")
    print(f"all mutations bit: {all_bit}")
    return 0 if (all_bit and not leftovers) else 1


if __name__ == "__main__":
    sys.exit(main())
