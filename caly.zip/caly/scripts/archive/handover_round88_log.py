#!/usr/bin/env python3
"""Round 88 (environment handover) documentation patch.

One-shot doc surgery per CONTINUATION_PLAYBOOK §6: patch files are written as
python (not heredoc regex), each anchor is asserted to exist exactly once, and
the file is written a single time.

This round is an *environment reconstruction* round (the workspace shipped with
no toolchain and no pinned core assets), not a behavior-changing code round:
the 813-test / 31-clippy gate is restored to the documented snapshot and the
only written record is the onboarding log. No TEST_FLOOR / census / code change.
"""

import pathlib

ROOT = pathlib.Path(__file__).resolve().parents[1]
NOTES = ROOT / "docs" / "docs/history/ONBOARDING_NOTES.md"

text = NOTES.read_text(encoding="utf-8")

# --- 1. New §4.162 entry, appended after §4.161 (history is append-only, §6.7) ----
anchor_4161_end = "  若日后找回原件，sha256 对得上再替换——本轮不把合成信封钉进 `real_core.rs`。\n---\n"
entry_4162 = anchor_4161_end + """
### 4.162 接续沙箱（第八十八轮）再验证：资产恢复规程 §4.156/§4.160 仍然有效，但 `subscription-20260803.txt` 这次随包在

- **Observed**：第八十八轮接手的沙箱里 cargo 不在 PATH（按 playbook §8 用 rustup 1.98.0
  minimal + rustfmt/clippy 恢复），`assets/cores` 与 `assets/geo` 仍为空目录。首次全量
  `cargo test --workspace --no-fail-fast` 实测 **794 passed / 19 failed**，失败面与
  §4.156 记录同形但比它多一个文件：`caly-daemon` lib `effect_std` 2、
  `caly-daemon` 集成 `real_apply` 9 / `spawn_artifacts` 2、`caly-io-std` `real_core` 3、
  `caly-mihomo` `selfcheck` 1、`caly-singbox` `pinned_asset` 1 / `selfcheck` 1
  ——全部是「缺资产=按名红」设计（`asset-read` 先于 digest 比对），无一个属于代码回归。
  其余约 794 个测试全绿。
- **与旧记录的唯一差异**：§4.161 说 `caly.zip` 不带 `fixtures/subscription-20260803.txt`，
  但本轮交付物里该文件**已存在**（2,210 字节、30 个 `://` 节点行、含
  `rezerv23.yunus.guru` 与 `47.86.167.194`，与 §4.161 的 oracle 一致），
  `source_inspection` / `source_durable` / pipeline `source.rs` 开箱即绿。该恢复步骤
  在本快照上不再需要；规程本身保留（未来更瘦的交付物仍会缺它）。
- **Recovery（本轮照做，验证规程未腐）**：mihomo `v1.19.30` gz 与 sing-box `1.13.20`
  tgz 从官方 GitHub release 直取；`geoip.metadb`/`geosite.dat` 按 §4.160 从
  `MetaCubeX/meta-rules-dat` 的 dangling `before` SHA
  `cfefb6cf68a23d8faadc6e15901dd68693d6a01a` 取回（jsdelivr `@release` 已是 08-30 滚动版）。
  四文件 sha256 与钉死常量逐字相等：mihomo `cf06ce2c…`、sing-box `646bc01b…`、
  geoip `08492c6d…`、geosite `ddc131ca…`。恢复后 `real_apply` 10/10（含 example.com
  经 ActiveCore 取回，72s）、`spawn_artifacts` 2/2、`real_core` 3/3、`effect_std` 2/2。
- **Disposition**：①环境缺失先按名查资产/工具链，不要先怀疑代码——§4.156 的判据
  （`expected binary-digest-mismatch, got asset-read`）本轮再次成立；②geo 滚动数据的
  恢复路径是 Events `before` SHA，不是 jsdelivr 最新节点；③本环境 1.9 GiB 内存 / 2 vCPU，
  真核 E2E 串行跑约 90s，完整 `check.sh`（两次 clippy 冷编）约 4–5 分钟，排期按此。

---
"""
assert text.count(anchor_4161_end) == 1, "§4.161 end anchor not found exactly once"
text = text.replace(anchor_4161_end, entry_4162, 1)

# --- 2. Disposition ledger row 6.114 (ledger numbering must stay continuous) ---------
# Rows are stored newest-first after the 6.9x block; 6.113 (round 87) is the current head.
anchor_6113 = "| 6.113 | 第八十七轮："
row_6114 = """| 6.114 | 第八十八轮（**环境接手轮，零生产代码改动**）：新沙箱无工具链且 `assets/` 为空——重装 rustup 1.98.0 minimal+rustfmt/clippy（playbook §8），按 §4.156/§4.160 重建四份钉死资产（mihomo v1.19.30 gz、sing-box 1.13.20 tgz 官方 release；geoip/geosite 从 dangling `before` SHA `cfefb6cf…` 取回），四个 sha256 与裁判常量逐字全等；fixture `subscription-20260803.txt` 本轮**随包存在**（§4.161 记录的缺失在本快照不再复现，规程保留）。量选实测首跑 794 passed / 19 failed，失败面=7 个资产依赖测试文件全红（`asset-read` 按名），资产就位后 `scripts/check.sh` 全绿：**813 tests (floor 813) / clippy 31 / fmt clean / 0 warning**，real_apply 10、spawn_artifacts 2、real_core 3、effect_std 2 定向全过。无新 ADR、无测试数变动、无生产代码改动；留档仅本日志（§4.162）。下一轮靶子维持 ROADMAP §13：共享 timeout scheduler / typed `send_request_frame` / SessionRegistry 生产化。 | §4.162 |
"""
assert text.count(anchor_6113) == 1, "6.113 row anchor not found exactly once"
text = text.replace(anchor_6113, row_6114 + anchor_6113, 1)

NOTES.write_text(text, encoding="utf-8")
print("patched:", NOTES)
