"""Falsification harness for round 59 (Http route honesty; the proxy door probe).

Same discipline as rounds 16/32–58: one mutation per run, exact-anchor replacement with
`assert count == 1`, restore by content and mtime, sha256-verified, stale `*.r59bak`
swept at startup. A mutation that cannot compile proves nothing (`§4.112`); backups are
per-mutation (`§4.137`); each cargo run carries a hard timeout (`§4.139`). Real cores
that outlive their judge are swept (both core patterns, split — `§4.143`).

Five mutations, each bitten by a judge this round created:

- M1  a mihomo spawn stops publishing its mixed port — the ActiveCore route has no
      address and the end-to-end judge's through-the-core fetch fails by name;
- M2  ActiveCore silently resolved-and-dialled direct (the round's founding lie, back) —
      the stub judge never sees the absolute-form request;
- M3  SystemProxy silently goes direct — the named-refusal judge goes looking for words
      that are no longer spoken;
- M4  shutdown stops clearing the route — a stopped core leaves a dangling address and
      the judge's post-stop fetch dials a freed port instead of failing by name;
- M5  the mihomo render stops emitting passthrough protocol params — the core's own
      `-t` refuses the passwordless artifact.

Usage: `python3 scripts/archive/falsify_round59.py` (exit 0 = every mutation bit, every file restored).
"""

import hashlib
import os
import pathlib
import shutil
import subprocess
import sys
import time

ROOT = pathlib.Path("/home/user/caly")
ENV = dict(os.environ)
ENV["PATH"] = str(pathlib.Path.home() / ".cargo/bin") + ":" + ENV.get("PATH", "")
SRC = {
    "effect_std": ROOT / "crates/caly-daemon/src/effect_std.rs",
    "http": ROOT / "crates/caly-io-std/src/http.rs",
    "mihomo": ROOT / "crates/caly-mihomo/src/adapter.rs",
}

M2_DIRECT_ARM = """                FetchRoute::{arm} => {{
                    let address: SocketAddr = (parsed.host.as_str(), parsed.port)
                        .to_socket_addrs()
                        .map_err(|error| {{
                            Self::fault(
                                IoFaultKind::Unavailable,
                                format!("resolve {}: {{error}}", parsed.host),
                            )
                        }})?
                        .next()
                        .ok_or_else(|| {{
                            Self::fault(
                                IoFaultKind::Unavailable,
                                format!("resolve {}: no address", parsed.host),
                            )
                        }})?;
                    (address, false)
                }}"""

MUTATIONS = [
    (
        "M1 mihomo spawn hides its mixed port",
        "effect_std",
        """                // The core answers proxy requests on its mixed inbound from now on.
                self.set_core_route(Some(mixed_port));""",
        """                let _ = mixed_port;""",
        [
            "a_fetch_through_the_active_core_really_rides_the_core",
        ],
    ),
    (
        "M2 ActiveCore silently goes direct",
        "http",
        """                FetchRoute::ActiveCore => {
                    let source = self.core_route.as_ref().ok_or_else(|| {
                        Self::fault(
                            IoFaultKind::Unavailable,
                            "the ActiveCore route has no core route source wired on this \\
                             adapter — refusing rather than silently going direct (ADR-047 §2)",
                        )
                    })?;
                    let guarded = source
                        .lock()
                        .map_err(|_| Self::poisoned("core route source"))?;
                    let address = guarded.ok_or_else(|| {
                        Self::fault(
                            IoFaultKind::Unavailable,
                            "no live core to route through: the ActiveCore route needs a \\
                             spawned core (ADR-047 §2)",
                        )
                    })?;
                    (address, true)
                }""",
        M2_DIRECT_ARM.replace("{arm}", "ActiveCore"),
        [
            "active_core_sends_an_absolute_form_proxy_request",
        ],
    ),
    (
        "M3 SystemProxy silently goes direct",
        "http",
        """                FetchRoute::SystemProxy => {
                    return Err(Self::fault(
                        IoFaultKind::Unsupported,
                        "system-proxy resolution is not implemented on this adapter; refusing \\
                         by name rather than silently going direct (ADR-047 §2)",
                    ));
                }""",
        M2_DIRECT_ARM.replace("{arm}", "SystemProxy"),
        [
            "system_proxy_is_refused_by_name_not_silently_direct",
        ],
    ),
    (
        "M4 shutdown leaves the route dangling",
        "effect_std",
        """        // The route closes with the core (`ADR-047 §2`): shutdown bypasses the plan path,
        // but the honesty rule is the same — no live core, no route to a freed port.
        self.set_core_route(None);""",
        """        let _ = &self.core_route;""",
        [
            "a_fetch_through_the_active_core_really_rides_the_core",
        ],
    ),
    (
        "M5 mihomo render drops passthrough params",
        "mihomo",
        """        for (key, value) in &node.passthrough {
            lines.push(format!("    {key}: {value}"));
        }""",
        """        let _ = &node.passthrough;""",
        [
            "the_rendered_artifact_passes_the_cores_own_config_test",
        ],
    ),
]


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def sweep_stray_cores():
    for pattern in ("caly-ru" "n.yaml", "sing-box" " run"):
        subprocess.run(
            ["pkill", "-f", pattern],
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
        )
    time.sleep(1.0)  # a kill is not done until a beat has passed


def run_cargo():
    argvs = [
        ["cargo", "test", "-p", "caly-io-std", "--test", "http_route", "--no-fail-fast"],
        ["cargo", "test", "-p", "caly-mihomo", "--test", "selfcheck", "--no-fail-fast"],
        ["cargo", "test", "-p", "caly-daemon", "--test", "real_apply", "--no-fail-fast"],
    ]
    failed = []
    tail = ""
    for argv in argvs:
        try:
            proc = subprocess.run(
                argv,
                cwd=str(ROOT),
                env=ENV,
                capture_output=True,
                text=True,
                timeout=900,  # §4.139
            )
        except subprocess.TimeoutExpired:
            return 124, [], "TIMEOUT: the mutation wedged the suite (§4.139) — redesign it"
        out = proc.stdout + proc.stderr
        tail += out[-2000:]
        failed += [
            line[5:].split(" ... ")[0].split("::")[-1].strip()
            for line in out.splitlines()
            if line.startswith("test ") and line.rstrip().endswith("... FAILED")
        ]
    return 0, sorted(set(failed)), tail


def main():
    for path in ROOT.rglob("*.r59bak"):
        original = pathlib.Path(str(path)[: -len(".r59bak")])
        shutil.move(str(path), str(original))
        print("swept leftover backup:", path.name)
    sweep_stray_cores()

    originals = {name: digest(path) for name, path in SRC.items()}
    results = []
    bad = False
    for label, key, old, new, expected in MUTATIONS:
        path = SRC[key]
        backup = pathlib.Path(str(path) + ".r59bak")
        shutil.copyfile(path, backup)  # per-mutation backup (§4.137)
        s = path.read_text()
        assert s.count(old) == 1, "%s: anchor x%d" % (label, s.count(old))
        try:
            path.write_text(s.replace(old, new, 1))
            code, failed, out = run_cargo()
            wedged = code == 124
            red = [name for name in expected if name in failed]
            compile_error = "error[" in out or "could not compile" in out
            ok = bool(red) and not compile_error and not wedged
            results.append((label, ok))
            print("%-42s %s  red=%s" % (label, "BIT" if ok else "NO EFFECT", red or failed[:4]))
            if not ok:
                if compile_error:
                    print("   !! the mutation did not compile; it proves nothing")
                if wedged:
                    print("   !! the mutation wedged the suite; it proves nothing (§4.139)")
                print("   output tail:\n", out[-1200:])
        finally:
            shutil.move(str(backup), str(path))
            os.utime(path, None)
            assert digest(path) == originals[key], "%s: restore did not reproduce the file" % label
            sweep_stray_cores()

    print("\n== summary ==")
    for label, ok in results:
        print("%-42s %s" % (label, "bit" if ok else "DID NOT BIT"))
        if not ok:
            bad = True
    print("all mutations bit:", not bad)
    sys.exit(1 if bad else 0)


if __name__ == "__main__":
    main()
