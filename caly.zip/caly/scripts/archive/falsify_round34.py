"""Falsification harness for round 34 (the cumulative byte budget at the store seam).

Same discipline as `falsify_round16/32/33`: one mutation per run, one file per mutation,
exact-anchor replacement with `assert count == 1`, restore by content and mtime,
sha256-verified, stale `*.r34bak` swept at startup. A mutation that fails to compile proves
nothing (`§4.112`) and is reported, not counted.

The eight mutations are `ADR-039 §2` step 2's doors stated as removals: the write admission
(size known up front, refused before any byte lands), the write charge, the read admission
("is anything left"), the read charge -- on the durable backend and the memory backend each --
plus the one wording both backends share.

Usage: `python3 scripts/archive/falsify_round34.py` (exit 0 = every mutation bit, every file restored).
"""

import hashlib
import os
import pathlib
import shutil
import subprocess
import sys

ROOT = pathlib.Path("/home/user/caly")
ENV = dict(os.environ)
ENV["PATH"] = str(pathlib.Path.home() / ".cargo/bin") + ":" + ENV.get("PATH", "")
SRC = {
    "fs_store": ROOT / "crates/caly-storage/src/fs_store.rs",
    "memory": ROOT / "crates/caly-storage/src/memory.rs",
    "budget": ROOT / "crates/caly-io/src/budget.rs",
}

MUTATIONS = [
    (
        "M1 fs write admission lost",
        "fs_store",
        "        caly_io::budget::admit_bytes(ctx, suffix, bytes.len() as u64).map_err(from_iofault)?;",
        "        let _ = caly_io::budget::admit_bytes(ctx, suffix, bytes.len() as u64);",
        ["a_write_that_would_cross_the_callers_budget_is_refused_before_it_lands"],
    ),
    (
        "M2b fs write charge lost (verification read still charges)",
        "fs_store",
        "        caly_io::budget::charge(ctx, moved);",
        "        let _ = moved;",
        ["a_write_charges_the_bytes_it_wrote_not_just_the_verification_read"],
    ),
    (
        "M3 fs read admission lost",
        "fs_store",
        "        caly_io::budget::admit_unit(ctx, suffix).map_err(from_iofault)?;",
        "        let _ = caly_io::budget::admit_unit(ctx, suffix);",
        ["a_read_charges_what_it_moved_and_the_next_unit_refuses"],
    ),
    (
        "M4 fs read charge lost",
        "fs_store",
        "                caly_io::budget::charge(ctx, bytes.len() as u64);",
        "                let _: u64 = bytes.len() as u64;",
        ["a_read_charges_what_it_moved_and_the_next_unit_refuses"],
    ),
    (
        "M5 memory write admission lost",
        "memory",
        """            caly_io::budget::admit_bytes(ctx, &intent.source_label, intent.payload.len() as u64)
                .map_err(|fault| {
                    StorageError::new(
                        StorageErrorKind::CapacityExceeded,
                        fault.summary,
                    )
                })?;""",
        "            let _ = caly_io::budget::admit_bytes(ctx, &intent.source_label, intent.payload.len() as u64);",
        ["both_backends_answer_the_budget_door_the_same_way"],
    ),
    (
        "M6 memory read admission lost",
        "memory",
        """            caly_io::budget::admit_unit(ctx, &digest).map_err(|fault| {
                StorageError::new(StorageErrorKind::CapacityExceeded, fault.summary)
            })?;""",
        "            let _ = caly_io::budget::admit_unit(ctx, &digest);",
        ["a_memory_read_charges_and_then_refuses_new_units"],
    ),
    (
        "M7 memory read charge lost",
        "memory",
        "            caly_io::budget::charge(ctx, payload.len() as u64);",
        "            let _: u64 = payload.len() as u64;",
        ["a_memory_read_charges_and_then_refuses_new_units"],
    ),
    (
        "M8 the shared refusal loses the word cumulative",
        "budget",
        '"{resource} would take this caller past its cumulative io_budget.max_bytes = {cap} \\',
        '"{resource} would take this caller past its io_budget.max_bytes = {cap} \\',
        ["a_write_that_would_cross_the_callers_budget_is_refused_before_it_lands"],
    ),
]


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def run_cargo():
    proc = subprocess.run(
        ["cargo", "test", "-p", "caly-storage", "--no-fail-fast"],
        cwd=str(ROOT),
        env=ENV,
        capture_output=True,
        text=True,
    )
    out = proc.stdout + proc.stderr
    failed = sorted(
        {
            line[5:].split(" ... ")[0].split("::")[-1].strip()
            for line in out.splitlines()
            if line.startswith("test ") and line.rstrip().endswith("... FAILED")
        }
    )
    return proc.returncode, failed, out


def main():
    for path in ROOT.rglob("*.r34bak"):
        original = pathlib.Path(str(path)[: -len(".r34bak")])
        shutil.move(str(path), str(original))
        print("swept leftover backup:", path.name)

    originals = {name: digest(path) for name, path in SRC.items()}
    results = []
    bad = False
    for label, key, old, new, expected in MUTATIONS:
        path = SRC[key]
        s = path.read_text()
        assert s.count(old) == 1, "%s: anchor x%d" % (label, s.count(old))
        backup = pathlib.Path(str(path) + ".r34bak")
        shutil.copyfile(path, backup)
        try:
            path.write_text(s.replace(old, new, 1))
            code, failed, out = run_cargo()
            red = [name for name in expected if name in failed]
            compile_error = "error[" in out or "could not compile" in out
            ok = bool(red) and not compile_error
            results.append((label, ok))
            print("%-46s %s  red=%s" % (label, "BIT" if ok else "NO EFFECT", red or failed[:4]))
            if not ok:
                if compile_error:
                    print("   !! the mutation did not compile; it proves nothing")
                print("   output tail:\n", out[-1200:])
        finally:
            shutil.move(str(backup), str(path))
            os.utime(path, None)
            assert digest(path) == originals[key], "%s: restore did not reproduce the file" % label

    print("\n== summary ==")
    for label, ok in results:
        print("%-46s %s" % (label, "bit" if ok else "DID NOT BIT"))
        if not ok:
            bad = True
    print("all mutations bit:", not bad)
    sys.exit(1 if bad else 0)


if __name__ == "__main__":
    main()
