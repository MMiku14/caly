"""Falsification harness for round 33 (the caller's context at the store seam).

Same discipline as `scripts/archive/falsify_round16.py` / `falsify_round32.py`: one mutation per run,
one file per mutation, exact-anchor replacement with `assert count == 1`, restore by content and
mtime, sha256-verified, stale `*.r33bak` swept at startup. "Red" is read from cargo's own
`... FAILED` lines; a mutation that fails to compile proves nothing (`§4.112`) and is reported as
such rather than counted.

The six mutations are `ADR-039`'s step-1 properties stated as removals: the walk's cancellation
gate (up-front and between levels are the same `spend`), the memory-side cancellation doors, the
fabricated-identity ghost the ADR exists to bury, and the error kind that keeps "cancelled"
distinct from "failed".

Usage: `python3 scripts/archive/falsify_round33.py` (exit 0 = every mutation bit, every file restored).
"""

import hashlib
import os
import pathlib
import shutil
import subprocess
import sys

ROOT = pathlib.Path("/home/user/caly")
ENV = dict(os.environ)
ENV["PATH"] = str(pathlib.Path.home() / ".cargo/bin") + ":" + ENV.get("PATH", "")
SRC = {
    "fs_store": ROOT / "crates/caly-storage/src/fs_store.rs",
    "memory": ROOT / "crates/caly-storage/src/memory.rs",
}

MUTATIONS = [
    (
        "M1 the walk's spend gate loses its cancellation check",
        "fs_store",
        """    let spend = |visited: &mut usize| -> Result<(), StorageError> {
        if ctx.cancel.is_cancelled() {""",
        """    let spend = |visited: &mut usize| -> Result<(), StorageError> {
        if false && ctx.cancel.is_cancelled() {""",
        ["a_cancellation_that_arrives_mid_walk_stops_the_next_level"],
    ),
    (
        "M2 memory's walk loses its cancellation door",
        "memory",
        """            // Same door as the fs walk's first spend (`ADR-039 §2.3`): a cancelled caller is
            // refused before the unit starts. The contract suite pins both backends to one answer.
            if ctx.cancel.is_cancelled() {""",
        """            // Same door as the fs walk's first spend (`ADR-039 §2.3`): a cancelled caller is
            // refused before the unit starts. The contract suite pins both backends to one answer.
            if false && ctx.cancel.is_cancelled() {""",
        ["a_cancelled_caller_is_refused_the_same_way_on_both_backends"],
    ),
    (
        "M3 fs delete_content loses its cancellation door",
        "fs_store",
        """            // A cancelled context refuses the unit before it starts (`ADR-039 §2.3`); deleting is
            // exactly the kind of work that must not begin under a withdrawn call.
            if ctx.cancel.is_cancelled() {""",
        """            // A cancelled context refuses the unit before it starts (`ADR-039 §2.3`); deleting is
            // exactly the kind of work that must not begin under a withdrawn call.
            if false && ctx.cancel.is_cancelled() {""",
        ["a_cancelled_caller_is_refused_the_same_way_on_both_backends"],
    ),
    (
        "M4 memory delete_content loses its cancellation door",
        "memory",
        """            // Same door as fs-store's, same reason (`ADR-039 §2.3`).
            if ctx.cancel.is_cancelled() {""",
        """            // Same door as fs-store's, same reason (`ADR-039 §2.3`).
            if false && ctx.cancel.is_cancelled() {""",
        ["a_cancelled_caller_is_refused_the_same_way_on_both_backends"],
    ),
    (
        "M5 the walk hands the port a fabricated identity again",
        "fs_store",
        """            walk_content_tree(
                store.inner.fs.as_ref(),
                &store.inner.root,
                ctx,
                MAX_CONTENT_WALK_DIRECTORIES,
            )""",
        """            walk_content_tree(
                store.inner.fs.as_ref(),
                &store.inner.root,
                &caly_io::RequestContext::new(
                    caly_io::TraceId::new("storage"),
                    caly_io::Actor::System,
                ),
                MAX_CONTENT_WALK_DIRECTORIES,
            )""",
        ["the_port_sees_the_callers_trace_not_a_fabricated_ghost"],
    ),
    (
        "M6 the walk reports cancellation as busy",
        "fs_store",
        """            return Err(StorageError::new(
                StorageErrorKind::Cancelled,
                "the caller cancelled before this level of the content walk",
            ));""",
        """            return Err(StorageError::new(
                StorageErrorKind::Busy,
                "the caller cancelled before this level of the content walk",
            ));""",
        ["a_cancellation_that_arrives_mid_walk_stops_the_next_level"],
    ),
]


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def run_cargo():
    proc = subprocess.run(
        ["cargo", "test", "-p", "caly-storage", "--no-fail-fast"],
        cwd=str(ROOT),
        env=ENV,
        capture_output=True,
        text=True,
    )
    out = proc.stdout + proc.stderr
    failed = sorted(
        {
            line[5:].split(" ... ")[0].split("::")[-1].strip()
            for line in out.splitlines()
            if line.startswith("test ") and line.rstrip().endswith("... FAILED")
        }
    )
    return proc.returncode, failed, out


def main():
    for path in ROOT.rglob("*.r33bak"):
        original = pathlib.Path(str(path)[: -len(".r33bak")])
        shutil.move(str(path), str(original))
        print("swept leftover backup:", path.name)

    originals = {name: digest(path) for name, path in SRC.items()}
    results = []
    bad = False
    for label, key, old, new, expected in MUTATIONS:
        path = SRC[key]
        s = path.read_text()
        assert s.count(old) == 1, "%s: anchor x%d" % (label, s.count(old))
        backup = pathlib.Path(str(path) + ".r33bak")
        shutil.copyfile(path, backup)
        try:
            path.write_text(s.replace(old, new, 1))
            code, failed, out = run_cargo()
            red = [name for name in expected if name in failed]
            compile_error = "error[" in out or "could not compile" in out
            ok = bool(red) and not compile_error
            results.append((label, ok))
            print("%-52s %s  red=%s" % (label, "BIT" if ok else "NO EFFECT", red or failed[:4]))
            if not ok:
                if compile_error:
                    print("   !! the mutation did not compile; it proves nothing")
                print("   output tail:\n", out[-1200:])
        finally:
            shutil.move(str(backup), str(path))
            os.utime(path, None)
            assert digest(path) == originals[key], "%s: restore did not reproduce the file" % label

    print("\n== summary ==")
    for label, ok in results:
        print("%-52s %s" % (label, "bit" if ok else "DID NOT BIT"))
        if not ok:
            bad = True
    print("all mutations bit:", not bad)
    sys.exit(1 if bad else 0)


if __name__ == "__main__":
    main()
