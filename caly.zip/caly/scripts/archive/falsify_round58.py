"""Falsification harness for round 58 (the sing-box spawn face; revival by identity).

Same discipline as rounds 16/32–57: one mutation per run, exact-anchor replacement with
`assert count == 1`, restore by content and mtime, sha256-verified, stale `*.r58bak`
swept at startup. A mutation that cannot compile proves nothing (`§4.112`); backups are
per-mutation (`§4.137`); each cargo run carries a hard timeout — a mutation that wedges
the suite counts as DID NOT BIT (`§4.139`). Real cores that outlive their judge are swept
(both core patterns, split in the harness so it never matches its own command line —
`§4.143`) with a sleep before the next verdict.

Five mutations, each bitten by a judge this round created:

- M1  the sing-box spawn skips its tar.gz digest check — the second core's supply-chain
      unit judge (spawn must refuse a binary the plan did not name) goes red;
- M2  the envelope stops merging the clash-api controller — no controller, no ApiReady,
      the end-to-end sing-box judge times out at the probe;
- M3  the render regresses to the legacy dns `address` shape — a shape sing-box 1.13.20
      FATALs on by default; the render judges hold the schema table;
- M4  the revival shape drops the sing-box arm — the cross-core rollback judge finds the
      revival silently skipped (no stage, no core);
- M5  the demo re-forces tun for sing-box — every sing-box apply dies at NetApply again
      and the end-to-end judge cannot complete.

Usage: `python3 scripts/archive/falsify_round58.py` (exit 0 = every mutation bit, every file restored).
"""

import hashlib
import os
import pathlib
import shutil
import subprocess
import sys
import time

ROOT = pathlib.Path("/home/user/caly")
ENV = dict(os.environ)
ENV["PATH"] = str(pathlib.Path.home() / ".cargo/bin") + ":" + ENV.get("PATH", "")
SRC = {
    "effect_std": ROOT / "crates/caly-daemon/src/effect_std.rs",
    "render": ROOT / "crates/caly-singbox/src/adapter.rs",
    "worker": ROOT / "crates/caly-engine/src/worker.rs",
    "apply": ROOT / "crates/caly-engine/src/apply.rs",
}

MUTATIONS = [
    (
        "M1 singbox spawn skips digest check",
        "effect_std",
        """        let core_sha256 = caly_common::digest::sha256_hex(&core_tgz);
        if binary_digest != core_sha256 {
            return Err(StepFailure::new(
                "binary-digest-mismatch",
                format!(
                    "the plan pins core binary {binary_digest}; this backend's asset \\
                     {} hashes to {core_sha256} — refusing to run a binary the plan \\
                     did not name",
                    self.assets.singbox_tgz
                ),
                false,
            ));
        }""",
        """        let core_sha256 = caly_common::digest::sha256_hex(&core_tgz);
        let _ = (core_sha256, binary_digest);""",
        [
            "singbox_spawn_refuses_a_binary_the_plan_did_not_name",
        ],
    ),
    (
        "M2 envelope omits the clash-api controller",
        "effect_std",
        """        if let Some(experimental) = config.get_mut("experimental").and_then(|v| v.as_object_mut())
        {
            experimental.insert(
                "clash_api".to_owned(),
                serde_json::json!({
                    "external_controller": format!("127.0.0.1:{controller_port}")
                }),
            );
        }""",
        """        let _ = &controller_port;""",
        [
            "singbox_profile_runs_a_real_second_core",
        ],
    ),
    (
        "M3 render regresses to legacy dns servers",
        "render",
        """        let tag = format!("dns-{}", index + 1);
        let kind = if server.starts_with("https://") { "https" } else { "udp" };
        let resolver = if server.parse::<std::net::IpAddr>().is_ok() {
            String::new()
        } else {
            format!(",\\"domain_resolver\\":\\"caly-local\\"")
        };
        dns_servers.push(format!(
            "{{\\"type\\":\\"{kind}\\",\\"tag\\":\\"{tag}\\",\\"server\\":\\"{server}\\"{resolver}}}"
        ));""",
        """        let tag = format!("dns-{}", index + 1);
        dns_servers.push(format!(
            "{{\\"tag\\":\\"{tag}\\",\\"address\\":\\"{server}\\"}}"
        ));""",
        [
            "render_emits_the_shapes_singbox_113_accepts",
        ],
    ),
    (
        "M4 revival shape drops the sing-box arm",
        "worker",
        """    } else if core_identity.starts_with("sing-box@") {
        Some((caly_plan::CoreKind::SingBox, "config.json"))
    } else {
        None
    }""",
        """    } else {
        None
    }""",
        [
            "rollback_revives_a_singbox_deployment_across_a_mihomo_interlude",
        ],
    ),
    (
        "M5 demo re-forces tun for sing-box",
        "apply",
        """    let wants_tun = request.profile_id.0.contains("tun");""",
        """    let wants_tun = request.profile_id.0.contains("tun") || matches!(target, CoreTarget::SingBox);""",
        [
            "singbox_profile_runs_a_real_second_core",
        ],
    ),
]


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def sweep_stray_cores():
    for pattern in ("caly-ru" "n.yaml", "sing-box" " run"):
        subprocess.run(
            ["pkill", "-f", pattern],
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
        )
    time.sleep(1.0)  # a kill is not done until a beat has passed


def run_cargo():
    argvs = [
        ["cargo", "test", "-p", "caly-daemon", "--lib", "--no-fail-fast"],
        ["cargo", "test", "-p", "caly-daemon", "--test", "real_apply", "--no-fail-fast"],
        ["cargo", "test", "-p", "caly-singbox", "--no-fail-fast"],
    ]
    failed = []
    tail = ""
    for argv in argvs:
        try:
            proc = subprocess.run(
                argv,
                cwd=str(ROOT),
                env=ENV,
                capture_output=True,
                text=True,
                timeout=900,  # §4.139
            )
        except subprocess.TimeoutExpired:
            return 124, [], "TIMEOUT: the mutation wedged the suite (§4.139) — redesign it"
        out = proc.stdout + proc.stderr
        tail += out[-2000:]
        failed += [
            line[5:].split(" ... ")[0].split("::")[-1].strip()
            for line in out.splitlines()
            if line.startswith("test ") and line.rstrip().endswith("... FAILED")
        ]
    return 0, sorted(set(failed)), tail


def main():
    for path in ROOT.rglob("*.r58bak"):
        original = pathlib.Path(str(path)[: -len(".r58bak")])
        shutil.move(str(path), str(original))
        print("swept leftover backup:", path.name)
    sweep_stray_cores()

    originals = {name: digest(path) for name, path in SRC.items()}
    results = []
    bad = False
    for label, key, old, new, expected in MUTATIONS:
        path = SRC[key]
        backup = pathlib.Path(str(path) + ".r58bak")
        shutil.copyfile(path, backup)  # per-mutation backup (§4.137)
        s = path.read_text()
        assert s.count(old) == 1, "%s: anchor x%d" % (label, s.count(old))
        try:
            path.write_text(s.replace(old, new, 1))
            code, failed, out = run_cargo()
            wedged = code == 124
            red = [name for name in expected if name in failed]
            compile_error = "error[" in out or "could not compile" in out
            ok = bool(red) and not compile_error and not wedged
            results.append((label, ok))
            print("%-46s %s  red=%s" % (label, "BIT" if ok else "NO EFFECT", red or failed[:4]))
            if not ok:
                if compile_error:
                    print("   !! the mutation did not compile; it proves nothing")
                if wedged:
                    print("   !! the mutation wedged the suite; it proves nothing (§4.139)")
                print("   output tail:\n", out[-1200:])
        finally:
            shutil.move(str(backup), str(path))
            os.utime(path, None)
            assert digest(path) == originals[key], "%s: restore did not reproduce the file" % label
            sweep_stray_cores()

    print("\n== summary ==")
    for label, ok in results:
        print("%-46s %s" % (label, "bit" if ok else "DID NOT BIT"))
        if not ok:
            bad = True
    print("all mutations bit:", not bad)
    sys.exit(1 if bad else 0)


if __name__ == "__main__":
    main()
