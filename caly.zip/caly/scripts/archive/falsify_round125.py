#!/usr/bin/env python3
"""Round 125 falsify: cross-process core adoption (ADR-060).

Four mutations break the adoption door from four sides: the start_time identity check is
skipped (a recycled pid would be adopted), the adopted instance is never installed (adoption
in name only), the foreign stop degenerates into an "already gone" lie (the adopted core is
left running), and a dead core's receipt is never cleared (next start adopts a corpse).

Each mutation rewrites `effect_std.rs`, runs a targeted red/green pair of library judges,
then restores byte-for-byte (sha256 + mtime bump). No bin builds needed: the judged behavior
lives in the library; the both-binaries flagship e2e is far slower and guards wiring the
falsify already pins here.
"""
import hashlib
import os
import subprocess
import sys

CALY = "/home/user/caly/caly"
EFFECT_STD = f"{CALY}/crates/caly-daemon/src/effect_std.rs"

JUDGE_ADOPT = "-p caly-daemon --test real_apply adoption_rebuilds_a_live_core_across_runtime_death_and_stops_it"
JUDGE_DEAD = "-p caly-daemon --test real_apply adoption_refuses_a_dead_core_and_clears_the_receipt"
JUDGE_RECYCLED = "-p caly-daemon --test real_apply adoption_refuses_a_recycled_pid_and_never_signals_the_process"
JUDGE_SILENT = "-p caly-daemon --test real_apply adoption_refuses_a_silent_controller_and_keeps_the_receipt"


def sha(path: str) -> str:
    return hashlib.sha256(open(path, "rb").read()).hexdigest()


def run(*args: str) -> tuple[int, str]:
    proc = subprocess.run(args, cwd=CALY, capture_output=True, text=True, timeout=900)
    return proc.returncode, proc.stdout + proc.stderr


def test(name: str, expect_ok: bool) -> str:
    code, out = run("cargo", "test", *name.split(), "--", "--test-threads=1")
    compiled = "error[" not in out and "error: " not in out
    passed = code == 0 and compiled
    if passed == expect_ok:
        return "GREEN" if expect_ok else "RED"
    verdict = "UNEXPECTED-RED" if expect_ok else "MISSED-BIT"
    tail = "\n".join(out.splitlines()[-14:])
    print(f"    [{verdict}] {name}\n    --------\n{tail}\n    --------")
    return verdict


MUTATIONS = [
    dict(
        name="M1 the start_time identity compare never fires (pid-only adoption)",
        old="""        let observed = observed.expect("proc_start_time answered above");
        if observed != receipt.start_time {""",
        new="""        let observed = observed.expect("proc_start_time answered above");
        if false {
            // (mutated: the identity compare can no longer fire; observed is now unused)
            let _ = &observed;""",
        red=[(JUDGE_RECYCLED, False)],
        green=[(JUDGE_ADOPT, True)],
    ),
    dict(
        name="M2 the adopted instance is never installed (adoption in name only)",
        old="""            state.instance.replace(LiveInstance {
                handle: caly_io::ChildHandle {
                    pid: receipt.pid,
                    instance_nonce: receipt.nonce.clone(),
                },""",
        new="""            drop(LiveInstance {
                handle: caly_io::ChildHandle {
                    pid: receipt.pid,
                    instance_nonce: receipt.nonce.clone(),
                },""",
        red=[(JUDGE_ADOPT, False)],
        green=[(JUDGE_DEAD, True)],
    ),
    dict(
        name="M3 the foreign stop pretends already-gone (the adopted core is left running)",
        old="""        let pid = live.handle.pid;
        let start_time = live.start_time.clone();
        match stopper(pid, &start_time, grace_ms) {""",
        new="""        let pid = live.handle.pid;
        let start_time = live.start_time.clone();
        let _ = (&stopper, pid, &start_time);
        match Ok::<ForeignStopOutcome, String>(ForeignStopOutcome::AlreadyGone) {""",
        red=[(JUDGE_ADOPT, False)],
        green=[(JUDGE_DEAD, True)],
    ),
    dict(
        name="M4 a dead core's receipt is never cleared",
        old="""        if !Self::proc_exists(receipt.pid) || observed.is_none() {
            self.clear_receipt();
            return Ok(AdoptionOutcome::CoreGone { pid: receipt.pid });""",
        new="""        if !Self::proc_exists(receipt.pid) || observed.is_none() {
            return Ok(AdoptionOutcome::CoreGone { pid: receipt.pid });""",
        red=[(JUDGE_DEAD, False)],
        green=[(JUDGE_SILENT, True)],
    ),
]


def main() -> int:
    leftovers: list[str] = []
    for mutation in MUTATIONS:
        path = EFFECT_STD
        original = open(path, "rb").read().decode()
        original_sha = hashlib.sha256(original.encode()).hexdigest()
        if mutation["old"] not in original:
            print(f"{mutation['name']}: ANCHOR NOT FOUND (skipped)")
            continue
        mutated = original.replace(mutation["old"], mutation["new"], 1)
        open(path, "w").write(mutated)
        os.utime(path, None)
        try:
            verdicts = []
            for name, expect in mutation["red"] + mutation["green"]:
                verdicts.append(test(name, expect))
            reds = verdicts[: len(mutation["red"])]
            greens = verdicts[len(mutation["red"]) :]
            ok = all(v == "RED" for v in reds) and all(v == "GREEN" for v in greens)
            print(
                f"{mutation['name']}: {'BIT' if ok else 'MISSED-BIT'} "
                f"(red={reds} green={greens})"
            )
        finally:
            open(path, "w").write(original)
            os.utime(path, None)
            if sha(path) != original_sha:
                leftovers.append(path)
    if leftovers:
        print(f"LEFTOVERS: {leftovers}")
        return 1
    print("leftovers: []")
    return 0


if __name__ == "__main__":
    sys.exit(main())
