#!/usr/bin/env python3
"""Round 121 falsify: the state-gap resume hint is a feedable cursor.

The wire field `resume_from` (and the CLI hint that passes it through) must be
an EXCLUSIVE request cursor: feeding it straight back into `--from` lands
exactly on the oldest retained line. Mutations break that from three sides:
the pump regressing to the raw retained edge, the cursor over-shooting into a
re-read of trimmed space, and the CLI hint mangling the value.

Each mutation rewrites one production file, runs a targeted red/green pair,
then restores byte-for-byte (sha256 + mtime bump). Binary-e2e judges are
preceded by an explicit build of the sibling binaries (round-120 lesson).
"""
import hashlib
import os
import subprocess
import sys

CALY = "/home/user/caly/caly"
JOB_STREAM_RS = f"{CALY}/crates/caly-daemon/src/job_stream.rs"
CALY_RS = f"{CALY}/crates/caly-cli/src/bin/caly.rs"

JUDGE_GAP = (
    "-p caly-daemon --lib "
    "job_stream::tests::a_gap_hands_back_a_cursor_that_lands_on_the_oldest_retained_line"
)
JUDGE_HINT = (
    "-p caly-cli --test caly_cli_e2e a_state_gap_end_names_the_cursor_to_resume_with"
)


def sha(path: str) -> str:
    return hashlib.sha256(open(path, "rb").read()).hexdigest()


def run(*args: str) -> tuple[int, str]:
    proc = subprocess.run(args, cwd=CALY, capture_output=True, text=True, timeout=900)
    return proc.returncode, proc.stdout + proc.stderr


def build_bins() -> None:
    code, out = run(
        "cargo", "build", "-p", "caly-daemon", "--bin", "calyd", "-p", "caly-cli", "--bin", "caly"
    )
    if code != 0:
        sys.exit(f"binaries failed to build:\n{out[-4000:]}")


def test(name: str, expect_ok: bool) -> str:
    build_bins()
    code, out = run("cargo", "test", *name.split())
    if code == 0 and "error[" in out:
        code = 1
    passed = code == 0
    if passed == expect_ok:
        return "GREEN" if expect_ok else "RED"
    return "UNEXPECTED-RED" if expect_ok else "MISSED-BIT"


MUTATIONS = [
    dict(
        name="M1 the gap regresses to the raw retained edge (hint skips the oldest line)",
        file=JOB_STREAM_RS,
        old="""            return PumpStep::Gap {
                resume_from: page.retained_from_event_index.saturating_sub(1),
            };""",
        new="""            return PumpStep::Gap {
                resume_from: page.retained_from_event_index,
            };""",
        red=[
            (JUDGE_GAP, False),
        ],
        green=[
            # A non-gap pump path has no stake in the hint arithmetic.
            ("-p caly-daemon --lib job_stream::tests::a_terminal_job_flushes_then_ends", True),
        ],
    ),
    dict(
        name="M2 the cursor over-shoots (retained-2): the hint re-asks a trimmed position",
        file=JOB_STREAM_RS,
        old="""            return PumpStep::Gap {
                resume_from: page.retained_from_event_index.saturating_sub(1),
            };""",
        new="""            return PumpStep::Gap {
                resume_from: page.retained_from_event_index.saturating_sub(2),
            };""",
        red=[
            # retained=2 -> cursor 0 -> from(0)+1 < 2 -> reset again: the judge's
            # "the hinted cursor must be readable" assert fires (a resume hint that
            # re-gaps is a hint that can never be followed).
            (JUDGE_GAP, False),
        ],
        green=[
            ("-p caly-daemon --lib job_stream::tests::a_growing_job_is_served_as_contiguous_deltas", True),
        ],
    ),
    dict(
        name="M3 the CLI hint mangles the cursor value",
        file=CALY_RS,
        old='        eprintln!("caly: the stream fell out of the retained window; resume with --from {resume}");',
        new='        eprintln!("caly: the stream fell out of the retained window; resume with --from 0");',
        red=[
            (JUDGE_HINT, False),
        ],
        green=[
            # A judge with no stake in the hint stays green.
            (
                "-p caly-cli --test caly_cli_e2e "
                "a_follow_end_frame_with_a_foreign_stream_id_does_not_set_the_verdict",
                True,
            ),
        ],
    ),
]


def main() -> int:
    leftovers: list[str] = []
    for mutation in MUTATIONS:
        path = mutation["file"]
        original = open(path, "rb").read().decode()
        original_sha = hashlib.sha256(original.encode()).hexdigest()
        if mutation["old"] not in original:
            print(f"{mutation['name']}: ANCHOR NOT FOUND (skipped)")
            continue
        mutated = original.replace(mutation["old"], mutation["new"], 1)
        open(path, "w").write(mutated)
        os.utime(path, None)  # immediate mtime bump so the next build relinks
        try:
            verdicts = []
            for name, expect in mutation["red"] + mutation["green"]:
                verdicts.append(test(name, expect))
            reds = verdicts[: len(mutation["red"])]
            greens = verdicts[len(mutation["red"]) :]
            ok = all(v == "RED" for v in reds) and all(v == "GREEN" for v in greens)
            print(
                f"{mutation['name']}: {'BIT' if ok else 'MISSED-BIT'} "
                f"(red={reds} green={greens})"
            )
        finally:
            open(path, "w").write(original)
            os.utime(path, None)
            after_sha = hashlib.sha256(open(path, "rb").read()).hexdigest()
            if after_sha != original_sha:
                leftovers.append(path)
    if leftovers:
        print(f"LEFTOVERS: {leftovers}")
        return 1
    # Relink the restored sources so target/debug carries the pristine binaries.
    build_bins()
    print("leftovers: []")
    return 0


if __name__ == "__main__":
    sys.exit(main())
