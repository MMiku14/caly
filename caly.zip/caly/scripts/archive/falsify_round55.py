"""Falsification harness for round 55 (the real effect backend: `StdEffectRuntime` running a
pinned real core through the same daemon command path).

Same discipline as rounds 16/32–54: one mutation per run, exact-anchor replacement with
`assert count == 1`, restore by content and mtime, sha256-verified, stale `*.r55bak` swept at
startup. A mutation that cannot compile proves nothing (`§4.112`); backups are per-mutation
(`§4.137`); each cargo run carries a hard timeout — a mutation that wedges the suite counts as
DID NOT BIT (`§4.139`).

Mutations that fake a stop or a refusal can leave a real core running when their judge dies
mid-lifecycle, so the harness sweeps stray `caly-run.yaml` cores after every mutation and
**sleeps** before the next verdict (`DEVELOPMENT_LOG_2026-08-27 §6`: never trust a kill
without a beat).

Five mutations, each bitten by a real-core judge in `real_apply.rs`:

- M1  the spawn command neutered (`exec /bin/true` instead of the core chain) — the
      nightshift chain must go red at its own probe;
- M2  the rollback stop fabricating an exit instead of stopping — the rollback judge must
      catch the surviving pid in the process table;
- M3  `NetApply` pretending success instead of refusing by name — the TUN judge exists for
      exactly this lie;
- M4  the un-materialize compensation neutered — the rollback judge must catch the file
      that should not survive;
- M5  the dns enhanced-mode mapping regressing to `mixed` — a value the real core rejects
      (`invalid mode`), caught by the nightshift chain.

Usage: `python3 scripts/archive/falsify_round55.py` (exit 0 = every mutation bit, every file restored).
"""

import hashlib
import os
import pathlib
import shutil
import subprocess
import sys
import time

ROOT = pathlib.Path("/home/user/caly")
ENV = dict(os.environ)
ENV["PATH"] = str(pathlib.Path.home() / ".cargo/bin") + ":" + ENV.get("PATH", "")
SRC = {
    "std": ROOT / "crates/caly-daemon/src/effect_std.rs",
    "adapter": ROOT / "crates/caly-mihomo/src/adapter.rs",
}

MUTATIONS = [
    (
        "M1 spawn neutered: exec /bin/true instead of the core",
        "std",
        '''"gunzip -kf core.gz && chmod +x core && exec ./core -d . -f caly-run.yaml"
                                    .to_owned(),''',
        '''"exec /bin/true".to_owned(),''',
        [
            "nightshift_applies_end_to_end_with_a_live_real_core",
        ],
    ),
    (
        "M2 rollback stop fabricates the exit",
        "std",
        '''                    Some(live) if instance.0 == INSTANCE => {
                        let exit = self.port(self.proc.stop(&live.handle, 0), "stop")?;''',
        '''                    Some(live) if instance.0 == INSTANCE => {
                        let _ = &live.handle;
                        let exit = caly_io::ChildExit { code: 0, signaled: false };''',
        [
            "rollback_really_stops_the_core_the_apply_started",
        ],
    ),
    (
        "M3 NetApply pretends success instead of refusing",
        "std",
        '''            EffectStep::NetApply { plan } => Err(StepFailure::new(
                "unsupported-net-apply",
                format!(
                    "the privileged Platform face is a deliberate absence (ADR-042 §2.2); \\
                     \\"{}\\" cannot be applied on the real backend yet",
                    plan.summary
                ),
                false,
            )),''',
        '''            EffectStep::NetApply { plan } => Ok(StepEvidence::one(format!(
                "net.apply {} (pretended: no privileged face exists and no one refused)",
                plan.summary
            ))),''',
        [
            "tun_profile_is_refused_by_name_and_leaves_no_core",
        ],
    ),
    (
        "M4 un-materialize compensation neutered",
        "std",
        '''                let _ = self.port(self.fs.remove(&path, &self.ctx()), "fs-remove");''',
        '''                let _ = &path;''',
        [
            "rollback_really_stops_the_core_the_apply_started",
        ],
    ),
    (
        "M5 dns enhanced-mode regresses to mixed (real core: fatal)",
        "adapter",
        '''        caly_ir::DnsMode::Mixed => "normal",''',
        '''        caly_ir::DnsMode::Mixed => "mixed",''',
        [
            "nightshift_applies_end_to_end_with_a_live_real_core",
        ],
    ),
]


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def sweep_stray_cores():
    """A fabricated stop leaves a real core running after its judge died; the next verdict
    needs a clean host (ports, processes) to mean anything. The pattern never matches this
    harness's own command line (`§4.143`: pkill -f that matches yourself kills yourself)."""
    subprocess.run(
        ["pkill", "-f", "caly-run.yaml"],
        stdout=subprocess.DEVNULL,
        stderr=subprocess.DEVNULL,
    )
    time.sleep(1.0)  # a kill is not done until a beat has passed (§6, tmpfs log)


def run_cargo():
    argv = ["cargo", "test", "-p", "caly-daemon", "--test", "real_apply", "--no-fail-fast"]
    try:
        proc = subprocess.run(
            argv,
            cwd=str(ROOT),
            env=ENV,
            capture_output=True,
            text=True,
            timeout=900,  # a wedged suite is a wedged *mutant*, not a verdict (§4.139)
        )
    except subprocess.TimeoutExpired:
        return 124, [], "TIMEOUT: the mutation wedged the suite (§4.139) — redesign it"
    out = proc.stdout + proc.stderr
    failed = sorted(
        {
            line[5:].split(" ... ")[0].split("::")[-1].strip()
            for line in out.splitlines()
            if line.startswith("test ") and line.rstrip().endswith("... FAILED")
        }
    )
    return proc.returncode, failed, out


def main():
    for path in ROOT.rglob("*.r55bak"):
        original = pathlib.Path(str(path)[: -len(".r55bak")])
        shutil.move(str(path), str(original))
        print("swept leftover backup:", path.name)
    sweep_stray_cores()

    originals = {name: digest(path) for name, path in SRC.items()}
    results = []
    bad = False
    for label, key, old, new, expected in MUTATIONS:
        path = SRC[key]
        backup = pathlib.Path(str(path) + ".r55bak")
        shutil.copyfile(path, backup)  # per-mutation backup (§4.137)
        s = path.read_text()
        assert s.count(old) == 1, "%s: anchor x%d" % (label, s.count(old))
        try:
            mutated = s.replace(old, new, 1)
            path.write_text(mutated)
            code, failed, out = run_cargo()
            wedged = code == 124
            red = [name for name in expected if name in failed]
            compile_error = "error[" in out or "could not compile" in out
            ok = bool(red) and not compile_error and not wedged
            results.append((label, ok))
            print("%-52s %s  red=%s" % (label, "BIT" if ok else "NO EFFECT", red or failed[:4]))
            if not ok:
                if compile_error:
                    print("   !! the mutation did not compile; it proves nothing")
                if wedged:
                    print("   !! the mutation wedged the suite; it proves nothing (§4.139)")
                print("   output tail:\n", out[-1200:])
        finally:
            shutil.move(str(backup), str(path))
            os.utime(path, None)
            assert digest(path) == originals[key], "%s: restore did not reproduce the file" % label
            sweep_stray_cores()

    print("\n== summary ==")
    for label, ok in results:
        print("%-52s %s" % (label, "bit" if ok else "DID NOT BIT"))
        if not ok:
            bad = True
    print("all mutations bit:", not bad)
    sys.exit(1 if bad else 0)


if __name__ == "__main__":
    main()
