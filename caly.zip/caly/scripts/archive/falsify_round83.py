#!/usr/bin/env python3
"""Round 83 falsification harness.

The claim: `docs/guides/ERRORS.md §4`'s Category column and `ErrorCode::category()` are one
map (the canonical per-code default), judged by `caly-api/tests/error_doc.rs`:

- M1 (must bite)  a document-side drift: §4's `PERMISSION` row changes Platform to
    User — the category judge goes red (the documented default and the code's
    canonical default disagree).
- M2 (must bite)  a code-side drift: `ErrorCode::Timeout.category()` stops returning
    Io and returns User — the category judge goes red (the code default and the doc
    default disagree).

Usage: `python3 scripts/archive/falsify_round83.py` (exit 0 = all bit, files restored).
Restore bumps mtime (stale-fingerprint bomb; R79.5.1).
"""

import hashlib
import os
import pathlib
import shutil
import subprocess
import sys
import time

ROOT = pathlib.Path("/home/user/caly_extract/caly")
ENV = dict(os.environ)
ENV["PATH"] = str(pathlib.Path.home() / ".cargo/bin") + ":" + ENV.get("PATH", "")

DOC = ROOT / "docs/guides/ERRORS.md"
CODE = ROOT / "crates/caly-api/src/error.rs"

JUDGE = ["cargo", "test", "-q", "-p", "caly-api", "--test", "error_doc"]
JUDGE_TIMEOUT_SECS = 300


def digest(path):
    return hashlib.sha256(pathlib.Path(path).read_bytes()).hexdigest()


def sweep_strays():
    for path in ROOT.rglob("*.r83bak"):
        print(f"  note  sweeping stale {path}")
        path.unlink()


def run_judge():
    begin = time.time()
    proc = subprocess.Popen(
        JUDGE, cwd=ROOT, env=ENV,
        stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
        text=True, start_new_session=True,
    )
    try:
        out, _ = proc.communicate(timeout=JUDGE_TIMEOUT_SECS)
    except subprocess.TimeoutExpired:
        os.killpg(proc.pid, 9)
        proc.wait()
        return None, time.time() - begin, "HANG"
    ok = "0 failed" in (out or "") and "test result: ok" in (out or "")
    return ok, time.time() - begin, ""


def apply_one(path, needle, replacement):
    text = path.read_text()
    assert text.count(needle) == 1, f"{path}: needle not unique: {needle!r}"
    bak = pathlib.Path(str(path) + ".r83bak")
    shutil.copy2(path, bak)
    path.write_text(text.replace(needle, replacement))


def restore_one(path):
    bak = pathlib.Path(str(path) + ".r83bak")
    if bak.exists():
        shutil.copy2(bak, path)
        bak.unlink()
        os.utime(path, None)


M1_OLD = "| `PERMISSION` | Platform | 可能 |"
M1_NEW = "| `PERMISSION` | User | 可能 |"

M2_OLD = "            Self::Timeout => ErrorCategory::Io,"
M2_NEW = "            Self::Timeout => ErrorCategory::User,"


def main():
    sweep_strays()
    results = []

    apply_one(DOC, M1_OLD, M1_NEW)
    ok, secs, note = run_judge()
    results.append(("M1", "§4's PERMISSION category drifts (must bite)", ok, secs, note))
    restore_one(DOC)

    apply_one(CODE, M2_OLD, M2_NEW)
    ok, secs, note = run_judge()
    results.append(("M2", "category()'s Timeout arm drifts (must bite)", ok, secs, note))
    restore_one(CODE)

    all_bite = True
    for name, label, bit, secs, note in results:
        if note:
            print(f"  {'ok' if not bit else 'MISS'}    {name} {label} ({note} in {secs:.1f}s)")
        else:
            print(f"  {'ok' if not bit else 'MISS'}    {name} {label} (bite in {secs:.1f}s)")
        if bit:
            all_bite = False

    print(f"restored: doc={digest(DOC)[:12]}… code={digest(CODE)[:12]}…")
    print("all mutations behaved as predicted: " + ("True" if all_bite else "False"))
    sys.exit(0 if all_bite else 1)


if __name__ == "__main__":
    main()
