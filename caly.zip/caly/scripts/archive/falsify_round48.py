"""Falsification harness for round 48 (`jobs.follow` + `profiles.rollback` on the wire,
`caly job`/`caly rollback`, and `caly jobs --from/--max` paging).

Same discipline as rounds 16/32–47: one mutation per run, exact-anchor replacement with
`assert count == 1`, restore by content and mtime, sha256-verified, stale `*.r48bak` swept at
startup. A mutation that cannot compile proves nothing (`§4.112`). Backups are taken **per
mutation** (`§4.137`).

Six mutations: `jobs.follow` dropped from the whitelist, a follow summary that lies about the
state, a rollback that swallows the named snapshot (quietly using the last-known-good), the
CLI hiding `last_stage`, the CLI ignoring `--from`, and the daemon hiding the resume cursor.

Usage: `python3 scripts/archive/falsify_round48.py` (exit 0 = every mutation bit, every file restored).
"""

import hashlib
import os
import pathlib
import shutil
import subprocess
import sys

ROOT = pathlib.Path("/home/user/caly")
ENV = dict(os.environ)
ENV["PATH"] = str(pathlib.Path.home() / ".cargo/bin") + ":" + ENV.get("PATH", "")
SRC = {
    "daemon": ROOT / "crates/caly-daemon/src/bin/calyd.rs",
    "cli": ROOT / "crates/caly-cli/src/bin/caly.rs",
}

MUTATIONS = [
    (
        "M1 jobs.follow drops off the whitelist",
        "daemon",
        '                    "jobs.follow" => {',
        '                    "jobs.follow-x" => {',
        [
            "the_follow_summary_agrees_with_the_events_page",
            "caly_job_prints_the_summary_the_wire_said",
        ],
    ),
    (
        "M2 the follow summary lies about the state",
        "daemon",
        '        ("state", view.state.clone()),',
        '        ("state", "running".to_owned()),',
        [
            "the_follow_summary_agrees_with_the_events_page",
            "caly_job_prints_the_summary_the_wire_said",
        ],
    ),
    (
        "M3 a rollback swallows the named snapshot",
        "daemon",
        '                            snapshot_id: wire_field(&records, "snapshot_id").map(str::to_owned),',
        "                            snapshot_id: None,",
        [
            "rollback_points_at_the_named_snapshot_not_the_last_known_good",
            "caly_rollback_targets_the_named_snapshot_and_requires_a_key",
        ],
    ),
    (
        "M4 the CLI hides last_stage",
        "cli",
        """        "last_stage",
        "last_stage_pct",""",
        """        "last_stage_pct",""",
        [
            "caly_job_prints_the_summary_the_wire_said",
        ],
    ),
    (
        "M5 the CLI ignores --from",
        "cli",
        """            if let Some(from) = from_event_index.clone() {
                records.push(("from_event_index", from));
            }""",
        """            let _ = &from_event_index;""",
        [
            "caly_jobs_pages_by_cursor_and_the_pages_tile_the_window",
        ],
    ),
    (
        "M6 the daemon hides the resume cursor",
        "daemon",
        """        (
            "next_from_event_index".to_owned(),
            view.next_from_event_index
                .map(|value| value.to_string())
                .unwrap_or_default(),
        ),""",
        """        (
            "next_from_event_index".to_owned(),
            String::new(),
        ),""",
        [
            "caly_jobs_pages_by_cursor_and_the_pages_tile_the_window",
        ],
    ),
]


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def run_cargo():
    proc = subprocess.run(
        [
            "cargo",
            "test",
            "-p",
            "caly-daemon",
            "--test",
            "calyd_wire",
            "-p",
            "caly-cli",
            "--test",
            "caly_cli_e2e",
            "--no-fail-fast",
        ],
        cwd=str(ROOT),
        env=ENV,
        capture_output=True,
        text=True,
    )
    out = proc.stdout + proc.stderr
    failed = sorted(
        {
            line[5:].split(" ... ")[0].split("::")[-1].strip()
            for line in out.splitlines()
            if line.startswith("test ") and line.rstrip().endswith("... FAILED")
        }
    )
    return proc.returncode, failed, out


def main():
    for path in ROOT.rglob("*.r48bak"):
        original = pathlib.Path(str(path)[: -len(".r48bak")])
        shutil.move(str(path), str(original))
        print("swept leftover backup:", path.name)

    originals = {name: digest(path) for name, path in SRC.items()}
    results = []
    bad = False
    for label, key, old, new, expected in MUTATIONS:
        path = SRC[key]
        backup = pathlib.Path(str(path) + ".r48bak")
        shutil.copyfile(path, backup)  # per-mutation backup (§4.137)
        s = path.read_text()
        assert s.count(old) == 1, "%s: anchor x%d" % (label, s.count(old))
        try:
            path.write_text(s.replace(old, new, 1))
            code, failed, out = run_cargo()
            red = [name for name in expected if name in failed]
            compile_error = "error[" in out or "could not compile" in out
            ok = bool(red) and not compile_error
            results.append((label, ok))
            print("%-52s %s  red=%s" % (label, "BIT" if ok else "NO EFFECT", red or failed[:4]))
            if not ok:
                if compile_error:
                    print("   !! the mutation did not compile; it proves nothing")
                print("   output tail:\n", out[-1200:])
        finally:
            shutil.move(str(backup), str(path))
            os.utime(path, None)
            assert digest(path) == originals[key], "%s: restore did not reproduce the file" % label

    print("\n== summary ==")
    for label, ok in results:
        print("%-52s %s" % (label, "bit" if ok else "DID NOT BIT"))
        if not ok:
            bad = True
    print("all mutations bit:", not bad)
    sys.exit(1 if bad else 0)


if __name__ == "__main__":
    main()
