#!/usr/bin/env python3
"""Round 136 falsify: sharded record directories (ADR-062).

Four mutations:
  M1 writes go flat again, no bucket segment (layout judge must go red);
  M2 the reopen walk skips buckets entirely (the 4097 judge must go red);
  M3 the v1->v2 migration hook no-ops (the migration judge must go red);
  M4 the wrong-bucket name claim is disabled (the displaced-record judge must go red).

Byte-for-byte restore per mutation (sha256 + mtime bump); RED verdicts carry the
compiled-guard.
"""
import hashlib
import os
import subprocess
import sys

CALY = "/home/user/caly/caly"
STORE = f"{CALY}/crates/caly-storage/src/fs_store.rs"
MIG = f"{CALY}/crates/caly-storage/src/migrations.rs"

T_LAYOUT = "-p caly-storage --test sharded_records records_land_in_hash_buckets_and_the_top_level_holds_no_records"
T_4097 = "-p caly-storage --test sharded_records forty_ninety_seven_objects_reopen_because_the_growth_is_sharded"
T_BUCKETCAP = "-p caly-storage --test sharded_records a_record_bucket_past_the_cap_refuses_reopen_naming_the_bucket"
T_MIGRATE = "-p caly-storage --test sharded_records a_v1_flat_store_migrates_to_sharded_buckets_losing_nothing"
T_WRONGBUCKET = "-p caly-storage --test sharded_records a_record_in_the_wrong_bucket_is_refused_by_name_at_reopen"
T_SCHEMA = "-p caly-storage --test schema a_fresh_store_is_initialised_once_and_never_rewritten_on_read"


def run(*args: str) -> tuple[int, str]:
    proc = subprocess.run(args, cwd=CALY, capture_output=True, text=True, timeout=900)
    return proc.returncode, proc.stdout + proc.stderr


def test(name: str, expect_ok: bool) -> str:
    code, out = run("cargo", "test", *name.split(), "--", "--test-threads=1")
    compiled = "error[" not in out and "error: " not in out
    passed = code == 0 and compiled
    if passed == expect_ok:
        return "GREEN" if expect_ok else "RED"
    verdict = "UNEXPECTED-RED" if expect_ok else "MISSED-BIT"
    tail = "\n".join(out.splitlines()[-10:])
    print(f"    [{verdict}] {name}\n    --------\n{tail}\n    --------")
    return verdict


MUTATIONS = [
    dict(
        name="M1 writes go flat again",
        file=STORE,
        old="""    let stem = escape_component(digest);
    format!("{OBJECT_DIRECTORY}/{}/{stem}.obj", record_shard(&stem))
}""",
        new="""    let stem = escape_component(digest);
    format!("{OBJECT_DIRECTORY}/{stem}.obj")
}""",
        red=[(T_LAYOUT, False), (T_4097, False)],
        green=[(T_BUCKETCAP, True)],
    ),
    dict(
        name="M2 the reopen walk skips buckets",
        file=STORE,
        old="""            if is_lower_hex(name) && name.len() == 2 {
                for suffix in self.list_suffixes(&top, ctx)? {""",
        new="""            if false && is_lower_hex(name) && name.len() == 2 {
                for suffix in self.list_suffixes(&top, ctx)? {""",
        red=[(T_4097, False), (T_LAYOUT, False)],
        green=[(T_SCHEMA, True)],
    ),
    dict(
        name="M3 the migration hook no-ops",
        file=MIG,
        old="""                if !is_record_name(&name) {
                    continue;
                }
                let from = VPath::try_from_str(&format!("{root}/{suffix}"))""",
        new="""                if true || !is_record_name(&name) {
                    continue;
                }
                let from = VPath::try_from_str(&format!("{root}/{suffix}"))""",
        red=[(T_MIGRATE, False)],
        green=[(T_LAYOUT, True)],
    ),
    dict(
        name="M4 the wrong-bucket name claim disappears",
        file=STORE,
        old="""            if suffix != expected {
                problems.push(format!(
                    "object record {suffix} is not the path its digest ({}) would occupy \\
                     -- legacy or forged naming, or the wrong bucket (ADR-062)",""",
        new="""            if false && suffix != expected {
                problems.push(format!(
                    "object record {suffix} is not the path its digest ({}) would occupy \\
                     -- legacy or forged naming, or the wrong bucket (ADR-062)",""",
        red=[(T_WRONGBUCKET, False)],
        green=[(T_LAYOUT, True)],
    ),
]


def main() -> int:
    leftovers: list[str] = []
    for mutation in MUTATIONS:
        path = mutation["file"]
        original = open(path, "rb").read().decode()
        original_sha = hashlib.sha256(original.encode()).hexdigest()
        if mutation["old"] not in original:
            print(f"{mutation['name']}: ANCHOR NOT FOUND (skipped)")
            continue
        mutated = original.replace(mutation["old"], mutation["new"], 1)
        open(path, "w").write(mutated)
        os.utime(path, None)
        try:
            verdicts = []
            for name, expect in mutation["red"] + mutation["green"]:
                verdicts.append(test(name, expect))
            reds = verdicts[: len(mutation["red"])]
            greens = verdicts[len(mutation["red"]) :]
            ok = all(v == "RED" for v in reds) and all(v == "GREEN" for v in greens)
            print(
                f"{mutation['name']}: {'BIT' if ok else 'MISSED-BIT'} "
                f"(red={reds} green={greens})"
            )
        finally:
            open(path, "w").write(original)
            os.utime(path, None)
            if hashlib.sha256(open(path, "rb").read().decode().encode()).hexdigest() != original_sha:
                leftovers.append(path)
    if leftovers:
        print(f"LEFTOVERS: {leftovers}")
        return 1
    print("leftovers: []")
    return 0


if __name__ == "__main__":
    sys.exit(main())
