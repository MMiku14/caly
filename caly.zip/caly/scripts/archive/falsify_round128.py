#!/usr/bin/env python3
"""Round 128 falsify: the hardening gates (fuzz judges + counting perf judges).

Four mutations break the new gates from four sides: a parser panic on the empty/multibyte
boundary (twice — the capability JSON reader and the record codec, the two byte-facing
layers), the batch dating quietly degrading into per-record stats, and the fresh ADR-061
tag grammar panicking on an absent tag.

Each mutation rewrites one production file, runs a targeted red/green pair, then restores
byte-for-byte (sha256 + mtime bump). RED verdicts carry the compiled-guard (a compile
error is not a red).
"""
import hashlib
import os
import subprocess
import sys

CALY = "/home/user/caly/caly"
CAP_JSON = f"{CALY}/crates/caly-cap/src/json.rs"
RECORD = f"{CALY}/crates/caly-storage/src/record.rs"
FS_STORE = f"{CALY}/crates/caly-storage/src/fs_store.rs"
PERSISTENCE = f"{CALY}/crates/caly-engine/src/source_persistence.rs"

J_CAP_FUZZ = "-p caly-cap --test fuzz_json mutated_documents_never_panic_and_refuse_by_name"
J_CAP_VALID = "-p caly-cap --test fuzz_json the_valid_corpus_parses_and_the_values_survive"
J_REC_FUZZ = "-p caly-storage --test fuzz_record_codec mutated_records_never_panic_and_refuse_by_name"
J_REC_VALID = "-p caly-storage --test fuzz_record_codec the_valid_corpus_decodes_through_the_typed_surface"
J_PERF_BATCH = "-p caly-storage --test perf_regression batch_dating_stays_constant_as_the_directory_grows"
J_PERF_LINEAR = "-p caly-storage --test perf_regression reopening_a_bigger_store_costs_linearly_more_port_calls"
J_ENG_FUZZ = "-p caly-engine --lib source_persistence::tests::mutated_caches_never_panic"


def run(*args: str) -> tuple[int, str]:
    proc = subprocess.run(args, cwd=CALY, capture_output=True, text=True, timeout=900)
    return proc.returncode, proc.stdout + proc.stderr


def test(name: str, expect_ok: bool) -> str:
    code, out = run("cargo", "test", *name.split(), "--", "--test-threads=1")
    compiled = "error[" not in out and "error: " not in out
    passed = code == 0 and compiled
    if passed == expect_ok:
        return "GREEN" if expect_ok else "RED"
    verdict = "UNEXPECTED-RED" if expect_ok else "MISSED-BIT"
    tail = "\n".join(out.splitlines()[-12:])
    print(f"    [{verdict}] {name}\n    --------\n{tail}\n    --------")
    return verdict


MUTATIONS = [
    dict(
        name="M1 the capability JSON reader slices before it looks",
        file=CAP_JSON,
        old="""pub fn parse_json(raw: &str) -> Result<JsonValue, JsonError> {
    let bytes = raw.as_bytes();""",
        new="""pub fn parse_json(raw: &str) -> Result<JsonValue, JsonError> {
    let _probe = &raw[1..];
    let bytes = raw.as_bytes();""",
        red=[(J_CAP_FUZZ, False)],
        green=[("-p caly-cap --test registry_drift", True)],
    ),
    dict(
        name="M2 the record codec indexes into an empty document",
        file=RECORD,
        old="""    pub fn decode(raw: &str) -> Result<Self, RecordCodecError> {
        let mut tag: Option<String> = None;""",
        new="""    pub fn decode(raw: &str) -> Result<Self, RecordCodecError> {
        let _probe = &raw[..1];
        let mut tag: Option<String> = None;""",
        red=[(J_REC_FUZZ, False)],
        green=[(J_PERF_BATCH, True)],
    ),
    dict(
        name="M3 batch dating quietly degrades into per-record stats",
        file=FS_STORE,
        old="""        let metas = drive_port(
            self.inner.fs.stat_many(&paths, ctx),
            ctx,
            self.inner.clock.as_deref(),
        )?
        .map_err(from_iofault)?;""",
        new="""        let mut dated = Vec::new();
        for path in &paths {
            dated.push(
                drive_port(self.inner.fs.stat(path, ctx), ctx, self.inner.clock.as_deref())?
                    .map_err(from_iofault)?,
            );
        }
        let metas = dated;""",
        red=[(J_PERF_BATCH, False)],
        green=[(J_PERF_LINEAR, True)],
    ),
    dict(
        name="M4 the tag grammar panics on an absent tag",
        file=PERSISTENCE,
        old="""fn decode_tag_epoch(found: &str, v1: &str, v2: &str) -> Result<u32, String> {
    if found == v1 {""",
        new="""fn decode_tag_epoch(found: &str, v1: &str, v2: &str) -> Result<u32, String> {
    let _probe = &found[..1];
    if found == v1 {""",
        red=[(J_ENG_FUZZ, False)],
        green=[(J_CAP_VALID, True)],
    ),
]


def main() -> int:
    leftovers: list[str] = []
    for mutation in MUTATIONS:
        path = mutation["file"]
        original = open(path, "rb").read().decode()
        original_sha = hashlib.sha256(original.encode()).hexdigest()
        if mutation["old"] not in original:
            print(f"{mutation['name']}: ANCHOR NOT FOUND (skipped)")
            continue
        mutated = original.replace(mutation["old"], mutation["new"], 1)
        open(path, "w").write(mutated)
        os.utime(path, None)
        try:
            verdicts = []
            for name, expect in mutation["red"] + mutation["green"]:
                verdicts.append(test(name, expect))
            reds = verdicts[: len(mutation["red"])]
            greens = verdicts[len(mutation["red"]) :]
            ok = all(v == "RED" for v in reds) and all(v == "GREEN" for v in greens)
            print(
                f"{mutation['name']}: {'BIT' if ok else 'MISSED-BIT'} "
                f"(red={reds} green={greens})"
            )
        finally:
            open(path, "w").write(original)
            os.utime(path, None)
            if hashlib.sha256(open(path, "rb").read()).hexdigest() != original_sha:
                leftovers.append(path)
    if leftovers:
        print(f"LEFTOVERS: {leftovers}")
        return 1
    print("leftovers: []")
    return 0


if __name__ == "__main__":
    sys.exit(main())
