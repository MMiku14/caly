"""Falsification harness for round 44 (the `caly` CLI: the daemon's first real client).

Round 44's own finding, recorded where the next round will look: M1 (skip hello) originally
DEADLOCKED instead of failing -- neither side had a read timeout, so a waiting daemon and a
waiting client hung forever. A mutation that hangs is a finding about the product, not a broken
mutation: both sides got bounded reads that same round (the CLI exits 11 on timeout; the daemon
ends an idle connection), and only then could M1 bite.

Same discipline as rounds 16/32–43: one mutation per run, exact-anchor replacement with
`assert count == 1`, restore by content and mtime, sha256-verified, stale `*.r44bak` swept at
startup. A mutation that cannot compile proves nothing (`§4.112`).

Four mutations against the CLI's source, each aimed at one judge: skipping hello (the session
order the daemon refuses), exiting 0 on an unreachable daemon, dropping a field from the
output, and printing a fabricated answer instead of reading the wire (the oracle-parity judge
exists for exactly this).

Usage: `python3 scripts/archive/falsify_round44.py` (exit 0 = every mutation bit, every file restored).
"""

import hashlib
import os
import pathlib
import shutil
import subprocess
import sys

ROOT = pathlib.Path("/home/user/caly")
ENV = dict(os.environ)
ENV["PATH"] = str(pathlib.Path.home() / ".cargo/bin") + ":" + ENV.get("PATH", "")
SRC = ROOT / "crates/caly-cli/src/bin/caly.rs"

MUTATIONS = [
    (
        "M1 the CLI skips hello",
        """    session.send(WIRE_KIND_HELLO, &hello())?;""",
        "    // (hello skipped: the session order is not the CLI's to decide)",
        ["caly_status_prints_what_the_wire_actually_says"],
    ),
    (
        "M2 an unreachable daemon exits 0",
        """            eprintln!("caly: {summary}");
            return exit_code(ExitCode::Unavailable);""",
        """            eprintln!("caly: {summary}");
            return exit_code(ExitCode::Success);""",
        ["an_unreachable_daemon_is_exit_12_and_names_the_address"],
    ),
    (
        "M3 the output drops a field",
        """        "pending_recovery_decisions",
        "last_recovery_summary",""",
        """        "last_recovery_summary",""",
        ["caly_status_prints_what_the_wire_actually_says"],
    ),
    (
        "M4 the CLI fabricates the answer",
        """    match ask_status(&mut session) {
        Ok(Answer::Status(records)) => {
            print_status(&records);""",
        """    match ask_status(&mut session) {
        Ok(Answer::Status(records)) => {
            let _ = records;
            println!("core_running: false");
            println!("active_profile: made-up");""",
        ["caly_status_prints_what_the_wire_actually_says"],
    ),
]


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def run_cargo():
    proc = subprocess.run(
        ["cargo", "test", "-p", "caly-cli", "--test", "caly_cli_e2e", "--no-fail-fast"],
        cwd=str(ROOT),
        env=ENV,
        capture_output=True,
        text=True,
    )
    out = proc.stdout + proc.stderr
    failed = sorted(
        {
            line[5:].split(" ... ")[0].split("::")[-1].strip()
            for line in out.splitlines()
            if line.startswith("test ") and line.rstrip().endswith("... FAILED")
        }
    )
    return proc.returncode, failed, out


def main():
    for path in ROOT.rglob("*.r44bak"):
        original = pathlib.Path(str(path)[: -len(".r44bak")])
        shutil.move(str(path), str(original))
        print("swept leftover backup:", path.name)

    original = digest(SRC)
    results = []
    bad = False
    for label, old, new, expected in MUTATIONS:
        s = SRC.read_text()
        assert s.count(old) == 1, "%s: anchor x%d" % (label, s.count(old))
        backup = pathlib.Path(str(SRC) + ".r44bak")
        shutil.copyfile(SRC, backup)
        try:
            SRC.write_text(s.replace(old, new, 1))
            code, failed, out = run_cargo()
            red = [name for name in expected if name in failed]
            compile_error = "error[" in out or "could not compile" in out
            ok = bool(red) and not compile_error
            results.append((label, ok))
            print("%-42s %s  red=%s" % (label, "BIT" if ok else "NO EFFECT", red or failed[:4]))
            if not ok:
                if compile_error:
                    print("   !! the mutation did not compile; it proves nothing")
                print("   output tail:\n", out[-1200:])
        finally:
            shutil.move(str(backup), str(SRC))
            os.utime(SRC, None)
            assert digest(SRC) == original, "%s: restore did not reproduce the file" % label

    print("\n== summary ==")
    for label, ok in results:
        print("%-42s %s" % (label, "bit" if ok else "DID NOT BIT"))
        if not ok:
            bad = True
    print("all mutations bit:", not bad)
    sys.exit(1 if bad else 0)


if __name__ == "__main__":
    main()
