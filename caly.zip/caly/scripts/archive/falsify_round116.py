#!/usr/bin/env python3
"""Round 116 falsify: stream END failure_code (ADR-058).

Each mutation rewrites one production file, runs a targeted red/green test pair,
then restores the file byte-for-byte (sha256 + immediate mtime bump, per the
round-112 lesson: the next mutation must relink the poisoned binary).
"""
import hashlib
import os
import subprocess
import sys

CALY = "/home/user/caly"
CALY_RS = f"{CALY}/crates/caly-cli/src/bin/caly.rs"
CALYD_RS = f"{CALY}/crates/caly-daemon/src/bin/calyd.rs"


def sha(path: str) -> str:
    return hashlib.sha256(open(path, "rb").read()).hexdigest()


def run(*args: str) -> tuple[int, str]:
    proc = subprocess.run(args, cwd=CALY, capture_output=True, text=True, timeout=900)
    return proc.returncode, proc.stdout + proc.stderr


def test(name: str, expect_ok: bool) -> str:
    code, out = run("cargo", "test", *name.split())
    if code == 0 and "error[" in out:
        code = 1
    passed = code == 0
    if passed == expect_ok:
        return "GREEN" if expect_ok else "RED"
    return "UNEXPECTED-RED" if expect_ok else "MISSED-BIT"


MUTATIONS = [
    dict(
        name="M1 daemon never attaches the code",
        file=CALYD_RS,
        old="if matches!(outcome, caly_ipc::JobOutcome::Failed) {",
        new="if false && matches!(outcome, caly_ipc::JobOutcome::Failed) {",
        red=[
            ("-p caly-daemon --test calyd_wire the_end_frame_of_a_failed_job_carries_the_failure_code", False),
            ("-p caly-cli --test caly_cli_e2e caly_follow_of_a_failed_job_exits_with_the_jobs_failure_code", False),
        ],
        green=[
            ("-p caly-cli --test caly_cli_e2e a_streamed_failure_without_a_failure_code_stays_exit_one", True),
            ("-p caly-arch-test --test dependency_direction the_cli_stream_verdict_maps_the_end_frames_failure_code", True),
        ],
    ),
    dict(
        name="M2 the CLI verdict ignores the end frame's code",
        file=CALY_RS,
        old='''        "Failed" => match wire_field(records, "failure_code").filter(|code| !code.is_empty()) {
            Some(code) => Ok(caly_cli::from_wire_refusal_code(code)),
            None => Ok(ExitCode::GeneralFailure),
        },''',
        new='''        "Failed" => Ok(ExitCode::GeneralFailure),''',
        red=[
            ("-p caly-cli --test caly_cli_e2e caly_follow_of_a_failed_job_exits_with_the_jobs_failure_code", False),
            ("-p caly-cli --test caly_cli_e2e a_streamed_failure_carrying_a_failure_code_exits_with_that_code", False),
            ("-p caly-arch-test --test dependency_direction the_cli_stream_verdict_maps_the_end_frames_failure_code", False),
        ],
        green=[
            ("-p caly-cli --test caly_cli_e2e a_streamed_failure_without_a_failure_code_stays_exit_one", True),
        ],
    ),
    dict(
        name="M3 the daemon fabricates a code on every end",
        file=CALYD_RS,
        old='''                                                    if matches!(outcome, caly_ipc::JobOutcome::Failed) {
                                                        match app.job_failure_code(caly_api::JobId(
                                                            job_id,
                                                        )) {
                                                            Ok(Some(code)) => end_records.push((
                                                                "failure_code".to_owned(),
                                                                code,
                                                            )),
                                                            Ok(None) => {}
                                                            Err(summary) => {
                                                                eprintln!(
                                                                    "calyd: end frame lost its \\
                                                                     failure code: {summary}"
                                                                );
                                                            }
                                                        }
                                                    }''',
        new='''                                                    end_records.push((
                                                        "failure_code".to_owned(),
                                                        "CONFLICT".to_owned(),
                                                    ));''',
        red=[
            ("-p caly-daemon --test calyd_wire an_acceptance_means_queued_and_a_stream_watches_the_worker_finish", False),
        ],
        green=[
            ("-p caly-daemon --test calyd_wire the_end_frame_of_a_failed_job_carries_the_failure_code", True),
            ("-p caly-cli --test caly_cli_e2e a_stream_end_verdict_is_not_overridden_by_a_stray_failure_code", True),
        ],
    ),
    dict(
        name="M4 a recognised code is guessed as success",
        file=CALY_RS,
        old="            Some(code) => Ok(caly_cli::from_wire_refusal_code(code)),",
        new="            Some(_code) => Ok(ExitCode::Success),",
        red=[
            ("-p caly-cli --test caly_cli_e2e a_streamed_failure_carrying_a_failure_code_exits_with_that_code", False),
            ("-p caly-cli --test caly_cli_e2e caly_follow_of_a_failed_job_exits_with_the_jobs_failure_code", False),
            ("-p caly-cli --test caly_cli_e2e a_stream_end_verdict_is_not_overridden_by_a_stray_failure_code", False),
        ],
        green=[
            ("-p caly-cli --test caly_cli_e2e a_streamed_failure_without_a_failure_code_stays_exit_one", True),
        ],
    ),
    dict(
        name="M5 an absent code is guessed as success",
        file=CALY_RS,
        old="            None => Ok(ExitCode::GeneralFailure),",
        new="            None => Ok(ExitCode::Success),",
        red=[
            ("-p caly-cli --test caly_cli_e2e a_streamed_failure_without_a_failure_code_stays_exit_one", False),
        ],
        green=[
            ("-p caly-cli --test caly_cli_e2e a_streamed_failure_carrying_a_failure_code_exits_with_that_code", True),
            ("-p caly-daemon --test calyd_wire the_end_frame_of_a_failed_job_carries_the_failure_code", True),
        ],
    ),
]


def main() -> int:
    leftovers: list[str] = []
    for mutation in MUTATIONS:
        path = mutation["file"]
        original = open(path, "rb").read().decode()
        original_sha = hashlib.sha256(original.encode()).hexdigest()
        if mutation["old"] not in original:
            print(f"{mutation['name']}: ANCHOR NOT FOUND (skipped)")
            continue
        mutated = original.replace(mutation["old"], mutation["new"], 1)
        open(path, "w").write(mutated)
        os.utime(path, None)  # immediate mtime bump so the next build relinks
        try:
            verdicts = []
            for name, expect in mutation["red"] + mutation["green"]:
                verdicts.append(test(name, expect))
            reds = verdicts[: len(mutation["red"])]
            greens = verdicts[len(mutation["red"]) :]
            ok = all(v == "RED" for v in reds) and all(v == "GREEN" for v in greens)
            print(
                f"{mutation['name']}: {'BIT' if ok else 'MISSED-BIT'} "
                f"(red={reds} green={greens})"
            )
        finally:
            restored = open(path, "rb").read().decode()
            open(path, "w").write(original)
            os.utime(path, None)
            after_sha = hashlib.sha256(open(path, "rb").read()).hexdigest()
            if after_sha != original_sha:
                leftovers.append(path)
    if leftovers:
        print(f"LEFTOVERS: {leftovers}")
        return 1
    print("leftovers: []")
    return 0


if __name__ == "__main__":
    sys.exit(main())
