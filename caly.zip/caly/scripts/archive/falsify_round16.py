"""Falsification harness for round 16 (`ADR-035` step 2: delete the `caly-storage` index layer).

Kept in the repo as a **template**, not as a gate. The nine mutations below are anchored to exact
source text of that round, so after any reformat they stop matching and the harness refuses to mutate
anything (that is the point of `assert s.count(old) == 1` before every write). Re-running a stale
entry therefore produces "ANCHOR x0", never a false green -- which is the difference between a
falsification harness and a test that can only pass.

Usage: `python3 scripts/archive/falsify_round16.py` (needs `cargo` on PATH; exit code 0 means every mutation
turned at least the named test red, and both source files were restored byte-identically).

Rules learned the hard way (docs/history/ONBOARDING_NOTES.md 4.60 / 4.64 / 4.66):
  * one mutation per run, one file per mutation;
  * try/finally restore, and verify the restore actually happened;
  * sweep leftover backups at startup, because an interrupted run leaves broken code behind.
"""

import hashlib
import os
import pathlib
import shutil
import subprocess
import sys

ROOT = pathlib.Path("/home/user/caly")
import os
ENV = dict(os.environ)
ENV["PATH"] = str(pathlib.Path.home() / ".cargo/bin") + ":" + ENV.get("PATH", "")
SRC = {
    "fs_store": ROOT / "crates/caly-storage/src/fs_store.rs",
    "schema": ROOT / "crates/caly-storage/src/schema.rs",
}

MUTATIONS = [
    (
        "M1 reap removed",
        "fs_store",
        "        let mut problems = Vec::new();\n        self.reap_residue();\n",
        "        let mut problems = Vec::new();\n",
        ["a_temp_file_is_debris_but_an_unexplained_name_is_damage"],
    ),
    (
        "M2 unexplained names ignored",
        "fs_store",
        """            if !is_record_name(name) {
                return Err(StorageError::new(
                    StorageErrorKind::IntegrityViolation,
                    format!("unexpected file in {dir}: {name}"),
                ));
            }""",
        """            if !is_record_name(name) {
                continue;
            }""",
        ["a_temp_file_is_debris_but_an_unexplained_name_is_damage"],
    ),
    (
        "M3 enumeration unbounded",
        "fs_store",
        "            ListCap(MAX_ENTRIES_PER_DIRECTORY),\n        )\n    }",
        "            ListCap(u32::MAX),\n        )\n    }",
        ["enumeration_refuses_rather_than_returning_a_short_list"],
    ),
    (
        "M4 pending scan answers from the cache",
        "fs_store",
        """            Ok(store
                .load_apply_journals()?
                .into_iter()
                .filter(|record| matches!(record.state, ApplyJournalState::Pending))
                .collect())""",
        """            Ok(lock(&store.inner.apply_journals)
                .values()
                .filter(|record| matches!(record.state, ApplyJournalState::Pending))
                .cloned()
                .collect())""",
        ["a_pending_scan_answers_from_the_records_and_not_from_memory"],
    ),
    (
        "M5 rollback point copies nothing",
        "schema",
        '"records/apply-journal",\n];',
        '"records/apply-journals-typo",\n];',
        ["a_contiguous_chain_migrates_records_history_and_creates_a_rollback_point"],
    ),
    (
        "M6 residue no longer recognised",
        "fs_store",
        """fn is_temp_residue(name: &str) -> bool {
    let Some(at) = name.rfind(".tmp-") else {
        return false;
    };""",
        """fn is_temp_residue(name: &str) -> bool {
    let _ = name;
    false
}
#[allow(dead_code)]
fn is_temp_residue_unused(name: &str) -> bool {
    let Some(at) = name.rfind(".tmp-") else {
        return false;
    };""",
        ["a_temp_file_is_debris_but_an_unexplained_name_is_damage"],
    ),
    (
        "M7 unlistable counts as empty",
        "schema",
        "            Err(_) => return true,",
        "            Err(_) => return false,",
        ["enumeration_refuses_rather_than_returning_a_short_list"],
    ),
    (
        "M8 snapshot enumeration answers from memory",
        "fs_store",
        '''        let dir = Self::record_directory("snapshot");
        let mut values = Vec::new();''',
        '''        let dir = Self::record_directory("snapshot");
        let mut cached: Vec<SnapshotRecord> = lock(&self.inner.snapshots).values().cloned().collect();
        cached.sort_by(|left, right| left.id.0.cmp(&right.id.0));
        #[allow(unreachable_code)]
        return Ok(cached);
        let mut values = Vec::new();''',
        ["a_record_written_behind_the_stores_back_is_enumerated_like_any_other"],
    ),
    (
        "M9 a write grows a companion file",
        "fs_store",
        """            let suffix = FsStore::record_path("snapshot", &record.id.0);
            store.write_text(&suffix, &encode_snapshot(&record), Durability::D3)?;""",
        """            let suffix = FsStore::record_path("snapshot", &record.id.0);
            store.write_text(&suffix, &encode_snapshot(&record), Durability::D3)?;
            store.write_text(&format!("manifest/snapshot.idx"), "x\\n", Durability::D3)?;""",
        ["the_store_writes_no_index_of_anything_it_wrote"],
    ),
]


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def run_cargo(pkg):
    proc = subprocess.run(
        ["cargo", "test", "-p", pkg, "--no-fail-fast"],
        cwd=str(ROOT),
        env=ENV,
        capture_output=True,
        text=True,
    )
    out = proc.stdout + proc.stderr
    failed = sorted(
        {
            line[5:].split(" ... ")[0].split("::")[-1].strip()
            for line in out.splitlines()
            if line.startswith("test ") and line.rstrip().endswith("... FAILED")
        }
    )
    return proc.returncode, failed, out


def main():
    # sweep leftovers from an interrupted previous run
    for path in ROOT.rglob("*.r16bak"):
        original = pathlib.Path(str(path)[: -len(".r16bak")])
        shutil.move(str(path), str(original))
        print("swept leftover backup:", path.name)

    originals = {name: digest(path) for name, path in SRC.items()}
    results = []
    bad = False
    for label, key, old, new, expected in MUTATIONS:
        path = SRC[key]
        s = path.read_text()
        assert s.count(old) == 1, "%s: anchor x%d" % (label, s.count(old))
        backup = pathlib.Path(str(path) + ".r16bak")
        shutil.copyfile(path, backup)
        try:
            path.write_text(s.replace(old, new, 1))
            code, failed, out = run_cargo("caly-storage")
            red = [name for name in expected if name in failed]
            compile_error = "error[" in out or "cannot find" in out
            ok = bool(red) and len(failed) > 0
            if compile_error:
                print("   !! the mutation did not compile; it proves nothing")
            results.append((label, ok, red, failed[:6], code))
            print("%-46s %s  red=%s" % (label, "BIT" if ok else "NO EFFECT", red or failed[:4]))
            if not ok:
                print("   output tail:\n", out[-1500:])
        finally:
            # Restore by *content*, and bump the mtime. `shutil.move` preserves the backup's own
            # mtime, which is older than the mutated build's outputs -- cargo then decides the
            # mutated rlib is still fresh and relinks every dependent test binary against it. That
            # is exactly what happened in round 16: the next gate run failed in a test of this round
            # while the sources hashed clean (docs/history/ONBOARDING_NOTES.md 4.71).
            shutil.move(str(backup), str(path))
            os.utime(path, None)
            assert digest(path) == originals[key], "%s: restore did not reproduce the file" % label
        print("   restored clean: %s" % (digest(path) == originals[key]))

    print("\n== summary ==")
    bad = bool(bad) or bool([r for r in results if not r[1]])
    for label, ok, red, failed, code in results:
        print("%-46s %s" % (label, "bit" if ok else "DID NOT BIT (red=%s)" % failed))
        if not ok:
            bad = True
    print("all mutations bit:", not bad)

    code, failed, out = run_cargo("caly-storage")
    print("post-restore caly-storage:", "green" if code == 0 else "RED %s" % failed)

    # The whole workspace, not just the mutated package. Without this a restored file whose mtime
    # predates the mutated build leaves stale artifacts behind, and the *next* person to run the
    # gate gets a red that has nothing to do with the tree (see 4.71).
    proc = subprocess.run(
        ["cargo", "test", "--workspace", "--no-fail-fast"],
        cwd=str(ROOT),
        env=ENV,
        capture_output=True,
        text=True,
    )
    tail = proc.stdout + proc.stderr
    reds = [line for line in tail.splitlines() if line.startswith("test ") and line.endswith("... FAILED")]
    print(
        "post-restore workspace:",
        "green" if proc.returncode == 0 else "RED %s" % reds[:5],
    )
    if proc.returncode != 0:
        bad = True
    for name, path in SRC.items():
        print("digest ok:", name, digest(path) == originals[name])
    return 0 if not bad else 1


sys.exit(main())
