#!/usr/bin/env python3
"""Falsification harness for round 114: the subscription pipeline gets a user surface.

Round 114 put `sources.list`/`sources.inspect` on the v0 wire and in the CLI, and applied the
round-113 contract to sources: the list IS the registry (worker endpoints -- registered and
durable-restored -- unioned with the workflow's resolved sources), and an id outside it is a
named CONFLICT refusal, never a fabricated view (`OPERATOR_SCENARIO_REPORT` finding #3).
  T1 = calyd_wire::sources_list_names_registered_endpoints_before_any_fetch_and_inspect_answers_them
  T2 = calyd_wire::sources_inspect_refuses_a_missing_id_and_an_unknown_source_but_keeps_the_session
  T3 = caly_cli_e2e::caly_sources_lists_the_registered_endpoint_and_source_refuses_unknown_ids

Each mutation below breaks one production property and must bite its judge:
  M1  app.rs:            the registry guard is disabled (any id answers again -- the false
                         success this round closed)                        -> T2/T3 red
  M2  app.rs:            the guard flips to always-refuse (registered ids refused too) -> T1/T3 red
  M3  query/source.rs:   the refusal code becomes Internal instead of Conflict -> T2/T3 red
  M4  app.rs:            the list drops the endpoint registry (registered locators invisible
                         again -- the black box this round opened)          -> T1/T3 red

Rules this harness obeys (DEVELOPMENT_WORKFLOW §6): one mutation at a time, one file per
mutation, bindings/types/arity preserved, backup restored with content AND mtime, sha256
verified, "did not compile" reported separately from "did not bite", and every restored file
gets its mtime bumped IMMEDIATELY (round-110/112 mtime incidents, §4.184/§4.186).
"""
from __future__ import annotations

import hashlib
import os
import shutil
import subprocess
import sys

ROOT = "/home/user/caly"

MUTATIONS = [
    {
        "name": "M1-registry-guard-disabled",
        "file": "crates/caly-daemon/src/app.rs",
        "old": (
            "        let known = self.known_source_ids().map_err(SourceViewError::Internal)?;\n"
            "        if !known.contains(&source_id.0) {"
        ),
        "new": (
            "        let known = self.known_source_ids().map_err(SourceViewError::Internal)?;\n"
            "        if false { // M1: any id answers again"
        ),
        "expect_red": [
            {
                "bin": ["cargo", "test", "-p", "caly-daemon", "--test", "calyd_wire"],
                "name": "sources_inspect_refuses_a_missing_id_and_an_unknown_source_but_keeps_the_session",
            },
            {
                "bin": ["cargo", "test", "-p", "caly-cli", "--test", "caly_cli_e2e"],
                "name": "caly_sources_lists_the_registered_endpoint_and_source_refuses_unknown_ids",
            },
        ],
        "expect_green": [
            {
                "bin": ["cargo", "test", "-p", "caly-daemon", "--test", "calyd_wire"],
                "name": "sources_list_names_registered_endpoints_before_any_fetch_and_inspect_answers_them",
            },
            {
                "bin": ["cargo", "test", "-p", "caly-daemon", "--test", "calyd_wire"],
                "name": "profiles_list_counts_its_lines_and_never_invents_a_second_active",
            },
        ],
    },
    {
        "name": "M2-registry-guard-flips-to-always-refuse",
        "file": "crates/caly-daemon/src/app.rs",
        "old": (
            "        let known = self.known_source_ids().map_err(SourceViewError::Internal)?;\n"
            "        if !known.contains(&source_id.0) {"
        ),
        "new": (
            "        let known = self.known_source_ids().map_err(SourceViewError::Internal)?;\n"
            "        if true { // M2: refuse even registered sources"
        ),
        "expect_red": [
            {
                "bin": ["cargo", "test", "-p", "caly-daemon", "--test", "calyd_wire"],
                "name": "sources_list_names_registered_endpoints_before_any_fetch_and_inspect_answers_them",
            },
            {
                "bin": ["cargo", "test", "-p", "caly-cli", "--test", "caly_cli_e2e"],
                "name": "caly_sources_lists_the_registered_endpoint_and_source_refuses_unknown_ids",
            },
        ],
        "expect_green": [
            {
                "bin": ["cargo", "test", "-p", "caly-daemon", "--test", "calyd_wire"],
                "name": "sources_inspect_refuses_a_missing_id_and_an_unknown_source_but_keeps_the_session",
            },
            {
                "bin": ["cargo", "test", "-p", "caly-daemon", "--test", "calyd_wire"],
                "name": "profiles_list_counts_its_lines_and_never_invents_a_second_active",
            },
        ],
    },
    {
        "name": "M3-refusal-code-becomes-internal",
        "file": "crates/caly-daemon/src/query/source.rs",
        "old": "        ErrorCode::Conflict,\n        ErrorCategory::User,",
        "new": "        ErrorCode::Internal, // M3\n        ErrorCategory::User,",
        "expect_red": [
            {
                "bin": ["cargo", "test", "-p", "caly-daemon", "--test", "calyd_wire"],
                "name": "sources_inspect_refuses_a_missing_id_and_an_unknown_source_but_keeps_the_session",
            },
            {
                "bin": ["cargo", "test", "-p", "caly-cli", "--test", "caly_cli_e2e"],
                "name": "caly_sources_lists_the_registered_endpoint_and_source_refuses_unknown_ids",
            },
        ],
        "expect_green": [
            {
                "bin": ["cargo", "test", "-p", "caly-daemon", "--test", "calyd_wire"],
                "name": "sources_list_names_registered_endpoints_before_any_fetch_and_inspect_answers_them",
            },
            {
                "bin": ["cargo", "test", "-p", "caly-daemon", "--test", "calyd_wire"],
                "name": "profiles_list_counts_its_lines_and_never_invents_a_second_active",
            },
        ],
    },
    {
        "name": "M4-list-drops-the-endpoint-registry",
        "file": "crates/caly-daemon/src/app.rs",
        "old": (
            "        // visible before any fetch (the \"subscription onboarding day\" surface, round 114) and a\n"
            "        // durable-restored entry keeps its own label and kind across restarts.\n"
            "        for endpoint in self.engine.list_source_endpoints()? {"
        ),
        "new": (
            "        // visible before any fetch (the \"subscription onboarding day\" surface, round 114) and a\n"
            "        // durable-restored entry keeps its own label and kind across restarts.\n"
            "        for endpoint in Vec::<caly_engine::SourceEndpoint>::new() { // M4: registry invisible again"
        ),
        "expect_red": [
            {
                "bin": ["cargo", "test", "-p", "caly-daemon", "--test", "calyd_wire"],
                "name": "sources_list_names_registered_endpoints_before_any_fetch_and_inspect_answers_them",
            },
            {
                "bin": ["cargo", "test", "-p", "caly-cli", "--test", "caly_cli_e2e"],
                "name": "caly_sources_lists_the_registered_endpoint_and_source_refuses_unknown_ids",
            },
        ],
        "expect_green": [
            {
                "bin": ["cargo", "test", "-p", "caly-daemon", "--test", "calyd_wire"],
                "name": "sources_inspect_refuses_a_missing_id_and_an_unknown_source_but_keeps_the_session",
            },
            {
                "bin": ["cargo", "test", "-p", "caly-daemon", "--test", "calyd_wire"],
                "name": "profiles_list_counts_its_lines_and_never_invents_a_second_active",
            },
        ],
    },
]


def sha256(path: str) -> str:
    with open(path, "rb") as handle:
        return hashlib.sha256(handle.read()).hexdigest()


def run_tests(targets: list[dict]) -> tuple[int, str, str]:
    """Run each named test; return (exit, combined tail, kind).

    kind is "build_failed" / "red" / "green". A nonzero exit whose log shows a compile error is
    build_failed -- rustc bit, not the judge.
    """
    parts: list[str] = []
    any_red = False
    for target in targets:
        proc = subprocess.run(
            target["bin"] + [target["name"]],
            cwd=ROOT,
            capture_output=True,
            text=True,
            timeout=1800,
        )
        tail = "\n".join((proc.stdout + proc.stderr).splitlines()[-10:])
        parts.append(f"--- {target['name']} (exit {proc.returncode}) ---\n{tail}")
        if "error[" in proc.stdout or "could not compile" in proc.stdout:
            return proc.returncode, "\n".join(parts), "build_failed"
        if proc.returncode != 0:
            any_red = True
    if any_red:
        return 1, "\n".join(parts), "red"
    return 0, "\n".join(parts), "green"


def main() -> int:
    results: list[tuple[str, str]] = []
    for mutation in MUTATIONS:
        path = os.path.join(ROOT, mutation["file"])
        backup = path + ".r114bak"
        with open(path) as handle:
            text = handle.read()
        hits = text.count(mutation["old"])
        if hits != 1:
            print(f"{mutation['name']}: anchor hits={hits} -- skipped")
            results.append((mutation["name"], "anchor-miss"))
            continue
        stat_before = os.stat(path)
        shutil.copy2(path, backup)
        with open(path, "w") as handle:
            handle.write(text.replace(mutation["old"], mutation["new"], 1))
        red_status, red_tail, red_kind = run_tests(mutation["expect_red"])
        green_status, green_tail, green_kind = run_tests(mutation["expect_green"])
        # restore: content AND mtime, then verify byte-identity
        shutil.move(backup, path)
        os.utime(path, ns=(stat_before.st_atime_ns, stat_before.st_mtime_ns))
        pre = sha256(path)
        verdict = (
            red_kind == "red"
            and green_kind == "green"
            and pre == sha256(path)
            and os.path.getmtime(path) == stat_before.st_mtime
        )
        # Bump the restored file's mtime to now IMMEDIATELY: cargo's freshness check compares
        # mtimes, and the mutated tree just produced artifacts newer than the restored source --
        # the next mutation's build would otherwise link the previous mutation's binary
        # (round-112 first run bit itself; §4.184/§4.186).
        os.utime(path, None)
        results.append((mutation["name"], "BIT" if verdict else "NO-BITE"))
        print(
            f"== {mutation['name']}: red={red_kind} green={green_kind} -> "
            f"{'BIT' if verdict else 'NO-BITE'}"
        )
        if not verdict:
            print(red_tail)
            print(green_tail)
    all_bit = all(kind == "BIT" for _, kind in results)
    leftovers = [
        os.path.join(ROOT, mutation["file"]) + ".r114bak"
        for mutation in MUTATIONS
        if os.path.exists(os.path.join(ROOT, mutation["file"]) + ".r114bak")
    ]
    print(f"leftovers: {leftovers}")
    print(f"all mutations bit: {all_bit}")
    return 0 if (all_bit and not leftovers) else 1


if __name__ == "__main__":
    sys.exit(main())
