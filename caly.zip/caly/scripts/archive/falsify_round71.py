#!/usr/bin/env python3
"""Round 71 falsification harness.

The claim under test (`IMPLEMENTATION_STATUS §8.6`, the v0 record dialect): the hello /
hello_ack / request-header vocabulary is one implementation in `caly_ipc::dialect`, and
the CLI **validates the hello_ack's content** (protocol major, session encoding) instead
of trusting the frame kind as v0 did. The judges:

- `caly_cli_e2e::caly_refuses_a_hello_ack_that_contradicts_the_session` (fake daemon
  answers `encoding=msgpack`/`major=2`; the CLI must exit 13 and name the mismatch).
- `caly_ipc::dialect::server_hello_ack_records_keep_the_legacy_keys_first_then_echo_the_session`
  (the ack carries the pre-round keys plus the echo a client can check).

- M1 (must bite)  the CLI forgets to validate the ack (v0 behavior, kind only) — the
      fake-daemon judge sees exit 0 and fails.
- M2 (must bite)  the daemon's ack drops the echo keys (pre-round 3-key ack) — the
      key-order judge fails.

Usage: `python3 scripts/archive/falsify_round71.py` (exit 0 = both bit, files restored).
"""

import hashlib
import os
import pathlib
import subprocess
import sys
import time

ROOT = pathlib.Path("/home/user/caly_extract/caly")
ENV = dict(os.environ)
ENV["PATH"] = str(pathlib.Path.home() / ".cargo/bin") + ":" + ENV.get("PATH", "")

CALY = ROOT / "crates/caly-cli/src/bin/caly.rs"
DIALECT = ROOT / "crates/caly-ipc/src/dialect.rs"

M1_OLD = """    let view = server_hello_ack_from_records(&wire_parse_records(&text))?;
    client_validate_hello_ack(&view, json)?;
    eprintln!("""
M1_NEW = """    let view = server_hello_ack_from_records(&wire_parse_records(&text))?;
    let _ = (&view, json);
    eprintln!("""
M1_JUDGE = [
    "-p", "caly-cli", "--test", "caly_cli_e2e",
    "caly_refuses_a_hello_ack_that_contradicts_the_session",
]

M2_OLD = """    vec![
        ("daemon_name", daemon_name.to_owned()),
        ("daemon_version", daemon_version.to_owned()),
        ("instance_id", instance_id.to_owned()),
        ("major", "1".to_owned()),
        ("minor", "0".to_owned()),
        (
            "encoding",
            if session_json { "json" } else { "records" }.to_owned(),
        ),
        ("compression", "none".to_owned()),
    ]
"""
M2_NEW = """    vec![
        ("daemon_name", daemon_name.to_owned()),
        ("daemon_version", daemon_version.to_owned()),
        ("instance_id", instance_id.to_owned()),
    ]
"""
M2_JUDGE = [
    "-p", "caly-ipc",
    "server_hello_ack_records_keep_the_legacy_keys_first_then_echo_the_session",
]


def digest(path):
    return hashlib.sha256(pathlib.Path(path).read_bytes()).hexdigest()


def sweep_strays():
    for path in ROOT.rglob("*.r71bak"):
        print(f"  note  sweeping stale {path}")
        path.unlink()


def run_judge(args):
    begin = time.time()
    proc = subprocess.run(
        ["cargo", "test"] + args,
        cwd=ROOT,
        env=ENV,
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
        text=True,
        timeout=900,
    )
    return proc, time.time() - begin


def main():
    original_caly = CALY.read_text()
    original_dialect = DIALECT.read_text()
    all_ok = True
    try:
        for label, path, old, new, judge in [
            ("M1 the CLI skips ack validation (must bite)", CALY, M1_OLD, M1_NEW, M1_JUDGE),
            ("M2 the ack drops its echo keys (must bite)", DIALECT, M2_OLD, M2_NEW, M2_JUDGE),
        ]:
            if path.read_text() != (original_caly if path == CALY else original_dialect):
                print(f"  FAIL  {label}: tree is dirty before mutation")
                all_ok = False
                break
            if old not in path.read_text():
                print(f"  FAIL  {label}: anchor not found — pattern drifted")
                all_ok = False
                break
            backup = ROOT / ".r71bak"
            backup.write_bytes(path.read_bytes())
            path.write_text(path.read_text().replace(old, new, 1))
            proc, elapsed = run_judge(judge)
            if proc.returncode != 0 and "error[E" not in proc.stdout:
                print(f"  ok    {label} (bite in {elapsed:.1f}s)")
            elif "error[E" in proc.stdout:
                print(f"  FAIL  {label}: compiler error, not a property failure ({elapsed:.1f}s)")
                all_ok = False
            else:
                print(f"  FAIL  {label}: judge stayed green ({elapsed:.1f}s)")
                all_ok = False
            path.write_bytes(backup.read_bytes())
            backup.unlink()
            if path.read_text() != (original_caly if path == CALY else original_dialect):
                print(f"  FAIL  {label}: restore mismatch")
                all_ok = False
    finally:
        sweep_strays()
        if CALY.read_text() != original_caly:
            CALY.write_text(original_caly)
            print("  note  hard-restored caly.rs")
        if DIALECT.read_text() != original_dialect:
            DIALECT.write_text(original_dialect)
            print("  note  hard-restored dialect.rs")

    if all_ok:
        print("all mutations behaved as predicted: True")
        return 0
    print("all mutations behaved as predicted: False")
    return 1


if __name__ == "__main__":
    sys.exit(main())
