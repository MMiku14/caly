"""Falsification harness for round 40 (`ADR-041` §2 follow-up: the name claim on every record family).

Same discipline as rounds 16/32–39: one mutation per run, exact-anchor replacement with
`assert count == 1`, restore by content and mtime, sha256-verified, stale `*.r40bak` swept at
startup. A mutation that cannot compile proves nothing (`§4.112`).

Three mutations: the generalized check disarmed, the check quietly comparing the stem to the
**raw** id (which would accept a file named by its un-escaped id — the second judge exists for
exactly this), and the writer dropping the escaping so the store refuses its own records on
reopen.

Usage: `python3 scripts/archive/falsify_round40.py` (exit 0 = every mutation bit, every file restored).
"""

import hashlib
import os
import pathlib
import shutil
import subprocess
import sys

ROOT = pathlib.Path("/home/user/caly")
ENV = dict(os.environ)
ENV["PATH"] = str(pathlib.Path.home() / ".cargo/bin") + ":" + ENV.get("PATH", "")
SRC = ROOT / "crates/caly-storage/src/fs_store.rs"

NAME_CLAIM_CHECK = """                    if stem != Some(escape_component(id).as_str()) {
                        problems.push(format!(
                            "{kind} record {suffix} is not the name its id ({id}) would occupy \\
                             -- legacy or forged naming"
                        ));"""

MUTATIONS = [
    (
        "M1 the generalized name check is disarmed",
        NAME_CLAIM_CHECK,
        """                    if false && stem != Some(escape_component(id).as_str()) {
                        problems.push(format!(
                            "{kind} record {suffix} is not the name its id ({id}) would occupy \\
                             -- legacy or forged naming"
                        ));""",
        [
            "boot_refuses_a_flattened_era_name_in_every_record_family",
            "boot_refuses_a_record_file_named_by_its_raw_unescaped_id",
        ],
    ),
    (
        "M2 the check compares the stem to the raw id",
        NAME_CLAIM_CHECK,
        """                    if stem != Some(id) {
                        problems.push(format!(
                            "{kind} record {suffix} is not the name its id ({id}) would occupy \\
                             -- legacy or forged naming"
                        ));""",
        ["boot_refuses_a_record_file_named_by_its_raw_unescaped_id"],
    ),
    (
        "M3 the writer drops the escaping for record paths",
        'format!("records/{kind}/{}.rec", escape_component(id))',
        'format!("records/{kind}/{}.rec", id)',
        ["the_durable_enumeration_is_the_directory_and_survives_a_restart"],
    ),
]


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def run_cargo():
    proc = subprocess.run(
        ["cargo", "test", "-p", "caly-storage", "--no-fail-fast"],
        cwd=str(ROOT),
        env=ENV,
        capture_output=True,
        text=True,
    )
    out = proc.stdout + proc.stderr
    failed = sorted(
        {
            line[5:].split(" ... ")[0].split("::")[-1].strip()
            for line in out.splitlines()
            if line.startswith("test ") and line.rstrip().endswith("... FAILED")
        }
    )
    return proc.returncode, failed, out


def main():
    for path in ROOT.rglob("*.r40bak"):
        original = pathlib.Path(str(path)[: -len(".r40bak")])
        shutil.move(str(path), str(original))
        print("swept leftover backup:", path.name)

    original = digest(SRC)
    results = []
    bad = False
    for label, old, new, expected in MUTATIONS:
        s = SRC.read_text()
        assert s.count(old) == 1, "%s: anchor x%d" % (label, s.count(old))
        backup = pathlib.Path(str(SRC) + ".r40bak")
        shutil.copyfile(SRC, backup)
        try:
            SRC.write_text(s.replace(old, new, 1))
            code, failed, out = run_cargo()
            red = [name for name in expected if name in failed]
            compile_error = "error[" in out or "could not compile" in out
            ok = bool(red) and not compile_error
            results.append((label, ok))
            print("%-48s %s  red=%s" % (label, "BIT" if ok else "NO EFFECT", red or failed[:4]))
            if not ok:
                if compile_error:
                    print("   !! the mutation did not compile; it proves nothing")
                print("   output tail:\n", out[-1200:])
        finally:
            shutil.move(str(backup), str(SRC))
            os.utime(SRC, None)
            assert digest(SRC) == original, "%s: restore did not reproduce the file" % label

    print("\n== summary ==")
    for label, ok in results:
        print("%-48s %s" % (label, "bit" if ok else "DID NOT BIT"))
        if not ok:
            bad = True
    print("all mutations bit:", not bad)
    sys.exit(1 if bad else 0)


if __name__ == "__main__":
    main()
