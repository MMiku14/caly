#!/usr/bin/env python3
"""Falsification harness for round 112: CLI --role reaches the daemon's role gate.

Four new judges were added in `crates/caly-cli/tests/caly_cli_e2e.rs`:
  T1 = caly_role_viewer_reads_but_is_refused_an_admin_only_command
  T2 = caly_role_operator_is_refused_an_admin_only_command_too
  T3 = caly_role_flag_rejects_an_unknown_role_as_usage_before_any_round_trip
  T4 = caly_role_admin_is_the_default_and_still_reaches_admin_commands

Each mutation below breaks one production property and must bite its judge:
  M1  handshake_drive.rs: the hello bytes hardcode Admin even though the config carries the
      declared role (the first-draft bug, caught by hand before the judges landed) -> T1/T2 red
  M2  caly.rs: the no-flag default role flips to Viewer                           -> T4 red
  M3  caly.rs: parse_role maps unknown spellings to Admin instead of refusing     -> T3 red

Rules this harness obeys (DEVELOPMENT_WORKFLOW §6): one mutation at a time, one file per
mutation, bindings/types/arity preserved, backup restored with content AND mtime, sha256
verified, and "did not compile" reported separately from "did not bite". Restored files get
their mtime bumped to now so cargo cannot reuse a mutated artifact (round-110 incident,
ONBOARDING_NOTES §4.184).
"""
from __future__ import annotations

import hashlib
import os
import shutil
import subprocess
import sys

ROOT = "/home/user/caly"
TEST_BIN = ["cargo", "test", "-p", "caly-cli", "--test", "caly_cli_e2e"]

MUTATIONS = [
    {
        "name": "M1-hello-bytes-hardcode-admin",
        "file": "crates/caly-ipc/src/handshake_drive.rs",
        "old": "    pump.send(WIRE_KIND_HELLO, &client_hello_payload(role, json))",
        "new": "    pump.send(WIRE_KIND_HELLO, &client_hello_payload(Role::Admin, json)) // M1",
        "expect_red": [
            "caly_role_viewer_reads_but_is_refused_an_admin_only_command",
            "caly_role_operator_is_refused_an_admin_only_command_too",
        ],
        "expect_green": [
            "caly_role_flag_rejects_an_unknown_role_as_usage_before_any_round_trip",
            "caly_role_admin_is_the_default_and_still_reaches_admin_commands",
        ],
    },
    {
        "name": "M2-default-role-flips-to-viewer",
        "file": "crates/caly-cli/src/bin/caly.rs",
        "old": "    let mut role = Role::Admin;",
        "new": "    let mut role = Role::Viewer; // M2",
        "expect_red": ["caly_role_admin_is_the_default_and_still_reaches_admin_commands"],
        "expect_green": [
            "caly_role_viewer_reads_but_is_refused_an_admin_only_command",
            "caly_role_operator_is_refused_an_admin_only_command_too",
            "caly_role_flag_rejects_an_unknown_role_as_usage_before_any_round_trip",
        ],
    },
    {
        "name": "M3-unknown-role-maps-to-admin",
        "file": "crates/caly-cli/src/bin/caly.rs",
        "old": '        "admin" => Some(Role::Admin),\n        _ => None,',
        "new": '        "admin" => Some(Role::Admin),\n        _ => Some(Role::Admin), // M3',
        "expect_red": ["caly_role_flag_rejects_an_unknown_role_as_usage_before_any_round_trip"],
        "expect_green": [
            "caly_role_viewer_reads_but_is_refused_an_admin_only_command",
            "caly_role_operator_is_refused_an_admin_only_command_too",
            "caly_role_admin_is_the_default_and_still_reaches_admin_commands",
        ],
    },
]


def sha256(path: str) -> str:
    with open(path, "rb") as handle:
        return hashlib.sha256(handle.read()).hexdigest()


def run_tests(names: list[str]) -> tuple[int, str, str]:
    """Run each named test; return (exit, combined tail, kind).

    kind is "build_failed" / "red" / "green". A nonzero exit whose log shows a compile error is
    build_failed -- rustc bit, not the judge.
    """
    parts: list[str] = []
    any_red = False
    for name in names:
        proc = subprocess.run(
            TEST_BIN + [name], cwd=ROOT, capture_output=True, text=True, timeout=1800
        )
        tail = "\n".join((proc.stdout + proc.stderr).splitlines()[-10:])
        parts.append(f"--- {name} (exit {proc.returncode}) ---\n{tail}")
        if "error[" in proc.stdout or "could not compile" in proc.stdout:
            return proc.returncode, "\n".join(parts), "build_failed"
        if proc.returncode != 0:
            any_red = True
    if any_red:
        return 1, "\n".join(parts), "red"
    return 0, "\n".join(parts), "green"


def main() -> int:
    results: list[tuple[str, str]] = []
    for mutation in MUTATIONS:
        path = os.path.join(ROOT, mutation["file"])
        backup = path + ".r112bak"
        with open(path) as handle:
            text = handle.read()
        hits = text.count(mutation["old"])
        if hits != 1:
            print(f"{mutation['name']}: anchor hits={hits} -- skipped")
            results.append((mutation["name"], "anchor-miss"))
            continue
        stat_before = os.stat(path)
        shutil.copy2(path, backup)
        with open(path, "w") as handle:
            handle.write(text.replace(mutation["old"], mutation["new"], 1))
        red_status, red_tail, red_kind = run_tests(mutation["expect_red"])
        green_status, green_tail, green_kind = run_tests(mutation["expect_green"])
        # restore: content AND mtime, then verify byte-identity
        shutil.move(backup, path)
        os.utime(path, ns=(stat_before.st_atime_ns, stat_before.st_mtime_ns))
        pre = sha256(path)
        verdict = (
            red_kind == "red"
            and green_kind == "green"
            and pre == sha256(path)
            and os.path.getmtime(path) == stat_before.st_mtime
        )
        # Bump the restored file's mtime to now IMMEDIATELY: cargo's freshness check compares
        # mtimes, and the mutated tree just produced artifacts newer than the restored source —
        # the next mutation's build would otherwise link the previous mutation's binary
        # (round-110 incident §4.184, and this script's own first run bit itself with it).
        os.utime(path, None)
        results.append((mutation["name"], "BIT" if verdict else "NO-BITE"))
        print(
            f"== {mutation['name']}: red={red_kind} green={green_kind} -> "
            f"{'BIT' if verdict else 'NO-BITE'}"
        )
        if not verdict:
            print(red_tail)
            print(green_tail)
    all_bit = all(kind == "BIT" for _, kind in results)
    leftovers = [name for name in os.listdir(ROOT) if name.endswith(".r112bak")]
    print(f"leftovers: {leftovers}")
    print(f"all mutations bit: {all_bit}")
    return 0 if (all_bit and not leftovers) else 1


if __name__ == "__main__":
    sys.exit(main())
