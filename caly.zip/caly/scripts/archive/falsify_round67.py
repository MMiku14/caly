#!/usr/bin/env python3
"""Round 67 falsification harness.

The claim under test: a real apply's runtime root holds the pinned assets' exact bytes
(the gz/tgz copy, the gunzipped/tar-extracted binary, the two geo databases) and the
merged config (artifact plus documented envelope), judged by
`spawn_artifacts::the_spawned_mihomo_artifacts_are_the_pinned_assets_byte_for_byte` and
`..._singbox_...`. Each mutation corrupts one of those bytes/merge while compiling;
the golden judges must go red (a digest-of-asset judge would stay green, which is the
gap this round closes).

Mutations (all in `crates/caly-daemon/src/effect_std.rs`, SpawnCore):
- M1  the geoip copy carries the geosite bytes (asset cross-write);
- M2  the mihomo envelope drops the geox-url block;
- M3  the sing-box merge drops the clash_api controller;
- M4  the sing-box extraction loses --strip-components (member lands in a subdir);
- M5  the mihomo envelope says log-level: debug instead of info.

Usage: `python3 scripts/archive/falsify_round67.py` (exit 0 = every mutation bit, files restored).
"""

import hashlib
import os
import pathlib
import subprocess
import sys
import time

ROOT = pathlib.Path("/home/user/caly_extract/caly")
ENV = dict(os.environ)
ENV["PATH"] = str(pathlib.Path.home() / ".cargo/bin") + ":" + ENV.get("PATH", "")

SRC = ROOT / "crates/caly-daemon/src/effect_std.rs"

MUTATIONS = [
    (
        "M1 geoip copy carries the geosite bytes",
        'self.write_root(&format!("{dir}/geoip.metadb"), geoip, "asset-copy")?;',
        'self.write_root(&format!("{dir}/geoip.metadb"), geosite.clone(), "asset-copy")?;',
    ),
    (
        "M2 mihomo envelope drops the geox-url block",
        """                     log-level: info\\n\\
                     geox-url:\\n  geoip: \\"http://127.0.0.1:1/geoip.metadb\\"\\n  geosite: \\"http://127.0.0.1:1/geosite.dat\\"\\n  mmdb: \\"http://127.0.0.1:1/country.mmdb\\"\\n  asn: \\"http://127.0.0.1:1/GeoLite2-ASN.mmdb\\"\\n\"""",
        """                     log-level: info\\n\"""",
    ),
    (
        "M3 sing-box merge drops the clash_api controller",
        """        if let Some(experimental) = config.get_mut("experimental").and_then(|v| v.as_object_mut())
        {
            experimental.insert(
                "clash_api".to_owned(),
                serde_json::json!({
                    "external_controller": format!("127.0.0.1:{controller_port}")
                }),
            );
        }""",
        "",
    ),
    (
        "M4 sing-box extraction loses --strip-components",
        "--strip-components=1 && chmod +x sing-box",
        "--strip-components=0 && chmod +x sing-box",
    ),
    (
        "M5 mihomo envelope says log-level: debug",
        """                     log-level: info\\n\\
""",
        """                     log-level: debug\\n\\
""",
    ),
]


def digest(path):
    return hashlib.sha256(pathlib.Path(path).read_bytes()).hexdigest()


def sweep_strays():
    for path in ROOT.rglob("*.r67bak"):
        print(f"  note  sweeping stale {path}")
        path.unlink()


def run_judges():
    begin = time.time()
    proc = subprocess.run(
        [
            "cargo",
            "test",
            "-p",
            "caly-daemon",
            "--test",
            "spawn_artifacts",
        ],
        cwd=ROOT,
        env=ENV,
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
        text=True,
        timeout=900,
    )
    return proc, time.time() - begin


def main():
    original = SRC.read_text()
    original_digest = digest(SRC)
    anchors = set()
    for name, old, new in MUTATIONS:
        anchors.add(old)
    for anchor in sorted(anchors):
        count = original.count(anchor)
        if count != 1:
            print(f"  FAIL  anchor count={count} (want 1) for: {anchor[:60]!r}")
            return 1

    sweep_strays()
    all_bit = True
    try:
        for name, old, new in MUTATIONS:
            backup = ROOT / ".r67bak"
            backup.write_text(SRC.read_text())
            SRC.write_text(SRC.read_text().replace(old, new, 1))
            if digest(SRC) == original_digest:
                print(f"  FAIL  {name}: mutation produced no change")
                SRC.write_text(backup.read_text())
                all_bit = False
                continue
            try:
                proc, elapsed = run_judges()
                if proc.returncode != 0:
                    if "error[E" in proc.stdout:
                        print(f"  FAIL  {name}: compiler error, not a property failure ({elapsed:.1f}s)")
                        tail = [l for l in proc.stdout.splitlines() if "error[E" in l][:3]
                        print("        " + " | ".join(tail))
                        all_bit = False
                    else:
                        print(f"  ok    {name} (bite in {elapsed:.1f}s)")
                else:
                    print(f"  FAIL  {name}: judges stayed green ({elapsed:.1f}s)")
                    all_bit = False
            except subprocess.TimeoutExpired:
                print(f"  FAIL  {name}: timed out (900s) — hanging mutation, not a bite")
                all_bit = False
            finally:
                SRC.write_text(backup.read_text())
                backup.unlink()
            if SRC.read_text() != original:
                print(f"  FAIL  {name}: restore mismatch")
                all_bit = False
    finally:
        sweep_strays()

    final_digest = digest(SRC)
    if final_digest != original_digest:
        print(f"  FAIL  final digest mismatch: {final_digest} != {original_digest}")
        all_bit = False
    if all_bit:
        print("all mutations bit: True")
        return 0
    print("all mutations bit: False")
    return 1


if __name__ == "__main__":
    sys.exit(main())
