"""Falsification harness for round 37 (`ADR-040`: a `ByteStream` label is the caller's own name).

Same discipline as rounds 16/32–36: one mutation per run, exact-anchor replacement with
`assert count == 1`, restore by content and mtime, sha256-verified, stale `*.r37bak` swept at
startup. A mutation that cannot compile proves nothing (`§4.112`).

The four mutations walk the label's failure modes: the host path riding back out of the sandbox
(the original sin this round closed), a label that is *nothing* (parity alone would forgive it —
both backends empty is still "equal"), a simulator-side divergence, and the fetch label losing
its pinned shape.

Usage: `python3 scripts/archive/falsify_round37.py` (exit 0 = every mutation bit, every file restored).
"""

import hashlib
import os
import pathlib
import shutil
import subprocess
import sys

ROOT = pathlib.Path("/home/user/caly")
ENV = dict(os.environ)
ENV["PATH"] = str(pathlib.Path.home() / ".cargo/bin") + ":" + ENV.get("PATH", "")
SRC = {
    "std": ROOT / "crates/caly-io-std/src/lib.rs",
    "sim": ROOT / "crates/caly-io-sim/src/port_impl.rs",
}

MUTATIONS = [
    (
        "M1 the host path rides back out of the sandbox",
        "std",
        """            Ok(ByteStream {
                label: path.as_relative_path(),
            })""",
        "            Ok(ByteStream { label: target })",
        ["open_stream_label_carries_no_host_path"],
    ),
    (
        "M2 the label is nothing at all (parity forgives)",
        "std",
        """            Ok(ByteStream {
                label: path.as_relative_path(),
            })""",
        '            Ok(ByteStream { label: String::new() })\n            // ^ empty on BOTH backends would still be "equal" — the shared judge\n            // asserts the label IS the requested path, not merely that backends match',
        ["fs_port_contract_passes_against_real_files"],
    ),
    (
        "M3 the simulator drifts to a host-flavoured label",
        "sim",
        """                Ok(ByteStream { label: key })""",
        '                Ok(ByteStream { label: format!("/var/host/{key}") })',
        ["sim_fs_satisfies_the_shared_fs_contract"],
    ),
    (
        "M4 the fetch label loses its pinned shape",
        "sim",
        'label: format!("http:{}", req.url),',
        'label: format!("stream:{}", req.url),',
        ["fetch_body_label_names_the_request_in_a_pinned_shape"],
    ),
]


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def run_cargo():
    proc = subprocess.run(
        ["cargo", "test", "-p", "caly-io-std", "-p", "caly-io-sim", "--no-fail-fast"],
        cwd=str(ROOT),
        env=ENV,
        capture_output=True,
        text=True,
    )
    out = proc.stdout + proc.stderr
    failed = sorted(
        {
            line[5:].split(" ... ")[0].split("::")[-1].strip()
            for line in out.splitlines()
            if line.startswith("test ") and line.rstrip().endswith("... FAILED")
        }
    )
    return proc.returncode, failed, out


def main():
    for path in ROOT.rglob("*.r37bak"):
        original = pathlib.Path(str(path)[: -len(".r37bak")])
        shutil.move(str(path), str(original))
        print("swept leftover backup:", path.name)

    originals = {name: digest(path) for name, path in SRC.items()}
    results = []
    bad = False
    for label, key, old, new, expected in MUTATIONS:
        path = SRC[key]
        s = path.read_text()
        assert s.count(old) == 1, "%s: anchor x%d" % (label, s.count(old))
        backup = pathlib.Path(str(path) + ".r37bak")
        shutil.copyfile(path, backup)
        try:
            path.write_text(s.replace(old, new, 1))
            code, failed, out = run_cargo()
            red = [name for name in expected if name in failed]
            compile_error = "error[" in out or "could not compile" in out
            ok = bool(red) and not compile_error
            results.append((label, ok))
            print("%-48s %s  red=%s" % (label, "BIT" if ok else "NO EFFECT", red or failed[:4]))
            if not ok:
                if compile_error:
                    print("   !! the mutation did not compile; it proves nothing")
                print("   output tail:\n", out[-1200:])
        finally:
            shutil.move(str(backup), str(path))
            os.utime(path, None)
            assert digest(path) == originals[key], "%s: restore did not reproduce the file" % label

    print("\n== summary ==")
    for label, ok in results:
        print("%-48s %s" % (label, "bit" if ok else "DID NOT BIT"))
        if not ok:
            bad = True
    print("all mutations bit:", not bad)
    sys.exit(1 if bad else 0)


if __name__ == "__main__":
    main()
