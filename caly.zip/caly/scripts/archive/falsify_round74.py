#!/usr/bin/env python3
"""Round 74 falsification harness.

The claim under test (`ADR-054`): `Fs::stat_many` is one logical port call whose entries are
exactly the one-by-one `stat` answers, and `FsStore::object_records` dates its whole
directory with **one** `stat_many` (zero `stat` calls) — behavior identical to the
per-record reads it replaced. The judges:

- `caly-storage/tests/stat_many.rs::object_records_dates_its_whole_directory_with_one_stat_many`
  (CountingFs asserts `stat_many == 1`, `stat == 0`, ages correct)
- `caly-io-sim/tests/contract.rs::sim_fs_satisfies_the_shared_fs_contract`
  (the shared contract, incl. the new `stat_many` items)

- M1 (must bite)  `object_records` falls back to per-record `stat` — the counting judge
      sees `stat > 0` and fails.
- M2 (must bite)  `SimFs::stat_many` returns the wrong number of entries — the shared
      contract's length assertion fails (and the store would zip misaligned).

Usage: `python3 scripts/archive/falsify_round74.py` (exit 0 = both bit, files restored).
"""

import hashlib
import os
import pathlib
import subprocess
import sys
import time

ROOT = pathlib.Path("/home/user/caly_extract/caly")
ENV = dict(os.environ)
ENV["PATH"] = str(pathlib.Path.home() / ".cargo/bin") + ":" + ENV.get("PATH", "")

FS_STORE = ROOT / "crates/caly-storage/src/fs_store.rs"
SIM = ROOT / "crates/caly-io-sim/src/port_impl.rs"

M1_OLD = """        let metas = drive_port(
            self.inner.fs.stat_many(&paths, ctx),
            ctx,
            self.inner.clock.as_deref(),
        )?
        .map_err(from_iofault)?;"""
M1_NEW = """        let mut metas = Vec::with_capacity(paths.len());
        for path in &paths {
            let meta = drive_port(self.inner.fs.stat(path, ctx), ctx, self.inner.clock.as_deref())?
                .map_err(from_iofault)?;
            metas.push(meta);
        }"""
M1_JUDGE = [
    "-p", "caly-storage", "--test", "stat_many",
    "object_records_dates_its_whole_directory_with_one_stat_many",
]

M2_OLD = "            Ok(keys.iter().map(|key| sim_meta(&guard, key)).collect())"
M2_NEW = "            Ok(keys.iter().map(|key| sim_meta(&guard, key)).take(keys.len() - 1).collect())"
M2_JUDGE = [
    "-p", "caly-io-sim", "--test", "contract",
    "sim_fs_satisfies_the_shared_fs_contract",
]


def digest(path):
    return hashlib.sha256(pathlib.Path(path).read_bytes()).hexdigest()


def sweep_strays():
    for path in ROOT.rglob("*.r74bak"):
        print(f"  note  sweeping stale {path}")
        path.unlink()


def run_judge(args):
    begin = time.time()
    proc = subprocess.run(
        ["cargo", "test"] + args,
        cwd=ROOT,
        env=ENV,
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
        text=True,
        timeout=300,
    )
    return proc, time.time() - begin


def main():
    original_store = FS_STORE.read_text()
    original_sim = SIM.read_text()
    all_ok = True
    try:
        for label, path, original, old, new, judge in [
            (
                "M1 object_records falls back to per-record stat (must bite)",
                FS_STORE, original_store, M1_OLD, M1_NEW, M1_JUDGE,
            ),
            (
                "M2 stat_many returns the wrong count (must bite)",
                SIM, original_sim, M2_OLD, M2_NEW, M2_JUDGE,
            ),
        ]:
            if path.read_text() != original:
                print(f"  FAIL  {label}: tree is dirty before mutation")
                all_ok = False
                break
            if old not in original:
                print(f"  FAIL  {label}: anchor not found — pattern drifted")
                all_ok = False
                break
            backup = ROOT / ".r74bak"
            backup.write_bytes(path.read_bytes())
            path.write_text(path.read_text().replace(old, new, 1))
            proc, elapsed = run_judge(judge)
            if proc.returncode != 0 and "error[E" not in proc.stdout:
                print(f"  ok    {label} (bite in {elapsed:.1f}s)")
            elif "error[E" in proc.stdout:
                print(f"  FAIL  {label}: compiler error, not a property failure ({elapsed:.1f}s)")
                all_ok = False
            else:
                print(f"  FAIL  {label}: judge stayed green ({elapsed:.1f}s)")
                all_ok = False
            path.write_bytes(backup.read_bytes())
            backup.unlink()
            if path.read_text() != original:
                print(f"  FAIL  {label}: restore mismatch")
                all_ok = False
    finally:
        sweep_strays()
        if FS_STORE.read_text() != original_store:
            FS_STORE.write_text(original_store)
            print("  note  hard-restored fs_store.rs")
        if SIM.read_text() != original_sim:
            SIM.write_text(original_sim)
            print("  note  hard-restored port_impl.rs")

    if all_ok:
        print("all mutations behaved as predicted: True")
        return 0
    print("all mutations behaved as predicted: False")
    return 1


if __name__ == "__main__":
    sys.exit(main())
