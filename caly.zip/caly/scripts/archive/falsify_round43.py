"""Falsification harness for round 43 (`calyd`: the first executable, judged over a real socket).

Same discipline as rounds 16/32–42: one mutation per run, exact-anchor replacement with
`assert count == 1`, restore by content and mtime, sha256-verified, stale `*.r43bak` swept at
startup. A mutation that cannot compile proves nothing (`§4.112`).

Four mutations against the binary's source, each aimed at one wire judge: answering requests
before hello (session order), swallowing the inbound cap (read-then-answer), dropping a status
field from the wire (a client could not tell "none" from "forgotten"), and the whitelist
falling open (any op answered as status).

Usage: `python3 scripts/archive/falsify_round43.py` (exit 0 = every mutation bit, every file restored).
"""

import hashlib
import os
import pathlib
import shutil
import subprocess
import sys

ROOT = pathlib.Path("/home/user/caly")
ENV = dict(os.environ)
ENV["PATH"] = str(pathlib.Path.home() / ".cargo/bin") + ":" + ENV.get("PATH", "")
SRC = ROOT / "crates/caly-daemon/src/bin/calyd.rs"

MUTATIONS = [
    (
        "M1 a request before hello is answered",
        """            KIND_REQUEST if hello_seen => {""",
        """            KIND_REQUEST => {
                let _ = hello_seen;"""
        ,
        ["a_request_before_hello_is_refused_not_answered"],
    ),
    (
        "M2 the inbound cap swallows over-size frames",
        """    if len > MAX_FRAME_SIZE_BYTES as usize {
        return Err(std::io::Error::new(""",
        """    if false && len > MAX_FRAME_SIZE_BYTES as usize {
        return Err(std::io::Error::new(""",
        ["a_frame_over_the_wire_cap_is_refused_by_the_connection"],
    ),
    (
        "M3 the response forgets a field",
        """        (
            "pending_recovery_decisions",
            status.pending_recovery_decisions.to_string(),
        ),""",
        """        // (pending_recovery_decisions forgotten on the wire)""",
        ["hello_then_runtime_status_answers_every_field_over_the_wire"],
    ),
    (
        "M4 the whitelist falls open",
        """                if operation != "runtime.status" {""",
        """                if false {""",
        ["an_operation_off_the_v0_wire_is_refused_by_name_not_guessed"],
    ),
]


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def run_cargo():
    proc = subprocess.run(
        ["cargo", "test", "-p", "caly-daemon", "--test", "calyd_wire", "--no-fail-fast"],
        cwd=str(ROOT),
        env=ENV,
        capture_output=True,
        text=True,
    )
    out = proc.stdout + proc.stderr
    failed = sorted(
        {
            line[5:].split(" ... ")[0].split("::")[-1].strip()
            for line in out.splitlines()
            if line.startswith("test ") and line.rstrip().endswith("... FAILED")
        }
    )
    return proc.returncode, failed, out


def main():
    for path in ROOT.rglob("*.r43bak"):
        original = pathlib.Path(str(path)[: -len(".r43bak")])
        shutil.move(str(path), str(original))
        print("swept leftover backup:", path.name)

    original = digest(SRC)
    results = []
    bad = False
    for label, old, new, expected in MUTATIONS:
        s = SRC.read_text()
        assert s.count(old) == 1, "%s: anchor x%d" % (label, s.count(old))
        backup = pathlib.Path(str(SRC) + ".r43bak")
        shutil.copyfile(SRC, backup)
        try:
            SRC.write_text(s.replace(old, new, 1))
            code, failed, out = run_cargo()
            red = [name for name in expected if name in failed]
            compile_error = "error[" in out or "could not compile" in out
            ok = bool(red) and not compile_error
            results.append((label, ok))
            print("%-46s %s  red=%s" % (label, "BIT" if ok else "NO EFFECT", red or failed[:4]))
            if not ok:
                if compile_error:
                    print("   !! the mutation did not compile; it proves nothing")
                print("   output tail:\n", out[-1200:])
        finally:
            shutil.move(str(backup), str(SRC))
            os.utime(SRC, None)
            assert digest(SRC) == original, "%s: restore did not reproduce the file" % label

    print("\n== summary ==")
    for label, ok in results:
        print("%-46s %s" % (label, "bit" if ok else "DID NOT BIT"))
        if not ok:
            bad = True
    print("all mutations bit:", not bad)
    sys.exit(1 if bad else 0)


if __name__ == "__main__":
    main()
