#!/usr/bin/env python3
"""Round 133 falsify: the R131-ledger fixes.

Four mutations, one production file each:
  M1 the session stream-table cap disappears (R131-F1's judge must go red);
  M2 the resolver spawn failure panics again instead of refusing (R131-F2);
  M3 a local subscription->kind match reappears in caly-app (R131-F4's gate);
  M4 the json decode failure is swallowed into empty records again (R131-F5).

F3 (stream door three-way) has no reachable red today — its Err arm exists only under a
poisoned engine lock, and manufacturing one would be fabricating a path; recorded as such
in the ledger. F6 (mint-time bound) is an allocation-only change whose semantics are pinned
by the existing stream judges (snapshot/deployment families). F9 is comment/guide copy.

Byte-for-byte restore per mutation (sha256 + mtime bump); RED verdicts carry the
compiled-guard.
"""
import hashlib
import os
import subprocess
import sys

CALY = "/home/user/caly/caly"
SESSION = f"{CALY}/crates/caly-daemon/src/session.rs"
RESOLVE = f"{CALY}/crates/caly-io-std/src/resolve.rs"
REMOTE = f"{CALY}/crates/caly-app/src/remote.rs"
CALY_BIN = f"{CALY}/crates/caly-cli/src/bin/caly.rs"

J_CAP = (
    "-p caly-daemon --test watch_snapshot_stream "
    "a_session_stream_table_is_bounded_and_refuses_by_name_when_full"
)
J_SPAWN = "-p caly-io-std --test resolver_spawn_failure"
J_HOME = "-p caly-arch-test --test dependency_direction subscription_to_stream_kind_has_one_home"
J_JSON = (
    "-p caly-cli --test caly_cli_e2e "
    "caly_names_an_undecodable_json_frame_as_a_protocol_disagreement"
)


def run(*args: str) -> tuple[int, str]:
    proc = subprocess.run(args, cwd=CALY, capture_output=True, text=True, timeout=900)
    return proc.returncode, proc.stdout + proc.stderr


def test(name: str, expect_ok: bool) -> str:
    code, out = run("cargo", "test", *name.split(), "--", "--test-threads=1")
    compiled = "error[" not in out and "error: " not in out
    passed = code == 0 and compiled
    if passed == expect_ok:
        return "GREEN" if expect_ok else "RED"
    verdict = "UNEXPECTED-RED" if expect_ok else "MISSED-BIT"
    tail = "\n".join(out.splitlines()[-10:])
    print(f"    [{verdict}] {name}\n    --------\n{tail}\n    --------")
    return verdict


MUTATIONS = [
    dict(
        name="M1 the session stream-table cap disappears",
        file=SESSION,
        old="""        if crate::stream::stream_kind_for_operation(&envelope.operation).is_some()
            && self.opened_streams.len() >= crate::stream::MAX_OPENED_SESSION_STREAMS
        {""",
        new="""        if false
            && crate::stream::stream_kind_for_operation(&envelope.operation).is_some()
            && self.opened_streams.len() >= crate::stream::MAX_OPENED_SESSION_STREAMS
        {""",
        red=[(J_CAP, False)],
        green=[(J_JSON, True)],
    ),
    dict(
        name="M2 the resolver spawn failure panics again",
        file=RESOLVE,
        # The honest reachable shape of the original defect: the failed-init cell becomes a
        # panic again (the seam pre-sets None without spawning, so the mutant must sit at the
        # None-handling point, not inside the spawn block it bypasses).
        old="""    cell.as_ref().ok_or_else(|| spawn_refused(host))""",
        new="""    Ok(cell.as_ref().unwrap_or_else(|| panic!("spawn the bounded resolver thread")))""",
        red=[(J_SPAWN, False)],
        green=[(J_CAP, True)],
    ),
    dict(
        name="M3 a local subscription->kind match reappears in caly-app",
        file=REMOTE,
        old="""                self.session.register_stream(
                    opened.stream_id,
                    caly_ipc::stream_kind_for_subscription(subscription),
                );
                Ok(opened)
            }""",
        new="""                let kind = match subscription.clone() {
                    RuntimeSubscription::Dashboard => caly_ipc::StreamKind::Dashboard,
                    _ => caly_ipc::stream_kind_for_subscription(subscription),
                };
                self.session.register_stream(opened.stream_id, kind);
                Ok(opened)
            }""",
        red=[(J_HOME, False)],
        green=[(J_CAP, True)],
    ),
    dict(
        name="M4 the json decode failure is swallowed again",
        file=CALY_BIN,
        old="""        if json {
            caly_ipc::json_to_records(&text)
                .map_err(|error| format!("json decode of a {kind} frame failed: {error}"))
        } else {
            Ok(wire_parse_records(&text))
        }""",
        new="""        if json {
            Ok(caly_ipc::json_to_records(&text).unwrap_or_default())
        } else {
            Ok(wire_parse_records(&text))
        }""",
        red=[(J_JSON, False)],
        green=[(J_CAP, True)],
    ),
]


def main() -> int:
    leftovers: list[str] = []
    for mutation in MUTATIONS:
        path = mutation["file"]
        original = open(path, "rb").read().decode()
        original_sha = hashlib.sha256(original.encode()).hexdigest()
        if mutation["old"] not in original:
            print(f"{mutation['name']}: ANCHOR NOT FOUND (skipped)")
            continue
        mutated = original.replace(mutation["old"], mutation["new"], 1)
        open(path, "w").write(mutated)
        os.utime(path, None)
        try:
            verdicts = []
            for name, expect in mutation["red"] + mutation["green"]:
                verdicts.append(test(name, expect))
            reds = verdicts[: len(mutation["red"])]
            greens = verdicts[len(mutation["red"]) :]
            ok = all(v == "RED" for v in reds) and all(v == "GREEN" for v in greens)
            print(
                f"{mutation['name']}: {'BIT' if ok else 'MISSED-BIT'} "
                f"(red={reds} green={greens})"
            )
        finally:
            open(path, "w").write(original)
            os.utime(path, None)
            if hashlib.sha256(open(path, "rb").read().decode().encode()).hexdigest() != original_sha:
                leftovers.append(path)
    if leftovers:
        print(f"LEFTOVERS: {leftovers}")
        return 1
    print("leftovers: []")
    return 0


if __name__ == "__main__":
    sys.exit(main())
