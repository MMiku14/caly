"""Falsification harness for round 65 (source-index record corruption falsification).

Same discipline as rounds 16/32-60: one mutation per run, exact-anchor replacement with
`assert count == 1`, restore by content and mtime, sha256-verified, stale `*.r65bak`
swept at startup. A mutation that cannot compile proves nothing (`§4.112`); backups are
per-mutation (`§4.137`); each cargo run carries a hard timeout (`§4.139`); a mutation must
keep bindings, types and call arity so the failure is the property, not the program
(`§4.112` again).

Nine mutations, each bitten by a judge this round created:

- M1  the normalized_cache anchor check is deleted — the codec accepts a cache field that
      no longer matches its digest;
- M2  the `sha256:` + 64-hex format check is deleted — a raw anchor a writer could not have
      produced is accepted;
- M3  `Record::req` returns "" instead of reporting a missing field — a record missing its
      required field loads as if it were complete;
- M4  the empty identity / zero cap checks are deleted — a record with no identity or a
      cap of 0 bytes loads;
- M5  `updated_at` is defaulted to 0 instead of parsed — a malformed timestamp is silently
      accepted;
- M6  the worker's metadata-disagreement check is deleted — a record whose raw object
      metadata stopped agreeing with the durable anchors restores;
- M7  the worker's 304 digest guard always evaluates false — unverified raw bytes are
      reused as if they were verified;
- M8  a missing raw body on 304 is treated as an empty body — the by-name refusal is gone
      (the empty bytes then trip the digest guard with the *wrong* message);
- M9  `FsStore::read_object` stops re-verifying content on read — the reuse boundary
      refuses only because the worker's own guard still fires (message-based bite, plus the
      pre-existing object-contract judge).

Usage: `python3 scripts/archive/falsify_round65.py` (exit 0 = every mutation bit, every file restored).
"""

import hashlib
import os
import pathlib
import shutil
import subprocess
import sys
import time

ROOT = pathlib.Path("/home/user/caly_extract/caly")
ENV = dict(os.environ)
ENV["PATH"] = str(pathlib.Path.home() / ".cargo/bin") + ":" + ENV.get("PATH", "")
SRC = {
    "record": ROOT / "crates/caly-storage/src/record.rs",
    "worker": ROOT / "crates/caly-engine/src/source_worker.rs",
    "fs_store": ROOT / "crates/caly-storage/src/fs_store.rs",
}

MUTATIONS = [
    (
        "M1 normalized anchor check deleted",
        "record",
        """    verify_source_text_anchor("normalized_cache", &normalized_cache, &normalized_digest)?;
""",
        "",
        [("caly-storage", "record_codec", "source_index_rejects_cache_fields_detached_from_their_anchors")],
        [],
    ),
    (
        "M2 raw sha256 format check deleted",
        "record",
        """    if !source_anchor(&raw_content_sha256) {
        return Err(RecordCodecError::new(
            "source index raw_content_sha256 is not a sha256 anchor",
        ));
    }
""",
        "",
        [("caly-storage", "record_codec", "source_index_rejects_a_raw_anchor_that_is_not_sha256")],
        [],
    ),
    (
        "M3 missing field reports empty instead of name",
        "record",
        """        self.fields
            .get(key)
            .and_then(|values| values.first())
            .map(String::as_str)
            .ok_or_else(|| RecordCodecError::new(format!("missing required field {key:?}")))
""",
        """        Ok(self.fields
            .get(key)
            .and_then(|values| values.first())
            .map(String::as_str)
            .unwrap_or(""))
""",
        [("caly-storage", "record_codec", "source_index_reports_a_missing_required_field_by_name")],
        [("caly-storage", "record_codec", "a_missing_required_field_is_reported_by_name")],
    ),
    (
        "M4 empty identity / zero cap checks deleted",
        "record",
        """    if source_id.trim().is_empty() {
        return Err(RecordCodecError::new("source index source_id must not be empty"));
    }
    if locator.trim().is_empty() {
        return Err(RecordCodecError::new("source index locator must not be empty"));
    }
    if max_body_bytes == 0 {
        return Err(RecordCodecError::new(
            "source index max_body_bytes must be greater than zero",
        ));
    }
""",
        "",
        [("caly-storage", "record_codec", "source_index_rejects_empty_identity_locator_and_zero_cap")],
        [],
    ),
    (
        "M5 updated_at defaulted to 0",
        "record",
        """    let updated_at_unix_ms = record.i64_field("updated_at")?;
""",
        """    let updated_at_unix_ms = 0;
""",
        [("caly-storage", "record_codec", "source_index_rejects_malformed_timestamps_and_flags")],
        [],
    ),
    (
        "M6 worker metadata disagreement check deleted",
        "worker",
        """        if object.digest.0 != record.raw_object_digest
            || object.kind != ObjectKind::RawSource
            || object.content_sha256.as_deref() != Some(record.raw_content_sha256.as_str())
            || object.size_bytes != Some(record.raw_bytes_len)
        {
            return Err(format!(
                "source index {source_id} raw object metadata disagrees with its durable anchors"
            ));
        }
""",
        "",
        [("caly-engine", "source_durable", "disagreeing_raw_object_metadata_refuses_durable_worker_restore")],
        [],
    ),
    (
        "M7 worker 304 digest guard always false",
        "worker",
        """            if previous.raw.content_digest.0 != digest
                || previous.raw_object.content_sha256.as_deref() != Some(digest.as_str())
            {
""",
        """            if previous.reused_raw_body {
""",
        [("caly-engine", "source_durable", "a_304_reuse_with_unverified_bytes_is_refused_by_the_worker_anchor")],
        [],
    ),
    (
        "M8 missing 304 body becomes empty body",
        "worker",
        """            .ok_or_else(|| {
                format!(
                    "source {} returned 304 but its cached raw body is missing",
                    endpoint.source_id.0
                )
            })?;
""",
        """            .unwrap_or_default();
""",
        [("caly-engine", "source_durable", "a_304_reuse_with_a_lost_raw_body_is_refused_by_name")],
        [],
    ),
    (
        "M9 FsStore read no longer verifies content on read",
        "fs_store",
        """            if !caly_common::digest::sha256_matches(&anchor, &bytes) {
                return Err(StorageError::new(
                    StorageErrorKind::IntegrityViolation,
                    format!("object {digest} failed integrity verification on read"),
                ));
            }
""",
        "",
        [("caly-engine", "source_durable", "corrupt_raw_bytes_between_restore_and_304_refuse_reuse_on_the_durable_store")],
        [("caly-storage", "object_contract", "tampered_content_is_refused_on_read_rather_than_handed_back")],
    ),
]


def digest(path):
    return hashlib.sha256(pathlib.Path(path).read_bytes()).hexdigest()


def sweep_strays():
    for pattern in ("*.r65bak", "*.rNNbak"):
        for path in ROOT.rglob(pattern):
            print(f"  note  sweeping stale {path}")
            path.unlink()


class MutationError(Exception):
    pass


def run_cargo(args, timeout=900):
    proc = subprocess.run(
        ["cargo", *args],
        cwd=str(ROOT),
        env=ENV,
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
        text=True,
        timeout=timeout,
    )
    return proc.returncode, proc.stdout


def judge_hit(pkg, test_bin, test_name):
    """Run one test by exact name. Returns (bit, output) where bit=True iff the test
        FAILED while compiling fine — the shape of "the property stopped holding".
        A compile error or a pass are both 'not bit'."""
    code, out = run_cargo(["test", "-p", pkg, "--test", test_bin, test_name, "--", "--exact"])
    if "error[" in out or "could not compile" in out:
        return False, out
    if f"test {test_name} ... FAILED" in out:
        return True, out
    return False, out


def main():
    sweep_strays()
    bad = False
    for label, key, old, new, expected, extras in MUTATIONS:
        path = SRC[key]
        text = pathlib.Path(path).read_text(encoding="utf-8")
        if text.count(old) != 1:
            print(f"  FAIL  {label}: anchor not unique (count={text.count(old)})")
            bad = True
            continue
        backup = f"{path}.r65bak"
        shutil.copy2(path, backup)
        before = digest(path)
        try:
            pathlib.Path(path).write_text(text.replace(old, new, 1), encoding="utf-8")
            all_hit = True
            details = []
            for pkg, test_bin, name in expected + extras:
                bit, out = judge_hit(pkg, test_bin, name)
                tail = [line for line in out.splitlines() if "FAILED" in line or "error[" in line][-1:]
                if bit:
                    details.append(f"      bit: {pkg}/{test_bin}::{name}")
                else:
                    all_hit = False
                    details.append(
                        f"      NOT BIT: {pkg}/{test_bin}::{name}"
                        + (" (compiler error, not a property failure)" if "error[" in out else "")
                        + (f" | {tail[0]}" if tail else "")
                    )
            print(f"  {'ok  ' if all_hit else 'FAIL'}  {label}")
            print("\n".join(details))
            if not all_hit:
                bad = True
        except subprocess.TimeoutExpired:
            print(f"  FAIL  {label}: cargo timed out (nothing proven)")
            bad = True
        finally:
            shutil.move(backup, path)
            os.utime(path, None)
            restored = digest(path)
            if restored != before:
                print(f"  FAIL  {label}: restore mismatch")
                bad = True
    print("all mutations bit:", not bad)
    return 1 if bad else 0


if __name__ == "__main__":
    sys.exit(main())
