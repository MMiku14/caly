"""Falsification harness for round 32 (the orphan content sweep).

Same shape as `scripts/archive/falsify_round16.py` (the template this repo keeps on purpose): one mutation
per run, one file per mutation, exact-anchor replacement with `assert count == 1`, restore by
content **and** mtime, sha256-verified. A stale anchor aborts with "anchor x0" rather than
producing a false green.

The fifteen mutations below are the round's properties stated as *removals*: each turns off one
behaviour the tests claim to hold, and the harness checks that at least the named test went red.
"Red" is read from cargo's own `... FAILED` lines, and a mutation that fails to compile proves
nothing (`§4.112`) -- the harness says so out loud instead of counting it.

Usage: `python3 scripts/archive/falsify_round32.py` (needs `cargo` on PATH; exit code 0 means every
mutation bit and every file was restored byte-identically).
"""

import hashlib
import os
import pathlib
import shutil
import subprocess
import sys

ROOT = pathlib.Path("/home/user/caly")
ENV = dict(os.environ)
ENV["PATH"] = str(pathlib.Path.home() / ".cargo/bin") + ":" + ENV.get("PATH", "")
SRC = {
    "gc": ROOT / "crates/caly-storage/src/gc.rs",
    "fs_store": ROOT / "crates/caly-storage/src/fs_store.rs",
    "memory": ROOT / "crates/caly-storage/src/memory.rs",
    "engine_plan": ROOT / "crates/caly-engine/src/gc_plan.rs",
    "engine_service": ROOT / "crates/caly-engine/src/service.rs",
}

# (label, file-key, old, new, cargo package, expected red tests)
MUTATIONS = [
    (
        "M1 walk never reaches the leaf level",
        "fs_store",
        """            let files = list_directory(
                fs,
                root,
                ctx,
                &leaf_suffix,
                ListCap(MAX_ENTRIES_PER_DIRECTORY),
            )?;""",
        "            let files: Vec<String> = Vec::new();",
        "caly-storage",
        ["the_walk_sees_content_no_metadata_names"],
    ),
    (
        "M2 plan treats referenced anchors as orphans",
        "gc",
        "if referenced.contains(anchor) {",
        "if false && referenced.contains(anchor) {",
        "caly-storage",
        ["referenced_content_is_never_orphaned_no_matter_how_old"],
    ),
    (
        "M3 unknown age becomes collectable",
        "gc",
        """surviving one extra cycle is not.
            None => false,""",
        """surviving one extra cycle is not.
            None => true,""",
        "caly-storage",
        ["an_orphan_of_unknown_age_survives_every_cycle"],
    ),
    (
        "M4 grace comparison inverted",
        "gc",
        "policy.now_unix_ms.saturating_sub(modified_at) >= policy.grace_period_ms",
        "policy.now_unix_ms.saturating_sub(modified_at) < policy.grace_period_ms",
        "caly-storage",
        ["grace_boundaries_hold_from_both_sides"],
    ),
    (
        "M5 fs store deletes content metadata still names",
        "fs_store",
        """                .any(|object| object.content_sha256.as_deref() == Some(anchor.as_str()))
                {""",
        """                .any(|object| false)
                {""",
        "caly-storage",
        ["the_store_refuses_to_delete_content_metadata_still_names"],
    ),
    (
        "M6 memory store deletes content metadata still names",
        "memory",
        """objects
                .values()
                .any(|object| object.content_sha256.as_deref() == Some(anchor.as_str()))""",
        """objects
                .values()
                .any(|object| false)""",
        "caly-storage",
        ["the_content_tree_door_answers_the_same_way_on_both_backends"],
    ),
    (
        "M7 residue reclassified as unexplained damage",
        "fs_store",
        """
                let target = if is_temp_residue(&name)
                    && is_lower_hex(stem)
                    && stem.len() == CONTENT_LEAF_HEX_LEN
                {""",
        """
                let target = if false && is_temp_residue(&name)
                    && is_lower_hex(stem)
                    && stem.len() == CONTENT_LEAF_HEX_LEN
                {""",
        "caly-storage",
        ["write_residue_is_discovered_as_its_own_kind"],
    ),
    (
        "M8 unexplainable anchors become paths",
        "fs_store",
        "if !is_lower_hex(hex) {",
        "if false && !is_lower_hex(hex) {",
        "caly-storage",
        ["a_target_the_layout_cannot_explain_is_refused"],
    ),
    (
        "M9 directory budget never bites",
        "fs_store",
        "if *visited > dir_budget {",
        "if false && *visited > dir_budget {",
        "caly-storage",
        ["the_directory_budget_is_measured_from_both_sides"],
    ),
    (
        "M10 the capability gap is registered under another class",
        "engine_service",
        """gaps.push(crate::gc_plan::GcRootGap::new(
                    "content-tree",""",
        """gaps.push(crate::gc_plan::GcRootGap::new(
                    "content-blindness",""",
        "caly-engine",
        ["an_unwalkable_backend_is_a_gap_and_the_cycle_deletes_nothing"],
    ),
    (
        "M11 collect never sweeps content",
        "engine_service",
        "if !plan.orphan_sweep.is_empty() {",
        "if false && !plan.orphan_sweep.is_empty() {",
        "caly-engine",
        ["a_cycle_deletes_the_orphan_it_planned_and_says_so"],
    ),
    (
        "M12 orphans get a full second budget",
        "engine_plan",
        "let remaining_budget = policy.max_deletions.saturating_sub(plan.collect.len());",
        "let remaining_budget = policy.max_deletions;",
        "caly-engine",
        ["objects_and_content_share_one_deletion_budget"],
    ),
    (
        "M13 the record's sentence drops the content half",
        "engine_plan",
        "self.collected_content.len(),",
        "0,",
        "caly-engine",
        ["the_record_line_and_the_dto_line_are_one_sentence"],
    ),
    (
        "M14 the walk accepts hex leaves of any length",
        "fs_store",
        "} else if is_lower_hex(&name) && name.len() == CONTENT_LEAF_HEX_LEN {",
        "} else if is_lower_hex(&name) {",
        "caly-storage",
        ["a_leaf_of_the_wrong_hex_length_is_damage_not_an_anchor"],
    ),
    (
        "M15 the walk accepts half-length residue stems",
        "fs_store",
        """
                let target = if is_temp_residue(&name)
                    && is_lower_hex(stem)
                    && stem.len() == CONTENT_LEAF_HEX_LEN
                {""",
        "                let target = if is_temp_residue(&name) {",
        "caly-storage",
        ["a_residue_whose_stem_is_not_a_full_leaf_is_damage"],
    ),
]


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def run_cargo(pkg):
    proc = subprocess.run(
        ["cargo", "test", "-p", pkg, "--no-fail-fast"],
        cwd=str(ROOT),
        env=ENV,
        capture_output=True,
        text=True,
    )
    out = proc.stdout + proc.stderr
    failed = sorted(
        {
            line[5:].split(" ... ")[0].split("::")[-1].strip()
            for line in out.splitlines()
            if line.startswith("test ") and line.rstrip().endswith("... FAILED")
        }
    )
    return proc.returncode, failed, out


def main():
    for path in ROOT.rglob("*.r32bak"):
        original = pathlib.Path(str(path)[: -len(".r32bak")])
        shutil.move(str(path), str(original))
        print("swept leftover backup:", path.name)

    originals = {name: digest(path) for name, path in SRC.items()}
    results = []
    bad = False
    for label, key, old, new, pkg, expected in MUTATIONS:
        path = SRC[key]
        s = path.read_text()
        assert s.count(old) == 1, "%s: anchor x%d" % (label, s.count(old))
        backup = pathlib.Path(str(path) + ".r32bak")
        shutil.copyfile(path, backup)
        try:
            path.write_text(s.replace(old, new, 1))
            code, failed, out = run_cargo(pkg)
            red = [name for name in expected if name in failed]
            # A build failure proves rustc, not the property (`§4.112`): the mutations are shaped to
            # keep bindings and arity, so a compile error means the shape was wrong, not the test.
            # M10 renames the gap class rather than deleting the push (a bare block where a match
            # arm belongs does not compile): the red it produces proves the class-name assertion is
            # attached to exactly that line, whose other failure mode -- swallowing `Unsupported`
            # into an empty list -- is the same assertion's red.
            compile_error = "error[" in out or "could not compile" in out
            ok = bool(red) and len(failed) > 0 and not compile_error
            results.append((label, ok))
            print("%-46s %s  red=%s" % (label, "BIT" if ok else "NO EFFECT", red or failed[:4]))
            if not ok:
                if compile_error:
                    print("   !! the mutation did not compile; it proves nothing")
                print("   output tail:\n", out[-1200:])
        finally:
            # Restore by content, bump the mtime, verify: the round-16 lesson about stale relinks.
            shutil.move(str(backup), str(path))
            os.utime(path, None)
            assert digest(path) == originals[key], "%s: restore did not reproduce the file" % label

    print("\n== summary ==")
    for label, ok in results:
        print("%-46s %s" % (label, "bit" if ok else "DID NOT BIT"))
        if not ok:
            bad = True
    print("all mutations bit:", not bad)
    sys.exit(1 if bad else 0)


if __name__ == "__main__":
    main()
