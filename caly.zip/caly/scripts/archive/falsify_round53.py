"""Falsification harness for round 53 (the worker thread + live streams, mid-stream dead-peer
reaping, StdProc per ADR-042, and the numeric-field gate at the wire).

Same discipline as rounds 16/32–52: one mutation per run, exact-anchor replacement with
`assert count == 1`, restore by content and mtime, sha256-verified, stale `*.r53bak` swept at
startup. A mutation that cannot compile proves nothing (`§4.112`). Backups are taken **per
mutation** (`§4.137`). No hang-shaped mutations, and the harness enforces that claim itself:
each cargo run gets a hard 15-minute timeout, and a mutation that wedges the suite counts as
DID NOT BIT — a wedged mutant proves nothing and must be redesigned (`§4.139`; the original
M2 here, "the worker never drains", was exactly that shape: the target judge reds in 10s, but
every unrelated stream test then crawls to its 10_000-tick pump budget, which is a budget,
not a wall-clock deadline).

Six mutations: the acceptance arm draining inline again (round 47's shape), the worker-tick
flag ignored (the daemon drains at its default cadence no matter what `--worker-tick-ms`
says — one knob must mean one policy), the Wait-branch peer probe removed, a spawn failure
swallowed into a fake handle, the env injection dropped, and the numeric gate reverted to
`.ok()` (garbage silently becoming "use the default").

Usage: `python3 scripts/archive/falsify_round53.py` (exit 0 = every mutation bit, every file restored).
"""

import hashlib
import os
import pathlib
import shutil
import subprocess
import sys

ROOT = pathlib.Path("/home/user/caly")
ENV = dict(os.environ)
ENV["PATH"] = str(pathlib.Path.home() / ".cargo/bin") + ":" + ENV.get("PATH", "")
SRC = {
    "daemon": ROOT / "crates/caly-daemon/src/bin/calyd.rs",
    "proc": ROOT / "crates/caly-io-std/src/proc.rs",
}

MUTATIONS = [
    (
        "M1 the acceptance arm drains inline again (round 47's shape)",
        "daemon",
        """                                        // The worker thread owns the run from here (round 53):
                                        // acceptance means **queued**. The job stays `accepted`
                                        // on the query surface until the worker's next tick
                                        // claims it — that window is the first honest live
                                        // stream this daemon could ever carry.
                                        write_frame(""",
        """                                        let _ = app.drain_engine_once();
                                        write_frame(""",
        [
            "an_acceptance_means_queued_and_a_stream_watches_the_worker_finish",
        ],
    ),
    (
        "M2 the worker-tick flag is ignored (fixed 25ms cadence)",
        "daemon",
        """            std::thread::sleep(std::time::Duration::from_millis(worker_tick_ms));""",
        """            std::thread::sleep(std::time::Duration::from_millis(25));""",
        [
            "an_acceptance_means_queued_and_a_stream_watches_the_worker_finish",
        ],
    ),
    (
        "M3 the Wait-branch peer probe is removed",
        "daemon",
        """                                                    match peer {
                                                        Ok(0) => {""",
        """                                                    match peer {
                                                        Ok(1) => {""",
        [
            "a_stream_client_that_leaves_mid_wait_is_reaped_within_one_wait_tick",
        ],
    ),
    (
        "M4 a spawn failure is swallowed into a fake handle",
        "proc",
        """            })?;
            let pid = child.id();""",
        """            });
            let pid = child.as_ref().map(|spawned| spawned.id()).unwrap_or(7);""",
        [
            "a_missing_program_is_not_found_by_name",
        ],
    ),
    (
        "M5 the env injection is dropped",
        "proc",
        """            for (key, value) in &spec.env {
                command.env(key, value);
            }""",
        """            for (key, value) in &spec.env {
                let _ = (key, value);
            }""",
        [
            "a_child_sees_the_cwd_and_env_the_spec_named",
        ],
    ),
    (
        "M6 the numeric gate reverts to silent defaulting",
        "daemon",
        """        Some(raw) => raw
            .parse::<T>()
            .map(Some)
            .map_err(|_| format!("the {field} record must be a number; got {raw:?} — refusing rather than defaulting it")),""",
        """        Some(raw) => Ok(raw.parse::<T>().ok()),""",
        [
            "a_number_field_that_wont_parse_is_a_named_refusal_not_a_default",
        ],
    ),
]


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def run_cargo():
    argv = [
        "cargo",
        "test",
        "-p",
        "caly-daemon",
        "--test",
        "calyd_wire",
        "-p",
        "caly-cli",
        "--test",
        "caly_cli_e2e",
        "-p",
        "caly-io-std",
        "--test",
        "proc_std",
        "--no-fail-fast",
    ]
    try:
        proc = subprocess.run(
            argv,
            cwd=str(ROOT),
            env=ENV,
            capture_output=True,
            text=True,
            timeout=900,  # a wedged suite is a wedged *mutant*, not a verdict (§4.139)
        )
    except subprocess.TimeoutExpired:
        return 124, [], "TIMEOUT: the mutation wedged the suite (§4.139) — redesign it"
    out = proc.stdout + proc.stderr
    failed = sorted(
        {
            line[5:].split(" ... ")[0].split("::")[-1].strip()
            for line in out.splitlines()
            if line.startswith("test ") and line.rstrip().endswith("... FAILED")
        }
    )
    return proc.returncode, failed, out


def main():
    for path in ROOT.rglob("*.r53bak"):
        original = pathlib.Path(str(path)[: -len(".r53bak")])
        shutil.move(str(path), str(original))
        print("swept leftover backup:", path.name)

    originals = {name: digest(path) for name, path in SRC.items()}
    results = []
    bad = False
    for label, key, old, new, expected in MUTATIONS:
        path = SRC[key]
        backup = pathlib.Path(str(path) + ".r53bak")
        shutil.copyfile(path, backup)  # per-mutation backup (§4.137)
        s = path.read_text()
        assert s.count(old) == 1, "%s: anchor x%d" % (label, s.count(old))
        try:
            mutated = s.replace(old, new, 1)
            path.write_text(mutated)
            code, failed, out = run_cargo()
            wedged = code == 124
            red = [name for name in expected if name in failed]
            compile_error = "error[" in out or "could not compile" in out
            ok = bool(red) and not compile_error and not wedged
            results.append((label, ok))
            print("%-52s %s  red=%s" % (label, "BIT" if ok else "NO EFFECT", red or failed[:4]))
            if not ok:
                if compile_error:
                    print("   !! the mutation did not compile; it proves nothing")
                if wedged:
                    print("   !! the mutation wedged the suite; it proves nothing (§4.139)")
                print("   output tail:\n", out[-1200:])
        finally:
            shutil.move(str(backup), str(path))
            os.utime(path, None)
            assert digest(path) == originals[key], "%s: restore did not reproduce the file" % label

    print("\n== summary ==")
    for label, ok in results:
        print("%-52s %s" % (label, "bit" if ok else "DID NOT BIT"))
        if not ok:
            bad = True
    print("all mutations bit:", not bad)
    sys.exit(1 if bad else 0)


if __name__ == "__main__":
    main()
