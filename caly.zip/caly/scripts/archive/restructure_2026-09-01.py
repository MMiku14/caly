#!/usr/bin/env python3
"""One-shot script: reorganize the docs tree on 2026-09-01.

**Already applied** — kept in scripts/archive/ for provenance only. Do not re-run: the rewrite
maps in this file were themselves rewritten by the sweep it performed (its own source lived under
scripts/), so the tables below now read as identity and re-running it is a no-op. The ongoing
equivalents are scripts/regenerate_test_census.py and scripts/regenerate_doc_index.py.
"""
from __future__ import annotations

import re
import shutil
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]

# (old path relative to repo root, new path) — files moved first, references rewritten after.
MOVES = [
    # legacy root specs -> history/legacy
    ("docs/history/legacy/Caly_Architecture_RFC.md", "docs/history/legacy/docs/history/legacy/Caly_Architecture_RFC.md"),
    ("docs/history/legacy/Caly_Unified_Architecture.md", "docs/history/legacy/docs/history/legacy/Caly_Unified_Architecture.md"),
    # development logs -> history/logs
    ("docs/history/ONBOARDING_NOTES.md", "docs/history/ONBOARDING_NOTES.md"),
] + [
    (f"docs/{name}", f"docs/history/logs/{name}")
    for name in sorted(
        [p.name for p in (ROOT / "docs").glob("DEVELOPMENT_LOG_*.md")]
    )
] + [
    # status snapshots
    ("docs/status/IMPLEMENTATION_STATUS.md", "docs/status/IMPLEMENTATION_STATUS.md"),
    ("docs/status/ROADMAP.md", "docs/status/ROADMAP.md"),
    ("docs/status/CENTERLINE_PROGRESS.md", "docs/status/CENTERLINE_PROGRESS.md"),
    # guides
    ("docs/guides/FEATURES.md", "docs/guides/FEATURES.md"),
    ("docs/guides/GLOSSARY.md", "docs/guides/GLOSSARY.md"),
    ("docs/guides/STYLEGUIDE.md", "docs/guides/STYLEGUIDE.md"),
    ("docs/guides/ERRORS.md", "docs/guides/ERRORS.md"),
    ("docs/guides/EXIT_CODES.md", "docs/guides/EXIT_CODES.md"),
    ("docs/guides/DEPLOYMENT_SYSTEMD.md", "docs/guides/DEPLOYMENT_SYSTEMD.md"),
    ("docs/guides/ROBUSTNESS_GUIDE.md", "docs/guides/ROBUSTNESS_GUIDE.md"),
    # engineering docs
    ("docs/engineering/TUI_PLAN.md", "docs/engineering/TUI_PLAN.md"),
    ("docs/engineering/APPLY_EXECUTION_CENTERLINE.md", "docs/engineering/APPLY_EXECUTION_CENTERLINE.md"),
    ("docs/engineering/STORAGE_RECOVERY_EXECUTION_PLAN.md", "docs/engineering/STORAGE_RECOVERY_EXECUTION_PLAN.md"),
    ("docs/engineering/CAPABILITY_VALIDATION_EXECUTION_PLAN.md", "docs/engineering/CAPABILITY_VALIDATION_EXECUTION_PLAN.md"),
    ("docs/engineering/API_DTO_MIGRATION_PLAN.md", "docs/engineering/API_DTO_MIGRATION_PLAN.md"),
    ("docs/engineering/CORE_VERTICAL_SLICES.md", "docs/engineering/CORE_VERTICAL_SLICES.md"),
    ("docs/engineering/RFC_ADR_CRATE_INDEX.md", "docs/engineering/RFC_ADR_CRATE_INDEX.md"),
    ("docs/engineering/JOB_FLOW_SCENARIO_REVIEW.md", "docs/engineering/JOB_FLOW_SCENARIO_REVIEW.md"),
    ("docs/engineering/IPC_PROTOCOL_ANALYSIS.md", "docs/engineering/IPC_PROTOCOL_ANALYSIS.md"),
    ("docs/engineering/IPC_TRANSPORT_DECISION.md", "docs/engineering/IPC_TRANSPORT_DECISION.md"),
    ("docs/engineering/IPC_SESSION_MODEL.md", "docs/engineering/IPC_SESSION_MODEL.md"),
    ("docs/engineering/IPC_JOB_FOLLOW_MODEL.md", "docs/engineering/IPC_JOB_FOLLOW_MODEL.md"),
    ("docs/engineering/IPC_STREAM_POLICY.md", "docs/engineering/IPC_STREAM_POLICY.md"),
    ("docs/engineering/IPC_IMPLEMENTATION_PLAN.md", "docs/engineering/IPC_IMPLEMENTATION_PLAN.md"),
    ("docs/engineering/IPC_LOOPBACK_HARNESS.md", "docs/engineering/IPC_LOOPBACK_HARNESS.md"),
    ("docs/engineering/APP_CLIENT_LAYER.md", "docs/engineering/APP_CLIENT_LAYER.md"),
    ("docs/engineering/REMOTE_FACADE_PARITY.md", "docs/engineering/REMOTE_FACADE_PARITY.md"),
    ("docs/engineering/TRANSPORT_RUNTIME_MODEL.md", "docs/engineering/TRANSPORT_RUNTIME_MODEL.md"),
    ("docs/engineering/OVERLOAD_AND_RETRY_MODEL.md", "docs/engineering/OVERLOAD_AND_RETRY_MODEL.md"),
    ("docs/engineering/LOOPBACK_CONTRACTS.md", "docs/engineering/LOOPBACK_CONTRACTS.md"),
    ("docs/engineering/REDACTION_AND_SUPPORT_BUNDLE.md", "docs/engineering/REDACTION_AND_SUPPORT_BUNDLE.md"),
    ("docs/engineering/SCENARIO_SUITE.md", "docs/engineering/SCENARIO_SUITE.md"),
    # one-shot round scripts -> scripts/archive
    ("scripts/archive/handover_round88_log.py", "scripts/archive/handover_round88_log.py"),
    ("scripts/archive/round89_docs.py", "scripts/archive/round89_docs.py"),
    ("scripts/archive/round90_docs.py", "scripts/archive/round90_docs.py"),
] + [
    (f"scripts/{name}", f"scripts/archive/{name}")
    for name in sorted(
        [p.name for p in (ROOT / "scripts").glob("falsify_round*.py")]
    )
]

# Reference rewrites: exact string -> exact string. Longest keys first so that
# `docs/history/logs/DEVELOPMENT_LOG_2026-08-31.md` wins over nothing else (they are disjoint anyway).
REWRITES = [
    (old, new) for old, new in MOVES if old.endswith(".md") or old.startswith("scripts/")
]
# The playbook is replaced by the new workflow document:
REWRITES.append(("docs/guides/DEVELOPMENT_WORKFLOW.md", "docs/guides/DEVELOPMENT_WORKFLOW.md"))

# Bare-name rewrites (a citation like `docs/guides/FEATURES.md` without the docs/ prefix).
BARE = {
    "docs/guides/DEVELOPMENT_WORKFLOW.md": "docs/guides/DEVELOPMENT_WORKFLOW.md",
    "docs/history/ONBOARDING_NOTES.md": "docs/history/ONBOARDING_NOTES.md",
    "docs/status/IMPLEMENTATION_STATUS.md": "docs/status/IMPLEMENTATION_STATUS.md",
    "docs/status/ROADMAP.md": "docs/status/ROADMAP.md",
    "docs/status/CENTERLINE_PROGRESS.md": "docs/status/CENTERLINE_PROGRESS.md",
    "docs/guides/FEATURES.md": "docs/guides/FEATURES.md",
    "docs/guides/GLOSSARY.md": "docs/guides/GLOSSARY.md",
    "docs/guides/STYLEGUIDE.md": "docs/guides/STYLEGUIDE.md",
    "docs/guides/ERRORS.md": "docs/guides/ERRORS.md",
    "docs/guides/EXIT_CODES.md": "docs/guides/EXIT_CODES.md",
    "docs/guides/DEPLOYMENT_SYSTEMD.md": "docs/guides/DEPLOYMENT_SYSTEMD.md",
    "docs/guides/ROBUSTNESS_GUIDE.md": "docs/guides/ROBUSTNESS_GUIDE.md",
    "docs/engineering/TUI_PLAN.md": "docs/engineering/TUI_PLAN.md",
    "docs/engineering/APPLY_EXECUTION_CENTERLINE.md": "docs/engineering/APPLY_EXECUTION_CENTERLINE.md",
    "docs/engineering/STORAGE_RECOVERY_EXECUTION_PLAN.md": "docs/engineering/STORAGE_RECOVERY_EXECUTION_PLAN.md",
    "docs/engineering/CAPABILITY_VALIDATION_EXECUTION_PLAN.md": "docs/engineering/CAPABILITY_VALIDATION_EXECUTION_PLAN.md",
    "docs/engineering/API_DTO_MIGRATION_PLAN.md": "docs/engineering/API_DTO_MIGRATION_PLAN.md",
    "docs/engineering/CORE_VERTICAL_SLICES.md": "docs/engineering/CORE_VERTICAL_SLICES.md",
    "docs/engineering/RFC_ADR_CRATE_INDEX.md": "docs/engineering/RFC_ADR_CRATE_INDEX.md",
    "docs/engineering/JOB_FLOW_SCENARIO_REVIEW.md": "docs/engineering/JOB_FLOW_SCENARIO_REVIEW.md",
    "docs/engineering/IPC_PROTOCOL_ANALYSIS.md": "docs/engineering/IPC_PROTOCOL_ANALYSIS.md",
    "docs/engineering/IPC_TRANSPORT_DECISION.md": "docs/engineering/IPC_TRANSPORT_DECISION.md",
    "docs/engineering/IPC_SESSION_MODEL.md": "docs/engineering/IPC_SESSION_MODEL.md",
    "docs/engineering/IPC_JOB_FOLLOW_MODEL.md": "docs/engineering/IPC_JOB_FOLLOW_MODEL.md",
    "docs/engineering/IPC_STREAM_POLICY.md": "docs/engineering/IPC_STREAM_POLICY.md",
    "docs/engineering/IPC_IMPLEMENTATION_PLAN.md": "docs/engineering/IPC_IMPLEMENTATION_PLAN.md",
    "docs/engineering/IPC_LOOPBACK_HARNESS.md": "docs/engineering/IPC_LOOPBACK_HARNESS.md",
    "docs/engineering/APP_CLIENT_LAYER.md": "docs/engineering/APP_CLIENT_LAYER.md",
    "docs/engineering/REMOTE_FACADE_PARITY.md": "docs/engineering/REMOTE_FACADE_PARITY.md",
    "docs/engineering/TRANSPORT_RUNTIME_MODEL.md": "docs/engineering/TRANSPORT_RUNTIME_MODEL.md",
    "docs/engineering/OVERLOAD_AND_RETRY_MODEL.md": "docs/engineering/OVERLOAD_AND_RETRY_MODEL.md",
    "docs/engineering/LOOPBACK_CONTRACTS.md": "docs/engineering/LOOPBACK_CONTRACTS.md",
    "docs/engineering/REDACTION_AND_SUPPORT_BUNDLE.md": "docs/engineering/REDACTION_AND_SUPPORT_BUNDLE.md",
    "docs/engineering/SCENARIO_SUITE.md": "docs/engineering/SCENARIO_SUITE.md",
}

# Files whose text is swept for references (docs/**/*.md and the scripts/gate sources).
SWEEP_SUFFIXES = (".md", ".py", ".sh", ".rs", ".toml")
SWEEP_ROOTS = ["docs", "scripts", "crates/caly-arch-test"]

def sweep_file(path: Path) -> int:
    text = path.read_text()
    original = text
    for old, new in REWRITES:
        if old in text:
            text = text.replace(old, new)
    for bare, new in BARE.items():
        text = re.sub(r"(?<![/\w.\-#])" + re.escape(bare), new, text)
    if text != original:
        path.write_text(text)
        return 1
    return 0

def main() -> int:
    moved, rewritten, files_touched = 0, 0, 0
    for old, new in MOVES:
        src = ROOT / old
        dst = ROOT / new
        if not src.exists():
            print(f"SKIP (missing): {old}")
            continue
        dst.parent.mkdir(parents=True, exist_ok=True)
        shutil.move(str(src), str(dst))
        moved += 1
    for root in SWEEP_ROOTS:
        base = ROOT / root
        if not base.is_dir():
            continue
        for path in sorted(base.rglob("*")):
            if path.is_file() and path.suffix in SWEEP_SUFFIXES:
                files_touched += sweep_file(path)
    print(f"moved {moved} files, {files_touched} files rewritten")
    return 0

if __name__ == "__main__":
    sys.exit(main())
