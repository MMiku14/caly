"""Falsification harness for round 42 (`StdHttp`: the second `Http` backend, on a real socket).

Same discipline as rounds 16/32–41: one mutation per run, exact-anchor replacement with
`assert count == 1`, restore by content and mtime, sha256-verified, stale `*.r42bak` swept at
startup. A mutation that cannot compile proves nothing (`§4.112`).

Four mutations, one per judge: the label losing its pinned prefix (the shared contract runs on
BOTH backends now — this is exactly the drift it exists to catch), the transfer ceiling dropped
(an over-bound body would arrive instead of refusing), the conditional header not sent (a 304
judge would silently see 200s), and `https` quietly downgraded to a connection attempt (the
doctrine-named refusal is the honest answer).

Usage: `python3 scripts/archive/falsify_round42.py` (exit 0 = every mutation bit, every file restored).
"""

import hashlib
import os
import pathlib
import shutil
import subprocess
import sys

ROOT = pathlib.Path("/home/user/caly")
ENV = dict(os.environ)
ENV["PATH"] = str(pathlib.Path.home() / ".cargo/bin") + ":" + ENV.get("PATH", "")
SRC = ROOT / "crates/caly-io-std/src/http.rs"

MUTATIONS = [
    (
        "M1 the label loses its pinned prefix",
        '                    label: format!("http:{url}"),',
        '                    label: url.clone(),',
        ["std_http_satisfies_the_shared_fetch_contract"],
    ),
    (
        "M2 the transfer ceiling is dropped",
        """            let size = Self::consume_body(&mut reader, &head, ceiling.bytes)?;
            if let Some(too_big) = ceiling.violation(size, &url) {
                return Err(too_big);
            }""",
        """            let _ = Self::consume_body(&mut reader, &head, ceiling.bytes)?;
            let _ = (&ceiling, &url);""",
        ["std_http_satisfies_the_shared_fetch_contract"],
    ),
    (
        "M3 the conditional header is not sent",
        """            if let Some(etag) = &req.etag {
                request.push_str(&format!("If-None-Match: {etag}\\r\\n"));
            }""",
        "            let _ = &req.etag;",
        ["a_presented_etag_gets_304_as_the_answer"],
    ),
    (
        "M4 https is quietly downgraded to plain http",
        """    } else if url.starts_with("https://") {
        return Err(IoFault::new(
            IoFaultKind::Unsupported,
            format!(
                "https is not implemented: TLS needs a client the no-external-crate doctrine \\
                 (RFC-0001 §1.4) cannot provide, and refusing is the honest answer: {url}"
            ),
        ));
    } else {""",
        """    } else if let Some(rest) = url.strip_prefix("https://") {
        // The quiet downgrade: parse the TLS URL as if the caller asked for plain HTTP.
        rest
    } else {""",
        ["https_is_refused_with_the_doctrine_named_not_a_socket_error"],
    ),
]


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def run_cargo():
    proc = subprocess.run(
        ["cargo", "test", "-p", "caly-io-std", "--no-fail-fast"],
        cwd=str(ROOT),
        env=ENV,
        capture_output=True,
        text=True,
    )
    out = proc.stdout + proc.stderr
    failed = sorted(
        {
            line[5:].split(" ... ")[0].split("::")[-1].strip()
            for line in out.splitlines()
            if line.startswith("test ") and line.rstrip().endswith("... FAILED")
        }
    )
    return proc.returncode, failed, out


def main():
    for path in ROOT.rglob("*.r42bak"):
        original = pathlib.Path(str(path)[: -len(".r42bak")])
        shutil.move(str(path), str(original))
        print("swept leftover backup:", path.name)

    original = digest(SRC)
    results = []
    bad = False
    for label, old, new, expected in MUTATIONS:
        s = SRC.read_text()
        assert s.count(old) == 1, "%s: anchor x%d" % (label, s.count(old))
        backup = pathlib.Path(str(SRC) + ".r42bak")
        shutil.copyfile(SRC, backup)
        try:
            SRC.write_text(s.replace(old, new, 1))
            code, failed, out = run_cargo()
            red = [name for name in expected if name in failed]
            compile_error = "error[" in out or "could not compile" in out
            ok = bool(red) and not compile_error
            results.append((label, ok))
            print("%-48s %s  red=%s" % (label, "BIT" if ok else "NO EFFECT", red or failed[:4]))
            if not ok:
                if compile_error:
                    print("   !! the mutation did not compile; it proves nothing")
                print("   output tail:\n", out[-1200:])
        finally:
            shutil.move(str(backup), str(SRC))
            os.utime(SRC, None)
            assert digest(SRC) == original, "%s: restore did not reproduce the file" % label

    print("\n== summary ==")
    for label, ok in results:
        print("%-48s %s" % (label, "bit" if ok else "DID NOT BIT"))
        if not ok:
            bad = True
    print("all mutations bit:", not bad)
    sys.exit(1 if bad else 0)


if __name__ == "__main__":
    main()
