"""Falsification harness for round 57 (rollback revives the target deployment; the second
core's asset pin).

Same discipline as rounds 16/32–56: one mutation per run, exact-anchor replacement with
`assert count == 1`, restore by content and mtime, sha256-verified, stale `*.r57bak`
swept at startup. A mutation that cannot compile proves nothing (`§4.112`); backups are
per-mutation (`§4.137`); each cargo run carries a hard timeout — a mutation that wedges
the suite counts as DID NOT BIT (`§4.139`). Real cores that outlive their judge are
swept (`caly-run.yaml` pattern, split in the harness so it never matches its own command
line — `§4.143`) with a sleep before the next verdict.

Five mutations, each bitten by a judge this round created:

- M1  the revival skipped entirely (worker calls a stub Ok) — the revive judge finds no
      `rollback.redeploy.executed` stage and no live core;
- M2  the revival's identity probe loses its target (`None`) — "some config" passes and
      the judge's identity-proof assertion goes looking for the digest it will not find;
- M3  the sing-box digest const off by one character — the pinned-asset judge catches the
      archive no longer matching what the plan carries;
- M4  the snapshot-truth promotion skipped — the operator view keeps pointing at the
      rolled-back deployment, and the revive judge's post-rollback Noop summary reads
      "Restart";
- M5  the simulator stops seeding the core's identity on spawn — every ConfigIdentity
      probe (the revival's included) fails and the sim gates go red.

Usage: `python3 scripts/archive/falsify_round57.py` (exit 0 = every mutation bit, every file restored).
"""

import hashlib
import os
import pathlib
import shutil
import subprocess
import sys
import time

ROOT = pathlib.Path("/home/user/caly")
ENV = dict(os.environ)
ENV["PATH"] = str(pathlib.Path.home() / ".cargo/bin") + ":" + ENV.get("PATH", "")
SRC = {
    "worker": ROOT / "crates/caly-engine/src/worker.rs",
    "sim": ROOT / "crates/caly-engine/src/sim_runtime.rs",
    "singbox": ROOT / "crates/caly-singbox/src/adapter.rs",
}

MUTATIONS = [
    (
        "M1 revival skipped (stub Ok)",
        "worker",
        """    let redeployed = match redeploy_rollback_target(handle, &run, &target) {
        Ok(summary) => summary,
        Err(failure) => return run.fail(failure, EstimatedImpact::Restart),
    };""",
        """    let _ = &target;
    let redeployed = "revival skipped (mutation)".to_owned();""",
        [
            "rollback_stops_the_new_core_and_revives_the_old_deployment",
        ],
    ),
    (
        "M2 revival identity probe loses its target",
        "worker",
        """            caly_plan::EffectStep::Probe {
                probe: caly_plan::ProbeSpec {
                    kind: caly_plan::ProbeKind::ConfigIdentity,
                    target: Some(digest.clone()),
                },
                deadline_ms: 3_000,
            },""",
        """            caly_plan::EffectStep::Probe {
                probe: caly_plan::ProbeSpec {
                    kind: caly_plan::ProbeKind::ConfigIdentity,
                    target: None,
                },
                deadline_ms: 3_000,
            },""",
        [
            "rollback_stops_the_new_core_and_revives_the_old_deployment",
        ],
    ),
    (
        "M3 sing-box digest off by one char",
        "singbox",
        '''pub const SINGBOX_BINARY_SHA256: &str =
    "646bc01bf128c32a12eb50d8690e387bba7504da7b1d65c704bd53916e38595a";''',
        '''pub const SINGBOX_BINARY_SHA256: &str =
    "646bc01bf128c32a12eb50d8690e387bba7504da7b1d65c704bd53916e38595b";''',
        [
            "the_pinned_singbox_archive_hashes_to_what_the_plan_names",
        ],
    ),
    (
        "M4 snapshot-truth promotion skipped",
        "worker",
        """    handle
        .promote_snapshot_to_last_known_good(&target)
        .map_err(ApplyFailure::from)?;""",
        """    let _ = &target;""",
        [
            "rollback_stops_the_new_core_and_revives_the_old_deployment",
        ],
    ),
    (
        "M5 sim stops seeding identity on spawn",
        "sim",
        """                guard.core_identity = Some(spec.config_digest.clone());""",
        """                guard.core_identity = None;""",
        [
            "rollback_command_executes_compensations",
        ],
    ),
]


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def sweep_stray_cores():
    subprocess.run(
        ["pkill", "-f", "caly-ru" "n.yaml"],
        stdout=subprocess.DEVNULL,
        stderr=subprocess.DEVNULL,
    )
    time.sleep(1.0)  # a kill is not done until a beat has passed


def run_cargo():
    argvs = [
        ["cargo", "test", "-p", "caly-daemon", "--test", "real_apply", "--no-fail-fast"],
        ["cargo", "test", "-p", "caly-singbox", "--no-fail-fast"],
        ["cargo", "test", "-p", "caly-engine", "--test", "apply_execution_gate", "--no-fail-fast"],
    ]
    failed = []
    tail = ""
    for argv in argvs:
        try:
            proc = subprocess.run(
                argv,
                cwd=str(ROOT),
                env=ENV,
                capture_output=True,
                text=True,
                timeout=900,  # §4.139
            )
        except subprocess.TimeoutExpired:
            return 124, [], "TIMEOUT: the mutation wedged the suite (§4.139) — redesign it"
        out = proc.stdout + proc.stderr
        tail += out[-2000:]
        failed += [
            line[5:].split(" ... ")[0].split("::")[-1].strip()
            for line in out.splitlines()
            if line.startswith("test ") and line.rstrip().endswith("... FAILED")
        ]
    return 0, sorted(set(failed)), tail


def main():
    for path in ROOT.rglob("*.r57bak"):
        original = pathlib.Path(str(path)[: -len(".r57bak")])
        shutil.move(str(path), str(original))
        print("swept leftover backup:", path.name)
    sweep_stray_cores()

    originals = {name: digest(path) for name, path in SRC.items()}
    results = []
    bad = False
    for label, key, old, new, expected in MUTATIONS:
        path = SRC[key]
        backup = pathlib.Path(str(path) + ".r57bak")
        shutil.copyfile(path, backup)  # per-mutation backup (§4.137)
        s = path.read_text()
        assert s.count(old) == 1, "%s: anchor x%d" % (label, s.count(old))
        try:
            mutated = s.replace(old, new, 1)
            path.write_text(mutated)
            code, failed, out = run_cargo()
            wedged = code == 124
            red = [name for name in expected if name in failed]
            compile_error = "error[" in out or "could not compile" in out
            ok = bool(red) and not compile_error and not wedged
            results.append((label, ok))
            print("%-52s %s  red=%s" % (label, "BIT" if ok else "NO EFFECT", red or failed[:4]))
            if not ok:
                if compile_error:
                    print("   !! the mutation did not compile; it proves nothing")
                if wedged:
                    print("   !! the mutation wedged the suite; it proves nothing (§4.139)")
                print("   output tail:\n", out[-1200:])
        finally:
            shutil.move(str(backup), str(path))
            os.utime(path, None)
            assert digest(path) == originals[key], "%s: restore did not reproduce the file" % label
            sweep_stray_cores()

    print("\n== summary ==")
    for label, ok in results:
        print("%-52s %s" % (label, "bit" if ok else "DID NOT BIT"))
        if not ok:
            bad = True
    print("all mutations bit:", not bad)
    sys.exit(1 if bad else 0)


if __name__ == "__main__":
    main()
