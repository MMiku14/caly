#!/usr/bin/env python3
"""Round 87 falsification harness.

The claim: production bind/handshake is one BindSpec + one WireIo pump, not
a TCP-only leftover with a UDS flag. Two mutations, one file each:

- M1 (must bite)  UDS port-file drops the `unix:` prefix and writes the path
    only — `unix_port_file_text_is_the_unix_prefix` goes red. A bare path in
    `--port-file` is how a TCP parser would treat a UDS listener as a u16.
- M2 (must bite)  `drive_client_hello` skips `client_validate_hello_ack` —
    `an_encoding_lie_is_refused_before_observe` goes red. That is the R71
    hole (kind-only hello_ack) dressed as a typed loop.

Usage: `python3 scripts/archive/falsify_round87.py` (exit 0 = all bit, files restored).
Restore bumps mtime (stale-fingerprint bomb; R79.5.1). ROOT is this
workspace (`/home/user/caly`), not a leftover extract path.
"""

import hashlib
import os
import pathlib
import shutil
import subprocess
import sys
import time

ROOT = pathlib.Path("/home/user/caly")
ENV = dict(os.environ)
ENV["PATH"] = str(pathlib.Path.home() / ".cargo/bin") + ":" + ENV.get("PATH", "")

ENDPOINT = ROOT / "crates/caly-ipc/src/endpoint.rs"
DRIVE = ROOT / "crates/caly-ipc/src/handshake_drive.rs"

M1_JUDGE = [
    "cargo",
    "test",
    "-q",
    "-p",
    "caly-ipc",
    "--lib",
    "endpoint::tests::unix_port_file_text_is_the_unix_prefix",
    "--",
    "--exact",
]
M2_JUDGE = [
    "cargo",
    "test",
    "-q",
    "-p",
    "caly-ipc",
    "--lib",
    "handshake_drive::tests::an_encoding_lie_is_refused_before_observe",
    "--",
    "--exact",
]
JUDGE_TIMEOUT_SECS = 180


def digest(path):
    return hashlib.sha256(pathlib.Path(path).read_bytes()).hexdigest()


def sweep_strays():
    for path in ROOT.rglob("*.r87bak"):
        print(f"  note  sweeping stale {path}")
        path.unlink()


def run_judge(cmd):
    begin = time.time()
    proc = subprocess.Popen(
        cmd,
        cwd=ROOT,
        env=ENV,
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
        text=True,
        start_new_session=True,
    )
    try:
        out, _ = proc.communicate(timeout=JUDGE_TIMEOUT_SECS)
    except subprocess.TimeoutExpired:
        os.killpg(proc.pid, 9)
        proc.wait()
        return None, time.time() - begin, "HANG"
    combined = out or ""
    build_failed = "error[" in combined or "could not compile" in combined
    if build_failed:
        return None, time.time() - begin, "COMPILE"
    # A filter that matches nothing prints `ok. 0 passed; 0 failed` — that is
    # not a green judge, it is a silent miss of the test we meant to run.
    if "0 passed; 0 failed" in combined:
        return True, time.time() - begin, "ZERO_TESTS"
    ok = "0 failed" in combined and "test result: ok" in combined
    return ok, time.time() - begin, ""


def apply_one(path, needle, replacement):
    text = path.read_text()
    assert text.count(needle) == 1, f"{path}: needle not unique ({text.count(needle)}): {needle!r}"
    bak = pathlib.Path(str(path) + ".r87bak")
    shutil.copy2(path, bak)
    path.write_text(text.replace(needle, replacement))


def restore_one(path):
    bak = pathlib.Path(str(path) + ".r87bak")
    if bak.exists():
        shutil.copy2(bak, path)
        bak.unlink()
        os.utime(path, None)


# Unique against BoundAddr::display, which also formats unix:{path}.
M1_OLD = """            BoundAddr::Tcp { port, .. } => port.to_string(),
            BoundAddr::Unix { path } => format!("unix:{path}"),"""
M1_NEW = """            BoundAddr::Tcp { port, .. } => port.to_string(),
            BoundAddr::Unix { path } => path.clone(),"""

M2_OLD = "    client_validate_hello_ack(&view, json)?;\n"
M2_NEW = "    let _ = json;\n"


def main():
    sweep_strays()
    before_endpoint = digest(ENDPOINT)
    before_drive = digest(DRIVE)
    results = []

    apply_one(ENDPOINT, M1_OLD, M1_NEW)
    ok, secs, note = run_judge(M1_JUDGE)
    results.append(
        (
            "M1",
            "UDS port-file drops unix: prefix (must bite)",
            ok,
            secs,
            note,
        )
    )
    restore_one(ENDPOINT)

    apply_one(DRIVE, M2_OLD, M2_NEW)
    ok, secs, note = run_judge(M2_JUDGE)
    results.append(
        (
            "M2",
            "drive_client_hello skips client_validate_hello_ack (must bite)",
            ok,
            secs,
            note,
        )
    )
    restore_one(DRIVE)

    all_bite = True
    for name, label, bit, secs, note in results:
        if note:
            print(f"  {'ok' if not bit else 'MISS'}    {name} {label} ({note} in {secs:.1f}s)")
        else:
            print(f"  {'ok' if not bit else 'MISS'}    {name} {label} (bite in {secs:.1f}s)")
        if bit:
            all_bite = False

    after_endpoint = digest(ENDPOINT)
    after_drive = digest(DRIVE)
    assert after_endpoint == before_endpoint, "endpoint.rs not restored"
    assert after_drive == before_drive, "handshake_drive.rs not restored"
    print(f"restored: endpoint={after_endpoint[:12]}… drive={after_drive[:12]}…")
    print("all mutations behaved as predicted: " + ("True" if all_bite else "False"))
    sys.exit(0 if all_bite else 1)


if __name__ == "__main__":
    main()
