#!/usr/bin/env python3
"""Round 130 falsify: the Deployment stream producer + the two backpressure producers.

Four mutations break the round's contract from four sides: the per-kind frame filter
disappears (a deployment stream is again the whole shared window), the filter inverts
(a deployment stream carries everything EXCEPT deployment events — the seq coupling
to the log survives, the production semantics do not), the engine stops recording
`EventBacklog` where it observes the roll, and the report outlet for
`StreamBackpressure` is severed where the Reset is minted.

Each mutation rewrites one production file, runs a targeted red/green pair, then restores
byte-for-byte (sha256 + mtime bump). RED verdicts carry the compiled-guard (a compile
error is not a red).
"""
import hashlib
import os
import subprocess
import sys

CALY = "/home/user/caly/caly"
BRIDGE = f"{CALY}/crates/caly-daemon/src/watch_bridge.rs"
SERVICE = f"{CALY}/crates/caly-engine/src/service.rs"
APP = f"{CALY}/crates/caly-daemon/src/app.rs"

T = "-p caly-daemon --test deployment_stream"
J_REPLAY = f"{T} a_deployment_watch_replays_only_deployment_events_from_the_retained_window"
J_LIVE = f"{T} a_deployment_watch_delivers_only_the_new_deployment_events_after_a_pull"
J_RESUME = f"{T} a_deployment_watch_resumes_from_an_explicit_cursor"
J_LAGGARD = f"{T} a_deployment_watch_that_falls_behind_gets_a_reset_and_the_pressure_is_recorded"
J_GUARD = (
    "-p caly-daemon --test watch_snapshot_stream "
    "after_the_snapshot_only_new_events_arrive_as_patches"
)


def run(*args: str) -> tuple[int, str]:
    proc = subprocess.run(args, cwd=CALY, capture_output=True, text=True, timeout=900)
    return proc.returncode, proc.stdout + proc.stderr


def test(name: str, expect_ok: bool) -> str:
    code, out = run("cargo", "test", *name.split(), "--", "--test-threads=1")
    compiled = "error[" not in out and "error: " not in out
    passed = code == 0 and compiled
    if passed == expect_ok:
        return "GREEN" if expect_ok else "RED"
    verdict = "UNEXPECTED-RED" if expect_ok else "MISSED-BIT"
    tail = "\n".join(out.splitlines()[-12:])
    print(f"    [{verdict}] {name}\n    --------\n{tail}\n    --------")
    return verdict


MUTATIONS = [
    dict(
        name="M1 the per-kind filter disappears (deployment == the whole window)",
        file=BRIDGE,
        old="""        if request.kind == StreamKind::Deployment
            && event.kind != caly_engine::EventKind::DeploymentChanged
        {
            continue;
        }
""",
        new="",
        red=[(J_REPLAY, False), (J_LIVE, False)],
        green=[(J_LAGGARD, True)],
    ),
    dict(
        name="M2 the filter inverts (everything EXCEPT deployment events)",
        file=BRIDGE,
        old="""            && event.kind != caly_engine::EventKind::DeploymentChanged""",
        new="""            && event.kind == caly_engine::EventKind::DeploymentChanged""",
        red=[(J_REPLAY, False), (J_RESUME, False)],
        green=[(J_GUARD, True)],
    ),
    dict(
        name="M3 the engine stops recording EventBacklog at the roll",
        file=SERVICE,
        old="""                if from_exclusive.is_some() {""",
        new="""                if false {""",
        red=[(J_LAGGARD, False)],
        green=[(J_REPLAY, True)],
    ),
    dict(
        name="M4 the StreamBackpressure report outlet is severed at the Reset mints",
        file=APP,
        old="""    pub fn record_stream_backpressure(
        &self,
        kind: caly_ipc::StreamKind,
        stream_id: caly_api::StreamId,
        detail: &str,
    ) -> Result<(), String> {
        self.engine
            .record_stream_backpressure(&format!("{kind:?}"), stream_id.0, detail)
    }""",
        new="""    pub fn record_stream_backpressure(
        &self,
        kind: caly_ipc::StreamKind,
        stream_id: caly_api::StreamId,
        detail: &str,
    ) -> Result<(), String> {
        let _ = (kind, stream_id, detail);
        Ok(())
    }""",
        red=[(J_LAGGARD, False)],
        green=[(J_REPLAY, True)],
    ),
]


def main() -> int:
    leftovers: list[str] = []
    for mutation in MUTATIONS:
        path = mutation["file"]
        original = open(path, "rb").read().decode()
        original_sha = hashlib.sha256(original.encode()).hexdigest()
        if mutation["old"] not in original:
            print(f"{mutation['name']}: ANCHOR NOT FOUND (skipped)")
            continue
        mutated = original.replace(mutation["old"], mutation["new"], 1)
        open(path, "w").write(mutated)
        os.utime(path, None)
        try:
            verdicts = []
            for name, expect in mutation["red"] + mutation["green"]:
                verdicts.append(test(name, expect))
            reds = verdicts[: len(mutation["red"])]
            greens = verdicts[len(mutation["red"]) :]
            ok = all(v == "RED" for v in reds) and all(v == "GREEN" for v in greens)
            print(
                f"{mutation['name']}: {'BIT' if ok else 'MISSED-BIT'} "
                f"(red={reds} green={greens})"
            )
        finally:
            open(path, "w").write(original)
            os.utime(path, None)
            if hashlib.sha256(open(path, "rb").read()).hexdigest() != original_sha:
                leftovers.append(path)
    if leftovers:
        print(f"LEFTOVERS: {leftovers}")
        return 1
    print("leftovers: []")
    return 0


if __name__ == "__main__":
    sys.exit(main())
