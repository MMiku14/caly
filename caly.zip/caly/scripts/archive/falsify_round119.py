#!/usr/bin/env python3
"""Round 119 falsify: support bundle carries the durable job history (ADR-057 §5 slice 3).

Each mutation rewrites one production file, runs a targeted red/green test pair,
then restores the file byte-for-byte (sha256 + immediate mtime bump, per the
round-112 lesson: the next mutation must relink the poisoned binary).

Note: this archive script lives with the round that wrote it; the repo root is
/home/user/caly/caly (the zip ships a nested caly/ directory).
"""
import hashlib
import os
import subprocess
import sys

CALY = "/home/user/caly/caly"
BUNDLE_RS = f"{CALY}/crates/caly-engine/src/bundle.rs"


def sha(path: str) -> str:
    return hashlib.sha256(open(path, "rb").read()).hexdigest()


def run(*args: str) -> tuple[int, str]:
    proc = subprocess.run(args, cwd=CALY, capture_output=True, text=True, timeout=900)
    return proc.returncode, proc.stdout + proc.stderr


def test(name: str, expect_ok: bool) -> str:
    code, out = run("cargo", "test", *name.split())
    if code == 0 and "error[" in out:
        code = 1
    passed = code == 0
    if passed == expect_ok:
        return "GREEN" if expect_ok else "RED"
    return "UNEXPECTED-RED" if expect_ok else "MISSED-BIT"


MUTATIONS = [
    dict(
        name="M1 the collector is never called (section silently absent)",
        file=BUNDLE_RS,
        old="""    collect_runtime_log(&state, &mut draft);
    collect_job_history(&backend, &mut draft)?;""",
        new="""    collect_runtime_log(&state, &mut draft);""",
        red=[
            ("-p caly-engine --test support_bundle the_bundle_carries_the_durable_job_history_beyond_the_process_lifetime", False),
            ("-p caly-engine --test support_bundle the_job_history_header_carries_the_stable_failure_code", False),
            ("-p caly-engine --test support_bundle the_job_history_section_is_bounded_and_reports_the_total", False),
            ("-p caly-engine --test support_bundle an_empty_job_history_is_stated_not_omitted", False),
            # The declared-section contract notices the missing section too.
            ("-p caly-engine --test support_bundle the_bundle_carries_every_section_the_docs_require", False),
        ],
        green=[
            # A judge with no stake in the new section stays green: the mutation removes
            # the collector, it does not break the bundle.
            ("-p caly-engine --test support_bundle the_bundle_reports_the_deployment_the_store_remembers", True),
        ],
    ),
    dict(
        name="M2 the header drops the stable failure code",
        file=BUNDLE_RS,
        old='                record.failure_code.as_deref().unwrap_or("-"),',
        new='                "-",',
        red=[
            ("-p caly-engine --test support_bundle the_job_history_header_carries_the_stable_failure_code", False),
        ],
        green=[
            ("-p caly-engine --test support_bundle the_bundle_carries_the_durable_job_history_beyond_the_process_lifetime", True),
            ("-p caly-engine --test support_bundle the_job_history_section_is_bounded_and_reports_the_total", True),
        ],
    ),
    dict(
        name="M3 the job window is unbounded",
        file=BUNDLE_RS,
        old="    for record in records.iter().take(JOB_HISTORY_JOBS) {",
        new="    for record in records.iter() {",
        red=[
            ("-p caly-engine --test support_bundle the_job_history_section_is_bounded_and_reports_the_total", False),
        ],
        green=[
            ("-p caly-engine --test support_bundle the_bundle_carries_the_durable_job_history_beyond_the_process_lifetime", True),
            ("-p caly-engine --test support_bundle an_empty_job_history_is_stated_not_omitted", True),
        ],
    ),
]


def main() -> int:
    leftovers: list[str] = []
    for mutation in MUTATIONS:
        path = mutation["file"]
        original = open(path, "rb").read().decode()
        original_sha = hashlib.sha256(original.encode()).hexdigest()
        if mutation["old"] not in original:
            print(f"{mutation['name']}: ANCHOR NOT FOUND (skipped)")
            continue
        mutated = original.replace(mutation["old"], mutation["new"], 1)
        open(path, "w").write(mutated)
        os.utime(path, None)  # immediate mtime bump so the next build relinks
        try:
            verdicts = []
            for name, expect in mutation["red"] + mutation["green"]:
                verdicts.append(test(name, expect))
            reds = verdicts[: len(mutation["red"])]
            greens = verdicts[len(mutation["red"]) :]
            ok = all(v == "RED" for v in reds) and all(v == "GREEN" for v in greens)
            print(
                f"{mutation['name']}: {'BIT' if ok else 'MISSED-BIT'} "
                f"(red={reds} green={greens})"
            )
        finally:
            open(path, "w").write(original)
            os.utime(path, None)
            after_sha = hashlib.sha256(open(path, "rb").read()).hexdigest()
            if after_sha != original_sha:
                leftovers.append(path)
    if leftovers:
        print(f"LEFTOVERS: {leftovers}")
        return 1
    print("leftovers: []")
    return 0


if __name__ == "__main__":
    sys.exit(main())
