#!/usr/bin/env python3
"""Round 80 falsification harness.

The claim: `docs/guides/ERRORS.md` §4/§4.1's code names and `caly_api::ErrorCode` form the
documented closure, judged by `caly-api/tests/error_doc.rs`:

- M1 (must bite)  a document-side drift: the §4 row for `CONFIG_INVALID` is typo'd to
    `CONFIG_INVALIDX` — the closure judge goes red (the enum's code is no longer
    documented and the doc's code no longer exists).
- M2 (must bite)  a reserved promotion without a doc move: `RATE_LIMITED` gains a §4
    row while still listed in §4.1 — the stable count (12) and the pinned half-way
    both break.
- M3 (must bite)  a vocabulary drift: the §3 category `Config` becomes `Configs` —
    the doc-internal conformance judge goes red (the §4 row's category is no longer
    defined).
- M4 (must bite)  a code-side drift: `as_str` maps `Timeout` to `TIMEOUT_` — the R80
    closure judge goes red, and the R79 exit-code judge goes red too (both judges are
    run; the report says which reddened).

Usage: `python3 scripts/archive/falsify_round80.py` (exit 0 = all bit, files restored).
Restore bumps mtime (`os.utime(path, None)`) — copy2's preserved mtime would leave a
stale-fingerprint time bomb (the R79.5.1 lesson).
"""

import hashlib
import os
import pathlib
import shutil
import subprocess
import sys
import time

ROOT = pathlib.Path("/home/user/caly_extract/caly")
ENV = dict(os.environ)
ENV["PATH"] = str(pathlib.Path.home() / ".cargo/bin") + ":" + ENV.get("PATH", "")

DOC = ROOT / "docs/guides/ERRORS.md"
CODE = ROOT / "crates/caly-api/src/error.rs"

JUDGE_R80 = ["cargo", "test", "-q", "-p", "caly-api", "--test", "error_doc"]
JUDGE_R79 = ["cargo", "test", "-q", "-p", "caly-cli", "--test", "exit_code_table"]
JUDGE_TIMEOUT_SECS = 300


def digest(path):
    return hashlib.sha256(pathlib.Path(path).read_bytes()).hexdigest()


def sweep_strays():
    for path in ROOT.rglob("*.r80bak"):
        print(f"  note  sweeping stale {path}")
        path.unlink()


def run_judge(command):
    begin = time.time()
    proc = subprocess.Popen(
        command,
        cwd=ROOT,
        env=ENV,
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
        text=True,
        start_new_session=True,
    )
    try:
        out, _ = proc.communicate(timeout=JUDGE_TIMEOUT_SECS)
    except subprocess.TimeoutExpired:
        os.killpg(proc.pid, 9)
        proc.wait()
        return None, time.time() - begin, "HANG"
    ok = "0 failed" in (out or "") and "test result: ok" in (out or "")
    return ok, time.time() - begin, ""


def apply_one(path, needle, replacement):
    text = path.read_text()
    assert text.count(needle) == 1, f"{path}: needle not unique: {needle!r}"
    bak = pathlib.Path(str(path) + ".r80bak")
    shutil.copy2(path, bak)
    path.write_text(text.replace(needle, replacement))


def restore_one(path):
    bak = pathlib.Path(str(path) + ".r80bak")
    if bak.exists():
        shutil.copy2(bak, path)
        bak.unlink()
        # copy2 keeps the ORIGINAL mtime, which can be OLDER than a rlib built from the
        # mutated text — cargo then trusts the stale artifact forever (R79.5.1). Bump
        # mtime to now so the next build is forced.
        os.utime(path, None)


M1_OLD = "| `CONFIG_INVALID` | Config | 否 |"
M1_NEW = "| `CONFIG_INVALIDX` | Config | 否 |"

M2_OLD = "| `CURSOR_STALE` | User | 否 | 分页 cursor 对应的 revision 已过期，需重新查询 |"
M2_NEW = (
    M2_OLD
    + "\n"
    + "| `RATE_LIMITED` | Io | 是 | 请求过频，调用方应退避重试 |"
)

M3_OLD = "| `Config` | 配置解析、校验、冲突、引用或迁移错误 |"
M3_NEW = "| `Configs` | 配置解析、校验、冲突、引用或迁移错误 |"

M4_OLD = '    Self::Timeout => "TIMEOUT",'
M4_NEW = '    Self::Timeout => "TIMEOUT_" ,'


def main():
    sweep_strays()
    results = []

    # M1: document-side drift on a stable code name.
    apply_one(DOC, M1_OLD, M1_NEW)
    ok, secs, note = run_judge(JUDGE_R80)
    results.append(("M1", "the §4 stable name is typo'd (must bite)", ok, secs, note))
    restore_one(DOC)

    # M2: a reserved code gains a stable row without leaving §4.1.
    apply_one(DOC, M2_OLD, M2_NEW)
    ok, secs, note = run_judge(JUDGE_R80)
    results.append(("M2", "a reserved code is promoted without a doc move (must bite)", ok, secs, note))
    restore_one(DOC)

    # M3: document-side drift inside the vocabulary (§3 category renamed).
    apply_one(DOC, M3_OLD, M3_NEW)
    ok, secs, note = run_judge(JUDGE_R80)
    results.append(("M3", "a §3 category name drifts (must bite)", ok, secs, note))
    restore_one(DOC)

    # M4: code-side drift in as_str, judged by both R80 and R79.
    apply_one(CODE, M4_OLD, M4_NEW)
    ok80, secs80, note80 = run_judge(JUDGE_R80)
    ok79, secs79, _ = run_judge(JUDGE_R79)
    note80 = (note80 or "") + f"; R79 judge red={not ok79} ({secs79:.1f}s)"
    results.append(("M4", "as_str drifts for Timeout (must bite, R79 too)", ok80, secs80, note80))
    restore_one(CODE)

    all_bite = True
    for name, label, bit, secs, note in results:
        if note:
            print(f"  {'ok' if not bit else 'MISS'}    {name} {label} ({note} in {secs:.1f}s)")
        else:
            print(f"  {'ok' if not bit else 'MISS'}    {name} {label} (bite in {secs:.1f}s)")
        if bit:
            all_bite = False

    print(f"restored: doc={digest(DOC)[:12]}… code={digest(CODE)[:12]}…")
    print("all mutations behaved as predicted: " + ("True" if all_bite else "False"))
    sys.exit(0 if all_bite else 1)


if __name__ == "__main__":
    main()
