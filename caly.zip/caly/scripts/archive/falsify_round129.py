#!/usr/bin/env python3
"""Round 129 falsify: bounded DNS resolution (ADR-052 addendum §7).

Four mutations break the bounded-resolver contract from four sides: the singleton becomes
a thread per call (the unbounded-liability regression), an expired deadline still enters
the uninterruptible syscall, the caller-deadline refusal is mislabelled as a network
error, and the caller's budget is swapped for the fixed peer timeout.

Each mutation rewrites one production file, runs a targeted red/green pair, then restores
byte-for-byte (sha256 + mtime bump). RED verdicts carry the compiled-guard (a compile
error is not a red).
"""
import hashlib
import os
import subprocess
import sys

CALY = "/home/user/caly/caly"
RESOLVE = f"{CALY}/crates/caly-io-std/src/resolve.rs"

T = "-p caly-io-std --test bounded_resolve"
J_ONE = f"{T} the_real_resolver_answers_through_exactly_one_shared_thread"
J_EXPIRED = f"{T} an_expired_deadline_refuses_by_name_without_entering_the_resolver"
J_HUNG = f"{T} a_hung_lookup_times_out_by_name_and_the_single_thread_recovers"
J_BUDGET = f"{T} the_callers_smaller_budget_wins_over_the_peer_timeout"


def run(*args: str) -> tuple[int, str]:
    proc = subprocess.run(args, cwd=CALY, capture_output=True, text=True, timeout=900)
    return proc.returncode, proc.stdout + proc.stderr


def test(name: str, expect_ok: bool) -> str:
    code, out = run("cargo", "test", *name.split(), "--", "--test-threads=1")
    compiled = "error[" not in out and "error: " not in out
    passed = code == 0 and compiled
    if passed == expect_ok:
        return "GREEN" if expect_ok else "RED"
    verdict = "UNEXPECTED-RED" if expect_ok else "MISSED-BIT"
    tail = "\n".join(out.splitlines()[-12:])
    print(f"    [{verdict}] {name}\n    --------\n{tail}\n    --------")
    return verdict


MUTATIONS = [
    dict(
        name="M1 the singleton quietly becomes a thread per call",
        file=RESOLVE,
        old="""fn sender() -> &'static mpsc::Sender<Request> {
    RESOLVER.get_or_init(|| {
        let (sender, receiver) = mpsc::channel::<Request>();
        thread::Builder::new()
            .name("caly-bounded-resolver".to_owned())
            .spawn(move || worker(receiver))
            .expect("spawn the bounded resolver thread");
        RESOLVER_THREADS.fetch_add(1, Ordering::Relaxed);
        sender
    })
}""",
        new="""fn sender() -> &'static mpsc::Sender<Request> {
    let (sender, receiver) = mpsc::channel::<Request>();
    thread::Builder::new()
        .name("caly-bounded-resolver".to_owned())
        .spawn(move || worker(receiver))
        .expect("spawn the bounded resolver thread");
    RESOLVER_THREADS.fetch_add(1, Ordering::Relaxed);
    Box::leak(Box::new(sender))
}""",
        red=[(J_ONE, False)],
        green=[(J_BUDGET, True)],
    ),
    dict(
        name="M2 an expired deadline still enters the uninterruptible syscall",
        file=RESOLVE,
        old="""    if budget.is_zero() {
        return Err(refused_deadline(host));
    }""",
        new="""    if false && budget.is_zero() {
        return Err(refused_deadline(host));
    }""",
        red=[(J_EXPIRED, False)],
        green=[(J_ONE, True)],
    ),
    dict(
        name="M3 the caller-deadline refusal is mislabelled as a network error",
        file=RESOLVE,
        old="""fn not_answered(host: &str, budget: Duration) -> IoFault {
    IoFault::new(
        IoFaultKind::Timeout,""",
        new="""fn not_answered(host: &str, budget: Duration) -> IoFault {
    IoFault::new(
        IoFaultKind::Unavailable,""",
        red=[(J_HUNG, False)],
        green=[(J_EXPIRED, True)],
    ),
    dict(
        name="M4 the caller's budget is swapped for the fixed peer timeout",
        file=RESOLVE,
        old="""    match reply_receiver.recv_timeout(budget) {""",
        new="""    match reply_receiver.recv_timeout(Duration::from_secs(5)) {""",
        red=[(J_BUDGET, False)],
        green=[(J_ONE, True)],
    ),
]


def main() -> int:
    leftovers: list[str] = []
    for mutation in MUTATIONS:
        path = mutation["file"]
        original = open(path, "rb").read().decode()
        original_sha = hashlib.sha256(original.encode()).hexdigest()
        if mutation["old"] not in original:
            print(f"{mutation['name']}: ANCHOR NOT FOUND (skipped)")
            continue
        mutated = original.replace(mutation["old"], mutation["new"], 1)
        open(path, "w").write(mutated)
        os.utime(path, None)
        try:
            verdicts = []
            for name, expect in mutation["red"] + mutation["green"]:
                verdicts.append(test(name, expect))
            reds = verdicts[: len(mutation["red"])]
            greens = verdicts[len(mutation["red"]) :]
            ok = all(v == "RED" for v in reds) and all(v == "GREEN" for v in greens)
            print(
                f"{mutation['name']}: {'BIT' if ok else 'MISSED-BIT'} "
                f"(red={reds} green={greens})"
            )
        finally:
            open(path, "w").write(original)
            os.utime(path, None)
            if hashlib.sha256(open(path, "rb").read()).hexdigest() != original_sha:
                leftovers.append(path)
    if leftovers:
        print(f"LEFTOVERS: {leftovers}")
        return 1
    print("leftovers: []")
    return 0


if __name__ == "__main__":
    sys.exit(main())
