#!/usr/bin/env python3
"""Round 86 falsification harness.

The claim: lifecycle refusal consumes `ApiError::for_code(Conflict)`, so
category is Config and retryable is false; `for_code` itself reads
`code.category()` / `retry_policy()`. Two mutations, one file each:

- M1 (must bite)  `for_code` restates User instead of `code.category()` —
    the error_doc judge goes red.
- M2 (must bite)  lifecycle refusal goes back to Conflict+Platform+true —
    the durable_boot recovering-daemon judge goes red.

Usage: `python3 scripts/archive/falsify_round86.py` (exit 0 = all bit, files restored).
Restore bumps mtime (stale-fingerprint bomb; R79.5.1). ROOT is this
workspace (`/home/user/caly`), not a leftover extract path.
"""

import hashlib
import os
import pathlib
import shutil
import subprocess
import sys
import time

ROOT = pathlib.Path("/home/user/caly")
ENV = dict(os.environ)
ENV["PATH"] = str(pathlib.Path.home() / ".cargo/bin") + ":" + ENV.get("PATH", "")

ERROR = ROOT / "crates/caly-api/src/error.rs"
APP = ROOT / "crates/caly-daemon/src/app.rs"

M1_JUDGE = [
    "cargo",
    "test",
    "-q",
    "-p",
    "caly-api",
    "--test",
    "error_doc",
    "for_code_consumes_the_section_4_defaults",
]
M2_JUDGE = [
    "cargo",
    "test",
    "-q",
    "-p",
    "caly-daemon",
    "--test",
    "durable_boot",
    "a_recovering_daemon_refuses_apply_and_still_answers_status_and_rollback",
]
JUDGE_TIMEOUT_SECS = 180


def digest(path):
    return hashlib.sha256(pathlib.Path(path).read_bytes()).hexdigest()


def sweep_strays():
    for path in ROOT.rglob("*.r86bak"):
        print(f"  note  sweeping stale {path}")
        path.unlink()


def run_judge(cmd):
    begin = time.time()
    proc = subprocess.Popen(
        cmd,
        cwd=ROOT,
        env=ENV,
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
        text=True,
        start_new_session=True,
    )
    try:
        out, _ = proc.communicate(timeout=JUDGE_TIMEOUT_SECS)
    except subprocess.TimeoutExpired:
        os.killpg(proc.pid, 9)
        proc.wait()
        return None, time.time() - begin, "HANG"
    combined = out or ""
    build_failed = "error[" in combined or "could not compile" in combined
    if build_failed:
        return None, time.time() - begin, "COMPILE"
    ok = "0 failed" in combined and "test result: ok" in combined
    return ok, time.time() - begin, ""


def apply_one(path, needle, replacement):
    text = path.read_text()
    assert text.count(needle) == 1, f"{path}: needle not unique: {needle!r}"
    bak = pathlib.Path(str(path) + ".r86bak")
    shutil.copy2(path, bak)
    path.write_text(text.replace(needle, replacement))


def restore_one(path):
    bak = pathlib.Path(str(path) + ".r86bak")
    if bak.exists():
        shutil.copy2(bak, path)
        bak.unlink()
        os.utime(path, None)


M1_OLD = "            code.category(),"
M1_NEW = "            ErrorCategory::User,"

M2_OLD = """            ApiError::for_code(
                caly_api::ErrorCode::Conflict,
                format!("daemon is {lifecycle:?} and will not accept this command yet"),
                trace_id.clone(),
            )"""
M2_NEW = """            ApiError::new(
                caly_api::ErrorCode::Conflict,
                caly_api::ErrorCategory::Platform,
                true,
                format!("daemon is {lifecycle:?} and will not accept this command yet"),
                trace_id.clone(),
            )"""


def main():
    sweep_strays()
    before_error = digest(ERROR)
    before_app = digest(APP)
    results = []

    apply_one(ERROR, M1_OLD, M1_NEW)
    ok, secs, note = run_judge(M1_JUDGE)
    results.append(("M1", "for_code restates User instead of category() (must bite)", ok, secs, note))
    restore_one(ERROR)

    apply_one(APP, M2_OLD, M2_NEW)
    ok, secs, note = run_judge(M2_JUDGE)
    results.append(("M2", "lifecycle refusal back to Platform+true (must bite)", ok, secs, note))
    restore_one(APP)

    all_bite = True
    for name, label, bit, secs, note in results:
        if note:
            print(f"  {'ok' if not bit else 'MISS'}    {name} {label} ({note} in {secs:.1f}s)")
        else:
            print(f"  {'ok' if not bit else 'MISS'}    {name} {label} (bite in {secs:.1f}s)")
        if bit:
            all_bite = False

    after_error = digest(ERROR)
    after_app = digest(APP)
    assert after_error == before_error, "error.rs not restored"
    assert after_app == before_app, "app.rs not restored"
    print(f"restored: error={after_error[:12]}… app={after_app[:12]}…")
    print("all mutations behaved as predicted: " + ("True" if all_bite else "False"))
    sys.exit(0 if all_bite else 1)


if __name__ == "__main__":
    main()
