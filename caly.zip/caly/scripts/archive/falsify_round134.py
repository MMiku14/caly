#!/usr/bin/env python3
"""Round 134 falsify: platform face round 1 — UDS socket mode + source registration quota.

Four mutations, one production file each:
  M1 the registration quota disappears (worker + binary judges must go red);
  M2 the world-accessible mode validation disappears (endpoint judge);
  M3 bind_unix applies the default mode regardless of the parameter (endpoint+binary);
  M4 calyd drops the flag on the floor (binds with the default; binary judge).

Byte-for-byte restore per mutation (sha256 + mtime bump); RED verdicts carry the
compiled-guard.
"""
import hashlib
import os
import subprocess
import sys

CALY = "/home/user/caly/caly"
WORKER = f"{CALY}/crates/caly-engine/src/source_worker.rs"
ENDPOINT = f"{CALY}/crates/caly-ipc/src/endpoint.rs"
CALYD = f"{CALY}/crates/caly-daemon/src/bin/calyd.rs"

T_WORKER = "-p caly-engine --lib the_registration_quota_refuses_growth_past_the_cap_but_not_updates"
T_WORLD = "-p caly-ipc --test endpoint a_world_accessible_socket_mode_is_refused_by_name"
T_GROUP = "-p caly-ipc --test endpoint an_explicit_group_socket_mode_is_applied_at_bind"
T_BINMODE = (
    "-p caly-daemon --test calyd_wire the_socket_mode_flag_is_applied_to_the_bound_unix_socket"
)
T_BINCAP = (
    "-p caly-daemon --test calyd_wire a_65th_source_endpoint_registration_is_refused_at_startup_by_name"
)


def run(*args: str) -> tuple[int, str]:
    proc = subprocess.run(args, cwd=CALY, capture_output=True, text=True, timeout=900)
    return proc.returncode, proc.stdout + proc.stderr


def test(name: str, expect_ok: bool) -> str:
    code, out = run("cargo", "test", *name.split(), "--", "--test-threads=1")
    compiled = "error[" not in out and "error: " not in out
    passed = code == 0 and compiled
    if passed == expect_ok:
        return "GREEN" if expect_ok else "RED"
    verdict = "UNEXPECTED-RED" if expect_ok else "MISSED-BIT"
    tail = "\n".join(out.splitlines()[-10:])
    print(f"    [{verdict}] {name}\n    --------\n{tail}\n    --------")
    return verdict


MUTATIONS = [
    dict(
        name="M1 the registration quota disappears",
        file=WORKER,
        old="""        if previous.is_none() && guard.len() >= MAX_SOURCE_ENDPOINTS {""",
        new="""        if false && previous.is_none() && guard.len() >= MAX_SOURCE_ENDPOINTS {""",
        red=[(T_WORKER, False), (T_BINCAP, False)],
        green=[(T_WORLD, True)],
    ),
    dict(
        name="M2 the world-accessible mode validation disappears",
        file=ENDPOINT,
        old="""        if unix_mode & 0o007 != 0 {""",
        new="""        if false && unix_mode & 0o007 != 0 {""",
        red=[(T_WORLD, False)],
        green=[(T_GROUP, True)],
    ),
    dict(
        name="M3 bind_unix applies the default mode regardless of the parameter",
        file=ENDPOINT,
        old="""    std::fs::set_permissions(Path::new(path), std::fs::Permissions::from_mode(mode))""",
        new="""    std::fs::set_permissions(
        Path::new(path),
        std::fs::Permissions::from_mode(UNIX_SOCKET_MODE),
    )""",
        red=[(T_GROUP, False), (T_BINMODE, False)],
        green=[(T_WORLD, True)],
    ),
    dict(
        name="M4 calyd drops the flag on the floor",
        file=CALYD,
        old="""    let (listener, bound) = match WireListener::bind_with_unix_mode(
        &spec,
        socket_mode.unwrap_or(caly_ipc::UNIX_SOCKET_MODE),
    ) {""",
        new="""    let _ = socket_mode;
    let (listener, bound) = match WireListener::bind(&spec) {""",
        red=[(T_BINMODE, False)],
        green=[(T_BINCAP, True)],
    ),
]


def main() -> int:
    leftovers: list[str] = []
    for mutation in MUTATIONS:
        path = mutation["file"]
        original = open(path, "rb").read().decode()
        original_sha = hashlib.sha256(original.encode()).hexdigest()
        if mutation["old"] not in original:
            print(f"{mutation['name']}: ANCHOR NOT FOUND (skipped)")
            continue
        mutated = original.replace(mutation["old"], mutation["new"], 1)
        open(path, "w").write(mutated)
        os.utime(path, None)
        try:
            verdicts = []
            for name, expect in mutation["red"] + mutation["green"]:
                verdicts.append(test(name, expect))
            reds = verdicts[: len(mutation["red"])]
            greens = verdicts[len(mutation["red"]) :]
            ok = all(v == "RED" for v in reds) and all(v == "GREEN" for v in greens)
            print(
                f"{mutation['name']}: {'BIT' if ok else 'MISSED-BIT'} "
                f"(red={reds} green={greens})"
            )
        finally:
            open(path, "w").write(original)
            os.utime(path, None)
            if hashlib.sha256(open(path, "rb").read().decode().encode()).hexdigest() != original_sha:
                leftovers.append(path)
    if leftovers:
        print(f"LEFTOVERS: {leftovers}")
        return 1
    print("leftovers: []")
    return 0


if __name__ == "__main__":
    sys.exit(main())
