#!/usr/bin/env python3
"""Round 123 falsify: the three §13#3 closures.

Six mutations across the three slices: the peek crate misreading EAGAIN as Closed
(would reap live sessions), the endpoint regressing to permanent Indeterminate,
the session id counter never advancing, the per-request correlation check removed,
the daemon spending the connection after a stream ends, and the CLI hand-spelling
an operation name (the second request table, round 76's shape).

Each mutation rewrites one production file, runs a targeted red/green pair, then
restores byte-for-byte (sha256 + mtime bump). Binary-e2e judges are preceded by an
explicit build of the sibling binaries (round-120 lesson).
"""
import hashlib
import os
import subprocess
import sys

CALY = "/home/user/caly/caly"
PEEK_RS = f"{CALY}/crates/caly-uds-peek/src/lib.rs"
ENDPOINT_RS = f"{CALY}/crates/caly-ipc/src/endpoint.rs"
CALY_RS = f"{CALY}/crates/caly-cli/src/bin/caly.rs"
CALYD_RS = f"{CALY}/crates/caly-daemon/src/bin/calyd.rs"

JUDGE_IDS = "-p caly-cli --test caly_cli_e2e a_second_request_on_one_session_carries_the_next_id"
JUDGE_STALE = "-p caly-cli --test caly_cli_e2e a_stale_id_echo_for_the_second_request_is_refused"
JUDGE_TABLE = "-p caly-arch-test --test dependency_direction the_cli_speaks_the_one_typed_request_table"


def sha(path: str) -> str:
    return hashlib.sha256(open(path, "rb").read()).hexdigest()


def run(*args: str) -> tuple[int, str]:
    proc = subprocess.run(args, cwd=CALY, capture_output=True, text=True, timeout=900)
    return proc.returncode, proc.stdout + proc.stderr


def build_bins() -> None:
    code, out = run(
        "cargo", "build", "-p", "caly-daemon", "--bin", "calyd", "-p", "caly-cli", "--bin", "caly"
    )
    if code != 0:
        sys.exit(f"binaries failed to build:\n{out[-4000:]}")


def test(name: str, expect_ok: bool) -> str:
    build_bins()
    code, out = run("cargo", "test", *name.split())
    if code == 0 and "error[" in out:
        code = 1
    passed = code == 0
    if passed == expect_ok:
        return "GREEN" if expect_ok else "RED"
    return "UNEXPECTED-RED" if expect_ok else "MISSED-BIT"


MUTATIONS = [
    dict(
        name="M1 the peek reads EAGAIN as Closed (every quiet live session would be reaped)",
        file=PEEK_RS,
        old="            EAGAIN => super::UdsPeek::Alive,",
        new="            EAGAIN => super::UdsPeek::Closed,",
        red=[
            ("-p caly-uds-peek a_quiet_live_pair_is_alive", False),
        ],
        green=[
            ("-p caly-uds-peek a_dropped_peer_is_closed", True),
        ],
    ),
    dict(
        name="M2 the endpoint regresses to permanent Indeterminate (pre-ADR-059 behavior)",
        file=ENDPOINT_RS,
        old="""        match caly_uds_peek::peek_stream(self) {
            caly_uds_peek::UdsPeek::Closed => Ok(PeerProbe::Closed),
            caly_uds_peek::UdsPeek::Alive => Ok(PeerProbe::Alive),
            caly_uds_peek::UdsPeek::Unknown => Ok(PeerProbe::Indeterminate),
        }""",
        new="""        let _ = caly_uds_peek::peek_stream(self);
        Ok(PeerProbe::Indeterminate)""",
        red=[
            ("-p caly-ipc --test endpoint unix_probe_reports_closed_after_the_peer_drops", False),
            ("-p caly-daemon --test calyd_wire a_uds_stream_client_that_leaves_mid_wait_is_reaped_too", False),
        ],
        green=[
            ("-p caly-ipc --test endpoint tcp_probe_reports_closed_after_the_peer_drops", True),
        ],
    ),
    dict(
        name="M3 the session id counter never advances (both requests carry 1)",
        file=CALY_RS,
        old="""    fn next_request(&mut self) -> u64 {
        let id = self.next_request_id;
        self.next_request_id = self.next_request_id.saturating_add(1);
        id
    }""",
        new="""    fn next_request(&mut self) -> u64 {
        let id = 1;
        self.next_request_id = self.next_request_id.saturating_add(1);
        id
    }""",
        red=[
            (JUDGE_IDS, False),
        ],
        green=[
            ("-p caly-cli --test caly_cli_e2e a_state_gap_end_names_the_cursor_to_resume_with", True),
        ],
    ),
    dict(
        name="M4 the opened-frame correlation check is removed (a stale echo would be followed)",
        file=CALY_RS,
        old="""                if opened_request_id != Some(request_id) {""",
        new="""                if false {""",
        red=[
            (JUDGE_STALE, False),
        ],
        green=[
            (
                "-p caly-cli --test caly_cli_e2e "
                "a_follow_data_and_end_with_the_opened_stream_id_are_accepted",
                True,
            ),
        ],
    ),
    dict(
        name="M5 the daemon spends the connection after a stream ends",
        file=CALYD_RS,
        old="""                                                    write_frame(
                                                        stream,
                                                        KIND_STREAM_END,
                                                        &encode_payload(json_session, &end_records),
                                                    )?;
                                                    break;""",
        new="""                                                    write_frame(
                                                        stream,
                                                        KIND_STREAM_END,
                                                        &encode_payload(json_session, &end_records),
                                                    )?;
                                                    return Ok(());""",
        red=[
            (
                "-p caly-daemon --test calyd_wire "
                "a_connection_serves_a_second_stream_after_the_first_ends",
                False,
            ),
        ],
        green=[
            (
                "-p caly-daemon --test calyd_wire "
                "a_stream_client_that_leaves_mid_wait_is_reaped_within_one_wait_tick",
                True,
            ),
        ],
    ),
    dict(
        name="M6 the CLI hand-spells the operation name (the second request table)",
        file=CALY_RS,
        old="""        &request_payload(request_id, wire.name, &wire.extras, json),""",
        new="""        &request_payload(request_id, "jobs.follow-stream", &wire.extras, json),""",
        red=[
            (JUDGE_TABLE, False),
        ],
        green=[
            (
                "-p caly-cli --test caly_cli_e2e "
                "a_follow_data_and_end_with_the_opened_stream_id_are_accepted",
                True,
            ),
        ],
    ),
]


def main() -> int:
    leftovers: list[str] = []
    for mutation in MUTATIONS:
        path = mutation["file"]
        original = open(path, "rb").read().decode()
        original_sha = hashlib.sha256(original.encode()).hexdigest()
        if mutation["old"] not in original:
            print(f"{mutation['name']}: ANCHOR NOT FOUND (skipped)")
            continue
        mutated = original.replace(mutation["old"], mutation["new"], 1)
        open(path, "w").write(mutated)
        os.utime(path, None)  # immediate mtime bump so the next build relinks
        try:
            verdicts = []
            for name, expect in mutation["red"] + mutation["green"]:
                verdicts.append(test(name, expect))
            reds = verdicts[: len(mutation["red"])]
            greens = verdicts[len(mutation["red"]) :]
            ok = all(v == "RED" for v in reds) and all(v == "GREEN" for v in greens)
            print(
                f"{mutation['name']}: {'BIT' if ok else 'MISSED-BIT'} "
                f"(red={reds} green={greens})"
            )
        finally:
            open(path, "w").write(original)
            os.utime(path, None)
            after_sha = hashlib.sha256(open(path, "rb").read()).hexdigest()
            if after_sha != original_sha:
                leftovers.append(path)
    if leftovers:
        print(f"LEFTOVERS: {leftovers}")
        return 1
    # Relink the restored sources so target/debug carries the pristine binaries.
    build_bins()
    print("leftovers: []")
    return 0


if __name__ == "__main__":
    sys.exit(main())
