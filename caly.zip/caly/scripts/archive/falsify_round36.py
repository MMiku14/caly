"""Falsification harness for round 36 (the caller's context, façade → store, end to end).

Same discipline as rounds 16/32/33/34/35: one mutation per run, one file per mutation,
exact-anchor replacement with `assert count == 1`, restore by content and mtime, sha256-verified,
stale `*.r36bak` swept at startup. A mutation that fails to compile proves nothing (`§4.112`).

The six mutations are `ADR-039 §2` step 4's threading as removals, each aimed at one judge:
the engine answering with its ghost context, the daemon dropping the caller's budget, dropping
the deadline conversion, fabricating the trace, the app method ignoring the context it was
handed -- and a regression guard for the exact bug this round's own judge caught on its first
run (`deadline_ms.or(Some(0))`, the "no deadline becomes expired now" silent policy).

Usage: `python3 scripts/archive/falsify_round36.py` (exit 0 = every mutation bit, every file restored).
"""

import hashlib
import os
import pathlib
import shutil
import subprocess
import sys

ROOT = pathlib.Path("/home/user/caly")
ENV = dict(os.environ)
ENV["PATH"] = str(pathlib.Path.home() / ".cargo/bin") + ":" + ENV.get("PATH", "")
SRC = {
    "engine": ROOT / "crates/caly-engine/src/service.rs",
    "handler": ROOT / "crates/caly-daemon/src/handler.rs",
    "app": ROOT / "crates/caly-daemon/src/app.rs",
}

MUTATIONS = [
    (
        "M1 the engine answers with its ghost context",
        "engine",
        "        run_ready(self.storage.read_object(digest, max_bytes, ctx))?.map_err(|error| error.summary)",
        "        run_ready(self.storage.read_object(digest, max_bytes, &Self::store_ctx()))?\n            .map_err(|error| error.summary)",
        ["a_caller_who_states_a_byte_budget_has_it_enforced_at_the_store"],
    ),
    (
        "M2 the daemon drops the caller's budget",
        "handler",
        """    ctx.io_budget = envelope
        .io_budget
        .clone()
        .unwrap_or_else(caly_common::IoBudget::default_command);""",
        "    ctx.io_budget = caly_common::IoBudget::default_command();",
        ["a_caller_who_states_a_byte_budget_has_it_enforced_at_the_store"],
    ),
    (
        "M3 the daemon drops the deadline conversion",
        "handler",
        """    if let (Some(clock), Some(relative)) = (app.storage_clock_for_deadlines(), envelope.deadline_ms)
    {
        ctx = ctx.with_deadline_from(
            Some(caly_engine::Clock::mono(&*clock).ticks_millis),
            relative,
        );
    }""",
        "    let _ = app.storage_clock_for_deadlines();",
        ["a_caller_who_states_a_deadline_has_it_judged_by_the_injected_clock"],
    ),
    (
        "M4 the daemon fabricates the caller's trace",
        "handler",
        "    let mut ctx = RequestContext::new(envelope.trace_id.clone(), actor);",
        '    let mut ctx = RequestContext::new(caly_common::TraceId::new("daemon"), actor);',
        ["during_the_read_the_port_answers_to_the_caller_not_to_the_engine"],
    ),
    (
        "M5 the app method ignores the context it was handed",
        "app",
        "            .object_payload(digest, SUPPORT_BUNDLE_READ_LIMIT, ctx)?",
        '            .object_payload(digest, SUPPORT_BUNDLE_READ_LIMIT, &caly_api::default_ctx(\n                "ghost",\n                caly_common::Actor::System,\n            ))?',
        ["a_caller_who_states_a_byte_budget_has_it_enforced_at_the_store"],
    ),
    (
        "M6 regression: no deadline becomes expired now",
        "handler",
        "Some(relative)) = (app.storage_clock_for_deadlines(), envelope.deadline_ms)",
        "Some(relative)) = (app.storage_clock_for_deadlines(), envelope.deadline_ms.or(Some(0)))",
        ["a_caller_who_states_neither_budget_nor_deadline_reads_exactly_as_before"],
    ),
]


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def run_cargo():
    proc = subprocess.run(
        ["cargo", "test", "-p", "caly-daemon", "--no-fail-fast"],
        cwd=str(ROOT),
        env=ENV,
        capture_output=True,
        text=True,
    )
    out = proc.stdout + proc.stderr
    failed = sorted(
        {
            line[5:].split(" ... ")[0].split("::")[-1].strip()
            for line in out.splitlines()
            if line.startswith("test ") and line.rstrip().endswith("... FAILED")
        }
    )
    return proc.returncode, failed, out


def main():
    for path in ROOT.rglob("*.r36bak"):
        original = pathlib.Path(str(path)[: -len(".r36bak")])
        shutil.move(str(path), str(original))
        print("swept leftover backup:", path.name)

    originals = {name: digest(path) for name, path in SRC.items()}
    results = []
    bad = False
    for label, key, old, new, expected in MUTATIONS:
        path = SRC[key]
        s = path.read_text()
        assert s.count(old) == 1, "%s: anchor x%d" % (label, s.count(old))
        backup = pathlib.Path(str(path) + ".r36bak")
        shutil.copyfile(path, backup)
        try:
            path.write_text(s.replace(old, new, 1))
            code, failed, out = run_cargo()
            red = [name for name in expected if name in failed]
            compile_error = "error[" in out or "could not compile" in out
            ok = bool(red) and not compile_error
            results.append((label, ok))
            print("%-52s %s  red=%s" % (label, "BIT" if ok else "NO EFFECT", red or failed[:4]))
            if not ok:
                if compile_error:
                    print("   !! the mutation did not compile; it proves nothing")
                print("   output tail:\n", out[-1200:])
        finally:
            shutil.move(str(backup), str(path))
            os.utime(path, None)
            assert digest(path) == originals[key], "%s: restore did not reproduce the file" % label

    print("\n== summary ==")
    for label, ok in results:
        print("%-52s %s" % (label, "bit" if ok else "DID NOT BIT"))
        if not ok:
            bad = True
    print("all mutations bit:", not bad)
    sys.exit(1 if bad else 0)


if __name__ == "__main__":
    main()
