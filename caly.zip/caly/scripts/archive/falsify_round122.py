#!/usr/bin/env python3
"""Round 122 falsify: the shared timeout scheduler owns every transport deadline.

Four mutations break the single-home property from four sides: the handshake phase
applies the wrong window, the probe restores the probe window instead of the live
phase, the server constructor swallows the operator's --session-idle-ms override,
and the CLI bypasses the scheduler with a direct setter call (the second home).

Each mutation rewrites one production file, runs a targeted red/green pair, then
restores byte-for-byte (sha256 + mtime bump). Binary-e2e judges are preceded by an
explicit build of the sibling binaries (round-120 lesson).
"""
import hashlib
import os
import subprocess
import sys

CALY = "/home/user/caly/caly"
TIMEOUT_RS = f"{CALY}/crates/caly-ipc/src/timeout.rs"
CALY_RS = f"{CALY}/crates/caly-cli/src/bin/caly.rs"

JUDGE_CLIENT = "-p caly-ipc --lib timeout::tests::a_client_connection_walks_its_deadline_phases"
JUDGE_SERVER = (
    "-p caly-ipc --lib "
    "timeout::tests::a_server_connection_walks_its_deadline_phases_and_honours_the_idle_flag"
)
JUDGE_PROBE = "-p caly-ipc --lib timeout::tests::a_probe_narrows_the_window_and_restores_the_live_phase"
JUDGE_TABLE = "-p caly-ipc --lib timeout::tests::the_documented_table_is_the_one_production_reads"
JUDGE_HOME = "-p caly-arch-test --test dependency_direction the_transport_deadlines_have_one_home"
JUDGE_UNRELATED_CLI = (
    "-p caly-cli --test caly_cli_e2e a_state_gap_end_names_the_cursor_to_resume_with"
)


def sha(path: str) -> str:
    return hashlib.sha256(open(path, "rb").read()).hexdigest()


def run(*args: str) -> tuple[int, str]:
    proc = subprocess.run(args, cwd=CALY, capture_output=True, text=True, timeout=900)
    return proc.returncode, proc.stdout + proc.stderr


def build_bins() -> None:
    code, out = run(
        "cargo", "build", "-p", "caly-daemon", "--bin", "calyd", "-p", "caly-cli", "--bin", "caly"
    )
    if code != 0:
        sys.exit(f"binaries failed to build:\n{out[-4000:]}")


def test(name: str, expect_ok: bool) -> str:
    build_bins()
    code, out = run("cargo", "test", *name.split())
    if code == 0 and "error[" in out:
        code = 1
    passed = code == 0
    if passed == expect_ok:
        return "GREEN" if expect_ok else "RED"
    return "UNEXPECTED-RED" if expect_ok else "MISSED-BIT"


MUTATIONS = [
    dict(
        name="M1 the handshake phase applies the request window (strangers owed 3s, not 5s)",
        file=TIMEOUT_RS,
        old="""    /// Phase: a stranger owes a fast hello. Both halves (round 90).
    pub fn enter_handshake<T: DeadlineIo + ?Sized>(&mut self, io: &mut T) -> io::Result<()> {
        self.enter(io, HANDSHAKE_TIMEOUT)
    }""",
        new="""    /// Phase: a stranger owes a fast hello. Both halves (round 90).
    pub fn enter_handshake<T: DeadlineIo + ?Sized>(&mut self, io: &mut T) -> io::Result<()> {
        self.enter(io, REQUEST_TIMEOUT)
    }""",
        red=[
            (JUDGE_CLIENT, False),
            (JUDGE_SERVER, False),
        ],
        green=[
            # The probe judge enters session/stream phases directly; the handshake
            # window is not its stake.
            (JUDGE_PROBE, True),
        ],
    ),
    dict(
        name="M2 the probe restores the probe window, not the live phase",
        file=TIMEOUT_RS,
        old="""        // Restore to the live phase, both halves (read was narrowed; write is set again
        // idempotently so there is exactly one application path).
        let phase = self.phase;
        io.apply_deadline(Some(phase))?;""",
        new="""        // Restore to the live phase, both halves (read was narrowed; write is set again
        // idempotently so there is exactly one application path).
        io.apply_deadline(Some(PROBE_WINDOW))?;""",
        red=[
            # The recorded sequence must be [50ms, phase] on read and [phase] on write;
            # restoring the probe window leaves the connection on a 50ms deadline.
            (JUDGE_PROBE, False),
        ],
        green=[
            (JUDGE_TABLE, True),
        ],
    ),
    dict(
        name="M3 the server constructor swallows the --session-idle-ms override",
        file=TIMEOUT_RS,
        old="""    pub fn server(session_idle: Duration) -> Self {
        Self {
            session_idle,
            phase: HANDSHAKE_TIMEOUT,
        }
    }""",
        new="""    pub fn server(session_idle: Duration) -> Self {
        Self {
            session_idle: DEFAULT_SESSION_IDLE,
            phase: HANDSHAKE_TIMEOUT,
        }
    }""",
        red=[
            # The judge builds the scheduler with a 7s session idle and demands the
            # override lands on the wire deadlines; a swallowed flag is a silent no-op.
            (JUDGE_SERVER, False),
        ],
        green=[
            (JUDGE_CLIENT, True),
        ],
    ),
    dict(
        name="M4 the CLI bypasses the scheduler with a direct setter call (the second home)",
        file=CALY_RS,
        old="""        self.timeouts
            .enter_stream(&mut self.pump)
            .map_err(|error| format!("set stream transport timeouts: {error}"))""",
        new="""        self.pump
            .set_idle(Some(caly_ipc::STREAM_IDLE_TIMEOUT))
            .map_err(|error| format!("set stream transport timeouts: {error}"))""",
        red=[
            # The single-home gate: a direct setter call in a speaker's production
            # code is a second home, even when the value it applies is right.
            (JUDGE_HOME, False),
        ],
        green=[
            # Behavior is unchanged by the bypass (same value, same halves) — an
            # unrelated CLI judge proves the tree still runs.
            (JUDGE_UNRELATED_CLI, True),
        ],
    ),
]


def main() -> int:
    leftovers: list[str] = []
    for mutation in MUTATIONS:
        path = mutation["file"]
        original = open(path, "rb").read().decode()
        original_sha = hashlib.sha256(original.encode()).hexdigest()
        if mutation["old"] not in original:
            print(f"{mutation['name']}: ANCHOR NOT FOUND (skipped)")
            continue
        mutated = original.replace(mutation["old"], mutation["new"], 1)
        open(path, "w").write(mutated)
        os.utime(path, None)  # immediate mtime bump so the next build relinks
        try:
            verdicts = []
            for name, expect in mutation["red"] + mutation["green"]:
                verdicts.append(test(name, expect))
            reds = verdicts[: len(mutation["red"])]
            greens = verdicts[len(mutation["red"]) :]
            ok = all(v == "RED" for v in reds) and all(v == "GREEN" for v in greens)
            print(
                f"{mutation['name']}: {'BIT' if ok else 'MISSED-BIT'} "
                f"(red={reds} green={greens})"
            )
        finally:
            open(path, "w").write(original)
            os.utime(path, None)
            after_sha = hashlib.sha256(open(path, "rb").read()).hexdigest()
            if after_sha != original_sha:
                leftovers.append(path)
    if leftovers:
        print(f"LEFTOVERS: {leftovers}")
        return 1
    # Relink the restored sources so target/debug carries the pristine binaries.
    build_bins()
    print("leftovers: []")
    return 0


if __name__ == "__main__":
    sys.exit(main())
