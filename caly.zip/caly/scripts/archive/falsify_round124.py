#!/usr/bin/env python3
"""Round 124 falsify: the graceful-drain stop sequence (ADR-056 addendum).

Three mutations break the sequence from three sides: the drain loop is skipped
(in-flight sessions are cut at the signal), the listener stays open during the
drain (new clients are still accepted while shutting down), and the drain window
is zeroed in the shared policy table.

Each mutation rewrites one production file, runs a targeted red/green pair, then
restores byte-for-byte (sha256 + mtime bump). Binary-e2e judges are preceded by
an explicit build of the sibling binaries (round-120 lesson).
"""
import hashlib
import os
import subprocess
import sys

CALY = "/home/user/caly/caly"
CALYD_RS = f"{CALY}/crates/caly-daemon/src/bin/calyd.rs"
TIMEOUT_RS = f"{CALY}/crates/caly-ipc/src/timeout.rs"

JUDGE_DRAIN = (
    "-p caly-daemon --test calyd_wire a_sigterm_drains_the_inflight_session_and_refuses_new_clients"
)
JUDGE_EXIT0 = "-p caly-daemon --test calyd_wire sigterm_shuts_calyd_down_gracefully_with_exit_zero"
JUDGE_TABLE = "-p caly-ipc --lib timeout::tests::the_documented_table_is_the_one_production_reads"


def sha(path: str) -> str:
    return hashlib.sha256(open(path, "rb").read()).hexdigest()


def run(*args: str) -> tuple[int, str]:
    proc = subprocess.run(args, cwd=CALY, capture_output=True, text=True, timeout=900)
    return proc.returncode, proc.stdout + proc.stderr


def build_bins() -> None:
    code, out = run(
        "cargo", "build", "-p", "caly-daemon", "--bin", "calyd", "-p", "caly-cli", "--bin", "caly"
    )
    if code != 0:
        sys.exit(f"binaries failed to build:\n{out[-4000:]}")


def test(name: str, expect_ok: bool) -> str:
    build_bins()
    code, out = run("cargo", "test", *name.split())
    if code == 0 and "error[" in out:
        code = 1
    passed = code == 0
    if passed == expect_ok:
        return "GREEN" if expect_ok else "RED"
    return "UNEXPECTED-RED" if expect_ok else "MISSED-BIT"


MUTATIONS = [
    dict(
        name="M1 the drain loop is skipped (sessions are cut at the signal)",
        file=CALYD_RS,
        old="""    let ticks = u64::try_from(caly_ipc::SHUTDOWN_DRAIN.as_millis()).unwrap_or(3_000) / 20;
    for _ in 0..ticks {
        connections.retain(|handle| !handle.is_finished());
        if connections.is_empty() {
            break;
        }
        std::thread::sleep(std::time::Duration::from_millis(20));
    }""",
        new="""    let ticks = u64::try_from(caly_ipc::SHUTDOWN_DRAIN.as_millis()).unwrap_or(3_000) / 20;
    let _ = ticks;""",
        red=[
            (JUDGE_DRAIN, False),
        ],
        green=[
            # The clean-stop exit is unchanged by skipping the drain.
            (JUDGE_EXIT0, True),
        ],
    ),
    dict(
        name="M2 the listener stays open during the drain (new clients still accepted)",
        file=CALYD_RS,
        old="""    drop(listener);
    connections.retain(|handle| !handle.is_finished());""",
        new="""    connections.retain(|handle| !handle.is_finished());""",
        red=[
            # The refused-new-clients poll times out: connects keep succeeding.
            (JUDGE_DRAIN, False),
        ],
        green=[
            (JUDGE_EXIT0, True),
        ],
    ),
    dict(
        name="M3 the drain window is zeroed in the shared table",
        file=TIMEOUT_RS,
        old="""pub const SHUTDOWN_DRAIN: Duration = Duration::from_secs(3);""",
        new="""pub const SHUTDOWN_DRAIN: Duration = Duration::from_secs(0);""",
        red=[
            # The table judge pins the value AND its request-sized relation.
            (JUDGE_TABLE, False),
        ],
        green=[
            ("-p caly-ipc --lib timeout::tests::a_probe_narrows_the_window_and_restores_the_live_phase", True),
        ],
    ),
]


def main() -> int:
    leftovers: list[str] = []
    for mutation in MUTATIONS:
        path = mutation["file"]
        original = open(path, "rb").read().decode()
        original_sha = hashlib.sha256(original.encode()).hexdigest()
        if mutation["old"] not in original:
            print(f"{mutation['name']}: ANCHOR NOT FOUND (skipped)")
            continue
        mutated = original.replace(mutation["old"], mutation["new"], 1)
        open(path, "w").write(mutated)
        os.utime(path, None)  # immediate mtime bump so the next build relinks
        try:
            verdicts = []
            for name, expect in mutation["red"] + mutation["green"]:
                verdicts.append(test(name, expect))
            reds = verdicts[: len(mutation["red"])]
            greens = verdicts[len(mutation["red"]) :]
            ok = all(v == "RED" for v in reds) and all(v == "GREEN" for v in greens)
            print(
                f"{mutation['name']}: {'BIT' if ok else 'MISSED-BIT'} "
                f"(red={reds} green={greens})"
            )
        finally:
            open(path, "w").write(original)
            os.utime(path, None)
            after_sha = hashlib.sha256(open(path, "rb").read()).hexdigest()
            if after_sha != original_sha:
                leftovers.append(path)
    if leftovers:
        print(f"LEFTOVERS: {leftovers}")
        return 1
    # Relink the restored sources so target/debug carries the pristine binaries.
    build_bins()
    print("leftovers: []")
    return 0


if __name__ == "__main__":
    sys.exit(main())
