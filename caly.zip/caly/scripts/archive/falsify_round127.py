#!/usr/bin/env python3
"""Round 127 falsify: SnapshotThenPatch watch streams and the bounded producer.

Five mutations break the contract from five sides: the snapshot never emits (the old
behaviour), the snapshot renders a second divergent copy of the status facts, the per-pull
bound disappears, the slow-client reset is swallowed into silence, and the snapshot
repeats on every pull (the patch stream never starts).

Each mutation rewrites one production file, runs a targeted red/green pair, then restores
byte-for-byte (sha256 + mtime bump). RED verdicts carry the compiled-guard (a compile
error is not a red).
"""
import hashlib
import os
import subprocess
import sys

CALY = "/home/user/caly/caly"
SESSION = f"{CALY}/crates/caly-daemon/src/session.rs"
STREAM = f"{CALY}/crates/caly-daemon/src/stream.rs"
BRIDGE = f"{CALY}/crates/caly-daemon/src/watch_bridge.rs"

T = "-p caly-daemon --test watch_snapshot_stream"
J_SNAPSHOT = f"{T} a_dashboard_watch_opens_with_one_snapshot_frame_mid_flight"
J_PATCHES = f"{T} after_the_snapshot_only_new_events_arrive_as_patches"
J_CONN = f"{T} a_connections_watch_opens_with_the_connections_page_as_its_snapshot"
J_BOUNDED = f"{T} a_long_backlog_is_served_in_bounded_pulls_with_nothing_lost_or_repeated"
J_RESET = f"{T} a_client_that_falls_behind_retention_gets_a_named_reset"


def run(*args: str) -> tuple[int, str]:
    proc = subprocess.run(args, cwd=CALY, capture_output=True, text=True, timeout=900)
    return proc.returncode, proc.stdout + proc.stderr


def test(name: str, expect_ok: bool) -> str:
    code, out = run("cargo", "test", *name.split(), "--", "--test-threads=1")
    compiled = "error[" not in out and "error: " not in out
    passed = code == 0 and compiled
    if passed == expect_ok:
        return "GREEN" if expect_ok else "RED"
    verdict = "UNEXPECTED-RED" if expect_ok else "MISSED-BIT"
    tail = "\n".join(out.splitlines()[-12:])
    print(f"    [{verdict}] {name}\n    --------\n{tail}\n    --------")
    return verdict


MUTATIONS = [
    dict(
        name="M1 the snapshot never emits (the pre-round behaviour)",
        file=SESSION,
        old="""        let snapshot_due = matches!(&opened.opened.source, StreamSource::RuntimeSubscription(_))
            && is_snapshot_then_patch(opened.opened.kind)
            && effective_from.is_none();""",
        new="""        let snapshot_due = false
            && matches!(&opened.opened.source, StreamSource::RuntimeSubscription(_))
            && is_snapshot_then_patch(opened.opened.kind)
            && effective_from.is_none();""",
        red=[(J_SNAPSHOT, False)],
        green=[(J_BOUNDED, True)],
    ),
    dict(
        name="M2 the snapshot renders a second, divergent copy of the status facts",
        file=STREAM,
        old="""    let none = String::new;
    vec![
        ("core_running".to_owned(), status.core_running.to_string()),""",
        new="""    let none = String::new;
    vec![
        ("running".to_owned(), status.core_running.to_string()),""",
        red=[(J_SNAPSHOT, False)],
        green=[(J_RESET, True)],
    ),
    dict(
        name="M3 the per-pull bound disappears",
        file=SESSION,
        old="""                    frames.truncate(MAX_WATCH_FRAMES_PER_PULL);
                    frames""",
        new="""                    let _ = MAX_WATCH_FRAMES_PER_PULL;
                    frames""",
        red=[(J_BOUNDED, False)],
        green=[(J_SNAPSHOT, True)],
    ),
    dict(
        name="M4 the slow-client reset is swallowed into silence",
        file=BRIDGE,
        old="""    if followed.reset_required {
        return Ok(vec![StreamFrame {
            stream_id: request.stream_id,
            seq: followed.next_seq,
            kind: request.kind,
            payload: StreamPayload::Reset {
                reason: ResetReason::StateGapTooLarge,
            },
        }]);
    }

    let mut frames = Vec::new();
    for event in followed.events {""",
        new="""    if followed.reset_required {
        return Ok(Vec::new());
    }

    let mut frames = Vec::new();
    for event in followed.events {""",
        red=[(J_RESET, False)],
        green=[(J_SNAPSHOT, True)],
    ),
    dict(
        name="M5 the resume cursor is ignored, so the snapshot repeats every pull",
        file=STREAM,
        old="""            AckPolicy::Required | AckPolicy::Optional => self.acked_upto.or(self.last_emitted_seq),""",
        new="""            AckPolicy::Required => self.acked_upto.or(self.last_emitted_seq),
            AckPolicy::Optional => None,""",
        red=[(J_PATCHES, False)],
        green=[(J_CONN, True)],
    ),
]


def main() -> int:
    leftovers: list[str] = []
    for mutation in MUTATIONS:
        path = mutation["file"]
        original = open(path, "rb").read().decode()
        original_sha = hashlib.sha256(original.encode()).hexdigest()
        if mutation["old"] not in original:
            print(f"{mutation['name']}: ANCHOR NOT FOUND (skipped)")
            continue
        mutated = original.replace(mutation["old"], mutation["new"], 1)
        open(path, "w").write(mutated)
        os.utime(path, None)
        try:
            verdicts = []
            for name, expect in mutation["red"] + mutation["green"]:
                verdicts.append(test(name, expect))
            reds = verdicts[: len(mutation["red"])]
            greens = verdicts[len(mutation["red"]) :]
            ok = all(v == "RED" for v in reds) and all(v == "GREEN" for v in greens)
            print(
                f"{mutation['name']}: {'BIT' if ok else 'MISSED-BIT'} "
                f"(red={reds} green={greens})"
            )
        finally:
            open(path, "w").write(original)
            os.utime(path, None)
            if hashlib.sha256(open(path, "rb").read()).hexdigest() != original_sha:
                leftovers.append(path)
    if leftovers:
        print(f"LEFTOVERS: {leftovers}")
        return 1
    print("leftovers: []")
    return 0


if __name__ == "__main__":
    sys.exit(main())
