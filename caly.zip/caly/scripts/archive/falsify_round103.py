#!/usr/bin/env python3
"""Round 103 falsification harness.

Target property: `caly follow <id> --json` exits by the stream's verdict, not an unconditional
success. Before R103 the STREAM_END json branch printed the payload then `return
Ok(ExitCode::Success)` regardless of outcome (the human render mapped Succeeded/Failed/
Cancelled/TimedOut; json diverged), so a failed job followed with --json reported exit 0
(docs/guides/EXIT_CODES.md §1.4: --json changes the rendering, not the exit semantics).

Judges:
  - e2e a_json_follow_of_a_failed_job_exits_nonzero_like_the_human_render (json Failed -> exit 1);
  - e2e a_json_follow_of_a_succeeded_job_stays_exit_zero (json Succeeded -> exit 0, anti-vacuity);
  - arch gate the_follow_stream_end_exit_code_is_shared_between_json_and_records.

Mutations (rebuilt; a judge must go red):
  M1 restore the json short-circuit: after the json `println!`, return Success before the shared
     verdict. Bites the FAILED e2e (gets 0 not 1) and the gate (no `return stream_end_exit_code`).
     The SUCCEEDED e2e stays green (it expected 0 anyway), proving M1 only disables the verdict.
  M2 delete the shared verdict call (replace with unconditional Success on both paths). Bites the
     FAILED e2e and the gate (the `return stream_end_exit_code(&records);` form disappears).

Restoration is content sha256-verified. cwd = workspace root.
"""

import hashlib
import pathlib
import shutil
import subprocess
import sys

ROOT = pathlib.Path(__file__).resolve().parents[1]
BIN = ROOT / "crates/caly-cli/src/bin/caly.rs"
SUFFIX = ".r103bak"

FAILED_E2E = "a_json_follow_of_a_failed_job_exits_nonzero_like_the_human_render ... FAILED"
SUCC_E2E = "a_json_follow_of_a_succeeded_job_stays_exit_zero ... FAILED"
GATE = "the_follow_stream_end_exit_code_is_shared_between_json_and_records ... FAILED"


def sha256(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def run_e2e():
    proc = subprocess.run(
        ["cargo", "test", "-p", "caly-cli", "--test", "caly_cli_e2e", "a_json_follow"],
        cwd=ROOT, capture_output=True, text=True,
    )
    return proc.stdout + proc.stderr


def run_gate():
    proc = subprocess.run(
        ["cargo", "test", "-p", "caly-arch-test", "--test", "dependency_direction",
         "the_follow_stream_end_exit_code"],
        cwd=ROOT, capture_output=True, text=True,
    )
    return proc.stdout + proc.stderr


def main():
    digest = sha256(BIN)
    bak = BIN.with_name(BIN.name + SUFFIX)
    shutil.copy2(str(BIN), str(bak))
    base = bak.read_text()
    ok = True
    try:
        # M1: json path returns Success right after printing, before the shared verdict.
        m1_anchor = """                if json {
                    println!("{}", String::from_utf8_lossy(&payload));
                }"""
        m1_repl = """                if json {
                    println!("{}", String::from_utf8_lossy(&payload));
                    return Ok(ExitCode::Success);
                }"""
        assert base.count(m1_anchor) == 1, "M1 anchor not found"
        m1 = base.replace(m1_anchor, m1_repl)
        BIN.write_text(m1)
        out = run_e2e()
        ok &= (FAILED_E2E in out) and (print("  BIT  [M1 json short-circuit]: FAILED e2e went red") or True)
        if FAILED_E2E not in out:
            print("  FAIL [M1 json short-circuit]: FAILED e2e stayed green"); ok = False
        if SUCC_E2E in out:
            print("  FAIL [M1 json short-circuit]: SUCCEEDED e2e unexpectedly red (should stay 0)"); ok = False
        else:
            print("  ok   [M1 json short-circuit]: SUCCEEDED e2e still green (verdict-only change)")
        gout = run_gate()
        if GATE in gout:
            print("  BIT  [M1 json short-circuit]: gate went red")
        else:
            print("  FAIL [M1 json short-circuit]: gate stayed green"); ok = False

        # M2: remove the shared verdict call entirely (both paths become Success).
        m2_anchor = "                return stream_end_exit_code(&records);"
        assert base.count(m2_anchor) == 1, "M2 anchor not found"
        m2 = base.replace(m2_anchor, "                return Ok(ExitCode::Success);")
        BIN.write_text(m2)
        out = run_e2e()
        if FAILED_E2E in out:
            print("  BIT  [M2 no-shared-verdict]: FAILED e2e went red")
        else:
            print("  FAIL [M2 no-shared-verdict]: FAILED e2e stayed green"); ok = False
        gout = run_gate()
        if GATE in gout:
            print("  BIT  [M2 no-shared-verdict]: gate went red")
        else:
            print("  FAIL [M2 no-shared-verdict]: gate stayed green"); ok = False
    finally:
        shutil.move(str(bak), str(BIN))
        got = sha256(BIN)
        assert got == digest, f"restore mismatch: {got} != {digest}"

    if not ok:
        print("ROUND 103 FALSIFICATION: RED (a mutation was not caught)")
        sys.exit(1)
    print("ROUND 103 FALSIFICATION: all mutations BIT; restore sha256-verified.")


if __name__ == "__main__":
    main()
