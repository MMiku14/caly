#!/usr/bin/env python3
"""Round 120 falsify: real-core deployment follow/resume user-plane e2e (P2 slice).

Each mutation rewrites one production file, runs a targeted red/green test pair,
then restores the file byte-for-byte (sha256 + immediate mtime bump, per the
round-112 lesson: the next mutation must relink the poisoned binary).

Round-120 difference from round 119: the judges are binary e2e — they spawn the
sibling `calyd`/`caly` binaries out of target/debug, which `cargo test` does NOT
build as a test dependency. So every test run is preceded by an explicit
`cargo build` of both binaries (also the round-120 onboarding lesson).

Note: this archive script lives with the round that wrote it; the repo root is
/home/user/caly/caly (the zip ships a nested caly/ directory).
"""
import hashlib
import os
import subprocess
import sys

CALY = "/home/user/caly/caly"
CALYD_RS = f"{CALY}/crates/caly-daemon/src/bin/calyd.rs"
JOB_STREAM_RS = f"{CALY}/crates/caly-daemon/src/job_stream.rs"
CALY_RS = f"{CALY}/crates/caly-cli/src/bin/caly.rs"

JUDGE_APPLY = (
    "-p caly-cli --test caly_cli_e2e "
    "an_apply_wait_streams_a_real_core_deployment_with_the_cores_own_identity"
)
JUDGE_RESUME = (
    "-p caly-cli --test caly_cli_e2e "
    "a_resume_after_a_zero_ack_disconnect_replays_the_whole_real_deployment"
)


def sha(path: str) -> str:
    return hashlib.sha256(open(path, "rb").read()).hexdigest()


def run(*args: str) -> tuple[int, str]:
    proc = subprocess.run(args, cwd=CALY, capture_output=True, text=True, timeout=900)
    return proc.returncode, proc.stdout + proc.stderr


def build_bins() -> None:
    code, out = run(
        "cargo", "build", "-p", "caly-daemon", "--bin", "calyd", "-p", "caly-cli", "--bin", "caly"
    )
    if code != 0:
        sys.exit(f"binaries failed to build:\n{out[-4000:]}")


def test(name: str, expect_ok: bool) -> str:
    build_bins()
    code, out = run("cargo", "test", *name.split())
    if code == 0 and "error[" in out:
        code = 1
    passed = code == 0
    if passed == expect_ok:
        return "GREEN" if expect_ok else "RED"
    return "UNEXPECTED-RED" if expect_ok else "MISSED-BIT"


MUTATIONS = [
    dict(
        name="M1 the daemon silently falls back to the simulated runtime under --effect-runtime real",
        file=CALYD_RS,
        old="""    let effects = effects_runtime
        .clone()
        .map(|runtime| runtime as Arc<dyn caly_engine::EffectRuntime>);""",
        new="""    let effects = None;""",
        red=[
            # The identity probe must carry the pinned core's own /version answer;
            # the simulated identity observation (`core.identity simulated`) never
            # carries a version. Deployment "succeeds" in sim — only the evidence
            # line catches the silent fallback.
            (JUDGE_APPLY, False),
        ],
        green=[
            # The resume replay contract holds in either world; this judge has no
            # stake in which runtime served the deployment.
            (JUDGE_RESUME, True),
        ],
    ),
    dict(
        name="M2 the CLI drops the --resume wiring (the flag parses but never reaches the wire)",
        file=CALY_RS,
        old="""    let stream_request = match (resume, job_id) {""",
        new="""    let stream_request = match (None::<&str>, job_id) {""",
        red=[
            # `caly follow --resume N` now hits the (None, None) usage arm: exit 2
            # instead of 0 + `resumed=true`.
            (JUDGE_RESUME, False),
        ],
        green=[
            # The apply --wait path never uses --resume.
            (JUDGE_APPLY, True),
        ],
    ),
    dict(
        name="M4 the daemon treats a zero-ack disconnect as 'already received' (replay skips ahead)",
        file=CALYD_RS,
        # First attempt mutated the request's `from_event_index` — it missed: the
        # replay start is the (job_id, from) pair the pump keeps in `stream_job`
        # (the WatchOpened handler replays from it), not the request field. The
        # registry entry's `acked` IS the replay fact; poisoning it is the bite.
        old="""                        stream_job = Some((entry.job_id, entry.acked));""",
        new="""                        stream_job = Some((entry.job_id, entry.acked.or(Some(1))));""",
        red=[
            # The vanished client confirmed nothing; the replay must be the whole
            # window. Skipping event 0 breaks line-for-line equality with a fresh
            # follow of the same job.
            (JUDGE_RESUME, False),
        ],
        green=[
            # A fresh open never goes through the resume arm.
            (JUDGE_APPLY, True),
        ],
    ),
    dict(
        name="M5 the pump cursor regresses to the live edge (the round-120 loss, restored)",
        file=JOB_STREAM_RS,
        old="""            let next = page
                .next_from_event_index
                .unwrap_or(page.next_event_index.saturating_sub(1));""",
        new="""            let next = page
                .next_from_event_index
                .unwrap_or(page.next_event_index);""",
        red=[
            # The unit judge pins the cursor polarity deterministically: a page that
            # ran to the live edge must cursor at the LAST delivered index, or the
            # next exclusive read skips the first event that lands after it.
            (
                "-p caly-daemon --lib job_stream a_live_edge_page_cursors_at_the_last_delivered_index",
                False,
            ),
        ],
        green=[
            # The empty-first-page path is not this mutation's bite; that judge
            # stays green so the red above is specific.
            (
                "-p caly-cli --test caly_cli_e2e a_stream_opened_before_the_first_event_still_delivers_it",
                True,
            ),
        ],
    ),
    dict(
        name="M6 an empty first page seeds the cursor at the retained edge (skips event 0)",
        file=JOB_STREAM_RS,
        old="""        // An empty page sets NO cursor: nothing has been delivered, so the next read starts
        // from the open position again (a fresh open's start; a resume's acked position).
        // Seeding the window's retained edge here would make the next exclusive read skip
        // that very event once it exists — the exact loss this round closed.
        if !page.events.is_empty() {""",
        new="""        if self.cursor.is_none() {
            self.cursor = Some(page.retained_from_event_index);
        }
        if !page.events.is_empty() {""",
        red=[
            # The stream provably opens on an empty, still-running window (worker tick
            # widened to 2s), so the first event arrives AFTER the first (empty) page —
            # the seeded cursor makes the next exclusive read skip it, every time.
            (
                "-p caly-cli --test caly_cli_e2e a_stream_opened_before_the_first_event_still_delivers_it",
                False,
            ),
            (
                "-p caly-daemon --lib job_stream an_empty_page_leaves_the_cursor_alone",
                False,
            ),
        ],
        green=[
            # The apply --wait path on an idle daemon replays a terminal window in one
            # page; the seed never engages there.
            (JUDGE_APPLY, True),
        ],
    ),
]


def main() -> int:
    leftovers: list[str] = []
    for mutation in MUTATIONS:
        path = mutation["file"]
        original = open(path, "rb").read().decode()
        original_sha = hashlib.sha256(original.encode()).hexdigest()
        if mutation["old"] not in original:
            print(f"{mutation['name']}: ANCHOR NOT FOUND (skipped)")
            continue
        mutated = original.replace(mutation["old"], mutation["new"], 1)
        open(path, "w").write(mutated)
        os.utime(path, None)  # immediate mtime bump so the next build relinks
        try:
            verdicts = []
            for name, expect in mutation["red"] + mutation["green"]:
                verdicts.append(test(name, expect))
            reds = verdicts[: len(mutation["red"])]
            greens = verdicts[len(mutation["red"]) :]
            ok = all(v == "RED" for v in reds) and all(v == "GREEN" for v in greens)
            print(
                f"{mutation['name']}: {'BIT' if ok else 'MISSED-BIT'} "
                f"(red={reds} green={greens})"
            )
        finally:
            open(path, "w").write(original)
            os.utime(path, None)
            after_sha = hashlib.sha256(open(path, "rb").read()).hexdigest()
            if after_sha != original_sha:
                leftovers.append(path)
    if leftovers:
        print(f"LEFTOVERS: {leftovers}")
        return 1
    # Relink the restored sources so target/debug carries the pristine binaries.
    build_bins()
    print("leftovers: []")
    return 0


if __name__ == "__main__":
    sys.exit(main())
