#!/usr/bin/env python3
"""Round 73 falsification harness.

The claim under test (`ADR-053`, RFC-0010 §11.1 SSRF 网络访问边界): a `Direct` fetch with
the conservative `Default` scope is rejected **after connect and before any byte is written**
when the peer the connection reached is loopback/link-local-metadata/private — named as
`PermissionDenied` with the policy and class. The judge is
`caly-io-std/tests/http_contract.rs`:

- `the_default_scope_refuses_a_loopback_peer_by_name` (PermissionDenied + 0 bytes at server)
- `an_explicit_any_peer_scope_allows_a_loopback_peer` (opt-in passes the boundary)
- `peer_address_classification_covers_the_rfc_partition` (the RFC §11.1 partition, pinned)

- M1 (must bite)  the post-connect check is dropped — the loopback fetch succeeds and writes
      a request, and the refusal judge's 0-bytes assertion fails.
- M2 (must bite)  the classifier calls 127.0.0.0/8 `Public` — the partition judge and the
      refusal judge both fail.

Usage: `python3 scripts/archive/falsify_round73.py` (exit 0 = both bit, files restored).
"""

import hashlib
import os
import pathlib
import subprocess
import sys
import time

ROOT = pathlib.Path("/home/user/caly_extract/caly")
ENV = dict(os.environ)
ENV["PATH"] = str(pathlib.Path.home() / ".cargo/bin") + ":" + ENV.get("PATH", "")

HTTP = ROOT / "crates/caly-io-std/src/http.rs"

M1_OLD = "            if !exempt_from_peer_check {"
M1_NEW = "            if false && !exempt_from_peer_check {"

M2_OLD = "            if octets[0] == 127 {"
M2_NEW = "            if octets[0] == 127 && false {"

JUDGE = [
    "-p", "caly-io-std", "--test", "http_contract",
    "the_default_scope_refuses_a_loopback_peer_by_name",
]
JUDGE2 = [
    "-p", "caly-io-std", "--test", "http_contract",
    "peer_address_classification_covers_the_rfc_partition",
]


def digest(path):
    return hashlib.sha256(pathlib.Path(path).read_bytes()).hexdigest()


def sweep_strays():
    for path in ROOT.rglob("*.r73bak"):
        print(f"  note  sweeping stale {path}")
        path.unlink()


def run_judge(args):
    begin = time.time()
    proc = subprocess.run(
        ["cargo", "test"] + args,
        cwd=ROOT,
        env=ENV,
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
        text=True,
        timeout=300,
    )
    return proc, time.time() - begin


def main():
    original = HTTP.read_text()
    all_ok = True
    try:
        for label, old, new, judge in [
            ("M1 the post-connect check is dropped (must bite)", M1_OLD, M1_NEW, JUDGE),
            ("M2 127.0.0.0/8 is classified Public (must bite)", M2_OLD, M2_NEW, JUDGE2),
        ]:
            if HTTP.read_text() != original:
                print(f"  FAIL  {label}: tree is dirty before mutation")
                all_ok = False
                break
            if old not in original:
                print(f"  FAIL  {label}: anchor not found — pattern drifted")
                all_ok = False
                break
            backup = ROOT / ".r73bak"
            backup.write_bytes(HTTP.read_bytes())
            HTTP.write_text(HTTP.read_text().replace(old, new, 1))
            proc, elapsed = run_judge(judge)
            if proc.returncode != 0 and "error[E" not in proc.stdout:
                print(f"  ok    {label} (bite in {elapsed:.1f}s)")
            elif "error[E" in proc.stdout:
                print(f"  FAIL  {label}: compiler error, not a property failure ({elapsed:.1f}s)")
                all_ok = False
            else:
                print(f"  FAIL  {label}: judge stayed green ({elapsed:.1f}s)")
                all_ok = False
            HTTP.write_bytes(backup.read_bytes())
            backup.unlink()
            if HTTP.read_text() != original:
                print(f"  FAIL  {label}: restore mismatch")
                all_ok = False
    finally:
        sweep_strays()
        if HTTP.read_text() != original:
            HTTP.write_text(original)
            print("  note  hard-restored http.rs")

    if all_ok:
        print("all mutations behaved as predicted: True")
        return 0
    print("all mutations behaved as predicted: False")
    return 1


if __name__ == "__main__":
    sys.exit(main())
