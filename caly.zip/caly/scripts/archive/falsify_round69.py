#!/usr/bin/env python3
"""Round 69 falsification harness.

The claim under test (`IMPLEMENTATION_STATUS §8.4` "RuntimeDriver identity/telemetry"): a
real apply's plan ends with `CoreIdentity` + `TelemetryTraffic` probes whose evidence comes
from the LIVE core — `GET /version`'s self-reported version next to the kind the plan
spawned (`probe.core-identity kind=… version=…`), and the core's OWN cumulative counters
(`probe.telemetry-traffic upload_total=… download_total=…` from `/connections`). The judge
is `real_apply::the_applied_core_names_itself_and_counts_its_own_traffic` (both real cores):
it asserts the evidence in the job log AND that a fetch through the core moves the counters
it can read back through the production parse path.

- M1 (must bite)  the identity probe stops reading `/version` and hardcodes a version —
      "answered" is not "identified", and a 200-ok skeleton must not pass.
- M2 (must bite)  the counters stop being the core's — `controller_totals` returns (0,0) —
      the after-fetch increase assertion must fail, and the hardcoded baseline must be
      visible in the probe evidence.
- M3 (must bite)  the mihomo plan drops the CoreIdentity step — the mihomo half of the
      judge finds no identity evidence at all.
- M4 (must bite)  the sing-box plan drops the TelemetryTraffic step — the sing-box half of
      the judge finds no telemetry evidence at all.

Sim-side parity is NOT mutated here on purpose: the sim arms are compiler-exhaustive (a
removed arm is an `error[E`), and the simulator keeps no counters, so a value-level
mutation there would be testing a constant, not a property.

Usage: `python3 scripts/archive/falsify_round69.py` (exit 0 = all four bit, files restored).
"""

import hashlib
import os
import pathlib
import subprocess
import sys
import time

ROOT = pathlib.Path("/home/user/caly_extract/caly")
ENV = dict(os.environ)
ENV["PATH"] = str(pathlib.Path.home() / ".cargo/bin") + ":" + ENV.get("PATH", "")

JUDGE = "the_applied_core_names_itself_and_counts_its_own_traffic"

EFFECT_STD = ROOT / "crates/caly-daemon/src/effect_std.rs"
MIHOMO_ADAPTER = ROOT / "crates/caly-mihomo/src/adapter.rs"
SINGBOX_ADAPTER = ROOT / "crates/caly-singbox/src/adapter.rs"

# M1: the CoreIdentity arm stops reading /version and hardcodes a version.
M1_OLD = """                    let version = self.controller_version(port).map_err(|reason| {
                        StepFailure::new(
                            "core-identity-unreadable",
                            format!(
                                "the controller on 127.0.0.1:{port} answered but its identity \\
                                 could not be read: {reason}"
                            ),
                            false,
                        )
                    })?;"""
M1_NEW = """                    let version = "0.0.0-not-the-core".to_owned();"""

# M2: the counters stop being the core's — always (0, 0).
M2_OLD = """        let upload = body
            .get("uploadTotal")
            .and_then(|value| value.as_u64())
            .ok_or_else(|| "no u64 `uploadTotal`".to_owned())?;
        let download = body
            .get("downloadTotal")
            .and_then(|value| value.as_u64())
            .ok_or_else(|| "no u64 `downloadTotal`".to_owned())?;
        Ok((upload, download))"""
M2_NEW = """        let _ = body.get("uploadTotal");
        Ok((0, 0))"""

# M3: the mihomo plan drops the CoreIdentity probe step (comment + push, unique in file).
M3_OLD = """    // Round 69 (`IMPLEMENTATION_STATUS §8.4`): `ApiReady` proved the controller answers;
    // this probe names what the plan spawned. The real backend reads `GET /version` so the
    // evidence carries the core's self-reported version (`probe.core-identity kind=…
    // version=…`) — a 200 with an unreadable body is a refusal, not an identity.
    steps.push(EffectStep::Probe {
        probe: ProbeSpec {
            kind: ProbeKind::CoreIdentity,
            target: None,
        },
        deadline_ms: 3_000,
    });
"""
M3_NEW = ""

# M4: the sing-box plan drops the TelemetryTraffic probe step.
M4_OLD = """    // Round 69: and it proves the counters are the core's own, then records their value as
    // the apply-time baseline (`probe.telemetry-traffic upload_total=… download_total=…`),
    // so a later judge can show a fetch through the core moves them.
    steps.push(EffectStep::Probe {
        probe: ProbeSpec {
            kind: ProbeKind::TelemetryTraffic,
            target: None,
        },
        deadline_ms: 3_000,
    });
"""
M4_NEW = ""


def digest(path):
    return hashlib.sha256(pathlib.Path(path).read_bytes()).hexdigest()


def sweep_strays():
    for path in ROOT.rglob("*.r69bak"):
        print(f"  note  sweeping stale {path}")
        path.unlink()


def run_judge():
    begin = time.time()
    proc = subprocess.run(
        [
            "cargo",
            "test",
            "-p",
            "caly-daemon",
            "--test",
            "real_apply",
            JUDGE,
        ],
        cwd=ROOT,
        env=ENV,
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
        text=True,
        timeout=900,
    )
    return proc, time.time() - begin


def main():
    originals = {
        EFFECT_STD: EFFECT_STD.read_text(),
        MIHOMO_ADAPTER: MIHOMO_ADAPTER.read_text(),
        SINGBOX_ADAPTER: SINGBOX_ADAPTER.read_text(),
    }
    anchors = {
        "M1": EFFECT_STD.read_text().count(M1_OLD),
        "M2": EFFECT_STD.read_text().count(M2_OLD),
        "M3": MIHOMO_ADAPTER.read_text().count(M3_OLD),
        "M4": SINGBOX_ADAPTER.read_text().count(M4_OLD),
    }
    for name, count in anchors.items():
        if count != 1:
            print(f"  FAIL  {name} anchor count={count} (want 1)")
            return 1

    mutations = [
        ("M1 identity hardcoded (must bite)", EFFECT_STD, M1_OLD, M1_NEW),
        ("M2 counters hardcoded (must bite)", EFFECT_STD, M2_OLD, M2_NEW),
        ("M3 mihomo drops CoreIdentity step (must bite)", MIHOMO_ADAPTER, M3_OLD, M3_NEW),
        ("M4 sing-box drops TelemetryTraffic step (must bite)", SINGBOX_ADAPTER, M4_OLD, M4_NEW),
    ]

    all_ok = True
    try:
        for label, path, old, new in mutations:
            if path.read_text() != originals[path]:
                print(f"  FAIL  {label}: tree is dirty before mutation")
                all_ok = False
                break
            backup = ROOT / ".r69bak"
            backup.write_bytes(path.read_bytes())
            path.write_text(path.read_text().replace(old, new, 1))
            proc, elapsed = run_judge()
            if proc.returncode != 0 and "error[E" not in proc.stdout:
                print(f"  ok    {label} (bite in {elapsed:.1f}s)")
            elif "error[E" in proc.stdout:
                print(f"  FAIL  {label}: compiler error, not a property failure ({elapsed:.1f}s)")
                all_ok = False
            else:
                print(f"  FAIL  {label}: judge stayed green ({elapsed:.1f}s)")
                all_ok = False
            path.write_bytes(backup.read_bytes())
            backup.unlink()
            if path.read_text() != originals[path]:
                print(f"  FAIL  {label}: restore mismatch")
                all_ok = False
    finally:
        sweep_strays()
        for path, original in originals.items():
            if path.read_text() != original:
                path.write_text(original)
                print(f"  note  hard-restored {path}")

    if all_ok:
        print("all mutations behaved as predicted: True")
        return 0
    print("all mutations behaved as predicted: False")
    return 1


if __name__ == "__main__":
    sys.exit(main())
