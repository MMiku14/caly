#!/usr/bin/env python3
"""Round 126 falsify: cache-tag evolution and read-time migration (ADR-061).

Four mutations break the evolution semantics from four sides: the v1->epoch-1 historical
fact becomes a wrong constant, unknown tags are tolerated as v1, a stale-epoch cache flows
into the engine as current, and the digest anchors are checked against the RE-ENCODED
(migrated) text instead of the stored bytes.

Each mutation rewrites one production file, runs a targeted red/green pair, then restores
byte-for-byte (sha256 + mtime bump). RED verdicts carry the compiled-guard introduced in
round 125 (a compile error is not a red).
"""
import hashlib
import os
import subprocess
import sys

CALY = "/home/user/caly/caly"
PERSISTENCE = f"{CALY}/crates/caly-engine/src/source_persistence.rs"
WORKER = f"{CALY}/crates/caly-engine/src/source_worker.rs"

J_LEGACY = "-p caly-engine --test source_durable a_legacy_v1_cache_tag_migrates_forward_and_the_worker_boots"
J_STALE = "-p caly-engine --test source_durable a_stale_epoch_cache_is_not_consumed_and_the_worker_still_boots"
J_UNKNOWN = "-p caly-engine --test source_durable an_unknown_cache_tag_refuses_boot_by_name"
J_UNIT_FIDELITY = "-p caly-engine --lib source_persistence::tests::a_v1_tag_decodes_as_epoch_one"
J_UNIT_BYNAME = "-p caly-engine --lib source_persistence::tests::an_unknown_tag_refuses_by_name"


def run(*args: str) -> tuple[int, str]:
    proc = subprocess.run(args, cwd=CALY, capture_output=True, text=True, timeout=900)
    return proc.returncode, proc.stdout + proc.stderr


def test(name: str, expect_ok: bool) -> str:
    code, out = run("cargo", "test", *name.split(), "--", "--test-threads=1")
    compiled = "error[" not in out and "error: " not in out
    passed = code == 0 and compiled
    if passed == expect_ok:
        return "GREEN" if expect_ok else "RED"
    verdict = "UNEXPECTED-RED" if expect_ok else "MISSED-BIT"
    tail = "\\n".join(out.splitlines()[-12:])
    print(f"    [{verdict}] {name}\\n    --------\\n{tail}\\n    --------")
    return verdict


MUTATIONS = [
    dict(
        name="M1 the v1 historical fact becomes epoch 0",
        file=PERSISTENCE,
        old="""    if found == v1 {
        return Ok(1);
    }""",
        new="""    if found == v1 {
        return Ok(0);
    }""",
        red=[(J_UNIT_FIDELITY, False)],
        green=[(J_UNKNOWN, True)],
    ),
    dict(
        name="M2 unknown tags are tolerated as v1",
        file=PERSISTENCE,
        old="""fn decode_tag_epoch(found: &str, v1: &str, v2: &str) -> Result<u32, String> {
    if found == v1 {""",
        new="""fn decode_tag_epoch(found: &str, v1: &str, v2: &str) -> Result<u32, String> {
    let _ = (found, v2);
    if true {
        return Ok(1);
    }
    if found == v1 {""",
        red=[(J_UNKNOWN, False)],
        green=[(J_LEGACY, True)],
    ),
    dict(
        name="M3 a stale-epoch cache flows into the engine as current",
        file=WORKER,
        old="""            match recency {
                CacheRecency::Current => {
                    self.cache
                        .lock()
                        .map_err(|_| "source cache lock poisoned".to_owned())?
                        .insert(source_id, CachedSource { report });
                }
                CacheRecency::Stale { recorded_epoch } => {
                    let _ = (report, recorded_epoch);
                }
            }""",
        new="""            let _ = &recency;
            self.cache
                .lock()
                .map_err(|_| "source cache lock poisoned".to_owned())?
                .insert(source_id, CachedSource { report });""",
        red=[(J_STALE, False)],
        green=[(J_LEGACY, True)],
    ),
    dict(
        name="M4 anchors are checked against the re-encoded (migrated) text",
        file=PERSISTENCE,
        old="""    let normalized_anchor = caly_common::digest::sha256_digest(record.normalized_cache.as_bytes());""",
        new="""    let normalized_anchor = caly_common::digest::sha256_digest(
        decode_normalized(&record.normalized_cache)
            .map(|(value, _)| encode_normalized(&value))
            .unwrap_or_else(|_| record.normalized_cache.clone())
            .as_bytes(),
    );""",
        red=[(J_LEGACY, False)],
        green=[(J_UNKNOWN, True)],
    ),
]


def main() -> int:
    leftovers: list[str] = []
    for mutation in MUTATIONS:
        path = mutation["file"]
        original = open(path, "rb").read().decode()
        original_sha = hashlib.sha256(original.encode()).hexdigest()
        if mutation["old"] not in original:
            print(f"{mutation['name']}: ANCHOR NOT FOUND (skipped)")
            continue
        mutated = original.replace(mutation["old"], mutation["new"], 1)
        open(path, "w").write(mutated)
        os.utime(path, None)
        try:
            verdicts = []
            for name, expect in mutation["red"] + mutation["green"]:
                verdicts.append(test(name, expect))
            reds = verdicts[: len(mutation["red"])]
            greens = verdicts[len(mutation["red"]) :]
            ok = all(v == "RED" for v in reds) and all(v == "GREEN" for v in greens)
            print(
                f"{mutation['name']}: {'BIT' if ok else 'MISSED-BIT'} "
                f"(red={reds} green={greens})"
            )
        finally:
            open(path, "w").write(original)
            os.utime(path, None)
            if hashlib.sha256(open(path, "rb").read()).hexdigest() != original_sha:
                leftovers.append(path)
    if leftovers:
        print(f"LEFTOVERS: {leftovers}")
        return 1
    print("leftovers: []")
    return 0


if __name__ == "__main__":
    sys.exit(main())
