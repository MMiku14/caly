#!/usr/bin/env python3
"""Falsification harness for round 115: `caly apply --wait`.

Round 115 composed the documented `apply`+`follow` two-line pattern into one command: after the
acceptance prints, the SAME session opens the follow stream for the accepted job and takes the
stream's verdict as the exit code (no protocol change -- still two wire requests on one
connection). The flag is opt-in and apply-only.
  T1 = caly_cli_e2e::caly_apply_with_wait_prints_the_acceptance_then_streams_the_job_and_takes_its_verdict
  T2 = caly_cli_e2e::a_wait_apply_of_a_failed_job_exits_nonzero_like_a_follow
  T3 = caly_cli_e2e::an_apply_without_wait_never_opens_a_stream
  T4 = caly_cli_e2e::caly_wait_on_a_non_apply_verb_is_a_usage_error

Each mutation below breaks one production property and must bite its judge:
  M1  caly.rs:  the wait half is dropped (acceptance prints, exit 0 as before)   -> T1/T2 red
  M2  caly.rs:  apply always follows (the flag stops being opt-in)                -> T3 red
  M3  caly.rs:  the stream's verdict is dropped (wait always exits 0)             -> T2 red
  M4  caly.rs:  the apply-only usage guard is disabled (--wait anywhere)          -> T4 red

Rules this harness obeys (DEVELOPMENT_WORKFLOW §6): one mutation at a time, one file per
mutation, bindings/types/arity preserved, backup restored with content AND mtime, sha256
verified, "did not compile" reported separately from "did not bite", and every restored file
gets its mtime bumped IMMEDIATELY (round-110/112 mtime incidents, §4.184/§4.186).
"""
from __future__ import annotations

import hashlib
import os
import shutil
import subprocess
import sys

ROOT = "/home/user/caly"
CLI = "crates/caly-cli/src/bin/caly.rs"
CLI_TEST = ["cargo", "test", "-p", "caly-cli", "--test", "caly_cli_e2e"]

MUTATIONS = [
    {
        "name": "M1-wait-half-dropped",
        "file": CLI,
        "old": (
            '                "profiles.apply" if wait => {\n'
            "                    print_accepted(&records);\n"
            "                    return wait_for_accepted_job(&mut session, &records, json_mode);\n"
            "                }"
        ),
        "new": (
            '                "profiles.apply" if wait => {\n'
            "                    print_accepted(&records);\n"
            "                    return exit_code(ExitCode::Success); // M1: the wait half never runs\n"
            "                }"
        ),
        "expect_red": [
            {"bin": CLI_TEST, "name": "caly_apply_with_wait_prints_the_acceptance_then_streams_the_job_and_takes_its_verdict"},
            {"bin": CLI_TEST, "name": "a_wait_apply_of_a_failed_job_exits_nonzero_like_a_follow"},
        ],
        "expect_green": [
            {"bin": CLI_TEST, "name": "an_apply_without_wait_never_opens_a_stream"},
            {"bin": CLI_TEST, "name": "caly_wait_on_a_non_apply_verb_is_a_usage_error"},
        ],
    },
    {
        "name": "M2-apply-always-follows",
        "file": CLI,
        "old": '                "profiles.apply" if wait => {',
        "new": '                "profiles.apply" => { // M2: the flag stops being opt-in',
        "expect_red": [
            {"bin": CLI_TEST, "name": "an_apply_without_wait_never_opens_a_stream"},
        ],
        "expect_green": [
            {"bin": CLI_TEST, "name": "a_wait_apply_of_a_failed_job_exits_nonzero_like_a_follow"},
            {"bin": CLI_TEST, "name": "caly_wait_on_a_non_apply_verb_is_a_usage_error"},
        ],
    },
    {
        "name": "M3-stream-verdict-dropped",
        "file": CLI,
        "old": (
            "    match follow_stream_after_hello(session, Some(&job_id), None, None, json) {\n"
            "        Ok(code) => exit_code(code),"
        ),
        "new": (
            "    match follow_stream_after_hello(session, Some(&job_id), None, None, json) {\n"
            "        Ok(_code) => exit_code(ExitCode::Success), // M3: the verdict never reaches the exit code"
        ),
        "expect_red": [
            {"bin": CLI_TEST, "name": "a_wait_apply_of_a_failed_job_exits_nonzero_like_a_follow"},
        ],
        "expect_green": [
            {"bin": CLI_TEST, "name": "caly_apply_with_wait_prints_the_acceptance_then_streams_the_job_and_takes_its_verdict"},
            {"bin": CLI_TEST, "name": "an_apply_without_wait_never_opens_a_stream"},
        ],
    },
    {
        "name": "M4-apply-only-guard-disabled",
        "file": CLI,
        "old": "    if wait && wire.name != \"profiles.apply\" {",
        "new": "    if false && wire.name != \"profiles.apply\" { // M4: --wait anywhere",
        "expect_red": [
            {"bin": CLI_TEST, "name": "caly_wait_on_a_non_apply_verb_is_a_usage_error"},
        ],
        "expect_green": [
            {"bin": CLI_TEST, "name": "caly_apply_with_wait_prints_the_acceptance_then_streams_the_job_and_takes_its_verdict"},
            {"bin": CLI_TEST, "name": "a_wait_apply_of_a_failed_job_exits_nonzero_like_a_follow"},
        ],
    },
]


def sha256(path: str) -> str:
    with open(path, "rb") as handle:
        return hashlib.sha256(handle.read()).hexdigest()


def run_tests(targets: list[dict]) -> tuple[int, str, str]:
    """Run each named test; return (exit, combined tail, kind).

    kind is "build_failed" / "red" / "green". A nonzero exit whose log shows a compile error is
    build_failed -- rustc bit, not the judge.
    """
    parts: list[str] = []
    any_red = False
    for target in targets:
        proc = subprocess.run(
            target["bin"] + [target["name"]],
            cwd=ROOT,
            capture_output=True,
            text=True,
            timeout=1800,
        )
        tail = "\n".join((proc.stdout + proc.stderr).splitlines()[-10:])
        parts.append(f"--- {target['name']} (exit {proc.returncode}) ---\n{tail}")
        if "error[" in proc.stdout or "could not compile" in proc.stdout:
            return proc.returncode, "\n".join(parts), "build_failed"
        if proc.returncode != 0:
            any_red = True
    if any_red:
        return 1, "\n".join(parts), "red"
    return 0, "\n".join(parts), "green"


def main() -> int:
    results: list[tuple[str, str]] = []
    for mutation in MUTATIONS:
        path = os.path.join(ROOT, mutation["file"])
        backup = path + ".r115bak"
        with open(path) as handle:
            text = handle.read()
        hits = text.count(mutation["old"])
        if hits != 1:
            print(f"{mutation['name']}: anchor hits={hits} -- skipped")
            results.append((mutation["name"], "anchor-miss"))
            continue
        stat_before = os.stat(path)
        shutil.copy2(path, backup)
        with open(path, "w") as handle:
            handle.write(text.replace(mutation["old"], mutation["new"], 1))
        red_status, red_tail, red_kind = run_tests(mutation["expect_red"])
        green_status, green_tail, green_kind = run_tests(mutation["expect_green"])
        # restore: content AND mtime, then verify byte-identity
        shutil.move(backup, path)
        os.utime(path, ns=(stat_before.st_atime_ns, stat_before.st_mtime_ns))
        pre = sha256(path)
        verdict = (
            red_kind == "red"
            and green_kind == "green"
            and pre == sha256(path)
            and os.path.getmtime(path) == stat_before.st_mtime
        )
        # Bump the restored file's mtime to now IMMEDIATELY: cargo's freshness check compares
        # mtimes, and the mutated tree just produced artifacts newer than the restored source --
        # the next mutation's build would otherwise link the previous mutation's binary
        # (round-112 first run bit itself; §4.184/§4.186).
        os.utime(path, None)
        results.append((mutation["name"], "BIT" if verdict else "NO-BITE"))
        print(
            f"== {mutation['name']}: red={red_kind} green={green_kind} -> "
            f"{'BIT' if verdict else 'NO-BITE'}"
        )
        if not verdict:
            print(red_tail)
            print(green_tail)
    all_bit = all(kind == "BIT" for _, kind in results)
    leftovers = [
        os.path.join(ROOT, mutation["file"]) + ".r115bak"
        for mutation in MUTATIONS
        if os.path.exists(os.path.join(ROOT, mutation["file"]) + ".r115bak")
    ]
    print(f"leftovers: {leftovers}")
    print(f"all mutations bit: {all_bit}")
    return 0 if (all_bit and not leftovers) else 1


if __name__ == "__main__":
    sys.exit(main())
