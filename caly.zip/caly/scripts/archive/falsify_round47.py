"""Falsification harness for round 47 (the command closed loop: `profiles.apply` and
`jobs.events` on the wire, inline drain before the acceptance is written).

Same discipline as rounds 16/32–46: one mutation per run, exact-anchor replacement with
`assert count == 1`, restore by content and mtime, sha256-verified, stale `*.r47bak` swept at
startup. A mutation that cannot compile proves nothing (`§4.112`). Backups are taken **per
mutation** (`§4.137`: a backup outside the loop is consumed by the first restore, and the next
mutation stays in the tree).

Six mutations: apply dropped from the whitelist, the inline drain removed (an acceptance the
client reads for a job that has not run), the wire swallowing the caller's idempotency key, an
acceptance that lies about the job id, `jobs.events` dropped from the whitelist, and the CLI
swallowing the event lines.

Usage: `python3 scripts/archive/falsify_round47.py` (exit 0 = every mutation bit, every file restored).
"""

import hashlib
import os
import pathlib
import shutil
import subprocess
import sys

ROOT = pathlib.Path("/home/user/caly")
ENV = dict(os.environ)
ENV["PATH"] = str(pathlib.Path.home() / ".cargo/bin") + ":" + ENV.get("PATH", "")
SRC = {
    "daemon": ROOT / "crates/caly-daemon/src/bin/calyd.rs",
    "cli": ROOT / "crates/caly-cli/src/bin/caly.rs",
}

MUTATIONS = [
    (
        "M1 profiles.apply drops off the whitelist",
        "daemon",
        '                    "profiles.apply" => {',
        '                    "profiles.apply-x" => {',
        [
            "an_apply_has_already_run_by_the_time_the_acceptance_arrives",
            "the_same_idempotency_key_replays_the_same_job_not_a_new_one",
            "caly_apply_prints_an_acceptance_whose_job_has_already_run",
        ],
    ),
    (
        "M2 the inline drain is removed (accept before running)",
        "daemon",
        """                                        let mut guard = 0;
                                        loop {
                                            match app.drain_engine_once() {
                                                Ok(0) => break,""",
        """                                        let mut guard = 0;
                                        loop {
                                            match Ok::<usize, String>(0) {
                                                Ok(0) => break,""",
        [
            "an_apply_has_already_run_by_the_time_the_acceptance_arrives",
            "caly_apply_prints_an_acceptance_whose_job_has_already_run",
        ],
    ),
    (
        "M3 the wire swallows the caller's idempotency key",
        "daemon",
        '                    idempotency_key: wire_field(&records, "idempotency_key").map(str::to_owned),',
        "                    idempotency_key: None,",
        [
            "an_apply_has_already_run_by_the_time_the_acceptance_arrives",
            "the_same_idempotency_key_replays_the_same_job_not_a_new_one",
            "caly_apply_prints_an_acceptance_whose_job_has_already_run",
        ],
    ),
    (
        "M4 the acceptance lies about the job id",
        "daemon",
        '        ("job_id", accepted.job_id.0.to_string()),',
        '        ("job_id", "0".to_owned()),',
        [
            "an_apply_has_already_run_by_the_time_the_acceptance_arrives",
            "the_same_idempotency_key_replays_the_same_job_not_a_new_one",
            "caly_apply_prints_an_acceptance_whose_job_has_already_run",
            "caly_jobs_prints_the_events_the_wire_said",
        ],
    ),
    (
        "M5 jobs.events drops off the whitelist",
        "daemon",
        '                    "jobs.events" => {',
        '                    "jobs.events-x" => {',
        [
            "an_apply_has_already_run_by_the_time_the_acceptance_arrives",
            "caly_jobs_prints_the_events_the_wire_said",
        ],
    ),
    (
        "M6 the CLI swallows the event lines",
        "cli",
        """        let line = find(&format!("event_{index}"));
        println!("  - {line}");""",
        """        let line = find(&format!("event_{index}"));
        let _ = line;""",
        [
            "caly_jobs_prints_the_events_the_wire_said",
        ],
    ),
]


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def run_cargo():
    proc = subprocess.run(
        [
            "cargo",
            "test",
            "-p",
            "caly-daemon",
            "--test",
            "calyd_wire",
            "-p",
            "caly-cli",
            "--test",
            "caly_cli_e2e",
            "--no-fail-fast",
        ],
        cwd=str(ROOT),
        env=ENV,
        capture_output=True,
        text=True,
    )
    out = proc.stdout + proc.stderr
    failed = sorted(
        {
            line[5:].split(" ... ")[0].split("::")[-1].strip()
            for line in out.splitlines()
            if line.startswith("test ") and line.rstrip().endswith("... FAILED")
        }
    )
    return proc.returncode, failed, out


def main():
    for path in ROOT.rglob("*.r47bak"):
        original = pathlib.Path(str(path)[: -len(".r47bak")])
        shutil.move(str(path), str(original))
        print("swept leftover backup:", path.name)

    originals = {name: digest(path) for name, path in SRC.items()}
    results = []
    bad = False
    for label, key, old, new, expected in MUTATIONS:
        path = SRC[key]
        backup = pathlib.Path(str(path) + ".r47bak")
        shutil.copyfile(path, backup)  # per-mutation backup (§4.137)
        s = path.read_text()
        assert s.count(old) == 1, "%s: anchor x%d" % (label, s.count(old))
        try:
            path.write_text(s.replace(old, new, 1))
            code, failed, out = run_cargo()
            red = [name for name in expected if name in failed]
            compile_error = "error[" in out or "could not compile" in out
            ok = bool(red) and not compile_error
            results.append((label, ok))
            print("%-52s %s  red=%s" % (label, "BIT" if ok else "NO EFFECT", red or failed[:4]))
            if not ok:
                if compile_error:
                    print("   !! the mutation did not compile; it proves nothing")
                print("   output tail:\n", out[-1200:])
        finally:
            shutil.move(str(backup), str(path))
            os.utime(path, None)
            assert digest(path) == originals[key], "%s: restore did not reproduce the file" % label

    print("\n== summary ==")
    for label, ok in results:
        print("%-52s %s" % (label, "bit" if ok else "DID NOT BIT"))
        if not ok:
            bad = True
    print("all mutations bit:", not bad)
    sys.exit(1 if bad else 0)


if __name__ == "__main__":
    main()
