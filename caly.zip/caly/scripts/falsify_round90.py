#!/usr/bin/env python3
"""Round 90 falsification harness.

Target property: the daemon bounds the WRITE direction of every connection phase
symmetrically with the read deadline (`set_transport_deadlines` sets both, and is
installed at accept/hello + post-hello session), proved in-process by
`a_peer_that_never_reads_blocks_the_daemon_write_only_until_the_write_deadline`.

Three mutations, one file each, preserving bindings/types/arity (the goal is "the
property stops holding", not "the build breaks"):

  M1 (gate predicate): delete the write-timeout line from `set_transport_deadlines`
      in calyd.rs. The fix is gone at its root. Expected to bite: the arch-test
      gate (it reads the helper body and requires `set_write_timeout`) — build
      stays green, gate goes red.
  M2 (gate install count): remove the accept-loop phase installation so the
      helper is called at only one phase point. Expected to bite: the arch-test
      gate's "installed at both phase points" assert — build stays green, gate red.
  M3 (mechanism test): in the new calyd unit test, remove the
      `set_transport_deadlines` call so the write has no deadline. The blocked
      write must then hang past the deadline: the test must FAIL (the writer only
      returns because of the deadline). Expected to bite: the calyd bin test.

Restoration is content + mtime, sha256-verified. cwd = workspace root.
"""

import hashlib
import os
import pathlib
import shutil
import subprocess
import sys

ROOT = pathlib.Path(__file__).resolve().parents[1]
GATE = ROOT / "crates/caly-arch-test/tests/dependency_direction.rs"
CALYD = ROOT / "crates/caly-daemon/src/bin/calyd.rs"
SUFFIX = ".r90bak"


def sha256(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def backup(path):
    digest = sha256(path)
    shutil.move(str(path), str(path.with_name(path.name + SUFFIX)))
    return digest


def restore(path, expected):
    shutil.move(str(path.with_name(path.name + SUFFIX)), str(path))
    os.utime(path, None)
    got = sha256(path)
    assert got == expected, f"restore mismatch {path}: {got} != {expected}"


def backup_text(path):
    return path.with_name(path.name + SUFFIX).read_text()


def cargo(args, timeout=240):
    proc = subprocess.run(["cargo", *args], cwd=ROOT, capture_output=True, text=True, timeout=timeout)
    return proc.returncode, proc.stdout + proc.stderr


def gate_result():
    rc, out = cargo([
        "test", "-p", "caly-arch-test", "--test", "dependency_direction",
        "the_daemon_bounds_the_write_deadline_symmetrically_with_the_read_one",
    ])
    build_failed = "error[" in out or "could not compile" in out
    passed = "test result: ok" in out and "1 passed" in out
    return build_failed, passed, out


def mech_result():
    rc, out = cargo(["test", "-p", "caly-daemon", "--bin", "calyd",
                     "a_peer_that_never_reads", "--", "--exact"])
    build_failed = "error[" in out or "could not compile" in out
    # Test names are fuzzy-matched; success line carries 1 passed.
    passed = "test result: ok" in out and "1 passed" in out
    hung = "test ... ok" not in out and "timeout" in out.lower()
    return build_failed, passed, out, hung


def sweep():
    for f in ROOT.glob("crates/**/*.r90bak"):
        f.unlink()


def main():
    sweep()
    bf, ok, out = gate_result()
    assert not bf and ok, "clean tree gate must pass:\n" + out[-1500:]
    print("baseline: gate green")

    results = {}

    # M1: helper no longer sets the write deadline -> gate must bite, build stays green.
    d1 = backup(CALYD)
    try:
        t = backup_text(CALYD)
        old = "    stream.set_read_timeout(Some(deadline))?;\n    stream.set_write_timeout(Some(deadline))\n}"
        new = "    stream.set_read_timeout(Some(deadline))?;\n}"
        assert t.count(old) == 1, f"M1 anchor {t.count(old)}"
        CALYD.write_text(t.replace(old, new, 1))
        bf, ok, out = gate_result()
        bit = (not bf) and (not ok) and "write deadline" in out
        results["M1 helper-drops-write-deadline"] = bit
        print(f"M1: build_failed={bf} gate_passed={ok} bit={bit}")
    finally:
        restore(CALYD, d1)

    # M2: accept-loop installation removed -> gate's two-phase assert bites, build green.
    d2 = backup(CALYD)
    try:
        t = backup_text(CALYD)
        old = (
            "        // Strangers speak AND drain fast: the hello phase bounds both directions (round 90 \u2014\n"
            "        // a peer that accepts the connection then never reads hello_ack must not pin a thread).\n"
            "        if let Err(error) = set_transport_deadlines(&stream, HELLO_TIMEOUT) {\n"
            "            eprintln!(\"calyd: set transport deadlines: {error}\");\n"
            "            continue;\n"
            "        }\n"
        )
        assert t.count(old) == 1, f"M2 anchor {t.count(old)}"
        CALYD.write_text(t.replace(old, "", 1))
        bf, ok, out = gate_result()
        bit = (not bf) and (not ok) and "phase point" in out
        results["M2 accept-phase-missing"] = bit
        print(f"M2: build_failed={bf} gate_passed={ok} bit={bit}")
    finally:
        restore(CALYD, d2)

    # M3: mechanism test without the deadline must fail (the writer only returns because of it).
    d3 = backup(CALYD)
    try:
        t = backup_text(CALYD)
        old = '        set_transport_deadlines(&writer, deadline).expect("set deadlines");\n'
        new = '        // mutation: write deadline intentionally not set\n'
        assert t.count(old) == 1, f"M3 anchor {t.count(old)}"
        CALYD.write_text(t.replace(old, new, 1))
        bf, passed, out, hung = mech_result()
        # Build stays green; the mechanism test must NOT pass (it hangs -> the test harness
        # reports failure/timeout). A passing test with no deadline is the false-safe we forbid.
        bit = (not bf) and (not passed)
        results["M3 test-without-deadline-fails"] = bit
        print(f"M3: build_failed={bf} test_passed={passed} bit={bit}")
    finally:
        restore(CALYD, d3)

    sweep()
    all_bit = all(results.values())
    print(f"\nall mutations bit: {all_bit}")
    for name, bit in results.items():
        print(f"  {'BIT' if bit else 'MISS'}  {name}")
    return 0 if all_bit else 1


if __name__ == "__main__":
    sys.exit(main())
