#!/usr/bin/env bash
set -euo pipefail

root="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
failures=0

reject_dep() {
  local manifest="$1"
  local dependency="$2"
  if grep -Eq "^[[:space:]]*${dependency}[[:space:]]*=" "$manifest"; then
    printf 'forbidden dependency: %s -> %s\n' "$manifest" "$dependency" >&2
    failures=$((failures + 1))
  fi
}

all_internal=(caly-domain caly-ports caly-backends caly-kernel caly-config caly-platform caly-application caly-protocol caly-server caly-tui)
manifest() { printf '%s/crates/%s/Cargo.toml' "$root" "$1"; }

# Domain has no internal dependencies.
for dep in "${all_internal[@]:1}"; do reject_dep "$(manifest caly-domain)" "$dep"; done

# Infrastructure cannot depend on Application, Transport, or Presentation.
for crate in caly-ports caly-backends caly-kernel caly-config caly-platform; do
  for dep in caly-application caly-protocol caly-server caly-tui; do
    reject_dep "$(manifest "$crate")" "$dep"
  done
done

# Application cannot depend on Transport or Presentation.
for dep in caly-protocol caly-server caly-tui; do
  reject_dep "$(manifest caly-application)" "$dep"
done

# Protocol contracts/client cannot depend on daemon Application or Presentation.
for dep in caly-application caly-backends caly-server caly-tui; do
  reject_dep "$(manifest caly-protocol)" "$dep"
done

# Daemon server is a Transport adapter, never Presentation.
for dep in caly-backends caly-tui; do reject_dep "$(manifest caly-server)" "$dep"; done

# Thin clients may directly depend only on Domain and Protocol.
for crate in caly-tui; do
  for dep in caly-kernel caly-config caly-platform caly-application caly-backends caly-server; do
    reject_dep "$(manifest "$crate")" "$dep"
  done
done

if (( failures > 0 )); then
  printf 'dependency discipline failed with %d violation(s)\n' "$failures" >&2
  exit 1
fi

printf 'dependency discipline passed (manifest-level static check)\n'
