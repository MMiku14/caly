#!/usr/bin/env python3
"""Non-compiling structural checks for the caly Rust workspace.

Advisory only: this script reports style/line-budget/forbidden-pattern findings
as warnings and always exits 0. The hard gates are cargo fmt/check/test/clippy;
this script exists to remind humans about drift, never to block a build.
"""

from __future__ import annotations

import re
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
RUST_FILES = sorted((ROOT / "crates").rglob("*.rs")) + sorted((ROOT / "bins").rglob("*.rs"))
MAX_FILE_LINES = 400
WARN_FILE_LINES = 300
FORBIDDEN_PATTERNS = {
    "bare unwrap": re.compile(r"\.unwrap\s*\("),
    "bare expect": re.compile(r"\.expect\s*\("),
    "panic macro": re.compile(r"\bpanic!\s*\("),
    "unreachable macro": re.compile(r"\bunreachable!\s*\("),
    "source TODO/FIXME": re.compile(r"\b(?:TODO|FIXME)\b"),
    "unbounded channel": re.compile(r"\bunbounded(?:_channel)?\s*\("),
}


def relative(path: Path) -> str:
    return str(path.relative_to(ROOT))


def function_spans(lines: list[str]) -> list[tuple[int, int]]:
    """Returns approximate Rust function spans using balanced braces."""
    spans: list[tuple[int, int]] = []
    index = 0
    while index < len(lines):
        if not re.search(r"\bfn\s+[A-Za-z_][A-Za-z0-9_]*", lines[index]):
            index += 1
            continue
        start = index
        depth = 0
        body_started = False
        while index < len(lines):
            depth += lines[index].count("{") - lines[index].count("}")
            body_started = body_started or "{" in lines[index]
            if body_started and depth <= 0:
                spans.append((start + 1, index + 1))
                break
            index += 1
        index += 1
    return spans


def check_files() -> list[str]:
    warnings: list[str] = []
    for path in RUST_FILES:
        text = path.read_text(encoding="utf-8")
        lines = text.splitlines()
        line_count = len(lines)
        if line_count > MAX_FILE_LINES:
            warnings.append(f"{relative(path)}: {line_count} lines exceeds {MAX_FILE_LINES}")
        elif line_count > WARN_FILE_LINES:
            warnings.append(f"{relative(path)}: {line_count} lines approaches file limit")
        for start, end in function_spans(lines):
            function_lines = end - start + 1
            if function_lines > 80:
                warnings.append(f"{relative(path)}:{start}: function spans {function_lines} lines")
            elif function_lines > 50:
                warnings.append(f"{relative(path)}:{start}: function spans {function_lines} lines")
        for label, pattern in FORBIDDEN_PATTERNS.items():
            for match in pattern.finditer(text):
                line = text.count("\n", 0, match.start()) + 1
                warnings.append(f"{relative(path)}:{line}: forbidden {label}")
    return warnings


def check_domain_purity() -> list[str]:
    warnings: list[str] = []
    domain = ROOT / "crates" / "caly-domain" / "src"
    forbidden = re.compile(
        r"\b(?:tokio|async_std|std::path|PathBuf|std::fs|std::net|std::process|tonic|prost)::?"
    )
    for path in sorted(domain.rglob("*.rs")):
        text = path.read_text(encoding="utf-8")
        for match in forbidden.finditer(text):
            line = text.count("\n", 0, match.start()) + 1
            warnings.append(f"{relative(path)}:{line}: concrete I/O/runtime type in Domain")
    return warnings


def main() -> int:
    warnings = check_files()
    warnings.extend(check_domain_purity())
    for warning in warnings:
        print(f"warning: {warning}")
    print(
        f"scanned {len(RUST_FILES)} Rust files: "
        f"{len(warnings)} warning(s) (advisory only, not a gate)"
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
