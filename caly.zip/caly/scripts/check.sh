#!/usr/bin/env bash
# Caly local quality gate.
#
# The repository ships no CI, and `cargo test --workspace` alone is not a gate: with zero
# tests it exits green. This script is the minimum set of checks that makes the documented
# invariants (dependency direction, pure core, deterministic simulation) actually observable.
#
# Design rule: every check must FAIL when it could not run. A gate that reports "clean"
# because the toolchain was missing is worse than no gate, since it reads as a pass in logs.
#
# Usage:  scripts/check.sh
set -uo pipefail
cd "$(dirname "$0")/.."

fail=0
# Minimum number of tests the workspace must contain. Raised whenever tests are added (the number is
# printed by the tests step), lowered only with a reason in the same commit — losing a test is a
# silent regression in every other design of this gate. See the note in the tests step.
TEST_FLOOR=902

note() { printf '\033[1m== %s\033[0m\n' "$*"; }
ok()   { printf '  ok    %s\n' "$*"; }
bad()  { printf '  FAIL  %s\n' "$*"; fail=$((fail + 1)); }

# --- toolchain resolution -------------------------------------------------------------
[ -d "$HOME/.cargo/bin" ] && PATH="$HOME/.cargo/bin:$PATH"
export PATH
if ! command -v cargo >/dev/null 2>&1; then
  echo "  FAIL  cargo not found on PATH"
  echo "        install: curl -sSf https://sh.rustup.rs | sh -s -- -y --profile minimal"
  exit 1
fi

note "toolchain"
cargo --version
rustc --version

if ! command -v cargo-clippy >/dev/null 2>&1; then
  bad "clippy component missing: rustup component add clippy"
fi
if ! command -v cargo-fmt >/dev/null 2>&1; then
  bad "rustfmt component missing: rustup component add rustfmt"
fi

# --- lint environment ------------------------------------------------------------------
# Cargo replays cached lints per crate, so the warning *count* depends on what happened to be
# dirty. A gate whose number moves between two identical runs is not a gate, so the build and the
# clippy ratchet each run in their own throwaway target dir, created empty. Costs full lint passes;
# that is the price of a deterministic signal.
#
# Two flaws this script used to have, both found the hard way in round 14 (see
# `docs/history/ONBOARDING_NOTES.md §4.65`):
#
# * the comment claimed clippy ran in the throwaway dir, but the tests section `unset`
#   `CARGO_TARGET_DIR` and nothing set it back — so clippy ran against the warm repo `target/`, which
#   is exactly the "cached replay" the two-run-max was invented to patch. Each step now gets its own
#   fresh dir explicitly, and the max-of-two is kept as a belt-braces check rather than as the fix.
# * verdicts were computed from shell variables: `out="$(cargo … 2>&1)"` then
#   `printf '%s\n' "$out" | grep -q PATTERN`. Under `set -o pipefail` that is a **race**: `grep -q`
#   exits at the first match, `printf` then dies of `SIGPIPE` (141), `pipefail` promotes the 141 to the
#   pipeline's status, and `if ! …` reads a *successful* run as a failure. It surfaced as
#   "no test results parsed" on a log that was visibly full of `test result:` lines, and as
#   "clippy did not run" — both intermittent, both wrong, and the exit code (0) was the only clue.
#   Every verdict now greps the log **file** directly, with no pipe and no shell variable in between.
#   Anything that merely prints an excerpt keeps its pipe but is `|| true`-guarded, because losing a
#   line of context must never change a verdict.
GATE_ROOT="$(mktemp -d)"
trap 'rm -rf "$GATE_ROOT"' EXIT
CHECK_DIR="$GATE_ROOT/check"
CLIPPY1_DIR="$GATE_ROOT/clippy1"
# The second pass deliberately reuses the first pass' directory: cold-vs-warm is the
# comparison that catches an undercount; a second cold dir pays a full build for no signal.
mkdir -p "$CHECK_DIR" "$CLIPPY1_DIR"
# Logs stay in the repo's target dir rather than the throwaway one: a failure message that points at a
# file the exit trap has already deleted is not a diagnosis. Override with CALY_GATE_LOG_DIR.
LOG_DIR="${CALY_GATE_LOG_DIR:-$PWD/target/gate-logs}"
mkdir -p "$LOG_DIR"

# run_step <log> <target-dir|"-"> <command…> — captures status, retries once if the log has nothing
# parsable (no `Finished`, no `test result`, no `error`), which is always a tooling failure and never
# a code verdict.
run_step() {
  local log="$1" dir="$2"
  shift 2
  local attempt status
  for attempt in 1 2; do
    : >"$log"
    if [ "$dir" = "-" ]; then
      env -u CARGO_TARGET_DIR "$@" >>"$log" 2>&1
    else
      CARGO_TARGET_DIR="$dir" "$@" >>"$log" 2>&1
    fi
    status=$?
    if grep -qE '^test result|^[[:space:]]*Finished|^error' "$log"; then
      RUN_STATUS=$status
      return 0
    fi
    [ "$attempt" = 1 ] && printf '  note  %s produced nothing parsable (status %s); retrying once\n' \
      "${RUN_NAME:-step}" "$status"
  done
  RUN_STATUS=$status
  return 0
}
export CARGO_TARGET_DIR="$CHECK_DIR"

# --- build -----------------------------------------------------------------------------
note "build (must be free of warnings)"
RUN_NAME="cargo check"
run_step "$LOG_DIR/check.log" "$CHECK_DIR" cargo check --workspace --all-targets
if ! grep -q 'Finished' "$LOG_DIR/check.log"; then
  bad "cargo check did not complete (status $RUN_STATUS); see $LOG_DIR/check.log"
  grep -E '^(error|warning)' "$LOG_DIR/check.log" | head -20 || true
elif grep -qE '^(warning|error)' "$LOG_DIR/check.log"; then
  bad "cargo check produced warnings/errors"
  grep -E '^(warning|error)' "$LOG_DIR/check.log" | head -20 || true
else
  ok "cargo check --workspace --all-targets is clean"
fi

# --- tests -----------------------------------------------------------------------------
# Test *results* do not depend on lint caching, so reuse the normal target dir for speed.
note "tests"
RUN_NAME="cargo test"
run_step "$LOG_DIR/tests.log" - cargo test --workspace
if ! grep -qE '^test result' "$LOG_DIR/tests.log"; then
  bad "no test results parsed (status $RUN_STATUS, $(wc -l <"$LOG_DIR/tests.log" | tr -d ' ') log line(s)); see $LOG_DIR/tests.log"
  head -10 "$LOG_DIR/tests.log"
  tail -20 "$LOG_DIR/tests.log"
elif grep -qE 'test result: FAILED' "$LOG_DIR/tests.log"; then
  bad "test failures present"
  grep -E '^(test .*FAILED|error\[)' "$LOG_DIR/tests.log" | head -20 || true
else
  # awk reads the file itself: no pipe, so nothing can die of SIGPIPE on the way to the number.
  passed="$(awk '/^test result: ok\./ {s+=$4} END {print s+0}' "$LOG_DIR/tests.log")"
  if [ "${passed:-0}" -eq 0 ]; then
    bad "zero tests executed: a green run with no tests is not a signal"
  elif [ "${passed:-0}" -lt "$TEST_FLOOR" ]; then
    # A floor, not a target: the count only moves when code moves. This exists because round 15 lost
    # four contract tests to a bad patch slice and nothing noticed — the census table is regenerated
    # from the tree, so it agreed with the loss. A gate that can only see additions cannot see deletion.
    bad "test count fell below the floor: $passed < floor $TEST_FLOOR (a test was lost; if the removal is deliberate, lower the floor and say why)"
  else
    ok "$passed tests passed (floor $TEST_FLOOR)"
  fi
fi

# --- clippy (ratchet) ------------------------------------------------------------------
note "clippy (ratchet on distinct source locations)"
# Metric: unique `-->` source locations. Raw `warning:` line counts are misleading because
# cargo also prints "<crate> generated N warnings" summaries plus lib/test duplicates.
# Baseline measured on this tree with clippy 1.98.0 in a clean lint pass; it moves only when the code
# moves (33 -> 32 in round 3-4, by fixing code).
#
# The measurement itself needed fixing: cargo replays cached lints per crate, so two runs over the
# same tree reported 23 and 32 locations in round 9 — an undercount that would have "earned" a
# baseline drop that the code had not done anything to deserve. Clippy is therefore run twice in the
# throwaway target dir and the **max** is used, so a warm cache can only ever push the number up,
# never hide a lint.
CLIPPY_BASELINE=31
RUN_NAME="cargo clippy"
run_step "$LOG_DIR/clippy1.log" "$CLIPPY1_DIR" cargo clippy --workspace --all-targets
run_step "$LOG_DIR/clippy2.log" "$CLIPPY1_DIR" cargo clippy --workspace --all-targets
if ! grep -qE 'Finished|^(warning|error)' "$LOG_DIR/clippy1.log"; then
  bad "clippy did not run (status $RUN_STATUS); see $LOG_DIR/clippy1.log"
else
  # Counted with grep -c on unique locations, per log file, and the two logs are compared with
  # `test` rather than a pipeline: every step here must be able to fail loudly, but the *verdict*
  # must never depend on a pipe closing early.
  grep -E '^[[:space:]]+--> ' "$LOG_DIR/clippy1.log" | sort -u > "$LOG_DIR/loc1.txt" || true
  grep -E '^[[:space:]]+--> ' "$LOG_DIR/clippy2.log" | sort -u > "$LOG_DIR/loc2.txt" || true
  first_count=$(wc -l < "$LOG_DIR/loc1.txt" | tr -d ' ')
  second_count=$(wc -l < "$LOG_DIR/loc2.txt" | tr -d ' ')
  clippy_count="$first_count"
  if [ "${second_count:-0}" -gt "${first_count:-0}" ]; then
    clippy_count="$second_count"
  fi
  if [ "${clippy_count:-0}" -gt "$CLIPPY_BASELINE" ]; then
    bad "clippy locations grew: $clippy_count > baseline $CLIPPY_BASELINE"
    grep -E '^warning: ' "$LOG_DIR/clippy1.log" | sort | uniq -c | sort -rn | head -10 || true
  elif [ "${clippy_count:-0}" -lt "$CLIPPY_BASELINE" ]; then
    ok "clippy locations shrank: $clippy_count < baseline $CLIPPY_BASELINE (lower the baseline)"
  else
    ok "clippy locations at baseline ($clippy_count)"
  fi
fi

# --- formatting (hard gate since the 2026-09-01 repo-wide rustfmt commit) -------------
# Formatting debt is zero and stays zero: an unformatted diff is a review hazard, and with git
# (unlike the pre-git zip era) a formatting-only commit is cheap to review. The old "advisory"
# mode retired with the big format commit.
note "formatting"
unset CARGO_TARGET_DIR
fmt_log="$LOG_DIR/fmt.log"
cargo fmt --all -- --check >"$fmt_log" 2>&1
if [ ! -s "$fmt_log" ]; then
  ok "cargo fmt is clean"
elif grep -qi 'not installed' "$fmt_log"; then
  bad "rustfmt unavailable; install the component before trusting this gate"
else
  bad "$(wc -l <"$fmt_log" | tr -d ' ') formatting diff lines (run: cargo fmt --all)"
  grep -E '^Diff in' "$fmt_log" | head -10 || true
fi

note "result"
if [ "$fail" -gt 0 ]; then
  echo "  $fail gate(s) failed"
  exit 1
fi
echo "  all gates passed"
