"""Falsification harness for round 46 (the profiles query surface on the wire + the session's
own idle deadline).

Same discipline as rounds 16/32–45: one mutation per run, exact-anchor replacement with
`assert count == 1`, restore by content and mtime, sha256-verified, stale `*.r46bak` swept at
startup. A mutation that cannot compile proves nothing (`§4.112`). Backups are taken **per
mutation** (`§4.137`: a backup outside the loop is consumed by the first restore, and the next
mutation stays in the tree).

Six mutations: `profiles.list` dropped from the whitelist, a profile count that lies about its
own lines, a missing `profile_id` answered by guessing the default, a view that echoes the
default id no matter which was asked, the session idle deadline removed (the reap falls back to
the hello deadline still on the socket — the mutation one shared constant could never expose),
and the CLI dropping the profile label.

Usage: `python3 scripts/falsify_round46.py` (exit 0 = every mutation bit, every file restored).
"""

import hashlib
import os
import pathlib
import shutil
import subprocess
import sys

ROOT = pathlib.Path("/home/user/caly")
ENV = dict(os.environ)
ENV["PATH"] = str(pathlib.Path.home() / ".cargo/bin") + ":" + ENV.get("PATH", "")
SRC = {
    "daemon": ROOT / "crates/caly-daemon/src/bin/calyd.rs",
    "cli": ROOT / "crates/caly-cli/src/bin/caly.rs",
}

MUTATIONS = [
    (
        "M1 profiles.list drops off the whitelist",
        "daemon",
        '                    "profiles.list" => Operation::Profile(ProfileOp::List),',
        '                    "profiles.list-x" => Operation::Profile(ProfileOp::List),',
        [
            "profiles_list_counts_its_lines_and_never_invents_a_second_active",
            "caly_profiles_prints_the_list_the_wire_actually_said",
        ],
    ),
    (
        "M2 profile_count lies about its own lines",
        "daemon",
        '        ("profile_count".to_owned(), profiles.len().to_string()),',
        '        ("profile_count".to_owned(), (profiles.len() + 1).to_string()),',
        [
            "profiles_list_counts_its_lines_and_never_invents_a_second_active",
            "caly_profiles_prints_the_list_the_wire_actually_said",
        ],
    ),
    (
        "M3 a missing profile_id is answered by guessing the default",
        "daemon",
        """                        let Some(profile_id) = wire_field(&records, "profile_id") else {
                            refusal(
                                stream,
                                request_id,
                                "USAGE",
                                "profiles.get needs a profile_id record; refusing rather than \\
                                 guessing one",
                            )?;
                            continue;
                        };""",
        '                        let profile_id = wire_field(&records, "profile_id").unwrap_or("default");',
        [
            "profiles_get_refuses_a_missing_id_and_echoes_the_one_it_was_asked",
        ],
    ),
    (
        "M4 the view echoes the default id no matter which was asked",
        "daemon",
        '        ("profile_id", view.summary.id.0.clone()),',
        '        ("profile_id", "default".to_owned()),',
        [
            "profiles_get_refuses_a_missing_id_and_echoes_the_one_it_was_asked",
            "caly_profile_prints_the_view_the_wire_said_for_that_id",
        ],
    ),
    (
        "M5 the session idle deadline is removed (hello's stays on the socket)",
        "daemon",
        """                        // The session is active: from here the peer is judged by the session
                        // idle deadline — its own policy, not the hello deadline the socket
                        // carried in with it.
                        let _ = stream.set_read_timeout(Some(session_idle));""",
        """                        // The session is active: from here the peer is judged by the session
                        // idle deadline — its own policy, not the hello deadline the socket
                        // carried in with it.
                        let _ = session_idle;""",
        [
            "a_quiet_session_is_reaped_at_its_own_deadline_not_the_hello_one",
        ],
    ),
    (
        "M6 the CLI drops the profile label",
        "cli",
        '        println!("{marker} {id}  {label}");',
        '        println!("{marker} {id}");',
        [
            "caly_profiles_prints_the_list_the_wire_actually_said",
        ],
    ),
]


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def run_cargo():
    proc = subprocess.run(
        [
            "cargo",
            "test",
            "-p",
            "caly-daemon",
            "--test",
            "calyd_wire",
            "-p",
            "caly-cli",
            "--test",
            "caly_cli_e2e",
            "--no-fail-fast",
        ],
        cwd=str(ROOT),
        env=ENV,
        capture_output=True,
        text=True,
    )
    out = proc.stdout + proc.stderr
    failed = sorted(
        {
            line[5:].split(" ... ")[0].split("::")[-1].strip()
            for line in out.splitlines()
            if line.startswith("test ") and line.rstrip().endswith("... FAILED")
        }
    )
    return proc.returncode, failed, out


def main():
    for path in ROOT.rglob("*.r46bak"):
        original = pathlib.Path(str(path)[: -len(".r46bak")])
        shutil.move(str(path), str(original))
        print("swept leftover backup:", path.name)

    originals = {name: digest(path) for name, path in SRC.items()}
    results = []
    bad = False
    for label, key, old, new, expected in MUTATIONS:
        path = SRC[key]
        backup = pathlib.Path(str(path) + ".r46bak")
        shutil.copyfile(path, backup)  # per-mutation backup (§4.137)
        s = path.read_text()
        assert s.count(old) == 1, "%s: anchor x%d" % (label, s.count(old))
        try:
            path.write_text(s.replace(old, new, 1))
            code, failed, out = run_cargo()
            red = [name for name in expected if name in failed]
            compile_error = "error[" in out or "could not compile" in out
            ok = bool(red) and not compile_error
            results.append((label, ok))
            print("%-52s %s  red=%s" % (label, "BIT" if ok else "NO EFFECT", red or failed[:4]))
            if not ok:
                if compile_error:
                    print("   !! the mutation did not compile; it proves nothing")
                print("   output tail:\n", out[-1200:])
        finally:
            shutil.move(str(backup), str(path))
            os.utime(path, None)
            assert digest(path) == originals[key], "%s: restore did not reproduce the file" % label

    print("\n== summary ==")
    for label, ok in results:
        print("%-52s %s" % (label, "bit" if ok else "DID NOT BIT"))
        if not ok:
            bad = True
    print("all mutations bit:", not bad)
    sys.exit(1 if bad else 0)


if __name__ == "__main__":
    main()
