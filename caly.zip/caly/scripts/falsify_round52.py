"""Falsification harness for round 52 (the reconnect path: ack frames, the server-side stream
table, and resume semantics — acked cursors continue, unacked emissions replay).

Same discipline as rounds 16/32–51: one mutation per run, exact-anchor replacement with
`assert count == 1`, restore by content and mtime, sha256-verified, stale `*.r52bak` swept at
startup. A mutation that cannot compile proves nothing (`§4.112`). Backups are taken **per
mutation** (`§4.137`). No hang-shaped mutations.

Six mutations: resume ignoring the acked cursor, the ack frame being silently dropped, an
unknown-stream resume answered as a fresh open, resume from emitted-instead-of-acked (breaking
at-least-once), the stream-table cap removed, and the CLI never acking.

Usage: `python3 scripts/falsify_round52.py` (exit 0 = every mutation bit, every file restored).
"""

import hashlib
import os
import pathlib
import shutil
import subprocess
import sys

ROOT = pathlib.Path("/home/user/caly")
ENV = dict(os.environ)
ENV["PATH"] = str(pathlib.Path.home() / ".cargo/bin") + ":" + ENV.get("PATH", "")
SRC = {
    "daemon": ROOT / "crates/caly-daemon/src/bin/calyd.rs",
    "cli": ROOT / "crates/caly-cli/src/bin/caly.rs",
}

MUTATIONS = [
    (
        "M1 resume ignores the acked cursor",
        "daemon",
        "                            stream_job = Some((entry.job_id, entry.acked));",
        "                            stream_job = Some((entry.job_id, None));",
        [
            "an_acked_stream_resumes_with_an_empty_delta",
            "caly_follow_acks_and_a_resume_prints_nothing_new",
        ],
    ),
    (
        "M2 the ack frame is silently dropped",
        "daemon",
        "                entry.acked = Some(entry.acked.map_or(cursor, |seen| seen.max(cursor)));",
        "                entry.acked = { let _ = cursor; entry.acked };",
        [
            "an_acked_stream_resumes_with_an_empty_delta",
            "caly_follow_acks_and_a_resume_prints_nothing_new",
        ],
    ),
    (
        "M3 an unknown-stream resume is answered as a fresh open",
        "daemon",
        """                            let Some(entry) = streams.get(stream_id) else {
                                refusal(
                                    stream,
                                    json_session,
                                    request_id,
                                    "NOT_FOUND",
                                    &format!(
                                        "stream {stream_id} is not open (never opened, ended \\
                                         and evicted, or this daemon restarted); open a fresh \\
                                         stream by job_id instead"
                                    ),
                                )?;
                                continue;
                            };""",
        """                            let entry = streams.get(stream_id).unwrap_or(calyd_stream_fallback(
                                stream_id,
                            ));""",
        [
            "a_resume_of_an_unknown_stream_is_refused_by_name",
        ],
    ),
    (
        "M4 resume from emitted instead of acked (at-least-once broken)",
        "daemon",
        "                            stream_job = Some((entry.job_id, entry.acked));",
        "                            stream_job = Some((entry.job_id, entry.last_emitted));",
        [
            "an_unacked_stream_replays_everything_on_resume",
        ],
    ),
    (
        "M5 the stream-table cap is removed",
        "daemon",
        "        if guard.len() >= MAX_STREAM_TABLE {",
        "        if false && guard.len() >= MAX_STREAM_TABLE {",
        [
            "the_stream_table_is_bounded_and_refuses_loudly",
        ],
    ),
    (
        "M6 the CLI never acks",
        "cli",
        "    if !stream_id.is_empty() && !upto.is_empty() {",
        "    if false && !stream_id.is_empty() && !upto.is_empty() {",
        [
            "caly_follow_acks_and_a_resume_prints_nothing_new",
        ],
    ),
]

# M3 references a helper the mutation itself must provide; inject it next to the table so the
# mutant compiles (a mutation that cannot compile proves nothing, §4.112).
M3_HELPER = """
fn calyd_stream_fallback(stream_id: u64) -> StreamEntry {
    let _ = stream_id;
    StreamEntry {
        job_id: 1,
        acked: None,
        last_emitted: None,
    }
}
"""


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def run_cargo():
    proc = subprocess.run(
        [
            "cargo",
            "test",
            "-p",
            "caly-daemon",
            "--test",
            "calyd_wire",
            "-p",
            "caly-cli",
            "--test",
            "caly_cli_e2e",
            "--no-fail-fast",
        ],
        cwd=str(ROOT),
        env=ENV,
        capture_output=True,
        text=True,
    )
    out = proc.stdout + proc.stderr
    failed = sorted(
        {
            line[5:].split(" ... ")[0].split("::")[-1].strip()
            for line in out.splitlines()
            if line.startswith("test ") and line.rstrip().endswith("... FAILED")
        }
    )
    return proc.returncode, failed, out


def main():
    for path in ROOT.rglob("*.r52bak"):
        original = pathlib.Path(str(path)[: -len(".r52bak")])
        shutil.move(str(path), str(original))
        print("swept leftover backup:", path.name)

    originals = {name: digest(path) for name, path in SRC.items()}
    results = []
    bad = False
    for label, key, old, new, expected in MUTATIONS:
        path = SRC[key]
        backup = pathlib.Path(str(path) + ".r52bak")
        shutil.copyfile(path, backup)  # per-mutation backup (§4.137)
        s = path.read_text()
        assert s.count(old) == 1, "%s: anchor x%d" % (label, s.count(old))
        try:
            mutated = s.replace(old, new, 1)
            if "calyd_stream_fallback" in new:
                # the fallback helper rides along so the mutant compiles
                anchor = "fn serve_connection("
                assert mutated.count(anchor) == 1
                mutated = mutated.replace(anchor, M3_HELPER + "\n" + anchor, 1)
            path.write_text(mutated)
            code, failed, out = run_cargo()
            red = [name for name in expected if name in failed]
            compile_error = "error[" in out or "could not compile" in out
            ok = bool(red) and not compile_error
            results.append((label, ok))
            print("%-52s %s  red=%s" % (label, "BIT" if ok else "NO EFFECT", red or failed[:4]))
            if not ok:
                if compile_error:
                    print("   !! the mutation did not compile; it proves nothing")
                print("   output tail:\n", out[-1200:])
        finally:
            shutil.move(str(backup), str(path))
            os.utime(path, None)
            assert digest(path) == originals[key], "%s: restore did not reproduce the file" % label

    print("\n== summary ==")
    for label, ok in results:
        print("%-52s %s" % (label, "bit" if ok else "DID NOT BIT"))
        if not ok:
            bad = True
    print("all mutations bit:", not bad)
    sys.exit(1 if bad else 0)


if __name__ == "__main__":
    main()
