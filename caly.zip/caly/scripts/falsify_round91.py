#!/usr/bin/env python3
"""Round 91 falsification harness.

Target property: a followed Job stream waits through silent ticks on the STREAM's
idle deadline (30s), not the 3s request/answer deadline, and the dead-peer probe
does not borrow the read budget. Two compounded defects are fixed:

  1. `caly follow` widened nothing — a real core's silent spawn/probe (the daemon's
     stream pump emits no frame on a `Wait`) made a healthy long job exit 11 after
     the 3s op deadline. Fix: `Session::enter_stream_mode` widens both directions
     via `FramePump::set_idle(STREAM_IDLE_TIMEOUT)` when the stream opens.
  2. `FramePump::recv` ran its TCP `peek` on the caller's full read deadline. A peek
     blocks until a byte or the timeout, and maps that timeout to `Alive`, so a
     silent peer waited out the deadline in `peek` AND AGAIN in `read_exact` —
     doubling the silent budget and making any widening useless for short gaps.
     Fix: the probe runs on a short window and restores the caller's deadline.

Mutations (one file each; bindings/types/arity preserved so the build stays green
and the *judge* is what bites):

  M1 (no stream widening): comment out the `session.enter_stream_mode()?;` call in
      the follow opened-frame branch. Expected to bite BOTH
        - the e2e judge `caly_follow_survives_a_silent_gap_longer_than_the_request_deadline`
          (a 4s silent gap then times out at 3s -> exit 11), and
        - the arch-test gate `the_cli_widens_a_follow_stream...` (no call site).
  M2 (probe borrows the read budget): in `FramePump::recv`, drop the narrow/restore
      around `probe_peer` so the peek uses the caller's idle deadline. Expected to
      bite the duplex unit test `recvs_probe_uses_a_short_window_and_restores...`
      (no short-window deadline in the history).
  M3 (widening sets only one direction): in `enter_stream_mode`, route around
      `set_idle` by setting only the read timeout, so the write half keeps the short
      deadline. Expected to bite the arch-test gate (the helper must go through
      `set_idle`, which bounds both).

Restoration is content + mtime, sha256-verified. cwd = workspace root.
"""

import hashlib
import os
import pathlib
import shutil
import subprocess
import sys

ROOT = pathlib.Path(__file__).resolve().parents[1]
GATE = ROOT / "crates/caly-arch-test/tests/dependency_direction.rs"
CALY = ROOT / "crates/caly-cli/src/bin/caly.rs"
DUPLEX = ROOT / "crates/caly-ipc/src/duplex.rs"
SUFFIX = ".r91bak"


def sha256(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def backup(path):
    digest = sha256(path)
    shutil.move(str(path), str(path.with_name(path.name + SUFFIX)))
    return digest


def backup_text(path):
    return path.with_name(path.name + SUFFIX).read_text()


def restore(path, expected):
    shutil.move(str(path.with_name(path.name + SUFFIX)), str(path))
    os.utime(path, None)
    got = sha256(path)
    assert got == expected, f"restore mismatch {path}: {got} != {expected}"


def cargo(args, timeout=300):
    proc = subprocess.run(
        ["cargo", *args], cwd=ROOT, capture_output=True, text=True, timeout=timeout
    )
    return proc.returncode, proc.stdout + proc.stderr


def build_failed(out):
    return "error[" in out or "could not compile" in out


def e2e_gap_result():
    # The judge spawns the caly binary; build it first so a stale binary can never mask a
    # mutation (CARGO_BIN_EXE_caly points at the just-built target).
    rc, out = cargo(["build", "-p", "caly-cli", "--bin", "caly"])
    if build_failed(out):
        return True, False, out
    rc, out = cargo(
        [
            "test", "-p", "caly-cli", "--test", "caly_cli_e2e",
            "caly_follow_survives_a_silent_gap_longer_than_the_request_deadline",
        ]
    )
    return False, ("test result: ok" in out and "1 passed" in out), out


def gate_result():
    rc, out = cargo(
        [
            "test", "-p", "caly-arch-test", "--test", "dependency_direction",
            "the_cli_widens_a_follow_stream_to_its_own_idle_deadline_when_opened",
        ]
    )
    # A single named test: a FAILED summary or a panic is red; an ok summary with no FAILED
    # line is green. Do not key off "N passed" (the filter prints "13 filtered out" too).
    red = "test result: FAILED" in out or "panicked" in out
    return build_failed(out), (not red and "test result: ok" in out), out


def duplex_probe_result():
    rc, out = cargo(
        ["test", "-p", "caly-ipc", "--lib", "recvs_probe_uses_a_short_window"]
    )
    red = "test result: FAILED" in out or "panicked" in out
    return build_failed(out), (not red and "test result: ok" in out), out


def sweep():
    for f in ROOT.glob("crates/**/*.r91bak"):
        f.unlink()


def main():
    sweep()
    # Baseline: every judge green on the fixed tree.
    bf, ok, out = e2e_gap_result()
    assert not bf and ok, "clean tree e2e must pass:\n" + out[-1500:]
    bf, ok, out = gate_result()
    assert not bf and ok, "clean tree gate must pass:\n" + out[-1500:]
    bf, ok, out = duplex_probe_result()
    assert not bf and ok, "clean tree duplex test must pass:\n" + out[-1500:]
    print("baseline: e2e + gate + duplex all green")

    results = {}

    # M1: no stream widening -> the e2e gap judge times out at the 3s op deadline AND the
    # arch-test gate loses its call site. Build stays green.
    d1 = backup(CALY)
    try:
        t = backup_text(CALY)
        old = "                session.enter_stream_mode()?;\n"
        new = "                // mutation: follow stream widening intentionally removed\n"
        assert t.count(old) == 1, f"M1 anchor {t.count(old)}"
        CALY.write_text(t.replace(old, new, 1))
        bf_e2e, e2e_ok, e2e_out = e2e_gap_result()
        e2e_bit = (not bf_e2e) and (not e2e_ok) and "3000ms" in e2e_out
        bf_gate, gate_ok, gate_out = gate_result()
        gate_bit = (not bf_gate) and (not gate_ok) and "call site" in gate_out
        bit = e2e_bit and gate_bit
        results["M1 no-widening: e2e-timeout AND gate-call-site"] = bit
        print(f"M1: e2e_build_failed={bf_e2e} e2e_passed={e2e_ok} (bit={e2e_bit}) | "
              f"gate_build_failed={bf_gate} gate_passed={gate_ok} (bit={gate_bit}) -> {bit}")
    finally:
        restore(CALY, d1)

    # M2: probe borrows the caller's full read deadline (no narrow/restore) -> the duplex
    # history test must fail: no short-window deadline appears. Build stays green.
    d2 = backup(DUPLEX)
    try:
        t = backup_text(DUPLEX)
        old = (
            "        let restore = self.idle;\n"
            "        if let Err(error) = self.stream.set_read_timeout(Some(Self::PROBE_WINDOW)) {\n"
            "            return Err(WireFrameError {\n"
            "                summary: format!(\"narrow read deadline for probe: {error}\"),\n"
            "                timed_out: false,\n"
            "            });\n"
            "        }\n"
            "        let probed = self.stream.probe_peer();\n"
            "        if let Err(error) = self.stream.set_read_timeout(restore) {\n"
            "            return Err(WireFrameError {\n"
            "                summary: format!(\"restore read deadline after probe: {error}\"),\n"
            "                timed_out: false,\n"
            "            });\n"
            "        }\n"
        )
        new = (
            "        // mutation: probe borrows the caller's full read deadline (no narrow/restore)\n"
            "        let probed = self.stream.probe_peer();\n"
        )
        assert t.count(old) == 1, f"M2 anchor {t.count(old)}"
        DUPLEX.write_text(t.replace(old, new, 1))
        bf, passed, out = duplex_probe_result()
        bit = (not bf) and (not passed) and "narrow" in out
        results["M2 probe-borrows-read-budget"] = bit
        print(f"M2: build_failed={bf} test_passed={passed} bit={bit}")
    finally:
        restore(DUPLEX, d2)

    # M3: widen the READ half only, through the raw stream setter instead of the symmetric
    # `set_idle` (the write half keeps the short op deadline — the asymmetry round 90/91 forbid).
    # This still compiles and the opened branch still calls the method (so the STREAM_IDLE_TIMEOUT
    # constant and the (c) call-site assert stay present); only the (b) "must widen through
    # set_idle, which bounds BOTH" assert can bite it.
    d3 = backup(CALY)
    try:
        t = backup_text(CALY)
        old = (
            "        self.pump\n"
            "            .set_idle(Some(STREAM_IDLE_TIMEOUT))\n"
            "            .map_err(|error| format!(\"set stream transport timeouts: {error}\"))\n"
        )
        new = (
            "        self.pump\n"
            "            .inner_mut()\n"
            "            .set_read_timeout(Some(STREAM_IDLE_TIMEOUT))\n"
            "            .map_err(|error| format!(\"set stream read timeout: {error}\"))\n"
        )
        assert t.count(old) == 1, f"M3 anchor {t.count(old)}"
        CALY.write_text(t.replace(old, new, 1))
        bf, ok, out = gate_result()
        bit = (not bf) and (not ok) and "set_idle" in out
        results["M3 read-only-widening-gate-reds"] = bit
        print(f"M3: build_failed={bf} gate_passed={ok} bit={bit}")
    finally:
        restore(CALY, d3)

    sweep()
    all_bit = all(results.values())
    print(f"\nall mutations bit: {all_bit}")
    for name, bit in results.items():
        print(f"  {'BIT' if bit else 'MISS'}  {name}")
    return 0 if all_bit else 1


if __name__ == "__main__":
    sys.exit(main())
