"""Falsification harness for round 45 (concurrent connections + `diagnostics.doctor` on the wire).

Same discipline as rounds 16/32–44: one mutation per run, exact-anchor replacement with
`assert count == 1`, restore by content and mtime, sha256-verified, stale `*.r45bak` swept at
startup. A mutation that cannot compile proves nothing (`§4.112`). Backups are taken **per
mutation** (`§4.137`: a backup outside the loop is consumed by the first restore, and the next
mutation stays in the tree).

Four mutations: the daemon back to one-connection-at-a-time (the wedge shape threads removed),
doctor dropped from the whitelist, a tier count that lies about its own lines, and the CLI
swallowing a tier's output.

Usage: `python3 scripts/falsify_round45.py` (exit 0 = every mutation bit, every file restored).
"""

import hashlib
import os
import pathlib
import shutil
import subprocess
import sys

ROOT = pathlib.Path("/home/user/caly")
ENV = dict(os.environ)
ENV["PATH"] = str(pathlib.Path.home() / ".cargo/bin") + ":" + ENV.get("PATH", "")
SRC = {
    "daemon": ROOT / "crates/caly-daemon/src/bin/calyd.rs",
    "cli": ROOT / "crates/caly-cli/src/bin/caly.rs",
}

MUTATIONS = [
    (
        "M1 the daemon serves one connection at a time again",
        "daemon",
        """        let app = std::sync::Arc::clone(&app);
        std::thread::spawn(move || {
            if let Err(error) = serve_connection(&app, &mut stream) {
                eprintln!("calyd: connection ended: {error}");
            }
        });""",
        """        let app = std::sync::Arc::clone(&app);
        if let Err(error) = serve_connection(&app, &mut stream) {
            eprintln!("calyd: connection ended: {error}");
        }""",
        ["a_silent_client_never_costs_another_client_its_turn"],
    ),
    (
        "M2 doctor drops off the whitelist",
        "daemon",
        '                    "diagnostics.doctor" => {',
        '                    "diagnostics.doctor-x" => {',
        [
            "doctor_answers_with_tiers_whose_counts_match_their_lines",
            "caly_doctor_prints_the_tiers_the_wire_actually_said",
        ],
    ),
    (
        "M3 a tier count lies about its own lines",
        "daemon",
        '        ("warning_count".to_owned(), report.warnings.len().to_string()),',
        '        ("warning_count".to_owned(), (report.warnings.len() + 1).to_string()),',
        ["doctor_answers_with_tiers_whose_counts_match_their_lines"],
    ),
    (
        "M4 the CLI swallows the notes tier",
        "cli",
        """    println!("notes: {}", find("note_count"));
    for line in &notes {
        println!("  - {line}");
    }""",
        """    println!("notes: {}", find("note_count"));
    let _ = &notes;""",
        ["caly_doctor_prints_the_tiers_the_wire_actually_said"],
    ),
]


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def run_cargo():
    proc = subprocess.run(
        [
            "cargo",
            "test",
            "-p",
            "caly-daemon",
            "--test",
            "calyd_wire",
            "-p",
            "caly-cli",
            "--test",
            "caly_cli_e2e",
            "--no-fail-fast",
        ],
        cwd=str(ROOT),
        env=ENV,
        capture_output=True,
        text=True,
    )
    out = proc.stdout + proc.stderr
    failed = sorted(
        {
            line[5:].split(" ... ")[0].split("::")[-1].strip()
            for line in out.splitlines()
            if line.startswith("test ") and line.rstrip().endswith("... FAILED")
        }
    )
    return proc.returncode, failed, out


def main():
    for path in ROOT.rglob("*.r45bak"):
        original = pathlib.Path(str(path)[: -len(".r45bak")])
        shutil.move(str(path), str(original))
        print("swept leftover backup:", path.name)

    originals = {name: digest(path) for name, path in SRC.items()}
    results = []
    bad = False
    for label, key, old, new, expected in MUTATIONS:
        path = SRC[key]
        backup = pathlib.Path(str(path) + ".r45bak")
        shutil.copyfile(path, backup)  # per-mutation backup (§4.137)
        s = path.read_text()
        assert s.count(old) == 1, "%s: anchor x%d" % (label, s.count(old))
        try:
            path.write_text(s.replace(old, new, 1))
            code, failed, out = run_cargo()
            red = [name for name in expected if name in failed]
            compile_error = "error[" in out or "could not compile" in out
            ok = bool(red) and not compile_error
            results.append((label, ok))
            print("%-48s %s  red=%s" % (label, "BIT" if ok else "NO EFFECT", red or failed[:4]))
            if not ok:
                if compile_error:
                    print("   !! the mutation did not compile; it proves nothing")
                print("   output tail:\n", out[-1200:])
        finally:
            shutil.move(str(backup), str(path))
            os.utime(path, None)
            assert digest(path) == originals[key], "%s: restore did not reproduce the file" % label

    print("\n== summary ==")
    for label, ok in results:
        print("%-48s %s" % (label, "bit" if ok else "DID NOT BIT"))
        if not ok:
            bad = True
    print("all mutations bit:", not bad)
    sys.exit(1 if bad else 0)


if __name__ == "__main__":
    main()
