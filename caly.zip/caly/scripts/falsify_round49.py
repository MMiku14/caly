"""Falsification harness for round 49 (the maintenance pair `system.gc-plan`/`system.gc` and
the bundle pair `diagnostics.support-bundle`/`diagnostics.support-bundle-read` on the wire).

Same discipline as rounds 16/32–48: one mutation per run, exact-anchor replacement with
`assert count == 1`, restore by content and mtime, sha256-verified, stale `*.r49bak` swept at
startup. A mutation that cannot compile proves nothing (`§4.112`). Backups are taken **per
mutation** (`§4.137`).

Six mutations: `system.gc-plan` dropped from the whitelist, a plan count that lies about its
lines, the gc command swallowing its bounds records (the door refusal disappears), a bundle
read that always says `truncated: false`, a bundle read that swallows the digest record (a
bogus digest would quietly return the newest bundle instead of a refusal), and the CLI hiding
`would_run`.

Usage: `python3 scripts/falsify_round49.py` (exit 0 = every mutation bit, every file restored).
"""

import hashlib
import os
import pathlib
import shutil
import subprocess
import sys

ROOT = pathlib.Path("/home/user/caly")
ENV = dict(os.environ)
ENV["PATH"] = str(pathlib.Path.home() / ".cargo/bin") + ":" + ENV.get("PATH", "")
SRC = {
    "daemon": ROOT / "crates/caly-daemon/src/bin/calyd.rs",
    "cli": ROOT / "crates/caly-cli/src/bin/caly.rs",
}

MUTATIONS = [
    (
        "M1 system.gc-plan drops off the whitelist",
        "daemon",
        '                    "system.gc-plan" => Operation::System(SystemOp::GcPlan {',
        '                    "system.gc-plan-x" => Operation::System(SystemOp::GcPlan {',
        [
            "a_gc_plan_asked_twice_changes_nothing_but_the_clock",
            "caly_gc_plan_matches_an_independent_oracle",
        ],
    ),
    (
        "M2 collect_count lies about its lines",
        "daemon",
        '        ("collect_count".to_owned(), view.collect.len().to_string()),',
        '        ("collect_count".to_owned(), (view.collect.len() + 1).to_string()),',
        [
            "a_gc_plan_asked_twice_changes_nothing_but_the_clock",
            "caly_gc_plan_matches_an_independent_oracle",
        ],
    ),
    (
        "M3 the gc command swallows its bounds records",
        "daemon",
        """                    "system.gc" => Operation::System(SystemOp::CollectGarbage {
                        request: caly_api::GcCollectRequest {
                            grace_period_ms: wire_field(&records, "grace_period_ms")
                                .and_then(|v| v.parse().ok()),
                            max_deletions: wire_field(&records, "max_deletions")
                                .and_then(|v| v.parse().ok()),
                        },
                    }),""",
        """                    "system.gc" => Operation::System(SystemOp::CollectGarbage {
                        request: caly_api::GcCollectRequest::new(),
                    }),""",
        [
            "a_gc_command_is_keyed_bounded_at_the_door_and_replays",
        ],
    ),
    (
        "M4 a bundle read always says truncated: false",
        "daemon",
        '        ("truncated", view.truncated.to_string()),',
        '        ("truncated", "false".to_owned()),',
        [
            "a_bundle_export_reports_its_digest_and_reads_back_honestly",
            "caly_bundle_exports_and_reads_back_with_honest_bounds",
        ],
    ),
    (
        "M5 a bundle read swallows the digest record",
        "daemon",
        '                                digest: wire_field(&records, "digest").map(str::to_owned),',
        "                                digest: None,",
        [
            "a_bundle_export_reports_its_digest_and_reads_back_honestly",
        ],
    ),
    (
        "M6 the CLI hides would_run",
        "cli",
        """        "would_run",
        "refusal",""",
        """        "refusal",""",
        [
            "caly_gc_plan_matches_an_independent_oracle",
        ],
    ),
]


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def run_cargo():
    proc = subprocess.run(
        [
            "cargo",
            "test",
            "-p",
            "caly-daemon",
            "--test",
            "calyd_wire",
            "-p",
            "caly-cli",
            "--test",
            "caly_cli_e2e",
            "--no-fail-fast",
        ],
        cwd=str(ROOT),
        env=ENV,
        capture_output=True,
        text=True,
    )
    out = proc.stdout + proc.stderr
    failed = sorted(
        {
            line[5:].split(" ... ")[0].split("::")[-1].strip()
            for line in out.splitlines()
            if line.startswith("test ") and line.rstrip().endswith("... FAILED")
        }
    )
    return proc.returncode, failed, out


def main():
    for path in ROOT.rglob("*.r49bak"):
        original = pathlib.Path(str(path)[: -len(".r49bak")])
        shutil.move(str(path), str(original))
        print("swept leftover backup:", path.name)

    originals = {name: digest(path) for name, path in SRC.items()}
    results = []
    bad = False
    for label, key, old, new, expected in MUTATIONS:
        path = SRC[key]
        backup = pathlib.Path(str(path) + ".r49bak")
        shutil.copyfile(path, backup)  # per-mutation backup (§4.137)
        s = path.read_text()
        assert s.count(old) == 1, "%s: anchor x%d" % (label, s.count(old))
        try:
            path.write_text(s.replace(old, new, 1))
            code, failed, out = run_cargo()
            red = [name for name in expected if name in failed]
            compile_error = "error[" in out or "could not compile" in out
            ok = bool(red) and not compile_error
            results.append((label, ok))
            print("%-52s %s  red=%s" % (label, "BIT" if ok else "NO EFFECT", red or failed[:4]))
            if not ok:
                if compile_error:
                    print("   !! the mutation did not compile; it proves nothing")
                print("   output tail:\n", out[-1200:])
        finally:
            shutil.move(str(backup), str(path))
            os.utime(path, None)
            assert digest(path) == originals[key], "%s: restore did not reproduce the file" % label

    print("\n== summary ==")
    for label, ok in results:
        print("%-52s %s" % (label, "bit" if ok else "DID NOT BIT"))
        if not ok:
            bad = True
    print("all mutations bit:", not bad)
    sys.exit(1 if bad else 0)


if __name__ == "__main__":
    main()
