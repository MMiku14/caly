#!/usr/bin/env python3
"""Round 82 falsification harness.

The claim: `docs/ERRORS.md` §4's stable codes and §5.x's usage rules cover each other
exactly, judged by `caly-api/tests/error_doc.rs`:

- M1 (must bite)  a rule-section drift: §5.7's heading loses its code name (TIMEOUT ->
    TIMEOUTX) — the coverage judge goes red (TIMEOUT has no rules, TIMEOUTX is not a
    stable code).
- M2 (must bite)  a reserved-code promotion through the back door: a §5.11 CANCELLED
    rule section appears — the judge goes red (ten sections only, and CANCELLED is not
    a §4 stable code).

Usage: `python3 scripts/falsify_round82.py` (exit 0 = all bit, files restored).
Restore bumps mtime (stale-fingerprint bomb; R79.5.1).
"""

import hashlib
import os
import pathlib
import shutil
import subprocess
import sys
import time

ROOT = pathlib.Path("/home/user/caly_extract/caly")
ENV = dict(os.environ)
ENV["PATH"] = str(pathlib.Path.home() / ".cargo/bin") + ":" + ENV.get("PATH", "")

DOC = ROOT / "docs/ERRORS.md"

JUDGE = ["cargo", "test", "-q", "-p", "caly-api", "--test", "error_doc"]
JUDGE_TIMEOUT_SECS = 300


def digest(path):
    return hashlib.sha256(pathlib.Path(path).read_bytes()).hexdigest()


def sweep_strays():
    for path in ROOT.rglob("*.r82bak"):
        print(f"  note  sweeping stale {path}")
        path.unlink()


def run_judge():
    begin = time.time()
    proc = subprocess.Popen(
        JUDGE, cwd=ROOT, env=ENV,
        stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
        text=True, start_new_session=True,
    )
    try:
        out, _ = proc.communicate(timeout=JUDGE_TIMEOUT_SECS)
    except subprocess.TimeoutExpired:
        os.killpg(proc.pid, 9)
        proc.wait()
        return None, time.time() - begin, "HANG"
    ok = "0 failed" in (out or "") and "test result: ok" in (out or "")
    return ok, time.time() - begin, ""


def apply_one(path, needle, replacement):
    text = path.read_text()
    assert text.count(needle) == 1, f"{path}: needle not unique: {needle!r}"
    bak = pathlib.Path(str(path) + ".r82bak")
    shutil.copy2(path, bak)
    path.write_text(text.replace(needle, replacement))


def restore_one(path):
    bak = pathlib.Path(str(path) + ".r82bak")
    if bak.exists():
        shutil.copy2(bak, path)
        bak.unlink()
        os.utime(path, None)


M1_OLD = "### 5.7 `TIMEOUT`"
M1_NEW = "### 5.7 `TIMEOUTX`"

M2_OLD = "## 6. Redaction 规则"
M2_NEW = "### 5.11 `CANCELLED`\n\n对 `CANCELLED` 的使用规则（示例）。\n\n---\n\n## 6. Redaction 规则"


def main():
    sweep_strays()
    results = []

    apply_one(DOC, M1_OLD, M1_NEW)
    ok, secs, note = run_judge()
    results.append(("M1", "§5.7's heading loses its code (must bite)", ok, secs, note))
    restore_one(DOC)

    apply_one(DOC, M2_OLD, M2_NEW)
    ok, secs, note = run_judge()
    results.append(("M2", "a §5.11 rule section appears for CANCELLED (must bite)", ok, secs, note))
    restore_one(DOC)

    all_bite = True
    for name, label, bit, secs, note in results:
        if note:
            print(f"  {'ok' if not bit else 'MISS'}    {name} {label} ({note} in {secs:.1f}s)")
        else:
            print(f"  {'ok' if not bit else 'MISS'}    {name} {label} (bite in {secs:.1f}s)")
        if bit:
            all_bite = False

    print(f"restored: doc={digest(DOC)[:12]}…")
    print("all mutations behaved as predicted: " + ("True" if all_bite else "False"))
    sys.exit(0 if all_bite else 1)


if __name__ == "__main__":
    main()
