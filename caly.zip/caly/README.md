# Caly

**Mihomo / sing-box 的控制平面（control plane）**——把代理配置当成「可审计、可回滚、可恢复的部署事务」来管理。

```text
不可信输入（多源订阅/补丁）
  → 统一语义 IR → 冲突与能力约束 → 确定性原生产物
  → 最小代价部署计划 → 可补偿执行 → 可证明恢复
```

- 形态：守护进程 `calyd`（唯一状态所有者）+ 无状态 CLI `caly`（wire 客户端）+ 规划中的 TUI。
- 面向：网关 / 服务器 / 无头环境；可脚本、可 CI、可多客户端远程操作。
- **不是**桌面 GUI 客户端（定位对比见 `docs/guides/FEATURES.md §0`）。
- 代码：Rust workspace，20 个 crate，直接外部依赖仅 `serde_json`（ADR-046 授权）。
- 状态快照与缺口：`docs/status/IMPLEMENTATION_STATUS.md`、`docs/status/ROADMAP.md`。

## 快速开始

```bash
# 1. 工具链（rust-toolchain.toml 已钉 stable + rustfmt + clippy）
curl -sSf https://sh.rustup.rs | sh -s -- -y --profile minimal --default-toolchain stable
rustup component add rustfmt clippy

# 2. 钉死资产（真核 e2e 测试需要；不入 git，按 sha256 校验，见 scripts/fetch_assets.sh）
bash scripts/fetch_assets.sh

# 3. 构建
cargo build --workspace

# 4. 起守护进程（默认 simulated 运行时；真实内核用 --effect-runtime real 显式 opt-in）
./target/debug/calyd --data-dir var/caly --port-file var/caly.port

# 5. 另一个终端里用 CLI 操作（CLI 从 port-file 读监听点）
./target/debug/caly status
./target/debug/caly jobs          # 部署作业列表
./target/debug/caly job <id>      # 单个作业（含事件分页）
```

运行本地门禁（与 CI 同一套）：

```bash
bash scripts/check.sh
python3 scripts/regenerate_test_census.py --check
python3 scripts/regenerate_doc_index.py --check
```

systemd 部署见 `docs/guides/DEPLOYMENT_SYSTEMD.md`（unit 工件在 `packaging/systemd/`）。

## 文档地图

入口：`docs/README.md`（总索引，含文档树与阅读路径）。

| 想回答的问题 | 去哪里 |
|---|---|
| caly 现在能做什么、还差什么 | `docs/guides/FEATURES.md` |
| 系统边界与外部契约（最高权威） | `docs/rfcs/`（RFC-0001 ~ RFC-0010） |
| 为什么这么设计 | `docs/adrs/`（ADR-011 ~ ADR-057） |
| 现在实现在哪、缺口在哪 | `docs/status/`（IMPLEMENTATION_STATUS / ROADMAP / CENTERLINE_PROGRESS） |
| 怎么接续开发 | `docs/guides/DEVELOPMENT_WORKFLOW.md` |
| 历轮踩坑与决策留档 | `docs/history/`（接手笔记 + 逐轮日志 + 被取代的旧规格） |

## 开发

- 开发范式：`docs/guides/DEVELOPMENT_WORKFLOW.md`（分支模型、提交规范、七步循环、门禁清单）。
- CI：`.github/workflows/ci.yml`——与本地 `scripts/check.sh` 完全一致，`main` 永远绿。
- 变更记录：根 `CHANGELOG.md`；逐轮明细在 `docs/history/logs/`。
- 基线说明：根目录 `caly.zip` 是上游交付基线（已解包入库），保留但不再跟踪。

## 许可证

Apache-2.0 OR MIT（见 `Cargo.toml`）。
