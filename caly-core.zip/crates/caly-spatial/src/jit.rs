//! ROBDD-to-Native JIT Machine Code Compiler.
//!
//! Compiles a reduced ROBDD routing graph into native x86_64 machine
//! code.
//!
//! # Supported predicates
//!
//! The JIT supports exactly four predicate shapes, chosen because each
//! maps to a single `cmp`/`test` on a field of [`RouteQueryContext`]:
//!
//! * `Port(u16)`       — `cmp word ptr [rdi + 4], imm16`
//! * `PortRange(a, b)` — two `cmp`s with range bounds
//! * `Protocol(p)`     — `cmp byte ptr [rdi + 6], imm8`
//! * `IpCidr(V4, len)` — `mov eax, [rdi]; and eax, mask; cmp eax, net`
//!
//! Every other predicate (`DomainSuffix`, `DomainKeyword`, `Process`,
//! `DnsIpCidr`, `IpCidr(V6, _)`) causes the emitter to terminate the
//! current basic block with a sentinel
//! `mov eax, 0x8000_0000 | node_id; ret`. `execute_raw` returns that
//! `u32` unchanged, and [`crate::router::SpatialRouter::route`] resumes
//! the BDD from `node_id`. This is what lets a rule set containing a
//! single domain rule still benefit from JIT compilation of its
//! numeric prefixes.
//!
//! # Why `RouteQueryContext` has no pointers
//!
//! An earlier revision stored `*const u8` pointers to the caller's
//! `domain` / `process` strings. Because `RouteQueryContext` has no
//! lifetime parameter, safe code could construct one, drop the source
//! strings, and then hand the context to `execute_interpreter` — a
//! use-after-free reachable from safe Rust. The struct now carries only
//! the numeric fields the JIT actually reads. Domain- and
//! process-sensitive predicates are evaluated by the BDD pass in
//! [`crate::router`], which receives them through the borrowed
//! `EvaluationContext` where the borrow checker can enforce their
//! lifetime.

use crate::bdd::{BddEngine, BddNode, NodeId, Predicate, Protocol, TERMINAL_FALSE, TERMINAL_TRUE};
use crate::error::Result;
#[cfg(all(target_arch = "x86_64", target_os = "linux", not(miri)))]
use crate::error::SpatialError;
use crate::router::RouteQuery;
#[cfg(all(target_arch = "x86_64", target_os = "linux", not(miri)))]
use std::collections::{HashMap, HashSet, VecDeque};
use std::net::IpAddr;

/// C-ABI context passed to JIT-compiled code.
///
/// On x86_64 System V AMD64, the pointer arrives in `rdi`; the compiler
/// emits loads relative to that register. Field offsets are part of the
/// JIT's ABI and are asserted below at compile time. Reordering fields
/// without updating the emitter would silently desynchronize the two.
///
/// The struct is deliberately `Copy` and free of pointers: it can be
/// constructed from a [`RouteQuery`] without borrowing the query's
/// strings, so no lifetime parameter is needed and no use-after-free is
/// possible from safe code.
#[repr(C, align(8))]
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub struct RouteQueryContext {
    /// Offset 0: IPv4 destination in host byte order.
    pub ipv4: u32,
    /// Offset 4: TCP/UDP destination port.
    pub port: u16,
    /// Offset 6: IP protocol number (6=TCP, 17=UDP, 1=ICMP, ...).
    pub protocol: u8,
    /// Offset 7: 1 if `ipv6` holds the destination, 0 for IPv4.
    pub ip_is_v6: u8,
    /// Offset 8: IPv6 destination octets (network byte order).
    pub ipv6: [u8; 16],
}

const _: () = assert!(std::mem::size_of::<RouteQueryContext>() == 24);
const _: () = assert!(std::mem::align_of::<RouteQueryContext>() == 8);
const _: () = assert!(std::mem::offset_of!(RouteQueryContext, ipv4) == 0);
const _: () = assert!(std::mem::offset_of!(RouteQueryContext, port) == 4);
const _: () = assert!(std::mem::offset_of!(RouteQueryContext, protocol) == 6);
const _: () = assert!(std::mem::offset_of!(RouteQueryContext, ip_is_v6) == 7);
const _: () = assert!(std::mem::offset_of!(RouteQueryContext, ipv6) == 8);

impl RouteQueryContext {
    /// Builds an all-zero context: IPv4 `0.0.0.0`, port 0, protocol 0.
    #[inline(always)]
    pub fn new() -> Self {
        Self {
            ipv4: 0,
            port: 0,
            protocol: 0,
            ip_is_v6: 0,
            ipv6: [0; 16],
        }
    }

    /// Private helper: install an IP and set `ip_is_v6` accordingly.
    #[inline]
    fn set_ip(&mut self, ip: IpAddr) {
        match ip {
            IpAddr::V4(v4) => {
                self.ipv4 = u32::from(v4);
                self.ip_is_v6 = 0;
            }
            IpAddr::V6(v6) => {
                self.ipv6 = v6.octets();
                self.ip_is_v6 = 1;
            }
        }
    }

    /// Builds a context from an IP, port, and protocol.
    pub fn from_ip_port(ip: IpAddr, port: u16, protocol: Protocol) -> Self {
        let mut ctx = Self::new();
        ctx.port = port;
        ctx.protocol = protocol.as_u8();
        ctx.set_ip(ip);
        ctx
    }

    /// Builds a context from a [`RouteQuery`], copying the numeric
    /// fields. `domain` and `process` are intentionally ignored: the JIT
    /// cannot evaluate them, and storing pointers to them would make
    /// this function unsound under a safe signature.
    pub fn from_query(q: &RouteQuery<'_>) -> Self {
        let mut ctx = Self::new();
        ctx.port = q.port;
        ctx.protocol = q.protocol.as_u8();
        if let Some(ip) = q.ip {
            ctx.set_ip(ip);
        }
        ctx
    }
}

impl Default for RouteQueryContext {
    fn default() -> Self {
        Self::new()
    }
}

/// IPv4 netmask for `prefix_len` leading bits. `prefix_len` must be ≤ 32.
#[inline]
fn ipv4_mask(prefix_len: u32) -> u32 {
    if prefix_len == 0 {
        0
    } else {
        (!0u32) << (32 - prefix_len)
    }
}

/// JIT-compiled native machine code routing engine.
pub struct BddJitCompiler {
    #[cfg(all(target_arch = "x86_64", target_os = "linux", not(miri)))]
    exec_ptr: *const u8,
    #[cfg(all(target_arch = "x86_64", target_os = "linux", not(miri)))]
    exec_size: usize,

    // Interpreter fallback state. Also used on non-x86_64 platforms and
    // under Miri, where the emitter is disabled but `execute_interpreter`
    // must still answer correctly.
    nodes: Vec<BddNode>,
    predicates: Vec<Predicate>,
    root: NodeId,
    default_action: u16,
}

// SAFETY: `BddJitCompiler` owns an mmap'd code region plus plain data.
// The region is written once during `compile` and never mutated
// afterwards; `execute_raw` calls it read-only from any thread.
unsafe impl Send for BddJitCompiler {}
unsafe impl Sync for BddJitCompiler {}

impl Drop for BddJitCompiler {
    fn drop(&mut self) {
        #[cfg(all(target_arch = "x86_64", target_os = "linux", not(miri)))]
        if !self.exec_ptr.is_null() && self.exec_size > 0 {
            // SAFETY: `exec_ptr`/`exec_size` are exactly the values
            // returned by the `mmap` in `alloc_exec_memory`; nothing
            // else has unmapped them.
            let r = unsafe { libc::munmap(self.exec_ptr as *mut libc::c_void, self.exec_size) };
            if r != 0 {
                eprintln!(
                    "caly-spatial: BddJitCompiler::drop munmap failed: {}",
                    std::io::Error::last_os_error()
                );
            }
            self.exec_ptr = std::ptr::null();
            self.exec_size = 0;
        }
    }
}

// ─────────────────────────────────────────────────────────────────────────
// x86_64 emitter
// ─────────────────────────────────────────────────────────────────────────

#[cfg(all(target_arch = "x86_64", target_os = "linux", not(miri)))]
#[derive(Clone, Copy, Debug)]
struct BranchFixup {
    /// Offset of the 4-byte rel32 field, relative to the start of `code`.
    code_offset: usize,
    /// BDD node id whose emitted entry offset the rel32 must reach.
    target_node: NodeId,
}

/// Linear x86_64 code buffer with deferred rel32 fixups.
///
/// The emitter is intentionally a thin wrapper over `Vec<u8>` + a fixup
/// list; every `jcc`/`jmp` records a `BranchFixup` instead of computing a
/// displacement, so the emitter does not need to know the final layout.
/// A single pass through [`CodeEmitter::resolve`] patches them all once
/// every BDD node has an entry offset.
#[cfg(all(target_arch = "x86_64", target_os = "linux", not(miri)))]
struct CodeEmitter {
    code: Vec<u8>,
    fixups: Vec<BranchFixup>,
}

#[cfg(all(target_arch = "x86_64", target_os = "linux", not(miri)))]
impl CodeEmitter {
    fn with_capacity(cap: usize) -> Self {
        Self {
            code: Vec::with_capacity(cap),
            fixups: Vec::new(),
        }
    }

    #[inline]
    fn len(&self) -> usize {
        self.code.len()
    }

    #[inline]
    fn bytes(&mut self, b: &[u8]) {
        self.code.extend_from_slice(b);
    }

    #[inline]
    fn byte(&mut self, b: u8) {
        self.code.push(b);
    }

    #[inline]
    fn u16(&mut self, v: u16) {
        self.code.extend_from_slice(&v.to_le_bytes());
    }

    #[inline]
    fn u32(&mut self, v: u32) {
        self.code.extend_from_slice(&v.to_le_bytes());
    }

    /// Emits a rel32 branch: opcode bytes (including any `0f` prefix)
    /// followed by a 4-byte placeholder, registering a fixup to `target`.
    #[inline]
    fn branch(&mut self, opcode: &[u8], target: NodeId) {
        self.code.extend_from_slice(opcode);
        let code_offset = self.code.len();
        self.code.extend_from_slice(&[0, 0, 0, 0]);
        self.fixups.push(BranchFixup {
            code_offset,
            target_node: target,
        });
    }

    #[inline]
    fn je(&mut self, target: NodeId)  { self.branch(&[0x0f, 0x84], target); }
    #[inline]
    fn jne(&mut self, target: NodeId) { self.branch(&[0x0f, 0x85], target); }
    #[inline]
    fn jb(&mut self, target: NodeId)  { self.branch(&[0x0f, 0x82], target); }
    #[inline]
    fn ja(&mut self, target: NodeId)  { self.branch(&[0x0f, 0x87], target); }
    #[inline]
    fn jmp(&mut self, target: NodeId) { self.branch(&[0xe9], target); }

    /// Emits `mov eax, imm32; pop rbp; ret`.
    ///
    /// The `pop rbp` mirrors the `push rbp` in the compiled prologue so
    /// the stack is balanced on return. `imm32` is loaded sign-agnostic
    /// (`mov eax, imm32` zero-extends to `rax`), which is fine because
    /// `execute_raw` only consumes the low 32 bits.
    fn mov_eax_ret(&mut self, imm32: u32) {
        self.byte(0xb8);
        self.u32(imm32);
        self.byte(0x5d); // pop rbp
        self.byte(0xc3); // ret
    }

    /// Second pass: patch every recorded branch to its target node.
    fn resolve(&mut self, node_offsets: &HashMap<NodeId, usize>) -> Result<()> {
        for fixup in &self.fixups {
            let target_offset = node_offsets.get(&fixup.target_node).ok_or_else(|| {
                SpatialError::Internal(format!(
                    "Unresolved JIT target node: {}",
                    fixup.target_node,
                ))
            })?;
            // rel32 is measured from the byte *after* the branch's 4-byte
            // operand.
            let next_inst = (fixup.code_offset + 4) as isize;
            let rel = *target_offset as isize - next_inst;
            if rel < i32::MIN as isize || rel > i32::MAX as isize {
                return Err(SpatialError::Internal(format!(
                    "JIT rel32 overflow: target={target_offset}, next={next_inst}, rel={rel}",
                )));
            }
            self.code[fixup.code_offset..fixup.code_offset + 4]
                .copy_from_slice(&(rel as i32).to_le_bytes());
        }
        Ok(())
    }

    /// Emits the comparison + branch sequence for a single BDD decision.
    ///
    /// Every predicate shape ends the same way: a `je` to `high`, then a
    /// `jmp` to `low`. Both branches are recorded as rel32 fixups; the
    /// caller resolves them once every node has an entry offset.
    ///
    /// Predicates this JIT cannot evaluate terminate the block with a
    /// layered-compilation sentinel instead.
    fn emit_predicate(&mut self, node_id: NodeId, pred: &Predicate, high: NodeId, low: NodeId) {
        match pred {
            Predicate::Port(p) => {
                // `cmp word ptr [rdi + 4], imm16`
                self.bytes(&[0x66, 0x81, 0x7f, 0x04]);
                self.u16(*p);
                self.je(high);
                self.jmp(low);
            }
            Predicate::PortRange(min_p, max_p) => {
                // `movzx eax, word ptr [rdi + 4]`
                self.bytes(&[0x0f, 0xb7, 0x47, 0x04]);

                // `cmp eax, imm32(min)` + `jb low`
                self.byte(0x3d);
                self.u32(*min_p as u32);
                self.jb(low);

                // `cmp eax, imm32(max)` + `ja low`
                self.byte(0x3d);
                self.u32(*max_p as u32);
                self.ja(low);

                // `jmp high`
                self.jmp(high);
            }
            Predicate::Protocol(proto) => {
                // `cmp byte ptr [rdi + 6], imm8`
                self.bytes(&[0x80, 0x7f, 0x06, proto.as_u8()]);
                self.je(high);
                self.jmp(low);
            }
            Predicate::IpCidr(IpAddr::V4(v4), prefix_len) => {
                // `cmp byte ptr [rdi + 7], 0` + `jne low`
                //
                // The JIT only handles IPv4 CIDRs, so an IPv6 query must
                // fall through to the low branch.
                self.bytes(&[0x80, 0x7f, 0x07, 0x00]);
                self.jne(low);

                let v4_u32 = u32::from(*v4);
                let mask = ipv4_mask(*prefix_len as u32);
                let net = v4_u32 & mask;

                if *prefix_len == 32 {
                    // `/32`: compare the whole word directly.
                    // `cmp dword ptr [rdi], imm32`
                    self.bytes(&[0x81, 0x7f, 0x00]);
                    self.u32(net);
                } else {
                    // `mov eax, [rdi]; and eax, imm32; cmp eax, imm32`
                    self.bytes(&[0x8b, 0x47, 0x00]);
                    self.byte(0x25);
                    self.u32(mask);
                    self.byte(0x3d);
                    self.u32(net);
                }

                self.je(high);
                self.jmp(low);
            }
            _ => {
                // Layered compilation: this node uses a predicate the
                // JIT cannot evaluate. Emit a trampoline that returns
                // the sentinel `0x8000_0000 | node_id`; `execute_raw`
                // forwards it and `SpatialRouter::route` resumes the
                // BDD from that node.
                debug_assert!(
                    (node_id & 0x8000_0000) == 0,
                    "node_id overflow for JIT sentinel: {node_id:#x}",
                );
                let sentinel: u32 = 0x8000_0000 | (node_id & 0x7FFF_FFFF);
                self.mov_eax_ret(sentinel);
            }
        }
    }
}

// ─────────────────────────────────────────────────────────────────────────
// BddJitCompiler
// ─────────────────────────────────────────────────────────────────────────

impl BddJitCompiler {
    /// Compiles an ROBDD graph into native machine code.
    ///
    /// On non-x86_64 (or when the target disables JIT, e.g. Miri or
    /// non-Linux), only the interpreter state is populated;
    /// `execute_raw` returns 0 and `execute_interpreter` remains the
    /// effective implementation.
    pub fn compile(engine: &BddEngine, root: NodeId, default_action: u16) -> Result<Self> {
        // Snapshot the engine's immutable data up front. The compiler
        // never touches `engine` again, so the rest of `self` is
        // independent of the BDD's lifetime.
        let nodes = engine.get_nodes().to_vec();
        let predicates = engine.get_predicates().to_vec();

        #[cfg(all(target_arch = "x86_64", target_os = "linux", not(miri)))]
        {
            let mut emit = CodeEmitter::with_capacity(512);

            // System V AMD64 prologue: push rbp; mov rbp, rsp. The frame
            // pointer lets `perf --call-graph fp` unwind through JIT
            // frames, which is invaluable when a routing hot path shows
            // up in a profile.
            emit.bytes(&[0x55, 0x48, 0x89, 0xE5]);

            let mut node_offsets: HashMap<NodeId, usize> = HashMap::new();
            let mut visited: HashSet<NodeId> = HashSet::new();
            let mut queue: VecDeque<NodeId> = VecDeque::new();

            queue.push_back(root);
            visited.insert(root);

            while let Some(node_id) = queue.pop_front() {
                node_offsets.insert(node_id, emit.len());

                // Boolean terminals (False/True) are never routed here
                // by a well-formed BDD; they carry no action and must
                // resolve to the default. Same for out-of-range nodes.
                // Guard defensively.
                if node_id == TERMINAL_FALSE || node_id == TERMINAL_TRUE {
                    emit.mov_eax_ret(default_action as u32);
                    continue;
                }

                let node = match nodes.get(node_id as usize) {
                    Some(&n) => n,
                    None => {
                        emit.mov_eax_ret(default_action as u32);
                        continue;
                    }
                };

                match node {
                    BddNode::Terminal(action) => emit.mov_eax_ret(action as u32),
                    BddNode::Decision { var, low, high } => {
                        // Enqueue children before emitting the parent's
                        // jump so their entry offsets are recorded by
                        // the time the fixup pass runs.
                        if visited.insert(high) {
                            queue.push_back(high);
                        }
                        if visited.insert(low) {
                            queue.push_back(low);
                        }

                        let pred = &predicates[var.raw() as usize];
                        emit.emit_predicate(node_id, pred, high, low);
                    }
                }
            }

            emit.resolve(&node_offsets)?;

            // SAFETY: `emit.code` is a fully-formed x86_64 instruction
            // sequence whose entry point follows the System V AMD64 ABI
            // (`rdi` in, `eax` out). `alloc_exec_memory` copies it into
            // a fresh R+W page and re-protects that page R+X before
            // returning.
            let (exec_ptr, exec_size) = unsafe { Self::alloc_exec_memory(&emit.code)? };

            Ok(Self {
                exec_ptr,
                exec_size,
                nodes,
                predicates,
                root,
                default_action,
            })
        }

        #[cfg(not(all(target_arch = "x86_64", target_os = "linux", not(miri))))]
        {
            Ok(Self {
                nodes,
                predicates,
                root,
                default_action,
            })
        }
    }

    /// Cached page size; `sysconf(_SC_PAGESIZE)` is only called once.
    #[cfg(all(target_arch = "x86_64", target_os = "linux", not(miri)))]
    #[inline]
    fn page_size() -> usize {
        use std::sync::OnceLock;
        static PAGE_SIZE: OnceLock<usize> = OnceLock::new();
        *PAGE_SIZE.get_or_init(|| {
            // SAFETY: `sysconf` is safe to call at any time on POSIX.
            let sz = unsafe { libc::sysconf(libc::_SC_PAGESIZE) } as usize;
            if sz == 0 { 4096 } else { sz }
        })
    }

    /// Allocates an executable page, copies `code` into it, and flips it
    /// to read+execute.
    ///
    /// # Safety
    ///
    /// `code` must be a valid x86_64 instruction stream; the caller is
    /// responsible for emitting well-formed instructions whose entry
    /// point obeys the System V AMD64 ABI.
    #[cfg(all(target_arch = "x86_64", target_os = "linux", not(miri)))]
    unsafe fn alloc_exec_memory(code: &[u8]) -> Result<(*const u8, usize)> {
        // SAFETY: forwarded to the caller for the "well-formed
        // instructions" part; the mmap/mprotect sequence below is
        // self-contained and returns a pointer whose lifetime is owned
        // by the resulting `BddJitCompiler`.
        unsafe {
            let page = Self::page_size();
            let size = code.len().div_ceil(page).max(1) * page;

            let ptr = libc::mmap(
                std::ptr::null_mut(),
                size,
                libc::PROT_READ | libc::PROT_WRITE,
                libc::MAP_ANONYMOUS | libc::MAP_PRIVATE,
                -1,
                0,
            );
            if ptr == libc::MAP_FAILED {
                return Err(SpatialError::Internal(
                    "mmap failed for JIT code page".into(),
                ));
            }

            std::ptr::copy_nonoverlapping(code.as_ptr(), ptr as *mut u8, code.len());

            if libc::mprotect(ptr, size, libc::PROT_READ | libc::PROT_EXEC) != 0 {
                libc::munmap(ptr, size);
                return Err(SpatialError::Internal(
                    "mprotect failed to set executable permissions".into(),
                ));
            }

            Ok((ptr as *const u8, size))
        }
    }

    /// Runs the JIT-compiled code and returns the raw action code.
    ///
    /// * `bit 31 == 0`: low 16 bits are an action code. The router
    ///   resolves it via its action table.
    /// * `bit 31 == 1`: low 31 bits are a BDD node id. The router must
    ///   resume BDD evaluation from that node (layered compilation).
    /// * `raw == 0`: no JIT body is available (interpreter-only build,
    ///   or the compile step was a no-op). Treated by the router as
    ///   "run the BDD pass from the root".
    #[inline]
    pub fn execute_raw(&self, ctx: &RouteQueryContext) -> u32 {
        #[cfg(all(target_arch = "x86_64", target_os = "linux", not(miri)))]
        if !self.exec_ptr.is_null() {
            // SAFETY: `exec_ptr` was produced by `compile`, which
            // guarantees a well-formed SysV-AMD64 function
            // `extern "C" fn(*const RouteQueryContext) -> u32`. The
            // signature matches `func` below exactly.
            let func: extern "C" fn(*const RouteQueryContext) -> u32 =
                unsafe { std::mem::transmute(self.exec_ptr) };
            return func(ctx as *const RouteQueryContext);
        }
        0
    }

    /// Convenience wrapper that discards the layered-compilation
    /// sentinel. When the JIT stops at an unsupported predicate,
    /// `execute` returns 0 (`ACTION_CODE_NO_MATCH`), signalling the
    /// router to fall back to the full BDD pass.
    #[inline]
    pub fn execute(&self, ctx: &RouteQueryContext) -> u16 {
        let raw = self.execute_raw(ctx);
        if (raw & 0x8000_0000) != 0 {
            0
        } else {
            raw as u16
        }
    }

    /// Interprets the BDD starting from an arbitrary node.
    ///
    /// Intended for debugging and for the layered-compilation fallback
    /// path; the production entry point is
    /// [`crate::router::SpatialRouter::route`].
    pub fn interpret_from(&self, node_id: u32, ctx: &RouteQueryContext) -> u16 {
        let mut curr = node_id;
        while curr != TERMINAL_FALSE && curr != TERMINAL_TRUE {
            if (curr as usize) >= self.nodes.len() {
                return self.default_action;
            }
            match self.nodes[curr as usize] {
                BddNode::Terminal(action) => return action,
                BddNode::Decision { var, low, high } => {
                    let pred = &self.predicates[var.raw() as usize];
                    curr = if Self::eval_predicate_ctx(pred, ctx) {
                        high
                    } else {
                        low
                    };
                }
            }
        }
        self.default_action
    }

    /// Interprets the BDD from the compiled root node.
    #[inline]
    pub fn execute_interpreter(&self, ctx: &RouteQueryContext) -> u16 {
        self.interpret_from(self.root as u32, ctx)
    }

    /// Evaluates a predicate against the pointer-free context.
    ///
    /// Domain- and process-bearing predicates always return `false`
    /// here: their inputs are not present in `RouteQueryContext`.
    /// `SpatialRouter::route` evaluates them in the BDD pass, where the
    /// borrowed `EvaluationContext` still has access to the original
    /// strings. This is the "layered compilation" contract in action.
    fn eval_predicate_ctx(pred: &Predicate, ctx: &RouteQueryContext) -> bool {
        match pred {
            Predicate::Port(p) => ctx.port == *p,
            Predicate::PortRange(min, max) => ctx.port >= *min && ctx.port <= *max,
            Predicate::Protocol(proto) => ctx.protocol == proto.as_u8(),
            Predicate::IpCidr(IpAddr::V4(v4), len) => {
                if ctx.ip_is_v6 != 0 {
                    return false;
                }
                let mask = ipv4_mask(*len as u32);
                (ctx.ipv4 & mask) == (u32::from(*v4) & mask)
            }
            Predicate::IpCidr(IpAddr::V6(v6), len) => {
                if ctx.ip_is_v6 == 0 {
                    return false;
                }
                let target = u128::from(*v6);
                let actual = u128::from_be_bytes(ctx.ipv6);
                let mask = if *len == 0 {
                    0
                } else {
                    (!0u128) << (128 - len)
                };
                (actual & mask) == (target & mask)
            }
            // The remaining predicates cannot be decided from the JIT
            // context alone; the BDD pass handles them.
            Predicate::DomainExact(_)
            | Predicate::DomainSuffix(_)
            | Predicate::DomainKeyword(_)
            | Predicate::Process(_)
            | Predicate::DnsIpCidr(_, _) => false,
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::net::Ipv4Addr;

    /// `RouteQueryContext` must round-trip every numeric field through
    /// `from_query` without retaining any borrow of the original query.
    /// The test deliberately drops the `RouteQuery` before inspecting
    /// the context; if `from_query` ever re-introduces a raw pointer to
    /// the query's strings, this test would become flaky under Miri.
    #[test]
    fn test_from_query_drops_no_pointers() {
        let ctx = {
            let query = RouteQuery::from_ip(
                IpAddr::V4(Ipv4Addr::new(10, 20, 30, 40)),
                8443,
                Protocol::Tcp,
            );
            RouteQueryContext::from_query(&query)
        };
        assert_eq!(ctx.port, 8443);
        assert_eq!(ctx.protocol, 6);
        assert_eq!(ctx.ipv4, u32::from(Ipv4Addr::new(10, 20, 30, 40)));
        assert_eq!(ctx.ip_is_v6, 0);
    }
}
