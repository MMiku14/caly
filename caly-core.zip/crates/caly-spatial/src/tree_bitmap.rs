//! IPv6 16-bit Stride Tree-Bitmap Lookup Engine with Segmented Sparse Bitmaps.
//! Features bitmask-accelerated O(1) prefix length jumping, normalized address insertion,
//! and sub-microsecond zero-heap lookup paths.

use crate::error::{Result, SpatialError};
use smallvec::SmallVec;
use std::net::Ipv6Addr;
use std::str::FromStr;

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub struct WordEntry {
    pub word_idx: u16,
    pub word: u64,
}

#[derive(Clone, Debug, PartialEq, Eq)]
pub struct SparseBitmap {
    pub entries: SmallVec<[WordEntry; 8]>,
}

pub type Bitmap64k = SparseBitmap;
pub type Bitmap128k = SparseBitmap;

impl Default for SparseBitmap {
    fn default() -> Self {
        Self::new()
    }
}

impl SparseBitmap {
    #[inline(always)]
    pub fn new() -> Self {
        Self {
            entries: SmallVec::new(),
        }
    }

    #[inline(always)]
    pub fn is_empty(&self) -> bool {
        self.entries.is_empty()
    }

    #[inline(always)]
    pub fn clear(&mut self) {
        self.entries.clear();
    }

    #[inline]
    pub fn total_count(&self) -> usize {
        self.entries
            .iter()
            .map(|e| e.word.count_ones() as usize)
            .sum()
    }

    #[inline]
    pub fn get(&self, bit: usize) -> bool {
        let word_idx = (bit >> 6) as u16;
        let bit_idx = bit & 63;
        match self.entries.binary_search_by_key(&word_idx, |e| e.word_idx) {
            Ok(i) => (self.entries[i].word & (1u64 << bit_idx)) != 0,
            Err(_) => false,
        }
    }

    pub fn set(&mut self, bit: usize) {
        let word_idx = (bit >> 6) as u16;
        let bit_idx = bit & 63;
        let mask = 1u64 << bit_idx;
        match self.entries.binary_search_by_key(&word_idx, |e| e.word_idx) {
            Ok(i) => {
                self.entries[i].word |= mask;
            }
            Err(pos) => {
                self.entries.insert(
                    pos,
                    WordEntry {
                        word_idx,
                        word: mask,
                    },
                );
            }
        }
    }

    #[inline]
    pub fn popcount_before(&self, bit: usize) -> usize {
        let target_word_idx = (bit >> 6) as u16;
        let bit_idx = bit & 63;
        let pos = self
            .entries
            .partition_point(|e| e.word_idx < target_word_idx);
        let mut count: usize = self.entries[..pos]
            .iter()
            .map(|e| e.word.count_ones() as usize)
            .sum();
        if let Some(entry) = self.entries.get(pos) {
            if entry.word_idx == target_word_idx && bit_idx > 0 {
                let mask = (1u64 << bit_idx) - 1;
                count += (entry.word & mask).count_ones() as usize;
            }
        }
        count
    }
}

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub struct TreeRouteEntry {
    pub action: u16,
    pub prefix_len: u8,
}

#[derive(Clone, Debug, PartialEq, Eq)]
pub struct TreeBitmapNode {
    pub internal_bitmap: SparseBitmap,
    pub child_bitmap: SparseBitmap,
    pub children: SmallVec<[u32; 8]>,
    pub results: SmallVec<[TreeRouteEntry; 8]>,
    pub present_lengths: u32,
}

impl Default for TreeBitmapNode {
    fn default() -> Self {
        Self::new()
    }
}

impl TreeBitmapNode {
    #[inline(always)]
    pub fn new() -> Self {
        Self {
            internal_bitmap: SparseBitmap::new(),
            child_bitmap: SparseBitmap::new(),
            children: SmallVec::new(),
            results: SmallVec::new(),
            present_lengths: 0,
        }
    }
}

pub struct TreeBitmap {
    nodes: Vec<TreeBitmapNode>,
    default_action: u16,
}

impl TreeBitmap {
    pub fn new(default_action: u16) -> Self {
        let mut nodes = Vec::with_capacity(16);
        nodes.push(TreeBitmapNode::new());
        Self {
            nodes,
            default_action,
        }
    }

    #[inline(always)]
    pub fn internal_bit_index(len: u8, val: u16) -> usize {
        let base = if len == 0 { 0usize } else { (1usize << len) - 1 };
        base + (val as usize)
    }

    pub fn insert(&mut self, addr: u128, prefix_len: u8, action: u16) -> Result<()> {
        if prefix_len > 128 {
            return Err(SpatialError::InvalidIpv6Prefix(prefix_len));
        }

        let mask = if prefix_len == 0 {
            0
        } else {
            !0u128 << (128 - prefix_len)
        };
        let normalized_addr = addr & mask;

        let mut current_node_idx = 0usize;
        let mut level = 0u8;

        loop {
            let stride_start_bit = level * 16;
            let bits_remaining = prefix_len.saturating_sub(stride_start_bit);

            if bits_remaining <= 16 {
                let shift = 128 - stride_start_bit - 16;
                let stride_chunk = ((normalized_addr >> shift) & 0xFFFF) as u16;
                let val = if bits_remaining == 0 {
                    0
                } else if bits_remaining == 16 {
                    stride_chunk
                } else {
                    stride_chunk >> (16 - bits_remaining)
                };

                let bit_idx = Self::internal_bit_index(bits_remaining, val);
                let already_set = self.nodes[current_node_idx].internal_bitmap.get(bit_idx);
                let pos = self.nodes[current_node_idx]
                    .internal_bitmap
                    .popcount_before(bit_idx);

                if already_set {
                    let entry = &mut self.nodes[current_node_idx].results[pos];
                    if prefix_len >= entry.prefix_len {
                        entry.action = action;
                        entry.prefix_len = prefix_len;
                    }
                } else {
                    self.nodes[current_node_idx].internal_bitmap.set(bit_idx);
                    self.nodes[current_node_idx].results.insert(
                        pos,
                        TreeRouteEntry {
                            action,
                            prefix_len,
                        },
                    );
                    self.nodes[current_node_idx].present_lengths |= 1u32 << bits_remaining;
                }
                return Ok(());
            } else {
                let shift = 128 - stride_start_bit - 16;
                let child_key = ((normalized_addr >> shift) & 0xFFFF) as u16;
                let child_exists = self.nodes[current_node_idx]
                    .child_bitmap
                    .get(child_key as usize);
                let child_pos = self.nodes[current_node_idx]
                    .child_bitmap
                    .popcount_before(child_key as usize);

                let next_node_idx = if child_exists {
                    self.nodes[current_node_idx].children[child_pos] as usize
                } else {
                    let new_node_idx = self.nodes.len() as u32;
                    self.nodes.push(TreeBitmapNode::new());
                    self.nodes[current_node_idx]
                        .child_bitmap
                        .set(child_key as usize);
                    self.nodes[current_node_idx]
                        .children
                        .insert(child_pos, new_node_idx);
                    new_node_idx as usize
                };
                current_node_idx = next_node_idx;
                level += 1;
            }
        }
    }

    pub fn insert_addr(&mut self, addr: Ipv6Addr, prefix_len: u8, action: u16) -> Result<()> {
        self.insert(u128::from(addr), prefix_len, action)
    }

    pub fn insert_cidr(&mut self, cidr: &str, action: u16) -> Result<()> {
        let (addr_part, prefix_part) = cidr.split_once('/').ok_or_else(|| {
            SpatialError::InvalidCidr(format!("{cidr}: expected exactly one '/'"))
        })?;
        if prefix_part.contains('/') {
            return Err(SpatialError::InvalidCidr(format!("{cidr}: multiple slashes")));
        }
        let addr = Ipv6Addr::from_str(addr_part)
            .map_err(|_| SpatialError::InvalidIp(addr_part.to_string()))?;
        let prefix_len: u8 = prefix_part.parse().map_err(|_| {
            SpatialError::InvalidCidr(format!("{cidr}: invalid prefix '{prefix_part}'"))
        })?;
        self.insert_addr(addr, prefix_len, action)
    }

    #[inline]
    pub fn lookup(&self, addr: u128) -> u16 {
        let mut current_node_idx = 0usize;
        let mut best_action = self.default_action;
        let mut best_prefix_len = 0u8;

        for level in 0..8u8 {
            let node = &self.nodes[current_node_idx];
            let shift = 112 - (level as usize * 16);
            let chunk = ((addr >> shift) & 0xFFFF) as u16;

            let mut active_lengths = node.present_lengths;
            while active_lengths != 0 {
                let len = 31 - active_lengths.leading_zeros() as u8;
                active_lengths &= !(1u32 << len);

                let val = if len == 16 {
                    chunk
                } else if len == 0 {
                    0
                } else {
                    chunk >> (16 - len)
                };

                let bit_idx = Self::internal_bit_index(len, val);
                if node.internal_bitmap.get(bit_idx) {
                    let pos = node.internal_bitmap.popcount_before(bit_idx);
                    let res = &node.results[pos];
                    let total_len = level * 16 + len;
                    if total_len >= best_prefix_len {
                        best_action = res.action;
                        best_prefix_len = total_len;
                    }
                    break;
                }
            }

            if node.child_bitmap.get(chunk as usize) {
                let child_pos = node.child_bitmap.popcount_before(chunk as usize);
                current_node_idx = node.children[child_pos] as usize;
            } else {
                break;
            }
        }
        best_action
    }

    #[inline(always)]
    pub fn lookup_addr(&self, addr: Ipv6Addr) -> u16 {
        self.lookup(u128::from(addr))
    }

    #[inline(always)]
    pub fn node_count(&self) -> usize {
        self.nodes.len()
    }
}

