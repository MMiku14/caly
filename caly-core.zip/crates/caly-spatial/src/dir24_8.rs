//! DIR-24-8 Hardware-level IPv4 Fast Lookup Engine.
//! Provides direct action resolution in 1 clock load for prefixes <= /24
//! and secondary resolution in 2 clock loads for prefixes /25..=/32.

use crate::error::{Result, SpatialError};
use std::net::Ipv4Addr;
use std::str::FromStr;

pub const TBL24_ENTRIES: usize = 1 << 24;
pub const TBL8_CHUNK_SIZE: usize = 256;
pub const TBL8_FLAG: u16 = 0x8000;
pub const ACTION_MASK: u16 = 0x7FFF;
pub const MAX_ACTION_CODE: u16 = 0x7FFF;
pub const MAX_TBL8_CHUNKS: usize = 0x8000;

const BATCH_FILL_THRESHOLD: usize = 256;

fn filled_boxed_slice<T: Clone>(len: usize, value: T, name: &str) -> Result<Box<[T]>> {
    let mut values = Vec::new();
    values
        .try_reserve_exact(len)
        .map_err(|e| SpatialError::Internal(format!("{name} try_reserve failed: {e}")))?;
    values.resize(len, value);
    Ok(values.into_boxed_slice())
}

fn parse_cidr(cidr: &str) -> Result<(Ipv4Addr, u8)> {
    let (addr_part, prefix_part) = cidr.split_once('/').ok_or_else(|| {
        SpatialError::InvalidCidr(format!("{cidr}: expected exactly one '/'"))
    })?;

    if prefix_part.contains('/') {
        return Err(SpatialError::InvalidCidr(format!(
            "{cidr}: multiple slashes"
        )));
    }

    let addr = Ipv4Addr::from_str(addr_part)
        .map_err(|_| SpatialError::InvalidIp(addr_part.to_string()))?;
    let prefix_len: u8 = prefix_part.parse().map_err(|_| {
        SpatialError::InvalidCidr(format!("{cidr}: prefix '{prefix_part}' is invalid"))
    })?;

    if prefix_len > 32 {
        return Err(SpatialError::InvalidIpv4Prefix(prefix_len));
    }

    Ok((addr, prefix_len))
}

/// # Safety
///
/// `tbl24_base` must point to a table containing at least `TBL24_ENTRIES`
/// consecutive `u16` entries.
#[inline(always)]
pub unsafe fn prefetch_route_entry(ip_u32: u32, tbl24_base: *const u16) {
    #[cfg(target_arch = "x86_64")]
    unsafe {
        let offset = (ip_u32 >> 8) as usize;
        let ptr = tbl24_base.add(offset) as *const i8;
        core::arch::x86_64::_mm_prefetch(ptr, core::arch::x86_64::_MM_HINT_T0);
    }

    #[cfg(target_arch = "aarch64")]
    unsafe {
        let offset = (ip_u32 >> 8) as usize;
        let ptr = tbl24_base.add(offset) as *const u8;
        core::arch::asm!(
            "prfm pldl1keep, [{0}]",
            in(reg) ptr,
            options(nostack, preserves_flags)
        );
    }

    #[cfg(not(any(target_arch = "x86_64", target_arch = "aarch64")))]
    {
        let _ = (ip_u32, tbl24_base);
    }
}

pub struct Dir24_8 {
    tbl24: Box<[u16]>,
    tbl24_len: Option<Box<[u8]>>,
    tbl8: Vec<u16>,
    tbl8_len: Vec<u8>,
    num_chunks: usize,
    #[allow(dead_code)]
    default_action: u16,
}

impl Dir24_8 {
    pub fn new(default_action: u16) -> Result<Self> {
        if default_action > MAX_ACTION_CODE {
            return Err(SpatialError::ActionCodeOverflow(default_action));
        }

        let tbl24 = filled_boxed_slice(TBL24_ENTRIES, default_action, "tbl24")?;
        let tbl24_len = Some(filled_boxed_slice(TBL24_ENTRIES, 0u8, "tbl24_len")?);

        Ok(Self {
            tbl24,
            tbl24_len,
            tbl8: Vec::new(),
            tbl8_len: Vec::new(),
            num_chunks: 0,
            default_action,
        })
    }

    #[inline(always)]
    pub fn tbl24_base(&self) -> *const u16 {
        self.tbl24.as_ptr()
    }

    #[inline(always)]
    pub fn prefetch(&self, ip_u32: u32) {
        unsafe { prefetch_route_entry(ip_u32, self.tbl24_base()) };
    }

    #[inline]
    pub fn prefetch_batch(&self, ips: &[u32]) {
        let base = self.tbl24_base();
        const WINDOW: usize = 8;

        for chunk in ips.chunks(WINDOW) {
            for &ip in chunk {
                unsafe { prefetch_route_entry(ip, base) };
            }
        }
    }

    #[inline(always)]
    pub fn lookup(&self, ip: u32) -> u16 {
        let idx24 = (ip >> 8) as usize;
        // ip >> 8 始终落在 tbl24 的索引范围内。
        let entry = unsafe { *self.tbl24.get_unchecked(idx24) };

        if (entry & TBL8_FLAG) == 0 {
            entry
        } else {
            let chunk_idx = (entry & ACTION_MASK) as usize;
            let offset = (ip & 0xFF) as usize;
            let tbl8_idx = chunk_idx * TBL8_CHUNK_SIZE + offset;
            debug_assert!(tbl8_idx < self.tbl8.len());
            unsafe { *self.tbl8.get_unchecked(tbl8_idx) }
        }
    }

    #[inline(always)]
    pub fn lookup_addr(&self, addr: Ipv4Addr) -> u16 {
        self.lookup(u32::from(addr))
    }

    pub fn insert(&mut self, ip: u32, prefix_len: u8, action: u16) -> Result<()> {
        if prefix_len > 32 {
            return Err(SpatialError::InvalidIpv4Prefix(prefix_len));
        }
        if action > MAX_ACTION_CODE {
            return Err(SpatialError::ActionCodeOverflow(action));
        }

        let mask = if prefix_len == 0 {
            0
        } else {
            u32::MAX << (32 - prefix_len)
        };
        let network = ip & mask;

        if prefix_len <= 24 {
            self.insert_tbl24_prefix(network, prefix_len, action);
        } else {
            self.insert_tbl8_prefix(network, prefix_len, action)?;
        }

        Ok(())
    }

    pub fn insert_bulk(&mut self, routes: &[(&str, u16)]) -> Result<()> {
        let mut parsed: Vec<(u32, u8, u16)> = Vec::with_capacity(routes.len());

        for &(cidr, action) in routes {
            let (addr, prefix_len) = parse_cidr(cidr)?;
            parsed.push((u32::from(addr), prefix_len, action));
        }

        // 保留相同前缀长度的输入顺序，使后插入的同长度路由覆盖前者。
        parsed.sort_by(|a, b| b.1.cmp(&a.1));

        for (ip, prefix_len, action) in parsed {
            self.insert(ip, prefix_len, action)?;
        }

        Ok(())
    }

    pub fn insert_addr(&mut self, addr: Ipv4Addr, prefix_len: u8, action: u16) -> Result<()> {
        self.insert(u32::from(addr), prefix_len, action)
    }

    pub fn insert_cidr(&mut self, cidr: &str) -> Result<RouteCidrBuilder<'_>> {
        let (addr, prefix_len) = parse_cidr(cidr)?;

        Ok(RouteCidrBuilder {
            dir: self,
            addr,
            prefix_len,
        })
    }

    #[inline(always)]
    pub fn allocated_chunks(&self) -> usize {
        self.num_chunks
    }

    pub fn seal(&mut self) {
        self.tbl24_len = None;
    }

    #[inline(always)]
    pub fn is_tbl8(&self, ip: u32) -> bool {
        let idx24 = (ip >> 8) as usize;
        (self.tbl24[idx24] & TBL8_FLAG) != 0
    }

    #[cfg(test)]
    #[allow(dead_code)]
    pub(crate) fn force_num_chunks(&mut self, n: usize) {
        self.num_chunks = n;
    }

    fn insert_tbl24_prefix(&mut self, network: u32, prefix_len: u8, action: u16) {
        let start = (network >> 8) as usize;
        let count = 1usize << (24 - prefix_len);
        let end = start + count;

        if count >= BATCH_FILL_THRESHOLD {
            let lengths = self
                .tbl24_len
                .as_mut()
                .expect("tbl24_len dropped before insert; call seal() after all inserts");

            let can_fill_all = self.tbl24[start..end]
                .iter()
                .zip(lengths[start..end].iter())
                .all(|(entry, len)| (*entry & TBL8_FLAG) == 0 && *len <= prefix_len);

            if can_fill_all {
                self.tbl24[start..end].fill(action);
                lengths[start..end].fill(prefix_len);
                return;
            }
        }

        for idx in start..end {
            let entry = self.tbl24[idx];

            if (entry & TBL8_FLAG) != 0 {
                let chunk_idx = (entry & ACTION_MASK) as usize;
                self.update_tbl8_range(
                    chunk_idx,
                    0,
                    TBL8_CHUNK_SIZE,
                    prefix_len,
                    action,
                );
            } else {
                let lengths = self
                    .tbl24_len
                    .as_mut()
                    .expect("tbl24_len dropped before insert; call seal() after all inserts");

                if lengths[idx] <= prefix_len {
                    self.tbl24[idx] = action;
                    lengths[idx] = prefix_len;
                }
            }
        }
    }

    fn insert_tbl8_prefix(
        &mut self,
        network: u32,
        prefix_len: u8,
        action: u16,
    ) -> Result<()> {
        let idx24 = (network >> 8) as usize;
        let chunk_idx = self.ensure_tbl8_chunk(idx24)?;

        let count = 1usize << (32 - prefix_len);
        // network 已按 prefix_len 归一化，末字节无需再次做对齐掩码。
        let offset = (network & 0xFF) as usize;
        debug_assert!(offset + count <= TBL8_CHUNK_SIZE);

        self.update_tbl8_range(chunk_idx, offset, count, prefix_len, action);
        Ok(())
    }

    fn ensure_tbl8_chunk(&mut self, idx24: usize) -> Result<usize> {
        let entry = self.tbl24[idx24];
        if (entry & TBL8_FLAG) != 0 {
            return Ok((entry & ACTION_MASK) as usize);
        }

        let old_len = self
            .tbl24_len
            .as_ref()
            .expect("tbl24_len dropped before insert")[idx24];

        if self.num_chunks >= MAX_TBL8_CHUNKS {
            return Err(SpatialError::Tbl8Exhausted);
        }

        let chunk_idx = self.num_chunks;
        self.tbl8.resize(self.tbl8.len() + TBL8_CHUNK_SIZE, entry);
        self.tbl8_len
            .resize(self.tbl8_len.len() + TBL8_CHUNK_SIZE, old_len);

        self.num_chunks += 1;
        self.tbl24[idx24] = TBL8_FLAG | (chunk_idx as u16);
        self.tbl24_len
            .as_mut()
            .expect("tbl24_len dropped before insert")[idx24] = 24;

        Ok(chunk_idx)
    }

    #[inline]
    fn update_tbl8_range(
        &mut self,
        chunk_idx: usize,
        offset: usize,
        count: usize,
        prefix_len: u8,
        action: u16,
    ) {
        let start = chunk_idx * TBL8_CHUNK_SIZE + offset;
        let end = start + count;

        for (entry, len) in self.tbl8[start..end]
            .iter_mut()
            .zip(self.tbl8_len[start..end].iter_mut())
        {
            if *len <= prefix_len {
                *entry = action;
                *len = prefix_len;
            }
        }
    }
}

#[must_use = "RouteCidrBuilder must be consumed with .with_action(..)"]
pub struct RouteCidrBuilder<'a> {
    dir: &'a mut Dir24_8,
    addr: Ipv4Addr,
    prefix_len: u8,
}

impl<'a> RouteCidrBuilder<'a> {
    pub fn with_action(self, action: u16) -> Result<()> {
        self.dir.insert_addr(self.addr, self.prefix_len, action)
    }
}

impl<'a> core::fmt::Debug for RouteCidrBuilder<'a> {
    fn fmt(&self, f: &mut core::fmt::Formatter<'_>) -> core::fmt::Result {
        f.debug_struct("RouteCidrBuilder")
            .field("addr", &self.addr)
            .field("prefix_len", &self.prefix_len)
            .finish_non_exhaustive()
    }
}
