use thiserror::Error;

/// Errors arising from spatial lookup structures and rule compilation.
#[derive(Debug, Error, PartialEq, Eq, Clone)]
pub enum SpatialError {
    #[error("Invalid IPv4 prefix length: {0} (must be 0..=32)")]
    InvalidIpv4Prefix(u8),

    #[error("Invalid IPv6 prefix length: {0} (must be 0..=128)")]
    InvalidIpv6Prefix(u8),

    #[error("TBL8 secondary chunk allocation exhausted (maximum capacity reached)")]
    Tbl8Exhausted,

    #[error("Action code {0} exceeds 15-bit direct action limit (0..=32767)")]
    ActionCodeOverflow(u16),

    #[error("Invalid CIDR notation: '{0}'")]
    InvalidCidr(String),

    #[error("Invalid IP address format: '{0}'")]
    InvalidIp(String),

    #[error("Rule compilation error: {0}")]
    CompilationError(String),

    #[error("Internal spatial error: {0}")]
    Internal(String),

    /// Wrapper for an underlying I/O error.
    ///
    /// Stored as `String` rather than `std::io::Error` because
    /// `SpatialError` derives `PartialEq`/`Eq`/`Clone`, and
    /// `std::io::Error` implements none of those. Conversion from
    /// `io::Error` is provided via the `From` impl below.
    #[error("Spatial I/O error: {0}")]
    Io(String),
}

impl From<std::io::Error> for SpatialError {
    #[inline]
    fn from(e: std::io::Error) -> Self {
        SpatialError::Io(e.to_string())
    }
}

pub type Result<T> = std::result::Result<T, SpatialError>;
