// `workspace-hack` is a cargo-hakari synthetic crate that unifies
// feature resolution across the workspace. It is intentionally
// never `use`d by any source file, so the standard
// `unused_crate_dependencies` lint does not apply here.
#![allow(unused_crate_dependencies)]

//! `caly-spatial`: Spatial Routing Manifold, DIR-24-8 Engine, ROBDD, and Native JIT Compiler.
//! Hardware-level IPv4 fast-path, 16-bit stride IPv6 Tree-Bitmap with segmented sparse bitmaps,
//! Shannon-reduced ordered binary decision diagrams, and native x86_64 JIT compilation.

#![deny(unsafe_op_in_unsafe_fn)]
#![warn(clippy::undocumented_unsafe_blocks)]
#![warn(clippy::multiple_unsafe_ops_per_block)]

pub mod bdd;
pub mod dir24_8;
pub mod dns_pipeline;
pub mod error;
pub mod jit;
pub mod router;
pub mod tree_bitmap;

// Re-exports
pub use bdd::{
    BddEngine, BddNode, BoolOp, DeadRuleReport, DnsIndependence, EvaluationContext, NodeId,
    Predicate, Protocol, RuleDefinition, Variable, TERMINAL_FALSE, TERMINAL_TRUE,
};
pub use dir24_8::{
    prefetch_route_entry, Dir24_8, ACTION_MASK, MAX_ACTION_CODE, MAX_TBL8_CHUNKS, TBL24_ENTRIES,
    TBL8_CHUNK_SIZE, TBL8_FLAG,
};
pub use dns_pipeline::{
    DnsCacheEntry, DnsResolutionQuery, SpeculativeDnsPipeline, SpeculativeDnsResult,
};
pub use error::{Result, SpatialError};
pub use jit::{BddJitCompiler, RouteQueryContext};
pub use router::{
    CompilationReport, RouteAction, RouteDecision, RouteQuery, RouterConfig, SpatialRouter,
    SpatialRule,
};
pub use tree_bitmap::{
    Bitmap128k, Bitmap64k, SparseBitmap, TreeBitmap, TreeBitmapNode, TreeRouteEntry, WordEntry,
};

#[cfg(test)]
mod tests {
    use super::*;
    use std::net::{IpAddr, Ipv4Addr, Ipv6Addr};


    /// Regression guard for layered compilation (v14).
    ///
    /// Before v14, a single `DomainSuffix` rule would disable the JIT
    /// globally: `emit_predicate_check` returned `Err`, and
    /// `compile_tables` silently stored `jit = None`. After v14 the
    /// JIT emits a sentinel trampoline and stays active, deferring
    /// only the domain-bearing subtree to the BDD pass.
    #[test]
    #[cfg_attr(miri, ignore)]
    fn test_jit_remains_active_with_domain_rules() {
        let mut router = SpatialRouter::new(RouteAction::Direct).unwrap();

        router.add_rule(SpatialRule {
            predicates: vec![Predicate::DomainSuffix("internal.corp".into())],
            action: RouteAction::Proxy("corp-out".into()),
            tag: "internal".into(),
        });
        router.add_rule(SpatialRule {
            predicates: vec![Predicate::Port(443), Predicate::Protocol(Protocol::Tcp)],
            action: RouteAction::Proxy("tls-out".into()),
            tag: "https".into(),
        });

        router.compile_tables().unwrap();
        assert!(
            router.is_jit_active(),
            "JIT must remain active even with domain rules (layered compilation)",
        );

        // The numeric rule must still resolve through the JIT fast path.
        let q_num = RouteQuery::from_ip(
            IpAddr::V4(Ipv4Addr::new(93, 184, 216, 34)),
            443,
            Protocol::Tcp,
        );
        let d_num = router.route(&q_num);
        assert_eq!(d_num.action, RouteAction::Proxy("tls-out".into()));
        assert_eq!(d_num.dns_independence, DnsIndependence::Proved);

        // The domain rule must route through the BDD pass; with the
        // domain supplied, the rule matches deterministically.
        let q_dom = RouteQuery::from_domain("service.internal.corp", 80, Protocol::Tcp);
        let d_dom = router.route(&q_dom);
        assert_eq!(d_dom.action, RouteAction::Proxy("corp-out".into()));
        assert_eq!(d_dom.dns_independence, DnsIndependence::Proved);
    }

    /// Rule priority: the first matching rule in declaration order wins.
    #[test]
    #[cfg_attr(miri, ignore)]
    fn test_spatial_router_first_match_wins() {
        let mut router = SpatialRouter::new(RouteAction::Direct).unwrap();
        // Two rules with overlapping predicates: the earlier one must
        // win, even though the later one is more specific in a
        // different dimension.
        router.add_rule(SpatialRule {
            predicates: vec![Predicate::Port(443)],
            action: RouteAction::Proxy("first".into()),
            tag: "first".into(),
        });
        router.add_rule(SpatialRule {
            predicates: vec![Predicate::Port(443), Predicate::Protocol(Protocol::Tcp)],
            action: RouteAction::Proxy("second".into()),
            tag: "second".into(),
        });
        router.compile_tables().unwrap();

        let q = RouteQuery::from_ip(
            IpAddr::V4(Ipv4Addr::new(1, 1, 1, 1)),
            443,
            Protocol::Tcp,
        );
        let dec = router.route(&q);
        assert_eq!(dec.action, RouteAction::Proxy("first".into()));
    }

    /// An IP-only query must never be forced through the DNS fork path
    /// just because a Domain rule exists in the table. The domain never
    /// participated in the query; the Domain predicate is simply false.
    #[test]
    #[cfg_attr(miri, ignore)]
    fn test_spatial_router_ip_only_with_domain_rule_is_proved() {
        let mut router = SpatialRouter::new(RouteAction::Direct).unwrap();
        router.add_rule(SpatialRule {
            predicates: vec![Predicate::DomainSuffix("internal.corp".into())],
            action: RouteAction::Proxy("corp-out".into()),
            tag: "internal".into(),
        });
        router.add_rule(SpatialRule {
            predicates: vec![Predicate::Port(443)],
            action: RouteAction::Proxy("tls-out".into()),
            tag: "https".into(),
        });
        router.compile_tables().unwrap();

        // IP + port 443: must resolve to the port rule, Proved.
        let query = RouteQuery::from_ip(
            IpAddr::V4(Ipv4Addr::new(93, 184, 216, 34)),
            443,
            Protocol::Tcp,
        );
        let dec = router.route(&query);
        assert_eq!(dec.dns_independence, DnsIndependence::Proved);
        assert_eq!(dec.action, RouteAction::Proxy("tls-out".into()));

        // IP + unrelated port: falls through to the default, still Proved.
        let query = RouteQuery::from_ip(
            IpAddr::V4(Ipv4Addr::new(93, 184, 216, 34)),
            8080,
            Protocol::Tcp,
        );
        let dec = router.route(&query);
        assert_eq!(dec.dns_independence, DnsIndependence::Proved);
        assert_eq!(dec.action, RouteAction::Direct);
    }

    #[test]
    fn test_dir24_8_lpm_and_cidr_overrides() {
        let mut dir = Dir24_8::new(0).expect("failed to create DIR-24-8");

        // Action codes
        let act_default = 1u16;
        let act_10_8 = 2u16;
        let act_10_1_16 = 3u16;
        let act_10_1_1_24 = 4u16;
        let act_10_1_1_128_25 = 5u16;
        let act_10_1_1_200_32 = 6u16;

        // Insert routes in arbitrary order
        dir.insert_cidr("0.0.0.0/0")
            .unwrap()
            .with_action(act_default)
            .unwrap();
        dir.insert_cidr("10.0.0.0/8")
            .unwrap()
            .with_action(act_10_8)
            .unwrap();
        dir.insert_cidr("10.1.0.0/16")
            .unwrap()
            .with_action(act_10_1_16)
            .unwrap();
        dir.insert_cidr("10.1.1.0/24")
            .unwrap()
            .with_action(act_10_1_1_24)
            .unwrap();
        dir.insert_cidr("10.1.1.128/25")
            .unwrap()
            .with_action(act_10_1_1_128_25)
            .unwrap();
        dir.insert_cidr("10.1.1.200/32")
            .unwrap()
            .with_action(act_10_1_1_200_32)
            .unwrap();

        // Verify that secondary TBL8 chunk was allocated for /25 and /32
        assert!(dir.allocated_chunks() >= 1);
        assert!(dir.is_tbl8(u32::from(Ipv4Addr::new(10, 1, 1, 200))));
        assert!(!dir.is_tbl8(u32::from(Ipv4Addr::new(10, 2, 0, 1))));

        // Longest-Prefix Match (LPM) verification
        assert_eq!(
            dir.lookup_addr(Ipv4Addr::new(10, 1, 1, 200)),
            act_10_1_1_200_32
        );
        assert_eq!(
            dir.lookup_addr(Ipv4Addr::new(10, 1, 1, 150)),
            act_10_1_1_128_25
        );
        assert_eq!(dir.lookup_addr(Ipv4Addr::new(10, 1, 1, 50)), act_10_1_1_24);
        assert_eq!(dir.lookup_addr(Ipv4Addr::new(10, 1, 2, 1)), act_10_1_16);
        assert_eq!(dir.lookup_addr(Ipv4Addr::new(10, 2, 1, 1)), act_10_8);
    }

    #[test]
    fn test_sparse_bitmap_operations_and_memory_reduction() {
        // Verify drastic node memory reduction (from 24 KiB down to under 256 bytes)
        let node_size = std::mem::size_of::<TreeBitmapNode>();
        // SmallVec inline 容量从 4 提升到 8 后节点约 384 字节；
        // 仍远小于旧实现 24 KiB 的节点尺寸。
        assert!(
            node_size <= 512,
            "TreeBitmapNode size must be <= 512 bytes, got {node_size} bytes"
        );

        let mut bm = SparseBitmap::new();
        assert!(bm.is_empty());
        assert_eq!(bm.total_count(), 0);

        // Test boundary bits: 0, 63, 64, 127, 1023, 65535, 131071
        let test_bits = [0, 63, 64, 127, 500, 1023, 4096, 65535, 131071];
        for &bit in &test_bits {
            assert!(!bm.get(bit));
            bm.set(bit);
            assert!(bm.get(bit));
        }

        assert_eq!(bm.total_count(), test_bits.len());

        // Verify popcount_before semantics
        assert_eq!(bm.popcount_before(0), 0);
        assert_eq!(bm.popcount_before(1), 1);
        assert_eq!(bm.popcount_before(63), 1);
        assert_eq!(bm.popcount_before(64), 2);
        assert_eq!(bm.popcount_before(65), 3);
        assert_eq!(bm.popcount_before(128), 4);
        assert_eq!(bm.popcount_before(200000), test_bits.len());

        // Test multiple bits in the same word
        bm.set(10);
        bm.set(20);
        bm.set(30);
        assert_eq!(bm.popcount_before(15), 2); // bit 0 and bit 10
        assert_eq!(bm.popcount_before(25), 3); // bits 0, 10, 20
        assert_eq!(bm.popcount_before(35), 4); // bits 0, 10, 20, 30

        bm.clear();
        assert!(bm.is_empty());
        assert_eq!(bm.total_count(), 0);
    }

    #[test]
    fn test_tree_bitmap_ipv6_sparse_lpm() {
        let mut tb = TreeBitmap::new(0);

        let act_default = 1u16;
        let act_2001_32 = 2u16;
        let act_2001_48 = 3u16;
        let act_2001_64 = 4u16;
        let act_host_128 = 5u16;

        tb.insert_cidr("::/0", act_default).unwrap();
        tb.insert_cidr("2001:db8::/32", act_2001_32).unwrap();
        tb.insert_cidr("2001:db8:85a3::/48", act_2001_48).unwrap();
        tb.insert_cidr("2001:db8:85a3:8a2e::/64", act_2001_64)
            .unwrap();
        tb.insert_cidr("2001:db8:85a3:8a2e::1/128", act_host_128)
            .unwrap();

        // Exact /128 match
        let addr_host = Ipv6Addr::new(0x2001, 0x0db8, 0x85a3, 0x8a2e, 0, 0, 0, 1);
        assert_eq!(tb.lookup_addr(addr_host), act_host_128);

        // /64 match
        let addr_64 = Ipv6Addr::new(0x2001, 0x0db8, 0x85a3, 0x8a2e, 0, 0, 0, 2);
        assert_eq!(tb.lookup_addr(addr_64), act_2001_64);

        // /48 match
        let addr_48 = Ipv6Addr::new(0x2001, 0x0db8, 0x85a3, 0x9999, 0, 0, 0, 1);
        assert_eq!(tb.lookup_addr(addr_48), act_2001_48);

        // /32 match
        let addr_32 = Ipv6Addr::new(0x2001, 0x0db8, 0x1111, 0, 0, 0, 0, 1);
        assert_eq!(tb.lookup_addr(addr_32), act_2001_32);

        // Default match
        let addr_other = Ipv6Addr::new(0xfe80, 0, 0, 0, 0, 0, 0, 1);
        assert_eq!(tb.lookup_addr(addr_other), act_default);
    }

    #[test]
    #[cfg_attr(miri, ignore)]
    fn test_bdd_jit_compiler_execution() {
        let mut engine = BddEngine::new();

        let r1 = RuleDefinition {
            predicates: vec![Predicate::Port(443), Predicate::Protocol(Protocol::Tcp)],
            action: 10,
            tag: "https".to_string(),
        };
        let r2 = RuleDefinition {
            predicates: vec![Predicate::Port(80), Predicate::Protocol(Protocol::Tcp)],
            action: 20,
            tag: "http".to_string(),
        };
        let r3 = RuleDefinition {
            predicates: vec![Predicate::IpCidr(
                IpAddr::V4(Ipv4Addr::new(192, 168, 1, 0)),
                24,
            )],
            action: 30,
            tag: "local_lan".to_string(),
        };

        let default_act = 99u16;
        let (root, dead) = engine.compile_rules(&[r1, r2, r3], default_act).unwrap();
        assert!(dead.is_empty());

        let jit = BddJitCompiler::compile(&engine, root, default_act).expect("JIT compile failed");

        // 1. Test HTTPS packet
        let ctx_https = RouteQueryContext::from_ip_port(
            IpAddr::V4(Ipv4Addr::new(1, 1, 1, 1)),
            443,
            Protocol::Tcp,
        );
        assert_eq!(jit.execute(&ctx_https), 10);

        // 2. Test HTTP packet
        let ctx_http = RouteQueryContext::from_ip_port(
            IpAddr::V4(Ipv4Addr::new(1, 1, 1, 1)),
            80,
            Protocol::Tcp,
        );
        assert_eq!(jit.execute(&ctx_http), 20);

        // 3. Test LAN CIDR packet
        let ctx_lan = RouteQueryContext::from_ip_port(
            IpAddr::V4(Ipv4Addr::new(192, 168, 1, 55)),
            8080,
            Protocol::Udp,
        );
        assert_eq!(jit.execute(&ctx_lan), 30);

        // 4. Test Non-matching packet
        let ctx_other = RouteQueryContext::from_ip_port(
            IpAddr::V4(Ipv4Addr::new(8, 8, 8, 8)),
            53,
            Protocol::Udp,
        );
        assert_eq!(jit.execute(&ctx_other), default_act);
    }

    #[test]
    #[cfg_attr(miri, ignore)]
    fn test_spatial_router_compile_from_config_and_jit() {
        let config = RouterConfig {
            default_action: RouteAction::Direct,
            rules: vec![
                SpatialRule {
                    predicates: vec![Predicate::Port(443), Predicate::Protocol(Protocol::Tcp)],
                    action: RouteAction::Proxy("tls-out".to_string()),
                    tag: "secure_web".to_string(),
                },
                SpatialRule {
                    predicates: vec![Predicate::Port(80)],
                    action: RouteAction::Direct,
                    tag: "plain_web".to_string(),
                },
            ],
            ipv4_cidrs: vec![
                ("10.0.0.0/8".to_string(), RouteAction::Pass),
                ("192.168.0.0/16".to_string(), RouteAction::Pass),
            ],
            ipv6_cidrs: vec![("fc00::/7".to_string(), RouteAction::Pass)],
        };

        let router = SpatialRouter::compile(config).expect("SpatialRouter::compile failed");
        assert!(router.is_jit_active());

        // 1. Match Rule 1 via JIT: Port 443 TCP -> Proxy("tls-out")
        let q1 = RouteQuery::from_ip(
            IpAddr::V4(Ipv4Addr::new(93, 184, 216, 34)),
            443,
            Protocol::Tcp,
        );
        let dec1 = router.route(&q1);
        assert_eq!(dec1.action, RouteAction::Proxy("tls-out".to_string()));

        // 2. Match Rule 2 via JIT: Port 80 -> Direct
        let q2 = RouteQuery::from_ip(
            IpAddr::V4(Ipv4Addr::new(93, 184, 216, 34)),
            80,
            Protocol::Tcp,
        );
        let dec2 = router.route(&q2);
        assert_eq!(dec2.action, RouteAction::Direct);

        // 3. Match IPv4 CIDR table: 10.1.2.3:8080 -> Pass
        let q3 = RouteQuery::from_ip(IpAddr::V4(Ipv4Addr::new(10, 1, 2, 3)), 8080, Protocol::Tcp);
        let dec3 = router.route(&q3);
        assert_eq!(dec3.action, RouteAction::Pass);

        // 4. Match IPv6 CIDR table: fc00::1:9000 -> Pass
        let q4 = RouteQuery::from_ip(
            IpAddr::V6(Ipv6Addr::new(0xfc00, 0, 0, 0, 0, 0, 0, 1)),
            9000,
            Protocol::Udp,
        );
        let dec4 = router.route(&q4);
        assert_eq!(dec4.action, RouteAction::Pass);

        // 5. Default fallback -> Direct
        let q5 = RouteQuery::from_ip(IpAddr::V4(Ipv4Addr::new(8, 8, 8, 8)), 53, Protocol::Udp);
        let dec5 = router.route(&q5);
        assert_eq!(dec5.action, RouteAction::Direct);
    }

    #[test]
    fn test_speculative_dns_pipeline_lifecycle() {
        let mut router = SpatialRouter::new(RouteAction::Pass).expect("create router");
        router
            .add_ipv4_route("1.1.1.0/24", RouteAction::Proxy("cloudflare".into()))
            .unwrap();
        router
            .add_ipv6_route("2606:4700::/32", RouteAction::Proxy("cloudflare-v6".into()))
            .unwrap();

        let clock = caly_memory::TscClock::default();
        let pipeline = SpeculativeDnsPipeline::new_with_clock(clock, 60);

        let domain = "one.one.one.one";

        // 1. Initial query: cache miss -> returns PendingResolution
        match pipeline.resolve_or_speculate(domain, &router) {
            SpeculativeDnsResult::PendingResolution { query_id } => {
                assert!(query_id >= 1);
            }
            SpeculativeDnsResult::QueueFull => panic!("unexpected QueueFull in test"),
            SpeculativeDnsResult::Resolved(_) => panic!("expected cache miss"),
        }

        assert_eq!(pipeline.pending_count(), 1);
        let pending = pipeline.poll_pending_queries(10);
        assert_eq!(pending.len(), 1);
        assert_eq!(pending[0].domain, domain);
        assert_eq!(pipeline.pending_count(), 0);

        // 2. Feedback injection: inject resolved IPv4 address 1.1.1.1
        let action = pipeline.inject_resolution(
            domain,
            vec![IpAddr::V4(Ipv4Addr::new(1, 1, 1, 1))],
            &router,
        );
        assert_eq!(action, RouteAction::Proxy("cloudflare".into()));
        assert_eq!(pipeline.cache_size(), 1);

        // 3. Subsequent query: cache hit -> returns Resolved(Proxy("cloudflare"))
        match pipeline.resolve_or_speculate(domain, &router) {
            SpeculativeDnsResult::Resolved(act) => {
                assert_eq!(act, RouteAction::Proxy("cloudflare".into()));
            }
            SpeculativeDnsResult::PendingResolution { .. } => panic!("expected cache hit"),
                SpeculativeDnsResult::QueueFull => {
                    panic!("unexpected QueueFull in test")
                }
        }

        // 4. Invalidation
        assert!(pipeline.invalidate(domain));
        assert_eq!(pipeline.cache_size(), 0);
    }

    #[test]
    #[cfg_attr(miri, ignore)]
    fn test_spatial_router_speculative_routing_integration() {
        let mut router = SpatialRouter::new(RouteAction::Direct).expect("create router");
        router
            .add_ipv4_route("10.0.0.0/8", RouteAction::Pass)
            .unwrap();
        router
            .add_ipv4_route("198.51.100.0/24", RouteAction::Proxy("proxy-us".into()))
            .unwrap();

        // Add a rule that requires DNS evaluation by matching on DNS IP
        router.add_rule(SpatialRule {
            predicates: vec![
                Predicate::DomainSuffix("internal.corp".into()),
                Predicate::DnsIpCidr(IpAddr::V4(Ipv4Addr::new(10, 0, 0, 0)), 8),
            ],
            action: RouteAction::Pass,
            tag: "internal_corp_rule".into(),
        });
        router.compile_tables().unwrap();

        let clock = caly_memory::TscClock::default();
        let pipeline = std::sync::Arc::new(SpeculativeDnsPipeline::new_with_clock(clock, 120));
        let router = router.with_dns_pipeline(pipeline.clone());

        let query = RouteQuery::from_domain("service.internal.corp", 443, Protocol::Tcp);

        // 1. Initial speculative routing -> requires DNS, enqueues query
        let dec1 = router.route(&query);
        assert_eq!(dec1.dns_independence, DnsIndependence::RequiresDns);
        assert!(dec1.tag.as_ref().unwrap().starts_with("dns_pending:"));

        // 2. Poll pending query from pipeline
        let pending = pipeline.poll_pending_queries(1);
        assert_eq!(pending.len(), 1);
        assert_eq!(pending[0].domain, "service.internal.corp");

        // 3. Inject resolution feedback: 10.2.3.4
        let action = pipeline.inject_resolution(
            "service.internal.corp",
            vec![IpAddr::V4(Ipv4Addr::new(10, 2, 3, 4))],
            &router,
        );
        assert_eq!(action, RouteAction::Pass);

        // 4. Subsequent speculative routing -> hit, Proved action
        let dec2 = router.route(&query);
        assert_eq!(dec2.dns_independence, DnsIndependence::Proved);
        assert_eq!(dec2.action, RouteAction::Pass);
        assert_eq!(dec2.tag.as_deref(), Some("speculative_dns_cache_hit"));
    }

    /// Exhaustive LPM stress: nested prefixes at every depth.
    /// Verifies that inserting /8, /12, /16, /24, /25, /32 in arbitrary
    /// order still produces correct longest-prefix matches.
    #[test]
    fn test_dir24_8_exhaustive_lpm() {
        let mut dir = Dir24_8::new(0).expect("create dir24");

        let cases = [
            ("0.0.0.0/0", 100u16),
            ("10.0.0.0/8", 101u16),
            ("172.16.0.0/12", 102u16),
            ("10.0.0.0/16", 103u16),
            ("10.0.0.0/24", 104u16),
            ("10.0.1.0/24", 105u16),
            ("10.0.0.128/25", 106u16),
            ("10.0.0.200/32", 107u16),
        ];
        for (cidr, action) in &cases {
            dir.insert_cidr(cidr).unwrap().with_action(*action).unwrap();
        }

        // Ascending specificity
        assert_eq!(dir.lookup_addr(Ipv4Addr::new(8, 8, 8, 8)), 100);
        assert_eq!(dir.lookup_addr(Ipv4Addr::new(10, 5, 0, 1)), 101);
        assert_eq!(dir.lookup_addr(Ipv4Addr::new(172, 31, 0, 1)), 102);
        assert_eq!(dir.lookup_addr(Ipv4Addr::new(172, 32, 0, 1)), 100);
        assert_eq!(dir.lookup_addr(Ipv4Addr::new(10, 0, 5, 1)), 103);
        assert_eq!(dir.lookup_addr(Ipv4Addr::new(10, 0, 0, 1)), 104);
        assert_eq!(dir.lookup_addr(Ipv4Addr::new(10, 0, 1, 1)), 105);
        assert_eq!(dir.lookup_addr(Ipv4Addr::new(10, 0, 0, 200)), 107);
        assert_eq!(dir.lookup_addr(Ipv4Addr::new(10, 0, 0, 130)), 106);
        assert_eq!(dir.lookup_addr(Ipv4Addr::new(10, 0, 0, 100)), 104);

        assert!(dir.allocated_chunks() > 0, "TBL8 chunk should be allocated");
        assert!(dir.is_tbl8(u32::from(Ipv4Addr::new(10, 0, 0, 200))));
    }

    /// Tree-Bitmap: verify LPM at every IPv6 prefix length.
    #[test]
    fn test_tree_bitmap_all_prefix_lengths() {
        let mut tb = TreeBitmap::new(0);

        tb.insert_cidr("::/0", 1).unwrap();
        tb.insert_cidr("2001:db8::/32", 2).unwrap();
        tb.insert_cidr("2001:db8:85a3::/48", 3).unwrap();
        tb.insert_cidr("2001:db8:85a3:8a2e::/64", 4).unwrap();
        tb.insert_cidr("2001:db8:85a3:8a2e:370:7334::/96", 5)
            .unwrap();
        tb.insert_cidr("2001:db8:85a3:8a2e:370:7334::1/128", 6)
            .unwrap();

        let check = |addr: Ipv6Addr, expected: u16| {
            assert_eq!(
                tb.lookup_addr(addr),
                expected,
                "LPM failed for {addr}: expected {expected}"
            );
        };

        check(
            Ipv6Addr::new(0x2001, 0x0db8, 0x85a3, 0x8a2e, 0x370, 0x7334, 0, 1),
            6,
        );
        check(
            Ipv6Addr::new(0x2001, 0x0db8, 0x85a3, 0x8a2e, 0x370, 0x7334, 0, 2),
            5,
        );
        check(Ipv6Addr::new(0x2001, 0x0db8, 0x85a3, 0x8a2e, 0, 0, 0, 1), 4);
        check(Ipv6Addr::new(0x2001, 0x0db8, 0x85a3, 0x9999, 0, 0, 0, 1), 3);
        check(Ipv6Addr::new(0x2001, 0x0db8, 0x1111, 0, 0, 0, 0, 1), 2);
        check(Ipv6Addr::new(0xfe80, 0, 0, 0, 0, 0, 0, 1), 1);
    }

    /// BDD: verify dead-rule detection with shadowing rules.
    #[test]
    fn test_bdd_dead_rule_detection() {
        let mut engine = BddEngine::new();

        // Rule 0 matches all TCP; Rule 1 matches TCP port 443 (fully shadowed)
        let rules = vec![
            RuleDefinition {
                predicates: vec![Predicate::Protocol(Protocol::Tcp)],
                action: 10,
                tag: "all_tcp".into(),
            },
            RuleDefinition {
                predicates: vec![Predicate::Protocol(Protocol::Tcp), Predicate::Port(443)],
                action: 20,
                tag: "shadowed_https".into(),
            },
            RuleDefinition {
                predicates: vec![Predicate::Protocol(Protocol::Udp)],
                action: 30,
                tag: "all_udp".into(),
            },
        ];

        let (_, dead) = engine.compile_rules(&rules, 99).unwrap();
        assert_eq!(dead.len(), 1, "exactly one dead rule expected");
        assert_eq!(dead[0].rule_index, 1);
        assert_eq!(dead[0].tag, "shadowed_https");
    }

    /// BDD: Zero-DNS proof — if the rule outcome does not depend on a DNS
    /// predicate, it must be marked `DnsIndependence::Proved`.
    #[test]
    fn test_bdd_zero_dns_proof_positive() {
        let mut engine = BddEngine::new();

        let rules = vec![RuleDefinition {
            predicates: vec![Predicate::Port(80), Predicate::Protocol(Protocol::Tcp)],
            action: 7,
            tag: "plain_web".into(),
        }];
        let (root, _) = engine.compile_rules(&rules, 0).unwrap();

        let ctx = EvaluationContext {
            domain: Some("example.com"),
            ip: None,
            port: 80,
            protocol: Protocol::Tcp,
            process: None,
            dns_resolved_ips: None,
        };
        let (code, proof) = engine.prove_dns_independence(root, &ctx);
        assert_eq!(code, 7);
        assert_eq!(proof, DnsIndependence::Proved);
    }

    /// Deterministic fuzz test: 200 random routes, 500 random queries,
    /// verified against a naive linear LPM implementation.
    #[test]
    fn test_dir24_8_random_lpm_matches_naive() {
        use std::collections::HashSet;

        // Reproducible LCG.
        let mut seed: u64 = 0xDEAD_BEEF_CAFE_BABE;
        let mut next = || {
            seed = seed
                .wrapping_mul(6364136223846793005)
                .wrapping_add(1442695040888963407);
            seed
        };

        let mut dir = Dir24_8::new(0).expect("create dir24");
        let mut routes: Vec<(u32, u8, u16)> = Vec::with_capacity(200);
        let mut seen: HashSet<(u32, u8)> = HashSet::new();

        while routes.len() < 200 {
            let prefix_len = ((next() >> 32) % 33) as u8;
            let raw_ip = (next() >> 32) as u32;
            let mask = if prefix_len == 0 {
                0
            } else {
                !0u32 << (32 - prefix_len)
            };
            let net = raw_ip & mask;
            if !seen.insert((net, prefix_len)) {
                continue;
            }
            let action = (routes.len() as u16) + 1; // 1..=200, avoid code 0
            dir.insert(net, prefix_len, action).expect("insert");
            routes.push((net, prefix_len, action));
        }

        // 500 random queries: LPM must match a naive linear scan.
        for _ in 0..500 {
            let query = (next() >> 32) as u32;
            let expected = routes
                .iter()
                .filter(|(net, len, _)| {
                    let mask = if *len == 0 { 0 } else { !0u32 << (32 - *len) };
                    (query & mask) == (*net & mask)
                })
                .max_by_key(|(_, len, _)| *len)
                .map(|(_, _, a)| *a)
                .unwrap_or(0);

            assert_eq!(dir.lookup(query), expected, "mismatch for {query:#010x}",);
        }
    }
}
