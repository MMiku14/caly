//! Unified Spatial Router Engine.
//! Integrates DIR-24-8, IPv6 Tree-Bitmap, ROBDD, and native JIT machine code execution.

use crate::bdd::{
    BddEngine, DeadRuleReport, DnsIndependence, EvaluationContext, NodeId, Predicate, Protocol,
    RuleDefinition, TERMINAL_FALSE,
};
use crate::dir24_8::Dir24_8;
use crate::dns_pipeline::{SpeculativeDnsPipeline, SpeculativeDnsResult};
use crate::error::{Result, SpatialError};
use crate::jit::{BddJitCompiler, RouteQueryContext};
use crate::tree_bitmap::TreeBitmap;
use std::collections::HashMap;
use std::net::IpAddr;
use std::sync::atomic::{AtomicU64, Ordering};
use std::sync::Arc;

#[derive(Clone, Debug, PartialEq, Eq, Hash, Default)]
pub enum RouteAction {
    #[default]
    Direct,
    Proxy(String),
    Reject,
    Pass,
    Custom(u16),
}

pub const ACTION_CODE_NO_MATCH: u16 = 0;
pub const ACTION_CODE_DIRECT: u16 = 1;
pub const ACTION_CODE_PASS: u16 = 2;
pub const ACTION_CODE_REJECT: u16 = 0x7FFF;

#[derive(Clone, Debug)]
pub struct RouteQuery<'a> {
    pub domain: Option<&'a str>,
    pub ip: Option<IpAddr>,
    pub port: u16,
    pub protocol: Protocol,
    pub process: Option<&'a str>,
    pub dns_resolved_ips: Option<&'a [IpAddr]>,
}

impl<'a> RouteQuery<'a> {
    pub fn from_domain(domain: &'a str, port: u16, protocol: Protocol) -> Self {
        Self {
            domain: Some(domain),
            ip: None,
            port,
            protocol,
            process: None,
            dns_resolved_ips: None,
        }
    }

    pub fn from_ip(ip: IpAddr, port: u16, protocol: Protocol) -> Self {
        Self {
            domain: None,
            ip: Some(ip),
            port,
            protocol,
            process: None,
            dns_resolved_ips: None,
        }
    }

    pub fn new(
        domain: Option<&'a str>,
        ip: Option<IpAddr>,
        port: u16,
        protocol: Protocol,
        process: Option<&'a str>,
    ) -> Self {
        Self {
            domain,
            ip,
            port,
            protocol,
            process,
            dns_resolved_ips: None,
        }
    }

    pub fn with_resolved_ips(mut self, ips: &'a [IpAddr]) -> Self {
        self.dns_resolved_ips = Some(ips);
        self
    }
}

#[derive(Clone, Debug, PartialEq, Eq)]
pub struct RouteDecision {
    pub action: RouteAction,
    pub action_code: u16,
    pub dns_independence: DnsIndependence,
    pub tag: Option<String>,
}

#[derive(Clone, Debug)]
pub struct SpatialRule {
    pub predicates: Vec<Predicate>,
    pub action: RouteAction,
    pub tag: String,
}

#[derive(Clone, Debug, Default)]
pub struct RouterConfig {
    pub default_action: RouteAction,
    pub rules: Vec<SpatialRule>,
    pub ipv4_cidrs: Vec<(String, RouteAction)>,
    pub ipv6_cidrs: Vec<(String, RouteAction)>,
}

#[derive(Clone, Debug)]
pub struct CompilationReport {
    pub total_rules: usize,
    pub active_rules: usize,
    pub dead_rules: Vec<DeadRuleReport>,
    pub bdd_node_count: usize,
    pub ipv4_chunks: usize,
    pub ipv6_nodes: usize,
    pub jit_enabled: bool,
}

pub struct SpatialRouter {
    dir24_8: Dir24_8,
    tree_bitmap: TreeBitmap,
    bdd: BddEngine,
    bdd_root: NodeId,
    rules: Vec<SpatialRule>,
    action_to_code: HashMap<RouteAction, u16>,
    code_to_action: HashMap<u16, RouteAction>,
    next_action_code: u16,
    default_action: RouteAction,
    compiled: bool,
    jit: Option<BddJitCompiler>,
    dns_pipeline: Option<Arc<SpeculativeDnsPipeline>>,
    query_hit_counter: AtomicU64,
}

impl SpatialRouter {
    pub fn new(default_action: RouteAction) -> Result<Self> {
        let mut router = Self {
            dir24_8: Dir24_8::new(0)?,
            tree_bitmap: TreeBitmap::new(0),
            bdd: BddEngine::new(),
            bdd_root: TERMINAL_FALSE,
            rules: Vec::new(),
            action_to_code: HashMap::new(),
            code_to_action: HashMap::new(),
            next_action_code: ACTION_CODE_PASS + 1,
            default_action: default_action.clone(),
            compiled: false,
            jit: None,
            dns_pipeline: None,
            query_hit_counter: AtomicU64::new(0),
        };

        router.register_action(RouteAction::Reject);
        router.register_action(RouteAction::Direct);
        router.register_action(RouteAction::Pass);
        router.register_action(default_action);
        Ok(router)
    }

    pub fn compile(config: RouterConfig) -> Result<Self> {
        Self::compile_from_config(config)
    }

    pub fn compile_from_config(config: RouterConfig) -> Result<Self> {
        let mut router = Self::new(config.default_action)?;
        for (cidr, action) in config.ipv4_cidrs {
            router.add_ipv4_route(&cidr, action)?;
        }
        for (cidr, action) in config.ipv6_cidrs {
            router.add_ipv6_route(&cidr, action)?;
        }
        for rule in config.rules {
            router.add_rule(rule);
        }
        router.compile_tables()?;
        Ok(router)
    }

    pub fn register_action(&mut self, action: RouteAction) -> u16 {
        if let Some(&code) = self.action_to_code.get(&action) {
            return code;
        }
        let code = match &action {
            RouteAction::Reject => ACTION_CODE_REJECT,
            RouteAction::Direct => ACTION_CODE_DIRECT,
            RouteAction::Pass => ACTION_CODE_PASS,
            RouteAction::Custom(c) => *c,
            _ => {
                while self.code_to_action.contains_key(&self.next_action_code)
                    || self.next_action_code <= 2
                    || self.next_action_code >= ACTION_CODE_REJECT
                {
                    self.next_action_code = self.next_action_code.wrapping_add(1);
                }
                if self.next_action_code >= ACTION_CODE_REJECT {
                    return ACTION_CODE_REJECT;
                }
                let c = self.next_action_code;
                self.next_action_code += 1;
                c
            }
        };
        self.action_to_code.insert(action.clone(), code);
        self.code_to_action.insert(code, action);
        code
    }

    pub fn resolve_action(&self, code: u16) -> RouteAction {
        if code == ACTION_CODE_REJECT {
            return RouteAction::Reject;
        }
        self.code_to_action
            .get(&code)
            .cloned()
            .unwrap_or_else(|| self.default_action.clone())
    }

    pub fn with_dns_pipeline(mut self, pipeline: Arc<SpeculativeDnsPipeline>) -> Self {
        self.dns_pipeline = Some(pipeline);
        self
    }

    #[inline]
    pub fn dns_pipeline(&self) -> Option<&Arc<SpeculativeDnsPipeline>> {
        self.dns_pipeline.as_ref()
    }

    #[inline(always)]
    pub fn dir24_8(&self) -> &Dir24_8 {
        &self.dir24_8
    }

    #[inline(always)]
    pub fn tree_bitmap(&self) -> &TreeBitmap {
        &self.tree_bitmap
    }

    #[inline(always)]
    pub fn default_action(&self) -> &RouteAction {
        &self.default_action
    }

    pub fn lookup_ip(&self, ip: IpAddr) -> Option<RouteAction> {
        let code = match ip {
            IpAddr::V4(v4) => self.dir24_8.lookup_addr(v4),
            IpAddr::V6(v6) => self.tree_bitmap.lookup_addr(v6),
        };
        if code != 0 {
            Some(self.resolve_action(code))
        } else {
            None
        }
    }

    pub fn route_speculative<'a>(
        &self,
        query: &RouteQuery<'a>,
        pipeline: &SpeculativeDnsPipeline,
    ) -> RouteDecision {
        let decision = self.route(query);
        if decision.dns_independence == DnsIndependence::RequiresDns {
            if let Some(domain) = query.domain {
                match pipeline.resolve_or_speculate(domain, self) {
                    SpeculativeDnsResult::Resolved(action) => {
                        let action_code = self.action_to_code.get(&action).copied().unwrap_or(0);
                        return RouteDecision {
                            action,
                            action_code,
                            dns_independence: DnsIndependence::Proved,
                            tag: Some("speculative_dns_cache_hit".into()),
                        };
                    }
                    SpeculativeDnsResult::PendingResolution { query_id } => {
                        return RouteDecision {
                            action: decision.action,
                            action_code: decision.action_code,
                            dns_independence: DnsIndependence::RequiresDns,
                            tag: Some(format!("dns_pending:{query_id}")),
                        };
                    }
                    SpeculativeDnsResult::QueueFull => {
                        let default_code = self
                            .action_to_code
                            .get(&self.default_action)
                            .copied()
                            .unwrap_or(0);
                        return RouteDecision {
                            action: self.default_action.clone(),
                            action_code: default_code,
                            dns_independence: DnsIndependence::RequiresDns,
                            tag: Some("dns_queue_full".into()),
                        };
                    }
                }
            }
        }
        decision
    }

    #[inline(always)]
    pub fn prefetch_ipv4(&self, ip_u32: u32) {
        self.dir24_8.prefetch(ip_u32);
    }

    pub fn add_ipv4_route(&mut self, cidr: &str, action: RouteAction) -> Result<()> {
        if action == RouteAction::Reject {
            return Err(SpatialError::CompilationError(
                "RouteAction::Reject cannot be represented directly in DIR-24-8 table".into(),
            ));
        }
        let code = self.register_action(action);
        self.dir24_8.insert_cidr(cidr)?.with_action(code)
    }

    pub fn add_ipv6_route(&mut self, cidr: &str, action: RouteAction) -> Result<()> {
        let code = self.register_action(action);
        self.tree_bitmap.insert_cidr(cidr, code)
    }

    pub fn add_rule(&mut self, rule: SpatialRule) {
        let _ = self.register_action(rule.action.clone());
        self.rules.push(rule);
        self.compiled = false;
        self.jit = None;
        self.bdd_root = TERMINAL_FALSE;
    }

    pub fn compile_tables(&mut self) -> Result<CompilationReport> {
        let _ = self.register_action(self.default_action.clone());

        // Snapshot rule metadata to eliminate aliasing borrow conflicts on `self`
        let rules_snapshot: Vec<(RouteAction, Vec<Predicate>, String)> = self
            .rules
            .iter()
            .map(|r| (r.action.clone(), r.predicates.clone(), r.tag.clone()))
            .collect();

        // Populate fast hardware tables ONLY for pure, single-predicate IP rules
        for (action, predicates, _) in &rules_snapshot {
            if predicates.len() == 1 {
                let action_code = self.register_action(action.clone());
                match &predicates[0] {
                    Predicate::IpCidr(IpAddr::V4(v4), len) => {
                        self.dir24_8.insert_addr(*v4, *len, action_code)?;
                    }
                    Predicate::IpCidr(IpAddr::V6(v6), len) => {
                        self.tree_bitmap.insert_addr(*v6, *len, action_code)?;
                    }
                    _ => {}
                }
            }
        }

        let mut bdd_rules = Vec::with_capacity(rules_snapshot.len());
        for (action, predicates, tag) in &rules_snapshot {
            let code = self.register_action(action.clone());
            bdd_rules.push(RuleDefinition {
                predicates: predicates.clone(),
                action: code,
                tag: tag.clone(),
            });
        }

        let total_rules = bdd_rules.len();
        let (root, dead_rules) = self.bdd.compile_rules(&bdd_rules, ACTION_CODE_NO_MATCH)?;
        self.bdd_root = root;

        if self.bdd_root != TERMINAL_FALSE {
            self.jit = BddJitCompiler::compile(&self.bdd, self.bdd_root, 0).ok();
        }

        self.compiled = true;
        Ok(CompilationReport {
            total_rules,
            active_rules: total_rules - dead_rules.len(),
            dead_rules,
            bdd_node_count: self.bdd.node_count(),
            ipv4_chunks: self.dir24_8.allocated_chunks(),
            ipv6_nodes: self.tree_bitmap.node_count(),
            jit_enabled: self.jit.is_some(),
        })
    }

    #[inline(always)]
    pub fn is_jit_active(&self) -> bool {
        self.jit.is_some()
    }

    #[inline(always)]
    pub fn jit(&self) -> Option<&BddJitCompiler> {
        self.jit.as_ref()
    }

    pub fn route(&self, query: &RouteQuery<'_>) -> RouteDecision {
        self.query_hit_counter.fetch_add(1, Ordering::Relaxed);

        let mut bdd_root_override: Option<NodeId> = None;
        if let Some(jit) = &self.jit {
            let q_ctx = RouteQueryContext::from_query(query);
            let raw = jit.execute_raw(&q_ctx);
            if (raw & 0x8000_0000) != 0 {
                bdd_root_override = Some(raw & 0x7FFF_FFFF);
            } else {
                let action_code = raw as u16;
                if action_code != ACTION_CODE_NO_MATCH {
                    return RouteDecision {
                        action: self.resolve_action(action_code),
                        action_code,
                        dns_independence: DnsIndependence::Proved,
                        tag: None,
                    };
                }
            }
        }

        let ctx = EvaluationContext {
            domain: query.domain,
            ip: query.ip,
            port: query.port,
            protocol: query.protocol,
            process: query.process,
            dns_resolved_ips: query.dns_resolved_ips,
        };

        if self.compiled && self.bdd_root != TERMINAL_FALSE {
            let root = bdd_root_override.unwrap_or(self.bdd_root);
            let (action_code, proof) = self.bdd.prove_dns_independence(root, &ctx);
            if proof == DnsIndependence::Proved && action_code != 0 {
                return RouteDecision {
                    action: self.resolve_action(action_code),
                    action_code,
                    dns_independence: DnsIndependence::Proved,
                    tag: None,
                };
            }

            if query.dns_resolved_ips.is_some() {
                let code = self.bdd.evaluate_full(self.bdd_root, &ctx);
                if code != 0 {
                    return RouteDecision {
                        action: self.resolve_action(code),
                        action_code: code,
                        dns_independence: DnsIndependence::Proved,
                        tag: None,
                    };
                }
            }

            if proof == DnsIndependence::RequiresDns
                && query.ip.is_none()
                && query.dns_resolved_ips.is_none()
            {
                if let (Some(pipeline), Some(domain)) = (&self.dns_pipeline, query.domain) {
                    match pipeline.resolve_or_speculate(domain, self) {
                        SpeculativeDnsResult::Resolved(action) => {
                            let action_code =
                                self.action_to_code.get(&action).copied().unwrap_or(0);
                            return RouteDecision {
                                action,
                                action_code,
                                dns_independence: DnsIndependence::Proved,
                                tag: Some("speculative_dns_cache_hit".into()),
                            };
                        }
                        SpeculativeDnsResult::PendingResolution { query_id } => {
                            let default_code = self
                                .action_to_code
                                .get(&self.default_action)
                                .copied()
                                .unwrap_or(0);
                            return RouteDecision {
                                action: self.default_action.clone(),
                                action_code: default_code,
                                dns_independence: DnsIndependence::RequiresDns,
                                tag: Some(format!("dns_pending:{query_id}")),
                            };
                        }
                        SpeculativeDnsResult::QueueFull => {
                            let default_code = self
                                .action_to_code
                                .get(&self.default_action)
                                .copied()
                                .unwrap_or(0);
                            return RouteDecision {
                                action: self.default_action.clone(),
                                action_code: default_code,
                                dns_independence: DnsIndependence::RequiresDns,
                                tag: Some("dns_queue_full".into()),
                            };
                        }
                    }
                }
                let default_code = self
                    .action_to_code
                    .get(&self.default_action)
                    .copied()
                    .unwrap_or(0);
                return RouteDecision {
                    action: self.default_action.clone(),
                    action_code: default_code,
                    dns_independence: DnsIndependence::RequiresDns,
                    tag: None,
                };
            }
        }

        if let Some(ip) = query.ip {
            match ip {
                IpAddr::V4(v4) => {
                    let code = self.dir24_8.lookup_addr(v4);
                    if code != 0 {
                        return RouteDecision {
                            action: self.resolve_action(code),
                            action_code: code,
                            dns_independence: DnsIndependence::Proved,
                            tag: None,
                        };
                    }
                }
                IpAddr::V6(v6) => {
                    let code = self.tree_bitmap.lookup_addr(v6);
                    if code != 0 {
                        return RouteDecision {
                            action: self.resolve_action(code),
                            action_code: code,
                            dns_independence: DnsIndependence::Proved,
                            tag: None,
                        };
                    }
                }
            }
        }

        let default_code = self
            .action_to_code
            .get(&self.default_action)
            .copied()
            .unwrap_or(0);

        RouteDecision {
            action: self.default_action.clone(),
            action_code: default_code,
            dns_independence: DnsIndependence::Proved,
            tag: None,
        }
    }
}
