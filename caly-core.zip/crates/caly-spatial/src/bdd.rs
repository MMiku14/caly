//! Multi-dimensional Reduced Ordered Binary Decision Diagrams (ROBDD).
//! Provides Shannon decomposition, terminal memoization, dead-rule pruning,
//! and deterministic Zero-DNS short-circuit proofs.

use crate::error::{Result, SpatialError};
use std::collections::{HashMap, HashSet};
use std::net::IpAddr;

#[derive(Clone, Copy, Debug, PartialEq, Eq, Hash)]
pub enum Protocol {
    Tcp,
    Udp,
    Icmp,
    Other(u8),
}

impl Protocol {
    #[inline(always)]
    pub const fn from_u8(v: u8) -> Self {
        match v {
            6 => Self::Tcp,
            17 => Self::Udp,
            1 => Self::Icmp,
            other => Self::Other(other),
        }
    }

    #[inline(always)]
    pub const fn as_u8(&self) -> u8 {
        match self {
            Self::Tcp => 6,
            Self::Udp => 17,
            Self::Icmp => 1,
            Self::Other(other) => *other,
        }
    }
}

#[derive(Clone, Copy, Debug, PartialEq, Eq, PartialOrd, Ord, Hash)]
pub struct Variable(u32);

impl Variable {
    #[inline(always)]
    pub const fn raw(self) -> u32 {
        self.0
    }
}

#[derive(Clone, Debug, PartialEq, Eq, Hash)]
pub enum Predicate {
    DomainExact(String),
    DomainSuffix(String),
    DomainKeyword(String),
    IpCidr(IpAddr, u8),
    Port(u16),
    PortRange(u16, u16),
    Protocol(Protocol),
    Process(String),
    DnsIpCidr(IpAddr, u8),
}

#[derive(Clone, Copy, Debug, PartialEq, Eq, Hash)]
pub enum DnsIndependence {
    Proved,
    RequiresDns,
}

impl DnsIndependence {
    #[inline(always)]
    pub fn is_proved(&self) -> bool {
        matches!(self, Self::Proved)
    }
}

pub const MAX_RULES_PER_COMPILE: usize = 4096;
pub const MAX_BDD_RECURSION_DEPTH: usize = 1024;
pub type NodeId = u32;
pub const TERMINAL_FALSE: NodeId = 0;
pub const TERMINAL_TRUE: NodeId = 1;
pub const ACTION_NODE_BASE: NodeId = 2;

#[derive(Clone, Copy, Debug, PartialEq, Eq, Hash)]
pub enum BddNode {
    Terminal(u16),
    Decision {
        var: Variable,
        low: NodeId,
        high: NodeId,
    },
}

#[derive(Clone, Copy, Debug, PartialEq, Eq, Hash)]
pub enum BoolOp {
    And,
    Or,
    Xor,
}

#[derive(Clone, Debug, PartialEq, Eq)]
pub struct DeadRuleReport {
    pub rule_index: usize,
    pub tag: String,
}

#[derive(Clone, Debug)]
pub struct EvaluationContext<'a> {
    pub domain: Option<&'a str>,
    pub ip: Option<IpAddr>,
    pub port: u16,
    pub protocol: Protocol,
    pub process: Option<&'a str>,
    pub dns_resolved_ips: Option<&'a [IpAddr]>,
}

#[derive(Clone, Debug)]
pub struct RuleDefinition {
    pub predicates: Vec<Predicate>,
    pub action: u16,
    pub tag: String,
}

pub struct BddEngine {
    nodes: Vec<BddNode>,
    terminal_map: HashMap<u16, NodeId>,
    unique_table: HashMap<(Variable, NodeId, NodeId), NodeId>,
    apply_cache: HashMap<(BoolOp, NodeId, NodeId), NodeId>,
    ite_cache: HashMap<(NodeId, NodeId, NodeId), NodeId>,
    predicates: Vec<Predicate>,
    pred_to_var: HashMap<Predicate, Variable>,
    dns_vars: HashSet<Variable>,
}

impl Default for BddEngine {
    fn default() -> Self {
        Self::new()
    }
}

impl BddEngine {
    pub fn new() -> Self {
        let mut nodes = Vec::with_capacity(512);
        nodes.push(BddNode::Terminal(0)); // TERMINAL_FALSE
        nodes.push(BddNode::Terminal(1)); // TERMINAL_TRUE

        Self {
            nodes,
            terminal_map: HashMap::with_capacity(64),
            unique_table: HashMap::with_capacity(1024),
            apply_cache: HashMap::with_capacity(1024),
            ite_cache: HashMap::with_capacity(1024),
            predicates: Vec::with_capacity(128),
            pred_to_var: HashMap::with_capacity(128),
            dns_vars: HashSet::with_capacity(16),
        }
    }

    pub fn register_predicate(&mut self, pred: Predicate) -> Variable {
        if let Some(&var) = self.pred_to_var.get(&pred) {
            return var;
        }
        let is_dns = matches!(pred, Predicate::DnsIpCidr(_, _));
        let var = Variable(self.predicates.len() as u32);
        self.predicates.push(pred.clone());
        self.pred_to_var.insert(pred, var);
        if is_dns {
            self.dns_vars.insert(var);
        }
        var
    }

    #[inline(always)]
    pub fn is_dns_var(&self, var: Variable) -> bool {
        self.dns_vars.contains(&var)
    }

    #[inline]
    pub fn terminal(&mut self, action: u16) -> NodeId {
        if let Some(&id) = self.terminal_map.get(&action) {
            return id;
        }
        let id = self.nodes.len() as NodeId;
        self.nodes.push(BddNode::Terminal(action));
        self.terminal_map.insert(action, id);
        id
    }

    pub fn make_node(&mut self, var: Variable, low: NodeId, high: NodeId) -> NodeId {
        if low == high {
            return low;
        }
        let key = (var, low, high);
        if let Some(&id) = self.unique_table.get(&key) {
            return id;
        }
        let id = self.nodes.len() as NodeId;
        self.nodes.push(BddNode::Decision { var, low, high });
        self.unique_table.insert(key, id);
        id
    }

    #[inline(always)]
    pub fn get_node(&self, id: NodeId) -> BddNode {
        match self.nodes.get(id as usize) {
            Some(&node) => node,
            None => BddNode::Terminal(0),
        }
    }

    pub fn eval_predicate(pred: &Predicate, ctx: &EvaluationContext<'_>) -> bool {
        match pred {
            Predicate::DomainExact(d) => ctx.domain.is_some_and(|q| q.eq_ignore_ascii_case(d)),
            Predicate::DomainSuffix(s) => ctx.domain.is_some_and(|q| {
                let q_lower = q.to_ascii_lowercase();
                let s_lower = s.to_ascii_lowercase();
                let s_clean = s_lower.strip_prefix('.').unwrap_or(&s_lower);
                if q_lower == s_clean {
                    true
                } else if q_lower.len() > s_clean.len() && q_lower.ends_with(s_clean) {
                    let prefix_len = q_lower.len() - s_clean.len();
                    q_lower.as_bytes()[prefix_len - 1] == b'.'
                } else {
                    false
                }
            }),
            Predicate::DomainKeyword(k) => {
                if k.is_empty() {
                    return false;
                }
                ctx.domain.is_some_and(|q| {
                    let q_bytes = q.as_bytes();
                    let k_bytes = k.as_bytes();
                    if q_bytes.len() < k_bytes.len() {
                        return false;
                    }
                    q_bytes
                        .windows(k_bytes.len())
                        .any(|w| w.eq_ignore_ascii_case(k_bytes))
                })
            }
            Predicate::IpCidr(cidr_addr, prefix_len) => ctx
                .ip
                .is_some_and(|ip| Self::ip_matches_cidr(ip, *cidr_addr, *prefix_len)),
            Predicate::Port(p) => ctx.port == *p,
            Predicate::PortRange(start, end) => ctx.port >= *start && ctx.port <= *end,
            Predicate::Protocol(proto) => ctx.protocol == *proto,
            Predicate::Process(proc) => {
                if proc.is_empty() {
                    return false;
                }
                ctx.process.is_some_and(|p| {
                    let p_bytes = p.as_bytes();
                    let proc_bytes = proc.as_bytes();
                    if p_bytes.len() < proc_bytes.len() {
                        return false;
                    }
                    p_bytes
                        .windows(proc_bytes.len())
                        .any(|w| w.eq_ignore_ascii_case(proc_bytes))
                })
            }
            Predicate::DnsIpCidr(cidr_addr, prefix_len) => {
                if let Some(resolved_ips) = ctx.dns_resolved_ips {
                    resolved_ips
                        .iter()
                        .any(|&ip| Self::ip_matches_cidr(ip, *cidr_addr, *prefix_len))
                } else {
                    false
                }
            }
        }
    }

    fn ip_matches_cidr(target: IpAddr, cidr_addr: IpAddr, prefix_len: u8) -> bool {
        match (target, cidr_addr) {
            (IpAddr::V4(t4), IpAddr::V4(c4)) => {
                if prefix_len > 32 {
                    return false;
                }
                if prefix_len == 0 {
                    return true;
                }
                let mask = !0u32 << (32 - prefix_len);
                (u32::from(t4) & mask) == (u32::from(c4) & mask)
            }
            (IpAddr::V6(t6), IpAddr::V6(c6)) => {
                if prefix_len > 128 {
                    return false;
                }
                if prefix_len == 0 {
                    return true;
                }
                let mask = !0u128 << (128 - prefix_len);
                (u128::from(t6) & mask) == (u128::from(c6) & mask)
            }
            _ => false,
        }
    }

    pub fn apply(&mut self, op: BoolOp, f: NodeId, g: NodeId) -> NodeId {
        self.apply_internal(op, f, g, 0)
    }

    fn apply_internal(&mut self, op: BoolOp, mut f: NodeId, mut g: NodeId, depth: usize) -> NodeId {
        if depth > MAX_BDD_RECURSION_DEPTH {
            return TERMINAL_FALSE;
        }

        match op {
            BoolOp::And => {
                if f == TERMINAL_FALSE || g == TERMINAL_FALSE {
                    return TERMINAL_FALSE;
                }
                if f == TERMINAL_TRUE {
                    return g;
                }
                if g == TERMINAL_TRUE {
                    return f;
                }
                if f == g {
                    return f;
                }
                if f > g {
                    std::mem::swap(&mut f, &mut g);
                }
            }
            BoolOp::Or => {
                if f == TERMINAL_TRUE || g == TERMINAL_TRUE {
                    return TERMINAL_TRUE;
                }
                if f == TERMINAL_FALSE {
                    return g;
                }
                if g == TERMINAL_FALSE {
                    return f;
                }
                if f == g {
                    return f;
                }
                if f > g {
                    std::mem::swap(&mut f, &mut g);
                }
            }
            BoolOp::Xor => {
                if f == g {
                    return TERMINAL_FALSE;
                }
                if f == TERMINAL_FALSE {
                    return g;
                }
                if g == TERMINAL_FALSE {
                    return f;
                }
                if f > g {
                    std::mem::swap(&mut f, &mut g);
                }
            }
        }

        let key = (op, f, g);
        if let Some(&res) = self.apply_cache.get(&key) {
            return res;
        }

        let (var, f_low, f_high, g_low, g_high) = match (self.get_node(f), self.get_node(g)) {
            (
                BddNode::Decision { var: vf, low: lf, high: hf },
                BddNode::Decision { var: vg, low: lg, high: hg },
            ) => {
                if vf == vg {
                    (vf, lf, hf, lg, hg)
                } else if vf < vg {
                    (vf, lf, hf, g, g)
                } else {
                    (vg, f, f, lg, hg)
                }
            }
            (BddNode::Decision { var: vf, low: lf, high: hf }, BddNode::Terminal(_)) => {
                (vf, lf, hf, g, g)
            }
            (BddNode::Terminal(_), BddNode::Decision { var: vg, low: lg, high: hg }) => {
                (vg, f, f, lg, hg)
            }
            (BddNode::Terminal(a), BddNode::Terminal(b)) => {
                if a > 1 || b > 1 {
                    return TERMINAL_FALSE;
                }
                let res = match op {
                    BoolOp::And => {
                        if a != 0 && b != 0 { TERMINAL_TRUE } else { TERMINAL_FALSE }
                    }
                    BoolOp::Or => {
                        if a != 0 || b != 0 { TERMINAL_TRUE } else { TERMINAL_FALSE }
                    }
                    BoolOp::Xor => {
                        if (a != 0) ^ (b != 0) { TERMINAL_TRUE } else { TERMINAL_FALSE }
                    }
                };
                return res;
            }
        };

        let low = self.apply_internal(op, f_low, g_low, depth + 1);
        let high = self.apply_internal(op, f_high, g_high, depth + 1);
        let result = self.make_node(var, low, high);
        self.apply_cache.insert(key, result);
        result
    }

    pub fn apply_not(&mut self, f: NodeId) -> NodeId {
        if f == TERMINAL_FALSE {
            return TERMINAL_TRUE;
        }
        if f == TERMINAL_TRUE {
            return TERMINAL_FALSE;
        }
        if let BddNode::Terminal(_) = self.get_node(f) {
            return TERMINAL_FALSE;
        }

        let mut results: HashMap<NodeId, NodeId> = HashMap::new();
        let mut visiting: HashSet<NodeId> = HashSet::new();
        let mut stack: Vec<NodeId> = Vec::with_capacity(64);
        stack.push(f);

        while let Some(&node) = stack.last() {
            if results.contains_key(&node) {
                stack.pop();
                continue;
            }
            match self.get_node(node) {
                BddNode::Terminal(_) => {
                    results.insert(node, TERMINAL_FALSE);
                    stack.pop();
                }
                BddNode::Decision { var, low, high } => {
                    let low_ready = low <= TERMINAL_TRUE || results.contains_key(&low);
                    let high_ready = high <= TERMINAL_TRUE || results.contains_key(&high);

                    if !low_ready {
                        if visiting.insert(low) {
                            stack.push(low);
                        }
                        continue;
                    }
                    if !high_ready {
                        if visiting.insert(high) {
                            stack.push(high);
                        }
                        continue;
                    }

                    let not_low = if low == TERMINAL_FALSE {
                        TERMINAL_TRUE
                    } else if low == TERMINAL_TRUE {
                        TERMINAL_FALSE
                    } else {
                        results[&low]
                    };

                    let not_high = if high == TERMINAL_FALSE {
                        TERMINAL_TRUE
                    } else if high == TERMINAL_TRUE {
                        TERMINAL_FALSE
                    } else {
                        results[&high]
                    };

                    let result = self.make_node(var, not_low, not_high);
                    results.insert(node, result);
                    visiting.remove(&node);
                    stack.pop();
                }
            }
        }
        results[&f]
    }

    pub fn ite(&mut self, cond: NodeId, then_node: NodeId, else_node: NodeId) -> NodeId {
        self.ite_internal(cond, then_node, else_node, 0)
    }

    fn ite_internal(&mut self, cond: NodeId, then_node: NodeId, else_node: NodeId, depth: usize) -> NodeId {
        if depth > MAX_BDD_RECURSION_DEPTH {
            return else_node;
        }
        if cond == TERMINAL_TRUE {
            return then_node;
        }
        if cond == TERMINAL_FALSE {
            return else_node;
        }
        if then_node == else_node {
            return then_node;
        }

        let key = (cond, then_node, else_node);
        if let Some(&res) = self.ite_cache.get(&key) {
            return res;
        }

        let mut top_var = Variable(u32::MAX);
        if let BddNode::Decision { var, .. } = self.get_node(cond) {
            if var < top_var {
                top_var = var;
            }
        }
        if let BddNode::Decision { var, .. } = self.get_node(then_node) {
            if var < top_var {
                top_var = var;
            }
        }
        if let BddNode::Decision { var, .. } = self.get_node(else_node) {
            if var < top_var {
                top_var = var;
            }
        }

        let (c_low, c_high) = self.cofactors(cond, top_var);
        let (t_low, t_high) = self.cofactors(then_node, top_var);
        let (e_low, e_high) = self.cofactors(else_node, top_var);

        let high = self.ite_internal(c_high, t_high, e_high, depth + 1);
        let low = self.ite_internal(c_low, t_low, e_low, depth + 1);
        let result = self.make_node(top_var, low, high);
        self.ite_cache.insert(key, result);
        result
    }

    #[inline]
    fn cofactors(&self, node: NodeId, top: Variable) -> (NodeId, NodeId) {
        match self.get_node(node) {
            BddNode::Decision { var, low, high } if var == top => (low, high),
            _ => (node, node),
        }
    }

    pub fn compile_condition(&mut self, predicates: &[Predicate]) -> NodeId {
        if predicates.is_empty() {
            return TERMINAL_FALSE;
        }
        let mut cond_node = TERMINAL_TRUE;
        for pred in predicates {
            let var = self.register_predicate(pred.clone());
            let pred_node = self.make_node(var, TERMINAL_FALSE, TERMINAL_TRUE);
            cond_node = self.apply(BoolOp::And, cond_node, pred_node);
        }
        cond_node
    }

    pub fn compile_rules(
        &mut self,
        rules: &[RuleDefinition],
        default_action: u16,
    ) -> Result<(NodeId, Vec<DeadRuleReport>)> {
        if rules.len() > MAX_RULES_PER_COMPILE {
            return Err(SpatialError::CompilationError(format!(
                "rule count {} exceeds MAX_RULES_PER_COMPILE ({})",
                rules.len(),
                MAX_RULES_PER_COMPILE,
            )));
        }

        let mut dead_rules = Vec::new();
        let mut accumulated_match = TERMINAL_FALSE;
        let mut compiled_rules = Vec::with_capacity(rules.len());

        for (idx, rule) in rules.iter().enumerate() {
            if rule.predicates.is_empty() {
                dead_rules.push(DeadRuleReport {
                    rule_index: idx,
                    tag: rule.tag.clone(),
                });
                continue;
            }

            let cond = self.compile_condition(&rule.predicates);
            let not_acc = self.apply_not(accumulated_match);
            let effective_cond = self.apply(BoolOp::And, cond, not_acc);

            if effective_cond == TERMINAL_FALSE {
                dead_rules.push(DeadRuleReport {
                    rule_index: idx,
                    tag: rule.tag.clone(),
                });
                continue;
            }

            accumulated_match = self.apply(BoolOp::Or, accumulated_match, cond);
            compiled_rules.push((effective_cond, rule.action));
        }

        let mut root = self.terminal(default_action);
        for &(cond, action) in compiled_rules.iter().rev() {
            let act_terminal = self.terminal(action);
            root = self.ite(cond, act_terminal, root);
        }

        self.clear_caches();
        Ok((root, dead_rules))
    }

    pub fn prove_dns_independence(
        &self,
        root: NodeId,
        ctx: &EvaluationContext<'_>,
    ) -> (u16, DnsIndependence) {
        let mut current = root;
        loop {
            match self.get_node(current) {
                BddNode::Terminal(action) => return (action, DnsIndependence::Proved),
                BddNode::Decision { var, low, high } => {
                    if self.is_dns_var(var) && ctx.dns_resolved_ips.is_none() {
                        let mut first = None;
                        let mut second = None;
                        self.collect_until_two_actions(current, &mut first, &mut second);
                        match (first, second) {
                            (Some(a), None) => return (a, DnsIndependence::Proved),
                            _ => return (0, DnsIndependence::RequiresDns),
                        }
                    }
                    let pred = &self.predicates[var.raw() as usize];
                    let branch_val = Self::eval_predicate(pred, ctx);
                    current = if branch_val { high } else { low };
                }
            }
        }
    }

    fn collect_until_two_actions(
        &self,
        node_id: NodeId,
        first: &mut Option<u16>,
        second: &mut Option<u16>,
    ) {
        let mut visited: HashSet<NodeId> = HashSet::new();
        let mut stack: Vec<NodeId> = Vec::with_capacity(32);
        stack.push(node_id);

        while let Some(id) = stack.pop() {
            if !visited.insert(id) {
                continue;
            }
            match self.get_node(id) {
                BddNode::Terminal(a) => {
                    if first.is_none() {
                        *first = Some(a);
                    } else if *first != Some(a) {
                        *second = Some(a);
                        return;
                    }
                }
                BddNode::Decision { low, high, .. } => {
                    stack.push(low);
                    stack.push(high);
                }
            }
        }
    }

    pub fn evaluate_full(&self, root: NodeId, ctx: &EvaluationContext<'_>) -> u16 {
        let mut current = root;
        loop {
            match self.get_node(current) {
                BddNode::Terminal(a) => return a,
                BddNode::Decision { var, low, high } => {
                    let pred = &self.predicates[var.0 as usize];
                    let is_true = Self::eval_predicate(pred, ctx);
                    current = if is_true { high } else { low };
                }
            }
        }
    }

    pub fn clear_caches(&mut self) {
        self.apply_cache.clear();
        self.apply_cache.shrink_to_fit();
        self.ite_cache.clear();
        self.ite_cache.shrink_to_fit();
    }

    #[inline(always)]
    pub fn get_nodes(&self) -> &[BddNode] {
        &self.nodes
    }

    #[inline(always)]
    pub fn get_predicates(&self) -> &[Predicate] {
        &self.predicates
    }

    #[inline(always)]
    pub fn node_count(&self) -> usize {
        self.nodes.len()
    }
}
