//! Speculative Zero-DNS Resolution Pipeline & Hyperplane Continuous Feedback Loop.
//! Features zero-allocation domain normalization, partitioned low-contention TSC cache,
//! negative resolution guards, and continuous endpoint health scoring.

use std::collections::{HashMap, VecDeque};
use std::net::IpAddr;
use std::sync::atomic::{AtomicU64, Ordering};
use std::sync::{Arc, Mutex, RwLock};
use caly_memory::{read_tsc, TscClock};
use crate::router::{RouteAction, SpatialRouter};

const CACHE_SHARDS: usize = 64;
const CACHE_SHARDS_MASK: usize = CACHE_SHARDS - 1;
const DEFAULT_PENDING_CAP: usize = 65536;
const FEEDBACK_CAP: usize = 65536;

#[inline]
fn lock_or_recover<'a, T>(m: &'a Mutex<T>) -> std::sync::MutexGuard<'a, T> {
    m.lock().unwrap_or_else(|poisoned| poisoned.into_inner())
}

#[inline]
fn rw_read<'a, T>(m: &'a RwLock<T>) -> std::sync::RwLockReadGuard<'a, T> {
    m.read().unwrap_or_else(|poisoned| poisoned.into_inner())
}

#[inline]
fn rw_write<'a, T>(m: &'a RwLock<T>) -> std::sync::RwLockWriteGuard<'a, T> {
    m.write().unwrap_or_else(|poisoned| poisoned.into_inner())
}

/// Zero-allocation stack buffer for ASCII lowercase domain transformation.
/// Sized to 256 bytes to comfortably house the RFC 1035 maximum domain length (253 bytes).
pub struct StackAsciiLower<const N: usize = 256> {
    buf: [u8; N],
    len: usize,
}

impl<const N: usize> StackAsciiLower<N> {
    #[inline(always)]
    pub fn from_str(s: &str) -> Option<Self> {
        let bytes = s.as_bytes();
        if bytes.len() > N {
            return None;
        }
        let mut buf = [0u8; N];
        for (i, &b) in bytes.iter().enumerate() {
            buf[i] = b.to_ascii_lowercase();
        }
        Some(Self {
            buf,
            len: bytes.len(),
        })
    }

    #[inline(always)]
    pub fn as_str(&self) -> &str {
        // SAFETY: `buf` was constructed by transforming valid UTF-8 scalar values byte-for-byte via `to_ascii_lowercase`.
        unsafe { std::str::from_utf8_unchecked(&self.buf[..self.len]) }
    }
}

#[derive(Clone, Debug, PartialEq, Eq)]
pub enum CachedResolution {
    Resolved(Vec<IpAddr>),
    Negative,
}

#[derive(Clone, Debug, PartialEq, Eq)]
pub struct DnsCacheEntry {
    pub payload: CachedResolution,
    pub resolved_at_tsc: u64,
    pub expires_at_tsc: u64,
}

impl DnsCacheEntry {
    #[inline(always)]
    pub fn new(payload: CachedResolution, ttl_cycles: u64, current_tsc: u64) -> Self {
        Self {
            payload,
            resolved_at_tsc: current_tsc,
            expires_at_tsc: current_tsc.saturating_add(ttl_cycles),
        }
    }

    #[inline(always)]
    pub fn is_expired(&self, current_tsc: u64) -> bool {
        current_tsc >= self.expires_at_tsc
    }

    #[inline(always)]
    pub fn remaining_cycles(&self, current_tsc: u64) -> u64 {
        self.expires_at_tsc.saturating_sub(current_tsc)
    }
}

#[derive(Clone, Debug, PartialEq, Eq)]
pub enum SpeculativeDnsResult {
    Resolved(RouteAction),
    PendingResolution { query_id: u64 },
    QueueFull,
}

#[derive(Clone, Debug, PartialEq, Eq)]
pub struct DnsResolutionQuery {
    pub query_id: u64,
    pub domain: String,
    pub requested_tsc: u64,
}

#[derive(Debug, Clone, Copy, Default)]
pub struct EndpointScore {
    pub rtt_nanos: u64,
    pub success_count: u64,
    pub failure_count: u64,
    pub last_seen_tsc: u64,
}

impl EndpointScore {
    #[inline]
    pub fn rank_key(&self) -> u64 {
        if self.success_count == 0 {
            return u64::MAX;
        }
        self.rtt_nanos
            .saturating_add(self.failure_count.saturating_mul(1_000_000))
    }
}

pub struct SpeculativeDnsPipeline {
    shards: Vec<RwLock<HashMap<String, Arc<DnsCacheEntry>>>>,
    pending_queue: Mutex<VecDeque<DnsResolutionQuery>>,
    pending_cap: usize,
    next_query_id: AtomicU64,
    clock: TscClock,
    last_calib_tsc: AtomicU64,
    default_ttl_cycles: u64,
    negative_ttl_cycles: u64,
    endpoint_scores: RwLock<HashMap<(String, IpAddr), EndpointScore>>,
    prune_cursor: AtomicU64,
}

impl Default for SpeculativeDnsPipeline {
    fn default() -> Self {
        Self::new_with_clock(TscClock::default(), 300)
    }
}

impl SpeculativeDnsPipeline {
    pub fn new() -> Self {
        Self::default()
    }

    pub fn new_with_clock(clock: TscClock, default_ttl_secs: u64) -> Self {
        let mut shards = Vec::with_capacity(CACHE_SHARDS);
        for _ in 0..CACHE_SHARDS {
            shards.push(RwLock::new(HashMap::with_capacity(64)));
        }
        let default_ttl_cycles = clock.ns_to_cycles(default_ttl_secs.saturating_mul(1_000_000_000));
        let negative_ttl_cycles = clock.ns_to_cycles(5_000_000_000); // 5s negative cache TTL

        Self {
            shards,
            pending_queue: Mutex::new(VecDeque::with_capacity(256)),
            pending_cap: DEFAULT_PENDING_CAP,
            next_query_id: AtomicU64::new(1),
            clock,
            last_calib_tsc: AtomicU64::new(read_tsc()),
            default_ttl_cycles,
            negative_ttl_cycles,
            endpoint_scores: RwLock::new(HashMap::new()),
            prune_cursor: AtomicU64::new(0),
        }
    }

    pub fn with_default_ttl(mut self, ttl_secs: u64) -> Self {
        self.default_ttl_cycles = self
            .clock
            .ns_to_cycles(ttl_secs.saturating_mul(1_000_000_000));
        self
    }

    #[inline(always)]
    fn shard_index_raw(bytes: &[u8]) -> usize {
        let mut hash: u64 = 0xcbf2_9ce4_8422_2325;
        for &b in bytes {
            hash ^= b.to_ascii_lowercase() as u64;
            hash = hash.wrapping_mul(0x0000_0100_0000_01b3);
        }
        (hash as usize) & CACHE_SHARDS_MASK
    }

    pub fn shard_index(&self, domain: &str) -> usize {
        Self::shard_index_raw(domain.as_bytes())
    }

    pub fn resolve(&self, domain: &str) -> Option<Vec<IpAddr>> {
        let current_tsc = read_tsc();
        let idx = Self::shard_index_raw(domain.as_bytes());

        let stack_dom = StackAsciiLower::<256>::from_str(domain);
        let dom_lower = stack_dom.as_ref().map(|s| s.as_str());

        let entry = {
            let guard = rw_read(&self.shards[idx]);
            match dom_lower {
                Some(clean) => guard.get(clean).map(Arc::clone),
                None => {
                    let heap_key = domain.to_ascii_lowercase();
                    guard.get(&heap_key).map(Arc::clone)
                }
            }
        };

        entry.and_then(|e| {
            if e.is_expired(current_tsc) {
                None
            } else {
                match &e.payload {
                    CachedResolution::Resolved(ips) => Some(ips.clone()),
                    CachedResolution::Negative => None,
                }
            }
        })
    }

    pub fn speculative_best(&self, domain: &str) -> Option<IpAddr> {
        let ips = self.resolve(domain)?;
        if ips.is_empty() {
            return None;
        }

        let scores = rw_read(&self.endpoint_scores);
        if scores.is_empty() {
            return ips.into_iter().next();
        }

        let mut best: Option<(u64, IpAddr)> = None;
        let dom_normalized = domain.to_ascii_lowercase();

        for &ip in &ips {
            let rank = scores
                .get(&(dom_normalized.clone(), ip))
                .map(EndpointScore::rank_key)
                .unwrap_or(1u64 << 62);

            match best {
                Some((best_rank, _)) if best_rank <= rank => {}
                _ => best = Some((rank, ip)),
            }
        }
        best.map(|(_, ip)| ip)
    }

    pub fn resolve_or_speculate(
        &self,
        domain: &str,
        router: &SpatialRouter,
    ) -> SpeculativeDnsResult {
        let current_tsc = read_tsc();
        let idx = Self::shard_index_raw(domain.as_bytes());

        let stack_dom = StackAsciiLower::<256>::from_str(domain);
        let dom_lower = stack_dom.as_ref().map(|s| s.as_str());

        let hit = {
            let guard = rw_read(&self.shards[idx]);
            match dom_lower {
                Some(clean) => guard.get(clean).map(Arc::clone),
                None => {
                    let heap_key = domain.to_ascii_lowercase();
                    guard.get(&heap_key).map(Arc::clone)
                }
            }
        };

        if let Some(entry) = hit {
            if !entry.is_expired(current_tsc) {
                match &entry.payload {
                    CachedResolution::Resolved(ips) => {
                        for ip in ips {
                            if let IpAddr::V4(v4) = ip {
                                router.prefetch_ipv4(u32::from(*v4));
                            }
                        }
                        for ip in ips {
                            if let Some(action) = router.lookup_ip(*ip) {
                                return SpeculativeDnsResult::Resolved(action);
                            }
                        }
                        return SpeculativeDnsResult::Resolved(router.default_action().clone());
                    }
                    CachedResolution::Negative => {
                        return SpeculativeDnsResult::Resolved(router.default_action().clone());
                    }
                }
            }
        }

        let normalized_key = match dom_lower {
            Some(clean) => clean.to_string(),
            None => domain.to_ascii_lowercase(),
        };

        let mut queue = lock_or_recover(&self.pending_queue);
        if queue.len() >= self.pending_cap {
            return SpeculativeDnsResult::QueueFull;
        }

        if let Some(existing) = queue.iter().find(|q| q.domain == normalized_key) {
            return SpeculativeDnsResult::PendingResolution {
                query_id: existing.query_id,
            };
        }

        let query_id = self.next_query_id.fetch_add(1, Ordering::Relaxed);
        queue.push_back(DnsResolutionQuery {
            query_id,
            domain: normalized_key,
            requested_tsc: current_tsc,
        });

        SpeculativeDnsResult::PendingResolution { query_id }
    }

    pub fn inject_resolution(
        &self,
        domain: &str,
        ips: Vec<IpAddr>,
        router: &SpatialRouter,
    ) -> RouteAction {
        self.inject_resolution_with_ttl(domain, ips, self.default_ttl_cycles, router)
    }

    pub fn inject_resolution_with_ttl(
        &self,
        domain: &str,
        ips: Vec<IpAddr>,
        ttl_cycles: u64,
        router: &SpatialRouter,
    ) -> RouteAction {
        let current_tsc = read_tsc();
        let key = domain.to_ascii_lowercase();
        let idx = Self::shard_index_raw(key.as_bytes());

        for ip in &ips {
            if let IpAddr::V4(v4) = ip {
                router.prefetch_ipv4(u32::from(*v4));
            }
        }

        let (payload, eff_ttl) = if ips.is_empty() {
            (CachedResolution::Negative, self.negative_ttl_cycles)
        } else {
            (CachedResolution::Resolved(ips.clone()), ttl_cycles)
        };

        let entry = Arc::new(DnsCacheEntry::new(payload, eff_ttl, current_tsc));
        {
            let mut guard = rw_write(&self.shards[idx]);
            guard.insert(key, entry);
        }

        for ip in &ips {
            if let Some(action) = router.lookup_ip(*ip) {
                return action;
            }
        }
        router.default_action().clone()
    }

    pub fn inject_resolution_with_secs(
        &self,
        domain: &str,
        ips: Vec<IpAddr>,
        ttl_secs: u64,
        router: &SpatialRouter,
    ) -> RouteAction {
        let ttl_cycles = self
            .clock
            .ns_to_cycles(ttl_secs.saturating_mul(1_000_000_000));
        self.inject_resolution_with_ttl(domain, ips, ttl_cycles, router)
    }

    pub fn poll_pending_queries(&self, max_batch: usize) -> Vec<DnsResolutionQuery> {
        let mut queue = lock_or_recover(&self.pending_queue);
        let count = queue.len().min(max_batch);
        let mut batch = Vec::with_capacity(count);
        for _ in 0..count {
            if let Some(q) = queue.pop_front() {
                batch.push(q);
            }
        }
        batch
    }

    #[inline]
    pub fn pending_count(&self) -> usize {
        lock_or_recover(&self.pending_queue).len()
    }

    pub fn cache_size(&self) -> usize {
        self.shards.iter().map(|s| rw_read(s).len()).sum()
    }

    pub fn invalidate(&self, domain: &str) -> bool {
        let key = domain.to_ascii_lowercase();
        let idx = Self::shard_index_raw(key.as_bytes());
        let mut guard = rw_write(&self.shards[idx]);
        guard.remove(&key).is_some()
    }

    pub fn clear(&self) {
        for shard in &self.shards {
            rw_write(shard).clear();
        }
        lock_or_recover(&self.pending_queue).clear();
    }

    pub fn prune_expired(&self) -> usize {
        let current_tsc = read_tsc();
        let mut pruned = 0;
        for shard in &self.shards {
            let mut guard = rw_write(shard);
            let before = guard.len();
            guard.retain(|_, entry| !entry.is_expired(current_tsc));
            pruned += before - guard.len();
        }
        pruned
    }

    pub fn prune_expired_batched(&self, max_shards: usize) -> usize {
        let current_tsc = read_tsc();
        let n = self.shards.len();
        if n == 0 {
            return 0;
        }
        let step = max_shards.max(1).min(n);
        let start = (self.prune_cursor.fetch_add(step as u64, Ordering::Relaxed) as usize) % n;
        let mut pruned = 0usize;

        for i in 0..step {
            let idx = (start + i) % n;
            let mut guard = rw_write(&self.shards[idx]);
            let before = guard.len();
            guard.retain(|_, entry| !entry.is_expired(current_tsc));
            pruned += before - guard.len();
        }
        pruned
    }

    pub fn insert_mapping(&self, domain: &str, ips: Vec<IpAddr>, ttl_secs: u64) {
        let key = domain.to_ascii_lowercase();
        let ttl_cycles = self.clock.ns_to_cycles(ttl_secs.saturating_mul(1_000_000_000));
        let entry = Arc::new(DnsCacheEntry::new(
            CachedResolution::Resolved(ips),
            ttl_cycles,
            read_tsc(),
        ));
        let idx = Self::shard_index_raw(key.as_bytes());
        rw_write(&self.shards[idx]).insert(key, entry);
    }

    pub fn record_feedback(
        &self,
        domain: &str,
        ip: IpAddr,
        rtt_nanos: u64,
        success: bool,
        now_tsc: u64,
    ) {
        let key = (domain.to_ascii_lowercase(), ip);
        let mut guard = rw_write(&self.endpoint_scores);

        if guard.len() >= FEEDBACK_CAP && !guard.contains_key(&key) {
            let mut by_age: Vec<_> = guard
                .iter()
                .map(|(k, v)| (k.clone(), v.last_seen_tsc))
                .collect();
            by_age.sort_unstable_by_key(|(_, t)| *t);
            let evict = by_age.len() / 4;
            for (k, _) in by_age.into_iter().take(evict) {
                guard.remove(&k);
            }
        }

        let e = guard.entry(key).or_default();
        e.rtt_nanos = rtt_nanos;
        e.last_seen_tsc = now_tsc;
        if success {
            e.success_count = e.success_count.saturating_add(1);
        } else {
            e.failure_count = e.failure_count.saturating_add(1);
        }
    }

    #[inline]
    pub fn len(&self) -> usize {
        self.cache_size()
    }

    #[inline]
    pub fn is_empty(&self) -> bool {
        self.cache_size() == 0
    }

    #[inline(always)]
    pub fn clock(&self) -> &TscClock {
        &self.clock
    }

    pub fn maybe_recalibrate(&self, threshold_cycles: u64) -> bool {
        let now = read_tsc();
        let last = self.last_calib_tsc.load(Ordering::Acquire);
        if now.saturating_sub(last) >= threshold_cycles {
            self.last_calib_tsc.store(now, Ordering::Release);
            true
        } else {
            false
        }
    }
}
