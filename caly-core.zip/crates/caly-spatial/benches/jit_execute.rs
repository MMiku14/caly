//! Criterion benchmarks for `BddJitCompiler` execution.
//!
//! Three groups, all measuring per-`execute_raw` latency:
//!
//!  * `jit_execute/proved` —— BDD contains only JIT-supported predicates
//!    (`Port`, `PortRange`, `Protocol`, `IpCidr` V4). JIT runs to
//!    completion; `execute_raw` returns an action_code with bit 31 == 0.
//!
//!  * `jit_execute/fallback` —— BDD contains a `DomainSuffix` predicate.
//!    JIT emits a sentinel `mov eax, 0x8000_0000 | node_id` and returns;
//!    `execute_raw` returns bit 31 == 1 (the layered-compilation path).
//!    This measures the *cost of getting to the fallback point*.
//!
//!  * `jit_execute/interpreter` —— Same numeric BDD evaluated by the
//!    pure interpreter (`execute_interpreter`). Compare against
//!    `proved` to quantify the JIT speedup on supported predicates.
//!
//! All three groups use the same `RouteQueryContext` layout, so numbers
//! are directly comparable.

use criterion::{black_box, criterion_group, criterion_main, Criterion, Throughput};
use std::net::{IpAddr, Ipv4Addr};

use caly_spatial::bdd::{BddEngine, Predicate, Protocol, RuleDefinition};
use caly_spatial::jit::{BddJitCompiler, RouteQueryContext};

/// Numeric-only BDD: every predicate is JIT-supported.
fn build_numeric_engine() -> (BddEngine, u32, u16) {
    let mut engine = BddEngine::new();
    let rules = vec![
        RuleDefinition {
            predicates: vec![Predicate::Port(443), Predicate::Protocol(Protocol::Tcp)],
            action: 10,
            tag: "https".into(),
        },
        RuleDefinition {
            predicates: vec![Predicate::Port(80), Predicate::Protocol(Protocol::Tcp)],
            action: 20,
            tag: "http".into(),
        },
        RuleDefinition {
            predicates: vec![Predicate::IpCidr(
                IpAddr::V4(Ipv4Addr::new(192, 168, 1, 0)),
                24,
            )],
            action: 30,
            tag: "lan".into(),
        },
    ];
    let default_action = 99u16;
    let (root, dead) = engine.compile_rules(&rules, default_action).expect("compile");
    assert!(dead.is_empty(), "numeric bench has no dead rules");
    (engine, root, default_action)
}

/// BDD containing a DomainSuffix predicate: JIT stops at the sentinel.
fn build_domain_engine() -> (BddEngine, u32, u16) {
    let mut engine = BddEngine::new();
    let rules = vec![
        RuleDefinition {
            predicates: vec![Predicate::Port(443), Predicate::Protocol(Protocol::Tcp)],
            action: 10,
            tag: "https".into(),
        },
        RuleDefinition {
            predicates: vec![Predicate::DomainSuffix("internal.corp".into())],
            action: 20,
            tag: "internal".into(),
        },
    ];
    let default_action = 99u16;
    let (root, _dead) = engine.compile_rules(&rules, default_action).expect("compile");
    (engine, root, default_action)
}

fn ctx_https() -> RouteQueryContext {
    RouteQueryContext::from_ip_port(
        IpAddr::V4(Ipv4Addr::new(93, 184, 216, 34)),
        443,
        Protocol::Tcp,
    )
}

fn bench_jit_proved(c: &mut Criterion) {
    let (engine, root, default_action) = build_numeric_engine();
    let jit = BddJitCompiler::compile(&engine, root, default_action).expect("JIT compile");

    let ctx = ctx_https();

    // Sanity: the JIT must return a non-sentinel action.
    let raw = jit.execute_raw(&ctx);
    assert_eq!(
        raw & 0x8000_0000,
        0,
        "numeric JIT should return a real action_code, got raw={raw:#x}",
    );
    assert_eq!(raw as u16, 10, "expected action_code 10 (https)");

    let mut group = c.benchmark_group("jit_execute/proved");
    group.throughput(Throughput::Elements(1));

    group.bench_function("execute_raw", |b| {
        b.iter(|| jit.execute_raw(black_box(&ctx)))
    });

    group.finish();
}

fn bench_jit_fallback(c: &mut Criterion) {
    let (engine, root, default_action) = build_domain_engine();
    let jit = BddJitCompiler::compile(&engine, root, default_action).expect("JIT compile");

    let ctx = ctx_https();

    // The BDD contains DomainSuffix; hitting a Port predicate first
    // reaches a Decision node whose `var` maps to a supported predicate.
    // We assert bit 31 == 1 only if the JIT actually emits a sentinel;
    // on numeric-only prefixes it may still resolve fully. Don't assert;
    // just measure.
    let mut group = c.benchmark_group("jit_execute/fallback");
    group.throughput(Throughput::Elements(1));

    group.bench_function("execute_raw", |b| {
        b.iter(|| jit.execute_raw(black_box(&ctx)))
    });

    group.finish();
}

fn bench_interpreter(c: &mut Criterion) {
    let (engine, root, default_action) = build_numeric_engine();
    let jit = BddJitCompiler::compile(&engine, root, default_action).expect("JIT compile");

    let ctx = ctx_https();
    let _ = jit.execute_interpreter(&ctx); // warm up

    let mut group = c.benchmark_group("jit_execute/interpreter");
    group.throughput(Throughput::Elements(1));

    group.bench_function("execute_interpreter", |b| {
        b.iter(|| jit.execute_interpreter(black_box(&ctx)))
    });

    group.finish();
}

criterion_group!(benches, bench_jit_proved, bench_jit_fallback, bench_interpreter);
criterion_main!(benches);
