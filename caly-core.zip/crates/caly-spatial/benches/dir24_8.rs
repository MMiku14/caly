//! Criterion benchmarks for the DIR-24-8 IPv4 LPM engine.
//!
//! The `tbl24_only` group measures a cold-cache lookup: each query is a
//! random `u32`, so the 16 MiB TBL24 array does not fit in any cache level.
//! The observed ~8.6 ns corresponds to the L2/L3 miss path.
//!
//! The `with_prefetch` group demonstrates the software-prefetch pattern:
//! the caller drives `prefetch_batch` over the next K queries, giving the
//! prefetcher time to pull the cache line in before `lookup` reads it.

use criterion::{black_box, criterion_group, criterion_main, BenchmarkId, Criterion, Throughput};
use caly_spatial::Dir24_8;

fn build_table(n: usize) -> Dir24_8 {
    let mut dir = Dir24_8::new(0).expect("create dir24");
    let mut seed: u64 = 0xC0FFEE_DEAD_BEEF;
    let mut next = || {
        seed = seed.wrapping_mul(6364136223846793005).wrapping_add(1442695040888963407);
        seed
    };

    for i in 0..n {
        let prefix_len = ((next() >> 32) % 33) as u8;
        let raw_ip = (next() >> 32) as u32;
        let mask = if prefix_len == 0 { 0 } else { !0u32 << (32 - prefix_len) };
        let net = raw_ip & mask;
        dir.insert(net, prefix_len, (i as u16) + 1).expect("insert");
    }
    dir
}

fn make_queries(count: usize) -> Vec<u32> {
    let mut seed: u64 = 0x1234_5678_9ABC_DEF0;
    (0..count)
        .map(|_| {
            seed = seed.wrapping_mul(6364136223846793005).wrapping_add(1442695040888963407);
            (seed >> 32) as u32
        })
        .collect()
}

fn bench_dir24_8_lookup(c: &mut Criterion) {
    let mut group = c.benchmark_group("dir24_8/lookup");
    group.throughput(Throughput::Elements(1));

    let queries = make_queries(10_000);

    for table_size in [1_000usize, 10_000] {
        let dir = build_table(table_size);
        group.bench_with_input(
            BenchmarkId::new("tbl24_only", table_size),
            &dir,
            |b, dir| {
                let mut i = 0usize;
                b.iter(|| {
                    let q = black_box(queries[i % queries.len()]);
                    i += 1;
                    black_box(dir.lookup(q))
                });
            },
        );
    }
    group.finish();

    // Compare lookup with and without software prefetch.
    let dir = build_table(10_000);
    let queries = make_queries(1024);

    let mut group = c.benchmark_group("dir24_8/prefetch");
    group.throughput(Throughput::Elements(1024));

    group.bench_function("baseline", |b| {
        b.iter(|| {
            let mut acc = 0u32;
            for &q in &queries {
                acc = acc.wrapping_add(dir.lookup(black_box(q)) as u32);
            }
            black_box(acc)
        });
    });

    group.bench_function("prefetch_batch", |b| {
        b.iter(|| {
            // Prefetch the entire batch first. On real workloads the
            // prefetches would be issued one iteration ahead of the
            // corresponding lookup; here we do it eagerly to show the
            // cache-hint effect in isolation.
            dir.prefetch_batch(black_box(&queries));
            let mut acc = 0u32;
            for &q in &queries {
                acc = acc.wrapping_add(dir.lookup(black_box(q)) as u32);
            }
            black_box(acc)
        });
    });

    group.finish();
}

fn bench_dir24_8_construction(c: &mut Criterion) {
    let mut group = c.benchmark_group("dir24_8/construct");
    group.bench_function("1k_routes_naive", |b| {
        b.iter(|| {
            let _ = black_box(build_table(1_000));
        });
    });
    group.finish();
}

/// Measure the batch-fill fast path directly.
///
/// `Dir24_8::insert` uses `slice::fill` when:
///   1. the covered TBL24 range has no `TBL8_FLAG` slots, and
///   2. every slot's existing prefix_len <= the new prefix_len,
/// and the range is at least `BATCH_FILL_THRESHOLD` slots wide.
///
/// We build a fresh table per iteration and insert one wide prefix.
/// Compare across prefix lengths: `/0` (16 Mi), `/8` (64 Ki),
/// `/16` (256), `/24` (1, below threshold → slow path).
fn bench_dir24_8_batch_fill(c: &mut Criterion) {
    let mut group = c.benchmark_group("dir24_8/batch_fill");
    group.throughput(Throughput::Elements(1));

    for &(cidr, label) in &[
        ("0.0.0.0/0", "slash0"),
        ("10.0.0.0/8", "slash8"),
        ("10.1.0.0/16", "slash16"),
        ("10.1.1.0/24", "slash24_below_threshold"),
    ] {
        group.bench_function(label, |b| {
            b.iter_batched(
                || Dir24_8::new(0).expect("create"),
                |mut dir| {
                    dir.insert_cidr(cidr)
                        .expect("insert_cidr")
                        .with_action(42)
                        .expect("with_action");
                    black_box(dir)
                },
                criterion::BatchSize::SmallInput,
            );
        });
    }
    group.finish();
}

criterion_group!(
    benches,
    bench_dir24_8_lookup,
    bench_dir24_8_construction,
    bench_dir24_8_batch_fill,
);
criterion_main!(benches);
