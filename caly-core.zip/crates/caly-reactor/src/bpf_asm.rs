//! High-performance native eBPF instruction emitter for Linux kernel SK_MSG programs.
//! Generates bytecode conforming strictly to the Linux kernel UAPI:
//! `struct bpf_insn { __u8 code; __u8 dst_reg:4, src_reg:4; __s16 off; __s32 imm; };`

/// Standard 64-bit eBPF instruction representation (8 bytes).
#[repr(C)]
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub struct BpfInsn {
    /// Instruction opcode.
    pub code: u8,
    /// Packed registers: `dst_reg` in bits 0..=3, `src_reg` in bits 4..=7.
    pub dst_src: u8,
    /// Signed 16-bit displacement offset.
    pub off: i16,
    /// Signed 32-bit immediate constant or helper function identifier.
    pub imm: i32,
}

const _: () = assert!(std::mem::size_of::<BpfInsn>() == 8);

// -----------------------------------------------------------------------------
// Core eBPF Opcodes and Helper Constants
// -----------------------------------------------------------------------------

pub const BPF_LD: u8 = 0x00;
pub const BPF_LDX: u8 = 0x01;
pub const BPF_ST: u8 = 0x02;
pub const BPF_STX: u8 = 0x03;
pub const BPF_ALU: u8 = 0x04;
pub const BPF_JMP: u8 = 0x05;
pub const BPF_ALU64: u8 = 0x07;

pub const BPF_W: u8 = 0x00;
pub const BPF_H: u8 = 0x08;
pub const BPF_B: u8 = 0x10;
pub const BPF_DW: u8 = 0x18;

pub const BPF_IMM: u8 = 0x00;
pub const BPF_MEM: u8 = 0x60;

pub const BPF_ADD: u8 = 0x00;
pub const BPF_MOV: u8 = 0xb0;
pub const BPF_CALL: u8 = 0x80;
pub const BPF_EXIT: u8 = 0x90;

pub const BPF_K: u8 = 0x00;
pub const BPF_X: u8 = 0x08;

pub const BPF_ALU64_ADD_K: u8 = BPF_ALU64 | BPF_ADD | BPF_K;
pub const BPF_ALU64_MOV_K: u8 = BPF_ALU64 | BPF_MOV | BPF_K;
pub const BPF_ALU64_MOV_X: u8 = BPF_ALU64 | BPF_MOV | BPF_X;
pub const BPF_LD_DW_IMM: u8 = BPF_LD | BPF_DW | BPF_IMM;
pub const BPF_ST_DW_MEM: u8 = BPF_ST | BPF_DW | BPF_MEM;
pub const BPF_ST_B_MEM: u8 = BPF_ST | BPF_B | BPF_MEM;
pub const BPF_LDX_W_MEM: u8 = BPF_LDX | BPF_W | BPF_MEM;
pub const BPF_STX_W_MEM: u8 = BPF_STX | BPF_W | BPF_MEM;
pub const BPF_STX_H_MEM: u8 = BPF_STX | BPF_H | BPF_MEM;
pub const BPF_JMP_CALL: u8 = BPF_JMP | BPF_CALL;
pub const BPF_JMP_EXIT: u8 = BPF_JMP | BPF_EXIT;

pub const BPF_PSEUDO_MAP_FD: u8 = 1;
pub const BPF_FUNC_MSG_REDIRECT_HASH: i32 = 71;
pub const SK_PASS: i32 = 1;

impl BpfInsn {
    /// Constructs a raw eBPF instruction safely packing source and destination registers.
    #[inline(always)]
    pub const fn new(code: u8, dst: u8, src: u8, off: i16, imm: i32) -> Self {
        debug_assert!(dst <= 10);
        debug_assert!(src <= 10);
        Self {
            code,
            dst_src: (dst & 0x0F) | ((src & 0x0F) << 4),
            off,
            imm,
        }
    }

    /// `dst = imm` (64-bit sign-extended immediate load).
    #[inline(always)]
    pub const fn mov64_imm(dst: u8, imm: i32) -> Self {
        Self::new(BPF_ALU64_MOV_K, dst, 0, 0, imm)
    }

    /// `dst = src` (64-bit register copy).
    #[inline(always)]
    pub const fn mov64_reg(dst: u8, src: u8) -> Self {
        Self::new(BPF_ALU64_MOV_X, dst, src, 0, 0)
    }

    /// `call imm` (Calls eBPF helper function with ID `func_id`).
    #[inline(always)]
    pub const fn call(func_id: i32) -> Self {
        Self::new(BPF_JMP_CALL, 0, 0, 0, func_id)
    }

    /// `exit` (Terminates BPF execution returning value in R0).
    #[inline(always)]
    pub const fn exit() -> Self {
        Self::new(BPF_JMP_EXIT, 0, 0, 0, 0)
    }
}

/// Assembles a verifier-compliant native `BPF_PROG_TYPE_SK_MSG` verdict program.
/// Total instruction count is strictly guaranteed to be exactly 21 instructions.
pub fn assemble_sk_msg_verdict_prog(map_fd: i32) -> [BpfInsn; 21] {
    [
        // 1. Zero out 40-byte FlowKey on stack: [r10 - 40 .. r10]
        BpfInsn::new(BPF_ST_DW_MEM, 10, 0, -40, 0),
        BpfInsn::new(BPF_ST_DW_MEM, 10, 0, -32, 0),
        BpfInsn::new(BPF_ST_DW_MEM, 10, 0, -24, 0),
        BpfInsn::new(BPF_ST_DW_MEM, 10, 0, -16, 0),
        BpfInsn::new(BPF_ST_DW_MEM, 10, 0, -8, 0),

        // 2. Extract IPv4 5-tuple from struct sk_msg_md (in r1) into FlowKey on stack:
        //    sk_msg_md::local_ip4 (offset 24) -> FlowKey.src_ip[12..16] (stack -28)
        BpfInsn::new(BPF_LDX_W_MEM, 5, 1, 24, 0),
        BpfInsn::new(BPF_STX_W_MEM, 10, 5, -28, 0),

        //    sk_msg_md::remote_ip4 (offset 20) -> FlowKey.dst_ip[12..16] (stack -12)
        BpfInsn::new(BPF_LDX_W_MEM, 5, 1, 20, 0),
        BpfInsn::new(BPF_STX_W_MEM, 10, 5, -12, 0),

        //    sk_msg_md::local_port (offset 64) -> FlowKey.src_port (stack -8)
        BpfInsn::new(BPF_LDX_W_MEM, 5, 1, 64, 0),
        BpfInsn::new(BPF_STX_H_MEM, 10, 5, -8, 0),

        //    sk_msg_md::remote_port (offset 60) -> FlowKey.dst_port (stack -6)
        BpfInsn::new(BPF_LDX_W_MEM, 5, 1, 60, 0),
        BpfInsn::new(BPF_STX_H_MEM, 10, 5, -6, 0),

        //    FlowKey.protocol = IPPROTO_TCP (6) (stack offset -4)
        BpfInsn::new(BPF_ST_B_MEM, 10, 0, -4, 6),

        // 3. Load map_fd into R2 (16-byte BPF_LD_IMM64 wide pseudo-instruction)
        BpfInsn::new(BPF_LD_DW_IMM, 2, BPF_PSEUDO_MAP_FD, 0, map_fd),
        BpfInsn::new(0, 0, 0, 0, 0), // zero placeholder merged by kernel verifier

        // 4. R3 = pointer to FlowKey on stack: r3 = r10 - 40
        BpfInsn::new(BPF_ALU64_MOV_X, 3, 10, 0, 0),
        BpfInsn::new(BPF_ALU64_ADD_K, 3, 0, 0, -40),

        // 5. R4 = 0 (flags = 0)
        BpfInsn::new(BPF_ALU64_MOV_K, 4, 0, 0, 0),

        // 6. call bpf_msg_redirect_hash
        BpfInsn::new(BPF_JMP_CALL, 0, 0, 0, BPF_FUNC_MSG_REDIRECT_HASH),

        // 7. exit
        BpfInsn::new(BPF_JMP_EXIT, 0, 0, 0, 0),
    ]
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_bpf_insn_layout_and_emitter() {
        let prog = assemble_sk_msg_verdict_prog(42);
        assert_eq!(prog.len(), 21);
        assert_eq!(std::mem::size_of_val(&prog), 21 * 8);

        // Verify map_fd instruction layout
        assert_eq!(prog[14].code, BPF_LD_DW_IMM);
        assert_eq!(prog[14].dst_src & 0x0F, 2);
        assert_eq!((prog[14].dst_src >> 4) & 0x0F, BPF_PSEUDO_MAP_FD);
        assert_eq!(prog[14].imm, 42);

        // Verify R3 stack pointer computation
        assert_eq!(prog[16].code, BPF_ALU64_MOV_X);
        assert_eq!(prog[16].dst_src & 0x0F, 3);
        assert_eq!((prog[16].dst_src >> 4) & 0x0F, 10);
        assert_eq!(prog[17].code, BPF_ALU64_ADD_K);
        assert_eq!(prog[17].dst_src & 0x0F, 3);
        assert_eq!(prog[17].imm, -40);

        // Verify call and exit instructions
        assert_eq!(prog[19].code, BPF_JMP_CALL);
        assert_eq!(prog[19].imm, BPF_FUNC_MSG_REDIRECT_HASH);
        assert_eq!(prog[20].code, BPF_JMP_EXIT);
    }
}
