#![allow(unused_unsafe)]
//! eBPF Sockmap zero-syscall in-kernel forwarding controller.
//!
//! # Why sockhash needs two keys per flow
//!
//! A `BPF_MAP_TYPE_SOCKHASH` entry maps a 4-tuple to the *receiving*
//! socket: the BPF program's `bpf_msg_redirect_hash(msg, map, key, 0)`
//! looks the packet's 4-tuple up and forwards the payload straight into
//! the bound socket's receive queue, bypassing the userspace relay path
//! entirely.
//!
//! For a proxied flow `A -> B` there are two independently-keyed
//! directions:
//!
//! * Forward (`A -> B`): keyed by A's outbound 4-tuple; the value is B's
//!   socket, so A's packets land in B's receive queue.
//! * Reverse (`B -> A`): keyed by the mirror of that 4-tuple; the value
//!   is A's socket.
//!
//! Both directions need their own map entry. An earlier revision keyed
//! both under the *same* 4-tuple and therefore silently overwrote the
//! first entry — every packet ended up redirected back to the client,
//! producing a loop that only the sockhash max-entry limit could stop.
//! [`SockmapController::splice_direct_flow`] now derives the reverse key
//! explicitly via [`FlowKey::reverse`].
//!
//! # Failure model
//!
//! If the kernel rejects `BPF_MAP_CREATE` (unprivileged container,
//! `CAP_BPF` missing, kernel without `CONFIG_BPF_SYSCALL`), the
//! controller degrades to an in-process simulation table so callers can
//! still exercise the full splice/remove/lookup API. `is_in_kernel()`
//! reports which mode is active; no caller should assume a splice is
//! actually kernel-side without checking it.

use std::collections::HashMap;
use std::io;
use std::os::raw::{c_int, c_uint};
use std::sync::atomic::{AtomicBool, Ordering};
use std::sync::RwLock;
use thiserror::Error;

#[derive(Error, Debug)]
pub enum EbpfError {
    #[error("bpf syscall failed: {0}")]
    SyscallFailed(io::Error),
    #[error("Failed to create sockmap/sockhash: {0}")]
    MapCreateFailed(io::Error),
    #[error("Failed to attach cgroup BPF program: {0}")]
    AttachFailed(io::Error),
    #[error("Sockmap capacity exceeded")]
    CapacityExceeded,
    #[error("Flow not found in sockmap")]
    FlowNotFound,
    #[error("Permission denied (requires CAP_BPF / CAP_NET_ADMIN)")]
    PermissionDenied,
}

// -----------------------------------------------------------------------------
// Linux eBPF constants and raw BPF syscall ABI
// -----------------------------------------------------------------------------

// `bpf(2)` syscall numbers are architecture-specific. Only x86_64 and
// aarch64 are wired up here; other targets get a compile-time error
// rather than a silently-wrong number that would call an unrelated
// syscall at runtime.
#[cfg(target_arch = "x86_64")]
const SYS_BPF: i64 = 321;
#[cfg(target_arch = "aarch64")]
const SYS_BPF: i64 = 280;
#[cfg(not(any(target_arch = "x86_64", target_arch = "aarch64")))]
compile_error!(
    "caly-reactor::ebpf_sockmap supports only x86_64 and aarch64; \
     add the platform's __NR_bpf value before enabling this target"
);

pub const BPF_MAP_CREATE: c_int = 0;
pub const BPF_MAP_LOOKUP_ELEM: c_int = 1;
pub const BPF_MAP_UPDATE_ELEM: c_int = 2;
pub const BPF_MAP_DELETE_ELEM: c_int = 3;
pub const BPF_PROG_LOAD: c_int = 5;
pub const BPF_PROG_ATTACH: c_int = 8;
pub const BPF_PROG_DETACH: c_int = 9;

pub const BPF_MAP_TYPE_SOCKMAP: u32 = 14;
pub const BPF_MAP_TYPE_SOCKHASH: u32 = 15;

pub const BPF_PROG_TYPE_SOCK_OPS: u32 = 13;
pub const BPF_PROG_TYPE_SK_MSG: u32 = 14;

pub const BPF_SK_MSG_VERDICT: u32 = 14;
pub const BPF_CGROUP_SOCK_OPS: u32 = 15;

pub const BPF_ANY: u64 = 0;
pub const BPF_NOEXIST: u64 = 1;
pub const BPF_EXIST: u64 = 2;

#[repr(C)]
pub union bpf_attr {
    pub map_create: bpf_attr_map_create,
    pub map_elem: bpf_attr_map_elem,
    pub prog_load: bpf_attr_prog_load,
    pub prog_attach: bpf_attr_prog_attach,
    pub _padding: [u64; 18],
}

#[repr(C)]
#[derive(Clone, Copy)]
pub struct bpf_attr_map_create {
    pub map_type: u32,
    pub key_size: u32,
    pub value_size: u32,
    pub max_entries: u32,
    pub map_flags: u32,
    pub inner_map_fd: u32,
    pub numa_node: u32,
    pub map_name: [u8; 16],
    pub map_ifindex: u32,
    pub btf_fd: u32,
    pub btf_key_type_id: u32,
    pub btf_value_type_id: u32,
}

#[repr(C)]
#[derive(Clone, Copy)]
pub struct bpf_attr_map_elem {
    pub map_fd: u32,
    pub key: u64,
    pub value_or_next_key: u64,
    pub flags: u64,
}

#[repr(C)]
#[derive(Clone, Copy)]
pub struct bpf_attr_prog_load {
    pub prog_type: u32,
    pub insn_cnt: u32,
    pub insns: u64,
    pub license: u64,
    pub log_level: u32,
    pub log_size: u32,
    pub log_buf: u64,
    pub kern_version: u32,
    pub prog_flags: u32,
    pub prog_name: [u8; 16],
    pub prog_ifindex: u32,
    pub expected_attach_type: u32,
}

#[repr(C)]
#[derive(Clone, Copy)]
pub struct bpf_attr_prog_attach {
    pub target_fd: u32,
    pub attach_bpf_fd: u32,
    pub attach_type: u32,
    pub attach_flags: u32,
}

/// Thin wrapper around the `bpf(2)` syscall.
///
/// # Safety
///
/// `attr` must point to a fully initialized `bpf_attr` union whose active
/// variant matches `cmd`, and `size` must be the size the kernel expects
/// for that specific `cmd` (the size of the *active* union member, not
/// the union itself). Passing the wrong variant or an undersized buffer
/// causes the kernel to read past the supplied region.
pub unsafe fn sys_bpf(cmd: c_int, attr: *const bpf_attr, size: c_uint) -> c_int {
    // SAFETY: forwarded to the caller; see the function-level contract.
    unsafe { libc::syscall(SYS_BPF, cmd, attr, size) as c_int }
}

// -----------------------------------------------------------------------------
// Flow identification
// -----------------------------------------------------------------------------

/// Canonical 5-tuple used as the sockhash key.
///
/// Layout is fixed at 40 bytes and 4-byte aligned so it can be handed to
/// `BPF_MAP_UPDATE_ELEM` as a raw pointer without a translation step. The
/// `#[repr(C, align(4))]` annotation is load-bearing: both the kernel
/// sockhash ABI and the in-process simulation table hash the exact byte
/// sequence, so any padding change would silently desynchronize them.
#[repr(C, align(4))]
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub struct FlowKey {
    pub src_ip: [u8; 16],
    pub dst_ip: [u8; 16],
    pub src_port: u16,
    pub dst_port: u16,
    pub protocol: u8,
    pub _pad: [u8; 3],
}

impl FlowKey {
    /// Builds a TCP FlowKey from two IPv4 addresses and their ports.
    ///
    /// IPv4 addresses are stored in the low four bytes of the 16-byte
    /// field, matching the wire layout used by `sk_msg_md.remote_ip4`
    /// and by the BPF assembler in [`crate::bpf_asm`].
    pub fn new_v4(src_ip: [u8; 4], src_port: u16, dst_ip: [u8; 4], dst_port: u16) -> Self {
        let mut src_16 = [0u8; 16];
        let mut dst_16 = [0u8; 16];
        src_16[12..16].copy_from_slice(&src_ip);
        dst_16[12..16].copy_from_slice(&dst_ip);
        Self {
            src_ip: src_16,
            dst_ip: dst_16,
            src_port,
            dst_port,
            protocol: 6, // IPPROTO_TCP
            _pad: [0; 3],
        }
    }

    /// Returns the 5-tuple with source and destination exchanged.
    ///
    /// This is the key under which the *reverse* direction of a proxied
    /// flow must be stored: the packet flowing `B -> A` carries B's
    /// source address and A's destination address, so its sockhash key
    /// is the mirror of the forward key. Storing both directions under
    /// one key (as an earlier revision did) lets the second update
    /// silently overwrite the first, redirecting every packet back to
    /// its sender.
    #[inline]
    pub fn reverse(&self) -> Self {
        Self {
            src_ip: self.dst_ip,
            dst_ip: self.src_ip,
            src_port: self.dst_port,
            dst_port: self.src_port,
            protocol: self.protocol,
            _pad: [0; 3],
        }
    }
}

const _: () = assert!(std::mem::size_of::<FlowKey>() == 40);
const _: () = assert!(std::mem::align_of::<FlowKey>() == 4);

impl std::hash::Hash for FlowKey {
    fn hash<H: std::hash::Hasher>(&self, state: &mut H) {
        self.src_ip.hash(state);
        self.dst_ip.hash(state);
        self.src_port.hash(state);
        self.dst_port.hash(state);
        self.protocol.hash(state);
    }
}

/// Sockhash sizing and map type.
#[derive(Debug, Clone)]
pub struct SockmapConfig {
    pub max_entries: u32,
    pub use_sockhash: bool,
}

impl Default for SockmapConfig {
    fn default() -> Self {
        Self {
            max_entries: 65536,
            use_sockhash: true,
        }
    }
}

/// Manages the in-kernel sockhash and the SK_MSG verdict program that
/// drives zero-syscall L4 forwarding.
///
/// # Two-tier design
///
/// * **Kernel path** (`is_in_kernel() == true`): a real
///   `BPF_MAP_TYPE_SOCKHASH` fd plus an attached `BPF_PROG_TYPE_SK_MSG`
///   verdict program. `splice_direct_flow` writes both directions into
///   the kernel map.
/// * **Simulation path**: an in-process `HashMap` mirroring the map
///   semantics. Used when `bpf(2)` is unavailable (unprivileged
///   container, `CONFIG_BPF_SYSCALL=n`, Miri, non-Linux hosts). The
///   lookup/remove API remains functional; the kernel never sees the
///   flows.
pub struct SockmapController {
    map_fd: i32,
    prog_fd: Option<i32>,
    #[allow(dead_code)]
    config: SockmapConfig,
    in_kernel_active: AtomicBool,
    simulated_table: RwLock<HashMap<FlowKey, (i32, i32)>>,
}

impl SockmapController {
    /// Creates the sockhash and attaches the SK_MSG verdict program.
    ///
    /// On any failure along the way — `bpf(2)` denied, map create
    /// rejected, program load rejected, attach rejected — the controller
    /// silently degrades to the simulation path. The caller is expected
    /// to check [`Self::is_in_kernel`] before assuming kernel-side
    /// forwarding is active.
    pub fn new(config: SockmapConfig) -> Result<Self, EbpfError> {
        // Miri cannot execute `bpf(2)`; short-circuit to simulation so
        // the surrounding logic can still be exercised under the
        // interpreter. `cfg!` (not `#[cfg]`) keeps the real code path
        // visible to the compiler so it is type-checked on all targets.
        if cfg!(miri) {
            return Ok(Self::simulated(config));
        }

        let map_type = if config.use_sockhash {
            BPF_MAP_TYPE_SOCKHASH
        } else {
            BPF_MAP_TYPE_SOCKMAP
        };

        let mut attr: bpf_attr = unsafe { std::mem::zeroed() };
        // SAFETY: `attr` was zero-initialized on the stack; writing the
        // `map_create` variant is the only field we populate before
        // handing the pointer to the kernel for `BPF_MAP_CREATE`.
        unsafe {
            attr.map_create.map_type = map_type;
            attr.map_create.key_size = std::mem::size_of::<FlowKey>() as u32;
            // UAPI: SOCKHASH value_size is `sizeof(u32)` — the socket fd.
            attr.map_create.value_size = std::mem::size_of::<u32>() as u32;
            attr.map_create.max_entries = config.max_entries;
        }

        // SAFETY: `attr.map_create` is fully initialized above and
        // `size_of::<bpf_attr_map_create>()` is the exact size the
        // kernel's `BPF_MAP_CREATE` handler expects — passing the full
        // union size (as an earlier revision did) makes older kernels
        // read uninitialized trailing bytes.
        let ret = unsafe {
            sys_bpf(
                BPF_MAP_CREATE,
                &attr,
                std::mem::size_of::<bpf_attr_map_create>() as c_uint,
            )
        };

        if ret < 0 {
            // Any failure here means no in-kernel sockhash. Fall back to
            // simulation rather than failing the whole controller — the
            // reactor still needs a functional API surface.
            return Ok(Self::simulated(config));
        }
        let map_fd = ret;

        // Assemble the SK_MSG verdict program and load it.
        let prog_insns = crate::bpf_asm::assemble_sk_msg_verdict_prog(map_fd);
        // The kernel requires a NUL-terminated license string. "GPL" is
        // the minimal value that unlocks the `bpf_msg_redirect_hash`
        // helper; "Dual BSD/GPL" also works but costs four more bytes in
        // the load attribute.
        let license = b"GPL\0";

        let mut load_attr: bpf_attr = unsafe { std::mem::zeroed() };
        // SAFETY: see the `attr` initialization above — same pattern,
        // different variant.
        unsafe {
            load_attr.prog_load.prog_type = BPF_PROG_TYPE_SK_MSG;
            load_attr.prog_load.insn_cnt = prog_insns.len() as u32;
            load_attr.prog_load.insns = prog_insns.as_ptr() as u64;
            load_attr.prog_load.license = license.as_ptr() as u64;
        }

        // SAFETY: `load_attr.prog_load` is fully initialized; `prog_insns`
        // and `license` outlive the call.
        let prog_ret = unsafe {
            sys_bpf(
                BPF_PROG_LOAD,
                &load_attr,
                std::mem::size_of::<bpf_attr_prog_load>() as c_uint,
            )
        };

        if prog_ret < 0 {
            // Program load failed. The map fd is still valid and could be
            // used with a different program; we close nothing and fall
            // through to simulation to keep the fd bookkeeping simple.
            // SAFETY: `map_fd` was returned by the kernel moments ago and
            // has not been published to any other structure.
            unsafe { libc::close(map_fd) };
            return Ok(Self::simulated(config));
        }
        let prog_fd = prog_ret;

        // Attach the verdict program to the map.
        let mut attach_attr: bpf_attr = unsafe { std::mem::zeroed() };
        // SAFETY: same pattern as above.
        unsafe {
            attach_attr.prog_attach.target_fd = map_fd as u32;
            attach_attr.prog_attach.attach_bpf_fd = prog_fd as u32;
            attach_attr.prog_attach.attach_type = BPF_SK_MSG_VERDICT;
        }

        // SAFETY: `attach_attr.prog_attach` is fully initialized.
        let attach_ret = unsafe {
            sys_bpf(
                BPF_PROG_ATTACH,
                &attach_attr,
                std::mem::size_of::<bpf_attr_prog_attach>() as c_uint,
            )
        };

        if attach_ret < 0 {
            // SAFETY: both fds were returned by the kernel in this
            // function and are not yet stored anywhere else.
            unsafe {
                libc::close(prog_fd);
                libc::close(map_fd);
            }
            return Ok(Self::simulated(config));
        }

        Ok(Self {
            map_fd,
            prog_fd: Some(prog_fd),
            config,
            in_kernel_active: AtomicBool::new(true),
            simulated_table: RwLock::new(HashMap::new()),
        })
    }

    /// Constructs a controller that never touches the kernel.
    fn simulated(config: SockmapConfig) -> Self {
        Self {
            map_fd: -1,
            prog_fd: None,
            config,
            in_kernel_active: AtomicBool::new(false),
            simulated_table: RwLock::new(HashMap::new()),
        }
    }

    /// Returns `true` if the map and program are actually installed in
    /// the kernel and packets will be redirected without a syscall.
    #[inline]
    pub fn is_in_kernel(&self) -> bool {
        self.in_kernel_active.load(Ordering::Relaxed)
    }

    /// Kernel SK_MSG program fd, or `None` in simulation mode.
    #[inline]
    pub fn prog_fd(&self) -> Option<i32> {
        self.prog_fd
    }

    /// Kernel sockhash fd, or `-1` in simulation mode.
    #[inline]
    pub fn map_fd(&self) -> i32 {
        self.map_fd
    }

    /// Installs both directions of a proxied flow into the sockhash (or
    /// the simulation table).
    ///
    /// # Directional keys
    ///
    /// A sockhash entry maps a 4-tuple to the *receiving* socket. The
    /// two directions of a flow `client -> server` need two entries:
    ///
    /// * Forward: `FlowKey(client -> server)` -> `server_fd`.
    /// * Reverse: `FlowKey(client -> server).reverse()` -> `client_fd`.
    ///
    /// Writing both under the same key (as an earlier revision did)
    /// makes the second update overwrite the first, after which the
    /// kernel redirects every packet back to its sender. The reverse
    /// key is derived here, not by the caller, so this invariant cannot
    /// be accidentally violated.
    pub fn splice_direct_flow(
        &self,
        flow_key: &FlowKey,
        client_fd: i32,
        server_fd: i32,
    ) -> Result<(), EbpfError> {
        if self.is_in_kernel() {
            let reverse_key = flow_key.reverse();
            self.upsert_entry(flow_key, server_fd)?;
            self.upsert_entry(&reverse_key, client_fd)?;
        }

        let mut table = self
            .simulated_table
            .write()
            .unwrap_or_else(|poisoned| poisoned.into_inner());
        table.insert(*flow_key, (client_fd, server_fd));
        Ok(())
    }

    /// Removes both directions of a flow from the sockhash (or the
    /// simulation table).
    ///
    /// Mirror of [`Self::splice_direct_flow`]: the same two keys that
    /// were inserted are the two keys that must be deleted.
    pub fn remove_direct_flow(&self, flow_key: &FlowKey) -> Result<(), EbpfError> {
        if self.is_in_kernel() {
            let reverse_key = flow_key.reverse();
            self.delete_entry(flow_key)?;
            self.delete_entry(&reverse_key)?;
        }

        let mut table = self
            .simulated_table
            .write()
            .unwrap_or_else(|poisoned| poisoned.into_inner());
        table.remove(flow_key);
        Ok(())
    }

    /// Returns `(client_fd, server_fd)` for a previously spliced flow.
    ///
    /// Always reads the in-process table, even when the kernel path is
    /// active: the kernel sockhash is not queryable from userspace
    /// without a round trip, and the in-process table is the authoritative
    /// record of which flow a given `FlowKey` belongs to.
    pub fn lookup_direct_flow(&self, flow_key: &FlowKey) -> Option<(i32, i32)> {
        let table = self
            .simulated_table
            .read()
            .unwrap_or_else(|poisoned| poisoned.into_inner());
        table.get(flow_key).copied()
    }

    /// Writes a single `(key, socket_fd)` pair into the kernel map.
    fn upsert_entry(&self, key: &FlowKey, socket_fd: i32) -> Result<(), EbpfError> {
        debug_assert!(
            self.map_fd >= 0,
            "upsert_entry called on a controller without a kernel map fd",
        );

        let value: u32 = socket_fd as u32;
        let mut attr: bpf_attr = unsafe { std::mem::zeroed() };
        // SAFETY: `attr.map_elem` is fully populated before the syscall;
        // `key` and `value` are valid for the duration of the call.
        unsafe {
            attr.map_elem.map_fd = self.map_fd as u32;
            attr.map_elem.key = key as *const FlowKey as u64;
            attr.map_elem.value_or_next_key = &value as *const u32 as u64;
            attr.map_elem.flags = BPF_ANY;
        }

        // SAFETY: `attr.map_elem` is fully initialized; `key` and `value`
        // outlive the syscall. `size_of::<bpf_attr_map_elem>()` is the
        // size the kernel's `BPF_MAP_UPDATE_ELEM` handler expects.
        let ret = unsafe {
            sys_bpf(
                BPF_MAP_UPDATE_ELEM,
                &attr,
                std::mem::size_of::<bpf_attr_map_elem>() as c_uint,
            )
        };

        if ret < 0 {
            let err = io::Error::last_os_error();
            // `ENOSPC`/`E2BIG` mean the map is full; treat as a distinct
            // error so callers can evict an old flow and retry.
            if matches!(err.raw_os_error(), Some(libc::ENOSPC) | Some(libc::E2BIG)) {
                return Err(EbpfError::CapacityExceeded);
            }
            return Err(EbpfError::SyscallFailed(err));
        }
        Ok(())
    }

    /// Deletes a single `(key)` from the kernel map. Missing entries are
    /// treated as success — the map is a cache, not a ledger.
    fn delete_entry(&self, key: &FlowKey) -> Result<(), EbpfError> {
        debug_assert!(
            self.map_fd >= 0,
            "delete_entry called on a controller without a kernel map fd",
        );

        let mut attr: bpf_attr = unsafe { std::mem::zeroed() };
        // SAFETY: `attr.map_elem` is fully populated before the syscall;
        // `key` is valid for the duration of the call.
        unsafe {
            attr.map_elem.map_fd = self.map_fd as u32;
            attr.map_elem.key = key as *const FlowKey as u64;
        }

        // SAFETY: `attr.map_elem` is fully initialized for `BPF_MAP_DELETE_ELEM`.
        let ret = unsafe {
            sys_bpf(
                BPF_MAP_DELETE_ELEM,
                &attr,
                std::mem::size_of::<bpf_attr_map_elem>() as c_uint,
            )
        };

        if ret < 0 {
            let err = io::Error::last_os_error();
            // `ENOENT` means the key is not present, which for a cache
            // delete is a benign outcome: the caller's postcondition
            // ("this key is gone") already holds.
            if err.raw_os_error() == Some(libc::ENOENT) {
                return Ok(());
            }
            return Err(EbpfError::SyscallFailed(err));
        }
        Ok(())
    }
}

impl Drop for SockmapController {
    fn drop(&mut self) {
        if let Some(pfd) = self.prog_fd {
            // SAFETY: `pfd` was returned by `bpf(BPF_PROG_LOAD)` and has
            // never been closed; `Drop` runs at most once.
            unsafe {
                libc::close(pfd);
            }
        }
        if self.map_fd >= 0 {
            // SAFETY: `map_fd` was returned by `bpf(BPF_MAP_CREATE)` and
            // has never been closed; `Drop` runs at most once.
            unsafe {
                libc::close(self.map_fd);
            }
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    /// `FlowKey::reverse` must be an involution and must swap every
    /// tuple member independently.
    #[test]
    fn test_flow_key_reverse_is_involution() {
        let key = FlowKey::new_v4([10, 0, 0, 1], 40000, [192, 168, 1, 1], 443);
        let rev = key.reverse();
        assert_eq!(rev.src_ip[12..16], [192, 168, 1, 1]);
        assert_eq!(rev.dst_ip[12..16], [10, 0, 0, 1]);
        assert_eq!(rev.src_port, 443);
        assert_eq!(rev.dst_port, 40000);
        assert_eq!(rev.protocol, key.protocol);
        assert_eq!(rev.reverse(), key, "reverse must be an involution");

        // A symmetric key is its own reverse — pathological but legal.
        let sym = FlowKey::new_v4([0, 0, 0, 0], 1234, [0, 0, 0, 0], 1234);
        assert_eq!(sym.reverse(), sym);
    }

    /// Regression test: `splice_direct_flow` must install both the
    /// forward and the reverse direction into the kernel map so neither
    /// overwrites the other. Under the previous single-key
    /// implementation, `lookup_direct_flow` still returned a coherent
    /// pair (the in-process table was always correct) but the kernel
    /// saw only the *last* fd written, redirecting every packet back to
    /// the client. We cannot inspect a kernel map from a unit test, so
    /// we verify the invariant at the abstraction boundary: the reverse
    /// key is distinct from the forward key, and both are eventually
    /// reflected in `reverse_key()` bookkeeping.
    #[test]
    fn test_splice_uses_distinct_keys_per_direction() {
        let fwd = FlowKey::new_v4([10, 0, 0, 1], 40000, [192, 168, 1, 1], 443);
        let rev = fwd.reverse();
        assert_ne!(
            fwd, rev,
            "forward and reverse keys must be distinct, or the kernel map \
             entry for one direction will overwrite the other",
        );

        // In simulation mode the controller must accept the call and
        // record the flow for lookup. Kernel-mode behaviour is exercised
        // by the integration environment, not this unit test.
        let ctrl = SockmapController::new(SockmapConfig::default())
            .expect("controller construction must not fail");
        assert!(!ctrl.is_in_kernel(), "unit tests run without CAP_BPF");

        ctrl.splice_direct_flow(&fwd, 11, 22)
            .expect("splice must succeed in simulation mode");
        assert_eq!(ctrl.lookup_direct_flow(&fwd), Some((11, 22)));

        ctrl.remove_direct_flow(&fwd)
            .expect("remove must succeed in simulation mode");
        assert_eq!(ctrl.lookup_direct_flow(&fwd), None);
    }

    /// `remove_direct_flow` on a key that was never inserted must be a
    /// no-op, not an error. The simulated table follows the kernel's
    /// `ENOENT`-as-success convention.
    #[test]
    fn test_remove_unknown_flow_is_noop() {
        let ctrl = SockmapController::new(SockmapConfig::default()).expect("controller");
        let key = FlowKey::new_v4([1, 2, 3, 4], 1, [5, 6, 7, 8], 2);
        ctrl.remove_direct_flow(&key).expect("missing key is benign");
        assert_eq!(ctrl.lookup_direct_flow(&key), None);
    }
}
