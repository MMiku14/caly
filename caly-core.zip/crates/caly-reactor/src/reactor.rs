#![allow(unused_unsafe)]
//! CoreReactor: Per-Core Event Loop, Async Outbound Dialing, and Dispatcher.

use std::collections::{HashMap, VecDeque};
use std::net::{IpAddr, Ipv4Addr};
use std::sync::atomic::{AtomicBool, Ordering};
use std::sync::Arc;
use thiserror::Error;

use caly_memory::IngressFrameDesc;
use caly_transducer::{FlowDecision, ProtocolTransducer, TransducerOutput};

use crate::af_xdp::{XskConfig, XskError, XskSocket};
use crate::ebpf_sockmap::{FlowKey, SockmapConfig, SockmapController};
use crate::epoll_driver::{EpollDriver, EPOLL_LISTEN, EPOLL_READ, EPOLL_WRITE};
use crate::io_uring_driver::{
    pin_to_core, AdaptiveBackoff, CqeEvent, FixedBufferPool, IoUringConfig, IoUringDriver,
    IoUringError, IORING_CQE_F_MORE,
};
use crate::socket_addr::GenericSockAddr;
use crate::token::{IoOperation, IoToken};

#[derive(Error, Debug)]
pub enum ReactorError {
    #[error("io_uring driver error: {0}")]
    IoUring(#[from] IoUringError),

    #[error("AF_XDP driver error: {0}")]
    AfXdp(#[from] XskError),

    #[error("eBPF sockmap error: {0}")]
    Sockmap(#[from] crate::ebpf_sockmap::EbpfError),

    #[error("Connection error: {0}")]
    Connection(String),
}

/// Operational reactor engine backend.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum ReactorBackend {
    /// High-performance Linux io_uring SQPOLL with pre-registered fixed buffers.
    IoUring,
    /// Standard Linux Edge-Triggered epoll fallback.
    Epoll,
    /// Automatically try io_uring; if unsupported or restricted (ENOSYS/EPERM), fall back to Epoll.
    Auto,
}

/// Operational ingress driver mode for the Core Reactor.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum IngressMode {
    /// Linux io_uring SQPOLL with pre-registered fixed buffers.
    IoUring,
    /// Linux AF_XDP (XSK) Zero-Copy Kernel Bypass driver (< 500ns latency).
    AfXdp,
    /// Hybrid concurrency: io_uring for standard streams + AF_XDP for raw bypass.
    Hybrid,
}

/// Lifecycle state machine for a client-server connection pair.
#[derive(Debug, Clone, PartialEq, Eq)]
pub enum ConnPhase {
    /// Inbound handshake inspection and negotiation in progress.
    Handshaking,
    /// Asynchronous outbound TCP dialing in flight to target server.
    ConnectingServer { server_fd: i32, target: String },
    /// Handshake completed; bidirectional streaming relay or eBPF direct splice active.
    Established,
}

/// Trait for in-place stream transformations (WebSocket unmasking, REALITY decrypting).
pub trait InPlacePipeline: Send {
    fn apply_in_place(&mut self, buffer: &mut [u8]);
}

impl<T: caly_pipe::pipeline::InPlaceTransducer + Send> InPlacePipeline for T {
    #[inline(always)]
    fn apply_in_place(&mut self, buffer: &mut [u8]) {
        let _ = self.transform_mut(buffer);
    }
}

/// Routing decision not yet known (mid-handshake).
#[repr(u8)]
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum FlowRouteState {
    Unknown = 0,
    Direct = 1,
    Proxy = 2,
}

impl FlowRouteState {
    #[inline]
    pub const fn as_u8(self) -> u8 {
        self as u8
    }
}

/// Legacy `u8` constants retained for source compatibility.
pub const ROUTE_UNKNOWN: u8 = FlowRouteState::Unknown as u8;
pub const ROUTE_DIRECT: u8 = FlowRouteState::Direct as u8;
pub const ROUTE_PROXY: u8 = FlowRouteState::Proxy as u8;

/// Maximum bytes buffered per direction, per connection (1 MiB).
const MAX_PENDING_PER_DIRECTION: usize = 1 << 20;

/// Stack buffer size used to copy small payloads out of the fixed buffer pool.
const STACK_SCRATCH_SIZE: usize = 4096;

/// Result of a queue-and-send attempt on a [`ConnectionState`].
#[derive(Debug, PartialEq, Eq)]
pub(crate) enum SendResult {
    /// All bytes handed to the kernel (or appended to the queue) safely.
    Ok,
    /// Peer window full; bytes are queued and will be flushed on the next opportunity.
    Queued,
    /// Connection is unrecoverable; caller should `teardown_connection`.
    Error,
}

/// A chunk of outbound data waiting in the per-connection send queue.
///
/// Tracks `offset` alongside `Vec<u8>` to avoid `Vec::drain(..n)` memmoves on
/// partial writes: advancing is O(1), and the chunk is popped only once fully sent.
#[derive(Debug)]
pub struct PendingChunk {
    data: Vec<u8>,
    offset: usize,
}

impl PendingChunk {
    #[inline]
    pub fn new(data: Vec<u8>) -> Self {
        Self { data, offset: 0 }
    }

    #[inline]
    pub fn remaining(&self) -> &[u8] {
        &self.data[self.offset..]
    }

    #[inline]
    pub fn len(&self) -> usize {
        self.data.len() - self.offset
    }

    #[inline]
    pub fn is_empty(&self) -> bool {
        self.offset >= self.data.len()
    }

    #[inline]
    pub fn advance(&mut self, n: usize) {
        debug_assert!(
            self.offset + n <= self.data.len(),
            "PendingChunk::advance beyond end: offset={}, n={}, len={}",
            self.offset,
            n,
            self.data.len(),
        );
        self.offset += n;
    }
}

/// State of an active proxy connection session.
pub struct ConnectionState {
    pub client_fd: i32,
    pub server_fd: Option<i32>,
    pub phase: ConnPhase,
    pub transducer: ProtocolTransducer,
    pub is_spliced: bool,
    pub rx_buf_idx: Option<u16>,
    /// Read buffer for the server-side socket.
    pub server_rx_buf: Option<u16>,
    pub flow_key: Option<FlowKey>,
    pub pending_initial_payload: Option<Vec<u8>>,
    pub target_addr: Option<GenericSockAddr>,
    pub speculative_ip: Option<IpAddr>,
    pub reverse_pipeline: Option<Box<dyn InPlacePipeline>>,
    /// Outbound bytes destined for the server socket.
    pub pending_to_server: VecDeque<PendingChunk>,
    /// Mirror of `pending_to_server` for the client socket.
    pub pending_to_client: VecDeque<PendingChunk>,
    /// Cumulative bytes queued in `pending_to_server`.
    pub pending_bytes_server: usize,
    /// Cumulative bytes queued in `pending_to_client`.
    pub pending_bytes_client: usize,
    /// Cached routing verdict, updated once the protocol transducer publishes its `FlowDecision`.
    pub route: FlowRouteState,
}

impl ConnectionState {
    fn new(
        client_fd: i32,
        server_fd: Option<i32>,
        phase: ConnPhase,
        rx_buf_idx: Option<u16>,
        server_rx_buf: Option<u16>,
        flow_key: Option<FlowKey>,
    ) -> Self {
        Self {
            client_fd,
            server_fd,
            phase,
            transducer: ProtocolTransducer::new(),
            is_spliced: false,
            rx_buf_idx,
            server_rx_buf,
            flow_key,
            pending_initial_payload: None,
            target_addr: None,
            speculative_ip: None,
            reverse_pipeline: None,
            pending_to_server: VecDeque::new(),
            pending_to_client: VecDeque::new(),
            pending_bytes_server: 0,
            pending_bytes_client: 0,
            route: FlowRouteState::Unknown,
        }
    }

    #[inline]
    fn enqueue_to_server(&mut self, payload: Vec<u8>) {
        self.pending_bytes_server = self.pending_bytes_server.saturating_add(payload.len());
        self.pending_to_server.push_back(PendingChunk::new(payload));
    }

    #[inline]
    fn send_to_server(&mut self, server_fd: i32, data: &[u8]) -> SendResult {
        Self::send_or_queue(
            server_fd,
            data,
            &mut self.pending_to_server,
            &mut self.pending_bytes_server,
        )
    }

    #[inline]
    fn send_to_client(&mut self, data: &[u8]) -> SendResult {
        Self::send_or_queue(
            self.client_fd,
            data,
            &mut self.pending_to_client,
            &mut self.pending_bytes_client,
        )
    }

    #[inline]
    fn send_or_queue(
        fd: i32,
        data: &[u8],
        queue: &mut VecDeque<PendingChunk>,
        pending_bytes: &mut usize,
    ) -> SendResult {
        if *pending_bytes > MAX_PENDING_PER_DIRECTION {
            return SendResult::Error;
        }

        // SAFETY: `fd` is an open socket owned by this connection; `data` is a valid slice.
        let n = unsafe {
            libc::send(
                fd,
                data.as_ptr() as *const libc::c_void,
                data.len(),
                libc::MSG_NOSIGNAL | libc::MSG_DONTWAIT,
            )
        };

        if n < 0 {
            let err = std::io::Error::last_os_error();
            if err.kind() == std::io::ErrorKind::WouldBlock {
                queue.push_back(PendingChunk::new(data.to_vec()));
                *pending_bytes = pending_bytes.saturating_add(data.len());
                return SendResult::Queued;
            }
            return SendResult::Error;
        }

        let sent = n as usize;
        if sent < data.len() {
            let tail = data.len() - sent;
            queue.push_back(PendingChunk::new(data[sent..].to_vec()));
            *pending_bytes = pending_bytes.saturating_add(tail);
            return SendResult::Queued;
        }
        SendResult::Ok
    }

    #[inline]
    fn flush_queue(
        fd: i32,
        queue: &mut VecDeque<PendingChunk>,
        pending_bytes: &mut usize,
    ) -> SendResult {
        loop {
            let (rem_ptr, rem_len) = match queue.front() {
                Some(front) => {
                    let s = front.remaining();
                    (s.as_ptr(), s.len())
                }
                None => return SendResult::Ok,
            };

            if rem_len == 0 {
                queue.pop_front();
                continue;
            }

            // SAFETY: `rem_ptr` points to the front chunk's buffer and is only read by `send(2)`.
            let n = unsafe {
                libc::send(
                    fd,
                    rem_ptr as *const libc::c_void,
                    rem_len,
                    libc::MSG_NOSIGNAL | libc::MSG_DONTWAIT,
                )
            };
            if n < 0 {
                let err = std::io::Error::last_os_error();
                if err.kind() == std::io::ErrorKind::WouldBlock {
                    return SendResult::Queued;
                }
                return SendResult::Error;
            }

            let sent = n as usize;
            let front_len = queue.front().unwrap().len();
            if sent < front_len {
                queue.front_mut().unwrap().advance(sent);
                *pending_bytes = pending_bytes.saturating_sub(sent);
                return SendResult::Queued;
            }
            queue.pop_front();
            *pending_bytes = pending_bytes.saturating_sub(front_len);
        }
    }

    fn flush_to_server(&mut self) -> SendResult {
        match self.server_fd {
            Some(fd) => Self::flush_queue(
                fd,
                &mut self.pending_to_server,
                &mut self.pending_bytes_server,
            ),
            None => SendResult::Ok,
        }
    }

    fn flush_to_client(&mut self) -> SendResult {
        Self::flush_queue(
            self.client_fd,
            &mut self.pending_to_client,
            &mut self.pending_bytes_client,
        )
    }

    #[inline]
    fn has_pending_writes(&self) -> bool {
        !self.pending_to_server.is_empty() || !self.pending_to_client.is_empty()
    }
}

#[derive(Debug, Clone)]
pub struct CoreReactorConfig {
    pub core_id: usize,
    pub backend: ReactorBackend,
    pub ingress_mode: IngressMode,
    pub ring_entries: u32,
    pub fixed_buffers: usize,
    pub buffer_size: usize,
    pub spin_limit: u32,
    pub xsk_config: Option<XskConfig>,
}

impl Default for CoreReactorConfig {
    fn default() -> Self {
        Self {
            core_id: 0,
            backend: ReactorBackend::Auto,
            ingress_mode: IngressMode::IoUring,
            ring_entries: 1024,
            fixed_buffers: 512,
            buffer_size: 16384,
            spin_limit: 100,
            xsk_config: None,
        }
    }
}

pub struct CoreReactor {
    core_id: usize,
    backend: ReactorBackend,
    ingress_mode: IngressMode,
    epoll: Option<EpollDriver>,
    ring: IoUringDriver,
    xsk: Option<XskSocket>,
    sockmap: SockmapController,
    connections: HashMap<u64, ConnectionState>,
    flow_index: HashMap<FlowKey, u64>,
    dirty_conns: VecDeque<u64>,
    /// Read buffers belonging to already-torn-down connections awaiting their in-flight CQE.
    orphaned_client_read: HashMap<u32, u16>,
    /// Same as `orphaned_client_read`, for server-side read SQEs.
    orphaned_server_read: HashMap<u32, u16>,
    next_conn_id: u64,
    backoff: AdaptiveBackoff,
    running: Arc<AtomicBool>,
    xsk_rx_batch: Vec<IngressFrameDesc>,
    pub listener_fd: Option<i32>,
}

impl CoreReactor {
    pub fn new(config: CoreReactorConfig) -> Result<Self, ReactorError> {
        let io_config = IoUringConfig {
            entries: config.ring_entries,
            sqpoll_cpu: Some(config.core_id as u32),
            sqpoll_idle_ms: 2000,
            fixed_buffer_count: config.fixed_buffers,
            fixed_buffer_size: config.buffer_size,
        };

        let ring = IoUringDriver::new(io_config)?;
        let sockmap = SockmapController::new(SockmapConfig::default())?;

        let (backend, epoll) = match config.backend {
            ReactorBackend::Epoll => {
                let ep = EpollDriver::new().map_err(|e| {
                    ReactorError::Connection(format!("epoll driver creation failed: {e}"))
                })?;
                (ReactorBackend::Epoll, Some(ep))
            }
            ReactorBackend::IoUring => (ReactorBackend::IoUring, None),
            ReactorBackend::Auto => {
                if ring.is_kernel() {
                    (ReactorBackend::IoUring, None)
                } else {
                    let ep = EpollDriver::new().map_err(|e| {
                        ReactorError::Connection(format!("epoll fallback creation failed: {e}"))
                    })?;
                    (ReactorBackend::Epoll, Some(ep))
                }
            }
        };

        let xsk = match config.ingress_mode {
            IngressMode::AfXdp | IngressMode::Hybrid => {
                let xsk_cfg = config.xsk_config.unwrap_or_default();
                let umem = caly_memory::HugePageMemory::allocate(
                    (xsk_cfg.chunk_size * xsk_cfg.fill_size) as usize,
                    caly_memory::HugePageSize::Standard4KiB,
                )
                .map_err(|e| ReactorError::Connection(format!("UMEM alloc failed: {e}")))?;
                let mut sock = XskSocket::new_with_memory(umem, xsk_cfg)?;
                let _ = sock.populate_fill_ring(64);
                Some(sock)
            }
            IngressMode::IoUring => None,
        };

        Ok(Self {
            core_id: config.core_id,
            backend,
            ingress_mode: config.ingress_mode,
            epoll,
            ring,
            xsk,
            sockmap,
            connections: HashMap::new(),
            flow_index: HashMap::new(),
            dirty_conns: VecDeque::new(),
            orphaned_client_read: HashMap::new(),
            orphaned_server_read: HashMap::new(),
            next_conn_id: 1,
            backoff: AdaptiveBackoff::new(config.spin_limit),
            running: Arc::new(AtomicBool::new(true)),
            xsk_rx_batch: vec![IngressFrameDesc::default(); 64],
            listener_fd: None,
        })
    }

    #[inline]
    pub fn core_id(&self) -> usize {
        self.core_id
    }

    #[inline]
    pub fn running_handle(&self) -> Arc<AtomicBool> {
        self.running.clone()
    }

    #[inline]
    pub fn buffer_pool(&mut self) -> &mut FixedBufferPool {
        self.ring.buffer_pool()
    }

    /// Number of active connections currently tracked by this reactor.
    #[inline]
    pub fn connection_count(&self) -> usize {
        self.connections.len()
    }

    /// Returns a shared reference to the connection state identified by `conn_id`,
    /// or `None` if no such connection is currently registered.
    #[inline]
    pub fn connection(&self, conn_id: u64) -> Option<&ConnectionState> {
        self.connections.get(&conn_id)
    }

    /// Returns the active backend engine.
    #[inline(always)]
    pub fn backend(&self) -> ReactorBackend {
        self.backend
    }

    /// Attaches a listening socket to this reactor using multishot accept or epoll.
    pub fn attach_listener(&mut self, listen_fd: i32) -> Result<(), ReactorError> {
        if let Some(old) = self.listener_fd {
            if old != listen_fd {
                eprintln!("caly-reactor: replacing listener {old} with {listen_fd}");
            }
        }
        self.listener_fd = Some(listen_fd);
        let accept_token = IoToken::encode(IoOperation::Accept, None, 0);

        match self.backend {
            ReactorBackend::IoUring => {
                self.ring.submit_accept_multishot(listen_fd, accept_token)?;
            }
            ReactorBackend::Epoll => {
                if let Some(ref epoll) = self.epoll {
                    epoll
                        .add_fd(listen_fd, EPOLL_LISTEN, accept_token)
                        .map_err(|e| {
                            ReactorError::Connection(format!("epoll attach_listener failed: {e}"))
                        })?;
                }
            }
            ReactorBackend::Auto => unreachable!(),
        }
        Ok(())
    }

    pub fn register_connection(
        &mut self,
        client_fd: i32,
        server_fd: Option<i32>,
        flow_key: Option<FlowKey>,
    ) -> Result<u64, ReactorError> {
        let conn_id = self.next_conn_id;
        if conn_id > u32::MAX as u64 {
            return Err(ReactorError::Connection(
                "conn_id space exhausted (u32 overflow)".to_string(),
            ));
        }
        self.next_conn_id += 1;

        let buf_idx = self.ring.buffer_pool().acquire()?;
        let phase = if server_fd.is_some() {
            ConnPhase::Established
        } else {
            ConnPhase::Handshaking
        };

        let user_data = IoToken::encode(IoOperation::ReadClient, Some(buf_idx), conn_id as u32);

        // 1. Submit initial client read / register epoll interest.
        match self.backend {
            ReactorBackend::IoUring => {
                if let Err(e) = self.ring.submit_read_fixed(client_fd, buf_idx, 0, 0, user_data) {
                    self.ring.buffer_pool().release(buf_idx);
                    return Err(e.into());
                }
            }
            ReactorBackend::Epoll => {
                if let Some(ref epoll) = self.epoll {
                    if let Err(e) = epoll.add_fd(client_fd, EPOLL_READ, user_data) {
                        self.ring.buffer_pool().release(buf_idx);
                        return Err(ReactorError::Connection(format!(
                            "epoll register_connection failed: {e}"
                        )));
                    }
                }
            }
            ReactorBackend::Auto => unreachable!(),
        }

        // 2. Server-side read setup (io_uring only).
        let server_rx_buf = if server_fd.is_some() && self.backend == ReactorBackend::IoUring {
            match self.ring.buffer_pool().acquire() {
                Ok(b) => Some(b),
                Err(e) => {
                    if let Some(ref epoll) = self.epoll {
                        let _ = epoll.remove_fd(client_fd);
                    }
                    self.ring.buffer_pool().release(buf_idx);
                    return Err(ReactorError::Connection(format!(
                        "server-side rx buffer acquisition failed: {e:?}"
                    )));
                }
            }
        } else {
            None
        };

        if self.backend == ReactorBackend::IoUring {
            if let (Some(sfd), Some(s_buf)) = (server_fd, server_rx_buf) {
                if let Err(e) = self.submit_read_fixed_with_token(
                    sfd,
                    IoOperation::ReadServer,
                    s_buf,
                    conn_id as u32,
                ) {
                    if let Some(ref epoll) = self.epoll {
                        let _ = epoll.remove_fd(client_fd);
                    }
                    self.ring.buffer_pool().release(buf_idx);
                    self.ring.buffer_pool().release(s_buf);
                    return Err(e.into());
                }
            }
        }

        let state = ConnectionState::new(
            client_fd,
            server_fd,
            phase,
            Some(buf_idx),
            server_rx_buf,
            flow_key,
        );

        if let Some(key) = state.flow_key {
            self.flow_index.insert(key, conn_id);
        }
        self.connections.insert(conn_id, state);
        Ok(conn_id)
    }

    pub fn run_tick(&mut self) -> Result<usize, ReactorError> {
        let mut total_events = 0;

        // Drain any queued outbound bytes before accepting new input.
        self.flush_pending_queues();

        // 1. Process io_uring submissions & completions
        if self.backend == ReactorBackend::IoUring
            && matches!(self.ingress_mode, IngressMode::IoUring | IngressMode::Hybrid)
        {
            let _ = self.ring.flush_submissions()?;

            let mut completed_events = Vec::with_capacity(32);
            self.ring.reap_completions(|cqe| completed_events.push(cqe));

            total_events += completed_events.len();
            for cqe in completed_events {
                self.handle_cqe(cqe)?;
            }
        }

        // 2. Process Epoll events when running in Epoll fallback mode
        if self.backend == ReactorBackend::Epoll {
            if let Some(ref epoll) = self.epoll {
                let mut events = [libc::epoll_event { events: 0, u64: 0 }; 64];
                let count = epoll
                    .poll(&mut events, 0)
                    .map_err(|e| ReactorError::Connection(e.to_string()))?;
                total_events += count;
                for ev in events.iter().take(count) {
                    self.handle_epoll_event(*ev)?;
                }
            }
        }

        // 3. Process AF_XDP Zero-Copy Ingress
        if matches!(self.ingress_mode, IngressMode::AfXdp | IngressMode::Hybrid) {
            if let Some(ref mut xsk) = self.xsk {
                if let Ok(rx_count) = xsk.poll_rx_batch(&mut self.xsk_rx_batch) {
                    total_events += rx_count;
                    for i in 0..rx_count {
                        let frame = self.xsk_rx_batch[i];
                        self.handle_xsk_frame(&frame)?;
                    }
                }
            }
        }

        if total_events > 0 {
            self.backoff.reset();
        } else {
            self.backoff.spin();
        }

        Ok(total_events)
    }

    pub fn handle_cqe(&mut self, cqe: CqeEvent) -> Result<(), ReactorError> {
        let token = IoToken::decode(cqe.user_data);
        match token.op {
            IoOperation::WriteClient | IoOperation::WriteServer => {
                self.on_cqe_write(token, cqe.result);
            }
            IoOperation::Close => {}
            IoOperation::Accept => {
                self.on_cqe_accept(cqe.result, cqe.flags);
            }
            IoOperation::Connect => {
                self.on_cqe_connect(token, cqe.result);
            }
            IoOperation::ReadServer => {
                self.on_cqe_read_server(token, cqe.result);
            }
            IoOperation::ReadClient => {
                self.on_cqe_read_client(token, cqe.result);
            }
        }
        Ok(())
    }

    pub fn teardown_connection(&mut self, conn_id: u64) {
        let Some(mut conn) = self.connections.remove(&conn_id) else {
            eprintln!("caly-reactor: teardown_connection on unknown conn_id={conn_id}");
            return;
        };

        if let Some(key) = conn.flow_key {
            self.flow_index.remove(&key);
            let _ = self.sockmap.remove_direct_flow(&key);
        }

        let is_iouring = self.backend == ReactorBackend::IoUring;

        if let Some(buf_idx) = conn.rx_buf_idx.take() {
            if is_iouring {
                self.orphaned_client_read.insert(conn_id as u32, buf_idx);
            } else {
                self.ring.buffer_pool().release(buf_idx);
            }
        }
        if let Some(s_buf) = conn.server_rx_buf.take() {
            if is_iouring {
                self.orphaned_server_read.insert(conn_id as u32, s_buf);
            } else {
                self.ring.buffer_pool().release(s_buf);
            }
        }

        if let Some(ref epoll) = self.epoll {
            let _ = epoll.remove_fd(conn.client_fd);
            if let Some(s_fd) = conn.server_fd {
                let _ = epoll.remove_fd(s_fd);
            }
        }

        if is_iouring {
            let close_client_token = IoToken::encode(IoOperation::Close, None, conn_id as u32);
            let _ = self.ring.submit_close(conn.client_fd, close_client_token);
            if let Some(server_fd) = conn.server_fd {
                let close_server_token =
                    IoToken::encode(IoOperation::Close, Some(u16::MAX - 1), conn_id as u32);
                let _ = self.ring.submit_close(server_fd, close_server_token);
            }
            let _ = self.ring.flush_submissions();
        } else {
            // SAFETY: `client_fd` and `server_fd` are open descriptors owned by this connection.
            unsafe {
                libc::close(conn.client_fd);
                if let Some(s_fd) = conn.server_fd {
                    libc::close(s_fd);
                }
            }
        }
    }

    pub fn run_loop(&mut self) -> Result<(), ReactorError> {
        let _ = pin_to_core(self.core_id);
        while self.running.load(Ordering::Relaxed) {
            self.run_tick()?;
        }
        let ids: Vec<u64> = self.connections.keys().copied().collect();
        for id in ids {
            self.teardown_connection(id);
        }
        let _ = self.ring.flush_submissions();
        Ok(())
    }

    // ─── Internal Helpers: Queue & Buffer Management ──────────────────────────

    #[inline]
    fn mark_dirty(&mut self, conn_id: u64) {
        if !self.dirty_conns.contains(&conn_id) {
            self.dirty_conns.push_back(conn_id);
        }
    }

    fn flush_pending_queues(&mut self) {
        let mut to_teardown: Vec<u64> = Vec::new();
        let mut remaining = self.dirty_conns.len();

        while remaining > 0 {
            remaining -= 1;
            let Some(conn_id) = self.dirty_conns.pop_front() else {
                break;
            };
            let Some(conn) = self.connections.get_mut(&conn_id) else {
                continue;
            };

            if matches!(conn.flush_to_server(), SendResult::Error)
                || matches!(conn.flush_to_client(), SendResult::Error)
            {
                to_teardown.push(conn_id);
                continue;
            }

            if conn.has_pending_writes() {
                self.dirty_conns.push_back(conn_id);
            }
        }

        for id in to_teardown {
            self.teardown_connection(id);
        }
    }

    #[inline]
    fn submit_read_fixed_with_token(
        &mut self,
        fd: i32,
        op: IoOperation,
        buf_idx: u16,
        conn_id: u32,
    ) -> Result<(), IoUringError> {
        let token = IoToken::encode(op, Some(buf_idx), conn_id);
        self.ring.submit_read_fixed(fd, buf_idx, 0, 0, token)
    }

    /// Acquires a fixed buffer, copies `payload` into it, and submits a write SQE.
    /// Automatically releases the buffer if SQE submission fails.
    fn submit_buffered_write(
        &mut self,
        fd: i32,
        op: IoOperation,
        payload: &[u8],
        conn_id: u32,
    ) -> bool {
        let Ok(write_buf) = self.ring.buffer_pool().acquire() else {
            return false;
        };
        let out_slice = self.ring.buffer_pool().get_slice_mut(write_buf);
        let len = payload.len().min(out_slice.len());
        out_slice[..len].copy_from_slice(&payload[..len]);

        let write_token = IoToken::encode(op, Some(write_buf), conn_id);
        if self
            .ring
            .submit_write_fixed(fd, write_buf, len as u32, 0, write_token)
            .is_err()
        {
            self.ring.buffer_pool().release(write_buf);
            return false;
        }
        true
    }

    /// Attempts to splice a direct flow in-kernel via eBPF sockmap.
    /// Returns `true` if the flow is now actively spliced in the kernel.
    fn try_splice_conn(&mut self, conn_id: u64) -> bool {
        let Some(conn) = self.connections.get_mut(&conn_id) else {
            return false;
        };
        let (Some(server_fd), Some(ref key)) = (conn.server_fd, &conn.flow_key) else {
            return false;
        };
        let _ = self.sockmap.splice_direct_flow(key, conn.client_fd, server_fd);
        let spliced = self.sockmap.is_in_kernel();
        conn.is_spliced = spliced;
        spliced
    }

    // ─── Internal Helpers: AF_XDP Ingress ─────────────────────────────────────

    fn handle_xsk_frame(&mut self, frame: &IngressFrameDesc) -> Result<(), ReactorError> {
        let is_v6 = (frame.flags & caly_memory::flags::FLAG_IPV6) != 0;
        let peer_port = frame.peer_port;

        let matched_id = if is_v6 {
            let v6 = frame.get_ipv6().octets();
            self.flow_index.iter().find_map(|(key, &id)| {
                let hit = (key.src_ip == v6 && key.src_port == peer_port)
                    || (key.dst_ip == v6 && key.dst_port == peer_port);
                hit.then_some(id)
            })
        } else {
            let peer_ip = frame.get_ipv4().unwrap_or(Ipv4Addr::UNSPECIFIED).octets();
            self.flow_index.iter().find_map(|(key, &id)| {
                let hit = (key.src_ip[12..16] == peer_ip && key.src_port == peer_port)
                    || (key.dst_ip[12..16] == peer_ip && key.dst_port == peer_port);
                hit.then_some(id)
            })
        };

        if let Some(conn_id) = matched_id {
            if let (Some(conn), Some(ref xsk)) = (self.connections.get_mut(&conn_id), &self.xsk) {
                let packet_slice = xsk.get_packet_slice(frame);
                let _ = conn.transducer.consume(packet_slice);
            }
        }

        Ok(())
    }

    // ─── Internal Helpers: io_uring CQE Handlers ──────────────────────────────

    fn on_cqe_write(&mut self, token: IoToken, result: i32) {
        let conn_id = token.conn_id as u64;
        if let Some(buf_idx) = token.buf_idx {
            self.ring.buffer_pool().release(buf_idx);
        }
        if result < 0 {
            let errno = -result;
            let fatal = matches!(errno, libc::EPIPE | libc::ECONNRESET | libc::EBADF);
            if fatal {
                self.teardown_connection(conn_id);
            } else {
                eprintln!("caly-reactor: write errno={errno} on conn={conn_id}, keeping");
            }
        }
    }

    fn on_cqe_accept(&mut self, client_fd: i32, flags: u32) {
        if client_fd >= 0 && self.register_connection(client_fd, None, None).is_err() {
            // SAFETY: `client_fd` is a freshly accepted descriptor not owned by any state.
            unsafe { libc::close(client_fd) };
        }
        if (flags & IORING_CQE_F_MORE) == 0 {
            if let Some(listen_fd) = self.listener_fd {
                let _ = self.attach_listener(listen_fd);
            }
        }
    }

    fn on_cqe_connect(&mut self, token: IoToken, result: i32) {
        let conn_id = token.conn_id as u64;
        if result < 0 {
            self.teardown_connection(conn_id);
            return;
        }

        let (client_fd, server_fd, client_reply, has_initial_payload, c_buf, is_direct) = {
            let Some(conn) = self.connections.get_mut(&conn_id) else {
                return;
            };
            let Some(sfd) = conn.server_fd else {
                self.teardown_connection(conn_id);
                return;
            };
            conn.phase = ConnPhase::Established;
            (
                conn.client_fd,
                sfd,
                conn.transducer.take_client_reply(),
                conn.pending_initial_payload.is_some(),
                conn.rx_buf_idx,
                conn.transducer.decision() == Some(FlowDecision::Direct),
            )
        };

        // 1. Forward handshake reply to client if pending.
        if let Some(reply) = client_reply {
            let _ = self.submit_buffered_write(
                client_fd,
                IoOperation::WriteClient,
                &reply,
                token.conn_id,
            );
        }

        // 2. Forward the client's initial payload to the server.
        // Acquire a buffer BEFORE taking `pending_initial_payload` so we don't drop it on exhaustion.
        if has_initial_payload {
            if let Ok(write_buf) = self.ring.buffer_pool().acquire() {
                if let Some(payload) = self
                    .connections
                    .get_mut(&conn_id)
                    .and_then(|c| c.pending_initial_payload.take())
                {
                    let out_slice = self.ring.buffer_pool().get_slice_mut(write_buf);
                    let len = payload.len().min(out_slice.len());
                    out_slice[..len].copy_from_slice(&payload[..len]);
                    let write_token =
                        IoToken::encode(IoOperation::WriteServer, Some(write_buf), token.conn_id);
                    if self
                        .ring
                        .submit_write_fixed(server_fd, write_buf, len as u32, 0, write_token)
                        .is_err()
                    {
                        self.ring.buffer_pool().release(write_buf);
                    }
                } else {
                    self.ring.buffer_pool().release(write_buf);
                }
            }
        }

        // 3. Submit fixed read on server socket.
        if let Ok(server_rx) = self.ring.buffer_pool().acquire() {
            if let Some(conn) = self.connections.get_mut(&conn_id) {
                conn.server_rx_buf = Some(server_rx);
            }
            let _ = self.submit_read_fixed_with_token(
                server_fd,
                IoOperation::ReadServer,
                server_rx,
                token.conn_id,
            );
        }

        // 4. Resume fixed read on client socket.
        if let Some(c_buf) = c_buf {
            let _ = self.submit_read_fixed_with_token(
                client_fd,
                IoOperation::ReadClient,
                c_buf,
                token.conn_id,
            );
        }

        // 5. Direct flow kernel splicing if decision is Direct.
        if is_direct {
            self.try_splice_conn(conn_id);
        }
    }

    fn on_cqe_read_server(&mut self, token: IoToken, result: i32) {
        if let Some(orphan_buf) = self.orphaned_server_read.remove(&token.conn_id) {
            self.ring.buffer_pool().release(orphan_buf);
            return;
        }

        let conn_id = token.conn_id as u64;
        if result <= 0 {
            self.teardown_connection(conn_id);
            return;
        }

        let bytes_read = result as usize;
        let Some((s_buf, client_fd, server_fd, has_reverse_pipeline)) =
            self.connections.get(&conn_id).and_then(|c| {
                Some((
                    c.server_rx_buf?,
                    c.client_fd,
                    c.server_fd,
                    c.reverse_pipeline.is_some(),
                ))
            })
        else {
            return;
        };

        // ─── Zero-copy path ────────────────────────────────────────────
        if !has_reverse_pipeline {
            if let Ok(new_buf) = self.ring.buffer_pool().acquire() {
                if let Some(conn) = self.connections.get_mut(&conn_id) {
                    conn.server_rx_buf = Some(new_buf);
                }

                let write_token =
                    IoToken::encode(IoOperation::WriteClient, Some(s_buf), token.conn_id);
                if self
                    .ring
                    .submit_write_fixed(client_fd, s_buf, bytes_read as u32, 0, write_token)
                    .is_err()
                {
                    self.ring.buffer_pool().release(s_buf);
                    self.rearm_server_read_or_teardown(conn_id, server_fd, new_buf, token.conn_id);
                    return;
                }

                self.rearm_server_read_or_teardown(conn_id, server_fd, new_buf, token.conn_id);
                return;
            }
        }

        // ─── Copy path (reverse_pipeline present, or pool exhausted) ───
        let Ok(c_write) = self.ring.buffer_pool().acquire() else {
            if let Some(sfd) = server_fd {
                let _ = self.submit_read_fixed_with_token(
                    sfd,
                    IoOperation::ReadServer,
                    s_buf,
                    token.conn_id,
                );
            }
            return;
        };

        let to_write = {
            let pool = self.ring.buffer_pool();
            let len = bytes_read.min(pool.buffer_size());
            // SAFETY: `s_buf` and `c_write` are distinct indices in the fixed buffer pool.
            unsafe {
                let src_ptr = pool.get_slice(s_buf).as_ptr();
                let dst_ptr = pool.get_slice_mut(c_write).as_mut_ptr();
                std::ptr::copy_nonoverlapping(src_ptr, dst_ptr, len);
            }
            len
        };

        if let Some(conn) = self.connections.get_mut(&conn_id) {
            if let Some(ref mut reverse_pipe) = conn.reverse_pipeline {
                let out_slice = self.ring.buffer_pool().get_slice_mut(c_write);
                reverse_pipe.apply_in_place(&mut out_slice[..to_write]);
            }
        }

        let write_token = IoToken::encode(IoOperation::WriteClient, Some(c_write), token.conn_id);
        if self
            .ring
            .submit_write_fixed(client_fd, c_write, to_write as u32, 0, write_token)
            .is_err()
        {
            self.ring.buffer_pool().release(c_write);
        }

        if let Some(sfd) = server_fd {
            let _ = self.submit_read_fixed_with_token(
                sfd,
                IoOperation::ReadServer,
                s_buf,
                token.conn_id,
            );
        }
    }

    fn rearm_server_read_or_teardown(
        &mut self,
        conn_id: u64,
        server_fd: Option<i32>,
        new_buf: u16,
        token_conn_id: u32,
    ) {
        if let Some(sfd) = server_fd {
            if self
                .submit_read_fixed_with_token(sfd, IoOperation::ReadServer, new_buf, token_conn_id)
                .is_err()
            {
                self.ring.buffer_pool().release(new_buf);
                if let Some(conn) = self.connections.get_mut(&conn_id) {
                    conn.server_rx_buf = None;
                }
                self.teardown_connection(conn_id);
            }
        }
    }

    fn on_cqe_read_client(&mut self, token: IoToken, result: i32) {
        if let Some(orphan_buf) = self.orphaned_client_read.remove(&token.conn_id) {
            self.ring.buffer_pool().release(orphan_buf);
            return;
        }

        let conn_id = token.conn_id as u64;
        if result <= 0 {
            self.teardown_connection(conn_id);
            return;
        }

        let bytes_read = result as usize;
        let Some(buf_idx) = self.connections.get(&conn_id).and_then(|c| c.rx_buf_idx) else {
            return;
        };

        let mut stack_buf = [0u8; STACK_SCRATCH_SIZE];
        let heap_buf: Vec<u8>;
        let data: &[u8] = {
            let s = self.ring.buffer_pool().get_slice(buf_idx);
            let len = bytes_read.min(s.len());
            if len <= stack_buf.len() {
                stack_buf[..len].copy_from_slice(&s[..len]);
                &stack_buf[..len]
            } else {
                heap_buf = s[..len].to_vec();
                &heap_buf[..]
            }
        };

        let (output, client_reply, decision, client_fd, server_fd, phase) = {
            let Some(conn) = self.connections.get_mut(&conn_id) else {
                return;
            };
            let res = conn.transducer.consume(data).map(|out| match out {
                TransducerOutput::DirectForward => TransducerAction::DirectForward,
                TransducerOutput::ProxyForward(b) => TransducerAction::ProxyForward(b.to_vec()),
                TransducerOutput::Continue => TransducerAction::Continue,
                TransducerOutput::Terminate => TransducerAction::Terminate,
            });
            let client_reply = conn.transducer.take_client_reply();
            let decision = conn.transducer.decision();

            if conn.route == FlowRouteState::Unknown {
                match decision.as_ref() {
                    Some(FlowDecision::Direct) => conn.route = FlowRouteState::Direct,
                    Some(FlowDecision::Proxy(_)) => conn.route = FlowRouteState::Proxy,
                    _ => {}
                }
            }

            (
                res,
                client_reply,
                decision,
                conn.client_fd,
                conn.server_fd,
                conn.phase.clone(),
            )
        };

        match output {
            Ok(TransducerAction::DirectForward) => {
                let can_splice = self
                    .connections
                    .get(&conn_id)
                    .map(|c| c.server_fd.is_some() && c.flow_key.is_some())
                    .unwrap_or(false);

                if can_splice {
                    if !self.try_splice_conn(conn_id) {
                        let _ = self.submit_read_fixed_with_token(
                            client_fd,
                            IoOperation::ReadClient,
                            buf_idx,
                            token.conn_id,
                        );
                    }
                } else {
                    self.dial_outbound_uring(conn_id, token.conn_id, decision, None);
                }
            }
            Ok(TransducerAction::ProxyForward(forward_bytes)) => {
                if let Some(reply) = client_reply {
                    let _ = self.submit_buffered_write(
                        client_fd,
                        IoOperation::WriteClient,
                        &reply,
                        token.conn_id,
                    );
                }

                if let Some(sfd) = server_fd {
                    if phase == ConnPhase::Established {
                        let _ = self.submit_buffered_write(
                            sfd,
                            IoOperation::WriteServer,
                            &forward_bytes,
                            token.conn_id,
                        );
                        let _ = self.submit_read_fixed_with_token(
                            client_fd,
                            IoOperation::ReadClient,
                            buf_idx,
                            token.conn_id,
                        );
                    }
                } else {
                    self.dial_outbound_uring(
                        conn_id,
                        token.conn_id,
                        decision,
                        Some(forward_bytes),
                    );
                }
            }
            Ok(TransducerAction::Continue) => {
                if let Some(reply) = client_reply {
                    let _ = self.submit_buffered_write(
                        client_fd,
                        IoOperation::WriteClient,
                        &reply,
                        token.conn_id,
                    );
                }
                let _ = self.submit_read_fixed_with_token(
                    client_fd,
                    IoOperation::ReadClient,
                    buf_idx,
                    token.conn_id,
                );
            }
            Ok(TransducerAction::Terminate) | Err(_) => {
                self.teardown_connection(conn_id);
            }
        }
    }

    fn dial_outbound_uring(
        &mut self,
        conn_id: u64,
        token_conn_id: u32,
        decision: Option<FlowDecision>,
        initial_payload: Option<Vec<u8>>,
    ) {
        let target_str = match decision {
            Some(FlowDecision::Proxy(ref t)) => t.clone(),
            _ => "0.0.0.0:0".to_string(),
        };

        let speculative_ip = self.connections.get(&conn_id).and_then(|c| c.speculative_ip);
        let Some((gsa, sa_len, af_domain)) =
            GenericSockAddr::resolve_target_with_speculative(&target_str, speculative_ip)
        else {
            self.teardown_connection(conn_id);
            return;
        };

        // SAFETY: `af_domain` is validated by `GenericSockAddr`.
        let sfd = unsafe { libc::socket(af_domain, libc::SOCK_STREAM | libc::SOCK_NONBLOCK, 0) };
        if sfd < 0 {
            self.teardown_connection(conn_id);
            return;
        }

        if let Some(conn) = self.connections.get_mut(&conn_id) {
            conn.server_fd = Some(sfd);
            conn.phase = ConnPhase::ConnectingServer {
                server_fd: sfd,
                target: target_str,
            };
            conn.target_addr = Some(gsa);
            if initial_payload.is_some() {
                conn.pending_initial_payload = initial_payload;
            }
        }

        let connect_token = IoToken::encode(IoOperation::Connect, None, token_conn_id);
        let _ = self
            .ring
            .submit_connect(sfd, gsa.as_ptr(), sa_len, connect_token);
    }

    // ─── Internal Helpers: Epoll Backend Handlers ─────────────────────────────

    fn handle_epoll_event(&mut self, ev: libc::epoll_event) -> Result<(), ReactorError> {
        let token = IoToken::decode(ev.u64);
        let conn_id = token.conn_id as u64;

        match token.op {
            IoOperation::Accept => {
                if let Some(listen_fd) = self.listener_fd {
                    loop {
                        // SAFETY: `listen_fd` is an open listening socket.
                        let client_fd = unsafe {
                            libc::accept4(
                                listen_fd,
                                std::ptr::null_mut(),
                                std::ptr::null_mut(),
                                libc::SOCK_NONBLOCK | libc::SOCK_CLOEXEC,
                            )
                        };
                        if client_fd < 0 {
                            break;
                        }
                        if self.register_connection(client_fd, None, None).is_err() {
                            // SAFETY: `client_fd` was just returned by `accept4` and is unowned.
                            unsafe { libc::close(client_fd) };
                        }
                    }
                }
            }
            IoOperation::ReadClient => self.handle_epoll_client_read(conn_id, token)?,
            IoOperation::Connect => self.handle_epoll_server_connect(conn_id)?,
            IoOperation::ReadServer => self.handle_epoll_server_read(conn_id, token)?,
            _ => {}
        }

        Ok(())
    }

    fn handle_epoll_client_read(
        &mut self,
        conn_id: u64,
        _token: IoToken,
    ) -> Result<(), ReactorError> {
        let Some((client_fd, buf_idx)) = self
            .connections
            .get(&conn_id)
            .and_then(|c| Some((c.client_fd, c.rx_buf_idx?)))
        else {
            return Ok(());
        };

        loop {
            let Some(phase) = self.connections.get(&conn_id).map(|c| c.phase.clone()) else {
                return Ok(());
            };

            let (data_ptr, max_len) = {
                let s = self.ring.buffer_pool().get_slice_mut(buf_idx);
                (s.as_mut_ptr(), s.len())
            };

            // SAFETY: `client_fd` is a valid socket; `data_ptr` is valid for `max_len` bytes.
            let bytes_read = unsafe {
                libc::recv(
                    client_fd,
                    data_ptr as *mut libc::c_void,
                    max_len,
                    libc::MSG_DONTWAIT,
                )
            };

            if bytes_read == 0 {
                self.teardown_connection(conn_id);
                return Ok(());
            }
            if bytes_read < 0 {
                let err = std::io::Error::last_os_error();
                if err.kind() == std::io::ErrorKind::WouldBlock {
                    return Ok(());
                }
                self.teardown_connection(conn_id);
                return Ok(());
            }

            let bytes_read = bytes_read as usize;

            // 1. Early client data while outbound connect is still in flight.
            if matches!(phase, ConnPhase::ConnectingServer { .. }) {
                let payload = self.ring.buffer_pool().get_slice(buf_idx)[..bytes_read].to_vec();
                if let Some(conn) = self.connections.get_mut(&conn_id) {
                    conn.enqueue_to_server(payload);
                }
                self.mark_dirty(conn_id);
                continue;
            }

            // 2. Copy payload to stack/heap scratch so `self.connections` can be mutated freely.
            let mut stack_buf = [0u8; STACK_SCRATCH_SIZE];
            let heap_buf: Vec<u8>;
            let data: &[u8] = if bytes_read <= stack_buf.len() {
                let s = self.ring.buffer_pool().get_slice(buf_idx);
                stack_buf[..bytes_read].copy_from_slice(&s[..bytes_read]);
                &stack_buf[..bytes_read]
            } else {
                let s = self.ring.buffer_pool().get_slice(buf_idx);
                heap_buf = s[..bytes_read].to_vec();
                &heap_buf[..]
            };

            // 3. Fast-path: Established or Direct routed flows relay directly to server.
            let direct_server_fd = self.connections.get(&conn_id).and_then(|c| {
                if phase == ConnPhase::Established || c.route == FlowRouteState::Direct {
                    c.server_fd
                } else {
                    None
                }
            });

            if phase == ConnPhase::Established || direct_server_fd.is_some() {
                let Some(server_fd) = direct_server_fd else {
                    return Ok(());
                };
                let send_res = self
                    .connections
                    .get_mut(&conn_id)
                    .map(|c| c.send_to_server(server_fd, data))
                    .unwrap_or(SendResult::Error);

                match send_res {
                    SendResult::Ok => {}
                    SendResult::Queued => self.mark_dirty(conn_id),
                    SendResult::Error => {
                        self.teardown_connection(conn_id);
                        return Ok(());
                    }
                }
                continue;
            }

            // 4. Handshake path: feed the protocol transducer.
            let mut target_to_dial = None;
            let mut client_reply_to_send = None;
            let mut initial_payload = None;
            let mut terminate = false;

            if let Some(conn) = self.connections.get_mut(&conn_id) {
                match conn.transducer.consume(data) {
                    Ok(TransducerOutput::Continue) => {
                        client_reply_to_send = conn.transducer.take_client_reply();
                    }
                    Ok(TransducerOutput::DirectForward) => {
                        client_reply_to_send = conn.transducer.take_client_reply();
                        target_to_dial = Some(
                            conn.transducer
                                .target_address()
                                .unwrap_or("127.0.0.1:80")
                                .to_string(),
                        );
                    }
                    Ok(TransducerOutput::ProxyForward(forward_bytes)) => {
                        client_reply_to_send = conn.transducer.take_client_reply();
                        target_to_dial = Some(
                            conn.transducer
                                .target_address()
                                .unwrap_or("127.0.0.1:80")
                                .to_string(),
                        );
                        initial_payload = Some(forward_bytes.to_vec());
                    }
                    Ok(TransducerOutput::Terminate) | Err(_) => {
                        terminate = true;
                    }
                }
            }

            if terminate {
                self.teardown_connection(conn_id);
                return Ok(());
            }

            if let Some(reply) = client_reply_to_send {
                let send_res = self
                    .connections
                    .get_mut(&conn_id)
                    .map(|c| c.send_to_client(&reply))
                    .unwrap_or(SendResult::Error);

                match send_res {
                    SendResult::Ok => {}
                    SendResult::Queued => self.mark_dirty(conn_id),
                    SendResult::Error => {
                        self.teardown_connection(conn_id);
                        return Ok(());
                    }
                }
            }

            if let Some(target) = target_to_dial {
                self.dial_outbound_epoll(conn_id, &target, initial_payload)?;
            }
        }
    }

    fn dial_outbound_epoll(
        &mut self,
        conn_id: u64,
        target: &str,
        initial_payload: Option<Vec<u8>>,
    ) -> Result<(), ReactorError> {
        let Some(speculative_ip) = self.connections.get(&conn_id).map(|c| c.speculative_ip) else {
            return Ok(());
        };

        let Some((sockaddr, addrlen, af_domain)) =
            GenericSockAddr::resolve_target_with_speculative(target, speculative_ip)
        else {
            self.teardown_connection(conn_id);
            return Ok(());
        };

        // SAFETY: `af_domain` is validated by `GenericSockAddr`.
        let sfd = unsafe {
            libc::socket(
                af_domain,
                libc::SOCK_STREAM | libc::SOCK_NONBLOCK | libc::SOCK_CLOEXEC,
                0,
            )
        };
        if sfd < 0 {
            self.teardown_connection(conn_id);
            return Ok(());
        }

        // SAFETY: `sfd` is a valid socket; `sockaddr` and `addrlen` match `af_domain`.
        let ret = unsafe { libc::connect(sfd, sockaddr.as_ptr(), addrlen) };
        let is_connected = ret == 0;
        let is_in_progress =
            ret < 0 && std::io::Error::last_os_error().raw_os_error() == Some(libc::EINPROGRESS);

        if !is_connected && !is_in_progress {
            // SAFETY: `sfd` is owned locally and not yet stored in `self.connections`.
            unsafe { libc::close(sfd) };
            self.teardown_connection(conn_id);
            return Ok(());
        }

        if let Some(ref epoll) = self.epoll {
            let (op, events) = if is_connected {
                (IoOperation::ReadServer, EPOLL_READ)
            } else {
                (IoOperation::Connect, EPOLL_WRITE)
            };
            let token = IoToken::encode(op, None, conn_id as u32);
            if let Err(e) = epoll.add_fd(sfd, events, token) {
                eprintln!("caly-reactor: epoll.add_fd({sfd}) failed for conn {conn_id}: {e}");
                // SAFETY: `sfd` is owned locally and not yet stored in `self.connections`.
                unsafe { libc::close(sfd) };
                self.teardown_connection(conn_id);
                return Ok(());
            }
        }

        if let Some(conn) = self.connections.get_mut(&conn_id) {
            conn.server_fd = Some(sfd);
            conn.target_addr = Some(sockaddr);
            conn.pending_initial_payload = initial_payload;
            conn.phase = if is_connected {
                ConnPhase::Established
            } else {
                ConnPhase::ConnectingServer {
                    server_fd: sfd,
                    target: target.to_string(),
                }
            };
        }

        if is_connected {
            self.finalize_epoll_connection(conn_id)?;
        }

        Ok(())
    }

    fn handle_epoll_server_connect(&mut self, conn_id: u64) -> Result<(), ReactorError> {
        let Some(server_fd) = self.connections.get(&conn_id).and_then(|c| match c.phase {
            ConnPhase::ConnectingServer { server_fd, .. } => Some(server_fd),
            _ => None,
        }) else {
            return Ok(());
        };

        let mut err: libc::c_int = 0;
        let mut len = std::mem::size_of::<libc::c_int>() as libc::socklen_t;
        // SAFETY: `server_fd` is an open socket owned by this connection.
        let res = unsafe {
            libc::getsockopt(
                server_fd,
                libc::SOL_SOCKET,
                libc::SO_ERROR,
                &mut err as *mut _ as *mut libc::c_void,
                &mut len,
            )
        };

        if res < 0 || err != 0 {
            self.teardown_connection(conn_id);
            return Ok(());
        }

        if let Some(ref epoll) = self.epoll {
            let token = IoToken::encode(IoOperation::ReadServer, None, conn_id as u32);
            if let Err(e) = epoll.modify_fd(server_fd, EPOLL_READ, token) {
                eprintln!("caly-reactor: epoll.modify_fd({server_fd}) failed for conn {conn_id}: {e}");
                self.teardown_connection(conn_id);
                return Ok(());
            }
        }

        if let Some(conn) = self.connections.get_mut(&conn_id) {
            conn.phase = ConnPhase::Established;
        }

        self.finalize_epoll_connection(conn_id)
    }

    fn finalize_epoll_connection(&mut self, conn_id: u64) -> Result<(), ReactorError> {
        let Some((server_fd, initial_payload, is_direct)) =
            self.connections.get_mut(&conn_id).map(|c| {
                (
                    c.server_fd,
                    c.pending_initial_payload.take(),
                    c.transducer.decision() == Some(FlowDecision::Direct),
                )
            })
        else {
            return Ok(());
        };

        if let (Some(sfd), Some(payload)) = (server_fd, initial_payload) {
            let send_res = self
                .connections
                .get_mut(&conn_id)
                .map(|c| c.send_to_server(sfd, &payload))
                .unwrap_or(SendResult::Error);

            match send_res {
                SendResult::Ok => {}
                SendResult::Queued => self.mark_dirty(conn_id),
                SendResult::Error => {
                    self.teardown_connection(conn_id);
                    return Ok(());
                }
            }
        }

        if is_direct {
            self.try_splice_conn(conn_id);
        }

        Ok(())
    }

    fn handle_epoll_server_read(
        &mut self,
        conn_id: u64,
        _token: IoToken,
    ) -> Result<(), ReactorError> {
        let Some(server_fd) = self.connections.get(&conn_id).and_then(|c| c.server_fd) else {
            return Ok(());
        };

        let mut buf = [0u8; 8192];
        let mut should_teardown = false;

        loop {
            // SAFETY: `server_fd` is an open socket; `buf` is valid for `buf.len()` bytes.
            let bytes_read = unsafe {
                libc::recv(
                    server_fd,
                    buf.as_mut_ptr() as *mut libc::c_void,
                    buf.len(),
                    libc::MSG_DONTWAIT,
                )
            };

            if bytes_read == 0 {
                should_teardown = true;
                break;
            }
            if bytes_read < 0 {
                let err = std::io::Error::last_os_error();
                if err.kind() != std::io::ErrorKind::WouldBlock {
                    should_teardown = true;
                }
                break;
            }

            let slice = &mut buf[..bytes_read as usize];

            let send_res = if let Some(conn) = self.connections.get_mut(&conn_id) {
                if let Some(ref mut reverse_pipe) = conn.reverse_pipeline {
                    reverse_pipe.apply_in_place(slice);
                }
                conn.send_to_client(slice)
            } else {
                SendResult::Error
            };

            match send_res {
                SendResult::Ok => {}
                SendResult::Queued => self.mark_dirty(conn_id),
                SendResult::Error => {
                    should_teardown = true;
                    break;
                }
            }
        }

        if should_teardown {
            self.teardown_connection(conn_id);
        }
        Ok(())
    }
}

/// Owned representation of [`TransducerOutput`] to decouple borrows of `ConnectionState` from `self`.
enum TransducerAction {
    DirectForward,
    ProxyForward(Vec<u8>),
    Continue,
    Terminate,
}

impl Drop for CoreReactor {
    fn drop(&mut self) {
        for (_, buf) in self.orphaned_client_read.drain() {
            self.ring.buffer_pool().release(buf);
        }
        for (_, buf) in self.orphaned_server_read.drain() {
            self.ring.buffer_pool().release(buf);
        }
    }
}

#[cfg(test)]
mod pending_chunk_and_reactor_tests {
    use super::*;

    // ─── PendingChunk ──────────────────────────────────────────────────

    #[test]
    fn test_pending_chunk_advance_semantics() {
        let mut chunk = PendingChunk::new(vec![1, 2, 3, 4, 5]);
        assert_eq!(chunk.len(), 5);
        assert_eq!(chunk.remaining(), &[1, 2, 3, 4, 5]);
        assert!(!chunk.is_empty());

        chunk.advance(2);
        assert_eq!(chunk.len(), 3);
        assert_eq!(chunk.remaining(), &[3, 4, 5]);

        chunk.advance(3);
        assert_eq!(chunk.len(), 0);
        assert!(chunk.is_empty());
        assert!(chunk.remaining().is_empty());
    }

    #[test]
    fn test_pending_chunk_partial_flush_sequence() {
        let original: Vec<u8> = (0..16).collect();
        let mut chunk = PendingChunk::new(original.clone());

        for (i, _) in original.iter().enumerate() {
            assert_eq!(
                chunk.len(),
                original.len() - i,
                "len before advance {i}",
            );
            assert_eq!(
                chunk.remaining(),
                &original[i..],
                "remaining before advance {i}",
            );
            chunk.advance(1);
        }
        assert!(chunk.is_empty());
        assert_eq!(chunk.len(), 0);
    }

    #[test]
    fn test_pending_chunk_advance_zero_is_noop() {
        let mut chunk = PendingChunk::new(vec![1, 2, 3]);
        let before = chunk.remaining().to_vec();
        chunk.advance(0);
        assert_eq!(chunk.remaining(), before.as_slice());
        assert_eq!(chunk.len(), 3);
    }

    #[test]
    #[cfg(debug_assertions)]
    #[should_panic(expected = "PendingChunk::advance beyond end")]
    fn test_pending_chunk_advance_overflow_panics() {
        let mut chunk = PendingChunk::new(vec![1, 2, 3]);
        chunk.advance(4);
    }

    // ─── mark_dirty & Reactor Lifecycle ────────────────────────────────

    #[test]
    #[cfg_attr(miri, ignore)]
    fn test_register_connection_with_server_fd_consumes_buffer_iouring() {
        let config = CoreReactorConfig {
            core_id: 0,
            backend: ReactorBackend::IoUring,
            ingress_mode: IngressMode::IoUring,
            ring_entries: 16,
            fixed_buffers: 8,
            buffer_size: 2048,
            spin_limit: 10,
            xsk_config: None,
        };
        let mut reactor = CoreReactor::new(config).expect("reactor");
        assert_eq!(reactor.backend(), ReactorBackend::IoUring);

        let mut sv_c = [0i32; 2];
        let mut sv_s = [0i32; 2];
        unsafe {
            libc::socketpair(
                libc::AF_UNIX,
                libc::SOCK_STREAM | libc::SOCK_NONBLOCK,
                0,
                sv_c.as_mut_ptr(),
            );
            libc::socketpair(
                libc::AF_UNIX,
                libc::SOCK_STREAM | libc::SOCK_NONBLOCK,
                0,
                sv_s.as_mut_ptr(),
            );
        }
        let (client_fd, client_peer) = (sv_c[0], sv_c[1]);
        let (server_fd, server_peer) = (sv_s[0], sv_s[1]);

        let avail_before = reactor.buffer_pool().available_buffers();

        let conn_id = reactor
            .register_connection(client_fd, Some(server_fd), None)
            .expect("register with server_fd");

        assert_eq!(
            reactor.buffer_pool().available_buffers(),
            avail_before - 2,
            "io_uring register with server_fd must consume two buffers",
        );

        let conn = reactor.connection(conn_id).expect("conn present");
        assert!(conn.rx_buf_idx.is_some());
        assert!(
            conn.server_rx_buf.is_some(),
            "server_rx_buf must be Some on io_uring when server_fd was provided",
        );

        unsafe {
            libc::close(client_fd);
            libc::close(client_peer);
            libc::close(server_fd);
            libc::close(server_peer);
        }
    }

    #[test]
    #[cfg_attr(miri, ignore)]
    fn test_drop_releases_orphaned_buffers_does_not_panic() {
        let config = CoreReactorConfig {
            core_id: 0,
            backend: ReactorBackend::IoUring,
            ingress_mode: IngressMode::IoUring,
            ring_entries: 16,
            fixed_buffers: 8,
            buffer_size: 2048,
            spin_limit: 10,
            xsk_config: None,
        };

        let mut reactor = CoreReactor::new(config).expect("reactor");

        let mut sv = [0i32; 2];
        unsafe {
            libc::socketpair(
                libc::AF_UNIX,
                libc::SOCK_STREAM | libc::SOCK_NONBLOCK,
                0,
                sv.as_mut_ptr(),
            )
        };
        let (c0, s0) = (sv[0], sv[1]);

        let conn_id = reactor
            .register_connection(c0, None, None)
            .expect("register");
        reactor.teardown_connection(conn_id);

        assert!(
            !reactor.orphaned_client_read.is_empty(),
            "buffer must be parked pre-drop",
        );

        drop(reactor);

        unsafe {
            libc::close(c0);
            libc::close(s0);
        }
    }

    #[test]
    #[cfg_attr(miri, ignore)]
    fn test_teardown_defers_iouring_read_buffer_release() {
        let config = CoreReactorConfig {
            core_id: 0,
            backend: ReactorBackend::IoUring,
            ingress_mode: IngressMode::IoUring,
            ring_entries: 16,
            fixed_buffers: 8,
            buffer_size: 2048,
            spin_limit: 10,
            xsk_config: None,
        };
        let mut reactor = CoreReactor::new(config).expect("reactor");
        assert_eq!(reactor.backend(), ReactorBackend::IoUring);

        let mut sv = [0i32; 2];
        unsafe {
            libc::socketpair(
                libc::AF_UNIX,
                libc::SOCK_STREAM | libc::SOCK_NONBLOCK,
                0,
                sv.as_mut_ptr(),
            )
        };
        let (c0, s0) = (sv[0], sv[1]);

        let conn_id = reactor
            .register_connection(c0, None, None)
            .expect("register");
        let buf_idx = reactor
            .connection(conn_id)
            .and_then(|c| c.rx_buf_idx)
            .expect("rx_buf_idx assigned");
        let avail_before_teardown = reactor.buffer_pool().available_buffers();

        reactor.teardown_connection(conn_id);

        assert_eq!(
            reactor.orphaned_client_read.get(&(conn_id as u32)).copied(),
            Some(buf_idx),
            "io_uring teardown must park the client read buffer",
        );
        assert_eq!(
            reactor.buffer_pool().available_buffers(),
            avail_before_teardown,
            "buffer pool size must not change until the CQE arrives",
        );

        let cqe = CqeEvent {
            user_data: IoToken::encode(
                IoOperation::ReadClient,
                Some(buf_idx),
                conn_id as u32,
            ),
            result: 0,
            flags: 0,
        };
        reactor.handle_cqe(cqe).expect("handle orphaned CQE");

        assert!(
            reactor.orphaned_client_read.is_empty(),
            "orphan map must drain after its CQE is handled",
        );
        assert_eq!(
            reactor.buffer_pool().available_buffers(),
            avail_before_teardown + 1,
            "buffer must be back in the pool after the orphan CQE",
        );

        unsafe {
            libc::close(c0);
            libc::close(s0);
        }
    }

    #[test]
    #[cfg_attr(miri, ignore)]
    fn test_teardown_epoll_releases_buffer_immediately() {
        let config = CoreReactorConfig {
            core_id: 0,
            backend: ReactorBackend::Epoll,
            ingress_mode: IngressMode::IoUring,
            ring_entries: 16,
            fixed_buffers: 8,
            buffer_size: 2048,
            spin_limit: 10,
            xsk_config: None,
        };
        let mut reactor = CoreReactor::new(config).expect("reactor");
        assert_eq!(reactor.backend(), ReactorBackend::Epoll);

        let mut sv = [0i32; 2];
        unsafe {
            libc::socketpair(
                libc::AF_UNIX,
                libc::SOCK_STREAM | libc::SOCK_NONBLOCK,
                0,
                sv.as_mut_ptr(),
            )
        };
        let (c0, s0) = (sv[0], sv[1]);

        let conn_id = reactor
            .register_connection(c0, None, None)
            .expect("register");
        let avail_before = reactor.buffer_pool().available_buffers();

        reactor.teardown_connection(conn_id);

        assert!(
            reactor.orphaned_client_read.is_empty(),
            "epoll teardown must not park buffers",
        );
        assert_eq!(
            reactor.buffer_pool().available_buffers(),
            avail_before + 1,
            "epoll teardown must release the buffer synchronously",
        );

        unsafe {
            libc::close(c0);
            libc::close(s0);
        }
    }

    #[test]
    #[cfg_attr(miri, ignore)]
    fn test_register_connection_defaults_to_no_reverse_pipeline() {
        let config = CoreReactorConfig {
            core_id: 0,
            backend: ReactorBackend::Epoll,
            ingress_mode: IngressMode::IoUring,
            ring_entries: 8,
            fixed_buffers: 4,
            buffer_size: 2048,
            spin_limit: 10,
            xsk_config: None,
        };
        let mut reactor = CoreReactor::new(config).expect("reactor");

        let mut sv = [0i32; 2];
        unsafe {
            libc::socketpair(
                libc::AF_UNIX,
                libc::SOCK_STREAM | libc::SOCK_NONBLOCK,
                0,
                sv.as_mut_ptr(),
            )
        };
        let (c0, s0) = (sv[0], sv[1]);

        let conn_id = reactor
            .register_connection(c0, None, None)
            .expect("register");
        let conn = reactor.connection(conn_id).expect("conn present");
        assert!(
            conn.reverse_pipeline.is_none(),
            "default `reverse_pipeline` must be `None` for the zero-copy \
             ReadServer path to engage",
        );

        unsafe {
            libc::close(c0);
            libc::close(s0);
        }
    }

    #[test]
    #[cfg_attr(miri, ignore)]
    fn test_mark_dirty_deduplicates() {
        let config = CoreReactorConfig {
            core_id: 0,
            backend: ReactorBackend::Epoll,
            ingress_mode: IngressMode::IoUring,
            ring_entries: 8,
            fixed_buffers: 4,
            buffer_size: 2048,
            spin_limit: 10,
            xsk_config: None,
        };
        let mut reactor = CoreReactor::new(config).expect("reactor");

        reactor.mark_dirty(1);
        reactor.mark_dirty(1);
        reactor.mark_dirty(2);
        reactor.mark_dirty(1);

        assert_eq!(
            reactor.dirty_conns.len(),
            2,
            "mark_dirty must deduplicate; queue={:?}",
            reactor.dirty_conns,
        );
        assert_eq!(reactor.dirty_conns.front().copied(), Some(1));
        assert_eq!(reactor.dirty_conns.back().copied(), Some(2));
    }

    // ─── conn_id overflow ──────────────────────────────────────────────

    #[test]
    #[cfg_attr(miri, ignore)]
    fn test_conn_id_overflow_rejected() {
        let config = CoreReactorConfig {
            core_id: 0,
            backend: ReactorBackend::Epoll,
            ingress_mode: IngressMode::IoUring,
            ring_entries: 8,
            fixed_buffers: 4,
            buffer_size: 2048,
            spin_limit: 10,
            xsk_config: None,
        };
        let mut reactor = CoreReactor::new(config).expect("reactor");

        reactor.next_conn_id = u32::MAX as u64 + 1;

        let err = reactor
            .register_connection(0, None, None)
            .expect_err("registration must fail once conn_id > u32::MAX");
        let msg = err.to_string();
        assert!(
            msg.contains("exhausted") || msg.contains("overflow"),
            "unexpected error message: {msg}",
        );
    }
}
