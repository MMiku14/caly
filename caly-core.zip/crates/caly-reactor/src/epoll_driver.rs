//! Standard Linux Edge-Triggered epoll fallback driver.
//!
//! Provides a zero-dependency, low-latency epoll driver for containerized
//! environments where io_uring is restricted (e.g. `ENOSYS` or `EPERM`).

use std::io;

/// Standard edge-triggered epoll read event mask (including peer shutdown detection).
pub const EPOLL_READ: u32 = (libc::EPOLLIN | libc::EPOLLET | libc::EPOLLRDHUP) as u32;

/// Standard edge-triggered epoll write event mask.
pub const EPOLL_WRITE: u32 = (libc::EPOLLOUT | libc::EPOLLET) as u32;

/// Combined read-write edge-triggered event mask.
pub const EPOLL_READ_WRITE: u32 =
    (libc::EPOLLIN | libc::EPOLLOUT | libc::EPOLLET | libc::EPOLLRDHUP) as u32;

/// Edge-triggered listen event mask for TCP server listener sockets.
pub const EPOLL_LISTEN: u32 = (libc::EPOLLIN | libc::EPOLLET) as u32;

/// Edge-triggered Linux epoll driver.
#[derive(Debug)]
pub struct EpollDriver {
    epoll_fd: i32,
}

impl EpollDriver {
    /// Creates a new `EpollDriver` instance with close-on-exec enabled.
    pub fn new() -> Result<Self, io::Error> {
        let epoll_fd = unsafe { libc::epoll_create1(libc::EPOLL_CLOEXEC) };
        if epoll_fd < 0 {
            return Err(io::Error::last_os_error());
        }
        Ok(Self { epoll_fd })
    }

    /// Raw epoll file descriptor.
    #[inline(always)]
    pub fn as_raw_fd(&self) -> i32 {
        self.epoll_fd
    }

    fn ctl_fd(&self, op: i32, fd: i32, events: u32, user_data: u64) -> Result<(), io::Error> {
        let mut event = libc::epoll_event {
            events,
            u64: user_data,
        };
        let res = unsafe { libc::epoll_ctl(self.epoll_fd, op, fd, &mut event) };
        if res < 0 {
            Err(io::Error::last_os_error())
        } else {
            Ok(())
        }
    }

    /// Adds a file descriptor to the interest list with edge-triggered events and custom user data.
    pub fn add_fd(&self, fd: i32, events: u32, user_data: u64) -> Result<(), io::Error> {
        self.ctl_fd(libc::EPOLL_CTL_ADD, fd, events, user_data)
    }

    /// Modifies the registered interest mask and user data for an existing file descriptor.
    pub fn modify_fd(&self, fd: i32, events: u32, user_data: u64) -> Result<(), io::Error> {
        self.ctl_fd(libc::EPOLL_CTL_MOD, fd, events, user_data)
    }

    /// Removes a file descriptor from the epoll interest list.
    pub fn remove_fd(&self, fd: i32) -> Result<(), io::Error> {
        let res = unsafe {
            libc::epoll_ctl(self.epoll_fd, libc::EPOLL_CTL_DEL, fd, std::ptr::null_mut())
        };
        if res < 0 {
            Err(io::Error::last_os_error())
        } else {
            Ok(())
        }
    }

    /// Rust 惯用超时版本；None 表示无限等待。
    pub fn poll_timeout(
        &self,
        events: &mut [libc::epoll_event],
        timeout: Option<std::time::Duration>,
    ) -> Result<usize, io::Error> {
        let ms = match timeout {
            None => -1,
            Some(d) => {
                // 非零但不足 1ms 的 Duration 向上取整为 1ms，
                // 避免落到 0ms 忙轮询。
                let raw = d.as_millis().min(i32::MAX as u128) as i32;
                if raw == 0 && d.as_nanos() > 0 { 1 } else { raw }
            }
        };
        self.poll(events, ms)
    }

    /// Waits for events on the epoll instance.
    ///
    /// Handles `EINTR` signals gracefully by returning `Ok(0)`.
    pub fn poll(
        &self,
        events: &mut [libc::epoll_event],
        timeout_ms: i32,
    ) -> Result<usize, io::Error> {
        if events.is_empty() {
            return Ok(0);
        }
        let res = unsafe {
            libc::epoll_wait(
                self.epoll_fd,
                events.as_mut_ptr(),
                events.len() as libc::c_int,
                timeout_ms,
            )
        };
        if res < 0 {
            let err = io::Error::last_os_error();
            if err.raw_os_error() == Some(libc::EINTR) {
                Ok(0)
            } else {
                Err(err)
            }
        } else {
            Ok(res as usize)
        }
    }
}

impl Drop for EpollDriver {
    fn drop(&mut self) {
        if self.epoll_fd >= 0 {
            // SAFETY: `fd` is an open descriptor owned by this scope; close consumes it.
            unsafe {
                libc::close(self.epoll_fd);
            }
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    #[cfg_attr(miri, ignore)]
    fn test_epoll_driver_lifecycle() {
        let driver = EpollDriver::new().expect("epoll_create1 should succeed");
        assert!(driver.as_raw_fd() >= 0);

        // Create pipe to test event registration
        let mut pipefds = [0i32; 2];
        let ret = unsafe { libc::pipe2(pipefds.as_mut_ptr(), libc::O_NONBLOCK | libc::O_CLOEXEC) };
        assert_eq!(ret, 0, "pipe2 creation");

        let (rfd, wfd) = (pipefds[0], pipefds[1]);

        // Register read end
        driver
            .add_fd(rfd, EPOLL_READ, 1001)
            .expect("add_fd read end");

        // Initial poll should have no events
        let mut events = [libc::epoll_event { events: 0, u64: 0 }; 4];
        let n = driver.poll(&mut events, 0).expect("poll empty");
        assert_eq!(n, 0);

        // Write data to pipe
        let msg = b"CALY_EPOLL_PING";
        let written = unsafe { libc::write(wfd, msg.as_ptr() as *const libc::c_void, msg.len()) };
        assert_eq!(written, msg.len() as isize);

        // Poll should detect read event.
        // NOTE: `libc::epoll_event` is `#[repr(C, packed)]` on x86_64, so forming
        // a reference to its `u64` field (which `assert_eq!` does) is E0793
        // ("reference to field of packed struct is unaligned"). Copy it out first.
        let n = driver.poll(&mut events, 50).expect("poll ready");
        assert_eq!(n, 1);
        let user_data = events[0].u64;
        assert_eq!(user_data, 1001);
        assert!((events[0].events & libc::EPOLLIN as u32) != 0);

        // Modify fd
        driver.modify_fd(rfd, EPOLL_READ, 1002).expect("modify_fd");

        // Remove fd
        driver.remove_fd(rfd).expect("remove_fd");

        // SAFETY: `fd` is an open descriptor owned by this scope; close consumes it.
        unsafe {
            libc::close(rfd);
            libc::close(wfd);
        }
    }
}
