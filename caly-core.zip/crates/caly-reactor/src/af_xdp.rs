//! AF_XDP (XSK) Zero-Copy Kernel Bypass Driver.
//! Provides sub-microsecond packet ingestion and transmission via Linux XDP sockets.

use std::collections::VecDeque;
use std::net::{Ipv4Addr, Ipv6Addr};
use std::sync::atomic::Ordering;
use thiserror::Error;

use caly_memory::flags::{
    FLAG_ACK, FLAG_FIN, FLAG_IPV4, FLAG_IPV6, FLAG_RST, FLAG_SYN, FLAG_TCP, FLAG_UDP,
};
use caly_memory::{read_cpu_tsc, HugePageMemory, IngressFrameDesc};

pub const MAX_UMEM_SIZE: usize = u32::MAX as usize;

pub const AF_XDP: libc::c_int = 44;
pub const SOL_XDP: libc::c_int = 283;

pub const XDP_MMAP_OFFSETS: libc::c_int = 1;
pub const XDP_RX_RING: libc::c_int = 2;
pub const XDP_TX_RING: libc::c_int = 3;
pub const XDP_UMEM_REG: libc::c_int = 4;
pub const XDP_UMEM_FILL_RING: libc::c_int = 5;
pub const XDP_UMEM_COMPLETION_RING: libc::c_int = 6;
pub const XDP_STATISTICS: libc::c_int = 7;
pub const XDP_OPTIONS: libc::c_int = 8;

pub const XDP_PGOFF_RX_RING: libc::off_t = 0;
pub const XDP_PGOFF_TX_RING: libc::off_t = 0x8000_0000;
pub const XDP_UMEM_PGOFF_FILL_RING: libc::off_t = 0x1_0000_0000;
pub const XDP_UMEM_PGOFF_COMPLETION_RING: libc::off_t = 0x1_8000_0000;

pub const XDP_SHARED_UMEM: u16 = 1 << 0;
pub const XDP_COPY: u16 = 1 << 1;
pub const XDP_ZEROCOPY: u16 = 1 << 2;
pub const XDP_USE_NEED_WAKEUP: u16 = 1 << 3;

#[derive(Error, Debug)]
pub enum XskError {
    #[error("Socket creation failed: {0}")]
    Socket(std::io::Error),
    #[error("Setsockopt failed for {0}: {1}")]
    Setsockopt(String, std::io::Error),
    #[error("mmap failed for ring {0}: {1}")]
    Mmap(String, std::io::Error),
    #[error("Socket bind failed: {0}")]
    Bind(std::io::Error),
    #[error("UMEM registration error: {0}")]
    Umem(String),
    #[error("Ring buffer exhausted / full")]
    RingFull,
    #[error("Invalid descriptor address: {0:#x}")]
    InvalidAddress(u64),
}

#[repr(C)]
#[derive(Debug, Clone, Copy, Default)]
pub struct XdpUmemReg {
    pub addr: u64,
    pub len: u64,
    pub chunk_size: u32,
    pub headroom: u32,
    pub flags: u32,
}

#[repr(C)]
#[derive(Debug, Clone, Copy, Default)]
pub struct XdpRingOffset {
    pub producer: u64,
    pub consumer: u64,
    pub desc: u64,
    pub flags: u64,
}

#[repr(C)]
#[derive(Debug, Clone, Copy, Default)]
pub struct XdpMmapOffsets {
    pub rx: XdpRingOffset,
    pub tx: XdpRingOffset,
    pub fr: XdpRingOffset,
    pub cr: XdpRingOffset,
}

#[repr(C)]
#[derive(Debug, Clone, Copy, Default, PartialEq, Eq)]
pub struct XdpDesc {
    pub addr: u64,
    pub len: u32,
    pub options: u32,
}

#[repr(C)]
#[derive(Debug, Clone, Copy)]
pub struct SockaddrXdp {
    pub sxdp_family: u16,
    pub sxdp_flags: u16,
    pub sxdp_ifindex: u32,
    pub sxdp_queue_id: u32,
    pub sxdp_shared_umem_fd: u32,
}

const UNROLL_RX: usize = 4;

#[derive(Debug, Clone)]
pub struct XskConfig {
    pub ifname: String,
    pub ifindex: u32,
    pub queue_id: u32,
    pub rx_size: u32,
    pub tx_size: u32,
    pub fill_size: u32,
    pub comp_size: u32,
    pub chunk_size: u32,
    pub headroom: u32,
    pub bind_flags: u16,
}

impl Default for XskConfig {
    fn default() -> Self {
        Self {
            ifname: "lo".to_string(),
            ifindex: 1,
            queue_id: 0,
            rx_size: 2048,
            tx_size: 2048,
            fill_size: 4096,
            comp_size: 2048,
            chunk_size: 2048,
            headroom: 0,
            bind_flags: XDP_ZEROCOPY | XDP_USE_NEED_WAKEUP,
        }
    }
}

impl XskConfig {
    pub fn for_interface(ifname: impl Into<String>, ifindex: u32) -> Self {
        Self {
            ifname: ifname.into(),
            ifindex,
            ..Default::default()
        }
    }
}

pub struct XskRingProd {
    producer: *mut u32,
    consumer: *const u32,
    ring: *mut u8,
    size: u32,
    mask: u32,
}

unsafe impl Send for XskRingProd {}
unsafe impl Sync for XskRingProd {}

impl XskRingProd {
    #[inline(always)]
    pub fn available(&self, cached_cons: &mut u32, cached_prod: u32) -> u32 {
        let occupied = cached_prod.wrapping_sub(*cached_cons);
        if occupied >= self.size {
            *cached_cons = unsafe { std::ptr::read_volatile(self.consumer) };
            std::sync::atomic::fence(Ordering::Acquire);
            let fresh = cached_prod.wrapping_sub(*cached_cons);
            if fresh >= self.size { 0 } else { self.size - fresh }
        } else {
            self.size - occupied
        }
    }

    #[inline(always)]
    pub unsafe fn write_addr(&mut self, idx: u32, addr: u64) {
        unsafe {
            let ring_ptr = self.ring as *mut u64;
            let slot = (idx & self.mask) as usize;
            std::ptr::write_volatile(ring_ptr.add(slot), addr);
        }
    }

    #[inline(always)]
    pub unsafe fn write_desc(&mut self, idx: u32, desc: &XdpDesc) {
        unsafe {
            let ring_ptr = self.ring as *mut XdpDesc;
            let slot = (idx & self.mask) as usize;
            std::ptr::write_volatile(ring_ptr.add(slot), *desc);
        }
    }

    #[inline(always)]
    pub fn submit(&mut self, prod: u32) {
        std::sync::atomic::fence(Ordering::Release);
        unsafe { std::ptr::write_volatile(self.producer, prod) };
    }
}

pub struct XskRingCons {
    producer: *const u32,
    consumer: *mut u32,
    ring: *const u8,
    #[allow(dead_code)]
    size: u32,
    mask: u32,
}

unsafe impl Send for XskRingCons {}
unsafe impl Sync for XskRingCons {}

impl XskRingCons {
    #[inline(always)]
    pub fn peek(&self, cached_prod: &mut u32, cached_cons: u32) -> u32 {
        let available = (*cached_prod).wrapping_sub(cached_cons);
        if available == 0 {
            *cached_prod = unsafe { std::ptr::read_volatile(self.producer) };
            std::sync::atomic::fence(Ordering::Acquire);
            (*cached_prod).wrapping_sub(cached_cons)
        } else {
            available
        }
    }

    #[inline(always)]
    pub unsafe fn read_desc(&self, idx: u32) -> XdpDesc {
        unsafe {
            let ring_ptr = self.ring as *const XdpDesc;
            let slot = (idx & self.mask) as usize;
            std::ptr::read_volatile(ring_ptr.add(slot))
        }
    }

    #[inline(always)]
    pub fn release(&mut self, cons: u32) {
        std::sync::atomic::fence(Ordering::Release);
        unsafe { std::ptr::write_volatile(self.consumer, cons) };
    }
}

pub struct XskSocket {
    fd: i32,
    config: XskConfig,
    umem_base: *mut u8,
    umem_len: usize,
    ring_maps: Vec<(*mut u8, usize)>,
    fill_ring: Option<XskRingProd>,
    rx_ring: Option<XskRingCons>,
    tx_ring: Option<XskRingProd>,
    fill_prod: u32,
    fill_cons: u32,
    rx_prod: u32,
    rx_cons: u32,
    tx_prod: u32,
    tx_cons: u32,
    is_simulation: bool,
    sim_rx: VecDeque<XdpDesc>,
    sim_fill: VecDeque<u64>,
    umem_memory: Option<HugePageMemory>,
}

unsafe impl Send for XskSocket {}
unsafe impl Sync for XskSocket {}

impl XskSocket {
    pub fn new_with_memory(umem: HugePageMemory, config: XskConfig) -> Result<Self, XskError> {
        let mut sock = Self::from_raw_umem(umem.as_ptr() as *mut u8, umem.len(), config)?;
        sock.umem_memory = Some(umem);
        Ok(sock)
    }

    pub fn from_raw_umem(
        umem_ptr: *mut u8,
        umem_len: usize,
        config: XskConfig,
    ) -> Result<Self, XskError> {
        for (name, v) in [
            ("rx_size", config.rx_size),
            ("tx_size", config.tx_size),
            ("fill_size", config.fill_size),
            ("comp_size", config.comp_size),
        ] {
            if v == 0 || (v & (v - 1)) != 0 {
                return Err(XskError::Umem(format!(
                    "{name} must be a non-zero power of two, got {v}"
                )));
            }
        }

        if config.ifindex == 0 || config.ifname.is_empty() {
            return Err(XskError::Umem("Invalid interface settings".to_string()));
        }

        let fd = unsafe { libc::socket(AF_XDP, libc::SOCK_RAW, 0) };
        if fd < 0 {
            return Ok(Self::new_simulated(umem_ptr, umem_len, config));
        }

        let umem_reg = XdpUmemReg {
            addr: umem_ptr as u64,
            len: umem_len as u64,
            chunk_size: config.chunk_size,
            headroom: config.headroom,
            flags: 0,
        };

        let res = unsafe {
            libc::setsockopt(
                fd,
                SOL_XDP,
                XDP_UMEM_REG,
                &umem_reg as *const _ as *const libc::c_void,
                std::mem::size_of::<XdpUmemReg>() as libc::socklen_t,
            )
        };
        if res < 0 {
            unsafe { libc::close(fd) };
            return Ok(Self::new_simulated(umem_ptr, umem_len, config));
        }

        for (opt, val, name) in [
            (XDP_UMEM_FILL_RING, config.fill_size, "FILL_RING"),
            (XDP_UMEM_COMPLETION_RING, config.comp_size, "COMP_RING"),
            (XDP_RX_RING, config.rx_size, "RX_RING"),
            (XDP_TX_RING, config.tx_size, "TX_RING"),
        ] {
            let r = unsafe {
                libc::setsockopt(
                    fd,
                    SOL_XDP,
                    opt,
                    &val as *const _ as *const libc::c_void,
                    std::mem::size_of::<u32>() as libc::socklen_t,
                )
            };
            if r < 0 {
                unsafe { libc::close(fd) };
                return Err(XskError::Setsockopt(name.into(), std::io::Error::last_os_error()));
            }
        }

        let mut offsets = XdpMmapOffsets::default();
        let mut optlen = std::mem::size_of::<XdpMmapOffsets>() as libc::socklen_t;
        let res = unsafe {
            libc::getsockopt(
                fd,
                SOL_XDP,
                XDP_MMAP_OFFSETS,
                &mut offsets as *mut _ as *mut libc::c_void,
                &mut optlen,
            )
        };
        if res < 0 {
            unsafe { libc::close(fd) };
            return Ok(Self::new_simulated(umem_ptr, umem_len, config));
        }

        let (fill_ring, rx_ring, tx_ring, ring_maps) = unsafe {
            let fill_size_bytes = offsets.fr.desc as usize + (config.fill_size as usize * 8);
            let fill_map = libc::mmap(
                std::ptr::null_mut(),
                fill_size_bytes,
                libc::PROT_READ | libc::PROT_WRITE,
                libc::MAP_SHARED | libc::MAP_POPULATE,
                fd,
                XDP_UMEM_PGOFF_FILL_RING,
            );

            let rx_size_bytes = offsets.rx.desc as usize + (config.rx_size as usize * std::mem::size_of::<XdpDesc>());
            let rx_map = libc::mmap(
                std::ptr::null_mut(),
                rx_size_bytes,
                libc::PROT_READ | libc::PROT_WRITE,
                libc::MAP_SHARED | libc::MAP_POPULATE,
                fd,
                XDP_PGOFF_RX_RING,
            );

            let tx_size_bytes = offsets.tx.desc as usize + (config.tx_size as usize * std::mem::size_of::<XdpDesc>());
            let tx_map = libc::mmap(
                std::ptr::null_mut(),
                tx_size_bytes,
                libc::PROT_READ | libc::PROT_WRITE,
                libc::MAP_SHARED | libc::MAP_POPULATE,
                fd,
                XDP_PGOFF_TX_RING,
            );

            if fill_map == libc::MAP_FAILED || rx_map == libc::MAP_FAILED || tx_map == libc::MAP_FAILED {
                if fill_map != libc::MAP_FAILED { libc::munmap(fill_map, fill_size_bytes); }
                if rx_map != libc::MAP_FAILED { libc::munmap(rx_map, rx_size_bytes); }
                if tx_map != libc::MAP_FAILED { libc::munmap(tx_map, tx_size_bytes); }
                libc::close(fd);
                return Ok(Self::new_simulated(umem_ptr, umem_len, config));
            }

            let fr = XskRingProd {
                producer: (fill_map as *mut u8).add(offsets.fr.producer as usize) as *mut u32,
                consumer: (fill_map as *mut u8).add(offsets.fr.consumer as usize) as *const u32,
                ring: (fill_map as *mut u8).add(offsets.fr.desc as usize),
                size: config.fill_size,
                mask: config.fill_size - 1,
            };

            let rx = XskRingCons {
                producer: (rx_map as *mut u8).add(offsets.rx.producer as usize) as *const u32,
                consumer: (rx_map as *mut u8).add(offsets.rx.consumer as usize) as *mut u32,
                ring: (rx_map as *mut u8).add(offsets.rx.desc as usize),
                size: config.rx_size,
                mask: config.rx_size - 1,
            };

            let tx = XskRingProd {
                producer: (tx_map as *mut u8).add(offsets.tx.producer as usize) as *mut u32,
                consumer: (tx_map as *mut u8).add(offsets.tx.consumer as usize) as *const u32,
                ring: (tx_map as *mut u8).add(offsets.tx.desc as usize),
                size: config.tx_size,
                mask: config.tx_size - 1,
            };

            (
                Some(fr),
                Some(rx),
                Some(tx),
                vec![
                    (fill_map as *mut u8, fill_size_bytes),
                    (rx_map as *mut u8, rx_size_bytes),
                    (tx_map as *mut u8, tx_size_bytes),
                ],
            )
        };

        let sxdp = SockaddrXdp {
            sxdp_family: AF_XDP as u16,
            sxdp_flags: config.bind_flags,
            sxdp_ifindex: config.ifindex,
            sxdp_queue_id: config.queue_id,
            sxdp_shared_umem_fd: 0,
        };

        let res = unsafe {
            libc::bind(
                fd,
                &sxdp as *const _ as *const libc::sockaddr,
                std::mem::size_of::<SockaddrXdp>() as libc::socklen_t,
            )
        };
        if res < 0 {
            unsafe { libc::close(fd) };
            return Ok(Self::new_simulated(umem_ptr, umem_len, config));
        }

        Ok(Self {
            fd,
            config,
            umem_base: umem_ptr,
            umem_len,
            ring_maps,
            fill_ring,
            rx_ring,
            tx_ring,
            fill_prod: 0,
            fill_cons: 0,
            rx_prod: 0,
            rx_cons: 0,
            tx_prod: 0,
            tx_cons: 0,
            is_simulation: false,
            sim_rx: VecDeque::new(),
            sim_fill: VecDeque::new(),
            umem_memory: None,
        })
    }

    fn new_simulated(umem_ptr: *mut u8, umem_len: usize, config: XskConfig) -> Self {
        Self {
            fd: -1,
            config,
            umem_base: umem_ptr,
            umem_len,
            ring_maps: Vec::new(),
            fill_ring: None,
            rx_ring: None,
            tx_ring: None,
            fill_prod: 0,
            fill_cons: 0,
            rx_prod: 0,
            rx_cons: 0,
            tx_prod: 0,
            tx_cons: 0,
            is_simulation: true,
            sim_rx: VecDeque::new(),
            sim_fill: VecDeque::new(),
            umem_memory: None,
        }
    }

    #[inline(always)]
    pub fn is_simulation(&self) -> bool {
        self.is_simulation
    }

    #[inline(always)]
    pub fn fd(&self) -> i32 {
        self.fd
    }

    pub fn populate_fill_ring(&mut self, chunk_count: u32) -> Result<(), XskError> {
        let chunk_size = self.config.chunk_size as u64;
        let max_chunks = (self.umem_len as u64) / chunk_size;
        let count = chunk_count.min(max_chunks as u32).min(self.config.fill_size);

        if self.is_simulation {
            for i in 0..count {
                self.sim_fill.push_back((i as u64) * chunk_size);
            }
            return Ok(());
        }

        if let Some(ref mut fr) = self.fill_ring {
            let avail = fr.available(&mut self.fill_cons, self.fill_prod);
            let to_fill = count.min(avail);
            for i in 0..to_fill {
                let cursor = self.fill_prod.wrapping_add(i);
                let addr = ((cursor as u64) % max_chunks) * chunk_size;
                unsafe { fr.write_addr(cursor, addr) };
            }
            self.fill_prod = self.fill_prod.wrapping_add(to_fill);
            fr.submit(self.fill_prod);
        }
        Ok(())
    }

    pub fn poll_rx_batch(&mut self, frames: &mut [IngressFrameDesc]) -> Result<usize, XskError> {
        let max_recv = frames.len();
        if max_recv == 0 {
            return Ok(0);
        }

        if self.is_simulation {
            let mut count = 0;
            let tsc = read_cpu_tsc();
            while count < max_recv {
                if let Some(desc) = self.sim_rx.pop_front() {
                    frames[count] = parse_raw_packet_to_desc(
                        self.umem_base,
                        self.umem_len,
                        desc.addr as u32,
                        desc.len,
                        tsc,
                    );
                    count += 1;
                } else {
                    break;
                }
            }
            return Ok(count);
        }

        let mut received = 0;
        let tsc = read_cpu_tsc();
        if let Some(ref mut rx) = self.rx_ring {
            let entries = rx.peek(&mut self.rx_prod, self.rx_cons);
            let to_read = (entries as usize).min(max_recv);
            let umem_base = self.umem_base;
            let umem_len = self.umem_len;

            let mut i = 0;
            while i < to_read {
                let chunk = UNROLL_RX.min(to_read - i);
                let mut desc_buf = [XdpDesc::default(); UNROLL_RX];
                for (j, slot) in desc_buf.iter_mut().enumerate().take(chunk) {
                    let idx = self.rx_cons.wrapping_add((i + j) as u32);
                    *slot = unsafe { rx.read_desc(idx) };
                }
                for (j, desc) in desc_buf.iter().enumerate().take(chunk) {
                    frames[i + j] = parse_raw_packet_to_desc(
                        umem_base,
                        umem_len,
                        desc.addr as u32,
                        desc.len,
                        tsc,
                    );
                }
                i += chunk;
            }

            if to_read > 0 {
                self.rx_cons = self.rx_cons.wrapping_add(to_read as u32);
                rx.release(self.rx_cons);
                received = to_read;
            }
        }
        Ok(received)
    }

    #[inline(always)]
    pub fn get_packet_slice(&self, desc: &IngressFrameDesc) -> &[u8] {
        let offset = desc.data_offset as usize;
        let len = desc.data_len as usize;
        assert!(offset + len <= self.umem_len, "UMEM slice out of bounds");
        unsafe { std::slice::from_raw_parts(self.umem_base.add(offset), len) }
    }

    #[inline(always)]
    pub fn get_packet_slice_mut(&mut self, desc: &IngressFrameDesc) -> &mut [u8] {
        let offset = desc.data_offset as usize;
        let len = desc.data_len as usize;
        assert!(offset + len <= self.umem_len, "UMEM slice out of bounds");
        unsafe { std::slice::from_raw_parts_mut(self.umem_base.add(offset), len) }
    }

    #[inline(always)]
    pub fn get_packet_payload_slice(&self, desc: &IngressFrameDesc) -> &[u8] {
        let pkt = self.get_packet_slice(desc);
        let offset = compute_payload_offset(pkt);
        if offset < pkt.len() { &pkt[offset..] } else { &[] }
    }

    #[inline(always)]
    pub fn get_packet_payload_slice_mut(&mut self, desc: &IngressFrameDesc) -> &mut [u8] {
        let offset = compute_payload_offset(self.get_packet_slice(desc));
        let pkt_mut = self.get_packet_slice_mut(desc);
        if offset < pkt_mut.len() { &mut pkt_mut[offset..] } else { &mut [] }
    }

    pub fn get_umem_splicing_bridge<'a>(
        &'a mut self,
        desc: &IngressFrameDesc,
    ) -> caly_pipe::splicing_bridge::UmemChunkBridge<'a> {
        let payload = self.get_packet_payload_slice_mut(desc);
        caly_pipe::splicing_bridge::UmemChunkBridge::from_mut_slice(payload, desc.data_offset)
    }

    pub fn submit_tx(&mut self, desc: &XdpDesc) -> Result<(), XskError> {
        if self.is_simulation {
            return Ok(());
        }
        if let Some(ref mut tx) = self.tx_ring {
            let avail = tx.available(&mut self.tx_cons, self.tx_prod);
            if avail == 0 {
                return Err(XskError::RingFull);
            }
            unsafe { tx.write_desc(self.tx_prod, desc) };
            self.tx_prod = self.tx_prod.wrapping_add(1);
            tx.submit(self.tx_prod);
            Ok(())
        } else {
            Err(XskError::RingFull)
        }
    }
}

impl Drop for XskSocket {
    fn drop(&mut self) {
        for &(ptr, len) in &self.ring_maps {
            if !ptr.is_null() && len > 0 {
                unsafe { libc::munmap(ptr as *mut libc::c_void, len) };
            }
        }
        self.ring_maps.clear();
        if self.fd >= 0 {
            unsafe { libc::close(self.fd) };
        }
    }
}

#[inline(always)]
pub fn calculate_flow_hash_v4(src: [u8; 4], dst: [u8; 4], sport: u16, dport: u16, proto: u8) -> u32 {
    let s = u32::from_ne_bytes(src);
    let d = u32::from_ne_bytes(dst);
    let (ip_low, ip_high) = if s < d { (s, d) } else { (d, s) };
    let (port_low, port_high) = if sport < dport { (sport, dport) } else { (dport, sport) };
    let ports = ((port_low as u32) << 16) | (port_high as u32);
    ip_low ^ ip_high.rotate_left(13) ^ ports.rotate_left(7) ^ (proto as u32)
}

#[inline(always)]
pub fn calculate_flow_hash_v6(src: [u8; 16], dst: [u8; 16], sport: u16, dport: u16, proto: u8) -> u32 {
    let (ip_low, ip_high) = if src < dst { (src, dst) } else { (dst, src) };
    let (port_low, port_high) = if sport < dport { (sport, dport) } else { (dport, sport) };
    let mut h: u32 = 0x811c9dc5;
    for b in ip_low.iter().chain(ip_high.iter()) {
        h = h.wrapping_mul(16777619) ^ (*b as u32);
    }
    let ports = ((port_low as u32) << 16) | (port_high as u32);
    h ^ ports.rotate_left(11) ^ (proto as u32)
}

#[inline(always)]
pub fn compute_payload_offset(pkt: &[u8]) -> usize {
    if pkt.len() < 14 {
        return 0;
    }
    let mut ethertype = u16::from_be_bytes([pkt[12], pkt[13]]);
    let mut ip_start = 14usize;

    while matches!(ethertype, 0x8100 | 0x88A8 | 0x9100) {
        if pkt.len() < ip_start + 4 {
            return pkt.len();
        }
        ethertype = u16::from_be_bytes([pkt[ip_start + 2], pkt[ip_start + 3]]);
        ip_start += 4;
    }

    match ethertype {
        0x0800 => {
            if pkt.len() < ip_start + 20 {
                return pkt.len();
            }
            let ihl = ((pkt[ip_start] & 0x0F) as usize) * 4;
            if ihl < 20 || pkt.len() < ip_start + ihl {
                return pkt.len();
            }
            let proto = pkt[ip_start + 9];
            let l4_start = ip_start + ihl;
            if proto == 6 {
                if pkt.len() < l4_start + 20 {
                    return pkt.len();
                }
                let tcp_hdr_len = (((pkt[l4_start + 12] >> 4) & 0x0F) as usize) * 4;
                l4_start + tcp_hdr_len.max(20)
            } else if proto == 17 {
                l4_start + 8
            } else {
                l4_start
            }
        }
        0x86DD => {
            if pkt.len() < ip_start + 40 {
                return pkt.len();
            }
            let mut next_header = pkt[ip_start + 6];
            let mut l4_start = ip_start + 40;

            while matches!(next_header, 0 | 43 | 60 | 51) {
                if pkt.len() < l4_start + 2 {
                    return pkt.len();
                }
                let ext_len = (pkt[l4_start + 1] as usize + 1) * 8;
                if pkt.len() < l4_start + ext_len {
                    return pkt.len();
                }
                next_header = pkt[l4_start];
                l4_start += ext_len;
            }

            if next_header == 44 {
                if pkt.len() < l4_start + 8 {
                    return pkt.len();
                }
                next_header = pkt[l4_start];
                l4_start += 8;
            }

            if next_header == 6 {
                if pkt.len() < l4_start + 20 {
                    return pkt.len();
                }
                let tcp_hdr_len = (((pkt[l4_start + 12] >> 4) & 0x0F) as usize) * 4;
                l4_start + tcp_hdr_len.max(20)
            } else if next_header == 17 {
                l4_start + 8
            } else {
                l4_start
            }
        }
        _ => ip_start,
    }
}

#[inline(always)]
pub fn parse_raw_packet_to_desc(
    umem_base: *const u8,
    umem_len: usize,
    umem_offset: u32,
    packet_len: u32,
    tsc: u64,
) -> IngressFrameDesc {
    let mut desc = IngressFrameDesc::new(tsc, umem_offset, packet_len);
    let offset = umem_offset as usize;
    let len = packet_len as usize;

    if offset + len > umem_len || len < 14 {
        return desc;
    }

    unsafe {
        let pkt = std::slice::from_raw_parts(umem_base.add(offset), len);
        let mut ethertype = u16::from_be_bytes([pkt[12], pkt[13]]);
        let mut ip_off = 14usize;

        while matches!(ethertype, 0x8100 | 0x88A8 | 0x9100) {
            if len < ip_off + 4 {
                return desc;
            }
            ethertype = u16::from_be_bytes([pkt[ip_off + 2], pkt[ip_off + 3]]);
            ip_off += 4;
        }

        match ethertype {
            0x0800 => {
                if len >= ip_off + 20 {
                    let ip_hdr = &pkt[ip_off..];
                    let ihl_words = ip_hdr[0] & 0x0F;
                    if ihl_words >= 5 {
                        let ihl = (ihl_words * 4) as usize;
                        if len >= ip_off + ihl {
                            let frag_field = u16::from_be_bytes([ip_hdr[6], ip_hdr[7]]);
                            if (frag_field & 0x3fff) != 0 {
                                return desc;
                            }
                            desc.flags |= FLAG_IPV4;
                            let protocol = ip_hdr[9];
                            let src_ip = [ip_hdr[12], ip_hdr[13], ip_hdr[14], ip_hdr[15]];
                            let dst_ip = [ip_hdr[16], ip_hdr[17], ip_hdr[18], ip_hdr[19]];
                            desc.set_ipv4(Ipv4Addr::from(src_ip));

                            let l4_offset = ip_off + ihl;
                            if protocol == 6 && len >= l4_offset + 20 {
                                desc.flags |= FLAG_TCP;
                                let tcp_hdr = &pkt[l4_offset..];
                                let src_port = u16::from_be_bytes([tcp_hdr[0], tcp_hdr[1]]);
                                let dst_port = u16::from_be_bytes([tcp_hdr[2], tcp_hdr[3]]);
                                desc.peer_port = src_port;
                                let tcp_flags = tcp_hdr[13];
                                if (tcp_flags & 0x02) != 0 { desc.flags |= FLAG_SYN; }
                                if (tcp_flags & 0x01) != 0 { desc.flags |= FLAG_FIN; }
                                if (tcp_flags & 0x04) != 0 { desc.flags |= FLAG_RST; }
                                if (tcp_flags & 0x10) != 0 { desc.flags |= FLAG_ACK; }
                                desc.flow_hash = calculate_flow_hash_v4(src_ip, dst_ip, src_port, dst_port, 6);
                            } else if protocol == 17 && len >= l4_offset + 8 {
                                desc.flags |= FLAG_UDP;
                                let udp_hdr = &pkt[l4_offset..];
                                let src_port = u16::from_be_bytes([udp_hdr[0], udp_hdr[1]]);
                                let dst_port = u16::from_be_bytes([udp_hdr[2], udp_hdr[3]]);
                                desc.peer_port = src_port;
                                desc.flow_hash = calculate_flow_hash_v4(src_ip, dst_ip, src_port, dst_port, 17);
                            }
                        }
                    }
                }
            }
            0x86DD => {
                if len >= ip_off + 40 {
                    let ip_hdr = &pkt[ip_off..];
                    let mut next_header = ip_hdr[6];
                    let mut src_ip = [0u8; 16];
                    let mut dst_ip6 = [0u8; 16];
                    src_ip.copy_from_slice(&ip_hdr[8..24]);
                    dst_ip6.copy_from_slice(&ip_hdr[24..40]);
                    desc.flags |= FLAG_IPV6;
                    desc.set_ipv6(Ipv6Addr::from(src_ip));

                    let mut l4_offset = ip_off + 40;
                    while matches!(next_header, 0 | 43 | 60 | 51) {
                        if len < l4_offset + 2 {
                            return desc;
                        }
                        let ext = &pkt[l4_offset..];
                        let hdr_len = (ext[1] as usize + 1) * 8;
                        if l4_offset.checked_add(hdr_len).map_or(true, |end| end > len) {
                            return desc;
                        }
                        next_header = ext[0];
                        l4_offset += hdr_len;
                    }

                    if next_header == 44 {
                        if len < l4_offset + 8 {
                            return desc;
                        }
                        let frag = &pkt[l4_offset..];
                        let frag_off = u16::from_be_bytes([frag[2], frag[3]]) & 0xfff8;
                        if frag_off != 0 {
                            return desc;
                        }
                        next_header = frag[0];
                        l4_offset += 8;
                    }

                    if next_header == 6 && len >= l4_offset + 20 {
                        desc.flags |= FLAG_TCP;
                        let tcp_hdr = &pkt[l4_offset..];
                        let src_port = u16::from_be_bytes([tcp_hdr[0], tcp_hdr[1]]);
                        let dst_port = u16::from_be_bytes([tcp_hdr[2], tcp_hdr[3]]);
                        desc.peer_port = src_port;
                        let tcp_flags = tcp_hdr[13];
                        if (tcp_flags & 0x02) != 0 { desc.flags |= FLAG_SYN; }
                        if (tcp_flags & 0x01) != 0 { desc.flags |= FLAG_FIN; }
                        if (tcp_flags & 0x04) != 0 { desc.flags |= FLAG_RST; }
                        if (tcp_flags & 0x10) != 0 { desc.flags |= FLAG_ACK; }
                        desc.flow_hash = calculate_flow_hash_v6(src_ip, dst_ip6, src_port, dst_port, 6);
                    } else if next_header == 17 && len >= l4_offset + 8 {
                        desc.flags |= FLAG_UDP;
                        let udp_hdr = &pkt[l4_offset..];
                        let src_port = u16::from_be_bytes([udp_hdr[0], udp_hdr[1]]);
                        let dst_port = u16::from_be_bytes([udp_hdr[2], udp_hdr[3]]);
                        desc.peer_port = src_port;
                        desc.flow_hash = calculate_flow_hash_v6(src_ip, dst_ip6, src_port, dst_port, 17);
                    }
                }
            }
            _ => {}
        }
    }
    desc
}
