//! Composite 64-bit io_uring `user_data` encoding and lifecycle token.
//! Encodes generation tag, operation code, optional fixed buffer index, and connection identifier.

/// High-level I/O operations tracked by the io_uring reactor.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
#[repr(u8)]
pub enum IoOperation {
    /// Reading data from client socket into a fixed buffer.
    ReadClient = 0x01,
    /// Writing data to client socket from a fixed buffer.
    WriteClient = 0x02,
    /// Reading data from server/outbound socket into a fixed buffer.
    ReadServer = 0x03,
    /// Writing data to server/outbound socket from a fixed buffer.
    WriteServer = 0x04,
    /// Asynchronous outbound TCP socket connection.
    Connect = 0x05,
    /// Inbound connection accept operation.
    Accept = 0x06,
    /// Socket descriptor closure.
    Close = 0x07,
}

impl IoOperation {
    #[inline(always)]
    pub fn from_u8(val: u8) -> Self {
        match val {
            0x01 => Self::ReadClient,
            0x02 => Self::WriteClient,
            0x03 => Self::ReadServer,
            0x04 => Self::WriteServer,
            0x05 => Self::Connect,
            0x06 => Self::Accept,
            0x07 => Self::Close,
            _ => Self::Close,
        }
    }
}

/// Composite io_uring user_data token.
/// Bit layout in `u64`:
/// - Bits 56..=63: Generation tag (`u8`) for ABA protection
/// - Bits 48..=55: Operation code (`IoOperation` as `u8`)
/// - Bits 32..=47: Fixed buffer index (`u16`, `0xFFFF` denotes `None`)
/// - Bits 0..=31:  Connection ID (`u32`)
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub struct IoToken {
    pub op: IoOperation,
    pub buf_idx: Option<u16>,
    pub conn_id: u32,
    pub generation: u8,
}

impl IoToken {
    pub const NO_BUFFER: u16 = 0xFFFF;

    #[inline(always)]
    pub const fn new(op: IoOperation, buf_idx: Option<u16>, conn_id: u32) -> Self {
        Self {
            op,
            buf_idx,
            conn_id,
            generation: 0,
        }
    }

    #[inline(always)]
    pub const fn with_generation(op: IoOperation, buf_idx: Option<u16>, conn_id: u32, generation: u8) -> Self {
        Self {
            op,
            buf_idx,
            conn_id,
            generation,
        }
    }

    #[inline(always)]
    pub fn encode(op: IoOperation, buf_idx: Option<u16>, conn_id: u32) -> u64 {
        Self::encode_with_generation(op, buf_idx, conn_id, 0)
    }

    #[inline(always)]
    pub fn encode_with_generation(op: IoOperation, buf_idx: Option<u16>, conn_id: u32, generation: u8) -> u64 {
        const GEN_SHIFT: u64 = 56;
        const OP_SHIFT: u64 = 48;
        const BUF_SHIFT: u64 = 32;
        const BUF_MASK: u64 = 0xFFFF;
        const CONN_MASK: u64 = 0xFFFF_FFFF;

        let gen_part = (generation as u64) << GEN_SHIFT;
        let op_part = (op as u8 as u64) << OP_SHIFT;
        let buf_part = (buf_idx.unwrap_or(Self::NO_BUFFER) as u64 & BUF_MASK) << BUF_SHIFT;
        let conn_part = conn_id as u64 & CONN_MASK;

        gen_part | op_part | buf_part | conn_part
    }

    #[inline(always)]
    pub fn decode(user_data: u64) -> Self {
        let generation = ((user_data >> 56) & 0xFF) as u8;
        let op_raw = ((user_data >> 48) & 0xFF) as u8;
        let op = IoOperation::from_u8(op_raw);
        let buf_raw = ((user_data >> 32) & 0xFFFF) as u16;
        let buf_idx = if buf_raw == Self::NO_BUFFER {
            None
        } else {
            Some(buf_raw)
        };
        let conn_id = (user_data & 0xFFFF_FFFF) as u32;

        Self {
            op,
            buf_idx,
            conn_id,
            generation,
        }
    }

    #[inline(always)]
    pub fn as_u64(&self) -> u64 {
        Self::encode_with_generation(self.op, self.buf_idx, self.conn_id, self.generation)
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_io_token_roundtrip() {
        let cases = [
            (IoOperation::ReadClient, Some(0), 1),
            (IoOperation::WriteServer, Some(511), 1024),
            (IoOperation::WriteClient, Some(16), 999999),
            (IoOperation::Connect, None, 42),
            (IoOperation::Close, None, 0),
            (IoOperation::ReadServer, Some(1023), u32::MAX),
        ];
        for (op, buf_idx, conn_id) in cases {
            let encoded = IoToken::encode(op, buf_idx, conn_id);
            let decoded = IoToken::decode(encoded);
            assert_eq!(decoded.op, op);
            assert_eq!(decoded.buf_idx, buf_idx);
            assert_eq!(decoded.conn_id, conn_id);
            assert_eq!(decoded.generation, 0);
        }
    }

    #[test]
    fn test_io_token_with_generation() {
        let encoded = IoToken::encode_with_generation(IoOperation::ReadClient, Some(8), 500, 42);
        let decoded = IoToken::decode(encoded);
        assert_eq!(decoded.op, IoOperation::ReadClient);
        assert_eq!(decoded.buf_idx, Some(8));
        assert_eq!(decoded.conn_id, 500);
        assert_eq!(decoded.generation, 42);
    }

    #[test]
    fn test_io_operation_unknown_byte_falls_back_to_close() {
        assert_eq!(IoOperation::from_u8(0x42), IoOperation::Close);
    }
}
