//! Safe wrappers around the `libc` syscalls used by the reactor.
//!
//! Every function here documents its preconditions and returns an
//! [`io::Result`], so callers in `reactor.rs` can stay entirely free of
//! `unsafe` blocks. All `unsafe` operations on file descriptors are
//! confined to this module, where they can be audited in isolation.
//!
//! # Invariants
//!
//! * All `fd` arguments must be valid, open, non-blocking socket descriptors
//!   that the caller owns for the duration of the call. The wrappers issue
//!   `MSG_DONTWAIT` / `O_NONBLOCK` where applicable, so they never block.
//! * The wrappers **never** close or otherwise invalidate the descriptor;
//!   ownership transfer is explicit via [`close_fd`].

use std::io;
use std::os::raw::{c_int, c_void};

/// Non-blocking `recv(2)` wrapper.
///
/// * Returns `Ok(0)` on orderly shutdown (peer closed its write half).
/// * Returns `Ok(n)`, `n > 0`, on success.
/// * Returns `Err(WouldBlock)` when no data is currently available
///   (edge-triggered drain loops should stop on this).
/// * Returns `Err(_)` on any other OS error.
#[inline]
pub fn recv_nonblocking(fd: i32, buf: &mut [u8]) -> io::Result<usize> {
    debug_assert!(fd >= 0, "recv_nonblocking called with negative fd");
    // SAFETY: `fd` is a valid, open socket descriptor per the module
    // contract. `buf.as_mut_ptr()` points to `buf.len()` writable bytes
    // that are valid for the duration of the call. MSG_DONTWAIT
    // guarantees the call cannot block.
    let n = unsafe {
        libc::recv(
            fd,
            buf.as_mut_ptr() as *mut c_void,
            buf.len(),
            libc::MSG_DONTWAIT,
        )
    };
    if n < 0 {
        Err(io::Error::last_os_error())
    } else {
        Ok(n as usize)
    }
}

/// Non-blocking `send(2)` wrapper.
///
/// * Returns `Ok(0)` if the peer has shut down its read half.
/// * Returns `Ok(n)`, `n > 0`, on partial or full write.
/// * Returns `Err(WouldBlock)` when the socket buffer is full.
#[inline]
pub fn send_nonblocking(fd: i32, buf: &[u8]) -> io::Result<usize> {
    debug_assert!(fd >= 0, "send_nonblocking called with negative fd");
    // SAFETY: `fd` is a valid, open socket descriptor per the module
    // contract. `buf.as_ptr()` points to `buf.len()` readable bytes.
    // MSG_NOSIGNAL suppresses SIGPIPE on closed peer. MSG_DONTWAIT
    // guarantees the call cannot block.
    let n = unsafe {
        libc::send(
            fd,
            buf.as_ptr() as *const c_void,
            buf.len(),
            libc::MSG_NOSIGNAL | libc::MSG_DONTWAIT,
        )
    };
    if n < 0 {
        Err(io::Error::last_os_error())
    } else {
        Ok(n as usize)
    }
}

/// Non-blocking `accept4(2)` wrapper.
///
/// Returns the new non-blocking, close-on-exec client descriptor.
#[inline]
pub fn accept_nonblocking(listen_fd: i32) -> io::Result<i32> {
    debug_assert!(listen_fd >= 0, "accept_nonblocking called with negative fd");
    // SAFETY: `listen_fd` is a valid, open listening socket. `addr`/`addrlen`
    // are null so the kernel does not write to them.
    let fd = unsafe {
        libc::accept4(
            listen_fd,
            std::ptr::null_mut(),
            std::ptr::null_mut(),
            libc::SOCK_NONBLOCK | libc::SOCK_CLOEXEC,
        )
    };
    if fd < 0 {
        Err(io::Error::last_os_error())
    } else {
        Ok(fd)
    }
}

/// Non-blocking `connect(2)` wrapper.
///
/// * Returns `Ok(true)` if the connection completed immediately.
/// * Returns `Ok(false)` if the connection is in progress (`EINPROGRESS`).
/// * Returns `Err(_)` on any other failure.
#[inline]
pub fn connect_nonblocking(
    fd: i32,
    addr: *const libc::sockaddr,
    addrlen: libc::socklen_t,
) -> io::Result<bool> {
    debug_assert!(fd >= 0, "connect_nonblocking called with negative fd");
    // SAFETY: `fd` is a valid, non-blocking socket. `addr` points to a
    // sockaddr of `addrlen` bytes owned by the caller.
    let ret = unsafe { libc::connect(fd, addr, addrlen) };
    if ret == 0 {
        return Ok(true);
    }
    let err = io::Error::last_os_error();
    match err.raw_os_error() {
        Some(libc::EINPROGRESS) => Ok(false),
        _ => Err(err),
    }
}

/// Creates a non-blocking, close-on-exec TCP socket for the given address family.
#[inline]
pub fn tcp_socket(af_domain: i32) -> io::Result<i32> {
    // SAFETY: `socket(2)` is safe for valid, well-known domain constants
    // (AF_INET, AF_INET6). The returned fd is owned by the caller.
    let fd = unsafe {
        libc::socket(
            af_domain,
            libc::SOCK_STREAM | libc::SOCK_NONBLOCK | libc::SOCK_CLOEXEC,
            0,
        )
    };
    if fd < 0 {
        Err(io::Error::last_os_error())
    } else {
        Ok(fd)
    }
}

/// Closes a descriptor, ignoring errors (for use in `Drop`).
///
/// Returns `true` if the descriptor was actually closed (i.e. it was
/// non-negative on entry). Negative descriptors are silently ignored.
#[inline]
#[must_use]
pub fn close_fd(fd: &mut i32) -> bool {
    if *fd < 0 {
        return false;
    }
    // SAFETY: `*fd` is a valid, open descriptor owned by the caller; after
    // this call it is no longer valid, and we mark it as such below.
    // SAFETY: `fd` is an open descriptor owned by this scope; close consumes it.
    unsafe {
        libc::close(*fd);
    }
    *fd = -1;
    true
}

/// Looks up `SO_ERROR` on a connecting socket to determine the outcome of a
/// non-blocking `connect(2)`.
#[inline]
pub fn take_so_error(fd: i32) -> io::Result<()> {
    let mut err: c_int = 0;
    let mut len = std::mem::size_of::<c_int>() as libc::socklen_t;
    // SAFETY: `fd` is a valid socket; `&mut err` and `&mut len` point to
    // properly-typed locals.
    let res = unsafe {
        libc::getsockopt(
            fd,
            libc::SOL_SOCKET,
            libc::SO_ERROR,
            &mut err as *mut c_int as *mut c_void,
            &mut len,
        )
    };
    if res < 0 {
        return Err(io::Error::last_os_error());
    }
    if err == 0 {
        Ok(())
    } else {
        Err(io::Error::from_raw_os_error(err))
    }
}
